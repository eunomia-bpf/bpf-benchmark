
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_fentry_v53.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	cbz	x2, 0x8c <native_bpf_strncasestr+0x8c>
       4:      	mov	x8, x0
       8:      	mov	x0, xzr
       c:      	mov	x9, x2
      10:      	b	0x34 <native_bpf_strncasestr+0x34>
      14:      	nop
      18:      	nop
      1c:      	nop
      20:      	add	x0, x0, #0x1
      24:      	sub	x9, x9, #0x1
      28:      	add	x8, x8, #0x1
      2c:      	cmp	x0, x2
      30:      	b.eq	0x8c <native_bpf_strncasestr+0x8c>
      34:      	mov	x10, xzr
      38:      	nop
      3c:      	nop
      40:      	cmp	x9, x10
      44:      	b.eq	0x20 <native_bpf_strncasestr+0x20>
      48:      	ldrb	w11, [x1, x10]
      4c:      	cbz	w11, 0x90 <native_bpf_strncasestr+0x90>
      50:      	ldrb	w12, [x8, x10]
      54:      	sub	w13, w12, #0x41
      58:      	orr	w14, w12, #0x20
      5c:      	cmp	w13, #0x1a
      60:      	sub	w13, w11, #0x41
      64:      	csel	w12, w14, w12, lo
      68:      	orr	w14, w11, #0x20
      6c:      	cmp	w13, #0x1a
      70:      	csel	w11, w14, w11, lo
      74:      	cmp	w12, w11
      78:      	b.ne	0x20 <native_bpf_strncasestr+0x20>
      7c:      	cmp	x10, #0x63
      80:      	add	x10, x10, #0x1
      84:      	b.lo	0x40 <native_bpf_strncasestr+0x40>
      88:      	b	0x20 <native_bpf_strncasestr+0x20>
      8c:      	mov	w0, #-0x1               // =-1
      90:      	ret

Disassembly of section fentry/generic_fentry_tail:

0000000000000000 <generic_fentry_setup_event>:
       0:      	sub	sp, sp, #0x90
       4:      	str	x29, [sp, #0x40]
       8:      	stp	x30, x25, [sp, #0x50]
       c:      	stp	x24, x23, [sp, #0x60]
      10:      	stp	x22, x21, [sp, #0x70]
      14:      	stp	x20, x19, [sp, #0x80]
      18:      	str	wzr, [sp, #0x48]
      1c:      	adrp	x20, 0x0 <generic_fentry_setup_event>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x48
      28:      	ldr	x20, [x20]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0x48
      34:      	mov	x0, x20
      38:      	blr	x8
      3c:      	cbz	x0, 0x368 <generic_fentry_setup_event+0x368>
      40:      	adrp	x21, 0x0 <generic_fentry_setup_event>
      44:      	mov	w8, #0x5ef8             // =24312
      48:      	mov	x22, x0
      4c:      	ldr	x21, [x21]
      50:      	add	x1, x0, x8
      54:      	mov	w8, #0x1                // =1
      58:      	mov	x0, x21
      5c:      	blr	x8
      60:      	cbz	x0, 0x368 <generic_fentry_setup_event+0x368>
      64:      	ldr	w8, [x0, #0x54]
      68:      	mov	x23, x0
      6c:      	cbz	w8, 0x128 <generic_fentry_setup_event+0x128>
      70:      	mov	w8, #0x8                // =8
      74:      	mov	w9, #0x4                // =4
      78:      	add	x10, sp, #0x18
      7c:      	add	x0, sp, #0x18
      80:      	mov	w1, #0x8                // =8
      84:      	mov	x2, x19
      88:      	blr	x9
      8c:      	ldr	x25, [sp, #0x18]
      90:      	cbz	x25, 0x368 <generic_fentry_setup_event+0x368>
      94:      	add	x2, x25, #0x110
      98:      	mov	w29, #0x8               // =8
      9c:      	add	x8, sp, #0x18
      a0:      	mov	w9, #0x4                // =4
      a4:      	add	x0, sp, #0x18
      a8:      	mov	w1, #0x8                // =8
      ac:      	mov	w24, #0x4               // =4
      b0:      	blr	x9
      b4:      	ldr	x8, [sp, #0x18]
      b8:      	add	x2, x25, #0x8
      bc:      	mov	w9, #0x4                // =4
      c0:      	add	x0, sp, #0x18
      c4:      	str	x8, [x22, #0x5e50]
      c8:      	add	x8, sp, #0x18
      cc:      	mov	w1, #0x8                // =8
      d0:      	blr	x9
      d4:      	ldr	x8, [sp, #0x18]
      d8:      	add	x2, x25, #0x10
      dc:      	mov	w9, #0x4                // =4
      e0:      	add	x0, sp, #0x18
      e4:      	str	x8, [x22, #0x5e58]
      e8:      	add	x8, sp, #0x18
      ec:      	mov	w1, #0x8                // =8
      f0:      	blr	x9
      f4:      	ldr	x8, [sp, #0x18]
      f8:      	add	x2, x25, #0x18
      fc:      	mov	w9, #0x4                // =4
     100:      	add	x0, sp, #0x18
     104:      	str	x8, [x22, #0x5e60]
     108:      	add	x8, sp, #0x18
     10c:      	mov	w1, #0x8                // =8
     110:      	blr	x9
     114:      	ldr	x8, [sp, #0x18]
     118:      	add	x2, x25, #0x20
     11c:      	str	x8, [x22, #0x5e68]
     120:      	add	x8, sp, #0x18
     124:      	b	0x1b8 <generic_fentry_setup_event+0x1b8>
     128:      	mov	w25, #0x8               // =8
     12c:      	add	x8, sp, #0x18
     130:      	mov	w9, #0x4                // =4
     134:      	add	x0, sp, #0x18
     138:      	mov	w1, #0x8                // =8
     13c:      	mov	x2, x19
     140:      	mov	w24, #0x4               // =4
     144:      	blr	x9
     148:      	ldr	x8, [sp, #0x18]
     14c:      	add	x2, x19, #0x8
     150:      	mov	w9, #0x4                // =4
     154:      	add	x0, sp, #0x18
     158:      	str	x8, [x22, #0x5e50]
     15c:      	add	x8, sp, #0x18
     160:      	mov	w1, #0x8                // =8
     164:      	blr	x9
     168:      	ldr	x8, [sp, #0x18]
     16c:      	add	x2, x19, #0x10
     170:      	mov	w9, #0x4                // =4
     174:      	add	x0, sp, #0x18
     178:      	str	x8, [x22, #0x5e58]
     17c:      	add	x8, sp, #0x18
     180:      	mov	w1, #0x8                // =8
     184:      	blr	x9
     188:      	ldr	x8, [sp, #0x18]
     18c:      	add	x2, x19, #0x18
     190:      	mov	w9, #0x4                // =4
     194:      	add	x0, sp, #0x18
     198:      	str	x8, [x22, #0x5e60]
     19c:      	add	x8, sp, #0x18
     1a0:      	mov	w1, #0x8                // =8
     1a4:      	blr	x9
     1a8:      	ldr	x8, [sp, #0x18]
     1ac:      	add	x2, x19, #0x20
     1b0:      	str	x8, [x22, #0x5e68]
     1b4:      	add	x8, sp, #0x18
     1b8:      	add	x0, sp, #0x18
     1bc:      	mov	w1, #0x8                // =8
     1c0:      	blr	x24
     1c4:      	ldr	x8, [sp, #0x18]
     1c8:      	strh	wzr, [x22, #0x2]
     1cc:      	str	wzr, [x22, #0x4]
     1d0:      	str	x8, [x22, #0x5e70]
     1d4:      	mov	w8, #0xd                // =13
     1d8:      	strb	w8, [x22]
     1dc:      	mov	w8, #0x7d               // =125
     1e0:      	blr	x8
     1e4:      	str	x0, [x22, #0x8]
     1e8:      	str	xzr, [x22, #0x70]
     1ec:      	mov	w8, #0xe                // =14
     1f0:      	mov	w24, #0xe               // =14
     1f4:      	str	wzr, [x22, #0x14]
     1f8:      	blr	x8
     1fc:      	str	w0, [x22, #0x7c]
     200:      	blr	x24
     204:      	cmn	x0, #0x16
     208:      	b.ne	0x22c <generic_fentry_setup_event+0x22c>
     20c:      	add	x2, x19, #0xe8
     210:      	mov	w8, #0x8                // =8
     214:      	mov	w9, #0x4                // =4
     218:      	add	x10, sp, #0x18
     21c:      	add	x0, sp, #0x18
     220:      	mov	w1, #0x8                // =8
     224:      	blr	x9
     228:      	ldr	x0, [sp, #0x18]
     22c:      	str	x0, [x22, #0x68]
     230:      	ldr	w8, [x23, #0x5c]
     234:      	cmp	w8, #0x1
     238:      	b.lt	0x2f0 <generic_fentry_setup_event+0x2f0>
     23c:      	ldr	x8, [x22, #0x60]
     240:      	ldr	x9, [x22, #0x8]
     244:      	mov	w10, #0x1               // =1
     248:      	mov	x3, xzr
     24c:      	add	x1, sp, #0x8
     250:      	add	x2, sp, #0x18
     254:      	str	xzr, [sp, #0x28]
     258:      	stp	x9, x10, [sp, #0x18]
     25c:      	stp	x8, x0, [sp, #0x8]
     260:      	adrp	x0, 0x0 <generic_fentry_setup_event>
     264:      	mov	w8, #0x2                // =2
     268:      	add	x9, sp, #0x8
     26c:      	add	x10, sp, #0x18
     270:      	ldr	x0, [x0]
     274:      	blr	x8
     278:      	cbz	x0, 0x2f0 <generic_fentry_setup_event+0x2f0>
     27c:      	neg	w8, w0
     280:      	adrp	x22, 0x0 <generic_fentry_setup_event>
     284:      	mov	w9, #0x1                // =1
     288:      	strh	w8, [sp, #0x34]
     28c:      	mov	w8, #0x5                // =5
     290:      	add	x1, sp, #0x34
     294:      	mov	w23, #0x1               // =1
     298:      	strh	w8, [sp, #0x36]
     29c:      	mov	x8, #0x46               // =70
     2a0:      	movk	x8, #0x2, lsl #32
     2a4:      	stur	x8, [sp, #0x38]
     2a8:      	add	x8, sp, #0x34
     2ac:      	ldr	x22, [x22]
     2b0:      	mov	x0, x22
     2b4:      	blr	x9
     2b8:      	cbz	x0, 0x2cc <generic_fentry_setup_event+0x2cc>
     2bc:      	ldr	w8, [x0]
     2c0:      	add	w8, w8, #0x1
     2c4:      	str	w8, [x0]
     2c8:      	b	0x2f0 <generic_fentry_setup_event+0x2f0>
     2cc:      	str	w23, [sp, #0x4c]
     2d0:      	mov	x3, xzr
     2d4:      	mov	w8, #0x2                // =2
     2d8:      	add	x9, sp, #0x34
     2dc:      	add	x10, sp, #0x4c
     2e0:      	add	x1, sp, #0x34
     2e4:      	add	x2, sp, #0x4c
     2e8:      	mov	x0, x22
     2ec:      	blr	x8
     2f0:      	str	wzr, [sp, #0x18]
     2f4:      	mov	w8, #0x1                // =1
     2f8:      	add	x9, sp, #0x18
     2fc:      	add	x1, sp, #0x18
     300:      	mov	x0, x20
     304:      	blr	x8
     308:      	adrp	x20, 0x0 <generic_fentry_setup_event>
     30c:      	ldr	x20, [x20]
     310:      	cbz	x0, 0x338 <generic_fentry_setup_event+0x338>
     314:      	mov	w8, #0x5ef8             // =24312
     318:      	add	x1, x0, x8
     31c:      	mov	w8, #0x1                // =1
     320:      	mov	x0, x21
     324:      	blr	x8
     328:      	cbz	x0, 0x338 <generic_fentry_setup_event+0x338>
     32c:      	ldr	w8, [x0, #0x40]
     330:      	cmn	w8, #0x1
     334:      	b.ne	0x350 <generic_fentry_setup_event+0x350>
     338:      	mov	w8, #0x3                // =3
     33c:      	mov	w9, #0xc                // =12
     340:      	mov	x0, x19
     344:      	mov	x1, x20
     348:      	mov	w2, #0x3                // =3
     34c:      	blr	x9
     350:      	mov	w8, #0x1                // =1
     354:      	mov	w9, #0xc                // =12
     358:      	mov	x0, x19
     35c:      	mov	x1, x20
     360:      	mov	w2, #0x1                // =1
     364:      	blr	x9
     368:      	ldp	x20, x19, [sp, #0x80]
     36c:      	mov	w0, wzr
     370:      	ldr	x29, [sp, #0x40]
     374:      	ldp	x22, x21, [sp, #0x70]
     378:      	ldp	x24, x23, [sp, #0x60]
     37c:      	ldp	x30, x25, [sp, #0x50]
     380:      	add	sp, sp, #0x90
     384:      	ret
     388:      	nop
     38c:      	nop

0000000000000390 <generic_fentry_process_event>:
     390:      	sub	sp, sp, #0x150
     394:      	str	x29, [sp, #0x100]
     398:      	stp	x30, x25, [sp, #0x110]
     39c:      	stp	x24, x23, [sp, #0x120]
     3a0:      	stp	x22, x21, [sp, #0x130]
     3a4:      	stp	x20, x19, [sp, #0x140]
     3a8:      	str	wzr, [sp, #0x5c]
     3ac:      	adrp	x22, 0x0 <generic_fentry_setup_event>
     3b0:      	mov	w8, #0x1                // =1
     3b4:      	add	x9, sp, #0x5c
     3b8:      	ldr	x22, [x22]
     3bc:      	mov	x19, x0
     3c0:      	add	x1, sp, #0x5c
     3c4:      	mov	x0, x22
     3c8:      	blr	x8
     3cc:      	cbz	x0, 0xc2c <generic_fentry_process_event+0x89c>
     3d0:      	ldr	w24, [x0, #0x4]
     3d4:      	mov	w29, #0x5efc            // =24316
     3d8:      	adrp	x25, 0x0 <generic_fentry_setup_event>
     3dc:      	mov	x20, x0
     3e0:      	ldr	w21, [x0, x29]
     3e4:      	ldr	x25, [x25]
     3e8:      	lsr	w8, w24, #3
     3ec:      	cmp	w8, #0x464
     3f0:      	b.hi	0xb98 <generic_fentry_process_event+0x808>
     3f4:      	str	wzr, [sp, #0x68]
     3f8:      	mov	w8, #0x1                // =1
     3fc:      	add	x9, sp, #0x68
     400:      	add	x1, sp, #0x68
     404:      	mov	x0, x22
     408:      	blr	x8
     40c:      	cbz	x0, 0xb98 <generic_fentry_process_event+0x808>
     410:      	mov	w8, #0x5ef8             // =24312
     414:      	mov	x23, x0
     418:      	add	x1, x0, x8
     41c:      	adrp	x0, 0x0 <generic_fentry_setup_event>
     420:      	mov	w8, #0x1                // =1
     424:      	ldr	x0, [x0]
     428:      	blr	x8
     42c:      	cmp	w21, #0x4
     430:      	ccmp	x0, #0x0, #0x4, le
     434:      	b.eq	0xb98 <generic_fentry_process_event+0x808>
     438:      	and	x29, x21, #0x7
     43c:      	str	x21, [sp, #0x50]
     440:      	str	x24, [sp, #0x108]
     444:      	add	x8, x0, x29, lsl #2
     448:      	add	x25, x23, x29, lsl #2
     44c:      	ldrsw	x21, [x8, #0x18]
     450:      	ldr	w24, [x8, #0x4]
     454:      	mov	w8, #0x5ea0             // =24224
     458:      	str	wzr, [x25, x8]
     45c:      	and	x10, x21, #0xffffffff
     460:      	tbnz	w21, #0x8, 0x484 <generic_fentry_process_event+0xf4>
     464:      	tbnz	w21, #0x7, 0x48c <generic_fentry_process_event+0xfc>
     468:      	tbnz	w10, #0x6, 0x498 <generic_fentry_process_event+0x108>
     46c:      	add	x8, x0, x29, lsl #2
     470:      	ldr	w8, [x8, #0x40]
     474:      	and	x8, x8, #0x7
     478:      	add	x8, x23, x8, lsl #3
     47c:      	ldr	x8, [x8, #0x5e50]
     480:      	b	0x4bc <generic_fentry_process_event+0x12c>
     484:      	str	xzr, [sp, #0x60]
     488:      	b	0x838 <generic_fentry_process_event+0x4a8>
     48c:      	mov	x8, xzr
     490:      	str	xzr, [sp, #0x60]
     494:      	b	0x4c0 <generic_fentry_process_event+0x130>
     498:      	mov	w8, #0x23               // =35
     49c:      	mov	x23, x0
     4a0:      	mov	x22, x10
     4a4:      	blr	x8
     4a8:      	mov	x10, x22
     4ac:      	adrp	x22, 0x0 <generic_fentry_setup_event>
     4b0:      	mov	x8, x0
     4b4:      	ldr	x22, [x22]
     4b8:      	mov	x0, x23
     4bc:      	str	x8, [sp, #0x60]
     4c0:      	cmp	w29, #0x4
     4c4:      	b.hi	0x838 <generic_fentry_process_event+0x4a8>
     4c8:      	mov	w9, #0x50               // =80
     4cc:      	umaddl	x11, w29, w9, x0
     4d0:      	ldrh	w9, [x11, #0x76]
     4d4:      	cbz	w9, 0x838 <generic_fentry_process_event+0x4a8>
     4d8:      	ldur	w9, [x11, #0x70]
     4dc:      	str	x11, [sp, #0x48]
     4e0:      	add	x8, x8, x9
     4e4:      	str	x8, [sp, #0x60]
     4e8:      	ldurh	w9, [x11, #0x74]
     4ec:      	cbz	w9, 0x52c <generic_fentry_process_event+0x19c>
     4f0:      	mov	w9, #0x8                // =8
     4f4:      	mov	x23, x21
     4f8:      	mov	x21, x22
     4fc:      	mov	x22, x10
     500:      	mov	w10, #0x4               // =4
     504:      	add	x11, sp, #0x60
     508:      	ldr	x2, [sp, #0x60]
     50c:      	add	x0, sp, #0x60
     510:      	mov	w1, #0x8                // =8
     514:      	blr	x10
     518:      	ldr	x11, [sp, #0x48]
     51c:      	mov	x10, x22
     520:      	mov	x22, x21
     524:      	mov	x21, x23
     528:      	tbnz	w0, #0x1f, 0x81c <generic_fentry_process_event+0x48c>
     52c:      	ldurh	w8, [x11, #0x7e]
     530:      	cbz	w8, 0x838 <generic_fentry_process_event+0x4a8>
     534:      	ldr	x8, [sp, #0x60]
     538:      	ldur	w9, [x11, #0x78]
     53c:      	add	x8, x8, x9
     540:      	str	x8, [sp, #0x60]
     544:      	ldurh	w9, [x11, #0x7c]
     548:      	cbz	w9, 0x588 <generic_fentry_process_event+0x1f8>
     54c:      	mov	w9, #0x8                // =8
     550:      	mov	x23, x21
     554:      	mov	x21, x22
     558:      	mov	x22, x10
     55c:      	mov	w10, #0x4               // =4
     560:      	add	x11, sp, #0x60
     564:      	ldr	x2, [sp, #0x60]
     568:      	add	x0, sp, #0x60
     56c:      	mov	w1, #0x8                // =8
     570:      	blr	x10
     574:      	ldr	x11, [sp, #0x48]
     578:      	mov	x10, x22
     57c:      	mov	x22, x21
     580:      	mov	x21, x23
     584:      	tbnz	w0, #0x1f, 0x824 <generic_fentry_process_event+0x494>
     588:      	ldurh	w8, [x11, #0x86]
     58c:      	cbz	w8, 0x838 <generic_fentry_process_event+0x4a8>
     590:      	ldr	x8, [sp, #0x60]
     594:      	ldur	w9, [x11, #0x80]
     598:      	add	x8, x8, x9
     59c:      	str	x8, [sp, #0x60]
     5a0:      	ldurh	w9, [x11, #0x84]
     5a4:      	cbz	w9, 0x5e4 <generic_fentry_process_event+0x254>
     5a8:      	mov	w9, #0x8                // =8
     5ac:      	mov	x23, x21
     5b0:      	mov	x21, x22
     5b4:      	mov	x22, x10
     5b8:      	mov	w10, #0x4               // =4
     5bc:      	add	x11, sp, #0x60
     5c0:      	ldr	x2, [sp, #0x60]
     5c4:      	add	x0, sp, #0x60
     5c8:      	mov	w1, #0x8                // =8
     5cc:      	blr	x10
     5d0:      	ldr	x11, [sp, #0x48]
     5d4:      	mov	x10, x22
     5d8:      	mov	x22, x21
     5dc:      	mov	x21, x23
     5e0:      	tbnz	w0, #0x1f, 0x82c <generic_fentry_process_event+0x49c>
     5e4:      	ldurh	w8, [x11, #0x8e]
     5e8:      	cbz	w8, 0x838 <generic_fentry_process_event+0x4a8>
     5ec:      	ldr	x8, [sp, #0x60]
     5f0:      	ldur	w9, [x11, #0x88]
     5f4:      	add	x8, x8, x9
     5f8:      	str	x8, [sp, #0x60]
     5fc:      	ldurh	w9, [x11, #0x8c]
     600:      	cbz	w9, 0x644 <generic_fentry_process_event+0x2b4>
     604:      	mov	w9, #0x8                // =8
     608:      	mov	x23, x21
     60c:      	mov	x21, x22
     610:      	mov	x22, x10
     614:      	add	x10, sp, #0x60
     618:      	mov	w11, #0x4               // =4
     61c:      	ldr	x2, [sp, #0x60]
     620:      	add	x0, sp, #0x60
     624:      	mov	w1, #0x8                // =8
     628:      	blr	x11
     62c:      	ldr	x11, [sp, #0x48]
     630:      	mov	w9, #0x4                // =4
     634:      	mov	x10, x22
     638:      	mov	x22, x21
     63c:      	mov	x21, x23
     640:      	tbnz	w0, #0x1f, 0x830 <generic_fentry_process_event+0x4a0>
     644:      	ldurh	w8, [x11, #0x96]
     648:      	cbz	w8, 0x838 <generic_fentry_process_event+0x4a8>
     64c:      	ldr	x8, [sp, #0x60]
     650:      	ldur	w9, [x11, #0x90]
     654:      	add	x8, x8, x9
     658:      	str	x8, [sp, #0x60]
     65c:      	ldurh	w9, [x11, #0x94]
     660:      	cbz	w9, 0x6a0 <generic_fentry_process_event+0x310>
     664:      	mov	w9, #0x8                // =8
     668:      	mov	x23, x21
     66c:      	mov	x21, x22
     670:      	mov	x22, x10
     674:      	mov	w10, #0x4               // =4
     678:      	add	x11, sp, #0x60
     67c:      	ldr	x2, [sp, #0x60]
     680:      	add	x0, sp, #0x60
     684:      	mov	w1, #0x8                // =8
     688:      	blr	x10
     68c:      	ldr	x11, [sp, #0x48]
     690:      	mov	x10, x22
     694:      	mov	x22, x21
     698:      	mov	x21, x23
     69c:      	tbnz	w0, #0x1f, 0x1530 <generic_fentry_process_event+0x11a0>
     6a0:      	ldurh	w8, [x11, #0x9e]
     6a4:      	cbz	w8, 0x838 <generic_fentry_process_event+0x4a8>
     6a8:      	ldr	x8, [sp, #0x60]
     6ac:      	ldur	w9, [x11, #0x98]
     6b0:      	add	x8, x8, x9
     6b4:      	str	x8, [sp, #0x60]
     6b8:      	ldurh	w9, [x11, #0x9c]
     6bc:      	cbz	w9, 0x6f8 <generic_fentry_process_event+0x368>
     6c0:      	mov	w9, #0x8                // =8
     6c4:      	mov	x23, x21
     6c8:      	mov	x21, x22
     6cc:      	mov	x22, x10
     6d0:      	mov	w10, #0x4               // =4
     6d4:      	add	x11, sp, #0x60
     6d8:      	ldr	x2, [sp, #0x60]
     6dc:      	add	x0, sp, #0x60
     6e0:      	mov	w1, #0x8                // =8
     6e4:      	blr	x10
     6e8:      	mov	x10, x22
     6ec:      	mov	x22, x21
     6f0:      	mov	x21, x23
     6f4:      	tbnz	w0, #0x1f, 0x1644 <generic_fentry_process_event+0x12b4>
     6f8:      	ldr	x23, [sp, #0x48]
     6fc:      	ldurh	w8, [x23, #0xa6]
     700:      	cbz	w8, 0x838 <generic_fentry_process_event+0x4a8>
     704:      	ldr	x8, [sp, #0x60]
     708:      	ldur	w9, [x23, #0xa0]
     70c:      	add	x8, x8, x9
     710:      	str	x10, [sp, #0x40]
     714:      	str	x8, [sp, #0x60]
     718:      	ldurh	w9, [x23, #0xa4]
     71c:      	cbz	w9, 0x740 <generic_fentry_process_event+0x3b0>
     720:      	mov	w9, #0x8                // =8
     724:      	mov	w10, #0x4               // =4
     728:      	add	x11, sp, #0x60
     72c:      	ldr	x2, [sp, #0x60]
     730:      	add	x0, sp, #0x60
     734:      	mov	w1, #0x8                // =8
     738:      	blr	x10
     73c:      	tbnz	w0, #0x1f, 0x17fc <generic_fentry_process_event+0x146c>
     740:      	ldurh	w8, [x23, #0xae]
     744:      	ldr	x10, [sp, #0x40]
     748:      	cbz	w8, 0x838 <generic_fentry_process_event+0x4a8>
     74c:      	ldr	x8, [sp, #0x60]
     750:      	ldur	w9, [x23, #0xa8]
     754:      	add	x8, x8, x9
     758:      	str	x8, [sp, #0x60]
     75c:      	ldurh	w9, [x23, #0xac]
     760:      	cbz	w9, 0x78c <generic_fentry_process_event+0x3fc>
     764:      	mov	w11, #0x8               // =8
     768:      	mov	w9, #0x4                // =4
     76c:      	add	x10, sp, #0x60
     770:      	ldr	x2, [sp, #0x60]
     774:      	add	x0, sp, #0x60
     778:      	mov	w1, #0x8                // =8
     77c:      	blr	x9
     780:      	ldr	x10, [sp, #0x40]
     784:      	mov	w9, #0x8                // =8
     788:      	tbnz	w0, #0x1f, 0x830 <generic_fentry_process_event+0x4a0>
     78c:      	ldurh	w8, [x23, #0xb6]
     790:      	cbz	w8, 0x838 <generic_fentry_process_event+0x4a8>
     794:      	ldr	x8, [sp, #0x60]
     798:      	ldur	w9, [x23, #0xb0]
     79c:      	add	x8, x8, x9
     7a0:      	str	x8, [sp, #0x60]
     7a4:      	ldurh	w9, [x23, #0xb4]
     7a8:      	cbz	w9, 0x7cc <generic_fentry_process_event+0x43c>
     7ac:      	mov	w9, #0x8                // =8
     7b0:      	mov	w10, #0x4               // =4
     7b4:      	add	x11, sp, #0x60
     7b8:      	ldr	x2, [sp, #0x60]
     7bc:      	add	x0, sp, #0x60
     7c0:      	mov	w1, #0x8                // =8
     7c4:      	blr	x10
     7c8:      	tbnz	w0, #0x1f, 0x2370 <generic_fentry_process_event+0x1fe0>
     7cc:      	ldp	x10, x11, [sp, #0x40]
     7d0:      	ldurh	w8, [x11, #0xbe]
     7d4:      	cbz	w8, 0x838 <generic_fentry_process_event+0x4a8>
     7d8:      	ldr	x8, [sp, #0x60]
     7dc:      	ldur	w9, [x11, #0xb8]
     7e0:      	add	x8, x8, x9
     7e4:      	str	x8, [sp, #0x60]
     7e8:      	ldurh	w9, [x11, #0xbc]
     7ec:      	cbz	w9, 0x838 <generic_fentry_process_event+0x4a8>
     7f0:      	mov	w9, #0x8                // =8
     7f4:      	mov	w10, #0x4               // =4
     7f8:      	add	x11, sp, #0x60
     7fc:      	ldr	x2, [sp, #0x60]
     800:      	add	x0, sp, #0x60
     804:      	mov	w1, #0x8                // =8
     808:      	blr	x10
     80c:      	ldr	x10, [sp, #0x40]
     810:      	tbz	w0, #0x1f, 0x838 <generic_fentry_process_event+0x4a8>
     814:      	mov	w9, #0xa                // =10
     818:      	b	0x830 <generic_fentry_process_event+0x4a0>
     81c:      	mov	w9, #0x1                // =1
     820:      	b	0x830 <generic_fentry_process_event+0x4a0>
     824:      	mov	w9, #0x2                // =2
     828:      	b	0x830 <generic_fentry_process_event+0x4a0>
     82c:      	mov	w9, #0x3                // =3
     830:      	mov	w8, #0x5ea0             // =24224
     834:      	str	w9, [x25, x8]
     838:      	mov	x9, #0x8000             // =32768
     83c:      	mov	w8, #0x1                // =1
     840:      	cmp	w24, #0x2a
     844:      	movk	x9, #0x101, lsl #16
     848:      	lsl	x8, x8, x24
     84c:      	movk	x9, #0x420, lsl #32
     850:      	and	x8, x8, x9
     854:      	ccmp	x8, #0x0, #0x4, ls
     858:      	b.eq	0x948 <generic_fentry_process_event+0x5b8>
     85c:      	str	wzr, [sp, #0xe8]
     860:      	ldr	x21, [sp, #0x60]
     864:      	mov	w8, #0x1                // =1
     868:      	add	x9, sp, #0xe8
     86c:      	add	x1, sp, #0xe8
     870:      	mov	x0, x22
     874:      	blr	x8
     878:      	cbz	x0, 0x8e4 <generic_fentry_process_event+0x554>
     87c:      	mov	w8, #0x6420             // =25632
     880:      	mov	x23, x0
     884:      	add	x25, x0, x8
     888:      	ldr	w8, [x25]
     88c:      	cbz	w8, 0x8fc <generic_fentry_process_event+0x56c>
     890:      	str	wzr, [x25]
     894:      	adrp	x0, 0x0 <generic_fentry_setup_event>
     898:      	mov	w8, #0x1                // =1
     89c:      	add	x9, sp, #0xe8
     8a0:      	ldr	x0, [x0]
     8a4:      	add	x1, sp, #0xe8
     8a8:      	blr	x8
     8ac:      	ldr	x21, [sp, #0x50]
     8b0:      	cbz	x0, 0x990 <generic_fentry_process_event+0x600>
     8b4:      	add	x8, x23, x29, lsl #2
     8b8:      	mov	w9, #0x5ea0             // =24224
     8bc:      	ldr	x24, [sp, #0x108]
     8c0:      	add	x11, x23, x29, lsl #3
     8c4:      	ldr	w10, [x8, x9]
     8c8:      	add	x8, x23, #0x90
     8cc:      	add	x9, x24, #0x4
     8d0:      	str	w10, [x8, x24]
     8d4:      	str	x9, [x11, #0x5e78]
     8d8:      	cbz	w10, 0x9f8 <generic_fentry_process_event+0x668>
     8dc:      	mov	w8, #0x4                // =4
     8e0:      	b	0xaac <generic_fentry_process_event+0x71c>
     8e4:      	mov	x8, xzr
     8e8:      	adrp	x25, 0x0 <generic_fentry_setup_event>
     8ec:      	mov	w29, #0x5efc            // =24316
     8f0:      	ldr	x25, [x25]
     8f4:      	ldr	x21, [sp, #0x50]
     8f8:      	b	0xb90 <generic_fentry_process_event+0x800>
     8fc:      	add	x8, sp, #0xe0
     900:      	cmp	w24, #0x17
     904:      	str	x21, [sp, #0x98]
     908:      	str	xzr, [x8, #0x10]
     90c:      	b.le	0x9a4 <generic_fentry_process_event+0x614>
     910:      	adrp	x25, 0x0 <generic_fentry_setup_event>
     914:      	cmp	w24, #0x18
     918:      	mov	w29, #0x5efc            // =24316
     91c:      	ldr	x25, [x25]
     920:      	b.eq	0xafc <generic_fentry_process_event+0x76c>
     924:      	cmp	w24, #0x25
     928:      	b.eq	0xb40 <generic_fentry_process_event+0x7b0>
     92c:      	cmp	w24, #0x2a
     930:      	b.ne	0xc7c <generic_fentry_process_event+0x8ec>
     934:      	mov	w8, #0x6430             // =25648
     938:      	str	xzr, [x23, #0x6430]
     93c:      	str	x21, [x23, #0x6438]
     940:      	add	x8, x23, x8
     944:      	b	0xb6c <generic_fentry_process_event+0x7dc>
     948:      	ldr	x25, [sp, #0x60]
     94c:      	cmp	w24, #0x15
     950:      	b.gt	0x9cc <generic_fentry_process_event+0x63c>
     954:      	mov	w23, #0x1fe             // =510
     958:      	cmp	w24, #0x9
     95c:      	b.le	0xad4 <generic_fentry_process_event+0x744>
     960:      	cmp	w24, #0x10
     964:      	b.le	0xc84 <generic_fentry_process_event+0x8f4>
     968:      	cmp	w24, #0x12
     96c:      	b.le	0xcfc <generic_fentry_process_event+0x96c>
     970:      	cmp	w24, #0x13
     974:      	b.eq	0xd24 <generic_fentry_process_event+0x994>
     978:      	cmp	w24, #0x14
     97c:      	b.eq	0xd4c <generic_fentry_process_event+0x9bc>
     980:      	cmp	w24, #0x15
     984:      	b.ne	0xd5c <generic_fentry_process_event+0x9cc>
     988:      	mov	w23, #0x20              // =32
     98c:      	b	0xd60 <generic_fentry_process_event+0x9d0>
     990:      	adrp	x25, 0x0 <generic_fentry_setup_event>
     994:      	mov	x8, xzr
     998:      	mov	w29, #0x5efc            // =24316
     99c:      	ldr	x25, [x25]
     9a0:      	b	0xb90 <generic_fentry_process_event+0x800>
     9a4:      	adrp	x25, 0x0 <generic_fentry_setup_event>
     9a8:      	add	x21, sp, #0xe0
     9ac:      	cmp	w24, #0xf
     9b0:      	ldr	x25, [x25]
     9b4:      	mov	w29, #0x5efc            // =24316
     9b8:      	b.eq	0xc4c <generic_fentry_process_event+0x8bc>
     9bc:      	cmp	w24, #0x10
     9c0:      	b.ne	0xc7c <generic_fentry_process_event+0x8ec>
     9c4:      	add	x24, sp, #0x70
     9c8:      	b	0xb20 <generic_fentry_process_event+0x790>
     9cc:      	cmp	w24, #0x20
     9d0:      	b.gt	0xabc <generic_fentry_process_event+0x72c>
     9d4:      	cmp	w24, #0x1a
     9d8:      	b.gt	0xca8 <generic_fentry_process_event+0x918>
     9dc:      	cmp	w24, #0x16
     9e0:      	b.eq	0xcf4 <generic_fentry_process_event+0x964>
     9e4:      	cmp	w24, #0x17
     9e8:      	b.eq	0xca0 <generic_fentry_process_event+0x910>
     9ec:      	cmp	w24, #0x1a
     9f0:      	b.eq	0xd3c <generic_fentry_process_event+0x9ac>
     9f4:      	b	0xd5c <generic_fentry_process_event+0x9cc>
     9f8:      	add	x21, x8, x9
     9fc:      	ldr	w8, [x25, #0x4]
     a00:      	ldr	x25, [x23, #0x6440]
     a04:      	mov	w24, #0x4               // =4
     a08:      	and	x9, x8, #0xfff
     a0c:      	add	x2, x0, x9
     a10:      	mov	w9, #0xfff              // =4095
     a14:      	add	x0, x21, #0x4
     a18:      	sub	w8, w9, w8
     a1c:      	and	w23, w8, #0xfff
     a20:      	mov	w8, #0x4                // =4
     a24:      	mov	w1, w23
     a28:      	blr	x8
     a2c:      	str	w23, [x21]
     a30:      	add	x2, x25, #0x8
     a34:      	mov	w25, #0x8               // =8
     a38:      	add	x8, sp, #0x98
     a3c:      	mov	w9, #0x4                // =4
     a40:      	add	x0, sp, #0x98
     a44:      	mov	w1, #0x8                // =8
     a48:      	blr	x9
     a4c:      	ldr	x8, [sp, #0x98]
     a50:      	add	x9, sp, #0xf0
     a54:      	mov	w10, #0x4               // =4
     a58:      	add	x0, sp, #0xf0
     a5c:      	mov	w1, #0x8                // =8
     a60:      	add	x8, x8, #0x30
     a64:      	ldr	x8, [sp, #0x98]
     a68:      	add	x2, x8, #0x30
     a6c:      	blr	x10
     a70:      	add	x11, sp, #0xe0
     a74:      	mov	w9, #0x2                // =2
     a78:      	add	x10, sp, #0x70
     a7c:      	ldr	x8, [x11, #0x10]
     a80:      	add	x0, sp, #0x70
     a84:      	mov	w1, #0x2                // =2
     a88:      	ldr	x2, [x11, #0x10]
     a8c:      	blr	x24
     a90:      	add	x8, x21, x23
     a94:      	ldr	x24, [sp, #0x108]
     a98:      	ldr	x21, [sp, #0x50]
     a9c:      	str	wzr, [x8, #0x4]
     aa0:      	ldrh	w9, [sp, #0x70]
     aa4:      	strh	w9, [x8, #0x8]
     aa8:      	add	w8, w23, #0xe
     aac:      	adrp	x25, 0x0 <generic_fentry_setup_event>
     ab0:      	mov	w29, #0x5efc            // =24316
     ab4:      	ldr	x25, [x25]
     ab8:      	b	0xb94 <generic_fentry_process_event+0x804>
     abc:      	cmp	w24, #0x26
     ac0:      	b.gt	0xcbc <generic_fentry_process_event+0x92c>
     ac4:      	sub	w8, w24, #0x21
     ac8:      	cmp	w8, #0x4
     acc:      	b.lo	0xca0 <generic_fentry_process_event+0x910>
     ad0:      	b	0xd5c <generic_fentry_process_event+0x9cc>
     ad4:      	cmp	w24, #0x4
     ad8:      	b.gt	0xcd8 <generic_fentry_process_event+0x948>
     adc:      	sub	w8, w24, #0x2
     ae0:      	cmp	w8, #0x2
     ae4:      	b.lo	0xcb4 <generic_fentry_process_event+0x924>
     ae8:      	cmp	w24, #0x1
     aec:      	b.eq	0xcb4 <generic_fentry_process_event+0x924>
     af0:      	cmp	w24, #0x4
     af4:      	b.eq	0xca0 <generic_fentry_process_event+0x910>
     af8:      	b	0xd5c <generic_fentry_process_event+0x9cc>
     afc:      	add	x24, sp, #0x70
     b00:      	mov	w8, #0x8                // =8
     b04:      	mov	w9, #0x4                // =4
     b08:      	ldr	x2, [sp, #0x98]
     b0c:      	add	x0, sp, #0x70
     b10:      	mov	w1, #0x8                // =8
     b14:      	blr	x9
     b18:      	ldr	x8, [sp, #0x70]
     b1c:      	str	x8, [sp, #0x98]
     b20:      	mov	w8, #0x8                // =8
     b24:      	mov	w9, #0x4                // =4
     b28:      	add	x10, sp, #0x98
     b2c:      	add	x0, sp, #0x70
     b30:      	add	x2, sp, #0x98
     b34:      	mov	w1, #0x8                // =8
     b38:      	blr	x9
     b3c:      	b	0xb64 <generic_fentry_process_event+0x7d4>
     b40:      	add	x8, x21, #0x40
     b44:      	mov	w9, #0x8                // =8
     b48:      	mov	w10, #0x4               // =4
     b4c:      	str	x8, [sp, #0x98]
     b50:      	add	x11, sp, #0x70
     b54:      	add	x0, sp, #0x70
     b58:      	mov	w1, #0x8                // =8
     b5c:      	ldr	x2, [sp, #0x98]
     b60:      	blr	x10
     b64:      	ldr	x8, [sp, #0x70]
     b68:      	add	x8, x8, #0x40
     b6c:      	ldr	x21, [sp, #0x50]
     b70:      	str	x8, [x23, #0x6440]
     b74:      	mov	w8, #0x6                // =6
     b78:      	mov	w9, #0xc                // =12
     b7c:      	mov	x0, x19
     b80:      	mov	x1, x25
     b84:      	mov	w2, #0x6                // =6
     b88:      	blr	x9
     b8c:      	mov	x8, xzr
     b90:      	ldr	x24, [sp, #0x108]
     b94:      	add	w24, w24, w8
     b98:      	cmp	w21, #0x3
     b9c:      	str	w24, [x20, #0x4]
     ba0:      	b.gt	0xc10 <generic_fentry_process_event+0x880>
     ba4:      	str	wzr, [sp, #0x98]
     ba8:      	mov	w8, #0x1                // =1
     bac:      	add	x9, sp, #0x98
     bb0:      	add	x1, sp, #0x98
     bb4:      	mov	x0, x22
     bb8:      	blr	x8
     bbc:      	cbz	x0, 0xc10 <generic_fentry_process_event+0x880>
     bc0:      	mov	w8, #0x5ef8             // =24312
     bc4:      	add	x1, x0, x8
     bc8:      	adrp	x0, 0x0 <generic_fentry_setup_event>
     bcc:      	mov	w8, #0x1                // =1
     bd0:      	ldr	x0, [x0]
     bd4:      	blr	x8
     bd8:      	cbz	x0, 0xc10 <generic_fentry_process_event+0x880>
     bdc:      	add	w8, w21, #0x1
     be0:      	and	w9, w8, #0x7
     be4:      	add	x9, x0, w9, uxtw #2
     be8:      	ldr	w9, [x9, #0x40]
     bec:      	cmn	w9, #0x1
     bf0:      	b.eq	0xc10 <generic_fentry_process_event+0x880>
     bf4:      	str	w8, [x20, x29]
     bf8:      	mov	w8, #0x1                // =1
     bfc:      	mov	w9, #0xc                // =12
     c00:      	mov	x0, x19
     c04:      	mov	x1, x25
     c08:      	mov	w2, #0x1                // =1
     c0c:      	blr	x9
     c10:      	str	wzr, [x20, x29]
     c14:      	mov	w8, #0x3                // =3
     c18:      	mov	w9, #0xc                // =12
     c1c:      	mov	x0, x19
     c20:      	mov	x1, x25
     c24:      	mov	w2, #0x3                // =3
     c28:      	blr	x9
     c2c:      	ldp	x20, x19, [sp, #0x140]
     c30:      	mov	w0, wzr
     c34:      	ldr	x29, [sp, #0x100]
     c38:      	ldp	x22, x21, [sp, #0x130]
     c3c:      	ldp	x24, x23, [sp, #0x120]
     c40:      	ldp	x30, x25, [sp, #0x110]
     c44:      	add	sp, sp, #0x150
     c48:      	ret
     c4c:      	mov	w8, #0x8                // =8
     c50:      	mov	w9, #0x4                // =4
     c54:      	add	x10, sp, #0xf0
     c58:      	add	x11, sp, #0x98
     c5c:      	add	x0, sp, #0xf0
     c60:      	add	x2, sp, #0x98
     c64:      	mov	w1, #0x8                // =8
     c68:      	blr	x9
     c6c:      	ldr	x8, [x21, #0x10]
     c70:      	ldr	x21, [sp, #0x50]
     c74:      	cbnz	x8, 0xb70 <generic_fentry_process_event+0x7e0>
     c78:      	b	0xb90 <generic_fentry_process_event+0x800>
     c7c:      	mov	x8, xzr
     c80:      	b	0x8f4 <generic_fentry_process_event+0x564>
     c84:      	sub	w8, w24, #0xa
     c88:      	cmp	w8, #0x2
     c8c:      	b.lo	0xca0 <generic_fentry_process_event+0x910>
     c90:      	sub	w8, w24, #0xc
     c94:      	cmp	w8, #0x2
     c98:      	b.lo	0xcb4 <generic_fentry_process_event+0x924>
     c9c:      	b	0xd5c <generic_fentry_process_event+0x9cc>
     ca0:      	mov	w23, #0x8               // =8
     ca4:      	b	0xd60 <generic_fentry_process_event+0x9d0>
     ca8:      	sub	w8, w24, #0x1d
     cac:      	cmp	w8, #0x4
     cb0:      	b.hs	0xd54 <generic_fentry_process_event+0x9c4>
     cb4:      	mov	w23, #0x4               // =4
     cb8:      	b	0xd60 <generic_fentry_process_event+0x9d0>
     cbc:      	cmp	w24, #0x28
     cc0:      	b.gt	0xd14 <generic_fentry_process_event+0x984>
     cc4:      	cmp	w24, #0x27
     cc8:      	b.eq	0xcf4 <generic_fentry_process_event+0x964>
     ccc:      	cmp	w24, #0x28
     cd0:      	b.eq	0xd24 <generic_fentry_process_event+0x994>
     cd4:      	b	0xd5c <generic_fentry_process_event+0x9cc>
     cd8:      	cmp	w24, #0x6
     cdc:      	b.gt	0xd2c <generic_fentry_process_event+0x99c>
     ce0:      	cmp	w24, #0x5
     ce4:      	b.eq	0xd44 <generic_fentry_process_event+0x9b4>
     ce8:      	cmp	w24, #0x6
     cec:      	b.eq	0xd60 <generic_fentry_process_event+0x9d0>
     cf0:      	b	0xd5c <generic_fentry_process_event+0x9cc>
     cf4:      	mov	w23, #0x10              // =16
     cf8:      	b	0xd60 <generic_fentry_process_event+0x9d0>
     cfc:      	cmp	w24, #0x11
     d00:      	b.eq	0xd60 <generic_fentry_process_event+0x9d0>
     d04:      	cmp	w24, #0x12
     d08:      	mov	x23, x21
     d0c:      	b.eq	0xd60 <generic_fentry_process_event+0x9d0>
     d10:      	b	0xd5c <generic_fentry_process_event+0x9cc>
     d14:      	cmp	w24, #0x29
     d18:      	b.eq	0xd44 <generic_fentry_process_event+0x9b4>
     d1c:      	cmp	w24, #0x2b
     d20:      	b.ne	0xd5c <generic_fentry_process_event+0x9cc>
     d24:      	mov	w23, #0x18              // =24
     d28:      	b	0xd60 <generic_fentry_process_event+0x9d0>
     d2c:      	cmp	w24, #0x7
     d30:      	b.eq	0xd44 <generic_fentry_process_event+0x9b4>
     d34:      	cmp	w24, #0x8
     d38:      	b.ne	0xd5c <generic_fentry_process_event+0x9cc>
     d3c:      	mov	w23, #0x50              // =80
     d40:      	b	0xd60 <generic_fentry_process_event+0x9d0>
     d44:      	mov	w23, #0x40              // =64
     d48:      	b	0xd60 <generic_fentry_process_event+0x9d0>
     d4c:      	mov	w23, #0x98              // =152
     d50:      	b	0xd60 <generic_fentry_process_event+0x9d0>
     d54:      	cmp	w24, #0x1b
     d58:      	b.eq	0xd3c <generic_fentry_process_event+0x9ac>
     d5c:      	mov	x23, xzr
     d60:      	str	x10, [sp, #0x40]
     d64:      	str	wzr, [sp, #0x6c]
     d68:      	mov	w8, #0x1                // =1
     d6c:      	add	x9, sp, #0x6c
     d70:      	add	x1, sp, #0x6c
     d74:      	mov	x0, x22
     d78:      	blr	x8
     d7c:      	mov	x8, xzr
     d80:      	cbz	x0, 0x8e8 <generic_fentry_process_event+0x558>
     d84:      	ldr	x10, [sp, #0x108]
     d88:      	mov	w9, #0x3ffb             // =16379
     d8c:      	sub	x9, x9, x23
     d90:      	cmp	x9, x10
     d94:      	b.ls	0x8e8 <generic_fentry_process_event+0x558>
     d98:      	add	x23, x0, x29, lsl #2
     d9c:      	mov	w8, #0x5ea0             // =24224
     da0:      	ldr	x9, [sp, #0x108]
     da4:      	add	x10, x0, #0x90
     da8:      	str	x25, [sp, #0x48]
     dac:      	ldr	w8, [x23, x8]
     db0:      	add	x25, x9, #0x4
     db4:      	str	w8, [x10, x9]
     db8:      	add	x9, x0, x29, lsl #3
     dbc:      	str	x25, [x9, #0x5e78]
     dc0:      	cbz	w8, 0xdcc <generic_fentry_process_event+0xa3c>
     dc4:      	mov	w8, #0x4                // =4
     dc8:      	b	0x8e8 <generic_fentry_process_event+0x558>
     dcc:      	add	x8, x10, x25
     dd0:      	cmp	w24, #0x17
     dd4:      	str	x10, [sp, #0x20]
     dd8:      	str	x8, [sp, #0x30]
     ddc:      	ldr	x8, [sp, #0x48]
     de0:      	str	x8, [sp, #0x98]
     de4:      	add	x8, sp, #0xe0
     de8:      	str	xzr, [x8, #0x10]
     dec:      	b.le	0xe18 <generic_fentry_process_event+0xa88>
     df0:      	cmp	w24, #0x18
     df4:      	b.eq	0xe34 <generic_fentry_process_event+0xaa4>
     df8:      	cmp	w24, #0x25
     dfc:      	b.eq	0xe84 <generic_fentry_process_event+0xaf4>
     e00:      	cmp	w24, #0x2a
     e04:      	b.ne	0x13b0 <generic_fentry_process_event+0x1020>
     e08:      	ldr	x8, [sp, #0x48]
     e0c:      	stp	xzr, x8, [sp, #0x70]
     e10:      	add	x8, sp, #0x70
     e14:      	b	0xeb8 <generic_fentry_process_event+0xb28>
     e18:      	cmp	w24, #0xf
     e1c:      	b.eq	0x1304 <generic_fentry_process_event+0xf74>
     e20:      	cmp	w24, #0x10
     e24:      	b.ne	0x13b0 <generic_fentry_process_event+0x1020>
     e28:      	add	x21, sp, #0xe8
     e2c:      	add	x24, sp, #0xe0
     e30:      	b	0xe60 <generic_fentry_process_event+0xad0>
     e34:      	add	x21, sp, #0xe8
     e38:      	mov	w8, #0x8                // =8
     e3c:      	mov	w9, #0x4                // =4
     e40:      	ldr	x10, [sp, #0x48]
     e44:      	ldr	x2, [sp, #0x98]
     e48:      	add	x0, sp, #0xe8
     e4c:      	mov	w1, #0x8                // =8
     e50:      	blr	x9
     e54:      	add	x24, sp, #0xe0
     e58:      	ldr	x8, [x24, #0x8]
     e5c:      	str	x8, [sp, #0x98]
     e60:      	mov	w8, #0x8                // =8
     e64:      	mov	w9, #0x4                // =4
     e68:      	add	x10, sp, #0x98
     e6c:      	add	x0, sp, #0xe8
     e70:      	add	x2, sp, #0x98
     e74:      	mov	w1, #0x8                // =8
     e78:      	blr	x9
     e7c:      	ldr	x8, [x24, #0x8]
     e80:      	b	0xeb4 <generic_fentry_process_event+0xb24>
     e84:      	ldr	x8, [sp, #0x48]
     e88:      	mov	w9, #0x8                // =8
     e8c:      	mov	w10, #0x4               // =4
     e90:      	add	x11, sp, #0xe8
     e94:      	add	x0, sp, #0xe8
     e98:      	mov	w1, #0x8                // =8
     e9c:      	add	x8, x8, #0x40
     ea0:      	str	x8, [sp, #0x98]
     ea4:      	ldr	x2, [sp, #0x98]
     ea8:      	blr	x10
     eac:      	add	x8, sp, #0xe0
     eb0:      	ldr	x8, [x8, #0x8]
     eb4:      	add	x8, x8, #0x40
     eb8:      	str	x8, [sp, #0x38]
     ebc:      	str	wzr, [sp, #0x84]
     ec0:      	adrp	x0, 0x0 <generic_fentry_setup_event>
     ec4:      	mov	w8, #0x1                // =1
     ec8:      	add	x9, sp, #0x84
     ecc:      	ldr	x0, [x0]
     ed0:      	add	x1, sp, #0x84
     ed4:      	blr	x8
     ed8:      	cbz	x0, 0x122c <generic_fentry_process_event+0xe9c>
     edc:      	add	x8, x0, #0x1, lsl #12   // =0x1000
     ee0:      	stp	x0, x23, [sp, #0x10]
     ee4:      	str	x8, [sp, #0x40]
     ee8:      	mov	w8, #0x23               // =35
     eec:      	blr	x8
     ef0:      	add	x2, x0, #0xb30
     ef4:      	mov	w24, #0x8               // =8
     ef8:      	add	x8, sp, #0x88
     efc:      	mov	w9, #0x4                // =4
     f00:      	add	x0, sp, #0x88
     f04:      	mov	w1, #0x8                // =8
     f08:      	mov	w29, #0x4               // =4
     f0c:      	blr	x9
     f10:      	ldr	x21, [sp, #0x88]
     f14:      	mov	w9, #0x4                // =4
     f18:      	add	x0, sp, #0x90
     f1c:      	mov	w1, #0x8                // =8
     f20:      	add	x8, x21, #0x18
     f24:      	str	x8, [sp, #0x48]
     f28:      	ldr	x8, [sp, #0x38]
     f2c:      	add	x2, x8, #0x8
     f30:      	add	x8, sp, #0x90
     f34:      	str	x2, [sp, #0x28]
     f38:      	blr	x9
     f3c:      	ldr	x23, [sp, #0x90]
     f40:      	add	x25, sp, #0x98
     f44:      	add	x0, sp, #0x98
     f48:      	mov	w1, #0x8                // =8
     f4c:      	add	x2, x23, #0x10
     f50:      	blr	x29
     f54:      	ldr	x8, [sp, #0x98]
     f58:      	cbz	x8, 0xf6c <generic_fentry_process_event+0xbdc>
     f5c:      	ldr	x9, [sp, #0x40]
     f60:      	ldr	x10, [sp, #0x10]
     f64:      	mov	w8, #0x1000             // =4096
     f68:      	b	0xfb8 <generic_fentry_process_event+0xc28>
     f6c:      	add	x2, x23, #0x18
     f70:      	mov	w8, #0x8                // =8
     f74:      	mov	w9, #0x4                // =4
     f78:      	add	x10, sp, #0x98
     f7c:      	add	x0, sp, #0x98
     f80:      	mov	w1, #0x8                // =8
     f84:      	blr	x9
     f88:      	ldr	x8, [sp, #0x98]
     f8c:      	cmp	x8, x23
     f90:      	b.eq	0xf5c <generic_fentry_process_event+0xbcc>
     f94:      	ldr	x10, [sp, #0x10]
     f98:      	mov	w8, #0x2964             // =10596
     f9c:      	strh	w8, [x10, #0xffe]
     fa0:      	adrp	x8, 0x0 <generic_fentry_setup_event>
     fa4:      	add	x8, x8, #0x0
     fa8:      	add	x9, x10, #0xff6
     fac:      	ldr	x8, [x8]
     fb0:      	str	x8, [x9]
     fb4:      	mov	w8, #0xff6              // =4086
     fb8:      	stp	xzr, xzr, [sp, #0x98]
     fbc:      	add	x2, x21, #0x20
     fc0:      	mov	w21, #0x8               // =8
     fc4:      	add	x0, sp, #0x98
     fc8:      	mov	w1, #0x8                // =8
     fcc:      	add	x23, x25, #0x8
     fd0:      	stp	x10, xzr, [sp, #0xa8]
     fd4:      	add	x10, sp, #0x98
     fd8:      	add	x29, x25, #0x18
     fdc:      	stp	xzr, xzr, [sp, #0xb8]
     fe0:      	add	x25, x10, #0x20
     fe4:      	mov	w24, #0x4               // =4
     fe8:      	str	x9, [sp, #0x40]
     fec:      	str	x9, [sp, #0xc8]
     ff0:      	str	w8, [sp, #0xd0]
     ff4:      	mov	w8, #0x4                // =4
     ff8:      	strb	wzr, [sp, #0xd4]
     ffc:      	blr	x8
    1000:      	ldr	x2, [sp, #0x48]
    1004:      	mov	w8, #0x4                // =4
    1008:      	mov	x0, x23
    100c:      	mov	w1, #0x8                // =8
    1010:      	mov	w23, #0x8               // =8
    1014:      	blr	x8
    1018:      	ldr	x2, [sp, #0x28]
    101c:      	mov	w8, #0x4                // =4
    1020:      	mov	x0, x29
    1024:      	mov	w1, #0x8                // =8
    1028:      	str	x29, [sp, #0x48]
    102c:      	blr	x8
    1030:      	ldr	x2, [sp, #0x38]
    1034:      	mov	x0, x25
    1038:      	mov	w1, #0x8                // =8
    103c:      	blr	x24
    1040:      	ldr	x8, [sp, #0xb8]
    1044:      	mov	w25, #0x80              // =128
    1048:      	sub	x8, x8, #0x20
    104c:      	str	x8, [sp, #0xc0]
    1050:      	b	0x105c <generic_fentry_process_event+0xccc>
    1054:      	subs	w25, w25, #0x1
    1058:      	b.eq	0x11ec <generic_fentry_process_event+0xe5c>
    105c:      	ldp	x29, x2, [sp, #0xb0]
    1060:      	ldp	x8, x9, [sp, #0x98]
    1064:      	cmp	x29, x8
    1068:      	ccmp	x2, x9, #0x0, eq
    106c:      	b.eq	0x11e4 <generic_fentry_process_event+0xe54>
    1070:      	ldr	x24, [sp, #0xc0]
    1074:      	mov	w8, #0x4                // =4
    1078:      	add	x9, sp, #0xd8
    107c:      	add	x0, sp, #0xd8
    1080:      	mov	w1, #0x8                // =8
    1084:      	blr	x8
    1088:      	ldr	x8, [sp, #0xd8]
    108c:      	mov	w21, #0x8               // =8
    1090:      	cmp	x29, x8
    1094:      	b.eq	0x118c <generic_fentry_process_event+0xdfc>
    1098:      	add	x23, x29, #0x18
    109c:      	mov	w8, #0x4                // =4
    10a0:      	add	x9, sp, #0xe8
    10a4:      	add	x0, sp, #0xe8
    10a8:      	mov	w1, #0x8                // =8
    10ac:      	mov	x2, x23
    10b0:      	blr	x8
    10b4:      	add	x8, sp, #0xe0
    10b8:      	ldr	x8, [x8, #0x8]
    10bc:      	cmp	x8, x29
    10c0:      	b.eq	0x118c <generic_fentry_process_event+0xdfc>
    10c4:      	mov	w8, #0x4                // =4
    10c8:      	add	x9, sp, #0xe0
    10cc:      	add	x0, sp, #0xe0
    10d0:      	mov	w1, #0x8                // =8
    10d4:      	mov	x2, x23
    10d8:      	blr	x8
    10dc:      	add	x2, x29, #0x20
    10e0:      	mov	w8, #0x4                // =4
    10e4:      	mov	w9, #0x10               // =16
    10e8:      	add	x10, sp, #0xf0
    10ec:      	add	x0, sp, #0xf0
    10f0:      	mov	w1, #0x10               // =16
    10f4:      	blr	x8
    10f8:      	add	x8, sp, #0xe0
    10fc:      	ldr	w23, [sp, #0xf4]
    1100:      	ldr	x10, [sp, #0xc8]
    1104:      	ldr	w24, [sp, #0xd0]
    1108:      	ldr	x9, [x8, #0x18]
    110c:      	ldr	x8, [sp, #0xa8]
    1110:      	sub	x12, x10, x8
    1114:      	subs	w10, w23, w24
    1118:      	csel	w10, wzr, w10, lo
    111c:      	cmp	w24, w23
    1120:      	csel	w11, w24, w23, lo
    1124:      	cinc	w13, w11, hi
    1128:      	sub	w14, w24, w13
    112c:      	subs	x12, x12, x13
    1130:      	str	w14, [sp, #0xd0]
    1134:      	b.lo	0x11ec <generic_fentry_process_event+0xe5c>
    1138:      	cmp	x12, #0xfff
    113c:      	b.hi	0x11ec <generic_fentry_process_event+0xe5c>
    1140:      	cmp	w24, w23
    1144:      	b.ls	0x1150 <generic_fentry_process_event+0xdc0>
    1148:      	mov	w13, #0x2f              // =47
    114c:      	strb	w13, [x8, x12]
    1150:      	add	x29, x8, x12
    1154:      	cmp	w24, w23
    1158:      	add	x2, x9, x10
    115c:      	and	w1, w11, #0xff
    1160:      	mov	w8, #0x4                // =4
    1164:      	cinc	x0, x29, hi
    1168:      	blr	x8
    116c:      	cmp	w24, w23
    1170:      	str	x29, [sp, #0xc8]
    1174:      	b.ls	0x11ec <generic_fentry_process_event+0xe5c>
    1178:      	add	x8, sp, #0xe0
    117c:      	mov	w23, #0x8               // =8
    1180:      	ldr	x8, [x8]
    1184:      	str	x8, [sp, #0xb0]
    1188:      	b	0x1054 <generic_fentry_process_event+0xcc4>
    118c:      	add	x2, x24, #0x10
    1190:      	mov	w8, #0x4                // =4
    1194:      	add	x9, sp, #0xe8
    1198:      	add	x0, sp, #0xe8
    119c:      	mov	w1, #0x8                // =8
    11a0:      	blr	x8
    11a4:      	add	x9, sp, #0xe0
    11a8:      	ldr	x8, [sp, #0xc0]
    11ac:      	mov	w23, #0x8               // =8
    11b0:      	ldr	x9, [x9, #0x8]
    11b4:      	cmp	x8, x9
    11b8:      	b.eq	0x11e4 <generic_fentry_process_event+0xe54>
    11bc:      	ldr	x0, [sp, #0x48]
    11c0:      	add	x2, x24, #0x18
    11c4:      	mov	w8, #0x4                // =4
    11c8:      	mov	w1, #0x8                // =8
    11cc:      	blr	x8
    11d0:      	add	x8, sp, #0xe0
    11d4:      	ldr	x8, [x8, #0x8]
    11d8:      	add	x9, x8, #0x20
    11dc:      	stp	x9, x8, [sp, #0xb8]
    11e0:      	b	0x1054 <generic_fentry_process_event+0xcc4>
    11e4:      	mov	w8, #0x1                // =1
    11e8:      	strb	w8, [sp, #0xd4]
    11ec:      	ldr	x8, [sp, #0xc8]
    11f0:      	ldr	x2, [sp, #0x40]
    11f4:      	cmp	x8, x2
    11f8:      	b.eq	0x1234 <generic_fentry_process_event+0xea4>
    11fc:      	ldrb	w9, [sp, #0xd4]
    1200:      	mov	w11, #0x1000            // =4096
    1204:      	cmp	w9, #0x0
    1208:      	ldr	w9, [sp, #0xd0]
    120c:      	cset	w10, eq
    1210:      	sub	w11, w11, w9
    1214:      	cmp	w9, #0x0
    1218:      	csel	w9, w11, w9, gt
    121c:      	cbz	x8, 0x122c <generic_fentry_process_event+0xe9c>
    1220:      	lsl	w21, w10, #1
    1224:      	mov	x2, x8
    1228:      	b	0x123c <generic_fentry_process_event+0xeac>
    122c:      	mov	x23, xzr
    1230:      	b	0x12d8 <generic_fentry_process_event+0xf48>
    1234:      	mov	w9, wzr
    1238:      	mov	w21, wzr
    123c:      	ldr	x29, [sp, #0x30]
    1240:      	and	w23, w9, #0xfff
    1244:      	mov	w8, #0x4                // =4
    1248:      	mov	w24, #0x4               // =4
    124c:      	mov	w1, w23
    1250:      	add	x0, x29, #0x4
    1254:      	blr	x8
    1258:      	str	w23, [x29]
    125c:      	ldr	x2, [sp, #0x28]
    1260:      	mov	w25, #0x8               // =8
    1264:      	add	x8, sp, #0x98
    1268:      	mov	w9, #0x4                // =4
    126c:      	add	x0, sp, #0x98
    1270:      	mov	w1, #0x8                // =8
    1274:      	blr	x9
    1278:      	ldr	x8, [sp, #0x98]
    127c:      	add	x9, sp, #0xf0
    1280:      	mov	w10, #0x4               // =4
    1284:      	add	x0, sp, #0xf0
    1288:      	mov	w1, #0x8                // =8
    128c:      	add	x8, x8, #0x30
    1290:      	ldr	x8, [sp, #0x98]
    1294:      	add	x2, x8, #0x30
    1298:      	blr	x10
    129c:      	add	x11, sp, #0xe0
    12a0:      	mov	w9, #0x2                // =2
    12a4:      	add	x10, sp, #0xe8
    12a8:      	ldr	x8, [x11, #0x10]
    12ac:      	add	x0, sp, #0xe8
    12b0:      	mov	w1, #0x2                // =2
    12b4:      	ldr	x2, [x11, #0x10]
    12b8:      	blr	x24
    12bc:      	add	x8, x29, x23
    12c0:      	add	w23, w23, #0xa
    12c4:      	str	w21, [x8, #0x4]
    12c8:      	ldrh	w9, [sp, #0xe8]
    12cc:      	strh	w9, [x8, #0x8]
    12d0:      	mov	w10, #0x5ea0            // =24224
    12d4:      	tbnz	w23, #0x1f, 0x12e4 <generic_fentry_process_event+0xf54>
    12d8:      	and	x8, x23, #0x7fffffff
    12dc:      	add	x8, x8, #0x4
    12e0:      	b	0x8e8 <generic_fentry_process_event+0x558>
    12e4:      	ldr	x9, [sp, #0x18]
    12e8:      	mov	w8, #-0x1               // =-1
    12ec:      	str	w8, [x9, x10]
    12f0:      	ldr	x9, [sp, #0x108]
    12f4:      	ldr	x10, [sp, #0x20]
    12f8:      	str	w8, [x10, x9]
    12fc:      	mov	w8, #0x4                // =4
    1300:      	b	0x8e8 <generic_fentry_process_event+0x558>
    1304:      	mov	w8, #0x8                // =8
    1308:      	mov	w9, #0x4                // =4
    130c:      	add	x10, sp, #0xf0
    1310:      	add	x11, sp, #0x98
    1314:      	add	x0, sp, #0xf0
    1318:      	add	x2, sp, #0x98
    131c:      	mov	w1, #0x8                // =8
    1320:      	blr	x9
    1324:      	add	x8, sp, #0xe0
    1328:      	ldr	x8, [x8, #0x10]
    132c:      	str	x8, [sp, #0x38]
    1330:      	cbnz	x8, 0xebc <generic_fentry_process_event+0xb2c>
    1334:      	str	x23, [sp, #0x18]
    1338:      	str	wzr, [sp, #0x90]
    133c:      	mov	w8, #0x1                // =1
    1340:      	add	x9, sp, #0x90
    1344:      	add	x1, sp, #0x90
    1348:      	mov	x0, x22
    134c:      	blr	x8
    1350:      	mov	x23, xzr
    1354:      	cbz	x0, 0x12d0 <generic_fentry_process_event+0xf40>
    1358:      	cmp	w24, #0x19
    135c:      	str	x19, [sp, #0x8]
    1360:      	b.gt	0x164c <generic_fentry_process_event+0x12bc>
    1364:      	mov	x8, x24
    1368:      	cmp	w24, #0x12
    136c:      	b.le	0x167c <generic_fentry_process_event+0x12ec>
    1370:      	cmp	w24, #0x14
    1374:      	b.le	0x1a28 <generic_fentry_process_event+0x1698>
    1378:      	cmp	w8, #0x15
    137c:      	b.eq	0x2134 <generic_fentry_process_event+0x1da4>
    1380:      	cmp	w8, #0x16
    1384:      	b.eq	0x20d4 <generic_fentry_process_event+0x1d44>
    1388:      	adrp	x22, 0x1000 <generic_fentry_process_event+0xc70>
    138c:      	cmp	w8, #0x17
    1390:      	ldr	x22, [x22]
    1394:      	ldr	x19, [sp, #0x8]
    1398:      	b.ne	0x12d0 <generic_fentry_process_event+0xf40>
    139c:      	ldr	x8, [sp, #0x30]
    13a0:      	ldr	x9, [sp, #0x48]
    13a4:      	mov	w23, #0x8               // =8
    13a8:      	stp	w9, wzr, [x8]
    13ac:      	b	0x12d0 <generic_fentry_process_event+0xf40>
    13b0:      	cmp	w24, #0x28
    13b4:      	b.hi	0x1334 <generic_fentry_process_event+0xfa4>
    13b8:      	mov	x9, #0x7cf2             // =31986
    13bc:      	mov	w8, #0x1                // =1
    13c0:      	movk	x9, #0xf202, lsl #16
    13c4:      	lsl	x8, x8, x24
    13c8:      	movk	x9, #0x1c1, lsl #32
    13cc:      	tst	x8, x9
    13d0:      	b.eq	0x1334 <generic_fentry_process_event+0xfa4>
    13d4:      	ldr	x9, [sp, #0x48]
    13d8:      	add	x8, sp, #0xe0
    13dc:      	str	x23, [sp, #0x18]
    13e0:      	add	x1, sp, #0x90
    13e4:      	mov	x0, x22
    13e8:      	str	wzr, [sp, #0x90]
    13ec:      	str	x9, [x8]
    13f0:      	mov	w8, #0x1                // =1
    13f4:      	add	x9, sp, #0x90
    13f8:      	blr	x8
    13fc:      	mov	x23, xzr
    1400:      	cbz	x0, 0x12d0 <generic_fentry_process_event+0xf40>
    1404:      	cmp	w24, #0x10
    1408:      	b.gt	0x1538 <generic_fentry_process_event+0x11a8>
    140c:      	cmp	w24, #0x9
    1410:      	b.gt	0x1564 <generic_fentry_process_event+0x11d4>
    1414:      	cmp	w24, #0x4
    1418:      	str	x19, [sp, #0x8]
    141c:      	b.le	0x16d8 <generic_fentry_process_event+0x1348>
    1420:      	cmp	w24, #0x5
    1424:      	b.eq	0x1cb0 <generic_fentry_process_event+0x1920>
    1428:      	mov	x8, x24
    142c:      	cmp	w8, #0x6
    1430:      	b.eq	0x15c8 <generic_fentry_process_event+0x1238>
    1434:      	adrp	x22, 0x1000 <generic_fentry_process_event+0xc70>
    1438:      	cmp	w8, #0x7
    143c:      	mov	w10, #0x5ea0            // =24224
    1440:      	ldr	x22, [x22]
    1444:      	ldr	x19, [sp, #0x8]
    1448:      	b.ne	0x12d4 <generic_fentry_process_event+0xf44>
    144c:      	add	x8, sp, #0xe0
    1450:      	ldr	x29, [sp, #0x30]
    1454:      	mov	x21, x0
    1458:      	mov	w25, #0x2               // =2
    145c:      	ldr	x23, [x8]
    1460:      	mov	w8, #0x4                // =4
    1464:      	mov	w1, #0x2                // =2
    1468:      	mov	w24, #0x4               // =4
    146c:      	str	x23, [x29, #0x28]
    1470:      	add	x0, x29, #0x26
    1474:      	add	x2, x23, #0x10
    1478:      	blr	x8
    147c:      	add	x0, x29, #0x3a
    1480:      	add	x2, x23, #0x12
    1484:      	mov	w8, #0x1                // =1
    1488:      	mov	w9, #0x4                // =4
    148c:      	mov	w1, #0x1                // =1
    1490:      	blr	x9
    1494:      	add	x0, x29, #0x38
    1498:      	add	x2, x23, #0x21e
    149c:      	mov	w8, #0x4                // =4
    14a0:      	mov	w1, #0x2                // =2
    14a4:      	blr	x8
    14a8:      	add	x0, x29, #0x24
    14ac:      	add	x2, x23, #0x21c
    14b0:      	mov	w8, #0x4                // =4
    14b4:      	mov	w1, #0x2                // =2
    14b8:      	blr	x8
    14bc:      	add	x0, x29, #0x30
    14c0:      	add	x2, x23, #0x214
    14c4:      	mov	w8, #0x4                // =4
    14c8:      	mov	w1, #0x4                // =4
    14cc:      	blr	x8
    14d0:      	add	x0, x29, #0x34
    14d4:      	add	x2, x23, #0x210
    14d8:      	mov	w1, #0x4                // =4
    14dc:      	blr	x24
    14e0:      	ldrh	w8, [x29, #0x26]
    14e4:      	mov	x24, x29
    14e8:      	stp	xzr, xzr, [x29]
    14ec:      	cmp	w8, #0xa
    14f0:      	str	xzr, [x29, #0x18]
    14f4:      	str	xzr, [x24, #0x10]!
    14f8:      	b.eq	0x240c <generic_fentry_process_event+0x207c>
    14fc:      	cmp	w8, #0x2
    1500:      	b.ne	0x2438 <generic_fentry_process_event+0x20a8>
    1504:      	ldr	x0, [sp, #0x30]
    1508:      	add	x2, x23, #0x4
    150c:      	mov	w8, #0x4                // =4
    1510:      	mov	w1, #0x4                // =4
    1514:      	mov	w25, #0x4               // =4
    1518:      	blr	x8
    151c:      	mov	x0, x24
    1520:      	mov	w1, #0x4                // =4
    1524:      	mov	x2, x23
    1528:      	blr	x25
    152c:      	b	0x2438 <generic_fentry_process_event+0x20a8>
    1530:      	mov	w9, #0x5                // =5
    1534:      	b	0x830 <generic_fentry_process_event+0x4a0>
    1538:      	cmp	w24, #0x1e
    153c:      	b.gt	0x1604 <generic_fentry_process_event+0x1274>
    1540:      	cmp	w24, #0x1c
    1544:      	b.gt	0x173c <generic_fentry_process_event+0x13ac>
    1548:      	mov	x8, x24
    154c:      	cmp	w8, #0x11
    1550:      	b.eq	0x1e14 <generic_fentry_process_event+0x1a84>
    1554:      	cmp	w8, #0x19
    1558:      	b.eq	0x1ad0 <generic_fentry_process_event+0x1740>
    155c:      	cmp	w8, #0x1c
    1560:      	b	0x16f4 <generic_fentry_process_event+0x1364>
    1564:      	sub	w8, w24, #0xa
    1568:      	cmp	w8, #0x2
    156c:      	b.lo	0x16fc <generic_fentry_process_event+0x136c>
    1570:      	sub	w8, w24, #0xc
    1574:      	cmp	w8, #0x2
    1578:      	b.lo	0x171c <generic_fentry_process_event+0x138c>
    157c:      	mov	x9, x24
    1580:      	mov	w10, #0x5ea0            // =24224
    1584:      	cmp	w9, #0xe
    1588:      	b.ne	0x12d4 <generic_fentry_process_event+0xf44>
    158c:      	str	x19, [sp, #0x8]
    1590:      	mov	w21, #0x8               // =8
    1594:      	add	x8, sp, #0x98
    1598:      	add	x24, sp, #0xe0
    159c:      	mov	w9, #0x4                // =4
    15a0:      	add	x0, sp, #0x98
    15a4:      	add	x2, sp, #0xe0
    15a8:      	mov	w1, #0x8                // =8
    15ac:      	mov	w23, #0x4               // =4
    15b0:      	blr	x9
    15b4:      	ldr	x8, [sp, #0x98]
    15b8:      	add	x0, sp, #0xe0
    15bc:      	mov	w1, #0x8                // =8
    15c0:      	ldr	x2, [sp, #0x98]
    15c4:      	blr	x23
    15c8:      	add	x8, sp, #0xe0
    15cc:      	mov	w9, #0x2d               // =45
    15d0:      	mov	w1, #0x1ff              // =511
    15d4:      	ldr	x2, [x8]
    15d8:      	ldr	x8, [sp, #0x30]
    15dc:      	add	x0, x8, #0x4
    15e0:      	mov	w8, #0x1ff              // =511
    15e4:      	blr	x9
    15e8:      	mov	x23, x0
    15ec:      	tbnz	x0, #0x3f, 0x3628 <generic_fentry_process_event+0x3298>
    15f0:      	ldr	x9, [sp, #0x30]
    15f4:      	sub	w8, w23, #0x1
    15f8:      	add	x23, x23, #0x3
    15fc:      	str	w8, [x9]
    1600:      	b	0x3628 <generic_fentry_process_event+0x3298>
    1604:      	mov	x29, x19
    1608:      	mov	x25, x22
    160c:      	cmp	w24, #0x26
    1610:      	b.gt	0x1760 <generic_fentry_process_event+0x13d0>
    1614:      	sub	w8, w24, #0x1f
    1618:      	cmp	w8, #0x2
    161c:      	b.hs	0x19b0 <generic_fentry_process_event+0x1620>
    1620:      	ldr	x0, [sp, #0x30]
    1624:      	mov	w8, #0x1                // =1
    1628:      	add	x9, sp, #0xe0
    162c:      	mov	w10, #0x4               // =4
    1630:      	add	x2, sp, #0xe0
    1634:      	mov	w1, #0x1                // =1
    1638:      	mov	w23, #0x4               // =4
    163c:      	blr	x10
    1640:      	b	0x25f8 <generic_fentry_process_event+0x2268>
    1644:      	mov	w9, #0x6                // =6
    1648:      	b	0x830 <generic_fentry_process_event+0x4a0>
    164c:      	cmp	w24, #0x20
    1650:      	b.le	0x192c <generic_fentry_process_event+0x159c>
    1654:      	sub	w8, w24, #0x21
    1658:      	cmp	w8, #0x4
    165c:      	b.hs	0x1808 <generic_fentry_process_event+0x1478>
    1660:      	ldr	x0, [sp, #0x30]
    1664:      	ldr	x2, [sp, #0x48]
    1668:      	mov	w23, #0x8               // =8
    166c:      	mov	w8, #0x4                // =4
    1670:      	mov	w1, #0x8                // =8
    1674:      	blr	x8
    1678:      	b	0x2d58 <generic_fentry_process_event+0x29c8>
    167c:      	cmp	w24, #0x7
    1680:      	b.gt	0x19f0 <generic_fentry_process_event+0x1660>
    1684:      	mov	x29, x0
    1688:      	cmp	w8, #0x2
    168c:      	b.eq	0x1f08 <generic_fentry_process_event+0x1b78>
    1690:      	adrp	x22, 0x1000 <generic_fentry_process_event+0xc70>
    1694:      	cmp	w8, #0x3
    1698:      	ldr	x22, [x22]
    169c:      	ldr	x19, [sp, #0x8]
    16a0:      	b.ne	0x12d0 <generic_fentry_process_event+0xf40>
    16a4:      	add	x24, x29, #0x90
    16a8:      	and	w8, w21, #0xf
    16ac:      	add	x25, x24, x25
    16b0:      	cmp	w8, #0x2
    16b4:      	b.le	0x2594 <generic_fentry_process_event+0x2204>
    16b8:      	cmp	w8, #0x3
    16bc:      	b.eq	0x2730 <generic_fentry_process_event+0x23a0>
    16c0:      	cmp	w8, #0x4
    16c4:      	b.eq	0x2738 <generic_fentry_process_event+0x23a8>
    16c8:      	cmp	w8, #0x5
    16cc:      	b.ne	0x278c <generic_fentry_process_event+0x23fc>
    16d0:      	mov	w8, #0x5e70             // =24176
    16d4:      	b	0x2744 <generic_fentry_process_event+0x23b4>
    16d8:      	adrp	x22, 0x1000 <generic_fentry_process_event+0xc70>
    16dc:      	cmp	w24, #0x1
    16e0:      	ldr	x22, [x22]
    16e4:      	ldr	x19, [sp, #0x8]
    16e8:      	b.eq	0x171c <generic_fentry_process_event+0x138c>
    16ec:      	mov	x8, x24
    16f0:      	cmp	w8, #0x4
    16f4:      	mov	w10, #0x5ea0            // =24224
    16f8:      	b.ne	0x12d4 <generic_fentry_process_event+0xf44>
    16fc:      	ldr	x0, [sp, #0x30]
    1700:      	mov	w23, #0x8               // =8
    1704:      	mov	w8, #0x4                // =4
    1708:      	add	x9, sp, #0xe0
    170c:      	add	x2, sp, #0xe0
    1710:      	mov	w1, #0x8                // =8
    1714:      	blr	x8
    1718:      	b	0x12d0 <generic_fentry_process_event+0xf40>
    171c:      	ldr	x0, [sp, #0x30]
    1720:      	add	x8, sp, #0xe0
    1724:      	mov	w9, #0x4                // =4
    1728:      	add	x2, sp, #0xe0
    172c:      	mov	w1, #0x4                // =4
    1730:      	mov	w23, #0x4               // =4
    1734:      	blr	x9
    1738:      	b	0x12d0 <generic_fentry_process_event+0xf40>
    173c:      	ldr	x0, [sp, #0x30]
    1740:      	mov	w8, #0x2                // =2
    1744:      	add	x9, sp, #0xe0
    1748:      	mov	w10, #0x4               // =4
    174c:      	add	x2, sp, #0xe0
    1750:      	mov	w1, #0x2                // =2
    1754:      	mov	w23, #0x4               // =4
    1758:      	blr	x10
    175c:      	b	0x12d0 <generic_fentry_process_event+0xf40>
    1760:      	cmp	w24, #0x27
    1764:      	b.eq	0x1ec8 <generic_fentry_process_event+0x1b38>
    1768:      	mov	x8, x24
    176c:      	mov	w10, #0x5ea0            // =24224
    1770:      	mov	x22, x25
    1774:      	mov	x19, x29
    1778:      	cmp	w8, #0x28
    177c:      	b.ne	0x12d4 <generic_fentry_process_event+0xf44>
    1780:      	ldr	x0, [sp, #0x30]
    1784:      	add	x8, sp, #0xe0
    1788:      	mov	w9, #0x4                // =4
    178c:      	mov	w1, #0x2                // =2
    1790:      	ldr	x23, [x8]
    1794:      	mov	w8, #0x2                // =2
    1798:      	str	xzr, [x0]
    179c:      	stp	xzr, xzr, [x0, #0x8]
    17a0:      	mov	x2, x23
    17a4:      	blr	x9
    17a8:      	tbnz	x0, #0x3f, 0x25f4 <generic_fentry_process_event+0x2264>
    17ac:      	ldr	x8, [sp, #0x30]
    17b0:      	ldrh	w8, [x8]
    17b4:      	cmp	w8, #0xa
    17b8:      	b.eq	0x25ac <generic_fentry_process_event+0x221c>
    17bc:      	cmp	w8, #0x2
    17c0:      	b.ne	0x25e0 <generic_fentry_process_event+0x2250>
    17c4:      	add	x2, x23, #0x4
    17c8:      	add	x8, sp, #0x98
    17cc:      	mov	w9, #0x4                // =4
    17d0:      	add	x0, sp, #0x98
    17d4:      	mov	w1, #0x4                // =4
    17d8:      	mov	w21, #0x4               // =4
    17dc:      	blr	x9
    17e0:      	ldr	w8, [sp, #0x98]
    17e4:      	ldr	x9, [sp, #0x30]
    17e8:      	add	x2, x23, #0x2
    17ec:      	add	x0, x9, #0x2
    17f0:      	str	x8, [x9, #0x8]
    17f4:      	mov	w8, #0x2                // =2
    17f8:      	b	0x25d8 <generic_fentry_process_event+0x2248>
    17fc:      	ldr	x10, [sp, #0x40]
    1800:      	mov	w9, #0x7                // =7
    1804:      	b	0x830 <generic_fentry_process_event+0x4a0>
    1808:      	mov	x9, x24
    180c:      	cmp	w9, #0x2b
    1810:      	b.eq	0x21f0 <generic_fentry_process_event+0x1e60>
    1814:      	adrp	x22, 0x1000 <generic_fentry_process_event+0xc70>
    1818:      	cmp	w9, #0x29
    181c:      	ldr	x22, [x22]
    1820:      	ldr	x19, [sp, #0x8]
    1824:      	b.ne	0x12d0 <generic_fentry_process_event+0xf40>
    1828:      	ldr	x8, [sp, #0x48]
    182c:      	mov	w9, #0x4                // =4
    1830:      	add	x10, sp, #0x98
    1834:      	mov	x21, x0
    1838:      	add	x0, sp, #0x98
    183c:      	mov	w1, #0x8                // =8
    1840:      	add	x2, x8, #0x18
    1844:      	mov	w8, #0x8                // =8
    1848:      	blr	x9
    184c:      	ldr	x23, [sp, #0x98]
    1850:      	cbz	x23, 0x26e8 <generic_fentry_process_event+0x2358>
    1854:      	ldr	x29, [sp, #0x30]
    1858:      	add	x2, x23, #0x10
    185c:      	mov	w25, #0x2               // =2
    1860:      	mov	w8, #0x4                // =4
    1864:      	str	x23, [x29, #0x28]
    1868:      	add	x0, x29, #0x26
    186c:      	mov	w1, #0x2                // =2
    1870:      	mov	w24, #0x4               // =4
    1874:      	blr	x8
    1878:      	add	x0, x29, #0x3a
    187c:      	add	x2, x23, #0x12
    1880:      	mov	w8, #0x1                // =1
    1884:      	mov	w9, #0x4                // =4
    1888:      	mov	w1, #0x1                // =1
    188c:      	blr	x9
    1890:      	add	x0, x29, #0x38
    1894:      	add	x2, x23, #0x21e
    1898:      	mov	w8, #0x4                // =4
    189c:      	mov	w1, #0x2                // =2
    18a0:      	blr	x8
    18a4:      	add	x0, x29, #0x24
    18a8:      	add	x2, x23, #0x21c
    18ac:      	mov	w8, #0x4                // =4
    18b0:      	mov	w1, #0x2                // =2
    18b4:      	blr	x8
    18b8:      	add	x0, x29, #0x30
    18bc:      	add	x2, x23, #0x214
    18c0:      	mov	w8, #0x4                // =4
    18c4:      	mov	w1, #0x4                // =4
    18c8:      	blr	x8
    18cc:      	add	x0, x29, #0x34
    18d0:      	add	x2, x23, #0x210
    18d4:      	mov	w1, #0x4                // =4
    18d8:      	blr	x24
    18dc:      	ldrh	w8, [x29, #0x26]
    18e0:      	mov	x24, x29
    18e4:      	stp	xzr, xzr, [x29]
    18e8:      	cmp	w8, #0xa
    18ec:      	str	xzr, [x29, #0x18]
    18f0:      	str	xzr, [x24, #0x10]!
    18f4:      	b.eq	0x2678 <generic_fentry_process_event+0x22e8>
    18f8:      	cmp	w8, #0x2
    18fc:      	b.ne	0x26a4 <generic_fentry_process_event+0x2314>
    1900:      	ldr	x0, [sp, #0x30]
    1904:      	add	x2, x23, #0x4
    1908:      	mov	w8, #0x4                // =4
    190c:      	mov	w1, #0x4                // =4
    1910:      	mov	w25, #0x4               // =4
    1914:      	blr	x8
    1918:      	mov	x0, x24
    191c:      	mov	w1, #0x4                // =4
    1920:      	mov	x2, x23
    1924:      	blr	x25
    1928:      	b	0x26a4 <generic_fentry_process_event+0x2314>
    192c:      	cmp	w24, #0x1a
    1930:      	b.eq	0x2280 <generic_fentry_process_event+0x1ef0>
    1934:      	adrp	x22, 0x1000 <generic_fentry_process_event+0xc70>
    1938:      	mov	x8, x24
    193c:      	ldr	x22, [x22]
    1940:      	ldr	x19, [sp, #0x8]
    1944:      	cmp	w8, #0x1b
    1948:      	b.ne	0x12d0 <generic_fentry_process_event+0xf40>
    194c:      	ldr	x10, [sp, #0x30]
    1950:      	ldr	x8, [sp, #0x48]
    1954:      	mov	w9, #0x2d               // =45
    1958:      	mov	w1, #0x3f               // =63
    195c:      	mov	x0, x10
    1960:      	stp	xzr, xzr, [x10, #0x40]
    1964:      	stp	xzr, xzr, [x10, #0x30]
    1968:      	stp	xzr, xzr, [x10, #0x20]
    196c:      	str	xzr, [x10, #0x18]
    1970:      	stp	xzr, xzr, [x10]
    1974:      	add	x2, x8, #0x18
    1978:      	mov	w8, #0x3f               // =63
    197c:      	str	xzr, [x0, #0x10]!
    1980:      	blr	x9
    1984:      	tbnz	x0, #0x3f, 0x24c4 <generic_fentry_process_event+0x2134>
    1988:      	ldr	x8, [sp, #0x30]
    198c:      	mov	w9, #0x4                // =4
    1990:      	mov	w1, #0x8                // =8
    1994:      	add	x0, x8, #0x8
    1998:      	ldr	x8, [sp, #0x48]
    199c:      	add	x2, x8, #0x360
    19a0:      	mov	w8, #0x8                // =8
    19a4:      	blr	x9
    19a8:      	mov	w23, #0x50              // =80
    19ac:      	b	0x2d58 <generic_fentry_process_event+0x29c8>
    19b0:      	mov	x9, x24
    19b4:      	mov	w10, #0x5ea0            // =24224
    19b8:      	mov	x22, x25
    19bc:      	mov	x19, x29
    19c0:      	cmp	w9, #0x26
    19c4:      	b.ne	0x12d4 <generic_fentry_process_event+0xf44>
    19c8:      	add	x8, sp, #0xe0
    19cc:      	ldr	x9, [sp, #0x30]
    19d0:      	ldr	x8, [x8]
    19d4:      	add	x0, x9, #0x4
    19d8:      	add	x2, x19, w8, uxth
    19dc:      	ubfx	w8, w8, #16, #12
    19e0:      	add	w1, w8, #0x1
    19e4:      	mov	w8, #0x2d               // =45
    19e8:      	blr	x8
    19ec:      	b	0x1eec <generic_fentry_process_event+0x1b5c>
    19f0:      	cmp	w8, #0x8
    19f4:      	b.eq	0x1f58 <generic_fentry_process_event+0x1bc8>
    19f8:      	adrp	x22, 0x1000 <generic_fentry_process_event+0xc70>
    19fc:      	cmp	w8, #0x12
    1a00:      	ldr	x22, [x22]
    1a04:      	ldr	x19, [sp, #0x8]
    1a08:      	b.ne	0x12d0 <generic_fentry_process_event+0xf40>
    1a0c:      	ldp	x8, x2, [sp, #0x40]
    1a10:      	and	x23, x8, #0x3ff
    1a14:      	ldr	x0, [sp, #0x30]
    1a18:      	mov	w8, #0x4                // =4
    1a1c:      	mov	w1, w23
    1a20:      	blr	x8
    1a24:      	b	0x12d0 <generic_fentry_process_event+0xf40>
    1a28:      	cmp	w8, #0x13
    1a2c:      	b.eq	0x21ac <generic_fentry_process_event+0x1e1c>
    1a30:      	adrp	x22, 0x1000 <generic_fentry_process_event+0xc70>
    1a34:      	cmp	w8, #0x14
    1a38:      	ldr	x22, [x22]
    1a3c:      	ldr	x19, [sp, #0x8]
    1a40:      	b.ne	0x12d0 <generic_fentry_process_event+0xf40>
    1a44:      	ldr	x29, [sp, #0x48]
    1a48:      	str	xzr, [sp, #0x98]
    1a4c:      	mov	w24, #0x8               // =8
    1a50:      	add	x8, sp, #0x98
    1a54:      	mov	w9, #0x4                // =4
    1a58:      	add	x0, sp, #0x98
    1a5c:      	mov	w1, #0x8                // =8
    1a60:      	mov	w21, #0x4               // =4
    1a64:      	add	x2, x29, #0x110
    1a68:      	add	x23, x29, #0xd8
    1a6c:      	blr	x9
    1a70:      	ldr	x8, [sp, #0x98]
    1a74:      	mov	w9, #0x80               // =128
    1a78:      	mov	w10, #0x2d              // =45
    1a7c:      	ldr	x25, [sp, #0x30]
    1a80:      	mov	w1, #0x80               // =128
    1a84:      	mov	x0, x25
    1a88:      	ldr	x2, [sp, #0x98]
    1a8c:      	blr	x10
    1a90:      	add	x0, x25, #0x90
    1a94:      	mov	w8, #0x4                // =4
    1a98:      	mov	w1, #0x4                // =4
    1a9c:      	mov	x2, x23
    1aa0:      	blr	x8
    1aa4:      	add	x0, x25, #0x80
    1aa8:      	add	x2, x29, #0xe0
    1aac:      	mov	w8, #0x4                // =4
    1ab0:      	mov	w1, #0x8                // =8
    1ab4:      	blr	x8
    1ab8:      	add	x0, x25, #0x88
    1abc:      	add	x2, x29, #0x118
    1ac0:      	mov	w1, #0x8                // =8
    1ac4:      	blr	x21
    1ac8:      	mov	w23, #0x98              // =152
    1acc:      	b	0x12d0 <generic_fentry_process_event+0xf40>
    1ad0:      	add	x8, sp, #0xe0
    1ad4:      	mov	w9, #0x4                // =4
    1ad8:      	add	x10, sp, #0x88
    1adc:      	ldr	x23, [x8]
    1ae0:      	mov	w8, #0x1                // =1
    1ae4:      	mov	x29, x0
    1ae8:      	add	x0, sp, #0x88
    1aec:      	mov	w1, #0x1                // =1
    1af0:      	mov	x2, x23
    1af4:      	blr	x9
    1af8:      	ldrb	w8, [sp, #0x88]
    1afc:      	cmp	w8, #0x1
    1b00:      	b.ne	0x2360 <generic_fentry_process_event+0x1fd0>
    1b04:      	add	x2, x23, #0x10
    1b08:      	mov	w23, #0x8               // =8
    1b0c:      	add	x8, sp, #0xf0
    1b10:      	mov	w9, #0x4                // =4
    1b14:      	add	x0, sp, #0xf0
    1b18:      	mov	w1, #0x8                // =8
    1b1c:      	mov	w24, #0x4               // =4
    1b20:      	blr	x9
    1b24:      	add	x8, sp, #0xe0
    1b28:      	mov	w9, #0x4                // =4
    1b2c:      	add	x0, sp, #0x70
    1b30:      	ldr	x2, [x8, #0x10]
    1b34:      	add	x8, sp, #0x70
    1b38:      	mov	w1, #0x8                // =8
    1b3c:      	blr	x9
    1b40:      	add	x8, sp, #0xe0
    1b44:      	add	x0, sp, #0xe8
    1b48:      	mov	w1, #0x8                // =8
    1b4c:      	ldr	x8, [x8, #0x10]
    1b50:      	add	x2, x8, #0x8
    1b54:      	add	x8, sp, #0xe8
    1b58:      	blr	x24
    1b5c:      	add	x8, sp, #0xe0
    1b60:      	ldr	x9, [sp, #0x70]
    1b64:      	ldr	x8, [x8, #0x8]
    1b68:      	stp	x9, x8, [sp, #0x40]
    1b6c:      	add	x8, x29, #0x90
    1b70:      	add	x29, x8, x25
    1b74:      	tbz	w21, #0x5, 0x261c <generic_fentry_process_event+0x228c>
    1b78:      	ldr	x9, [sp, #0x48]
    1b7c:      	cmp	x9, #0x1, lsl #12       // =0x1000
    1b80:      	b.lo	0x2608 <generic_fentry_process_event+0x2278>
    1b84:      	mov	w8, #0x1                // =1
    1b88:      	adrp	x0, 0x1000 <generic_fentry_process_event+0xc70>
    1b8c:      	add	x9, sp, #0xd8
    1b90:      	str	w8, [x29]
    1b94:      	str	wzr, [sp, #0xd8]
    1b98:      	add	x1, sp, #0xd8
    1b9c:      	ldr	x0, [x0]
    1ba0:      	blr	x8
    1ba4:      	str	x0, [sp, #0x38]
    1ba8:      	cbz	x0, 0x28fc <generic_fentry_process_event+0x256c>
    1bac:      	ldr	x23, [sp, #0x38]
    1bb0:      	mov	w8, #0x18               // =24
    1bb4:      	str	w8, [x23]
    1bb8:      	mov	w8, #0xe                // =14
    1bbc:      	blr	x8
    1bc0:      	str	x0, [x23, #0x10]!
    1bc4:      	cmn	x0, #0x16
    1bc8:      	b.ne	0x1bf0 <generic_fentry_process_event+0x1860>
    1bcc:      	add	x2, x19, #0xe8
    1bd0:      	mov	w8, #0x8                // =8
    1bd4:      	mov	w9, #0x4                // =4
    1bd8:      	add	x10, sp, #0x98
    1bdc:      	add	x0, sp, #0x98
    1be0:      	mov	w1, #0x8                // =8
    1be4:      	blr	x9
    1be8:      	ldr	x8, [sp, #0x98]
    1bec:      	str	x8, [x23]
    1bf0:      	mov	w8, #0x7d               // =125
    1bf4:      	blr	x8
    1bf8:      	ldr	x11, [sp, #0x38]
    1bfc:      	mov	x21, xzr
    1c00:      	mov	x10, x29
    1c04:      	mov	w25, #0xa               // =10
    1c08:      	str	x0, [x11, #0x18]
    1c0c:      	ldp	x8, x9, [x23]
    1c10:      	add	x23, x11, #0x20
    1c14:      	stur	x9, [x29, #0x1c]
    1c18:      	stur	x8, [x29, #0x14]
    1c1c:      	ldr	x8, [sp, #0x48]
    1c20:      	subs	x8, x8, x21
    1c24:      	b.mi	0x2d68 <generic_fentry_process_event+0x29d8>
    1c28:      	ldr	x9, [sp, #0x40]
    1c2c:      	mov	x0, x23
    1c30:      	add	x2, x21, x9
    1c34:      	mov	w9, #0x7fe0             // =32736
    1c38:      	cmp	x8, x9
    1c3c:      	csel	x24, x8, x9, lo
    1c40:      	mov	w8, #0x4                // =4
    1c44:      	mov	w1, w24
    1c48:      	blr	x8
    1c4c:      	tbnz	w0, #0x1f, 0x1c88 <generic_fentry_process_event+0x18f8>
    1c50:      	ldr	x3, [sp, #0x38]
    1c54:      	add	w4, w24, #0x20
    1c58:      	adrp	x1, 0x1000 <generic_fentry_process_event+0xc70>
    1c5c:      	mov	w8, #0x19               // =25
    1c60:      	str	w4, [x3, #0x4]
    1c64:      	mov	w9, #-0x1               // =-1
    1c68:      	mov	x0, x19
    1c6c:      	mov	w2, #-0x1               // =-1
    1c70:      	ldr	x1, [x1]
    1c74:      	blr	x8
    1c78:      	sxtw	x8, w0
    1c7c:      	tst	w0, #0x80000000
    1c80:      	csel	x8, x24, x8, eq
    1c84:      	b	0x1c8c <generic_fentry_process_event+0x18fc>
    1c88:      	sxtw	x8, w0
    1c8c:      	tbnz	w8, #0x1f, 0x2d70 <generic_fentry_process_event+0x29e0>
    1c90:      	and	x8, x8, #0x7fffffff
    1c94:      	add	x21, x8, x21
    1c98:      	ldr	x8, [sp, #0x48]
    1c9c:      	cmp	x21, x8
    1ca0:      	b.eq	0x2dbc <generic_fentry_process_event+0x2a2c>
    1ca4:      	subs	w25, w25, #0x1
    1ca8:      	b.ne	0x1c1c <generic_fentry_process_event+0x188c>
    1cac:      	b	0x3120 <generic_fentry_process_event+0x2d90>
    1cb0:      	add	x8, sp, #0xe0
    1cb4:      	ldr	x23, [sp, #0x30]
    1cb8:      	mov	w1, #0x4                // =4
    1cbc:      	mov	w21, #0x4               // =4
    1cc0:      	ldr	x24, [x8]
    1cc4:      	mov	w8, #0x4                // =4
    1cc8:      	add	x0, x23, #0x28
    1ccc:      	add	x2, x24, #0x98
    1cd0:      	blr	x8
    1cd4:      	add	x0, x23, #0x2c
    1cd8:      	add	x2, x24, #0x70
    1cdc:      	mov	w8, #0x4                // =4
    1ce0:      	mov	w1, #0x4                // =4
    1ce4:      	blr	x8
    1ce8:      	add	x0, x23, #0x30
    1cec:      	add	x2, x24, #0x90
    1cf0:      	mov	w8, #0x4                // =4
    1cf4:      	mov	w1, #0x4                // =4
    1cf8:      	blr	x8
    1cfc:      	add	x0, x23, #0x34
    1d00:      	add	x2, x24, #0xa8
    1d04:      	mov	w8, #0x4                // =4
    1d08:      	mov	w1, #0x4                // =4
    1d0c:      	blr	x8
    1d10:      	str	xzr, [sp, #0x98]
    1d14:      	add	x2, x24, #0xc8
    1d18:      	mov	w8, #0x8                // =8
    1d1c:      	add	x9, sp, #0x98
    1d20:      	mov	w10, #0x4               // =4
    1d24:      	add	x0, sp, #0x98
    1d28:      	mov	w1, #0x8                // =8
    1d2c:      	blr	x10
    1d30:      	str	x24, [sp, #0x48]
    1d34:      	add	x2, x24, #0xb8
    1d38:      	mov	w8, #0x2                // =2
    1d3c:      	add	x9, sp, #0xe8
    1d40:      	mov	w10, #0x4               // =4
    1d44:      	add	x0, sp, #0xe8
    1d48:      	mov	w1, #0x2                // =2
    1d4c:      	blr	x10
    1d50:      	ldr	x8, [sp, #0x98]
    1d54:      	ldrh	w9, [sp, #0xe8]
    1d58:      	add	x0, sp, #0x84
    1d5c:      	mov	w1, #0x1                // =1
    1d60:      	add	x23, x8, x9
    1d64:      	mov	w8, #0x1                // =1
    1d68:      	add	x9, sp, #0x84
    1d6c:      	mov	x2, x23
    1d70:      	blr	x21
    1d74:      	ldrb	w8, [sp, #0x84]
    1d78:      	lsr	w8, w8, #4
    1d7c:      	cmp	w8, #0x6
    1d80:      	b.eq	0x2384 <generic_fentry_process_event+0x1ff4>
    1d84:      	cmp	w8, #0x4
    1d88:      	b.ne	0x3624 <generic_fentry_process_event+0x3294>
    1d8c:      	add	x2, x23, #0x9
    1d90:      	mov	w8, #0x1                // =1
    1d94:      	add	x9, sp, #0x88
    1d98:      	mov	w10, #0x4               // =4
    1d9c:      	add	x0, sp, #0x88
    1da0:      	mov	w1, #0x1                // =1
    1da4:      	mov	w21, #0x4               // =4
    1da8:      	blr	x10
    1dac:      	ldr	x0, [sp, #0x30]
    1db0:      	ldrb	w8, [sp, #0x88]
    1db4:      	mov	w25, #0x2               // =2
    1db8:      	add	x2, x23, #0xc
    1dbc:      	mov	w1, #0x4                // =4
    1dc0:      	mov	x24, x0
    1dc4:      	strh	w8, [x0, #0x24]
    1dc8:      	strh	w25, [x0, #0x26]
    1dcc:      	stp	xzr, xzr, [x0]
    1dd0:      	str	xzr, [x0, #0x18]
    1dd4:      	mov	w8, #0x4                // =4
    1dd8:      	str	xzr, [x24, #0x10]!
    1ddc:      	blr	x8
    1de0:      	add	x2, x23, #0x10
    1de4:      	mov	w8, #0x4                // =4
    1de8:      	mov	x0, x24
    1dec:      	mov	w1, #0x4                // =4
    1df0:      	blr	x8
    1df4:      	ldr	x8, [sp, #0x48]
    1df8:      	add	x0, sp, #0xd8
    1dfc:      	mov	w1, #0x2                // =2
    1e00:      	add	x2, x8, #0xb6
    1e04:      	add	x8, sp, #0xd8
    1e08:      	blr	x21
    1e0c:      	ldrb	w25, [sp, #0x88]
    1e10:      	b	0x34e4 <generic_fentry_process_event+0x3154>
    1e14:      	str	xzr, [sp, #0xa0]
    1e18:      	mov	w8, #0xe                // =14
    1e1c:      	blr	x8
    1e20:      	lsr	x8, x0, #32
    1e24:      	add	x9, sp, #0xf0
    1e28:      	add	x10, sp, #0xe0
    1e2c:      	str	x8, [sp, #0x98]
    1e30:      	mov	w8, #0x4                // =4
    1e34:      	add	x0, sp, #0xf0
    1e38:      	add	x2, sp, #0xe0
    1e3c:      	mov	w1, #0x4                // =4
    1e40:      	blr	x8
    1e44:      	ldr	w8, [sp, #0xf0]
    1e48:      	adrp	x0, 0x1000 <generic_fentry_process_event+0xc70>
    1e4c:      	add	x9, sp, #0x98
    1e50:      	add	x1, sp, #0x98
    1e54:      	str	w8, [sp, #0xa0]
    1e58:      	mov	w8, #0x1                // =1
    1e5c:      	ldr	x0, [x0]
    1e60:      	blr	x8
    1e64:      	cbz	x0, 0x237c <generic_fentry_process_event+0x1fec>
    1e68:      	ldr	x25, [sp, #0x30]
    1e6c:      	ldr	w21, [x0]
    1e70:      	add	x8, sp, #0xf0
    1e74:      	mov	w9, #0x4                // =4
    1e78:      	mov	x23, x0
    1e7c:      	add	x2, sp, #0xf0
    1e80:      	mov	w1, #0x4                // =4
    1e84:      	mov	w24, #0x4               // =4
    1e88:      	mov	x0, x25
    1e8c:      	blr	x9
    1e90:      	and	x21, x21, #0xfff
    1e94:      	add	x0, x25, #0x4
    1e98:      	mov	w8, #0x4                // =4
    1e9c:      	mov	x2, x23
    1ea0:      	add	x1, x21, #0x4
    1ea4:      	blr	x8
    1ea8:      	add	w21, w21, #0x8
    1eac:      	mov	w1, #0x4                // =4
    1eb0:      	add	x8, x21, x23
    1eb4:      	add	x0, x25, x21
    1eb8:      	sub	x2, x8, #0x4
    1ebc:      	blr	x24
    1ec0:      	add	x23, x21, #0x4
    1ec4:      	b	0x12d0 <generic_fentry_process_event+0xf40>
    1ec8:      	add	x8, sp, #0xe0
    1ecc:      	mov	w9, #0x2d               // =45
    1ed0:      	mov	w1, #0x11               // =17
    1ed4:      	ldr	x8, [x8]
    1ed8:      	add	x2, x8, #0x118
    1edc:      	ldr	x8, [sp, #0x30]
    1ee0:      	add	x0, x8, #0x4
    1ee4:      	mov	w8, #0x11               // =17
    1ee8:      	blr	x9
    1eec:      	mov	x23, x0
    1ef0:      	tbnz	x0, #0x3f, 0x25f8 <generic_fentry_process_event+0x2268>
    1ef4:      	ldr	x9, [sp, #0x30]
    1ef8:      	sub	w8, w23, #0x1
    1efc:      	add	x23, x23, #0x3
    1f00:      	str	w8, [x9]
    1f04:      	b	0x25f8 <generic_fentry_process_event+0x2268>
    1f08:      	add	x23, x29, #0x90
    1f0c:      	add	x8, x23, x25
    1f10:      	str	x8, [sp, #0x38]
    1f14:      	add	x8, sp, #0xe0
    1f18:      	str	xzr, [x8]
    1f1c:      	tbnz	w21, #0x4, 0x24cc <generic_fentry_process_event+0x213c>
    1f20:      	ldr	x9, [sp, #0x40]
    1f24:      	mov	x8, xzr
    1f28:      	and	x25, x21, #0xffffffff
    1f2c:      	and	w9, w9, #0xf
    1f30:      	cmp	w9, #0x2
    1f34:      	b.le	0x2660 <generic_fentry_process_event+0x22d0>
    1f38:      	cmp	w9, #0x3
    1f3c:      	b.eq	0x2904 <generic_fentry_process_event+0x2574>
    1f40:      	cmp	w9, #0x4
    1f44:      	b.eq	0x290c <generic_fentry_process_event+0x257c>
    1f48:      	cmp	w9, #0x5
    1f4c:      	b.ne	0x2920 <generic_fentry_process_event+0x2590>
    1f50:      	mov	w8, #0x5e70             // =24176
    1f54:      	b	0x2918 <generic_fentry_process_event+0x2588>
    1f58:      	ldr	x29, [sp, #0x48]
    1f5c:      	ldr	x25, [sp, #0x30]
    1f60:      	mov	w8, #0x4                // =4
    1f64:      	mov	w1, #0x4                // =4
    1f68:      	mov	w21, #0x4               // =4
    1f6c:      	add	x2, x29, #0x8
    1f70:      	mov	x0, x25
    1f74:      	add	x23, x25, #0x28
    1f78:      	add	x19, x25, #0x40
    1f7c:      	blr	x8
    1f80:      	add	x0, x25, #0x4
    1f84:      	add	x2, x29, #0xc
    1f88:      	mov	w8, #0x4                // =4
    1f8c:      	mov	w1, #0x4                // =4
    1f90:      	blr	x8
    1f94:      	add	x0, x25, #0x10
    1f98:      	add	x2, x29, #0x18
    1f9c:      	mov	w8, #0x4                // =4
    1fa0:      	mov	w1, #0x4                // =4
    1fa4:      	blr	x8
    1fa8:      	add	x0, x25, #0x14
    1fac:      	add	x2, x29, #0x1c
    1fb0:      	mov	w8, #0x4                // =4
    1fb4:      	mov	w1, #0x4                // =4
    1fb8:      	blr	x8
    1fbc:      	add	x0, x25, #0x8
    1fc0:      	add	x2, x29, #0x10
    1fc4:      	mov	w8, #0x4                // =4
    1fc8:      	mov	w1, #0x4                // =4
    1fcc:      	blr	x8
    1fd0:      	add	x0, x25, #0xc
    1fd4:      	add	x2, x29, #0x14
    1fd8:      	mov	w8, #0x4                // =4
    1fdc:      	mov	w1, #0x4                // =4
    1fe0:      	blr	x8
    1fe4:      	add	x0, x25, #0x18
    1fe8:      	add	x2, x29, #0x20
    1fec:      	mov	w8, #0x4                // =4
    1ff0:      	mov	w1, #0x4                // =4
    1ff4:      	blr	x8
    1ff8:      	add	x0, x25, #0x1c
    1ffc:      	add	x2, x29, #0x24
    2000:      	mov	w8, #0x4                // =4
    2004:      	mov	w1, #0x4                // =4
    2008:      	blr	x8
    200c:      	str	wzr, [x25, #0x24]
    2010:      	add	x0, x25, #0x20
    2014:      	add	x2, x29, #0x28
    2018:      	mov	w8, #0x4                // =4
    201c:      	mov	w1, #0x4                // =4
    2020:      	blr	x8
    2024:      	add	x0, x25, #0x30
    2028:      	add	x2, x29, #0x40
    202c:      	mov	w24, #0x8               // =8
    2030:      	mov	w8, #0x4                // =4
    2034:      	mov	w1, #0x8                // =8
    2038:      	blr	x8
    203c:      	add	x0, x25, #0x38
    2040:      	add	x2, x29, #0x30
    2044:      	mov	w8, #0x4                // =4
    2048:      	mov	w1, #0x8                // =8
    204c:      	blr	x8
    2050:      	add	x2, x29, #0x38
    2054:      	mov	w8, #0x4                // =4
    2058:      	mov	x0, x23
    205c:      	mov	w1, #0x8                // =8
    2060:      	blr	x8
    2064:      	add	x2, x29, #0x90
    2068:      	add	x8, sp, #0x98
    206c:      	mov	w9, #0x4                // =4
    2070:      	add	x0, sp, #0x98
    2074:      	mov	w1, #0x8                // =8
    2078:      	blr	x9
    207c:      	ldr	x23, [sp, #0x98]
    2080:      	mov	w8, #0x4                // =4
    2084:      	mov	x0, x19
    2088:      	mov	w1, #0x4                // =4
    208c:      	add	x2, x23, #0xc8
    2090:      	blr	x8
    2094:      	add	x0, x25, #0x44
    2098:      	add	x2, x23, #0xcc
    209c:      	mov	w8, #0x4                // =4
    20a0:      	mov	w1, #0x4                // =4
    20a4:      	blr	x8
    20a8:      	add	x0, x25, #0x48
    20ac:      	add	x2, x23, #0xd0
    20b0:      	mov	w8, #0x4                // =4
    20b4:      	mov	w1, #0x4                // =4
    20b8:      	blr	x8
    20bc:      	add	x0, x25, #0x4c
    20c0:      	add	x2, x23, #0x158
    20c4:      	mov	w1, #0x4                // =4
    20c8:      	blr	x21
    20cc:      	mov	w23, #0x50              // =80
    20d0:      	b	0x2d58 <generic_fentry_process_event+0x29c8>
    20d4:      	ldr	x24, [sp, #0x48]
    20d8:      	ldr	x23, [sp, #0x30]
    20dc:      	mov	w8, #0x4                // =4
    20e0:      	mov	w1, #0x4                // =4
    20e4:      	mov	w21, #0x4               // =4
    20e8:      	add	x2, x24, #0xc8
    20ec:      	mov	x0, x23
    20f0:      	blr	x8
    20f4:      	add	x0, x23, #0x4
    20f8:      	add	x2, x24, #0xcc
    20fc:      	mov	w8, #0x4                // =4
    2100:      	mov	w1, #0x4                // =4
    2104:      	blr	x8
    2108:      	add	x0, x23, #0x8
    210c:      	add	x2, x24, #0xd0
    2110:      	mov	w8, #0x4                // =4
    2114:      	mov	w1, #0x4                // =4
    2118:      	blr	x8
    211c:      	add	x0, x23, #0xc
    2120:      	add	x2, x24, #0x158
    2124:      	mov	w1, #0x4                // =4
    2128:      	blr	x21
    212c:      	mov	w23, #0x10              // =16
    2130:      	b	0x2d58 <generic_fentry_process_event+0x29c8>
    2134:      	ldr	x24, [sp, #0x48]
    2138:      	ldr	x23, [sp, #0x30]
    213c:      	mov	w8, #0x4                // =4
    2140:      	mov	w1, #0x4                // =4
    2144:      	mov	w21, #0x4               // =4
    2148:      	add	x2, x24, #0x38
    214c:      	mov	x0, x23
    2150:      	blr	x8
    2154:      	add	x0, x23, #0x4
    2158:      	add	x2, x24, #0x3c
    215c:      	mov	w8, #0x4                // =4
    2160:      	mov	w1, #0x4                // =4
    2164:      	blr	x8
    2168:      	add	x0, x23, #0x8
    216c:      	add	x2, x24, #0x40
    2170:      	mov	w8, #0x4                // =4
    2174:      	mov	w1, #0x4                // =4
    2178:      	blr	x8
    217c:      	add	x0, x23, #0xc
    2180:      	add	x2, x24, #0x44
    2184:      	mov	w8, #0x4                // =4
    2188:      	mov	w1, #0x4                // =4
    218c:      	blr	x8
    2190:      	add	x0, x23, #0x10
    2194:      	add	x2, x24, #0x80
    2198:      	mov	w8, #0x10               // =16
    219c:      	mov	w1, #0x10               // =16
    21a0:      	blr	x21
    21a4:      	mov	w23, #0x20              // =32
    21a8:      	b	0x2d58 <generic_fentry_process_event+0x29c8>
    21ac:      	ldr	x23, [sp, #0x30]
    21b0:      	ldr	x24, [sp, #0x48]
    21b4:      	mov	w8, #0x4                // =4
    21b8:      	mov	w1, #0x4                // =4
    21bc:      	mov	w21, #0x4               // =4
    21c0:      	mov	x0, x23
    21c4:      	mov	x2, x24
    21c8:      	blr	x8
    21cc:      	add	x0, x23, #0x4
    21d0:      	add	x2, x24, #0x4
    21d4:      	mov	w8, #0x4                // =4
    21d8:      	mov	w1, #0x4                // =4
    21dc:      	blr	x8
    21e0:      	add	x0, x23, #0x8
    21e4:      	add	x2, x24, #0x30
    21e8:      	mov	w8, #0x10               // =16
    21ec:      	b	0x2270 <generic_fentry_process_event+0x1ee0>
    21f0:      	ldr	x24, [sp, #0x48]
    21f4:      	add	x8, sp, #0x98
    21f8:      	mov	w9, #0x4                // =4
    21fc:      	add	x0, sp, #0x98
    2200:      	mov	w1, #0x4                // =4
    2204:      	mov	w21, #0x4               // =4
    2208:      	add	x2, x24, #0x4
    220c:      	blr	x9
    2210:      	ldr	w8, [sp, #0x98]
    2214:      	ldr	x23, [sp, #0x30]
    2218:      	add	x2, x24, #0xc
    221c:      	add	x0, sp, #0x98
    2220:      	mov	w1, #0x4                // =4
    2224:      	str	w8, [x23]
    2228:      	add	x8, sp, #0x98
    222c:      	blr	x21
    2230:      	ldr	w8, [sp, #0x98]
    2234:      	add	x2, x24, #0x50
    2238:      	add	x9, sp, #0x98
    223c:      	mov	w10, #0x2d              // =45
    2240:      	str	w8, [x23, #0x4]
    2244:      	mov	w8, #0x8                // =8
    2248:      	add	x0, sp, #0x98
    224c:      	mov	w1, #0x8                // =8
    2250:      	mov	w21, #0x2d              // =45
    2254:      	blr	x10
    2258:      	ldr	x8, [sp, #0x98]
    225c:      	add	x0, x23, #0x8
    2260:      	mov	w9, #0x10               // =16
    2264:      	add	x8, x8, #0x3f8
    2268:      	ldr	x8, [sp, #0x98]
    226c:      	add	x2, x8, #0x3f8
    2270:      	mov	w1, #0x10               // =16
    2274:      	blr	x21
    2278:      	mov	w23, #0x18              // =24
    227c:      	b	0x2d58 <generic_fentry_process_event+0x29c8>
    2280:      	ldr	x11, [sp, #0x30]
    2284:      	ldr	x2, [sp, #0x48]
    2288:      	mov	w8, #0x8                // =8
    228c:      	mov	w9, #0x4                // =4
    2290:      	add	x10, sp, #0x98
    2294:      	add	x0, sp, #0x98
    2298:      	mov	w1, #0x8                // =8
    229c:      	stp	xzr, xzr, [x11, #0x40]
    22a0:      	stp	xzr, xzr, [x11, #0x30]
    22a4:      	stp	xzr, xzr, [x11, #0x20]
    22a8:      	stp	xzr, xzr, [x11, #0x10]
    22ac:      	stp	xzr, xzr, [x11]
    22b0:      	blr	x9
    22b4:      	mov	x23, xzr
    22b8:      	cbnz	x0, 0x2d58 <generic_fentry_process_event+0x29c8>
    22bc:      	ldr	x8, [sp, #0x30]
    22c0:      	mov	w9, #0x3f               // =63
    22c4:      	mov	w10, #0x2d              // =45
    22c8:      	mov	w1, #0x3f               // =63
    22cc:      	add	x0, x8, #0x10
    22d0:      	ldr	x8, [sp, #0x98]
    22d4:      	ldr	x2, [sp, #0x98]
    22d8:      	blr	x10
    22dc:      	tbnz	x0, #0x3f, 0x24c4 <generic_fentry_process_event+0x2134>
    22e0:      	ldr	x24, [sp, #0x48]
    22e4:      	mov	w21, #0x8               // =8
    22e8:      	add	x8, sp, #0xf0
    22ec:      	mov	w9, #0x4                // =4
    22f0:      	add	x0, sp, #0xf0
    22f4:      	mov	w1, #0x8                // =8
    22f8:      	mov	w23, #0x4               // =4
    22fc:      	add	x2, x24, #0x8
    2300:      	blr	x9
    2304:      	ldr	x8, [sp, #0x30]
    2308:      	add	x10, sp, #0xe0
    230c:      	mov	w9, #0x4                // =4
    2310:      	mov	w1, #0x8                // =8
    2314:      	add	x0, x8, #0x8
    2318:      	ldr	x8, [x10, #0x10]
    231c:      	add	x8, x8, #0x360
    2320:      	ldr	x8, [x10, #0x10]
    2324:      	add	x2, x8, #0x360
    2328:      	blr	x9
    232c:      	add	x2, x24, #0x58
    2330:      	add	x8, sp, #0xf0
    2334:      	add	x0, sp, #0xf0
    2338:      	mov	w1, #0x4                // =4
    233c:      	blr	x23
    2340:      	cbnz	x0, 0x2358 <generic_fentry_process_event+0x1fc8>
    2344:      	ldr	w8, [sp, #0xf0]
    2348:      	ldr	x9, [sp, #0x30]
    234c:      	cmp	w8, #0x0
    2350:      	cset	w8, ne
    2354:      	str	w8, [x9]
    2358:      	mov	w23, #0x50              // =80
    235c:      	b	0x2d58 <generic_fentry_process_event+0x29c8>
    2360:      	add	x8, x29, x25
    2364:      	mov	w23, #0x8               // =8
    2368:      	str	xzr, [x8, #0x90]
    236c:      	b	0x12d0 <generic_fentry_process_event+0xf40>
    2370:      	ldr	x10, [sp, #0x40]
    2374:      	mov	w9, #0x9                // =9
    2378:      	b	0x830 <generic_fentry_process_event+0x4a0>
    237c:      	mov	x23, #-0x1              // =-1
    2380:      	b	0x12d0 <generic_fentry_process_event+0xf40>
    2384:      	str	wzr, [sp, #0xf0]
    2388:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    238c:      	ldr	x29, [sp, #0x98]
    2390:      	mov	w8, #0x1                // =1
    2394:      	add	x9, sp, #0xf0
    2398:      	add	x1, sp, #0xf0
    239c:      	ldrh	w23, [sp, #0xe8]
    23a0:      	ldr	x0, [x0]
    23a4:      	add	x21, x29, x23
    23a8:      	blr	x8
    23ac:      	cbz	x0, 0x34a0 <generic_fentry_process_event+0x3110>
    23b0:      	mov	w8, #0xff               // =255
    23b4:      	strh	w23, [x0]
    23b8:      	strb	wzr, [x0, #0x7]
    23bc:      	add	x23, x0, #0x6
    23c0:      	add	x2, x21, #0x6
    23c4:      	mov	w9, #0x4                // =4
    23c8:      	strb	w8, [x0, #0x5]
    23cc:      	mov	w8, #0x1                // =1
    23d0:      	mov	x24, x0
    23d4:      	mov	x0, x23
    23d8:      	mov	w1, #0x1                // =1
    23dc:      	blr	x9
    23e0:      	tbnz	x0, #0x3f, 0x34a0 <generic_fentry_process_event+0x3110>
    23e4:      	ldrb	w8, [x24, #0x5]
    23e8:      	cmp	w8, #0x32
    23ec:      	b.gt	0x2878 <generic_fentry_process_event+0x24e8>
    23f0:      	cbz	w8, 0x28f0 <generic_fentry_process_event+0x2560>
    23f4:      	cmp	w8, #0x2b
    23f8:      	b.eq	0x28f0 <generic_fentry_process_event+0x2560>
    23fc:      	cmp	w8, #0x2c
    2400:      	b.ne	0x2e84 <generic_fentry_process_event+0x2af4>
    2404:      	mov	w8, #0x8                // =8
    2408:      	b	0x2dd0 <generic_fentry_process_event+0x2a40>
    240c:      	ldr	x0, [sp, #0x30]
    2410:      	add	x2, x23, #0x48
    2414:      	mov	w25, #0x10              // =16
    2418:      	mov	w8, #0x4                // =4
    241c:      	mov	w1, #0x10               // =16
    2420:      	mov	w29, #0x4               // =4
    2424:      	blr	x8
    2428:      	add	x2, x23, #0x38
    242c:      	mov	x0, x24
    2430:      	mov	w1, #0x10               // =16
    2434:      	blr	x29
    2438:      	ldr	x29, [sp, #0x30]
    243c:      	add	x24, x23, #0xc
    2440:      	add	x2, x23, #0xe
    2444:      	mov	w23, #0x2               // =2
    2448:      	mov	w8, #0x4                // =4
    244c:      	mov	w1, #0x2                // =2
    2450:      	mov	w25, #0x4               // =4
    2454:      	add	x0, x29, #0x20
    2458:      	blr	x8
    245c:      	add	x0, x29, #0x22
    2460:      	mov	w1, #0x2                // =2
    2464:      	mov	x2, x24
    2468:      	blr	x25
    246c:      	ldrh	w8, [x29, #0x22]
    2470:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    2474:      	add	x9, sp, #0x98
    2478:      	add	x1, sp, #0x98
    247c:      	rev	w8, w8
    2480:      	lsr	w8, w8, #16
    2484:      	strh	w8, [x29, #0x22]
    2488:      	add	x8, sp, #0xe0
    248c:      	ldr	x8, [x8]
    2490:      	str	x8, [sp, #0x98]
    2494:      	mov	w8, #0x1                // =1
    2498:      	ldr	x0, [x0]
    249c:      	blr	x8
    24a0:      	cbz	x0, 0x3624 <generic_fentry_process_event+0x3294>
    24a4:      	ldr	w8, [x0]
    24a8:      	mov	w23, #0x40              // =64
    24ac:      	str	w8, [x21, #0x10]
    24b0:      	ldr	x8, [x0, #0x8]
    24b4:      	str	x8, [x21, #0x18]
    24b8:      	ldr	w8, [x0, #0x4]
    24bc:      	str	w8, [x21, #0x7c]
    24c0:      	b	0x3628 <generic_fentry_process_event+0x3298>
    24c4:      	mov	x23, xzr
    24c8:      	b	0x2d58 <generic_fentry_process_event+0x29c8>
    24cc:      	mov	w8, #0xe                // =14
    24d0:      	blr	x8
    24d4:      	cmn	x0, #0x16
    24d8:      	b.ne	0x2500 <generic_fentry_process_event+0x2170>
    24dc:      	ldr	x8, [sp, #0x8]
    24e0:      	mov	w9, #0x4                // =4
    24e4:      	add	x10, sp, #0x98
    24e8:      	add	x0, sp, #0x98
    24ec:      	mov	w1, #0x8                // =8
    24f0:      	add	x2, x8, #0xe8
    24f4:      	mov	w8, #0x8                // =8
    24f8:      	blr	x9
    24fc:      	ldr	x0, [sp, #0x98]
    2500:      	ldr	x10, [x29, #0x8]
    2504:      	ldr	x9, [sp, #0x48]
    2508:      	mov	x3, xzr
    250c:      	add	x1, sp, #0xf0
    2510:      	add	x2, sp, #0x98
    2514:      	ldr	x8, [x29, #0x60]
    2518:      	str	xzr, [sp, #0xa8]
    251c:      	stp	x10, x9, [sp, #0x98]
    2520:      	add	x9, sp, #0xe0
    2524:      	add	x10, sp, #0x98
    2528:      	stp	x8, x0, [x9, #0x10]
    252c:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    2530:      	mov	w8, #0x2                // =2
    2534:      	add	x9, sp, #0xf0
    2538:      	ldr	x0, [x0]
    253c:      	blr	x8
    2540:      	cbz	x0, 0x28bc <generic_fentry_process_event+0x252c>
    2544:      	neg	w8, w0
    2548:      	adrp	x23, 0x2000 <generic_fentry_process_event+0x1c70>
    254c:      	mov	w9, #0x1                // =1
    2550:      	strh	w8, [sp, #0x70]
    2554:      	mov	w8, #0x5                // =5
    2558:      	add	x1, sp, #0x70
    255c:      	mov	w21, #0x1               // =1
    2560:      	strh	w8, [sp, #0x72]
    2564:      	mov	x8, #0x46               // =70
    2568:      	movk	x8, #0x2, lsl #32
    256c:      	stur	x8, [sp, #0x74]
    2570:      	add	x8, sp, #0x70
    2574:      	ldr	x23, [x23]
    2578:      	mov	x0, x23
    257c:      	blr	x9
    2580:      	cbz	x0, 0x2898 <generic_fentry_process_event+0x2508>
    2584:      	ldr	w8, [x0]
    2588:      	add	w8, w8, #0x1
    258c:      	str	w8, [x0]
    2590:      	b	0x28bc <generic_fentry_process_event+0x252c>
    2594:      	cmp	w8, #0x1
    2598:      	b.eq	0x2740 <generic_fentry_process_event+0x23b0>
    259c:      	cmp	w8, #0x2
    25a0:      	b.ne	0x278c <generic_fentry_process_event+0x23fc>
    25a4:      	mov	w8, #0x5e58             // =24152
    25a8:      	b	0x2744 <generic_fentry_process_event+0x23b4>
    25ac:      	ldr	x24, [sp, #0x30]
    25b0:      	add	x2, x23, #0x8
    25b4:      	mov	w8, #0x10               // =16
    25b8:      	mov	w9, #0x4                // =4
    25bc:      	mov	w1, #0x10               // =16
    25c0:      	mov	w21, #0x4               // =4
    25c4:      	add	x0, x24, #0x8
    25c8:      	blr	x9
    25cc:      	add	x0, x24, #0x2
    25d0:      	add	x2, x23, #0x2
    25d4:      	mov	w8, #0x2                // =2
    25d8:      	mov	w1, #0x2                // =2
    25dc:      	blr	x21
    25e0:      	ldr	x9, [sp, #0x30]
    25e4:      	ldrh	w8, [x9, #0x2]
    25e8:      	rev	w8, w8
    25ec:      	lsr	w8, w8, #16
    25f0:      	strh	w8, [x9, #0x2]
    25f4:      	mov	w23, #0x18              // =24
    25f8:      	mov	w10, #0x5ea0            // =24224
    25fc:      	mov	x22, x25
    2600:      	mov	x19, x29
    2604:      	b	0x12d4 <generic_fentry_process_event+0xf44>
    2608:      	ldr	x9, [sp, #0x108]
    260c:      	str	wzr, [x29]
    2610:      	mov	w23, #0xc               // =12
    2614:      	add	x8, x8, x9
    2618:      	add	x29, x8, #0x8
    261c:      	ldp	x2, x9, [sp, #0x40]
    2620:      	mov	w8, #0xfff              // =4095
    2624:      	add	x0, x29, #0x8
    2628:      	cmp	x9, #0xfff
    262c:      	csel	x24, x9, x8, lo
    2630:      	mov	w8, #0x4                // =4
    2634:      	mov	w1, w24
    2638:      	blr	x8
    263c:      	tbnz	w0, #0x1f, 0x2650 <generic_fentry_process_event+0x22c0>
    2640:      	ldr	x8, [sp, #0x48]
    2644:      	add	x23, x23, x24
    2648:      	stp	w8, w24, [x29]
    264c:      	b	0x12d0 <generic_fentry_process_event+0xf40>
    2650:      	mov	w8, #-0x2               // =-2
    2654:      	mov	w23, #0x4               // =4
    2658:      	str	w8, [x29]
    265c:      	b	0x12d0 <generic_fentry_process_event+0xf40>
    2660:      	cmp	w9, #0x1
    2664:      	b.eq	0x2914 <generic_fentry_process_event+0x2584>
    2668:      	cmp	w9, #0x2
    266c:      	b.ne	0x2920 <generic_fentry_process_event+0x2590>
    2670:      	mov	w8, #0x5e58             // =24152
    2674:      	b	0x2918 <generic_fentry_process_event+0x2588>
    2678:      	ldr	x0, [sp, #0x30]
    267c:      	add	x2, x23, #0x48
    2680:      	mov	w25, #0x10              // =16
    2684:      	mov	w8, #0x4                // =4
    2688:      	mov	w1, #0x10               // =16
    268c:      	mov	w29, #0x4               // =4
    2690:      	blr	x8
    2694:      	add	x2, x23, #0x38
    2698:      	mov	x0, x24
    269c:      	mov	w1, #0x10               // =16
    26a0:      	blr	x29
    26a4:      	ldr	x29, [sp, #0x30]
    26a8:      	add	x24, x23, #0xc
    26ac:      	add	x2, x23, #0xe
    26b0:      	mov	w23, #0x2               // =2
    26b4:      	mov	w8, #0x4                // =4
    26b8:      	mov	w1, #0x2                // =2
    26bc:      	mov	w25, #0x4               // =4
    26c0:      	add	x0, x29, #0x20
    26c4:      	blr	x8
    26c8:      	add	x0, x29, #0x22
    26cc:      	mov	w1, #0x2                // =2
    26d0:      	mov	x2, x24
    26d4:      	blr	x25
    26d8:      	ldrh	w8, [x29, #0x22]
    26dc:      	rev	w8, w8
    26e0:      	lsr	w8, w8, #16
    26e4:      	strh	w8, [x29, #0x22]
    26e8:      	ldr	x8, [sp, #0x30]
    26ec:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    26f0:      	add	x9, sp, #0x98
    26f4:      	add	x1, sp, #0x98
    26f8:      	ldr	x8, [x8, #0x28]
    26fc:      	str	x8, [sp, #0x98]
    2700:      	mov	w8, #0x1                // =1
    2704:      	ldr	x0, [x0]
    2708:      	blr	x8
    270c:      	cbz	x0, 0x2728 <generic_fentry_process_event+0x2398>
    2710:      	ldr	w8, [x0]
    2714:      	str	w8, [x21, #0x10]
    2718:      	ldr	x8, [x0, #0x8]
    271c:      	str	x8, [x21, #0x18]
    2720:      	ldr	w8, [x0, #0x4]
    2724:      	str	w8, [x21, #0x7c]
    2728:      	mov	w23, #0x40              // =64
    272c:      	b	0x2d58 <generic_fentry_process_event+0x29c8>
    2730:      	mov	w8, #0x5e60             // =24160
    2734:      	b	0x2744 <generic_fentry_process_event+0x23b4>
    2738:      	mov	w8, #0x5e68             // =24168
    273c:      	b	0x2744 <generic_fentry_process_event+0x23b4>
    2740:      	mov	w8, #0x5e50             // =24144
    2744:      	add	x8, x29, x8
    2748:      	ldr	x21, [x8]
    274c:      	ldr	x8, [sp, #0x40]
    2750:      	tbnz	w8, #0x4, 0x279c <generic_fentry_process_event+0x240c>
    2754:      	cbz	x21, 0x2868 <generic_fentry_process_event+0x24d8>
    2758:      	ldr	x2, [sp, #0x48]
    275c:      	mov	w8, #0x10               // =16
    2760:      	mov	w9, #0x4                // =4
    2764:      	add	x10, sp, #0x98
    2768:      	add	x0, sp, #0x98
    276c:      	mov	w1, #0x10               // =16
    2770:      	blr	x9
    2774:      	tbnz	w0, #0x1f, 0x2d4c <generic_fentry_process_event+0x29bc>
    2778:      	ldr	x23, [sp, #0xa0]
    277c:      	cmp	x23, #0xffe
    2780:      	b.ls	0x2ae8 <generic_fentry_process_event+0x2758>
    2784:      	mov	w8, #-0x3               // =-3
    2788:      	b	0x2d50 <generic_fentry_process_event+0x29c0>
    278c:      	ldr	x8, [sp, #0x40]
    2790:      	mov	x21, xzr
    2794:      	mov	x23, xzr
    2798:      	tbz	w8, #0x4, 0x286c <generic_fentry_process_event+0x24dc>
    279c:      	mov	w8, #0xe                // =14
    27a0:      	blr	x8
    27a4:      	cmn	x0, #0x16
    27a8:      	b.ne	0x27d0 <generic_fentry_process_event+0x2440>
    27ac:      	ldr	x8, [sp, #0x8]
    27b0:      	mov	w9, #0x4                // =4
    27b4:      	add	x10, sp, #0x98
    27b8:      	add	x0, sp, #0x98
    27bc:      	mov	w1, #0x8                // =8
    27c0:      	add	x2, x8, #0xe8
    27c4:      	mov	w8, #0x8                // =8
    27c8:      	blr	x9
    27cc:      	ldr	x0, [sp, #0x98]
    27d0:      	ldr	x10, [x29, #0x8]
    27d4:      	ldr	x9, [sp, #0x48]
    27d8:      	mov	x3, xzr
    27dc:      	add	x1, sp, #0xf0
    27e0:      	add	x2, sp, #0x98
    27e4:      	ldr	x8, [x29, #0x60]
    27e8:      	str	x21, [sp, #0xa8]
    27ec:      	stp	x10, x9, [sp, #0x98]
    27f0:      	add	x9, sp, #0xe0
    27f4:      	add	x10, sp, #0x98
    27f8:      	stp	x8, x0, [x9, #0x10]
    27fc:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    2800:      	mov	w8, #0x2                // =2
    2804:      	add	x9, sp, #0xf0
    2808:      	ldr	x0, [x0]
    280c:      	blr	x8
    2810:      	cbz	x0, 0x28e8 <generic_fentry_process_event+0x2558>
    2814:      	neg	w8, w0
    2818:      	adrp	x23, 0x2000 <generic_fentry_process_event+0x1c70>
    281c:      	mov	w9, #0x1                // =1
    2820:      	strh	w8, [sp, #0x70]
    2824:      	mov	w8, #0x5                // =5
    2828:      	add	x1, sp, #0x70
    282c:      	mov	w21, #0x1               // =1
    2830:      	strh	w8, [sp, #0x72]
    2834:      	mov	x8, #0x57               // =87
    2838:      	movk	x8, #0x2, lsl #32
    283c:      	stur	x8, [sp, #0x74]
    2840:      	add	x8, sp, #0x70
    2844:      	ldr	x23, [x23]
    2848:      	mov	x0, x23
    284c:      	blr	x9
    2850:      	cbz	x0, 0x28c4 <generic_fentry_process_event+0x2534>
    2854:      	ldr	w8, [x0]
    2858:      	add	w8, w8, #0x1
    285c:      	str	w8, [x0]
    2860:      	mov	w8, #-0x4               // =-4
    2864:      	b	0x2d50 <generic_fentry_process_event+0x29c0>
    2868:      	mov	x23, xzr
    286c:      	stp	w23, w23, [x25]
    2870:      	add	x23, x23, #0x8
    2874:      	b	0x2d58 <generic_fentry_process_event+0x29c8>
    2878:      	cmp	w8, #0x33
    287c:      	b.eq	0x2dc4 <generic_fentry_process_event+0x2a34>
    2880:      	cmp	w8, #0x3c
    2884:      	b.eq	0x28f0 <generic_fentry_process_event+0x2560>
    2888:      	cmp	w8, #0xff
    288c:      	b.ne	0x2e84 <generic_fentry_process_event+0x2af4>
    2890:      	mov	w8, #0x28               // =40
    2894:      	b	0x2dd0 <generic_fentry_process_event+0x2a40>
    2898:      	str	w21, [sp, #0xd8]
    289c:      	mov	x3, xzr
    28a0:      	mov	w8, #0x2                // =2
    28a4:      	add	x9, sp, #0x70
    28a8:      	add	x10, sp, #0xd8
    28ac:      	add	x1, sp, #0x70
    28b0:      	add	x2, sp, #0xd8
    28b4:      	mov	x0, x23
    28b8:      	blr	x8
    28bc:      	mov	w8, #-0x4               // =-4
    28c0:      	b	0x2ad8 <generic_fentry_process_event+0x2748>
    28c4:      	str	w21, [sp, #0xe8]
    28c8:      	mov	x3, xzr
    28cc:      	mov	w8, #0x2                // =2
    28d0:      	add	x9, sp, #0x70
    28d4:      	add	x10, sp, #0xe8
    28d8:      	add	x1, sp, #0x70
    28dc:      	add	x2, sp, #0xe8
    28e0:      	mov	x0, x23
    28e4:      	blr	x8
    28e8:      	mov	w8, #-0x4               // =-4
    28ec:      	b	0x2d50 <generic_fentry_process_event+0x29c0>
    28f0:      	ldrb	w8, [x24, #0x7]
    28f4:      	lsl	w8, w8, #3
    28f8:      	b	0x2dcc <generic_fentry_process_event+0x2a3c>
    28fc:      	mov	w23, #0x4               // =4
    2900:      	b	0x12d0 <generic_fentry_process_event+0xf40>
    2904:      	mov	w8, #0x5e60             // =24160
    2908:      	b	0x2918 <generic_fentry_process_event+0x2588>
    290c:      	mov	w8, #0x5e68             // =24168
    2910:      	b	0x2918 <generic_fentry_process_event+0x2588>
    2914:      	mov	w8, #0x5e50             // =24144
    2918:      	add	x8, x29, x8
    291c:      	ldr	x8, [x8]
    2920:      	add	x21, sp, #0xe0
    2924:      	mov	w24, #0x8               // =8
    2928:      	add	x9, sp, #0xe0
    292c:      	str	x8, [x21, #0x8]
    2930:      	mov	w8, #0x4                // =4
    2934:      	add	x10, sp, #0xe8
    2938:      	add	x0, sp, #0xe0
    293c:      	add	x2, sp, #0xe8
    2940:      	mov	w1, #0x8                // =8
    2944:      	blr	x8
    2948:      	ldr	x21, [x21]
    294c:      	tbz	w25, #0x5, 0x2a9c <generic_fentry_process_event+0x270c>
    2950:      	cmp	x21, #0x1, lsl #12      // =0x1000
    2954:      	b.lo	0x2a80 <generic_fentry_process_event+0x26f0>
    2958:      	ldr	x9, [sp, #0x38]
    295c:      	mov	w8, #0x1                // =1
    2960:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    2964:      	add	x1, sp, #0xf0
    2968:      	str	w8, [x9]
    296c:      	str	wzr, [sp, #0xf0]
    2970:      	add	x9, sp, #0xf0
    2974:      	ldr	x0, [x0]
    2978:      	blr	x8
    297c:      	cbz	x0, 0x2d54 <generic_fentry_process_event+0x29c4>
    2980:      	mov	w8, #0x18               // =24
    2984:      	mov	x22, x0
    2988:      	str	w8, [x0]
    298c:      	mov	w8, #0xe                // =14
    2990:      	blr	x8
    2994:      	mov	x23, x22
    2998:      	cmn	x0, #0x16
    299c:      	str	x0, [x23, #0x10]!
    29a0:      	b.ne	0x29cc <generic_fentry_process_event+0x263c>
    29a4:      	ldr	x8, [sp, #0x8]
    29a8:      	mov	w9, #0x4                // =4
    29ac:      	add	x10, sp, #0x98
    29b0:      	add	x0, sp, #0x98
    29b4:      	mov	w1, #0x8                // =8
    29b8:      	add	x2, x8, #0xe8
    29bc:      	mov	w8, #0x8                // =8
    29c0:      	blr	x9
    29c4:      	ldr	x8, [sp, #0x98]
    29c8:      	str	x8, [x23]
    29cc:      	mov	w8, #0x7d               // =125
    29d0:      	blr	x8
    29d4:      	str	x0, [x22, #0x18]
    29d8:      	ldr	x10, [sp, #0x38]
    29dc:      	mov	x25, xzr
    29e0:      	add	x19, x22, #0x20
    29e4:      	mov	w29, #0xa               // =10
    29e8:      	mov	w24, #0x7fe0            // =32736
    29ec:      	ldp	x8, x9, [x23]
    29f0:      	stur	x9, [x10, #0x1c]
    29f4:      	stur	x8, [x10, #0x14]
    29f8:      	subs	x8, x21, x25
    29fc:      	b.mi	0x2ec8 <generic_fentry_process_event+0x2b38>
    2a00:      	ldr	x9, [sp, #0x48]
    2a04:      	cmp	x8, x24
    2a08:      	mov	x0, x19
    2a0c:      	csel	x23, x8, x24, lo
    2a10:      	mov	w8, #0x4                // =4
    2a14:      	mov	w1, w23
    2a18:      	add	x2, x25, x9
    2a1c:      	blr	x8
    2a20:      	tbnz	w0, #0x1f, 0x2a5c <generic_fentry_process_event+0x26cc>
    2a24:      	add	w4, w23, #0x20
    2a28:      	adrp	x1, 0x2000 <generic_fentry_process_event+0x1c70>
    2a2c:      	ldr	x0, [sp, #0x8]
    2a30:      	mov	w8, #0x19               // =25
    2a34:      	str	w4, [x22, #0x4]
    2a38:      	mov	w9, #-0x1               // =-1
    2a3c:      	mov	w2, #-0x1               // =-1
    2a40:      	mov	x3, x22
    2a44:      	ldr	x1, [x1]
    2a48:      	blr	x8
    2a4c:      	sxtw	x8, w0
    2a50:      	tst	w0, #0x80000000
    2a54:      	csel	x8, x23, x8, eq
    2a58:      	b	0x2a60 <generic_fentry_process_event+0x26d0>
    2a5c:      	sxtw	x8, w0
    2a60:      	tbnz	w8, #0x1f, 0x2ed0 <generic_fentry_process_event+0x2b40>
    2a64:      	and	x8, x8, #0x7fffffff
    2a68:      	add	x25, x8, x25
    2a6c:      	cmp	x25, x21
    2a70:      	b.eq	0x2f1c <generic_fentry_process_event+0x2b8c>
    2a74:      	subs	w29, w29, #0x1
    2a78:      	b.ne	0x29f8 <generic_fentry_process_event+0x2668>
    2a7c:      	b	0x3260 <generic_fentry_process_event+0x2ed0>
    2a80:      	ldr	x8, [sp, #0x38]
    2a84:      	mov	w24, #0xc               // =12
    2a88:      	str	wzr, [x8]
    2a8c:      	ldr	x8, [sp, #0x108]
    2a90:      	add	x8, x23, x8
    2a94:      	add	x8, x8, #0x8
    2a98:      	str	x8, [sp, #0x38]
    2a9c:      	cmp	x21, #0xfff
    2aa0:      	mov	w8, #0xfff              // =4095
    2aa4:      	ldr	x2, [sp, #0x48]
    2aa8:      	csel	x23, x21, x8, lo
    2aac:      	ldr	x8, [sp, #0x38]
    2ab0:      	mov	w1, w23
    2ab4:      	add	x0, x8, #0x8
    2ab8:      	mov	w8, #0x4                // =4
    2abc:      	blr	x8
    2ac0:      	tbnz	w0, #0x1f, 0x2ad4 <generic_fentry_process_event+0x2744>
    2ac4:      	ldr	x8, [sp, #0x38]
    2ac8:      	stp	w21, w23, [x8]
    2acc:      	add	x23, x24, x23
    2ad0:      	b	0x2d58 <generic_fentry_process_event+0x29c8>
    2ad4:      	mov	w8, #-0x2               // =-2
    2ad8:      	ldr	x9, [sp, #0x38]
    2adc:      	mov	w23, #0x4               // =4
    2ae0:      	str	w8, [x9]
    2ae4:      	b	0x2d58 <generic_fentry_process_event+0x29c8>
    2ae8:      	ldr	x8, [sp, #0x108]
    2aec:      	mov	w9, #0x4                // =4
    2af0:      	mov	w1, w23
    2af4:      	add	x29, x8, #0xc
    2af8:      	ldr	x8, [sp, #0x98]
    2afc:      	add	x0, x24, x29
    2b00:      	ldr	x2, [sp, #0x98]
    2b04:      	blr	x9
    2b08:      	tbnz	w0, #0x1f, 0x2d4c <generic_fentry_process_event+0x29bc>
    2b0c:      	cmp	x21, #0x1
    2b10:      	b.eq	0x286c <generic_fentry_process_event+0x24dc>
    2b14:      	ldr	x8, [sp, #0x48]
    2b18:      	mov	w9, #0x4                // =4
    2b1c:      	add	x10, sp, #0x98
    2b20:      	add	x0, sp, #0x98
    2b24:      	mov	w1, #0x10               // =16
    2b28:      	add	x2, x8, #0x10
    2b2c:      	mov	w8, #0x10               // =16
    2b30:      	blr	x9
    2b34:      	tbnz	w0, #0x1f, 0x2d4c <generic_fentry_process_event+0x29bc>
    2b38:      	ldr	x22, [sp, #0xa0]
    2b3c:      	cmp	x22, #0xffe
    2b40:      	b.hi	0x2784 <generic_fentry_process_event+0x23f4>
    2b44:      	add	x29, x23, x29
    2b48:      	ldr	x8, [sp, #0x98]
    2b4c:      	mov	w9, #0x4                // =4
    2b50:      	mov	w1, w22
    2b54:      	add	x0, x24, x29
    2b58:      	ldr	x2, [sp, #0x98]
    2b5c:      	blr	x9
    2b60:      	tbnz	w0, #0x1f, 0x2d4c <generic_fentry_process_event+0x29bc>
    2b64:      	add	x23, x22, x23
    2b68:      	cmp	x21, #0x3
    2b6c:      	b.lo	0x286c <generic_fentry_process_event+0x24dc>
    2b70:      	ldr	x8, [sp, #0x48]
    2b74:      	mov	w9, #0x4                // =4
    2b78:      	add	x10, sp, #0x98
    2b7c:      	add	x0, sp, #0x98
    2b80:      	mov	w1, #0x10               // =16
    2b84:      	add	x2, x8, #0x20
    2b88:      	mov	w8, #0x10               // =16
    2b8c:      	blr	x9
    2b90:      	tbnz	w0, #0x1f, 0x2d4c <generic_fentry_process_event+0x29bc>
    2b94:      	ldr	x19, [sp, #0xa0]
    2b98:      	cmp	x19, #0xffe
    2b9c:      	b.hi	0x2784 <generic_fentry_process_event+0x23f4>
    2ba0:      	add	x29, x22, x29
    2ba4:      	mov	w9, #0x4                // =4
    2ba8:      	mov	w1, w19
    2bac:      	and	x8, x29, #0x3fff
    2bb0:      	add	x0, x24, x8
    2bb4:      	ldr	x8, [sp, #0x98]
    2bb8:      	ldr	x2, [sp, #0x98]
    2bbc:      	blr	x9
    2bc0:      	tbnz	w0, #0x1f, 0x2d4c <generic_fentry_process_event+0x29bc>
    2bc4:      	add	x23, x19, x23
    2bc8:      	cmp	x21, #0x3
    2bcc:      	b.eq	0x286c <generic_fentry_process_event+0x24dc>
    2bd0:      	ldr	x8, [sp, #0x48]
    2bd4:      	mov	w9, #0x4                // =4
    2bd8:      	add	x10, sp, #0x98
    2bdc:      	add	x0, sp, #0x98
    2be0:      	mov	w1, #0x10               // =16
    2be4:      	add	x2, x8, #0x30
    2be8:      	mov	w8, #0x10               // =16
    2bec:      	blr	x9
    2bf0:      	tbnz	w0, #0x1f, 0x2d4c <generic_fentry_process_event+0x29bc>
    2bf4:      	ldr	x22, [sp, #0xa0]
    2bf8:      	cmp	x22, #0xffe
    2bfc:      	b.hi	0x2784 <generic_fentry_process_event+0x23f4>
    2c00:      	add	x29, x19, x29
    2c04:      	mov	w9, #0x4                // =4
    2c08:      	mov	w1, w22
    2c0c:      	and	x8, x29, #0x3fff
    2c10:      	add	x0, x24, x8
    2c14:      	ldr	x8, [sp, #0x98]
    2c18:      	ldr	x2, [sp, #0x98]
    2c1c:      	blr	x9
    2c20:      	tbnz	w0, #0x1f, 0x2d4c <generic_fentry_process_event+0x29bc>
    2c24:      	add	x23, x22, x23
    2c28:      	cmp	x21, #0x5
    2c2c:      	b.lo	0x286c <generic_fentry_process_event+0x24dc>
    2c30:      	ldr	x8, [sp, #0x48]
    2c34:      	mov	w9, #0x4                // =4
    2c38:      	add	x10, sp, #0x98
    2c3c:      	add	x0, sp, #0x98
    2c40:      	mov	w1, #0x10               // =16
    2c44:      	add	x2, x8, #0x40
    2c48:      	mov	w8, #0x10               // =16
    2c4c:      	blr	x9
    2c50:      	tbnz	w0, #0x1f, 0x2d4c <generic_fentry_process_event+0x29bc>
    2c54:      	ldr	x19, [sp, #0xa0]
    2c58:      	cmp	x19, #0xffe
    2c5c:      	b.hi	0x2784 <generic_fentry_process_event+0x23f4>
    2c60:      	add	x29, x22, x29
    2c64:      	mov	w9, #0x4                // =4
    2c68:      	mov	w1, w19
    2c6c:      	and	x8, x29, #0x3fff
    2c70:      	add	x0, x24, x8
    2c74:      	ldr	x8, [sp, #0x98]
    2c78:      	ldr	x2, [sp, #0x98]
    2c7c:      	blr	x9
    2c80:      	tbnz	w0, #0x1f, 0x2d4c <generic_fentry_process_event+0x29bc>
    2c84:      	add	x23, x19, x23
    2c88:      	cmp	x21, #0x5
    2c8c:      	b.eq	0x286c <generic_fentry_process_event+0x24dc>
    2c90:      	ldr	x8, [sp, #0x48]
    2c94:      	mov	w9, #0x4                // =4
    2c98:      	add	x10, sp, #0x98
    2c9c:      	add	x0, sp, #0x98
    2ca0:      	mov	w1, #0x10               // =16
    2ca4:      	add	x2, x8, #0x50
    2ca8:      	mov	w8, #0x10               // =16
    2cac:      	blr	x9
    2cb0:      	tbnz	w0, #0x1f, 0x2d4c <generic_fentry_process_event+0x29bc>
    2cb4:      	ldr	x22, [sp, #0xa0]
    2cb8:      	cmp	x22, #0xffe
    2cbc:      	b.hi	0x2784 <generic_fentry_process_event+0x23f4>
    2cc0:      	add	x29, x19, x29
    2cc4:      	mov	w9, #0x4                // =4
    2cc8:      	mov	w1, w22
    2ccc:      	and	x8, x29, #0x3fff
    2cd0:      	add	x0, x24, x8
    2cd4:      	ldr	x8, [sp, #0x98]
    2cd8:      	ldr	x2, [sp, #0x98]
    2cdc:      	blr	x9
    2ce0:      	tbnz	w0, #0x1f, 0x2d4c <generic_fentry_process_event+0x29bc>
    2ce4:      	add	x23, x22, x23
    2ce8:      	cmp	x21, #0x7
    2cec:      	b.lo	0x286c <generic_fentry_process_event+0x24dc>
    2cf0:      	ldr	x8, [sp, #0x48]
    2cf4:      	mov	w9, #0x4                // =4
    2cf8:      	add	x10, sp, #0x98
    2cfc:      	add	x0, sp, #0x98
    2d00:      	mov	w1, #0x10               // =16
    2d04:      	add	x2, x8, #0x60
    2d08:      	mov	w8, #0x10               // =16
    2d0c:      	blr	x9
    2d10:      	tbnz	w0, #0x1f, 0x2d4c <generic_fentry_process_event+0x29bc>
    2d14:      	ldr	x21, [sp, #0xa0]
    2d18:      	cmp	x21, #0xffe
    2d1c:      	b.hi	0x2784 <generic_fentry_process_event+0x23f4>
    2d20:      	add	x8, x22, x29
    2d24:      	mov	w9, #0x4                // =4
    2d28:      	mov	w1, w21
    2d2c:      	and	x8, x8, #0x3fff
    2d30:      	add	x0, x24, x8
    2d34:      	ldr	x8, [sp, #0x98]
    2d38:      	ldr	x2, [sp, #0x98]
    2d3c:      	blr	x9
    2d40:      	tbnz	w0, #0x1f, 0x2d4c <generic_fentry_process_event+0x29bc>
    2d44:      	add	x23, x21, x23
    2d48:      	b	0x286c <generic_fentry_process_event+0x24dc>
    2d4c:      	mov	w8, #-0x2               // =-2
    2d50:      	str	w8, [x25]
    2d54:      	mov	w23, #0x4               // =4
    2d58:      	adrp	x22, 0x2000 <generic_fentry_process_event+0x1c70>
    2d5c:      	ldr	x22, [x22]
    2d60:      	ldr	x19, [sp, #0x8]
    2d64:      	b	0x12d0 <generic_fentry_process_event+0xf40>
    2d68:      	mov	x21, #-0x1              // =-1
    2d6c:      	b	0x2d74 <generic_fentry_process_event+0x29e4>
    2d70:      	mov	x21, x8
    2d74:      	str	wzr, [sp, #0x98]
    2d78:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    2d7c:      	mov	w8, #0x1                // =1
    2d80:      	add	x9, sp, #0x98
    2d84:      	ldr	x0, [x0]
    2d88:      	add	x1, sp, #0x98
    2d8c:      	blr	x8
    2d90:      	cbz	x0, 0x3120 <generic_fentry_process_event+0x2d90>
    2d94:      	cmn	x21, #0xc
    2d98:      	b.gt	0x2ea8 <generic_fentry_process_event+0x2b18>
    2d9c:      	cmn	x21, #0x1c
    2da0:      	b.eq	0x30ec <generic_fentry_process_event+0x2d5c>
    2da4:      	cmn	x21, #0x16
    2da8:      	b.eq	0x3104 <generic_fentry_process_event+0x2d74>
    2dac:      	cmn	x21, #0x10
    2db0:      	b.ne	0x30fc <generic_fentry_process_event+0x2d6c>
    2db4:      	add	x8, x0, #0x558
    2db8:      	b	0x3110 <generic_fentry_process_event+0x2d80>
    2dbc:      	ldr	x21, [sp, #0x48]
    2dc0:      	b	0x3120 <generic_fentry_process_event+0x2d90>
    2dc4:      	ldrb	w8, [x24, #0x7]
    2dc8:      	lsl	w8, w8, #2
    2dcc:      	add	w8, w8, #0x8
    2dd0:      	strh	w8, [x24, #0x2]
    2dd4:      	ldrh	w9, [x24]
    2dd8:      	ldrb	w25, [x24, #0x6]
    2ddc:      	add	w8, w9, w8
    2de0:      	cmp	w25, #0x3c
    2de4:      	strh	w8, [x24]
    2de8:      	b.hi	0x2ea0 <generic_fentry_process_event+0x2b10>
    2dec:      	mov	x19, #0x1               // =1
    2df0:      	mov	w9, #0x1                // =1
    2df4:      	movk	x19, #0x1800, lsl #32
    2df8:      	lsl	x9, x9, x25
    2dfc:      	movk	x19, #0x1008, lsl #48
    2e00:      	tst	x9, x19
    2e04:      	b.eq	0x2ea0 <generic_fentry_process_event+0x2b10>
    2e08:      	strb	w25, [x24, #0x5]
    2e0c:      	add	x8, x29, w8, uxth
    2e10:      	mov	w9, #0x2                // =2
    2e14:      	mov	w10, #0x4               // =4
    2e18:      	mov	x0, x23
    2e1c:      	mov	w1, #0x2                // =2
    2e20:      	ldrh	w8, [x24]
    2e24:      	add	x2, x29, x8
    2e28:      	blr	x10
    2e2c:      	tbnz	x0, #0x3f, 0x34a0 <generic_fentry_process_event+0x3110>
    2e30:      	ldrb	w8, [x24, #0x5]
    2e34:      	cmp	w8, #0x32
    2e38:      	b.gt	0x2e58 <generic_fentry_process_event+0x2ac8>
    2e3c:      	cbz	w8, 0x2e78 <generic_fentry_process_event+0x2ae8>
    2e40:      	cmp	w8, #0x2b
    2e44:      	b.eq	0x2e78 <generic_fentry_process_event+0x2ae8>
    2e48:      	cmp	w8, #0x2c
    2e4c:      	b.ne	0x2fd8 <generic_fentry_process_event+0x2c48>
    2e50:      	mov	w8, #0x8                // =8
    2e54:      	b	0x2f30 <generic_fentry_process_event+0x2ba0>
    2e58:      	cmp	w8, #0x33
    2e5c:      	b.eq	0x2f24 <generic_fentry_process_event+0x2b94>
    2e60:      	cmp	w8, #0x3c
    2e64:      	b.eq	0x2e78 <generic_fentry_process_event+0x2ae8>
    2e68:      	cmp	w8, #0xff
    2e6c:      	b.ne	0x2fd8 <generic_fentry_process_event+0x2c48>
    2e70:      	mov	w8, #0x28               // =40
    2e74:      	b	0x2f30 <generic_fentry_process_event+0x2ba0>
    2e78:      	ldrb	w8, [x24, #0x7]
    2e7c:      	lsl	w8, w8, #3
    2e80:      	b	0x2f2c <generic_fentry_process_event+0x2b9c>
    2e84:      	ldrh	w8, [x24, #0x2]
    2e88:      	ldrh	w9, [x24]
    2e8c:      	ldrb	w25, [x24, #0x6]
    2e90:      	add	w8, w9, w8
    2e94:      	cmp	w25, #0x3c
    2e98:      	strh	w8, [x24]
    2e9c:      	b.ls	0x2dec <generic_fentry_process_event+0x2a5c>
    2ea0:      	strh	w8, [sp, #0xd8]
    2ea4:      	b	0x34a4 <generic_fentry_process_event+0x3114>
    2ea8:      	cmn	x21, #0xb
    2eac:      	b.eq	0x30f4 <generic_fentry_process_event+0x2d64>
    2eb0:      	cmn	x21, #0x7
    2eb4:      	b.eq	0x310c <generic_fentry_process_event+0x2d7c>
    2eb8:      	cmn	x21, #0x2
    2ebc:      	b.ne	0x30fc <generic_fentry_process_event+0x2d6c>
    2ec0:      	add	x8, x0, #0x548
    2ec4:      	b	0x3110 <generic_fentry_process_event+0x2d80>
    2ec8:      	mov	x25, #-0x1              // =-1
    2ecc:      	b	0x2ed4 <generic_fentry_process_event+0x2b44>
    2ed0:      	mov	x25, x8
    2ed4:      	str	wzr, [sp, #0x98]
    2ed8:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    2edc:      	mov	w8, #0x1                // =1
    2ee0:      	add	x9, sp, #0x98
    2ee4:      	ldr	x0, [x0]
    2ee8:      	add	x1, sp, #0x98
    2eec:      	blr	x8
    2ef0:      	cbz	x0, 0x3260 <generic_fentry_process_event+0x2ed0>
    2ef4:      	cmn	x25, #0xc
    2ef8:      	b.gt	0x2ff8 <generic_fentry_process_event+0x2c68>
    2efc:      	cmn	x25, #0x1c
    2f00:      	b.eq	0x322c <generic_fentry_process_event+0x2e9c>
    2f04:      	cmn	x25, #0x16
    2f08:      	b.eq	0x3234 <generic_fentry_process_event+0x2ea4>
    2f0c:      	cmn	x25, #0x10
    2f10:      	b.ne	0x324c <generic_fentry_process_event+0x2ebc>
    2f14:      	add	x8, x0, #0x558
    2f18:      	b	0x3250 <generic_fentry_process_event+0x2ec0>
    2f1c:      	mov	x25, x21
    2f20:      	b	0x3260 <generic_fentry_process_event+0x2ed0>
    2f24:      	ldrb	w8, [x24, #0x7]
    2f28:      	lsl	w8, w8, #2
    2f2c:      	add	w8, w8, #0x8
    2f30:      	strh	w8, [x24, #0x2]
    2f34:      	ldrh	w9, [x24]
    2f38:      	ldrb	w25, [x24, #0x6]
    2f3c:      	add	w8, w9, w8
    2f40:      	cmp	w25, #0x3c
    2f44:      	strh	w8, [x24]
    2f48:      	b.hi	0x3658 <generic_fentry_process_event+0x32c8>
    2f4c:      	mov	w9, #0x1                // =1
    2f50:      	lsl	x9, x9, x25
    2f54:      	tst	x9, x19
    2f58:      	b.eq	0x3658 <generic_fentry_process_event+0x32c8>
    2f5c:      	strb	w25, [x24, #0x5]
    2f60:      	add	x8, x29, w8, uxth
    2f64:      	mov	w9, #0x2                // =2
    2f68:      	mov	w10, #0x4               // =4
    2f6c:      	mov	x0, x23
    2f70:      	mov	w1, #0x2                // =2
    2f74:      	ldrh	w8, [x24]
    2f78:      	add	x2, x29, x8
    2f7c:      	blr	x10
    2f80:      	tbnz	x0, #0x3f, 0x34a0 <generic_fentry_process_event+0x3110>
    2f84:      	ldrb	w8, [x24, #0x5]
    2f88:      	cmp	w8, #0x32
    2f8c:      	b.gt	0x2fac <generic_fentry_process_event+0x2c1c>
    2f90:      	cbz	w8, 0x2fcc <generic_fentry_process_event+0x2c3c>
    2f94:      	cmp	w8, #0x2b
    2f98:      	b.eq	0x2fcc <generic_fentry_process_event+0x2c3c>
    2f9c:      	cmp	w8, #0x2c
    2fa0:      	b.ne	0x30cc <generic_fentry_process_event+0x2d3c>
    2fa4:      	mov	w8, #0x8                // =8
    2fa8:      	b	0x3024 <generic_fentry_process_event+0x2c94>
    2fac:      	cmp	w8, #0x33
    2fb0:      	b.eq	0x3018 <generic_fentry_process_event+0x2c88>
    2fb4:      	cmp	w8, #0x3c
    2fb8:      	b.eq	0x2fcc <generic_fentry_process_event+0x2c3c>
    2fbc:      	cmp	w8, #0xff
    2fc0:      	b.ne	0x30cc <generic_fentry_process_event+0x2d3c>
    2fc4:      	mov	w8, #0x28               // =40
    2fc8:      	b	0x3024 <generic_fentry_process_event+0x2c94>
    2fcc:      	ldrb	w8, [x24, #0x7]
    2fd0:      	lsl	w8, w8, #3
    2fd4:      	b	0x3020 <generic_fentry_process_event+0x2c90>
    2fd8:      	ldrh	w8, [x24, #0x2]
    2fdc:      	ldrh	w9, [x24]
    2fe0:      	ldrb	w25, [x24, #0x6]
    2fe4:      	add	w8, w9, w8
    2fe8:      	cmp	w25, #0x3c
    2fec:      	strh	w8, [x24]
    2ff0:      	b.ls	0x2f4c <generic_fentry_process_event+0x2bbc>
    2ff4:      	b	0x3658 <generic_fentry_process_event+0x32c8>
    2ff8:      	cmn	x25, #0xb
    2ffc:      	b.eq	0x323c <generic_fentry_process_event+0x2eac>
    3000:      	cmn	x25, #0x7
    3004:      	b.eq	0x3244 <generic_fentry_process_event+0x2eb4>
    3008:      	cmn	x25, #0x2
    300c:      	b.ne	0x324c <generic_fentry_process_event+0x2ebc>
    3010:      	add	x8, x0, #0x548
    3014:      	b	0x3250 <generic_fentry_process_event+0x2ec0>
    3018:      	ldrb	w8, [x24, #0x7]
    301c:      	lsl	w8, w8, #2
    3020:      	add	w8, w8, #0x8
    3024:      	strh	w8, [x24, #0x2]
    3028:      	ldrh	w9, [x24]
    302c:      	ldrb	w25, [x24, #0x6]
    3030:      	add	w8, w9, w8
    3034:      	cmp	w25, #0x3c
    3038:      	strh	w8, [x24]
    303c:      	b.hi	0x3658 <generic_fentry_process_event+0x32c8>
    3040:      	mov	w9, #0x1                // =1
    3044:      	lsl	x9, x9, x25
    3048:      	tst	x9, x19
    304c:      	b.eq	0x3658 <generic_fentry_process_event+0x32c8>
    3050:      	strb	w25, [x24, #0x5]
    3054:      	add	x8, x29, w8, uxth
    3058:      	mov	w9, #0x2                // =2
    305c:      	mov	w10, #0x4               // =4
    3060:      	mov	x0, x23
    3064:      	mov	w1, #0x2                // =2
    3068:      	ldrh	w8, [x24]
    306c:      	add	x2, x29, x8
    3070:      	blr	x10
    3074:      	tbnz	x0, #0x3f, 0x34a0 <generic_fentry_process_event+0x3110>
    3078:      	ldrb	w8, [x24, #0x5]
    307c:      	cmp	w8, #0x32
    3080:      	b.gt	0x30a0 <generic_fentry_process_event+0x2d10>
    3084:      	cbz	w8, 0x30c0 <generic_fentry_process_event+0x2d30>
    3088:      	cmp	w8, #0x2b
    308c:      	b.eq	0x30c0 <generic_fentry_process_event+0x2d30>
    3090:      	cmp	w8, #0x2c
    3094:      	b.ne	0x320c <generic_fentry_process_event+0x2e7c>
    3098:      	mov	w8, #0x8                // =8
    309c:      	b	0x3164 <generic_fentry_process_event+0x2dd4>
    30a0:      	cmp	w8, #0x33
    30a4:      	b.eq	0x3158 <generic_fentry_process_event+0x2dc8>
    30a8:      	cmp	w8, #0x3c
    30ac:      	b.eq	0x30c0 <generic_fentry_process_event+0x2d30>
    30b0:      	cmp	w8, #0xff
    30b4:      	b.ne	0x320c <generic_fentry_process_event+0x2e7c>
    30b8:      	mov	w8, #0x28               // =40
    30bc:      	b	0x3164 <generic_fentry_process_event+0x2dd4>
    30c0:      	ldrb	w8, [x24, #0x7]
    30c4:      	lsl	w8, w8, #3
    30c8:      	b	0x3160 <generic_fentry_process_event+0x2dd0>
    30cc:      	ldrh	w8, [x24, #0x2]
    30d0:      	ldrh	w9, [x24]
    30d4:      	ldrb	w25, [x24, #0x6]
    30d8:      	add	w8, w9, w8
    30dc:      	cmp	w25, #0x3c
    30e0:      	strh	w8, [x24]
    30e4:      	b.ls	0x3040 <generic_fentry_process_event+0x2cb0>
    30e8:      	b	0x3658 <generic_fentry_process_event+0x32c8>
    30ec:      	add	x8, x0, #0x568
    30f0:      	b	0x3110 <generic_fentry_process_event+0x2d80>
    30f4:      	add	x8, x0, #0x570
    30f8:      	b	0x3110 <generic_fentry_process_event+0x2d80>
    30fc:      	add	x8, x0, #0x540
    3100:      	b	0x3110 <generic_fentry_process_event+0x2d80>
    3104:      	add	x8, x0, #0x560
    3108:      	b	0x3110 <generic_fentry_process_event+0x2d80>
    310c:      	add	x8, x0, #0x550
    3110:      	ldaxr	x9, [x8]
    3114:      	add	x9, x9, #0x1
    3118:      	stlxr	w10, x9, [x8]
    311c:      	cbnz	w10, 0x3110 <generic_fentry_process_event+0x2d80>
    3120:      	tbnz	w21, #0x1f, 0x313c <generic_fentry_process_event+0x2dac>
    3124:      	ldr	x9, [sp, #0x48]
    3128:      	stur	xzr, [x29, #0x4]
    312c:      	sub	w8, w9, w21
    3130:      	cmn	x9, #0x1
    3134:      	csel	w8, wzr, w8, eq
    3138:      	b	0x314c <generic_fentry_process_event+0x2dbc>
    313c:      	mov	w8, wzr
    3140:      	mov	x9, x29
    3144:      	stp	w21, wzr, [x29, #0x4]
    3148:      	mov	w21, wzr
    314c:      	stp	w8, w21, [x29, #0xc]
    3150:      	mov	w23, #0x24              // =36
    3154:      	b	0x12d0 <generic_fentry_process_event+0xf40>
    3158:      	ldrb	w8, [x24, #0x7]
    315c:      	lsl	w8, w8, #2
    3160:      	add	w8, w8, #0x8
    3164:      	strh	w8, [x24, #0x2]
    3168:      	ldrh	w9, [x24]
    316c:      	ldrb	w25, [x24, #0x6]
    3170:      	add	w8, w9, w8
    3174:      	cmp	w25, #0x3c
    3178:      	strh	w8, [x24]
    317c:      	b.hi	0x3658 <generic_fentry_process_event+0x32c8>
    3180:      	mov	w9, #0x1                // =1
    3184:      	lsl	x9, x9, x25
    3188:      	tst	x9, x19
    318c:      	b.eq	0x3658 <generic_fentry_process_event+0x32c8>
    3190:      	strb	w25, [x24, #0x5]
    3194:      	add	x8, x29, w8, uxth
    3198:      	mov	w9, #0x2                // =2
    319c:      	mov	w10, #0x4               // =4
    31a0:      	mov	x0, x23
    31a4:      	mov	w1, #0x2                // =2
    31a8:      	ldrh	w8, [x24]
    31ac:      	add	x2, x29, x8
    31b0:      	blr	x10
    31b4:      	tbnz	x0, #0x3f, 0x34a0 <generic_fentry_process_event+0x3110>
    31b8:      	ldrb	w8, [x24, #0x5]
    31bc:      	cmp	w8, #0x32
    31c0:      	b.gt	0x31e0 <generic_fentry_process_event+0x2e50>
    31c4:      	cbz	w8, 0x3200 <generic_fentry_process_event+0x2e70>
    31c8:      	cmp	w8, #0x2b
    31cc:      	b.eq	0x3200 <generic_fentry_process_event+0x2e70>
    31d0:      	cmp	w8, #0x2c
    31d4:      	b.ne	0x3350 <generic_fentry_process_event+0x2fc0>
    31d8:      	mov	w8, #0x8                // =8
    31dc:      	b	0x32a8 <generic_fentry_process_event+0x2f18>
    31e0:      	cmp	w8, #0x33
    31e4:      	b.eq	0x329c <generic_fentry_process_event+0x2f0c>
    31e8:      	cmp	w8, #0x3c
    31ec:      	b.eq	0x3200 <generic_fentry_process_event+0x2e70>
    31f0:      	cmp	w8, #0xff
    31f4:      	b.ne	0x3350 <generic_fentry_process_event+0x2fc0>
    31f8:      	mov	w8, #0x28               // =40
    31fc:      	b	0x32a8 <generic_fentry_process_event+0x2f18>
    3200:      	ldrb	w8, [x24, #0x7]
    3204:      	lsl	w8, w8, #3
    3208:      	b	0x32a4 <generic_fentry_process_event+0x2f14>
    320c:      	ldrh	w8, [x24, #0x2]
    3210:      	ldrh	w9, [x24]
    3214:      	ldrb	w25, [x24, #0x6]
    3218:      	add	w8, w9, w8
    321c:      	cmp	w25, #0x3c
    3220:      	strh	w8, [x24]
    3224:      	b.ls	0x3180 <generic_fentry_process_event+0x2df0>
    3228:      	b	0x3658 <generic_fentry_process_event+0x32c8>
    322c:      	add	x8, x0, #0x568
    3230:      	b	0x3250 <generic_fentry_process_event+0x2ec0>
    3234:      	add	x8, x0, #0x560
    3238:      	b	0x3250 <generic_fentry_process_event+0x2ec0>
    323c:      	add	x8, x0, #0x570
    3240:      	b	0x3250 <generic_fentry_process_event+0x2ec0>
    3244:      	add	x8, x0, #0x550
    3248:      	b	0x3250 <generic_fentry_process_event+0x2ec0>
    324c:      	add	x8, x0, #0x540
    3250:      	ldaxr	x9, [x8]
    3254:      	add	x9, x9, #0x1
    3258:      	stlxr	w10, x9, [x8]
    325c:      	cbnz	w10, 0x3250 <generic_fentry_process_event+0x2ec0>
    3260:      	tbnz	w25, #0x1f, 0x327c <generic_fentry_process_event+0x2eec>
    3264:      	ldr	x8, [sp, #0x38]
    3268:      	cmn	x21, #0x1
    326c:      	stur	xzr, [x8, #0x4]
    3270:      	sub	w8, w21, w25
    3274:      	csel	w8, wzr, w8, eq
    3278:      	b	0x328c <generic_fentry_process_event+0x2efc>
    327c:      	ldr	x9, [sp, #0x38]
    3280:      	mov	w8, wzr
    3284:      	stp	w25, wzr, [x9, #0x4]
    3288:      	mov	w25, wzr
    328c:      	ldr	x9, [sp, #0x38]
    3290:      	mov	w23, #0x24              // =36
    3294:      	stp	w8, w25, [x9, #0xc]
    3298:      	b	0x2d58 <generic_fentry_process_event+0x29c8>
    329c:      	ldrb	w8, [x24, #0x7]
    32a0:      	lsl	w8, w8, #2
    32a4:      	add	w8, w8, #0x8
    32a8:      	strh	w8, [x24, #0x2]
    32ac:      	ldrh	w9, [x24]
    32b0:      	ldrb	w25, [x24, #0x6]
    32b4:      	add	w8, w9, w8
    32b8:      	cmp	w25, #0x3c
    32bc:      	strh	w8, [x24]
    32c0:      	b.hi	0x3658 <generic_fentry_process_event+0x32c8>
    32c4:      	mov	w9, #0x1                // =1
    32c8:      	lsl	x9, x9, x25
    32cc:      	tst	x9, x19
    32d0:      	b.eq	0x3658 <generic_fentry_process_event+0x32c8>
    32d4:      	strb	w25, [x24, #0x5]
    32d8:      	add	x8, x29, w8, uxth
    32dc:      	mov	w9, #0x2                // =2
    32e0:      	mov	w10, #0x4               // =4
    32e4:      	mov	x0, x23
    32e8:      	mov	w1, #0x2                // =2
    32ec:      	ldrh	w8, [x24]
    32f0:      	add	x2, x29, x8
    32f4:      	blr	x10
    32f8:      	tbnz	x0, #0x3f, 0x34a0 <generic_fentry_process_event+0x3110>
    32fc:      	ldrb	w8, [x24, #0x5]
    3300:      	cmp	w8, #0x32
    3304:      	b.gt	0x3324 <generic_fentry_process_event+0x2f94>
    3308:      	cbz	w8, 0x3344 <generic_fentry_process_event+0x2fb4>
    330c:      	cmp	w8, #0x2b
    3310:      	b.eq	0x3344 <generic_fentry_process_event+0x2fb4>
    3314:      	cmp	w8, #0x2c
    3318:      	b.ne	0x3424 <generic_fentry_process_event+0x3094>
    331c:      	mov	w8, #0x8                // =8
    3320:      	b	0x337c <generic_fentry_process_event+0x2fec>
    3324:      	cmp	w8, #0x33
    3328:      	b.eq	0x3370 <generic_fentry_process_event+0x2fe0>
    332c:      	cmp	w8, #0x3c
    3330:      	b.eq	0x3344 <generic_fentry_process_event+0x2fb4>
    3334:      	cmp	w8, #0xff
    3338:      	b.ne	0x3424 <generic_fentry_process_event+0x3094>
    333c:      	mov	w8, #0x28               // =40
    3340:      	b	0x337c <generic_fentry_process_event+0x2fec>
    3344:      	ldrb	w8, [x24, #0x7]
    3348:      	lsl	w8, w8, #3
    334c:      	b	0x3378 <generic_fentry_process_event+0x2fe8>
    3350:      	ldrh	w8, [x24, #0x2]
    3354:      	ldrh	w9, [x24]
    3358:      	ldrb	w25, [x24, #0x6]
    335c:      	add	w8, w9, w8
    3360:      	cmp	w25, #0x3c
    3364:      	strh	w8, [x24]
    3368:      	b.ls	0x32c4 <generic_fentry_process_event+0x2f34>
    336c:      	b	0x3658 <generic_fentry_process_event+0x32c8>
    3370:      	ldrb	w8, [x24, #0x7]
    3374:      	lsl	w8, w8, #2
    3378:      	add	w8, w8, #0x8
    337c:      	strh	w8, [x24, #0x2]
    3380:      	ldrh	w9, [x24]
    3384:      	ldrb	w25, [x24, #0x6]
    3388:      	add	w8, w9, w8
    338c:      	cmp	w25, #0x3c
    3390:      	strh	w8, [x24]
    3394:      	b.hi	0x3658 <generic_fentry_process_event+0x32c8>
    3398:      	mov	w9, #0x1                // =1
    339c:      	lsl	x9, x9, x25
    33a0:      	tst	x9, x19
    33a4:      	b.eq	0x3658 <generic_fentry_process_event+0x32c8>
    33a8:      	strb	w25, [x24, #0x5]
    33ac:      	add	x8, x29, w8, uxth
    33b0:      	mov	w9, #0x2                // =2
    33b4:      	mov	w10, #0x4               // =4
    33b8:      	mov	x0, x23
    33bc:      	mov	w1, #0x2                // =2
    33c0:      	ldrh	w8, [x24]
    33c4:      	add	x2, x29, x8
    33c8:      	blr	x10
    33cc:      	tbnz	x0, #0x3f, 0x34a0 <generic_fentry_process_event+0x3110>
    33d0:      	ldrb	w8, [x24, #0x5]
    33d4:      	cmp	w8, #0x32
    33d8:      	b.gt	0x33f8 <generic_fentry_process_event+0x3068>
    33dc:      	cbz	w8, 0x3418 <generic_fentry_process_event+0x3088>
    33e0:      	cmp	w8, #0x2b
    33e4:      	b.eq	0x3418 <generic_fentry_process_event+0x3088>
    33e8:      	cmp	w8, #0x2c
    33ec:      	b.ne	0x363c <generic_fentry_process_event+0x32ac>
    33f0:      	mov	w8, #0x8                // =8
    33f4:      	b	0x3450 <generic_fentry_process_event+0x30c0>
    33f8:      	cmp	w8, #0x33
    33fc:      	b.eq	0x3444 <generic_fentry_process_event+0x30b4>
    3400:      	cmp	w8, #0x3c
    3404:      	b.eq	0x3418 <generic_fentry_process_event+0x3088>
    3408:      	cmp	w8, #0xff
    340c:      	b.ne	0x363c <generic_fentry_process_event+0x32ac>
    3410:      	mov	w8, #0x28               // =40
    3414:      	b	0x3450 <generic_fentry_process_event+0x30c0>
    3418:      	ldrb	w8, [x24, #0x7]
    341c:      	lsl	w8, w8, #3
    3420:      	b	0x344c <generic_fentry_process_event+0x30bc>
    3424:      	ldrh	w8, [x24, #0x2]
    3428:      	ldrh	w9, [x24]
    342c:      	ldrb	w25, [x24, #0x6]
    3430:      	add	w8, w9, w8
    3434:      	cmp	w25, #0x3c
    3438:      	strh	w8, [x24]
    343c:      	b.ls	0x3398 <generic_fentry_process_event+0x3008>
    3440:      	b	0x3658 <generic_fentry_process_event+0x32c8>
    3444:      	ldrb	w8, [x24, #0x7]
    3448:      	lsl	w8, w8, #2
    344c:      	add	w8, w8, #0x8
    3450:      	strh	w8, [x24, #0x2]
    3454:      	ldrh	w9, [x24]
    3458:      	ldrb	w25, [x24, #0x6]
    345c:      	add	w8, w9, w8
    3460:      	cmp	w25, #0x3c
    3464:      	strh	w8, [x24]
    3468:      	b.hi	0x3658 <generic_fentry_process_event+0x32c8>
    346c:      	mov	w9, #0x1                // =1
    3470:      	lsl	x9, x9, x25
    3474:      	tst	x9, x19
    3478:      	b.eq	0x3658 <generic_fentry_process_event+0x32c8>
    347c:      	strb	w25, [x24, #0x5]
    3480:      	add	x8, x29, w8, uxth
    3484:      	mov	w9, #0x2                // =2
    3488:      	mov	w10, #0x4               // =4
    348c:      	mov	x0, x23
    3490:      	mov	w1, #0x2                // =2
    3494:      	ldrh	w8, [x24]
    3498:      	add	x2, x29, x8
    349c:      	blr	x10
    34a0:      	mov	w25, wzr
    34a4:      	ldr	x29, [sp, #0x30]
    34a8:      	mov	w8, #0xa                // =10
    34ac:      	strb	w25, [sp, #0x88]
    34b0:      	add	x2, x21, #0x8
    34b4:      	mov	w23, #0x10              // =16
    34b8:      	mov	w1, #0x10               // =16
    34bc:      	mov	w24, #0x4               // =4
    34c0:      	strh	w25, [x29, #0x24]
    34c4:      	strh	w8, [x29, #0x26]
    34c8:      	mov	w8, #0x4                // =4
    34cc:      	mov	x0, x29
    34d0:      	blr	x8
    34d4:      	add	x0, x29, #0x10
    34d8:      	add	x2, x21, #0x18
    34dc:      	mov	w1, #0x10               // =16
    34e0:      	blr	x24
    34e4:      	cmp	w25, #0x11
    34e8:      	b.eq	0x352c <generic_fentry_process_event+0x319c>
    34ec:      	cmp	w25, #0x6
    34f0:      	b.ne	0x356c <generic_fentry_process_event+0x31dc>
    34f4:      	ldr	x8, [sp, #0x98]
    34f8:      	ldrh	w9, [sp, #0xd8]
    34fc:      	mov	w21, #0x2               // =2
    3500:      	mov	w1, #0x2                // =2
    3504:      	mov	w24, #0x4               // =4
    3508:      	add	x23, x8, x9
    350c:      	ldr	x25, [sp, #0x30]
    3510:      	add	x0, x25, #0x20
    3514:      	mov	w8, #0x4                // =4
    3518:      	mov	x2, x23
    351c:      	blr	x8
    3520:      	add	x0, x25, #0x22
    3524:      	add	x2, x23, #0x2
    3528:      	b	0x3560 <generic_fentry_process_event+0x31d0>
    352c:      	ldr	x8, [sp, #0x98]
    3530:      	ldrh	w9, [sp, #0xd8]
    3534:      	mov	w21, #0x2               // =2
    3538:      	mov	w1, #0x2                // =2
    353c:      	mov	w24, #0x4               // =4
    3540:      	add	x23, x8, x9
    3544:      	ldr	x25, [sp, #0x30]
    3548:      	add	x0, x25, #0x20
    354c:      	mov	w8, #0x4                // =4
    3550:      	mov	x2, x23
    3554:      	blr	x8
    3558:      	add	x0, x25, #0x22
    355c:      	add	x2, x23, #0x2
    3560:      	mov	w1, #0x2                // =2
    3564:      	blr	x24
    3568:      	b	0x3574 <generic_fentry_process_event+0x31e4>
    356c:      	ldr	x8, [sp, #0x30]
    3570:      	str	wzr, [x8, #0x20]
    3574:      	ldr	x9, [sp, #0x30]
    3578:      	add	x10, sp, #0xf0
    357c:      	add	x0, sp, #0xf0
    3580:      	mov	w1, #0x8                // =8
    3584:      	ldrh	w8, [x9, #0x20]
    3588:      	rev	w8, w8
    358c:      	lsr	w8, w8, #16
    3590:      	strh	w8, [x9, #0x20]
    3594:      	ldrh	w8, [x9, #0x22]
    3598:      	rev	w8, w8
    359c:      	lsr	w8, w8, #16
    35a0:      	strh	w8, [x9, #0x22]
    35a4:      	ldr	x8, [sp, #0x48]
    35a8:      	mov	w9, #0x4                // =4
    35ac:      	add	x2, x8, #0xe0
    35b0:      	mov	w8, #0x8                // =8
    35b4:      	blr	x9
    35b8:      	add	x8, sp, #0xe0
    35bc:      	ldr	x8, [x8, #0x10]
    35c0:      	cbz	x8, 0x3624 <generic_fentry_process_event+0x3294>
    35c4:      	add	x8, x8, #0x5
    35c8:      	mov	w9, #0x8                // =8
    35cc:      	add	x10, sp, #0x70
    35d0:      	mov	w11, #0x4               // =4
    35d4:      	add	x23, sp, #0xe0
    35d8:      	ldr	x8, [x23, #0x10]
    35dc:      	add	x0, sp, #0x70
    35e0:      	mov	w1, #0x8                // =8
    35e4:      	mov	w21, #0x4               // =4
    35e8:      	add	x2, x8, #0x5
    35ec:      	blr	x11
    35f0:      	ldr	x8, [x23, #0x10]
    35f4:      	ldr	x9, [sp, #0x70]
    35f8:      	mov	w1, #0x4                // =4
    35fc:      	add	x23, x8, x9, lsl #3
    3600:      	ldr	x24, [sp, #0x30]
    3604:      	add	x0, x24, #0x38
    3608:      	mov	w8, #0x4                // =4
    360c:      	add	x2, x23, #0x44
    3610:      	blr	x8
    3614:      	add	x0, x24, #0x3c
    3618:      	add	x2, x23, #0x45
    361c:      	mov	w1, #0x4                // =4
    3620:      	blr	x21
    3624:      	mov	w23, #0x40              // =64
    3628:      	adrp	x22, 0x3000 <generic_fentry_process_event+0x2c70>
    362c:      	mov	w10, #0x5ea0            // =24224
    3630:      	ldr	x22, [x22]
    3634:      	ldr	x19, [sp, #0x8]
    3638:      	b	0x12d4 <generic_fentry_process_event+0xf44>
    363c:      	ldrh	w8, [x24, #0x2]
    3640:      	ldrh	w9, [x24]
    3644:      	ldrb	w25, [x24, #0x6]
    3648:      	add	w8, w9, w8
    364c:      	cmp	w25, #0x3c
    3650:      	strh	w8, [x24]
    3654:      	b.ls	0x346c <generic_fentry_process_event+0x30dc>
    3658:      	strh	w8, [sp, #0xd8]
    365c:      	b	0x34a4 <generic_fentry_process_event+0x3114>

0000000000003660 <generic_fentry_process_filter>:
    3660:      	sub	sp, sp, #0x130
    3664:      	str	x29, [sp, #0xe0]
    3668:      	stp	x30, x25, [sp, #0xf0]
    366c:      	stp	x24, x23, [sp, #0x100]
    3670:      	stp	x22, x21, [sp, #0x110]
    3674:      	stp	x20, x19, [sp, #0x120]
    3678:      	mov	x22, x0
    367c:      	str	wzr, [sp, #0x54]
    3680:      	adrp	x0, 0x3000 <generic_fentry_process_event+0x2c70>
    3684:      	mov	w8, #0x1                // =1
    3688:      	ldr	x0, [x0]
    368c:      	add	x9, sp, #0x54
    3690:      	add	x1, sp, #0x54
    3694:      	blr	x8
    3698:      	cbz	x0, 0x5534 <generic_fentry_process_filter+0x1ed4>
    369c:      	mov	w8, #0x5ec0             // =24256
    36a0:      	mov	x20, x0
    36a4:      	add	x29, x0, x8
    36a8:      	mov	w8, #0x23               // =35
    36ac:      	blr	x8
    36b0:      	str	x0, [sp, #0x58]
    36b4:      	add	x8, x0, #0x8d4
    36b8:      	mov	w9, #0x4                // =4
    36bc:      	mov	w10, #0x71              // =113
    36c0:      	add	x11, sp, #0xd8
    36c4:      	add	x0, sp, #0xd8
    36c8:      	mov	w1, #0x4                // =4
    36cc:      	ldr	x8, [sp, #0x58]
    36d0:      	add	x2, x8, #0x8d4
    36d4:      	blr	x10
    36d8:      	ldr	w8, [sp, #0xd8]
    36dc:      	adrp	x19, 0x3000 <generic_fentry_process_event+0x2c70>
    36e0:      	add	x9, sp, #0xc8
    36e4:      	add	x1, sp, #0xc8
    36e8:      	str	w8, [sp, #0xc8]
    36ec:      	mov	w8, #0x1                // =1
    36f0:      	ldr	x19, [x19]
    36f4:      	mov	x0, x19
    36f8:      	blr	x8
    36fc:      	cbz	x0, 0x370c <generic_fentry_process_filter+0xac>
    3700:      	ldr	x8, [x0, #0x8]
    3704:      	mov	x24, x0
    3708:      	cbnz	x8, 0x433c <generic_fentry_process_filter+0xcdc>
    370c:      	ldr	x8, [sp, #0x58]
    3710:      	mov	w9, #0x8                // =8
    3714:      	mov	w10, #0x71              // =113
    3718:      	add	x11, sp, #0x58
    371c:      	add	x0, sp, #0x58
    3720:      	mov	w1, #0x8                // =8
    3724:      	add	x8, x8, #0x8e0
    3728:      	ldr	x8, [sp, #0x58]
    372c:      	add	x2, x8, #0x8e0
    3730:      	blr	x10
    3734:      	ldr	x8, [sp, #0x58]
    3738:      	cbz	x8, 0x38b4 <generic_fentry_process_filter+0x254>
    373c:      	add	x8, x8, #0x8d4
    3740:      	mov	w9, #0x4                // =4
    3744:      	mov	w10, #0x71              // =113
    3748:      	add	x11, sp, #0xd8
    374c:      	ldr	x8, [sp, #0x58]
    3750:      	add	x0, sp, #0xd8
    3754:      	mov	w1, #0x4                // =4
    3758:      	add	x2, x8, #0x8d4
    375c:      	blr	x10
    3760:      	ldr	w8, [sp, #0xd8]
    3764:      	add	x9, sp, #0xc8
    3768:      	add	x1, sp, #0xc8
    376c:      	mov	x0, x19
    3770:      	str	w8, [sp, #0xc8]
    3774:      	mov	w8, #0x1                // =1
    3778:      	blr	x8
    377c:      	cbz	x0, 0x378c <generic_fentry_process_filter+0x12c>
    3780:      	ldr	x8, [x0, #0x8]
    3784:      	mov	x24, x0
    3788:      	cbnz	x8, 0x433c <generic_fentry_process_filter+0xcdc>
    378c:      	ldr	x8, [sp, #0x58]
    3790:      	mov	w9, #0x8                // =8
    3794:      	mov	w10, #0x71              // =113
    3798:      	add	x11, sp, #0x58
    379c:      	add	x0, sp, #0x58
    37a0:      	mov	w1, #0x8                // =8
    37a4:      	add	x8, x8, #0x8e0
    37a8:      	ldr	x8, [sp, #0x58]
    37ac:      	add	x2, x8, #0x8e0
    37b0:      	blr	x10
    37b4:      	ldr	x8, [sp, #0x58]
    37b8:      	cbz	x8, 0x38b4 <generic_fentry_process_filter+0x254>
    37bc:      	add	x8, x8, #0x8d4
    37c0:      	mov	w9, #0x4                // =4
    37c4:      	mov	w10, #0x71              // =113
    37c8:      	add	x11, sp, #0xd8
    37cc:      	ldr	x8, [sp, #0x58]
    37d0:      	add	x0, sp, #0xd8
    37d4:      	mov	w1, #0x4                // =4
    37d8:      	add	x2, x8, #0x8d4
    37dc:      	blr	x10
    37e0:      	ldr	w8, [sp, #0xd8]
    37e4:      	add	x9, sp, #0xc8
    37e8:      	add	x1, sp, #0xc8
    37ec:      	mov	x0, x19
    37f0:      	str	w8, [sp, #0xc8]
    37f4:      	mov	w8, #0x1                // =1
    37f8:      	blr	x8
    37fc:      	cbz	x0, 0x380c <generic_fentry_process_filter+0x1ac>
    3800:      	ldr	x8, [x0, #0x8]
    3804:      	mov	x24, x0
    3808:      	cbnz	x8, 0x433c <generic_fentry_process_filter+0xcdc>
    380c:      	ldr	x8, [sp, #0x58]
    3810:      	mov	w9, #0x8                // =8
    3814:      	mov	w10, #0x71              // =113
    3818:      	add	x11, sp, #0x58
    381c:      	add	x0, sp, #0x58
    3820:      	mov	w1, #0x8                // =8
    3824:      	add	x8, x8, #0x8e0
    3828:      	ldr	x8, [sp, #0x58]
    382c:      	add	x2, x8, #0x8e0
    3830:      	blr	x10
    3834:      	ldr	x8, [sp, #0x58]
    3838:      	cbz	x8, 0x38b4 <generic_fentry_process_filter+0x254>
    383c:      	add	x8, x8, #0x8d4
    3840:      	mov	w9, #0x4                // =4
    3844:      	mov	w10, #0x71              // =113
    3848:      	add	x11, sp, #0xd8
    384c:      	ldr	x8, [sp, #0x58]
    3850:      	add	x0, sp, #0xd8
    3854:      	mov	w1, #0x4                // =4
    3858:      	add	x2, x8, #0x8d4
    385c:      	blr	x10
    3860:      	ldr	w8, [sp, #0xd8]
    3864:      	add	x9, sp, #0xc8
    3868:      	add	x1, sp, #0xc8
    386c:      	mov	x0, x19
    3870:      	str	w8, [sp, #0xc8]
    3874:      	mov	w8, #0x1                // =1
    3878:      	blr	x8
    387c:      	cbz	x0, 0x388c <generic_fentry_process_filter+0x22c>
    3880:      	ldr	x8, [x0, #0x8]
    3884:      	mov	x24, x0
    3888:      	cbnz	x8, 0x433c <generic_fentry_process_filter+0xcdc>
    388c:      	ldr	x8, [sp, #0x58]
    3890:      	mov	w9, #0x8                // =8
    3894:      	mov	w10, #0x71              // =113
    3898:      	add	x11, sp, #0x58
    389c:      	add	x0, sp, #0x58
    38a0:      	mov	w1, #0x8                // =8
    38a4:      	add	x8, x8, #0x8e0
    38a8:      	ldr	x8, [sp, #0x58]
    38ac:      	add	x2, x8, #0x8e0
    38b0:      	blr	x10
    38b4:      	mov	w8, #0x23               // =35
    38b8:      	blr	x8
    38bc:      	add	x2, x0, #0x8d4
    38c0:      	mov	w8, #0x4                // =4
    38c4:      	add	x9, sp, #0x58
    38c8:      	mov	x24, x0
    38cc:      	add	x0, sp, #0x58
    38d0:      	mov	w1, #0x4                // =4
    38d4:      	blr	x8
    38d8:      	ldr	w8, [sp, #0x58]
    38dc:      	mov	x19, x29
    38e0:      	str	w8, [x19, #0x50]!
    38e4:      	mov	w8, #0x7d               // =125
    38e8:      	blr	x8
    38ec:      	str	x0, [x20, #0x5f18]
    38f0:      	str	wzr, [x19, #0x10]
    38f4:      	add	x2, x24, #0x60
    38f8:      	mov	w8, #0x8                // =8
    38fc:      	mov	w9, #0x71               // =113
    3900:      	add	x10, sp, #0xc8
    3904:      	str	xzr, [x20, #0x5f28]
    3908:      	str	x19, [sp, #0x48]
    390c:      	add	x0, sp, #0xc8
    3910:      	mov	w1, #0x8                // =8
    3914:      	str	wzr, [x19, #0x20]
    3918:      	blr	x9
    391c:      	ldr	x8, [sp, #0xc8]
    3920:      	cbz	x8, 0x3990 <generic_fentry_process_filter+0x330>
    3924:      	add	x8, x8, #0x4
    3928:      	mov	w9, #0x4                // =4
    392c:      	mov	w10, #0x71              // =113
    3930:      	add	x11, sp, #0xd8
    3934:      	ldr	x8, [sp, #0xc8]
    3938:      	add	x0, sp, #0xd8
    393c:      	mov	w1, #0x4                // =4
    3940:      	add	x2, x8, #0x4
    3944:      	blr	x10
    3948:      	ldr	w8, [sp, #0xd8]
    394c:      	cbz	w8, 0x3990 <generic_fentry_process_filter+0x330>
    3950:      	ldr	x9, [sp, #0xc8]
    3954:      	lsl	w8, w8, #4
    3958:      	mov	w10, #0x71              // =113
    395c:      	add	x11, sp, #0x58
    3960:      	add	x0, sp, #0x58
    3964:      	mov	w1, #0x10               // =16
    3968:      	add	x8, x9, x8
    396c:      	mov	w9, #0x10               // =16
    3970:      	add	x8, x8, #0x80
    3974:      	ldr	w9, [sp, #0xd8]
    3978:      	ldr	x8, [sp, #0xc8]
    397c:      	lsl	w9, w9, #4
    3980:      	add	x8, x8, x9
    3984:      	add	x2, x8, #0x80
    3988:      	blr	x10
    398c:      	ldr	w8, [sp, #0x58]
    3990:      	str	w8, [x29, #0x74]
    3994:      	mov	w8, #0x5f60             // =24416
    3998:      	str	x20, [sp, #0xe8]
    399c:      	add	x23, x24, #0xae0
    39a0:      	mov	w19, #0x8               // =8
    39a4:      	add	x25, x20, x8
    39a8:      	add	x8, sp, #0x58
    39ac:      	mov	w9, #0x4                // =4
    39b0:      	add	x0, sp, #0x58
    39b4:      	mov	w1, #0x8                // =8
    39b8:      	mov	x2, x23
    39bc:      	mov	w21, #0x4               // =4
    39c0:      	blr	x9
    39c4:      	ldr	x20, [sp, #0x58]
    39c8:      	ldr	x9, [sp, #0xe8]
    39cc:      	mov	w8, #0x5f68             // =24424
    39d0:      	mov	w1, #0x8                // =8
    39d4:      	add	x0, x9, x8
    39d8:      	add	x2, x20, #0x40
    39dc:      	mov	w8, #0x4                // =4
    39e0:      	blr	x8
    39e4:      	ldr	x9, [sp, #0xe8]
    39e8:      	mov	w8, #0x5f70             // =24432
    39ec:      	add	x2, x20, #0x30
    39f0:      	mov	w1, #0x8                // =8
    39f4:      	add	x0, x9, x8
    39f8:      	mov	w8, #0x4                // =4
    39fc:      	blr	x8
    3a00:      	add	x2, x20, #0x38
    3a04:      	mov	w8, #0x4                // =4
    3a08:      	mov	x0, x25
    3a0c:      	mov	w1, #0x8                // =8
    3a10:      	blr	x8
    3a14:      	ldr	x9, [sp, #0xe8]
    3a18:      	mov	w8, #0x5f38             // =24376
    3a1c:      	add	x2, x24, #0xb50
    3a20:      	add	x0, sp, #0xd8
    3a24:      	mov	w1, #0x8                // =8
    3a28:      	add	x25, x9, x8
    3a2c:      	add	x8, sp, #0xd8
    3a30:      	mov	w9, #0x4                // =4
    3a34:      	blr	x9
    3a38:      	add	x12, sp, #0xd8
    3a3c:      	mov	w9, #0x48               // =72
    3a40:      	add	x10, sp, #0x58
    3a44:      	ldr	x8, [x12]
    3a48:      	mov	w11, #0x4               // =4
    3a4c:      	add	x0, sp, #0x58
    3a50:      	mov	w1, #0x48               // =72
    3a54:      	ldr	x2, [x12]
    3a58:      	blr	x11
    3a5c:      	ldr	x8, [sp, #0x60]
    3a60:      	mov	w9, #0x4                // =4
    3a64:      	mov	x0, x25
    3a68:      	mov	w1, #0x4                // =4
    3a6c:      	add	x8, x8, #0x218
    3a70:      	ldr	x8, [sp, #0x60]
    3a74:      	ldr	x25, [sp, #0xe8]
    3a78:      	add	x2, x8, #0x218
    3a7c:      	blr	x9
    3a80:      	mov	w8, #0x5f3c             // =24380
    3a84:      	mov	w9, #0x4                // =4
    3a88:      	mov	w1, #0x4                // =4
    3a8c:      	add	x0, x25, x8
    3a90:      	ldr	x8, [sp, #0x68]
    3a94:      	add	x8, x8, #0x4d8
    3a98:      	ldr	x8, [sp, #0x68]
    3a9c:      	add	x2, x8, #0x4d8
    3aa0:      	blr	x9
    3aa4:      	mov	w8, #0x5f40             // =24384
    3aa8:      	mov	w9, #0x4                // =4
    3aac:      	mov	w1, #0x4                // =4
    3ab0:      	add	x0, x25, x8
    3ab4:      	ldr	x8, [sp, #0x70]
    3ab8:      	add	x8, x8, #0x58
    3abc:      	ldr	x8, [sp, #0x70]
    3ac0:      	add	x2, x8, #0x58
    3ac4:      	blr	x9
    3ac8:      	str	xzr, [sp, #0xc0]
    3acc:      	add	x2, x24, #0x938
    3ad0:      	add	x8, sp, #0xc0
    3ad4:      	add	x0, sp, #0xc0
    3ad8:      	mov	w1, #0x8                // =8
    3adc:      	blr	x21
    3ae0:      	ldr	x8, [sp, #0xc0]
    3ae4:      	cbz	x8, 0x3b6c <generic_fentry_process_filter+0x50c>
    3ae8:      	str	wzr, [sp, #0xb8]
    3aec:      	add	x8, x8, #0x4
    3af0:      	add	x9, sp, #0xb8
    3af4:      	mov	w10, #0x4               // =4
    3af8:      	add	x0, sp, #0xb8
    3afc:      	mov	w1, #0x4                // =4
    3b00:      	mov	w19, #0x4               // =4
    3b04:      	ldr	x8, [sp, #0xc0]
    3b08:      	add	x2, x8, #0x4
    3b0c:      	blr	x10
    3b10:      	ldr	x8, [sp, #0xc0]
    3b14:      	ldrsw	x9, [sp, #0xb8]
    3b18:      	add	x10, sp, #0xc8
    3b1c:      	mov	w11, #0x4               // =4
    3b20:      	add	x0, sp, #0xc8
    3b24:      	mov	w1, #0x10               // =16
    3b28:      	add	x8, x8, x9, lsl #4
    3b2c:      	mov	w9, #0x10               // =16
    3b30:      	add	x8, x8, #0x80
    3b34:      	ldr	x8, [sp, #0xc0]
    3b38:      	ldrsw	x9, [sp, #0xb8]
    3b3c:      	add	x8, x8, x9, lsl #4
    3b40:      	add	x2, x8, #0x80
    3b44:      	blr	x11
    3b48:      	mov	w8, #0x5f44             // =24388
    3b4c:      	mov	w1, #0x4                // =4
    3b50:      	add	x0, x25, x8
    3b54:      	ldr	x8, [sp, #0xd0]
    3b58:      	add	x8, x8, #0x158
    3b5c:      	ldr	x8, [sp, #0xd0]
    3b60:      	add	x2, x8, #0x158
    3b64:      	blr	x19
    3b68:      	b	0x3b70 <generic_fentry_process_filter+0x510>
    3b6c:      	str	wzr, [x29, #0x84]
    3b70:      	mov	w8, #0x5f48             // =24392
    3b74:      	mov	w9, #0x4                // =4
    3b78:      	mov	w1, #0x4                // =4
    3b7c:      	mov	w19, #0x4               // =4
    3b80:      	add	x0, x25, x8
    3b84:      	ldr	x8, [sp, #0x78]
    3b88:      	add	x8, x8, #0x158
    3b8c:      	ldr	x8, [sp, #0x78]
    3b90:      	add	x2, x8, #0x158
    3b94:      	blr	x9
    3b98:      	mov	w8, #0x5f4c             // =24396
    3b9c:      	mov	w9, #0x4                // =4
    3ba0:      	mov	w1, #0x4                // =4
    3ba4:      	add	x0, x25, x8
    3ba8:      	ldr	x8, [sp, #0x80]
    3bac:      	add	x8, x8, #0x118
    3bb0:      	ldr	x8, [sp, #0x80]
    3bb4:      	add	x2, x8, #0x118
    3bb8:      	blr	x9
    3bbc:      	mov	w8, #0x5f50             // =24400
    3bc0:      	mov	w9, #0x4                // =4
    3bc4:      	mov	w1, #0x4                // =4
    3bc8:      	add	x0, x25, x8
    3bcc:      	ldr	x8, [sp, #0x88]
    3bd0:      	add	x8, x8, #0x98
    3bd4:      	ldr	x8, [sp, #0x88]
    3bd8:      	add	x2, x8, #0x98
    3bdc:      	blr	x9
    3be0:      	mov	w8, #0x5f54             // =24404
    3be4:      	mov	w9, #0x4                // =4
    3be8:      	mov	w1, #0x4                // =4
    3bec:      	add	x0, x25, x8
    3bf0:      	ldr	x8, [sp, #0x90]
    3bf4:      	add	x8, x8, #0x98
    3bf8:      	ldr	x8, [sp, #0x90]
    3bfc:      	add	x2, x8, #0x98
    3c00:      	blr	x9
    3c04:      	mov	w8, #0x5f58             // =24408
    3c08:      	mov	w9, #0x4                // =4
    3c0c:      	mov	w1, #0x4                // =4
    3c10:      	add	x0, x25, x8
    3c14:      	ldr	x8, [sp, #0x98]
    3c18:      	add	x8, x8, #0x58
    3c1c:      	ldr	x8, [sp, #0x98]
    3c20:      	add	x2, x8, #0x58
    3c24:      	blr	x9
    3c28:      	stp	xzr, xzr, [sp, #0xc0]
    3c2c:      	mov	w20, #0x8               // =8
    3c30:      	add	x8, sp, #0xc8
    3c34:      	mov	w9, #0x4                // =4
    3c38:      	add	x0, sp, #0xc8
    3c3c:      	mov	w1, #0x8                // =8
    3c40:      	mov	x2, x23
    3c44:      	blr	x9
    3c48:      	ldr	x8, [sp, #0xc8]
    3c4c:      	add	x9, sp, #0xc0
    3c50:      	mov	w10, #0x4               // =4
    3c54:      	add	x0, sp, #0xc0
    3c58:      	mov	w1, #0x8                // =8
    3c5c:      	add	x8, x8, #0x90
    3c60:      	ldr	x8, [sp, #0xc8]
    3c64:      	add	x2, x8, #0x90
    3c68:      	blr	x10
    3c6c:      	mov	w8, #0x5f5c             // =24412
    3c70:      	mov	w1, #0x4                // =4
    3c74:      	add	x0, x25, x8
    3c78:      	ldr	x8, [sp, #0xc0]
    3c7c:      	add	x8, x8, #0x158
    3c80:      	ldr	x8, [sp, #0xc0]
    3c84:      	add	x2, x8, #0x158
    3c88:      	blr	x19
    3c8c:      	ldr	w8, [x29, #0x74]
    3c90:      	cmp	w8, #0x1
    3c94:      	b.ne	0x3ca4 <generic_fentry_process_filter+0x644>
    3c98:      	ldr	w8, [x29, #0x70]
    3c9c:      	orr	w8, w8, #0x2000000
    3ca0:      	str	w8, [x29, #0x70]
    3ca4:      	add	x0, x29, #0xb8
    3ca8:      	mov	w1, wzr
    3cac:      	mov	w2, #0x308              // =776
    3cb0:      	bl	0x3cb0 <generic_fentry_process_filter+0x650>
    3cb4:      	mov	w8, #0x6290             // =25232
    3cb8:      	add	x2, x24, #0x858
    3cbc:      	mov	w19, #0x8               // =8
    3cc0:      	mov	w9, #0x4                // =4
    3cc4:      	add	x0, sp, #0xc8
    3cc8:      	mov	w1, #0x8                // =8
    3ccc:      	mov	w20, #0x4               // =4
    3cd0:      	add	x21, x25, x8
    3cd4:      	add	x8, sp, #0xc8
    3cd8:      	blr	x9
    3cdc:      	ldr	x8, [sp, #0xc8]
    3ce0:      	add	x9, sp, #0x58
    3ce4:      	add	x0, sp, #0x58
    3ce8:      	mov	w1, #0x8                // =8
    3cec:      	add	x8, x8, #0x528
    3cf0:      	ldr	x8, [sp, #0xc8]
    3cf4:      	add	x2, x8, #0x528
    3cf8:      	blr	x20
    3cfc:      	str	wzr, [sp, #0xa4]
    3d00:      	adrp	x0, 0x3000 <generic_fentry_process_event+0x2c70>
    3d04:      	ldr	x19, [sp, #0x58]
    3d08:      	mov	w8, #0x1                // =1
    3d0c:      	add	x9, sp, #0xa4
    3d10:      	add	x1, sp, #0xa4
    3d14:      	ldr	x0, [x0]
    3d18:      	blr	x8
    3d1c:      	cbz	x0, 0x418c <generic_fentry_process_filter+0xb2c>
    3d20:      	mov	w8, #0x1000             // =4096
    3d24:      	stp	x21, x22, [sp, #0x30]
    3d28:      	mov	x24, x0
    3d2c:      	add	x20, x0, #0x1, lsl #12  // =0x1000
    3d30:      	str	x29, [sp, #0x40]
    3d34:      	str	w8, [x29, #0x550]
    3d38:      	mov	w8, #0x23               // =35
    3d3c:      	blr	x8
    3d40:      	add	x2, x0, #0xb30
    3d44:      	mov	w23, #0x8               // =8
    3d48:      	add	x8, sp, #0xa8
    3d4c:      	mov	w9, #0x4                // =4
    3d50:      	add	x0, sp, #0xa8
    3d54:      	mov	w1, #0x8                // =8
    3d58:      	mov	w29, #0x4               // =4
    3d5c:      	blr	x9
    3d60:      	ldr	x22, [sp, #0xa8]
    3d64:      	add	x25, x19, #0x48
    3d68:      	add	x8, sp, #0xb0
    3d6c:      	mov	w9, #0x4                // =4
    3d70:      	add	x0, sp, #0xb0
    3d74:      	mov	w1, #0x8                // =8
    3d78:      	mov	x2, x25
    3d7c:      	blr	x9
    3d80:      	ldr	x21, [sp, #0xb0]
    3d84:      	add	x8, sp, #0x58
    3d88:      	add	x0, sp, #0x58
    3d8c:      	mov	w1, #0x8                // =8
    3d90:      	add	x2, x21, #0x10
    3d94:      	blr	x29
    3d98:      	ldr	x8, [sp, #0x58]
    3d9c:      	cbz	x8, 0x4010 <generic_fentry_process_filter+0x9b0>
    3da0:      	ldr	x8, [sp, #0x40]
    3da4:      	stp	xzr, xzr, [sp, #0x58]
    3da8:      	add	x21, x22, #0x18
    3dac:      	add	x9, sp, #0x58
    3db0:      	add	x2, x22, #0x20
    3db4:      	mov	w22, #0x8               // =8
    3db8:      	stp	x24, xzr, [sp, #0x68]
    3dbc:      	add	x0, sp, #0x58
    3dc0:      	mov	w1, #0x8                // =8
    3dc4:      	add	x29, x19, #0x40
    3dc8:      	add	x19, x9, #0x8
    3dcc:      	add	x24, x9, #0x18
    3dd0:      	stp	xzr, xzr, [sp, #0x78]
    3dd4:      	add	x23, x9, #0x20
    3dd8:      	str	x20, [sp, #0x88]
    3ddc:      	str	x20, [sp, #0x28]
    3de0:      	mov	w20, #0x4               // =4
    3de4:      	ldr	w8, [x8, #0x550]
    3de8:      	strb	wzr, [sp, #0x94]
    3dec:      	str	w8, [sp, #0x90]
    3df0:      	mov	w8, #0x4                // =4
    3df4:      	blr	x8
    3df8:      	mov	w8, #0x4                // =4
    3dfc:      	mov	x0, x19
    3e00:      	mov	w1, #0x8                // =8
    3e04:      	mov	x2, x21
    3e08:      	blr	x8
    3e0c:      	mov	w8, #0x4                // =4
    3e10:      	mov	x0, x24
    3e14:      	mov	w1, #0x8                // =8
    3e18:      	mov	x2, x25
    3e1c:      	blr	x8
    3e20:      	mov	x0, x23
    3e24:      	mov	w1, #0x8                // =8
    3e28:      	mov	x2, x29
    3e2c:      	blr	x20
    3e30:      	ldr	x8, [sp, #0x78]
    3e34:      	mov	w19, #0x80              // =128
    3e38:      	add	x21, sp, #0xb8
    3e3c:      	add	x23, sp, #0xd8
    3e40:      	sub	x8, x8, #0x20
    3e44:      	str	x8, [sp, #0x80]
    3e48:      	b	0x3e54 <generic_fentry_process_filter+0x7f4>
    3e4c:      	subs	w19, w19, #0x1
    3e50:      	b.eq	0x3fc0 <generic_fentry_process_filter+0x960>
    3e54:      	ldp	x20, x2, [sp, #0x70]
    3e58:      	ldp	x8, x9, [sp, #0x58]
    3e5c:      	cmp	x20, x8
    3e60:      	ccmp	x2, x9, #0x0, eq
    3e64:      	b.eq	0x3fb8 <generic_fentry_process_filter+0x958>
    3e68:      	ldr	x29, [sp, #0x80]
    3e6c:      	mov	w8, #0x4                // =4
    3e70:      	add	x0, sp, #0xb8
    3e74:      	mov	w1, #0x8                // =8
    3e78:      	blr	x8
    3e7c:      	ldr	x8, [sp, #0xb8]
    3e80:      	cmp	x20, x8
    3e84:      	b.eq	0x3f6c <generic_fentry_process_filter+0x90c>
    3e88:      	add	x25, x20, #0x18
    3e8c:      	mov	w8, #0x4                // =4
    3e90:      	add	x0, sp, #0xd8
    3e94:      	mov	w1, #0x8                // =8
    3e98:      	mov	x2, x25
    3e9c:      	blr	x8
    3ea0:      	add	x8, sp, #0xd8
    3ea4:      	ldr	x8, [x8]
    3ea8:      	cmp	x8, x20
    3eac:      	b.eq	0x3f6c <generic_fentry_process_filter+0x90c>
    3eb0:      	mov	w8, #0x4                // =4
    3eb4:      	add	x9, sp, #0xc0
    3eb8:      	add	x0, sp, #0xc0
    3ebc:      	mov	w1, #0x8                // =8
    3ec0:      	mov	x2, x25
    3ec4:      	blr	x8
    3ec8:      	add	x2, x20, #0x20
    3ecc:      	mov	w8, #0x4                // =4
    3ed0:      	mov	w9, #0x10               // =16
    3ed4:      	add	x10, sp, #0xc8
    3ed8:      	add	x0, sp, #0xc8
    3edc:      	mov	w1, #0x10               // =16
    3ee0:      	blr	x8
    3ee4:      	ldr	w20, [sp, #0xcc]
    3ee8:      	ldr	x8, [sp, #0x68]
    3eec:      	ldr	x10, [sp, #0x88]
    3ef0:      	sub	x12, x10, x8
    3ef4:      	ldr	w25, [sp, #0x90]
    3ef8:      	subs	w10, w20, w25
    3efc:      	ldr	x9, [sp, #0xd0]
    3f00:      	csel	w10, wzr, w10, lo
    3f04:      	cmp	w25, w20
    3f08:      	csel	w11, w25, w20, lo
    3f0c:      	cinc	w13, w11, hi
    3f10:      	sub	w14, w25, w13
    3f14:      	subs	x12, x12, x13
    3f18:      	str	w14, [sp, #0x90]
    3f1c:      	b.lo	0x3fc0 <generic_fentry_process_filter+0x960>
    3f20:      	cmp	x12, #0xfff
    3f24:      	b.hi	0x3fc0 <generic_fentry_process_filter+0x960>
    3f28:      	cmp	w25, w20
    3f2c:      	b.ls	0x3f38 <generic_fentry_process_filter+0x8d8>
    3f30:      	mov	w13, #0x2f              // =47
    3f34:      	strb	w13, [x8, x12]
    3f38:      	add	x29, x8, x12
    3f3c:      	cmp	w25, w20
    3f40:      	add	x2, x9, x10
    3f44:      	and	w1, w11, #0xff
    3f48:      	mov	w8, #0x4                // =4
    3f4c:      	cinc	x0, x29, hi
    3f50:      	blr	x8
    3f54:      	cmp	w25, w20
    3f58:      	str	x29, [sp, #0x88]
    3f5c:      	b.ls	0x3fc0 <generic_fentry_process_filter+0x960>
    3f60:      	ldr	x8, [sp, #0xc0]
    3f64:      	str	x8, [sp, #0x70]
    3f68:      	b	0x3e4c <generic_fentry_process_filter+0x7ec>
    3f6c:      	add	x2, x29, #0x10
    3f70:      	mov	w8, #0x4                // =4
    3f74:      	add	x0, sp, #0xd8
    3f78:      	mov	w1, #0x8                // =8
    3f7c:      	blr	x8
    3f80:      	add	x20, sp, #0xd8
    3f84:      	ldr	x8, [sp, #0x80]
    3f88:      	ldr	x9, [x20]
    3f8c:      	cmp	x8, x9
    3f90:      	b.eq	0x3fb8 <generic_fentry_process_filter+0x958>
    3f94:      	add	x2, x29, #0x18
    3f98:      	mov	w8, #0x4                // =4
    3f9c:      	mov	x0, x24
    3fa0:      	mov	w1, #0x8                // =8
    3fa4:      	blr	x8
    3fa8:      	ldr	x8, [x20]
    3fac:      	add	x9, x8, #0x20
    3fb0:      	stp	x9, x8, [sp, #0x78]
    3fb4:      	b	0x3e4c <generic_fentry_process_filter+0x7ec>
    3fb8:      	mov	w8, #0x1                // =1
    3fbc:      	strb	w8, [sp, #0x94]
    3fc0:      	ldr	x24, [sp, #0x88]
    3fc4:      	ldr	x9, [sp, #0x28]
    3fc8:      	cmp	x24, x9
    3fcc:      	b.eq	0x4060 <generic_fentry_process_filter+0xa00>
    3fd0:      	ldrb	w8, [sp, #0x94]
    3fd4:      	ldp	x22, x29, [sp, #0x38]
    3fd8:      	cmp	w8, #0x0
    3fdc:      	ldr	x21, [sp, #0x30]
    3fe0:      	cset	w8, eq
    3fe4:      	lsl	w9, w8, #1
    3fe8:      	ldr	w8, [sp, #0x90]
    3fec:      	str	w9, [x29, #0x554]
    3ff0:      	cmp	w8, #0x1
    3ff4:      	str	w8, [x29, #0x550]
    3ff8:      	b.lt	0x4008 <generic_fentry_process_filter+0x9a8>
    3ffc:      	mov	w9, #0x1000             // =4096
    4000:      	sub	w8, w9, w8
    4004:      	str	w8, [x29, #0x550]
    4008:      	cbnz	x24, 0x4074 <generic_fentry_process_filter+0xa14>
    400c:      	b	0x418c <generic_fentry_process_filter+0xb2c>
    4010:      	add	x2, x21, #0x18
    4014:      	mov	w8, #0x8                // =8
    4018:      	mov	w9, #0x4                // =4
    401c:      	add	x10, sp, #0x58
    4020:      	add	x0, sp, #0x58
    4024:      	mov	w1, #0x8                // =8
    4028:      	blr	x9
    402c:      	ldr	x8, [sp, #0x58]
    4030:      	cmp	x8, x21
    4034:      	b.eq	0x3da0 <generic_fentry_process_filter+0x740>
    4038:      	ldr	x29, [sp, #0x40]
    403c:      	ldr	w9, [x29, #0x550]
    4040:      	sub	w8, w9, #0xa
    4044:      	cmp	w9, #0x9
    4048:      	str	w8, [x29, #0x550]
    404c:      	b.gt	0x4530 <generic_fentry_process_filter+0xed0>
    4050:      	mov	w9, #-0x24              // =-36
    4054:      	mov	x24, x20
    4058:      	str	w9, [x29, #0x554]
    405c:      	b	0x4070 <generic_fentry_process_filter+0xa10>
    4060:      	ldr	x29, [sp, #0x40]
    4064:      	mov	w8, wzr
    4068:      	mov	x24, x9
    406c:      	str	xzr, [x29, #0x550]
    4070:      	ldp	x21, x22, [sp, #0x30]
    4074:      	subs	w9, w8, #0x7f
    4078:      	mov	w10, #0x7f              // =127
    407c:      	mov	x11, x29
    4080:      	mov	x0, x21
    4084:      	mov	x2, x24
    4088:      	csel	w29, w8, w10, lo
    408c:      	csel	w19, wzr, w9, lo
    4090:      	cmp	w8, #0xff
    4094:      	mov	w9, #0xff               // =255
    4098:      	csel	w8, w8, w9, lo
    409c:      	and	w1, w8, #0xff
    40a0:      	str	w1, [x11, #0x550]
    40a4:      	mov	w8, #0x4                // =4
    40a8:      	blr	x8
    40ac:      	adrp	x25, 0x4000 <generic_fentry_process_filter+0x9a0>
    40b0:      	ldr	x25, [x25]
    40b4:      	cbz	x0, 0x4124 <generic_fentry_process_filter+0xac4>
    40b8:      	neg	w8, w0
    40bc:      	mov	w9, #0x1                // =1
    40c0:      	add	x1, sp, #0x58
    40c4:      	strh	w8, [sp, #0x58]
    40c8:      	mov	w8, #0x8                // =8
    40cc:      	mov	x0, x25
    40d0:      	mov	w20, #0x1               // =1
    40d4:      	strh	w8, [sp, #0x5a]
    40d8:      	mov	x8, #0x2de              // =734
    40dc:      	movk	x8, #0x4, lsl #32
    40e0:      	stur	x8, [sp, #0x5c]
    40e4:      	add	x8, sp, #0x58
    40e8:      	blr	x9
    40ec:      	cbz	x0, 0x4100 <generic_fentry_process_filter+0xaa0>
    40f0:      	ldr	w8, [x0]
    40f4:      	add	w8, w8, #0x1
    40f8:      	str	w8, [x0]
    40fc:      	b	0x4124 <generic_fentry_process_filter+0xac4>
    4100:      	str	w20, [sp, #0xc8]
    4104:      	mov	x3, xzr
    4108:      	mov	w8, #0x2                // =2
    410c:      	add	x9, sp, #0x58
    4110:      	add	x10, sp, #0xc8
    4114:      	add	x1, sp, #0x58
    4118:      	add	x2, sp, #0xc8
    411c:      	mov	x0, x25
    4120:      	blr	x8
    4124:      	ldr	x9, [sp, #0xe8]
    4128:      	mov	w8, #0x6390             // =25488
    412c:      	add	x2, x24, x19
    4130:      	mov	w1, w29
    4134:      	add	x0, x9, x8
    4138:      	mov	w8, #0x4                // =4
    413c:      	blr	x8
    4140:      	ldr	x29, [sp, #0x40]
    4144:      	cbz	x0, 0x418c <generic_fentry_process_filter+0xb2c>
    4148:      	neg	w8, w0
    414c:      	mov	w9, #0x1                // =1
    4150:      	add	x1, sp, #0x58
    4154:      	strh	w8, [sp, #0x58]
    4158:      	mov	w8, #0x8                // =8
    415c:      	mov	x0, x25
    4160:      	mov	w19, #0x1               // =1
    4164:      	strh	w8, [sp, #0x5a]
    4168:      	mov	x8, #0x2e0              // =736
    416c:      	movk	x8, #0x4, lsl #32
    4170:      	stur	x8, [sp, #0x5c]
    4174:      	add	x8, sp, #0x58
    4178:      	blr	x9
    417c:      	cbz	x0, 0x41b0 <generic_fentry_process_filter+0xb50>
    4180:      	ldr	w8, [x0]
    4184:      	add	w8, w8, #0x1
    4188:      	str	w8, [x0]
    418c:      	ldr	w8, [x29, #0x550]
    4190:      	sub	w9, w8, #0x101
    4194:      	cmn	w9, #0x101
    4198:      	b.hi	0x41e4 <generic_fentry_process_filter+0xb84>
    419c:      	ldr	x20, [sp, #0xe8]
    41a0:      	ldr	x24, [sp, #0x48]
    41a4:      	mov	w8, #-0x1               // =-1
    41a8:      	stur	w8, [x29, #0xb8]
    41ac:      	b	0x4330 <generic_fentry_process_filter+0xcd0>
    41b0:      	str	w19, [sp, #0xc8]
    41b4:      	mov	x3, xzr
    41b8:      	mov	w8, #0x2                // =2
    41bc:      	add	x9, sp, #0x58
    41c0:      	add	x10, sp, #0xc8
    41c4:      	add	x1, sp, #0x58
    41c8:      	add	x2, sp, #0xc8
    41cc:      	mov	x0, x25
    41d0:      	blr	x8
    41d4:      	ldr	w8, [x29, #0x550]
    41d8:      	sub	w9, w8, #0x101
    41dc:      	cmn	w9, #0x101
    41e0:      	b.ls	0x419c <generic_fentry_process_filter+0xb3c>
    41e4:      	ldr	x20, [sp, #0xe8]
    41e8:      	and	x24, x8, #0xff
    41ec:      	mov	w8, #0x5f80             // =24448
    41f0:      	mov	x2, x21
    41f4:      	mov	w1, w24
    41f8:      	add	x0, x20, x8
    41fc:      	mov	w8, #0x4                // =4
    4200:      	blr	x8
    4204:      	mov	x23, x0
    4208:      	cbz	x0, 0x4284 <generic_fentry_process_filter+0xc24>
    420c:      	neg	w8, w23
    4210:      	adrp	x25, 0x4000 <generic_fentry_process_filter+0x9a0>
    4214:      	mov	w9, #0x1                // =1
    4218:      	strh	w8, [sp, #0x58]
    421c:      	mov	w8, #0xf                // =15
    4220:      	add	x1, sp, #0x58
    4224:      	mov	w19, #0x1               // =1
    4228:      	strh	w8, [sp, #0x5a]
    422c:      	mov	x8, #0x164              // =356
    4230:      	movk	x8, #0x4, lsl #32
    4234:      	stur	x8, [sp, #0x5c]
    4238:      	add	x8, sp, #0x58
    423c:      	ldr	x25, [x25]
    4240:      	mov	x0, x25
    4244:      	blr	x9
    4248:      	cbz	x0, 0x425c <generic_fentry_process_filter+0xbfc>
    424c:      	ldr	w8, [x0]
    4250:      	add	w8, w8, #0x1
    4254:      	str	w8, [x0]
    4258:      	b	0x4280 <generic_fentry_process_filter+0xc20>
    425c:      	str	w19, [sp, #0xc8]
    4260:      	mov	x3, xzr
    4264:      	mov	w8, #0x2                // =2
    4268:      	add	x9, sp, #0x58
    426c:      	add	x10, sp, #0xc8
    4270:      	add	x1, sp, #0x58
    4274:      	add	x2, sp, #0xc8
    4278:      	mov	x0, x25
    427c:      	blr	x8
    4280:      	ldr	x20, [sp, #0xe8]
    4284:      	cmp	w23, #0x0
    4288:      	csel	w8, w24, w23, eq
    428c:      	cmp	w24, #0x7f
    4290:      	stur	w8, [x29, #0xb8]
    4294:      	mov	w8, #0x7f               // =127
    4298:      	csel	w1, w24, w8, lo
    429c:      	mov	w8, #0x6080             // =24704
    42a0:      	add	x0, x20, x8
    42a4:      	mov	w8, #0x6390             // =25488
    42a8:      	add	x2, x20, x8
    42ac:      	mov	w8, #0x4                // =4
    42b0:      	blr	x8
    42b4:      	ldr	x24, [sp, #0x48]
    42b8:      	cbz	x0, 0x4330 <generic_fentry_process_filter+0xcd0>
    42bc:      	neg	w8, w0
    42c0:      	adrp	x23, 0x4000 <generic_fentry_process_filter+0x9a0>
    42c4:      	mov	w9, #0x1                // =1
    42c8:      	strh	w8, [sp, #0x58]
    42cc:      	mov	w8, #0xf                // =15
    42d0:      	add	x1, sp, #0x58
    42d4:      	mov	w19, #0x1               // =1
    42d8:      	strh	w8, [sp, #0x5a]
    42dc:      	mov	x8, #0x16a              // =362
    42e0:      	movk	x8, #0x4, lsl #32
    42e4:      	stur	x8, [sp, #0x5c]
    42e8:      	add	x8, sp, #0x58
    42ec:      	ldr	x23, [x23]
    42f0:      	mov	x0, x23
    42f4:      	blr	x9
    42f8:      	cbz	x0, 0x430c <generic_fentry_process_filter+0xcac>
    42fc:      	ldr	w8, [x0]
    4300:      	add	w8, w8, #0x1
    4304:      	str	w8, [x0]
    4308:      	b	0x4330 <generic_fentry_process_filter+0xcd0>
    430c:      	str	w19, [sp, #0xc8]
    4310:      	mov	x3, xzr
    4314:      	mov	w8, #0x2                // =2
    4318:      	add	x9, sp, #0x58
    431c:      	add	x10, sp, #0xc8
    4320:      	add	x1, sp, #0x58
    4324:      	add	x2, sp, #0xc8
    4328:      	mov	x0, x23
    432c:      	blr	x8
    4330:      	ldrb	w8, [x20, #0x1]
    4334:      	orr	w8, w8, #0x10
    4338:      	strb	w8, [x20, #0x1]
    433c:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4340:      	mov	w8, #0x5ef8             // =24312
    4344:      	ldr	x0, [x0]
    4348:      	add	x1, x20, x8
    434c:      	mov	w8, #0x1                // =1
    4350:      	blr	x8
    4354:      	cbz	x0, 0x5534 <generic_fentry_process_filter+0x1ed4>
    4358:      	ldr	x21, [x20, #0x5eb8]
    435c:      	cmp	x21, #0x6
    4360:      	b.hs	0x44f8 <generic_fentry_process_filter+0xe98>
    4364:      	ldrsw	x8, [x0]
    4368:      	mov	x23, x0
    436c:      	cbz	w8, 0x4514 <generic_fentry_process_filter+0xeb4>
    4370:      	cmp	x21, x8
    4374:      	b.hs	0x44f8 <generic_fentry_process_filter+0xe98>
    4378:      	str	x8, [sp, #0x28]
    437c:      	stp	x29, x24, [sp, #0x40]
    4380:      	adrp	x24, 0x4000 <generic_fentry_process_filter+0x9a0>
    4384:      	mov	w8, #0x1                // =1
    4388:      	add	x9, sp, #0x58
    438c:      	str	x20, [sp, #0xe8]
    4390:      	add	x1, sp, #0x58
    4394:      	str	x22, [sp, #0x38]
    4398:      	str	w21, [sp, #0x58]
    439c:      	str	wzr, [sp, #0xc8]
    43a0:      	ldr	x24, [x24]
    43a4:      	mov	x0, x24
    43a8:      	blr	x8
    43ac:      	cbz	x0, 0x4660 <generic_fentry_process_filter+0x1000>
    43b0:      	ldr	w8, [x0]
    43b4:      	mov	x25, x0
    43b8:      	cbz	w8, 0x4660 <generic_fentry_process_filter+0x1000>
    43bc:      	ldr	x9, [sp, #0x48]
    43c0:      	ldr	w9, [x9, #0x68]
    43c4:      	tbnz	w9, #0x1f, 0x54dc <generic_fentry_process_filter+0x1e7c>
    43c8:      	cmp	w8, #0x1b
    43cc:      	b.hi	0x54dc <generic_fentry_process_filter+0x1e7c>
    43d0:      	mov	w9, #0x1                // =1
    43d4:      	lsl	w9, w9, w8
    43d8:      	tst	w9, #0x60
    43dc:      	b.ne	0x45d4 <generic_fentry_process_filter+0xf74>
    43e0:      	mov	w10, #0x100             // =256
    43e4:      	movk	w10, #0x400, lsl #16
    43e8:      	tst	w9, w10
    43ec:      	b.ne	0x4550 <generic_fentry_process_filter+0xef0>
    43f0:      	mov	w9, #0x1                // =1
    43f4:      	lsl	w8, w9, w8
    43f8:      	mov	w9, #0x200              // =512
    43fc:      	movk	w9, #0x800, lsl #16
    4400:      	tst	w8, w9
    4404:      	b.eq	0x54dc <generic_fentry_process_filter+0x1e7c>
    4408:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    440c:      	add	x1, x25, #0x4
    4410:      	mov	w8, #0x1                // =1
    4414:      	ldr	x0, [x0]
    4418:      	blr	x8
    441c:      	cbz	x0, 0x54dc <generic_fentry_process_filter+0x1e7c>
    4420:      	ldr	x8, [sp, #0x48]
    4424:      	mov	x20, x0
    4428:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    442c:      	mov	w9, #0x7f               // =127
    4430:      	ldr	w8, [x8, #0x68]
    4434:      	ldr	x0, [x0]
    4438:      	add	x1, sp, #0xc8
    443c:      	cmp	w8, #0x7f
    4440:      	csel	w19, w8, w9, lt
    4444:      	mov	w8, #0x1                // =1
    4448:      	add	x9, sp, #0xc8
    444c:      	blr	x8
    4450:      	cbz	x0, 0x54dc <generic_fentry_process_filter+0x1e7c>
    4454:      	sxtw	x1, w19
    4458:      	mov	x29, x0
    445c:      	lsl	w8, w1, #3
    4460:      	str	w8, [x0]
    4464:      	ldr	x8, [sp, #0x48]
    4468:      	ldr	w8, [x8, #0x6c]
    446c:      	cbnz	w8, 0x44cc <generic_fentry_process_filter+0xe6c>
    4470:      	ldr	x11, [sp, #0x48]
    4474:      	and	w13, w1, #0x7f
    4478:      	mov	x8, xzr
    447c:      	ldr	w12, [x11, #0x68]
    4480:      	add	x9, x11, #0x1f0
    4484:      	add	x10, x11, #0x170
    4488:      	sub	w11, w12, w1
    448c:      	add	w12, w12, w13
    4490:      	add	w11, w11, w13
    4494:      	mvn	w13, w1
    4498:      	add	w12, w13, w12
    449c:      	cmp	x8, #0x7f
    44a0:      	b.eq	0x44c0 <generic_fentry_process_filter+0xe60>
    44a4:      	and	x13, x12, #0x7f
    44a8:      	sub	w12, w12, #0x1
    44ac:      	ldrb	w13, [x10, x13]
    44b0:      	strb	w13, [x9, x8]
    44b4:      	add	x8, x8, #0x1
    44b8:      	cmp	x11, x8
    44bc:      	b.ne	0x449c <generic_fentry_process_filter+0xe3c>
    44c0:      	ldr	x9, [sp, #0x48]
    44c4:      	mov	w8, #0x1                // =1
    44c8:      	str	w8, [x9, #0x6c]
    44cc:      	cmp	w1, #0x7f
    44d0:      	b.hi	0x44ec <generic_fentry_process_filter+0xe8c>
    44d4:      	ldr	x8, [sp, #0x48]
    44d8:      	add	x0, x29, #0x4
    44dc:      	add	x2, x8, #0x1f0
    44e0:      	mov	w8, #0x4                // =4
    44e4:      	blr	x8
    44e8:      	tbnz	x0, #0x3f, 0x54dc <generic_fentry_process_filter+0x1e7c>
    44ec:      	mov	w8, #0x1                // =1
    44f0:      	mov	x0, x20
    44f4:      	b	0x45cc <generic_fentry_process_filter+0xf6c>
    44f8:      	ldr	w8, [x24]
    44fc:      	str	w8, [x20, #0x10]
    4500:      	ldr	x8, [x24, #0x8]
    4504:      	str	x8, [x20, #0x18]
    4508:      	ldrb	w8, [x29]
    450c:      	cbnz	w8, 0x5518 <generic_fentry_process_filter+0x1eb8>
    4510:      	b	0x5534 <generic_fentry_process_filter+0x1ed4>
    4514:      	mov	w8, #0x1                // =1
    4518:      	strb	w8, [x29]
    451c:      	ldr	w8, [x24]
    4520:      	str	w8, [x20, #0x10]
    4524:      	ldr	x8, [x24, #0x8]
    4528:      	str	x8, [x20, #0x18]
    452c:      	b	0x5518 <generic_fentry_process_filter+0x1eb8>
    4530:      	mov	w8, #0x2964             // =10596
    4534:      	add	x20, x24, #0xff6
    4538:      	strh	w8, [x24, #0xffe]
    453c:      	adrp	x8, 0x4000 <generic_fentry_process_filter+0x9a0>
    4540:      	add	x8, x8, #0x0
    4544:      	ldr	x8, [x8]
    4548:      	str	x8, [x20]
    454c:      	b	0x3da0 <generic_fentry_process_filter+0x740>
    4550:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4554:      	add	x1, x25, #0x4
    4558:      	mov	w8, #0x1                // =1
    455c:      	ldr	x0, [x0]
    4560:      	blr	x8
    4564:      	cbz	x0, 0x54dc <generic_fentry_process_filter+0x1e7c>
    4568:      	mov	x19, x0
    456c:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4570:      	mov	w8, #0x1                // =1
    4574:      	ldr	x0, [x0]
    4578:      	add	x9, sp, #0xc8
    457c:      	add	x1, sp, #0xc8
    4580:      	blr	x8
    4584:      	cbz	x0, 0x54dc <generic_fentry_process_filter+0x1e7c>
    4588:      	mov	w1, wzr
    458c:      	mov	w2, #0x104              // =260
    4590:      	mov	x29, x0
    4594:      	bl	0x4594 <generic_fentry_process_filter+0xf34>
    4598:      	ldr	x10, [sp, #0x48]
    459c:      	mov	x0, x29
    45a0:      	ldr	w8, [x10, #0x68]
    45a4:      	add	x2, x10, #0x70
    45a8:      	lsl	w9, w8, #3
    45ac:      	and	x8, x8, #0xff
    45b0:      	str	w9, [x0], #0x4
    45b4:      	mov	w9, #0x4                // =4
    45b8:      	ldrb	w1, [x10, #0x68]
    45bc:      	blr	x9
    45c0:      	tbnz	x0, #0x3f, 0x54dc <generic_fentry_process_filter+0x1e7c>
    45c4:      	mov	w8, #0x1                // =1
    45c8:      	mov	x0, x19
    45cc:      	mov	x1, x29
    45d0:      	b	0x4628 <generic_fentry_process_filter+0xfc8>
    45d4:      	ldr	w8, [x25, #0x8]
    45d8:      	cmn	w8, #0x1
    45dc:      	b.eq	0x4600 <generic_fentry_process_filter+0xfa0>
    45e0:      	ldr	x9, [sp, #0x48]
    45e4:      	ldr	x9, [x9, #0x370]
    45e8:      	lsr	x8, x9, x8
    45ec:      	tbz	w8, #0x0, 0x4600 <generic_fentry_process_filter+0xfa0>
    45f0:      	mov	x0, #0xffee             // =65518
    45f4:      	movk	x0, #0xadc0, lsl #16
    45f8:      	movk	x0, #0xb, lsl #32
    45fc:      	b	0x462c <generic_fentry_process_filter+0xfcc>
    4600:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4604:      	mov	w8, #0x1                // =1
    4608:      	add	x9, sp, #0x58
    460c:      	ldr	x0, [x0]
    4610:      	add	x1, sp, #0x58
    4614:      	blr	x8
    4618:      	cbz	x0, 0x54dc <generic_fentry_process_filter+0x1e7c>
    461c:      	ldr	x8, [sp, #0x48]
    4620:      	add	x1, x8, #0x70
    4624:      	mov	w8, #0x1                // =1
    4628:      	blr	x8
    462c:      	ldr	w8, [x25]
    4630:      	cmp	w8, #0x25
    4634:      	b.hi	0x465c <generic_fentry_process_filter+0xffc>
    4638:      	mov	w9, #0x1                // =1
    463c:      	lsl	x8, x9, x8
    4640:      	mov	x9, #0x50               // =80
    4644:      	movk	x9, #0xc00, lsl #16
    4648:      	movk	x9, #0x20, lsl #32
    464c:      	tst	x8, x9
    4650:      	b.eq	0x465c <generic_fentry_process_filter+0xffc>
    4654:      	cbnz	x0, 0x54dc <generic_fentry_process_filter+0x1e7c>
    4658:      	b	0x4660 <generic_fentry_process_filter+0x1000>
    465c:      	cbz	x0, 0x54dc <generic_fentry_process_filter+0x1e7c>
    4660:      	adrp	x8, 0x4000 <generic_fentry_process_filter+0x9a0>
    4664:      	ldr	x8, [x8]
    4668:      	ldrb	w8, [x8]
    466c:      	cbz	w8, 0x48e4 <generic_fentry_process_filter+0x1284>
    4670:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4674:      	mov	w8, #0x1                // =1
    4678:      	ldr	x0, [x0]
    467c:      	ldr	x1, [sp, #0x48]
    4680:      	blr	x8
    4684:      	cbz	x0, 0x48e4 <generic_fentry_process_filter+0x1284>
    4688:      	add	w8, w21, #0x5
    468c:      	str	wzr, [sp, #0xc8]
    4690:      	add	x9, sp, #0x58
    4694:      	mov	x25, x0
    4698:      	str	w8, [sp, #0x58]
    469c:      	mov	w8, #0x1                // =1
    46a0:      	add	x1, sp, #0x58
    46a4:      	mov	x0, x24
    46a8:      	blr	x8
    46ac:      	cbz	x0, 0x48e4 <generic_fentry_process_filter+0x1284>
    46b0:      	ldr	w8, [x0]
    46b4:      	mov	x24, x0
    46b8:      	cbz	w8, 0x48e4 <generic_fentry_process_filter+0x1284>
    46bc:      	ldr	w9, [x25]
    46c0:      	tbnz	w9, #0x1f, 0x54dc <generic_fentry_process_filter+0x1e7c>
    46c4:      	cmp	w8, #0x1b
    46c8:      	b.hi	0x54dc <generic_fentry_process_filter+0x1e7c>
    46cc:      	mov	w9, #0x1                // =1
    46d0:      	lsl	w9, w9, w8
    46d4:      	tst	w9, #0x60
    46d8:      	b.ne	0x4860 <generic_fentry_process_filter+0x1200>
    46dc:      	mov	w10, #0x100             // =256
    46e0:      	movk	w10, #0x400, lsl #16
    46e4:      	tst	w9, w10
    46e8:      	b.ne	0x47e0 <generic_fentry_process_filter+0x1180>
    46ec:      	mov	w9, #0x1                // =1
    46f0:      	lsl	w8, w9, w8
    46f4:      	mov	w9, #0x200              // =512
    46f8:      	movk	w9, #0x800, lsl #16
    46fc:      	tst	w8, w9
    4700:      	b.eq	0x54dc <generic_fentry_process_filter+0x1e7c>
    4704:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4708:      	add	x1, x24, #0x4
    470c:      	mov	w8, #0x1                // =1
    4710:      	ldr	x0, [x0]
    4714:      	blr	x8
    4718:      	cbz	x0, 0x54dc <generic_fentry_process_filter+0x1e7c>
    471c:      	ldr	w8, [x25]
    4720:      	mov	x20, x0
    4724:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4728:      	mov	w9, #0x7f               // =127
    472c:      	ldr	x0, [x0]
    4730:      	add	x1, sp, #0xc8
    4734:      	cmp	w8, #0x7f
    4738:      	csel	w19, w8, w9, lt
    473c:      	mov	w8, #0x1                // =1
    4740:      	add	x9, sp, #0xc8
    4744:      	blr	x8
    4748:      	cbz	x0, 0x54dc <generic_fentry_process_filter+0x1e7c>
    474c:      	sxtw	x1, w19
    4750:      	mov	x29, x0
    4754:      	lsl	w8, w1, #3
    4758:      	str	w8, [x0]
    475c:      	ldr	w8, [x25, #0x4]
    4760:      	cbnz	w8, 0x47b8 <generic_fentry_process_filter+0x1158>
    4764:      	ldr	w12, [x25]
    4768:      	and	w13, w1, #0x7f
    476c:      	mov	x8, xzr
    4770:      	add	x9, x25, #0x188
    4774:      	add	x10, x25, #0x108
    4778:      	sub	w11, w12, w1
    477c:      	add	w12, w12, w13
    4780:      	add	w11, w11, w13
    4784:      	mvn	w13, w1
    4788:      	add	w12, w13, w12
    478c:      	cmp	x8, #0x7f
    4790:      	b.eq	0x47b0 <generic_fentry_process_filter+0x1150>
    4794:      	and	x13, x12, #0x7f
    4798:      	sub	w12, w12, #0x1
    479c:      	ldrb	w13, [x10, x13]
    47a0:      	strb	w13, [x9, x8]
    47a4:      	add	x8, x8, #0x1
    47a8:      	cmp	x11, x8
    47ac:      	b.ne	0x478c <generic_fentry_process_filter+0x112c>
    47b0:      	mov	w8, #0x1                // =1
    47b4:      	str	w8, [x25, #0x4]
    47b8:      	cmp	w1, #0x7f
    47bc:      	b.hi	0x47d4 <generic_fentry_process_filter+0x1174>
    47c0:      	add	x0, x29, #0x4
    47c4:      	add	x2, x25, #0x188
    47c8:      	mov	w8, #0x4                // =4
    47cc:      	blr	x8
    47d0:      	tbnz	x0, #0x3f, 0x54dc <generic_fentry_process_filter+0x1e7c>
    47d4:      	mov	w8, #0x1                // =1
    47d8:      	mov	x0, x20
    47dc:      	b	0x4858 <generic_fentry_process_filter+0x11f8>
    47e0:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    47e4:      	add	x1, x24, #0x4
    47e8:      	mov	w8, #0x1                // =1
    47ec:      	ldr	x0, [x0]
    47f0:      	blr	x8
    47f4:      	cbz	x0, 0x54dc <generic_fentry_process_filter+0x1e7c>
    47f8:      	mov	x19, x0
    47fc:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4800:      	mov	w8, #0x1                // =1
    4804:      	ldr	x0, [x0]
    4808:      	add	x9, sp, #0xc8
    480c:      	add	x1, sp, #0xc8
    4810:      	blr	x8
    4814:      	cbz	x0, 0x54dc <generic_fentry_process_filter+0x1e7c>
    4818:      	mov	w1, wzr
    481c:      	mov	w2, #0x104              // =260
    4820:      	mov	x29, x0
    4824:      	bl	0x4824 <generic_fentry_process_filter+0x11c4>
    4828:      	ldr	w8, [x25]
    482c:      	mov	x0, x29
    4830:      	add	x2, x25, #0x8
    4834:      	lsl	w9, w8, #3
    4838:      	and	x8, x8, #0xff
    483c:      	str	w9, [x0], #0x4
    4840:      	mov	w9, #0x4                // =4
    4844:      	ldrb	w1, [x25]
    4848:      	blr	x9
    484c:      	tbnz	x0, #0x3f, 0x54dc <generic_fentry_process_filter+0x1e7c>
    4850:      	mov	w8, #0x1                // =1
    4854:      	mov	x0, x19
    4858:      	mov	x1, x29
    485c:      	b	0x48ac <generic_fentry_process_filter+0x124c>
    4860:      	ldr	w8, [x24, #0x8]
    4864:      	cmn	w8, #0x1
    4868:      	b.eq	0x4888 <generic_fentry_process_filter+0x1228>
    486c:      	ldr	x9, [x25, #0x308]
    4870:      	lsr	x8, x9, x8
    4874:      	tbz	w8, #0x0, 0x4888 <generic_fentry_process_filter+0x1228>
    4878:      	mov	x0, #0xffee             // =65518
    487c:      	movk	x0, #0xadc0, lsl #16
    4880:      	movk	x0, #0xb, lsl #32
    4884:      	b	0x48b0 <generic_fentry_process_filter+0x1250>
    4888:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    488c:      	mov	w8, #0x1                // =1
    4890:      	add	x9, sp, #0x58
    4894:      	ldr	x0, [x0]
    4898:      	add	x1, sp, #0x58
    489c:      	blr	x8
    48a0:      	cbz	x0, 0x54dc <generic_fentry_process_filter+0x1e7c>
    48a4:      	add	x1, x25, #0x8
    48a8:      	mov	w8, #0x1                // =1
    48ac:      	blr	x8
    48b0:      	ldr	w8, [x24]
    48b4:      	cmp	w8, #0x25
    48b8:      	b.hi	0x48e0 <generic_fentry_process_filter+0x1280>
    48bc:      	mov	w9, #0x1                // =1
    48c0:      	lsl	x8, x9, x8
    48c4:      	mov	x9, #0x50               // =80
    48c8:      	movk	x9, #0xc00, lsl #16
    48cc:      	movk	x9, #0x20, lsl #32
    48d0:      	tst	x8, x9
    48d4:      	b.eq	0x48e0 <generic_fentry_process_filter+0x1280>
    48d8:      	cbnz	x0, 0x54dc <generic_fentry_process_filter+0x1e7c>
    48dc:      	b	0x48e4 <generic_fentry_process_filter+0x1284>
    48e0:      	cbz	x0, 0x54dc <generic_fentry_process_filter+0x1e7c>
    48e4:      	lsl	w8, w21, #2
    48e8:      	add	x9, x8, #0x4
    48ec:      	ldr	w8, [x9, x23]
    48f0:      	add	w9, w8, w9
    48f4:      	and	w11, w9, #0x3ff
    48f8:      	add	w9, w9, #0x4
    48fc:      	and	x9, x9, #0x3ff
    4900:      	add	x10, x11, #0x8
    4904:      	ldr	w9, [x9, x23]
    4908:      	cmp	w9, #0x5
    490c:      	b.lo	0x499c <generic_fentry_process_filter+0x133c>
    4910:      	add	x9, x10, x23
    4914:      	ldr	w10, [x9, #0x8]
    4918:      	ldp	w12, w22, [x9]
    491c:      	stp	x9, x11, [sp, #0x8]
    4920:      	mov	w9, #0x4                // =4
    4924:      	cmp	w10, #0x4
    4928:      	stp	xzr, xzr, [sp, #0x58]
    492c:      	csel	w9, w10, w9, lo
    4930:      	cmp	w12, #0x6
    4934:      	b.ne	0x4940 <generic_fentry_process_filter+0x12e0>
    4938:      	mov	x11, #0x100000001       // =4294967297
    493c:      	stp	x11, x11, [sp, #0x58]
    4940:      	cbz	w10, 0x4da4 <generic_fentry_process_filter+0x1744>
    4944:      	ldr	x10, [sp, #0x48]
    4948:      	add	w8, w8, w21, lsl #2
    494c:      	tst	x22, #0x1
    4950:      	add	x25, sp, #0x58
    4954:      	str	w12, [sp, #0x30]
    4958:      	add	w8, w8, #0x4
    495c:      	and	x8, x8, #0x3ff
    4960:      	add	x21, x8, #0x14
    4964:      	sub	x8, x9, #0x1
    4968:      	mov	w9, #0x3                // =3
    496c:      	add	x11, x10, #0x24
    4970:      	str	x11, [sp, #0x20]
    4974:      	csel	x11, x10, x11, eq
    4978:      	cmp	x8, #0x3
    497c:      	add	x10, x10, #0x10
    4980:      	csel	x8, x8, x9, lo
    4984:      	and	x9, x21, #0x7fc
    4988:      	mov	x20, x11
    498c:      	str	x10, [sp, #0x18]
    4990:      	add	x24, x23, x9
    4994:      	add	x19, x8, #0x1
    4998:      	b	0x49d4 <generic_fentry_process_filter+0x1374>
    499c:      	mov	w9, #0x1                // =1
    49a0:      	mov	w8, w10
    49a4:      	b	0x4dec <generic_fentry_process_filter+0x178c>
    49a8:      	mov	w8, #0x1                // =1
    49ac:      	ldr	w12, [sp, #0x30]
    49b0:      	mov	x11, x20
    49b4:      	cmp	w12, #0x6
    49b8:      	eor	w8, w8, #0x1
    49bc:      	csinc	w9, w8, wzr, eq
    49c0:      	str	w9, [x25], #0x4
    49c4:      	add	x21, x21, #0x4
    49c8:      	add	x24, x24, #0x4
    49cc:      	subs	x19, x19, #0x1
    49d0:      	b.eq	0x4da4 <generic_fentry_process_filter+0x1744>
    49d4:      	cmp	x21, #0x3e8
    49d8:      	b.ls	0x4bfc <generic_fentry_process_filter+0x159c>
    49dc:      	mov	x29, xzr
    49e0:      	tbz	w22, #0x1, 0x4c04 <generic_fentry_process_filter+0x15a4>
    49e4:      	tbnz	w22, #0x0, 0x4c30 <generic_fentry_process_filter+0x15d0>
    49e8:      	ldr	x10, [sp, #0x48]
    49ec:      	mov	w8, #0x1                // =1
    49f0:      	ldr	w9, [x10]
    49f4:      	cmp	x29, x9
    49f8:      	b.eq	0x49b4 <generic_fentry_process_filter+0x1354>
    49fc:      	ldr	w9, [x10, #0x10]
    4a00:      	cmp	x29, x9
    4a04:      	b.eq	0x49b4 <generic_fentry_process_filter+0x1354>
    4a08:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4a0c:      	mov	w8, #0x1                // =1
    4a10:      	ldr	x0, [x0]
    4a14:      	ldr	x1, [sp, #0x18]
    4a18:      	blr	x8
    4a1c:      	cbz	x0, 0x4d88 <generic_fentry_process_filter+0x1728>
    4a20:      	ldr	w9, [x0]
    4a24:      	mov	x1, x0
    4a28:      	mov	w8, #0x1                // =1
    4a2c:      	cmp	x29, x9
    4a30:      	b.eq	0x49ac <generic_fentry_process_filter+0x134c>
    4a34:      	ldr	w9, [x1, #0x10]!
    4a38:      	ldr	w12, [sp, #0x30]
    4a3c:      	mov	x11, x20
    4a40:      	cmp	x29, x9
    4a44:      	b.eq	0x49b4 <generic_fentry_process_filter+0x1354>
    4a48:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4a4c:      	mov	w8, #0x1                // =1
    4a50:      	ldr	x0, [x0]
    4a54:      	blr	x8
    4a58:      	cbz	x0, 0x4d88 <generic_fentry_process_filter+0x1728>
    4a5c:      	ldr	w9, [x0]
    4a60:      	mov	x1, x0
    4a64:      	mov	w8, #0x1                // =1
    4a68:      	cmp	x29, x9
    4a6c:      	b.eq	0x49ac <generic_fentry_process_filter+0x134c>
    4a70:      	ldr	w9, [x1, #0x10]!
    4a74:      	ldr	w12, [sp, #0x30]
    4a78:      	mov	x11, x20
    4a7c:      	cmp	x29, x9
    4a80:      	b.eq	0x49b4 <generic_fentry_process_filter+0x1354>
    4a84:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4a88:      	mov	w8, #0x1                // =1
    4a8c:      	ldr	x0, [x0]
    4a90:      	blr	x8
    4a94:      	cbz	x0, 0x4d88 <generic_fentry_process_filter+0x1728>
    4a98:      	ldr	w9, [x0]
    4a9c:      	mov	x1, x0
    4aa0:      	mov	w8, #0x1                // =1
    4aa4:      	cmp	x29, x9
    4aa8:      	b.eq	0x49ac <generic_fentry_process_filter+0x134c>
    4aac:      	ldr	w9, [x1, #0x10]!
    4ab0:      	ldr	w12, [sp, #0x30]
    4ab4:      	mov	x11, x20
    4ab8:      	cmp	x29, x9
    4abc:      	b.eq	0x49b4 <generic_fentry_process_filter+0x1354>
    4ac0:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4ac4:      	mov	w8, #0x1                // =1
    4ac8:      	ldr	x0, [x0]
    4acc:      	blr	x8
    4ad0:      	cbz	x0, 0x4d88 <generic_fentry_process_filter+0x1728>
    4ad4:      	ldr	w9, [x0]
    4ad8:      	mov	x1, x0
    4adc:      	mov	w8, #0x1                // =1
    4ae0:      	cmp	x29, x9
    4ae4:      	b.eq	0x49ac <generic_fentry_process_filter+0x134c>
    4ae8:      	ldr	w9, [x1, #0x10]!
    4aec:      	ldr	w12, [sp, #0x30]
    4af0:      	mov	x11, x20
    4af4:      	cmp	x29, x9
    4af8:      	b.eq	0x49b4 <generic_fentry_process_filter+0x1354>
    4afc:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4b00:      	mov	w8, #0x1                // =1
    4b04:      	ldr	x0, [x0]
    4b08:      	blr	x8
    4b0c:      	cbz	x0, 0x4d88 <generic_fentry_process_filter+0x1728>
    4b10:      	ldr	w9, [x0]
    4b14:      	mov	x1, x0
    4b18:      	mov	w8, #0x1                // =1
    4b1c:      	cmp	x29, x9
    4b20:      	b.eq	0x49ac <generic_fentry_process_filter+0x134c>
    4b24:      	ldr	w9, [x1, #0x10]!
    4b28:      	ldr	w12, [sp, #0x30]
    4b2c:      	mov	x11, x20
    4b30:      	cmp	x29, x9
    4b34:      	b.eq	0x49b4 <generic_fentry_process_filter+0x1354>
    4b38:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4b3c:      	mov	w8, #0x1                // =1
    4b40:      	ldr	x0, [x0]
    4b44:      	blr	x8
    4b48:      	cbz	x0, 0x4d88 <generic_fentry_process_filter+0x1728>
    4b4c:      	ldr	w9, [x0]
    4b50:      	mov	x1, x0
    4b54:      	mov	w8, #0x1                // =1
    4b58:      	cmp	x29, x9
    4b5c:      	b.eq	0x49ac <generic_fentry_process_filter+0x134c>
    4b60:      	ldr	w9, [x1, #0x10]!
    4b64:      	ldr	w12, [sp, #0x30]
    4b68:      	mov	x11, x20
    4b6c:      	cmp	x29, x9
    4b70:      	b.eq	0x49b4 <generic_fentry_process_filter+0x1354>
    4b74:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4b78:      	mov	w8, #0x1                // =1
    4b7c:      	ldr	x0, [x0]
    4b80:      	blr	x8
    4b84:      	cbz	x0, 0x4d88 <generic_fentry_process_filter+0x1728>
    4b88:      	ldr	w9, [x0]
    4b8c:      	mov	x1, x0
    4b90:      	mov	w8, #0x1                // =1
    4b94:      	cmp	x29, x9
    4b98:      	b.eq	0x49ac <generic_fentry_process_filter+0x134c>
    4b9c:      	ldr	w9, [x1, #0x10]!
    4ba0:      	ldr	w12, [sp, #0x30]
    4ba4:      	mov	x11, x20
    4ba8:      	cmp	x29, x9
    4bac:      	b.eq	0x49b4 <generic_fentry_process_filter+0x1354>
    4bb0:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4bb4:      	mov	w8, #0x1                // =1
    4bb8:      	ldr	x0, [x0]
    4bbc:      	blr	x8
    4bc0:      	cbz	x0, 0x4d88 <generic_fentry_process_filter+0x1728>
    4bc4:      	ldr	w9, [x0]
    4bc8:      	mov	x1, x0
    4bcc:      	mov	w8, #0x1                // =1
    4bd0:      	cmp	x29, x9
    4bd4:      	b.eq	0x49ac <generic_fentry_process_filter+0x134c>
    4bd8:      	ldr	w9, [x1, #0x10]!
    4bdc:      	ldr	w12, [sp, #0x30]
    4be0:      	mov	x11, x20
    4be4:      	cmp	x29, x9
    4be8:      	b.eq	0x49b4 <generic_fentry_process_filter+0x1354>
    4bec:      	adrp	x9, 0x4000 <generic_fentry_process_filter+0x9a0>
    4bf0:      	mov	w8, #0x1                // =1
    4bf4:      	ldr	x9, [x9]
    4bf8:      	b	0x4d7c <generic_fentry_process_filter+0x171c>
    4bfc:      	ldr	w29, [x24]
    4c00:      	tbnz	w22, #0x1, 0x49e4 <generic_fentry_process_filter+0x1384>
    4c04:      	ldr	w8, [x11]
    4c08:      	cmp	w12, #0x5
    4c0c:      	b.ne	0x4c20 <generic_fentry_process_filter+0x15c0>
    4c10:      	cmp	x29, x8
    4c14:      	b.eq	0x4c20 <generic_fentry_process_filter+0x15c0>
    4c18:      	mov	w9, wzr
    4c1c:      	b	0x49c0 <generic_fentry_process_filter+0x1360>
    4c20:      	cmp	w12, #0x6
    4c24:      	ccmp	x29, x8, #0x0, eq
    4c28:      	cset	w9, ne
    4c2c:      	b	0x49c0 <generic_fentry_process_filter+0x1360>
    4c30:      	ldr	x8, [sp, #0x20]
    4c34:      	ldr	w9, [x8]
    4c38:      	cbz	w9, 0x49c0 <generic_fentry_process_filter+0x1360>
    4c3c:      	mov	w8, #0x1                // =1
    4c40:      	cbz	x29, 0x49b4 <generic_fentry_process_filter+0x1354>
    4c44:      	cmp	x29, x9
    4c48:      	b.eq	0x49b4 <generic_fentry_process_filter+0x1354>
    4c4c:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4c50:      	mov	w8, #0x1                // =1
    4c54:      	ldr	x0, [x0]
    4c58:      	ldr	x1, [sp, #0x18]
    4c5c:      	blr	x8
    4c60:      	cbz	x0, 0x4d88 <generic_fentry_process_filter+0x1728>
    4c64:      	ldr	w8, [x0, #0x24]
    4c68:      	cmp	x29, x8
    4c6c:      	b.eq	0x49a8 <generic_fentry_process_filter+0x1348>
    4c70:      	add	x1, x0, #0x10
    4c74:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4c78:      	mov	w8, #0x1                // =1
    4c7c:      	ldr	x0, [x0]
    4c80:      	blr	x8
    4c84:      	cbz	x0, 0x4d88 <generic_fentry_process_filter+0x1728>
    4c88:      	ldr	w8, [x0, #0x24]
    4c8c:      	cmp	x29, x8
    4c90:      	b.eq	0x49a8 <generic_fentry_process_filter+0x1348>
    4c94:      	add	x1, x0, #0x10
    4c98:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4c9c:      	mov	w8, #0x1                // =1
    4ca0:      	ldr	x0, [x0]
    4ca4:      	blr	x8
    4ca8:      	cbz	x0, 0x4d88 <generic_fentry_process_filter+0x1728>
    4cac:      	ldr	w8, [x0, #0x24]
    4cb0:      	cmp	x29, x8
    4cb4:      	b.eq	0x49a8 <generic_fentry_process_filter+0x1348>
    4cb8:      	add	x1, x0, #0x10
    4cbc:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4cc0:      	mov	w8, #0x1                // =1
    4cc4:      	ldr	x0, [x0]
    4cc8:      	blr	x8
    4ccc:      	cbz	x0, 0x4d88 <generic_fentry_process_filter+0x1728>
    4cd0:      	ldr	w8, [x0, #0x24]
    4cd4:      	cmp	x29, x8
    4cd8:      	b.eq	0x49a8 <generic_fentry_process_filter+0x1348>
    4cdc:      	add	x1, x0, #0x10
    4ce0:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4ce4:      	mov	w8, #0x1                // =1
    4ce8:      	ldr	x0, [x0]
    4cec:      	blr	x8
    4cf0:      	cbz	x0, 0x4d88 <generic_fentry_process_filter+0x1728>
    4cf4:      	ldr	w8, [x0, #0x24]
    4cf8:      	cmp	x29, x8
    4cfc:      	b.eq	0x49a8 <generic_fentry_process_filter+0x1348>
    4d00:      	add	x1, x0, #0x10
    4d04:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4d08:      	mov	w8, #0x1                // =1
    4d0c:      	ldr	x0, [x0]
    4d10:      	blr	x8
    4d14:      	cbz	x0, 0x4d88 <generic_fentry_process_filter+0x1728>
    4d18:      	ldr	w8, [x0, #0x24]
    4d1c:      	cmp	x29, x8
    4d20:      	b.eq	0x49a8 <generic_fentry_process_filter+0x1348>
    4d24:      	add	x1, x0, #0x10
    4d28:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4d2c:      	mov	w8, #0x1                // =1
    4d30:      	ldr	x0, [x0]
    4d34:      	blr	x8
    4d38:      	cbz	x0, 0x4d88 <generic_fentry_process_filter+0x1728>
    4d3c:      	ldr	w8, [x0, #0x24]
    4d40:      	cmp	x29, x8
    4d44:      	b.eq	0x49a8 <generic_fentry_process_filter+0x1348>
    4d48:      	add	x1, x0, #0x10
    4d4c:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4d50:      	mov	w8, #0x1                // =1
    4d54:      	ldr	x0, [x0]
    4d58:      	blr	x8
    4d5c:      	cbz	x0, 0x4d88 <generic_fentry_process_filter+0x1728>
    4d60:      	ldr	w8, [x0, #0x24]
    4d64:      	cmp	x29, x8
    4d68:      	b.eq	0x49a8 <generic_fentry_process_filter+0x1348>
    4d6c:      	adrp	x9, 0x4000 <generic_fentry_process_filter+0x9a0>
    4d70:      	add	x1, x0, #0x10
    4d74:      	mov	w8, #0x1                // =1
    4d78:      	ldr	x9, [x9]
    4d7c:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x9a0>
    4d80:      	ldr	x0, [x0]
    4d84:      	blr	x8
    4d88:      	ldr	w12, [sp, #0x30]
    4d8c:      	mov	w8, wzr
    4d90:      	mov	w9, wzr
    4d94:      	mov	x11, x20
    4d98:      	cmp	w12, #0x5
    4d9c:      	b.ne	0x49b4 <generic_fentry_process_filter+0x1354>
    4da0:      	b	0x49c0 <generic_fentry_process_filter+0x1360>
    4da4:      	ldp	w8, w9, [sp, #0x58]
    4da8:      	ldp	w10, w11, [sp, #0x60]
    4dac:      	cmp	w12, #0x6
    4db0:      	b.ne	0x4dc4 <generic_fentry_process_filter+0x1764>
    4db4:      	and	w8, w9, w8
    4db8:      	and	w9, w10, w11
    4dbc:      	and	w9, w8, w9
    4dc0:      	b	0x4dd0 <generic_fentry_process_filter+0x1770>
    4dc4:      	orr	w8, w9, w8
    4dc8:      	orr	w9, w10, w11
    4dcc:      	orr	w9, w8, w9
    4dd0:      	ldr	x8, [sp, #0x10]
    4dd4:      	cbz	w9, 0x54dc <generic_fentry_process_filter+0x1e7c>
    4dd8:      	ldr	x10, [sp, #0x8]
    4ddc:      	add	w8, w8, #0x14
    4de0:      	ldr	w10, [x10, #0x8]
    4de4:      	ubfiz	w10, w10, #2, #3
    4de8:      	add	w8, w10, w8
    4dec:      	and	x10, x8, #0x3ff
    4df0:      	add	w8, w8, #0x4
    4df4:      	mov	w19, #0xa               // =10
    4df8:      	ldr	w10, [x10, x23]
    4dfc:      	mov	w20, #0x4               // =4
    4e00:      	mov	x25, #0x100000001       // =4294967297
    4e04:      	sub	w22, w10, #0x4
    4e08:      	ldr	x10, [sp, #0xe8]
    4e0c:      	add	x10, x10, #0x20
    4e10:      	str	x10, [sp, #0x30]
    4e14:      	b	0x4e2c <generic_fentry_process_filter+0x17cc>
    4e18:      	orr	w8, w9, w8
    4e1c:      	orr	w9, w10, w11
    4e20:      	orr	w9, w8, w9
    4e24:      	cbnz	w9, 0x4fe0 <generic_fentry_process_filter+0x1980>
    4e28:      	b	0x54dc <generic_fentry_process_filter+0x1e7c>
    4e2c:      	cbz	w22, 0x4ff4 <generic_fentry_process_filter+0x1994>
    4e30:      	and	x9, x8, #0x3ff
    4e34:      	add	x10, x9, x23
    4e38:      	ldr	w29, [x10, #0x8]
    4e3c:      	ldp	w9, w24, [x10]
    4e40:      	stp	xzr, xzr, [sp, #0x58]
    4e44:      	cmp	w29, #0x4
    4e48:      	csel	w10, w29, w20, lo
    4e4c:      	cmp	w24, #0x6
    4e50:      	b.ne	0x4e58 <generic_fentry_process_filter+0x17f8>
    4e54:      	stp	x25, x25, [sp, #0x58]
    4e58:      	add	w21, w8, #0xc
    4e5c:      	cbz	w29, 0x4fc0 <generic_fentry_process_filter+0x1960>
    4e60:      	and	x9, x9, #0xf
    4e64:      	cmp	w9, #0xa
    4e68:      	b.lo	0x4e94 <generic_fentry_process_filter+0x1834>
    4e6c:      	sub	x8, x10, #0x1
    4e70:      	mov	w9, #0x3                // =3
    4e74:      	add	x0, sp, #0x58
    4e78:      	mov	w1, wzr
    4e7c:      	cmp	x8, #0x3
    4e80:      	csel	x8, x8, x9, lo
    4e84:      	lsl	x8, x8, #2
    4e88:      	add	x2, x8, #0x4
    4e8c:      	bl	0x4e8c <generic_fentry_process_filter+0x182c>
    4e90:      	b	0x4fc0 <generic_fentry_process_filter+0x1960>
    4e94:      	cmp	w21, #0x3e8
    4e98:      	b.ls	0x4ea4 <generic_fentry_process_filter+0x1844>
    4e9c:      	mov	w11, wzr
    4ea0:      	b	0x4eac <generic_fentry_process_filter+0x184c>
    4ea4:      	and	w11, w21, #0xfffffffc
    4ea8:      	ldr	w11, [x23, w11, uxtw]
    4eac:      	ldr	x12, [sp, #0x30]
    4eb0:      	cmp	w24, #0x5
    4eb4:      	sub	x10, x10, #0x1
    4eb8:      	ldr	w9, [x12, x9, lsl #2]
    4ebc:      	cset	w12, ne
    4ec0:      	cmp	w24, #0x6
    4ec4:      	cset	w13, ne
    4ec8:      	cmp	w11, w9
    4ecc:      	csinc	w11, w12, wzr, ne
    4ed0:      	csinc	w12, w13, wzr, eq
    4ed4:      	and	w11, w11, w12
    4ed8:      	str	w11, [sp, #0x58]
    4edc:      	cbz	x10, 0x4fc0 <generic_fentry_process_filter+0x1960>
    4ee0:      	add	w11, w8, #0x10
    4ee4:      	cmp	w11, #0x3e8
    4ee8:      	b.ls	0x4ef4 <generic_fentry_process_filter+0x1894>
    4eec:      	mov	w11, wzr
    4ef0:      	b	0x4efc <generic_fentry_process_filter+0x189c>
    4ef4:      	and	w11, w11, #0xfffffffc
    4ef8:      	ldr	w11, [x23, w11, uxtw]
    4efc:      	cmp	w24, #0x5
    4f00:      	cset	w12, ne
    4f04:      	cmp	w24, #0x6
    4f08:      	cset	w13, ne
    4f0c:      	cmp	w11, w9
    4f10:      	csinc	w11, w12, wzr, ne
    4f14:      	csinc	w12, w13, wzr, eq
    4f18:      	cmp	x10, #0x1
    4f1c:      	and	w11, w11, w12
    4f20:      	str	w11, [sp, #0x5c]
    4f24:      	b.eq	0x4fc0 <generic_fentry_process_filter+0x1960>
    4f28:      	add	w11, w8, #0x14
    4f2c:      	cmp	w11, #0x3e8
    4f30:      	b.ls	0x4f3c <generic_fentry_process_filter+0x18dc>
    4f34:      	mov	w11, wzr
    4f38:      	b	0x4f44 <generic_fentry_process_filter+0x18e4>
    4f3c:      	and	w11, w11, #0xfffffffc
    4f40:      	ldr	w11, [x23, w11, uxtw]
    4f44:      	cmp	w24, #0x5
    4f48:      	cset	w12, ne
    4f4c:      	cmp	w24, #0x6
    4f50:      	cset	w13, ne
    4f54:      	cmp	w11, w9
    4f58:      	csinc	w11, w12, wzr, ne
    4f5c:      	csinc	w12, w13, wzr, eq
    4f60:      	cmp	x10, #0x2
    4f64:      	and	w11, w11, w12
    4f68:      	str	w11, [sp, #0x60]
    4f6c:      	b.eq	0x4fc0 <generic_fentry_process_filter+0x1960>
    4f70:      	add	w8, w8, #0x18
    4f74:      	cmp	w8, #0x3e8
    4f78:      	b.ls	0x4f84 <generic_fentry_process_filter+0x1924>
    4f7c:      	mov	w8, wzr
    4f80:      	b	0x4f8c <generic_fentry_process_filter+0x192c>
    4f84:      	and	w8, w8, #0xfffffffc
    4f88:      	ldr	w8, [x23, w8, uxtw]
    4f8c:      	cmp	w24, #0x5
    4f90:      	cset	w10, ne
    4f94:      	cmp	w24, #0x6
    4f98:      	cset	w11, ne
    4f9c:      	cmp	w8, w9
    4fa0:      	csinc	w8, w10, wzr, ne
    4fa4:      	csinc	w9, w11, wzr, eq
    4fa8:      	and	w8, w8, w9
    4fac:      	str	w8, [sp, #0x64]
    4fb0:      	nop
    4fb4:      	nop
    4fb8:      	nop
    4fbc:      	nop
    4fc0:      	ldp	w8, w9, [sp, #0x58]
    4fc4:      	ldp	w10, w11, [sp, #0x60]
    4fc8:      	cmp	w24, #0x6
    4fcc:      	b.ne	0x4e18 <generic_fentry_process_filter+0x17b8>
    4fd0:      	and	w8, w9, w8
    4fd4:      	and	w9, w10, w11
    4fd8:      	and	w9, w8, w9
    4fdc:      	cbz	w9, 0x54dc <generic_fentry_process_filter+0x1e7c>
    4fe0:      	lsl	w8, w29, #2
    4fe4:      	sub	w10, w22, w29, lsl #2
    4fe8:      	and	w8, w8, #0x1c
    4fec:      	sub	w22, w10, #0xc
    4ff0:      	add	w8, w8, w21
    4ff4:      	subs	x19, x19, #0x1
    4ff8:      	b.ne	0x4e2c <generic_fentry_process_filter+0x17cc>
    4ffc:      	mov	w10, w8
    5000:      	add	w19, w8, #0x4
    5004:      	and	x10, x10, #0x3ff
    5008:      	ldr	w10, [x10, x23]
    500c:      	cmp	w10, #0x4
    5010:      	b.ne	0x50a8 <generic_fentry_process_filter+0x1a48>
    5014:      	cbz	w9, 0x54dc <generic_fentry_process_filter+0x1e7c>
    5018:      	mov	w8, w19
    501c:      	and	x8, x8, #0x3ff
    5020:      	ldr	w9, [x8, x23]
    5024:      	add	w8, w19, #0x4
    5028:      	cmp	w9, #0x4
    502c:      	mov	w9, w8
    5030:      	b.eq	0x53d8 <generic_fentry_process_filter+0x1d78>
    5034:      	and	x8, x8, #0x3ff
    5038:      	add	x8, x8, x23
    503c:      	ldp	w20, w22, [x8]
    5040:      	mov	w8, #0xe                // =14
    5044:      	blr	x8
    5048:      	lsr	x8, x0, #32
    504c:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x19a0>
    5050:      	add	x9, sp, #0x58
    5054:      	str	w8, [sp, #0x58]
    5058:      	mov	w8, #0x1                // =1
    505c:      	add	x1, sp, #0x58
    5060:      	ldr	x0, [x0]
    5064:      	blr	x8
    5068:      	cbz	x0, 0x54dc <generic_fentry_process_filter+0x1e7c>
    506c:      	cmp	w20, #0x5
    5070:      	b.eq	0x5124 <generic_fentry_process_filter+0x1ac4>
    5074:      	cmp	w20, #0x6
    5078:      	b.ne	0x54dc <generic_fentry_process_filter+0x1e7c>
    507c:      	ldr	x11, [sp, #0xe8]
    5080:      	mov	w8, #0x5ee8             // =24296
    5084:      	add	x8, x11, x8
    5088:      	tbnz	w22, #0x0, 0x5158 <generic_fentry_process_filter+0x1af8>
    508c:      	ldr	w9, [x0, #0x28]
    5090:      	cbz	w9, 0x5150 <generic_fentry_process_filter+0x1af0>
    5094:      	ldr	x10, [sp, #0x30]
    5098:      	ldr	w10, [x10]
    509c:      	cmp	w9, w10
    50a0:      	b.eq	0x5158 <generic_fentry_process_filter+0x1af8>
    50a4:      	b	0x53cc <generic_fentry_process_filter+0x1d6c>
    50a8:      	and	x9, x19, #0x3ff
    50ac:      	add	w19, w8, #0x18
    50b0:      	add	x9, x9, x23
    50b4:      	ldp	w8, w10, [x9]
    50b8:      	ldr	w12, [x9, #0x8]
    50bc:      	ldur	x11, [x9, #0xc]
    50c0:      	cbz	w12, 0x50e4 <generic_fentry_process_filter+0x1a84>
    50c4:      	ldr	x14, [sp, #0xe8]
    50c8:      	mov	w9, wzr
    50cc:      	cmp	w8, #0x2
    50d0:      	b.hi	0x5014 <generic_fentry_process_filter+0x19b4>
    50d4:      	ldr	w13, [x14, #0x44]
    50d8:      	cmp	w13, w12
    50dc:      	b.ne	0x50f8 <generic_fentry_process_filter+0x1a98>
    50e0:      	b	0x5014 <generic_fentry_process_filter+0x19b4>
    50e4:      	ldr	x14, [sp, #0xe8]
    50e8:      	cmp	w8, #0x2
    50ec:      	b.ls	0x50f8 <generic_fentry_process_filter+0x1a98>
    50f0:      	mov	w9, wzr
    50f4:      	b	0x5014 <generic_fentry_process_filter+0x19b4>
    50f8:      	add	x9, x14, #0x48
    50fc:      	cmp	w10, #0x5
    5100:      	ldr	x8, [x9, x8, lsl #3]
    5104:      	and	x8, x8, x11
    5108:      	b.ne	0x5118 <generic_fentry_process_filter+0x1ab8>
    510c:      	cmp	x8, #0x0
    5110:      	cset	w9, ne
    5114:      	b	0x5014 <generic_fentry_process_filter+0x19b4>
    5118:      	cmp	x8, #0x0
    511c:      	cset	w9, eq
    5120:      	b	0x5014 <generic_fentry_process_filter+0x19b4>
    5124:      	ldr	x11, [sp, #0xe8]
    5128:      	mov	w8, #0x5ee8             // =24296
    512c:      	add	x8, x11, x8
    5130:      	tbz	w22, #0x0, 0x517c <generic_fentry_process_filter+0x1b1c>
    5134:      	ldr	w9, [x0, #0x28]
    5138:      	cbz	w9, 0x5174 <generic_fentry_process_filter+0x1b14>
    513c:      	ldr	x10, [sp, #0x30]
    5140:      	ldr	w10, [x10]
    5144:      	cmp	w9, w10
    5148:      	b.eq	0x517c <generic_fentry_process_filter+0x1b1c>
    514c:      	b	0x53cc <generic_fentry_process_filter+0x1d6c>
    5150:      	mov	w9, #0x1                // =1
    5154:      	str	x9, [x8]
    5158:      	tbnz	w22, #0x1, 0x51a0 <generic_fentry_process_filter+0x1b40>
    515c:      	ldr	w9, [x0, #0x2c]
    5160:      	cbz	w9, 0x5198 <generic_fentry_process_filter+0x1b38>
    5164:      	ldr	w10, [x11, #0x24]
    5168:      	cmp	w9, w10
    516c:      	b.eq	0x51a0 <generic_fentry_process_filter+0x1b40>
    5170:      	b	0x53cc <generic_fentry_process_filter+0x1d6c>
    5174:      	mov	w9, #0x1                // =1
    5178:      	str	x9, [x8]
    517c:      	tbz	w22, #0x1, 0x51c4 <generic_fentry_process_filter+0x1b64>
    5180:      	ldr	w9, [x0, #0x2c]
    5184:      	cbz	w9, 0x51bc <generic_fentry_process_filter+0x1b5c>
    5188:      	ldr	w10, [x11, #0x24]
    518c:      	cmp	w9, w10
    5190:      	b.eq	0x51c4 <generic_fentry_process_filter+0x1b64>
    5194:      	b	0x53cc <generic_fentry_process_filter+0x1d6c>
    5198:      	mov	w9, #0x1                // =1
    519c:      	str	x9, [x8]
    51a0:      	tbnz	w22, #0x2, 0x51e8 <generic_fentry_process_filter+0x1b88>
    51a4:      	ldr	w9, [x0, #0x30]
    51a8:      	cbz	w9, 0x51e0 <generic_fentry_process_filter+0x1b80>
    51ac:      	ldr	w10, [x11, #0x28]
    51b0:      	cmp	w9, w10
    51b4:      	b.eq	0x51e8 <generic_fentry_process_filter+0x1b88>
    51b8:      	b	0x53cc <generic_fentry_process_filter+0x1d6c>
    51bc:      	mov	w9, #0x1                // =1
    51c0:      	str	x9, [x8]
    51c4:      	tbz	w22, #0x2, 0x520c <generic_fentry_process_filter+0x1bac>
    51c8:      	ldr	w9, [x0, #0x30]
    51cc:      	cbz	w9, 0x5204 <generic_fentry_process_filter+0x1ba4>
    51d0:      	ldr	w10, [x11, #0x28]
    51d4:      	cmp	w9, w10
    51d8:      	b.eq	0x520c <generic_fentry_process_filter+0x1bac>
    51dc:      	b	0x53cc <generic_fentry_process_filter+0x1d6c>
    51e0:      	mov	w9, #0x1                // =1
    51e4:      	str	x9, [x8]
    51e8:      	tbnz	w22, #0x3, 0x5230 <generic_fentry_process_filter+0x1bd0>
    51ec:      	ldr	w9, [x0, #0x34]
    51f0:      	cbz	w9, 0x5228 <generic_fentry_process_filter+0x1bc8>
    51f4:      	ldr	w10, [x11, #0x2c]
    51f8:      	cmp	w9, w10
    51fc:      	b.eq	0x5230 <generic_fentry_process_filter+0x1bd0>
    5200:      	b	0x53cc <generic_fentry_process_filter+0x1d6c>
    5204:      	mov	w9, #0x1                // =1
    5208:      	str	x9, [x8]
    520c:      	tbz	w22, #0x3, 0x5254 <generic_fentry_process_filter+0x1bf4>
    5210:      	ldr	w9, [x0, #0x34]
    5214:      	cbz	w9, 0x524c <generic_fentry_process_filter+0x1bec>
    5218:      	ldr	w10, [x11, #0x2c]
    521c:      	cmp	w9, w10
    5220:      	b.eq	0x5254 <generic_fentry_process_filter+0x1bf4>
    5224:      	b	0x53cc <generic_fentry_process_filter+0x1d6c>
    5228:      	mov	w9, #0x1                // =1
    522c:      	str	x9, [x8]
    5230:      	tbnz	w22, #0x4, 0x5278 <generic_fentry_process_filter+0x1c18>
    5234:      	ldr	w9, [x0, #0x38]
    5238:      	cbz	w9, 0x5270 <generic_fentry_process_filter+0x1c10>
    523c:      	ldr	w10, [x11, #0x30]
    5240:      	cmp	w9, w10
    5244:      	b.eq	0x5278 <generic_fentry_process_filter+0x1c18>
    5248:      	b	0x53cc <generic_fentry_process_filter+0x1d6c>
    524c:      	mov	w9, #0x1                // =1
    5250:      	str	x9, [x8]
    5254:      	tbz	w22, #0x4, 0x529c <generic_fentry_process_filter+0x1c3c>
    5258:      	ldr	w9, [x0, #0x38]
    525c:      	cbz	w9, 0x5294 <generic_fentry_process_filter+0x1c34>
    5260:      	ldr	w10, [x11, #0x30]
    5264:      	cmp	w9, w10
    5268:      	b.eq	0x529c <generic_fentry_process_filter+0x1c3c>
    526c:      	b	0x53cc <generic_fentry_process_filter+0x1d6c>
    5270:      	mov	w9, #0x1                // =1
    5274:      	str	x9, [x8]
    5278:      	tbnz	w22, #0x5, 0x52c0 <generic_fentry_process_filter+0x1c60>
    527c:      	ldr	w9, [x0, #0x3c]
    5280:      	cbz	w9, 0x52b8 <generic_fentry_process_filter+0x1c58>
    5284:      	ldr	w10, [x11, #0x34]
    5288:      	cmp	w9, w10
    528c:      	b.eq	0x52c0 <generic_fentry_process_filter+0x1c60>
    5290:      	b	0x53cc <generic_fentry_process_filter+0x1d6c>
    5294:      	mov	w9, #0x1                // =1
    5298:      	str	x9, [x8]
    529c:      	tbz	w22, #0x5, 0x52e4 <generic_fentry_process_filter+0x1c84>
    52a0:      	ldr	w9, [x0, #0x3c]
    52a4:      	cbz	w9, 0x52dc <generic_fentry_process_filter+0x1c7c>
    52a8:      	ldr	w10, [x11, #0x34]
    52ac:      	cmp	w9, w10
    52b0:      	b.eq	0x52e4 <generic_fentry_process_filter+0x1c84>
    52b4:      	b	0x53cc <generic_fentry_process_filter+0x1d6c>
    52b8:      	mov	w9, #0x1                // =1
    52bc:      	str	x9, [x8]
    52c0:      	tbnz	w22, #0x6, 0x5308 <generic_fentry_process_filter+0x1ca8>
    52c4:      	ldr	w9, [x0, #0x40]
    52c8:      	cbz	w9, 0x5300 <generic_fentry_process_filter+0x1ca0>
    52cc:      	ldr	w10, [x11, #0x38]
    52d0:      	cmp	w9, w10
    52d4:      	b.eq	0x5308 <generic_fentry_process_filter+0x1ca8>
    52d8:      	b	0x53cc <generic_fentry_process_filter+0x1d6c>
    52dc:      	mov	w9, #0x1                // =1
    52e0:      	str	x9, [x8]
    52e4:      	tbz	w22, #0x6, 0x532c <generic_fentry_process_filter+0x1ccc>
    52e8:      	ldr	w9, [x0, #0x40]
    52ec:      	cbz	w9, 0x5324 <generic_fentry_process_filter+0x1cc4>
    52f0:      	ldr	w10, [x11, #0x38]
    52f4:      	cmp	w9, w10
    52f8:      	b.eq	0x532c <generic_fentry_process_filter+0x1ccc>
    52fc:      	b	0x53cc <generic_fentry_process_filter+0x1d6c>
    5300:      	mov	w9, #0x1                // =1
    5304:      	str	x9, [x8]
    5308:      	tbnz	w22, #0x7, 0x5350 <generic_fentry_process_filter+0x1cf0>
    530c:      	ldr	w9, [x0, #0x44]
    5310:      	cbz	w9, 0x5348 <generic_fentry_process_filter+0x1ce8>
    5314:      	ldr	w10, [x11, #0x3c]
    5318:      	cmp	w9, w10
    531c:      	b.eq	0x5350 <generic_fentry_process_filter+0x1cf0>
    5320:      	b	0x53cc <generic_fentry_process_filter+0x1d6c>
    5324:      	mov	w9, #0x1                // =1
    5328:      	str	x9, [x8]
    532c:      	tbz	w22, #0x7, 0x5378 <generic_fentry_process_filter+0x1d18>
    5330:      	ldr	w9, [x0, #0x44]
    5334:      	cbz	w9, 0x5370 <generic_fentry_process_filter+0x1d10>
    5338:      	ldr	w10, [x11, #0x3c]
    533c:      	cmp	w9, w10
    5340:      	b.eq	0x5378 <generic_fentry_process_filter+0x1d18>
    5344:      	b	0x53cc <generic_fentry_process_filter+0x1d6c>
    5348:      	mov	w9, #0x1                // =1
    534c:      	str	x9, [x8]
    5350:      	tbnz	w22, #0x8, 0x53a0 <generic_fentry_process_filter+0x1d40>
    5354:      	ldr	w9, [x0, #0x48]
    5358:      	cbz	w9, 0x5398 <generic_fentry_process_filter+0x1d38>
    535c:      	ldr	x10, [sp, #0xe8]
    5360:      	ldr	w10, [x10, #0x40]
    5364:      	cmp	w9, w10
    5368:      	b.eq	0x53a0 <generic_fentry_process_filter+0x1d40>
    536c:      	b	0x53cc <generic_fentry_process_filter+0x1d6c>
    5370:      	mov	w9, #0x1                // =1
    5374:      	str	x9, [x8]
    5378:      	tbz	w22, #0x8, 0x53b0 <generic_fentry_process_filter+0x1d50>
    537c:      	ldr	w9, [x0, #0x48]
    5380:      	cbz	w9, 0x53a8 <generic_fentry_process_filter+0x1d48>
    5384:      	ldr	x10, [sp, #0xe8]
    5388:      	ldr	w10, [x10, #0x40]
    538c:      	cmp	w9, w10
    5390:      	b.eq	0x53b0 <generic_fentry_process_filter+0x1d50>
    5394:      	b	0x53cc <generic_fentry_process_filter+0x1d6c>
    5398:      	mov	w9, #0x1                // =1
    539c:      	str	x9, [x8]
    53a0:      	tbz	w22, #0x9, 0x53b4 <generic_fentry_process_filter+0x1d54>
    53a4:      	b	0x54dc <generic_fentry_process_filter+0x1e7c>
    53a8:      	mov	w9, #0x1                // =1
    53ac:      	str	x9, [x8]
    53b0:      	tbz	w22, #0x9, 0x54dc <generic_fentry_process_filter+0x1e7c>
    53b4:      	ldr	w9, [x0, #0x4c]
    53b8:      	cbz	w9, 0x54d4 <generic_fentry_process_filter+0x1e74>
    53bc:      	ldr	x10, [sp, #0xe8]
    53c0:      	ldr	w10, [x10, #0x44]
    53c4:      	cmp	w9, w10
    53c8:      	b.eq	0x54dc <generic_fentry_process_filter+0x1e7c>
    53cc:      	add	w9, w19, #0xc
    53d0:      	mov	w10, #0x1               // =1
    53d4:      	str	x10, [x8]
    53d8:      	and	x8, x9, #0x3ff
    53dc:      	adrp	x24, 0x5000 <generic_fentry_process_filter+0x19a0>
    53e0:      	ldr	w8, [x8, x23]
    53e4:      	ldr	x24, [x24]
    53e8:      	cmp	w8, #0x4
    53ec:      	b.ne	0x5420 <generic_fentry_process_filter+0x1dc0>
    53f0:      	ldr	x9, [sp, #0xe8]
    53f4:      	mov	w8, #0x5eb8             // =24248
    53f8:      	add	x8, x9, x8
    53fc:      	ldr	x9, [x9, #0x5eb8]
    5400:      	and	x9, x9, #0x1f
    5404:      	add	x8, x8, x9
    5408:      	mov	w9, #0x1                // =1
    540c:      	strb	w9, [x8, #0x9]
    5410:      	ldr	x8, [sp, #0x40]
    5414:      	strb	w9, [x8, #0x20]
    5418:      	strb	w9, [x8]
    541c:      	b	0x54dc <generic_fentry_process_filter+0x1e7c>
    5420:      	add	w8, w9, #0x4
    5424:      	and	x8, x8, #0x3ff
    5428:      	add	x8, x8, x23
    542c:      	ldp	w21, w19, [x8]
    5430:      	ldr	w22, [x8, #0x8]
    5434:      	ldur	x20, [x8, #0xc]
    5438:      	mov	w8, #0xe                // =14
    543c:      	blr	x8
    5440:      	lsr	x8, x0, #32
    5444:      	add	x9, sp, #0x58
    5448:      	add	x1, sp, #0x58
    544c:      	str	w8, [sp, #0x58]
    5450:      	mov	w8, #0x1                // =1
    5454:      	mov	x0, x24
    5458:      	blr	x8
    545c:      	cbz	x0, 0x54dc <generic_fentry_process_filter+0x1e7c>
    5460:      	cmp	w21, #0x2
    5464:      	cbz	w22, 0x5480 <generic_fentry_process_filter+0x1e20>
    5468:      	b.hi	0x54dc <generic_fentry_process_filter+0x1e7c>
    546c:      	ldr	x8, [sp, #0xe8]
    5470:      	ldr	w8, [x8, #0x44]
    5474:      	cmp	w8, w22
    5478:      	b.ne	0x5484 <generic_fentry_process_filter+0x1e24>
    547c:      	b	0x54dc <generic_fentry_process_filter+0x1e7c>
    5480:      	b.hi	0x54dc <generic_fentry_process_filter+0x1e7c>
    5484:      	ldr	x8, [sp, #0xe8]
    5488:      	lsl	x10, x21, #3
    548c:      	add	x9, x8, #0x48
    5490:      	add	x8, x0, x21, lsl #3
    5494:      	ldr	x8, [x8, #0x50]
    5498:      	ldr	x9, [x9, x10]
    549c:      	eor	x10, x9, x8
    54a0:      	tst	x10, x20
    54a4:      	b.eq	0x54b4 <generic_fentry_process_filter+0x1e54>
    54a8:      	cmp	w19, #0x5
    54ac:      	b.eq	0x54c4 <generic_fentry_process_filter+0x1e64>
    54b0:      	b	0x54dc <generic_fentry_process_filter+0x1e7c>
    54b4:      	cmp	x8, x9
    54b8:      	b.eq	0x54dc <generic_fentry_process_filter+0x1e7c>
    54bc:      	cmp	w19, #0x6
    54c0:      	b.ne	0x54dc <generic_fentry_process_filter+0x1e7c>
    54c4:      	ldr	x9, [sp, #0xe8]
    54c8:      	mov	w8, #0x1                // =1
    54cc:      	str	x8, [x9, #0x5ef0]
    54d0:      	b	0x53f0 <generic_fentry_process_filter+0x1d90>
    54d4:      	mov	w9, #0x1                // =1
    54d8:      	str	x9, [x8]
    54dc:      	ldr	x9, [sp, #0xe8]
    54e0:      	ldr	x10, [sp, #0x28]
    54e4:      	ldr	x8, [x9, #0x5eb8]
    54e8:      	add	x8, x8, #0x1
    54ec:      	cmp	x8, x10
    54f0:      	str	x8, [x9, #0x5eb8]
    54f4:      	b.ls	0x5554 <generic_fentry_process_filter+0x1ef4>
    54f8:      	ldr	x10, [sp, #0x48]
    54fc:      	ldr	w8, [x10]
    5500:      	str	w8, [x9, #0x10]
    5504:      	ldr	x8, [x10, #0x8]
    5508:      	str	x8, [x9, #0x18]
    550c:      	ldp	x22, x8, [sp, #0x38]
    5510:      	ldrb	w8, [x8]
    5514:      	cbz	w8, 0x5534 <generic_fentry_process_filter+0x1ed4>
    5518:      	adrp	x1, 0x5000 <generic_fentry_process_filter+0x19a0>
    551c:      	mov	x8, xzr
    5520:      	mov	w9, #0xc                // =12
    5524:      	ldr	x1, [x1]
    5528:      	mov	x0, x22
    552c:      	mov	w2, wzr
    5530:      	blr	x9
    5534:      	ldp	x20, x19, [sp, #0x120]
    5538:      	mov	w0, wzr
    553c:      	ldr	x29, [sp, #0xe0]
    5540:      	ldp	x22, x21, [sp, #0x110]
    5544:      	ldp	x24, x23, [sp, #0x100]
    5548:      	ldp	x30, x25, [sp, #0xf0]
    554c:      	add	sp, sp, #0x130
    5550:      	ret
    5554:      	adrp	x1, 0x5000 <generic_fentry_process_filter+0x19a0>
    5558:      	mov	w8, #0x2                // =2
    555c:      	mov	w9, #0xc                // =12
    5560:      	ldr	x1, [x1]
    5564:      	ldr	x0, [sp, #0x38]
    5568:      	mov	w2, #0x2                // =2
    556c:      	b	0x5530 <generic_fentry_process_filter+0x1ed0>

0000000000005570 <generic_fentry_filter_arg>:
    5570:      	sub	sp, sp, #0xf0
    5574:      	str	x29, [sp, #0xa0]
    5578:      	stp	x30, x25, [sp, #0xb0]
    557c:      	stp	x24, x23, [sp, #0xc0]
    5580:      	stp	x22, x21, [sp, #0xd0]
    5584:      	stp	x20, x19, [sp, #0xe0]
    5588:      	mov	x19, x0
    558c:      	str	wzr, [sp, #0xa8]
    5590:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x19a0>
    5594:      	mov	w8, #0x1                // =1
    5598:      	ldr	x0, [x0]
    559c:      	add	x9, sp, #0xa8
    55a0:      	add	x1, sp, #0xa8
    55a4:      	blr	x8
    55a8:      	cbz	x0, 0x5718 <generic_fentry_filter_arg+0x1a8>
    55ac:      	mov	w8, #0x5ec1             // =24257
    55b0:      	mov	x20, x0
    55b4:      	add	x22, x0, x8
    55b8:      	mov	w8, #0x5ef8             // =24312
    55bc:      	add	x1, x0, x8
    55c0:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x19a0>
    55c4:      	ldur	w23, [x22, #0x3f]
    55c8:      	mov	w8, #0x1                // =1
    55cc:      	ldr	x0, [x0]
    55d0:      	blr	x8
    55d4:      	cbz	x0, 0x56fc <generic_fentry_filter_arg+0x18c>
    55d8:      	ldrb	w8, [x22, #0x1f]
    55dc:      	cbz	w8, 0x56fc <generic_fentry_filter_arg+0x18c>
    55e0:      	and	x8, x23, #0x7
    55e4:      	mov	w10, #0x5ec1            // =24257
    55e8:      	stp	x23, x22, [sp, #0x50]
    55ec:      	add	x9, x20, x8
    55f0:      	ldrb	w9, [x9, x10]
    55f4:      	cbz	w9, 0x566c <generic_fentry_filter_arg+0xfc>
    55f8:      	lsl	w8, w8, #2
    55fc:      	mov	x21, x0
    5600:      	add	x8, x8, #0x4
    5604:      	ldr	w9, [x8, x0]
    5608:      	add	x8, x8, x9
    560c:      	add	x8, x8, #0x4
    5610:      	and	x9, x8, #0x3ff
    5614:      	ldr	w9, [x9, x0]
    5618:      	add	x8, x8, x9
    561c:      	and	x9, x8, #0x3ff
    5620:      	ldr	w9, [x9, x0]
    5624:      	add	x8, x8, x9
    5628:      	and	x9, x8, #0x3ff
    562c:      	ldr	w9, [x9, x0]
    5630:      	add	x8, x8, x9
    5634:      	and	x9, x8, #0x3ff
    5638:      	ldr	w9, [x9, x0]
    563c:      	add	x8, x8, x9
    5640:      	and	x9, x8, #0x3ff
    5644:      	ldr	w9, [x9, x0]
    5648:      	add	x16, x8, x9
    564c:      	and	x15, x16, #0x3ff
    5650:      	add	x17, x0, x15
    5654:      	ldr	w8, [x17]
    5658:      	cmp	w8, #0x19
    565c:      	b.hs	0x56c0 <generic_fentry_filter_arg+0x150>
    5660:      	cmp	w15, #0x1
    5664:      	b.eq	0x56fc <generic_fentry_filter_arg+0x18c>
    5668:      	cbnz	w15, 0x56d8 <generic_fentry_filter_arg+0x168>
    566c:      	ldr	x8, [sp, #0x50]
    5670:      	cmp	w8, #0x1
    5674:      	b.gt	0x5694 <generic_fentry_filter_arg+0x124>
    5678:      	ldr	x9, [sp, #0x58]
    567c:      	cmn	w8, #0x1
    5680:      	b.eq	0x5738 <generic_fentry_filter_arg+0x1c8>
    5684:      	cbz	w8, 0x5748 <generic_fentry_filter_arg+0x1d8>
    5688:      	cmp	w8, #0x1
    568c:      	b.eq	0x5758 <generic_fentry_filter_arg+0x1e8>
    5690:      	b	0x56b0 <generic_fentry_filter_arg+0x140>
    5694:      	ldr	x9, [sp, #0x58]
    5698:      	cmp	w8, #0x2
    569c:      	b.eq	0x5768 <generic_fentry_filter_arg+0x1f8>
    56a0:      	cmp	w8, #0x3
    56a4:      	b.eq	0x5778 <generic_fentry_filter_arg+0x208>
    56a8:      	cmp	w8, #0x4
    56ac:      	b.eq	0x5788 <generic_fentry_filter_arg+0x218>
    56b0:      	cmp	w8, #0x4
    56b4:      	b.gt	0x57b4 <generic_fentry_filter_arg+0x244>
    56b8:      	add	w8, w8, #0x1
    56bc:      	b	0x5794 <generic_fentry_filter_arg+0x224>
    56c0:      	mov	x25, xzr
    56c4:      	mov	w2, #0x5ea0             // =24224
    56c8:      	mov	w12, #0x1               // =1
    56cc:      	stp	x19, x17, [sp, #0x30]
    56d0:      	stp	x16, x15, [sp, #0x40]
    56d4:      	b	0x5814 <generic_fentry_filter_arg+0x2a4>
    56d8:      	ldr	x8, [sp, #0x58]
    56dc:      	adrp	x1, 0x5000 <generic_fentry_process_filter+0x19a0>
    56e0:      	mov	w9, #0xc                // =12
    56e4:      	mov	x0, x19
    56e8:      	stur	w15, [x8, #0x43]
    56ec:      	mov	w8, #0x4                // =4
    56f0:      	mov	w2, #0x4                // =4
    56f4:      	ldr	x1, [x1]
    56f8:      	blr	x9
    56fc:      	adrp	x1, 0x5000 <generic_fentry_process_filter+0x19a0>
    5700:      	mov	w8, #0x5                // =5
    5704:      	mov	w9, #0xc                // =12
    5708:      	ldr	x1, [x1]
    570c:      	mov	x0, x19
    5710:      	mov	w2, #0x5                // =5
    5714:      	blr	x9
    5718:      	ldp	x20, x19, [sp, #0xe0]
    571c:      	mov	w0, wzr
    5720:      	ldr	x29, [sp, #0xa0]
    5724:      	ldp	x22, x21, [sp, #0xd0]
    5728:      	ldp	x24, x23, [sp, #0xc0]
    572c:      	ldp	x30, x25, [sp, #0xb0]
    5730:      	add	sp, sp, #0xf0
    5734:      	ret
    5738:      	ldrb	w8, [x9]
    573c:      	cbz	w8, 0x5748 <generic_fentry_filter_arg+0x1d8>
    5740:      	mov	w8, wzr
    5744:      	b	0x5794 <generic_fentry_filter_arg+0x224>
    5748:      	ldrb	w8, [x9, #0x1]
    574c:      	cbz	w8, 0x5758 <generic_fentry_filter_arg+0x1e8>
    5750:      	mov	w8, #0x1                // =1
    5754:      	b	0x5794 <generic_fentry_filter_arg+0x224>
    5758:      	ldrb	w8, [x9, #0x2]
    575c:      	cbz	w8, 0x5768 <generic_fentry_filter_arg+0x1f8>
    5760:      	mov	w8, #0x2                // =2
    5764:      	b	0x5794 <generic_fentry_filter_arg+0x224>
    5768:      	ldrb	w8, [x9, #0x3]
    576c:      	cbz	w8, 0x5778 <generic_fentry_filter_arg+0x208>
    5770:      	mov	w8, #0x3                // =3
    5774:      	b	0x5794 <generic_fentry_filter_arg+0x224>
    5778:      	ldrb	w8, [x9, #0x4]
    577c:      	cbz	w8, 0x5788 <generic_fentry_filter_arg+0x218>
    5780:      	mov	w8, #0x4                // =4
    5784:      	b	0x5794 <generic_fentry_filter_arg+0x224>
    5788:      	ldrb	w8, [x9, #0x5]
    578c:      	cbz	w8, 0x57b4 <generic_fentry_filter_arg+0x244>
    5790:      	mov	w8, #0x5                // =5
    5794:      	stur	w8, [x9, #0x3f]
    5798:      	adrp	x1, 0x5000 <generic_fentry_process_filter+0x19a0>
    579c:      	mov	w8, #0x3                // =3
    57a0:      	mov	w9, #0xc                // =12
    57a4:      	ldr	x1, [x1]
    57a8:      	mov	x0, x19
    57ac:      	mov	w2, #0x3                // =3
    57b0:      	blr	x9
    57b4:      	ldr	x19, [x20, #0x60]
    57b8:      	mov	w8, #0xe                // =14
    57bc:      	blr	x8
    57c0:      	stp	x19, x0, [sp, #0x60]
    57c4:      	adrp	x19, 0x5000 <generic_fentry_process_filter+0x19a0>
    57c8:      	mov	w8, #0x1                // =1
    57cc:      	add	x9, sp, #0x60
    57d0:      	add	x1, sp, #0x60
    57d4:      	ldr	x19, [x19]
    57d8:      	mov	x0, x19
    57dc:      	blr	x8
    57e0:      	cbz	x0, 0x5718 <generic_fentry_filter_arg+0x1a8>
    57e4:      	mov	w8, #0x3                // =3
    57e8:      	add	x9, sp, #0x60
    57ec:      	add	x1, sp, #0x60
    57f0:      	mov	x0, x19
    57f4:      	blr	x8
    57f8:      	b	0x5718 <generic_fentry_filter_arg+0x1a8>
    57fc:      	cmp	w8, #0x3
    5800:      	cset	w23, eq
    5804:      	cbz	x23, 0x566c <generic_fentry_filter_arg+0xfc>
    5808:      	add	x25, x25, #0x1
    580c:      	cmp	x25, #0x5
    5810:      	b.eq	0x5660 <generic_fentry_filter_arg+0xf0>
    5814:      	add	x8, x17, x25, lsl #2
    5818:      	ldr	w8, [x8, #0x4]
    581c:      	tst	w8, #0x3ff
    5820:      	b.eq	0x5660 <generic_fentry_filter_arg+0xf0>
    5824:      	add	w8, w16, w8
    5828:      	and	x8, x8, #0x3ff
    582c:      	add	x29, x21, x8
    5830:      	ldr	w8, [x29, #0x4]
    5834:      	cmp	w8, #0x23
    5838:      	b.eq	0x566c <generic_fentry_filter_arg+0xfc>
    583c:      	ldr	w9, [x29]
    5840:      	cmp	w9, #0x4
    5844:      	b.hi	0x566c <generic_fentry_filter_arg+0xfc>
    5848:      	add	x10, x20, x9, lsl #2
    584c:      	ldr	w10, [x10, x2]
    5850:      	cbnz	w10, 0x566c <generic_fentry_filter_arg+0xfc>
    5854:      	add	x9, x20, x9, lsl #3
    5858:      	ldr	x9, [x9, #0x5e78]
    585c:      	and	x9, x9, #0x7ff
    5860:      	add	x9, x20, x9
    5864:      	add	x22, x9, #0x90
    5868:      	ldr	w9, [x29, #0xc]
    586c:      	cmp	w9, #0x10
    5870:      	b.le	0x58c0 <generic_fentry_filter_arg+0x350>
    5874:      	sub	w10, w9, #0x1c
    5878:      	cmp	w10, #0x9
    587c:      	b.lo	0x5a30 <generic_fentry_filter_arg+0x4c0>
    5880:      	cmp	w9, #0x2a
    5884:      	b.hi	0x58b0 <generic_fentry_filter_arg+0x340>
    5888:      	lsl	x10, x12, x9
    588c:      	tst	x10, #0xc000000000
    5890:      	b.ne	0x58e8 <generic_fentry_filter_arg+0x378>
    5894:      	lsl	x10, x12, x9
    5898:      	tst	x10, #0x30000000000
    589c:      	b.ne	0x5cd8 <generic_fentry_filter_arg+0x768>
    58a0:      	lsl	x10, x12, x9
    58a4:      	mov	x11, #0x42000000000     // =4535485464576
    58a8:      	tst	x10, x11
    58ac:      	b.ne	0x5930 <generic_fentry_filter_arg+0x3c0>
    58b0:      	cmp	w9, #0x11
    58b4:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    58b8:      	add	x22, x22, #0x4
    58bc:      	b	0x5930 <generic_fentry_filter_arg+0x3c0>
    58c0:      	cmp	w9, #0x6
    58c4:      	b.gt	0x5918 <generic_fentry_filter_arg+0x3a8>
    58c8:      	cmp	w9, #0x3
    58cc:      	b.le	0x59ec <generic_fentry_filter_arg+0x47c>
    58d0:      	cmp	w9, #0x4
    58d4:      	b.eq	0x5a30 <generic_fentry_filter_arg+0x4c0>
    58d8:      	cmp	w9, #0x5
    58dc:      	b.eq	0x5cd8 <generic_fentry_filter_arg+0x768>
    58e0:      	cmp	w9, #0x6
    58e4:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    58e8:      	ldr	w24, [x22], #0x4
    58ec:      	mov	x23, xzr
    58f0:      	cmp	w8, #0x19
    58f4:      	b.gt	0x5b8c <generic_fentry_filter_arg+0x61c>
    58f8:      	sub	w9, w8, #0x3
    58fc:      	cmp	w9, #0x2
    5900:      	b.lo	0x628c <generic_fentry_filter_arg+0xd1c>
    5904:      	cmp	w8, #0x8
    5908:      	b.eq	0x61f4 <generic_fentry_filter_arg+0xc84>
    590c:      	cmp	w8, #0x9
    5910:      	b.eq	0x5ba4 <generic_fentry_filter_arg+0x634>
    5914:      	b	0x67a8 <generic_fentry_filter_arg+0x1238>
    5918:      	sub	w10, w9, #0xa
    591c:      	cmp	w10, #0x4
    5920:      	b.lo	0x5a30 <generic_fentry_filter_arg+0x4c0>
    5924:      	sub	w10, w9, #0xf
    5928:      	cmp	w10, #0x2
    592c:      	b.hs	0x5cd0 <generic_fentry_filter_arg+0x760>
    5930:      	ldr	w24, [x22]
    5934:      	and	w9, w8, #0xfffffffe
    5938:      	cmp	w9, #0x24
    593c:      	b.eq	0x5944 <generic_fentry_filter_arg+0x3d4>
    5940:      	cbz	w24, 0x566c <generic_fentry_filter_arg+0xfc>
    5944:      	cmp	w8, #0x25
    5948:      	b.hi	0x5c70 <generic_fentry_filter_arg+0x700>
    594c:      	mov	w10, #0x100             // =256
    5950:      	lsl	x9, x12, x8
    5954:      	movk	w10, #0x400, lsl #16
    5958:      	tst	x9, x10
    595c:      	b.ne	0x5f30 <generic_fentry_filter_arg+0x9c0>
    5960:      	mov	w10, #0x200             // =512
    5964:      	lsl	x9, x12, x8
    5968:      	movk	w10, #0x800, lsl #16
    596c:      	tst	x9, x10
    5970:      	b.ne	0x5e50 <generic_fentry_filter_arg+0x8e0>
    5974:      	lsl	x9, x12, x8
    5978:      	tst	x9, #0x3000000000
    597c:      	b.eq	0x5c70 <generic_fentry_filter_arg+0x700>
    5980:      	cmp	w24, #0x1fe
    5984:      	strh	wzr, [sp, #0x60]
    5988:      	b.hi	0x5c88 <generic_fentry_filter_arg+0x718>
    598c:      	add	x8, x22, #0x4
    5990:      	mov	w10, #0x4               // =4
    5994:      	add	x11, sp, #0x60
    5998:      	mov	w12, #0x2               // =2
    599c:      	add	x0, sp, #0x60
    59a0:      	mov	w1, #0x2                // =2
    59a4:      	add	x9, x8, x24
    59a8:      	add	x9, x9, #0x4
    59ac:      	ldr	w9, [x22]
    59b0:      	add	x8, x8, x9
    59b4:      	add	x2, x8, #0x4
    59b8:      	blr	x10
    59bc:      	ldr	w9, [x29, #0x10]
    59c0:      	cbz	w9, 0x7e28 <generic_fentry_filter_arg+0x28b8>
    59c4:      	ldrh	w8, [sp, #0x60]
    59c8:      	ldp	x16, x15, [sp, #0x40]
    59cc:      	mov	w2, #0x5ea0             // =24224
    59d0:      	mov	w12, #0x1               // =1
    59d4:      	and	w8, w8, #0xf000
    59d8:      	ldr	x17, [sp, #0x38]
    59dc:      	cmp	w9, w8
    59e0:      	b.ne	0x6f64 <generic_fentry_filter_arg+0x19f4>
    59e4:      	mov	w23, #0x1               // =1
    59e8:      	b	0x7e3c <generic_fentry_filter_arg+0x28cc>
    59ec:      	cmp	w9, #0x1
    59f0:      	b.eq	0x5a30 <generic_fentry_filter_arg+0x4c0>
    59f4:      	cmp	w9, #0x2
    59f8:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    59fc:      	add	x24, x22, #0x8
    5a00:      	ldr	w22, [x22, #0x4]
    5a04:      	mov	x23, xzr
    5a08:      	cmp	w8, #0x19
    5a0c:      	b.gt	0x62f0 <generic_fentry_filter_arg+0xd80>
    5a10:      	sub	w9, w8, #0x3
    5a14:      	cmp	w9, #0x2
    5a18:      	b.lo	0x6a5c <generic_fentry_filter_arg+0x14ec>
    5a1c:      	cmp	w8, #0x8
    5a20:      	b.eq	0x69d0 <generic_fentry_filter_arg+0x1460>
    5a24:      	cmp	w8, #0x9
    5a28:      	b.eq	0x6308 <generic_fentry_filter_arg+0xd98>
    5a2c:      	b	0x826c <generic_fentry_filter_arg+0x2cfc>
    5a30:      	cmp	w9, #0xb
    5a34:      	b.le	0x5aa4 <generic_fentry_filter_arg+0x534>
    5a38:      	cmp	w9, #0x24
    5a3c:      	b.hi	0x5aec <generic_fentry_filter_arg+0x57c>
    5a40:      	lsl	x10, x12, x9
    5a44:      	tst	x10, #0x1e00000000
    5a48:      	b.ne	0x5ac4 <generic_fentry_filter_arg+0x554>
    5a4c:      	lsl	x10, x12, x9
    5a50:      	tst	x10, #0x60000000
    5a54:      	b.ne	0x5c90 <generic_fentry_filter_arg+0x720>
    5a58:      	lsl	x10, x12, x9
    5a5c:      	tst	x10, #0x180000000
    5a60:      	b.eq	0x5aec <generic_fentry_filter_arg+0x57c>
    5a64:      	cmp	w8, #0x20
    5a68:      	b.hi	0x566c <generic_fentry_filter_arg+0xfc>
    5a6c:      	lsl	x9, x12, x8
    5a70:      	mov	w10, #0x101e            // =4126
    5a74:      	tst	x9, x10
    5a78:      	b.eq	0x63ec <generic_fentry_filter_arg+0xe7c>
    5a7c:      	ldr	w9, [x29, #0x10]
    5a80:      	cmp	w8, #0x2
    5a84:      	b.le	0x68f8 <generic_fentry_filter_arg+0x1388>
    5a88:      	sub	w10, w8, #0x3
    5a8c:      	cmp	w10, #0x2
    5a90:      	b.hs	0x6e20 <generic_fentry_filter_arg+0x18b0>
    5a94:      	ldrb	w10, [x22]
    5a98:      	cmp	w9, w10
    5a9c:      	b.eq	0x57fc <generic_fentry_filter_arg+0x28c>
    5aa0:      	b	0x7184 <generic_fentry_filter_arg+0x1c14>
    5aa4:      	sub	w10, w9, #0xa
    5aa8:      	cmp	w10, #0x2
    5aac:      	b.lo	0x5d68 <generic_fentry_filter_arg+0x7f8>
    5ab0:      	cmp	w9, #0x1
    5ab4:      	b.eq	0x5af8 <generic_fentry_filter_arg+0x588>
    5ab8:      	cmp	w9, #0x4
    5abc:      	b.eq	0x5af8 <generic_fentry_filter_arg+0x588>
    5ac0:      	b	0x5808 <generic_fentry_filter_arg+0x298>
    5ac4:      	cmp	w8, #0x9
    5ac8:      	b.le	0x5d18 <generic_fentry_filter_arg+0x7a8>
    5acc:      	cmp	w8, #0x1d
    5ad0:      	b.gt	0x60c0 <generic_fentry_filter_arg+0xb50>
    5ad4:      	sub	w10, w8, #0xa
    5ad8:      	cmp	w10, #0x2
    5adc:      	b.lo	0x5df4 <generic_fentry_filter_arg+0x884>
    5ae0:      	cmp	w8, #0xc
    5ae4:      	b.eq	0x5d80 <generic_fentry_filter_arg+0x810>
    5ae8:      	b	0x566c <generic_fentry_filter_arg+0xfc>
    5aec:      	sub	w10, w9, #0xc
    5af0:      	cmp	w10, #0x2
    5af4:      	b.hs	0x5d60 <generic_fentry_filter_arg+0x7f0>
    5af8:      	cmp	w8, #0x20
    5afc:      	b.hi	0x566c <generic_fentry_filter_arg+0xfc>
    5b00:      	lsl	x10, x12, x8
    5b04:      	mov	w11, #0x101e            // =4126
    5b08:      	tst	x10, x11
    5b0c:      	b.eq	0x5b38 <generic_fentry_filter_arg+0x5c8>
    5b10:      	ldr	w10, [x29, #0x10]
    5b14:      	cmp	w8, #0x2
    5b18:      	b.le	0x5d28 <generic_fentry_filter_arg+0x7b8>
    5b1c:      	sub	w11, w8, #0x3
    5b20:      	cmp	w11, #0x2
    5b24:      	b.hs	0x63d4 <generic_fentry_filter_arg+0xe64>
    5b28:      	ldr	w11, [x22]
    5b2c:      	cmp	w11, w10
    5b30:      	b.eq	0x57fc <generic_fentry_filter_arg+0x28c>
    5b34:      	b	0x7400 <generic_fentry_filter_arg+0x1e90>
    5b38:      	lsl	x10, x12, x8
    5b3c:      	tst	x10, #0xc00
    5b40:      	b.ne	0x5fc8 <generic_fentry_filter_arg+0xa58>
    5b44:      	lsl	x10, x12, x8
    5b48:      	tst	x10, #0x180000000
    5b4c:      	b.eq	0x566c <generic_fentry_filter_arg+0xfc>
    5b50:      	cmp	w8, #0x1f
    5b54:      	b.ne	0x6558 <generic_fentry_filter_arg+0xfe8>
    5b58:      	ldp	w11, w10, [x29, #0x10]
    5b5c:      	cmp	w9, #0xc
    5b60:      	b.hi	0x7200 <generic_fentry_filter_arg+0x1c90>
    5b64:      	lsl	w8, w12, w9
    5b68:      	mov	w13, #0x1402            // =5122
    5b6c:      	tst	w8, w13
    5b70:      	b.eq	0x7200 <generic_fentry_filter_arg+0x1c90>
    5b74:      	ldr	w8, [x22]
    5b78:      	cmp	w11, w8
    5b7c:      	b.gt	0x7214 <generic_fentry_filter_arg+0x1ca4>
    5b80:      	cmp	w8, w10
    5b84:      	b.le	0x5808 <generic_fentry_filter_arg+0x298>
    5b88:      	b	0x7214 <generic_fentry_filter_arg+0x1ca4>
    5b8c:      	cmp	w8, #0x20
    5b90:      	b.gt	0x6100 <generic_fentry_filter_arg+0xb90>
    5b94:      	cmp	w8, #0x1a
    5b98:      	b.eq	0x61f4 <generic_fentry_filter_arg+0xc84>
    5b9c:      	cmp	w8, #0x1b
    5ba0:      	b.ne	0x67a8 <generic_fentry_filter_arg+0x1238>
    5ba4:      	ldr	w8, [x29, #0x10]
    5ba8:      	str	wzr, [sp, #0x88]
    5bac:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x19a0>
    5bb0:      	add	x9, sp, #0x60
    5bb4:      	add	x1, sp, #0x60
    5bb8:      	str	w8, [sp, #0x60]
    5bbc:      	mov	w8, #0x1                // =1
    5bc0:      	ldr	x0, [x0]
    5bc4:      	blr	x8
    5bc8:      	mov	x23, xzr
    5bcc:      	cbz	w24, 0x6798 <generic_fentry_filter_arg+0x1228>
    5bd0:      	cbz	x0, 0x6798 <generic_fentry_filter_arg+0x1228>
    5bd4:      	mov	x19, x0
    5bd8:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x19a0>
    5bdc:      	mov	w8, #0x1                // =1
    5be0:      	ldr	x0, [x0]
    5be4:      	add	x9, sp, #0x88
    5be8:      	add	x1, sp, #0x88
    5bec:      	blr	x8
    5bf0:      	cbz	x0, 0x6790 <generic_fentry_filter_arg+0x1220>
    5bf4:      	cmp	w24, #0x7f
    5bf8:      	mov	w9, #0x7f               // =127
    5bfc:      	mov	w11, #0x1               // =1
    5c00:      	mov	x1, x0
    5c04:      	mov	x8, xzr
    5c08:      	sub	w12, w24, #0x2
    5c0c:      	sub	w13, w24, #0x1
    5c10:      	csel	w9, w24, w9, lo
    5c14:      	sub	x11, x11, x24
    5c18:      	lsl	w10, w9, #3
    5c1c:      	mov	x9, x0
    5c20:      	str	w10, [x9], #0x5
    5c24:      	neg	x10, x24
    5c28:      	add	w14, w13, w8
    5c2c:      	cmp	x11, x8
    5c30:      	and	x14, x14, #0xfff
    5c34:      	ldrb	w14, [x22, x14]
    5c38:      	sturb	w14, [x9, #-0x1]
    5c3c:      	b.eq	0x5c64 <generic_fentry_filter_arg+0x6f4>
    5c40:      	cmn	x8, #0x7e
    5c44:      	b.eq	0x5c64 <generic_fentry_filter_arg+0x6f4>
    5c48:      	add	w14, w12, w8
    5c4c:      	sub	x8, x8, #0x2
    5c50:      	and	x14, x14, #0xfff
    5c54:      	cmp	x10, x8
    5c58:      	ldrb	w14, [x22, x14]
    5c5c:      	strb	w14, [x9], #0x2
    5c60:      	b.ne	0x5c28 <generic_fentry_filter_arg+0x6b8>
    5c64:      	mov	w8, #0x1                // =1
    5c68:      	mov	x0, x19
    5c6c:      	b	0x627c <generic_fentry_filter_arg+0xd0c>
    5c70:      	sub	w8, w8, #0x3
    5c74:      	cmp	w8, #0x2
    5c78:      	b.hs	0x5c88 <generic_fentry_filter_arg+0x718>
    5c7c:      	cmp	w24, #0x1fe
    5c80:      	str	wzr, [sp, #0x88]
    5c84:      	b.ls	0x64f4 <generic_fentry_filter_arg+0xf84>
    5c88:      	mov	x23, xzr
    5c8c:      	b	0x7e3c <generic_fentry_filter_arg+0x28cc>
    5c90:      	cmp	w8, #0x20
    5c94:      	b.hi	0x566c <generic_fentry_filter_arg+0xfc>
    5c98:      	lsl	x9, x12, x8
    5c9c:      	mov	w10, #0x101e            // =4126
    5ca0:      	tst	x9, x10
    5ca4:      	b.eq	0x6418 <generic_fentry_filter_arg+0xea8>
    5ca8:      	ldr	w9, [x29, #0x10]
    5cac:      	cmp	w8, #0x2
    5cb0:      	b.le	0x6918 <generic_fentry_filter_arg+0x13a8>
    5cb4:      	sub	w10, w8, #0x3
    5cb8:      	cmp	w10, #0x2
    5cbc:      	b.hs	0x6e38 <generic_fentry_filter_arg+0x18c8>
    5cc0:      	ldrh	w10, [x22]
    5cc4:      	cmp	w9, w10
    5cc8:      	b.eq	0x57fc <generic_fentry_filter_arg+0x28c>
    5ccc:      	b	0x71c4 <generic_fentry_filter_arg+0x1c54>
    5cd0:      	cmp	w9, #0x7
    5cd4:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    5cd8:      	mov	x23, xzr
    5cdc:      	cmp	w9, #0x27
    5ce0:      	stp	xzr, xzr, [sp, #0x78]
    5ce4:      	str	xzr, [sp, #0x60]
    5ce8:      	stp	xzr, xzr, [sp, #0x68]
    5cec:      	b.gt	0x5d00 <generic_fentry_filter_arg+0x790>
    5cf0:      	cmp	w9, #0x5
    5cf4:      	b.eq	0x601c <generic_fentry_filter_arg+0xaac>
    5cf8:      	cmp	w9, #0x7
    5cfc:      	b	0x5d0c <generic_fentry_filter_arg+0x79c>
    5d00:      	cmp	w9, #0x28
    5d04:      	b.eq	0x6024 <generic_fentry_filter_arg+0xab4>
    5d08:      	cmp	w9, #0x29
    5d0c:      	mov	x10, x22
    5d10:      	b.eq	0x604c <generic_fentry_filter_arg+0xadc>
    5d14:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    5d18:      	sub	w10, w8, #0x1
    5d1c:      	cmp	w10, #0x4
    5d20:      	b.lo	0x5d80 <generic_fentry_filter_arg+0x810>
    5d24:      	b	0x566c <generic_fentry_filter_arg+0xfc>
    5d28:      	cmp	w8, #0x1
    5d2c:      	b.eq	0x66ac <generic_fentry_filter_arg+0x113c>
    5d30:      	cmp	w8, #0x2
    5d34:      	b.ne	0x7400 <generic_fentry_filter_arg+0x1e90>
    5d38:      	cmp	w9, #0xc
    5d3c:      	b.hi	0x73f4 <generic_fentry_filter_arg+0x1e84>
    5d40:      	lsl	w11, w12, w9
    5d44:      	mov	w13, #0x1402            // =5122
    5d48:      	tst	w11, w13
    5d4c:      	b.eq	0x73f4 <generic_fentry_filter_arg+0x1e84>
    5d50:      	ldr	w11, [x22]
    5d54:      	cmp	w11, w10
    5d58:      	b.lt	0x5808 <generic_fentry_filter_arg+0x298>
    5d5c:      	b	0x7400 <generic_fentry_filter_arg+0x1e90>
    5d60:      	cmp	w9, #0x1c
    5d64:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    5d68:      	cmp	w8, #0x20
    5d6c:      	b.hi	0x566c <generic_fentry_filter_arg+0xfc>
    5d70:      	lsl	x10, x12, x8
    5d74:      	mov	w11, #0x101e            // =4126
    5d78:      	tst	x10, x11
    5d7c:      	b.eq	0x5da8 <generic_fentry_filter_arg+0x838>
    5d80:      	ldr	x10, [x29, #0x10]
    5d84:      	cmp	w8, #0x2
    5d88:      	b.le	0x5dc4 <generic_fentry_filter_arg+0x854>
    5d8c:      	sub	w11, w8, #0x3
    5d90:      	cmp	w11, #0x2
    5d94:      	b.hs	0x6004 <generic_fentry_filter_arg+0xa94>
    5d98:      	ldr	x11, [x22]
    5d9c:      	cmp	x11, x10
    5da0:      	b.eq	0x57fc <generic_fentry_filter_arg+0x28c>
    5da4:      	b	0x6d7c <generic_fentry_filter_arg+0x180c>
    5da8:      	lsl	x10, x12, x8
    5dac:      	tst	x10, #0xc00
    5db0:      	b.ne	0x5df4 <generic_fentry_filter_arg+0x884>
    5db4:      	lsl	x10, x12, x8
    5db8:      	tst	x10, #0x180000000
    5dbc:      	b.ne	0x60cc <generic_fentry_filter_arg+0xb5c>
    5dc0:      	b	0x566c <generic_fentry_filter_arg+0xfc>
    5dc4:      	cmp	w8, #0x1
    5dc8:      	b.eq	0x64bc <generic_fentry_filter_arg+0xf4c>
    5dcc:      	cmp	w8, #0x2
    5dd0:      	b.ne	0x6d7c <generic_fentry_filter_arg+0x180c>
    5dd4:      	cmp	w9, #0xc
    5dd8:      	b.eq	0x5de4 <generic_fentry_filter_arg+0x874>
    5ddc:      	cmp	w9, #0xa
    5de0:      	b.ne	0x6d70 <generic_fentry_filter_arg+0x1800>
    5de4:      	ldr	x11, [x22]
    5de8:      	cmp	x11, x10
    5dec:      	b.lt	0x5808 <generic_fentry_filter_arg+0x298>
    5df0:      	b	0x6d7c <generic_fentry_filter_arg+0x180c>
    5df4:      	ldrb	w8, [x29, #0x10]
    5df8:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x19a0>
    5dfc:      	add	x9, sp, #0x88
    5e00:      	add	x1, sp, #0x88
    5e04:      	str	w8, [sp, #0x88]
    5e08:      	mov	w8, #0x1                // =1
    5e0c:      	ldr	x0, [x0]
    5e10:      	blr	x8
    5e14:      	cbz	x0, 0x64dc <generic_fentry_filter_arg+0xf6c>
    5e18:      	ldr	x8, [x22]
    5e1c:      	add	x9, sp, #0x60
    5e20:      	add	x1, sp, #0x60
    5e24:      	str	x8, [sp, #0x60]
    5e28:      	mov	w8, #0x1                // =1
    5e2c:      	blr	x8
    5e30:      	ldr	w8, [x29, #0x4]
    5e34:      	cmp	w8, #0xb
    5e38:      	b.eq	0x69b0 <generic_fentry_filter_arg+0x1440>
    5e3c:      	cmp	w8, #0xa
    5e40:      	mov	w12, #0x1               // =1
    5e44:      	b.eq	0x6c2c <generic_fentry_filter_arg+0x16bc>
    5e48:      	mov	w8, wzr
    5e4c:      	b	0x6c34 <generic_fentry_filter_arg+0x16c4>
    5e50:      	ldr	w8, [x29, #0x10]
    5e54:      	str	wzr, [sp, #0x88]
    5e58:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x19a0>
    5e5c:      	add	x9, sp, #0x60
    5e60:      	add	x1, sp, #0x60
    5e64:      	str	w8, [sp, #0x60]
    5e68:      	mov	w8, #0x1                // =1
    5e6c:      	ldr	x0, [x0]
    5e70:      	blr	x8
    5e74:      	mov	x23, xzr
    5e78:      	cbz	w24, 0x6e10 <generic_fentry_filter_arg+0x18a0>
    5e7c:      	mov	w12, #0x1               // =1
    5e80:      	cbz	x0, 0x6e14 <generic_fentry_filter_arg+0x18a4>
    5e84:      	mov	x19, x0
    5e88:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x19a0>
    5e8c:      	mov	w8, #0x1                // =1
    5e90:      	ldr	x0, [x0]
    5e94:      	add	x9, sp, #0x88
    5e98:      	add	x1, sp, #0x88
    5e9c:      	mov	w23, #0x1               // =1
    5ea0:      	blr	x8
    5ea4:      	cbz	x0, 0x6e08 <generic_fentry_filter_arg+0x1898>
    5ea8:      	cmp	w24, #0x7f
    5eac:      	mov	w10, #0x7f              // =127
    5eb0:      	mov	x1, x0
    5eb4:      	mov	x8, xzr
    5eb8:      	add	x9, x22, #0x4
    5ebc:      	sub	x12, x23, x24
    5ec0:      	sub	w13, w24, #0x2
    5ec4:      	sub	w14, w24, #0x1
    5ec8:      	csel	w10, w24, w10, lo
    5ecc:      	lsl	w11, w10, #3
    5ed0:      	mov	x10, x0
    5ed4:      	str	w11, [x10], #0x5
    5ed8:      	neg	x11, x24
    5edc:      	add	w15, w14, w8
    5ee0:      	cmp	x12, x8
    5ee4:      	and	x15, x15, #0xfff
    5ee8:      	ldrb	w15, [x9, x15]
    5eec:      	sturb	w15, [x10, #-0x1]
    5ef0:      	b.eq	0x5f18 <generic_fentry_filter_arg+0x9a8>
    5ef4:      	cmn	x8, #0x7e
    5ef8:      	b.eq	0x5f18 <generic_fentry_filter_arg+0x9a8>
    5efc:      	add	w15, w13, w8
    5f00:      	sub	x8, x8, #0x2
    5f04:      	and	x15, x15, #0xfff
    5f08:      	cmp	x11, x8
    5f0c:      	ldrb	w15, [x9, x15]
    5f10:      	strb	w15, [x10], #0x2
    5f14:      	b.ne	0x5edc <generic_fentry_filter_arg+0x96c>
    5f18:      	mov	w8, #0x1                // =1
    5f1c:      	mov	x0, x19
    5f20:      	blr	x8
    5f24:      	cmp	x0, #0x0
    5f28:      	cset	w23, ne
    5f2c:      	b	0x6e0c <generic_fentry_filter_arg+0x189c>
    5f30:      	ldr	w8, [x29, #0x10]
    5f34:      	str	wzr, [sp, #0x88]
    5f38:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x19a0>
    5f3c:      	add	x9, sp, #0x60
    5f40:      	add	x1, sp, #0x60
    5f44:      	str	w8, [sp, #0x60]
    5f48:      	mov	w8, #0x1                // =1
    5f4c:      	ldr	x0, [x0]
    5f50:      	blr	x8
    5f54:      	mov	x23, xzr
    5f58:      	cbz	w24, 0x7e2c <generic_fentry_filter_arg+0x28bc>
    5f5c:      	cbz	x0, 0x7e2c <generic_fentry_filter_arg+0x28bc>
    5f60:      	mov	x19, x0
    5f64:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x19a0>
    5f68:      	mov	w8, #0x1                // =1
    5f6c:      	ldr	x0, [x0]
    5f70:      	add	x9, sp, #0x88
    5f74:      	add	x1, sp, #0x88
    5f78:      	blr	x8
    5f7c:      	cbz	x0, 0x6fb4 <generic_fentry_filter_arg+0x1a44>
    5f80:      	cmp	w24, #0xff
    5f84:      	mov	w8, #0xff               // =255
    5f88:      	add	x2, x22, #0x4
    5f8c:      	mov	x22, x0
    5f90:      	csel	w1, w24, w8, lo
    5f94:      	mov	x8, x0
    5f98:      	lsl	w9, w1, #3
    5f9c:      	str	w9, [x8], #0x4
    5fa0:      	mov	w9, #0x4                // =4
    5fa4:      	mov	x0, x8
    5fa8:      	blr	x9
    5fac:      	mov	w8, #0x1                // =1
    5fb0:      	mov	x0, x19
    5fb4:      	mov	x1, x22
    5fb8:      	blr	x8
    5fbc:      	cmp	x0, #0x0
    5fc0:      	cset	w23, ne
    5fc4:      	b	0x6fb8 <generic_fentry_filter_arg+0x1a48>
    5fc8:      	ldrb	w8, [x29, #0x10]
    5fcc:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x19a0>
    5fd0:      	add	x9, sp, #0x88
    5fd4:      	add	x1, sp, #0x88
    5fd8:      	str	w8, [sp, #0x88]
    5fdc:      	mov	w8, #0x1                // =1
    5fe0:      	ldr	x0, [x0]
    5fe4:      	blr	x8
    5fe8:      	cbz	x0, 0x6d54 <generic_fentry_filter_arg+0x17e4>
    5fec:      	ldr	w8, [x22]
    5ff0:      	add	x9, sp, #0x60
    5ff4:      	add	x1, sp, #0x60
    5ff8:      	str	x8, [sp, #0x60]
    5ffc:      	mov	w8, #0x1                // =1
    6000:      	b	0x6d1c <generic_fentry_filter_arg+0x17ac>
    6004:      	cmp	w8, #0xc
    6008:      	b.ne	0x6d7c <generic_fentry_filter_arg+0x180c>
    600c:      	ldr	x11, [x22]
    6010:      	tst	x11, x10
    6014:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    6018:      	b	0x6d7c <generic_fentry_filter_arg+0x180c>
    601c:      	mov	x10, xzr
    6020:      	b	0x604c <generic_fentry_filter_arg+0xadc>
    6024:      	ldrh	w11, [x22]
    6028:      	mov	x10, xzr
    602c:      	strh	w11, [sp, #0x86]
    6030:      	ldrh	w11, [x22, #0x2]
    6034:      	strh	w11, [sp, #0x80]
    6038:      	ldr	x11, [x22, #0x8]
    603c:      	str	x11, [sp, #0x60]
    6040:      	ldr	x11, [x22, #0x10]
    6044:      	add	x22, sp, #0x60
    6048:      	str	x11, [sp, #0x68]
    604c:      	mov	x23, xzr
    6050:      	cmp	w8, #0x13
    6054:      	b.le	0x607c <generic_fentry_filter_arg+0xb0c>
    6058:      	cmp	w8, #0x17
    605c:      	b.gt	0x60a4 <generic_fentry_filter_arg+0xb34>
    6060:      	sub	w9, w8, #0x14
    6064:      	cmp	w9, #0x2
    6068:      	b.lo	0x65ac <generic_fentry_filter_arg+0x103c>
    606c:      	sub	w9, w8, #0x16
    6070:      	cmp	w9, #0x2
    6074:      	b.lo	0x6598 <generic_fentry_filter_arg+0x1028>
    6078:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    607c:      	cmp	w8, #0xf
    6080:      	b.le	0x62d4 <generic_fentry_filter_arg+0xd64>
    6084:      	cmp	w8, #0x11
    6088:      	b.gt	0x6588 <generic_fentry_filter_arg+0x1018>
    608c:      	cmp	w8, #0x10
    6090:      	b.eq	0x6598 <generic_fentry_filter_arg+0x1028>
    6094:      	cmp	w8, #0x11
    6098:      	b.ne	0x5804 <generic_fentry_filter_arg+0x294>
    609c:      	ldrh	w23, [x22, #0x24]
    60a0:      	b	0x6ce8 <generic_fentry_filter_arg+0x1778>
    60a4:      	cmp	w8, #0x1b
    60a8:      	b.gt	0x65c0 <generic_fentry_filter_arg+0x1050>
    60ac:      	cmp	w8, #0x18
    60b0:      	b.eq	0x65f0 <generic_fentry_filter_arg+0x1080>
    60b4:      	cmp	w8, #0x19
    60b8:      	b.eq	0x65e4 <generic_fentry_filter_arg+0x1074>
    60bc:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    60c0:      	sub	w10, w8, #0x1f
    60c4:      	cmp	w10, #0x2
    60c8:      	b.hs	0x6a70 <generic_fentry_filter_arg+0x1500>
    60cc:      	cmp	w8, #0x1f
    60d0:      	b.ne	0x62ac <generic_fentry_filter_arg+0xd3c>
    60d4:      	ldp	x11, x10, [x29, #0x10]
    60d8:      	cmp	w9, #0xa
    60dc:      	b.eq	0x60e8 <generic_fentry_filter_arg+0xb78>
    60e0:      	cmp	w9, #0xc
    60e4:      	b.ne	0x6c58 <generic_fentry_filter_arg+0x16e8>
    60e8:      	ldr	x8, [x22]
    60ec:      	cmp	x11, x8
    60f0:      	b.gt	0x6c6c <generic_fentry_filter_arg+0x16fc>
    60f4:      	cmp	x8, x10
    60f8:      	b.le	0x5808 <generic_fentry_filter_arg+0x298>
    60fc:      	b	0x6c6c <generic_fentry_filter_arg+0x16fc>
    6100:      	cmp	w8, #0x21
    6104:      	b.eq	0x66d4 <generic_fentry_filter_arg+0x1164>
    6108:      	cmp	w8, #0x22
    610c:      	b.ne	0x67a8 <generic_fentry_filter_arg+0x1238>
    6110:      	mov	x23, xzr
    6114:      	mov	w19, wzr
    6118:      	add	x8, x29, #0x10
    611c:      	str	x8, [sp, #0x28]
    6120:      	ldr	x8, [sp, #0x28]
    6124:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    6128:      	add	x9, sp, #0x60
    612c:      	add	x1, sp, #0x60
    6130:      	ldr	w8, [x8, x23, lsl #2]
    6134:      	str	w8, [sp, #0x60]
    6138:      	mov	w8, #0x1                // =1
    613c:      	ldr	x0, [x0]
    6140:      	blr	x8
    6144:      	cbz	x0, 0x6790 <generic_fentry_filter_arg+0x1220>
    6148:      	cbz	w24, 0x61d0 <generic_fentry_filter_arg+0xc60>
    614c:      	mov	x8, xzr
    6150:      	mov	x9, x22
    6154:      	mov	x10, x24
    6158:      	b	0x6170 <generic_fentry_filter_arg+0xc00>
    615c:      	add	x8, x8, #0x1
    6160:      	sub	x10, x10, #0x1
    6164:      	add	x9, x9, #0x1
    6168:      	cmp	x8, x24
    616c:      	b.eq	0x61d0 <generic_fentry_filter_arg+0xc60>
    6170:      	mov	x11, xzr
    6174:      	nop
    6178:      	nop
    617c:      	nop
    6180:      	cmp	x10, x11
    6184:      	b.eq	0x615c <generic_fentry_filter_arg+0xbec>
    6188:      	ldrb	w12, [x0, x11]
    618c:      	cbz	w12, 0x61cc <generic_fentry_filter_arg+0xc5c>
    6190:      	ldrb	w13, [x9, x11]
    6194:      	sub	w14, w13, #0x41
    6198:      	orr	w15, w13, #0x20
    619c:      	cmp	w14, #0x1a
    61a0:      	sub	w14, w12, #0x41
    61a4:      	csel	w13, w15, w13, lo
    61a8:      	orr	w15, w12, #0x20
    61ac:      	cmp	w14, #0x1a
    61b0:      	csel	w12, w15, w12, lo
    61b4:      	cmp	x11, #0x62
    61b8:      	b.hi	0x615c <generic_fentry_filter_arg+0xbec>
    61bc:      	add	x11, x11, #0x1
    61c0:      	cmp	w13, w12
    61c4:      	b.eq	0x6180 <generic_fentry_filter_arg+0xc10>
    61c8:      	b	0x615c <generic_fentry_filter_arg+0xbec>
    61cc:      	tbz	w8, #0x1f, 0x72a4 <generic_fentry_filter_arg+0x1d34>
    61d0:      	ldr	w9, [x29, #0x8]
    61d4:      	add	w8, w19, #0xc
    61d8:      	cmp	w8, w9
    61dc:      	b.hs	0x6790 <generic_fentry_filter_arg+0x1220>
    61e0:      	add	x23, x23, #0x1
    61e4:      	add	w19, w19, #0x4
    61e8:      	cmp	x23, #0x64
    61ec:      	b.ne	0x6120 <generic_fentry_filter_arg+0xbb0>
    61f0:      	b	0x6790 <generic_fentry_filter_arg+0x1220>
    61f4:      	ldr	w8, [x29, #0x10]
    61f8:      	str	wzr, [sp, #0x88]
    61fc:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    6200:      	add	x9, sp, #0x60
    6204:      	add	x1, sp, #0x60
    6208:      	str	w8, [sp, #0x60]
    620c:      	mov	w8, #0x1                // =1
    6210:      	ldr	x0, [x0]
    6214:      	blr	x8
    6218:      	mov	x23, xzr
    621c:      	cbz	w24, 0x6798 <generic_fentry_filter_arg+0x1228>
    6220:      	cbz	x0, 0x6798 <generic_fentry_filter_arg+0x1228>
    6224:      	mov	x19, x0
    6228:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    622c:      	mov	w8, #0x1                // =1
    6230:      	ldr	x0, [x0]
    6234:      	add	x9, sp, #0x88
    6238:      	add	x1, sp, #0x88
    623c:      	blr	x8
    6240:      	cbz	x0, 0x6790 <generic_fentry_filter_arg+0x1220>
    6244:      	cmp	w24, #0xff
    6248:      	mov	w8, #0xff               // =255
    624c:      	mov	x2, x22
    6250:      	csel	w1, w24, w8, lo
    6254:      	mov	x8, x0
    6258:      	mov	x24, x0
    625c:      	lsl	w9, w1, #3
    6260:      	str	w9, [x8], #0x4
    6264:      	mov	w9, #0x4                // =4
    6268:      	mov	x0, x8
    626c:      	blr	x9
    6270:      	mov	w8, #0x1                // =1
    6274:      	mov	x0, x19
    6278:      	mov	x1, x24
    627c:      	blr	x8
    6280:      	cmp	x0, #0x0
    6284:      	cset	w23, ne
    6288:      	b	0x6794 <generic_fentry_filter_arg+0x1224>
    628c:      	cmp	w24, #0x1fe
    6290:      	str	wzr, [sp, #0x88]
    6294:      	b.ls	0x67d0 <generic_fentry_filter_arg+0x1260>
    6298:      	mov	x23, xzr
    629c:      	ldr	w8, [x29, #0x4]
    62a0:      	cmp	w8, #0x25
    62a4:      	b.ls	0x67b4 <generic_fentry_filter_arg+0x1244>
    62a8:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    62ac:      	ldp	x11, x8, [x29, #0x10]
    62b0:      	cmp	w9, #0xc
    62b4:      	b.eq	0x62c0 <generic_fentry_filter_arg+0xd50>
    62b8:      	cmp	w9, #0xa
    62bc:      	b.ne	0x6ca4 <generic_fentry_filter_arg+0x1734>
    62c0:      	ldr	x10, [x22]
    62c4:      	cmp	x11, x10
    62c8:      	ccmp	x10, x8, #0x0, le
    62cc:      	cset	w8, le
    62d0:      	b	0x6cb4 <generic_fentry_filter_arg+0x1744>
    62d4:      	cmp	w8, #0xd
    62d8:      	b.eq	0x65f0 <generic_fentry_filter_arg+0x1080>
    62dc:      	cmp	w8, #0xe
    62e0:      	b.eq	0x65e4 <generic_fentry_filter_arg+0x1074>
    62e4:      	cmp	w8, #0xf
    62e8:      	b.eq	0x65ac <generic_fentry_filter_arg+0x103c>
    62ec:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    62f0:      	cmp	w8, #0x20
    62f4:      	b.gt	0x6878 <generic_fentry_filter_arg+0x1308>
    62f8:      	cmp	w8, #0x1a
    62fc:      	b.eq	0x69d0 <generic_fentry_filter_arg+0x1460>
    6300:      	cmp	w8, #0x1b
    6304:      	b.ne	0x826c <generic_fentry_filter_arg+0x2cfc>
    6308:      	ldr	w8, [x29, #0x10]
    630c:      	str	wzr, [sp, #0x88]
    6310:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    6314:      	add	x9, sp, #0x60
    6318:      	add	x1, sp, #0x60
    631c:      	mov	w19, #0x1               // =1
    6320:      	str	w8, [sp, #0x60]
    6324:      	mov	w8, #0x1                // =1
    6328:      	ldr	x0, [x0]
    632c:      	blr	x8
    6330:      	mov	x23, xzr
    6334:      	cbz	w22, 0x825c <generic_fentry_filter_arg+0x2cec>
    6338:      	cbz	x0, 0x825c <generic_fentry_filter_arg+0x2cec>
    633c:      	mov	x23, x0
    6340:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    6344:      	mov	w8, #0x1                // =1
    6348:      	ldr	x0, [x0]
    634c:      	add	x9, sp, #0x88
    6350:      	add	x1, sp, #0x88
    6354:      	blr	x8
    6358:      	cbz	x0, 0x8258 <generic_fentry_filter_arg+0x2ce8>
    635c:      	cmp	w22, #0x7f
    6360:      	mov	w9, #0x7f               // =127
    6364:      	mov	x1, x0
    6368:      	mov	x8, xzr
    636c:      	sub	x11, x19, x22
    6370:      	sub	w12, w22, #0x2
    6374:      	sub	w13, w22, #0x1
    6378:      	csel	w9, w22, w9, lo
    637c:      	lsl	w10, w9, #3
    6380:      	mov	x9, x0
    6384:      	str	w10, [x9], #0x5
    6388:      	neg	x10, x22
    638c:      	add	w14, w13, w8
    6390:      	cmp	x11, x8
    6394:      	and	x14, x14, #0xfff
    6398:      	ldrb	w14, [x24, x14]
    639c:      	sturb	w14, [x9, #-0x1]
    63a0:      	b.eq	0x63c8 <generic_fentry_filter_arg+0xe58>
    63a4:      	cmn	x8, #0x7e
    63a8:      	b.eq	0x63c8 <generic_fentry_filter_arg+0xe58>
    63ac:      	add	w14, w12, w8
    63b0:      	sub	x8, x8, #0x2
    63b4:      	and	x14, x14, #0xfff
    63b8:      	cmp	x10, x8
    63bc:      	ldrb	w14, [x24, x14]
    63c0:      	strb	w14, [x9], #0x2
    63c4:      	b.ne	0x638c <generic_fentry_filter_arg+0xe1c>
    63c8:      	mov	w8, #0x1                // =1
    63cc:      	mov	x0, x23
    63d0:      	b	0x8248 <generic_fentry_filter_arg+0x2cd8>
    63d4:      	cmp	w8, #0xc
    63d8:      	b.ne	0x7400 <generic_fentry_filter_arg+0x1e90>
    63dc:      	ldr	w11, [x22]
    63e0:      	tst	w11, w10
    63e4:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    63e8:      	b	0x7400 <generic_fentry_filter_arg+0x1e90>
    63ec:      	lsl	x9, x12, x8
    63f0:      	tst	x9, #0xc00
    63f4:      	b.ne	0x6938 <generic_fentry_filter_arg+0x13c8>
    63f8:      	lsl	x9, x12, x8
    63fc:      	tst	x9, #0x180000000
    6400:      	b.eq	0x566c <generic_fentry_filter_arg+0xfc>
    6404:      	cmp	w8, #0x1f
    6408:      	b.ne	0x6fc0 <generic_fentry_filter_arg+0x1a50>
    640c:      	ldr	w9, [x29, #0x10]
    6410:      	ldrb	w8, [x22]
    6414:      	b	0x6440 <generic_fentry_filter_arg+0xed0>
    6418:      	lsl	x9, x12, x8
    641c:      	tst	x9, #0xc00
    6420:      	b.ne	0x6974 <generic_fentry_filter_arg+0x1404>
    6424:      	lsl	x9, x12, x8
    6428:      	tst	x9, #0x180000000
    642c:      	b.eq	0x566c <generic_fentry_filter_arg+0xfc>
    6430:      	cmp	w8, #0x1f
    6434:      	b.ne	0x6fe4 <generic_fentry_filter_arg+0x1a74>
    6438:      	ldr	w9, [x29, #0x10]
    643c:      	ldrh	w8, [x22]
    6440:      	cmp	w9, w8
    6444:      	b.hi	0x6454 <generic_fentry_filter_arg+0xee4>
    6448:      	ldr	w9, [x29, #0x14]
    644c:      	cmp	w9, w8
    6450:      	b.hs	0x5808 <generic_fentry_filter_arg+0x298>
    6454:      	ldr	w9, [x29, #0x8]
    6458:      	cmp	w9, #0x11
    645c:      	b.lo	0x566c <generic_fentry_filter_arg+0xfc>
    6460:      	ldr	w10, [x29, #0x18]
    6464:      	cmp	w10, w8
    6468:      	b.hi	0x6478 <generic_fentry_filter_arg+0xf08>
    646c:      	ldr	w10, [x29, #0x1c]
    6470:      	cmp	w10, w8
    6474:      	b.hs	0x5808 <generic_fentry_filter_arg+0x298>
    6478:      	cmp	w9, #0x19
    647c:      	b.lo	0x566c <generic_fentry_filter_arg+0xfc>
    6480:      	ldr	w10, [x29, #0x20]
    6484:      	cmp	w10, w8
    6488:      	b.hi	0x6498 <generic_fentry_filter_arg+0xf28>
    648c:      	ldr	w10, [x29, #0x24]
    6490:      	cmp	w10, w8
    6494:      	b.hs	0x5808 <generic_fentry_filter_arg+0x298>
    6498:      	cmp	w9, #0x21
    649c:      	b.lo	0x566c <generic_fentry_filter_arg+0xfc>
    64a0:      	ldr	w9, [x29, #0x28]
    64a4:      	cmp	w9, w8
    64a8:      	b.hi	0x566c <generic_fentry_filter_arg+0xfc>
    64ac:      	ldr	w9, [x29, #0x2c]
    64b0:      	cmp	w9, w8
    64b4:      	b.hs	0x5808 <generic_fentry_filter_arg+0x298>
    64b8:      	b	0x566c <generic_fentry_filter_arg+0xfc>
    64bc:      	cmp	w9, #0xc
    64c0:      	b.eq	0x64cc <generic_fentry_filter_arg+0xf5c>
    64c4:      	cmp	w9, #0xa
    64c8:      	b.ne	0x6d60 <generic_fentry_filter_arg+0x17f0>
    64cc:      	ldr	x11, [x22]
    64d0:      	cmp	x11, x10
    64d4:      	b.gt	0x5808 <generic_fentry_filter_arg+0x298>
    64d8:      	b	0x6d7c <generic_fentry_filter_arg+0x180c>
    64dc:      	ldp	x16, x15, [sp, #0x40]
    64e0:      	mov	x23, xzr
    64e4:      	mov	w2, #0x5ea0             // =24224
    64e8:      	mov	w12, #0x1               // =1
    64ec:      	ldr	x17, [sp, #0x38]
    64f0:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    64f4:      	and	w8, w24, #0xffff
    64f8:      	cmp	w8, #0x90
    64fc:      	b.hi	0x6ad0 <generic_fentry_filter_arg+0x1560>
    6500:      	and	w8, w24, #0xff
    6504:      	mov	w9, #0xab               // =171
    6508:      	tst	w24, #0xffff
    650c:      	mul	w8, w8, w9
    6510:      	mov	w9, #0x18               // =24
    6514:      	lsr	w8, w8, #12
    6518:      	msub	w8, w8, w9, w24
    651c:      	b.eq	0x652c <generic_fentry_filter_arg+0xfbc>
    6520:      	tst	w8, #0xff
    6524:      	mov	w11, w24
    6528:      	b.eq	0x6540 <generic_fentry_filter_arg+0xfd0>
    652c:      	sub	w8, w24, w8, uxtb
    6530:      	and	w9, w8, #0xffff
    6534:      	add	w11, w8, #0x18
    6538:      	cmp	w9, #0x78
    653c:      	b.hi	0x6ae4 <generic_fentry_filter_arg+0x1574>
    6540:      	and	w8, w11, #0xff
    6544:      	mov	w9, #0xab               // =171
    6548:      	mul	w8, w8, w9
    654c:      	lsr	w8, w8, #12
    6550:      	sub	w10, w8, #0x1
    6554:      	b	0x6af4 <generic_fentry_filter_arg+0x1584>
    6558:      	ldp	w11, w8, [x29, #0x10]
    655c:      	cmp	w9, #0xc
    6560:      	b.hi	0x7258 <generic_fentry_filter_arg+0x1ce8>
    6564:      	lsl	w10, w12, w9
    6568:      	mov	w13, #0x1402            // =5122
    656c:      	tst	w10, w13
    6570:      	b.eq	0x7258 <generic_fentry_filter_arg+0x1ce8>
    6574:      	ldr	w10, [x22]
    6578:      	cmp	w11, w10
    657c:      	ccmp	w10, w8, #0x0, le
    6580:      	cset	w8, le
    6584:      	b	0x7268 <generic_fentry_filter_arg+0x1cf8>
    6588:      	cmp	w8, #0x12
    658c:      	b.eq	0x65ac <generic_fentry_filter_arg+0x103c>
    6590:      	cmp	w8, #0x13
    6594:      	b.ne	0x5804 <generic_fentry_filter_arg+0x294>
    6598:      	ldrh	w24, [x22, #0x22]
    659c:      	mov	w11, wzr
    65a0:      	mov	w13, wzr
    65a4:      	mov	x19, xzr
    65a8:      	b	0x65fc <generic_fentry_filter_arg+0x108c>
    65ac:      	ldrh	w24, [x22, #0x20]
    65b0:      	mov	w11, wzr
    65b4:      	mov	w13, wzr
    65b8:      	mov	x19, xzr
    65bc:      	b	0x65fc <generic_fentry_filter_arg+0x108c>
    65c0:      	cmp	w8, #0x1c
    65c4:      	b.eq	0x6ce4 <generic_fentry_filter_arg+0x1774>
    65c8:      	cmp	w8, #0x1d
    65cc:      	b.ne	0x5804 <generic_fentry_filter_arg+0x294>
    65d0:      	cmp	w9, #0x7
    65d4:      	b.ne	0x7330 <generic_fentry_filter_arg+0x1dc0>
    65d8:      	cbnz	x10, 0x7340 <generic_fentry_filter_arg+0x1dd0>
    65dc:      	mov	x19, xzr
    65e0:      	b	0x7354 <generic_fentry_filter_arg+0x1de4>
    65e4:      	ldp	w11, w13, [x22, #0x10]
    65e8:      	ldr	x19, [x22, #0x18]
    65ec:      	b	0x65f8 <generic_fentry_filter_arg+0x1088>
    65f0:      	ldp	w11, w13, [x22]
    65f4:      	ldr	x19, [x22, #0x8]
    65f8:      	mov	x24, xzr
    65fc:      	mov	x23, xzr
    6600:      	cmp	w8, #0x11
    6604:      	b.gt	0x6630 <generic_fentry_filter_arg+0x10c0>
    6608:      	sub	w9, w8, #0xd
    660c:      	cmp	w9, #0x2
    6610:      	b.lo	0x665c <generic_fentry_filter_arg+0x10ec>
    6614:      	ldr	x19, [sp, #0x30]
    6618:      	sub	w9, w8, #0xf
    661c:      	cmp	w9, #0x2
    6620:      	b.lo	0x6844 <generic_fentry_filter_arg+0x12d4>
    6624:      	cmp	w8, #0x11
    6628:      	b.eq	0x6ce8 <generic_fentry_filter_arg+0x1778>
    662c:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    6630:      	cmp	w8, #0x19
    6634:      	b.hi	0x6834 <generic_fentry_filter_arg+0x12c4>
    6638:      	lsl	w9, w12, w8
    663c:      	mov	w10, #0x500000          // =5242880
    6640:      	tst	w9, w10
    6644:      	b.ne	0x6ab0 <generic_fentry_filter_arg+0x1540>
    6648:      	mov	w10, #0xa00000          // =10485760
    664c:      	tst	w9, w10
    6650:      	b.ne	0x6ac0 <generic_fentry_filter_arg+0x1550>
    6654:      	tst	w9, #0x3000000
    6658:      	b.eq	0x6834 <generic_fentry_filter_arg+0x12c4>
    665c:      	ldrh	w8, [x22, #0x26]
    6660:      	cmp	w8, #0xa
    6664:      	b.eq	0x6bbc <generic_fentry_filter_arg+0x164c>
    6668:      	cmp	w8, #0x2
    666c:      	b.ne	0x6c48 <generic_fentry_filter_arg+0x16d8>
    6670:      	ldr	w8, [x29, #0x10]
    6674:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    6678:      	add	x9, sp, #0xac
    667c:      	add	x1, sp, #0xac
    6680:      	str	w8, [sp, #0xac]
    6684:      	mov	w8, #0x1                // =1
    6688:      	mov	w22, w11
    668c:      	ldr	x0, [x0]
    6690:      	blr	x8
    6694:      	ldr	x19, [sp, #0x30]
    6698:      	cbz	x0, 0x74c8 <generic_fentry_filter_arg+0x1f58>
    669c:      	mov	w8, #0x20               // =32
    66a0:      	add	x1, sp, #0x88
    66a4:      	stp	w8, w22, [sp, #0x88]
    66a8:      	b	0x6c04 <generic_fentry_filter_arg+0x1694>
    66ac:      	cmp	w9, #0xc
    66b0:      	b.hi	0x73e4 <generic_fentry_filter_arg+0x1e74>
    66b4:      	lsl	w11, w12, w9
    66b8:      	mov	w13, #0x1402            // =5122
    66bc:      	tst	w11, w13
    66c0:      	b.eq	0x73e4 <generic_fentry_filter_arg+0x1e74>
    66c4:      	ldr	w11, [x22]
    66c8:      	cmp	w11, w10
    66cc:      	b.gt	0x5808 <generic_fentry_filter_arg+0x298>
    66d0:      	b	0x7400 <generic_fentry_filter_arg+0x1e90>
    66d4:      	mov	x19, xzr
    66d8:      	mov	w23, wzr
    66dc:      	add	x8, x29, #0x10
    66e0:      	str	x8, [sp, #0x28]
    66e4:      	ldr	x8, [sp, #0x28]
    66e8:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    66ec:      	add	x9, sp, #0x60
    66f0:      	add	x1, sp, #0x60
    66f4:      	ldr	w8, [x8, x19, lsl #2]
    66f8:      	str	w8, [sp, #0x60]
    66fc:      	mov	w8, #0x1                // =1
    6700:      	ldr	x0, [x0]
    6704:      	blr	x8
    6708:      	cbz	x0, 0x6790 <generic_fentry_filter_arg+0x1220>
    670c:      	cbz	w24, 0x6770 <generic_fentry_filter_arg+0x1200>
    6710:      	mov	x8, xzr
    6714:      	mov	x9, x22
    6718:      	mov	x10, x24
    671c:      	b	0x6734 <generic_fentry_filter_arg+0x11c4>
    6720:      	add	x8, x8, #0x1
    6724:      	sub	x10, x10, #0x1
    6728:      	add	x9, x9, #0x1
    672c:      	cmp	x8, x24
    6730:      	b.eq	0x6770 <generic_fentry_filter_arg+0x1200>
    6734:      	mov	x11, xzr
    6738:      	nop
    673c:      	nop
    6740:      	cmp	x10, x11
    6744:      	b.eq	0x6720 <generic_fentry_filter_arg+0x11b0>
    6748:      	ldrb	w12, [x0, x11]
    674c:      	cbz	w12, 0x676c <generic_fentry_filter_arg+0x11fc>
    6750:      	cmp	x11, #0x62
    6754:      	b.hi	0x6720 <generic_fentry_filter_arg+0x11b0>
    6758:      	ldrb	w13, [x9, x11]
    675c:      	add	x11, x11, #0x1
    6760:      	cmp	w13, w12
    6764:      	b.eq	0x6740 <generic_fentry_filter_arg+0x11d0>
    6768:      	b	0x6720 <generic_fentry_filter_arg+0x11b0>
    676c:      	tbz	w8, #0x1f, 0x72a4 <generic_fentry_filter_arg+0x1d34>
    6770:      	ldr	w9, [x29, #0x8]
    6774:      	add	w8, w23, #0xc
    6778:      	cmp	w8, w9
    677c:      	b.hs	0x6790 <generic_fentry_filter_arg+0x1220>
    6780:      	add	x19, x19, #0x1
    6784:      	add	w23, w23, #0x4
    6788:      	cmp	x19, #0x64
    678c:      	b.ne	0x66e4 <generic_fentry_filter_arg+0x1174>
    6790:      	mov	x23, xzr
    6794:      	ldr	x19, [sp, #0x30]
    6798:      	ldp	x16, x15, [sp, #0x40]
    679c:      	mov	w2, #0x5ea0             // =24224
    67a0:      	mov	w12, #0x1               // =1
    67a4:      	ldr	x17, [sp, #0x38]
    67a8:      	ldr	w8, [x29, #0x4]
    67ac:      	cmp	w8, #0x25
    67b0:      	b.hi	0x5804 <generic_fentry_filter_arg+0x294>
    67b4:      	mov	x9, #0x50               // =80
    67b8:      	lsl	x8, x12, x8
    67bc:      	movk	x9, #0xc00, lsl #16
    67c0:      	movk	x9, #0x20, lsl #32
    67c4:      	tst	x8, x9
    67c8:      	b.ne	0x8294 <generic_fentry_filter_arg+0x2d24>
    67cc:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    67d0:      	and	w8, w24, #0xffff
    67d4:      	cmp	w8, #0x90
    67d8:      	b.hi	0x6e50 <generic_fentry_filter_arg+0x18e0>
    67dc:      	and	w8, w24, #0xff
    67e0:      	mov	w9, #0xab               // =171
    67e4:      	tst	w24, #0xffff
    67e8:      	mul	w8, w8, w9
    67ec:      	mov	w9, #0x18               // =24
    67f0:      	lsr	w8, w8, #12
    67f4:      	msub	w8, w8, w9, w24
    67f8:      	b.eq	0x6808 <generic_fentry_filter_arg+0x1298>
    67fc:      	tst	w8, #0xff
    6800:      	mov	w11, w24
    6804:      	b.eq	0x681c <generic_fentry_filter_arg+0x12ac>
    6808:      	sub	w8, w24, w8, uxtb
    680c:      	and	w9, w8, #0xffff
    6810:      	add	w11, w8, #0x18
    6814:      	cmp	w9, #0x78
    6818:      	b.hi	0x6e64 <generic_fentry_filter_arg+0x18f4>
    681c:      	and	w8, w11, #0xff
    6820:      	mov	w9, #0xab               // =171
    6824:      	mul	w8, w8, w9
    6828:      	lsr	w8, w8, #12
    682c:      	sub	w10, w8, #0x1
    6830:      	b	0x6e74 <generic_fentry_filter_arg+0x1904>
    6834:      	ldr	x19, [sp, #0x30]
    6838:      	sub	w8, w8, #0x12
    683c:      	cmp	w8, #0x2
    6840:      	b.hs	0x5804 <generic_fentry_filter_arg+0x294>
    6844:      	ldrb	w8, [x29, #0x10]
    6848:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    684c:      	add	x9, sp, #0xac
    6850:      	add	x1, sp, #0xac
    6854:      	str	w8, [sp, #0xac]
    6858:      	mov	w8, #0x1                // =1
    685c:      	ldr	x0, [x0]
    6860:      	blr	x8
    6864:      	cbz	x0, 0x6d54 <generic_fentry_filter_arg+0x17e4>
    6868:      	str	x24, [sp, #0x88]
    686c:      	mov	w8, #0x1                // =1
    6870:      	add	x9, sp, #0x88
    6874:      	b	0x6d18 <generic_fentry_filter_arg+0x17a8>
    6878:      	cmp	w8, #0x21
    687c:      	b.eq	0x7050 <generic_fentry_filter_arg+0x1ae0>
    6880:      	cmp	w8, #0x22
    6884:      	b.ne	0x826c <generic_fentry_filter_arg+0x2cfc>
    6888:      	mov	w19, #0x10              // =16
    688c:      	ldr	w8, [x29, x19]
    6890:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    6894:      	add	x9, sp, #0x60
    6898:      	add	x1, sp, #0x60
    689c:      	str	w8, [sp, #0x60]
    68a0:      	mov	w8, #0x1                // =1
    68a4:      	ldr	x0, [x0]
    68a8:      	blr	x8
    68ac:      	cbz	x0, 0x7a20 <generic_fentry_filter_arg+0x24b0>
    68b0:      	mov	x1, x0
    68b4:      	mov	x0, x24
    68b8:      	mov	x2, x22
    68bc:      	bl	0x68bc <generic_fentry_filter_arg+0x134c>
    68c0:      	tbz	w0, #0x1f, 0x7a28 <generic_fentry_filter_arg+0x24b8>
    68c4:      	ldr	w8, [x29, #0x8]
    68c8:      	add	x19, x19, #0x4
    68cc:      	mov	w12, #0x1               // =1
    68d0:      	mov	x23, xzr
    68d4:      	sub	w9, w19, #0x8
    68d8:      	cmp	w9, w8
    68dc:      	b.hs	0x7a30 <generic_fentry_filter_arg+0x24c0>
    68e0:      	ldp	x16, x15, [sp, #0x40]
    68e4:      	cmp	x19, #0x1a0
    68e8:      	mov	w2, #0x5ea0             // =24224
    68ec:      	ldr	x17, [sp, #0x38]
    68f0:      	b.ne	0x688c <generic_fentry_filter_arg+0x131c>
    68f4:      	b	0x826c <generic_fentry_filter_arg+0x2cfc>
    68f8:      	cmp	w8, #0x1
    68fc:      	b.eq	0x7178 <generic_fentry_filter_arg+0x1c08>
    6900:      	cmp	w8, #0x2
    6904:      	b.ne	0x7184 <generic_fentry_filter_arg+0x1c14>
    6908:      	ldrb	w10, [x22]
    690c:      	cmp	w9, w10
    6910:      	b.hi	0x5808 <generic_fentry_filter_arg+0x298>
    6914:      	b	0x7184 <generic_fentry_filter_arg+0x1c14>
    6918:      	cmp	w8, #0x1
    691c:      	b.eq	0x71b8 <generic_fentry_filter_arg+0x1c48>
    6920:      	cmp	w8, #0x2
    6924:      	b.ne	0x71c4 <generic_fentry_filter_arg+0x1c54>
    6928:      	ldrh	w10, [x22]
    692c:      	cmp	w9, w10
    6930:      	b.hi	0x5808 <generic_fentry_filter_arg+0x298>
    6934:      	b	0x71c4 <generic_fentry_filter_arg+0x1c54>
    6938:      	ldrb	w8, [x29, #0x10]
    693c:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    6940:      	add	x9, sp, #0x88
    6944:      	add	x1, sp, #0x88
    6948:      	str	w8, [sp, #0x88]
    694c:      	mov	w8, #0x1                // =1
    6950:      	ldr	x0, [x0]
    6954:      	blr	x8
    6958:      	cbz	x0, 0x6d54 <generic_fentry_filter_arg+0x17e4>
    695c:      	ldrb	w8, [x22]
    6960:      	add	x9, sp, #0x60
    6964:      	add	x1, sp, #0x60
    6968:      	str	x8, [sp, #0x60]
    696c:      	mov	w8, #0x1                // =1
    6970:      	b	0x6d1c <generic_fentry_filter_arg+0x17ac>
    6974:      	ldrb	w8, [x29, #0x10]
    6978:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    697c:      	add	x9, sp, #0x88
    6980:      	add	x1, sp, #0x88
    6984:      	str	w8, [sp, #0x88]
    6988:      	mov	w8, #0x1                // =1
    698c:      	ldr	x0, [x0]
    6990:      	blr	x8
    6994:      	cbz	x0, 0x6d54 <generic_fentry_filter_arg+0x17e4>
    6998:      	ldrh	w8, [x22]
    699c:      	add	x9, sp, #0x60
    69a0:      	add	x1, sp, #0x60
    69a4:      	str	x8, [sp, #0x60]
    69a8:      	mov	w8, #0x1                // =1
    69ac:      	b	0x6d1c <generic_fentry_filter_arg+0x17ac>
    69b0:      	ldp	x16, x15, [sp, #0x40]
    69b4:      	cmp	x0, #0x0
    69b8:      	mov	w2, #0x5ea0             // =24224
    69bc:      	mov	w12, #0x1               // =1
    69c0:      	cset	w8, eq
    69c4:      	ldr	x17, [sp, #0x38]
    69c8:      	mov	w23, w8
    69cc:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    69d0:      	ldr	w8, [x29, #0x10]
    69d4:      	str	wzr, [sp, #0x88]
    69d8:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    69dc:      	add	x9, sp, #0x60
    69e0:      	add	x1, sp, #0x60
    69e4:      	str	w8, [sp, #0x60]
    69e8:      	mov	w8, #0x1                // =1
    69ec:      	ldr	x0, [x0]
    69f0:      	blr	x8
    69f4:      	mov	x23, xzr
    69f8:      	cbz	w22, 0x825c <generic_fentry_filter_arg+0x2cec>
    69fc:      	cbz	x0, 0x825c <generic_fentry_filter_arg+0x2cec>
    6a00:      	mov	x19, x0
    6a04:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    6a08:      	mov	w8, #0x1                // =1
    6a0c:      	ldr	x0, [x0]
    6a10:      	add	x9, sp, #0x88
    6a14:      	add	x1, sp, #0x88
    6a18:      	blr	x8
    6a1c:      	cbz	x0, 0x8258 <generic_fentry_filter_arg+0x2ce8>
    6a20:      	cmp	w22, #0xff
    6a24:      	mov	w8, #0xff               // =255
    6a28:      	mov	x2, x24
    6a2c:      	csel	w1, w22, w8, lo
    6a30:      	mov	x8, x0
    6a34:      	mov	x22, x0
    6a38:      	lsl	w9, w1, #3
    6a3c:      	str	w9, [x8], #0x4
    6a40:      	mov	w9, #0x4                // =4
    6a44:      	mov	x0, x8
    6a48:      	blr	x9
    6a4c:      	mov	w8, #0x1                // =1
    6a50:      	mov	x0, x19
    6a54:      	mov	x1, x22
    6a58:      	b	0x8248 <generic_fentry_filter_arg+0x2cd8>
    6a5c:      	cmp	w22, #0x1fe
    6a60:      	str	wzr, [sp, #0x88]
    6a64:      	b.ls	0x7114 <generic_fentry_filter_arg+0x1ba4>
    6a68:      	mov	x23, xzr
    6a6c:      	b	0x826c <generic_fentry_filter_arg+0x2cfc>
    6a70:      	cmp	w8, #0x1e
    6a74:      	b.ne	0x566c <generic_fentry_filter_arg+0xfc>
    6a78:      	ldr	w8, [x29, #0x10]
    6a7c:      	and	x8, x8, #0x7
    6a80:      	add	x9, x20, x8, lsl #2
    6a84:      	ldr	w9, [x9, x2]
    6a88:      	cbnz	w9, 0x566c <generic_fentry_filter_arg+0xfc>
    6a8c:      	add	x8, x20, x8, lsl #3
    6a90:      	ldr	x9, [x22]
    6a94:      	ldr	x8, [x8, #0x5e78]
    6a98:      	and	x8, x8, #0x7ff
    6a9c:      	add	x8, x20, x8
    6aa0:      	ldr	x8, [x8, #0x90]
    6aa4:      	bics	xzr, x8, x9
    6aa8:      	cset	w23, ne
    6aac:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    6ab0:      	ldr	x19, [sp, #0x30]
    6ab4:      	cmp	x24, #0x400
    6ab8:      	cset	w23, lo
    6abc:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    6ac0:      	ldr	x19, [sp, #0x30]
    6ac4:      	cmp	x24, #0x3ff
    6ac8:      	cset	w23, hi
    6acc:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    6ad0:      	and	w8, w24, #0xffff
    6ad4:      	mov	w9, #0x1fe              // =510
    6ad8:      	cmp	w8, #0x100
    6adc:      	mov	w8, #0x100              // =256
    6ae0:      	csel	w11, w9, w8, hi
    6ae4:      	and	w8, w11, #0xffff
    6ae8:      	cmp	w8, #0x100
    6aec:      	mov	w8, #0x6                // =6
    6af0:      	cinc	w10, w8, ne
    6af4:      	add	x8, x29, #0x10
    6af8:      	and	w9, w10, #0xf
    6afc:      	ldr	w8, [x8, w9, uxtw #2]
    6b00:      	cmn	w8, #0x1
    6b04:      	b.eq	0x7e28 <generic_fentry_filter_arg+0x28b8>
    6b08:      	str	w11, [sp, #0x10]
    6b0c:      	stp	w8, w10, [sp, #0x1c]
    6b10:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    6b14:      	mov	w8, #0x1                // =1
    6b18:      	add	x23, sp, #0x88
    6b1c:      	add	x1, sp, #0x88
    6b20:      	ldr	x0, [x0]
    6b24:      	blr	x8
    6b28:      	str	x0, [sp, #0x28]
    6b2c:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    6b30:      	mov	w8, #0x1                // =1
    6b34:      	add	x1, sp, #0x88
    6b38:      	ldr	x0, [x0]
    6b3c:      	blr	x8
    6b40:      	ldr	x9, [sp, #0x28]
    6b44:      	mov	x23, xzr
    6b48:      	cbz	x9, 0x7e2c <generic_fentry_filter_arg+0x28bc>
    6b4c:      	ldp	x16, x15, [sp, #0x40]
    6b50:      	mov	w2, #0x5ea0             // =24224
    6b54:      	mov	w12, #0x1               // =1
    6b58:      	ldr	x17, [sp, #0x38]
    6b5c:      	cbz	x0, 0x7e3c <generic_fentry_filter_arg+0x28cc>
    6b60:      	ldr	w23, [sp, #0x20]
    6b64:      	mov	x8, x9
    6b68:      	str	x0, [sp, #0x8]
    6b6c:      	add	x2, x22, #0x4
    6b70:      	mov	x22, x9
    6b74:      	mov	x0, x8
    6b78:      	cmp	w23, #0x5
    6b7c:      	b.gt	0x753c <generic_fentry_filter_arg+0x1fcc>
    6b80:      	strb	w24, [x0], #0x1
    6b84:      	mov	w8, #0x4                // =4
    6b88:      	mov	w1, w24
    6b8c:      	blr	x8
    6b90:      	ldr	w8, [sp, #0x10]
    6b94:      	and	w8, w8, #0xffff
    6b98:      	cmp	w8, w24
    6b9c:      	b.ls	0x7578 <generic_fentry_filter_arg+0x2008>
    6ba0:      	add	x9, x22, x24
    6ba4:      	sub	w8, w8, w24
    6ba8:      	ldr	x2, [sp, #0x8]
    6bac:      	add	x0, x9, #0x1
    6bb0:      	and	w1, w8, #0xfff
    6bb4:      	mov	w8, #0x4                // =4
    6bb8:      	b	0x7574 <generic_fentry_filter_arg+0x2004>
    6bbc:      	ldr	w8, [x29, #0x14]
    6bc0:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    6bc4:      	add	x9, sp, #0xac
    6bc8:      	add	x1, sp, #0xac
    6bcc:      	str	w8, [sp, #0xac]
    6bd0:      	mov	w8, #0x1                // =1
    6bd4:      	mov	w23, w13
    6bd8:      	mov	w22, w11
    6bdc:      	ldr	x0, [x0]
    6be0:      	blr	x8
    6be4:      	cbz	x0, 0x74d0 <generic_fentry_filter_arg+0x1f60>
    6be8:      	mov	w8, #0x80               // =128
    6bec:      	stp	w23, w19, [sp, #0x90]
    6bf0:      	add	x1, sp, #0x88
    6bf4:      	stp	w8, w22, [sp, #0x88]
    6bf8:      	lsr	x8, x19, #32
    6bfc:      	ldr	x19, [sp, #0x30]
    6c00:      	str	w8, [sp, #0x98]
    6c04:      	mov	w8, #0x1                // =1
    6c08:      	blr	x8
    6c0c:      	ldr	w8, [x29, #0x4]
    6c10:      	sub	w9, w8, #0x18
    6c14:      	cmp	w9, #0x2
    6c18:      	b.lo	0x71f8 <generic_fentry_filter_arg+0x1c88>
    6c1c:      	sub	w8, w8, #0xd
    6c20:      	mov	w12, #0x1               // =1
    6c24:      	cmp	w8, #0x1
    6c28:      	b.hi	0x5e48 <generic_fentry_filter_arg+0x8d8>
    6c2c:      	cmp	x0, #0x0
    6c30:      	cset	w8, ne
    6c34:      	ldp	x16, x15, [sp, #0x40]
    6c38:      	mov	w2, #0x5ea0             // =24224
    6c3c:      	mov	w23, w8
    6c40:      	ldr	x17, [sp, #0x38]
    6c44:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    6c48:      	ldr	x19, [sp, #0x30]
    6c4c:      	mov	w8, wzr
    6c50:      	mov	w23, wzr
    6c54:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    6c58:      	ldr	x8, [x22]
    6c5c:      	cmp	x11, x8
    6c60:      	b.hi	0x6c6c <generic_fentry_filter_arg+0x16fc>
    6c64:      	cmp	x8, x10
    6c68:      	b.ls	0x5808 <generic_fentry_filter_arg+0x298>
    6c6c:      	ldr	w10, [x29, #0x8]
    6c70:      	cmp	w10, #0x19
    6c74:      	b.lo	0x566c <generic_fentry_filter_arg+0xfc>
    6c78:      	ldp	x12, x11, [x29, #0x20]
    6c7c:      	cmp	w9, #0xc
    6c80:      	b.eq	0x6c8c <generic_fentry_filter_arg+0x171c>
    6c84:      	cmp	w9, #0xa
    6c88:      	b.ne	0x72e8 <generic_fentry_filter_arg+0x1d78>
    6c8c:      	cmp	x12, x8
    6c90:      	mov	w12, #0x1               // =1
    6c94:      	b.gt	0x72fc <generic_fentry_filter_arg+0x1d8c>
    6c98:      	cmp	x8, x11
    6c9c:      	b.le	0x5808 <generic_fentry_filter_arg+0x298>
    6ca0:      	b	0x72fc <generic_fentry_filter_arg+0x1d8c>
    6ca4:      	ldr	x10, [x22]
    6ca8:      	cmp	x11, x10
    6cac:      	ccmp	x10, x8, #0x2, ls
    6cb0:      	cset	w8, ls
    6cb4:      	ldr	w11, [x29, #0x8]
    6cb8:      	cmp	w11, #0x19
    6cbc:      	b.lo	0x7c44 <generic_fentry_filter_arg+0x26d4>
    6cc0:      	ldp	x13, x12, [x29, #0x20]
    6cc4:      	cmp	w9, #0xc
    6cc8:      	b.eq	0x6cd4 <generic_fentry_filter_arg+0x1764>
    6ccc:      	cmp	w9, #0xa
    6cd0:      	b.ne	0x72ac <generic_fentry_filter_arg+0x1d3c>
    6cd4:      	cmp	x13, x10
    6cd8:      	ccmp	x10, x12, #0x0, le
    6cdc:      	cset	w12, le
    6ce0:      	b	0x72b8 <generic_fentry_filter_arg+0x1d48>
    6ce4:      	ldrh	w23, [x22, #0x26]
    6ce8:      	ldrb	w8, [x29, #0x10]
    6cec:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    6cf0:      	add	x9, sp, #0xac
    6cf4:      	add	x1, sp, #0xac
    6cf8:      	str	w8, [sp, #0xac]
    6cfc:      	mov	w8, #0x1                // =1
    6d00:      	ldr	x0, [x0]
    6d04:      	blr	x8
    6d08:      	cbz	x0, 0x6d54 <generic_fentry_filter_arg+0x17e4>
    6d0c:      	str	x23, [sp, #0x88]
    6d10:      	mov	w8, #0x1                // =1
    6d14:      	add	x9, sp, #0x88
    6d18:      	add	x1, sp, #0x88
    6d1c:      	blr	x8
    6d20:      	ldr	w9, [x29, #0x4]
    6d24:      	mov	w8, wzr
    6d28:      	mov	w12, #0x1               // =1
    6d2c:      	cmp	w9, #0x1d
    6d30:      	b.hi	0x73d0 <generic_fentry_filter_arg+0x1e60>
    6d34:      	mov	w10, #0x8400            // =33792
    6d38:      	lsl	w9, w12, w9
    6d3c:      	movk	w10, #0x3003, lsl #16
    6d40:      	tst	w9, w10
    6d44:      	b.eq	0x73b8 <generic_fentry_filter_arg+0x1e48>
    6d48:      	cmp	x0, #0x0
    6d4c:      	cset	w8, ne
    6d50:      	b	0x73d0 <generic_fentry_filter_arg+0x1e60>
    6d54:      	mov	x23, xzr
    6d58:      	mov	w12, #0x1               // =1
    6d5c:      	b	0x73d4 <generic_fentry_filter_arg+0x1e64>
    6d60:      	ldr	x11, [x22]
    6d64:      	cmp	x11, x10
    6d68:      	b.hi	0x5808 <generic_fentry_filter_arg+0x298>
    6d6c:      	b	0x6d7c <generic_fentry_filter_arg+0x180c>
    6d70:      	ldr	x11, [x22]
    6d74:      	cmp	x11, x10
    6d78:      	b.lo	0x5808 <generic_fentry_filter_arg+0x298>
    6d7c:      	ldr	w10, [x29, #0x8]
    6d80:      	cmp	w10, #0x11
    6d84:      	b.lo	0x82fc <generic_fentry_filter_arg+0x2d8c>
    6d88:      	ldr	x11, [x29, #0x18]
    6d8c:      	cmp	w8, #0x2
    6d90:      	b.le	0x6db4 <generic_fentry_filter_arg+0x1844>
    6d94:      	sub	w12, w8, #0x3
    6d98:      	cmp	w12, #0x2
    6d9c:      	b.hs	0x6de8 <generic_fentry_filter_arg+0x1878>
    6da0:      	ldr	x12, [x22]
    6da4:      	cmp	x12, x11
    6da8:      	mov	w12, #0x1               // =1
    6dac:      	b.eq	0x57fc <generic_fentry_filter_arg+0x28c>
    6db0:      	b	0x78fc <generic_fentry_filter_arg+0x238c>
    6db4:      	cmp	w8, #0x1
    6db8:      	b.eq	0x6f40 <generic_fentry_filter_arg+0x19d0>
    6dbc:      	cmp	w8, #0x2
    6dc0:      	b.ne	0x78fc <generic_fentry_filter_arg+0x238c>
    6dc4:      	cmp	w9, #0xc
    6dc8:      	b.eq	0x6dd4 <generic_fentry_filter_arg+0x1864>
    6dcc:      	cmp	w9, #0xa
    6dd0:      	b.ne	0x78ec <generic_fentry_filter_arg+0x237c>
    6dd4:      	ldr	x12, [x22]
    6dd8:      	cmp	x12, x11
    6ddc:      	mov	w12, #0x1               // =1
    6de0:      	b.lt	0x5808 <generic_fentry_filter_arg+0x298>
    6de4:      	b	0x78fc <generic_fentry_filter_arg+0x238c>
    6de8:      	cmp	w8, #0xc
    6dec:      	mov	w12, #0x1               // =1
    6df0:      	b.ne	0x78fc <generic_fentry_filter_arg+0x238c>
    6df4:      	ldr	x12, [x22]
    6df8:      	tst	x12, x11
    6dfc:      	mov	w12, #0x1               // =1
    6e00:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    6e04:      	b	0x78fc <generic_fentry_filter_arg+0x238c>
    6e08:      	mov	x23, xzr
    6e0c:      	ldr	x19, [sp, #0x30]
    6e10:      	mov	w12, #0x1               // =1
    6e14:      	ldp	x16, x15, [sp, #0x40]
    6e18:      	mov	w2, #0x5ea0             // =24224
    6e1c:      	b	0x7e38 <generic_fentry_filter_arg+0x28c8>
    6e20:      	cmp	w8, #0xc
    6e24:      	b.ne	0x7184 <generic_fentry_filter_arg+0x1c14>
    6e28:      	ldrb	w10, [x22]
    6e2c:      	tst	w9, w10
    6e30:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    6e34:      	b	0x7184 <generic_fentry_filter_arg+0x1c14>
    6e38:      	cmp	w8, #0xc
    6e3c:      	b.ne	0x71c4 <generic_fentry_filter_arg+0x1c54>
    6e40:      	ldrh	w10, [x22]
    6e44:      	tst	w9, w10
    6e48:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    6e4c:      	b	0x71c4 <generic_fentry_filter_arg+0x1c54>
    6e50:      	and	w8, w24, #0xffff
    6e54:      	mov	w9, #0x1fe              // =510
    6e58:      	cmp	w8, #0x100
    6e5c:      	mov	w8, #0x100              // =256
    6e60:      	csel	w11, w9, w8, hi
    6e64:      	and	w8, w11, #0xffff
    6e68:      	cmp	w8, #0x100
    6e6c:      	mov	w8, #0x6                // =6
    6e70:      	cinc	w10, w8, ne
    6e74:      	add	x8, x29, #0x10
    6e78:      	and	w9, w10, #0xf
    6e7c:      	ldr	w8, [x8, w9, uxtw #2]
    6e80:      	cmn	w8, #0x1
    6e84:      	b.eq	0x7c98 <generic_fentry_filter_arg+0x2728>
    6e88:      	str	w11, [sp, #0x10]
    6e8c:      	str	w8, [sp, #0x1c]
    6e90:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    6e94:      	mov	w8, #0x1                // =1
    6e98:      	add	x23, sp, #0x88
    6e9c:      	add	x1, sp, #0x88
    6ea0:      	str	w10, [sp, #0x28]
    6ea4:      	ldr	x0, [x0]
    6ea8:      	blr	x8
    6eac:      	str	x0, [sp, #0x20]
    6eb0:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0xa90>
    6eb4:      	mov	w8, #0x1                // =1
    6eb8:      	add	x1, sp, #0x88
    6ebc:      	ldr	x0, [x0]
    6ec0:      	blr	x8
    6ec4:      	ldr	x9, [sp, #0x20]
    6ec8:      	mov	x23, xzr
    6ecc:      	cbz	x9, 0x6798 <generic_fentry_filter_arg+0x1228>
    6ed0:      	ldp	x16, x15, [sp, #0x40]
    6ed4:      	mov	w2, #0x5ea0             // =24224
    6ed8:      	mov	w12, #0x1               // =1
    6edc:      	ldr	x17, [sp, #0x38]
    6ee0:      	cbz	x0, 0x67a8 <generic_fentry_filter_arg+0x1238>
    6ee4:      	mov	x8, x9
    6ee8:      	ldr	w9, [sp, #0x28]
    6eec:      	mov	x23, x0
    6ef0:      	cmp	w9, #0x5
    6ef4:      	b.gt	0x77d8 <generic_fentry_filter_arg+0x2268>
    6ef8:      	mov	x0, x8
    6efc:      	mov	x9, x8
    6f00:      	mov	w8, #0x4                // =4
    6f04:      	mov	w1, w24
    6f08:      	mov	x2, x22
    6f0c:      	strb	w24, [x0], #0x1
    6f10:      	mov	x22, x9
    6f14:      	blr	x8
    6f18:      	ldr	w8, [sp, #0x10]
    6f1c:      	and	w8, w8, #0xffff
    6f20:      	cmp	w8, w24
    6f24:      	b.ls	0x7824 <generic_fentry_filter_arg+0x22b4>
    6f28:      	add	x9, x22, x24
    6f2c:      	sub	w8, w8, w24
    6f30:      	add	x0, x9, #0x1
    6f34:      	and	w1, w8, #0xfff
    6f38:      	mov	w8, #0x4                // =4
    6f3c:      	b	0x781c <generic_fentry_filter_arg+0x22ac>
    6f40:      	cmp	w9, #0xc
    6f44:      	b.eq	0x6f50 <generic_fentry_filter_arg+0x19e0>
    6f48:      	cmp	w9, #0xa
    6f4c:      	b.ne	0x78d8 <generic_fentry_filter_arg+0x2368>
    6f50:      	ldr	x12, [x22]
    6f54:      	cmp	x12, x11
    6f58:      	mov	w12, #0x1               // =1
    6f5c:      	b.gt	0x5808 <generic_fentry_filter_arg+0x298>
    6f60:      	b	0x78fc <generic_fentry_filter_arg+0x238c>
    6f64:      	ldr	w9, [x29, #0x8]
    6f68:      	cmp	w9, #0xd
    6f6c:      	b.lo	0x5c88 <generic_fentry_filter_arg+0x718>
    6f70:      	ldr	w10, [x29, #0x14]
    6f74:      	cbz	w10, 0x5c88 <generic_fentry_filter_arg+0x718>
    6f78:      	cmp	w10, w8
    6f7c:      	b.eq	0x59e4 <generic_fentry_filter_arg+0x474>
    6f80:      	cmp	w9, #0x11
    6f84:      	b.lo	0x5c88 <generic_fentry_filter_arg+0x718>
    6f88:      	ldr	w10, [x29, #0x18]
    6f8c:      	cbz	w10, 0x5c88 <generic_fentry_filter_arg+0x718>
    6f90:      	cmp	w10, w8
    6f94:      	b.eq	0x59e4 <generic_fentry_filter_arg+0x474>
    6f98:      	cmp	w9, #0x15
    6f9c:      	b.lo	0x6fb4 <generic_fentry_filter_arg+0x1a44>
    6fa0:      	ldr	w9, [x29, #0x1c]
    6fa4:      	cbz	w9, 0x6fb4 <generic_fentry_filter_arg+0x1a44>
    6fa8:      	cmp	w9, w8
    6fac:      	cset	w23, eq
    6fb0:      	b	0x6fb8 <generic_fentry_filter_arg+0x1a48>
    6fb4:      	mov	x23, xzr
    6fb8:      	ldr	x19, [sp, #0x30]
    6fbc:      	b	0x7e2c <generic_fentry_filter_arg+0x28bc>
    6fc0:      	ldp	w8, w11, [x29, #0x10]
    6fc4:      	ldrb	w9, [x22]
    6fc8:      	cmp	w8, w9
    6fcc:      	ldr	w10, [x29, #0x8]
    6fd0:      	ccmp	w11, w9, #0x0, ls
    6fd4:      	cset	w8, hs
    6fd8:      	cmp	w10, #0x11
    6fdc:      	b.lo	0x7e7c <generic_fentry_filter_arg+0x290c>
    6fe0:      	b	0x7004 <generic_fentry_filter_arg+0x1a94>
    6fe4:      	ldp	w8, w11, [x29, #0x10]
    6fe8:      	ldrh	w9, [x22]
    6fec:      	cmp	w8, w9
    6ff0:      	ldr	w10, [x29, #0x8]
    6ff4:      	ccmp	w11, w9, #0x0, ls
    6ff8:      	cset	w8, hs
    6ffc:      	cmp	w10, #0x11
    7000:      	b.lo	0x7e7c <generic_fentry_filter_arg+0x290c>
    7004:      	ldp	w11, w12, [x29, #0x18]
    7008:      	cmp	w11, w9
    700c:      	ccmp	w12, w9, #0x0, ls
    7010:      	mov	w12, #0x1               // =1
    7014:      	csinc	w8, w8, wzr, lo
    7018:      	cmp	w10, #0x19
    701c:      	b.lo	0x7e7c <generic_fentry_filter_arg+0x290c>
    7020:      	ldp	w11, w12, [x29, #0x20]
    7024:      	cmp	w11, w9
    7028:      	ccmp	w12, w9, #0x0, ls
    702c:      	mov	w12, #0x1               // =1
    7030:      	csinc	w8, w8, wzr, lo
    7034:      	cmp	w10, #0x21
    7038:      	b.lo	0x7e7c <generic_fentry_filter_arg+0x290c>
    703c:      	ldp	w10, w11, [x29, #0x28]
    7040:      	cmp	w10, w9
    7044:      	ccmp	w11, w9, #0x0, ls
    7048:      	csinc	w8, w8, wzr, lo
    704c:      	b	0x7e7c <generic_fentry_filter_arg+0x290c>
    7050:      	mov	x19, xzr
    7054:      	mov	w23, wzr
    7058:      	add	x8, x29, #0x10
    705c:      	str	x8, [sp, #0x28]
    7060:      	ldr	x8, [sp, #0x28]
    7064:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    7068:      	add	x9, sp, #0x60
    706c:      	add	x1, sp, #0x60
    7070:      	ldr	w8, [x8, x19, lsl #2]
    7074:      	str	w8, [sp, #0x60]
    7078:      	mov	w8, #0x1                // =1
    707c:      	ldr	x0, [x0]
    7080:      	blr	x8
    7084:      	cbz	x0, 0x8258 <generic_fentry_filter_arg+0x2ce8>
    7088:      	cbz	w22, 0x70f0 <generic_fentry_filter_arg+0x1b80>
    708c:      	mov	x8, xzr
    7090:      	mov	x9, x24
    7094:      	mov	x10, x22
    7098:      	b	0x70b0 <generic_fentry_filter_arg+0x1b40>
    709c:      	add	x8, x8, #0x1
    70a0:      	sub	x10, x10, #0x1
    70a4:      	add	x9, x9, #0x1
    70a8:      	cmp	x8, x22
    70ac:      	b.eq	0x70f0 <generic_fentry_filter_arg+0x1b80>
    70b0:      	mov	x11, xzr
    70b4:      	nop
    70b8:      	nop
    70bc:      	nop
    70c0:      	cmp	x10, x11
    70c4:      	b.eq	0x709c <generic_fentry_filter_arg+0x1b2c>
    70c8:      	ldrb	w12, [x0, x11]
    70cc:      	cbz	w12, 0x70ec <generic_fentry_filter_arg+0x1b7c>
    70d0:      	cmp	x11, #0x62
    70d4:      	b.hi	0x709c <generic_fentry_filter_arg+0x1b2c>
    70d8:      	ldrb	w13, [x9, x11]
    70dc:      	add	x11, x11, #0x1
    70e0:      	cmp	w13, w12
    70e4:      	b.eq	0x70c0 <generic_fentry_filter_arg+0x1b50>
    70e8:      	b	0x709c <generic_fentry_filter_arg+0x1b2c>
    70ec:      	tbz	w8, #0x1f, 0x7d0c <generic_fentry_filter_arg+0x279c>
    70f0:      	ldr	w9, [x29, #0x8]
    70f4:      	add	w8, w23, #0xc
    70f8:      	cmp	w8, w9
    70fc:      	b.hs	0x8258 <generic_fentry_filter_arg+0x2ce8>
    7100:      	add	x19, x19, #0x1
    7104:      	add	w23, w23, #0x4
    7108:      	cmp	x19, #0x64
    710c:      	b.ne	0x7060 <generic_fentry_filter_arg+0x1af0>
    7110:      	b	0x8258 <generic_fentry_filter_arg+0x2ce8>
    7114:      	and	w8, w22, #0xffff
    7118:      	cmp	w8, #0x90
    711c:      	b.hi	0x75fc <generic_fentry_filter_arg+0x208c>
    7120:      	and	w8, w22, #0xff
    7124:      	mov	w9, #0xab               // =171
    7128:      	tst	w22, #0xffff
    712c:      	mul	w8, w8, w9
    7130:      	mov	w9, #0x18               // =24
    7134:      	lsr	w8, w8, #12
    7138:      	msub	w8, w8, w9, w22
    713c:      	b.eq	0x714c <generic_fentry_filter_arg+0x1bdc>
    7140:      	tst	w8, #0xff
    7144:      	mov	w11, w22
    7148:      	b.eq	0x7160 <generic_fentry_filter_arg+0x1bf0>
    714c:      	sub	w8, w22, w8, uxtb
    7150:      	and	w9, w8, #0xffff
    7154:      	add	w11, w8, #0x18
    7158:      	cmp	w9, #0x78
    715c:      	b.hi	0x7610 <generic_fentry_filter_arg+0x20a0>
    7160:      	and	w8, w11, #0xff
    7164:      	mov	w9, #0xab               // =171
    7168:      	mul	w8, w8, w9
    716c:      	lsr	w8, w8, #12
    7170:      	sub	w10, w8, #0x1
    7174:      	b	0x7620 <generic_fentry_filter_arg+0x20b0>
    7178:      	ldrb	w10, [x22]
    717c:      	cmp	w9, w10
    7180:      	b.lo	0x5808 <generic_fentry_filter_arg+0x298>
    7184:      	ldr	w9, [x29, #0x8]
    7188:      	cmp	w9, #0xd
    718c:      	b.lo	0x82fc <generic_fentry_filter_arg+0x2d8c>
    7190:      	ldr	w10, [x29, #0x14]
    7194:      	cmp	w8, #0x2
    7198:      	b.le	0x74fc <generic_fentry_filter_arg+0x1f8c>
    719c:      	sub	w11, w8, #0x3
    71a0:      	cmp	w11, #0x2
    71a4:      	b.hs	0x7984 <generic_fentry_filter_arg+0x2414>
    71a8:      	ldrb	w11, [x22]
    71ac:      	cmp	w10, w11
    71b0:      	b.eq	0x57fc <generic_fentry_filter_arg+0x28c>
    71b4:      	b	0x7a48 <generic_fentry_filter_arg+0x24d8>
    71b8:      	ldrh	w10, [x22]
    71bc:      	cmp	w9, w10
    71c0:      	b.lo	0x5808 <generic_fentry_filter_arg+0x298>
    71c4:      	ldr	w9, [x29, #0x8]
    71c8:      	cmp	w9, #0xd
    71cc:      	b.lo	0x82fc <generic_fentry_filter_arg+0x2d8c>
    71d0:      	ldr	w10, [x29, #0x14]
    71d4:      	cmp	w8, #0x2
    71d8:      	b.le	0x751c <generic_fentry_filter_arg+0x1fac>
    71dc:      	sub	w11, w8, #0x3
    71e0:      	cmp	w11, #0x2
    71e4:      	b.hs	0x799c <generic_fentry_filter_arg+0x242c>
    71e8:      	ldrh	w11, [x22]
    71ec:      	cmp	w10, w11
    71f0:      	b.eq	0x57fc <generic_fentry_filter_arg+0x28c>
    71f4:      	b	0x7a84 <generic_fentry_filter_arg+0x2514>
    71f8:      	cmp	x0, #0x0
    71fc:      	b	0x74e0 <generic_fentry_filter_arg+0x1f70>
    7200:      	ldr	w8, [x22]
    7204:      	cmp	w11, w8
    7208:      	b.hi	0x7214 <generic_fentry_filter_arg+0x1ca4>
    720c:      	cmp	w8, w10
    7210:      	b.ls	0x5808 <generic_fentry_filter_arg+0x298>
    7214:      	ldr	w10, [x29, #0x8]
    7218:      	cmp	w10, #0x11
    721c:      	b.lo	0x566c <generic_fentry_filter_arg+0xfc>
    7220:      	ldp	w12, w11, [x29, #0x18]
    7224:      	mov	w13, #0x1               // =1
    7228:      	cmp	w9, #0xc
    722c:      	b.hi	0x772c <generic_fentry_filter_arg+0x21bc>
    7230:      	lsl	w13, w13, w9
    7234:      	mov	w14, #0x1402            // =5122
    7238:      	tst	w13, w14
    723c:      	b.eq	0x772c <generic_fentry_filter_arg+0x21bc>
    7240:      	cmp	w12, w8
    7244:      	mov	w12, #0x1               // =1
    7248:      	b.gt	0x7740 <generic_fentry_filter_arg+0x21d0>
    724c:      	cmp	w8, w11
    7250:      	b.le	0x5808 <generic_fentry_filter_arg+0x298>
    7254:      	b	0x7740 <generic_fentry_filter_arg+0x21d0>
    7258:      	ldr	w10, [x22]
    725c:      	cmp	w11, w10
    7260:      	ccmp	w10, w8, #0x2, ls
    7264:      	cset	w8, ls
    7268:      	ldr	w11, [x29, #0x8]
    726c:      	cmp	w11, #0x11
    7270:      	b.lo	0x7e7c <generic_fentry_filter_arg+0x290c>
    7274:      	ldp	w13, w12, [x29, #0x18]
    7278:      	mov	w14, #0x1               // =1
    727c:      	cmp	w9, #0xc
    7280:      	b.hi	0x76e0 <generic_fentry_filter_arg+0x2170>
    7284:      	lsl	w14, w14, w9
    7288:      	mov	w1, #0x1402             // =5122
    728c:      	tst	w14, w1
    7290:      	b.eq	0x76e0 <generic_fentry_filter_arg+0x2170>
    7294:      	cmp	w13, w10
    7298:      	ccmp	w10, w12, #0x0, le
    729c:      	cset	w12, le
    72a0:      	b	0x76ec <generic_fentry_filter_arg+0x217c>
    72a4:      	mov	w23, #0x1               // =1
    72a8:      	b	0x6794 <generic_fentry_filter_arg+0x1224>
    72ac:      	cmp	x13, x10
    72b0:      	ccmp	x10, x12, #0x2, ls
    72b4:      	cset	w12, ls
    72b8:      	orr	w8, w8, w12
    72bc:      	cmp	w11, #0x29
    72c0:      	b.lo	0x7c44 <generic_fentry_filter_arg+0x26d4>
    72c4:      	ldp	x13, x12, [x29, #0x30]
    72c8:      	cmp	w9, #0xc
    72cc:      	b.eq	0x72d8 <generic_fentry_filter_arg+0x1d68>
    72d0:      	cmp	w9, #0xa
    72d4:      	b.ne	0x7780 <generic_fentry_filter_arg+0x2210>
    72d8:      	cmp	x13, x10
    72dc:      	ccmp	x10, x12, #0x0, le
    72e0:      	cset	w12, le
    72e4:      	b	0x778c <generic_fentry_filter_arg+0x221c>
    72e8:      	cmp	x12, x8
    72ec:      	mov	w12, #0x1               // =1
    72f0:      	b.hi	0x72fc <generic_fentry_filter_arg+0x1d8c>
    72f4:      	cmp	x8, x11
    72f8:      	b.ls	0x5808 <generic_fentry_filter_arg+0x298>
    72fc:      	cmp	w10, #0x29
    7300:      	b.lo	0x566c <generic_fentry_filter_arg+0xfc>
    7304:      	ldp	x12, x11, [x29, #0x30]
    7308:      	cmp	w9, #0xc
    730c:      	b.eq	0x7318 <generic_fentry_filter_arg+0x1da8>
    7310:      	cmp	w9, #0xa
    7314:      	b.ne	0x7894 <generic_fentry_filter_arg+0x2324>
    7318:      	cmp	x12, x8
    731c:      	mov	w12, #0x1               // =1
    7320:      	b.gt	0x78a8 <generic_fentry_filter_arg+0x2338>
    7324:      	cmp	x8, x11
    7328:      	b.le	0x5808 <generic_fentry_filter_arg+0x298>
    732c:      	b	0x78a8 <generic_fentry_filter_arg+0x2338>
    7330:      	mov	x19, xzr
    7334:      	cmp	w9, #0x29
    7338:      	b.ne	0x7344 <generic_fentry_filter_arg+0x1dd4>
    733c:      	cbz	x10, 0x7344 <generic_fentry_filter_arg+0x1dd4>
    7340:      	ldrb	w19, [x10, #0x3a]
    7344:      	cmp	w9, #0x29
    7348:      	b.eq	0x7354 <generic_fentry_filter_arg+0x1de4>
    734c:      	cmp	w9, #0x7
    7350:      	b.ne	0x77cc <generic_fentry_filter_arg+0x225c>
    7354:      	ldrb	w8, [x29, #0x10]
    7358:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    735c:      	add	x9, sp, #0xac
    7360:      	add	x1, sp, #0xac
    7364:      	str	w8, [sp, #0xac]
    7368:      	mov	w8, #0x1                // =1
    736c:      	ldr	x0, [x0]
    7370:      	blr	x8
    7374:      	cbz	x0, 0x77bc <generic_fentry_filter_arg+0x224c>
    7378:      	str	x19, [sp, #0x88]
    737c:      	mov	w8, #0x1                // =1
    7380:      	add	x9, sp, #0x88
    7384:      	add	x1, sp, #0x88
    7388:      	blr	x8
    738c:      	ldr	w9, [x29, #0x4]
    7390:      	mov	w8, wzr
    7394:      	cmp	w9, #0x1d
    7398:      	b.hi	0x82a4 <generic_fentry_filter_arg+0x2d34>
    739c:      	ldr	x19, [sp, #0x30]
    73a0:      	mov	w12, #0x1               // =1
    73a4:      	mov	w10, #0x8400            // =33792
    73a8:      	lsl	w9, w12, w9
    73ac:      	movk	w10, #0x3003, lsl #16
    73b0:      	tst	w9, w10
    73b4:      	b.ne	0x6d48 <generic_fentry_filter_arg+0x17d8>
    73b8:      	mov	w10, #0x800             // =2048
    73bc:      	movk	w10, #0xc, lsl #16
    73c0:      	tst	w9, w10
    73c4:      	b.eq	0x73d0 <generic_fentry_filter_arg+0x1e60>
    73c8:      	cmp	x0, #0x0
    73cc:      	cset	w8, eq
    73d0:      	mov	w23, w8
    73d4:      	ldp	x16, x15, [sp, #0x40]
    73d8:      	mov	w2, #0x5ea0             // =24224
    73dc:      	ldr	x17, [sp, #0x38]
    73e0:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    73e4:      	ldr	w11, [x22]
    73e8:      	cmp	w11, w10
    73ec:      	b.hi	0x5808 <generic_fentry_filter_arg+0x298>
    73f0:      	b	0x7400 <generic_fentry_filter_arg+0x1e90>
    73f4:      	ldr	w11, [x22]
    73f8:      	cmp	w11, w10
    73fc:      	b.lo	0x5808 <generic_fentry_filter_arg+0x298>
    7400:      	ldr	w10, [x29, #0x8]
    7404:      	cmp	w10, #0xd
    7408:      	b.lo	0x82fc <generic_fentry_filter_arg+0x2d8c>
    740c:      	ldr	w11, [x29, #0x14]
    7410:      	cmp	w8, #0x2
    7414:      	b.le	0x7438 <generic_fentry_filter_arg+0x1ec8>
    7418:      	sub	w12, w8, #0x3
    741c:      	cmp	w12, #0x2
    7420:      	b.hs	0x7478 <generic_fentry_filter_arg+0x1f08>
    7424:      	ldr	w12, [x22]
    7428:      	cmp	w12, w11
    742c:      	mov	w12, #0x1               // =1
    7430:      	b.eq	0x57fc <generic_fentry_filter_arg+0x28c>
    7434:      	b	0x7b70 <generic_fentry_filter_arg+0x2600>
    7438:      	cmp	w8, #0x1
    743c:      	b.eq	0x7498 <generic_fentry_filter_arg+0x1f28>
    7440:      	cmp	w8, #0x2
    7444:      	b.ne	0x7b70 <generic_fentry_filter_arg+0x2600>
    7448:      	mov	w12, #0x1               // =1
    744c:      	cmp	w9, #0xc
    7450:      	b.hi	0x7b60 <generic_fentry_filter_arg+0x25f0>
    7454:      	lsl	w12, w12, w9
    7458:      	mov	w13, #0x1402            // =5122
    745c:      	tst	w12, w13
    7460:      	b.eq	0x7b60 <generic_fentry_filter_arg+0x25f0>
    7464:      	ldr	w12, [x22]
    7468:      	cmp	w12, w11
    746c:      	mov	w12, #0x1               // =1
    7470:      	b.lt	0x5808 <generic_fentry_filter_arg+0x298>
    7474:      	b	0x7b70 <generic_fentry_filter_arg+0x2600>
    7478:      	cmp	w8, #0xc
    747c:      	mov	w12, #0x1               // =1
    7480:      	b.ne	0x7b70 <generic_fentry_filter_arg+0x2600>
    7484:      	ldr	w12, [x22]
    7488:      	tst	w12, w11
    748c:      	mov	w12, #0x1               // =1
    7490:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    7494:      	b	0x7b70 <generic_fentry_filter_arg+0x2600>
    7498:      	mov	w12, #0x1               // =1
    749c:      	cmp	w9, #0xc
    74a0:      	b.hi	0x7b4c <generic_fentry_filter_arg+0x25dc>
    74a4:      	lsl	w12, w12, w9
    74a8:      	mov	w13, #0x1402            // =5122
    74ac:      	tst	w12, w13
    74b0:      	b.eq	0x7b4c <generic_fentry_filter_arg+0x25dc>
    74b4:      	ldr	w12, [x22]
    74b8:      	cmp	w12, w11
    74bc:      	mov	w12, #0x1               // =1
    74c0:      	b.gt	0x5808 <generic_fentry_filter_arg+0x298>
    74c4:      	b	0x7b70 <generic_fentry_filter_arg+0x2600>
    74c8:      	ldr	w8, [x29, #0x4]
    74cc:      	b	0x74d8 <generic_fentry_filter_arg+0x1f68>
    74d0:      	ldr	w8, [x29, #0x4]
    74d4:      	ldr	x19, [sp, #0x30]
    74d8:      	and	w8, w8, #0xfffffffe
    74dc:      	cmp	w8, #0x18
    74e0:      	cset	w8, eq
    74e4:      	ldp	x16, x15, [sp, #0x40]
    74e8:      	mov	w2, #0x5ea0             // =24224
    74ec:      	mov	w12, #0x1               // =1
    74f0:      	mov	w23, w8
    74f4:      	ldr	x17, [sp, #0x38]
    74f8:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    74fc:      	cmp	w8, #0x1
    7500:      	b.eq	0x7a3c <generic_fentry_filter_arg+0x24cc>
    7504:      	cmp	w8, #0x2
    7508:      	b.ne	0x7a48 <generic_fentry_filter_arg+0x24d8>
    750c:      	ldrb	w11, [x22]
    7510:      	cmp	w10, w11
    7514:      	b.hi	0x5808 <generic_fentry_filter_arg+0x298>
    7518:      	b	0x7a48 <generic_fentry_filter_arg+0x24d8>
    751c:      	cmp	w8, #0x1
    7520:      	b.eq	0x7a78 <generic_fentry_filter_arg+0x2508>
    7524:      	cmp	w8, #0x2
    7528:      	b.ne	0x7a84 <generic_fentry_filter_arg+0x2514>
    752c:      	ldrh	w11, [x22]
    7530:      	cmp	w10, w11
    7534:      	b.hi	0x5808 <generic_fentry_filter_arg+0x298>
    7538:      	b	0x7a84 <generic_fentry_filter_arg+0x2514>
    753c:      	strh	w24, [x0], #0x2
    7540:      	mov	w8, #0x4                // =4
    7544:      	mov	w1, w24
    7548:      	blr	x8
    754c:      	ldr	w8, [sp, #0x10]
    7550:      	and	w8, w8, #0xffff
    7554:      	cmp	w8, w24
    7558:      	b.ls	0x7578 <generic_fentry_filter_arg+0x2008>
    755c:      	add	x9, x22, x24
    7560:      	sub	w8, w8, w24
    7564:      	ldr	x2, [sp, #0x8]
    7568:      	add	x0, x9, #0x2
    756c:      	and	w1, w8, #0xfff
    7570:      	mov	w8, #0x4                // =4
    7574:      	blr	x8
    7578:      	ldr	w8, [sp, #0x1c]
    757c:      	cmp	w23, #0x3
    7580:      	str	w8, [sp, #0x60]
    7584:      	b.gt	0x75c0 <generic_fentry_filter_arg+0x2050>
    7588:      	ldp	x16, x15, [sp, #0x40]
    758c:      	cmp	w23, #0x1
    7590:      	mov	w2, #0x5ea0             // =24224
    7594:      	mov	w12, #0x1               // =1
    7598:      	ldr	x17, [sp, #0x38]
    759c:      	b.gt	0x79d8 <generic_fentry_filter_arg+0x2468>
    75a0:      	cbz	w23, 0x7db8 <generic_fentry_filter_arg+0x2848>
    75a4:      	cmp	w23, #0x1
    75a8:      	b.ne	0x5c88 <generic_fentry_filter_arg+0x718>
    75ac:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    75b0:      	mov	w8, #0x1                // =1
    75b4:      	add	x9, sp, #0x60
    75b8:      	ldr	x0, [x0]
    75bc:      	b	0x7e04 <generic_fentry_filter_arg+0x2894>
    75c0:      	ldp	x16, x15, [sp, #0x40]
    75c4:      	cmp	w23, #0x5
    75c8:      	mov	w2, #0x5ea0             // =24224
    75cc:      	mov	w12, #0x1               // =1
    75d0:      	ldr	x17, [sp, #0x38]
    75d4:      	b.gt	0x79fc <generic_fentry_filter_arg+0x248c>
    75d8:      	cmp	w23, #0x4
    75dc:      	b.eq	0x7dcc <generic_fentry_filter_arg+0x285c>
    75e0:      	cmp	w23, #0x5
    75e4:      	b.ne	0x5c88 <generic_fentry_filter_arg+0x718>
    75e8:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    75ec:      	mov	w8, #0x1                // =1
    75f0:      	add	x9, sp, #0x60
    75f4:      	ldr	x0, [x0]
    75f8:      	b	0x7e04 <generic_fentry_filter_arg+0x2894>
    75fc:      	and	w8, w22, #0xffff
    7600:      	mov	w9, #0x1fe              // =510
    7604:      	cmp	w8, #0x100
    7608:      	mov	w8, #0x100              // =256
    760c:      	csel	w11, w9, w8, hi
    7610:      	and	w8, w11, #0xffff
    7614:      	cmp	w8, #0x100
    7618:      	mov	w8, #0x6                // =6
    761c:      	cinc	w10, w8, ne
    7620:      	add	x8, x29, #0x10
    7624:      	and	w9, w10, #0xf
    7628:      	ldr	w8, [x8, w9, uxtw #2]
    762c:      	cmn	w8, #0x1
    7630:      	b.eq	0x8258 <generic_fentry_filter_arg+0x2ce8>
    7634:      	stp	w11, w8, [sp, #0x1c]
    7638:      	str	w10, [sp, #0x28]
    763c:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    7640:      	mov	w8, #0x1                // =1
    7644:      	add	x19, sp, #0x88
    7648:      	add	x1, sp, #0x88
    764c:      	ldr	x0, [x0]
    7650:      	blr	x8
    7654:      	mov	x9, x0
    7658:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    765c:      	mov	w8, #0x1                // =1
    7660:      	ldr	x0, [x0]
    7664:      	add	x1, sp, #0x88
    7668:      	mov	x19, x9
    766c:      	blr	x8
    7670:      	mov	x23, xzr
    7674:      	cbz	x19, 0x825c <generic_fentry_filter_arg+0x2cec>
    7678:      	ldp	x16, x15, [sp, #0x40]
    767c:      	mov	w2, #0x5ea0             // =24224
    7680:      	mov	w12, #0x1               // =1
    7684:      	ldr	x17, [sp, #0x38]
    7688:      	cbz	x0, 0x826c <generic_fentry_filter_arg+0x2cfc>
    768c:      	ldr	w23, [sp, #0x28]
    7690:      	str	x0, [sp, #0x10]
    7694:      	mov	x0, x19
    7698:      	cmp	w23, #0x5
    769c:      	b.gt	0x7d14 <generic_fentry_filter_arg+0x27a4>
    76a0:      	strb	w22, [x0], #0x1
    76a4:      	mov	w8, #0x4                // =4
    76a8:      	mov	w1, w22
    76ac:      	mov	x2, x24
    76b0:      	blr	x8
    76b4:      	ldr	w8, [sp, #0x1c]
    76b8:      	and	w8, w8, #0xffff
    76bc:      	cmp	w8, w22
    76c0:      	b.ls	0x7d54 <generic_fentry_filter_arg+0x27e4>
    76c4:      	add	x9, x19, x22
    76c8:      	sub	w8, w8, w22
    76cc:      	ldr	x2, [sp, #0x10]
    76d0:      	add	x0, x9, #0x1
    76d4:      	and	w1, w8, #0xfff
    76d8:      	mov	w8, #0x4                // =4
    76dc:      	b	0x7d50 <generic_fentry_filter_arg+0x27e0>
    76e0:      	cmp	w13, w10
    76e4:      	ccmp	w10, w12, #0x2, ls
    76e8:      	cset	w12, ls
    76ec:      	orr	w8, w8, w12
    76f0:      	cmp	w11, #0x19
    76f4:      	mov	w12, #0x1               // =1
    76f8:      	b.lo	0x7e7c <generic_fentry_filter_arg+0x290c>
    76fc:      	ldp	w13, w12, [x29, #0x20]
    7700:      	mov	w14, #0x1               // =1
    7704:      	cmp	w9, #0xc
    7708:      	b.hi	0x7ab4 <generic_fentry_filter_arg+0x2544>
    770c:      	lsl	w14, w14, w9
    7710:      	mov	w1, #0x1402             // =5122
    7714:      	tst	w14, w1
    7718:      	b.eq	0x7ab4 <generic_fentry_filter_arg+0x2544>
    771c:      	cmp	w13, w10
    7720:      	ccmp	w10, w12, #0x0, le
    7724:      	cset	w12, le
    7728:      	b	0x7ac0 <generic_fentry_filter_arg+0x2550>
    772c:      	cmp	w12, w8
    7730:      	mov	w12, #0x1               // =1
    7734:      	b.hi	0x7740 <generic_fentry_filter_arg+0x21d0>
    7738:      	cmp	w8, w11
    773c:      	b.ls	0x5808 <generic_fentry_filter_arg+0x298>
    7740:      	cmp	w10, #0x19
    7744:      	b.lo	0x566c <generic_fentry_filter_arg+0xfc>
    7748:      	ldp	w12, w11, [x29, #0x20]
    774c:      	mov	w13, #0x1               // =1
    7750:      	cmp	w9, #0xc
    7754:      	b.hi	0x7b00 <generic_fentry_filter_arg+0x2590>
    7758:      	lsl	w13, w13, w9
    775c:      	mov	w14, #0x1402            // =5122
    7760:      	tst	w13, w14
    7764:      	b.eq	0x7b00 <generic_fentry_filter_arg+0x2590>
    7768:      	cmp	w12, w8
    776c:      	mov	w12, #0x1               // =1
    7770:      	b.gt	0x7b14 <generic_fentry_filter_arg+0x25a4>
    7774:      	cmp	w8, w11
    7778:      	b.le	0x5808 <generic_fentry_filter_arg+0x298>
    777c:      	b	0x7b14 <generic_fentry_filter_arg+0x25a4>
    7780:      	cmp	x13, x10
    7784:      	ccmp	x10, x12, #0x2, ls
    7788:      	cset	w12, ls
    778c:      	orr	w8, w8, w12
    7790:      	cmp	w11, #0x39
    7794:      	b.lo	0x7c44 <generic_fentry_filter_arg+0x26d4>
    7798:      	ldp	x12, x11, [x29, #0x40]
    779c:      	cmp	w9, #0xc
    77a0:      	b.eq	0x77ac <generic_fentry_filter_arg+0x223c>
    77a4:      	cmp	w9, #0xa
    77a8:      	b.ne	0x7c34 <generic_fentry_filter_arg+0x26c4>
    77ac:      	cmp	x12, x10
    77b0:      	ccmp	x10, x11, #0x0, le
    77b4:      	cset	w9, le
    77b8:      	b	0x7c40 <generic_fentry_filter_arg+0x26d0>
    77bc:      	ldr	x19, [sp, #0x30]
    77c0:      	mov	x23, xzr
    77c4:      	mov	w12, #0x1               // =1
    77c8:      	b	0x73d4 <generic_fentry_filter_arg+0x1e64>
    77cc:      	ldr	x19, [sp, #0x30]
    77d0:      	mov	x23, xzr
    77d4:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    77d8:      	mov	x0, x8
    77dc:      	mov	x9, x8
    77e0:      	mov	w8, #0x4                // =4
    77e4:      	mov	w1, w24
    77e8:      	mov	x2, x22
    77ec:      	strh	w24, [x0], #0x2
    77f0:      	mov	x22, x9
    77f4:      	blr	x8
    77f8:      	ldr	w8, [sp, #0x10]
    77fc:      	and	w8, w8, #0xffff
    7800:      	cmp	w8, w24
    7804:      	b.ls	0x7824 <generic_fentry_filter_arg+0x22b4>
    7808:      	add	x9, x22, x24
    780c:      	sub	w8, w8, w24
    7810:      	add	x0, x9, #0x2
    7814:      	and	w1, w8, #0xfff
    7818:      	mov	w8, #0x4                // =4
    781c:      	mov	x2, x23
    7820:      	blr	x8
    7824:      	ldr	w8, [sp, #0x1c]
    7828:      	str	w8, [sp, #0x60]
    782c:      	ldr	w8, [sp, #0x28]
    7830:      	cmp	w8, #0x3
    7834:      	b.gt	0x7864 <generic_fentry_filter_arg+0x22f4>
    7838:      	cmp	w8, #0x1
    783c:      	mov	w12, #0x1               // =1
    7840:      	b.gt	0x7c50 <generic_fentry_filter_arg+0x26e0>
    7844:      	cbz	w8, 0x7f8c <generic_fentry_filter_arg+0x2a1c>
    7848:      	cmp	w8, #0x1
    784c:      	b.ne	0x7c98 <generic_fentry_filter_arg+0x2728>
    7850:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    7854:      	mov	w8, #0x1                // =1
    7858:      	add	x9, sp, #0x60
    785c:      	ldr	x0, [x0]
    7860:      	b	0x7fd8 <generic_fentry_filter_arg+0x2a68>
    7864:      	cmp	w8, #0x5
    7868:      	mov	w12, #0x1               // =1
    786c:      	b.gt	0x7c74 <generic_fentry_filter_arg+0x2704>
    7870:      	cmp	w8, #0x4
    7874:      	b.eq	0x7fa0 <generic_fentry_filter_arg+0x2a30>
    7878:      	cmp	w8, #0x5
    787c:      	b.ne	0x7c98 <generic_fentry_filter_arg+0x2728>
    7880:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    7884:      	mov	w8, #0x1                // =1
    7888:      	add	x9, sp, #0x60
    788c:      	ldr	x0, [x0]
    7890:      	b	0x7fd8 <generic_fentry_filter_arg+0x2a68>
    7894:      	cmp	x12, x8
    7898:      	mov	w12, #0x1               // =1
    789c:      	b.hi	0x78a8 <generic_fentry_filter_arg+0x2338>
    78a0:      	cmp	x8, x11
    78a4:      	b.ls	0x5808 <generic_fentry_filter_arg+0x298>
    78a8:      	cmp	w10, #0x39
    78ac:      	b.lo	0x566c <generic_fentry_filter_arg+0xfc>
    78b0:      	ldp	x11, x10, [x29, #0x40]
    78b4:      	cmp	w9, #0xc
    78b8:      	b.eq	0x78c4 <generic_fentry_filter_arg+0x2354>
    78bc:      	cmp	w9, #0xa
    78c0:      	b.ne	0x7cb8 <generic_fentry_filter_arg+0x2748>
    78c4:      	cmp	x11, x8
    78c8:      	b.gt	0x566c <generic_fentry_filter_arg+0xfc>
    78cc:      	cmp	x8, x10
    78d0:      	b.le	0x5808 <generic_fentry_filter_arg+0x298>
    78d4:      	b	0x566c <generic_fentry_filter_arg+0xfc>
    78d8:      	ldr	x12, [x22]
    78dc:      	cmp	x12, x11
    78e0:      	mov	w12, #0x1               // =1
    78e4:      	b.hi	0x5808 <generic_fentry_filter_arg+0x298>
    78e8:      	b	0x78fc <generic_fentry_filter_arg+0x238c>
    78ec:      	ldr	x12, [x22]
    78f0:      	cmp	x12, x11
    78f4:      	mov	w12, #0x1               // =1
    78f8:      	b.lo	0x5808 <generic_fentry_filter_arg+0x298>
    78fc:      	cmp	w10, #0x19
    7900:      	b.lo	0x82fc <generic_fentry_filter_arg+0x2d8c>
    7904:      	ldr	x11, [x29, #0x20]
    7908:      	cmp	w8, #0x2
    790c:      	b.le	0x7930 <generic_fentry_filter_arg+0x23c0>
    7910:      	sub	w12, w8, #0x3
    7914:      	cmp	w12, #0x2
    7918:      	b.hs	0x7964 <generic_fentry_filter_arg+0x23f4>
    791c:      	ldr	x12, [x22]
    7920:      	cmp	x12, x11
    7924:      	mov	w12, #0x1               // =1
    7928:      	b.eq	0x57fc <generic_fentry_filter_arg+0x28c>
    792c:      	b	0x7ea8 <generic_fentry_filter_arg+0x2938>
    7930:      	cmp	w8, #0x1
    7934:      	b.eq	0x79b4 <generic_fentry_filter_arg+0x2444>
    7938:      	cmp	w8, #0x2
    793c:      	b.ne	0x7ea8 <generic_fentry_filter_arg+0x2938>
    7940:      	cmp	w9, #0xc
    7944:      	b.eq	0x7950 <generic_fentry_filter_arg+0x23e0>
    7948:      	cmp	w9, #0xa
    794c:      	b.ne	0x7e98 <generic_fentry_filter_arg+0x2928>
    7950:      	ldr	x12, [x22]
    7954:      	cmp	x12, x11
    7958:      	mov	w12, #0x1               // =1
    795c:      	b.lt	0x5808 <generic_fentry_filter_arg+0x298>
    7960:      	b	0x7ea8 <generic_fentry_filter_arg+0x2938>
    7964:      	cmp	w8, #0xc
    7968:      	mov	w12, #0x1               // =1
    796c:      	b.ne	0x7ea8 <generic_fentry_filter_arg+0x2938>
    7970:      	ldr	x12, [x22]
    7974:      	tst	x12, x11
    7978:      	mov	w12, #0x1               // =1
    797c:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    7980:      	b	0x7ea8 <generic_fentry_filter_arg+0x2938>
    7984:      	cmp	w8, #0xc
    7988:      	b.ne	0x7a48 <generic_fentry_filter_arg+0x24d8>
    798c:      	ldrb	w11, [x22]
    7990:      	tst	w10, w11
    7994:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    7998:      	b	0x7a48 <generic_fentry_filter_arg+0x24d8>
    799c:      	cmp	w8, #0xc
    79a0:      	b.ne	0x7a84 <generic_fentry_filter_arg+0x2514>
    79a4:      	ldrh	w11, [x22]
    79a8:      	tst	w10, w11
    79ac:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    79b0:      	b	0x7a84 <generic_fentry_filter_arg+0x2514>
    79b4:      	cmp	w9, #0xc
    79b8:      	b.eq	0x79c4 <generic_fentry_filter_arg+0x2454>
    79bc:      	cmp	w9, #0xa
    79c0:      	b.ne	0x7e84 <generic_fentry_filter_arg+0x2914>
    79c4:      	ldr	x12, [x22]
    79c8:      	cmp	x12, x11
    79cc:      	mov	w12, #0x1               // =1
    79d0:      	b.gt	0x5808 <generic_fentry_filter_arg+0x298>
    79d4:      	b	0x7ea8 <generic_fentry_filter_arg+0x2938>
    79d8:      	cmp	w23, #0x2
    79dc:      	b.eq	0x7de0 <generic_fentry_filter_arg+0x2870>
    79e0:      	cmp	w23, #0x3
    79e4:      	b.ne	0x5c88 <generic_fentry_filter_arg+0x718>
    79e8:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    79ec:      	mov	w8, #0x1                // =1
    79f0:      	add	x9, sp, #0x60
    79f4:      	ldr	x0, [x0]
    79f8:      	b	0x7e04 <generic_fentry_filter_arg+0x2894>
    79fc:      	cmp	w23, #0x6
    7a00:      	b.eq	0x7df4 <generic_fentry_filter_arg+0x2884>
    7a04:      	cmp	w23, #0x7
    7a08:      	b.ne	0x5c88 <generic_fentry_filter_arg+0x718>
    7a0c:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    7a10:      	mov	w8, #0x1                // =1
    7a14:      	add	x9, sp, #0x60
    7a18:      	ldr	x0, [x0]
    7a1c:      	b	0x7e04 <generic_fentry_filter_arg+0x2894>
    7a20:      	mov	x23, xzr
    7a24:      	b	0x7a2c <generic_fentry_filter_arg+0x24bc>
    7a28:      	mov	w23, #0x1               // =1
    7a2c:      	mov	w12, #0x1               // =1
    7a30:      	ldp	x16, x15, [sp, #0x40]
    7a34:      	mov	w2, #0x5ea0             // =24224
    7a38:      	b	0x8268 <generic_fentry_filter_arg+0x2cf8>
    7a3c:      	ldrb	w11, [x22]
    7a40:      	cmp	w10, w11
    7a44:      	b.lo	0x5808 <generic_fentry_filter_arg+0x298>
    7a48:      	cmp	w9, #0x11
    7a4c:      	b.lo	0x82fc <generic_fentry_filter_arg+0x2d8c>
    7a50:      	ldr	w10, [x29, #0x18]
    7a54:      	cmp	w8, #0x2
    7a58:      	b.le	0x7ccc <generic_fentry_filter_arg+0x275c>
    7a5c:      	sub	w11, w8, #0x3
    7a60:      	cmp	w11, #0x2
    7a64:      	b.hs	0x7f28 <generic_fentry_filter_arg+0x29b8>
    7a68:      	ldrb	w11, [x22]
    7a6c:      	cmp	w10, w11
    7a70:      	b.eq	0x57fc <generic_fentry_filter_arg+0x28c>
    7a74:      	b	0x8058 <generic_fentry_filter_arg+0x2ae8>
    7a78:      	ldrh	w11, [x22]
    7a7c:      	cmp	w10, w11
    7a80:      	b.lo	0x5808 <generic_fentry_filter_arg+0x298>
    7a84:      	cmp	w9, #0x11
    7a88:      	b.lo	0x82fc <generic_fentry_filter_arg+0x2d8c>
    7a8c:      	ldr	w10, [x29, #0x18]
    7a90:      	cmp	w8, #0x2
    7a94:      	b.le	0x7cec <generic_fentry_filter_arg+0x277c>
    7a98:      	sub	w11, w8, #0x3
    7a9c:      	cmp	w11, #0x2
    7aa0:      	b.hs	0x7f40 <generic_fentry_filter_arg+0x29d0>
    7aa4:      	ldrh	w11, [x22]
    7aa8:      	cmp	w10, w11
    7aac:      	b.eq	0x57fc <generic_fentry_filter_arg+0x28c>
    7ab0:      	b	0x809c <generic_fentry_filter_arg+0x2b2c>
    7ab4:      	cmp	w13, w10
    7ab8:      	ccmp	w10, w12, #0x2, ls
    7abc:      	cset	w12, ls
    7ac0:      	orr	w8, w8, w12
    7ac4:      	cmp	w11, #0x21
    7ac8:      	mov	w12, #0x1               // =1
    7acc:      	b.lo	0x7e7c <generic_fentry_filter_arg+0x290c>
    7ad0:      	ldp	w12, w11, [x29, #0x28]
    7ad4:      	mov	w13, #0x1               // =1
    7ad8:      	cmp	w9, #0xc
    7adc:      	b.hi	0x7e68 <generic_fentry_filter_arg+0x28f8>
    7ae0:      	lsl	w9, w13, w9
    7ae4:      	mov	w13, #0x1402            // =5122
    7ae8:      	tst	w9, w13
    7aec:      	b.eq	0x7e68 <generic_fentry_filter_arg+0x28f8>
    7af0:      	cmp	w12, w10
    7af4:      	ccmp	w10, w11, #0x0, le
    7af8:      	cset	w9, le
    7afc:      	b	0x7e74 <generic_fentry_filter_arg+0x2904>
    7b00:      	cmp	w12, w8
    7b04:      	mov	w12, #0x1               // =1
    7b08:      	b.hi	0x7b14 <generic_fentry_filter_arg+0x25a4>
    7b0c:      	cmp	w8, w11
    7b10:      	b.ls	0x5808 <generic_fentry_filter_arg+0x298>
    7b14:      	cmp	w10, #0x21
    7b18:      	b.lo	0x566c <generic_fentry_filter_arg+0xfc>
    7b1c:      	ldp	w11, w10, [x29, #0x28]
    7b20:      	cmp	w9, #0xc
    7b24:      	b.hi	0x7f58 <generic_fentry_filter_arg+0x29e8>
    7b28:      	lsl	w9, w12, w9
    7b2c:      	mov	w13, #0x1402            // =5122
    7b30:      	tst	w9, w13
    7b34:      	b.eq	0x7f58 <generic_fentry_filter_arg+0x29e8>
    7b38:      	cmp	w11, w8
    7b3c:      	b.gt	0x566c <generic_fentry_filter_arg+0xfc>
    7b40:      	cmp	w8, w10
    7b44:      	b.le	0x5808 <generic_fentry_filter_arg+0x298>
    7b48:      	b	0x566c <generic_fentry_filter_arg+0xfc>
    7b4c:      	ldr	w12, [x22]
    7b50:      	cmp	w12, w11
    7b54:      	mov	w12, #0x1               // =1
    7b58:      	b.hi	0x5808 <generic_fentry_filter_arg+0x298>
    7b5c:      	b	0x7b70 <generic_fentry_filter_arg+0x2600>
    7b60:      	ldr	w12, [x22]
    7b64:      	cmp	w12, w11
    7b68:      	mov	w12, #0x1               // =1
    7b6c:      	b.lo	0x5808 <generic_fentry_filter_arg+0x298>
    7b70:      	cmp	w10, #0x11
    7b74:      	b.lo	0x82fc <generic_fentry_filter_arg+0x2d8c>
    7b78:      	ldr	w11, [x29, #0x18]
    7b7c:      	cmp	w8, #0x2
    7b80:      	b.le	0x7ba4 <generic_fentry_filter_arg+0x2634>
    7b84:      	sub	w12, w8, #0x3
    7b88:      	cmp	w12, #0x2
    7b8c:      	b.hs	0x7be4 <generic_fentry_filter_arg+0x2674>
    7b90:      	ldr	w12, [x22]
    7b94:      	cmp	w12, w11
    7b98:      	mov	w12, #0x1               // =1
    7b9c:      	b.eq	0x57fc <generic_fentry_filter_arg+0x28c>
    7ba0:      	b	0x80f8 <generic_fentry_filter_arg+0x2b88>
    7ba4:      	cmp	w8, #0x1
    7ba8:      	b.eq	0x7c04 <generic_fentry_filter_arg+0x2694>
    7bac:      	cmp	w8, #0x2
    7bb0:      	b.ne	0x80f8 <generic_fentry_filter_arg+0x2b88>
    7bb4:      	mov	w12, #0x1               // =1
    7bb8:      	cmp	w9, #0xc
    7bbc:      	b.hi	0x80e8 <generic_fentry_filter_arg+0x2b78>
    7bc0:      	lsl	w12, w12, w9
    7bc4:      	mov	w13, #0x1402            // =5122
    7bc8:      	tst	w12, w13
    7bcc:      	b.eq	0x80e8 <generic_fentry_filter_arg+0x2b78>
    7bd0:      	ldr	w12, [x22]
    7bd4:      	cmp	w12, w11
    7bd8:      	mov	w12, #0x1               // =1
    7bdc:      	b.lt	0x5808 <generic_fentry_filter_arg+0x298>
    7be0:      	b	0x80f8 <generic_fentry_filter_arg+0x2b88>
    7be4:      	cmp	w8, #0xc
    7be8:      	mov	w12, #0x1               // =1
    7bec:      	b.ne	0x80f8 <generic_fentry_filter_arg+0x2b88>
    7bf0:      	ldr	w12, [x22]
    7bf4:      	tst	w12, w11
    7bf8:      	mov	w12, #0x1               // =1
    7bfc:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    7c00:      	b	0x80f8 <generic_fentry_filter_arg+0x2b88>
    7c04:      	mov	w12, #0x1               // =1
    7c08:      	cmp	w9, #0xc
    7c0c:      	b.hi	0x80d4 <generic_fentry_filter_arg+0x2b64>
    7c10:      	lsl	w12, w12, w9
    7c14:      	mov	w13, #0x1402            // =5122
    7c18:      	tst	w12, w13
    7c1c:      	b.eq	0x80d4 <generic_fentry_filter_arg+0x2b64>
    7c20:      	ldr	w12, [x22]
    7c24:      	cmp	w12, w11
    7c28:      	mov	w12, #0x1               // =1
    7c2c:      	b.gt	0x5808 <generic_fentry_filter_arg+0x298>
    7c30:      	b	0x80f8 <generic_fentry_filter_arg+0x2b88>
    7c34:      	cmp	x12, x10
    7c38:      	ccmp	x10, x11, #0x2, ls
    7c3c:      	cset	w9, ls
    7c40:      	orr	w8, w8, w9
    7c44:      	mov	w12, #0x1               // =1
    7c48:      	tbz	w8, #0x0, 0x5808 <generic_fentry_filter_arg+0x298>
    7c4c:      	b	0x566c <generic_fentry_filter_arg+0xfc>
    7c50:      	cmp	w8, #0x2
    7c54:      	b.eq	0x7fb4 <generic_fentry_filter_arg+0x2a44>
    7c58:      	cmp	w8, #0x3
    7c5c:      	b.ne	0x7c98 <generic_fentry_filter_arg+0x2728>
    7c60:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    7c64:      	mov	w8, #0x1                // =1
    7c68:      	add	x9, sp, #0x60
    7c6c:      	ldr	x0, [x0]
    7c70:      	b	0x7fd8 <generic_fentry_filter_arg+0x2a68>
    7c74:      	cmp	w8, #0x6
    7c78:      	b.eq	0x7fc8 <generic_fentry_filter_arg+0x2a58>
    7c7c:      	cmp	w8, #0x7
    7c80:      	b.ne	0x7c98 <generic_fentry_filter_arg+0x2728>
    7c84:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    7c88:      	mov	w8, #0x1                // =1
    7c8c:      	add	x9, sp, #0x60
    7c90:      	ldr	x0, [x0]
    7c94:      	b	0x7fd8 <generic_fentry_filter_arg+0x2a68>
    7c98:      	ldp	x16, x15, [sp, #0x40]
    7c9c:      	mov	x23, xzr
    7ca0:      	mov	w2, #0x5ea0             // =24224
    7ca4:      	ldr	x17, [sp, #0x38]
    7ca8:      	ldr	w8, [x29, #0x4]
    7cac:      	cmp	w8, #0x25
    7cb0:      	b.ls	0x67b4 <generic_fentry_filter_arg+0x1244>
    7cb4:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    7cb8:      	cmp	x11, x8
    7cbc:      	b.hi	0x566c <generic_fentry_filter_arg+0xfc>
    7cc0:      	cmp	x8, x10
    7cc4:      	b.ls	0x5808 <generic_fentry_filter_arg+0x298>
    7cc8:      	b	0x566c <generic_fentry_filter_arg+0xfc>
    7ccc:      	cmp	w8, #0x1
    7cd0:      	b.eq	0x804c <generic_fentry_filter_arg+0x2adc>
    7cd4:      	cmp	w8, #0x2
    7cd8:      	b.ne	0x8058 <generic_fentry_filter_arg+0x2ae8>
    7cdc:      	ldrb	w11, [x22]
    7ce0:      	cmp	w10, w11
    7ce4:      	b.hi	0x5808 <generic_fentry_filter_arg+0x298>
    7ce8:      	b	0x8058 <generic_fentry_filter_arg+0x2ae8>
    7cec:      	cmp	w8, #0x1
    7cf0:      	b.eq	0x8090 <generic_fentry_filter_arg+0x2b20>
    7cf4:      	cmp	w8, #0x2
    7cf8:      	b.ne	0x809c <generic_fentry_filter_arg+0x2b2c>
    7cfc:      	ldrh	w11, [x22]
    7d00:      	cmp	w10, w11
    7d04:      	b.hi	0x5808 <generic_fentry_filter_arg+0x298>
    7d08:      	b	0x809c <generic_fentry_filter_arg+0x2b2c>
    7d0c:      	mov	w23, #0x1               // =1
    7d10:      	b	0x825c <generic_fentry_filter_arg+0x2cec>
    7d14:      	strh	w22, [x0], #0x2
    7d18:      	mov	w8, #0x4                // =4
    7d1c:      	mov	w1, w22
    7d20:      	mov	x2, x24
    7d24:      	blr	x8
    7d28:      	ldr	w8, [sp, #0x1c]
    7d2c:      	and	w8, w8, #0xffff
    7d30:      	cmp	w8, w22
    7d34:      	b.ls	0x7d54 <generic_fentry_filter_arg+0x27e4>
    7d38:      	add	x9, x19, x22
    7d3c:      	sub	w8, w8, w22
    7d40:      	ldr	x2, [sp, #0x10]
    7d44:      	add	x0, x9, #0x2
    7d48:      	and	w1, w8, #0xfff
    7d4c:      	mov	w8, #0x4                // =4
    7d50:      	blr	x8
    7d54:      	ldr	w8, [sp, #0x20]
    7d58:      	cmp	w23, #0x3
    7d5c:      	str	w8, [sp, #0x60]
    7d60:      	b.gt	0x7d8c <generic_fentry_filter_arg+0x281c>
    7d64:      	cmp	w23, #0x1
    7d68:      	b.gt	0x8004 <generic_fentry_filter_arg+0x2a94>
    7d6c:      	cbz	w23, 0x81e8 <generic_fentry_filter_arg+0x2c78>
    7d70:      	cmp	w23, #0x1
    7d74:      	b.ne	0x8258 <generic_fentry_filter_arg+0x2ce8>
    7d78:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    7d7c:      	mov	w8, #0x1                // =1
    7d80:      	add	x9, sp, #0x60
    7d84:      	ldr	x0, [x0]
    7d88:      	b	0x8234 <generic_fentry_filter_arg+0x2cc4>
    7d8c:      	cmp	w23, #0x5
    7d90:      	b.gt	0x8028 <generic_fentry_filter_arg+0x2ab8>
    7d94:      	cmp	w23, #0x4
    7d98:      	b.eq	0x81fc <generic_fentry_filter_arg+0x2c8c>
    7d9c:      	cmp	w23, #0x5
    7da0:      	b.ne	0x8258 <generic_fentry_filter_arg+0x2ce8>
    7da4:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    7da8:      	mov	w8, #0x1                // =1
    7dac:      	add	x9, sp, #0x60
    7db0:      	ldr	x0, [x0]
    7db4:      	b	0x8234 <generic_fentry_filter_arg+0x2cc4>
    7db8:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    7dbc:      	mov	w8, #0x1                // =1
    7dc0:      	add	x9, sp, #0x60
    7dc4:      	ldr	x0, [x0]
    7dc8:      	b	0x7e04 <generic_fentry_filter_arg+0x2894>
    7dcc:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    7dd0:      	mov	w8, #0x1                // =1
    7dd4:      	add	x9, sp, #0x60
    7dd8:      	ldr	x0, [x0]
    7ddc:      	b	0x7e04 <generic_fentry_filter_arg+0x2894>
    7de0:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    7de4:      	mov	w8, #0x1                // =1
    7de8:      	add	x9, sp, #0x60
    7dec:      	ldr	x0, [x0]
    7df0:      	b	0x7e04 <generic_fentry_filter_arg+0x2894>
    7df4:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    7df8:      	mov	w8, #0x1                // =1
    7dfc:      	add	x9, sp, #0x60
    7e00:      	ldr	x0, [x0]
    7e04:      	add	x1, sp, #0x60
    7e08:      	blr	x8
    7e0c:      	cbz	x0, 0x7e28 <generic_fentry_filter_arg+0x28b8>
    7e10:      	mov	w8, #0x1                // =1
    7e14:      	mov	x1, x22
    7e18:      	blr	x8
    7e1c:      	cmp	x0, #0x0
    7e20:      	cset	w23, ne
    7e24:      	b	0x7e2c <generic_fentry_filter_arg+0x28bc>
    7e28:      	mov	x23, xzr
    7e2c:      	ldp	x16, x15, [sp, #0x40]
    7e30:      	mov	w2, #0x5ea0             // =24224
    7e34:      	mov	w12, #0x1               // =1
    7e38:      	ldr	x17, [sp, #0x38]
    7e3c:      	ldr	w8, [x29, #0x4]
    7e40:      	cmp	w8, #0x25
    7e44:      	b.hi	0x5804 <generic_fentry_filter_arg+0x294>
    7e48:      	mov	x9, #0x50               // =80
    7e4c:      	lsl	x8, x12, x8
    7e50:      	movk	x9, #0xc00, lsl #16
    7e54:      	movk	x9, #0x20, lsl #32
    7e58:      	tst	x8, x9
    7e5c:      	b.eq	0x5804 <generic_fentry_filter_arg+0x294>
    7e60:      	eor	x23, x23, #0x1
    7e64:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    7e68:      	cmp	w12, w10
    7e6c:      	ccmp	w10, w11, #0x2, ls
    7e70:      	cset	w9, ls
    7e74:      	orr	w8, w8, w9
    7e78:      	mov	w12, #0x1               // =1
    7e7c:      	tbz	w8, #0x0, 0x5808 <generic_fentry_filter_arg+0x298>
    7e80:      	b	0x566c <generic_fentry_filter_arg+0xfc>
    7e84:      	ldr	x12, [x22]
    7e88:      	cmp	x12, x11
    7e8c:      	mov	w12, #0x1               // =1
    7e90:      	b.hi	0x5808 <generic_fentry_filter_arg+0x298>
    7e94:      	b	0x7ea8 <generic_fentry_filter_arg+0x2938>
    7e98:      	ldr	x12, [x22]
    7e9c:      	cmp	x12, x11
    7ea0:      	mov	w12, #0x1               // =1
    7ea4:      	b.lo	0x5808 <generic_fentry_filter_arg+0x298>
    7ea8:      	cmp	w10, #0x21
    7eac:      	b.lo	0x82fc <generic_fentry_filter_arg+0x2d8c>
    7eb0:      	ldr	x10, [x29, #0x28]
    7eb4:      	cmp	w8, #0x2
    7eb8:      	b.le	0x7ee8 <generic_fentry_filter_arg+0x2978>
    7ebc:      	sub	w9, w8, #0x3
    7ec0:      	cmp	w9, #0x2
    7ec4:      	b.lo	0x7f18 <generic_fentry_filter_arg+0x29a8>
    7ec8:      	cmp	w8, #0x6
    7ecc:      	b.eq	0x5808 <generic_fentry_filter_arg+0x298>
    7ed0:      	cmp	w8, #0xc
    7ed4:      	b.ne	0x566c <generic_fentry_filter_arg+0xfc>
    7ed8:      	ldr	x9, [x22]
    7edc:      	tst	x9, x10
    7ee0:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    7ee4:      	b	0x82fc <generic_fentry_filter_arg+0x2d8c>
    7ee8:      	cmp	w8, #0x1
    7eec:      	b.eq	0x7f6c <generic_fentry_filter_arg+0x29fc>
    7ef0:      	cmp	w8, #0x2
    7ef4:      	b.ne	0x566c <generic_fentry_filter_arg+0xfc>
    7ef8:      	cmp	w9, #0xc
    7efc:      	b.eq	0x7f08 <generic_fentry_filter_arg+0x2998>
    7f00:      	cmp	w9, #0xa
    7f04:      	b.ne	0x82b0 <generic_fentry_filter_arg+0x2d40>
    7f08:      	ldr	x9, [x22]
    7f0c:      	cmp	x9, x10
    7f10:      	b.lt	0x5808 <generic_fentry_filter_arg+0x298>
    7f14:      	b	0x82fc <generic_fentry_filter_arg+0x2d8c>
    7f18:      	ldr	x9, [x22]
    7f1c:      	cmp	x9, x10
    7f20:      	b.ne	0x82fc <generic_fentry_filter_arg+0x2d8c>
    7f24:      	b	0x57fc <generic_fentry_filter_arg+0x28c>
    7f28:      	cmp	w8, #0xc
    7f2c:      	b.ne	0x8058 <generic_fentry_filter_arg+0x2ae8>
    7f30:      	ldrb	w11, [x22]
    7f34:      	tst	w10, w11
    7f38:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    7f3c:      	b	0x8058 <generic_fentry_filter_arg+0x2ae8>
    7f40:      	cmp	w8, #0xc
    7f44:      	b.ne	0x809c <generic_fentry_filter_arg+0x2b2c>
    7f48:      	ldrh	w11, [x22]
    7f4c:      	tst	w10, w11
    7f50:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    7f54:      	b	0x809c <generic_fentry_filter_arg+0x2b2c>
    7f58:      	cmp	w11, w8
    7f5c:      	b.hi	0x566c <generic_fentry_filter_arg+0xfc>
    7f60:      	cmp	w8, w10
    7f64:      	b.ls	0x5808 <generic_fentry_filter_arg+0x298>
    7f68:      	b	0x566c <generic_fentry_filter_arg+0xfc>
    7f6c:      	cmp	w9, #0xc
    7f70:      	b.eq	0x7f7c <generic_fentry_filter_arg+0x2a0c>
    7f74:      	cmp	w9, #0xa
    7f78:      	b.ne	0x82c0 <generic_fentry_filter_arg+0x2d50>
    7f7c:      	ldr	x9, [x22]
    7f80:      	cmp	x9, x10
    7f84:      	b.gt	0x5808 <generic_fentry_filter_arg+0x298>
    7f88:      	b	0x82fc <generic_fentry_filter_arg+0x2d8c>
    7f8c:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    7f90:      	mov	w8, #0x1                // =1
    7f94:      	add	x9, sp, #0x60
    7f98:      	ldr	x0, [x0]
    7f9c:      	b	0x7fd8 <generic_fentry_filter_arg+0x2a68>
    7fa0:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    7fa4:      	mov	w8, #0x1                // =1
    7fa8:      	add	x9, sp, #0x60
    7fac:      	ldr	x0, [x0]
    7fb0:      	b	0x7fd8 <generic_fentry_filter_arg+0x2a68>
    7fb4:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    7fb8:      	mov	w8, #0x1                // =1
    7fbc:      	add	x9, sp, #0x60
    7fc0:      	ldr	x0, [x0]
    7fc4:      	b	0x7fd8 <generic_fentry_filter_arg+0x2a68>
    7fc8:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1a90>
    7fcc:      	mov	w8, #0x1                // =1
    7fd0:      	add	x9, sp, #0x60
    7fd4:      	ldr	x0, [x0]
    7fd8:      	add	x1, sp, #0x60
    7fdc:      	blr	x8
    7fe0:      	cbz	x0, 0x7ffc <generic_fentry_filter_arg+0x2a8c>
    7fe4:      	mov	w8, #0x1                // =1
    7fe8:      	mov	x1, x22
    7fec:      	blr	x8
    7ff0:      	cmp	x0, #0x0
    7ff4:      	cset	w23, ne
    7ff8:      	b	0x6798 <generic_fentry_filter_arg+0x1228>
    7ffc:      	mov	x23, xzr
    8000:      	b	0x6798 <generic_fentry_filter_arg+0x1228>
    8004:      	cmp	w23, #0x2
    8008:      	b.eq	0x8210 <generic_fentry_filter_arg+0x2ca0>
    800c:      	cmp	w23, #0x3
    8010:      	b.ne	0x8258 <generic_fentry_filter_arg+0x2ce8>
    8014:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8018:      	mov	w8, #0x1                // =1
    801c:      	add	x9, sp, #0x60
    8020:      	ldr	x0, [x0]
    8024:      	b	0x8234 <generic_fentry_filter_arg+0x2cc4>
    8028:      	cmp	w23, #0x6
    802c:      	b.eq	0x8224 <generic_fentry_filter_arg+0x2cb4>
    8030:      	cmp	w23, #0x7
    8034:      	b.ne	0x8258 <generic_fentry_filter_arg+0x2ce8>
    8038:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    803c:      	mov	w8, #0x1                // =1
    8040:      	add	x9, sp, #0x60
    8044:      	ldr	x0, [x0]
    8048:      	b	0x8234 <generic_fentry_filter_arg+0x2cc4>
    804c:      	ldrb	w11, [x22]
    8050:      	cmp	w10, w11
    8054:      	b.lo	0x5808 <generic_fentry_filter_arg+0x298>
    8058:      	cmp	w9, #0x15
    805c:      	b.lo	0x82fc <generic_fentry_filter_arg+0x2d8c>
    8060:      	ldr	w9, [x29, #0x1c]
    8064:      	cmp	w8, #0x2
    8068:      	b.le	0x81a0 <generic_fentry_filter_arg+0x2c30>
    806c:      	sub	w10, w8, #0x3
    8070:      	cmp	w10, #0x2
    8074:      	b.lo	0x81d0 <generic_fentry_filter_arg+0x2c60>
    8078:      	cmp	w8, #0x6
    807c:      	b.eq	0x5808 <generic_fentry_filter_arg+0x298>
    8080:      	cmp	w8, #0xc
    8084:      	b.ne	0x566c <generic_fentry_filter_arg+0xfc>
    8088:      	ldrb	w10, [x22]
    808c:      	b	0x812c <generic_fentry_filter_arg+0x2bbc>
    8090:      	ldrh	w11, [x22]
    8094:      	cmp	w10, w11
    8098:      	b.lo	0x5808 <generic_fentry_filter_arg+0x298>
    809c:      	cmp	w9, #0x15
    80a0:      	b.lo	0x82fc <generic_fentry_filter_arg+0x2d8c>
    80a4:      	ldr	w9, [x29, #0x1c]
    80a8:      	cmp	w8, #0x2
    80ac:      	b.le	0x81b8 <generic_fentry_filter_arg+0x2c48>
    80b0:      	sub	w10, w8, #0x3
    80b4:      	cmp	w10, #0x2
    80b8:      	b.lo	0x81d8 <generic_fentry_filter_arg+0x2c68>
    80bc:      	cmp	w8, #0x6
    80c0:      	b.eq	0x5808 <generic_fentry_filter_arg+0x298>
    80c4:      	cmp	w8, #0xc
    80c8:      	b.ne	0x566c <generic_fentry_filter_arg+0xfc>
    80cc:      	ldrh	w10, [x22]
    80d0:      	b	0x812c <generic_fentry_filter_arg+0x2bbc>
    80d4:      	ldr	w12, [x22]
    80d8:      	cmp	w12, w11
    80dc:      	mov	w12, #0x1               // =1
    80e0:      	b.hi	0x5808 <generic_fentry_filter_arg+0x298>
    80e4:      	b	0x80f8 <generic_fentry_filter_arg+0x2b88>
    80e8:      	ldr	w12, [x22]
    80ec:      	cmp	w12, w11
    80f0:      	mov	w12, #0x1               // =1
    80f4:      	b.lo	0x5808 <generic_fentry_filter_arg+0x298>
    80f8:      	cmp	w10, #0x15
    80fc:      	b.lo	0x82fc <generic_fentry_filter_arg+0x2d8c>
    8100:      	ldr	w10, [x29, #0x1c]
    8104:      	cmp	w8, #0x2
    8108:      	b.le	0x8138 <generic_fentry_filter_arg+0x2bc8>
    810c:      	sub	w9, w8, #0x3
    8110:      	cmp	w9, #0x2
    8114:      	b.lo	0x8170 <generic_fentry_filter_arg+0x2c00>
    8118:      	cmp	w8, #0x6
    811c:      	b.eq	0x5808 <generic_fentry_filter_arg+0x298>
    8120:      	cmp	w8, #0xc
    8124:      	b.ne	0x566c <generic_fentry_filter_arg+0xfc>
    8128:      	ldr	w9, [x22]
    812c:      	tst	w9, w10
    8130:      	b.ne	0x5808 <generic_fentry_filter_arg+0x298>
    8134:      	b	0x82fc <generic_fentry_filter_arg+0x2d8c>
    8138:      	cmp	w8, #0x1
    813c:      	b.eq	0x8178 <generic_fentry_filter_arg+0x2c08>
    8140:      	cmp	w8, #0x2
    8144:      	b.ne	0x566c <generic_fentry_filter_arg+0xfc>
    8148:      	cmp	w9, #0xc
    814c:      	b.hi	0x82e0 <generic_fentry_filter_arg+0x2d70>
    8150:      	lsl	w9, w12, w9
    8154:      	mov	w11, #0x1402            // =5122
    8158:      	tst	w9, w11
    815c:      	b.eq	0x82e0 <generic_fentry_filter_arg+0x2d70>
    8160:      	ldr	w9, [x22]
    8164:      	cmp	w9, w10
    8168:      	b.lt	0x5808 <generic_fentry_filter_arg+0x298>
    816c:      	b	0x82fc <generic_fentry_filter_arg+0x2d8c>
    8170:      	ldr	w9, [x22]
    8174:      	b	0x81dc <generic_fentry_filter_arg+0x2c6c>
    8178:      	cmp	w9, #0xc
    817c:      	b.hi	0x82f0 <generic_fentry_filter_arg+0x2d80>
    8180:      	lsl	w9, w12, w9
    8184:      	mov	w11, #0x1402            // =5122
    8188:      	tst	w9, w11
    818c:      	b.eq	0x82f0 <generic_fentry_filter_arg+0x2d80>
    8190:      	ldr	w9, [x22]
    8194:      	cmp	w9, w10
    8198:      	b.gt	0x5808 <generic_fentry_filter_arg+0x298>
    819c:      	b	0x82fc <generic_fentry_filter_arg+0x2d8c>
    81a0:      	cmp	w8, #0x1
    81a4:      	b.eq	0x82d0 <generic_fentry_filter_arg+0x2d60>
    81a8:      	cmp	w8, #0x2
    81ac:      	b.ne	0x566c <generic_fentry_filter_arg+0xfc>
    81b0:      	ldrb	w10, [x22]
    81b4:      	b	0x82f4 <generic_fentry_filter_arg+0x2d84>
    81b8:      	cmp	w8, #0x1
    81bc:      	b.eq	0x82d8 <generic_fentry_filter_arg+0x2d68>
    81c0:      	cmp	w8, #0x2
    81c4:      	b.ne	0x566c <generic_fentry_filter_arg+0xfc>
    81c8:      	ldrh	w10, [x22]
    81cc:      	b	0x82f4 <generic_fentry_filter_arg+0x2d84>
    81d0:      	ldrb	w10, [x22]
    81d4:      	b	0x81dc <generic_fentry_filter_arg+0x2c6c>
    81d8:      	ldrh	w10, [x22]
    81dc:      	cmp	w9, w10
    81e0:      	b.eq	0x57fc <generic_fentry_filter_arg+0x28c>
    81e4:      	b	0x82fc <generic_fentry_filter_arg+0x2d8c>
    81e8:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    81ec:      	mov	w8, #0x1                // =1
    81f0:      	add	x9, sp, #0x60
    81f4:      	ldr	x0, [x0]
    81f8:      	b	0x8234 <generic_fentry_filter_arg+0x2cc4>
    81fc:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8200:      	mov	w8, #0x1                // =1
    8204:      	add	x9, sp, #0x60
    8208:      	ldr	x0, [x0]
    820c:      	b	0x8234 <generic_fentry_filter_arg+0x2cc4>
    8210:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8214:      	mov	w8, #0x1                // =1
    8218:      	add	x9, sp, #0x60
    821c:      	ldr	x0, [x0]
    8220:      	b	0x8234 <generic_fentry_filter_arg+0x2cc4>
    8224:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8228:      	mov	w8, #0x1                // =1
    822c:      	add	x9, sp, #0x60
    8230:      	ldr	x0, [x0]
    8234:      	add	x1, sp, #0x60
    8238:      	blr	x8
    823c:      	cbz	x0, 0x8258 <generic_fentry_filter_arg+0x2ce8>
    8240:      	mov	w8, #0x1                // =1
    8244:      	mov	x1, x19
    8248:      	blr	x8
    824c:      	cmp	x0, #0x0
    8250:      	cset	w23, ne
    8254:      	b	0x825c <generic_fentry_filter_arg+0x2cec>
    8258:      	mov	x23, xzr
    825c:      	ldp	x16, x15, [sp, #0x40]
    8260:      	mov	w2, #0x5ea0             // =24224
    8264:      	mov	w12, #0x1               // =1
    8268:      	ldr	x17, [sp, #0x38]
    826c:      	ldr	w8, [x29, #0x4]
    8270:      	cmp	w8, #0x25
    8274:      	b.hi	0x829c <generic_fentry_filter_arg+0x2d2c>
    8278:      	mov	x9, #0x50               // =80
    827c:      	ldr	x19, [sp, #0x30]
    8280:      	lsl	x8, x12, x8
    8284:      	movk	x9, #0xc00, lsl #16
    8288:      	movk	x9, #0x20, lsl #32
    828c:      	tst	x8, x9
    8290:      	b.eq	0x5804 <generic_fentry_filter_arg+0x294>
    8294:      	cmp	x23, #0x0
    8298:      	b	0x5800 <generic_fentry_filter_arg+0x290>
    829c:      	ldr	x19, [sp, #0x30]
    82a0:      	b	0x5804 <generic_fentry_filter_arg+0x294>
    82a4:      	ldr	x19, [sp, #0x30]
    82a8:      	mov	w12, #0x1               // =1
    82ac:      	b	0x73d0 <generic_fentry_filter_arg+0x1e60>
    82b0:      	ldr	x9, [x22]
    82b4:      	cmp	x9, x10
    82b8:      	b.lo	0x5808 <generic_fentry_filter_arg+0x298>
    82bc:      	b	0x82fc <generic_fentry_filter_arg+0x2d8c>
    82c0:      	ldr	x9, [x22]
    82c4:      	cmp	x9, x10
    82c8:      	b.hi	0x5808 <generic_fentry_filter_arg+0x298>
    82cc:      	b	0x82fc <generic_fentry_filter_arg+0x2d8c>
    82d0:      	ldrb	w10, [x22]
    82d4:      	b	0x82e4 <generic_fentry_filter_arg+0x2d74>
    82d8:      	ldrh	w10, [x22]
    82dc:      	b	0x82e4 <generic_fentry_filter_arg+0x2d74>
    82e0:      	ldr	w9, [x22]
    82e4:      	cmp	w9, w10
    82e8:      	b.lo	0x5808 <generic_fentry_filter_arg+0x298>
    82ec:      	b	0x82fc <generic_fentry_filter_arg+0x2d8c>
    82f0:      	ldr	w9, [x22]
    82f4:      	cmp	w9, w10
    82f8:      	b.hi	0x5808 <generic_fentry_filter_arg+0x298>
    82fc:      	orr	w8, w8, #0x2
    8300:      	cmp	w8, #0x6
    8304:      	b.eq	0x5808 <generic_fentry_filter_arg+0x298>
    8308:      	b	0x566c <generic_fentry_filter_arg+0xfc>
    830c:      	nop

0000000000008310 <generic_fentry_actions>:
    8310:      	sub	sp, sp, #0xe0
    8314:      	str	x29, [sp, #0x90]
    8318:      	stp	x30, x25, [sp, #0xa0]
    831c:      	stp	x24, x23, [sp, #0xb0]
    8320:      	stp	x22, x21, [sp, #0xc0]
    8324:      	stp	x20, x19, [sp, #0xd0]
    8328:      	str	x0, [sp, #0x50]
    832c:      	str	wzr, [sp, #0x5c]
    8330:      	adrp	x29, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8334:      	mov	w8, #0x1                // =1
    8338:      	add	x9, sp, #0x5c
    833c:      	add	x1, sp, #0x5c
    8340:      	ldr	x29, [x29]
    8344:      	mov	x0, x29
    8348:      	blr	x8
    834c:      	cbz	x0, 0x8dd8 <generic_fentry_actions+0xac8>
    8350:      	mov	w8, #0x5f04             // =24324
    8354:      	ldr	w19, [x0, x8]
    8358:      	cmp	w19, #0x2
    835c:      	b.lt	0x8dd8 <generic_fentry_actions+0xac8>
    8360:      	mov	w8, #0x5ef8             // =24312
    8364:      	add	x1, x0, x8
    8368:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    836c:      	mov	w8, #0x1                // =1
    8370:      	ldr	x0, [x0]
    8374:      	blr	x8
    8378:      	cbz	x0, 0x8dd8 <generic_fentry_actions+0xac8>
    837c:      	and	x8, x19, #0x7ff
    8380:      	add	x9, sp, #0x60
    8384:      	add	x1, sp, #0x60
    8388:      	ldr	w8, [x0, x8]
    838c:      	str	wzr, [sp, #0x60]
    8390:      	add	w8, w8, w19
    8394:      	and	w8, w8, #0x7ff
    8398:      	add	x21, x0, x8
    839c:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    83a0:      	mov	w8, #0x1                // =1
    83a4:      	ldr	x0, [x0]
    83a8:      	blr	x8
    83ac:      	cbz	x0, 0x83f4 <generic_fentry_actions+0xe4>
    83b0:      	ldrb	w8, [x0]
    83b4:      	mov	w11, #0x6               // =6
    83b8:      	mov	w14, #0x7               // =7
    83bc:      	mov	w10, #0x8               // =8
    83c0:      	mov	w12, #0x5               // =5
    83c4:      	mov	w13, #0x9               // =9
    83c8:      	ands	w8, w8, #0xff
    83cc:      	cset	w9, eq
    83d0:      	cmp	w8, #0x0
    83d4:      	str	w9, [sp, #0x48]
    83d8:      	mov	w9, #0x4                // =4
    83dc:      	csel	x8, x11, x14, eq
    83e0:      	csel	x11, x10, x13, eq
    83e4:      	str	x8, [sp, #0x30]
    83e8:      	csel	x8, x9, x12, eq
    83ec:      	stp	x11, x8, [sp, #0x38]
    83f0:      	b	0x8414 <generic_fentry_actions+0x104>
    83f4:      	mov	w8, #0x1                // =1
    83f8:      	str	w8, [sp, #0x48]
    83fc:      	mov	w8, #0x4                // =4
    8400:      	str	x8, [sp, #0x40]
    8404:      	mov	w8, #0x8                // =8
    8408:      	str	x8, [sp, #0x38]
    840c:      	mov	w8, #0x6                // =6
    8410:      	str	x8, [sp, #0x30]
    8414:      	adrp	x25, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8418:      	mov	w23, wzr
    841c:      	mov	w24, wzr
    8420:      	ldr	x25, [x25]
    8424:      	add	x20, sp, #0x64
    8428:      	mov	w8, #0x1                // =1
    842c:      	str	w8, [sp, #0x4c]
    8430:      	b	0x8450 <generic_fentry_actions+0x140>
    8434:      	nop
    8438:      	nop
    843c:      	nop
    8440:      	mov	w24, wzr
    8444:      	add	w23, w23, #0x1
    8448:      	cmp	w23, #0x3
    844c:      	b.eq	0x8db4 <generic_fentry_actions+0xaa4>
    8450:      	ldr	w9, [x21]
    8454:      	lsl	w8, w24, #2
    8458:      	add	w8, w8, #0x4
    845c:      	cmp	w8, w9
    8460:      	b.hs	0x8db4 <generic_fentry_actions+0xaa4>
    8464:      	add	x8, x21, w24, uxtw #2
    8468:      	add	x1, sp, #0x64
    846c:      	mov	x0, x29
    8470:      	ldrsw	x19, [x8, #0x4]
    8474:      	str	wzr, [sp, #0x64]
    8478:      	mov	w8, #0x1                // =1
    847c:      	blr	x8
    8480:      	cbz	x0, 0x8440 <generic_fentry_actions+0x130>
    8484:      	mov	x22, x0
    8488:      	cmp	w19, #0x7
    848c:      	b.gt	0x84c0 <generic_fentry_actions+0x1b0>
    8490:      	cmp	w19, #0x3
    8494:      	b.gt	0x8510 <generic_fentry_actions+0x200>
    8498:      	cmp	w19, #0x1
    849c:      	b.gt	0x8590 <generic_fentry_actions+0x280>
    84a0:      	cbz	w19, 0x86f4 <generic_fentry_actions+0x3e4>
    84a4:      	cmp	w19, #0x1
    84a8:      	b.eq	0x85a0 <generic_fentry_actions+0x290>
    84ac:      	adrp	x25, 0x8000 <generic_fentry_filter_arg+0x2a90>
    84b0:      	b	0x87f8 <generic_fentry_actions+0x4e8>
    84b4:      	nop
    84b8:      	nop
    84bc:      	nop
    84c0:      	cmp	w19, #0xb
    84c4:      	b.gt	0x8568 <generic_fentry_actions+0x258>
    84c8:      	sub	w8, w19, #0xa
    84cc:      	cmp	w8, #0x2
    84d0:      	b.lo	0x8604 <generic_fentry_actions+0x2f4>
    84d4:      	cmp	w19, #0x8
    84d8:      	b.eq	0x864c <generic_fentry_actions+0x33c>
    84dc:      	cmp	w19, #0x9
    84e0:      	b.ne	0x87fc <generic_fentry_actions+0x4ec>
    84e4:      	add	w24, w24, #0x1
    84e8:      	add	x8, x21, w24, uxtw #2
    84ec:      	ldr	w0, [x8, #0x4]
    84f0:      	ldr	w8, [sp, #0x48]
    84f4:      	add	x25, sp, #0x68
    84f8:      	cbz	w8, 0x879c <generic_fentry_actions+0x48c>
    84fc:      	sxtw	x8, w0
    8500:      	mov	w9, #0x6d               // =109
    8504:      	blr	x9
    8508:      	mov	w20, #0x2               // =2
    850c:      	b	0x87b0 <generic_fentry_actions+0x4a0>
    8510:      	sub	w8, w19, #0x6
    8514:      	cmp	w8, #0x2
    8518:      	b.lo	0x8638 <generic_fentry_actions+0x328>
    851c:      	cmp	w19, #0x4
    8520:      	b.eq	0x8654 <generic_fentry_actions+0x344>
    8524:      	cmp	w19, #0x5
    8528:      	b.ne	0x87fc <generic_fentry_actions+0x4ec>
    852c:      	add	w8, w24, #0x1
    8530:      	add	x9, x21, #0x4
    8534:      	add	w24, w24, #0x2
    8538:      	ldr	w8, [x9, w8, uxtw #2]
    853c:      	ldr	w20, [x9, w24, uxtw #2]
    8540:      	stp	xzr, xzr, [sp, #0x68]
    8544:      	and	x8, x8, #0x7
    8548:      	cmp	w8, #0x4
    854c:      	b.hi	0x8560 <generic_fentry_actions+0x250>
    8550:      	add	x9, x22, x8, lsl #2
    8554:      	mov	w10, #0x5ea0            // =24224
    8558:      	ldr	w9, [x9, x10]
    855c:      	cbz	w9, 0x89d8 <generic_fentry_actions+0x6c8>
    8560:      	add	x20, sp, #0x64
    8564:      	b	0x87fc <generic_fentry_actions+0x4ec>
    8568:      	cmp	w19, #0xc
    856c:      	b.eq	0x87a4 <generic_fentry_actions+0x494>
    8570:      	cmp	w19, #0xd
    8574:      	b.eq	0x8664 <generic_fentry_actions+0x354>
    8578:      	cmp	w19, #0xe
    857c:      	b.ne	0x87fc <generic_fentry_actions+0x4ec>
    8580:      	ldr	x20, [sp, #0x38]
    8584:      	add	x25, sp, #0x68
    8588:      	add	w24, w24, #0x2
    858c:      	b	0x87b0 <generic_fentry_actions+0x4a0>
    8590:      	cmp	w19, #0x2
    8594:      	b.eq	0x878c <generic_fentry_actions+0x47c>
    8598:      	cmp	w19, #0x3
    859c:      	b.ne	0x84ac <generic_fentry_actions+0x19c>
    85a0:      	add	w8, w24, #0x1
    85a4:      	add	x9, x21, #0x4
    85a8:      	add	w24, w24, #0x2
    85ac:      	ldr	w20, [x9, w24, uxtw #2]
    85b0:      	mov	x25, x21
    85b4:      	ldr	w21, [x9, w8, uxtw #2]
    85b8:      	str	wzr, [sp, #0x78]
    85bc:      	stp	xzr, xzr, [sp, #0x68]
    85c0:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    85c4:      	mov	w8, #0x1                // =1
    85c8:      	add	x9, sp, #0x78
    85cc:      	add	x1, sp, #0x78
    85d0:      	ldr	x0, [x0]
    85d4:      	blr	x8
    85d8:      	cbz	x0, 0x85ec <generic_fentry_actions+0x2dc>
    85dc:      	and	x8, x21, #0x7
    85e0:      	cmp	w8, #0x4
    85e4:      	b.ls	0x8814 <generic_fentry_actions+0x504>
    85e8:      	mov	w0, wzr
    85ec:      	mov	x21, x25
    85f0:      	adrp	x25, 0x8000 <generic_fentry_filter_arg+0x2a90>
    85f4:      	add	x20, sp, #0x64
    85f8:      	ldr	x25, [x25]
    85fc:      	cbnz	w0, 0x8440 <generic_fentry_actions+0x130>
    8600:      	b	0x87fc <generic_fentry_actions+0x4ec>
    8604:      	add	w24, w24, #0x1
    8608:      	add	x8, x21, w24, uxtw #2
    860c:      	ldr	w8, [x8, #0x4]
    8610:      	and	x8, x8, #0x7
    8614:      	cmp	w8, #0x4
    8618:      	b.hi	0x862c <generic_fentry_actions+0x31c>
    861c:      	add	x9, x22, x8, lsl #2
    8620:      	mov	w10, #0x5ea0            // =24224
    8624:      	ldr	w9, [x9, x10]
    8628:      	cbz	w9, 0x8830 <generic_fentry_actions+0x520>
    862c:      	mov	w0, wzr
    8630:      	cbnz	w0, 0x8440 <generic_fentry_actions+0x130>
    8634:      	b	0x87fc <generic_fentry_actions+0x4ec>
    8638:      	add	w24, w24, #0x1
    863c:      	add	x8, x21, w24, uxtw #2
    8640:      	ldr	w8, [x8, #0x4]
    8644:      	str	w8, [x22, #0x78]
    8648:      	b	0x87fc <generic_fentry_actions+0x4ec>
    864c:      	str	wzr, [sp, #0x4c]
    8650:      	b	0x87fc <generic_fentry_actions+0x4ec>
    8654:      	ldr	x20, [sp, #0x40]
    8658:      	add	x25, sp, #0x68
    865c:      	add	w24, w24, #0x1
    8660:      	b	0x87b0 <generic_fentry_actions+0x4a0>
    8664:      	mov	w8, #0xe                // =14
    8668:      	blr	x8
    866c:      	str	x0, [sp, #0x88]
    8670:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8674:      	mov	w8, #0x1                // =1
    8678:      	add	x9, sp, #0x88
    867c:      	ldr	x0, [x0]
    8680:      	add	x1, sp, #0x88
    8684:      	blr	x8
    8688:      	cbz	x0, 0x87fc <generic_fentry_actions+0x4ec>
    868c:      	ldur	x8, [x0, #0x4]
    8690:      	mov	x20, x21
    8694:      	add	x21, sp, #0x78
    8698:      	add	x1, sp, #0x78
    869c:      	str	x8, [sp, #0x78]
    86a0:      	mov	w8, #0x2                // =2
    86a4:      	mov	x0, x25
    86a8:      	str	w8, [sp, #0x80]
    86ac:      	mov	w8, #0x1                // =1
    86b0:      	blr	x8
    86b4:      	mov	w9, #0x1                // =1
    86b8:      	str	w9, [sp, #0x98]
    86bc:      	cbz	x0, 0x8968 <generic_fentry_actions+0x658>
    86c0:      	ldaxr	w8, [x0]
    86c4:      	add	w8, w8, #0x1
    86c8:      	stlxr	w9, w8, [x0]
    86cc:      	cbnz	w9, 0x86c0 <generic_fentry_actions+0x3b0>
    86d0:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    86d4:      	mov	w8, #0x3                // =3
    86d8:      	add	x9, sp, #0x88
    86dc:      	ldr	x0, [x0]
    86e0:      	add	x1, sp, #0x88
    86e4:      	blr	x8
    86e8:      	mov	x21, x20
    86ec:      	add	x20, sp, #0x64
    86f0:      	b	0x87fc <generic_fentry_actions+0x4ec>
    86f4:      	add	w8, w24, #0x1
    86f8:      	add	x9, x21, #0x4
    86fc:      	ldr	w25, [x9, w8, uxtw #2]
    8700:      	add	w8, w24, #0x2
    8704:      	ldr	w20, [x9, w8, uxtw #2]
    8708:      	mov	w8, #0x7d               // =125
    870c:      	blr	x8
    8710:      	str	x0, [sp, #0x68]
    8714:      	str	wzr, [sp, #0x88]
    8718:      	str	x25, [sp, #0x18]
    871c:      	cbz	w25, 0x8cbc <generic_fentry_actions+0x9ac>
    8720:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8724:      	mov	w8, #0x1                // =1
    8728:      	add	x9, sp, #0x88
    872c:      	ldr	x0, [x0]
    8730:      	add	x1, sp, #0x88
    8734:      	blr	x8
    8738:      	cbz	x0, 0x8cbc <generic_fentry_actions+0x9ac>
    873c:      	mov	x25, x0
    8740:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8744:      	mov	w8, #0x1                // =1
    8748:      	ldr	x0, [x0]
    874c:      	add	x9, sp, #0x88
    8750:      	add	x1, sp, #0x88
    8754:      	blr	x8
    8758:      	ldr	x8, [x22, #0x60]
    875c:      	mov	x2, x0
    8760:      	cmp	w20, #0x2
    8764:      	str	x8, [x25]
    8768:      	ldr	x8, [x22, #0x70]
    876c:      	str	x8, [x25, #0x8]
    8770:      	b.eq	0x8adc <generic_fentry_actions+0x7cc>
    8774:      	cmp	w20, #0x1
    8778:      	b.eq	0x8ad0 <generic_fentry_actions+0x7c0>
    877c:      	cbnz	w20, 0x8cbc <generic_fentry_actions+0x9ac>
    8780:      	ldr	w8, [x22, #0x7c]
    8784:      	str	x21, [sp, #0x8]
    8788:      	b	0x8ae4 <generic_fentry_actions+0x7d4>
    878c:      	mov	w0, #0x9                // =9
    8790:      	ldr	w8, [sp, #0x48]
    8794:      	add	x25, sp, #0x68
    8798:      	cbnz	w8, 0x84fc <generic_fentry_actions+0x1ec>
    879c:      	mov	w20, #0x3               // =3
    87a0:      	b	0x87b0 <generic_fentry_actions+0x4a0>
    87a4:      	ldr	x20, [sp, #0x30]
    87a8:      	add	x25, sp, #0x68
    87ac:      	add	w24, w24, #0x3
    87b0:      	str	wzr, [sp, #0x68]
    87b4:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    87b8:      	mov	w8, #0x1                // =1
    87bc:      	add	x1, sp, #0x68
    87c0:      	ldr	x0, [x0]
    87c4:      	blr	x8
    87c8:      	cbz	x0, 0x87f0 <generic_fentry_actions+0x4e0>
    87cc:      	add	x8, x0, x20, lsl #3
    87d0:      	nop
    87d4:      	nop
    87d8:      	nop
    87dc:      	nop
    87e0:      	ldaxr	x9, [x8]
    87e4:      	add	x9, x9, #0x1
    87e8:      	stlxr	w10, x9, [x8]
    87ec:      	cbnz	w10, 0x87e0 <generic_fentry_actions+0x4d0>
    87f0:      	adrp	x25, 0x8000 <generic_fentry_filter_arg+0x2a90>
    87f4:      	add	x20, sp, #0x64
    87f8:      	ldr	x25, [x25]
    87fc:      	add	w24, w24, #0x1
    8800:      	str	x19, [x22, #0x70]
    8804:      	add	w23, w23, #0x1
    8808:      	cmp	w23, #0x3
    880c:      	b.ne	0x8450 <generic_fentry_actions+0x140>
    8810:      	b	0x8db4 <generic_fentry_actions+0xaa4>
    8814:      	add	x9, x22, x8, lsl #2
    8818:      	mov	w10, #0x5ea0            // =24224
    881c:      	ldr	w9, [x9, x10]
    8820:      	cbz	w9, 0x88c8 <generic_fentry_actions+0x5b8>
    8824:      	mov	x21, x25
    8828:      	mov	w0, wzr
    882c:      	b	0x85f0 <generic_fentry_actions+0x2e0>
    8830:      	add	x8, x22, x8, lsl #3
    8834:      	ldr	x8, [x8, #0x5e78]
    8838:      	and	x8, x8, #0x7ff
    883c:      	add	x8, x22, x8
    8840:      	ldr	x8, [x8, #0xb8]
    8844:      	str	x8, [sp, #0x78]
    8848:      	cbz	x8, 0x862c <generic_fentry_actions+0x31c>
    884c:      	cmp	w19, #0xa
    8850:      	b.ne	0x8ab0 <generic_fentry_actions+0x7a0>
    8854:      	mov	w8, #0xe                // =14
    8858:      	add	x25, sp, #0x68
    885c:      	mov	x20, x21
    8860:      	blr	x8
    8864:      	lsr	x8, x0, #32
    8868:      	mov	x21, x0
    886c:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8870:      	str	w8, [sp, #0x68]
    8874:      	mov	w8, #0x1                // =1
    8878:      	add	x1, sp, #0x68
    887c:      	ldr	x0, [x0]
    8880:      	blr	x8
    8884:      	cbz	x0, 0x88bc <generic_fentry_actions+0x5ac>
    8888:      	ldr	w8, [x0]
    888c:      	mov	x3, xzr
    8890:      	add	x9, sp, #0x78
    8894:      	add	x1, sp, #0x78
    8898:      	stp	w8, w21, [sp, #0x68]
    889c:      	ldr	x8, [x0, #0x8]
    88a0:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    88a4:      	add	x2, sp, #0x68
    88a8:      	str	x8, [sp, #0x70]
    88ac:      	mov	w8, #0x2                // =2
    88b0:      	ldr	x0, [x0]
    88b4:      	blr	x8
    88b8:      	mov	w0, wzr
    88bc:      	adrp	x25, 0x8000 <generic_fentry_filter_arg+0x2a90>
    88c0:      	mov	x21, x20
    88c4:      	b	0x85f4 <generic_fentry_actions+0x2e4>
    88c8:      	add	x8, x22, x8, lsl #3
    88cc:      	mov	x21, x0
    88d0:      	ldr	x8, [x8, #0x5e78]
    88d4:      	str	wzr, [sp, #0x74]
    88d8:      	and	x8, x8, #0x7ff
    88dc:      	add	x8, x22, x8
    88e0:      	ldr	w8, [x8, #0x90]
    88e4:      	str	w8, [sp, #0x70]
    88e8:      	mov	w8, #0xe                // =14
    88ec:      	blr	x8
    88f0:      	lsr	x8, x0, #32
    88f4:      	cmp	w19, #0x1
    88f8:      	str	x8, [sp, #0x68]
    88fc:      	b.ne	0x8a94 <generic_fentry_actions+0x784>
    8900:      	and	x8, x20, #0x7
    8904:      	cmp	w8, #0x4
    8908:      	b.hi	0x85e8 <generic_fentry_actions+0x2d8>
    890c:      	add	x9, x22, x8, lsl #2
    8910:      	mov	w10, #0x5ea0            // =24224
    8914:      	add	x20, sp, #0x68
    8918:      	ldr	w9, [x9, x10]
    891c:      	cbnz	w9, 0x85e8 <generic_fentry_actions+0x2d8>
    8920:      	add	x8, x22, x8, lsl #3
    8924:      	mov	x0, x21
    8928:      	ldr	x8, [x8, #0x5e78]
    892c:      	and	x8, x8, #0x7ff
    8930:      	add	x2, x22, x8
    8934:      	ldr	w8, [x2, #0x90]!
    8938:      	and	x8, x8, #0xfff
    893c:      	add	x1, x8, #0x8
    8940:      	mov	w8, #0x4                // =4
    8944:      	blr	x8
    8948:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    894c:      	mov	x3, xzr
    8950:      	mov	w8, #0x2                // =2
    8954:      	ldr	x0, [x0]
    8958:      	add	x1, sp, #0x68
    895c:      	mov	x2, x21
    8960:      	blr	x8
    8964:      	b	0x85e8 <generic_fentry_actions+0x2d8>
    8968:      	mov	w8, #0x2                // =2
    896c:      	add	x10, sp, #0x98
    8970:      	add	x1, sp, #0x78
    8974:      	add	x2, sp, #0x98
    8978:      	mov	x0, x25
    897c:      	mov	w3, #0x1                // =1
    8980:      	blr	x8
    8984:      	cbz	x0, 0x86d0 <generic_fentry_actions+0x3c0>
    8988:      	mov	x21, x0
    898c:      	adrp	x25, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8990:      	add	x9, sp, #0x68
    8994:      	add	x1, sp, #0x68
    8998:      	neg	w8, w21
    899c:      	strh	w8, [sp, #0x68]
    89a0:      	mov	w8, #0x3                // =3
    89a4:      	strh	w8, [sp, #0x6a]
    89a8:      	mov	x8, #0x3b               // =59
    89ac:      	movk	x8, #0x2, lsl #32
    89b0:      	stur	x8, [sp, #0x6c]
    89b4:      	mov	w8, #0x1                // =1
    89b8:      	ldr	x25, [x25]
    89bc:      	mov	x0, x25
    89c0:      	blr	x8
    89c4:      	cbz	x0, 0x8d40 <generic_fentry_actions+0xa30>
    89c8:      	ldr	w8, [x0]
    89cc:      	add	w8, w8, #0x1
    89d0:      	str	w8, [x0]
    89d4:      	b	0x8d68 <generic_fentry_actions+0xa58>
    89d8:      	add	x8, x22, x8, lsl #3
    89dc:      	ldr	x8, [x8, #0x5e78]
    89e0:      	and	x8, x8, #0x7ff
    89e4:      	add	x8, x22, x8
    89e8:      	ldr	w8, [x8, #0x90]
    89ec:      	str	w8, [sp, #0x70]
    89f0:      	mov	w8, #0xe                // =14
    89f4:      	blr	x8
    89f8:      	lsr	x8, x0, #32
    89fc:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8a00:      	add	x9, sp, #0x68
    8a04:      	str	x8, [sp, #0x68]
    8a08:      	mov	w8, #0x1                // =1
    8a0c:      	add	x1, sp, #0x68
    8a10:      	ldr	x0, [x0]
    8a14:      	blr	x8
    8a18:      	cbz	x0, 0x8560 <generic_fentry_actions+0x250>
    8a1c:      	and	x8, x20, #0x7
    8a20:      	cmp	w8, #0x4
    8a24:      	b.hi	0x8560 <generic_fentry_actions+0x250>
    8a28:      	add	x9, x22, x8, lsl #2
    8a2c:      	mov	w10, #0x5ea0            // =24224
    8a30:      	ldr	w9, [x9, x10]
    8a34:      	cbnz	w9, 0x8560 <generic_fentry_actions+0x250>
    8a38:      	add	x8, x22, x8, lsl #3
    8a3c:      	mov	x20, x21
    8a40:      	mov	x21, x0
    8a44:      	ldr	x8, [x8, #0x5e78]
    8a48:      	str	wzr, [sp, #0x74]
    8a4c:      	and	x8, x8, #0x7ff
    8a50:      	add	x8, x22, x8
    8a54:      	ldr	w8, [x8, #0x90]
    8a58:      	str	w8, [sp, #0x70]
    8a5c:      	mov	w8, #0xe                // =14
    8a60:      	blr	x8
    8a64:      	lsr	x8, x0, #32
    8a68:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8a6c:      	mov	x3, xzr
    8a70:      	str	x8, [sp, #0x68]
    8a74:      	mov	w8, #0x2                // =2
    8a78:      	add	x9, sp, #0x68
    8a7c:      	add	x1, sp, #0x68
    8a80:      	ldr	x0, [x0]
    8a84:      	mov	x2, x21
    8a88:      	mov	x21, x20
    8a8c:      	blr	x8
    8a90:      	b	0x8560 <generic_fentry_actions+0x250>
    8a94:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8a98:      	mov	w8, #0x3                // =3
    8a9c:      	add	x9, sp, #0x68
    8aa0:      	ldr	x0, [x0]
    8aa4:      	add	x1, sp, #0x68
    8aa8:      	blr	x8
    8aac:      	b	0x85ec <generic_fentry_actions+0x2dc>
    8ab0:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8ab4:      	mov	w8, #0x3                // =3
    8ab8:      	add	x9, sp, #0x78
    8abc:      	ldr	x0, [x0]
    8ac0:      	add	x1, sp, #0x78
    8ac4:      	blr	x8
    8ac8:      	cbnz	w0, 0x8440 <generic_fentry_actions+0x130>
    8acc:      	b	0x87fc <generic_fentry_actions+0x4ec>
    8ad0:      	ldr	w8, [x22, #0x10]
    8ad4:      	str	x21, [sp, #0x8]
    8ad8:      	b	0x8ae4 <generic_fentry_actions+0x7d4>
    8adc:      	str	x21, [sp, #0x8]
    8ae0:      	mov	x8, xzr
    8ae4:      	str	x8, [x25, #0x10]
    8ae8:      	str	x25, [sp, #0x10]
    8aec:      	add	x0, x25, #0x18
    8af0:      	mov	w8, #0x4                // =4
    8af4:      	mov	w9, #0xc8               // =200
    8af8:      	mov	w1, #0xc8               // =200
    8afc:      	str	x0, [sp, #0x20]
    8b00:      	blr	x8
    8b04:      	str	wzr, [sp, #0x2c]
    8b08:      	adrp	x25, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8b0c:      	mov	w8, #0x5e78             // =24184
    8b10:      	mov	x21, xzr
    8b14:      	ldr	x25, [x25]
    8b18:      	add	x20, x22, x8
    8b1c:      	b	0x8b30 <generic_fentry_actions+0x820>
    8b20:      	add	x21, x21, #0x4
    8b24:      	add	x20, x20, #0x8
    8b28:      	cmp	x21, #0x14
    8b2c:      	b.eq	0x8c58 <generic_fentry_actions+0x948>
    8b30:      	str	wzr, [sp, #0x78]
    8b34:      	mov	w8, #0x1                // =1
    8b38:      	add	x9, sp, #0x78
    8b3c:      	add	x1, sp, #0x78
    8b40:      	mov	x0, x29
    8b44:      	blr	x8
    8b48:      	cbz	x0, 0x8c58 <generic_fentry_actions+0x948>
    8b4c:      	mov	w8, #0x5ef8             // =24312
    8b50:      	add	x1, x0, x8
    8b54:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8b58:      	mov	w8, #0x1                // =1
    8b5c:      	ldr	x0, [x0]
    8b60:      	blr	x8
    8b64:      	cbz	x0, 0x8c58 <generic_fentry_actions+0x948>
    8b68:      	add	x8, x0, x21
    8b6c:      	ldr	w8, [x8, #0x40]
    8b70:      	cmn	w8, #0x1
    8b74:      	b.eq	0x8c58 <generic_fentry_actions+0x948>
    8b78:      	ldr	x8, [x20]
    8b7c:      	ldr	w9, [x22, #0x4]
    8b80:      	cmp	x8, x9
    8b84:      	b.ge	0x8c58 <generic_fentry_actions+0x948>
    8b88:      	cmp	x21, #0x10
    8b8c:      	b.eq	0x8bec <generic_fentry_actions+0x8dc>
    8b90:      	str	wzr, [sp, #0x78]
    8b94:      	mov	w8, #0x1                // =1
    8b98:      	add	x9, sp, #0x78
    8b9c:      	add	x1, sp, #0x78
    8ba0:      	mov	x0, x29
    8ba4:      	blr	x8
    8ba8:      	cbz	x0, 0x8be8 <generic_fentry_actions+0x8d8>
    8bac:      	mov	w8, #0x5ef8             // =24312
    8bb0:      	add	x1, x0, x8
    8bb4:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8bb8:      	mov	w8, #0x1                // =1
    8bbc:      	ldr	x0, [x0]
    8bc0:      	blr	x8
    8bc4:      	cbz	x0, 0x8be8 <generic_fentry_actions+0x8d8>
    8bc8:      	add	x8, x0, x21
    8bcc:      	ldr	w9, [x8, #0x44]
    8bd0:      	ldr	x8, [x20]
    8bd4:      	cmn	w9, #0x1
    8bd8:      	b.eq	0x8bec <generic_fentry_actions+0x8dc>
    8bdc:      	ldr	w9, [x20, #0x8]
    8be0:      	sub	w9, w9, w8
    8be4:      	b	0x8bf8 <generic_fentry_actions+0x8e8>
    8be8:      	ldr	x8, [x20]
    8bec:      	ldr	w9, [x22, #0x4]
    8bf0:      	sub	w9, w9, w8
    8bf4:      	add	w9, w9, #0x4
    8bf8:      	cmp	w9, #0x1
    8bfc:      	b.lt	0x8b20 <generic_fentry_actions+0x810>
    8c00:      	mov	w10, #0x3ffc            // =16380
    8c04:      	cmp	w9, #0x28
    8c08:      	add	w8, w8, w10
    8c0c:      	mov	w10, #0x28              // =40
    8c10:      	csel	w29, w9, w10, lt
    8c14:      	ldr	w9, [sp, #0x2c]
    8c18:      	and	x8, x8, #0x3fff
    8c1c:      	add	x8, x22, x8
    8c20:      	mov	w1, w29
    8c24:      	add	x2, x8, #0x90
    8c28:      	mov	w8, #0x4                // =4
    8c2c:      	and	w25, w9, #0xff
    8c30:      	ldr	x9, [sp, #0x20]
    8c34:      	add	x0, x9, x25
    8c38:      	blr	x8
    8c3c:      	add	w8, w29, w25
    8c40:      	adrp	x25, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8c44:      	adrp	x29, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8c48:      	str	w8, [sp, #0x2c]
    8c4c:      	ldr	x25, [x25]
    8c50:      	ldr	x29, [x29]
    8c54:      	b	0x8b20 <generic_fentry_actions+0x810>
    8c58:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8c5c:      	mov	w8, #0x1                // =1
    8c60:      	ldr	x0, [x0]
    8c64:      	ldr	x1, [sp, #0x10]
    8c68:      	blr	x8
    8c6c:      	ldr	x21, [sp, #0x8]
    8c70:      	cbz	x0, 0x8c9c <generic_fentry_actions+0x98c>
    8c74:      	ldr	x9, [sp, #0x68]
    8c78:      	ldr	x11, [sp, #0x18]
    8c7c:      	mov	x10, #-0x4240           // =-16960
    8c80:      	movk	x10, #0xfff0, lsl #16
    8c84:      	ldr	x8, [x0]
    8c88:      	madd	x9, x11, x10, x9
    8c8c:      	cmp	x8, x9
    8c90:      	b.ls	0x8c9c <generic_fentry_actions+0x98c>
    8c94:      	str	wzr, [sp, #0x4c]
    8c98:      	b	0x8cc4 <generic_fentry_actions+0x9b4>
    8c9c:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8ca0:      	mov	x3, xzr
    8ca4:      	mov	w8, #0x2                // =2
    8ca8:      	ldr	x0, [x0]
    8cac:      	ldr	x1, [sp, #0x10]
    8cb0:      	add	x9, sp, #0x68
    8cb4:      	add	x2, sp, #0x68
    8cb8:      	blr	x8
    8cbc:      	adrp	x25, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8cc0:      	ldr	x25, [x25]
    8cc4:      	add	w8, w24, #0x3
    8cc8:      	add	x20, sp, #0x64
    8ccc:      	add	x8, x21, w8, uxtw #2
    8cd0:      	ldr	w8, [x8, #0x4]
    8cd4:      	cbz	w8, 0x8d00 <generic_fentry_actions+0x9f0>
    8cd8:      	ldrb	w8, [x22, #0x1]
    8cdc:      	adrp	x1, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8ce0:      	ldr	x0, [sp, #0x50]
    8ce4:      	mov	x2, xzr
    8ce8:      	orr	w8, w8, #0x2
    8cec:      	strb	w8, [x22, #0x1]
    8cf0:      	mov	w8, #0x1b               // =27
    8cf4:      	ldr	x1, [x1]
    8cf8:      	blr	x8
    8cfc:      	str	x0, [x22, #0x80]
    8d00:      	add	w24, w24, #0x4
    8d04:      	add	x8, x21, w24, uxtw #2
    8d08:      	ldr	w8, [x8, #0x4]
    8d0c:      	cbz	w8, 0x87fc <generic_fentry_actions+0x4ec>
    8d10:      	ldrb	w8, [x22, #0x1]
    8d14:      	adrp	x1, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8d18:      	ldr	x0, [sp, #0x50]
    8d1c:      	mov	w9, #0x100              // =256
    8d20:      	mov	w2, #0x100              // =256
    8d24:      	orr	w8, w8, #0x4
    8d28:      	strb	w8, [x22, #0x1]
    8d2c:      	mov	w8, #0x1b               // =27
    8d30:      	ldr	x1, [x1]
    8d34:      	blr	x8
    8d38:      	str	x0, [x22, #0x88]
    8d3c:      	b	0x87fc <generic_fentry_actions+0x4ec>
    8d40:      	mov	w8, #0x1                // =1
    8d44:      	mov	x3, xzr
    8d48:      	add	x9, sp, #0x9c
    8d4c:      	str	w8, [sp, #0x9c]
    8d50:      	mov	w8, #0x2                // =2
    8d54:      	add	x10, sp, #0x68
    8d58:      	add	x1, sp, #0x68
    8d5c:      	add	x2, sp, #0x9c
    8d60:      	mov	x0, x25
    8d64:      	blr	x8
    8d68:      	adrp	x25, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8d6c:      	ldr	x25, [x25]
    8d70:      	cbz	w21, 0x86d0 <generic_fentry_actions+0x3c0>
    8d74:      	mov	w8, #0x1                // =1
    8d78:      	add	x9, sp, #0x78
    8d7c:      	add	x1, sp, #0x78
    8d80:      	mov	x0, x25
    8d84:      	blr	x8
    8d88:      	cbz	x0, 0x86d0 <generic_fentry_actions+0x3c0>
    8d8c:      	ldr	w8, [sp, #0x98]
    8d90:      	nop
    8d94:      	nop
    8d98:      	nop
    8d9c:      	nop
    8da0:      	ldaxr	w9, [x0]
    8da4:      	add	w9, w9, w8
    8da8:      	stlxr	w10, w9, [x0]
    8dac:      	cbnz	w10, 0x8da0 <generic_fentry_actions+0xa90>
    8db0:      	b	0x86d0 <generic_fentry_actions+0x3c0>
    8db4:      	ldr	w8, [sp, #0x4c]
    8db8:      	cbz	w8, 0x8dd8 <generic_fentry_actions+0xac8>
    8dbc:      	adrp	x1, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8dc0:      	mov	w8, #0x5                // =5
    8dc4:      	mov	w9, #0xc                // =12
    8dc8:      	ldr	x1, [x1]
    8dcc:      	ldr	x0, [sp, #0x50]
    8dd0:      	mov	w2, #0x5                // =5
    8dd4:      	blr	x9
    8dd8:      	ldp	x20, x19, [sp, #0xd0]
    8ddc:      	mov	w0, wzr
    8de0:      	ldr	x29, [sp, #0x90]
    8de4:      	ldp	x22, x21, [sp, #0xc0]
    8de8:      	ldp	x24, x23, [sp, #0xb0]
    8dec:      	ldp	x30, x25, [sp, #0xa0]
    8df0:      	add	sp, sp, #0xe0
    8df4:      	ret
    8df8:      	nop
    8dfc:      	nop

0000000000008e00 <generic_fentry_output>:
    8e00:      	sub	sp, sp, #0xc0
    8e04:      	str	x29, [sp, #0x70]
    8e08:      	stp	x30, x25, [sp, #0x80]
    8e0c:      	stp	x24, x23, [sp, #0x90]
    8e10:      	stp	x22, x21, [sp, #0xa0]
    8e14:      	stp	x20, x19, [sp, #0xb0]
    8e18:      	mov	x19, x0
    8e1c:      	str	wzr, [sp, #0x4]
    8e20:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8e24:      	mov	w8, #0x1                // =1
    8e28:      	ldr	x0, [x0]
    8e2c:      	add	x9, sp, #0x4
    8e30:      	add	x1, sp, #0x4
    8e34:      	blr	x8
    8e38:      	cbz	x0, 0x9298 <generic_fentry_output+0x498>
    8e3c:      	adrp	x21, 0x8000 <generic_fentry_filter_arg+0x2a90>
    8e40:      	ldr	x8, [x0, #0x5ee8]
    8e44:      	mov	x20, x0
    8e48:      	ldr	x21, [x21]
    8e4c:      	cbz	x8, 0x90d8 <generic_fentry_output+0x2d8>
    8e50:      	mov	w8, #0xe                // =14
    8e54:      	blr	x8
    8e58:      	mov	w8, #0x23               // =35
    8e5c:      	lsr	x22, x0, #32
    8e60:      	blr	x8
    8e64:      	str	w22, [sp, #0x28]
    8e68:      	mov	w8, #0x1                // =1
    8e6c:      	add	x9, sp, #0x28
    8e70:      	mov	x23, x0
    8e74:      	add	x1, sp, #0x28
    8e78:      	mov	x0, x21
    8e7c:      	blr	x8
    8e80:      	cbz	x0, 0x90d8 <generic_fentry_output+0x2d8>
    8e84:      	add	x2, x23, #0xb50
    8e88:      	mov	w29, #0x8               // =8
    8e8c:      	add	x8, sp, #0x78
    8e90:      	mov	w9, #0x4                // =4
    8e94:      	mov	x22, x0
    8e98:      	add	x24, x0, #0x28
    8e9c:      	add	x0, sp, #0x78
    8ea0:      	mov	w1, #0x8                // =8
    8ea4:      	mov	w25, #0x4               // =4
    8ea8:      	blr	x9
    8eac:      	ldr	x8, [sp, #0x78]
    8eb0:      	mov	w9, #0x48               // =72
    8eb4:      	add	x10, sp, #0x28
    8eb8:      	mov	w11, #0x4               // =4
    8ebc:      	ldr	x2, [sp, #0x78]
    8ec0:      	add	x0, sp, #0x28
    8ec4:      	mov	w1, #0x48               // =72
    8ec8:      	blr	x11
    8ecc:      	ldr	x8, [sp, #0x30]
    8ed0:      	mov	w9, #0x4                // =4
    8ed4:      	mov	x0, x24
    8ed8:      	mov	w1, #0x4                // =4
    8edc:      	add	x8, x8, #0x218
    8ee0:      	ldr	x8, [sp, #0x30]
    8ee4:      	add	x2, x8, #0x218
    8ee8:      	blr	x9
    8eec:      	ldr	x8, [sp, #0x38]
    8ef0:      	add	x0, x22, #0x2c
    8ef4:      	mov	w9, #0x4                // =4
    8ef8:      	mov	w1, #0x4                // =4
    8efc:      	add	x8, x8, #0x4d8
    8f00:      	ldr	x8, [sp, #0x38]
    8f04:      	add	x2, x8, #0x4d8
    8f08:      	blr	x9
    8f0c:      	ldr	x8, [sp, #0x40]
    8f10:      	add	x0, x22, #0x30
    8f14:      	mov	w9, #0x4                // =4
    8f18:      	mov	w1, #0x4                // =4
    8f1c:      	add	x8, x8, #0x58
    8f20:      	ldr	x8, [sp, #0x40]
    8f24:      	add	x2, x8, #0x58
    8f28:      	blr	x9
    8f2c:      	str	xzr, [sp, #0x20]
    8f30:      	add	x2, x23, #0x938
    8f34:      	add	x8, sp, #0x20
    8f38:      	add	x0, sp, #0x20
    8f3c:      	mov	w1, #0x8                // =8
    8f40:      	blr	x25
    8f44:      	ldr	x8, [sp, #0x20]
    8f48:      	cbz	x8, 0x8fcc <generic_fentry_output+0x1cc>
    8f4c:      	str	wzr, [sp, #0x1c]
    8f50:      	add	x8, x8, #0x4
    8f54:      	add	x9, sp, #0x1c
    8f58:      	mov	w10, #0x4               // =4
    8f5c:      	add	x0, sp, #0x1c
    8f60:      	mov	w1, #0x4                // =4
    8f64:      	mov	w24, #0x4               // =4
    8f68:      	ldr	x8, [sp, #0x20]
    8f6c:      	add	x2, x8, #0x4
    8f70:      	blr	x10
    8f74:      	ldr	x8, [sp, #0x20]
    8f78:      	ldrsw	x9, [sp, #0x1c]
    8f7c:      	add	x10, sp, #0x8
    8f80:      	mov	w11, #0x4               // =4
    8f84:      	add	x0, sp, #0x8
    8f88:      	mov	w1, #0x10               // =16
    8f8c:      	add	x8, x8, x9, lsl #4
    8f90:      	mov	w9, #0x10               // =16
    8f94:      	add	x8, x8, #0x80
    8f98:      	ldr	x8, [sp, #0x20]
    8f9c:      	ldrsw	x9, [sp, #0x1c]
    8fa0:      	add	x8, x8, x9, lsl #4
    8fa4:      	add	x2, x8, #0x80
    8fa8:      	blr	x11
    8fac:      	ldr	x8, [sp, #0x10]
    8fb0:      	add	x0, x22, #0x34
    8fb4:      	mov	w1, #0x4                // =4
    8fb8:      	add	x8, x8, #0x158
    8fbc:      	ldr	x8, [sp, #0x10]
    8fc0:      	add	x2, x8, #0x158
    8fc4:      	blr	x24
    8fc8:      	b	0x8fd0 <generic_fentry_output+0x1d0>
    8fcc:      	str	wzr, [x22, #0x34]
    8fd0:      	ldr	x8, [sp, #0x48]
    8fd4:      	add	x0, x22, #0x38
    8fd8:      	mov	w9, #0x4                // =4
    8fdc:      	mov	w1, #0x4                // =4
    8fe0:      	mov	w24, #0x4               // =4
    8fe4:      	add	x8, x8, #0x158
    8fe8:      	ldr	x8, [sp, #0x48]
    8fec:      	add	x2, x8, #0x158
    8ff0:      	blr	x9
    8ff4:      	ldr	x8, [sp, #0x50]
    8ff8:      	add	x0, x22, #0x3c
    8ffc:      	mov	w9, #0x4                // =4
    9000:      	mov	w1, #0x4                // =4
    9004:      	add	x8, x8, #0x118
    9008:      	ldr	x8, [sp, #0x50]
    900c:      	add	x2, x8, #0x118
    9010:      	blr	x9
    9014:      	ldr	x8, [sp, #0x58]
    9018:      	add	x0, x22, #0x40
    901c:      	mov	w9, #0x4                // =4
    9020:      	mov	w1, #0x4                // =4
    9024:      	add	x8, x8, #0x98
    9028:      	ldr	x8, [sp, #0x58]
    902c:      	add	x2, x8, #0x98
    9030:      	blr	x9
    9034:      	ldr	x8, [sp, #0x60]
    9038:      	add	x0, x22, #0x44
    903c:      	mov	w9, #0x4                // =4
    9040:      	mov	w1, #0x4                // =4
    9044:      	add	x8, x8, #0x98
    9048:      	ldr	x8, [sp, #0x60]
    904c:      	add	x2, x8, #0x98
    9050:      	blr	x9
    9054:      	ldr	x8, [sp, #0x68]
    9058:      	add	x0, x22, #0x48
    905c:      	mov	w9, #0x4                // =4
    9060:      	mov	w1, #0x4                // =4
    9064:      	add	x8, x8, #0x58
    9068:      	ldr	x8, [sp, #0x68]
    906c:      	add	x2, x8, #0x58
    9070:      	blr	x9
    9074:      	str	xzr, [sp, #0x8]
    9078:      	str	xzr, [sp, #0x20]
    907c:      	add	x2, x23, #0xae0
    9080:      	mov	w23, #0x8               // =8
    9084:      	add	x8, sp, #0x8
    9088:      	mov	w9, #0x4                // =4
    908c:      	add	x0, sp, #0x8
    9090:      	mov	w1, #0x8                // =8
    9094:      	blr	x9
    9098:      	ldr	x8, [sp, #0x8]
    909c:      	add	x9, sp, #0x20
    90a0:      	mov	w10, #0x4               // =4
    90a4:      	add	x0, sp, #0x20
    90a8:      	mov	w1, #0x8                // =8
    90ac:      	add	x8, x8, #0x90
    90b0:      	ldr	x8, [sp, #0x8]
    90b4:      	add	x2, x8, #0x90
    90b8:      	blr	x10
    90bc:      	ldr	x8, [sp, #0x20]
    90c0:      	add	x0, x22, #0x4c
    90c4:      	mov	w1, #0x4                // =4
    90c8:      	add	x8, x8, #0x158
    90cc:      	ldr	x8, [sp, #0x20]
    90d0:      	add	x2, x8, #0x158
    90d4:      	blr	x24
    90d8:      	ldr	x8, [x20, #0x5ef0]
    90dc:      	cbz	x8, 0x9178 <generic_fentry_output+0x378>
    90e0:      	mov	w8, #0xe                // =14
    90e4:      	blr	x8
    90e8:      	mov	w8, #0x23               // =35
    90ec:      	lsr	x23, x0, #32
    90f0:      	blr	x8
    90f4:      	str	w23, [sp, #0x28]
    90f8:      	mov	w8, #0x1                // =1
    90fc:      	add	x9, sp, #0x28
    9100:      	mov	x22, x0
    9104:      	add	x1, sp, #0x28
    9108:      	mov	x0, x21
    910c:      	blr	x8
    9110:      	cbz	x0, 0x9178 <generic_fentry_output+0x378>
    9114:      	add	x2, x22, #0xae0
    9118:      	mov	w22, #0x8               // =8
    911c:      	add	x8, sp, #0x28
    9120:      	mov	w9, #0x4                // =4
    9124:      	add	x21, x0, #0x50
    9128:      	mov	x24, x0
    912c:      	add	x0, sp, #0x28
    9130:      	mov	w1, #0x8                // =8
    9134:      	mov	w23, #0x4               // =4
    9138:      	blr	x9
    913c:      	ldr	x25, [sp, #0x28]
    9140:      	add	x0, x24, #0x58
    9144:      	mov	w8, #0x4                // =4
    9148:      	mov	w1, #0x8                // =8
    914c:      	add	x2, x25, #0x40
    9150:      	blr	x8
    9154:      	add	x0, x24, #0x60
    9158:      	add	x2, x25, #0x30
    915c:      	mov	w8, #0x4                // =4
    9160:      	mov	w1, #0x8                // =8
    9164:      	blr	x8
    9168:      	add	x2, x25, #0x38
    916c:      	mov	x0, x21
    9170:      	mov	w1, #0x8                // =8
    9174:      	blr	x23
    9178:      	ldr	w8, [x20, #0x4]
    917c:      	mov	w9, #0x2328             // =9000
    9180:      	adrp	x1, 0x9000 <generic_fentry_output+0x200>
    9184:      	mov	x0, x19
    9188:      	ldr	x1, [x1]
    918c:      	mov	w2, #-0x1               // =-1
    9190:      	mov	x3, x20
    9194:      	add	w8, w8, #0x90
    9198:      	and	w8, w8, #0x7fff
    919c:      	cmp	w8, w9
    91a0:      	csel	w4, w8, w9, lo
    91a4:      	mov	w8, #-0x1               // =-1
    91a8:      	mov	w9, #0x19               // =25
    91ac:      	blr	x9
    91b0:      	tbnz	x0, #0x3f, 0x91f4 <generic_fentry_output+0x3f4>
    91b4:      	str	wzr, [sp, #0x28]
    91b8:      	adrp	x0, 0x9000 <generic_fentry_output+0x200>
    91bc:      	mov	w8, #0x1                // =1
    91c0:      	add	x9, sp, #0x28
    91c4:      	ldr	x0, [x0]
    91c8:      	add	x1, sp, #0x28
    91cc:      	blr	x8
    91d0:      	cbz	x0, 0x9298 <generic_fentry_output+0x498>
    91d4:      	add	x8, x0, #0x8
    91d8:      	nop
    91dc:      	nop
    91e0:      	ldaxr	x9, [x8]
    91e4:      	add	x9, x9, #0x1
    91e8:      	stlxr	w10, x9, [x8]
    91ec:      	cbnz	w10, 0x91e0 <generic_fentry_output+0x3e0>
    91f0:      	b	0x9298 <generic_fentry_output+0x498>
    91f4:      	mov	x19, x0
    91f8:      	str	wzr, [sp, #0x28]
    91fc:      	adrp	x0, 0x9000 <generic_fentry_output+0x200>
    9200:      	mov	w8, #0x1                // =1
    9204:      	ldr	x0, [x0]
    9208:      	add	x9, sp, #0x28
    920c:      	add	x1, sp, #0x28
    9210:      	blr	x8
    9214:      	cbz	x0, 0x9298 <generic_fentry_output+0x498>
    9218:      	mov	x8, x19
    921c:      	cmn	x19, #0xc
    9220:      	b.gt	0x9244 <generic_fentry_output+0x444>
    9224:      	cmn	x8, #0x1c
    9228:      	b.eq	0x9264 <generic_fentry_output+0x464>
    922c:      	cmn	x8, #0x16
    9230:      	b.eq	0x927c <generic_fentry_output+0x47c>
    9234:      	cmn	x8, #0x10
    9238:      	b.ne	0x9274 <generic_fentry_output+0x474>
    923c:      	add	x8, x0, #0x2f0
    9240:      	b	0x9288 <generic_fentry_output+0x488>
    9244:      	cmn	x8, #0xb
    9248:      	b.eq	0x926c <generic_fentry_output+0x46c>
    924c:      	cmn	x8, #0x7
    9250:      	b.eq	0x9284 <generic_fentry_output+0x484>
    9254:      	cmn	x8, #0x2
    9258:      	b.ne	0x9274 <generic_fentry_output+0x474>
    925c:      	add	x8, x0, #0x2e0
    9260:      	b	0x9288 <generic_fentry_output+0x488>
    9264:      	add	x8, x0, #0x300
    9268:      	b	0x9288 <generic_fentry_output+0x488>
    926c:      	add	x8, x0, #0x308
    9270:      	b	0x9288 <generic_fentry_output+0x488>
    9274:      	add	x8, x0, #0x2d8
    9278:      	b	0x9288 <generic_fentry_output+0x488>
    927c:      	add	x8, x0, #0x2f8
    9280:      	b	0x9288 <generic_fentry_output+0x488>
    9284:      	add	x8, x0, #0x2e8
    9288:      	ldaxr	x9, [x8]
    928c:      	add	x9, x9, #0x1
    9290:      	stlxr	w10, x9, [x8]
    9294:      	cbnz	w10, 0x9288 <generic_fentry_output+0x488>
    9298:      	ldp	x20, x19, [sp, #0xb0]
    929c:      	mov	w0, wzr
    92a0:      	ldr	x29, [sp, #0x70]
    92a4:      	ldp	x22, x21, [sp, #0xa0]
    92a8:      	ldp	x24, x23, [sp, #0x90]
    92ac:      	ldp	x30, x25, [sp, #0x80]
    92b0:      	add	sp, sp, #0xc0
    92b4:      	ret
    92b8:      	nop
    92bc:      	nop

00000000000092c0 <generic_fentry_path>:
    92c0:      	sub	sp, sp, #0xe0
    92c4:      	str	x29, [sp, #0x90]
    92c8:      	stp	x30, x25, [sp, #0xa0]
    92cc:      	stp	x24, x23, [sp, #0xb0]
    92d0:      	stp	x22, x21, [sp, #0xc0]
    92d4:      	stp	x20, x19, [sp, #0xd0]
    92d8:      	mov	x19, x0
    92dc:      	str	wzr, [sp, #0x28]
    92e0:      	adrp	x0, 0x9000 <generic_fentry_output+0x200>
    92e4:      	mov	w8, #0x1                // =1
    92e8:      	ldr	x0, [x0]
    92ec:      	add	x9, sp, #0x28
    92f0:      	add	x1, sp, #0x28
    92f4:      	blr	x8
    92f8:      	cbz	x0, 0x1515c <generic_fentry_path+0xbe9c>
    92fc:      	mov	w8, #0x6420             // =25632
    9300:      	add	x25, x0, x8
    9304:      	ldr	w8, [x25]
    9308:      	cmp	w8, #0x1
    930c:      	b.eq	0x93b8 <generic_fentry_path+0xf8>
    9310:      	cbnz	w8, 0x1515c <generic_fentry_path+0xbe9c>
    9314:      	mov	x20, x0
    9318:      	ldr	x22, [x0, #0x6440]
    931c:      	str	wzr, [sp, #0x70]
    9320:      	adrp	x0, 0x9000 <generic_fentry_output+0x200>
    9324:      	mov	w8, #0x1                // =1
    9328:      	add	x9, sp, #0x70
    932c:      	ldr	x0, [x0]
    9330:      	add	x1, sp, #0x70
    9334:      	blr	x8
    9338:      	cbz	x0, 0x1515c <generic_fentry_path+0xbe9c>
    933c:      	str	x19, [sp, #0x20]
    9340:      	add	x2, x22, #0x8
    9344:      	mov	w8, #0x8                // =8
    9348:      	mov	w9, #0x4                // =4
    934c:      	add	x10, sp, #0x80
    9350:      	mov	x21, x0
    9354:      	add	x29, x0, #0xfff
    9358:      	add	x0, sp, #0x80
    935c:      	mov	w1, #0x8                // =8
    9360:      	blr	x9
    9364:      	adrp	x22, 0x9000 <generic_fentry_output+0x200>
    9368:      	ldr	x22, [x22]
    936c:      	cbz	x0, 0x14de8 <generic_fentry_path+0xbb28>
    9370:      	neg	w8, w0
    9374:      	mov	w9, #0x1                // =1
    9378:      	add	x1, sp, #0x30
    937c:      	strh	w8, [sp, #0x30]
    9380:      	mov	w8, #0x6                // =6
    9384:      	mov	x0, x22
    9388:      	mov	w23, #0x1               // =1
    938c:      	strh	w8, [sp, #0x32]
    9390:      	mov	x8, #0x2c               // =44
    9394:      	movk	x8, #0x4, lsl #32
    9398:      	stur	x8, [sp, #0x34]
    939c:      	add	x8, sp, #0x30
    93a0:      	blr	x9
    93a4:      	cbz	x0, 0x14dc4 <generic_fentry_path+0xbb04>
    93a8:      	ldr	w8, [x0]
    93ac:      	add	w8, w8, #0x1
    93b0:      	str	w8, [x0]
    93b4:      	b	0x14de8 <generic_fentry_path+0xbb28>
    93b8:      	ldr	x8, [x0, #0x6448]
    93bc:      	ldr	x9, [x0, #0x6450]
    93c0:      	mov	x20, x0
    93c4:      	add	x1, sp, #0x2c
    93c8:      	str	xzr, [sp, #0x60]
    93cc:      	str	wzr, [sp, #0x68]
    93d0:      	strb	wzr, [sp, #0x6c]
    93d4:      	str	wzr, [sp, #0x2c]
    93d8:      	stp	x8, x9, [sp, #0x30]
    93dc:      	ldr	x8, [x0, #0x6458]
    93e0:      	ldr	x9, [x0, #0x6468]
    93e4:      	stp	xzr, x8, [sp, #0x40]
    93e8:      	ldr	x8, [x0, #0x6460]
    93ec:      	adrp	x0, 0x9000 <generic_fentry_output+0x200>
    93f0:      	stp	x8, x9, [sp, #0x50]
    93f4:      	mov	w8, #0x1                // =1
    93f8:      	add	x9, sp, #0x2c
    93fc:      	ldr	x0, [x0]
    9400:      	blr	x8
    9404:      	cbz	x0, 0x1515c <generic_fentry_path+0xbe9c>
    9408:      	str	x0, [sp, #0x40]
    940c:      	add	x10, sp, #0x30
    9410:      	stp	x20, x19, [sp, #0x18]
    9414:      	mov	w20, #0x200             // =512
    9418:      	mov	w29, #0x8               // =8
    941c:      	ldr	w8, [x25, #0x4]
    9420:      	add	x22, x10, #0x18
    9424:      	add	x19, sp, #0x70
    9428:      	and	x9, x8, #0xfff
    942c:      	str	x0, [sp, #0x10]
    9430:      	str	w8, [sp, #0x68]
    9434:      	add	x9, x0, x9
    9438:      	str	x9, [sp, #0x60]
    943c:      	ldp	x21, x2, [sp, #0x48]
    9440:      	ldp	x8, x9, [sp, #0x30]
    9444:      	cmp	x21, x8
    9448:      	ccmp	x2, x9, #0x0, eq
    944c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    9450:      	ldr	x24, [sp, #0x58]
    9454:      	mov	w8, #0x4                // =4
    9458:      	add	x0, sp, #0x70
    945c:      	mov	w1, #0x8                // =8
    9460:      	blr	x8
    9464:      	ldr	x8, [sp, #0x70]
    9468:      	cmp	x21, x8
    946c:      	b.eq	0x9568 <generic_fentry_path+0x2a8>
    9470:      	add	x23, x21, #0x18
    9474:      	mov	w8, #0x4                // =4
    9478:      	add	x9, sp, #0x98
    947c:      	add	x0, sp, #0x98
    9480:      	mov	w1, #0x8                // =8
    9484:      	mov	x2, x23
    9488:      	blr	x8
    948c:      	ldr	x8, [sp, #0x98]
    9490:      	cmp	x8, x21
    9494:      	b.eq	0x9568 <generic_fentry_path+0x2a8>
    9498:      	mov	w8, #0x4                // =4
    949c:      	add	x9, sp, #0x78
    94a0:      	add	x0, sp, #0x78
    94a4:      	mov	w1, #0x8                // =8
    94a8:      	mov	x2, x23
    94ac:      	blr	x8
    94b0:      	add	x2, x21, #0x20
    94b4:      	mov	w8, #0x4                // =4
    94b8:      	mov	w9, #0x10               // =16
    94bc:      	add	x10, sp, #0x80
    94c0:      	add	x0, sp, #0x80
    94c4:      	mov	w1, #0x10               // =16
    94c8:      	blr	x8
    94cc:      	ldr	w21, [sp, #0x84]
    94d0:      	ldr	x8, [sp, #0x40]
    94d4:      	ldr	x10, [sp, #0x60]
    94d8:      	sub	x12, x10, x8
    94dc:      	ldr	w23, [sp, #0x68]
    94e0:      	subs	w10, w21, w23
    94e4:      	ldr	x9, [sp, #0x88]
    94e8:      	csel	w10, wzr, w10, lo
    94ec:      	cmp	w23, w21
    94f0:      	csel	w11, w23, w21, lo
    94f4:      	cinc	w13, w11, hi
    94f8:      	sub	w14, w23, w13
    94fc:      	subs	x12, x12, x13
    9500:      	str	w14, [sp, #0x68]
    9504:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    9508:      	cmp	x12, #0xfff
    950c:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    9510:      	cmp	w23, w21
    9514:      	b.ls	0x9520 <generic_fentry_path+0x260>
    9518:      	mov	w13, #0x2f              // =47
    951c:      	strb	w13, [x8, x12]
    9520:      	add	x19, x8, x12
    9524:      	cmp	w23, w21
    9528:      	add	x2, x9, x10
    952c:      	and	w1, w11, #0xff
    9530:      	mov	w8, #0x4                // =4
    9534:      	cinc	x0, x19, hi
    9538:      	blr	x8
    953c:      	cmp	w23, w21
    9540:      	str	x19, [sp, #0x60]
    9544:      	add	x19, sp, #0x70
    9548:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    954c:      	ldr	x21, [sp, #0x78]
    9550:      	ldp	x2, x24, [sp, #0x50]
    9554:      	str	x21, [sp, #0x48]
    9558:      	ldr	x8, [sp, #0x30]
    955c:      	cmp	x21, x8
    9560:      	b.eq	0x95c0 <generic_fentry_path+0x300>
    9564:      	b	0x95cc <generic_fentry_path+0x30c>
    9568:      	add	x2, x24, #0x10
    956c:      	mov	w8, #0x4                // =4
    9570:      	add	x9, sp, #0x98
    9574:      	add	x0, sp, #0x98
    9578:      	mov	w1, #0x8                // =8
    957c:      	blr	x8
    9580:      	ldr	x8, [sp, #0x58]
    9584:      	ldr	x9, [sp, #0x98]
    9588:      	cmp	x8, x9
    958c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    9590:      	add	x2, x24, #0x18
    9594:      	mov	w8, #0x4                // =4
    9598:      	mov	x0, x22
    959c:      	mov	w1, #0x8                // =8
    95a0:      	blr	x8
    95a4:      	ldr	x24, [sp, #0x98]
    95a8:      	ldr	x21, [sp, #0x48]
    95ac:      	add	x2, x24, #0x20
    95b0:      	stp	x2, x24, [sp, #0x50]
    95b4:      	ldr	x8, [sp, #0x30]
    95b8:      	cmp	x21, x8
    95bc:      	b.ne	0x95cc <generic_fentry_path+0x30c>
    95c0:      	ldr	x8, [sp, #0x38]
    95c4:      	cmp	x2, x8
    95c8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    95cc:      	mov	w8, #0x4                // =4
    95d0:      	add	x0, sp, #0x70
    95d4:      	mov	w1, #0x8                // =8
    95d8:      	blr	x8
    95dc:      	ldr	x8, [sp, #0x70]
    95e0:      	cmp	x21, x8
    95e4:      	b.eq	0x96e0 <generic_fentry_path+0x420>
    95e8:      	add	x23, x21, #0x18
    95ec:      	mov	w8, #0x4                // =4
    95f0:      	add	x9, sp, #0x98
    95f4:      	add	x0, sp, #0x98
    95f8:      	mov	w1, #0x8                // =8
    95fc:      	mov	x2, x23
    9600:      	blr	x8
    9604:      	ldr	x8, [sp, #0x98]
    9608:      	cmp	x8, x21
    960c:      	b.eq	0x96e0 <generic_fentry_path+0x420>
    9610:      	mov	w8, #0x4                // =4
    9614:      	add	x9, sp, #0x78
    9618:      	add	x0, sp, #0x78
    961c:      	mov	w1, #0x8                // =8
    9620:      	mov	x2, x23
    9624:      	blr	x8
    9628:      	add	x2, x21, #0x20
    962c:      	mov	w8, #0x4                // =4
    9630:      	mov	w9, #0x10               // =16
    9634:      	add	x10, sp, #0x80
    9638:      	add	x0, sp, #0x80
    963c:      	mov	w1, #0x10               // =16
    9640:      	blr	x8
    9644:      	ldr	w21, [sp, #0x84]
    9648:      	ldr	x8, [sp, #0x40]
    964c:      	ldr	x10, [sp, #0x60]
    9650:      	sub	x12, x10, x8
    9654:      	ldr	w23, [sp, #0x68]
    9658:      	subs	w10, w21, w23
    965c:      	ldr	x9, [sp, #0x88]
    9660:      	csel	w10, wzr, w10, lo
    9664:      	cmp	w23, w21
    9668:      	csel	w11, w23, w21, lo
    966c:      	cinc	w13, w11, hi
    9670:      	sub	w14, w23, w13
    9674:      	subs	x12, x12, x13
    9678:      	str	w14, [sp, #0x68]
    967c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    9680:      	cmp	x12, #0xfff
    9684:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    9688:      	cmp	w23, w21
    968c:      	b.ls	0x9698 <generic_fentry_path+0x3d8>
    9690:      	mov	w13, #0x2f              // =47
    9694:      	strb	w13, [x8, x12]
    9698:      	add	x19, x8, x12
    969c:      	cmp	w23, w21
    96a0:      	add	x2, x9, x10
    96a4:      	and	w1, w11, #0xff
    96a8:      	mov	w8, #0x4                // =4
    96ac:      	cinc	x0, x19, hi
    96b0:      	blr	x8
    96b4:      	cmp	w23, w21
    96b8:      	str	x19, [sp, #0x60]
    96bc:      	add	x19, sp, #0x70
    96c0:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    96c4:      	ldr	x21, [sp, #0x78]
    96c8:      	ldp	x2, x24, [sp, #0x50]
    96cc:      	str	x21, [sp, #0x48]
    96d0:      	ldr	x8, [sp, #0x30]
    96d4:      	cmp	x21, x8
    96d8:      	b.eq	0x9738 <generic_fentry_path+0x478>
    96dc:      	b	0x9744 <generic_fentry_path+0x484>
    96e0:      	add	x2, x24, #0x10
    96e4:      	mov	w8, #0x4                // =4
    96e8:      	add	x9, sp, #0x98
    96ec:      	add	x0, sp, #0x98
    96f0:      	mov	w1, #0x8                // =8
    96f4:      	blr	x8
    96f8:      	ldr	x8, [sp, #0x58]
    96fc:      	ldr	x9, [sp, #0x98]
    9700:      	cmp	x8, x9
    9704:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    9708:      	add	x2, x24, #0x18
    970c:      	mov	w8, #0x4                // =4
    9710:      	mov	x0, x22
    9714:      	mov	w1, #0x8                // =8
    9718:      	blr	x8
    971c:      	ldr	x24, [sp, #0x98]
    9720:      	ldr	x21, [sp, #0x48]
    9724:      	add	x2, x24, #0x20
    9728:      	stp	x2, x24, [sp, #0x50]
    972c:      	ldr	x8, [sp, #0x30]
    9730:      	cmp	x21, x8
    9734:      	b.ne	0x9744 <generic_fentry_path+0x484>
    9738:      	ldr	x8, [sp, #0x38]
    973c:      	cmp	x2, x8
    9740:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    9744:      	mov	w8, #0x4                // =4
    9748:      	add	x0, sp, #0x70
    974c:      	mov	w1, #0x8                // =8
    9750:      	blr	x8
    9754:      	ldr	x8, [sp, #0x70]
    9758:      	cmp	x21, x8
    975c:      	b.eq	0x9858 <generic_fentry_path+0x598>
    9760:      	add	x23, x21, #0x18
    9764:      	mov	w8, #0x4                // =4
    9768:      	add	x9, sp, #0x98
    976c:      	add	x0, sp, #0x98
    9770:      	mov	w1, #0x8                // =8
    9774:      	mov	x2, x23
    9778:      	blr	x8
    977c:      	ldr	x8, [sp, #0x98]
    9780:      	cmp	x8, x21
    9784:      	b.eq	0x9858 <generic_fentry_path+0x598>
    9788:      	mov	w8, #0x4                // =4
    978c:      	add	x9, sp, #0x78
    9790:      	add	x0, sp, #0x78
    9794:      	mov	w1, #0x8                // =8
    9798:      	mov	x2, x23
    979c:      	blr	x8
    97a0:      	add	x2, x21, #0x20
    97a4:      	mov	w8, #0x4                // =4
    97a8:      	mov	w9, #0x10               // =16
    97ac:      	add	x10, sp, #0x80
    97b0:      	add	x0, sp, #0x80
    97b4:      	mov	w1, #0x10               // =16
    97b8:      	blr	x8
    97bc:      	ldr	w21, [sp, #0x84]
    97c0:      	ldr	x8, [sp, #0x40]
    97c4:      	ldr	x10, [sp, #0x60]
    97c8:      	sub	x12, x10, x8
    97cc:      	ldr	w23, [sp, #0x68]
    97d0:      	subs	w10, w21, w23
    97d4:      	ldr	x9, [sp, #0x88]
    97d8:      	csel	w10, wzr, w10, lo
    97dc:      	cmp	w23, w21
    97e0:      	csel	w11, w23, w21, lo
    97e4:      	cinc	w13, w11, hi
    97e8:      	sub	w14, w23, w13
    97ec:      	subs	x12, x12, x13
    97f0:      	str	w14, [sp, #0x68]
    97f4:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    97f8:      	cmp	x12, #0xfff
    97fc:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    9800:      	cmp	w23, w21
    9804:      	b.ls	0x9810 <generic_fentry_path+0x550>
    9808:      	mov	w13, #0x2f              // =47
    980c:      	strb	w13, [x8, x12]
    9810:      	add	x19, x8, x12
    9814:      	cmp	w23, w21
    9818:      	add	x2, x9, x10
    981c:      	and	w1, w11, #0xff
    9820:      	mov	w8, #0x4                // =4
    9824:      	cinc	x0, x19, hi
    9828:      	blr	x8
    982c:      	cmp	w23, w21
    9830:      	str	x19, [sp, #0x60]
    9834:      	add	x19, sp, #0x70
    9838:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    983c:      	ldr	x21, [sp, #0x78]
    9840:      	ldp	x2, x24, [sp, #0x50]
    9844:      	str	x21, [sp, #0x48]
    9848:      	ldr	x8, [sp, #0x30]
    984c:      	cmp	x21, x8
    9850:      	b.eq	0x98b0 <generic_fentry_path+0x5f0>
    9854:      	b	0x98bc <generic_fentry_path+0x5fc>
    9858:      	add	x2, x24, #0x10
    985c:      	mov	w8, #0x4                // =4
    9860:      	add	x9, sp, #0x98
    9864:      	add	x0, sp, #0x98
    9868:      	mov	w1, #0x8                // =8
    986c:      	blr	x8
    9870:      	ldr	x8, [sp, #0x58]
    9874:      	ldr	x9, [sp, #0x98]
    9878:      	cmp	x8, x9
    987c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    9880:      	add	x2, x24, #0x18
    9884:      	mov	w8, #0x4                // =4
    9888:      	mov	x0, x22
    988c:      	mov	w1, #0x8                // =8
    9890:      	blr	x8
    9894:      	ldr	x24, [sp, #0x98]
    9898:      	ldr	x21, [sp, #0x48]
    989c:      	add	x2, x24, #0x20
    98a0:      	stp	x2, x24, [sp, #0x50]
    98a4:      	ldr	x8, [sp, #0x30]
    98a8:      	cmp	x21, x8
    98ac:      	b.ne	0x98bc <generic_fentry_path+0x5fc>
    98b0:      	ldr	x8, [sp, #0x38]
    98b4:      	cmp	x2, x8
    98b8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    98bc:      	mov	w8, #0x4                // =4
    98c0:      	add	x0, sp, #0x70
    98c4:      	mov	w1, #0x8                // =8
    98c8:      	blr	x8
    98cc:      	ldr	x8, [sp, #0x70]
    98d0:      	cmp	x21, x8
    98d4:      	b.eq	0x99d0 <generic_fentry_path+0x710>
    98d8:      	add	x23, x21, #0x18
    98dc:      	mov	w8, #0x4                // =4
    98e0:      	add	x9, sp, #0x98
    98e4:      	add	x0, sp, #0x98
    98e8:      	mov	w1, #0x8                // =8
    98ec:      	mov	x2, x23
    98f0:      	blr	x8
    98f4:      	ldr	x8, [sp, #0x98]
    98f8:      	cmp	x8, x21
    98fc:      	b.eq	0x99d0 <generic_fentry_path+0x710>
    9900:      	mov	w8, #0x4                // =4
    9904:      	add	x9, sp, #0x78
    9908:      	add	x0, sp, #0x78
    990c:      	mov	w1, #0x8                // =8
    9910:      	mov	x2, x23
    9914:      	blr	x8
    9918:      	add	x2, x21, #0x20
    991c:      	mov	w8, #0x4                // =4
    9920:      	mov	w9, #0x10               // =16
    9924:      	add	x10, sp, #0x80
    9928:      	add	x0, sp, #0x80
    992c:      	mov	w1, #0x10               // =16
    9930:      	blr	x8
    9934:      	ldr	w21, [sp, #0x84]
    9938:      	ldr	x8, [sp, #0x40]
    993c:      	ldr	x10, [sp, #0x60]
    9940:      	sub	x12, x10, x8
    9944:      	ldr	w23, [sp, #0x68]
    9948:      	subs	w10, w21, w23
    994c:      	ldr	x9, [sp, #0x88]
    9950:      	csel	w10, wzr, w10, lo
    9954:      	cmp	w23, w21
    9958:      	csel	w11, w23, w21, lo
    995c:      	cinc	w13, w11, hi
    9960:      	sub	w14, w23, w13
    9964:      	subs	x12, x12, x13
    9968:      	str	w14, [sp, #0x68]
    996c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    9970:      	cmp	x12, #0xfff
    9974:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    9978:      	cmp	w23, w21
    997c:      	b.ls	0x9988 <generic_fentry_path+0x6c8>
    9980:      	mov	w13, #0x2f              // =47
    9984:      	strb	w13, [x8, x12]
    9988:      	add	x19, x8, x12
    998c:      	cmp	w23, w21
    9990:      	add	x2, x9, x10
    9994:      	and	w1, w11, #0xff
    9998:      	mov	w8, #0x4                // =4
    999c:      	cinc	x0, x19, hi
    99a0:      	blr	x8
    99a4:      	cmp	w23, w21
    99a8:      	str	x19, [sp, #0x60]
    99ac:      	add	x19, sp, #0x70
    99b0:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    99b4:      	ldr	x21, [sp, #0x78]
    99b8:      	ldp	x2, x24, [sp, #0x50]
    99bc:      	str	x21, [sp, #0x48]
    99c0:      	ldr	x8, [sp, #0x30]
    99c4:      	cmp	x21, x8
    99c8:      	b.eq	0x9a28 <generic_fentry_path+0x768>
    99cc:      	b	0x9a34 <generic_fentry_path+0x774>
    99d0:      	add	x2, x24, #0x10
    99d4:      	mov	w8, #0x4                // =4
    99d8:      	add	x9, sp, #0x98
    99dc:      	add	x0, sp, #0x98
    99e0:      	mov	w1, #0x8                // =8
    99e4:      	blr	x8
    99e8:      	ldr	x8, [sp, #0x58]
    99ec:      	ldr	x9, [sp, #0x98]
    99f0:      	cmp	x8, x9
    99f4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    99f8:      	add	x2, x24, #0x18
    99fc:      	mov	w8, #0x4                // =4
    9a00:      	mov	x0, x22
    9a04:      	mov	w1, #0x8                // =8
    9a08:      	blr	x8
    9a0c:      	ldr	x24, [sp, #0x98]
    9a10:      	ldr	x21, [sp, #0x48]
    9a14:      	add	x2, x24, #0x20
    9a18:      	stp	x2, x24, [sp, #0x50]
    9a1c:      	ldr	x8, [sp, #0x30]
    9a20:      	cmp	x21, x8
    9a24:      	b.ne	0x9a34 <generic_fentry_path+0x774>
    9a28:      	ldr	x8, [sp, #0x38]
    9a2c:      	cmp	x2, x8
    9a30:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    9a34:      	mov	w8, #0x4                // =4
    9a38:      	add	x0, sp, #0x70
    9a3c:      	mov	w1, #0x8                // =8
    9a40:      	blr	x8
    9a44:      	ldr	x8, [sp, #0x70]
    9a48:      	cmp	x21, x8
    9a4c:      	b.eq	0x9b48 <generic_fentry_path+0x888>
    9a50:      	add	x23, x21, #0x18
    9a54:      	mov	w8, #0x4                // =4
    9a58:      	add	x9, sp, #0x98
    9a5c:      	add	x0, sp, #0x98
    9a60:      	mov	w1, #0x8                // =8
    9a64:      	mov	x2, x23
    9a68:      	blr	x8
    9a6c:      	ldr	x8, [sp, #0x98]
    9a70:      	cmp	x8, x21
    9a74:      	b.eq	0x9b48 <generic_fentry_path+0x888>
    9a78:      	mov	w8, #0x4                // =4
    9a7c:      	add	x9, sp, #0x78
    9a80:      	add	x0, sp, #0x78
    9a84:      	mov	w1, #0x8                // =8
    9a88:      	mov	x2, x23
    9a8c:      	blr	x8
    9a90:      	add	x2, x21, #0x20
    9a94:      	mov	w8, #0x4                // =4
    9a98:      	mov	w9, #0x10               // =16
    9a9c:      	add	x10, sp, #0x80
    9aa0:      	add	x0, sp, #0x80
    9aa4:      	mov	w1, #0x10               // =16
    9aa8:      	blr	x8
    9aac:      	ldr	w21, [sp, #0x84]
    9ab0:      	ldr	x8, [sp, #0x40]
    9ab4:      	ldr	x10, [sp, #0x60]
    9ab8:      	sub	x12, x10, x8
    9abc:      	ldr	w23, [sp, #0x68]
    9ac0:      	subs	w10, w21, w23
    9ac4:      	ldr	x9, [sp, #0x88]
    9ac8:      	csel	w10, wzr, w10, lo
    9acc:      	cmp	w23, w21
    9ad0:      	csel	w11, w23, w21, lo
    9ad4:      	cinc	w13, w11, hi
    9ad8:      	sub	w14, w23, w13
    9adc:      	subs	x12, x12, x13
    9ae0:      	str	w14, [sp, #0x68]
    9ae4:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    9ae8:      	cmp	x12, #0xfff
    9aec:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    9af0:      	cmp	w23, w21
    9af4:      	b.ls	0x9b00 <generic_fentry_path+0x840>
    9af8:      	mov	w13, #0x2f              // =47
    9afc:      	strb	w13, [x8, x12]
    9b00:      	add	x19, x8, x12
    9b04:      	cmp	w23, w21
    9b08:      	add	x2, x9, x10
    9b0c:      	and	w1, w11, #0xff
    9b10:      	mov	w8, #0x4                // =4
    9b14:      	cinc	x0, x19, hi
    9b18:      	blr	x8
    9b1c:      	cmp	w23, w21
    9b20:      	str	x19, [sp, #0x60]
    9b24:      	add	x19, sp, #0x70
    9b28:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    9b2c:      	ldr	x21, [sp, #0x78]
    9b30:      	ldp	x2, x24, [sp, #0x50]
    9b34:      	str	x21, [sp, #0x48]
    9b38:      	ldr	x8, [sp, #0x30]
    9b3c:      	cmp	x21, x8
    9b40:      	b.eq	0x9ba0 <generic_fentry_path+0x8e0>
    9b44:      	b	0x9bac <generic_fentry_path+0x8ec>
    9b48:      	add	x2, x24, #0x10
    9b4c:      	mov	w8, #0x4                // =4
    9b50:      	add	x9, sp, #0x98
    9b54:      	add	x0, sp, #0x98
    9b58:      	mov	w1, #0x8                // =8
    9b5c:      	blr	x8
    9b60:      	ldr	x8, [sp, #0x58]
    9b64:      	ldr	x9, [sp, #0x98]
    9b68:      	cmp	x8, x9
    9b6c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    9b70:      	add	x2, x24, #0x18
    9b74:      	mov	w8, #0x4                // =4
    9b78:      	mov	x0, x22
    9b7c:      	mov	w1, #0x8                // =8
    9b80:      	blr	x8
    9b84:      	ldr	x24, [sp, #0x98]
    9b88:      	ldr	x21, [sp, #0x48]
    9b8c:      	add	x2, x24, #0x20
    9b90:      	stp	x2, x24, [sp, #0x50]
    9b94:      	ldr	x8, [sp, #0x30]
    9b98:      	cmp	x21, x8
    9b9c:      	b.ne	0x9bac <generic_fentry_path+0x8ec>
    9ba0:      	ldr	x8, [sp, #0x38]
    9ba4:      	cmp	x2, x8
    9ba8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    9bac:      	mov	w8, #0x4                // =4
    9bb0:      	add	x0, sp, #0x70
    9bb4:      	mov	w1, #0x8                // =8
    9bb8:      	blr	x8
    9bbc:      	ldr	x8, [sp, #0x70]
    9bc0:      	cmp	x21, x8
    9bc4:      	b.eq	0x9cc0 <generic_fentry_path+0xa00>
    9bc8:      	add	x23, x21, #0x18
    9bcc:      	mov	w8, #0x4                // =4
    9bd0:      	add	x9, sp, #0x98
    9bd4:      	add	x0, sp, #0x98
    9bd8:      	mov	w1, #0x8                // =8
    9bdc:      	mov	x2, x23
    9be0:      	blr	x8
    9be4:      	ldr	x8, [sp, #0x98]
    9be8:      	cmp	x8, x21
    9bec:      	b.eq	0x9cc0 <generic_fentry_path+0xa00>
    9bf0:      	mov	w8, #0x4                // =4
    9bf4:      	add	x9, sp, #0x78
    9bf8:      	add	x0, sp, #0x78
    9bfc:      	mov	w1, #0x8                // =8
    9c00:      	mov	x2, x23
    9c04:      	blr	x8
    9c08:      	add	x2, x21, #0x20
    9c0c:      	mov	w8, #0x4                // =4
    9c10:      	mov	w9, #0x10               // =16
    9c14:      	add	x10, sp, #0x80
    9c18:      	add	x0, sp, #0x80
    9c1c:      	mov	w1, #0x10               // =16
    9c20:      	blr	x8
    9c24:      	ldr	w21, [sp, #0x84]
    9c28:      	ldr	x8, [sp, #0x40]
    9c2c:      	ldr	x10, [sp, #0x60]
    9c30:      	sub	x12, x10, x8
    9c34:      	ldr	w23, [sp, #0x68]
    9c38:      	subs	w10, w21, w23
    9c3c:      	ldr	x9, [sp, #0x88]
    9c40:      	csel	w10, wzr, w10, lo
    9c44:      	cmp	w23, w21
    9c48:      	csel	w11, w23, w21, lo
    9c4c:      	cinc	w13, w11, hi
    9c50:      	sub	w14, w23, w13
    9c54:      	subs	x12, x12, x13
    9c58:      	str	w14, [sp, #0x68]
    9c5c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    9c60:      	cmp	x12, #0xfff
    9c64:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    9c68:      	cmp	w23, w21
    9c6c:      	b.ls	0x9c78 <generic_fentry_path+0x9b8>
    9c70:      	mov	w13, #0x2f              // =47
    9c74:      	strb	w13, [x8, x12]
    9c78:      	add	x19, x8, x12
    9c7c:      	cmp	w23, w21
    9c80:      	add	x2, x9, x10
    9c84:      	and	w1, w11, #0xff
    9c88:      	mov	w8, #0x4                // =4
    9c8c:      	cinc	x0, x19, hi
    9c90:      	blr	x8
    9c94:      	cmp	w23, w21
    9c98:      	str	x19, [sp, #0x60]
    9c9c:      	add	x19, sp, #0x70
    9ca0:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    9ca4:      	ldr	x21, [sp, #0x78]
    9ca8:      	ldp	x2, x24, [sp, #0x50]
    9cac:      	str	x21, [sp, #0x48]
    9cb0:      	ldr	x8, [sp, #0x30]
    9cb4:      	cmp	x21, x8
    9cb8:      	b.eq	0x9d18 <generic_fentry_path+0xa58>
    9cbc:      	b	0x9d24 <generic_fentry_path+0xa64>
    9cc0:      	add	x2, x24, #0x10
    9cc4:      	mov	w8, #0x4                // =4
    9cc8:      	add	x9, sp, #0x98
    9ccc:      	add	x0, sp, #0x98
    9cd0:      	mov	w1, #0x8                // =8
    9cd4:      	blr	x8
    9cd8:      	ldr	x8, [sp, #0x58]
    9cdc:      	ldr	x9, [sp, #0x98]
    9ce0:      	cmp	x8, x9
    9ce4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    9ce8:      	add	x2, x24, #0x18
    9cec:      	mov	w8, #0x4                // =4
    9cf0:      	mov	x0, x22
    9cf4:      	mov	w1, #0x8                // =8
    9cf8:      	blr	x8
    9cfc:      	ldr	x24, [sp, #0x98]
    9d00:      	ldr	x21, [sp, #0x48]
    9d04:      	add	x2, x24, #0x20
    9d08:      	stp	x2, x24, [sp, #0x50]
    9d0c:      	ldr	x8, [sp, #0x30]
    9d10:      	cmp	x21, x8
    9d14:      	b.ne	0x9d24 <generic_fentry_path+0xa64>
    9d18:      	ldr	x8, [sp, #0x38]
    9d1c:      	cmp	x2, x8
    9d20:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    9d24:      	mov	w8, #0x4                // =4
    9d28:      	add	x0, sp, #0x70
    9d2c:      	mov	w1, #0x8                // =8
    9d30:      	blr	x8
    9d34:      	ldr	x8, [sp, #0x70]
    9d38:      	cmp	x21, x8
    9d3c:      	b.eq	0x9e38 <generic_fentry_path+0xb78>
    9d40:      	add	x23, x21, #0x18
    9d44:      	mov	w8, #0x4                // =4
    9d48:      	add	x9, sp, #0x98
    9d4c:      	add	x0, sp, #0x98
    9d50:      	mov	w1, #0x8                // =8
    9d54:      	mov	x2, x23
    9d58:      	blr	x8
    9d5c:      	ldr	x8, [sp, #0x98]
    9d60:      	cmp	x8, x21
    9d64:      	b.eq	0x9e38 <generic_fentry_path+0xb78>
    9d68:      	mov	w8, #0x4                // =4
    9d6c:      	add	x9, sp, #0x78
    9d70:      	add	x0, sp, #0x78
    9d74:      	mov	w1, #0x8                // =8
    9d78:      	mov	x2, x23
    9d7c:      	blr	x8
    9d80:      	add	x2, x21, #0x20
    9d84:      	mov	w8, #0x4                // =4
    9d88:      	mov	w9, #0x10               // =16
    9d8c:      	add	x10, sp, #0x80
    9d90:      	add	x0, sp, #0x80
    9d94:      	mov	w1, #0x10               // =16
    9d98:      	blr	x8
    9d9c:      	ldr	w21, [sp, #0x84]
    9da0:      	ldr	x8, [sp, #0x40]
    9da4:      	ldr	x10, [sp, #0x60]
    9da8:      	sub	x12, x10, x8
    9dac:      	ldr	w23, [sp, #0x68]
    9db0:      	subs	w10, w21, w23
    9db4:      	ldr	x9, [sp, #0x88]
    9db8:      	csel	w10, wzr, w10, lo
    9dbc:      	cmp	w23, w21
    9dc0:      	csel	w11, w23, w21, lo
    9dc4:      	cinc	w13, w11, hi
    9dc8:      	sub	w14, w23, w13
    9dcc:      	subs	x12, x12, x13
    9dd0:      	str	w14, [sp, #0x68]
    9dd4:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    9dd8:      	cmp	x12, #0xfff
    9ddc:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    9de0:      	cmp	w23, w21
    9de4:      	b.ls	0x9df0 <generic_fentry_path+0xb30>
    9de8:      	mov	w13, #0x2f              // =47
    9dec:      	strb	w13, [x8, x12]
    9df0:      	add	x19, x8, x12
    9df4:      	cmp	w23, w21
    9df8:      	add	x2, x9, x10
    9dfc:      	and	w1, w11, #0xff
    9e00:      	mov	w8, #0x4                // =4
    9e04:      	cinc	x0, x19, hi
    9e08:      	blr	x8
    9e0c:      	cmp	w23, w21
    9e10:      	str	x19, [sp, #0x60]
    9e14:      	add	x19, sp, #0x70
    9e18:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    9e1c:      	ldr	x21, [sp, #0x78]
    9e20:      	ldp	x2, x24, [sp, #0x50]
    9e24:      	str	x21, [sp, #0x48]
    9e28:      	ldr	x8, [sp, #0x30]
    9e2c:      	cmp	x21, x8
    9e30:      	b.eq	0x9e90 <generic_fentry_path+0xbd0>
    9e34:      	b	0x9e9c <generic_fentry_path+0xbdc>
    9e38:      	add	x2, x24, #0x10
    9e3c:      	mov	w8, #0x4                // =4
    9e40:      	add	x9, sp, #0x98
    9e44:      	add	x0, sp, #0x98
    9e48:      	mov	w1, #0x8                // =8
    9e4c:      	blr	x8
    9e50:      	ldr	x8, [sp, #0x58]
    9e54:      	ldr	x9, [sp, #0x98]
    9e58:      	cmp	x8, x9
    9e5c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    9e60:      	add	x2, x24, #0x18
    9e64:      	mov	w8, #0x4                // =4
    9e68:      	mov	x0, x22
    9e6c:      	mov	w1, #0x8                // =8
    9e70:      	blr	x8
    9e74:      	ldr	x24, [sp, #0x98]
    9e78:      	ldr	x21, [sp, #0x48]
    9e7c:      	add	x2, x24, #0x20
    9e80:      	stp	x2, x24, [sp, #0x50]
    9e84:      	ldr	x8, [sp, #0x30]
    9e88:      	cmp	x21, x8
    9e8c:      	b.ne	0x9e9c <generic_fentry_path+0xbdc>
    9e90:      	ldr	x8, [sp, #0x38]
    9e94:      	cmp	x2, x8
    9e98:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    9e9c:      	mov	w8, #0x4                // =4
    9ea0:      	add	x0, sp, #0x70
    9ea4:      	mov	w1, #0x8                // =8
    9ea8:      	blr	x8
    9eac:      	ldr	x8, [sp, #0x70]
    9eb0:      	cmp	x21, x8
    9eb4:      	b.eq	0x9fb0 <generic_fentry_path+0xcf0>
    9eb8:      	add	x23, x21, #0x18
    9ebc:      	mov	w8, #0x4                // =4
    9ec0:      	add	x9, sp, #0x98
    9ec4:      	add	x0, sp, #0x98
    9ec8:      	mov	w1, #0x8                // =8
    9ecc:      	mov	x2, x23
    9ed0:      	blr	x8
    9ed4:      	ldr	x8, [sp, #0x98]
    9ed8:      	cmp	x8, x21
    9edc:      	b.eq	0x9fb0 <generic_fentry_path+0xcf0>
    9ee0:      	mov	w8, #0x4                // =4
    9ee4:      	add	x9, sp, #0x78
    9ee8:      	add	x0, sp, #0x78
    9eec:      	mov	w1, #0x8                // =8
    9ef0:      	mov	x2, x23
    9ef4:      	blr	x8
    9ef8:      	add	x2, x21, #0x20
    9efc:      	mov	w8, #0x4                // =4
    9f00:      	mov	w9, #0x10               // =16
    9f04:      	add	x10, sp, #0x80
    9f08:      	add	x0, sp, #0x80
    9f0c:      	mov	w1, #0x10               // =16
    9f10:      	blr	x8
    9f14:      	ldr	w21, [sp, #0x84]
    9f18:      	ldr	x8, [sp, #0x40]
    9f1c:      	ldr	x10, [sp, #0x60]
    9f20:      	sub	x12, x10, x8
    9f24:      	ldr	w23, [sp, #0x68]
    9f28:      	subs	w10, w21, w23
    9f2c:      	ldr	x9, [sp, #0x88]
    9f30:      	csel	w10, wzr, w10, lo
    9f34:      	cmp	w23, w21
    9f38:      	csel	w11, w23, w21, lo
    9f3c:      	cinc	w13, w11, hi
    9f40:      	sub	w14, w23, w13
    9f44:      	subs	x12, x12, x13
    9f48:      	str	w14, [sp, #0x68]
    9f4c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    9f50:      	cmp	x12, #0xfff
    9f54:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    9f58:      	cmp	w23, w21
    9f5c:      	b.ls	0x9f68 <generic_fentry_path+0xca8>
    9f60:      	mov	w13, #0x2f              // =47
    9f64:      	strb	w13, [x8, x12]
    9f68:      	add	x19, x8, x12
    9f6c:      	cmp	w23, w21
    9f70:      	add	x2, x9, x10
    9f74:      	and	w1, w11, #0xff
    9f78:      	mov	w8, #0x4                // =4
    9f7c:      	cinc	x0, x19, hi
    9f80:      	blr	x8
    9f84:      	cmp	w23, w21
    9f88:      	str	x19, [sp, #0x60]
    9f8c:      	add	x19, sp, #0x70
    9f90:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    9f94:      	ldr	x21, [sp, #0x78]
    9f98:      	ldp	x2, x24, [sp, #0x50]
    9f9c:      	str	x21, [sp, #0x48]
    9fa0:      	ldr	x8, [sp, #0x30]
    9fa4:      	cmp	x21, x8
    9fa8:      	b.eq	0xa008 <generic_fentry_path+0xd48>
    9fac:      	b	0xa014 <generic_fentry_path+0xd54>
    9fb0:      	add	x2, x24, #0x10
    9fb4:      	mov	w8, #0x4                // =4
    9fb8:      	add	x9, sp, #0x98
    9fbc:      	add	x0, sp, #0x98
    9fc0:      	mov	w1, #0x8                // =8
    9fc4:      	blr	x8
    9fc8:      	ldr	x8, [sp, #0x58]
    9fcc:      	ldr	x9, [sp, #0x98]
    9fd0:      	cmp	x8, x9
    9fd4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    9fd8:      	add	x2, x24, #0x18
    9fdc:      	mov	w8, #0x4                // =4
    9fe0:      	mov	x0, x22
    9fe4:      	mov	w1, #0x8                // =8
    9fe8:      	blr	x8
    9fec:      	ldr	x24, [sp, #0x98]
    9ff0:      	ldr	x21, [sp, #0x48]
    9ff4:      	add	x2, x24, #0x20
    9ff8:      	stp	x2, x24, [sp, #0x50]
    9ffc:      	ldr	x8, [sp, #0x30]
    a000:      	cmp	x21, x8
    a004:      	b.ne	0xa014 <generic_fentry_path+0xd54>
    a008:      	ldr	x8, [sp, #0x38]
    a00c:      	cmp	x2, x8
    a010:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    a014:      	mov	w8, #0x4                // =4
    a018:      	add	x0, sp, #0x70
    a01c:      	mov	w1, #0x8                // =8
    a020:      	blr	x8
    a024:      	ldr	x8, [sp, #0x70]
    a028:      	cmp	x21, x8
    a02c:      	b.eq	0xa128 <generic_fentry_path+0xe68>
    a030:      	add	x23, x21, #0x18
    a034:      	mov	w8, #0x4                // =4
    a038:      	add	x9, sp, #0x98
    a03c:      	add	x0, sp, #0x98
    a040:      	mov	w1, #0x8                // =8
    a044:      	mov	x2, x23
    a048:      	blr	x8
    a04c:      	ldr	x8, [sp, #0x98]
    a050:      	cmp	x8, x21
    a054:      	b.eq	0xa128 <generic_fentry_path+0xe68>
    a058:      	mov	w8, #0x4                // =4
    a05c:      	add	x9, sp, #0x78
    a060:      	add	x0, sp, #0x78
    a064:      	mov	w1, #0x8                // =8
    a068:      	mov	x2, x23
    a06c:      	blr	x8
    a070:      	add	x2, x21, #0x20
    a074:      	mov	w8, #0x4                // =4
    a078:      	mov	w9, #0x10               // =16
    a07c:      	add	x10, sp, #0x80
    a080:      	add	x0, sp, #0x80
    a084:      	mov	w1, #0x10               // =16
    a088:      	blr	x8
    a08c:      	ldr	w21, [sp, #0x84]
    a090:      	ldr	x8, [sp, #0x40]
    a094:      	ldr	x10, [sp, #0x60]
    a098:      	sub	x12, x10, x8
    a09c:      	ldr	w23, [sp, #0x68]
    a0a0:      	subs	w10, w21, w23
    a0a4:      	ldr	x9, [sp, #0x88]
    a0a8:      	csel	w10, wzr, w10, lo
    a0ac:      	cmp	w23, w21
    a0b0:      	csel	w11, w23, w21, lo
    a0b4:      	cinc	w13, w11, hi
    a0b8:      	sub	w14, w23, w13
    a0bc:      	subs	x12, x12, x13
    a0c0:      	str	w14, [sp, #0x68]
    a0c4:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    a0c8:      	cmp	x12, #0xfff
    a0cc:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    a0d0:      	cmp	w23, w21
    a0d4:      	b.ls	0xa0e0 <generic_fentry_path+0xe20>
    a0d8:      	mov	w13, #0x2f              // =47
    a0dc:      	strb	w13, [x8, x12]
    a0e0:      	add	x19, x8, x12
    a0e4:      	cmp	w23, w21
    a0e8:      	add	x2, x9, x10
    a0ec:      	and	w1, w11, #0xff
    a0f0:      	mov	w8, #0x4                // =4
    a0f4:      	cinc	x0, x19, hi
    a0f8:      	blr	x8
    a0fc:      	cmp	w23, w21
    a100:      	str	x19, [sp, #0x60]
    a104:      	add	x19, sp, #0x70
    a108:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    a10c:      	ldr	x21, [sp, #0x78]
    a110:      	ldp	x2, x24, [sp, #0x50]
    a114:      	str	x21, [sp, #0x48]
    a118:      	ldr	x8, [sp, #0x30]
    a11c:      	cmp	x21, x8
    a120:      	b.eq	0xa180 <generic_fentry_path+0xec0>
    a124:      	b	0xa18c <generic_fentry_path+0xecc>
    a128:      	add	x2, x24, #0x10
    a12c:      	mov	w8, #0x4                // =4
    a130:      	add	x9, sp, #0x98
    a134:      	add	x0, sp, #0x98
    a138:      	mov	w1, #0x8                // =8
    a13c:      	blr	x8
    a140:      	ldr	x8, [sp, #0x58]
    a144:      	ldr	x9, [sp, #0x98]
    a148:      	cmp	x8, x9
    a14c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    a150:      	add	x2, x24, #0x18
    a154:      	mov	w8, #0x4                // =4
    a158:      	mov	x0, x22
    a15c:      	mov	w1, #0x8                // =8
    a160:      	blr	x8
    a164:      	ldr	x24, [sp, #0x98]
    a168:      	ldr	x21, [sp, #0x48]
    a16c:      	add	x2, x24, #0x20
    a170:      	stp	x2, x24, [sp, #0x50]
    a174:      	ldr	x8, [sp, #0x30]
    a178:      	cmp	x21, x8
    a17c:      	b.ne	0xa18c <generic_fentry_path+0xecc>
    a180:      	ldr	x8, [sp, #0x38]
    a184:      	cmp	x2, x8
    a188:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    a18c:      	mov	w8, #0x4                // =4
    a190:      	add	x0, sp, #0x70
    a194:      	mov	w1, #0x8                // =8
    a198:      	blr	x8
    a19c:      	ldr	x8, [sp, #0x70]
    a1a0:      	cmp	x21, x8
    a1a4:      	b.eq	0xa294 <generic_fentry_path+0xfd4>
    a1a8:      	add	x23, x21, #0x18
    a1ac:      	mov	w8, #0x4                // =4
    a1b0:      	add	x9, sp, #0x98
    a1b4:      	add	x0, sp, #0x98
    a1b8:      	mov	w1, #0x8                // =8
    a1bc:      	mov	x2, x23
    a1c0:      	blr	x8
    a1c4:      	ldr	x8, [sp, #0x98]
    a1c8:      	cmp	x8, x21
    a1cc:      	b.eq	0xa294 <generic_fentry_path+0xfd4>
    a1d0:      	mov	w8, #0x4                // =4
    a1d4:      	add	x9, sp, #0x78
    a1d8:      	add	x0, sp, #0x78
    a1dc:      	mov	w1, #0x8                // =8
    a1e0:      	mov	x2, x23
    a1e4:      	blr	x8
    a1e8:      	add	x2, x21, #0x20
    a1ec:      	mov	w8, #0x4                // =4
    a1f0:      	mov	w9, #0x10               // =16
    a1f4:      	add	x10, sp, #0x80
    a1f8:      	add	x0, sp, #0x80
    a1fc:      	mov	w1, #0x10               // =16
    a200:      	blr	x8
    a204:      	ldr	w21, [sp, #0x84]
    a208:      	ldr	x8, [sp, #0x40]
    a20c:      	ldr	x10, [sp, #0x60]
    a210:      	sub	x12, x10, x8
    a214:      	ldr	w23, [sp, #0x68]
    a218:      	subs	w10, w21, w23
    a21c:      	ldr	x9, [sp, #0x88]
    a220:      	csel	w10, wzr, w10, lo
    a224:      	cmp	w23, w21
    a228:      	csel	w11, w23, w21, lo
    a22c:      	cinc	w13, w11, hi
    a230:      	sub	w14, w23, w13
    a234:      	subs	x12, x12, x13
    a238:      	str	w14, [sp, #0x68]
    a23c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    a240:      	cmp	x12, #0xfff
    a244:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    a248:      	cmp	w23, w21
    a24c:      	b.ls	0xa258 <generic_fentry_path+0xf98>
    a250:      	mov	w13, #0x2f              // =47
    a254:      	strb	w13, [x8, x12]
    a258:      	add	x19, x8, x12
    a25c:      	cmp	w23, w21
    a260:      	add	x2, x9, x10
    a264:      	and	w1, w11, #0xff
    a268:      	mov	w8, #0x4                // =4
    a26c:      	cinc	x0, x19, hi
    a270:      	blr	x8
    a274:      	cmp	w23, w21
    a278:      	str	x19, [sp, #0x60]
    a27c:      	add	x19, sp, #0x70
    a280:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    a284:      	ldr	x21, [sp, #0x78]
    a288:      	ldp	x2, x24, [sp, #0x50]
    a28c:      	str	x21, [sp, #0x48]
    a290:      	b	0xa2e0 <generic_fentry_path+0x1020>
    a294:      	add	x2, x24, #0x10
    a298:      	mov	w8, #0x4                // =4
    a29c:      	add	x9, sp, #0x98
    a2a0:      	add	x0, sp, #0x98
    a2a4:      	mov	w1, #0x8                // =8
    a2a8:      	blr	x8
    a2ac:      	ldr	x8, [sp, #0x58]
    a2b0:      	ldr	x9, [sp, #0x98]
    a2b4:      	cmp	x8, x9
    a2b8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    a2bc:      	add	x2, x24, #0x18
    a2c0:      	mov	w8, #0x4                // =4
    a2c4:      	mov	x0, x22
    a2c8:      	mov	w1, #0x8                // =8
    a2cc:      	blr	x8
    a2d0:      	ldr	x24, [sp, #0x98]
    a2d4:      	ldr	x21, [sp, #0x48]
    a2d8:      	add	x2, x24, #0x20
    a2dc:      	stp	x2, x24, [sp, #0x50]
    a2e0:      	ldr	x8, [sp, #0x30]
    a2e4:      	cmp	x21, x8
    a2e8:      	b.ne	0xa2f8 <generic_fentry_path+0x1038>
    a2ec:      	ldr	x8, [sp, #0x38]
    a2f0:      	cmp	x2, x8
    a2f4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    a2f8:      	mov	w8, #0x4                // =4
    a2fc:      	add	x0, sp, #0x70
    a300:      	mov	w1, #0x8                // =8
    a304:      	blr	x8
    a308:      	ldr	x8, [sp, #0x70]
    a30c:      	cmp	x21, x8
    a310:      	b.eq	0xa400 <generic_fentry_path+0x1140>
    a314:      	add	x23, x21, #0x18
    a318:      	mov	w8, #0x4                // =4
    a31c:      	add	x9, sp, #0x98
    a320:      	add	x0, sp, #0x98
    a324:      	mov	w1, #0x8                // =8
    a328:      	mov	x2, x23
    a32c:      	blr	x8
    a330:      	ldr	x8, [sp, #0x98]
    a334:      	cmp	x8, x21
    a338:      	b.eq	0xa400 <generic_fentry_path+0x1140>
    a33c:      	mov	w8, #0x4                // =4
    a340:      	add	x9, sp, #0x78
    a344:      	add	x0, sp, #0x78
    a348:      	mov	w1, #0x8                // =8
    a34c:      	mov	x2, x23
    a350:      	blr	x8
    a354:      	add	x2, x21, #0x20
    a358:      	mov	w8, #0x4                // =4
    a35c:      	mov	w9, #0x10               // =16
    a360:      	add	x10, sp, #0x80
    a364:      	add	x0, sp, #0x80
    a368:      	mov	w1, #0x10               // =16
    a36c:      	blr	x8
    a370:      	ldr	w21, [sp, #0x84]
    a374:      	ldr	x8, [sp, #0x40]
    a378:      	ldr	x10, [sp, #0x60]
    a37c:      	sub	x12, x10, x8
    a380:      	ldr	w23, [sp, #0x68]
    a384:      	subs	w10, w21, w23
    a388:      	ldr	x9, [sp, #0x88]
    a38c:      	csel	w10, wzr, w10, lo
    a390:      	cmp	w23, w21
    a394:      	csel	w11, w23, w21, lo
    a398:      	cinc	w13, w11, hi
    a39c:      	sub	w14, w23, w13
    a3a0:      	subs	x12, x12, x13
    a3a4:      	str	w14, [sp, #0x68]
    a3a8:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    a3ac:      	cmp	x12, #0xfff
    a3b0:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    a3b4:      	cmp	w23, w21
    a3b8:      	b.ls	0xa3c4 <generic_fentry_path+0x1104>
    a3bc:      	mov	w13, #0x2f              // =47
    a3c0:      	strb	w13, [x8, x12]
    a3c4:      	add	x19, x8, x12
    a3c8:      	cmp	w23, w21
    a3cc:      	add	x2, x9, x10
    a3d0:      	and	w1, w11, #0xff
    a3d4:      	mov	w8, #0x4                // =4
    a3d8:      	cinc	x0, x19, hi
    a3dc:      	blr	x8
    a3e0:      	cmp	w23, w21
    a3e4:      	str	x19, [sp, #0x60]
    a3e8:      	add	x19, sp, #0x70
    a3ec:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    a3f0:      	ldr	x21, [sp, #0x78]
    a3f4:      	ldp	x2, x24, [sp, #0x50]
    a3f8:      	str	x21, [sp, #0x48]
    a3fc:      	b	0xa44c <generic_fentry_path+0x118c>
    a400:      	add	x2, x24, #0x10
    a404:      	mov	w8, #0x4                // =4
    a408:      	add	x9, sp, #0x98
    a40c:      	add	x0, sp, #0x98
    a410:      	mov	w1, #0x8                // =8
    a414:      	blr	x8
    a418:      	ldr	x8, [sp, #0x58]
    a41c:      	ldr	x9, [sp, #0x98]
    a420:      	cmp	x8, x9
    a424:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    a428:      	add	x2, x24, #0x18
    a42c:      	mov	w8, #0x4                // =4
    a430:      	mov	x0, x22
    a434:      	mov	w1, #0x8                // =8
    a438:      	blr	x8
    a43c:      	ldr	x24, [sp, #0x98]
    a440:      	ldr	x21, [sp, #0x48]
    a444:      	add	x2, x24, #0x20
    a448:      	stp	x2, x24, [sp, #0x50]
    a44c:      	ldr	x8, [sp, #0x30]
    a450:      	cmp	x21, x8
    a454:      	b.ne	0xa464 <generic_fentry_path+0x11a4>
    a458:      	ldr	x8, [sp, #0x38]
    a45c:      	cmp	x2, x8
    a460:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    a464:      	mov	w8, #0x4                // =4
    a468:      	add	x0, sp, #0x70
    a46c:      	mov	w1, #0x8                // =8
    a470:      	blr	x8
    a474:      	ldr	x8, [sp, #0x70]
    a478:      	cmp	x21, x8
    a47c:      	b.eq	0xa56c <generic_fentry_path+0x12ac>
    a480:      	add	x23, x21, #0x18
    a484:      	mov	w8, #0x4                // =4
    a488:      	add	x9, sp, #0x98
    a48c:      	add	x0, sp, #0x98
    a490:      	mov	w1, #0x8                // =8
    a494:      	mov	x2, x23
    a498:      	blr	x8
    a49c:      	ldr	x8, [sp, #0x98]
    a4a0:      	cmp	x8, x21
    a4a4:      	b.eq	0xa56c <generic_fentry_path+0x12ac>
    a4a8:      	mov	w8, #0x4                // =4
    a4ac:      	add	x9, sp, #0x78
    a4b0:      	add	x0, sp, #0x78
    a4b4:      	mov	w1, #0x8                // =8
    a4b8:      	mov	x2, x23
    a4bc:      	blr	x8
    a4c0:      	add	x2, x21, #0x20
    a4c4:      	mov	w8, #0x4                // =4
    a4c8:      	mov	w9, #0x10               // =16
    a4cc:      	add	x10, sp, #0x80
    a4d0:      	add	x0, sp, #0x80
    a4d4:      	mov	w1, #0x10               // =16
    a4d8:      	blr	x8
    a4dc:      	ldr	w21, [sp, #0x84]
    a4e0:      	ldr	x8, [sp, #0x40]
    a4e4:      	ldr	x10, [sp, #0x60]
    a4e8:      	sub	x12, x10, x8
    a4ec:      	ldr	w23, [sp, #0x68]
    a4f0:      	subs	w10, w21, w23
    a4f4:      	ldr	x9, [sp, #0x88]
    a4f8:      	csel	w10, wzr, w10, lo
    a4fc:      	cmp	w23, w21
    a500:      	csel	w11, w23, w21, lo
    a504:      	cinc	w13, w11, hi
    a508:      	sub	w14, w23, w13
    a50c:      	subs	x12, x12, x13
    a510:      	str	w14, [sp, #0x68]
    a514:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    a518:      	cmp	x12, #0xfff
    a51c:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    a520:      	cmp	w23, w21
    a524:      	b.ls	0xa530 <generic_fentry_path+0x1270>
    a528:      	mov	w13, #0x2f              // =47
    a52c:      	strb	w13, [x8, x12]
    a530:      	add	x19, x8, x12
    a534:      	cmp	w23, w21
    a538:      	add	x2, x9, x10
    a53c:      	and	w1, w11, #0xff
    a540:      	mov	w8, #0x4                // =4
    a544:      	cinc	x0, x19, hi
    a548:      	blr	x8
    a54c:      	cmp	w23, w21
    a550:      	str	x19, [sp, #0x60]
    a554:      	add	x19, sp, #0x70
    a558:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    a55c:      	ldr	x21, [sp, #0x78]
    a560:      	ldp	x2, x24, [sp, #0x50]
    a564:      	str	x21, [sp, #0x48]
    a568:      	b	0xa5b8 <generic_fentry_path+0x12f8>
    a56c:      	add	x2, x24, #0x10
    a570:      	mov	w8, #0x4                // =4
    a574:      	add	x9, sp, #0x98
    a578:      	add	x0, sp, #0x98
    a57c:      	mov	w1, #0x8                // =8
    a580:      	blr	x8
    a584:      	ldr	x8, [sp, #0x58]
    a588:      	ldr	x9, [sp, #0x98]
    a58c:      	cmp	x8, x9
    a590:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    a594:      	add	x2, x24, #0x18
    a598:      	mov	w8, #0x4                // =4
    a59c:      	mov	x0, x22
    a5a0:      	mov	w1, #0x8                // =8
    a5a4:      	blr	x8
    a5a8:      	ldr	x24, [sp, #0x98]
    a5ac:      	ldr	x21, [sp, #0x48]
    a5b0:      	add	x2, x24, #0x20
    a5b4:      	stp	x2, x24, [sp, #0x50]
    a5b8:      	ldr	x8, [sp, #0x30]
    a5bc:      	cmp	x21, x8
    a5c0:      	b.ne	0xa5d0 <generic_fentry_path+0x1310>
    a5c4:      	ldr	x8, [sp, #0x38]
    a5c8:      	cmp	x2, x8
    a5cc:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    a5d0:      	mov	w8, #0x4                // =4
    a5d4:      	add	x0, sp, #0x70
    a5d8:      	mov	w1, #0x8                // =8
    a5dc:      	blr	x8
    a5e0:      	ldr	x8, [sp, #0x70]
    a5e4:      	cmp	x21, x8
    a5e8:      	b.eq	0xa6d8 <generic_fentry_path+0x1418>
    a5ec:      	add	x23, x21, #0x18
    a5f0:      	mov	w8, #0x4                // =4
    a5f4:      	add	x9, sp, #0x98
    a5f8:      	add	x0, sp, #0x98
    a5fc:      	mov	w1, #0x8                // =8
    a600:      	mov	x2, x23
    a604:      	blr	x8
    a608:      	ldr	x8, [sp, #0x98]
    a60c:      	cmp	x8, x21
    a610:      	b.eq	0xa6d8 <generic_fentry_path+0x1418>
    a614:      	mov	w8, #0x4                // =4
    a618:      	add	x9, sp, #0x78
    a61c:      	add	x0, sp, #0x78
    a620:      	mov	w1, #0x8                // =8
    a624:      	mov	x2, x23
    a628:      	blr	x8
    a62c:      	add	x2, x21, #0x20
    a630:      	mov	w8, #0x4                // =4
    a634:      	mov	w9, #0x10               // =16
    a638:      	add	x10, sp, #0x80
    a63c:      	add	x0, sp, #0x80
    a640:      	mov	w1, #0x10               // =16
    a644:      	blr	x8
    a648:      	ldr	w21, [sp, #0x84]
    a64c:      	ldr	x8, [sp, #0x40]
    a650:      	ldr	x10, [sp, #0x60]
    a654:      	sub	x12, x10, x8
    a658:      	ldr	w23, [sp, #0x68]
    a65c:      	subs	w10, w21, w23
    a660:      	ldr	x9, [sp, #0x88]
    a664:      	csel	w10, wzr, w10, lo
    a668:      	cmp	w23, w21
    a66c:      	csel	w11, w23, w21, lo
    a670:      	cinc	w13, w11, hi
    a674:      	sub	w14, w23, w13
    a678:      	subs	x12, x12, x13
    a67c:      	str	w14, [sp, #0x68]
    a680:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    a684:      	cmp	x12, #0xfff
    a688:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    a68c:      	cmp	w23, w21
    a690:      	b.ls	0xa69c <generic_fentry_path+0x13dc>
    a694:      	mov	w13, #0x2f              // =47
    a698:      	strb	w13, [x8, x12]
    a69c:      	add	x19, x8, x12
    a6a0:      	cmp	w23, w21
    a6a4:      	add	x2, x9, x10
    a6a8:      	and	w1, w11, #0xff
    a6ac:      	mov	w8, #0x4                // =4
    a6b0:      	cinc	x0, x19, hi
    a6b4:      	blr	x8
    a6b8:      	cmp	w23, w21
    a6bc:      	str	x19, [sp, #0x60]
    a6c0:      	add	x19, sp, #0x70
    a6c4:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    a6c8:      	ldr	x21, [sp, #0x78]
    a6cc:      	ldp	x2, x24, [sp, #0x50]
    a6d0:      	str	x21, [sp, #0x48]
    a6d4:      	b	0xa724 <generic_fentry_path+0x1464>
    a6d8:      	add	x2, x24, #0x10
    a6dc:      	mov	w8, #0x4                // =4
    a6e0:      	add	x9, sp, #0x98
    a6e4:      	add	x0, sp, #0x98
    a6e8:      	mov	w1, #0x8                // =8
    a6ec:      	blr	x8
    a6f0:      	ldr	x8, [sp, #0x58]
    a6f4:      	ldr	x9, [sp, #0x98]
    a6f8:      	cmp	x8, x9
    a6fc:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    a700:      	add	x2, x24, #0x18
    a704:      	mov	w8, #0x4                // =4
    a708:      	mov	x0, x22
    a70c:      	mov	w1, #0x8                // =8
    a710:      	blr	x8
    a714:      	ldr	x24, [sp, #0x98]
    a718:      	ldr	x21, [sp, #0x48]
    a71c:      	add	x2, x24, #0x20
    a720:      	stp	x2, x24, [sp, #0x50]
    a724:      	ldr	x8, [sp, #0x30]
    a728:      	cmp	x21, x8
    a72c:      	b.ne	0xa73c <generic_fentry_path+0x147c>
    a730:      	ldr	x8, [sp, #0x38]
    a734:      	cmp	x2, x8
    a738:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    a73c:      	mov	w8, #0x4                // =4
    a740:      	add	x0, sp, #0x70
    a744:      	mov	w1, #0x8                // =8
    a748:      	blr	x8
    a74c:      	ldr	x8, [sp, #0x70]
    a750:      	cmp	x21, x8
    a754:      	b.eq	0xa844 <generic_fentry_path+0x1584>
    a758:      	add	x23, x21, #0x18
    a75c:      	mov	w8, #0x4                // =4
    a760:      	add	x9, sp, #0x98
    a764:      	add	x0, sp, #0x98
    a768:      	mov	w1, #0x8                // =8
    a76c:      	mov	x2, x23
    a770:      	blr	x8
    a774:      	ldr	x8, [sp, #0x98]
    a778:      	cmp	x8, x21
    a77c:      	b.eq	0xa844 <generic_fentry_path+0x1584>
    a780:      	mov	w8, #0x4                // =4
    a784:      	add	x9, sp, #0x78
    a788:      	add	x0, sp, #0x78
    a78c:      	mov	w1, #0x8                // =8
    a790:      	mov	x2, x23
    a794:      	blr	x8
    a798:      	add	x2, x21, #0x20
    a79c:      	mov	w8, #0x4                // =4
    a7a0:      	mov	w9, #0x10               // =16
    a7a4:      	add	x10, sp, #0x80
    a7a8:      	add	x0, sp, #0x80
    a7ac:      	mov	w1, #0x10               // =16
    a7b0:      	blr	x8
    a7b4:      	ldr	w21, [sp, #0x84]
    a7b8:      	ldr	x8, [sp, #0x40]
    a7bc:      	ldr	x10, [sp, #0x60]
    a7c0:      	sub	x12, x10, x8
    a7c4:      	ldr	w23, [sp, #0x68]
    a7c8:      	subs	w10, w21, w23
    a7cc:      	ldr	x9, [sp, #0x88]
    a7d0:      	csel	w10, wzr, w10, lo
    a7d4:      	cmp	w23, w21
    a7d8:      	csel	w11, w23, w21, lo
    a7dc:      	cinc	w13, w11, hi
    a7e0:      	sub	w14, w23, w13
    a7e4:      	subs	x12, x12, x13
    a7e8:      	str	w14, [sp, #0x68]
    a7ec:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    a7f0:      	cmp	x12, #0xfff
    a7f4:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    a7f8:      	cmp	w23, w21
    a7fc:      	b.ls	0xa808 <generic_fentry_path+0x1548>
    a800:      	mov	w13, #0x2f              // =47
    a804:      	strb	w13, [x8, x12]
    a808:      	add	x19, x8, x12
    a80c:      	cmp	w23, w21
    a810:      	add	x2, x9, x10
    a814:      	and	w1, w11, #0xff
    a818:      	mov	w8, #0x4                // =4
    a81c:      	cinc	x0, x19, hi
    a820:      	blr	x8
    a824:      	cmp	w23, w21
    a828:      	str	x19, [sp, #0x60]
    a82c:      	add	x19, sp, #0x70
    a830:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    a834:      	ldr	x21, [sp, #0x78]
    a838:      	ldp	x2, x24, [sp, #0x50]
    a83c:      	str	x21, [sp, #0x48]
    a840:      	b	0xa890 <generic_fentry_path+0x15d0>
    a844:      	add	x2, x24, #0x10
    a848:      	mov	w8, #0x4                // =4
    a84c:      	add	x9, sp, #0x98
    a850:      	add	x0, sp, #0x98
    a854:      	mov	w1, #0x8                // =8
    a858:      	blr	x8
    a85c:      	ldr	x8, [sp, #0x58]
    a860:      	ldr	x9, [sp, #0x98]
    a864:      	cmp	x8, x9
    a868:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    a86c:      	add	x2, x24, #0x18
    a870:      	mov	w8, #0x4                // =4
    a874:      	mov	x0, x22
    a878:      	mov	w1, #0x8                // =8
    a87c:      	blr	x8
    a880:      	ldr	x24, [sp, #0x98]
    a884:      	ldr	x21, [sp, #0x48]
    a888:      	add	x2, x24, #0x20
    a88c:      	stp	x2, x24, [sp, #0x50]
    a890:      	ldr	x8, [sp, #0x30]
    a894:      	cmp	x21, x8
    a898:      	b.ne	0xa8a8 <generic_fentry_path+0x15e8>
    a89c:      	ldr	x8, [sp, #0x38]
    a8a0:      	cmp	x2, x8
    a8a4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    a8a8:      	mov	w8, #0x4                // =4
    a8ac:      	add	x0, sp, #0x70
    a8b0:      	mov	w1, #0x8                // =8
    a8b4:      	blr	x8
    a8b8:      	ldr	x8, [sp, #0x70]
    a8bc:      	cmp	x21, x8
    a8c0:      	b.eq	0xa9b0 <generic_fentry_path+0x16f0>
    a8c4:      	add	x23, x21, #0x18
    a8c8:      	mov	w8, #0x4                // =4
    a8cc:      	add	x9, sp, #0x98
    a8d0:      	add	x0, sp, #0x98
    a8d4:      	mov	w1, #0x8                // =8
    a8d8:      	mov	x2, x23
    a8dc:      	blr	x8
    a8e0:      	ldr	x8, [sp, #0x98]
    a8e4:      	cmp	x8, x21
    a8e8:      	b.eq	0xa9b0 <generic_fentry_path+0x16f0>
    a8ec:      	mov	w8, #0x4                // =4
    a8f0:      	add	x9, sp, #0x78
    a8f4:      	add	x0, sp, #0x78
    a8f8:      	mov	w1, #0x8                // =8
    a8fc:      	mov	x2, x23
    a900:      	blr	x8
    a904:      	add	x2, x21, #0x20
    a908:      	mov	w8, #0x4                // =4
    a90c:      	mov	w9, #0x10               // =16
    a910:      	add	x10, sp, #0x80
    a914:      	add	x0, sp, #0x80
    a918:      	mov	w1, #0x10               // =16
    a91c:      	blr	x8
    a920:      	ldr	w21, [sp, #0x84]
    a924:      	ldr	x8, [sp, #0x40]
    a928:      	ldr	x10, [sp, #0x60]
    a92c:      	sub	x12, x10, x8
    a930:      	ldr	w23, [sp, #0x68]
    a934:      	subs	w10, w21, w23
    a938:      	ldr	x9, [sp, #0x88]
    a93c:      	csel	w10, wzr, w10, lo
    a940:      	cmp	w23, w21
    a944:      	csel	w11, w23, w21, lo
    a948:      	cinc	w13, w11, hi
    a94c:      	sub	w14, w23, w13
    a950:      	subs	x12, x12, x13
    a954:      	str	w14, [sp, #0x68]
    a958:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    a95c:      	cmp	x12, #0xfff
    a960:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    a964:      	cmp	w23, w21
    a968:      	b.ls	0xa974 <generic_fentry_path+0x16b4>
    a96c:      	mov	w13, #0x2f              // =47
    a970:      	strb	w13, [x8, x12]
    a974:      	add	x19, x8, x12
    a978:      	cmp	w23, w21
    a97c:      	add	x2, x9, x10
    a980:      	and	w1, w11, #0xff
    a984:      	mov	w8, #0x4                // =4
    a988:      	cinc	x0, x19, hi
    a98c:      	blr	x8
    a990:      	cmp	w23, w21
    a994:      	str	x19, [sp, #0x60]
    a998:      	add	x19, sp, #0x70
    a99c:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    a9a0:      	ldr	x21, [sp, #0x78]
    a9a4:      	ldp	x2, x24, [sp, #0x50]
    a9a8:      	str	x21, [sp, #0x48]
    a9ac:      	b	0xa9fc <generic_fentry_path+0x173c>
    a9b0:      	add	x2, x24, #0x10
    a9b4:      	mov	w8, #0x4                // =4
    a9b8:      	add	x9, sp, #0x98
    a9bc:      	add	x0, sp, #0x98
    a9c0:      	mov	w1, #0x8                // =8
    a9c4:      	blr	x8
    a9c8:      	ldr	x8, [sp, #0x58]
    a9cc:      	ldr	x9, [sp, #0x98]
    a9d0:      	cmp	x8, x9
    a9d4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    a9d8:      	add	x2, x24, #0x18
    a9dc:      	mov	w8, #0x4                // =4
    a9e0:      	mov	x0, x22
    a9e4:      	mov	w1, #0x8                // =8
    a9e8:      	blr	x8
    a9ec:      	ldr	x24, [sp, #0x98]
    a9f0:      	ldr	x21, [sp, #0x48]
    a9f4:      	add	x2, x24, #0x20
    a9f8:      	stp	x2, x24, [sp, #0x50]
    a9fc:      	ldr	x8, [sp, #0x30]
    aa00:      	cmp	x21, x8
    aa04:      	b.ne	0xaa14 <generic_fentry_path+0x1754>
    aa08:      	ldr	x8, [sp, #0x38]
    aa0c:      	cmp	x2, x8
    aa10:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    aa14:      	mov	w8, #0x4                // =4
    aa18:      	add	x0, sp, #0x70
    aa1c:      	mov	w1, #0x8                // =8
    aa20:      	blr	x8
    aa24:      	ldr	x8, [sp, #0x70]
    aa28:      	cmp	x21, x8
    aa2c:      	b.eq	0xab1c <generic_fentry_path+0x185c>
    aa30:      	add	x23, x21, #0x18
    aa34:      	mov	w8, #0x4                // =4
    aa38:      	add	x9, sp, #0x98
    aa3c:      	add	x0, sp, #0x98
    aa40:      	mov	w1, #0x8                // =8
    aa44:      	mov	x2, x23
    aa48:      	blr	x8
    aa4c:      	ldr	x8, [sp, #0x98]
    aa50:      	cmp	x8, x21
    aa54:      	b.eq	0xab1c <generic_fentry_path+0x185c>
    aa58:      	mov	w8, #0x4                // =4
    aa5c:      	add	x9, sp, #0x78
    aa60:      	add	x0, sp, #0x78
    aa64:      	mov	w1, #0x8                // =8
    aa68:      	mov	x2, x23
    aa6c:      	blr	x8
    aa70:      	add	x2, x21, #0x20
    aa74:      	mov	w8, #0x4                // =4
    aa78:      	mov	w9, #0x10               // =16
    aa7c:      	add	x10, sp, #0x80
    aa80:      	add	x0, sp, #0x80
    aa84:      	mov	w1, #0x10               // =16
    aa88:      	blr	x8
    aa8c:      	ldr	w21, [sp, #0x84]
    aa90:      	ldr	x8, [sp, #0x40]
    aa94:      	ldr	x10, [sp, #0x60]
    aa98:      	sub	x12, x10, x8
    aa9c:      	ldr	w23, [sp, #0x68]
    aaa0:      	subs	w10, w21, w23
    aaa4:      	ldr	x9, [sp, #0x88]
    aaa8:      	csel	w10, wzr, w10, lo
    aaac:      	cmp	w23, w21
    aab0:      	csel	w11, w23, w21, lo
    aab4:      	cinc	w13, w11, hi
    aab8:      	sub	w14, w23, w13
    aabc:      	subs	x12, x12, x13
    aac0:      	str	w14, [sp, #0x68]
    aac4:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    aac8:      	cmp	x12, #0xfff
    aacc:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    aad0:      	cmp	w23, w21
    aad4:      	b.ls	0xaae0 <generic_fentry_path+0x1820>
    aad8:      	mov	w13, #0x2f              // =47
    aadc:      	strb	w13, [x8, x12]
    aae0:      	add	x19, x8, x12
    aae4:      	cmp	w23, w21
    aae8:      	add	x2, x9, x10
    aaec:      	and	w1, w11, #0xff
    aaf0:      	mov	w8, #0x4                // =4
    aaf4:      	cinc	x0, x19, hi
    aaf8:      	blr	x8
    aafc:      	cmp	w23, w21
    ab00:      	str	x19, [sp, #0x60]
    ab04:      	add	x19, sp, #0x70
    ab08:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    ab0c:      	ldr	x21, [sp, #0x78]
    ab10:      	ldp	x2, x24, [sp, #0x50]
    ab14:      	str	x21, [sp, #0x48]
    ab18:      	b	0xab68 <generic_fentry_path+0x18a8>
    ab1c:      	add	x2, x24, #0x10
    ab20:      	mov	w8, #0x4                // =4
    ab24:      	add	x9, sp, #0x98
    ab28:      	add	x0, sp, #0x98
    ab2c:      	mov	w1, #0x8                // =8
    ab30:      	blr	x8
    ab34:      	ldr	x8, [sp, #0x58]
    ab38:      	ldr	x9, [sp, #0x98]
    ab3c:      	cmp	x8, x9
    ab40:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    ab44:      	add	x2, x24, #0x18
    ab48:      	mov	w8, #0x4                // =4
    ab4c:      	mov	x0, x22
    ab50:      	mov	w1, #0x8                // =8
    ab54:      	blr	x8
    ab58:      	ldr	x24, [sp, #0x98]
    ab5c:      	ldr	x21, [sp, #0x48]
    ab60:      	add	x2, x24, #0x20
    ab64:      	stp	x2, x24, [sp, #0x50]
    ab68:      	ldr	x8, [sp, #0x30]
    ab6c:      	cmp	x21, x8
    ab70:      	b.ne	0xab80 <generic_fentry_path+0x18c0>
    ab74:      	ldr	x8, [sp, #0x38]
    ab78:      	cmp	x2, x8
    ab7c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    ab80:      	mov	w8, #0x4                // =4
    ab84:      	add	x0, sp, #0x70
    ab88:      	mov	w1, #0x8                // =8
    ab8c:      	blr	x8
    ab90:      	ldr	x8, [sp, #0x70]
    ab94:      	cmp	x21, x8
    ab98:      	b.eq	0xac88 <generic_fentry_path+0x19c8>
    ab9c:      	add	x23, x21, #0x18
    aba0:      	mov	w8, #0x4                // =4
    aba4:      	add	x9, sp, #0x98
    aba8:      	add	x0, sp, #0x98
    abac:      	mov	w1, #0x8                // =8
    abb0:      	mov	x2, x23
    abb4:      	blr	x8
    abb8:      	ldr	x8, [sp, #0x98]
    abbc:      	cmp	x8, x21
    abc0:      	b.eq	0xac88 <generic_fentry_path+0x19c8>
    abc4:      	mov	w8, #0x4                // =4
    abc8:      	add	x9, sp, #0x78
    abcc:      	add	x0, sp, #0x78
    abd0:      	mov	w1, #0x8                // =8
    abd4:      	mov	x2, x23
    abd8:      	blr	x8
    abdc:      	add	x2, x21, #0x20
    abe0:      	mov	w8, #0x4                // =4
    abe4:      	mov	w9, #0x10               // =16
    abe8:      	add	x10, sp, #0x80
    abec:      	add	x0, sp, #0x80
    abf0:      	mov	w1, #0x10               // =16
    abf4:      	blr	x8
    abf8:      	ldr	w21, [sp, #0x84]
    abfc:      	ldr	x8, [sp, #0x40]
    ac00:      	ldr	x10, [sp, #0x60]
    ac04:      	sub	x12, x10, x8
    ac08:      	ldr	w23, [sp, #0x68]
    ac0c:      	subs	w10, w21, w23
    ac10:      	ldr	x9, [sp, #0x88]
    ac14:      	csel	w10, wzr, w10, lo
    ac18:      	cmp	w23, w21
    ac1c:      	csel	w11, w23, w21, lo
    ac20:      	cinc	w13, w11, hi
    ac24:      	sub	w14, w23, w13
    ac28:      	subs	x12, x12, x13
    ac2c:      	str	w14, [sp, #0x68]
    ac30:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    ac34:      	cmp	x12, #0xfff
    ac38:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    ac3c:      	cmp	w23, w21
    ac40:      	b.ls	0xac4c <generic_fentry_path+0x198c>
    ac44:      	mov	w13, #0x2f              // =47
    ac48:      	strb	w13, [x8, x12]
    ac4c:      	add	x19, x8, x12
    ac50:      	cmp	w23, w21
    ac54:      	add	x2, x9, x10
    ac58:      	and	w1, w11, #0xff
    ac5c:      	mov	w8, #0x4                // =4
    ac60:      	cinc	x0, x19, hi
    ac64:      	blr	x8
    ac68:      	cmp	w23, w21
    ac6c:      	str	x19, [sp, #0x60]
    ac70:      	add	x19, sp, #0x70
    ac74:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    ac78:      	ldr	x21, [sp, #0x78]
    ac7c:      	ldp	x2, x24, [sp, #0x50]
    ac80:      	str	x21, [sp, #0x48]
    ac84:      	b	0xacd4 <generic_fentry_path+0x1a14>
    ac88:      	add	x2, x24, #0x10
    ac8c:      	mov	w8, #0x4                // =4
    ac90:      	add	x9, sp, #0x98
    ac94:      	add	x0, sp, #0x98
    ac98:      	mov	w1, #0x8                // =8
    ac9c:      	blr	x8
    aca0:      	ldr	x8, [sp, #0x58]
    aca4:      	ldr	x9, [sp, #0x98]
    aca8:      	cmp	x8, x9
    acac:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    acb0:      	add	x2, x24, #0x18
    acb4:      	mov	w8, #0x4                // =4
    acb8:      	mov	x0, x22
    acbc:      	mov	w1, #0x8                // =8
    acc0:      	blr	x8
    acc4:      	ldr	x24, [sp, #0x98]
    acc8:      	ldr	x21, [sp, #0x48]
    accc:      	add	x2, x24, #0x20
    acd0:      	stp	x2, x24, [sp, #0x50]
    acd4:      	ldr	x8, [sp, #0x30]
    acd8:      	cmp	x21, x8
    acdc:      	b.ne	0xacec <generic_fentry_path+0x1a2c>
    ace0:      	ldr	x8, [sp, #0x38]
    ace4:      	cmp	x2, x8
    ace8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    acec:      	mov	w8, #0x4                // =4
    acf0:      	add	x0, sp, #0x70
    acf4:      	mov	w1, #0x8                // =8
    acf8:      	blr	x8
    acfc:      	ldr	x8, [sp, #0x70]
    ad00:      	cmp	x21, x8
    ad04:      	b.eq	0xadf4 <generic_fentry_path+0x1b34>
    ad08:      	add	x23, x21, #0x18
    ad0c:      	mov	w8, #0x4                // =4
    ad10:      	add	x9, sp, #0x98
    ad14:      	add	x0, sp, #0x98
    ad18:      	mov	w1, #0x8                // =8
    ad1c:      	mov	x2, x23
    ad20:      	blr	x8
    ad24:      	ldr	x8, [sp, #0x98]
    ad28:      	cmp	x8, x21
    ad2c:      	b.eq	0xadf4 <generic_fentry_path+0x1b34>
    ad30:      	mov	w8, #0x4                // =4
    ad34:      	add	x9, sp, #0x78
    ad38:      	add	x0, sp, #0x78
    ad3c:      	mov	w1, #0x8                // =8
    ad40:      	mov	x2, x23
    ad44:      	blr	x8
    ad48:      	add	x2, x21, #0x20
    ad4c:      	mov	w8, #0x4                // =4
    ad50:      	mov	w9, #0x10               // =16
    ad54:      	add	x10, sp, #0x80
    ad58:      	add	x0, sp, #0x80
    ad5c:      	mov	w1, #0x10               // =16
    ad60:      	blr	x8
    ad64:      	ldr	w21, [sp, #0x84]
    ad68:      	ldr	x8, [sp, #0x40]
    ad6c:      	ldr	x10, [sp, #0x60]
    ad70:      	sub	x12, x10, x8
    ad74:      	ldr	w23, [sp, #0x68]
    ad78:      	subs	w10, w21, w23
    ad7c:      	ldr	x9, [sp, #0x88]
    ad80:      	csel	w10, wzr, w10, lo
    ad84:      	cmp	w23, w21
    ad88:      	csel	w11, w23, w21, lo
    ad8c:      	cinc	w13, w11, hi
    ad90:      	sub	w14, w23, w13
    ad94:      	subs	x12, x12, x13
    ad98:      	str	w14, [sp, #0x68]
    ad9c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    ada0:      	cmp	x12, #0xfff
    ada4:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    ada8:      	cmp	w23, w21
    adac:      	b.ls	0xadb8 <generic_fentry_path+0x1af8>
    adb0:      	mov	w13, #0x2f              // =47
    adb4:      	strb	w13, [x8, x12]
    adb8:      	add	x19, x8, x12
    adbc:      	cmp	w23, w21
    adc0:      	add	x2, x9, x10
    adc4:      	and	w1, w11, #0xff
    adc8:      	mov	w8, #0x4                // =4
    adcc:      	cinc	x0, x19, hi
    add0:      	blr	x8
    add4:      	cmp	w23, w21
    add8:      	str	x19, [sp, #0x60]
    addc:      	add	x19, sp, #0x70
    ade0:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    ade4:      	ldr	x21, [sp, #0x78]
    ade8:      	ldp	x2, x24, [sp, #0x50]
    adec:      	str	x21, [sp, #0x48]
    adf0:      	b	0xae40 <generic_fentry_path+0x1b80>
    adf4:      	add	x2, x24, #0x10
    adf8:      	mov	w8, #0x4                // =4
    adfc:      	add	x9, sp, #0x98
    ae00:      	add	x0, sp, #0x98
    ae04:      	mov	w1, #0x8                // =8
    ae08:      	blr	x8
    ae0c:      	ldr	x8, [sp, #0x58]
    ae10:      	ldr	x9, [sp, #0x98]
    ae14:      	cmp	x8, x9
    ae18:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    ae1c:      	add	x2, x24, #0x18
    ae20:      	mov	w8, #0x4                // =4
    ae24:      	mov	x0, x22
    ae28:      	mov	w1, #0x8                // =8
    ae2c:      	blr	x8
    ae30:      	ldr	x24, [sp, #0x98]
    ae34:      	ldr	x21, [sp, #0x48]
    ae38:      	add	x2, x24, #0x20
    ae3c:      	stp	x2, x24, [sp, #0x50]
    ae40:      	ldr	x8, [sp, #0x30]
    ae44:      	cmp	x21, x8
    ae48:      	b.ne	0xae58 <generic_fentry_path+0x1b98>
    ae4c:      	ldr	x8, [sp, #0x38]
    ae50:      	cmp	x2, x8
    ae54:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    ae58:      	mov	w8, #0x4                // =4
    ae5c:      	add	x0, sp, #0x70
    ae60:      	mov	w1, #0x8                // =8
    ae64:      	blr	x8
    ae68:      	ldr	x8, [sp, #0x70]
    ae6c:      	cmp	x21, x8
    ae70:      	b.eq	0xaf60 <generic_fentry_path+0x1ca0>
    ae74:      	add	x23, x21, #0x18
    ae78:      	mov	w8, #0x4                // =4
    ae7c:      	add	x9, sp, #0x98
    ae80:      	add	x0, sp, #0x98
    ae84:      	mov	w1, #0x8                // =8
    ae88:      	mov	x2, x23
    ae8c:      	blr	x8
    ae90:      	ldr	x8, [sp, #0x98]
    ae94:      	cmp	x8, x21
    ae98:      	b.eq	0xaf60 <generic_fentry_path+0x1ca0>
    ae9c:      	mov	w8, #0x4                // =4
    aea0:      	add	x9, sp, #0x78
    aea4:      	add	x0, sp, #0x78
    aea8:      	mov	w1, #0x8                // =8
    aeac:      	mov	x2, x23
    aeb0:      	blr	x8
    aeb4:      	add	x2, x21, #0x20
    aeb8:      	mov	w8, #0x4                // =4
    aebc:      	mov	w9, #0x10               // =16
    aec0:      	add	x10, sp, #0x80
    aec4:      	add	x0, sp, #0x80
    aec8:      	mov	w1, #0x10               // =16
    aecc:      	blr	x8
    aed0:      	ldr	w21, [sp, #0x84]
    aed4:      	ldr	x8, [sp, #0x40]
    aed8:      	ldr	x10, [sp, #0x60]
    aedc:      	sub	x12, x10, x8
    aee0:      	ldr	w23, [sp, #0x68]
    aee4:      	subs	w10, w21, w23
    aee8:      	ldr	x9, [sp, #0x88]
    aeec:      	csel	w10, wzr, w10, lo
    aef0:      	cmp	w23, w21
    aef4:      	csel	w11, w23, w21, lo
    aef8:      	cinc	w13, w11, hi
    aefc:      	sub	w14, w23, w13
    af00:      	subs	x12, x12, x13
    af04:      	str	w14, [sp, #0x68]
    af08:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    af0c:      	cmp	x12, #0xfff
    af10:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    af14:      	cmp	w23, w21
    af18:      	b.ls	0xaf24 <generic_fentry_path+0x1c64>
    af1c:      	mov	w13, #0x2f              // =47
    af20:      	strb	w13, [x8, x12]
    af24:      	add	x19, x8, x12
    af28:      	cmp	w23, w21
    af2c:      	add	x2, x9, x10
    af30:      	and	w1, w11, #0xff
    af34:      	mov	w8, #0x4                // =4
    af38:      	cinc	x0, x19, hi
    af3c:      	blr	x8
    af40:      	cmp	w23, w21
    af44:      	str	x19, [sp, #0x60]
    af48:      	add	x19, sp, #0x70
    af4c:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    af50:      	ldr	x21, [sp, #0x78]
    af54:      	ldp	x2, x24, [sp, #0x50]
    af58:      	str	x21, [sp, #0x48]
    af5c:      	b	0xafac <generic_fentry_path+0x1cec>
    af60:      	add	x2, x24, #0x10
    af64:      	mov	w8, #0x4                // =4
    af68:      	add	x9, sp, #0x98
    af6c:      	add	x0, sp, #0x98
    af70:      	mov	w1, #0x8                // =8
    af74:      	blr	x8
    af78:      	ldr	x8, [sp, #0x58]
    af7c:      	ldr	x9, [sp, #0x98]
    af80:      	cmp	x8, x9
    af84:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    af88:      	add	x2, x24, #0x18
    af8c:      	mov	w8, #0x4                // =4
    af90:      	mov	x0, x22
    af94:      	mov	w1, #0x8                // =8
    af98:      	blr	x8
    af9c:      	ldr	x24, [sp, #0x98]
    afa0:      	ldr	x21, [sp, #0x48]
    afa4:      	add	x2, x24, #0x20
    afa8:      	stp	x2, x24, [sp, #0x50]
    afac:      	ldr	x8, [sp, #0x30]
    afb0:      	cmp	x21, x8
    afb4:      	b.ne	0xafc4 <generic_fentry_path+0x1d04>
    afb8:      	ldr	x8, [sp, #0x38]
    afbc:      	cmp	x2, x8
    afc0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    afc4:      	mov	w8, #0x4                // =4
    afc8:      	add	x0, sp, #0x70
    afcc:      	mov	w1, #0x8                // =8
    afd0:      	blr	x8
    afd4:      	ldr	x8, [sp, #0x70]
    afd8:      	cmp	x21, x8
    afdc:      	b.eq	0xb0cc <generic_fentry_path+0x1e0c>
    afe0:      	add	x23, x21, #0x18
    afe4:      	mov	w8, #0x4                // =4
    afe8:      	add	x9, sp, #0x98
    afec:      	add	x0, sp, #0x98
    aff0:      	mov	w1, #0x8                // =8
    aff4:      	mov	x2, x23
    aff8:      	blr	x8
    affc:      	ldr	x8, [sp, #0x98]
    b000:      	cmp	x8, x21
    b004:      	b.eq	0xb0cc <generic_fentry_path+0x1e0c>
    b008:      	mov	w8, #0x4                // =4
    b00c:      	add	x9, sp, #0x78
    b010:      	add	x0, sp, #0x78
    b014:      	mov	w1, #0x8                // =8
    b018:      	mov	x2, x23
    b01c:      	blr	x8
    b020:      	add	x2, x21, #0x20
    b024:      	mov	w8, #0x4                // =4
    b028:      	mov	w9, #0x10               // =16
    b02c:      	add	x10, sp, #0x80
    b030:      	add	x0, sp, #0x80
    b034:      	mov	w1, #0x10               // =16
    b038:      	blr	x8
    b03c:      	ldr	w21, [sp, #0x84]
    b040:      	ldr	x8, [sp, #0x40]
    b044:      	ldr	x10, [sp, #0x60]
    b048:      	sub	x12, x10, x8
    b04c:      	ldr	w23, [sp, #0x68]
    b050:      	subs	w10, w21, w23
    b054:      	ldr	x9, [sp, #0x88]
    b058:      	csel	w10, wzr, w10, lo
    b05c:      	cmp	w23, w21
    b060:      	csel	w11, w23, w21, lo
    b064:      	cinc	w13, w11, hi
    b068:      	sub	w14, w23, w13
    b06c:      	subs	x12, x12, x13
    b070:      	str	w14, [sp, #0x68]
    b074:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    b078:      	cmp	x12, #0xfff
    b07c:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    b080:      	cmp	w23, w21
    b084:      	b.ls	0xb090 <generic_fentry_path+0x1dd0>
    b088:      	mov	w13, #0x2f              // =47
    b08c:      	strb	w13, [x8, x12]
    b090:      	add	x19, x8, x12
    b094:      	cmp	w23, w21
    b098:      	add	x2, x9, x10
    b09c:      	and	w1, w11, #0xff
    b0a0:      	mov	w8, #0x4                // =4
    b0a4:      	cinc	x0, x19, hi
    b0a8:      	blr	x8
    b0ac:      	cmp	w23, w21
    b0b0:      	str	x19, [sp, #0x60]
    b0b4:      	add	x19, sp, #0x70
    b0b8:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    b0bc:      	ldr	x21, [sp, #0x78]
    b0c0:      	ldp	x2, x24, [sp, #0x50]
    b0c4:      	str	x21, [sp, #0x48]
    b0c8:      	b	0xb118 <generic_fentry_path+0x1e58>
    b0cc:      	add	x2, x24, #0x10
    b0d0:      	mov	w8, #0x4                // =4
    b0d4:      	add	x9, sp, #0x98
    b0d8:      	add	x0, sp, #0x98
    b0dc:      	mov	w1, #0x8                // =8
    b0e0:      	blr	x8
    b0e4:      	ldr	x8, [sp, #0x58]
    b0e8:      	ldr	x9, [sp, #0x98]
    b0ec:      	cmp	x8, x9
    b0f0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    b0f4:      	add	x2, x24, #0x18
    b0f8:      	mov	w8, #0x4                // =4
    b0fc:      	mov	x0, x22
    b100:      	mov	w1, #0x8                // =8
    b104:      	blr	x8
    b108:      	ldr	x24, [sp, #0x98]
    b10c:      	ldr	x21, [sp, #0x48]
    b110:      	add	x2, x24, #0x20
    b114:      	stp	x2, x24, [sp, #0x50]
    b118:      	ldr	x8, [sp, #0x30]
    b11c:      	cmp	x21, x8
    b120:      	b.ne	0xb130 <generic_fentry_path+0x1e70>
    b124:      	ldr	x8, [sp, #0x38]
    b128:      	cmp	x2, x8
    b12c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    b130:      	mov	w8, #0x4                // =4
    b134:      	add	x0, sp, #0x70
    b138:      	mov	w1, #0x8                // =8
    b13c:      	blr	x8
    b140:      	ldr	x8, [sp, #0x70]
    b144:      	cmp	x21, x8
    b148:      	b.eq	0xb238 <generic_fentry_path+0x1f78>
    b14c:      	add	x23, x21, #0x18
    b150:      	mov	w8, #0x4                // =4
    b154:      	add	x9, sp, #0x98
    b158:      	add	x0, sp, #0x98
    b15c:      	mov	w1, #0x8                // =8
    b160:      	mov	x2, x23
    b164:      	blr	x8
    b168:      	ldr	x8, [sp, #0x98]
    b16c:      	cmp	x8, x21
    b170:      	b.eq	0xb238 <generic_fentry_path+0x1f78>
    b174:      	mov	w8, #0x4                // =4
    b178:      	add	x9, sp, #0x78
    b17c:      	add	x0, sp, #0x78
    b180:      	mov	w1, #0x8                // =8
    b184:      	mov	x2, x23
    b188:      	blr	x8
    b18c:      	add	x2, x21, #0x20
    b190:      	mov	w8, #0x4                // =4
    b194:      	mov	w9, #0x10               // =16
    b198:      	add	x10, sp, #0x80
    b19c:      	add	x0, sp, #0x80
    b1a0:      	mov	w1, #0x10               // =16
    b1a4:      	blr	x8
    b1a8:      	ldr	w21, [sp, #0x84]
    b1ac:      	ldr	x8, [sp, #0x40]
    b1b0:      	ldr	x10, [sp, #0x60]
    b1b4:      	sub	x12, x10, x8
    b1b8:      	ldr	w23, [sp, #0x68]
    b1bc:      	subs	w10, w21, w23
    b1c0:      	ldr	x9, [sp, #0x88]
    b1c4:      	csel	w10, wzr, w10, lo
    b1c8:      	cmp	w23, w21
    b1cc:      	csel	w11, w23, w21, lo
    b1d0:      	cinc	w13, w11, hi
    b1d4:      	sub	w14, w23, w13
    b1d8:      	subs	x12, x12, x13
    b1dc:      	str	w14, [sp, #0x68]
    b1e0:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    b1e4:      	cmp	x12, #0xfff
    b1e8:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    b1ec:      	cmp	w23, w21
    b1f0:      	b.ls	0xb1fc <generic_fentry_path+0x1f3c>
    b1f4:      	mov	w13, #0x2f              // =47
    b1f8:      	strb	w13, [x8, x12]
    b1fc:      	add	x19, x8, x12
    b200:      	cmp	w23, w21
    b204:      	add	x2, x9, x10
    b208:      	and	w1, w11, #0xff
    b20c:      	mov	w8, #0x4                // =4
    b210:      	cinc	x0, x19, hi
    b214:      	blr	x8
    b218:      	cmp	w23, w21
    b21c:      	str	x19, [sp, #0x60]
    b220:      	add	x19, sp, #0x70
    b224:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    b228:      	ldr	x21, [sp, #0x78]
    b22c:      	ldp	x2, x24, [sp, #0x50]
    b230:      	str	x21, [sp, #0x48]
    b234:      	b	0xb284 <generic_fentry_path+0x1fc4>
    b238:      	add	x2, x24, #0x10
    b23c:      	mov	w8, #0x4                // =4
    b240:      	add	x9, sp, #0x98
    b244:      	add	x0, sp, #0x98
    b248:      	mov	w1, #0x8                // =8
    b24c:      	blr	x8
    b250:      	ldr	x8, [sp, #0x58]
    b254:      	ldr	x9, [sp, #0x98]
    b258:      	cmp	x8, x9
    b25c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    b260:      	add	x2, x24, #0x18
    b264:      	mov	w8, #0x4                // =4
    b268:      	mov	x0, x22
    b26c:      	mov	w1, #0x8                // =8
    b270:      	blr	x8
    b274:      	ldr	x24, [sp, #0x98]
    b278:      	ldr	x21, [sp, #0x48]
    b27c:      	add	x2, x24, #0x20
    b280:      	stp	x2, x24, [sp, #0x50]
    b284:      	ldr	x8, [sp, #0x30]
    b288:      	cmp	x21, x8
    b28c:      	b.ne	0xb29c <generic_fentry_path+0x1fdc>
    b290:      	ldr	x8, [sp, #0x38]
    b294:      	cmp	x2, x8
    b298:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    b29c:      	mov	w8, #0x4                // =4
    b2a0:      	add	x0, sp, #0x70
    b2a4:      	mov	w1, #0x8                // =8
    b2a8:      	blr	x8
    b2ac:      	ldr	x8, [sp, #0x70]
    b2b0:      	cmp	x21, x8
    b2b4:      	b.eq	0xb3a4 <generic_fentry_path+0x20e4>
    b2b8:      	add	x23, x21, #0x18
    b2bc:      	mov	w8, #0x4                // =4
    b2c0:      	add	x9, sp, #0x98
    b2c4:      	add	x0, sp, #0x98
    b2c8:      	mov	w1, #0x8                // =8
    b2cc:      	mov	x2, x23
    b2d0:      	blr	x8
    b2d4:      	ldr	x8, [sp, #0x98]
    b2d8:      	cmp	x8, x21
    b2dc:      	b.eq	0xb3a4 <generic_fentry_path+0x20e4>
    b2e0:      	mov	w8, #0x4                // =4
    b2e4:      	add	x9, sp, #0x78
    b2e8:      	add	x0, sp, #0x78
    b2ec:      	mov	w1, #0x8                // =8
    b2f0:      	mov	x2, x23
    b2f4:      	blr	x8
    b2f8:      	add	x2, x21, #0x20
    b2fc:      	mov	w8, #0x4                // =4
    b300:      	mov	w9, #0x10               // =16
    b304:      	add	x10, sp, #0x80
    b308:      	add	x0, sp, #0x80
    b30c:      	mov	w1, #0x10               // =16
    b310:      	blr	x8
    b314:      	ldr	w21, [sp, #0x84]
    b318:      	ldr	x8, [sp, #0x40]
    b31c:      	ldr	x10, [sp, #0x60]
    b320:      	sub	x12, x10, x8
    b324:      	ldr	w23, [sp, #0x68]
    b328:      	subs	w10, w21, w23
    b32c:      	ldr	x9, [sp, #0x88]
    b330:      	csel	w10, wzr, w10, lo
    b334:      	cmp	w23, w21
    b338:      	csel	w11, w23, w21, lo
    b33c:      	cinc	w13, w11, hi
    b340:      	sub	w14, w23, w13
    b344:      	subs	x12, x12, x13
    b348:      	str	w14, [sp, #0x68]
    b34c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    b350:      	cmp	x12, #0xfff
    b354:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    b358:      	cmp	w23, w21
    b35c:      	b.ls	0xb368 <generic_fentry_path+0x20a8>
    b360:      	mov	w13, #0x2f              // =47
    b364:      	strb	w13, [x8, x12]
    b368:      	add	x19, x8, x12
    b36c:      	cmp	w23, w21
    b370:      	add	x2, x9, x10
    b374:      	and	w1, w11, #0xff
    b378:      	mov	w8, #0x4                // =4
    b37c:      	cinc	x0, x19, hi
    b380:      	blr	x8
    b384:      	cmp	w23, w21
    b388:      	str	x19, [sp, #0x60]
    b38c:      	add	x19, sp, #0x70
    b390:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    b394:      	ldr	x21, [sp, #0x78]
    b398:      	ldp	x2, x24, [sp, #0x50]
    b39c:      	str	x21, [sp, #0x48]
    b3a0:      	b	0xb3f0 <generic_fentry_path+0x2130>
    b3a4:      	add	x2, x24, #0x10
    b3a8:      	mov	w8, #0x4                // =4
    b3ac:      	add	x9, sp, #0x98
    b3b0:      	add	x0, sp, #0x98
    b3b4:      	mov	w1, #0x8                // =8
    b3b8:      	blr	x8
    b3bc:      	ldr	x8, [sp, #0x58]
    b3c0:      	ldr	x9, [sp, #0x98]
    b3c4:      	cmp	x8, x9
    b3c8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    b3cc:      	add	x2, x24, #0x18
    b3d0:      	mov	w8, #0x4                // =4
    b3d4:      	mov	x0, x22
    b3d8:      	mov	w1, #0x8                // =8
    b3dc:      	blr	x8
    b3e0:      	ldr	x24, [sp, #0x98]
    b3e4:      	ldr	x21, [sp, #0x48]
    b3e8:      	add	x2, x24, #0x20
    b3ec:      	stp	x2, x24, [sp, #0x50]
    b3f0:      	ldr	x8, [sp, #0x30]
    b3f4:      	cmp	x21, x8
    b3f8:      	b.ne	0xb408 <generic_fentry_path+0x2148>
    b3fc:      	ldr	x8, [sp, #0x38]
    b400:      	cmp	x2, x8
    b404:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    b408:      	mov	w8, #0x4                // =4
    b40c:      	add	x0, sp, #0x70
    b410:      	mov	w1, #0x8                // =8
    b414:      	blr	x8
    b418:      	ldr	x8, [sp, #0x70]
    b41c:      	cmp	x21, x8
    b420:      	b.eq	0xb510 <generic_fentry_path+0x2250>
    b424:      	add	x23, x21, #0x18
    b428:      	mov	w8, #0x4                // =4
    b42c:      	add	x9, sp, #0x98
    b430:      	add	x0, sp, #0x98
    b434:      	mov	w1, #0x8                // =8
    b438:      	mov	x2, x23
    b43c:      	blr	x8
    b440:      	ldr	x8, [sp, #0x98]
    b444:      	cmp	x8, x21
    b448:      	b.eq	0xb510 <generic_fentry_path+0x2250>
    b44c:      	mov	w8, #0x4                // =4
    b450:      	add	x9, sp, #0x78
    b454:      	add	x0, sp, #0x78
    b458:      	mov	w1, #0x8                // =8
    b45c:      	mov	x2, x23
    b460:      	blr	x8
    b464:      	add	x2, x21, #0x20
    b468:      	mov	w8, #0x4                // =4
    b46c:      	mov	w9, #0x10               // =16
    b470:      	add	x10, sp, #0x80
    b474:      	add	x0, sp, #0x80
    b478:      	mov	w1, #0x10               // =16
    b47c:      	blr	x8
    b480:      	ldr	w21, [sp, #0x84]
    b484:      	ldr	x8, [sp, #0x40]
    b488:      	ldr	x10, [sp, #0x60]
    b48c:      	sub	x12, x10, x8
    b490:      	ldr	w23, [sp, #0x68]
    b494:      	subs	w10, w21, w23
    b498:      	ldr	x9, [sp, #0x88]
    b49c:      	csel	w10, wzr, w10, lo
    b4a0:      	cmp	w23, w21
    b4a4:      	csel	w11, w23, w21, lo
    b4a8:      	cinc	w13, w11, hi
    b4ac:      	sub	w14, w23, w13
    b4b0:      	subs	x12, x12, x13
    b4b4:      	str	w14, [sp, #0x68]
    b4b8:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    b4bc:      	cmp	x12, #0xfff
    b4c0:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    b4c4:      	cmp	w23, w21
    b4c8:      	b.ls	0xb4d4 <generic_fentry_path+0x2214>
    b4cc:      	mov	w13, #0x2f              // =47
    b4d0:      	strb	w13, [x8, x12]
    b4d4:      	add	x19, x8, x12
    b4d8:      	cmp	w23, w21
    b4dc:      	add	x2, x9, x10
    b4e0:      	and	w1, w11, #0xff
    b4e4:      	mov	w8, #0x4                // =4
    b4e8:      	cinc	x0, x19, hi
    b4ec:      	blr	x8
    b4f0:      	cmp	w23, w21
    b4f4:      	str	x19, [sp, #0x60]
    b4f8:      	add	x19, sp, #0x70
    b4fc:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    b500:      	ldr	x21, [sp, #0x78]
    b504:      	ldp	x2, x24, [sp, #0x50]
    b508:      	str	x21, [sp, #0x48]
    b50c:      	b	0xb55c <generic_fentry_path+0x229c>
    b510:      	add	x2, x24, #0x10
    b514:      	mov	w8, #0x4                // =4
    b518:      	add	x9, sp, #0x98
    b51c:      	add	x0, sp, #0x98
    b520:      	mov	w1, #0x8                // =8
    b524:      	blr	x8
    b528:      	ldr	x8, [sp, #0x58]
    b52c:      	ldr	x9, [sp, #0x98]
    b530:      	cmp	x8, x9
    b534:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    b538:      	add	x2, x24, #0x18
    b53c:      	mov	w8, #0x4                // =4
    b540:      	mov	x0, x22
    b544:      	mov	w1, #0x8                // =8
    b548:      	blr	x8
    b54c:      	ldr	x24, [sp, #0x98]
    b550:      	ldr	x21, [sp, #0x48]
    b554:      	add	x2, x24, #0x20
    b558:      	stp	x2, x24, [sp, #0x50]
    b55c:      	ldr	x8, [sp, #0x30]
    b560:      	cmp	x21, x8
    b564:      	b.ne	0xb574 <generic_fentry_path+0x22b4>
    b568:      	ldr	x8, [sp, #0x38]
    b56c:      	cmp	x2, x8
    b570:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    b574:      	mov	w8, #0x4                // =4
    b578:      	add	x0, sp, #0x70
    b57c:      	mov	w1, #0x8                // =8
    b580:      	blr	x8
    b584:      	ldr	x8, [sp, #0x70]
    b588:      	cmp	x21, x8
    b58c:      	b.eq	0xb67c <generic_fentry_path+0x23bc>
    b590:      	add	x23, x21, #0x18
    b594:      	mov	w8, #0x4                // =4
    b598:      	add	x9, sp, #0x98
    b59c:      	add	x0, sp, #0x98
    b5a0:      	mov	w1, #0x8                // =8
    b5a4:      	mov	x2, x23
    b5a8:      	blr	x8
    b5ac:      	ldr	x8, [sp, #0x98]
    b5b0:      	cmp	x8, x21
    b5b4:      	b.eq	0xb67c <generic_fentry_path+0x23bc>
    b5b8:      	mov	w8, #0x4                // =4
    b5bc:      	add	x9, sp, #0x78
    b5c0:      	add	x0, sp, #0x78
    b5c4:      	mov	w1, #0x8                // =8
    b5c8:      	mov	x2, x23
    b5cc:      	blr	x8
    b5d0:      	add	x2, x21, #0x20
    b5d4:      	mov	w8, #0x4                // =4
    b5d8:      	mov	w9, #0x10               // =16
    b5dc:      	add	x10, sp, #0x80
    b5e0:      	add	x0, sp, #0x80
    b5e4:      	mov	w1, #0x10               // =16
    b5e8:      	blr	x8
    b5ec:      	ldr	w21, [sp, #0x84]
    b5f0:      	ldr	x8, [sp, #0x40]
    b5f4:      	ldr	x10, [sp, #0x60]
    b5f8:      	sub	x12, x10, x8
    b5fc:      	ldr	w23, [sp, #0x68]
    b600:      	subs	w10, w21, w23
    b604:      	ldr	x9, [sp, #0x88]
    b608:      	csel	w10, wzr, w10, lo
    b60c:      	cmp	w23, w21
    b610:      	csel	w11, w23, w21, lo
    b614:      	cinc	w13, w11, hi
    b618:      	sub	w14, w23, w13
    b61c:      	subs	x12, x12, x13
    b620:      	str	w14, [sp, #0x68]
    b624:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    b628:      	cmp	x12, #0xfff
    b62c:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    b630:      	cmp	w23, w21
    b634:      	b.ls	0xb640 <generic_fentry_path+0x2380>
    b638:      	mov	w13, #0x2f              // =47
    b63c:      	strb	w13, [x8, x12]
    b640:      	add	x19, x8, x12
    b644:      	cmp	w23, w21
    b648:      	add	x2, x9, x10
    b64c:      	and	w1, w11, #0xff
    b650:      	mov	w8, #0x4                // =4
    b654:      	cinc	x0, x19, hi
    b658:      	blr	x8
    b65c:      	cmp	w23, w21
    b660:      	str	x19, [sp, #0x60]
    b664:      	add	x19, sp, #0x70
    b668:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    b66c:      	ldr	x21, [sp, #0x78]
    b670:      	ldp	x2, x24, [sp, #0x50]
    b674:      	str	x21, [sp, #0x48]
    b678:      	b	0xb6c8 <generic_fentry_path+0x2408>
    b67c:      	add	x2, x24, #0x10
    b680:      	mov	w8, #0x4                // =4
    b684:      	add	x9, sp, #0x98
    b688:      	add	x0, sp, #0x98
    b68c:      	mov	w1, #0x8                // =8
    b690:      	blr	x8
    b694:      	ldr	x8, [sp, #0x58]
    b698:      	ldr	x9, [sp, #0x98]
    b69c:      	cmp	x8, x9
    b6a0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    b6a4:      	add	x2, x24, #0x18
    b6a8:      	mov	w8, #0x4                // =4
    b6ac:      	mov	x0, x22
    b6b0:      	mov	w1, #0x8                // =8
    b6b4:      	blr	x8
    b6b8:      	ldr	x24, [sp, #0x98]
    b6bc:      	ldr	x21, [sp, #0x48]
    b6c0:      	add	x2, x24, #0x20
    b6c4:      	stp	x2, x24, [sp, #0x50]
    b6c8:      	ldr	x8, [sp, #0x30]
    b6cc:      	cmp	x21, x8
    b6d0:      	b.ne	0xb6e0 <generic_fentry_path+0x2420>
    b6d4:      	ldr	x8, [sp, #0x38]
    b6d8:      	cmp	x2, x8
    b6dc:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    b6e0:      	mov	w8, #0x4                // =4
    b6e4:      	add	x0, sp, #0x70
    b6e8:      	mov	w1, #0x8                // =8
    b6ec:      	blr	x8
    b6f0:      	ldr	x8, [sp, #0x70]
    b6f4:      	cmp	x21, x8
    b6f8:      	b.eq	0xb7e8 <generic_fentry_path+0x2528>
    b6fc:      	add	x23, x21, #0x18
    b700:      	mov	w8, #0x4                // =4
    b704:      	add	x9, sp, #0x98
    b708:      	add	x0, sp, #0x98
    b70c:      	mov	w1, #0x8                // =8
    b710:      	mov	x2, x23
    b714:      	blr	x8
    b718:      	ldr	x8, [sp, #0x98]
    b71c:      	cmp	x8, x21
    b720:      	b.eq	0xb7e8 <generic_fentry_path+0x2528>
    b724:      	mov	w8, #0x4                // =4
    b728:      	add	x9, sp, #0x78
    b72c:      	add	x0, sp, #0x78
    b730:      	mov	w1, #0x8                // =8
    b734:      	mov	x2, x23
    b738:      	blr	x8
    b73c:      	add	x2, x21, #0x20
    b740:      	mov	w8, #0x4                // =4
    b744:      	mov	w9, #0x10               // =16
    b748:      	add	x10, sp, #0x80
    b74c:      	add	x0, sp, #0x80
    b750:      	mov	w1, #0x10               // =16
    b754:      	blr	x8
    b758:      	ldr	w21, [sp, #0x84]
    b75c:      	ldr	x8, [sp, #0x40]
    b760:      	ldr	x10, [sp, #0x60]
    b764:      	sub	x12, x10, x8
    b768:      	ldr	w23, [sp, #0x68]
    b76c:      	subs	w10, w21, w23
    b770:      	ldr	x9, [sp, #0x88]
    b774:      	csel	w10, wzr, w10, lo
    b778:      	cmp	w23, w21
    b77c:      	csel	w11, w23, w21, lo
    b780:      	cinc	w13, w11, hi
    b784:      	sub	w14, w23, w13
    b788:      	subs	x12, x12, x13
    b78c:      	str	w14, [sp, #0x68]
    b790:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    b794:      	cmp	x12, #0xfff
    b798:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    b79c:      	cmp	w23, w21
    b7a0:      	b.ls	0xb7ac <generic_fentry_path+0x24ec>
    b7a4:      	mov	w13, #0x2f              // =47
    b7a8:      	strb	w13, [x8, x12]
    b7ac:      	add	x19, x8, x12
    b7b0:      	cmp	w23, w21
    b7b4:      	add	x2, x9, x10
    b7b8:      	and	w1, w11, #0xff
    b7bc:      	mov	w8, #0x4                // =4
    b7c0:      	cinc	x0, x19, hi
    b7c4:      	blr	x8
    b7c8:      	cmp	w23, w21
    b7cc:      	str	x19, [sp, #0x60]
    b7d0:      	add	x19, sp, #0x70
    b7d4:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    b7d8:      	ldr	x21, [sp, #0x78]
    b7dc:      	ldp	x2, x24, [sp, #0x50]
    b7e0:      	str	x21, [sp, #0x48]
    b7e4:      	b	0xb834 <generic_fentry_path+0x2574>
    b7e8:      	add	x2, x24, #0x10
    b7ec:      	mov	w8, #0x4                // =4
    b7f0:      	add	x9, sp, #0x98
    b7f4:      	add	x0, sp, #0x98
    b7f8:      	mov	w1, #0x8                // =8
    b7fc:      	blr	x8
    b800:      	ldr	x8, [sp, #0x58]
    b804:      	ldr	x9, [sp, #0x98]
    b808:      	cmp	x8, x9
    b80c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    b810:      	add	x2, x24, #0x18
    b814:      	mov	w8, #0x4                // =4
    b818:      	mov	x0, x22
    b81c:      	mov	w1, #0x8                // =8
    b820:      	blr	x8
    b824:      	ldr	x24, [sp, #0x98]
    b828:      	ldr	x21, [sp, #0x48]
    b82c:      	add	x2, x24, #0x20
    b830:      	stp	x2, x24, [sp, #0x50]
    b834:      	ldr	x8, [sp, #0x30]
    b838:      	cmp	x21, x8
    b83c:      	b.ne	0xb84c <generic_fentry_path+0x258c>
    b840:      	ldr	x8, [sp, #0x38]
    b844:      	cmp	x2, x8
    b848:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    b84c:      	mov	w8, #0x4                // =4
    b850:      	add	x0, sp, #0x70
    b854:      	mov	w1, #0x8                // =8
    b858:      	blr	x8
    b85c:      	ldr	x8, [sp, #0x70]
    b860:      	cmp	x21, x8
    b864:      	b.eq	0xb954 <generic_fentry_path+0x2694>
    b868:      	add	x23, x21, #0x18
    b86c:      	mov	w8, #0x4                // =4
    b870:      	add	x9, sp, #0x98
    b874:      	add	x0, sp, #0x98
    b878:      	mov	w1, #0x8                // =8
    b87c:      	mov	x2, x23
    b880:      	blr	x8
    b884:      	ldr	x8, [sp, #0x98]
    b888:      	cmp	x8, x21
    b88c:      	b.eq	0xb954 <generic_fentry_path+0x2694>
    b890:      	mov	w8, #0x4                // =4
    b894:      	add	x9, sp, #0x78
    b898:      	add	x0, sp, #0x78
    b89c:      	mov	w1, #0x8                // =8
    b8a0:      	mov	x2, x23
    b8a4:      	blr	x8
    b8a8:      	add	x2, x21, #0x20
    b8ac:      	mov	w8, #0x4                // =4
    b8b0:      	mov	w9, #0x10               // =16
    b8b4:      	add	x10, sp, #0x80
    b8b8:      	add	x0, sp, #0x80
    b8bc:      	mov	w1, #0x10               // =16
    b8c0:      	blr	x8
    b8c4:      	ldr	w21, [sp, #0x84]
    b8c8:      	ldr	x8, [sp, #0x40]
    b8cc:      	ldr	x10, [sp, #0x60]
    b8d0:      	sub	x12, x10, x8
    b8d4:      	ldr	w23, [sp, #0x68]
    b8d8:      	subs	w10, w21, w23
    b8dc:      	ldr	x9, [sp, #0x88]
    b8e0:      	csel	w10, wzr, w10, lo
    b8e4:      	cmp	w23, w21
    b8e8:      	csel	w11, w23, w21, lo
    b8ec:      	cinc	w13, w11, hi
    b8f0:      	sub	w14, w23, w13
    b8f4:      	subs	x12, x12, x13
    b8f8:      	str	w14, [sp, #0x68]
    b8fc:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    b900:      	cmp	x12, #0xfff
    b904:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    b908:      	cmp	w23, w21
    b90c:      	b.ls	0xb918 <generic_fentry_path+0x2658>
    b910:      	mov	w13, #0x2f              // =47
    b914:      	strb	w13, [x8, x12]
    b918:      	add	x19, x8, x12
    b91c:      	cmp	w23, w21
    b920:      	add	x2, x9, x10
    b924:      	and	w1, w11, #0xff
    b928:      	mov	w8, #0x4                // =4
    b92c:      	cinc	x0, x19, hi
    b930:      	blr	x8
    b934:      	cmp	w23, w21
    b938:      	str	x19, [sp, #0x60]
    b93c:      	add	x19, sp, #0x70
    b940:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    b944:      	ldr	x21, [sp, #0x78]
    b948:      	ldp	x2, x24, [sp, #0x50]
    b94c:      	str	x21, [sp, #0x48]
    b950:      	b	0xb9a0 <generic_fentry_path+0x26e0>
    b954:      	add	x2, x24, #0x10
    b958:      	mov	w8, #0x4                // =4
    b95c:      	add	x9, sp, #0x98
    b960:      	add	x0, sp, #0x98
    b964:      	mov	w1, #0x8                // =8
    b968:      	blr	x8
    b96c:      	ldr	x8, [sp, #0x58]
    b970:      	ldr	x9, [sp, #0x98]
    b974:      	cmp	x8, x9
    b978:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    b97c:      	add	x2, x24, #0x18
    b980:      	mov	w8, #0x4                // =4
    b984:      	mov	x0, x22
    b988:      	mov	w1, #0x8                // =8
    b98c:      	blr	x8
    b990:      	ldr	x24, [sp, #0x98]
    b994:      	ldr	x21, [sp, #0x48]
    b998:      	add	x2, x24, #0x20
    b99c:      	stp	x2, x24, [sp, #0x50]
    b9a0:      	ldr	x8, [sp, #0x30]
    b9a4:      	cmp	x21, x8
    b9a8:      	b.ne	0xb9b8 <generic_fentry_path+0x26f8>
    b9ac:      	ldr	x8, [sp, #0x38]
    b9b0:      	cmp	x2, x8
    b9b4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    b9b8:      	mov	w8, #0x4                // =4
    b9bc:      	add	x0, sp, #0x70
    b9c0:      	mov	w1, #0x8                // =8
    b9c4:      	blr	x8
    b9c8:      	ldr	x8, [sp, #0x70]
    b9cc:      	cmp	x21, x8
    b9d0:      	b.eq	0xbac0 <generic_fentry_path+0x2800>
    b9d4:      	add	x23, x21, #0x18
    b9d8:      	mov	w8, #0x4                // =4
    b9dc:      	add	x9, sp, #0x98
    b9e0:      	add	x0, sp, #0x98
    b9e4:      	mov	w1, #0x8                // =8
    b9e8:      	mov	x2, x23
    b9ec:      	blr	x8
    b9f0:      	ldr	x8, [sp, #0x98]
    b9f4:      	cmp	x8, x21
    b9f8:      	b.eq	0xbac0 <generic_fentry_path+0x2800>
    b9fc:      	mov	w8, #0x4                // =4
    ba00:      	add	x9, sp, #0x78
    ba04:      	add	x0, sp, #0x78
    ba08:      	mov	w1, #0x8                // =8
    ba0c:      	mov	x2, x23
    ba10:      	blr	x8
    ba14:      	add	x2, x21, #0x20
    ba18:      	mov	w8, #0x4                // =4
    ba1c:      	mov	w9, #0x10               // =16
    ba20:      	add	x10, sp, #0x80
    ba24:      	add	x0, sp, #0x80
    ba28:      	mov	w1, #0x10               // =16
    ba2c:      	blr	x8
    ba30:      	ldr	w21, [sp, #0x84]
    ba34:      	ldr	x8, [sp, #0x40]
    ba38:      	ldr	x10, [sp, #0x60]
    ba3c:      	sub	x12, x10, x8
    ba40:      	ldr	w23, [sp, #0x68]
    ba44:      	subs	w10, w21, w23
    ba48:      	ldr	x9, [sp, #0x88]
    ba4c:      	csel	w10, wzr, w10, lo
    ba50:      	cmp	w23, w21
    ba54:      	csel	w11, w23, w21, lo
    ba58:      	cinc	w13, w11, hi
    ba5c:      	sub	w14, w23, w13
    ba60:      	subs	x12, x12, x13
    ba64:      	str	w14, [sp, #0x68]
    ba68:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    ba6c:      	cmp	x12, #0xfff
    ba70:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    ba74:      	cmp	w23, w21
    ba78:      	b.ls	0xba84 <generic_fentry_path+0x27c4>
    ba7c:      	mov	w13, #0x2f              // =47
    ba80:      	strb	w13, [x8, x12]
    ba84:      	add	x19, x8, x12
    ba88:      	cmp	w23, w21
    ba8c:      	add	x2, x9, x10
    ba90:      	and	w1, w11, #0xff
    ba94:      	mov	w8, #0x4                // =4
    ba98:      	cinc	x0, x19, hi
    ba9c:      	blr	x8
    baa0:      	cmp	w23, w21
    baa4:      	str	x19, [sp, #0x60]
    baa8:      	add	x19, sp, #0x70
    baac:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    bab0:      	ldr	x21, [sp, #0x78]
    bab4:      	ldp	x2, x24, [sp, #0x50]
    bab8:      	str	x21, [sp, #0x48]
    babc:      	b	0xbb0c <generic_fentry_path+0x284c>
    bac0:      	add	x2, x24, #0x10
    bac4:      	mov	w8, #0x4                // =4
    bac8:      	add	x9, sp, #0x98
    bacc:      	add	x0, sp, #0x98
    bad0:      	mov	w1, #0x8                // =8
    bad4:      	blr	x8
    bad8:      	ldr	x8, [sp, #0x58]
    badc:      	ldr	x9, [sp, #0x98]
    bae0:      	cmp	x8, x9
    bae4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    bae8:      	add	x2, x24, #0x18
    baec:      	mov	w8, #0x4                // =4
    baf0:      	mov	x0, x22
    baf4:      	mov	w1, #0x8                // =8
    baf8:      	blr	x8
    bafc:      	ldr	x24, [sp, #0x98]
    bb00:      	ldr	x21, [sp, #0x48]
    bb04:      	add	x2, x24, #0x20
    bb08:      	stp	x2, x24, [sp, #0x50]
    bb0c:      	ldr	x8, [sp, #0x30]
    bb10:      	cmp	x21, x8
    bb14:      	b.ne	0xbb24 <generic_fentry_path+0x2864>
    bb18:      	ldr	x8, [sp, #0x38]
    bb1c:      	cmp	x2, x8
    bb20:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    bb24:      	mov	w8, #0x4                // =4
    bb28:      	add	x0, sp, #0x70
    bb2c:      	mov	w1, #0x8                // =8
    bb30:      	blr	x8
    bb34:      	ldr	x8, [sp, #0x70]
    bb38:      	cmp	x21, x8
    bb3c:      	b.eq	0xbc2c <generic_fentry_path+0x296c>
    bb40:      	add	x23, x21, #0x18
    bb44:      	mov	w8, #0x4                // =4
    bb48:      	add	x9, sp, #0x98
    bb4c:      	add	x0, sp, #0x98
    bb50:      	mov	w1, #0x8                // =8
    bb54:      	mov	x2, x23
    bb58:      	blr	x8
    bb5c:      	ldr	x8, [sp, #0x98]
    bb60:      	cmp	x8, x21
    bb64:      	b.eq	0xbc2c <generic_fentry_path+0x296c>
    bb68:      	mov	w8, #0x4                // =4
    bb6c:      	add	x9, sp, #0x78
    bb70:      	add	x0, sp, #0x78
    bb74:      	mov	w1, #0x8                // =8
    bb78:      	mov	x2, x23
    bb7c:      	blr	x8
    bb80:      	add	x2, x21, #0x20
    bb84:      	mov	w8, #0x4                // =4
    bb88:      	mov	w9, #0x10               // =16
    bb8c:      	add	x10, sp, #0x80
    bb90:      	add	x0, sp, #0x80
    bb94:      	mov	w1, #0x10               // =16
    bb98:      	blr	x8
    bb9c:      	ldr	w21, [sp, #0x84]
    bba0:      	ldr	x8, [sp, #0x40]
    bba4:      	ldr	x10, [sp, #0x60]
    bba8:      	sub	x12, x10, x8
    bbac:      	ldr	w23, [sp, #0x68]
    bbb0:      	subs	w10, w21, w23
    bbb4:      	ldr	x9, [sp, #0x88]
    bbb8:      	csel	w10, wzr, w10, lo
    bbbc:      	cmp	w23, w21
    bbc0:      	csel	w11, w23, w21, lo
    bbc4:      	cinc	w13, w11, hi
    bbc8:      	sub	w14, w23, w13
    bbcc:      	subs	x12, x12, x13
    bbd0:      	str	w14, [sp, #0x68]
    bbd4:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    bbd8:      	cmp	x12, #0xfff
    bbdc:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    bbe0:      	cmp	w23, w21
    bbe4:      	b.ls	0xbbf0 <generic_fentry_path+0x2930>
    bbe8:      	mov	w13, #0x2f              // =47
    bbec:      	strb	w13, [x8, x12]
    bbf0:      	add	x19, x8, x12
    bbf4:      	cmp	w23, w21
    bbf8:      	add	x2, x9, x10
    bbfc:      	and	w1, w11, #0xff
    bc00:      	mov	w8, #0x4                // =4
    bc04:      	cinc	x0, x19, hi
    bc08:      	blr	x8
    bc0c:      	cmp	w23, w21
    bc10:      	str	x19, [sp, #0x60]
    bc14:      	add	x19, sp, #0x70
    bc18:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    bc1c:      	ldr	x21, [sp, #0x78]
    bc20:      	ldp	x2, x24, [sp, #0x50]
    bc24:      	str	x21, [sp, #0x48]
    bc28:      	b	0xbc78 <generic_fentry_path+0x29b8>
    bc2c:      	add	x2, x24, #0x10
    bc30:      	mov	w8, #0x4                // =4
    bc34:      	add	x9, sp, #0x98
    bc38:      	add	x0, sp, #0x98
    bc3c:      	mov	w1, #0x8                // =8
    bc40:      	blr	x8
    bc44:      	ldr	x8, [sp, #0x58]
    bc48:      	ldr	x9, [sp, #0x98]
    bc4c:      	cmp	x8, x9
    bc50:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    bc54:      	add	x2, x24, #0x18
    bc58:      	mov	w8, #0x4                // =4
    bc5c:      	mov	x0, x22
    bc60:      	mov	w1, #0x8                // =8
    bc64:      	blr	x8
    bc68:      	ldr	x24, [sp, #0x98]
    bc6c:      	ldr	x21, [sp, #0x48]
    bc70:      	add	x2, x24, #0x20
    bc74:      	stp	x2, x24, [sp, #0x50]
    bc78:      	ldr	x8, [sp, #0x30]
    bc7c:      	cmp	x21, x8
    bc80:      	b.ne	0xbc90 <generic_fentry_path+0x29d0>
    bc84:      	ldr	x8, [sp, #0x38]
    bc88:      	cmp	x2, x8
    bc8c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    bc90:      	mov	w8, #0x4                // =4
    bc94:      	add	x0, sp, #0x70
    bc98:      	mov	w1, #0x8                // =8
    bc9c:      	blr	x8
    bca0:      	ldr	x8, [sp, #0x70]
    bca4:      	cmp	x21, x8
    bca8:      	b.eq	0xbd98 <generic_fentry_path+0x2ad8>
    bcac:      	add	x23, x21, #0x18
    bcb0:      	mov	w8, #0x4                // =4
    bcb4:      	add	x9, sp, #0x98
    bcb8:      	add	x0, sp, #0x98
    bcbc:      	mov	w1, #0x8                // =8
    bcc0:      	mov	x2, x23
    bcc4:      	blr	x8
    bcc8:      	ldr	x8, [sp, #0x98]
    bccc:      	cmp	x8, x21
    bcd0:      	b.eq	0xbd98 <generic_fentry_path+0x2ad8>
    bcd4:      	mov	w8, #0x4                // =4
    bcd8:      	add	x9, sp, #0x78
    bcdc:      	add	x0, sp, #0x78
    bce0:      	mov	w1, #0x8                // =8
    bce4:      	mov	x2, x23
    bce8:      	blr	x8
    bcec:      	add	x2, x21, #0x20
    bcf0:      	mov	w8, #0x4                // =4
    bcf4:      	mov	w9, #0x10               // =16
    bcf8:      	add	x10, sp, #0x80
    bcfc:      	add	x0, sp, #0x80
    bd00:      	mov	w1, #0x10               // =16
    bd04:      	blr	x8
    bd08:      	ldr	w21, [sp, #0x84]
    bd0c:      	ldr	x8, [sp, #0x40]
    bd10:      	ldr	x10, [sp, #0x60]
    bd14:      	sub	x12, x10, x8
    bd18:      	ldr	w23, [sp, #0x68]
    bd1c:      	subs	w10, w21, w23
    bd20:      	ldr	x9, [sp, #0x88]
    bd24:      	csel	w10, wzr, w10, lo
    bd28:      	cmp	w23, w21
    bd2c:      	csel	w11, w23, w21, lo
    bd30:      	cinc	w13, w11, hi
    bd34:      	sub	w14, w23, w13
    bd38:      	subs	x12, x12, x13
    bd3c:      	str	w14, [sp, #0x68]
    bd40:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    bd44:      	cmp	x12, #0xfff
    bd48:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    bd4c:      	cmp	w23, w21
    bd50:      	b.ls	0xbd5c <generic_fentry_path+0x2a9c>
    bd54:      	mov	w13, #0x2f              // =47
    bd58:      	strb	w13, [x8, x12]
    bd5c:      	add	x19, x8, x12
    bd60:      	cmp	w23, w21
    bd64:      	add	x2, x9, x10
    bd68:      	and	w1, w11, #0xff
    bd6c:      	mov	w8, #0x4                // =4
    bd70:      	cinc	x0, x19, hi
    bd74:      	blr	x8
    bd78:      	cmp	w23, w21
    bd7c:      	str	x19, [sp, #0x60]
    bd80:      	add	x19, sp, #0x70
    bd84:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    bd88:      	ldr	x21, [sp, #0x78]
    bd8c:      	ldp	x2, x24, [sp, #0x50]
    bd90:      	str	x21, [sp, #0x48]
    bd94:      	b	0xbde4 <generic_fentry_path+0x2b24>
    bd98:      	add	x2, x24, #0x10
    bd9c:      	mov	w8, #0x4                // =4
    bda0:      	add	x9, sp, #0x98
    bda4:      	add	x0, sp, #0x98
    bda8:      	mov	w1, #0x8                // =8
    bdac:      	blr	x8
    bdb0:      	ldr	x8, [sp, #0x58]
    bdb4:      	ldr	x9, [sp, #0x98]
    bdb8:      	cmp	x8, x9
    bdbc:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    bdc0:      	add	x2, x24, #0x18
    bdc4:      	mov	w8, #0x4                // =4
    bdc8:      	mov	x0, x22
    bdcc:      	mov	w1, #0x8                // =8
    bdd0:      	blr	x8
    bdd4:      	ldr	x24, [sp, #0x98]
    bdd8:      	ldr	x21, [sp, #0x48]
    bddc:      	add	x2, x24, #0x20
    bde0:      	stp	x2, x24, [sp, #0x50]
    bde4:      	ldr	x8, [sp, #0x30]
    bde8:      	cmp	x21, x8
    bdec:      	b.ne	0xbdfc <generic_fentry_path+0x2b3c>
    bdf0:      	ldr	x8, [sp, #0x38]
    bdf4:      	cmp	x2, x8
    bdf8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    bdfc:      	mov	w8, #0x4                // =4
    be00:      	add	x0, sp, #0x70
    be04:      	mov	w1, #0x8                // =8
    be08:      	blr	x8
    be0c:      	ldr	x8, [sp, #0x70]
    be10:      	cmp	x21, x8
    be14:      	b.eq	0xbf04 <generic_fentry_path+0x2c44>
    be18:      	add	x23, x21, #0x18
    be1c:      	mov	w8, #0x4                // =4
    be20:      	add	x9, sp, #0x98
    be24:      	add	x0, sp, #0x98
    be28:      	mov	w1, #0x8                // =8
    be2c:      	mov	x2, x23
    be30:      	blr	x8
    be34:      	ldr	x8, [sp, #0x98]
    be38:      	cmp	x8, x21
    be3c:      	b.eq	0xbf04 <generic_fentry_path+0x2c44>
    be40:      	mov	w8, #0x4                // =4
    be44:      	add	x9, sp, #0x78
    be48:      	add	x0, sp, #0x78
    be4c:      	mov	w1, #0x8                // =8
    be50:      	mov	x2, x23
    be54:      	blr	x8
    be58:      	add	x2, x21, #0x20
    be5c:      	mov	w8, #0x4                // =4
    be60:      	mov	w9, #0x10               // =16
    be64:      	add	x10, sp, #0x80
    be68:      	add	x0, sp, #0x80
    be6c:      	mov	w1, #0x10               // =16
    be70:      	blr	x8
    be74:      	ldr	w21, [sp, #0x84]
    be78:      	ldr	x8, [sp, #0x40]
    be7c:      	ldr	x10, [sp, #0x60]
    be80:      	sub	x12, x10, x8
    be84:      	ldr	w23, [sp, #0x68]
    be88:      	subs	w10, w21, w23
    be8c:      	ldr	x9, [sp, #0x88]
    be90:      	csel	w10, wzr, w10, lo
    be94:      	cmp	w23, w21
    be98:      	csel	w11, w23, w21, lo
    be9c:      	cinc	w13, w11, hi
    bea0:      	sub	w14, w23, w13
    bea4:      	subs	x12, x12, x13
    bea8:      	str	w14, [sp, #0x68]
    beac:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    beb0:      	cmp	x12, #0xfff
    beb4:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    beb8:      	cmp	w23, w21
    bebc:      	b.ls	0xbec8 <generic_fentry_path+0x2c08>
    bec0:      	mov	w13, #0x2f              // =47
    bec4:      	strb	w13, [x8, x12]
    bec8:      	add	x19, x8, x12
    becc:      	cmp	w23, w21
    bed0:      	add	x2, x9, x10
    bed4:      	and	w1, w11, #0xff
    bed8:      	mov	w8, #0x4                // =4
    bedc:      	cinc	x0, x19, hi
    bee0:      	blr	x8
    bee4:      	cmp	w23, w21
    bee8:      	str	x19, [sp, #0x60]
    beec:      	add	x19, sp, #0x70
    bef0:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    bef4:      	ldr	x21, [sp, #0x78]
    bef8:      	ldp	x2, x24, [sp, #0x50]
    befc:      	str	x21, [sp, #0x48]
    bf00:      	b	0xbf50 <generic_fentry_path+0x2c90>
    bf04:      	add	x2, x24, #0x10
    bf08:      	mov	w8, #0x4                // =4
    bf0c:      	add	x9, sp, #0x98
    bf10:      	add	x0, sp, #0x98
    bf14:      	mov	w1, #0x8                // =8
    bf18:      	blr	x8
    bf1c:      	ldr	x8, [sp, #0x58]
    bf20:      	ldr	x9, [sp, #0x98]
    bf24:      	cmp	x8, x9
    bf28:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    bf2c:      	add	x2, x24, #0x18
    bf30:      	mov	w8, #0x4                // =4
    bf34:      	mov	x0, x22
    bf38:      	mov	w1, #0x8                // =8
    bf3c:      	blr	x8
    bf40:      	ldr	x24, [sp, #0x98]
    bf44:      	ldr	x21, [sp, #0x48]
    bf48:      	add	x2, x24, #0x20
    bf4c:      	stp	x2, x24, [sp, #0x50]
    bf50:      	ldr	x8, [sp, #0x30]
    bf54:      	cmp	x21, x8
    bf58:      	b.ne	0xbf68 <generic_fentry_path+0x2ca8>
    bf5c:      	ldr	x8, [sp, #0x38]
    bf60:      	cmp	x2, x8
    bf64:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    bf68:      	mov	w8, #0x4                // =4
    bf6c:      	add	x0, sp, #0x70
    bf70:      	mov	w1, #0x8                // =8
    bf74:      	blr	x8
    bf78:      	ldr	x8, [sp, #0x70]
    bf7c:      	cmp	x21, x8
    bf80:      	b.eq	0xc070 <generic_fentry_path+0x2db0>
    bf84:      	add	x23, x21, #0x18
    bf88:      	mov	w8, #0x4                // =4
    bf8c:      	add	x9, sp, #0x98
    bf90:      	add	x0, sp, #0x98
    bf94:      	mov	w1, #0x8                // =8
    bf98:      	mov	x2, x23
    bf9c:      	blr	x8
    bfa0:      	ldr	x8, [sp, #0x98]
    bfa4:      	cmp	x8, x21
    bfa8:      	b.eq	0xc070 <generic_fentry_path+0x2db0>
    bfac:      	mov	w8, #0x4                // =4
    bfb0:      	add	x9, sp, #0x78
    bfb4:      	add	x0, sp, #0x78
    bfb8:      	mov	w1, #0x8                // =8
    bfbc:      	mov	x2, x23
    bfc0:      	blr	x8
    bfc4:      	add	x2, x21, #0x20
    bfc8:      	mov	w8, #0x4                // =4
    bfcc:      	mov	w9, #0x10               // =16
    bfd0:      	add	x10, sp, #0x80
    bfd4:      	add	x0, sp, #0x80
    bfd8:      	mov	w1, #0x10               // =16
    bfdc:      	blr	x8
    bfe0:      	ldr	w21, [sp, #0x84]
    bfe4:      	ldr	x8, [sp, #0x40]
    bfe8:      	ldr	x10, [sp, #0x60]
    bfec:      	sub	x12, x10, x8
    bff0:      	ldr	w23, [sp, #0x68]
    bff4:      	subs	w10, w21, w23
    bff8:      	ldr	x9, [sp, #0x88]
    bffc:      	csel	w10, wzr, w10, lo
    c000:      	cmp	w23, w21
    c004:      	csel	w11, w23, w21, lo
    c008:      	cinc	w13, w11, hi
    c00c:      	sub	w14, w23, w13
    c010:      	subs	x12, x12, x13
    c014:      	str	w14, [sp, #0x68]
    c018:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    c01c:      	cmp	x12, #0xfff
    c020:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    c024:      	cmp	w23, w21
    c028:      	b.ls	0xc034 <generic_fentry_path+0x2d74>
    c02c:      	mov	w13, #0x2f              // =47
    c030:      	strb	w13, [x8, x12]
    c034:      	add	x19, x8, x12
    c038:      	cmp	w23, w21
    c03c:      	add	x2, x9, x10
    c040:      	and	w1, w11, #0xff
    c044:      	mov	w8, #0x4                // =4
    c048:      	cinc	x0, x19, hi
    c04c:      	blr	x8
    c050:      	cmp	w23, w21
    c054:      	str	x19, [sp, #0x60]
    c058:      	add	x19, sp, #0x70
    c05c:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    c060:      	ldr	x21, [sp, #0x78]
    c064:      	ldp	x2, x24, [sp, #0x50]
    c068:      	str	x21, [sp, #0x48]
    c06c:      	b	0xc0bc <generic_fentry_path+0x2dfc>
    c070:      	add	x2, x24, #0x10
    c074:      	mov	w8, #0x4                // =4
    c078:      	add	x9, sp, #0x98
    c07c:      	add	x0, sp, #0x98
    c080:      	mov	w1, #0x8                // =8
    c084:      	blr	x8
    c088:      	ldr	x8, [sp, #0x58]
    c08c:      	ldr	x9, [sp, #0x98]
    c090:      	cmp	x8, x9
    c094:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    c098:      	add	x2, x24, #0x18
    c09c:      	mov	w8, #0x4                // =4
    c0a0:      	mov	x0, x22
    c0a4:      	mov	w1, #0x8                // =8
    c0a8:      	blr	x8
    c0ac:      	ldr	x24, [sp, #0x98]
    c0b0:      	ldr	x21, [sp, #0x48]
    c0b4:      	add	x2, x24, #0x20
    c0b8:      	stp	x2, x24, [sp, #0x50]
    c0bc:      	ldr	x8, [sp, #0x30]
    c0c0:      	cmp	x21, x8
    c0c4:      	b.ne	0xc0d4 <generic_fentry_path+0x2e14>
    c0c8:      	ldr	x8, [sp, #0x38]
    c0cc:      	cmp	x2, x8
    c0d0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    c0d4:      	mov	w8, #0x4                // =4
    c0d8:      	add	x0, sp, #0x70
    c0dc:      	mov	w1, #0x8                // =8
    c0e0:      	blr	x8
    c0e4:      	ldr	x8, [sp, #0x70]
    c0e8:      	cmp	x21, x8
    c0ec:      	b.eq	0xc1dc <generic_fentry_path+0x2f1c>
    c0f0:      	add	x23, x21, #0x18
    c0f4:      	mov	w8, #0x4                // =4
    c0f8:      	add	x9, sp, #0x98
    c0fc:      	add	x0, sp, #0x98
    c100:      	mov	w1, #0x8                // =8
    c104:      	mov	x2, x23
    c108:      	blr	x8
    c10c:      	ldr	x8, [sp, #0x98]
    c110:      	cmp	x8, x21
    c114:      	b.eq	0xc1dc <generic_fentry_path+0x2f1c>
    c118:      	mov	w8, #0x4                // =4
    c11c:      	add	x9, sp, #0x78
    c120:      	add	x0, sp, #0x78
    c124:      	mov	w1, #0x8                // =8
    c128:      	mov	x2, x23
    c12c:      	blr	x8
    c130:      	add	x2, x21, #0x20
    c134:      	mov	w8, #0x4                // =4
    c138:      	mov	w9, #0x10               // =16
    c13c:      	add	x10, sp, #0x80
    c140:      	add	x0, sp, #0x80
    c144:      	mov	w1, #0x10               // =16
    c148:      	blr	x8
    c14c:      	ldr	w21, [sp, #0x84]
    c150:      	ldr	x8, [sp, #0x40]
    c154:      	ldr	x10, [sp, #0x60]
    c158:      	sub	x12, x10, x8
    c15c:      	ldr	w23, [sp, #0x68]
    c160:      	subs	w10, w21, w23
    c164:      	ldr	x9, [sp, #0x88]
    c168:      	csel	w10, wzr, w10, lo
    c16c:      	cmp	w23, w21
    c170:      	csel	w11, w23, w21, lo
    c174:      	cinc	w13, w11, hi
    c178:      	sub	w14, w23, w13
    c17c:      	subs	x12, x12, x13
    c180:      	str	w14, [sp, #0x68]
    c184:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    c188:      	cmp	x12, #0xfff
    c18c:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    c190:      	cmp	w23, w21
    c194:      	b.ls	0xc1a0 <generic_fentry_path+0x2ee0>
    c198:      	mov	w13, #0x2f              // =47
    c19c:      	strb	w13, [x8, x12]
    c1a0:      	add	x19, x8, x12
    c1a4:      	cmp	w23, w21
    c1a8:      	add	x2, x9, x10
    c1ac:      	and	w1, w11, #0xff
    c1b0:      	mov	w8, #0x4                // =4
    c1b4:      	cinc	x0, x19, hi
    c1b8:      	blr	x8
    c1bc:      	cmp	w23, w21
    c1c0:      	str	x19, [sp, #0x60]
    c1c4:      	add	x19, sp, #0x70
    c1c8:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    c1cc:      	ldr	x21, [sp, #0x78]
    c1d0:      	ldp	x2, x24, [sp, #0x50]
    c1d4:      	str	x21, [sp, #0x48]
    c1d8:      	b	0xc228 <generic_fentry_path+0x2f68>
    c1dc:      	add	x2, x24, #0x10
    c1e0:      	mov	w8, #0x4                // =4
    c1e4:      	add	x9, sp, #0x98
    c1e8:      	add	x0, sp, #0x98
    c1ec:      	mov	w1, #0x8                // =8
    c1f0:      	blr	x8
    c1f4:      	ldr	x8, [sp, #0x58]
    c1f8:      	ldr	x9, [sp, #0x98]
    c1fc:      	cmp	x8, x9
    c200:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    c204:      	add	x2, x24, #0x18
    c208:      	mov	w8, #0x4                // =4
    c20c:      	mov	x0, x22
    c210:      	mov	w1, #0x8                // =8
    c214:      	blr	x8
    c218:      	ldr	x24, [sp, #0x98]
    c21c:      	ldr	x21, [sp, #0x48]
    c220:      	add	x2, x24, #0x20
    c224:      	stp	x2, x24, [sp, #0x50]
    c228:      	ldr	x8, [sp, #0x30]
    c22c:      	cmp	x21, x8
    c230:      	b.ne	0xc240 <generic_fentry_path+0x2f80>
    c234:      	ldr	x8, [sp, #0x38]
    c238:      	cmp	x2, x8
    c23c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    c240:      	mov	w8, #0x4                // =4
    c244:      	add	x0, sp, #0x70
    c248:      	mov	w1, #0x8                // =8
    c24c:      	blr	x8
    c250:      	ldr	x8, [sp, #0x70]
    c254:      	cmp	x21, x8
    c258:      	b.eq	0xc348 <generic_fentry_path+0x3088>
    c25c:      	add	x23, x21, #0x18
    c260:      	mov	w8, #0x4                // =4
    c264:      	add	x9, sp, #0x98
    c268:      	add	x0, sp, #0x98
    c26c:      	mov	w1, #0x8                // =8
    c270:      	mov	x2, x23
    c274:      	blr	x8
    c278:      	ldr	x8, [sp, #0x98]
    c27c:      	cmp	x8, x21
    c280:      	b.eq	0xc348 <generic_fentry_path+0x3088>
    c284:      	mov	w8, #0x4                // =4
    c288:      	add	x9, sp, #0x78
    c28c:      	add	x0, sp, #0x78
    c290:      	mov	w1, #0x8                // =8
    c294:      	mov	x2, x23
    c298:      	blr	x8
    c29c:      	add	x2, x21, #0x20
    c2a0:      	mov	w8, #0x4                // =4
    c2a4:      	mov	w9, #0x10               // =16
    c2a8:      	add	x10, sp, #0x80
    c2ac:      	add	x0, sp, #0x80
    c2b0:      	mov	w1, #0x10               // =16
    c2b4:      	blr	x8
    c2b8:      	ldr	w21, [sp, #0x84]
    c2bc:      	ldr	x8, [sp, #0x40]
    c2c0:      	ldr	x10, [sp, #0x60]
    c2c4:      	sub	x12, x10, x8
    c2c8:      	ldr	w23, [sp, #0x68]
    c2cc:      	subs	w10, w21, w23
    c2d0:      	ldr	x9, [sp, #0x88]
    c2d4:      	csel	w10, wzr, w10, lo
    c2d8:      	cmp	w23, w21
    c2dc:      	csel	w11, w23, w21, lo
    c2e0:      	cinc	w13, w11, hi
    c2e4:      	sub	w14, w23, w13
    c2e8:      	subs	x12, x12, x13
    c2ec:      	str	w14, [sp, #0x68]
    c2f0:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    c2f4:      	cmp	x12, #0xfff
    c2f8:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    c2fc:      	cmp	w23, w21
    c300:      	b.ls	0xc30c <generic_fentry_path+0x304c>
    c304:      	mov	w13, #0x2f              // =47
    c308:      	strb	w13, [x8, x12]
    c30c:      	add	x19, x8, x12
    c310:      	cmp	w23, w21
    c314:      	add	x2, x9, x10
    c318:      	and	w1, w11, #0xff
    c31c:      	mov	w8, #0x4                // =4
    c320:      	cinc	x0, x19, hi
    c324:      	blr	x8
    c328:      	cmp	w23, w21
    c32c:      	str	x19, [sp, #0x60]
    c330:      	add	x19, sp, #0x70
    c334:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    c338:      	ldr	x21, [sp, #0x78]
    c33c:      	ldp	x2, x24, [sp, #0x50]
    c340:      	str	x21, [sp, #0x48]
    c344:      	b	0xc394 <generic_fentry_path+0x30d4>
    c348:      	add	x2, x24, #0x10
    c34c:      	mov	w8, #0x4                // =4
    c350:      	add	x9, sp, #0x98
    c354:      	add	x0, sp, #0x98
    c358:      	mov	w1, #0x8                // =8
    c35c:      	blr	x8
    c360:      	ldr	x8, [sp, #0x58]
    c364:      	ldr	x9, [sp, #0x98]
    c368:      	cmp	x8, x9
    c36c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    c370:      	add	x2, x24, #0x18
    c374:      	mov	w8, #0x4                // =4
    c378:      	mov	x0, x22
    c37c:      	mov	w1, #0x8                // =8
    c380:      	blr	x8
    c384:      	ldr	x24, [sp, #0x98]
    c388:      	ldr	x21, [sp, #0x48]
    c38c:      	add	x2, x24, #0x20
    c390:      	stp	x2, x24, [sp, #0x50]
    c394:      	ldr	x8, [sp, #0x30]
    c398:      	cmp	x21, x8
    c39c:      	b.ne	0xc3ac <generic_fentry_path+0x30ec>
    c3a0:      	ldr	x8, [sp, #0x38]
    c3a4:      	cmp	x2, x8
    c3a8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    c3ac:      	mov	w8, #0x4                // =4
    c3b0:      	add	x0, sp, #0x70
    c3b4:      	mov	w1, #0x8                // =8
    c3b8:      	blr	x8
    c3bc:      	ldr	x8, [sp, #0x70]
    c3c0:      	cmp	x21, x8
    c3c4:      	b.eq	0xc4b4 <generic_fentry_path+0x31f4>
    c3c8:      	add	x23, x21, #0x18
    c3cc:      	mov	w8, #0x4                // =4
    c3d0:      	add	x9, sp, #0x98
    c3d4:      	add	x0, sp, #0x98
    c3d8:      	mov	w1, #0x8                // =8
    c3dc:      	mov	x2, x23
    c3e0:      	blr	x8
    c3e4:      	ldr	x8, [sp, #0x98]
    c3e8:      	cmp	x8, x21
    c3ec:      	b.eq	0xc4b4 <generic_fentry_path+0x31f4>
    c3f0:      	mov	w8, #0x4                // =4
    c3f4:      	add	x9, sp, #0x78
    c3f8:      	add	x0, sp, #0x78
    c3fc:      	mov	w1, #0x8                // =8
    c400:      	mov	x2, x23
    c404:      	blr	x8
    c408:      	add	x2, x21, #0x20
    c40c:      	mov	w8, #0x4                // =4
    c410:      	mov	w9, #0x10               // =16
    c414:      	add	x10, sp, #0x80
    c418:      	add	x0, sp, #0x80
    c41c:      	mov	w1, #0x10               // =16
    c420:      	blr	x8
    c424:      	ldr	w21, [sp, #0x84]
    c428:      	ldr	x8, [sp, #0x40]
    c42c:      	ldr	x10, [sp, #0x60]
    c430:      	sub	x12, x10, x8
    c434:      	ldr	w23, [sp, #0x68]
    c438:      	subs	w10, w21, w23
    c43c:      	ldr	x9, [sp, #0x88]
    c440:      	csel	w10, wzr, w10, lo
    c444:      	cmp	w23, w21
    c448:      	csel	w11, w23, w21, lo
    c44c:      	cinc	w13, w11, hi
    c450:      	sub	w14, w23, w13
    c454:      	subs	x12, x12, x13
    c458:      	str	w14, [sp, #0x68]
    c45c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    c460:      	cmp	x12, #0xfff
    c464:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    c468:      	cmp	w23, w21
    c46c:      	b.ls	0xc478 <generic_fentry_path+0x31b8>
    c470:      	mov	w13, #0x2f              // =47
    c474:      	strb	w13, [x8, x12]
    c478:      	add	x19, x8, x12
    c47c:      	cmp	w23, w21
    c480:      	add	x2, x9, x10
    c484:      	and	w1, w11, #0xff
    c488:      	mov	w8, #0x4                // =4
    c48c:      	cinc	x0, x19, hi
    c490:      	blr	x8
    c494:      	cmp	w23, w21
    c498:      	str	x19, [sp, #0x60]
    c49c:      	add	x19, sp, #0x70
    c4a0:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    c4a4:      	ldr	x21, [sp, #0x78]
    c4a8:      	ldp	x2, x24, [sp, #0x50]
    c4ac:      	str	x21, [sp, #0x48]
    c4b0:      	b	0xc500 <generic_fentry_path+0x3240>
    c4b4:      	add	x2, x24, #0x10
    c4b8:      	mov	w8, #0x4                // =4
    c4bc:      	add	x9, sp, #0x98
    c4c0:      	add	x0, sp, #0x98
    c4c4:      	mov	w1, #0x8                // =8
    c4c8:      	blr	x8
    c4cc:      	ldr	x8, [sp, #0x58]
    c4d0:      	ldr	x9, [sp, #0x98]
    c4d4:      	cmp	x8, x9
    c4d8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    c4dc:      	add	x2, x24, #0x18
    c4e0:      	mov	w8, #0x4                // =4
    c4e4:      	mov	x0, x22
    c4e8:      	mov	w1, #0x8                // =8
    c4ec:      	blr	x8
    c4f0:      	ldr	x24, [sp, #0x98]
    c4f4:      	ldr	x21, [sp, #0x48]
    c4f8:      	add	x2, x24, #0x20
    c4fc:      	stp	x2, x24, [sp, #0x50]
    c500:      	ldr	x8, [sp, #0x30]
    c504:      	cmp	x21, x8
    c508:      	b.ne	0xc518 <generic_fentry_path+0x3258>
    c50c:      	ldr	x8, [sp, #0x38]
    c510:      	cmp	x2, x8
    c514:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    c518:      	mov	w8, #0x4                // =4
    c51c:      	add	x0, sp, #0x70
    c520:      	mov	w1, #0x8                // =8
    c524:      	blr	x8
    c528:      	ldr	x8, [sp, #0x70]
    c52c:      	cmp	x21, x8
    c530:      	b.eq	0xc620 <generic_fentry_path+0x3360>
    c534:      	add	x23, x21, #0x18
    c538:      	mov	w8, #0x4                // =4
    c53c:      	add	x9, sp, #0x98
    c540:      	add	x0, sp, #0x98
    c544:      	mov	w1, #0x8                // =8
    c548:      	mov	x2, x23
    c54c:      	blr	x8
    c550:      	ldr	x8, [sp, #0x98]
    c554:      	cmp	x8, x21
    c558:      	b.eq	0xc620 <generic_fentry_path+0x3360>
    c55c:      	mov	w8, #0x4                // =4
    c560:      	add	x9, sp, #0x78
    c564:      	add	x0, sp, #0x78
    c568:      	mov	w1, #0x8                // =8
    c56c:      	mov	x2, x23
    c570:      	blr	x8
    c574:      	add	x2, x21, #0x20
    c578:      	mov	w8, #0x4                // =4
    c57c:      	mov	w9, #0x10               // =16
    c580:      	add	x10, sp, #0x80
    c584:      	add	x0, sp, #0x80
    c588:      	mov	w1, #0x10               // =16
    c58c:      	blr	x8
    c590:      	ldr	w21, [sp, #0x84]
    c594:      	ldr	x8, [sp, #0x40]
    c598:      	ldr	x10, [sp, #0x60]
    c59c:      	sub	x12, x10, x8
    c5a0:      	ldr	w23, [sp, #0x68]
    c5a4:      	subs	w10, w21, w23
    c5a8:      	ldr	x9, [sp, #0x88]
    c5ac:      	csel	w10, wzr, w10, lo
    c5b0:      	cmp	w23, w21
    c5b4:      	csel	w11, w23, w21, lo
    c5b8:      	cinc	w13, w11, hi
    c5bc:      	sub	w14, w23, w13
    c5c0:      	subs	x12, x12, x13
    c5c4:      	str	w14, [sp, #0x68]
    c5c8:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    c5cc:      	cmp	x12, #0xfff
    c5d0:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    c5d4:      	cmp	w23, w21
    c5d8:      	b.ls	0xc5e4 <generic_fentry_path+0x3324>
    c5dc:      	mov	w13, #0x2f              // =47
    c5e0:      	strb	w13, [x8, x12]
    c5e4:      	add	x19, x8, x12
    c5e8:      	cmp	w23, w21
    c5ec:      	add	x2, x9, x10
    c5f0:      	and	w1, w11, #0xff
    c5f4:      	mov	w8, #0x4                // =4
    c5f8:      	cinc	x0, x19, hi
    c5fc:      	blr	x8
    c600:      	cmp	w23, w21
    c604:      	str	x19, [sp, #0x60]
    c608:      	add	x19, sp, #0x70
    c60c:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    c610:      	ldr	x21, [sp, #0x78]
    c614:      	ldp	x2, x24, [sp, #0x50]
    c618:      	str	x21, [sp, #0x48]
    c61c:      	b	0xc66c <generic_fentry_path+0x33ac>
    c620:      	add	x2, x24, #0x10
    c624:      	mov	w8, #0x4                // =4
    c628:      	add	x9, sp, #0x98
    c62c:      	add	x0, sp, #0x98
    c630:      	mov	w1, #0x8                // =8
    c634:      	blr	x8
    c638:      	ldr	x8, [sp, #0x58]
    c63c:      	ldr	x9, [sp, #0x98]
    c640:      	cmp	x8, x9
    c644:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    c648:      	add	x2, x24, #0x18
    c64c:      	mov	w8, #0x4                // =4
    c650:      	mov	x0, x22
    c654:      	mov	w1, #0x8                // =8
    c658:      	blr	x8
    c65c:      	ldr	x24, [sp, #0x98]
    c660:      	ldr	x21, [sp, #0x48]
    c664:      	add	x2, x24, #0x20
    c668:      	stp	x2, x24, [sp, #0x50]
    c66c:      	ldr	x8, [sp, #0x30]
    c670:      	cmp	x21, x8
    c674:      	b.ne	0xc684 <generic_fentry_path+0x33c4>
    c678:      	ldr	x8, [sp, #0x38]
    c67c:      	cmp	x2, x8
    c680:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    c684:      	mov	w8, #0x4                // =4
    c688:      	add	x0, sp, #0x70
    c68c:      	mov	w1, #0x8                // =8
    c690:      	blr	x8
    c694:      	ldr	x8, [sp, #0x70]
    c698:      	cmp	x21, x8
    c69c:      	b.eq	0xc78c <generic_fentry_path+0x34cc>
    c6a0:      	add	x23, x21, #0x18
    c6a4:      	mov	w8, #0x4                // =4
    c6a8:      	add	x9, sp, #0x98
    c6ac:      	add	x0, sp, #0x98
    c6b0:      	mov	w1, #0x8                // =8
    c6b4:      	mov	x2, x23
    c6b8:      	blr	x8
    c6bc:      	ldr	x8, [sp, #0x98]
    c6c0:      	cmp	x8, x21
    c6c4:      	b.eq	0xc78c <generic_fentry_path+0x34cc>
    c6c8:      	mov	w8, #0x4                // =4
    c6cc:      	add	x9, sp, #0x78
    c6d0:      	add	x0, sp, #0x78
    c6d4:      	mov	w1, #0x8                // =8
    c6d8:      	mov	x2, x23
    c6dc:      	blr	x8
    c6e0:      	add	x2, x21, #0x20
    c6e4:      	mov	w8, #0x4                // =4
    c6e8:      	mov	w9, #0x10               // =16
    c6ec:      	add	x10, sp, #0x80
    c6f0:      	add	x0, sp, #0x80
    c6f4:      	mov	w1, #0x10               // =16
    c6f8:      	blr	x8
    c6fc:      	ldr	w21, [sp, #0x84]
    c700:      	ldr	x8, [sp, #0x40]
    c704:      	ldr	x10, [sp, #0x60]
    c708:      	sub	x12, x10, x8
    c70c:      	ldr	w23, [sp, #0x68]
    c710:      	subs	w10, w21, w23
    c714:      	ldr	x9, [sp, #0x88]
    c718:      	csel	w10, wzr, w10, lo
    c71c:      	cmp	w23, w21
    c720:      	csel	w11, w23, w21, lo
    c724:      	cinc	w13, w11, hi
    c728:      	sub	w14, w23, w13
    c72c:      	subs	x12, x12, x13
    c730:      	str	w14, [sp, #0x68]
    c734:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    c738:      	cmp	x12, #0xfff
    c73c:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    c740:      	cmp	w23, w21
    c744:      	b.ls	0xc750 <generic_fentry_path+0x3490>
    c748:      	mov	w13, #0x2f              // =47
    c74c:      	strb	w13, [x8, x12]
    c750:      	add	x19, x8, x12
    c754:      	cmp	w23, w21
    c758:      	add	x2, x9, x10
    c75c:      	and	w1, w11, #0xff
    c760:      	mov	w8, #0x4                // =4
    c764:      	cinc	x0, x19, hi
    c768:      	blr	x8
    c76c:      	cmp	w23, w21
    c770:      	str	x19, [sp, #0x60]
    c774:      	add	x19, sp, #0x70
    c778:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    c77c:      	ldr	x21, [sp, #0x78]
    c780:      	ldp	x2, x24, [sp, #0x50]
    c784:      	str	x21, [sp, #0x48]
    c788:      	b	0xc7d8 <generic_fentry_path+0x3518>
    c78c:      	add	x2, x24, #0x10
    c790:      	mov	w8, #0x4                // =4
    c794:      	add	x9, sp, #0x98
    c798:      	add	x0, sp, #0x98
    c79c:      	mov	w1, #0x8                // =8
    c7a0:      	blr	x8
    c7a4:      	ldr	x8, [sp, #0x58]
    c7a8:      	ldr	x9, [sp, #0x98]
    c7ac:      	cmp	x8, x9
    c7b0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    c7b4:      	add	x2, x24, #0x18
    c7b8:      	mov	w8, #0x4                // =4
    c7bc:      	mov	x0, x22
    c7c0:      	mov	w1, #0x8                // =8
    c7c4:      	blr	x8
    c7c8:      	ldr	x24, [sp, #0x98]
    c7cc:      	ldr	x21, [sp, #0x48]
    c7d0:      	add	x2, x24, #0x20
    c7d4:      	stp	x2, x24, [sp, #0x50]
    c7d8:      	ldr	x8, [sp, #0x30]
    c7dc:      	cmp	x21, x8
    c7e0:      	b.ne	0xc7f0 <generic_fentry_path+0x3530>
    c7e4:      	ldr	x8, [sp, #0x38]
    c7e8:      	cmp	x2, x8
    c7ec:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    c7f0:      	mov	w8, #0x4                // =4
    c7f4:      	add	x0, sp, #0x70
    c7f8:      	mov	w1, #0x8                // =8
    c7fc:      	blr	x8
    c800:      	ldr	x8, [sp, #0x70]
    c804:      	cmp	x21, x8
    c808:      	b.eq	0xc8f8 <generic_fentry_path+0x3638>
    c80c:      	add	x23, x21, #0x18
    c810:      	mov	w8, #0x4                // =4
    c814:      	add	x9, sp, #0x98
    c818:      	add	x0, sp, #0x98
    c81c:      	mov	w1, #0x8                // =8
    c820:      	mov	x2, x23
    c824:      	blr	x8
    c828:      	ldr	x8, [sp, #0x98]
    c82c:      	cmp	x8, x21
    c830:      	b.eq	0xc8f8 <generic_fentry_path+0x3638>
    c834:      	mov	w8, #0x4                // =4
    c838:      	add	x9, sp, #0x78
    c83c:      	add	x0, sp, #0x78
    c840:      	mov	w1, #0x8                // =8
    c844:      	mov	x2, x23
    c848:      	blr	x8
    c84c:      	add	x2, x21, #0x20
    c850:      	mov	w8, #0x4                // =4
    c854:      	mov	w9, #0x10               // =16
    c858:      	add	x10, sp, #0x80
    c85c:      	add	x0, sp, #0x80
    c860:      	mov	w1, #0x10               // =16
    c864:      	blr	x8
    c868:      	ldr	w21, [sp, #0x84]
    c86c:      	ldr	x8, [sp, #0x40]
    c870:      	ldr	x10, [sp, #0x60]
    c874:      	sub	x12, x10, x8
    c878:      	ldr	w23, [sp, #0x68]
    c87c:      	subs	w10, w21, w23
    c880:      	ldr	x9, [sp, #0x88]
    c884:      	csel	w10, wzr, w10, lo
    c888:      	cmp	w23, w21
    c88c:      	csel	w11, w23, w21, lo
    c890:      	cinc	w13, w11, hi
    c894:      	sub	w14, w23, w13
    c898:      	subs	x12, x12, x13
    c89c:      	str	w14, [sp, #0x68]
    c8a0:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    c8a4:      	cmp	x12, #0xfff
    c8a8:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    c8ac:      	cmp	w23, w21
    c8b0:      	b.ls	0xc8bc <generic_fentry_path+0x35fc>
    c8b4:      	mov	w13, #0x2f              // =47
    c8b8:      	strb	w13, [x8, x12]
    c8bc:      	add	x19, x8, x12
    c8c0:      	cmp	w23, w21
    c8c4:      	add	x2, x9, x10
    c8c8:      	and	w1, w11, #0xff
    c8cc:      	mov	w8, #0x4                // =4
    c8d0:      	cinc	x0, x19, hi
    c8d4:      	blr	x8
    c8d8:      	cmp	w23, w21
    c8dc:      	str	x19, [sp, #0x60]
    c8e0:      	add	x19, sp, #0x70
    c8e4:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    c8e8:      	ldr	x21, [sp, #0x78]
    c8ec:      	ldp	x2, x24, [sp, #0x50]
    c8f0:      	str	x21, [sp, #0x48]
    c8f4:      	b	0xc944 <generic_fentry_path+0x3684>
    c8f8:      	add	x2, x24, #0x10
    c8fc:      	mov	w8, #0x4                // =4
    c900:      	add	x9, sp, #0x98
    c904:      	add	x0, sp, #0x98
    c908:      	mov	w1, #0x8                // =8
    c90c:      	blr	x8
    c910:      	ldr	x8, [sp, #0x58]
    c914:      	ldr	x9, [sp, #0x98]
    c918:      	cmp	x8, x9
    c91c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    c920:      	add	x2, x24, #0x18
    c924:      	mov	w8, #0x4                // =4
    c928:      	mov	x0, x22
    c92c:      	mov	w1, #0x8                // =8
    c930:      	blr	x8
    c934:      	ldr	x24, [sp, #0x98]
    c938:      	ldr	x21, [sp, #0x48]
    c93c:      	add	x2, x24, #0x20
    c940:      	stp	x2, x24, [sp, #0x50]
    c944:      	ldr	x8, [sp, #0x30]
    c948:      	cmp	x21, x8
    c94c:      	b.ne	0xc95c <generic_fentry_path+0x369c>
    c950:      	ldr	x8, [sp, #0x38]
    c954:      	cmp	x2, x8
    c958:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    c95c:      	mov	w8, #0x4                // =4
    c960:      	add	x0, sp, #0x70
    c964:      	mov	w1, #0x8                // =8
    c968:      	blr	x8
    c96c:      	ldr	x8, [sp, #0x70]
    c970:      	cmp	x21, x8
    c974:      	b.eq	0xca64 <generic_fentry_path+0x37a4>
    c978:      	add	x23, x21, #0x18
    c97c:      	mov	w8, #0x4                // =4
    c980:      	add	x9, sp, #0x98
    c984:      	add	x0, sp, #0x98
    c988:      	mov	w1, #0x8                // =8
    c98c:      	mov	x2, x23
    c990:      	blr	x8
    c994:      	ldr	x8, [sp, #0x98]
    c998:      	cmp	x8, x21
    c99c:      	b.eq	0xca64 <generic_fentry_path+0x37a4>
    c9a0:      	mov	w8, #0x4                // =4
    c9a4:      	add	x9, sp, #0x78
    c9a8:      	add	x0, sp, #0x78
    c9ac:      	mov	w1, #0x8                // =8
    c9b0:      	mov	x2, x23
    c9b4:      	blr	x8
    c9b8:      	add	x2, x21, #0x20
    c9bc:      	mov	w8, #0x4                // =4
    c9c0:      	mov	w9, #0x10               // =16
    c9c4:      	add	x10, sp, #0x80
    c9c8:      	add	x0, sp, #0x80
    c9cc:      	mov	w1, #0x10               // =16
    c9d0:      	blr	x8
    c9d4:      	ldr	w21, [sp, #0x84]
    c9d8:      	ldr	x8, [sp, #0x40]
    c9dc:      	ldr	x10, [sp, #0x60]
    c9e0:      	sub	x12, x10, x8
    c9e4:      	ldr	w23, [sp, #0x68]
    c9e8:      	subs	w10, w21, w23
    c9ec:      	ldr	x9, [sp, #0x88]
    c9f0:      	csel	w10, wzr, w10, lo
    c9f4:      	cmp	w23, w21
    c9f8:      	csel	w11, w23, w21, lo
    c9fc:      	cinc	w13, w11, hi
    ca00:      	sub	w14, w23, w13
    ca04:      	subs	x12, x12, x13
    ca08:      	str	w14, [sp, #0x68]
    ca0c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    ca10:      	cmp	x12, #0xfff
    ca14:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    ca18:      	cmp	w23, w21
    ca1c:      	b.ls	0xca28 <generic_fentry_path+0x3768>
    ca20:      	mov	w13, #0x2f              // =47
    ca24:      	strb	w13, [x8, x12]
    ca28:      	add	x19, x8, x12
    ca2c:      	cmp	w23, w21
    ca30:      	add	x2, x9, x10
    ca34:      	and	w1, w11, #0xff
    ca38:      	mov	w8, #0x4                // =4
    ca3c:      	cinc	x0, x19, hi
    ca40:      	blr	x8
    ca44:      	cmp	w23, w21
    ca48:      	str	x19, [sp, #0x60]
    ca4c:      	add	x19, sp, #0x70
    ca50:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    ca54:      	ldr	x21, [sp, #0x78]
    ca58:      	ldp	x2, x24, [sp, #0x50]
    ca5c:      	str	x21, [sp, #0x48]
    ca60:      	b	0xcab0 <generic_fentry_path+0x37f0>
    ca64:      	add	x2, x24, #0x10
    ca68:      	mov	w8, #0x4                // =4
    ca6c:      	add	x9, sp, #0x98
    ca70:      	add	x0, sp, #0x98
    ca74:      	mov	w1, #0x8                // =8
    ca78:      	blr	x8
    ca7c:      	ldr	x8, [sp, #0x58]
    ca80:      	ldr	x9, [sp, #0x98]
    ca84:      	cmp	x8, x9
    ca88:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    ca8c:      	add	x2, x24, #0x18
    ca90:      	mov	w8, #0x4                // =4
    ca94:      	mov	x0, x22
    ca98:      	mov	w1, #0x8                // =8
    ca9c:      	blr	x8
    caa0:      	ldr	x24, [sp, #0x98]
    caa4:      	ldr	x21, [sp, #0x48]
    caa8:      	add	x2, x24, #0x20
    caac:      	stp	x2, x24, [sp, #0x50]
    cab0:      	ldr	x8, [sp, #0x30]
    cab4:      	cmp	x21, x8
    cab8:      	b.ne	0xcac8 <generic_fentry_path+0x3808>
    cabc:      	ldr	x8, [sp, #0x38]
    cac0:      	cmp	x2, x8
    cac4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    cac8:      	mov	w8, #0x4                // =4
    cacc:      	add	x0, sp, #0x70
    cad0:      	mov	w1, #0x8                // =8
    cad4:      	blr	x8
    cad8:      	ldr	x8, [sp, #0x70]
    cadc:      	cmp	x21, x8
    cae0:      	b.eq	0xcbd0 <generic_fentry_path+0x3910>
    cae4:      	add	x23, x21, #0x18
    cae8:      	mov	w8, #0x4                // =4
    caec:      	add	x9, sp, #0x98
    caf0:      	add	x0, sp, #0x98
    caf4:      	mov	w1, #0x8                // =8
    caf8:      	mov	x2, x23
    cafc:      	blr	x8
    cb00:      	ldr	x8, [sp, #0x98]
    cb04:      	cmp	x8, x21
    cb08:      	b.eq	0xcbd0 <generic_fentry_path+0x3910>
    cb0c:      	mov	w8, #0x4                // =4
    cb10:      	add	x9, sp, #0x78
    cb14:      	add	x0, sp, #0x78
    cb18:      	mov	w1, #0x8                // =8
    cb1c:      	mov	x2, x23
    cb20:      	blr	x8
    cb24:      	add	x2, x21, #0x20
    cb28:      	mov	w8, #0x4                // =4
    cb2c:      	mov	w9, #0x10               // =16
    cb30:      	add	x10, sp, #0x80
    cb34:      	add	x0, sp, #0x80
    cb38:      	mov	w1, #0x10               // =16
    cb3c:      	blr	x8
    cb40:      	ldr	w21, [sp, #0x84]
    cb44:      	ldr	x8, [sp, #0x40]
    cb48:      	ldr	x10, [sp, #0x60]
    cb4c:      	sub	x12, x10, x8
    cb50:      	ldr	w23, [sp, #0x68]
    cb54:      	subs	w10, w21, w23
    cb58:      	ldr	x9, [sp, #0x88]
    cb5c:      	csel	w10, wzr, w10, lo
    cb60:      	cmp	w23, w21
    cb64:      	csel	w11, w23, w21, lo
    cb68:      	cinc	w13, w11, hi
    cb6c:      	sub	w14, w23, w13
    cb70:      	subs	x12, x12, x13
    cb74:      	str	w14, [sp, #0x68]
    cb78:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    cb7c:      	cmp	x12, #0xfff
    cb80:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    cb84:      	cmp	w23, w21
    cb88:      	b.ls	0xcb94 <generic_fentry_path+0x38d4>
    cb8c:      	mov	w13, #0x2f              // =47
    cb90:      	strb	w13, [x8, x12]
    cb94:      	add	x19, x8, x12
    cb98:      	cmp	w23, w21
    cb9c:      	add	x2, x9, x10
    cba0:      	and	w1, w11, #0xff
    cba4:      	mov	w8, #0x4                // =4
    cba8:      	cinc	x0, x19, hi
    cbac:      	blr	x8
    cbb0:      	cmp	w23, w21
    cbb4:      	str	x19, [sp, #0x60]
    cbb8:      	add	x19, sp, #0x70
    cbbc:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    cbc0:      	ldr	x21, [sp, #0x78]
    cbc4:      	ldp	x2, x24, [sp, #0x50]
    cbc8:      	str	x21, [sp, #0x48]
    cbcc:      	b	0xcc1c <generic_fentry_path+0x395c>
    cbd0:      	add	x2, x24, #0x10
    cbd4:      	mov	w8, #0x4                // =4
    cbd8:      	add	x9, sp, #0x98
    cbdc:      	add	x0, sp, #0x98
    cbe0:      	mov	w1, #0x8                // =8
    cbe4:      	blr	x8
    cbe8:      	ldr	x8, [sp, #0x58]
    cbec:      	ldr	x9, [sp, #0x98]
    cbf0:      	cmp	x8, x9
    cbf4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    cbf8:      	add	x2, x24, #0x18
    cbfc:      	mov	w8, #0x4                // =4
    cc00:      	mov	x0, x22
    cc04:      	mov	w1, #0x8                // =8
    cc08:      	blr	x8
    cc0c:      	ldr	x24, [sp, #0x98]
    cc10:      	ldr	x21, [sp, #0x48]
    cc14:      	add	x2, x24, #0x20
    cc18:      	stp	x2, x24, [sp, #0x50]
    cc1c:      	ldr	x8, [sp, #0x30]
    cc20:      	cmp	x21, x8
    cc24:      	b.ne	0xcc34 <generic_fentry_path+0x3974>
    cc28:      	ldr	x8, [sp, #0x38]
    cc2c:      	cmp	x2, x8
    cc30:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    cc34:      	mov	w8, #0x4                // =4
    cc38:      	add	x0, sp, #0x70
    cc3c:      	mov	w1, #0x8                // =8
    cc40:      	blr	x8
    cc44:      	ldr	x8, [sp, #0x70]
    cc48:      	cmp	x21, x8
    cc4c:      	b.eq	0xcd3c <generic_fentry_path+0x3a7c>
    cc50:      	add	x23, x21, #0x18
    cc54:      	mov	w8, #0x4                // =4
    cc58:      	add	x9, sp, #0x98
    cc5c:      	add	x0, sp, #0x98
    cc60:      	mov	w1, #0x8                // =8
    cc64:      	mov	x2, x23
    cc68:      	blr	x8
    cc6c:      	ldr	x8, [sp, #0x98]
    cc70:      	cmp	x8, x21
    cc74:      	b.eq	0xcd3c <generic_fentry_path+0x3a7c>
    cc78:      	mov	w8, #0x4                // =4
    cc7c:      	add	x9, sp, #0x78
    cc80:      	add	x0, sp, #0x78
    cc84:      	mov	w1, #0x8                // =8
    cc88:      	mov	x2, x23
    cc8c:      	blr	x8
    cc90:      	add	x2, x21, #0x20
    cc94:      	mov	w8, #0x4                // =4
    cc98:      	mov	w9, #0x10               // =16
    cc9c:      	add	x10, sp, #0x80
    cca0:      	add	x0, sp, #0x80
    cca4:      	mov	w1, #0x10               // =16
    cca8:      	blr	x8
    ccac:      	ldr	w21, [sp, #0x84]
    ccb0:      	ldr	x8, [sp, #0x40]
    ccb4:      	ldr	x10, [sp, #0x60]
    ccb8:      	sub	x12, x10, x8
    ccbc:      	ldr	w23, [sp, #0x68]
    ccc0:      	subs	w10, w21, w23
    ccc4:      	ldr	x9, [sp, #0x88]
    ccc8:      	csel	w10, wzr, w10, lo
    cccc:      	cmp	w23, w21
    ccd0:      	csel	w11, w23, w21, lo
    ccd4:      	cinc	w13, w11, hi
    ccd8:      	sub	w14, w23, w13
    ccdc:      	subs	x12, x12, x13
    cce0:      	str	w14, [sp, #0x68]
    cce4:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    cce8:      	cmp	x12, #0xfff
    ccec:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    ccf0:      	cmp	w23, w21
    ccf4:      	b.ls	0xcd00 <generic_fentry_path+0x3a40>
    ccf8:      	mov	w13, #0x2f              // =47
    ccfc:      	strb	w13, [x8, x12]
    cd00:      	add	x19, x8, x12
    cd04:      	cmp	w23, w21
    cd08:      	add	x2, x9, x10
    cd0c:      	and	w1, w11, #0xff
    cd10:      	mov	w8, #0x4                // =4
    cd14:      	cinc	x0, x19, hi
    cd18:      	blr	x8
    cd1c:      	cmp	w23, w21
    cd20:      	str	x19, [sp, #0x60]
    cd24:      	add	x19, sp, #0x70
    cd28:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    cd2c:      	ldr	x21, [sp, #0x78]
    cd30:      	ldp	x2, x24, [sp, #0x50]
    cd34:      	str	x21, [sp, #0x48]
    cd38:      	b	0xcd88 <generic_fentry_path+0x3ac8>
    cd3c:      	add	x2, x24, #0x10
    cd40:      	mov	w8, #0x4                // =4
    cd44:      	add	x9, sp, #0x98
    cd48:      	add	x0, sp, #0x98
    cd4c:      	mov	w1, #0x8                // =8
    cd50:      	blr	x8
    cd54:      	ldr	x8, [sp, #0x58]
    cd58:      	ldr	x9, [sp, #0x98]
    cd5c:      	cmp	x8, x9
    cd60:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    cd64:      	add	x2, x24, #0x18
    cd68:      	mov	w8, #0x4                // =4
    cd6c:      	mov	x0, x22
    cd70:      	mov	w1, #0x8                // =8
    cd74:      	blr	x8
    cd78:      	ldr	x24, [sp, #0x98]
    cd7c:      	ldr	x21, [sp, #0x48]
    cd80:      	add	x2, x24, #0x20
    cd84:      	stp	x2, x24, [sp, #0x50]
    cd88:      	ldr	x8, [sp, #0x30]
    cd8c:      	cmp	x21, x8
    cd90:      	b.ne	0xcda0 <generic_fentry_path+0x3ae0>
    cd94:      	ldr	x8, [sp, #0x38]
    cd98:      	cmp	x2, x8
    cd9c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    cda0:      	mov	w8, #0x4                // =4
    cda4:      	add	x0, sp, #0x70
    cda8:      	mov	w1, #0x8                // =8
    cdac:      	blr	x8
    cdb0:      	ldr	x8, [sp, #0x70]
    cdb4:      	cmp	x21, x8
    cdb8:      	b.eq	0xcea8 <generic_fentry_path+0x3be8>
    cdbc:      	add	x23, x21, #0x18
    cdc0:      	mov	w8, #0x4                // =4
    cdc4:      	add	x9, sp, #0x98
    cdc8:      	add	x0, sp, #0x98
    cdcc:      	mov	w1, #0x8                // =8
    cdd0:      	mov	x2, x23
    cdd4:      	blr	x8
    cdd8:      	ldr	x8, [sp, #0x98]
    cddc:      	cmp	x8, x21
    cde0:      	b.eq	0xcea8 <generic_fentry_path+0x3be8>
    cde4:      	mov	w8, #0x4                // =4
    cde8:      	add	x9, sp, #0x78
    cdec:      	add	x0, sp, #0x78
    cdf0:      	mov	w1, #0x8                // =8
    cdf4:      	mov	x2, x23
    cdf8:      	blr	x8
    cdfc:      	add	x2, x21, #0x20
    ce00:      	mov	w8, #0x4                // =4
    ce04:      	mov	w9, #0x10               // =16
    ce08:      	add	x10, sp, #0x80
    ce0c:      	add	x0, sp, #0x80
    ce10:      	mov	w1, #0x10               // =16
    ce14:      	blr	x8
    ce18:      	ldr	w21, [sp, #0x84]
    ce1c:      	ldr	x8, [sp, #0x40]
    ce20:      	ldr	x10, [sp, #0x60]
    ce24:      	sub	x12, x10, x8
    ce28:      	ldr	w23, [sp, #0x68]
    ce2c:      	subs	w10, w21, w23
    ce30:      	ldr	x9, [sp, #0x88]
    ce34:      	csel	w10, wzr, w10, lo
    ce38:      	cmp	w23, w21
    ce3c:      	csel	w11, w23, w21, lo
    ce40:      	cinc	w13, w11, hi
    ce44:      	sub	w14, w23, w13
    ce48:      	subs	x12, x12, x13
    ce4c:      	str	w14, [sp, #0x68]
    ce50:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    ce54:      	cmp	x12, #0xfff
    ce58:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    ce5c:      	cmp	w23, w21
    ce60:      	b.ls	0xce6c <generic_fentry_path+0x3bac>
    ce64:      	mov	w13, #0x2f              // =47
    ce68:      	strb	w13, [x8, x12]
    ce6c:      	add	x19, x8, x12
    ce70:      	cmp	w23, w21
    ce74:      	add	x2, x9, x10
    ce78:      	and	w1, w11, #0xff
    ce7c:      	mov	w8, #0x4                // =4
    ce80:      	cinc	x0, x19, hi
    ce84:      	blr	x8
    ce88:      	cmp	w23, w21
    ce8c:      	str	x19, [sp, #0x60]
    ce90:      	add	x19, sp, #0x70
    ce94:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    ce98:      	ldr	x21, [sp, #0x78]
    ce9c:      	ldp	x2, x24, [sp, #0x50]
    cea0:      	str	x21, [sp, #0x48]
    cea4:      	b	0xcef4 <generic_fentry_path+0x3c34>
    cea8:      	add	x2, x24, #0x10
    ceac:      	mov	w8, #0x4                // =4
    ceb0:      	add	x9, sp, #0x98
    ceb4:      	add	x0, sp, #0x98
    ceb8:      	mov	w1, #0x8                // =8
    cebc:      	blr	x8
    cec0:      	ldr	x8, [sp, #0x58]
    cec4:      	ldr	x9, [sp, #0x98]
    cec8:      	cmp	x8, x9
    cecc:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    ced0:      	add	x2, x24, #0x18
    ced4:      	mov	w8, #0x4                // =4
    ced8:      	mov	x0, x22
    cedc:      	mov	w1, #0x8                // =8
    cee0:      	blr	x8
    cee4:      	ldr	x24, [sp, #0x98]
    cee8:      	ldr	x21, [sp, #0x48]
    ceec:      	add	x2, x24, #0x20
    cef0:      	stp	x2, x24, [sp, #0x50]
    cef4:      	ldr	x8, [sp, #0x30]
    cef8:      	cmp	x21, x8
    cefc:      	b.ne	0xcf0c <generic_fentry_path+0x3c4c>
    cf00:      	ldr	x8, [sp, #0x38]
    cf04:      	cmp	x2, x8
    cf08:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    cf0c:      	mov	w8, #0x4                // =4
    cf10:      	add	x0, sp, #0x70
    cf14:      	mov	w1, #0x8                // =8
    cf18:      	blr	x8
    cf1c:      	ldr	x8, [sp, #0x70]
    cf20:      	cmp	x21, x8
    cf24:      	b.eq	0xd014 <generic_fentry_path+0x3d54>
    cf28:      	add	x23, x21, #0x18
    cf2c:      	mov	w8, #0x4                // =4
    cf30:      	add	x9, sp, #0x98
    cf34:      	add	x0, sp, #0x98
    cf38:      	mov	w1, #0x8                // =8
    cf3c:      	mov	x2, x23
    cf40:      	blr	x8
    cf44:      	ldr	x8, [sp, #0x98]
    cf48:      	cmp	x8, x21
    cf4c:      	b.eq	0xd014 <generic_fentry_path+0x3d54>
    cf50:      	mov	w8, #0x4                // =4
    cf54:      	add	x9, sp, #0x78
    cf58:      	add	x0, sp, #0x78
    cf5c:      	mov	w1, #0x8                // =8
    cf60:      	mov	x2, x23
    cf64:      	blr	x8
    cf68:      	add	x2, x21, #0x20
    cf6c:      	mov	w8, #0x4                // =4
    cf70:      	mov	w9, #0x10               // =16
    cf74:      	add	x10, sp, #0x80
    cf78:      	add	x0, sp, #0x80
    cf7c:      	mov	w1, #0x10               // =16
    cf80:      	blr	x8
    cf84:      	ldr	w21, [sp, #0x84]
    cf88:      	ldr	x8, [sp, #0x40]
    cf8c:      	ldr	x10, [sp, #0x60]
    cf90:      	sub	x12, x10, x8
    cf94:      	ldr	w23, [sp, #0x68]
    cf98:      	subs	w10, w21, w23
    cf9c:      	ldr	x9, [sp, #0x88]
    cfa0:      	csel	w10, wzr, w10, lo
    cfa4:      	cmp	w23, w21
    cfa8:      	csel	w11, w23, w21, lo
    cfac:      	cinc	w13, w11, hi
    cfb0:      	sub	w14, w23, w13
    cfb4:      	subs	x12, x12, x13
    cfb8:      	str	w14, [sp, #0x68]
    cfbc:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    cfc0:      	cmp	x12, #0xfff
    cfc4:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    cfc8:      	cmp	w23, w21
    cfcc:      	b.ls	0xcfd8 <generic_fentry_path+0x3d18>
    cfd0:      	mov	w13, #0x2f              // =47
    cfd4:      	strb	w13, [x8, x12]
    cfd8:      	add	x19, x8, x12
    cfdc:      	cmp	w23, w21
    cfe0:      	add	x2, x9, x10
    cfe4:      	and	w1, w11, #0xff
    cfe8:      	mov	w8, #0x4                // =4
    cfec:      	cinc	x0, x19, hi
    cff0:      	blr	x8
    cff4:      	cmp	w23, w21
    cff8:      	str	x19, [sp, #0x60]
    cffc:      	add	x19, sp, #0x70
    d000:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    d004:      	ldr	x21, [sp, #0x78]
    d008:      	ldp	x2, x24, [sp, #0x50]
    d00c:      	str	x21, [sp, #0x48]
    d010:      	b	0xd060 <generic_fentry_path+0x3da0>
    d014:      	add	x2, x24, #0x10
    d018:      	mov	w8, #0x4                // =4
    d01c:      	add	x9, sp, #0x98
    d020:      	add	x0, sp, #0x98
    d024:      	mov	w1, #0x8                // =8
    d028:      	blr	x8
    d02c:      	ldr	x8, [sp, #0x58]
    d030:      	ldr	x9, [sp, #0x98]
    d034:      	cmp	x8, x9
    d038:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    d03c:      	add	x2, x24, #0x18
    d040:      	mov	w8, #0x4                // =4
    d044:      	mov	x0, x22
    d048:      	mov	w1, #0x8                // =8
    d04c:      	blr	x8
    d050:      	ldr	x24, [sp, #0x98]
    d054:      	ldr	x21, [sp, #0x48]
    d058:      	add	x2, x24, #0x20
    d05c:      	stp	x2, x24, [sp, #0x50]
    d060:      	ldr	x8, [sp, #0x30]
    d064:      	cmp	x21, x8
    d068:      	b.ne	0xd078 <generic_fentry_path+0x3db8>
    d06c:      	ldr	x8, [sp, #0x38]
    d070:      	cmp	x2, x8
    d074:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    d078:      	mov	w8, #0x4                // =4
    d07c:      	add	x0, sp, #0x70
    d080:      	mov	w1, #0x8                // =8
    d084:      	blr	x8
    d088:      	ldr	x8, [sp, #0x70]
    d08c:      	cmp	x21, x8
    d090:      	b.eq	0xd180 <generic_fentry_path+0x3ec0>
    d094:      	add	x23, x21, #0x18
    d098:      	mov	w8, #0x4                // =4
    d09c:      	add	x9, sp, #0x98
    d0a0:      	add	x0, sp, #0x98
    d0a4:      	mov	w1, #0x8                // =8
    d0a8:      	mov	x2, x23
    d0ac:      	blr	x8
    d0b0:      	ldr	x8, [sp, #0x98]
    d0b4:      	cmp	x8, x21
    d0b8:      	b.eq	0xd180 <generic_fentry_path+0x3ec0>
    d0bc:      	mov	w8, #0x4                // =4
    d0c0:      	add	x9, sp, #0x78
    d0c4:      	add	x0, sp, #0x78
    d0c8:      	mov	w1, #0x8                // =8
    d0cc:      	mov	x2, x23
    d0d0:      	blr	x8
    d0d4:      	add	x2, x21, #0x20
    d0d8:      	mov	w8, #0x4                // =4
    d0dc:      	mov	w9, #0x10               // =16
    d0e0:      	add	x10, sp, #0x80
    d0e4:      	add	x0, sp, #0x80
    d0e8:      	mov	w1, #0x10               // =16
    d0ec:      	blr	x8
    d0f0:      	ldr	w21, [sp, #0x84]
    d0f4:      	ldr	x8, [sp, #0x40]
    d0f8:      	ldr	x10, [sp, #0x60]
    d0fc:      	sub	x12, x10, x8
    d100:      	ldr	w23, [sp, #0x68]
    d104:      	subs	w10, w21, w23
    d108:      	ldr	x9, [sp, #0x88]
    d10c:      	csel	w10, wzr, w10, lo
    d110:      	cmp	w23, w21
    d114:      	csel	w11, w23, w21, lo
    d118:      	cinc	w13, w11, hi
    d11c:      	sub	w14, w23, w13
    d120:      	subs	x12, x12, x13
    d124:      	str	w14, [sp, #0x68]
    d128:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    d12c:      	cmp	x12, #0xfff
    d130:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    d134:      	cmp	w23, w21
    d138:      	b.ls	0xd144 <generic_fentry_path+0x3e84>
    d13c:      	mov	w13, #0x2f              // =47
    d140:      	strb	w13, [x8, x12]
    d144:      	add	x19, x8, x12
    d148:      	cmp	w23, w21
    d14c:      	add	x2, x9, x10
    d150:      	and	w1, w11, #0xff
    d154:      	mov	w8, #0x4                // =4
    d158:      	cinc	x0, x19, hi
    d15c:      	blr	x8
    d160:      	cmp	w23, w21
    d164:      	str	x19, [sp, #0x60]
    d168:      	add	x19, sp, #0x70
    d16c:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    d170:      	ldr	x21, [sp, #0x78]
    d174:      	ldp	x2, x24, [sp, #0x50]
    d178:      	str	x21, [sp, #0x48]
    d17c:      	b	0xd1cc <generic_fentry_path+0x3f0c>
    d180:      	add	x2, x24, #0x10
    d184:      	mov	w8, #0x4                // =4
    d188:      	add	x9, sp, #0x98
    d18c:      	add	x0, sp, #0x98
    d190:      	mov	w1, #0x8                // =8
    d194:      	blr	x8
    d198:      	ldr	x8, [sp, #0x58]
    d19c:      	ldr	x9, [sp, #0x98]
    d1a0:      	cmp	x8, x9
    d1a4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    d1a8:      	add	x2, x24, #0x18
    d1ac:      	mov	w8, #0x4                // =4
    d1b0:      	mov	x0, x22
    d1b4:      	mov	w1, #0x8                // =8
    d1b8:      	blr	x8
    d1bc:      	ldr	x24, [sp, #0x98]
    d1c0:      	ldr	x21, [sp, #0x48]
    d1c4:      	add	x2, x24, #0x20
    d1c8:      	stp	x2, x24, [sp, #0x50]
    d1cc:      	ldr	x8, [sp, #0x30]
    d1d0:      	cmp	x21, x8
    d1d4:      	b.ne	0xd1e4 <generic_fentry_path+0x3f24>
    d1d8:      	ldr	x8, [sp, #0x38]
    d1dc:      	cmp	x2, x8
    d1e0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    d1e4:      	mov	w8, #0x4                // =4
    d1e8:      	add	x0, sp, #0x70
    d1ec:      	mov	w1, #0x8                // =8
    d1f0:      	blr	x8
    d1f4:      	ldr	x8, [sp, #0x70]
    d1f8:      	cmp	x21, x8
    d1fc:      	b.eq	0xd2ec <generic_fentry_path+0x402c>
    d200:      	add	x23, x21, #0x18
    d204:      	mov	w8, #0x4                // =4
    d208:      	add	x9, sp, #0x98
    d20c:      	add	x0, sp, #0x98
    d210:      	mov	w1, #0x8                // =8
    d214:      	mov	x2, x23
    d218:      	blr	x8
    d21c:      	ldr	x8, [sp, #0x98]
    d220:      	cmp	x8, x21
    d224:      	b.eq	0xd2ec <generic_fentry_path+0x402c>
    d228:      	mov	w8, #0x4                // =4
    d22c:      	add	x9, sp, #0x78
    d230:      	add	x0, sp, #0x78
    d234:      	mov	w1, #0x8                // =8
    d238:      	mov	x2, x23
    d23c:      	blr	x8
    d240:      	add	x2, x21, #0x20
    d244:      	mov	w8, #0x4                // =4
    d248:      	mov	w9, #0x10               // =16
    d24c:      	add	x10, sp, #0x80
    d250:      	add	x0, sp, #0x80
    d254:      	mov	w1, #0x10               // =16
    d258:      	blr	x8
    d25c:      	ldr	w21, [sp, #0x84]
    d260:      	ldr	x8, [sp, #0x40]
    d264:      	ldr	x10, [sp, #0x60]
    d268:      	sub	x12, x10, x8
    d26c:      	ldr	w23, [sp, #0x68]
    d270:      	subs	w10, w21, w23
    d274:      	ldr	x9, [sp, #0x88]
    d278:      	csel	w10, wzr, w10, lo
    d27c:      	cmp	w23, w21
    d280:      	csel	w11, w23, w21, lo
    d284:      	cinc	w13, w11, hi
    d288:      	sub	w14, w23, w13
    d28c:      	subs	x12, x12, x13
    d290:      	str	w14, [sp, #0x68]
    d294:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    d298:      	cmp	x12, #0xfff
    d29c:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    d2a0:      	cmp	w23, w21
    d2a4:      	b.ls	0xd2b0 <generic_fentry_path+0x3ff0>
    d2a8:      	mov	w13, #0x2f              // =47
    d2ac:      	strb	w13, [x8, x12]
    d2b0:      	add	x19, x8, x12
    d2b4:      	cmp	w23, w21
    d2b8:      	add	x2, x9, x10
    d2bc:      	and	w1, w11, #0xff
    d2c0:      	mov	w8, #0x4                // =4
    d2c4:      	cinc	x0, x19, hi
    d2c8:      	blr	x8
    d2cc:      	cmp	w23, w21
    d2d0:      	str	x19, [sp, #0x60]
    d2d4:      	add	x19, sp, #0x70
    d2d8:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    d2dc:      	ldr	x21, [sp, #0x78]
    d2e0:      	ldp	x2, x24, [sp, #0x50]
    d2e4:      	str	x21, [sp, #0x48]
    d2e8:      	b	0xd338 <generic_fentry_path+0x4078>
    d2ec:      	add	x2, x24, #0x10
    d2f0:      	mov	w8, #0x4                // =4
    d2f4:      	add	x9, sp, #0x98
    d2f8:      	add	x0, sp, #0x98
    d2fc:      	mov	w1, #0x8                // =8
    d300:      	blr	x8
    d304:      	ldr	x8, [sp, #0x58]
    d308:      	ldr	x9, [sp, #0x98]
    d30c:      	cmp	x8, x9
    d310:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    d314:      	add	x2, x24, #0x18
    d318:      	mov	w8, #0x4                // =4
    d31c:      	mov	x0, x22
    d320:      	mov	w1, #0x8                // =8
    d324:      	blr	x8
    d328:      	ldr	x24, [sp, #0x98]
    d32c:      	ldr	x21, [sp, #0x48]
    d330:      	add	x2, x24, #0x20
    d334:      	stp	x2, x24, [sp, #0x50]
    d338:      	ldr	x8, [sp, #0x30]
    d33c:      	cmp	x21, x8
    d340:      	b.ne	0xd350 <generic_fentry_path+0x4090>
    d344:      	ldr	x8, [sp, #0x38]
    d348:      	cmp	x2, x8
    d34c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    d350:      	mov	w8, #0x4                // =4
    d354:      	add	x0, sp, #0x70
    d358:      	mov	w1, #0x8                // =8
    d35c:      	blr	x8
    d360:      	ldr	x8, [sp, #0x70]
    d364:      	cmp	x21, x8
    d368:      	b.eq	0xd458 <generic_fentry_path+0x4198>
    d36c:      	add	x23, x21, #0x18
    d370:      	mov	w8, #0x4                // =4
    d374:      	add	x9, sp, #0x98
    d378:      	add	x0, sp, #0x98
    d37c:      	mov	w1, #0x8                // =8
    d380:      	mov	x2, x23
    d384:      	blr	x8
    d388:      	ldr	x8, [sp, #0x98]
    d38c:      	cmp	x8, x21
    d390:      	b.eq	0xd458 <generic_fentry_path+0x4198>
    d394:      	mov	w8, #0x4                // =4
    d398:      	add	x9, sp, #0x78
    d39c:      	add	x0, sp, #0x78
    d3a0:      	mov	w1, #0x8                // =8
    d3a4:      	mov	x2, x23
    d3a8:      	blr	x8
    d3ac:      	add	x2, x21, #0x20
    d3b0:      	mov	w8, #0x4                // =4
    d3b4:      	mov	w9, #0x10               // =16
    d3b8:      	add	x10, sp, #0x80
    d3bc:      	add	x0, sp, #0x80
    d3c0:      	mov	w1, #0x10               // =16
    d3c4:      	blr	x8
    d3c8:      	ldr	w21, [sp, #0x84]
    d3cc:      	ldr	x8, [sp, #0x40]
    d3d0:      	ldr	x10, [sp, #0x60]
    d3d4:      	sub	x12, x10, x8
    d3d8:      	ldr	w23, [sp, #0x68]
    d3dc:      	subs	w10, w21, w23
    d3e0:      	ldr	x9, [sp, #0x88]
    d3e4:      	csel	w10, wzr, w10, lo
    d3e8:      	cmp	w23, w21
    d3ec:      	csel	w11, w23, w21, lo
    d3f0:      	cinc	w13, w11, hi
    d3f4:      	sub	w14, w23, w13
    d3f8:      	subs	x12, x12, x13
    d3fc:      	str	w14, [sp, #0x68]
    d400:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    d404:      	cmp	x12, #0xfff
    d408:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    d40c:      	cmp	w23, w21
    d410:      	b.ls	0xd41c <generic_fentry_path+0x415c>
    d414:      	mov	w13, #0x2f              // =47
    d418:      	strb	w13, [x8, x12]
    d41c:      	add	x19, x8, x12
    d420:      	cmp	w23, w21
    d424:      	add	x2, x9, x10
    d428:      	and	w1, w11, #0xff
    d42c:      	mov	w8, #0x4                // =4
    d430:      	cinc	x0, x19, hi
    d434:      	blr	x8
    d438:      	cmp	w23, w21
    d43c:      	str	x19, [sp, #0x60]
    d440:      	add	x19, sp, #0x70
    d444:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    d448:      	ldr	x21, [sp, #0x78]
    d44c:      	ldp	x2, x24, [sp, #0x50]
    d450:      	str	x21, [sp, #0x48]
    d454:      	b	0xd4a4 <generic_fentry_path+0x41e4>
    d458:      	add	x2, x24, #0x10
    d45c:      	mov	w8, #0x4                // =4
    d460:      	add	x9, sp, #0x98
    d464:      	add	x0, sp, #0x98
    d468:      	mov	w1, #0x8                // =8
    d46c:      	blr	x8
    d470:      	ldr	x8, [sp, #0x58]
    d474:      	ldr	x9, [sp, #0x98]
    d478:      	cmp	x8, x9
    d47c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    d480:      	add	x2, x24, #0x18
    d484:      	mov	w8, #0x4                // =4
    d488:      	mov	x0, x22
    d48c:      	mov	w1, #0x8                // =8
    d490:      	blr	x8
    d494:      	ldr	x24, [sp, #0x98]
    d498:      	ldr	x21, [sp, #0x48]
    d49c:      	add	x2, x24, #0x20
    d4a0:      	stp	x2, x24, [sp, #0x50]
    d4a4:      	ldr	x8, [sp, #0x30]
    d4a8:      	cmp	x21, x8
    d4ac:      	b.ne	0xd4bc <generic_fentry_path+0x41fc>
    d4b0:      	ldr	x8, [sp, #0x38]
    d4b4:      	cmp	x2, x8
    d4b8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    d4bc:      	mov	w8, #0x4                // =4
    d4c0:      	add	x0, sp, #0x70
    d4c4:      	mov	w1, #0x8                // =8
    d4c8:      	blr	x8
    d4cc:      	ldr	x8, [sp, #0x70]
    d4d0:      	cmp	x21, x8
    d4d4:      	b.eq	0xd5c4 <generic_fentry_path+0x4304>
    d4d8:      	add	x23, x21, #0x18
    d4dc:      	mov	w8, #0x4                // =4
    d4e0:      	add	x9, sp, #0x98
    d4e4:      	add	x0, sp, #0x98
    d4e8:      	mov	w1, #0x8                // =8
    d4ec:      	mov	x2, x23
    d4f0:      	blr	x8
    d4f4:      	ldr	x8, [sp, #0x98]
    d4f8:      	cmp	x8, x21
    d4fc:      	b.eq	0xd5c4 <generic_fentry_path+0x4304>
    d500:      	mov	w8, #0x4                // =4
    d504:      	add	x9, sp, #0x78
    d508:      	add	x0, sp, #0x78
    d50c:      	mov	w1, #0x8                // =8
    d510:      	mov	x2, x23
    d514:      	blr	x8
    d518:      	add	x2, x21, #0x20
    d51c:      	mov	w8, #0x4                // =4
    d520:      	mov	w9, #0x10               // =16
    d524:      	add	x10, sp, #0x80
    d528:      	add	x0, sp, #0x80
    d52c:      	mov	w1, #0x10               // =16
    d530:      	blr	x8
    d534:      	ldr	w21, [sp, #0x84]
    d538:      	ldr	x8, [sp, #0x40]
    d53c:      	ldr	x10, [sp, #0x60]
    d540:      	sub	x12, x10, x8
    d544:      	ldr	w23, [sp, #0x68]
    d548:      	subs	w10, w21, w23
    d54c:      	ldr	x9, [sp, #0x88]
    d550:      	csel	w10, wzr, w10, lo
    d554:      	cmp	w23, w21
    d558:      	csel	w11, w23, w21, lo
    d55c:      	cinc	w13, w11, hi
    d560:      	sub	w14, w23, w13
    d564:      	subs	x12, x12, x13
    d568:      	str	w14, [sp, #0x68]
    d56c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    d570:      	cmp	x12, #0xfff
    d574:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    d578:      	cmp	w23, w21
    d57c:      	b.ls	0xd588 <generic_fentry_path+0x42c8>
    d580:      	mov	w13, #0x2f              // =47
    d584:      	strb	w13, [x8, x12]
    d588:      	add	x19, x8, x12
    d58c:      	cmp	w23, w21
    d590:      	add	x2, x9, x10
    d594:      	and	w1, w11, #0xff
    d598:      	mov	w8, #0x4                // =4
    d59c:      	cinc	x0, x19, hi
    d5a0:      	blr	x8
    d5a4:      	cmp	w23, w21
    d5a8:      	str	x19, [sp, #0x60]
    d5ac:      	add	x19, sp, #0x70
    d5b0:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    d5b4:      	ldr	x21, [sp, #0x78]
    d5b8:      	ldp	x2, x24, [sp, #0x50]
    d5bc:      	str	x21, [sp, #0x48]
    d5c0:      	b	0xd610 <generic_fentry_path+0x4350>
    d5c4:      	add	x2, x24, #0x10
    d5c8:      	mov	w8, #0x4                // =4
    d5cc:      	add	x9, sp, #0x98
    d5d0:      	add	x0, sp, #0x98
    d5d4:      	mov	w1, #0x8                // =8
    d5d8:      	blr	x8
    d5dc:      	ldr	x8, [sp, #0x58]
    d5e0:      	ldr	x9, [sp, #0x98]
    d5e4:      	cmp	x8, x9
    d5e8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    d5ec:      	add	x2, x24, #0x18
    d5f0:      	mov	w8, #0x4                // =4
    d5f4:      	mov	x0, x22
    d5f8:      	mov	w1, #0x8                // =8
    d5fc:      	blr	x8
    d600:      	ldr	x24, [sp, #0x98]
    d604:      	ldr	x21, [sp, #0x48]
    d608:      	add	x2, x24, #0x20
    d60c:      	stp	x2, x24, [sp, #0x50]
    d610:      	ldr	x8, [sp, #0x30]
    d614:      	cmp	x21, x8
    d618:      	b.ne	0xd628 <generic_fentry_path+0x4368>
    d61c:      	ldr	x8, [sp, #0x38]
    d620:      	cmp	x2, x8
    d624:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    d628:      	mov	w8, #0x4                // =4
    d62c:      	add	x0, sp, #0x70
    d630:      	mov	w1, #0x8                // =8
    d634:      	blr	x8
    d638:      	ldr	x8, [sp, #0x70]
    d63c:      	cmp	x21, x8
    d640:      	b.eq	0xd730 <generic_fentry_path+0x4470>
    d644:      	add	x23, x21, #0x18
    d648:      	mov	w8, #0x4                // =4
    d64c:      	add	x9, sp, #0x98
    d650:      	add	x0, sp, #0x98
    d654:      	mov	w1, #0x8                // =8
    d658:      	mov	x2, x23
    d65c:      	blr	x8
    d660:      	ldr	x8, [sp, #0x98]
    d664:      	cmp	x8, x21
    d668:      	b.eq	0xd730 <generic_fentry_path+0x4470>
    d66c:      	mov	w8, #0x4                // =4
    d670:      	add	x9, sp, #0x78
    d674:      	add	x0, sp, #0x78
    d678:      	mov	w1, #0x8                // =8
    d67c:      	mov	x2, x23
    d680:      	blr	x8
    d684:      	add	x2, x21, #0x20
    d688:      	mov	w8, #0x4                // =4
    d68c:      	mov	w9, #0x10               // =16
    d690:      	add	x10, sp, #0x80
    d694:      	add	x0, sp, #0x80
    d698:      	mov	w1, #0x10               // =16
    d69c:      	blr	x8
    d6a0:      	ldr	w21, [sp, #0x84]
    d6a4:      	ldr	x8, [sp, #0x40]
    d6a8:      	ldr	x10, [sp, #0x60]
    d6ac:      	sub	x12, x10, x8
    d6b0:      	ldr	w23, [sp, #0x68]
    d6b4:      	subs	w10, w21, w23
    d6b8:      	ldr	x9, [sp, #0x88]
    d6bc:      	csel	w10, wzr, w10, lo
    d6c0:      	cmp	w23, w21
    d6c4:      	csel	w11, w23, w21, lo
    d6c8:      	cinc	w13, w11, hi
    d6cc:      	sub	w14, w23, w13
    d6d0:      	subs	x12, x12, x13
    d6d4:      	str	w14, [sp, #0x68]
    d6d8:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    d6dc:      	cmp	x12, #0xfff
    d6e0:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    d6e4:      	cmp	w23, w21
    d6e8:      	b.ls	0xd6f4 <generic_fentry_path+0x4434>
    d6ec:      	mov	w13, #0x2f              // =47
    d6f0:      	strb	w13, [x8, x12]
    d6f4:      	add	x19, x8, x12
    d6f8:      	cmp	w23, w21
    d6fc:      	add	x2, x9, x10
    d700:      	and	w1, w11, #0xff
    d704:      	mov	w8, #0x4                // =4
    d708:      	cinc	x0, x19, hi
    d70c:      	blr	x8
    d710:      	cmp	w23, w21
    d714:      	str	x19, [sp, #0x60]
    d718:      	add	x19, sp, #0x70
    d71c:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    d720:      	ldr	x21, [sp, #0x78]
    d724:      	ldp	x2, x24, [sp, #0x50]
    d728:      	str	x21, [sp, #0x48]
    d72c:      	b	0xd77c <generic_fentry_path+0x44bc>
    d730:      	add	x2, x24, #0x10
    d734:      	mov	w8, #0x4                // =4
    d738:      	add	x9, sp, #0x98
    d73c:      	add	x0, sp, #0x98
    d740:      	mov	w1, #0x8                // =8
    d744:      	blr	x8
    d748:      	ldr	x8, [sp, #0x58]
    d74c:      	ldr	x9, [sp, #0x98]
    d750:      	cmp	x8, x9
    d754:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    d758:      	add	x2, x24, #0x18
    d75c:      	mov	w8, #0x4                // =4
    d760:      	mov	x0, x22
    d764:      	mov	w1, #0x8                // =8
    d768:      	blr	x8
    d76c:      	ldr	x24, [sp, #0x98]
    d770:      	ldr	x21, [sp, #0x48]
    d774:      	add	x2, x24, #0x20
    d778:      	stp	x2, x24, [sp, #0x50]
    d77c:      	ldr	x8, [sp, #0x30]
    d780:      	cmp	x21, x8
    d784:      	b.ne	0xd794 <generic_fentry_path+0x44d4>
    d788:      	ldr	x8, [sp, #0x38]
    d78c:      	cmp	x2, x8
    d790:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    d794:      	mov	w8, #0x4                // =4
    d798:      	add	x0, sp, #0x70
    d79c:      	mov	w1, #0x8                // =8
    d7a0:      	blr	x8
    d7a4:      	ldr	x8, [sp, #0x70]
    d7a8:      	cmp	x21, x8
    d7ac:      	b.eq	0xd89c <generic_fentry_path+0x45dc>
    d7b0:      	add	x23, x21, #0x18
    d7b4:      	mov	w8, #0x4                // =4
    d7b8:      	add	x9, sp, #0x98
    d7bc:      	add	x0, sp, #0x98
    d7c0:      	mov	w1, #0x8                // =8
    d7c4:      	mov	x2, x23
    d7c8:      	blr	x8
    d7cc:      	ldr	x8, [sp, #0x98]
    d7d0:      	cmp	x8, x21
    d7d4:      	b.eq	0xd89c <generic_fentry_path+0x45dc>
    d7d8:      	mov	w8, #0x4                // =4
    d7dc:      	add	x9, sp, #0x78
    d7e0:      	add	x0, sp, #0x78
    d7e4:      	mov	w1, #0x8                // =8
    d7e8:      	mov	x2, x23
    d7ec:      	blr	x8
    d7f0:      	add	x2, x21, #0x20
    d7f4:      	mov	w8, #0x4                // =4
    d7f8:      	mov	w9, #0x10               // =16
    d7fc:      	add	x10, sp, #0x80
    d800:      	add	x0, sp, #0x80
    d804:      	mov	w1, #0x10               // =16
    d808:      	blr	x8
    d80c:      	ldr	w21, [sp, #0x84]
    d810:      	ldr	x8, [sp, #0x40]
    d814:      	ldr	x10, [sp, #0x60]
    d818:      	sub	x12, x10, x8
    d81c:      	ldr	w23, [sp, #0x68]
    d820:      	subs	w10, w21, w23
    d824:      	ldr	x9, [sp, #0x88]
    d828:      	csel	w10, wzr, w10, lo
    d82c:      	cmp	w23, w21
    d830:      	csel	w11, w23, w21, lo
    d834:      	cinc	w13, w11, hi
    d838:      	sub	w14, w23, w13
    d83c:      	subs	x12, x12, x13
    d840:      	str	w14, [sp, #0x68]
    d844:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    d848:      	cmp	x12, #0xfff
    d84c:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    d850:      	cmp	w23, w21
    d854:      	b.ls	0xd860 <generic_fentry_path+0x45a0>
    d858:      	mov	w13, #0x2f              // =47
    d85c:      	strb	w13, [x8, x12]
    d860:      	add	x19, x8, x12
    d864:      	cmp	w23, w21
    d868:      	add	x2, x9, x10
    d86c:      	and	w1, w11, #0xff
    d870:      	mov	w8, #0x4                // =4
    d874:      	cinc	x0, x19, hi
    d878:      	blr	x8
    d87c:      	cmp	w23, w21
    d880:      	str	x19, [sp, #0x60]
    d884:      	add	x19, sp, #0x70
    d888:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    d88c:      	ldr	x21, [sp, #0x78]
    d890:      	ldp	x2, x24, [sp, #0x50]
    d894:      	str	x21, [sp, #0x48]
    d898:      	b	0xd8e8 <generic_fentry_path+0x4628>
    d89c:      	add	x2, x24, #0x10
    d8a0:      	mov	w8, #0x4                // =4
    d8a4:      	add	x9, sp, #0x98
    d8a8:      	add	x0, sp, #0x98
    d8ac:      	mov	w1, #0x8                // =8
    d8b0:      	blr	x8
    d8b4:      	ldr	x8, [sp, #0x58]
    d8b8:      	ldr	x9, [sp, #0x98]
    d8bc:      	cmp	x8, x9
    d8c0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    d8c4:      	add	x2, x24, #0x18
    d8c8:      	mov	w8, #0x4                // =4
    d8cc:      	mov	x0, x22
    d8d0:      	mov	w1, #0x8                // =8
    d8d4:      	blr	x8
    d8d8:      	ldr	x24, [sp, #0x98]
    d8dc:      	ldr	x21, [sp, #0x48]
    d8e0:      	add	x2, x24, #0x20
    d8e4:      	stp	x2, x24, [sp, #0x50]
    d8e8:      	ldr	x8, [sp, #0x30]
    d8ec:      	cmp	x21, x8
    d8f0:      	b.ne	0xd900 <generic_fentry_path+0x4640>
    d8f4:      	ldr	x8, [sp, #0x38]
    d8f8:      	cmp	x2, x8
    d8fc:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    d900:      	mov	w8, #0x4                // =4
    d904:      	add	x0, sp, #0x70
    d908:      	mov	w1, #0x8                // =8
    d90c:      	blr	x8
    d910:      	ldr	x8, [sp, #0x70]
    d914:      	cmp	x21, x8
    d918:      	b.eq	0xda08 <generic_fentry_path+0x4748>
    d91c:      	add	x23, x21, #0x18
    d920:      	mov	w8, #0x4                // =4
    d924:      	add	x9, sp, #0x98
    d928:      	add	x0, sp, #0x98
    d92c:      	mov	w1, #0x8                // =8
    d930:      	mov	x2, x23
    d934:      	blr	x8
    d938:      	ldr	x8, [sp, #0x98]
    d93c:      	cmp	x8, x21
    d940:      	b.eq	0xda08 <generic_fentry_path+0x4748>
    d944:      	mov	w8, #0x4                // =4
    d948:      	add	x9, sp, #0x78
    d94c:      	add	x0, sp, #0x78
    d950:      	mov	w1, #0x8                // =8
    d954:      	mov	x2, x23
    d958:      	blr	x8
    d95c:      	add	x2, x21, #0x20
    d960:      	mov	w8, #0x4                // =4
    d964:      	mov	w9, #0x10               // =16
    d968:      	add	x10, sp, #0x80
    d96c:      	add	x0, sp, #0x80
    d970:      	mov	w1, #0x10               // =16
    d974:      	blr	x8
    d978:      	ldr	w21, [sp, #0x84]
    d97c:      	ldr	x8, [sp, #0x40]
    d980:      	ldr	x10, [sp, #0x60]
    d984:      	sub	x12, x10, x8
    d988:      	ldr	w23, [sp, #0x68]
    d98c:      	subs	w10, w21, w23
    d990:      	ldr	x9, [sp, #0x88]
    d994:      	csel	w10, wzr, w10, lo
    d998:      	cmp	w23, w21
    d99c:      	csel	w11, w23, w21, lo
    d9a0:      	cinc	w13, w11, hi
    d9a4:      	sub	w14, w23, w13
    d9a8:      	subs	x12, x12, x13
    d9ac:      	str	w14, [sp, #0x68]
    d9b0:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    d9b4:      	cmp	x12, #0xfff
    d9b8:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    d9bc:      	cmp	w23, w21
    d9c0:      	b.ls	0xd9cc <generic_fentry_path+0x470c>
    d9c4:      	mov	w13, #0x2f              // =47
    d9c8:      	strb	w13, [x8, x12]
    d9cc:      	add	x19, x8, x12
    d9d0:      	cmp	w23, w21
    d9d4:      	add	x2, x9, x10
    d9d8:      	and	w1, w11, #0xff
    d9dc:      	mov	w8, #0x4                // =4
    d9e0:      	cinc	x0, x19, hi
    d9e4:      	blr	x8
    d9e8:      	cmp	w23, w21
    d9ec:      	str	x19, [sp, #0x60]
    d9f0:      	add	x19, sp, #0x70
    d9f4:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    d9f8:      	ldr	x21, [sp, #0x78]
    d9fc:      	ldp	x2, x24, [sp, #0x50]
    da00:      	str	x21, [sp, #0x48]
    da04:      	b	0xda54 <generic_fentry_path+0x4794>
    da08:      	add	x2, x24, #0x10
    da0c:      	mov	w8, #0x4                // =4
    da10:      	add	x9, sp, #0x98
    da14:      	add	x0, sp, #0x98
    da18:      	mov	w1, #0x8                // =8
    da1c:      	blr	x8
    da20:      	ldr	x8, [sp, #0x58]
    da24:      	ldr	x9, [sp, #0x98]
    da28:      	cmp	x8, x9
    da2c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    da30:      	add	x2, x24, #0x18
    da34:      	mov	w8, #0x4                // =4
    da38:      	mov	x0, x22
    da3c:      	mov	w1, #0x8                // =8
    da40:      	blr	x8
    da44:      	ldr	x24, [sp, #0x98]
    da48:      	ldr	x21, [sp, #0x48]
    da4c:      	add	x2, x24, #0x20
    da50:      	stp	x2, x24, [sp, #0x50]
    da54:      	ldr	x8, [sp, #0x30]
    da58:      	cmp	x21, x8
    da5c:      	b.ne	0xda6c <generic_fentry_path+0x47ac>
    da60:      	ldr	x8, [sp, #0x38]
    da64:      	cmp	x2, x8
    da68:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    da6c:      	mov	w8, #0x4                // =4
    da70:      	add	x0, sp, #0x70
    da74:      	mov	w1, #0x8                // =8
    da78:      	blr	x8
    da7c:      	ldr	x8, [sp, #0x70]
    da80:      	cmp	x21, x8
    da84:      	b.eq	0xdb74 <generic_fentry_path+0x48b4>
    da88:      	add	x23, x21, #0x18
    da8c:      	mov	w8, #0x4                // =4
    da90:      	add	x9, sp, #0x98
    da94:      	add	x0, sp, #0x98
    da98:      	mov	w1, #0x8                // =8
    da9c:      	mov	x2, x23
    daa0:      	blr	x8
    daa4:      	ldr	x8, [sp, #0x98]
    daa8:      	cmp	x8, x21
    daac:      	b.eq	0xdb74 <generic_fentry_path+0x48b4>
    dab0:      	mov	w8, #0x4                // =4
    dab4:      	add	x9, sp, #0x78
    dab8:      	add	x0, sp, #0x78
    dabc:      	mov	w1, #0x8                // =8
    dac0:      	mov	x2, x23
    dac4:      	blr	x8
    dac8:      	add	x2, x21, #0x20
    dacc:      	mov	w8, #0x4                // =4
    dad0:      	mov	w9, #0x10               // =16
    dad4:      	add	x10, sp, #0x80
    dad8:      	add	x0, sp, #0x80
    dadc:      	mov	w1, #0x10               // =16
    dae0:      	blr	x8
    dae4:      	ldr	w21, [sp, #0x84]
    dae8:      	ldr	x8, [sp, #0x40]
    daec:      	ldr	x10, [sp, #0x60]
    daf0:      	sub	x12, x10, x8
    daf4:      	ldr	w23, [sp, #0x68]
    daf8:      	subs	w10, w21, w23
    dafc:      	ldr	x9, [sp, #0x88]
    db00:      	csel	w10, wzr, w10, lo
    db04:      	cmp	w23, w21
    db08:      	csel	w11, w23, w21, lo
    db0c:      	cinc	w13, w11, hi
    db10:      	sub	w14, w23, w13
    db14:      	subs	x12, x12, x13
    db18:      	str	w14, [sp, #0x68]
    db1c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    db20:      	cmp	x12, #0xfff
    db24:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    db28:      	cmp	w23, w21
    db2c:      	b.ls	0xdb38 <generic_fentry_path+0x4878>
    db30:      	mov	w13, #0x2f              // =47
    db34:      	strb	w13, [x8, x12]
    db38:      	add	x19, x8, x12
    db3c:      	cmp	w23, w21
    db40:      	add	x2, x9, x10
    db44:      	and	w1, w11, #0xff
    db48:      	mov	w8, #0x4                // =4
    db4c:      	cinc	x0, x19, hi
    db50:      	blr	x8
    db54:      	cmp	w23, w21
    db58:      	str	x19, [sp, #0x60]
    db5c:      	add	x19, sp, #0x70
    db60:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    db64:      	ldr	x21, [sp, #0x78]
    db68:      	ldp	x2, x24, [sp, #0x50]
    db6c:      	str	x21, [sp, #0x48]
    db70:      	b	0xdbc0 <generic_fentry_path+0x4900>
    db74:      	add	x2, x24, #0x10
    db78:      	mov	w8, #0x4                // =4
    db7c:      	add	x9, sp, #0x98
    db80:      	add	x0, sp, #0x98
    db84:      	mov	w1, #0x8                // =8
    db88:      	blr	x8
    db8c:      	ldr	x8, [sp, #0x58]
    db90:      	ldr	x9, [sp, #0x98]
    db94:      	cmp	x8, x9
    db98:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    db9c:      	add	x2, x24, #0x18
    dba0:      	mov	w8, #0x4                // =4
    dba4:      	mov	x0, x22
    dba8:      	mov	w1, #0x8                // =8
    dbac:      	blr	x8
    dbb0:      	ldr	x24, [sp, #0x98]
    dbb4:      	ldr	x21, [sp, #0x48]
    dbb8:      	add	x2, x24, #0x20
    dbbc:      	stp	x2, x24, [sp, #0x50]
    dbc0:      	ldr	x8, [sp, #0x30]
    dbc4:      	cmp	x21, x8
    dbc8:      	b.ne	0xdbd8 <generic_fentry_path+0x4918>
    dbcc:      	ldr	x8, [sp, #0x38]
    dbd0:      	cmp	x2, x8
    dbd4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    dbd8:      	mov	w8, #0x4                // =4
    dbdc:      	add	x0, sp, #0x70
    dbe0:      	mov	w1, #0x8                // =8
    dbe4:      	blr	x8
    dbe8:      	ldr	x8, [sp, #0x70]
    dbec:      	cmp	x21, x8
    dbf0:      	b.eq	0xdce0 <generic_fentry_path+0x4a20>
    dbf4:      	add	x23, x21, #0x18
    dbf8:      	mov	w8, #0x4                // =4
    dbfc:      	add	x9, sp, #0x98
    dc00:      	add	x0, sp, #0x98
    dc04:      	mov	w1, #0x8                // =8
    dc08:      	mov	x2, x23
    dc0c:      	blr	x8
    dc10:      	ldr	x8, [sp, #0x98]
    dc14:      	cmp	x8, x21
    dc18:      	b.eq	0xdce0 <generic_fentry_path+0x4a20>
    dc1c:      	mov	w8, #0x4                // =4
    dc20:      	add	x9, sp, #0x78
    dc24:      	add	x0, sp, #0x78
    dc28:      	mov	w1, #0x8                // =8
    dc2c:      	mov	x2, x23
    dc30:      	blr	x8
    dc34:      	add	x2, x21, #0x20
    dc38:      	mov	w8, #0x4                // =4
    dc3c:      	mov	w9, #0x10               // =16
    dc40:      	add	x10, sp, #0x80
    dc44:      	add	x0, sp, #0x80
    dc48:      	mov	w1, #0x10               // =16
    dc4c:      	blr	x8
    dc50:      	ldr	w21, [sp, #0x84]
    dc54:      	ldr	x8, [sp, #0x40]
    dc58:      	ldr	x10, [sp, #0x60]
    dc5c:      	sub	x12, x10, x8
    dc60:      	ldr	w23, [sp, #0x68]
    dc64:      	subs	w10, w21, w23
    dc68:      	ldr	x9, [sp, #0x88]
    dc6c:      	csel	w10, wzr, w10, lo
    dc70:      	cmp	w23, w21
    dc74:      	csel	w11, w23, w21, lo
    dc78:      	cinc	w13, w11, hi
    dc7c:      	sub	w14, w23, w13
    dc80:      	subs	x12, x12, x13
    dc84:      	str	w14, [sp, #0x68]
    dc88:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    dc8c:      	cmp	x12, #0xfff
    dc90:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    dc94:      	cmp	w23, w21
    dc98:      	b.ls	0xdca4 <generic_fentry_path+0x49e4>
    dc9c:      	mov	w13, #0x2f              // =47
    dca0:      	strb	w13, [x8, x12]
    dca4:      	add	x19, x8, x12
    dca8:      	cmp	w23, w21
    dcac:      	add	x2, x9, x10
    dcb0:      	and	w1, w11, #0xff
    dcb4:      	mov	w8, #0x4                // =4
    dcb8:      	cinc	x0, x19, hi
    dcbc:      	blr	x8
    dcc0:      	cmp	w23, w21
    dcc4:      	str	x19, [sp, #0x60]
    dcc8:      	add	x19, sp, #0x70
    dccc:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    dcd0:      	ldr	x21, [sp, #0x78]
    dcd4:      	ldp	x2, x24, [sp, #0x50]
    dcd8:      	str	x21, [sp, #0x48]
    dcdc:      	b	0xdd2c <generic_fentry_path+0x4a6c>
    dce0:      	add	x2, x24, #0x10
    dce4:      	mov	w8, #0x4                // =4
    dce8:      	add	x9, sp, #0x98
    dcec:      	add	x0, sp, #0x98
    dcf0:      	mov	w1, #0x8                // =8
    dcf4:      	blr	x8
    dcf8:      	ldr	x8, [sp, #0x58]
    dcfc:      	ldr	x9, [sp, #0x98]
    dd00:      	cmp	x8, x9
    dd04:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    dd08:      	add	x2, x24, #0x18
    dd0c:      	mov	w8, #0x4                // =4
    dd10:      	mov	x0, x22
    dd14:      	mov	w1, #0x8                // =8
    dd18:      	blr	x8
    dd1c:      	ldr	x24, [sp, #0x98]
    dd20:      	ldr	x21, [sp, #0x48]
    dd24:      	add	x2, x24, #0x20
    dd28:      	stp	x2, x24, [sp, #0x50]
    dd2c:      	ldr	x8, [sp, #0x30]
    dd30:      	cmp	x21, x8
    dd34:      	b.ne	0xdd44 <generic_fentry_path+0x4a84>
    dd38:      	ldr	x8, [sp, #0x38]
    dd3c:      	cmp	x2, x8
    dd40:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    dd44:      	mov	w8, #0x4                // =4
    dd48:      	add	x0, sp, #0x70
    dd4c:      	mov	w1, #0x8                // =8
    dd50:      	blr	x8
    dd54:      	ldr	x8, [sp, #0x70]
    dd58:      	cmp	x21, x8
    dd5c:      	b.eq	0xde4c <generic_fentry_path+0x4b8c>
    dd60:      	add	x23, x21, #0x18
    dd64:      	mov	w8, #0x4                // =4
    dd68:      	add	x9, sp, #0x98
    dd6c:      	add	x0, sp, #0x98
    dd70:      	mov	w1, #0x8                // =8
    dd74:      	mov	x2, x23
    dd78:      	blr	x8
    dd7c:      	ldr	x8, [sp, #0x98]
    dd80:      	cmp	x8, x21
    dd84:      	b.eq	0xde4c <generic_fentry_path+0x4b8c>
    dd88:      	mov	w8, #0x4                // =4
    dd8c:      	add	x9, sp, #0x78
    dd90:      	add	x0, sp, #0x78
    dd94:      	mov	w1, #0x8                // =8
    dd98:      	mov	x2, x23
    dd9c:      	blr	x8
    dda0:      	add	x2, x21, #0x20
    dda4:      	mov	w8, #0x4                // =4
    dda8:      	mov	w9, #0x10               // =16
    ddac:      	add	x10, sp, #0x80
    ddb0:      	add	x0, sp, #0x80
    ddb4:      	mov	w1, #0x10               // =16
    ddb8:      	blr	x8
    ddbc:      	ldr	w21, [sp, #0x84]
    ddc0:      	ldr	x8, [sp, #0x40]
    ddc4:      	ldr	x10, [sp, #0x60]
    ddc8:      	sub	x12, x10, x8
    ddcc:      	ldr	w23, [sp, #0x68]
    ddd0:      	subs	w10, w21, w23
    ddd4:      	ldr	x9, [sp, #0x88]
    ddd8:      	csel	w10, wzr, w10, lo
    dddc:      	cmp	w23, w21
    dde0:      	csel	w11, w23, w21, lo
    dde4:      	cinc	w13, w11, hi
    dde8:      	sub	w14, w23, w13
    ddec:      	subs	x12, x12, x13
    ddf0:      	str	w14, [sp, #0x68]
    ddf4:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    ddf8:      	cmp	x12, #0xfff
    ddfc:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    de00:      	cmp	w23, w21
    de04:      	b.ls	0xde10 <generic_fentry_path+0x4b50>
    de08:      	mov	w13, #0x2f              // =47
    de0c:      	strb	w13, [x8, x12]
    de10:      	add	x19, x8, x12
    de14:      	cmp	w23, w21
    de18:      	add	x2, x9, x10
    de1c:      	and	w1, w11, #0xff
    de20:      	mov	w8, #0x4                // =4
    de24:      	cinc	x0, x19, hi
    de28:      	blr	x8
    de2c:      	cmp	w23, w21
    de30:      	str	x19, [sp, #0x60]
    de34:      	add	x19, sp, #0x70
    de38:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    de3c:      	ldr	x21, [sp, #0x78]
    de40:      	ldp	x2, x24, [sp, #0x50]
    de44:      	str	x21, [sp, #0x48]
    de48:      	b	0xde98 <generic_fentry_path+0x4bd8>
    de4c:      	add	x2, x24, #0x10
    de50:      	mov	w8, #0x4                // =4
    de54:      	add	x9, sp, #0x98
    de58:      	add	x0, sp, #0x98
    de5c:      	mov	w1, #0x8                // =8
    de60:      	blr	x8
    de64:      	ldr	x8, [sp, #0x58]
    de68:      	ldr	x9, [sp, #0x98]
    de6c:      	cmp	x8, x9
    de70:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    de74:      	add	x2, x24, #0x18
    de78:      	mov	w8, #0x4                // =4
    de7c:      	mov	x0, x22
    de80:      	mov	w1, #0x8                // =8
    de84:      	blr	x8
    de88:      	ldr	x24, [sp, #0x98]
    de8c:      	ldr	x21, [sp, #0x48]
    de90:      	add	x2, x24, #0x20
    de94:      	stp	x2, x24, [sp, #0x50]
    de98:      	ldr	x8, [sp, #0x30]
    de9c:      	cmp	x21, x8
    dea0:      	b.ne	0xdeb0 <generic_fentry_path+0x4bf0>
    dea4:      	ldr	x8, [sp, #0x38]
    dea8:      	cmp	x2, x8
    deac:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    deb0:      	mov	w8, #0x4                // =4
    deb4:      	add	x0, sp, #0x70
    deb8:      	mov	w1, #0x8                // =8
    debc:      	blr	x8
    dec0:      	ldr	x8, [sp, #0x70]
    dec4:      	cmp	x21, x8
    dec8:      	b.eq	0xdfb8 <generic_fentry_path+0x4cf8>
    decc:      	add	x23, x21, #0x18
    ded0:      	mov	w8, #0x4                // =4
    ded4:      	add	x9, sp, #0x98
    ded8:      	add	x0, sp, #0x98
    dedc:      	mov	w1, #0x8                // =8
    dee0:      	mov	x2, x23
    dee4:      	blr	x8
    dee8:      	ldr	x8, [sp, #0x98]
    deec:      	cmp	x8, x21
    def0:      	b.eq	0xdfb8 <generic_fentry_path+0x4cf8>
    def4:      	mov	w8, #0x4                // =4
    def8:      	add	x9, sp, #0x78
    defc:      	add	x0, sp, #0x78
    df00:      	mov	w1, #0x8                // =8
    df04:      	mov	x2, x23
    df08:      	blr	x8
    df0c:      	add	x2, x21, #0x20
    df10:      	mov	w8, #0x4                // =4
    df14:      	mov	w9, #0x10               // =16
    df18:      	add	x10, sp, #0x80
    df1c:      	add	x0, sp, #0x80
    df20:      	mov	w1, #0x10               // =16
    df24:      	blr	x8
    df28:      	ldr	w21, [sp, #0x84]
    df2c:      	ldr	x8, [sp, #0x40]
    df30:      	ldr	x10, [sp, #0x60]
    df34:      	sub	x12, x10, x8
    df38:      	ldr	w23, [sp, #0x68]
    df3c:      	subs	w10, w21, w23
    df40:      	ldr	x9, [sp, #0x88]
    df44:      	csel	w10, wzr, w10, lo
    df48:      	cmp	w23, w21
    df4c:      	csel	w11, w23, w21, lo
    df50:      	cinc	w13, w11, hi
    df54:      	sub	w14, w23, w13
    df58:      	subs	x12, x12, x13
    df5c:      	str	w14, [sp, #0x68]
    df60:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    df64:      	cmp	x12, #0xfff
    df68:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    df6c:      	cmp	w23, w21
    df70:      	b.ls	0xdf7c <generic_fentry_path+0x4cbc>
    df74:      	mov	w13, #0x2f              // =47
    df78:      	strb	w13, [x8, x12]
    df7c:      	add	x19, x8, x12
    df80:      	cmp	w23, w21
    df84:      	add	x2, x9, x10
    df88:      	and	w1, w11, #0xff
    df8c:      	mov	w8, #0x4                // =4
    df90:      	cinc	x0, x19, hi
    df94:      	blr	x8
    df98:      	cmp	w23, w21
    df9c:      	str	x19, [sp, #0x60]
    dfa0:      	add	x19, sp, #0x70
    dfa4:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    dfa8:      	ldr	x21, [sp, #0x78]
    dfac:      	ldp	x2, x24, [sp, #0x50]
    dfb0:      	str	x21, [sp, #0x48]
    dfb4:      	b	0xe004 <generic_fentry_path+0x4d44>
    dfb8:      	add	x2, x24, #0x10
    dfbc:      	mov	w8, #0x4                // =4
    dfc0:      	add	x9, sp, #0x98
    dfc4:      	add	x0, sp, #0x98
    dfc8:      	mov	w1, #0x8                // =8
    dfcc:      	blr	x8
    dfd0:      	ldr	x8, [sp, #0x58]
    dfd4:      	ldr	x9, [sp, #0x98]
    dfd8:      	cmp	x8, x9
    dfdc:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    dfe0:      	add	x2, x24, #0x18
    dfe4:      	mov	w8, #0x4                // =4
    dfe8:      	mov	x0, x22
    dfec:      	mov	w1, #0x8                // =8
    dff0:      	blr	x8
    dff4:      	ldr	x24, [sp, #0x98]
    dff8:      	ldr	x21, [sp, #0x48]
    dffc:      	add	x2, x24, #0x20
    e000:      	stp	x2, x24, [sp, #0x50]
    e004:      	ldr	x8, [sp, #0x30]
    e008:      	cmp	x21, x8
    e00c:      	b.ne	0xe01c <generic_fentry_path+0x4d5c>
    e010:      	ldr	x8, [sp, #0x38]
    e014:      	cmp	x2, x8
    e018:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    e01c:      	mov	w8, #0x4                // =4
    e020:      	add	x0, sp, #0x70
    e024:      	mov	w1, #0x8                // =8
    e028:      	blr	x8
    e02c:      	ldr	x8, [sp, #0x70]
    e030:      	cmp	x21, x8
    e034:      	b.eq	0xe124 <generic_fentry_path+0x4e64>
    e038:      	add	x23, x21, #0x18
    e03c:      	mov	w8, #0x4                // =4
    e040:      	add	x9, sp, #0x98
    e044:      	add	x0, sp, #0x98
    e048:      	mov	w1, #0x8                // =8
    e04c:      	mov	x2, x23
    e050:      	blr	x8
    e054:      	ldr	x8, [sp, #0x98]
    e058:      	cmp	x8, x21
    e05c:      	b.eq	0xe124 <generic_fentry_path+0x4e64>
    e060:      	mov	w8, #0x4                // =4
    e064:      	add	x9, sp, #0x78
    e068:      	add	x0, sp, #0x78
    e06c:      	mov	w1, #0x8                // =8
    e070:      	mov	x2, x23
    e074:      	blr	x8
    e078:      	add	x2, x21, #0x20
    e07c:      	mov	w8, #0x4                // =4
    e080:      	mov	w9, #0x10               // =16
    e084:      	add	x10, sp, #0x80
    e088:      	add	x0, sp, #0x80
    e08c:      	mov	w1, #0x10               // =16
    e090:      	blr	x8
    e094:      	ldr	w21, [sp, #0x84]
    e098:      	ldr	x8, [sp, #0x40]
    e09c:      	ldr	x10, [sp, #0x60]
    e0a0:      	sub	x12, x10, x8
    e0a4:      	ldr	w23, [sp, #0x68]
    e0a8:      	subs	w10, w21, w23
    e0ac:      	ldr	x9, [sp, #0x88]
    e0b0:      	csel	w10, wzr, w10, lo
    e0b4:      	cmp	w23, w21
    e0b8:      	csel	w11, w23, w21, lo
    e0bc:      	cinc	w13, w11, hi
    e0c0:      	sub	w14, w23, w13
    e0c4:      	subs	x12, x12, x13
    e0c8:      	str	w14, [sp, #0x68]
    e0cc:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    e0d0:      	cmp	x12, #0xfff
    e0d4:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    e0d8:      	cmp	w23, w21
    e0dc:      	b.ls	0xe0e8 <generic_fentry_path+0x4e28>
    e0e0:      	mov	w13, #0x2f              // =47
    e0e4:      	strb	w13, [x8, x12]
    e0e8:      	add	x19, x8, x12
    e0ec:      	cmp	w23, w21
    e0f0:      	add	x2, x9, x10
    e0f4:      	and	w1, w11, #0xff
    e0f8:      	mov	w8, #0x4                // =4
    e0fc:      	cinc	x0, x19, hi
    e100:      	blr	x8
    e104:      	cmp	w23, w21
    e108:      	str	x19, [sp, #0x60]
    e10c:      	add	x19, sp, #0x70
    e110:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    e114:      	ldr	x21, [sp, #0x78]
    e118:      	ldp	x2, x24, [sp, #0x50]
    e11c:      	str	x21, [sp, #0x48]
    e120:      	b	0xe170 <generic_fentry_path+0x4eb0>
    e124:      	add	x2, x24, #0x10
    e128:      	mov	w8, #0x4                // =4
    e12c:      	add	x9, sp, #0x98
    e130:      	add	x0, sp, #0x98
    e134:      	mov	w1, #0x8                // =8
    e138:      	blr	x8
    e13c:      	ldr	x8, [sp, #0x58]
    e140:      	ldr	x9, [sp, #0x98]
    e144:      	cmp	x8, x9
    e148:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    e14c:      	add	x2, x24, #0x18
    e150:      	mov	w8, #0x4                // =4
    e154:      	mov	x0, x22
    e158:      	mov	w1, #0x8                // =8
    e15c:      	blr	x8
    e160:      	ldr	x24, [sp, #0x98]
    e164:      	ldr	x21, [sp, #0x48]
    e168:      	add	x2, x24, #0x20
    e16c:      	stp	x2, x24, [sp, #0x50]
    e170:      	ldr	x8, [sp, #0x30]
    e174:      	cmp	x21, x8
    e178:      	b.ne	0xe188 <generic_fentry_path+0x4ec8>
    e17c:      	ldr	x8, [sp, #0x38]
    e180:      	cmp	x2, x8
    e184:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    e188:      	mov	w8, #0x4                // =4
    e18c:      	add	x0, sp, #0x70
    e190:      	mov	w1, #0x8                // =8
    e194:      	blr	x8
    e198:      	ldr	x8, [sp, #0x70]
    e19c:      	cmp	x21, x8
    e1a0:      	b.eq	0xe290 <generic_fentry_path+0x4fd0>
    e1a4:      	add	x23, x21, #0x18
    e1a8:      	mov	w8, #0x4                // =4
    e1ac:      	add	x9, sp, #0x98
    e1b0:      	add	x0, sp, #0x98
    e1b4:      	mov	w1, #0x8                // =8
    e1b8:      	mov	x2, x23
    e1bc:      	blr	x8
    e1c0:      	ldr	x8, [sp, #0x98]
    e1c4:      	cmp	x8, x21
    e1c8:      	b.eq	0xe290 <generic_fentry_path+0x4fd0>
    e1cc:      	mov	w8, #0x4                // =4
    e1d0:      	add	x9, sp, #0x78
    e1d4:      	add	x0, sp, #0x78
    e1d8:      	mov	w1, #0x8                // =8
    e1dc:      	mov	x2, x23
    e1e0:      	blr	x8
    e1e4:      	add	x2, x21, #0x20
    e1e8:      	mov	w8, #0x4                // =4
    e1ec:      	mov	w9, #0x10               // =16
    e1f0:      	add	x10, sp, #0x80
    e1f4:      	add	x0, sp, #0x80
    e1f8:      	mov	w1, #0x10               // =16
    e1fc:      	blr	x8
    e200:      	ldr	w21, [sp, #0x84]
    e204:      	ldr	x8, [sp, #0x40]
    e208:      	ldr	x10, [sp, #0x60]
    e20c:      	sub	x12, x10, x8
    e210:      	ldr	w23, [sp, #0x68]
    e214:      	subs	w10, w21, w23
    e218:      	ldr	x9, [sp, #0x88]
    e21c:      	csel	w10, wzr, w10, lo
    e220:      	cmp	w23, w21
    e224:      	csel	w11, w23, w21, lo
    e228:      	cinc	w13, w11, hi
    e22c:      	sub	w14, w23, w13
    e230:      	subs	x12, x12, x13
    e234:      	str	w14, [sp, #0x68]
    e238:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    e23c:      	cmp	x12, #0xfff
    e240:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    e244:      	cmp	w23, w21
    e248:      	b.ls	0xe254 <generic_fentry_path+0x4f94>
    e24c:      	mov	w13, #0x2f              // =47
    e250:      	strb	w13, [x8, x12]
    e254:      	add	x19, x8, x12
    e258:      	cmp	w23, w21
    e25c:      	add	x2, x9, x10
    e260:      	and	w1, w11, #0xff
    e264:      	mov	w8, #0x4                // =4
    e268:      	cinc	x0, x19, hi
    e26c:      	blr	x8
    e270:      	cmp	w23, w21
    e274:      	str	x19, [sp, #0x60]
    e278:      	add	x19, sp, #0x70
    e27c:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    e280:      	ldr	x21, [sp, #0x78]
    e284:      	ldp	x2, x24, [sp, #0x50]
    e288:      	str	x21, [sp, #0x48]
    e28c:      	b	0xe2dc <generic_fentry_path+0x501c>
    e290:      	add	x2, x24, #0x10
    e294:      	mov	w8, #0x4                // =4
    e298:      	add	x9, sp, #0x98
    e29c:      	add	x0, sp, #0x98
    e2a0:      	mov	w1, #0x8                // =8
    e2a4:      	blr	x8
    e2a8:      	ldr	x8, [sp, #0x58]
    e2ac:      	ldr	x9, [sp, #0x98]
    e2b0:      	cmp	x8, x9
    e2b4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    e2b8:      	add	x2, x24, #0x18
    e2bc:      	mov	w8, #0x4                // =4
    e2c0:      	mov	x0, x22
    e2c4:      	mov	w1, #0x8                // =8
    e2c8:      	blr	x8
    e2cc:      	ldr	x24, [sp, #0x98]
    e2d0:      	ldr	x21, [sp, #0x48]
    e2d4:      	add	x2, x24, #0x20
    e2d8:      	stp	x2, x24, [sp, #0x50]
    e2dc:      	ldr	x8, [sp, #0x30]
    e2e0:      	cmp	x21, x8
    e2e4:      	b.ne	0xe2f4 <generic_fentry_path+0x5034>
    e2e8:      	ldr	x8, [sp, #0x38]
    e2ec:      	cmp	x2, x8
    e2f0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    e2f4:      	mov	w8, #0x4                // =4
    e2f8:      	add	x0, sp, #0x70
    e2fc:      	mov	w1, #0x8                // =8
    e300:      	blr	x8
    e304:      	ldr	x8, [sp, #0x70]
    e308:      	cmp	x21, x8
    e30c:      	b.eq	0xe3fc <generic_fentry_path+0x513c>
    e310:      	add	x23, x21, #0x18
    e314:      	mov	w8, #0x4                // =4
    e318:      	add	x9, sp, #0x98
    e31c:      	add	x0, sp, #0x98
    e320:      	mov	w1, #0x8                // =8
    e324:      	mov	x2, x23
    e328:      	blr	x8
    e32c:      	ldr	x8, [sp, #0x98]
    e330:      	cmp	x8, x21
    e334:      	b.eq	0xe3fc <generic_fentry_path+0x513c>
    e338:      	mov	w8, #0x4                // =4
    e33c:      	add	x9, sp, #0x78
    e340:      	add	x0, sp, #0x78
    e344:      	mov	w1, #0x8                // =8
    e348:      	mov	x2, x23
    e34c:      	blr	x8
    e350:      	add	x2, x21, #0x20
    e354:      	mov	w8, #0x4                // =4
    e358:      	mov	w9, #0x10               // =16
    e35c:      	add	x10, sp, #0x80
    e360:      	add	x0, sp, #0x80
    e364:      	mov	w1, #0x10               // =16
    e368:      	blr	x8
    e36c:      	ldr	w21, [sp, #0x84]
    e370:      	ldr	x8, [sp, #0x40]
    e374:      	ldr	x10, [sp, #0x60]
    e378:      	sub	x12, x10, x8
    e37c:      	ldr	w23, [sp, #0x68]
    e380:      	subs	w10, w21, w23
    e384:      	ldr	x9, [sp, #0x88]
    e388:      	csel	w10, wzr, w10, lo
    e38c:      	cmp	w23, w21
    e390:      	csel	w11, w23, w21, lo
    e394:      	cinc	w13, w11, hi
    e398:      	sub	w14, w23, w13
    e39c:      	subs	x12, x12, x13
    e3a0:      	str	w14, [sp, #0x68]
    e3a4:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    e3a8:      	cmp	x12, #0xfff
    e3ac:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    e3b0:      	cmp	w23, w21
    e3b4:      	b.ls	0xe3c0 <generic_fentry_path+0x5100>
    e3b8:      	mov	w13, #0x2f              // =47
    e3bc:      	strb	w13, [x8, x12]
    e3c0:      	add	x19, x8, x12
    e3c4:      	cmp	w23, w21
    e3c8:      	add	x2, x9, x10
    e3cc:      	and	w1, w11, #0xff
    e3d0:      	mov	w8, #0x4                // =4
    e3d4:      	cinc	x0, x19, hi
    e3d8:      	blr	x8
    e3dc:      	cmp	w23, w21
    e3e0:      	str	x19, [sp, #0x60]
    e3e4:      	add	x19, sp, #0x70
    e3e8:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    e3ec:      	ldr	x21, [sp, #0x78]
    e3f0:      	ldp	x2, x24, [sp, #0x50]
    e3f4:      	str	x21, [sp, #0x48]
    e3f8:      	b	0xe448 <generic_fentry_path+0x5188>
    e3fc:      	add	x2, x24, #0x10
    e400:      	mov	w8, #0x4                // =4
    e404:      	add	x9, sp, #0x98
    e408:      	add	x0, sp, #0x98
    e40c:      	mov	w1, #0x8                // =8
    e410:      	blr	x8
    e414:      	ldr	x8, [sp, #0x58]
    e418:      	ldr	x9, [sp, #0x98]
    e41c:      	cmp	x8, x9
    e420:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    e424:      	add	x2, x24, #0x18
    e428:      	mov	w8, #0x4                // =4
    e42c:      	mov	x0, x22
    e430:      	mov	w1, #0x8                // =8
    e434:      	blr	x8
    e438:      	ldr	x24, [sp, #0x98]
    e43c:      	ldr	x21, [sp, #0x48]
    e440:      	add	x2, x24, #0x20
    e444:      	stp	x2, x24, [sp, #0x50]
    e448:      	ldr	x8, [sp, #0x30]
    e44c:      	cmp	x21, x8
    e450:      	b.ne	0xe460 <generic_fentry_path+0x51a0>
    e454:      	ldr	x8, [sp, #0x38]
    e458:      	cmp	x2, x8
    e45c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    e460:      	mov	w8, #0x4                // =4
    e464:      	add	x0, sp, #0x70
    e468:      	mov	w1, #0x8                // =8
    e46c:      	blr	x8
    e470:      	ldr	x8, [sp, #0x70]
    e474:      	cmp	x21, x8
    e478:      	b.eq	0xe568 <generic_fentry_path+0x52a8>
    e47c:      	add	x23, x21, #0x18
    e480:      	mov	w8, #0x4                // =4
    e484:      	add	x9, sp, #0x98
    e488:      	add	x0, sp, #0x98
    e48c:      	mov	w1, #0x8                // =8
    e490:      	mov	x2, x23
    e494:      	blr	x8
    e498:      	ldr	x8, [sp, #0x98]
    e49c:      	cmp	x8, x21
    e4a0:      	b.eq	0xe568 <generic_fentry_path+0x52a8>
    e4a4:      	mov	w8, #0x4                // =4
    e4a8:      	add	x9, sp, #0x78
    e4ac:      	add	x0, sp, #0x78
    e4b0:      	mov	w1, #0x8                // =8
    e4b4:      	mov	x2, x23
    e4b8:      	blr	x8
    e4bc:      	add	x2, x21, #0x20
    e4c0:      	mov	w8, #0x4                // =4
    e4c4:      	mov	w9, #0x10               // =16
    e4c8:      	add	x10, sp, #0x80
    e4cc:      	add	x0, sp, #0x80
    e4d0:      	mov	w1, #0x10               // =16
    e4d4:      	blr	x8
    e4d8:      	ldr	w21, [sp, #0x84]
    e4dc:      	ldr	x8, [sp, #0x40]
    e4e0:      	ldr	x10, [sp, #0x60]
    e4e4:      	sub	x12, x10, x8
    e4e8:      	ldr	w23, [sp, #0x68]
    e4ec:      	subs	w10, w21, w23
    e4f0:      	ldr	x9, [sp, #0x88]
    e4f4:      	csel	w10, wzr, w10, lo
    e4f8:      	cmp	w23, w21
    e4fc:      	csel	w11, w23, w21, lo
    e500:      	cinc	w13, w11, hi
    e504:      	sub	w14, w23, w13
    e508:      	subs	x12, x12, x13
    e50c:      	str	w14, [sp, #0x68]
    e510:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    e514:      	cmp	x12, #0xfff
    e518:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    e51c:      	cmp	w23, w21
    e520:      	b.ls	0xe52c <generic_fentry_path+0x526c>
    e524:      	mov	w13, #0x2f              // =47
    e528:      	strb	w13, [x8, x12]
    e52c:      	add	x19, x8, x12
    e530:      	cmp	w23, w21
    e534:      	add	x2, x9, x10
    e538:      	and	w1, w11, #0xff
    e53c:      	mov	w8, #0x4                // =4
    e540:      	cinc	x0, x19, hi
    e544:      	blr	x8
    e548:      	cmp	w23, w21
    e54c:      	str	x19, [sp, #0x60]
    e550:      	add	x19, sp, #0x70
    e554:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    e558:      	ldr	x21, [sp, #0x78]
    e55c:      	ldp	x2, x24, [sp, #0x50]
    e560:      	str	x21, [sp, #0x48]
    e564:      	b	0xe5b4 <generic_fentry_path+0x52f4>
    e568:      	add	x2, x24, #0x10
    e56c:      	mov	w8, #0x4                // =4
    e570:      	add	x9, sp, #0x98
    e574:      	add	x0, sp, #0x98
    e578:      	mov	w1, #0x8                // =8
    e57c:      	blr	x8
    e580:      	ldr	x8, [sp, #0x58]
    e584:      	ldr	x9, [sp, #0x98]
    e588:      	cmp	x8, x9
    e58c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    e590:      	add	x2, x24, #0x18
    e594:      	mov	w8, #0x4                // =4
    e598:      	mov	x0, x22
    e59c:      	mov	w1, #0x8                // =8
    e5a0:      	blr	x8
    e5a4:      	ldr	x24, [sp, #0x98]
    e5a8:      	ldr	x21, [sp, #0x48]
    e5ac:      	add	x2, x24, #0x20
    e5b0:      	stp	x2, x24, [sp, #0x50]
    e5b4:      	ldr	x8, [sp, #0x30]
    e5b8:      	cmp	x21, x8
    e5bc:      	b.ne	0xe5cc <generic_fentry_path+0x530c>
    e5c0:      	ldr	x8, [sp, #0x38]
    e5c4:      	cmp	x2, x8
    e5c8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    e5cc:      	mov	w8, #0x4                // =4
    e5d0:      	add	x0, sp, #0x70
    e5d4:      	mov	w1, #0x8                // =8
    e5d8:      	blr	x8
    e5dc:      	ldr	x8, [sp, #0x70]
    e5e0:      	cmp	x21, x8
    e5e4:      	b.eq	0xe6d4 <generic_fentry_path+0x5414>
    e5e8:      	add	x23, x21, #0x18
    e5ec:      	mov	w8, #0x4                // =4
    e5f0:      	add	x9, sp, #0x98
    e5f4:      	add	x0, sp, #0x98
    e5f8:      	mov	w1, #0x8                // =8
    e5fc:      	mov	x2, x23
    e600:      	blr	x8
    e604:      	ldr	x8, [sp, #0x98]
    e608:      	cmp	x8, x21
    e60c:      	b.eq	0xe6d4 <generic_fentry_path+0x5414>
    e610:      	mov	w8, #0x4                // =4
    e614:      	add	x9, sp, #0x78
    e618:      	add	x0, sp, #0x78
    e61c:      	mov	w1, #0x8                // =8
    e620:      	mov	x2, x23
    e624:      	blr	x8
    e628:      	add	x2, x21, #0x20
    e62c:      	mov	w8, #0x4                // =4
    e630:      	mov	w9, #0x10               // =16
    e634:      	add	x10, sp, #0x80
    e638:      	add	x0, sp, #0x80
    e63c:      	mov	w1, #0x10               // =16
    e640:      	blr	x8
    e644:      	ldr	w21, [sp, #0x84]
    e648:      	ldr	x8, [sp, #0x40]
    e64c:      	ldr	x10, [sp, #0x60]
    e650:      	sub	x12, x10, x8
    e654:      	ldr	w23, [sp, #0x68]
    e658:      	subs	w10, w21, w23
    e65c:      	ldr	x9, [sp, #0x88]
    e660:      	csel	w10, wzr, w10, lo
    e664:      	cmp	w23, w21
    e668:      	csel	w11, w23, w21, lo
    e66c:      	cinc	w13, w11, hi
    e670:      	sub	w14, w23, w13
    e674:      	subs	x12, x12, x13
    e678:      	str	w14, [sp, #0x68]
    e67c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    e680:      	cmp	x12, #0xfff
    e684:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    e688:      	cmp	w23, w21
    e68c:      	b.ls	0xe698 <generic_fentry_path+0x53d8>
    e690:      	mov	w13, #0x2f              // =47
    e694:      	strb	w13, [x8, x12]
    e698:      	add	x19, x8, x12
    e69c:      	cmp	w23, w21
    e6a0:      	add	x2, x9, x10
    e6a4:      	and	w1, w11, #0xff
    e6a8:      	mov	w8, #0x4                // =4
    e6ac:      	cinc	x0, x19, hi
    e6b0:      	blr	x8
    e6b4:      	cmp	w23, w21
    e6b8:      	str	x19, [sp, #0x60]
    e6bc:      	add	x19, sp, #0x70
    e6c0:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    e6c4:      	ldr	x21, [sp, #0x78]
    e6c8:      	ldp	x2, x24, [sp, #0x50]
    e6cc:      	str	x21, [sp, #0x48]
    e6d0:      	b	0xe720 <generic_fentry_path+0x5460>
    e6d4:      	add	x2, x24, #0x10
    e6d8:      	mov	w8, #0x4                // =4
    e6dc:      	add	x9, sp, #0x98
    e6e0:      	add	x0, sp, #0x98
    e6e4:      	mov	w1, #0x8                // =8
    e6e8:      	blr	x8
    e6ec:      	ldr	x8, [sp, #0x58]
    e6f0:      	ldr	x9, [sp, #0x98]
    e6f4:      	cmp	x8, x9
    e6f8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    e6fc:      	add	x2, x24, #0x18
    e700:      	mov	w8, #0x4                // =4
    e704:      	mov	x0, x22
    e708:      	mov	w1, #0x8                // =8
    e70c:      	blr	x8
    e710:      	ldr	x24, [sp, #0x98]
    e714:      	ldr	x21, [sp, #0x48]
    e718:      	add	x2, x24, #0x20
    e71c:      	stp	x2, x24, [sp, #0x50]
    e720:      	ldr	x8, [sp, #0x30]
    e724:      	cmp	x21, x8
    e728:      	b.ne	0xe738 <generic_fentry_path+0x5478>
    e72c:      	ldr	x8, [sp, #0x38]
    e730:      	cmp	x2, x8
    e734:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    e738:      	mov	w8, #0x4                // =4
    e73c:      	add	x0, sp, #0x70
    e740:      	mov	w1, #0x8                // =8
    e744:      	blr	x8
    e748:      	ldr	x8, [sp, #0x70]
    e74c:      	cmp	x21, x8
    e750:      	b.eq	0xe840 <generic_fentry_path+0x5580>
    e754:      	add	x23, x21, #0x18
    e758:      	mov	w8, #0x4                // =4
    e75c:      	add	x9, sp, #0x98
    e760:      	add	x0, sp, #0x98
    e764:      	mov	w1, #0x8                // =8
    e768:      	mov	x2, x23
    e76c:      	blr	x8
    e770:      	ldr	x8, [sp, #0x98]
    e774:      	cmp	x8, x21
    e778:      	b.eq	0xe840 <generic_fentry_path+0x5580>
    e77c:      	mov	w8, #0x4                // =4
    e780:      	add	x9, sp, #0x78
    e784:      	add	x0, sp, #0x78
    e788:      	mov	w1, #0x8                // =8
    e78c:      	mov	x2, x23
    e790:      	blr	x8
    e794:      	add	x2, x21, #0x20
    e798:      	mov	w8, #0x4                // =4
    e79c:      	mov	w9, #0x10               // =16
    e7a0:      	add	x10, sp, #0x80
    e7a4:      	add	x0, sp, #0x80
    e7a8:      	mov	w1, #0x10               // =16
    e7ac:      	blr	x8
    e7b0:      	ldr	w21, [sp, #0x84]
    e7b4:      	ldr	x8, [sp, #0x40]
    e7b8:      	ldr	x10, [sp, #0x60]
    e7bc:      	sub	x12, x10, x8
    e7c0:      	ldr	w23, [sp, #0x68]
    e7c4:      	subs	w10, w21, w23
    e7c8:      	ldr	x9, [sp, #0x88]
    e7cc:      	csel	w10, wzr, w10, lo
    e7d0:      	cmp	w23, w21
    e7d4:      	csel	w11, w23, w21, lo
    e7d8:      	cinc	w13, w11, hi
    e7dc:      	sub	w14, w23, w13
    e7e0:      	subs	x12, x12, x13
    e7e4:      	str	w14, [sp, #0x68]
    e7e8:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    e7ec:      	cmp	x12, #0xfff
    e7f0:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    e7f4:      	cmp	w23, w21
    e7f8:      	b.ls	0xe804 <generic_fentry_path+0x5544>
    e7fc:      	mov	w13, #0x2f              // =47
    e800:      	strb	w13, [x8, x12]
    e804:      	add	x19, x8, x12
    e808:      	cmp	w23, w21
    e80c:      	add	x2, x9, x10
    e810:      	and	w1, w11, #0xff
    e814:      	mov	w8, #0x4                // =4
    e818:      	cinc	x0, x19, hi
    e81c:      	blr	x8
    e820:      	cmp	w23, w21
    e824:      	str	x19, [sp, #0x60]
    e828:      	add	x19, sp, #0x70
    e82c:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    e830:      	ldr	x21, [sp, #0x78]
    e834:      	ldp	x2, x24, [sp, #0x50]
    e838:      	str	x21, [sp, #0x48]
    e83c:      	b	0xe88c <generic_fentry_path+0x55cc>
    e840:      	add	x2, x24, #0x10
    e844:      	mov	w8, #0x4                // =4
    e848:      	add	x9, sp, #0x98
    e84c:      	add	x0, sp, #0x98
    e850:      	mov	w1, #0x8                // =8
    e854:      	blr	x8
    e858:      	ldr	x8, [sp, #0x58]
    e85c:      	ldr	x9, [sp, #0x98]
    e860:      	cmp	x8, x9
    e864:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    e868:      	add	x2, x24, #0x18
    e86c:      	mov	w8, #0x4                // =4
    e870:      	mov	x0, x22
    e874:      	mov	w1, #0x8                // =8
    e878:      	blr	x8
    e87c:      	ldr	x24, [sp, #0x98]
    e880:      	ldr	x21, [sp, #0x48]
    e884:      	add	x2, x24, #0x20
    e888:      	stp	x2, x24, [sp, #0x50]
    e88c:      	ldr	x8, [sp, #0x30]
    e890:      	cmp	x21, x8
    e894:      	b.ne	0xe8a4 <generic_fentry_path+0x55e4>
    e898:      	ldr	x8, [sp, #0x38]
    e89c:      	cmp	x2, x8
    e8a0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    e8a4:      	mov	w8, #0x4                // =4
    e8a8:      	add	x0, sp, #0x70
    e8ac:      	mov	w1, #0x8                // =8
    e8b0:      	blr	x8
    e8b4:      	ldr	x8, [sp, #0x70]
    e8b8:      	cmp	x21, x8
    e8bc:      	b.eq	0xe9ac <generic_fentry_path+0x56ec>
    e8c0:      	add	x23, x21, #0x18
    e8c4:      	mov	w8, #0x4                // =4
    e8c8:      	add	x9, sp, #0x98
    e8cc:      	add	x0, sp, #0x98
    e8d0:      	mov	w1, #0x8                // =8
    e8d4:      	mov	x2, x23
    e8d8:      	blr	x8
    e8dc:      	ldr	x8, [sp, #0x98]
    e8e0:      	cmp	x8, x21
    e8e4:      	b.eq	0xe9ac <generic_fentry_path+0x56ec>
    e8e8:      	mov	w8, #0x4                // =4
    e8ec:      	add	x9, sp, #0x78
    e8f0:      	add	x0, sp, #0x78
    e8f4:      	mov	w1, #0x8                // =8
    e8f8:      	mov	x2, x23
    e8fc:      	blr	x8
    e900:      	add	x2, x21, #0x20
    e904:      	mov	w8, #0x4                // =4
    e908:      	mov	w9, #0x10               // =16
    e90c:      	add	x10, sp, #0x80
    e910:      	add	x0, sp, #0x80
    e914:      	mov	w1, #0x10               // =16
    e918:      	blr	x8
    e91c:      	ldr	w21, [sp, #0x84]
    e920:      	ldr	x8, [sp, #0x40]
    e924:      	ldr	x10, [sp, #0x60]
    e928:      	sub	x12, x10, x8
    e92c:      	ldr	w23, [sp, #0x68]
    e930:      	subs	w10, w21, w23
    e934:      	ldr	x9, [sp, #0x88]
    e938:      	csel	w10, wzr, w10, lo
    e93c:      	cmp	w23, w21
    e940:      	csel	w11, w23, w21, lo
    e944:      	cinc	w13, w11, hi
    e948:      	sub	w14, w23, w13
    e94c:      	subs	x12, x12, x13
    e950:      	str	w14, [sp, #0x68]
    e954:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    e958:      	cmp	x12, #0xfff
    e95c:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    e960:      	cmp	w23, w21
    e964:      	b.ls	0xe970 <generic_fentry_path+0x56b0>
    e968:      	mov	w13, #0x2f              // =47
    e96c:      	strb	w13, [x8, x12]
    e970:      	add	x19, x8, x12
    e974:      	cmp	w23, w21
    e978:      	add	x2, x9, x10
    e97c:      	and	w1, w11, #0xff
    e980:      	mov	w8, #0x4                // =4
    e984:      	cinc	x0, x19, hi
    e988:      	blr	x8
    e98c:      	cmp	w23, w21
    e990:      	str	x19, [sp, #0x60]
    e994:      	add	x19, sp, #0x70
    e998:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    e99c:      	ldr	x21, [sp, #0x78]
    e9a0:      	ldp	x2, x24, [sp, #0x50]
    e9a4:      	str	x21, [sp, #0x48]
    e9a8:      	b	0xe9f8 <generic_fentry_path+0x5738>
    e9ac:      	add	x2, x24, #0x10
    e9b0:      	mov	w8, #0x4                // =4
    e9b4:      	add	x9, sp, #0x98
    e9b8:      	add	x0, sp, #0x98
    e9bc:      	mov	w1, #0x8                // =8
    e9c0:      	blr	x8
    e9c4:      	ldr	x8, [sp, #0x58]
    e9c8:      	ldr	x9, [sp, #0x98]
    e9cc:      	cmp	x8, x9
    e9d0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    e9d4:      	add	x2, x24, #0x18
    e9d8:      	mov	w8, #0x4                // =4
    e9dc:      	mov	x0, x22
    e9e0:      	mov	w1, #0x8                // =8
    e9e4:      	blr	x8
    e9e8:      	ldr	x24, [sp, #0x98]
    e9ec:      	ldr	x21, [sp, #0x48]
    e9f0:      	add	x2, x24, #0x20
    e9f4:      	stp	x2, x24, [sp, #0x50]
    e9f8:      	ldr	x8, [sp, #0x30]
    e9fc:      	cmp	x21, x8
    ea00:      	b.ne	0xea10 <generic_fentry_path+0x5750>
    ea04:      	ldr	x8, [sp, #0x38]
    ea08:      	cmp	x2, x8
    ea0c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    ea10:      	mov	w8, #0x4                // =4
    ea14:      	add	x0, sp, #0x70
    ea18:      	mov	w1, #0x8                // =8
    ea1c:      	blr	x8
    ea20:      	ldr	x8, [sp, #0x70]
    ea24:      	cmp	x21, x8
    ea28:      	b.eq	0xeb18 <generic_fentry_path+0x5858>
    ea2c:      	add	x23, x21, #0x18
    ea30:      	mov	w8, #0x4                // =4
    ea34:      	add	x9, sp, #0x98
    ea38:      	add	x0, sp, #0x98
    ea3c:      	mov	w1, #0x8                // =8
    ea40:      	mov	x2, x23
    ea44:      	blr	x8
    ea48:      	ldr	x8, [sp, #0x98]
    ea4c:      	cmp	x8, x21
    ea50:      	b.eq	0xeb18 <generic_fentry_path+0x5858>
    ea54:      	mov	w8, #0x4                // =4
    ea58:      	add	x9, sp, #0x78
    ea5c:      	add	x0, sp, #0x78
    ea60:      	mov	w1, #0x8                // =8
    ea64:      	mov	x2, x23
    ea68:      	blr	x8
    ea6c:      	add	x2, x21, #0x20
    ea70:      	mov	w8, #0x4                // =4
    ea74:      	mov	w9, #0x10               // =16
    ea78:      	add	x10, sp, #0x80
    ea7c:      	add	x0, sp, #0x80
    ea80:      	mov	w1, #0x10               // =16
    ea84:      	blr	x8
    ea88:      	ldr	w21, [sp, #0x84]
    ea8c:      	ldr	x8, [sp, #0x40]
    ea90:      	ldr	x10, [sp, #0x60]
    ea94:      	sub	x12, x10, x8
    ea98:      	ldr	w23, [sp, #0x68]
    ea9c:      	subs	w10, w21, w23
    eaa0:      	ldr	x9, [sp, #0x88]
    eaa4:      	csel	w10, wzr, w10, lo
    eaa8:      	cmp	w23, w21
    eaac:      	csel	w11, w23, w21, lo
    eab0:      	cinc	w13, w11, hi
    eab4:      	sub	w14, w23, w13
    eab8:      	subs	x12, x12, x13
    eabc:      	str	w14, [sp, #0x68]
    eac0:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    eac4:      	cmp	x12, #0xfff
    eac8:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    eacc:      	cmp	w23, w21
    ead0:      	b.ls	0xeadc <generic_fentry_path+0x581c>
    ead4:      	mov	w13, #0x2f              // =47
    ead8:      	strb	w13, [x8, x12]
    eadc:      	add	x19, x8, x12
    eae0:      	cmp	w23, w21
    eae4:      	add	x2, x9, x10
    eae8:      	and	w1, w11, #0xff
    eaec:      	mov	w8, #0x4                // =4
    eaf0:      	cinc	x0, x19, hi
    eaf4:      	blr	x8
    eaf8:      	cmp	w23, w21
    eafc:      	str	x19, [sp, #0x60]
    eb00:      	add	x19, sp, #0x70
    eb04:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    eb08:      	ldr	x21, [sp, #0x78]
    eb0c:      	ldp	x2, x24, [sp, #0x50]
    eb10:      	str	x21, [sp, #0x48]
    eb14:      	b	0xeb64 <generic_fentry_path+0x58a4>
    eb18:      	add	x2, x24, #0x10
    eb1c:      	mov	w8, #0x4                // =4
    eb20:      	add	x9, sp, #0x98
    eb24:      	add	x0, sp, #0x98
    eb28:      	mov	w1, #0x8                // =8
    eb2c:      	blr	x8
    eb30:      	ldr	x8, [sp, #0x58]
    eb34:      	ldr	x9, [sp, #0x98]
    eb38:      	cmp	x8, x9
    eb3c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    eb40:      	add	x2, x24, #0x18
    eb44:      	mov	w8, #0x4                // =4
    eb48:      	mov	x0, x22
    eb4c:      	mov	w1, #0x8                // =8
    eb50:      	blr	x8
    eb54:      	ldr	x24, [sp, #0x98]
    eb58:      	ldr	x21, [sp, #0x48]
    eb5c:      	add	x2, x24, #0x20
    eb60:      	stp	x2, x24, [sp, #0x50]
    eb64:      	ldr	x8, [sp, #0x30]
    eb68:      	cmp	x21, x8
    eb6c:      	b.ne	0xeb7c <generic_fentry_path+0x58bc>
    eb70:      	ldr	x8, [sp, #0x38]
    eb74:      	cmp	x2, x8
    eb78:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    eb7c:      	mov	w8, #0x4                // =4
    eb80:      	add	x0, sp, #0x70
    eb84:      	mov	w1, #0x8                // =8
    eb88:      	blr	x8
    eb8c:      	ldr	x8, [sp, #0x70]
    eb90:      	cmp	x21, x8
    eb94:      	b.eq	0xec84 <generic_fentry_path+0x59c4>
    eb98:      	add	x23, x21, #0x18
    eb9c:      	mov	w8, #0x4                // =4
    eba0:      	add	x9, sp, #0x98
    eba4:      	add	x0, sp, #0x98
    eba8:      	mov	w1, #0x8                // =8
    ebac:      	mov	x2, x23
    ebb0:      	blr	x8
    ebb4:      	ldr	x8, [sp, #0x98]
    ebb8:      	cmp	x8, x21
    ebbc:      	b.eq	0xec84 <generic_fentry_path+0x59c4>
    ebc0:      	mov	w8, #0x4                // =4
    ebc4:      	add	x9, sp, #0x78
    ebc8:      	add	x0, sp, #0x78
    ebcc:      	mov	w1, #0x8                // =8
    ebd0:      	mov	x2, x23
    ebd4:      	blr	x8
    ebd8:      	add	x2, x21, #0x20
    ebdc:      	mov	w8, #0x4                // =4
    ebe0:      	mov	w9, #0x10               // =16
    ebe4:      	add	x10, sp, #0x80
    ebe8:      	add	x0, sp, #0x80
    ebec:      	mov	w1, #0x10               // =16
    ebf0:      	blr	x8
    ebf4:      	ldr	w21, [sp, #0x84]
    ebf8:      	ldr	x8, [sp, #0x40]
    ebfc:      	ldr	x10, [sp, #0x60]
    ec00:      	sub	x12, x10, x8
    ec04:      	ldr	w23, [sp, #0x68]
    ec08:      	subs	w10, w21, w23
    ec0c:      	ldr	x9, [sp, #0x88]
    ec10:      	csel	w10, wzr, w10, lo
    ec14:      	cmp	w23, w21
    ec18:      	csel	w11, w23, w21, lo
    ec1c:      	cinc	w13, w11, hi
    ec20:      	sub	w14, w23, w13
    ec24:      	subs	x12, x12, x13
    ec28:      	str	w14, [sp, #0x68]
    ec2c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    ec30:      	cmp	x12, #0xfff
    ec34:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    ec38:      	cmp	w23, w21
    ec3c:      	b.ls	0xec48 <generic_fentry_path+0x5988>
    ec40:      	mov	w13, #0x2f              // =47
    ec44:      	strb	w13, [x8, x12]
    ec48:      	add	x19, x8, x12
    ec4c:      	cmp	w23, w21
    ec50:      	add	x2, x9, x10
    ec54:      	and	w1, w11, #0xff
    ec58:      	mov	w8, #0x4                // =4
    ec5c:      	cinc	x0, x19, hi
    ec60:      	blr	x8
    ec64:      	cmp	w23, w21
    ec68:      	str	x19, [sp, #0x60]
    ec6c:      	add	x19, sp, #0x70
    ec70:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    ec74:      	ldr	x21, [sp, #0x78]
    ec78:      	ldp	x2, x24, [sp, #0x50]
    ec7c:      	str	x21, [sp, #0x48]
    ec80:      	b	0xecd0 <generic_fentry_path+0x5a10>
    ec84:      	add	x2, x24, #0x10
    ec88:      	mov	w8, #0x4                // =4
    ec8c:      	add	x9, sp, #0x98
    ec90:      	add	x0, sp, #0x98
    ec94:      	mov	w1, #0x8                // =8
    ec98:      	blr	x8
    ec9c:      	ldr	x8, [sp, #0x58]
    eca0:      	ldr	x9, [sp, #0x98]
    eca4:      	cmp	x8, x9
    eca8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    ecac:      	add	x2, x24, #0x18
    ecb0:      	mov	w8, #0x4                // =4
    ecb4:      	mov	x0, x22
    ecb8:      	mov	w1, #0x8                // =8
    ecbc:      	blr	x8
    ecc0:      	ldr	x24, [sp, #0x98]
    ecc4:      	ldr	x21, [sp, #0x48]
    ecc8:      	add	x2, x24, #0x20
    eccc:      	stp	x2, x24, [sp, #0x50]
    ecd0:      	ldr	x8, [sp, #0x30]
    ecd4:      	cmp	x21, x8
    ecd8:      	b.ne	0xece8 <generic_fentry_path+0x5a28>
    ecdc:      	ldr	x8, [sp, #0x38]
    ece0:      	cmp	x2, x8
    ece4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    ece8:      	mov	w8, #0x4                // =4
    ecec:      	add	x0, sp, #0x70
    ecf0:      	mov	w1, #0x8                // =8
    ecf4:      	blr	x8
    ecf8:      	ldr	x8, [sp, #0x70]
    ecfc:      	cmp	x21, x8
    ed00:      	b.eq	0xedf0 <generic_fentry_path+0x5b30>
    ed04:      	add	x23, x21, #0x18
    ed08:      	mov	w8, #0x4                // =4
    ed0c:      	add	x9, sp, #0x98
    ed10:      	add	x0, sp, #0x98
    ed14:      	mov	w1, #0x8                // =8
    ed18:      	mov	x2, x23
    ed1c:      	blr	x8
    ed20:      	ldr	x8, [sp, #0x98]
    ed24:      	cmp	x8, x21
    ed28:      	b.eq	0xedf0 <generic_fentry_path+0x5b30>
    ed2c:      	mov	w8, #0x4                // =4
    ed30:      	add	x9, sp, #0x78
    ed34:      	add	x0, sp, #0x78
    ed38:      	mov	w1, #0x8                // =8
    ed3c:      	mov	x2, x23
    ed40:      	blr	x8
    ed44:      	add	x2, x21, #0x20
    ed48:      	mov	w8, #0x4                // =4
    ed4c:      	mov	w9, #0x10               // =16
    ed50:      	add	x10, sp, #0x80
    ed54:      	add	x0, sp, #0x80
    ed58:      	mov	w1, #0x10               // =16
    ed5c:      	blr	x8
    ed60:      	ldr	w21, [sp, #0x84]
    ed64:      	ldr	x8, [sp, #0x40]
    ed68:      	ldr	x10, [sp, #0x60]
    ed6c:      	sub	x12, x10, x8
    ed70:      	ldr	w23, [sp, #0x68]
    ed74:      	subs	w10, w21, w23
    ed78:      	ldr	x9, [sp, #0x88]
    ed7c:      	csel	w10, wzr, w10, lo
    ed80:      	cmp	w23, w21
    ed84:      	csel	w11, w23, w21, lo
    ed88:      	cinc	w13, w11, hi
    ed8c:      	sub	w14, w23, w13
    ed90:      	subs	x12, x12, x13
    ed94:      	str	w14, [sp, #0x68]
    ed98:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    ed9c:      	cmp	x12, #0xfff
    eda0:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    eda4:      	cmp	w23, w21
    eda8:      	b.ls	0xedb4 <generic_fentry_path+0x5af4>
    edac:      	mov	w13, #0x2f              // =47
    edb0:      	strb	w13, [x8, x12]
    edb4:      	add	x19, x8, x12
    edb8:      	cmp	w23, w21
    edbc:      	add	x2, x9, x10
    edc0:      	and	w1, w11, #0xff
    edc4:      	mov	w8, #0x4                // =4
    edc8:      	cinc	x0, x19, hi
    edcc:      	blr	x8
    edd0:      	cmp	w23, w21
    edd4:      	str	x19, [sp, #0x60]
    edd8:      	add	x19, sp, #0x70
    eddc:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    ede0:      	ldr	x21, [sp, #0x78]
    ede4:      	ldp	x2, x24, [sp, #0x50]
    ede8:      	str	x21, [sp, #0x48]
    edec:      	b	0xee3c <generic_fentry_path+0x5b7c>
    edf0:      	add	x2, x24, #0x10
    edf4:      	mov	w8, #0x4                // =4
    edf8:      	add	x9, sp, #0x98
    edfc:      	add	x0, sp, #0x98
    ee00:      	mov	w1, #0x8                // =8
    ee04:      	blr	x8
    ee08:      	ldr	x8, [sp, #0x58]
    ee0c:      	ldr	x9, [sp, #0x98]
    ee10:      	cmp	x8, x9
    ee14:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    ee18:      	add	x2, x24, #0x18
    ee1c:      	mov	w8, #0x4                // =4
    ee20:      	mov	x0, x22
    ee24:      	mov	w1, #0x8                // =8
    ee28:      	blr	x8
    ee2c:      	ldr	x24, [sp, #0x98]
    ee30:      	ldr	x21, [sp, #0x48]
    ee34:      	add	x2, x24, #0x20
    ee38:      	stp	x2, x24, [sp, #0x50]
    ee3c:      	ldr	x8, [sp, #0x30]
    ee40:      	cmp	x21, x8
    ee44:      	b.ne	0xee54 <generic_fentry_path+0x5b94>
    ee48:      	ldr	x8, [sp, #0x38]
    ee4c:      	cmp	x2, x8
    ee50:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    ee54:      	mov	w8, #0x4                // =4
    ee58:      	add	x0, sp, #0x70
    ee5c:      	mov	w1, #0x8                // =8
    ee60:      	blr	x8
    ee64:      	ldr	x8, [sp, #0x70]
    ee68:      	cmp	x21, x8
    ee6c:      	b.eq	0xef5c <generic_fentry_path+0x5c9c>
    ee70:      	add	x23, x21, #0x18
    ee74:      	mov	w8, #0x4                // =4
    ee78:      	add	x9, sp, #0x98
    ee7c:      	add	x0, sp, #0x98
    ee80:      	mov	w1, #0x8                // =8
    ee84:      	mov	x2, x23
    ee88:      	blr	x8
    ee8c:      	ldr	x8, [sp, #0x98]
    ee90:      	cmp	x8, x21
    ee94:      	b.eq	0xef5c <generic_fentry_path+0x5c9c>
    ee98:      	mov	w8, #0x4                // =4
    ee9c:      	add	x9, sp, #0x78
    eea0:      	add	x0, sp, #0x78
    eea4:      	mov	w1, #0x8                // =8
    eea8:      	mov	x2, x23
    eeac:      	blr	x8
    eeb0:      	add	x2, x21, #0x20
    eeb4:      	mov	w8, #0x4                // =4
    eeb8:      	mov	w9, #0x10               // =16
    eebc:      	add	x10, sp, #0x80
    eec0:      	add	x0, sp, #0x80
    eec4:      	mov	w1, #0x10               // =16
    eec8:      	blr	x8
    eecc:      	ldr	w21, [sp, #0x84]
    eed0:      	ldr	x8, [sp, #0x40]
    eed4:      	ldr	x10, [sp, #0x60]
    eed8:      	sub	x12, x10, x8
    eedc:      	ldr	w23, [sp, #0x68]
    eee0:      	subs	w10, w21, w23
    eee4:      	ldr	x9, [sp, #0x88]
    eee8:      	csel	w10, wzr, w10, lo
    eeec:      	cmp	w23, w21
    eef0:      	csel	w11, w23, w21, lo
    eef4:      	cinc	w13, w11, hi
    eef8:      	sub	w14, w23, w13
    eefc:      	subs	x12, x12, x13
    ef00:      	str	w14, [sp, #0x68]
    ef04:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    ef08:      	cmp	x12, #0xfff
    ef0c:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    ef10:      	cmp	w23, w21
    ef14:      	b.ls	0xef20 <generic_fentry_path+0x5c60>
    ef18:      	mov	w13, #0x2f              // =47
    ef1c:      	strb	w13, [x8, x12]
    ef20:      	add	x19, x8, x12
    ef24:      	cmp	w23, w21
    ef28:      	add	x2, x9, x10
    ef2c:      	and	w1, w11, #0xff
    ef30:      	mov	w8, #0x4                // =4
    ef34:      	cinc	x0, x19, hi
    ef38:      	blr	x8
    ef3c:      	cmp	w23, w21
    ef40:      	str	x19, [sp, #0x60]
    ef44:      	add	x19, sp, #0x70
    ef48:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    ef4c:      	ldr	x21, [sp, #0x78]
    ef50:      	ldp	x2, x24, [sp, #0x50]
    ef54:      	str	x21, [sp, #0x48]
    ef58:      	b	0xefa8 <generic_fentry_path+0x5ce8>
    ef5c:      	add	x2, x24, #0x10
    ef60:      	mov	w8, #0x4                // =4
    ef64:      	add	x9, sp, #0x98
    ef68:      	add	x0, sp, #0x98
    ef6c:      	mov	w1, #0x8                // =8
    ef70:      	blr	x8
    ef74:      	ldr	x8, [sp, #0x58]
    ef78:      	ldr	x9, [sp, #0x98]
    ef7c:      	cmp	x8, x9
    ef80:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    ef84:      	add	x2, x24, #0x18
    ef88:      	mov	w8, #0x4                // =4
    ef8c:      	mov	x0, x22
    ef90:      	mov	w1, #0x8                // =8
    ef94:      	blr	x8
    ef98:      	ldr	x24, [sp, #0x98]
    ef9c:      	ldr	x21, [sp, #0x48]
    efa0:      	add	x2, x24, #0x20
    efa4:      	stp	x2, x24, [sp, #0x50]
    efa8:      	ldr	x8, [sp, #0x30]
    efac:      	cmp	x21, x8
    efb0:      	b.ne	0xefc0 <generic_fentry_path+0x5d00>
    efb4:      	ldr	x8, [sp, #0x38]
    efb8:      	cmp	x2, x8
    efbc:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    efc0:      	mov	w8, #0x4                // =4
    efc4:      	add	x0, sp, #0x70
    efc8:      	mov	w1, #0x8                // =8
    efcc:      	blr	x8
    efd0:      	ldr	x8, [sp, #0x70]
    efd4:      	cmp	x21, x8
    efd8:      	b.eq	0xf0c8 <generic_fentry_path+0x5e08>
    efdc:      	add	x23, x21, #0x18
    efe0:      	mov	w8, #0x4                // =4
    efe4:      	add	x9, sp, #0x98
    efe8:      	add	x0, sp, #0x98
    efec:      	mov	w1, #0x8                // =8
    eff0:      	mov	x2, x23
    eff4:      	blr	x8
    eff8:      	ldr	x8, [sp, #0x98]
    effc:      	cmp	x8, x21
    f000:      	b.eq	0xf0c8 <generic_fentry_path+0x5e08>
    f004:      	mov	w8, #0x4                // =4
    f008:      	add	x9, sp, #0x78
    f00c:      	add	x0, sp, #0x78
    f010:      	mov	w1, #0x8                // =8
    f014:      	mov	x2, x23
    f018:      	blr	x8
    f01c:      	add	x2, x21, #0x20
    f020:      	mov	w8, #0x4                // =4
    f024:      	mov	w9, #0x10               // =16
    f028:      	add	x10, sp, #0x80
    f02c:      	add	x0, sp, #0x80
    f030:      	mov	w1, #0x10               // =16
    f034:      	blr	x8
    f038:      	ldr	w21, [sp, #0x84]
    f03c:      	ldr	x8, [sp, #0x40]
    f040:      	ldr	x10, [sp, #0x60]
    f044:      	sub	x12, x10, x8
    f048:      	ldr	w23, [sp, #0x68]
    f04c:      	subs	w10, w21, w23
    f050:      	ldr	x9, [sp, #0x88]
    f054:      	csel	w10, wzr, w10, lo
    f058:      	cmp	w23, w21
    f05c:      	csel	w11, w23, w21, lo
    f060:      	cinc	w13, w11, hi
    f064:      	sub	w14, w23, w13
    f068:      	subs	x12, x12, x13
    f06c:      	str	w14, [sp, #0x68]
    f070:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    f074:      	cmp	x12, #0xfff
    f078:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    f07c:      	cmp	w23, w21
    f080:      	b.ls	0xf08c <generic_fentry_path+0x5dcc>
    f084:      	mov	w13, #0x2f              // =47
    f088:      	strb	w13, [x8, x12]
    f08c:      	add	x19, x8, x12
    f090:      	cmp	w23, w21
    f094:      	add	x2, x9, x10
    f098:      	and	w1, w11, #0xff
    f09c:      	mov	w8, #0x4                // =4
    f0a0:      	cinc	x0, x19, hi
    f0a4:      	blr	x8
    f0a8:      	cmp	w23, w21
    f0ac:      	str	x19, [sp, #0x60]
    f0b0:      	add	x19, sp, #0x70
    f0b4:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    f0b8:      	ldr	x21, [sp, #0x78]
    f0bc:      	ldp	x2, x24, [sp, #0x50]
    f0c0:      	str	x21, [sp, #0x48]
    f0c4:      	b	0xf114 <generic_fentry_path+0x5e54>
    f0c8:      	add	x2, x24, #0x10
    f0cc:      	mov	w8, #0x4                // =4
    f0d0:      	add	x9, sp, #0x98
    f0d4:      	add	x0, sp, #0x98
    f0d8:      	mov	w1, #0x8                // =8
    f0dc:      	blr	x8
    f0e0:      	ldr	x8, [sp, #0x58]
    f0e4:      	ldr	x9, [sp, #0x98]
    f0e8:      	cmp	x8, x9
    f0ec:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    f0f0:      	add	x2, x24, #0x18
    f0f4:      	mov	w8, #0x4                // =4
    f0f8:      	mov	x0, x22
    f0fc:      	mov	w1, #0x8                // =8
    f100:      	blr	x8
    f104:      	ldr	x24, [sp, #0x98]
    f108:      	ldr	x21, [sp, #0x48]
    f10c:      	add	x2, x24, #0x20
    f110:      	stp	x2, x24, [sp, #0x50]
    f114:      	ldr	x8, [sp, #0x30]
    f118:      	cmp	x21, x8
    f11c:      	b.ne	0xf12c <generic_fentry_path+0x5e6c>
    f120:      	ldr	x8, [sp, #0x38]
    f124:      	cmp	x2, x8
    f128:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    f12c:      	mov	w8, #0x4                // =4
    f130:      	add	x0, sp, #0x70
    f134:      	mov	w1, #0x8                // =8
    f138:      	blr	x8
    f13c:      	ldr	x8, [sp, #0x70]
    f140:      	cmp	x21, x8
    f144:      	b.eq	0xf234 <generic_fentry_path+0x5f74>
    f148:      	add	x23, x21, #0x18
    f14c:      	mov	w8, #0x4                // =4
    f150:      	add	x9, sp, #0x98
    f154:      	add	x0, sp, #0x98
    f158:      	mov	w1, #0x8                // =8
    f15c:      	mov	x2, x23
    f160:      	blr	x8
    f164:      	ldr	x8, [sp, #0x98]
    f168:      	cmp	x8, x21
    f16c:      	b.eq	0xf234 <generic_fentry_path+0x5f74>
    f170:      	mov	w8, #0x4                // =4
    f174:      	add	x9, sp, #0x78
    f178:      	add	x0, sp, #0x78
    f17c:      	mov	w1, #0x8                // =8
    f180:      	mov	x2, x23
    f184:      	blr	x8
    f188:      	add	x2, x21, #0x20
    f18c:      	mov	w8, #0x4                // =4
    f190:      	mov	w9, #0x10               // =16
    f194:      	add	x10, sp, #0x80
    f198:      	add	x0, sp, #0x80
    f19c:      	mov	w1, #0x10               // =16
    f1a0:      	blr	x8
    f1a4:      	ldr	w21, [sp, #0x84]
    f1a8:      	ldr	x8, [sp, #0x40]
    f1ac:      	ldr	x10, [sp, #0x60]
    f1b0:      	sub	x12, x10, x8
    f1b4:      	ldr	w23, [sp, #0x68]
    f1b8:      	subs	w10, w21, w23
    f1bc:      	ldr	x9, [sp, #0x88]
    f1c0:      	csel	w10, wzr, w10, lo
    f1c4:      	cmp	w23, w21
    f1c8:      	csel	w11, w23, w21, lo
    f1cc:      	cinc	w13, w11, hi
    f1d0:      	sub	w14, w23, w13
    f1d4:      	subs	x12, x12, x13
    f1d8:      	str	w14, [sp, #0x68]
    f1dc:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    f1e0:      	cmp	x12, #0xfff
    f1e4:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    f1e8:      	cmp	w23, w21
    f1ec:      	b.ls	0xf1f8 <generic_fentry_path+0x5f38>
    f1f0:      	mov	w13, #0x2f              // =47
    f1f4:      	strb	w13, [x8, x12]
    f1f8:      	add	x19, x8, x12
    f1fc:      	cmp	w23, w21
    f200:      	add	x2, x9, x10
    f204:      	and	w1, w11, #0xff
    f208:      	mov	w8, #0x4                // =4
    f20c:      	cinc	x0, x19, hi
    f210:      	blr	x8
    f214:      	cmp	w23, w21
    f218:      	str	x19, [sp, #0x60]
    f21c:      	add	x19, sp, #0x70
    f220:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    f224:      	ldr	x21, [sp, #0x78]
    f228:      	ldp	x2, x24, [sp, #0x50]
    f22c:      	str	x21, [sp, #0x48]
    f230:      	b	0xf280 <generic_fentry_path+0x5fc0>
    f234:      	add	x2, x24, #0x10
    f238:      	mov	w8, #0x4                // =4
    f23c:      	add	x9, sp, #0x98
    f240:      	add	x0, sp, #0x98
    f244:      	mov	w1, #0x8                // =8
    f248:      	blr	x8
    f24c:      	ldr	x8, [sp, #0x58]
    f250:      	ldr	x9, [sp, #0x98]
    f254:      	cmp	x8, x9
    f258:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    f25c:      	add	x2, x24, #0x18
    f260:      	mov	w8, #0x4                // =4
    f264:      	mov	x0, x22
    f268:      	mov	w1, #0x8                // =8
    f26c:      	blr	x8
    f270:      	ldr	x24, [sp, #0x98]
    f274:      	ldr	x21, [sp, #0x48]
    f278:      	add	x2, x24, #0x20
    f27c:      	stp	x2, x24, [sp, #0x50]
    f280:      	ldr	x8, [sp, #0x30]
    f284:      	cmp	x21, x8
    f288:      	b.ne	0xf298 <generic_fentry_path+0x5fd8>
    f28c:      	ldr	x8, [sp, #0x38]
    f290:      	cmp	x2, x8
    f294:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    f298:      	mov	w8, #0x4                // =4
    f29c:      	add	x0, sp, #0x70
    f2a0:      	mov	w1, #0x8                // =8
    f2a4:      	blr	x8
    f2a8:      	ldr	x8, [sp, #0x70]
    f2ac:      	cmp	x21, x8
    f2b0:      	b.eq	0xf3a0 <generic_fentry_path+0x60e0>
    f2b4:      	add	x23, x21, #0x18
    f2b8:      	mov	w8, #0x4                // =4
    f2bc:      	add	x9, sp, #0x98
    f2c0:      	add	x0, sp, #0x98
    f2c4:      	mov	w1, #0x8                // =8
    f2c8:      	mov	x2, x23
    f2cc:      	blr	x8
    f2d0:      	ldr	x8, [sp, #0x98]
    f2d4:      	cmp	x8, x21
    f2d8:      	b.eq	0xf3a0 <generic_fentry_path+0x60e0>
    f2dc:      	mov	w8, #0x4                // =4
    f2e0:      	add	x9, sp, #0x78
    f2e4:      	add	x0, sp, #0x78
    f2e8:      	mov	w1, #0x8                // =8
    f2ec:      	mov	x2, x23
    f2f0:      	blr	x8
    f2f4:      	add	x2, x21, #0x20
    f2f8:      	mov	w8, #0x4                // =4
    f2fc:      	mov	w9, #0x10               // =16
    f300:      	add	x10, sp, #0x80
    f304:      	add	x0, sp, #0x80
    f308:      	mov	w1, #0x10               // =16
    f30c:      	blr	x8
    f310:      	ldr	w21, [sp, #0x84]
    f314:      	ldr	x8, [sp, #0x40]
    f318:      	ldr	x10, [sp, #0x60]
    f31c:      	sub	x12, x10, x8
    f320:      	ldr	w23, [sp, #0x68]
    f324:      	subs	w10, w21, w23
    f328:      	ldr	x9, [sp, #0x88]
    f32c:      	csel	w10, wzr, w10, lo
    f330:      	cmp	w23, w21
    f334:      	csel	w11, w23, w21, lo
    f338:      	cinc	w13, w11, hi
    f33c:      	sub	w14, w23, w13
    f340:      	subs	x12, x12, x13
    f344:      	str	w14, [sp, #0x68]
    f348:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    f34c:      	cmp	x12, #0xfff
    f350:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    f354:      	cmp	w23, w21
    f358:      	b.ls	0xf364 <generic_fentry_path+0x60a4>
    f35c:      	mov	w13, #0x2f              // =47
    f360:      	strb	w13, [x8, x12]
    f364:      	add	x19, x8, x12
    f368:      	cmp	w23, w21
    f36c:      	add	x2, x9, x10
    f370:      	and	w1, w11, #0xff
    f374:      	mov	w8, #0x4                // =4
    f378:      	cinc	x0, x19, hi
    f37c:      	blr	x8
    f380:      	cmp	w23, w21
    f384:      	str	x19, [sp, #0x60]
    f388:      	add	x19, sp, #0x70
    f38c:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    f390:      	ldr	x21, [sp, #0x78]
    f394:      	ldp	x2, x24, [sp, #0x50]
    f398:      	str	x21, [sp, #0x48]
    f39c:      	b	0xf3ec <generic_fentry_path+0x612c>
    f3a0:      	add	x2, x24, #0x10
    f3a4:      	mov	w8, #0x4                // =4
    f3a8:      	add	x9, sp, #0x98
    f3ac:      	add	x0, sp, #0x98
    f3b0:      	mov	w1, #0x8                // =8
    f3b4:      	blr	x8
    f3b8:      	ldr	x8, [sp, #0x58]
    f3bc:      	ldr	x9, [sp, #0x98]
    f3c0:      	cmp	x8, x9
    f3c4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    f3c8:      	add	x2, x24, #0x18
    f3cc:      	mov	w8, #0x4                // =4
    f3d0:      	mov	x0, x22
    f3d4:      	mov	w1, #0x8                // =8
    f3d8:      	blr	x8
    f3dc:      	ldr	x24, [sp, #0x98]
    f3e0:      	ldr	x21, [sp, #0x48]
    f3e4:      	add	x2, x24, #0x20
    f3e8:      	stp	x2, x24, [sp, #0x50]
    f3ec:      	ldr	x8, [sp, #0x30]
    f3f0:      	cmp	x21, x8
    f3f4:      	b.ne	0xf404 <generic_fentry_path+0x6144>
    f3f8:      	ldr	x8, [sp, #0x38]
    f3fc:      	cmp	x2, x8
    f400:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    f404:      	mov	w8, #0x4                // =4
    f408:      	add	x0, sp, #0x70
    f40c:      	mov	w1, #0x8                // =8
    f410:      	blr	x8
    f414:      	ldr	x8, [sp, #0x70]
    f418:      	cmp	x21, x8
    f41c:      	b.eq	0xf50c <generic_fentry_path+0x624c>
    f420:      	add	x23, x21, #0x18
    f424:      	mov	w8, #0x4                // =4
    f428:      	add	x9, sp, #0x98
    f42c:      	add	x0, sp, #0x98
    f430:      	mov	w1, #0x8                // =8
    f434:      	mov	x2, x23
    f438:      	blr	x8
    f43c:      	ldr	x8, [sp, #0x98]
    f440:      	cmp	x8, x21
    f444:      	b.eq	0xf50c <generic_fentry_path+0x624c>
    f448:      	mov	w8, #0x4                // =4
    f44c:      	add	x9, sp, #0x78
    f450:      	add	x0, sp, #0x78
    f454:      	mov	w1, #0x8                // =8
    f458:      	mov	x2, x23
    f45c:      	blr	x8
    f460:      	add	x2, x21, #0x20
    f464:      	mov	w8, #0x4                // =4
    f468:      	mov	w9, #0x10               // =16
    f46c:      	add	x10, sp, #0x80
    f470:      	add	x0, sp, #0x80
    f474:      	mov	w1, #0x10               // =16
    f478:      	blr	x8
    f47c:      	ldr	w21, [sp, #0x84]
    f480:      	ldr	x8, [sp, #0x40]
    f484:      	ldr	x10, [sp, #0x60]
    f488:      	sub	x12, x10, x8
    f48c:      	ldr	w23, [sp, #0x68]
    f490:      	subs	w10, w21, w23
    f494:      	ldr	x9, [sp, #0x88]
    f498:      	csel	w10, wzr, w10, lo
    f49c:      	cmp	w23, w21
    f4a0:      	csel	w11, w23, w21, lo
    f4a4:      	cinc	w13, w11, hi
    f4a8:      	sub	w14, w23, w13
    f4ac:      	subs	x12, x12, x13
    f4b0:      	str	w14, [sp, #0x68]
    f4b4:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    f4b8:      	cmp	x12, #0xfff
    f4bc:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    f4c0:      	cmp	w23, w21
    f4c4:      	b.ls	0xf4d0 <generic_fentry_path+0x6210>
    f4c8:      	mov	w13, #0x2f              // =47
    f4cc:      	strb	w13, [x8, x12]
    f4d0:      	add	x19, x8, x12
    f4d4:      	cmp	w23, w21
    f4d8:      	add	x2, x9, x10
    f4dc:      	and	w1, w11, #0xff
    f4e0:      	mov	w8, #0x4                // =4
    f4e4:      	cinc	x0, x19, hi
    f4e8:      	blr	x8
    f4ec:      	cmp	w23, w21
    f4f0:      	str	x19, [sp, #0x60]
    f4f4:      	add	x19, sp, #0x70
    f4f8:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    f4fc:      	ldr	x21, [sp, #0x78]
    f500:      	ldp	x2, x24, [sp, #0x50]
    f504:      	str	x21, [sp, #0x48]
    f508:      	b	0xf558 <generic_fentry_path+0x6298>
    f50c:      	add	x2, x24, #0x10
    f510:      	mov	w8, #0x4                // =4
    f514:      	add	x9, sp, #0x98
    f518:      	add	x0, sp, #0x98
    f51c:      	mov	w1, #0x8                // =8
    f520:      	blr	x8
    f524:      	ldr	x8, [sp, #0x58]
    f528:      	ldr	x9, [sp, #0x98]
    f52c:      	cmp	x8, x9
    f530:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    f534:      	add	x2, x24, #0x18
    f538:      	mov	w8, #0x4                // =4
    f53c:      	mov	x0, x22
    f540:      	mov	w1, #0x8                // =8
    f544:      	blr	x8
    f548:      	ldr	x24, [sp, #0x98]
    f54c:      	ldr	x21, [sp, #0x48]
    f550:      	add	x2, x24, #0x20
    f554:      	stp	x2, x24, [sp, #0x50]
    f558:      	ldr	x8, [sp, #0x30]
    f55c:      	cmp	x21, x8
    f560:      	b.ne	0xf570 <generic_fentry_path+0x62b0>
    f564:      	ldr	x8, [sp, #0x38]
    f568:      	cmp	x2, x8
    f56c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    f570:      	mov	w8, #0x4                // =4
    f574:      	add	x0, sp, #0x70
    f578:      	mov	w1, #0x8                // =8
    f57c:      	blr	x8
    f580:      	ldr	x8, [sp, #0x70]
    f584:      	cmp	x21, x8
    f588:      	b.eq	0xf678 <generic_fentry_path+0x63b8>
    f58c:      	add	x23, x21, #0x18
    f590:      	mov	w8, #0x4                // =4
    f594:      	add	x9, sp, #0x98
    f598:      	add	x0, sp, #0x98
    f59c:      	mov	w1, #0x8                // =8
    f5a0:      	mov	x2, x23
    f5a4:      	blr	x8
    f5a8:      	ldr	x8, [sp, #0x98]
    f5ac:      	cmp	x8, x21
    f5b0:      	b.eq	0xf678 <generic_fentry_path+0x63b8>
    f5b4:      	mov	w8, #0x4                // =4
    f5b8:      	add	x9, sp, #0x78
    f5bc:      	add	x0, sp, #0x78
    f5c0:      	mov	w1, #0x8                // =8
    f5c4:      	mov	x2, x23
    f5c8:      	blr	x8
    f5cc:      	add	x2, x21, #0x20
    f5d0:      	mov	w8, #0x4                // =4
    f5d4:      	mov	w9, #0x10               // =16
    f5d8:      	add	x10, sp, #0x80
    f5dc:      	add	x0, sp, #0x80
    f5e0:      	mov	w1, #0x10               // =16
    f5e4:      	blr	x8
    f5e8:      	ldr	w21, [sp, #0x84]
    f5ec:      	ldr	x8, [sp, #0x40]
    f5f0:      	ldr	x10, [sp, #0x60]
    f5f4:      	sub	x12, x10, x8
    f5f8:      	ldr	w23, [sp, #0x68]
    f5fc:      	subs	w10, w21, w23
    f600:      	ldr	x9, [sp, #0x88]
    f604:      	csel	w10, wzr, w10, lo
    f608:      	cmp	w23, w21
    f60c:      	csel	w11, w23, w21, lo
    f610:      	cinc	w13, w11, hi
    f614:      	sub	w14, w23, w13
    f618:      	subs	x12, x12, x13
    f61c:      	str	w14, [sp, #0x68]
    f620:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    f624:      	cmp	x12, #0xfff
    f628:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    f62c:      	cmp	w23, w21
    f630:      	b.ls	0xf63c <generic_fentry_path+0x637c>
    f634:      	mov	w13, #0x2f              // =47
    f638:      	strb	w13, [x8, x12]
    f63c:      	add	x19, x8, x12
    f640:      	cmp	w23, w21
    f644:      	add	x2, x9, x10
    f648:      	and	w1, w11, #0xff
    f64c:      	mov	w8, #0x4                // =4
    f650:      	cinc	x0, x19, hi
    f654:      	blr	x8
    f658:      	cmp	w23, w21
    f65c:      	str	x19, [sp, #0x60]
    f660:      	add	x19, sp, #0x70
    f664:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    f668:      	ldr	x21, [sp, #0x78]
    f66c:      	ldp	x2, x24, [sp, #0x50]
    f670:      	str	x21, [sp, #0x48]
    f674:      	b	0xf6c4 <generic_fentry_path+0x6404>
    f678:      	add	x2, x24, #0x10
    f67c:      	mov	w8, #0x4                // =4
    f680:      	add	x9, sp, #0x98
    f684:      	add	x0, sp, #0x98
    f688:      	mov	w1, #0x8                // =8
    f68c:      	blr	x8
    f690:      	ldr	x8, [sp, #0x58]
    f694:      	ldr	x9, [sp, #0x98]
    f698:      	cmp	x8, x9
    f69c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    f6a0:      	add	x2, x24, #0x18
    f6a4:      	mov	w8, #0x4                // =4
    f6a8:      	mov	x0, x22
    f6ac:      	mov	w1, #0x8                // =8
    f6b0:      	blr	x8
    f6b4:      	ldr	x24, [sp, #0x98]
    f6b8:      	ldr	x21, [sp, #0x48]
    f6bc:      	add	x2, x24, #0x20
    f6c0:      	stp	x2, x24, [sp, #0x50]
    f6c4:      	ldr	x8, [sp, #0x30]
    f6c8:      	cmp	x21, x8
    f6cc:      	b.ne	0xf6dc <generic_fentry_path+0x641c>
    f6d0:      	ldr	x8, [sp, #0x38]
    f6d4:      	cmp	x2, x8
    f6d8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    f6dc:      	mov	w8, #0x4                // =4
    f6e0:      	add	x0, sp, #0x70
    f6e4:      	mov	w1, #0x8                // =8
    f6e8:      	blr	x8
    f6ec:      	ldr	x8, [sp, #0x70]
    f6f0:      	cmp	x21, x8
    f6f4:      	b.eq	0xf7e4 <generic_fentry_path+0x6524>
    f6f8:      	add	x23, x21, #0x18
    f6fc:      	mov	w8, #0x4                // =4
    f700:      	add	x9, sp, #0x98
    f704:      	add	x0, sp, #0x98
    f708:      	mov	w1, #0x8                // =8
    f70c:      	mov	x2, x23
    f710:      	blr	x8
    f714:      	ldr	x8, [sp, #0x98]
    f718:      	cmp	x8, x21
    f71c:      	b.eq	0xf7e4 <generic_fentry_path+0x6524>
    f720:      	mov	w8, #0x4                // =4
    f724:      	add	x9, sp, #0x78
    f728:      	add	x0, sp, #0x78
    f72c:      	mov	w1, #0x8                // =8
    f730:      	mov	x2, x23
    f734:      	blr	x8
    f738:      	add	x2, x21, #0x20
    f73c:      	mov	w8, #0x4                // =4
    f740:      	mov	w9, #0x10               // =16
    f744:      	add	x10, sp, #0x80
    f748:      	add	x0, sp, #0x80
    f74c:      	mov	w1, #0x10               // =16
    f750:      	blr	x8
    f754:      	ldr	w21, [sp, #0x84]
    f758:      	ldr	x8, [sp, #0x40]
    f75c:      	ldr	x10, [sp, #0x60]
    f760:      	sub	x12, x10, x8
    f764:      	ldr	w23, [sp, #0x68]
    f768:      	subs	w10, w21, w23
    f76c:      	ldr	x9, [sp, #0x88]
    f770:      	csel	w10, wzr, w10, lo
    f774:      	cmp	w23, w21
    f778:      	csel	w11, w23, w21, lo
    f77c:      	cinc	w13, w11, hi
    f780:      	sub	w14, w23, w13
    f784:      	subs	x12, x12, x13
    f788:      	str	w14, [sp, #0x68]
    f78c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    f790:      	cmp	x12, #0xfff
    f794:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    f798:      	cmp	w23, w21
    f79c:      	b.ls	0xf7a8 <generic_fentry_path+0x64e8>
    f7a0:      	mov	w13, #0x2f              // =47
    f7a4:      	strb	w13, [x8, x12]
    f7a8:      	add	x19, x8, x12
    f7ac:      	cmp	w23, w21
    f7b0:      	add	x2, x9, x10
    f7b4:      	and	w1, w11, #0xff
    f7b8:      	mov	w8, #0x4                // =4
    f7bc:      	cinc	x0, x19, hi
    f7c0:      	blr	x8
    f7c4:      	cmp	w23, w21
    f7c8:      	str	x19, [sp, #0x60]
    f7cc:      	add	x19, sp, #0x70
    f7d0:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    f7d4:      	ldr	x21, [sp, #0x78]
    f7d8:      	ldp	x2, x24, [sp, #0x50]
    f7dc:      	str	x21, [sp, #0x48]
    f7e0:      	b	0xf830 <generic_fentry_path+0x6570>
    f7e4:      	add	x2, x24, #0x10
    f7e8:      	mov	w8, #0x4                // =4
    f7ec:      	add	x9, sp, #0x98
    f7f0:      	add	x0, sp, #0x98
    f7f4:      	mov	w1, #0x8                // =8
    f7f8:      	blr	x8
    f7fc:      	ldr	x8, [sp, #0x58]
    f800:      	ldr	x9, [sp, #0x98]
    f804:      	cmp	x8, x9
    f808:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    f80c:      	add	x2, x24, #0x18
    f810:      	mov	w8, #0x4                // =4
    f814:      	mov	x0, x22
    f818:      	mov	w1, #0x8                // =8
    f81c:      	blr	x8
    f820:      	ldr	x24, [sp, #0x98]
    f824:      	ldr	x21, [sp, #0x48]
    f828:      	add	x2, x24, #0x20
    f82c:      	stp	x2, x24, [sp, #0x50]
    f830:      	ldr	x8, [sp, #0x30]
    f834:      	cmp	x21, x8
    f838:      	b.ne	0xf848 <generic_fentry_path+0x6588>
    f83c:      	ldr	x8, [sp, #0x38]
    f840:      	cmp	x2, x8
    f844:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    f848:      	mov	w8, #0x4                // =4
    f84c:      	add	x0, sp, #0x70
    f850:      	mov	w1, #0x8                // =8
    f854:      	blr	x8
    f858:      	ldr	x8, [sp, #0x70]
    f85c:      	cmp	x21, x8
    f860:      	b.eq	0xf950 <generic_fentry_path+0x6690>
    f864:      	add	x23, x21, #0x18
    f868:      	mov	w8, #0x4                // =4
    f86c:      	add	x9, sp, #0x98
    f870:      	add	x0, sp, #0x98
    f874:      	mov	w1, #0x8                // =8
    f878:      	mov	x2, x23
    f87c:      	blr	x8
    f880:      	ldr	x8, [sp, #0x98]
    f884:      	cmp	x8, x21
    f888:      	b.eq	0xf950 <generic_fentry_path+0x6690>
    f88c:      	mov	w8, #0x4                // =4
    f890:      	add	x9, sp, #0x78
    f894:      	add	x0, sp, #0x78
    f898:      	mov	w1, #0x8                // =8
    f89c:      	mov	x2, x23
    f8a0:      	blr	x8
    f8a4:      	add	x2, x21, #0x20
    f8a8:      	mov	w8, #0x4                // =4
    f8ac:      	mov	w9, #0x10               // =16
    f8b0:      	add	x10, sp, #0x80
    f8b4:      	add	x0, sp, #0x80
    f8b8:      	mov	w1, #0x10               // =16
    f8bc:      	blr	x8
    f8c0:      	ldr	w21, [sp, #0x84]
    f8c4:      	ldr	x8, [sp, #0x40]
    f8c8:      	ldr	x10, [sp, #0x60]
    f8cc:      	sub	x12, x10, x8
    f8d0:      	ldr	w23, [sp, #0x68]
    f8d4:      	subs	w10, w21, w23
    f8d8:      	ldr	x9, [sp, #0x88]
    f8dc:      	csel	w10, wzr, w10, lo
    f8e0:      	cmp	w23, w21
    f8e4:      	csel	w11, w23, w21, lo
    f8e8:      	cinc	w13, w11, hi
    f8ec:      	sub	w14, w23, w13
    f8f0:      	subs	x12, x12, x13
    f8f4:      	str	w14, [sp, #0x68]
    f8f8:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    f8fc:      	cmp	x12, #0xfff
    f900:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    f904:      	cmp	w23, w21
    f908:      	b.ls	0xf914 <generic_fentry_path+0x6654>
    f90c:      	mov	w13, #0x2f              // =47
    f910:      	strb	w13, [x8, x12]
    f914:      	add	x19, x8, x12
    f918:      	cmp	w23, w21
    f91c:      	add	x2, x9, x10
    f920:      	and	w1, w11, #0xff
    f924:      	mov	w8, #0x4                // =4
    f928:      	cinc	x0, x19, hi
    f92c:      	blr	x8
    f930:      	cmp	w23, w21
    f934:      	str	x19, [sp, #0x60]
    f938:      	add	x19, sp, #0x70
    f93c:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    f940:      	ldr	x21, [sp, #0x78]
    f944:      	ldp	x2, x24, [sp, #0x50]
    f948:      	str	x21, [sp, #0x48]
    f94c:      	b	0xf99c <generic_fentry_path+0x66dc>
    f950:      	add	x2, x24, #0x10
    f954:      	mov	w8, #0x4                // =4
    f958:      	add	x9, sp, #0x98
    f95c:      	add	x0, sp, #0x98
    f960:      	mov	w1, #0x8                // =8
    f964:      	blr	x8
    f968:      	ldr	x8, [sp, #0x58]
    f96c:      	ldr	x9, [sp, #0x98]
    f970:      	cmp	x8, x9
    f974:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    f978:      	add	x2, x24, #0x18
    f97c:      	mov	w8, #0x4                // =4
    f980:      	mov	x0, x22
    f984:      	mov	w1, #0x8                // =8
    f988:      	blr	x8
    f98c:      	ldr	x24, [sp, #0x98]
    f990:      	ldr	x21, [sp, #0x48]
    f994:      	add	x2, x24, #0x20
    f998:      	stp	x2, x24, [sp, #0x50]
    f99c:      	ldr	x8, [sp, #0x30]
    f9a0:      	cmp	x21, x8
    f9a4:      	b.ne	0xf9b4 <generic_fentry_path+0x66f4>
    f9a8:      	ldr	x8, [sp, #0x38]
    f9ac:      	cmp	x2, x8
    f9b0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    f9b4:      	mov	w8, #0x4                // =4
    f9b8:      	add	x0, sp, #0x70
    f9bc:      	mov	w1, #0x8                // =8
    f9c0:      	blr	x8
    f9c4:      	ldr	x8, [sp, #0x70]
    f9c8:      	cmp	x21, x8
    f9cc:      	b.eq	0xfabc <generic_fentry_path+0x67fc>
    f9d0:      	add	x23, x21, #0x18
    f9d4:      	mov	w8, #0x4                // =4
    f9d8:      	add	x9, sp, #0x98
    f9dc:      	add	x0, sp, #0x98
    f9e0:      	mov	w1, #0x8                // =8
    f9e4:      	mov	x2, x23
    f9e8:      	blr	x8
    f9ec:      	ldr	x8, [sp, #0x98]
    f9f0:      	cmp	x8, x21
    f9f4:      	b.eq	0xfabc <generic_fentry_path+0x67fc>
    f9f8:      	mov	w8, #0x4                // =4
    f9fc:      	add	x9, sp, #0x78
    fa00:      	add	x0, sp, #0x78
    fa04:      	mov	w1, #0x8                // =8
    fa08:      	mov	x2, x23
    fa0c:      	blr	x8
    fa10:      	add	x2, x21, #0x20
    fa14:      	mov	w8, #0x4                // =4
    fa18:      	mov	w9, #0x10               // =16
    fa1c:      	add	x10, sp, #0x80
    fa20:      	add	x0, sp, #0x80
    fa24:      	mov	w1, #0x10               // =16
    fa28:      	blr	x8
    fa2c:      	ldr	w21, [sp, #0x84]
    fa30:      	ldr	x8, [sp, #0x40]
    fa34:      	ldr	x10, [sp, #0x60]
    fa38:      	sub	x12, x10, x8
    fa3c:      	ldr	w23, [sp, #0x68]
    fa40:      	subs	w10, w21, w23
    fa44:      	ldr	x9, [sp, #0x88]
    fa48:      	csel	w10, wzr, w10, lo
    fa4c:      	cmp	w23, w21
    fa50:      	csel	w11, w23, w21, lo
    fa54:      	cinc	w13, w11, hi
    fa58:      	sub	w14, w23, w13
    fa5c:      	subs	x12, x12, x13
    fa60:      	str	w14, [sp, #0x68]
    fa64:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    fa68:      	cmp	x12, #0xfff
    fa6c:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    fa70:      	cmp	w23, w21
    fa74:      	b.ls	0xfa80 <generic_fentry_path+0x67c0>
    fa78:      	mov	w13, #0x2f              // =47
    fa7c:      	strb	w13, [x8, x12]
    fa80:      	add	x19, x8, x12
    fa84:      	cmp	w23, w21
    fa88:      	add	x2, x9, x10
    fa8c:      	and	w1, w11, #0xff
    fa90:      	mov	w8, #0x4                // =4
    fa94:      	cinc	x0, x19, hi
    fa98:      	blr	x8
    fa9c:      	cmp	w23, w21
    faa0:      	str	x19, [sp, #0x60]
    faa4:      	add	x19, sp, #0x70
    faa8:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    faac:      	ldr	x21, [sp, #0x78]
    fab0:      	ldp	x2, x24, [sp, #0x50]
    fab4:      	str	x21, [sp, #0x48]
    fab8:      	b	0xfb08 <generic_fentry_path+0x6848>
    fabc:      	add	x2, x24, #0x10
    fac0:      	mov	w8, #0x4                // =4
    fac4:      	add	x9, sp, #0x98
    fac8:      	add	x0, sp, #0x98
    facc:      	mov	w1, #0x8                // =8
    fad0:      	blr	x8
    fad4:      	ldr	x8, [sp, #0x58]
    fad8:      	ldr	x9, [sp, #0x98]
    fadc:      	cmp	x8, x9
    fae0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    fae4:      	add	x2, x24, #0x18
    fae8:      	mov	w8, #0x4                // =4
    faec:      	mov	x0, x22
    faf0:      	mov	w1, #0x8                // =8
    faf4:      	blr	x8
    faf8:      	ldr	x24, [sp, #0x98]
    fafc:      	ldr	x21, [sp, #0x48]
    fb00:      	add	x2, x24, #0x20
    fb04:      	stp	x2, x24, [sp, #0x50]
    fb08:      	ldr	x8, [sp, #0x30]
    fb0c:      	cmp	x21, x8
    fb10:      	b.ne	0xfb20 <generic_fentry_path+0x6860>
    fb14:      	ldr	x8, [sp, #0x38]
    fb18:      	cmp	x2, x8
    fb1c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    fb20:      	mov	w8, #0x4                // =4
    fb24:      	add	x0, sp, #0x70
    fb28:      	mov	w1, #0x8                // =8
    fb2c:      	blr	x8
    fb30:      	ldr	x8, [sp, #0x70]
    fb34:      	cmp	x21, x8
    fb38:      	b.eq	0xfc28 <generic_fentry_path+0x6968>
    fb3c:      	add	x23, x21, #0x18
    fb40:      	mov	w8, #0x4                // =4
    fb44:      	add	x9, sp, #0x98
    fb48:      	add	x0, sp, #0x98
    fb4c:      	mov	w1, #0x8                // =8
    fb50:      	mov	x2, x23
    fb54:      	blr	x8
    fb58:      	ldr	x8, [sp, #0x98]
    fb5c:      	cmp	x8, x21
    fb60:      	b.eq	0xfc28 <generic_fentry_path+0x6968>
    fb64:      	mov	w8, #0x4                // =4
    fb68:      	add	x9, sp, #0x78
    fb6c:      	add	x0, sp, #0x78
    fb70:      	mov	w1, #0x8                // =8
    fb74:      	mov	x2, x23
    fb78:      	blr	x8
    fb7c:      	add	x2, x21, #0x20
    fb80:      	mov	w8, #0x4                // =4
    fb84:      	mov	w9, #0x10               // =16
    fb88:      	add	x10, sp, #0x80
    fb8c:      	add	x0, sp, #0x80
    fb90:      	mov	w1, #0x10               // =16
    fb94:      	blr	x8
    fb98:      	ldr	w21, [sp, #0x84]
    fb9c:      	ldr	x8, [sp, #0x40]
    fba0:      	ldr	x10, [sp, #0x60]
    fba4:      	sub	x12, x10, x8
    fba8:      	ldr	w23, [sp, #0x68]
    fbac:      	subs	w10, w21, w23
    fbb0:      	ldr	x9, [sp, #0x88]
    fbb4:      	csel	w10, wzr, w10, lo
    fbb8:      	cmp	w23, w21
    fbbc:      	csel	w11, w23, w21, lo
    fbc0:      	cinc	w13, w11, hi
    fbc4:      	sub	w14, w23, w13
    fbc8:      	subs	x12, x12, x13
    fbcc:      	str	w14, [sp, #0x68]
    fbd0:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    fbd4:      	cmp	x12, #0xfff
    fbd8:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    fbdc:      	cmp	w23, w21
    fbe0:      	b.ls	0xfbec <generic_fentry_path+0x692c>
    fbe4:      	mov	w13, #0x2f              // =47
    fbe8:      	strb	w13, [x8, x12]
    fbec:      	add	x19, x8, x12
    fbf0:      	cmp	w23, w21
    fbf4:      	add	x2, x9, x10
    fbf8:      	and	w1, w11, #0xff
    fbfc:      	mov	w8, #0x4                // =4
    fc00:      	cinc	x0, x19, hi
    fc04:      	blr	x8
    fc08:      	cmp	w23, w21
    fc0c:      	str	x19, [sp, #0x60]
    fc10:      	add	x19, sp, #0x70
    fc14:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    fc18:      	ldr	x21, [sp, #0x78]
    fc1c:      	ldp	x2, x24, [sp, #0x50]
    fc20:      	str	x21, [sp, #0x48]
    fc24:      	b	0xfc74 <generic_fentry_path+0x69b4>
    fc28:      	add	x2, x24, #0x10
    fc2c:      	mov	w8, #0x4                // =4
    fc30:      	add	x9, sp, #0x98
    fc34:      	add	x0, sp, #0x98
    fc38:      	mov	w1, #0x8                // =8
    fc3c:      	blr	x8
    fc40:      	ldr	x8, [sp, #0x58]
    fc44:      	ldr	x9, [sp, #0x98]
    fc48:      	cmp	x8, x9
    fc4c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    fc50:      	add	x2, x24, #0x18
    fc54:      	mov	w8, #0x4                // =4
    fc58:      	mov	x0, x22
    fc5c:      	mov	w1, #0x8                // =8
    fc60:      	blr	x8
    fc64:      	ldr	x24, [sp, #0x98]
    fc68:      	ldr	x21, [sp, #0x48]
    fc6c:      	add	x2, x24, #0x20
    fc70:      	stp	x2, x24, [sp, #0x50]
    fc74:      	ldr	x8, [sp, #0x30]
    fc78:      	cmp	x21, x8
    fc7c:      	b.ne	0xfc8c <generic_fentry_path+0x69cc>
    fc80:      	ldr	x8, [sp, #0x38]
    fc84:      	cmp	x2, x8
    fc88:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    fc8c:      	mov	w8, #0x4                // =4
    fc90:      	add	x0, sp, #0x70
    fc94:      	mov	w1, #0x8                // =8
    fc98:      	blr	x8
    fc9c:      	ldr	x8, [sp, #0x70]
    fca0:      	cmp	x21, x8
    fca4:      	b.eq	0xfd94 <generic_fentry_path+0x6ad4>
    fca8:      	add	x23, x21, #0x18
    fcac:      	mov	w8, #0x4                // =4
    fcb0:      	add	x9, sp, #0x98
    fcb4:      	add	x0, sp, #0x98
    fcb8:      	mov	w1, #0x8                // =8
    fcbc:      	mov	x2, x23
    fcc0:      	blr	x8
    fcc4:      	ldr	x8, [sp, #0x98]
    fcc8:      	cmp	x8, x21
    fccc:      	b.eq	0xfd94 <generic_fentry_path+0x6ad4>
    fcd0:      	mov	w8, #0x4                // =4
    fcd4:      	add	x9, sp, #0x78
    fcd8:      	add	x0, sp, #0x78
    fcdc:      	mov	w1, #0x8                // =8
    fce0:      	mov	x2, x23
    fce4:      	blr	x8
    fce8:      	add	x2, x21, #0x20
    fcec:      	mov	w8, #0x4                // =4
    fcf0:      	mov	w9, #0x10               // =16
    fcf4:      	add	x10, sp, #0x80
    fcf8:      	add	x0, sp, #0x80
    fcfc:      	mov	w1, #0x10               // =16
    fd00:      	blr	x8
    fd04:      	ldr	w21, [sp, #0x84]
    fd08:      	ldr	x8, [sp, #0x40]
    fd0c:      	ldr	x10, [sp, #0x60]
    fd10:      	sub	x12, x10, x8
    fd14:      	ldr	w23, [sp, #0x68]
    fd18:      	subs	w10, w21, w23
    fd1c:      	ldr	x9, [sp, #0x88]
    fd20:      	csel	w10, wzr, w10, lo
    fd24:      	cmp	w23, w21
    fd28:      	csel	w11, w23, w21, lo
    fd2c:      	cinc	w13, w11, hi
    fd30:      	sub	w14, w23, w13
    fd34:      	subs	x12, x12, x13
    fd38:      	str	w14, [sp, #0x68]
    fd3c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    fd40:      	cmp	x12, #0xfff
    fd44:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    fd48:      	cmp	w23, w21
    fd4c:      	b.ls	0xfd58 <generic_fentry_path+0x6a98>
    fd50:      	mov	w13, #0x2f              // =47
    fd54:      	strb	w13, [x8, x12]
    fd58:      	add	x19, x8, x12
    fd5c:      	cmp	w23, w21
    fd60:      	add	x2, x9, x10
    fd64:      	and	w1, w11, #0xff
    fd68:      	mov	w8, #0x4                // =4
    fd6c:      	cinc	x0, x19, hi
    fd70:      	blr	x8
    fd74:      	cmp	w23, w21
    fd78:      	str	x19, [sp, #0x60]
    fd7c:      	add	x19, sp, #0x70
    fd80:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    fd84:      	ldr	x21, [sp, #0x78]
    fd88:      	ldp	x2, x24, [sp, #0x50]
    fd8c:      	str	x21, [sp, #0x48]
    fd90:      	b	0xfde0 <generic_fentry_path+0x6b20>
    fd94:      	add	x2, x24, #0x10
    fd98:      	mov	w8, #0x4                // =4
    fd9c:      	add	x9, sp, #0x98
    fda0:      	add	x0, sp, #0x98
    fda4:      	mov	w1, #0x8                // =8
    fda8:      	blr	x8
    fdac:      	ldr	x8, [sp, #0x58]
    fdb0:      	ldr	x9, [sp, #0x98]
    fdb4:      	cmp	x8, x9
    fdb8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    fdbc:      	add	x2, x24, #0x18
    fdc0:      	mov	w8, #0x4                // =4
    fdc4:      	mov	x0, x22
    fdc8:      	mov	w1, #0x8                // =8
    fdcc:      	blr	x8
    fdd0:      	ldr	x24, [sp, #0x98]
    fdd4:      	ldr	x21, [sp, #0x48]
    fdd8:      	add	x2, x24, #0x20
    fddc:      	stp	x2, x24, [sp, #0x50]
    fde0:      	ldr	x8, [sp, #0x30]
    fde4:      	cmp	x21, x8
    fde8:      	b.ne	0xfdf8 <generic_fentry_path+0x6b38>
    fdec:      	ldr	x8, [sp, #0x38]
    fdf0:      	cmp	x2, x8
    fdf4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    fdf8:      	mov	w8, #0x4                // =4
    fdfc:      	add	x0, sp, #0x70
    fe00:      	mov	w1, #0x8                // =8
    fe04:      	blr	x8
    fe08:      	ldr	x8, [sp, #0x70]
    fe0c:      	cmp	x21, x8
    fe10:      	b.eq	0xff00 <generic_fentry_path+0x6c40>
    fe14:      	add	x23, x21, #0x18
    fe18:      	mov	w8, #0x4                // =4
    fe1c:      	add	x9, sp, #0x98
    fe20:      	add	x0, sp, #0x98
    fe24:      	mov	w1, #0x8                // =8
    fe28:      	mov	x2, x23
    fe2c:      	blr	x8
    fe30:      	ldr	x8, [sp, #0x98]
    fe34:      	cmp	x8, x21
    fe38:      	b.eq	0xff00 <generic_fentry_path+0x6c40>
    fe3c:      	mov	w8, #0x4                // =4
    fe40:      	add	x9, sp, #0x78
    fe44:      	add	x0, sp, #0x78
    fe48:      	mov	w1, #0x8                // =8
    fe4c:      	mov	x2, x23
    fe50:      	blr	x8
    fe54:      	add	x2, x21, #0x20
    fe58:      	mov	w8, #0x4                // =4
    fe5c:      	mov	w9, #0x10               // =16
    fe60:      	add	x10, sp, #0x80
    fe64:      	add	x0, sp, #0x80
    fe68:      	mov	w1, #0x10               // =16
    fe6c:      	blr	x8
    fe70:      	ldr	w21, [sp, #0x84]
    fe74:      	ldr	x8, [sp, #0x40]
    fe78:      	ldr	x10, [sp, #0x60]
    fe7c:      	sub	x12, x10, x8
    fe80:      	ldr	w23, [sp, #0x68]
    fe84:      	subs	w10, w21, w23
    fe88:      	ldr	x9, [sp, #0x88]
    fe8c:      	csel	w10, wzr, w10, lo
    fe90:      	cmp	w23, w21
    fe94:      	csel	w11, w23, w21, lo
    fe98:      	cinc	w13, w11, hi
    fe9c:      	sub	w14, w23, w13
    fea0:      	subs	x12, x12, x13
    fea4:      	str	w14, [sp, #0x68]
    fea8:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
    feac:      	cmp	x12, #0xfff
    feb0:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
    feb4:      	cmp	w23, w21
    feb8:      	b.ls	0xfec4 <generic_fentry_path+0x6c04>
    febc:      	mov	w13, #0x2f              // =47
    fec0:      	strb	w13, [x8, x12]
    fec4:      	add	x19, x8, x12
    fec8:      	cmp	w23, w21
    fecc:      	add	x2, x9, x10
    fed0:      	and	w1, w11, #0xff
    fed4:      	mov	w8, #0x4                // =4
    fed8:      	cinc	x0, x19, hi
    fedc:      	blr	x8
    fee0:      	cmp	w23, w21
    fee4:      	str	x19, [sp, #0x60]
    fee8:      	add	x19, sp, #0x70
    feec:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
    fef0:      	ldr	x21, [sp, #0x78]
    fef4:      	ldp	x2, x24, [sp, #0x50]
    fef8:      	str	x21, [sp, #0x48]
    fefc:      	b	0xff4c <generic_fentry_path+0x6c8c>
    ff00:      	add	x2, x24, #0x10
    ff04:      	mov	w8, #0x4                // =4
    ff08:      	add	x9, sp, #0x98
    ff0c:      	add	x0, sp, #0x98
    ff10:      	mov	w1, #0x8                // =8
    ff14:      	blr	x8
    ff18:      	ldr	x8, [sp, #0x58]
    ff1c:      	ldr	x9, [sp, #0x98]
    ff20:      	cmp	x8, x9
    ff24:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    ff28:      	add	x2, x24, #0x18
    ff2c:      	mov	w8, #0x4                // =4
    ff30:      	mov	x0, x22
    ff34:      	mov	w1, #0x8                // =8
    ff38:      	blr	x8
    ff3c:      	ldr	x24, [sp, #0x98]
    ff40:      	ldr	x21, [sp, #0x48]
    ff44:      	add	x2, x24, #0x20
    ff48:      	stp	x2, x24, [sp, #0x50]
    ff4c:      	ldr	x8, [sp, #0x30]
    ff50:      	cmp	x21, x8
    ff54:      	b.ne	0xff64 <generic_fentry_path+0x6ca4>
    ff58:      	ldr	x8, [sp, #0x38]
    ff5c:      	cmp	x2, x8
    ff60:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
    ff64:      	mov	w8, #0x4                // =4
    ff68:      	add	x0, sp, #0x70
    ff6c:      	mov	w1, #0x8                // =8
    ff70:      	blr	x8
    ff74:      	ldr	x8, [sp, #0x70]
    ff78:      	cmp	x21, x8
    ff7c:      	b.eq	0x1006c <generic_fentry_path+0x6dac>
    ff80:      	add	x23, x21, #0x18
    ff84:      	mov	w8, #0x4                // =4
    ff88:      	add	x9, sp, #0x98
    ff8c:      	add	x0, sp, #0x98
    ff90:      	mov	w1, #0x8                // =8
    ff94:      	mov	x2, x23
    ff98:      	blr	x8
    ff9c:      	ldr	x8, [sp, #0x98]
    ffa0:      	cmp	x8, x21
    ffa4:      	b.eq	0x1006c <generic_fentry_path+0x6dac>
    ffa8:      	mov	w8, #0x4                // =4
    ffac:      	add	x9, sp, #0x78
    ffb0:      	add	x0, sp, #0x78
    ffb4:      	mov	w1, #0x8                // =8
    ffb8:      	mov	x2, x23
    ffbc:      	blr	x8
    ffc0:      	add	x2, x21, #0x20
    ffc4:      	mov	w8, #0x4                // =4
    ffc8:      	mov	w9, #0x10               // =16
    ffcc:      	add	x10, sp, #0x80
    ffd0:      	add	x0, sp, #0x80
    ffd4:      	mov	w1, #0x10               // =16
    ffd8:      	blr	x8
    ffdc:      	ldr	w21, [sp, #0x84]
    ffe0:      	ldr	x8, [sp, #0x40]
    ffe4:      	ldr	x10, [sp, #0x60]
    ffe8:      	sub	x12, x10, x8
    ffec:      	ldr	w23, [sp, #0x68]
    fff0:      	subs	w10, w21, w23
    fff4:      	ldr	x9, [sp, #0x88]
    fff8:      	csel	w10, wzr, w10, lo
    fffc:      	cmp	w23, w21
   10000:      	csel	w11, w23, w21, lo
   10004:      	cinc	w13, w11, hi
   10008:      	sub	w14, w23, w13
   1000c:      	subs	x12, x12, x13
   10010:      	str	w14, [sp, #0x68]
   10014:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   10018:      	cmp	x12, #0xfff
   1001c:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   10020:      	cmp	w23, w21
   10024:      	b.ls	0x10030 <generic_fentry_path+0x6d70>
   10028:      	mov	w13, #0x2f              // =47
   1002c:      	strb	w13, [x8, x12]
   10030:      	add	x19, x8, x12
   10034:      	cmp	w23, w21
   10038:      	add	x2, x9, x10
   1003c:      	and	w1, w11, #0xff
   10040:      	mov	w8, #0x4                // =4
   10044:      	cinc	x0, x19, hi
   10048:      	blr	x8
   1004c:      	cmp	w23, w21
   10050:      	str	x19, [sp, #0x60]
   10054:      	add	x19, sp, #0x70
   10058:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   1005c:      	ldr	x21, [sp, #0x78]
   10060:      	ldp	x2, x24, [sp, #0x50]
   10064:      	str	x21, [sp, #0x48]
   10068:      	b	0x100b8 <generic_fentry_path+0x6df8>
   1006c:      	add	x2, x24, #0x10
   10070:      	mov	w8, #0x4                // =4
   10074:      	add	x9, sp, #0x98
   10078:      	add	x0, sp, #0x98
   1007c:      	mov	w1, #0x8                // =8
   10080:      	blr	x8
   10084:      	ldr	x8, [sp, #0x58]
   10088:      	ldr	x9, [sp, #0x98]
   1008c:      	cmp	x8, x9
   10090:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   10094:      	add	x2, x24, #0x18
   10098:      	mov	w8, #0x4                // =4
   1009c:      	mov	x0, x22
   100a0:      	mov	w1, #0x8                // =8
   100a4:      	blr	x8
   100a8:      	ldr	x24, [sp, #0x98]
   100ac:      	ldr	x21, [sp, #0x48]
   100b0:      	add	x2, x24, #0x20
   100b4:      	stp	x2, x24, [sp, #0x50]
   100b8:      	ldr	x8, [sp, #0x30]
   100bc:      	cmp	x21, x8
   100c0:      	b.ne	0x100d0 <generic_fentry_path+0x6e10>
   100c4:      	ldr	x8, [sp, #0x38]
   100c8:      	cmp	x2, x8
   100cc:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   100d0:      	mov	w8, #0x4                // =4
   100d4:      	add	x0, sp, #0x70
   100d8:      	mov	w1, #0x8                // =8
   100dc:      	blr	x8
   100e0:      	ldr	x8, [sp, #0x70]
   100e4:      	cmp	x21, x8
   100e8:      	b.eq	0x101d8 <generic_fentry_path+0x6f18>
   100ec:      	add	x23, x21, #0x18
   100f0:      	mov	w8, #0x4                // =4
   100f4:      	add	x9, sp, #0x98
   100f8:      	add	x0, sp, #0x98
   100fc:      	mov	w1, #0x8                // =8
   10100:      	mov	x2, x23
   10104:      	blr	x8
   10108:      	ldr	x8, [sp, #0x98]
   1010c:      	cmp	x8, x21
   10110:      	b.eq	0x101d8 <generic_fentry_path+0x6f18>
   10114:      	mov	w8, #0x4                // =4
   10118:      	add	x9, sp, #0x78
   1011c:      	add	x0, sp, #0x78
   10120:      	mov	w1, #0x8                // =8
   10124:      	mov	x2, x23
   10128:      	blr	x8
   1012c:      	add	x2, x21, #0x20
   10130:      	mov	w8, #0x4                // =4
   10134:      	mov	w9, #0x10               // =16
   10138:      	add	x10, sp, #0x80
   1013c:      	add	x0, sp, #0x80
   10140:      	mov	w1, #0x10               // =16
   10144:      	blr	x8
   10148:      	ldr	w21, [sp, #0x84]
   1014c:      	ldr	x8, [sp, #0x40]
   10150:      	ldr	x10, [sp, #0x60]
   10154:      	sub	x12, x10, x8
   10158:      	ldr	w23, [sp, #0x68]
   1015c:      	subs	w10, w21, w23
   10160:      	ldr	x9, [sp, #0x88]
   10164:      	csel	w10, wzr, w10, lo
   10168:      	cmp	w23, w21
   1016c:      	csel	w11, w23, w21, lo
   10170:      	cinc	w13, w11, hi
   10174:      	sub	w14, w23, w13
   10178:      	subs	x12, x12, x13
   1017c:      	str	w14, [sp, #0x68]
   10180:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   10184:      	cmp	x12, #0xfff
   10188:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   1018c:      	cmp	w23, w21
   10190:      	b.ls	0x1019c <generic_fentry_path+0x6edc>
   10194:      	mov	w13, #0x2f              // =47
   10198:      	strb	w13, [x8, x12]
   1019c:      	add	x19, x8, x12
   101a0:      	cmp	w23, w21
   101a4:      	add	x2, x9, x10
   101a8:      	and	w1, w11, #0xff
   101ac:      	mov	w8, #0x4                // =4
   101b0:      	cinc	x0, x19, hi
   101b4:      	blr	x8
   101b8:      	cmp	w23, w21
   101bc:      	str	x19, [sp, #0x60]
   101c0:      	add	x19, sp, #0x70
   101c4:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   101c8:      	ldr	x21, [sp, #0x78]
   101cc:      	ldp	x2, x24, [sp, #0x50]
   101d0:      	str	x21, [sp, #0x48]
   101d4:      	b	0x10224 <generic_fentry_path+0x6f64>
   101d8:      	add	x2, x24, #0x10
   101dc:      	mov	w8, #0x4                // =4
   101e0:      	add	x9, sp, #0x98
   101e4:      	add	x0, sp, #0x98
   101e8:      	mov	w1, #0x8                // =8
   101ec:      	blr	x8
   101f0:      	ldr	x8, [sp, #0x58]
   101f4:      	ldr	x9, [sp, #0x98]
   101f8:      	cmp	x8, x9
   101fc:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   10200:      	add	x2, x24, #0x18
   10204:      	mov	w8, #0x4                // =4
   10208:      	mov	x0, x22
   1020c:      	mov	w1, #0x8                // =8
   10210:      	blr	x8
   10214:      	ldr	x24, [sp, #0x98]
   10218:      	ldr	x21, [sp, #0x48]
   1021c:      	add	x2, x24, #0x20
   10220:      	stp	x2, x24, [sp, #0x50]
   10224:      	ldr	x8, [sp, #0x30]
   10228:      	cmp	x21, x8
   1022c:      	b.ne	0x1023c <generic_fentry_path+0x6f7c>
   10230:      	ldr	x8, [sp, #0x38]
   10234:      	cmp	x2, x8
   10238:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   1023c:      	mov	w8, #0x4                // =4
   10240:      	add	x0, sp, #0x70
   10244:      	mov	w1, #0x8                // =8
   10248:      	blr	x8
   1024c:      	ldr	x8, [sp, #0x70]
   10250:      	cmp	x21, x8
   10254:      	b.eq	0x10344 <generic_fentry_path+0x7084>
   10258:      	add	x23, x21, #0x18
   1025c:      	mov	w8, #0x4                // =4
   10260:      	add	x9, sp, #0x98
   10264:      	add	x0, sp, #0x98
   10268:      	mov	w1, #0x8                // =8
   1026c:      	mov	x2, x23
   10270:      	blr	x8
   10274:      	ldr	x8, [sp, #0x98]
   10278:      	cmp	x8, x21
   1027c:      	b.eq	0x10344 <generic_fentry_path+0x7084>
   10280:      	mov	w8, #0x4                // =4
   10284:      	add	x9, sp, #0x78
   10288:      	add	x0, sp, #0x78
   1028c:      	mov	w1, #0x8                // =8
   10290:      	mov	x2, x23
   10294:      	blr	x8
   10298:      	add	x2, x21, #0x20
   1029c:      	mov	w8, #0x4                // =4
   102a0:      	mov	w9, #0x10               // =16
   102a4:      	add	x10, sp, #0x80
   102a8:      	add	x0, sp, #0x80
   102ac:      	mov	w1, #0x10               // =16
   102b0:      	blr	x8
   102b4:      	ldr	w21, [sp, #0x84]
   102b8:      	ldr	x8, [sp, #0x40]
   102bc:      	ldr	x10, [sp, #0x60]
   102c0:      	sub	x12, x10, x8
   102c4:      	ldr	w23, [sp, #0x68]
   102c8:      	subs	w10, w21, w23
   102cc:      	ldr	x9, [sp, #0x88]
   102d0:      	csel	w10, wzr, w10, lo
   102d4:      	cmp	w23, w21
   102d8:      	csel	w11, w23, w21, lo
   102dc:      	cinc	w13, w11, hi
   102e0:      	sub	w14, w23, w13
   102e4:      	subs	x12, x12, x13
   102e8:      	str	w14, [sp, #0x68]
   102ec:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   102f0:      	cmp	x12, #0xfff
   102f4:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   102f8:      	cmp	w23, w21
   102fc:      	b.ls	0x10308 <generic_fentry_path+0x7048>
   10300:      	mov	w13, #0x2f              // =47
   10304:      	strb	w13, [x8, x12]
   10308:      	add	x19, x8, x12
   1030c:      	cmp	w23, w21
   10310:      	add	x2, x9, x10
   10314:      	and	w1, w11, #0xff
   10318:      	mov	w8, #0x4                // =4
   1031c:      	cinc	x0, x19, hi
   10320:      	blr	x8
   10324:      	cmp	w23, w21
   10328:      	str	x19, [sp, #0x60]
   1032c:      	add	x19, sp, #0x70
   10330:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   10334:      	ldr	x21, [sp, #0x78]
   10338:      	ldp	x2, x24, [sp, #0x50]
   1033c:      	str	x21, [sp, #0x48]
   10340:      	b	0x10390 <generic_fentry_path+0x70d0>
   10344:      	add	x2, x24, #0x10
   10348:      	mov	w8, #0x4                // =4
   1034c:      	add	x9, sp, #0x98
   10350:      	add	x0, sp, #0x98
   10354:      	mov	w1, #0x8                // =8
   10358:      	blr	x8
   1035c:      	ldr	x8, [sp, #0x58]
   10360:      	ldr	x9, [sp, #0x98]
   10364:      	cmp	x8, x9
   10368:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   1036c:      	add	x2, x24, #0x18
   10370:      	mov	w8, #0x4                // =4
   10374:      	mov	x0, x22
   10378:      	mov	w1, #0x8                // =8
   1037c:      	blr	x8
   10380:      	ldr	x24, [sp, #0x98]
   10384:      	ldr	x21, [sp, #0x48]
   10388:      	add	x2, x24, #0x20
   1038c:      	stp	x2, x24, [sp, #0x50]
   10390:      	ldr	x8, [sp, #0x30]
   10394:      	cmp	x21, x8
   10398:      	b.ne	0x103a8 <generic_fentry_path+0x70e8>
   1039c:      	ldr	x8, [sp, #0x38]
   103a0:      	cmp	x2, x8
   103a4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   103a8:      	mov	w8, #0x4                // =4
   103ac:      	add	x0, sp, #0x70
   103b0:      	mov	w1, #0x8                // =8
   103b4:      	blr	x8
   103b8:      	ldr	x8, [sp, #0x70]
   103bc:      	cmp	x21, x8
   103c0:      	b.eq	0x104b0 <generic_fentry_path+0x71f0>
   103c4:      	add	x23, x21, #0x18
   103c8:      	mov	w8, #0x4                // =4
   103cc:      	add	x9, sp, #0x98
   103d0:      	add	x0, sp, #0x98
   103d4:      	mov	w1, #0x8                // =8
   103d8:      	mov	x2, x23
   103dc:      	blr	x8
   103e0:      	ldr	x8, [sp, #0x98]
   103e4:      	cmp	x8, x21
   103e8:      	b.eq	0x104b0 <generic_fentry_path+0x71f0>
   103ec:      	mov	w8, #0x4                // =4
   103f0:      	add	x9, sp, #0x78
   103f4:      	add	x0, sp, #0x78
   103f8:      	mov	w1, #0x8                // =8
   103fc:      	mov	x2, x23
   10400:      	blr	x8
   10404:      	add	x2, x21, #0x20
   10408:      	mov	w8, #0x4                // =4
   1040c:      	mov	w9, #0x10               // =16
   10410:      	add	x10, sp, #0x80
   10414:      	add	x0, sp, #0x80
   10418:      	mov	w1, #0x10               // =16
   1041c:      	blr	x8
   10420:      	ldr	w21, [sp, #0x84]
   10424:      	ldr	x8, [sp, #0x40]
   10428:      	ldr	x10, [sp, #0x60]
   1042c:      	sub	x12, x10, x8
   10430:      	ldr	w23, [sp, #0x68]
   10434:      	subs	w10, w21, w23
   10438:      	ldr	x9, [sp, #0x88]
   1043c:      	csel	w10, wzr, w10, lo
   10440:      	cmp	w23, w21
   10444:      	csel	w11, w23, w21, lo
   10448:      	cinc	w13, w11, hi
   1044c:      	sub	w14, w23, w13
   10450:      	subs	x12, x12, x13
   10454:      	str	w14, [sp, #0x68]
   10458:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   1045c:      	cmp	x12, #0xfff
   10460:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   10464:      	cmp	w23, w21
   10468:      	b.ls	0x10474 <generic_fentry_path+0x71b4>
   1046c:      	mov	w13, #0x2f              // =47
   10470:      	strb	w13, [x8, x12]
   10474:      	add	x19, x8, x12
   10478:      	cmp	w23, w21
   1047c:      	add	x2, x9, x10
   10480:      	and	w1, w11, #0xff
   10484:      	mov	w8, #0x4                // =4
   10488:      	cinc	x0, x19, hi
   1048c:      	blr	x8
   10490:      	cmp	w23, w21
   10494:      	str	x19, [sp, #0x60]
   10498:      	add	x19, sp, #0x70
   1049c:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   104a0:      	ldr	x21, [sp, #0x78]
   104a4:      	ldp	x2, x24, [sp, #0x50]
   104a8:      	str	x21, [sp, #0x48]
   104ac:      	b	0x104fc <generic_fentry_path+0x723c>
   104b0:      	add	x2, x24, #0x10
   104b4:      	mov	w8, #0x4                // =4
   104b8:      	add	x9, sp, #0x98
   104bc:      	add	x0, sp, #0x98
   104c0:      	mov	w1, #0x8                // =8
   104c4:      	blr	x8
   104c8:      	ldr	x8, [sp, #0x58]
   104cc:      	ldr	x9, [sp, #0x98]
   104d0:      	cmp	x8, x9
   104d4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   104d8:      	add	x2, x24, #0x18
   104dc:      	mov	w8, #0x4                // =4
   104e0:      	mov	x0, x22
   104e4:      	mov	w1, #0x8                // =8
   104e8:      	blr	x8
   104ec:      	ldr	x24, [sp, #0x98]
   104f0:      	ldr	x21, [sp, #0x48]
   104f4:      	add	x2, x24, #0x20
   104f8:      	stp	x2, x24, [sp, #0x50]
   104fc:      	ldr	x8, [sp, #0x30]
   10500:      	cmp	x21, x8
   10504:      	b.ne	0x10514 <generic_fentry_path+0x7254>
   10508:      	ldr	x8, [sp, #0x38]
   1050c:      	cmp	x2, x8
   10510:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   10514:      	mov	w8, #0x4                // =4
   10518:      	add	x0, sp, #0x70
   1051c:      	mov	w1, #0x8                // =8
   10520:      	blr	x8
   10524:      	ldr	x8, [sp, #0x70]
   10528:      	cmp	x21, x8
   1052c:      	b.eq	0x1061c <generic_fentry_path+0x735c>
   10530:      	add	x23, x21, #0x18
   10534:      	mov	w8, #0x4                // =4
   10538:      	add	x9, sp, #0x98
   1053c:      	add	x0, sp, #0x98
   10540:      	mov	w1, #0x8                // =8
   10544:      	mov	x2, x23
   10548:      	blr	x8
   1054c:      	ldr	x8, [sp, #0x98]
   10550:      	cmp	x8, x21
   10554:      	b.eq	0x1061c <generic_fentry_path+0x735c>
   10558:      	mov	w8, #0x4                // =4
   1055c:      	add	x9, sp, #0x78
   10560:      	add	x0, sp, #0x78
   10564:      	mov	w1, #0x8                // =8
   10568:      	mov	x2, x23
   1056c:      	blr	x8
   10570:      	add	x2, x21, #0x20
   10574:      	mov	w8, #0x4                // =4
   10578:      	mov	w9, #0x10               // =16
   1057c:      	add	x10, sp, #0x80
   10580:      	add	x0, sp, #0x80
   10584:      	mov	w1, #0x10               // =16
   10588:      	blr	x8
   1058c:      	ldr	w21, [sp, #0x84]
   10590:      	ldr	x8, [sp, #0x40]
   10594:      	ldr	x10, [sp, #0x60]
   10598:      	sub	x12, x10, x8
   1059c:      	ldr	w23, [sp, #0x68]
   105a0:      	subs	w10, w21, w23
   105a4:      	ldr	x9, [sp, #0x88]
   105a8:      	csel	w10, wzr, w10, lo
   105ac:      	cmp	w23, w21
   105b0:      	csel	w11, w23, w21, lo
   105b4:      	cinc	w13, w11, hi
   105b8:      	sub	w14, w23, w13
   105bc:      	subs	x12, x12, x13
   105c0:      	str	w14, [sp, #0x68]
   105c4:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   105c8:      	cmp	x12, #0xfff
   105cc:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   105d0:      	cmp	w23, w21
   105d4:      	b.ls	0x105e0 <generic_fentry_path+0x7320>
   105d8:      	mov	w13, #0x2f              // =47
   105dc:      	strb	w13, [x8, x12]
   105e0:      	add	x19, x8, x12
   105e4:      	cmp	w23, w21
   105e8:      	add	x2, x9, x10
   105ec:      	and	w1, w11, #0xff
   105f0:      	mov	w8, #0x4                // =4
   105f4:      	cinc	x0, x19, hi
   105f8:      	blr	x8
   105fc:      	cmp	w23, w21
   10600:      	str	x19, [sp, #0x60]
   10604:      	add	x19, sp, #0x70
   10608:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   1060c:      	ldr	x21, [sp, #0x78]
   10610:      	ldp	x2, x24, [sp, #0x50]
   10614:      	str	x21, [sp, #0x48]
   10618:      	b	0x10668 <generic_fentry_path+0x73a8>
   1061c:      	add	x2, x24, #0x10
   10620:      	mov	w8, #0x4                // =4
   10624:      	add	x9, sp, #0x98
   10628:      	add	x0, sp, #0x98
   1062c:      	mov	w1, #0x8                // =8
   10630:      	blr	x8
   10634:      	ldr	x8, [sp, #0x58]
   10638:      	ldr	x9, [sp, #0x98]
   1063c:      	cmp	x8, x9
   10640:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   10644:      	add	x2, x24, #0x18
   10648:      	mov	w8, #0x4                // =4
   1064c:      	mov	x0, x22
   10650:      	mov	w1, #0x8                // =8
   10654:      	blr	x8
   10658:      	ldr	x24, [sp, #0x98]
   1065c:      	ldr	x21, [sp, #0x48]
   10660:      	add	x2, x24, #0x20
   10664:      	stp	x2, x24, [sp, #0x50]
   10668:      	ldr	x8, [sp, #0x30]
   1066c:      	cmp	x21, x8
   10670:      	b.ne	0x10680 <generic_fentry_path+0x73c0>
   10674:      	ldr	x8, [sp, #0x38]
   10678:      	cmp	x2, x8
   1067c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   10680:      	mov	w8, #0x4                // =4
   10684:      	add	x0, sp, #0x70
   10688:      	mov	w1, #0x8                // =8
   1068c:      	blr	x8
   10690:      	ldr	x8, [sp, #0x70]
   10694:      	cmp	x21, x8
   10698:      	b.eq	0x10788 <generic_fentry_path+0x74c8>
   1069c:      	add	x23, x21, #0x18
   106a0:      	mov	w8, #0x4                // =4
   106a4:      	add	x9, sp, #0x98
   106a8:      	add	x0, sp, #0x98
   106ac:      	mov	w1, #0x8                // =8
   106b0:      	mov	x2, x23
   106b4:      	blr	x8
   106b8:      	ldr	x8, [sp, #0x98]
   106bc:      	cmp	x8, x21
   106c0:      	b.eq	0x10788 <generic_fentry_path+0x74c8>
   106c4:      	mov	w8, #0x4                // =4
   106c8:      	add	x9, sp, #0x78
   106cc:      	add	x0, sp, #0x78
   106d0:      	mov	w1, #0x8                // =8
   106d4:      	mov	x2, x23
   106d8:      	blr	x8
   106dc:      	add	x2, x21, #0x20
   106e0:      	mov	w8, #0x4                // =4
   106e4:      	mov	w9, #0x10               // =16
   106e8:      	add	x10, sp, #0x80
   106ec:      	add	x0, sp, #0x80
   106f0:      	mov	w1, #0x10               // =16
   106f4:      	blr	x8
   106f8:      	ldr	w21, [sp, #0x84]
   106fc:      	ldr	x8, [sp, #0x40]
   10700:      	ldr	x10, [sp, #0x60]
   10704:      	sub	x12, x10, x8
   10708:      	ldr	w23, [sp, #0x68]
   1070c:      	subs	w10, w21, w23
   10710:      	ldr	x9, [sp, #0x88]
   10714:      	csel	w10, wzr, w10, lo
   10718:      	cmp	w23, w21
   1071c:      	csel	w11, w23, w21, lo
   10720:      	cinc	w13, w11, hi
   10724:      	sub	w14, w23, w13
   10728:      	subs	x12, x12, x13
   1072c:      	str	w14, [sp, #0x68]
   10730:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   10734:      	cmp	x12, #0xfff
   10738:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   1073c:      	cmp	w23, w21
   10740:      	b.ls	0x1074c <generic_fentry_path+0x748c>
   10744:      	mov	w13, #0x2f              // =47
   10748:      	strb	w13, [x8, x12]
   1074c:      	add	x19, x8, x12
   10750:      	cmp	w23, w21
   10754:      	add	x2, x9, x10
   10758:      	and	w1, w11, #0xff
   1075c:      	mov	w8, #0x4                // =4
   10760:      	cinc	x0, x19, hi
   10764:      	blr	x8
   10768:      	cmp	w23, w21
   1076c:      	str	x19, [sp, #0x60]
   10770:      	add	x19, sp, #0x70
   10774:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   10778:      	ldr	x21, [sp, #0x78]
   1077c:      	ldp	x2, x24, [sp, #0x50]
   10780:      	str	x21, [sp, #0x48]
   10784:      	b	0x107d4 <generic_fentry_path+0x7514>
   10788:      	add	x2, x24, #0x10
   1078c:      	mov	w8, #0x4                // =4
   10790:      	add	x9, sp, #0x98
   10794:      	add	x0, sp, #0x98
   10798:      	mov	w1, #0x8                // =8
   1079c:      	blr	x8
   107a0:      	ldr	x8, [sp, #0x58]
   107a4:      	ldr	x9, [sp, #0x98]
   107a8:      	cmp	x8, x9
   107ac:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   107b0:      	add	x2, x24, #0x18
   107b4:      	mov	w8, #0x4                // =4
   107b8:      	mov	x0, x22
   107bc:      	mov	w1, #0x8                // =8
   107c0:      	blr	x8
   107c4:      	ldr	x24, [sp, #0x98]
   107c8:      	ldr	x21, [sp, #0x48]
   107cc:      	add	x2, x24, #0x20
   107d0:      	stp	x2, x24, [sp, #0x50]
   107d4:      	ldr	x8, [sp, #0x30]
   107d8:      	cmp	x21, x8
   107dc:      	b.ne	0x107ec <generic_fentry_path+0x752c>
   107e0:      	ldr	x8, [sp, #0x38]
   107e4:      	cmp	x2, x8
   107e8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   107ec:      	mov	w8, #0x4                // =4
   107f0:      	add	x0, sp, #0x70
   107f4:      	mov	w1, #0x8                // =8
   107f8:      	blr	x8
   107fc:      	ldr	x8, [sp, #0x70]
   10800:      	cmp	x21, x8
   10804:      	b.eq	0x108f4 <generic_fentry_path+0x7634>
   10808:      	add	x23, x21, #0x18
   1080c:      	mov	w8, #0x4                // =4
   10810:      	add	x9, sp, #0x98
   10814:      	add	x0, sp, #0x98
   10818:      	mov	w1, #0x8                // =8
   1081c:      	mov	x2, x23
   10820:      	blr	x8
   10824:      	ldr	x8, [sp, #0x98]
   10828:      	cmp	x8, x21
   1082c:      	b.eq	0x108f4 <generic_fentry_path+0x7634>
   10830:      	mov	w8, #0x4                // =4
   10834:      	add	x9, sp, #0x78
   10838:      	add	x0, sp, #0x78
   1083c:      	mov	w1, #0x8                // =8
   10840:      	mov	x2, x23
   10844:      	blr	x8
   10848:      	add	x2, x21, #0x20
   1084c:      	mov	w8, #0x4                // =4
   10850:      	mov	w9, #0x10               // =16
   10854:      	add	x10, sp, #0x80
   10858:      	add	x0, sp, #0x80
   1085c:      	mov	w1, #0x10               // =16
   10860:      	blr	x8
   10864:      	ldr	w21, [sp, #0x84]
   10868:      	ldr	x8, [sp, #0x40]
   1086c:      	ldr	x10, [sp, #0x60]
   10870:      	sub	x12, x10, x8
   10874:      	ldr	w23, [sp, #0x68]
   10878:      	subs	w10, w21, w23
   1087c:      	ldr	x9, [sp, #0x88]
   10880:      	csel	w10, wzr, w10, lo
   10884:      	cmp	w23, w21
   10888:      	csel	w11, w23, w21, lo
   1088c:      	cinc	w13, w11, hi
   10890:      	sub	w14, w23, w13
   10894:      	subs	x12, x12, x13
   10898:      	str	w14, [sp, #0x68]
   1089c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   108a0:      	cmp	x12, #0xfff
   108a4:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   108a8:      	cmp	w23, w21
   108ac:      	b.ls	0x108b8 <generic_fentry_path+0x75f8>
   108b0:      	mov	w13, #0x2f              // =47
   108b4:      	strb	w13, [x8, x12]
   108b8:      	add	x19, x8, x12
   108bc:      	cmp	w23, w21
   108c0:      	add	x2, x9, x10
   108c4:      	and	w1, w11, #0xff
   108c8:      	mov	w8, #0x4                // =4
   108cc:      	cinc	x0, x19, hi
   108d0:      	blr	x8
   108d4:      	cmp	w23, w21
   108d8:      	str	x19, [sp, #0x60]
   108dc:      	add	x19, sp, #0x70
   108e0:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   108e4:      	ldr	x21, [sp, #0x78]
   108e8:      	ldp	x2, x24, [sp, #0x50]
   108ec:      	str	x21, [sp, #0x48]
   108f0:      	b	0x10940 <generic_fentry_path+0x7680>
   108f4:      	add	x2, x24, #0x10
   108f8:      	mov	w8, #0x4                // =4
   108fc:      	add	x9, sp, #0x98
   10900:      	add	x0, sp, #0x98
   10904:      	mov	w1, #0x8                // =8
   10908:      	blr	x8
   1090c:      	ldr	x8, [sp, #0x58]
   10910:      	ldr	x9, [sp, #0x98]
   10914:      	cmp	x8, x9
   10918:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   1091c:      	add	x2, x24, #0x18
   10920:      	mov	w8, #0x4                // =4
   10924:      	mov	x0, x22
   10928:      	mov	w1, #0x8                // =8
   1092c:      	blr	x8
   10930:      	ldr	x24, [sp, #0x98]
   10934:      	ldr	x21, [sp, #0x48]
   10938:      	add	x2, x24, #0x20
   1093c:      	stp	x2, x24, [sp, #0x50]
   10940:      	ldr	x8, [sp, #0x30]
   10944:      	cmp	x21, x8
   10948:      	b.ne	0x10958 <generic_fentry_path+0x7698>
   1094c:      	ldr	x8, [sp, #0x38]
   10950:      	cmp	x2, x8
   10954:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   10958:      	mov	w8, #0x4                // =4
   1095c:      	add	x0, sp, #0x70
   10960:      	mov	w1, #0x8                // =8
   10964:      	blr	x8
   10968:      	ldr	x8, [sp, #0x70]
   1096c:      	cmp	x21, x8
   10970:      	b.eq	0x10a60 <generic_fentry_path+0x77a0>
   10974:      	add	x23, x21, #0x18
   10978:      	mov	w8, #0x4                // =4
   1097c:      	add	x9, sp, #0x98
   10980:      	add	x0, sp, #0x98
   10984:      	mov	w1, #0x8                // =8
   10988:      	mov	x2, x23
   1098c:      	blr	x8
   10990:      	ldr	x8, [sp, #0x98]
   10994:      	cmp	x8, x21
   10998:      	b.eq	0x10a60 <generic_fentry_path+0x77a0>
   1099c:      	mov	w8, #0x4                // =4
   109a0:      	add	x9, sp, #0x78
   109a4:      	add	x0, sp, #0x78
   109a8:      	mov	w1, #0x8                // =8
   109ac:      	mov	x2, x23
   109b0:      	blr	x8
   109b4:      	add	x2, x21, #0x20
   109b8:      	mov	w8, #0x4                // =4
   109bc:      	mov	w9, #0x10               // =16
   109c0:      	add	x10, sp, #0x80
   109c4:      	add	x0, sp, #0x80
   109c8:      	mov	w1, #0x10               // =16
   109cc:      	blr	x8
   109d0:      	ldr	w21, [sp, #0x84]
   109d4:      	ldr	x8, [sp, #0x40]
   109d8:      	ldr	x10, [sp, #0x60]
   109dc:      	sub	x12, x10, x8
   109e0:      	ldr	w23, [sp, #0x68]
   109e4:      	subs	w10, w21, w23
   109e8:      	ldr	x9, [sp, #0x88]
   109ec:      	csel	w10, wzr, w10, lo
   109f0:      	cmp	w23, w21
   109f4:      	csel	w11, w23, w21, lo
   109f8:      	cinc	w13, w11, hi
   109fc:      	sub	w14, w23, w13
   10a00:      	subs	x12, x12, x13
   10a04:      	str	w14, [sp, #0x68]
   10a08:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   10a0c:      	cmp	x12, #0xfff
   10a10:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   10a14:      	cmp	w23, w21
   10a18:      	b.ls	0x10a24 <generic_fentry_path+0x7764>
   10a1c:      	mov	w13, #0x2f              // =47
   10a20:      	strb	w13, [x8, x12]
   10a24:      	add	x19, x8, x12
   10a28:      	cmp	w23, w21
   10a2c:      	add	x2, x9, x10
   10a30:      	and	w1, w11, #0xff
   10a34:      	mov	w8, #0x4                // =4
   10a38:      	cinc	x0, x19, hi
   10a3c:      	blr	x8
   10a40:      	cmp	w23, w21
   10a44:      	str	x19, [sp, #0x60]
   10a48:      	add	x19, sp, #0x70
   10a4c:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   10a50:      	ldr	x21, [sp, #0x78]
   10a54:      	ldp	x2, x24, [sp, #0x50]
   10a58:      	str	x21, [sp, #0x48]
   10a5c:      	b	0x10aac <generic_fentry_path+0x77ec>
   10a60:      	add	x2, x24, #0x10
   10a64:      	mov	w8, #0x4                // =4
   10a68:      	add	x9, sp, #0x98
   10a6c:      	add	x0, sp, #0x98
   10a70:      	mov	w1, #0x8                // =8
   10a74:      	blr	x8
   10a78:      	ldr	x8, [sp, #0x58]
   10a7c:      	ldr	x9, [sp, #0x98]
   10a80:      	cmp	x8, x9
   10a84:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   10a88:      	add	x2, x24, #0x18
   10a8c:      	mov	w8, #0x4                // =4
   10a90:      	mov	x0, x22
   10a94:      	mov	w1, #0x8                // =8
   10a98:      	blr	x8
   10a9c:      	ldr	x24, [sp, #0x98]
   10aa0:      	ldr	x21, [sp, #0x48]
   10aa4:      	add	x2, x24, #0x20
   10aa8:      	stp	x2, x24, [sp, #0x50]
   10aac:      	ldr	x8, [sp, #0x30]
   10ab0:      	cmp	x21, x8
   10ab4:      	b.ne	0x10ac4 <generic_fentry_path+0x7804>
   10ab8:      	ldr	x8, [sp, #0x38]
   10abc:      	cmp	x2, x8
   10ac0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   10ac4:      	mov	w8, #0x4                // =4
   10ac8:      	add	x0, sp, #0x70
   10acc:      	mov	w1, #0x8                // =8
   10ad0:      	blr	x8
   10ad4:      	ldr	x8, [sp, #0x70]
   10ad8:      	cmp	x21, x8
   10adc:      	b.eq	0x10bcc <generic_fentry_path+0x790c>
   10ae0:      	add	x23, x21, #0x18
   10ae4:      	mov	w8, #0x4                // =4
   10ae8:      	add	x9, sp, #0x98
   10aec:      	add	x0, sp, #0x98
   10af0:      	mov	w1, #0x8                // =8
   10af4:      	mov	x2, x23
   10af8:      	blr	x8
   10afc:      	ldr	x8, [sp, #0x98]
   10b00:      	cmp	x8, x21
   10b04:      	b.eq	0x10bcc <generic_fentry_path+0x790c>
   10b08:      	mov	w8, #0x4                // =4
   10b0c:      	add	x9, sp, #0x78
   10b10:      	add	x0, sp, #0x78
   10b14:      	mov	w1, #0x8                // =8
   10b18:      	mov	x2, x23
   10b1c:      	blr	x8
   10b20:      	add	x2, x21, #0x20
   10b24:      	mov	w8, #0x4                // =4
   10b28:      	mov	w9, #0x10               // =16
   10b2c:      	add	x10, sp, #0x80
   10b30:      	add	x0, sp, #0x80
   10b34:      	mov	w1, #0x10               // =16
   10b38:      	blr	x8
   10b3c:      	ldr	w21, [sp, #0x84]
   10b40:      	ldr	x8, [sp, #0x40]
   10b44:      	ldr	x10, [sp, #0x60]
   10b48:      	sub	x12, x10, x8
   10b4c:      	ldr	w23, [sp, #0x68]
   10b50:      	subs	w10, w21, w23
   10b54:      	ldr	x9, [sp, #0x88]
   10b58:      	csel	w10, wzr, w10, lo
   10b5c:      	cmp	w23, w21
   10b60:      	csel	w11, w23, w21, lo
   10b64:      	cinc	w13, w11, hi
   10b68:      	sub	w14, w23, w13
   10b6c:      	subs	x12, x12, x13
   10b70:      	str	w14, [sp, #0x68]
   10b74:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   10b78:      	cmp	x12, #0xfff
   10b7c:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   10b80:      	cmp	w23, w21
   10b84:      	b.ls	0x10b90 <generic_fentry_path+0x78d0>
   10b88:      	mov	w13, #0x2f              // =47
   10b8c:      	strb	w13, [x8, x12]
   10b90:      	add	x19, x8, x12
   10b94:      	cmp	w23, w21
   10b98:      	add	x2, x9, x10
   10b9c:      	and	w1, w11, #0xff
   10ba0:      	mov	w8, #0x4                // =4
   10ba4:      	cinc	x0, x19, hi
   10ba8:      	blr	x8
   10bac:      	cmp	w23, w21
   10bb0:      	str	x19, [sp, #0x60]
   10bb4:      	add	x19, sp, #0x70
   10bb8:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   10bbc:      	ldr	x21, [sp, #0x78]
   10bc0:      	ldp	x2, x24, [sp, #0x50]
   10bc4:      	str	x21, [sp, #0x48]
   10bc8:      	b	0x10c18 <generic_fentry_path+0x7958>
   10bcc:      	add	x2, x24, #0x10
   10bd0:      	mov	w8, #0x4                // =4
   10bd4:      	add	x9, sp, #0x98
   10bd8:      	add	x0, sp, #0x98
   10bdc:      	mov	w1, #0x8                // =8
   10be0:      	blr	x8
   10be4:      	ldr	x8, [sp, #0x58]
   10be8:      	ldr	x9, [sp, #0x98]
   10bec:      	cmp	x8, x9
   10bf0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   10bf4:      	add	x2, x24, #0x18
   10bf8:      	mov	w8, #0x4                // =4
   10bfc:      	mov	x0, x22
   10c00:      	mov	w1, #0x8                // =8
   10c04:      	blr	x8
   10c08:      	ldr	x24, [sp, #0x98]
   10c0c:      	ldr	x21, [sp, #0x48]
   10c10:      	add	x2, x24, #0x20
   10c14:      	stp	x2, x24, [sp, #0x50]
   10c18:      	ldr	x8, [sp, #0x30]
   10c1c:      	cmp	x21, x8
   10c20:      	b.ne	0x10c30 <generic_fentry_path+0x7970>
   10c24:      	ldr	x8, [sp, #0x38]
   10c28:      	cmp	x2, x8
   10c2c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   10c30:      	mov	w8, #0x4                // =4
   10c34:      	add	x0, sp, #0x70
   10c38:      	mov	w1, #0x8                // =8
   10c3c:      	blr	x8
   10c40:      	ldr	x8, [sp, #0x70]
   10c44:      	cmp	x21, x8
   10c48:      	b.eq	0x10d38 <generic_fentry_path+0x7a78>
   10c4c:      	add	x23, x21, #0x18
   10c50:      	mov	w8, #0x4                // =4
   10c54:      	add	x9, sp, #0x98
   10c58:      	add	x0, sp, #0x98
   10c5c:      	mov	w1, #0x8                // =8
   10c60:      	mov	x2, x23
   10c64:      	blr	x8
   10c68:      	ldr	x8, [sp, #0x98]
   10c6c:      	cmp	x8, x21
   10c70:      	b.eq	0x10d38 <generic_fentry_path+0x7a78>
   10c74:      	mov	w8, #0x4                // =4
   10c78:      	add	x9, sp, #0x78
   10c7c:      	add	x0, sp, #0x78
   10c80:      	mov	w1, #0x8                // =8
   10c84:      	mov	x2, x23
   10c88:      	blr	x8
   10c8c:      	add	x2, x21, #0x20
   10c90:      	mov	w8, #0x4                // =4
   10c94:      	mov	w9, #0x10               // =16
   10c98:      	add	x10, sp, #0x80
   10c9c:      	add	x0, sp, #0x80
   10ca0:      	mov	w1, #0x10               // =16
   10ca4:      	blr	x8
   10ca8:      	ldr	w21, [sp, #0x84]
   10cac:      	ldr	x8, [sp, #0x40]
   10cb0:      	ldr	x10, [sp, #0x60]
   10cb4:      	sub	x12, x10, x8
   10cb8:      	ldr	w23, [sp, #0x68]
   10cbc:      	subs	w10, w21, w23
   10cc0:      	ldr	x9, [sp, #0x88]
   10cc4:      	csel	w10, wzr, w10, lo
   10cc8:      	cmp	w23, w21
   10ccc:      	csel	w11, w23, w21, lo
   10cd0:      	cinc	w13, w11, hi
   10cd4:      	sub	w14, w23, w13
   10cd8:      	subs	x12, x12, x13
   10cdc:      	str	w14, [sp, #0x68]
   10ce0:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   10ce4:      	cmp	x12, #0xfff
   10ce8:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   10cec:      	cmp	w23, w21
   10cf0:      	b.ls	0x10cfc <generic_fentry_path+0x7a3c>
   10cf4:      	mov	w13, #0x2f              // =47
   10cf8:      	strb	w13, [x8, x12]
   10cfc:      	add	x19, x8, x12
   10d00:      	cmp	w23, w21
   10d04:      	add	x2, x9, x10
   10d08:      	and	w1, w11, #0xff
   10d0c:      	mov	w8, #0x4                // =4
   10d10:      	cinc	x0, x19, hi
   10d14:      	blr	x8
   10d18:      	cmp	w23, w21
   10d1c:      	str	x19, [sp, #0x60]
   10d20:      	add	x19, sp, #0x70
   10d24:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   10d28:      	ldr	x21, [sp, #0x78]
   10d2c:      	ldp	x2, x24, [sp, #0x50]
   10d30:      	str	x21, [sp, #0x48]
   10d34:      	b	0x10d84 <generic_fentry_path+0x7ac4>
   10d38:      	add	x2, x24, #0x10
   10d3c:      	mov	w8, #0x4                // =4
   10d40:      	add	x9, sp, #0x98
   10d44:      	add	x0, sp, #0x98
   10d48:      	mov	w1, #0x8                // =8
   10d4c:      	blr	x8
   10d50:      	ldr	x8, [sp, #0x58]
   10d54:      	ldr	x9, [sp, #0x98]
   10d58:      	cmp	x8, x9
   10d5c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   10d60:      	add	x2, x24, #0x18
   10d64:      	mov	w8, #0x4                // =4
   10d68:      	mov	x0, x22
   10d6c:      	mov	w1, #0x8                // =8
   10d70:      	blr	x8
   10d74:      	ldr	x24, [sp, #0x98]
   10d78:      	ldr	x21, [sp, #0x48]
   10d7c:      	add	x2, x24, #0x20
   10d80:      	stp	x2, x24, [sp, #0x50]
   10d84:      	ldr	x8, [sp, #0x30]
   10d88:      	cmp	x21, x8
   10d8c:      	b.ne	0x10d9c <generic_fentry_path+0x7adc>
   10d90:      	ldr	x8, [sp, #0x38]
   10d94:      	cmp	x2, x8
   10d98:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   10d9c:      	mov	w8, #0x4                // =4
   10da0:      	add	x0, sp, #0x70
   10da4:      	mov	w1, #0x8                // =8
   10da8:      	blr	x8
   10dac:      	ldr	x8, [sp, #0x70]
   10db0:      	cmp	x21, x8
   10db4:      	b.eq	0x10ea4 <generic_fentry_path+0x7be4>
   10db8:      	add	x23, x21, #0x18
   10dbc:      	mov	w8, #0x4                // =4
   10dc0:      	add	x9, sp, #0x98
   10dc4:      	add	x0, sp, #0x98
   10dc8:      	mov	w1, #0x8                // =8
   10dcc:      	mov	x2, x23
   10dd0:      	blr	x8
   10dd4:      	ldr	x8, [sp, #0x98]
   10dd8:      	cmp	x8, x21
   10ddc:      	b.eq	0x10ea4 <generic_fentry_path+0x7be4>
   10de0:      	mov	w8, #0x4                // =4
   10de4:      	add	x9, sp, #0x78
   10de8:      	add	x0, sp, #0x78
   10dec:      	mov	w1, #0x8                // =8
   10df0:      	mov	x2, x23
   10df4:      	blr	x8
   10df8:      	add	x2, x21, #0x20
   10dfc:      	mov	w8, #0x4                // =4
   10e00:      	mov	w9, #0x10               // =16
   10e04:      	add	x10, sp, #0x80
   10e08:      	add	x0, sp, #0x80
   10e0c:      	mov	w1, #0x10               // =16
   10e10:      	blr	x8
   10e14:      	ldr	w21, [sp, #0x84]
   10e18:      	ldr	x8, [sp, #0x40]
   10e1c:      	ldr	x10, [sp, #0x60]
   10e20:      	sub	x12, x10, x8
   10e24:      	ldr	w23, [sp, #0x68]
   10e28:      	subs	w10, w21, w23
   10e2c:      	ldr	x9, [sp, #0x88]
   10e30:      	csel	w10, wzr, w10, lo
   10e34:      	cmp	w23, w21
   10e38:      	csel	w11, w23, w21, lo
   10e3c:      	cinc	w13, w11, hi
   10e40:      	sub	w14, w23, w13
   10e44:      	subs	x12, x12, x13
   10e48:      	str	w14, [sp, #0x68]
   10e4c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   10e50:      	cmp	x12, #0xfff
   10e54:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   10e58:      	cmp	w23, w21
   10e5c:      	b.ls	0x10e68 <generic_fentry_path+0x7ba8>
   10e60:      	mov	w13, #0x2f              // =47
   10e64:      	strb	w13, [x8, x12]
   10e68:      	add	x19, x8, x12
   10e6c:      	cmp	w23, w21
   10e70:      	add	x2, x9, x10
   10e74:      	and	w1, w11, #0xff
   10e78:      	mov	w8, #0x4                // =4
   10e7c:      	cinc	x0, x19, hi
   10e80:      	blr	x8
   10e84:      	cmp	w23, w21
   10e88:      	str	x19, [sp, #0x60]
   10e8c:      	add	x19, sp, #0x70
   10e90:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   10e94:      	ldr	x21, [sp, #0x78]
   10e98:      	ldp	x2, x24, [sp, #0x50]
   10e9c:      	str	x21, [sp, #0x48]
   10ea0:      	b	0x10ef0 <generic_fentry_path+0x7c30>
   10ea4:      	add	x2, x24, #0x10
   10ea8:      	mov	w8, #0x4                // =4
   10eac:      	add	x9, sp, #0x98
   10eb0:      	add	x0, sp, #0x98
   10eb4:      	mov	w1, #0x8                // =8
   10eb8:      	blr	x8
   10ebc:      	ldr	x8, [sp, #0x58]
   10ec0:      	ldr	x9, [sp, #0x98]
   10ec4:      	cmp	x8, x9
   10ec8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   10ecc:      	add	x2, x24, #0x18
   10ed0:      	mov	w8, #0x4                // =4
   10ed4:      	mov	x0, x22
   10ed8:      	mov	w1, #0x8                // =8
   10edc:      	blr	x8
   10ee0:      	ldr	x24, [sp, #0x98]
   10ee4:      	ldr	x21, [sp, #0x48]
   10ee8:      	add	x2, x24, #0x20
   10eec:      	stp	x2, x24, [sp, #0x50]
   10ef0:      	ldr	x8, [sp, #0x30]
   10ef4:      	cmp	x21, x8
   10ef8:      	b.ne	0x10f08 <generic_fentry_path+0x7c48>
   10efc:      	ldr	x8, [sp, #0x38]
   10f00:      	cmp	x2, x8
   10f04:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   10f08:      	mov	w8, #0x4                // =4
   10f0c:      	add	x0, sp, #0x70
   10f10:      	mov	w1, #0x8                // =8
   10f14:      	blr	x8
   10f18:      	ldr	x8, [sp, #0x70]
   10f1c:      	cmp	x21, x8
   10f20:      	b.eq	0x11010 <generic_fentry_path+0x7d50>
   10f24:      	add	x23, x21, #0x18
   10f28:      	mov	w8, #0x4                // =4
   10f2c:      	add	x9, sp, #0x98
   10f30:      	add	x0, sp, #0x98
   10f34:      	mov	w1, #0x8                // =8
   10f38:      	mov	x2, x23
   10f3c:      	blr	x8
   10f40:      	ldr	x8, [sp, #0x98]
   10f44:      	cmp	x8, x21
   10f48:      	b.eq	0x11010 <generic_fentry_path+0x7d50>
   10f4c:      	mov	w8, #0x4                // =4
   10f50:      	add	x9, sp, #0x78
   10f54:      	add	x0, sp, #0x78
   10f58:      	mov	w1, #0x8                // =8
   10f5c:      	mov	x2, x23
   10f60:      	blr	x8
   10f64:      	add	x2, x21, #0x20
   10f68:      	mov	w8, #0x4                // =4
   10f6c:      	mov	w9, #0x10               // =16
   10f70:      	add	x10, sp, #0x80
   10f74:      	add	x0, sp, #0x80
   10f78:      	mov	w1, #0x10               // =16
   10f7c:      	blr	x8
   10f80:      	ldr	w21, [sp, #0x84]
   10f84:      	ldr	x8, [sp, #0x40]
   10f88:      	ldr	x10, [sp, #0x60]
   10f8c:      	sub	x12, x10, x8
   10f90:      	ldr	w23, [sp, #0x68]
   10f94:      	subs	w10, w21, w23
   10f98:      	ldr	x9, [sp, #0x88]
   10f9c:      	csel	w10, wzr, w10, lo
   10fa0:      	cmp	w23, w21
   10fa4:      	csel	w11, w23, w21, lo
   10fa8:      	cinc	w13, w11, hi
   10fac:      	sub	w14, w23, w13
   10fb0:      	subs	x12, x12, x13
   10fb4:      	str	w14, [sp, #0x68]
   10fb8:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   10fbc:      	cmp	x12, #0xfff
   10fc0:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   10fc4:      	cmp	w23, w21
   10fc8:      	b.ls	0x10fd4 <generic_fentry_path+0x7d14>
   10fcc:      	mov	w13, #0x2f              // =47
   10fd0:      	strb	w13, [x8, x12]
   10fd4:      	add	x19, x8, x12
   10fd8:      	cmp	w23, w21
   10fdc:      	add	x2, x9, x10
   10fe0:      	and	w1, w11, #0xff
   10fe4:      	mov	w8, #0x4                // =4
   10fe8:      	cinc	x0, x19, hi
   10fec:      	blr	x8
   10ff0:      	cmp	w23, w21
   10ff4:      	str	x19, [sp, #0x60]
   10ff8:      	add	x19, sp, #0x70
   10ffc:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   11000:      	ldr	x21, [sp, #0x78]
   11004:      	ldp	x2, x24, [sp, #0x50]
   11008:      	str	x21, [sp, #0x48]
   1100c:      	b	0x1105c <generic_fentry_path+0x7d9c>
   11010:      	add	x2, x24, #0x10
   11014:      	mov	w8, #0x4                // =4
   11018:      	add	x9, sp, #0x98
   1101c:      	add	x0, sp, #0x98
   11020:      	mov	w1, #0x8                // =8
   11024:      	blr	x8
   11028:      	ldr	x8, [sp, #0x58]
   1102c:      	ldr	x9, [sp, #0x98]
   11030:      	cmp	x8, x9
   11034:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   11038:      	add	x2, x24, #0x18
   1103c:      	mov	w8, #0x4                // =4
   11040:      	mov	x0, x22
   11044:      	mov	w1, #0x8                // =8
   11048:      	blr	x8
   1104c:      	ldr	x24, [sp, #0x98]
   11050:      	ldr	x21, [sp, #0x48]
   11054:      	add	x2, x24, #0x20
   11058:      	stp	x2, x24, [sp, #0x50]
   1105c:      	ldr	x8, [sp, #0x30]
   11060:      	cmp	x21, x8
   11064:      	b.ne	0x11074 <generic_fentry_path+0x7db4>
   11068:      	ldr	x8, [sp, #0x38]
   1106c:      	cmp	x2, x8
   11070:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   11074:      	str	x25, [sp, #0x8]
   11078:      	mov	w8, #0x4                // =4
   1107c:      	add	x0, sp, #0x70
   11080:      	mov	w1, #0x8                // =8
   11084:      	blr	x8
   11088:      	ldr	x8, [sp, #0x70]
   1108c:      	cmp	x21, x8
   11090:      	b.eq	0x11184 <generic_fentry_path+0x7ec4>
   11094:      	add	x23, x21, #0x18
   11098:      	mov	w8, #0x4                // =4
   1109c:      	add	x9, sp, #0x98
   110a0:      	add	x0, sp, #0x98
   110a4:      	mov	w1, #0x8                // =8
   110a8:      	mov	x2, x23
   110ac:      	blr	x8
   110b0:      	ldr	x8, [sp, #0x98]
   110b4:      	cmp	x8, x21
   110b8:      	b.eq	0x11184 <generic_fentry_path+0x7ec4>
   110bc:      	mov	w8, #0x4                // =4
   110c0:      	add	x9, sp, #0x78
   110c4:      	add	x0, sp, #0x78
   110c8:      	mov	w1, #0x8                // =8
   110cc:      	mov	x2, x23
   110d0:      	blr	x8
   110d4:      	add	x2, x21, #0x20
   110d8:      	mov	w8, #0x4                // =4
   110dc:      	mov	w9, #0x10               // =16
   110e0:      	add	x10, sp, #0x80
   110e4:      	add	x0, sp, #0x80
   110e8:      	mov	w1, #0x10               // =16
   110ec:      	blr	x8
   110f0:      	ldr	w21, [sp, #0x84]
   110f4:      	ldr	x8, [sp, #0x40]
   110f8:      	ldr	x10, [sp, #0x60]
   110fc:      	sub	x12, x10, x8
   11100:      	ldr	w23, [sp, #0x68]
   11104:      	subs	w10, w21, w23
   11108:      	ldr	x9, [sp, #0x88]
   1110c:      	ldr	x25, [sp, #0x8]
   11110:      	csel	w10, wzr, w10, lo
   11114:      	cmp	w23, w21
   11118:      	csel	w11, w23, w21, lo
   1111c:      	cinc	w13, w11, hi
   11120:      	sub	w14, w23, w13
   11124:      	subs	x12, x12, x13
   11128:      	str	w14, [sp, #0x68]
   1112c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   11130:      	cmp	x12, #0xfff
   11134:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   11138:      	cmp	w23, w21
   1113c:      	b.ls	0x11148 <generic_fentry_path+0x7e88>
   11140:      	mov	w13, #0x2f              // =47
   11144:      	strb	w13, [x8, x12]
   11148:      	add	x19, x8, x12
   1114c:      	cmp	w23, w21
   11150:      	add	x2, x9, x10
   11154:      	and	w1, w11, #0xff
   11158:      	mov	w8, #0x4                // =4
   1115c:      	cinc	x0, x19, hi
   11160:      	blr	x8
   11164:      	ldr	x25, [sp, #0x8]
   11168:      	cmp	w23, w21
   1116c:      	str	x19, [sp, #0x60]
   11170:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   11174:      	ldr	x21, [sp, #0x78]
   11178:      	ldp	x2, x24, [sp, #0x50]
   1117c:      	str	x21, [sp, #0x48]
   11180:      	b	0x111d4 <generic_fentry_path+0x7f14>
   11184:      	add	x2, x24, #0x10
   11188:      	mov	w8, #0x4                // =4
   1118c:      	add	x9, sp, #0x98
   11190:      	add	x0, sp, #0x98
   11194:      	mov	w1, #0x8                // =8
   11198:      	blr	x8
   1119c:      	ldr	x8, [sp, #0x58]
   111a0:      	ldr	x9, [sp, #0x98]
   111a4:      	cmp	x8, x9
   111a8:      	ldr	x25, [sp, #0x8]
   111ac:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   111b0:      	add	x2, x24, #0x18
   111b4:      	mov	w8, #0x4                // =4
   111b8:      	mov	x0, x22
   111bc:      	mov	w1, #0x8                // =8
   111c0:      	blr	x8
   111c4:      	ldr	x24, [sp, #0x98]
   111c8:      	ldr	x21, [sp, #0x48]
   111cc:      	add	x2, x24, #0x20
   111d0:      	stp	x2, x24, [sp, #0x50]
   111d4:      	ldr	x8, [sp, #0x30]
   111d8:      	ldr	x25, [sp, #0x8]
   111dc:      	add	x9, sp, #0x70
   111e0:      	cmp	x21, x8
   111e4:      	b.ne	0x111f4 <generic_fentry_path+0x7f34>
   111e8:      	ldr	x8, [sp, #0x38]
   111ec:      	cmp	x2, x8
   111f0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   111f4:      	mov	w8, #0x4                // =4
   111f8:      	add	x0, sp, #0x70
   111fc:      	mov	w1, #0x8                // =8
   11200:      	blr	x8
   11204:      	ldr	x8, [sp, #0x70]
   11208:      	cmp	x21, x8
   1120c:      	b.eq	0x11300 <generic_fentry_path+0x8040>
   11210:      	add	x23, x21, #0x18
   11214:      	mov	w8, #0x4                // =4
   11218:      	add	x9, sp, #0x98
   1121c:      	add	x0, sp, #0x98
   11220:      	mov	w1, #0x8                // =8
   11224:      	mov	x2, x23
   11228:      	blr	x8
   1122c:      	ldr	x8, [sp, #0x98]
   11230:      	cmp	x8, x21
   11234:      	b.eq	0x11300 <generic_fentry_path+0x8040>
   11238:      	mov	w8, #0x4                // =4
   1123c:      	add	x9, sp, #0x78
   11240:      	add	x0, sp, #0x78
   11244:      	mov	w1, #0x8                // =8
   11248:      	mov	x2, x23
   1124c:      	blr	x8
   11250:      	add	x2, x21, #0x20
   11254:      	mov	w8, #0x4                // =4
   11258:      	mov	w9, #0x10               // =16
   1125c:      	add	x10, sp, #0x80
   11260:      	add	x0, sp, #0x80
   11264:      	mov	w1, #0x10               // =16
   11268:      	blr	x8
   1126c:      	ldr	w21, [sp, #0x84]
   11270:      	ldr	x8, [sp, #0x40]
   11274:      	ldr	x10, [sp, #0x60]
   11278:      	sub	x12, x10, x8
   1127c:      	ldr	w23, [sp, #0x68]
   11280:      	subs	w10, w21, w23
   11284:      	ldr	x9, [sp, #0x88]
   11288:      	ldr	x25, [sp, #0x8]
   1128c:      	csel	w10, wzr, w10, lo
   11290:      	cmp	w23, w21
   11294:      	csel	w11, w23, w21, lo
   11298:      	cinc	w13, w11, hi
   1129c:      	sub	w14, w23, w13
   112a0:      	subs	x12, x12, x13
   112a4:      	str	w14, [sp, #0x68]
   112a8:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   112ac:      	cmp	x12, #0xfff
   112b0:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   112b4:      	cmp	w23, w21
   112b8:      	b.ls	0x112c4 <generic_fentry_path+0x8004>
   112bc:      	mov	w13, #0x2f              // =47
   112c0:      	strb	w13, [x8, x12]
   112c4:      	add	x19, x8, x12
   112c8:      	cmp	w23, w21
   112cc:      	add	x2, x9, x10
   112d0:      	and	w1, w11, #0xff
   112d4:      	mov	w8, #0x4                // =4
   112d8:      	cinc	x0, x19, hi
   112dc:      	blr	x8
   112e0:      	ldr	x25, [sp, #0x8]
   112e4:      	cmp	w23, w21
   112e8:      	str	x19, [sp, #0x60]
   112ec:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   112f0:      	ldr	x21, [sp, #0x78]
   112f4:      	ldp	x2, x24, [sp, #0x50]
   112f8:      	str	x21, [sp, #0x48]
   112fc:      	b	0x11350 <generic_fentry_path+0x8090>
   11300:      	add	x2, x24, #0x10
   11304:      	mov	w8, #0x4                // =4
   11308:      	add	x9, sp, #0x98
   1130c:      	add	x0, sp, #0x98
   11310:      	mov	w1, #0x8                // =8
   11314:      	blr	x8
   11318:      	ldr	x8, [sp, #0x58]
   1131c:      	ldr	x9, [sp, #0x98]
   11320:      	cmp	x8, x9
   11324:      	ldr	x25, [sp, #0x8]
   11328:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   1132c:      	add	x2, x24, #0x18
   11330:      	mov	w8, #0x4                // =4
   11334:      	mov	x0, x22
   11338:      	mov	w1, #0x8                // =8
   1133c:      	blr	x8
   11340:      	ldr	x24, [sp, #0x98]
   11344:      	ldr	x21, [sp, #0x48]
   11348:      	add	x2, x24, #0x20
   1134c:      	stp	x2, x24, [sp, #0x50]
   11350:      	ldr	x8, [sp, #0x30]
   11354:      	ldr	x25, [sp, #0x8]
   11358:      	add	x9, sp, #0x70
   1135c:      	cmp	x21, x8
   11360:      	b.ne	0x11370 <generic_fentry_path+0x80b0>
   11364:      	ldr	x8, [sp, #0x38]
   11368:      	cmp	x2, x8
   1136c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   11370:      	mov	w8, #0x4                // =4
   11374:      	add	x0, sp, #0x70
   11378:      	mov	w1, #0x8                // =8
   1137c:      	blr	x8
   11380:      	ldr	x8, [sp, #0x70]
   11384:      	cmp	x21, x8
   11388:      	b.eq	0x1147c <generic_fentry_path+0x81bc>
   1138c:      	add	x23, x21, #0x18
   11390:      	mov	w8, #0x4                // =4
   11394:      	add	x9, sp, #0x98
   11398:      	add	x0, sp, #0x98
   1139c:      	mov	w1, #0x8                // =8
   113a0:      	mov	x2, x23
   113a4:      	blr	x8
   113a8:      	ldr	x8, [sp, #0x98]
   113ac:      	cmp	x8, x21
   113b0:      	b.eq	0x1147c <generic_fentry_path+0x81bc>
   113b4:      	mov	w8, #0x4                // =4
   113b8:      	add	x9, sp, #0x78
   113bc:      	add	x0, sp, #0x78
   113c0:      	mov	w1, #0x8                // =8
   113c4:      	mov	x2, x23
   113c8:      	blr	x8
   113cc:      	add	x2, x21, #0x20
   113d0:      	mov	w8, #0x4                // =4
   113d4:      	mov	w9, #0x10               // =16
   113d8:      	add	x10, sp, #0x80
   113dc:      	add	x0, sp, #0x80
   113e0:      	mov	w1, #0x10               // =16
   113e4:      	blr	x8
   113e8:      	ldr	w21, [sp, #0x84]
   113ec:      	ldr	x8, [sp, #0x40]
   113f0:      	ldr	x10, [sp, #0x60]
   113f4:      	sub	x12, x10, x8
   113f8:      	ldr	w23, [sp, #0x68]
   113fc:      	subs	w10, w21, w23
   11400:      	ldr	x9, [sp, #0x88]
   11404:      	ldr	x25, [sp, #0x8]
   11408:      	csel	w10, wzr, w10, lo
   1140c:      	cmp	w23, w21
   11410:      	csel	w11, w23, w21, lo
   11414:      	cinc	w13, w11, hi
   11418:      	sub	w14, w23, w13
   1141c:      	subs	x12, x12, x13
   11420:      	str	w14, [sp, #0x68]
   11424:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   11428:      	cmp	x12, #0xfff
   1142c:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   11430:      	cmp	w23, w21
   11434:      	b.ls	0x11440 <generic_fentry_path+0x8180>
   11438:      	mov	w13, #0x2f              // =47
   1143c:      	strb	w13, [x8, x12]
   11440:      	add	x19, x8, x12
   11444:      	cmp	w23, w21
   11448:      	add	x2, x9, x10
   1144c:      	and	w1, w11, #0xff
   11450:      	mov	w8, #0x4                // =4
   11454:      	cinc	x0, x19, hi
   11458:      	blr	x8
   1145c:      	ldr	x25, [sp, #0x8]
   11460:      	cmp	w23, w21
   11464:      	str	x19, [sp, #0x60]
   11468:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   1146c:      	ldr	x21, [sp, #0x78]
   11470:      	ldp	x2, x24, [sp, #0x50]
   11474:      	str	x21, [sp, #0x48]
   11478:      	b	0x114cc <generic_fentry_path+0x820c>
   1147c:      	add	x2, x24, #0x10
   11480:      	mov	w8, #0x4                // =4
   11484:      	add	x9, sp, #0x98
   11488:      	add	x0, sp, #0x98
   1148c:      	mov	w1, #0x8                // =8
   11490:      	blr	x8
   11494:      	ldr	x8, [sp, #0x58]
   11498:      	ldr	x9, [sp, #0x98]
   1149c:      	cmp	x8, x9
   114a0:      	ldr	x25, [sp, #0x8]
   114a4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   114a8:      	add	x2, x24, #0x18
   114ac:      	mov	w8, #0x4                // =4
   114b0:      	mov	x0, x22
   114b4:      	mov	w1, #0x8                // =8
   114b8:      	blr	x8
   114bc:      	ldr	x24, [sp, #0x98]
   114c0:      	ldr	x21, [sp, #0x48]
   114c4:      	add	x2, x24, #0x20
   114c8:      	stp	x2, x24, [sp, #0x50]
   114cc:      	ldr	x8, [sp, #0x30]
   114d0:      	ldr	x25, [sp, #0x8]
   114d4:      	add	x9, sp, #0x70
   114d8:      	cmp	x21, x8
   114dc:      	b.ne	0x114ec <generic_fentry_path+0x822c>
   114e0:      	ldr	x8, [sp, #0x38]
   114e4:      	cmp	x2, x8
   114e8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   114ec:      	mov	w8, #0x4                // =4
   114f0:      	add	x0, sp, #0x70
   114f4:      	mov	w1, #0x8                // =8
   114f8:      	blr	x8
   114fc:      	ldr	x8, [sp, #0x70]
   11500:      	cmp	x21, x8
   11504:      	b.eq	0x115f8 <generic_fentry_path+0x8338>
   11508:      	add	x23, x21, #0x18
   1150c:      	mov	w8, #0x4                // =4
   11510:      	add	x9, sp, #0x98
   11514:      	add	x0, sp, #0x98
   11518:      	mov	w1, #0x8                // =8
   1151c:      	mov	x2, x23
   11520:      	blr	x8
   11524:      	ldr	x8, [sp, #0x98]
   11528:      	cmp	x8, x21
   1152c:      	b.eq	0x115f8 <generic_fentry_path+0x8338>
   11530:      	mov	w8, #0x4                // =4
   11534:      	add	x9, sp, #0x78
   11538:      	add	x0, sp, #0x78
   1153c:      	mov	w1, #0x8                // =8
   11540:      	mov	x2, x23
   11544:      	blr	x8
   11548:      	add	x2, x21, #0x20
   1154c:      	mov	w8, #0x4                // =4
   11550:      	mov	w9, #0x10               // =16
   11554:      	add	x10, sp, #0x80
   11558:      	add	x0, sp, #0x80
   1155c:      	mov	w1, #0x10               // =16
   11560:      	blr	x8
   11564:      	ldr	w21, [sp, #0x84]
   11568:      	ldr	x8, [sp, #0x40]
   1156c:      	ldr	x10, [sp, #0x60]
   11570:      	sub	x12, x10, x8
   11574:      	ldr	w23, [sp, #0x68]
   11578:      	subs	w10, w21, w23
   1157c:      	ldr	x9, [sp, #0x88]
   11580:      	ldr	x25, [sp, #0x8]
   11584:      	csel	w10, wzr, w10, lo
   11588:      	cmp	w23, w21
   1158c:      	csel	w11, w23, w21, lo
   11590:      	cinc	w13, w11, hi
   11594:      	sub	w14, w23, w13
   11598:      	subs	x12, x12, x13
   1159c:      	str	w14, [sp, #0x68]
   115a0:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   115a4:      	cmp	x12, #0xfff
   115a8:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   115ac:      	cmp	w23, w21
   115b0:      	b.ls	0x115bc <generic_fentry_path+0x82fc>
   115b4:      	mov	w13, #0x2f              // =47
   115b8:      	strb	w13, [x8, x12]
   115bc:      	add	x19, x8, x12
   115c0:      	cmp	w23, w21
   115c4:      	add	x2, x9, x10
   115c8:      	and	w1, w11, #0xff
   115cc:      	mov	w8, #0x4                // =4
   115d0:      	cinc	x0, x19, hi
   115d4:      	blr	x8
   115d8:      	ldr	x25, [sp, #0x8]
   115dc:      	cmp	w23, w21
   115e0:      	str	x19, [sp, #0x60]
   115e4:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   115e8:      	ldr	x21, [sp, #0x78]
   115ec:      	ldp	x2, x24, [sp, #0x50]
   115f0:      	str	x21, [sp, #0x48]
   115f4:      	b	0x11648 <generic_fentry_path+0x8388>
   115f8:      	add	x2, x24, #0x10
   115fc:      	mov	w8, #0x4                // =4
   11600:      	add	x9, sp, #0x98
   11604:      	add	x0, sp, #0x98
   11608:      	mov	w1, #0x8                // =8
   1160c:      	blr	x8
   11610:      	ldr	x8, [sp, #0x58]
   11614:      	ldr	x9, [sp, #0x98]
   11618:      	cmp	x8, x9
   1161c:      	ldr	x25, [sp, #0x8]
   11620:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   11624:      	add	x2, x24, #0x18
   11628:      	mov	w8, #0x4                // =4
   1162c:      	mov	x0, x22
   11630:      	mov	w1, #0x8                // =8
   11634:      	blr	x8
   11638:      	ldr	x24, [sp, #0x98]
   1163c:      	ldr	x21, [sp, #0x48]
   11640:      	add	x2, x24, #0x20
   11644:      	stp	x2, x24, [sp, #0x50]
   11648:      	ldr	x8, [sp, #0x30]
   1164c:      	ldr	x25, [sp, #0x8]
   11650:      	add	x9, sp, #0x70
   11654:      	cmp	x21, x8
   11658:      	b.ne	0x11668 <generic_fentry_path+0x83a8>
   1165c:      	ldr	x8, [sp, #0x38]
   11660:      	cmp	x2, x8
   11664:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   11668:      	mov	w8, #0x4                // =4
   1166c:      	add	x0, sp, #0x70
   11670:      	mov	w1, #0x8                // =8
   11674:      	blr	x8
   11678:      	ldr	x8, [sp, #0x70]
   1167c:      	cmp	x21, x8
   11680:      	b.eq	0x11774 <generic_fentry_path+0x84b4>
   11684:      	add	x23, x21, #0x18
   11688:      	mov	w8, #0x4                // =4
   1168c:      	add	x9, sp, #0x98
   11690:      	add	x0, sp, #0x98
   11694:      	mov	w1, #0x8                // =8
   11698:      	mov	x2, x23
   1169c:      	blr	x8
   116a0:      	ldr	x8, [sp, #0x98]
   116a4:      	cmp	x8, x21
   116a8:      	b.eq	0x11774 <generic_fentry_path+0x84b4>
   116ac:      	mov	w8, #0x4                // =4
   116b0:      	add	x9, sp, #0x78
   116b4:      	add	x0, sp, #0x78
   116b8:      	mov	w1, #0x8                // =8
   116bc:      	mov	x2, x23
   116c0:      	blr	x8
   116c4:      	add	x2, x21, #0x20
   116c8:      	mov	w8, #0x4                // =4
   116cc:      	mov	w9, #0x10               // =16
   116d0:      	add	x10, sp, #0x80
   116d4:      	add	x0, sp, #0x80
   116d8:      	mov	w1, #0x10               // =16
   116dc:      	blr	x8
   116e0:      	ldr	w21, [sp, #0x84]
   116e4:      	ldr	x8, [sp, #0x40]
   116e8:      	ldr	x10, [sp, #0x60]
   116ec:      	sub	x12, x10, x8
   116f0:      	ldr	w23, [sp, #0x68]
   116f4:      	subs	w10, w21, w23
   116f8:      	ldr	x9, [sp, #0x88]
   116fc:      	ldr	x25, [sp, #0x8]
   11700:      	csel	w10, wzr, w10, lo
   11704:      	cmp	w23, w21
   11708:      	csel	w11, w23, w21, lo
   1170c:      	cinc	w13, w11, hi
   11710:      	sub	w14, w23, w13
   11714:      	subs	x12, x12, x13
   11718:      	str	w14, [sp, #0x68]
   1171c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   11720:      	cmp	x12, #0xfff
   11724:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   11728:      	cmp	w23, w21
   1172c:      	b.ls	0x11738 <generic_fentry_path+0x8478>
   11730:      	mov	w13, #0x2f              // =47
   11734:      	strb	w13, [x8, x12]
   11738:      	add	x19, x8, x12
   1173c:      	cmp	w23, w21
   11740:      	add	x2, x9, x10
   11744:      	and	w1, w11, #0xff
   11748:      	mov	w8, #0x4                // =4
   1174c:      	cinc	x0, x19, hi
   11750:      	blr	x8
   11754:      	ldr	x25, [sp, #0x8]
   11758:      	cmp	w23, w21
   1175c:      	str	x19, [sp, #0x60]
   11760:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   11764:      	ldr	x21, [sp, #0x78]
   11768:      	ldp	x2, x24, [sp, #0x50]
   1176c:      	str	x21, [sp, #0x48]
   11770:      	b	0x117c4 <generic_fentry_path+0x8504>
   11774:      	add	x2, x24, #0x10
   11778:      	mov	w8, #0x4                // =4
   1177c:      	add	x9, sp, #0x98
   11780:      	add	x0, sp, #0x98
   11784:      	mov	w1, #0x8                // =8
   11788:      	blr	x8
   1178c:      	ldr	x8, [sp, #0x58]
   11790:      	ldr	x9, [sp, #0x98]
   11794:      	cmp	x8, x9
   11798:      	ldr	x25, [sp, #0x8]
   1179c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   117a0:      	add	x2, x24, #0x18
   117a4:      	mov	w8, #0x4                // =4
   117a8:      	mov	x0, x22
   117ac:      	mov	w1, #0x8                // =8
   117b0:      	blr	x8
   117b4:      	ldr	x24, [sp, #0x98]
   117b8:      	ldr	x21, [sp, #0x48]
   117bc:      	add	x2, x24, #0x20
   117c0:      	stp	x2, x24, [sp, #0x50]
   117c4:      	ldr	x8, [sp, #0x30]
   117c8:      	ldr	x25, [sp, #0x8]
   117cc:      	add	x9, sp, #0x70
   117d0:      	cmp	x21, x8
   117d4:      	b.ne	0x117e4 <generic_fentry_path+0x8524>
   117d8:      	ldr	x8, [sp, #0x38]
   117dc:      	cmp	x2, x8
   117e0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   117e4:      	mov	w8, #0x4                // =4
   117e8:      	add	x0, sp, #0x70
   117ec:      	mov	w1, #0x8                // =8
   117f0:      	blr	x8
   117f4:      	ldr	x8, [sp, #0x70]
   117f8:      	cmp	x21, x8
   117fc:      	b.eq	0x118f0 <generic_fentry_path+0x8630>
   11800:      	add	x23, x21, #0x18
   11804:      	mov	w8, #0x4                // =4
   11808:      	add	x9, sp, #0x98
   1180c:      	add	x0, sp, #0x98
   11810:      	mov	w1, #0x8                // =8
   11814:      	mov	x2, x23
   11818:      	blr	x8
   1181c:      	ldr	x8, [sp, #0x98]
   11820:      	cmp	x8, x21
   11824:      	b.eq	0x118f0 <generic_fentry_path+0x8630>
   11828:      	mov	w8, #0x4                // =4
   1182c:      	add	x9, sp, #0x78
   11830:      	add	x0, sp, #0x78
   11834:      	mov	w1, #0x8                // =8
   11838:      	mov	x2, x23
   1183c:      	blr	x8
   11840:      	add	x2, x21, #0x20
   11844:      	mov	w8, #0x4                // =4
   11848:      	mov	w9, #0x10               // =16
   1184c:      	add	x10, sp, #0x80
   11850:      	add	x0, sp, #0x80
   11854:      	mov	w1, #0x10               // =16
   11858:      	blr	x8
   1185c:      	ldr	w21, [sp, #0x84]
   11860:      	ldr	x8, [sp, #0x40]
   11864:      	ldr	x10, [sp, #0x60]
   11868:      	sub	x12, x10, x8
   1186c:      	ldr	w23, [sp, #0x68]
   11870:      	subs	w10, w21, w23
   11874:      	ldr	x9, [sp, #0x88]
   11878:      	ldr	x25, [sp, #0x8]
   1187c:      	csel	w10, wzr, w10, lo
   11880:      	cmp	w23, w21
   11884:      	csel	w11, w23, w21, lo
   11888:      	cinc	w13, w11, hi
   1188c:      	sub	w14, w23, w13
   11890:      	subs	x12, x12, x13
   11894:      	str	w14, [sp, #0x68]
   11898:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   1189c:      	cmp	x12, #0xfff
   118a0:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   118a4:      	cmp	w23, w21
   118a8:      	b.ls	0x118b4 <generic_fentry_path+0x85f4>
   118ac:      	mov	w13, #0x2f              // =47
   118b0:      	strb	w13, [x8, x12]
   118b4:      	add	x19, x8, x12
   118b8:      	cmp	w23, w21
   118bc:      	add	x2, x9, x10
   118c0:      	and	w1, w11, #0xff
   118c4:      	mov	w8, #0x4                // =4
   118c8:      	cinc	x0, x19, hi
   118cc:      	blr	x8
   118d0:      	ldr	x25, [sp, #0x8]
   118d4:      	cmp	w23, w21
   118d8:      	str	x19, [sp, #0x60]
   118dc:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   118e0:      	ldr	x21, [sp, #0x78]
   118e4:      	ldp	x2, x24, [sp, #0x50]
   118e8:      	str	x21, [sp, #0x48]
   118ec:      	b	0x11940 <generic_fentry_path+0x8680>
   118f0:      	add	x2, x24, #0x10
   118f4:      	mov	w8, #0x4                // =4
   118f8:      	add	x9, sp, #0x98
   118fc:      	add	x0, sp, #0x98
   11900:      	mov	w1, #0x8                // =8
   11904:      	blr	x8
   11908:      	ldr	x8, [sp, #0x58]
   1190c:      	ldr	x9, [sp, #0x98]
   11910:      	cmp	x8, x9
   11914:      	ldr	x25, [sp, #0x8]
   11918:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   1191c:      	add	x2, x24, #0x18
   11920:      	mov	w8, #0x4                // =4
   11924:      	mov	x0, x22
   11928:      	mov	w1, #0x8                // =8
   1192c:      	blr	x8
   11930:      	ldr	x24, [sp, #0x98]
   11934:      	ldr	x21, [sp, #0x48]
   11938:      	add	x2, x24, #0x20
   1193c:      	stp	x2, x24, [sp, #0x50]
   11940:      	ldr	x8, [sp, #0x30]
   11944:      	ldr	x25, [sp, #0x8]
   11948:      	add	x9, sp, #0x70
   1194c:      	cmp	x21, x8
   11950:      	b.ne	0x11960 <generic_fentry_path+0x86a0>
   11954:      	ldr	x8, [sp, #0x38]
   11958:      	cmp	x2, x8
   1195c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   11960:      	mov	w8, #0x4                // =4
   11964:      	add	x0, sp, #0x70
   11968:      	mov	w1, #0x8                // =8
   1196c:      	blr	x8
   11970:      	ldr	x8, [sp, #0x70]
   11974:      	cmp	x21, x8
   11978:      	b.eq	0x11a6c <generic_fentry_path+0x87ac>
   1197c:      	add	x23, x21, #0x18
   11980:      	mov	w8, #0x4                // =4
   11984:      	add	x9, sp, #0x98
   11988:      	add	x0, sp, #0x98
   1198c:      	mov	w1, #0x8                // =8
   11990:      	mov	x2, x23
   11994:      	blr	x8
   11998:      	ldr	x8, [sp, #0x98]
   1199c:      	cmp	x8, x21
   119a0:      	b.eq	0x11a6c <generic_fentry_path+0x87ac>
   119a4:      	mov	w8, #0x4                // =4
   119a8:      	add	x9, sp, #0x78
   119ac:      	add	x0, sp, #0x78
   119b0:      	mov	w1, #0x8                // =8
   119b4:      	mov	x2, x23
   119b8:      	blr	x8
   119bc:      	add	x2, x21, #0x20
   119c0:      	mov	w8, #0x4                // =4
   119c4:      	mov	w9, #0x10               // =16
   119c8:      	add	x10, sp, #0x80
   119cc:      	add	x0, sp, #0x80
   119d0:      	mov	w1, #0x10               // =16
   119d4:      	blr	x8
   119d8:      	ldr	w21, [sp, #0x84]
   119dc:      	ldr	x8, [sp, #0x40]
   119e0:      	ldr	x10, [sp, #0x60]
   119e4:      	sub	x12, x10, x8
   119e8:      	ldr	w23, [sp, #0x68]
   119ec:      	subs	w10, w21, w23
   119f0:      	ldr	x9, [sp, #0x88]
   119f4:      	ldr	x25, [sp, #0x8]
   119f8:      	csel	w10, wzr, w10, lo
   119fc:      	cmp	w23, w21
   11a00:      	csel	w11, w23, w21, lo
   11a04:      	cinc	w13, w11, hi
   11a08:      	sub	w14, w23, w13
   11a0c:      	subs	x12, x12, x13
   11a10:      	str	w14, [sp, #0x68]
   11a14:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   11a18:      	cmp	x12, #0xfff
   11a1c:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   11a20:      	cmp	w23, w21
   11a24:      	b.ls	0x11a30 <generic_fentry_path+0x8770>
   11a28:      	mov	w13, #0x2f              // =47
   11a2c:      	strb	w13, [x8, x12]
   11a30:      	add	x19, x8, x12
   11a34:      	cmp	w23, w21
   11a38:      	add	x2, x9, x10
   11a3c:      	and	w1, w11, #0xff
   11a40:      	mov	w8, #0x4                // =4
   11a44:      	cinc	x0, x19, hi
   11a48:      	blr	x8
   11a4c:      	ldr	x25, [sp, #0x8]
   11a50:      	cmp	w23, w21
   11a54:      	str	x19, [sp, #0x60]
   11a58:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   11a5c:      	ldr	x21, [sp, #0x78]
   11a60:      	ldp	x2, x24, [sp, #0x50]
   11a64:      	str	x21, [sp, #0x48]
   11a68:      	b	0x11abc <generic_fentry_path+0x87fc>
   11a6c:      	add	x2, x24, #0x10
   11a70:      	mov	w8, #0x4                // =4
   11a74:      	add	x9, sp, #0x98
   11a78:      	add	x0, sp, #0x98
   11a7c:      	mov	w1, #0x8                // =8
   11a80:      	blr	x8
   11a84:      	ldr	x8, [sp, #0x58]
   11a88:      	ldr	x9, [sp, #0x98]
   11a8c:      	cmp	x8, x9
   11a90:      	ldr	x25, [sp, #0x8]
   11a94:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   11a98:      	add	x2, x24, #0x18
   11a9c:      	mov	w8, #0x4                // =4
   11aa0:      	mov	x0, x22
   11aa4:      	mov	w1, #0x8                // =8
   11aa8:      	blr	x8
   11aac:      	ldr	x24, [sp, #0x98]
   11ab0:      	ldr	x21, [sp, #0x48]
   11ab4:      	add	x2, x24, #0x20
   11ab8:      	stp	x2, x24, [sp, #0x50]
   11abc:      	ldr	x8, [sp, #0x30]
   11ac0:      	ldr	x25, [sp, #0x8]
   11ac4:      	add	x9, sp, #0x70
   11ac8:      	cmp	x21, x8
   11acc:      	b.ne	0x11adc <generic_fentry_path+0x881c>
   11ad0:      	ldr	x8, [sp, #0x38]
   11ad4:      	cmp	x2, x8
   11ad8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   11adc:      	mov	w8, #0x4                // =4
   11ae0:      	add	x0, sp, #0x70
   11ae4:      	mov	w1, #0x8                // =8
   11ae8:      	blr	x8
   11aec:      	ldr	x8, [sp, #0x70]
   11af0:      	cmp	x21, x8
   11af4:      	b.eq	0x11be8 <generic_fentry_path+0x8928>
   11af8:      	add	x23, x21, #0x18
   11afc:      	mov	w8, #0x4                // =4
   11b00:      	add	x9, sp, #0x98
   11b04:      	add	x0, sp, #0x98
   11b08:      	mov	w1, #0x8                // =8
   11b0c:      	mov	x2, x23
   11b10:      	blr	x8
   11b14:      	ldr	x8, [sp, #0x98]
   11b18:      	cmp	x8, x21
   11b1c:      	b.eq	0x11be8 <generic_fentry_path+0x8928>
   11b20:      	mov	w8, #0x4                // =4
   11b24:      	add	x9, sp, #0x78
   11b28:      	add	x0, sp, #0x78
   11b2c:      	mov	w1, #0x8                // =8
   11b30:      	mov	x2, x23
   11b34:      	blr	x8
   11b38:      	add	x2, x21, #0x20
   11b3c:      	mov	w8, #0x4                // =4
   11b40:      	mov	w9, #0x10               // =16
   11b44:      	add	x10, sp, #0x80
   11b48:      	add	x0, sp, #0x80
   11b4c:      	mov	w1, #0x10               // =16
   11b50:      	blr	x8
   11b54:      	ldr	w21, [sp, #0x84]
   11b58:      	ldr	x8, [sp, #0x40]
   11b5c:      	ldr	x10, [sp, #0x60]
   11b60:      	sub	x12, x10, x8
   11b64:      	ldr	w23, [sp, #0x68]
   11b68:      	subs	w10, w21, w23
   11b6c:      	ldr	x9, [sp, #0x88]
   11b70:      	ldr	x25, [sp, #0x8]
   11b74:      	csel	w10, wzr, w10, lo
   11b78:      	cmp	w23, w21
   11b7c:      	csel	w11, w23, w21, lo
   11b80:      	cinc	w13, w11, hi
   11b84:      	sub	w14, w23, w13
   11b88:      	subs	x12, x12, x13
   11b8c:      	str	w14, [sp, #0x68]
   11b90:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   11b94:      	cmp	x12, #0xfff
   11b98:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   11b9c:      	cmp	w23, w21
   11ba0:      	b.ls	0x11bac <generic_fentry_path+0x88ec>
   11ba4:      	mov	w13, #0x2f              // =47
   11ba8:      	strb	w13, [x8, x12]
   11bac:      	add	x19, x8, x12
   11bb0:      	cmp	w23, w21
   11bb4:      	add	x2, x9, x10
   11bb8:      	and	w1, w11, #0xff
   11bbc:      	mov	w8, #0x4                // =4
   11bc0:      	cinc	x0, x19, hi
   11bc4:      	blr	x8
   11bc8:      	ldr	x25, [sp, #0x8]
   11bcc:      	cmp	w23, w21
   11bd0:      	str	x19, [sp, #0x60]
   11bd4:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   11bd8:      	ldr	x21, [sp, #0x78]
   11bdc:      	ldp	x2, x24, [sp, #0x50]
   11be0:      	str	x21, [sp, #0x48]
   11be4:      	b	0x11c38 <generic_fentry_path+0x8978>
   11be8:      	add	x2, x24, #0x10
   11bec:      	mov	w8, #0x4                // =4
   11bf0:      	add	x9, sp, #0x98
   11bf4:      	add	x0, sp, #0x98
   11bf8:      	mov	w1, #0x8                // =8
   11bfc:      	blr	x8
   11c00:      	ldr	x8, [sp, #0x58]
   11c04:      	ldr	x9, [sp, #0x98]
   11c08:      	cmp	x8, x9
   11c0c:      	ldr	x25, [sp, #0x8]
   11c10:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   11c14:      	add	x2, x24, #0x18
   11c18:      	mov	w8, #0x4                // =4
   11c1c:      	mov	x0, x22
   11c20:      	mov	w1, #0x8                // =8
   11c24:      	blr	x8
   11c28:      	ldr	x24, [sp, #0x98]
   11c2c:      	ldr	x21, [sp, #0x48]
   11c30:      	add	x2, x24, #0x20
   11c34:      	stp	x2, x24, [sp, #0x50]
   11c38:      	ldr	x8, [sp, #0x30]
   11c3c:      	ldr	x25, [sp, #0x8]
   11c40:      	add	x9, sp, #0x70
   11c44:      	cmp	x21, x8
   11c48:      	b.ne	0x11c58 <generic_fentry_path+0x8998>
   11c4c:      	ldr	x8, [sp, #0x38]
   11c50:      	cmp	x2, x8
   11c54:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   11c58:      	mov	w8, #0x4                // =4
   11c5c:      	add	x0, sp, #0x70
   11c60:      	mov	w1, #0x8                // =8
   11c64:      	blr	x8
   11c68:      	ldr	x8, [sp, #0x70]
   11c6c:      	cmp	x21, x8
   11c70:      	b.eq	0x11d64 <generic_fentry_path+0x8aa4>
   11c74:      	add	x23, x21, #0x18
   11c78:      	mov	w8, #0x4                // =4
   11c7c:      	add	x9, sp, #0x98
   11c80:      	add	x0, sp, #0x98
   11c84:      	mov	w1, #0x8                // =8
   11c88:      	mov	x2, x23
   11c8c:      	blr	x8
   11c90:      	ldr	x8, [sp, #0x98]
   11c94:      	cmp	x8, x21
   11c98:      	b.eq	0x11d64 <generic_fentry_path+0x8aa4>
   11c9c:      	mov	w8, #0x4                // =4
   11ca0:      	add	x9, sp, #0x78
   11ca4:      	add	x0, sp, #0x78
   11ca8:      	mov	w1, #0x8                // =8
   11cac:      	mov	x2, x23
   11cb0:      	blr	x8
   11cb4:      	add	x2, x21, #0x20
   11cb8:      	mov	w8, #0x4                // =4
   11cbc:      	mov	w9, #0x10               // =16
   11cc0:      	add	x10, sp, #0x80
   11cc4:      	add	x0, sp, #0x80
   11cc8:      	mov	w1, #0x10               // =16
   11ccc:      	blr	x8
   11cd0:      	ldr	w21, [sp, #0x84]
   11cd4:      	ldr	x8, [sp, #0x40]
   11cd8:      	ldr	x10, [sp, #0x60]
   11cdc:      	sub	x12, x10, x8
   11ce0:      	ldr	w23, [sp, #0x68]
   11ce4:      	subs	w10, w21, w23
   11ce8:      	ldr	x9, [sp, #0x88]
   11cec:      	ldr	x25, [sp, #0x8]
   11cf0:      	csel	w10, wzr, w10, lo
   11cf4:      	cmp	w23, w21
   11cf8:      	csel	w11, w23, w21, lo
   11cfc:      	cinc	w13, w11, hi
   11d00:      	sub	w14, w23, w13
   11d04:      	subs	x12, x12, x13
   11d08:      	str	w14, [sp, #0x68]
   11d0c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   11d10:      	cmp	x12, #0xfff
   11d14:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   11d18:      	cmp	w23, w21
   11d1c:      	b.ls	0x11d28 <generic_fentry_path+0x8a68>
   11d20:      	mov	w13, #0x2f              // =47
   11d24:      	strb	w13, [x8, x12]
   11d28:      	add	x19, x8, x12
   11d2c:      	cmp	w23, w21
   11d30:      	add	x2, x9, x10
   11d34:      	and	w1, w11, #0xff
   11d38:      	mov	w8, #0x4                // =4
   11d3c:      	cinc	x0, x19, hi
   11d40:      	blr	x8
   11d44:      	ldr	x25, [sp, #0x8]
   11d48:      	cmp	w23, w21
   11d4c:      	str	x19, [sp, #0x60]
   11d50:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   11d54:      	ldr	x21, [sp, #0x78]
   11d58:      	ldp	x2, x24, [sp, #0x50]
   11d5c:      	str	x21, [sp, #0x48]
   11d60:      	b	0x11db4 <generic_fentry_path+0x8af4>
   11d64:      	add	x2, x24, #0x10
   11d68:      	mov	w8, #0x4                // =4
   11d6c:      	add	x9, sp, #0x98
   11d70:      	add	x0, sp, #0x98
   11d74:      	mov	w1, #0x8                // =8
   11d78:      	blr	x8
   11d7c:      	ldr	x8, [sp, #0x58]
   11d80:      	ldr	x9, [sp, #0x98]
   11d84:      	cmp	x8, x9
   11d88:      	ldr	x25, [sp, #0x8]
   11d8c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   11d90:      	add	x2, x24, #0x18
   11d94:      	mov	w8, #0x4                // =4
   11d98:      	mov	x0, x22
   11d9c:      	mov	w1, #0x8                // =8
   11da0:      	blr	x8
   11da4:      	ldr	x24, [sp, #0x98]
   11da8:      	ldr	x21, [sp, #0x48]
   11dac:      	add	x2, x24, #0x20
   11db0:      	stp	x2, x24, [sp, #0x50]
   11db4:      	ldr	x8, [sp, #0x30]
   11db8:      	ldr	x25, [sp, #0x8]
   11dbc:      	add	x9, sp, #0x70
   11dc0:      	cmp	x21, x8
   11dc4:      	b.ne	0x11dd4 <generic_fentry_path+0x8b14>
   11dc8:      	ldr	x8, [sp, #0x38]
   11dcc:      	cmp	x2, x8
   11dd0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   11dd4:      	mov	w8, #0x4                // =4
   11dd8:      	add	x0, sp, #0x70
   11ddc:      	mov	w1, #0x8                // =8
   11de0:      	blr	x8
   11de4:      	ldr	x8, [sp, #0x70]
   11de8:      	cmp	x21, x8
   11dec:      	b.eq	0x11ee0 <generic_fentry_path+0x8c20>
   11df0:      	add	x23, x21, #0x18
   11df4:      	mov	w8, #0x4                // =4
   11df8:      	add	x9, sp, #0x98
   11dfc:      	add	x0, sp, #0x98
   11e00:      	mov	w1, #0x8                // =8
   11e04:      	mov	x2, x23
   11e08:      	blr	x8
   11e0c:      	ldr	x8, [sp, #0x98]
   11e10:      	cmp	x8, x21
   11e14:      	b.eq	0x11ee0 <generic_fentry_path+0x8c20>
   11e18:      	mov	w8, #0x4                // =4
   11e1c:      	add	x9, sp, #0x78
   11e20:      	add	x0, sp, #0x78
   11e24:      	mov	w1, #0x8                // =8
   11e28:      	mov	x2, x23
   11e2c:      	blr	x8
   11e30:      	add	x2, x21, #0x20
   11e34:      	mov	w8, #0x4                // =4
   11e38:      	mov	w9, #0x10               // =16
   11e3c:      	add	x10, sp, #0x80
   11e40:      	add	x0, sp, #0x80
   11e44:      	mov	w1, #0x10               // =16
   11e48:      	blr	x8
   11e4c:      	ldr	w21, [sp, #0x84]
   11e50:      	ldr	x8, [sp, #0x40]
   11e54:      	ldr	x10, [sp, #0x60]
   11e58:      	sub	x12, x10, x8
   11e5c:      	ldr	w23, [sp, #0x68]
   11e60:      	subs	w10, w21, w23
   11e64:      	ldr	x9, [sp, #0x88]
   11e68:      	ldr	x25, [sp, #0x8]
   11e6c:      	csel	w10, wzr, w10, lo
   11e70:      	cmp	w23, w21
   11e74:      	csel	w11, w23, w21, lo
   11e78:      	cinc	w13, w11, hi
   11e7c:      	sub	w14, w23, w13
   11e80:      	subs	x12, x12, x13
   11e84:      	str	w14, [sp, #0x68]
   11e88:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   11e8c:      	cmp	x12, #0xfff
   11e90:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   11e94:      	cmp	w23, w21
   11e98:      	b.ls	0x11ea4 <generic_fentry_path+0x8be4>
   11e9c:      	mov	w13, #0x2f              // =47
   11ea0:      	strb	w13, [x8, x12]
   11ea4:      	add	x19, x8, x12
   11ea8:      	cmp	w23, w21
   11eac:      	add	x2, x9, x10
   11eb0:      	and	w1, w11, #0xff
   11eb4:      	mov	w8, #0x4                // =4
   11eb8:      	cinc	x0, x19, hi
   11ebc:      	blr	x8
   11ec0:      	ldr	x25, [sp, #0x8]
   11ec4:      	cmp	w23, w21
   11ec8:      	str	x19, [sp, #0x60]
   11ecc:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   11ed0:      	ldr	x21, [sp, #0x78]
   11ed4:      	ldp	x2, x24, [sp, #0x50]
   11ed8:      	str	x21, [sp, #0x48]
   11edc:      	b	0x11f30 <generic_fentry_path+0x8c70>
   11ee0:      	add	x2, x24, #0x10
   11ee4:      	mov	w8, #0x4                // =4
   11ee8:      	add	x9, sp, #0x98
   11eec:      	add	x0, sp, #0x98
   11ef0:      	mov	w1, #0x8                // =8
   11ef4:      	blr	x8
   11ef8:      	ldr	x8, [sp, #0x58]
   11efc:      	ldr	x9, [sp, #0x98]
   11f00:      	cmp	x8, x9
   11f04:      	ldr	x25, [sp, #0x8]
   11f08:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   11f0c:      	add	x2, x24, #0x18
   11f10:      	mov	w8, #0x4                // =4
   11f14:      	mov	x0, x22
   11f18:      	mov	w1, #0x8                // =8
   11f1c:      	blr	x8
   11f20:      	ldr	x24, [sp, #0x98]
   11f24:      	ldr	x21, [sp, #0x48]
   11f28:      	add	x2, x24, #0x20
   11f2c:      	stp	x2, x24, [sp, #0x50]
   11f30:      	ldr	x8, [sp, #0x30]
   11f34:      	ldr	x25, [sp, #0x8]
   11f38:      	add	x9, sp, #0x70
   11f3c:      	cmp	x21, x8
   11f40:      	b.ne	0x11f50 <generic_fentry_path+0x8c90>
   11f44:      	ldr	x8, [sp, #0x38]
   11f48:      	cmp	x2, x8
   11f4c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   11f50:      	mov	w8, #0x4                // =4
   11f54:      	add	x0, sp, #0x70
   11f58:      	mov	w1, #0x8                // =8
   11f5c:      	blr	x8
   11f60:      	ldr	x8, [sp, #0x70]
   11f64:      	cmp	x21, x8
   11f68:      	b.eq	0x1205c <generic_fentry_path+0x8d9c>
   11f6c:      	add	x23, x21, #0x18
   11f70:      	mov	w8, #0x4                // =4
   11f74:      	add	x9, sp, #0x98
   11f78:      	add	x0, sp, #0x98
   11f7c:      	mov	w1, #0x8                // =8
   11f80:      	mov	x2, x23
   11f84:      	blr	x8
   11f88:      	ldr	x8, [sp, #0x98]
   11f8c:      	cmp	x8, x21
   11f90:      	b.eq	0x1205c <generic_fentry_path+0x8d9c>
   11f94:      	mov	w8, #0x4                // =4
   11f98:      	add	x9, sp, #0x78
   11f9c:      	add	x0, sp, #0x78
   11fa0:      	mov	w1, #0x8                // =8
   11fa4:      	mov	x2, x23
   11fa8:      	blr	x8
   11fac:      	add	x2, x21, #0x20
   11fb0:      	mov	w8, #0x4                // =4
   11fb4:      	mov	w9, #0x10               // =16
   11fb8:      	add	x10, sp, #0x80
   11fbc:      	add	x0, sp, #0x80
   11fc0:      	mov	w1, #0x10               // =16
   11fc4:      	blr	x8
   11fc8:      	ldr	w21, [sp, #0x84]
   11fcc:      	ldr	x8, [sp, #0x40]
   11fd0:      	ldr	x10, [sp, #0x60]
   11fd4:      	sub	x12, x10, x8
   11fd8:      	ldr	w23, [sp, #0x68]
   11fdc:      	subs	w10, w21, w23
   11fe0:      	ldr	x9, [sp, #0x88]
   11fe4:      	ldr	x25, [sp, #0x8]
   11fe8:      	csel	w10, wzr, w10, lo
   11fec:      	cmp	w23, w21
   11ff0:      	csel	w11, w23, w21, lo
   11ff4:      	cinc	w13, w11, hi
   11ff8:      	sub	w14, w23, w13
   11ffc:      	subs	x12, x12, x13
   12000:      	str	w14, [sp, #0x68]
   12004:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   12008:      	cmp	x12, #0xfff
   1200c:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   12010:      	cmp	w23, w21
   12014:      	b.ls	0x12020 <generic_fentry_path+0x8d60>
   12018:      	mov	w13, #0x2f              // =47
   1201c:      	strb	w13, [x8, x12]
   12020:      	add	x19, x8, x12
   12024:      	cmp	w23, w21
   12028:      	add	x2, x9, x10
   1202c:      	and	w1, w11, #0xff
   12030:      	mov	w8, #0x4                // =4
   12034:      	cinc	x0, x19, hi
   12038:      	blr	x8
   1203c:      	ldr	x25, [sp, #0x8]
   12040:      	cmp	w23, w21
   12044:      	str	x19, [sp, #0x60]
   12048:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   1204c:      	ldr	x21, [sp, #0x78]
   12050:      	ldp	x2, x24, [sp, #0x50]
   12054:      	str	x21, [sp, #0x48]
   12058:      	b	0x120ac <generic_fentry_path+0x8dec>
   1205c:      	add	x2, x24, #0x10
   12060:      	mov	w8, #0x4                // =4
   12064:      	add	x9, sp, #0x98
   12068:      	add	x0, sp, #0x98
   1206c:      	mov	w1, #0x8                // =8
   12070:      	blr	x8
   12074:      	ldr	x8, [sp, #0x58]
   12078:      	ldr	x9, [sp, #0x98]
   1207c:      	cmp	x8, x9
   12080:      	ldr	x25, [sp, #0x8]
   12084:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   12088:      	add	x2, x24, #0x18
   1208c:      	mov	w8, #0x4                // =4
   12090:      	mov	x0, x22
   12094:      	mov	w1, #0x8                // =8
   12098:      	blr	x8
   1209c:      	ldr	x24, [sp, #0x98]
   120a0:      	ldr	x21, [sp, #0x48]
   120a4:      	add	x2, x24, #0x20
   120a8:      	stp	x2, x24, [sp, #0x50]
   120ac:      	ldr	x8, [sp, #0x30]
   120b0:      	ldr	x25, [sp, #0x8]
   120b4:      	add	x9, sp, #0x70
   120b8:      	cmp	x21, x8
   120bc:      	b.ne	0x120cc <generic_fentry_path+0x8e0c>
   120c0:      	ldr	x8, [sp, #0x38]
   120c4:      	cmp	x2, x8
   120c8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   120cc:      	mov	w8, #0x4                // =4
   120d0:      	add	x0, sp, #0x70
   120d4:      	mov	w1, #0x8                // =8
   120d8:      	blr	x8
   120dc:      	ldr	x8, [sp, #0x70]
   120e0:      	cmp	x21, x8
   120e4:      	b.eq	0x121d8 <generic_fentry_path+0x8f18>
   120e8:      	add	x23, x21, #0x18
   120ec:      	mov	w8, #0x4                // =4
   120f0:      	add	x9, sp, #0x98
   120f4:      	add	x0, sp, #0x98
   120f8:      	mov	w1, #0x8                // =8
   120fc:      	mov	x2, x23
   12100:      	blr	x8
   12104:      	ldr	x8, [sp, #0x98]
   12108:      	cmp	x8, x21
   1210c:      	b.eq	0x121d8 <generic_fentry_path+0x8f18>
   12110:      	mov	w8, #0x4                // =4
   12114:      	add	x9, sp, #0x78
   12118:      	add	x0, sp, #0x78
   1211c:      	mov	w1, #0x8                // =8
   12120:      	mov	x2, x23
   12124:      	blr	x8
   12128:      	add	x2, x21, #0x20
   1212c:      	mov	w8, #0x4                // =4
   12130:      	mov	w9, #0x10               // =16
   12134:      	add	x10, sp, #0x80
   12138:      	add	x0, sp, #0x80
   1213c:      	mov	w1, #0x10               // =16
   12140:      	blr	x8
   12144:      	ldr	w21, [sp, #0x84]
   12148:      	ldr	x8, [sp, #0x40]
   1214c:      	ldr	x10, [sp, #0x60]
   12150:      	sub	x12, x10, x8
   12154:      	ldr	w23, [sp, #0x68]
   12158:      	subs	w10, w21, w23
   1215c:      	ldr	x9, [sp, #0x88]
   12160:      	ldr	x25, [sp, #0x8]
   12164:      	csel	w10, wzr, w10, lo
   12168:      	cmp	w23, w21
   1216c:      	csel	w11, w23, w21, lo
   12170:      	cinc	w13, w11, hi
   12174:      	sub	w14, w23, w13
   12178:      	subs	x12, x12, x13
   1217c:      	str	w14, [sp, #0x68]
   12180:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   12184:      	cmp	x12, #0xfff
   12188:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   1218c:      	cmp	w23, w21
   12190:      	b.ls	0x1219c <generic_fentry_path+0x8edc>
   12194:      	mov	w13, #0x2f              // =47
   12198:      	strb	w13, [x8, x12]
   1219c:      	add	x19, x8, x12
   121a0:      	cmp	w23, w21
   121a4:      	add	x2, x9, x10
   121a8:      	and	w1, w11, #0xff
   121ac:      	mov	w8, #0x4                // =4
   121b0:      	cinc	x0, x19, hi
   121b4:      	blr	x8
   121b8:      	ldr	x25, [sp, #0x8]
   121bc:      	cmp	w23, w21
   121c0:      	str	x19, [sp, #0x60]
   121c4:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   121c8:      	ldr	x21, [sp, #0x78]
   121cc:      	ldp	x2, x24, [sp, #0x50]
   121d0:      	str	x21, [sp, #0x48]
   121d4:      	b	0x12228 <generic_fentry_path+0x8f68>
   121d8:      	add	x2, x24, #0x10
   121dc:      	mov	w8, #0x4                // =4
   121e0:      	add	x9, sp, #0x98
   121e4:      	add	x0, sp, #0x98
   121e8:      	mov	w1, #0x8                // =8
   121ec:      	blr	x8
   121f0:      	ldr	x8, [sp, #0x58]
   121f4:      	ldr	x9, [sp, #0x98]
   121f8:      	cmp	x8, x9
   121fc:      	ldr	x25, [sp, #0x8]
   12200:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   12204:      	add	x2, x24, #0x18
   12208:      	mov	w8, #0x4                // =4
   1220c:      	mov	x0, x22
   12210:      	mov	w1, #0x8                // =8
   12214:      	blr	x8
   12218:      	ldr	x24, [sp, #0x98]
   1221c:      	ldr	x21, [sp, #0x48]
   12220:      	add	x2, x24, #0x20
   12224:      	stp	x2, x24, [sp, #0x50]
   12228:      	ldr	x8, [sp, #0x30]
   1222c:      	ldr	x25, [sp, #0x8]
   12230:      	add	x9, sp, #0x70
   12234:      	cmp	x21, x8
   12238:      	b.ne	0x12248 <generic_fentry_path+0x8f88>
   1223c:      	ldr	x8, [sp, #0x38]
   12240:      	cmp	x2, x8
   12244:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   12248:      	mov	w8, #0x4                // =4
   1224c:      	add	x0, sp, #0x70
   12250:      	mov	w1, #0x8                // =8
   12254:      	blr	x8
   12258:      	ldr	x8, [sp, #0x70]
   1225c:      	cmp	x21, x8
   12260:      	b.eq	0x12354 <generic_fentry_path+0x9094>
   12264:      	add	x23, x21, #0x18
   12268:      	mov	w8, #0x4                // =4
   1226c:      	add	x9, sp, #0x98
   12270:      	add	x0, sp, #0x98
   12274:      	mov	w1, #0x8                // =8
   12278:      	mov	x2, x23
   1227c:      	blr	x8
   12280:      	ldr	x8, [sp, #0x98]
   12284:      	cmp	x8, x21
   12288:      	b.eq	0x12354 <generic_fentry_path+0x9094>
   1228c:      	mov	w8, #0x4                // =4
   12290:      	add	x9, sp, #0x78
   12294:      	add	x0, sp, #0x78
   12298:      	mov	w1, #0x8                // =8
   1229c:      	mov	x2, x23
   122a0:      	blr	x8
   122a4:      	add	x2, x21, #0x20
   122a8:      	mov	w8, #0x4                // =4
   122ac:      	mov	w9, #0x10               // =16
   122b0:      	add	x10, sp, #0x80
   122b4:      	add	x0, sp, #0x80
   122b8:      	mov	w1, #0x10               // =16
   122bc:      	blr	x8
   122c0:      	ldr	w21, [sp, #0x84]
   122c4:      	ldr	x8, [sp, #0x40]
   122c8:      	ldr	x10, [sp, #0x60]
   122cc:      	sub	x12, x10, x8
   122d0:      	ldr	w23, [sp, #0x68]
   122d4:      	subs	w10, w21, w23
   122d8:      	ldr	x9, [sp, #0x88]
   122dc:      	ldr	x25, [sp, #0x8]
   122e0:      	csel	w10, wzr, w10, lo
   122e4:      	cmp	w23, w21
   122e8:      	csel	w11, w23, w21, lo
   122ec:      	cinc	w13, w11, hi
   122f0:      	sub	w14, w23, w13
   122f4:      	subs	x12, x12, x13
   122f8:      	str	w14, [sp, #0x68]
   122fc:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   12300:      	cmp	x12, #0xfff
   12304:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   12308:      	cmp	w23, w21
   1230c:      	b.ls	0x12318 <generic_fentry_path+0x9058>
   12310:      	mov	w13, #0x2f              // =47
   12314:      	strb	w13, [x8, x12]
   12318:      	add	x19, x8, x12
   1231c:      	cmp	w23, w21
   12320:      	add	x2, x9, x10
   12324:      	and	w1, w11, #0xff
   12328:      	mov	w8, #0x4                // =4
   1232c:      	cinc	x0, x19, hi
   12330:      	blr	x8
   12334:      	ldr	x25, [sp, #0x8]
   12338:      	cmp	w23, w21
   1233c:      	str	x19, [sp, #0x60]
   12340:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   12344:      	ldr	x21, [sp, #0x78]
   12348:      	ldp	x2, x24, [sp, #0x50]
   1234c:      	str	x21, [sp, #0x48]
   12350:      	b	0x123a4 <generic_fentry_path+0x90e4>
   12354:      	add	x2, x24, #0x10
   12358:      	mov	w8, #0x4                // =4
   1235c:      	add	x9, sp, #0x98
   12360:      	add	x0, sp, #0x98
   12364:      	mov	w1, #0x8                // =8
   12368:      	blr	x8
   1236c:      	ldr	x8, [sp, #0x58]
   12370:      	ldr	x9, [sp, #0x98]
   12374:      	cmp	x8, x9
   12378:      	ldr	x25, [sp, #0x8]
   1237c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   12380:      	add	x2, x24, #0x18
   12384:      	mov	w8, #0x4                // =4
   12388:      	mov	x0, x22
   1238c:      	mov	w1, #0x8                // =8
   12390:      	blr	x8
   12394:      	ldr	x24, [sp, #0x98]
   12398:      	ldr	x21, [sp, #0x48]
   1239c:      	add	x2, x24, #0x20
   123a0:      	stp	x2, x24, [sp, #0x50]
   123a4:      	ldr	x8, [sp, #0x30]
   123a8:      	ldr	x25, [sp, #0x8]
   123ac:      	add	x9, sp, #0x70
   123b0:      	cmp	x21, x8
   123b4:      	b.ne	0x123c4 <generic_fentry_path+0x9104>
   123b8:      	ldr	x8, [sp, #0x38]
   123bc:      	cmp	x2, x8
   123c0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   123c4:      	mov	w8, #0x4                // =4
   123c8:      	add	x0, sp, #0x70
   123cc:      	mov	w1, #0x8                // =8
   123d0:      	blr	x8
   123d4:      	ldr	x8, [sp, #0x70]
   123d8:      	cmp	x21, x8
   123dc:      	b.eq	0x124d0 <generic_fentry_path+0x9210>
   123e0:      	add	x23, x21, #0x18
   123e4:      	mov	w8, #0x4                // =4
   123e8:      	add	x9, sp, #0x98
   123ec:      	add	x0, sp, #0x98
   123f0:      	mov	w1, #0x8                // =8
   123f4:      	mov	x2, x23
   123f8:      	blr	x8
   123fc:      	ldr	x8, [sp, #0x98]
   12400:      	cmp	x8, x21
   12404:      	b.eq	0x124d0 <generic_fentry_path+0x9210>
   12408:      	mov	w8, #0x4                // =4
   1240c:      	add	x9, sp, #0x78
   12410:      	add	x0, sp, #0x78
   12414:      	mov	w1, #0x8                // =8
   12418:      	mov	x2, x23
   1241c:      	blr	x8
   12420:      	add	x2, x21, #0x20
   12424:      	mov	w8, #0x4                // =4
   12428:      	mov	w9, #0x10               // =16
   1242c:      	add	x10, sp, #0x80
   12430:      	add	x0, sp, #0x80
   12434:      	mov	w1, #0x10               // =16
   12438:      	blr	x8
   1243c:      	ldr	w21, [sp, #0x84]
   12440:      	ldr	x8, [sp, #0x40]
   12444:      	ldr	x10, [sp, #0x60]
   12448:      	sub	x12, x10, x8
   1244c:      	ldr	w23, [sp, #0x68]
   12450:      	subs	w10, w21, w23
   12454:      	ldr	x9, [sp, #0x88]
   12458:      	ldr	x25, [sp, #0x8]
   1245c:      	csel	w10, wzr, w10, lo
   12460:      	cmp	w23, w21
   12464:      	csel	w11, w23, w21, lo
   12468:      	cinc	w13, w11, hi
   1246c:      	sub	w14, w23, w13
   12470:      	subs	x12, x12, x13
   12474:      	str	w14, [sp, #0x68]
   12478:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   1247c:      	cmp	x12, #0xfff
   12480:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   12484:      	cmp	w23, w21
   12488:      	b.ls	0x12494 <generic_fentry_path+0x91d4>
   1248c:      	mov	w13, #0x2f              // =47
   12490:      	strb	w13, [x8, x12]
   12494:      	add	x19, x8, x12
   12498:      	cmp	w23, w21
   1249c:      	add	x2, x9, x10
   124a0:      	and	w1, w11, #0xff
   124a4:      	mov	w8, #0x4                // =4
   124a8:      	cinc	x0, x19, hi
   124ac:      	blr	x8
   124b0:      	ldr	x25, [sp, #0x8]
   124b4:      	cmp	w23, w21
   124b8:      	str	x19, [sp, #0x60]
   124bc:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   124c0:      	ldr	x21, [sp, #0x78]
   124c4:      	ldp	x2, x24, [sp, #0x50]
   124c8:      	str	x21, [sp, #0x48]
   124cc:      	b	0x12520 <generic_fentry_path+0x9260>
   124d0:      	add	x2, x24, #0x10
   124d4:      	mov	w8, #0x4                // =4
   124d8:      	add	x9, sp, #0x98
   124dc:      	add	x0, sp, #0x98
   124e0:      	mov	w1, #0x8                // =8
   124e4:      	blr	x8
   124e8:      	ldr	x8, [sp, #0x58]
   124ec:      	ldr	x9, [sp, #0x98]
   124f0:      	cmp	x8, x9
   124f4:      	ldr	x25, [sp, #0x8]
   124f8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   124fc:      	add	x2, x24, #0x18
   12500:      	mov	w8, #0x4                // =4
   12504:      	mov	x0, x22
   12508:      	mov	w1, #0x8                // =8
   1250c:      	blr	x8
   12510:      	ldr	x24, [sp, #0x98]
   12514:      	ldr	x21, [sp, #0x48]
   12518:      	add	x2, x24, #0x20
   1251c:      	stp	x2, x24, [sp, #0x50]
   12520:      	ldr	x8, [sp, #0x30]
   12524:      	ldr	x25, [sp, #0x8]
   12528:      	add	x9, sp, #0x70
   1252c:      	cmp	x21, x8
   12530:      	b.ne	0x12540 <generic_fentry_path+0x9280>
   12534:      	ldr	x8, [sp, #0x38]
   12538:      	cmp	x2, x8
   1253c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   12540:      	mov	w8, #0x4                // =4
   12544:      	add	x0, sp, #0x70
   12548:      	mov	w1, #0x8                // =8
   1254c:      	blr	x8
   12550:      	ldr	x8, [sp, #0x70]
   12554:      	cmp	x21, x8
   12558:      	b.eq	0x1264c <generic_fentry_path+0x938c>
   1255c:      	add	x23, x21, #0x18
   12560:      	mov	w8, #0x4                // =4
   12564:      	add	x9, sp, #0x98
   12568:      	add	x0, sp, #0x98
   1256c:      	mov	w1, #0x8                // =8
   12570:      	mov	x2, x23
   12574:      	blr	x8
   12578:      	ldr	x8, [sp, #0x98]
   1257c:      	cmp	x8, x21
   12580:      	b.eq	0x1264c <generic_fentry_path+0x938c>
   12584:      	mov	w8, #0x4                // =4
   12588:      	add	x9, sp, #0x78
   1258c:      	add	x0, sp, #0x78
   12590:      	mov	w1, #0x8                // =8
   12594:      	mov	x2, x23
   12598:      	blr	x8
   1259c:      	add	x2, x21, #0x20
   125a0:      	mov	w8, #0x4                // =4
   125a4:      	mov	w9, #0x10               // =16
   125a8:      	add	x10, sp, #0x80
   125ac:      	add	x0, sp, #0x80
   125b0:      	mov	w1, #0x10               // =16
   125b4:      	blr	x8
   125b8:      	ldr	w21, [sp, #0x84]
   125bc:      	ldr	x8, [sp, #0x40]
   125c0:      	ldr	x10, [sp, #0x60]
   125c4:      	sub	x12, x10, x8
   125c8:      	ldr	w23, [sp, #0x68]
   125cc:      	subs	w10, w21, w23
   125d0:      	ldr	x9, [sp, #0x88]
   125d4:      	ldr	x25, [sp, #0x8]
   125d8:      	csel	w10, wzr, w10, lo
   125dc:      	cmp	w23, w21
   125e0:      	csel	w11, w23, w21, lo
   125e4:      	cinc	w13, w11, hi
   125e8:      	sub	w14, w23, w13
   125ec:      	subs	x12, x12, x13
   125f0:      	str	w14, [sp, #0x68]
   125f4:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   125f8:      	cmp	x12, #0xfff
   125fc:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   12600:      	cmp	w23, w21
   12604:      	b.ls	0x12610 <generic_fentry_path+0x9350>
   12608:      	mov	w13, #0x2f              // =47
   1260c:      	strb	w13, [x8, x12]
   12610:      	add	x19, x8, x12
   12614:      	cmp	w23, w21
   12618:      	add	x2, x9, x10
   1261c:      	and	w1, w11, #0xff
   12620:      	mov	w8, #0x4                // =4
   12624:      	cinc	x0, x19, hi
   12628:      	blr	x8
   1262c:      	ldr	x25, [sp, #0x8]
   12630:      	cmp	w23, w21
   12634:      	str	x19, [sp, #0x60]
   12638:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   1263c:      	ldr	x21, [sp, #0x78]
   12640:      	ldp	x2, x24, [sp, #0x50]
   12644:      	str	x21, [sp, #0x48]
   12648:      	b	0x1269c <generic_fentry_path+0x93dc>
   1264c:      	add	x2, x24, #0x10
   12650:      	mov	w8, #0x4                // =4
   12654:      	add	x9, sp, #0x98
   12658:      	add	x0, sp, #0x98
   1265c:      	mov	w1, #0x8                // =8
   12660:      	blr	x8
   12664:      	ldr	x8, [sp, #0x58]
   12668:      	ldr	x9, [sp, #0x98]
   1266c:      	cmp	x8, x9
   12670:      	ldr	x25, [sp, #0x8]
   12674:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   12678:      	add	x2, x24, #0x18
   1267c:      	mov	w8, #0x4                // =4
   12680:      	mov	x0, x22
   12684:      	mov	w1, #0x8                // =8
   12688:      	blr	x8
   1268c:      	ldr	x24, [sp, #0x98]
   12690:      	ldr	x21, [sp, #0x48]
   12694:      	add	x2, x24, #0x20
   12698:      	stp	x2, x24, [sp, #0x50]
   1269c:      	ldr	x8, [sp, #0x30]
   126a0:      	ldr	x25, [sp, #0x8]
   126a4:      	add	x9, sp, #0x70
   126a8:      	cmp	x21, x8
   126ac:      	b.ne	0x126bc <generic_fentry_path+0x93fc>
   126b0:      	ldr	x8, [sp, #0x38]
   126b4:      	cmp	x2, x8
   126b8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   126bc:      	mov	w8, #0x4                // =4
   126c0:      	add	x0, sp, #0x70
   126c4:      	mov	w1, #0x8                // =8
   126c8:      	blr	x8
   126cc:      	ldr	x8, [sp, #0x70]
   126d0:      	cmp	x21, x8
   126d4:      	b.eq	0x127c8 <generic_fentry_path+0x9508>
   126d8:      	add	x23, x21, #0x18
   126dc:      	mov	w8, #0x4                // =4
   126e0:      	add	x9, sp, #0x98
   126e4:      	add	x0, sp, #0x98
   126e8:      	mov	w1, #0x8                // =8
   126ec:      	mov	x2, x23
   126f0:      	blr	x8
   126f4:      	ldr	x8, [sp, #0x98]
   126f8:      	cmp	x8, x21
   126fc:      	b.eq	0x127c8 <generic_fentry_path+0x9508>
   12700:      	mov	w8, #0x4                // =4
   12704:      	add	x9, sp, #0x78
   12708:      	add	x0, sp, #0x78
   1270c:      	mov	w1, #0x8                // =8
   12710:      	mov	x2, x23
   12714:      	blr	x8
   12718:      	add	x2, x21, #0x20
   1271c:      	mov	w8, #0x4                // =4
   12720:      	mov	w9, #0x10               // =16
   12724:      	add	x10, sp, #0x80
   12728:      	add	x0, sp, #0x80
   1272c:      	mov	w1, #0x10               // =16
   12730:      	blr	x8
   12734:      	ldr	w21, [sp, #0x84]
   12738:      	ldr	x8, [sp, #0x40]
   1273c:      	ldr	x10, [sp, #0x60]
   12740:      	sub	x12, x10, x8
   12744:      	ldr	w23, [sp, #0x68]
   12748:      	subs	w10, w21, w23
   1274c:      	ldr	x9, [sp, #0x88]
   12750:      	ldr	x25, [sp, #0x8]
   12754:      	csel	w10, wzr, w10, lo
   12758:      	cmp	w23, w21
   1275c:      	csel	w11, w23, w21, lo
   12760:      	cinc	w13, w11, hi
   12764:      	sub	w14, w23, w13
   12768:      	subs	x12, x12, x13
   1276c:      	str	w14, [sp, #0x68]
   12770:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   12774:      	cmp	x12, #0xfff
   12778:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   1277c:      	cmp	w23, w21
   12780:      	b.ls	0x1278c <generic_fentry_path+0x94cc>
   12784:      	mov	w13, #0x2f              // =47
   12788:      	strb	w13, [x8, x12]
   1278c:      	add	x19, x8, x12
   12790:      	cmp	w23, w21
   12794:      	add	x2, x9, x10
   12798:      	and	w1, w11, #0xff
   1279c:      	mov	w8, #0x4                // =4
   127a0:      	cinc	x0, x19, hi
   127a4:      	blr	x8
   127a8:      	ldr	x25, [sp, #0x8]
   127ac:      	cmp	w23, w21
   127b0:      	str	x19, [sp, #0x60]
   127b4:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   127b8:      	ldr	x21, [sp, #0x78]
   127bc:      	ldp	x2, x24, [sp, #0x50]
   127c0:      	str	x21, [sp, #0x48]
   127c4:      	b	0x12818 <generic_fentry_path+0x9558>
   127c8:      	add	x2, x24, #0x10
   127cc:      	mov	w8, #0x4                // =4
   127d0:      	add	x9, sp, #0x98
   127d4:      	add	x0, sp, #0x98
   127d8:      	mov	w1, #0x8                // =8
   127dc:      	blr	x8
   127e0:      	ldr	x8, [sp, #0x58]
   127e4:      	ldr	x9, [sp, #0x98]
   127e8:      	cmp	x8, x9
   127ec:      	ldr	x25, [sp, #0x8]
   127f0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   127f4:      	add	x2, x24, #0x18
   127f8:      	mov	w8, #0x4                // =4
   127fc:      	mov	x0, x22
   12800:      	mov	w1, #0x8                // =8
   12804:      	blr	x8
   12808:      	ldr	x24, [sp, #0x98]
   1280c:      	ldr	x21, [sp, #0x48]
   12810:      	add	x2, x24, #0x20
   12814:      	stp	x2, x24, [sp, #0x50]
   12818:      	ldr	x8, [sp, #0x30]
   1281c:      	ldr	x25, [sp, #0x8]
   12820:      	add	x9, sp, #0x70
   12824:      	cmp	x21, x8
   12828:      	b.ne	0x12838 <generic_fentry_path+0x9578>
   1282c:      	ldr	x8, [sp, #0x38]
   12830:      	cmp	x2, x8
   12834:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   12838:      	mov	w8, #0x4                // =4
   1283c:      	add	x0, sp, #0x70
   12840:      	mov	w1, #0x8                // =8
   12844:      	blr	x8
   12848:      	ldr	x8, [sp, #0x70]
   1284c:      	cmp	x21, x8
   12850:      	b.eq	0x12944 <generic_fentry_path+0x9684>
   12854:      	add	x23, x21, #0x18
   12858:      	mov	w8, #0x4                // =4
   1285c:      	add	x9, sp, #0x98
   12860:      	add	x0, sp, #0x98
   12864:      	mov	w1, #0x8                // =8
   12868:      	mov	x2, x23
   1286c:      	blr	x8
   12870:      	ldr	x8, [sp, #0x98]
   12874:      	cmp	x8, x21
   12878:      	b.eq	0x12944 <generic_fentry_path+0x9684>
   1287c:      	mov	w8, #0x4                // =4
   12880:      	add	x9, sp, #0x78
   12884:      	add	x0, sp, #0x78
   12888:      	mov	w1, #0x8                // =8
   1288c:      	mov	x2, x23
   12890:      	blr	x8
   12894:      	add	x2, x21, #0x20
   12898:      	mov	w8, #0x4                // =4
   1289c:      	mov	w9, #0x10               // =16
   128a0:      	add	x10, sp, #0x80
   128a4:      	add	x0, sp, #0x80
   128a8:      	mov	w1, #0x10               // =16
   128ac:      	blr	x8
   128b0:      	ldr	w21, [sp, #0x84]
   128b4:      	ldr	x8, [sp, #0x40]
   128b8:      	ldr	x10, [sp, #0x60]
   128bc:      	sub	x12, x10, x8
   128c0:      	ldr	w23, [sp, #0x68]
   128c4:      	subs	w10, w21, w23
   128c8:      	ldr	x9, [sp, #0x88]
   128cc:      	ldr	x25, [sp, #0x8]
   128d0:      	csel	w10, wzr, w10, lo
   128d4:      	cmp	w23, w21
   128d8:      	csel	w11, w23, w21, lo
   128dc:      	cinc	w13, w11, hi
   128e0:      	sub	w14, w23, w13
   128e4:      	subs	x12, x12, x13
   128e8:      	str	w14, [sp, #0x68]
   128ec:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   128f0:      	cmp	x12, #0xfff
   128f4:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   128f8:      	cmp	w23, w21
   128fc:      	b.ls	0x12908 <generic_fentry_path+0x9648>
   12900:      	mov	w13, #0x2f              // =47
   12904:      	strb	w13, [x8, x12]
   12908:      	add	x19, x8, x12
   1290c:      	cmp	w23, w21
   12910:      	add	x2, x9, x10
   12914:      	and	w1, w11, #0xff
   12918:      	mov	w8, #0x4                // =4
   1291c:      	cinc	x0, x19, hi
   12920:      	blr	x8
   12924:      	ldr	x25, [sp, #0x8]
   12928:      	cmp	w23, w21
   1292c:      	str	x19, [sp, #0x60]
   12930:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   12934:      	ldr	x21, [sp, #0x78]
   12938:      	ldp	x2, x24, [sp, #0x50]
   1293c:      	str	x21, [sp, #0x48]
   12940:      	b	0x12994 <generic_fentry_path+0x96d4>
   12944:      	add	x2, x24, #0x10
   12948:      	mov	w8, #0x4                // =4
   1294c:      	add	x9, sp, #0x98
   12950:      	add	x0, sp, #0x98
   12954:      	mov	w1, #0x8                // =8
   12958:      	blr	x8
   1295c:      	ldr	x8, [sp, #0x58]
   12960:      	ldr	x9, [sp, #0x98]
   12964:      	cmp	x8, x9
   12968:      	ldr	x25, [sp, #0x8]
   1296c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   12970:      	add	x2, x24, #0x18
   12974:      	mov	w8, #0x4                // =4
   12978:      	mov	x0, x22
   1297c:      	mov	w1, #0x8                // =8
   12980:      	blr	x8
   12984:      	ldr	x24, [sp, #0x98]
   12988:      	ldr	x21, [sp, #0x48]
   1298c:      	add	x2, x24, #0x20
   12990:      	stp	x2, x24, [sp, #0x50]
   12994:      	ldr	x8, [sp, #0x30]
   12998:      	ldr	x25, [sp, #0x8]
   1299c:      	add	x9, sp, #0x70
   129a0:      	cmp	x21, x8
   129a4:      	b.ne	0x129b4 <generic_fentry_path+0x96f4>
   129a8:      	ldr	x8, [sp, #0x38]
   129ac:      	cmp	x2, x8
   129b0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   129b4:      	mov	w8, #0x4                // =4
   129b8:      	add	x0, sp, #0x70
   129bc:      	mov	w1, #0x8                // =8
   129c0:      	blr	x8
   129c4:      	ldr	x8, [sp, #0x70]
   129c8:      	cmp	x21, x8
   129cc:      	b.eq	0x12ac0 <generic_fentry_path+0x9800>
   129d0:      	add	x23, x21, #0x18
   129d4:      	mov	w8, #0x4                // =4
   129d8:      	add	x9, sp, #0x98
   129dc:      	add	x0, sp, #0x98
   129e0:      	mov	w1, #0x8                // =8
   129e4:      	mov	x2, x23
   129e8:      	blr	x8
   129ec:      	ldr	x8, [sp, #0x98]
   129f0:      	cmp	x8, x21
   129f4:      	b.eq	0x12ac0 <generic_fentry_path+0x9800>
   129f8:      	mov	w8, #0x4                // =4
   129fc:      	add	x9, sp, #0x78
   12a00:      	add	x0, sp, #0x78
   12a04:      	mov	w1, #0x8                // =8
   12a08:      	mov	x2, x23
   12a0c:      	blr	x8
   12a10:      	add	x2, x21, #0x20
   12a14:      	mov	w8, #0x4                // =4
   12a18:      	mov	w9, #0x10               // =16
   12a1c:      	add	x10, sp, #0x80
   12a20:      	add	x0, sp, #0x80
   12a24:      	mov	w1, #0x10               // =16
   12a28:      	blr	x8
   12a2c:      	ldr	w21, [sp, #0x84]
   12a30:      	ldr	x8, [sp, #0x40]
   12a34:      	ldr	x10, [sp, #0x60]
   12a38:      	sub	x12, x10, x8
   12a3c:      	ldr	w23, [sp, #0x68]
   12a40:      	subs	w10, w21, w23
   12a44:      	ldr	x9, [sp, #0x88]
   12a48:      	ldr	x25, [sp, #0x8]
   12a4c:      	csel	w10, wzr, w10, lo
   12a50:      	cmp	w23, w21
   12a54:      	csel	w11, w23, w21, lo
   12a58:      	cinc	w13, w11, hi
   12a5c:      	sub	w14, w23, w13
   12a60:      	subs	x12, x12, x13
   12a64:      	str	w14, [sp, #0x68]
   12a68:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   12a6c:      	cmp	x12, #0xfff
   12a70:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   12a74:      	cmp	w23, w21
   12a78:      	b.ls	0x12a84 <generic_fentry_path+0x97c4>
   12a7c:      	mov	w13, #0x2f              // =47
   12a80:      	strb	w13, [x8, x12]
   12a84:      	add	x19, x8, x12
   12a88:      	cmp	w23, w21
   12a8c:      	add	x2, x9, x10
   12a90:      	and	w1, w11, #0xff
   12a94:      	mov	w8, #0x4                // =4
   12a98:      	cinc	x0, x19, hi
   12a9c:      	blr	x8
   12aa0:      	ldr	x25, [sp, #0x8]
   12aa4:      	cmp	w23, w21
   12aa8:      	str	x19, [sp, #0x60]
   12aac:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   12ab0:      	ldr	x21, [sp, #0x78]
   12ab4:      	ldp	x2, x24, [sp, #0x50]
   12ab8:      	str	x21, [sp, #0x48]
   12abc:      	b	0x12b10 <generic_fentry_path+0x9850>
   12ac0:      	add	x2, x24, #0x10
   12ac4:      	mov	w8, #0x4                // =4
   12ac8:      	add	x9, sp, #0x98
   12acc:      	add	x0, sp, #0x98
   12ad0:      	mov	w1, #0x8                // =8
   12ad4:      	blr	x8
   12ad8:      	ldr	x8, [sp, #0x58]
   12adc:      	ldr	x9, [sp, #0x98]
   12ae0:      	cmp	x8, x9
   12ae4:      	ldr	x25, [sp, #0x8]
   12ae8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   12aec:      	add	x2, x24, #0x18
   12af0:      	mov	w8, #0x4                // =4
   12af4:      	mov	x0, x22
   12af8:      	mov	w1, #0x8                // =8
   12afc:      	blr	x8
   12b00:      	ldr	x24, [sp, #0x98]
   12b04:      	ldr	x21, [sp, #0x48]
   12b08:      	add	x2, x24, #0x20
   12b0c:      	stp	x2, x24, [sp, #0x50]
   12b10:      	ldr	x8, [sp, #0x30]
   12b14:      	ldr	x25, [sp, #0x8]
   12b18:      	add	x9, sp, #0x70
   12b1c:      	cmp	x21, x8
   12b20:      	b.ne	0x12b30 <generic_fentry_path+0x9870>
   12b24:      	ldr	x8, [sp, #0x38]
   12b28:      	cmp	x2, x8
   12b2c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   12b30:      	mov	w8, #0x4                // =4
   12b34:      	add	x0, sp, #0x70
   12b38:      	mov	w1, #0x8                // =8
   12b3c:      	blr	x8
   12b40:      	ldr	x8, [sp, #0x70]
   12b44:      	cmp	x21, x8
   12b48:      	b.eq	0x12c3c <generic_fentry_path+0x997c>
   12b4c:      	add	x23, x21, #0x18
   12b50:      	mov	w8, #0x4                // =4
   12b54:      	add	x9, sp, #0x98
   12b58:      	add	x0, sp, #0x98
   12b5c:      	mov	w1, #0x8                // =8
   12b60:      	mov	x2, x23
   12b64:      	blr	x8
   12b68:      	ldr	x8, [sp, #0x98]
   12b6c:      	cmp	x8, x21
   12b70:      	b.eq	0x12c3c <generic_fentry_path+0x997c>
   12b74:      	mov	w8, #0x4                // =4
   12b78:      	add	x9, sp, #0x78
   12b7c:      	add	x0, sp, #0x78
   12b80:      	mov	w1, #0x8                // =8
   12b84:      	mov	x2, x23
   12b88:      	blr	x8
   12b8c:      	add	x2, x21, #0x20
   12b90:      	mov	w8, #0x4                // =4
   12b94:      	mov	w9, #0x10               // =16
   12b98:      	add	x10, sp, #0x80
   12b9c:      	add	x0, sp, #0x80
   12ba0:      	mov	w1, #0x10               // =16
   12ba4:      	blr	x8
   12ba8:      	ldr	w21, [sp, #0x84]
   12bac:      	ldr	x8, [sp, #0x40]
   12bb0:      	ldr	x10, [sp, #0x60]
   12bb4:      	sub	x12, x10, x8
   12bb8:      	ldr	w23, [sp, #0x68]
   12bbc:      	subs	w10, w21, w23
   12bc0:      	ldr	x9, [sp, #0x88]
   12bc4:      	ldr	x25, [sp, #0x8]
   12bc8:      	csel	w10, wzr, w10, lo
   12bcc:      	cmp	w23, w21
   12bd0:      	csel	w11, w23, w21, lo
   12bd4:      	cinc	w13, w11, hi
   12bd8:      	sub	w14, w23, w13
   12bdc:      	subs	x12, x12, x13
   12be0:      	str	w14, [sp, #0x68]
   12be4:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   12be8:      	cmp	x12, #0xfff
   12bec:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   12bf0:      	cmp	w23, w21
   12bf4:      	b.ls	0x12c00 <generic_fentry_path+0x9940>
   12bf8:      	mov	w13, #0x2f              // =47
   12bfc:      	strb	w13, [x8, x12]
   12c00:      	add	x19, x8, x12
   12c04:      	cmp	w23, w21
   12c08:      	add	x2, x9, x10
   12c0c:      	and	w1, w11, #0xff
   12c10:      	mov	w8, #0x4                // =4
   12c14:      	cinc	x0, x19, hi
   12c18:      	blr	x8
   12c1c:      	ldr	x25, [sp, #0x8]
   12c20:      	cmp	w23, w21
   12c24:      	str	x19, [sp, #0x60]
   12c28:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   12c2c:      	ldr	x21, [sp, #0x78]
   12c30:      	ldp	x2, x24, [sp, #0x50]
   12c34:      	str	x21, [sp, #0x48]
   12c38:      	b	0x12c8c <generic_fentry_path+0x99cc>
   12c3c:      	add	x2, x24, #0x10
   12c40:      	mov	w8, #0x4                // =4
   12c44:      	add	x9, sp, #0x98
   12c48:      	add	x0, sp, #0x98
   12c4c:      	mov	w1, #0x8                // =8
   12c50:      	blr	x8
   12c54:      	ldr	x8, [sp, #0x58]
   12c58:      	ldr	x9, [sp, #0x98]
   12c5c:      	cmp	x8, x9
   12c60:      	ldr	x25, [sp, #0x8]
   12c64:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   12c68:      	add	x2, x24, #0x18
   12c6c:      	mov	w8, #0x4                // =4
   12c70:      	mov	x0, x22
   12c74:      	mov	w1, #0x8                // =8
   12c78:      	blr	x8
   12c7c:      	ldr	x24, [sp, #0x98]
   12c80:      	ldr	x21, [sp, #0x48]
   12c84:      	add	x2, x24, #0x20
   12c88:      	stp	x2, x24, [sp, #0x50]
   12c8c:      	ldr	x8, [sp, #0x30]
   12c90:      	ldr	x25, [sp, #0x8]
   12c94:      	add	x9, sp, #0x70
   12c98:      	cmp	x21, x8
   12c9c:      	b.ne	0x12cac <generic_fentry_path+0x99ec>
   12ca0:      	ldr	x8, [sp, #0x38]
   12ca4:      	cmp	x2, x8
   12ca8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   12cac:      	mov	w8, #0x4                // =4
   12cb0:      	add	x0, sp, #0x70
   12cb4:      	mov	w1, #0x8                // =8
   12cb8:      	blr	x8
   12cbc:      	ldr	x8, [sp, #0x70]
   12cc0:      	cmp	x21, x8
   12cc4:      	b.eq	0x12db8 <generic_fentry_path+0x9af8>
   12cc8:      	add	x23, x21, #0x18
   12ccc:      	mov	w8, #0x4                // =4
   12cd0:      	add	x9, sp, #0x98
   12cd4:      	add	x0, sp, #0x98
   12cd8:      	mov	w1, #0x8                // =8
   12cdc:      	mov	x2, x23
   12ce0:      	blr	x8
   12ce4:      	ldr	x8, [sp, #0x98]
   12ce8:      	cmp	x8, x21
   12cec:      	b.eq	0x12db8 <generic_fentry_path+0x9af8>
   12cf0:      	mov	w8, #0x4                // =4
   12cf4:      	add	x9, sp, #0x78
   12cf8:      	add	x0, sp, #0x78
   12cfc:      	mov	w1, #0x8                // =8
   12d00:      	mov	x2, x23
   12d04:      	blr	x8
   12d08:      	add	x2, x21, #0x20
   12d0c:      	mov	w8, #0x4                // =4
   12d10:      	mov	w9, #0x10               // =16
   12d14:      	add	x10, sp, #0x80
   12d18:      	add	x0, sp, #0x80
   12d1c:      	mov	w1, #0x10               // =16
   12d20:      	blr	x8
   12d24:      	ldr	w21, [sp, #0x84]
   12d28:      	ldr	x8, [sp, #0x40]
   12d2c:      	ldr	x10, [sp, #0x60]
   12d30:      	sub	x12, x10, x8
   12d34:      	ldr	w23, [sp, #0x68]
   12d38:      	subs	w10, w21, w23
   12d3c:      	ldr	x9, [sp, #0x88]
   12d40:      	ldr	x25, [sp, #0x8]
   12d44:      	csel	w10, wzr, w10, lo
   12d48:      	cmp	w23, w21
   12d4c:      	csel	w11, w23, w21, lo
   12d50:      	cinc	w13, w11, hi
   12d54:      	sub	w14, w23, w13
   12d58:      	subs	x12, x12, x13
   12d5c:      	str	w14, [sp, #0x68]
   12d60:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   12d64:      	cmp	x12, #0xfff
   12d68:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   12d6c:      	cmp	w23, w21
   12d70:      	b.ls	0x12d7c <generic_fentry_path+0x9abc>
   12d74:      	mov	w13, #0x2f              // =47
   12d78:      	strb	w13, [x8, x12]
   12d7c:      	add	x19, x8, x12
   12d80:      	cmp	w23, w21
   12d84:      	add	x2, x9, x10
   12d88:      	and	w1, w11, #0xff
   12d8c:      	mov	w8, #0x4                // =4
   12d90:      	cinc	x0, x19, hi
   12d94:      	blr	x8
   12d98:      	ldr	x25, [sp, #0x8]
   12d9c:      	cmp	w23, w21
   12da0:      	str	x19, [sp, #0x60]
   12da4:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   12da8:      	ldr	x21, [sp, #0x78]
   12dac:      	ldp	x2, x24, [sp, #0x50]
   12db0:      	str	x21, [sp, #0x48]
   12db4:      	b	0x12e08 <generic_fentry_path+0x9b48>
   12db8:      	add	x2, x24, #0x10
   12dbc:      	mov	w8, #0x4                // =4
   12dc0:      	add	x9, sp, #0x98
   12dc4:      	add	x0, sp, #0x98
   12dc8:      	mov	w1, #0x8                // =8
   12dcc:      	blr	x8
   12dd0:      	ldr	x8, [sp, #0x58]
   12dd4:      	ldr	x9, [sp, #0x98]
   12dd8:      	cmp	x8, x9
   12ddc:      	ldr	x25, [sp, #0x8]
   12de0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   12de4:      	add	x2, x24, #0x18
   12de8:      	mov	w8, #0x4                // =4
   12dec:      	mov	x0, x22
   12df0:      	mov	w1, #0x8                // =8
   12df4:      	blr	x8
   12df8:      	ldr	x24, [sp, #0x98]
   12dfc:      	ldr	x21, [sp, #0x48]
   12e00:      	add	x2, x24, #0x20
   12e04:      	stp	x2, x24, [sp, #0x50]
   12e08:      	ldr	x8, [sp, #0x30]
   12e0c:      	ldr	x25, [sp, #0x8]
   12e10:      	add	x9, sp, #0x70
   12e14:      	cmp	x21, x8
   12e18:      	b.ne	0x12e28 <generic_fentry_path+0x9b68>
   12e1c:      	ldr	x8, [sp, #0x38]
   12e20:      	cmp	x2, x8
   12e24:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   12e28:      	mov	w8, #0x4                // =4
   12e2c:      	add	x0, sp, #0x70
   12e30:      	mov	w1, #0x8                // =8
   12e34:      	blr	x8
   12e38:      	ldr	x8, [sp, #0x70]
   12e3c:      	cmp	x21, x8
   12e40:      	b.eq	0x12f34 <generic_fentry_path+0x9c74>
   12e44:      	add	x23, x21, #0x18
   12e48:      	mov	w8, #0x4                // =4
   12e4c:      	add	x9, sp, #0x98
   12e50:      	add	x0, sp, #0x98
   12e54:      	mov	w1, #0x8                // =8
   12e58:      	mov	x2, x23
   12e5c:      	blr	x8
   12e60:      	ldr	x8, [sp, #0x98]
   12e64:      	cmp	x8, x21
   12e68:      	b.eq	0x12f34 <generic_fentry_path+0x9c74>
   12e6c:      	mov	w8, #0x4                // =4
   12e70:      	add	x9, sp, #0x78
   12e74:      	add	x0, sp, #0x78
   12e78:      	mov	w1, #0x8                // =8
   12e7c:      	mov	x2, x23
   12e80:      	blr	x8
   12e84:      	add	x2, x21, #0x20
   12e88:      	mov	w8, #0x4                // =4
   12e8c:      	mov	w9, #0x10               // =16
   12e90:      	add	x10, sp, #0x80
   12e94:      	add	x0, sp, #0x80
   12e98:      	mov	w1, #0x10               // =16
   12e9c:      	blr	x8
   12ea0:      	ldr	w21, [sp, #0x84]
   12ea4:      	ldr	x8, [sp, #0x40]
   12ea8:      	ldr	x10, [sp, #0x60]
   12eac:      	sub	x12, x10, x8
   12eb0:      	ldr	w23, [sp, #0x68]
   12eb4:      	subs	w10, w21, w23
   12eb8:      	ldr	x9, [sp, #0x88]
   12ebc:      	ldr	x25, [sp, #0x8]
   12ec0:      	csel	w10, wzr, w10, lo
   12ec4:      	cmp	w23, w21
   12ec8:      	csel	w11, w23, w21, lo
   12ecc:      	cinc	w13, w11, hi
   12ed0:      	sub	w14, w23, w13
   12ed4:      	subs	x12, x12, x13
   12ed8:      	str	w14, [sp, #0x68]
   12edc:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   12ee0:      	cmp	x12, #0xfff
   12ee4:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   12ee8:      	cmp	w23, w21
   12eec:      	b.ls	0x12ef8 <generic_fentry_path+0x9c38>
   12ef0:      	mov	w13, #0x2f              // =47
   12ef4:      	strb	w13, [x8, x12]
   12ef8:      	add	x19, x8, x12
   12efc:      	cmp	w23, w21
   12f00:      	add	x2, x9, x10
   12f04:      	and	w1, w11, #0xff
   12f08:      	mov	w8, #0x4                // =4
   12f0c:      	cinc	x0, x19, hi
   12f10:      	blr	x8
   12f14:      	ldr	x25, [sp, #0x8]
   12f18:      	cmp	w23, w21
   12f1c:      	str	x19, [sp, #0x60]
   12f20:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   12f24:      	ldr	x21, [sp, #0x78]
   12f28:      	ldp	x2, x24, [sp, #0x50]
   12f2c:      	str	x21, [sp, #0x48]
   12f30:      	b	0x12f84 <generic_fentry_path+0x9cc4>
   12f34:      	add	x2, x24, #0x10
   12f38:      	mov	w8, #0x4                // =4
   12f3c:      	add	x9, sp, #0x98
   12f40:      	add	x0, sp, #0x98
   12f44:      	mov	w1, #0x8                // =8
   12f48:      	blr	x8
   12f4c:      	ldr	x8, [sp, #0x58]
   12f50:      	ldr	x9, [sp, #0x98]
   12f54:      	cmp	x8, x9
   12f58:      	ldr	x25, [sp, #0x8]
   12f5c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   12f60:      	add	x2, x24, #0x18
   12f64:      	mov	w8, #0x4                // =4
   12f68:      	mov	x0, x22
   12f6c:      	mov	w1, #0x8                // =8
   12f70:      	blr	x8
   12f74:      	ldr	x24, [sp, #0x98]
   12f78:      	ldr	x21, [sp, #0x48]
   12f7c:      	add	x2, x24, #0x20
   12f80:      	stp	x2, x24, [sp, #0x50]
   12f84:      	ldr	x8, [sp, #0x30]
   12f88:      	ldr	x25, [sp, #0x8]
   12f8c:      	add	x9, sp, #0x70
   12f90:      	cmp	x21, x8
   12f94:      	b.ne	0x12fa4 <generic_fentry_path+0x9ce4>
   12f98:      	ldr	x8, [sp, #0x38]
   12f9c:      	cmp	x2, x8
   12fa0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   12fa4:      	mov	w8, #0x4                // =4
   12fa8:      	add	x0, sp, #0x70
   12fac:      	mov	w1, #0x8                // =8
   12fb0:      	blr	x8
   12fb4:      	ldr	x8, [sp, #0x70]
   12fb8:      	cmp	x21, x8
   12fbc:      	b.eq	0x130b0 <generic_fentry_path+0x9df0>
   12fc0:      	add	x23, x21, #0x18
   12fc4:      	mov	w8, #0x4                // =4
   12fc8:      	add	x9, sp, #0x98
   12fcc:      	add	x0, sp, #0x98
   12fd0:      	mov	w1, #0x8                // =8
   12fd4:      	mov	x2, x23
   12fd8:      	blr	x8
   12fdc:      	ldr	x8, [sp, #0x98]
   12fe0:      	cmp	x8, x21
   12fe4:      	b.eq	0x130b0 <generic_fentry_path+0x9df0>
   12fe8:      	mov	w8, #0x4                // =4
   12fec:      	add	x9, sp, #0x78
   12ff0:      	add	x0, sp, #0x78
   12ff4:      	mov	w1, #0x8                // =8
   12ff8:      	mov	x2, x23
   12ffc:      	blr	x8
   13000:      	add	x2, x21, #0x20
   13004:      	mov	w8, #0x4                // =4
   13008:      	mov	w9, #0x10               // =16
   1300c:      	add	x10, sp, #0x80
   13010:      	add	x0, sp, #0x80
   13014:      	mov	w1, #0x10               // =16
   13018:      	blr	x8
   1301c:      	ldr	w21, [sp, #0x84]
   13020:      	ldr	x8, [sp, #0x40]
   13024:      	ldr	x10, [sp, #0x60]
   13028:      	sub	x12, x10, x8
   1302c:      	ldr	w23, [sp, #0x68]
   13030:      	subs	w10, w21, w23
   13034:      	ldr	x9, [sp, #0x88]
   13038:      	ldr	x25, [sp, #0x8]
   1303c:      	csel	w10, wzr, w10, lo
   13040:      	cmp	w23, w21
   13044:      	csel	w11, w23, w21, lo
   13048:      	cinc	w13, w11, hi
   1304c:      	sub	w14, w23, w13
   13050:      	subs	x12, x12, x13
   13054:      	str	w14, [sp, #0x68]
   13058:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   1305c:      	cmp	x12, #0xfff
   13060:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   13064:      	cmp	w23, w21
   13068:      	b.ls	0x13074 <generic_fentry_path+0x9db4>
   1306c:      	mov	w13, #0x2f              // =47
   13070:      	strb	w13, [x8, x12]
   13074:      	add	x19, x8, x12
   13078:      	cmp	w23, w21
   1307c:      	add	x2, x9, x10
   13080:      	and	w1, w11, #0xff
   13084:      	mov	w8, #0x4                // =4
   13088:      	cinc	x0, x19, hi
   1308c:      	blr	x8
   13090:      	ldr	x25, [sp, #0x8]
   13094:      	cmp	w23, w21
   13098:      	str	x19, [sp, #0x60]
   1309c:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   130a0:      	ldr	x21, [sp, #0x78]
   130a4:      	ldp	x2, x24, [sp, #0x50]
   130a8:      	str	x21, [sp, #0x48]
   130ac:      	b	0x13100 <generic_fentry_path+0x9e40>
   130b0:      	add	x2, x24, #0x10
   130b4:      	mov	w8, #0x4                // =4
   130b8:      	add	x9, sp, #0x98
   130bc:      	add	x0, sp, #0x98
   130c0:      	mov	w1, #0x8                // =8
   130c4:      	blr	x8
   130c8:      	ldr	x8, [sp, #0x58]
   130cc:      	ldr	x9, [sp, #0x98]
   130d0:      	cmp	x8, x9
   130d4:      	ldr	x25, [sp, #0x8]
   130d8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   130dc:      	add	x2, x24, #0x18
   130e0:      	mov	w8, #0x4                // =4
   130e4:      	mov	x0, x22
   130e8:      	mov	w1, #0x8                // =8
   130ec:      	blr	x8
   130f0:      	ldr	x24, [sp, #0x98]
   130f4:      	ldr	x21, [sp, #0x48]
   130f8:      	add	x2, x24, #0x20
   130fc:      	stp	x2, x24, [sp, #0x50]
   13100:      	ldr	x8, [sp, #0x30]
   13104:      	ldr	x25, [sp, #0x8]
   13108:      	add	x9, sp, #0x70
   1310c:      	cmp	x21, x8
   13110:      	b.ne	0x13120 <generic_fentry_path+0x9e60>
   13114:      	ldr	x8, [sp, #0x38]
   13118:      	cmp	x2, x8
   1311c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   13120:      	mov	w8, #0x4                // =4
   13124:      	add	x0, sp, #0x70
   13128:      	mov	w1, #0x8                // =8
   1312c:      	blr	x8
   13130:      	ldr	x8, [sp, #0x70]
   13134:      	cmp	x21, x8
   13138:      	b.eq	0x1322c <generic_fentry_path+0x9f6c>
   1313c:      	add	x23, x21, #0x18
   13140:      	mov	w8, #0x4                // =4
   13144:      	add	x9, sp, #0x98
   13148:      	add	x0, sp, #0x98
   1314c:      	mov	w1, #0x8                // =8
   13150:      	mov	x2, x23
   13154:      	blr	x8
   13158:      	ldr	x8, [sp, #0x98]
   1315c:      	cmp	x8, x21
   13160:      	b.eq	0x1322c <generic_fentry_path+0x9f6c>
   13164:      	mov	w8, #0x4                // =4
   13168:      	add	x9, sp, #0x78
   1316c:      	add	x0, sp, #0x78
   13170:      	mov	w1, #0x8                // =8
   13174:      	mov	x2, x23
   13178:      	blr	x8
   1317c:      	add	x2, x21, #0x20
   13180:      	mov	w8, #0x4                // =4
   13184:      	mov	w9, #0x10               // =16
   13188:      	add	x10, sp, #0x80
   1318c:      	add	x0, sp, #0x80
   13190:      	mov	w1, #0x10               // =16
   13194:      	blr	x8
   13198:      	ldr	w21, [sp, #0x84]
   1319c:      	ldr	x8, [sp, #0x40]
   131a0:      	ldr	x10, [sp, #0x60]
   131a4:      	sub	x12, x10, x8
   131a8:      	ldr	w23, [sp, #0x68]
   131ac:      	subs	w10, w21, w23
   131b0:      	ldr	x9, [sp, #0x88]
   131b4:      	ldr	x25, [sp, #0x8]
   131b8:      	csel	w10, wzr, w10, lo
   131bc:      	cmp	w23, w21
   131c0:      	csel	w11, w23, w21, lo
   131c4:      	cinc	w13, w11, hi
   131c8:      	sub	w14, w23, w13
   131cc:      	subs	x12, x12, x13
   131d0:      	str	w14, [sp, #0x68]
   131d4:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   131d8:      	cmp	x12, #0xfff
   131dc:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   131e0:      	cmp	w23, w21
   131e4:      	b.ls	0x131f0 <generic_fentry_path+0x9f30>
   131e8:      	mov	w13, #0x2f              // =47
   131ec:      	strb	w13, [x8, x12]
   131f0:      	add	x19, x8, x12
   131f4:      	cmp	w23, w21
   131f8:      	add	x2, x9, x10
   131fc:      	and	w1, w11, #0xff
   13200:      	mov	w8, #0x4                // =4
   13204:      	cinc	x0, x19, hi
   13208:      	blr	x8
   1320c:      	ldr	x25, [sp, #0x8]
   13210:      	cmp	w23, w21
   13214:      	str	x19, [sp, #0x60]
   13218:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   1321c:      	ldr	x21, [sp, #0x78]
   13220:      	ldp	x2, x24, [sp, #0x50]
   13224:      	str	x21, [sp, #0x48]
   13228:      	b	0x1327c <generic_fentry_path+0x9fbc>
   1322c:      	add	x2, x24, #0x10
   13230:      	mov	w8, #0x4                // =4
   13234:      	add	x9, sp, #0x98
   13238:      	add	x0, sp, #0x98
   1323c:      	mov	w1, #0x8                // =8
   13240:      	blr	x8
   13244:      	ldr	x8, [sp, #0x58]
   13248:      	ldr	x9, [sp, #0x98]
   1324c:      	cmp	x8, x9
   13250:      	ldr	x25, [sp, #0x8]
   13254:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   13258:      	add	x2, x24, #0x18
   1325c:      	mov	w8, #0x4                // =4
   13260:      	mov	x0, x22
   13264:      	mov	w1, #0x8                // =8
   13268:      	blr	x8
   1326c:      	ldr	x24, [sp, #0x98]
   13270:      	ldr	x21, [sp, #0x48]
   13274:      	add	x2, x24, #0x20
   13278:      	stp	x2, x24, [sp, #0x50]
   1327c:      	ldr	x8, [sp, #0x30]
   13280:      	ldr	x25, [sp, #0x8]
   13284:      	add	x9, sp, #0x70
   13288:      	cmp	x21, x8
   1328c:      	b.ne	0x1329c <generic_fentry_path+0x9fdc>
   13290:      	ldr	x8, [sp, #0x38]
   13294:      	cmp	x2, x8
   13298:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   1329c:      	mov	w8, #0x4                // =4
   132a0:      	add	x0, sp, #0x70
   132a4:      	mov	w1, #0x8                // =8
   132a8:      	blr	x8
   132ac:      	ldr	x8, [sp, #0x70]
   132b0:      	cmp	x21, x8
   132b4:      	b.eq	0x133a8 <generic_fentry_path+0xa0e8>
   132b8:      	add	x23, x21, #0x18
   132bc:      	mov	w8, #0x4                // =4
   132c0:      	add	x9, sp, #0x98
   132c4:      	add	x0, sp, #0x98
   132c8:      	mov	w1, #0x8                // =8
   132cc:      	mov	x2, x23
   132d0:      	blr	x8
   132d4:      	ldr	x8, [sp, #0x98]
   132d8:      	cmp	x8, x21
   132dc:      	b.eq	0x133a8 <generic_fentry_path+0xa0e8>
   132e0:      	mov	w8, #0x4                // =4
   132e4:      	add	x9, sp, #0x78
   132e8:      	add	x0, sp, #0x78
   132ec:      	mov	w1, #0x8                // =8
   132f0:      	mov	x2, x23
   132f4:      	blr	x8
   132f8:      	add	x2, x21, #0x20
   132fc:      	mov	w8, #0x4                // =4
   13300:      	mov	w9, #0x10               // =16
   13304:      	add	x10, sp, #0x80
   13308:      	add	x0, sp, #0x80
   1330c:      	mov	w1, #0x10               // =16
   13310:      	blr	x8
   13314:      	ldr	w21, [sp, #0x84]
   13318:      	ldr	x8, [sp, #0x40]
   1331c:      	ldr	x10, [sp, #0x60]
   13320:      	sub	x12, x10, x8
   13324:      	ldr	w23, [sp, #0x68]
   13328:      	subs	w10, w21, w23
   1332c:      	ldr	x9, [sp, #0x88]
   13330:      	ldr	x25, [sp, #0x8]
   13334:      	csel	w10, wzr, w10, lo
   13338:      	cmp	w23, w21
   1333c:      	csel	w11, w23, w21, lo
   13340:      	cinc	w13, w11, hi
   13344:      	sub	w14, w23, w13
   13348:      	subs	x12, x12, x13
   1334c:      	str	w14, [sp, #0x68]
   13350:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   13354:      	cmp	x12, #0xfff
   13358:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   1335c:      	cmp	w23, w21
   13360:      	b.ls	0x1336c <generic_fentry_path+0xa0ac>
   13364:      	mov	w13, #0x2f              // =47
   13368:      	strb	w13, [x8, x12]
   1336c:      	add	x19, x8, x12
   13370:      	cmp	w23, w21
   13374:      	add	x2, x9, x10
   13378:      	and	w1, w11, #0xff
   1337c:      	mov	w8, #0x4                // =4
   13380:      	cinc	x0, x19, hi
   13384:      	blr	x8
   13388:      	ldr	x25, [sp, #0x8]
   1338c:      	cmp	w23, w21
   13390:      	str	x19, [sp, #0x60]
   13394:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   13398:      	ldr	x21, [sp, #0x78]
   1339c:      	ldp	x2, x24, [sp, #0x50]
   133a0:      	str	x21, [sp, #0x48]
   133a4:      	b	0x133f8 <generic_fentry_path+0xa138>
   133a8:      	add	x2, x24, #0x10
   133ac:      	mov	w8, #0x4                // =4
   133b0:      	add	x9, sp, #0x98
   133b4:      	add	x0, sp, #0x98
   133b8:      	mov	w1, #0x8                // =8
   133bc:      	blr	x8
   133c0:      	ldr	x8, [sp, #0x58]
   133c4:      	ldr	x9, [sp, #0x98]
   133c8:      	cmp	x8, x9
   133cc:      	ldr	x25, [sp, #0x8]
   133d0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   133d4:      	add	x2, x24, #0x18
   133d8:      	mov	w8, #0x4                // =4
   133dc:      	mov	x0, x22
   133e0:      	mov	w1, #0x8                // =8
   133e4:      	blr	x8
   133e8:      	ldr	x24, [sp, #0x98]
   133ec:      	ldr	x21, [sp, #0x48]
   133f0:      	add	x2, x24, #0x20
   133f4:      	stp	x2, x24, [sp, #0x50]
   133f8:      	ldr	x8, [sp, #0x30]
   133fc:      	ldr	x25, [sp, #0x8]
   13400:      	add	x9, sp, #0x70
   13404:      	cmp	x21, x8
   13408:      	b.ne	0x13418 <generic_fentry_path+0xa158>
   1340c:      	ldr	x8, [sp, #0x38]
   13410:      	cmp	x2, x8
   13414:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   13418:      	mov	w8, #0x4                // =4
   1341c:      	add	x0, sp, #0x70
   13420:      	mov	w1, #0x8                // =8
   13424:      	blr	x8
   13428:      	ldr	x8, [sp, #0x70]
   1342c:      	cmp	x21, x8
   13430:      	b.eq	0x13524 <generic_fentry_path+0xa264>
   13434:      	add	x23, x21, #0x18
   13438:      	mov	w8, #0x4                // =4
   1343c:      	add	x9, sp, #0x98
   13440:      	add	x0, sp, #0x98
   13444:      	mov	w1, #0x8                // =8
   13448:      	mov	x2, x23
   1344c:      	blr	x8
   13450:      	ldr	x8, [sp, #0x98]
   13454:      	cmp	x8, x21
   13458:      	b.eq	0x13524 <generic_fentry_path+0xa264>
   1345c:      	mov	w8, #0x4                // =4
   13460:      	add	x9, sp, #0x78
   13464:      	add	x0, sp, #0x78
   13468:      	mov	w1, #0x8                // =8
   1346c:      	mov	x2, x23
   13470:      	blr	x8
   13474:      	add	x2, x21, #0x20
   13478:      	mov	w8, #0x4                // =4
   1347c:      	mov	w9, #0x10               // =16
   13480:      	add	x10, sp, #0x80
   13484:      	add	x0, sp, #0x80
   13488:      	mov	w1, #0x10               // =16
   1348c:      	blr	x8
   13490:      	ldr	w21, [sp, #0x84]
   13494:      	ldr	x8, [sp, #0x40]
   13498:      	ldr	x10, [sp, #0x60]
   1349c:      	sub	x12, x10, x8
   134a0:      	ldr	w23, [sp, #0x68]
   134a4:      	subs	w10, w21, w23
   134a8:      	ldr	x9, [sp, #0x88]
   134ac:      	ldr	x25, [sp, #0x8]
   134b0:      	csel	w10, wzr, w10, lo
   134b4:      	cmp	w23, w21
   134b8:      	csel	w11, w23, w21, lo
   134bc:      	cinc	w13, w11, hi
   134c0:      	sub	w14, w23, w13
   134c4:      	subs	x12, x12, x13
   134c8:      	str	w14, [sp, #0x68]
   134cc:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   134d0:      	cmp	x12, #0xfff
   134d4:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   134d8:      	cmp	w23, w21
   134dc:      	b.ls	0x134e8 <generic_fentry_path+0xa228>
   134e0:      	mov	w13, #0x2f              // =47
   134e4:      	strb	w13, [x8, x12]
   134e8:      	add	x19, x8, x12
   134ec:      	cmp	w23, w21
   134f0:      	add	x2, x9, x10
   134f4:      	and	w1, w11, #0xff
   134f8:      	mov	w8, #0x4                // =4
   134fc:      	cinc	x0, x19, hi
   13500:      	blr	x8
   13504:      	ldr	x25, [sp, #0x8]
   13508:      	cmp	w23, w21
   1350c:      	str	x19, [sp, #0x60]
   13510:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   13514:      	ldr	x21, [sp, #0x78]
   13518:      	ldp	x2, x24, [sp, #0x50]
   1351c:      	str	x21, [sp, #0x48]
   13520:      	b	0x13574 <generic_fentry_path+0xa2b4>
   13524:      	add	x2, x24, #0x10
   13528:      	mov	w8, #0x4                // =4
   1352c:      	add	x9, sp, #0x98
   13530:      	add	x0, sp, #0x98
   13534:      	mov	w1, #0x8                // =8
   13538:      	blr	x8
   1353c:      	ldr	x8, [sp, #0x58]
   13540:      	ldr	x9, [sp, #0x98]
   13544:      	cmp	x8, x9
   13548:      	ldr	x25, [sp, #0x8]
   1354c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   13550:      	add	x2, x24, #0x18
   13554:      	mov	w8, #0x4                // =4
   13558:      	mov	x0, x22
   1355c:      	mov	w1, #0x8                // =8
   13560:      	blr	x8
   13564:      	ldr	x24, [sp, #0x98]
   13568:      	ldr	x21, [sp, #0x48]
   1356c:      	add	x2, x24, #0x20
   13570:      	stp	x2, x24, [sp, #0x50]
   13574:      	ldr	x8, [sp, #0x30]
   13578:      	ldr	x25, [sp, #0x8]
   1357c:      	add	x9, sp, #0x70
   13580:      	cmp	x21, x8
   13584:      	b.ne	0x13594 <generic_fentry_path+0xa2d4>
   13588:      	ldr	x8, [sp, #0x38]
   1358c:      	cmp	x2, x8
   13590:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   13594:      	mov	w8, #0x4                // =4
   13598:      	add	x0, sp, #0x70
   1359c:      	mov	w1, #0x8                // =8
   135a0:      	blr	x8
   135a4:      	ldr	x8, [sp, #0x70]
   135a8:      	cmp	x21, x8
   135ac:      	b.eq	0x136a0 <generic_fentry_path+0xa3e0>
   135b0:      	add	x23, x21, #0x18
   135b4:      	mov	w8, #0x4                // =4
   135b8:      	add	x9, sp, #0x98
   135bc:      	add	x0, sp, #0x98
   135c0:      	mov	w1, #0x8                // =8
   135c4:      	mov	x2, x23
   135c8:      	blr	x8
   135cc:      	ldr	x8, [sp, #0x98]
   135d0:      	cmp	x8, x21
   135d4:      	b.eq	0x136a0 <generic_fentry_path+0xa3e0>
   135d8:      	mov	w8, #0x4                // =4
   135dc:      	add	x9, sp, #0x78
   135e0:      	add	x0, sp, #0x78
   135e4:      	mov	w1, #0x8                // =8
   135e8:      	mov	x2, x23
   135ec:      	blr	x8
   135f0:      	add	x2, x21, #0x20
   135f4:      	mov	w8, #0x4                // =4
   135f8:      	mov	w9, #0x10               // =16
   135fc:      	add	x10, sp, #0x80
   13600:      	add	x0, sp, #0x80
   13604:      	mov	w1, #0x10               // =16
   13608:      	blr	x8
   1360c:      	ldr	w21, [sp, #0x84]
   13610:      	ldr	x8, [sp, #0x40]
   13614:      	ldr	x10, [sp, #0x60]
   13618:      	sub	x12, x10, x8
   1361c:      	ldr	w23, [sp, #0x68]
   13620:      	subs	w10, w21, w23
   13624:      	ldr	x9, [sp, #0x88]
   13628:      	ldr	x25, [sp, #0x8]
   1362c:      	csel	w10, wzr, w10, lo
   13630:      	cmp	w23, w21
   13634:      	csel	w11, w23, w21, lo
   13638:      	cinc	w13, w11, hi
   1363c:      	sub	w14, w23, w13
   13640:      	subs	x12, x12, x13
   13644:      	str	w14, [sp, #0x68]
   13648:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   1364c:      	cmp	x12, #0xfff
   13650:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   13654:      	cmp	w23, w21
   13658:      	b.ls	0x13664 <generic_fentry_path+0xa3a4>
   1365c:      	mov	w13, #0x2f              // =47
   13660:      	strb	w13, [x8, x12]
   13664:      	add	x19, x8, x12
   13668:      	cmp	w23, w21
   1366c:      	add	x2, x9, x10
   13670:      	and	w1, w11, #0xff
   13674:      	mov	w8, #0x4                // =4
   13678:      	cinc	x0, x19, hi
   1367c:      	blr	x8
   13680:      	ldr	x25, [sp, #0x8]
   13684:      	cmp	w23, w21
   13688:      	str	x19, [sp, #0x60]
   1368c:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   13690:      	ldr	x21, [sp, #0x78]
   13694:      	ldp	x2, x24, [sp, #0x50]
   13698:      	str	x21, [sp, #0x48]
   1369c:      	b	0x136f0 <generic_fentry_path+0xa430>
   136a0:      	add	x2, x24, #0x10
   136a4:      	mov	w8, #0x4                // =4
   136a8:      	add	x9, sp, #0x98
   136ac:      	add	x0, sp, #0x98
   136b0:      	mov	w1, #0x8                // =8
   136b4:      	blr	x8
   136b8:      	ldr	x8, [sp, #0x58]
   136bc:      	ldr	x9, [sp, #0x98]
   136c0:      	cmp	x8, x9
   136c4:      	ldr	x25, [sp, #0x8]
   136c8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   136cc:      	add	x2, x24, #0x18
   136d0:      	mov	w8, #0x4                // =4
   136d4:      	mov	x0, x22
   136d8:      	mov	w1, #0x8                // =8
   136dc:      	blr	x8
   136e0:      	ldr	x24, [sp, #0x98]
   136e4:      	ldr	x21, [sp, #0x48]
   136e8:      	add	x2, x24, #0x20
   136ec:      	stp	x2, x24, [sp, #0x50]
   136f0:      	ldr	x8, [sp, #0x30]
   136f4:      	ldr	x25, [sp, #0x8]
   136f8:      	add	x9, sp, #0x70
   136fc:      	cmp	x21, x8
   13700:      	b.ne	0x13710 <generic_fentry_path+0xa450>
   13704:      	ldr	x8, [sp, #0x38]
   13708:      	cmp	x2, x8
   1370c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   13710:      	mov	w8, #0x4                // =4
   13714:      	add	x0, sp, #0x70
   13718:      	mov	w1, #0x8                // =8
   1371c:      	blr	x8
   13720:      	ldr	x8, [sp, #0x70]
   13724:      	cmp	x21, x8
   13728:      	b.eq	0x1381c <generic_fentry_path+0xa55c>
   1372c:      	add	x23, x21, #0x18
   13730:      	mov	w8, #0x4                // =4
   13734:      	add	x9, sp, #0x98
   13738:      	add	x0, sp, #0x98
   1373c:      	mov	w1, #0x8                // =8
   13740:      	mov	x2, x23
   13744:      	blr	x8
   13748:      	ldr	x8, [sp, #0x98]
   1374c:      	cmp	x8, x21
   13750:      	b.eq	0x1381c <generic_fentry_path+0xa55c>
   13754:      	mov	w8, #0x4                // =4
   13758:      	add	x9, sp, #0x78
   1375c:      	add	x0, sp, #0x78
   13760:      	mov	w1, #0x8                // =8
   13764:      	mov	x2, x23
   13768:      	blr	x8
   1376c:      	add	x2, x21, #0x20
   13770:      	mov	w8, #0x4                // =4
   13774:      	mov	w9, #0x10               // =16
   13778:      	add	x10, sp, #0x80
   1377c:      	add	x0, sp, #0x80
   13780:      	mov	w1, #0x10               // =16
   13784:      	blr	x8
   13788:      	ldr	w21, [sp, #0x84]
   1378c:      	ldr	x8, [sp, #0x40]
   13790:      	ldr	x10, [sp, #0x60]
   13794:      	sub	x12, x10, x8
   13798:      	ldr	w23, [sp, #0x68]
   1379c:      	subs	w10, w21, w23
   137a0:      	ldr	x9, [sp, #0x88]
   137a4:      	ldr	x25, [sp, #0x8]
   137a8:      	csel	w10, wzr, w10, lo
   137ac:      	cmp	w23, w21
   137b0:      	csel	w11, w23, w21, lo
   137b4:      	cinc	w13, w11, hi
   137b8:      	sub	w14, w23, w13
   137bc:      	subs	x12, x12, x13
   137c0:      	str	w14, [sp, #0x68]
   137c4:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   137c8:      	cmp	x12, #0xfff
   137cc:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   137d0:      	cmp	w23, w21
   137d4:      	b.ls	0x137e0 <generic_fentry_path+0xa520>
   137d8:      	mov	w13, #0x2f              // =47
   137dc:      	strb	w13, [x8, x12]
   137e0:      	add	x19, x8, x12
   137e4:      	cmp	w23, w21
   137e8:      	add	x2, x9, x10
   137ec:      	and	w1, w11, #0xff
   137f0:      	mov	w8, #0x4                // =4
   137f4:      	cinc	x0, x19, hi
   137f8:      	blr	x8
   137fc:      	ldr	x25, [sp, #0x8]
   13800:      	cmp	w23, w21
   13804:      	str	x19, [sp, #0x60]
   13808:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   1380c:      	ldr	x21, [sp, #0x78]
   13810:      	ldp	x2, x24, [sp, #0x50]
   13814:      	str	x21, [sp, #0x48]
   13818:      	b	0x1386c <generic_fentry_path+0xa5ac>
   1381c:      	add	x2, x24, #0x10
   13820:      	mov	w8, #0x4                // =4
   13824:      	add	x9, sp, #0x98
   13828:      	add	x0, sp, #0x98
   1382c:      	mov	w1, #0x8                // =8
   13830:      	blr	x8
   13834:      	ldr	x8, [sp, #0x58]
   13838:      	ldr	x9, [sp, #0x98]
   1383c:      	cmp	x8, x9
   13840:      	ldr	x25, [sp, #0x8]
   13844:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   13848:      	add	x2, x24, #0x18
   1384c:      	mov	w8, #0x4                // =4
   13850:      	mov	x0, x22
   13854:      	mov	w1, #0x8                // =8
   13858:      	blr	x8
   1385c:      	ldr	x24, [sp, #0x98]
   13860:      	ldr	x21, [sp, #0x48]
   13864:      	add	x2, x24, #0x20
   13868:      	stp	x2, x24, [sp, #0x50]
   1386c:      	ldr	x8, [sp, #0x30]
   13870:      	ldr	x25, [sp, #0x8]
   13874:      	add	x9, sp, #0x70
   13878:      	cmp	x21, x8
   1387c:      	b.ne	0x1388c <generic_fentry_path+0xa5cc>
   13880:      	ldr	x8, [sp, #0x38]
   13884:      	cmp	x2, x8
   13888:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   1388c:      	mov	w8, #0x4                // =4
   13890:      	add	x0, sp, #0x70
   13894:      	mov	w1, #0x8                // =8
   13898:      	blr	x8
   1389c:      	ldr	x8, [sp, #0x70]
   138a0:      	cmp	x21, x8
   138a4:      	b.eq	0x13998 <generic_fentry_path+0xa6d8>
   138a8:      	add	x23, x21, #0x18
   138ac:      	mov	w8, #0x4                // =4
   138b0:      	add	x9, sp, #0x98
   138b4:      	add	x0, sp, #0x98
   138b8:      	mov	w1, #0x8                // =8
   138bc:      	mov	x2, x23
   138c0:      	blr	x8
   138c4:      	ldr	x8, [sp, #0x98]
   138c8:      	cmp	x8, x21
   138cc:      	b.eq	0x13998 <generic_fentry_path+0xa6d8>
   138d0:      	mov	w8, #0x4                // =4
   138d4:      	add	x9, sp, #0x78
   138d8:      	add	x0, sp, #0x78
   138dc:      	mov	w1, #0x8                // =8
   138e0:      	mov	x2, x23
   138e4:      	blr	x8
   138e8:      	add	x2, x21, #0x20
   138ec:      	mov	w8, #0x4                // =4
   138f0:      	mov	w9, #0x10               // =16
   138f4:      	add	x10, sp, #0x80
   138f8:      	add	x0, sp, #0x80
   138fc:      	mov	w1, #0x10               // =16
   13900:      	blr	x8
   13904:      	ldr	w21, [sp, #0x84]
   13908:      	ldr	x8, [sp, #0x40]
   1390c:      	ldr	x10, [sp, #0x60]
   13910:      	sub	x12, x10, x8
   13914:      	ldr	w23, [sp, #0x68]
   13918:      	subs	w10, w21, w23
   1391c:      	ldr	x9, [sp, #0x88]
   13920:      	ldr	x25, [sp, #0x8]
   13924:      	csel	w10, wzr, w10, lo
   13928:      	cmp	w23, w21
   1392c:      	csel	w11, w23, w21, lo
   13930:      	cinc	w13, w11, hi
   13934:      	sub	w14, w23, w13
   13938:      	subs	x12, x12, x13
   1393c:      	str	w14, [sp, #0x68]
   13940:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   13944:      	cmp	x12, #0xfff
   13948:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   1394c:      	cmp	w23, w21
   13950:      	b.ls	0x1395c <generic_fentry_path+0xa69c>
   13954:      	mov	w13, #0x2f              // =47
   13958:      	strb	w13, [x8, x12]
   1395c:      	add	x19, x8, x12
   13960:      	cmp	w23, w21
   13964:      	add	x2, x9, x10
   13968:      	and	w1, w11, #0xff
   1396c:      	mov	w8, #0x4                // =4
   13970:      	cinc	x0, x19, hi
   13974:      	blr	x8
   13978:      	ldr	x25, [sp, #0x8]
   1397c:      	cmp	w23, w21
   13980:      	str	x19, [sp, #0x60]
   13984:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   13988:      	ldr	x21, [sp, #0x78]
   1398c:      	ldp	x2, x24, [sp, #0x50]
   13990:      	str	x21, [sp, #0x48]
   13994:      	b	0x139e8 <generic_fentry_path+0xa728>
   13998:      	add	x2, x24, #0x10
   1399c:      	mov	w8, #0x4                // =4
   139a0:      	add	x9, sp, #0x98
   139a4:      	add	x0, sp, #0x98
   139a8:      	mov	w1, #0x8                // =8
   139ac:      	blr	x8
   139b0:      	ldr	x8, [sp, #0x58]
   139b4:      	ldr	x9, [sp, #0x98]
   139b8:      	cmp	x8, x9
   139bc:      	ldr	x25, [sp, #0x8]
   139c0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   139c4:      	add	x2, x24, #0x18
   139c8:      	mov	w8, #0x4                // =4
   139cc:      	mov	x0, x22
   139d0:      	mov	w1, #0x8                // =8
   139d4:      	blr	x8
   139d8:      	ldr	x24, [sp, #0x98]
   139dc:      	ldr	x21, [sp, #0x48]
   139e0:      	add	x2, x24, #0x20
   139e4:      	stp	x2, x24, [sp, #0x50]
   139e8:      	ldr	x8, [sp, #0x30]
   139ec:      	ldr	x25, [sp, #0x8]
   139f0:      	add	x9, sp, #0x70
   139f4:      	cmp	x21, x8
   139f8:      	b.ne	0x13a08 <generic_fentry_path+0xa748>
   139fc:      	ldr	x8, [sp, #0x38]
   13a00:      	cmp	x2, x8
   13a04:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   13a08:      	mov	w8, #0x4                // =4
   13a0c:      	add	x0, sp, #0x70
   13a10:      	mov	w1, #0x8                // =8
   13a14:      	blr	x8
   13a18:      	ldr	x8, [sp, #0x70]
   13a1c:      	cmp	x21, x8
   13a20:      	b.eq	0x13b14 <generic_fentry_path+0xa854>
   13a24:      	add	x23, x21, #0x18
   13a28:      	mov	w8, #0x4                // =4
   13a2c:      	add	x9, sp, #0x98
   13a30:      	add	x0, sp, #0x98
   13a34:      	mov	w1, #0x8                // =8
   13a38:      	mov	x2, x23
   13a3c:      	blr	x8
   13a40:      	ldr	x8, [sp, #0x98]
   13a44:      	cmp	x8, x21
   13a48:      	b.eq	0x13b14 <generic_fentry_path+0xa854>
   13a4c:      	mov	w8, #0x4                // =4
   13a50:      	add	x9, sp, #0x78
   13a54:      	add	x0, sp, #0x78
   13a58:      	mov	w1, #0x8                // =8
   13a5c:      	mov	x2, x23
   13a60:      	blr	x8
   13a64:      	add	x2, x21, #0x20
   13a68:      	mov	w8, #0x4                // =4
   13a6c:      	mov	w9, #0x10               // =16
   13a70:      	add	x10, sp, #0x80
   13a74:      	add	x0, sp, #0x80
   13a78:      	mov	w1, #0x10               // =16
   13a7c:      	blr	x8
   13a80:      	ldr	w21, [sp, #0x84]
   13a84:      	ldr	x8, [sp, #0x40]
   13a88:      	ldr	x10, [sp, #0x60]
   13a8c:      	sub	x12, x10, x8
   13a90:      	ldr	w23, [sp, #0x68]
   13a94:      	subs	w10, w21, w23
   13a98:      	ldr	x9, [sp, #0x88]
   13a9c:      	ldr	x25, [sp, #0x8]
   13aa0:      	csel	w10, wzr, w10, lo
   13aa4:      	cmp	w23, w21
   13aa8:      	csel	w11, w23, w21, lo
   13aac:      	cinc	w13, w11, hi
   13ab0:      	sub	w14, w23, w13
   13ab4:      	subs	x12, x12, x13
   13ab8:      	str	w14, [sp, #0x68]
   13abc:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   13ac0:      	cmp	x12, #0xfff
   13ac4:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   13ac8:      	cmp	w23, w21
   13acc:      	b.ls	0x13ad8 <generic_fentry_path+0xa818>
   13ad0:      	mov	w13, #0x2f              // =47
   13ad4:      	strb	w13, [x8, x12]
   13ad8:      	add	x19, x8, x12
   13adc:      	cmp	w23, w21
   13ae0:      	add	x2, x9, x10
   13ae4:      	and	w1, w11, #0xff
   13ae8:      	mov	w8, #0x4                // =4
   13aec:      	cinc	x0, x19, hi
   13af0:      	blr	x8
   13af4:      	ldr	x25, [sp, #0x8]
   13af8:      	cmp	w23, w21
   13afc:      	str	x19, [sp, #0x60]
   13b00:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   13b04:      	ldr	x21, [sp, #0x78]
   13b08:      	ldp	x2, x24, [sp, #0x50]
   13b0c:      	str	x21, [sp, #0x48]
   13b10:      	b	0x13b64 <generic_fentry_path+0xa8a4>
   13b14:      	add	x2, x24, #0x10
   13b18:      	mov	w8, #0x4                // =4
   13b1c:      	add	x9, sp, #0x98
   13b20:      	add	x0, sp, #0x98
   13b24:      	mov	w1, #0x8                // =8
   13b28:      	blr	x8
   13b2c:      	ldr	x8, [sp, #0x58]
   13b30:      	ldr	x9, [sp, #0x98]
   13b34:      	cmp	x8, x9
   13b38:      	ldr	x25, [sp, #0x8]
   13b3c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   13b40:      	add	x2, x24, #0x18
   13b44:      	mov	w8, #0x4                // =4
   13b48:      	mov	x0, x22
   13b4c:      	mov	w1, #0x8                // =8
   13b50:      	blr	x8
   13b54:      	ldr	x24, [sp, #0x98]
   13b58:      	ldr	x21, [sp, #0x48]
   13b5c:      	add	x2, x24, #0x20
   13b60:      	stp	x2, x24, [sp, #0x50]
   13b64:      	ldr	x8, [sp, #0x30]
   13b68:      	ldr	x25, [sp, #0x8]
   13b6c:      	add	x9, sp, #0x70
   13b70:      	cmp	x21, x8
   13b74:      	b.ne	0x13b84 <generic_fentry_path+0xa8c4>
   13b78:      	ldr	x8, [sp, #0x38]
   13b7c:      	cmp	x2, x8
   13b80:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   13b84:      	mov	w8, #0x4                // =4
   13b88:      	add	x0, sp, #0x70
   13b8c:      	mov	w1, #0x8                // =8
   13b90:      	blr	x8
   13b94:      	ldr	x8, [sp, #0x70]
   13b98:      	cmp	x21, x8
   13b9c:      	b.eq	0x13c90 <generic_fentry_path+0xa9d0>
   13ba0:      	add	x23, x21, #0x18
   13ba4:      	mov	w8, #0x4                // =4
   13ba8:      	add	x9, sp, #0x98
   13bac:      	add	x0, sp, #0x98
   13bb0:      	mov	w1, #0x8                // =8
   13bb4:      	mov	x2, x23
   13bb8:      	blr	x8
   13bbc:      	ldr	x8, [sp, #0x98]
   13bc0:      	cmp	x8, x21
   13bc4:      	b.eq	0x13c90 <generic_fentry_path+0xa9d0>
   13bc8:      	mov	w8, #0x4                // =4
   13bcc:      	add	x9, sp, #0x78
   13bd0:      	add	x0, sp, #0x78
   13bd4:      	mov	w1, #0x8                // =8
   13bd8:      	mov	x2, x23
   13bdc:      	blr	x8
   13be0:      	add	x2, x21, #0x20
   13be4:      	mov	w8, #0x4                // =4
   13be8:      	mov	w9, #0x10               // =16
   13bec:      	add	x10, sp, #0x80
   13bf0:      	add	x0, sp, #0x80
   13bf4:      	mov	w1, #0x10               // =16
   13bf8:      	blr	x8
   13bfc:      	ldr	w21, [sp, #0x84]
   13c00:      	ldr	x8, [sp, #0x40]
   13c04:      	ldr	x10, [sp, #0x60]
   13c08:      	sub	x12, x10, x8
   13c0c:      	ldr	w23, [sp, #0x68]
   13c10:      	subs	w10, w21, w23
   13c14:      	ldr	x9, [sp, #0x88]
   13c18:      	ldr	x25, [sp, #0x8]
   13c1c:      	csel	w10, wzr, w10, lo
   13c20:      	cmp	w23, w21
   13c24:      	csel	w11, w23, w21, lo
   13c28:      	cinc	w13, w11, hi
   13c2c:      	sub	w14, w23, w13
   13c30:      	subs	x12, x12, x13
   13c34:      	str	w14, [sp, #0x68]
   13c38:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   13c3c:      	cmp	x12, #0xfff
   13c40:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   13c44:      	cmp	w23, w21
   13c48:      	b.ls	0x13c54 <generic_fentry_path+0xa994>
   13c4c:      	mov	w13, #0x2f              // =47
   13c50:      	strb	w13, [x8, x12]
   13c54:      	add	x19, x8, x12
   13c58:      	cmp	w23, w21
   13c5c:      	add	x2, x9, x10
   13c60:      	and	w1, w11, #0xff
   13c64:      	mov	w8, #0x4                // =4
   13c68:      	cinc	x0, x19, hi
   13c6c:      	blr	x8
   13c70:      	ldr	x25, [sp, #0x8]
   13c74:      	cmp	w23, w21
   13c78:      	str	x19, [sp, #0x60]
   13c7c:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   13c80:      	ldr	x21, [sp, #0x78]
   13c84:      	ldp	x2, x24, [sp, #0x50]
   13c88:      	str	x21, [sp, #0x48]
   13c8c:      	b	0x13ce0 <generic_fentry_path+0xaa20>
   13c90:      	add	x2, x24, #0x10
   13c94:      	mov	w8, #0x4                // =4
   13c98:      	add	x9, sp, #0x98
   13c9c:      	add	x0, sp, #0x98
   13ca0:      	mov	w1, #0x8                // =8
   13ca4:      	blr	x8
   13ca8:      	ldr	x8, [sp, #0x58]
   13cac:      	ldr	x9, [sp, #0x98]
   13cb0:      	cmp	x8, x9
   13cb4:      	ldr	x25, [sp, #0x8]
   13cb8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   13cbc:      	add	x2, x24, #0x18
   13cc0:      	mov	w8, #0x4                // =4
   13cc4:      	mov	x0, x22
   13cc8:      	mov	w1, #0x8                // =8
   13ccc:      	blr	x8
   13cd0:      	ldr	x24, [sp, #0x98]
   13cd4:      	ldr	x21, [sp, #0x48]
   13cd8:      	add	x2, x24, #0x20
   13cdc:      	stp	x2, x24, [sp, #0x50]
   13ce0:      	ldr	x8, [sp, #0x30]
   13ce4:      	ldr	x25, [sp, #0x8]
   13ce8:      	add	x9, sp, #0x70
   13cec:      	cmp	x21, x8
   13cf0:      	b.ne	0x13d00 <generic_fentry_path+0xaa40>
   13cf4:      	ldr	x8, [sp, #0x38]
   13cf8:      	cmp	x2, x8
   13cfc:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   13d00:      	mov	w8, #0x4                // =4
   13d04:      	add	x0, sp, #0x70
   13d08:      	mov	w1, #0x8                // =8
   13d0c:      	blr	x8
   13d10:      	ldr	x8, [sp, #0x70]
   13d14:      	cmp	x21, x8
   13d18:      	b.eq	0x13e0c <generic_fentry_path+0xab4c>
   13d1c:      	add	x23, x21, #0x18
   13d20:      	mov	w8, #0x4                // =4
   13d24:      	add	x9, sp, #0x98
   13d28:      	add	x0, sp, #0x98
   13d2c:      	mov	w1, #0x8                // =8
   13d30:      	mov	x2, x23
   13d34:      	blr	x8
   13d38:      	ldr	x8, [sp, #0x98]
   13d3c:      	cmp	x8, x21
   13d40:      	b.eq	0x13e0c <generic_fentry_path+0xab4c>
   13d44:      	mov	w8, #0x4                // =4
   13d48:      	add	x9, sp, #0x78
   13d4c:      	add	x0, sp, #0x78
   13d50:      	mov	w1, #0x8                // =8
   13d54:      	mov	x2, x23
   13d58:      	blr	x8
   13d5c:      	add	x2, x21, #0x20
   13d60:      	mov	w8, #0x4                // =4
   13d64:      	mov	w9, #0x10               // =16
   13d68:      	add	x10, sp, #0x80
   13d6c:      	add	x0, sp, #0x80
   13d70:      	mov	w1, #0x10               // =16
   13d74:      	blr	x8
   13d78:      	ldr	w21, [sp, #0x84]
   13d7c:      	ldr	x8, [sp, #0x40]
   13d80:      	ldr	x10, [sp, #0x60]
   13d84:      	sub	x12, x10, x8
   13d88:      	ldr	w23, [sp, #0x68]
   13d8c:      	subs	w10, w21, w23
   13d90:      	ldr	x9, [sp, #0x88]
   13d94:      	ldr	x25, [sp, #0x8]
   13d98:      	csel	w10, wzr, w10, lo
   13d9c:      	cmp	w23, w21
   13da0:      	csel	w11, w23, w21, lo
   13da4:      	cinc	w13, w11, hi
   13da8:      	sub	w14, w23, w13
   13dac:      	subs	x12, x12, x13
   13db0:      	str	w14, [sp, #0x68]
   13db4:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   13db8:      	cmp	x12, #0xfff
   13dbc:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   13dc0:      	cmp	w23, w21
   13dc4:      	b.ls	0x13dd0 <generic_fentry_path+0xab10>
   13dc8:      	mov	w13, #0x2f              // =47
   13dcc:      	strb	w13, [x8, x12]
   13dd0:      	add	x19, x8, x12
   13dd4:      	cmp	w23, w21
   13dd8:      	add	x2, x9, x10
   13ddc:      	and	w1, w11, #0xff
   13de0:      	mov	w8, #0x4                // =4
   13de4:      	cinc	x0, x19, hi
   13de8:      	blr	x8
   13dec:      	ldr	x25, [sp, #0x8]
   13df0:      	cmp	w23, w21
   13df4:      	str	x19, [sp, #0x60]
   13df8:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   13dfc:      	ldr	x21, [sp, #0x78]
   13e00:      	ldp	x2, x24, [sp, #0x50]
   13e04:      	str	x21, [sp, #0x48]
   13e08:      	b	0x13e5c <generic_fentry_path+0xab9c>
   13e0c:      	add	x2, x24, #0x10
   13e10:      	mov	w8, #0x4                // =4
   13e14:      	add	x9, sp, #0x98
   13e18:      	add	x0, sp, #0x98
   13e1c:      	mov	w1, #0x8                // =8
   13e20:      	blr	x8
   13e24:      	ldr	x8, [sp, #0x58]
   13e28:      	ldr	x9, [sp, #0x98]
   13e2c:      	cmp	x8, x9
   13e30:      	ldr	x25, [sp, #0x8]
   13e34:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   13e38:      	add	x2, x24, #0x18
   13e3c:      	mov	w8, #0x4                // =4
   13e40:      	mov	x0, x22
   13e44:      	mov	w1, #0x8                // =8
   13e48:      	blr	x8
   13e4c:      	ldr	x24, [sp, #0x98]
   13e50:      	ldr	x21, [sp, #0x48]
   13e54:      	add	x2, x24, #0x20
   13e58:      	stp	x2, x24, [sp, #0x50]
   13e5c:      	ldr	x8, [sp, #0x30]
   13e60:      	ldr	x25, [sp, #0x8]
   13e64:      	add	x9, sp, #0x70
   13e68:      	cmp	x21, x8
   13e6c:      	b.ne	0x13e7c <generic_fentry_path+0xabbc>
   13e70:      	ldr	x8, [sp, #0x38]
   13e74:      	cmp	x2, x8
   13e78:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   13e7c:      	mov	w8, #0x4                // =4
   13e80:      	add	x0, sp, #0x70
   13e84:      	mov	w1, #0x8                // =8
   13e88:      	blr	x8
   13e8c:      	ldr	x8, [sp, #0x70]
   13e90:      	cmp	x21, x8
   13e94:      	b.eq	0x13f88 <generic_fentry_path+0xacc8>
   13e98:      	add	x23, x21, #0x18
   13e9c:      	mov	w8, #0x4                // =4
   13ea0:      	add	x9, sp, #0x98
   13ea4:      	add	x0, sp, #0x98
   13ea8:      	mov	w1, #0x8                // =8
   13eac:      	mov	x2, x23
   13eb0:      	blr	x8
   13eb4:      	ldr	x8, [sp, #0x98]
   13eb8:      	cmp	x8, x21
   13ebc:      	b.eq	0x13f88 <generic_fentry_path+0xacc8>
   13ec0:      	mov	w8, #0x4                // =4
   13ec4:      	add	x9, sp, #0x78
   13ec8:      	add	x0, sp, #0x78
   13ecc:      	mov	w1, #0x8                // =8
   13ed0:      	mov	x2, x23
   13ed4:      	blr	x8
   13ed8:      	add	x2, x21, #0x20
   13edc:      	mov	w8, #0x4                // =4
   13ee0:      	mov	w9, #0x10               // =16
   13ee4:      	add	x10, sp, #0x80
   13ee8:      	add	x0, sp, #0x80
   13eec:      	mov	w1, #0x10               // =16
   13ef0:      	blr	x8
   13ef4:      	ldr	w21, [sp, #0x84]
   13ef8:      	ldr	x8, [sp, #0x40]
   13efc:      	ldr	x10, [sp, #0x60]
   13f00:      	sub	x12, x10, x8
   13f04:      	ldr	w23, [sp, #0x68]
   13f08:      	subs	w10, w21, w23
   13f0c:      	ldr	x9, [sp, #0x88]
   13f10:      	ldr	x25, [sp, #0x8]
   13f14:      	csel	w10, wzr, w10, lo
   13f18:      	cmp	w23, w21
   13f1c:      	csel	w11, w23, w21, lo
   13f20:      	cinc	w13, w11, hi
   13f24:      	sub	w14, w23, w13
   13f28:      	subs	x12, x12, x13
   13f2c:      	str	w14, [sp, #0x68]
   13f30:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   13f34:      	cmp	x12, #0xfff
   13f38:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   13f3c:      	cmp	w23, w21
   13f40:      	b.ls	0x13f4c <generic_fentry_path+0xac8c>
   13f44:      	mov	w13, #0x2f              // =47
   13f48:      	strb	w13, [x8, x12]
   13f4c:      	add	x19, x8, x12
   13f50:      	cmp	w23, w21
   13f54:      	add	x2, x9, x10
   13f58:      	and	w1, w11, #0xff
   13f5c:      	mov	w8, #0x4                // =4
   13f60:      	cinc	x0, x19, hi
   13f64:      	blr	x8
   13f68:      	ldr	x25, [sp, #0x8]
   13f6c:      	cmp	w23, w21
   13f70:      	str	x19, [sp, #0x60]
   13f74:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   13f78:      	ldr	x21, [sp, #0x78]
   13f7c:      	ldp	x2, x24, [sp, #0x50]
   13f80:      	str	x21, [sp, #0x48]
   13f84:      	b	0x13fd8 <generic_fentry_path+0xad18>
   13f88:      	add	x2, x24, #0x10
   13f8c:      	mov	w8, #0x4                // =4
   13f90:      	add	x9, sp, #0x98
   13f94:      	add	x0, sp, #0x98
   13f98:      	mov	w1, #0x8                // =8
   13f9c:      	blr	x8
   13fa0:      	ldr	x8, [sp, #0x58]
   13fa4:      	ldr	x9, [sp, #0x98]
   13fa8:      	cmp	x8, x9
   13fac:      	ldr	x25, [sp, #0x8]
   13fb0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   13fb4:      	add	x2, x24, #0x18
   13fb8:      	mov	w8, #0x4                // =4
   13fbc:      	mov	x0, x22
   13fc0:      	mov	w1, #0x8                // =8
   13fc4:      	blr	x8
   13fc8:      	ldr	x24, [sp, #0x98]
   13fcc:      	ldr	x21, [sp, #0x48]
   13fd0:      	add	x2, x24, #0x20
   13fd4:      	stp	x2, x24, [sp, #0x50]
   13fd8:      	ldr	x8, [sp, #0x30]
   13fdc:      	ldr	x25, [sp, #0x8]
   13fe0:      	add	x9, sp, #0x70
   13fe4:      	cmp	x21, x8
   13fe8:      	b.ne	0x13ff8 <generic_fentry_path+0xad38>
   13fec:      	ldr	x8, [sp, #0x38]
   13ff0:      	cmp	x2, x8
   13ff4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   13ff8:      	mov	w8, #0x4                // =4
   13ffc:      	add	x0, sp, #0x70
   14000:      	mov	w1, #0x8                // =8
   14004:      	blr	x8
   14008:      	ldr	x8, [sp, #0x70]
   1400c:      	cmp	x21, x8
   14010:      	b.eq	0x14104 <generic_fentry_path+0xae44>
   14014:      	add	x23, x21, #0x18
   14018:      	mov	w8, #0x4                // =4
   1401c:      	add	x9, sp, #0x98
   14020:      	add	x0, sp, #0x98
   14024:      	mov	w1, #0x8                // =8
   14028:      	mov	x2, x23
   1402c:      	blr	x8
   14030:      	ldr	x8, [sp, #0x98]
   14034:      	cmp	x8, x21
   14038:      	b.eq	0x14104 <generic_fentry_path+0xae44>
   1403c:      	mov	w8, #0x4                // =4
   14040:      	add	x9, sp, #0x78
   14044:      	add	x0, sp, #0x78
   14048:      	mov	w1, #0x8                // =8
   1404c:      	mov	x2, x23
   14050:      	blr	x8
   14054:      	add	x2, x21, #0x20
   14058:      	mov	w8, #0x4                // =4
   1405c:      	mov	w9, #0x10               // =16
   14060:      	add	x10, sp, #0x80
   14064:      	add	x0, sp, #0x80
   14068:      	mov	w1, #0x10               // =16
   1406c:      	blr	x8
   14070:      	ldr	w21, [sp, #0x84]
   14074:      	ldr	x8, [sp, #0x40]
   14078:      	ldr	x10, [sp, #0x60]
   1407c:      	sub	x12, x10, x8
   14080:      	ldr	w23, [sp, #0x68]
   14084:      	subs	w10, w21, w23
   14088:      	ldr	x9, [sp, #0x88]
   1408c:      	ldr	x25, [sp, #0x8]
   14090:      	csel	w10, wzr, w10, lo
   14094:      	cmp	w23, w21
   14098:      	csel	w11, w23, w21, lo
   1409c:      	cinc	w13, w11, hi
   140a0:      	sub	w14, w23, w13
   140a4:      	subs	x12, x12, x13
   140a8:      	str	w14, [sp, #0x68]
   140ac:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   140b0:      	cmp	x12, #0xfff
   140b4:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   140b8:      	cmp	w23, w21
   140bc:      	b.ls	0x140c8 <generic_fentry_path+0xae08>
   140c0:      	mov	w13, #0x2f              // =47
   140c4:      	strb	w13, [x8, x12]
   140c8:      	add	x19, x8, x12
   140cc:      	cmp	w23, w21
   140d0:      	add	x2, x9, x10
   140d4:      	and	w1, w11, #0xff
   140d8:      	mov	w8, #0x4                // =4
   140dc:      	cinc	x0, x19, hi
   140e0:      	blr	x8
   140e4:      	ldr	x25, [sp, #0x8]
   140e8:      	cmp	w23, w21
   140ec:      	str	x19, [sp, #0x60]
   140f0:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   140f4:      	ldr	x21, [sp, #0x78]
   140f8:      	ldp	x2, x24, [sp, #0x50]
   140fc:      	str	x21, [sp, #0x48]
   14100:      	b	0x14154 <generic_fentry_path+0xae94>
   14104:      	add	x2, x24, #0x10
   14108:      	mov	w8, #0x4                // =4
   1410c:      	add	x9, sp, #0x98
   14110:      	add	x0, sp, #0x98
   14114:      	mov	w1, #0x8                // =8
   14118:      	blr	x8
   1411c:      	ldr	x8, [sp, #0x58]
   14120:      	ldr	x9, [sp, #0x98]
   14124:      	cmp	x8, x9
   14128:      	ldr	x25, [sp, #0x8]
   1412c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   14130:      	add	x2, x24, #0x18
   14134:      	mov	w8, #0x4                // =4
   14138:      	mov	x0, x22
   1413c:      	mov	w1, #0x8                // =8
   14140:      	blr	x8
   14144:      	ldr	x24, [sp, #0x98]
   14148:      	ldr	x21, [sp, #0x48]
   1414c:      	add	x2, x24, #0x20
   14150:      	stp	x2, x24, [sp, #0x50]
   14154:      	ldr	x8, [sp, #0x30]
   14158:      	ldr	x25, [sp, #0x8]
   1415c:      	add	x9, sp, #0x70
   14160:      	cmp	x21, x8
   14164:      	b.ne	0x14174 <generic_fentry_path+0xaeb4>
   14168:      	ldr	x8, [sp, #0x38]
   1416c:      	cmp	x2, x8
   14170:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   14174:      	mov	w8, #0x4                // =4
   14178:      	add	x0, sp, #0x70
   1417c:      	mov	w1, #0x8                // =8
   14180:      	blr	x8
   14184:      	ldr	x8, [sp, #0x70]
   14188:      	cmp	x21, x8
   1418c:      	b.eq	0x14280 <generic_fentry_path+0xafc0>
   14190:      	add	x23, x21, #0x18
   14194:      	mov	w8, #0x4                // =4
   14198:      	add	x9, sp, #0x98
   1419c:      	add	x0, sp, #0x98
   141a0:      	mov	w1, #0x8                // =8
   141a4:      	mov	x2, x23
   141a8:      	blr	x8
   141ac:      	ldr	x8, [sp, #0x98]
   141b0:      	cmp	x8, x21
   141b4:      	b.eq	0x14280 <generic_fentry_path+0xafc0>
   141b8:      	mov	w8, #0x4                // =4
   141bc:      	add	x9, sp, #0x78
   141c0:      	add	x0, sp, #0x78
   141c4:      	mov	w1, #0x8                // =8
   141c8:      	mov	x2, x23
   141cc:      	blr	x8
   141d0:      	add	x2, x21, #0x20
   141d4:      	mov	w8, #0x4                // =4
   141d8:      	mov	w9, #0x10               // =16
   141dc:      	add	x10, sp, #0x80
   141e0:      	add	x0, sp, #0x80
   141e4:      	mov	w1, #0x10               // =16
   141e8:      	blr	x8
   141ec:      	ldr	w21, [sp, #0x84]
   141f0:      	ldr	x8, [sp, #0x40]
   141f4:      	ldr	x10, [sp, #0x60]
   141f8:      	sub	x12, x10, x8
   141fc:      	ldr	w23, [sp, #0x68]
   14200:      	subs	w10, w21, w23
   14204:      	ldr	x9, [sp, #0x88]
   14208:      	ldr	x25, [sp, #0x8]
   1420c:      	csel	w10, wzr, w10, lo
   14210:      	cmp	w23, w21
   14214:      	csel	w11, w23, w21, lo
   14218:      	cinc	w13, w11, hi
   1421c:      	sub	w14, w23, w13
   14220:      	subs	x12, x12, x13
   14224:      	str	w14, [sp, #0x68]
   14228:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   1422c:      	cmp	x12, #0xfff
   14230:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   14234:      	cmp	w23, w21
   14238:      	b.ls	0x14244 <generic_fentry_path+0xaf84>
   1423c:      	mov	w13, #0x2f              // =47
   14240:      	strb	w13, [x8, x12]
   14244:      	add	x19, x8, x12
   14248:      	cmp	w23, w21
   1424c:      	add	x2, x9, x10
   14250:      	and	w1, w11, #0xff
   14254:      	mov	w8, #0x4                // =4
   14258:      	cinc	x0, x19, hi
   1425c:      	blr	x8
   14260:      	ldr	x25, [sp, #0x8]
   14264:      	cmp	w23, w21
   14268:      	str	x19, [sp, #0x60]
   1426c:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   14270:      	ldr	x21, [sp, #0x78]
   14274:      	ldp	x2, x24, [sp, #0x50]
   14278:      	str	x21, [sp, #0x48]
   1427c:      	b	0x142d0 <generic_fentry_path+0xb010>
   14280:      	add	x2, x24, #0x10
   14284:      	mov	w8, #0x4                // =4
   14288:      	add	x9, sp, #0x98
   1428c:      	add	x0, sp, #0x98
   14290:      	mov	w1, #0x8                // =8
   14294:      	blr	x8
   14298:      	ldr	x8, [sp, #0x58]
   1429c:      	ldr	x9, [sp, #0x98]
   142a0:      	cmp	x8, x9
   142a4:      	ldr	x25, [sp, #0x8]
   142a8:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   142ac:      	add	x2, x24, #0x18
   142b0:      	mov	w8, #0x4                // =4
   142b4:      	mov	x0, x22
   142b8:      	mov	w1, #0x8                // =8
   142bc:      	blr	x8
   142c0:      	ldr	x24, [sp, #0x98]
   142c4:      	ldr	x21, [sp, #0x48]
   142c8:      	add	x2, x24, #0x20
   142cc:      	stp	x2, x24, [sp, #0x50]
   142d0:      	ldr	x8, [sp, #0x30]
   142d4:      	ldr	x25, [sp, #0x8]
   142d8:      	add	x9, sp, #0x70
   142dc:      	cmp	x21, x8
   142e0:      	b.ne	0x142f0 <generic_fentry_path+0xb030>
   142e4:      	ldr	x8, [sp, #0x38]
   142e8:      	cmp	x2, x8
   142ec:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   142f0:      	mov	w8, #0x4                // =4
   142f4:      	add	x0, sp, #0x70
   142f8:      	mov	w1, #0x8                // =8
   142fc:      	blr	x8
   14300:      	ldr	x8, [sp, #0x70]
   14304:      	cmp	x21, x8
   14308:      	b.eq	0x143fc <generic_fentry_path+0xb13c>
   1430c:      	add	x23, x21, #0x18
   14310:      	mov	w8, #0x4                // =4
   14314:      	add	x9, sp, #0x98
   14318:      	add	x0, sp, #0x98
   1431c:      	mov	w1, #0x8                // =8
   14320:      	mov	x2, x23
   14324:      	blr	x8
   14328:      	ldr	x8, [sp, #0x98]
   1432c:      	cmp	x8, x21
   14330:      	b.eq	0x143fc <generic_fentry_path+0xb13c>
   14334:      	mov	w8, #0x4                // =4
   14338:      	add	x9, sp, #0x78
   1433c:      	add	x0, sp, #0x78
   14340:      	mov	w1, #0x8                // =8
   14344:      	mov	x2, x23
   14348:      	blr	x8
   1434c:      	add	x2, x21, #0x20
   14350:      	mov	w8, #0x4                // =4
   14354:      	mov	w9, #0x10               // =16
   14358:      	add	x10, sp, #0x80
   1435c:      	add	x0, sp, #0x80
   14360:      	mov	w1, #0x10               // =16
   14364:      	blr	x8
   14368:      	ldr	w21, [sp, #0x84]
   1436c:      	ldr	x8, [sp, #0x40]
   14370:      	ldr	x10, [sp, #0x60]
   14374:      	sub	x12, x10, x8
   14378:      	ldr	w23, [sp, #0x68]
   1437c:      	subs	w10, w21, w23
   14380:      	ldr	x9, [sp, #0x88]
   14384:      	ldr	x25, [sp, #0x8]
   14388:      	csel	w10, wzr, w10, lo
   1438c:      	cmp	w23, w21
   14390:      	csel	w11, w23, w21, lo
   14394:      	cinc	w13, w11, hi
   14398:      	sub	w14, w23, w13
   1439c:      	subs	x12, x12, x13
   143a0:      	str	w14, [sp, #0x68]
   143a4:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   143a8:      	cmp	x12, #0xfff
   143ac:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   143b0:      	cmp	w23, w21
   143b4:      	b.ls	0x143c0 <generic_fentry_path+0xb100>
   143b8:      	mov	w13, #0x2f              // =47
   143bc:      	strb	w13, [x8, x12]
   143c0:      	add	x19, x8, x12
   143c4:      	cmp	w23, w21
   143c8:      	add	x2, x9, x10
   143cc:      	and	w1, w11, #0xff
   143d0:      	mov	w8, #0x4                // =4
   143d4:      	cinc	x0, x19, hi
   143d8:      	blr	x8
   143dc:      	ldr	x25, [sp, #0x8]
   143e0:      	cmp	w23, w21
   143e4:      	str	x19, [sp, #0x60]
   143e8:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   143ec:      	ldr	x21, [sp, #0x78]
   143f0:      	ldp	x2, x24, [sp, #0x50]
   143f4:      	str	x21, [sp, #0x48]
   143f8:      	b	0x1444c <generic_fentry_path+0xb18c>
   143fc:      	add	x2, x24, #0x10
   14400:      	mov	w8, #0x4                // =4
   14404:      	add	x9, sp, #0x98
   14408:      	add	x0, sp, #0x98
   1440c:      	mov	w1, #0x8                // =8
   14410:      	blr	x8
   14414:      	ldr	x8, [sp, #0x58]
   14418:      	ldr	x9, [sp, #0x98]
   1441c:      	cmp	x8, x9
   14420:      	ldr	x25, [sp, #0x8]
   14424:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   14428:      	add	x2, x24, #0x18
   1442c:      	mov	w8, #0x4                // =4
   14430:      	mov	x0, x22
   14434:      	mov	w1, #0x8                // =8
   14438:      	blr	x8
   1443c:      	ldr	x24, [sp, #0x98]
   14440:      	ldr	x21, [sp, #0x48]
   14444:      	add	x2, x24, #0x20
   14448:      	stp	x2, x24, [sp, #0x50]
   1444c:      	ldr	x8, [sp, #0x30]
   14450:      	ldr	x25, [sp, #0x8]
   14454:      	add	x9, sp, #0x70
   14458:      	cmp	x21, x8
   1445c:      	b.ne	0x1446c <generic_fentry_path+0xb1ac>
   14460:      	ldr	x8, [sp, #0x38]
   14464:      	cmp	x2, x8
   14468:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   1446c:      	mov	w8, #0x4                // =4
   14470:      	add	x0, sp, #0x70
   14474:      	mov	w1, #0x8                // =8
   14478:      	blr	x8
   1447c:      	ldr	x8, [sp, #0x70]
   14480:      	cmp	x21, x8
   14484:      	b.eq	0x14578 <generic_fentry_path+0xb2b8>
   14488:      	add	x23, x21, #0x18
   1448c:      	mov	w8, #0x4                // =4
   14490:      	add	x9, sp, #0x98
   14494:      	add	x0, sp, #0x98
   14498:      	mov	w1, #0x8                // =8
   1449c:      	mov	x2, x23
   144a0:      	blr	x8
   144a4:      	ldr	x8, [sp, #0x98]
   144a8:      	cmp	x8, x21
   144ac:      	b.eq	0x14578 <generic_fentry_path+0xb2b8>
   144b0:      	mov	w8, #0x4                // =4
   144b4:      	add	x9, sp, #0x78
   144b8:      	add	x0, sp, #0x78
   144bc:      	mov	w1, #0x8                // =8
   144c0:      	mov	x2, x23
   144c4:      	blr	x8
   144c8:      	add	x2, x21, #0x20
   144cc:      	mov	w8, #0x4                // =4
   144d0:      	mov	w9, #0x10               // =16
   144d4:      	add	x10, sp, #0x80
   144d8:      	add	x0, sp, #0x80
   144dc:      	mov	w1, #0x10               // =16
   144e0:      	blr	x8
   144e4:      	ldr	w21, [sp, #0x84]
   144e8:      	ldr	x8, [sp, #0x40]
   144ec:      	ldr	x10, [sp, #0x60]
   144f0:      	sub	x12, x10, x8
   144f4:      	ldr	w23, [sp, #0x68]
   144f8:      	subs	w10, w21, w23
   144fc:      	ldr	x9, [sp, #0x88]
   14500:      	ldr	x25, [sp, #0x8]
   14504:      	csel	w10, wzr, w10, lo
   14508:      	cmp	w23, w21
   1450c:      	csel	w11, w23, w21, lo
   14510:      	cinc	w13, w11, hi
   14514:      	sub	w14, w23, w13
   14518:      	subs	x12, x12, x13
   1451c:      	str	w14, [sp, #0x68]
   14520:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   14524:      	cmp	x12, #0xfff
   14528:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   1452c:      	cmp	w23, w21
   14530:      	b.ls	0x1453c <generic_fentry_path+0xb27c>
   14534:      	mov	w13, #0x2f              // =47
   14538:      	strb	w13, [x8, x12]
   1453c:      	add	x19, x8, x12
   14540:      	cmp	w23, w21
   14544:      	add	x2, x9, x10
   14548:      	and	w1, w11, #0xff
   1454c:      	mov	w8, #0x4                // =4
   14550:      	cinc	x0, x19, hi
   14554:      	blr	x8
   14558:      	ldr	x25, [sp, #0x8]
   1455c:      	cmp	w23, w21
   14560:      	str	x19, [sp, #0x60]
   14564:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   14568:      	ldr	x21, [sp, #0x78]
   1456c:      	ldp	x2, x24, [sp, #0x50]
   14570:      	str	x21, [sp, #0x48]
   14574:      	b	0x145c8 <generic_fentry_path+0xb308>
   14578:      	add	x2, x24, #0x10
   1457c:      	mov	w8, #0x4                // =4
   14580:      	add	x9, sp, #0x98
   14584:      	add	x0, sp, #0x98
   14588:      	mov	w1, #0x8                // =8
   1458c:      	blr	x8
   14590:      	ldr	x8, [sp, #0x58]
   14594:      	ldr	x9, [sp, #0x98]
   14598:      	cmp	x8, x9
   1459c:      	ldr	x25, [sp, #0x8]
   145a0:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   145a4:      	add	x2, x24, #0x18
   145a8:      	mov	w8, #0x4                // =4
   145ac:      	mov	x0, x22
   145b0:      	mov	w1, #0x8                // =8
   145b4:      	blr	x8
   145b8:      	ldr	x24, [sp, #0x98]
   145bc:      	ldr	x21, [sp, #0x48]
   145c0:      	add	x2, x24, #0x20
   145c4:      	stp	x2, x24, [sp, #0x50]
   145c8:      	ldr	x8, [sp, #0x30]
   145cc:      	ldr	x25, [sp, #0x8]
   145d0:      	add	x9, sp, #0x70
   145d4:      	cmp	x21, x8
   145d8:      	b.ne	0x145e8 <generic_fentry_path+0xb328>
   145dc:      	ldr	x8, [sp, #0x38]
   145e0:      	cmp	x2, x8
   145e4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   145e8:      	mov	w8, #0x4                // =4
   145ec:      	add	x0, sp, #0x70
   145f0:      	mov	w1, #0x8                // =8
   145f4:      	blr	x8
   145f8:      	ldr	x8, [sp, #0x70]
   145fc:      	cmp	x21, x8
   14600:      	b.eq	0x146f4 <generic_fentry_path+0xb434>
   14604:      	add	x23, x21, #0x18
   14608:      	mov	w8, #0x4                // =4
   1460c:      	add	x9, sp, #0x98
   14610:      	add	x0, sp, #0x98
   14614:      	mov	w1, #0x8                // =8
   14618:      	mov	x2, x23
   1461c:      	blr	x8
   14620:      	ldr	x8, [sp, #0x98]
   14624:      	cmp	x8, x21
   14628:      	b.eq	0x146f4 <generic_fentry_path+0xb434>
   1462c:      	mov	w8, #0x4                // =4
   14630:      	add	x9, sp, #0x78
   14634:      	add	x0, sp, #0x78
   14638:      	mov	w1, #0x8                // =8
   1463c:      	mov	x2, x23
   14640:      	blr	x8
   14644:      	add	x2, x21, #0x20
   14648:      	mov	w8, #0x4                // =4
   1464c:      	mov	w9, #0x10               // =16
   14650:      	add	x10, sp, #0x80
   14654:      	add	x0, sp, #0x80
   14658:      	mov	w1, #0x10               // =16
   1465c:      	blr	x8
   14660:      	ldr	w21, [sp, #0x84]
   14664:      	ldr	x8, [sp, #0x40]
   14668:      	ldr	x10, [sp, #0x60]
   1466c:      	sub	x12, x10, x8
   14670:      	ldr	w23, [sp, #0x68]
   14674:      	subs	w10, w21, w23
   14678:      	ldr	x9, [sp, #0x88]
   1467c:      	ldr	x25, [sp, #0x8]
   14680:      	csel	w10, wzr, w10, lo
   14684:      	cmp	w23, w21
   14688:      	csel	w11, w23, w21, lo
   1468c:      	cinc	w13, w11, hi
   14690:      	sub	w14, w23, w13
   14694:      	subs	x12, x12, x13
   14698:      	str	w14, [sp, #0x68]
   1469c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   146a0:      	cmp	x12, #0xfff
   146a4:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   146a8:      	cmp	w23, w21
   146ac:      	b.ls	0x146b8 <generic_fentry_path+0xb3f8>
   146b0:      	mov	w13, #0x2f              // =47
   146b4:      	strb	w13, [x8, x12]
   146b8:      	add	x19, x8, x12
   146bc:      	cmp	w23, w21
   146c0:      	add	x2, x9, x10
   146c4:      	and	w1, w11, #0xff
   146c8:      	mov	w8, #0x4                // =4
   146cc:      	cinc	x0, x19, hi
   146d0:      	blr	x8
   146d4:      	ldr	x25, [sp, #0x8]
   146d8:      	cmp	w23, w21
   146dc:      	str	x19, [sp, #0x60]
   146e0:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   146e4:      	ldr	x21, [sp, #0x78]
   146e8:      	ldp	x2, x24, [sp, #0x50]
   146ec:      	str	x21, [sp, #0x48]
   146f0:      	b	0x14744 <generic_fentry_path+0xb484>
   146f4:      	add	x2, x24, #0x10
   146f8:      	mov	w8, #0x4                // =4
   146fc:      	add	x9, sp, #0x98
   14700:      	add	x0, sp, #0x98
   14704:      	mov	w1, #0x8                // =8
   14708:      	blr	x8
   1470c:      	ldr	x8, [sp, #0x58]
   14710:      	ldr	x9, [sp, #0x98]
   14714:      	cmp	x8, x9
   14718:      	ldr	x25, [sp, #0x8]
   1471c:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   14720:      	add	x2, x24, #0x18
   14724:      	mov	w8, #0x4                // =4
   14728:      	mov	x0, x22
   1472c:      	mov	w1, #0x8                // =8
   14730:      	blr	x8
   14734:      	ldr	x24, [sp, #0x98]
   14738:      	ldr	x21, [sp, #0x48]
   1473c:      	add	x2, x24, #0x20
   14740:      	stp	x2, x24, [sp, #0x50]
   14744:      	ldr	x8, [sp, #0x30]
   14748:      	ldr	x25, [sp, #0x8]
   1474c:      	add	x9, sp, #0x70
   14750:      	cmp	x21, x8
   14754:      	b.ne	0x14764 <generic_fentry_path+0xb4a4>
   14758:      	ldr	x8, [sp, #0x38]
   1475c:      	cmp	x2, x8
   14760:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   14764:      	mov	w8, #0x4                // =4
   14768:      	add	x0, sp, #0x70
   1476c:      	mov	w1, #0x8                // =8
   14770:      	blr	x8
   14774:      	ldr	x8, [sp, #0x70]
   14778:      	cmp	x21, x8
   1477c:      	b.eq	0x14870 <generic_fentry_path+0xb5b0>
   14780:      	add	x23, x21, #0x18
   14784:      	mov	w8, #0x4                // =4
   14788:      	add	x9, sp, #0x98
   1478c:      	add	x0, sp, #0x98
   14790:      	mov	w1, #0x8                // =8
   14794:      	mov	x2, x23
   14798:      	blr	x8
   1479c:      	ldr	x8, [sp, #0x98]
   147a0:      	cmp	x8, x21
   147a4:      	b.eq	0x14870 <generic_fentry_path+0xb5b0>
   147a8:      	mov	w8, #0x4                // =4
   147ac:      	add	x9, sp, #0x78
   147b0:      	add	x0, sp, #0x78
   147b4:      	mov	w1, #0x8                // =8
   147b8:      	mov	x2, x23
   147bc:      	blr	x8
   147c0:      	add	x2, x21, #0x20
   147c4:      	mov	w8, #0x4                // =4
   147c8:      	mov	w9, #0x10               // =16
   147cc:      	add	x10, sp, #0x80
   147d0:      	add	x0, sp, #0x80
   147d4:      	mov	w1, #0x10               // =16
   147d8:      	blr	x8
   147dc:      	ldr	w21, [sp, #0x84]
   147e0:      	ldr	x8, [sp, #0x40]
   147e4:      	ldr	x10, [sp, #0x60]
   147e8:      	sub	x12, x10, x8
   147ec:      	ldr	w23, [sp, #0x68]
   147f0:      	subs	w10, w21, w23
   147f4:      	ldr	x9, [sp, #0x88]
   147f8:      	ldr	x25, [sp, #0x8]
   147fc:      	csel	w10, wzr, w10, lo
   14800:      	cmp	w23, w21
   14804:      	csel	w11, w23, w21, lo
   14808:      	cinc	w13, w11, hi
   1480c:      	sub	w14, w23, w13
   14810:      	subs	x12, x12, x13
   14814:      	str	w14, [sp, #0x68]
   14818:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   1481c:      	cmp	x12, #0xfff
   14820:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   14824:      	cmp	w23, w21
   14828:      	b.ls	0x14834 <generic_fentry_path+0xb574>
   1482c:      	mov	w13, #0x2f              // =47
   14830:      	strb	w13, [x8, x12]
   14834:      	add	x19, x8, x12
   14838:      	cmp	w23, w21
   1483c:      	add	x2, x9, x10
   14840:      	and	w1, w11, #0xff
   14844:      	mov	w8, #0x4                // =4
   14848:      	cinc	x0, x19, hi
   1484c:      	blr	x8
   14850:      	ldr	x25, [sp, #0x8]
   14854:      	cmp	w23, w21
   14858:      	str	x19, [sp, #0x60]
   1485c:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   14860:      	ldr	x21, [sp, #0x78]
   14864:      	ldp	x2, x24, [sp, #0x50]
   14868:      	str	x21, [sp, #0x48]
   1486c:      	b	0x148c0 <generic_fentry_path+0xb600>
   14870:      	add	x2, x24, #0x10
   14874:      	mov	w8, #0x4                // =4
   14878:      	add	x9, sp, #0x98
   1487c:      	add	x0, sp, #0x98
   14880:      	mov	w1, #0x8                // =8
   14884:      	blr	x8
   14888:      	ldr	x8, [sp, #0x58]
   1488c:      	ldr	x9, [sp, #0x98]
   14890:      	cmp	x8, x9
   14894:      	ldr	x25, [sp, #0x8]
   14898:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   1489c:      	add	x2, x24, #0x18
   148a0:      	mov	w8, #0x4                // =4
   148a4:      	mov	x0, x22
   148a8:      	mov	w1, #0x8                // =8
   148ac:      	blr	x8
   148b0:      	ldr	x24, [sp, #0x98]
   148b4:      	ldr	x21, [sp, #0x48]
   148b8:      	add	x2, x24, #0x20
   148bc:      	stp	x2, x24, [sp, #0x50]
   148c0:      	ldr	x8, [sp, #0x30]
   148c4:      	ldr	x25, [sp, #0x8]
   148c8:      	add	x9, sp, #0x70
   148cc:      	cmp	x21, x8
   148d0:      	b.ne	0x148e0 <generic_fentry_path+0xb620>
   148d4:      	ldr	x8, [sp, #0x38]
   148d8:      	cmp	x2, x8
   148dc:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   148e0:      	mov	w8, #0x4                // =4
   148e4:      	add	x0, sp, #0x70
   148e8:      	mov	w1, #0x8                // =8
   148ec:      	blr	x8
   148f0:      	ldr	x8, [sp, #0x70]
   148f4:      	cmp	x21, x8
   148f8:      	b.eq	0x149ec <generic_fentry_path+0xb72c>
   148fc:      	add	x23, x21, #0x18
   14900:      	mov	w8, #0x4                // =4
   14904:      	add	x9, sp, #0x98
   14908:      	add	x0, sp, #0x98
   1490c:      	mov	w1, #0x8                // =8
   14910:      	mov	x2, x23
   14914:      	blr	x8
   14918:      	ldr	x8, [sp, #0x98]
   1491c:      	cmp	x8, x21
   14920:      	b.eq	0x149ec <generic_fentry_path+0xb72c>
   14924:      	mov	w8, #0x4                // =4
   14928:      	add	x9, sp, #0x78
   1492c:      	add	x0, sp, #0x78
   14930:      	mov	w1, #0x8                // =8
   14934:      	mov	x2, x23
   14938:      	blr	x8
   1493c:      	add	x2, x21, #0x20
   14940:      	mov	w8, #0x4                // =4
   14944:      	mov	w9, #0x10               // =16
   14948:      	add	x10, sp, #0x80
   1494c:      	add	x0, sp, #0x80
   14950:      	mov	w1, #0x10               // =16
   14954:      	blr	x8
   14958:      	ldr	w21, [sp, #0x84]
   1495c:      	ldr	x8, [sp, #0x40]
   14960:      	ldr	x10, [sp, #0x60]
   14964:      	sub	x12, x10, x8
   14968:      	ldr	w23, [sp, #0x68]
   1496c:      	subs	w10, w21, w23
   14970:      	ldr	x9, [sp, #0x88]
   14974:      	ldr	x25, [sp, #0x8]
   14978:      	csel	w10, wzr, w10, lo
   1497c:      	cmp	w23, w21
   14980:      	csel	w11, w23, w21, lo
   14984:      	cinc	w13, w11, hi
   14988:      	sub	w14, w23, w13
   1498c:      	subs	x12, x12, x13
   14990:      	str	w14, [sp, #0x68]
   14994:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   14998:      	cmp	x12, #0xfff
   1499c:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   149a0:      	cmp	w23, w21
   149a4:      	b.ls	0x149b0 <generic_fentry_path+0xb6f0>
   149a8:      	mov	w13, #0x2f              // =47
   149ac:      	strb	w13, [x8, x12]
   149b0:      	add	x19, x8, x12
   149b4:      	cmp	w23, w21
   149b8:      	add	x2, x9, x10
   149bc:      	and	w1, w11, #0xff
   149c0:      	mov	w8, #0x4                // =4
   149c4:      	cinc	x0, x19, hi
   149c8:      	blr	x8
   149cc:      	ldr	x25, [sp, #0x8]
   149d0:      	cmp	w23, w21
   149d4:      	str	x19, [sp, #0x60]
   149d8:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   149dc:      	ldr	x21, [sp, #0x78]
   149e0:      	ldp	x2, x24, [sp, #0x50]
   149e4:      	str	x21, [sp, #0x48]
   149e8:      	b	0x14a3c <generic_fentry_path+0xb77c>
   149ec:      	add	x2, x24, #0x10
   149f0:      	mov	w8, #0x4                // =4
   149f4:      	add	x9, sp, #0x98
   149f8:      	add	x0, sp, #0x98
   149fc:      	mov	w1, #0x8                // =8
   14a00:      	blr	x8
   14a04:      	ldr	x8, [sp, #0x58]
   14a08:      	ldr	x9, [sp, #0x98]
   14a0c:      	cmp	x8, x9
   14a10:      	ldr	x25, [sp, #0x8]
   14a14:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   14a18:      	add	x2, x24, #0x18
   14a1c:      	mov	w8, #0x4                // =4
   14a20:      	mov	x0, x22
   14a24:      	mov	w1, #0x8                // =8
   14a28:      	blr	x8
   14a2c:      	ldr	x24, [sp, #0x98]
   14a30:      	ldr	x21, [sp, #0x48]
   14a34:      	add	x2, x24, #0x20
   14a38:      	stp	x2, x24, [sp, #0x50]
   14a3c:      	ldr	x8, [sp, #0x30]
   14a40:      	ldr	x25, [sp, #0x8]
   14a44:      	add	x9, sp, #0x70
   14a48:      	cmp	x21, x8
   14a4c:      	b.ne	0x14a5c <generic_fentry_path+0xb79c>
   14a50:      	ldr	x8, [sp, #0x38]
   14a54:      	cmp	x2, x8
   14a58:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   14a5c:      	mov	w8, #0x4                // =4
   14a60:      	add	x0, sp, #0x70
   14a64:      	mov	w1, #0x8                // =8
   14a68:      	blr	x8
   14a6c:      	ldr	x8, [sp, #0x70]
   14a70:      	cmp	x21, x8
   14a74:      	b.eq	0x14b68 <generic_fentry_path+0xb8a8>
   14a78:      	add	x23, x21, #0x18
   14a7c:      	mov	w8, #0x4                // =4
   14a80:      	add	x9, sp, #0x98
   14a84:      	add	x0, sp, #0x98
   14a88:      	mov	w1, #0x8                // =8
   14a8c:      	mov	x2, x23
   14a90:      	blr	x8
   14a94:      	ldr	x8, [sp, #0x98]
   14a98:      	cmp	x8, x21
   14a9c:      	b.eq	0x14b68 <generic_fentry_path+0xb8a8>
   14aa0:      	mov	w8, #0x4                // =4
   14aa4:      	add	x9, sp, #0x78
   14aa8:      	add	x0, sp, #0x78
   14aac:      	mov	w1, #0x8                // =8
   14ab0:      	mov	x2, x23
   14ab4:      	blr	x8
   14ab8:      	add	x2, x21, #0x20
   14abc:      	mov	w8, #0x4                // =4
   14ac0:      	mov	w9, #0x10               // =16
   14ac4:      	add	x10, sp, #0x80
   14ac8:      	add	x0, sp, #0x80
   14acc:      	mov	w1, #0x10               // =16
   14ad0:      	blr	x8
   14ad4:      	ldr	w21, [sp, #0x84]
   14ad8:      	ldr	x8, [sp, #0x40]
   14adc:      	ldr	x10, [sp, #0x60]
   14ae0:      	sub	x12, x10, x8
   14ae4:      	ldr	w23, [sp, #0x68]
   14ae8:      	subs	w10, w21, w23
   14aec:      	ldr	x9, [sp, #0x88]
   14af0:      	ldr	x25, [sp, #0x8]
   14af4:      	csel	w10, wzr, w10, lo
   14af8:      	cmp	w23, w21
   14afc:      	csel	w11, w23, w21, lo
   14b00:      	cinc	w13, w11, hi
   14b04:      	sub	w14, w23, w13
   14b08:      	subs	x12, x12, x13
   14b0c:      	str	w14, [sp, #0x68]
   14b10:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   14b14:      	cmp	x12, #0xfff
   14b18:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   14b1c:      	cmp	w23, w21
   14b20:      	b.ls	0x14b2c <generic_fentry_path+0xb86c>
   14b24:      	mov	w13, #0x2f              // =47
   14b28:      	strb	w13, [x8, x12]
   14b2c:      	add	x19, x8, x12
   14b30:      	cmp	w23, w21
   14b34:      	add	x2, x9, x10
   14b38:      	and	w1, w11, #0xff
   14b3c:      	mov	w8, #0x4                // =4
   14b40:      	cinc	x0, x19, hi
   14b44:      	blr	x8
   14b48:      	ldr	x25, [sp, #0x8]
   14b4c:      	cmp	w23, w21
   14b50:      	str	x19, [sp, #0x60]
   14b54:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   14b58:      	ldr	x21, [sp, #0x78]
   14b5c:      	ldp	x2, x24, [sp, #0x50]
   14b60:      	str	x21, [sp, #0x48]
   14b64:      	b	0x14bb8 <generic_fentry_path+0xb8f8>
   14b68:      	add	x2, x24, #0x10
   14b6c:      	mov	w8, #0x4                // =4
   14b70:      	add	x9, sp, #0x98
   14b74:      	add	x0, sp, #0x98
   14b78:      	mov	w1, #0x8                // =8
   14b7c:      	blr	x8
   14b80:      	ldr	x8, [sp, #0x58]
   14b84:      	ldr	x9, [sp, #0x98]
   14b88:      	cmp	x8, x9
   14b8c:      	ldr	x25, [sp, #0x8]
   14b90:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   14b94:      	add	x2, x24, #0x18
   14b98:      	mov	w8, #0x4                // =4
   14b9c:      	mov	x0, x22
   14ba0:      	mov	w1, #0x8                // =8
   14ba4:      	blr	x8
   14ba8:      	ldr	x24, [sp, #0x98]
   14bac:      	ldr	x21, [sp, #0x48]
   14bb0:      	add	x2, x24, #0x20
   14bb4:      	stp	x2, x24, [sp, #0x50]
   14bb8:      	ldr	x8, [sp, #0x30]
   14bbc:      	ldr	x25, [sp, #0x8]
   14bc0:      	add	x9, sp, #0x70
   14bc4:      	cmp	x21, x8
   14bc8:      	b.ne	0x14bd8 <generic_fentry_path+0xb918>
   14bcc:      	ldr	x8, [sp, #0x38]
   14bd0:      	cmp	x2, x8
   14bd4:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   14bd8:      	mov	w8, #0x4                // =4
   14bdc:      	add	x0, sp, #0x70
   14be0:      	mov	w1, #0x8                // =8
   14be4:      	blr	x8
   14be8:      	ldr	x8, [sp, #0x70]
   14bec:      	cmp	x21, x8
   14bf0:      	b.eq	0x14ce0 <generic_fentry_path+0xba20>
   14bf4:      	add	x23, x21, #0x18
   14bf8:      	mov	w8, #0x4                // =4
   14bfc:      	add	x9, sp, #0x98
   14c00:      	add	x0, sp, #0x98
   14c04:      	mov	w1, #0x8                // =8
   14c08:      	mov	x2, x23
   14c0c:      	blr	x8
   14c10:      	ldr	x8, [sp, #0x98]
   14c14:      	cmp	x8, x21
   14c18:      	b.eq	0x14ce0 <generic_fentry_path+0xba20>
   14c1c:      	mov	w8, #0x4                // =4
   14c20:      	add	x9, sp, #0x78
   14c24:      	add	x0, sp, #0x78
   14c28:      	mov	w1, #0x8                // =8
   14c2c:      	mov	x2, x23
   14c30:      	blr	x8
   14c34:      	add	x2, x21, #0x20
   14c38:      	mov	w8, #0x4                // =4
   14c3c:      	mov	w9, #0x10               // =16
   14c40:      	add	x10, sp, #0x80
   14c44:      	add	x0, sp, #0x80
   14c48:      	mov	w1, #0x10               // =16
   14c4c:      	blr	x8
   14c50:      	ldr	w21, [sp, #0x84]
   14c54:      	ldr	x8, [sp, #0x40]
   14c58:      	ldr	x10, [sp, #0x60]
   14c5c:      	sub	x12, x10, x8
   14c60:      	ldr	w23, [sp, #0x68]
   14c64:      	subs	w10, w21, w23
   14c68:      	ldr	x9, [sp, #0x88]
   14c6c:      	ldr	x25, [sp, #0x8]
   14c70:      	csel	w10, wzr, w10, lo
   14c74:      	cmp	w23, w21
   14c78:      	csel	w11, w23, w21, lo
   14c7c:      	cinc	w13, w11, hi
   14c80:      	sub	w14, w23, w13
   14c84:      	subs	x12, x12, x13
   14c88:      	str	w14, [sp, #0x68]
   14c8c:      	b.lo	0x14d48 <generic_fentry_path+0xba88>
   14c90:      	cmp	x12, #0xfff
   14c94:      	b.hi	0x14d48 <generic_fentry_path+0xba88>
   14c98:      	cmp	w23, w21
   14c9c:      	b.ls	0x14ca8 <generic_fentry_path+0xb9e8>
   14ca0:      	mov	w13, #0x2f              // =47
   14ca4:      	strb	w13, [x8, x12]
   14ca8:      	add	x19, x8, x12
   14cac:      	cmp	w23, w21
   14cb0:      	add	x2, x9, x10
   14cb4:      	and	w1, w11, #0xff
   14cb8:      	mov	w8, #0x4                // =4
   14cbc:      	cinc	x0, x19, hi
   14cc0:      	blr	x8
   14cc4:      	ldr	x25, [sp, #0x8]
   14cc8:      	cmp	w23, w21
   14ccc:      	str	x19, [sp, #0x60]
   14cd0:      	b.ls	0x14d48 <generic_fentry_path+0xba88>
   14cd4:      	ldr	x8, [sp, #0x78]
   14cd8:      	str	x8, [sp, #0x48]
   14cdc:      	b	0x14d2c <generic_fentry_path+0xba6c>
   14ce0:      	add	x2, x24, #0x10
   14ce4:      	mov	w8, #0x4                // =4
   14ce8:      	add	x9, sp, #0x98
   14cec:      	add	x0, sp, #0x98
   14cf0:      	mov	w1, #0x8                // =8
   14cf4:      	blr	x8
   14cf8:      	ldr	x8, [sp, #0x58]
   14cfc:      	ldr	x9, [sp, #0x98]
   14d00:      	cmp	x8, x9
   14d04:      	ldr	x25, [sp, #0x8]
   14d08:      	b.eq	0x14d40 <generic_fentry_path+0xba80>
   14d0c:      	add	x2, x24, #0x18
   14d10:      	mov	w8, #0x4                // =4
   14d14:      	mov	x0, x22
   14d18:      	mov	w1, #0x8                // =8
   14d1c:      	blr	x8
   14d20:      	ldr	x8, [sp, #0x98]
   14d24:      	add	x9, x8, #0x20
   14d28:      	stp	x9, x8, [sp, #0x50]
   14d2c:      	ldr	x25, [sp, #0x8]
   14d30:      	subs	w20, w20, #0x80
   14d34:      	add	x19, sp, #0x70
   14d38:      	b.ne	0x943c <generic_fentry_path+0x17c>
   14d3c:      	b	0x14d48 <generic_fentry_path+0xba88>
   14d40:      	mov	w8, #0x1                // =1
   14d44:      	strb	w8, [sp, #0x6c]
   14d48:      	ldr	w8, [x25, #0x8]
   14d4c:      	ldp	x10, x20, [sp, #0x10]
   14d50:      	add	w8, w8, #0x1
   14d54:      	str	w8, [x25, #0x8]
   14d58:      	ldr	w9, [sp, #0x60]
   14d5c:      	sub	w9, w9, w10
   14d60:      	str	w9, [x25, #0x4]
   14d64:      	ldrb	w9, [sp, #0x6c]
   14d68:      	cbnz	w9, 0x14da0 <generic_fentry_path+0xbae0>
   14d6c:      	cmp	w8, #0x8
   14d70:      	b.eq	0x14da0 <generic_fentry_path+0xbae0>
   14d74:      	ldp	x8, x9, [sp, #0x48]
   14d78:      	mov	w2, #0x6                // =6
   14d7c:      	str	x8, [x20, #0x6458]
   14d80:      	ldr	x8, [sp, #0x58]
   14d84:      	str	x9, [x20, #0x6460]
   14d88:      	adrp	x9, 0x14000 <generic_fentry_path+0xad40>
   14d8c:      	str	x8, [x20, #0x6468]
   14d90:      	mov	w8, #0xc                // =12
   14d94:      	ldr	x9, [x9]
   14d98:      	ldr	x0, [sp, #0x20]
   14d9c:      	b	0x14db4 <generic_fentry_path+0xbaf4>
   14da0:      	adrp	x9, 0x14000 <generic_fentry_path+0xad40>
   14da4:      	mov	w2, #0x1                // =1
   14da8:      	mov	w8, #0xc                // =12
   14dac:      	ldr	x9, [x9]
   14db0:      	ldr	x0, [sp, #0x20]
   14db4:      	adrp	x1, 0x14000 <generic_fentry_path+0xad40>
   14db8:      	ldr	x1, [x1]
   14dbc:      	blr	x8
   14dc0:      	b	0x1515c <generic_fentry_path+0xbe9c>
   14dc4:      	str	w23, [sp, #0x98]
   14dc8:      	mov	x3, xzr
   14dcc:      	mov	w8, #0x2                // =2
   14dd0:      	add	x9, sp, #0x30
   14dd4:      	add	x10, sp, #0x98
   14dd8:      	add	x1, sp, #0x30
   14ddc:      	add	x2, sp, #0x98
   14de0:      	mov	x0, x22
   14de4:      	blr	x8
   14de8:      	ldr	x23, [sp, #0x80]
   14dec:      	mov	w8, #0x8                // =8
   14df0:      	mov	w9, #0x4                // =4
   14df4:      	add	x10, sp, #0x30
   14df8:      	add	x0, sp, #0x30
   14dfc:      	mov	w1, #0x8                // =8
   14e00:      	add	x2, x23, #0x10
   14e04:      	blr	x9
   14e08:      	ldr	x8, [sp, #0x30]
   14e0c:      	cbnz	x8, 0x14e54 <generic_fentry_path+0xbb94>
   14e10:      	add	x2, x23, #0x18
   14e14:      	mov	w8, #0x8                // =8
   14e18:      	mov	w9, #0x4                // =4
   14e1c:      	add	x10, sp, #0x30
   14e20:      	add	x0, sp, #0x30
   14e24:      	mov	w1, #0x8                // =8
   14e28:      	blr	x9
   14e2c:      	ldr	x8, [sp, #0x30]
   14e30:      	cmp	x8, x23
   14e34:      	b.eq	0x14e54 <generic_fentry_path+0xbb94>
   14e38:      	adrp	x8, 0x14000 <generic_fentry_path+0xad40>
   14e3c:      	add	x8, x8, #0x0
   14e40:      	add	x29, x21, #0xff5
   14e44:      	ldr	x8, [x8]
   14e48:      	str	x8, [x29]
   14e4c:      	mov	w8, #0x2964             // =10596
   14e50:      	strh	w8, [x29, #0x8]
   14e54:      	mov	w8, #0x23               // =35
   14e58:      	blr	x8
   14e5c:      	add	x2, x0, #0xb30
   14e60:      	mov	w8, #0x8                // =8
   14e64:      	mov	w9, #0x4                // =4
   14e68:      	add	x10, sp, #0x98
   14e6c:      	add	x0, sp, #0x98
   14e70:      	mov	w1, #0x8                // =8
   14e74:      	blr	x9
   14e78:      	cbz	x0, 0x14ee8 <generic_fentry_path+0xbc28>
   14e7c:      	neg	w8, w0
   14e80:      	mov	w9, #0x1                // =1
   14e84:      	add	x1, sp, #0x30
   14e88:      	strh	w8, [sp, #0x30]
   14e8c:      	mov	w8, #0x6                // =6
   14e90:      	mov	x0, x22
   14e94:      	mov	w23, #0x1               // =1
   14e98:      	strh	w8, [sp, #0x32]
   14e9c:      	mov	x8, #0x33               // =51
   14ea0:      	movk	x8, #0x4, lsl #32
   14ea4:      	stur	x8, [sp, #0x34]
   14ea8:      	add	x8, sp, #0x30
   14eac:      	blr	x9
   14eb0:      	cbz	x0, 0x14ec4 <generic_fentry_path+0xbc04>
   14eb4:      	ldr	w8, [x0]
   14eb8:      	add	w8, w8, #0x1
   14ebc:      	str	w8, [x0]
   14ec0:      	b	0x14ee8 <generic_fentry_path+0xbc28>
   14ec4:      	str	w23, [sp, #0x78]
   14ec8:      	mov	x3, xzr
   14ecc:      	mov	w8, #0x2                // =2
   14ed0:      	add	x9, sp, #0x30
   14ed4:      	add	x10, sp, #0x78
   14ed8:      	add	x1, sp, #0x30
   14edc:      	add	x2, sp, #0x78
   14ee0:      	mov	x0, x22
   14ee4:      	blr	x8
   14ee8:      	ldr	x8, [sp, #0x98]
   14eec:      	mov	w9, #0x6448             // =25672
   14ef0:      	ldr	x23, [x20, #0x6440]
   14ef4:      	mov	w1, #0x8                // =8
   14ef8:      	add	x0, x20, x9
   14efc:      	mov	w9, #0x4                // =4
   14f00:      	add	x24, x8, #0x18
   14f04:      	add	x2, x8, #0x20
   14f08:      	mov	w8, #0x8                // =8
   14f0c:      	blr	x9
   14f10:      	cbz	x0, 0x14f80 <generic_fentry_path+0xbcc0>
   14f14:      	neg	w8, w0
   14f18:      	mov	w9, #0x1                // =1
   14f1c:      	add	x1, sp, #0x30
   14f20:      	strh	w8, [sp, #0x30]
   14f24:      	mov	w8, #0x6                // =6
   14f28:      	mov	x0, x22
   14f2c:      	mov	w19, #0x1               // =1
   14f30:      	strh	w8, [sp, #0x32]
   14f34:      	mov	x8, #0x38               // =56
   14f38:      	movk	x8, #0x4, lsl #32
   14f3c:      	stur	x8, [sp, #0x34]
   14f40:      	add	x8, sp, #0x30
   14f44:      	blr	x9
   14f48:      	cbz	x0, 0x14f5c <generic_fentry_path+0xbc9c>
   14f4c:      	ldr	w8, [x0]
   14f50:      	add	w8, w8, #0x1
   14f54:      	str	w8, [x0]
   14f58:      	b	0x14f80 <generic_fentry_path+0xbcc0>
   14f5c:      	str	w19, [sp, #0x78]
   14f60:      	mov	x3, xzr
   14f64:      	mov	w8, #0x2                // =2
   14f68:      	add	x9, sp, #0x30
   14f6c:      	add	x10, sp, #0x78
   14f70:      	add	x1, sp, #0x30
   14f74:      	add	x2, sp, #0x78
   14f78:      	mov	x0, x22
   14f7c:      	blr	x8
   14f80:      	mov	w8, #0x6450             // =25680
   14f84:      	mov	w9, #0x4                // =4
   14f88:      	mov	w1, #0x8                // =8
   14f8c:      	mov	x2, x24
   14f90:      	add	x0, x20, x8
   14f94:      	mov	w8, #0x8                // =8
   14f98:      	blr	x9
   14f9c:      	cbz	x0, 0x1500c <generic_fentry_path+0xbd4c>
   14fa0:      	neg	w8, w0
   14fa4:      	mov	w9, #0x1                // =1
   14fa8:      	add	x1, sp, #0x30
   14fac:      	strh	w8, [sp, #0x30]
   14fb0:      	mov	w8, #0x6                // =6
   14fb4:      	mov	x0, x22
   14fb8:      	mov	w19, #0x1               // =1
   14fbc:      	strh	w8, [sp, #0x32]
   14fc0:      	mov	x8, #0x39               // =57
   14fc4:      	movk	x8, #0x4, lsl #32
   14fc8:      	stur	x8, [sp, #0x34]
   14fcc:      	add	x8, sp, #0x30
   14fd0:      	blr	x9
   14fd4:      	cbz	x0, 0x14fe8 <generic_fentry_path+0xbd28>
   14fd8:      	ldr	w8, [x0]
   14fdc:      	add	w8, w8, #0x1
   14fe0:      	str	w8, [x0]
   14fe4:      	b	0x1500c <generic_fentry_path+0xbd4c>
   14fe8:      	str	w19, [sp, #0x78]
   14fec:      	mov	x3, xzr
   14ff0:      	mov	w8, #0x2                // =2
   14ff4:      	add	x9, sp, #0x30
   14ff8:      	add	x10, sp, #0x78
   14ffc:      	add	x1, sp, #0x30
   15000:      	add	x2, sp, #0x78
   15004:      	mov	x0, x22
   15008:      	blr	x8
   1500c:      	mov	w8, #0x6458             // =25688
   15010:      	add	x2, x23, #0x8
   15014:      	mov	w9, #0x4                // =4
   15018:      	mov	w1, #0x8                // =8
   1501c:      	add	x0, x20, x8
   15020:      	mov	w8, #0x8                // =8
   15024:      	blr	x9
   15028:      	cbz	x0, 0x15098 <generic_fentry_path+0xbdd8>
   1502c:      	neg	w8, w0
   15030:      	mov	w9, #0x1                // =1
   15034:      	add	x1, sp, #0x30
   15038:      	strh	w8, [sp, #0x30]
   1503c:      	mov	w8, #0x6                // =6
   15040:      	mov	x0, x22
   15044:      	mov	w19, #0x1               // =1
   15048:      	strh	w8, [sp, #0x32]
   1504c:      	mov	x8, #0x3a               // =58
   15050:      	movk	x8, #0x4, lsl #32
   15054:      	stur	x8, [sp, #0x34]
   15058:      	add	x8, sp, #0x30
   1505c:      	blr	x9
   15060:      	cbz	x0, 0x15074 <generic_fentry_path+0xbdb4>
   15064:      	ldr	w8, [x0]
   15068:      	add	w8, w8, #0x1
   1506c:      	str	w8, [x0]
   15070:      	b	0x15098 <generic_fentry_path+0xbdd8>
   15074:      	str	w19, [sp, #0x78]
   15078:      	mov	x3, xzr
   1507c:      	mov	w8, #0x2                // =2
   15080:      	add	x9, sp, #0x30
   15084:      	add	x10, sp, #0x78
   15088:      	add	x1, sp, #0x30
   1508c:      	add	x2, sp, #0x78
   15090:      	mov	x0, x22
   15094:      	blr	x8
   15098:      	mov	w8, #0x6460             // =25696
   1509c:      	mov	w9, #0x4                // =4
   150a0:      	mov	w1, #0x8                // =8
   150a4:      	mov	x2, x23
   150a8:      	add	x0, x20, x8
   150ac:      	mov	w8, #0x8                // =8
   150b0:      	blr	x9
   150b4:      	cbz	x0, 0x15124 <generic_fentry_path+0xbe64>
   150b8:      	neg	w8, w0
   150bc:      	mov	w9, #0x1                // =1
   150c0:      	add	x1, sp, #0x30
   150c4:      	strh	w8, [sp, #0x30]
   150c8:      	mov	w8, #0x6                // =6
   150cc:      	mov	x0, x22
   150d0:      	mov	w19, #0x1               // =1
   150d4:      	strh	w8, [sp, #0x32]
   150d8:      	mov	x8, #0x3b               // =59
   150dc:      	movk	x8, #0x4, lsl #32
   150e0:      	stur	x8, [sp, #0x34]
   150e4:      	add	x8, sp, #0x30
   150e8:      	blr	x9
   150ec:      	cbz	x0, 0x15100 <generic_fentry_path+0xbe40>
   150f0:      	ldr	w8, [x0]
   150f4:      	add	w8, w8, #0x1
   150f8:      	str	w8, [x0]
   150fc:      	b	0x15124 <generic_fentry_path+0xbe64>
   15100:      	str	w19, [sp, #0x78]
   15104:      	mov	x3, xzr
   15108:      	mov	w8, #0x2                // =2
   1510c:      	add	x9, sp, #0x30
   15110:      	add	x10, sp, #0x78
   15114:      	add	x1, sp, #0x30
   15118:      	add	x2, sp, #0x78
   1511c:      	mov	x0, x22
   15120:      	blr	x8
   15124:      	ldr	x8, [x20, #0x6460]
   15128:      	mov	w9, #0x1                // =1
   1512c:      	adrp	x1, 0x15000 <generic_fentry_path+0xbd40>
   15130:      	mov	w2, #0x6                // =6
   15134:      	str	w9, [x25]
   15138:      	mov	w9, #0xc                // =12
   1513c:      	sub	x8, x8, #0x20
   15140:      	str	x8, [x20, #0x6468]
   15144:      	sub	w8, w29, w21
   15148:      	stp	w8, wzr, [x25, #0x4]
   1514c:      	mov	w8, #0x6                // =6
   15150:      	ldr	x1, [x1]
   15154:      	ldr	x0, [sp, #0x20]
   15158:      	blr	x9
   1515c:      	ldp	x20, x19, [sp, #0xd0]
   15160:      	mov	w0, wzr
   15164:      	ldr	x29, [sp, #0x90]
   15168:      	ldp	x22, x21, [sp, #0xc0]
   1516c:      	ldp	x24, x23, [sp, #0xb0]
   15170:      	ldp	x30, x25, [sp, #0xa0]
   15174:      	add	sp, sp, #0xe0
   15178:      	ret

Disassembly of section fentry/generic_fentry:

0000000000000000 <generic_fentry_event>:
       0:      	sub	sp, sp, #0xd0
       4:      	stp	x30, x25, [sp, #0x90]
       8:      	stp	x24, x23, [sp, #0xa0]
       c:      	stp	x22, x21, [sp, #0xb0]
      10:      	stp	x20, x19, [sp, #0xc0]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0xc]
      1c:      	adrp	x0, 0x0 <generic_fentry_event>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0xc
      2c:      	add	x1, sp, #0xc
      30:      	blr	x8
      34:      	cbz	x0, 0x540 <generic_fentry_event+0x540>
      38:      	mov	w8, #0x5ef8             // =24312
      3c:      	mov	x20, x0
      40:      	add	x21, x0, x8
      44:      	adrp	x0, 0x0 <generic_fentry_event>
      48:      	mov	w8, #0x1                // =1
      4c:      	str	wzr, [x21]
      50:      	mov	x1, x21
      54:      	ldr	x0, [x0]
      58:      	blr	x8
      5c:      	cbz	x0, 0x540 <generic_fentry_event+0x540>
      60:      	ldr	w8, [x0, #0x64]
      64:      	str	w8, [sp, #0x1c]
      68:      	cbz	w8, 0x224 <generic_fentry_event+0x224>
      6c:      	adrp	x22, 0x0 <generic_fentry_event>
      70:      	mov	w8, #0x1                // =1
      74:      	add	x9, sp, #0x1c
      78:      	ldr	x22, [x22]
      7c:      	mov	x24, x0
      80:      	add	x1, sp, #0x1c
      84:      	mov	x0, x22
      88:      	blr	x8
      8c:      	cbz	x0, 0x540 <generic_fentry_event+0x540>
      90:      	mov	x23, x0
      94:      	str	wzr, [sp, #0x84]
      98:      	adrp	x0, 0x0 <generic_fentry_event>
      9c:      	mov	w8, #0x1                // =1
      a0:      	ldr	x0, [x0]
      a4:      	add	x9, sp, #0x84
      a8:      	add	x1, sp, #0x84
      ac:      	blr	x8
      b0:      	cbz	x0, 0xdc <generic_fentry_event+0xdc>
      b4:      	ldr	x8, [x0, #0x20]
      b8:      	mov	w9, #0x7270             // =29296
      bc:      	movk	w9, #0x6367, lsl #16
      c0:      	cmp	x8, x9
      c4:      	b.ne	0xe4 <generic_fentry_event+0xe4>
      c8:      	mov	w8, #0x50               // =80
      cc:      	blr	x8
      d0:      	str	x0, [sp, #0x30]
      d4:      	cbnz	x0, 0x1d8 <generic_fentry_event+0x1d8>
      d8:      	b	0x540 <generic_fentry_event+0x540>
      dc:      	mov	w25, wzr
      e0:      	b	0xe8 <generic_fentry_event+0xe8>
      e4:      	ldr	w25, [x0, #0x10]
      e8:      	mov	w8, #0x23               // =35
      ec:      	blr	x8
      f0:      	str	xzr, [sp, #0x88]
      f4:      	add	x2, x0, #0xcd0
      f8:      	mov	w8, #0x8                // =8
      fc:      	mov	w9, #0x71               // =113
     100:      	add	x10, sp, #0x20
     104:      	add	x0, sp, #0x20
     108:      	mov	w1, #0x8                // =8
     10c:      	blr	x9
     110:      	ldr	x8, [sp, #0x20]
     114:      	cbz	x8, 0x540 <generic_fentry_event+0x540>
     118:      	cmp	w25, #0xb
     11c:      	b.hi	0x540 <generic_fentry_event+0x540>
     120:      	ubfiz	x9, x25, #3, #32
     124:      	mov	w10, #0x8               // =8
     128:      	mov	w11, #0x71              // =113
     12c:      	add	x12, sp, #0x38
     130:      	add	x0, sp, #0x38
     134:      	mov	w1, #0x8                // =8
     138:      	add	x8, x8, x9
     13c:      	ldr	x8, [sp, #0x20]
     140:      	add	x2, x8, x9
     144:      	blr	x11
     148:      	ldr	x8, [sp, #0x38]
     14c:      	cbz	x8, 0x540 <generic_fentry_event+0x540>
     150:      	mov	w9, #0x8                // =8
     154:      	mov	w10, #0x71              // =113
     158:      	add	x11, sp, #0x88
     15c:      	ldr	x2, [sp, #0x38]
     160:      	add	x0, sp, #0x88
     164:      	mov	w1, #0x8                // =8
     168:      	blr	x10
     16c:      	ldr	x8, [sp, #0x88]
     170:      	cbz	x8, 0x540 <generic_fentry_event+0x540>
     174:      	str	xzr, [sp, #0x38]
     178:      	add	x2, x8, #0x100
     17c:      	mov	w8, #0x8                // =8
     180:      	mov	w9, #0x71               // =113
     184:      	add	x10, sp, #0x38
     188:      	add	x0, sp, #0x38
     18c:      	mov	w1, #0x8                // =8
     190:      	blr	x9
     194:      	ldr	x8, [sp, #0x38]
     198:      	str	xzr, [sp, #0x38]
     19c:      	cbz	x8, 0x1cc <generic_fentry_event+0x1cc>
     1a0:      	add	x2, x8, #0x60
     1a4:      	mov	w8, #0x8                // =8
     1a8:      	mov	w9, #0x71               // =113
     1ac:      	add	x10, sp, #0x38
     1b0:      	add	x0, sp, #0x38
     1b4:      	mov	w1, #0x8                // =8
     1b8:      	blr	x9
     1bc:      	ldr	x0, [sp, #0x38]
     1c0:      	str	x0, [sp, #0x30]
     1c4:      	cbnz	x0, 0x1d8 <generic_fentry_event+0x1d8>
     1c8:      	b	0x540 <generic_fentry_event+0x540>
     1cc:      	mov	x0, xzr
     1d0:      	str	xzr, [sp, #0x30]
     1d4:      	cbz	xzr, 0x540 <generic_fentry_event+0x540>
     1d8:      	str	x0, [sp, #0x38]
     1dc:      	adrp	x0, 0x0 <generic_fentry_event>
     1e0:      	mov	w8, #0x1                // =1
     1e4:      	add	x9, sp, #0x38
     1e8:      	ldr	x0, [x0]
     1ec:      	add	x1, sp, #0x38
     1f0:      	blr	x8
     1f4:      	cbz	x0, 0x204 <generic_fentry_event+0x204>
     1f8:      	ldr	x8, [x0]
     1fc:      	cbz	x8, 0x204 <generic_fentry_event+0x204>
     200:      	str	x8, [sp, #0x30]
     204:      	mov	w8, #0x1                // =1
     208:      	add	x9, sp, #0x30
     20c:      	add	x1, sp, #0x30
     210:      	mov	x0, x23
     214:      	blr	x8
     218:      	mov	x8, x0
     21c:      	mov	x0, x24
     220:      	cbz	x8, 0x55c <generic_fentry_event+0x55c>
     224:      	ldr	w9, [x0]
     228:      	mov	w8, #0x6420             // =25632
     22c:      	stur	xzr, [x21, #0x4]
     230:      	str	xzr, [x20, #0x5eb8]
     234:      	str	xzr, [x20, #0x5ec0]
     238:      	str	wzr, [x20, x8]
     23c:      	mov	w8, #0x23               // =35
     240:      	str	xzr, [x20, #0x5ec8]
     244:      	str	xzr, [x20, #0x5ed0]
     248:      	str	xzr, [x20, #0x5ed8]
     24c:      	stp	x9, xzr, [x20, #0x60]
     250:      	mov	w9, #0x5eb8             // =24248
     254:      	add	x9, x20, x9
     258:      	strb	wzr, [x9, #0x28]
     25c:      	blr	x8
     260:      	add	x2, x0, #0xb50
     264:      	mov	w25, #0x8               // =8
     268:      	add	x8, sp, #0x88
     26c:      	mov	w9, #0x4                // =4
     270:      	mov	x22, x0
     274:      	add	x0, sp, #0x88
     278:      	mov	w1, #0x8                // =8
     27c:      	add	x23, x20, #0x20
     280:      	mov	w24, #0x4               // =4
     284:      	blr	x9
     288:      	ldr	x8, [sp, #0x88]
     28c:      	mov	w9, #0x48               // =72
     290:      	add	x10, sp, #0x38
     294:      	mov	w11, #0x4               // =4
     298:      	ldr	x2, [sp, #0x88]
     29c:      	add	x0, sp, #0x38
     2a0:      	mov	w1, #0x48               // =72
     2a4:      	blr	x11
     2a8:      	ldr	x8, [sp, #0x40]
     2ac:      	mov	w9, #0x4                // =4
     2b0:      	mov	x0, x23
     2b4:      	mov	w1, #0x4                // =4
     2b8:      	add	x8, x8, #0x218
     2bc:      	ldr	x8, [sp, #0x40]
     2c0:      	add	x2, x8, #0x218
     2c4:      	blr	x9
     2c8:      	ldr	x8, [sp, #0x48]
     2cc:      	add	x0, x20, #0x24
     2d0:      	mov	w9, #0x4                // =4
     2d4:      	mov	w1, #0x4                // =4
     2d8:      	add	x8, x8, #0x4d8
     2dc:      	ldr	x8, [sp, #0x48]
     2e0:      	add	x2, x8, #0x4d8
     2e4:      	blr	x9
     2e8:      	ldr	x8, [sp, #0x50]
     2ec:      	add	x0, x20, #0x28
     2f0:      	mov	w9, #0x4                // =4
     2f4:      	mov	w1, #0x4                // =4
     2f8:      	add	x8, x8, #0x58
     2fc:      	ldr	x8, [sp, #0x50]
     300:      	add	x2, x8, #0x58
     304:      	blr	x9
     308:      	str	xzr, [sp, #0x30]
     30c:      	add	x2, x22, #0x938
     310:      	add	x8, sp, #0x30
     314:      	add	x0, sp, #0x30
     318:      	mov	w1, #0x8                // =8
     31c:      	blr	x24
     320:      	ldr	x8, [sp, #0x30]
     324:      	cbz	x8, 0x3a8 <generic_fentry_event+0x3a8>
     328:      	str	wzr, [sp, #0x10]
     32c:      	add	x8, x8, #0x4
     330:      	add	x9, sp, #0x10
     334:      	mov	w10, #0x4               // =4
     338:      	add	x0, sp, #0x10
     33c:      	mov	w1, #0x4                // =4
     340:      	mov	w23, #0x4               // =4
     344:      	ldr	x8, [sp, #0x30]
     348:      	add	x2, x8, #0x4
     34c:      	blr	x10
     350:      	ldr	x8, [sp, #0x30]
     354:      	ldrsw	x9, [sp, #0x10]
     358:      	add	x10, sp, #0x20
     35c:      	mov	w11, #0x4               // =4
     360:      	add	x0, sp, #0x20
     364:      	mov	w1, #0x10               // =16
     368:      	add	x8, x8, x9, lsl #4
     36c:      	mov	w9, #0x10               // =16
     370:      	add	x8, x8, #0x80
     374:      	ldr	x8, [sp, #0x30]
     378:      	ldrsw	x9, [sp, #0x10]
     37c:      	add	x8, x8, x9, lsl #4
     380:      	add	x2, x8, #0x80
     384:      	blr	x11
     388:      	ldr	x8, [sp, #0x28]
     38c:      	add	x0, x20, #0x2c
     390:      	mov	w1, #0x4                // =4
     394:      	add	x8, x8, #0x158
     398:      	ldr	x8, [sp, #0x28]
     39c:      	add	x2, x8, #0x158
     3a0:      	blr	x23
     3a4:      	b	0x3ac <generic_fentry_event+0x3ac>
     3a8:      	str	wzr, [x20, #0x2c]
     3ac:      	ldr	x8, [sp, #0x58]
     3b0:      	add	x0, x20, #0x30
     3b4:      	mov	w9, #0x4                // =4
     3b8:      	mov	w1, #0x4                // =4
     3bc:      	mov	w24, #0x4               // =4
     3c0:      	add	x8, x8, #0x158
     3c4:      	ldr	x8, [sp, #0x58]
     3c8:      	add	x2, x8, #0x158
     3cc:      	blr	x9
     3d0:      	ldr	x8, [sp, #0x60]
     3d4:      	add	x0, x20, #0x34
     3d8:      	mov	w9, #0x4                // =4
     3dc:      	mov	w1, #0x4                // =4
     3e0:      	add	x8, x8, #0x118
     3e4:      	ldr	x8, [sp, #0x60]
     3e8:      	add	x2, x8, #0x118
     3ec:      	blr	x9
     3f0:      	ldr	x8, [sp, #0x68]
     3f4:      	add	x0, x20, #0x38
     3f8:      	mov	w9, #0x4                // =4
     3fc:      	mov	w1, #0x4                // =4
     400:      	add	x8, x8, #0x98
     404:      	ldr	x8, [sp, #0x68]
     408:      	add	x2, x8, #0x98
     40c:      	blr	x9
     410:      	ldr	x8, [sp, #0x70]
     414:      	add	x0, x20, #0x3c
     418:      	mov	w9, #0x4                // =4
     41c:      	mov	w1, #0x4                // =4
     420:      	add	x8, x8, #0x98
     424:      	ldr	x8, [sp, #0x70]
     428:      	add	x2, x8, #0x98
     42c:      	blr	x9
     430:      	ldr	x8, [sp, #0x78]
     434:      	add	x0, x20, #0x40
     438:      	mov	w9, #0x4                // =4
     43c:      	mov	w1, #0x4                // =4
     440:      	add	x8, x8, #0x58
     444:      	ldr	x8, [sp, #0x78]
     448:      	add	x2, x8, #0x58
     44c:      	blr	x9
     450:      	str	xzr, [sp, #0x20]
     454:      	str	xzr, [sp, #0x30]
     458:      	add	x22, x22, #0xae0
     45c:      	mov	w25, #0x8               // =8
     460:      	add	x8, sp, #0x20
     464:      	mov	w9, #0x4                // =4
     468:      	add	x0, sp, #0x20
     46c:      	mov	w1, #0x8                // =8
     470:      	mov	x2, x22
     474:      	blr	x9
     478:      	ldr	x8, [sp, #0x20]
     47c:      	add	x9, sp, #0x30
     480:      	mov	w10, #0x4               // =4
     484:      	add	x0, sp, #0x30
     488:      	mov	w1, #0x8                // =8
     48c:      	add	x8, x8, #0x90
     490:      	ldr	x8, [sp, #0x20]
     494:      	add	x2, x8, #0x90
     498:      	blr	x10
     49c:      	ldr	x8, [sp, #0x30]
     4a0:      	add	x0, x20, #0x44
     4a4:      	mov	w9, #0x4                // =4
     4a8:      	mov	w1, #0x4                // =4
     4ac:      	add	x8, x8, #0x158
     4b0:      	ldr	x8, [sp, #0x30]
     4b4:      	add	x2, x8, #0x158
     4b8:      	blr	x9
     4bc:      	add	x8, sp, #0x38
     4c0:      	mov	w9, #0x4                // =4
     4c4:      	add	x0, sp, #0x38
     4c8:      	mov	w1, #0x8                // =8
     4cc:      	mov	x2, x22
     4d0:      	add	x23, x20, #0x48
     4d4:      	blr	x9
     4d8:      	ldr	x22, [sp, #0x38]
     4dc:      	add	x0, x20, #0x50
     4e0:      	mov	w8, #0x4                // =4
     4e4:      	mov	w1, #0x8                // =8
     4e8:      	add	x2, x22, #0x40
     4ec:      	blr	x8
     4f0:      	add	x0, x20, #0x58
     4f4:      	add	x2, x22, #0x30
     4f8:      	mov	w8, #0x4                // =4
     4fc:      	mov	w1, #0x8                // =8
     500:      	blr	x8
     504:      	add	x2, x22, #0x38
     508:      	mov	x0, x23
     50c:      	mov	w1, #0x8                // =8
     510:      	blr	x24
     514:      	strb	wzr, [x21, #0x10]
     518:      	strb	wzr, [x20, #0x1]
     51c:      	adrp	x1, 0x0 <generic_fentry_event>
     520:      	mov	w8, #0x2                // =2
     524:      	mov	w9, #0xc                // =12
     528:      	mov	x0, x19
     52c:      	str	xzr, [x20, #0x5ee8]
     530:      	str	xzr, [x20, #0x5ef0]
     534:      	ldr	x1, [x1]
     538:      	mov	w2, #0x2                // =2
     53c:      	blr	x9
     540:      	ldp	x20, x19, [sp, #0xc0]
     544:      	mov	w0, wzr
     548:      	ldp	x22, x21, [sp, #0xb0]
     54c:      	ldp	x24, x23, [sp, #0xa0]
     550:      	ldp	x30, x25, [sp, #0x90]
     554:      	add	sp, sp, #0xd0
     558:      	ret
     55c:      	mov	x8, #-0x1               // =-1
     560:      	mov	w9, #0x1                // =1
     564:      	add	x1, sp, #0x10
     568:      	str	x8, [sp, #0x10]
     56c:      	add	x8, sp, #0x10
     570:      	mov	x0, x23
     574:      	mov	w25, #0x1               // =1
     578:      	blr	x9
     57c:      	cbz	x0, 0x540 <generic_fentry_event+0x540>
     580:      	str	w25, [sp, #0x1c]
     584:      	add	x8, sp, #0x1c
     588:      	add	x1, sp, #0x1c
     58c:      	mov	x0, x22
     590:      	blr	x25
     594:      	cbz	x0, 0x540 <generic_fentry_event+0x540>
     598:      	mov	w8, #0x1                // =1
     59c:      	add	x9, sp, #0x30
     5a0:      	add	x1, sp, #0x30
     5a4:      	blr	x8
     5a8:      	mov	x8, x0
     5ac:      	mov	x0, x24
     5b0:      	cbnz	x8, 0x540 <generic_fentry_event+0x540>
     5b4:      	b	0x224 <generic_fentry_event+0x224>
