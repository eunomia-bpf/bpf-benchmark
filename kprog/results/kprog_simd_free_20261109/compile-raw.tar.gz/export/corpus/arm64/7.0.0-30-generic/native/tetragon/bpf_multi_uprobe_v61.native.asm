
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_multi_uprobe_v61.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <read_reg>:
       0:      	ror	w9, w1, #0x3
       4:      	mov	x8, xzr
       8:      	cmp	w9, #0xf
       c:      	b.le	0x48 <read_reg+0x48>
      10:      	cmp	w9, #0x17
      14:      	b.le	0x9c <read_reg+0x9c>
      18:      	cmp	w9, #0x1b
      1c:      	b.le	0xc4 <read_reg+0xc4>
      20:      	cmp	w9, #0x1d
      24:      	b.le	0x15c <read_reg+0x15c>
      28:      	cmp	w9, #0x1e
      2c:      	b.eq	0x27c <read_reg+0x27c>
      30:      	cmp	w9, #0x20
      34:      	b.eq	0x21c <read_reg+0x21c>
      38:      	cmp	w9, #0x1f
      3c:      	b.ne	0x290 <read_reg+0x290>
      40:      	add	x0, x0, #0xf8
      44:      	b	0x280 <read_reg+0x280>
      48:      	cmp	w9, #0x7
      4c:      	b.gt	0x74 <read_reg+0x74>
      50:      	cmp	w9, #0x3
      54:      	b.gt	0xe4 <read_reg+0xe4>
      58:      	cmp	w9, #0x1
      5c:      	b.gt	0x174 <read_reg+0x174>
      60:      	cbz	w9, 0x280 <read_reg+0x280>
      64:      	cmp	w9, #0x1
      68:      	b.ne	0x290 <read_reg+0x290>
      6c:      	add	x0, x0, #0x8
      70:      	b	0x280 <read_reg+0x280>
      74:      	cmp	w9, #0xb
      78:      	b.gt	0x104 <read_reg+0x104>
      7c:      	cmp	w9, #0x9
      80:      	b.gt	0x18c <read_reg+0x18c>
      84:      	cmp	w9, #0x8
      88:      	b.eq	0x224 <read_reg+0x224>
      8c:      	cmp	w9, #0x9
      90:      	b.ne	0x290 <read_reg+0x290>
      94:      	add	x0, x0, #0x48
      98:      	b	0x280 <read_reg+0x280>
      9c:      	cmp	w9, #0x13
      a0:      	b.gt	0x124 <read_reg+0x124>
      a4:      	cmp	w9, #0x11
      a8:      	b.gt	0x1d4 <read_reg+0x1d4>
      ac:      	cmp	w9, #0x10
      b0:      	b.eq	0x25c <read_reg+0x25c>
      b4:      	cmp	w9, #0x11
      b8:      	b.ne	0x290 <read_reg+0x290>
      bc:      	add	x0, x0, #0x88
      c0:      	b	0x280 <read_reg+0x280>
      c4:      	cmp	w9, #0x19
      c8:      	b.gt	0x144 <read_reg+0x144>
      cc:      	cmp	w9, #0x18
      d0:      	b.eq	0x204 <read_reg+0x204>
      d4:      	cmp	w9, #0x19
      d8:      	b.ne	0x290 <read_reg+0x290>
      dc:      	add	x0, x0, #0xc8
      e0:      	b	0x280 <read_reg+0x280>
      e4:      	cmp	w9, #0x5
      e8:      	b.gt	0x1a4 <read_reg+0x1a4>
      ec:      	cmp	w9, #0x4
      f0:      	b.eq	0x22c <read_reg+0x22c>
      f4:      	cmp	w9, #0x5
      f8:      	b.ne	0x290 <read_reg+0x290>
      fc:      	add	x0, x0, #0x28
     100:      	b	0x280 <read_reg+0x280>
     104:      	cmp	w9, #0xd
     108:      	b.gt	0x1bc <read_reg+0x1bc>
     10c:      	cmp	w9, #0xc
     110:      	b.eq	0x234 <read_reg+0x234>
     114:      	cmp	w9, #0xd
     118:      	b.ne	0x290 <read_reg+0x290>
     11c:      	add	x0, x0, #0x68
     120:      	b	0x280 <read_reg+0x280>
     124:      	cmp	w9, #0x15
     128:      	b.gt	0x1ec <read_reg+0x1ec>
     12c:      	cmp	w9, #0x14
     130:      	b.eq	0x264 <read_reg+0x264>
     134:      	cmp	w9, #0x15
     138:      	b.ne	0x290 <read_reg+0x290>
     13c:      	add	x0, x0, #0xa8
     140:      	b	0x280 <read_reg+0x280>
     144:      	cmp	w9, #0x1a
     148:      	b.eq	0x20c <read_reg+0x20c>
     14c:      	cmp	w9, #0x1b
     150:      	b.ne	0x290 <read_reg+0x290>
     154:      	add	x0, x0, #0xd8
     158:      	b	0x280 <read_reg+0x280>
     15c:      	cmp	w9, #0x1c
     160:      	b.eq	0x214 <read_reg+0x214>
     164:      	cmp	w9, #0x1d
     168:      	b.ne	0x290 <read_reg+0x290>
     16c:      	add	x0, x0, #0xe8
     170:      	b	0x280 <read_reg+0x280>
     174:      	cmp	w9, #0x2
     178:      	b.eq	0x23c <read_reg+0x23c>
     17c:      	cmp	w9, #0x3
     180:      	b.ne	0x290 <read_reg+0x290>
     184:      	add	x0, x0, #0x18
     188:      	b	0x280 <read_reg+0x280>
     18c:      	cmp	w9, #0xa
     190:      	b.eq	0x244 <read_reg+0x244>
     194:      	cmp	w9, #0xb
     198:      	b.ne	0x290 <read_reg+0x290>
     19c:      	add	x0, x0, #0x58
     1a0:      	b	0x280 <read_reg+0x280>
     1a4:      	cmp	w9, #0x6
     1a8:      	b.eq	0x24c <read_reg+0x24c>
     1ac:      	cmp	w9, #0x7
     1b0:      	b.ne	0x290 <read_reg+0x290>
     1b4:      	add	x0, x0, #0x38
     1b8:      	b	0x280 <read_reg+0x280>
     1bc:      	cmp	w9, #0xe
     1c0:      	b.eq	0x254 <read_reg+0x254>
     1c4:      	cmp	w9, #0xf
     1c8:      	b.ne	0x290 <read_reg+0x290>
     1cc:      	add	x0, x0, #0x78
     1d0:      	b	0x280 <read_reg+0x280>
     1d4:      	cmp	w9, #0x12
     1d8:      	b.eq	0x26c <read_reg+0x26c>
     1dc:      	cmp	w9, #0x13
     1e0:      	b.ne	0x290 <read_reg+0x290>
     1e4:      	add	x0, x0, #0x98
     1e8:      	b	0x280 <read_reg+0x280>
     1ec:      	cmp	w9, #0x16
     1f0:      	b.eq	0x274 <read_reg+0x274>
     1f4:      	cmp	w9, #0x17
     1f8:      	b.ne	0x290 <read_reg+0x290>
     1fc:      	add	x0, x0, #0xb8
     200:      	b	0x280 <read_reg+0x280>
     204:      	add	x0, x0, #0xc0
     208:      	b	0x280 <read_reg+0x280>
     20c:      	add	x0, x0, #0xd0
     210:      	b	0x280 <read_reg+0x280>
     214:      	add	x0, x0, #0xe0
     218:      	b	0x280 <read_reg+0x280>
     21c:      	add	x0, x0, #0x100
     220:      	b	0x280 <read_reg+0x280>
     224:      	add	x0, x0, #0x40
     228:      	b	0x280 <read_reg+0x280>
     22c:      	add	x0, x0, #0x20
     230:      	b	0x280 <read_reg+0x280>
     234:      	add	x0, x0, #0x60
     238:      	b	0x280 <read_reg+0x280>
     23c:      	add	x0, x0, #0x10
     240:      	b	0x280 <read_reg+0x280>
     244:      	add	x0, x0, #0x50
     248:      	b	0x280 <read_reg+0x280>
     24c:      	add	x0, x0, #0x30
     250:      	b	0x280 <read_reg+0x280>
     254:      	add	x0, x0, #0x70
     258:      	b	0x280 <read_reg+0x280>
     25c:      	add	x0, x0, #0x80
     260:      	b	0x280 <read_reg+0x280>
     264:      	add	x0, x0, #0xa0
     268:      	b	0x280 <read_reg+0x280>
     26c:      	add	x0, x0, #0x90
     270:      	b	0x280 <read_reg+0x280>
     274:      	add	x0, x0, #0xb0
     278:      	b	0x280 <read_reg+0x280>
     27c:      	add	x0, x0, #0xf0
     280:      	ldr	x8, [x0]
     284:      	mov	x9, #-0x1               // =-1
     288:      	lsr	x9, x9, x2
     28c:      	and	x8, x8, x9
     290:      	mov	x0, x8
     294:      	ret
     298:      	nop
     29c:      	nop

00000000000002a0 <extract_arg_depth>:
     2a0:      	cmp	w0, #0x9
     2a4:      	b.ls	0x2b0 <extract_arg_depth+0x10>
     2a8:      	mov	w0, #0x1                // =1
     2ac:      	ret
     2b0:      	str	x30, [sp, #-0x20]!
     2b4:      	stp	x20, x19, [sp, #0x10]
     2b8:      	ldr	x8, [x1]
     2bc:      	add	x9, x8, w0, uxtw #3
     2c0:      	ldrh	w9, [x9, #0x6]
     2c4:      	cbz	w9, 0x354 <extract_arg_depth+0xb4>
     2c8:      	mov	w9, w0
     2cc:      	add	x10, x8, x9, lsl #3
     2d0:      	ldr	x8, [x1, #0x8]
     2d4:      	ldr	w11, [x10]
     2d8:      	ldrh	w10, [x10, #0x4]
     2dc:      	ldr	x9, [x8]
     2e0:      	add	x9, x9, x11
     2e4:      	str	x9, [x8]
     2e8:      	cbz	w10, 0x318 <extract_arg_depth+0x78>
     2ec:      	ldrb	w10, [x1, #0x10]
     2f0:      	mov	w19, w0
     2f4:      	cbz	w10, 0x328 <extract_arg_depth+0x88>
     2f8:      	mov	w10, #0x8               // =8
     2fc:      	mov	w11, #0x94              // =148
     300:      	ldr	x0, [x1, #0x8]
     304:      	mov	x20, x1
     308:      	mov	w1, #0x8                // =8
     30c:      	ldr	x2, [x0]
     310:      	blr	x11
     314:      	tbnz	w0, #0x1f, 0x348 <extract_arg_depth+0xa8>
     318:      	mov	w0, wzr
     31c:      	ldp	x20, x19, [sp, #0x10]
     320:      	ldr	x30, [sp], #0x20
     324:      	ret
     328:      	mov	w10, #0x8               // =8
     32c:      	mov	w11, #0x4               // =4
     330:      	ldr	x0, [x1, #0x8]
     334:      	mov	x20, x1
     338:      	mov	w1, #0x8                // =8
     33c:      	ldr	x2, [x0]
     340:      	blr	x11
     344:      	tbz	w0, #0x1f, 0x318 <extract_arg_depth+0x78>
     348:      	ldr	x9, [x20, #0x18]
     34c:      	add	w8, w19, #0x1
     350:      	str	w8, [x9]
     354:      	mov	w0, #0x1                // =1
     358:      	ldp	x20, x19, [sp, #0x10]
     35c:      	ldr	x30, [sp], #0x20
     360:      	ret
     364:      	nop
     368:      	nop
     36c:      	nop

0000000000000370 <filter_64ty>:
     370:      	str	x30, [sp, #-0x10]!
     374:      	mov	x8, x0
     378:      	mov	x0, xzr
     37c:      	ldr	w9, [x8, #0x4]
     380:      	cmp	w9, #0x20
     384:      	b.hi	0x3e4 <filter_64ty+0x74>
     388:      	mov	w10, #0x1               // =1
     38c:      	mov	w11, #0x101e            // =4126
     390:      	lsl	x10, x10, x9
     394:      	tst	x10, x11
     398:      	b.eq	0x3ac <filter_64ty+0x3c>
     39c:      	mov	x0, x8
     3a0:      	bl	0x570 <filter_64ty_selector_val>
     3a4:      	ldr	x30, [sp], #0x10
     3a8:      	ret
     3ac:      	mov	w10, #0x1               // =1
     3b0:      	lsl	x10, x10, x9
     3b4:      	tst	x10, #0xc00
     3b8:      	b.ne	0x3dc <filter_64ty+0x6c>
     3bc:      	mov	w10, #0x1               // =1
     3c0:      	lsl	x9, x10, x9
     3c4:      	tst	x9, #0x180000000
     3c8:      	b.eq	0x3e4 <filter_64ty+0x74>
     3cc:      	mov	x0, x8
     3d0:      	bl	0x970 <filter_64ty_range>
     3d4:      	ldr	x30, [sp], #0x10
     3d8:      	ret
     3dc:      	mov	x0, x8
     3e0:      	bl	0x8d0 <filter_64ty_map>
     3e4:      	ldr	x30, [sp], #0x10
     3e8:      	ret
     3ec:      	nop

00000000000003f0 <filter_32ty>:
     3f0:      	str	x30, [sp, #-0x10]!
     3f4:      	mov	x8, x0
     3f8:      	mov	x0, xzr
     3fc:      	ldr	w9, [x8, #0x4]
     400:      	cmp	w9, #0x20
     404:      	b.hi	0x464 <filter_32ty+0x74>
     408:      	mov	w10, #0x1               // =1
     40c:      	mov	w11, #0x101e            // =4126
     410:      	lsl	x10, x10, x9
     414:      	tst	x10, x11
     418:      	b.eq	0x42c <filter_32ty+0x3c>
     41c:      	mov	x0, x8
     420:      	bl	0xbc0 <filter_32ty_selector_val>
     424:      	ldr	x30, [sp], #0x10
     428:      	ret
     42c:      	mov	w10, #0x1               // =1
     430:      	lsl	x10, x10, x9
     434:      	tst	x10, #0xc00
     438:      	b.ne	0x45c <filter_32ty+0x6c>
     43c:      	mov	w10, #0x1               // =1
     440:      	lsl	x9, x10, x9
     444:      	tst	x9, #0x180000000
     448:      	b.eq	0x464 <filter_32ty+0x74>
     44c:      	mov	x0, x8
     450:      	bl	0xfe0 <filter_32ty_range>
     454:      	ldr	x30, [sp], #0x10
     458:      	ret
     45c:      	mov	x0, x8
     460:      	bl	0xf20 <filter_32ty_map>
     464:      	ldr	x30, [sp], #0x10
     468:      	ret
     46c:      	nop

0000000000000470 <filter_16ty>:
     470:      	str	x30, [sp, #-0x10]!
     474:      	mov	x8, x0
     478:      	mov	x0, xzr
     47c:      	ldr	w9, [x8, #0x4]
     480:      	cmp	w9, #0x20
     484:      	b.hi	0x4e4 <filter_16ty+0x74>
     488:      	mov	w10, #0x1               // =1
     48c:      	mov	w11, #0x101e            // =4126
     490:      	lsl	x10, x10, x9
     494:      	tst	x10, x11
     498:      	b.eq	0x4ac <filter_16ty+0x3c>
     49c:      	mov	x0, x8
     4a0:      	bl	0x1230 <filter_16ty_selector_val>
     4a4:      	ldr	x30, [sp], #0x10
     4a8:      	ret
     4ac:      	mov	w10, #0x1               // =1
     4b0:      	lsl	x10, x10, x9
     4b4:      	tst	x10, #0xc00
     4b8:      	b.ne	0x4dc <filter_16ty+0x6c>
     4bc:      	mov	w10, #0x1               // =1
     4c0:      	lsl	x9, x10, x9
     4c4:      	tst	x9, #0x180000000
     4c8:      	b.eq	0x4e4 <filter_16ty+0x74>
     4cc:      	mov	x0, x8
     4d0:      	bl	0x1650 <filter_16ty_range>
     4d4:      	ldr	x30, [sp], #0x10
     4d8:      	ret
     4dc:      	mov	x0, x8
     4e0:      	bl	0x1590 <filter_16ty_map>
     4e4:      	ldr	x30, [sp], #0x10
     4e8:      	ret
     4ec:      	nop

00000000000004f0 <filter_8ty>:
     4f0:      	str	x30, [sp, #-0x10]!
     4f4:      	mov	x8, x0
     4f8:      	mov	x0, xzr
     4fc:      	ldr	w9, [x8, #0x4]
     500:      	cmp	w9, #0x20
     504:      	b.hi	0x564 <filter_8ty+0x74>
     508:      	mov	w10, #0x1               // =1
     50c:      	mov	w11, #0x101e            // =4126
     510:      	lsl	x10, x10, x9
     514:      	tst	x10, x11
     518:      	b.eq	0x52c <filter_8ty+0x3c>
     51c:      	mov	x0, x8
     520:      	bl	0x18a0 <filter_8ty_selector_val>
     524:      	ldr	x30, [sp], #0x10
     528:      	ret
     52c:      	mov	w10, #0x1               // =1
     530:      	lsl	x10, x10, x9
     534:      	tst	x10, #0xc00
     538:      	b.ne	0x55c <filter_8ty+0x6c>
     53c:      	mov	w10, #0x1               // =1
     540:      	lsl	x9, x10, x9
     544:      	tst	x9, #0x180000000
     548:      	b.eq	0x564 <filter_8ty+0x74>
     54c:      	mov	x0, x8
     550:      	bl	0x1cc0 <filter_8ty_range>
     554:      	ldr	x30, [sp], #0x10
     558:      	ret
     55c:      	mov	x0, x8
     560:      	bl	0x1c00 <filter_8ty_map>
     564:      	ldr	x30, [sp], #0x10
     568:      	ret
     56c:      	nop

0000000000000570 <filter_64ty_selector_val>:
     570:      	ldr	w8, [x0, #0x4]
     574:      	cmp	w8, #0x25
     578:      	b.hi	0x5ec <filter_64ty_selector_val+0x7c>
     57c:      	mov	x10, #0x40              // =64
     580:      	mov	w9, #0x1                // =1
     584:      	movk	x10, #0xc00, lsl #16
     588:      	lsl	x9, x9, x8
     58c:      	movk	x10, #0x20, lsl #32
     590:      	tst	x9, x10
     594:      	b.eq	0x5a0 <filter_64ty_selector_val+0x30>
     598:      	mov	w0, #0x1                // =1
     59c:      	ret
     5a0:      	mov	w9, #0x1                // =1
     5a4:      	lsl	x9, x9, x8
     5a8:      	tst	x9, #0x18
     5ac:      	b.eq	0x5cc <filter_64ty_selector_val+0x5c>
     5b0:      	ldr	x9, [x1]
     5b4:      	ldr	x10, [x0, #0x10]
     5b8:      	cmp	x9, x10
     5bc:      	b.ne	0x66c <filter_64ty_selector_val+0xfc>
     5c0:      	cmp	w8, #0x3
     5c4:      	cset	w0, eq
     5c8:      	ret
     5cc:      	cmp	x8, #0xc
     5d0:      	b.ne	0x5ec <filter_64ty_selector_val+0x7c>
     5d4:      	ldr	x8, [x1]
     5d8:      	ldr	x9, [x0, #0x10]
     5dc:      	tst	x8, x9
     5e0:      	b.eq	0x718 <filter_64ty_selector_val+0x1a8>
     5e4:      	mov	w0, #0x1                // =1
     5e8:      	ret
     5ec:      	cmp	w8, #0x1
     5f0:      	b.eq	0x634 <filter_64ty_selector_val+0xc4>
     5f4:      	cmp	w8, #0x2
     5f8:      	b.ne	0x8c0 <filter_64ty_selector_val+0x350>
     5fc:      	ldr	w8, [x0, #0xc]
     600:      	cmp	w8, #0xc
     604:      	b.hi	0x750 <filter_64ty_selector_val+0x1e0>
     608:      	mov	w9, #0x1                // =1
     60c:      	lsl	w8, w9, w8
     610:      	mov	w9, #0x1402             // =5122
     614:      	tst	w8, w9
     618:      	b.eq	0x750 <filter_64ty_selector_val+0x1e0>
     61c:      	ldr	x8, [x1]
     620:      	ldr	x9, [x0, #0x10]
     624:      	cmp	x8, x9
     628:      	b.ge	0x6f8 <filter_64ty_selector_val+0x188>
     62c:      	mov	w0, #0x1                // =1
     630:      	ret
     634:      	ldr	w8, [x0, #0xc]
     638:      	cmp	w8, #0xc
     63c:      	b.hi	0x738 <filter_64ty_selector_val+0x1c8>
     640:      	mov	w9, #0x1                // =1
     644:      	lsl	w8, w9, w8
     648:      	mov	w9, #0x1402             // =5122
     64c:      	tst	w8, w9
     650:      	b.eq	0x738 <filter_64ty_selector_val+0x1c8>
     654:      	ldr	x8, [x1]
     658:      	ldr	x9, [x0, #0x10]
     65c:      	cmp	x8, x9
     660:      	b.le	0x6d8 <filter_64ty_selector_val+0x168>
     664:      	mov	w0, #0x1                // =1
     668:      	ret
     66c:      	ldr	w10, [x0, #0x8]
     670:      	cmp	w10, #0x11
     674:      	b.lo	0x6ac <filter_64ty_selector_val+0x13c>
     678:      	ldr	x11, [x0, #0x18]
     67c:      	cmp	x9, x11
     680:      	b.eq	0x5c0 <filter_64ty_selector_val+0x50>
     684:      	cmp	w10, #0x19
     688:      	b.lo	0x6ac <filter_64ty_selector_val+0x13c>
     68c:      	ldr	x11, [x0, #0x20]
     690:      	cmp	x9, x11
     694:      	b.eq	0x5c0 <filter_64ty_selector_val+0x50>
     698:      	cmp	w10, #0x21
     69c:      	b.lo	0x6ac <filter_64ty_selector_val+0x13c>
     6a0:      	ldr	x10, [x0, #0x28]
     6a4:      	cmp	x9, x10
     6a8:      	b.eq	0x5c0 <filter_64ty_selector_val+0x50>
     6ac:      	cmp	w8, #0x25
     6b0:      	b.hi	0x8c0 <filter_64ty_selector_val+0x350>
     6b4:      	mov	w9, #0x1                // =1
     6b8:      	lsl	x8, x9, x8
     6bc:      	mov	x9, #0x50               // =80
     6c0:      	movk	x9, #0xc00, lsl #16
     6c4:      	movk	x9, #0x20, lsl #32
     6c8:      	tst	x8, x9
     6cc:      	b.eq	0x8c0 <filter_64ty_selector_val+0x350>
     6d0:      	mov	w0, #0x1                // =1
     6d4:      	ret
     6d8:      	ldr	w9, [x0, #0x8]
     6dc:      	cmp	w9, #0x11
     6e0:      	b.lo	0x8c0 <filter_64ty_selector_val+0x350>
     6e4:      	ldr	x10, [x0, #0x18]
     6e8:      	cmp	x8, x10
     6ec:      	b.le	0x7a8 <filter_64ty_selector_val+0x238>
     6f0:      	mov	w0, #0x1                // =1
     6f4:      	ret
     6f8:      	ldr	w9, [x0, #0x8]
     6fc:      	cmp	w9, #0x11
     700:      	b.lo	0x8c0 <filter_64ty_selector_val+0x350>
     704:      	ldr	x10, [x0, #0x18]
     708:      	cmp	x8, x10
     70c:      	b.ge	0x7c4 <filter_64ty_selector_val+0x254>
     710:      	mov	w0, #0x1                // =1
     714:      	ret
     718:      	ldr	w9, [x0, #0x8]
     71c:      	cmp	w9, #0x11
     720:      	b.lo	0x8c0 <filter_64ty_selector_val+0x350>
     724:      	ldr	x10, [x0, #0x18]
     728:      	tst	x8, x10
     72c:      	b.eq	0x7e0 <filter_64ty_selector_val+0x270>
     730:      	mov	w0, #0x1                // =1
     734:      	ret
     738:      	ldr	x8, [x1]
     73c:      	ldr	x9, [x0, #0x10]
     740:      	cmp	x8, x9
     744:      	b.ls	0x768 <filter_64ty_selector_val+0x1f8>
     748:      	mov	w0, #0x1                // =1
     74c:      	ret
     750:      	ldr	x8, [x1]
     754:      	ldr	x9, [x0, #0x10]
     758:      	cmp	x8, x9
     75c:      	b.hs	0x788 <filter_64ty_selector_val+0x218>
     760:      	mov	w0, #0x1                // =1
     764:      	ret
     768:      	ldr	w9, [x0, #0x8]
     76c:      	cmp	w9, #0x11
     770:      	b.lo	0x8c0 <filter_64ty_selector_val+0x350>
     774:      	ldr	x10, [x0, #0x18]
     778:      	cmp	x8, x10
     77c:      	b.ls	0x7fc <filter_64ty_selector_val+0x28c>
     780:      	mov	w0, #0x1                // =1
     784:      	ret
     788:      	ldr	w9, [x0, #0x8]
     78c:      	cmp	w9, #0x11
     790:      	b.lo	0x8c0 <filter_64ty_selector_val+0x350>
     794:      	ldr	x10, [x0, #0x18]
     798:      	cmp	x8, x10
     79c:      	b.hs	0x818 <filter_64ty_selector_val+0x2a8>
     7a0:      	mov	w0, #0x1                // =1
     7a4:      	ret
     7a8:      	cmp	w9, #0x19
     7ac:      	b.lo	0x8c0 <filter_64ty_selector_val+0x350>
     7b0:      	ldr	x10, [x0, #0x20]
     7b4:      	cmp	x8, x10
     7b8:      	b.le	0x834 <filter_64ty_selector_val+0x2c4>
     7bc:      	mov	w0, #0x1                // =1
     7c0:      	ret
     7c4:      	cmp	w9, #0x19
     7c8:      	b.lo	0x8c0 <filter_64ty_selector_val+0x350>
     7cc:      	ldr	x10, [x0, #0x20]
     7d0:      	cmp	x8, x10
     7d4:      	b.ge	0x850 <filter_64ty_selector_val+0x2e0>
     7d8:      	mov	w0, #0x1                // =1
     7dc:      	ret
     7e0:      	cmp	w9, #0x19
     7e4:      	b.lo	0x8c0 <filter_64ty_selector_val+0x350>
     7e8:      	ldr	x10, [x0, #0x20]
     7ec:      	tst	x8, x10
     7f0:      	b.eq	0x86c <filter_64ty_selector_val+0x2fc>
     7f4:      	mov	w0, #0x1                // =1
     7f8:      	ret
     7fc:      	cmp	w9, #0x19
     800:      	b.lo	0x8c0 <filter_64ty_selector_val+0x350>
     804:      	ldr	x10, [x0, #0x20]
     808:      	cmp	x8, x10
     80c:      	b.ls	0x888 <filter_64ty_selector_val+0x318>
     810:      	mov	w0, #0x1                // =1
     814:      	ret
     818:      	cmp	w9, #0x19
     81c:      	b.lo	0x8c0 <filter_64ty_selector_val+0x350>
     820:      	ldr	x10, [x0, #0x20]
     824:      	cmp	x8, x10
     828:      	b.hs	0x8a4 <filter_64ty_selector_val+0x334>
     82c:      	mov	w0, #0x1                // =1
     830:      	ret
     834:      	cmp	w9, #0x21
     838:      	b.lo	0x8c0 <filter_64ty_selector_val+0x350>
     83c:      	ldr	x9, [x0, #0x28]
     840:      	cmp	x8, x9
     844:      	b.le	0x8c0 <filter_64ty_selector_val+0x350>
     848:      	mov	w0, #0x1                // =1
     84c:      	ret
     850:      	cmp	w9, #0x21
     854:      	b.lo	0x8c0 <filter_64ty_selector_val+0x350>
     858:      	ldr	x9, [x0, #0x28]
     85c:      	cmp	x8, x9
     860:      	b.ge	0x8c0 <filter_64ty_selector_val+0x350>
     864:      	mov	w0, #0x1                // =1
     868:      	ret
     86c:      	cmp	w9, #0x21
     870:      	b.lo	0x8c0 <filter_64ty_selector_val+0x350>
     874:      	ldr	x9, [x0, #0x28]
     878:      	tst	x8, x9
     87c:      	b.eq	0x8c0 <filter_64ty_selector_val+0x350>
     880:      	mov	w0, #0x1                // =1
     884:      	ret
     888:      	cmp	w9, #0x21
     88c:      	b.lo	0x8c0 <filter_64ty_selector_val+0x350>
     890:      	ldr	x9, [x0, #0x28]
     894:      	cmp	x8, x9
     898:      	b.ls	0x8c0 <filter_64ty_selector_val+0x350>
     89c:      	mov	w0, #0x1                // =1
     8a0:      	ret
     8a4:      	cmp	w9, #0x21
     8a8:      	b.lo	0x8c0 <filter_64ty_selector_val+0x350>
     8ac:      	ldr	x9, [x0, #0x28]
     8b0:      	cmp	x8, x9
     8b4:      	b.hs	0x8c0 <filter_64ty_selector_val+0x350>
     8b8:      	mov	w0, #0x1                // =1
     8bc:      	ret
     8c0:      	mov	x0, xzr
     8c4:      	ret
     8c8:      	nop
     8cc:      	nop

00000000000008d0 <filter_64ty_map>:
     8d0:      	sub	sp, sp, #0x30
     8d4:      	str	x30, [sp, #0x10]
     8d8:      	stp	x20, x19, [sp, #0x20]
     8dc:      	ldrb	w8, [x0, #0x10]
     8e0:      	mov	x19, x0
     8e4:      	adrp	x0, 0x0 <read_reg>
     8e8:      	add	x9, sp, #0x1c
     8ec:      	str	w8, [sp, #0x1c]
     8f0:      	mov	w8, #0x1                // =1
     8f4:      	mov	x20, x1
     8f8:      	add	x1, sp, #0x1c
     8fc:      	ldr	x0, [x0]
     900:      	blr	x8
     904:      	cbz	x0, 0x954 <filter_64ty_map+0x84>
     908:      	ldr	x8, [x20]
     90c:      	add	x9, sp, #0x8
     910:      	add	x1, sp, #0x8
     914:      	str	x8, [sp, #0x8]
     918:      	mov	w8, #0x1                // =1
     91c:      	blr	x8
     920:      	ldr	w8, [x19, #0x4]
     924:      	cmp	w8, #0xb
     928:      	b.eq	0x940 <filter_64ty_map+0x70>
     92c:      	cmp	w8, #0xa
     930:      	b.ne	0x94c <filter_64ty_map+0x7c>
     934:      	cmp	x0, #0x0
     938:      	cset	w8, ne
     93c:      	b	0x950 <filter_64ty_map+0x80>
     940:      	cmp	x0, #0x0
     944:      	cset	w8, eq
     948:      	b	0x950 <filter_64ty_map+0x80>
     94c:      	mov	w8, wzr
     950:      	mov	w0, w8
     954:      	ldp	x20, x19, [sp, #0x20]
     958:      	ldr	x30, [sp, #0x10]
     95c:      	add	sp, sp, #0x30
     960:      	ret
     964:      	nop
     968:      	nop
     96c:      	nop

0000000000000970 <filter_64ty_range>:
     970:      	ldr	w9, [x0, #0xc]
     974:      	ldr	w8, [x0, #0x4]
     978:      	mov	w10, #0x1               // =1
     97c:      	cmp	w9, #0xc
     980:      	lsl	w9, w10, w9
     984:      	mov	w10, #0x1402            // =5122
     988:      	and	w9, w9, w10
     98c:      	ccmp	w9, #0x0, #0x4, ls
     990:      	b.eq	0xa90 <filter_64ty_range+0x120>
     994:      	ldr	x10, [x1]
     998:      	cmp	w8, #0x1f
     99c:      	b.ne	0xa24 <filter_64ty_range+0xb4>
     9a0:      	ldr	x9, [x0, #0x10]
     9a4:      	cmp	x9, x10
     9a8:      	b.gt	0x9b8 <filter_64ty_range+0x48>
     9ac:      	ldr	x9, [x0, #0x18]
     9b0:      	cmp	x10, x9
     9b4:      	b.le	0xab4 <filter_64ty_range+0x144>
     9b8:      	ldr	w9, [x0, #0x8]
     9bc:      	cmp	w9, #0x19
     9c0:      	b.lo	0xba0 <filter_64ty_range+0x230>
     9c4:      	ldr	x11, [x0, #0x20]
     9c8:      	cmp	x11, x10
     9cc:      	b.gt	0x9dc <filter_64ty_range+0x6c>
     9d0:      	ldr	x11, [x0, #0x28]
     9d4:      	cmp	x10, x11
     9d8:      	b.le	0xab4 <filter_64ty_range+0x144>
     9dc:      	cmp	w9, #0x29
     9e0:      	b.lo	0xba0 <filter_64ty_range+0x230>
     9e4:      	ldr	x11, [x0, #0x30]
     9e8:      	cmp	x11, x10
     9ec:      	b.gt	0x9fc <filter_64ty_range+0x8c>
     9f0:      	ldr	x11, [x0, #0x38]
     9f4:      	cmp	x10, x11
     9f8:      	b.le	0xab4 <filter_64ty_range+0x144>
     9fc:      	cmp	w9, #0x39
     a00:      	b.lo	0xba0 <filter_64ty_range+0x230>
     a04:      	ldr	x11, [x0, #0x40]
     a08:      	mov	w9, wzr
     a0c:      	cmp	x11, x10
     a10:      	b.gt	0xb90 <filter_64ty_range+0x220>
     a14:      	ldr	x11, [x0, #0x48]
     a18:      	cmp	x10, x11
     a1c:      	b.le	0xab4 <filter_64ty_range+0x144>
     a20:      	b	0xb90 <filter_64ty_range+0x220>
     a24:      	ldp	x9, x12, [x0, #0x10]
     a28:      	cmp	x9, x10
     a2c:      	ldr	w11, [x0, #0x8]
     a30:      	ccmp	x10, x12, #0x0, le
     a34:      	cset	w9, le
     a38:      	cmp	w11, #0x19
     a3c:      	b.lo	0xb90 <filter_64ty_range+0x220>
     a40:      	ldp	x12, x13, [x0, #0x20]
     a44:      	cmp	x12, x10
     a48:      	ccmp	x10, x13, #0x0, le
     a4c:      	csinc	w9, w9, wzr, gt
     a50:      	cmp	w11, #0x29
     a54:      	b.lo	0xb90 <filter_64ty_range+0x220>
     a58:      	ldp	x12, x13, [x0, #0x30]
     a5c:      	cmp	x12, x10
     a60:      	ccmp	x10, x13, #0x0, le
     a64:      	csinc	w9, w9, wzr, gt
     a68:      	cmp	w11, #0x39
     a6c:      	b.lo	0xb90 <filter_64ty_range+0x220>
     a70:      	ldp	x11, x12, [x0, #0x40]
     a74:      	cmp	x11, x10
     a78:      	ccmp	x10, x12, #0x0, le
     a7c:      	csinc	w9, w9, wzr, gt
     a80:      	cmp	w8, #0x20
     a84:      	eor	w8, w9, #0x1
     a88:      	csel	w0, wzr, w8, ne
     a8c:      	ret
     a90:      	ldr	x10, [x1]
     a94:      	cmp	w8, #0x1f
     a98:      	b.ne	0xabc <filter_64ty_range+0x14c>
     a9c:      	ldr	x9, [x0, #0x10]
     aa0:      	cmp	x9, x10
     aa4:      	b.hi	0xb28 <filter_64ty_range+0x1b8>
     aa8:      	ldr	x9, [x0, #0x18]
     aac:      	cmp	x10, x9
     ab0:      	b.hi	0xb28 <filter_64ty_range+0x1b8>
     ab4:      	mov	w0, #0x1                // =1
     ab8:      	ret
     abc:      	ldp	x9, x12, [x0, #0x10]
     ac0:      	cmp	x9, x10
     ac4:      	ldr	w11, [x0, #0x8]
     ac8:      	ccmp	x10, x12, #0x2, ls
     acc:      	cset	w9, ls
     ad0:      	cmp	w11, #0x19
     ad4:      	b.lo	0xb90 <filter_64ty_range+0x220>
     ad8:      	ldp	x12, x13, [x0, #0x20]
     adc:      	cmp	x12, x10
     ae0:      	ccmp	x10, x13, #0x2, ls
     ae4:      	csinc	w9, w9, wzr, hi
     ae8:      	cmp	w11, #0x29
     aec:      	b.lo	0xb90 <filter_64ty_range+0x220>
     af0:      	ldp	x12, x13, [x0, #0x30]
     af4:      	cmp	x12, x10
     af8:      	ccmp	x10, x13, #0x2, ls
     afc:      	csinc	w9, w9, wzr, hi
     b00:      	cmp	w11, #0x39
     b04:      	b.lo	0xb90 <filter_64ty_range+0x220>
     b08:      	ldp	x11, x12, [x0, #0x40]
     b0c:      	cmp	x11, x10
     b10:      	ccmp	x10, x12, #0x2, ls
     b14:      	csinc	w9, w9, wzr, hi
     b18:      	cmp	w8, #0x20
     b1c:      	eor	w8, w9, #0x1
     b20:      	csel	w0, wzr, w8, ne
     b24:      	ret
     b28:      	ldr	w9, [x0, #0x8]
     b2c:      	cmp	w9, #0x19
     b30:      	b.lo	0xba0 <filter_64ty_range+0x230>
     b34:      	ldr	x11, [x0, #0x20]
     b38:      	cmp	x11, x10
     b3c:      	b.hi	0xb4c <filter_64ty_range+0x1dc>
     b40:      	ldr	x11, [x0, #0x28]
     b44:      	cmp	x10, x11
     b48:      	b.ls	0xab4 <filter_64ty_range+0x144>
     b4c:      	cmp	w9, #0x29
     b50:      	b.lo	0xba0 <filter_64ty_range+0x230>
     b54:      	ldr	x11, [x0, #0x30]
     b58:      	cmp	x11, x10
     b5c:      	b.hi	0xb6c <filter_64ty_range+0x1fc>
     b60:      	ldr	x11, [x0, #0x38]
     b64:      	cmp	x10, x11
     b68:      	b.ls	0xab4 <filter_64ty_range+0x144>
     b6c:      	cmp	w9, #0x39
     b70:      	b.lo	0xba0 <filter_64ty_range+0x230>
     b74:      	ldr	x11, [x0, #0x40]
     b78:      	mov	w9, wzr
     b7c:      	cmp	x11, x10
     b80:      	b.hi	0xb90 <filter_64ty_range+0x220>
     b84:      	ldr	x11, [x0, #0x48]
     b88:      	cmp	x10, x11
     b8c:      	b.ls	0xab4 <filter_64ty_range+0x144>
     b90:      	cmp	w8, #0x20
     b94:      	eor	w8, w9, #0x1
     b98:      	csel	w0, wzr, w8, ne
     b9c:      	ret
     ba0:      	mov	w9, wzr
     ba4:      	cmp	w8, #0x20
     ba8:      	eor	w8, w9, #0x1
     bac:      	csel	w0, wzr, w8, ne
     bb0:      	ret
     bb4:      	nop
     bb8:      	nop
     bbc:      	nop

0000000000000bc0 <filter_32ty_selector_val>:
     bc0:      	ldr	w8, [x0, #0x4]
     bc4:      	cmp	w8, #0x25
     bc8:      	b.hi	0xc3c <filter_32ty_selector_val+0x7c>
     bcc:      	mov	x10, #0x40              // =64
     bd0:      	mov	w9, #0x1                // =1
     bd4:      	movk	x10, #0xc00, lsl #16
     bd8:      	lsl	x9, x9, x8
     bdc:      	movk	x10, #0x20, lsl #32
     be0:      	tst	x9, x10
     be4:      	b.eq	0xbf0 <filter_32ty_selector_val+0x30>
     be8:      	mov	w0, #0x1                // =1
     bec:      	ret
     bf0:      	mov	w9, #0x1                // =1
     bf4:      	lsl	x9, x9, x8
     bf8:      	tst	x9, #0x18
     bfc:      	b.eq	0xc1c <filter_32ty_selector_val+0x5c>
     c00:      	ldr	w9, [x1]
     c04:      	ldr	w10, [x0, #0x10]
     c08:      	cmp	w9, w10
     c0c:      	b.ne	0xcbc <filter_32ty_selector_val+0xfc>
     c10:      	cmp	w8, #0x3
     c14:      	cset	w0, eq
     c18:      	ret
     c1c:      	cmp	x8, #0xc
     c20:      	b.ne	0xc3c <filter_32ty_selector_val+0x7c>
     c24:      	ldr	w8, [x1]
     c28:      	ldr	w9, [x0, #0x10]
     c2c:      	tst	w8, w9
     c30:      	b.eq	0xd68 <filter_32ty_selector_val+0x1a8>
     c34:      	mov	w0, #0x1                // =1
     c38:      	ret
     c3c:      	cmp	w8, #0x1
     c40:      	b.eq	0xc84 <filter_32ty_selector_val+0xc4>
     c44:      	cmp	w8, #0x2
     c48:      	b.ne	0xf10 <filter_32ty_selector_val+0x350>
     c4c:      	ldr	w8, [x0, #0xc]
     c50:      	cmp	w8, #0xc
     c54:      	b.hi	0xda0 <filter_32ty_selector_val+0x1e0>
     c58:      	mov	w9, #0x1                // =1
     c5c:      	lsl	w8, w9, w8
     c60:      	mov	w9, #0x1402             // =5122
     c64:      	tst	w8, w9
     c68:      	b.eq	0xda0 <filter_32ty_selector_val+0x1e0>
     c6c:      	ldr	w8, [x1]
     c70:      	ldr	w9, [x0, #0x10]
     c74:      	cmp	w8, w9
     c78:      	b.ge	0xd48 <filter_32ty_selector_val+0x188>
     c7c:      	mov	w0, #0x1                // =1
     c80:      	ret
     c84:      	ldr	w8, [x0, #0xc]
     c88:      	cmp	w8, #0xc
     c8c:      	b.hi	0xd88 <filter_32ty_selector_val+0x1c8>
     c90:      	mov	w9, #0x1                // =1
     c94:      	lsl	w8, w9, w8
     c98:      	mov	w9, #0x1402             // =5122
     c9c:      	tst	w8, w9
     ca0:      	b.eq	0xd88 <filter_32ty_selector_val+0x1c8>
     ca4:      	ldr	w8, [x1]
     ca8:      	ldr	w9, [x0, #0x10]
     cac:      	cmp	w8, w9
     cb0:      	b.le	0xd28 <filter_32ty_selector_val+0x168>
     cb4:      	mov	w0, #0x1                // =1
     cb8:      	ret
     cbc:      	ldr	w10, [x0, #0x8]
     cc0:      	cmp	w10, #0xd
     cc4:      	b.lo	0xcfc <filter_32ty_selector_val+0x13c>
     cc8:      	ldr	w11, [x0, #0x14]
     ccc:      	cmp	w9, w11
     cd0:      	b.eq	0xc10 <filter_32ty_selector_val+0x50>
     cd4:      	cmp	w10, #0x11
     cd8:      	b.lo	0xcfc <filter_32ty_selector_val+0x13c>
     cdc:      	ldr	w11, [x0, #0x18]
     ce0:      	cmp	w9, w11
     ce4:      	b.eq	0xc10 <filter_32ty_selector_val+0x50>
     ce8:      	cmp	w10, #0x15
     cec:      	b.lo	0xcfc <filter_32ty_selector_val+0x13c>
     cf0:      	ldr	w10, [x0, #0x1c]
     cf4:      	cmp	w9, w10
     cf8:      	b.eq	0xc10 <filter_32ty_selector_val+0x50>
     cfc:      	cmp	w8, #0x25
     d00:      	b.hi	0xf10 <filter_32ty_selector_val+0x350>
     d04:      	mov	w9, #0x1                // =1
     d08:      	lsl	x8, x9, x8
     d0c:      	mov	x9, #0x50               // =80
     d10:      	movk	x9, #0xc00, lsl #16
     d14:      	movk	x9, #0x20, lsl #32
     d18:      	tst	x8, x9
     d1c:      	b.eq	0xf10 <filter_32ty_selector_val+0x350>
     d20:      	mov	w0, #0x1                // =1
     d24:      	ret
     d28:      	ldr	w9, [x0, #0x8]
     d2c:      	cmp	w9, #0xd
     d30:      	b.lo	0xf10 <filter_32ty_selector_val+0x350>
     d34:      	ldr	w10, [x0, #0x14]
     d38:      	cmp	w8, w10
     d3c:      	b.le	0xdf8 <filter_32ty_selector_val+0x238>
     d40:      	mov	w0, #0x1                // =1
     d44:      	ret
     d48:      	ldr	w9, [x0, #0x8]
     d4c:      	cmp	w9, #0xd
     d50:      	b.lo	0xf10 <filter_32ty_selector_val+0x350>
     d54:      	ldr	w10, [x0, #0x14]
     d58:      	cmp	w8, w10
     d5c:      	b.ge	0xe14 <filter_32ty_selector_val+0x254>
     d60:      	mov	w0, #0x1                // =1
     d64:      	ret
     d68:      	ldr	w9, [x0, #0x8]
     d6c:      	cmp	w9, #0xd
     d70:      	b.lo	0xf10 <filter_32ty_selector_val+0x350>
     d74:      	ldr	w10, [x0, #0x14]
     d78:      	tst	w8, w10
     d7c:      	b.eq	0xe30 <filter_32ty_selector_val+0x270>
     d80:      	mov	w0, #0x1                // =1
     d84:      	ret
     d88:      	ldr	w8, [x1]
     d8c:      	ldr	w9, [x0, #0x10]
     d90:      	cmp	w8, w9
     d94:      	b.ls	0xdb8 <filter_32ty_selector_val+0x1f8>
     d98:      	mov	w0, #0x1                // =1
     d9c:      	ret
     da0:      	ldr	w8, [x1]
     da4:      	ldr	w9, [x0, #0x10]
     da8:      	cmp	w8, w9
     dac:      	b.hs	0xdd8 <filter_32ty_selector_val+0x218>
     db0:      	mov	w0, #0x1                // =1
     db4:      	ret
     db8:      	ldr	w9, [x0, #0x8]
     dbc:      	cmp	w9, #0xd
     dc0:      	b.lo	0xf10 <filter_32ty_selector_val+0x350>
     dc4:      	ldr	w10, [x0, #0x14]
     dc8:      	cmp	w8, w10
     dcc:      	b.ls	0xe4c <filter_32ty_selector_val+0x28c>
     dd0:      	mov	w0, #0x1                // =1
     dd4:      	ret
     dd8:      	ldr	w9, [x0, #0x8]
     ddc:      	cmp	w9, #0xd
     de0:      	b.lo	0xf10 <filter_32ty_selector_val+0x350>
     de4:      	ldr	w10, [x0, #0x14]
     de8:      	cmp	w8, w10
     dec:      	b.hs	0xe68 <filter_32ty_selector_val+0x2a8>
     df0:      	mov	w0, #0x1                // =1
     df4:      	ret
     df8:      	cmp	w9, #0x11
     dfc:      	b.lo	0xf10 <filter_32ty_selector_val+0x350>
     e00:      	ldr	w10, [x0, #0x18]
     e04:      	cmp	w8, w10
     e08:      	b.le	0xe84 <filter_32ty_selector_val+0x2c4>
     e0c:      	mov	w0, #0x1                // =1
     e10:      	ret
     e14:      	cmp	w9, #0x11
     e18:      	b.lo	0xf10 <filter_32ty_selector_val+0x350>
     e1c:      	ldr	w10, [x0, #0x18]
     e20:      	cmp	w8, w10
     e24:      	b.ge	0xea0 <filter_32ty_selector_val+0x2e0>
     e28:      	mov	w0, #0x1                // =1
     e2c:      	ret
     e30:      	cmp	w9, #0x11
     e34:      	b.lo	0xf10 <filter_32ty_selector_val+0x350>
     e38:      	ldr	w10, [x0, #0x18]
     e3c:      	tst	w8, w10
     e40:      	b.eq	0xebc <filter_32ty_selector_val+0x2fc>
     e44:      	mov	w0, #0x1                // =1
     e48:      	ret
     e4c:      	cmp	w9, #0x11
     e50:      	b.lo	0xf10 <filter_32ty_selector_val+0x350>
     e54:      	ldr	w10, [x0, #0x18]
     e58:      	cmp	w8, w10
     e5c:      	b.ls	0xed8 <filter_32ty_selector_val+0x318>
     e60:      	mov	w0, #0x1                // =1
     e64:      	ret
     e68:      	cmp	w9, #0x11
     e6c:      	b.lo	0xf10 <filter_32ty_selector_val+0x350>
     e70:      	ldr	w10, [x0, #0x18]
     e74:      	cmp	w8, w10
     e78:      	b.hs	0xef4 <filter_32ty_selector_val+0x334>
     e7c:      	mov	w0, #0x1                // =1
     e80:      	ret
     e84:      	cmp	w9, #0x15
     e88:      	b.lo	0xf10 <filter_32ty_selector_val+0x350>
     e8c:      	ldr	w9, [x0, #0x1c]
     e90:      	cmp	w8, w9
     e94:      	b.le	0xf10 <filter_32ty_selector_val+0x350>
     e98:      	mov	w0, #0x1                // =1
     e9c:      	ret
     ea0:      	cmp	w9, #0x15
     ea4:      	b.lo	0xf10 <filter_32ty_selector_val+0x350>
     ea8:      	ldr	w9, [x0, #0x1c]
     eac:      	cmp	w8, w9
     eb0:      	b.ge	0xf10 <filter_32ty_selector_val+0x350>
     eb4:      	mov	w0, #0x1                // =1
     eb8:      	ret
     ebc:      	cmp	w9, #0x15
     ec0:      	b.lo	0xf10 <filter_32ty_selector_val+0x350>
     ec4:      	ldr	w9, [x0, #0x1c]
     ec8:      	tst	w8, w9
     ecc:      	b.eq	0xf10 <filter_32ty_selector_val+0x350>
     ed0:      	mov	w0, #0x1                // =1
     ed4:      	ret
     ed8:      	cmp	w9, #0x15
     edc:      	b.lo	0xf10 <filter_32ty_selector_val+0x350>
     ee0:      	ldr	w9, [x0, #0x1c]
     ee4:      	cmp	w8, w9
     ee8:      	b.ls	0xf10 <filter_32ty_selector_val+0x350>
     eec:      	mov	w0, #0x1                // =1
     ef0:      	ret
     ef4:      	cmp	w9, #0x15
     ef8:      	b.lo	0xf10 <filter_32ty_selector_val+0x350>
     efc:      	ldr	w9, [x0, #0x1c]
     f00:      	cmp	w8, w9
     f04:      	b.hs	0xf10 <filter_32ty_selector_val+0x350>
     f08:      	mov	w0, #0x1                // =1
     f0c:      	ret
     f10:      	mov	x0, xzr
     f14:      	ret
     f18:      	nop
     f1c:      	nop

0000000000000f20 <filter_32ty_map>:
     f20:      	sub	sp, sp, #0x30
     f24:      	str	x30, [sp, #0x10]
     f28:      	stp	x20, x19, [sp, #0x20]
     f2c:      	ldrb	w8, [x0, #0x10]
     f30:      	mov	x19, x0
     f34:      	adrp	x0, 0x0 <read_reg>
     f38:      	add	x9, sp, #0x1c
     f3c:      	str	w8, [sp, #0x1c]
     f40:      	mov	w8, #0x1                // =1
     f44:      	mov	x20, x1
     f48:      	add	x1, sp, #0x1c
     f4c:      	ldr	x0, [x0]
     f50:      	blr	x8
     f54:      	cbz	x0, 0xfc8 <filter_32ty_map+0xa8>
     f58:      	ldr	w8, [x20]
     f5c:      	mov	w9, #0x1                // =1
     f60:      	add	x1, sp, #0x8
     f64:      	mov	w20, #0x1               // =1
     f68:      	str	x8, [sp, #0x8]
     f6c:      	add	x8, sp, #0x8
     f70:      	blr	x9
     f74:      	ldr	w9, [x19, #0x4]
     f78:      	mov	w8, wzr
     f7c:      	cmp	w9, #0x1d
     f80:      	b.hi	0xfc4 <filter_32ty_map+0xa4>
     f84:      	mov	w11, #0x8400            // =33792
     f88:      	lsl	w10, w20, w9
     f8c:      	movk	w11, #0x3003, lsl #16
     f90:      	tst	w10, w11
     f94:      	b.eq	0xfa4 <filter_32ty_map+0x84>
     f98:      	cmp	x0, #0x0
     f9c:      	cset	w8, ne
     fa0:      	b	0xfc4 <filter_32ty_map+0xa4>
     fa4:      	mov	w10, #0x1               // =1
     fa8:      	lsl	w9, w10, w9
     fac:      	mov	w10, #0x800             // =2048
     fb0:      	movk	w10, #0xc, lsl #16
     fb4:      	tst	w9, w10
     fb8:      	b.eq	0xfc4 <filter_32ty_map+0xa4>
     fbc:      	cmp	x0, #0x0
     fc0:      	cset	w8, eq
     fc4:      	mov	w0, w8
     fc8:      	ldp	x20, x19, [sp, #0x20]
     fcc:      	ldr	x30, [sp, #0x10]
     fd0:      	add	sp, sp, #0x30
     fd4:      	ret
     fd8:      	nop
     fdc:      	nop

0000000000000fe0 <filter_32ty_range>:
     fe0:      	ldr	w9, [x0, #0xc]
     fe4:      	ldr	w8, [x0, #0x4]
     fe8:      	mov	w10, #0x1               // =1
     fec:      	cmp	w9, #0xc
     ff0:      	lsl	w9, w10, w9
     ff4:      	mov	w10, #0x1402            // =5122
     ff8:      	and	w9, w9, w10
     ffc:      	ccmp	w9, #0x0, #0x4, ls
    1000:      	b.eq	0x1100 <filter_32ty_range+0x120>
    1004:      	ldr	w10, [x1]
    1008:      	cmp	w8, #0x1f
    100c:      	b.ne	0x1094 <filter_32ty_range+0xb4>
    1010:      	ldr	w9, [x0, #0x10]
    1014:      	cmp	w9, w10
    1018:      	b.gt	0x1028 <filter_32ty_range+0x48>
    101c:      	ldr	w9, [x0, #0x14]
    1020:      	cmp	w10, w9
    1024:      	b.le	0x1124 <filter_32ty_range+0x144>
    1028:      	ldr	w9, [x0, #0x8]
    102c:      	cmp	w9, #0x11
    1030:      	b.lo	0x1210 <filter_32ty_range+0x230>
    1034:      	ldr	w11, [x0, #0x18]
    1038:      	cmp	w11, w10
    103c:      	b.gt	0x104c <filter_32ty_range+0x6c>
    1040:      	ldr	w11, [x0, #0x1c]
    1044:      	cmp	w10, w11
    1048:      	b.le	0x1124 <filter_32ty_range+0x144>
    104c:      	cmp	w9, #0x19
    1050:      	b.lo	0x1210 <filter_32ty_range+0x230>
    1054:      	ldr	w11, [x0, #0x20]
    1058:      	cmp	w11, w10
    105c:      	b.gt	0x106c <filter_32ty_range+0x8c>
    1060:      	ldr	w11, [x0, #0x24]
    1064:      	cmp	w10, w11
    1068:      	b.le	0x1124 <filter_32ty_range+0x144>
    106c:      	cmp	w9, #0x21
    1070:      	b.lo	0x1210 <filter_32ty_range+0x230>
    1074:      	ldr	w11, [x0, #0x28]
    1078:      	mov	w9, wzr
    107c:      	cmp	w11, w10
    1080:      	b.gt	0x1200 <filter_32ty_range+0x220>
    1084:      	ldr	w11, [x0, #0x2c]
    1088:      	cmp	w10, w11
    108c:      	b.le	0x1124 <filter_32ty_range+0x144>
    1090:      	b	0x1200 <filter_32ty_range+0x220>
    1094:      	ldp	w9, w12, [x0, #0x10]
    1098:      	ldr	w11, [x0, #0x8]
    109c:      	cmp	w9, w10
    10a0:      	ccmp	w10, w12, #0x0, le
    10a4:      	cset	w9, le
    10a8:      	cmp	w11, #0x11
    10ac:      	b.lo	0x1200 <filter_32ty_range+0x220>
    10b0:      	ldp	w12, w13, [x0, #0x18]
    10b4:      	cmp	w12, w10
    10b8:      	ccmp	w10, w13, #0x0, le
    10bc:      	csinc	w9, w9, wzr, gt
    10c0:      	cmp	w11, #0x19
    10c4:      	b.lo	0x1200 <filter_32ty_range+0x220>
    10c8:      	ldp	w12, w13, [x0, #0x20]
    10cc:      	cmp	w12, w10
    10d0:      	ccmp	w10, w13, #0x0, le
    10d4:      	csinc	w9, w9, wzr, gt
    10d8:      	cmp	w11, #0x21
    10dc:      	b.lo	0x1200 <filter_32ty_range+0x220>
    10e0:      	ldp	w11, w12, [x0, #0x28]
    10e4:      	cmp	w11, w10
    10e8:      	ccmp	w10, w12, #0x0, le
    10ec:      	csinc	w9, w9, wzr, gt
    10f0:      	cmp	w8, #0x20
    10f4:      	eor	w8, w9, #0x1
    10f8:      	csel	w0, wzr, w8, ne
    10fc:      	ret
    1100:      	ldr	w10, [x1]
    1104:      	cmp	w8, #0x1f
    1108:      	b.ne	0x112c <filter_32ty_range+0x14c>
    110c:      	ldr	w9, [x0, #0x10]
    1110:      	cmp	w9, w10
    1114:      	b.hi	0x1198 <filter_32ty_range+0x1b8>
    1118:      	ldr	w9, [x0, #0x14]
    111c:      	cmp	w10, w9
    1120:      	b.hi	0x1198 <filter_32ty_range+0x1b8>
    1124:      	mov	w0, #0x1                // =1
    1128:      	ret
    112c:      	ldp	w9, w12, [x0, #0x10]
    1130:      	ldr	w11, [x0, #0x8]
    1134:      	cmp	w9, w10
    1138:      	ccmp	w10, w12, #0x2, ls
    113c:      	cset	w9, ls
    1140:      	cmp	w11, #0x11
    1144:      	b.lo	0x1200 <filter_32ty_range+0x220>
    1148:      	ldp	w12, w13, [x0, #0x18]
    114c:      	cmp	w12, w10
    1150:      	ccmp	w10, w13, #0x2, ls
    1154:      	csinc	w9, w9, wzr, hi
    1158:      	cmp	w11, #0x19
    115c:      	b.lo	0x1200 <filter_32ty_range+0x220>
    1160:      	ldp	w12, w13, [x0, #0x20]
    1164:      	cmp	w12, w10
    1168:      	ccmp	w10, w13, #0x2, ls
    116c:      	csinc	w9, w9, wzr, hi
    1170:      	cmp	w11, #0x21
    1174:      	b.lo	0x1200 <filter_32ty_range+0x220>
    1178:      	ldp	w11, w12, [x0, #0x28]
    117c:      	cmp	w11, w10
    1180:      	ccmp	w10, w12, #0x2, ls
    1184:      	csinc	w9, w9, wzr, hi
    1188:      	cmp	w8, #0x20
    118c:      	eor	w8, w9, #0x1
    1190:      	csel	w0, wzr, w8, ne
    1194:      	ret
    1198:      	ldr	w9, [x0, #0x8]
    119c:      	cmp	w9, #0x11
    11a0:      	b.lo	0x1210 <filter_32ty_range+0x230>
    11a4:      	ldr	w11, [x0, #0x18]
    11a8:      	cmp	w11, w10
    11ac:      	b.hi	0x11bc <filter_32ty_range+0x1dc>
    11b0:      	ldr	w11, [x0, #0x1c]
    11b4:      	cmp	w10, w11
    11b8:      	b.ls	0x1124 <filter_32ty_range+0x144>
    11bc:      	cmp	w9, #0x19
    11c0:      	b.lo	0x1210 <filter_32ty_range+0x230>
    11c4:      	ldr	w11, [x0, #0x20]
    11c8:      	cmp	w11, w10
    11cc:      	b.hi	0x11dc <filter_32ty_range+0x1fc>
    11d0:      	ldr	w11, [x0, #0x24]
    11d4:      	cmp	w10, w11
    11d8:      	b.ls	0x1124 <filter_32ty_range+0x144>
    11dc:      	cmp	w9, #0x21
    11e0:      	b.lo	0x1210 <filter_32ty_range+0x230>
    11e4:      	ldr	w11, [x0, #0x28]
    11e8:      	mov	w9, wzr
    11ec:      	cmp	w11, w10
    11f0:      	b.hi	0x1200 <filter_32ty_range+0x220>
    11f4:      	ldr	w11, [x0, #0x2c]
    11f8:      	cmp	w10, w11
    11fc:      	b.ls	0x1124 <filter_32ty_range+0x144>
    1200:      	cmp	w8, #0x20
    1204:      	eor	w8, w9, #0x1
    1208:      	csel	w0, wzr, w8, ne
    120c:      	ret
    1210:      	mov	w9, wzr
    1214:      	cmp	w8, #0x20
    1218:      	eor	w8, w9, #0x1
    121c:      	csel	w0, wzr, w8, ne
    1220:      	ret
    1224:      	nop
    1228:      	nop
    122c:      	nop

0000000000001230 <filter_16ty_selector_val>:
    1230:      	ldr	w8, [x0, #0x4]
    1234:      	cmp	w8, #0x25
    1238:      	b.hi	0x12ac <filter_16ty_selector_val+0x7c>
    123c:      	mov	x10, #0x40              // =64
    1240:      	mov	w9, #0x1                // =1
    1244:      	movk	x10, #0xc00, lsl #16
    1248:      	lsl	x9, x9, x8
    124c:      	movk	x10, #0x20, lsl #32
    1250:      	tst	x9, x10
    1254:      	b.eq	0x1260 <filter_16ty_selector_val+0x30>
    1258:      	mov	w0, #0x1                // =1
    125c:      	ret
    1260:      	mov	w9, #0x1                // =1
    1264:      	lsl	x9, x9, x8
    1268:      	tst	x9, #0x18
    126c:      	b.eq	0x128c <filter_16ty_selector_val+0x5c>
    1270:      	ldrh	w9, [x1]
    1274:      	ldr	w10, [x0, #0x10]
    1278:      	cmp	w10, w9
    127c:      	b.ne	0x132c <filter_16ty_selector_val+0xfc>
    1280:      	cmp	w8, #0x3
    1284:      	cset	w0, eq
    1288:      	ret
    128c:      	cmp	x8, #0xc
    1290:      	b.ne	0x12ac <filter_16ty_selector_val+0x7c>
    1294:      	ldrh	w8, [x1]
    1298:      	ldr	w9, [x0, #0x10]
    129c:      	tst	w9, w8
    12a0:      	b.eq	0x13d8 <filter_16ty_selector_val+0x1a8>
    12a4:      	mov	w0, #0x1                // =1
    12a8:      	ret
    12ac:      	cmp	w8, #0x1
    12b0:      	b.eq	0x12f4 <filter_16ty_selector_val+0xc4>
    12b4:      	cmp	w8, #0x2
    12b8:      	b.ne	0x1580 <filter_16ty_selector_val+0x350>
    12bc:      	ldr	w8, [x0, #0xc]
    12c0:      	cmp	w8, #0xc
    12c4:      	b.hi	0x1410 <filter_16ty_selector_val+0x1e0>
    12c8:      	mov	w9, #0x1                // =1
    12cc:      	lsl	w8, w9, w8
    12d0:      	mov	w9, #0x1402             // =5122
    12d4:      	tst	w8, w9
    12d8:      	b.eq	0x1410 <filter_16ty_selector_val+0x1e0>
    12dc:      	ldrsh	w8, [x1]
    12e0:      	ldr	w9, [x0, #0x10]
    12e4:      	cmp	w9, w8
    12e8:      	b.le	0x13b8 <filter_16ty_selector_val+0x188>
    12ec:      	mov	w0, #0x1                // =1
    12f0:      	ret
    12f4:      	ldr	w8, [x0, #0xc]
    12f8:      	cmp	w8, #0xc
    12fc:      	b.hi	0x13f8 <filter_16ty_selector_val+0x1c8>
    1300:      	mov	w9, #0x1                // =1
    1304:      	lsl	w8, w9, w8
    1308:      	mov	w9, #0x1402             // =5122
    130c:      	tst	w8, w9
    1310:      	b.eq	0x13f8 <filter_16ty_selector_val+0x1c8>
    1314:      	ldrsh	w8, [x1]
    1318:      	ldr	w9, [x0, #0x10]
    131c:      	cmp	w9, w8
    1320:      	b.ge	0x1398 <filter_16ty_selector_val+0x168>
    1324:      	mov	w0, #0x1                // =1
    1328:      	ret
    132c:      	ldr	w10, [x0, #0x8]
    1330:      	cmp	w10, #0xd
    1334:      	b.lo	0x136c <filter_16ty_selector_val+0x13c>
    1338:      	ldr	w11, [x0, #0x14]
    133c:      	cmp	w11, w9
    1340:      	b.eq	0x1280 <filter_16ty_selector_val+0x50>
    1344:      	cmp	w10, #0x11
    1348:      	b.lo	0x136c <filter_16ty_selector_val+0x13c>
    134c:      	ldr	w11, [x0, #0x18]
    1350:      	cmp	w11, w9
    1354:      	b.eq	0x1280 <filter_16ty_selector_val+0x50>
    1358:      	cmp	w10, #0x15
    135c:      	b.lo	0x136c <filter_16ty_selector_val+0x13c>
    1360:      	ldr	w10, [x0, #0x1c]
    1364:      	cmp	w10, w9
    1368:      	b.eq	0x1280 <filter_16ty_selector_val+0x50>
    136c:      	cmp	w8, #0x25
    1370:      	b.hi	0x1580 <filter_16ty_selector_val+0x350>
    1374:      	mov	w9, #0x1                // =1
    1378:      	lsl	x8, x9, x8
    137c:      	mov	x9, #0x50               // =80
    1380:      	movk	x9, #0xc00, lsl #16
    1384:      	movk	x9, #0x20, lsl #32
    1388:      	tst	x8, x9
    138c:      	b.eq	0x1580 <filter_16ty_selector_val+0x350>
    1390:      	mov	w0, #0x1                // =1
    1394:      	ret
    1398:      	ldr	w9, [x0, #0x8]
    139c:      	cmp	w9, #0xd
    13a0:      	b.lo	0x1580 <filter_16ty_selector_val+0x350>
    13a4:      	ldr	w10, [x0, #0x14]
    13a8:      	cmp	w10, w8
    13ac:      	b.ge	0x1468 <filter_16ty_selector_val+0x238>
    13b0:      	mov	w0, #0x1                // =1
    13b4:      	ret
    13b8:      	ldr	w9, [x0, #0x8]
    13bc:      	cmp	w9, #0xd
    13c0:      	b.lo	0x1580 <filter_16ty_selector_val+0x350>
    13c4:      	ldr	w10, [x0, #0x14]
    13c8:      	cmp	w10, w8
    13cc:      	b.le	0x1484 <filter_16ty_selector_val+0x254>
    13d0:      	mov	w0, #0x1                // =1
    13d4:      	ret
    13d8:      	ldr	w9, [x0, #0x8]
    13dc:      	cmp	w9, #0xd
    13e0:      	b.lo	0x1580 <filter_16ty_selector_val+0x350>
    13e4:      	ldr	w10, [x0, #0x14]
    13e8:      	tst	w10, w8
    13ec:      	b.eq	0x14a0 <filter_16ty_selector_val+0x270>
    13f0:      	mov	w0, #0x1                // =1
    13f4:      	ret
    13f8:      	ldrh	w8, [x1]
    13fc:      	ldr	w9, [x0, #0x10]
    1400:      	cmp	w9, w8
    1404:      	b.hs	0x1428 <filter_16ty_selector_val+0x1f8>
    1408:      	mov	w0, #0x1                // =1
    140c:      	ret
    1410:      	ldrh	w8, [x1]
    1414:      	ldr	w9, [x0, #0x10]
    1418:      	cmp	w9, w8
    141c:      	b.ls	0x1448 <filter_16ty_selector_val+0x218>
    1420:      	mov	w0, #0x1                // =1
    1424:      	ret
    1428:      	ldr	w9, [x0, #0x8]
    142c:      	cmp	w9, #0xd
    1430:      	b.lo	0x1580 <filter_16ty_selector_val+0x350>
    1434:      	ldr	w10, [x0, #0x14]
    1438:      	cmp	w10, w8
    143c:      	b.hs	0x14bc <filter_16ty_selector_val+0x28c>
    1440:      	mov	w0, #0x1                // =1
    1444:      	ret
    1448:      	ldr	w9, [x0, #0x8]
    144c:      	cmp	w9, #0xd
    1450:      	b.lo	0x1580 <filter_16ty_selector_val+0x350>
    1454:      	ldr	w10, [x0, #0x14]
    1458:      	cmp	w10, w8
    145c:      	b.ls	0x14d8 <filter_16ty_selector_val+0x2a8>
    1460:      	mov	w0, #0x1                // =1
    1464:      	ret
    1468:      	cmp	w9, #0x11
    146c:      	b.lo	0x1580 <filter_16ty_selector_val+0x350>
    1470:      	ldr	w10, [x0, #0x18]
    1474:      	cmp	w10, w8
    1478:      	b.ge	0x14f4 <filter_16ty_selector_val+0x2c4>
    147c:      	mov	w0, #0x1                // =1
    1480:      	ret
    1484:      	cmp	w9, #0x11
    1488:      	b.lo	0x1580 <filter_16ty_selector_val+0x350>
    148c:      	ldr	w10, [x0, #0x18]
    1490:      	cmp	w10, w8
    1494:      	b.le	0x1510 <filter_16ty_selector_val+0x2e0>
    1498:      	mov	w0, #0x1                // =1
    149c:      	ret
    14a0:      	cmp	w9, #0x11
    14a4:      	b.lo	0x1580 <filter_16ty_selector_val+0x350>
    14a8:      	ldr	w10, [x0, #0x18]
    14ac:      	tst	w10, w8
    14b0:      	b.eq	0x152c <filter_16ty_selector_val+0x2fc>
    14b4:      	mov	w0, #0x1                // =1
    14b8:      	ret
    14bc:      	cmp	w9, #0x11
    14c0:      	b.lo	0x1580 <filter_16ty_selector_val+0x350>
    14c4:      	ldr	w10, [x0, #0x18]
    14c8:      	cmp	w10, w8
    14cc:      	b.hs	0x1548 <filter_16ty_selector_val+0x318>
    14d0:      	mov	w0, #0x1                // =1
    14d4:      	ret
    14d8:      	cmp	w9, #0x11
    14dc:      	b.lo	0x1580 <filter_16ty_selector_val+0x350>
    14e0:      	ldr	w10, [x0, #0x18]
    14e4:      	cmp	w10, w8
    14e8:      	b.ls	0x1564 <filter_16ty_selector_val+0x334>
    14ec:      	mov	w0, #0x1                // =1
    14f0:      	ret
    14f4:      	cmp	w9, #0x15
    14f8:      	b.lo	0x1580 <filter_16ty_selector_val+0x350>
    14fc:      	ldr	w9, [x0, #0x1c]
    1500:      	cmp	w9, w8
    1504:      	b.ge	0x1580 <filter_16ty_selector_val+0x350>
    1508:      	mov	w0, #0x1                // =1
    150c:      	ret
    1510:      	cmp	w9, #0x15
    1514:      	b.lo	0x1580 <filter_16ty_selector_val+0x350>
    1518:      	ldr	w9, [x0, #0x1c]
    151c:      	cmp	w9, w8
    1520:      	b.le	0x1580 <filter_16ty_selector_val+0x350>
    1524:      	mov	w0, #0x1                // =1
    1528:      	ret
    152c:      	cmp	w9, #0x15
    1530:      	b.lo	0x1580 <filter_16ty_selector_val+0x350>
    1534:      	ldr	w9, [x0, #0x1c]
    1538:      	tst	w9, w8
    153c:      	b.eq	0x1580 <filter_16ty_selector_val+0x350>
    1540:      	mov	w0, #0x1                // =1
    1544:      	ret
    1548:      	cmp	w9, #0x15
    154c:      	b.lo	0x1580 <filter_16ty_selector_val+0x350>
    1550:      	ldr	w9, [x0, #0x1c]
    1554:      	cmp	w9, w8
    1558:      	b.hs	0x1580 <filter_16ty_selector_val+0x350>
    155c:      	mov	w0, #0x1                // =1
    1560:      	ret
    1564:      	cmp	w9, #0x15
    1568:      	b.lo	0x1580 <filter_16ty_selector_val+0x350>
    156c:      	ldr	w9, [x0, #0x1c]
    1570:      	cmp	w9, w8
    1574:      	b.ls	0x1580 <filter_16ty_selector_val+0x350>
    1578:      	mov	w0, #0x1                // =1
    157c:      	ret
    1580:      	mov	x0, xzr
    1584:      	ret
    1588:      	nop
    158c:      	nop

0000000000001590 <filter_16ty_map>:
    1590:      	sub	sp, sp, #0x30
    1594:      	str	x30, [sp, #0x10]
    1598:      	stp	x20, x19, [sp, #0x20]
    159c:      	ldrb	w8, [x0, #0x10]
    15a0:      	mov	x19, x0
    15a4:      	adrp	x0, 0x1000 <filter_32ty_range+0x20>
    15a8:      	add	x9, sp, #0x1c
    15ac:      	str	w8, [sp, #0x1c]
    15b0:      	mov	w8, #0x1                // =1
    15b4:      	mov	x20, x1
    15b8:      	add	x1, sp, #0x1c
    15bc:      	ldr	x0, [x0]
    15c0:      	blr	x8
    15c4:      	cbz	x0, 0x1638 <filter_16ty_map+0xa8>
    15c8:      	ldrh	w8, [x20]
    15cc:      	mov	w9, #0x1                // =1
    15d0:      	add	x1, sp, #0x8
    15d4:      	mov	w20, #0x1               // =1
    15d8:      	str	x8, [sp, #0x8]
    15dc:      	add	x8, sp, #0x8
    15e0:      	blr	x9
    15e4:      	ldr	w9, [x19, #0x4]
    15e8:      	mov	w8, wzr
    15ec:      	cmp	w9, #0x1d
    15f0:      	b.hi	0x1634 <filter_16ty_map+0xa4>
    15f4:      	mov	w11, #0x8400            // =33792
    15f8:      	lsl	w10, w20, w9
    15fc:      	movk	w11, #0x3003, lsl #16
    1600:      	tst	w10, w11
    1604:      	b.eq	0x1614 <filter_16ty_map+0x84>
    1608:      	cmp	x0, #0x0
    160c:      	cset	w8, ne
    1610:      	b	0x1634 <filter_16ty_map+0xa4>
    1614:      	mov	w10, #0x1               // =1
    1618:      	lsl	w9, w10, w9
    161c:      	mov	w10, #0x800             // =2048
    1620:      	movk	w10, #0xc, lsl #16
    1624:      	tst	w9, w10
    1628:      	b.eq	0x1634 <filter_16ty_map+0xa4>
    162c:      	cmp	x0, #0x0
    1630:      	cset	w8, eq
    1634:      	mov	w0, w8
    1638:      	ldp	x20, x19, [sp, #0x20]
    163c:      	ldr	x30, [sp, #0x10]
    1640:      	add	sp, sp, #0x30
    1644:      	ret
    1648:      	nop
    164c:      	nop

0000000000001650 <filter_16ty_range>:
    1650:      	ldr	w9, [x0, #0xc]
    1654:      	ldr	w8, [x0, #0x4]
    1658:      	mov	w10, #0x1               // =1
    165c:      	cmp	w9, #0xc
    1660:      	lsl	w9, w10, w9
    1664:      	mov	w10, #0x1402            // =5122
    1668:      	and	w9, w9, w10
    166c:      	ccmp	w9, #0x0, #0x4, ls
    1670:      	b.eq	0x1770 <filter_16ty_range+0x120>
    1674:      	ldrsh	w10, [x1]
    1678:      	cmp	w8, #0x1f
    167c:      	b.ne	0x1704 <filter_16ty_range+0xb4>
    1680:      	ldr	w9, [x0, #0x10]
    1684:      	cmp	w9, w10
    1688:      	b.gt	0x1698 <filter_16ty_range+0x48>
    168c:      	ldr	w9, [x0, #0x14]
    1690:      	cmp	w9, w10
    1694:      	b.ge	0x1794 <filter_16ty_range+0x144>
    1698:      	ldr	w9, [x0, #0x8]
    169c:      	cmp	w9, #0x11
    16a0:      	b.lo	0x1880 <filter_16ty_range+0x230>
    16a4:      	ldr	w11, [x0, #0x18]
    16a8:      	cmp	w11, w10
    16ac:      	b.gt	0x16bc <filter_16ty_range+0x6c>
    16b0:      	ldr	w11, [x0, #0x1c]
    16b4:      	cmp	w11, w10
    16b8:      	b.ge	0x1794 <filter_16ty_range+0x144>
    16bc:      	cmp	w9, #0x19
    16c0:      	b.lo	0x1880 <filter_16ty_range+0x230>
    16c4:      	ldr	w11, [x0, #0x20]
    16c8:      	cmp	w11, w10
    16cc:      	b.gt	0x16dc <filter_16ty_range+0x8c>
    16d0:      	ldr	w11, [x0, #0x24]
    16d4:      	cmp	w11, w10
    16d8:      	b.ge	0x1794 <filter_16ty_range+0x144>
    16dc:      	cmp	w9, #0x21
    16e0:      	b.lo	0x1880 <filter_16ty_range+0x230>
    16e4:      	ldr	w11, [x0, #0x28]
    16e8:      	mov	w9, wzr
    16ec:      	cmp	w11, w10
    16f0:      	b.gt	0x1870 <filter_16ty_range+0x220>
    16f4:      	ldr	w11, [x0, #0x2c]
    16f8:      	cmp	w11, w10
    16fc:      	b.ge	0x1794 <filter_16ty_range+0x144>
    1700:      	b	0x1870 <filter_16ty_range+0x220>
    1704:      	ldp	w9, w12, [x0, #0x10]
    1708:      	ldr	w11, [x0, #0x8]
    170c:      	cmp	w9, w10
    1710:      	ccmp	w12, w10, #0x8, le
    1714:      	cset	w9, ge
    1718:      	cmp	w11, #0x11
    171c:      	b.lo	0x1870 <filter_16ty_range+0x220>
    1720:      	ldp	w12, w13, [x0, #0x18]
    1724:      	cmp	w12, w10
    1728:      	ccmp	w13, w10, #0x8, le
    172c:      	csinc	w9, w9, wzr, lt
    1730:      	cmp	w11, #0x19
    1734:      	b.lo	0x1870 <filter_16ty_range+0x220>
    1738:      	ldp	w12, w13, [x0, #0x20]
    173c:      	cmp	w12, w10
    1740:      	ccmp	w13, w10, #0x8, le
    1744:      	csinc	w9, w9, wzr, lt
    1748:      	cmp	w11, #0x21
    174c:      	b.lo	0x1870 <filter_16ty_range+0x220>
    1750:      	ldp	w11, w12, [x0, #0x28]
    1754:      	cmp	w11, w10
    1758:      	ccmp	w12, w10, #0x8, le
    175c:      	csinc	w9, w9, wzr, lt
    1760:      	cmp	w8, #0x20
    1764:      	eor	w8, w9, #0x1
    1768:      	csel	w0, wzr, w8, ne
    176c:      	ret
    1770:      	ldrh	w10, [x1]
    1774:      	cmp	w8, #0x1f
    1778:      	b.ne	0x179c <filter_16ty_range+0x14c>
    177c:      	ldr	w9, [x0, #0x10]
    1780:      	cmp	w9, w10
    1784:      	b.hi	0x1808 <filter_16ty_range+0x1b8>
    1788:      	ldr	w9, [x0, #0x14]
    178c:      	cmp	w9, w10
    1790:      	b.lo	0x1808 <filter_16ty_range+0x1b8>
    1794:      	mov	w0, #0x1                // =1
    1798:      	ret
    179c:      	ldp	w9, w12, [x0, #0x10]
    17a0:      	ldr	w11, [x0, #0x8]
    17a4:      	cmp	w9, w10
    17a8:      	ccmp	w12, w10, #0x0, ls
    17ac:      	cset	w9, hs
    17b0:      	cmp	w11, #0x11
    17b4:      	b.lo	0x1870 <filter_16ty_range+0x220>
    17b8:      	ldp	w12, w13, [x0, #0x18]
    17bc:      	cmp	w12, w10
    17c0:      	ccmp	w13, w10, #0x0, ls
    17c4:      	csinc	w9, w9, wzr, lo
    17c8:      	cmp	w11, #0x19
    17cc:      	b.lo	0x1870 <filter_16ty_range+0x220>
    17d0:      	ldp	w12, w13, [x0, #0x20]
    17d4:      	cmp	w12, w10
    17d8:      	ccmp	w13, w10, #0x0, ls
    17dc:      	csinc	w9, w9, wzr, lo
    17e0:      	cmp	w11, #0x21
    17e4:      	b.lo	0x1870 <filter_16ty_range+0x220>
    17e8:      	ldp	w11, w12, [x0, #0x28]
    17ec:      	cmp	w11, w10
    17f0:      	ccmp	w12, w10, #0x0, ls
    17f4:      	csinc	w9, w9, wzr, lo
    17f8:      	cmp	w8, #0x20
    17fc:      	eor	w8, w9, #0x1
    1800:      	csel	w0, wzr, w8, ne
    1804:      	ret
    1808:      	ldr	w9, [x0, #0x8]
    180c:      	cmp	w9, #0x11
    1810:      	b.lo	0x1880 <filter_16ty_range+0x230>
    1814:      	ldr	w11, [x0, #0x18]
    1818:      	cmp	w11, w10
    181c:      	b.hi	0x182c <filter_16ty_range+0x1dc>
    1820:      	ldr	w11, [x0, #0x1c]
    1824:      	cmp	w11, w10
    1828:      	b.hs	0x1794 <filter_16ty_range+0x144>
    182c:      	cmp	w9, #0x19
    1830:      	b.lo	0x1880 <filter_16ty_range+0x230>
    1834:      	ldr	w11, [x0, #0x20]
    1838:      	cmp	w11, w10
    183c:      	b.hi	0x184c <filter_16ty_range+0x1fc>
    1840:      	ldr	w11, [x0, #0x24]
    1844:      	cmp	w11, w10
    1848:      	b.hs	0x1794 <filter_16ty_range+0x144>
    184c:      	cmp	w9, #0x21
    1850:      	b.lo	0x1880 <filter_16ty_range+0x230>
    1854:      	ldr	w11, [x0, #0x28]
    1858:      	mov	w9, wzr
    185c:      	cmp	w11, w10
    1860:      	b.hi	0x1870 <filter_16ty_range+0x220>
    1864:      	ldr	w11, [x0, #0x2c]
    1868:      	cmp	w11, w10
    186c:      	b.hs	0x1794 <filter_16ty_range+0x144>
    1870:      	cmp	w8, #0x20
    1874:      	eor	w8, w9, #0x1
    1878:      	csel	w0, wzr, w8, ne
    187c:      	ret
    1880:      	mov	w9, wzr
    1884:      	cmp	w8, #0x20
    1888:      	eor	w8, w9, #0x1
    188c:      	csel	w0, wzr, w8, ne
    1890:      	ret
    1894:      	nop
    1898:      	nop
    189c:      	nop

00000000000018a0 <filter_8ty_selector_val>:
    18a0:      	ldr	w8, [x0, #0x4]
    18a4:      	cmp	w8, #0x25
    18a8:      	b.hi	0x191c <filter_8ty_selector_val+0x7c>
    18ac:      	mov	x10, #0x40              // =64
    18b0:      	mov	w9, #0x1                // =1
    18b4:      	movk	x10, #0xc00, lsl #16
    18b8:      	lsl	x9, x9, x8
    18bc:      	movk	x10, #0x20, lsl #32
    18c0:      	tst	x9, x10
    18c4:      	b.eq	0x18d0 <filter_8ty_selector_val+0x30>
    18c8:      	mov	w0, #0x1                // =1
    18cc:      	ret
    18d0:      	mov	w9, #0x1                // =1
    18d4:      	lsl	x9, x9, x8
    18d8:      	tst	x9, #0x18
    18dc:      	b.eq	0x18fc <filter_8ty_selector_val+0x5c>
    18e0:      	ldrb	w9, [x1]
    18e4:      	ldr	w10, [x0, #0x10]
    18e8:      	cmp	w10, w9
    18ec:      	b.ne	0x199c <filter_8ty_selector_val+0xfc>
    18f0:      	cmp	w8, #0x3
    18f4:      	cset	w0, eq
    18f8:      	ret
    18fc:      	cmp	x8, #0xc
    1900:      	b.ne	0x191c <filter_8ty_selector_val+0x7c>
    1904:      	ldrb	w8, [x1]
    1908:      	ldr	w9, [x0, #0x10]
    190c:      	tst	w9, w8
    1910:      	b.eq	0x1a48 <filter_8ty_selector_val+0x1a8>
    1914:      	mov	w0, #0x1                // =1
    1918:      	ret
    191c:      	cmp	w8, #0x1
    1920:      	b.eq	0x1964 <filter_8ty_selector_val+0xc4>
    1924:      	cmp	w8, #0x2
    1928:      	b.ne	0x1bf0 <filter_8ty_selector_val+0x350>
    192c:      	ldr	w8, [x0, #0xc]
    1930:      	cmp	w8, #0xc
    1934:      	b.hi	0x1a80 <filter_8ty_selector_val+0x1e0>
    1938:      	mov	w9, #0x1                // =1
    193c:      	lsl	w8, w9, w8
    1940:      	mov	w9, #0x1402             // =5122
    1944:      	tst	w8, w9
    1948:      	b.eq	0x1a80 <filter_8ty_selector_val+0x1e0>
    194c:      	ldrsb	w8, [x1]
    1950:      	ldr	w9, [x0, #0x10]
    1954:      	cmp	w9, w8
    1958:      	b.le	0x1a28 <filter_8ty_selector_val+0x188>
    195c:      	mov	w0, #0x1                // =1
    1960:      	ret
    1964:      	ldr	w8, [x0, #0xc]
    1968:      	cmp	w8, #0xc
    196c:      	b.hi	0x1a68 <filter_8ty_selector_val+0x1c8>
    1970:      	mov	w9, #0x1                // =1
    1974:      	lsl	w8, w9, w8
    1978:      	mov	w9, #0x1402             // =5122
    197c:      	tst	w8, w9
    1980:      	b.eq	0x1a68 <filter_8ty_selector_val+0x1c8>
    1984:      	ldrsb	w8, [x1]
    1988:      	ldr	w9, [x0, #0x10]
    198c:      	cmp	w9, w8
    1990:      	b.ge	0x1a08 <filter_8ty_selector_val+0x168>
    1994:      	mov	w0, #0x1                // =1
    1998:      	ret
    199c:      	ldr	w10, [x0, #0x8]
    19a0:      	cmp	w10, #0xd
    19a4:      	b.lo	0x19dc <filter_8ty_selector_val+0x13c>
    19a8:      	ldr	w11, [x0, #0x14]
    19ac:      	cmp	w11, w9
    19b0:      	b.eq	0x18f0 <filter_8ty_selector_val+0x50>
    19b4:      	cmp	w10, #0x11
    19b8:      	b.lo	0x19dc <filter_8ty_selector_val+0x13c>
    19bc:      	ldr	w11, [x0, #0x18]
    19c0:      	cmp	w11, w9
    19c4:      	b.eq	0x18f0 <filter_8ty_selector_val+0x50>
    19c8:      	cmp	w10, #0x15
    19cc:      	b.lo	0x19dc <filter_8ty_selector_val+0x13c>
    19d0:      	ldr	w10, [x0, #0x1c]
    19d4:      	cmp	w10, w9
    19d8:      	b.eq	0x18f0 <filter_8ty_selector_val+0x50>
    19dc:      	cmp	w8, #0x25
    19e0:      	b.hi	0x1bf0 <filter_8ty_selector_val+0x350>
    19e4:      	mov	w9, #0x1                // =1
    19e8:      	lsl	x8, x9, x8
    19ec:      	mov	x9, #0x50               // =80
    19f0:      	movk	x9, #0xc00, lsl #16
    19f4:      	movk	x9, #0x20, lsl #32
    19f8:      	tst	x8, x9
    19fc:      	b.eq	0x1bf0 <filter_8ty_selector_val+0x350>
    1a00:      	mov	w0, #0x1                // =1
    1a04:      	ret
    1a08:      	ldr	w9, [x0, #0x8]
    1a0c:      	cmp	w9, #0xd
    1a10:      	b.lo	0x1bf0 <filter_8ty_selector_val+0x350>
    1a14:      	ldr	w10, [x0, #0x14]
    1a18:      	cmp	w10, w8
    1a1c:      	b.ge	0x1ad8 <filter_8ty_selector_val+0x238>
    1a20:      	mov	w0, #0x1                // =1
    1a24:      	ret
    1a28:      	ldr	w9, [x0, #0x8]
    1a2c:      	cmp	w9, #0xd
    1a30:      	b.lo	0x1bf0 <filter_8ty_selector_val+0x350>
    1a34:      	ldr	w10, [x0, #0x14]
    1a38:      	cmp	w10, w8
    1a3c:      	b.le	0x1af4 <filter_8ty_selector_val+0x254>
    1a40:      	mov	w0, #0x1                // =1
    1a44:      	ret
    1a48:      	ldr	w9, [x0, #0x8]
    1a4c:      	cmp	w9, #0xd
    1a50:      	b.lo	0x1bf0 <filter_8ty_selector_val+0x350>
    1a54:      	ldr	w10, [x0, #0x14]
    1a58:      	tst	w10, w8
    1a5c:      	b.eq	0x1b10 <filter_8ty_selector_val+0x270>
    1a60:      	mov	w0, #0x1                // =1
    1a64:      	ret
    1a68:      	ldrb	w8, [x1]
    1a6c:      	ldr	w9, [x0, #0x10]
    1a70:      	cmp	w9, w8
    1a74:      	b.hs	0x1a98 <filter_8ty_selector_val+0x1f8>
    1a78:      	mov	w0, #0x1                // =1
    1a7c:      	ret
    1a80:      	ldrb	w8, [x1]
    1a84:      	ldr	w9, [x0, #0x10]
    1a88:      	cmp	w9, w8
    1a8c:      	b.ls	0x1ab8 <filter_8ty_selector_val+0x218>
    1a90:      	mov	w0, #0x1                // =1
    1a94:      	ret
    1a98:      	ldr	w9, [x0, #0x8]
    1a9c:      	cmp	w9, #0xd
    1aa0:      	b.lo	0x1bf0 <filter_8ty_selector_val+0x350>
    1aa4:      	ldr	w10, [x0, #0x14]
    1aa8:      	cmp	w10, w8
    1aac:      	b.hs	0x1b2c <filter_8ty_selector_val+0x28c>
    1ab0:      	mov	w0, #0x1                // =1
    1ab4:      	ret
    1ab8:      	ldr	w9, [x0, #0x8]
    1abc:      	cmp	w9, #0xd
    1ac0:      	b.lo	0x1bf0 <filter_8ty_selector_val+0x350>
    1ac4:      	ldr	w10, [x0, #0x14]
    1ac8:      	cmp	w10, w8
    1acc:      	b.ls	0x1b48 <filter_8ty_selector_val+0x2a8>
    1ad0:      	mov	w0, #0x1                // =1
    1ad4:      	ret
    1ad8:      	cmp	w9, #0x11
    1adc:      	b.lo	0x1bf0 <filter_8ty_selector_val+0x350>
    1ae0:      	ldr	w10, [x0, #0x18]
    1ae4:      	cmp	w10, w8
    1ae8:      	b.ge	0x1b64 <filter_8ty_selector_val+0x2c4>
    1aec:      	mov	w0, #0x1                // =1
    1af0:      	ret
    1af4:      	cmp	w9, #0x11
    1af8:      	b.lo	0x1bf0 <filter_8ty_selector_val+0x350>
    1afc:      	ldr	w10, [x0, #0x18]
    1b00:      	cmp	w10, w8
    1b04:      	b.le	0x1b80 <filter_8ty_selector_val+0x2e0>
    1b08:      	mov	w0, #0x1                // =1
    1b0c:      	ret
    1b10:      	cmp	w9, #0x11
    1b14:      	b.lo	0x1bf0 <filter_8ty_selector_val+0x350>
    1b18:      	ldr	w10, [x0, #0x18]
    1b1c:      	tst	w10, w8
    1b20:      	b.eq	0x1b9c <filter_8ty_selector_val+0x2fc>
    1b24:      	mov	w0, #0x1                // =1
    1b28:      	ret
    1b2c:      	cmp	w9, #0x11
    1b30:      	b.lo	0x1bf0 <filter_8ty_selector_val+0x350>
    1b34:      	ldr	w10, [x0, #0x18]
    1b38:      	cmp	w10, w8
    1b3c:      	b.hs	0x1bb8 <filter_8ty_selector_val+0x318>
    1b40:      	mov	w0, #0x1                // =1
    1b44:      	ret
    1b48:      	cmp	w9, #0x11
    1b4c:      	b.lo	0x1bf0 <filter_8ty_selector_val+0x350>
    1b50:      	ldr	w10, [x0, #0x18]
    1b54:      	cmp	w10, w8
    1b58:      	b.ls	0x1bd4 <filter_8ty_selector_val+0x334>
    1b5c:      	mov	w0, #0x1                // =1
    1b60:      	ret
    1b64:      	cmp	w9, #0x15
    1b68:      	b.lo	0x1bf0 <filter_8ty_selector_val+0x350>
    1b6c:      	ldr	w9, [x0, #0x1c]
    1b70:      	cmp	w9, w8
    1b74:      	b.ge	0x1bf0 <filter_8ty_selector_val+0x350>
    1b78:      	mov	w0, #0x1                // =1
    1b7c:      	ret
    1b80:      	cmp	w9, #0x15
    1b84:      	b.lo	0x1bf0 <filter_8ty_selector_val+0x350>
    1b88:      	ldr	w9, [x0, #0x1c]
    1b8c:      	cmp	w9, w8
    1b90:      	b.le	0x1bf0 <filter_8ty_selector_val+0x350>
    1b94:      	mov	w0, #0x1                // =1
    1b98:      	ret
    1b9c:      	cmp	w9, #0x15
    1ba0:      	b.lo	0x1bf0 <filter_8ty_selector_val+0x350>
    1ba4:      	ldr	w9, [x0, #0x1c]
    1ba8:      	tst	w9, w8
    1bac:      	b.eq	0x1bf0 <filter_8ty_selector_val+0x350>
    1bb0:      	mov	w0, #0x1                // =1
    1bb4:      	ret
    1bb8:      	cmp	w9, #0x15
    1bbc:      	b.lo	0x1bf0 <filter_8ty_selector_val+0x350>
    1bc0:      	ldr	w9, [x0, #0x1c]
    1bc4:      	cmp	w9, w8
    1bc8:      	b.hs	0x1bf0 <filter_8ty_selector_val+0x350>
    1bcc:      	mov	w0, #0x1                // =1
    1bd0:      	ret
    1bd4:      	cmp	w9, #0x15
    1bd8:      	b.lo	0x1bf0 <filter_8ty_selector_val+0x350>
    1bdc:      	ldr	w9, [x0, #0x1c]
    1be0:      	cmp	w9, w8
    1be4:      	b.ls	0x1bf0 <filter_8ty_selector_val+0x350>
    1be8:      	mov	w0, #0x1                // =1
    1bec:      	ret
    1bf0:      	mov	x0, xzr
    1bf4:      	ret
    1bf8:      	nop
    1bfc:      	nop

0000000000001c00 <filter_8ty_map>:
    1c00:      	sub	sp, sp, #0x30
    1c04:      	str	x30, [sp, #0x10]
    1c08:      	stp	x20, x19, [sp, #0x20]
    1c0c:      	ldrb	w8, [x0, #0x10]
    1c10:      	mov	x19, x0
    1c14:      	adrp	x0, 0x1000 <filter_32ty_range+0x20>
    1c18:      	add	x9, sp, #0x1c
    1c1c:      	str	w8, [sp, #0x1c]
    1c20:      	mov	w8, #0x1                // =1
    1c24:      	mov	x20, x1
    1c28:      	add	x1, sp, #0x1c
    1c2c:      	ldr	x0, [x0]
    1c30:      	blr	x8
    1c34:      	cbz	x0, 0x1ca8 <filter_8ty_map+0xa8>
    1c38:      	ldrb	w8, [x20]
    1c3c:      	mov	w9, #0x1                // =1
    1c40:      	add	x1, sp, #0x8
    1c44:      	mov	w20, #0x1               // =1
    1c48:      	str	x8, [sp, #0x8]
    1c4c:      	add	x8, sp, #0x8
    1c50:      	blr	x9
    1c54:      	ldr	w9, [x19, #0x4]
    1c58:      	mov	w8, wzr
    1c5c:      	cmp	w9, #0x1d
    1c60:      	b.hi	0x1ca4 <filter_8ty_map+0xa4>
    1c64:      	mov	w11, #0x8400            // =33792
    1c68:      	lsl	w10, w20, w9
    1c6c:      	movk	w11, #0x3003, lsl #16
    1c70:      	tst	w10, w11
    1c74:      	b.eq	0x1c84 <filter_8ty_map+0x84>
    1c78:      	cmp	x0, #0x0
    1c7c:      	cset	w8, ne
    1c80:      	b	0x1ca4 <filter_8ty_map+0xa4>
    1c84:      	mov	w10, #0x1               // =1
    1c88:      	lsl	w9, w10, w9
    1c8c:      	mov	w10, #0x800             // =2048
    1c90:      	movk	w10, #0xc, lsl #16
    1c94:      	tst	w9, w10
    1c98:      	b.eq	0x1ca4 <filter_8ty_map+0xa4>
    1c9c:      	cmp	x0, #0x0
    1ca0:      	cset	w8, eq
    1ca4:      	mov	w0, w8
    1ca8:      	ldp	x20, x19, [sp, #0x20]
    1cac:      	ldr	x30, [sp, #0x10]
    1cb0:      	add	sp, sp, #0x30
    1cb4:      	ret
    1cb8:      	nop
    1cbc:      	nop

0000000000001cc0 <filter_8ty_range>:
    1cc0:      	ldr	w9, [x0, #0xc]
    1cc4:      	ldr	w8, [x0, #0x4]
    1cc8:      	mov	w10, #0x1               // =1
    1ccc:      	cmp	w9, #0xc
    1cd0:      	lsl	w9, w10, w9
    1cd4:      	mov	w10, #0x1402            // =5122
    1cd8:      	and	w9, w9, w10
    1cdc:      	ccmp	w9, #0x0, #0x4, ls
    1ce0:      	b.eq	0x1de0 <filter_8ty_range+0x120>
    1ce4:      	ldrsb	w10, [x1]
    1ce8:      	cmp	w8, #0x1f
    1cec:      	b.ne	0x1d74 <filter_8ty_range+0xb4>
    1cf0:      	ldr	w9, [x0, #0x10]
    1cf4:      	cmp	w9, w10
    1cf8:      	b.gt	0x1d08 <filter_8ty_range+0x48>
    1cfc:      	ldr	w9, [x0, #0x14]
    1d00:      	cmp	w9, w10
    1d04:      	b.ge	0x1e04 <filter_8ty_range+0x144>
    1d08:      	ldr	w9, [x0, #0x8]
    1d0c:      	cmp	w9, #0x11
    1d10:      	b.lo	0x1ef0 <filter_8ty_range+0x230>
    1d14:      	ldr	w11, [x0, #0x18]
    1d18:      	cmp	w11, w10
    1d1c:      	b.gt	0x1d2c <filter_8ty_range+0x6c>
    1d20:      	ldr	w11, [x0, #0x1c]
    1d24:      	cmp	w11, w10
    1d28:      	b.ge	0x1e04 <filter_8ty_range+0x144>
    1d2c:      	cmp	w9, #0x19
    1d30:      	b.lo	0x1ef0 <filter_8ty_range+0x230>
    1d34:      	ldr	w11, [x0, #0x20]
    1d38:      	cmp	w11, w10
    1d3c:      	b.gt	0x1d4c <filter_8ty_range+0x8c>
    1d40:      	ldr	w11, [x0, #0x24]
    1d44:      	cmp	w11, w10
    1d48:      	b.ge	0x1e04 <filter_8ty_range+0x144>
    1d4c:      	cmp	w9, #0x21
    1d50:      	b.lo	0x1ef0 <filter_8ty_range+0x230>
    1d54:      	ldr	w11, [x0, #0x28]
    1d58:      	mov	w9, wzr
    1d5c:      	cmp	w11, w10
    1d60:      	b.gt	0x1ee0 <filter_8ty_range+0x220>
    1d64:      	ldr	w11, [x0, #0x2c]
    1d68:      	cmp	w11, w10
    1d6c:      	b.ge	0x1e04 <filter_8ty_range+0x144>
    1d70:      	b	0x1ee0 <filter_8ty_range+0x220>
    1d74:      	ldp	w9, w12, [x0, #0x10]
    1d78:      	ldr	w11, [x0, #0x8]
    1d7c:      	cmp	w9, w10
    1d80:      	ccmp	w12, w10, #0x8, le
    1d84:      	cset	w9, ge
    1d88:      	cmp	w11, #0x11
    1d8c:      	b.lo	0x1ee0 <filter_8ty_range+0x220>
    1d90:      	ldp	w12, w13, [x0, #0x18]
    1d94:      	cmp	w12, w10
    1d98:      	ccmp	w13, w10, #0x8, le
    1d9c:      	csinc	w9, w9, wzr, lt
    1da0:      	cmp	w11, #0x19
    1da4:      	b.lo	0x1ee0 <filter_8ty_range+0x220>
    1da8:      	ldp	w12, w13, [x0, #0x20]
    1dac:      	cmp	w12, w10
    1db0:      	ccmp	w13, w10, #0x8, le
    1db4:      	csinc	w9, w9, wzr, lt
    1db8:      	cmp	w11, #0x21
    1dbc:      	b.lo	0x1ee0 <filter_8ty_range+0x220>
    1dc0:      	ldp	w11, w12, [x0, #0x28]
    1dc4:      	cmp	w11, w10
    1dc8:      	ccmp	w12, w10, #0x8, le
    1dcc:      	csinc	w9, w9, wzr, lt
    1dd0:      	cmp	w8, #0x20
    1dd4:      	eor	w8, w9, #0x1
    1dd8:      	csel	w0, wzr, w8, ne
    1ddc:      	ret
    1de0:      	ldrb	w10, [x1]
    1de4:      	cmp	w8, #0x1f
    1de8:      	b.ne	0x1e0c <filter_8ty_range+0x14c>
    1dec:      	ldr	w9, [x0, #0x10]
    1df0:      	cmp	w9, w10
    1df4:      	b.hi	0x1e78 <filter_8ty_range+0x1b8>
    1df8:      	ldr	w9, [x0, #0x14]
    1dfc:      	cmp	w9, w10
    1e00:      	b.lo	0x1e78 <filter_8ty_range+0x1b8>
    1e04:      	mov	w0, #0x1                // =1
    1e08:      	ret
    1e0c:      	ldp	w9, w12, [x0, #0x10]
    1e10:      	ldr	w11, [x0, #0x8]
    1e14:      	cmp	w9, w10
    1e18:      	ccmp	w12, w10, #0x0, ls
    1e1c:      	cset	w9, hs
    1e20:      	cmp	w11, #0x11
    1e24:      	b.lo	0x1ee0 <filter_8ty_range+0x220>
    1e28:      	ldp	w12, w13, [x0, #0x18]
    1e2c:      	cmp	w12, w10
    1e30:      	ccmp	w13, w10, #0x0, ls
    1e34:      	csinc	w9, w9, wzr, lo
    1e38:      	cmp	w11, #0x19
    1e3c:      	b.lo	0x1ee0 <filter_8ty_range+0x220>
    1e40:      	ldp	w12, w13, [x0, #0x20]
    1e44:      	cmp	w12, w10
    1e48:      	ccmp	w13, w10, #0x0, ls
    1e4c:      	csinc	w9, w9, wzr, lo
    1e50:      	cmp	w11, #0x21
    1e54:      	b.lo	0x1ee0 <filter_8ty_range+0x220>
    1e58:      	ldp	w11, w12, [x0, #0x28]
    1e5c:      	cmp	w11, w10
    1e60:      	ccmp	w12, w10, #0x0, ls
    1e64:      	csinc	w9, w9, wzr, lo
    1e68:      	cmp	w8, #0x20
    1e6c:      	eor	w8, w9, #0x1
    1e70:      	csel	w0, wzr, w8, ne
    1e74:      	ret
    1e78:      	ldr	w9, [x0, #0x8]
    1e7c:      	cmp	w9, #0x11
    1e80:      	b.lo	0x1ef0 <filter_8ty_range+0x230>
    1e84:      	ldr	w11, [x0, #0x18]
    1e88:      	cmp	w11, w10
    1e8c:      	b.hi	0x1e9c <filter_8ty_range+0x1dc>
    1e90:      	ldr	w11, [x0, #0x1c]
    1e94:      	cmp	w11, w10
    1e98:      	b.hs	0x1e04 <filter_8ty_range+0x144>
    1e9c:      	cmp	w9, #0x19
    1ea0:      	b.lo	0x1ef0 <filter_8ty_range+0x230>
    1ea4:      	ldr	w11, [x0, #0x20]
    1ea8:      	cmp	w11, w10
    1eac:      	b.hi	0x1ebc <filter_8ty_range+0x1fc>
    1eb0:      	ldr	w11, [x0, #0x24]
    1eb4:      	cmp	w11, w10
    1eb8:      	b.hs	0x1e04 <filter_8ty_range+0x144>
    1ebc:      	cmp	w9, #0x21
    1ec0:      	b.lo	0x1ef0 <filter_8ty_range+0x230>
    1ec4:      	ldr	w11, [x0, #0x28]
    1ec8:      	mov	w9, wzr
    1ecc:      	cmp	w11, w10
    1ed0:      	b.hi	0x1ee0 <filter_8ty_range+0x220>
    1ed4:      	ldr	w11, [x0, #0x2c]
    1ed8:      	cmp	w11, w10
    1edc:      	b.hs	0x1e04 <filter_8ty_range+0x144>
    1ee0:      	cmp	w8, #0x20
    1ee4:      	eor	w8, w9, #0x1
    1ee8:      	csel	w0, wzr, w8, ne
    1eec:      	ret
    1ef0:      	mov	w9, wzr
    1ef4:      	cmp	w8, #0x20
    1ef8:      	eor	w8, w9, #0x1
    1efc:      	csel	w0, wzr, w8, ne
    1f00:      	ret
    1f04:      	nop
    1f08:      	nop
    1f0c:      	nop

0000000000001f10 <filter_file_buf>:
    1f10:      	stp	x30, x19, [sp, #-0x10]!
    1f14:      	ldr	w2, [x1]
    1f18:      	ldr	w8, [x0, #0x4]
    1f1c:      	mov	x19, x0
    1f20:      	cbnz	w2, 0x1f3c <filter_file_buf+0x2c>
    1f24:      	and	w9, w8, #0xfffffffe
    1f28:      	cmp	w9, #0x24
    1f2c:      	b.eq	0x1f3c <filter_file_buf+0x2c>
    1f30:      	mov	x0, xzr
    1f34:      	ldp	x30, x19, [sp], #0x10
    1f38:      	ret
    1f3c:      	cmp	w8, #0x25
    1f40:      	b.hi	0x1f9c <filter_file_buf+0x8c>
    1f44:      	mov	w9, #0x1                // =1
    1f48:      	mov	w10, #0x100             // =256
    1f4c:      	lsl	x9, x9, x8
    1f50:      	movk	w10, #0x400, lsl #16
    1f54:      	tst	x9, x10
    1f58:      	b.ne	0x1fe0 <filter_file_buf+0xd0>
    1f5c:      	mov	w9, #0x1                // =1
    1f60:      	mov	w10, #0x200             // =512
    1f64:      	lsl	x9, x9, x8
    1f68:      	movk	w10, #0x800, lsl #16
    1f6c:      	tst	x9, x10
    1f70:      	b.ne	0x1fc4 <filter_file_buf+0xb4>
    1f74:      	mov	w9, #0x1                // =1
    1f78:      	lsl	x9, x9, x8
    1f7c:      	tst	x9, #0x3000000000
    1f80:      	b.eq	0x1f9c <filter_file_buf+0x8c>
    1f84:      	mov	x0, x19
    1f88:      	bl	0x2bf0 <filter_file_type>
    1f8c:      	ldr	w8, [x19, #0x4]
    1f90:      	cmp	w8, #0x25
    1f94:      	b.ls	0x2008 <filter_file_buf+0xf8>
    1f98:      	b	0x202c <filter_file_buf+0x11c>
    1f9c:      	sub	w9, w8, #0x3
    1fa0:      	cmp	w9, #0x2
    1fa4:      	b.hs	0x1ffc <filter_file_buf+0xec>
    1fa8:      	add	x1, x1, #0x4
    1fac:      	mov	x0, x19
    1fb0:      	bl	0x2620 <filter_char_buf_equal>
    1fb4:      	ldr	w8, [x19, #0x4]
    1fb8:      	cmp	w8, #0x25
    1fbc:      	b.ls	0x2008 <filter_file_buf+0xf8>
    1fc0:      	b	0x202c <filter_file_buf+0x11c>
    1fc4:      	ldr	w0, [x19, #0x10]
    1fc8:      	add	x1, x1, #0x4
    1fcc:      	bl	0x2b10 <filter_char_buf_postfix>
    1fd0:      	ldr	w8, [x19, #0x4]
    1fd4:      	cmp	w8, #0x25
    1fd8:      	b.ls	0x2008 <filter_file_buf+0xf8>
    1fdc:      	b	0x202c <filter_file_buf+0x11c>
    1fe0:      	ldr	w0, [x19, #0x10]
    1fe4:      	add	x1, x1, #0x4
    1fe8:      	bl	0x2a50 <filter_char_buf_prefix>
    1fec:      	ldr	w8, [x19, #0x4]
    1ff0:      	cmp	w8, #0x25
    1ff4:      	b.ls	0x2008 <filter_file_buf+0xf8>
    1ff8:      	b	0x202c <filter_file_buf+0x11c>
    1ffc:      	mov	x0, xzr
    2000:      	cmp	w8, #0x25
    2004:      	b.hi	0x202c <filter_file_buf+0x11c>
    2008:      	mov	w8, w8
    200c:      	mov	w9, #0x1                // =1
    2010:      	lsl	x8, x9, x8
    2014:      	mov	x9, #0x50               // =80
    2018:      	movk	x9, #0xc00, lsl #16
    201c:      	movk	x9, #0x20, lsl #32
    2020:      	tst	x8, x9
    2024:      	b.eq	0x202c <filter_file_buf+0x11c>
    2028:      	eor	x0, x0, #0x1
    202c:      	ldp	x30, x19, [sp], #0x10
    2030:      	ret
    2034:      	nop
    2038:      	nop
    203c:      	nop

0000000000002040 <filter_char_buf>:
    2040:      	stp	x30, x19, [sp, #-0x10]!
    2044:      	mov	w8, w2
    2048:      	mov	x19, x0
    204c:      	add	x9, x1, w2, sxtw
    2050:      	ldur	w2, [x9, #-0x4]
    2054:      	add	x1, x1, w8, uxtw
    2058:      	ldr	w8, [x0, #0x4]
    205c:      	mov	x0, xzr
    2060:      	cmp	w8, #0x19
    2064:      	b.gt	0x2088 <filter_char_buf+0x48>
    2068:      	sub	w9, w8, #0x3
    206c:      	cmp	w9, #0x2
    2070:      	b.lo	0x20d4 <filter_char_buf+0x94>
    2074:      	cmp	w8, #0x8
    2078:      	b.eq	0x20c8 <filter_char_buf+0x88>
    207c:      	cmp	w8, #0x9
    2080:      	b.eq	0x20a0 <filter_char_buf+0x60>
    2084:      	b	0x20f0 <filter_char_buf+0xb0>
    2088:      	cmp	w8, #0x20
    208c:      	b.gt	0x20ac <filter_char_buf+0x6c>
    2090:      	cmp	w8, #0x1a
    2094:      	b.eq	0x20c8 <filter_char_buf+0x88>
    2098:      	cmp	w8, #0x1b
    209c:      	b.ne	0x20f0 <filter_char_buf+0xb0>
    20a0:      	ldr	w0, [x19, #0x10]
    20a4:      	bl	0x2b10 <filter_char_buf_postfix>
    20a8:      	b	0x20ec <filter_char_buf+0xac>
    20ac:      	cmp	w8, #0x21
    20b0:      	b.eq	0x20e0 <filter_char_buf+0xa0>
    20b4:      	cmp	w8, #0x22
    20b8:      	b.ne	0x20f0 <filter_char_buf+0xb0>
    20bc:      	mov	x0, x19
    20c0:      	mov	w3, #0x1                // =1
    20c4:      	b	0x20e8 <filter_char_buf+0xa8>
    20c8:      	ldr	w0, [x19, #0x10]
    20cc:      	bl	0x2a50 <filter_char_buf_prefix>
    20d0:      	b	0x20ec <filter_char_buf+0xac>
    20d4:      	mov	x0, x19
    20d8:      	bl	0x2620 <filter_char_buf_equal>
    20dc:      	b	0x20ec <filter_char_buf+0xac>
    20e0:      	mov	x0, x19
    20e4:      	mov	w3, wzr
    20e8:      	bl	0x2cf0 <filter_char_substring>
    20ec:      	ldr	w8, [x19, #0x4]
    20f0:      	cmp	w8, #0x25
    20f4:      	b.hi	0x2120 <filter_char_buf+0xe0>
    20f8:      	mov	w8, w8
    20fc:      	mov	w9, #0x1                // =1
    2100:      	lsl	x8, x9, x8
    2104:      	mov	x9, #0x50               // =80
    2108:      	movk	x9, #0xc00, lsl #16
    210c:      	movk	x9, #0x20, lsl #32
    2110:      	tst	x8, x9
    2114:      	b.eq	0x2120 <filter_char_buf+0xe0>
    2118:      	cmp	x0, #0x0
    211c:      	cset	w0, eq
    2120:      	ldp	x30, x19, [sp], #0x10
    2124:      	ret
    2128:      	nop
    212c:      	nop

0000000000002130 <filter_inet>:
    2130:      	sub	sp, sp, #0x80
    2134:      	str	x30, [sp, #0x50]
    2138:      	stp	x22, x21, [sp, #0x60]
    213c:      	stp	x20, x19, [sp, #0x70]
    2140:      	ldr	w10, [x0, #0xc]
    2144:      	mov	x8, xzr
    2148:      	stp	xzr, xzr, [sp, #0x28]
    214c:      	cmp	w10, #0x27
    2150:      	str	xzr, [sp, #0x10]
    2154:      	stp	xzr, xzr, [sp, #0x18]
    2158:      	str	wzr, [sp, #0x58]
    215c:      	str	wzr, [sp, #0xc]
    2160:      	b.gt	0x21ac <filter_inet+0x7c>
    2164:      	cmp	w10, #0x5
    2168:      	b.eq	0x21e0 <filter_inet+0xb0>
    216c:      	cmp	w10, #0x7
    2170:      	mov	x11, x1
    2174:      	b.ne	0x23b4 <filter_inet+0x284>
    2178:      	ldr	w9, [x0, #0x4]
    217c:      	mov	x8, xzr
    2180:      	cmp	w9, #0x13
    2184:      	b.le	0x2228 <filter_inet+0xf8>
    2188:      	cmp	w9, #0x17
    218c:      	b.gt	0x21c4 <filter_inet+0x94>
    2190:      	sub	w10, w9, #0x14
    2194:      	cmp	w10, #0x2
    2198:      	b.lo	0x2284 <filter_inet+0x154>
    219c:      	sub	w10, w9, #0x16
    21a0:      	cmp	w10, #0x2
    21a4:      	b.lo	0x227c <filter_inet+0x14c>
    21a8:      	b	0x23b4 <filter_inet+0x284>
    21ac:      	cmp	w10, #0x28
    21b0:      	b.eq	0x21f8 <filter_inet+0xc8>
    21b4:      	cmp	w10, #0x29
    21b8:      	mov	x11, x1
    21bc:      	b.eq	0x2178 <filter_inet+0x48>
    21c0:      	b	0x23b4 <filter_inet+0x284>
    21c4:      	cmp	w9, #0x1b
    21c8:      	b.gt	0x22c8 <filter_inet+0x198>
    21cc:      	cmp	w9, #0x18
    21d0:      	b.eq	0x2384 <filter_inet+0x254>
    21d4:      	cmp	w9, #0x19
    21d8:      	b.eq	0x22e8 <filter_inet+0x1b8>
    21dc:      	b	0x23b4 <filter_inet+0x284>
    21e0:      	mov	x11, xzr
    21e4:      	ldr	w9, [x0, #0x4]
    21e8:      	mov	x8, xzr
    21ec:      	cmp	w9, #0x13
    21f0:      	b.gt	0x2188 <filter_inet+0x58>
    21f4:      	b	0x2228 <filter_inet+0xf8>
    21f8:      	ldrh	w8, [x1]
    21fc:      	ldrh	w9, [x1, #0x2]
    2200:      	mov	x11, xzr
    2204:      	strh	w8, [sp, #0x36]
    2208:      	strh	w9, [sp, #0x30]
    220c:      	ldp	x8, x9, [x1, #0x8]
    2210:      	add	x1, sp, #0x10
    2214:      	stp	x8, x9, [sp, #0x10]
    2218:      	ldr	w9, [x0, #0x4]
    221c:      	mov	x8, xzr
    2220:      	cmp	w9, #0x13
    2224:      	b.gt	0x2188 <filter_inet+0x58>
    2228:      	cmp	w9, #0xf
    222c:      	b.le	0x2250 <filter_inet+0x120>
    2230:      	cmp	w9, #0x11
    2234:      	b.gt	0x226c <filter_inet+0x13c>
    2238:      	cmp	w9, #0x10
    223c:      	b.eq	0x227c <filter_inet+0x14c>
    2240:      	cmp	w9, #0x11
    2244:      	b.ne	0x23b4 <filter_inet+0x284>
    2248:      	ldrh	w8, [x1, #0x24]
    224c:      	b	0x249c <filter_inet+0x36c>
    2250:      	cmp	w9, #0xd
    2254:      	b.eq	0x2384 <filter_inet+0x254>
    2258:      	cmp	w9, #0xe
    225c:      	b.eq	0x22e8 <filter_inet+0x1b8>
    2260:      	cmp	w9, #0xf
    2264:      	b.eq	0x2284 <filter_inet+0x154>
    2268:      	b	0x23b4 <filter_inet+0x284>
    226c:      	cmp	w9, #0x12
    2270:      	b.eq	0x2284 <filter_inet+0x154>
    2274:      	cmp	w9, #0x13
    2278:      	b.ne	0x23b4 <filter_inet+0x284>
    227c:      	ldrh	w10, [x1, #0x22]
    2280:      	b	0x2288 <filter_inet+0x158>
    2284:      	ldrh	w10, [x1, #0x20]
    2288:      	mov	w19, wzr
    228c:      	mov	w20, wzr
    2290:      	mov	x21, xzr
    2294:      	str	w10, [sp, #0xc]
    2298:      	mov	x8, xzr
    229c:      	cmp	w9, #0x11
    22a0:      	b.gt	0x2300 <filter_inet+0x1d0>
    22a4:      	sub	w10, w9, #0xd
    22a8:      	cmp	w10, #0x2
    22ac:      	b.lo	0x2338 <filter_inet+0x208>
    22b0:      	sub	w10, w9, #0xf
    22b4:      	cmp	w10, #0x2
    22b8:      	b.lo	0x23ac <filter_inet+0x27c>
    22bc:      	cmp	w9, #0x11
    22c0:      	b.eq	0x24a0 <filter_inet+0x370>
    22c4:      	b	0x23b4 <filter_inet+0x284>
    22c8:      	cmp	w9, #0x1c
    22cc:      	b.eq	0x2498 <filter_inet+0x368>
    22d0:      	cmp	w9, #0x1d
    22d4:      	b.ne	0x23b4 <filter_inet+0x284>
    22d8:      	cmp	w10, #0x7
    22dc:      	b.ne	0x24f0 <filter_inet+0x3c0>
    22e0:      	cbnz	x11, 0x24fc <filter_inet+0x3cc>
    22e4:      	b	0x24a0 <filter_inet+0x370>
    22e8:      	ldp	w19, w20, [x1, #0x10]
    22ec:      	ldr	x21, [x1, #0x18]
    22f0:      	mov	w10, wzr
    22f4:      	mov	x8, xzr
    22f8:      	cmp	w9, #0x11
    22fc:      	b.le	0x22a4 <filter_inet+0x174>
    2300:      	cmp	w9, #0x19
    2304:      	b.hi	0x23a0 <filter_inet+0x270>
    2308:      	mov	w11, #0x1               // =1
    230c:      	mov	w12, #0x500000          // =5242880
    2310:      	lsl	w11, w11, w9
    2314:      	tst	w11, w12
    2318:      	b.ne	0x23cc <filter_inet+0x29c>
    231c:      	mov	w12, #0xa00000          // =10485760
    2320:      	tst	w11, w12
    2324:      	b.ne	0x23ec <filter_inet+0x2bc>
    2328:      	mov	w10, #0x1               // =1
    232c:      	lsl	w10, w10, w9
    2330:      	tst	w10, #0x3000000
    2334:      	b.eq	0x23a0 <filter_inet+0x270>
    2338:      	ldrh	w8, [x1, #0x26]
    233c:      	cmp	w8, #0xa
    2340:      	b.eq	0x240c <filter_inet+0x2dc>
    2344:      	cmp	w8, #0x2
    2348:      	b.ne	0x247c <filter_inet+0x34c>
    234c:      	ldr	w8, [x0, #0x10]
    2350:      	mov	x22, x0
    2354:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    2358:      	add	x9, sp, #0x5c
    235c:      	str	w8, [sp, #0x5c]
    2360:      	mov	w8, #0x1                // =1
    2364:      	add	x1, sp, #0x5c
    2368:      	ldr	x0, [x0]
    236c:      	blr	x8
    2370:      	cbz	x0, 0x24bc <filter_inet+0x38c>
    2374:      	mov	w8, #0x20               // =32
    2378:      	add	x1, sp, #0x3c
    237c:      	stp	w8, w19, [sp, #0x3c]
    2380:      	b	0x244c <filter_inet+0x31c>
    2384:      	ldp	w19, w20, [x1]
    2388:      	ldr	x21, [x1, #0x8]
    238c:      	mov	w10, wzr
    2390:      	mov	x8, xzr
    2394:      	cmp	w9, #0x11
    2398:      	b.le	0x22a4 <filter_inet+0x174>
    239c:      	b	0x2300 <filter_inet+0x1d0>
    23a0:      	sub	w9, w9, #0x12
    23a4:      	cmp	w9, #0x2
    23a8:      	b.hs	0x23b4 <filter_inet+0x284>
    23ac:      	add	x1, sp, #0xc
    23b0:      	b	0x24a4 <filter_inet+0x374>
    23b4:      	ldp	x20, x19, [sp, #0x70]
    23b8:      	mov	x0, x8
    23bc:      	ldr	x30, [sp, #0x50]
    23c0:      	ldp	x22, x21, [sp, #0x60]
    23c4:      	add	sp, sp, #0x80
    23c8:      	ret
    23cc:      	cmp	w10, #0x400
    23d0:      	cset	w8, lo
    23d4:      	ldp	x20, x19, [sp, #0x70]
    23d8:      	mov	x0, x8
    23dc:      	ldr	x30, [sp, #0x50]
    23e0:      	ldp	x22, x21, [sp, #0x60]
    23e4:      	add	sp, sp, #0x80
    23e8:      	ret
    23ec:      	cmp	w10, #0x3ff
    23f0:      	cset	w8, hi
    23f4:      	ldp	x20, x19, [sp, #0x70]
    23f8:      	mov	x0, x8
    23fc:      	ldr	x30, [sp, #0x50]
    2400:      	ldp	x22, x21, [sp, #0x60]
    2404:      	add	sp, sp, #0x80
    2408:      	ret
    240c:      	ldr	w8, [x0, #0x14]
    2410:      	mov	x22, x0
    2414:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    2418:      	add	x9, sp, #0x5c
    241c:      	str	w8, [sp, #0x5c]
    2420:      	mov	w8, #0x1                // =1
    2424:      	add	x1, sp, #0x5c
    2428:      	ldr	x0, [x0]
    242c:      	blr	x8
    2430:      	cbz	x0, 0x24bc <filter_inet+0x38c>
    2434:      	mov	w8, #0x80               // =128
    2438:      	add	x1, sp, #0x3c
    243c:      	stp	w20, w21, [sp, #0x44]
    2440:      	stp	w8, w19, [sp, #0x3c]
    2444:      	lsr	x8, x21, #32
    2448:      	str	w8, [sp, #0x4c]
    244c:      	mov	w8, #0x1                // =1
    2450:      	blr	x8
    2454:      	ldr	w8, [x22, #0x4]
    2458:      	sub	w9, w8, #0x18
    245c:      	cmp	w9, #0x2
    2460:      	b.lo	0x24cc <filter_inet+0x39c>
    2464:      	sub	w8, w8, #0xd
    2468:      	cmp	w8, #0x1
    246c:      	b.hi	0x247c <filter_inet+0x34c>
    2470:      	cmp	x0, #0x0
    2474:      	cset	w8, ne
    2478:      	b	0x24d4 <filter_inet+0x3a4>
    247c:      	mov	w8, wzr
    2480:      	ldp	x20, x19, [sp, #0x70]
    2484:      	mov	x0, x8
    2488:      	ldr	x30, [sp, #0x50]
    248c:      	ldp	x22, x21, [sp, #0x60]
    2490:      	add	sp, sp, #0x80
    2494:      	ret
    2498:      	ldrh	w8, [x1, #0x26]
    249c:      	str	w8, [sp, #0x58]
    24a0:      	add	x1, sp, #0x58
    24a4:      	bl	0xf20 <filter_32ty_map>
    24a8:      	ldp	x20, x19, [sp, #0x70]
    24ac:      	ldr	x30, [sp, #0x50]
    24b0:      	ldp	x22, x21, [sp, #0x60]
    24b4:      	add	sp, sp, #0x80
    24b8:      	ret
    24bc:      	ldr	w8, [x22, #0x4]
    24c0:      	and	w8, w8, #0xfffffffe
    24c4:      	cmp	w8, #0x18
    24c8:      	b	0x24d0 <filter_inet+0x3a0>
    24cc:      	cmp	x0, #0x0
    24d0:      	cset	w8, eq
    24d4:      	mov	w8, w8
    24d8:      	ldp	x20, x19, [sp, #0x70]
    24dc:      	mov	x0, x8
    24e0:      	ldr	x30, [sp, #0x50]
    24e4:      	ldp	x22, x21, [sp, #0x60]
    24e8:      	add	sp, sp, #0x80
    24ec:      	ret
    24f0:      	cmp	w10, #0x29
    24f4:      	b.ne	0x2504 <filter_inet+0x3d4>
    24f8:      	cbz	x11, 0x2504 <filter_inet+0x3d4>
    24fc:      	ldrb	w8, [x11, #0x3a]
    2500:      	str	w8, [sp, #0x58]
    2504:      	cmp	w10, #0x29
    2508:      	b.eq	0x24a0 <filter_inet+0x370>
    250c:      	cmp	w10, #0x7
    2510:      	b.eq	0x24a0 <filter_inet+0x370>
    2514:      	mov	x8, xzr
    2518:      	ldp	x20, x19, [sp, #0x70]
    251c:      	mov	x0, x8
    2520:      	ldr	x30, [sp, #0x50]
    2524:      	ldp	x22, x21, [sp, #0x60]
    2528:      	add	sp, sp, #0x80
    252c:      	ret

0000000000002530 <filter_sockaddr_un>:
    2530:      	sub	sp, sp, #0x20
    2534:      	stp	x30, x19, [sp, #0x10]
    2538:      	mov	x19, x0
    253c:      	ldrb	w2, [x1, #0x3]
    2540:      	mov	x0, xzr
    2544:      	ldr	w8, [x19, #0x4]
    2548:      	cmp	w8, #0x19
    254c:      	b.gt	0x25a0 <filter_sockaddr_un+0x70>
    2550:      	sub	w9, w8, #0x3
    2554:      	cmp	w9, #0x2
    2558:      	b.hs	0x25b4 <filter_sockaddr_un+0x84>
    255c:      	add	x1, x1, #0x4
    2560:      	mov	x0, x19
    2564:      	bl	0x2620 <filter_char_buf_equal>
    2568:      	ldr	w8, [x19, #0x4]
    256c:      	cmp	w8, #0x25
    2570:      	b.hi	0x2594 <filter_sockaddr_un+0x64>
    2574:      	mov	w9, #0x1                // =1
    2578:      	lsl	x8, x9, x8
    257c:      	mov	x9, #0x50               // =80
    2580:      	movk	x9, #0xc00, lsl #16
    2584:      	movk	x9, #0x20, lsl #32
    2588:      	tst	x8, x9
    258c:      	b.eq	0x2594 <filter_sockaddr_un+0x64>
    2590:      	eor	x0, x0, #0x1
    2594:      	ldp	x30, x19, [sp, #0x10]
    2598:      	add	sp, sp, #0x20
    259c:      	ret
    25a0:      	cmp	w8, #0x1c
    25a4:      	b.eq	0x2600 <filter_sockaddr_un+0xd0>
    25a8:      	cmp	w8, #0x1a
    25ac:      	b.eq	0x25bc <filter_sockaddr_un+0x8c>
    25b0:      	b	0x2594 <filter_sockaddr_un+0x64>
    25b4:      	cmp	w8, #0x8
    25b8:      	b.ne	0x2594 <filter_sockaddr_un+0x64>
    25bc:      	ldr	w0, [x19, #0x10]
    25c0:      	add	x1, x1, #0x4
    25c4:      	bl	0x2a50 <filter_char_buf_prefix>
    25c8:      	ldr	w8, [x19, #0x4]
    25cc:      	cmp	w8, #0x25
    25d0:      	b.hi	0x2594 <filter_sockaddr_un+0x64>
    25d4:      	mov	w9, #0x1                // =1
    25d8:      	lsl	x8, x9, x8
    25dc:      	mov	x9, #0x50               // =80
    25e0:      	movk	x9, #0xc00, lsl #16
    25e4:      	movk	x9, #0x20, lsl #32
    25e8:      	tst	x8, x9
    25ec:      	b.eq	0x2594 <filter_sockaddr_un+0x64>
    25f0:      	eor	x0, x0, #0x1
    25f4:      	ldp	x30, x19, [sp, #0x10]
    25f8:      	add	sp, sp, #0x20
    25fc:      	ret
    2600:      	ldrh	w8, [x1]
    2604:      	add	x1, sp, #0xc
    2608:      	mov	x0, x19
    260c:      	str	w8, [sp, #0xc]
    2610:      	bl	0xf20 <filter_32ty_map>
    2614:      	ldp	x30, x19, [sp, #0x10]
    2618:      	add	sp, sp, #0x20
    261c:      	ret

0000000000002620 <filter_char_buf_equal>:
    2620:      	str	x29, [sp, #-0x50]!
    2624:      	stp	x30, x25, [sp, #0x10]
    2628:      	stp	x24, x23, [sp, #0x20]
    262c:      	stp	x22, x21, [sp, #0x30]
    2630:      	stp	x20, x19, [sp, #0x40]
    2634:      	cmp	w2, #0x1, lsl #12       // =0x1000
    2638:      	str	wzr, [sp, #0x8]
    263c:      	b.ls	0x265c <filter_char_buf_equal+0x3c>
    2640:      	mov	x0, xzr
    2644:      	ldp	x20, x19, [sp, #0x40]
    2648:      	ldp	x22, x21, [sp, #0x30]
    264c:      	ldp	x24, x23, [sp, #0x20]
    2650:      	ldp	x30, x25, [sp, #0x10]
    2654:      	ldr	x29, [sp], #0x50
    2658:      	ret
    265c:      	and	w9, w2, #0xffff
    2660:      	add	x8, x0, #0x10
    2664:      	cmp	w9, #0x90
    2668:      	b.hi	0x26d8 <filter_char_buf_equal+0xb8>
    266c:      	and	w9, w2, #0xff
    2670:      	mov	w10, #0xab              // =171
    2674:      	tst	w2, #0xffff
    2678:      	mul	w9, w9, w10
    267c:      	mov	w10, #0x18              // =24
    2680:      	lsr	w9, w9, #12
    2684:      	msub	w9, w9, w10, w2
    2688:      	b.eq	0x2698 <filter_char_buf_equal+0x78>
    268c:      	tst	w9, #0xff
    2690:      	mov	w23, w2
    2694:      	b.eq	0x26b0 <filter_char_buf_equal+0x90>
    2698:      	sub	w9, w2, w9, uxtb
    269c:      	and	w10, w9, #0xffff
    26a0:      	add	w9, w9, #0x18
    26a4:      	and	w23, w9, #0xffff
    26a8:      	cmp	w10, #0x78
    26ac:      	b.hi	0x274c <filter_char_buf_equal+0x12c>
    26b0:      	and	w9, w23, #0xff
    26b4:      	mov	w10, #0xab              // =171
    26b8:      	mul	w9, w9, w10
    26bc:      	lsr	w9, w9, #12
    26c0:      	sub	w22, w9, #0x1
    26c4:      	and	w9, w22, #0xf
    26c8:      	ldr	w24, [x8, w9, uxtw #2]
    26cc:      	cmn	w24, #0x1
    26d0:      	b.ne	0x27c4 <filter_char_buf_equal+0x1a4>
    26d4:      	b	0x296c <filter_char_buf_equal+0x34c>
    26d8:      	cmp	w9, #0x101
    26dc:      	b.hs	0x271c <filter_char_buf_equal+0xfc>
    26e0:      	mov	w23, #0x100             // =256
    26e4:      	sub	w9, w23, #0x100
    26e8:      	ror	w9, w9, #0x8
    26ec:      	cmp	w9, #0x2
    26f0:      	b.le	0x275c <filter_char_buf_equal+0x13c>
    26f4:      	cmp	w9, #0x3
    26f8:      	b.eq	0x2798 <filter_char_buf_equal+0x178>
    26fc:      	cmp	w9, #0x7
    2700:      	b.ne	0x2780 <filter_char_buf_equal+0x160>
    2704:      	mov	w22, #0x9               // =9
    2708:      	and	w9, w22, #0xf
    270c:      	ldr	w24, [x8, w9, uxtw #2]
    2710:      	cmn	w24, #0x1
    2714:      	b.ne	0x27c4 <filter_char_buf_equal+0x1a4>
    2718:      	b	0x296c <filter_char_buf_equal+0x34c>
    271c:      	and	w9, w2, #0xffff
    2720:      	cmp	w9, #0x201
    2724:      	b.hs	0x2740 <filter_char_buf_equal+0x120>
    2728:      	mov	w23, #0x200             // =512
    272c:      	sub	w9, w23, #0x100
    2730:      	ror	w9, w9, #0x8
    2734:      	cmp	w9, #0x2
    2738:      	b.le	0x275c <filter_char_buf_equal+0x13c>
    273c:      	b	0x26f4 <filter_char_buf_equal+0xd4>
    2740:      	cmp	w9, #0x401
    2744:      	b.hs	0x2924 <filter_char_buf_equal+0x304>
    2748:      	mov	w23, #0x400             // =1024
    274c:      	sub	w9, w23, #0x100
    2750:      	ror	w9, w9, #0x8
    2754:      	cmp	w9, #0x2
    2758:      	b.gt	0x26f4 <filter_char_buf_equal+0xd4>
    275c:      	cbz	w9, 0x27b0 <filter_char_buf_equal+0x190>
    2760:      	cmp	w9, #0x1
    2764:      	b.ne	0x2780 <filter_char_buf_equal+0x160>
    2768:      	mov	w22, #0x7               // =7
    276c:      	and	w9, w22, #0xf
    2770:      	ldr	w24, [x8, w9, uxtw #2]
    2774:      	cmn	w24, #0x1
    2778:      	b.ne	0x27c4 <filter_char_buf_equal+0x1a4>
    277c:      	b	0x296c <filter_char_buf_equal+0x34c>
    2780:      	mov	w22, #0xa               // =10
    2784:      	and	w9, w22, #0xf
    2788:      	ldr	w24, [x8, w9, uxtw #2]
    278c:      	cmn	w24, #0x1
    2790:      	b.ne	0x27c4 <filter_char_buf_equal+0x1a4>
    2794:      	b	0x296c <filter_char_buf_equal+0x34c>
    2798:      	mov	w22, #0x8               // =8
    279c:      	and	w9, w22, #0xf
    27a0:      	ldr	w24, [x8, w9, uxtw #2]
    27a4:      	cmn	w24, #0x1
    27a8:      	b.ne	0x27c4 <filter_char_buf_equal+0x1a4>
    27ac:      	b	0x296c <filter_char_buf_equal+0x34c>
    27b0:      	mov	w22, #0x6               // =6
    27b4:      	and	w9, w22, #0xf
    27b8:      	ldr	w24, [x8, w9, uxtw #2]
    27bc:      	cmn	w24, #0x1
    27c0:      	b.eq	0x296c <filter_char_buf_equal+0x34c>
    27c4:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    27c8:      	add	x29, sp, #0x8
    27cc:      	mov	w8, #0x1                // =1
    27d0:      	ldr	x0, [x0]
    27d4:      	mov	x25, x1
    27d8:      	add	x1, sp, #0x8
    27dc:      	mov	w21, w2
    27e0:      	mov	w20, #0x1               // =1
    27e4:      	blr	x8
    27e8:      	mov	x19, x0
    27ec:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    27f0:      	add	x1, sp, #0x8
    27f4:      	ldr	x0, [x0]
    27f8:      	blr	x20
    27fc:      	mov	x20, x0
    2800:      	mov	x0, xzr
    2804:      	cbz	x19, 0x2644 <filter_char_buf_equal+0x24>
    2808:      	cbz	x20, 0x2644 <filter_char_buf_equal+0x24>
    280c:      	mov	x0, x19
    2810:      	cmp	w22, #0x5
    2814:      	b.gt	0x284c <filter_char_buf_equal+0x22c>
    2818:      	strb	w21, [x0], #0x1
    281c:      	mov	w29, w21
    2820:      	mov	w8, #0x4                // =4
    2824:      	mov	x2, x25
    2828:      	mov	w1, w21
    282c:      	blr	x8
    2830:      	subs	w8, w23, w21
    2834:      	b.ls	0x2884 <filter_char_buf_equal+0x264>
    2838:      	add	x9, x19, x29
    283c:      	and	w1, w8, #0xfff
    2840:      	mov	w8, #0x4                // =4
    2844:      	add	x0, x9, #0x1
    2848:      	b	0x287c <filter_char_buf_equal+0x25c>
    284c:      	strh	w21, [x0], #0x2
    2850:      	mov	w29, w21
    2854:      	mov	w8, #0x4                // =4
    2858:      	mov	x2, x25
    285c:      	mov	w1, w21
    2860:      	blr	x8
    2864:      	subs	w8, w23, w21
    2868:      	b.ls	0x2884 <filter_char_buf_equal+0x264>
    286c:      	add	x9, x19, x29
    2870:      	and	w1, w8, #0xfff
    2874:      	mov	w8, #0x4                // =4
    2878:      	add	x0, x9, #0x2
    287c:      	mov	x2, x20
    2880:      	blr	x8
    2884:      	cmp	w22, #0x4
    2888:      	str	w24, [sp, #0xc]
    288c:      	b.le	0x28c4 <filter_char_buf_equal+0x2a4>
    2890:      	cmp	w22, #0x7
    2894:      	b.gt	0x28f8 <filter_char_buf_equal+0x2d8>
    2898:      	cmp	w22, #0x5
    289c:      	b.eq	0x29ec <filter_char_buf_equal+0x3cc>
    28a0:      	cmp	w22, #0x6
    28a4:      	b.eq	0x29b0 <filter_char_buf_equal+0x390>
    28a8:      	cmp	w22, #0x7
    28ac:      	b.ne	0x296c <filter_char_buf_equal+0x34c>
    28b0:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    28b4:      	mov	w8, #0x1                // =1
    28b8:      	add	x9, sp, #0xc
    28bc:      	ldr	x0, [x0]
    28c0:      	b	0x2a10 <filter_char_buf_equal+0x3f0>
    28c4:      	cmp	w22, #0x1
    28c8:      	b.le	0x294c <filter_char_buf_equal+0x32c>
    28cc:      	cmp	w22, #0x2
    28d0:      	b.eq	0x29d8 <filter_char_buf_equal+0x3b8>
    28d4:      	cmp	w22, #0x3
    28d8:      	b.eq	0x299c <filter_char_buf_equal+0x37c>
    28dc:      	cmp	w22, #0x4
    28e0:      	b.ne	0x296c <filter_char_buf_equal+0x34c>
    28e4:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    28e8:      	mov	w8, #0x1                // =1
    28ec:      	add	x9, sp, #0xc
    28f0:      	ldr	x0, [x0]
    28f4:      	b	0x2a10 <filter_char_buf_equal+0x3f0>
    28f8:      	cmp	w22, #0x8
    28fc:      	b.eq	0x2a00 <filter_char_buf_equal+0x3e0>
    2900:      	cmp	w22, #0x9
    2904:      	b.eq	0x29c4 <filter_char_buf_equal+0x3a4>
    2908:      	cmp	w22, #0xa
    290c:      	b.ne	0x296c <filter_char_buf_equal+0x34c>
    2910:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    2914:      	mov	w8, #0x1                // =1
    2918:      	add	x9, sp, #0xc
    291c:      	ldr	x0, [x0]
    2920:      	b	0x2a10 <filter_char_buf_equal+0x3f0>
    2924:      	and	w9, w2, #0xffff
    2928:      	mov	w10, #0x1000            // =4096
    292c:      	cmp	w9, #0x800
    2930:      	mov	w9, #0x800              // =2048
    2934:      	csel	w23, w10, w9, hi
    2938:      	sub	w9, w23, #0x100
    293c:      	ror	w9, w9, #0x8
    2940:      	cmp	w9, #0x2
    2944:      	b.le	0x275c <filter_char_buf_equal+0x13c>
    2948:      	b	0x26f4 <filter_char_buf_equal+0xd4>
    294c:      	cbz	w22, 0x2988 <filter_char_buf_equal+0x368>
    2950:      	cmp	w22, #0x1
    2954:      	b.ne	0x296c <filter_char_buf_equal+0x34c>
    2958:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    295c:      	mov	w8, #0x1                // =1
    2960:      	add	x9, sp, #0xc
    2964:      	ldr	x0, [x0]
    2968:      	b	0x2a10 <filter_char_buf_equal+0x3f0>
    296c:      	mov	x0, xzr
    2970:      	ldp	x20, x19, [sp, #0x40]
    2974:      	ldp	x22, x21, [sp, #0x30]
    2978:      	ldp	x24, x23, [sp, #0x20]
    297c:      	ldp	x30, x25, [sp, #0x10]
    2980:      	ldr	x29, [sp], #0x50
    2984:      	ret
    2988:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    298c:      	mov	w8, #0x1                // =1
    2990:      	add	x9, sp, #0xc
    2994:      	ldr	x0, [x0]
    2998:      	b	0x2a10 <filter_char_buf_equal+0x3f0>
    299c:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    29a0:      	mov	w8, #0x1                // =1
    29a4:      	add	x9, sp, #0xc
    29a8:      	ldr	x0, [x0]
    29ac:      	b	0x2a10 <filter_char_buf_equal+0x3f0>
    29b0:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    29b4:      	mov	w8, #0x1                // =1
    29b8:      	add	x9, sp, #0xc
    29bc:      	ldr	x0, [x0]
    29c0:      	b	0x2a10 <filter_char_buf_equal+0x3f0>
    29c4:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    29c8:      	mov	w8, #0x1                // =1
    29cc:      	add	x9, sp, #0xc
    29d0:      	ldr	x0, [x0]
    29d4:      	b	0x2a10 <filter_char_buf_equal+0x3f0>
    29d8:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    29dc:      	mov	w8, #0x1                // =1
    29e0:      	add	x9, sp, #0xc
    29e4:      	ldr	x0, [x0]
    29e8:      	b	0x2a10 <filter_char_buf_equal+0x3f0>
    29ec:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    29f0:      	mov	w8, #0x1                // =1
    29f4:      	add	x9, sp, #0xc
    29f8:      	ldr	x0, [x0]
    29fc:      	b	0x2a10 <filter_char_buf_equal+0x3f0>
    2a00:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    2a04:      	mov	w8, #0x1                // =1
    2a08:      	add	x9, sp, #0xc
    2a0c:      	ldr	x0, [x0]
    2a10:      	add	x1, sp, #0xc
    2a14:      	blr	x8
    2a18:      	cbz	x0, 0x2644 <filter_char_buf_equal+0x24>
    2a1c:      	mov	w8, #0x1                // =1
    2a20:      	mov	x1, x19
    2a24:      	blr	x8
    2a28:      	cmp	x0, #0x0
    2a2c:      	cset	w0, ne
    2a30:      	ldp	x20, x19, [sp, #0x40]
    2a34:      	ldp	x22, x21, [sp, #0x30]
    2a38:      	ldp	x24, x23, [sp, #0x20]
    2a3c:      	ldp	x30, x25, [sp, #0x10]
    2a40:      	ldr	x29, [sp], #0x50
    2a44:      	ret
    2a48:      	nop
    2a4c:      	nop

0000000000002a50 <filter_char_buf_prefix>:
    2a50:      	sub	sp, sp, #0x30
    2a54:      	stp	x30, x21, [sp, #0x10]
    2a58:      	stp	x20, x19, [sp, #0x20]
    2a5c:      	stp	wzr, w0, [sp, #0x8]
    2a60:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    2a64:      	mov	w8, #0x1                // =1
    2a68:      	add	x9, sp, #0xc
    2a6c:      	ldr	x0, [x0]
    2a70:      	mov	x19, x1
    2a74:      	add	x1, sp, #0xc
    2a78:      	mov	w20, w2
    2a7c:      	blr	x8
    2a80:      	mov	x8, x0
    2a84:      	mov	x0, xzr
    2a88:      	cbz	w20, 0x2af4 <filter_char_buf_prefix+0xa4>
    2a8c:      	cbz	x8, 0x2af4 <filter_char_buf_prefix+0xa4>
    2a90:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    2a94:      	mov	x21, x8
    2a98:      	mov	w8, #0x1                // =1
    2a9c:      	ldr	x0, [x0]
    2aa0:      	add	x9, sp, #0x8
    2aa4:      	add	x1, sp, #0x8
    2aa8:      	blr	x8
    2aac:      	cbz	x0, 0x2af4 <filter_char_buf_prefix+0xa4>
    2ab0:      	cmp	w20, #0xff
    2ab4:      	mov	w8, #0xff               // =255
    2ab8:      	mov	x2, x19
    2abc:      	csel	w1, w20, w8, lo
    2ac0:      	mov	x8, x0
    2ac4:      	mov	x20, x0
    2ac8:      	lsl	w9, w1, #3
    2acc:      	str	w9, [x8], #0x4
    2ad0:      	mov	w9, #0x4                // =4
    2ad4:      	mov	x0, x8
    2ad8:      	blr	x9
    2adc:      	mov	w8, #0x1                // =1
    2ae0:      	mov	x0, x21
    2ae4:      	mov	x1, x20
    2ae8:      	blr	x8
    2aec:      	cmp	x0, #0x0
    2af0:      	cset	w0, ne
    2af4:      	ldp	x20, x19, [sp, #0x20]
    2af8:      	ldp	x30, x21, [sp, #0x10]
    2afc:      	add	sp, sp, #0x30
    2b00:      	ret
    2b04:      	nop
    2b08:      	nop
    2b0c:      	nop

0000000000002b10 <filter_char_buf_postfix>:
    2b10:      	sub	sp, sp, #0x30
    2b14:      	stp	x30, x21, [sp, #0x10]
    2b18:      	stp	x20, x19, [sp, #0x20]
    2b1c:      	stp	wzr, w0, [sp, #0x8]
    2b20:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    2b24:      	mov	w8, #0x1                // =1
    2b28:      	add	x9, sp, #0xc
    2b2c:      	ldr	x0, [x0]
    2b30:      	mov	x19, x1
    2b34:      	add	x1, sp, #0xc
    2b38:      	mov	w20, w2
    2b3c:      	blr	x8
    2b40:      	mov	x8, x0
    2b44:      	mov	x0, xzr
    2b48:      	cbz	w20, 0x2bdc <filter_char_buf_postfix+0xcc>
    2b4c:      	cbz	x8, 0x2bdc <filter_char_buf_postfix+0xcc>
    2b50:      	adrp	x0, 0x2000 <filter_file_buf+0xf0>
    2b54:      	mov	x21, x8
    2b58:      	mov	w8, #0x1                // =1
    2b5c:      	ldr	x0, [x0]
    2b60:      	add	x9, sp, #0x8
    2b64:      	add	x1, sp, #0x8
    2b68:      	blr	x8
    2b6c:      	cbz	x0, 0x2bdc <filter_char_buf_postfix+0xcc>
    2b70:      	cmp	w20, #0x7f
    2b74:      	mov	w9, #0x7f               // =127
    2b78:      	mov	x1, x0
    2b7c:      	mov	x8, xzr
    2b80:      	sub	w10, w20, #0x1
    2b84:      	csel	w9, w20, w9, lo
    2b88:      	lsl	w9, w9, #3
    2b8c:      	str	w9, [x0]
    2b90:      	mov	w9, w20
    2b94:      	nop
    2b98:      	nop
    2b9c:      	nop
    2ba0:      	cmp	x8, #0x7f
    2ba4:      	b.eq	0x2bc8 <filter_char_buf_postfix+0xb8>
    2ba8:      	and	x11, x10, #0xfff
    2bac:      	add	x12, x1, x8
    2bb0:      	add	x8, x8, #0x1
    2bb4:      	ldrb	w11, [x19, x11]
    2bb8:      	sub	w10, w10, #0x1
    2bbc:      	cmp	x9, x8
    2bc0:      	strb	w11, [x12, #0x4]
    2bc4:      	b.ne	0x2ba0 <filter_char_buf_postfix+0x90>
    2bc8:      	mov	w8, #0x1                // =1
    2bcc:      	mov	x0, x21
    2bd0:      	blr	x8
    2bd4:      	cmp	x0, #0x0
    2bd8:      	cset	w0, ne
    2bdc:      	ldp	x20, x19, [sp, #0x20]
    2be0:      	ldp	x30, x21, [sp, #0x10]
    2be4:      	add	sp, sp, #0x30
    2be8:      	ret
    2bec:      	nop

0000000000002bf0 <filter_file_type>:
    2bf0:      	sub	sp, sp, #0x20
    2bf4:      	stp	x30, x19, [sp, #0x10]
    2bf8:      	ldr	w8, [x1]
    2bfc:      	strh	wzr, [sp, #0xc]
    2c00:      	cmp	w8, #0x1, lsl #12       // =0x1000
    2c04:      	b.hi	0x2cdc <filter_file_type+0xec>
    2c08:      	add	x9, x1, #0x4
    2c0c:      	mov	w10, #0x2               // =2
    2c10:      	mov	w11, #0x4               // =4
    2c14:      	add	x12, sp, #0xc
    2c18:      	mov	x19, x0
    2c1c:      	add	x0, sp, #0xc
    2c20:      	add	x8, x9, x8
    2c24:      	add	x8, x8, #0x4
    2c28:      	ldr	w8, [x1]
    2c2c:      	mov	w1, #0x2                // =2
    2c30:      	add	x8, x9, x8
    2c34:      	add	x2, x8, #0x4
    2c38:      	blr	x11
    2c3c:      	ldr	w9, [x19, #0x10]
    2c40:      	cbz	w9, 0x2cdc <filter_file_type+0xec>
    2c44:      	ldrh	w8, [sp, #0xc]
    2c48:      	and	w8, w8, #0xf000
    2c4c:      	cmp	w9, w8
    2c50:      	b.ne	0x2c64 <filter_file_type+0x74>
    2c54:      	mov	w0, #0x1                // =1
    2c58:      	ldp	x30, x19, [sp, #0x10]
    2c5c:      	add	sp, sp, #0x20
    2c60:      	ret
    2c64:      	ldr	w9, [x19, #0x8]
    2c68:      	cmp	w9, #0xc
    2c6c:      	b.ls	0x2cdc <filter_file_type+0xec>
    2c70:      	ldr	w10, [x19, #0x14]
    2c74:      	cbz	w10, 0x2cdc <filter_file_type+0xec>
    2c78:      	cmp	w10, w8
    2c7c:      	b.ne	0x2c90 <filter_file_type+0xa0>
    2c80:      	mov	w0, #0x1                // =1
    2c84:      	ldp	x30, x19, [sp, #0x10]
    2c88:      	add	sp, sp, #0x20
    2c8c:      	ret
    2c90:      	cmp	w9, #0x11
    2c94:      	b.lo	0x2cdc <filter_file_type+0xec>
    2c98:      	ldr	w10, [x19, #0x18]
    2c9c:      	cbz	w10, 0x2cdc <filter_file_type+0xec>
    2ca0:      	cmp	w10, w8
    2ca4:      	b.ne	0x2cb8 <filter_file_type+0xc8>
    2ca8:      	mov	w0, #0x1                // =1
    2cac:      	ldp	x30, x19, [sp, #0x10]
    2cb0:      	add	sp, sp, #0x20
    2cb4:      	ret
    2cb8:      	cmp	w9, #0x15
    2cbc:      	b.lo	0x2cdc <filter_file_type+0xec>
    2cc0:      	ldr	w9, [x19, #0x1c]
    2cc4:      	cbz	w9, 0x2cdc <filter_file_type+0xec>
    2cc8:      	cmp	w9, w8
    2ccc:      	cset	w0, eq
    2cd0:      	ldp	x30, x19, [sp, #0x10]
    2cd4:      	add	sp, sp, #0x20
    2cd8:      	ret
    2cdc:      	mov	x0, xzr
    2ce0:      	ldp	x30, x19, [sp, #0x10]
    2ce4:      	add	sp, sp, #0x20
    2ce8:      	ret
    2cec:      	nop

0000000000002cf0 <filter_char_substring>:
    2cf0:      	str	x29, [sp, #-0x50]!
    2cf4:      	stp	x30, x25, [sp, #0x10]
    2cf8:      	stp	x24, x23, [sp, #0x20]
    2cfc:      	stp	x22, x21, [sp, #0x30]
    2d00:      	stp	x20, x19, [sp, #0x40]
    2d04:      	mov	x21, x1
    2d08:      	mov	x19, x0
    2d0c:      	add	x23, x0, #0x10
    2d10:      	mov	w24, w2
    2d14:      	tbz	w3, #0x0, 0x2e08 <filter_char_substring+0x118>
    2d18:      	cbz	w2, 0x2ec8 <filter_char_substring+0x1d8>
    2d1c:      	adrp	x22, 0x2000 <filter_file_buf+0xf0>
    2d20:      	mov	x25, xzr
    2d24:      	mov	w29, wzr
    2d28:      	ldr	x22, [x22]
    2d2c:      	add	x20, sp, #0xc
    2d30:      	nop
    2d34:      	nop
    2d38:      	nop
    2d3c:      	nop
    2d40:      	ldr	w8, [x23, x25, lsl #2]
    2d44:      	add	x1, sp, #0xc
    2d48:      	mov	x0, x22
    2d4c:      	str	w8, [sp, #0xc]
    2d50:      	mov	w8, #0x1                // =1
    2d54:      	blr	x8
    2d58:      	cbz	x0, 0x2f68 <filter_char_substring+0x278>
    2d5c:      	mov	x8, xzr
    2d60:      	mov	x9, x21
    2d64:      	mov	x10, x24
    2d68:      	b	0x2d80 <filter_char_substring+0x90>
    2d6c:      	add	x8, x8, #0x1
    2d70:      	sub	x10, x10, #0x1
    2d74:      	add	x9, x9, #0x1
    2d78:      	cmp	x8, x24
    2d7c:      	b.eq	0x2de4 <filter_char_substring+0xf4>
    2d80:      	mov	x11, xzr
    2d84:      	cmp	x10, x11
    2d88:      	b.eq	0x2d6c <filter_char_substring+0x7c>
    2d8c:      	ldrb	w12, [x0, x11]
    2d90:      	cbz	w12, 0x2de0 <filter_char_substring+0xf0>
    2d94:      	ldrb	w13, [x9, x11]
    2d98:      	sub	w14, w13, #0x41
    2d9c:      	orr	w15, w13, #0x20
    2da0:      	cmp	w14, #0x1a
    2da4:      	sub	w14, w12, #0x41
    2da8:      	csel	w13, w15, w13, lo
    2dac:      	orr	w15, w12, #0x20
    2db0:      	cmp	w14, #0x1a
    2db4:      	csel	w12, w15, w12, lo
    2db8:      	cmp	x11, #0x62
    2dbc:      	b.hi	0x2d6c <filter_char_substring+0x7c>
    2dc0:      	add	x11, x11, #0x1
    2dc4:      	cmp	w13, w12
    2dc8:      	b.eq	0x2d84 <filter_char_substring+0x94>
    2dcc:      	b	0x2d6c <filter_char_substring+0x7c>
    2dd0:      	nop
    2dd4:      	nop
    2dd8:      	nop
    2ddc:      	nop
    2de0:      	tbz	w8, #0x1f, 0x2f80 <filter_char_substring+0x290>
    2de4:      	ldr	w9, [x19, #0x8]
    2de8:      	add	w8, w29, #0xc
    2dec:      	cmp	w8, w9
    2df0:      	b.hs	0x2f64 <filter_char_substring+0x274>
    2df4:      	add	x25, x25, #0x1
    2df8:      	add	w29, w29, #0x4
    2dfc:      	cmp	x25, #0x64
    2e00:      	b.ne	0x2d40 <filter_char_substring+0x50>
    2e04:      	b	0x2f64 <filter_char_substring+0x274>
    2e08:      	cbz	w2, 0x2f1c <filter_char_substring+0x22c>
    2e0c:      	adrp	x22, 0x2000 <filter_file_buf+0xf0>
    2e10:      	mov	x25, xzr
    2e14:      	mov	w29, wzr
    2e18:      	ldr	x22, [x22]
    2e1c:      	add	x20, sp, #0xc
    2e20:      	ldr	w8, [x23, x25, lsl #2]
    2e24:      	add	x1, sp, #0xc
    2e28:      	mov	x0, x22
    2e2c:      	str	w8, [sp, #0xc]
    2e30:      	mov	w8, #0x1                // =1
    2e34:      	blr	x8
    2e38:      	cbz	x0, 0x2f68 <filter_char_substring+0x278>
    2e3c:      	mov	x8, xzr
    2e40:      	mov	x9, x21
    2e44:      	mov	x10, x24
    2e48:      	b	0x2e60 <filter_char_substring+0x170>
    2e4c:      	add	x8, x8, #0x1
    2e50:      	sub	x10, x10, #0x1
    2e54:      	add	x9, x9, #0x1
    2e58:      	cmp	x8, x24
    2e5c:      	b.eq	0x2ea4 <filter_char_substring+0x1b4>
    2e60:      	mov	x11, xzr
    2e64:      	cmp	x10, x11
    2e68:      	b.eq	0x2e4c <filter_char_substring+0x15c>
    2e6c:      	ldrb	w12, [x0, x11]
    2e70:      	cbz	w12, 0x2ea0 <filter_char_substring+0x1b0>
    2e74:      	cmp	x11, #0x62
    2e78:      	b.hi	0x2e4c <filter_char_substring+0x15c>
    2e7c:      	ldrb	w13, [x9, x11]
    2e80:      	add	x11, x11, #0x1
    2e84:      	cmp	w13, w12
    2e88:      	b.eq	0x2e64 <filter_char_substring+0x174>
    2e8c:      	b	0x2e4c <filter_char_substring+0x15c>
    2e90:      	nop
    2e94:      	nop
    2e98:      	nop
    2e9c:      	nop
    2ea0:      	tbz	w8, #0x1f, 0x2f80 <filter_char_substring+0x290>
    2ea4:      	ldr	w9, [x19, #0x8]
    2ea8:      	add	w8, w29, #0xc
    2eac:      	cmp	w8, w9
    2eb0:      	b.hs	0x2f64 <filter_char_substring+0x274>
    2eb4:      	add	x25, x25, #0x1
    2eb8:      	add	w29, w29, #0x4
    2ebc:      	cmp	x25, #0x64
    2ec0:      	b.ne	0x2e20 <filter_char_substring+0x130>
    2ec4:      	b	0x2f64 <filter_char_substring+0x274>
    2ec8:      	adrp	x20, 0x2000 <filter_file_buf+0xf0>
    2ecc:      	mov	w21, #0x10              // =16
    2ed0:      	add	x22, sp, #0xc
    2ed4:      	ldr	x20, [x20]
    2ed8:      	nop
    2edc:      	nop
    2ee0:      	ldr	w8, [x19, x21]
    2ee4:      	add	x1, sp, #0xc
    2ee8:      	mov	x0, x20
    2eec:      	str	w8, [sp, #0xc]
    2ef0:      	mov	w8, #0x1                // =1
    2ef4:      	blr	x8
    2ef8:      	cbz	x0, 0x2f68 <filter_char_substring+0x278>
    2efc:      	ldr	w8, [x19, #0x8]
    2f00:      	add	x21, x21, #0x4
    2f04:      	sub	w9, w21, #0x8
    2f08:      	cmp	w9, w8
    2f0c:      	b.hs	0x2f64 <filter_char_substring+0x274>
    2f10:      	cmp	x21, #0x1a0
    2f14:      	b.ne	0x2ee0 <filter_char_substring+0x1f0>
    2f18:      	b	0x2f64 <filter_char_substring+0x274>
    2f1c:      	adrp	x20, 0x2000 <filter_file_buf+0xf0>
    2f20:      	mov	w21, #0x10              // =16
    2f24:      	add	x22, sp, #0xc
    2f28:      	ldr	x20, [x20]
    2f2c:      	ldr	w8, [x19, x21]
    2f30:      	add	x1, sp, #0xc
    2f34:      	mov	x0, x20
    2f38:      	str	w8, [sp, #0xc]
    2f3c:      	mov	w8, #0x1                // =1
    2f40:      	blr	x8
    2f44:      	cbz	x0, 0x2f68 <filter_char_substring+0x278>
    2f48:      	ldr	w8, [x19, #0x8]
    2f4c:      	add	x21, x21, #0x4
    2f50:      	sub	w9, w21, #0x8
    2f54:      	cmp	w9, w8
    2f58:      	b.hs	0x2f64 <filter_char_substring+0x274>
    2f5c:      	cmp	x21, #0x1a0
    2f60:      	b.ne	0x2f2c <filter_char_substring+0x23c>
    2f64:      	mov	x0, xzr
    2f68:      	ldp	x20, x19, [sp, #0x40]
    2f6c:      	ldp	x22, x21, [sp, #0x30]
    2f70:      	ldp	x24, x23, [sp, #0x20]
    2f74:      	ldp	x30, x25, [sp, #0x10]
    2f78:      	ldr	x29, [sp], #0x50
    2f7c:      	ret
    2f80:      	mov	w0, #0x1                // =1
    2f84:      	ldp	x20, x19, [sp, #0x40]
    2f88:      	ldp	x22, x21, [sp, #0x30]
    2f8c:      	ldp	x24, x23, [sp, #0x20]
    2f90:      	ldp	x30, x25, [sp, #0x10]
    2f94:      	ldr	x29, [sp], #0x50
    2f98:      	ret
    2f9c:      	nop

0000000000002fa0 <do_action>:
    2fa0:      	sub	sp, sp, #0xc0
    2fa4:      	str	x29, [sp, #0x70]
    2fa8:      	stp	x30, x25, [sp, #0x80]
    2fac:      	stp	x24, x23, [sp, #0x90]
    2fb0:      	stp	x22, x21, [sp, #0xa0]
    2fb4:      	stp	x20, x19, [sp, #0xb0]
    2fb8:      	add	x8, x2, w1, uxtw #2
    2fbc:      	str	wzr, [sp, #0x44]
    2fc0:      	adrp	x24, 0x2000 <filter_file_buf+0xf0>
    2fc4:      	add	x9, sp, #0x44
    2fc8:      	mov	w19, w1
    2fcc:      	ldrsw	x20, [x8, #0x4]
    2fd0:      	ldr	x24, [x24]
    2fd4:      	mov	w8, #0x1                // =1
    2fd8:      	mov	x22, x0
    2fdc:      	add	x1, sp, #0x44
    2fe0:      	mov	w25, w4
    2fe4:      	mov	x23, x3
    2fe8:      	mov	x21, x2
    2fec:      	mov	x0, x24
    2ff0:      	blr	x8
    2ff4:      	cbz	x0, 0x3938 <do_action+0x998>
    2ff8:      	mov	x29, x0
    2ffc:      	cmp	w20, #0x7
    3000:      	b.gt	0x3024 <do_action+0x84>
    3004:      	cmp	w20, #0x3
    3008:      	b.gt	0x306c <do_action+0xcc>
    300c:      	cmp	w20, #0x1
    3010:      	b.gt	0x319c <do_action+0x1fc>
    3014:      	cbz	w20, 0x3428 <do_action+0x488>
    3018:      	cmp	w20, #0x1
    301c:      	b.eq	0x31ac <do_action+0x20c>
    3020:      	b	0x3930 <do_action+0x990>
    3024:      	cmp	w20, #0xb
    3028:      	b.gt	0x3170 <do_action+0x1d0>
    302c:      	sub	w8, w20, #0xa
    3030:      	cmp	w8, #0x2
    3034:      	b.lo	0x32a0 <do_action+0x300>
    3038:      	cmp	w20, #0x8
    303c:      	b.eq	0x32ec <do_action+0x34c>
    3040:      	cmp	w20, #0x9
    3044:      	b.ne	0x3930 <do_action+0x990>
    3048:      	add	w19, w19, #0x1
    304c:      	add	x8, x21, w19, uxtw #2
    3050:      	ldr	w0, [x8, #0x4]
    3054:      	tbz	w25, #0x0, 0x34d4 <do_action+0x534>
    3058:      	sxtw	x8, w0
    305c:      	mov	w9, #0x6d               // =109
    3060:      	blr	x9
    3064:      	mov	w21, #0x2               // =2
    3068:      	b	0x38f4 <do_action+0x954>
    306c:      	sub	w8, w20, #0x6
    3070:      	cmp	w8, #0x2
    3074:      	b.lo	0x32d8 <do_action+0x338>
    3078:      	cmp	w20, #0x4
    307c:      	b.eq	0x32f4 <do_action+0x354>
    3080:      	cmp	w20, #0x5
    3084:      	b.ne	0x3930 <do_action+0x990>
    3088:      	add	w9, w19, #0x1
    308c:      	add	x8, x21, #0x4
    3090:      	add	w19, w19, #0x2
    3094:      	ldr	w9, [x8, w9, uxtw #2]
    3098:      	and	x9, x9, #0x7
    309c:      	cmp	w9, #0x4
    30a0:      	b.hi	0x3930 <do_action+0x990>
    30a4:      	add	x10, x29, x9, lsl #2
    30a8:      	mov	w11, #0x5ea0            // =24224
    30ac:      	ldr	w10, [x10, x11]
    30b0:      	cbnz	w10, 0x3930 <do_action+0x990>
    30b4:      	ldr	w22, [x8, w19, uxtw #2]
    30b8:      	add	x8, x29, x9, lsl #3
    30bc:      	ldr	x8, [x8, #0x5e78]
    30c0:      	str	wzr, [sp, #0x54]
    30c4:      	and	x8, x8, #0x7ff
    30c8:      	add	x8, x29, x8
    30cc:      	ldr	w8, [x8, #0x90]
    30d0:      	str	w8, [sp, #0x50]
    30d4:      	mov	w8, #0xe                // =14
    30d8:      	blr	x8
    30dc:      	lsr	x8, x0, #32
    30e0:      	adrp	x21, 0x3000 <do_action+0x60>
    30e4:      	add	x9, sp, #0x48
    30e8:      	str	x8, [sp, #0x48]
    30ec:      	mov	w8, #0x1                // =1
    30f0:      	add	x1, sp, #0x48
    30f4:      	ldr	x21, [x21]
    30f8:      	mov	x0, x21
    30fc:      	blr	x8
    3100:      	cbz	x0, 0x3930 <do_action+0x990>
    3104:      	and	x8, x22, #0x7
    3108:      	cmp	w8, #0x4
    310c:      	b.hi	0x3930 <do_action+0x990>
    3110:      	add	x9, x29, x8, lsl #2
    3114:      	mov	w10, #0x5ea0            // =24224
    3118:      	ldr	w9, [x9, x10]
    311c:      	cbnz	w9, 0x3930 <do_action+0x990>
    3120:      	add	x8, x29, x8, lsl #3
    3124:      	mov	x22, x0
    3128:      	ldr	x8, [x8, #0x5e78]
    312c:      	str	wzr, [sp, #0x54]
    3130:      	and	x8, x8, #0x7ff
    3134:      	add	x8, x29, x8
    3138:      	ldr	w8, [x8, #0x90]
    313c:      	str	w8, [sp, #0x50]
    3140:      	mov	w8, #0xe                // =14
    3144:      	blr	x8
    3148:      	lsr	x8, x0, #32
    314c:      	mov	x3, xzr
    3150:      	add	x9, sp, #0x48
    3154:      	str	x8, [sp, #0x48]
    3158:      	mov	w8, #0x2                // =2
    315c:      	add	x1, sp, #0x48
    3160:      	mov	x0, x21
    3164:      	mov	x2, x22
    3168:      	blr	x8
    316c:      	b	0x3930 <do_action+0x990>
    3170:      	cmp	w20, #0xc
    3174:      	b.eq	0x34dc <do_action+0x53c>
    3178:      	cmp	w20, #0xd
    317c:      	b.eq	0x3398 <do_action+0x3f8>
    3180:      	cmp	w20, #0xe
    3184:      	b.ne	0x3930 <do_action+0x990>
    3188:      	tst	w25, #0x1
    318c:      	mov	w8, #0x8                // =8
    3190:      	add	w19, w19, #0x2
    3194:      	cinc	x21, x8, eq
    3198:      	b	0x38f4 <do_action+0x954>
    319c:      	cmp	w20, #0x2
    31a0:      	b.eq	0x34cc <do_action+0x52c>
    31a4:      	cmp	w20, #0x3
    31a8:      	b.ne	0x3930 <do_action+0x990>
    31ac:      	add	w8, w19, #0x1
    31b0:      	add	x9, x21, #0x4
    31b4:      	add	w19, w19, #0x2
    31b8:      	str	wzr, [sp, #0x58]
    31bc:      	ldr	w22, [x9, w8, uxtw #2]
    31c0:      	adrp	x0, 0x3000 <do_action+0x60>
    31c4:      	ldr	w21, [x9, w19, uxtw #2]
    31c8:      	ldr	x0, [x0]
    31cc:      	mov	w8, #0x1                // =1
    31d0:      	add	x9, sp, #0x58
    31d4:      	add	x1, sp, #0x58
    31d8:      	blr	x8
    31dc:      	cbz	x0, 0x32cc <do_action+0x32c>
    31e0:      	and	x8, x22, #0x7
    31e4:      	cmp	w8, #0x4
    31e8:      	b.hi	0x32c8 <do_action+0x328>
    31ec:      	add	x9, x29, x8, lsl #2
    31f0:      	mov	w10, #0x5ea0            // =24224
    31f4:      	ldr	w9, [x9, x10]
    31f8:      	cbnz	w9, 0x32c8 <do_action+0x328>
    31fc:      	add	x8, x29, x8, lsl #3
    3200:      	mov	x22, x0
    3204:      	ldr	x8, [x8, #0x5e78]
    3208:      	str	wzr, [sp, #0x54]
    320c:      	and	x8, x8, #0x7ff
    3210:      	add	x8, x29, x8
    3214:      	ldr	w8, [x8, #0x90]
    3218:      	str	w8, [sp, #0x50]
    321c:      	mov	w8, #0xe                // =14
    3220:      	blr	x8
    3224:      	lsr	x8, x0, #32
    3228:      	cmp	w20, #0x1
    322c:      	str	x8, [sp, #0x48]
    3230:      	b.ne	0x3600 <do_action+0x660>
    3234:      	and	x8, x21, #0x7
    3238:      	cmp	w8, #0x4
    323c:      	b.hi	0x32c8 <do_action+0x328>
    3240:      	add	x9, x29, x8, lsl #2
    3244:      	mov	w10, #0x5ea0            // =24224
    3248:      	ldr	w9, [x9, x10]
    324c:      	cbnz	w9, 0x32c8 <do_action+0x328>
    3250:      	add	x8, x29, x8, lsl #3
    3254:      	mov	x0, x22
    3258:      	mov	x21, x22
    325c:      	ldr	x8, [x8, #0x5e78]
    3260:      	and	x8, x8, #0x7ff
    3264:      	add	x2, x29, x8
    3268:      	ldr	w8, [x2, #0x90]!
    326c:      	and	x8, x8, #0xfff
    3270:      	add	x1, x8, #0x8
    3274:      	mov	w8, #0x4                // =4
    3278:      	blr	x8
    327c:      	adrp	x0, 0x3000 <do_action+0x60>
    3280:      	mov	x3, xzr
    3284:      	mov	w8, #0x2                // =2
    3288:      	ldr	x0, [x0]
    328c:      	add	x9, sp, #0x48
    3290:      	add	x1, sp, #0x48
    3294:      	mov	x2, x22
    3298:      	blr	x8
    329c:      	b	0x32c8 <do_action+0x328>
    32a0:      	add	w19, w19, #0x1
    32a4:      	add	x8, x21, w19, uxtw #2
    32a8:      	ldr	w8, [x8, #0x4]
    32ac:      	and	x8, x8, #0x7
    32b0:      	cmp	w8, #0x4
    32b4:      	b.hi	0x32c8 <do_action+0x328>
    32b8:      	add	x9, x29, x8, lsl #2
    32bc:      	mov	w10, #0x5ea0            // =24224
    32c0:      	ldr	w9, [x9, x10]
    32c4:      	cbz	w9, 0x34f8 <do_action+0x558>
    32c8:      	mov	w0, wzr
    32cc:      	cbz	w0, 0x3930 <do_action+0x990>
    32d0:      	mov	w0, wzr
    32d4:      	b	0x3938 <do_action+0x998>
    32d8:      	add	w19, w19, #0x1
    32dc:      	add	x8, x21, w19, uxtw #2
    32e0:      	ldr	w8, [x8, #0x4]
    32e4:      	str	w8, [x29, #0x78]
    32e8:      	b	0x3930 <do_action+0x990>
    32ec:      	strb	wzr, [x23]
    32f0:      	b	0x3930 <do_action+0x990>
    32f4:      	add	w19, w19, #0x1
    32f8:      	tbz	w25, #0x0, 0x34f0 <do_action+0x550>
    32fc:      	add	x8, x21, w19, uxtw #2
    3300:      	ldr	w24, [x8, #0x4]
    3304:      	mov	w8, #0xe                // =14
    3308:      	str	w24, [sp, #0x7c]
    330c:      	blr	x8
    3310:      	str	x0, [sp, #0x58]
    3314:      	adrp	x21, 0x3000 <do_action+0x60>
    3318:      	mov	w8, #0x1                // =1
    331c:      	add	x9, sp, #0x58
    3320:      	ldr	x21, [x21]
    3324:      	add	x1, sp, #0x58
    3328:      	mov	x0, x21
    332c:      	blr	x8
    3330:      	mov	x22, x0
    3334:      	cbz	x0, 0x3340 <do_action+0x3a0>
    3338:      	cmn	x22, #0xfff
    333c:      	b.lo	0x38ec <do_action+0x94c>
    3340:      	cmp	x22, #0x0
    3344:      	mov	w8, #0x2                // =2
    3348:      	adrp	x23, 0x3000 <do_action+0x60>
    334c:      	mov	w9, #0x1                // =1
    3350:      	add	x1, sp, #0x48
    3354:      	mov	w25, #0x1               // =1
    3358:      	csneg	w8, w8, w22, eq
    335c:      	strh	w8, [sp, #0x48]
    3360:      	mov	w8, #0xa                // =10
    3364:      	strh	w8, [sp, #0x4a]
    3368:      	mov	x8, #0x3a               // =58
    336c:      	movk	x8, #0x1, lsl #32
    3370:      	stur	x8, [sp, #0x4c]
    3374:      	add	x8, sp, #0x48
    3378:      	ldr	x23, [x23]
    337c:      	mov	x0, x23
    3380:      	blr	x9
    3384:      	cbz	x0, 0x38c4 <do_action+0x924>
    3388:      	ldr	w8, [x0]
    338c:      	add	w8, w8, #0x1
    3390:      	str	w8, [x0]
    3394:      	b	0x38e8 <do_action+0x948>
    3398:      	mov	w8, #0xe                // =14
    339c:      	blr	x8
    33a0:      	str	x0, [sp, #0x68]
    33a4:      	adrp	x21, 0x3000 <do_action+0x60>
    33a8:      	add	x8, sp, #0x68
    33ac:      	mov	w9, #0x1                // =1
    33b0:      	ldr	x21, [x21]
    33b4:      	add	x1, sp, #0x68
    33b8:      	mov	w23, #0x1               // =1
    33bc:      	mov	x0, x21
    33c0:      	blr	x9
    33c4:      	cbz	x0, 0x3930 <do_action+0x990>
    33c8:      	ldur	x8, [x0, #0x4]
    33cc:      	adrp	x22, 0x3000 <do_action+0x60>
    33d0:      	mov	w9, #0x1                // =1
    33d4:      	add	x1, sp, #0x58
    33d8:      	str	x8, [sp, #0x58]
    33dc:      	mov	w8, #0x2                // =2
    33e0:      	str	w8, [sp, #0x60]
    33e4:      	add	x8, sp, #0x58
    33e8:      	ldr	x22, [x22]
    33ec:      	mov	x0, x22
    33f0:      	blr	x9
    33f4:      	str	w23, [sp, #0x78]
    33f8:      	cbz	x0, 0x3584 <do_action+0x5e4>
    33fc:      	nop
    3400:      	ldaxr	w8, [x0]
    3404:      	add	w8, w8, #0x1
    3408:      	stlxr	w9, w8, [x0]
    340c:      	cbnz	w9, 0x3400 <do_action+0x460>
    3410:      	mov	w8, #0x3                // =3
    3414:      	add	x9, sp, #0x68
    3418:      	add	x1, sp, #0x68
    341c:      	mov	x0, x21
    3420:      	blr	x8
    3424:      	b	0x3930 <do_action+0x990>
    3428:      	add	w8, w19, #0x1
    342c:      	add	x9, x21, #0x4
    3430:      	str	x22, [sp, #0x30]
    3434:      	ldr	w25, [x9, w8, uxtw #2]
    3438:      	add	w8, w19, #0x2
    343c:      	ldr	w22, [x9, w8, uxtw #2]
    3440:      	mov	w8, #0x7d               // =125
    3444:      	blr	x8
    3448:      	str	x0, [sp, #0x8]
    344c:      	str	x0, [sp, #0x48]
    3450:      	str	wzr, [sp, #0x68]
    3454:      	cbz	w25, 0x382c <do_action+0x88c>
    3458:      	adrp	x0, 0x3000 <do_action+0x60>
    345c:      	mov	w8, #0x1                // =1
    3460:      	add	x9, sp, #0x68
    3464:      	ldr	x0, [x0]
    3468:      	add	x1, sp, #0x68
    346c:      	blr	x8
    3470:      	cbz	x0, 0x382c <do_action+0x88c>
    3474:      	mov	x10, x0
    3478:      	adrp	x0, 0x3000 <do_action+0x60>
    347c:      	mov	w8, #0x1                // =1
    3480:      	ldr	x0, [x0]
    3484:      	add	x9, sp, #0x68
    3488:      	add	x1, sp, #0x68
    348c:      	str	x10, [sp, #0x10]
    3490:      	blr	x8
    3494:      	ldr	x9, [sp, #0x10]
    3498:      	ldr	x8, [x29, #0x60]
    349c:      	mov	x2, x0
    34a0:      	cmp	w22, #0x2
    34a4:      	str	x8, [x9]
    34a8:      	ldr	x8, [x29, #0x70]
    34ac:      	str	x8, [x9, #0x8]
    34b0:      	b.eq	0x3644 <do_action+0x6a4>
    34b4:      	cmp	w22, #0x1
    34b8:      	b.eq	0x3638 <do_action+0x698>
    34bc:      	cbnz	w22, 0x382c <do_action+0x88c>
    34c0:      	ldr	w8, [x29, #0x7c]
    34c4:      	str	x25, [sp]
    34c8:      	b	0x364c <do_action+0x6ac>
    34cc:      	mov	w0, #0x9                // =9
    34d0:      	tbnz	w25, #0x0, 0x3058 <do_action+0xb8>
    34d4:      	mov	w21, #0x3               // =3
    34d8:      	b	0x38f4 <do_action+0x954>
    34dc:      	tst	w25, #0x1
    34e0:      	mov	w8, #0x6                // =6
    34e4:      	add	w19, w19, #0x3
    34e8:      	cinc	x21, x8, eq
    34ec:      	b	0x38f4 <do_action+0x954>
    34f0:      	mov	w21, #0x5               // =5
    34f4:      	b	0x38f4 <do_action+0x954>
    34f8:      	add	x8, x29, x8, lsl #3
    34fc:      	ldr	x8, [x8, #0x5e78]
    3500:      	and	x8, x8, #0x7ff
    3504:      	add	x8, x29, x8
    3508:      	ldr	x8, [x8, #0xb8]
    350c:      	str	x8, [sp, #0x58]
    3510:      	cbz	x8, 0x32c8 <do_action+0x328>
    3514:      	cmp	w20, #0xa
    3518:      	b.ne	0x361c <do_action+0x67c>
    351c:      	mov	w8, #0xe                // =14
    3520:      	blr	x8
    3524:      	lsr	x8, x0, #32
    3528:      	mov	x21, x0
    352c:      	adrp	x0, 0x3000 <do_action+0x60>
    3530:      	str	w8, [sp, #0x48]
    3534:      	mov	w8, #0x1                // =1
    3538:      	add	x9, sp, #0x48
    353c:      	add	x1, sp, #0x48
    3540:      	ldr	x0, [x0]
    3544:      	blr	x8
    3548:      	cbz	x0, 0x32cc <do_action+0x32c>
    354c:      	ldr	w8, [x0]
    3550:      	mov	x3, xzr
    3554:      	add	x9, sp, #0x58
    3558:      	add	x10, sp, #0x48
    355c:      	stp	w8, w21, [sp, #0x48]
    3560:      	ldr	x8, [x0, #0x8]
    3564:      	adrp	x0, 0x3000 <do_action+0x60>
    3568:      	add	x1, sp, #0x58
    356c:      	add	x2, sp, #0x48
    3570:      	str	x8, [sp, #0x50]
    3574:      	mov	w8, #0x2                // =2
    3578:      	ldr	x0, [x0]
    357c:      	blr	x8
    3580:      	b	0x32c8 <do_action+0x328>
    3584:      	mov	w8, #0x1                // =1
    3588:      	mov	w9, #0x2                // =2
    358c:      	add	x10, sp, #0x58
    3590:      	add	x11, sp, #0x78
    3594:      	add	x1, sp, #0x58
    3598:      	add	x2, sp, #0x78
    359c:      	mov	x0, x22
    35a0:      	mov	w3, #0x1                // =1
    35a4:      	blr	x9
    35a8:      	cbz	x0, 0x3410 <do_action+0x470>
    35ac:      	mov	x23, x0
    35b0:      	adrp	x24, 0x3000 <do_action+0x60>
    35b4:      	mov	w9, #0x1                // =1
    35b8:      	add	x1, sp, #0x48
    35bc:      	mov	w25, #0x1               // =1
    35c0:      	neg	w8, w23
    35c4:      	strh	w8, [sp, #0x48]
    35c8:      	mov	w8, #0x3                // =3
    35cc:      	strh	w8, [sp, #0x4a]
    35d0:      	mov	x8, #0x3b               // =59
    35d4:      	movk	x8, #0x2, lsl #32
    35d8:      	stur	x8, [sp, #0x4c]
    35dc:      	add	x8, sp, #0x48
    35e0:      	ldr	x24, [x24]
    35e4:      	mov	x0, x24
    35e8:      	blr	x9
    35ec:      	cbz	x0, 0x3978 <do_action+0x9d8>
    35f0:      	ldr	w8, [x0]
    35f4:      	add	w8, w8, #0x1
    35f8:      	str	w8, [x0]
    35fc:      	b	0x399c <do_action+0x9fc>
    3600:      	adrp	x0, 0x3000 <do_action+0x60>
    3604:      	mov	w8, #0x3                // =3
    3608:      	add	x9, sp, #0x48
    360c:      	ldr	x0, [x0]
    3610:      	add	x1, sp, #0x48
    3614:      	blr	x8
    3618:      	b	0x32cc <do_action+0x32c>
    361c:      	adrp	x0, 0x3000 <do_action+0x60>
    3620:      	mov	w8, #0x3                // =3
    3624:      	add	x9, sp, #0x58
    3628:      	ldr	x0, [x0]
    362c:      	add	x1, sp, #0x58
    3630:      	blr	x8
    3634:      	b	0x32cc <do_action+0x32c>
    3638:      	ldr	w8, [x29, #0x10]
    363c:      	str	x25, [sp]
    3640:      	b	0x364c <do_action+0x6ac>
    3644:      	str	x25, [sp]
    3648:      	mov	w8, wzr
    364c:      	mov	w8, w8
    3650:      	add	x0, x9, #0x18
    3654:      	mov	w1, #0xc8               // =200
    3658:      	str	x8, [x9, #0x10]
    365c:      	mov	w8, #0xc8               // =200
    3660:      	mov	w9, #0x4                // =4
    3664:      	str	x0, [sp, #0x18]
    3668:      	blr	x9
    366c:      	ldr	x22, [sp, #0x30]
    3670:      	mov	w8, #0x5e78             // =24184
    3674:      	mov	x25, xzr
    3678:      	str	wzr, [sp, #0x2c]
    367c:      	add	x10, x29, x8
    3680:      	str	x23, [sp, #0x20]
    3684:      	b	0x3698 <do_action+0x6f8>
    3688:      	add	x25, x25, #0x4
    368c:      	add	x10, x10, #0x8
    3690:      	cmp	x25, #0x14
    3694:      	b.eq	0x37d0 <do_action+0x830>
    3698:      	str	x10, [sp, #0x38]
    369c:      	str	wzr, [sp, #0x58]
    36a0:      	mov	w8, #0x1                // =1
    36a4:      	add	x9, sp, #0x58
    36a8:      	add	x1, sp, #0x58
    36ac:      	mov	x0, x24
    36b0:      	blr	x8
    36b4:      	cbz	x0, 0x37d0 <do_action+0x830>
    36b8:      	mov	w8, #0x5ef8             // =24312
    36bc:      	add	x1, x0, x8
    36c0:      	adrp	x0, 0x3000 <do_action+0x60>
    36c4:      	mov	w8, #0x1                // =1
    36c8:      	ldr	x0, [x0]
    36cc:      	blr	x8
    36d0:      	cbz	x0, 0x37d0 <do_action+0x830>
    36d4:      	add	x8, x0, x25
    36d8:      	ldr	x10, [sp, #0x38]
    36dc:      	ldr	w8, [x8, #0x40]
    36e0:      	cmn	w8, #0x1
    36e4:      	b.eq	0x37d0 <do_action+0x830>
    36e8:      	ldr	x8, [x10]
    36ec:      	ldr	w9, [x29, #0x4]
    36f0:      	cmp	x8, x9
    36f4:      	b.ge	0x37d0 <do_action+0x830>
    36f8:      	cmp	x25, #0x10
    36fc:      	b.eq	0x3764 <do_action+0x7c4>
    3700:      	str	wzr, [sp, #0x58]
    3704:      	mov	w8, #0x1                // =1
    3708:      	add	x9, sp, #0x58
    370c:      	add	x1, sp, #0x58
    3710:      	mov	x0, x24
    3714:      	blr	x8
    3718:      	cbz	x0, 0x375c <do_action+0x7bc>
    371c:      	mov	w8, #0x5ef8             // =24312
    3720:      	add	x1, x0, x8
    3724:      	adrp	x0, 0x3000 <do_action+0x60>
    3728:      	mov	w8, #0x1                // =1
    372c:      	ldr	x0, [x0]
    3730:      	blr	x8
    3734:      	cbz	x0, 0x375c <do_action+0x7bc>
    3738:      	ldr	x10, [sp, #0x38]
    373c:      	add	x8, x0, x25
    3740:      	ldr	w9, [x8, #0x44]
    3744:      	ldr	x8, [x10]
    3748:      	cmn	w9, #0x1
    374c:      	b.eq	0x3764 <do_action+0x7c4>
    3750:      	ldr	w9, [x10, #0x8]
    3754:      	sub	w9, w9, w8
    3758:      	b	0x3770 <do_action+0x7d0>
    375c:      	ldr	x10, [sp, #0x38]
    3760:      	ldr	x8, [x10]
    3764:      	ldr	w9, [x29, #0x4]
    3768:      	sub	w9, w9, w8
    376c:      	add	w9, w9, #0x4
    3770:      	cmp	w9, #0x1
    3774:      	b.lt	0x3688 <do_action+0x6e8>
    3778:      	mov	w10, #0x3ffc            // =16380
    377c:      	cmp	w9, #0x28
    3780:      	mov	x23, x29
    3784:      	add	w8, w8, w10
    3788:      	mov	w10, #0x28              // =40
    378c:      	csel	w29, w9, w10, lt
    3790:      	ldr	w9, [sp, #0x2c]
    3794:      	and	x8, x8, #0x3fff
    3798:      	add	x8, x23, x8
    379c:      	mov	w1, w29
    37a0:      	add	x2, x8, #0x90
    37a4:      	mov	w8, #0x4                // =4
    37a8:      	and	w22, w9, #0xff
    37ac:      	ldr	x9, [sp, #0x18]
    37b0:      	add	x0, x9, x22
    37b4:      	blr	x8
    37b8:      	add	w8, w29, w22
    37bc:      	ldp	x22, x10, [sp, #0x30]
    37c0:      	mov	x29, x23
    37c4:      	ldr	x23, [sp, #0x20]
    37c8:      	str	w8, [sp, #0x2c]
    37cc:      	b	0x3688 <do_action+0x6e8>
    37d0:      	adrp	x24, 0x3000 <do_action+0x60>
    37d4:      	mov	w8, #0x1                // =1
    37d8:      	ldr	x24, [x24]
    37dc:      	ldr	x1, [sp, #0x10]
    37e0:      	mov	x0, x24
    37e4:      	blr	x8
    37e8:      	cbz	x0, 0x3810 <do_action+0x870>
    37ec:      	ldp	x10, x11, [sp]
    37f0:      	mov	x9, #-0x4240            // =-16960
    37f4:      	movk	x9, #0xfff0, lsl #16
    37f8:      	ldr	x8, [x0]
    37fc:      	madd	x9, x10, x9, x11
    3800:      	cmp	x8, x9
    3804:      	b.ls	0x3810 <do_action+0x870>
    3808:      	strb	wzr, [x23]
    380c:      	b	0x3830 <do_action+0x890>
    3810:      	ldr	x1, [sp, #0x10]
    3814:      	mov	x3, xzr
    3818:      	mov	w8, #0x2                // =2
    381c:      	add	x9, sp, #0x48
    3820:      	add	x2, sp, #0x48
    3824:      	mov	x0, x24
    3828:      	blr	x8
    382c:      	ldr	x22, [sp, #0x30]
    3830:      	add	w8, w19, #0x3
    3834:      	adrp	x23, 0x3000 <do_action+0x60>
    3838:      	add	x8, x21, w8, uxtw #2
    383c:      	ldr	w8, [x8, #0x4]
    3840:      	ldr	x23, [x23]
    3844:      	cbz	w8, 0x386c <do_action+0x8cc>
    3848:      	ldrb	w8, [x29, #0x1]
    384c:      	mov	x2, xzr
    3850:      	mov	x0, x22
    3854:      	mov	x1, x23
    3858:      	orr	w8, w8, #0x2
    385c:      	strb	w8, [x29, #0x1]
    3860:      	mov	w8, #0x1b               // =27
    3864:      	blr	x8
    3868:      	str	x0, [x29, #0x80]
    386c:      	add	w8, w19, #0x4
    3870:      	add	x8, x21, w8, uxtw #2
    3874:      	ldr	w8, [x8, #0x4]
    3878:      	cbz	w8, 0x38a4 <do_action+0x904>
    387c:      	ldrb	w8, [x29, #0x1]
    3880:      	mov	w9, #0x1b               // =27
    3884:      	mov	x0, x22
    3888:      	mov	x1, x23
    388c:      	mov	w2, #0x100              // =256
    3890:      	orr	w8, w8, #0x4
    3894:      	strb	w8, [x29, #0x1]
    3898:      	mov	w8, #0x100              // =256
    389c:      	blr	x9
    38a0:      	str	x0, [x29, #0x88]
    38a4:      	add	w19, w19, #0x5
    38a8:      	add	x8, x21, w19, uxtw #2
    38ac:      	ldr	w8, [x8, #0x4]
    38b0:      	cbz	w8, 0x3930 <do_action+0x990>
    38b4:      	ldrb	w8, [x29, #0x1]
    38b8:      	orr	w8, w8, #0x8
    38bc:      	strb	w8, [x29, #0x1]
    38c0:      	b	0x3930 <do_action+0x990>
    38c4:      	str	w25, [sp, #0x68]
    38c8:      	mov	x3, xzr
    38cc:      	mov	w8, #0x2                // =2
    38d0:      	add	x9, sp, #0x48
    38d4:      	add	x10, sp, #0x68
    38d8:      	add	x1, sp, #0x48
    38dc:      	add	x2, sp, #0x68
    38e0:      	mov	x0, x23
    38e4:      	blr	x8
    38e8:      	cbz	x22, 0x3954 <do_action+0x9b4>
    38ec:      	str	w24, [x22]
    38f0:      	mov	w21, #0x4               // =4
    38f4:      	str	wzr, [sp, #0x48]
    38f8:      	adrp	x0, 0x3000 <do_action+0x60>
    38fc:      	mov	w8, #0x1                // =1
    3900:      	add	x9, sp, #0x48
    3904:      	ldr	x0, [x0]
    3908:      	add	x1, sp, #0x48
    390c:      	blr	x8
    3910:      	cbz	x0, 0x3930 <do_action+0x990>
    3914:      	add	x8, x0, x21, lsl #3
    3918:      	nop
    391c:      	nop
    3920:      	ldaxr	x9, [x8]
    3924:      	add	x9, x9, #0x1
    3928:      	stlxr	w10, x9, [x8]
    392c:      	cbnz	w10, 0x3920 <do_action+0x980>
    3930:      	add	w0, w19, #0x1
    3934:      	str	x20, [x29, #0x70]
    3938:      	ldp	x20, x19, [sp, #0xb0]
    393c:      	ldr	x29, [sp, #0x70]
    3940:      	ldp	x22, x21, [sp, #0xa0]
    3944:      	ldp	x24, x23, [sp, #0x90]
    3948:      	ldp	x30, x25, [sp, #0x80]
    394c:      	add	sp, sp, #0xc0
    3950:      	ret
    3954:      	mov	x3, xzr
    3958:      	mov	w8, #0x2                // =2
    395c:      	add	x9, sp, #0x58
    3960:      	add	x10, sp, #0x7c
    3964:      	add	x1, sp, #0x58
    3968:      	add	x2, sp, #0x7c
    396c:      	mov	x0, x21
    3970:      	blr	x8
    3974:      	b	0x38f0 <do_action+0x950>
    3978:      	str	w25, [sp, #0x7c]
    397c:      	mov	x3, xzr
    3980:      	mov	w8, #0x2                // =2
    3984:      	add	x9, sp, #0x48
    3988:      	add	x10, sp, #0x7c
    398c:      	add	x1, sp, #0x48
    3990:      	add	x2, sp, #0x7c
    3994:      	mov	x0, x24
    3998:      	blr	x8
    399c:      	cbz	w23, 0x3410 <do_action+0x470>
    39a0:      	mov	w8, #0x1                // =1
    39a4:      	add	x9, sp, #0x58
    39a8:      	add	x1, sp, #0x58
    39ac:      	mov	x0, x22
    39b0:      	blr	x8
    39b4:      	cbz	x0, 0x3410 <do_action+0x470>
    39b8:      	ldr	w8, [sp, #0x78]
    39bc:      	ldaxr	w9, [x0]
    39c0:      	add	w9, w9, w8
    39c4:      	stlxr	w10, w9, [x0]
    39c8:      	cbnz	w10, 0x39bc <do_action+0xa1c>
    39cc:      	b	0x3410 <do_action+0x470>

00000000000039d0 <try_preload_arg>:
    39d0:      	sub	sp, sp, #0x60
    39d4:      	str	x30, [sp, #0x30]
    39d8:      	stp	x22, x21, [sp, #0x40]
    39dc:      	stp	x20, x19, [sp, #0x50]
    39e0:      	ldr	x20, [x1]
    39e4:      	and	w19, w0, #0x7
    39e8:      	add	x8, x20, w19, uxtw #2
    39ec:      	ldr	w8, [x8, #0x18]
    39f0:      	tbnz	w8, #0x8, 0x3a0c <try_preload_arg+0x3c>
    39f4:      	ldp	x20, x19, [sp, #0x50]
    39f8:      	mov	w0, wzr
    39fc:      	ldr	x30, [sp, #0x30]
    3a00:      	ldp	x22, x21, [sp, #0x40]
    3a04:      	add	sp, sp, #0x60
    3a08:      	ret
    3a0c:      	ldr	x0, [x1, #0x8]
    3a10:      	tbnz	w8, #0x7, 0x3a54 <try_preload_arg+0x84>
    3a14:      	str	wzr, [sp, #0x38]
    3a18:      	add	x8, x20, x19, lsl #2
    3a1c:      	ldr	w8, [x8, #0x40]
    3a20:      	cmp	w8, #0x1
    3a24:      	b.le	0x3d50 <try_preload_arg+0x380>
    3a28:      	cmp	w8, #0x2
    3a2c:      	b.eq	0x3d70 <try_preload_arg+0x3a0>
    3a30:      	cmp	w8, #0x3
    3a34:      	b.eq	0x3d84 <try_preload_arg+0x3b4>
    3a38:      	cmp	w8, #0x4
    3a3c:      	b.ne	0x3dbc <try_preload_arg+0x3ec>
    3a40:      	add	x2, x0, #0x20
    3a44:      	mov	w8, #0x8                // =8
    3a48:      	mov	w9, #0x4                // =4
    3a4c:      	add	x10, sp, #0x10
    3a50:      	b	0x3da8 <try_preload_arg+0x3d8>
    3a54:      	str	wzr, [sp, #0x38]
    3a58:      	add	x21, x20, x19, lsl #2
    3a5c:      	mov	w9, #0x40               // =64
    3a60:      	ldrb	w8, [x21, #0x2c2]
    3a64:      	ldrh	w1, [x21, #0x2c0]
    3a68:      	sub	w2, w9, w8, lsl #3
    3a6c:      	bl	0x0 <read_reg>
    3a70:      	str	x0, [sp, #0x8]
    3a74:      	cmp	w19, #0x4
    3a78:      	ldr	w21, [x21, #0x4]
    3a7c:      	b.hi	0x4194 <try_preload_arg+0x7c4>
    3a80:      	mov	w8, #0x50               // =80
    3a84:      	umaddl	x8, w19, w8, x20
    3a88:      	ldrh	w9, [x8, #0x76]
    3a8c:      	cbz	w9, 0x4194 <try_preload_arg+0x7c4>
    3a90:      	add	x19, x8, #0x70
    3a94:      	add	x8, sp, #0x8
    3a98:      	stp	x19, x8, [sp, #0x10]
    3a9c:      	mov	w8, #0x1                // =1
    3aa0:      	strb	w8, [sp, #0x20]
    3aa4:      	add	x8, sp, #0x38
    3aa8:      	str	x8, [sp, #0x28]
    3aac:      	adrp	x8, 0x3000 <do_action+0x60>
    3ab0:      	ldr	x8, [x8]
    3ab4:      	ldrb	w8, [x8]
    3ab8:      	cbz	w8, 0x408c <try_preload_arg+0x6bc>
    3abc:      	ldrh	w8, [x19, #0x6]
    3ac0:      	cbz	w8, 0x4194 <try_preload_arg+0x7c4>
    3ac4:      	ldr	x8, [sp, #0x8]
    3ac8:      	ldr	w9, [x19]
    3acc:      	add	x8, x8, x9
    3ad0:      	str	x8, [sp, #0x8]
    3ad4:      	ldrh	w9, [x19, #0x4]
    3ad8:      	cbz	w9, 0x3afc <try_preload_arg+0x12c>
    3adc:      	mov	w9, #0x8                // =8
    3ae0:      	mov	w10, #0x94              // =148
    3ae4:      	add	x11, sp, #0x8
    3ae8:      	ldr	x2, [sp, #0x8]
    3aec:      	add	x0, sp, #0x8
    3af0:      	mov	w1, #0x8                // =8
    3af4:      	blr	x10
    3af8:      	tbnz	w0, #0x1f, 0x40e4 <try_preload_arg+0x714>
    3afc:      	ldrh	w8, [x19, #0xe]
    3b00:      	cbz	w8, 0x4194 <try_preload_arg+0x7c4>
    3b04:      	ldr	x8, [sp, #0x8]
    3b08:      	ldr	w9, [x19, #0x8]
    3b0c:      	add	x8, x8, x9
    3b10:      	str	x8, [sp, #0x8]
    3b14:      	ldrh	w9, [x19, #0xc]
    3b18:      	cbz	w9, 0x3b3c <try_preload_arg+0x16c>
    3b1c:      	mov	w9, #0x8                // =8
    3b20:      	mov	w10, #0x94              // =148
    3b24:      	add	x11, sp, #0x8
    3b28:      	ldr	x2, [sp, #0x8]
    3b2c:      	add	x0, sp, #0x8
    3b30:      	mov	w1, #0x8                // =8
    3b34:      	blr	x10
    3b38:      	tbnz	w0, #0x1f, 0x4100 <try_preload_arg+0x730>
    3b3c:      	ldrh	w8, [x19, #0x16]
    3b40:      	cbz	w8, 0x4194 <try_preload_arg+0x7c4>
    3b44:      	ldr	x8, [sp, #0x8]
    3b48:      	ldr	w9, [x19, #0x10]
    3b4c:      	add	x8, x8, x9
    3b50:      	str	x8, [sp, #0x8]
    3b54:      	ldrh	w9, [x19, #0x14]
    3b58:      	cbz	w9, 0x3b7c <try_preload_arg+0x1ac>
    3b5c:      	mov	w9, #0x8                // =8
    3b60:      	mov	w10, #0x94              // =148
    3b64:      	add	x11, sp, #0x8
    3b68:      	ldr	x2, [sp, #0x8]
    3b6c:      	add	x0, sp, #0x8
    3b70:      	mov	w1, #0x8                // =8
    3b74:      	blr	x10
    3b78:      	tbnz	w0, #0x1f, 0x411c <try_preload_arg+0x74c>
    3b7c:      	ldrh	w8, [x19, #0x1e]
    3b80:      	cbz	w8, 0x4194 <try_preload_arg+0x7c4>
    3b84:      	ldr	x8, [sp, #0x8]
    3b88:      	ldr	w9, [x19, #0x18]
    3b8c:      	add	x8, x8, x9
    3b90:      	str	x8, [sp, #0x8]
    3b94:      	ldrh	w9, [x19, #0x1c]
    3b98:      	cbz	w9, 0x3bbc <try_preload_arg+0x1ec>
    3b9c:      	mov	w9, #0x8                // =8
    3ba0:      	mov	w10, #0x94              // =148
    3ba4:      	add	x11, sp, #0x8
    3ba8:      	ldr	x2, [sp, #0x8]
    3bac:      	add	x0, sp, #0x8
    3bb0:      	mov	w1, #0x8                // =8
    3bb4:      	blr	x10
    3bb8:      	tbnz	w0, #0x1f, 0x4138 <try_preload_arg+0x768>
    3bbc:      	ldrh	w8, [x19, #0x26]
    3bc0:      	cbz	w8, 0x4194 <try_preload_arg+0x7c4>
    3bc4:      	ldr	x8, [sp, #0x8]
    3bc8:      	ldr	w9, [x19, #0x20]
    3bcc:      	add	x8, x8, x9
    3bd0:      	str	x8, [sp, #0x8]
    3bd4:      	ldrh	w9, [x19, #0x24]
    3bd8:      	cbz	w9, 0x3bfc <try_preload_arg+0x22c>
    3bdc:      	mov	w9, #0x8                // =8
    3be0:      	mov	w10, #0x94              // =148
    3be4:      	add	x11, sp, #0x8
    3be8:      	ldr	x2, [sp, #0x8]
    3bec:      	add	x0, sp, #0x8
    3bf0:      	mov	w1, #0x8                // =8
    3bf4:      	blr	x10
    3bf8:      	tbnz	w0, #0x1f, 0x4154 <try_preload_arg+0x784>
    3bfc:      	ldrh	w8, [x19, #0x2e]
    3c00:      	cbz	w8, 0x4194 <try_preload_arg+0x7c4>
    3c04:      	ldr	x8, [sp, #0x8]
    3c08:      	ldr	w9, [x19, #0x28]
    3c0c:      	add	x8, x8, x9
    3c10:      	str	x8, [sp, #0x8]
    3c14:      	ldrh	w9, [x19, #0x2c]
    3c18:      	cbz	w9, 0x3c3c <try_preload_arg+0x26c>
    3c1c:      	mov	w9, #0x8                // =8
    3c20:      	mov	w10, #0x94              // =148
    3c24:      	add	x11, sp, #0x8
    3c28:      	ldr	x2, [sp, #0x8]
    3c2c:      	add	x0, sp, #0x8
    3c30:      	mov	w1, #0x8                // =8
    3c34:      	blr	x10
    3c38:      	tbnz	w0, #0x1f, 0x4170 <try_preload_arg+0x7a0>
    3c3c:      	ldrh	w8, [x19, #0x36]
    3c40:      	cbz	w8, 0x4194 <try_preload_arg+0x7c4>
    3c44:      	ldr	x8, [sp, #0x8]
    3c48:      	ldr	w9, [x19, #0x30]
    3c4c:      	add	x8, x8, x9
    3c50:      	str	x8, [sp, #0x8]
    3c54:      	ldrh	w9, [x19, #0x34]
    3c58:      	cbz	w9, 0x3c7c <try_preload_arg+0x2ac>
    3c5c:      	mov	w9, #0x8                // =8
    3c60:      	mov	w10, #0x94              // =148
    3c64:      	add	x11, sp, #0x8
    3c68:      	ldr	x2, [sp, #0x8]
    3c6c:      	add	x0, sp, #0x8
    3c70:      	mov	w1, #0x8                // =8
    3c74:      	blr	x10
    3c78:      	tbnz	w0, #0x1f, 0x418c <try_preload_arg+0x7bc>
    3c7c:      	ldrh	w8, [x19, #0x3e]
    3c80:      	cbz	w8, 0x4194 <try_preload_arg+0x7c4>
    3c84:      	ldr	x8, [sp, #0x8]
    3c88:      	ldr	w9, [x19, #0x38]
    3c8c:      	add	x8, x8, x9
    3c90:      	str	x8, [sp, #0x8]
    3c94:      	ldrh	w9, [x19, #0x3c]
    3c98:      	cbz	w9, 0x3cbc <try_preload_arg+0x2ec>
    3c9c:      	mov	w20, #0x8               // =8
    3ca0:      	mov	w9, #0x94               // =148
    3ca4:      	add	x10, sp, #0x8
    3ca8:      	ldr	x2, [sp, #0x8]
    3cac:      	add	x0, sp, #0x8
    3cb0:      	mov	w1, #0x8                // =8
    3cb4:      	blr	x9
    3cb8:      	tbnz	w0, #0x1f, 0x40e8 <try_preload_arg+0x718>
    3cbc:      	ldrh	w8, [x19, #0x46]
    3cc0:      	cbz	w8, 0x4194 <try_preload_arg+0x7c4>
    3cc4:      	ldr	x8, [sp, #0x8]
    3cc8:      	ldr	w9, [x19, #0x40]
    3ccc:      	add	x8, x8, x9
    3cd0:      	str	x8, [sp, #0x8]
    3cd4:      	ldrh	w9, [x19, #0x44]
    3cd8:      	cbz	w9, 0x3cfc <try_preload_arg+0x32c>
    3cdc:      	mov	w9, #0x8                // =8
    3ce0:      	mov	w10, #0x94              // =148
    3ce4:      	add	x11, sp, #0x8
    3ce8:      	ldr	x2, [sp, #0x8]
    3cec:      	add	x0, sp, #0x8
    3cf0:      	mov	w1, #0x8                // =8
    3cf4:      	blr	x10
    3cf8:      	tbnz	w0, #0x1f, 0x430c <try_preload_arg+0x93c>
    3cfc:      	ldrh	w8, [x19, #0x4e]
    3d00:      	cbz	w8, 0x4194 <try_preload_arg+0x7c4>
    3d04:      	ldr	x8, [sp, #0x8]
    3d08:      	ldr	w9, [x19, #0x48]
    3d0c:      	add	x8, x8, x9
    3d10:      	str	x8, [sp, #0x8]
    3d14:      	ldrh	w9, [x19, #0x4c]
    3d18:      	cbz	w9, 0x4194 <try_preload_arg+0x7c4>
    3d1c:      	mov	w9, #0x8                // =8
    3d20:      	mov	w10, #0x94              // =148
    3d24:      	add	x11, sp, #0x8
    3d28:      	ldr	x2, [sp, #0x8]
    3d2c:      	add	x0, sp, #0x8
    3d30:      	mov	w1, #0x8                // =8
    3d34:      	blr	x10
    3d38:      	tbz	w0, #0x1f, 0x4194 <try_preload_arg+0x7c4>
    3d3c:      	mov	w20, #0xa               // =10
    3d40:      	str	w20, [sp, #0x38]
    3d44:      	cmp	w21, #0x6
    3d48:      	b.eq	0x419c <try_preload_arg+0x7cc>
    3d4c:      	b	0x39f4 <try_preload_arg+0x24>
    3d50:      	cbz	w8, 0x3d98 <try_preload_arg+0x3c8>
    3d54:      	cmp	w8, #0x1
    3d58:      	b.ne	0x3dbc <try_preload_arg+0x3ec>
    3d5c:      	add	x2, x0, #0x8
    3d60:      	mov	w8, #0x8                // =8
    3d64:      	mov	w9, #0x4                // =4
    3d68:      	add	x10, sp, #0x10
    3d6c:      	b	0x3da8 <try_preload_arg+0x3d8>
    3d70:      	add	x2, x0, #0x10
    3d74:      	mov	w8, #0x8                // =8
    3d78:      	mov	w9, #0x4                // =4
    3d7c:      	add	x10, sp, #0x10
    3d80:      	b	0x3da8 <try_preload_arg+0x3d8>
    3d84:      	add	x2, x0, #0x18
    3d88:      	mov	w8, #0x8                // =8
    3d8c:      	mov	w9, #0x4                // =4
    3d90:      	add	x10, sp, #0x10
    3d94:      	b	0x3da8 <try_preload_arg+0x3d8>
    3d98:      	mov	w8, #0x8                // =8
    3d9c:      	mov	w9, #0x4                // =4
    3da0:      	add	x10, sp, #0x10
    3da4:      	mov	x2, x0
    3da8:      	add	x0, sp, #0x10
    3dac:      	mov	w1, #0x8                // =8
    3db0:      	blr	x9
    3db4:      	ldr	x8, [sp, #0x10]
    3db8:      	str	x8, [sp, #0x8]
    3dbc:      	cmp	w19, #0x4
    3dc0:      	b.hi	0x4224 <try_preload_arg+0x854>
    3dc4:      	mov	w8, #0x50               // =80
    3dc8:      	umaddl	x8, w19, w8, x20
    3dcc:      	ldrh	w9, [x8, #0x76]
    3dd0:      	cbz	w9, 0x4224 <try_preload_arg+0x854>
    3dd4:      	add	x21, x8, #0x70
    3dd8:      	add	x8, sp, #0x8
    3ddc:      	stp	x21, x8, [sp, #0x10]
    3de0:      	mov	w8, #0x1                // =1
    3de4:      	strb	w8, [sp, #0x20]
    3de8:      	add	x8, sp, #0x38
    3dec:      	str	x8, [sp, #0x28]
    3df0:      	adrp	x8, 0x3000 <do_action+0x60>
    3df4:      	ldr	x8, [x8]
    3df8:      	ldrb	w8, [x8]
    3dfc:      	cbz	w8, 0x40bc <try_preload_arg+0x6ec>
    3e00:      	ldrh	w8, [x21, #0x6]
    3e04:      	cbz	w8, 0x4224 <try_preload_arg+0x854>
    3e08:      	ldr	x8, [sp, #0x8]
    3e0c:      	ldr	w9, [x21]
    3e10:      	add	x8, x8, x9
    3e14:      	str	x8, [sp, #0x8]
    3e18:      	ldrh	w9, [x21, #0x4]
    3e1c:      	cbz	w9, 0x3e40 <try_preload_arg+0x470>
    3e20:      	mov	w9, #0x8                // =8
    3e24:      	mov	w10, #0x94              // =148
    3e28:      	add	x11, sp, #0x8
    3e2c:      	ldr	x2, [sp, #0x8]
    3e30:      	add	x0, sp, #0x8
    3e34:      	mov	w1, #0x8                // =8
    3e38:      	blr	x10
    3e3c:      	tbnz	w0, #0x1f, 0x40f8 <try_preload_arg+0x728>
    3e40:      	ldrh	w8, [x21, #0xe]
    3e44:      	cbz	w8, 0x4224 <try_preload_arg+0x854>
    3e48:      	ldr	x8, [sp, #0x8]
    3e4c:      	ldr	w9, [x21, #0x8]
    3e50:      	add	x8, x8, x9
    3e54:      	str	x8, [sp, #0x8]
    3e58:      	ldrh	w9, [x21, #0xc]
    3e5c:      	cbz	w9, 0x3e80 <try_preload_arg+0x4b0>
    3e60:      	mov	w9, #0x8                // =8
    3e64:      	mov	w10, #0x94              // =148
    3e68:      	add	x11, sp, #0x8
    3e6c:      	ldr	x2, [sp, #0x8]
    3e70:      	add	x0, sp, #0x8
    3e74:      	mov	w1, #0x8                // =8
    3e78:      	blr	x10
    3e7c:      	tbnz	w0, #0x1f, 0x4114 <try_preload_arg+0x744>
    3e80:      	ldrh	w8, [x21, #0x16]
    3e84:      	cbz	w8, 0x4224 <try_preload_arg+0x854>
    3e88:      	ldr	x8, [sp, #0x8]
    3e8c:      	ldr	w9, [x21, #0x10]
    3e90:      	add	x8, x8, x9
    3e94:      	str	x8, [sp, #0x8]
    3e98:      	ldrh	w9, [x21, #0x14]
    3e9c:      	cbz	w9, 0x3ec0 <try_preload_arg+0x4f0>
    3ea0:      	mov	w9, #0x8                // =8
    3ea4:      	mov	w10, #0x94              // =148
    3ea8:      	add	x11, sp, #0x8
    3eac:      	ldr	x2, [sp, #0x8]
    3eb0:      	add	x0, sp, #0x8
    3eb4:      	mov	w1, #0x8                // =8
    3eb8:      	blr	x10
    3ebc:      	tbnz	w0, #0x1f, 0x4130 <try_preload_arg+0x760>
    3ec0:      	ldrh	w8, [x21, #0x1e]
    3ec4:      	cbz	w8, 0x4224 <try_preload_arg+0x854>
    3ec8:      	ldr	x8, [sp, #0x8]
    3ecc:      	ldr	w9, [x21, #0x18]
    3ed0:      	add	x8, x8, x9
    3ed4:      	str	x8, [sp, #0x8]
    3ed8:      	ldrh	w9, [x21, #0x1c]
    3edc:      	cbz	w9, 0x3f00 <try_preload_arg+0x530>
    3ee0:      	mov	w9, #0x8                // =8
    3ee4:      	mov	w10, #0x94              // =148
    3ee8:      	add	x11, sp, #0x8
    3eec:      	ldr	x2, [sp, #0x8]
    3ef0:      	add	x0, sp, #0x8
    3ef4:      	mov	w1, #0x8                // =8
    3ef8:      	blr	x10
    3efc:      	tbnz	w0, #0x1f, 0x414c <try_preload_arg+0x77c>
    3f00:      	ldrh	w8, [x21, #0x26]
    3f04:      	cbz	w8, 0x4224 <try_preload_arg+0x854>
    3f08:      	ldr	x8, [sp, #0x8]
    3f0c:      	ldr	w9, [x21, #0x20]
    3f10:      	add	x8, x8, x9
    3f14:      	str	x8, [sp, #0x8]
    3f18:      	ldrh	w9, [x21, #0x24]
    3f1c:      	cbz	w9, 0x3f40 <try_preload_arg+0x570>
    3f20:      	mov	w9, #0x8                // =8
    3f24:      	mov	w10, #0x94              // =148
    3f28:      	add	x11, sp, #0x8
    3f2c:      	ldr	x2, [sp, #0x8]
    3f30:      	add	x0, sp, #0x8
    3f34:      	mov	w1, #0x8                // =8
    3f38:      	blr	x10
    3f3c:      	tbnz	w0, #0x1f, 0x4168 <try_preload_arg+0x798>
    3f40:      	ldrh	w8, [x21, #0x2e]
    3f44:      	cbz	w8, 0x4224 <try_preload_arg+0x854>
    3f48:      	ldr	x8, [sp, #0x8]
    3f4c:      	ldr	w9, [x21, #0x28]
    3f50:      	add	x8, x8, x9
    3f54:      	str	x8, [sp, #0x8]
    3f58:      	ldrh	w9, [x21, #0x2c]
    3f5c:      	cbz	w9, 0x3f80 <try_preload_arg+0x5b0>
    3f60:      	mov	w9, #0x8                // =8
    3f64:      	mov	w10, #0x94              // =148
    3f68:      	add	x11, sp, #0x8
    3f6c:      	ldr	x2, [sp, #0x8]
    3f70:      	add	x0, sp, #0x8
    3f74:      	mov	w1, #0x8                // =8
    3f78:      	blr	x10
    3f7c:      	tbnz	w0, #0x1f, 0x4184 <try_preload_arg+0x7b4>
    3f80:      	ldrh	w8, [x21, #0x36]
    3f84:      	cbz	w8, 0x4224 <try_preload_arg+0x854>
    3f88:      	ldr	x8, [sp, #0x8]
    3f8c:      	ldr	w9, [x21, #0x30]
    3f90:      	add	x8, x8, x9
    3f94:      	str	x8, [sp, #0x8]
    3f98:      	ldrh	w9, [x21, #0x34]
    3f9c:      	cbz	w9, 0x3fc0 <try_preload_arg+0x5f0>
    3fa0:      	mov	w9, #0x8                // =8
    3fa4:      	mov	w10, #0x94              // =148
    3fa8:      	add	x11, sp, #0x8
    3fac:      	ldr	x2, [sp, #0x8]
    3fb0:      	add	x0, sp, #0x8
    3fb4:      	mov	w1, #0x8                // =8
    3fb8:      	blr	x10
    3fbc:      	tbnz	w0, #0x1f, 0x421c <try_preload_arg+0x84c>
    3fc0:      	ldrh	w8, [x21, #0x3e]
    3fc4:      	cbz	w8, 0x4224 <try_preload_arg+0x854>
    3fc8:      	ldr	x8, [sp, #0x8]
    3fcc:      	ldr	w9, [x21, #0x38]
    3fd0:      	add	x8, x8, x9
    3fd4:      	str	x8, [sp, #0x8]
    3fd8:      	ldrh	w9, [x21, #0x3c]
    3fdc:      	cbz	w9, 0x4004 <try_preload_arg+0x634>
    3fe0:      	mov	w9, #0x8                // =8
    3fe4:      	mov	w10, #0x94              // =148
    3fe8:      	add	x11, sp, #0x8
    3fec:      	ldr	x2, [sp, #0x8]
    3ff0:      	add	x0, sp, #0x8
    3ff4:      	mov	w1, #0x8                // =8
    3ff8:      	blr	x10
    3ffc:      	mov	w8, #0x8                // =8
    4000:      	tbnz	w0, #0x1f, 0x4220 <try_preload_arg+0x850>
    4004:      	ldrh	w8, [x21, #0x46]
    4008:      	cbz	w8, 0x4224 <try_preload_arg+0x854>
    400c:      	ldr	x8, [sp, #0x8]
    4010:      	ldr	w9, [x21, #0x40]
    4014:      	add	x8, x8, x9
    4018:      	str	x8, [sp, #0x8]
    401c:      	ldrh	w9, [x21, #0x44]
    4020:      	cbz	w9, 0x4044 <try_preload_arg+0x674>
    4024:      	mov	w9, #0x8                // =8
    4028:      	mov	w10, #0x94              // =148
    402c:      	add	x11, sp, #0x8
    4030:      	ldr	x2, [sp, #0x8]
    4034:      	add	x0, sp, #0x8
    4038:      	mov	w1, #0x8                // =8
    403c:      	blr	x10
    4040:      	tbnz	w0, #0x1f, 0x4320 <try_preload_arg+0x950>
    4044:      	ldrh	w8, [x21, #0x4e]
    4048:      	cbz	w8, 0x4224 <try_preload_arg+0x854>
    404c:      	ldr	x8, [sp, #0x8]
    4050:      	ldr	w9, [x21, #0x48]
    4054:      	add	x8, x8, x9
    4058:      	str	x8, [sp, #0x8]
    405c:      	ldrh	w9, [x21, #0x4c]
    4060:      	cbz	w9, 0x4224 <try_preload_arg+0x854>
    4064:      	mov	w9, #0x8                // =8
    4068:      	mov	w10, #0x94              // =148
    406c:      	add	x11, sp, #0x8
    4070:      	ldr	x2, [sp, #0x8]
    4074:      	add	x0, sp, #0x8
    4078:      	mov	w1, #0x8                // =8
    407c:      	blr	x10
    4080:      	tbz	w0, #0x1f, 0x4224 <try_preload_arg+0x854>
    4084:      	mov	w8, #0xa                // =10
    4088:      	b	0x4220 <try_preload_arg+0x850>
    408c:      	mov	x3, xzr
    4090:      	adrp	x1, 0x4000 <try_preload_arg+0x630>
    4094:      	add	x1, x1, #0x0
    4098:      	mov	w8, #0xa                // =10
    409c:      	mov	w9, #0xb5               // =181
    40a0:      	add	x10, sp, #0x10
    40a4:      	add	x2, sp, #0x10
    40a8:      	mov	w0, #0xa                // =10
    40ac:      	blr	x9
    40b0:      	cmp	w21, #0x6
    40b4:      	b.eq	0x419c <try_preload_arg+0x7cc>
    40b8:      	b	0x39f4 <try_preload_arg+0x24>
    40bc:      	mov	x3, xzr
    40c0:      	adrp	x1, 0x4000 <try_preload_arg+0x630>
    40c4:      	add	x1, x1, #0x0
    40c8:      	mov	w8, #0xa                // =10
    40cc:      	mov	w9, #0xb5               // =181
    40d0:      	add	x10, sp, #0x10
    40d4:      	add	x2, sp, #0x10
    40d8:      	mov	w0, #0xa                // =10
    40dc:      	blr	x9
    40e0:      	b	0x4224 <try_preload_arg+0x854>
    40e4:      	mov	w20, #0x1               // =1
    40e8:      	str	w20, [sp, #0x38]
    40ec:      	cmp	w21, #0x6
    40f0:      	b.eq	0x419c <try_preload_arg+0x7cc>
    40f4:      	b	0x39f4 <try_preload_arg+0x24>
    40f8:      	mov	w8, #0x1                // =1
    40fc:      	b	0x4220 <try_preload_arg+0x850>
    4100:      	mov	w20, #0x2               // =2
    4104:      	str	w20, [sp, #0x38]
    4108:      	cmp	w21, #0x6
    410c:      	b.eq	0x419c <try_preload_arg+0x7cc>
    4110:      	b	0x39f4 <try_preload_arg+0x24>
    4114:      	mov	w8, #0x2                // =2
    4118:      	b	0x4220 <try_preload_arg+0x850>
    411c:      	mov	w20, #0x3               // =3
    4120:      	str	w20, [sp, #0x38]
    4124:      	cmp	w21, #0x6
    4128:      	b.eq	0x419c <try_preload_arg+0x7cc>
    412c:      	b	0x39f4 <try_preload_arg+0x24>
    4130:      	mov	w8, #0x3                // =3
    4134:      	b	0x4220 <try_preload_arg+0x850>
    4138:      	mov	w20, #0x4               // =4
    413c:      	str	w20, [sp, #0x38]
    4140:      	cmp	w21, #0x6
    4144:      	b.eq	0x419c <try_preload_arg+0x7cc>
    4148:      	b	0x39f4 <try_preload_arg+0x24>
    414c:      	mov	w8, #0x4                // =4
    4150:      	b	0x4220 <try_preload_arg+0x850>
    4154:      	mov	w20, #0x5               // =5
    4158:      	str	w20, [sp, #0x38]
    415c:      	cmp	w21, #0x6
    4160:      	b.eq	0x419c <try_preload_arg+0x7cc>
    4164:      	b	0x39f4 <try_preload_arg+0x24>
    4168:      	mov	w8, #0x5                // =5
    416c:      	b	0x4220 <try_preload_arg+0x850>
    4170:      	mov	w20, #0x6               // =6
    4174:      	str	w20, [sp, #0x38]
    4178:      	cmp	w21, #0x6
    417c:      	b.eq	0x419c <try_preload_arg+0x7cc>
    4180:      	b	0x39f4 <try_preload_arg+0x24>
    4184:      	mov	w8, #0x6                // =6
    4188:      	b	0x4220 <try_preload_arg+0x850>
    418c:      	mov	w20, #0x7               // =7
    4190:      	str	w20, [sp, #0x38]
    4194:      	cmp	w21, #0x6
    4198:      	b.ne	0x39f4 <try_preload_arg+0x24>
    419c:      	ldr	x19, [sp, #0x8]
    41a0:      	ldr	w21, [sp, #0x38]
    41a4:      	mov	w8, #0xe                // =14
    41a8:      	blr	x8
    41ac:      	str	x0, [sp, #0x10]
    41b0:      	str	wzr, [sp, #0x3c]
    41b4:      	adrp	x0, 0x4000 <try_preload_arg+0x630>
    41b8:      	mov	w8, #0x1                // =1
    41bc:      	add	x9, sp, #0x3c
    41c0:      	add	x1, sp, #0x3c
    41c4:      	ldr	x0, [x0]
    41c8:      	blr	x8
    41cc:      	cbz	x0, 0x39f4 <try_preload_arg+0x24>
    41d0:      	adrp	x20, 0x4000 <try_preload_arg+0x630>
    41d4:      	mov	x3, xzr
    41d8:      	mov	w8, #0x2                // =2
    41dc:      	ldr	x20, [x20]
    41e0:      	add	x22, sp, #0x10
    41e4:      	mov	x2, x0
    41e8:      	add	x1, sp, #0x10
    41ec:      	mov	x0, x20
    41f0:      	blr	x8
    41f4:      	mov	w8, #0x1                // =1
    41f8:      	add	x1, sp, #0x10
    41fc:      	mov	x0, x20
    4200:      	blr	x8
    4204:      	cbz	x0, 0x39f4 <try_preload_arg+0x24>
    4208:      	cbnz	w21, 0x42f0 <try_preload_arg+0x920>
    420c:      	add	x8, x0, #0x4
    4210:      	mov	w9, #0x1000             // =4096
    4214:      	mov	w10, #0x72              // =114
    4218:      	b	0x42cc <try_preload_arg+0x8fc>
    421c:      	mov	w8, #0x7                // =7
    4220:      	str	w8, [sp, #0x38]
    4224:      	add	x8, x20, x19, lsl #2
    4228:      	mov	w9, #0x4                // =4
    422c:      	add	x10, sp, #0x8
    4230:      	ldr	w19, [x8, #0x4]
    4234:      	mov	w8, #0x8                // =8
    4238:      	add	x0, sp, #0x8
    423c:      	add	x2, sp, #0x8
    4240:      	mov	w1, #0x8                // =8
    4244:      	blr	x9
    4248:      	cmp	w19, #0x6
    424c:      	b.ne	0x39f4 <try_preload_arg+0x24>
    4250:      	ldr	x19, [sp, #0x8]
    4254:      	ldr	w21, [sp, #0x38]
    4258:      	mov	w8, #0xe                // =14
    425c:      	blr	x8
    4260:      	str	x0, [sp, #0x10]
    4264:      	str	wzr, [sp, #0x3c]
    4268:      	adrp	x0, 0x4000 <try_preload_arg+0x630>
    426c:      	mov	w8, #0x1                // =1
    4270:      	add	x9, sp, #0x3c
    4274:      	add	x1, sp, #0x3c
    4278:      	ldr	x0, [x0]
    427c:      	blr	x8
    4280:      	cbz	x0, 0x39f4 <try_preload_arg+0x24>
    4284:      	adrp	x20, 0x4000 <try_preload_arg+0x630>
    4288:      	mov	x3, xzr
    428c:      	mov	w8, #0x2                // =2
    4290:      	ldr	x20, [x20]
    4294:      	add	x22, sp, #0x10
    4298:      	mov	x2, x0
    429c:      	add	x1, sp, #0x10
    42a0:      	mov	x0, x20
    42a4:      	blr	x8
    42a8:      	mov	w8, #0x1                // =1
    42ac:      	add	x1, sp, #0x10
    42b0:      	mov	x0, x20
    42b4:      	blr	x8
    42b8:      	cbz	x0, 0x39f4 <try_preload_arg+0x24>
    42bc:      	cbnz	w21, 0x42f0 <try_preload_arg+0x920>
    42c0:      	add	x8, x0, #0x4
    42c4:      	mov	w9, #0x1000             // =4096
    42c8:      	mov	w10, #0x72              // =114
    42cc:      	mov	x20, x0
    42d0:      	mov	x0, x8
    42d4:      	mov	w1, #0x1000             // =4096
    42d8:      	mov	x2, x19
    42dc:      	blr	x10
    42e0:      	mov	x8, x0
    42e4:      	mov	x0, x20
    42e8:      	tbz	x8, #0x3f, 0x42f0 <try_preload_arg+0x920>
    42ec:      	mov	w21, #-0x1              // =-1
    42f0:      	str	w21, [x0]
    42f4:      	ldp	x20, x19, [sp, #0x50]
    42f8:      	mov	w0, wzr
    42fc:      	ldr	x30, [sp, #0x30]
    4300:      	ldp	x22, x21, [sp, #0x40]
    4304:      	add	sp, sp, #0x60
    4308:      	ret
    430c:      	mov	w20, #0x9               // =9
    4310:      	str	w20, [sp, #0x38]
    4314:      	cmp	w21, #0x6
    4318:      	b.eq	0x419c <try_preload_arg+0x7cc>
    431c:      	b	0x39f4 <try_preload_arg+0x24>
    4320:      	mov	w8, #0x9                // =9
    4324:      	b	0x4220 <try_preload_arg+0x850>
    4328:      	nop
    432c:      	nop

0000000000004330 <write_reg>:
    4330:      	ror	w8, w1, #0x3
    4334:      	cmp	w8, #0xf
    4338:      	b.le	0x4388 <write_reg+0x58>
    433c:      	cmp	w8, #0x17
    4340:      	b.le	0x4404 <write_reg+0xd4>
    4344:      	cmp	w8, #0x1b
    4348:      	b.le	0x4440 <write_reg+0x110>
    434c:      	cmp	w8, #0x1d
    4350:      	b.le	0x453c <write_reg+0x20c>
    4354:      	cmp	w8, #0x1e
    4358:      	b.eq	0x4830 <write_reg+0x500>
    435c:      	cmp	w8, #0x20
    4360:      	b.eq	0x46c4 <write_reg+0x394>
    4364:      	cmp	w8, #0x1f
    4368:      	b.ne	0x4950 <write_reg+0x620>
    436c:      	and	w8, w2, #0xff
    4370:      	cmp	w8, #0x4
    4374:      	b.eq	0x4884 <write_reg+0x554>
    4378:      	cmp	w8, #0x8
    437c:      	b.ne	0x4950 <write_reg+0x620>
    4380:      	str	x3, [x0, #0xf8]
    4384:      	ret
    4388:      	cmp	w8, #0x7
    438c:      	b.gt	0x43c8 <write_reg+0x98>
    4390:      	cmp	w8, #0x3
    4394:      	b.gt	0x4474 <write_reg+0x144>
    4398:      	cmp	w8, #0x1
    439c:      	b.gt	0x4568 <write_reg+0x238>
    43a0:      	cbz	w8, 0x46e0 <write_reg+0x3b0>
    43a4:      	cmp	w8, #0x1
    43a8:      	b.ne	0x4950 <write_reg+0x620>
    43ac:      	and	w8, w2, #0xff
    43b0:      	cmp	w8, #0x4
    43b4:      	b.eq	0x48cc <write_reg+0x59c>
    43b8:      	cmp	w8, #0x8
    43bc:      	b.ne	0x4950 <write_reg+0x620>
    43c0:      	str	x3, [x0, #0x8]
    43c4:      	ret
    43c8:      	cmp	w8, #0xb
    43cc:      	b.gt	0x44a8 <write_reg+0x178>
    43d0:      	cmp	w8, #0x9
    43d4:      	b.gt	0x4594 <write_reg+0x264>
    43d8:      	cmp	w8, #0x8
    43dc:      	b.eq	0x46fc <write_reg+0x3cc>
    43e0:      	cmp	w8, #0x9
    43e4:      	b.ne	0x4950 <write_reg+0x620>
    43e8:      	and	w8, w2, #0xff
    43ec:      	cmp	w8, #0x4
    43f0:      	b.eq	0x48d4 <write_reg+0x5a4>
    43f4:      	cmp	w8, #0x8
    43f8:      	b.ne	0x4950 <write_reg+0x620>
    43fc:      	str	x3, [x0, #0x48]
    4400:      	ret
    4404:      	cmp	w8, #0x13
    4408:      	b.gt	0x44dc <write_reg+0x1ac>
    440c:      	cmp	w8, #0x11
    4410:      	b.gt	0x4618 <write_reg+0x2e8>
    4414:      	cmp	w8, #0x10
    4418:      	b.eq	0x47c0 <write_reg+0x490>
    441c:      	cmp	w8, #0x11
    4420:      	b.ne	0x4950 <write_reg+0x620>
    4424:      	and	w8, w2, #0xff
    4428:      	cmp	w8, #0x4
    442c:      	b.eq	0x492c <write_reg+0x5fc>
    4430:      	cmp	w8, #0x8
    4434:      	b.ne	0x4950 <write_reg+0x620>
    4438:      	str	x3, [x0, #0x88]
    443c:      	ret
    4440:      	cmp	w8, #0x19
    4444:      	b.gt	0x4510 <write_reg+0x1e0>
    4448:      	cmp	w8, #0x18
    444c:      	b.eq	0x4670 <write_reg+0x340>
    4450:      	cmp	w8, #0x19
    4454:      	b.ne	0x4950 <write_reg+0x620>
    4458:      	and	w8, w2, #0xff
    445c:      	cmp	w8, #0x4
    4460:      	b.eq	0x485c <write_reg+0x52c>
    4464:      	cmp	w8, #0x8
    4468:      	b.ne	0x4950 <write_reg+0x620>
    446c:      	str	x3, [x0, #0xc8]
    4470:      	ret
    4474:      	cmp	w8, #0x5
    4478:      	b.gt	0x45c0 <write_reg+0x290>
    447c:      	cmp	w8, #0x4
    4480:      	b.eq	0x4718 <write_reg+0x3e8>
    4484:      	cmp	w8, #0x5
    4488:      	b.ne	0x4950 <write_reg+0x620>
    448c:      	and	w8, w2, #0xff
    4490:      	cmp	w8, #0x4
    4494:      	b.eq	0x48dc <write_reg+0x5ac>
    4498:      	cmp	w8, #0x8
    449c:      	b.ne	0x4950 <write_reg+0x620>
    44a0:      	str	x3, [x0, #0x28]
    44a4:      	ret
    44a8:      	cmp	w8, #0xd
    44ac:      	b.gt	0x45ec <write_reg+0x2bc>
    44b0:      	cmp	w8, #0xc
    44b4:      	b.eq	0x4734 <write_reg+0x404>
    44b8:      	cmp	w8, #0xd
    44bc:      	b.ne	0x4950 <write_reg+0x620>
    44c0:      	and	w8, w2, #0xff
    44c4:      	cmp	w8, #0x4
    44c8:      	b.eq	0x48e4 <write_reg+0x5b4>
    44cc:      	cmp	w8, #0x8
    44d0:      	b.ne	0x4950 <write_reg+0x620>
    44d4:      	str	x3, [x0, #0x68]
    44d8:      	ret
    44dc:      	cmp	w8, #0x15
    44e0:      	b.gt	0x4644 <write_reg+0x314>
    44e4:      	cmp	w8, #0x14
    44e8:      	b.eq	0x47dc <write_reg+0x4ac>
    44ec:      	cmp	w8, #0x15
    44f0:      	b.ne	0x4950 <write_reg+0x620>
    44f4:      	and	w8, w2, #0xff
    44f8:      	cmp	w8, #0x4
    44fc:      	b.eq	0x4934 <write_reg+0x604>
    4500:      	cmp	w8, #0x8
    4504:      	b.ne	0x4950 <write_reg+0x620>
    4508:      	str	x3, [x0, #0xa8]
    450c:      	ret
    4510:      	cmp	w8, #0x1a
    4514:      	b.eq	0x468c <write_reg+0x35c>
    4518:      	cmp	w8, #0x1b
    451c:      	b.ne	0x4950 <write_reg+0x620>
    4520:      	and	w8, w2, #0xff
    4524:      	cmp	w8, #0x4
    4528:      	b.eq	0x4864 <write_reg+0x534>
    452c:      	cmp	w8, #0x8
    4530:      	b.ne	0x4950 <write_reg+0x620>
    4534:      	str	x3, [x0, #0xd8]
    4538:      	ret
    453c:      	cmp	w8, #0x1c
    4540:      	b.eq	0x46a8 <write_reg+0x378>
    4544:      	cmp	w8, #0x1d
    4548:      	b.ne	0x4950 <write_reg+0x620>
    454c:      	and	w8, w2, #0xff
    4550:      	cmp	w8, #0x4
    4554:      	b.eq	0x487c <write_reg+0x54c>
    4558:      	cmp	w8, #0x8
    455c:      	b.ne	0x4950 <write_reg+0x620>
    4560:      	str	x3, [x0, #0xe8]
    4564:      	ret
    4568:      	cmp	w8, #0x2
    456c:      	b.eq	0x4750 <write_reg+0x420>
    4570:      	cmp	w8, #0x3
    4574:      	b.ne	0x4950 <write_reg+0x620>
    4578:      	and	w8, w2, #0xff
    457c:      	cmp	w8, #0x4
    4580:      	b.eq	0x48ec <write_reg+0x5bc>
    4584:      	cmp	w8, #0x8
    4588:      	b.ne	0x4950 <write_reg+0x620>
    458c:      	str	x3, [x0, #0x18]
    4590:      	ret
    4594:      	cmp	w8, #0xa
    4598:      	b.eq	0x476c <write_reg+0x43c>
    459c:      	cmp	w8, #0xb
    45a0:      	b.ne	0x4950 <write_reg+0x620>
    45a4:      	and	w8, w2, #0xff
    45a8:      	cmp	w8, #0x4
    45ac:      	b.eq	0x48f4 <write_reg+0x5c4>
    45b0:      	cmp	w8, #0x8
    45b4:      	b.ne	0x4950 <write_reg+0x620>
    45b8:      	str	x3, [x0, #0x58]
    45bc:      	ret
    45c0:      	cmp	w8, #0x6
    45c4:      	b.eq	0x4788 <write_reg+0x458>
    45c8:      	cmp	w8, #0x7
    45cc:      	b.ne	0x4950 <write_reg+0x620>
    45d0:      	and	w8, w2, #0xff
    45d4:      	cmp	w8, #0x4
    45d8:      	b.eq	0x48fc <write_reg+0x5cc>
    45dc:      	cmp	w8, #0x8
    45e0:      	b.ne	0x4950 <write_reg+0x620>
    45e4:      	str	x3, [x0, #0x38]
    45e8:      	ret
    45ec:      	cmp	w8, #0xe
    45f0:      	b.eq	0x47a4 <write_reg+0x474>
    45f4:      	cmp	w8, #0xf
    45f8:      	b.ne	0x4950 <write_reg+0x620>
    45fc:      	and	w8, w2, #0xff
    4600:      	cmp	w8, #0x4
    4604:      	b.eq	0x4904 <write_reg+0x5d4>
    4608:      	cmp	w8, #0x8
    460c:      	b.ne	0x4950 <write_reg+0x620>
    4610:      	str	x3, [x0, #0x78]
    4614:      	ret
    4618:      	cmp	w8, #0x12
    461c:      	b.eq	0x47f8 <write_reg+0x4c8>
    4620:      	cmp	w8, #0x13
    4624:      	b.ne	0x4950 <write_reg+0x620>
    4628:      	and	w8, w2, #0xff
    462c:      	cmp	w8, #0x4
    4630:      	b.eq	0x493c <write_reg+0x60c>
    4634:      	cmp	w8, #0x8
    4638:      	b.ne	0x4950 <write_reg+0x620>
    463c:      	str	x3, [x0, #0x98]
    4640:      	ret
    4644:      	cmp	w8, #0x16
    4648:      	b.eq	0x4814 <write_reg+0x4e4>
    464c:      	cmp	w8, #0x17
    4650:      	b.ne	0x4950 <write_reg+0x620>
    4654:      	and	w8, w2, #0xff
    4658:      	cmp	w8, #0x4
    465c:      	b.eq	0x4944 <write_reg+0x614>
    4660:      	cmp	w8, #0x8
    4664:      	b.ne	0x4950 <write_reg+0x620>
    4668:      	str	x3, [x0, #0xb8]
    466c:      	ret
    4670:      	and	w8, w2, #0xff
    4674:      	cmp	w8, #0x4
    4678:      	b.eq	0x484c <write_reg+0x51c>
    467c:      	cmp	w8, #0x8
    4680:      	b.ne	0x4950 <write_reg+0x620>
    4684:      	str	x3, [x0, #0xc0]
    4688:      	ret
    468c:      	and	w8, w2, #0xff
    4690:      	cmp	w8, #0x4
    4694:      	b.eq	0x4854 <write_reg+0x524>
    4698:      	cmp	w8, #0x8
    469c:      	b.ne	0x4950 <write_reg+0x620>
    46a0:      	str	x3, [x0, #0xd0]
    46a4:      	ret
    46a8:      	and	w8, w2, #0xff
    46ac:      	cmp	w8, #0x4
    46b0:      	b.eq	0x486c <write_reg+0x53c>
    46b4:      	cmp	w8, #0x8
    46b8:      	b.ne	0x4950 <write_reg+0x620>
    46bc:      	str	x3, [x0, #0xe0]
    46c0:      	ret
    46c4:      	and	w8, w2, #0xff
    46c8:      	cmp	w8, #0x4
    46cc:      	b.eq	0x4874 <write_reg+0x544>
    46d0:      	cmp	w8, #0x8
    46d4:      	b.ne	0x4950 <write_reg+0x620>
    46d8:      	str	x3, [x0, #0x100]
    46dc:      	ret
    46e0:      	and	w8, w2, #0xff
    46e4:      	cmp	w8, #0x4
    46e8:      	b.eq	0x488c <write_reg+0x55c>
    46ec:      	cmp	w8, #0x8
    46f0:      	b.ne	0x4950 <write_reg+0x620>
    46f4:      	str	x3, [x0]
    46f8:      	ret
    46fc:      	and	w8, w2, #0xff
    4700:      	cmp	w8, #0x4
    4704:      	b.eq	0x4894 <write_reg+0x564>
    4708:      	cmp	w8, #0x8
    470c:      	b.ne	0x4950 <write_reg+0x620>
    4710:      	str	x3, [x0, #0x40]
    4714:      	ret
    4718:      	and	w8, w2, #0xff
    471c:      	cmp	w8, #0x4
    4720:      	b.eq	0x489c <write_reg+0x56c>
    4724:      	cmp	w8, #0x8
    4728:      	b.ne	0x4950 <write_reg+0x620>
    472c:      	str	x3, [x0, #0x20]
    4730:      	ret
    4734:      	and	w8, w2, #0xff
    4738:      	cmp	w8, #0x4
    473c:      	b.eq	0x48a4 <write_reg+0x574>
    4740:      	cmp	w8, #0x8
    4744:      	b.ne	0x4950 <write_reg+0x620>
    4748:      	str	x3, [x0, #0x60]
    474c:      	ret
    4750:      	and	w8, w2, #0xff
    4754:      	cmp	w8, #0x4
    4758:      	b.eq	0x48ac <write_reg+0x57c>
    475c:      	cmp	w8, #0x8
    4760:      	b.ne	0x4950 <write_reg+0x620>
    4764:      	str	x3, [x0, #0x10]
    4768:      	ret
    476c:      	and	w8, w2, #0xff
    4770:      	cmp	w8, #0x4
    4774:      	b.eq	0x48b4 <write_reg+0x584>
    4778:      	cmp	w8, #0x8
    477c:      	b.ne	0x4950 <write_reg+0x620>
    4780:      	str	x3, [x0, #0x50]
    4784:      	ret
    4788:      	and	w8, w2, #0xff
    478c:      	cmp	w8, #0x4
    4790:      	b.eq	0x48bc <write_reg+0x58c>
    4794:      	cmp	w8, #0x8
    4798:      	b.ne	0x4950 <write_reg+0x620>
    479c:      	str	x3, [x0, #0x30]
    47a0:      	ret
    47a4:      	and	w8, w2, #0xff
    47a8:      	cmp	w8, #0x4
    47ac:      	b.eq	0x48c4 <write_reg+0x594>
    47b0:      	cmp	w8, #0x8
    47b4:      	b.ne	0x4950 <write_reg+0x620>
    47b8:      	str	x3, [x0, #0x70]
    47bc:      	ret
    47c0:      	and	w8, w2, #0xff
    47c4:      	cmp	w8, #0x4
    47c8:      	b.eq	0x490c <write_reg+0x5dc>
    47cc:      	cmp	w8, #0x8
    47d0:      	b.ne	0x4950 <write_reg+0x620>
    47d4:      	str	x3, [x0, #0x80]
    47d8:      	ret
    47dc:      	and	w8, w2, #0xff
    47e0:      	cmp	w8, #0x4
    47e4:      	b.eq	0x4914 <write_reg+0x5e4>
    47e8:      	cmp	w8, #0x8
    47ec:      	b.ne	0x4950 <write_reg+0x620>
    47f0:      	str	x3, [x0, #0xa0]
    47f4:      	ret
    47f8:      	and	w8, w2, #0xff
    47fc:      	cmp	w8, #0x4
    4800:      	b.eq	0x491c <write_reg+0x5ec>
    4804:      	cmp	w8, #0x8
    4808:      	b.ne	0x4950 <write_reg+0x620>
    480c:      	str	x3, [x0, #0x90]
    4810:      	ret
    4814:      	and	w8, w2, #0xff
    4818:      	cmp	w8, #0x4
    481c:      	b.eq	0x4924 <write_reg+0x5f4>
    4820:      	cmp	w8, #0x8
    4824:      	b.ne	0x4950 <write_reg+0x620>
    4828:      	str	x3, [x0, #0xb0]
    482c:      	ret
    4830:      	and	w8, w2, #0xff
    4834:      	cmp	w8, #0x4
    4838:      	b.eq	0x494c <write_reg+0x61c>
    483c:      	cmp	w8, #0x8
    4840:      	b.ne	0x4950 <write_reg+0x620>
    4844:      	str	x3, [x0, #0xf0]
    4848:      	ret
    484c:      	str	w3, [x0, #0xc0]
    4850:      	ret
    4854:      	str	w3, [x0, #0xd0]
    4858:      	ret
    485c:      	str	w3, [x0, #0xc8]
    4860:      	ret
    4864:      	str	w3, [x0, #0xd8]
    4868:      	ret
    486c:      	str	w3, [x0, #0xe0]
    4870:      	ret
    4874:      	str	w3, [x0, #0x100]
    4878:      	ret
    487c:      	str	w3, [x0, #0xe8]
    4880:      	ret
    4884:      	str	w3, [x0, #0xf8]
    4888:      	ret
    488c:      	str	w3, [x0]
    4890:      	ret
    4894:      	str	w3, [x0, #0x40]
    4898:      	ret
    489c:      	str	w3, [x0, #0x20]
    48a0:      	ret
    48a4:      	str	w3, [x0, #0x60]
    48a8:      	ret
    48ac:      	str	w3, [x0, #0x10]
    48b0:      	ret
    48b4:      	str	w3, [x0, #0x50]
    48b8:      	ret
    48bc:      	str	w3, [x0, #0x30]
    48c0:      	ret
    48c4:      	str	w3, [x0, #0x70]
    48c8:      	ret
    48cc:      	str	w3, [x0, #0x8]
    48d0:      	ret
    48d4:      	str	w3, [x0, #0x48]
    48d8:      	ret
    48dc:      	str	w3, [x0, #0x28]
    48e0:      	ret
    48e4:      	str	w3, [x0, #0x68]
    48e8:      	ret
    48ec:      	str	w3, [x0, #0x18]
    48f0:      	ret
    48f4:      	str	w3, [x0, #0x58]
    48f8:      	ret
    48fc:      	str	w3, [x0, #0x38]
    4900:      	ret
    4904:      	str	w3, [x0, #0x78]
    4908:      	ret
    490c:      	str	w3, [x0, #0x80]
    4910:      	ret
    4914:      	str	w3, [x0, #0xa0]
    4918:      	ret
    491c:      	str	w3, [x0, #0x90]
    4920:      	ret
    4924:      	str	w3, [x0, #0xb0]
    4928:      	ret
    492c:      	str	w3, [x0, #0x88]
    4930:      	ret
    4934:      	str	w3, [x0, #0xa8]
    4938:      	ret
    493c:      	str	w3, [x0, #0x98]
    4940:      	ret
    4944:      	str	w3, [x0, #0xb8]
    4948:      	ret
    494c:      	str	w3, [x0, #0xf0]
    4950:      	ret

Disassembly of section uprobe.multi:

0000000000000000 <generic_uprobe_setup_event>:
       0:      	sub	sp, sp, #0x80
       4:      	stp	x30, x25, [sp, #0x40]
       8:      	stp	x24, x23, [sp, #0x50]
       c:      	stp	x22, x21, [sp, #0x60]
      10:      	stp	x20, x19, [sp, #0x70]
      14:      	str	wzr, [sp, #0x4]
      18:      	adrp	x20, 0x0 <generic_uprobe_setup_event>
      1c:      	mov	w8, #0x1                // =1
      20:      	add	x9, sp, #0x4
      24:      	ldr	x20, [x20]
      28:      	mov	x19, x0
      2c:      	add	x1, sp, #0x4
      30:      	mov	x0, x20
      34:      	blr	x8
      38:      	cbz	x0, 0x2a4 <generic_uprobe_setup_event+0x2a4>
      3c:      	adrp	x21, 0x0 <generic_uprobe_setup_event>
      40:      	mov	w8, #0x5ef8             // =24312
      44:      	mov	x22, x0
      48:      	ldr	x21, [x21]
      4c:      	add	x1, x0, x8
      50:      	mov	w8, #0x1                // =1
      54:      	mov	x0, x21
      58:      	blr	x8
      5c:      	cbz	x0, 0x2a4 <generic_uprobe_setup_event+0x2a4>
      60:      	mov	w25, #0x8               // =8
      64:      	add	x8, sp, #0x18
      68:      	mov	w9, #0x4                // =4
      6c:      	mov	x23, x0
      70:      	add	x0, sp, #0x18
      74:      	mov	w1, #0x8                // =8
      78:      	mov	x2, x19
      7c:      	mov	w24, #0x4               // =4
      80:      	blr	x9
      84:      	ldr	x8, [sp, #0x18]
      88:      	add	x2, x19, #0x8
      8c:      	mov	w9, #0x4                // =4
      90:      	add	x0, sp, #0x18
      94:      	str	x8, [x22, #0x5e50]
      98:      	add	x8, sp, #0x18
      9c:      	mov	w1, #0x8                // =8
      a0:      	blr	x9
      a4:      	ldr	x8, [sp, #0x18]
      a8:      	add	x2, x19, #0x10
      ac:      	mov	w9, #0x4                // =4
      b0:      	add	x0, sp, #0x18
      b4:      	str	x8, [x22, #0x5e58]
      b8:      	add	x8, sp, #0x18
      bc:      	mov	w1, #0x8                // =8
      c0:      	blr	x9
      c4:      	ldr	x8, [sp, #0x18]
      c8:      	add	x2, x19, #0x18
      cc:      	mov	w9, #0x4                // =4
      d0:      	add	x0, sp, #0x18
      d4:      	str	x8, [x22, #0x5e60]
      d8:      	add	x8, sp, #0x18
      dc:      	mov	w1, #0x8                // =8
      e0:      	blr	x9
      e4:      	ldr	x8, [sp, #0x18]
      e8:      	add	x2, x19, #0x20
      ec:      	add	x0, sp, #0x18
      f0:      	mov	w1, #0x8                // =8
      f4:      	str	x8, [x22, #0x5e68]
      f8:      	add	x8, sp, #0x18
      fc:      	blr	x24
     100:      	ldr	x8, [sp, #0x18]
     104:      	strh	wzr, [x22, #0x2]
     108:      	str	wzr, [x22, #0x4]
     10c:      	str	x8, [x22, #0x5e70]
     110:      	mov	w8, #0xf                // =15
     114:      	strb	w8, [x22]
     118:      	mov	w8, #0x7d               // =125
     11c:      	blr	x8
     120:      	str	x0, [x22, #0x8]
     124:      	str	xzr, [x22, #0x70]
     128:      	mov	w8, #0xe                // =14
     12c:      	mov	w24, #0xe               // =14
     130:      	str	wzr, [x22, #0x14]
     134:      	blr	x8
     138:      	str	w0, [x22, #0x7c]
     13c:      	blr	x24
     140:      	cmn	x0, #0x16
     144:      	b.ne	0x168 <generic_uprobe_setup_event+0x168>
     148:      	add	x2, x19, #0xe8
     14c:      	mov	w8, #0x8                // =8
     150:      	mov	w9, #0x4                // =4
     154:      	add	x10, sp, #0x18
     158:      	add	x0, sp, #0x18
     15c:      	mov	w1, #0x8                // =8
     160:      	blr	x9
     164:      	ldr	x0, [sp, #0x18]
     168:      	str	x0, [x22, #0x68]
     16c:      	ldr	w8, [x23, #0x5c]
     170:      	cmp	w8, #0x1
     174:      	b.lt	0x22c <generic_uprobe_setup_event+0x22c>
     178:      	ldr	x8, [x22, #0x60]
     17c:      	ldr	x9, [x22, #0x8]
     180:      	mov	w10, #0x1               // =1
     184:      	mov	x3, xzr
     188:      	add	x1, sp, #0x8
     18c:      	add	x2, sp, #0x18
     190:      	str	xzr, [sp, #0x28]
     194:      	stp	x9, x10, [sp, #0x18]
     198:      	stp	x8, x0, [sp, #0x8]
     19c:      	adrp	x0, 0x0 <generic_uprobe_setup_event>
     1a0:      	mov	w8, #0x2                // =2
     1a4:      	add	x9, sp, #0x8
     1a8:      	add	x10, sp, #0x18
     1ac:      	ldr	x0, [x0]
     1b0:      	blr	x8
     1b4:      	cbz	x0, 0x22c <generic_uprobe_setup_event+0x22c>
     1b8:      	neg	w8, w0
     1bc:      	adrp	x22, 0x0 <generic_uprobe_setup_event>
     1c0:      	mov	w9, #0x1                // =1
     1c4:      	strh	w8, [sp, #0x34]
     1c8:      	mov	w8, #0x5                // =5
     1cc:      	add	x1, sp, #0x34
     1d0:      	mov	w23, #0x1               // =1
     1d4:      	strh	w8, [sp, #0x36]
     1d8:      	mov	x8, #0x46               // =70
     1dc:      	movk	x8, #0x2, lsl #32
     1e0:      	stur	x8, [sp, #0x38]
     1e4:      	add	x8, sp, #0x34
     1e8:      	ldr	x22, [x22]
     1ec:      	mov	x0, x22
     1f0:      	blr	x9
     1f4:      	cbz	x0, 0x208 <generic_uprobe_setup_event+0x208>
     1f8:      	ldr	w8, [x0]
     1fc:      	add	w8, w8, #0x1
     200:      	str	w8, [x0]
     204:      	b	0x22c <generic_uprobe_setup_event+0x22c>
     208:      	str	w23, [sp, #0x30]
     20c:      	mov	x3, xzr
     210:      	mov	w8, #0x2                // =2
     214:      	add	x9, sp, #0x34
     218:      	add	x10, sp, #0x30
     21c:      	add	x1, sp, #0x34
     220:      	add	x2, sp, #0x30
     224:      	mov	x0, x22
     228:      	blr	x8
     22c:      	str	wzr, [sp, #0x18]
     230:      	mov	w8, #0x1                // =1
     234:      	add	x9, sp, #0x18
     238:      	add	x1, sp, #0x18
     23c:      	mov	x0, x20
     240:      	blr	x8
     244:      	adrp	x20, 0x0 <generic_uprobe_setup_event>
     248:      	ldr	x20, [x20]
     24c:      	cbz	x0, 0x274 <generic_uprobe_setup_event+0x274>
     250:      	mov	w8, #0x5ef8             // =24312
     254:      	add	x1, x0, x8
     258:      	mov	w8, #0x1                // =1
     25c:      	mov	x0, x21
     260:      	blr	x8
     264:      	cbz	x0, 0x274 <generic_uprobe_setup_event+0x274>
     268:      	ldr	w8, [x0, #0x40]
     26c:      	cmn	w8, #0x1
     270:      	b.ne	0x28c <generic_uprobe_setup_event+0x28c>
     274:      	mov	w8, #0x3                // =3
     278:      	mov	w9, #0xc                // =12
     27c:      	mov	x0, x19
     280:      	mov	x1, x20
     284:      	mov	w2, #0x3                // =3
     288:      	blr	x9
     28c:      	mov	w8, #0x1                // =1
     290:      	mov	w9, #0xc                // =12
     294:      	mov	x0, x19
     298:      	mov	x1, x20
     29c:      	mov	w2, #0x1                // =1
     2a0:      	blr	x9
     2a4:      	ldp	x20, x19, [sp, #0x70]
     2a8:      	mov	w0, wzr
     2ac:      	ldp	x22, x21, [sp, #0x60]
     2b0:      	ldp	x24, x23, [sp, #0x50]
     2b4:      	ldp	x30, x25, [sp, #0x40]
     2b8:      	add	sp, sp, #0x80
     2bc:      	ret

00000000000002c0 <generic_uprobe_process_event>:
     2c0:      	sub	sp, sp, #0x160
     2c4:      	str	x29, [sp, #0x110]
     2c8:      	stp	x30, x25, [sp, #0x120]
     2cc:      	stp	x24, x23, [sp, #0x130]
     2d0:      	stp	x22, x21, [sp, #0x140]
     2d4:      	stp	x20, x19, [sp, #0x150]
     2d8:      	str	wzr, [sp, #0x5c]
     2dc:      	adrp	x25, 0x0 <generic_uprobe_setup_event>
     2e0:      	mov	w8, #0x1                // =1
     2e4:      	add	x9, sp, #0x5c
     2e8:      	ldr	x25, [x25]
     2ec:      	mov	x19, x0
     2f0:      	add	x1, sp, #0x5c
     2f4:      	mov	x0, x25
     2f8:      	blr	x8
     2fc:      	cbz	x0, 0x8d0 <generic_uprobe_process_event+0x610>
     300:      	ldr	w24, [x0, #0x4]
     304:      	mov	w21, #0x5efc            // =24316
     308:      	mov	x20, x0
     30c:      	ldr	w23, [x0, x21]
     310:      	lsr	w8, w24, #3
     314:      	cmp	w8, #0x464
     318:      	b.hi	0x834 <generic_uprobe_process_event+0x574>
     31c:      	str	wzr, [sp, #0x68]
     320:      	mov	w8, #0x1                // =1
     324:      	add	x9, sp, #0x68
     328:      	add	x1, sp, #0x68
     32c:      	mov	x0, x25
     330:      	blr	x8
     334:      	cbz	x0, 0x834 <generic_uprobe_process_event+0x574>
     338:      	mov	w8, #0x5ef8             // =24312
     33c:      	mov	x22, x0
     340:      	add	x1, x0, x8
     344:      	adrp	x0, 0x0 <generic_uprobe_setup_event>
     348:      	mov	w8, #0x1                // =1
     34c:      	ldr	x0, [x0]
     350:      	blr	x8
     354:      	cmp	w23, #0x4
     358:      	ccmp	x0, #0x0, #0x4, le
     35c:      	b.eq	0x834 <generic_uprobe_process_event+0x574>
     360:      	and	x29, x23, #0x7
     364:      	stp	x23, x19, [sp, #0x48]
     368:      	mov	w9, #0x5ea0             // =24224
     36c:      	add	x19, sp, #0xe0
     370:      	add	x8, x0, x29, lsl #2
     374:      	ldrsw	x23, [x8, #0x18]
     378:      	str	x24, [sp, #0x118]
     37c:      	ldr	w24, [x8, #0x4]
     380:      	add	x8, x22, x29, lsl #2
     384:      	add	x25, x8, x9
     388:      	str	wzr, [x25]
     38c:      	and	x10, x23, #0xffffffff
     390:      	str	x10, [sp, #0x38]
     394:      	tbnz	w23, #0x8, 0x3c8 <generic_uprobe_process_event+0x108>
     398:      	tbnz	w10, #0x7, 0x438 <generic_uprobe_process_event+0x178>
     39c:      	ldr	x19, [sp, #0x50]
     3a0:      	tbnz	w23, #0x6, 0x49c <generic_uprobe_process_event+0x1dc>
     3a4:      	add	x8, x0, x29, lsl #2
     3a8:      	ldr	w8, [x8, #0x40]
     3ac:      	and	x8, x8, #0x7
     3b0:      	add	x8, x22, x8, lsl #3
     3b4:      	ldr	x10, [x8, #0x5e50]
     3b8:      	cmp	w29, #0x4
     3bc:      	str	x10, [sp, #0x60]
     3c0:      	b.ls	0x4f8 <generic_uprobe_process_event+0x238>
     3c4:      	b	0x5e8 <generic_uprobe_process_event+0x328>
     3c8:      	str	xzr, [sp, #0x98]
     3cc:      	mov	w8, #0xe                // =14
     3d0:      	blr	x8
     3d4:      	str	x0, [x19, #0x10]
     3d8:      	adrp	x0, 0x0 <generic_uprobe_setup_event>
     3dc:      	mov	w8, #0x1                // =1
     3e0:      	add	x9, sp, #0xf0
     3e4:      	ldr	x0, [x0]
     3e8:      	add	x1, sp, #0xf0
     3ec:      	blr	x8
     3f0:      	cbz	x0, 0x428 <generic_uprobe_process_event+0x168>
     3f4:      	ldr	w8, [x0]
     3f8:      	cmp	w24, #0x6
     3fc:      	str	w8, [x25]
     400:      	b.ne	0x428 <generic_uprobe_process_event+0x168>
     404:      	add	x8, x0, #0x4
     408:      	mov	w9, #0x4                // =4
     40c:      	add	x10, sp, #0x98
     410:      	str	x8, [sp, #0x98]
     414:      	mov	w8, #0x8                // =8
     418:      	add	x0, sp, #0x98
     41c:      	add	x2, sp, #0x98
     420:      	mov	w1, #0x8                // =8
     424:      	blr	x9
     428:      	ldr	x10, [sp, #0x98]
     42c:      	ldr	x19, [sp, #0x50]
     430:      	str	x10, [sp, #0x60]
     434:      	b	0x5ec <generic_uprobe_process_event+0x32c>
     438:      	add	x8, x0, x29, lsl #2
     43c:      	mov	w10, #0x40              // =64
     440:      	ldr	x19, [sp, #0x50]
     444:      	ldrb	w9, [x8, #0x2c2]
     448:      	ldrh	w1, [x8, #0x2c0]
     44c:      	sub	w22, w10, w9, lsl #3
     450:      	ldr	w9, [x0, #0x54]
     454:      	cbz	w9, 0x4c0 <generic_uprobe_process_event+0x200>
     458:      	cbz	x19, 0x4e8 <generic_uprobe_process_event+0x228>
     45c:      	add	x2, x19, x1
     460:      	mov	w8, #0x8                // =8
     464:      	mov	w9, #0x4                // =4
     468:      	add	x10, sp, #0x98
     46c:      	mov	x21, x0
     470:      	add	x0, sp, #0x98
     474:      	mov	w1, #0x8                // =8
     478:      	blr	x9
     47c:      	ldr	x8, [sp, #0x98]
     480:      	mov	x0, x21
     484:      	lsl	x8, x8, x22
     488:      	asr	x10, x8, x22
     48c:      	cmp	w29, #0x4
     490:      	str	x10, [sp, #0x60]
     494:      	b.ls	0x4f8 <generic_uprobe_process_event+0x238>
     498:      	b	0x5e8 <generic_uprobe_process_event+0x328>
     49c:      	mov	w8, #0x23               // =35
     4a0:      	mov	x21, x0
     4a4:      	blr	x8
     4a8:      	mov	x10, x0
     4ac:      	mov	x0, x21
     4b0:      	cmp	w29, #0x4
     4b4:      	str	x10, [sp, #0x60]
     4b8:      	b.ls	0x4f8 <generic_uprobe_process_event+0x238>
     4bc:      	b	0x5e8 <generic_uprobe_process_event+0x328>
     4c0:      	mov	x21, x0
     4c4:      	mov	x0, x19
     4c8:      	mov	w2, w22
     4cc:      	bl	0x4cc <generic_uprobe_process_event+0x20c>
     4d0:      	mov	x10, x0
     4d4:      	mov	x0, x21
     4d8:      	cmp	w29, #0x4
     4dc:      	str	x10, [sp, #0x60]
     4e0:      	b.ls	0x4f8 <generic_uprobe_process_event+0x238>
     4e4:      	b	0x5e8 <generic_uprobe_process_event+0x328>
     4e8:      	mov	x10, xzr
     4ec:      	cmp	w29, #0x4
     4f0:      	str	x10, [sp, #0x60]
     4f4:      	b.hi	0x5e8 <generic_uprobe_process_event+0x328>
     4f8:      	mov	w8, #0x50               // =80
     4fc:      	mov	w21, #0x5efc            // =24316
     500:      	umaddl	x8, w29, w8, x0
     504:      	ldrh	w9, [x8, #0x76]
     508:      	cbz	w9, 0x5ec <generic_uprobe_process_event+0x32c>
     50c:      	add	x8, x8, #0x70
     510:      	add	x9, sp, #0x60
     514:      	strb	wzr, [sp, #0xa8]
     518:      	str	x25, [sp, #0xb0]
     51c:      	stp	x8, x9, [sp, #0x98]
     520:      	adrp	x8, 0x0 <generic_uprobe_setup_event>
     524:      	ldr	x8, [x8]
     528:      	ldrb	w8, [x8]
     52c:      	cbz	w8, 0x5c0 <generic_uprobe_process_event+0x300>
     530:      	mov	x25, xzr
     534:      	mov	w22, #0x1               // =1
     538:      	mov	w21, #0x8               // =8
     53c:      	b	0x568 <generic_uprobe_process_event+0x2a8>
     540:      	mov	w10, #0x4               // =4
     544:      	ldr	x0, [sp, #0xa0]
     548:      	mov	w1, #0x8                // =8
     54c:      	ldr	x2, [x0]
     550:      	blr	x10
     554:      	tbnz	w0, #0x1f, 0x5b4 <generic_uprobe_process_event+0x2f4>
     558:      	add	x25, x25, #0x8
     55c:      	add	w22, w22, #0x1
     560:      	cmp	x25, #0x50
     564:      	b.eq	0x5e4 <generic_uprobe_process_event+0x324>
     568:      	ldr	x8, [sp, #0x98]
     56c:      	add	x10, x8, x25
     570:      	ldrh	w8, [x10, #0x6]
     574:      	cbz	w8, 0x5e4 <generic_uprobe_process_event+0x324>
     578:      	ldr	x8, [sp, #0xa0]
     57c:      	ldr	w11, [x10]
     580:      	ldr	x9, [x8]
     584:      	add	x9, x9, x11
     588:      	str	x9, [x8]
     58c:      	ldrh	w10, [x10, #0x4]
     590:      	cbz	w10, 0x558 <generic_uprobe_process_event+0x298>
     594:      	ldrb	w10, [sp, #0xa8]
     598:      	cbz	w10, 0x540 <generic_uprobe_process_event+0x280>
     59c:      	mov	w10, #0x94              // =148
     5a0:      	ldr	x0, [sp, #0xa0]
     5a4:      	mov	w1, #0x8                // =8
     5a8:      	ldr	x2, [x0]
     5ac:      	blr	x10
     5b0:      	tbz	w0, #0x1f, 0x558 <generic_uprobe_process_event+0x298>
     5b4:      	ldr	x8, [sp, #0xb0]
     5b8:      	str	w22, [x8]
     5bc:      	b	0x5e4 <generic_uprobe_process_event+0x324>
     5c0:      	mov	x3, xzr
     5c4:      	adrp	x1, 0x0 <generic_uprobe_setup_event>
     5c8:      	add	x1, x1, #0x0
     5cc:      	mov	w8, #0xa                // =10
     5d0:      	mov	w9, #0xb5               // =181
     5d4:      	add	x10, sp, #0x98
     5d8:      	add	x2, sp, #0x98
     5dc:      	mov	w0, #0xa                // =10
     5e0:      	blr	x9
     5e4:      	ldr	x10, [sp, #0x60]
     5e8:      	mov	w21, #0x5efc            // =24316
     5ec:      	mov	w22, #0x1000            // =4096
     5f0:      	cmp	w24, #0x15
     5f4:      	b.gt	0x630 <generic_uprobe_process_event+0x370>
     5f8:      	adrp	x25, 0x0 <generic_uprobe_setup_event>
     5fc:      	cmp	w24, #0xb
     600:      	ldr	x25, [x25]
     604:      	b.gt	0x668 <generic_uprobe_process_event+0x3a8>
     608:      	cmp	w24, #0x5
     60c:      	b.gt	0x6d8 <generic_uprobe_process_event+0x418>
     610:      	cmp	w24, #0x3
     614:      	b.gt	0x76c <generic_uprobe_process_event+0x4ac>
     618:      	sub	w8, w24, #0x2
     61c:      	cmp	w8, #0x2
     620:      	b.lo	0x728 <generic_uprobe_process_event+0x468>
     624:      	cmp	w24, #0x1
     628:      	b.eq	0x728 <generic_uprobe_process_event+0x468>
     62c:      	b	0x7a4 <generic_uprobe_process_event+0x4e4>
     630:      	adrp	x25, 0x0 <generic_uprobe_setup_event>
     634:      	cmp	w24, #0x20
     638:      	ldr	x25, [x25]
     63c:      	b.le	0x68c <generic_uprobe_process_event+0x3cc>
     640:      	cmp	w24, #0x27
     644:      	b.gt	0x6b0 <generic_uprobe_process_event+0x3f0>
     648:      	sub	w8, w24, #0x21
     64c:      	cmp	w8, #0x4
     650:      	b.lo	0x784 <generic_uprobe_process_event+0x4c4>
     654:      	cmp	w24, #0x25
     658:      	b.eq	0x7a8 <generic_uprobe_process_event+0x4e8>
     65c:      	cmp	w24, #0x27
     660:      	b.eq	0x730 <generic_uprobe_process_event+0x470>
     664:      	b	0x7a4 <generic_uprobe_process_event+0x4e4>
     668:      	cmp	w24, #0x11
     66c:      	b.gt	0x6fc <generic_uprobe_process_event+0x43c>
     670:      	sub	w8, w24, #0xf
     674:      	cmp	w8, #0x3
     678:      	b.lo	0x7a8 <generic_uprobe_process_event+0x4e8>
     67c:      	sub	w8, w24, #0xc
     680:      	cmp	w8, #0x2
     684:      	b.lo	0x728 <generic_uprobe_process_event+0x468>
     688:      	b	0x7a4 <generic_uprobe_process_event+0x4e4>
     68c:      	cmp	w24, #0x1a
     690:      	b.gt	0x71c <generic_uprobe_process_event+0x45c>
     694:      	cmp	w24, #0x16
     698:      	b.eq	0x730 <generic_uprobe_process_event+0x470>
     69c:      	cmp	w24, #0x17
     6a0:      	b.eq	0x784 <generic_uprobe_process_event+0x4c4>
     6a4:      	cmp	w24, #0x1a
     6a8:      	b.eq	0x79c <generic_uprobe_process_event+0x4dc>
     6ac:      	b	0x7a4 <generic_uprobe_process_event+0x4e4>
     6b0:      	cmp	w24, #0x29
     6b4:      	b.le	0x750 <generic_uprobe_process_event+0x490>
     6b8:      	cmp	w24, #0x2a
     6bc:      	b.eq	0x7a8 <generic_uprobe_process_event+0x4e8>
     6c0:      	cmp	w24, #0x2b
     6c4:      	b.eq	0x764 <generic_uprobe_process_event+0x4a4>
     6c8:      	cmp	w24, #0x2c
     6cc:      	b.ne	0x7a4 <generic_uprobe_process_event+0x4e4>
     6d0:      	mov	w22, #0x70              // =112
     6d4:      	b	0x7a8 <generic_uprobe_process_event+0x4e8>
     6d8:      	cmp	w24, #0x9
     6dc:      	b.gt	0x784 <generic_uprobe_process_event+0x4c4>
     6e0:      	cmp	w24, #0x6
     6e4:      	b.eq	0x7a8 <generic_uprobe_process_event+0x4e8>
     6e8:      	cmp	w24, #0x7
     6ec:      	b.eq	0x77c <generic_uprobe_process_event+0x4bc>
     6f0:      	cmp	w24, #0x8
     6f4:      	b.eq	0x79c <generic_uprobe_process_event+0x4dc>
     6f8:      	b	0x7a4 <generic_uprobe_process_event+0x4e4>
     6fc:      	cmp	w24, #0x13
     700:      	b.gt	0x738 <generic_uprobe_process_event+0x478>
     704:      	cmp	w24, #0x12
     708:      	mov	x22, x23
     70c:      	b.eq	0x7a8 <generic_uprobe_process_event+0x4e8>
     710:      	cmp	w24, #0x13
     714:      	b.eq	0x764 <generic_uprobe_process_event+0x4a4>
     718:      	b	0x7a4 <generic_uprobe_process_event+0x4e4>
     71c:      	sub	w8, w24, #0x1d
     720:      	cmp	w8, #0x4
     724:      	b.hs	0x794 <generic_uprobe_process_event+0x4d4>
     728:      	mov	w22, #0x4               // =4
     72c:      	b	0x7a8 <generic_uprobe_process_event+0x4e8>
     730:      	mov	w22, #0x10              // =16
     734:      	b	0x7a8 <generic_uprobe_process_event+0x4e8>
     738:      	cmp	w24, #0x14
     73c:      	b.eq	0x78c <generic_uprobe_process_event+0x4cc>
     740:      	cmp	w24, #0x15
     744:      	b.ne	0x7a4 <generic_uprobe_process_event+0x4e4>
     748:      	mov	w22, #0x20              // =32
     74c:      	b	0x7a8 <generic_uprobe_process_event+0x4e8>
     750:      	cmp	w24, #0x28
     754:      	b.eq	0x764 <generic_uprobe_process_event+0x4a4>
     758:      	cmp	w24, #0x29
     75c:      	b.eq	0x77c <generic_uprobe_process_event+0x4bc>
     760:      	b	0x7a4 <generic_uprobe_process_event+0x4e4>
     764:      	mov	w22, #0x18              // =24
     768:      	b	0x7a8 <generic_uprobe_process_event+0x4e8>
     76c:      	cmp	w24, #0x4
     770:      	b.eq	0x784 <generic_uprobe_process_event+0x4c4>
     774:      	cmp	w24, #0x5
     778:      	b.ne	0x7a4 <generic_uprobe_process_event+0x4e4>
     77c:      	mov	w22, #0x40              // =64
     780:      	b	0x7a8 <generic_uprobe_process_event+0x4e8>
     784:      	mov	w22, #0x8               // =8
     788:      	b	0x7a8 <generic_uprobe_process_event+0x4e8>
     78c:      	mov	w22, #0x98              // =152
     790:      	b	0x7a8 <generic_uprobe_process_event+0x4e8>
     794:      	cmp	w24, #0x1b
     798:      	b.ne	0x7a4 <generic_uprobe_process_event+0x4e4>
     79c:      	mov	w22, #0x50              // =80
     7a0:      	b	0x7a8 <generic_uprobe_process_event+0x4e8>
     7a4:      	mov	x22, xzr
     7a8:      	str	x10, [sp, #0x40]
     7ac:      	str	wzr, [sp, #0x6c]
     7b0:      	mov	w8, #0x1                // =1
     7b4:      	add	x9, sp, #0x6c
     7b8:      	add	x1, sp, #0x6c
     7bc:      	mov	x0, x25
     7c0:      	blr	x8
     7c4:      	cbz	x0, 0x82c <generic_uprobe_process_event+0x56c>
     7c8:      	ldr	x9, [sp, #0x118]
     7cc:      	mov	w8, #0x3ffb             // =16379
     7d0:      	sub	x8, x8, x22
     7d4:      	cmp	x8, x9
     7d8:      	b.ls	0x82c <generic_uprobe_process_event+0x56c>
     7dc:      	add	x22, x0, x29, lsl #2
     7e0:      	mov	w8, #0x5ea0             // =24224
     7e4:      	add	x11, x0, #0x90
     7e8:      	ldr	w9, [x22, x8]
     7ec:      	ldr	x8, [sp, #0x118]
     7f0:      	add	x10, x0, x29, lsl #3
     7f4:      	str	w9, [x11, x8]
     7f8:      	add	x8, x8, #0x4
     7fc:      	str	x8, [x10, #0x5e78]
     800:      	cbz	w9, 0x8f0 <generic_uprobe_process_event+0x630>
     804:      	ldr	x23, [sp, #0x48]
     808:      	ldr	x24, [sp, #0x118]
     80c:      	mov	w8, #0x4                // =4
     810:      	add	w24, w8, w24
     814:      	str	w24, [x20, #0x4]
     818:      	adrp	x22, 0x0 <generic_uprobe_setup_event>
     81c:      	cmp	w23, #0x3
     820:      	ldr	x22, [x22]
     824:      	b.le	0x848 <generic_uprobe_process_event+0x588>
     828:      	b	0x8b4 <generic_uprobe_process_event+0x5f4>
     82c:      	ldr	x23, [sp, #0x48]
     830:      	ldr	x24, [sp, #0x118]
     834:      	str	w24, [x20, #0x4]
     838:      	adrp	x22, 0x0 <generic_uprobe_setup_event>
     83c:      	cmp	w23, #0x3
     840:      	ldr	x22, [x22]
     844:      	b.gt	0x8b4 <generic_uprobe_process_event+0x5f4>
     848:      	str	wzr, [sp, #0x98]
     84c:      	mov	w8, #0x1                // =1
     850:      	add	x9, sp, #0x98
     854:      	add	x1, sp, #0x98
     858:      	mov	x0, x25
     85c:      	blr	x8
     860:      	cbz	x0, 0x8b4 <generic_uprobe_process_event+0x5f4>
     864:      	mov	w8, #0x5ef8             // =24312
     868:      	add	x1, x0, x8
     86c:      	adrp	x0, 0x0 <generic_uprobe_setup_event>
     870:      	mov	w8, #0x1                // =1
     874:      	ldr	x0, [x0]
     878:      	blr	x8
     87c:      	cbz	x0, 0x8b4 <generic_uprobe_process_event+0x5f4>
     880:      	add	w8, w23, #0x1
     884:      	and	w9, w8, #0x7
     888:      	add	x9, x0, w9, uxtw #2
     88c:      	ldr	w9, [x9, #0x40]
     890:      	cmn	w9, #0x1
     894:      	b.eq	0x8b4 <generic_uprobe_process_event+0x5f4>
     898:      	str	w8, [x20, x21]
     89c:      	mov	w8, #0x1                // =1
     8a0:      	mov	w9, #0xc                // =12
     8a4:      	mov	x0, x19
     8a8:      	mov	x1, x22
     8ac:      	mov	w2, #0x1                // =1
     8b0:      	blr	x9
     8b4:      	str	wzr, [x20, x21]
     8b8:      	mov	w8, #0x3                // =3
     8bc:      	mov	w9, #0xc                // =12
     8c0:      	mov	x0, x19
     8c4:      	mov	x1, x22
     8c8:      	mov	w2, #0x3                // =3
     8cc:      	blr	x9
     8d0:      	ldp	x20, x19, [sp, #0x150]
     8d4:      	mov	w0, wzr
     8d8:      	ldr	x29, [sp, #0x110]
     8dc:      	ldp	x22, x21, [sp, #0x140]
     8e0:      	ldp	x24, x23, [sp, #0x130]
     8e4:      	ldp	x30, x25, [sp, #0x120]
     8e8:      	add	sp, sp, #0x160
     8ec:      	ret
     8f0:      	ldr	x10, [sp, #0x40]
     8f4:      	and	x29, x8, #0x3fff
     8f8:      	cmp	w24, #0x17
     8fc:      	add	x8, x11, x29
     900:      	stp	x8, x11, [sp, #0x28]
     904:      	add	x8, sp, #0xe0
     908:      	str	xzr, [x8, #0x10]
     90c:      	str	x10, [sp, #0x98]
     910:      	b.le	0x938 <generic_uprobe_process_event+0x678>
     914:      	cmp	w24, #0x18
     918:      	b.eq	0x954 <generic_uprobe_process_event+0x694>
     91c:      	cmp	w24, #0x25
     920:      	b.eq	0x9a8 <generic_uprobe_process_event+0x6e8>
     924:      	cmp	w24, #0x2a
     928:      	b.ne	0xed4 <generic_uprobe_process_event+0xc14>
     92c:      	stp	xzr, x10, [sp, #0x70]
     930:      	add	x21, sp, #0x70
     934:      	b	0xa08 <generic_uprobe_process_event+0x748>
     938:      	cmp	w24, #0xf
     93c:      	b.eq	0x9dc <generic_uprobe_process_event+0x71c>
     940:      	cmp	w24, #0x10
     944:      	b.ne	0xed4 <generic_uprobe_process_event+0xc14>
     948:      	add	x21, sp, #0x100
     94c:      	add	x19, sp, #0xe0
     950:      	b	0x97c <generic_uprobe_process_event+0x6bc>
     954:      	add	x21, sp, #0x100
     958:      	mov	w8, #0x8                // =8
     95c:      	mov	w9, #0x4                // =4
     960:      	ldr	x2, [sp, #0x98]
     964:      	add	x0, sp, #0x100
     968:      	mov	w1, #0x8                // =8
     96c:      	blr	x9
     970:      	add	x19, sp, #0xe0
     974:      	ldr	x8, [x19, #0x20]
     978:      	str	x8, [sp, #0x98]
     97c:      	mov	w8, #0x8                // =8
     980:      	mov	w9, #0x4                // =4
     984:      	add	x10, sp, #0x98
     988:      	add	x0, sp, #0x100
     98c:      	add	x2, sp, #0x98
     990:      	mov	w1, #0x8                // =8
     994:      	blr	x9
     998:      	ldr	x8, [x19, #0x20]
     99c:      	ldr	x19, [sp, #0x50]
     9a0:      	add	x21, x8, #0x40
     9a4:      	b	0xa08 <generic_uprobe_process_event+0x748>
     9a8:      	add	x8, x10, #0x40
     9ac:      	mov	w9, #0x8                // =8
     9b0:      	mov	w10, #0x4               // =4
     9b4:      	str	x8, [sp, #0x98]
     9b8:      	add	x11, sp, #0x100
     9bc:      	add	x0, sp, #0x100
     9c0:      	mov	w1, #0x8                // =8
     9c4:      	ldr	x2, [sp, #0x98]
     9c8:      	blr	x10
     9cc:      	add	x8, sp, #0xe0
     9d0:      	ldr	x8, [x8, #0x20]
     9d4:      	add	x21, x8, #0x40
     9d8:      	b	0xa08 <generic_uprobe_process_event+0x748>
     9dc:      	mov	w8, #0x8                // =8
     9e0:      	mov	w9, #0x4                // =4
     9e4:      	add	x10, sp, #0xf0
     9e8:      	add	x11, sp, #0x98
     9ec:      	add	x0, sp, #0xf0
     9f0:      	add	x2, sp, #0x98
     9f4:      	mov	w1, #0x8                // =8
     9f8:      	blr	x9
     9fc:      	add	x8, sp, #0xe0
     a00:      	ldr	x21, [x8, #0x10]
     a04:      	cbz	x21, 0x1098 <generic_uprobe_process_event+0xdd8>
     a08:      	str	wzr, [sp, #0x84]
     a0c:      	adrp	x0, 0x0 <generic_uprobe_setup_event>
     a10:      	mov	w8, #0x1                // =1
     a14:      	add	x9, sp, #0x84
     a18:      	ldr	x0, [x0]
     a1c:      	add	x1, sp, #0x84
     a20:      	blr	x8
     a24:      	cbz	x0, 0xfd0 <generic_uprobe_process_event+0xd10>
     a28:      	add	x8, x0, #0x1, lsl #12   // =0x1000
     a2c:      	str	x22, [sp, #0x20]
     a30:      	mov	x24, x0
     a34:      	str	x8, [sp, #0x40]
     a38:      	mov	w8, #0x23               // =35
     a3c:      	blr	x8
     a40:      	add	x2, x0, #0xb30
     a44:      	mov	w23, #0x8               // =8
     a48:      	add	x8, sp, #0x88
     a4c:      	mov	w9, #0x4                // =4
     a50:      	add	x0, sp, #0x88
     a54:      	mov	w1, #0x8                // =8
     a58:      	mov	w22, #0x4               // =4
     a5c:      	blr	x9
     a60:      	ldr	x8, [sp, #0x88]
     a64:      	add	x2, x21, #0x8
     a68:      	mov	w9, #0x4                // =4
     a6c:      	add	x0, sp, #0x90
     a70:      	stp	x8, x21, [sp, #0x10]
     a74:      	add	x8, x8, #0x18
     a78:      	mov	w1, #0x8                // =8
     a7c:      	str	x8, [sp, #0x50]
     a80:      	add	x8, sp, #0x90
     a84:      	str	x2, [sp, #0x38]
     a88:      	blr	x9
     a8c:      	ldr	x21, [sp, #0x90]
     a90:      	add	x29, sp, #0x98
     a94:      	add	x0, sp, #0x98
     a98:      	mov	w1, #0x8                // =8
     a9c:      	add	x2, x21, #0x10
     aa0:      	blr	x22
     aa4:      	ldr	x8, [sp, #0x98]
     aa8:      	cbz	x8, 0xab8 <generic_uprobe_process_event+0x7f8>
     aac:      	ldr	x9, [sp, #0x40]
     ab0:      	mov	w8, #0x1000             // =4096
     ab4:      	b	0xb00 <generic_uprobe_process_event+0x840>
     ab8:      	add	x2, x21, #0x18
     abc:      	mov	w8, #0x8                // =8
     ac0:      	mov	w9, #0x4                // =4
     ac4:      	add	x10, sp, #0x98
     ac8:      	add	x0, sp, #0x98
     acc:      	mov	w1, #0x8                // =8
     ad0:      	blr	x9
     ad4:      	ldr	x8, [sp, #0x98]
     ad8:      	cmp	x8, x21
     adc:      	b.eq	0xaac <generic_uprobe_process_event+0x7ec>
     ae0:      	mov	w8, #0x2964             // =10596
     ae4:      	add	x9, x24, #0xff6
     ae8:      	strh	w8, [x24, #0xffe]
     aec:      	adrp	x8, 0x0 <generic_uprobe_setup_event>
     af0:      	add	x8, x8, #0x0
     af4:      	ldr	x8, [x8]
     af8:      	str	x8, [x9]
     afc:      	mov	w8, #0xff6              // =4086
     b00:      	str	x9, [sp, #0x40]
     b04:      	str	x9, [sp, #0xc8]
     b08:      	ldr	x9, [sp, #0x10]
     b0c:      	mov	w21, #0x8               // =8
     b10:      	add	x0, sp, #0x98
     b14:      	mov	w1, #0x8                // =8
     b18:      	stp	xzr, xzr, [sp, #0x98]
     b1c:      	add	x23, x29, #0x8
     b20:      	add	x25, x29, #0x18
     b24:      	mov	w22, #0x4               // =4
     b28:      	add	x2, x9, #0x20
     b2c:      	stp	x24, xzr, [sp, #0xa8]
     b30:      	stp	xzr, xzr, [sp, #0xb8]
     b34:      	str	w8, [sp, #0xd0]
     b38:      	mov	w8, #0x4                // =4
     b3c:      	add	x24, x29, #0x20
     b40:      	strb	wzr, [sp, #0xd4]
     b44:      	blr	x8
     b48:      	ldr	x2, [sp, #0x50]
     b4c:      	mov	w8, #0x4                // =4
     b50:      	mov	x0, x23
     b54:      	mov	w1, #0x8                // =8
     b58:      	blr	x8
     b5c:      	ldr	x2, [sp, #0x38]
     b60:      	mov	w8, #0x4                // =4
     b64:      	mov	x0, x25
     b68:      	mov	w1, #0x8                // =8
     b6c:      	str	x25, [sp, #0x50]
     b70:      	blr	x8
     b74:      	ldr	x2, [sp, #0x18]
     b78:      	mov	x0, x24
     b7c:      	mov	w1, #0x8                // =8
     b80:      	blr	x22
     b84:      	ldr	x8, [sp, #0xb8]
     b88:      	sub	x8, x8, #0x20
     b8c:      	str	x8, [sp, #0xc0]
     b90:      	adrp	x8, 0x0 <generic_uprobe_setup_event>
     b94:      	ldr	x8, [x8]
     b98:      	ldrb	w8, [x8]
     b9c:      	cbz	w8, 0xd40 <generic_uprobe_process_event+0xa80>
     ba0:      	mov	w23, #0x800             // =2048
     ba4:      	mov	w24, #0x8               // =8
     ba8:      	add	x22, sp, #0xe0
     bac:      	ldp	x21, x2, [sp, #0xb0]
     bb0:      	ldp	x8, x9, [sp, #0x98]
     bb4:      	cmp	x21, x8
     bb8:      	ccmp	x2, x9, #0x0, eq
     bbc:      	b.eq	0xf70 <generic_uprobe_process_event+0xcb0>
     bc0:      	ldr	x25, [sp, #0xc0]
     bc4:      	mov	w8, #0x4                // =4
     bc8:      	add	x9, sp, #0xe0
     bcc:      	add	x0, sp, #0xe0
     bd0:      	mov	w1, #0x8                // =8
     bd4:      	blr	x8
     bd8:      	ldr	x8, [x22]
     bdc:      	add	x29, sp, #0xe0
     be0:      	cmp	x21, x8
     be4:      	b.eq	0xce0 <generic_uprobe_process_event+0xa20>
     be8:      	add	x22, x21, #0x18
     bec:      	mov	w8, #0x4                // =4
     bf0:      	add	x9, sp, #0x100
     bf4:      	add	x0, sp, #0x100
     bf8:      	mov	w1, #0x8                // =8
     bfc:      	mov	x2, x22
     c00:      	blr	x8
     c04:      	ldr	x8, [x29, #0x20]
     c08:      	cmp	x8, x21
     c0c:      	b.eq	0xce0 <generic_uprobe_process_event+0xa20>
     c10:      	mov	w8, #0x4                // =4
     c14:      	add	x9, sp, #0xe8
     c18:      	add	x0, sp, #0xe8
     c1c:      	mov	w1, #0x8                // =8
     c20:      	mov	x2, x22
     c24:      	blr	x8
     c28:      	add	x2, x21, #0x20
     c2c:      	mov	w8, #0x4                // =4
     c30:      	mov	w9, #0x10               // =16
     c34:      	add	x10, sp, #0xf0
     c38:      	add	x0, sp, #0xf0
     c3c:      	mov	w1, #0x10               // =16
     c40:      	blr	x8
     c44:      	ldr	w21, [sp, #0xf4]
     c48:      	ldr	x8, [sp, #0xa8]
     c4c:      	ldr	x10, [sp, #0xc8]
     c50:      	sub	x12, x10, x8
     c54:      	ldr	w22, [sp, #0xd0]
     c58:      	subs	w10, w21, w22
     c5c:      	ldr	x9, [x29, #0x18]
     c60:      	csel	w10, wzr, w10, lo
     c64:      	cmp	w22, w21
     c68:      	csel	w11, w22, w21, lo
     c6c:      	cinc	w13, w11, hi
     c70:      	sub	w14, w22, w13
     c74:      	subs	x12, x12, x13
     c78:      	str	w14, [sp, #0xd0]
     c7c:      	b.lo	0xf78 <generic_uprobe_process_event+0xcb8>
     c80:      	cmp	x12, #0xfff
     c84:      	b.hi	0xf78 <generic_uprobe_process_event+0xcb8>
     c88:      	cmp	w22, w21
     c8c:      	b.ls	0xc98 <generic_uprobe_process_event+0x9d8>
     c90:      	mov	w13, #0x2f              // =47
     c94:      	strb	w13, [x8, x12]
     c98:      	add	x25, x8, x12
     c9c:      	cmp	w22, w21
     ca0:      	add	x2, x9, x10
     ca4:      	and	w1, w11, #0xff
     ca8:      	mov	w8, #0x4                // =4
     cac:      	cinc	x0, x25, hi
     cb0:      	blr	x8
     cb4:      	cmp	w22, w21
     cb8:      	str	x25, [sp, #0xc8]
     cbc:      	b.ls	0xf78 <generic_uprobe_process_event+0xcb8>
     cc0:      	add	x22, sp, #0xe0
     cc4:      	ldr	x8, [x22, #0x8]
     cc8:      	str	x8, [sp, #0xb0]
     ccc:      	adrp	x25, 0x0 <generic_uprobe_setup_event>
     cd0:      	subs	w23, w23, #0x1
     cd4:      	ldr	x25, [x25]
     cd8:      	b.ne	0xbac <generic_uprobe_process_event+0x8ec>
     cdc:      	b	0xf90 <generic_uprobe_process_event+0xcd0>
     ce0:      	add	x2, x25, #0x10
     ce4:      	mov	w8, #0x4                // =4
     ce8:      	add	x9, sp, #0x100
     cec:      	add	x0, sp, #0x100
     cf0:      	mov	w1, #0x8                // =8
     cf4:      	blr	x8
     cf8:      	ldr	x8, [sp, #0xc0]
     cfc:      	ldr	x9, [x29, #0x20]
     d00:      	add	x22, sp, #0xe0
     d04:      	cmp	x8, x9
     d08:      	b.eq	0xf80 <generic_uprobe_process_event+0xcc0>
     d0c:      	ldr	x0, [sp, #0x50]
     d10:      	add	x2, x25, #0x18
     d14:      	mov	w8, #0x4                // =4
     d18:      	mov	w1, #0x8                // =8
     d1c:      	blr	x8
     d20:      	ldr	x8, [x22, #0x20]
     d24:      	add	x9, x8, #0x20
     d28:      	stp	x9, x8, [sp, #0xb8]
     d2c:      	adrp	x25, 0x0 <generic_uprobe_setup_event>
     d30:      	subs	w23, w23, #0x1
     d34:      	ldr	x25, [x25]
     d38:      	b.ne	0xbac <generic_uprobe_process_event+0x8ec>
     d3c:      	b	0xf90 <generic_uprobe_process_event+0xcd0>
     d40:      	mov	w23, #0x800             // =2048
     d44:      	mov	w24, #0x8               // =8
     d48:      	add	x22, sp, #0xe0
     d4c:      	b	0xd60 <generic_uprobe_process_event+0xaa0>
     d50:      	adrp	x25, 0x0 <generic_uprobe_setup_event>
     d54:      	subs	w23, w23, #0x1
     d58:      	ldr	x25, [x25]
     d5c:      	b.eq	0xf90 <generic_uprobe_process_event+0xcd0>
     d60:      	ldp	x21, x2, [sp, #0xb0]
     d64:      	ldp	x8, x9, [sp, #0x98]
     d68:      	cmp	x21, x8
     d6c:      	ccmp	x2, x9, #0x0, eq
     d70:      	b.eq	0xf70 <generic_uprobe_process_event+0xcb0>
     d74:      	ldr	x25, [sp, #0xc0]
     d78:      	mov	w8, #0x4                // =4
     d7c:      	add	x9, sp, #0xe0
     d80:      	add	x0, sp, #0xe0
     d84:      	mov	w1, #0x8                // =8
     d88:      	blr	x8
     d8c:      	ldr	x8, [x22]
     d90:      	add	x29, sp, #0xe0
     d94:      	cmp	x21, x8
     d98:      	b.eq	0xe84 <generic_uprobe_process_event+0xbc4>
     d9c:      	add	x22, x21, #0x18
     da0:      	mov	w8, #0x4                // =4
     da4:      	add	x9, sp, #0x100
     da8:      	add	x0, sp, #0x100
     dac:      	mov	w1, #0x8                // =8
     db0:      	mov	x2, x22
     db4:      	blr	x8
     db8:      	ldr	x8, [x29, #0x20]
     dbc:      	cmp	x8, x21
     dc0:      	b.eq	0xe84 <generic_uprobe_process_event+0xbc4>
     dc4:      	mov	w8, #0x4                // =4
     dc8:      	add	x9, sp, #0xe8
     dcc:      	add	x0, sp, #0xe8
     dd0:      	mov	w1, #0x8                // =8
     dd4:      	mov	x2, x22
     dd8:      	blr	x8
     ddc:      	add	x2, x21, #0x20
     de0:      	mov	w8, #0x4                // =4
     de4:      	mov	w9, #0x10               // =16
     de8:      	add	x10, sp, #0xf0
     dec:      	add	x0, sp, #0xf0
     df0:      	mov	w1, #0x10               // =16
     df4:      	blr	x8
     df8:      	ldr	w21, [sp, #0xf4]
     dfc:      	ldr	x8, [sp, #0xa8]
     e00:      	ldr	x10, [sp, #0xc8]
     e04:      	sub	x12, x10, x8
     e08:      	ldr	w22, [sp, #0xd0]
     e0c:      	subs	w10, w21, w22
     e10:      	ldr	x9, [x29, #0x18]
     e14:      	csel	w10, wzr, w10, lo
     e18:      	cmp	w22, w21
     e1c:      	csel	w11, w22, w21, lo
     e20:      	cinc	w13, w11, hi
     e24:      	sub	w14, w22, w13
     e28:      	subs	x12, x12, x13
     e2c:      	str	w14, [sp, #0xd0]
     e30:      	b.lo	0xf78 <generic_uprobe_process_event+0xcb8>
     e34:      	cmp	x12, #0xfff
     e38:      	b.hi	0xf78 <generic_uprobe_process_event+0xcb8>
     e3c:      	cmp	w22, w21
     e40:      	b.ls	0xe4c <generic_uprobe_process_event+0xb8c>
     e44:      	mov	w13, #0x2f              // =47
     e48:      	strb	w13, [x8, x12]
     e4c:      	add	x25, x8, x12
     e50:      	cmp	w22, w21
     e54:      	add	x2, x9, x10
     e58:      	and	w1, w11, #0xff
     e5c:      	mov	w8, #0x4                // =4
     e60:      	cinc	x0, x25, hi
     e64:      	blr	x8
     e68:      	cmp	w22, w21
     e6c:      	str	x25, [sp, #0xc8]
     e70:      	b.ls	0xf78 <generic_uprobe_process_event+0xcb8>
     e74:      	add	x22, sp, #0xe0
     e78:      	ldr	x8, [x22, #0x8]
     e7c:      	str	x8, [sp, #0xb0]
     e80:      	b	0xd50 <generic_uprobe_process_event+0xa90>
     e84:      	add	x2, x25, #0x10
     e88:      	mov	w8, #0x4                // =4
     e8c:      	add	x9, sp, #0x100
     e90:      	add	x0, sp, #0x100
     e94:      	mov	w1, #0x8                // =8
     e98:      	blr	x8
     e9c:      	ldr	x8, [sp, #0xc0]
     ea0:      	ldr	x9, [x29, #0x20]
     ea4:      	add	x22, sp, #0xe0
     ea8:      	cmp	x8, x9
     eac:      	b.eq	0xf80 <generic_uprobe_process_event+0xcc0>
     eb0:      	ldr	x0, [sp, #0x50]
     eb4:      	add	x2, x25, #0x18
     eb8:      	mov	w8, #0x4                // =4
     ebc:      	mov	w1, #0x8                // =8
     ec0:      	blr	x8
     ec4:      	ldr	x8, [x22, #0x20]
     ec8:      	add	x9, x8, #0x20
     ecc:      	stp	x9, x8, [sp, #0xb8]
     ed0:      	b	0xd50 <generic_uprobe_process_event+0xa90>
     ed4:      	cmp	w24, #0x2c
     ed8:      	b.hi	0x1098 <generic_uprobe_process_event+0xdd8>
     edc:      	mov	x9, #0x7cf2             // =31986
     ee0:      	mov	w8, #0x1                // =1
     ee4:      	movk	x9, #0xf202, lsl #16
     ee8:      	lsl	x8, x8, x24
     eec:      	movk	x9, #0x11c1, lsl #32
     ef0:      	tst	x8, x9
     ef4:      	b.eq	0x1098 <generic_uprobe_process_event+0xdd8>
     ef8:      	add	x8, sp, #0xe0
     efc:      	str	x22, [sp, #0x20]
     f00:      	str	wzr, [sp, #0xe0]
     f04:      	add	x9, sp, #0xe0
     f08:      	add	x1, sp, #0xe0
     f0c:      	mov	x0, x25
     f10:      	str	x10, [x8, #0x8]
     f14:      	mov	w8, #0x1                // =1
     f18:      	blr	x8
     f1c:      	mov	x22, xzr
     f20:      	cbz	x0, 0x22b8 <generic_uprobe_process_event+0x1ff8>
     f24:      	ldr	x11, [sp, #0x30]
     f28:      	cmp	w24, #0x10
     f2c:      	b.le	0x1110 <generic_uprobe_process_event+0xe50>
     f30:      	cmp	w24, #0x1e
     f34:      	mov	w21, #0x5efc            // =24316
     f38:      	b.le	0x122c <generic_uprobe_process_event+0xf6c>
     f3c:      	cmp	w24, #0x26
     f40:      	b.gt	0x1304 <generic_uprobe_process_event+0x1044>
     f44:      	sub	w8, w24, #0x1f
     f48:      	cmp	w8, #0x2
     f4c:      	b.hs	0x173c <generic_uprobe_process_event+0x147c>
     f50:      	mov	w8, #0x1                // =1
     f54:      	add	x9, sp, #0xe8
     f58:      	mov	w10, #0x4               // =4
     f5c:      	ldr	x0, [sp, #0x28]
     f60:      	mov	w22, #0x4               // =4
     f64:      	add	x2, sp, #0xe8
     f68:      	mov	w1, #0x1                // =1
     f6c:      	b	0x1448 <generic_uprobe_process_event+0x1188>
     f70:      	mov	w8, #0x1                // =1
     f74:      	strb	w8, [sp, #0xd4]
     f78:      	adrp	x25, 0x0 <generic_uprobe_setup_event>
     f7c:      	b	0xf8c <generic_uprobe_process_event+0xccc>
     f80:      	mov	w8, #0x1                // =1
     f84:      	adrp	x25, 0x0 <generic_uprobe_setup_event>
     f88:      	strb	w8, [sp, #0xd4]
     f8c:      	ldr	x25, [x25]
     f90:      	ldr	x8, [sp, #0xc8]
     f94:      	ldr	x2, [sp, #0x40]
     f98:      	cmp	x8, x2
     f9c:      	b.eq	0xfe4 <generic_uprobe_process_event+0xd24>
     fa0:      	ldrb	w9, [sp, #0xd4]
     fa4:      	mov	w11, #0x1000            // =4096
     fa8:      	cmp	w9, #0x0
     fac:      	ldr	w9, [sp, #0xd0]
     fb0:      	cset	w10, eq
     fb4:      	sub	w11, w11, w9
     fb8:      	cmp	w9, #0x0
     fbc:      	csel	w9, w11, w9, gt
     fc0:      	cbz	x8, 0xfd0 <generic_uprobe_process_event+0xd10>
     fc4:      	lsl	w21, w10, #1
     fc8:      	mov	x2, x8
     fcc:      	b	0xfec <generic_uprobe_process_event+0xd2c>
     fd0:      	ldr	x23, [sp, #0x48]
     fd4:      	ldr	x24, [sp, #0x118]
     fd8:      	mov	x22, xzr
     fdc:      	mov	w21, #0x5efc            // =24316
     fe0:      	b	0x22d0 <generic_uprobe_process_event+0x2010>
     fe4:      	mov	w21, wzr
     fe8:      	mov	w9, wzr
     fec:      	ldr	x29, [sp, #0x28]
     ff0:      	and	w22, w9, #0xfff
     ff4:      	mov	w8, #0x4                // =4
     ff8:      	mov	w23, #0x4               // =4
     ffc:      	mov	w1, w22
    1000:      	add	x0, x29, #0x4
    1004:      	blr	x8
    1008:      	str	w22, [x29]
    100c:      	ldr	x2, [sp, #0x38]
    1010:      	mov	w24, #0x8               // =8
    1014:      	add	x8, sp, #0x98
    1018:      	mov	w9, #0x4                // =4
    101c:      	add	x0, sp, #0x98
    1020:      	mov	w1, #0x8                // =8
    1024:      	blr	x9
    1028:      	ldr	x8, [sp, #0x98]
    102c:      	add	x9, sp, #0xf0
    1030:      	mov	w10, #0x4               // =4
    1034:      	add	x0, sp, #0xf0
    1038:      	mov	w1, #0x8                // =8
    103c:      	add	x8, x8, #0x30
    1040:      	ldr	x8, [sp, #0x98]
    1044:      	add	x2, x8, #0x30
    1048:      	blr	x10
    104c:      	add	x11, sp, #0xe0
    1050:      	mov	w9, #0x2                // =2
    1054:      	add	x10, sp, #0x100
    1058:      	ldr	x8, [x11, #0x10]
    105c:      	add	x0, sp, #0x100
    1060:      	mov	w1, #0x2                // =2
    1064:      	ldr	x2, [x11, #0x10]
    1068:      	blr	x23
    106c:      	add	x8, x29, x22
    1070:      	ldr	x23, [sp, #0x48]
    1074:      	ldr	x24, [sp, #0x118]
    1078:      	add	w22, w22, #0xa
    107c:      	mov	w10, #0x5ea0            // =24224
    1080:      	ldr	x11, [sp, #0x30]
    1084:      	str	w21, [x8, #0x4]
    1088:      	mov	w21, #0x5efc            // =24316
    108c:      	ldrh	w9, [sp, #0x100]
    1090:      	strh	w9, [x8, #0x8]
    1094:      	b	0x22cc <generic_uprobe_process_event+0x200c>
    1098:      	str	x22, [sp, #0x20]
    109c:      	str	wzr, [sp, #0x88]
    10a0:      	mov	w8, #0x1                // =1
    10a4:      	add	x9, sp, #0x88
    10a8:      	add	x1, sp, #0x88
    10ac:      	mov	x0, x25
    10b0:      	blr	x8
    10b4:      	mov	x22, xzr
    10b8:      	cbz	x0, 0x1e54 <generic_uprobe_process_event+0x1b94>
    10bc:      	cmp	w24, #0x19
    10c0:      	mov	w21, #0x5efc            // =24316
    10c4:      	b.gt	0x12d0 <generic_uprobe_process_event+0x1010>
    10c8:      	ldr	x25, [sp, #0x28]
    10cc:      	cmp	w24, #0x12
    10d0:      	b.le	0x13d0 <generic_uprobe_process_event+0x1110>
    10d4:      	cmp	w24, #0x14
    10d8:      	b.le	0x1688 <generic_uprobe_process_event+0x13c8>
    10dc:      	cmp	w24, #0x15
    10e0:      	b.eq	0x1d18 <generic_uprobe_process_event+0x1a58>
    10e4:      	cmp	w24, #0x16
    10e8:      	b.eq	0x1cbc <generic_uprobe_process_event+0x19fc>
    10ec:      	ldr	x11, [sp, #0x30]
    10f0:      	ldr	x8, [sp, #0x40]
    10f4:      	cmp	w24, #0x17
    10f8:      	mov	w21, #0x5efc            // =24316
    10fc:      	mov	w10, #0x5ea0            // =24224
    1100:      	b.ne	0x1e60 <generic_uprobe_process_event+0x1ba0>
    1104:      	stp	w8, wzr, [x25]
    1108:      	mov	w22, #0x8               // =8
    110c:      	b	0x1e60 <generic_uprobe_process_event+0x1ba0>
    1110:      	cmp	w24, #0x9
    1114:      	mov	w21, #0x5efc            // =24316
    1118:      	mov	w10, #0x5ea0            // =24224
    111c:      	b.gt	0x1254 <generic_uprobe_process_event+0xf94>
    1120:      	cmp	w24, #0x4
    1124:      	b.le	0x1450 <generic_uprobe_process_event+0x1190>
    1128:      	cmp	w24, #0x5
    112c:      	b.eq	0x18e8 <generic_uprobe_process_event+0x1628>
    1130:      	cmp	w24, #0x6
    1134:      	b.eq	0x12b0 <generic_uprobe_process_event+0xff0>
    1138:      	ldr	x11, [sp, #0x30]
    113c:      	cmp	w24, #0x7
    1140:      	mov	w10, #0x5ea0            // =24224
    1144:      	b.ne	0x22c4 <generic_uprobe_process_event+0x2004>
    1148:      	add	x8, sp, #0xe0
    114c:      	ldr	x25, [sp, #0x28]
    1150:      	mov	x29, x0
    1154:      	mov	w22, #0x2               // =2
    1158:      	ldr	x23, [x8, #0x8]
    115c:      	mov	w8, #0x4                // =4
    1160:      	mov	w1, #0x2                // =2
    1164:      	mov	w21, #0x4               // =4
    1168:      	str	x23, [x25, #0x28]
    116c:      	add	x0, x25, #0x26
    1170:      	add	x2, x23, #0x10
    1174:      	blr	x8
    1178:      	add	x0, x25, #0x3a
    117c:      	add	x2, x23, #0x12
    1180:      	mov	w8, #0x1                // =1
    1184:      	mov	w9, #0x4                // =4
    1188:      	mov	w1, #0x1                // =1
    118c:      	blr	x9
    1190:      	add	x0, x25, #0x38
    1194:      	add	x2, x23, #0x21e
    1198:      	mov	w8, #0x4                // =4
    119c:      	mov	w1, #0x2                // =2
    11a0:      	blr	x8
    11a4:      	add	x0, x25, #0x24
    11a8:      	add	x2, x23, #0x21c
    11ac:      	mov	w8, #0x4                // =4
    11b0:      	mov	w1, #0x2                // =2
    11b4:      	blr	x8
    11b8:      	add	x0, x25, #0x30
    11bc:      	add	x2, x23, #0x214
    11c0:      	mov	w8, #0x4                // =4
    11c4:      	mov	w1, #0x4                // =4
    11c8:      	blr	x8
    11cc:      	add	x0, x25, #0x34
    11d0:      	add	x2, x23, #0x210
    11d4:      	mov	w1, #0x4                // =4
    11d8:      	blr	x21
    11dc:      	ldrh	w8, [x25, #0x26]
    11e0:      	mov	x22, x25
    11e4:      	stp	xzr, xzr, [x25]
    11e8:      	cmp	w8, #0xa
    11ec:      	str	xzr, [x25, #0x18]
    11f0:      	str	xzr, [x22, #0x10]!
    11f4:      	b.eq	0x2048 <generic_uprobe_process_event+0x1d88>
    11f8:      	cmp	w8, #0x2
    11fc:      	b.ne	0x2074 <generic_uprobe_process_event+0x1db4>
    1200:      	add	x2, x23, #0x4
    1204:      	mov	w8, #0x4                // =4
    1208:      	mov	x0, x25
    120c:      	mov	w1, #0x4                // =4
    1210:      	mov	w21, #0x4               // =4
    1214:      	blr	x8
    1218:      	mov	x0, x22
    121c:      	mov	w1, #0x4                // =4
    1220:      	mov	x2, x23
    1224:      	blr	x21
    1228:      	b	0x2074 <generic_uprobe_process_event+0x1db4>
    122c:      	cmp	w24, #0x1c
    1230:      	b.gt	0x142c <generic_uprobe_process_event+0x116c>
    1234:      	cmp	w24, #0x11
    1238:      	b.eq	0x1770 <generic_uprobe_process_event+0x14b0>
    123c:      	cmp	w24, #0x19
    1240:      	b.eq	0x1824 <generic_uprobe_process_event+0x1564>
    1244:      	cmp	w24, #0x1c
    1248:      	mov	w10, #0x5ea0            // =24224
    124c:      	b.eq	0x1460 <generic_uprobe_process_event+0x11a0>
    1250:      	b	0x22c4 <generic_uprobe_process_event+0x2004>
    1254:      	sub	w8, w24, #0xa
    1258:      	cmp	w8, #0x2
    125c:      	b.lo	0x1460 <generic_uprobe_process_event+0x11a0>
    1260:      	sub	w8, w24, #0xc
    1264:      	cmp	w8, #0x2
    1268:      	b.lo	0x1480 <generic_uprobe_process_event+0x11c0>
    126c:      	cmp	w24, #0xe
    1270:      	b.ne	0x22c4 <generic_uprobe_process_event+0x2004>
    1274:      	mov	w21, #0x8               // =8
    1278:      	add	x8, sp, #0x98
    127c:      	add	x23, sp, #0xe8
    1280:      	mov	w9, #0x4                // =4
    1284:      	add	x0, sp, #0x98
    1288:      	add	x2, sp, #0xe8
    128c:      	mov	w1, #0x8                // =8
    1290:      	mov	w22, #0x4               // =4
    1294:      	blr	x9
    1298:      	ldr	x8, [sp, #0x98]
    129c:      	add	x0, sp, #0xe8
    12a0:      	mov	w1, #0x8                // =8
    12a4:      	mov	w21, #0x5efc            // =24316
    12a8:      	ldr	x2, [sp, #0x98]
    12ac:      	blr	x22
    12b0:      	ldr	x23, [sp, #0x28]
    12b4:      	add	x8, sp, #0xe0
    12b8:      	mov	w9, #0x2d               // =45
    12bc:      	mov	w1, #0x1001             // =4097
    12c0:      	ldr	x2, [x8, #0x8]
    12c4:      	mov	w8, #0x1001             // =4097
    12c8:      	add	x0, x23, #0x4
    12cc:      	b	0x1a64 <generic_uprobe_process_event+0x17a4>
    12d0:      	ldr	x25, [sp, #0x28]
    12d4:      	ldr	x2, [sp, #0x40]
    12d8:      	cmp	w24, #0x20
    12dc:      	b.le	0x15cc <generic_uprobe_process_event+0x130c>
    12e0:      	sub	w8, w24, #0x21
    12e4:      	cmp	w8, #0x4
    12e8:      	b.hs	0x14ac <generic_uprobe_process_event+0x11ec>
    12ec:      	mov	w22, #0x8               // =8
    12f0:      	mov	w8, #0x4                // =4
    12f4:      	mov	x0, x25
    12f8:      	mov	w1, #0x8                // =8
    12fc:      	blr	x8
    1300:      	b	0x1e58 <generic_uprobe_process_event+0x1b98>
    1304:      	cmp	w24, #0x27
    1308:      	b.eq	0x1a44 <generic_uprobe_process_event+0x1784>
    130c:      	cmp	w24, #0x28
    1310:      	b.eq	0x1a80 <generic_uprobe_process_event+0x17c0>
    1314:      	cmp	w24, #0x2c
    1318:      	mov	w10, #0x5ea0            // =24224
    131c:      	b.ne	0x22c4 <generic_uprobe_process_event+0x2004>
    1320:      	ldr	x0, [sp, #0x28]
    1324:      	add	x8, sp, #0xe0
    1328:      	strb	wzr, [sp, #0x98]
    132c:      	mov	w9, #0x4                // =4
    1330:      	mov	w1, #0x2                // =2
    1334:      	ldr	x22, [x8, #0x8]
    1338:      	mov	w8, #0x2                // =2
    133c:      	stp	xzr, xzr, [x0]
    1340:      	stp	xzr, xzr, [x0, #0x10]
    1344:      	mov	x2, x22
    1348:      	stp	xzr, xzr, [x0, #0x20]
    134c:      	stp	xzr, xzr, [x0, #0x30]
    1350:      	stp	xzr, xzr, [x0, #0x40]
    1354:      	stp	xzr, xzr, [x0, #0x50]
    1358:      	stp	xzr, xzr, [x0, #0x60]
    135c:      	blr	x9
    1360:      	tbnz	x0, #0x3f, 0x22b4 <generic_uprobe_process_event+0x1ff4>
    1364:      	add	x23, x22, #0x2
    1368:      	mov	w8, #0x1                // =1
    136c:      	mov	w9, #0x4                // =4
    1370:      	add	x10, sp, #0x98
    1374:      	add	x0, sp, #0x98
    1378:      	mov	w1, #0x1                // =1
    137c:      	mov	x2, x23
    1380:      	blr	x9
    1384:      	tbnz	x0, #0x3f, 0x22b4 <generic_uprobe_process_event+0x1ff4>
    1388:      	ldrb	w8, [sp, #0x98]
    138c:      	ldr	x10, [sp, #0x28]
    1390:      	cmp	w8, #0x0
    1394:      	add	x0, x10, #0x4
    1398:      	cset	w9, eq
    139c:      	strb	w9, [x10, #0x2]
    13a0:      	cbz	w8, 0x2288 <generic_uprobe_process_event+0x1fc8>
    13a4:      	mov	w8, #0x6c               // =108
    13a8:      	mov	w9, #0x2d               // =45
    13ac:      	mov	w1, #0x6c               // =108
    13b0:      	mov	x2, x23
    13b4:      	blr	x9
    13b8:      	adrp	x25, 0x1000 <generic_uprobe_process_event+0xd40>
    13bc:      	ldr	x25, [x25]
    13c0:      	ldr	x19, [sp, #0x50]
    13c4:      	tbnz	w0, #0x1f, 0x22b4 <generic_uprobe_process_event+0x1ff4>
    13c8:      	sub	w21, w0, #0x1
    13cc:      	b	0x22ac <generic_uprobe_process_event+0x1fec>
    13d0:      	cmp	w24, #0x7
    13d4:      	b.gt	0x1644 <generic_uprobe_process_event+0x1384>
    13d8:      	cmp	w24, #0x2
    13dc:      	b.eq	0x1afc <generic_uprobe_process_event+0x183c>
    13e0:      	ldr	x11, [sp, #0x30]
    13e4:      	cmp	w24, #0x3
    13e8:      	mov	w10, #0x5ea0            // =24224
    13ec:      	b.ne	0x1e60 <generic_uprobe_process_event+0x1ba0>
    13f0:      	ldr	x8, [sp, #0x38]
    13f4:      	add	x23, x0, #0x90
    13f8:      	mov	x25, x0
    13fc:      	add	x29, x23, x29
    1400:      	and	w8, w8, #0xf
    1404:      	cmp	w8, #0x2
    1408:      	b.le	0x21d8 <generic_uprobe_process_event+0x1f18>
    140c:      	cmp	w8, #0x3
    1410:      	b.eq	0x23e8 <generic_uprobe_process_event+0x2128>
    1414:      	cmp	w8, #0x4
    1418:      	b.eq	0x23f0 <generic_uprobe_process_event+0x2130>
    141c:      	cmp	w8, #0x5
    1420:      	b.ne	0x2444 <generic_uprobe_process_event+0x2184>
    1424:      	mov	w8, #0x5e70             // =24176
    1428:      	b	0x23fc <generic_uprobe_process_event+0x213c>
    142c:      	ldr	x0, [sp, #0x28]
    1430:      	mov	w8, #0x2                // =2
    1434:      	add	x9, sp, #0xe8
    1438:      	mov	w10, #0x4               // =4
    143c:      	mov	w22, #0x4               // =4
    1440:      	add	x2, sp, #0xe8
    1444:      	mov	w1, #0x2                // =2
    1448:      	blr	x10
    144c:      	b	0x149c <generic_uprobe_process_event+0x11dc>
    1450:      	cmp	w24, #0x1
    1454:      	b.eq	0x1480 <generic_uprobe_process_event+0x11c0>
    1458:      	cmp	w24, #0x4
    145c:      	b.ne	0x22c4 <generic_uprobe_process_event+0x2004>
    1460:      	ldr	x0, [sp, #0x28]
    1464:      	mov	w22, #0x8               // =8
    1468:      	mov	w8, #0x4                // =4
    146c:      	add	x9, sp, #0xe8
    1470:      	add	x2, sp, #0xe8
    1474:      	mov	w1, #0x8                // =8
    1478:      	blr	x8
    147c:      	b	0x149c <generic_uprobe_process_event+0x11dc>
    1480:      	ldr	x0, [sp, #0x28]
    1484:      	add	x8, sp, #0xe8
    1488:      	mov	w9, #0x4                // =4
    148c:      	add	x2, sp, #0xe8
    1490:      	mov	w1, #0x4                // =4
    1494:      	mov	w22, #0x4               // =4
    1498:      	blr	x9
    149c:      	ldr	x11, [sp, #0x30]
    14a0:      	ldr	x23, [sp, #0x48]
    14a4:      	mov	w10, #0x5ea0            // =24224
    14a8:      	b	0x22c8 <generic_uprobe_process_event+0x2008>
    14ac:      	cmp	w24, #0x2b
    14b0:      	b.eq	0x1dcc <generic_uprobe_process_event+0x1b0c>
    14b4:      	ldr	x11, [sp, #0x30]
    14b8:      	cmp	w24, #0x29
    14bc:      	mov	w21, #0x5efc            // =24316
    14c0:      	mov	w10, #0x5ea0            // =24224
    14c4:      	b.ne	0x1e60 <generic_uprobe_process_event+0x1ba0>
    14c8:      	add	x2, x2, #0x18
    14cc:      	mov	w8, #0x8                // =8
    14d0:      	mov	w9, #0x4                // =4
    14d4:      	add	x10, sp, #0x98
    14d8:      	mov	x29, x0
    14dc:      	add	x0, sp, #0x98
    14e0:      	mov	w1, #0x8                // =8
    14e4:      	mov	x25, x11
    14e8:      	blr	x9
    14ec:      	ldr	x23, [sp, #0x98]
    14f0:      	cbz	x23, 0x2390 <generic_uprobe_process_event+0x20d0>
    14f4:      	ldr	x24, [sp, #0x28]
    14f8:      	add	x2, x23, #0x10
    14fc:      	mov	w22, #0x2               // =2
    1500:      	mov	w8, #0x4                // =4
    1504:      	str	x23, [x24, #0x28]
    1508:      	add	x0, x24, #0x26
    150c:      	mov	w1, #0x2                // =2
    1510:      	mov	w21, #0x4               // =4
    1514:      	blr	x8
    1518:      	add	x0, x24, #0x3a
    151c:      	add	x2, x23, #0x12
    1520:      	mov	w8, #0x1                // =1
    1524:      	mov	w9, #0x4                // =4
    1528:      	mov	w1, #0x1                // =1
    152c:      	blr	x9
    1530:      	add	x0, x24, #0x38
    1534:      	add	x2, x23, #0x21e
    1538:      	mov	w8, #0x4                // =4
    153c:      	mov	w1, #0x2                // =2
    1540:      	blr	x8
    1544:      	add	x0, x24, #0x24
    1548:      	add	x2, x23, #0x21c
    154c:      	mov	w8, #0x4                // =4
    1550:      	mov	w1, #0x2                // =2
    1554:      	blr	x8
    1558:      	add	x0, x24, #0x30
    155c:      	add	x2, x23, #0x214
    1560:      	mov	w8, #0x4                // =4
    1564:      	mov	w1, #0x4                // =4
    1568:      	blr	x8
    156c:      	add	x0, x24, #0x34
    1570:      	add	x2, x23, #0x210
    1574:      	mov	w1, #0x4                // =4
    1578:      	blr	x21
    157c:      	ldrh	w8, [x24, #0x26]
    1580:      	mov	x22, x24
    1584:      	stp	xzr, xzr, [x24]
    1588:      	cmp	w8, #0xa
    158c:      	str	xzr, [x24, #0x18]
    1590:      	str	xzr, [x22, #0x10]!
    1594:      	b.eq	0x2320 <generic_uprobe_process_event+0x2060>
    1598:      	cmp	w8, #0x2
    159c:      	b.ne	0x234c <generic_uprobe_process_event+0x208c>
    15a0:      	ldr	x0, [sp, #0x28]
    15a4:      	add	x2, x23, #0x4
    15a8:      	mov	w8, #0x4                // =4
    15ac:      	mov	w1, #0x4                // =4
    15b0:      	mov	w21, #0x4               // =4
    15b4:      	blr	x8
    15b8:      	mov	x0, x22
    15bc:      	mov	w1, #0x4                // =4
    15c0:      	mov	x2, x23
    15c4:      	blr	x21
    15c8:      	b	0x234c <generic_uprobe_process_event+0x208c>
    15cc:      	cmp	w24, #0x1a
    15d0:      	b.eq	0x1e70 <generic_uprobe_process_event+0x1bb0>
    15d4:      	ldr	x11, [sp, #0x30]
    15d8:      	cmp	w24, #0x1b
    15dc:      	mov	w10, #0x5ea0            // =24224
    15e0:      	b.ne	0x1e60 <generic_uprobe_process_event+0x1ba0>
    15e4:      	mov	x0, x25
    15e8:      	stp	xzr, xzr, [x25, #0x40]
    15ec:      	add	x2, x2, #0x18
    15f0:      	mov	w8, #0x3f               // =63
    15f4:      	mov	w9, #0x2d               // =45
    15f8:      	mov	w1, #0x3f               // =63
    15fc:      	stp	xzr, xzr, [x25, #0x30]
    1600:      	mov	x23, x11
    1604:      	str	xzr, [x25, #0x18]
    1608:      	stp	xzr, xzr, [x25, #0x20]
    160c:      	str	xzr, [x0, #0x10]!
    1610:      	stp	xzr, xzr, [x25]
    1614:      	blr	x9
    1618:      	tbnz	x0, #0x3f, 0x2250 <generic_uprobe_process_event+0x1f90>
    161c:      	ldr	x8, [sp, #0x28]
    1620:      	mov	w9, #0x4                // =4
    1624:      	mov	w1, #0x8                // =8
    1628:      	add	x0, x8, #0x8
    162c:      	ldr	x8, [sp, #0x40]
    1630:      	add	x2, x8, #0x360
    1634:      	mov	w8, #0x8                // =8
    1638:      	blr	x9
    163c:      	mov	w22, #0x50              // =80
    1640:      	b	0x2254 <generic_uprobe_process_event+0x1f94>
    1644:      	cmp	w24, #0x8
    1648:      	b.eq	0x1b44 <generic_uprobe_process_event+0x1884>
    164c:      	ldr	x11, [sp, #0x30]
    1650:      	ldr	x2, [sp, #0x40]
    1654:      	cmp	w24, #0x12
    1658:      	mov	w21, #0x5efc            // =24316
    165c:      	mov	w10, #0x5ea0            // =24224
    1660:      	b.ne	0x1e60 <generic_uprobe_process_event+0x1ba0>
    1664:      	ldr	x8, [sp, #0x38]
    1668:      	mov	x0, x25
    166c:      	mov	x23, x11
    1670:      	and	x22, x8, #0x3ff
    1674:      	mov	w8, #0x4                // =4
    1678:      	mov	w1, w22
    167c:      	blr	x8
    1680:      	mov	x11, x23
    1684:      	b	0x1e5c <generic_uprobe_process_event+0x1b9c>
    1688:      	cmp	w24, #0x13
    168c:      	b.eq	0x1d8c <generic_uprobe_process_event+0x1acc>
    1690:      	ldr	x11, [sp, #0x30]
    1694:      	ldr	x29, [sp, #0x40]
    1698:      	cmp	w24, #0x14
    169c:      	mov	w21, #0x5efc            // =24316
    16a0:      	mov	w10, #0x5ea0            // =24224
    16a4:      	b.ne	0x1e60 <generic_uprobe_process_event+0x1ba0>
    16a8:      	str	xzr, [sp, #0x98]
    16ac:      	add	x2, x29, #0x110
    16b0:      	mov	w23, #0x8               // =8
    16b4:      	add	x8, sp, #0x98
    16b8:      	mov	w9, #0x4                // =4
    16bc:      	add	x0, sp, #0x98
    16c0:      	mov	w1, #0x8                // =8
    16c4:      	add	x22, x29, #0xd8
    16c8:      	mov	w21, #0x4               // =4
    16cc:      	mov	x24, x11
    16d0:      	blr	x9
    16d4:      	ldr	x8, [sp, #0x98]
    16d8:      	mov	w9, #0x80               // =128
    16dc:      	mov	w10, #0x2d              // =45
    16e0:      	mov	x0, x25
    16e4:      	ldr	x2, [sp, #0x98]
    16e8:      	mov	w1, #0x80               // =128
    16ec:      	blr	x10
    16f0:      	add	x0, x25, #0x90
    16f4:      	mov	w8, #0x4                // =4
    16f8:      	mov	w1, #0x4                // =4
    16fc:      	mov	x2, x22
    1700:      	blr	x8
    1704:      	add	x0, x25, #0x80
    1708:      	add	x2, x29, #0xe0
    170c:      	mov	w8, #0x4                // =4
    1710:      	mov	w1, #0x8                // =8
    1714:      	blr	x8
    1718:      	add	x0, x25, #0x88
    171c:      	add	x2, x29, #0x118
    1720:      	mov	w1, #0x8                // =8
    1724:      	blr	x21
    1728:      	mov	x11, x24
    172c:      	mov	w10, #0x5ea0            // =24224
    1730:      	mov	w21, #0x5efc            // =24316
    1734:      	mov	w22, #0x98              // =152
    1738:      	b	0x1e60 <generic_uprobe_process_event+0x1ba0>
    173c:      	cmp	w24, #0x26
    1740:      	mov	w10, #0x5ea0            // =24224
    1744:      	b.ne	0x22c4 <generic_uprobe_process_event+0x2004>
    1748:      	add	x8, sp, #0xe0
    174c:      	ldr	x23, [sp, #0x28]
    1750:      	ldr	x8, [x8, #0x8]
    1754:      	add	x0, x23, #0x4
    1758:      	add	x2, x19, w8, uxth
    175c:      	ubfx	w8, w8, #16, #12
    1760:      	add	w1, w8, #0x1
    1764:      	mov	w8, #0x2d               // =45
    1768:      	blr	x8
    176c:      	b	0x1a68 <generic_uprobe_process_event+0x17a8>
    1770:      	str	xzr, [sp, #0xa0]
    1774:      	mov	w8, #0xe                // =14
    1778:      	blr	x8
    177c:      	lsr	x8, x0, #32
    1780:      	add	x9, sp, #0xf0
    1784:      	add	x10, sp, #0xe8
    1788:      	str	x8, [sp, #0x98]
    178c:      	mov	w8, #0x4                // =4
    1790:      	add	x0, sp, #0xf0
    1794:      	add	x2, sp, #0xe8
    1798:      	mov	w1, #0x4                // =4
    179c:      	blr	x8
    17a0:      	ldr	w8, [sp, #0xf0]
    17a4:      	adrp	x0, 0x1000 <generic_uprobe_process_event+0xd40>
    17a8:      	add	x9, sp, #0x98
    17ac:      	add	x1, sp, #0x98
    17b0:      	str	w8, [sp, #0xa0]
    17b4:      	mov	w8, #0x1                // =1
    17b8:      	ldr	x0, [x0]
    17bc:      	blr	x8
    17c0:      	cbz	x0, 0x1f48 <generic_uprobe_process_event+0x1c88>
    17c4:      	ldr	x24, [sp, #0x28]
    17c8:      	ldr	w21, [x0]
    17cc:      	add	x8, sp, #0xf0
    17d0:      	mov	w9, #0x4                // =4
    17d4:      	add	x2, sp, #0xf0
    17d8:      	mov	x22, x0
    17dc:      	mov	w1, #0x4                // =4
    17e0:      	mov	w23, #0x4               // =4
    17e4:      	mov	x0, x24
    17e8:      	blr	x9
    17ec:      	and	x21, x21, #0xfff
    17f0:      	add	x0, x24, #0x4
    17f4:      	mov	w8, #0x4                // =4
    17f8:      	mov	x2, x22
    17fc:      	add	x1, x21, #0x4
    1800:      	blr	x8
    1804:      	add	w21, w21, #0x8
    1808:      	mov	w1, #0x4                // =4
    180c:      	add	x8, x21, x22
    1810:      	add	x0, x24, x21
    1814:      	sub	x2, x8, #0x4
    1818:      	blr	x23
    181c:      	add	x22, x21, #0x4
    1820:      	b	0x2fb4 <generic_uprobe_process_event+0x2cf4>
    1824:      	add	x8, sp, #0xe0
    1828:      	mov	w9, #0x4                // =4
    182c:      	add	x10, sp, #0x90
    1830:      	ldr	x22, [x8, #0x8]
    1834:      	mov	w8, #0x1                // =1
    1838:      	mov	x23, x0
    183c:      	add	x0, sp, #0x90
    1840:      	mov	w1, #0x1                // =1
    1844:      	mov	x2, x22
    1848:      	blr	x9
    184c:      	ldrb	w8, [sp, #0x90]
    1850:      	cbz	w8, 0x1f50 <generic_uprobe_process_event+0x1c90>
    1854:      	cmp	w8, #0x1
    1858:      	b.ne	0x20fc <generic_uprobe_process_event+0x1e3c>
    185c:      	add	x2, x22, #0x10
    1860:      	mov	w22, #0x8               // =8
    1864:      	add	x8, sp, #0x98
    1868:      	mov	w9, #0x4                // =4
    186c:      	add	x0, sp, #0x98
    1870:      	mov	w1, #0x8                // =8
    1874:      	mov	w21, #0x4               // =4
    1878:      	blr	x9
    187c:      	ldr	x2, [sp, #0x98]
    1880:      	add	x8, sp, #0xf0
    1884:      	mov	w9, #0x4                // =4
    1888:      	add	x0, sp, #0xf0
    188c:      	mov	w1, #0x8                // =8
    1890:      	blr	x9
    1894:      	ldr	x8, [sp, #0x98]
    1898:      	mov	w9, #0x4                // =4
    189c:      	add	x0, sp, #0x100
    18a0:      	mov	w1, #0x8                // =8
    18a4:      	add	x2, x8, #0x8
    18a8:      	add	x8, sp, #0x100
    18ac:      	blr	x9
    18b0:      	add	x8, sp, #0xe0
    18b4:      	add	x23, x23, x29
    18b8:      	ldr	x24, [x8, #0x20]
    18bc:      	ldr	x2, [x8, #0x10]
    18c0:      	mov	w8, #0xfff              // =4095
    18c4:      	add	x0, x23, #0x98
    18c8:      	cmp	x24, #0xfff
    18cc:      	csel	x22, x24, x8, lo
    18d0:      	mov	w1, w22
    18d4:      	blr	x21
    18d8:      	tbnz	w0, #0x1f, 0x2268 <generic_uprobe_process_event+0x1fa8>
    18dc:      	stp	w24, w22, [x23, #0x90]
    18e0:      	add	x22, x22, #0x8
    18e4:      	b	0x2fb4 <generic_uprobe_process_event+0x2cf4>
    18e8:      	add	x8, sp, #0xe0
    18ec:      	ldr	x21, [sp, #0x28]
    18f0:      	mov	w1, #0x4                // =4
    18f4:      	mov	w23, #0x4               // =4
    18f8:      	ldr	x24, [x8, #0x8]
    18fc:      	mov	w8, #0x4                // =4
    1900:      	add	x0, x21, #0x28
    1904:      	add	x2, x24, #0x98
    1908:      	blr	x8
    190c:      	add	x0, x21, #0x2c
    1910:      	add	x2, x24, #0x70
    1914:      	mov	w8, #0x4                // =4
    1918:      	mov	w1, #0x4                // =4
    191c:      	blr	x8
    1920:      	add	x0, x21, #0x30
    1924:      	add	x2, x24, #0x90
    1928:      	mov	w8, #0x4                // =4
    192c:      	mov	w1, #0x4                // =4
    1930:      	blr	x8
    1934:      	add	x0, x21, #0x34
    1938:      	add	x2, x24, #0xa8
    193c:      	mov	w8, #0x4                // =4
    1940:      	mov	w1, #0x4                // =4
    1944:      	blr	x8
    1948:      	str	xzr, [sp, #0x98]
    194c:      	add	x2, x24, #0xc8
    1950:      	mov	w8, #0x8                // =8
    1954:      	add	x9, sp, #0x98
    1958:      	mov	w10, #0x4               // =4
    195c:      	add	x0, sp, #0x98
    1960:      	mov	w1, #0x8                // =8
    1964:      	blr	x10
    1968:      	add	x2, x24, #0xb8
    196c:      	mov	w8, #0x2                // =2
    1970:      	add	x9, sp, #0x90
    1974:      	mov	w10, #0x4               // =4
    1978:      	add	x0, sp, #0x90
    197c:      	mov	w1, #0x2                // =2
    1980:      	blr	x10
    1984:      	ldr	x8, [sp, #0x98]
    1988:      	ldrh	w9, [sp, #0x90]
    198c:      	add	x0, sp, #0xdc
    1990:      	mov	w1, #0x1                // =1
    1994:      	add	x22, x8, x9
    1998:      	mov	w8, #0x1                // =1
    199c:      	add	x9, sp, #0xdc
    19a0:      	mov	x2, x22
    19a4:      	blr	x23
    19a8:      	ldrb	w8, [sp, #0xdc]
    19ac:      	lsr	w8, w8, #4
    19b0:      	cmp	w8, #0x6
    19b4:      	b.eq	0x1fc0 <generic_uprobe_process_event+0x1d00>
    19b8:      	cmp	w8, #0x4
    19bc:      	b.ne	0x2fb0 <generic_uprobe_process_event+0x2cf0>
    19c0:      	add	x2, x22, #0x9
    19c4:      	mov	w8, #0x1                // =1
    19c8:      	add	x9, sp, #0x84
    19cc:      	mov	w10, #0x4               // =4
    19d0:      	add	x0, sp, #0x84
    19d4:      	mov	w1, #0x1                // =1
    19d8:      	mov	w21, #0x4               // =4
    19dc:      	blr	x10
    19e0:      	ldr	x0, [sp, #0x28]
    19e4:      	ldrb	w8, [sp, #0x84]
    19e8:      	mov	w25, #0x2               // =2
    19ec:      	add	x2, x22, #0xc
    19f0:      	mov	w1, #0x4                // =4
    19f4:      	mov	x23, x0
    19f8:      	strh	w8, [x0, #0x24]
    19fc:      	strh	w25, [x0, #0x26]
    1a00:      	stp	xzr, xzr, [x0]
    1a04:      	str	xzr, [x0, #0x18]
    1a08:      	mov	w8, #0x4                // =4
    1a0c:      	str	xzr, [x23, #0x10]!
    1a10:      	blr	x8
    1a14:      	add	x2, x22, #0x10
    1a18:      	mov	w8, #0x4                // =4
    1a1c:      	mov	x0, x23
    1a20:      	mov	w1, #0x4                // =4
    1a24:      	blr	x8
    1a28:      	add	x2, x24, #0xb6
    1a2c:      	add	x8, sp, #0x88
    1a30:      	add	x0, sp, #0x88
    1a34:      	mov	w1, #0x2                // =2
    1a38:      	blr	x21
    1a3c:      	ldrb	w25, [sp, #0x84]
    1a40:      	b	0x2e74 <generic_uprobe_process_event+0x2bb4>
    1a44:      	add	x8, sp, #0xe0
    1a48:      	ldr	x23, [sp, #0x28]
    1a4c:      	mov	w9, #0x2d               // =45
    1a50:      	mov	w1, #0x11               // =17
    1a54:      	ldr	x8, [x8, #0x8]
    1a58:      	add	x0, x23, #0x4
    1a5c:      	add	x2, x8, #0x118
    1a60:      	mov	w8, #0x11               // =17
    1a64:      	blr	x9
    1a68:      	mov	x22, x0
    1a6c:      	tbnz	x0, #0x3f, 0x22bc <generic_uprobe_process_event+0x1ffc>
    1a70:      	sub	w8, w22, #0x1
    1a74:      	add	x22, x22, #0x3
    1a78:      	str	w8, [x23]
    1a7c:      	b	0x22bc <generic_uprobe_process_event+0x1ffc>
    1a80:      	ldr	x23, [sp, #0x28]
    1a84:      	add	x8, sp, #0xe0
    1a88:      	mov	w9, #0x4                // =4
    1a8c:      	mov	w1, #0x2                // =2
    1a90:      	ldr	x22, [x8, #0x8]
    1a94:      	mov	w8, #0x2                // =2
    1a98:      	str	xzr, [x23]
    1a9c:      	stp	xzr, xzr, [x23, #0x8]
    1aa0:      	mov	x0, x23
    1aa4:      	mov	x2, x22
    1aa8:      	blr	x9
    1aac:      	tbnz	x0, #0x3f, 0x2248 <generic_uprobe_process_event+0x1f88>
    1ab0:      	ldrh	w8, [x23]
    1ab4:      	cmp	w8, #0xa
    1ab8:      	b.eq	0x21f0 <generic_uprobe_process_event+0x1f30>
    1abc:      	cmp	w8, #0x2
    1ac0:      	b.ne	0x2224 <generic_uprobe_process_event+0x1f64>
    1ac4:      	add	x2, x22, #0x4
    1ac8:      	add	x8, sp, #0x98
    1acc:      	mov	w9, #0x4                // =4
    1ad0:      	add	x0, sp, #0x98
    1ad4:      	mov	w1, #0x4                // =4
    1ad8:      	mov	w21, #0x4               // =4
    1adc:      	blr	x9
    1ae0:      	ldr	w8, [sp, #0x98]
    1ae4:      	ldr	x9, [sp, #0x28]
    1ae8:      	add	x2, x22, #0x2
    1aec:      	add	x0, x9, #0x2
    1af0:      	str	x8, [x9, #0x8]
    1af4:      	mov	w8, #0x2                // =2
    1af8:      	b	0x221c <generic_uprobe_process_event+0x1f5c>
    1afc:      	add	x8, x0, x29
    1b00:      	mov	x22, x0
    1b04:      	add	x24, x8, #0x90
    1b08:      	add	x8, sp, #0xe0
    1b0c:      	str	xzr, [x8]
    1b10:      	tbnz	w23, #0x4, 0x210c <generic_uprobe_process_event+0x1e4c>
    1b14:      	and	w9, w23, #0xf
    1b18:      	mov	x8, xzr
    1b1c:      	cmp	w9, #0x2
    1b20:      	b.le	0x2308 <generic_uprobe_process_event+0x2048>
    1b24:      	cmp	w9, #0x3
    1b28:      	b.eq	0x25c0 <generic_uprobe_process_event+0x2300>
    1b2c:      	cmp	w9, #0x4
    1b30:      	b.eq	0x25c8 <generic_uprobe_process_event+0x2308>
    1b34:      	cmp	w9, #0x5
    1b38:      	b.ne	0x25dc <generic_uprobe_process_event+0x231c>
    1b3c:      	mov	w8, #0x5e70             // =24176
    1b40:      	b	0x25d4 <generic_uprobe_process_event+0x2314>
    1b44:      	ldr	x29, [sp, #0x40]
    1b48:      	mov	w8, #0x4                // =4
    1b4c:      	mov	x0, x25
    1b50:      	mov	w1, #0x4                // =4
    1b54:      	add	x22, x25, #0x28
    1b58:      	add	x24, x25, #0x40
    1b5c:      	mov	w23, #0x4               // =4
    1b60:      	add	x2, x29, #0x8
    1b64:      	blr	x8
    1b68:      	add	x0, x25, #0x4
    1b6c:      	add	x2, x29, #0xc
    1b70:      	mov	w8, #0x4                // =4
    1b74:      	mov	w1, #0x4                // =4
    1b78:      	blr	x8
    1b7c:      	add	x0, x25, #0x10
    1b80:      	add	x2, x29, #0x18
    1b84:      	mov	w8, #0x4                // =4
    1b88:      	mov	w1, #0x4                // =4
    1b8c:      	blr	x8
    1b90:      	add	x0, x25, #0x14
    1b94:      	add	x2, x29, #0x1c
    1b98:      	mov	w8, #0x4                // =4
    1b9c:      	mov	w1, #0x4                // =4
    1ba0:      	blr	x8
    1ba4:      	add	x0, x25, #0x8
    1ba8:      	add	x2, x29, #0x10
    1bac:      	mov	w8, #0x4                // =4
    1bb0:      	mov	w1, #0x4                // =4
    1bb4:      	blr	x8
    1bb8:      	add	x0, x25, #0xc
    1bbc:      	add	x2, x29, #0x14
    1bc0:      	mov	w8, #0x4                // =4
    1bc4:      	mov	w1, #0x4                // =4
    1bc8:      	blr	x8
    1bcc:      	add	x0, x25, #0x18
    1bd0:      	add	x2, x29, #0x20
    1bd4:      	mov	w8, #0x4                // =4
    1bd8:      	mov	w1, #0x4                // =4
    1bdc:      	blr	x8
    1be0:      	add	x0, x25, #0x1c
    1be4:      	add	x2, x29, #0x24
    1be8:      	mov	w8, #0x4                // =4
    1bec:      	mov	w1, #0x4                // =4
    1bf0:      	blr	x8
    1bf4:      	str	wzr, [x25, #0x24]
    1bf8:      	add	x0, x25, #0x20
    1bfc:      	add	x2, x29, #0x28
    1c00:      	mov	w8, #0x4                // =4
    1c04:      	mov	w1, #0x4                // =4
    1c08:      	blr	x8
    1c0c:      	add	x0, x25, #0x30
    1c10:      	add	x2, x29, #0x40
    1c14:      	mov	w21, #0x8               // =8
    1c18:      	mov	w8, #0x4                // =4
    1c1c:      	mov	w1, #0x8                // =8
    1c20:      	blr	x8
    1c24:      	add	x0, x25, #0x38
    1c28:      	add	x2, x29, #0x30
    1c2c:      	mov	w8, #0x4                // =4
    1c30:      	mov	w1, #0x8                // =8
    1c34:      	blr	x8
    1c38:      	add	x2, x29, #0x38
    1c3c:      	mov	w8, #0x4                // =4
    1c40:      	mov	x0, x22
    1c44:      	mov	w1, #0x8                // =8
    1c48:      	blr	x8
    1c4c:      	add	x2, x29, #0x90
    1c50:      	add	x8, sp, #0x98
    1c54:      	mov	w9, #0x4                // =4
    1c58:      	add	x0, sp, #0x98
    1c5c:      	mov	w1, #0x8                // =8
    1c60:      	blr	x9
    1c64:      	ldr	x21, [sp, #0x98]
    1c68:      	mov	w8, #0x4                // =4
    1c6c:      	mov	x0, x24
    1c70:      	mov	w1, #0x4                // =4
    1c74:      	add	x2, x21, #0xc8
    1c78:      	blr	x8
    1c7c:      	add	x0, x25, #0x44
    1c80:      	add	x2, x21, #0xcc
    1c84:      	mov	w8, #0x4                // =4
    1c88:      	mov	w1, #0x4                // =4
    1c8c:      	blr	x8
    1c90:      	add	x0, x25, #0x48
    1c94:      	add	x2, x21, #0xd0
    1c98:      	mov	w8, #0x4                // =4
    1c9c:      	mov	w1, #0x4                // =4
    1ca0:      	blr	x8
    1ca4:      	add	x0, x25, #0x4c
    1ca8:      	add	x2, x21, #0x158
    1cac:      	mov	w1, #0x4                // =4
    1cb0:      	blr	x23
    1cb4:      	mov	w22, #0x50              // =80
    1cb8:      	b	0x1e54 <generic_uprobe_process_event+0x1b94>
    1cbc:      	ldr	x22, [sp, #0x40]
    1cc0:      	mov	w8, #0x4                // =4
    1cc4:      	mov	x0, x25
    1cc8:      	mov	w1, #0x4                // =4
    1ccc:      	mov	w21, #0x4               // =4
    1cd0:      	add	x2, x22, #0xc8
    1cd4:      	blr	x8
    1cd8:      	add	x0, x25, #0x4
    1cdc:      	add	x2, x22, #0xcc
    1ce0:      	mov	w8, #0x4                // =4
    1ce4:      	mov	w1, #0x4                // =4
    1ce8:      	blr	x8
    1cec:      	add	x0, x25, #0x8
    1cf0:      	add	x2, x22, #0xd0
    1cf4:      	mov	w8, #0x4                // =4
    1cf8:      	mov	w1, #0x4                // =4
    1cfc:      	blr	x8
    1d00:      	add	x0, x25, #0xc
    1d04:      	add	x2, x22, #0x158
    1d08:      	mov	w1, #0x4                // =4
    1d0c:      	blr	x21
    1d10:      	mov	w22, #0x10              // =16
    1d14:      	b	0x1e54 <generic_uprobe_process_event+0x1b94>
    1d18:      	ldr	x22, [sp, #0x40]
    1d1c:      	mov	w8, #0x4                // =4
    1d20:      	mov	x0, x25
    1d24:      	mov	w1, #0x4                // =4
    1d28:      	mov	w21, #0x4               // =4
    1d2c:      	add	x2, x22, #0x38
    1d30:      	blr	x8
    1d34:      	add	x0, x25, #0x4
    1d38:      	add	x2, x22, #0x3c
    1d3c:      	mov	w8, #0x4                // =4
    1d40:      	mov	w1, #0x4                // =4
    1d44:      	blr	x8
    1d48:      	add	x0, x25, #0x8
    1d4c:      	add	x2, x22, #0x40
    1d50:      	mov	w8, #0x4                // =4
    1d54:      	mov	w1, #0x4                // =4
    1d58:      	blr	x8
    1d5c:      	add	x0, x25, #0xc
    1d60:      	add	x2, x22, #0x44
    1d64:      	mov	w8, #0x4                // =4
    1d68:      	mov	w1, #0x4                // =4
    1d6c:      	blr	x8
    1d70:      	add	x0, x25, #0x10
    1d74:      	add	x2, x22, #0x80
    1d78:      	mov	w8, #0x10               // =16
    1d7c:      	mov	w1, #0x10               // =16
    1d80:      	blr	x21
    1d84:      	mov	w22, #0x20              // =32
    1d88:      	b	0x1e54 <generic_uprobe_process_event+0x1b94>
    1d8c:      	ldr	x22, [sp, #0x40]
    1d90:      	mov	w8, #0x4                // =4
    1d94:      	mov	x0, x25
    1d98:      	mov	w1, #0x4                // =4
    1d9c:      	mov	w21, #0x4               // =4
    1da0:      	mov	x2, x22
    1da4:      	blr	x8
    1da8:      	add	x0, x25, #0x4
    1dac:      	add	x2, x22, #0x4
    1db0:      	mov	w8, #0x4                // =4
    1db4:      	mov	w1, #0x4                // =4
    1db8:      	blr	x8
    1dbc:      	add	x0, x25, #0x8
    1dc0:      	add	x2, x22, #0x30
    1dc4:      	mov	w8, #0x10               // =16
    1dc8:      	b	0x1e48 <generic_uprobe_process_event+0x1b88>
    1dcc:      	mov	x22, x2
    1dd0:      	add	x2, x2, #0x4
    1dd4:      	add	x8, sp, #0x98
    1dd8:      	mov	w9, #0x4                // =4
    1ddc:      	add	x0, sp, #0x98
    1de0:      	mov	w1, #0x4                // =4
    1de4:      	mov	w21, #0x4               // =4
    1de8:      	blr	x9
    1dec:      	ldr	w8, [sp, #0x98]
    1df0:      	add	x2, x22, #0xc
    1df4:      	add	x0, sp, #0x98
    1df8:      	mov	w1, #0x4                // =4
    1dfc:      	str	w8, [x25]
    1e00:      	add	x8, sp, #0x98
    1e04:      	blr	x21
    1e08:      	ldr	w8, [sp, #0x98]
    1e0c:      	add	x2, x22, #0x50
    1e10:      	add	x9, sp, #0x98
    1e14:      	mov	w10, #0x2d              // =45
    1e18:      	str	w8, [x25, #0x4]
    1e1c:      	mov	w8, #0x8                // =8
    1e20:      	add	x0, sp, #0x98
    1e24:      	mov	w1, #0x8                // =8
    1e28:      	mov	w21, #0x2d              // =45
    1e2c:      	blr	x10
    1e30:      	ldr	x8, [sp, #0x98]
    1e34:      	add	x0, x25, #0x8
    1e38:      	mov	w9, #0x10               // =16
    1e3c:      	add	x8, x8, #0x3f8
    1e40:      	ldr	x8, [sp, #0x98]
    1e44:      	add	x2, x8, #0x3f8
    1e48:      	mov	w1, #0x10               // =16
    1e4c:      	blr	x21
    1e50:      	mov	w22, #0x18              // =24
    1e54:      	mov	w21, #0x5efc            // =24316
    1e58:      	ldr	x11, [sp, #0x30]
    1e5c:      	mov	w10, #0x5ea0            // =24224
    1e60:      	adrp	x25, 0x1000 <generic_uprobe_process_event+0xd40>
    1e64:      	ldr	x23, [sp, #0x48]
    1e68:      	ldr	x25, [x25]
    1e6c:      	b	0x22c8 <generic_uprobe_process_event+0x2008>
    1e70:      	stp	xzr, xzr, [x25, #0x40]
    1e74:      	mov	w8, #0x8                // =8
    1e78:      	mov	w9, #0x4                // =4
    1e7c:      	add	x10, sp, #0x98
    1e80:      	add	x0, sp, #0x98
    1e84:      	mov	w1, #0x8                // =8
    1e88:      	stp	xzr, xzr, [x25, #0x30]
    1e8c:      	stp	xzr, xzr, [x25, #0x20]
    1e90:      	stp	xzr, xzr, [x25, #0x10]
    1e94:      	stp	xzr, xzr, [x25]
    1e98:      	blr	x9
    1e9c:      	mov	x22, xzr
    1ea0:      	cbnz	x0, 0x28bc <generic_uprobe_process_event+0x25fc>
    1ea4:      	ldr	x8, [sp, #0x28]
    1ea8:      	mov	w9, #0x3f               // =63
    1eac:      	mov	w10, #0x2d              // =45
    1eb0:      	mov	w1, #0x3f               // =63
    1eb4:      	add	x0, x8, #0x10
    1eb8:      	ldr	x8, [sp, #0x98]
    1ebc:      	ldr	x2, [sp, #0x98]
    1ec0:      	blr	x10
    1ec4:      	tbnz	x0, #0x3f, 0x2534 <generic_uprobe_process_event+0x2274>
    1ec8:      	ldr	x19, [sp, #0x40]
    1ecc:      	mov	w21, #0x8               // =8
    1ed0:      	add	x8, sp, #0xf0
    1ed4:      	mov	w9, #0x4                // =4
    1ed8:      	add	x0, sp, #0xf0
    1edc:      	mov	w1, #0x8                // =8
    1ee0:      	mov	w22, #0x4               // =4
    1ee4:      	add	x2, x19, #0x8
    1ee8:      	blr	x9
    1eec:      	ldr	x8, [sp, #0x28]
    1ef0:      	add	x10, sp, #0xe0
    1ef4:      	mov	w9, #0x4                // =4
    1ef8:      	mov	w1, #0x8                // =8
    1efc:      	add	x0, x8, #0x8
    1f00:      	ldr	x8, [x10, #0x10]
    1f04:      	add	x8, x8, #0x360
    1f08:      	ldr	x8, [x10, #0x10]
    1f0c:      	add	x2, x8, #0x360
    1f10:      	blr	x9
    1f14:      	add	x2, x19, #0x58
    1f18:      	add	x8, sp, #0xf0
    1f1c:      	add	x0, sp, #0xf0
    1f20:      	mov	w1, #0x4                // =4
    1f24:      	blr	x22
    1f28:      	cbnz	x0, 0x1f40 <generic_uprobe_process_event+0x1c80>
    1f2c:      	ldr	w8, [sp, #0xf0]
    1f30:      	ldr	x9, [sp, #0x28]
    1f34:      	cmp	w8, #0x0
    1f38:      	cset	w8, ne
    1f3c:      	str	w8, [x9]
    1f40:      	mov	w22, #0x50              // =80
    1f44:      	b	0x28bc <generic_uprobe_process_event+0x25fc>
    1f48:      	mov	x22, #-0x1              // =-1
    1f4c:      	b	0x2fb4 <generic_uprobe_process_event+0x2cf4>
    1f50:      	add	x2, x22, #0x10
    1f54:      	mov	w21, #0x8               // =8
    1f58:      	add	x8, sp, #0xf0
    1f5c:      	mov	w9, #0x4                // =4
    1f60:      	add	x0, sp, #0xf0
    1f64:      	mov	w1, #0x8                // =8
    1f68:      	mov	w25, #0x4               // =4
    1f6c:      	blr	x9
    1f70:      	add	x2, x22, #0x18
    1f74:      	add	x8, sp, #0x100
    1f78:      	mov	w9, #0x4                // =4
    1f7c:      	add	x0, sp, #0x100
    1f80:      	mov	w1, #0x8                // =8
    1f84:      	blr	x9
    1f88:      	add	x8, sp, #0xe0
    1f8c:      	add	x21, x23, x29
    1f90:      	ldr	x24, [x8, #0x20]
    1f94:      	ldr	x2, [x8, #0x10]
    1f98:      	mov	w8, #0xfff              // =4095
    1f9c:      	add	x0, x21, #0x98
    1fa0:      	cmp	x24, #0xfff
    1fa4:      	csel	x22, x24, x8, lo
    1fa8:      	mov	w1, w22
    1fac:      	blr	x25
    1fb0:      	tbnz	w0, #0x1f, 0x2278 <generic_uprobe_process_event+0x1fb8>
    1fb4:      	stp	w24, w22, [x21, #0x90]
    1fb8:      	add	x22, x22, #0x8
    1fbc:      	b	0x2fb4 <generic_uprobe_process_event+0x2cf4>
    1fc0:      	str	wzr, [sp, #0xf0]
    1fc4:      	adrp	x0, 0x1000 <generic_uprobe_process_event+0xd40>
    1fc8:      	ldr	x29, [sp, #0x98]
    1fcc:      	mov	w8, #0x1                // =1
    1fd0:      	add	x9, sp, #0xf0
    1fd4:      	add	x1, sp, #0xf0
    1fd8:      	ldrh	w21, [sp, #0x90]
    1fdc:      	ldr	x0, [x0]
    1fe0:      	add	x19, x29, x21
    1fe4:      	blr	x8
    1fe8:      	cbz	x0, 0x2e30 <generic_uprobe_process_event+0x2b70>
    1fec:      	mov	w8, #0xff               // =255
    1ff0:      	strh	w21, [x0]
    1ff4:      	strb	wzr, [x0, #0x7]
    1ff8:      	add	x22, x0, #0x6
    1ffc:      	add	x2, x19, #0x6
    2000:      	mov	w9, #0x4                // =4
    2004:      	strb	w8, [x0, #0x5]
    2008:      	mov	w8, #0x1                // =1
    200c:      	mov	x23, x0
    2010:      	mov	x0, x22
    2014:      	mov	w1, #0x1                // =1
    2018:      	blr	x9
    201c:      	tbnz	x0, #0x3f, 0x2e30 <generic_uprobe_process_event+0x2b70>
    2020:      	ldrb	w8, [x23, #0x5]
    2024:      	cmp	w8, #0x32
    2028:      	b.gt	0x253c <generic_uprobe_process_event+0x227c>
    202c:      	cbz	w8, 0x25b4 <generic_uprobe_process_event+0x22f4>
    2030:      	cmp	w8, #0x2b
    2034:      	b.eq	0x25b4 <generic_uprobe_process_event+0x22f4>
    2038:      	cmp	w8, #0x2c
    203c:      	b.ne	0x298c <generic_uprobe_process_event+0x26cc>
    2040:      	mov	w8, #0x8                // =8
    2044:      	b	0x28d8 <generic_uprobe_process_event+0x2618>
    2048:      	add	x2, x23, #0x48
    204c:      	mov	w21, #0x10              // =16
    2050:      	mov	w8, #0x4                // =4
    2054:      	mov	x0, x25
    2058:      	mov	w1, #0x10               // =16
    205c:      	mov	w24, #0x4               // =4
    2060:      	blr	x8
    2064:      	add	x2, x23, #0x38
    2068:      	mov	x0, x22
    206c:      	mov	w1, #0x10               // =16
    2070:      	blr	x24
    2074:      	add	x0, x25, #0x20
    2078:      	add	x2, x23, #0xe
    207c:      	mov	w21, #0x2               // =2
    2080:      	mov	w8, #0x4                // =4
    2084:      	mov	w1, #0x2                // =2
    2088:      	add	x22, x23, #0xc
    208c:      	mov	w23, #0x4               // =4
    2090:      	blr	x8
    2094:      	add	x0, x25, #0x22
    2098:      	mov	w1, #0x2                // =2
    209c:      	mov	x2, x22
    20a0:      	blr	x23
    20a4:      	ldrh	w8, [x25, #0x22]
    20a8:      	adrp	x0, 0x2000 <generic_uprobe_process_event+0x1d40>
    20ac:      	add	x9, sp, #0x98
    20b0:      	add	x1, sp, #0x98
    20b4:      	rev	w8, w8
    20b8:      	lsr	w8, w8, #16
    20bc:      	strh	w8, [x25, #0x22]
    20c0:      	add	x8, sp, #0xe0
    20c4:      	ldr	x8, [x8, #0x8]
    20c8:      	str	x8, [sp, #0x98]
    20cc:      	mov	w8, #0x1                // =1
    20d0:      	ldr	x0, [x0]
    20d4:      	blr	x8
    20d8:      	cbz	x0, 0x2fb0 <generic_uprobe_process_event+0x2cf0>
    20dc:      	ldr	w8, [x0]
    20e0:      	mov	w22, #0x40              // =64
    20e4:      	str	w8, [x29, #0x10]
    20e8:      	ldr	x8, [x0, #0x8]
    20ec:      	str	x8, [x29, #0x18]
    20f0:      	ldr	w8, [x0, #0x4]
    20f4:      	str	w8, [x29, #0x7c]
    20f8:      	b	0x2fb4 <generic_uprobe_process_event+0x2cf4>
    20fc:      	add	x8, x23, x29
    2100:      	mov	w22, #0x8               // =8
    2104:      	str	xzr, [x8, #0x90]
    2108:      	b	0x2fb4 <generic_uprobe_process_event+0x2cf4>
    210c:      	mov	w8, #0xe                // =14
    2110:      	blr	x8
    2114:      	cmn	x0, #0x16
    2118:      	b.ne	0x2140 <generic_uprobe_process_event+0x1e80>
    211c:      	ldr	x8, [sp, #0x50]
    2120:      	mov	w9, #0x4                // =4
    2124:      	add	x10, sp, #0x98
    2128:      	add	x0, sp, #0x98
    212c:      	mov	w1, #0x8                // =8
    2130:      	add	x2, x8, #0xe8
    2134:      	mov	w8, #0x8                // =8
    2138:      	blr	x9
    213c:      	ldr	x0, [sp, #0x98]
    2140:      	ldr	x10, [x22, #0x8]
    2144:      	ldr	x9, [sp, #0x40]
    2148:      	mov	x3, xzr
    214c:      	add	x1, sp, #0xf0
    2150:      	add	x2, sp, #0x98
    2154:      	add	x21, sp, #0xe0
    2158:      	ldr	x8, [x22, #0x60]
    215c:      	str	xzr, [sp, #0xa8]
    2160:      	stp	x10, x9, [sp, #0x98]
    2164:      	add	x9, sp, #0xe0
    2168:      	add	x10, sp, #0x98
    216c:      	stp	x8, x0, [x9, #0x10]
    2170:      	adrp	x0, 0x2000 <generic_uprobe_process_event+0x1d40>
    2174:      	mov	w8, #0x2                // =2
    2178:      	add	x9, sp, #0xf0
    217c:      	ldr	x0, [x0]
    2180:      	blr	x8
    2184:      	cbz	x0, 0x2580 <generic_uprobe_process_event+0x22c0>
    2188:      	neg	w8, w0
    218c:      	adrp	x22, 0x2000 <generic_uprobe_process_event+0x1d40>
    2190:      	mov	w9, #0x1                // =1
    2194:      	strh	w8, [sp, #0x100]
    2198:      	mov	w8, #0x5                // =5
    219c:      	add	x1, sp, #0x100
    21a0:      	strh	w8, [sp, #0x102]
    21a4:      	mov	x8, #0x46               // =70
    21a8:      	movk	x8, #0x2, lsl #32
    21ac:      	stur	x8, [x21, #0x24]
    21b0:      	add	x8, sp, #0x100
    21b4:      	mov	w21, #0x1               // =1
    21b8:      	ldr	x22, [x22]
    21bc:      	mov	x0, x22
    21c0:      	blr	x9
    21c4:      	cbz	x0, 0x255c <generic_uprobe_process_event+0x229c>
    21c8:      	ldr	w8, [x0]
    21cc:      	add	w8, w8, #0x1
    21d0:      	str	w8, [x0]
    21d4:      	b	0x2580 <generic_uprobe_process_event+0x22c0>
    21d8:      	cmp	w8, #0x1
    21dc:      	b.eq	0x23f8 <generic_uprobe_process_event+0x2138>
    21e0:      	cmp	w8, #0x2
    21e4:      	b.ne	0x2444 <generic_uprobe_process_event+0x2184>
    21e8:      	mov	w8, #0x5e58             // =24152
    21ec:      	b	0x23fc <generic_uprobe_process_event+0x213c>
    21f0:      	ldr	x23, [sp, #0x28]
    21f4:      	add	x2, x22, #0x8
    21f8:      	mov	w8, #0x10               // =16
    21fc:      	mov	w9, #0x4                // =4
    2200:      	mov	w1, #0x10               // =16
    2204:      	mov	w21, #0x4               // =4
    2208:      	add	x0, x23, #0x8
    220c:      	blr	x9
    2210:      	add	x0, x23, #0x2
    2214:      	add	x2, x22, #0x2
    2218:      	mov	w8, #0x2                // =2
    221c:      	mov	w1, #0x2                // =2
    2220:      	blr	x21
    2224:      	ldr	x9, [sp, #0x28]
    2228:      	adrp	x25, 0x2000 <generic_uprobe_process_event+0x1d40>
    222c:      	mov	w21, #0x5efc            // =24316
    2230:      	ldrh	w8, [x9, #0x2]
    2234:      	rev	w8, w8
    2238:      	lsr	w8, w8, #16
    223c:      	strh	w8, [x9, #0x2]
    2240:      	ldr	x25, [x25]
    2244:      	ldr	x19, [sp, #0x50]
    2248:      	mov	w22, #0x18              // =24
    224c:      	b	0x22bc <generic_uprobe_process_event+0x1ffc>
    2250:      	mov	x22, xzr
    2254:      	ldr	x19, [sp, #0x50]
    2258:      	mov	w21, #0x5efc            // =24316
    225c:      	mov	w10, #0x5ea0            // =24224
    2260:      	mov	x11, x23
    2264:      	b	0x1e60 <generic_uprobe_process_event+0x1ba0>
    2268:      	mov	w8, #-0x2               // =-2
    226c:      	mov	w22, #0x4               // =4
    2270:      	stur	w8, [x23, #0x90]
    2274:      	b	0x2fb4 <generic_uprobe_process_event+0x2cf4>
    2278:      	mov	w8, #-0x2               // =-2
    227c:      	mov	w22, #0x4               // =4
    2280:      	stur	w8, [x21, #0x90]
    2284:      	b	0x2fb4 <generic_uprobe_process_event+0x2cf4>
    2288:      	add	x2, x22, #0x3
    228c:      	mov	w21, #0x6b              // =107
    2290:      	mov	w8, #0x71               // =113
    2294:      	mov	w1, #0x6b               // =107
    2298:      	blr	x8
    229c:      	adrp	x25, 0x2000 <generic_uprobe_process_event+0x1d40>
    22a0:      	ldr	x25, [x25]
    22a4:      	ldr	x19, [sp, #0x50]
    22a8:      	tbnz	w0, #0x1f, 0x22b4 <generic_uprobe_process_event+0x1ff4>
    22ac:      	ldr	x8, [sp, #0x28]
    22b0:      	strb	w21, [x8, #0x3]
    22b4:      	mov	w22, #0x70              // =112
    22b8:      	mov	w21, #0x5efc            // =24316
    22bc:      	ldr	x11, [sp, #0x30]
    22c0:      	mov	w10, #0x5ea0            // =24224
    22c4:      	ldr	x23, [sp, #0x48]
    22c8:      	ldr	x24, [sp, #0x118]
    22cc:      	tbnz	w22, #0x1f, 0x22f4 <generic_uprobe_process_event+0x2034>
    22d0:      	and	w8, w22, #0x7fffffff
    22d4:      	add	w8, w8, #0x4
    22d8:      	add	w24, w8, w24
    22dc:      	str	w24, [x20, #0x4]
    22e0:      	adrp	x22, 0x2000 <generic_uprobe_process_event+0x1d40>
    22e4:      	cmp	w23, #0x3
    22e8:      	ldr	x22, [x22]
    22ec:      	b.le	0x848 <generic_uprobe_process_event+0x588>
    22f0:      	b	0x8b4 <generic_uprobe_process_event+0x5f4>
    22f4:      	ldr	x9, [sp, #0x20]
    22f8:      	mov	w8, #-0x1               // =-1
    22fc:      	str	w8, [x9, x10]
    2300:      	str	w8, [x11, x24]
    2304:      	b	0x80c <generic_uprobe_process_event+0x54c>
    2308:      	cmp	w9, #0x1
    230c:      	b.eq	0x25d0 <generic_uprobe_process_event+0x2310>
    2310:      	cmp	w9, #0x2
    2314:      	b.ne	0x25dc <generic_uprobe_process_event+0x231c>
    2318:      	mov	w8, #0x5e58             // =24152
    231c:      	b	0x25d4 <generic_uprobe_process_event+0x2314>
    2320:      	ldr	x0, [sp, #0x28]
    2324:      	add	x2, x23, #0x48
    2328:      	mov	w21, #0x10              // =16
    232c:      	mov	w8, #0x4                // =4
    2330:      	mov	w1, #0x10               // =16
    2334:      	mov	w24, #0x4               // =4
    2338:      	blr	x8
    233c:      	add	x2, x23, #0x38
    2340:      	mov	x0, x22
    2344:      	mov	w1, #0x10               // =16
    2348:      	blr	x24
    234c:      	ldr	x24, [sp, #0x28]
    2350:      	add	x2, x23, #0xe
    2354:      	mov	w21, #0x2               // =2
    2358:      	mov	w8, #0x4                // =4
    235c:      	mov	w1, #0x2                // =2
    2360:      	add	x22, x23, #0xc
    2364:      	mov	w23, #0x4               // =4
    2368:      	add	x0, x24, #0x20
    236c:      	blr	x8
    2370:      	add	x0, x24, #0x22
    2374:      	mov	w1, #0x2                // =2
    2378:      	mov	x2, x22
    237c:      	blr	x23
    2380:      	ldrh	w8, [x24, #0x22]
    2384:      	rev	w8, w8
    2388:      	lsr	w8, w8, #16
    238c:      	strh	w8, [x24, #0x22]
    2390:      	ldr	x8, [sp, #0x28]
    2394:      	adrp	x0, 0x2000 <generic_uprobe_process_event+0x1d40>
    2398:      	add	x9, sp, #0x98
    239c:      	add	x1, sp, #0x98
    23a0:      	ldr	x8, [x8, #0x28]
    23a4:      	str	x8, [sp, #0x98]
    23a8:      	mov	w8, #0x1                // =1
    23ac:      	ldr	x0, [x0]
    23b0:      	blr	x8
    23b4:      	cbz	x0, 0x23d0 <generic_uprobe_process_event+0x2110>
    23b8:      	ldr	w8, [x0]
    23bc:      	str	w8, [x29, #0x10]
    23c0:      	ldr	x8, [x0, #0x8]
    23c4:      	str	x8, [x29, #0x18]
    23c8:      	ldr	w8, [x0, #0x4]
    23cc:      	str	w8, [x29, #0x7c]
    23d0:      	ldr	x19, [sp, #0x50]
    23d4:      	mov	w22, #0x40              // =64
    23d8:      	mov	w21, #0x5efc            // =24316
    23dc:      	mov	w10, #0x5ea0            // =24224
    23e0:      	mov	x11, x25
    23e4:      	b	0x1e60 <generic_uprobe_process_event+0x1ba0>
    23e8:      	mov	w8, #0x5e60             // =24160
    23ec:      	b	0x23fc <generic_uprobe_process_event+0x213c>
    23f0:      	mov	w8, #0x5e68             // =24168
    23f4:      	b	0x23fc <generic_uprobe_process_event+0x213c>
    23f8:      	mov	w8, #0x5e50             // =24144
    23fc:      	add	x8, x25, x8
    2400:      	ldr	x24, [x8]
    2404:      	ldr	x8, [sp, #0x38]
    2408:      	tbnz	w8, #0x4, 0x2454 <generic_uprobe_process_event+0x2194>
    240c:      	cbz	x24, 0x2524 <generic_uprobe_process_event+0x2264>
    2410:      	ldr	x2, [sp, #0x40]
    2414:      	mov	w8, #0x10               // =16
    2418:      	mov	w9, #0x4                // =4
    241c:      	add	x10, sp, #0x98
    2420:      	add	x0, sp, #0x98
    2424:      	mov	w1, #0x10               // =16
    2428:      	blr	x9
    242c:      	tbnz	w0, #0x1f, 0x28b0 <generic_uprobe_process_event+0x25f0>
    2430:      	ldr	x22, [sp, #0xa0]
    2434:      	cmp	x22, #0xffe
    2438:      	b.ls	0x2644 <generic_uprobe_process_event+0x2384>
    243c:      	mov	w8, #-0x3               // =-3
    2440:      	b	0x28b4 <generic_uprobe_process_event+0x25f4>
    2444:      	ldr	x8, [sp, #0x38]
    2448:      	mov	x24, xzr
    244c:      	mov	x22, xzr
    2450:      	tbz	w8, #0x4, 0x2528 <generic_uprobe_process_event+0x2268>
    2454:      	mov	w8, #0xe                // =14
    2458:      	blr	x8
    245c:      	cmn	x0, #0x16
    2460:      	b.ne	0x2488 <generic_uprobe_process_event+0x21c8>
    2464:      	ldr	x8, [sp, #0x50]
    2468:      	mov	w9, #0x4                // =4
    246c:      	add	x10, sp, #0x98
    2470:      	add	x0, sp, #0x98
    2474:      	mov	w1, #0x8                // =8
    2478:      	add	x2, x8, #0xe8
    247c:      	mov	w8, #0x8                // =8
    2480:      	blr	x9
    2484:      	ldr	x0, [sp, #0x98]
    2488:      	ldr	x10, [x25, #0x8]
    248c:      	ldr	x9, [sp, #0x40]
    2490:      	mov	x3, xzr
    2494:      	add	x1, sp, #0xf0
    2498:      	add	x2, sp, #0x98
    249c:      	add	x21, sp, #0xe0
    24a0:      	ldr	x8, [x25, #0x60]
    24a4:      	str	x24, [sp, #0xa8]
    24a8:      	stp	x10, x9, [sp, #0x98]
    24ac:      	add	x9, sp, #0xe0
    24b0:      	add	x10, sp, #0x98
    24b4:      	stp	x8, x0, [x9, #0x10]
    24b8:      	adrp	x0, 0x2000 <generic_uprobe_process_event+0x1d40>
    24bc:      	mov	w8, #0x2                // =2
    24c0:      	add	x9, sp, #0xf0
    24c4:      	ldr	x0, [x0]
    24c8:      	blr	x8
    24cc:      	cbz	x0, 0x25ac <generic_uprobe_process_event+0x22ec>
    24d0:      	neg	w8, w0
    24d4:      	adrp	x22, 0x2000 <generic_uprobe_process_event+0x1d40>
    24d8:      	mov	w9, #0x1                // =1
    24dc:      	strh	w8, [sp, #0x100]
    24e0:      	mov	w8, #0x5                // =5
    24e4:      	add	x1, sp, #0x100
    24e8:      	strh	w8, [sp, #0x102]
    24ec:      	mov	x8, #0x57               // =87
    24f0:      	movk	x8, #0x2, lsl #32
    24f4:      	stur	x8, [x21, #0x24]
    24f8:      	add	x8, sp, #0x100
    24fc:      	mov	w21, #0x1               // =1
    2500:      	ldr	x22, [x22]
    2504:      	mov	x0, x22
    2508:      	blr	x9
    250c:      	cbz	x0, 0x2588 <generic_uprobe_process_event+0x22c8>
    2510:      	ldr	w8, [x0]
    2514:      	add	w8, w8, #0x1
    2518:      	str	w8, [x0]
    251c:      	mov	w8, #-0x4               // =-4
    2520:      	b	0x28b4 <generic_uprobe_process_event+0x25f4>
    2524:      	mov	x22, xzr
    2528:      	stp	w22, w22, [x29]
    252c:      	add	x22, x22, #0x8
    2530:      	b	0x28bc <generic_uprobe_process_event+0x25fc>
    2534:      	mov	x22, xzr
    2538:      	b	0x28bc <generic_uprobe_process_event+0x25fc>
    253c:      	cmp	w8, #0x33
    2540:      	b.eq	0x28cc <generic_uprobe_process_event+0x260c>
    2544:      	cmp	w8, #0x3c
    2548:      	b.eq	0x25b4 <generic_uprobe_process_event+0x22f4>
    254c:      	cmp	w8, #0xff
    2550:      	b.ne	0x298c <generic_uprobe_process_event+0x26cc>
    2554:      	mov	w8, #0x28               // =40
    2558:      	b	0x28d8 <generic_uprobe_process_event+0x2618>
    255c:      	str	w21, [sp, #0x90]
    2560:      	mov	x3, xzr
    2564:      	mov	w8, #0x2                // =2
    2568:      	add	x9, sp, #0x100
    256c:      	add	x10, sp, #0x90
    2570:      	add	x1, sp, #0x100
    2574:      	add	x2, sp, #0x90
    2578:      	mov	x0, x22
    257c:      	blr	x8
    2580:      	mov	w8, #-0x4               // =-4
    2584:      	b	0x263c <generic_uprobe_process_event+0x237c>
    2588:      	str	w21, [sp, #0xe8]
    258c:      	mov	x3, xzr
    2590:      	mov	w8, #0x2                // =2
    2594:      	add	x9, sp, #0x100
    2598:      	add	x10, sp, #0xe8
    259c:      	add	x1, sp, #0x100
    25a0:      	add	x2, sp, #0xe8
    25a4:      	mov	x0, x22
    25a8:      	blr	x8
    25ac:      	mov	w8, #-0x4               // =-4
    25b0:      	b	0x28b4 <generic_uprobe_process_event+0x25f4>
    25b4:      	ldrb	w8, [x23, #0x7]
    25b8:      	lsl	w8, w8, #3
    25bc:      	b	0x28d4 <generic_uprobe_process_event+0x2614>
    25c0:      	mov	w8, #0x5e60             // =24160
    25c4:      	b	0x25d4 <generic_uprobe_process_event+0x2314>
    25c8:      	mov	w8, #0x5e68             // =24168
    25cc:      	b	0x25d4 <generic_uprobe_process_event+0x2314>
    25d0:      	mov	w8, #0x5e50             // =24144
    25d4:      	add	x8, x22, x8
    25d8:      	ldr	x8, [x8]
    25dc:      	add	x19, sp, #0xe0
    25e0:      	add	x9, sp, #0xe0
    25e4:      	add	x10, sp, #0xe8
    25e8:      	str	x8, [x19, #0x8]
    25ec:      	mov	w8, #0x8                // =8
    25f0:      	mov	w11, #0x4               // =4
    25f4:      	add	x0, sp, #0xe0
    25f8:      	add	x2, sp, #0xe8
    25fc:      	mov	w1, #0x8                // =8
    2600:      	mov	w23, #0x4               // =4
    2604:      	blr	x11
    2608:      	ldr	x21, [x19]
    260c:      	mov	w8, #0xfff              // =4095
    2610:      	ldr	x2, [sp, #0x40]
    2614:      	add	x0, x24, #0x8
    2618:      	cmp	x21, #0xfff
    261c:      	csel	x22, x21, x8, lo
    2620:      	mov	w1, w22
    2624:      	blr	x23
    2628:      	tbnz	w0, #0x1f, 0x2638 <generic_uprobe_process_event+0x2378>
    262c:      	stp	w21, w22, [x24]
    2630:      	add	x22, x22, #0x8
    2634:      	b	0x28bc <generic_uprobe_process_event+0x25fc>
    2638:      	mov	w8, #-0x2               // =-2
    263c:      	str	w8, [x24]
    2640:      	b	0x28b8 <generic_uprobe_process_event+0x25f8>
    2644:      	ldr	x8, [sp, #0x118]
    2648:      	mov	w9, #0x4                // =4
    264c:      	mov	w1, w22
    2650:      	add	x21, x8, #0xc
    2654:      	and	x8, x21, #0x3fff
    2658:      	add	x0, x23, x8
    265c:      	ldr	x8, [sp, #0x98]
    2660:      	ldr	x2, [sp, #0x98]
    2664:      	blr	x9
    2668:      	tbnz	w0, #0x1f, 0x28b0 <generic_uprobe_process_event+0x25f0>
    266c:      	cmp	x24, #0x1
    2670:      	b.eq	0x2528 <generic_uprobe_process_event+0x2268>
    2674:      	ldr	x8, [sp, #0x40]
    2678:      	mov	w9, #0x4                // =4
    267c:      	add	x10, sp, #0x98
    2680:      	add	x0, sp, #0x98
    2684:      	mov	w1, #0x10               // =16
    2688:      	add	x2, x8, #0x10
    268c:      	mov	w8, #0x10               // =16
    2690:      	blr	x9
    2694:      	tbnz	w0, #0x1f, 0x28b0 <generic_uprobe_process_event+0x25f0>
    2698:      	ldr	x19, [sp, #0xa0]
    269c:      	cmp	x19, #0xffe
    26a0:      	b.hi	0x243c <generic_uprobe_process_event+0x217c>
    26a4:      	add	x21, x22, x21
    26a8:      	mov	w9, #0x4                // =4
    26ac:      	mov	w1, w19
    26b0:      	and	x8, x21, #0x3fff
    26b4:      	add	x0, x23, x8
    26b8:      	ldr	x8, [sp, #0x98]
    26bc:      	ldr	x2, [sp, #0x98]
    26c0:      	blr	x9
    26c4:      	tbnz	w0, #0x1f, 0x28b0 <generic_uprobe_process_event+0x25f0>
    26c8:      	add	x22, x19, x22
    26cc:      	cmp	x24, #0x3
    26d0:      	b.lo	0x2528 <generic_uprobe_process_event+0x2268>
    26d4:      	ldr	x8, [sp, #0x40]
    26d8:      	mov	w9, #0x4                // =4
    26dc:      	add	x10, sp, #0x98
    26e0:      	add	x0, sp, #0x98
    26e4:      	mov	w1, #0x10               // =16
    26e8:      	add	x2, x8, #0x20
    26ec:      	mov	w8, #0x10               // =16
    26f0:      	blr	x9
    26f4:      	tbnz	w0, #0x1f, 0x28b0 <generic_uprobe_process_event+0x25f0>
    26f8:      	ldr	x25, [sp, #0xa0]
    26fc:      	cmp	x25, #0xffe
    2700:      	b.hi	0x243c <generic_uprobe_process_event+0x217c>
    2704:      	add	x21, x19, x21
    2708:      	mov	w9, #0x4                // =4
    270c:      	mov	w1, w25
    2710:      	and	x8, x21, #0x3fff
    2714:      	add	x0, x23, x8
    2718:      	ldr	x8, [sp, #0x98]
    271c:      	ldr	x2, [sp, #0x98]
    2720:      	blr	x9
    2724:      	tbnz	w0, #0x1f, 0x28b0 <generic_uprobe_process_event+0x25f0>
    2728:      	add	x22, x25, x22
    272c:      	cmp	x24, #0x3
    2730:      	b.eq	0x2528 <generic_uprobe_process_event+0x2268>
    2734:      	ldr	x8, [sp, #0x40]
    2738:      	mov	w9, #0x4                // =4
    273c:      	add	x10, sp, #0x98
    2740:      	add	x0, sp, #0x98
    2744:      	mov	w1, #0x10               // =16
    2748:      	add	x2, x8, #0x30
    274c:      	mov	w8, #0x10               // =16
    2750:      	blr	x9
    2754:      	tbnz	w0, #0x1f, 0x28b0 <generic_uprobe_process_event+0x25f0>
    2758:      	ldr	x19, [sp, #0xa0]
    275c:      	cmp	x19, #0xffe
    2760:      	b.hi	0x243c <generic_uprobe_process_event+0x217c>
    2764:      	add	x21, x25, x21
    2768:      	mov	w9, #0x4                // =4
    276c:      	mov	w1, w19
    2770:      	and	x8, x21, #0x3fff
    2774:      	add	x0, x23, x8
    2778:      	ldr	x8, [sp, #0x98]
    277c:      	ldr	x2, [sp, #0x98]
    2780:      	blr	x9
    2784:      	tbnz	w0, #0x1f, 0x28b0 <generic_uprobe_process_event+0x25f0>
    2788:      	add	x22, x19, x22
    278c:      	cmp	x24, #0x5
    2790:      	b.lo	0x2528 <generic_uprobe_process_event+0x2268>
    2794:      	ldr	x8, [sp, #0x40]
    2798:      	mov	w9, #0x4                // =4
    279c:      	add	x10, sp, #0x98
    27a0:      	add	x0, sp, #0x98
    27a4:      	mov	w1, #0x10               // =16
    27a8:      	add	x2, x8, #0x40
    27ac:      	mov	w8, #0x10               // =16
    27b0:      	blr	x9
    27b4:      	tbnz	w0, #0x1f, 0x28b0 <generic_uprobe_process_event+0x25f0>
    27b8:      	ldr	x25, [sp, #0xa0]
    27bc:      	cmp	x25, #0xffe
    27c0:      	b.hi	0x243c <generic_uprobe_process_event+0x217c>
    27c4:      	add	x21, x19, x21
    27c8:      	mov	w9, #0x4                // =4
    27cc:      	mov	w1, w25
    27d0:      	and	x8, x21, #0x3fff
    27d4:      	add	x0, x23, x8
    27d8:      	ldr	x8, [sp, #0x98]
    27dc:      	ldr	x2, [sp, #0x98]
    27e0:      	blr	x9
    27e4:      	tbnz	w0, #0x1f, 0x28b0 <generic_uprobe_process_event+0x25f0>
    27e8:      	add	x22, x25, x22
    27ec:      	cmp	x24, #0x5
    27f0:      	b.eq	0x2528 <generic_uprobe_process_event+0x2268>
    27f4:      	ldr	x8, [sp, #0x40]
    27f8:      	mov	w9, #0x4                // =4
    27fc:      	add	x10, sp, #0x98
    2800:      	add	x0, sp, #0x98
    2804:      	mov	w1, #0x10               // =16
    2808:      	add	x2, x8, #0x50
    280c:      	mov	w8, #0x10               // =16
    2810:      	blr	x9
    2814:      	tbnz	w0, #0x1f, 0x28b0 <generic_uprobe_process_event+0x25f0>
    2818:      	ldr	x19, [sp, #0xa0]
    281c:      	cmp	x19, #0xffe
    2820:      	b.hi	0x243c <generic_uprobe_process_event+0x217c>
    2824:      	add	x21, x25, x21
    2828:      	mov	w9, #0x4                // =4
    282c:      	mov	w1, w19
    2830:      	and	x8, x21, #0x3fff
    2834:      	add	x0, x23, x8
    2838:      	ldr	x8, [sp, #0x98]
    283c:      	ldr	x2, [sp, #0x98]
    2840:      	blr	x9
    2844:      	tbnz	w0, #0x1f, 0x28b0 <generic_uprobe_process_event+0x25f0>
    2848:      	add	x22, x19, x22
    284c:      	cmp	x24, #0x7
    2850:      	b.lo	0x2528 <generic_uprobe_process_event+0x2268>
    2854:      	ldr	x8, [sp, #0x40]
    2858:      	mov	w9, #0x4                // =4
    285c:      	add	x10, sp, #0x98
    2860:      	add	x0, sp, #0x98
    2864:      	mov	w1, #0x10               // =16
    2868:      	add	x2, x8, #0x60
    286c:      	mov	w8, #0x10               // =16
    2870:      	blr	x9
    2874:      	tbnz	w0, #0x1f, 0x28b0 <generic_uprobe_process_event+0x25f0>
    2878:      	ldr	x24, [sp, #0xa0]
    287c:      	cmp	x24, #0xffe
    2880:      	b.hi	0x243c <generic_uprobe_process_event+0x217c>
    2884:      	add	x8, x19, x21
    2888:      	mov	w9, #0x4                // =4
    288c:      	mov	w1, w24
    2890:      	and	x8, x8, #0x3fff
    2894:      	add	x0, x23, x8
    2898:      	ldr	x8, [sp, #0x98]
    289c:      	ldr	x2, [sp, #0x98]
    28a0:      	blr	x9
    28a4:      	tbnz	w0, #0x1f, 0x28b0 <generic_uprobe_process_event+0x25f0>
    28a8:      	add	x22, x24, x22
    28ac:      	b	0x2528 <generic_uprobe_process_event+0x2268>
    28b0:      	mov	w8, #-0x2               // =-2
    28b4:      	str	w8, [x29]
    28b8:      	mov	w22, #0x4               // =4
    28bc:      	ldr	x11, [sp, #0x30]
    28c0:      	ldr	x19, [sp, #0x50]
    28c4:      	mov	w21, #0x5efc            // =24316
    28c8:      	b	0x1e5c <generic_uprobe_process_event+0x1b9c>
    28cc:      	ldrb	w8, [x23, #0x7]
    28d0:      	lsl	w8, w8, #2
    28d4:      	add	w8, w8, #0x8
    28d8:      	strh	w8, [x23, #0x2]
    28dc:      	ldrh	w9, [x23]
    28e0:      	ldrb	w25, [x23, #0x6]
    28e4:      	add	w8, w9, w8
    28e8:      	cmp	w25, #0x3c
    28ec:      	strh	w8, [x23]
    28f0:      	b.hi	0x29a8 <generic_uprobe_process_event+0x26e8>
    28f4:      	mov	x21, #0x1               // =1
    28f8:      	mov	w9, #0x1                // =1
    28fc:      	movk	x21, #0x1800, lsl #32
    2900:      	lsl	x9, x9, x25
    2904:      	movk	x21, #0x1008, lsl #48
    2908:      	tst	x9, x21
    290c:      	b.eq	0x29a8 <generic_uprobe_process_event+0x26e8>
    2910:      	strb	w25, [x23, #0x5]
    2914:      	add	x8, x29, w8, uxth
    2918:      	mov	w9, #0x2                // =2
    291c:      	mov	w10, #0x4               // =4
    2920:      	mov	x0, x22
    2924:      	mov	w1, #0x2                // =2
    2928:      	ldrh	w8, [x23]
    292c:      	add	x2, x29, x8
    2930:      	blr	x10
    2934:      	tbnz	x0, #0x3f, 0x2e30 <generic_uprobe_process_event+0x2b70>
    2938:      	ldrb	w8, [x23, #0x5]
    293c:      	cmp	w8, #0x32
    2940:      	b.gt	0x2960 <generic_uprobe_process_event+0x26a0>
    2944:      	cbz	w8, 0x2980 <generic_uprobe_process_event+0x26c0>
    2948:      	cmp	w8, #0x2b
    294c:      	b.eq	0x2980 <generic_uprobe_process_event+0x26c0>
    2950:      	cmp	w8, #0x2c
    2954:      	b.ne	0x2a64 <generic_uprobe_process_event+0x27a4>
    2958:      	mov	w8, #0x8                // =8
    295c:      	b	0x29bc <generic_uprobe_process_event+0x26fc>
    2960:      	cmp	w8, #0x33
    2964:      	b.eq	0x29b0 <generic_uprobe_process_event+0x26f0>
    2968:      	cmp	w8, #0x3c
    296c:      	b.eq	0x2980 <generic_uprobe_process_event+0x26c0>
    2970:      	cmp	w8, #0xff
    2974:      	b.ne	0x2a64 <generic_uprobe_process_event+0x27a4>
    2978:      	mov	w8, #0x28               // =40
    297c:      	b	0x29bc <generic_uprobe_process_event+0x26fc>
    2980:      	ldrb	w8, [x23, #0x7]
    2984:      	lsl	w8, w8, #3
    2988:      	b	0x29b8 <generic_uprobe_process_event+0x26f8>
    298c:      	ldrh	w8, [x23, #0x2]
    2990:      	ldrh	w9, [x23]
    2994:      	ldrb	w25, [x23, #0x6]
    2998:      	add	w8, w9, w8
    299c:      	cmp	w25, #0x3c
    29a0:      	strh	w8, [x23]
    29a4:      	b.ls	0x28f4 <generic_uprobe_process_event+0x2634>
    29a8:      	strh	w8, [sp, #0x88]
    29ac:      	b	0x2e34 <generic_uprobe_process_event+0x2b74>
    29b0:      	ldrb	w8, [x23, #0x7]
    29b4:      	lsl	w8, w8, #2
    29b8:      	add	w8, w8, #0x8
    29bc:      	strh	w8, [x23, #0x2]
    29c0:      	ldrh	w9, [x23]
    29c4:      	ldrb	w25, [x23, #0x6]
    29c8:      	add	w8, w9, w8
    29cc:      	cmp	w25, #0x3c
    29d0:      	strh	w8, [x23]
    29d4:      	b.hi	0x2fec <generic_uprobe_process_event+0x2d2c>
    29d8:      	mov	w9, #0x1                // =1
    29dc:      	lsl	x9, x9, x25
    29e0:      	tst	x9, x21
    29e4:      	b.eq	0x2fec <generic_uprobe_process_event+0x2d2c>
    29e8:      	strb	w25, [x23, #0x5]
    29ec:      	add	x8, x29, w8, uxth
    29f0:      	mov	w9, #0x2                // =2
    29f4:      	mov	w10, #0x4               // =4
    29f8:      	mov	x0, x22
    29fc:      	mov	w1, #0x2                // =2
    2a00:      	ldrh	w8, [x23]
    2a04:      	add	x2, x29, x8
    2a08:      	blr	x10
    2a0c:      	tbnz	x0, #0x3f, 0x2e30 <generic_uprobe_process_event+0x2b70>
    2a10:      	ldrb	w8, [x23, #0x5]
    2a14:      	cmp	w8, #0x32
    2a18:      	b.gt	0x2a38 <generic_uprobe_process_event+0x2778>
    2a1c:      	cbz	w8, 0x2a58 <generic_uprobe_process_event+0x2798>
    2a20:      	cmp	w8, #0x2b
    2a24:      	b.eq	0x2a58 <generic_uprobe_process_event+0x2798>
    2a28:      	cmp	w8, #0x2c
    2a2c:      	b.ne	0x2b38 <generic_uprobe_process_event+0x2878>
    2a30:      	mov	w8, #0x8                // =8
    2a34:      	b	0x2a90 <generic_uprobe_process_event+0x27d0>
    2a38:      	cmp	w8, #0x33
    2a3c:      	b.eq	0x2a84 <generic_uprobe_process_event+0x27c4>
    2a40:      	cmp	w8, #0x3c
    2a44:      	b.eq	0x2a58 <generic_uprobe_process_event+0x2798>
    2a48:      	cmp	w8, #0xff
    2a4c:      	b.ne	0x2b38 <generic_uprobe_process_event+0x2878>
    2a50:      	mov	w8, #0x28               // =40
    2a54:      	b	0x2a90 <generic_uprobe_process_event+0x27d0>
    2a58:      	ldrb	w8, [x23, #0x7]
    2a5c:      	lsl	w8, w8, #3
    2a60:      	b	0x2a8c <generic_uprobe_process_event+0x27cc>
    2a64:      	ldrh	w8, [x23, #0x2]
    2a68:      	ldrh	w9, [x23]
    2a6c:      	ldrb	w25, [x23, #0x6]
    2a70:      	add	w8, w9, w8
    2a74:      	cmp	w25, #0x3c
    2a78:      	strh	w8, [x23]
    2a7c:      	b.ls	0x29d8 <generic_uprobe_process_event+0x2718>
    2a80:      	b	0x2fec <generic_uprobe_process_event+0x2d2c>
    2a84:      	ldrb	w8, [x23, #0x7]
    2a88:      	lsl	w8, w8, #2
    2a8c:      	add	w8, w8, #0x8
    2a90:      	strh	w8, [x23, #0x2]
    2a94:      	ldrh	w9, [x23]
    2a98:      	ldrb	w25, [x23, #0x6]
    2a9c:      	add	w8, w9, w8
    2aa0:      	cmp	w25, #0x3c
    2aa4:      	strh	w8, [x23]
    2aa8:      	b.hi	0x2fec <generic_uprobe_process_event+0x2d2c>
    2aac:      	mov	w9, #0x1                // =1
    2ab0:      	lsl	x9, x9, x25
    2ab4:      	tst	x9, x21
    2ab8:      	b.eq	0x2fec <generic_uprobe_process_event+0x2d2c>
    2abc:      	strb	w25, [x23, #0x5]
    2ac0:      	add	x8, x29, w8, uxth
    2ac4:      	mov	w9, #0x2                // =2
    2ac8:      	mov	w10, #0x4               // =4
    2acc:      	mov	x0, x22
    2ad0:      	mov	w1, #0x2                // =2
    2ad4:      	ldrh	w8, [x23]
    2ad8:      	add	x2, x29, x8
    2adc:      	blr	x10
    2ae0:      	tbnz	x0, #0x3f, 0x2e30 <generic_uprobe_process_event+0x2b70>
    2ae4:      	ldrb	w8, [x23, #0x5]
    2ae8:      	cmp	w8, #0x32
    2aec:      	b.gt	0x2b0c <generic_uprobe_process_event+0x284c>
    2af0:      	cbz	w8, 0x2b2c <generic_uprobe_process_event+0x286c>
    2af4:      	cmp	w8, #0x2b
    2af8:      	b.eq	0x2b2c <generic_uprobe_process_event+0x286c>
    2afc:      	cmp	w8, #0x2c
    2b00:      	b.ne	0x2c0c <generic_uprobe_process_event+0x294c>
    2b04:      	mov	w8, #0x8                // =8
    2b08:      	b	0x2b64 <generic_uprobe_process_event+0x28a4>
    2b0c:      	cmp	w8, #0x33
    2b10:      	b.eq	0x2b58 <generic_uprobe_process_event+0x2898>
    2b14:      	cmp	w8, #0x3c
    2b18:      	b.eq	0x2b2c <generic_uprobe_process_event+0x286c>
    2b1c:      	cmp	w8, #0xff
    2b20:      	b.ne	0x2c0c <generic_uprobe_process_event+0x294c>
    2b24:      	mov	w8, #0x28               // =40
    2b28:      	b	0x2b64 <generic_uprobe_process_event+0x28a4>
    2b2c:      	ldrb	w8, [x23, #0x7]
    2b30:      	lsl	w8, w8, #3
    2b34:      	b	0x2b60 <generic_uprobe_process_event+0x28a0>
    2b38:      	ldrh	w8, [x23, #0x2]
    2b3c:      	ldrh	w9, [x23]
    2b40:      	ldrb	w25, [x23, #0x6]
    2b44:      	add	w8, w9, w8
    2b48:      	cmp	w25, #0x3c
    2b4c:      	strh	w8, [x23]
    2b50:      	b.ls	0x2aac <generic_uprobe_process_event+0x27ec>
    2b54:      	b	0x2fec <generic_uprobe_process_event+0x2d2c>
    2b58:      	ldrb	w8, [x23, #0x7]
    2b5c:      	lsl	w8, w8, #2
    2b60:      	add	w8, w8, #0x8
    2b64:      	strh	w8, [x23, #0x2]
    2b68:      	ldrh	w9, [x23]
    2b6c:      	ldrb	w25, [x23, #0x6]
    2b70:      	add	w8, w9, w8
    2b74:      	cmp	w25, #0x3c
    2b78:      	strh	w8, [x23]
    2b7c:      	b.hi	0x2fec <generic_uprobe_process_event+0x2d2c>
    2b80:      	mov	w9, #0x1                // =1
    2b84:      	lsl	x9, x9, x25
    2b88:      	tst	x9, x21
    2b8c:      	b.eq	0x2fec <generic_uprobe_process_event+0x2d2c>
    2b90:      	strb	w25, [x23, #0x5]
    2b94:      	add	x8, x29, w8, uxth
    2b98:      	mov	w9, #0x2                // =2
    2b9c:      	mov	w10, #0x4               // =4
    2ba0:      	mov	x0, x22
    2ba4:      	mov	w1, #0x2                // =2
    2ba8:      	ldrh	w8, [x23]
    2bac:      	add	x2, x29, x8
    2bb0:      	blr	x10
    2bb4:      	tbnz	x0, #0x3f, 0x2e30 <generic_uprobe_process_event+0x2b70>
    2bb8:      	ldrb	w8, [x23, #0x5]
    2bbc:      	cmp	w8, #0x32
    2bc0:      	b.gt	0x2be0 <generic_uprobe_process_event+0x2920>
    2bc4:      	cbz	w8, 0x2c00 <generic_uprobe_process_event+0x2940>
    2bc8:      	cmp	w8, #0x2b
    2bcc:      	b.eq	0x2c00 <generic_uprobe_process_event+0x2940>
    2bd0:      	cmp	w8, #0x2c
    2bd4:      	b.ne	0x2ce0 <generic_uprobe_process_event+0x2a20>
    2bd8:      	mov	w8, #0x8                // =8
    2bdc:      	b	0x2c38 <generic_uprobe_process_event+0x2978>
    2be0:      	cmp	w8, #0x33
    2be4:      	b.eq	0x2c2c <generic_uprobe_process_event+0x296c>
    2be8:      	cmp	w8, #0x3c
    2bec:      	b.eq	0x2c00 <generic_uprobe_process_event+0x2940>
    2bf0:      	cmp	w8, #0xff
    2bf4:      	b.ne	0x2ce0 <generic_uprobe_process_event+0x2a20>
    2bf8:      	mov	w8, #0x28               // =40
    2bfc:      	b	0x2c38 <generic_uprobe_process_event+0x2978>
    2c00:      	ldrb	w8, [x23, #0x7]
    2c04:      	lsl	w8, w8, #3
    2c08:      	b	0x2c34 <generic_uprobe_process_event+0x2974>
    2c0c:      	ldrh	w8, [x23, #0x2]
    2c10:      	ldrh	w9, [x23]
    2c14:      	ldrb	w25, [x23, #0x6]
    2c18:      	add	w8, w9, w8
    2c1c:      	cmp	w25, #0x3c
    2c20:      	strh	w8, [x23]
    2c24:      	b.ls	0x2b80 <generic_uprobe_process_event+0x28c0>
    2c28:      	b	0x2fec <generic_uprobe_process_event+0x2d2c>
    2c2c:      	ldrb	w8, [x23, #0x7]
    2c30:      	lsl	w8, w8, #2
    2c34:      	add	w8, w8, #0x8
    2c38:      	strh	w8, [x23, #0x2]
    2c3c:      	ldrh	w9, [x23]
    2c40:      	ldrb	w25, [x23, #0x6]
    2c44:      	add	w8, w9, w8
    2c48:      	cmp	w25, #0x3c
    2c4c:      	strh	w8, [x23]
    2c50:      	b.hi	0x2fec <generic_uprobe_process_event+0x2d2c>
    2c54:      	mov	w9, #0x1                // =1
    2c58:      	lsl	x9, x9, x25
    2c5c:      	tst	x9, x21
    2c60:      	b.eq	0x2fec <generic_uprobe_process_event+0x2d2c>
    2c64:      	strb	w25, [x23, #0x5]
    2c68:      	add	x8, x29, w8, uxth
    2c6c:      	mov	w9, #0x2                // =2
    2c70:      	mov	w10, #0x4               // =4
    2c74:      	mov	x0, x22
    2c78:      	mov	w1, #0x2                // =2
    2c7c:      	ldrh	w8, [x23]
    2c80:      	add	x2, x29, x8
    2c84:      	blr	x10
    2c88:      	tbnz	x0, #0x3f, 0x2e30 <generic_uprobe_process_event+0x2b70>
    2c8c:      	ldrb	w8, [x23, #0x5]
    2c90:      	cmp	w8, #0x32
    2c94:      	b.gt	0x2cb4 <generic_uprobe_process_event+0x29f4>
    2c98:      	cbz	w8, 0x2cd4 <generic_uprobe_process_event+0x2a14>
    2c9c:      	cmp	w8, #0x2b
    2ca0:      	b.eq	0x2cd4 <generic_uprobe_process_event+0x2a14>
    2ca4:      	cmp	w8, #0x2c
    2ca8:      	b.ne	0x2db4 <generic_uprobe_process_event+0x2af4>
    2cac:      	mov	w8, #0x8                // =8
    2cb0:      	b	0x2d0c <generic_uprobe_process_event+0x2a4c>
    2cb4:      	cmp	w8, #0x33
    2cb8:      	b.eq	0x2d00 <generic_uprobe_process_event+0x2a40>
    2cbc:      	cmp	w8, #0x3c
    2cc0:      	b.eq	0x2cd4 <generic_uprobe_process_event+0x2a14>
    2cc4:      	cmp	w8, #0xff
    2cc8:      	b.ne	0x2db4 <generic_uprobe_process_event+0x2af4>
    2ccc:      	mov	w8, #0x28               // =40
    2cd0:      	b	0x2d0c <generic_uprobe_process_event+0x2a4c>
    2cd4:      	ldrb	w8, [x23, #0x7]
    2cd8:      	lsl	w8, w8, #3
    2cdc:      	b	0x2d08 <generic_uprobe_process_event+0x2a48>
    2ce0:      	ldrh	w8, [x23, #0x2]
    2ce4:      	ldrh	w9, [x23]
    2ce8:      	ldrb	w25, [x23, #0x6]
    2cec:      	add	w8, w9, w8
    2cf0:      	cmp	w25, #0x3c
    2cf4:      	strh	w8, [x23]
    2cf8:      	b.ls	0x2c54 <generic_uprobe_process_event+0x2994>
    2cfc:      	b	0x2fec <generic_uprobe_process_event+0x2d2c>
    2d00:      	ldrb	w8, [x23, #0x7]
    2d04:      	lsl	w8, w8, #2
    2d08:      	add	w8, w8, #0x8
    2d0c:      	strh	w8, [x23, #0x2]
    2d10:      	ldrh	w9, [x23]
    2d14:      	ldrb	w25, [x23, #0x6]
    2d18:      	add	w8, w9, w8
    2d1c:      	cmp	w25, #0x3c
    2d20:      	strh	w8, [x23]
    2d24:      	b.hi	0x2fec <generic_uprobe_process_event+0x2d2c>
    2d28:      	mov	w9, #0x1                // =1
    2d2c:      	lsl	x9, x9, x25
    2d30:      	tst	x9, x21
    2d34:      	b.eq	0x2fec <generic_uprobe_process_event+0x2d2c>
    2d38:      	strb	w25, [x23, #0x5]
    2d3c:      	add	x8, x29, w8, uxth
    2d40:      	mov	w9, #0x2                // =2
    2d44:      	mov	w10, #0x4               // =4
    2d48:      	mov	x0, x22
    2d4c:      	mov	w1, #0x2                // =2
    2d50:      	ldrh	w8, [x23]
    2d54:      	add	x2, x29, x8
    2d58:      	blr	x10
    2d5c:      	tbnz	x0, #0x3f, 0x2e30 <generic_uprobe_process_event+0x2b70>
    2d60:      	ldrb	w8, [x23, #0x5]
    2d64:      	cmp	w8, #0x32
    2d68:      	b.gt	0x2d88 <generic_uprobe_process_event+0x2ac8>
    2d6c:      	cbz	w8, 0x2da8 <generic_uprobe_process_event+0x2ae8>
    2d70:      	cmp	w8, #0x2b
    2d74:      	b.eq	0x2da8 <generic_uprobe_process_event+0x2ae8>
    2d78:      	cmp	w8, #0x2c
    2d7c:      	b.ne	0x2fd0 <generic_uprobe_process_event+0x2d10>
    2d80:      	mov	w8, #0x8                // =8
    2d84:      	b	0x2de0 <generic_uprobe_process_event+0x2b20>
    2d88:      	cmp	w8, #0x33
    2d8c:      	b.eq	0x2dd4 <generic_uprobe_process_event+0x2b14>
    2d90:      	cmp	w8, #0x3c
    2d94:      	b.eq	0x2da8 <generic_uprobe_process_event+0x2ae8>
    2d98:      	cmp	w8, #0xff
    2d9c:      	b.ne	0x2fd0 <generic_uprobe_process_event+0x2d10>
    2da0:      	mov	w8, #0x28               // =40
    2da4:      	b	0x2de0 <generic_uprobe_process_event+0x2b20>
    2da8:      	ldrb	w8, [x23, #0x7]
    2dac:      	lsl	w8, w8, #3
    2db0:      	b	0x2ddc <generic_uprobe_process_event+0x2b1c>
    2db4:      	ldrh	w8, [x23, #0x2]
    2db8:      	ldrh	w9, [x23]
    2dbc:      	ldrb	w25, [x23, #0x6]
    2dc0:      	add	w8, w9, w8
    2dc4:      	cmp	w25, #0x3c
    2dc8:      	strh	w8, [x23]
    2dcc:      	b.ls	0x2d28 <generic_uprobe_process_event+0x2a68>
    2dd0:      	b	0x2fec <generic_uprobe_process_event+0x2d2c>
    2dd4:      	ldrb	w8, [x23, #0x7]
    2dd8:      	lsl	w8, w8, #2
    2ddc:      	add	w8, w8, #0x8
    2de0:      	strh	w8, [x23, #0x2]
    2de4:      	ldrh	w9, [x23]
    2de8:      	ldrb	w25, [x23, #0x6]
    2dec:      	add	w8, w9, w8
    2df0:      	cmp	w25, #0x3c
    2df4:      	strh	w8, [x23]
    2df8:      	b.hi	0x2fec <generic_uprobe_process_event+0x2d2c>
    2dfc:      	mov	w9, #0x1                // =1
    2e00:      	lsl	x9, x9, x25
    2e04:      	tst	x9, x21
    2e08:      	b.eq	0x2fec <generic_uprobe_process_event+0x2d2c>
    2e0c:      	strb	w25, [x23, #0x5]
    2e10:      	add	x8, x29, w8, uxth
    2e14:      	mov	w9, #0x2                // =2
    2e18:      	mov	w10, #0x4               // =4
    2e1c:      	mov	x0, x22
    2e20:      	mov	w1, #0x2                // =2
    2e24:      	ldrh	w8, [x23]
    2e28:      	add	x2, x29, x8
    2e2c:      	blr	x10
    2e30:      	mov	w25, wzr
    2e34:      	ldr	x23, [sp, #0x28]
    2e38:      	mov	w8, #0xa                // =10
    2e3c:      	strb	w25, [sp, #0x84]
    2e40:      	add	x2, x19, #0x8
    2e44:      	mov	w21, #0x10              // =16
    2e48:      	mov	w1, #0x10               // =16
    2e4c:      	mov	w22, #0x4               // =4
    2e50:      	strh	w25, [x23, #0x24]
    2e54:      	strh	w8, [x23, #0x26]
    2e58:      	mov	w8, #0x4                // =4
    2e5c:      	mov	x0, x23
    2e60:      	blr	x8
    2e64:      	add	x0, x23, #0x10
    2e68:      	add	x2, x19, #0x18
    2e6c:      	mov	w1, #0x10               // =16
    2e70:      	blr	x22
    2e74:      	cmp	w25, #0x11
    2e78:      	b.eq	0x2ebc <generic_uprobe_process_event+0x2bfc>
    2e7c:      	cmp	w25, #0x6
    2e80:      	b.ne	0x2efc <generic_uprobe_process_event+0x2c3c>
    2e84:      	ldr	x8, [sp, #0x98]
    2e88:      	ldrh	w9, [sp, #0x88]
    2e8c:      	mov	w21, #0x2               // =2
    2e90:      	mov	w1, #0x2                // =2
    2e94:      	mov	w23, #0x4               // =4
    2e98:      	add	x22, x8, x9
    2e9c:      	ldr	x25, [sp, #0x28]
    2ea0:      	add	x0, x25, #0x20
    2ea4:      	mov	w8, #0x4                // =4
    2ea8:      	mov	x2, x22
    2eac:      	blr	x8
    2eb0:      	add	x0, x25, #0x22
    2eb4:      	add	x2, x22, #0x2
    2eb8:      	b	0x2ef0 <generic_uprobe_process_event+0x2c30>
    2ebc:      	ldr	x8, [sp, #0x98]
    2ec0:      	ldrh	w9, [sp, #0x88]
    2ec4:      	mov	w21, #0x2               // =2
    2ec8:      	mov	w1, #0x2                // =2
    2ecc:      	mov	w23, #0x4               // =4
    2ed0:      	add	x22, x8, x9
    2ed4:      	ldr	x25, [sp, #0x28]
    2ed8:      	add	x0, x25, #0x20
    2edc:      	mov	w8, #0x4                // =4
    2ee0:      	mov	x2, x22
    2ee4:      	blr	x8
    2ee8:      	add	x0, x25, #0x22
    2eec:      	add	x2, x22, #0x2
    2ef0:      	mov	w1, #0x2                // =2
    2ef4:      	blr	x23
    2ef8:      	b	0x2f04 <generic_uprobe_process_event+0x2c44>
    2efc:      	ldr	x8, [sp, #0x28]
    2f00:      	str	wzr, [x8, #0x20]
    2f04:      	ldr	x9, [sp, #0x28]
    2f08:      	add	x2, x24, #0xe0
    2f0c:      	add	x10, sp, #0xf0
    2f10:      	add	x0, sp, #0xf0
    2f14:      	ldrh	w8, [x9, #0x20]
    2f18:      	mov	w1, #0x8                // =8
    2f1c:      	rev	w8, w8
    2f20:      	lsr	w8, w8, #16
    2f24:      	strh	w8, [x9, #0x20]
    2f28:      	ldrh	w8, [x9, #0x22]
    2f2c:      	rev	w8, w8
    2f30:      	lsr	w8, w8, #16
    2f34:      	strh	w8, [x9, #0x22]
    2f38:      	mov	w8, #0x8                // =8
    2f3c:      	mov	w9, #0x4                // =4
    2f40:      	blr	x9
    2f44:      	add	x8, sp, #0xe0
    2f48:      	ldr	x8, [x8, #0x10]
    2f4c:      	cbz	x8, 0x2fb0 <generic_uprobe_process_event+0x2cf0>
    2f50:      	add	x8, x8, #0x5
    2f54:      	mov	w9, #0x8                // =8
    2f58:      	add	x10, sp, #0x100
    2f5c:      	mov	w11, #0x4               // =4
    2f60:      	add	x19, sp, #0xe0
    2f64:      	ldr	x8, [x19, #0x10]
    2f68:      	add	x0, sp, #0x100
    2f6c:      	mov	w1, #0x8                // =8
    2f70:      	mov	w21, #0x4               // =4
    2f74:      	add	x2, x8, #0x5
    2f78:      	blr	x11
    2f7c:      	ldr	x8, [x19, #0x10]
    2f80:      	ldr	x9, [x19, #0x20]
    2f84:      	mov	w1, #0x4                // =4
    2f88:      	add	x22, x8, x9, lsl #3
    2f8c:      	ldr	x23, [sp, #0x28]
    2f90:      	add	x0, x23, #0x38
    2f94:      	mov	w8, #0x4                // =4
    2f98:      	add	x2, x22, #0x44
    2f9c:      	blr	x8
    2fa0:      	add	x0, x23, #0x3c
    2fa4:      	add	x2, x22, #0x45
    2fa8:      	mov	w1, #0x4                // =4
    2fac:      	blr	x21
    2fb0:      	mov	w22, #0x40              // =64
    2fb4:      	adrp	x25, 0x2000 <generic_uprobe_process_event+0x1d40>
    2fb8:      	mov	w21, #0x5efc            // =24316
    2fbc:      	mov	w10, #0x5ea0            // =24224
    2fc0:      	ldr	x25, [x25]
    2fc4:      	ldr	x11, [sp, #0x30]
    2fc8:      	ldp	x23, x19, [sp, #0x48]
    2fcc:      	b	0x22c8 <generic_uprobe_process_event+0x2008>
    2fd0:      	ldrh	w8, [x23, #0x2]
    2fd4:      	ldrh	w9, [x23]
    2fd8:      	ldrb	w25, [x23, #0x6]
    2fdc:      	add	w8, w9, w8
    2fe0:      	cmp	w25, #0x3c
    2fe4:      	strh	w8, [x23]
    2fe8:      	b.ls	0x2dfc <generic_uprobe_process_event+0x2b3c>
    2fec:      	strh	w8, [sp, #0x88]
    2ff0:      	b	0x2e34 <generic_uprobe_process_event+0x2b74>
    2ff4:      	nop
    2ff8:      	nop
    2ffc:      	nop

0000000000003000 <generic_uprobe_process_filter>:
    3000:      	sub	sp, sp, #0x130
    3004:      	str	x29, [sp, #0xe0]
    3008:      	stp	x30, x25, [sp, #0xf0]
    300c:      	stp	x24, x23, [sp, #0x100]
    3010:      	stp	x22, x21, [sp, #0x110]
    3014:      	stp	x20, x19, [sp, #0x120]
    3018:      	mov	x20, x0
    301c:      	str	wzr, [sp, #0x54]
    3020:      	adrp	x0, 0x3000 <generic_uprobe_process_filter>
    3024:      	mov	w8, #0x1                // =1
    3028:      	ldr	x0, [x0]
    302c:      	add	x9, sp, #0x54
    3030:      	add	x1, sp, #0x54
    3034:      	blr	x8
    3038:      	cbz	x0, 0x532c <generic_uprobe_process_filter+0x232c>
    303c:      	mov	w8, #0x5ec0             // =24256
    3040:      	mov	x22, x0
    3044:      	add	x29, x0, x8
    3048:      	mov	w8, #0x23               // =35
    304c:      	blr	x8
    3050:      	str	x0, [sp, #0x58]
    3054:      	add	x8, x0, #0x8d4
    3058:      	mov	w9, #0x4                // =4
    305c:      	mov	w10, #0x71              // =113
    3060:      	add	x11, sp, #0xd8
    3064:      	add	x0, sp, #0xd8
    3068:      	mov	w1, #0x4                // =4
    306c:      	ldr	x8, [sp, #0x58]
    3070:      	add	x2, x8, #0x8d4
    3074:      	blr	x10
    3078:      	ldr	w8, [sp, #0xd8]
    307c:      	adrp	x19, 0x3000 <generic_uprobe_process_filter>
    3080:      	add	x9, sp, #0xc8
    3084:      	add	x1, sp, #0xc8
    3088:      	str	w8, [sp, #0xc8]
    308c:      	mov	w8, #0x1                // =1
    3090:      	ldr	x19, [x19]
    3094:      	mov	x0, x19
    3098:      	blr	x8
    309c:      	cbz	x0, 0x30ac <generic_uprobe_process_filter+0xac>
    30a0:      	ldr	x8, [x0, #0x8]
    30a4:      	mov	x24, x0
    30a8:      	cbnz	x8, 0x3e8c <generic_uprobe_process_filter+0xe8c>
    30ac:      	ldr	x8, [sp, #0x58]
    30b0:      	mov	w9, #0x8                // =8
    30b4:      	mov	w10, #0x71              // =113
    30b8:      	add	x11, sp, #0x58
    30bc:      	add	x0, sp, #0x58
    30c0:      	mov	w1, #0x8                // =8
    30c4:      	add	x8, x8, #0x8e0
    30c8:      	ldr	x8, [sp, #0x58]
    30cc:      	add	x2, x8, #0x8e0
    30d0:      	blr	x10
    30d4:      	ldr	x8, [sp, #0x58]
    30d8:      	cbz	x8, 0x3254 <generic_uprobe_process_filter+0x254>
    30dc:      	add	x8, x8, #0x8d4
    30e0:      	mov	w9, #0x4                // =4
    30e4:      	mov	w10, #0x71              // =113
    30e8:      	add	x11, sp, #0xd8
    30ec:      	ldr	x8, [sp, #0x58]
    30f0:      	add	x0, sp, #0xd8
    30f4:      	mov	w1, #0x4                // =4
    30f8:      	add	x2, x8, #0x8d4
    30fc:      	blr	x10
    3100:      	ldr	w8, [sp, #0xd8]
    3104:      	add	x9, sp, #0xc8
    3108:      	add	x1, sp, #0xc8
    310c:      	mov	x0, x19
    3110:      	str	w8, [sp, #0xc8]
    3114:      	mov	w8, #0x1                // =1
    3118:      	blr	x8
    311c:      	cbz	x0, 0x312c <generic_uprobe_process_filter+0x12c>
    3120:      	ldr	x8, [x0, #0x8]
    3124:      	mov	x24, x0
    3128:      	cbnz	x8, 0x3e8c <generic_uprobe_process_filter+0xe8c>
    312c:      	ldr	x8, [sp, #0x58]
    3130:      	mov	w9, #0x8                // =8
    3134:      	mov	w10, #0x71              // =113
    3138:      	add	x11, sp, #0x58
    313c:      	add	x0, sp, #0x58
    3140:      	mov	w1, #0x8                // =8
    3144:      	add	x8, x8, #0x8e0
    3148:      	ldr	x8, [sp, #0x58]
    314c:      	add	x2, x8, #0x8e0
    3150:      	blr	x10
    3154:      	ldr	x8, [sp, #0x58]
    3158:      	cbz	x8, 0x3254 <generic_uprobe_process_filter+0x254>
    315c:      	add	x8, x8, #0x8d4
    3160:      	mov	w9, #0x4                // =4
    3164:      	mov	w10, #0x71              // =113
    3168:      	add	x11, sp, #0xd8
    316c:      	ldr	x8, [sp, #0x58]
    3170:      	add	x0, sp, #0xd8
    3174:      	mov	w1, #0x4                // =4
    3178:      	add	x2, x8, #0x8d4
    317c:      	blr	x10
    3180:      	ldr	w8, [sp, #0xd8]
    3184:      	add	x9, sp, #0xc8
    3188:      	add	x1, sp, #0xc8
    318c:      	mov	x0, x19
    3190:      	str	w8, [sp, #0xc8]
    3194:      	mov	w8, #0x1                // =1
    3198:      	blr	x8
    319c:      	cbz	x0, 0x31ac <generic_uprobe_process_filter+0x1ac>
    31a0:      	ldr	x8, [x0, #0x8]
    31a4:      	mov	x24, x0
    31a8:      	cbnz	x8, 0x3e8c <generic_uprobe_process_filter+0xe8c>
    31ac:      	ldr	x8, [sp, #0x58]
    31b0:      	mov	w9, #0x8                // =8
    31b4:      	mov	w10, #0x71              // =113
    31b8:      	add	x11, sp, #0x58
    31bc:      	add	x0, sp, #0x58
    31c0:      	mov	w1, #0x8                // =8
    31c4:      	add	x8, x8, #0x8e0
    31c8:      	ldr	x8, [sp, #0x58]
    31cc:      	add	x2, x8, #0x8e0
    31d0:      	blr	x10
    31d4:      	ldr	x8, [sp, #0x58]
    31d8:      	cbz	x8, 0x3254 <generic_uprobe_process_filter+0x254>
    31dc:      	add	x8, x8, #0x8d4
    31e0:      	mov	w9, #0x4                // =4
    31e4:      	mov	w10, #0x71              // =113
    31e8:      	add	x11, sp, #0xd8
    31ec:      	ldr	x8, [sp, #0x58]
    31f0:      	add	x0, sp, #0xd8
    31f4:      	mov	w1, #0x4                // =4
    31f8:      	add	x2, x8, #0x8d4
    31fc:      	blr	x10
    3200:      	ldr	w8, [sp, #0xd8]
    3204:      	add	x9, sp, #0xc8
    3208:      	add	x1, sp, #0xc8
    320c:      	mov	x0, x19
    3210:      	str	w8, [sp, #0xc8]
    3214:      	mov	w8, #0x1                // =1
    3218:      	blr	x8
    321c:      	cbz	x0, 0x322c <generic_uprobe_process_filter+0x22c>
    3220:      	ldr	x8, [x0, #0x8]
    3224:      	mov	x24, x0
    3228:      	cbnz	x8, 0x3e8c <generic_uprobe_process_filter+0xe8c>
    322c:      	ldr	x8, [sp, #0x58]
    3230:      	mov	w9, #0x8                // =8
    3234:      	mov	w10, #0x71              // =113
    3238:      	add	x11, sp, #0x58
    323c:      	add	x0, sp, #0x58
    3240:      	mov	w1, #0x8                // =8
    3244:      	add	x8, x8, #0x8e0
    3248:      	ldr	x8, [sp, #0x58]
    324c:      	add	x2, x8, #0x8e0
    3250:      	blr	x10
    3254:      	str	x20, [sp, #0x38]
    3258:      	mov	w8, #0x23               // =35
    325c:      	blr	x8
    3260:      	add	x2, x0, #0x8d4
    3264:      	mov	w8, #0x4                // =4
    3268:      	add	x9, sp, #0x58
    326c:      	mov	x24, x0
    3270:      	add	x0, sp, #0x58
    3274:      	mov	w1, #0x4                // =4
    3278:      	blr	x8
    327c:      	ldr	w8, [sp, #0x58]
    3280:      	mov	x19, x29
    3284:      	str	w8, [x19, #0x50]!
    3288:      	mov	w8, #0x7d               // =125
    328c:      	blr	x8
    3290:      	str	x0, [x22, #0x5f18]
    3294:      	str	wzr, [x19, #0x10]
    3298:      	add	x2, x24, #0x60
    329c:      	mov	w8, #0x8                // =8
    32a0:      	mov	w9, #0x71               // =113
    32a4:      	add	x10, sp, #0xc8
    32a8:      	str	xzr, [x22, #0x5f28]
    32ac:      	str	x19, [sp, #0x48]
    32b0:      	add	x0, sp, #0xc8
    32b4:      	mov	w1, #0x8                // =8
    32b8:      	str	wzr, [x19, #0x20]
    32bc:      	blr	x9
    32c0:      	ldr	x8, [sp, #0xc8]
    32c4:      	cbz	x8, 0x3334 <generic_uprobe_process_filter+0x334>
    32c8:      	add	x8, x8, #0x4
    32cc:      	mov	w9, #0x4                // =4
    32d0:      	mov	w10, #0x71              // =113
    32d4:      	add	x11, sp, #0xd8
    32d8:      	ldr	x8, [sp, #0xc8]
    32dc:      	add	x0, sp, #0xd8
    32e0:      	mov	w1, #0x4                // =4
    32e4:      	add	x2, x8, #0x4
    32e8:      	blr	x10
    32ec:      	ldr	w8, [sp, #0xd8]
    32f0:      	cbz	w8, 0x3334 <generic_uprobe_process_filter+0x334>
    32f4:      	ldr	x9, [sp, #0xc8]
    32f8:      	lsl	w8, w8, #4
    32fc:      	mov	w10, #0x71              // =113
    3300:      	add	x11, sp, #0x58
    3304:      	add	x0, sp, #0x58
    3308:      	mov	w1, #0x10               // =16
    330c:      	add	x8, x9, x8
    3310:      	mov	w9, #0x10               // =16
    3314:      	add	x8, x8, #0x80
    3318:      	ldr	w9, [sp, #0xd8]
    331c:      	ldr	x8, [sp, #0xc8]
    3320:      	lsl	w9, w9, #4
    3324:      	add	x8, x8, x9
    3328:      	add	x2, x8, #0x80
    332c:      	blr	x10
    3330:      	ldr	w8, [sp, #0x58]
    3334:      	str	w8, [x29, #0x74]
    3338:      	mov	w8, #0x5f60             // =24416
    333c:      	str	x22, [sp, #0xe8]
    3340:      	add	x23, x24, #0xae0
    3344:      	mov	w19, #0x8               // =8
    3348:      	add	x25, x22, x8
    334c:      	add	x8, sp, #0x58
    3350:      	mov	w9, #0x4                // =4
    3354:      	add	x0, sp, #0x58
    3358:      	mov	w1, #0x8                // =8
    335c:      	mov	x2, x23
    3360:      	mov	w21, #0x4               // =4
    3364:      	blr	x9
    3368:      	ldr	x20, [sp, #0x58]
    336c:      	ldr	x9, [sp, #0xe8]
    3370:      	mov	w8, #0x5f68             // =24424
    3374:      	mov	w1, #0x8                // =8
    3378:      	add	x0, x9, x8
    337c:      	add	x2, x20, #0x40
    3380:      	mov	w8, #0x4                // =4
    3384:      	blr	x8
    3388:      	ldr	x9, [sp, #0xe8]
    338c:      	mov	w8, #0x5f70             // =24432
    3390:      	add	x2, x20, #0x30
    3394:      	mov	w1, #0x8                // =8
    3398:      	add	x0, x9, x8
    339c:      	mov	w8, #0x4                // =4
    33a0:      	blr	x8
    33a4:      	add	x2, x20, #0x38
    33a8:      	mov	w8, #0x4                // =4
    33ac:      	mov	x0, x25
    33b0:      	mov	w1, #0x8                // =8
    33b4:      	blr	x8
    33b8:      	ldr	x9, [sp, #0xe8]
    33bc:      	mov	w8, #0x5f38             // =24376
    33c0:      	add	x2, x24, #0xb50
    33c4:      	add	x0, sp, #0xd8
    33c8:      	mov	w1, #0x8                // =8
    33cc:      	add	x25, x9, x8
    33d0:      	add	x8, sp, #0xd8
    33d4:      	mov	w9, #0x4                // =4
    33d8:      	blr	x9
    33dc:      	add	x12, sp, #0xd8
    33e0:      	mov	w9, #0x48               // =72
    33e4:      	add	x10, sp, #0x58
    33e8:      	ldr	x8, [x12]
    33ec:      	mov	w11, #0x4               // =4
    33f0:      	add	x0, sp, #0x58
    33f4:      	mov	w1, #0x48               // =72
    33f8:      	ldr	x2, [x12]
    33fc:      	blr	x11
    3400:      	ldr	x8, [sp, #0x60]
    3404:      	mov	w9, #0x4                // =4
    3408:      	mov	x0, x25
    340c:      	mov	w1, #0x4                // =4
    3410:      	add	x8, x8, #0x218
    3414:      	ldr	x8, [sp, #0x60]
    3418:      	ldr	x22, [sp, #0xe8]
    341c:      	add	x2, x8, #0x218
    3420:      	blr	x9
    3424:      	mov	w8, #0x5f3c             // =24380
    3428:      	mov	w9, #0x4                // =4
    342c:      	mov	w1, #0x4                // =4
    3430:      	add	x0, x22, x8
    3434:      	ldr	x8, [sp, #0x68]
    3438:      	add	x8, x8, #0x4d8
    343c:      	ldr	x8, [sp, #0x68]
    3440:      	add	x2, x8, #0x4d8
    3444:      	blr	x9
    3448:      	mov	w8, #0x5f40             // =24384
    344c:      	mov	w9, #0x4                // =4
    3450:      	mov	w1, #0x4                // =4
    3454:      	add	x0, x22, x8
    3458:      	ldr	x8, [sp, #0x70]
    345c:      	add	x8, x8, #0x58
    3460:      	ldr	x8, [sp, #0x70]
    3464:      	add	x2, x8, #0x58
    3468:      	blr	x9
    346c:      	str	xzr, [sp, #0xc0]
    3470:      	add	x2, x24, #0x938
    3474:      	add	x8, sp, #0xc0
    3478:      	add	x0, sp, #0xc0
    347c:      	mov	w1, #0x8                // =8
    3480:      	blr	x21
    3484:      	ldr	x8, [sp, #0xc0]
    3488:      	cbz	x8, 0x3510 <generic_uprobe_process_filter+0x510>
    348c:      	str	wzr, [sp, #0xb8]
    3490:      	add	x8, x8, #0x4
    3494:      	add	x9, sp, #0xb8
    3498:      	mov	w10, #0x4               // =4
    349c:      	add	x0, sp, #0xb8
    34a0:      	mov	w1, #0x4                // =4
    34a4:      	mov	w19, #0x4               // =4
    34a8:      	ldr	x8, [sp, #0xc0]
    34ac:      	add	x2, x8, #0x4
    34b0:      	blr	x10
    34b4:      	ldr	x8, [sp, #0xc0]
    34b8:      	ldrsw	x9, [sp, #0xb8]
    34bc:      	add	x10, sp, #0xc8
    34c0:      	mov	w11, #0x4               // =4
    34c4:      	add	x0, sp, #0xc8
    34c8:      	mov	w1, #0x10               // =16
    34cc:      	add	x8, x8, x9, lsl #4
    34d0:      	mov	w9, #0x10               // =16
    34d4:      	add	x8, x8, #0x80
    34d8:      	ldr	x8, [sp, #0xc0]
    34dc:      	ldrsw	x9, [sp, #0xb8]
    34e0:      	add	x8, x8, x9, lsl #4
    34e4:      	add	x2, x8, #0x80
    34e8:      	blr	x11
    34ec:      	mov	w8, #0x5f44             // =24388
    34f0:      	mov	w1, #0x4                // =4
    34f4:      	add	x0, x22, x8
    34f8:      	ldr	x8, [sp, #0xd0]
    34fc:      	add	x8, x8, #0x158
    3500:      	ldr	x8, [sp, #0xd0]
    3504:      	add	x2, x8, #0x158
    3508:      	blr	x19
    350c:      	b	0x3514 <generic_uprobe_process_filter+0x514>
    3510:      	str	wzr, [x29, #0x84]
    3514:      	mov	w8, #0x5f48             // =24392
    3518:      	mov	w9, #0x4                // =4
    351c:      	mov	w1, #0x4                // =4
    3520:      	mov	w19, #0x4               // =4
    3524:      	add	x0, x22, x8
    3528:      	ldr	x8, [sp, #0x78]
    352c:      	add	x8, x8, #0x158
    3530:      	ldr	x8, [sp, #0x78]
    3534:      	add	x2, x8, #0x158
    3538:      	blr	x9
    353c:      	mov	w8, #0x5f4c             // =24396
    3540:      	mov	w9, #0x4                // =4
    3544:      	mov	w1, #0x4                // =4
    3548:      	add	x0, x22, x8
    354c:      	ldr	x8, [sp, #0x80]
    3550:      	add	x8, x8, #0x118
    3554:      	ldr	x8, [sp, #0x80]
    3558:      	add	x2, x8, #0x118
    355c:      	blr	x9
    3560:      	mov	w8, #0x5f50             // =24400
    3564:      	mov	w9, #0x4                // =4
    3568:      	mov	w1, #0x4                // =4
    356c:      	add	x0, x22, x8
    3570:      	ldr	x8, [sp, #0x88]
    3574:      	add	x8, x8, #0x98
    3578:      	ldr	x8, [sp, #0x88]
    357c:      	add	x2, x8, #0x98
    3580:      	blr	x9
    3584:      	mov	w8, #0x5f54             // =24404
    3588:      	mov	w9, #0x4                // =4
    358c:      	mov	w1, #0x4                // =4
    3590:      	add	x0, x22, x8
    3594:      	ldr	x8, [sp, #0x90]
    3598:      	add	x8, x8, #0x98
    359c:      	ldr	x8, [sp, #0x90]
    35a0:      	add	x2, x8, #0x98
    35a4:      	blr	x9
    35a8:      	mov	w8, #0x5f58             // =24408
    35ac:      	mov	w9, #0x4                // =4
    35b0:      	mov	w1, #0x4                // =4
    35b4:      	add	x0, x22, x8
    35b8:      	ldr	x8, [sp, #0x98]
    35bc:      	add	x8, x8, #0x58
    35c0:      	ldr	x8, [sp, #0x98]
    35c4:      	add	x2, x8, #0x58
    35c8:      	blr	x9
    35cc:      	stp	xzr, xzr, [sp, #0xc0]
    35d0:      	mov	w20, #0x8               // =8
    35d4:      	add	x8, sp, #0xc8
    35d8:      	mov	w9, #0x4                // =4
    35dc:      	add	x0, sp, #0xc8
    35e0:      	mov	w1, #0x8                // =8
    35e4:      	mov	x2, x23
    35e8:      	blr	x9
    35ec:      	ldr	x8, [sp, #0xc8]
    35f0:      	add	x9, sp, #0xc0
    35f4:      	mov	w10, #0x4               // =4
    35f8:      	add	x0, sp, #0xc0
    35fc:      	mov	w1, #0x8                // =8
    3600:      	add	x8, x8, #0x90
    3604:      	ldr	x8, [sp, #0xc8]
    3608:      	add	x2, x8, #0x90
    360c:      	blr	x10
    3610:      	mov	w8, #0x5f5c             // =24412
    3614:      	mov	w1, #0x4                // =4
    3618:      	add	x0, x22, x8
    361c:      	ldr	x8, [sp, #0xc0]
    3620:      	add	x8, x8, #0x158
    3624:      	ldr	x8, [sp, #0xc0]
    3628:      	add	x2, x8, #0x158
    362c:      	blr	x19
    3630:      	ldr	w8, [x29, #0x74]
    3634:      	cmp	w8, #0x1
    3638:      	b.ne	0x3648 <generic_uprobe_process_filter+0x648>
    363c:      	ldr	w8, [x29, #0x70]
    3640:      	orr	w8, w8, #0x2000000
    3644:      	str	w8, [x29, #0x70]
    3648:      	add	x0, x29, #0xb8
    364c:      	mov	w1, wzr
    3650:      	mov	w2, #0x308              // =776
    3654:      	bl	0x3654 <generic_uprobe_process_filter+0x654>
    3658:      	mov	w8, #0x6290             // =25232
    365c:      	add	x2, x24, #0x858
    3660:      	mov	w19, #0x8               // =8
    3664:      	mov	w9, #0x4                // =4
    3668:      	add	x0, sp, #0xc8
    366c:      	mov	w1, #0x8                // =8
    3670:      	mov	w20, #0x4               // =4
    3674:      	add	x21, x22, x8
    3678:      	add	x8, sp, #0xc8
    367c:      	blr	x9
    3680:      	ldr	x8, [sp, #0xc8]
    3684:      	add	x9, sp, #0x58
    3688:      	add	x0, sp, #0x58
    368c:      	mov	w1, #0x8                // =8
    3690:      	add	x8, x8, #0x528
    3694:      	ldr	x8, [sp, #0xc8]
    3698:      	add	x2, x8, #0x528
    369c:      	blr	x20
    36a0:      	str	wzr, [sp, #0xa4]
    36a4:      	adrp	x0, 0x3000 <generic_uprobe_process_filter>
    36a8:      	ldr	x19, [sp, #0x58]
    36ac:      	mov	w8, #0x1                // =1
    36b0:      	add	x9, sp, #0xa4
    36b4:      	add	x1, sp, #0xa4
    36b8:      	ldr	x0, [x0]
    36bc:      	blr	x8
    36c0:      	cbz	x0, 0x3cd4 <generic_uprobe_process_filter+0xcd4>
    36c4:      	mov	w8, #0x1000             // =4096
    36c8:      	str	x21, [sp, #0x30]
    36cc:      	str	x29, [sp, #0x40]
    36d0:      	mov	x24, x0
    36d4:      	add	x20, x0, #0x1, lsl #12  // =0x1000
    36d8:      	str	w8, [x29, #0x550]
    36dc:      	mov	w8, #0x23               // =35
    36e0:      	blr	x8
    36e4:      	add	x2, x0, #0xb30
    36e8:      	mov	w23, #0x8               // =8
    36ec:      	add	x8, sp, #0xa8
    36f0:      	mov	w9, #0x4                // =4
    36f4:      	add	x0, sp, #0xa8
    36f8:      	mov	w1, #0x8                // =8
    36fc:      	mov	w29, #0x4               // =4
    3700:      	blr	x9
    3704:      	ldr	x22, [sp, #0xa8]
    3708:      	add	x25, x19, #0x48
    370c:      	add	x8, sp, #0xb0
    3710:      	mov	w9, #0x4                // =4
    3714:      	add	x0, sp, #0xb0
    3718:      	mov	w1, #0x8                // =8
    371c:      	mov	x2, x25
    3720:      	blr	x9
    3724:      	ldr	x21, [sp, #0xb0]
    3728:      	add	x8, sp, #0x58
    372c:      	add	x0, sp, #0x58
    3730:      	mov	w1, #0x8                // =8
    3734:      	add	x2, x21, #0x10
    3738:      	blr	x29
    373c:      	ldr	x8, [sp, #0x58]
    3740:      	cbz	x8, 0x3974 <generic_uprobe_process_filter+0x974>
    3744:      	ldr	x8, [sp, #0x40]
    3748:      	stp	xzr, xzr, [sp, #0x58]
    374c:      	add	x21, x22, #0x18
    3750:      	add	x9, sp, #0x58
    3754:      	add	x2, x22, #0x20
    3758:      	mov	w22, #0x8               // =8
    375c:      	stp	x24, xzr, [sp, #0x68]
    3760:      	add	x0, sp, #0x58
    3764:      	mov	w1, #0x8                // =8
    3768:      	add	x29, x19, #0x40
    376c:      	add	x19, x9, #0x8
    3770:      	add	x24, x9, #0x18
    3774:      	stp	xzr, xzr, [sp, #0x78]
    3778:      	add	x23, x9, #0x20
    377c:      	str	x20, [sp, #0x88]
    3780:      	str	x20, [sp, #0x28]
    3784:      	mov	w20, #0x4               // =4
    3788:      	ldr	w8, [x8, #0x550]
    378c:      	strb	wzr, [sp, #0x94]
    3790:      	str	w8, [sp, #0x90]
    3794:      	mov	w8, #0x4                // =4
    3798:      	blr	x8
    379c:      	mov	w8, #0x4                // =4
    37a0:      	mov	x0, x19
    37a4:      	mov	w1, #0x8                // =8
    37a8:      	mov	x2, x21
    37ac:      	blr	x8
    37b0:      	mov	w8, #0x4                // =4
    37b4:      	mov	x0, x24
    37b8:      	mov	w1, #0x8                // =8
    37bc:      	mov	x2, x25
    37c0:      	blr	x8
    37c4:      	mov	x0, x23
    37c8:      	mov	w1, #0x8                // =8
    37cc:      	mov	x2, x29
    37d0:      	blr	x20
    37d4:      	ldr	x8, [sp, #0x78]
    37d8:      	sub	x8, x8, #0x20
    37dc:      	str	x8, [sp, #0x80]
    37e0:      	adrp	x8, 0x3000 <generic_uprobe_process_filter>
    37e4:      	ldr	x8, [x8]
    37e8:      	ldrb	w8, [x8]
    37ec:      	cbz	w8, 0x39c8 <generic_uprobe_process_filter+0x9c8>
    37f0:      	mov	w19, #0x800             // =2048
    37f4:      	mov	w21, #0x8               // =8
    37f8:      	add	x23, sp, #0xb8
    37fc:      	add	x29, sp, #0xd8
    3800:      	b	0x3854 <generic_uprobe_process_filter+0x854>
    3804:      	add	x2, x22, #0x10
    3808:      	mov	w8, #0x4                // =4
    380c:      	add	x0, sp, #0xd8
    3810:      	mov	w1, #0x8                // =8
    3814:      	blr	x8
    3818:      	add	x20, sp, #0xd8
    381c:      	ldr	x8, [sp, #0x80]
    3820:      	ldr	x9, [x20]
    3824:      	cmp	x8, x9
    3828:      	b.eq	0x3b50 <generic_uprobe_process_filter+0xb50>
    382c:      	add	x2, x22, #0x18
    3830:      	mov	w8, #0x4                // =4
    3834:      	mov	x0, x24
    3838:      	mov	w1, #0x8                // =8
    383c:      	blr	x8
    3840:      	ldr	x8, [x20]
    3844:      	add	x9, x8, #0x20
    3848:      	stp	x9, x8, [sp, #0x78]
    384c:      	subs	w19, w19, #0x1
    3850:      	b.eq	0x3b58 <generic_uprobe_process_filter+0xb58>
    3854:      	ldp	x20, x2, [sp, #0x70]
    3858:      	ldp	x8, x9, [sp, #0x58]
    385c:      	cmp	x20, x8
    3860:      	ccmp	x2, x9, #0x0, eq
    3864:      	b.eq	0x3b50 <generic_uprobe_process_filter+0xb50>
    3868:      	ldr	x22, [sp, #0x80]
    386c:      	mov	w8, #0x4                // =4
    3870:      	add	x0, sp, #0xb8
    3874:      	mov	w1, #0x8                // =8
    3878:      	blr	x8
    387c:      	ldr	x8, [sp, #0xb8]
    3880:      	cmp	x20, x8
    3884:      	b.eq	0x3804 <generic_uprobe_process_filter+0x804>
    3888:      	add	x25, x20, #0x18
    388c:      	mov	w8, #0x4                // =4
    3890:      	add	x0, sp, #0xd8
    3894:      	mov	w1, #0x8                // =8
    3898:      	mov	x2, x25
    389c:      	blr	x8
    38a0:      	add	x8, sp, #0xd8
    38a4:      	ldr	x8, [x8]
    38a8:      	cmp	x8, x20
    38ac:      	b.eq	0x3804 <generic_uprobe_process_filter+0x804>
    38b0:      	mov	w8, #0x4                // =4
    38b4:      	add	x9, sp, #0xc0
    38b8:      	add	x0, sp, #0xc0
    38bc:      	mov	w1, #0x8                // =8
    38c0:      	mov	x2, x25
    38c4:      	blr	x8
    38c8:      	add	x2, x20, #0x20
    38cc:      	mov	w8, #0x4                // =4
    38d0:      	mov	w9, #0x10               // =16
    38d4:      	add	x10, sp, #0xc8
    38d8:      	add	x0, sp, #0xc8
    38dc:      	mov	w1, #0x10               // =16
    38e0:      	blr	x8
    38e4:      	ldr	w20, [sp, #0xcc]
    38e8:      	ldr	x8, [sp, #0x68]
    38ec:      	ldr	x10, [sp, #0x88]
    38f0:      	sub	x12, x10, x8
    38f4:      	ldr	w22, [sp, #0x90]
    38f8:      	subs	w10, w20, w22
    38fc:      	ldr	x9, [sp, #0xd0]
    3900:      	csel	w10, wzr, w10, lo
    3904:      	cmp	w22, w20
    3908:      	csel	w11, w22, w20, lo
    390c:      	cinc	w13, w11, hi
    3910:      	sub	w14, w22, w13
    3914:      	subs	x12, x12, x13
    3918:      	str	w14, [sp, #0x90]
    391c:      	b.lo	0x3b58 <generic_uprobe_process_filter+0xb58>
    3920:      	cmp	x12, #0xfff
    3924:      	b.hi	0x3b58 <generic_uprobe_process_filter+0xb58>
    3928:      	cmp	w22, w20
    392c:      	b.ls	0x3938 <generic_uprobe_process_filter+0x938>
    3930:      	mov	w13, #0x2f              // =47
    3934:      	strb	w13, [x8, x12]
    3938:      	add	x25, x8, x12
    393c:      	cmp	w22, w20
    3940:      	add	x2, x9, x10
    3944:      	and	w1, w11, #0xff
    3948:      	mov	w8, #0x4                // =4
    394c:      	cinc	x0, x25, hi
    3950:      	blr	x8
    3954:      	cmp	w22, w20
    3958:      	str	x25, [sp, #0x88]
    395c:      	b.ls	0x3b58 <generic_uprobe_process_filter+0xb58>
    3960:      	ldr	x8, [sp, #0xc0]
    3964:      	str	x8, [sp, #0x70]
    3968:      	subs	w19, w19, #0x1
    396c:      	b.ne	0x3854 <generic_uprobe_process_filter+0x854>
    3970:      	b	0x3b58 <generic_uprobe_process_filter+0xb58>
    3974:      	add	x2, x21, #0x18
    3978:      	mov	w8, #0x8                // =8
    397c:      	mov	w9, #0x4                // =4
    3980:      	add	x10, sp, #0x58
    3984:      	add	x0, sp, #0x58
    3988:      	mov	w1, #0x8                // =8
    398c:      	blr	x9
    3990:      	ldr	x8, [sp, #0x58]
    3994:      	cmp	x8, x21
    3998:      	b.eq	0x3744 <generic_uprobe_process_filter+0x744>
    399c:      	ldr	x29, [sp, #0x40]
    39a0:      	ldr	w9, [x29, #0x550]
    39a4:      	sub	w8, w9, #0xa
    39a8:      	cmp	w9, #0x9
    39ac:      	str	w8, [x29, #0x550]
    39b0:      	b.gt	0x4080 <generic_uprobe_process_filter+0x1080>
    39b4:      	ldr	x21, [sp, #0x30]
    39b8:      	mov	w9, #-0x24              // =-36
    39bc:      	mov	x24, x20
    39c0:      	str	w9, [x29, #0x554]
    39c4:      	b	0x3bbc <generic_uprobe_process_filter+0xbbc>
    39c8:      	mov	w19, #0x800             // =2048
    39cc:      	mov	w21, #0x8               // =8
    39d0:      	add	x23, sp, #0xb8
    39d4:      	add	x29, sp, #0xd8
    39d8:      	b	0x3a30 <generic_uprobe_process_filter+0xa30>
    39dc:      	nop
    39e0:      	add	x2, x22, #0x10
    39e4:      	mov	w8, #0x4                // =4
    39e8:      	add	x0, sp, #0xd8
    39ec:      	mov	w1, #0x8                // =8
    39f0:      	blr	x8
    39f4:      	add	x20, sp, #0xd8
    39f8:      	ldr	x8, [sp, #0x80]
    39fc:      	ldr	x9, [x20]
    3a00:      	cmp	x8, x9
    3a04:      	b.eq	0x3b50 <generic_uprobe_process_filter+0xb50>
    3a08:      	add	x2, x22, #0x18
    3a0c:      	mov	w8, #0x4                // =4
    3a10:      	mov	x0, x24
    3a14:      	mov	w1, #0x8                // =8
    3a18:      	blr	x8
    3a1c:      	ldr	x8, [x20]
    3a20:      	add	x9, x8, #0x20
    3a24:      	stp	x9, x8, [sp, #0x78]
    3a28:      	subs	w19, w19, #0x1
    3a2c:      	b.eq	0x3b58 <generic_uprobe_process_filter+0xb58>
    3a30:      	ldp	x20, x2, [sp, #0x70]
    3a34:      	ldp	x8, x9, [sp, #0x58]
    3a38:      	cmp	x20, x8
    3a3c:      	ccmp	x2, x9, #0x0, eq
    3a40:      	b.eq	0x3b50 <generic_uprobe_process_filter+0xb50>
    3a44:      	ldr	x22, [sp, #0x80]
    3a48:      	mov	w8, #0x4                // =4
    3a4c:      	add	x0, sp, #0xb8
    3a50:      	mov	w1, #0x8                // =8
    3a54:      	blr	x8
    3a58:      	ldr	x8, [sp, #0xb8]
    3a5c:      	cmp	x20, x8
    3a60:      	b.eq	0x39e0 <generic_uprobe_process_filter+0x9e0>
    3a64:      	add	x25, x20, #0x18
    3a68:      	mov	w8, #0x4                // =4
    3a6c:      	add	x0, sp, #0xd8
    3a70:      	mov	w1, #0x8                // =8
    3a74:      	mov	x2, x25
    3a78:      	blr	x8
    3a7c:      	add	x8, sp, #0xd8
    3a80:      	ldr	x8, [x8]
    3a84:      	cmp	x8, x20
    3a88:      	b.eq	0x39e0 <generic_uprobe_process_filter+0x9e0>
    3a8c:      	mov	w8, #0x4                // =4
    3a90:      	add	x9, sp, #0xc0
    3a94:      	add	x0, sp, #0xc0
    3a98:      	mov	w1, #0x8                // =8
    3a9c:      	mov	x2, x25
    3aa0:      	blr	x8
    3aa4:      	add	x2, x20, #0x20
    3aa8:      	mov	w8, #0x4                // =4
    3aac:      	mov	w9, #0x10               // =16
    3ab0:      	add	x10, sp, #0xc8
    3ab4:      	add	x0, sp, #0xc8
    3ab8:      	mov	w1, #0x10               // =16
    3abc:      	blr	x8
    3ac0:      	ldr	w20, [sp, #0xcc]
    3ac4:      	ldr	x8, [sp, #0x68]
    3ac8:      	ldr	x10, [sp, #0x88]
    3acc:      	sub	x12, x10, x8
    3ad0:      	ldr	w22, [sp, #0x90]
    3ad4:      	subs	w10, w20, w22
    3ad8:      	ldr	x9, [sp, #0xd0]
    3adc:      	csel	w10, wzr, w10, lo
    3ae0:      	cmp	w22, w20
    3ae4:      	csel	w11, w22, w20, lo
    3ae8:      	cinc	w13, w11, hi
    3aec:      	sub	w14, w22, w13
    3af0:      	subs	x12, x12, x13
    3af4:      	str	w14, [sp, #0x90]
    3af8:      	b.lo	0x3b58 <generic_uprobe_process_filter+0xb58>
    3afc:      	cmp	x12, #0xfff
    3b00:      	b.hi	0x3b58 <generic_uprobe_process_filter+0xb58>
    3b04:      	cmp	w22, w20
    3b08:      	b.ls	0x3b14 <generic_uprobe_process_filter+0xb14>
    3b0c:      	mov	w13, #0x2f              // =47
    3b10:      	strb	w13, [x8, x12]
    3b14:      	add	x25, x8, x12
    3b18:      	cmp	w22, w20
    3b1c:      	add	x2, x9, x10
    3b20:      	and	w1, w11, #0xff
    3b24:      	mov	w8, #0x4                // =4
    3b28:      	cinc	x0, x25, hi
    3b2c:      	blr	x8
    3b30:      	cmp	w22, w20
    3b34:      	str	x25, [sp, #0x88]
    3b38:      	b.ls	0x3b58 <generic_uprobe_process_filter+0xb58>
    3b3c:      	ldr	x8, [sp, #0xc0]
    3b40:      	str	x8, [sp, #0x70]
    3b44:      	subs	w19, w19, #0x1
    3b48:      	b.ne	0x3a30 <generic_uprobe_process_filter+0xa30>
    3b4c:      	b	0x3b58 <generic_uprobe_process_filter+0xb58>
    3b50:      	mov	w8, #0x1                // =1
    3b54:      	strb	w8, [sp, #0x94]
    3b58:      	ldr	x24, [sp, #0x88]
    3b5c:      	ldr	x9, [sp, #0x28]
    3b60:      	cmp	x24, x9
    3b64:      	b.eq	0x3ba8 <generic_uprobe_process_filter+0xba8>
    3b68:      	ldrb	w8, [sp, #0x94]
    3b6c:      	ldr	x29, [sp, #0x40]
    3b70:      	cmp	w8, #0x0
    3b74:      	ldr	x21, [sp, #0x30]
    3b78:      	cset	w8, eq
    3b7c:      	lsl	w9, w8, #1
    3b80:      	ldr	w8, [sp, #0x90]
    3b84:      	cmp	w8, #0x1
    3b88:      	str	w8, [x29, #0x550]
    3b8c:      	str	w9, [x29, #0x554]
    3b90:      	b.lt	0x3ba0 <generic_uprobe_process_filter+0xba0>
    3b94:      	mov	w9, #0x1000             // =4096
    3b98:      	sub	w8, w9, w8
    3b9c:      	str	w8, [x29, #0x550]
    3ba0:      	cbnz	x24, 0x3bbc <generic_uprobe_process_filter+0xbbc>
    3ba4:      	b	0x3cd4 <generic_uprobe_process_filter+0xcd4>
    3ba8:      	ldr	x29, [sp, #0x40]
    3bac:      	ldr	x21, [sp, #0x30]
    3bb0:      	mov	w8, wzr
    3bb4:      	mov	x24, x9
    3bb8:      	str	xzr, [x29, #0x550]
    3bbc:      	subs	w9, w8, #0x7f
    3bc0:      	mov	w10, #0x7f              // =127
    3bc4:      	mov	x11, x29
    3bc8:      	mov	x0, x21
    3bcc:      	mov	x2, x24
    3bd0:      	csel	w29, w8, w10, lo
    3bd4:      	csel	w19, wzr, w9, lo
    3bd8:      	cmp	w8, #0xff
    3bdc:      	mov	w9, #0xff               // =255
    3be0:      	csel	w8, w8, w9, lo
    3be4:      	and	w1, w8, #0xff
    3be8:      	str	w1, [x11, #0x550]
    3bec:      	mov	w8, #0x4                // =4
    3bf0:      	blr	x8
    3bf4:      	adrp	x25, 0x3000 <generic_uprobe_process_filter>
    3bf8:      	ldr	x25, [x25]
    3bfc:      	cbz	x0, 0x3c6c <generic_uprobe_process_filter+0xc6c>
    3c00:      	neg	w8, w0
    3c04:      	mov	w9, #0x1                // =1
    3c08:      	add	x1, sp, #0x58
    3c0c:      	strh	w8, [sp, #0x58]
    3c10:      	mov	w8, #0x8                // =8
    3c14:      	mov	x0, x25
    3c18:      	mov	w20, #0x1               // =1
    3c1c:      	strh	w8, [sp, #0x5a]
    3c20:      	mov	x8, #0x2de              // =734
    3c24:      	movk	x8, #0x4, lsl #32
    3c28:      	stur	x8, [sp, #0x5c]
    3c2c:      	add	x8, sp, #0x58
    3c30:      	blr	x9
    3c34:      	cbz	x0, 0x3c48 <generic_uprobe_process_filter+0xc48>
    3c38:      	ldr	w8, [x0]
    3c3c:      	add	w8, w8, #0x1
    3c40:      	str	w8, [x0]
    3c44:      	b	0x3c6c <generic_uprobe_process_filter+0xc6c>
    3c48:      	str	w20, [sp, #0xc8]
    3c4c:      	mov	x3, xzr
    3c50:      	mov	w8, #0x2                // =2
    3c54:      	add	x9, sp, #0x58
    3c58:      	add	x10, sp, #0xc8
    3c5c:      	add	x1, sp, #0x58
    3c60:      	add	x2, sp, #0xc8
    3c64:      	mov	x0, x25
    3c68:      	blr	x8
    3c6c:      	ldr	x9, [sp, #0xe8]
    3c70:      	mov	w8, #0x6390             // =25488
    3c74:      	add	x2, x24, x19
    3c78:      	mov	w1, w29
    3c7c:      	add	x0, x9, x8
    3c80:      	mov	w8, #0x4                // =4
    3c84:      	blr	x8
    3c88:      	ldr	x29, [sp, #0x40]
    3c8c:      	cbz	x0, 0x3cd4 <generic_uprobe_process_filter+0xcd4>
    3c90:      	neg	w8, w0
    3c94:      	mov	w9, #0x1                // =1
    3c98:      	add	x1, sp, #0x58
    3c9c:      	strh	w8, [sp, #0x58]
    3ca0:      	mov	w8, #0x8                // =8
    3ca4:      	mov	x0, x25
    3ca8:      	mov	w19, #0x1               // =1
    3cac:      	strh	w8, [sp, #0x5a]
    3cb0:      	mov	x8, #0x2e0              // =736
    3cb4:      	movk	x8, #0x4, lsl #32
    3cb8:      	stur	x8, [sp, #0x5c]
    3cbc:      	add	x8, sp, #0x58
    3cc0:      	blr	x9
    3cc4:      	cbz	x0, 0x3cfc <generic_uprobe_process_filter+0xcfc>
    3cc8:      	ldr	w8, [x0]
    3ccc:      	add	w8, w8, #0x1
    3cd0:      	str	w8, [x0]
    3cd4:      	ldr	w8, [x29, #0x550]
    3cd8:      	sub	w9, w8, #0x101
    3cdc:      	cmn	w9, #0x101
    3ce0:      	b.hi	0x3d30 <generic_uprobe_process_filter+0xd30>
    3ce4:      	ldr	x20, [sp, #0x38]
    3ce8:      	ldr	x22, [sp, #0xe8]
    3cec:      	mov	w8, #-0x1               // =-1
    3cf0:      	ldr	x24, [sp, #0x48]
    3cf4:      	stur	w8, [x29, #0xb8]
    3cf8:      	b	0x3e80 <generic_uprobe_process_filter+0xe80>
    3cfc:      	str	w19, [sp, #0xc8]
    3d00:      	mov	x3, xzr
    3d04:      	mov	w8, #0x2                // =2
    3d08:      	add	x9, sp, #0x58
    3d0c:      	add	x10, sp, #0xc8
    3d10:      	add	x1, sp, #0x58
    3d14:      	add	x2, sp, #0xc8
    3d18:      	mov	x0, x25
    3d1c:      	blr	x8
    3d20:      	ldr	w8, [x29, #0x550]
    3d24:      	sub	w9, w8, #0x101
    3d28:      	cmn	w9, #0x101
    3d2c:      	b.ls	0x3ce4 <generic_uprobe_process_filter+0xce4>
    3d30:      	ldr	x22, [sp, #0xe8]
    3d34:      	and	x24, x8, #0xff
    3d38:      	mov	w8, #0x5f80             // =24448
    3d3c:      	mov	x2, x21
    3d40:      	mov	w1, w24
    3d44:      	add	x0, x22, x8
    3d48:      	mov	w8, #0x4                // =4
    3d4c:      	blr	x8
    3d50:      	mov	x23, x0
    3d54:      	cbz	x0, 0x3dd0 <generic_uprobe_process_filter+0xdd0>
    3d58:      	neg	w8, w23
    3d5c:      	adrp	x25, 0x3000 <generic_uprobe_process_filter>
    3d60:      	mov	w9, #0x1                // =1
    3d64:      	strh	w8, [sp, #0x58]
    3d68:      	mov	w8, #0xf                // =15
    3d6c:      	add	x1, sp, #0x58
    3d70:      	mov	w19, #0x1               // =1
    3d74:      	strh	w8, [sp, #0x5a]
    3d78:      	mov	x8, #0x164              // =356
    3d7c:      	movk	x8, #0x4, lsl #32
    3d80:      	stur	x8, [sp, #0x5c]
    3d84:      	add	x8, sp, #0x58
    3d88:      	ldr	x25, [x25]
    3d8c:      	mov	x0, x25
    3d90:      	blr	x9
    3d94:      	cbz	x0, 0x3da8 <generic_uprobe_process_filter+0xda8>
    3d98:      	ldr	w8, [x0]
    3d9c:      	add	w8, w8, #0x1
    3da0:      	str	w8, [x0]
    3da4:      	b	0x3dcc <generic_uprobe_process_filter+0xdcc>
    3da8:      	str	w19, [sp, #0xc8]
    3dac:      	mov	x3, xzr
    3db0:      	mov	w8, #0x2                // =2
    3db4:      	add	x9, sp, #0x58
    3db8:      	add	x10, sp, #0xc8
    3dbc:      	add	x1, sp, #0x58
    3dc0:      	add	x2, sp, #0xc8
    3dc4:      	mov	x0, x25
    3dc8:      	blr	x8
    3dcc:      	ldr	x22, [sp, #0xe8]
    3dd0:      	cmp	w23, #0x0
    3dd4:      	csel	w8, w24, w23, eq
    3dd8:      	cmp	w24, #0x7f
    3ddc:      	stur	w8, [x29, #0xb8]
    3de0:      	mov	w8, #0x7f               // =127
    3de4:      	csel	w1, w24, w8, lo
    3de8:      	mov	w8, #0x6080             // =24704
    3dec:      	add	x0, x22, x8
    3df0:      	mov	w8, #0x6390             // =25488
    3df4:      	add	x2, x22, x8
    3df8:      	mov	w8, #0x4                // =4
    3dfc:      	blr	x8
    3e00:      	ldr	x20, [sp, #0x38]
    3e04:      	ldr	x24, [sp, #0x48]
    3e08:      	cbz	x0, 0x3e80 <generic_uprobe_process_filter+0xe80>
    3e0c:      	neg	w8, w0
    3e10:      	adrp	x23, 0x3000 <generic_uprobe_process_filter>
    3e14:      	mov	w9, #0x1                // =1
    3e18:      	strh	w8, [sp, #0x58]
    3e1c:      	mov	w8, #0xf                // =15
    3e20:      	add	x1, sp, #0x58
    3e24:      	mov	w19, #0x1               // =1
    3e28:      	strh	w8, [sp, #0x5a]
    3e2c:      	mov	x8, #0x16a              // =362
    3e30:      	movk	x8, #0x4, lsl #32
    3e34:      	stur	x8, [sp, #0x5c]
    3e38:      	add	x8, sp, #0x58
    3e3c:      	ldr	x23, [x23]
    3e40:      	mov	x0, x23
    3e44:      	blr	x9
    3e48:      	cbz	x0, 0x3e5c <generic_uprobe_process_filter+0xe5c>
    3e4c:      	ldr	w8, [x0]
    3e50:      	add	w8, w8, #0x1
    3e54:      	str	w8, [x0]
    3e58:      	b	0x3e80 <generic_uprobe_process_filter+0xe80>
    3e5c:      	str	w19, [sp, #0xc8]
    3e60:      	mov	x3, xzr
    3e64:      	mov	w8, #0x2                // =2
    3e68:      	add	x9, sp, #0x58
    3e6c:      	add	x10, sp, #0xc8
    3e70:      	add	x1, sp, #0x58
    3e74:      	add	x2, sp, #0xc8
    3e78:      	mov	x0, x23
    3e7c:      	blr	x8
    3e80:      	ldrb	w8, [x22, #0x1]
    3e84:      	orr	w8, w8, #0x10
    3e88:      	strb	w8, [x22, #0x1]
    3e8c:      	adrp	x0, 0x3000 <generic_uprobe_process_filter>
    3e90:      	mov	w8, #0x5ef8             // =24312
    3e94:      	ldr	x0, [x0]
    3e98:      	add	x1, x22, x8
    3e9c:      	mov	w8, #0x1                // =1
    3ea0:      	blr	x8
    3ea4:      	cbz	x0, 0x532c <generic_uprobe_process_filter+0x232c>
    3ea8:      	ldr	x21, [x22, #0x5eb8]
    3eac:      	cmp	x21, #0x6
    3eb0:      	b.hs	0x4048 <generic_uprobe_process_filter+0x1048>
    3eb4:      	ldrsw	x8, [x0]
    3eb8:      	mov	x23, x0
    3ebc:      	cbz	w8, 0x4064 <generic_uprobe_process_filter+0x1064>
    3ec0:      	cmp	x21, x8
    3ec4:      	b.hs	0x4048 <generic_uprobe_process_filter+0x1048>
    3ec8:      	str	x8, [sp, #0x28]
    3ecc:      	stp	x29, x24, [sp, #0x40]
    3ed0:      	adrp	x24, 0x3000 <generic_uprobe_process_filter>
    3ed4:      	mov	w8, #0x1                // =1
    3ed8:      	add	x9, sp, #0xd8
    3edc:      	str	x22, [sp, #0xe8]
    3ee0:      	add	x1, sp, #0xd8
    3ee4:      	str	x20, [sp, #0x38]
    3ee8:      	str	w21, [sp, #0xd8]
    3eec:      	str	wzr, [sp, #0xc0]
    3ef0:      	ldr	x24, [x24]
    3ef4:      	mov	x0, x24
    3ef8:      	blr	x8
    3efc:      	cbz	x0, 0x430c <generic_uprobe_process_filter+0x130c>
    3f00:      	ldr	w8, [x0]
    3f04:      	mov	x25, x0
    3f08:      	cbz	w8, 0x430c <generic_uprobe_process_filter+0x130c>
    3f0c:      	ldr	x9, [sp, #0x48]
    3f10:      	ldr	w9, [x9, #0x68]
    3f14:      	tbnz	w9, #0x1f, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    3f18:      	cmp	w8, #0x1b
    3f1c:      	b.hi	0x52d4 <generic_uprobe_process_filter+0x22d4>
    3f20:      	mov	w9, #0x1                // =1
    3f24:      	lsl	w9, w9, w8
    3f28:      	tst	w9, #0x60
    3f2c:      	b.ne	0x4124 <generic_uprobe_process_filter+0x1124>
    3f30:      	mov	w10, #0x100             // =256
    3f34:      	movk	w10, #0x400, lsl #16
    3f38:      	tst	w9, w10
    3f3c:      	b.ne	0x40a0 <generic_uprobe_process_filter+0x10a0>
    3f40:      	mov	w9, #0x1                // =1
    3f44:      	lsl	w8, w9, w8
    3f48:      	mov	w9, #0x200              // =512
    3f4c:      	movk	w9, #0x800, lsl #16
    3f50:      	tst	w8, w9
    3f54:      	b.eq	0x52d4 <generic_uprobe_process_filter+0x22d4>
    3f58:      	adrp	x0, 0x3000 <generic_uprobe_process_filter>
    3f5c:      	add	x1, x25, #0x4
    3f60:      	mov	w8, #0x1                // =1
    3f64:      	ldr	x0, [x0]
    3f68:      	blr	x8
    3f6c:      	cbz	x0, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    3f70:      	ldr	x8, [sp, #0x48]
    3f74:      	mov	x20, x0
    3f78:      	adrp	x0, 0x3000 <generic_uprobe_process_filter>
    3f7c:      	mov	w9, #0x7f               // =127
    3f80:      	ldr	w8, [x8, #0x68]
    3f84:      	ldr	x0, [x0]
    3f88:      	add	x1, sp, #0xc0
    3f8c:      	cmp	w8, #0x7f
    3f90:      	csel	w19, w8, w9, lt
    3f94:      	mov	w8, #0x1                // =1
    3f98:      	add	x9, sp, #0xc0
    3f9c:      	blr	x8
    3fa0:      	cbz	x0, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    3fa4:      	sxtw	x1, w19
    3fa8:      	mov	x29, x0
    3fac:      	lsl	w8, w1, #3
    3fb0:      	str	w8, [x0]
    3fb4:      	ldr	x8, [sp, #0x48]
    3fb8:      	ldr	w8, [x8, #0x6c]
    3fbc:      	cbnz	w8, 0x401c <generic_uprobe_process_filter+0x101c>
    3fc0:      	ldr	x11, [sp, #0x48]
    3fc4:      	and	w13, w1, #0x7f
    3fc8:      	mov	x8, xzr
    3fcc:      	ldr	w12, [x11, #0x68]
    3fd0:      	add	x9, x11, #0x1f0
    3fd4:      	add	x10, x11, #0x170
    3fd8:      	sub	w11, w12, w1
    3fdc:      	add	w12, w12, w13
    3fe0:      	add	w11, w11, w13
    3fe4:      	mvn	w13, w1
    3fe8:      	add	w12, w13, w12
    3fec:      	cmp	x8, #0x7f
    3ff0:      	b.eq	0x4010 <generic_uprobe_process_filter+0x1010>
    3ff4:      	and	x13, x12, #0x7f
    3ff8:      	sub	w12, w12, #0x1
    3ffc:      	ldrb	w13, [x10, x13]
    4000:      	strb	w13, [x9, x8]
    4004:      	add	x8, x8, #0x1
    4008:      	cmp	x11, x8
    400c:      	b.ne	0x3fec <generic_uprobe_process_filter+0xfec>
    4010:      	ldr	x9, [sp, #0x48]
    4014:      	mov	w8, #0x1                // =1
    4018:      	str	w8, [x9, #0x6c]
    401c:      	cmp	w1, #0x7f
    4020:      	b.hi	0x403c <generic_uprobe_process_filter+0x103c>
    4024:      	ldr	x8, [sp, #0x48]
    4028:      	add	x0, x29, #0x4
    402c:      	add	x2, x8, #0x1f0
    4030:      	mov	w8, #0x4                // =4
    4034:      	blr	x8
    4038:      	tbnz	x0, #0x3f, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    403c:      	mov	w8, #0x1                // =1
    4040:      	mov	x0, x20
    4044:      	b	0x411c <generic_uprobe_process_filter+0x111c>
    4048:      	ldr	w8, [x24]
    404c:      	str	w8, [x22, #0x10]
    4050:      	ldr	x8, [x24, #0x8]
    4054:      	str	x8, [x22, #0x18]
    4058:      	ldrb	w8, [x29]
    405c:      	cbnz	w8, 0x5310 <generic_uprobe_process_filter+0x2310>
    4060:      	b	0x532c <generic_uprobe_process_filter+0x232c>
    4064:      	mov	w8, #0x1                // =1
    4068:      	strb	w8, [x29]
    406c:      	ldr	w8, [x24]
    4070:      	str	w8, [x22, #0x10]
    4074:      	ldr	x8, [x24, #0x8]
    4078:      	str	x8, [x22, #0x18]
    407c:      	b	0x5310 <generic_uprobe_process_filter+0x2310>
    4080:      	mov	w8, #0x2964             // =10596
    4084:      	add	x20, x24, #0xff6
    4088:      	strh	w8, [x24, #0xffe]
    408c:      	adrp	x8, 0x4000 <generic_uprobe_process_filter+0x1000>
    4090:      	add	x8, x8, #0x0
    4094:      	ldr	x8, [x8]
    4098:      	str	x8, [x20]
    409c:      	b	0x3744 <generic_uprobe_process_filter+0x744>
    40a0:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    40a4:      	add	x1, x25, #0x4
    40a8:      	mov	w8, #0x1                // =1
    40ac:      	ldr	x0, [x0]
    40b0:      	blr	x8
    40b4:      	cbz	x0, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    40b8:      	mov	x19, x0
    40bc:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    40c0:      	mov	w8, #0x1                // =1
    40c4:      	ldr	x0, [x0]
    40c8:      	add	x9, sp, #0xc0
    40cc:      	add	x1, sp, #0xc0
    40d0:      	blr	x8
    40d4:      	cbz	x0, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    40d8:      	mov	w1, wzr
    40dc:      	mov	w2, #0x104              // =260
    40e0:      	mov	x29, x0
    40e4:      	bl	0x40e4 <generic_uprobe_process_filter+0x10e4>
    40e8:      	ldr	x10, [sp, #0x48]
    40ec:      	mov	x0, x29
    40f0:      	ldr	w8, [x10, #0x68]
    40f4:      	add	x2, x10, #0x70
    40f8:      	lsl	w9, w8, #3
    40fc:      	and	x8, x8, #0xff
    4100:      	str	w9, [x0], #0x4
    4104:      	mov	w9, #0x4                // =4
    4108:      	ldrb	w1, [x10, #0x68]
    410c:      	blr	x9
    4110:      	tbnz	x0, #0x3f, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    4114:      	mov	w8, #0x1                // =1
    4118:      	mov	x0, x19
    411c:      	mov	x1, x29
    4120:      	b	0x42d4 <generic_uprobe_process_filter+0x12d4>
    4124:      	str	wzr, [sp, #0xc8]
    4128:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    412c:      	mov	w8, #0x1                // =1
    4130:      	add	x9, sp, #0xc8
    4134:      	ldr	x0, [x0]
    4138:      	add	x1, sp, #0xc8
    413c:      	blr	x8
    4140:      	cbz	x0, 0x4280 <generic_uprobe_process_filter+0x1280>
    4144:      	ldr	x9, [sp, #0x48]
    4148:      	ldr	x8, [x0]
    414c:      	ldr	x9, [x9, #0x378]
    4150:      	cmp	x8, x9
    4154:      	b.eq	0x4280 <generic_uprobe_process_filter+0x1280>
    4158:      	str	x0, [sp, #0x30]
    415c:      	adrp	x8, 0x4000 <generic_uprobe_process_filter+0x1000>
    4160:      	mov	w20, wzr
    4164:      	mov	x19, xzr
    4168:      	ldr	x8, [x8]
    416c:      	ldrb	w8, [x8]
    4170:      	ldr	x9, [sp, #0x48]
    4174:      	add	x22, x9, #0x370
    4178:      	cbz	w8, 0x4248 <generic_uprobe_process_filter+0x1248>
    417c:      	ldr	x8, [sp, #0x48]
    4180:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4184:      	add	x9, sp, #0x58
    4188:      	add	x1, sp, #0x58
    418c:      	ldr	w8, [x8, #0x10]
    4190:      	str	w8, [sp, #0x58]
    4194:      	mov	w8, #0x1                // =1
    4198:      	ldr	x0, [x0]
    419c:      	blr	x8
    41a0:      	cbz	x0, 0x4270 <generic_uprobe_process_filter+0x1270>
    41a4:      	mov	x29, x0
    41a8:      	add	x1, x0, #0x70
    41ac:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    41b0:      	ldr	x0, [x0]
    41b4:      	mov	w8, #0x1                // =1
    41b8:      	blr	x8
    41bc:      	cbz	x0, 0x41d8 <generic_uprobe_process_filter+0x11d8>
    41c0:      	ldr	x8, [x0]
    41c4:      	cbz	x8, 0x41d8 <generic_uprobe_process_filter+0x11d8>
    41c8:      	ldaxr	x9, [x22]
    41cc:      	orr	x9, x9, x8
    41d0:      	stlxr	w10, x9, [x22]
    41d4:      	cbnz	w10, 0x41c8 <generic_uprobe_process_filter+0x11c8>
    41d8:      	cmp	x29, x19
    41dc:      	b.eq	0x4270 <generic_uprobe_process_filter+0x1270>
    41e0:      	mov	w8, #0x86a0             // =34464
    41e4:      	add	w20, w20, #0x1
    41e8:      	mov	x19, x29
    41ec:      	movk	w8, #0x1, lsl #16
    41f0:      	cmp	w20, w8
    41f4:      	b.ne	0x417c <generic_uprobe_process_filter+0x117c>
    41f8:      	b	0x4270 <generic_uprobe_process_filter+0x1270>
    41fc:      	mov	x29, x0
    4200:      	add	x1, x0, #0x70
    4204:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4208:      	ldr	x0, [x0]
    420c:      	mov	w8, #0x1                // =1
    4210:      	blr	x8
    4214:      	cbz	x0, 0x4230 <generic_uprobe_process_filter+0x1230>
    4218:      	ldr	x8, [x0]
    421c:      	cbz	x8, 0x4230 <generic_uprobe_process_filter+0x1230>
    4220:      	ldaxr	x9, [x22]
    4224:      	orr	x9, x9, x8
    4228:      	stlxr	w10, x9, [x22]
    422c:      	cbnz	w10, 0x4220 <generic_uprobe_process_filter+0x1220>
    4230:      	cmp	x29, x19
    4234:      	b.eq	0x4270 <generic_uprobe_process_filter+0x1270>
    4238:      	add	w20, w20, #0x1
    423c:      	mov	x19, x29
    4240:      	cmp	w20, #0x400
    4244:      	b.eq	0x4270 <generic_uprobe_process_filter+0x1270>
    4248:      	ldr	x8, [sp, #0x48]
    424c:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4250:      	add	x9, sp, #0x58
    4254:      	add	x1, sp, #0x58
    4258:      	ldr	w8, [x8, #0x10]
    425c:      	str	w8, [sp, #0x58]
    4260:      	mov	w8, #0x1                // =1
    4264:      	ldr	x0, [x0]
    4268:      	blr	x8
    426c:      	cbnz	x0, 0x41fc <generic_uprobe_process_filter+0x11fc>
    4270:      	ldr	x8, [sp, #0x30]
    4274:      	ldr	x9, [sp, #0x48]
    4278:      	ldr	x8, [x8]
    427c:      	str	x8, [x9, #0x378]
    4280:      	ldr	w8, [x25, #0x8]
    4284:      	cmn	w8, #0x1
    4288:      	b.eq	0x42ac <generic_uprobe_process_filter+0x12ac>
    428c:      	ldr	x9, [sp, #0x48]
    4290:      	ldr	x9, [x9, #0x370]
    4294:      	lsr	x8, x9, x8
    4298:      	tbz	w8, #0x0, 0x42ac <generic_uprobe_process_filter+0x12ac>
    429c:      	mov	x0, #0xffee             // =65518
    42a0:      	movk	x0, #0xadc0, lsl #16
    42a4:      	movk	x0, #0xb, lsl #32
    42a8:      	b	0x42d8 <generic_uprobe_process_filter+0x12d8>
    42ac:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    42b0:      	mov	w8, #0x1                // =1
    42b4:      	add	x9, sp, #0xd8
    42b8:      	ldr	x0, [x0]
    42bc:      	add	x1, sp, #0xd8
    42c0:      	blr	x8
    42c4:      	cbz	x0, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    42c8:      	ldr	x8, [sp, #0x48]
    42cc:      	add	x1, x8, #0x70
    42d0:      	mov	w8, #0x1                // =1
    42d4:      	blr	x8
    42d8:      	ldr	w8, [x25]
    42dc:      	cmp	w8, #0x25
    42e0:      	b.hi	0x4308 <generic_uprobe_process_filter+0x1308>
    42e4:      	mov	w9, #0x1                // =1
    42e8:      	lsl	x8, x9, x8
    42ec:      	mov	x9, #0x50               // =80
    42f0:      	movk	x9, #0xc00, lsl #16
    42f4:      	movk	x9, #0x20, lsl #32
    42f8:      	tst	x8, x9
    42fc:      	b.eq	0x4308 <generic_uprobe_process_filter+0x1308>
    4300:      	cbnz	x0, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    4304:      	b	0x430c <generic_uprobe_process_filter+0x130c>
    4308:      	cbz	x0, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    430c:      	adrp	x8, 0x4000 <generic_uprobe_process_filter+0x1000>
    4310:      	ldr	x8, [x8]
    4314:      	ldrb	w8, [x8]
    4318:      	cbz	w8, 0x46e0 <generic_uprobe_process_filter+0x16e0>
    431c:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4320:      	mov	w8, #0x1                // =1
    4324:      	ldr	x0, [x0]
    4328:      	ldr	x1, [sp, #0x48]
    432c:      	blr	x8
    4330:      	cbz	x0, 0x46e0 <generic_uprobe_process_filter+0x16e0>
    4334:      	add	w8, w21, #0x5
    4338:      	str	wzr, [sp, #0xc0]
    433c:      	add	x9, sp, #0xd8
    4340:      	mov	x25, x0
    4344:      	str	w8, [sp, #0xd8]
    4348:      	mov	w8, #0x1                // =1
    434c:      	add	x1, sp, #0xd8
    4350:      	mov	x0, x24
    4354:      	blr	x8
    4358:      	cbz	x0, 0x46e0 <generic_uprobe_process_filter+0x16e0>
    435c:      	ldr	w8, [x0]
    4360:      	mov	x24, x0
    4364:      	cbz	w8, 0x46e0 <generic_uprobe_process_filter+0x16e0>
    4368:      	ldr	w9, [x25]
    436c:      	tbnz	w9, #0x1f, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    4370:      	cmp	w8, #0x1b
    4374:      	b.hi	0x52d4 <generic_uprobe_process_filter+0x22d4>
    4378:      	mov	w9, #0x1                // =1
    437c:      	lsl	w9, w9, w8
    4380:      	tst	w9, #0x60
    4384:      	b.ne	0x450c <generic_uprobe_process_filter+0x150c>
    4388:      	mov	w10, #0x100             // =256
    438c:      	movk	w10, #0x400, lsl #16
    4390:      	tst	w9, w10
    4394:      	b.ne	0x448c <generic_uprobe_process_filter+0x148c>
    4398:      	mov	w9, #0x1                // =1
    439c:      	lsl	w8, w9, w8
    43a0:      	mov	w9, #0x200              // =512
    43a4:      	movk	w9, #0x800, lsl #16
    43a8:      	tst	w8, w9
    43ac:      	b.eq	0x52d4 <generic_uprobe_process_filter+0x22d4>
    43b0:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    43b4:      	add	x1, x24, #0x4
    43b8:      	mov	w8, #0x1                // =1
    43bc:      	ldr	x0, [x0]
    43c0:      	blr	x8
    43c4:      	cbz	x0, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    43c8:      	ldr	w8, [x25]
    43cc:      	mov	x20, x0
    43d0:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    43d4:      	mov	w9, #0x7f               // =127
    43d8:      	ldr	x0, [x0]
    43dc:      	add	x1, sp, #0xc0
    43e0:      	cmp	w8, #0x7f
    43e4:      	csel	w19, w8, w9, lt
    43e8:      	mov	w8, #0x1                // =1
    43ec:      	add	x9, sp, #0xc0
    43f0:      	blr	x8
    43f4:      	cbz	x0, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    43f8:      	sxtw	x1, w19
    43fc:      	mov	x29, x0
    4400:      	lsl	w8, w1, #3
    4404:      	str	w8, [x0]
    4408:      	ldr	w8, [x25, #0x4]
    440c:      	cbnz	w8, 0x4464 <generic_uprobe_process_filter+0x1464>
    4410:      	ldr	w12, [x25]
    4414:      	and	w13, w1, #0x7f
    4418:      	mov	x8, xzr
    441c:      	add	x9, x25, #0x188
    4420:      	add	x10, x25, #0x108
    4424:      	sub	w11, w12, w1
    4428:      	add	w12, w12, w13
    442c:      	add	w11, w11, w13
    4430:      	mvn	w13, w1
    4434:      	add	w12, w13, w12
    4438:      	cmp	x8, #0x7f
    443c:      	b.eq	0x445c <generic_uprobe_process_filter+0x145c>
    4440:      	and	x13, x12, #0x7f
    4444:      	sub	w12, w12, #0x1
    4448:      	ldrb	w13, [x10, x13]
    444c:      	strb	w13, [x9, x8]
    4450:      	add	x8, x8, #0x1
    4454:      	cmp	x11, x8
    4458:      	b.ne	0x4438 <generic_uprobe_process_filter+0x1438>
    445c:      	mov	w8, #0x1                // =1
    4460:      	str	w8, [x25, #0x4]
    4464:      	cmp	w1, #0x7f
    4468:      	b.hi	0x4480 <generic_uprobe_process_filter+0x1480>
    446c:      	add	x0, x29, #0x4
    4470:      	add	x2, x25, #0x188
    4474:      	mov	w8, #0x4                // =4
    4478:      	blr	x8
    447c:      	tbnz	x0, #0x3f, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    4480:      	mov	w8, #0x1                // =1
    4484:      	mov	x0, x20
    4488:      	b	0x4504 <generic_uprobe_process_filter+0x1504>
    448c:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4490:      	add	x1, x24, #0x4
    4494:      	mov	w8, #0x1                // =1
    4498:      	ldr	x0, [x0]
    449c:      	blr	x8
    44a0:      	cbz	x0, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    44a4:      	mov	x19, x0
    44a8:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    44ac:      	mov	w8, #0x1                // =1
    44b0:      	ldr	x0, [x0]
    44b4:      	add	x9, sp, #0xc0
    44b8:      	add	x1, sp, #0xc0
    44bc:      	blr	x8
    44c0:      	cbz	x0, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    44c4:      	mov	w1, wzr
    44c8:      	mov	w2, #0x104              // =260
    44cc:      	mov	x29, x0
    44d0:      	bl	0x44d0 <generic_uprobe_process_filter+0x14d0>
    44d4:      	ldr	w8, [x25]
    44d8:      	mov	x0, x29
    44dc:      	add	x2, x25, #0x8
    44e0:      	lsl	w9, w8, #3
    44e4:      	and	x8, x8, #0xff
    44e8:      	str	w9, [x0], #0x4
    44ec:      	mov	w9, #0x4                // =4
    44f0:      	ldrb	w1, [x25]
    44f4:      	blr	x9
    44f8:      	tbnz	x0, #0x3f, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    44fc:      	mov	w8, #0x1                // =1
    4500:      	mov	x0, x19
    4504:      	mov	x1, x29
    4508:      	b	0x46a8 <generic_uprobe_process_filter+0x16a8>
    450c:      	str	wzr, [sp, #0xc8]
    4510:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4514:      	mov	w8, #0x1                // =1
    4518:      	add	x9, sp, #0xc8
    451c:      	ldr	x0, [x0]
    4520:      	add	x1, sp, #0xc8
    4524:      	blr	x8
    4528:      	cbz	x0, 0x465c <generic_uprobe_process_filter+0x165c>
    452c:      	ldr	x8, [x0]
    4530:      	ldr	x9, [x25, #0x310]
    4534:      	cmp	x8, x9
    4538:      	b.eq	0x465c <generic_uprobe_process_filter+0x165c>
    453c:      	str	x0, [sp, #0x30]
    4540:      	adrp	x8, 0x4000 <generic_uprobe_process_filter+0x1000>
    4544:      	add	x22, x25, #0x308
    4548:      	mov	w20, wzr
    454c:      	ldr	x8, [x8]
    4550:      	mov	x19, xzr
    4554:      	ldrb	w8, [x8]
    4558:      	cbz	w8, 0x4628 <generic_uprobe_process_filter+0x1628>
    455c:      	ldr	x8, [sp, #0x48]
    4560:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4564:      	add	x9, sp, #0x58
    4568:      	add	x1, sp, #0x58
    456c:      	ldr	w8, [x8, #0x10]
    4570:      	str	w8, [sp, #0x58]
    4574:      	mov	w8, #0x1                // =1
    4578:      	ldr	x0, [x0]
    457c:      	blr	x8
    4580:      	cbz	x0, 0x4650 <generic_uprobe_process_filter+0x1650>
    4584:      	mov	x29, x0
    4588:      	add	x1, x0, #0x70
    458c:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4590:      	ldr	x0, [x0]
    4594:      	mov	w8, #0x1                // =1
    4598:      	blr	x8
    459c:      	cbz	x0, 0x45b8 <generic_uprobe_process_filter+0x15b8>
    45a0:      	ldr	x8, [x0]
    45a4:      	cbz	x8, 0x45b8 <generic_uprobe_process_filter+0x15b8>
    45a8:      	ldaxr	x9, [x22]
    45ac:      	orr	x9, x9, x8
    45b0:      	stlxr	w10, x9, [x22]
    45b4:      	cbnz	w10, 0x45a8 <generic_uprobe_process_filter+0x15a8>
    45b8:      	cmp	x29, x19
    45bc:      	b.eq	0x4650 <generic_uprobe_process_filter+0x1650>
    45c0:      	mov	w8, #0x86a0             // =34464
    45c4:      	add	w20, w20, #0x1
    45c8:      	mov	x19, x29
    45cc:      	movk	w8, #0x1, lsl #16
    45d0:      	cmp	w20, w8
    45d4:      	b.ne	0x455c <generic_uprobe_process_filter+0x155c>
    45d8:      	b	0x4650 <generic_uprobe_process_filter+0x1650>
    45dc:      	mov	x29, x0
    45e0:      	add	x1, x0, #0x70
    45e4:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    45e8:      	ldr	x0, [x0]
    45ec:      	mov	w8, #0x1                // =1
    45f0:      	blr	x8
    45f4:      	cbz	x0, 0x4610 <generic_uprobe_process_filter+0x1610>
    45f8:      	ldr	x8, [x0]
    45fc:      	cbz	x8, 0x4610 <generic_uprobe_process_filter+0x1610>
    4600:      	ldaxr	x9, [x22]
    4604:      	orr	x9, x9, x8
    4608:      	stlxr	w10, x9, [x22]
    460c:      	cbnz	w10, 0x4600 <generic_uprobe_process_filter+0x1600>
    4610:      	cmp	x29, x19
    4614:      	b.eq	0x4650 <generic_uprobe_process_filter+0x1650>
    4618:      	add	w20, w20, #0x1
    461c:      	mov	x19, x29
    4620:      	cmp	w20, #0x400
    4624:      	b.eq	0x4650 <generic_uprobe_process_filter+0x1650>
    4628:      	ldr	x8, [sp, #0x48]
    462c:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4630:      	add	x9, sp, #0x58
    4634:      	add	x1, sp, #0x58
    4638:      	ldr	w8, [x8, #0x10]
    463c:      	str	w8, [sp, #0x58]
    4640:      	mov	w8, #0x1                // =1
    4644:      	ldr	x0, [x0]
    4648:      	blr	x8
    464c:      	cbnz	x0, 0x45dc <generic_uprobe_process_filter+0x15dc>
    4650:      	ldr	x8, [sp, #0x30]
    4654:      	ldr	x8, [x8]
    4658:      	str	x8, [x25, #0x310]
    465c:      	ldr	w8, [x24, #0x8]
    4660:      	cmn	w8, #0x1
    4664:      	b.eq	0x4684 <generic_uprobe_process_filter+0x1684>
    4668:      	ldr	x9, [x25, #0x308]
    466c:      	lsr	x8, x9, x8
    4670:      	tbz	w8, #0x0, 0x4684 <generic_uprobe_process_filter+0x1684>
    4674:      	mov	x0, #0xffee             // =65518
    4678:      	movk	x0, #0xadc0, lsl #16
    467c:      	movk	x0, #0xb, lsl #32
    4680:      	b	0x46ac <generic_uprobe_process_filter+0x16ac>
    4684:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4688:      	mov	w8, #0x1                // =1
    468c:      	add	x9, sp, #0xd8
    4690:      	ldr	x0, [x0]
    4694:      	add	x1, sp, #0xd8
    4698:      	blr	x8
    469c:      	cbz	x0, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    46a0:      	add	x1, x25, #0x8
    46a4:      	mov	w8, #0x1                // =1
    46a8:      	blr	x8
    46ac:      	ldr	w8, [x24]
    46b0:      	cmp	w8, #0x25
    46b4:      	b.hi	0x46dc <generic_uprobe_process_filter+0x16dc>
    46b8:      	mov	w9, #0x1                // =1
    46bc:      	lsl	x8, x9, x8
    46c0:      	mov	x9, #0x50               // =80
    46c4:      	movk	x9, #0xc00, lsl #16
    46c8:      	movk	x9, #0x20, lsl #32
    46cc:      	tst	x8, x9
    46d0:      	b.eq	0x46dc <generic_uprobe_process_filter+0x16dc>
    46d4:      	cbnz	x0, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    46d8:      	b	0x46e0 <generic_uprobe_process_filter+0x16e0>
    46dc:      	cbz	x0, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    46e0:      	lsl	w8, w21, #2
    46e4:      	add	x9, x8, #0x4
    46e8:      	ldr	w8, [x9, x23]
    46ec:      	add	w9, w8, w9
    46f0:      	and	w11, w9, #0x3ff
    46f4:      	add	w9, w9, #0x4
    46f8:      	and	x9, x9, #0x3ff
    46fc:      	add	x10, x11, #0x8
    4700:      	ldr	w9, [x9, x23]
    4704:      	cmp	w9, #0x5
    4708:      	b.lo	0x4798 <generic_uprobe_process_filter+0x1798>
    470c:      	add	x9, x10, x23
    4710:      	ldr	w10, [x9, #0x8]
    4714:      	ldp	w12, w22, [x9]
    4718:      	stp	x9, x11, [sp, #0x8]
    471c:      	mov	w9, #0x4                // =4
    4720:      	cmp	w10, #0x4
    4724:      	stp	xzr, xzr, [sp, #0x58]
    4728:      	csel	w9, w10, w9, lo
    472c:      	cmp	w12, #0x6
    4730:      	b.ne	0x473c <generic_uprobe_process_filter+0x173c>
    4734:      	mov	x11, #0x100000001       // =4294967297
    4738:      	stp	x11, x11, [sp, #0x58]
    473c:      	cbz	w10, 0x4ba0 <generic_uprobe_process_filter+0x1ba0>
    4740:      	ldr	x10, [sp, #0x48]
    4744:      	add	w8, w8, w21, lsl #2
    4748:      	tst	x22, #0x1
    474c:      	add	x25, sp, #0x58
    4750:      	str	w12, [sp, #0x30]
    4754:      	add	w8, w8, #0x4
    4758:      	and	x8, x8, #0x3ff
    475c:      	add	x21, x8, #0x14
    4760:      	sub	x8, x9, #0x1
    4764:      	mov	w9, #0x3                // =3
    4768:      	add	x11, x10, #0x24
    476c:      	str	x11, [sp, #0x20]
    4770:      	csel	x11, x10, x11, eq
    4774:      	cmp	x8, #0x3
    4778:      	add	x10, x10, #0x10
    477c:      	csel	x8, x8, x9, lo
    4780:      	and	x9, x21, #0x7fc
    4784:      	mov	x20, x11
    4788:      	str	x10, [sp, #0x18]
    478c:      	add	x19, x23, x9
    4790:      	add	x24, x8, #0x1
    4794:      	b	0x47d0 <generic_uprobe_process_filter+0x17d0>
    4798:      	mov	w9, #0x1                // =1
    479c:      	mov	w8, w10
    47a0:      	b	0x4be8 <generic_uprobe_process_filter+0x1be8>
    47a4:      	mov	w8, #0x1                // =1
    47a8:      	ldr	w12, [sp, #0x30]
    47ac:      	mov	x11, x20
    47b0:      	cmp	w12, #0x6
    47b4:      	eor	w8, w8, #0x1
    47b8:      	csinc	w9, w8, wzr, eq
    47bc:      	str	w9, [x25], #0x4
    47c0:      	add	x21, x21, #0x4
    47c4:      	add	x19, x19, #0x4
    47c8:      	subs	x24, x24, #0x1
    47cc:      	b.eq	0x4ba0 <generic_uprobe_process_filter+0x1ba0>
    47d0:      	cmp	x21, #0x3e8
    47d4:      	b.ls	0x49f8 <generic_uprobe_process_filter+0x19f8>
    47d8:      	mov	x29, xzr
    47dc:      	tbz	w22, #0x1, 0x4a00 <generic_uprobe_process_filter+0x1a00>
    47e0:      	tbnz	w22, #0x0, 0x4a2c <generic_uprobe_process_filter+0x1a2c>
    47e4:      	ldr	x10, [sp, #0x48]
    47e8:      	mov	w8, #0x1                // =1
    47ec:      	ldr	w9, [x10]
    47f0:      	cmp	x29, x9
    47f4:      	b.eq	0x47b0 <generic_uprobe_process_filter+0x17b0>
    47f8:      	ldr	w9, [x10, #0x10]
    47fc:      	cmp	x29, x9
    4800:      	b.eq	0x47b0 <generic_uprobe_process_filter+0x17b0>
    4804:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4808:      	mov	w8, #0x1                // =1
    480c:      	ldr	x0, [x0]
    4810:      	ldr	x1, [sp, #0x18]
    4814:      	blr	x8
    4818:      	cbz	x0, 0x4b84 <generic_uprobe_process_filter+0x1b84>
    481c:      	ldr	w9, [x0]
    4820:      	mov	x1, x0
    4824:      	mov	w8, #0x1                // =1
    4828:      	cmp	x29, x9
    482c:      	b.eq	0x47a8 <generic_uprobe_process_filter+0x17a8>
    4830:      	ldr	w9, [x1, #0x10]!
    4834:      	ldr	w12, [sp, #0x30]
    4838:      	mov	x11, x20
    483c:      	cmp	x29, x9
    4840:      	b.eq	0x47b0 <generic_uprobe_process_filter+0x17b0>
    4844:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4848:      	mov	w8, #0x1                // =1
    484c:      	ldr	x0, [x0]
    4850:      	blr	x8
    4854:      	cbz	x0, 0x4b84 <generic_uprobe_process_filter+0x1b84>
    4858:      	ldr	w9, [x0]
    485c:      	mov	x1, x0
    4860:      	mov	w8, #0x1                // =1
    4864:      	cmp	x29, x9
    4868:      	b.eq	0x47a8 <generic_uprobe_process_filter+0x17a8>
    486c:      	ldr	w9, [x1, #0x10]!
    4870:      	ldr	w12, [sp, #0x30]
    4874:      	mov	x11, x20
    4878:      	cmp	x29, x9
    487c:      	b.eq	0x47b0 <generic_uprobe_process_filter+0x17b0>
    4880:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4884:      	mov	w8, #0x1                // =1
    4888:      	ldr	x0, [x0]
    488c:      	blr	x8
    4890:      	cbz	x0, 0x4b84 <generic_uprobe_process_filter+0x1b84>
    4894:      	ldr	w9, [x0]
    4898:      	mov	x1, x0
    489c:      	mov	w8, #0x1                // =1
    48a0:      	cmp	x29, x9
    48a4:      	b.eq	0x47a8 <generic_uprobe_process_filter+0x17a8>
    48a8:      	ldr	w9, [x1, #0x10]!
    48ac:      	ldr	w12, [sp, #0x30]
    48b0:      	mov	x11, x20
    48b4:      	cmp	x29, x9
    48b8:      	b.eq	0x47b0 <generic_uprobe_process_filter+0x17b0>
    48bc:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    48c0:      	mov	w8, #0x1                // =1
    48c4:      	ldr	x0, [x0]
    48c8:      	blr	x8
    48cc:      	cbz	x0, 0x4b84 <generic_uprobe_process_filter+0x1b84>
    48d0:      	ldr	w9, [x0]
    48d4:      	mov	x1, x0
    48d8:      	mov	w8, #0x1                // =1
    48dc:      	cmp	x29, x9
    48e0:      	b.eq	0x47a8 <generic_uprobe_process_filter+0x17a8>
    48e4:      	ldr	w9, [x1, #0x10]!
    48e8:      	ldr	w12, [sp, #0x30]
    48ec:      	mov	x11, x20
    48f0:      	cmp	x29, x9
    48f4:      	b.eq	0x47b0 <generic_uprobe_process_filter+0x17b0>
    48f8:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    48fc:      	mov	w8, #0x1                // =1
    4900:      	ldr	x0, [x0]
    4904:      	blr	x8
    4908:      	cbz	x0, 0x4b84 <generic_uprobe_process_filter+0x1b84>
    490c:      	ldr	w9, [x0]
    4910:      	mov	x1, x0
    4914:      	mov	w8, #0x1                // =1
    4918:      	cmp	x29, x9
    491c:      	b.eq	0x47a8 <generic_uprobe_process_filter+0x17a8>
    4920:      	ldr	w9, [x1, #0x10]!
    4924:      	ldr	w12, [sp, #0x30]
    4928:      	mov	x11, x20
    492c:      	cmp	x29, x9
    4930:      	b.eq	0x47b0 <generic_uprobe_process_filter+0x17b0>
    4934:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4938:      	mov	w8, #0x1                // =1
    493c:      	ldr	x0, [x0]
    4940:      	blr	x8
    4944:      	cbz	x0, 0x4b84 <generic_uprobe_process_filter+0x1b84>
    4948:      	ldr	w9, [x0]
    494c:      	mov	x1, x0
    4950:      	mov	w8, #0x1                // =1
    4954:      	cmp	x29, x9
    4958:      	b.eq	0x47a8 <generic_uprobe_process_filter+0x17a8>
    495c:      	ldr	w9, [x1, #0x10]!
    4960:      	ldr	w12, [sp, #0x30]
    4964:      	mov	x11, x20
    4968:      	cmp	x29, x9
    496c:      	b.eq	0x47b0 <generic_uprobe_process_filter+0x17b0>
    4970:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4974:      	mov	w8, #0x1                // =1
    4978:      	ldr	x0, [x0]
    497c:      	blr	x8
    4980:      	cbz	x0, 0x4b84 <generic_uprobe_process_filter+0x1b84>
    4984:      	ldr	w9, [x0]
    4988:      	mov	x1, x0
    498c:      	mov	w8, #0x1                // =1
    4990:      	cmp	x29, x9
    4994:      	b.eq	0x47a8 <generic_uprobe_process_filter+0x17a8>
    4998:      	ldr	w9, [x1, #0x10]!
    499c:      	ldr	w12, [sp, #0x30]
    49a0:      	mov	x11, x20
    49a4:      	cmp	x29, x9
    49a8:      	b.eq	0x47b0 <generic_uprobe_process_filter+0x17b0>
    49ac:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    49b0:      	mov	w8, #0x1                // =1
    49b4:      	ldr	x0, [x0]
    49b8:      	blr	x8
    49bc:      	cbz	x0, 0x4b84 <generic_uprobe_process_filter+0x1b84>
    49c0:      	ldr	w9, [x0]
    49c4:      	mov	x1, x0
    49c8:      	mov	w8, #0x1                // =1
    49cc:      	cmp	x29, x9
    49d0:      	b.eq	0x47a8 <generic_uprobe_process_filter+0x17a8>
    49d4:      	ldr	w9, [x1, #0x10]!
    49d8:      	ldr	w12, [sp, #0x30]
    49dc:      	mov	x11, x20
    49e0:      	cmp	x29, x9
    49e4:      	b.eq	0x47b0 <generic_uprobe_process_filter+0x17b0>
    49e8:      	adrp	x9, 0x4000 <generic_uprobe_process_filter+0x1000>
    49ec:      	mov	w8, #0x1                // =1
    49f0:      	ldr	x9, [x9]
    49f4:      	b	0x4b78 <generic_uprobe_process_filter+0x1b78>
    49f8:      	ldr	w29, [x19]
    49fc:      	tbnz	w22, #0x1, 0x47e0 <generic_uprobe_process_filter+0x17e0>
    4a00:      	ldr	w8, [x11]
    4a04:      	cmp	w12, #0x5
    4a08:      	b.ne	0x4a1c <generic_uprobe_process_filter+0x1a1c>
    4a0c:      	cmp	x29, x8
    4a10:      	b.eq	0x4a1c <generic_uprobe_process_filter+0x1a1c>
    4a14:      	mov	w9, wzr
    4a18:      	b	0x47bc <generic_uprobe_process_filter+0x17bc>
    4a1c:      	cmp	w12, #0x6
    4a20:      	ccmp	x29, x8, #0x0, eq
    4a24:      	cset	w9, ne
    4a28:      	b	0x47bc <generic_uprobe_process_filter+0x17bc>
    4a2c:      	ldr	x8, [sp, #0x20]
    4a30:      	ldr	w9, [x8]
    4a34:      	cbz	w9, 0x47bc <generic_uprobe_process_filter+0x17bc>
    4a38:      	mov	w8, #0x1                // =1
    4a3c:      	cbz	x29, 0x47b0 <generic_uprobe_process_filter+0x17b0>
    4a40:      	cmp	x29, x9
    4a44:      	b.eq	0x47b0 <generic_uprobe_process_filter+0x17b0>
    4a48:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4a4c:      	mov	w8, #0x1                // =1
    4a50:      	ldr	x0, [x0]
    4a54:      	ldr	x1, [sp, #0x18]
    4a58:      	blr	x8
    4a5c:      	cbz	x0, 0x4b84 <generic_uprobe_process_filter+0x1b84>
    4a60:      	ldr	w8, [x0, #0x24]
    4a64:      	cmp	x29, x8
    4a68:      	b.eq	0x47a4 <generic_uprobe_process_filter+0x17a4>
    4a6c:      	add	x1, x0, #0x10
    4a70:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4a74:      	mov	w8, #0x1                // =1
    4a78:      	ldr	x0, [x0]
    4a7c:      	blr	x8
    4a80:      	cbz	x0, 0x4b84 <generic_uprobe_process_filter+0x1b84>
    4a84:      	ldr	w8, [x0, #0x24]
    4a88:      	cmp	x29, x8
    4a8c:      	b.eq	0x47a4 <generic_uprobe_process_filter+0x17a4>
    4a90:      	add	x1, x0, #0x10
    4a94:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4a98:      	mov	w8, #0x1                // =1
    4a9c:      	ldr	x0, [x0]
    4aa0:      	blr	x8
    4aa4:      	cbz	x0, 0x4b84 <generic_uprobe_process_filter+0x1b84>
    4aa8:      	ldr	w8, [x0, #0x24]
    4aac:      	cmp	x29, x8
    4ab0:      	b.eq	0x47a4 <generic_uprobe_process_filter+0x17a4>
    4ab4:      	add	x1, x0, #0x10
    4ab8:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4abc:      	mov	w8, #0x1                // =1
    4ac0:      	ldr	x0, [x0]
    4ac4:      	blr	x8
    4ac8:      	cbz	x0, 0x4b84 <generic_uprobe_process_filter+0x1b84>
    4acc:      	ldr	w8, [x0, #0x24]
    4ad0:      	cmp	x29, x8
    4ad4:      	b.eq	0x47a4 <generic_uprobe_process_filter+0x17a4>
    4ad8:      	add	x1, x0, #0x10
    4adc:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4ae0:      	mov	w8, #0x1                // =1
    4ae4:      	ldr	x0, [x0]
    4ae8:      	blr	x8
    4aec:      	cbz	x0, 0x4b84 <generic_uprobe_process_filter+0x1b84>
    4af0:      	ldr	w8, [x0, #0x24]
    4af4:      	cmp	x29, x8
    4af8:      	b.eq	0x47a4 <generic_uprobe_process_filter+0x17a4>
    4afc:      	add	x1, x0, #0x10
    4b00:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4b04:      	mov	w8, #0x1                // =1
    4b08:      	ldr	x0, [x0]
    4b0c:      	blr	x8
    4b10:      	cbz	x0, 0x4b84 <generic_uprobe_process_filter+0x1b84>
    4b14:      	ldr	w8, [x0, #0x24]
    4b18:      	cmp	x29, x8
    4b1c:      	b.eq	0x47a4 <generic_uprobe_process_filter+0x17a4>
    4b20:      	add	x1, x0, #0x10
    4b24:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4b28:      	mov	w8, #0x1                // =1
    4b2c:      	ldr	x0, [x0]
    4b30:      	blr	x8
    4b34:      	cbz	x0, 0x4b84 <generic_uprobe_process_filter+0x1b84>
    4b38:      	ldr	w8, [x0, #0x24]
    4b3c:      	cmp	x29, x8
    4b40:      	b.eq	0x47a4 <generic_uprobe_process_filter+0x17a4>
    4b44:      	add	x1, x0, #0x10
    4b48:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4b4c:      	mov	w8, #0x1                // =1
    4b50:      	ldr	x0, [x0]
    4b54:      	blr	x8
    4b58:      	cbz	x0, 0x4b84 <generic_uprobe_process_filter+0x1b84>
    4b5c:      	ldr	w8, [x0, #0x24]
    4b60:      	cmp	x29, x8
    4b64:      	b.eq	0x47a4 <generic_uprobe_process_filter+0x17a4>
    4b68:      	adrp	x9, 0x4000 <generic_uprobe_process_filter+0x1000>
    4b6c:      	add	x1, x0, #0x10
    4b70:      	mov	w8, #0x1                // =1
    4b74:      	ldr	x9, [x9]
    4b78:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4b7c:      	ldr	x0, [x0]
    4b80:      	blr	x8
    4b84:      	ldr	w12, [sp, #0x30]
    4b88:      	mov	w8, wzr
    4b8c:      	mov	w9, wzr
    4b90:      	mov	x11, x20
    4b94:      	cmp	w12, #0x5
    4b98:      	b.ne	0x47b0 <generic_uprobe_process_filter+0x17b0>
    4b9c:      	b	0x47bc <generic_uprobe_process_filter+0x17bc>
    4ba0:      	ldp	w8, w9, [sp, #0x58]
    4ba4:      	ldp	w10, w11, [sp, #0x60]
    4ba8:      	cmp	w12, #0x6
    4bac:      	b.ne	0x4bc0 <generic_uprobe_process_filter+0x1bc0>
    4bb0:      	and	w8, w9, w8
    4bb4:      	and	w9, w10, w11
    4bb8:      	and	w9, w8, w9
    4bbc:      	b	0x4bcc <generic_uprobe_process_filter+0x1bcc>
    4bc0:      	orr	w8, w9, w8
    4bc4:      	orr	w9, w10, w11
    4bc8:      	orr	w9, w8, w9
    4bcc:      	ldr	x8, [sp, #0x10]
    4bd0:      	cbz	w9, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    4bd4:      	ldr	x10, [sp, #0x8]
    4bd8:      	add	w8, w8, #0x14
    4bdc:      	ldr	w10, [x10, #0x8]
    4be0:      	ubfiz	w10, w10, #2, #3
    4be4:      	add	w8, w10, w8
    4be8:      	and	x10, x8, #0x3ff
    4bec:      	add	w8, w8, #0x4
    4bf0:      	mov	w19, #0xa               // =10
    4bf4:      	ldr	w10, [x10, x23]
    4bf8:      	mov	w20, #0x4               // =4
    4bfc:      	mov	x25, #0x100000001       // =4294967297
    4c00:      	sub	w22, w10, #0x4
    4c04:      	ldr	x10, [sp, #0xe8]
    4c08:      	add	x10, x10, #0x20
    4c0c:      	str	x10, [sp, #0x30]
    4c10:      	b	0x4c28 <generic_uprobe_process_filter+0x1c28>
    4c14:      	nop
    4c18:      	nop
    4c1c:      	nop
    4c20:      	subs	x19, x19, #0x1
    4c24:      	b.eq	0x4df4 <generic_uprobe_process_filter+0x1df4>
    4c28:      	cbz	w22, 0x4c20 <generic_uprobe_process_filter+0x1c20>
    4c2c:      	and	x9, x8, #0x3ff
    4c30:      	add	x10, x9, x23
    4c34:      	ldr	w29, [x10, #0x8]
    4c38:      	ldp	w9, w24, [x10]
    4c3c:      	stp	xzr, xzr, [sp, #0x58]
    4c40:      	cmp	w29, #0x4
    4c44:      	csel	w10, w29, w20, lo
    4c48:      	cmp	w24, #0x6
    4c4c:      	b.ne	0x4c54 <generic_uprobe_process_filter+0x1c54>
    4c50:      	stp	x25, x25, [sp, #0x58]
    4c54:      	add	w21, w8, #0xc
    4c58:      	cbz	w29, 0x4dac <generic_uprobe_process_filter+0x1dac>
    4c5c:      	and	x9, x9, #0xf
    4c60:      	cmp	w9, #0xa
    4c64:      	b.lo	0x4c90 <generic_uprobe_process_filter+0x1c90>
    4c68:      	sub	x8, x10, #0x1
    4c6c:      	mov	w9, #0x3                // =3
    4c70:      	add	x0, sp, #0x58
    4c74:      	mov	w1, wzr
    4c78:      	cmp	x8, #0x3
    4c7c:      	csel	x8, x8, x9, lo
    4c80:      	lsl	x8, x8, #2
    4c84:      	add	x2, x8, #0x4
    4c88:      	bl	0x4c88 <generic_uprobe_process_filter+0x1c88>
    4c8c:      	b	0x4dac <generic_uprobe_process_filter+0x1dac>
    4c90:      	cmp	w21, #0x3e8
    4c94:      	b.ls	0x4ca0 <generic_uprobe_process_filter+0x1ca0>
    4c98:      	mov	w11, wzr
    4c9c:      	b	0x4ca8 <generic_uprobe_process_filter+0x1ca8>
    4ca0:      	and	w11, w21, #0xfffffffc
    4ca4:      	ldr	w11, [x23, w11, uxtw]
    4ca8:      	ldr	x12, [sp, #0x30]
    4cac:      	cmp	w24, #0x5
    4cb0:      	sub	x10, x10, #0x1
    4cb4:      	ldr	w9, [x12, x9, lsl #2]
    4cb8:      	cset	w12, ne
    4cbc:      	cmp	w24, #0x6
    4cc0:      	cset	w13, ne
    4cc4:      	cmp	w11, w9
    4cc8:      	csinc	w11, w12, wzr, ne
    4ccc:      	csinc	w12, w13, wzr, eq
    4cd0:      	and	w11, w11, w12
    4cd4:      	str	w11, [sp, #0x58]
    4cd8:      	cbz	x10, 0x4dac <generic_uprobe_process_filter+0x1dac>
    4cdc:      	add	w11, w8, #0x10
    4ce0:      	cmp	w11, #0x3e8
    4ce4:      	b.ls	0x4cf0 <generic_uprobe_process_filter+0x1cf0>
    4ce8:      	mov	w11, wzr
    4cec:      	b	0x4cf8 <generic_uprobe_process_filter+0x1cf8>
    4cf0:      	and	w11, w11, #0xfffffffc
    4cf4:      	ldr	w11, [x23, w11, uxtw]
    4cf8:      	cmp	w24, #0x5
    4cfc:      	cset	w12, ne
    4d00:      	cmp	w24, #0x6
    4d04:      	cset	w13, ne
    4d08:      	cmp	w11, w9
    4d0c:      	csinc	w11, w12, wzr, ne
    4d10:      	csinc	w12, w13, wzr, eq
    4d14:      	cmp	x10, #0x1
    4d18:      	and	w11, w11, w12
    4d1c:      	str	w11, [sp, #0x5c]
    4d20:      	b.eq	0x4dac <generic_uprobe_process_filter+0x1dac>
    4d24:      	add	w11, w8, #0x14
    4d28:      	cmp	w11, #0x3e8
    4d2c:      	b.ls	0x4d38 <generic_uprobe_process_filter+0x1d38>
    4d30:      	mov	w11, wzr
    4d34:      	b	0x4d40 <generic_uprobe_process_filter+0x1d40>
    4d38:      	and	w11, w11, #0xfffffffc
    4d3c:      	ldr	w11, [x23, w11, uxtw]
    4d40:      	cmp	w24, #0x5
    4d44:      	cset	w12, ne
    4d48:      	cmp	w24, #0x6
    4d4c:      	cset	w13, ne
    4d50:      	cmp	w11, w9
    4d54:      	csinc	w11, w12, wzr, ne
    4d58:      	csinc	w12, w13, wzr, eq
    4d5c:      	cmp	x10, #0x2
    4d60:      	and	w11, w11, w12
    4d64:      	str	w11, [sp, #0x60]
    4d68:      	b.eq	0x4dac <generic_uprobe_process_filter+0x1dac>
    4d6c:      	add	w8, w8, #0x18
    4d70:      	cmp	w8, #0x3e8
    4d74:      	b.ls	0x4d80 <generic_uprobe_process_filter+0x1d80>
    4d78:      	mov	w8, wzr
    4d7c:      	b	0x4d88 <generic_uprobe_process_filter+0x1d88>
    4d80:      	and	w8, w8, #0xfffffffc
    4d84:      	ldr	w8, [x23, w8, uxtw]
    4d88:      	cmp	w24, #0x5
    4d8c:      	cset	w10, ne
    4d90:      	cmp	w24, #0x6
    4d94:      	cset	w11, ne
    4d98:      	cmp	w8, w9
    4d9c:      	csinc	w8, w10, wzr, ne
    4da0:      	csinc	w9, w11, wzr, eq
    4da4:      	and	w8, w8, w9
    4da8:      	str	w8, [sp, #0x64]
    4dac:      	ldp	w8, w9, [sp, #0x58]
    4db0:      	ldp	w10, w11, [sp, #0x60]
    4db4:      	cmp	w24, #0x6
    4db8:      	b.ne	0x4dcc <generic_uprobe_process_filter+0x1dcc>
    4dbc:      	and	w8, w9, w8
    4dc0:      	and	w9, w10, w11
    4dc4:      	and	w9, w8, w9
    4dc8:      	b	0x4dd8 <generic_uprobe_process_filter+0x1dd8>
    4dcc:      	orr	w8, w9, w8
    4dd0:      	orr	w9, w10, w11
    4dd4:      	orr	w9, w8, w9
    4dd8:      	cbz	w9, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    4ddc:      	lsl	w8, w29, #2
    4de0:      	sub	w10, w22, w29, lsl #2
    4de4:      	and	w8, w8, #0x1c
    4de8:      	sub	w22, w10, #0xc
    4dec:      	add	w8, w8, w21
    4df0:      	b	0x4c20 <generic_uprobe_process_filter+0x1c20>
    4df4:      	mov	w10, w8
    4df8:      	add	w19, w8, #0x4
    4dfc:      	and	x10, x10, #0x3ff
    4e00:      	ldr	w10, [x10, x23]
    4e04:      	cmp	w10, #0x4
    4e08:      	b.ne	0x4ea0 <generic_uprobe_process_filter+0x1ea0>
    4e0c:      	cbz	w9, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    4e10:      	mov	w8, w19
    4e14:      	and	x8, x8, #0x3ff
    4e18:      	ldr	w9, [x8, x23]
    4e1c:      	add	w8, w19, #0x4
    4e20:      	cmp	w9, #0x4
    4e24:      	mov	w9, w8
    4e28:      	b.eq	0x51d0 <generic_uprobe_process_filter+0x21d0>
    4e2c:      	and	x8, x8, #0x3ff
    4e30:      	add	x8, x8, x23
    4e34:      	ldp	w20, w22, [x8]
    4e38:      	mov	w8, #0xe                // =14
    4e3c:      	blr	x8
    4e40:      	lsr	x8, x0, #32
    4e44:      	adrp	x0, 0x4000 <generic_uprobe_process_filter+0x1000>
    4e48:      	add	x9, sp, #0x58
    4e4c:      	str	w8, [sp, #0x58]
    4e50:      	mov	w8, #0x1                // =1
    4e54:      	add	x1, sp, #0x58
    4e58:      	ldr	x0, [x0]
    4e5c:      	blr	x8
    4e60:      	cbz	x0, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    4e64:      	cmp	w20, #0x5
    4e68:      	b.eq	0x4f1c <generic_uprobe_process_filter+0x1f1c>
    4e6c:      	cmp	w20, #0x6
    4e70:      	b.ne	0x52d4 <generic_uprobe_process_filter+0x22d4>
    4e74:      	ldr	x11, [sp, #0xe8]
    4e78:      	mov	w8, #0x5ee8             // =24296
    4e7c:      	add	x8, x11, x8
    4e80:      	tbnz	w22, #0x0, 0x4f50 <generic_uprobe_process_filter+0x1f50>
    4e84:      	ldr	w9, [x0, #0x28]
    4e88:      	cbz	w9, 0x4f48 <generic_uprobe_process_filter+0x1f48>
    4e8c:      	ldr	x10, [sp, #0x30]
    4e90:      	ldr	w10, [x10]
    4e94:      	cmp	w9, w10
    4e98:      	b.eq	0x4f50 <generic_uprobe_process_filter+0x1f50>
    4e9c:      	b	0x51c4 <generic_uprobe_process_filter+0x21c4>
    4ea0:      	and	x9, x19, #0x3ff
    4ea4:      	add	w19, w8, #0x18
    4ea8:      	add	x9, x9, x23
    4eac:      	ldp	w8, w10, [x9]
    4eb0:      	ldr	w12, [x9, #0x8]
    4eb4:      	ldur	x11, [x9, #0xc]
    4eb8:      	cbz	w12, 0x4edc <generic_uprobe_process_filter+0x1edc>
    4ebc:      	ldr	x14, [sp, #0xe8]
    4ec0:      	mov	w9, wzr
    4ec4:      	cmp	w8, #0x2
    4ec8:      	b.hi	0x4e0c <generic_uprobe_process_filter+0x1e0c>
    4ecc:      	ldr	w13, [x14, #0x44]
    4ed0:      	cmp	w13, w12
    4ed4:      	b.ne	0x4ef0 <generic_uprobe_process_filter+0x1ef0>
    4ed8:      	b	0x4e0c <generic_uprobe_process_filter+0x1e0c>
    4edc:      	ldr	x14, [sp, #0xe8]
    4ee0:      	cmp	w8, #0x2
    4ee4:      	b.ls	0x4ef0 <generic_uprobe_process_filter+0x1ef0>
    4ee8:      	mov	w9, wzr
    4eec:      	b	0x4e0c <generic_uprobe_process_filter+0x1e0c>
    4ef0:      	add	x9, x14, #0x48
    4ef4:      	cmp	w10, #0x5
    4ef8:      	ldr	x8, [x9, x8, lsl #3]
    4efc:      	and	x8, x8, x11
    4f00:      	b.ne	0x4f10 <generic_uprobe_process_filter+0x1f10>
    4f04:      	cmp	x8, #0x0
    4f08:      	cset	w9, ne
    4f0c:      	b	0x4e0c <generic_uprobe_process_filter+0x1e0c>
    4f10:      	cmp	x8, #0x0
    4f14:      	cset	w9, eq
    4f18:      	b	0x4e0c <generic_uprobe_process_filter+0x1e0c>
    4f1c:      	ldr	x11, [sp, #0xe8]
    4f20:      	mov	w8, #0x5ee8             // =24296
    4f24:      	add	x8, x11, x8
    4f28:      	tbz	w22, #0x0, 0x4f74 <generic_uprobe_process_filter+0x1f74>
    4f2c:      	ldr	w9, [x0, #0x28]
    4f30:      	cbz	w9, 0x4f6c <generic_uprobe_process_filter+0x1f6c>
    4f34:      	ldr	x10, [sp, #0x30]
    4f38:      	ldr	w10, [x10]
    4f3c:      	cmp	w9, w10
    4f40:      	b.eq	0x4f74 <generic_uprobe_process_filter+0x1f74>
    4f44:      	b	0x51c4 <generic_uprobe_process_filter+0x21c4>
    4f48:      	mov	w9, #0x1                // =1
    4f4c:      	str	x9, [x8]
    4f50:      	tbnz	w22, #0x1, 0x4f98 <generic_uprobe_process_filter+0x1f98>
    4f54:      	ldr	w9, [x0, #0x2c]
    4f58:      	cbz	w9, 0x4f90 <generic_uprobe_process_filter+0x1f90>
    4f5c:      	ldr	w10, [x11, #0x24]
    4f60:      	cmp	w9, w10
    4f64:      	b.eq	0x4f98 <generic_uprobe_process_filter+0x1f98>
    4f68:      	b	0x51c4 <generic_uprobe_process_filter+0x21c4>
    4f6c:      	mov	w9, #0x1                // =1
    4f70:      	str	x9, [x8]
    4f74:      	tbz	w22, #0x1, 0x4fbc <generic_uprobe_process_filter+0x1fbc>
    4f78:      	ldr	w9, [x0, #0x2c]
    4f7c:      	cbz	w9, 0x4fb4 <generic_uprobe_process_filter+0x1fb4>
    4f80:      	ldr	w10, [x11, #0x24]
    4f84:      	cmp	w9, w10
    4f88:      	b.eq	0x4fbc <generic_uprobe_process_filter+0x1fbc>
    4f8c:      	b	0x51c4 <generic_uprobe_process_filter+0x21c4>
    4f90:      	mov	w9, #0x1                // =1
    4f94:      	str	x9, [x8]
    4f98:      	tbnz	w22, #0x2, 0x4fe0 <generic_uprobe_process_filter+0x1fe0>
    4f9c:      	ldr	w9, [x0, #0x30]
    4fa0:      	cbz	w9, 0x4fd8 <generic_uprobe_process_filter+0x1fd8>
    4fa4:      	ldr	w10, [x11, #0x28]
    4fa8:      	cmp	w9, w10
    4fac:      	b.eq	0x4fe0 <generic_uprobe_process_filter+0x1fe0>
    4fb0:      	b	0x51c4 <generic_uprobe_process_filter+0x21c4>
    4fb4:      	mov	w9, #0x1                // =1
    4fb8:      	str	x9, [x8]
    4fbc:      	tbz	w22, #0x2, 0x5004 <generic_uprobe_process_filter+0x2004>
    4fc0:      	ldr	w9, [x0, #0x30]
    4fc4:      	cbz	w9, 0x4ffc <generic_uprobe_process_filter+0x1ffc>
    4fc8:      	ldr	w10, [x11, #0x28]
    4fcc:      	cmp	w9, w10
    4fd0:      	b.eq	0x5004 <generic_uprobe_process_filter+0x2004>
    4fd4:      	b	0x51c4 <generic_uprobe_process_filter+0x21c4>
    4fd8:      	mov	w9, #0x1                // =1
    4fdc:      	str	x9, [x8]
    4fe0:      	tbnz	w22, #0x3, 0x5028 <generic_uprobe_process_filter+0x2028>
    4fe4:      	ldr	w9, [x0, #0x34]
    4fe8:      	cbz	w9, 0x5020 <generic_uprobe_process_filter+0x2020>
    4fec:      	ldr	w10, [x11, #0x2c]
    4ff0:      	cmp	w9, w10
    4ff4:      	b.eq	0x5028 <generic_uprobe_process_filter+0x2028>
    4ff8:      	b	0x51c4 <generic_uprobe_process_filter+0x21c4>
    4ffc:      	mov	w9, #0x1                // =1
    5000:      	str	x9, [x8]
    5004:      	tbz	w22, #0x3, 0x504c <generic_uprobe_process_filter+0x204c>
    5008:      	ldr	w9, [x0, #0x34]
    500c:      	cbz	w9, 0x5044 <generic_uprobe_process_filter+0x2044>
    5010:      	ldr	w10, [x11, #0x2c]
    5014:      	cmp	w9, w10
    5018:      	b.eq	0x504c <generic_uprobe_process_filter+0x204c>
    501c:      	b	0x51c4 <generic_uprobe_process_filter+0x21c4>
    5020:      	mov	w9, #0x1                // =1
    5024:      	str	x9, [x8]
    5028:      	tbnz	w22, #0x4, 0x5070 <generic_uprobe_process_filter+0x2070>
    502c:      	ldr	w9, [x0, #0x38]
    5030:      	cbz	w9, 0x5068 <generic_uprobe_process_filter+0x2068>
    5034:      	ldr	w10, [x11, #0x30]
    5038:      	cmp	w9, w10
    503c:      	b.eq	0x5070 <generic_uprobe_process_filter+0x2070>
    5040:      	b	0x51c4 <generic_uprobe_process_filter+0x21c4>
    5044:      	mov	w9, #0x1                // =1
    5048:      	str	x9, [x8]
    504c:      	tbz	w22, #0x4, 0x5094 <generic_uprobe_process_filter+0x2094>
    5050:      	ldr	w9, [x0, #0x38]
    5054:      	cbz	w9, 0x508c <generic_uprobe_process_filter+0x208c>
    5058:      	ldr	w10, [x11, #0x30]
    505c:      	cmp	w9, w10
    5060:      	b.eq	0x5094 <generic_uprobe_process_filter+0x2094>
    5064:      	b	0x51c4 <generic_uprobe_process_filter+0x21c4>
    5068:      	mov	w9, #0x1                // =1
    506c:      	str	x9, [x8]
    5070:      	tbnz	w22, #0x5, 0x50b8 <generic_uprobe_process_filter+0x20b8>
    5074:      	ldr	w9, [x0, #0x3c]
    5078:      	cbz	w9, 0x50b0 <generic_uprobe_process_filter+0x20b0>
    507c:      	ldr	w10, [x11, #0x34]
    5080:      	cmp	w9, w10
    5084:      	b.eq	0x50b8 <generic_uprobe_process_filter+0x20b8>
    5088:      	b	0x51c4 <generic_uprobe_process_filter+0x21c4>
    508c:      	mov	w9, #0x1                // =1
    5090:      	str	x9, [x8]
    5094:      	tbz	w22, #0x5, 0x50dc <generic_uprobe_process_filter+0x20dc>
    5098:      	ldr	w9, [x0, #0x3c]
    509c:      	cbz	w9, 0x50d4 <generic_uprobe_process_filter+0x20d4>
    50a0:      	ldr	w10, [x11, #0x34]
    50a4:      	cmp	w9, w10
    50a8:      	b.eq	0x50dc <generic_uprobe_process_filter+0x20dc>
    50ac:      	b	0x51c4 <generic_uprobe_process_filter+0x21c4>
    50b0:      	mov	w9, #0x1                // =1
    50b4:      	str	x9, [x8]
    50b8:      	tbnz	w22, #0x6, 0x5100 <generic_uprobe_process_filter+0x2100>
    50bc:      	ldr	w9, [x0, #0x40]
    50c0:      	cbz	w9, 0x50f8 <generic_uprobe_process_filter+0x20f8>
    50c4:      	ldr	w10, [x11, #0x38]
    50c8:      	cmp	w9, w10
    50cc:      	b.eq	0x5100 <generic_uprobe_process_filter+0x2100>
    50d0:      	b	0x51c4 <generic_uprobe_process_filter+0x21c4>
    50d4:      	mov	w9, #0x1                // =1
    50d8:      	str	x9, [x8]
    50dc:      	tbz	w22, #0x6, 0x5124 <generic_uprobe_process_filter+0x2124>
    50e0:      	ldr	w9, [x0, #0x40]
    50e4:      	cbz	w9, 0x511c <generic_uprobe_process_filter+0x211c>
    50e8:      	ldr	w10, [x11, #0x38]
    50ec:      	cmp	w9, w10
    50f0:      	b.eq	0x5124 <generic_uprobe_process_filter+0x2124>
    50f4:      	b	0x51c4 <generic_uprobe_process_filter+0x21c4>
    50f8:      	mov	w9, #0x1                // =1
    50fc:      	str	x9, [x8]
    5100:      	tbnz	w22, #0x7, 0x5148 <generic_uprobe_process_filter+0x2148>
    5104:      	ldr	w9, [x0, #0x44]
    5108:      	cbz	w9, 0x5140 <generic_uprobe_process_filter+0x2140>
    510c:      	ldr	w10, [x11, #0x3c]
    5110:      	cmp	w9, w10
    5114:      	b.eq	0x5148 <generic_uprobe_process_filter+0x2148>
    5118:      	b	0x51c4 <generic_uprobe_process_filter+0x21c4>
    511c:      	mov	w9, #0x1                // =1
    5120:      	str	x9, [x8]
    5124:      	tbz	w22, #0x7, 0x5170 <generic_uprobe_process_filter+0x2170>
    5128:      	ldr	w9, [x0, #0x44]
    512c:      	cbz	w9, 0x5168 <generic_uprobe_process_filter+0x2168>
    5130:      	ldr	w10, [x11, #0x3c]
    5134:      	cmp	w9, w10
    5138:      	b.eq	0x5170 <generic_uprobe_process_filter+0x2170>
    513c:      	b	0x51c4 <generic_uprobe_process_filter+0x21c4>
    5140:      	mov	w9, #0x1                // =1
    5144:      	str	x9, [x8]
    5148:      	tbnz	w22, #0x8, 0x5198 <generic_uprobe_process_filter+0x2198>
    514c:      	ldr	w9, [x0, #0x48]
    5150:      	cbz	w9, 0x5190 <generic_uprobe_process_filter+0x2190>
    5154:      	ldr	x10, [sp, #0xe8]
    5158:      	ldr	w10, [x10, #0x40]
    515c:      	cmp	w9, w10
    5160:      	b.eq	0x5198 <generic_uprobe_process_filter+0x2198>
    5164:      	b	0x51c4 <generic_uprobe_process_filter+0x21c4>
    5168:      	mov	w9, #0x1                // =1
    516c:      	str	x9, [x8]
    5170:      	tbz	w22, #0x8, 0x51a8 <generic_uprobe_process_filter+0x21a8>
    5174:      	ldr	w9, [x0, #0x48]
    5178:      	cbz	w9, 0x51a0 <generic_uprobe_process_filter+0x21a0>
    517c:      	ldr	x10, [sp, #0xe8]
    5180:      	ldr	w10, [x10, #0x40]
    5184:      	cmp	w9, w10
    5188:      	b.eq	0x51a8 <generic_uprobe_process_filter+0x21a8>
    518c:      	b	0x51c4 <generic_uprobe_process_filter+0x21c4>
    5190:      	mov	w9, #0x1                // =1
    5194:      	str	x9, [x8]
    5198:      	tbz	w22, #0x9, 0x51ac <generic_uprobe_process_filter+0x21ac>
    519c:      	b	0x52d4 <generic_uprobe_process_filter+0x22d4>
    51a0:      	mov	w9, #0x1                // =1
    51a4:      	str	x9, [x8]
    51a8:      	tbz	w22, #0x9, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    51ac:      	ldr	w9, [x0, #0x4c]
    51b0:      	cbz	w9, 0x52cc <generic_uprobe_process_filter+0x22cc>
    51b4:      	ldr	x10, [sp, #0xe8]
    51b8:      	ldr	w10, [x10, #0x44]
    51bc:      	cmp	w9, w10
    51c0:      	b.eq	0x52d4 <generic_uprobe_process_filter+0x22d4>
    51c4:      	add	w9, w19, #0xc
    51c8:      	mov	w10, #0x1               // =1
    51cc:      	str	x10, [x8]
    51d0:      	and	x8, x9, #0x3ff
    51d4:      	adrp	x24, 0x5000 <generic_uprobe_process_filter+0x2000>
    51d8:      	ldr	w8, [x8, x23]
    51dc:      	ldr	x24, [x24]
    51e0:      	cmp	w8, #0x4
    51e4:      	b.ne	0x5218 <generic_uprobe_process_filter+0x2218>
    51e8:      	ldr	x9, [sp, #0xe8]
    51ec:      	mov	w8, #0x5eb8             // =24248
    51f0:      	add	x8, x9, x8
    51f4:      	ldr	x9, [x9, #0x5eb8]
    51f8:      	and	x9, x9, #0x1f
    51fc:      	add	x8, x8, x9
    5200:      	mov	w9, #0x1                // =1
    5204:      	strb	w9, [x8, #0x9]
    5208:      	ldr	x8, [sp, #0x40]
    520c:      	strb	w9, [x8, #0x20]
    5210:      	strb	w9, [x8]
    5214:      	b	0x52d4 <generic_uprobe_process_filter+0x22d4>
    5218:      	add	w8, w9, #0x4
    521c:      	and	x8, x8, #0x3ff
    5220:      	add	x8, x8, x23
    5224:      	ldp	w21, w19, [x8]
    5228:      	ldr	w22, [x8, #0x8]
    522c:      	ldur	x20, [x8, #0xc]
    5230:      	mov	w8, #0xe                // =14
    5234:      	blr	x8
    5238:      	lsr	x8, x0, #32
    523c:      	add	x9, sp, #0x58
    5240:      	add	x1, sp, #0x58
    5244:      	str	w8, [sp, #0x58]
    5248:      	mov	w8, #0x1                // =1
    524c:      	mov	x0, x24
    5250:      	blr	x8
    5254:      	cbz	x0, 0x52d4 <generic_uprobe_process_filter+0x22d4>
    5258:      	cmp	w21, #0x2
    525c:      	cbz	w22, 0x5278 <generic_uprobe_process_filter+0x2278>
    5260:      	b.hi	0x52d4 <generic_uprobe_process_filter+0x22d4>
    5264:      	ldr	x8, [sp, #0xe8]
    5268:      	ldr	w8, [x8, #0x44]
    526c:      	cmp	w8, w22
    5270:      	b.ne	0x527c <generic_uprobe_process_filter+0x227c>
    5274:      	b	0x52d4 <generic_uprobe_process_filter+0x22d4>
    5278:      	b.hi	0x52d4 <generic_uprobe_process_filter+0x22d4>
    527c:      	ldr	x8, [sp, #0xe8]
    5280:      	lsl	x10, x21, #3
    5284:      	add	x9, x8, #0x48
    5288:      	add	x8, x0, x21, lsl #3
    528c:      	ldr	x8, [x8, #0x50]
    5290:      	ldr	x9, [x9, x10]
    5294:      	eor	x10, x9, x8
    5298:      	tst	x10, x20
    529c:      	b.eq	0x52ac <generic_uprobe_process_filter+0x22ac>
    52a0:      	cmp	w19, #0x5
    52a4:      	b.eq	0x52bc <generic_uprobe_process_filter+0x22bc>
    52a8:      	b	0x52d4 <generic_uprobe_process_filter+0x22d4>
    52ac:      	cmp	x8, x9
    52b0:      	b.eq	0x52d4 <generic_uprobe_process_filter+0x22d4>
    52b4:      	cmp	w19, #0x6
    52b8:      	b.ne	0x52d4 <generic_uprobe_process_filter+0x22d4>
    52bc:      	ldr	x9, [sp, #0xe8]
    52c0:      	mov	w8, #0x1                // =1
    52c4:      	str	x8, [x9, #0x5ef0]
    52c8:      	b	0x51e8 <generic_uprobe_process_filter+0x21e8>
    52cc:      	mov	w9, #0x1                // =1
    52d0:      	str	x9, [x8]
    52d4:      	ldr	x9, [sp, #0xe8]
    52d8:      	ldr	x10, [sp, #0x28]
    52dc:      	ldr	x8, [x9, #0x5eb8]
    52e0:      	add	x8, x8, #0x1
    52e4:      	cmp	x8, x10
    52e8:      	str	x8, [x9, #0x5eb8]
    52ec:      	b.ls	0x534c <generic_uprobe_process_filter+0x234c>
    52f0:      	ldr	x10, [sp, #0x48]
    52f4:      	ldr	w8, [x10]
    52f8:      	str	w8, [x9, #0x10]
    52fc:      	ldr	x8, [x10, #0x8]
    5300:      	str	x8, [x9, #0x18]
    5304:      	ldp	x20, x8, [sp, #0x38]
    5308:      	ldrb	w8, [x8]
    530c:      	cbz	w8, 0x532c <generic_uprobe_process_filter+0x232c>
    5310:      	adrp	x1, 0x5000 <generic_uprobe_process_filter+0x2000>
    5314:      	mov	x8, xzr
    5318:      	mov	w9, #0xc                // =12
    531c:      	ldr	x1, [x1]
    5320:      	mov	x0, x20
    5324:      	mov	w2, wzr
    5328:      	blr	x9
    532c:      	ldp	x20, x19, [sp, #0x120]
    5330:      	mov	w0, wzr
    5334:      	ldr	x29, [sp, #0xe0]
    5338:      	ldp	x22, x21, [sp, #0x110]
    533c:      	ldp	x24, x23, [sp, #0x100]
    5340:      	ldp	x30, x25, [sp, #0xf0]
    5344:      	add	sp, sp, #0x130
    5348:      	ret
    534c:      	adrp	x1, 0x5000 <generic_uprobe_process_filter+0x2000>
    5350:      	mov	w8, #0x2                // =2
    5354:      	mov	w9, #0xc                // =12
    5358:      	ldr	x1, [x1]
    535c:      	ldr	x0, [sp, #0x38]
    5360:      	mov	w2, #0x2                // =2
    5364:      	b	0x5328 <generic_uprobe_process_filter+0x2328>
    5368:      	nop
    536c:      	nop

0000000000005370 <generic_uprobe_filter_arg>:
    5370:      	sub	sp, sp, #0x70
    5374:      	str	x29, [sp, #0x20]
    5378:      	stp	x30, x25, [sp, #0x30]
    537c:      	stp	x24, x23, [sp, #0x40]
    5380:      	stp	x22, x21, [sp, #0x50]
    5384:      	stp	x20, x19, [sp, #0x60]
    5388:      	mov	x19, x0
    538c:      	str	wzr, [sp, #0x2c]
    5390:      	adrp	x0, 0x5000 <generic_uprobe_process_filter+0x2000>
    5394:      	mov	w8, #0x1                // =1
    5398:      	ldr	x0, [x0]
    539c:      	add	x9, sp, #0x2c
    53a0:      	add	x1, sp, #0x2c
    53a4:      	blr	x8
    53a8:      	cbz	x0, 0x5734 <generic_uprobe_filter_arg+0x3c4>
    53ac:      	mov	w8, #0x5ec1             // =24257
    53b0:      	mov	x20, x0
    53b4:      	add	x22, x0, x8
    53b8:      	mov	w8, #0x5ef8             // =24312
    53bc:      	add	x1, x0, x8
    53c0:      	adrp	x0, 0x5000 <generic_uprobe_process_filter+0x2000>
    53c4:      	ldur	w23, [x22, #0x3f]
    53c8:      	mov	w8, #0x1                // =1
    53cc:      	ldr	x0, [x0]
    53d0:      	blr	x8
    53d4:      	cbz	x0, 0x5718 <generic_uprobe_filter_arg+0x3a8>
    53d8:      	ldrb	w8, [x22, #0x1f]
    53dc:      	cbz	w8, 0x5718 <generic_uprobe_filter_arg+0x3a8>
    53e0:      	and	x8, x23, #0x7
    53e4:      	mov	w10, #0x5ec1            // =24257
    53e8:      	add	x9, x20, x8
    53ec:      	ldrb	w9, [x9, x10]
    53f0:      	cbz	w9, 0x5470 <generic_uprobe_filter_arg+0x100>
    53f4:      	lsl	w8, w8, #2
    53f8:      	mov	x21, x0
    53fc:      	add	x8, x8, #0x4
    5400:      	ldr	w9, [x8, x0]
    5404:      	add	x8, x8, x9
    5408:      	add	x8, x8, #0x4
    540c:      	and	x9, x8, #0x3ff
    5410:      	ldr	w9, [x9, x0]
    5414:      	add	x8, x8, x9
    5418:      	and	x9, x8, #0x3ff
    541c:      	ldr	w9, [x9, x0]
    5420:      	add	x8, x8, x9
    5424:      	and	x9, x8, #0x3ff
    5428:      	ldr	w9, [x9, x0]
    542c:      	add	x8, x8, x9
    5430:      	and	x9, x8, #0x3ff
    5434:      	ldr	w9, [x9, x0]
    5438:      	add	x8, x8, x9
    543c:      	and	x9, x8, #0x3ff
    5440:      	ldr	w9, [x9, x0]
    5444:      	add	x25, x8, x9
    5448:      	and	x8, x25, #0x3ff
    544c:      	add	x29, x0, x8
    5450:      	str	x8, [sp, #0x8]
    5454:      	ldr	w8, [x29]
    5458:      	cmp	w8, #0x19
    545c:      	b.hs	0x54b8 <generic_uprobe_filter_arg+0x148>
    5460:      	ldr	x8, [sp, #0x8]
    5464:      	cmp	w8, #0x1
    5468:      	b.eq	0x5718 <generic_uprobe_filter_arg+0x3a8>
    546c:      	cbnz	w8, 0x56f4 <generic_uprobe_filter_arg+0x384>
    5470:      	cmp	w23, #0x1
    5474:      	b.gt	0x5490 <generic_uprobe_filter_arg+0x120>
    5478:      	cmn	w23, #0x1
    547c:      	b.eq	0x5754 <generic_uprobe_filter_arg+0x3e4>
    5480:      	cbz	w23, 0x5764 <generic_uprobe_filter_arg+0x3f4>
    5484:      	cmp	w23, #0x1
    5488:      	b.eq	0x5774 <generic_uprobe_filter_arg+0x404>
    548c:      	b	0x54a8 <generic_uprobe_filter_arg+0x138>
    5490:      	cmp	w23, #0x2
    5494:      	b.eq	0x5784 <generic_uprobe_filter_arg+0x414>
    5498:      	cmp	w23, #0x3
    549c:      	b.eq	0x5794 <generic_uprobe_filter_arg+0x424>
    54a0:      	cmp	w23, #0x4
    54a4:      	b.eq	0x57a4 <generic_uprobe_filter_arg+0x434>
    54a8:      	cmp	w23, #0x4
    54ac:      	b.gt	0x57d0 <generic_uprobe_filter_arg+0x460>
    54b0:      	add	w8, w23, #0x1
    54b4:      	b	0x57b0 <generic_uprobe_filter_arg+0x440>
    54b8:      	mov	w24, #0x4               // =4
    54bc:      	nop
    54c0:      	ldr	w8, [x29, x24]
    54c4:      	tst	w8, #0x3ff
    54c8:      	b.eq	0x5460 <generic_uprobe_filter_arg+0xf0>
    54cc:      	add	w8, w25, w8
    54d0:      	and	x8, x8, #0x3ff
    54d4:      	add	x0, x21, x8
    54d8:      	ldr	w9, [x0, #0x4]
    54dc:      	cmp	w9, #0x23
    54e0:      	b.eq	0x5470 <generic_uprobe_filter_arg+0x100>
    54e4:      	ldr	w8, [x0]
    54e8:      	cmp	w8, #0x4
    54ec:      	b.hi	0x5470 <generic_uprobe_filter_arg+0x100>
    54f0:      	add	x10, x20, x8, lsl #2
    54f4:      	mov	w11, #0x5ea0            // =24224
    54f8:      	ldr	w10, [x10, x11]
    54fc:      	cbnz	w10, 0x5470 <generic_uprobe_filter_arg+0x100>
    5500:      	add	x8, x20, x8, lsl #3
    5504:      	ldr	x8, [x8, #0x5e78]
    5508:      	and	x8, x8, #0x7ff
    550c:      	add	x8, x20, x8
    5510:      	add	x1, x8, #0x90
    5514:      	ldr	w8, [x0, #0xc]
    5518:      	cmp	w8, #0x1b
    551c:      	b.le	0x5540 <generic_uprobe_filter_arg+0x1d0>
    5520:      	cmp	w8, #0x25
    5524:      	b.gt	0x5574 <generic_uprobe_filter_arg+0x204>
    5528:      	sub	w10, w8, #0x1c
    552c:      	cmp	w10, #0x9
    5530:      	b.lo	0x55b8 <generic_uprobe_filter_arg+0x248>
    5534:      	cmp	w8, #0x25
    5538:      	b.eq	0x56a0 <generic_uprobe_filter_arg+0x330>
    553c:      	b	0x56e4 <generic_uprobe_filter_arg+0x374>
    5540:      	cmp	w8, #0x9
    5544:      	b.le	0x5598 <generic_uprobe_filter_arg+0x228>
    5548:      	sub	w10, w8, #0xa
    554c:      	cmp	w10, #0x4
    5550:      	b.lo	0x55b8 <generic_uprobe_filter_arg+0x248>
    5554:      	sub	w9, w8, #0xf
    5558:      	cmp	w9, #0x2
    555c:      	b.lo	0x56a0 <generic_uprobe_filter_arg+0x330>
    5560:      	cmp	w8, #0x11
    5564:      	b.ne	0x56e4 <generic_uprobe_filter_arg+0x374>
    5568:      	add	x1, x1, #0x4
    556c:      	bl	0x556c <generic_uprobe_filter_arg+0x1fc>
    5570:      	b	0x56e0 <generic_uprobe_filter_arg+0x370>
    5574:      	cmp	w8, #0x29
    5578:      	b.gt	0x5688 <generic_uprobe_filter_arg+0x318>
    557c:      	sub	w9, w8, #0x26
    5580:      	cmp	w9, #0x2
    5584:      	b.lo	0x563c <generic_uprobe_filter_arg+0x2cc>
    5588:      	sub	w8, w8, #0x28
    558c:      	cmp	w8, #0x2
    5590:      	b.lo	0x5634 <generic_uprobe_filter_arg+0x2c4>
    5594:      	b	0x56e4 <generic_uprobe_filter_arg+0x374>
    5598:      	cmp	w8, #0x4
    559c:      	b.gt	0x561c <generic_uprobe_filter_arg+0x2ac>
    55a0:      	cmp	w8, #0x1
    55a4:      	b.eq	0x55b8 <generic_uprobe_filter_arg+0x248>
    55a8:      	cmp	w8, #0x2
    55ac:      	b.eq	0x56c4 <generic_uprobe_filter_arg+0x354>
    55b0:      	cmp	w8, #0x4
    55b4:      	b.ne	0x56e4 <generic_uprobe_filter_arg+0x374>
    55b8:      	cmp	w8, #0xb
    55bc:      	b.le	0x55fc <generic_uprobe_filter_arg+0x28c>
    55c0:      	cmp	w8, #0x24
    55c4:      	b.hi	0x56a8 <generic_uprobe_filter_arg+0x338>
    55c8:      	mov	w11, #0x1               // =1
    55cc:      	lsl	x10, x11, x8
    55d0:      	tst	x10, #0x1e00000000
    55d4:      	b.ne	0x5644 <generic_uprobe_filter_arg+0x2d4>
    55d8:      	lsl	x9, x11, x8
    55dc:      	tst	x9, #0x60000000
    55e0:      	mov	w9, #0x1                // =1
    55e4:      	b.ne	0x56bc <generic_uprobe_filter_arg+0x34c>
    55e8:      	lsl	x9, x9, x8
    55ec:      	tst	x9, #0x180000000
    55f0:      	b.eq	0x56a8 <generic_uprobe_filter_arg+0x338>
    55f4:      	bl	0x55f4 <generic_uprobe_filter_arg+0x284>
    55f8:      	b	0x56e0 <generic_uprobe_filter_arg+0x370>
    55fc:      	sub	w9, w8, #0xa
    5600:      	cmp	w9, #0x2
    5604:      	b.lo	0x56d8 <generic_uprobe_filter_arg+0x368>
    5608:      	cmp	w8, #0x1
    560c:      	b.eq	0x56b4 <generic_uprobe_filter_arg+0x344>
    5610:      	cmp	w8, #0x4
    5614:      	b.eq	0x56b4 <generic_uprobe_filter_arg+0x344>
    5618:      	b	0x56e4 <generic_uprobe_filter_arg+0x374>
    561c:      	cmp	w8, #0x5
    5620:      	b.eq	0x5634 <generic_uprobe_filter_arg+0x2c4>
    5624:      	cmp	w8, #0x6
    5628:      	b.eq	0x563c <generic_uprobe_filter_arg+0x2cc>
    562c:      	cmp	w8, #0x7
    5630:      	b.ne	0x56e4 <generic_uprobe_filter_arg+0x374>
    5634:      	bl	0x5634 <generic_uprobe_filter_arg+0x2c4>
    5638:      	b	0x56e0 <generic_uprobe_filter_arg+0x370>
    563c:      	mov	w2, #0x4                // =4
    5640:      	b	0x56c8 <generic_uprobe_filter_arg+0x358>
    5644:      	cmp	w9, #0x1e
    5648:      	b.ne	0x56d8 <generic_uprobe_filter_arg+0x368>
    564c:      	ldr	w8, [x0, #0x10]
    5650:      	mov	w10, #0x5ea0            // =24224
    5654:      	and	x8, x8, #0x7
    5658:      	add	x9, x20, x8, lsl #2
    565c:      	ldr	w9, [x9, x10]
    5660:      	cbnz	w9, 0x5470 <generic_uprobe_filter_arg+0x100>
    5664:      	add	x8, x20, x8, lsl #3
    5668:      	ldr	x9, [x1]
    566c:      	ldr	x8, [x8, #0x5e78]
    5670:      	and	x8, x8, #0x7ff
    5674:      	add	x8, x20, x8
    5678:      	ldr	x8, [x8, #0x90]
    567c:      	bics	xzr, x8, x9
    5680:      	cset	w0, ne
    5684:      	b	0x56e0 <generic_uprobe_filter_arg+0x370>
    5688:      	cmp	w8, #0x2a
    568c:      	b.eq	0x56a0 <generic_uprobe_filter_arg+0x330>
    5690:      	cmp	w8, #0x2c
    5694:      	b.ne	0x56e4 <generic_uprobe_filter_arg+0x374>
    5698:      	bl	0x5698 <generic_uprobe_filter_arg+0x328>
    569c:      	b	0x56e0 <generic_uprobe_filter_arg+0x370>
    56a0:      	bl	0x56a0 <generic_uprobe_filter_arg+0x330>
    56a4:      	b	0x56e0 <generic_uprobe_filter_arg+0x370>
    56a8:      	sub	w9, w8, #0xc
    56ac:      	cmp	w9, #0x2
    56b0:      	b.hs	0x56d0 <generic_uprobe_filter_arg+0x360>
    56b4:      	bl	0x56b4 <generic_uprobe_filter_arg+0x344>
    56b8:      	b	0x56e0 <generic_uprobe_filter_arg+0x370>
    56bc:      	bl	0x56bc <generic_uprobe_filter_arg+0x34c>
    56c0:      	b	0x56e0 <generic_uprobe_filter_arg+0x370>
    56c4:      	mov	w2, #0x8                // =8
    56c8:      	bl	0x56c8 <generic_uprobe_filter_arg+0x358>
    56cc:      	b	0x56e0 <generic_uprobe_filter_arg+0x370>
    56d0:      	cmp	w8, #0x1c
    56d4:      	b.ne	0x56e4 <generic_uprobe_filter_arg+0x374>
    56d8:      	bl	0x56d8 <generic_uprobe_filter_arg+0x368>
    56dc:      	nop
    56e0:      	cbz	x0, 0x5470 <generic_uprobe_filter_arg+0x100>
    56e4:      	add	x24, x24, #0x4
    56e8:      	cmp	x24, #0x18
    56ec:      	b.ne	0x54c0 <generic_uprobe_filter_arg+0x150>
    56f0:      	b	0x5460 <generic_uprobe_filter_arg+0xf0>
    56f4:      	ldr	x8, [sp, #0x8]
    56f8:      	adrp	x1, 0x5000 <generic_uprobe_process_filter+0x2000>
    56fc:      	mov	w9, #0xc                // =12
    5700:      	mov	x0, x19
    5704:      	stur	w8, [x22, #0x43]
    5708:      	mov	w8, #0x4                // =4
    570c:      	mov	w2, #0x4                // =4
    5710:      	ldr	x1, [x1]
    5714:      	blr	x9
    5718:      	adrp	x1, 0x5000 <generic_uprobe_process_filter+0x2000>
    571c:      	mov	w8, #0x5                // =5
    5720:      	mov	w9, #0xc                // =12
    5724:      	ldr	x1, [x1]
    5728:      	mov	x0, x19
    572c:      	mov	w2, #0x5                // =5
    5730:      	blr	x9
    5734:      	ldp	x20, x19, [sp, #0x60]
    5738:      	mov	w0, wzr
    573c:      	ldr	x29, [sp, #0x20]
    5740:      	ldp	x22, x21, [sp, #0x50]
    5744:      	ldp	x24, x23, [sp, #0x40]
    5748:      	ldp	x30, x25, [sp, #0x30]
    574c:      	add	sp, sp, #0x70
    5750:      	ret
    5754:      	ldrb	w8, [x22]
    5758:      	cbz	w8, 0x5764 <generic_uprobe_filter_arg+0x3f4>
    575c:      	mov	w8, wzr
    5760:      	b	0x57b0 <generic_uprobe_filter_arg+0x440>
    5764:      	ldrb	w8, [x22, #0x1]
    5768:      	cbz	w8, 0x5774 <generic_uprobe_filter_arg+0x404>
    576c:      	mov	w8, #0x1                // =1
    5770:      	b	0x57b0 <generic_uprobe_filter_arg+0x440>
    5774:      	ldrb	w8, [x22, #0x2]
    5778:      	cbz	w8, 0x5784 <generic_uprobe_filter_arg+0x414>
    577c:      	mov	w8, #0x2                // =2
    5780:      	b	0x57b0 <generic_uprobe_filter_arg+0x440>
    5784:      	ldrb	w8, [x22, #0x3]
    5788:      	cbz	w8, 0x5794 <generic_uprobe_filter_arg+0x424>
    578c:      	mov	w8, #0x3                // =3
    5790:      	b	0x57b0 <generic_uprobe_filter_arg+0x440>
    5794:      	ldrb	w8, [x22, #0x4]
    5798:      	cbz	w8, 0x57a4 <generic_uprobe_filter_arg+0x434>
    579c:      	mov	w8, #0x4                // =4
    57a0:      	b	0x57b0 <generic_uprobe_filter_arg+0x440>
    57a4:      	ldrb	w8, [x22, #0x5]
    57a8:      	cbz	w8, 0x57d0 <generic_uprobe_filter_arg+0x460>
    57ac:      	mov	w8, #0x5                // =5
    57b0:      	stur	w8, [x22, #0x3f]
    57b4:      	adrp	x1, 0x5000 <generic_uprobe_process_filter+0x2000>
    57b8:      	mov	w8, #0x3                // =3
    57bc:      	mov	w9, #0xc                // =12
    57c0:      	ldr	x1, [x1]
    57c4:      	mov	x0, x19
    57c8:      	mov	w2, #0x3                // =3
    57cc:      	blr	x9
    57d0:      	ldr	x19, [x20, #0x60]
    57d4:      	mov	w8, #0xe                // =14
    57d8:      	blr	x8
    57dc:      	stp	x19, x0, [sp, #0x10]
    57e0:      	adrp	x19, 0x5000 <generic_uprobe_process_filter+0x2000>
    57e4:      	mov	w8, #0x1                // =1
    57e8:      	add	x9, sp, #0x10
    57ec:      	add	x1, sp, #0x10
    57f0:      	ldr	x19, [x19]
    57f4:      	mov	x0, x19
    57f8:      	blr	x8
    57fc:      	cbz	x0, 0x5734 <generic_uprobe_filter_arg+0x3c4>
    5800:      	mov	w8, #0x3                // =3
    5804:      	add	x9, sp, #0x10
    5808:      	add	x1, sp, #0x10
    580c:      	mov	x0, x19
    5810:      	blr	x8
    5814:      	b	0x5734 <generic_uprobe_filter_arg+0x3c4>
    5818:      	nop
    581c:      	nop

0000000000005820 <generic_uprobe_actions>:
    5820:      	sub	sp, sp, #0x40
    5824:      	str	x30, [sp, #0x10]
    5828:      	stp	x22, x21, [sp, #0x20]
    582c:      	stp	x20, x19, [sp, #0x30]
    5830:      	mov	x19, x0
    5834:      	str	wzr, [sp, #0xc]
    5838:      	adrp	x0, 0x5000 <generic_uprobe_process_filter+0x2000>
    583c:      	mov	w8, #0x1                // =1
    5840:      	ldr	x0, [x0]
    5844:      	add	x9, sp, #0xc
    5848:      	add	x1, sp, #0xc
    584c:      	blr	x8
    5850:      	cbz	x0, 0x5968 <generic_uprobe_actions+0x148>
    5854:      	mov	w8, #0x5f04             // =24324
    5858:      	ldr	w22, [x0, x8]
    585c:      	cmp	w22, #0x2
    5860:      	b.lt	0x5968 <generic_uprobe_actions+0x148>
    5864:      	mov	w8, #0x5ef8             // =24312
    5868:      	mov	w20, #0x1               // =1
    586c:      	add	x1, x0, x8
    5870:      	adrp	x0, 0x5000 <generic_uprobe_process_filter+0x2000>
    5874:      	mov	w8, #0x1                // =1
    5878:      	ldr	x0, [x0]
    587c:      	blr	x8
    5880:      	cbz	x0, 0x5968 <generic_uprobe_actions+0x148>
    5884:      	and	x8, x22, #0x7ff
    5888:      	mov	x21, x0
    588c:      	strb	w20, [sp, #0x1c]
    5890:      	mov	w9, #0x1                // =1
    5894:      	ldr	w8, [x0, x8]
    5898:      	str	wzr, [sp, #0x18]
    589c:      	adrp	x0, 0x5000 <generic_uprobe_process_filter+0x2000>
    58a0:      	add	x1, sp, #0x18
    58a4:      	ldr	x0, [x0]
    58a8:      	add	w8, w8, w22
    58ac:      	and	w22, w8, #0x7ff
    58b0:      	add	x8, sp, #0x18
    58b4:      	blr	x9
    58b8:      	cbz	x0, 0x58c8 <generic_uprobe_actions+0xa8>
    58bc:      	ldrb	w8, [x0]
    58c0:      	cmp	w8, #0x0
    58c4:      	cset	w20, eq
    58c8:      	ldr	w8, [x21, x22]
    58cc:      	cmp	w8, #0x5
    58d0:      	b.lo	0x5944 <generic_uprobe_actions+0x124>
    58d4:      	add	x2, x21, x22
    58d8:      	add	x3, sp, #0x1c
    58dc:      	mov	x0, x19
    58e0:      	mov	w1, wzr
    58e4:      	mov	w4, w20
    58e8:      	bl	0x58e8 <generic_uprobe_actions+0xc8>
    58ec:      	ldr	w9, [x21, x22]
    58f0:      	lsl	w8, w0, #2
    58f4:      	add	w8, w8, #0x4
    58f8:      	cmp	w8, w9
    58fc:      	b.hs	0x5944 <generic_uprobe_actions+0x124>
    5900:      	mov	w1, w0
    5904:      	add	x2, x21, x22
    5908:      	add	x3, sp, #0x1c
    590c:      	mov	x0, x19
    5910:      	mov	w4, w20
    5914:      	bl	0x5914 <generic_uprobe_actions+0xf4>
    5918:      	ldr	w9, [x21, x22]
    591c:      	lsl	w8, w0, #2
    5920:      	add	w8, w8, #0x4
    5924:      	cmp	w8, w9
    5928:      	b.hs	0x5944 <generic_uprobe_actions+0x124>
    592c:      	mov	w1, w0
    5930:      	add	x2, x21, x22
    5934:      	add	x3, sp, #0x1c
    5938:      	mov	x0, x19
    593c:      	mov	w4, w20
    5940:      	bl	0x5940 <generic_uprobe_actions+0x120>
    5944:      	ldrb	w8, [sp, #0x1c]
    5948:      	cbz	w8, 0x5968 <generic_uprobe_actions+0x148>
    594c:      	adrp	x1, 0x5000 <generic_uprobe_process_filter+0x2000>
    5950:      	mov	w8, #0x5                // =5
    5954:      	mov	w9, #0xc                // =12
    5958:      	ldr	x1, [x1]
    595c:      	mov	x0, x19
    5960:      	mov	w2, #0x5                // =5
    5964:      	blr	x9
    5968:      	ldp	x20, x19, [sp, #0x30]
    596c:      	mov	w0, wzr
    5970:      	ldr	x30, [sp, #0x10]
    5974:      	ldp	x22, x21, [sp, #0x20]
    5978:      	add	sp, sp, #0x40
    597c:      	ret

0000000000005980 <generic_uprobe_output>:
    5980:      	sub	sp, sp, #0xc0
    5984:      	str	x29, [sp, #0x70]
    5988:      	stp	x30, x25, [sp, #0x80]
    598c:      	stp	x24, x23, [sp, #0x90]
    5990:      	stp	x22, x21, [sp, #0xa0]
    5994:      	stp	x20, x19, [sp, #0xb0]
    5998:      	mov	x20, x0
    599c:      	str	wzr, [sp, #0x4]
    59a0:      	adrp	x0, 0x5000 <generic_uprobe_process_filter+0x2000>
    59a4:      	mov	w8, #0x1                // =1
    59a8:      	ldr	x0, [x0]
    59ac:      	add	x9, sp, #0x4
    59b0:      	add	x1, sp, #0x4
    59b4:      	blr	x8
    59b8:      	cbz	x0, 0x5f50 <generic_uprobe_output+0x5d0>
    59bc:      	adrp	x21, 0x5000 <generic_uprobe_process_filter+0x2000>
    59c0:      	ldr	x8, [x0, #0x5ee8]
    59c4:      	mov	x19, x0
    59c8:      	ldr	x21, [x21]
    59cc:      	cbz	x8, 0x5c58 <generic_uprobe_output+0x2d8>
    59d0:      	mov	w8, #0xe                // =14
    59d4:      	blr	x8
    59d8:      	mov	w8, #0x23               // =35
    59dc:      	lsr	x22, x0, #32
    59e0:      	blr	x8
    59e4:      	str	w22, [sp, #0x28]
    59e8:      	mov	w8, #0x1                // =1
    59ec:      	add	x9, sp, #0x28
    59f0:      	mov	x23, x0
    59f4:      	add	x1, sp, #0x28
    59f8:      	mov	x0, x21
    59fc:      	blr	x8
    5a00:      	cbz	x0, 0x5c58 <generic_uprobe_output+0x2d8>
    5a04:      	add	x2, x23, #0xb50
    5a08:      	mov	w29, #0x8               // =8
    5a0c:      	add	x8, sp, #0x78
    5a10:      	mov	w9, #0x4                // =4
    5a14:      	mov	x22, x0
    5a18:      	add	x24, x0, #0x28
    5a1c:      	add	x0, sp, #0x78
    5a20:      	mov	w1, #0x8                // =8
    5a24:      	mov	w25, #0x4               // =4
    5a28:      	blr	x9
    5a2c:      	ldr	x8, [sp, #0x78]
    5a30:      	mov	w9, #0x48               // =72
    5a34:      	add	x10, sp, #0x28
    5a38:      	mov	w11, #0x4               // =4
    5a3c:      	ldr	x2, [sp, #0x78]
    5a40:      	add	x0, sp, #0x28
    5a44:      	mov	w1, #0x48               // =72
    5a48:      	blr	x11
    5a4c:      	ldr	x8, [sp, #0x30]
    5a50:      	mov	w9, #0x4                // =4
    5a54:      	mov	x0, x24
    5a58:      	mov	w1, #0x4                // =4
    5a5c:      	add	x8, x8, #0x218
    5a60:      	ldr	x8, [sp, #0x30]
    5a64:      	add	x2, x8, #0x218
    5a68:      	blr	x9
    5a6c:      	ldr	x8, [sp, #0x38]
    5a70:      	add	x0, x22, #0x2c
    5a74:      	mov	w9, #0x4                // =4
    5a78:      	mov	w1, #0x4                // =4
    5a7c:      	add	x8, x8, #0x4d8
    5a80:      	ldr	x8, [sp, #0x38]
    5a84:      	add	x2, x8, #0x4d8
    5a88:      	blr	x9
    5a8c:      	ldr	x8, [sp, #0x40]
    5a90:      	add	x0, x22, #0x30
    5a94:      	mov	w9, #0x4                // =4
    5a98:      	mov	w1, #0x4                // =4
    5a9c:      	add	x8, x8, #0x58
    5aa0:      	ldr	x8, [sp, #0x40]
    5aa4:      	add	x2, x8, #0x58
    5aa8:      	blr	x9
    5aac:      	str	xzr, [sp, #0x20]
    5ab0:      	add	x2, x23, #0x938
    5ab4:      	add	x8, sp, #0x20
    5ab8:      	add	x0, sp, #0x20
    5abc:      	mov	w1, #0x8                // =8
    5ac0:      	blr	x25
    5ac4:      	ldr	x8, [sp, #0x20]
    5ac8:      	cbz	x8, 0x5b4c <generic_uprobe_output+0x1cc>
    5acc:      	str	wzr, [sp, #0x1c]
    5ad0:      	add	x8, x8, #0x4
    5ad4:      	add	x9, sp, #0x1c
    5ad8:      	mov	w10, #0x4               // =4
    5adc:      	add	x0, sp, #0x1c
    5ae0:      	mov	w1, #0x4                // =4
    5ae4:      	mov	w24, #0x4               // =4
    5ae8:      	ldr	x8, [sp, #0x20]
    5aec:      	add	x2, x8, #0x4
    5af0:      	blr	x10
    5af4:      	ldr	x8, [sp, #0x20]
    5af8:      	ldrsw	x9, [sp, #0x1c]
    5afc:      	add	x10, sp, #0x8
    5b00:      	mov	w11, #0x4               // =4
    5b04:      	add	x0, sp, #0x8
    5b08:      	mov	w1, #0x10               // =16
    5b0c:      	add	x8, x8, x9, lsl #4
    5b10:      	mov	w9, #0x10               // =16
    5b14:      	add	x8, x8, #0x80
    5b18:      	ldr	x8, [sp, #0x20]
    5b1c:      	ldrsw	x9, [sp, #0x1c]
    5b20:      	add	x8, x8, x9, lsl #4
    5b24:      	add	x2, x8, #0x80
    5b28:      	blr	x11
    5b2c:      	ldr	x8, [sp, #0x10]
    5b30:      	add	x0, x22, #0x34
    5b34:      	mov	w1, #0x4                // =4
    5b38:      	add	x8, x8, #0x158
    5b3c:      	ldr	x8, [sp, #0x10]
    5b40:      	add	x2, x8, #0x158
    5b44:      	blr	x24
    5b48:      	b	0x5b50 <generic_uprobe_output+0x1d0>
    5b4c:      	str	wzr, [x22, #0x34]
    5b50:      	ldr	x8, [sp, #0x48]
    5b54:      	add	x0, x22, #0x38
    5b58:      	mov	w9, #0x4                // =4
    5b5c:      	mov	w1, #0x4                // =4
    5b60:      	mov	w24, #0x4               // =4
    5b64:      	add	x8, x8, #0x158
    5b68:      	ldr	x8, [sp, #0x48]
    5b6c:      	add	x2, x8, #0x158
    5b70:      	blr	x9
    5b74:      	ldr	x8, [sp, #0x50]
    5b78:      	add	x0, x22, #0x3c
    5b7c:      	mov	w9, #0x4                // =4
    5b80:      	mov	w1, #0x4                // =4
    5b84:      	add	x8, x8, #0x118
    5b88:      	ldr	x8, [sp, #0x50]
    5b8c:      	add	x2, x8, #0x118
    5b90:      	blr	x9
    5b94:      	ldr	x8, [sp, #0x58]
    5b98:      	add	x0, x22, #0x40
    5b9c:      	mov	w9, #0x4                // =4
    5ba0:      	mov	w1, #0x4                // =4
    5ba4:      	add	x8, x8, #0x98
    5ba8:      	ldr	x8, [sp, #0x58]
    5bac:      	add	x2, x8, #0x98
    5bb0:      	blr	x9
    5bb4:      	ldr	x8, [sp, #0x60]
    5bb8:      	add	x0, x22, #0x44
    5bbc:      	mov	w9, #0x4                // =4
    5bc0:      	mov	w1, #0x4                // =4
    5bc4:      	add	x8, x8, #0x98
    5bc8:      	ldr	x8, [sp, #0x60]
    5bcc:      	add	x2, x8, #0x98
    5bd0:      	blr	x9
    5bd4:      	ldr	x8, [sp, #0x68]
    5bd8:      	add	x0, x22, #0x48
    5bdc:      	mov	w9, #0x4                // =4
    5be0:      	mov	w1, #0x4                // =4
    5be4:      	add	x8, x8, #0x58
    5be8:      	ldr	x8, [sp, #0x68]
    5bec:      	add	x2, x8, #0x58
    5bf0:      	blr	x9
    5bf4:      	str	xzr, [sp, #0x8]
    5bf8:      	str	xzr, [sp, #0x20]
    5bfc:      	add	x2, x23, #0xae0
    5c00:      	mov	w23, #0x8               // =8
    5c04:      	add	x8, sp, #0x8
    5c08:      	mov	w9, #0x4                // =4
    5c0c:      	add	x0, sp, #0x8
    5c10:      	mov	w1, #0x8                // =8
    5c14:      	blr	x9
    5c18:      	ldr	x8, [sp, #0x8]
    5c1c:      	add	x9, sp, #0x20
    5c20:      	mov	w10, #0x4               // =4
    5c24:      	add	x0, sp, #0x20
    5c28:      	mov	w1, #0x8                // =8
    5c2c:      	add	x8, x8, #0x90
    5c30:      	ldr	x8, [sp, #0x8]
    5c34:      	add	x2, x8, #0x90
    5c38:      	blr	x10
    5c3c:      	ldr	x8, [sp, #0x20]
    5c40:      	add	x0, x22, #0x4c
    5c44:      	mov	w1, #0x4                // =4
    5c48:      	add	x8, x8, #0x158
    5c4c:      	ldr	x8, [sp, #0x20]
    5c50:      	add	x2, x8, #0x158
    5c54:      	blr	x24
    5c58:      	ldr	x8, [x19, #0x5ef0]
    5c5c:      	cbz	x8, 0x5cf8 <generic_uprobe_output+0x378>
    5c60:      	mov	w8, #0xe                // =14
    5c64:      	blr	x8
    5c68:      	mov	w8, #0x23               // =35
    5c6c:      	lsr	x23, x0, #32
    5c70:      	blr	x8
    5c74:      	str	w23, [sp, #0x28]
    5c78:      	mov	w8, #0x1                // =1
    5c7c:      	add	x9, sp, #0x28
    5c80:      	mov	x22, x0
    5c84:      	add	x1, sp, #0x28
    5c88:      	mov	x0, x21
    5c8c:      	blr	x8
    5c90:      	cbz	x0, 0x5cf8 <generic_uprobe_output+0x378>
    5c94:      	add	x2, x22, #0xae0
    5c98:      	mov	w22, #0x8               // =8
    5c9c:      	add	x8, sp, #0x28
    5ca0:      	mov	w9, #0x4                // =4
    5ca4:      	add	x21, x0, #0x50
    5ca8:      	mov	x24, x0
    5cac:      	add	x0, sp, #0x28
    5cb0:      	mov	w1, #0x8                // =8
    5cb4:      	mov	w23, #0x4               // =4
    5cb8:      	blr	x9
    5cbc:      	ldr	x25, [sp, #0x28]
    5cc0:      	add	x0, x24, #0x58
    5cc4:      	mov	w8, #0x4                // =4
    5cc8:      	mov	w1, #0x8                // =8
    5ccc:      	add	x2, x25, #0x40
    5cd0:      	blr	x8
    5cd4:      	add	x0, x24, #0x60
    5cd8:      	add	x2, x25, #0x30
    5cdc:      	mov	w8, #0x4                // =4
    5ce0:      	mov	w1, #0x8                // =8
    5ce4:      	blr	x8
    5ce8:      	add	x2, x25, #0x38
    5cec:      	mov	x0, x21
    5cf0:      	mov	w1, #0x8                // =8
    5cf4:      	blr	x23
    5cf8:      	ldr	w8, [x19, #0x4]
    5cfc:      	mov	w9, #0x2328             // =9000
    5d00:      	str	wzr, [sp, #0x8]
    5d04:      	adrp	x0, 0x5000 <generic_uprobe_process_filter+0x2000>
    5d08:      	add	x1, sp, #0x8
    5d0c:      	add	w8, w8, #0x90
    5d10:      	ldr	x0, [x0]
    5d14:      	and	w8, w8, #0x7fff
    5d18:      	cmp	w8, w9
    5d1c:      	csel	w21, w8, w9, lo
    5d20:      	mov	w8, #0x1                // =1
    5d24:      	add	x9, sp, #0x8
    5d28:      	blr	x8
    5d2c:      	cbz	x0, 0x5d98 <generic_uprobe_output+0x418>
    5d30:      	ldrb	w8, [x0, #0x28]
    5d34:      	cbz	w8, 0x5d98 <generic_uprobe_output+0x418>
    5d38:      	adrp	x1, 0x5000 <generic_uprobe_process_filter+0x2000>
    5d3c:      	mov	w8, #-0x1               // =-1
    5d40:      	mov	w9, #0x19               // =25
    5d44:      	ldr	x1, [x1]
    5d48:      	mov	x0, x20
    5d4c:      	mov	w2, #-0x1               // =-1
    5d50:      	mov	x3, x19
    5d54:      	mov	x4, x21
    5d58:      	blr	x9
    5d5c:      	tbnz	x0, #0x3f, 0x5e44 <generic_uprobe_output+0x4c4>
    5d60:      	str	wzr, [sp, #0x28]
    5d64:      	adrp	x0, 0x5000 <generic_uprobe_process_filter+0x2000>
    5d68:      	mov	w8, #0x1                // =1
    5d6c:      	add	x9, sp, #0x28
    5d70:      	ldr	x0, [x0]
    5d74:      	add	x1, sp, #0x28
    5d78:      	blr	x8
    5d7c:      	cbz	x0, 0x5f50 <generic_uprobe_output+0x5d0>
    5d80:      	add	x8, x0, #0x8
    5d84:      	ldaxr	x9, [x8]
    5d88:      	add	x9, x9, #0x1
    5d8c:      	stlxr	w10, x9, [x8]
    5d90:      	cbnz	w10, 0x5d84 <generic_uprobe_output+0x404>
    5d94:      	b	0x5f50 <generic_uprobe_output+0x5d0>
    5d98:      	adrp	x0, 0x5000 <generic_uprobe_process_filter+0x2000>
    5d9c:      	mov	x3, xzr
    5da0:      	mov	w8, #0x82               // =130
    5da4:      	ldr	x0, [x0]
    5da8:      	mov	x1, x19
    5dac:      	mov	x2, x21
    5db0:      	blr	x8
    5db4:      	tbnz	x0, #0x3f, 0x5df4 <generic_uprobe_output+0x474>
    5db8:      	str	wzr, [sp, #0x28]
    5dbc:      	adrp	x0, 0x5000 <generic_uprobe_process_filter+0x2000>
    5dc0:      	mov	w8, #0x1                // =1
    5dc4:      	add	x9, sp, #0x28
    5dc8:      	ldr	x0, [x0]
    5dcc:      	add	x1, sp, #0x28
    5dd0:      	blr	x8
    5dd4:      	cbz	x0, 0x5f50 <generic_uprobe_output+0x5d0>
    5dd8:      	add	x8, x0, #0x8
    5ddc:      	nop
    5de0:      	ldaxr	x9, [x8]
    5de4:      	add	x9, x9, #0x1
    5de8:      	stlxr	w10, x9, [x8]
    5dec:      	cbnz	w10, 0x5de0 <generic_uprobe_output+0x460>
    5df0:      	b	0x5f50 <generic_uprobe_output+0x5d0>
    5df4:      	mov	x19, x0
    5df8:      	str	wzr, [sp, #0x28]
    5dfc:      	adrp	x0, 0x5000 <generic_uprobe_process_filter+0x2000>
    5e00:      	mov	w8, #0x1                // =1
    5e04:      	ldr	x0, [x0]
    5e08:      	add	x9, sp, #0x28
    5e0c:      	add	x1, sp, #0x28
    5e10:      	blr	x8
    5e14:      	cbz	x0, 0x5f50 <generic_uprobe_output+0x5d0>
    5e18:      	mov	x8, x19
    5e1c:      	cmn	x19, #0xc
    5e20:      	b.gt	0x5e94 <generic_uprobe_output+0x514>
    5e24:      	cmn	x8, #0x1c
    5e28:      	b.eq	0x5ed4 <generic_uprobe_output+0x554>
    5e2c:      	cmn	x8, #0x16
    5e30:      	b.eq	0x5eec <generic_uprobe_output+0x56c>
    5e34:      	cmn	x8, #0x10
    5e38:      	b.ne	0x5ee4 <generic_uprobe_output+0x564>
    5e3c:      	add	x8, x0, #0x360
    5e40:      	b	0x5f00 <generic_uprobe_output+0x580>
    5e44:      	mov	x19, x0
    5e48:      	str	wzr, [sp, #0x28]
    5e4c:      	adrp	x0, 0x5000 <generic_uprobe_process_filter+0x2000>
    5e50:      	mov	w8, #0x1                // =1
    5e54:      	ldr	x0, [x0]
    5e58:      	add	x9, sp, #0x28
    5e5c:      	add	x1, sp, #0x28
    5e60:      	blr	x8
    5e64:      	cbz	x0, 0x5f50 <generic_uprobe_output+0x5d0>
    5e68:      	mov	x8, x19
    5e6c:      	cmn	x19, #0xc
    5e70:      	b.gt	0x5eb4 <generic_uprobe_output+0x534>
    5e74:      	cmn	x8, #0x1c
    5e78:      	b.eq	0x5f14 <generic_uprobe_output+0x594>
    5e7c:      	cmn	x8, #0x16
    5e80:      	b.eq	0x5f2c <generic_uprobe_output+0x5ac>
    5e84:      	cmn	x8, #0x10
    5e88:      	b.ne	0x5f24 <generic_uprobe_output+0x5a4>
    5e8c:      	add	x8, x0, #0x360
    5e90:      	b	0x5f40 <generic_uprobe_output+0x5c0>
    5e94:      	cmn	x8, #0xb
    5e98:      	b.eq	0x5edc <generic_uprobe_output+0x55c>
    5e9c:      	cmn	x8, #0x7
    5ea0:      	b.eq	0x5ef4 <generic_uprobe_output+0x574>
    5ea4:      	cmn	x8, #0x2
    5ea8:      	b.ne	0x5ee4 <generic_uprobe_output+0x564>
    5eac:      	add	x8, x0, #0x350
    5eb0:      	b	0x5f00 <generic_uprobe_output+0x580>
    5eb4:      	cmn	x8, #0xb
    5eb8:      	b.eq	0x5f1c <generic_uprobe_output+0x59c>
    5ebc:      	cmn	x8, #0x7
    5ec0:      	b.eq	0x5f34 <generic_uprobe_output+0x5b4>
    5ec4:      	cmn	x8, #0x2
    5ec8:      	b.ne	0x5f24 <generic_uprobe_output+0x5a4>
    5ecc:      	add	x8, x0, #0x350
    5ed0:      	b	0x5f40 <generic_uprobe_output+0x5c0>
    5ed4:      	add	x8, x0, #0x370
    5ed8:      	b	0x5f00 <generic_uprobe_output+0x580>
    5edc:      	add	x8, x0, #0x378
    5ee0:      	b	0x5f00 <generic_uprobe_output+0x580>
    5ee4:      	add	x8, x0, #0x348
    5ee8:      	b	0x5f00 <generic_uprobe_output+0x580>
    5eec:      	add	x8, x0, #0x368
    5ef0:      	b	0x5f00 <generic_uprobe_output+0x580>
    5ef4:      	add	x8, x0, #0x358
    5ef8:      	nop
    5efc:      	nop
    5f00:      	ldaxr	x9, [x8]
    5f04:      	add	x9, x9, #0x1
    5f08:      	stlxr	w10, x9, [x8]
    5f0c:      	cbnz	w10, 0x5f00 <generic_uprobe_output+0x580>
    5f10:      	b	0x5f50 <generic_uprobe_output+0x5d0>
    5f14:      	add	x8, x0, #0x370
    5f18:      	b	0x5f40 <generic_uprobe_output+0x5c0>
    5f1c:      	add	x8, x0, #0x378
    5f20:      	b	0x5f40 <generic_uprobe_output+0x5c0>
    5f24:      	add	x8, x0, #0x348
    5f28:      	b	0x5f40 <generic_uprobe_output+0x5c0>
    5f2c:      	add	x8, x0, #0x368
    5f30:      	b	0x5f40 <generic_uprobe_output+0x5c0>
    5f34:      	add	x8, x0, #0x358
    5f38:      	nop
    5f3c:      	nop
    5f40:      	ldaxr	x9, [x8]
    5f44:      	add	x9, x9, #0x1
    5f48:      	stlxr	w10, x9, [x8]
    5f4c:      	cbnz	w10, 0x5f40 <generic_uprobe_output+0x5c0>
    5f50:      	ldp	x20, x19, [sp, #0xb0]
    5f54:      	mov	w0, wzr
    5f58:      	ldr	x29, [sp, #0x70]
    5f5c:      	ldp	x22, x21, [sp, #0xa0]
    5f60:      	ldp	x24, x23, [sp, #0x90]
    5f64:      	ldp	x30, x25, [sp, #0x80]
    5f68:      	add	sp, sp, #0xc0
    5f6c:      	ret

Disassembly of section uprobe.multi/generic_uprobe:

0000000000000000 <generic_uprobe_event>:
       0:      	sub	sp, sp, #0xd0
       4:      	stp	x30, x25, [sp, #0x90]
       8:      	stp	x24, x23, [sp, #0xa0]
       c:      	stp	x22, x21, [sp, #0xb0]
      10:      	stp	x20, x19, [sp, #0xc0]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0xc]
      1c:      	adrp	x0, 0x0 <generic_uprobe_event>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0xc
      2c:      	add	x1, sp, #0xc
      30:      	blr	x8
      34:      	cbz	x0, 0x544 <generic_uprobe_event+0x544>
      38:      	mov	w8, #0xae               // =174
      3c:      	mov	x20, x0
      40:      	add	x23, x0, #0x5, lsl #12  // =0x5000
      44:      	mov	x0, x19
      48:      	blr	x8
      4c:      	str	w0, [x23, #0xef8]
      50:      	adrp	x0, 0x0 <generic_uprobe_event>
      54:      	add	x1, x23, #0xef8
      58:      	mov	w8, #0x1                // =1
      5c:      	ldr	x0, [x0]
      60:      	blr	x8
      64:      	cbz	x0, 0x544 <generic_uprobe_event+0x544>
      68:      	ldr	w8, [x0, #0x64]
      6c:      	str	w8, [sp, #0x1c]
      70:      	cbz	w8, 0x22c <generic_uprobe_event+0x22c>
      74:      	adrp	x21, 0x0 <generic_uprobe_event>
      78:      	mov	w8, #0x1                // =1
      7c:      	add	x9, sp, #0x1c
      80:      	ldr	x21, [x21]
      84:      	mov	x24, x0
      88:      	add	x1, sp, #0x1c
      8c:      	mov	x0, x21
      90:      	blr	x8
      94:      	cbz	x0, 0x544 <generic_uprobe_event+0x544>
      98:      	mov	x22, x0
      9c:      	str	wzr, [sp, #0x84]
      a0:      	adrp	x0, 0x0 <generic_uprobe_event>
      a4:      	mov	w8, #0x1                // =1
      a8:      	ldr	x0, [x0]
      ac:      	add	x9, sp, #0x84
      b0:      	add	x1, sp, #0x84
      b4:      	blr	x8
      b8:      	cbz	x0, 0xe4 <generic_uprobe_event+0xe4>
      bc:      	ldr	x8, [x0, #0x20]
      c0:      	mov	w9, #0x7270             // =29296
      c4:      	movk	w9, #0x6367, lsl #16
      c8:      	cmp	x8, x9
      cc:      	b.ne	0xec <generic_uprobe_event+0xec>
      d0:      	mov	w8, #0x50               // =80
      d4:      	blr	x8
      d8:      	str	x0, [sp, #0x30]
      dc:      	cbnz	x0, 0x1e0 <generic_uprobe_event+0x1e0>
      e0:      	b	0x544 <generic_uprobe_event+0x544>
      e4:      	mov	w25, wzr
      e8:      	b	0xf0 <generic_uprobe_event+0xf0>
      ec:      	ldr	w25, [x0, #0x10]
      f0:      	mov	w8, #0x23               // =35
      f4:      	blr	x8
      f8:      	str	xzr, [sp, #0x88]
      fc:      	add	x2, x0, #0xcd0
     100:      	mov	w8, #0x8                // =8
     104:      	mov	w9, #0x71               // =113
     108:      	add	x10, sp, #0x20
     10c:      	add	x0, sp, #0x20
     110:      	mov	w1, #0x8                // =8
     114:      	blr	x9
     118:      	ldr	x8, [sp, #0x20]
     11c:      	cbz	x8, 0x544 <generic_uprobe_event+0x544>
     120:      	cmp	w25, #0xb
     124:      	b.hi	0x544 <generic_uprobe_event+0x544>
     128:      	ubfiz	x9, x25, #3, #32
     12c:      	mov	w10, #0x8               // =8
     130:      	mov	w11, #0x71              // =113
     134:      	add	x12, sp, #0x38
     138:      	add	x0, sp, #0x38
     13c:      	mov	w1, #0x8                // =8
     140:      	add	x8, x8, x9
     144:      	ldr	x8, [sp, #0x20]
     148:      	add	x2, x8, x9
     14c:      	blr	x11
     150:      	ldr	x8, [sp, #0x38]
     154:      	cbz	x8, 0x544 <generic_uprobe_event+0x544>
     158:      	mov	w9, #0x8                // =8
     15c:      	mov	w10, #0x71              // =113
     160:      	add	x11, sp, #0x88
     164:      	ldr	x2, [sp, #0x38]
     168:      	add	x0, sp, #0x88
     16c:      	mov	w1, #0x8                // =8
     170:      	blr	x10
     174:      	ldr	x8, [sp, #0x88]
     178:      	cbz	x8, 0x544 <generic_uprobe_event+0x544>
     17c:      	str	xzr, [sp, #0x38]
     180:      	add	x2, x8, #0x100
     184:      	mov	w8, #0x8                // =8
     188:      	mov	w9, #0x71               // =113
     18c:      	add	x10, sp, #0x38
     190:      	add	x0, sp, #0x38
     194:      	mov	w1, #0x8                // =8
     198:      	blr	x9
     19c:      	ldr	x8, [sp, #0x38]
     1a0:      	str	xzr, [sp, #0x38]
     1a4:      	cbz	x8, 0x1d4 <generic_uprobe_event+0x1d4>
     1a8:      	add	x2, x8, #0x60
     1ac:      	mov	w8, #0x8                // =8
     1b0:      	mov	w9, #0x71               // =113
     1b4:      	add	x10, sp, #0x38
     1b8:      	add	x0, sp, #0x38
     1bc:      	mov	w1, #0x8                // =8
     1c0:      	blr	x9
     1c4:      	ldr	x0, [sp, #0x38]
     1c8:      	str	x0, [sp, #0x30]
     1cc:      	cbnz	x0, 0x1e0 <generic_uprobe_event+0x1e0>
     1d0:      	b	0x544 <generic_uprobe_event+0x544>
     1d4:      	mov	x0, xzr
     1d8:      	str	xzr, [sp, #0x30]
     1dc:      	cbz	xzr, 0x544 <generic_uprobe_event+0x544>
     1e0:      	str	x0, [sp, #0x38]
     1e4:      	adrp	x0, 0x0 <generic_uprobe_event>
     1e8:      	mov	w8, #0x1                // =1
     1ec:      	add	x9, sp, #0x38
     1f0:      	ldr	x0, [x0]
     1f4:      	add	x1, sp, #0x38
     1f8:      	blr	x8
     1fc:      	cbz	x0, 0x20c <generic_uprobe_event+0x20c>
     200:      	ldr	x8, [x0]
     204:      	cbz	x8, 0x20c <generic_uprobe_event+0x20c>
     208:      	str	x8, [sp, #0x30]
     20c:      	mov	w8, #0x1                // =1
     210:      	add	x9, sp, #0x30
     214:      	add	x1, sp, #0x30
     218:      	mov	x0, x22
     21c:      	blr	x8
     220:      	mov	x8, x0
     224:      	mov	x0, x24
     228:      	cbz	x8, 0x560 <generic_uprobe_event+0x560>
     22c:      	ldr	w8, [x0]
     230:      	add	x9, x23, #0xefc
     234:      	str	xzr, [x20, #0x5eb8]
     238:      	str	xzr, [x20, #0x5ec0]
     23c:      	str	xzr, [x20, #0x5ec8]
     240:      	str	xzr, [x9]
     244:      	str	xzr, [x20, #0x5ed0]
     248:      	str	xzr, [x20, #0x5ed8]
     24c:      	stp	x8, xzr, [x20, #0x60]
     250:      	mov	w8, #0x5eb8             // =24248
     254:      	add	x8, x20, x8
     258:      	strb	wzr, [x8, #0x28]
     25c:      	mov	w8, #0x23               // =35
     260:      	blr	x8
     264:      	add	x2, x0, #0xb50
     268:      	mov	w25, #0x8               // =8
     26c:      	add	x8, sp, #0x88
     270:      	mov	w9, #0x4                // =4
     274:      	mov	x21, x0
     278:      	add	x0, sp, #0x88
     27c:      	mov	w1, #0x8                // =8
     280:      	add	x22, x20, #0x20
     284:      	mov	w24, #0x4               // =4
     288:      	blr	x9
     28c:      	ldr	x8, [sp, #0x88]
     290:      	mov	w9, #0x48               // =72
     294:      	add	x10, sp, #0x38
     298:      	mov	w11, #0x4               // =4
     29c:      	ldr	x2, [sp, #0x88]
     2a0:      	add	x0, sp, #0x38
     2a4:      	mov	w1, #0x48               // =72
     2a8:      	blr	x11
     2ac:      	ldr	x8, [sp, #0x40]
     2b0:      	mov	w9, #0x4                // =4
     2b4:      	mov	x0, x22
     2b8:      	mov	w1, #0x4                // =4
     2bc:      	add	x8, x8, #0x218
     2c0:      	ldr	x8, [sp, #0x40]
     2c4:      	add	x2, x8, #0x218
     2c8:      	blr	x9
     2cc:      	ldr	x8, [sp, #0x48]
     2d0:      	add	x0, x20, #0x24
     2d4:      	mov	w9, #0x4                // =4
     2d8:      	mov	w1, #0x4                // =4
     2dc:      	add	x8, x8, #0x4d8
     2e0:      	ldr	x8, [sp, #0x48]
     2e4:      	add	x2, x8, #0x4d8
     2e8:      	blr	x9
     2ec:      	ldr	x8, [sp, #0x50]
     2f0:      	add	x0, x20, #0x28
     2f4:      	mov	w9, #0x4                // =4
     2f8:      	mov	w1, #0x4                // =4
     2fc:      	add	x8, x8, #0x58
     300:      	ldr	x8, [sp, #0x50]
     304:      	add	x2, x8, #0x58
     308:      	blr	x9
     30c:      	str	xzr, [sp, #0x30]
     310:      	add	x2, x21, #0x938
     314:      	add	x8, sp, #0x30
     318:      	add	x0, sp, #0x30
     31c:      	mov	w1, #0x8                // =8
     320:      	blr	x24
     324:      	ldr	x8, [sp, #0x30]
     328:      	cbz	x8, 0x3ac <generic_uprobe_event+0x3ac>
     32c:      	str	wzr, [sp, #0x10]
     330:      	add	x8, x8, #0x4
     334:      	add	x9, sp, #0x10
     338:      	mov	w10, #0x4               // =4
     33c:      	add	x0, sp, #0x10
     340:      	mov	w1, #0x4                // =4
     344:      	mov	w22, #0x4               // =4
     348:      	ldr	x8, [sp, #0x30]
     34c:      	add	x2, x8, #0x4
     350:      	blr	x10
     354:      	ldr	x8, [sp, #0x30]
     358:      	ldrsw	x9, [sp, #0x10]
     35c:      	add	x10, sp, #0x20
     360:      	mov	w11, #0x4               // =4
     364:      	add	x0, sp, #0x20
     368:      	mov	w1, #0x10               // =16
     36c:      	add	x8, x8, x9, lsl #4
     370:      	mov	w9, #0x10               // =16
     374:      	add	x8, x8, #0x80
     378:      	ldr	x8, [sp, #0x30]
     37c:      	ldrsw	x9, [sp, #0x10]
     380:      	add	x8, x8, x9, lsl #4
     384:      	add	x2, x8, #0x80
     388:      	blr	x11
     38c:      	ldr	x8, [sp, #0x28]
     390:      	add	x0, x20, #0x2c
     394:      	mov	w1, #0x4                // =4
     398:      	add	x8, x8, #0x158
     39c:      	ldr	x8, [sp, #0x28]
     3a0:      	add	x2, x8, #0x158
     3a4:      	blr	x22
     3a8:      	b	0x3b0 <generic_uprobe_event+0x3b0>
     3ac:      	str	wzr, [x20, #0x2c]
     3b0:      	ldr	x8, [sp, #0x58]
     3b4:      	add	x0, x20, #0x30
     3b8:      	mov	w9, #0x4                // =4
     3bc:      	mov	w1, #0x4                // =4
     3c0:      	mov	w24, #0x4               // =4
     3c4:      	add	x8, x8, #0x158
     3c8:      	ldr	x8, [sp, #0x58]
     3cc:      	add	x2, x8, #0x158
     3d0:      	blr	x9
     3d4:      	ldr	x8, [sp, #0x60]
     3d8:      	add	x0, x20, #0x34
     3dc:      	mov	w9, #0x4                // =4
     3e0:      	mov	w1, #0x4                // =4
     3e4:      	add	x8, x8, #0x118
     3e8:      	ldr	x8, [sp, #0x60]
     3ec:      	add	x2, x8, #0x118
     3f0:      	blr	x9
     3f4:      	ldr	x8, [sp, #0x68]
     3f8:      	add	x0, x20, #0x38
     3fc:      	mov	w9, #0x4                // =4
     400:      	mov	w1, #0x4                // =4
     404:      	add	x8, x8, #0x98
     408:      	ldr	x8, [sp, #0x68]
     40c:      	add	x2, x8, #0x98
     410:      	blr	x9
     414:      	ldr	x8, [sp, #0x70]
     418:      	add	x0, x20, #0x3c
     41c:      	mov	w9, #0x4                // =4
     420:      	mov	w1, #0x4                // =4
     424:      	add	x8, x8, #0x98
     428:      	ldr	x8, [sp, #0x70]
     42c:      	add	x2, x8, #0x98
     430:      	blr	x9
     434:      	ldr	x8, [sp, #0x78]
     438:      	add	x0, x20, #0x40
     43c:      	mov	w9, #0x4                // =4
     440:      	mov	w1, #0x4                // =4
     444:      	add	x8, x8, #0x58
     448:      	ldr	x8, [sp, #0x78]
     44c:      	add	x2, x8, #0x58
     450:      	blr	x9
     454:      	str	xzr, [sp, #0x20]
     458:      	str	xzr, [sp, #0x30]
     45c:      	add	x21, x21, #0xae0
     460:      	mov	w25, #0x8               // =8
     464:      	add	x8, sp, #0x20
     468:      	mov	w9, #0x4                // =4
     46c:      	add	x0, sp, #0x20
     470:      	mov	w1, #0x8                // =8
     474:      	mov	x2, x21
     478:      	blr	x9
     47c:      	ldr	x8, [sp, #0x20]
     480:      	add	x9, sp, #0x30
     484:      	mov	w10, #0x4               // =4
     488:      	add	x0, sp, #0x30
     48c:      	mov	w1, #0x8                // =8
     490:      	add	x8, x8, #0x90
     494:      	ldr	x8, [sp, #0x20]
     498:      	add	x2, x8, #0x90
     49c:      	blr	x10
     4a0:      	ldr	x8, [sp, #0x30]
     4a4:      	add	x0, x20, #0x44
     4a8:      	mov	w9, #0x4                // =4
     4ac:      	mov	w1, #0x4                // =4
     4b0:      	add	x8, x8, #0x158
     4b4:      	ldr	x8, [sp, #0x30]
     4b8:      	add	x2, x8, #0x158
     4bc:      	blr	x9
     4c0:      	add	x8, sp, #0x38
     4c4:      	mov	w9, #0x4                // =4
     4c8:      	add	x0, sp, #0x38
     4cc:      	mov	w1, #0x8                // =8
     4d0:      	mov	x2, x21
     4d4:      	add	x22, x20, #0x48
     4d8:      	blr	x9
     4dc:      	ldr	x21, [sp, #0x38]
     4e0:      	add	x0, x20, #0x50
     4e4:      	mov	w8, #0x4                // =4
     4e8:      	mov	w1, #0x8                // =8
     4ec:      	add	x2, x21, #0x40
     4f0:      	blr	x8
     4f4:      	add	x0, x20, #0x58
     4f8:      	add	x2, x21, #0x30
     4fc:      	mov	w8, #0x4                // =4
     500:      	mov	w1, #0x8                // =8
     504:      	blr	x8
     508:      	add	x2, x21, #0x38
     50c:      	mov	x0, x22
     510:      	mov	w1, #0x8                // =8
     514:      	blr	x24
     518:      	strb	wzr, [x23, #0xf08]
     51c:      	strb	wzr, [x20, #0x1]
     520:      	adrp	x1, 0x0 <generic_uprobe_event>
     524:      	mov	w8, #0x2                // =2
     528:      	mov	w9, #0xc                // =12
     52c:      	mov	x0, x19
     530:      	str	xzr, [x20, #0x5ee8]
     534:      	str	xzr, [x20, #0x5ef0]
     538:      	ldr	x1, [x1]
     53c:      	mov	w2, #0x2                // =2
     540:      	blr	x9
     544:      	ldp	x20, x19, [sp, #0xc0]
     548:      	mov	w0, wzr
     54c:      	ldp	x22, x21, [sp, #0xb0]
     550:      	ldp	x24, x23, [sp, #0xa0]
     554:      	ldp	x30, x25, [sp, #0x90]
     558:      	add	sp, sp, #0xd0
     55c:      	ret
     560:      	mov	x8, #-0x1               // =-1
     564:      	mov	w9, #0x1                // =1
     568:      	add	x1, sp, #0x10
     56c:      	str	x8, [sp, #0x10]
     570:      	add	x8, sp, #0x10
     574:      	mov	x0, x22
     578:      	mov	w25, #0x1               // =1
     57c:      	blr	x9
     580:      	cbz	x0, 0x544 <generic_uprobe_event+0x544>
     584:      	str	w25, [sp, #0x1c]
     588:      	add	x8, sp, #0x1c
     58c:      	add	x1, sp, #0x1c
     590:      	mov	x0, x21
     594:      	blr	x25
     598:      	cbz	x0, 0x544 <generic_uprobe_event+0x544>
     59c:      	mov	w8, #0x1                // =1
     5a0:      	add	x9, sp, #0x30
     5a4:      	add	x1, sp, #0x30
     5a8:      	blr	x8
     5ac:      	mov	x8, x0
     5b0:      	mov	x0, x24
     5b4:      	cbnz	x8, 0x544 <generic_uprobe_event+0x544>
     5b8:      	b	0x22c <generic_uprobe_event+0x22c>

Disassembly of section uprobe.multi.s/generic_uprobe:

0000000000000000 <generic_sleepable_preload>:
       0:      	sub	sp, sp, #0x30
       4:      	stp	x30, x19, [sp, #0x20]
       8:      	mov	w8, #0xae               // =174
       c:      	mov	x19, x0
      10:      	blr	x8
      14:      	str	w0, [sp, #0x1c]
      18:      	adrp	x0, 0x0 <generic_sleepable_preload>
      1c:      	mov	w8, #0x1                // =1
      20:      	add	x9, sp, #0x1c
      24:      	ldr	x0, [x0]
      28:      	add	x1, sp, #0x1c
      2c:      	blr	x8
      30:      	cbz	x0, 0x84 <generic_sleepable_preload+0x84>
      34:      	stp	x0, x19, [sp, #0x8]
      38:      	adrp	x8, 0x0 <generic_sleepable_preload>
      3c:      	ldr	x8, [x8]
      40:      	ldrb	w8, [x8]
      44:      	cbz	w8, 0x94 <generic_sleepable_preload+0x94>
      48:      	add	x1, sp, #0x8
      4c:      	mov	w0, wzr
      50:      	bl	0x50 <generic_sleepable_preload+0x50>
      54:      	add	x1, sp, #0x8
      58:      	mov	w0, #0x1                // =1
      5c:      	bl	0x5c <generic_sleepable_preload+0x5c>
      60:      	add	x1, sp, #0x8
      64:      	mov	w0, #0x2                // =2
      68:      	bl	0x68 <generic_sleepable_preload+0x68>
      6c:      	add	x1, sp, #0x8
      70:      	mov	w0, #0x3                // =3
      74:      	bl	0x74 <generic_sleepable_preload+0x74>
      78:      	add	x1, sp, #0x8
      7c:      	mov	w0, #0x4                // =4
      80:      	bl	0x80 <generic_sleepable_preload+0x80>
      84:      	ldp	x30, x19, [sp, #0x20]
      88:      	mov	w0, wzr
      8c:      	add	sp, sp, #0x30
      90:      	ret
      94:      	mov	x3, xzr
      98:      	adrp	x1, 0x0 <generic_sleepable_preload>
      9c:      	add	x1, x1, #0x0
      a0:      	mov	w8, #0x5                // =5
      a4:      	mov	w9, #0xb5               // =181
      a8:      	add	x10, sp, #0x8
      ac:      	add	x2, sp, #0x8
      b0:      	mov	w0, #0x5                // =5
      b4:      	blr	x9
      b8:      	ldp	x30, x19, [sp, #0x20]
      bc:      	mov	w0, wzr
      c0:      	add	sp, sp, #0x30
      c4:      	ret
      c8:      	nop
      cc:      	nop

00000000000000d0 <generic_sleepable_preload_cleanup>:
      d0:      	str	x30, [sp, #-0x10]!
      d4:      	mov	w8, #0xe                // =14
      d8:      	blr	x8
      dc:      	str	x0, [sp, #0x8]
      e0:      	adrp	x0, 0x0 <generic_sleepable_preload>
      e4:      	mov	w8, #0x3                // =3
      e8:      	add	x9, sp, #0x8
      ec:      	ldr	x0, [x0]
      f0:      	add	x1, sp, #0x8
      f4:      	blr	x8
      f8:      	mov	w0, wzr
      fc:      	ldr	x30, [sp], #0x10
     100:      	ret
     104:      	nop
     108:      	nop
     10c:      	nop

0000000000000110 <generic_sleepable_offload>:
     110:      	sub	sp, sp, #0x50
     114:      	stp	x30, x25, [sp, #0x10]
     118:      	stp	x24, x23, [sp, #0x20]
     11c:      	stp	x22, x21, [sp, #0x30]
     120:      	stp	x20, x19, [sp, #0x40]
     124:      	str	xzr, [sp, #0x8]
     128:      	mov	w8, #0xe                // =14
     12c:      	mov	x19, x0
     130:      	blr	x8
     134:      	str	x0, [sp]
     138:      	adrp	x20, 0x0 <generic_sleepable_preload>
     13c:      	mov	w8, #0x1                // =1
     140:      	mov	x9, sp
     144:      	ldr	x20, [x20]
     148:      	mov	x1, sp
     14c:      	mov	x0, x20
     150:      	blr	x8
     154:      	cbz	x0, 0x2a4 <generic_sleepable_offload+0x194>
     158:      	mov	w8, #0x3                // =3
     15c:      	mov	x9, sp
     160:      	mov	x21, x0
     164:      	mov	x1, sp
     168:      	mov	x0, x20
     16c:      	blr	x8
     170:      	adrp	x0, 0x0 <generic_sleepable_preload>
     174:      	mov	w8, #0x1                // =1
     178:      	mov	x1, x21
     17c:      	ldr	x0, [x0]
     180:      	blr	x8
     184:      	cbz	x0, 0x2a4 <generic_sleepable_offload+0x194>
     188:      	mov	x20, x0
     18c:      	mov	x21, xzr
     190:      	add	x22, x0, #0x8
     194:      	mov	w23, #0x40              // =64
     198:      	mov	w24, #0x8               // =8
     19c:      	add	x25, sp, #0x8
     1a0:      	b	0x1c8 <generic_sleepable_offload+0xb8>
     1a4:      	ldurh	w1, [x22, #-0x4]
     1a8:      	ldr	x3, [x22]
     1ac:      	ldurb	w2, [x22, #-0x1]
     1b0:      	mov	x0, x19
     1b4:      	bl	0x1b4 <generic_sleepable_offload+0xa4>
     1b8:      	add	x21, x21, #0x1
     1bc:      	add	x22, x22, #0x10
     1c0:      	cmp	x21, #0x12
     1c4:      	b.eq	0x2a4 <generic_sleepable_offload+0x194>
     1c8:      	ldr	w8, [x20, #0x120]
     1cc:      	cmp	x21, x8
     1d0:      	b.hs	0x2a4 <generic_sleepable_offload+0x194>
     1d4:      	ldurb	w8, [x22, #-0x8]
     1d8:      	cmp	w8, #0x2
     1dc:      	b.gt	0x220 <generic_sleepable_offload+0x110>
     1e0:      	cmp	w8, #0x1
     1e4:      	b.eq	0x1a4 <generic_sleepable_offload+0x94>
     1e8:      	cmp	w8, #0x2
     1ec:      	b.ne	0x1b8 <generic_sleepable_offload+0xa8>
     1f0:      	ldurb	w8, [x22, #-0x2]
     1f4:      	ldurh	w1, [x22, #-0x6]
     1f8:      	mov	x0, x19
     1fc:      	sub	w2, w23, w8, lsl #3
     200:      	bl	0x200 <generic_sleepable_offload+0xf0>
     204:      	ldurh	w1, [x22, #-0x4]
     208:      	mov	x3, x0
     20c:      	str	x0, [sp, #0x8]
     210:      	b	0x1ac <generic_sleepable_offload+0x9c>
     214:      	nop
     218:      	nop
     21c:      	nop
     220:      	cmp	w8, #0x3
     224:      	b.eq	0x27c <generic_sleepable_offload+0x16c>
     228:      	cmp	w8, #0x4
     22c:      	b.ne	0x1b8 <generic_sleepable_offload+0xa8>
     230:      	ldurb	w8, [x22, #-0x2]
     234:      	ldurh	w1, [x22, #-0x6]
     238:      	mov	x0, x19
     23c:      	sub	w2, w23, w8, lsl #3
     240:      	bl	0x240 <generic_sleepable_offload+0x130>
     244:      	str	x0, [sp, #0x8]
     248:      	mov	w9, #0x70               // =112
     24c:      	mov	w1, #0x8                // =8
     250:      	ldr	x8, [x22]
     254:      	add	x8, x0, x8
     258:      	add	x0, sp, #0x8
     25c:      	ldr	x8, [sp, #0x8]
     260:      	ldr	x10, [x22]
     264:      	add	x2, x8, x10
     268:      	blr	x9
     26c:      	cbnz	w0, 0x1b8 <generic_sleepable_offload+0xa8>
     270:      	ldurh	w1, [x22, #-0x4]
     274:      	ldr	x3, [sp, #0x8]
     278:      	b	0x1ac <generic_sleepable_offload+0x9c>
     27c:      	ldurb	w8, [x22, #-0x2]
     280:      	ldurh	w1, [x22, #-0x6]
     284:      	mov	x0, x19
     288:      	sub	w2, w23, w8, lsl #3
     28c:      	bl	0x28c <generic_sleepable_offload+0x17c>
     290:      	ldr	x8, [x22]
     294:      	ldurh	w1, [x22, #-0x4]
     298:      	add	x3, x8, x0
     29c:      	str	x3, [sp, #0x8]
     2a0:      	b	0x1ac <generic_sleepable_offload+0x9c>
     2a4:      	ldp	x20, x19, [sp, #0x40]
     2a8:      	mov	w0, wzr
     2ac:      	ldp	x22, x21, [sp, #0x30]
     2b0:      	ldp	x24, x23, [sp, #0x20]
     2b4:      	ldp	x30, x25, [sp, #0x10]
     2b8:      	add	sp, sp, #0x50
     2bc:      	ret
