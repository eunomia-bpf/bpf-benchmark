
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/katran/healthchecking_ipip.native.o:	file format elf64-littleaarch64

Disassembly of section tc:

0000000000000000 <healthcheck_encap>:
       0:      	sub	sp, sp, #0x60
       4:      	str	x30, [sp, #0x30]
       8:      	stp	x22, x21, [sp, #0x40]
       c:      	stp	x20, x19, [sp, #0x50]
      10:      	mov	w9, #0x2                // =2
      14:      	mov	w8, #0x1                // =1
      18:      	mov	x19, x0
      1c:      	stp	xzr, xzr, [sp, #0x18]
      20:      	str	xzr, [sp, #0x10]
      24:      	stp	wzr, w9, [sp, #0x28]
      28:      	add	x1, sp, #0xc
      2c:      	ldr	w9, [x0, #0xa8]
      30:      	adrp	x0, 0x0 <healthcheck_encap>
      34:      	str	wzr, [sp, #0xc]
      38:      	stp	w8, w9, [sp, #0x38]
      3c:      	ldr	x0, [x0]
      40:      	blr	x8
      44:      	cbz	x0, 0xcc <healthcheck_encap+0xcc>
      48:      	ldr	w8, [x19, #0xa8]
      4c:      	mov	x20, x0
      50:      	cbz	w8, 0xa8 <healthcheck_encap+0xa8>
      54:      	adrp	x0, 0x0 <healthcheck_encap>
      58:      	mov	w8, #0x1                // =1
      5c:      	add	x1, sp, #0x3c
      60:      	ldr	x0, [x0]
      64:      	blr	x8
      68:      	cbz	x0, 0xa8 <healthcheck_encap+0xa8>
      6c:      	ldr	w8, [x19, #0x70]
      70:      	cmp	w8, #0x5c3
      74:      	b.lo	0xe4 <healthcheck_encap+0xe4>
      78:      	ldr	x8, [x20, #0x8]
      7c:      	mov	w0, #0x2                // =2
      80:      	add	x8, x8, #0x1
      84:      	str	x8, [x20, #0x8]
      88:      	ldr	x8, [x20, #0x18]
      8c:      	add	x8, x8, #0x1
      90:      	str	x8, [x20, #0x18]
      94:      	ldp	x20, x19, [sp, #0x50]
      98:      	ldr	x30, [sp, #0x30]
      9c:      	ldp	x22, x21, [sp, #0x40]
      a0:      	add	sp, sp, #0x60
      a4:      	ret
      a8:      	ldr	x8, [x20, #0x10]
      ac:      	mov	w0, #-0x1               // =-1
      b0:      	add	x8, x8, #0x1
      b4:      	str	x8, [x20, #0x10]
      b8:      	ldp	x20, x19, [sp, #0x50]
      bc:      	ldr	x30, [sp, #0x30]
      c0:      	ldp	x22, x21, [sp, #0x40]
      c4:      	add	sp, sp, #0x60
      c8:      	ret
      cc:      	mov	w0, #-0x1               // =-1
      d0:      	ldp	x20, x19, [sp, #0x50]
      d4:      	ldr	x30, [sp, #0x30]
      d8:      	ldp	x22, x21, [sp, #0x40]
      dc:      	add	sp, sp, #0x60
      e0:      	ret
      e4:      	mov	x22, x0
      e8:      	adrp	x0, 0x0 <healthcheck_encap>
      ec:      	mov	w8, #0x1                // =1
      f0:      	ldr	x0, [x0]
      f4:      	add	x1, sp, #0x38
      f8:      	blr	x8
      fc:      	cbz	x0, 0x148 <healthcheck_encap+0x148>
     100:      	mov	x21, x0
     104:      	adrp	x0, 0x0 <healthcheck_encap>
     108:      	mov	w8, #0x1                // =1
     10c:      	ldr	x0, [x0]
     110:      	add	x1, sp, #0x2c
     114:      	blr	x8
     118:      	cbz	x0, 0x148 <healthcheck_encap+0x148>
     11c:      	mov	w8, #0x40               // =64
     120:      	str	wzr, [x19, #0xa8]
     124:      	strb	w8, [sp, #0x25]
     128:      	ldrb	w8, [x22, #0x10]
     12c:      	cmp	w8, #0x1
     130:      	b.ne	0x16c <healthcheck_encap+0x16c>
     134:      	ldp	x8, x9, [x22]
     138:      	mov	w3, #0x1                // =1
     13c:      	stur	x9, [sp, #0x1c]
     140:      	stur	x8, [sp, #0x14]
     144:      	b	0x17c <healthcheck_encap+0x17c>
     148:      	ldr	x8, [x20, #0x8]
     14c:      	mov	w0, #0x2                // =2
     150:      	add	x8, x8, #0x1
     154:      	str	x8, [x20, #0x8]
     158:      	ldp	x20, x19, [sp, #0x50]
     15c:      	ldr	x30, [sp, #0x30]
     160:      	ldp	x22, x21, [sp, #0x40]
     164:      	add	sp, sp, #0x60
     168:      	ret
     16c:      	ldr	w8, [x22]
     170:      	mov	w3, wzr
     174:      	mov	x0, x21
     178:      	str	w8, [sp, #0x14]
     17c:      	ldr	x8, [x20]
     180:      	ldr	w21, [x0]
     184:      	add	x1, sp, #0x10
     188:      	mov	x0, x19
     18c:      	mov	w2, #0x1c               // =28
     190:      	add	x8, x8, #0x1
     194:      	str	x8, [x20]
     198:      	mov	w8, #0x15               // =21
     19c:      	blr	x8
     1a0:      	mov	w8, #0x17               // =23
     1a4:      	mov	w0, w21
     1a8:      	mov	w1, wzr
     1ac:      	blr	x8
     1b0:      	ldp	x20, x19, [sp, #0x50]
     1b4:      	ldr	x30, [sp, #0x30]
     1b8:      	ldp	x22, x21, [sp, #0x40]
     1bc:      	add	sp, sp, #0x60
     1c0:      	ret
