
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/cilium/bpf_wireguard.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <__check_cluster_id_bits>:
       0:      	adrp	x8, 0x0 <__check_cluster_id_bits>
       4:      	ldr	x8, [x8]
       8:      	ldr	wzr, [x8]
       c:      	ret

0000000000000010 <__check_device_mtu>:
      10:      	adrp	x8, 0x0 <__check_cluster_id_bits>
      14:      	ldr	x8, [x8]
      18:      	ldrh	wzr, [x8]
      1c:      	ret

Disassembly of section tc/tail:

0000000000000000 <tail_drop_notify>:
       0:      	sub	sp, sp, #0xa0
       4:      	str	x29, [sp, #0x50]
       8:      	stp	x30, x25, [sp, #0x60]
       c:      	stp	x24, x23, [sp, #0x70]
      10:      	stp	x22, x21, [sp, #0x80]
      14:      	stp	x20, x19, [sp, #0x90]
      18:      	adrp	x8, 0x0 <tail_drop_notify>
      1c:      	ldr	w23, [x0, #0x38]
      20:      	mov	x19, x0
      24:      	ldr	x8, [x8]
      28:      	ldrb	w8, [x8]
      2c:      	cbz	w8, 0x54 <tail_drop_notify+0x54>
      30:      	str	wzr, [sp, #0x10]
      34:      	mov	w8, #0x1                // =1
      38:      	adrp	x0, 0x0 <tail_drop_notify>
      3c:      	add	x1, sp, #0x10
      40:      	ldr	x0, [x0]
      44:      	blr	x8
      48:      	cbz	x0, 0x58 <tail_drop_notify+0x58>
      4c:      	ldr	x0, [x0]
      50:      	b	0x58 <tail_drop_notify+0x58>
      54:      	mov	x0, xzr
      58:      	mov	w29, #0x2               // =2
      5c:      	adrp	x9, 0x0 <tail_drop_notify>
      60:      	ldr	w25, [x19, #0x70]
      64:      	ldr	w22, [x19, #0x40]
      68:      	mov	w8, w25
      6c:      	str	x29, [sp, #0x40]
      70:      	ldr	x9, [x9]
      74:      	ldr	w10, [x9]
      78:      	cbz	w10, 0x1ac <tail_drop_notify+0x1ac>
      7c:      	str	x0, [sp, #0x8]
      80:      	adrp	x8, 0x0 <tail_drop_notify>
      84:      	ldr	x8, [x8]
      88:      	ldr	w8, [x8]
      8c:      	str	x8, [sp]
      90:      	mov	w8, #0x5                // =5
      94:      	ldr	w24, [x9]
      98:      	blr	x8
      9c:      	str	w29, [sp, #0x5c]
      a0:      	mov	x21, x0
      a4:      	mov	w8, #0x1                // =1
      a8:      	adrp	x0, 0x0 <tail_drop_notify>
      ac:      	add	x1, sp, #0x5c
      b0:      	ldr	x0, [x0]
      b4:      	blr	x8
      b8:      	mov	x20, x0
      bc:      	cbnz	x0, 0xe8 <tail_drop_notify+0xe8>
      c0:      	str	xzr, [sp, #0x48]
      c4:      	mov	w8, #0x2                // =2
      c8:      	adrp	x0, 0x0 <tail_drop_notify>
      cc:      	add	x1, sp, #0x5c
      d0:      	add	x2, sp, #0x48
      d4:      	mov	w3, wzr
      d8:      	add	x20, sp, #0x48
      dc:      	ldr	x0, [x0]
      e0:      	blr	x8
      e4:      	tbnz	w0, #0x1f, 0x260 <tail_drop_notify+0x260>
      e8:      	mov	w8, #0x1                // =1
      ec:      	adrp	x0, 0x0 <tail_drop_notify>
      f0:      	add	x1, sp, #0x40
      f4:      	ldr	x0, [x0]
      f8:      	blr	x8
      fc:      	cbz	x0, 0x168 <tail_drop_notify+0x168>
     100:      	ldr	x8, [x0]
     104:      	mov	w9, #0xca00             // =51712
     108:      	movk	w9, #0x3b9a, lsl #16
     10c:      	sub	x10, x21, x8
     110:      	cmp	x10, x9
     114:      	b.ls	0x194 <tail_drop_notify+0x194>
     118:      	mov	x11, #0x5a53            // =23123
     11c:      	lsr	x8, x10, #9
     120:      	neg	x10, x10
     124:      	movk	x11, #0xa09b, lsl #16
     128:      	movk	x11, #0xb82f, lsl #32
     12c:      	movk	x11, #0x44, lsl #48
     130:      	umulh	x8, x8, x11
     134:      	lsr	x11, x8, #11
     138:      	ldr	x8, [x0, #0x8]
     13c:      	madd	x9, x11, x9, x10
     140:      	madd	x8, x11, x24, x8
     144:      	add	x9, x21, x9
     148:      	stp	x9, x8, [x0]
     14c:      	ldr	x9, [sp]
     150:      	cmp	x8, x9
     154:      	b.ls	0x160 <tail_drop_notify+0x160>
     158:      	mov	x8, x9
     15c:      	str	x9, [x0, #0x8]
     160:      	cbnz	x8, 0x19c <tail_drop_notify+0x19c>
     164:      	b	0x280 <tail_drop_notify+0x280>
     168:      	sub	x8, x24, #0x1
     16c:      	adrp	x0, 0x0 <tail_drop_notify>
     170:      	add	x1, sp, #0x40
     174:      	stp	x21, x8, [sp, #0x10]
     178:      	mov	w8, #0x2                // =2
     17c:      	add	x2, sp, #0x10
     180:      	mov	w3, wzr
     184:      	ldr	x0, [x0]
     188:      	blr	x8
     18c:      	tbz	w0, #0x1f, 0x1a4 <tail_drop_notify+0x1a4>
     190:      	b	0x280 <tail_drop_notify+0x280>
     194:      	ldr	x8, [x0, #0x8]
     198:      	cbz	x8, 0x280 <tail_drop_notify+0x280>
     19c:      	sub	x8, x8, #0x1
     1a0:      	str	x8, [x0, #0x8]
     1a4:      	ldr	w8, [x19, #0x70]
     1a8:      	ldr	x0, [sp, #0x8]
     1ac:      	ldrh	w9, [x19, #0xb4]
     1b0:      	mov	w10, #0xdd86            // =56710
     1b4:      	cmp	w9, w10
     1b8:      	adrp	x10, 0x0 <tail_drop_notify>
     1bc:      	ldr	x10, [x10]
     1c0:      	cinc	w9, w29, eq
     1c4:      	ldr	w10, [x10]
     1c8:      	ldr	w14, [x19, #0x98]
     1cc:      	ldr	w12, [x19, #0x3c]
     1d0:      	ldr	x13, [x19, #0x10]
     1d4:      	cmp	w8, w10
     1d8:      	csel	w8, w8, w10, lo
     1dc:      	ldp	w10, w11, [x19, #0x30]
     1e0:      	cbz	x13, 0x1e8 <tail_drop_notify+0x1e8>
     1e4:      	ldr	w13, [x13, #0xe0]
     1e8:      	mov	w15, #0x1               // =1
     1ec:      	lsr	w16, w22, #8
     1f0:      	stp	w14, w25, [sp, #0x14]
     1f4:      	lsr	w14, w22, #16
     1f8:      	strb	w23, [sp, #0x11]
     1fc:      	mov	w17, #0x3               // =3
     200:      	strb	w15, [sp, #0x10]
     204:      	lsr	w15, w23, #8
     208:      	strh	wzr, [sp, #0x12]
     20c:      	adrp	x1, 0x0 <tail_drop_notify>
     210:      	add	x3, sp, #0x10
     214:      	mov	w4, #0x30               // =48
     218:      	strh	w8, [sp, #0x1c]
     21c:      	strh	w17, [sp, #0x1e]
     220:      	stp	w10, w11, [sp, #0x20]
     224:      	mov	w10, #-0x1              // =-1
     228:      	orr	x2, x10, x8, lsl #32
     22c:      	str	w12, [sp, #0x28]
     230:      	strh	w14, [sp, #0x2c]
     234:      	strb	w16, [sp, #0x2e]
     238:      	strb	w15, [sp, #0x2f]
     23c:      	str	w13, [sp, #0x30]
     240:      	strb	w9, [sp, #0x34]
     244:      	mov	w9, #0x19               // =25
     248:      	sturh	wzr, [sp, #0x35]
     24c:      	strb	wzr, [sp, #0x37]
     250:      	str	x0, [sp, #0x38]
     254:      	ldr	x1, [x1]
     258:      	mov	x0, x19
     25c:      	blr	x9
     260:      	and	w0, w22, #0xff
     264:      	ldp	x20, x19, [sp, #0x90]
     268:      	ldr	x29, [sp, #0x50]
     26c:      	ldp	x22, x21, [sp, #0x80]
     270:      	ldp	x24, x23, [sp, #0x70]
     274:      	ldp	x30, x25, [sp, #0x60]
     278:      	add	sp, sp, #0xa0
     27c:      	ret
     280:      	ldr	x8, [x20]
     284:      	add	x8, x8, #0x1
     288:      	str	x8, [x20]
     28c:      	b	0x260 <tail_drop_notify+0x260>

0000000000000290 <tail_icmp6_send_time_exceeded>:
     290:      	sub	sp, sp, #0xf0
     294:      	stp	x30, x23, [sp, #0xc0]
     298:      	stp	x22, x21, [sp, #0xd0]
     29c:      	stp	x20, x19, [sp, #0xe0]
     2a0:      	mov	w8, #0x3a               // =58
     2a4:      	ldp	w20, w22, [x0, #0x30]
     2a8:      	str	wzr, [x0, #0x30]
     2ac:      	adrp	x1, 0x0 <tail_drop_notify>
     2b0:      	add	x3, sp, #0xa8
     2b4:      	mov	w2, #-0x1               // =-1
     2b8:      	mov	w4, #0x14               // =20
     2bc:      	stp	xzr, xzr, [sp, #0x58]
     2c0:      	mov	x19, x0
     2c4:      	add	x21, sp, #0x18
     2c8:      	stp	xzr, xzr, [sp, #0x48]
     2cc:      	str	xzr, [sp, #0x20]
     2d0:      	strh	wzr, [sp, #0x14]
     2d4:      	strb	w8, [sp, #0x10]
     2d8:      	adrp	x8, 0x0 <tail_drop_notify>
     2dc:      	stp	xzr, xzr, [sp, #0x38]
     2e0:      	stp	xzr, xzr, [sp, #0x28]
     2e4:      	ldr	x8, [x8]
     2e8:      	ldr	x9, [x8]
     2ec:      	str	x9, [sp, #0x8]
     2f0:      	ldr	x8, [x8, #0x8]
     2f4:      	str	x8, [sp]
     2f8:      	mov	w8, #0x3                // =3
     2fc:      	str	xzr, [sp, #0xb0]
     300:      	str	wzr, [sp, #0xb8]
     304:      	ldr	w9, [x0, #0x98]
     308:      	str	x8, [sp, #0x18]
     30c:      	mov	w8, #0xe02              // =3586
     310:      	stp	w8, w9, [sp, #0xa8]
     314:      	mov	w8, #0x19               // =25
     318:      	ldr	x1, [x1]
     31c:      	blr	x8
     320:      	mov	w8, #0x1a               // =26
     324:      	add	x2, x21, #0x8
     328:      	mov	x0, x19
     32c:      	mov	w1, w20
     330:      	mov	w3, #0x28               // =40
     334:      	blr	x8
     338:      	tbnz	w0, #0x1f, 0x7bc <tail_icmp6_send_time_exceeded+0x52c>
     33c:      	mov	w8, #0x9                // =9
     340:      	add	w1, w20, #0x6
     344:      	add	x2, sp, #0x10
     348:      	mov	x0, x19
     34c:      	mov	w3, #0x1                // =1
     350:      	mov	w4, wzr
     354:      	blr	x8
     358:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     35c:      	ldrb	w8, [sp, #0x26]
     360:      	cmp	w8, #0x6
     364:      	b.eq	0x490 <tail_icmp6_send_time_exceeded+0x200>
     368:      	cmp	w8, #0x3a
     36c:      	b.eq	0x378 <tail_icmp6_send_time_exceeded+0xe8>
     370:      	cmp	w8, #0x11
     374:      	b.ne	0x7cc <tail_icmp6_send_time_exceeded+0x53c>
     378:      	mov	w8, #0x1a               // =26
     37c:      	add	w1, w20, #0x28
     380:      	add	x2, x21, #0x30
     384:      	mov	x0, x19
     388:      	mov	w3, #0x8                // =8
     38c:      	blr	x8
     390:      	tbnz	w0, #0x1f, 0x7bc <tail_icmp6_send_time_exceeded+0x52c>
     394:      	mov	w8, #0x1c               // =28
     398:      	add	x2, sp, #0x18
     39c:      	mov	x0, xzr
     3a0:      	mov	w1, wzr
     3a4:      	mov	w3, #0x38               // =56
     3a8:      	mov	w4, wzr
     3ac:      	mov	w21, #0x1c              // =28
     3b0:      	add	x23, sp, #0x18
     3b4:      	blr	x8
     3b8:      	mov	w8, #0x38000000         // =939524096
     3bc:      	mov	w4, w0
     3c0:      	add	x2, x23, #0x10
     3c4:      	str	w8, [sp, #0xa8]
     3c8:      	mov	w8, #0x3a000000         // =973078528
     3cc:      	mov	x0, xzr
     3d0:      	mov	w1, wzr
     3d4:      	str	w8, [sp, #0x98]
     3d8:      	mov	w8, #0x1c               // =28
     3dc:      	mov	w3, #0x10               // =16
     3e0:      	blr	x8
     3e4:      	mov	w8, #0x1c               // =28
     3e8:      	mov	w4, w0
     3ec:      	add	x2, x23, #0x20
     3f0:      	mov	x0, xzr
     3f4:      	mov	w1, wzr
     3f8:      	mov	w3, #0x10               // =16
     3fc:      	blr	x8
     400:      	mov	w8, #0x1c               // =28
     404:      	mov	w4, w0
     408:      	add	x2, sp, #0xa8
     40c:      	mov	x0, xzr
     410:      	mov	w1, wzr
     414:      	mov	w3, #0x4                // =4
     418:      	blr	x8
     41c:      	mov	w4, w0
     420:      	add	x2, sp, #0x98
     424:      	mov	x0, xzr
     428:      	mov	w1, wzr
     42c:      	mov	w3, #0x4                // =4
     430:      	blr	x21
     434:      	mov	w8, #0x3800             // =14336
     438:      	mov	w9, #0x26               // =38
     43c:      	mov	w21, w0
     440:      	strh	w8, [sp, #0x14]
     444:      	ldrh	w8, [sp, #0x24]
     448:      	mov	x0, x19
     44c:      	mov	w2, wzr
     450:      	ldr	w10, [x19, #0x70]
     454:      	rev	w8, w8
     458:      	sub	w8, w10, w8, lsr #16
     45c:      	add	w1, w8, #0x38
     460:      	blr	x9
     464:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     468:      	mov	w8, #0x9                // =9
     46c:      	add	w1, w20, #0x28
     470:      	add	x2, sp, #0x18
     474:      	mov	x0, x19
     478:      	mov	w3, #0x38               // =56
     47c:      	mov	w4, wzr
     480:      	blr	x8
     484:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     488:      	mov	w8, #0x9                // =9
     48c:      	b	0x5a4 <tail_icmp6_send_time_exceeded+0x314>
     490:      	mov	w8, #0x1a               // =26
     494:      	add	w1, w20, #0x28
     498:      	add	x2, x21, #0x30
     49c:      	mov	x0, x19
     4a0:      	mov	w3, #0x14               // =20
     4a4:      	blr	x8
     4a8:      	tbnz	w0, #0x1f, 0x7bc <tail_icmp6_send_time_exceeded+0x52c>
     4ac:      	mov	w8, #0x1c               // =28
     4b0:      	add	x2, sp, #0x18
     4b4:      	mov	x0, xzr
     4b8:      	mov	w1, wzr
     4bc:      	mov	w3, #0x44               // =68
     4c0:      	mov	w4, wzr
     4c4:      	mov	w21, #0x1c              // =28
     4c8:      	add	x23, sp, #0x18
     4cc:      	blr	x8
     4d0:      	mov	w8, #0x44000000         // =1140850688
     4d4:      	mov	w4, w0
     4d8:      	add	x2, x23, #0x10
     4dc:      	str	w8, [sp, #0xa8]
     4e0:      	mov	w8, #0x3a000000         // =973078528
     4e4:      	mov	x0, xzr
     4e8:      	mov	w1, wzr
     4ec:      	str	w8, [sp, #0x98]
     4f0:      	mov	w8, #0x1c               // =28
     4f4:      	mov	w3, #0x10               // =16
     4f8:      	blr	x8
     4fc:      	mov	w8, #0x1c               // =28
     500:      	mov	w4, w0
     504:      	add	x2, x23, #0x20
     508:      	mov	x0, xzr
     50c:      	mov	w1, wzr
     510:      	mov	w3, #0x10               // =16
     514:      	blr	x8
     518:      	mov	w8, #0x1c               // =28
     51c:      	mov	w4, w0
     520:      	add	x2, sp, #0xa8
     524:      	mov	x0, xzr
     528:      	mov	w1, wzr
     52c:      	mov	w3, #0x4                // =4
     530:      	blr	x8
     534:      	mov	w4, w0
     538:      	add	x2, sp, #0x98
     53c:      	mov	x0, xzr
     540:      	mov	w1, wzr
     544:      	mov	w3, #0x4                // =4
     548:      	blr	x21
     54c:      	mov	w8, #0x4400             // =17408
     550:      	mov	w9, #0x26               // =38
     554:      	mov	w21, w0
     558:      	strh	w8, [sp, #0x14]
     55c:      	ldrh	w8, [sp, #0x24]
     560:      	mov	x0, x19
     564:      	mov	w2, wzr
     568:      	ldr	w10, [x19, #0x70]
     56c:      	rev	w8, w8
     570:      	sub	w8, w10, w8, lsr #16
     574:      	add	w1, w8, #0x44
     578:      	blr	x9
     57c:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     580:      	mov	w8, #0x9                // =9
     584:      	add	w1, w20, #0x28
     588:      	add	x2, sp, #0x18
     58c:      	mov	x0, x19
     590:      	mov	w3, #0x44               // =68
     594:      	mov	w4, wzr
     598:      	blr	x8
     59c:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     5a0:      	mov	w8, #0x9                // =9
     5a4:      	add	w1, w20, #0x4
     5a8:      	add	x2, sp, #0x14
     5ac:      	mov	x0, x19
     5b0:      	mov	w3, #0x2                // =2
     5b4:      	mov	w4, wzr
     5b8:      	blr	x8
     5bc:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     5c0:      	mov	w8, #0xb                // =11
     5c4:      	add	w1, w20, #0x2a
     5c8:      	mov	x0, x19
     5cc:      	mov	w2, wzr
     5d0:      	mov	w3, w21
     5d4:      	mov	w4, #0x10               // =16
     5d8:      	blr	x8
     5dc:      	tbnz	w0, #0x1f, 0x88c <tail_icmp6_send_time_exceeded+0x5fc>
     5e0:      	ldp	x9, x8, [sp]
     5e4:      	add	w1, w20, #0x8
     5e8:      	add	x2, sp, #0x78
     5ec:      	mov	x0, x19
     5f0:      	mov	w3, #0x10               // =16
     5f4:      	stp	x8, x9, [sp, #0x98]
     5f8:      	adrp	x8, 0x0 <tail_drop_notify>
     5fc:      	ldr	x8, [x8]
     600:      	ldr	x8, [x8]
     604:      	str	x8, [sp, #0x88]
     608:      	mov	w8, #0x1a               // =26
     60c:      	blr	x8
     610:      	tbnz	w0, #0x1f, 0x7bc <tail_icmp6_send_time_exceeded+0x52c>
     614:      	mov	w8, #0x1a               // =26
     618:      	add	w1, w20, #0x18
     61c:      	add	x2, sp, #0x68
     620:      	mov	x0, x19
     624:      	mov	w3, #0x10               // =16
     628:      	blr	x8
     62c:      	tbnz	w0, #0x1f, 0x7bc <tail_icmp6_send_time_exceeded+0x52c>
     630:      	mov	w8, #0x9                // =9
     634:      	add	w1, w20, #0x8
     638:      	add	x2, sp, #0x98
     63c:      	mov	x0, x19
     640:      	mov	w3, #0x10               // =16
     644:      	mov	w4, wzr
     648:      	blr	x8
     64c:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     650:      	mov	w8, #0x9                // =9
     654:      	add	w1, w20, #0x18
     658:      	add	x2, sp, #0x78
     65c:      	mov	x0, x19
     660:      	mov	w3, #0x10               // =16
     664:      	mov	w4, wzr
     668:      	blr	x8
     66c:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     670:      	mov	w8, #0x1c               // =28
     674:      	add	x0, sp, #0x78
     678:      	add	x2, sp, #0x98
     67c:      	mov	w1, #0x10               // =16
     680:      	mov	w3, #0x10               // =16
     684:      	mov	w4, wzr
     688:      	blr	x8
     68c:      	mov	w3, w0
     690:      	mov	w8, #0xb                // =11
     694:      	add	w1, w20, #0x2a
     698:      	mov	x0, x19
     69c:      	mov	w2, wzr
     6a0:      	mov	w4, #0x10               // =16
     6a4:      	blr	x8
     6a8:      	tbnz	w0, #0x1f, 0x88c <tail_icmp6_send_time_exceeded+0x5fc>
     6ac:      	mov	w8, #0x1c               // =28
     6b0:      	add	x0, sp, #0x68
     6b4:      	add	x2, sp, #0x78
     6b8:      	mov	w1, #0x10               // =16
     6bc:      	mov	w3, #0x10               // =16
     6c0:      	mov	w4, wzr
     6c4:      	blr	x8
     6c8:      	mov	w3, w0
     6cc:      	mov	w8, #0xb                // =11
     6d0:      	add	w1, w20, #0x2a
     6d4:      	mov	x0, x19
     6d8:      	mov	w2, wzr
     6dc:      	mov	w4, #0x10               // =16
     6e0:      	blr	x8
     6e4:      	tbnz	w0, #0x1f, 0x88c <tail_icmp6_send_time_exceeded+0x5fc>
     6e8:      	mov	w8, #0x1a               // =26
     6ec:      	add	x2, sp, #0x90
     6f0:      	mov	x0, x19
     6f4:      	mov	w1, #0x6                // =6
     6f8:      	mov	w3, #0x6                // =6
     6fc:      	blr	x8
     700:      	tbnz	w0, #0x1f, 0x7bc <tail_icmp6_send_time_exceeded+0x52c>
     704:      	mov	w8, #0x9                // =9
     708:      	add	x2, sp, #0x90
     70c:      	mov	x0, x19
     710:      	mov	w1, wzr
     714:      	mov	w3, #0x6                // =6
     718:      	mov	w4, wzr
     71c:      	blr	x8
     720:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     724:      	mov	w8, #0x9                // =9
     728:      	add	x2, sp, #0x88
     72c:      	mov	x0, x19
     730:      	mov	w1, #0x6                // =6
     734:      	mov	w3, #0x6                // =6
     738:      	mov	w4, wzr
     73c:      	blr	x8
     740:      	tbnz	w0, #0x1f, 0x7c4 <tail_icmp6_send_time_exceeded+0x534>
     744:      	ldr	x8, [x19, #0x10]
     748:      	cbz	x8, 0x750 <tail_icmp6_send_time_exceeded+0x4c0>
     74c:      	ldr	w8, [x8, #0xe0]
     750:      	adrp	x10, 0x0 <tail_drop_notify>
     754:      	ldr	w9, [x19, #0x70]
     758:      	mov	w11, #0x403             // =1027
     75c:      	adrp	x1, 0x0 <tail_drop_notify>
     760:      	ldr	x10, [x10]
     764:      	add	x3, sp, #0xa8
     768:      	mov	x0, x19
     76c:      	mov	w4, #0x18               // =24
     770:      	ldr	w10, [x10]
     774:      	ldr	w12, [x19, #0x98]
     778:      	str	w9, [sp, #0xb0]
     77c:      	stp	w8, wzr, [sp, #0xb8]
     780:      	mov	w8, #0x19               // =25
     784:      	cmp	w9, w10
     788:      	stp	w11, w12, [sp, #0xa8]
     78c:      	csel	w10, w9, w10, lo
     790:      	mov	w9, #0x1                // =1
     794:      	strh	w10, [sp, #0xb4]
     798:      	strh	w9, [sp, #0xb6]
     79c:      	mov	w9, #-0x1               // =-1
     7a0:      	orr	x2, x9, x10, lsl #32
     7a4:      	ldr	x1, [x1]
     7a8:      	blr	x8
     7ac:      	ldr	x8, [x19, #0x10]
     7b0:      	cbz	x8, 0x894 <tail_icmp6_send_time_exceeded+0x604>
     7b4:      	ldr	w0, [x8, #0xe0]
     7b8:      	b	0x898 <tail_icmp6_send_time_exceeded+0x608>
     7bc:      	mov	w0, #-0x86              // =-134
     7c0:      	b	0x7d0 <tail_icmp6_send_time_exceeded+0x540>
     7c4:      	mov	w0, #-0x8d              // =-141
     7c8:      	b	0x7d0 <tail_icmp6_send_time_exceeded+0x540>
     7cc:      	mov	w0, #-0x8e              // =-142
     7d0:      	cmp	w0, #0x0
     7d4:      	str	xzr, [x19, #0x30]
     7d8:      	ldr	w20, [x19, #0x70]
     7dc:      	add	x1, sp, #0xa8
     7e0:      	cneg	w8, w0, mi
     7e4:      	adrp	x0, 0x0 <tail_drop_notify>
     7e8:      	and	w9, w8, #0xff
     7ec:      	str	w9, [x19, #0x38]
     7f0:      	mov	x9, #0x670200000000     // =113258287595520
     7f4:      	movk	x9, #0x142, lsl #48
     7f8:      	stur	x9, [x19, #0x3c]
     7fc:      	mov	x9, #0x1420000          // =21102592
     800:      	movk	x9, #0x67, lsl #32
     804:      	str	x9, [sp, #0xa8]
     808:      	strb	w8, [sp, #0xa8]
     80c:      	and	w8, w22, #0x3
     810:      	strb	w8, [sp, #0xa9]
     814:      	mov	w8, #0x1                // =1
     818:      	ldr	x0, [x0]
     81c:      	blr	x8
     820:      	cbz	x0, 0x838 <tail_icmp6_send_time_exceeded+0x5a8>
     824:      	ldp	x8, x9, [x0]
     828:      	add	x8, x8, #0x1
     82c:      	add	x9, x9, x20
     830:      	stp	x8, x9, [x0]
     834:      	b	0x85c <tail_icmp6_send_time_exceeded+0x5cc>
     838:      	mov	w8, #0x1                // =1
     83c:      	adrp	x0, 0x0 <tail_drop_notify>
     840:      	add	x1, sp, #0xa8
     844:      	stp	x8, x20, [sp, #0x18]
     848:      	mov	w8, #0x2                // =2
     84c:      	add	x2, sp, #0x18
     850:      	mov	w3, wzr
     854:      	ldr	x0, [x0]
     858:      	blr	x8
     85c:      	mov	w8, #0xc                // =12
     860:      	adrp	x1, 0x0 <tail_drop_notify>
     864:      	mov	x0, x19
     868:      	ldr	x1, [x1]
     86c:      	mov	w2, #0x1                // =1
     870:      	blr	x8
     874:      	mov	w0, #0x2                // =2
     878:      	ldp	x20, x19, [sp, #0xe0]
     87c:      	ldp	x22, x21, [sp, #0xd0]
     880:      	ldp	x30, x23, [sp, #0xc0]
     884:      	add	sp, sp, #0xf0
     888:      	ret
     88c:      	mov	w0, #-0x9a              // =-154
     890:      	b	0x7d0 <tail_icmp6_send_time_exceeded+0x540>
     894:      	mov	w0, wzr
     898:      	mov	w8, #0x17               // =23
     89c:      	mov	w1, wzr
     8a0:      	blr	x8
     8a4:      	tbnz	w0, #0x1f, 0x7d0 <tail_icmp6_send_time_exceeded+0x540>
     8a8:      	cmp	w0, #0x2
     8ac:      	b.ne	0x878 <tail_icmp6_send_time_exceeded+0x5e8>
     8b0:      	b	0x7d0 <tail_icmp6_send_time_exceeded+0x540>

Disassembly of section tc/entry:

0000000000000000 <cil_from_wireguard>:
       0:      	sub	sp, sp, #0x50
       4:      	str	x30, [sp, #0x20]
       8:      	stp	x22, x21, [sp, #0x30]
       c:      	stp	x20, x19, [sp, #0x40]
      10:      	str	wzr, [x0, #0x30]
      14:      	adrp	x8, 0x0 <cil_from_wireguard>
      18:      	mov	x19, x0
      1c:      	str	wzr, [x0, #0x34]
      20:      	str	wzr, [x0, #0x38]
      24:      	str	wzr, [x0, #0x3c]
      28:      	str	wzr, [x0, #0x40]
      2c:      	ldr	x8, [x8]
      30:      	ldrb	w9, [x8]
      34:      	cbz	w9, 0x7c <cil_from_wireguard+0x7c>
      38:      	ldrb	w21, [x8]
      3c:      	ldrh	w8, [x19, #0xb4]
      40:      	cmp	w8, #0x8
      44:      	b.ne	0x5c <cil_from_wireguard+0x5c>
      48:      	ldr	x8, [x19, #0xd0]
      4c:      	ldr	x9, [x19, #0x50]
      50:      	add	x10, x8, #0x14
      54:      	cmp	x10, x9
      58:      	b.ls	0x130 <cil_from_wireguard+0x130>
      5c:      	str	wzr, [sp, #0x10]
      60:      	mov	w8, #0x1                // =1
      64:      	adrp	x0, 0x0 <cil_from_wireguard>
      68:      	add	x1, sp, #0x10
      6c:      	ldr	x0, [x0]
      70:      	blr	x8
      74:      	cbz	x0, 0x7c <cil_from_wireguard+0x7c>
      78:      	str	xzr, [x0]
      7c:      	adrp	x8, 0x0 <cil_from_wireguard>
      80:      	ldr	x8, [x8]
      84:      	ldrb	w8, [x8]
      88:      	cbz	w8, 0x94 <cil_from_wireguard+0x94>
      8c:      	mov	w8, #0xd00              // =3328
      90:      	str	w8, [x19, #0xa8]
      94:      	adrp	x8, 0x0 <cil_from_wireguard>
      98:      	adrp	x0, 0x0 <cil_from_wireguard>
      9c:      	add	x1, sp, #0x28
      a0:      	ldr	x8, [x8]
      a4:      	ldr	wzr, [x8]
      a8:      	mov	x8, #0x10c              // =268
      ac:      	ldr	w19, [x19, #0x70]
      b0:      	movk	x8, #0x154, lsl #16
      b4:      	movk	x8, #0x7, lsl #32
      b8:      	str	x8, [sp, #0x28]
      bc:      	mov	w8, #0x1                // =1
      c0:      	ldr	x0, [x0]
      c4:      	blr	x8
      c8:      	cbz	x0, 0xf4 <cil_from_wireguard+0xf4>
      cc:      	ldp	x8, x9, [x0]
      d0:      	add	x8, x8, #0x1
      d4:      	add	x9, x9, x19
      d8:      	stp	x8, x9, [x0]
      dc:      	ldp	x20, x19, [sp, #0x40]
      e0:      	mov	w0, wzr
      e4:      	ldr	x30, [sp, #0x20]
      e8:      	ldp	x22, x21, [sp, #0x30]
      ec:      	add	sp, sp, #0x50
      f0:      	ret
      f4:      	mov	w8, #0x1                // =1
      f8:      	adrp	x0, 0x0 <cil_from_wireguard>
      fc:      	add	x1, sp, #0x28
     100:      	stp	x8, x19, [sp, #0x10]
     104:      	mov	w8, #0x2                // =2
     108:      	add	x2, sp, #0x10
     10c:      	mov	w3, wzr
     110:      	ldr	x0, [x0]
     114:      	blr	x8
     118:      	ldp	x20, x19, [sp, #0x40]
     11c:      	mov	w0, wzr
     120:      	ldr	x30, [sp, #0x20]
     124:      	ldp	x22, x21, [sp, #0x30]
     128:      	add	sp, sp, #0x50
     12c:      	ret
     130:      	ldrb	w8, [x8]
     134:      	and	w22, w8, #0xf
     138:      	cmp	w22, #0x6
     13c:      	b.hs	0x168 <cil_from_wireguard+0x168>
     140:      	mov	x20, xzr
     144:      	str	wzr, [sp, #0x10]
     148:      	mov	w8, #0x1                // =1
     14c:      	adrp	x0, 0x0 <cil_from_wireguard>
     150:      	add	x1, sp, #0x10
     154:      	ldr	x0, [x0]
     158:      	blr	x8
     15c:      	cbz	x0, 0x7c <cil_from_wireguard+0x7c>
     160:      	str	x20, [x0]
     164:      	b	0x7c <cil_from_wireguard+0x7c>
     168:      	mov	w8, #0x1a               // =26
     16c:      	add	x2, sp, #0x28
     170:      	mov	x0, x19
     174:      	mov	w1, #0x14               // =20
     178:      	mov	w3, #0x1                // =1
     17c:      	blr	x8
     180:      	tbnz	w0, #0x1f, 0x5c <cil_from_wireguard+0x5c>
     184:      	ldrb	w8, [sp, #0x28]
     188:      	cbz	w8, 0x140 <cil_from_wireguard+0x140>
     18c:      	cmp	w8, #0x1
     190:      	b.ne	0x19c <cil_from_wireguard+0x19c>
     194:      	mov	w20, #0x15              // =21
     198:      	b	0x214 <cil_from_wireguard+0x214>
     19c:      	mov	w8, #0x1a               // =26
     1a0:      	add	x2, sp, #0xc
     1a4:      	mov	x0, x19
     1a8:      	mov	w1, #0x15               // =21
     1ac:      	mov	w3, #0x1                // =1
     1b0:      	blr	x8
     1b4:      	tbnz	w0, #0x1f, 0x5c <cil_from_wireguard+0x5c>
     1b8:      	ldrb	w8, [sp, #0x28]
     1bc:      	cmp	w8, w21
     1c0:      	b.ne	0x20c <cil_from_wireguard+0x20c>
     1c4:      	mov	w20, #0x14              // =20
     1c8:      	ldrb	w8, [sp, #0xc]
     1cc:      	cmp	w8, #0xa
     1d0:      	b.eq	0x308 <cil_from_wireguard+0x308>
     1d4:      	cmp	w8, #0x6
     1d8:      	b.eq	0x2dc <cil_from_wireguard+0x2dc>
     1dc:      	cmp	w8, #0x4
     1e0:      	b.ne	0x5c <cil_from_wireguard+0x5c>
     1e4:      	mov	w8, #0x1a               // =26
     1e8:      	add	w1, w20, #0x2
     1ec:      	add	x2, sp, #0x10
     1f0:      	mov	x0, x19
     1f4:      	mov	w3, #0x2                // =2
     1f8:      	blr	x8
     1fc:      	ldrh	w8, [sp, #0x10]
     200:      	rev	w8, w8
     204:      	lsr	w8, w8, #16
     208:      	b	0x328 <cil_from_wireguard+0x328>
     20c:      	ldrb	w8, [sp, #0xc]
     210:      	add	w20, w8, #0x14
     214:      	lsl	w8, w22, #2
     218:      	add	w22, w8, #0x14
     21c:      	cmp	w20, w22
     220:      	b.hs	0x140 <cil_from_wireguard+0x140>
     224:      	mov	w8, #0x1a               // =26
     228:      	add	x2, sp, #0x28
     22c:      	mov	x0, x19
     230:      	mov	w1, w20
     234:      	mov	w3, #0x1                // =1
     238:      	blr	x8
     23c:      	tbnz	w0, #0x1f, 0x5c <cil_from_wireguard+0x5c>
     240:      	ldrb	w8, [sp, #0x28]
     244:      	cbz	w8, 0x140 <cil_from_wireguard+0x140>
     248:      	cmp	w8, #0x1
     24c:      	b.eq	0x27c <cil_from_wireguard+0x27c>
     250:      	mov	w8, #0x1a               // =26
     254:      	add	w1, w20, #0x1
     258:      	add	x2, sp, #0xc
     25c:      	mov	x0, x19
     260:      	mov	w3, #0x1                // =1
     264:      	blr	x8
     268:      	tbnz	w0, #0x1f, 0x5c <cil_from_wireguard+0x5c>
     26c:      	ldrb	w8, [sp, #0x28]
     270:      	cmp	w8, w21
     274:      	b.eq	0x1c8 <cil_from_wireguard+0x1c8>
     278:      	ldrb	w8, [sp, #0xc]
     27c:      	add	w20, w20, w8
     280:      	cmp	w20, w22
     284:      	b.hs	0x140 <cil_from_wireguard+0x140>
     288:      	mov	w8, #0x1a               // =26
     28c:      	add	x2, sp, #0x28
     290:      	mov	x0, x19
     294:      	mov	w1, w20
     298:      	mov	w3, #0x1                // =1
     29c:      	blr	x8
     2a0:      	tbnz	w0, #0x1f, 0x5c <cil_from_wireguard+0x5c>
     2a4:      	ldrb	w8, [sp, #0x28]
     2a8:      	cmp	w8, #0x2
     2ac:      	b.lo	0x140 <cil_from_wireguard+0x140>
     2b0:      	mov	w8, #0x1a               // =26
     2b4:      	add	w1, w20, #0x1
     2b8:      	add	x2, sp, #0xc
     2bc:      	mov	x0, x19
     2c0:      	mov	w3, #0x1                // =1
     2c4:      	blr	x8
     2c8:      	tbnz	w0, #0x1f, 0x5c <cil_from_wireguard+0x5c>
     2cc:      	ldrb	w8, [sp, #0x28]
     2d0:      	cmp	w8, w21
     2d4:      	b.ne	0x140 <cil_from_wireguard+0x140>
     2d8:      	b	0x1c8 <cil_from_wireguard+0x1c8>
     2dc:      	mov	w8, #0x1a               // =26
     2e0:      	add	w1, w20, #0x2
     2e4:      	add	x2, sp, #0x10
     2e8:      	mov	x0, x19
     2ec:      	mov	w3, #0x4                // =4
     2f0:      	blr	x8
     2f4:      	ldr	w8, [sp, #0x10]
     2f8:      	cmp	w0, #0x0
     2fc:      	rev	w8, w8
     300:      	csel	w20, wzr, w8, lt
     304:      	b	0x330 <cil_from_wireguard+0x330>
     308:      	mov	w8, #0x1a               // =26
     30c:      	add	w1, w20, #0x2
     310:      	add	x2, sp, #0x10
     314:      	mov	x0, x19
     318:      	mov	w3, #0x8                // =8
     31c:      	blr	x8
     320:      	ldr	x8, [sp, #0x10]
     324:      	rev	x8, x8
     328:      	cmp	w0, #0x0
     32c:      	csel	x20, xzr, x8, lt
     330:      	tbz	w0, #0x1f, 0x144 <cil_from_wireguard+0x144>
     334:      	b	0x5c <cil_from_wireguard+0x5c>
     338:      	nop
     33c:      	nop

0000000000000340 <cil_to_wireguard>:
     340:      	sub	sp, sp, #0x50
     344:      	str	x30, [sp, #0x20]
     348:      	stp	x22, x21, [sp, #0x30]
     34c:      	stp	x20, x19, [sp, #0x40]
     350:      	ldr	w8, [x0, #0xa8]
     354:      	mov	w9, #0xf00              // =3840
     358:      	mov	x19, x0
     35c:      	bics	wzr, w9, w8
     360:      	b.ne	0x380 <cil_to_wireguard+0x40>
     364:      	adrp	x8, 0x0 <cil_from_wireguard>
     368:      	ldr	x8, [x8]
     36c:      	ldr	wzr, [x8]
     370:      	ldr	wzr, [x8]
     374:      	ldr	wzr, [x8]
     378:      	ldr	wzr, [x8]
     37c:      	ldr	wzr, [x8]
     380:      	str	wzr, [x19, #0x30]
     384:      	adrp	x8, 0x0 <cil_from_wireguard>
     388:      	str	wzr, [x19, #0x34]
     38c:      	str	wzr, [x19, #0x38]
     390:      	str	wzr, [x19, #0x3c]
     394:      	str	wzr, [x19, #0x40]
     398:      	ldr	x8, [x8]
     39c:      	ldrb	w9, [x8]
     3a0:      	cbz	w9, 0x3e8 <cil_to_wireguard+0xa8>
     3a4:      	ldrb	w21, [x8]
     3a8:      	ldrh	w8, [x19, #0xb4]
     3ac:      	cmp	w8, #0x8
     3b0:      	b.ne	0x3c8 <cil_to_wireguard+0x88>
     3b4:      	ldr	x8, [x19, #0xd0]
     3b8:      	ldr	x9, [x19, #0x50]
     3bc:      	add	x10, x8, #0x14
     3c0:      	cmp	x10, x9
     3c4:      	b.ls	0x484 <cil_to_wireguard+0x144>
     3c8:      	str	wzr, [sp, #0x10]
     3cc:      	mov	w8, #0x1                // =1
     3d0:      	adrp	x0, 0x0 <cil_from_wireguard>
     3d4:      	add	x1, sp, #0x10
     3d8:      	ldr	x0, [x0]
     3dc:      	blr	x8
     3e0:      	cbz	x0, 0x3e8 <cil_to_wireguard+0xa8>
     3e4:      	str	xzr, [x0]
     3e8:      	adrp	x8, 0x0 <cil_from_wireguard>
     3ec:      	adrp	x0, 0x0 <cil_from_wireguard>
     3f0:      	add	x1, sp, #0x28
     3f4:      	ldr	x8, [x8]
     3f8:      	ldr	wzr, [x8]
     3fc:      	mov	x8, #0x20d              // =525
     400:      	ldr	w19, [x19, #0x70]
     404:      	movk	x8, #0x17d, lsl #16
     408:      	movk	x8, #0x7, lsl #32
     40c:      	str	x8, [sp, #0x28]
     410:      	mov	w8, #0x1                // =1
     414:      	ldr	x0, [x0]
     418:      	blr	x8
     41c:      	cbz	x0, 0x448 <cil_to_wireguard+0x108>
     420:      	ldp	x8, x9, [x0]
     424:      	add	x8, x8, #0x1
     428:      	add	x9, x9, x19
     42c:      	stp	x8, x9, [x0]
     430:      	ldp	x20, x19, [sp, #0x40]
     434:      	mov	w0, wzr
     438:      	ldr	x30, [sp, #0x20]
     43c:      	ldp	x22, x21, [sp, #0x30]
     440:      	add	sp, sp, #0x50
     444:      	ret
     448:      	mov	w8, #0x1                // =1
     44c:      	adrp	x0, 0x0 <cil_from_wireguard>
     450:      	add	x1, sp, #0x28
     454:      	stp	x8, x19, [sp, #0x10]
     458:      	mov	w8, #0x2                // =2
     45c:      	add	x2, sp, #0x10
     460:      	mov	w3, wzr
     464:      	ldr	x0, [x0]
     468:      	blr	x8
     46c:      	ldp	x20, x19, [sp, #0x40]
     470:      	mov	w0, wzr
     474:      	ldr	x30, [sp, #0x20]
     478:      	ldp	x22, x21, [sp, #0x30]
     47c:      	add	sp, sp, #0x50
     480:      	ret
     484:      	ldrb	w8, [x8]
     488:      	and	w22, w8, #0xf
     48c:      	cmp	w22, #0x6
     490:      	b.hs	0x4bc <cil_to_wireguard+0x17c>
     494:      	mov	x20, xzr
     498:      	str	wzr, [sp, #0x10]
     49c:      	mov	w8, #0x1                // =1
     4a0:      	adrp	x0, 0x0 <cil_from_wireguard>
     4a4:      	add	x1, sp, #0x10
     4a8:      	ldr	x0, [x0]
     4ac:      	blr	x8
     4b0:      	cbz	x0, 0x3e8 <cil_to_wireguard+0xa8>
     4b4:      	str	x20, [x0]
     4b8:      	b	0x3e8 <cil_to_wireguard+0xa8>
     4bc:      	mov	w8, #0x1a               // =26
     4c0:      	add	x2, sp, #0x28
     4c4:      	mov	x0, x19
     4c8:      	mov	w1, #0x14               // =20
     4cc:      	mov	w3, #0x1                // =1
     4d0:      	blr	x8
     4d4:      	tbnz	w0, #0x1f, 0x3c8 <cil_to_wireguard+0x88>
     4d8:      	ldrb	w8, [sp, #0x28]
     4dc:      	cbz	w8, 0x494 <cil_to_wireguard+0x154>
     4e0:      	cmp	w8, #0x1
     4e4:      	b.ne	0x4f0 <cil_to_wireguard+0x1b0>
     4e8:      	mov	w20, #0x15              // =21
     4ec:      	b	0x568 <cil_to_wireguard+0x228>
     4f0:      	mov	w8, #0x1a               // =26
     4f4:      	add	x2, sp, #0xc
     4f8:      	mov	x0, x19
     4fc:      	mov	w1, #0x15               // =21
     500:      	mov	w3, #0x1                // =1
     504:      	blr	x8
     508:      	tbnz	w0, #0x1f, 0x3c8 <cil_to_wireguard+0x88>
     50c:      	ldrb	w8, [sp, #0x28]
     510:      	cmp	w8, w21
     514:      	b.ne	0x560 <cil_to_wireguard+0x220>
     518:      	mov	w20, #0x14              // =20
     51c:      	ldrb	w8, [sp, #0xc]
     520:      	cmp	w8, #0xa
     524:      	b.eq	0x65c <cil_to_wireguard+0x31c>
     528:      	cmp	w8, #0x6
     52c:      	b.eq	0x630 <cil_to_wireguard+0x2f0>
     530:      	cmp	w8, #0x4
     534:      	b.ne	0x3c8 <cil_to_wireguard+0x88>
     538:      	mov	w8, #0x1a               // =26
     53c:      	add	w1, w20, #0x2
     540:      	add	x2, sp, #0x10
     544:      	mov	x0, x19
     548:      	mov	w3, #0x2                // =2
     54c:      	blr	x8
     550:      	ldrh	w8, [sp, #0x10]
     554:      	rev	w8, w8
     558:      	lsr	w8, w8, #16
     55c:      	b	0x67c <cil_to_wireguard+0x33c>
     560:      	ldrb	w8, [sp, #0xc]
     564:      	add	w20, w8, #0x14
     568:      	lsl	w8, w22, #2
     56c:      	add	w22, w8, #0x14
     570:      	cmp	w20, w22
     574:      	b.hs	0x494 <cil_to_wireguard+0x154>
     578:      	mov	w8, #0x1a               // =26
     57c:      	add	x2, sp, #0x28
     580:      	mov	x0, x19
     584:      	mov	w1, w20
     588:      	mov	w3, #0x1                // =1
     58c:      	blr	x8
     590:      	tbnz	w0, #0x1f, 0x3c8 <cil_to_wireguard+0x88>
     594:      	ldrb	w8, [sp, #0x28]
     598:      	cbz	w8, 0x494 <cil_to_wireguard+0x154>
     59c:      	cmp	w8, #0x1
     5a0:      	b.eq	0x5d0 <cil_to_wireguard+0x290>
     5a4:      	mov	w8, #0x1a               // =26
     5a8:      	add	w1, w20, #0x1
     5ac:      	add	x2, sp, #0xc
     5b0:      	mov	x0, x19
     5b4:      	mov	w3, #0x1                // =1
     5b8:      	blr	x8
     5bc:      	tbnz	w0, #0x1f, 0x3c8 <cil_to_wireguard+0x88>
     5c0:      	ldrb	w8, [sp, #0x28]
     5c4:      	cmp	w8, w21
     5c8:      	b.eq	0x51c <cil_to_wireguard+0x1dc>
     5cc:      	ldrb	w8, [sp, #0xc]
     5d0:      	add	w20, w20, w8
     5d4:      	cmp	w20, w22
     5d8:      	b.hs	0x494 <cil_to_wireguard+0x154>
     5dc:      	mov	w8, #0x1a               // =26
     5e0:      	add	x2, sp, #0x28
     5e4:      	mov	x0, x19
     5e8:      	mov	w1, w20
     5ec:      	mov	w3, #0x1                // =1
     5f0:      	blr	x8
     5f4:      	tbnz	w0, #0x1f, 0x3c8 <cil_to_wireguard+0x88>
     5f8:      	ldrb	w8, [sp, #0x28]
     5fc:      	cmp	w8, #0x2
     600:      	b.lo	0x494 <cil_to_wireguard+0x154>
     604:      	mov	w8, #0x1a               // =26
     608:      	add	w1, w20, #0x1
     60c:      	add	x2, sp, #0xc
     610:      	mov	x0, x19
     614:      	mov	w3, #0x1                // =1
     618:      	blr	x8
     61c:      	tbnz	w0, #0x1f, 0x3c8 <cil_to_wireguard+0x88>
     620:      	ldrb	w8, [sp, #0x28]
     624:      	cmp	w8, w21
     628:      	b.ne	0x494 <cil_to_wireguard+0x154>
     62c:      	b	0x51c <cil_to_wireguard+0x1dc>
     630:      	mov	w8, #0x1a               // =26
     634:      	add	w1, w20, #0x2
     638:      	add	x2, sp, #0x10
     63c:      	mov	x0, x19
     640:      	mov	w3, #0x4                // =4
     644:      	blr	x8
     648:      	ldr	w8, [sp, #0x10]
     64c:      	cmp	w0, #0x0
     650:      	rev	w8, w8
     654:      	csel	w20, wzr, w8, lt
     658:      	b	0x684 <cil_to_wireguard+0x344>
     65c:      	mov	w8, #0x1a               // =26
     660:      	add	w1, w20, #0x2
     664:      	add	x2, sp, #0x10
     668:      	mov	x0, x19
     66c:      	mov	w3, #0x8                // =8
     670:      	blr	x8
     674:      	ldr	x8, [sp, #0x10]
     678:      	rev	x8, x8
     67c:      	cmp	w0, #0x0
     680:      	csel	x20, xzr, x8, lt
     684:      	tbz	w0, #0x1f, 0x498 <cil_to_wireguard+0x158>
     688:      	b	0x3c8 <cil_to_wireguard+0x88>
