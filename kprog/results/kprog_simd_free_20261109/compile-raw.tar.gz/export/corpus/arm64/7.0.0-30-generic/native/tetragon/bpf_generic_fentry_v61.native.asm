
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_fentry_v61.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <extract_arg_depth>:
       0:      	cmp	w0, #0x9
       4:      	b.ls	0x10 <extract_arg_depth+0x10>
       8:      	mov	w0, #0x1                // =1
       c:      	ret
      10:      	str	x30, [sp, #-0x20]!
      14:      	stp	x20, x19, [sp, #0x10]
      18:      	ldr	x8, [x1]
      1c:      	add	x9, x8, w0, uxtw #3
      20:      	ldrh	w9, [x9, #0x6]
      24:      	cbz	w9, 0xb4 <extract_arg_depth+0xb4>
      28:      	mov	w9, w0
      2c:      	add	x10, x8, x9, lsl #3
      30:      	ldr	x8, [x1, #0x8]
      34:      	ldr	w11, [x10]
      38:      	ldrh	w10, [x10, #0x4]
      3c:      	ldr	x9, [x8]
      40:      	add	x9, x9, x11
      44:      	str	x9, [x8]
      48:      	cbz	w10, 0x78 <extract_arg_depth+0x78>
      4c:      	ldrb	w10, [x1, #0x10]
      50:      	mov	w19, w0
      54:      	cbz	w10, 0x88 <extract_arg_depth+0x88>
      58:      	mov	w10, #0x8               // =8
      5c:      	mov	w11, #0x94              // =148
      60:      	ldr	x0, [x1, #0x8]
      64:      	mov	x20, x1
      68:      	mov	w1, #0x8                // =8
      6c:      	ldr	x2, [x0]
      70:      	blr	x11
      74:      	tbnz	w0, #0x1f, 0xa8 <extract_arg_depth+0xa8>
      78:      	mov	w0, wzr
      7c:      	ldp	x20, x19, [sp, #0x10]
      80:      	ldr	x30, [sp], #0x20
      84:      	ret
      88:      	mov	w10, #0x8               // =8
      8c:      	mov	w11, #0x4               // =4
      90:      	ldr	x0, [x1, #0x8]
      94:      	mov	x20, x1
      98:      	mov	w1, #0x8                // =8
      9c:      	ldr	x2, [x0]
      a0:      	blr	x11
      a4:      	tbz	w0, #0x1f, 0x78 <extract_arg_depth+0x78>
      a8:      	ldr	x9, [x20, #0x18]
      ac:      	add	w8, w19, #0x1
      b0:      	str	w8, [x9]
      b4:      	mov	w0, #0x1                // =1
      b8:      	ldp	x20, x19, [sp, #0x10]
      bc:      	ldr	x30, [sp], #0x20
      c0:      	ret
      c4:      	nop
      c8:      	nop
      cc:      	nop

00000000000000d0 <do_bytes>:
      d0:      	sub	sp, sp, #0x40
      d4:      	stp	x30, x23, [sp, #0x10]
      d8:      	stp	x22, x21, [sp, #0x20]
      dc:      	stp	x20, x19, [sp, #0x30]
      e0:      	mov	x19, x3
      e4:      	mov	x21, x2
      e8:      	mov	x20, x1
      ec:      	mov	x22, x0
      f0:      	bl	0x310 <__do_bytes>
      f4:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
      f8:      	and	x23, x0, #0x7fffffff
      fc:      	subs	x3, x19, x23
     100:      	b.eq	0x2f8 <do_bytes+0x228>
     104:      	add	x2, x23, x21
     108:      	mov	x0, x22
     10c:      	mov	x1, x20
     110:      	bl	0x310 <__do_bytes>
     114:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     118:      	and	x8, x0, #0x7fffffff
     11c:      	add	x23, x8, x23
     120:      	subs	x3, x19, x23
     124:      	b.eq	0x2f8 <do_bytes+0x228>
     128:      	add	x2, x23, x21
     12c:      	mov	x0, x22
     130:      	mov	x1, x20
     134:      	bl	0x310 <__do_bytes>
     138:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     13c:      	and	x8, x0, #0x7fffffff
     140:      	add	x23, x8, x23
     144:      	subs	x3, x19, x23
     148:      	b.eq	0x2f8 <do_bytes+0x228>
     14c:      	add	x2, x23, x21
     150:      	mov	x0, x22
     154:      	mov	x1, x20
     158:      	bl	0x310 <__do_bytes>
     15c:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     160:      	and	x8, x0, #0x7fffffff
     164:      	add	x23, x8, x23
     168:      	subs	x3, x19, x23
     16c:      	b.eq	0x2f8 <do_bytes+0x228>
     170:      	add	x2, x23, x21
     174:      	mov	x0, x22
     178:      	mov	x1, x20
     17c:      	bl	0x310 <__do_bytes>
     180:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     184:      	and	x8, x0, #0x7fffffff
     188:      	add	x23, x8, x23
     18c:      	subs	x3, x19, x23
     190:      	b.eq	0x2f8 <do_bytes+0x228>
     194:      	add	x2, x23, x21
     198:      	mov	x0, x22
     19c:      	mov	x1, x20
     1a0:      	bl	0x310 <__do_bytes>
     1a4:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     1a8:      	and	x8, x0, #0x7fffffff
     1ac:      	add	x23, x8, x23
     1b0:      	subs	x3, x19, x23
     1b4:      	b.eq	0x2f8 <do_bytes+0x228>
     1b8:      	add	x2, x23, x21
     1bc:      	mov	x0, x22
     1c0:      	mov	x1, x20
     1c4:      	bl	0x310 <__do_bytes>
     1c8:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     1cc:      	and	x8, x0, #0x7fffffff
     1d0:      	add	x23, x8, x23
     1d4:      	subs	x3, x19, x23
     1d8:      	b.eq	0x2f8 <do_bytes+0x228>
     1dc:      	add	x2, x23, x21
     1e0:      	mov	x0, x22
     1e4:      	mov	x1, x20
     1e8:      	bl	0x310 <__do_bytes>
     1ec:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     1f0:      	and	x8, x0, #0x7fffffff
     1f4:      	add	x23, x8, x23
     1f8:      	subs	x3, x19, x23
     1fc:      	b.eq	0x2f8 <do_bytes+0x228>
     200:      	add	x2, x23, x21
     204:      	mov	x0, x22
     208:      	mov	x1, x20
     20c:      	bl	0x310 <__do_bytes>
     210:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     214:      	and	x8, x0, #0x7fffffff
     218:      	add	x23, x8, x23
     21c:      	subs	x3, x19, x23
     220:      	b.eq	0x2f8 <do_bytes+0x228>
     224:      	add	x2, x23, x21
     228:      	mov	x0, x22
     22c:      	mov	x1, x20
     230:      	bl	0x310 <__do_bytes>
     234:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     238:      	and	x8, x0, #0x7fffffff
     23c:      	add	x19, x8, x23
     240:      	mov	x0, x19
     244:      	ldp	x20, x19, [sp, #0x30]
     248:      	ldp	x22, x21, [sp, #0x20]
     24c:      	ldp	x30, x23, [sp, #0x10]
     250:      	add	sp, sp, #0x40
     254:      	ret
     258:      	sxtw	x19, w0
     25c:      	str	wzr, [sp, #0xc]
     260:      	adrp	x0, 0x0 <extract_arg_depth>
     264:      	mov	w8, #0x1                // =1
     268:      	ldr	x0, [x0]
     26c:      	add	x9, sp, #0xc
     270:      	add	x1, sp, #0xc
     274:      	blr	x8
     278:      	cbz	x0, 0x2f8 <do_bytes+0x228>
     27c:      	cmn	x19, #0xc
     280:      	b.gt	0x2a4 <do_bytes+0x1d4>
     284:      	cmn	x19, #0x1c
     288:      	b.eq	0x2c4 <do_bytes+0x1f4>
     28c:      	cmn	x19, #0x16
     290:      	b.eq	0x2dc <do_bytes+0x20c>
     294:      	cmn	x19, #0x10
     298:      	b.ne	0x2d4 <do_bytes+0x204>
     29c:      	add	x8, x0, #0x558
     2a0:      	b	0x2e8 <do_bytes+0x218>
     2a4:      	cmn	x19, #0xb
     2a8:      	b.eq	0x2cc <do_bytes+0x1fc>
     2ac:      	cmn	x19, #0x7
     2b0:      	b.eq	0x2e4 <do_bytes+0x214>
     2b4:      	cmn	x19, #0x2
     2b8:      	b.ne	0x2d4 <do_bytes+0x204>
     2bc:      	add	x8, x0, #0x548
     2c0:      	b	0x2e8 <do_bytes+0x218>
     2c4:      	add	x8, x0, #0x568
     2c8:      	b	0x2e8 <do_bytes+0x218>
     2cc:      	add	x8, x0, #0x570
     2d0:      	b	0x2e8 <do_bytes+0x218>
     2d4:      	add	x8, x0, #0x540
     2d8:      	b	0x2e8 <do_bytes+0x218>
     2dc:      	add	x8, x0, #0x560
     2e0:      	b	0x2e8 <do_bytes+0x218>
     2e4:      	add	x8, x0, #0x550
     2e8:      	ldaxr	x9, [x8]
     2ec:      	add	x9, x9, #0x1
     2f0:      	stlxr	w10, x9, [x8]
     2f4:      	cbnz	w10, 0x2e8 <do_bytes+0x218>
     2f8:      	mov	x0, x19
     2fc:      	ldp	x20, x19, [sp, #0x30]
     300:      	ldp	x22, x21, [sp, #0x20]
     304:      	ldp	x30, x23, [sp, #0x10]
     308:      	add	sp, sp, #0x40
     30c:      	ret

0000000000000310 <__do_bytes>:
     310:      	str	x30, [sp, #-0x30]!
     314:      	stp	x22, x21, [sp, #0x10]
     318:      	stp	x20, x19, [sp, #0x20]
     31c:      	tbnz	x3, #0x3f, 0x3b4 <__do_bytes+0xa4>
     320:      	mov	w8, #0x7fe0             // =32736
     324:      	mov	x22, x0
     328:      	add	x0, x1, #0x20
     32c:      	mov	x20, x1
     330:      	cmp	x3, x8
     334:      	csel	x19, x3, x8, lo
     338:      	mov	w8, #0x4                // =4
     33c:      	mov	w1, w19
     340:      	blr	x8
     344:      	tbnz	w0, #0x1f, 0x3ec <__do_bytes+0xdc>
     348:      	add	w21, w19, #0x20
     34c:      	str	wzr, [sp, #0xc]
     350:      	adrp	x0, 0x0 <extract_arg_depth>
     354:      	mov	w8, #0x1                // =1
     358:      	str	w21, [x20, #0x4]
     35c:      	add	x9, sp, #0xc
     360:      	add	x1, sp, #0xc
     364:      	ldr	x0, [x0]
     368:      	blr	x8
     36c:      	cbz	x0, 0x3cc <__do_bytes+0xbc>
     370:      	ldrb	w8, [x0, #0x28]
     374:      	cbz	w8, 0x3cc <__do_bytes+0xbc>
     378:      	adrp	x1, 0x0 <extract_arg_depth>
     37c:      	mov	w8, #-0x1               // =-1
     380:      	mov	w9, #0x19               // =25
     384:      	ldr	x1, [x1]
     388:      	mov	x0, x22
     38c:      	mov	w2, #-0x1               // =-1
     390:      	mov	x3, x20
     394:      	mov	x4, x21
     398:      	blr	x9
     39c:      	tbnz	w0, #0x1f, 0x3ec <__do_bytes+0xdc>
     3a0:      	mov	x0, x19
     3a4:      	ldp	x20, x19, [sp, #0x20]
     3a8:      	ldp	x22, x21, [sp, #0x10]
     3ac:      	ldr	x30, [sp], #0x30
     3b0:      	ret
     3b4:      	mov	x19, #-0x1              // =-1
     3b8:      	mov	x0, x19
     3bc:      	ldp	x20, x19, [sp, #0x20]
     3c0:      	ldp	x22, x21, [sp, #0x10]
     3c4:      	ldr	x30, [sp], #0x30
     3c8:      	ret
     3cc:      	adrp	x0, 0x0 <extract_arg_depth>
     3d0:      	mov	x3, xzr
     3d4:      	mov	w8, #0x82               // =130
     3d8:      	ldr	x0, [x0]
     3dc:      	mov	x1, x20
     3e0:      	mov	x2, x21
     3e4:      	blr	x8
     3e8:      	tbz	w0, #0x1f, 0x3a0 <__do_bytes+0x90>
     3ec:      	sxtw	x19, w0
     3f0:      	mov	x0, x19
     3f4:      	ldp	x20, x19, [sp, #0x20]
     3f8:      	ldp	x22, x21, [sp, #0x10]
     3fc:      	ldr	x30, [sp], #0x30
     400:      	ret
     404:      	nop
     408:      	nop
     40c:      	nop

0000000000000410 <filter_64ty>:
     410:      	str	x30, [sp, #-0x10]!
     414:      	mov	x8, x0
     418:      	mov	x0, xzr
     41c:      	ldr	w9, [x8, #0x4]
     420:      	cmp	w9, #0x20
     424:      	b.hi	0x484 <filter_64ty+0x74>
     428:      	mov	w10, #0x1               // =1
     42c:      	mov	w11, #0x101e            // =4126
     430:      	lsl	x10, x10, x9
     434:      	tst	x10, x11
     438:      	b.eq	0x44c <filter_64ty+0x3c>
     43c:      	mov	x0, x8
     440:      	bl	0x610 <filter_64ty_selector_val>
     444:      	ldr	x30, [sp], #0x10
     448:      	ret
     44c:      	mov	w10, #0x1               // =1
     450:      	lsl	x10, x10, x9
     454:      	tst	x10, #0xc00
     458:      	b.ne	0x47c <filter_64ty+0x6c>
     45c:      	mov	w10, #0x1               // =1
     460:      	lsl	x9, x10, x9
     464:      	tst	x9, #0x180000000
     468:      	b.eq	0x484 <filter_64ty+0x74>
     46c:      	mov	x0, x8
     470:      	bl	0xa10 <filter_64ty_range>
     474:      	ldr	x30, [sp], #0x10
     478:      	ret
     47c:      	mov	x0, x8
     480:      	bl	0x970 <filter_64ty_map>
     484:      	ldr	x30, [sp], #0x10
     488:      	ret
     48c:      	nop

0000000000000490 <filter_32ty>:
     490:      	str	x30, [sp, #-0x10]!
     494:      	mov	x8, x0
     498:      	mov	x0, xzr
     49c:      	ldr	w9, [x8, #0x4]
     4a0:      	cmp	w9, #0x20
     4a4:      	b.hi	0x504 <filter_32ty+0x74>
     4a8:      	mov	w10, #0x1               // =1
     4ac:      	mov	w11, #0x101e            // =4126
     4b0:      	lsl	x10, x10, x9
     4b4:      	tst	x10, x11
     4b8:      	b.eq	0x4cc <filter_32ty+0x3c>
     4bc:      	mov	x0, x8
     4c0:      	bl	0xc60 <filter_32ty_selector_val>
     4c4:      	ldr	x30, [sp], #0x10
     4c8:      	ret
     4cc:      	mov	w10, #0x1               // =1
     4d0:      	lsl	x10, x10, x9
     4d4:      	tst	x10, #0xc00
     4d8:      	b.ne	0x4fc <filter_32ty+0x6c>
     4dc:      	mov	w10, #0x1               // =1
     4e0:      	lsl	x9, x10, x9
     4e4:      	tst	x9, #0x180000000
     4e8:      	b.eq	0x504 <filter_32ty+0x74>
     4ec:      	mov	x0, x8
     4f0:      	bl	0x1080 <filter_32ty_range>
     4f4:      	ldr	x30, [sp], #0x10
     4f8:      	ret
     4fc:      	mov	x0, x8
     500:      	bl	0xfc0 <filter_32ty_map>
     504:      	ldr	x30, [sp], #0x10
     508:      	ret
     50c:      	nop

0000000000000510 <filter_16ty>:
     510:      	str	x30, [sp, #-0x10]!
     514:      	mov	x8, x0
     518:      	mov	x0, xzr
     51c:      	ldr	w9, [x8, #0x4]
     520:      	cmp	w9, #0x20
     524:      	b.hi	0x584 <filter_16ty+0x74>
     528:      	mov	w10, #0x1               // =1
     52c:      	mov	w11, #0x101e            // =4126
     530:      	lsl	x10, x10, x9
     534:      	tst	x10, x11
     538:      	b.eq	0x54c <filter_16ty+0x3c>
     53c:      	mov	x0, x8
     540:      	bl	0x12d0 <filter_16ty_selector_val>
     544:      	ldr	x30, [sp], #0x10
     548:      	ret
     54c:      	mov	w10, #0x1               // =1
     550:      	lsl	x10, x10, x9
     554:      	tst	x10, #0xc00
     558:      	b.ne	0x57c <filter_16ty+0x6c>
     55c:      	mov	w10, #0x1               // =1
     560:      	lsl	x9, x10, x9
     564:      	tst	x9, #0x180000000
     568:      	b.eq	0x584 <filter_16ty+0x74>
     56c:      	mov	x0, x8
     570:      	bl	0x16f0 <filter_16ty_range>
     574:      	ldr	x30, [sp], #0x10
     578:      	ret
     57c:      	mov	x0, x8
     580:      	bl	0x1630 <filter_16ty_map>
     584:      	ldr	x30, [sp], #0x10
     588:      	ret
     58c:      	nop

0000000000000590 <filter_8ty>:
     590:      	str	x30, [sp, #-0x10]!
     594:      	mov	x8, x0
     598:      	mov	x0, xzr
     59c:      	ldr	w9, [x8, #0x4]
     5a0:      	cmp	w9, #0x20
     5a4:      	b.hi	0x604 <filter_8ty+0x74>
     5a8:      	mov	w10, #0x1               // =1
     5ac:      	mov	w11, #0x101e            // =4126
     5b0:      	lsl	x10, x10, x9
     5b4:      	tst	x10, x11
     5b8:      	b.eq	0x5cc <filter_8ty+0x3c>
     5bc:      	mov	x0, x8
     5c0:      	bl	0x1940 <filter_8ty_selector_val>
     5c4:      	ldr	x30, [sp], #0x10
     5c8:      	ret
     5cc:      	mov	w10, #0x1               // =1
     5d0:      	lsl	x10, x10, x9
     5d4:      	tst	x10, #0xc00
     5d8:      	b.ne	0x5fc <filter_8ty+0x6c>
     5dc:      	mov	w10, #0x1               // =1
     5e0:      	lsl	x9, x10, x9
     5e4:      	tst	x9, #0x180000000
     5e8:      	b.eq	0x604 <filter_8ty+0x74>
     5ec:      	mov	x0, x8
     5f0:      	bl	0x1d60 <filter_8ty_range>
     5f4:      	ldr	x30, [sp], #0x10
     5f8:      	ret
     5fc:      	mov	x0, x8
     600:      	bl	0x1ca0 <filter_8ty_map>
     604:      	ldr	x30, [sp], #0x10
     608:      	ret
     60c:      	nop

0000000000000610 <filter_64ty_selector_val>:
     610:      	ldr	w8, [x0, #0x4]
     614:      	cmp	w8, #0x25
     618:      	b.hi	0x68c <filter_64ty_selector_val+0x7c>
     61c:      	mov	x10, #0x40              // =64
     620:      	mov	w9, #0x1                // =1
     624:      	movk	x10, #0xc00, lsl #16
     628:      	lsl	x9, x9, x8
     62c:      	movk	x10, #0x20, lsl #32
     630:      	tst	x9, x10
     634:      	b.eq	0x640 <filter_64ty_selector_val+0x30>
     638:      	mov	w0, #0x1                // =1
     63c:      	ret
     640:      	mov	w9, #0x1                // =1
     644:      	lsl	x9, x9, x8
     648:      	tst	x9, #0x18
     64c:      	b.eq	0x66c <filter_64ty_selector_val+0x5c>
     650:      	ldr	x9, [x1]
     654:      	ldr	x10, [x0, #0x10]
     658:      	cmp	x9, x10
     65c:      	b.ne	0x70c <filter_64ty_selector_val+0xfc>
     660:      	cmp	w8, #0x3
     664:      	cset	w0, eq
     668:      	ret
     66c:      	cmp	x8, #0xc
     670:      	b.ne	0x68c <filter_64ty_selector_val+0x7c>
     674:      	ldr	x8, [x1]
     678:      	ldr	x9, [x0, #0x10]
     67c:      	tst	x8, x9
     680:      	b.eq	0x7b8 <filter_64ty_selector_val+0x1a8>
     684:      	mov	w0, #0x1                // =1
     688:      	ret
     68c:      	cmp	w8, #0x1
     690:      	b.eq	0x6d4 <filter_64ty_selector_val+0xc4>
     694:      	cmp	w8, #0x2
     698:      	b.ne	0x960 <filter_64ty_selector_val+0x350>
     69c:      	ldr	w8, [x0, #0xc]
     6a0:      	cmp	w8, #0xc
     6a4:      	b.hi	0x7f0 <filter_64ty_selector_val+0x1e0>
     6a8:      	mov	w9, #0x1                // =1
     6ac:      	lsl	w8, w9, w8
     6b0:      	mov	w9, #0x1402             // =5122
     6b4:      	tst	w8, w9
     6b8:      	b.eq	0x7f0 <filter_64ty_selector_val+0x1e0>
     6bc:      	ldr	x8, [x1]
     6c0:      	ldr	x9, [x0, #0x10]
     6c4:      	cmp	x8, x9
     6c8:      	b.ge	0x798 <filter_64ty_selector_val+0x188>
     6cc:      	mov	w0, #0x1                // =1
     6d0:      	ret
     6d4:      	ldr	w8, [x0, #0xc]
     6d8:      	cmp	w8, #0xc
     6dc:      	b.hi	0x7d8 <filter_64ty_selector_val+0x1c8>
     6e0:      	mov	w9, #0x1                // =1
     6e4:      	lsl	w8, w9, w8
     6e8:      	mov	w9, #0x1402             // =5122
     6ec:      	tst	w8, w9
     6f0:      	b.eq	0x7d8 <filter_64ty_selector_val+0x1c8>
     6f4:      	ldr	x8, [x1]
     6f8:      	ldr	x9, [x0, #0x10]
     6fc:      	cmp	x8, x9
     700:      	b.le	0x778 <filter_64ty_selector_val+0x168>
     704:      	mov	w0, #0x1                // =1
     708:      	ret
     70c:      	ldr	w10, [x0, #0x8]
     710:      	cmp	w10, #0x11
     714:      	b.lo	0x74c <filter_64ty_selector_val+0x13c>
     718:      	ldr	x11, [x0, #0x18]
     71c:      	cmp	x9, x11
     720:      	b.eq	0x660 <filter_64ty_selector_val+0x50>
     724:      	cmp	w10, #0x19
     728:      	b.lo	0x74c <filter_64ty_selector_val+0x13c>
     72c:      	ldr	x11, [x0, #0x20]
     730:      	cmp	x9, x11
     734:      	b.eq	0x660 <filter_64ty_selector_val+0x50>
     738:      	cmp	w10, #0x21
     73c:      	b.lo	0x74c <filter_64ty_selector_val+0x13c>
     740:      	ldr	x10, [x0, #0x28]
     744:      	cmp	x9, x10
     748:      	b.eq	0x660 <filter_64ty_selector_val+0x50>
     74c:      	cmp	w8, #0x25
     750:      	b.hi	0x960 <filter_64ty_selector_val+0x350>
     754:      	mov	w9, #0x1                // =1
     758:      	lsl	x8, x9, x8
     75c:      	mov	x9, #0x50               // =80
     760:      	movk	x9, #0xc00, lsl #16
     764:      	movk	x9, #0x20, lsl #32
     768:      	tst	x8, x9
     76c:      	b.eq	0x960 <filter_64ty_selector_val+0x350>
     770:      	mov	w0, #0x1                // =1
     774:      	ret
     778:      	ldr	w9, [x0, #0x8]
     77c:      	cmp	w9, #0x11
     780:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     784:      	ldr	x10, [x0, #0x18]
     788:      	cmp	x8, x10
     78c:      	b.le	0x848 <filter_64ty_selector_val+0x238>
     790:      	mov	w0, #0x1                // =1
     794:      	ret
     798:      	ldr	w9, [x0, #0x8]
     79c:      	cmp	w9, #0x11
     7a0:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     7a4:      	ldr	x10, [x0, #0x18]
     7a8:      	cmp	x8, x10
     7ac:      	b.ge	0x864 <filter_64ty_selector_val+0x254>
     7b0:      	mov	w0, #0x1                // =1
     7b4:      	ret
     7b8:      	ldr	w9, [x0, #0x8]
     7bc:      	cmp	w9, #0x11
     7c0:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     7c4:      	ldr	x10, [x0, #0x18]
     7c8:      	tst	x8, x10
     7cc:      	b.eq	0x880 <filter_64ty_selector_val+0x270>
     7d0:      	mov	w0, #0x1                // =1
     7d4:      	ret
     7d8:      	ldr	x8, [x1]
     7dc:      	ldr	x9, [x0, #0x10]
     7e0:      	cmp	x8, x9
     7e4:      	b.ls	0x808 <filter_64ty_selector_val+0x1f8>
     7e8:      	mov	w0, #0x1                // =1
     7ec:      	ret
     7f0:      	ldr	x8, [x1]
     7f4:      	ldr	x9, [x0, #0x10]
     7f8:      	cmp	x8, x9
     7fc:      	b.hs	0x828 <filter_64ty_selector_val+0x218>
     800:      	mov	w0, #0x1                // =1
     804:      	ret
     808:      	ldr	w9, [x0, #0x8]
     80c:      	cmp	w9, #0x11
     810:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     814:      	ldr	x10, [x0, #0x18]
     818:      	cmp	x8, x10
     81c:      	b.ls	0x89c <filter_64ty_selector_val+0x28c>
     820:      	mov	w0, #0x1                // =1
     824:      	ret
     828:      	ldr	w9, [x0, #0x8]
     82c:      	cmp	w9, #0x11
     830:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     834:      	ldr	x10, [x0, #0x18]
     838:      	cmp	x8, x10
     83c:      	b.hs	0x8b8 <filter_64ty_selector_val+0x2a8>
     840:      	mov	w0, #0x1                // =1
     844:      	ret
     848:      	cmp	w9, #0x19
     84c:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     850:      	ldr	x10, [x0, #0x20]
     854:      	cmp	x8, x10
     858:      	b.le	0x8d4 <filter_64ty_selector_val+0x2c4>
     85c:      	mov	w0, #0x1                // =1
     860:      	ret
     864:      	cmp	w9, #0x19
     868:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     86c:      	ldr	x10, [x0, #0x20]
     870:      	cmp	x8, x10
     874:      	b.ge	0x8f0 <filter_64ty_selector_val+0x2e0>
     878:      	mov	w0, #0x1                // =1
     87c:      	ret
     880:      	cmp	w9, #0x19
     884:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     888:      	ldr	x10, [x0, #0x20]
     88c:      	tst	x8, x10
     890:      	b.eq	0x90c <filter_64ty_selector_val+0x2fc>
     894:      	mov	w0, #0x1                // =1
     898:      	ret
     89c:      	cmp	w9, #0x19
     8a0:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     8a4:      	ldr	x10, [x0, #0x20]
     8a8:      	cmp	x8, x10
     8ac:      	b.ls	0x928 <filter_64ty_selector_val+0x318>
     8b0:      	mov	w0, #0x1                // =1
     8b4:      	ret
     8b8:      	cmp	w9, #0x19
     8bc:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     8c0:      	ldr	x10, [x0, #0x20]
     8c4:      	cmp	x8, x10
     8c8:      	b.hs	0x944 <filter_64ty_selector_val+0x334>
     8cc:      	mov	w0, #0x1                // =1
     8d0:      	ret
     8d4:      	cmp	w9, #0x21
     8d8:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     8dc:      	ldr	x9, [x0, #0x28]
     8e0:      	cmp	x8, x9
     8e4:      	b.le	0x960 <filter_64ty_selector_val+0x350>
     8e8:      	mov	w0, #0x1                // =1
     8ec:      	ret
     8f0:      	cmp	w9, #0x21
     8f4:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     8f8:      	ldr	x9, [x0, #0x28]
     8fc:      	cmp	x8, x9
     900:      	b.ge	0x960 <filter_64ty_selector_val+0x350>
     904:      	mov	w0, #0x1                // =1
     908:      	ret
     90c:      	cmp	w9, #0x21
     910:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     914:      	ldr	x9, [x0, #0x28]
     918:      	tst	x8, x9
     91c:      	b.eq	0x960 <filter_64ty_selector_val+0x350>
     920:      	mov	w0, #0x1                // =1
     924:      	ret
     928:      	cmp	w9, #0x21
     92c:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     930:      	ldr	x9, [x0, #0x28]
     934:      	cmp	x8, x9
     938:      	b.ls	0x960 <filter_64ty_selector_val+0x350>
     93c:      	mov	w0, #0x1                // =1
     940:      	ret
     944:      	cmp	w9, #0x21
     948:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     94c:      	ldr	x9, [x0, #0x28]
     950:      	cmp	x8, x9
     954:      	b.hs	0x960 <filter_64ty_selector_val+0x350>
     958:      	mov	w0, #0x1                // =1
     95c:      	ret
     960:      	mov	x0, xzr
     964:      	ret
     968:      	nop
     96c:      	nop

0000000000000970 <filter_64ty_map>:
     970:      	sub	sp, sp, #0x30
     974:      	str	x30, [sp, #0x10]
     978:      	stp	x20, x19, [sp, #0x20]
     97c:      	ldrb	w8, [x0, #0x10]
     980:      	mov	x19, x0
     984:      	adrp	x0, 0x0 <extract_arg_depth>
     988:      	add	x9, sp, #0x1c
     98c:      	str	w8, [sp, #0x1c]
     990:      	mov	w8, #0x1                // =1
     994:      	mov	x20, x1
     998:      	add	x1, sp, #0x1c
     99c:      	ldr	x0, [x0]
     9a0:      	blr	x8
     9a4:      	cbz	x0, 0x9f4 <filter_64ty_map+0x84>
     9a8:      	ldr	x8, [x20]
     9ac:      	add	x9, sp, #0x8
     9b0:      	add	x1, sp, #0x8
     9b4:      	str	x8, [sp, #0x8]
     9b8:      	mov	w8, #0x1                // =1
     9bc:      	blr	x8
     9c0:      	ldr	w8, [x19, #0x4]
     9c4:      	cmp	w8, #0xb
     9c8:      	b.eq	0x9e0 <filter_64ty_map+0x70>
     9cc:      	cmp	w8, #0xa
     9d0:      	b.ne	0x9ec <filter_64ty_map+0x7c>
     9d4:      	cmp	x0, #0x0
     9d8:      	cset	w8, ne
     9dc:      	b	0x9f0 <filter_64ty_map+0x80>
     9e0:      	cmp	x0, #0x0
     9e4:      	cset	w8, eq
     9e8:      	b	0x9f0 <filter_64ty_map+0x80>
     9ec:      	mov	w8, wzr
     9f0:      	mov	w0, w8
     9f4:      	ldp	x20, x19, [sp, #0x20]
     9f8:      	ldr	x30, [sp, #0x10]
     9fc:      	add	sp, sp, #0x30
     a00:      	ret
     a04:      	nop
     a08:      	nop
     a0c:      	nop

0000000000000a10 <filter_64ty_range>:
     a10:      	ldr	w9, [x0, #0xc]
     a14:      	ldr	w8, [x0, #0x4]
     a18:      	mov	w10, #0x1               // =1
     a1c:      	cmp	w9, #0xc
     a20:      	lsl	w9, w10, w9
     a24:      	mov	w10, #0x1402            // =5122
     a28:      	and	w9, w9, w10
     a2c:      	ccmp	w9, #0x0, #0x4, ls
     a30:      	b.eq	0xb30 <filter_64ty_range+0x120>
     a34:      	ldr	x10, [x1]
     a38:      	cmp	w8, #0x1f
     a3c:      	b.ne	0xac4 <filter_64ty_range+0xb4>
     a40:      	ldr	x9, [x0, #0x10]
     a44:      	cmp	x9, x10
     a48:      	b.gt	0xa58 <filter_64ty_range+0x48>
     a4c:      	ldr	x9, [x0, #0x18]
     a50:      	cmp	x10, x9
     a54:      	b.le	0xb54 <filter_64ty_range+0x144>
     a58:      	ldr	w9, [x0, #0x8]
     a5c:      	cmp	w9, #0x19
     a60:      	b.lo	0xc40 <filter_64ty_range+0x230>
     a64:      	ldr	x11, [x0, #0x20]
     a68:      	cmp	x11, x10
     a6c:      	b.gt	0xa7c <filter_64ty_range+0x6c>
     a70:      	ldr	x11, [x0, #0x28]
     a74:      	cmp	x10, x11
     a78:      	b.le	0xb54 <filter_64ty_range+0x144>
     a7c:      	cmp	w9, #0x29
     a80:      	b.lo	0xc40 <filter_64ty_range+0x230>
     a84:      	ldr	x11, [x0, #0x30]
     a88:      	cmp	x11, x10
     a8c:      	b.gt	0xa9c <filter_64ty_range+0x8c>
     a90:      	ldr	x11, [x0, #0x38]
     a94:      	cmp	x10, x11
     a98:      	b.le	0xb54 <filter_64ty_range+0x144>
     a9c:      	cmp	w9, #0x39
     aa0:      	b.lo	0xc40 <filter_64ty_range+0x230>
     aa4:      	ldr	x11, [x0, #0x40]
     aa8:      	mov	w9, wzr
     aac:      	cmp	x11, x10
     ab0:      	b.gt	0xc30 <filter_64ty_range+0x220>
     ab4:      	ldr	x11, [x0, #0x48]
     ab8:      	cmp	x10, x11
     abc:      	b.le	0xb54 <filter_64ty_range+0x144>
     ac0:      	b	0xc30 <filter_64ty_range+0x220>
     ac4:      	ldp	x9, x12, [x0, #0x10]
     ac8:      	cmp	x9, x10
     acc:      	ldr	w11, [x0, #0x8]
     ad0:      	ccmp	x10, x12, #0x0, le
     ad4:      	cset	w9, le
     ad8:      	cmp	w11, #0x19
     adc:      	b.lo	0xc30 <filter_64ty_range+0x220>
     ae0:      	ldp	x12, x13, [x0, #0x20]
     ae4:      	cmp	x12, x10
     ae8:      	ccmp	x10, x13, #0x0, le
     aec:      	csinc	w9, w9, wzr, gt
     af0:      	cmp	w11, #0x29
     af4:      	b.lo	0xc30 <filter_64ty_range+0x220>
     af8:      	ldp	x12, x13, [x0, #0x30]
     afc:      	cmp	x12, x10
     b00:      	ccmp	x10, x13, #0x0, le
     b04:      	csinc	w9, w9, wzr, gt
     b08:      	cmp	w11, #0x39
     b0c:      	b.lo	0xc30 <filter_64ty_range+0x220>
     b10:      	ldp	x11, x12, [x0, #0x40]
     b14:      	cmp	x11, x10
     b18:      	ccmp	x10, x12, #0x0, le
     b1c:      	csinc	w9, w9, wzr, gt
     b20:      	cmp	w8, #0x20
     b24:      	eor	w8, w9, #0x1
     b28:      	csel	w0, wzr, w8, ne
     b2c:      	ret
     b30:      	ldr	x10, [x1]
     b34:      	cmp	w8, #0x1f
     b38:      	b.ne	0xb5c <filter_64ty_range+0x14c>
     b3c:      	ldr	x9, [x0, #0x10]
     b40:      	cmp	x9, x10
     b44:      	b.hi	0xbc8 <filter_64ty_range+0x1b8>
     b48:      	ldr	x9, [x0, #0x18]
     b4c:      	cmp	x10, x9
     b50:      	b.hi	0xbc8 <filter_64ty_range+0x1b8>
     b54:      	mov	w0, #0x1                // =1
     b58:      	ret
     b5c:      	ldp	x9, x12, [x0, #0x10]
     b60:      	cmp	x9, x10
     b64:      	ldr	w11, [x0, #0x8]
     b68:      	ccmp	x10, x12, #0x2, ls
     b6c:      	cset	w9, ls
     b70:      	cmp	w11, #0x19
     b74:      	b.lo	0xc30 <filter_64ty_range+0x220>
     b78:      	ldp	x12, x13, [x0, #0x20]
     b7c:      	cmp	x12, x10
     b80:      	ccmp	x10, x13, #0x2, ls
     b84:      	csinc	w9, w9, wzr, hi
     b88:      	cmp	w11, #0x29
     b8c:      	b.lo	0xc30 <filter_64ty_range+0x220>
     b90:      	ldp	x12, x13, [x0, #0x30]
     b94:      	cmp	x12, x10
     b98:      	ccmp	x10, x13, #0x2, ls
     b9c:      	csinc	w9, w9, wzr, hi
     ba0:      	cmp	w11, #0x39
     ba4:      	b.lo	0xc30 <filter_64ty_range+0x220>
     ba8:      	ldp	x11, x12, [x0, #0x40]
     bac:      	cmp	x11, x10
     bb0:      	ccmp	x10, x12, #0x2, ls
     bb4:      	csinc	w9, w9, wzr, hi
     bb8:      	cmp	w8, #0x20
     bbc:      	eor	w8, w9, #0x1
     bc0:      	csel	w0, wzr, w8, ne
     bc4:      	ret
     bc8:      	ldr	w9, [x0, #0x8]
     bcc:      	cmp	w9, #0x19
     bd0:      	b.lo	0xc40 <filter_64ty_range+0x230>
     bd4:      	ldr	x11, [x0, #0x20]
     bd8:      	cmp	x11, x10
     bdc:      	b.hi	0xbec <filter_64ty_range+0x1dc>
     be0:      	ldr	x11, [x0, #0x28]
     be4:      	cmp	x10, x11
     be8:      	b.ls	0xb54 <filter_64ty_range+0x144>
     bec:      	cmp	w9, #0x29
     bf0:      	b.lo	0xc40 <filter_64ty_range+0x230>
     bf4:      	ldr	x11, [x0, #0x30]
     bf8:      	cmp	x11, x10
     bfc:      	b.hi	0xc0c <filter_64ty_range+0x1fc>
     c00:      	ldr	x11, [x0, #0x38]
     c04:      	cmp	x10, x11
     c08:      	b.ls	0xb54 <filter_64ty_range+0x144>
     c0c:      	cmp	w9, #0x39
     c10:      	b.lo	0xc40 <filter_64ty_range+0x230>
     c14:      	ldr	x11, [x0, #0x40]
     c18:      	mov	w9, wzr
     c1c:      	cmp	x11, x10
     c20:      	b.hi	0xc30 <filter_64ty_range+0x220>
     c24:      	ldr	x11, [x0, #0x48]
     c28:      	cmp	x10, x11
     c2c:      	b.ls	0xb54 <filter_64ty_range+0x144>
     c30:      	cmp	w8, #0x20
     c34:      	eor	w8, w9, #0x1
     c38:      	csel	w0, wzr, w8, ne
     c3c:      	ret
     c40:      	mov	w9, wzr
     c44:      	cmp	w8, #0x20
     c48:      	eor	w8, w9, #0x1
     c4c:      	csel	w0, wzr, w8, ne
     c50:      	ret
     c54:      	nop
     c58:      	nop
     c5c:      	nop

0000000000000c60 <filter_32ty_selector_val>:
     c60:      	ldr	w8, [x0, #0x4]
     c64:      	cmp	w8, #0x25
     c68:      	b.hi	0xcdc <filter_32ty_selector_val+0x7c>
     c6c:      	mov	x10, #0x40              // =64
     c70:      	mov	w9, #0x1                // =1
     c74:      	movk	x10, #0xc00, lsl #16
     c78:      	lsl	x9, x9, x8
     c7c:      	movk	x10, #0x20, lsl #32
     c80:      	tst	x9, x10
     c84:      	b.eq	0xc90 <filter_32ty_selector_val+0x30>
     c88:      	mov	w0, #0x1                // =1
     c8c:      	ret
     c90:      	mov	w9, #0x1                // =1
     c94:      	lsl	x9, x9, x8
     c98:      	tst	x9, #0x18
     c9c:      	b.eq	0xcbc <filter_32ty_selector_val+0x5c>
     ca0:      	ldr	w9, [x1]
     ca4:      	ldr	w10, [x0, #0x10]
     ca8:      	cmp	w9, w10
     cac:      	b.ne	0xd5c <filter_32ty_selector_val+0xfc>
     cb0:      	cmp	w8, #0x3
     cb4:      	cset	w0, eq
     cb8:      	ret
     cbc:      	cmp	x8, #0xc
     cc0:      	b.ne	0xcdc <filter_32ty_selector_val+0x7c>
     cc4:      	ldr	w8, [x1]
     cc8:      	ldr	w9, [x0, #0x10]
     ccc:      	tst	w8, w9
     cd0:      	b.eq	0xe08 <filter_32ty_selector_val+0x1a8>
     cd4:      	mov	w0, #0x1                // =1
     cd8:      	ret
     cdc:      	cmp	w8, #0x1
     ce0:      	b.eq	0xd24 <filter_32ty_selector_val+0xc4>
     ce4:      	cmp	w8, #0x2
     ce8:      	b.ne	0xfb0 <filter_32ty_selector_val+0x350>
     cec:      	ldr	w8, [x0, #0xc]
     cf0:      	cmp	w8, #0xc
     cf4:      	b.hi	0xe40 <filter_32ty_selector_val+0x1e0>
     cf8:      	mov	w9, #0x1                // =1
     cfc:      	lsl	w8, w9, w8
     d00:      	mov	w9, #0x1402             // =5122
     d04:      	tst	w8, w9
     d08:      	b.eq	0xe40 <filter_32ty_selector_val+0x1e0>
     d0c:      	ldr	w8, [x1]
     d10:      	ldr	w9, [x0, #0x10]
     d14:      	cmp	w8, w9
     d18:      	b.ge	0xde8 <filter_32ty_selector_val+0x188>
     d1c:      	mov	w0, #0x1                // =1
     d20:      	ret
     d24:      	ldr	w8, [x0, #0xc]
     d28:      	cmp	w8, #0xc
     d2c:      	b.hi	0xe28 <filter_32ty_selector_val+0x1c8>
     d30:      	mov	w9, #0x1                // =1
     d34:      	lsl	w8, w9, w8
     d38:      	mov	w9, #0x1402             // =5122
     d3c:      	tst	w8, w9
     d40:      	b.eq	0xe28 <filter_32ty_selector_val+0x1c8>
     d44:      	ldr	w8, [x1]
     d48:      	ldr	w9, [x0, #0x10]
     d4c:      	cmp	w8, w9
     d50:      	b.le	0xdc8 <filter_32ty_selector_val+0x168>
     d54:      	mov	w0, #0x1                // =1
     d58:      	ret
     d5c:      	ldr	w10, [x0, #0x8]
     d60:      	cmp	w10, #0xd
     d64:      	b.lo	0xd9c <filter_32ty_selector_val+0x13c>
     d68:      	ldr	w11, [x0, #0x14]
     d6c:      	cmp	w9, w11
     d70:      	b.eq	0xcb0 <filter_32ty_selector_val+0x50>
     d74:      	cmp	w10, #0x11
     d78:      	b.lo	0xd9c <filter_32ty_selector_val+0x13c>
     d7c:      	ldr	w11, [x0, #0x18]
     d80:      	cmp	w9, w11
     d84:      	b.eq	0xcb0 <filter_32ty_selector_val+0x50>
     d88:      	cmp	w10, #0x15
     d8c:      	b.lo	0xd9c <filter_32ty_selector_val+0x13c>
     d90:      	ldr	w10, [x0, #0x1c]
     d94:      	cmp	w9, w10
     d98:      	b.eq	0xcb0 <filter_32ty_selector_val+0x50>
     d9c:      	cmp	w8, #0x25
     da0:      	b.hi	0xfb0 <filter_32ty_selector_val+0x350>
     da4:      	mov	w9, #0x1                // =1
     da8:      	lsl	x8, x9, x8
     dac:      	mov	x9, #0x50               // =80
     db0:      	movk	x9, #0xc00, lsl #16
     db4:      	movk	x9, #0x20, lsl #32
     db8:      	tst	x8, x9
     dbc:      	b.eq	0xfb0 <filter_32ty_selector_val+0x350>
     dc0:      	mov	w0, #0x1                // =1
     dc4:      	ret
     dc8:      	ldr	w9, [x0, #0x8]
     dcc:      	cmp	w9, #0xd
     dd0:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     dd4:      	ldr	w10, [x0, #0x14]
     dd8:      	cmp	w8, w10
     ddc:      	b.le	0xe98 <filter_32ty_selector_val+0x238>
     de0:      	mov	w0, #0x1                // =1
     de4:      	ret
     de8:      	ldr	w9, [x0, #0x8]
     dec:      	cmp	w9, #0xd
     df0:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     df4:      	ldr	w10, [x0, #0x14]
     df8:      	cmp	w8, w10
     dfc:      	b.ge	0xeb4 <filter_32ty_selector_val+0x254>
     e00:      	mov	w0, #0x1                // =1
     e04:      	ret
     e08:      	ldr	w9, [x0, #0x8]
     e0c:      	cmp	w9, #0xd
     e10:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     e14:      	ldr	w10, [x0, #0x14]
     e18:      	tst	w8, w10
     e1c:      	b.eq	0xed0 <filter_32ty_selector_val+0x270>
     e20:      	mov	w0, #0x1                // =1
     e24:      	ret
     e28:      	ldr	w8, [x1]
     e2c:      	ldr	w9, [x0, #0x10]
     e30:      	cmp	w8, w9
     e34:      	b.ls	0xe58 <filter_32ty_selector_val+0x1f8>
     e38:      	mov	w0, #0x1                // =1
     e3c:      	ret
     e40:      	ldr	w8, [x1]
     e44:      	ldr	w9, [x0, #0x10]
     e48:      	cmp	w8, w9
     e4c:      	b.hs	0xe78 <filter_32ty_selector_val+0x218>
     e50:      	mov	w0, #0x1                // =1
     e54:      	ret
     e58:      	ldr	w9, [x0, #0x8]
     e5c:      	cmp	w9, #0xd
     e60:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     e64:      	ldr	w10, [x0, #0x14]
     e68:      	cmp	w8, w10
     e6c:      	b.ls	0xeec <filter_32ty_selector_val+0x28c>
     e70:      	mov	w0, #0x1                // =1
     e74:      	ret
     e78:      	ldr	w9, [x0, #0x8]
     e7c:      	cmp	w9, #0xd
     e80:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     e84:      	ldr	w10, [x0, #0x14]
     e88:      	cmp	w8, w10
     e8c:      	b.hs	0xf08 <filter_32ty_selector_val+0x2a8>
     e90:      	mov	w0, #0x1                // =1
     e94:      	ret
     e98:      	cmp	w9, #0x11
     e9c:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     ea0:      	ldr	w10, [x0, #0x18]
     ea4:      	cmp	w8, w10
     ea8:      	b.le	0xf24 <filter_32ty_selector_val+0x2c4>
     eac:      	mov	w0, #0x1                // =1
     eb0:      	ret
     eb4:      	cmp	w9, #0x11
     eb8:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     ebc:      	ldr	w10, [x0, #0x18]
     ec0:      	cmp	w8, w10
     ec4:      	b.ge	0xf40 <filter_32ty_selector_val+0x2e0>
     ec8:      	mov	w0, #0x1                // =1
     ecc:      	ret
     ed0:      	cmp	w9, #0x11
     ed4:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     ed8:      	ldr	w10, [x0, #0x18]
     edc:      	tst	w8, w10
     ee0:      	b.eq	0xf5c <filter_32ty_selector_val+0x2fc>
     ee4:      	mov	w0, #0x1                // =1
     ee8:      	ret
     eec:      	cmp	w9, #0x11
     ef0:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     ef4:      	ldr	w10, [x0, #0x18]
     ef8:      	cmp	w8, w10
     efc:      	b.ls	0xf78 <filter_32ty_selector_val+0x318>
     f00:      	mov	w0, #0x1                // =1
     f04:      	ret
     f08:      	cmp	w9, #0x11
     f0c:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     f10:      	ldr	w10, [x0, #0x18]
     f14:      	cmp	w8, w10
     f18:      	b.hs	0xf94 <filter_32ty_selector_val+0x334>
     f1c:      	mov	w0, #0x1                // =1
     f20:      	ret
     f24:      	cmp	w9, #0x15
     f28:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     f2c:      	ldr	w9, [x0, #0x1c]
     f30:      	cmp	w8, w9
     f34:      	b.le	0xfb0 <filter_32ty_selector_val+0x350>
     f38:      	mov	w0, #0x1                // =1
     f3c:      	ret
     f40:      	cmp	w9, #0x15
     f44:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     f48:      	ldr	w9, [x0, #0x1c]
     f4c:      	cmp	w8, w9
     f50:      	b.ge	0xfb0 <filter_32ty_selector_val+0x350>
     f54:      	mov	w0, #0x1                // =1
     f58:      	ret
     f5c:      	cmp	w9, #0x15
     f60:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     f64:      	ldr	w9, [x0, #0x1c]
     f68:      	tst	w8, w9
     f6c:      	b.eq	0xfb0 <filter_32ty_selector_val+0x350>
     f70:      	mov	w0, #0x1                // =1
     f74:      	ret
     f78:      	cmp	w9, #0x15
     f7c:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     f80:      	ldr	w9, [x0, #0x1c]
     f84:      	cmp	w8, w9
     f88:      	b.ls	0xfb0 <filter_32ty_selector_val+0x350>
     f8c:      	mov	w0, #0x1                // =1
     f90:      	ret
     f94:      	cmp	w9, #0x15
     f98:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     f9c:      	ldr	w9, [x0, #0x1c]
     fa0:      	cmp	w8, w9
     fa4:      	b.hs	0xfb0 <filter_32ty_selector_val+0x350>
     fa8:      	mov	w0, #0x1                // =1
     fac:      	ret
     fb0:      	mov	x0, xzr
     fb4:      	ret
     fb8:      	nop
     fbc:      	nop

0000000000000fc0 <filter_32ty_map>:
     fc0:      	sub	sp, sp, #0x30
     fc4:      	str	x30, [sp, #0x10]
     fc8:      	stp	x20, x19, [sp, #0x20]
     fcc:      	ldrb	w8, [x0, #0x10]
     fd0:      	mov	x19, x0
     fd4:      	adrp	x0, 0x0 <extract_arg_depth>
     fd8:      	add	x9, sp, #0x1c
     fdc:      	str	w8, [sp, #0x1c]
     fe0:      	mov	w8, #0x1                // =1
     fe4:      	mov	x20, x1
     fe8:      	add	x1, sp, #0x1c
     fec:      	ldr	x0, [x0]
     ff0:      	blr	x8
     ff4:      	cbz	x0, 0x1068 <filter_32ty_map+0xa8>
     ff8:      	ldr	w8, [x20]
     ffc:      	mov	w9, #0x1                // =1
    1000:      	add	x1, sp, #0x8
    1004:      	mov	w20, #0x1               // =1
    1008:      	str	x8, [sp, #0x8]
    100c:      	add	x8, sp, #0x8
    1010:      	blr	x9
    1014:      	ldr	w9, [x19, #0x4]
    1018:      	mov	w8, wzr
    101c:      	cmp	w9, #0x1d
    1020:      	b.hi	0x1064 <filter_32ty_map+0xa4>
    1024:      	mov	w11, #0x8400            // =33792
    1028:      	lsl	w10, w20, w9
    102c:      	movk	w11, #0x3003, lsl #16
    1030:      	tst	w10, w11
    1034:      	b.eq	0x1044 <filter_32ty_map+0x84>
    1038:      	cmp	x0, #0x0
    103c:      	cset	w8, ne
    1040:      	b	0x1064 <filter_32ty_map+0xa4>
    1044:      	mov	w10, #0x1               // =1
    1048:      	lsl	w9, w10, w9
    104c:      	mov	w10, #0x800             // =2048
    1050:      	movk	w10, #0xc, lsl #16
    1054:      	tst	w9, w10
    1058:      	b.eq	0x1064 <filter_32ty_map+0xa4>
    105c:      	cmp	x0, #0x0
    1060:      	cset	w8, eq
    1064:      	mov	w0, w8
    1068:      	ldp	x20, x19, [sp, #0x20]
    106c:      	ldr	x30, [sp, #0x10]
    1070:      	add	sp, sp, #0x30
    1074:      	ret
    1078:      	nop
    107c:      	nop

0000000000001080 <filter_32ty_range>:
    1080:      	ldr	w9, [x0, #0xc]
    1084:      	ldr	w8, [x0, #0x4]
    1088:      	mov	w10, #0x1               // =1
    108c:      	cmp	w9, #0xc
    1090:      	lsl	w9, w10, w9
    1094:      	mov	w10, #0x1402            // =5122
    1098:      	and	w9, w9, w10
    109c:      	ccmp	w9, #0x0, #0x4, ls
    10a0:      	b.eq	0x11a0 <filter_32ty_range+0x120>
    10a4:      	ldr	w10, [x1]
    10a8:      	cmp	w8, #0x1f
    10ac:      	b.ne	0x1134 <filter_32ty_range+0xb4>
    10b0:      	ldr	w9, [x0, #0x10]
    10b4:      	cmp	w9, w10
    10b8:      	b.gt	0x10c8 <filter_32ty_range+0x48>
    10bc:      	ldr	w9, [x0, #0x14]
    10c0:      	cmp	w10, w9
    10c4:      	b.le	0x11c4 <filter_32ty_range+0x144>
    10c8:      	ldr	w9, [x0, #0x8]
    10cc:      	cmp	w9, #0x11
    10d0:      	b.lo	0x12b0 <filter_32ty_range+0x230>
    10d4:      	ldr	w11, [x0, #0x18]
    10d8:      	cmp	w11, w10
    10dc:      	b.gt	0x10ec <filter_32ty_range+0x6c>
    10e0:      	ldr	w11, [x0, #0x1c]
    10e4:      	cmp	w10, w11
    10e8:      	b.le	0x11c4 <filter_32ty_range+0x144>
    10ec:      	cmp	w9, #0x19
    10f0:      	b.lo	0x12b0 <filter_32ty_range+0x230>
    10f4:      	ldr	w11, [x0, #0x20]
    10f8:      	cmp	w11, w10
    10fc:      	b.gt	0x110c <filter_32ty_range+0x8c>
    1100:      	ldr	w11, [x0, #0x24]
    1104:      	cmp	w10, w11
    1108:      	b.le	0x11c4 <filter_32ty_range+0x144>
    110c:      	cmp	w9, #0x21
    1110:      	b.lo	0x12b0 <filter_32ty_range+0x230>
    1114:      	ldr	w11, [x0, #0x28]
    1118:      	mov	w9, wzr
    111c:      	cmp	w11, w10
    1120:      	b.gt	0x12a0 <filter_32ty_range+0x220>
    1124:      	ldr	w11, [x0, #0x2c]
    1128:      	cmp	w10, w11
    112c:      	b.le	0x11c4 <filter_32ty_range+0x144>
    1130:      	b	0x12a0 <filter_32ty_range+0x220>
    1134:      	ldp	w9, w12, [x0, #0x10]
    1138:      	ldr	w11, [x0, #0x8]
    113c:      	cmp	w9, w10
    1140:      	ccmp	w10, w12, #0x0, le
    1144:      	cset	w9, le
    1148:      	cmp	w11, #0x11
    114c:      	b.lo	0x12a0 <filter_32ty_range+0x220>
    1150:      	ldp	w12, w13, [x0, #0x18]
    1154:      	cmp	w12, w10
    1158:      	ccmp	w10, w13, #0x0, le
    115c:      	csinc	w9, w9, wzr, gt
    1160:      	cmp	w11, #0x19
    1164:      	b.lo	0x12a0 <filter_32ty_range+0x220>
    1168:      	ldp	w12, w13, [x0, #0x20]
    116c:      	cmp	w12, w10
    1170:      	ccmp	w10, w13, #0x0, le
    1174:      	csinc	w9, w9, wzr, gt
    1178:      	cmp	w11, #0x21
    117c:      	b.lo	0x12a0 <filter_32ty_range+0x220>
    1180:      	ldp	w11, w12, [x0, #0x28]
    1184:      	cmp	w11, w10
    1188:      	ccmp	w10, w12, #0x0, le
    118c:      	csinc	w9, w9, wzr, gt
    1190:      	cmp	w8, #0x20
    1194:      	eor	w8, w9, #0x1
    1198:      	csel	w0, wzr, w8, ne
    119c:      	ret
    11a0:      	ldr	w10, [x1]
    11a4:      	cmp	w8, #0x1f
    11a8:      	b.ne	0x11cc <filter_32ty_range+0x14c>
    11ac:      	ldr	w9, [x0, #0x10]
    11b0:      	cmp	w9, w10
    11b4:      	b.hi	0x1238 <filter_32ty_range+0x1b8>
    11b8:      	ldr	w9, [x0, #0x14]
    11bc:      	cmp	w10, w9
    11c0:      	b.hi	0x1238 <filter_32ty_range+0x1b8>
    11c4:      	mov	w0, #0x1                // =1
    11c8:      	ret
    11cc:      	ldp	w9, w12, [x0, #0x10]
    11d0:      	ldr	w11, [x0, #0x8]
    11d4:      	cmp	w9, w10
    11d8:      	ccmp	w10, w12, #0x2, ls
    11dc:      	cset	w9, ls
    11e0:      	cmp	w11, #0x11
    11e4:      	b.lo	0x12a0 <filter_32ty_range+0x220>
    11e8:      	ldp	w12, w13, [x0, #0x18]
    11ec:      	cmp	w12, w10
    11f0:      	ccmp	w10, w13, #0x2, ls
    11f4:      	csinc	w9, w9, wzr, hi
    11f8:      	cmp	w11, #0x19
    11fc:      	b.lo	0x12a0 <filter_32ty_range+0x220>
    1200:      	ldp	w12, w13, [x0, #0x20]
    1204:      	cmp	w12, w10
    1208:      	ccmp	w10, w13, #0x2, ls
    120c:      	csinc	w9, w9, wzr, hi
    1210:      	cmp	w11, #0x21
    1214:      	b.lo	0x12a0 <filter_32ty_range+0x220>
    1218:      	ldp	w11, w12, [x0, #0x28]
    121c:      	cmp	w11, w10
    1220:      	ccmp	w10, w12, #0x2, ls
    1224:      	csinc	w9, w9, wzr, hi
    1228:      	cmp	w8, #0x20
    122c:      	eor	w8, w9, #0x1
    1230:      	csel	w0, wzr, w8, ne
    1234:      	ret
    1238:      	ldr	w9, [x0, #0x8]
    123c:      	cmp	w9, #0x11
    1240:      	b.lo	0x12b0 <filter_32ty_range+0x230>
    1244:      	ldr	w11, [x0, #0x18]
    1248:      	cmp	w11, w10
    124c:      	b.hi	0x125c <filter_32ty_range+0x1dc>
    1250:      	ldr	w11, [x0, #0x1c]
    1254:      	cmp	w10, w11
    1258:      	b.ls	0x11c4 <filter_32ty_range+0x144>
    125c:      	cmp	w9, #0x19
    1260:      	b.lo	0x12b0 <filter_32ty_range+0x230>
    1264:      	ldr	w11, [x0, #0x20]
    1268:      	cmp	w11, w10
    126c:      	b.hi	0x127c <filter_32ty_range+0x1fc>
    1270:      	ldr	w11, [x0, #0x24]
    1274:      	cmp	w10, w11
    1278:      	b.ls	0x11c4 <filter_32ty_range+0x144>
    127c:      	cmp	w9, #0x21
    1280:      	b.lo	0x12b0 <filter_32ty_range+0x230>
    1284:      	ldr	w11, [x0, #0x28]
    1288:      	mov	w9, wzr
    128c:      	cmp	w11, w10
    1290:      	b.hi	0x12a0 <filter_32ty_range+0x220>
    1294:      	ldr	w11, [x0, #0x2c]
    1298:      	cmp	w10, w11
    129c:      	b.ls	0x11c4 <filter_32ty_range+0x144>
    12a0:      	cmp	w8, #0x20
    12a4:      	eor	w8, w9, #0x1
    12a8:      	csel	w0, wzr, w8, ne
    12ac:      	ret
    12b0:      	mov	w9, wzr
    12b4:      	cmp	w8, #0x20
    12b8:      	eor	w8, w9, #0x1
    12bc:      	csel	w0, wzr, w8, ne
    12c0:      	ret
    12c4:      	nop
    12c8:      	nop
    12cc:      	nop

00000000000012d0 <filter_16ty_selector_val>:
    12d0:      	ldr	w8, [x0, #0x4]
    12d4:      	cmp	w8, #0x25
    12d8:      	b.hi	0x134c <filter_16ty_selector_val+0x7c>
    12dc:      	mov	x10, #0x40              // =64
    12e0:      	mov	w9, #0x1                // =1
    12e4:      	movk	x10, #0xc00, lsl #16
    12e8:      	lsl	x9, x9, x8
    12ec:      	movk	x10, #0x20, lsl #32
    12f0:      	tst	x9, x10
    12f4:      	b.eq	0x1300 <filter_16ty_selector_val+0x30>
    12f8:      	mov	w0, #0x1                // =1
    12fc:      	ret
    1300:      	mov	w9, #0x1                // =1
    1304:      	lsl	x9, x9, x8
    1308:      	tst	x9, #0x18
    130c:      	b.eq	0x132c <filter_16ty_selector_val+0x5c>
    1310:      	ldrh	w9, [x1]
    1314:      	ldr	w10, [x0, #0x10]
    1318:      	cmp	w10, w9
    131c:      	b.ne	0x13cc <filter_16ty_selector_val+0xfc>
    1320:      	cmp	w8, #0x3
    1324:      	cset	w0, eq
    1328:      	ret
    132c:      	cmp	x8, #0xc
    1330:      	b.ne	0x134c <filter_16ty_selector_val+0x7c>
    1334:      	ldrh	w8, [x1]
    1338:      	ldr	w9, [x0, #0x10]
    133c:      	tst	w9, w8
    1340:      	b.eq	0x1478 <filter_16ty_selector_val+0x1a8>
    1344:      	mov	w0, #0x1                // =1
    1348:      	ret
    134c:      	cmp	w8, #0x1
    1350:      	b.eq	0x1394 <filter_16ty_selector_val+0xc4>
    1354:      	cmp	w8, #0x2
    1358:      	b.ne	0x1620 <filter_16ty_selector_val+0x350>
    135c:      	ldr	w8, [x0, #0xc]
    1360:      	cmp	w8, #0xc
    1364:      	b.hi	0x14b0 <filter_16ty_selector_val+0x1e0>
    1368:      	mov	w9, #0x1                // =1
    136c:      	lsl	w8, w9, w8
    1370:      	mov	w9, #0x1402             // =5122
    1374:      	tst	w8, w9
    1378:      	b.eq	0x14b0 <filter_16ty_selector_val+0x1e0>
    137c:      	ldrsh	w8, [x1]
    1380:      	ldr	w9, [x0, #0x10]
    1384:      	cmp	w9, w8
    1388:      	b.le	0x1458 <filter_16ty_selector_val+0x188>
    138c:      	mov	w0, #0x1                // =1
    1390:      	ret
    1394:      	ldr	w8, [x0, #0xc]
    1398:      	cmp	w8, #0xc
    139c:      	b.hi	0x1498 <filter_16ty_selector_val+0x1c8>
    13a0:      	mov	w9, #0x1                // =1
    13a4:      	lsl	w8, w9, w8
    13a8:      	mov	w9, #0x1402             // =5122
    13ac:      	tst	w8, w9
    13b0:      	b.eq	0x1498 <filter_16ty_selector_val+0x1c8>
    13b4:      	ldrsh	w8, [x1]
    13b8:      	ldr	w9, [x0, #0x10]
    13bc:      	cmp	w9, w8
    13c0:      	b.ge	0x1438 <filter_16ty_selector_val+0x168>
    13c4:      	mov	w0, #0x1                // =1
    13c8:      	ret
    13cc:      	ldr	w10, [x0, #0x8]
    13d0:      	cmp	w10, #0xd
    13d4:      	b.lo	0x140c <filter_16ty_selector_val+0x13c>
    13d8:      	ldr	w11, [x0, #0x14]
    13dc:      	cmp	w11, w9
    13e0:      	b.eq	0x1320 <filter_16ty_selector_val+0x50>
    13e4:      	cmp	w10, #0x11
    13e8:      	b.lo	0x140c <filter_16ty_selector_val+0x13c>
    13ec:      	ldr	w11, [x0, #0x18]
    13f0:      	cmp	w11, w9
    13f4:      	b.eq	0x1320 <filter_16ty_selector_val+0x50>
    13f8:      	cmp	w10, #0x15
    13fc:      	b.lo	0x140c <filter_16ty_selector_val+0x13c>
    1400:      	ldr	w10, [x0, #0x1c]
    1404:      	cmp	w10, w9
    1408:      	b.eq	0x1320 <filter_16ty_selector_val+0x50>
    140c:      	cmp	w8, #0x25
    1410:      	b.hi	0x1620 <filter_16ty_selector_val+0x350>
    1414:      	mov	w9, #0x1                // =1
    1418:      	lsl	x8, x9, x8
    141c:      	mov	x9, #0x50               // =80
    1420:      	movk	x9, #0xc00, lsl #16
    1424:      	movk	x9, #0x20, lsl #32
    1428:      	tst	x8, x9
    142c:      	b.eq	0x1620 <filter_16ty_selector_val+0x350>
    1430:      	mov	w0, #0x1                // =1
    1434:      	ret
    1438:      	ldr	w9, [x0, #0x8]
    143c:      	cmp	w9, #0xd
    1440:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1444:      	ldr	w10, [x0, #0x14]
    1448:      	cmp	w10, w8
    144c:      	b.ge	0x1508 <filter_16ty_selector_val+0x238>
    1450:      	mov	w0, #0x1                // =1
    1454:      	ret
    1458:      	ldr	w9, [x0, #0x8]
    145c:      	cmp	w9, #0xd
    1460:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1464:      	ldr	w10, [x0, #0x14]
    1468:      	cmp	w10, w8
    146c:      	b.le	0x1524 <filter_16ty_selector_val+0x254>
    1470:      	mov	w0, #0x1                // =1
    1474:      	ret
    1478:      	ldr	w9, [x0, #0x8]
    147c:      	cmp	w9, #0xd
    1480:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1484:      	ldr	w10, [x0, #0x14]
    1488:      	tst	w10, w8
    148c:      	b.eq	0x1540 <filter_16ty_selector_val+0x270>
    1490:      	mov	w0, #0x1                // =1
    1494:      	ret
    1498:      	ldrh	w8, [x1]
    149c:      	ldr	w9, [x0, #0x10]
    14a0:      	cmp	w9, w8
    14a4:      	b.hs	0x14c8 <filter_16ty_selector_val+0x1f8>
    14a8:      	mov	w0, #0x1                // =1
    14ac:      	ret
    14b0:      	ldrh	w8, [x1]
    14b4:      	ldr	w9, [x0, #0x10]
    14b8:      	cmp	w9, w8
    14bc:      	b.ls	0x14e8 <filter_16ty_selector_val+0x218>
    14c0:      	mov	w0, #0x1                // =1
    14c4:      	ret
    14c8:      	ldr	w9, [x0, #0x8]
    14cc:      	cmp	w9, #0xd
    14d0:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    14d4:      	ldr	w10, [x0, #0x14]
    14d8:      	cmp	w10, w8
    14dc:      	b.hs	0x155c <filter_16ty_selector_val+0x28c>
    14e0:      	mov	w0, #0x1                // =1
    14e4:      	ret
    14e8:      	ldr	w9, [x0, #0x8]
    14ec:      	cmp	w9, #0xd
    14f0:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    14f4:      	ldr	w10, [x0, #0x14]
    14f8:      	cmp	w10, w8
    14fc:      	b.ls	0x1578 <filter_16ty_selector_val+0x2a8>
    1500:      	mov	w0, #0x1                // =1
    1504:      	ret
    1508:      	cmp	w9, #0x11
    150c:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1510:      	ldr	w10, [x0, #0x18]
    1514:      	cmp	w10, w8
    1518:      	b.ge	0x1594 <filter_16ty_selector_val+0x2c4>
    151c:      	mov	w0, #0x1                // =1
    1520:      	ret
    1524:      	cmp	w9, #0x11
    1528:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    152c:      	ldr	w10, [x0, #0x18]
    1530:      	cmp	w10, w8
    1534:      	b.le	0x15b0 <filter_16ty_selector_val+0x2e0>
    1538:      	mov	w0, #0x1                // =1
    153c:      	ret
    1540:      	cmp	w9, #0x11
    1544:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1548:      	ldr	w10, [x0, #0x18]
    154c:      	tst	w10, w8
    1550:      	b.eq	0x15cc <filter_16ty_selector_val+0x2fc>
    1554:      	mov	w0, #0x1                // =1
    1558:      	ret
    155c:      	cmp	w9, #0x11
    1560:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1564:      	ldr	w10, [x0, #0x18]
    1568:      	cmp	w10, w8
    156c:      	b.hs	0x15e8 <filter_16ty_selector_val+0x318>
    1570:      	mov	w0, #0x1                // =1
    1574:      	ret
    1578:      	cmp	w9, #0x11
    157c:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1580:      	ldr	w10, [x0, #0x18]
    1584:      	cmp	w10, w8
    1588:      	b.ls	0x1604 <filter_16ty_selector_val+0x334>
    158c:      	mov	w0, #0x1                // =1
    1590:      	ret
    1594:      	cmp	w9, #0x15
    1598:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    159c:      	ldr	w9, [x0, #0x1c]
    15a0:      	cmp	w9, w8
    15a4:      	b.ge	0x1620 <filter_16ty_selector_val+0x350>
    15a8:      	mov	w0, #0x1                // =1
    15ac:      	ret
    15b0:      	cmp	w9, #0x15
    15b4:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    15b8:      	ldr	w9, [x0, #0x1c]
    15bc:      	cmp	w9, w8
    15c0:      	b.le	0x1620 <filter_16ty_selector_val+0x350>
    15c4:      	mov	w0, #0x1                // =1
    15c8:      	ret
    15cc:      	cmp	w9, #0x15
    15d0:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    15d4:      	ldr	w9, [x0, #0x1c]
    15d8:      	tst	w9, w8
    15dc:      	b.eq	0x1620 <filter_16ty_selector_val+0x350>
    15e0:      	mov	w0, #0x1                // =1
    15e4:      	ret
    15e8:      	cmp	w9, #0x15
    15ec:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    15f0:      	ldr	w9, [x0, #0x1c]
    15f4:      	cmp	w9, w8
    15f8:      	b.hs	0x1620 <filter_16ty_selector_val+0x350>
    15fc:      	mov	w0, #0x1                // =1
    1600:      	ret
    1604:      	cmp	w9, #0x15
    1608:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    160c:      	ldr	w9, [x0, #0x1c]
    1610:      	cmp	w9, w8
    1614:      	b.ls	0x1620 <filter_16ty_selector_val+0x350>
    1618:      	mov	w0, #0x1                // =1
    161c:      	ret
    1620:      	mov	x0, xzr
    1624:      	ret
    1628:      	nop
    162c:      	nop

0000000000001630 <filter_16ty_map>:
    1630:      	sub	sp, sp, #0x30
    1634:      	str	x30, [sp, #0x10]
    1638:      	stp	x20, x19, [sp, #0x20]
    163c:      	ldrb	w8, [x0, #0x10]
    1640:      	mov	x19, x0
    1644:      	adrp	x0, 0x1000 <filter_32ty_map+0x40>
    1648:      	add	x9, sp, #0x1c
    164c:      	str	w8, [sp, #0x1c]
    1650:      	mov	w8, #0x1                // =1
    1654:      	mov	x20, x1
    1658:      	add	x1, sp, #0x1c
    165c:      	ldr	x0, [x0]
    1660:      	blr	x8
    1664:      	cbz	x0, 0x16d8 <filter_16ty_map+0xa8>
    1668:      	ldrh	w8, [x20]
    166c:      	mov	w9, #0x1                // =1
    1670:      	add	x1, sp, #0x8
    1674:      	mov	w20, #0x1               // =1
    1678:      	str	x8, [sp, #0x8]
    167c:      	add	x8, sp, #0x8
    1680:      	blr	x9
    1684:      	ldr	w9, [x19, #0x4]
    1688:      	mov	w8, wzr
    168c:      	cmp	w9, #0x1d
    1690:      	b.hi	0x16d4 <filter_16ty_map+0xa4>
    1694:      	mov	w11, #0x8400            // =33792
    1698:      	lsl	w10, w20, w9
    169c:      	movk	w11, #0x3003, lsl #16
    16a0:      	tst	w10, w11
    16a4:      	b.eq	0x16b4 <filter_16ty_map+0x84>
    16a8:      	cmp	x0, #0x0
    16ac:      	cset	w8, ne
    16b0:      	b	0x16d4 <filter_16ty_map+0xa4>
    16b4:      	mov	w10, #0x1               // =1
    16b8:      	lsl	w9, w10, w9
    16bc:      	mov	w10, #0x800             // =2048
    16c0:      	movk	w10, #0xc, lsl #16
    16c4:      	tst	w9, w10
    16c8:      	b.eq	0x16d4 <filter_16ty_map+0xa4>
    16cc:      	cmp	x0, #0x0
    16d0:      	cset	w8, eq
    16d4:      	mov	w0, w8
    16d8:      	ldp	x20, x19, [sp, #0x20]
    16dc:      	ldr	x30, [sp, #0x10]
    16e0:      	add	sp, sp, #0x30
    16e4:      	ret
    16e8:      	nop
    16ec:      	nop

00000000000016f0 <filter_16ty_range>:
    16f0:      	ldr	w9, [x0, #0xc]
    16f4:      	ldr	w8, [x0, #0x4]
    16f8:      	mov	w10, #0x1               // =1
    16fc:      	cmp	w9, #0xc
    1700:      	lsl	w9, w10, w9
    1704:      	mov	w10, #0x1402            // =5122
    1708:      	and	w9, w9, w10
    170c:      	ccmp	w9, #0x0, #0x4, ls
    1710:      	b.eq	0x1810 <filter_16ty_range+0x120>
    1714:      	ldrsh	w10, [x1]
    1718:      	cmp	w8, #0x1f
    171c:      	b.ne	0x17a4 <filter_16ty_range+0xb4>
    1720:      	ldr	w9, [x0, #0x10]
    1724:      	cmp	w9, w10
    1728:      	b.gt	0x1738 <filter_16ty_range+0x48>
    172c:      	ldr	w9, [x0, #0x14]
    1730:      	cmp	w9, w10
    1734:      	b.ge	0x1834 <filter_16ty_range+0x144>
    1738:      	ldr	w9, [x0, #0x8]
    173c:      	cmp	w9, #0x11
    1740:      	b.lo	0x1920 <filter_16ty_range+0x230>
    1744:      	ldr	w11, [x0, #0x18]
    1748:      	cmp	w11, w10
    174c:      	b.gt	0x175c <filter_16ty_range+0x6c>
    1750:      	ldr	w11, [x0, #0x1c]
    1754:      	cmp	w11, w10
    1758:      	b.ge	0x1834 <filter_16ty_range+0x144>
    175c:      	cmp	w9, #0x19
    1760:      	b.lo	0x1920 <filter_16ty_range+0x230>
    1764:      	ldr	w11, [x0, #0x20]
    1768:      	cmp	w11, w10
    176c:      	b.gt	0x177c <filter_16ty_range+0x8c>
    1770:      	ldr	w11, [x0, #0x24]
    1774:      	cmp	w11, w10
    1778:      	b.ge	0x1834 <filter_16ty_range+0x144>
    177c:      	cmp	w9, #0x21
    1780:      	b.lo	0x1920 <filter_16ty_range+0x230>
    1784:      	ldr	w11, [x0, #0x28]
    1788:      	mov	w9, wzr
    178c:      	cmp	w11, w10
    1790:      	b.gt	0x1910 <filter_16ty_range+0x220>
    1794:      	ldr	w11, [x0, #0x2c]
    1798:      	cmp	w11, w10
    179c:      	b.ge	0x1834 <filter_16ty_range+0x144>
    17a0:      	b	0x1910 <filter_16ty_range+0x220>
    17a4:      	ldp	w9, w12, [x0, #0x10]
    17a8:      	ldr	w11, [x0, #0x8]
    17ac:      	cmp	w9, w10
    17b0:      	ccmp	w12, w10, #0x8, le
    17b4:      	cset	w9, ge
    17b8:      	cmp	w11, #0x11
    17bc:      	b.lo	0x1910 <filter_16ty_range+0x220>
    17c0:      	ldp	w12, w13, [x0, #0x18]
    17c4:      	cmp	w12, w10
    17c8:      	ccmp	w13, w10, #0x8, le
    17cc:      	csinc	w9, w9, wzr, lt
    17d0:      	cmp	w11, #0x19
    17d4:      	b.lo	0x1910 <filter_16ty_range+0x220>
    17d8:      	ldp	w12, w13, [x0, #0x20]
    17dc:      	cmp	w12, w10
    17e0:      	ccmp	w13, w10, #0x8, le
    17e4:      	csinc	w9, w9, wzr, lt
    17e8:      	cmp	w11, #0x21
    17ec:      	b.lo	0x1910 <filter_16ty_range+0x220>
    17f0:      	ldp	w11, w12, [x0, #0x28]
    17f4:      	cmp	w11, w10
    17f8:      	ccmp	w12, w10, #0x8, le
    17fc:      	csinc	w9, w9, wzr, lt
    1800:      	cmp	w8, #0x20
    1804:      	eor	w8, w9, #0x1
    1808:      	csel	w0, wzr, w8, ne
    180c:      	ret
    1810:      	ldrh	w10, [x1]
    1814:      	cmp	w8, #0x1f
    1818:      	b.ne	0x183c <filter_16ty_range+0x14c>
    181c:      	ldr	w9, [x0, #0x10]
    1820:      	cmp	w9, w10
    1824:      	b.hi	0x18a8 <filter_16ty_range+0x1b8>
    1828:      	ldr	w9, [x0, #0x14]
    182c:      	cmp	w9, w10
    1830:      	b.lo	0x18a8 <filter_16ty_range+0x1b8>
    1834:      	mov	w0, #0x1                // =1
    1838:      	ret
    183c:      	ldp	w9, w12, [x0, #0x10]
    1840:      	ldr	w11, [x0, #0x8]
    1844:      	cmp	w9, w10
    1848:      	ccmp	w12, w10, #0x0, ls
    184c:      	cset	w9, hs
    1850:      	cmp	w11, #0x11
    1854:      	b.lo	0x1910 <filter_16ty_range+0x220>
    1858:      	ldp	w12, w13, [x0, #0x18]
    185c:      	cmp	w12, w10
    1860:      	ccmp	w13, w10, #0x0, ls
    1864:      	csinc	w9, w9, wzr, lo
    1868:      	cmp	w11, #0x19
    186c:      	b.lo	0x1910 <filter_16ty_range+0x220>
    1870:      	ldp	w12, w13, [x0, #0x20]
    1874:      	cmp	w12, w10
    1878:      	ccmp	w13, w10, #0x0, ls
    187c:      	csinc	w9, w9, wzr, lo
    1880:      	cmp	w11, #0x21
    1884:      	b.lo	0x1910 <filter_16ty_range+0x220>
    1888:      	ldp	w11, w12, [x0, #0x28]
    188c:      	cmp	w11, w10
    1890:      	ccmp	w12, w10, #0x0, ls
    1894:      	csinc	w9, w9, wzr, lo
    1898:      	cmp	w8, #0x20
    189c:      	eor	w8, w9, #0x1
    18a0:      	csel	w0, wzr, w8, ne
    18a4:      	ret
    18a8:      	ldr	w9, [x0, #0x8]
    18ac:      	cmp	w9, #0x11
    18b0:      	b.lo	0x1920 <filter_16ty_range+0x230>
    18b4:      	ldr	w11, [x0, #0x18]
    18b8:      	cmp	w11, w10
    18bc:      	b.hi	0x18cc <filter_16ty_range+0x1dc>
    18c0:      	ldr	w11, [x0, #0x1c]
    18c4:      	cmp	w11, w10
    18c8:      	b.hs	0x1834 <filter_16ty_range+0x144>
    18cc:      	cmp	w9, #0x19
    18d0:      	b.lo	0x1920 <filter_16ty_range+0x230>
    18d4:      	ldr	w11, [x0, #0x20]
    18d8:      	cmp	w11, w10
    18dc:      	b.hi	0x18ec <filter_16ty_range+0x1fc>
    18e0:      	ldr	w11, [x0, #0x24]
    18e4:      	cmp	w11, w10
    18e8:      	b.hs	0x1834 <filter_16ty_range+0x144>
    18ec:      	cmp	w9, #0x21
    18f0:      	b.lo	0x1920 <filter_16ty_range+0x230>
    18f4:      	ldr	w11, [x0, #0x28]
    18f8:      	mov	w9, wzr
    18fc:      	cmp	w11, w10
    1900:      	b.hi	0x1910 <filter_16ty_range+0x220>
    1904:      	ldr	w11, [x0, #0x2c]
    1908:      	cmp	w11, w10
    190c:      	b.hs	0x1834 <filter_16ty_range+0x144>
    1910:      	cmp	w8, #0x20
    1914:      	eor	w8, w9, #0x1
    1918:      	csel	w0, wzr, w8, ne
    191c:      	ret
    1920:      	mov	w9, wzr
    1924:      	cmp	w8, #0x20
    1928:      	eor	w8, w9, #0x1
    192c:      	csel	w0, wzr, w8, ne
    1930:      	ret
    1934:      	nop
    1938:      	nop
    193c:      	nop

0000000000001940 <filter_8ty_selector_val>:
    1940:      	ldr	w8, [x0, #0x4]
    1944:      	cmp	w8, #0x25
    1948:      	b.hi	0x19bc <filter_8ty_selector_val+0x7c>
    194c:      	mov	x10, #0x40              // =64
    1950:      	mov	w9, #0x1                // =1
    1954:      	movk	x10, #0xc00, lsl #16
    1958:      	lsl	x9, x9, x8
    195c:      	movk	x10, #0x20, lsl #32
    1960:      	tst	x9, x10
    1964:      	b.eq	0x1970 <filter_8ty_selector_val+0x30>
    1968:      	mov	w0, #0x1                // =1
    196c:      	ret
    1970:      	mov	w9, #0x1                // =1
    1974:      	lsl	x9, x9, x8
    1978:      	tst	x9, #0x18
    197c:      	b.eq	0x199c <filter_8ty_selector_val+0x5c>
    1980:      	ldrb	w9, [x1]
    1984:      	ldr	w10, [x0, #0x10]
    1988:      	cmp	w10, w9
    198c:      	b.ne	0x1a3c <filter_8ty_selector_val+0xfc>
    1990:      	cmp	w8, #0x3
    1994:      	cset	w0, eq
    1998:      	ret
    199c:      	cmp	x8, #0xc
    19a0:      	b.ne	0x19bc <filter_8ty_selector_val+0x7c>
    19a4:      	ldrb	w8, [x1]
    19a8:      	ldr	w9, [x0, #0x10]
    19ac:      	tst	w9, w8
    19b0:      	b.eq	0x1ae8 <filter_8ty_selector_val+0x1a8>
    19b4:      	mov	w0, #0x1                // =1
    19b8:      	ret
    19bc:      	cmp	w8, #0x1
    19c0:      	b.eq	0x1a04 <filter_8ty_selector_val+0xc4>
    19c4:      	cmp	w8, #0x2
    19c8:      	b.ne	0x1c90 <filter_8ty_selector_val+0x350>
    19cc:      	ldr	w8, [x0, #0xc]
    19d0:      	cmp	w8, #0xc
    19d4:      	b.hi	0x1b20 <filter_8ty_selector_val+0x1e0>
    19d8:      	mov	w9, #0x1                // =1
    19dc:      	lsl	w8, w9, w8
    19e0:      	mov	w9, #0x1402             // =5122
    19e4:      	tst	w8, w9
    19e8:      	b.eq	0x1b20 <filter_8ty_selector_val+0x1e0>
    19ec:      	ldrsb	w8, [x1]
    19f0:      	ldr	w9, [x0, #0x10]
    19f4:      	cmp	w9, w8
    19f8:      	b.le	0x1ac8 <filter_8ty_selector_val+0x188>
    19fc:      	mov	w0, #0x1                // =1
    1a00:      	ret
    1a04:      	ldr	w8, [x0, #0xc]
    1a08:      	cmp	w8, #0xc
    1a0c:      	b.hi	0x1b08 <filter_8ty_selector_val+0x1c8>
    1a10:      	mov	w9, #0x1                // =1
    1a14:      	lsl	w8, w9, w8
    1a18:      	mov	w9, #0x1402             // =5122
    1a1c:      	tst	w8, w9
    1a20:      	b.eq	0x1b08 <filter_8ty_selector_val+0x1c8>
    1a24:      	ldrsb	w8, [x1]
    1a28:      	ldr	w9, [x0, #0x10]
    1a2c:      	cmp	w9, w8
    1a30:      	b.ge	0x1aa8 <filter_8ty_selector_val+0x168>
    1a34:      	mov	w0, #0x1                // =1
    1a38:      	ret
    1a3c:      	ldr	w10, [x0, #0x8]
    1a40:      	cmp	w10, #0xd
    1a44:      	b.lo	0x1a7c <filter_8ty_selector_val+0x13c>
    1a48:      	ldr	w11, [x0, #0x14]
    1a4c:      	cmp	w11, w9
    1a50:      	b.eq	0x1990 <filter_8ty_selector_val+0x50>
    1a54:      	cmp	w10, #0x11
    1a58:      	b.lo	0x1a7c <filter_8ty_selector_val+0x13c>
    1a5c:      	ldr	w11, [x0, #0x18]
    1a60:      	cmp	w11, w9
    1a64:      	b.eq	0x1990 <filter_8ty_selector_val+0x50>
    1a68:      	cmp	w10, #0x15
    1a6c:      	b.lo	0x1a7c <filter_8ty_selector_val+0x13c>
    1a70:      	ldr	w10, [x0, #0x1c]
    1a74:      	cmp	w10, w9
    1a78:      	b.eq	0x1990 <filter_8ty_selector_val+0x50>
    1a7c:      	cmp	w8, #0x25
    1a80:      	b.hi	0x1c90 <filter_8ty_selector_val+0x350>
    1a84:      	mov	w9, #0x1                // =1
    1a88:      	lsl	x8, x9, x8
    1a8c:      	mov	x9, #0x50               // =80
    1a90:      	movk	x9, #0xc00, lsl #16
    1a94:      	movk	x9, #0x20, lsl #32
    1a98:      	tst	x8, x9
    1a9c:      	b.eq	0x1c90 <filter_8ty_selector_val+0x350>
    1aa0:      	mov	w0, #0x1                // =1
    1aa4:      	ret
    1aa8:      	ldr	w9, [x0, #0x8]
    1aac:      	cmp	w9, #0xd
    1ab0:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1ab4:      	ldr	w10, [x0, #0x14]
    1ab8:      	cmp	w10, w8
    1abc:      	b.ge	0x1b78 <filter_8ty_selector_val+0x238>
    1ac0:      	mov	w0, #0x1                // =1
    1ac4:      	ret
    1ac8:      	ldr	w9, [x0, #0x8]
    1acc:      	cmp	w9, #0xd
    1ad0:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1ad4:      	ldr	w10, [x0, #0x14]
    1ad8:      	cmp	w10, w8
    1adc:      	b.le	0x1b94 <filter_8ty_selector_val+0x254>
    1ae0:      	mov	w0, #0x1                // =1
    1ae4:      	ret
    1ae8:      	ldr	w9, [x0, #0x8]
    1aec:      	cmp	w9, #0xd
    1af0:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1af4:      	ldr	w10, [x0, #0x14]
    1af8:      	tst	w10, w8
    1afc:      	b.eq	0x1bb0 <filter_8ty_selector_val+0x270>
    1b00:      	mov	w0, #0x1                // =1
    1b04:      	ret
    1b08:      	ldrb	w8, [x1]
    1b0c:      	ldr	w9, [x0, #0x10]
    1b10:      	cmp	w9, w8
    1b14:      	b.hs	0x1b38 <filter_8ty_selector_val+0x1f8>
    1b18:      	mov	w0, #0x1                // =1
    1b1c:      	ret
    1b20:      	ldrb	w8, [x1]
    1b24:      	ldr	w9, [x0, #0x10]
    1b28:      	cmp	w9, w8
    1b2c:      	b.ls	0x1b58 <filter_8ty_selector_val+0x218>
    1b30:      	mov	w0, #0x1                // =1
    1b34:      	ret
    1b38:      	ldr	w9, [x0, #0x8]
    1b3c:      	cmp	w9, #0xd
    1b40:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1b44:      	ldr	w10, [x0, #0x14]
    1b48:      	cmp	w10, w8
    1b4c:      	b.hs	0x1bcc <filter_8ty_selector_val+0x28c>
    1b50:      	mov	w0, #0x1                // =1
    1b54:      	ret
    1b58:      	ldr	w9, [x0, #0x8]
    1b5c:      	cmp	w9, #0xd
    1b60:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1b64:      	ldr	w10, [x0, #0x14]
    1b68:      	cmp	w10, w8
    1b6c:      	b.ls	0x1be8 <filter_8ty_selector_val+0x2a8>
    1b70:      	mov	w0, #0x1                // =1
    1b74:      	ret
    1b78:      	cmp	w9, #0x11
    1b7c:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1b80:      	ldr	w10, [x0, #0x18]
    1b84:      	cmp	w10, w8
    1b88:      	b.ge	0x1c04 <filter_8ty_selector_val+0x2c4>
    1b8c:      	mov	w0, #0x1                // =1
    1b90:      	ret
    1b94:      	cmp	w9, #0x11
    1b98:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1b9c:      	ldr	w10, [x0, #0x18]
    1ba0:      	cmp	w10, w8
    1ba4:      	b.le	0x1c20 <filter_8ty_selector_val+0x2e0>
    1ba8:      	mov	w0, #0x1                // =1
    1bac:      	ret
    1bb0:      	cmp	w9, #0x11
    1bb4:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1bb8:      	ldr	w10, [x0, #0x18]
    1bbc:      	tst	w10, w8
    1bc0:      	b.eq	0x1c3c <filter_8ty_selector_val+0x2fc>
    1bc4:      	mov	w0, #0x1                // =1
    1bc8:      	ret
    1bcc:      	cmp	w9, #0x11
    1bd0:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1bd4:      	ldr	w10, [x0, #0x18]
    1bd8:      	cmp	w10, w8
    1bdc:      	b.hs	0x1c58 <filter_8ty_selector_val+0x318>
    1be0:      	mov	w0, #0x1                // =1
    1be4:      	ret
    1be8:      	cmp	w9, #0x11
    1bec:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1bf0:      	ldr	w10, [x0, #0x18]
    1bf4:      	cmp	w10, w8
    1bf8:      	b.ls	0x1c74 <filter_8ty_selector_val+0x334>
    1bfc:      	mov	w0, #0x1                // =1
    1c00:      	ret
    1c04:      	cmp	w9, #0x15
    1c08:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1c0c:      	ldr	w9, [x0, #0x1c]
    1c10:      	cmp	w9, w8
    1c14:      	b.ge	0x1c90 <filter_8ty_selector_val+0x350>
    1c18:      	mov	w0, #0x1                // =1
    1c1c:      	ret
    1c20:      	cmp	w9, #0x15
    1c24:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1c28:      	ldr	w9, [x0, #0x1c]
    1c2c:      	cmp	w9, w8
    1c30:      	b.le	0x1c90 <filter_8ty_selector_val+0x350>
    1c34:      	mov	w0, #0x1                // =1
    1c38:      	ret
    1c3c:      	cmp	w9, #0x15
    1c40:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1c44:      	ldr	w9, [x0, #0x1c]
    1c48:      	tst	w9, w8
    1c4c:      	b.eq	0x1c90 <filter_8ty_selector_val+0x350>
    1c50:      	mov	w0, #0x1                // =1
    1c54:      	ret
    1c58:      	cmp	w9, #0x15
    1c5c:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1c60:      	ldr	w9, [x0, #0x1c]
    1c64:      	cmp	w9, w8
    1c68:      	b.hs	0x1c90 <filter_8ty_selector_val+0x350>
    1c6c:      	mov	w0, #0x1                // =1
    1c70:      	ret
    1c74:      	cmp	w9, #0x15
    1c78:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1c7c:      	ldr	w9, [x0, #0x1c]
    1c80:      	cmp	w9, w8
    1c84:      	b.ls	0x1c90 <filter_8ty_selector_val+0x350>
    1c88:      	mov	w0, #0x1                // =1
    1c8c:      	ret
    1c90:      	mov	x0, xzr
    1c94:      	ret
    1c98:      	nop
    1c9c:      	nop

0000000000001ca0 <filter_8ty_map>:
    1ca0:      	sub	sp, sp, #0x30
    1ca4:      	str	x30, [sp, #0x10]
    1ca8:      	stp	x20, x19, [sp, #0x20]
    1cac:      	ldrb	w8, [x0, #0x10]
    1cb0:      	mov	x19, x0
    1cb4:      	adrp	x0, 0x1000 <filter_32ty_map+0x40>
    1cb8:      	add	x9, sp, #0x1c
    1cbc:      	str	w8, [sp, #0x1c]
    1cc0:      	mov	w8, #0x1                // =1
    1cc4:      	mov	x20, x1
    1cc8:      	add	x1, sp, #0x1c
    1ccc:      	ldr	x0, [x0]
    1cd0:      	blr	x8
    1cd4:      	cbz	x0, 0x1d48 <filter_8ty_map+0xa8>
    1cd8:      	ldrb	w8, [x20]
    1cdc:      	mov	w9, #0x1                // =1
    1ce0:      	add	x1, sp, #0x8
    1ce4:      	mov	w20, #0x1               // =1
    1ce8:      	str	x8, [sp, #0x8]
    1cec:      	add	x8, sp, #0x8
    1cf0:      	blr	x9
    1cf4:      	ldr	w9, [x19, #0x4]
    1cf8:      	mov	w8, wzr
    1cfc:      	cmp	w9, #0x1d
    1d00:      	b.hi	0x1d44 <filter_8ty_map+0xa4>
    1d04:      	mov	w11, #0x8400            // =33792
    1d08:      	lsl	w10, w20, w9
    1d0c:      	movk	w11, #0x3003, lsl #16
    1d10:      	tst	w10, w11
    1d14:      	b.eq	0x1d24 <filter_8ty_map+0x84>
    1d18:      	cmp	x0, #0x0
    1d1c:      	cset	w8, ne
    1d20:      	b	0x1d44 <filter_8ty_map+0xa4>
    1d24:      	mov	w10, #0x1               // =1
    1d28:      	lsl	w9, w10, w9
    1d2c:      	mov	w10, #0x800             // =2048
    1d30:      	movk	w10, #0xc, lsl #16
    1d34:      	tst	w9, w10
    1d38:      	b.eq	0x1d44 <filter_8ty_map+0xa4>
    1d3c:      	cmp	x0, #0x0
    1d40:      	cset	w8, eq
    1d44:      	mov	w0, w8
    1d48:      	ldp	x20, x19, [sp, #0x20]
    1d4c:      	ldr	x30, [sp, #0x10]
    1d50:      	add	sp, sp, #0x30
    1d54:      	ret
    1d58:      	nop
    1d5c:      	nop

0000000000001d60 <filter_8ty_range>:
    1d60:      	ldr	w9, [x0, #0xc]
    1d64:      	ldr	w8, [x0, #0x4]
    1d68:      	mov	w10, #0x1               // =1
    1d6c:      	cmp	w9, #0xc
    1d70:      	lsl	w9, w10, w9
    1d74:      	mov	w10, #0x1402            // =5122
    1d78:      	and	w9, w9, w10
    1d7c:      	ccmp	w9, #0x0, #0x4, ls
    1d80:      	b.eq	0x1e80 <filter_8ty_range+0x120>
    1d84:      	ldrsb	w10, [x1]
    1d88:      	cmp	w8, #0x1f
    1d8c:      	b.ne	0x1e14 <filter_8ty_range+0xb4>
    1d90:      	ldr	w9, [x0, #0x10]
    1d94:      	cmp	w9, w10
    1d98:      	b.gt	0x1da8 <filter_8ty_range+0x48>
    1d9c:      	ldr	w9, [x0, #0x14]
    1da0:      	cmp	w9, w10
    1da4:      	b.ge	0x1ea4 <filter_8ty_range+0x144>
    1da8:      	ldr	w9, [x0, #0x8]
    1dac:      	cmp	w9, #0x11
    1db0:      	b.lo	0x1f90 <filter_8ty_range+0x230>
    1db4:      	ldr	w11, [x0, #0x18]
    1db8:      	cmp	w11, w10
    1dbc:      	b.gt	0x1dcc <filter_8ty_range+0x6c>
    1dc0:      	ldr	w11, [x0, #0x1c]
    1dc4:      	cmp	w11, w10
    1dc8:      	b.ge	0x1ea4 <filter_8ty_range+0x144>
    1dcc:      	cmp	w9, #0x19
    1dd0:      	b.lo	0x1f90 <filter_8ty_range+0x230>
    1dd4:      	ldr	w11, [x0, #0x20]
    1dd8:      	cmp	w11, w10
    1ddc:      	b.gt	0x1dec <filter_8ty_range+0x8c>
    1de0:      	ldr	w11, [x0, #0x24]
    1de4:      	cmp	w11, w10
    1de8:      	b.ge	0x1ea4 <filter_8ty_range+0x144>
    1dec:      	cmp	w9, #0x21
    1df0:      	b.lo	0x1f90 <filter_8ty_range+0x230>
    1df4:      	ldr	w11, [x0, #0x28]
    1df8:      	mov	w9, wzr
    1dfc:      	cmp	w11, w10
    1e00:      	b.gt	0x1f80 <filter_8ty_range+0x220>
    1e04:      	ldr	w11, [x0, #0x2c]
    1e08:      	cmp	w11, w10
    1e0c:      	b.ge	0x1ea4 <filter_8ty_range+0x144>
    1e10:      	b	0x1f80 <filter_8ty_range+0x220>
    1e14:      	ldp	w9, w12, [x0, #0x10]
    1e18:      	ldr	w11, [x0, #0x8]
    1e1c:      	cmp	w9, w10
    1e20:      	ccmp	w12, w10, #0x8, le
    1e24:      	cset	w9, ge
    1e28:      	cmp	w11, #0x11
    1e2c:      	b.lo	0x1f80 <filter_8ty_range+0x220>
    1e30:      	ldp	w12, w13, [x0, #0x18]
    1e34:      	cmp	w12, w10
    1e38:      	ccmp	w13, w10, #0x8, le
    1e3c:      	csinc	w9, w9, wzr, lt
    1e40:      	cmp	w11, #0x19
    1e44:      	b.lo	0x1f80 <filter_8ty_range+0x220>
    1e48:      	ldp	w12, w13, [x0, #0x20]
    1e4c:      	cmp	w12, w10
    1e50:      	ccmp	w13, w10, #0x8, le
    1e54:      	csinc	w9, w9, wzr, lt
    1e58:      	cmp	w11, #0x21
    1e5c:      	b.lo	0x1f80 <filter_8ty_range+0x220>
    1e60:      	ldp	w11, w12, [x0, #0x28]
    1e64:      	cmp	w11, w10
    1e68:      	ccmp	w12, w10, #0x8, le
    1e6c:      	csinc	w9, w9, wzr, lt
    1e70:      	cmp	w8, #0x20
    1e74:      	eor	w8, w9, #0x1
    1e78:      	csel	w0, wzr, w8, ne
    1e7c:      	ret
    1e80:      	ldrb	w10, [x1]
    1e84:      	cmp	w8, #0x1f
    1e88:      	b.ne	0x1eac <filter_8ty_range+0x14c>
    1e8c:      	ldr	w9, [x0, #0x10]
    1e90:      	cmp	w9, w10
    1e94:      	b.hi	0x1f18 <filter_8ty_range+0x1b8>
    1e98:      	ldr	w9, [x0, #0x14]
    1e9c:      	cmp	w9, w10
    1ea0:      	b.lo	0x1f18 <filter_8ty_range+0x1b8>
    1ea4:      	mov	w0, #0x1                // =1
    1ea8:      	ret
    1eac:      	ldp	w9, w12, [x0, #0x10]
    1eb0:      	ldr	w11, [x0, #0x8]
    1eb4:      	cmp	w9, w10
    1eb8:      	ccmp	w12, w10, #0x0, ls
    1ebc:      	cset	w9, hs
    1ec0:      	cmp	w11, #0x11
    1ec4:      	b.lo	0x1f80 <filter_8ty_range+0x220>
    1ec8:      	ldp	w12, w13, [x0, #0x18]
    1ecc:      	cmp	w12, w10
    1ed0:      	ccmp	w13, w10, #0x0, ls
    1ed4:      	csinc	w9, w9, wzr, lo
    1ed8:      	cmp	w11, #0x19
    1edc:      	b.lo	0x1f80 <filter_8ty_range+0x220>
    1ee0:      	ldp	w12, w13, [x0, #0x20]
    1ee4:      	cmp	w12, w10
    1ee8:      	ccmp	w13, w10, #0x0, ls
    1eec:      	csinc	w9, w9, wzr, lo
    1ef0:      	cmp	w11, #0x21
    1ef4:      	b.lo	0x1f80 <filter_8ty_range+0x220>
    1ef8:      	ldp	w11, w12, [x0, #0x28]
    1efc:      	cmp	w11, w10
    1f00:      	ccmp	w12, w10, #0x0, ls
    1f04:      	csinc	w9, w9, wzr, lo
    1f08:      	cmp	w8, #0x20
    1f0c:      	eor	w8, w9, #0x1
    1f10:      	csel	w0, wzr, w8, ne
    1f14:      	ret
    1f18:      	ldr	w9, [x0, #0x8]
    1f1c:      	cmp	w9, #0x11
    1f20:      	b.lo	0x1f90 <filter_8ty_range+0x230>
    1f24:      	ldr	w11, [x0, #0x18]
    1f28:      	cmp	w11, w10
    1f2c:      	b.hi	0x1f3c <filter_8ty_range+0x1dc>
    1f30:      	ldr	w11, [x0, #0x1c]
    1f34:      	cmp	w11, w10
    1f38:      	b.hs	0x1ea4 <filter_8ty_range+0x144>
    1f3c:      	cmp	w9, #0x19
    1f40:      	b.lo	0x1f90 <filter_8ty_range+0x230>
    1f44:      	ldr	w11, [x0, #0x20]
    1f48:      	cmp	w11, w10
    1f4c:      	b.hi	0x1f5c <filter_8ty_range+0x1fc>
    1f50:      	ldr	w11, [x0, #0x24]
    1f54:      	cmp	w11, w10
    1f58:      	b.hs	0x1ea4 <filter_8ty_range+0x144>
    1f5c:      	cmp	w9, #0x21
    1f60:      	b.lo	0x1f90 <filter_8ty_range+0x230>
    1f64:      	ldr	w11, [x0, #0x28]
    1f68:      	mov	w9, wzr
    1f6c:      	cmp	w11, w10
    1f70:      	b.hi	0x1f80 <filter_8ty_range+0x220>
    1f74:      	ldr	w11, [x0, #0x2c]
    1f78:      	cmp	w11, w10
    1f7c:      	b.hs	0x1ea4 <filter_8ty_range+0x144>
    1f80:      	cmp	w8, #0x20
    1f84:      	eor	w8, w9, #0x1
    1f88:      	csel	w0, wzr, w8, ne
    1f8c:      	ret
    1f90:      	mov	w9, wzr
    1f94:      	cmp	w8, #0x20
    1f98:      	eor	w8, w9, #0x1
    1f9c:      	csel	w0, wzr, w8, ne
    1fa0:      	ret
    1fa4:      	nop
    1fa8:      	nop
    1fac:      	nop

0000000000001fb0 <filter_file_buf>:
    1fb0:      	stp	x30, x19, [sp, #-0x10]!
    1fb4:      	ldr	w2, [x1]
    1fb8:      	ldr	w8, [x0, #0x4]
    1fbc:      	mov	x19, x0
    1fc0:      	cbnz	w2, 0x1fdc <filter_file_buf+0x2c>
    1fc4:      	and	w9, w8, #0xfffffffe
    1fc8:      	cmp	w9, #0x24
    1fcc:      	b.eq	0x1fdc <filter_file_buf+0x2c>
    1fd0:      	mov	x0, xzr
    1fd4:      	ldp	x30, x19, [sp], #0x10
    1fd8:      	ret
    1fdc:      	cmp	w8, #0x25
    1fe0:      	b.hi	0x203c <filter_file_buf+0x8c>
    1fe4:      	mov	w9, #0x1                // =1
    1fe8:      	mov	w10, #0x100             // =256
    1fec:      	lsl	x9, x9, x8
    1ff0:      	movk	w10, #0x400, lsl #16
    1ff4:      	tst	x9, x10
    1ff8:      	b.ne	0x2080 <filter_file_buf+0xd0>
    1ffc:      	mov	w9, #0x1                // =1
    2000:      	mov	w10, #0x200             // =512
    2004:      	lsl	x9, x9, x8
    2008:      	movk	w10, #0x800, lsl #16
    200c:      	tst	x9, x10
    2010:      	b.ne	0x2064 <filter_file_buf+0xb4>
    2014:      	mov	w9, #0x1                // =1
    2018:      	lsl	x9, x9, x8
    201c:      	tst	x9, #0x3000000000
    2020:      	b.eq	0x203c <filter_file_buf+0x8c>
    2024:      	mov	x0, x19
    2028:      	bl	0x2c90 <filter_file_type>
    202c:      	ldr	w8, [x19, #0x4]
    2030:      	cmp	w8, #0x25
    2034:      	b.ls	0x20a8 <filter_file_buf+0xf8>
    2038:      	b	0x20cc <filter_file_buf+0x11c>
    203c:      	sub	w9, w8, #0x3
    2040:      	cmp	w9, #0x2
    2044:      	b.hs	0x209c <filter_file_buf+0xec>
    2048:      	add	x1, x1, #0x4
    204c:      	mov	x0, x19
    2050:      	bl	0x26c0 <filter_char_buf_equal>
    2054:      	ldr	w8, [x19, #0x4]
    2058:      	cmp	w8, #0x25
    205c:      	b.ls	0x20a8 <filter_file_buf+0xf8>
    2060:      	b	0x20cc <filter_file_buf+0x11c>
    2064:      	ldr	w0, [x19, #0x10]
    2068:      	add	x1, x1, #0x4
    206c:      	bl	0x2bb0 <filter_char_buf_postfix>
    2070:      	ldr	w8, [x19, #0x4]
    2074:      	cmp	w8, #0x25
    2078:      	b.ls	0x20a8 <filter_file_buf+0xf8>
    207c:      	b	0x20cc <filter_file_buf+0x11c>
    2080:      	ldr	w0, [x19, #0x10]
    2084:      	add	x1, x1, #0x4
    2088:      	bl	0x2af0 <filter_char_buf_prefix>
    208c:      	ldr	w8, [x19, #0x4]
    2090:      	cmp	w8, #0x25
    2094:      	b.ls	0x20a8 <filter_file_buf+0xf8>
    2098:      	b	0x20cc <filter_file_buf+0x11c>
    209c:      	mov	x0, xzr
    20a0:      	cmp	w8, #0x25
    20a4:      	b.hi	0x20cc <filter_file_buf+0x11c>
    20a8:      	mov	w8, w8
    20ac:      	mov	w9, #0x1                // =1
    20b0:      	lsl	x8, x9, x8
    20b4:      	mov	x9, #0x50               // =80
    20b8:      	movk	x9, #0xc00, lsl #16
    20bc:      	movk	x9, #0x20, lsl #32
    20c0:      	tst	x8, x9
    20c4:      	b.eq	0x20cc <filter_file_buf+0x11c>
    20c8:      	eor	x0, x0, #0x1
    20cc:      	ldp	x30, x19, [sp], #0x10
    20d0:      	ret
    20d4:      	nop
    20d8:      	nop
    20dc:      	nop

00000000000020e0 <filter_char_buf>:
    20e0:      	stp	x30, x19, [sp, #-0x10]!
    20e4:      	mov	w8, w2
    20e8:      	mov	x19, x0
    20ec:      	add	x9, x1, w2, sxtw
    20f0:      	ldur	w2, [x9, #-0x4]
    20f4:      	add	x1, x1, w8, uxtw
    20f8:      	ldr	w8, [x0, #0x4]
    20fc:      	mov	x0, xzr
    2100:      	cmp	w8, #0x19
    2104:      	b.gt	0x2128 <filter_char_buf+0x48>
    2108:      	sub	w9, w8, #0x3
    210c:      	cmp	w9, #0x2
    2110:      	b.lo	0x2174 <filter_char_buf+0x94>
    2114:      	cmp	w8, #0x8
    2118:      	b.eq	0x2168 <filter_char_buf+0x88>
    211c:      	cmp	w8, #0x9
    2120:      	b.eq	0x2140 <filter_char_buf+0x60>
    2124:      	b	0x2190 <filter_char_buf+0xb0>
    2128:      	cmp	w8, #0x20
    212c:      	b.gt	0x214c <filter_char_buf+0x6c>
    2130:      	cmp	w8, #0x1a
    2134:      	b.eq	0x2168 <filter_char_buf+0x88>
    2138:      	cmp	w8, #0x1b
    213c:      	b.ne	0x2190 <filter_char_buf+0xb0>
    2140:      	ldr	w0, [x19, #0x10]
    2144:      	bl	0x2bb0 <filter_char_buf_postfix>
    2148:      	b	0x218c <filter_char_buf+0xac>
    214c:      	cmp	w8, #0x21
    2150:      	b.eq	0x2180 <filter_char_buf+0xa0>
    2154:      	cmp	w8, #0x22
    2158:      	b.ne	0x2190 <filter_char_buf+0xb0>
    215c:      	mov	x0, x19
    2160:      	mov	w3, #0x1                // =1
    2164:      	b	0x2188 <filter_char_buf+0xa8>
    2168:      	ldr	w0, [x19, #0x10]
    216c:      	bl	0x2af0 <filter_char_buf_prefix>
    2170:      	b	0x218c <filter_char_buf+0xac>
    2174:      	mov	x0, x19
    2178:      	bl	0x26c0 <filter_char_buf_equal>
    217c:      	b	0x218c <filter_char_buf+0xac>
    2180:      	mov	x0, x19
    2184:      	mov	w3, wzr
    2188:      	bl	0x2d90 <filter_char_substring>
    218c:      	ldr	w8, [x19, #0x4]
    2190:      	cmp	w8, #0x25
    2194:      	b.hi	0x21c0 <filter_char_buf+0xe0>
    2198:      	mov	w8, w8
    219c:      	mov	w9, #0x1                // =1
    21a0:      	lsl	x8, x9, x8
    21a4:      	mov	x9, #0x50               // =80
    21a8:      	movk	x9, #0xc00, lsl #16
    21ac:      	movk	x9, #0x20, lsl #32
    21b0:      	tst	x8, x9
    21b4:      	b.eq	0x21c0 <filter_char_buf+0xe0>
    21b8:      	cmp	x0, #0x0
    21bc:      	cset	w0, eq
    21c0:      	ldp	x30, x19, [sp], #0x10
    21c4:      	ret
    21c8:      	nop
    21cc:      	nop

00000000000021d0 <filter_inet>:
    21d0:      	sub	sp, sp, #0x80
    21d4:      	str	x30, [sp, #0x50]
    21d8:      	stp	x22, x21, [sp, #0x60]
    21dc:      	stp	x20, x19, [sp, #0x70]
    21e0:      	ldr	w10, [x0, #0xc]
    21e4:      	mov	x8, xzr
    21e8:      	stp	xzr, xzr, [sp, #0x28]
    21ec:      	cmp	w10, #0x27
    21f0:      	str	xzr, [sp, #0x10]
    21f4:      	stp	xzr, xzr, [sp, #0x18]
    21f8:      	str	wzr, [sp, #0x58]
    21fc:      	str	wzr, [sp, #0xc]
    2200:      	b.gt	0x224c <filter_inet+0x7c>
    2204:      	cmp	w10, #0x5
    2208:      	b.eq	0x2280 <filter_inet+0xb0>
    220c:      	cmp	w10, #0x7
    2210:      	mov	x11, x1
    2214:      	b.ne	0x2454 <filter_inet+0x284>
    2218:      	ldr	w9, [x0, #0x4]
    221c:      	mov	x8, xzr
    2220:      	cmp	w9, #0x13
    2224:      	b.le	0x22c8 <filter_inet+0xf8>
    2228:      	cmp	w9, #0x17
    222c:      	b.gt	0x2264 <filter_inet+0x94>
    2230:      	sub	w10, w9, #0x14
    2234:      	cmp	w10, #0x2
    2238:      	b.lo	0x2324 <filter_inet+0x154>
    223c:      	sub	w10, w9, #0x16
    2240:      	cmp	w10, #0x2
    2244:      	b.lo	0x231c <filter_inet+0x14c>
    2248:      	b	0x2454 <filter_inet+0x284>
    224c:      	cmp	w10, #0x28
    2250:      	b.eq	0x2298 <filter_inet+0xc8>
    2254:      	cmp	w10, #0x29
    2258:      	mov	x11, x1
    225c:      	b.eq	0x2218 <filter_inet+0x48>
    2260:      	b	0x2454 <filter_inet+0x284>
    2264:      	cmp	w9, #0x1b
    2268:      	b.gt	0x2368 <filter_inet+0x198>
    226c:      	cmp	w9, #0x18
    2270:      	b.eq	0x2424 <filter_inet+0x254>
    2274:      	cmp	w9, #0x19
    2278:      	b.eq	0x2388 <filter_inet+0x1b8>
    227c:      	b	0x2454 <filter_inet+0x284>
    2280:      	mov	x11, xzr
    2284:      	ldr	w9, [x0, #0x4]
    2288:      	mov	x8, xzr
    228c:      	cmp	w9, #0x13
    2290:      	b.gt	0x2228 <filter_inet+0x58>
    2294:      	b	0x22c8 <filter_inet+0xf8>
    2298:      	ldrh	w8, [x1]
    229c:      	ldrh	w9, [x1, #0x2]
    22a0:      	mov	x11, xzr
    22a4:      	strh	w8, [sp, #0x36]
    22a8:      	strh	w9, [sp, #0x30]
    22ac:      	ldp	x8, x9, [x1, #0x8]
    22b0:      	add	x1, sp, #0x10
    22b4:      	stp	x8, x9, [sp, #0x10]
    22b8:      	ldr	w9, [x0, #0x4]
    22bc:      	mov	x8, xzr
    22c0:      	cmp	w9, #0x13
    22c4:      	b.gt	0x2228 <filter_inet+0x58>
    22c8:      	cmp	w9, #0xf
    22cc:      	b.le	0x22f0 <filter_inet+0x120>
    22d0:      	cmp	w9, #0x11
    22d4:      	b.gt	0x230c <filter_inet+0x13c>
    22d8:      	cmp	w9, #0x10
    22dc:      	b.eq	0x231c <filter_inet+0x14c>
    22e0:      	cmp	w9, #0x11
    22e4:      	b.ne	0x2454 <filter_inet+0x284>
    22e8:      	ldrh	w8, [x1, #0x24]
    22ec:      	b	0x253c <filter_inet+0x36c>
    22f0:      	cmp	w9, #0xd
    22f4:      	b.eq	0x2424 <filter_inet+0x254>
    22f8:      	cmp	w9, #0xe
    22fc:      	b.eq	0x2388 <filter_inet+0x1b8>
    2300:      	cmp	w9, #0xf
    2304:      	b.eq	0x2324 <filter_inet+0x154>
    2308:      	b	0x2454 <filter_inet+0x284>
    230c:      	cmp	w9, #0x12
    2310:      	b.eq	0x2324 <filter_inet+0x154>
    2314:      	cmp	w9, #0x13
    2318:      	b.ne	0x2454 <filter_inet+0x284>
    231c:      	ldrh	w10, [x1, #0x22]
    2320:      	b	0x2328 <filter_inet+0x158>
    2324:      	ldrh	w10, [x1, #0x20]
    2328:      	mov	w19, wzr
    232c:      	mov	w20, wzr
    2330:      	mov	x21, xzr
    2334:      	str	w10, [sp, #0xc]
    2338:      	mov	x8, xzr
    233c:      	cmp	w9, #0x11
    2340:      	b.gt	0x23a0 <filter_inet+0x1d0>
    2344:      	sub	w10, w9, #0xd
    2348:      	cmp	w10, #0x2
    234c:      	b.lo	0x23d8 <filter_inet+0x208>
    2350:      	sub	w10, w9, #0xf
    2354:      	cmp	w10, #0x2
    2358:      	b.lo	0x244c <filter_inet+0x27c>
    235c:      	cmp	w9, #0x11
    2360:      	b.eq	0x2540 <filter_inet+0x370>
    2364:      	b	0x2454 <filter_inet+0x284>
    2368:      	cmp	w9, #0x1c
    236c:      	b.eq	0x2538 <filter_inet+0x368>
    2370:      	cmp	w9, #0x1d
    2374:      	b.ne	0x2454 <filter_inet+0x284>
    2378:      	cmp	w10, #0x7
    237c:      	b.ne	0x2590 <filter_inet+0x3c0>
    2380:      	cbnz	x11, 0x259c <filter_inet+0x3cc>
    2384:      	b	0x2540 <filter_inet+0x370>
    2388:      	ldp	w19, w20, [x1, #0x10]
    238c:      	ldr	x21, [x1, #0x18]
    2390:      	mov	w10, wzr
    2394:      	mov	x8, xzr
    2398:      	cmp	w9, #0x11
    239c:      	b.le	0x2344 <filter_inet+0x174>
    23a0:      	cmp	w9, #0x19
    23a4:      	b.hi	0x2440 <filter_inet+0x270>
    23a8:      	mov	w11, #0x1               // =1
    23ac:      	mov	w12, #0x500000          // =5242880
    23b0:      	lsl	w11, w11, w9
    23b4:      	tst	w11, w12
    23b8:      	b.ne	0x246c <filter_inet+0x29c>
    23bc:      	mov	w12, #0xa00000          // =10485760
    23c0:      	tst	w11, w12
    23c4:      	b.ne	0x248c <filter_inet+0x2bc>
    23c8:      	mov	w10, #0x1               // =1
    23cc:      	lsl	w10, w10, w9
    23d0:      	tst	w10, #0x3000000
    23d4:      	b.eq	0x2440 <filter_inet+0x270>
    23d8:      	ldrh	w8, [x1, #0x26]
    23dc:      	cmp	w8, #0xa
    23e0:      	b.eq	0x24ac <filter_inet+0x2dc>
    23e4:      	cmp	w8, #0x2
    23e8:      	b.ne	0x251c <filter_inet+0x34c>
    23ec:      	ldr	w8, [x0, #0x10]
    23f0:      	mov	x22, x0
    23f4:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    23f8:      	add	x9, sp, #0x5c
    23fc:      	str	w8, [sp, #0x5c]
    2400:      	mov	w8, #0x1                // =1
    2404:      	add	x1, sp, #0x5c
    2408:      	ldr	x0, [x0]
    240c:      	blr	x8
    2410:      	cbz	x0, 0x255c <filter_inet+0x38c>
    2414:      	mov	w8, #0x20               // =32
    2418:      	add	x1, sp, #0x3c
    241c:      	stp	w8, w19, [sp, #0x3c]
    2420:      	b	0x24ec <filter_inet+0x31c>
    2424:      	ldp	w19, w20, [x1]
    2428:      	ldr	x21, [x1, #0x8]
    242c:      	mov	w10, wzr
    2430:      	mov	x8, xzr
    2434:      	cmp	w9, #0x11
    2438:      	b.le	0x2344 <filter_inet+0x174>
    243c:      	b	0x23a0 <filter_inet+0x1d0>
    2440:      	sub	w9, w9, #0x12
    2444:      	cmp	w9, #0x2
    2448:      	b.hs	0x2454 <filter_inet+0x284>
    244c:      	add	x1, sp, #0xc
    2450:      	b	0x2544 <filter_inet+0x374>
    2454:      	ldp	x20, x19, [sp, #0x70]
    2458:      	mov	x0, x8
    245c:      	ldr	x30, [sp, #0x50]
    2460:      	ldp	x22, x21, [sp, #0x60]
    2464:      	add	sp, sp, #0x80
    2468:      	ret
    246c:      	cmp	w10, #0x400
    2470:      	cset	w8, lo
    2474:      	ldp	x20, x19, [sp, #0x70]
    2478:      	mov	x0, x8
    247c:      	ldr	x30, [sp, #0x50]
    2480:      	ldp	x22, x21, [sp, #0x60]
    2484:      	add	sp, sp, #0x80
    2488:      	ret
    248c:      	cmp	w10, #0x3ff
    2490:      	cset	w8, hi
    2494:      	ldp	x20, x19, [sp, #0x70]
    2498:      	mov	x0, x8
    249c:      	ldr	x30, [sp, #0x50]
    24a0:      	ldp	x22, x21, [sp, #0x60]
    24a4:      	add	sp, sp, #0x80
    24a8:      	ret
    24ac:      	ldr	w8, [x0, #0x14]
    24b0:      	mov	x22, x0
    24b4:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    24b8:      	add	x9, sp, #0x5c
    24bc:      	str	w8, [sp, #0x5c]
    24c0:      	mov	w8, #0x1                // =1
    24c4:      	add	x1, sp, #0x5c
    24c8:      	ldr	x0, [x0]
    24cc:      	blr	x8
    24d0:      	cbz	x0, 0x255c <filter_inet+0x38c>
    24d4:      	mov	w8, #0x80               // =128
    24d8:      	add	x1, sp, #0x3c
    24dc:      	stp	w20, w21, [sp, #0x44]
    24e0:      	stp	w8, w19, [sp, #0x3c]
    24e4:      	lsr	x8, x21, #32
    24e8:      	str	w8, [sp, #0x4c]
    24ec:      	mov	w8, #0x1                // =1
    24f0:      	blr	x8
    24f4:      	ldr	w8, [x22, #0x4]
    24f8:      	sub	w9, w8, #0x18
    24fc:      	cmp	w9, #0x2
    2500:      	b.lo	0x256c <filter_inet+0x39c>
    2504:      	sub	w8, w8, #0xd
    2508:      	cmp	w8, #0x1
    250c:      	b.hi	0x251c <filter_inet+0x34c>
    2510:      	cmp	x0, #0x0
    2514:      	cset	w8, ne
    2518:      	b	0x2574 <filter_inet+0x3a4>
    251c:      	mov	w8, wzr
    2520:      	ldp	x20, x19, [sp, #0x70]
    2524:      	mov	x0, x8
    2528:      	ldr	x30, [sp, #0x50]
    252c:      	ldp	x22, x21, [sp, #0x60]
    2530:      	add	sp, sp, #0x80
    2534:      	ret
    2538:      	ldrh	w8, [x1, #0x26]
    253c:      	str	w8, [sp, #0x58]
    2540:      	add	x1, sp, #0x58
    2544:      	bl	0xfc0 <filter_32ty_map>
    2548:      	ldp	x20, x19, [sp, #0x70]
    254c:      	ldr	x30, [sp, #0x50]
    2550:      	ldp	x22, x21, [sp, #0x60]
    2554:      	add	sp, sp, #0x80
    2558:      	ret
    255c:      	ldr	w8, [x22, #0x4]
    2560:      	and	w8, w8, #0xfffffffe
    2564:      	cmp	w8, #0x18
    2568:      	b	0x2570 <filter_inet+0x3a0>
    256c:      	cmp	x0, #0x0
    2570:      	cset	w8, eq
    2574:      	mov	w8, w8
    2578:      	ldp	x20, x19, [sp, #0x70]
    257c:      	mov	x0, x8
    2580:      	ldr	x30, [sp, #0x50]
    2584:      	ldp	x22, x21, [sp, #0x60]
    2588:      	add	sp, sp, #0x80
    258c:      	ret
    2590:      	cmp	w10, #0x29
    2594:      	b.ne	0x25a4 <filter_inet+0x3d4>
    2598:      	cbz	x11, 0x25a4 <filter_inet+0x3d4>
    259c:      	ldrb	w8, [x11, #0x3a]
    25a0:      	str	w8, [sp, #0x58]
    25a4:      	cmp	w10, #0x29
    25a8:      	b.eq	0x2540 <filter_inet+0x370>
    25ac:      	cmp	w10, #0x7
    25b0:      	b.eq	0x2540 <filter_inet+0x370>
    25b4:      	mov	x8, xzr
    25b8:      	ldp	x20, x19, [sp, #0x70]
    25bc:      	mov	x0, x8
    25c0:      	ldr	x30, [sp, #0x50]
    25c4:      	ldp	x22, x21, [sp, #0x60]
    25c8:      	add	sp, sp, #0x80
    25cc:      	ret

00000000000025d0 <filter_sockaddr_un>:
    25d0:      	sub	sp, sp, #0x20
    25d4:      	stp	x30, x19, [sp, #0x10]
    25d8:      	mov	x19, x0
    25dc:      	ldrb	w2, [x1, #0x3]
    25e0:      	mov	x0, xzr
    25e4:      	ldr	w8, [x19, #0x4]
    25e8:      	cmp	w8, #0x19
    25ec:      	b.gt	0x2640 <filter_sockaddr_un+0x70>
    25f0:      	sub	w9, w8, #0x3
    25f4:      	cmp	w9, #0x2
    25f8:      	b.hs	0x2654 <filter_sockaddr_un+0x84>
    25fc:      	add	x1, x1, #0x4
    2600:      	mov	x0, x19
    2604:      	bl	0x26c0 <filter_char_buf_equal>
    2608:      	ldr	w8, [x19, #0x4]
    260c:      	cmp	w8, #0x25
    2610:      	b.hi	0x2634 <filter_sockaddr_un+0x64>
    2614:      	mov	w9, #0x1                // =1
    2618:      	lsl	x8, x9, x8
    261c:      	mov	x9, #0x50               // =80
    2620:      	movk	x9, #0xc00, lsl #16
    2624:      	movk	x9, #0x20, lsl #32
    2628:      	tst	x8, x9
    262c:      	b.eq	0x2634 <filter_sockaddr_un+0x64>
    2630:      	eor	x0, x0, #0x1
    2634:      	ldp	x30, x19, [sp, #0x10]
    2638:      	add	sp, sp, #0x20
    263c:      	ret
    2640:      	cmp	w8, #0x1c
    2644:      	b.eq	0x26a0 <filter_sockaddr_un+0xd0>
    2648:      	cmp	w8, #0x1a
    264c:      	b.eq	0x265c <filter_sockaddr_un+0x8c>
    2650:      	b	0x2634 <filter_sockaddr_un+0x64>
    2654:      	cmp	w8, #0x8
    2658:      	b.ne	0x2634 <filter_sockaddr_un+0x64>
    265c:      	ldr	w0, [x19, #0x10]
    2660:      	add	x1, x1, #0x4
    2664:      	bl	0x2af0 <filter_char_buf_prefix>
    2668:      	ldr	w8, [x19, #0x4]
    266c:      	cmp	w8, #0x25
    2670:      	b.hi	0x2634 <filter_sockaddr_un+0x64>
    2674:      	mov	w9, #0x1                // =1
    2678:      	lsl	x8, x9, x8
    267c:      	mov	x9, #0x50               // =80
    2680:      	movk	x9, #0xc00, lsl #16
    2684:      	movk	x9, #0x20, lsl #32
    2688:      	tst	x8, x9
    268c:      	b.eq	0x2634 <filter_sockaddr_un+0x64>
    2690:      	eor	x0, x0, #0x1
    2694:      	ldp	x30, x19, [sp, #0x10]
    2698:      	add	sp, sp, #0x20
    269c:      	ret
    26a0:      	ldrh	w8, [x1]
    26a4:      	add	x1, sp, #0xc
    26a8:      	mov	x0, x19
    26ac:      	str	w8, [sp, #0xc]
    26b0:      	bl	0xfc0 <filter_32ty_map>
    26b4:      	ldp	x30, x19, [sp, #0x10]
    26b8:      	add	sp, sp, #0x20
    26bc:      	ret

00000000000026c0 <filter_char_buf_equal>:
    26c0:      	str	x29, [sp, #-0x50]!
    26c4:      	stp	x30, x25, [sp, #0x10]
    26c8:      	stp	x24, x23, [sp, #0x20]
    26cc:      	stp	x22, x21, [sp, #0x30]
    26d0:      	stp	x20, x19, [sp, #0x40]
    26d4:      	cmp	w2, #0x1, lsl #12       // =0x1000
    26d8:      	str	wzr, [sp, #0x8]
    26dc:      	b.ls	0x26fc <filter_char_buf_equal+0x3c>
    26e0:      	mov	x0, xzr
    26e4:      	ldp	x20, x19, [sp, #0x40]
    26e8:      	ldp	x22, x21, [sp, #0x30]
    26ec:      	ldp	x24, x23, [sp, #0x20]
    26f0:      	ldp	x30, x25, [sp, #0x10]
    26f4:      	ldr	x29, [sp], #0x50
    26f8:      	ret
    26fc:      	and	w9, w2, #0xffff
    2700:      	add	x8, x0, #0x10
    2704:      	cmp	w9, #0x90
    2708:      	b.hi	0x2778 <filter_char_buf_equal+0xb8>
    270c:      	and	w9, w2, #0xff
    2710:      	mov	w10, #0xab              // =171
    2714:      	tst	w2, #0xffff
    2718:      	mul	w9, w9, w10
    271c:      	mov	w10, #0x18              // =24
    2720:      	lsr	w9, w9, #12
    2724:      	msub	w9, w9, w10, w2
    2728:      	b.eq	0x2738 <filter_char_buf_equal+0x78>
    272c:      	tst	w9, #0xff
    2730:      	mov	w23, w2
    2734:      	b.eq	0x2750 <filter_char_buf_equal+0x90>
    2738:      	sub	w9, w2, w9, uxtb
    273c:      	and	w10, w9, #0xffff
    2740:      	add	w9, w9, #0x18
    2744:      	and	w23, w9, #0xffff
    2748:      	cmp	w10, #0x78
    274c:      	b.hi	0x27ec <filter_char_buf_equal+0x12c>
    2750:      	and	w9, w23, #0xff
    2754:      	mov	w10, #0xab              // =171
    2758:      	mul	w9, w9, w10
    275c:      	lsr	w9, w9, #12
    2760:      	sub	w22, w9, #0x1
    2764:      	and	w9, w22, #0xf
    2768:      	ldr	w24, [x8, w9, uxtw #2]
    276c:      	cmn	w24, #0x1
    2770:      	b.ne	0x2864 <filter_char_buf_equal+0x1a4>
    2774:      	b	0x2a0c <filter_char_buf_equal+0x34c>
    2778:      	cmp	w9, #0x101
    277c:      	b.hs	0x27bc <filter_char_buf_equal+0xfc>
    2780:      	mov	w23, #0x100             // =256
    2784:      	sub	w9, w23, #0x100
    2788:      	ror	w9, w9, #0x8
    278c:      	cmp	w9, #0x2
    2790:      	b.le	0x27fc <filter_char_buf_equal+0x13c>
    2794:      	cmp	w9, #0x3
    2798:      	b.eq	0x2838 <filter_char_buf_equal+0x178>
    279c:      	cmp	w9, #0x7
    27a0:      	b.ne	0x2820 <filter_char_buf_equal+0x160>
    27a4:      	mov	w22, #0x9               // =9
    27a8:      	and	w9, w22, #0xf
    27ac:      	ldr	w24, [x8, w9, uxtw #2]
    27b0:      	cmn	w24, #0x1
    27b4:      	b.ne	0x2864 <filter_char_buf_equal+0x1a4>
    27b8:      	b	0x2a0c <filter_char_buf_equal+0x34c>
    27bc:      	and	w9, w2, #0xffff
    27c0:      	cmp	w9, #0x201
    27c4:      	b.hs	0x27e0 <filter_char_buf_equal+0x120>
    27c8:      	mov	w23, #0x200             // =512
    27cc:      	sub	w9, w23, #0x100
    27d0:      	ror	w9, w9, #0x8
    27d4:      	cmp	w9, #0x2
    27d8:      	b.le	0x27fc <filter_char_buf_equal+0x13c>
    27dc:      	b	0x2794 <filter_char_buf_equal+0xd4>
    27e0:      	cmp	w9, #0x401
    27e4:      	b.hs	0x29c4 <filter_char_buf_equal+0x304>
    27e8:      	mov	w23, #0x400             // =1024
    27ec:      	sub	w9, w23, #0x100
    27f0:      	ror	w9, w9, #0x8
    27f4:      	cmp	w9, #0x2
    27f8:      	b.gt	0x2794 <filter_char_buf_equal+0xd4>
    27fc:      	cbz	w9, 0x2850 <filter_char_buf_equal+0x190>
    2800:      	cmp	w9, #0x1
    2804:      	b.ne	0x2820 <filter_char_buf_equal+0x160>
    2808:      	mov	w22, #0x7               // =7
    280c:      	and	w9, w22, #0xf
    2810:      	ldr	w24, [x8, w9, uxtw #2]
    2814:      	cmn	w24, #0x1
    2818:      	b.ne	0x2864 <filter_char_buf_equal+0x1a4>
    281c:      	b	0x2a0c <filter_char_buf_equal+0x34c>
    2820:      	mov	w22, #0xa               // =10
    2824:      	and	w9, w22, #0xf
    2828:      	ldr	w24, [x8, w9, uxtw #2]
    282c:      	cmn	w24, #0x1
    2830:      	b.ne	0x2864 <filter_char_buf_equal+0x1a4>
    2834:      	b	0x2a0c <filter_char_buf_equal+0x34c>
    2838:      	mov	w22, #0x8               // =8
    283c:      	and	w9, w22, #0xf
    2840:      	ldr	w24, [x8, w9, uxtw #2]
    2844:      	cmn	w24, #0x1
    2848:      	b.ne	0x2864 <filter_char_buf_equal+0x1a4>
    284c:      	b	0x2a0c <filter_char_buf_equal+0x34c>
    2850:      	mov	w22, #0x6               // =6
    2854:      	and	w9, w22, #0xf
    2858:      	ldr	w24, [x8, w9, uxtw #2]
    285c:      	cmn	w24, #0x1
    2860:      	b.eq	0x2a0c <filter_char_buf_equal+0x34c>
    2864:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2868:      	add	x29, sp, #0x8
    286c:      	mov	w8, #0x1                // =1
    2870:      	ldr	x0, [x0]
    2874:      	mov	x25, x1
    2878:      	add	x1, sp, #0x8
    287c:      	mov	w21, w2
    2880:      	mov	w20, #0x1               // =1
    2884:      	blr	x8
    2888:      	mov	x19, x0
    288c:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2890:      	add	x1, sp, #0x8
    2894:      	ldr	x0, [x0]
    2898:      	blr	x20
    289c:      	mov	x20, x0
    28a0:      	mov	x0, xzr
    28a4:      	cbz	x19, 0x26e4 <filter_char_buf_equal+0x24>
    28a8:      	cbz	x20, 0x26e4 <filter_char_buf_equal+0x24>
    28ac:      	mov	x0, x19
    28b0:      	cmp	w22, #0x5
    28b4:      	b.gt	0x28ec <filter_char_buf_equal+0x22c>
    28b8:      	strb	w21, [x0], #0x1
    28bc:      	mov	w29, w21
    28c0:      	mov	w8, #0x4                // =4
    28c4:      	mov	x2, x25
    28c8:      	mov	w1, w21
    28cc:      	blr	x8
    28d0:      	subs	w8, w23, w21
    28d4:      	b.ls	0x2924 <filter_char_buf_equal+0x264>
    28d8:      	add	x9, x19, x29
    28dc:      	and	w1, w8, #0xfff
    28e0:      	mov	w8, #0x4                // =4
    28e4:      	add	x0, x9, #0x1
    28e8:      	b	0x291c <filter_char_buf_equal+0x25c>
    28ec:      	strh	w21, [x0], #0x2
    28f0:      	mov	w29, w21
    28f4:      	mov	w8, #0x4                // =4
    28f8:      	mov	x2, x25
    28fc:      	mov	w1, w21
    2900:      	blr	x8
    2904:      	subs	w8, w23, w21
    2908:      	b.ls	0x2924 <filter_char_buf_equal+0x264>
    290c:      	add	x9, x19, x29
    2910:      	and	w1, w8, #0xfff
    2914:      	mov	w8, #0x4                // =4
    2918:      	add	x0, x9, #0x2
    291c:      	mov	x2, x20
    2920:      	blr	x8
    2924:      	cmp	w22, #0x4
    2928:      	str	w24, [sp, #0xc]
    292c:      	b.le	0x2964 <filter_char_buf_equal+0x2a4>
    2930:      	cmp	w22, #0x7
    2934:      	b.gt	0x2998 <filter_char_buf_equal+0x2d8>
    2938:      	cmp	w22, #0x5
    293c:      	b.eq	0x2a8c <filter_char_buf_equal+0x3cc>
    2940:      	cmp	w22, #0x6
    2944:      	b.eq	0x2a50 <filter_char_buf_equal+0x390>
    2948:      	cmp	w22, #0x7
    294c:      	b.ne	0x2a0c <filter_char_buf_equal+0x34c>
    2950:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2954:      	mov	w8, #0x1                // =1
    2958:      	add	x9, sp, #0xc
    295c:      	ldr	x0, [x0]
    2960:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2964:      	cmp	w22, #0x1
    2968:      	b.le	0x29ec <filter_char_buf_equal+0x32c>
    296c:      	cmp	w22, #0x2
    2970:      	b.eq	0x2a78 <filter_char_buf_equal+0x3b8>
    2974:      	cmp	w22, #0x3
    2978:      	b.eq	0x2a3c <filter_char_buf_equal+0x37c>
    297c:      	cmp	w22, #0x4
    2980:      	b.ne	0x2a0c <filter_char_buf_equal+0x34c>
    2984:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2988:      	mov	w8, #0x1                // =1
    298c:      	add	x9, sp, #0xc
    2990:      	ldr	x0, [x0]
    2994:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2998:      	cmp	w22, #0x8
    299c:      	b.eq	0x2aa0 <filter_char_buf_equal+0x3e0>
    29a0:      	cmp	w22, #0x9
    29a4:      	b.eq	0x2a64 <filter_char_buf_equal+0x3a4>
    29a8:      	cmp	w22, #0xa
    29ac:      	b.ne	0x2a0c <filter_char_buf_equal+0x34c>
    29b0:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    29b4:      	mov	w8, #0x1                // =1
    29b8:      	add	x9, sp, #0xc
    29bc:      	ldr	x0, [x0]
    29c0:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    29c4:      	and	w9, w2, #0xffff
    29c8:      	mov	w10, #0x1000            // =4096
    29cc:      	cmp	w9, #0x800
    29d0:      	mov	w9, #0x800              // =2048
    29d4:      	csel	w23, w10, w9, hi
    29d8:      	sub	w9, w23, #0x100
    29dc:      	ror	w9, w9, #0x8
    29e0:      	cmp	w9, #0x2
    29e4:      	b.le	0x27fc <filter_char_buf_equal+0x13c>
    29e8:      	b	0x2794 <filter_char_buf_equal+0xd4>
    29ec:      	cbz	w22, 0x2a28 <filter_char_buf_equal+0x368>
    29f0:      	cmp	w22, #0x1
    29f4:      	b.ne	0x2a0c <filter_char_buf_equal+0x34c>
    29f8:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    29fc:      	mov	w8, #0x1                // =1
    2a00:      	add	x9, sp, #0xc
    2a04:      	ldr	x0, [x0]
    2a08:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2a0c:      	mov	x0, xzr
    2a10:      	ldp	x20, x19, [sp, #0x40]
    2a14:      	ldp	x22, x21, [sp, #0x30]
    2a18:      	ldp	x24, x23, [sp, #0x20]
    2a1c:      	ldp	x30, x25, [sp, #0x10]
    2a20:      	ldr	x29, [sp], #0x50
    2a24:      	ret
    2a28:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2a2c:      	mov	w8, #0x1                // =1
    2a30:      	add	x9, sp, #0xc
    2a34:      	ldr	x0, [x0]
    2a38:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2a3c:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2a40:      	mov	w8, #0x1                // =1
    2a44:      	add	x9, sp, #0xc
    2a48:      	ldr	x0, [x0]
    2a4c:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2a50:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2a54:      	mov	w8, #0x1                // =1
    2a58:      	add	x9, sp, #0xc
    2a5c:      	ldr	x0, [x0]
    2a60:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2a64:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2a68:      	mov	w8, #0x1                // =1
    2a6c:      	add	x9, sp, #0xc
    2a70:      	ldr	x0, [x0]
    2a74:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2a78:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2a7c:      	mov	w8, #0x1                // =1
    2a80:      	add	x9, sp, #0xc
    2a84:      	ldr	x0, [x0]
    2a88:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2a8c:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2a90:      	mov	w8, #0x1                // =1
    2a94:      	add	x9, sp, #0xc
    2a98:      	ldr	x0, [x0]
    2a9c:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2aa0:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2aa4:      	mov	w8, #0x1                // =1
    2aa8:      	add	x9, sp, #0xc
    2aac:      	ldr	x0, [x0]
    2ab0:      	add	x1, sp, #0xc
    2ab4:      	blr	x8
    2ab8:      	cbz	x0, 0x26e4 <filter_char_buf_equal+0x24>
    2abc:      	mov	w8, #0x1                // =1
    2ac0:      	mov	x1, x19
    2ac4:      	blr	x8
    2ac8:      	cmp	x0, #0x0
    2acc:      	cset	w0, ne
    2ad0:      	ldp	x20, x19, [sp, #0x40]
    2ad4:      	ldp	x22, x21, [sp, #0x30]
    2ad8:      	ldp	x24, x23, [sp, #0x20]
    2adc:      	ldp	x30, x25, [sp, #0x10]
    2ae0:      	ldr	x29, [sp], #0x50
    2ae4:      	ret
    2ae8:      	nop
    2aec:      	nop

0000000000002af0 <filter_char_buf_prefix>:
    2af0:      	sub	sp, sp, #0x30
    2af4:      	stp	x30, x21, [sp, #0x10]
    2af8:      	stp	x20, x19, [sp, #0x20]
    2afc:      	stp	wzr, w0, [sp, #0x8]
    2b00:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2b04:      	mov	w8, #0x1                // =1
    2b08:      	add	x9, sp, #0xc
    2b0c:      	ldr	x0, [x0]
    2b10:      	mov	x19, x1
    2b14:      	add	x1, sp, #0xc
    2b18:      	mov	w20, w2
    2b1c:      	blr	x8
    2b20:      	mov	x8, x0
    2b24:      	mov	x0, xzr
    2b28:      	cbz	w20, 0x2b94 <filter_char_buf_prefix+0xa4>
    2b2c:      	cbz	x8, 0x2b94 <filter_char_buf_prefix+0xa4>
    2b30:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2b34:      	mov	x21, x8
    2b38:      	mov	w8, #0x1                // =1
    2b3c:      	ldr	x0, [x0]
    2b40:      	add	x9, sp, #0x8
    2b44:      	add	x1, sp, #0x8
    2b48:      	blr	x8
    2b4c:      	cbz	x0, 0x2b94 <filter_char_buf_prefix+0xa4>
    2b50:      	cmp	w20, #0xff
    2b54:      	mov	w8, #0xff               // =255
    2b58:      	mov	x2, x19
    2b5c:      	csel	w1, w20, w8, lo
    2b60:      	mov	x8, x0
    2b64:      	mov	x20, x0
    2b68:      	lsl	w9, w1, #3
    2b6c:      	str	w9, [x8], #0x4
    2b70:      	mov	w9, #0x4                // =4
    2b74:      	mov	x0, x8
    2b78:      	blr	x9
    2b7c:      	mov	w8, #0x1                // =1
    2b80:      	mov	x0, x21
    2b84:      	mov	x1, x20
    2b88:      	blr	x8
    2b8c:      	cmp	x0, #0x0
    2b90:      	cset	w0, ne
    2b94:      	ldp	x20, x19, [sp, #0x20]
    2b98:      	ldp	x30, x21, [sp, #0x10]
    2b9c:      	add	sp, sp, #0x30
    2ba0:      	ret
    2ba4:      	nop
    2ba8:      	nop
    2bac:      	nop

0000000000002bb0 <filter_char_buf_postfix>:
    2bb0:      	sub	sp, sp, #0x30
    2bb4:      	stp	x30, x21, [sp, #0x10]
    2bb8:      	stp	x20, x19, [sp, #0x20]
    2bbc:      	stp	wzr, w0, [sp, #0x8]
    2bc0:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2bc4:      	mov	w8, #0x1                // =1
    2bc8:      	add	x9, sp, #0xc
    2bcc:      	ldr	x0, [x0]
    2bd0:      	mov	x19, x1
    2bd4:      	add	x1, sp, #0xc
    2bd8:      	mov	w20, w2
    2bdc:      	blr	x8
    2be0:      	mov	x8, x0
    2be4:      	mov	x0, xzr
    2be8:      	cbz	w20, 0x2c7c <filter_char_buf_postfix+0xcc>
    2bec:      	cbz	x8, 0x2c7c <filter_char_buf_postfix+0xcc>
    2bf0:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2bf4:      	mov	x21, x8
    2bf8:      	mov	w8, #0x1                // =1
    2bfc:      	ldr	x0, [x0]
    2c00:      	add	x9, sp, #0x8
    2c04:      	add	x1, sp, #0x8
    2c08:      	blr	x8
    2c0c:      	cbz	x0, 0x2c7c <filter_char_buf_postfix+0xcc>
    2c10:      	cmp	w20, #0x7f
    2c14:      	mov	w9, #0x7f               // =127
    2c18:      	mov	x1, x0
    2c1c:      	mov	x8, xzr
    2c20:      	sub	w10, w20, #0x1
    2c24:      	csel	w9, w20, w9, lo
    2c28:      	lsl	w9, w9, #3
    2c2c:      	str	w9, [x0]
    2c30:      	mov	w9, w20
    2c34:      	nop
    2c38:      	nop
    2c3c:      	nop
    2c40:      	cmp	x8, #0x7f
    2c44:      	b.eq	0x2c68 <filter_char_buf_postfix+0xb8>
    2c48:      	and	x11, x10, #0xfff
    2c4c:      	add	x12, x1, x8
    2c50:      	add	x8, x8, #0x1
    2c54:      	ldrb	w11, [x19, x11]
    2c58:      	sub	w10, w10, #0x1
    2c5c:      	cmp	x9, x8
    2c60:      	strb	w11, [x12, #0x4]
    2c64:      	b.ne	0x2c40 <filter_char_buf_postfix+0x90>
    2c68:      	mov	w8, #0x1                // =1
    2c6c:      	mov	x0, x21
    2c70:      	blr	x8
    2c74:      	cmp	x0, #0x0
    2c78:      	cset	w0, ne
    2c7c:      	ldp	x20, x19, [sp, #0x20]
    2c80:      	ldp	x30, x21, [sp, #0x10]
    2c84:      	add	sp, sp, #0x30
    2c88:      	ret
    2c8c:      	nop

0000000000002c90 <filter_file_type>:
    2c90:      	sub	sp, sp, #0x20
    2c94:      	stp	x30, x19, [sp, #0x10]
    2c98:      	ldr	w8, [x1]
    2c9c:      	strh	wzr, [sp, #0xc]
    2ca0:      	cmp	w8, #0x1, lsl #12       // =0x1000
    2ca4:      	b.hi	0x2d7c <filter_file_type+0xec>
    2ca8:      	add	x9, x1, #0x4
    2cac:      	mov	w10, #0x2               // =2
    2cb0:      	mov	w11, #0x4               // =4
    2cb4:      	add	x12, sp, #0xc
    2cb8:      	mov	x19, x0
    2cbc:      	add	x0, sp, #0xc
    2cc0:      	add	x8, x9, x8
    2cc4:      	add	x8, x8, #0x4
    2cc8:      	ldr	w8, [x1]
    2ccc:      	mov	w1, #0x2                // =2
    2cd0:      	add	x8, x9, x8
    2cd4:      	add	x2, x8, #0x4
    2cd8:      	blr	x11
    2cdc:      	ldr	w9, [x19, #0x10]
    2ce0:      	cbz	w9, 0x2d7c <filter_file_type+0xec>
    2ce4:      	ldrh	w8, [sp, #0xc]
    2ce8:      	and	w8, w8, #0xf000
    2cec:      	cmp	w9, w8
    2cf0:      	b.ne	0x2d04 <filter_file_type+0x74>
    2cf4:      	mov	w0, #0x1                // =1
    2cf8:      	ldp	x30, x19, [sp, #0x10]
    2cfc:      	add	sp, sp, #0x20
    2d00:      	ret
    2d04:      	ldr	w9, [x19, #0x8]
    2d08:      	cmp	w9, #0xc
    2d0c:      	b.ls	0x2d7c <filter_file_type+0xec>
    2d10:      	ldr	w10, [x19, #0x14]
    2d14:      	cbz	w10, 0x2d7c <filter_file_type+0xec>
    2d18:      	cmp	w10, w8
    2d1c:      	b.ne	0x2d30 <filter_file_type+0xa0>
    2d20:      	mov	w0, #0x1                // =1
    2d24:      	ldp	x30, x19, [sp, #0x10]
    2d28:      	add	sp, sp, #0x20
    2d2c:      	ret
    2d30:      	cmp	w9, #0x11
    2d34:      	b.lo	0x2d7c <filter_file_type+0xec>
    2d38:      	ldr	w10, [x19, #0x18]
    2d3c:      	cbz	w10, 0x2d7c <filter_file_type+0xec>
    2d40:      	cmp	w10, w8
    2d44:      	b.ne	0x2d58 <filter_file_type+0xc8>
    2d48:      	mov	w0, #0x1                // =1
    2d4c:      	ldp	x30, x19, [sp, #0x10]
    2d50:      	add	sp, sp, #0x20
    2d54:      	ret
    2d58:      	cmp	w9, #0x15
    2d5c:      	b.lo	0x2d7c <filter_file_type+0xec>
    2d60:      	ldr	w9, [x19, #0x1c]
    2d64:      	cbz	w9, 0x2d7c <filter_file_type+0xec>
    2d68:      	cmp	w9, w8
    2d6c:      	cset	w0, eq
    2d70:      	ldp	x30, x19, [sp, #0x10]
    2d74:      	add	sp, sp, #0x20
    2d78:      	ret
    2d7c:      	mov	x0, xzr
    2d80:      	ldp	x30, x19, [sp, #0x10]
    2d84:      	add	sp, sp, #0x20
    2d88:      	ret
    2d8c:      	nop

0000000000002d90 <filter_char_substring>:
    2d90:      	str	x29, [sp, #-0x50]!
    2d94:      	stp	x30, x25, [sp, #0x10]
    2d98:      	stp	x24, x23, [sp, #0x20]
    2d9c:      	stp	x22, x21, [sp, #0x30]
    2da0:      	stp	x20, x19, [sp, #0x40]
    2da4:      	mov	x21, x1
    2da8:      	mov	x19, x0
    2dac:      	add	x23, x0, #0x10
    2db0:      	mov	w24, w2
    2db4:      	tbz	w3, #0x0, 0x2ea8 <filter_char_substring+0x118>
    2db8:      	cbz	w2, 0x2f68 <filter_char_substring+0x1d8>
    2dbc:      	adrp	x22, 0x2000 <filter_file_buf+0x50>
    2dc0:      	mov	x25, xzr
    2dc4:      	mov	w29, wzr
    2dc8:      	ldr	x22, [x22]
    2dcc:      	add	x20, sp, #0xc
    2dd0:      	nop
    2dd4:      	nop
    2dd8:      	nop
    2ddc:      	nop
    2de0:      	ldr	w8, [x23, x25, lsl #2]
    2de4:      	add	x1, sp, #0xc
    2de8:      	mov	x0, x22
    2dec:      	str	w8, [sp, #0xc]
    2df0:      	mov	w8, #0x1                // =1
    2df4:      	blr	x8
    2df8:      	cbz	x0, 0x3008 <filter_char_substring+0x278>
    2dfc:      	mov	x8, xzr
    2e00:      	mov	x9, x21
    2e04:      	mov	x10, x24
    2e08:      	b	0x2e20 <filter_char_substring+0x90>
    2e0c:      	add	x8, x8, #0x1
    2e10:      	sub	x10, x10, #0x1
    2e14:      	add	x9, x9, #0x1
    2e18:      	cmp	x8, x24
    2e1c:      	b.eq	0x2e84 <filter_char_substring+0xf4>
    2e20:      	mov	x11, xzr
    2e24:      	cmp	x10, x11
    2e28:      	b.eq	0x2e0c <filter_char_substring+0x7c>
    2e2c:      	ldrb	w12, [x0, x11]
    2e30:      	cbz	w12, 0x2e80 <filter_char_substring+0xf0>
    2e34:      	ldrb	w13, [x9, x11]
    2e38:      	sub	w14, w13, #0x41
    2e3c:      	orr	w15, w13, #0x20
    2e40:      	cmp	w14, #0x1a
    2e44:      	sub	w14, w12, #0x41
    2e48:      	csel	w13, w15, w13, lo
    2e4c:      	orr	w15, w12, #0x20
    2e50:      	cmp	w14, #0x1a
    2e54:      	csel	w12, w15, w12, lo
    2e58:      	cmp	x11, #0x62
    2e5c:      	b.hi	0x2e0c <filter_char_substring+0x7c>
    2e60:      	add	x11, x11, #0x1
    2e64:      	cmp	w13, w12
    2e68:      	b.eq	0x2e24 <filter_char_substring+0x94>
    2e6c:      	b	0x2e0c <filter_char_substring+0x7c>
    2e70:      	nop
    2e74:      	nop
    2e78:      	nop
    2e7c:      	nop
    2e80:      	tbz	w8, #0x1f, 0x3020 <filter_char_substring+0x290>
    2e84:      	ldr	w9, [x19, #0x8]
    2e88:      	add	w8, w29, #0xc
    2e8c:      	cmp	w8, w9
    2e90:      	b.hs	0x3004 <filter_char_substring+0x274>
    2e94:      	add	x25, x25, #0x1
    2e98:      	add	w29, w29, #0x4
    2e9c:      	cmp	x25, #0x64
    2ea0:      	b.ne	0x2de0 <filter_char_substring+0x50>
    2ea4:      	b	0x3004 <filter_char_substring+0x274>
    2ea8:      	cbz	w2, 0x2fbc <filter_char_substring+0x22c>
    2eac:      	adrp	x22, 0x2000 <filter_file_buf+0x50>
    2eb0:      	mov	x25, xzr
    2eb4:      	mov	w29, wzr
    2eb8:      	ldr	x22, [x22]
    2ebc:      	add	x20, sp, #0xc
    2ec0:      	ldr	w8, [x23, x25, lsl #2]
    2ec4:      	add	x1, sp, #0xc
    2ec8:      	mov	x0, x22
    2ecc:      	str	w8, [sp, #0xc]
    2ed0:      	mov	w8, #0x1                // =1
    2ed4:      	blr	x8
    2ed8:      	cbz	x0, 0x3008 <filter_char_substring+0x278>
    2edc:      	mov	x8, xzr
    2ee0:      	mov	x9, x21
    2ee4:      	mov	x10, x24
    2ee8:      	b	0x2f00 <filter_char_substring+0x170>
    2eec:      	add	x8, x8, #0x1
    2ef0:      	sub	x10, x10, #0x1
    2ef4:      	add	x9, x9, #0x1
    2ef8:      	cmp	x8, x24
    2efc:      	b.eq	0x2f44 <filter_char_substring+0x1b4>
    2f00:      	mov	x11, xzr
    2f04:      	cmp	x10, x11
    2f08:      	b.eq	0x2eec <filter_char_substring+0x15c>
    2f0c:      	ldrb	w12, [x0, x11]
    2f10:      	cbz	w12, 0x2f40 <filter_char_substring+0x1b0>
    2f14:      	cmp	x11, #0x62
    2f18:      	b.hi	0x2eec <filter_char_substring+0x15c>
    2f1c:      	ldrb	w13, [x9, x11]
    2f20:      	add	x11, x11, #0x1
    2f24:      	cmp	w13, w12
    2f28:      	b.eq	0x2f04 <filter_char_substring+0x174>
    2f2c:      	b	0x2eec <filter_char_substring+0x15c>
    2f30:      	nop
    2f34:      	nop
    2f38:      	nop
    2f3c:      	nop
    2f40:      	tbz	w8, #0x1f, 0x3020 <filter_char_substring+0x290>
    2f44:      	ldr	w9, [x19, #0x8]
    2f48:      	add	w8, w29, #0xc
    2f4c:      	cmp	w8, w9
    2f50:      	b.hs	0x3004 <filter_char_substring+0x274>
    2f54:      	add	x25, x25, #0x1
    2f58:      	add	w29, w29, #0x4
    2f5c:      	cmp	x25, #0x64
    2f60:      	b.ne	0x2ec0 <filter_char_substring+0x130>
    2f64:      	b	0x3004 <filter_char_substring+0x274>
    2f68:      	adrp	x20, 0x2000 <filter_file_buf+0x50>
    2f6c:      	mov	w21, #0x10              // =16
    2f70:      	add	x22, sp, #0xc
    2f74:      	ldr	x20, [x20]
    2f78:      	nop
    2f7c:      	nop
    2f80:      	ldr	w8, [x19, x21]
    2f84:      	add	x1, sp, #0xc
    2f88:      	mov	x0, x20
    2f8c:      	str	w8, [sp, #0xc]
    2f90:      	mov	w8, #0x1                // =1
    2f94:      	blr	x8
    2f98:      	cbz	x0, 0x3008 <filter_char_substring+0x278>
    2f9c:      	ldr	w8, [x19, #0x8]
    2fa0:      	add	x21, x21, #0x4
    2fa4:      	sub	w9, w21, #0x8
    2fa8:      	cmp	w9, w8
    2fac:      	b.hs	0x3004 <filter_char_substring+0x274>
    2fb0:      	cmp	x21, #0x1a0
    2fb4:      	b.ne	0x2f80 <filter_char_substring+0x1f0>
    2fb8:      	b	0x3004 <filter_char_substring+0x274>
    2fbc:      	adrp	x20, 0x2000 <filter_file_buf+0x50>
    2fc0:      	mov	w21, #0x10              // =16
    2fc4:      	add	x22, sp, #0xc
    2fc8:      	ldr	x20, [x20]
    2fcc:      	ldr	w8, [x19, x21]
    2fd0:      	add	x1, sp, #0xc
    2fd4:      	mov	x0, x20
    2fd8:      	str	w8, [sp, #0xc]
    2fdc:      	mov	w8, #0x1                // =1
    2fe0:      	blr	x8
    2fe4:      	cbz	x0, 0x3008 <filter_char_substring+0x278>
    2fe8:      	ldr	w8, [x19, #0x8]
    2fec:      	add	x21, x21, #0x4
    2ff0:      	sub	w9, w21, #0x8
    2ff4:      	cmp	w9, w8
    2ff8:      	b.hs	0x3004 <filter_char_substring+0x274>
    2ffc:      	cmp	x21, #0x1a0
    3000:      	b.ne	0x2fcc <filter_char_substring+0x23c>
    3004:      	mov	x0, xzr
    3008:      	ldp	x20, x19, [sp, #0x40]
    300c:      	ldp	x22, x21, [sp, #0x30]
    3010:      	ldp	x24, x23, [sp, #0x20]
    3014:      	ldp	x30, x25, [sp, #0x10]
    3018:      	ldr	x29, [sp], #0x50
    301c:      	ret
    3020:      	mov	w0, #0x1                // =1
    3024:      	ldp	x20, x19, [sp, #0x40]
    3028:      	ldp	x22, x21, [sp, #0x30]
    302c:      	ldp	x24, x23, [sp, #0x20]
    3030:      	ldp	x30, x25, [sp, #0x10]
    3034:      	ldr	x29, [sp], #0x50
    3038:      	ret
    303c:      	nop

0000000000003040 <do_action>:
    3040:      	sub	sp, sp, #0xc0
    3044:      	str	x29, [sp, #0x70]
    3048:      	stp	x30, x25, [sp, #0x80]
    304c:      	stp	x24, x23, [sp, #0x90]
    3050:      	stp	x22, x21, [sp, #0xa0]
    3054:      	stp	x20, x19, [sp, #0xb0]
    3058:      	add	x8, x2, w1, uxtw #2
    305c:      	str	wzr, [sp, #0x44]
    3060:      	adrp	x24, 0x3000 <filter_char_substring+0x270>
    3064:      	add	x9, sp, #0x44
    3068:      	mov	w19, w1
    306c:      	ldrsw	x22, [x8, #0x4]
    3070:      	ldr	x24, [x24]
    3074:      	mov	w8, #0x1                // =1
    3078:      	mov	x20, x0
    307c:      	add	x1, sp, #0x44
    3080:      	mov	w25, w4
    3084:      	mov	x23, x3
    3088:      	mov	x21, x2
    308c:      	mov	x0, x24
    3090:      	blr	x8
    3094:      	cbz	x0, 0x3538 <do_action+0x4f8>
    3098:      	mov	x29, x0
    309c:      	cmp	w22, #0x7
    30a0:      	b.gt	0x30c4 <do_action+0x84>
    30a4:      	cmp	w22, #0x3
    30a8:      	b.gt	0x310c <do_action+0xcc>
    30ac:      	cmp	w22, #0x1
    30b0:      	b.gt	0x3238 <do_action+0x1f8>
    30b4:      	cbz	w22, 0x3428 <do_action+0x3e8>
    30b8:      	cmp	w22, #0x1
    30bc:      	b.eq	0x3248 <do_action+0x208>
    30c0:      	b	0x3530 <do_action+0x4f0>
    30c4:      	cmp	w22, #0xb
    30c8:      	b.gt	0x3210 <do_action+0x1d0>
    30cc:      	sub	w8, w22, #0xa
    30d0:      	cmp	w8, #0x2
    30d4:      	b.lo	0x3338 <do_action+0x2f8>
    30d8:      	cmp	w22, #0x8
    30dc:      	b.eq	0x3384 <do_action+0x344>
    30e0:      	cmp	w22, #0x9
    30e4:      	b.ne	0x3530 <do_action+0x4f0>
    30e8:      	add	w19, w19, #0x1
    30ec:      	add	x8, x21, w19, uxtw #2
    30f0:      	ldr	w0, [x8, #0x4]
    30f4:      	tbz	w25, #0x0, 0x34d4 <do_action+0x494>
    30f8:      	sxtw	x8, w0
    30fc:      	mov	w9, #0x6d               // =109
    3100:      	blr	x9
    3104:      	mov	w20, #0x2               // =2
    3108:      	b	0x34ec <do_action+0x4ac>
    310c:      	sub	w8, w22, #0x6
    3110:      	cmp	w8, #0x2
    3114:      	b.lo	0x3370 <do_action+0x330>
    3118:      	cmp	w22, #0x4
    311c:      	b.eq	0x338c <do_action+0x34c>
    3120:      	cmp	w22, #0x5
    3124:      	b.ne	0x3530 <do_action+0x4f0>
    3128:      	add	w9, w19, #0x1
    312c:      	add	x8, x21, #0x4
    3130:      	add	w19, w19, #0x2
    3134:      	ldr	w9, [x8, w9, uxtw #2]
    3138:      	and	x9, x9, #0x7
    313c:      	cmp	w9, #0x4
    3140:      	b.hi	0x3530 <do_action+0x4f0>
    3144:      	add	x10, x29, x9, lsl #2
    3148:      	mov	w11, #0x5ea0            // =24224
    314c:      	ldr	w10, [x10, x11]
    3150:      	cbnz	w10, 0x3530 <do_action+0x4f0>
    3154:      	ldr	w20, [x8, w19, uxtw #2]
    3158:      	add	x8, x29, x9, lsl #3
    315c:      	ldr	x8, [x8, #0x5e78]
    3160:      	str	wzr, [sp, #0x54]
    3164:      	and	x8, x8, #0x7ff
    3168:      	add	x8, x29, x8
    316c:      	ldr	w8, [x8, #0x90]
    3170:      	str	w8, [sp, #0x50]
    3174:      	mov	w8, #0xe                // =14
    3178:      	blr	x8
    317c:      	lsr	x8, x0, #32
    3180:      	adrp	x21, 0x3000 <filter_char_substring+0x270>
    3184:      	add	x9, sp, #0x48
    3188:      	str	x8, [sp, #0x48]
    318c:      	mov	w8, #0x1                // =1
    3190:      	add	x1, sp, #0x48
    3194:      	ldr	x21, [x21]
    3198:      	mov	x0, x21
    319c:      	blr	x8
    31a0:      	cbz	x0, 0x3530 <do_action+0x4f0>
    31a4:      	and	x8, x20, #0x7
    31a8:      	cmp	w8, #0x4
    31ac:      	b.hi	0x3530 <do_action+0x4f0>
    31b0:      	add	x9, x29, x8, lsl #2
    31b4:      	mov	w10, #0x5ea0            // =24224
    31b8:      	ldr	w9, [x9, x10]
    31bc:      	cbnz	w9, 0x3530 <do_action+0x4f0>
    31c0:      	add	x8, x29, x8, lsl #3
    31c4:      	mov	x23, x0
    31c8:      	ldr	x8, [x8, #0x5e78]
    31cc:      	str	wzr, [sp, #0x54]
    31d0:      	and	x8, x8, #0x7ff
    31d4:      	add	x8, x29, x8
    31d8:      	ldr	w8, [x8, #0x90]
    31dc:      	str	w8, [sp, #0x50]
    31e0:      	mov	w8, #0xe                // =14
    31e4:      	blr	x8
    31e8:      	lsr	x8, x0, #32
    31ec:      	mov	x3, xzr
    31f0:      	add	x9, sp, #0x48
    31f4:      	str	x8, [sp, #0x48]
    31f8:      	mov	w8, #0x2                // =2
    31fc:      	add	x1, sp, #0x48
    3200:      	mov	x0, x21
    3204:      	mov	x2, x23
    3208:      	blr	x8
    320c:      	b	0x3530 <do_action+0x4f0>
    3210:      	cmp	w22, #0xc
    3214:      	b.eq	0x34dc <do_action+0x49c>
    3218:      	cmp	w22, #0xd
    321c:      	b.eq	0x339c <do_action+0x35c>
    3220:      	cmp	w22, #0xe
    3224:      	b.ne	0x3530 <do_action+0x4f0>
    3228:      	tst	w25, #0x1
    322c:      	mov	w8, #0x8                // =8
    3230:      	add	w19, w19, #0x2
    3234:      	b	0x34e8 <do_action+0x4a8>
    3238:      	cmp	w22, #0x2
    323c:      	b.eq	0x34cc <do_action+0x48c>
    3240:      	cmp	w22, #0x3
    3244:      	b.ne	0x3530 <do_action+0x4f0>
    3248:      	add	w8, w19, #0x1
    324c:      	add	x9, x21, #0x4
    3250:      	add	w19, w19, #0x2
    3254:      	str	wzr, [sp, #0x58]
    3258:      	ldr	w21, [x9, w8, uxtw #2]
    325c:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    3260:      	ldr	w20, [x9, w19, uxtw #2]
    3264:      	ldr	x0, [x0]
    3268:      	mov	w8, #0x1                // =1
    326c:      	add	x9, sp, #0x58
    3270:      	add	x1, sp, #0x58
    3274:      	blr	x8
    3278:      	cbz	x0, 0x3364 <do_action+0x324>
    327c:      	and	x8, x21, #0x7
    3280:      	cmp	w8, #0x4
    3284:      	b.hi	0x3360 <do_action+0x320>
    3288:      	add	x9, x29, x8, lsl #2
    328c:      	mov	w10, #0x5ea0            // =24224
    3290:      	ldr	w9, [x9, x10]
    3294:      	cbnz	w9, 0x3360 <do_action+0x320>
    3298:      	add	x8, x29, x8, lsl #3
    329c:      	mov	x21, x0
    32a0:      	ldr	x8, [x8, #0x5e78]
    32a4:      	str	wzr, [sp, #0x54]
    32a8:      	and	x8, x8, #0x7ff
    32ac:      	add	x8, x29, x8
    32b0:      	ldr	w8, [x8, #0x90]
    32b4:      	str	w8, [sp, #0x50]
    32b8:      	mov	w8, #0xe                // =14
    32bc:      	blr	x8
    32c0:      	lsr	x8, x0, #32
    32c4:      	cmp	w22, #0x1
    32c8:      	str	x8, [sp, #0x48]
    32cc:      	b.ne	0x365c <do_action+0x61c>
    32d0:      	and	x8, x20, #0x7
    32d4:      	cmp	w8, #0x4
    32d8:      	b.hi	0x3360 <do_action+0x320>
    32dc:      	add	x9, x29, x8, lsl #2
    32e0:      	mov	w10, #0x5ea0            // =24224
    32e4:      	ldr	w9, [x9, x10]
    32e8:      	cbnz	w9, 0x3360 <do_action+0x320>
    32ec:      	add	x8, x29, x8, lsl #3
    32f0:      	mov	x0, x21
    32f4:      	ldr	x8, [x8, #0x5e78]
    32f8:      	and	x8, x8, #0x7ff
    32fc:      	add	x2, x29, x8
    3300:      	ldr	w8, [x2, #0x90]!
    3304:      	and	x8, x8, #0xfff
    3308:      	add	x1, x8, #0x8
    330c:      	mov	w8, #0x4                // =4
    3310:      	blr	x8
    3314:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    3318:      	mov	x3, xzr
    331c:      	mov	w8, #0x2                // =2
    3320:      	ldr	x0, [x0]
    3324:      	add	x9, sp, #0x48
    3328:      	add	x1, sp, #0x48
    332c:      	mov	x2, x21
    3330:      	blr	x8
    3334:      	b	0x3360 <do_action+0x320>
    3338:      	add	w19, w19, #0x1
    333c:      	add	x8, x21, w19, uxtw #2
    3340:      	ldr	w8, [x8, #0x4]
    3344:      	and	x8, x8, #0x7
    3348:      	cmp	w8, #0x4
    334c:      	b.hi	0x3360 <do_action+0x320>
    3350:      	add	x9, x29, x8, lsl #2
    3354:      	mov	w10, #0x5ea0            // =24224
    3358:      	ldr	w9, [x9, x10]
    335c:      	cbz	w9, 0x3554 <do_action+0x514>
    3360:      	mov	w0, wzr
    3364:      	cbz	w0, 0x3530 <do_action+0x4f0>
    3368:      	mov	w0, wzr
    336c:      	b	0x3538 <do_action+0x4f8>
    3370:      	add	w19, w19, #0x1
    3374:      	add	x8, x21, w19, uxtw #2
    3378:      	ldr	w8, [x8, #0x4]
    337c:      	str	w8, [x29, #0x78]
    3380:      	b	0x3530 <do_action+0x4f0>
    3384:      	strb	wzr, [x23]
    3388:      	b	0x3530 <do_action+0x4f0>
    338c:      	tst	w25, #0x1
    3390:      	mov	w8, #0x4                // =4
    3394:      	add	w19, w19, #0x1
    3398:      	b	0x34e8 <do_action+0x4a8>
    339c:      	mov	w8, #0xe                // =14
    33a0:      	blr	x8
    33a4:      	str	x0, [sp, #0x68]
    33a8:      	adrp	x21, 0x3000 <filter_char_substring+0x270>
    33ac:      	add	x8, sp, #0x68
    33b0:      	mov	w9, #0x1                // =1
    33b4:      	ldr	x21, [x21]
    33b8:      	add	x1, sp, #0x68
    33bc:      	mov	w20, #0x1               // =1
    33c0:      	mov	x0, x21
    33c4:      	blr	x9
    33c8:      	cbz	x0, 0x3530 <do_action+0x4f0>
    33cc:      	ldur	x8, [x0, #0x4]
    33d0:      	adrp	x25, 0x3000 <filter_char_substring+0x270>
    33d4:      	mov	w9, #0x1                // =1
    33d8:      	add	x1, sp, #0x58
    33dc:      	str	x8, [sp, #0x58]
    33e0:      	mov	w8, #0x2                // =2
    33e4:      	str	w8, [sp, #0x60]
    33e8:      	add	x8, sp, #0x58
    33ec:      	ldr	x25, [x25]
    33f0:      	mov	x0, x25
    33f4:      	blr	x9
    33f8:      	str	w20, [sp, #0x78]
    33fc:      	cbz	x0, 0x35e0 <do_action+0x5a0>
    3400:      	ldaxr	w8, [x0]
    3404:      	add	w8, w8, #0x1
    3408:      	stlxr	w9, w8, [x0]
    340c:      	cbnz	w9, 0x3400 <do_action+0x3c0>
    3410:      	mov	w8, #0x3                // =3
    3414:      	add	x9, sp, #0x68
    3418:      	add	x1, sp, #0x68
    341c:      	mov	x0, x21
    3420:      	blr	x8
    3424:      	b	0x3530 <do_action+0x4f0>
    3428:      	add	w8, w19, #0x1
    342c:      	add	x9, x21, #0x4
    3430:      	str	x20, [sp, #0x30]
    3434:      	ldr	w25, [x9, w8, uxtw #2]
    3438:      	add	w8, w19, #0x2
    343c:      	ldr	w20, [x9, w8, uxtw #2]
    3440:      	mov	w8, #0x7d               // =125
    3444:      	blr	x8
    3448:      	str	x0, [sp, #0x8]
    344c:      	str	x0, [sp, #0x48]
    3450:      	str	wzr, [sp, #0x68]
    3454:      	cbz	w25, 0x3888 <do_action+0x848>
    3458:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    345c:      	mov	w8, #0x1                // =1
    3460:      	add	x9, sp, #0x68
    3464:      	ldr	x0, [x0]
    3468:      	add	x1, sp, #0x68
    346c:      	blr	x8
    3470:      	cbz	x0, 0x3888 <do_action+0x848>
    3474:      	mov	x10, x0
    3478:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    347c:      	mov	w8, #0x1                // =1
    3480:      	ldr	x0, [x0]
    3484:      	add	x9, sp, #0x68
    3488:      	add	x1, sp, #0x68
    348c:      	str	x10, [sp, #0x10]
    3490:      	blr	x8
    3494:      	ldr	x9, [sp, #0x10]
    3498:      	ldr	x8, [x29, #0x60]
    349c:      	mov	x2, x0
    34a0:      	cmp	w20, #0x2
    34a4:      	str	x8, [x9]
    34a8:      	ldr	x8, [x29, #0x70]
    34ac:      	str	x8, [x9, #0x8]
    34b0:      	b.eq	0x36a0 <do_action+0x660>
    34b4:      	cmp	w20, #0x1
    34b8:      	b.eq	0x3694 <do_action+0x654>
    34bc:      	cbnz	w20, 0x3888 <do_action+0x848>
    34c0:      	ldr	w8, [x29, #0x7c]
    34c4:      	str	x25, [sp]
    34c8:      	b	0x36a8 <do_action+0x668>
    34cc:      	mov	w0, #0x9                // =9
    34d0:      	tbnz	w25, #0x0, 0x30f8 <do_action+0xb8>
    34d4:      	mov	w20, #0x3               // =3
    34d8:      	b	0x34ec <do_action+0x4ac>
    34dc:      	tst	w25, #0x1
    34e0:      	mov	w8, #0x6                // =6
    34e4:      	add	w19, w19, #0x3
    34e8:      	cinc	x20, x8, eq
    34ec:      	str	wzr, [sp, #0x48]
    34f0:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    34f4:      	mov	w8, #0x1                // =1
    34f8:      	add	x9, sp, #0x48
    34fc:      	ldr	x0, [x0]
    3500:      	add	x1, sp, #0x48
    3504:      	blr	x8
    3508:      	cbz	x0, 0x3530 <do_action+0x4f0>
    350c:      	add	x8, x0, x20, lsl #3
    3510:      	nop
    3514:      	nop
    3518:      	nop
    351c:      	nop
    3520:      	ldaxr	x9, [x8]
    3524:      	add	x9, x9, #0x1
    3528:      	stlxr	w10, x9, [x8]
    352c:      	cbnz	w10, 0x3520 <do_action+0x4e0>
    3530:      	add	w0, w19, #0x1
    3534:      	str	x22, [x29, #0x70]
    3538:      	ldp	x20, x19, [sp, #0xb0]
    353c:      	ldr	x29, [sp, #0x70]
    3540:      	ldp	x22, x21, [sp, #0xa0]
    3544:      	ldp	x24, x23, [sp, #0x90]
    3548:      	ldp	x30, x25, [sp, #0x80]
    354c:      	add	sp, sp, #0xc0
    3550:      	ret
    3554:      	add	x8, x29, x8, lsl #3
    3558:      	ldr	x8, [x8, #0x5e78]
    355c:      	and	x8, x8, #0x7ff
    3560:      	add	x8, x29, x8
    3564:      	ldr	x8, [x8, #0xb8]
    3568:      	str	x8, [sp, #0x58]
    356c:      	cbz	x8, 0x3360 <do_action+0x320>
    3570:      	cmp	w22, #0xa
    3574:      	b.ne	0x3678 <do_action+0x638>
    3578:      	mov	w8, #0xe                // =14
    357c:      	blr	x8
    3580:      	lsr	x8, x0, #32
    3584:      	mov	x21, x0
    3588:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    358c:      	str	w8, [sp, #0x48]
    3590:      	mov	w8, #0x1                // =1
    3594:      	add	x9, sp, #0x48
    3598:      	add	x1, sp, #0x48
    359c:      	ldr	x0, [x0]
    35a0:      	blr	x8
    35a4:      	cbz	x0, 0x3364 <do_action+0x324>
    35a8:      	ldr	w8, [x0]
    35ac:      	mov	x3, xzr
    35b0:      	add	x9, sp, #0x58
    35b4:      	add	x10, sp, #0x48
    35b8:      	stp	w8, w21, [sp, #0x48]
    35bc:      	ldr	x8, [x0, #0x8]
    35c0:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    35c4:      	add	x1, sp, #0x58
    35c8:      	add	x2, sp, #0x48
    35cc:      	str	x8, [sp, #0x50]
    35d0:      	mov	w8, #0x2                // =2
    35d4:      	ldr	x0, [x0]
    35d8:      	blr	x8
    35dc:      	b	0x3360 <do_action+0x320>
    35e0:      	mov	w8, #0x1                // =1
    35e4:      	mov	w9, #0x2                // =2
    35e8:      	add	x10, sp, #0x58
    35ec:      	add	x11, sp, #0x78
    35f0:      	add	x1, sp, #0x58
    35f4:      	add	x2, sp, #0x78
    35f8:      	mov	x0, x25
    35fc:      	mov	w3, #0x1                // =1
    3600:      	blr	x9
    3604:      	cbz	x0, 0x3410 <do_action+0x3d0>
    3608:      	mov	x23, x0
    360c:      	adrp	x24, 0x3000 <filter_char_substring+0x270>
    3610:      	mov	w9, #0x1                // =1
    3614:      	add	x1, sp, #0x48
    3618:      	mov	w20, #0x1               // =1
    361c:      	neg	w8, w23
    3620:      	strh	w8, [sp, #0x48]
    3624:      	mov	w8, #0x3                // =3
    3628:      	strh	w8, [sp, #0x4a]
    362c:      	mov	x8, #0x3b               // =59
    3630:      	movk	x8, #0x2, lsl #32
    3634:      	stur	x8, [sp, #0x4c]
    3638:      	add	x8, sp, #0x48
    363c:      	ldr	x24, [x24]
    3640:      	mov	x0, x24
    3644:      	blr	x9
    3648:      	cbz	x0, 0x3920 <do_action+0x8e0>
    364c:      	ldr	w8, [x0]
    3650:      	add	w8, w8, #0x1
    3654:      	str	w8, [x0]
    3658:      	b	0x3944 <do_action+0x904>
    365c:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    3660:      	mov	w8, #0x3                // =3
    3664:      	add	x9, sp, #0x48
    3668:      	ldr	x0, [x0]
    366c:      	add	x1, sp, #0x48
    3670:      	blr	x8
    3674:      	b	0x3364 <do_action+0x324>
    3678:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    367c:      	mov	w8, #0x3                // =3
    3680:      	add	x9, sp, #0x58
    3684:      	ldr	x0, [x0]
    3688:      	add	x1, sp, #0x58
    368c:      	blr	x8
    3690:      	b	0x3364 <do_action+0x324>
    3694:      	ldr	w8, [x29, #0x10]
    3698:      	str	x25, [sp]
    369c:      	b	0x36a8 <do_action+0x668>
    36a0:      	str	x25, [sp]
    36a4:      	mov	w8, wzr
    36a8:      	mov	w8, w8
    36ac:      	add	x0, x9, #0x18
    36b0:      	mov	w1, #0xc8               // =200
    36b4:      	str	x8, [x9, #0x10]
    36b8:      	mov	w8, #0xc8               // =200
    36bc:      	mov	w9, #0x4                // =4
    36c0:      	str	x0, [sp, #0x18]
    36c4:      	blr	x9
    36c8:      	ldr	x20, [sp, #0x30]
    36cc:      	mov	w8, #0x5e78             // =24184
    36d0:      	mov	x25, xzr
    36d4:      	str	wzr, [sp, #0x2c]
    36d8:      	add	x10, x29, x8
    36dc:      	str	x23, [sp, #0x20]
    36e0:      	b	0x36f4 <do_action+0x6b4>
    36e4:      	add	x25, x25, #0x4
    36e8:      	add	x10, x10, #0x8
    36ec:      	cmp	x25, #0x14
    36f0:      	b.eq	0x382c <do_action+0x7ec>
    36f4:      	str	x10, [sp, #0x38]
    36f8:      	str	wzr, [sp, #0x58]
    36fc:      	mov	w8, #0x1                // =1
    3700:      	add	x9, sp, #0x58
    3704:      	add	x1, sp, #0x58
    3708:      	mov	x0, x24
    370c:      	blr	x8
    3710:      	cbz	x0, 0x382c <do_action+0x7ec>
    3714:      	mov	w8, #0x5ef8             // =24312
    3718:      	add	x1, x0, x8
    371c:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    3720:      	mov	w8, #0x1                // =1
    3724:      	ldr	x0, [x0]
    3728:      	blr	x8
    372c:      	cbz	x0, 0x382c <do_action+0x7ec>
    3730:      	add	x8, x0, x25
    3734:      	ldr	x10, [sp, #0x38]
    3738:      	ldr	w8, [x8, #0x40]
    373c:      	cmn	w8, #0x1
    3740:      	b.eq	0x382c <do_action+0x7ec>
    3744:      	ldr	x8, [x10]
    3748:      	ldr	w9, [x29, #0x4]
    374c:      	cmp	x8, x9
    3750:      	b.ge	0x382c <do_action+0x7ec>
    3754:      	cmp	x25, #0x10
    3758:      	b.eq	0x37c0 <do_action+0x780>
    375c:      	str	wzr, [sp, #0x58]
    3760:      	mov	w8, #0x1                // =1
    3764:      	add	x9, sp, #0x58
    3768:      	add	x1, sp, #0x58
    376c:      	mov	x0, x24
    3770:      	blr	x8
    3774:      	cbz	x0, 0x37b8 <do_action+0x778>
    3778:      	mov	w8, #0x5ef8             // =24312
    377c:      	add	x1, x0, x8
    3780:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    3784:      	mov	w8, #0x1                // =1
    3788:      	ldr	x0, [x0]
    378c:      	blr	x8
    3790:      	cbz	x0, 0x37b8 <do_action+0x778>
    3794:      	ldr	x10, [sp, #0x38]
    3798:      	add	x8, x0, x25
    379c:      	ldr	w9, [x8, #0x44]
    37a0:      	ldr	x8, [x10]
    37a4:      	cmn	w9, #0x1
    37a8:      	b.eq	0x37c0 <do_action+0x780>
    37ac:      	ldr	w9, [x10, #0x8]
    37b0:      	sub	w9, w9, w8
    37b4:      	b	0x37cc <do_action+0x78c>
    37b8:      	ldr	x10, [sp, #0x38]
    37bc:      	ldr	x8, [x10]
    37c0:      	ldr	w9, [x29, #0x4]
    37c4:      	sub	w9, w9, w8
    37c8:      	add	w9, w9, #0x4
    37cc:      	cmp	w9, #0x1
    37d0:      	b.lt	0x36e4 <do_action+0x6a4>
    37d4:      	mov	w10, #0x3ffc            // =16380
    37d8:      	cmp	w9, #0x28
    37dc:      	mov	x23, x29
    37e0:      	add	w8, w8, w10
    37e4:      	mov	w10, #0x28              // =40
    37e8:      	csel	w29, w9, w10, lt
    37ec:      	ldr	w9, [sp, #0x2c]
    37f0:      	and	x8, x8, #0x3fff
    37f4:      	add	x8, x23, x8
    37f8:      	mov	w1, w29
    37fc:      	add	x2, x8, #0x90
    3800:      	mov	w8, #0x4                // =4
    3804:      	and	w20, w9, #0xff
    3808:      	ldr	x9, [sp, #0x18]
    380c:      	add	x0, x9, x20
    3810:      	blr	x8
    3814:      	add	w8, w29, w20
    3818:      	ldp	x20, x10, [sp, #0x30]
    381c:      	mov	x29, x23
    3820:      	ldr	x23, [sp, #0x20]
    3824:      	str	w8, [sp, #0x2c]
    3828:      	b	0x36e4 <do_action+0x6a4>
    382c:      	adrp	x24, 0x3000 <filter_char_substring+0x270>
    3830:      	mov	w8, #0x1                // =1
    3834:      	ldr	x24, [x24]
    3838:      	ldr	x1, [sp, #0x10]
    383c:      	mov	x0, x24
    3840:      	blr	x8
    3844:      	cbz	x0, 0x386c <do_action+0x82c>
    3848:      	ldp	x10, x11, [sp]
    384c:      	mov	x9, #-0x4240            // =-16960
    3850:      	movk	x9, #0xfff0, lsl #16
    3854:      	ldr	x8, [x0]
    3858:      	madd	x9, x10, x9, x11
    385c:      	cmp	x8, x9
    3860:      	b.ls	0x386c <do_action+0x82c>
    3864:      	strb	wzr, [x23]
    3868:      	b	0x388c <do_action+0x84c>
    386c:      	ldr	x1, [sp, #0x10]
    3870:      	mov	x3, xzr
    3874:      	mov	w8, #0x2                // =2
    3878:      	add	x9, sp, #0x48
    387c:      	add	x2, sp, #0x48
    3880:      	mov	x0, x24
    3884:      	blr	x8
    3888:      	ldr	x20, [sp, #0x30]
    388c:      	add	w8, w19, #0x3
    3890:      	adrp	x23, 0x3000 <filter_char_substring+0x270>
    3894:      	add	x8, x21, w8, uxtw #2
    3898:      	ldr	w8, [x8, #0x4]
    389c:      	ldr	x23, [x23]
    38a0:      	cbz	w8, 0x38c8 <do_action+0x888>
    38a4:      	ldrb	w8, [x29, #0x1]
    38a8:      	mov	x2, xzr
    38ac:      	mov	x0, x20
    38b0:      	mov	x1, x23
    38b4:      	orr	w8, w8, #0x2
    38b8:      	strb	w8, [x29, #0x1]
    38bc:      	mov	w8, #0x1b               // =27
    38c0:      	blr	x8
    38c4:      	str	x0, [x29, #0x80]
    38c8:      	add	w8, w19, #0x4
    38cc:      	add	x8, x21, w8, uxtw #2
    38d0:      	ldr	w8, [x8, #0x4]
    38d4:      	cbz	w8, 0x3900 <do_action+0x8c0>
    38d8:      	ldrb	w8, [x29, #0x1]
    38dc:      	mov	w9, #0x1b               // =27
    38e0:      	mov	x0, x20
    38e4:      	mov	x1, x23
    38e8:      	mov	w2, #0x100              // =256
    38ec:      	orr	w8, w8, #0x4
    38f0:      	strb	w8, [x29, #0x1]
    38f4:      	mov	w8, #0x100              // =256
    38f8:      	blr	x9
    38fc:      	str	x0, [x29, #0x88]
    3900:      	add	w19, w19, #0x5
    3904:      	add	x8, x21, w19, uxtw #2
    3908:      	ldr	w8, [x8, #0x4]
    390c:      	cbz	w8, 0x3530 <do_action+0x4f0>
    3910:      	ldrb	w8, [x29, #0x1]
    3914:      	orr	w8, w8, #0x8
    3918:      	strb	w8, [x29, #0x1]
    391c:      	b	0x3530 <do_action+0x4f0>
    3920:      	str	w20, [sp, #0x7c]
    3924:      	mov	x3, xzr
    3928:      	mov	w8, #0x2                // =2
    392c:      	add	x9, sp, #0x48
    3930:      	add	x10, sp, #0x7c
    3934:      	add	x1, sp, #0x48
    3938:      	add	x2, sp, #0x7c
    393c:      	mov	x0, x24
    3940:      	blr	x8
    3944:      	cbz	w23, 0x3410 <do_action+0x3d0>
    3948:      	mov	w8, #0x1                // =1
    394c:      	add	x9, sp, #0x58
    3950:      	add	x1, sp, #0x58
    3954:      	mov	x0, x25
    3958:      	blr	x8
    395c:      	cbz	x0, 0x3410 <do_action+0x3d0>
    3960:      	ldr	w8, [sp, #0x78]
    3964:      	ldaxr	w9, [x0]
    3968:      	add	w9, w9, w8
    396c:      	stlxr	w10, w9, [x0]
    3970:      	cbnz	w10, 0x3964 <do_action+0x924>
    3974:      	b	0x3410 <do_action+0x3d0>

Disassembly of section fentry/generic_fentry_tail:

0000000000000000 <generic_fentry_setup_event>:
       0:      	sub	sp, sp, #0x90
       4:      	str	x29, [sp, #0x40]
       8:      	stp	x30, x25, [sp, #0x50]
       c:      	stp	x24, x23, [sp, #0x60]
      10:      	stp	x22, x21, [sp, #0x70]
      14:      	stp	x20, x19, [sp, #0x80]
      18:      	str	wzr, [sp, #0x48]
      1c:      	adrp	x20, 0x0 <generic_fentry_setup_event>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x48
      28:      	ldr	x20, [x20]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0x48
      34:      	mov	x0, x20
      38:      	blr	x8
      3c:      	cbz	x0, 0x368 <generic_fentry_setup_event+0x368>
      40:      	adrp	x21, 0x0 <generic_fentry_setup_event>
      44:      	mov	w8, #0x5ef8             // =24312
      48:      	mov	x22, x0
      4c:      	ldr	x21, [x21]
      50:      	add	x1, x0, x8
      54:      	mov	w8, #0x1                // =1
      58:      	mov	x0, x21
      5c:      	blr	x8
      60:      	cbz	x0, 0x368 <generic_fentry_setup_event+0x368>
      64:      	ldr	w8, [x0, #0x54]
      68:      	mov	x23, x0
      6c:      	cbz	w8, 0x128 <generic_fentry_setup_event+0x128>
      70:      	mov	w8, #0x8                // =8
      74:      	mov	w9, #0x4                // =4
      78:      	add	x10, sp, #0x18
      7c:      	add	x0, sp, #0x18
      80:      	mov	w1, #0x8                // =8
      84:      	mov	x2, x19
      88:      	blr	x9
      8c:      	ldr	x25, [sp, #0x18]
      90:      	cbz	x25, 0x368 <generic_fentry_setup_event+0x368>
      94:      	add	x2, x25, #0x110
      98:      	mov	w29, #0x8               // =8
      9c:      	add	x8, sp, #0x18
      a0:      	mov	w9, #0x4                // =4
      a4:      	add	x0, sp, #0x18
      a8:      	mov	w1, #0x8                // =8
      ac:      	mov	w24, #0x4               // =4
      b0:      	blr	x9
      b4:      	ldr	x8, [sp, #0x18]
      b8:      	add	x2, x25, #0x8
      bc:      	mov	w9, #0x4                // =4
      c0:      	add	x0, sp, #0x18
      c4:      	str	x8, [x22, #0x5e50]
      c8:      	add	x8, sp, #0x18
      cc:      	mov	w1, #0x8                // =8
      d0:      	blr	x9
      d4:      	ldr	x8, [sp, #0x18]
      d8:      	add	x2, x25, #0x10
      dc:      	mov	w9, #0x4                // =4
      e0:      	add	x0, sp, #0x18
      e4:      	str	x8, [x22, #0x5e58]
      e8:      	add	x8, sp, #0x18
      ec:      	mov	w1, #0x8                // =8
      f0:      	blr	x9
      f4:      	ldr	x8, [sp, #0x18]
      f8:      	add	x2, x25, #0x18
      fc:      	mov	w9, #0x4                // =4
     100:      	add	x0, sp, #0x18
     104:      	str	x8, [x22, #0x5e60]
     108:      	add	x8, sp, #0x18
     10c:      	mov	w1, #0x8                // =8
     110:      	blr	x9
     114:      	ldr	x8, [sp, #0x18]
     118:      	add	x2, x25, #0x20
     11c:      	str	x8, [x22, #0x5e68]
     120:      	add	x8, sp, #0x18
     124:      	b	0x1b8 <generic_fentry_setup_event+0x1b8>
     128:      	mov	w25, #0x8               // =8
     12c:      	add	x8, sp, #0x18
     130:      	mov	w9, #0x4                // =4
     134:      	add	x0, sp, #0x18
     138:      	mov	w1, #0x8                // =8
     13c:      	mov	x2, x19
     140:      	mov	w24, #0x4               // =4
     144:      	blr	x9
     148:      	ldr	x8, [sp, #0x18]
     14c:      	add	x2, x19, #0x8
     150:      	mov	w9, #0x4                // =4
     154:      	add	x0, sp, #0x18
     158:      	str	x8, [x22, #0x5e50]
     15c:      	add	x8, sp, #0x18
     160:      	mov	w1, #0x8                // =8
     164:      	blr	x9
     168:      	ldr	x8, [sp, #0x18]
     16c:      	add	x2, x19, #0x10
     170:      	mov	w9, #0x4                // =4
     174:      	add	x0, sp, #0x18
     178:      	str	x8, [x22, #0x5e58]
     17c:      	add	x8, sp, #0x18
     180:      	mov	w1, #0x8                // =8
     184:      	blr	x9
     188:      	ldr	x8, [sp, #0x18]
     18c:      	add	x2, x19, #0x18
     190:      	mov	w9, #0x4                // =4
     194:      	add	x0, sp, #0x18
     198:      	str	x8, [x22, #0x5e60]
     19c:      	add	x8, sp, #0x18
     1a0:      	mov	w1, #0x8                // =8
     1a4:      	blr	x9
     1a8:      	ldr	x8, [sp, #0x18]
     1ac:      	add	x2, x19, #0x20
     1b0:      	str	x8, [x22, #0x5e68]
     1b4:      	add	x8, sp, #0x18
     1b8:      	add	x0, sp, #0x18
     1bc:      	mov	w1, #0x8                // =8
     1c0:      	blr	x24
     1c4:      	ldr	x8, [sp, #0x18]
     1c8:      	strh	wzr, [x22, #0x2]
     1cc:      	str	wzr, [x22, #0x4]
     1d0:      	str	x8, [x22, #0x5e70]
     1d4:      	mov	w8, #0xd                // =13
     1d8:      	strb	w8, [x22]
     1dc:      	mov	w8, #0x7d               // =125
     1e0:      	blr	x8
     1e4:      	str	x0, [x22, #0x8]
     1e8:      	str	xzr, [x22, #0x70]
     1ec:      	mov	w8, #0xe                // =14
     1f0:      	mov	w24, #0xe               // =14
     1f4:      	str	wzr, [x22, #0x14]
     1f8:      	blr	x8
     1fc:      	str	w0, [x22, #0x7c]
     200:      	blr	x24
     204:      	cmn	x0, #0x16
     208:      	b.ne	0x22c <generic_fentry_setup_event+0x22c>
     20c:      	add	x2, x19, #0xe8
     210:      	mov	w8, #0x8                // =8
     214:      	mov	w9, #0x4                // =4
     218:      	add	x10, sp, #0x18
     21c:      	add	x0, sp, #0x18
     220:      	mov	w1, #0x8                // =8
     224:      	blr	x9
     228:      	ldr	x0, [sp, #0x18]
     22c:      	str	x0, [x22, #0x68]
     230:      	ldr	w8, [x23, #0x5c]
     234:      	cmp	w8, #0x1
     238:      	b.lt	0x2f0 <generic_fentry_setup_event+0x2f0>
     23c:      	ldr	x8, [x22, #0x60]
     240:      	ldr	x9, [x22, #0x8]
     244:      	mov	w10, #0x1               // =1
     248:      	mov	x3, xzr
     24c:      	add	x1, sp, #0x8
     250:      	add	x2, sp, #0x18
     254:      	str	xzr, [sp, #0x28]
     258:      	stp	x9, x10, [sp, #0x18]
     25c:      	stp	x8, x0, [sp, #0x8]
     260:      	adrp	x0, 0x0 <generic_fentry_setup_event>
     264:      	mov	w8, #0x2                // =2
     268:      	add	x9, sp, #0x8
     26c:      	add	x10, sp, #0x18
     270:      	ldr	x0, [x0]
     274:      	blr	x8
     278:      	cbz	x0, 0x2f0 <generic_fentry_setup_event+0x2f0>
     27c:      	neg	w8, w0
     280:      	adrp	x22, 0x0 <generic_fentry_setup_event>
     284:      	mov	w9, #0x1                // =1
     288:      	strh	w8, [sp, #0x34]
     28c:      	mov	w8, #0x5                // =5
     290:      	add	x1, sp, #0x34
     294:      	mov	w23, #0x1               // =1
     298:      	strh	w8, [sp, #0x36]
     29c:      	mov	x8, #0x46               // =70
     2a0:      	movk	x8, #0x2, lsl #32
     2a4:      	stur	x8, [sp, #0x38]
     2a8:      	add	x8, sp, #0x34
     2ac:      	ldr	x22, [x22]
     2b0:      	mov	x0, x22
     2b4:      	blr	x9
     2b8:      	cbz	x0, 0x2cc <generic_fentry_setup_event+0x2cc>
     2bc:      	ldr	w8, [x0]
     2c0:      	add	w8, w8, #0x1
     2c4:      	str	w8, [x0]
     2c8:      	b	0x2f0 <generic_fentry_setup_event+0x2f0>
     2cc:      	str	w23, [sp, #0x4c]
     2d0:      	mov	x3, xzr
     2d4:      	mov	w8, #0x2                // =2
     2d8:      	add	x9, sp, #0x34
     2dc:      	add	x10, sp, #0x4c
     2e0:      	add	x1, sp, #0x34
     2e4:      	add	x2, sp, #0x4c
     2e8:      	mov	x0, x22
     2ec:      	blr	x8
     2f0:      	str	wzr, [sp, #0x18]
     2f4:      	mov	w8, #0x1                // =1
     2f8:      	add	x9, sp, #0x18
     2fc:      	add	x1, sp, #0x18
     300:      	mov	x0, x20
     304:      	blr	x8
     308:      	adrp	x20, 0x0 <generic_fentry_setup_event>
     30c:      	ldr	x20, [x20]
     310:      	cbz	x0, 0x338 <generic_fentry_setup_event+0x338>
     314:      	mov	w8, #0x5ef8             // =24312
     318:      	add	x1, x0, x8
     31c:      	mov	w8, #0x1                // =1
     320:      	mov	x0, x21
     324:      	blr	x8
     328:      	cbz	x0, 0x338 <generic_fentry_setup_event+0x338>
     32c:      	ldr	w8, [x0, #0x40]
     330:      	cmn	w8, #0x1
     334:      	b.ne	0x350 <generic_fentry_setup_event+0x350>
     338:      	mov	w8, #0x3                // =3
     33c:      	mov	w9, #0xc                // =12
     340:      	mov	x0, x19
     344:      	mov	x1, x20
     348:      	mov	w2, #0x3                // =3
     34c:      	blr	x9
     350:      	mov	w8, #0x1                // =1
     354:      	mov	w9, #0xc                // =12
     358:      	mov	x0, x19
     35c:      	mov	x1, x20
     360:      	mov	w2, #0x1                // =1
     364:      	blr	x9
     368:      	ldp	x20, x19, [sp, #0x80]
     36c:      	mov	w0, wzr
     370:      	ldr	x29, [sp, #0x40]
     374:      	ldp	x22, x21, [sp, #0x70]
     378:      	ldp	x24, x23, [sp, #0x60]
     37c:      	ldp	x30, x25, [sp, #0x50]
     380:      	add	sp, sp, #0x90
     384:      	ret
     388:      	nop
     38c:      	nop

0000000000000390 <generic_fentry_process_event>:
     390:      	sub	sp, sp, #0x160
     394:      	str	x29, [sp, #0x110]
     398:      	stp	x30, x25, [sp, #0x120]
     39c:      	stp	x24, x23, [sp, #0x130]
     3a0:      	stp	x22, x21, [sp, #0x140]
     3a4:      	stp	x20, x19, [sp, #0x150]
     3a8:      	str	wzr, [sp, #0x5c]
     3ac:      	adrp	x25, 0x0 <generic_fentry_setup_event>
     3b0:      	mov	w8, #0x1                // =1
     3b4:      	add	x9, sp, #0x5c
     3b8:      	ldr	x25, [x25]
     3bc:      	mov	x19, x0
     3c0:      	add	x1, sp, #0x5c
     3c4:      	mov	x0, x25
     3c8:      	blr	x8
     3cc:      	cbz	x0, 0x1070 <generic_fentry_process_event+0xce0>
     3d0:      	ldr	w24, [x0, #0x4]
     3d4:      	mov	w21, #0x5efc            // =24316
     3d8:      	mov	x20, x0
     3dc:      	ldr	w23, [x0, x21]
     3e0:      	lsr	w8, w24, #3
     3e4:      	cmp	w8, #0x464
     3e8:      	b.hi	0x7d8 <generic_fentry_process_event+0x448>
     3ec:      	str	wzr, [sp, #0x68]
     3f0:      	mov	w8, #0x1                // =1
     3f4:      	add	x9, sp, #0x68
     3f8:      	add	x1, sp, #0x68
     3fc:      	mov	x0, x25
     400:      	blr	x8
     404:      	cbz	x0, 0x7d8 <generic_fentry_process_event+0x448>
     408:      	mov	w8, #0x5ef8             // =24312
     40c:      	mov	x22, x0
     410:      	add	x1, x0, x8
     414:      	adrp	x0, 0x0 <generic_fentry_setup_event>
     418:      	mov	w8, #0x1                // =1
     41c:      	ldr	x0, [x0]
     420:      	blr	x8
     424:      	cmp	w23, #0x4
     428:      	ccmp	x0, #0x0, #0x4, le
     42c:      	b.eq	0x7d8 <generic_fentry_process_event+0x448>
     430:      	and	x29, x23, #0x7
     434:      	str	x24, [sp, #0x118]
     438:      	str	x23, [sp, #0x50]
     43c:      	mov	w9, #0x5ea0             // =24224
     440:      	add	x8, x0, x29, lsl #2
     444:      	ldrsw	x24, [x8, #0x18]
     448:      	ldr	w23, [x8, #0x4]
     44c:      	add	x8, x22, x29, lsl #2
     450:      	add	x21, x8, x9
     454:      	str	wzr, [x21]
     458:      	and	x10, x24, #0xffffffff
     45c:      	str	x10, [sp, #0x40]
     460:      	tbnz	w24, #0x8, 0x484 <generic_fentry_process_event+0xf4>
     464:      	tbnz	w10, #0x7, 0x490 <generic_fentry_process_event+0x100>
     468:      	tbnz	w24, #0x6, 0x49c <generic_fentry_process_event+0x10c>
     46c:      	add	x8, x0, x29, lsl #2
     470:      	ldr	w8, [x8, #0x40]
     474:      	and	x8, x8, #0x7
     478:      	add	x8, x22, x8, lsl #3
     47c:      	ldr	x10, [x8, #0x5e50]
     480:      	b	0x4b0 <generic_fentry_process_event+0x120>
     484:      	mov	x10, xzr
     488:      	str	xzr, [sp, #0x60]
     48c:      	b	0x5b0 <generic_fentry_process_event+0x220>
     490:      	mov	x10, xzr
     494:      	str	xzr, [sp, #0x60]
     498:      	b	0x4b4 <generic_fentry_process_event+0x124>
     49c:      	mov	w8, #0x23               // =35
     4a0:      	mov	x22, x0
     4a4:      	blr	x8
     4a8:      	mov	x10, x0
     4ac:      	mov	x0, x22
     4b0:      	str	x10, [sp, #0x60]
     4b4:      	cmp	w29, #0x4
     4b8:      	b.hi	0x5b0 <generic_fentry_process_event+0x220>
     4bc:      	mov	w8, #0x50               // =80
     4c0:      	umaddl	x8, w29, w8, x0
     4c4:      	ldrh	w9, [x8, #0x76]
     4c8:      	cbz	w9, 0x5b0 <generic_fentry_process_event+0x220>
     4cc:      	add	x8, x8, #0x70
     4d0:      	add	x9, sp, #0x60
     4d4:      	strb	wzr, [sp, #0xa8]
     4d8:      	str	x21, [sp, #0xb0]
     4dc:      	stp	x8, x9, [sp, #0x98]
     4e0:      	adrp	x8, 0x0 <generic_fentry_setup_event>
     4e4:      	ldr	x8, [x8]
     4e8:      	ldrb	w8, [x8]
     4ec:      	cbz	w8, 0x580 <generic_fentry_process_event+0x1f0>
     4f0:      	mov	x25, xzr
     4f4:      	mov	w22, #0x1               // =1
     4f8:      	mov	w21, #0x8               // =8
     4fc:      	b	0x528 <generic_fentry_process_event+0x198>
     500:      	mov	w10, #0x4               // =4
     504:      	ldr	x0, [sp, #0xa0]
     508:      	mov	w1, #0x8                // =8
     50c:      	ldr	x2, [x0]
     510:      	blr	x10
     514:      	tbnz	w0, #0x1f, 0x574 <generic_fentry_process_event+0x1e4>
     518:      	add	x25, x25, #0x8
     51c:      	add	w22, w22, #0x1
     520:      	cmp	x25, #0x50
     524:      	b.eq	0x5a4 <generic_fentry_process_event+0x214>
     528:      	ldr	x8, [sp, #0x98]
     52c:      	add	x10, x8, x25
     530:      	ldrh	w8, [x10, #0x6]
     534:      	cbz	w8, 0x5a4 <generic_fentry_process_event+0x214>
     538:      	ldr	x8, [sp, #0xa0]
     53c:      	ldr	w11, [x10]
     540:      	ldr	x9, [x8]
     544:      	add	x9, x9, x11
     548:      	str	x9, [x8]
     54c:      	ldrh	w10, [x10, #0x4]
     550:      	cbz	w10, 0x518 <generic_fentry_process_event+0x188>
     554:      	ldrb	w10, [sp, #0xa8]
     558:      	cbz	w10, 0x500 <generic_fentry_process_event+0x170>
     55c:      	mov	w10, #0x94              // =148
     560:      	ldr	x0, [sp, #0xa0]
     564:      	mov	w1, #0x8                // =8
     568:      	ldr	x2, [x0]
     56c:      	blr	x10
     570:      	tbz	w0, #0x1f, 0x518 <generic_fentry_process_event+0x188>
     574:      	ldr	x8, [sp, #0xb0]
     578:      	str	w22, [x8]
     57c:      	b	0x5a4 <generic_fentry_process_event+0x214>
     580:      	mov	x3, xzr
     584:      	adrp	x1, 0x0 <generic_fentry_setup_event>
     588:      	add	x1, x1, #0x0
     58c:      	mov	w8, #0xa                // =10
     590:      	mov	w9, #0xb5               // =181
     594:      	add	x10, sp, #0x98
     598:      	add	x2, sp, #0x98
     59c:      	mov	w0, #0xa                // =10
     5a0:      	blr	x9
     5a4:      	adrp	x25, 0x0 <generic_fentry_setup_event>
     5a8:      	ldr	x10, [sp, #0x60]
     5ac:      	ldr	x25, [x25]
     5b0:      	mov	w22, #0x1000            // =4096
     5b4:      	cmp	w23, #0x15
     5b8:      	b.gt	0x5ec <generic_fentry_process_event+0x25c>
     5bc:      	cmp	w23, #0xb
     5c0:      	b.gt	0x61c <generic_fentry_process_event+0x28c>
     5c4:      	cmp	w23, #0x5
     5c8:      	b.gt	0x68c <generic_fentry_process_event+0x2fc>
     5cc:      	cmp	w23, #0x3
     5d0:      	b.gt	0x720 <generic_fentry_process_event+0x390>
     5d4:      	sub	w8, w23, #0x2
     5d8:      	cmp	w8, #0x2
     5dc:      	b.lo	0x6dc <generic_fentry_process_event+0x34c>
     5e0:      	cmp	w23, #0x1
     5e4:      	b.eq	0x6dc <generic_fentry_process_event+0x34c>
     5e8:      	b	0x758 <generic_fentry_process_event+0x3c8>
     5ec:      	cmp	w23, #0x20
     5f0:      	b.le	0x640 <generic_fentry_process_event+0x2b0>
     5f4:      	cmp	w23, #0x27
     5f8:      	b.gt	0x664 <generic_fentry_process_event+0x2d4>
     5fc:      	sub	w8, w23, #0x21
     600:      	cmp	w8, #0x4
     604:      	b.lo	0x738 <generic_fentry_process_event+0x3a8>
     608:      	cmp	w23, #0x25
     60c:      	b.eq	0x75c <generic_fentry_process_event+0x3cc>
     610:      	cmp	w23, #0x27
     614:      	b.eq	0x6e4 <generic_fentry_process_event+0x354>
     618:      	b	0x758 <generic_fentry_process_event+0x3c8>
     61c:      	cmp	w23, #0x11
     620:      	b.gt	0x6b0 <generic_fentry_process_event+0x320>
     624:      	sub	w8, w23, #0xf
     628:      	cmp	w8, #0x3
     62c:      	b.lo	0x75c <generic_fentry_process_event+0x3cc>
     630:      	sub	w8, w23, #0xc
     634:      	cmp	w8, #0x2
     638:      	b.lo	0x6dc <generic_fentry_process_event+0x34c>
     63c:      	b	0x758 <generic_fentry_process_event+0x3c8>
     640:      	cmp	w23, #0x1a
     644:      	b.gt	0x6d0 <generic_fentry_process_event+0x340>
     648:      	cmp	w23, #0x16
     64c:      	b.eq	0x6e4 <generic_fentry_process_event+0x354>
     650:      	cmp	w23, #0x17
     654:      	b.eq	0x738 <generic_fentry_process_event+0x3a8>
     658:      	cmp	w23, #0x1a
     65c:      	b.eq	0x750 <generic_fentry_process_event+0x3c0>
     660:      	b	0x758 <generic_fentry_process_event+0x3c8>
     664:      	cmp	w23, #0x29
     668:      	b.le	0x704 <generic_fentry_process_event+0x374>
     66c:      	cmp	w23, #0x2a
     670:      	b.eq	0x75c <generic_fentry_process_event+0x3cc>
     674:      	cmp	w23, #0x2b
     678:      	b.eq	0x718 <generic_fentry_process_event+0x388>
     67c:      	cmp	w23, #0x2c
     680:      	b.ne	0x758 <generic_fentry_process_event+0x3c8>
     684:      	mov	w22, #0x70              // =112
     688:      	b	0x75c <generic_fentry_process_event+0x3cc>
     68c:      	cmp	w23, #0x9
     690:      	b.gt	0x738 <generic_fentry_process_event+0x3a8>
     694:      	cmp	w23, #0x6
     698:      	b.eq	0x75c <generic_fentry_process_event+0x3cc>
     69c:      	cmp	w23, #0x7
     6a0:      	b.eq	0x730 <generic_fentry_process_event+0x3a0>
     6a4:      	cmp	w23, #0x8
     6a8:      	b.eq	0x750 <generic_fentry_process_event+0x3c0>
     6ac:      	b	0x758 <generic_fentry_process_event+0x3c8>
     6b0:      	cmp	w23, #0x13
     6b4:      	b.gt	0x6ec <generic_fentry_process_event+0x35c>
     6b8:      	cmp	w23, #0x12
     6bc:      	mov	x22, x24
     6c0:      	b.eq	0x75c <generic_fentry_process_event+0x3cc>
     6c4:      	cmp	w23, #0x13
     6c8:      	b.eq	0x718 <generic_fentry_process_event+0x388>
     6cc:      	b	0x758 <generic_fentry_process_event+0x3c8>
     6d0:      	sub	w8, w23, #0x1d
     6d4:      	cmp	w8, #0x4
     6d8:      	b.hs	0x748 <generic_fentry_process_event+0x3b8>
     6dc:      	mov	w22, #0x4               // =4
     6e0:      	b	0x75c <generic_fentry_process_event+0x3cc>
     6e4:      	mov	w22, #0x10              // =16
     6e8:      	b	0x75c <generic_fentry_process_event+0x3cc>
     6ec:      	cmp	w23, #0x14
     6f0:      	b.eq	0x740 <generic_fentry_process_event+0x3b0>
     6f4:      	cmp	w23, #0x15
     6f8:      	b.ne	0x758 <generic_fentry_process_event+0x3c8>
     6fc:      	mov	w22, #0x20              // =32
     700:      	b	0x75c <generic_fentry_process_event+0x3cc>
     704:      	cmp	w23, #0x28
     708:      	b.eq	0x718 <generic_fentry_process_event+0x388>
     70c:      	cmp	w23, #0x29
     710:      	b.eq	0x730 <generic_fentry_process_event+0x3a0>
     714:      	b	0x758 <generic_fentry_process_event+0x3c8>
     718:      	mov	w22, #0x18              // =24
     71c:      	b	0x75c <generic_fentry_process_event+0x3cc>
     720:      	cmp	w23, #0x4
     724:      	b.eq	0x738 <generic_fentry_process_event+0x3a8>
     728:      	cmp	w23, #0x5
     72c:      	b.ne	0x758 <generic_fentry_process_event+0x3c8>
     730:      	mov	w22, #0x40              // =64
     734:      	b	0x75c <generic_fentry_process_event+0x3cc>
     738:      	mov	w22, #0x8               // =8
     73c:      	b	0x75c <generic_fentry_process_event+0x3cc>
     740:      	mov	w22, #0x98              // =152
     744:      	b	0x75c <generic_fentry_process_event+0x3cc>
     748:      	cmp	w23, #0x1b
     74c:      	b.ne	0x758 <generic_fentry_process_event+0x3c8>
     750:      	mov	w22, #0x50              // =80
     754:      	b	0x75c <generic_fentry_process_event+0x3cc>
     758:      	mov	x22, xzr
     75c:      	str	x10, [sp, #0x48]
     760:      	str	wzr, [sp, #0x6c]
     764:      	mov	w8, #0x1                // =1
     768:      	add	x9, sp, #0x6c
     76c:      	add	x1, sp, #0x6c
     770:      	mov	x0, x25
     774:      	blr	x8
     778:      	cbz	x0, 0x7cc <generic_fentry_process_event+0x43c>
     77c:      	ldr	x9, [sp, #0x118]
     780:      	mov	w8, #0x3ffb             // =16379
     784:      	sub	x8, x8, x22
     788:      	cmp	x8, x9
     78c:      	b.ls	0x7cc <generic_fentry_process_event+0x43c>
     790:      	add	x22, x0, x29, lsl #2
     794:      	mov	w8, #0x5ea0             // =24224
     798:      	add	x21, x0, #0x90
     79c:      	ldr	w9, [x22, x8]
     7a0:      	ldr	x8, [sp, #0x118]
     7a4:      	add	x10, x0, x29, lsl #3
     7a8:      	str	w9, [x21, x8]
     7ac:      	add	x8, x8, #0x4
     7b0:      	str	x8, [x10, #0x5e78]
     7b4:      	cbz	w9, 0x85c <generic_fentry_process_event+0x4cc>
     7b8:      	ldr	x23, [sp, #0x50]
     7bc:      	ldr	x24, [sp, #0x118]
     7c0:      	mov	w8, #0x4                // =4
     7c4:      	mov	w21, #0x5efc            // =24316
     7c8:      	b	0x103c <generic_fentry_process_event+0xcac>
     7cc:      	ldr	x23, [sp, #0x50]
     7d0:      	ldr	x24, [sp, #0x118]
     7d4:      	mov	w21, #0x5efc            // =24316
     7d8:      	str	w24, [x20, #0x4]
     7dc:      	adrp	x22, 0x0 <generic_fentry_setup_event>
     7e0:      	cmp	w23, #0x3
     7e4:      	ldr	x22, [x22]
     7e8:      	b.gt	0x1054 <generic_fentry_process_event+0xcc4>
     7ec:      	str	wzr, [sp, #0x98]
     7f0:      	mov	w8, #0x1                // =1
     7f4:      	add	x9, sp, #0x98
     7f8:      	add	x1, sp, #0x98
     7fc:      	mov	x0, x25
     800:      	blr	x8
     804:      	cbz	x0, 0x1054 <generic_fentry_process_event+0xcc4>
     808:      	mov	w8, #0x5ef8             // =24312
     80c:      	add	x1, x0, x8
     810:      	adrp	x0, 0x0 <generic_fentry_setup_event>
     814:      	mov	w8, #0x1                // =1
     818:      	ldr	x0, [x0]
     81c:      	blr	x8
     820:      	cbz	x0, 0x1054 <generic_fentry_process_event+0xcc4>
     824:      	add	w8, w23, #0x1
     828:      	and	w9, w8, #0x7
     82c:      	add	x9, x0, w9, uxtw #2
     830:      	ldr	w9, [x9, #0x40]
     834:      	cmn	w9, #0x1
     838:      	b.eq	0x1054 <generic_fentry_process_event+0xcc4>
     83c:      	str	w8, [x20, x21]
     840:      	mov	w8, #0x1                // =1
     844:      	mov	w9, #0xc                // =12
     848:      	mov	x0, x19
     84c:      	mov	x1, x22
     850:      	mov	w2, #0x1                // =1
     854:      	blr	x9
     858:      	b	0x1054 <generic_fentry_process_event+0xcc4>
     85c:      	ldr	x10, [sp, #0x48]
     860:      	and	x29, x8, #0x3fff
     864:      	add	x9, sp, #0xe0
     868:      	cmp	w23, #0x17
     86c:      	str	xzr, [x9, #0x10]
     870:      	add	x8, x21, x29
     874:      	str	x8, [sp, #0x30]
     878:      	str	x10, [sp, #0x98]
     87c:      	b.le	0x8a8 <generic_fentry_process_event+0x518>
     880:      	cmp	w23, #0x18
     884:      	b.eq	0x8c8 <generic_fentry_process_event+0x538>
     888:      	cmp	w23, #0x25
     88c:      	b.eq	0x924 <generic_fentry_process_event+0x594>
     890:      	cmp	w23, #0x2a
     894:      	b.ne	0xe5c <generic_fentry_process_event+0xacc>
     898:      	add	x8, sp, #0x70
     89c:      	stp	xzr, x10, [sp, #0x70]
     8a0:      	str	x8, [sp, #0x38]
     8a4:      	b	0x98c <generic_fentry_process_event+0x5fc>
     8a8:      	cmp	w23, #0xf
     8ac:      	b.eq	0x95c <generic_fentry_process_event+0x5cc>
     8b0:      	cmp	w23, #0x10
     8b4:      	b.ne	0xe5c <generic_fentry_process_event+0xacc>
     8b8:      	mov	x23, x21
     8bc:      	add	x21, sp, #0x100
     8c0:      	add	x24, sp, #0xe0
     8c4:      	b	0x8f4 <generic_fentry_process_event+0x564>
     8c8:      	mov	x23, x21
     8cc:      	add	x21, sp, #0x100
     8d0:      	mov	w8, #0x8                // =8
     8d4:      	mov	w9, #0x4                // =4
     8d8:      	ldr	x2, [sp, #0x98]
     8dc:      	add	x0, sp, #0x100
     8e0:      	mov	w1, #0x8                // =8
     8e4:      	blr	x9
     8e8:      	add	x24, sp, #0xe0
     8ec:      	ldr	x8, [x24, #0x20]
     8f0:      	str	x8, [sp, #0x98]
     8f4:      	mov	w8, #0x8                // =8
     8f8:      	mov	w9, #0x4                // =4
     8fc:      	add	x10, sp, #0x98
     900:      	add	x0, sp, #0x100
     904:      	add	x2, sp, #0x98
     908:      	mov	w1, #0x8                // =8
     90c:      	blr	x9
     910:      	ldr	x8, [x24, #0x20]
     914:      	mov	x21, x23
     918:      	add	x8, x8, #0x40
     91c:      	str	x8, [sp, #0x38]
     920:      	b	0x98c <generic_fentry_process_event+0x5fc>
     924:      	add	x8, x10, #0x40
     928:      	mov	w9, #0x8                // =8
     92c:      	mov	w10, #0x4               // =4
     930:      	str	x8, [sp, #0x98]
     934:      	add	x11, sp, #0x100
     938:      	add	x0, sp, #0x100
     93c:      	mov	w1, #0x8                // =8
     940:      	ldr	x2, [sp, #0x98]
     944:      	blr	x10
     948:      	add	x8, sp, #0xe0
     94c:      	ldr	x8, [x8, #0x20]
     950:      	add	x8, x8, #0x40
     954:      	str	x8, [sp, #0x38]
     958:      	b	0x98c <generic_fentry_process_event+0x5fc>
     95c:      	mov	w8, #0x8                // =8
     960:      	mov	w9, #0x4                // =4
     964:      	add	x10, sp, #0xf0
     968:      	add	x11, sp, #0x98
     96c:      	add	x0, sp, #0xf0
     970:      	add	x2, sp, #0x98
     974:      	mov	w1, #0x8                // =8
     978:      	blr	x9
     97c:      	add	x8, sp, #0xe0
     980:      	ldr	x8, [x8, #0x10]
     984:      	str	x8, [sp, #0x38]
     988:      	cbz	x8, 0x1090 <generic_fentry_process_event+0xd00>
     98c:      	str	wzr, [sp, #0x84]
     990:      	adrp	x0, 0x0 <generic_fentry_setup_event>
     994:      	mov	w8, #0x1                // =1
     998:      	add	x9, sp, #0x84
     99c:      	ldr	x0, [x0]
     9a0:      	add	x1, sp, #0x84
     9a4:      	blr	x8
     9a8:      	cbz	x0, 0xf58 <generic_fentry_process_event+0xbc8>
     9ac:      	add	x8, x0, #0x1, lsl #12   // =0x1000
     9b0:      	stp	x21, x22, [sp, #0x18]
     9b4:      	mov	x24, x0
     9b8:      	str	x8, [sp, #0x40]
     9bc:      	mov	w8, #0x23               // =35
     9c0:      	blr	x8
     9c4:      	add	x2, x0, #0xb30
     9c8:      	mov	w23, #0x8               // =8
     9cc:      	add	x8, sp, #0x88
     9d0:      	mov	w9, #0x4                // =4
     9d4:      	add	x0, sp, #0x88
     9d8:      	mov	w1, #0x8                // =8
     9dc:      	mov	w25, #0x4               // =4
     9e0:      	blr	x9
     9e4:      	ldr	x8, [sp, #0x88]
     9e8:      	mov	w9, #0x4                // =4
     9ec:      	add	x0, sp, #0x90
     9f0:      	mov	w1, #0x8                // =8
     9f4:      	str	x8, [sp, #0x10]
     9f8:      	add	x8, x8, #0x18
     9fc:      	str	x8, [sp, #0x48]
     a00:      	ldr	x8, [sp, #0x38]
     a04:      	add	x2, x8, #0x8
     a08:      	add	x8, sp, #0x90
     a0c:      	str	x2, [sp, #0x28]
     a10:      	blr	x9
     a14:      	ldr	x21, [sp, #0x90]
     a18:      	add	x22, sp, #0x98
     a1c:      	add	x0, sp, #0x98
     a20:      	mov	w1, #0x8                // =8
     a24:      	add	x2, x21, #0x10
     a28:      	blr	x25
     a2c:      	ldr	x8, [sp, #0x98]
     a30:      	cbz	x8, 0xa40 <generic_fentry_process_event+0x6b0>
     a34:      	ldr	x9, [sp, #0x40]
     a38:      	mov	w8, #0x1000             // =4096
     a3c:      	b	0xa88 <generic_fentry_process_event+0x6f8>
     a40:      	add	x2, x21, #0x18
     a44:      	mov	w8, #0x8                // =8
     a48:      	mov	w9, #0x4                // =4
     a4c:      	add	x10, sp, #0x98
     a50:      	add	x0, sp, #0x98
     a54:      	mov	w1, #0x8                // =8
     a58:      	blr	x9
     a5c:      	ldr	x8, [sp, #0x98]
     a60:      	cmp	x8, x21
     a64:      	b.eq	0xa34 <generic_fentry_process_event+0x6a4>
     a68:      	mov	w8, #0x2964             // =10596
     a6c:      	add	x9, x24, #0xff6
     a70:      	strh	w8, [x24, #0xffe]
     a74:      	adrp	x8, 0x0 <generic_fentry_setup_event>
     a78:      	add	x8, x8, #0x0
     a7c:      	ldr	x8, [x8]
     a80:      	str	x8, [x9]
     a84:      	mov	w8, #0xff6              // =4086
     a88:      	str	x9, [sp, #0x40]
     a8c:      	str	x9, [sp, #0xc8]
     a90:      	ldr	x9, [sp, #0x10]
     a94:      	mov	w21, #0x8               // =8
     a98:      	add	x0, sp, #0x98
     a9c:      	mov	w1, #0x8                // =8
     aa0:      	stp	xzr, xzr, [sp, #0x98]
     aa4:      	add	x23, x22, #0x8
     aa8:      	add	x29, x22, #0x18
     aac:      	mov	w25, #0x4               // =4
     ab0:      	add	x2, x9, #0x20
     ab4:      	stp	x24, xzr, [sp, #0xa8]
     ab8:      	stp	xzr, xzr, [sp, #0xb8]
     abc:      	str	w8, [sp, #0xd0]
     ac0:      	mov	w8, #0x4                // =4
     ac4:      	add	x24, x22, #0x20
     ac8:      	strb	wzr, [sp, #0xd4]
     acc:      	blr	x8
     ad0:      	ldr	x2, [sp, #0x48]
     ad4:      	mov	w8, #0x4                // =4
     ad8:      	mov	x0, x23
     adc:      	mov	w1, #0x8                // =8
     ae0:      	blr	x8
     ae4:      	ldr	x2, [sp, #0x28]
     ae8:      	mov	w8, #0x4                // =4
     aec:      	mov	x0, x29
     af0:      	mov	w1, #0x8                // =8
     af4:      	str	x29, [sp, #0x48]
     af8:      	blr	x8
     afc:      	ldr	x2, [sp, #0x38]
     b00:      	mov	x0, x24
     b04:      	mov	w1, #0x8                // =8
     b08:      	blr	x25
     b0c:      	ldr	x8, [sp, #0xb8]
     b10:      	sub	x8, x8, #0x20
     b14:      	str	x8, [sp, #0xc0]
     b18:      	adrp	x8, 0x0 <generic_fentry_setup_event>
     b1c:      	ldr	x8, [x8]
     b20:      	ldrb	w8, [x8]
     b24:      	cbz	w8, 0xcc8 <generic_fentry_process_event+0x938>
     b28:      	mov	w23, #0x800             // =2048
     b2c:      	mov	w24, #0x8               // =8
     b30:      	add	x22, sp, #0xe0
     b34:      	ldp	x21, x2, [sp, #0xb0]
     b38:      	ldp	x8, x9, [sp, #0x98]
     b3c:      	cmp	x21, x8
     b40:      	ccmp	x2, x9, #0x0, eq
     b44:      	b.eq	0xef8 <generic_fentry_process_event+0xb68>
     b48:      	ldr	x25, [sp, #0xc0]
     b4c:      	mov	w8, #0x4                // =4
     b50:      	add	x9, sp, #0xe0
     b54:      	add	x0, sp, #0xe0
     b58:      	mov	w1, #0x8                // =8
     b5c:      	blr	x8
     b60:      	ldr	x8, [x22]
     b64:      	add	x29, sp, #0xe0
     b68:      	cmp	x21, x8
     b6c:      	b.eq	0xc68 <generic_fentry_process_event+0x8d8>
     b70:      	add	x22, x21, #0x18
     b74:      	mov	w8, #0x4                // =4
     b78:      	add	x9, sp, #0x100
     b7c:      	add	x0, sp, #0x100
     b80:      	mov	w1, #0x8                // =8
     b84:      	mov	x2, x22
     b88:      	blr	x8
     b8c:      	ldr	x8, [x29, #0x20]
     b90:      	cmp	x8, x21
     b94:      	b.eq	0xc68 <generic_fentry_process_event+0x8d8>
     b98:      	mov	w8, #0x4                // =4
     b9c:      	add	x9, sp, #0xe8
     ba0:      	add	x0, sp, #0xe8
     ba4:      	mov	w1, #0x8                // =8
     ba8:      	mov	x2, x22
     bac:      	blr	x8
     bb0:      	add	x2, x21, #0x20
     bb4:      	mov	w8, #0x4                // =4
     bb8:      	mov	w9, #0x10               // =16
     bbc:      	add	x10, sp, #0xf0
     bc0:      	add	x0, sp, #0xf0
     bc4:      	mov	w1, #0x10               // =16
     bc8:      	blr	x8
     bcc:      	ldr	w21, [sp, #0xf4]
     bd0:      	ldr	x8, [sp, #0xa8]
     bd4:      	ldr	x10, [sp, #0xc8]
     bd8:      	sub	x12, x10, x8
     bdc:      	ldr	w22, [sp, #0xd0]
     be0:      	subs	w10, w21, w22
     be4:      	ldr	x9, [x29, #0x18]
     be8:      	csel	w10, wzr, w10, lo
     bec:      	cmp	w22, w21
     bf0:      	csel	w11, w22, w21, lo
     bf4:      	cinc	w13, w11, hi
     bf8:      	sub	w14, w22, w13
     bfc:      	subs	x12, x12, x13
     c00:      	str	w14, [sp, #0xd0]
     c04:      	b.lo	0xf00 <generic_fentry_process_event+0xb70>
     c08:      	cmp	x12, #0xfff
     c0c:      	b.hi	0xf00 <generic_fentry_process_event+0xb70>
     c10:      	cmp	w22, w21
     c14:      	b.ls	0xc20 <generic_fentry_process_event+0x890>
     c18:      	mov	w13, #0x2f              // =47
     c1c:      	strb	w13, [x8, x12]
     c20:      	add	x25, x8, x12
     c24:      	cmp	w22, w21
     c28:      	add	x2, x9, x10
     c2c:      	and	w1, w11, #0xff
     c30:      	mov	w8, #0x4                // =4
     c34:      	cinc	x0, x25, hi
     c38:      	blr	x8
     c3c:      	cmp	w22, w21
     c40:      	str	x25, [sp, #0xc8]
     c44:      	b.ls	0xf00 <generic_fentry_process_event+0xb70>
     c48:      	add	x22, sp, #0xe0
     c4c:      	ldr	x8, [x22, #0x8]
     c50:      	str	x8, [sp, #0xb0]
     c54:      	adrp	x25, 0x0 <generic_fentry_setup_event>
     c58:      	subs	w23, w23, #0x1
     c5c:      	ldr	x25, [x25]
     c60:      	b.ne	0xb34 <generic_fentry_process_event+0x7a4>
     c64:      	b	0xf18 <generic_fentry_process_event+0xb88>
     c68:      	add	x2, x25, #0x10
     c6c:      	mov	w8, #0x4                // =4
     c70:      	add	x9, sp, #0x100
     c74:      	add	x0, sp, #0x100
     c78:      	mov	w1, #0x8                // =8
     c7c:      	blr	x8
     c80:      	ldr	x8, [sp, #0xc0]
     c84:      	ldr	x9, [x29, #0x20]
     c88:      	add	x22, sp, #0xe0
     c8c:      	cmp	x8, x9
     c90:      	b.eq	0xf08 <generic_fentry_process_event+0xb78>
     c94:      	ldr	x0, [sp, #0x48]
     c98:      	add	x2, x25, #0x18
     c9c:      	mov	w8, #0x4                // =4
     ca0:      	mov	w1, #0x8                // =8
     ca4:      	blr	x8
     ca8:      	ldr	x8, [x22, #0x20]
     cac:      	add	x9, x8, #0x20
     cb0:      	stp	x9, x8, [sp, #0xb8]
     cb4:      	adrp	x25, 0x0 <generic_fentry_setup_event>
     cb8:      	subs	w23, w23, #0x1
     cbc:      	ldr	x25, [x25]
     cc0:      	b.ne	0xb34 <generic_fentry_process_event+0x7a4>
     cc4:      	b	0xf18 <generic_fentry_process_event+0xb88>
     cc8:      	mov	w23, #0x800             // =2048
     ccc:      	mov	w24, #0x8               // =8
     cd0:      	add	x22, sp, #0xe0
     cd4:      	b	0xce8 <generic_fentry_process_event+0x958>
     cd8:      	adrp	x25, 0x0 <generic_fentry_setup_event>
     cdc:      	subs	w23, w23, #0x1
     ce0:      	ldr	x25, [x25]
     ce4:      	b.eq	0xf18 <generic_fentry_process_event+0xb88>
     ce8:      	ldp	x21, x2, [sp, #0xb0]
     cec:      	ldp	x8, x9, [sp, #0x98]
     cf0:      	cmp	x21, x8
     cf4:      	ccmp	x2, x9, #0x0, eq
     cf8:      	b.eq	0xef8 <generic_fentry_process_event+0xb68>
     cfc:      	ldr	x25, [sp, #0xc0]
     d00:      	mov	w8, #0x4                // =4
     d04:      	add	x9, sp, #0xe0
     d08:      	add	x0, sp, #0xe0
     d0c:      	mov	w1, #0x8                // =8
     d10:      	blr	x8
     d14:      	ldr	x8, [x22]
     d18:      	add	x29, sp, #0xe0
     d1c:      	cmp	x21, x8
     d20:      	b.eq	0xe0c <generic_fentry_process_event+0xa7c>
     d24:      	add	x22, x21, #0x18
     d28:      	mov	w8, #0x4                // =4
     d2c:      	add	x9, sp, #0x100
     d30:      	add	x0, sp, #0x100
     d34:      	mov	w1, #0x8                // =8
     d38:      	mov	x2, x22
     d3c:      	blr	x8
     d40:      	ldr	x8, [x29, #0x20]
     d44:      	cmp	x8, x21
     d48:      	b.eq	0xe0c <generic_fentry_process_event+0xa7c>
     d4c:      	mov	w8, #0x4                // =4
     d50:      	add	x9, sp, #0xe8
     d54:      	add	x0, sp, #0xe8
     d58:      	mov	w1, #0x8                // =8
     d5c:      	mov	x2, x22
     d60:      	blr	x8
     d64:      	add	x2, x21, #0x20
     d68:      	mov	w8, #0x4                // =4
     d6c:      	mov	w9, #0x10               // =16
     d70:      	add	x10, sp, #0xf0
     d74:      	add	x0, sp, #0xf0
     d78:      	mov	w1, #0x10               // =16
     d7c:      	blr	x8
     d80:      	ldr	w21, [sp, #0xf4]
     d84:      	ldr	x8, [sp, #0xa8]
     d88:      	ldr	x10, [sp, #0xc8]
     d8c:      	sub	x12, x10, x8
     d90:      	ldr	w22, [sp, #0xd0]
     d94:      	subs	w10, w21, w22
     d98:      	ldr	x9, [x29, #0x18]
     d9c:      	csel	w10, wzr, w10, lo
     da0:      	cmp	w22, w21
     da4:      	csel	w11, w22, w21, lo
     da8:      	cinc	w13, w11, hi
     dac:      	sub	w14, w22, w13
     db0:      	subs	x12, x12, x13
     db4:      	str	w14, [sp, #0xd0]
     db8:      	b.lo	0xf00 <generic_fentry_process_event+0xb70>
     dbc:      	cmp	x12, #0xfff
     dc0:      	b.hi	0xf00 <generic_fentry_process_event+0xb70>
     dc4:      	cmp	w22, w21
     dc8:      	b.ls	0xdd4 <generic_fentry_process_event+0xa44>
     dcc:      	mov	w13, #0x2f              // =47
     dd0:      	strb	w13, [x8, x12]
     dd4:      	add	x25, x8, x12
     dd8:      	cmp	w22, w21
     ddc:      	add	x2, x9, x10
     de0:      	and	w1, w11, #0xff
     de4:      	mov	w8, #0x4                // =4
     de8:      	cinc	x0, x25, hi
     dec:      	blr	x8
     df0:      	cmp	w22, w21
     df4:      	str	x25, [sp, #0xc8]
     df8:      	b.ls	0xf00 <generic_fentry_process_event+0xb70>
     dfc:      	add	x22, sp, #0xe0
     e00:      	ldr	x8, [x22, #0x8]
     e04:      	str	x8, [sp, #0xb0]
     e08:      	b	0xcd8 <generic_fentry_process_event+0x948>
     e0c:      	add	x2, x25, #0x10
     e10:      	mov	w8, #0x4                // =4
     e14:      	add	x9, sp, #0x100
     e18:      	add	x0, sp, #0x100
     e1c:      	mov	w1, #0x8                // =8
     e20:      	blr	x8
     e24:      	ldr	x8, [sp, #0xc0]
     e28:      	ldr	x9, [x29, #0x20]
     e2c:      	add	x22, sp, #0xe0
     e30:      	cmp	x8, x9
     e34:      	b.eq	0xf08 <generic_fentry_process_event+0xb78>
     e38:      	ldr	x0, [sp, #0x48]
     e3c:      	add	x2, x25, #0x18
     e40:      	mov	w8, #0x4                // =4
     e44:      	mov	w1, #0x8                // =8
     e48:      	blr	x8
     e4c:      	ldr	x8, [x22, #0x20]
     e50:      	add	x9, x8, #0x20
     e54:      	stp	x9, x8, [sp, #0xb8]
     e58:      	b	0xcd8 <generic_fentry_process_event+0x948>
     e5c:      	cmp	w23, #0x2c
     e60:      	b.hi	0x1090 <generic_fentry_process_event+0xd00>
     e64:      	mov	x9, #0x7cf2             // =31986
     e68:      	mov	w8, #0x1                // =1
     e6c:      	movk	x9, #0xf202, lsl #16
     e70:      	lsl	x8, x8, x23
     e74:      	movk	x9, #0x11c1, lsl #32
     e78:      	tst	x8, x9
     e7c:      	b.eq	0x1090 <generic_fentry_process_event+0xd00>
     e80:      	add	x8, sp, #0xe0
     e84:      	str	x22, [sp, #0x20]
     e88:      	str	wzr, [sp, #0x88]
     e8c:      	add	x9, sp, #0x88
     e90:      	add	x1, sp, #0x88
     e94:      	mov	x0, x25
     e98:      	str	x10, [x8]
     e9c:      	mov	w8, #0x1                // =1
     ea0:      	blr	x8
     ea4:      	mov	x22, xzr
     ea8:      	str	x21, [sp, #0x18]
     eac:      	cbz	x0, 0x1008 <generic_fentry_process_event+0xc78>
     eb0:      	cmp	w23, #0x10
     eb4:      	b.le	0x10fc <generic_fentry_process_event+0xd6c>
     eb8:      	cmp	w23, #0x1e
     ebc:      	b.le	0x120c <generic_fentry_process_event+0xe7c>
     ec0:      	cmp	w23, #0x26
     ec4:      	b.gt	0x12dc <generic_fentry_process_event+0xf4c>
     ec8:      	sub	w8, w23, #0x1f
     ecc:      	cmp	w8, #0x2
     ed0:      	b.hs	0x16b4 <generic_fentry_process_event+0x1324>
     ed4:      	ldr	x0, [sp, #0x30]
     ed8:      	mov	w8, #0x1                // =1
     edc:      	add	x9, sp, #0xe0
     ee0:      	mov	w10, #0x4               // =4
     ee4:      	add	x2, sp, #0xe0
     ee8:      	mov	w1, #0x1                // =1
     eec:      	mov	w22, #0x4               // =4
     ef0:      	blr	x10
     ef4:      	b	0x1008 <generic_fentry_process_event+0xc78>
     ef8:      	mov	w8, #0x1                // =1
     efc:      	strb	w8, [sp, #0xd4]
     f00:      	adrp	x25, 0x0 <generic_fentry_setup_event>
     f04:      	b	0xf14 <generic_fentry_process_event+0xb84>
     f08:      	mov	w8, #0x1                // =1
     f0c:      	adrp	x25, 0x0 <generic_fentry_setup_event>
     f10:      	strb	w8, [sp, #0xd4]
     f14:      	ldr	x25, [x25]
     f18:      	ldr	x8, [sp, #0xc8]
     f1c:      	ldr	x2, [sp, #0x40]
     f20:      	cmp	x8, x2
     f24:      	b.eq	0xf6c <generic_fentry_process_event+0xbdc>
     f28:      	ldrb	w9, [sp, #0xd4]
     f2c:      	mov	w11, #0x1000            // =4096
     f30:      	cmp	w9, #0x0
     f34:      	ldr	w9, [sp, #0xd0]
     f38:      	cset	w10, eq
     f3c:      	sub	w11, w11, w9
     f40:      	cmp	w9, #0x0
     f44:      	csel	w9, w11, w9, gt
     f48:      	cbz	x8, 0xf58 <generic_fentry_process_event+0xbc8>
     f4c:      	lsl	w21, w10, #1
     f50:      	mov	x2, x8
     f54:      	b	0xf74 <generic_fentry_process_event+0xbe4>
     f58:      	ldr	x23, [sp, #0x50]
     f5c:      	ldr	x24, [sp, #0x118]
     f60:      	mov	x22, xzr
     f64:      	mov	w21, #0x5efc            // =24316
     f68:      	b	0x1018 <generic_fentry_process_event+0xc88>
     f6c:      	mov	w21, wzr
     f70:      	mov	w9, wzr
     f74:      	ldr	x29, [sp, #0x30]
     f78:      	and	w22, w9, #0xfff
     f7c:      	mov	w8, #0x4                // =4
     f80:      	mov	w23, #0x4               // =4
     f84:      	mov	w1, w22
     f88:      	add	x0, x29, #0x4
     f8c:      	blr	x8
     f90:      	str	w22, [x29]
     f94:      	ldr	x2, [sp, #0x28]
     f98:      	mov	w24, #0x8               // =8
     f9c:      	add	x8, sp, #0x98
     fa0:      	mov	w9, #0x4                // =4
     fa4:      	add	x0, sp, #0x98
     fa8:      	mov	w1, #0x8                // =8
     fac:      	blr	x9
     fb0:      	ldr	x8, [sp, #0x98]
     fb4:      	add	x9, sp, #0xf0
     fb8:      	mov	w10, #0x4               // =4
     fbc:      	add	x0, sp, #0xf0
     fc0:      	mov	w1, #0x8                // =8
     fc4:      	add	x8, x8, #0x30
     fc8:      	ldr	x8, [sp, #0x98]
     fcc:      	add	x2, x8, #0x30
     fd0:      	blr	x10
     fd4:      	add	x11, sp, #0xe0
     fd8:      	mov	w9, #0x2                // =2
     fdc:      	add	x10, sp, #0x100
     fe0:      	ldr	x8, [x11, #0x10]
     fe4:      	add	x0, sp, #0x100
     fe8:      	mov	w1, #0x2                // =2
     fec:      	ldr	x2, [x11, #0x10]
     ff0:      	blr	x23
     ff4:      	add	x8, x29, x22
     ff8:      	add	w22, w22, #0xa
     ffc:      	str	w21, [x8, #0x4]
    1000:      	ldrh	w9, [sp, #0x100]
    1004:      	strh	w9, [x8, #0x8]
    1008:      	ldr	x23, [sp, #0x50]
    100c:      	ldr	x24, [sp, #0x118]
    1010:      	mov	w21, #0x5efc            // =24316
    1014:      	tbnz	w22, #0x1f, 0x1024 <generic_fentry_process_event+0xc94>
    1018:      	and	w8, w22, #0x7fffffff
    101c:      	add	w8, w8, #0x4
    1020:      	b	0x103c <generic_fentry_process_event+0xcac>
    1024:      	ldp	x9, x11, [sp, #0x18]
    1028:      	mov	w8, #-0x1               // =-1
    102c:      	mov	w10, #0x5ea0            // =24224
    1030:      	str	w8, [x11, x10]
    1034:      	str	w8, [x9, x24]
    1038:      	mov	w8, #0x4                // =4
    103c:      	add	w24, w8, w24
    1040:      	str	w24, [x20, #0x4]
    1044:      	adrp	x22, 0x1000 <generic_fentry_process_event+0xc70>
    1048:      	cmp	w23, #0x3
    104c:      	ldr	x22, [x22]
    1050:      	b.le	0x7ec <generic_fentry_process_event+0x45c>
    1054:      	str	wzr, [x20, x21]
    1058:      	mov	w8, #0x3                // =3
    105c:      	mov	w9, #0xc                // =12
    1060:      	mov	x0, x19
    1064:      	mov	x1, x22
    1068:      	mov	w2, #0x3                // =3
    106c:      	blr	x9
    1070:      	ldp	x20, x19, [sp, #0x150]
    1074:      	mov	w0, wzr
    1078:      	ldr	x29, [sp, #0x110]
    107c:      	ldp	x22, x21, [sp, #0x140]
    1080:      	ldp	x24, x23, [sp, #0x130]
    1084:      	ldp	x30, x25, [sp, #0x120]
    1088:      	add	sp, sp, #0x160
    108c:      	ret
    1090:      	str	x22, [sp, #0x20]
    1094:      	str	wzr, [sp, #0x88]
    1098:      	mov	w8, #0x1                // =1
    109c:      	add	x9, sp, #0x88
    10a0:      	add	x1, sp, #0x88
    10a4:      	mov	x0, x25
    10a8:      	blr	x8
    10ac:      	mov	x22, xzr
    10b0:      	str	x21, [sp, #0x18]
    10b4:      	cbz	x0, 0x1008 <generic_fentry_process_event+0xc78>
    10b8:      	cmp	w23, #0x19
    10bc:      	b.gt	0x12b4 <generic_fentry_process_event+0xf24>
    10c0:      	cmp	w23, #0x12
    10c4:      	b.le	0x13a0 <generic_fentry_process_event+0x1010>
    10c8:      	cmp	w23, #0x14
    10cc:      	b.le	0x1618 <generic_fentry_process_event+0x1288>
    10d0:      	cmp	w23, #0x15
    10d4:      	b.eq	0x1d38 <generic_fentry_process_event+0x19a8>
    10d8:      	cmp	w23, #0x16
    10dc:      	b.eq	0x1cd8 <generic_fentry_process_event+0x1948>
    10e0:      	ldr	x9, [sp, #0x48]
    10e4:      	cmp	w23, #0x17
    10e8:      	b.ne	0x1008 <generic_fentry_process_event+0xc78>
    10ec:      	ldr	x8, [sp, #0x30]
    10f0:      	mov	w22, #0x8               // =8
    10f4:      	stp	w9, wzr, [x8]
    10f8:      	b	0x1008 <generic_fentry_process_event+0xc78>
    10fc:      	cmp	w23, #0x9
    1100:      	b.gt	0x1238 <generic_fentry_process_event+0xea8>
    1104:      	cmp	w23, #0x4
    1108:      	b.le	0x1418 <generic_fentry_process_event+0x1088>
    110c:      	cmp	w23, #0x5
    1110:      	b.eq	0x18f8 <generic_fentry_process_event+0x1568>
    1114:      	ldr	x21, [sp, #0x30]
    1118:      	cmp	w23, #0x6
    111c:      	b.eq	0x1298 <generic_fentry_process_event+0xf08>
    1120:      	cmp	w23, #0x7
    1124:      	b.ne	0x1008 <generic_fentry_process_event+0xc78>
    1128:      	add	x8, sp, #0xe0
    112c:      	mov	x24, x0
    1130:      	add	x0, x21, #0x26
    1134:      	ldr	x23, [x8]
    1138:      	mov	w22, #0x2               // =2
    113c:      	mov	w8, #0x4                // =4
    1140:      	mov	w1, #0x2                // =2
    1144:      	mov	x25, x21
    1148:      	str	x23, [x21, #0x28]
    114c:      	add	x2, x23, #0x10
    1150:      	mov	w21, #0x4               // =4
    1154:      	blr	x8
    1158:      	add	x0, x25, #0x3a
    115c:      	add	x2, x23, #0x12
    1160:      	mov	w8, #0x1                // =1
    1164:      	mov	w9, #0x4                // =4
    1168:      	mov	w1, #0x1                // =1
    116c:      	blr	x9
    1170:      	add	x0, x25, #0x38
    1174:      	add	x2, x23, #0x21e
    1178:      	mov	w8, #0x4                // =4
    117c:      	mov	w1, #0x2                // =2
    1180:      	blr	x8
    1184:      	add	x0, x25, #0x24
    1188:      	add	x2, x23, #0x21c
    118c:      	mov	w8, #0x4                // =4
    1190:      	mov	w1, #0x2                // =2
    1194:      	blr	x8
    1198:      	add	x0, x25, #0x30
    119c:      	add	x2, x23, #0x214
    11a0:      	mov	w8, #0x4                // =4
    11a4:      	mov	w1, #0x4                // =4
    11a8:      	blr	x8
    11ac:      	add	x0, x25, #0x34
    11b0:      	add	x2, x23, #0x210
    11b4:      	mov	w1, #0x4                // =4
    11b8:      	blr	x21
    11bc:      	ldrh	w8, [x25, #0x26]
    11c0:      	mov	x22, x25
    11c4:      	stp	xzr, xzr, [x25]
    11c8:      	cmp	w8, #0xa
    11cc:      	str	xzr, [x25, #0x18]
    11d0:      	str	xzr, [x22, #0x10]!
    11d4:      	b.eq	0x2118 <generic_fentry_process_event+0x1d88>
    11d8:      	cmp	w8, #0x2
    11dc:      	b.ne	0x2144 <generic_fentry_process_event+0x1db4>
    11e0:      	ldr	x0, [sp, #0x30]
    11e4:      	add	x2, x23, #0x4
    11e8:      	mov	w8, #0x4                // =4
    11ec:      	mov	w1, #0x4                // =4
    11f0:      	mov	w21, #0x4               // =4
    11f4:      	blr	x8
    11f8:      	mov	x0, x22
    11fc:      	mov	w1, #0x4                // =4
    1200:      	mov	x2, x23
    1204:      	blr	x21
    1208:      	b	0x2144 <generic_fentry_process_event+0x1db4>
    120c:      	cmp	w23, #0x1c
    1210:      	b.gt	0x13f4 <generic_fentry_process_event+0x1064>
    1214:      	cmp	w23, #0x11
    1218:      	b.eq	0x16e4 <generic_fentry_process_event+0x1354>
    121c:      	cmp	w23, #0x19
    1220:      	str	x0, [sp, #0x48]
    1224:      	b.eq	0x17a0 <generic_fentry_process_event+0x1410>
    1228:      	ldr	x0, [sp, #0x30]
    122c:      	cmp	w23, #0x1c
    1230:      	b.eq	0x142c <generic_fentry_process_event+0x109c>
    1234:      	b	0x1008 <generic_fentry_process_event+0xc78>
    1238:      	ldr	x0, [sp, #0x30]
    123c:      	sub	w8, w23, #0xa
    1240:      	cmp	w8, #0x2
    1244:      	b.lo	0x142c <generic_fentry_process_event+0x109c>
    1248:      	sub	w8, w23, #0xc
    124c:      	cmp	w8, #0x2
    1250:      	b.lo	0x1448 <generic_fentry_process_event+0x10b8>
    1254:      	cmp	w23, #0xe
    1258:      	b.ne	0x1008 <generic_fentry_process_event+0xc78>
    125c:      	mov	w21, #0x8               // =8
    1260:      	add	x8, sp, #0x98
    1264:      	add	x23, sp, #0xe0
    1268:      	mov	w9, #0x4                // =4
    126c:      	add	x0, sp, #0x98
    1270:      	add	x2, sp, #0xe0
    1274:      	mov	w1, #0x8                // =8
    1278:      	mov	w22, #0x4               // =4
    127c:      	blr	x9
    1280:      	ldr	x8, [sp, #0x98]
    1284:      	add	x0, sp, #0xe0
    1288:      	mov	w1, #0x8                // =8
    128c:      	ldr	x2, [sp, #0x98]
    1290:      	ldr	x21, [sp, #0x30]
    1294:      	blr	x22
    1298:      	add	x8, sp, #0xe0
    129c:      	add	x0, x21, #0x4
    12a0:      	mov	w9, #0x2d               // =45
    12a4:      	ldr	x2, [x8]
    12a8:      	mov	w8, #0x1001             // =4097
    12ac:      	mov	w1, #0x1001             // =4097
    12b0:      	b	0x1a74 <generic_fentry_process_event+0x16e4>
    12b4:      	ldr	x2, [sp, #0x48]
    12b8:      	cmp	w23, #0x20
    12bc:      	b.le	0x1574 <generic_fentry_process_event+0x11e4>
    12c0:      	sub	w8, w23, #0x21
    12c4:      	cmp	w8, #0x4
    12c8:      	b.hs	0x1464 <generic_fentry_process_event+0x10d4>
    12cc:      	ldr	x0, [sp, #0x30]
    12d0:      	mov	w22, #0x8               // =8
    12d4:      	mov	w8, #0x4                // =4
    12d8:      	b	0x143c <generic_fentry_process_event+0x10ac>
    12dc:      	cmp	w23, #0x27
    12e0:      	b.eq	0x1a54 <generic_fentry_process_event+0x16c4>
    12e4:      	cmp	w23, #0x28
    12e8:      	b.eq	0x1a90 <generic_fentry_process_event+0x1700>
    12ec:      	ldr	x0, [sp, #0x30]
    12f0:      	cmp	w23, #0x2c
    12f4:      	b.ne	0x1008 <generic_fentry_process_event+0xc78>
    12f8:      	add	x8, sp, #0xe0
    12fc:      	strb	wzr, [sp, #0x98]
    1300:      	stp	xzr, xzr, [x0, #0x10]
    1304:      	mov	w9, #0x4                // =4
    1308:      	mov	w1, #0x2                // =2
    130c:      	ldr	x22, [x8]
    1310:      	mov	w8, #0x2                // =2
    1314:      	mov	x2, x22
    1318:      	stp	xzr, xzr, [x0]
    131c:      	stp	xzr, xzr, [x0, #0x20]
    1320:      	stp	xzr, xzr, [x0, #0x30]
    1324:      	stp	xzr, xzr, [x0, #0x40]
    1328:      	stp	xzr, xzr, [x0, #0x50]
    132c:      	stp	xzr, xzr, [x0, #0x60]
    1330:      	blr	x9
    1334:      	tbnz	x0, #0x3f, 0x2344 <generic_fentry_process_event+0x1fb4>
    1338:      	add	x23, x22, #0x2
    133c:      	mov	w8, #0x1                // =1
    1340:      	mov	w9, #0x4                // =4
    1344:      	add	x10, sp, #0x98
    1348:      	add	x0, sp, #0x98
    134c:      	mov	w1, #0x1                // =1
    1350:      	mov	x2, x23
    1354:      	blr	x9
    1358:      	tbnz	x0, #0x3f, 0x2344 <generic_fentry_process_event+0x1fb4>
    135c:      	ldrb	w8, [sp, #0x98]
    1360:      	ldr	x10, [sp, #0x30]
    1364:      	cmp	w8, #0x0
    1368:      	add	x0, x10, #0x4
    136c:      	cset	w9, eq
    1370:      	strb	w9, [x10, #0x2]
    1374:      	cbz	w8, 0x231c <generic_fentry_process_event+0x1f8c>
    1378:      	mov	w8, #0x6c               // =108
    137c:      	mov	w9, #0x2d               // =45
    1380:      	mov	w1, #0x6c               // =108
    1384:      	mov	x2, x23
    1388:      	blr	x9
    138c:      	adrp	x25, 0x1000 <generic_fentry_process_event+0xc70>
    1390:      	ldr	x25, [x25]
    1394:      	tbnz	w0, #0x1f, 0x2344 <generic_fentry_process_event+0x1fb4>
    1398:      	sub	w21, w0, #0x1
    139c:      	b	0x233c <generic_fentry_process_event+0x1fac>
    13a0:      	cmp	w23, #0x7
    13a4:      	b.gt	0x15ec <generic_fentry_process_event+0x125c>
    13a8:      	cmp	w23, #0x2
    13ac:      	b.eq	0x1b0c <generic_fentry_process_event+0x177c>
    13b0:      	cmp	w23, #0x3
    13b4:      	b.ne	0x1008 <generic_fentry_process_event+0xc78>
    13b8:      	ldr	x8, [sp, #0x40]
    13bc:      	add	x23, x0, #0x90
    13c0:      	mov	x24, x0
    13c4:      	add	x25, x23, x29
    13c8:      	and	w8, w8, #0xf
    13cc:      	cmp	w8, #0x2
    13d0:      	b.le	0x22ac <generic_fentry_process_event+0x1f1c>
    13d4:      	cmp	w8, #0x3
    13d8:      	b.eq	0x2418 <generic_fentry_process_event+0x2088>
    13dc:      	cmp	w8, #0x4
    13e0:      	b.eq	0x2420 <generic_fentry_process_event+0x2090>
    13e4:      	cmp	w8, #0x5
    13e8:      	b.ne	0x2474 <generic_fentry_process_event+0x20e4>
    13ec:      	mov	w8, #0x5e70             // =24176
    13f0:      	b	0x242c <generic_fentry_process_event+0x209c>
    13f4:      	ldr	x0, [sp, #0x30]
    13f8:      	mov	w8, #0x2                // =2
    13fc:      	add	x9, sp, #0xe0
    1400:      	mov	w10, #0x4               // =4
    1404:      	add	x2, sp, #0xe0
    1408:      	mov	w1, #0x2                // =2
    140c:      	mov	w22, #0x4               // =4
    1410:      	blr	x10
    1414:      	b	0x1008 <generic_fentry_process_event+0xc78>
    1418:      	ldr	x0, [sp, #0x30]
    141c:      	cmp	w23, #0x1
    1420:      	b.eq	0x1448 <generic_fentry_process_event+0x10b8>
    1424:      	cmp	w23, #0x4
    1428:      	b.ne	0x1008 <generic_fentry_process_event+0xc78>
    142c:      	mov	w22, #0x8               // =8
    1430:      	mov	w8, #0x4                // =4
    1434:      	add	x9, sp, #0xe0
    1438:      	add	x2, sp, #0xe0
    143c:      	mov	w1, #0x8                // =8
    1440:      	blr	x8
    1444:      	b	0x1008 <generic_fentry_process_event+0xc78>
    1448:      	add	x8, sp, #0xe0
    144c:      	mov	w9, #0x4                // =4
    1450:      	add	x2, sp, #0xe0
    1454:      	mov	w1, #0x4                // =4
    1458:      	mov	w22, #0x4               // =4
    145c:      	blr	x9
    1460:      	b	0x1008 <generic_fentry_process_event+0xc78>
    1464:      	cmp	w23, #0x2b
    1468:      	b.eq	0x1df4 <generic_fentry_process_event+0x1a64>
    146c:      	cmp	w23, #0x29
    1470:      	b.ne	0x1008 <generic_fentry_process_event+0xc78>
    1474:      	add	x2, x2, #0x18
    1478:      	mov	w8, #0x8                // =8
    147c:      	mov	w9, #0x4                // =4
    1480:      	add	x10, sp, #0x98
    1484:      	mov	x24, x0
    1488:      	add	x0, sp, #0x98
    148c:      	mov	w1, #0x8                // =8
    1490:      	blr	x9
    1494:      	ldr	x23, [sp, #0x98]
    1498:      	cbz	x23, 0x23d4 <generic_fentry_process_event+0x2044>
    149c:      	ldr	x25, [sp, #0x30]
    14a0:      	add	x2, x23, #0x10
    14a4:      	mov	w22, #0x2               // =2
    14a8:      	mov	w8, #0x4                // =4
    14ac:      	str	x23, [x25, #0x28]
    14b0:      	add	x0, x25, #0x26
    14b4:      	mov	w1, #0x2                // =2
    14b8:      	mov	w21, #0x4               // =4
    14bc:      	blr	x8
    14c0:      	add	x0, x25, #0x3a
    14c4:      	add	x2, x23, #0x12
    14c8:      	mov	w8, #0x1                // =1
    14cc:      	mov	w9, #0x4                // =4
    14d0:      	mov	w1, #0x1                // =1
    14d4:      	blr	x9
    14d8:      	add	x0, x25, #0x38
    14dc:      	add	x2, x23, #0x21e
    14e0:      	mov	w8, #0x4                // =4
    14e4:      	mov	w1, #0x2                // =2
    14e8:      	blr	x8
    14ec:      	add	x0, x25, #0x24
    14f0:      	add	x2, x23, #0x21c
    14f4:      	mov	w8, #0x4                // =4
    14f8:      	mov	w1, #0x2                // =2
    14fc:      	blr	x8
    1500:      	add	x0, x25, #0x30
    1504:      	add	x2, x23, #0x214
    1508:      	mov	w8, #0x4                // =4
    150c:      	mov	w1, #0x4                // =4
    1510:      	blr	x8
    1514:      	add	x0, x25, #0x34
    1518:      	add	x2, x23, #0x210
    151c:      	mov	w1, #0x4                // =4
    1520:      	blr	x21
    1524:      	ldrh	w8, [x25, #0x26]
    1528:      	mov	x22, x25
    152c:      	stp	xzr, xzr, [x25]
    1530:      	cmp	w8, #0xa
    1534:      	str	xzr, [x25, #0x18]
    1538:      	str	xzr, [x22, #0x10]!
    153c:      	b.eq	0x2364 <generic_fentry_process_event+0x1fd4>
    1540:      	cmp	w8, #0x2
    1544:      	b.ne	0x2390 <generic_fentry_process_event+0x2000>
    1548:      	ldr	x0, [sp, #0x30]
    154c:      	add	x2, x23, #0x4
    1550:      	mov	w8, #0x4                // =4
    1554:      	mov	w1, #0x4                // =4
    1558:      	mov	w21, #0x4               // =4
    155c:      	blr	x8
    1560:      	mov	x0, x22
    1564:      	mov	w1, #0x4                // =4
    1568:      	mov	x2, x23
    156c:      	blr	x21
    1570:      	b	0x2390 <generic_fentry_process_event+0x2000>
    1574:      	cmp	w23, #0x1a
    1578:      	b.eq	0x1e84 <generic_fentry_process_event+0x1af4>
    157c:      	cmp	w23, #0x1b
    1580:      	b.ne	0x1008 <generic_fentry_process_event+0xc78>
    1584:      	ldr	x10, [sp, #0x30]
    1588:      	add	x2, x2, #0x18
    158c:      	mov	w8, #0x3f               // =63
    1590:      	mov	w9, #0x2d               // =45
    1594:      	stp	xzr, xzr, [x10, #0x40]
    1598:      	mov	x0, x10
    159c:      	stp	xzr, xzr, [x10, #0x30]
    15a0:      	stp	xzr, xzr, [x10, #0x20]
    15a4:      	str	xzr, [x10, #0x18]
    15a8:      	stp	xzr, xzr, [x10]
    15ac:      	mov	w1, #0x3f               // =63
    15b0:      	str	xzr, [x0, #0x10]!
    15b4:      	blr	x9
    15b8:      	tbnz	x0, #0x3f, 0x21c4 <generic_fentry_process_event+0x1e34>
    15bc:      	ldr	x8, [sp, #0x30]
    15c0:      	mov	w9, #0x4                // =4
    15c4:      	mov	w1, #0x8                // =8
    15c8:      	add	x0, x8, #0x8
    15cc:      	ldr	x8, [sp, #0x48]
    15d0:      	add	x2, x8, #0x360
    15d4:      	mov	w8, #0x8                // =8
    15d8:      	blr	x9
    15dc:      	adrp	x25, 0x1000 <generic_fentry_process_event+0xc70>
    15e0:      	mov	w22, #0x50              // =80
    15e4:      	ldr	x25, [x25]
    15e8:      	b	0x1008 <generic_fentry_process_event+0xc78>
    15ec:      	cmp	w23, #0x8
    15f0:      	b.eq	0x1b58 <generic_fentry_process_event+0x17c8>
    15f4:      	ldr	x2, [sp, #0x48]
    15f8:      	cmp	w23, #0x12
    15fc:      	b.ne	0x1008 <generic_fentry_process_event+0xc78>
    1600:      	ldr	x8, [sp, #0x40]
    1604:      	ldr	x0, [sp, #0x30]
    1608:      	and	x22, x8, #0x3ff
    160c:      	mov	w8, #0x4                // =4
    1610:      	mov	w1, w22
    1614:      	b	0x1440 <generic_fentry_process_event+0x10b0>
    1618:      	cmp	w23, #0x13
    161c:      	b.eq	0x1db0 <generic_fentry_process_event+0x1a20>
    1620:      	ldr	x29, [sp, #0x48]
    1624:      	cmp	w23, #0x14
    1628:      	b.ne	0x1008 <generic_fentry_process_event+0xc78>
    162c:      	str	xzr, [sp, #0x98]
    1630:      	add	x2, x29, #0x110
    1634:      	mov	w23, #0x8               // =8
    1638:      	add	x8, sp, #0x98
    163c:      	mov	w9, #0x4                // =4
    1640:      	add	x0, sp, #0x98
    1644:      	mov	w1, #0x8                // =8
    1648:      	add	x22, x29, #0xd8
    164c:      	mov	w21, #0x4               // =4
    1650:      	blr	x9
    1654:      	ldr	x8, [sp, #0x98]
    1658:      	mov	w9, #0x80               // =128
    165c:      	mov	w10, #0x2d              // =45
    1660:      	ldr	x24, [sp, #0x30]
    1664:      	mov	w1, #0x80               // =128
    1668:      	mov	x0, x24
    166c:      	ldr	x2, [sp, #0x98]
    1670:      	blr	x10
    1674:      	add	x0, x24, #0x90
    1678:      	mov	w8, #0x4                // =4
    167c:      	mov	w1, #0x4                // =4
    1680:      	mov	x2, x22
    1684:      	blr	x8
    1688:      	add	x0, x24, #0x80
    168c:      	add	x2, x29, #0xe0
    1690:      	mov	w8, #0x4                // =4
    1694:      	mov	w1, #0x8                // =8
    1698:      	blr	x8
    169c:      	add	x0, x24, #0x88
    16a0:      	add	x2, x29, #0x118
    16a4:      	mov	w1, #0x8                // =8
    16a8:      	blr	x21
    16ac:      	mov	w22, #0x98              // =152
    16b0:      	b	0x1008 <generic_fentry_process_event+0xc78>
    16b4:      	ldr	x21, [sp, #0x30]
    16b8:      	cmp	w23, #0x26
    16bc:      	b.ne	0x1008 <generic_fentry_process_event+0xc78>
    16c0:      	add	x8, sp, #0xe0
    16c4:      	add	x0, x21, #0x4
    16c8:      	ldr	x8, [x8]
    16cc:      	add	x2, x19, w8, uxth
    16d0:      	ubfx	w8, w8, #16, #12
    16d4:      	add	w1, w8, #0x1
    16d8:      	mov	w8, #0x2d               // =45
    16dc:      	blr	x8
    16e0:      	b	0x1a78 <generic_fentry_process_event+0x16e8>
    16e4:      	str	xzr, [sp, #0xa0]
    16e8:      	mov	w8, #0xe                // =14
    16ec:      	blr	x8
    16f0:      	lsr	x8, x0, #32
    16f4:      	add	x9, sp, #0xf0
    16f8:      	add	x10, sp, #0xe0
    16fc:      	str	x8, [sp, #0x98]
    1700:      	mov	w8, #0x4                // =4
    1704:      	add	x0, sp, #0xf0
    1708:      	add	x2, sp, #0xe0
    170c:      	mov	w1, #0x4                // =4
    1710:      	blr	x8
    1714:      	ldr	w8, [sp, #0xf0]
    1718:      	adrp	x0, 0x1000 <generic_fentry_process_event+0xc70>
    171c:      	add	x9, sp, #0x98
    1720:      	add	x1, sp, #0x98
    1724:      	str	w8, [sp, #0xa0]
    1728:      	mov	w8, #0x1                // =1
    172c:      	ldr	x0, [x0]
    1730:      	blr	x8
    1734:      	cbz	x0, 0x1f68 <generic_fentry_process_event+0x1bd8>
    1738:      	ldr	x24, [sp, #0x30]
    173c:      	ldr	w21, [x0]
    1740:      	add	x8, sp, #0xf0
    1744:      	mov	w9, #0x4                // =4
    1748:      	add	x2, sp, #0xf0
    174c:      	mov	x22, x0
    1750:      	mov	w1, #0x4                // =4
    1754:      	mov	w23, #0x4               // =4
    1758:      	mov	x0, x24
    175c:      	blr	x9
    1760:      	and	x21, x21, #0xfff
    1764:      	add	x0, x24, #0x4
    1768:      	mov	w8, #0x4                // =4
    176c:      	mov	x2, x22
    1770:      	add	x1, x21, #0x4
    1774:      	blr	x8
    1778:      	add	w21, w21, #0x8
    177c:      	mov	w1, #0x4                // =4
    1780:      	add	x8, x21, x22
    1784:      	add	x0, x24, x21
    1788:      	sub	x2, x8, #0x4
    178c:      	blr	x23
    1790:      	adrp	x25, 0x1000 <generic_fentry_process_event+0xc70>
    1794:      	add	x22, x21, #0x4
    1798:      	ldr	x25, [x25]
    179c:      	b	0x1008 <generic_fentry_process_event+0xc78>
    17a0:      	add	x8, sp, #0xe0
    17a4:      	mov	w9, #0x4                // =4
    17a8:      	add	x10, sp, #0x84
    17ac:      	ldr	x22, [x8]
    17b0:      	mov	w8, #0x1                // =1
    17b4:      	add	x0, sp, #0x84
    17b8:      	mov	w1, #0x1                // =1
    17bc:      	mov	x2, x22
    17c0:      	blr	x9
    17c4:      	ldrb	w8, [sp, #0x84]
    17c8:      	cbz	w8, 0x1f78 <generic_fentry_process_event+0x1be8>
    17cc:      	cmp	w8, #0x1
    17d0:      	b.ne	0x21a8 <generic_fentry_process_event+0x1e18>
    17d4:      	add	x2, x22, #0x10
    17d8:      	mov	w23, #0x8               // =8
    17dc:      	add	x8, sp, #0xf0
    17e0:      	mov	w9, #0x4                // =4
    17e4:      	add	x0, sp, #0xf0
    17e8:      	mov	w1, #0x8                // =8
    17ec:      	mov	w21, #0x4               // =4
    17f0:      	blr	x9
    17f4:      	add	x22, sp, #0xe0
    17f8:      	add	x8, sp, #0x100
    17fc:      	mov	w9, #0x4                // =4
    1800:      	ldr	x2, [x22, #0x10]
    1804:      	add	x0, sp, #0x100
    1808:      	mov	w1, #0x8                // =8
    180c:      	blr	x9
    1810:      	ldr	x8, [x22, #0x10]
    1814:      	add	x0, sp, #0xe8
    1818:      	mov	w1, #0x8                // =8
    181c:      	add	x2, x8, #0x8
    1820:      	add	x8, sp, #0xe8
    1824:      	blr	x21
    1828:      	ldr	x8, [sp, #0x48]
    182c:      	ldr	x25, [x22, #0x20]
    1830:      	add	x8, x8, #0x90
    1834:      	ldr	x22, [x22, #0x8]
    1838:      	add	x29, x8, x29
    183c:      	tbz	w24, #0x5, 0x2580 <generic_fentry_process_event+0x21f0>
    1840:      	cmp	x22, #0x1, lsl #12      // =0x1000
    1844:      	b.lo	0x2568 <generic_fentry_process_event+0x21d8>
    1848:      	mov	w8, #0x1                // =1
    184c:      	adrp	x0, 0x1000 <generic_fentry_process_event+0xc70>
    1850:      	add	x9, sp, #0x90
    1854:      	str	w8, [x29]
    1858:      	str	wzr, [sp, #0x90]
    185c:      	add	x1, sp, #0x90
    1860:      	ldr	x0, [x0]
    1864:      	blr	x8
    1868:      	cbz	x0, 0x2a40 <generic_fentry_process_event+0x26b0>
    186c:      	mov	w8, #0x18               // =24
    1870:      	mov	x24, x0
    1874:      	str	w8, [x0]
    1878:      	mov	w8, #0xe                // =14
    187c:      	blr	x8
    1880:      	mov	x21, x24
    1884:      	cmn	x0, #0x16
    1888:      	str	x0, [x21, #0x10]!
    188c:      	b.ne	0x18b4 <generic_fentry_process_event+0x1524>
    1890:      	add	x2, x19, #0xe8
    1894:      	mov	w8, #0x8                // =8
    1898:      	mov	w9, #0x4                // =4
    189c:      	add	x10, sp, #0x98
    18a0:      	add	x0, sp, #0x98
    18a4:      	mov	w1, #0x8                // =8
    18a8:      	blr	x9
    18ac:      	ldr	x8, [sp, #0x98]
    18b0:      	str	x8, [x21]
    18b4:      	mov	w8, #0x7d               // =125
    18b8:      	blr	x8
    18bc:      	str	x0, [x24, #0x18]
    18c0:      	mov	x0, x19
    18c4:      	mov	x1, x24
    18c8:      	mov	x2, x25
    18cc:      	ldp	x8, x9, [x21]
    18d0:      	mov	x3, x22
    18d4:      	stur	x9, [x29, #0x1c]
    18d8:      	stur	x8, [x29, #0x14]
    18dc:      	bl	0x18dc <generic_fentry_process_event+0x154c>
    18e0:      	tbnz	w0, #0x1f, 0x206c <generic_fentry_process_event+0x1cdc>
    18e4:      	sub	w8, w22, w0
    18e8:      	cmn	x22, #0x1
    18ec:      	stur	xzr, [x29, #0x4]
    18f0:      	csel	w8, wzr, w8, eq
    18f4:      	b	0x2078 <generic_fentry_process_event+0x1ce8>
    18f8:      	add	x8, sp, #0xe0
    18fc:      	ldr	x21, [sp, #0x30]
    1900:      	mov	w1, #0x4                // =4
    1904:      	mov	w23, #0x4               // =4
    1908:      	ldr	x24, [x8]
    190c:      	mov	w8, #0x4                // =4
    1910:      	add	x0, x21, #0x28
    1914:      	add	x2, x24, #0x98
    1918:      	blr	x8
    191c:      	add	x0, x21, #0x2c
    1920:      	add	x2, x24, #0x70
    1924:      	mov	w8, #0x4                // =4
    1928:      	mov	w1, #0x4                // =4
    192c:      	blr	x8
    1930:      	add	x0, x21, #0x30
    1934:      	add	x2, x24, #0x90
    1938:      	mov	w8, #0x4                // =4
    193c:      	mov	w1, #0x4                // =4
    1940:      	blr	x8
    1944:      	add	x0, x21, #0x34
    1948:      	add	x2, x24, #0xa8
    194c:      	mov	w8, #0x4                // =4
    1950:      	mov	w1, #0x4                // =4
    1954:      	blr	x8
    1958:      	str	xzr, [sp, #0x98]
    195c:      	add	x2, x24, #0xc8
    1960:      	mov	w8, #0x8                // =8
    1964:      	add	x9, sp, #0x98
    1968:      	mov	w10, #0x4               // =4
    196c:      	add	x0, sp, #0x98
    1970:      	mov	w1, #0x8                // =8
    1974:      	blr	x10
    1978:      	add	x2, x24, #0xb8
    197c:      	mov	w8, #0x2                // =2
    1980:      	add	x9, sp, #0xe8
    1984:      	mov	w10, #0x4               // =4
    1988:      	add	x0, sp, #0xe8
    198c:      	mov	w1, #0x2                // =2
    1990:      	blr	x10
    1994:      	ldr	x8, [sp, #0x98]
    1998:      	ldrh	w9, [sp, #0xe8]
    199c:      	add	x0, sp, #0xdc
    19a0:      	mov	w1, #0x1                // =1
    19a4:      	add	x22, x8, x9
    19a8:      	mov	w8, #0x1                // =1
    19ac:      	add	x9, sp, #0xdc
    19b0:      	mov	x2, x22
    19b4:      	blr	x23
    19b8:      	ldrb	w8, [sp, #0xdc]
    19bc:      	lsr	w8, w8, #4
    19c0:      	cmp	w8, #0x6
    19c4:      	b.eq	0x208c <generic_fentry_process_event+0x1cfc>
    19c8:      	cmp	w8, #0x4
    19cc:      	b.ne	0x3170 <generic_fentry_process_event+0x2de0>
    19d0:      	add	x2, x22, #0x9
    19d4:      	mov	w8, #0x1                // =1
    19d8:      	add	x9, sp, #0x84
    19dc:      	mov	w10, #0x4               // =4
    19e0:      	add	x0, sp, #0x84
    19e4:      	mov	w1, #0x1                // =1
    19e8:      	mov	w21, #0x4               // =4
    19ec:      	blr	x10
    19f0:      	ldr	x0, [sp, #0x30]
    19f4:      	ldrb	w8, [sp, #0x84]
    19f8:      	mov	w25, #0x2               // =2
    19fc:      	add	x2, x22, #0xc
    1a00:      	mov	w1, #0x4                // =4
    1a04:      	mov	x23, x0
    1a08:      	strh	w8, [x0, #0x24]
    1a0c:      	strh	w25, [x0, #0x26]
    1a10:      	stp	xzr, xzr, [x0]
    1a14:      	str	xzr, [x0, #0x18]
    1a18:      	mov	w8, #0x4                // =4
    1a1c:      	str	xzr, [x23, #0x10]!
    1a20:      	blr	x8
    1a24:      	add	x2, x22, #0x10
    1a28:      	mov	w8, #0x4                // =4
    1a2c:      	mov	x0, x23
    1a30:      	mov	w1, #0x4                // =4
    1a34:      	blr	x8
    1a38:      	add	x2, x24, #0xb6
    1a3c:      	add	x8, sp, #0x90
    1a40:      	add	x0, sp, #0x90
    1a44:      	mov	w1, #0x2                // =2
    1a48:      	blr	x21
    1a4c:      	ldrb	w29, [sp, #0x84]
    1a50:      	b	0x3034 <generic_fentry_process_event+0x2ca4>
    1a54:      	add	x8, sp, #0xe0
    1a58:      	ldr	x21, [sp, #0x30]
    1a5c:      	mov	w9, #0x2d               // =45
    1a60:      	mov	w1, #0x11               // =17
    1a64:      	ldr	x8, [x8]
    1a68:      	add	x0, x21, #0x4
    1a6c:      	add	x2, x8, #0x118
    1a70:      	mov	w8, #0x11               // =17
    1a74:      	blr	x9
    1a78:      	mov	x22, x0
    1a7c:      	tbnz	x0, #0x3f, 0x1008 <generic_fentry_process_event+0xc78>
    1a80:      	sub	w8, w22, #0x1
    1a84:      	add	x22, x22, #0x3
    1a88:      	str	w8, [x21]
    1a8c:      	b	0x1008 <generic_fentry_process_event+0xc78>
    1a90:      	ldr	x21, [sp, #0x30]
    1a94:      	add	x8, sp, #0xe0
    1a98:      	mov	w9, #0x4                // =4
    1a9c:      	mov	w1, #0x2                // =2
    1aa0:      	ldr	x22, [x8]
    1aa4:      	mov	w8, #0x2                // =2
    1aa8:      	str	xzr, [x21]
    1aac:      	stp	xzr, xzr, [x21, #0x8]
    1ab0:      	mov	x0, x21
    1ab4:      	mov	x2, x22
    1ab8:      	blr	x9
    1abc:      	tbnz	x0, #0x3f, 0x2314 <generic_fentry_process_event+0x1f84>
    1ac0:      	ldrh	w8, [x21]
    1ac4:      	cmp	w8, #0xa
    1ac8:      	b.eq	0x22c4 <generic_fentry_process_event+0x1f34>
    1acc:      	cmp	w8, #0x2
    1ad0:      	b.ne	0x22f8 <generic_fentry_process_event+0x1f68>
    1ad4:      	add	x2, x22, #0x4
    1ad8:      	add	x8, sp, #0x98
    1adc:      	mov	w9, #0x4                // =4
    1ae0:      	add	x0, sp, #0x98
    1ae4:      	mov	w1, #0x4                // =4
    1ae8:      	mov	w21, #0x4               // =4
    1aec:      	blr	x9
    1af0:      	ldr	w8, [sp, #0x98]
    1af4:      	ldr	x9, [sp, #0x30]
    1af8:      	add	x2, x22, #0x2
    1afc:      	add	x0, x9, #0x2
    1b00:      	str	x8, [x9, #0x8]
    1b04:      	mov	w8, #0x2                // =2
    1b08:      	b	0x22f0 <generic_fentry_process_event+0x1f60>
    1b0c:      	add	x23, x0, #0x90
    1b10:      	mov	x22, x0
    1b14:      	add	x8, sp, #0xe0
    1b18:      	str	xzr, [x8]
    1b1c:      	add	x25, x23, x29
    1b20:      	tbnz	w24, #0x4, 0x21d4 <generic_fentry_process_event+0x1e44>
    1b24:      	and	w9, w24, #0xf
    1b28:      	mov	x8, xzr
    1b2c:      	and	x29, x24, #0xffffffff
    1b30:      	cmp	w9, #0x2
    1b34:      	b.le	0x234c <generic_fentry_process_event+0x1fbc>
    1b38:      	cmp	w9, #0x3
    1b3c:      	b.eq	0x2660 <generic_fentry_process_event+0x22d0>
    1b40:      	cmp	w9, #0x4
    1b44:      	b.eq	0x2668 <generic_fentry_process_event+0x22d8>
    1b48:      	cmp	w9, #0x5
    1b4c:      	b.ne	0x267c <generic_fentry_process_event+0x22ec>
    1b50:      	mov	w8, #0x5e70             // =24176
    1b54:      	b	0x2674 <generic_fentry_process_event+0x22e4>
    1b58:      	ldr	x29, [sp, #0x30]
    1b5c:      	ldr	x24, [sp, #0x48]
    1b60:      	mov	w1, #0x4                // =4
    1b64:      	mov	w23, #0x4               // =4
    1b68:      	add	x8, x29, #0x40
    1b6c:      	add	x2, x24, #0x8
    1b70:      	mov	x0, x29
    1b74:      	add	x22, x29, #0x28
    1b78:      	str	x8, [sp, #0x40]
    1b7c:      	mov	w8, #0x4                // =4
    1b80:      	blr	x8
    1b84:      	add	x0, x29, #0x4
    1b88:      	add	x2, x24, #0xc
    1b8c:      	mov	w8, #0x4                // =4
    1b90:      	mov	w1, #0x4                // =4
    1b94:      	blr	x8
    1b98:      	add	x0, x29, #0x10
    1b9c:      	add	x2, x24, #0x18
    1ba0:      	mov	w8, #0x4                // =4
    1ba4:      	mov	w1, #0x4                // =4
    1ba8:      	blr	x8
    1bac:      	add	x0, x29, #0x14
    1bb0:      	add	x2, x24, #0x1c
    1bb4:      	mov	w8, #0x4                // =4
    1bb8:      	mov	w1, #0x4                // =4
    1bbc:      	blr	x8
    1bc0:      	add	x0, x29, #0x8
    1bc4:      	add	x2, x24, #0x10
    1bc8:      	mov	w8, #0x4                // =4
    1bcc:      	mov	w1, #0x4                // =4
    1bd0:      	blr	x8
    1bd4:      	add	x0, x29, #0xc
    1bd8:      	add	x2, x24, #0x14
    1bdc:      	mov	w8, #0x4                // =4
    1be0:      	mov	w1, #0x4                // =4
    1be4:      	blr	x8
    1be8:      	add	x0, x29, #0x18
    1bec:      	add	x2, x24, #0x20
    1bf0:      	mov	w8, #0x4                // =4
    1bf4:      	mov	w1, #0x4                // =4
    1bf8:      	blr	x8
    1bfc:      	add	x0, x29, #0x1c
    1c00:      	add	x2, x24, #0x24
    1c04:      	mov	w8, #0x4                // =4
    1c08:      	mov	w1, #0x4                // =4
    1c0c:      	blr	x8
    1c10:      	str	wzr, [x29, #0x24]
    1c14:      	add	x0, x29, #0x20
    1c18:      	add	x2, x24, #0x28
    1c1c:      	mov	w8, #0x4                // =4
    1c20:      	mov	w1, #0x4                // =4
    1c24:      	blr	x8
    1c28:      	add	x0, x29, #0x30
    1c2c:      	add	x2, x24, #0x40
    1c30:      	mov	w21, #0x8               // =8
    1c34:      	mov	w8, #0x4                // =4
    1c38:      	mov	w1, #0x8                // =8
    1c3c:      	blr	x8
    1c40:      	add	x0, x29, #0x38
    1c44:      	add	x2, x24, #0x30
    1c48:      	mov	w8, #0x4                // =4
    1c4c:      	mov	w1, #0x8                // =8
    1c50:      	blr	x8
    1c54:      	add	x2, x24, #0x38
    1c58:      	mov	w8, #0x4                // =4
    1c5c:      	mov	x0, x22
    1c60:      	mov	w1, #0x8                // =8
    1c64:      	blr	x8
    1c68:      	add	x2, x24, #0x90
    1c6c:      	add	x8, sp, #0x98
    1c70:      	mov	w9, #0x4                // =4
    1c74:      	add	x0, sp, #0x98
    1c78:      	mov	w1, #0x8                // =8
    1c7c:      	blr	x9
    1c80:      	ldr	x21, [sp, #0x98]
    1c84:      	ldr	x0, [sp, #0x40]
    1c88:      	mov	w8, #0x4                // =4
    1c8c:      	mov	w1, #0x4                // =4
    1c90:      	add	x2, x21, #0xc8
    1c94:      	blr	x8
    1c98:      	add	x0, x29, #0x44
    1c9c:      	add	x2, x21, #0xcc
    1ca0:      	mov	w8, #0x4                // =4
    1ca4:      	mov	w1, #0x4                // =4
    1ca8:      	blr	x8
    1cac:      	add	x0, x29, #0x48
    1cb0:      	add	x2, x21, #0xd0
    1cb4:      	mov	w8, #0x4                // =4
    1cb8:      	mov	w1, #0x4                // =4
    1cbc:      	blr	x8
    1cc0:      	add	x0, x29, #0x4c
    1cc4:      	add	x2, x21, #0x158
    1cc8:      	mov	w1, #0x4                // =4
    1ccc:      	blr	x23
    1cd0:      	mov	w22, #0x50              // =80
    1cd4:      	b	0x1008 <generic_fentry_process_event+0xc78>
    1cd8:      	ldr	x23, [sp, #0x48]
    1cdc:      	ldr	x22, [sp, #0x30]
    1ce0:      	mov	w8, #0x4                // =4
    1ce4:      	mov	w1, #0x4                // =4
    1ce8:      	mov	w21, #0x4               // =4
    1cec:      	add	x2, x23, #0xc8
    1cf0:      	mov	x0, x22
    1cf4:      	blr	x8
    1cf8:      	add	x0, x22, #0x4
    1cfc:      	add	x2, x23, #0xcc
    1d00:      	mov	w8, #0x4                // =4
    1d04:      	mov	w1, #0x4                // =4
    1d08:      	blr	x8
    1d0c:      	add	x0, x22, #0x8
    1d10:      	add	x2, x23, #0xd0
    1d14:      	mov	w8, #0x4                // =4
    1d18:      	mov	w1, #0x4                // =4
    1d1c:      	blr	x8
    1d20:      	add	x0, x22, #0xc
    1d24:      	add	x2, x23, #0x158
    1d28:      	mov	w1, #0x4                // =4
    1d2c:      	blr	x21
    1d30:      	mov	w22, #0x10              // =16
    1d34:      	b	0x1008 <generic_fentry_process_event+0xc78>
    1d38:      	ldr	x23, [sp, #0x48]
    1d3c:      	ldr	x22, [sp, #0x30]
    1d40:      	mov	w8, #0x4                // =4
    1d44:      	mov	w1, #0x4                // =4
    1d48:      	mov	w21, #0x4               // =4
    1d4c:      	add	x2, x23, #0x38
    1d50:      	mov	x0, x22
    1d54:      	blr	x8
    1d58:      	add	x0, x22, #0x4
    1d5c:      	add	x2, x23, #0x3c
    1d60:      	mov	w8, #0x4                // =4
    1d64:      	mov	w1, #0x4                // =4
    1d68:      	blr	x8
    1d6c:      	add	x0, x22, #0x8
    1d70:      	add	x2, x23, #0x40
    1d74:      	mov	w8, #0x4                // =4
    1d78:      	mov	w1, #0x4                // =4
    1d7c:      	blr	x8
    1d80:      	add	x0, x22, #0xc
    1d84:      	add	x2, x23, #0x44
    1d88:      	mov	w8, #0x4                // =4
    1d8c:      	mov	w1, #0x4                // =4
    1d90:      	blr	x8
    1d94:      	add	x0, x22, #0x10
    1d98:      	add	x2, x23, #0x80
    1d9c:      	mov	w8, #0x10               // =16
    1da0:      	mov	w1, #0x10               // =16
    1da4:      	blr	x21
    1da8:      	mov	w22, #0x20              // =32
    1dac:      	b	0x1008 <generic_fentry_process_event+0xc78>
    1db0:      	ldr	x22, [sp, #0x30]
    1db4:      	ldr	x23, [sp, #0x48]
    1db8:      	mov	w8, #0x4                // =4
    1dbc:      	mov	w1, #0x4                // =4
    1dc0:      	mov	w21, #0x4               // =4
    1dc4:      	mov	x0, x22
    1dc8:      	mov	x2, x23
    1dcc:      	blr	x8
    1dd0:      	add	x0, x22, #0x4
    1dd4:      	add	x2, x23, #0x4
    1dd8:      	mov	w8, #0x4                // =4
    1ddc:      	mov	w1, #0x4                // =4
    1de0:      	blr	x8
    1de4:      	add	x0, x22, #0x8
    1de8:      	add	x2, x23, #0x30
    1dec:      	mov	w8, #0x10               // =16
    1df0:      	b	0x1e74 <generic_fentry_process_event+0x1ae4>
    1df4:      	mov	x23, x2
    1df8:      	add	x2, x2, #0x4
    1dfc:      	add	x8, sp, #0x98
    1e00:      	mov	w9, #0x4                // =4
    1e04:      	add	x0, sp, #0x98
    1e08:      	mov	w1, #0x4                // =4
    1e0c:      	mov	w21, #0x4               // =4
    1e10:      	blr	x9
    1e14:      	ldr	w8, [sp, #0x98]
    1e18:      	ldr	x22, [sp, #0x30]
    1e1c:      	add	x2, x23, #0xc
    1e20:      	add	x0, sp, #0x98
    1e24:      	mov	w1, #0x4                // =4
    1e28:      	str	w8, [x22]
    1e2c:      	add	x8, sp, #0x98
    1e30:      	blr	x21
    1e34:      	ldr	w8, [sp, #0x98]
    1e38:      	add	x2, x23, #0x50
    1e3c:      	add	x9, sp, #0x98
    1e40:      	mov	w10, #0x2d              // =45
    1e44:      	str	w8, [x22, #0x4]
    1e48:      	mov	w8, #0x8                // =8
    1e4c:      	add	x0, sp, #0x98
    1e50:      	mov	w1, #0x8                // =8
    1e54:      	mov	w21, #0x2d              // =45
    1e58:      	blr	x10
    1e5c:      	ldr	x8, [sp, #0x98]
    1e60:      	add	x0, x22, #0x8
    1e64:      	mov	w9, #0x10               // =16
    1e68:      	add	x8, x8, #0x3f8
    1e6c:      	ldr	x8, [sp, #0x98]
    1e70:      	add	x2, x8, #0x3f8
    1e74:      	mov	w1, #0x10               // =16
    1e78:      	blr	x21
    1e7c:      	mov	w22, #0x18              // =24
    1e80:      	b	0x1008 <generic_fentry_process_event+0xc78>
    1e84:      	ldr	x11, [sp, #0x30]
    1e88:      	mov	w8, #0x8                // =8
    1e8c:      	mov	w9, #0x4                // =4
    1e90:      	add	x10, sp, #0x98
    1e94:      	stp	xzr, xzr, [x11, #0x40]
    1e98:      	add	x0, sp, #0x98
    1e9c:      	stp	xzr, xzr, [x11, #0x30]
    1ea0:      	stp	xzr, xzr, [x11, #0x20]
    1ea4:      	mov	w1, #0x8                // =8
    1ea8:      	stp	xzr, xzr, [x11, #0x10]
    1eac:      	stp	xzr, xzr, [x11]
    1eb0:      	blr	x9
    1eb4:      	mov	x22, xzr
    1eb8:      	cbnz	x0, 0x1f5c <generic_fentry_process_event+0x1bcc>
    1ebc:      	ldr	x8, [sp, #0x30]
    1ec0:      	mov	w9, #0x3f               // =63
    1ec4:      	mov	w10, #0x2d              // =45
    1ec8:      	mov	w1, #0x3f               // =63
    1ecc:      	add	x0, x8, #0x10
    1ed0:      	ldr	x8, [sp, #0x98]
    1ed4:      	ldr	x2, [sp, #0x98]
    1ed8:      	blr	x10
    1edc:      	tbnz	x0, #0x3f, 0x21c4 <generic_fentry_process_event+0x1e34>
    1ee0:      	ldr	x23, [sp, #0x48]
    1ee4:      	mov	w21, #0x8               // =8
    1ee8:      	add	x8, sp, #0xf0
    1eec:      	mov	w9, #0x4                // =4
    1ef0:      	add	x0, sp, #0xf0
    1ef4:      	mov	w1, #0x8                // =8
    1ef8:      	mov	w22, #0x4               // =4
    1efc:      	add	x2, x23, #0x8
    1f00:      	blr	x9
    1f04:      	ldr	x8, [sp, #0x30]
    1f08:      	add	x10, sp, #0xe0
    1f0c:      	mov	w9, #0x4                // =4
    1f10:      	mov	w1, #0x8                // =8
    1f14:      	add	x0, x8, #0x8
    1f18:      	ldr	x8, [x10, #0x10]
    1f1c:      	add	x8, x8, #0x360
    1f20:      	ldr	x8, [x10, #0x10]
    1f24:      	add	x2, x8, #0x360
    1f28:      	blr	x9
    1f2c:      	add	x2, x23, #0x58
    1f30:      	add	x8, sp, #0xf0
    1f34:      	add	x0, sp, #0xf0
    1f38:      	mov	w1, #0x4                // =4
    1f3c:      	blr	x22
    1f40:      	cbnz	x0, 0x1f58 <generic_fentry_process_event+0x1bc8>
    1f44:      	ldr	w8, [sp, #0xf0]
    1f48:      	ldr	x9, [sp, #0x30]
    1f4c:      	cmp	w8, #0x0
    1f50:      	cset	w8, ne
    1f54:      	str	w8, [x9]
    1f58:      	mov	w22, #0x50              // =80
    1f5c:      	adrp	x25, 0x1000 <generic_fentry_process_event+0xc70>
    1f60:      	ldr	x25, [x25]
    1f64:      	b	0x1008 <generic_fentry_process_event+0xc78>
    1f68:      	adrp	x25, 0x1000 <generic_fentry_process_event+0xc70>
    1f6c:      	mov	x22, #-0x1              // =-1
    1f70:      	ldr	x25, [x25]
    1f74:      	b	0x1008 <generic_fentry_process_event+0xc78>
    1f78:      	add	x2, x22, #0x10
    1f7c:      	mov	w21, #0x8               // =8
    1f80:      	add	x8, sp, #0x100
    1f84:      	mov	w9, #0x4                // =4
    1f88:      	add	x0, sp, #0x100
    1f8c:      	mov	w1, #0x8                // =8
    1f90:      	mov	w23, #0x4               // =4
    1f94:      	blr	x9
    1f98:      	add	x2, x22, #0x18
    1f9c:      	add	x8, sp, #0xe8
    1fa0:      	add	x0, sp, #0xe8
    1fa4:      	mov	w1, #0x8                // =8
    1fa8:      	blr	x23
    1fac:      	add	x8, sp, #0xe0
    1fb0:      	ldr	x23, [x8, #0x20]
    1fb4:      	ldr	x22, [x8, #0x8]
    1fb8:      	ldp	x9, x8, [sp, #0x40]
    1fbc:      	add	x8, x8, #0x90
    1fc0:      	add	x29, x8, x29
    1fc4:      	tbz	w9, #0x5, 0x25d0 <generic_fentry_process_event+0x2240>
    1fc8:      	cmp	x22, #0x1, lsl #12      // =0x1000
    1fcc:      	b.lo	0x25b8 <generic_fentry_process_event+0x2228>
    1fd0:      	mov	w8, #0x1                // =1
    1fd4:      	adrp	x0, 0x1000 <generic_fentry_process_event+0xc70>
    1fd8:      	add	x9, sp, #0x90
    1fdc:      	str	w8, [x29]
    1fe0:      	str	wzr, [sp, #0x90]
    1fe4:      	add	x1, sp, #0x90
    1fe8:      	ldr	x0, [x0]
    1fec:      	blr	x8
    1ff0:      	cbz	x0, 0x2a40 <generic_fentry_process_event+0x26b0>
    1ff4:      	mov	w8, #0x18               // =24
    1ff8:      	mov	x24, x0
    1ffc:      	str	w8, [x0]
    2000:      	mov	w8, #0xe                // =14
    2004:      	blr	x8
    2008:      	mov	x21, x24
    200c:      	cmn	x0, #0x16
    2010:      	str	x0, [x21, #0x10]!
    2014:      	b.ne	0x203c <generic_fentry_process_event+0x1cac>
    2018:      	add	x2, x19, #0xe8
    201c:      	mov	w8, #0x8                // =8
    2020:      	mov	w9, #0x4                // =4
    2024:      	add	x10, sp, #0x98
    2028:      	add	x0, sp, #0x98
    202c:      	mov	w1, #0x8                // =8
    2030:      	blr	x9
    2034:      	ldr	x8, [sp, #0x98]
    2038:      	str	x8, [x21]
    203c:      	mov	w8, #0x7d               // =125
    2040:      	blr	x8
    2044:      	str	x0, [x24, #0x18]
    2048:      	mov	x0, x19
    204c:      	mov	x1, x24
    2050:      	mov	x2, x23
    2054:      	ldp	x8, x9, [x21]
    2058:      	mov	x3, x22
    205c:      	stur	x9, [x29, #0x1c]
    2060:      	stur	x8, [x29, #0x14]
    2064:      	bl	0x2064 <generic_fentry_process_event+0x1cd4>
    2068:      	tbz	w0, #0x1f, 0x18e4 <generic_fentry_process_event+0x1554>
    206c:      	mov	w8, wzr
    2070:      	stp	w0, wzr, [x29, #0x4]
    2074:      	mov	w0, wzr
    2078:      	stp	w8, w0, [x29, #0xc]
    207c:      	adrp	x25, 0x2000 <generic_fentry_process_event+0x1c70>
    2080:      	mov	w22, #0x24              // =36
    2084:      	ldr	x25, [x25]
    2088:      	b	0x1008 <generic_fentry_process_event+0xc78>
    208c:      	ldr	x8, [sp, #0x98]
    2090:      	ldrh	w21, [sp, #0xe8]
    2094:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    2098:      	add	x9, sp, #0xf0
    209c:      	add	x1, sp, #0xf0
    20a0:      	add	x25, x8, x21
    20a4:      	str	x8, [sp, #0x48]
    20a8:      	str	wzr, [sp, #0xf0]
    20ac:      	mov	w8, #0x1                // =1
    20b0:      	ldr	x0, [x0]
    20b4:      	blr	x8
    20b8:      	cbz	x0, 0x2ff0 <generic_fentry_process_event+0x2c60>
    20bc:      	mov	w8, #0xff               // =255
    20c0:      	strh	w21, [x0]
    20c4:      	strb	wzr, [x0, #0x7]
    20c8:      	add	x22, x0, #0x6
    20cc:      	add	x2, x25, #0x6
    20d0:      	mov	w9, #0x4                // =4
    20d4:      	strb	w8, [x0, #0x5]
    20d8:      	mov	w8, #0x1                // =1
    20dc:      	mov	x23, x0
    20e0:      	mov	x0, x22
    20e4:      	mov	w1, #0x1                // =1
    20e8:      	blr	x9
    20ec:      	tbnz	x0, #0x3f, 0x2ff0 <generic_fentry_process_event+0x2c60>
    20f0:      	ldrb	w8, [x23, #0x5]
    20f4:      	cmp	w8, #0x32
    20f8:      	b.gt	0x2608 <generic_fentry_process_event+0x2278>
    20fc:      	cbz	w8, 0x2654 <generic_fentry_process_event+0x22c4>
    2100:      	cmp	w8, #0x2b
    2104:      	b.eq	0x2654 <generic_fentry_process_event+0x22c4>
    2108:      	cmp	w8, #0x2c
    210c:      	b.ne	0x2b14 <generic_fentry_process_event+0x2784>
    2110:      	mov	w8, #0x8                // =8
    2114:      	b	0x2a5c <generic_fentry_process_event+0x26cc>
    2118:      	ldr	x0, [sp, #0x30]
    211c:      	add	x2, x23, #0x48
    2120:      	mov	w21, #0x10              // =16
    2124:      	mov	w8, #0x4                // =4
    2128:      	mov	w1, #0x10               // =16
    212c:      	mov	w25, #0x4               // =4
    2130:      	blr	x8
    2134:      	add	x2, x23, #0x38
    2138:      	mov	x0, x22
    213c:      	mov	w1, #0x10               // =16
    2140:      	blr	x25
    2144:      	ldr	x25, [sp, #0x30]
    2148:      	add	x2, x23, #0xe
    214c:      	mov	w21, #0x2               // =2
    2150:      	mov	w8, #0x4                // =4
    2154:      	mov	w1, #0x2                // =2
    2158:      	add	x22, x23, #0xc
    215c:      	mov	w23, #0x4               // =4
    2160:      	add	x0, x25, #0x20
    2164:      	blr	x8
    2168:      	add	x0, x25, #0x22
    216c:      	mov	w1, #0x2                // =2
    2170:      	mov	x2, x22
    2174:      	blr	x23
    2178:      	ldrh	w8, [x25, #0x22]
    217c:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    2180:      	add	x9, sp, #0x98
    2184:      	rev	w8, w8
    2188:      	lsr	w8, w8, #16
    218c:      	strh	w8, [x25, #0x22]
    2190:      	add	x8, sp, #0xe0
    2194:      	ldr	x8, [x8]
    2198:      	str	x8, [sp, #0x98]
    219c:      	mov	w8, #0x1                // =1
    21a0:      	ldr	x0, [x0]
    21a4:      	b	0x23f0 <generic_fentry_process_event+0x2060>
    21a8:      	ldr	x8, [sp, #0x48]
    21ac:      	adrp	x25, 0x2000 <generic_fentry_process_event+0x1c70>
    21b0:      	mov	w22, #0x8               // =8
    21b4:      	add	x8, x8, x29
    21b8:      	str	xzr, [x8, #0x90]
    21bc:      	ldr	x25, [x25]
    21c0:      	b	0x1008 <generic_fentry_process_event+0xc78>
    21c4:      	adrp	x25, 0x2000 <generic_fentry_process_event+0x1c70>
    21c8:      	mov	x22, xzr
    21cc:      	ldr	x25, [x25]
    21d0:      	b	0x1008 <generic_fentry_process_event+0xc78>
    21d4:      	mov	w8, #0xe                // =14
    21d8:      	blr	x8
    21dc:      	cmn	x0, #0x16
    21e0:      	b.ne	0x2204 <generic_fentry_process_event+0x1e74>
    21e4:      	add	x2, x19, #0xe8
    21e8:      	mov	w8, #0x8                // =8
    21ec:      	mov	w9, #0x4                // =4
    21f0:      	add	x10, sp, #0x98
    21f4:      	add	x0, sp, #0x98
    21f8:      	mov	w1, #0x8                // =8
    21fc:      	blr	x9
    2200:      	ldr	x0, [sp, #0x98]
    2204:      	ldr	x10, [x22, #0x8]
    2208:      	ldr	x9, [sp, #0x48]
    220c:      	mov	x3, xzr
    2210:      	add	x1, sp, #0xf0
    2214:      	add	x2, sp, #0x98
    2218:      	add	x21, sp, #0xe0
    221c:      	ldr	x8, [x22, #0x60]
    2220:      	str	xzr, [sp, #0xa8]
    2224:      	stp	x10, x9, [sp, #0x98]
    2228:      	add	x9, sp, #0xe0
    222c:      	add	x10, sp, #0x98
    2230:      	stp	x8, x0, [x9, #0x10]
    2234:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    2238:      	mov	w8, #0x2                // =2
    223c:      	add	x9, sp, #0xf0
    2240:      	ldr	x0, [x0]
    2244:      	blr	x8
    2248:      	cbz	x0, 0x264c <generic_fentry_process_event+0x22bc>
    224c:      	neg	w8, w0
    2250:      	adrp	x22, 0x2000 <generic_fentry_process_event+0x1c70>
    2254:      	mov	w9, #0x1                // =1
    2258:      	strh	w8, [sp, #0x100]
    225c:      	mov	w8, #0x5                // =5
    2260:      	add	x1, sp, #0x100
    2264:      	strh	w8, [sp, #0x102]
    2268:      	mov	x8, #0x46               // =70
    226c:      	movk	x8, #0x2, lsl #32
    2270:      	stur	x8, [x21, #0x24]
    2274:      	add	x8, sp, #0x100
    2278:      	mov	w21, #0x1               // =1
    227c:      	ldr	x22, [x22]
    2280:      	mov	x0, x22
    2284:      	blr	x9
    2288:      	cbnz	x0, 0x253c <generic_fentry_process_event+0x21ac>
    228c:      	str	w21, [sp, #0x90]
    2290:      	mov	x3, xzr
    2294:      	mov	w8, #0x2                // =2
    2298:      	add	x9, sp, #0x100
    229c:      	add	x10, sp, #0x90
    22a0:      	add	x1, sp, #0x100
    22a4:      	add	x2, sp, #0x90
    22a8:      	b	0x2644 <generic_fentry_process_event+0x22b4>
    22ac:      	cmp	w8, #0x1
    22b0:      	b.eq	0x2428 <generic_fentry_process_event+0x2098>
    22b4:      	cmp	w8, #0x2
    22b8:      	b.ne	0x2474 <generic_fentry_process_event+0x20e4>
    22bc:      	mov	w8, #0x5e58             // =24152
    22c0:      	b	0x242c <generic_fentry_process_event+0x209c>
    22c4:      	ldr	x23, [sp, #0x30]
    22c8:      	add	x2, x22, #0x8
    22cc:      	mov	w8, #0x10               // =16
    22d0:      	mov	w9, #0x4                // =4
    22d4:      	mov	w1, #0x10               // =16
    22d8:      	mov	w21, #0x4               // =4
    22dc:      	add	x0, x23, #0x8
    22e0:      	blr	x9
    22e4:      	add	x0, x23, #0x2
    22e8:      	add	x2, x22, #0x2
    22ec:      	mov	w8, #0x2                // =2
    22f0:      	mov	w1, #0x2                // =2
    22f4:      	blr	x21
    22f8:      	ldr	x9, [sp, #0x30]
    22fc:      	adrp	x25, 0x2000 <generic_fentry_process_event+0x1c70>
    2300:      	ldrh	w8, [x9, #0x2]
    2304:      	rev	w8, w8
    2308:      	lsr	w8, w8, #16
    230c:      	strh	w8, [x9, #0x2]
    2310:      	ldr	x25, [x25]
    2314:      	mov	w22, #0x18              // =24
    2318:      	b	0x1008 <generic_fentry_process_event+0xc78>
    231c:      	add	x2, x22, #0x3
    2320:      	mov	w21, #0x6b              // =107
    2324:      	mov	w8, #0x71               // =113
    2328:      	mov	w1, #0x6b               // =107
    232c:      	blr	x8
    2330:      	adrp	x25, 0x2000 <generic_fentry_process_event+0x1c70>
    2334:      	ldr	x25, [x25]
    2338:      	tbnz	w0, #0x1f, 0x2344 <generic_fentry_process_event+0x1fb4>
    233c:      	ldr	x8, [sp, #0x30]
    2340:      	strb	w21, [x8, #0x3]
    2344:      	mov	w22, #0x70              // =112
    2348:      	b	0x1008 <generic_fentry_process_event+0xc78>
    234c:      	cmp	w9, #0x1
    2350:      	b.eq	0x2670 <generic_fentry_process_event+0x22e0>
    2354:      	cmp	w9, #0x2
    2358:      	b.ne	0x267c <generic_fentry_process_event+0x22ec>
    235c:      	mov	w8, #0x5e58             // =24152
    2360:      	b	0x2674 <generic_fentry_process_event+0x22e4>
    2364:      	ldr	x0, [sp, #0x30]
    2368:      	add	x2, x23, #0x48
    236c:      	mov	w21, #0x10              // =16
    2370:      	mov	w8, #0x4                // =4
    2374:      	mov	w1, #0x10               // =16
    2378:      	mov	w25, #0x4               // =4
    237c:      	blr	x8
    2380:      	add	x2, x23, #0x38
    2384:      	mov	x0, x22
    2388:      	mov	w1, #0x10               // =16
    238c:      	blr	x25
    2390:      	ldr	x25, [sp, #0x30]
    2394:      	add	x2, x23, #0xe
    2398:      	mov	w21, #0x2               // =2
    239c:      	mov	w8, #0x4                // =4
    23a0:      	mov	w1, #0x2                // =2
    23a4:      	add	x22, x23, #0xc
    23a8:      	mov	w23, #0x4               // =4
    23ac:      	add	x0, x25, #0x20
    23b0:      	blr	x8
    23b4:      	add	x0, x25, #0x22
    23b8:      	mov	w1, #0x2                // =2
    23bc:      	mov	x2, x22
    23c0:      	blr	x23
    23c4:      	ldrh	w8, [x25, #0x22]
    23c8:      	rev	w8, w8
    23cc:      	lsr	w8, w8, #16
    23d0:      	strh	w8, [x25, #0x22]
    23d4:      	ldr	x8, [sp, #0x30]
    23d8:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    23dc:      	add	x9, sp, #0x98
    23e0:      	ldr	x8, [x8, #0x28]
    23e4:      	str	x8, [sp, #0x98]
    23e8:      	mov	w8, #0x1                // =1
    23ec:      	ldr	x0, [x0]
    23f0:      	add	x1, sp, #0x98
    23f4:      	blr	x8
    23f8:      	cbz	x0, 0x3170 <generic_fentry_process_event+0x2de0>
    23fc:      	ldr	w8, [x0]
    2400:      	str	w8, [x24, #0x10]
    2404:      	ldr	x8, [x0, #0x8]
    2408:      	str	x8, [x24, #0x18]
    240c:      	ldr	w8, [x0, #0x4]
    2410:      	str	w8, [x24, #0x7c]
    2414:      	b	0x3170 <generic_fentry_process_event+0x2de0>
    2418:      	mov	w8, #0x5e60             // =24160
    241c:      	b	0x242c <generic_fentry_process_event+0x209c>
    2420:      	mov	w8, #0x5e68             // =24168
    2424:      	b	0x242c <generic_fentry_process_event+0x209c>
    2428:      	mov	w8, #0x5e50             // =24144
    242c:      	add	x8, x24, x8
    2430:      	ldr	x29, [x8]
    2434:      	ldr	x8, [sp, #0x40]
    2438:      	tbnz	w8, #0x4, 0x2484 <generic_fentry_process_event+0x20f4>
    243c:      	cbz	x29, 0x2550 <generic_fentry_process_event+0x21c0>
    2440:      	ldr	x2, [sp, #0x48]
    2444:      	mov	w8, #0x10               // =16
    2448:      	mov	w9, #0x4                // =4
    244c:      	add	x10, sp, #0x98
    2450:      	add	x0, sp, #0x98
    2454:      	mov	w1, #0x10               // =16
    2458:      	blr	x9
    245c:      	tbnz	w0, #0x1f, 0x2a38 <generic_fentry_process_event+0x26a8>
    2460:      	ldr	x22, [sp, #0xa0]
    2464:      	cmp	x22, #0xffe
    2468:      	b.ls	0x27b4 <generic_fentry_process_event+0x2424>
    246c:      	mov	w8, #-0x3               // =-3
    2470:      	b	0x2a3c <generic_fentry_process_event+0x26ac>
    2474:      	ldr	x8, [sp, #0x40]
    2478:      	mov	x29, xzr
    247c:      	mov	x22, xzr
    2480:      	tbz	w8, #0x4, 0x2554 <generic_fentry_process_event+0x21c4>
    2484:      	mov	w8, #0xe                // =14
    2488:      	blr	x8
    248c:      	cmn	x0, #0x16
    2490:      	b.ne	0x24b4 <generic_fentry_process_event+0x2124>
    2494:      	add	x2, x19, #0xe8
    2498:      	mov	w8, #0x8                // =8
    249c:      	mov	w9, #0x4                // =4
    24a0:      	add	x10, sp, #0x98
    24a4:      	add	x0, sp, #0x98
    24a8:      	mov	w1, #0x8                // =8
    24ac:      	blr	x9
    24b0:      	ldr	x0, [sp, #0x98]
    24b4:      	ldr	x10, [x24, #0x8]
    24b8:      	ldr	x9, [sp, #0x48]
    24bc:      	mov	x3, xzr
    24c0:      	add	x1, sp, #0xf0
    24c4:      	add	x2, sp, #0x98
    24c8:      	add	x21, sp, #0xe0
    24cc:      	ldr	x8, [x24, #0x60]
    24d0:      	str	x29, [sp, #0xa8]
    24d4:      	stp	x10, x9, [sp, #0x98]
    24d8:      	add	x9, sp, #0xe0
    24dc:      	add	x10, sp, #0x98
    24e0:      	stp	x8, x0, [x9, #0x10]
    24e4:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    24e8:      	mov	w8, #0x2                // =2
    24ec:      	add	x9, sp, #0xf0
    24f0:      	ldr	x0, [x0]
    24f4:      	blr	x8
    24f8:      	cbz	x0, 0x264c <generic_fentry_process_event+0x22bc>
    24fc:      	neg	w8, w0
    2500:      	adrp	x22, 0x2000 <generic_fentry_process_event+0x1c70>
    2504:      	mov	w9, #0x1                // =1
    2508:      	strh	w8, [sp, #0x100]
    250c:      	mov	w8, #0x5                // =5
    2510:      	add	x1, sp, #0x100
    2514:      	strh	w8, [sp, #0x102]
    2518:      	mov	x8, #0x57               // =87
    251c:      	movk	x8, #0x2, lsl #32
    2520:      	stur	x8, [x21, #0x24]
    2524:      	add	x8, sp, #0x100
    2528:      	mov	w21, #0x1               // =1
    252c:      	ldr	x22, [x22]
    2530:      	mov	x0, x22
    2534:      	blr	x9
    2538:      	cbz	x0, 0x2628 <generic_fentry_process_event+0x2298>
    253c:      	ldr	w8, [x0]
    2540:      	add	w8, w8, #0x1
    2544:      	str	w8, [x0]
    2548:      	mov	w8, #-0x4               // =-4
    254c:      	b	0x2a3c <generic_fentry_process_event+0x26ac>
    2550:      	mov	x22, xzr
    2554:      	stp	w22, w22, [x25]
    2558:      	adrp	x25, 0x2000 <generic_fentry_process_event+0x1c70>
    255c:      	add	x22, x22, #0x8
    2560:      	ldr	x25, [x25]
    2564:      	b	0x1008 <generic_fentry_process_event+0xc78>
    2568:      	ldr	x9, [sp, #0x118]
    256c:      	str	wzr, [x29]
    2570:      	mov	w23, #0xc               // =12
    2574:      	add	w9, w9, #0x8
    2578:      	and	x9, x9, #0x3fff
    257c:      	add	x29, x8, x9
    2580:      	cmp	x22, #0xfff
    2584:      	mov	w8, #0xfff              // =4095
    2588:      	add	x0, x29, #0x8
    258c:      	mov	x2, x25
    2590:      	csel	x24, x22, x8, lo
    2594:      	mov	w8, #0x4                // =4
    2598:      	mov	w1, w24
    259c:      	blr	x8
    25a0:      	tbnz	w0, #0x1f, 0x25fc <generic_fentry_process_event+0x226c>
    25a4:      	stp	w22, w24, [x29]
    25a8:      	adrp	x25, 0x2000 <generic_fentry_process_event+0x1c70>
    25ac:      	add	x22, x23, x24
    25b0:      	ldr	x25, [x25]
    25b4:      	b	0x1008 <generic_fentry_process_event+0xc78>
    25b8:      	ldr	x9, [sp, #0x118]
    25bc:      	str	wzr, [x29]
    25c0:      	mov	w21, #0xc               // =12
    25c4:      	add	w9, w9, #0x8
    25c8:      	and	x9, x9, #0x3fff
    25cc:      	add	x29, x8, x9
    25d0:      	cmp	x22, #0xfff
    25d4:      	mov	w8, #0xfff              // =4095
    25d8:      	add	x0, x29, #0x8
    25dc:      	mov	x2, x23
    25e0:      	csel	x24, x22, x8, lo
    25e4:      	mov	w8, #0x4                // =4
    25e8:      	mov	w1, w24
    25ec:      	blr	x8
    25f0:      	tbnz	w0, #0x1f, 0x25fc <generic_fentry_process_event+0x226c>
    25f4:      	stp	w22, w24, [x29]
    25f8:      	b	0x27a4 <generic_fentry_process_event+0x2414>
    25fc:      	mov	w8, #-0x2               // =-2
    2600:      	str	w8, [x29]
    2604:      	b	0x2a40 <generic_fentry_process_event+0x26b0>
    2608:      	cmp	w8, #0x33
    260c:      	b.eq	0x2a50 <generic_fentry_process_event+0x26c0>
    2610:      	cmp	w8, #0x3c
    2614:      	b.eq	0x2654 <generic_fentry_process_event+0x22c4>
    2618:      	cmp	w8, #0xff
    261c:      	b.ne	0x2b14 <generic_fentry_process_event+0x2784>
    2620:      	mov	w8, #0x28               // =40
    2624:      	b	0x2a5c <generic_fentry_process_event+0x26cc>
    2628:      	str	w21, [sp, #0xe8]
    262c:      	mov	x3, xzr
    2630:      	mov	w8, #0x2                // =2
    2634:      	add	x9, sp, #0x100
    2638:      	add	x10, sp, #0xe8
    263c:      	add	x1, sp, #0x100
    2640:      	add	x2, sp, #0xe8
    2644:      	mov	x0, x22
    2648:      	blr	x8
    264c:      	mov	w8, #-0x4               // =-4
    2650:      	b	0x2a3c <generic_fentry_process_event+0x26ac>
    2654:      	ldrb	w8, [x23, #0x7]
    2658:      	lsl	w8, w8, #3
    265c:      	b	0x2a58 <generic_fentry_process_event+0x26c8>
    2660:      	mov	w8, #0x5e60             // =24160
    2664:      	b	0x2674 <generic_fentry_process_event+0x22e4>
    2668:      	mov	w8, #0x5e68             // =24168
    266c:      	b	0x2674 <generic_fentry_process_event+0x22e4>
    2670:      	mov	w8, #0x5e50             // =24144
    2674:      	add	x8, x22, x8
    2678:      	ldr	x8, [x8]
    267c:      	add	x22, sp, #0xe0
    2680:      	mov	w21, #0x8               // =8
    2684:      	add	x9, sp, #0xe0
    2688:      	str	x8, [x22, #0x8]
    268c:      	mov	w8, #0x4                // =4
    2690:      	add	x10, sp, #0xe8
    2694:      	add	x0, sp, #0xe0
    2698:      	add	x2, sp, #0xe8
    269c:      	mov	w1, #0x8                // =8
    26a0:      	blr	x8
    26a4:      	ldr	x22, [x22]
    26a8:      	tbz	w29, #0x5, 0x277c <generic_fentry_process_event+0x23ec>
    26ac:      	cmp	x22, #0x1, lsl #12      // =0x1000
    26b0:      	b.lo	0x2764 <generic_fentry_process_event+0x23d4>
    26b4:      	mov	w8, #0x1                // =1
    26b8:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    26bc:      	add	x9, sp, #0xf0
    26c0:      	str	w8, [x25]
    26c4:      	str	wzr, [sp, #0xf0]
    26c8:      	add	x1, sp, #0xf0
    26cc:      	ldr	x0, [x0]
    26d0:      	blr	x8
    26d4:      	cbz	x0, 0x2a40 <generic_fentry_process_event+0x26b0>
    26d8:      	mov	w8, #0x18               // =24
    26dc:      	mov	x24, x0
    26e0:      	str	w8, [x0]
    26e4:      	mov	w8, #0xe                // =14
    26e8:      	blr	x8
    26ec:      	mov	x21, x24
    26f0:      	cmn	x0, #0x16
    26f4:      	str	x0, [x21, #0x10]!
    26f8:      	b.ne	0x2720 <generic_fentry_process_event+0x2390>
    26fc:      	add	x2, x19, #0xe8
    2700:      	mov	w8, #0x8                // =8
    2704:      	mov	w9, #0x4                // =4
    2708:      	add	x10, sp, #0x98
    270c:      	add	x0, sp, #0x98
    2710:      	mov	w1, #0x8                // =8
    2714:      	blr	x9
    2718:      	ldr	x8, [sp, #0x98]
    271c:      	str	x8, [x21]
    2720:      	mov	w8, #0x7d               // =125
    2724:      	blr	x8
    2728:      	str	x0, [x24, #0x18]
    272c:      	ldr	x2, [sp, #0x48]
    2730:      	mov	x0, x19
    2734:      	mov	x1, x24
    2738:      	mov	x3, x22
    273c:      	ldp	x8, x9, [x21]
    2740:      	stur	x9, [x25, #0x1c]
    2744:      	stur	x8, [x25, #0x14]
    2748:      	bl	0x2748 <generic_fentry_process_event+0x23b8>
    274c:      	tbnz	w0, #0x1f, 0x2b38 <generic_fentry_process_event+0x27a8>
    2750:      	sub	w8, w22, w0
    2754:      	cmn	x22, #0x1
    2758:      	stur	xzr, [x25, #0x4]
    275c:      	csel	w8, wzr, w8, eq
    2760:      	b	0x2b44 <generic_fentry_process_event+0x27b4>
    2764:      	ldr	x8, [sp, #0x118]
    2768:      	str	wzr, [x25]
    276c:      	mov	w21, #0xc               // =12
    2770:      	add	w8, w8, #0x8
    2774:      	and	x8, x8, #0x3fff
    2778:      	add	x25, x23, x8
    277c:      	cmp	x22, #0xfff
    2780:      	mov	w8, #0xfff              // =4095
    2784:      	ldr	x2, [sp, #0x48]
    2788:      	add	x0, x25, #0x8
    278c:      	csel	x24, x22, x8, lo
    2790:      	mov	w8, #0x4                // =4
    2794:      	mov	w1, w24
    2798:      	blr	x8
    279c:      	tbnz	w0, #0x1f, 0x2a38 <generic_fentry_process_event+0x26a8>
    27a0:      	stp	w22, w24, [x25]
    27a4:      	adrp	x25, 0x2000 <generic_fentry_process_event+0x1c70>
    27a8:      	add	x22, x21, x24
    27ac:      	ldr	x25, [x25]
    27b0:      	b	0x1008 <generic_fentry_process_event+0xc78>
    27b4:      	ldr	x8, [sp, #0x118]
    27b8:      	mov	w9, #0x4                // =4
    27bc:      	mov	w1, w22
    27c0:      	add	x21, x8, #0xc
    27c4:      	and	x8, x21, #0x3fff
    27c8:      	add	x0, x23, x8
    27cc:      	ldr	x8, [sp, #0x98]
    27d0:      	ldr	x2, [sp, #0x98]
    27d4:      	blr	x9
    27d8:      	tbnz	w0, #0x1f, 0x2a38 <generic_fentry_process_event+0x26a8>
    27dc:      	cmp	x29, #0x1
    27e0:      	b.eq	0x2554 <generic_fentry_process_event+0x21c4>
    27e4:      	ldr	x8, [sp, #0x48]
    27e8:      	mov	w9, #0x4                // =4
    27ec:      	add	x10, sp, #0x98
    27f0:      	add	x0, sp, #0x98
    27f4:      	mov	w1, #0x10               // =16
    27f8:      	add	x2, x8, #0x10
    27fc:      	mov	w8, #0x10               // =16
    2800:      	blr	x9
    2804:      	tbnz	w0, #0x1f, 0x2a38 <generic_fentry_process_event+0x26a8>
    2808:      	ldr	x24, [sp, #0xa0]
    280c:      	cmp	x24, #0xffe
    2810:      	b.hi	0x246c <generic_fentry_process_event+0x20dc>
    2814:      	add	x21, x22, x21
    2818:      	mov	w9, #0x4                // =4
    281c:      	mov	w1, w24
    2820:      	and	x8, x21, #0x3fff
    2824:      	add	x0, x23, x8
    2828:      	ldr	x8, [sp, #0x98]
    282c:      	ldr	x2, [sp, #0x98]
    2830:      	blr	x9
    2834:      	tbnz	w0, #0x1f, 0x2a38 <generic_fentry_process_event+0x26a8>
    2838:      	add	x22, x24, x22
    283c:      	cmp	x29, #0x3
    2840:      	b.lo	0x2554 <generic_fentry_process_event+0x21c4>
    2844:      	ldr	x8, [sp, #0x48]
    2848:      	mov	w9, #0x4                // =4
    284c:      	add	x10, sp, #0x98
    2850:      	add	x0, sp, #0x98
    2854:      	mov	w1, #0x10               // =16
    2858:      	add	x2, x8, #0x20
    285c:      	mov	w8, #0x10               // =16
    2860:      	blr	x9
    2864:      	tbnz	w0, #0x1f, 0x2a38 <generic_fentry_process_event+0x26a8>
    2868:      	ldr	x8, [sp, #0xa0]
    286c:      	cmp	x8, #0xffe
    2870:      	str	x8, [sp, #0x40]
    2874:      	b.hi	0x246c <generic_fentry_process_event+0x20dc>
    2878:      	add	x21, x24, x21
    287c:      	mov	w9, #0x4                // =4
    2880:      	ldr	x1, [sp, #0x40]
    2884:      	and	x8, x21, #0x3fff
    2888:      	add	x0, x23, x8
    288c:      	ldr	x8, [sp, #0x98]
    2890:      	ldr	x2, [sp, #0x98]
    2894:      	blr	x9
    2898:      	tbnz	w0, #0x1f, 0x2a38 <generic_fentry_process_event+0x26a8>
    289c:      	ldr	x8, [sp, #0x40]
    28a0:      	cmp	x29, #0x3
    28a4:      	add	x22, x8, x22
    28a8:      	b.eq	0x2554 <generic_fentry_process_event+0x21c4>
    28ac:      	ldr	x8, [sp, #0x48]
    28b0:      	mov	w9, #0x4                // =4
    28b4:      	add	x10, sp, #0x98
    28b8:      	add	x0, sp, #0x98
    28bc:      	mov	w1, #0x10               // =16
    28c0:      	add	x2, x8, #0x30
    28c4:      	mov	w8, #0x10               // =16
    28c8:      	blr	x9
    28cc:      	tbnz	w0, #0x1f, 0x2a38 <generic_fentry_process_event+0x26a8>
    28d0:      	ldr	x24, [sp, #0xa0]
    28d4:      	cmp	x24, #0xffe
    28d8:      	b.hi	0x246c <generic_fentry_process_event+0x20dc>
    28dc:      	ldr	x8, [sp, #0x40]
    28e0:      	mov	w9, #0x4                // =4
    28e4:      	mov	w1, w24
    28e8:      	add	x21, x8, x21
    28ec:      	and	x8, x21, #0x3fff
    28f0:      	add	x0, x23, x8
    28f4:      	ldr	x8, [sp, #0x98]
    28f8:      	ldr	x2, [sp, #0x98]
    28fc:      	blr	x9
    2900:      	tbnz	w0, #0x1f, 0x2a38 <generic_fentry_process_event+0x26a8>
    2904:      	add	x22, x24, x22
    2908:      	cmp	x29, #0x5
    290c:      	b.lo	0x2554 <generic_fentry_process_event+0x21c4>
    2910:      	ldr	x8, [sp, #0x48]
    2914:      	mov	w9, #0x4                // =4
    2918:      	add	x10, sp, #0x98
    291c:      	add	x0, sp, #0x98
    2920:      	mov	w1, #0x10               // =16
    2924:      	add	x2, x8, #0x40
    2928:      	mov	w8, #0x10               // =16
    292c:      	blr	x9
    2930:      	tbnz	w0, #0x1f, 0x2a38 <generic_fentry_process_event+0x26a8>
    2934:      	ldr	x8, [sp, #0xa0]
    2938:      	cmp	x8, #0xffe
    293c:      	str	x8, [sp, #0x40]
    2940:      	b.hi	0x246c <generic_fentry_process_event+0x20dc>
    2944:      	add	x21, x24, x21
    2948:      	mov	w9, #0x4                // =4
    294c:      	ldr	x1, [sp, #0x40]
    2950:      	and	x8, x21, #0x3fff
    2954:      	add	x0, x23, x8
    2958:      	ldr	x8, [sp, #0x98]
    295c:      	ldr	x2, [sp, #0x98]
    2960:      	blr	x9
    2964:      	tbnz	w0, #0x1f, 0x2a38 <generic_fentry_process_event+0x26a8>
    2968:      	ldr	x8, [sp, #0x40]
    296c:      	cmp	x29, #0x5
    2970:      	add	x22, x8, x22
    2974:      	b.eq	0x2554 <generic_fentry_process_event+0x21c4>
    2978:      	ldr	x8, [sp, #0x48]
    297c:      	mov	w9, #0x4                // =4
    2980:      	add	x10, sp, #0x98
    2984:      	add	x0, sp, #0x98
    2988:      	mov	w1, #0x10               // =16
    298c:      	add	x2, x8, #0x50
    2990:      	mov	w8, #0x10               // =16
    2994:      	blr	x9
    2998:      	tbnz	w0, #0x1f, 0x2a38 <generic_fentry_process_event+0x26a8>
    299c:      	ldr	x24, [sp, #0xa0]
    29a0:      	cmp	x24, #0xffe
    29a4:      	b.hi	0x246c <generic_fentry_process_event+0x20dc>
    29a8:      	ldr	x8, [sp, #0x40]
    29ac:      	mov	w9, #0x4                // =4
    29b0:      	mov	w1, w24
    29b4:      	add	x21, x8, x21
    29b8:      	and	x8, x21, #0x3fff
    29bc:      	add	x0, x23, x8
    29c0:      	ldr	x8, [sp, #0x98]
    29c4:      	ldr	x2, [sp, #0x98]
    29c8:      	blr	x9
    29cc:      	tbnz	w0, #0x1f, 0x2a38 <generic_fentry_process_event+0x26a8>
    29d0:      	add	x22, x24, x22
    29d4:      	cmp	x29, #0x7
    29d8:      	b.lo	0x2554 <generic_fentry_process_event+0x21c4>
    29dc:      	ldr	x8, [sp, #0x48]
    29e0:      	mov	w9, #0x4                // =4
    29e4:      	add	x10, sp, #0x98
    29e8:      	add	x0, sp, #0x98
    29ec:      	mov	w1, #0x10               // =16
    29f0:      	add	x2, x8, #0x60
    29f4:      	mov	w8, #0x10               // =16
    29f8:      	blr	x9
    29fc:      	tbnz	w0, #0x1f, 0x2a38 <generic_fentry_process_event+0x26a8>
    2a00:      	ldr	x29, [sp, #0xa0]
    2a04:      	cmp	x29, #0xffe
    2a08:      	b.hi	0x246c <generic_fentry_process_event+0x20dc>
    2a0c:      	add	x8, x24, x21
    2a10:      	mov	w9, #0x4                // =4
    2a14:      	mov	w1, w29
    2a18:      	and	x8, x8, #0x3fff
    2a1c:      	add	x0, x23, x8
    2a20:      	ldr	x8, [sp, #0x98]
    2a24:      	ldr	x2, [sp, #0x98]
    2a28:      	blr	x9
    2a2c:      	tbnz	w0, #0x1f, 0x2a38 <generic_fentry_process_event+0x26a8>
    2a30:      	add	x22, x29, x22
    2a34:      	b	0x2554 <generic_fentry_process_event+0x21c4>
    2a38:      	mov	w8, #-0x2               // =-2
    2a3c:      	str	w8, [x25]
    2a40:      	adrp	x25, 0x2000 <generic_fentry_process_event+0x1c70>
    2a44:      	mov	w22, #0x4               // =4
    2a48:      	ldr	x25, [x25]
    2a4c:      	b	0x1008 <generic_fentry_process_event+0xc78>
    2a50:      	ldrb	w8, [x23, #0x7]
    2a54:      	lsl	w8, w8, #2
    2a58:      	add	w8, w8, #0x8
    2a5c:      	strh	w8, [x23, #0x2]
    2a60:      	ldrh	w9, [x23]
    2a64:      	ldrb	w29, [x23, #0x6]
    2a68:      	add	w8, w9, w8
    2a6c:      	cmp	w29, #0x3c
    2a70:      	strh	w8, [x23]
    2a74:      	b.hi	0x2b30 <generic_fentry_process_event+0x27a0>
    2a78:      	mov	x21, #0x1               // =1
    2a7c:      	mov	w9, #0x1                // =1
    2a80:      	movk	x21, #0x1800, lsl #32
    2a84:      	lsl	x9, x9, x29
    2a88:      	movk	x21, #0x1008, lsl #48
    2a8c:      	tst	x9, x21
    2a90:      	b.eq	0x2b30 <generic_fentry_process_event+0x27a0>
    2a94:      	ldr	x11, [sp, #0x48]
    2a98:      	strb	w29, [x23, #0x5]
    2a9c:      	mov	w9, #0x2                // =2
    2aa0:      	mov	w10, #0x4               // =4
    2aa4:      	mov	x0, x22
    2aa8:      	mov	w1, #0x2                // =2
    2aac:      	add	x8, x11, w8, uxth
    2ab0:      	ldrh	w8, [x23]
    2ab4:      	add	x2, x11, x8
    2ab8:      	blr	x10
    2abc:      	tbnz	x0, #0x3f, 0x2ff0 <generic_fentry_process_event+0x2c60>
    2ac0:      	ldrb	w8, [x23, #0x5]
    2ac4:      	cmp	w8, #0x32
    2ac8:      	b.gt	0x2ae8 <generic_fentry_process_event+0x2758>
    2acc:      	cbz	w8, 0x2b08 <generic_fentry_process_event+0x2778>
    2ad0:      	cmp	w8, #0x2b
    2ad4:      	b.eq	0x2b08 <generic_fentry_process_event+0x2778>
    2ad8:      	cmp	w8, #0x2c
    2adc:      	b.ne	0x2c10 <generic_fentry_process_event+0x2880>
    2ae0:      	mov	w8, #0x8                // =8
    2ae4:      	b	0x2b64 <generic_fentry_process_event+0x27d4>
    2ae8:      	cmp	w8, #0x33
    2aec:      	b.eq	0x2b58 <generic_fentry_process_event+0x27c8>
    2af0:      	cmp	w8, #0x3c
    2af4:      	b.eq	0x2b08 <generic_fentry_process_event+0x2778>
    2af8:      	cmp	w8, #0xff
    2afc:      	b.ne	0x2c10 <generic_fentry_process_event+0x2880>
    2b00:      	mov	w8, #0x28               // =40
    2b04:      	b	0x2b64 <generic_fentry_process_event+0x27d4>
    2b08:      	ldrb	w8, [x23, #0x7]
    2b0c:      	lsl	w8, w8, #3
    2b10:      	b	0x2b60 <generic_fentry_process_event+0x27d0>
    2b14:      	ldrh	w8, [x23, #0x2]
    2b18:      	ldrh	w9, [x23]
    2b1c:      	ldrb	w29, [x23, #0x6]
    2b20:      	add	w8, w9, w8
    2b24:      	cmp	w29, #0x3c
    2b28:      	strh	w8, [x23]
    2b2c:      	b.ls	0x2a78 <generic_fentry_process_event+0x26e8>
    2b30:      	strh	w8, [sp, #0x90]
    2b34:      	b	0x2ff4 <generic_fentry_process_event+0x2c64>
    2b38:      	mov	w8, wzr
    2b3c:      	stp	w0, wzr, [x25, #0x4]
    2b40:      	mov	w0, wzr
    2b44:      	stp	w8, w0, [x25, #0xc]
    2b48:      	adrp	x25, 0x2000 <generic_fentry_process_event+0x1c70>
    2b4c:      	mov	w22, #0x24              // =36
    2b50:      	ldr	x25, [x25]
    2b54:      	b	0x1008 <generic_fentry_process_event+0xc78>
    2b58:      	ldrb	w8, [x23, #0x7]
    2b5c:      	lsl	w8, w8, #2
    2b60:      	add	w8, w8, #0x8
    2b64:      	strh	w8, [x23, #0x2]
    2b68:      	ldrh	w9, [x23]
    2b6c:      	ldrb	w29, [x23, #0x6]
    2b70:      	add	w8, w9, w8
    2b74:      	cmp	w29, #0x3c
    2b78:      	strh	w8, [x23]
    2b7c:      	b.hi	0x319c <generic_fentry_process_event+0x2e0c>
    2b80:      	mov	w9, #0x1                // =1
    2b84:      	lsl	x9, x9, x29
    2b88:      	tst	x9, x21
    2b8c:      	b.eq	0x319c <generic_fentry_process_event+0x2e0c>
    2b90:      	ldr	x11, [sp, #0x48]
    2b94:      	strb	w29, [x23, #0x5]
    2b98:      	mov	w9, #0x2                // =2
    2b9c:      	mov	w10, #0x4               // =4
    2ba0:      	mov	x0, x22
    2ba4:      	mov	w1, #0x2                // =2
    2ba8:      	add	x8, x11, w8, uxth
    2bac:      	ldrh	w8, [x23]
    2bb0:      	add	x2, x11, x8
    2bb4:      	blr	x10
    2bb8:      	tbnz	x0, #0x3f, 0x2ff0 <generic_fentry_process_event+0x2c60>
    2bbc:      	ldrb	w8, [x23, #0x5]
    2bc0:      	cmp	w8, #0x32
    2bc4:      	b.gt	0x2be4 <generic_fentry_process_event+0x2854>
    2bc8:      	cbz	w8, 0x2c04 <generic_fentry_process_event+0x2874>
    2bcc:      	cmp	w8, #0x2b
    2bd0:      	b.eq	0x2c04 <generic_fentry_process_event+0x2874>
    2bd4:      	cmp	w8, #0x2c
    2bd8:      	b.ne	0x2ce8 <generic_fentry_process_event+0x2958>
    2bdc:      	mov	w8, #0x8                // =8
    2be0:      	b	0x2c3c <generic_fentry_process_event+0x28ac>
    2be4:      	cmp	w8, #0x33
    2be8:      	b.eq	0x2c30 <generic_fentry_process_event+0x28a0>
    2bec:      	cmp	w8, #0x3c
    2bf0:      	b.eq	0x2c04 <generic_fentry_process_event+0x2874>
    2bf4:      	cmp	w8, #0xff
    2bf8:      	b.ne	0x2ce8 <generic_fentry_process_event+0x2958>
    2bfc:      	mov	w8, #0x28               // =40
    2c00:      	b	0x2c3c <generic_fentry_process_event+0x28ac>
    2c04:      	ldrb	w8, [x23, #0x7]
    2c08:      	lsl	w8, w8, #3
    2c0c:      	b	0x2c38 <generic_fentry_process_event+0x28a8>
    2c10:      	ldrh	w8, [x23, #0x2]
    2c14:      	ldrh	w9, [x23]
    2c18:      	ldrb	w29, [x23, #0x6]
    2c1c:      	add	w8, w9, w8
    2c20:      	cmp	w29, #0x3c
    2c24:      	strh	w8, [x23]
    2c28:      	b.ls	0x2b80 <generic_fentry_process_event+0x27f0>
    2c2c:      	b	0x319c <generic_fentry_process_event+0x2e0c>
    2c30:      	ldrb	w8, [x23, #0x7]
    2c34:      	lsl	w8, w8, #2
    2c38:      	add	w8, w8, #0x8
    2c3c:      	strh	w8, [x23, #0x2]
    2c40:      	ldrh	w9, [x23]
    2c44:      	ldrb	w29, [x23, #0x6]
    2c48:      	add	w8, w9, w8
    2c4c:      	cmp	w29, #0x3c
    2c50:      	strh	w8, [x23]
    2c54:      	b.hi	0x319c <generic_fentry_process_event+0x2e0c>
    2c58:      	mov	w9, #0x1                // =1
    2c5c:      	lsl	x9, x9, x29
    2c60:      	tst	x9, x21
    2c64:      	b.eq	0x319c <generic_fentry_process_event+0x2e0c>
    2c68:      	ldr	x11, [sp, #0x48]
    2c6c:      	strb	w29, [x23, #0x5]
    2c70:      	mov	w9, #0x2                // =2
    2c74:      	mov	w10, #0x4               // =4
    2c78:      	mov	x0, x22
    2c7c:      	mov	w1, #0x2                // =2
    2c80:      	add	x8, x11, w8, uxth
    2c84:      	ldrh	w8, [x23]
    2c88:      	add	x2, x11, x8
    2c8c:      	blr	x10
    2c90:      	tbnz	x0, #0x3f, 0x2ff0 <generic_fentry_process_event+0x2c60>
    2c94:      	ldrb	w8, [x23, #0x5]
    2c98:      	cmp	w8, #0x32
    2c9c:      	b.gt	0x2cbc <generic_fentry_process_event+0x292c>
    2ca0:      	cbz	w8, 0x2cdc <generic_fentry_process_event+0x294c>
    2ca4:      	cmp	w8, #0x2b
    2ca8:      	b.eq	0x2cdc <generic_fentry_process_event+0x294c>
    2cac:      	cmp	w8, #0x2c
    2cb0:      	b.ne	0x2dc0 <generic_fentry_process_event+0x2a30>
    2cb4:      	mov	w8, #0x8                // =8
    2cb8:      	b	0x2d14 <generic_fentry_process_event+0x2984>
    2cbc:      	cmp	w8, #0x33
    2cc0:      	b.eq	0x2d08 <generic_fentry_process_event+0x2978>
    2cc4:      	cmp	w8, #0x3c
    2cc8:      	b.eq	0x2cdc <generic_fentry_process_event+0x294c>
    2ccc:      	cmp	w8, #0xff
    2cd0:      	b.ne	0x2dc0 <generic_fentry_process_event+0x2a30>
    2cd4:      	mov	w8, #0x28               // =40
    2cd8:      	b	0x2d14 <generic_fentry_process_event+0x2984>
    2cdc:      	ldrb	w8, [x23, #0x7]
    2ce0:      	lsl	w8, w8, #3
    2ce4:      	b	0x2d10 <generic_fentry_process_event+0x2980>
    2ce8:      	ldrh	w8, [x23, #0x2]
    2cec:      	ldrh	w9, [x23]
    2cf0:      	ldrb	w29, [x23, #0x6]
    2cf4:      	add	w8, w9, w8
    2cf8:      	cmp	w29, #0x3c
    2cfc:      	strh	w8, [x23]
    2d00:      	b.ls	0x2c58 <generic_fentry_process_event+0x28c8>
    2d04:      	b	0x319c <generic_fentry_process_event+0x2e0c>
    2d08:      	ldrb	w8, [x23, #0x7]
    2d0c:      	lsl	w8, w8, #2
    2d10:      	add	w8, w8, #0x8
    2d14:      	strh	w8, [x23, #0x2]
    2d18:      	ldrh	w9, [x23]
    2d1c:      	ldrb	w29, [x23, #0x6]
    2d20:      	add	w8, w9, w8
    2d24:      	cmp	w29, #0x3c
    2d28:      	strh	w8, [x23]
    2d2c:      	b.hi	0x319c <generic_fentry_process_event+0x2e0c>
    2d30:      	mov	w9, #0x1                // =1
    2d34:      	lsl	x9, x9, x29
    2d38:      	tst	x9, x21
    2d3c:      	b.eq	0x319c <generic_fentry_process_event+0x2e0c>
    2d40:      	ldr	x11, [sp, #0x48]
    2d44:      	strb	w29, [x23, #0x5]
    2d48:      	mov	w9, #0x2                // =2
    2d4c:      	mov	w10, #0x4               // =4
    2d50:      	mov	x0, x22
    2d54:      	mov	w1, #0x2                // =2
    2d58:      	add	x8, x11, w8, uxth
    2d5c:      	ldrh	w8, [x23]
    2d60:      	add	x2, x11, x8
    2d64:      	blr	x10
    2d68:      	tbnz	x0, #0x3f, 0x2ff0 <generic_fentry_process_event+0x2c60>
    2d6c:      	ldrb	w8, [x23, #0x5]
    2d70:      	cmp	w8, #0x32
    2d74:      	b.gt	0x2d94 <generic_fentry_process_event+0x2a04>
    2d78:      	cbz	w8, 0x2db4 <generic_fentry_process_event+0x2a24>
    2d7c:      	cmp	w8, #0x2b
    2d80:      	b.eq	0x2db4 <generic_fentry_process_event+0x2a24>
    2d84:      	cmp	w8, #0x2c
    2d88:      	b.ne	0x2e98 <generic_fentry_process_event+0x2b08>
    2d8c:      	mov	w8, #0x8                // =8
    2d90:      	b	0x2dec <generic_fentry_process_event+0x2a5c>
    2d94:      	cmp	w8, #0x33
    2d98:      	b.eq	0x2de0 <generic_fentry_process_event+0x2a50>
    2d9c:      	cmp	w8, #0x3c
    2da0:      	b.eq	0x2db4 <generic_fentry_process_event+0x2a24>
    2da4:      	cmp	w8, #0xff
    2da8:      	b.ne	0x2e98 <generic_fentry_process_event+0x2b08>
    2dac:      	mov	w8, #0x28               // =40
    2db0:      	b	0x2dec <generic_fentry_process_event+0x2a5c>
    2db4:      	ldrb	w8, [x23, #0x7]
    2db8:      	lsl	w8, w8, #3
    2dbc:      	b	0x2de8 <generic_fentry_process_event+0x2a58>
    2dc0:      	ldrh	w8, [x23, #0x2]
    2dc4:      	ldrh	w9, [x23]
    2dc8:      	ldrb	w29, [x23, #0x6]
    2dcc:      	add	w8, w9, w8
    2dd0:      	cmp	w29, #0x3c
    2dd4:      	strh	w8, [x23]
    2dd8:      	b.ls	0x2d30 <generic_fentry_process_event+0x29a0>
    2ddc:      	b	0x319c <generic_fentry_process_event+0x2e0c>
    2de0:      	ldrb	w8, [x23, #0x7]
    2de4:      	lsl	w8, w8, #2
    2de8:      	add	w8, w8, #0x8
    2dec:      	strh	w8, [x23, #0x2]
    2df0:      	ldrh	w9, [x23]
    2df4:      	ldrb	w29, [x23, #0x6]
    2df8:      	add	w8, w9, w8
    2dfc:      	cmp	w29, #0x3c
    2e00:      	strh	w8, [x23]
    2e04:      	b.hi	0x319c <generic_fentry_process_event+0x2e0c>
    2e08:      	mov	w9, #0x1                // =1
    2e0c:      	lsl	x9, x9, x29
    2e10:      	tst	x9, x21
    2e14:      	b.eq	0x319c <generic_fentry_process_event+0x2e0c>
    2e18:      	ldr	x11, [sp, #0x48]
    2e1c:      	strb	w29, [x23, #0x5]
    2e20:      	mov	w9, #0x2                // =2
    2e24:      	mov	w10, #0x4               // =4
    2e28:      	mov	x0, x22
    2e2c:      	mov	w1, #0x2                // =2
    2e30:      	add	x8, x11, w8, uxth
    2e34:      	ldrh	w8, [x23]
    2e38:      	add	x2, x11, x8
    2e3c:      	blr	x10
    2e40:      	tbnz	x0, #0x3f, 0x2ff0 <generic_fentry_process_event+0x2c60>
    2e44:      	ldrb	w8, [x23, #0x5]
    2e48:      	cmp	w8, #0x32
    2e4c:      	b.gt	0x2e6c <generic_fentry_process_event+0x2adc>
    2e50:      	cbz	w8, 0x2e8c <generic_fentry_process_event+0x2afc>
    2e54:      	cmp	w8, #0x2b
    2e58:      	b.eq	0x2e8c <generic_fentry_process_event+0x2afc>
    2e5c:      	cmp	w8, #0x2c
    2e60:      	b.ne	0x2f70 <generic_fentry_process_event+0x2be0>
    2e64:      	mov	w8, #0x8                // =8
    2e68:      	b	0x2ec4 <generic_fentry_process_event+0x2b34>
    2e6c:      	cmp	w8, #0x33
    2e70:      	b.eq	0x2eb8 <generic_fentry_process_event+0x2b28>
    2e74:      	cmp	w8, #0x3c
    2e78:      	b.eq	0x2e8c <generic_fentry_process_event+0x2afc>
    2e7c:      	cmp	w8, #0xff
    2e80:      	b.ne	0x2f70 <generic_fentry_process_event+0x2be0>
    2e84:      	mov	w8, #0x28               // =40
    2e88:      	b	0x2ec4 <generic_fentry_process_event+0x2b34>
    2e8c:      	ldrb	w8, [x23, #0x7]
    2e90:      	lsl	w8, w8, #3
    2e94:      	b	0x2ec0 <generic_fentry_process_event+0x2b30>
    2e98:      	ldrh	w8, [x23, #0x2]
    2e9c:      	ldrh	w9, [x23]
    2ea0:      	ldrb	w29, [x23, #0x6]
    2ea4:      	add	w8, w9, w8
    2ea8:      	cmp	w29, #0x3c
    2eac:      	strh	w8, [x23]
    2eb0:      	b.ls	0x2e08 <generic_fentry_process_event+0x2a78>
    2eb4:      	b	0x319c <generic_fentry_process_event+0x2e0c>
    2eb8:      	ldrb	w8, [x23, #0x7]
    2ebc:      	lsl	w8, w8, #2
    2ec0:      	add	w8, w8, #0x8
    2ec4:      	strh	w8, [x23, #0x2]
    2ec8:      	ldrh	w9, [x23]
    2ecc:      	ldrb	w29, [x23, #0x6]
    2ed0:      	add	w8, w9, w8
    2ed4:      	cmp	w29, #0x3c
    2ed8:      	strh	w8, [x23]
    2edc:      	b.hi	0x319c <generic_fentry_process_event+0x2e0c>
    2ee0:      	mov	w9, #0x1                // =1
    2ee4:      	lsl	x9, x9, x29
    2ee8:      	tst	x9, x21
    2eec:      	b.eq	0x319c <generic_fentry_process_event+0x2e0c>
    2ef0:      	ldr	x11, [sp, #0x48]
    2ef4:      	strb	w29, [x23, #0x5]
    2ef8:      	mov	w9, #0x2                // =2
    2efc:      	mov	w10, #0x4               // =4
    2f00:      	mov	x0, x22
    2f04:      	mov	w1, #0x2                // =2
    2f08:      	add	x8, x11, w8, uxth
    2f0c:      	ldrh	w8, [x23]
    2f10:      	add	x2, x11, x8
    2f14:      	blr	x10
    2f18:      	tbnz	x0, #0x3f, 0x2ff0 <generic_fentry_process_event+0x2c60>
    2f1c:      	ldrb	w8, [x23, #0x5]
    2f20:      	cmp	w8, #0x32
    2f24:      	b.gt	0x2f44 <generic_fentry_process_event+0x2bb4>
    2f28:      	cbz	w8, 0x2f64 <generic_fentry_process_event+0x2bd4>
    2f2c:      	cmp	w8, #0x2b
    2f30:      	b.eq	0x2f64 <generic_fentry_process_event+0x2bd4>
    2f34:      	cmp	w8, #0x2c
    2f38:      	b.ne	0x3180 <generic_fentry_process_event+0x2df0>
    2f3c:      	mov	w8, #0x8                // =8
    2f40:      	b	0x2f9c <generic_fentry_process_event+0x2c0c>
    2f44:      	cmp	w8, #0x33
    2f48:      	b.eq	0x2f90 <generic_fentry_process_event+0x2c00>
    2f4c:      	cmp	w8, #0x3c
    2f50:      	b.eq	0x2f64 <generic_fentry_process_event+0x2bd4>
    2f54:      	cmp	w8, #0xff
    2f58:      	b.ne	0x3180 <generic_fentry_process_event+0x2df0>
    2f5c:      	mov	w8, #0x28               // =40
    2f60:      	b	0x2f9c <generic_fentry_process_event+0x2c0c>
    2f64:      	ldrb	w8, [x23, #0x7]
    2f68:      	lsl	w8, w8, #3
    2f6c:      	b	0x2f98 <generic_fentry_process_event+0x2c08>
    2f70:      	ldrh	w8, [x23, #0x2]
    2f74:      	ldrh	w9, [x23]
    2f78:      	ldrb	w29, [x23, #0x6]
    2f7c:      	add	w8, w9, w8
    2f80:      	cmp	w29, #0x3c
    2f84:      	strh	w8, [x23]
    2f88:      	b.ls	0x2ee0 <generic_fentry_process_event+0x2b50>
    2f8c:      	b	0x319c <generic_fentry_process_event+0x2e0c>
    2f90:      	ldrb	w8, [x23, #0x7]
    2f94:      	lsl	w8, w8, #2
    2f98:      	add	w8, w8, #0x8
    2f9c:      	strh	w8, [x23, #0x2]
    2fa0:      	ldrh	w9, [x23]
    2fa4:      	ldrb	w29, [x23, #0x6]
    2fa8:      	add	w8, w9, w8
    2fac:      	cmp	w29, #0x3c
    2fb0:      	strh	w8, [x23]
    2fb4:      	b.hi	0x319c <generic_fentry_process_event+0x2e0c>
    2fb8:      	mov	w9, #0x1                // =1
    2fbc:      	lsl	x9, x9, x29
    2fc0:      	tst	x9, x21
    2fc4:      	b.eq	0x319c <generic_fentry_process_event+0x2e0c>
    2fc8:      	ldr	x11, [sp, #0x48]
    2fcc:      	strb	w29, [x23, #0x5]
    2fd0:      	mov	w9, #0x2                // =2
    2fd4:      	mov	w10, #0x4               // =4
    2fd8:      	mov	x0, x22
    2fdc:      	mov	w1, #0x2                // =2
    2fe0:      	add	x8, x11, w8, uxth
    2fe4:      	ldrh	w8, [x23]
    2fe8:      	add	x2, x11, x8
    2fec:      	blr	x10
    2ff0:      	mov	w29, wzr
    2ff4:      	ldr	x23, [sp, #0x30]
    2ff8:      	mov	w8, #0xa                // =10
    2ffc:      	strb	w29, [sp, #0x84]
    3000:      	add	x2, x25, #0x8
    3004:      	mov	w21, #0x10              // =16
    3008:      	mov	w1, #0x10               // =16
    300c:      	mov	w22, #0x4               // =4
    3010:      	strh	w29, [x23, #0x24]
    3014:      	strh	w8, [x23, #0x26]
    3018:      	mov	w8, #0x4                // =4
    301c:      	mov	x0, x23
    3020:      	blr	x8
    3024:      	add	x0, x23, #0x10
    3028:      	add	x2, x25, #0x18
    302c:      	mov	w1, #0x10               // =16
    3030:      	blr	x22
    3034:      	cmp	w29, #0x11
    3038:      	b.eq	0x307c <generic_fentry_process_event+0x2cec>
    303c:      	cmp	w29, #0x6
    3040:      	b.ne	0x30bc <generic_fentry_process_event+0x2d2c>
    3044:      	ldr	x8, [sp, #0x98]
    3048:      	ldrh	w9, [sp, #0x90]
    304c:      	mov	w21, #0x2               // =2
    3050:      	mov	w1, #0x2                // =2
    3054:      	mov	w23, #0x4               // =4
    3058:      	add	x22, x8, x9
    305c:      	ldr	x25, [sp, #0x30]
    3060:      	add	x0, x25, #0x20
    3064:      	mov	w8, #0x4                // =4
    3068:      	mov	x2, x22
    306c:      	blr	x8
    3070:      	add	x0, x25, #0x22
    3074:      	add	x2, x22, #0x2
    3078:      	b	0x30b0 <generic_fentry_process_event+0x2d20>
    307c:      	ldr	x8, [sp, #0x98]
    3080:      	ldrh	w9, [sp, #0x90]
    3084:      	mov	w21, #0x2               // =2
    3088:      	mov	w1, #0x2                // =2
    308c:      	mov	w23, #0x4               // =4
    3090:      	add	x22, x8, x9
    3094:      	ldr	x25, [sp, #0x30]
    3098:      	add	x0, x25, #0x20
    309c:      	mov	w8, #0x4                // =4
    30a0:      	mov	x2, x22
    30a4:      	blr	x8
    30a8:      	add	x0, x25, #0x22
    30ac:      	add	x2, x22, #0x2
    30b0:      	mov	w1, #0x2                // =2
    30b4:      	blr	x23
    30b8:      	b	0x30c4 <generic_fentry_process_event+0x2d34>
    30bc:      	ldr	x8, [sp, #0x30]
    30c0:      	str	wzr, [x8, #0x20]
    30c4:      	ldr	x9, [sp, #0x30]
    30c8:      	add	x2, x24, #0xe0
    30cc:      	add	x10, sp, #0xf0
    30d0:      	add	x0, sp, #0xf0
    30d4:      	ldrh	w8, [x9, #0x20]
    30d8:      	mov	w1, #0x8                // =8
    30dc:      	rev	w8, w8
    30e0:      	lsr	w8, w8, #16
    30e4:      	strh	w8, [x9, #0x20]
    30e8:      	ldrh	w8, [x9, #0x22]
    30ec:      	rev	w8, w8
    30f0:      	lsr	w8, w8, #16
    30f4:      	strh	w8, [x9, #0x22]
    30f8:      	mov	w8, #0x8                // =8
    30fc:      	mov	w9, #0x4                // =4
    3100:      	blr	x9
    3104:      	add	x8, sp, #0xe0
    3108:      	ldr	x8, [x8, #0x10]
    310c:      	cbz	x8, 0x3170 <generic_fentry_process_event+0x2de0>
    3110:      	add	x8, x8, #0x5
    3114:      	mov	w9, #0x8                // =8
    3118:      	add	x10, sp, #0x100
    311c:      	mov	w11, #0x4               // =4
    3120:      	add	x22, sp, #0xe0
    3124:      	ldr	x8, [x22, #0x10]
    3128:      	add	x0, sp, #0x100
    312c:      	mov	w1, #0x8                // =8
    3130:      	mov	w21, #0x4               // =4
    3134:      	add	x2, x8, #0x5
    3138:      	blr	x11
    313c:      	ldr	x8, [x22, #0x10]
    3140:      	ldr	x9, [x22, #0x20]
    3144:      	mov	w1, #0x4                // =4
    3148:      	add	x22, x8, x9, lsl #3
    314c:      	ldr	x23, [sp, #0x30]
    3150:      	add	x0, x23, #0x38
    3154:      	mov	w8, #0x4                // =4
    3158:      	add	x2, x22, #0x44
    315c:      	blr	x8
    3160:      	add	x0, x23, #0x3c
    3164:      	add	x2, x22, #0x45
    3168:      	mov	w1, #0x4                // =4
    316c:      	blr	x21
    3170:      	adrp	x25, 0x3000 <generic_fentry_process_event+0x2c70>
    3174:      	mov	w22, #0x40              // =64
    3178:      	ldr	x25, [x25]
    317c:      	b	0x1008 <generic_fentry_process_event+0xc78>
    3180:      	ldrh	w8, [x23, #0x2]
    3184:      	ldrh	w9, [x23]
    3188:      	ldrb	w29, [x23, #0x6]
    318c:      	add	w8, w9, w8
    3190:      	cmp	w29, #0x3c
    3194:      	strh	w8, [x23]
    3198:      	b.ls	0x2fb8 <generic_fentry_process_event+0x2c28>
    319c:      	strh	w8, [sp, #0x90]
    31a0:      	b	0x2ff4 <generic_fentry_process_event+0x2c64>
    31a4:      	nop
    31a8:      	nop
    31ac:      	nop

00000000000031b0 <generic_fentry_process_filter>:
    31b0:      	sub	sp, sp, #0x130
    31b4:      	str	x29, [sp, #0xe0]
    31b8:      	stp	x30, x25, [sp, #0xf0]
    31bc:      	stp	x24, x23, [sp, #0x100]
    31c0:      	stp	x22, x21, [sp, #0x110]
    31c4:      	stp	x20, x19, [sp, #0x120]
    31c8:      	mov	x20, x0
    31cc:      	str	wzr, [sp, #0x54]
    31d0:      	adrp	x0, 0x3000 <generic_fentry_process_event+0x2c70>
    31d4:      	mov	w8, #0x1                // =1
    31d8:      	ldr	x0, [x0]
    31dc:      	add	x9, sp, #0x54
    31e0:      	add	x1, sp, #0x54
    31e4:      	blr	x8
    31e8:      	cbz	x0, 0x54ec <generic_fentry_process_filter+0x233c>
    31ec:      	mov	w8, #0x5ec0             // =24256
    31f0:      	mov	x22, x0
    31f4:      	add	x29, x0, x8
    31f8:      	mov	w8, #0x23               // =35
    31fc:      	blr	x8
    3200:      	str	x0, [sp, #0x58]
    3204:      	add	x8, x0, #0x8d4
    3208:      	mov	w9, #0x4                // =4
    320c:      	mov	w10, #0x71              // =113
    3210:      	add	x11, sp, #0xd8
    3214:      	add	x0, sp, #0xd8
    3218:      	mov	w1, #0x4                // =4
    321c:      	ldr	x8, [sp, #0x58]
    3220:      	add	x2, x8, #0x8d4
    3224:      	blr	x10
    3228:      	ldr	w8, [sp, #0xd8]
    322c:      	adrp	x19, 0x3000 <generic_fentry_process_event+0x2c70>
    3230:      	add	x9, sp, #0xc8
    3234:      	add	x1, sp, #0xc8
    3238:      	str	w8, [sp, #0xc8]
    323c:      	mov	w8, #0x1                // =1
    3240:      	ldr	x19, [x19]
    3244:      	mov	x0, x19
    3248:      	blr	x8
    324c:      	cbz	x0, 0x325c <generic_fentry_process_filter+0xac>
    3250:      	ldr	x8, [x0, #0x8]
    3254:      	mov	x24, x0
    3258:      	cbnz	x8, 0x404c <generic_fentry_process_filter+0xe9c>
    325c:      	ldr	x8, [sp, #0x58]
    3260:      	mov	w9, #0x8                // =8
    3264:      	mov	w10, #0x71              // =113
    3268:      	add	x11, sp, #0x58
    326c:      	add	x0, sp, #0x58
    3270:      	mov	w1, #0x8                // =8
    3274:      	add	x8, x8, #0x8e0
    3278:      	ldr	x8, [sp, #0x58]
    327c:      	add	x2, x8, #0x8e0
    3280:      	blr	x10
    3284:      	ldr	x8, [sp, #0x58]
    3288:      	cbz	x8, 0x3404 <generic_fentry_process_filter+0x254>
    328c:      	add	x8, x8, #0x8d4
    3290:      	mov	w9, #0x4                // =4
    3294:      	mov	w10, #0x71              // =113
    3298:      	add	x11, sp, #0xd8
    329c:      	ldr	x8, [sp, #0x58]
    32a0:      	add	x0, sp, #0xd8
    32a4:      	mov	w1, #0x4                // =4
    32a8:      	add	x2, x8, #0x8d4
    32ac:      	blr	x10
    32b0:      	ldr	w8, [sp, #0xd8]
    32b4:      	add	x9, sp, #0xc8
    32b8:      	add	x1, sp, #0xc8
    32bc:      	mov	x0, x19
    32c0:      	str	w8, [sp, #0xc8]
    32c4:      	mov	w8, #0x1                // =1
    32c8:      	blr	x8
    32cc:      	cbz	x0, 0x32dc <generic_fentry_process_filter+0x12c>
    32d0:      	ldr	x8, [x0, #0x8]
    32d4:      	mov	x24, x0
    32d8:      	cbnz	x8, 0x404c <generic_fentry_process_filter+0xe9c>
    32dc:      	ldr	x8, [sp, #0x58]
    32e0:      	mov	w9, #0x8                // =8
    32e4:      	mov	w10, #0x71              // =113
    32e8:      	add	x11, sp, #0x58
    32ec:      	add	x0, sp, #0x58
    32f0:      	mov	w1, #0x8                // =8
    32f4:      	add	x8, x8, #0x8e0
    32f8:      	ldr	x8, [sp, #0x58]
    32fc:      	add	x2, x8, #0x8e0
    3300:      	blr	x10
    3304:      	ldr	x8, [sp, #0x58]
    3308:      	cbz	x8, 0x3404 <generic_fentry_process_filter+0x254>
    330c:      	add	x8, x8, #0x8d4
    3310:      	mov	w9, #0x4                // =4
    3314:      	mov	w10, #0x71              // =113
    3318:      	add	x11, sp, #0xd8
    331c:      	ldr	x8, [sp, #0x58]
    3320:      	add	x0, sp, #0xd8
    3324:      	mov	w1, #0x4                // =4
    3328:      	add	x2, x8, #0x8d4
    332c:      	blr	x10
    3330:      	ldr	w8, [sp, #0xd8]
    3334:      	add	x9, sp, #0xc8
    3338:      	add	x1, sp, #0xc8
    333c:      	mov	x0, x19
    3340:      	str	w8, [sp, #0xc8]
    3344:      	mov	w8, #0x1                // =1
    3348:      	blr	x8
    334c:      	cbz	x0, 0x335c <generic_fentry_process_filter+0x1ac>
    3350:      	ldr	x8, [x0, #0x8]
    3354:      	mov	x24, x0
    3358:      	cbnz	x8, 0x404c <generic_fentry_process_filter+0xe9c>
    335c:      	ldr	x8, [sp, #0x58]
    3360:      	mov	w9, #0x8                // =8
    3364:      	mov	w10, #0x71              // =113
    3368:      	add	x11, sp, #0x58
    336c:      	add	x0, sp, #0x58
    3370:      	mov	w1, #0x8                // =8
    3374:      	add	x8, x8, #0x8e0
    3378:      	ldr	x8, [sp, #0x58]
    337c:      	add	x2, x8, #0x8e0
    3380:      	blr	x10
    3384:      	ldr	x8, [sp, #0x58]
    3388:      	cbz	x8, 0x3404 <generic_fentry_process_filter+0x254>
    338c:      	add	x8, x8, #0x8d4
    3390:      	mov	w9, #0x4                // =4
    3394:      	mov	w10, #0x71              // =113
    3398:      	add	x11, sp, #0xd8
    339c:      	ldr	x8, [sp, #0x58]
    33a0:      	add	x0, sp, #0xd8
    33a4:      	mov	w1, #0x4                // =4
    33a8:      	add	x2, x8, #0x8d4
    33ac:      	blr	x10
    33b0:      	ldr	w8, [sp, #0xd8]
    33b4:      	add	x9, sp, #0xc8
    33b8:      	add	x1, sp, #0xc8
    33bc:      	mov	x0, x19
    33c0:      	str	w8, [sp, #0xc8]
    33c4:      	mov	w8, #0x1                // =1
    33c8:      	blr	x8
    33cc:      	cbz	x0, 0x33dc <generic_fentry_process_filter+0x22c>
    33d0:      	ldr	x8, [x0, #0x8]
    33d4:      	mov	x24, x0
    33d8:      	cbnz	x8, 0x404c <generic_fentry_process_filter+0xe9c>
    33dc:      	ldr	x8, [sp, #0x58]
    33e0:      	mov	w9, #0x8                // =8
    33e4:      	mov	w10, #0x71              // =113
    33e8:      	add	x11, sp, #0x58
    33ec:      	add	x0, sp, #0x58
    33f0:      	mov	w1, #0x8                // =8
    33f4:      	add	x8, x8, #0x8e0
    33f8:      	ldr	x8, [sp, #0x58]
    33fc:      	add	x2, x8, #0x8e0
    3400:      	blr	x10
    3404:      	str	x20, [sp, #0x38]
    3408:      	mov	w8, #0x23               // =35
    340c:      	blr	x8
    3410:      	add	x2, x0, #0x8d4
    3414:      	mov	w8, #0x4                // =4
    3418:      	add	x9, sp, #0x58
    341c:      	mov	x24, x0
    3420:      	add	x0, sp, #0x58
    3424:      	mov	w1, #0x4                // =4
    3428:      	blr	x8
    342c:      	ldr	w8, [sp, #0x58]
    3430:      	mov	x19, x29
    3434:      	str	w8, [x19, #0x50]!
    3438:      	mov	w8, #0x7d               // =125
    343c:      	blr	x8
    3440:      	str	x0, [x22, #0x5f18]
    3444:      	str	wzr, [x19, #0x10]
    3448:      	add	x2, x24, #0x60
    344c:      	mov	w8, #0x8                // =8
    3450:      	mov	w9, #0x71               // =113
    3454:      	add	x10, sp, #0xc8
    3458:      	str	xzr, [x22, #0x5f28]
    345c:      	str	x19, [sp, #0x48]
    3460:      	add	x0, sp, #0xc8
    3464:      	mov	w1, #0x8                // =8
    3468:      	str	wzr, [x19, #0x20]
    346c:      	blr	x9
    3470:      	ldr	x8, [sp, #0xc8]
    3474:      	cbz	x8, 0x34e4 <generic_fentry_process_filter+0x334>
    3478:      	add	x8, x8, #0x4
    347c:      	mov	w9, #0x4                // =4
    3480:      	mov	w10, #0x71              // =113
    3484:      	add	x11, sp, #0xd8
    3488:      	ldr	x8, [sp, #0xc8]
    348c:      	add	x0, sp, #0xd8
    3490:      	mov	w1, #0x4                // =4
    3494:      	add	x2, x8, #0x4
    3498:      	blr	x10
    349c:      	ldr	w8, [sp, #0xd8]
    34a0:      	cbz	w8, 0x34e4 <generic_fentry_process_filter+0x334>
    34a4:      	ldr	x9, [sp, #0xc8]
    34a8:      	lsl	w8, w8, #4
    34ac:      	mov	w10, #0x71              // =113
    34b0:      	add	x11, sp, #0x58
    34b4:      	add	x0, sp, #0x58
    34b8:      	mov	w1, #0x10               // =16
    34bc:      	add	x8, x9, x8
    34c0:      	mov	w9, #0x10               // =16
    34c4:      	add	x8, x8, #0x80
    34c8:      	ldr	w9, [sp, #0xd8]
    34cc:      	ldr	x8, [sp, #0xc8]
    34d0:      	lsl	w9, w9, #4
    34d4:      	add	x8, x8, x9
    34d8:      	add	x2, x8, #0x80
    34dc:      	blr	x10
    34e0:      	ldr	w8, [sp, #0x58]
    34e4:      	str	w8, [x29, #0x74]
    34e8:      	mov	w8, #0x5f60             // =24416
    34ec:      	str	x22, [sp, #0xe8]
    34f0:      	add	x23, x24, #0xae0
    34f4:      	mov	w19, #0x8               // =8
    34f8:      	add	x25, x22, x8
    34fc:      	add	x8, sp, #0x58
    3500:      	mov	w9, #0x4                // =4
    3504:      	add	x0, sp, #0x58
    3508:      	mov	w1, #0x8                // =8
    350c:      	mov	x2, x23
    3510:      	mov	w21, #0x4               // =4
    3514:      	blr	x9
    3518:      	ldr	x20, [sp, #0x58]
    351c:      	ldr	x9, [sp, #0xe8]
    3520:      	mov	w8, #0x5f68             // =24424
    3524:      	mov	w1, #0x8                // =8
    3528:      	add	x0, x9, x8
    352c:      	add	x2, x20, #0x40
    3530:      	mov	w8, #0x4                // =4
    3534:      	blr	x8
    3538:      	ldr	x9, [sp, #0xe8]
    353c:      	mov	w8, #0x5f70             // =24432
    3540:      	add	x2, x20, #0x30
    3544:      	mov	w1, #0x8                // =8
    3548:      	add	x0, x9, x8
    354c:      	mov	w8, #0x4                // =4
    3550:      	blr	x8
    3554:      	add	x2, x20, #0x38
    3558:      	mov	w8, #0x4                // =4
    355c:      	mov	x0, x25
    3560:      	mov	w1, #0x8                // =8
    3564:      	blr	x8
    3568:      	ldr	x9, [sp, #0xe8]
    356c:      	mov	w8, #0x5f38             // =24376
    3570:      	add	x2, x24, #0xb50
    3574:      	add	x0, sp, #0xd8
    3578:      	mov	w1, #0x8                // =8
    357c:      	add	x25, x9, x8
    3580:      	add	x8, sp, #0xd8
    3584:      	mov	w9, #0x4                // =4
    3588:      	blr	x9
    358c:      	add	x12, sp, #0xd8
    3590:      	mov	w9, #0x48               // =72
    3594:      	add	x10, sp, #0x58
    3598:      	ldr	x8, [x12]
    359c:      	mov	w11, #0x4               // =4
    35a0:      	add	x0, sp, #0x58
    35a4:      	mov	w1, #0x48               // =72
    35a8:      	ldr	x2, [x12]
    35ac:      	blr	x11
    35b0:      	ldr	x8, [sp, #0x60]
    35b4:      	mov	w9, #0x4                // =4
    35b8:      	mov	x0, x25
    35bc:      	mov	w1, #0x4                // =4
    35c0:      	add	x8, x8, #0x218
    35c4:      	ldr	x8, [sp, #0x60]
    35c8:      	ldr	x22, [sp, #0xe8]
    35cc:      	add	x2, x8, #0x218
    35d0:      	blr	x9
    35d4:      	mov	w8, #0x5f3c             // =24380
    35d8:      	mov	w9, #0x4                // =4
    35dc:      	mov	w1, #0x4                // =4
    35e0:      	add	x0, x22, x8
    35e4:      	ldr	x8, [sp, #0x68]
    35e8:      	add	x8, x8, #0x4d8
    35ec:      	ldr	x8, [sp, #0x68]
    35f0:      	add	x2, x8, #0x4d8
    35f4:      	blr	x9
    35f8:      	mov	w8, #0x5f40             // =24384
    35fc:      	mov	w9, #0x4                // =4
    3600:      	mov	w1, #0x4                // =4
    3604:      	add	x0, x22, x8
    3608:      	ldr	x8, [sp, #0x70]
    360c:      	add	x8, x8, #0x58
    3610:      	ldr	x8, [sp, #0x70]
    3614:      	add	x2, x8, #0x58
    3618:      	blr	x9
    361c:      	str	xzr, [sp, #0xc0]
    3620:      	add	x2, x24, #0x938
    3624:      	add	x8, sp, #0xc0
    3628:      	add	x0, sp, #0xc0
    362c:      	mov	w1, #0x8                // =8
    3630:      	blr	x21
    3634:      	ldr	x8, [sp, #0xc0]
    3638:      	cbz	x8, 0x36c0 <generic_fentry_process_filter+0x510>
    363c:      	str	wzr, [sp, #0xb8]
    3640:      	add	x8, x8, #0x4
    3644:      	add	x9, sp, #0xb8
    3648:      	mov	w10, #0x4               // =4
    364c:      	add	x0, sp, #0xb8
    3650:      	mov	w1, #0x4                // =4
    3654:      	mov	w19, #0x4               // =4
    3658:      	ldr	x8, [sp, #0xc0]
    365c:      	add	x2, x8, #0x4
    3660:      	blr	x10
    3664:      	ldr	x8, [sp, #0xc0]
    3668:      	ldrsw	x9, [sp, #0xb8]
    366c:      	add	x10, sp, #0xc8
    3670:      	mov	w11, #0x4               // =4
    3674:      	add	x0, sp, #0xc8
    3678:      	mov	w1, #0x10               // =16
    367c:      	add	x8, x8, x9, lsl #4
    3680:      	mov	w9, #0x10               // =16
    3684:      	add	x8, x8, #0x80
    3688:      	ldr	x8, [sp, #0xc0]
    368c:      	ldrsw	x9, [sp, #0xb8]
    3690:      	add	x8, x8, x9, lsl #4
    3694:      	add	x2, x8, #0x80
    3698:      	blr	x11
    369c:      	mov	w8, #0x5f44             // =24388
    36a0:      	mov	w1, #0x4                // =4
    36a4:      	add	x0, x22, x8
    36a8:      	ldr	x8, [sp, #0xd0]
    36ac:      	add	x8, x8, #0x158
    36b0:      	ldr	x8, [sp, #0xd0]
    36b4:      	add	x2, x8, #0x158
    36b8:      	blr	x19
    36bc:      	b	0x36c4 <generic_fentry_process_filter+0x514>
    36c0:      	str	wzr, [x29, #0x84]
    36c4:      	mov	w8, #0x5f48             // =24392
    36c8:      	mov	w9, #0x4                // =4
    36cc:      	mov	w1, #0x4                // =4
    36d0:      	mov	w19, #0x4               // =4
    36d4:      	add	x0, x22, x8
    36d8:      	ldr	x8, [sp, #0x78]
    36dc:      	add	x8, x8, #0x158
    36e0:      	ldr	x8, [sp, #0x78]
    36e4:      	add	x2, x8, #0x158
    36e8:      	blr	x9
    36ec:      	mov	w8, #0x5f4c             // =24396
    36f0:      	mov	w9, #0x4                // =4
    36f4:      	mov	w1, #0x4                // =4
    36f8:      	add	x0, x22, x8
    36fc:      	ldr	x8, [sp, #0x80]
    3700:      	add	x8, x8, #0x118
    3704:      	ldr	x8, [sp, #0x80]
    3708:      	add	x2, x8, #0x118
    370c:      	blr	x9
    3710:      	mov	w8, #0x5f50             // =24400
    3714:      	mov	w9, #0x4                // =4
    3718:      	mov	w1, #0x4                // =4
    371c:      	add	x0, x22, x8
    3720:      	ldr	x8, [sp, #0x88]
    3724:      	add	x8, x8, #0x98
    3728:      	ldr	x8, [sp, #0x88]
    372c:      	add	x2, x8, #0x98
    3730:      	blr	x9
    3734:      	mov	w8, #0x5f54             // =24404
    3738:      	mov	w9, #0x4                // =4
    373c:      	mov	w1, #0x4                // =4
    3740:      	add	x0, x22, x8
    3744:      	ldr	x8, [sp, #0x90]
    3748:      	add	x8, x8, #0x98
    374c:      	ldr	x8, [sp, #0x90]
    3750:      	add	x2, x8, #0x98
    3754:      	blr	x9
    3758:      	mov	w8, #0x5f58             // =24408
    375c:      	mov	w9, #0x4                // =4
    3760:      	mov	w1, #0x4                // =4
    3764:      	add	x0, x22, x8
    3768:      	ldr	x8, [sp, #0x98]
    376c:      	add	x8, x8, #0x58
    3770:      	ldr	x8, [sp, #0x98]
    3774:      	add	x2, x8, #0x58
    3778:      	blr	x9
    377c:      	stp	xzr, xzr, [sp, #0xc0]
    3780:      	mov	w20, #0x8               // =8
    3784:      	add	x8, sp, #0xc8
    3788:      	mov	w9, #0x4                // =4
    378c:      	add	x0, sp, #0xc8
    3790:      	mov	w1, #0x8                // =8
    3794:      	mov	x2, x23
    3798:      	blr	x9
    379c:      	ldr	x8, [sp, #0xc8]
    37a0:      	add	x9, sp, #0xc0
    37a4:      	mov	w10, #0x4               // =4
    37a8:      	add	x0, sp, #0xc0
    37ac:      	mov	w1, #0x8                // =8
    37b0:      	add	x8, x8, #0x90
    37b4:      	ldr	x8, [sp, #0xc8]
    37b8:      	add	x2, x8, #0x90
    37bc:      	blr	x10
    37c0:      	mov	w8, #0x5f5c             // =24412
    37c4:      	mov	w1, #0x4                // =4
    37c8:      	add	x0, x22, x8
    37cc:      	ldr	x8, [sp, #0xc0]
    37d0:      	add	x8, x8, #0x158
    37d4:      	ldr	x8, [sp, #0xc0]
    37d8:      	add	x2, x8, #0x158
    37dc:      	blr	x19
    37e0:      	ldr	w8, [x29, #0x74]
    37e4:      	cmp	w8, #0x1
    37e8:      	b.ne	0x37f8 <generic_fentry_process_filter+0x648>
    37ec:      	ldr	w8, [x29, #0x70]
    37f0:      	orr	w8, w8, #0x2000000
    37f4:      	str	w8, [x29, #0x70]
    37f8:      	add	x0, x29, #0xb8
    37fc:      	mov	w1, wzr
    3800:      	mov	w2, #0x308              // =776
    3804:      	bl	0x3804 <generic_fentry_process_filter+0x654>
    3808:      	mov	w8, #0x6290             // =25232
    380c:      	add	x2, x24, #0x858
    3810:      	mov	w19, #0x8               // =8
    3814:      	mov	w9, #0x4                // =4
    3818:      	add	x0, sp, #0xc8
    381c:      	mov	w1, #0x8                // =8
    3820:      	mov	w20, #0x4               // =4
    3824:      	add	x21, x22, x8
    3828:      	add	x8, sp, #0xc8
    382c:      	blr	x9
    3830:      	ldr	x8, [sp, #0xc8]
    3834:      	add	x9, sp, #0x58
    3838:      	add	x0, sp, #0x58
    383c:      	mov	w1, #0x8                // =8
    3840:      	add	x8, x8, #0x528
    3844:      	ldr	x8, [sp, #0xc8]
    3848:      	add	x2, x8, #0x528
    384c:      	blr	x20
    3850:      	str	wzr, [sp, #0xa4]
    3854:      	adrp	x0, 0x3000 <generic_fentry_process_event+0x2c70>
    3858:      	ldr	x19, [sp, #0x58]
    385c:      	mov	w8, #0x1                // =1
    3860:      	add	x9, sp, #0xa4
    3864:      	add	x1, sp, #0xa4
    3868:      	ldr	x0, [x0]
    386c:      	blr	x8
    3870:      	cbz	x0, 0x3e94 <generic_fentry_process_filter+0xce4>
    3874:      	mov	w8, #0x1000             // =4096
    3878:      	str	x21, [sp, #0x30]
    387c:      	str	x29, [sp, #0x40]
    3880:      	mov	x24, x0
    3884:      	add	x20, x0, #0x1, lsl #12  // =0x1000
    3888:      	str	w8, [x29, #0x550]
    388c:      	mov	w8, #0x23               // =35
    3890:      	blr	x8
    3894:      	add	x2, x0, #0xb30
    3898:      	mov	w23, #0x8               // =8
    389c:      	add	x8, sp, #0xa8
    38a0:      	mov	w9, #0x4                // =4
    38a4:      	add	x0, sp, #0xa8
    38a8:      	mov	w1, #0x8                // =8
    38ac:      	mov	w29, #0x4               // =4
    38b0:      	blr	x9
    38b4:      	ldr	x22, [sp, #0xa8]
    38b8:      	add	x25, x19, #0x48
    38bc:      	add	x8, sp, #0xb0
    38c0:      	mov	w9, #0x4                // =4
    38c4:      	add	x0, sp, #0xb0
    38c8:      	mov	w1, #0x8                // =8
    38cc:      	mov	x2, x25
    38d0:      	blr	x9
    38d4:      	ldr	x21, [sp, #0xb0]
    38d8:      	add	x8, sp, #0x58
    38dc:      	add	x0, sp, #0x58
    38e0:      	mov	w1, #0x8                // =8
    38e4:      	add	x2, x21, #0x10
    38e8:      	blr	x29
    38ec:      	ldr	x8, [sp, #0x58]
    38f0:      	cbz	x8, 0x3b30 <generic_fentry_process_filter+0x980>
    38f4:      	ldr	x8, [sp, #0x40]
    38f8:      	stp	xzr, xzr, [sp, #0x58]
    38fc:      	add	x21, x22, #0x18
    3900:      	add	x9, sp, #0x58
    3904:      	add	x2, x22, #0x20
    3908:      	mov	w22, #0x8               // =8
    390c:      	stp	x24, xzr, [sp, #0x68]
    3910:      	add	x0, sp, #0x58
    3914:      	mov	w1, #0x8                // =8
    3918:      	add	x29, x19, #0x40
    391c:      	add	x19, x9, #0x8
    3920:      	add	x24, x9, #0x18
    3924:      	stp	xzr, xzr, [sp, #0x78]
    3928:      	add	x23, x9, #0x20
    392c:      	str	x20, [sp, #0x88]
    3930:      	str	x20, [sp, #0x28]
    3934:      	mov	w20, #0x4               // =4
    3938:      	ldr	w8, [x8, #0x550]
    393c:      	strb	wzr, [sp, #0x94]
    3940:      	str	w8, [sp, #0x90]
    3944:      	mov	w8, #0x4                // =4
    3948:      	blr	x8
    394c:      	mov	w8, #0x4                // =4
    3950:      	mov	x0, x19
    3954:      	mov	w1, #0x8                // =8
    3958:      	mov	x2, x21
    395c:      	blr	x8
    3960:      	mov	w8, #0x4                // =4
    3964:      	mov	x0, x24
    3968:      	mov	w1, #0x8                // =8
    396c:      	mov	x2, x25
    3970:      	blr	x8
    3974:      	mov	x0, x23
    3978:      	mov	w1, #0x8                // =8
    397c:      	mov	x2, x29
    3980:      	blr	x20
    3984:      	ldr	x8, [sp, #0x78]
    3988:      	sub	x8, x8, #0x20
    398c:      	str	x8, [sp, #0x80]
    3990:      	adrp	x8, 0x3000 <generic_fentry_process_event+0x2c70>
    3994:      	ldr	x8, [x8]
    3998:      	ldrb	w8, [x8]
    399c:      	cbz	w8, 0x3b84 <generic_fentry_process_filter+0x9d4>
    39a0:      	mov	w19, #0x800             // =2048
    39a4:      	mov	w21, #0x8               // =8
    39a8:      	add	x23, sp, #0xb8
    39ac:      	add	x29, sp, #0xd8
    39b0:      	b	0x3a10 <generic_fentry_process_filter+0x860>
    39b4:      	nop
    39b8:      	nop
    39bc:      	nop
    39c0:      	add	x2, x22, #0x10
    39c4:      	mov	w8, #0x4                // =4
    39c8:      	add	x0, sp, #0xd8
    39cc:      	mov	w1, #0x8                // =8
    39d0:      	blr	x8
    39d4:      	add	x20, sp, #0xd8
    39d8:      	ldr	x8, [sp, #0x80]
    39dc:      	ldr	x9, [x20]
    39e0:      	cmp	x8, x9
    39e4:      	b.eq	0x3d10 <generic_fentry_process_filter+0xb60>
    39e8:      	add	x2, x22, #0x18
    39ec:      	mov	w8, #0x4                // =4
    39f0:      	mov	x0, x24
    39f4:      	mov	w1, #0x8                // =8
    39f8:      	blr	x8
    39fc:      	ldr	x8, [x20]
    3a00:      	add	x9, x8, #0x20
    3a04:      	stp	x9, x8, [sp, #0x78]
    3a08:      	subs	w19, w19, #0x1
    3a0c:      	b.eq	0x3d18 <generic_fentry_process_filter+0xb68>
    3a10:      	ldp	x20, x2, [sp, #0x70]
    3a14:      	ldp	x8, x9, [sp, #0x58]
    3a18:      	cmp	x20, x8
    3a1c:      	ccmp	x2, x9, #0x0, eq
    3a20:      	b.eq	0x3d10 <generic_fentry_process_filter+0xb60>
    3a24:      	ldr	x22, [sp, #0x80]
    3a28:      	mov	w8, #0x4                // =4
    3a2c:      	add	x0, sp, #0xb8
    3a30:      	mov	w1, #0x8                // =8
    3a34:      	blr	x8
    3a38:      	ldr	x8, [sp, #0xb8]
    3a3c:      	cmp	x20, x8
    3a40:      	b.eq	0x39c0 <generic_fentry_process_filter+0x810>
    3a44:      	add	x25, x20, #0x18
    3a48:      	mov	w8, #0x4                // =4
    3a4c:      	add	x0, sp, #0xd8
    3a50:      	mov	w1, #0x8                // =8
    3a54:      	mov	x2, x25
    3a58:      	blr	x8
    3a5c:      	add	x8, sp, #0xd8
    3a60:      	ldr	x8, [x8]
    3a64:      	cmp	x8, x20
    3a68:      	b.eq	0x39c0 <generic_fentry_process_filter+0x810>
    3a6c:      	mov	w8, #0x4                // =4
    3a70:      	add	x9, sp, #0xc0
    3a74:      	add	x0, sp, #0xc0
    3a78:      	mov	w1, #0x8                // =8
    3a7c:      	mov	x2, x25
    3a80:      	blr	x8
    3a84:      	add	x2, x20, #0x20
    3a88:      	mov	w8, #0x4                // =4
    3a8c:      	mov	w9, #0x10               // =16
    3a90:      	add	x10, sp, #0xc8
    3a94:      	add	x0, sp, #0xc8
    3a98:      	mov	w1, #0x10               // =16
    3a9c:      	blr	x8
    3aa0:      	ldr	w20, [sp, #0xcc]
    3aa4:      	ldr	x8, [sp, #0x68]
    3aa8:      	ldr	x10, [sp, #0x88]
    3aac:      	sub	x12, x10, x8
    3ab0:      	ldr	w22, [sp, #0x90]
    3ab4:      	subs	w10, w20, w22
    3ab8:      	ldr	x9, [sp, #0xd0]
    3abc:      	csel	w10, wzr, w10, lo
    3ac0:      	cmp	w22, w20
    3ac4:      	csel	w11, w22, w20, lo
    3ac8:      	cinc	w13, w11, hi
    3acc:      	sub	w14, w22, w13
    3ad0:      	subs	x12, x12, x13
    3ad4:      	str	w14, [sp, #0x90]
    3ad8:      	b.lo	0x3d18 <generic_fentry_process_filter+0xb68>
    3adc:      	cmp	x12, #0xfff
    3ae0:      	b.hi	0x3d18 <generic_fentry_process_filter+0xb68>
    3ae4:      	cmp	w22, w20
    3ae8:      	b.ls	0x3af4 <generic_fentry_process_filter+0x944>
    3aec:      	mov	w13, #0x2f              // =47
    3af0:      	strb	w13, [x8, x12]
    3af4:      	add	x25, x8, x12
    3af8:      	cmp	w22, w20
    3afc:      	add	x2, x9, x10
    3b00:      	and	w1, w11, #0xff
    3b04:      	mov	w8, #0x4                // =4
    3b08:      	cinc	x0, x25, hi
    3b0c:      	blr	x8
    3b10:      	cmp	w22, w20
    3b14:      	str	x25, [sp, #0x88]
    3b18:      	b.ls	0x3d18 <generic_fentry_process_filter+0xb68>
    3b1c:      	ldr	x8, [sp, #0xc0]
    3b20:      	str	x8, [sp, #0x70]
    3b24:      	subs	w19, w19, #0x1
    3b28:      	b.ne	0x3a10 <generic_fentry_process_filter+0x860>
    3b2c:      	b	0x3d18 <generic_fentry_process_filter+0xb68>
    3b30:      	add	x2, x21, #0x18
    3b34:      	mov	w8, #0x8                // =8
    3b38:      	mov	w9, #0x4                // =4
    3b3c:      	add	x10, sp, #0x58
    3b40:      	add	x0, sp, #0x58
    3b44:      	mov	w1, #0x8                // =8
    3b48:      	blr	x9
    3b4c:      	ldr	x8, [sp, #0x58]
    3b50:      	cmp	x8, x21
    3b54:      	b.eq	0x38f4 <generic_fentry_process_filter+0x744>
    3b58:      	ldr	x29, [sp, #0x40]
    3b5c:      	ldr	w9, [x29, #0x550]
    3b60:      	sub	w8, w9, #0xa
    3b64:      	cmp	w9, #0x9
    3b68:      	str	w8, [x29, #0x550]
    3b6c:      	b.gt	0x4240 <generic_fentry_process_filter+0x1090>
    3b70:      	ldr	x21, [sp, #0x30]
    3b74:      	mov	w9, #-0x24              // =-36
    3b78:      	mov	x24, x20
    3b7c:      	str	w9, [x29, #0x554]
    3b80:      	b	0x3d7c <generic_fentry_process_filter+0xbcc>
    3b84:      	mov	w19, #0x800             // =2048
    3b88:      	mov	w21, #0x8               // =8
    3b8c:      	add	x23, sp, #0xb8
    3b90:      	add	x29, sp, #0xd8
    3b94:      	b	0x3bf0 <generic_fentry_process_filter+0xa40>
    3b98:      	nop
    3b9c:      	nop
    3ba0:      	add	x2, x22, #0x10
    3ba4:      	mov	w8, #0x4                // =4
    3ba8:      	add	x0, sp, #0xd8
    3bac:      	mov	w1, #0x8                // =8
    3bb0:      	blr	x8
    3bb4:      	add	x20, sp, #0xd8
    3bb8:      	ldr	x8, [sp, #0x80]
    3bbc:      	ldr	x9, [x20]
    3bc0:      	cmp	x8, x9
    3bc4:      	b.eq	0x3d10 <generic_fentry_process_filter+0xb60>
    3bc8:      	add	x2, x22, #0x18
    3bcc:      	mov	w8, #0x4                // =4
    3bd0:      	mov	x0, x24
    3bd4:      	mov	w1, #0x8                // =8
    3bd8:      	blr	x8
    3bdc:      	ldr	x8, [x20]
    3be0:      	add	x9, x8, #0x20
    3be4:      	stp	x9, x8, [sp, #0x78]
    3be8:      	subs	w19, w19, #0x1
    3bec:      	b.eq	0x3d18 <generic_fentry_process_filter+0xb68>
    3bf0:      	ldp	x20, x2, [sp, #0x70]
    3bf4:      	ldp	x8, x9, [sp, #0x58]
    3bf8:      	cmp	x20, x8
    3bfc:      	ccmp	x2, x9, #0x0, eq
    3c00:      	b.eq	0x3d10 <generic_fentry_process_filter+0xb60>
    3c04:      	ldr	x22, [sp, #0x80]
    3c08:      	mov	w8, #0x4                // =4
    3c0c:      	add	x0, sp, #0xb8
    3c10:      	mov	w1, #0x8                // =8
    3c14:      	blr	x8
    3c18:      	ldr	x8, [sp, #0xb8]
    3c1c:      	cmp	x20, x8
    3c20:      	b.eq	0x3ba0 <generic_fentry_process_filter+0x9f0>
    3c24:      	add	x25, x20, #0x18
    3c28:      	mov	w8, #0x4                // =4
    3c2c:      	add	x0, sp, #0xd8
    3c30:      	mov	w1, #0x8                // =8
    3c34:      	mov	x2, x25
    3c38:      	blr	x8
    3c3c:      	add	x8, sp, #0xd8
    3c40:      	ldr	x8, [x8]
    3c44:      	cmp	x8, x20
    3c48:      	b.eq	0x3ba0 <generic_fentry_process_filter+0x9f0>
    3c4c:      	mov	w8, #0x4                // =4
    3c50:      	add	x9, sp, #0xc0
    3c54:      	add	x0, sp, #0xc0
    3c58:      	mov	w1, #0x8                // =8
    3c5c:      	mov	x2, x25
    3c60:      	blr	x8
    3c64:      	add	x2, x20, #0x20
    3c68:      	mov	w8, #0x4                // =4
    3c6c:      	mov	w9, #0x10               // =16
    3c70:      	add	x10, sp, #0xc8
    3c74:      	add	x0, sp, #0xc8
    3c78:      	mov	w1, #0x10               // =16
    3c7c:      	blr	x8
    3c80:      	ldr	w20, [sp, #0xcc]
    3c84:      	ldr	x8, [sp, #0x68]
    3c88:      	ldr	x10, [sp, #0x88]
    3c8c:      	sub	x12, x10, x8
    3c90:      	ldr	w22, [sp, #0x90]
    3c94:      	subs	w10, w20, w22
    3c98:      	ldr	x9, [sp, #0xd0]
    3c9c:      	csel	w10, wzr, w10, lo
    3ca0:      	cmp	w22, w20
    3ca4:      	csel	w11, w22, w20, lo
    3ca8:      	cinc	w13, w11, hi
    3cac:      	sub	w14, w22, w13
    3cb0:      	subs	x12, x12, x13
    3cb4:      	str	w14, [sp, #0x90]
    3cb8:      	b.lo	0x3d18 <generic_fentry_process_filter+0xb68>
    3cbc:      	cmp	x12, #0xfff
    3cc0:      	b.hi	0x3d18 <generic_fentry_process_filter+0xb68>
    3cc4:      	cmp	w22, w20
    3cc8:      	b.ls	0x3cd4 <generic_fentry_process_filter+0xb24>
    3ccc:      	mov	w13, #0x2f              // =47
    3cd0:      	strb	w13, [x8, x12]
    3cd4:      	add	x25, x8, x12
    3cd8:      	cmp	w22, w20
    3cdc:      	add	x2, x9, x10
    3ce0:      	and	w1, w11, #0xff
    3ce4:      	mov	w8, #0x4                // =4
    3ce8:      	cinc	x0, x25, hi
    3cec:      	blr	x8
    3cf0:      	cmp	w22, w20
    3cf4:      	str	x25, [sp, #0x88]
    3cf8:      	b.ls	0x3d18 <generic_fentry_process_filter+0xb68>
    3cfc:      	ldr	x8, [sp, #0xc0]
    3d00:      	str	x8, [sp, #0x70]
    3d04:      	subs	w19, w19, #0x1
    3d08:      	b.ne	0x3bf0 <generic_fentry_process_filter+0xa40>
    3d0c:      	b	0x3d18 <generic_fentry_process_filter+0xb68>
    3d10:      	mov	w8, #0x1                // =1
    3d14:      	strb	w8, [sp, #0x94]
    3d18:      	ldr	x24, [sp, #0x88]
    3d1c:      	ldr	x9, [sp, #0x28]
    3d20:      	cmp	x24, x9
    3d24:      	b.eq	0x3d68 <generic_fentry_process_filter+0xbb8>
    3d28:      	ldrb	w8, [sp, #0x94]
    3d2c:      	ldr	x29, [sp, #0x40]
    3d30:      	cmp	w8, #0x0
    3d34:      	ldr	x21, [sp, #0x30]
    3d38:      	cset	w8, eq
    3d3c:      	lsl	w9, w8, #1
    3d40:      	ldr	w8, [sp, #0x90]
    3d44:      	cmp	w8, #0x1
    3d48:      	str	w8, [x29, #0x550]
    3d4c:      	str	w9, [x29, #0x554]
    3d50:      	b.lt	0x3d60 <generic_fentry_process_filter+0xbb0>
    3d54:      	mov	w9, #0x1000             // =4096
    3d58:      	sub	w8, w9, w8
    3d5c:      	str	w8, [x29, #0x550]
    3d60:      	cbnz	x24, 0x3d7c <generic_fentry_process_filter+0xbcc>
    3d64:      	b	0x3e94 <generic_fentry_process_filter+0xce4>
    3d68:      	ldr	x29, [sp, #0x40]
    3d6c:      	ldr	x21, [sp, #0x30]
    3d70:      	mov	w8, wzr
    3d74:      	mov	x24, x9
    3d78:      	str	xzr, [x29, #0x550]
    3d7c:      	subs	w9, w8, #0x7f
    3d80:      	mov	w10, #0x7f              // =127
    3d84:      	mov	x11, x29
    3d88:      	mov	x0, x21
    3d8c:      	mov	x2, x24
    3d90:      	csel	w29, w8, w10, lo
    3d94:      	csel	w19, wzr, w9, lo
    3d98:      	cmp	w8, #0xff
    3d9c:      	mov	w9, #0xff               // =255
    3da0:      	csel	w8, w8, w9, lo
    3da4:      	and	w1, w8, #0xff
    3da8:      	str	w1, [x11, #0x550]
    3dac:      	mov	w8, #0x4                // =4
    3db0:      	blr	x8
    3db4:      	adrp	x25, 0x3000 <generic_fentry_process_event+0x2c70>
    3db8:      	ldr	x25, [x25]
    3dbc:      	cbz	x0, 0x3e2c <generic_fentry_process_filter+0xc7c>
    3dc0:      	neg	w8, w0
    3dc4:      	mov	w9, #0x1                // =1
    3dc8:      	add	x1, sp, #0x58
    3dcc:      	strh	w8, [sp, #0x58]
    3dd0:      	mov	w8, #0x8                // =8
    3dd4:      	mov	x0, x25
    3dd8:      	mov	w20, #0x1               // =1
    3ddc:      	strh	w8, [sp, #0x5a]
    3de0:      	mov	x8, #0x2de              // =734
    3de4:      	movk	x8, #0x4, lsl #32
    3de8:      	stur	x8, [sp, #0x5c]
    3dec:      	add	x8, sp, #0x58
    3df0:      	blr	x9
    3df4:      	cbz	x0, 0x3e08 <generic_fentry_process_filter+0xc58>
    3df8:      	ldr	w8, [x0]
    3dfc:      	add	w8, w8, #0x1
    3e00:      	str	w8, [x0]
    3e04:      	b	0x3e2c <generic_fentry_process_filter+0xc7c>
    3e08:      	str	w20, [sp, #0xc8]
    3e0c:      	mov	x3, xzr
    3e10:      	mov	w8, #0x2                // =2
    3e14:      	add	x9, sp, #0x58
    3e18:      	add	x10, sp, #0xc8
    3e1c:      	add	x1, sp, #0x58
    3e20:      	add	x2, sp, #0xc8
    3e24:      	mov	x0, x25
    3e28:      	blr	x8
    3e2c:      	ldr	x9, [sp, #0xe8]
    3e30:      	mov	w8, #0x6390             // =25488
    3e34:      	add	x2, x24, x19
    3e38:      	mov	w1, w29
    3e3c:      	add	x0, x9, x8
    3e40:      	mov	w8, #0x4                // =4
    3e44:      	blr	x8
    3e48:      	ldr	x29, [sp, #0x40]
    3e4c:      	cbz	x0, 0x3e94 <generic_fentry_process_filter+0xce4>
    3e50:      	neg	w8, w0
    3e54:      	mov	w9, #0x1                // =1
    3e58:      	add	x1, sp, #0x58
    3e5c:      	strh	w8, [sp, #0x58]
    3e60:      	mov	w8, #0x8                // =8
    3e64:      	mov	x0, x25
    3e68:      	mov	w19, #0x1               // =1
    3e6c:      	strh	w8, [sp, #0x5a]
    3e70:      	mov	x8, #0x2e0              // =736
    3e74:      	movk	x8, #0x4, lsl #32
    3e78:      	stur	x8, [sp, #0x5c]
    3e7c:      	add	x8, sp, #0x58
    3e80:      	blr	x9
    3e84:      	cbz	x0, 0x3ebc <generic_fentry_process_filter+0xd0c>
    3e88:      	ldr	w8, [x0]
    3e8c:      	add	w8, w8, #0x1
    3e90:      	str	w8, [x0]
    3e94:      	ldr	w8, [x29, #0x550]
    3e98:      	sub	w9, w8, #0x101
    3e9c:      	cmn	w9, #0x101
    3ea0:      	b.hi	0x3ef0 <generic_fentry_process_filter+0xd40>
    3ea4:      	ldr	x20, [sp, #0x38]
    3ea8:      	ldr	x22, [sp, #0xe8]
    3eac:      	mov	w8, #-0x1               // =-1
    3eb0:      	ldr	x24, [sp, #0x48]
    3eb4:      	stur	w8, [x29, #0xb8]
    3eb8:      	b	0x4040 <generic_fentry_process_filter+0xe90>
    3ebc:      	str	w19, [sp, #0xc8]
    3ec0:      	mov	x3, xzr
    3ec4:      	mov	w8, #0x2                // =2
    3ec8:      	add	x9, sp, #0x58
    3ecc:      	add	x10, sp, #0xc8
    3ed0:      	add	x1, sp, #0x58
    3ed4:      	add	x2, sp, #0xc8
    3ed8:      	mov	x0, x25
    3edc:      	blr	x8
    3ee0:      	ldr	w8, [x29, #0x550]
    3ee4:      	sub	w9, w8, #0x101
    3ee8:      	cmn	w9, #0x101
    3eec:      	b.ls	0x3ea4 <generic_fentry_process_filter+0xcf4>
    3ef0:      	ldr	x22, [sp, #0xe8]
    3ef4:      	and	x24, x8, #0xff
    3ef8:      	mov	w8, #0x5f80             // =24448
    3efc:      	mov	x2, x21
    3f00:      	mov	w1, w24
    3f04:      	add	x0, x22, x8
    3f08:      	mov	w8, #0x4                // =4
    3f0c:      	blr	x8
    3f10:      	mov	x23, x0
    3f14:      	cbz	x0, 0x3f90 <generic_fentry_process_filter+0xde0>
    3f18:      	neg	w8, w23
    3f1c:      	adrp	x25, 0x3000 <generic_fentry_process_event+0x2c70>
    3f20:      	mov	w9, #0x1                // =1
    3f24:      	strh	w8, [sp, #0x58]
    3f28:      	mov	w8, #0xf                // =15
    3f2c:      	add	x1, sp, #0x58
    3f30:      	mov	w19, #0x1               // =1
    3f34:      	strh	w8, [sp, #0x5a]
    3f38:      	mov	x8, #0x164              // =356
    3f3c:      	movk	x8, #0x4, lsl #32
    3f40:      	stur	x8, [sp, #0x5c]
    3f44:      	add	x8, sp, #0x58
    3f48:      	ldr	x25, [x25]
    3f4c:      	mov	x0, x25
    3f50:      	blr	x9
    3f54:      	cbz	x0, 0x3f68 <generic_fentry_process_filter+0xdb8>
    3f58:      	ldr	w8, [x0]
    3f5c:      	add	w8, w8, #0x1
    3f60:      	str	w8, [x0]
    3f64:      	b	0x3f8c <generic_fentry_process_filter+0xddc>
    3f68:      	str	w19, [sp, #0xc8]
    3f6c:      	mov	x3, xzr
    3f70:      	mov	w8, #0x2                // =2
    3f74:      	add	x9, sp, #0x58
    3f78:      	add	x10, sp, #0xc8
    3f7c:      	add	x1, sp, #0x58
    3f80:      	add	x2, sp, #0xc8
    3f84:      	mov	x0, x25
    3f88:      	blr	x8
    3f8c:      	ldr	x22, [sp, #0xe8]
    3f90:      	cmp	w23, #0x0
    3f94:      	csel	w8, w24, w23, eq
    3f98:      	cmp	w24, #0x7f
    3f9c:      	stur	w8, [x29, #0xb8]
    3fa0:      	mov	w8, #0x7f               // =127
    3fa4:      	csel	w1, w24, w8, lo
    3fa8:      	mov	w8, #0x6080             // =24704
    3fac:      	add	x0, x22, x8
    3fb0:      	mov	w8, #0x6390             // =25488
    3fb4:      	add	x2, x22, x8
    3fb8:      	mov	w8, #0x4                // =4
    3fbc:      	blr	x8
    3fc0:      	ldr	x20, [sp, #0x38]
    3fc4:      	ldr	x24, [sp, #0x48]
    3fc8:      	cbz	x0, 0x4040 <generic_fentry_process_filter+0xe90>
    3fcc:      	neg	w8, w0
    3fd0:      	adrp	x23, 0x3000 <generic_fentry_process_event+0x2c70>
    3fd4:      	mov	w9, #0x1                // =1
    3fd8:      	strh	w8, [sp, #0x58]
    3fdc:      	mov	w8, #0xf                // =15
    3fe0:      	add	x1, sp, #0x58
    3fe4:      	mov	w19, #0x1               // =1
    3fe8:      	strh	w8, [sp, #0x5a]
    3fec:      	mov	x8, #0x16a              // =362
    3ff0:      	movk	x8, #0x4, lsl #32
    3ff4:      	stur	x8, [sp, #0x5c]
    3ff8:      	add	x8, sp, #0x58
    3ffc:      	ldr	x23, [x23]
    4000:      	mov	x0, x23
    4004:      	blr	x9
    4008:      	cbz	x0, 0x401c <generic_fentry_process_filter+0xe6c>
    400c:      	ldr	w8, [x0]
    4010:      	add	w8, w8, #0x1
    4014:      	str	w8, [x0]
    4018:      	b	0x4040 <generic_fentry_process_filter+0xe90>
    401c:      	str	w19, [sp, #0xc8]
    4020:      	mov	x3, xzr
    4024:      	mov	w8, #0x2                // =2
    4028:      	add	x9, sp, #0x58
    402c:      	add	x10, sp, #0xc8
    4030:      	add	x1, sp, #0x58
    4034:      	add	x2, sp, #0xc8
    4038:      	mov	x0, x23
    403c:      	blr	x8
    4040:      	ldrb	w8, [x22, #0x1]
    4044:      	orr	w8, w8, #0x10
    4048:      	strb	w8, [x22, #0x1]
    404c:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4050:      	mov	w8, #0x5ef8             // =24312
    4054:      	ldr	x0, [x0]
    4058:      	add	x1, x22, x8
    405c:      	mov	w8, #0x1                // =1
    4060:      	blr	x8
    4064:      	cbz	x0, 0x54ec <generic_fentry_process_filter+0x233c>
    4068:      	ldr	x21, [x22, #0x5eb8]
    406c:      	cmp	x21, #0x6
    4070:      	b.hs	0x4208 <generic_fentry_process_filter+0x1058>
    4074:      	ldrsw	x8, [x0]
    4078:      	mov	x23, x0
    407c:      	cbz	w8, 0x4224 <generic_fentry_process_filter+0x1074>
    4080:      	cmp	x21, x8
    4084:      	b.hs	0x4208 <generic_fentry_process_filter+0x1058>
    4088:      	str	x8, [sp, #0x28]
    408c:      	stp	x29, x24, [sp, #0x40]
    4090:      	adrp	x24, 0x4000 <generic_fentry_process_filter+0xe50>
    4094:      	mov	w8, #0x1                // =1
    4098:      	add	x9, sp, #0xd8
    409c:      	str	x22, [sp, #0xe8]
    40a0:      	add	x1, sp, #0xd8
    40a4:      	str	x20, [sp, #0x38]
    40a8:      	str	w21, [sp, #0xd8]
    40ac:      	str	wzr, [sp, #0xc0]
    40b0:      	ldr	x24, [x24]
    40b4:      	mov	x0, x24
    40b8:      	blr	x8
    40bc:      	cbz	x0, 0x44cc <generic_fentry_process_filter+0x131c>
    40c0:      	ldr	w8, [x0]
    40c4:      	mov	x25, x0
    40c8:      	cbz	w8, 0x44cc <generic_fentry_process_filter+0x131c>
    40cc:      	ldr	x9, [sp, #0x48]
    40d0:      	ldr	w9, [x9, #0x68]
    40d4:      	tbnz	w9, #0x1f, 0x5494 <generic_fentry_process_filter+0x22e4>
    40d8:      	cmp	w8, #0x1b
    40dc:      	b.hi	0x5494 <generic_fentry_process_filter+0x22e4>
    40e0:      	mov	w9, #0x1                // =1
    40e4:      	lsl	w9, w9, w8
    40e8:      	tst	w9, #0x60
    40ec:      	b.ne	0x42e4 <generic_fentry_process_filter+0x1134>
    40f0:      	mov	w10, #0x100             // =256
    40f4:      	movk	w10, #0x400, lsl #16
    40f8:      	tst	w9, w10
    40fc:      	b.ne	0x4260 <generic_fentry_process_filter+0x10b0>
    4100:      	mov	w9, #0x1                // =1
    4104:      	lsl	w8, w9, w8
    4108:      	mov	w9, #0x200              // =512
    410c:      	movk	w9, #0x800, lsl #16
    4110:      	tst	w8, w9
    4114:      	b.eq	0x5494 <generic_fentry_process_filter+0x22e4>
    4118:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    411c:      	add	x1, x25, #0x4
    4120:      	mov	w8, #0x1                // =1
    4124:      	ldr	x0, [x0]
    4128:      	blr	x8
    412c:      	cbz	x0, 0x5494 <generic_fentry_process_filter+0x22e4>
    4130:      	ldr	x8, [sp, #0x48]
    4134:      	mov	x20, x0
    4138:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    413c:      	mov	w9, #0x7f               // =127
    4140:      	ldr	w8, [x8, #0x68]
    4144:      	ldr	x0, [x0]
    4148:      	add	x1, sp, #0xc0
    414c:      	cmp	w8, #0x7f
    4150:      	csel	w19, w8, w9, lt
    4154:      	mov	w8, #0x1                // =1
    4158:      	add	x9, sp, #0xc0
    415c:      	blr	x8
    4160:      	cbz	x0, 0x5494 <generic_fentry_process_filter+0x22e4>
    4164:      	sxtw	x1, w19
    4168:      	mov	x29, x0
    416c:      	lsl	w8, w1, #3
    4170:      	str	w8, [x0]
    4174:      	ldr	x8, [sp, #0x48]
    4178:      	ldr	w8, [x8, #0x6c]
    417c:      	cbnz	w8, 0x41dc <generic_fentry_process_filter+0x102c>
    4180:      	ldr	x11, [sp, #0x48]
    4184:      	and	w13, w1, #0x7f
    4188:      	mov	x8, xzr
    418c:      	ldr	w12, [x11, #0x68]
    4190:      	add	x9, x11, #0x1f0
    4194:      	add	x10, x11, #0x170
    4198:      	sub	w11, w12, w1
    419c:      	add	w12, w12, w13
    41a0:      	add	w11, w11, w13
    41a4:      	mvn	w13, w1
    41a8:      	add	w12, w13, w12
    41ac:      	cmp	x8, #0x7f
    41b0:      	b.eq	0x41d0 <generic_fentry_process_filter+0x1020>
    41b4:      	and	x13, x12, #0x7f
    41b8:      	sub	w12, w12, #0x1
    41bc:      	ldrb	w13, [x10, x13]
    41c0:      	strb	w13, [x9, x8]
    41c4:      	add	x8, x8, #0x1
    41c8:      	cmp	x11, x8
    41cc:      	b.ne	0x41ac <generic_fentry_process_filter+0xffc>
    41d0:      	ldr	x9, [sp, #0x48]
    41d4:      	mov	w8, #0x1                // =1
    41d8:      	str	w8, [x9, #0x6c]
    41dc:      	cmp	w1, #0x7f
    41e0:      	b.hi	0x41fc <generic_fentry_process_filter+0x104c>
    41e4:      	ldr	x8, [sp, #0x48]
    41e8:      	add	x0, x29, #0x4
    41ec:      	add	x2, x8, #0x1f0
    41f0:      	mov	w8, #0x4                // =4
    41f4:      	blr	x8
    41f8:      	tbnz	x0, #0x3f, 0x5494 <generic_fentry_process_filter+0x22e4>
    41fc:      	mov	w8, #0x1                // =1
    4200:      	mov	x0, x20
    4204:      	b	0x42dc <generic_fentry_process_filter+0x112c>
    4208:      	ldr	w8, [x24]
    420c:      	str	w8, [x22, #0x10]
    4210:      	ldr	x8, [x24, #0x8]
    4214:      	str	x8, [x22, #0x18]
    4218:      	ldrb	w8, [x29]
    421c:      	cbnz	w8, 0x54d0 <generic_fentry_process_filter+0x2320>
    4220:      	b	0x54ec <generic_fentry_process_filter+0x233c>
    4224:      	mov	w8, #0x1                // =1
    4228:      	strb	w8, [x29]
    422c:      	ldr	w8, [x24]
    4230:      	str	w8, [x22, #0x10]
    4234:      	ldr	x8, [x24, #0x8]
    4238:      	str	x8, [x22, #0x18]
    423c:      	b	0x54d0 <generic_fentry_process_filter+0x2320>
    4240:      	mov	w8, #0x2964             // =10596
    4244:      	add	x20, x24, #0xff6
    4248:      	strh	w8, [x24, #0xffe]
    424c:      	adrp	x8, 0x4000 <generic_fentry_process_filter+0xe50>
    4250:      	add	x8, x8, #0x0
    4254:      	ldr	x8, [x8]
    4258:      	str	x8, [x20]
    425c:      	b	0x38f4 <generic_fentry_process_filter+0x744>
    4260:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4264:      	add	x1, x25, #0x4
    4268:      	mov	w8, #0x1                // =1
    426c:      	ldr	x0, [x0]
    4270:      	blr	x8
    4274:      	cbz	x0, 0x5494 <generic_fentry_process_filter+0x22e4>
    4278:      	mov	x19, x0
    427c:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4280:      	mov	w8, #0x1                // =1
    4284:      	ldr	x0, [x0]
    4288:      	add	x9, sp, #0xc0
    428c:      	add	x1, sp, #0xc0
    4290:      	blr	x8
    4294:      	cbz	x0, 0x5494 <generic_fentry_process_filter+0x22e4>
    4298:      	mov	w1, wzr
    429c:      	mov	w2, #0x104              // =260
    42a0:      	mov	x29, x0
    42a4:      	bl	0x42a4 <generic_fentry_process_filter+0x10f4>
    42a8:      	ldr	x10, [sp, #0x48]
    42ac:      	mov	x0, x29
    42b0:      	ldr	w8, [x10, #0x68]
    42b4:      	add	x2, x10, #0x70
    42b8:      	lsl	w9, w8, #3
    42bc:      	and	x8, x8, #0xff
    42c0:      	str	w9, [x0], #0x4
    42c4:      	mov	w9, #0x4                // =4
    42c8:      	ldrb	w1, [x10, #0x68]
    42cc:      	blr	x9
    42d0:      	tbnz	x0, #0x3f, 0x5494 <generic_fentry_process_filter+0x22e4>
    42d4:      	mov	w8, #0x1                // =1
    42d8:      	mov	x0, x19
    42dc:      	mov	x1, x29
    42e0:      	b	0x4494 <generic_fentry_process_filter+0x12e4>
    42e4:      	str	wzr, [sp, #0xc8]
    42e8:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    42ec:      	mov	w8, #0x1                // =1
    42f0:      	add	x9, sp, #0xc8
    42f4:      	ldr	x0, [x0]
    42f8:      	add	x1, sp, #0xc8
    42fc:      	blr	x8
    4300:      	cbz	x0, 0x4440 <generic_fentry_process_filter+0x1290>
    4304:      	ldr	x9, [sp, #0x48]
    4308:      	ldr	x8, [x0]
    430c:      	ldr	x9, [x9, #0x378]
    4310:      	cmp	x8, x9
    4314:      	b.eq	0x4440 <generic_fentry_process_filter+0x1290>
    4318:      	str	x0, [sp, #0x30]
    431c:      	adrp	x8, 0x4000 <generic_fentry_process_filter+0xe50>
    4320:      	mov	w20, wzr
    4324:      	mov	x19, xzr
    4328:      	ldr	x8, [x8]
    432c:      	ldrb	w8, [x8]
    4330:      	ldr	x9, [sp, #0x48]
    4334:      	add	x22, x9, #0x370
    4338:      	cbz	w8, 0x4408 <generic_fentry_process_filter+0x1258>
    433c:      	ldr	x8, [sp, #0x48]
    4340:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4344:      	add	x9, sp, #0x58
    4348:      	add	x1, sp, #0x58
    434c:      	ldr	w8, [x8, #0x10]
    4350:      	str	w8, [sp, #0x58]
    4354:      	mov	w8, #0x1                // =1
    4358:      	ldr	x0, [x0]
    435c:      	blr	x8
    4360:      	cbz	x0, 0x4430 <generic_fentry_process_filter+0x1280>
    4364:      	mov	x29, x0
    4368:      	add	x1, x0, #0x70
    436c:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4370:      	ldr	x0, [x0]
    4374:      	mov	w8, #0x1                // =1
    4378:      	blr	x8
    437c:      	cbz	x0, 0x4398 <generic_fentry_process_filter+0x11e8>
    4380:      	ldr	x8, [x0]
    4384:      	cbz	x8, 0x4398 <generic_fentry_process_filter+0x11e8>
    4388:      	ldaxr	x9, [x22]
    438c:      	orr	x9, x9, x8
    4390:      	stlxr	w10, x9, [x22]
    4394:      	cbnz	w10, 0x4388 <generic_fentry_process_filter+0x11d8>
    4398:      	cmp	x29, x19
    439c:      	b.eq	0x4430 <generic_fentry_process_filter+0x1280>
    43a0:      	mov	w8, #0x86a0             // =34464
    43a4:      	add	w20, w20, #0x1
    43a8:      	mov	x19, x29
    43ac:      	movk	w8, #0x1, lsl #16
    43b0:      	cmp	w20, w8
    43b4:      	b.ne	0x433c <generic_fentry_process_filter+0x118c>
    43b8:      	b	0x4430 <generic_fentry_process_filter+0x1280>
    43bc:      	mov	x29, x0
    43c0:      	add	x1, x0, #0x70
    43c4:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    43c8:      	ldr	x0, [x0]
    43cc:      	mov	w8, #0x1                // =1
    43d0:      	blr	x8
    43d4:      	cbz	x0, 0x43f0 <generic_fentry_process_filter+0x1240>
    43d8:      	ldr	x8, [x0]
    43dc:      	cbz	x8, 0x43f0 <generic_fentry_process_filter+0x1240>
    43e0:      	ldaxr	x9, [x22]
    43e4:      	orr	x9, x9, x8
    43e8:      	stlxr	w10, x9, [x22]
    43ec:      	cbnz	w10, 0x43e0 <generic_fentry_process_filter+0x1230>
    43f0:      	cmp	x29, x19
    43f4:      	b.eq	0x4430 <generic_fentry_process_filter+0x1280>
    43f8:      	add	w20, w20, #0x1
    43fc:      	mov	x19, x29
    4400:      	cmp	w20, #0x400
    4404:      	b.eq	0x4430 <generic_fentry_process_filter+0x1280>
    4408:      	ldr	x8, [sp, #0x48]
    440c:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4410:      	add	x9, sp, #0x58
    4414:      	add	x1, sp, #0x58
    4418:      	ldr	w8, [x8, #0x10]
    441c:      	str	w8, [sp, #0x58]
    4420:      	mov	w8, #0x1                // =1
    4424:      	ldr	x0, [x0]
    4428:      	blr	x8
    442c:      	cbnz	x0, 0x43bc <generic_fentry_process_filter+0x120c>
    4430:      	ldr	x8, [sp, #0x30]
    4434:      	ldr	x9, [sp, #0x48]
    4438:      	ldr	x8, [x8]
    443c:      	str	x8, [x9, #0x378]
    4440:      	ldr	w8, [x25, #0x8]
    4444:      	cmn	w8, #0x1
    4448:      	b.eq	0x446c <generic_fentry_process_filter+0x12bc>
    444c:      	ldr	x9, [sp, #0x48]
    4450:      	ldr	x9, [x9, #0x370]
    4454:      	lsr	x8, x9, x8
    4458:      	tbz	w8, #0x0, 0x446c <generic_fentry_process_filter+0x12bc>
    445c:      	mov	x0, #0xffee             // =65518
    4460:      	movk	x0, #0xadc0, lsl #16
    4464:      	movk	x0, #0xb, lsl #32
    4468:      	b	0x4498 <generic_fentry_process_filter+0x12e8>
    446c:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4470:      	mov	w8, #0x1                // =1
    4474:      	add	x9, sp, #0xd8
    4478:      	ldr	x0, [x0]
    447c:      	add	x1, sp, #0xd8
    4480:      	blr	x8
    4484:      	cbz	x0, 0x5494 <generic_fentry_process_filter+0x22e4>
    4488:      	ldr	x8, [sp, #0x48]
    448c:      	add	x1, x8, #0x70
    4490:      	mov	w8, #0x1                // =1
    4494:      	blr	x8
    4498:      	ldr	w8, [x25]
    449c:      	cmp	w8, #0x25
    44a0:      	b.hi	0x44c8 <generic_fentry_process_filter+0x1318>
    44a4:      	mov	w9, #0x1                // =1
    44a8:      	lsl	x8, x9, x8
    44ac:      	mov	x9, #0x50               // =80
    44b0:      	movk	x9, #0xc00, lsl #16
    44b4:      	movk	x9, #0x20, lsl #32
    44b8:      	tst	x8, x9
    44bc:      	b.eq	0x44c8 <generic_fentry_process_filter+0x1318>
    44c0:      	cbnz	x0, 0x5494 <generic_fentry_process_filter+0x22e4>
    44c4:      	b	0x44cc <generic_fentry_process_filter+0x131c>
    44c8:      	cbz	x0, 0x5494 <generic_fentry_process_filter+0x22e4>
    44cc:      	adrp	x8, 0x4000 <generic_fentry_process_filter+0xe50>
    44d0:      	ldr	x8, [x8]
    44d4:      	ldrb	w8, [x8]
    44d8:      	cbz	w8, 0x48a0 <generic_fentry_process_filter+0x16f0>
    44dc:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    44e0:      	mov	w8, #0x1                // =1
    44e4:      	ldr	x0, [x0]
    44e8:      	ldr	x1, [sp, #0x48]
    44ec:      	blr	x8
    44f0:      	cbz	x0, 0x48a0 <generic_fentry_process_filter+0x16f0>
    44f4:      	add	w8, w21, #0x5
    44f8:      	str	wzr, [sp, #0xc0]
    44fc:      	add	x9, sp, #0xd8
    4500:      	mov	x25, x0
    4504:      	str	w8, [sp, #0xd8]
    4508:      	mov	w8, #0x1                // =1
    450c:      	add	x1, sp, #0xd8
    4510:      	mov	x0, x24
    4514:      	blr	x8
    4518:      	cbz	x0, 0x48a0 <generic_fentry_process_filter+0x16f0>
    451c:      	ldr	w8, [x0]
    4520:      	mov	x24, x0
    4524:      	cbz	w8, 0x48a0 <generic_fentry_process_filter+0x16f0>
    4528:      	ldr	w9, [x25]
    452c:      	tbnz	w9, #0x1f, 0x5494 <generic_fentry_process_filter+0x22e4>
    4530:      	cmp	w8, #0x1b
    4534:      	b.hi	0x5494 <generic_fentry_process_filter+0x22e4>
    4538:      	mov	w9, #0x1                // =1
    453c:      	lsl	w9, w9, w8
    4540:      	tst	w9, #0x60
    4544:      	b.ne	0x46cc <generic_fentry_process_filter+0x151c>
    4548:      	mov	w10, #0x100             // =256
    454c:      	movk	w10, #0x400, lsl #16
    4550:      	tst	w9, w10
    4554:      	b.ne	0x464c <generic_fentry_process_filter+0x149c>
    4558:      	mov	w9, #0x1                // =1
    455c:      	lsl	w8, w9, w8
    4560:      	mov	w9, #0x200              // =512
    4564:      	movk	w9, #0x800, lsl #16
    4568:      	tst	w8, w9
    456c:      	b.eq	0x5494 <generic_fentry_process_filter+0x22e4>
    4570:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4574:      	add	x1, x24, #0x4
    4578:      	mov	w8, #0x1                // =1
    457c:      	ldr	x0, [x0]
    4580:      	blr	x8
    4584:      	cbz	x0, 0x5494 <generic_fentry_process_filter+0x22e4>
    4588:      	ldr	w8, [x25]
    458c:      	mov	x20, x0
    4590:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4594:      	mov	w9, #0x7f               // =127
    4598:      	ldr	x0, [x0]
    459c:      	add	x1, sp, #0xc0
    45a0:      	cmp	w8, #0x7f
    45a4:      	csel	w19, w8, w9, lt
    45a8:      	mov	w8, #0x1                // =1
    45ac:      	add	x9, sp, #0xc0
    45b0:      	blr	x8
    45b4:      	cbz	x0, 0x5494 <generic_fentry_process_filter+0x22e4>
    45b8:      	sxtw	x1, w19
    45bc:      	mov	x29, x0
    45c0:      	lsl	w8, w1, #3
    45c4:      	str	w8, [x0]
    45c8:      	ldr	w8, [x25, #0x4]
    45cc:      	cbnz	w8, 0x4624 <generic_fentry_process_filter+0x1474>
    45d0:      	ldr	w12, [x25]
    45d4:      	and	w13, w1, #0x7f
    45d8:      	mov	x8, xzr
    45dc:      	add	x9, x25, #0x188
    45e0:      	add	x10, x25, #0x108
    45e4:      	sub	w11, w12, w1
    45e8:      	add	w12, w12, w13
    45ec:      	add	w11, w11, w13
    45f0:      	mvn	w13, w1
    45f4:      	add	w12, w13, w12
    45f8:      	cmp	x8, #0x7f
    45fc:      	b.eq	0x461c <generic_fentry_process_filter+0x146c>
    4600:      	and	x13, x12, #0x7f
    4604:      	sub	w12, w12, #0x1
    4608:      	ldrb	w13, [x10, x13]
    460c:      	strb	w13, [x9, x8]
    4610:      	add	x8, x8, #0x1
    4614:      	cmp	x11, x8
    4618:      	b.ne	0x45f8 <generic_fentry_process_filter+0x1448>
    461c:      	mov	w8, #0x1                // =1
    4620:      	str	w8, [x25, #0x4]
    4624:      	cmp	w1, #0x7f
    4628:      	b.hi	0x4640 <generic_fentry_process_filter+0x1490>
    462c:      	add	x0, x29, #0x4
    4630:      	add	x2, x25, #0x188
    4634:      	mov	w8, #0x4                // =4
    4638:      	blr	x8
    463c:      	tbnz	x0, #0x3f, 0x5494 <generic_fentry_process_filter+0x22e4>
    4640:      	mov	w8, #0x1                // =1
    4644:      	mov	x0, x20
    4648:      	b	0x46c4 <generic_fentry_process_filter+0x1514>
    464c:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4650:      	add	x1, x24, #0x4
    4654:      	mov	w8, #0x1                // =1
    4658:      	ldr	x0, [x0]
    465c:      	blr	x8
    4660:      	cbz	x0, 0x5494 <generic_fentry_process_filter+0x22e4>
    4664:      	mov	x19, x0
    4668:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    466c:      	mov	w8, #0x1                // =1
    4670:      	ldr	x0, [x0]
    4674:      	add	x9, sp, #0xc0
    4678:      	add	x1, sp, #0xc0
    467c:      	blr	x8
    4680:      	cbz	x0, 0x5494 <generic_fentry_process_filter+0x22e4>
    4684:      	mov	w1, wzr
    4688:      	mov	w2, #0x104              // =260
    468c:      	mov	x29, x0
    4690:      	bl	0x4690 <generic_fentry_process_filter+0x14e0>
    4694:      	ldr	w8, [x25]
    4698:      	mov	x0, x29
    469c:      	add	x2, x25, #0x8
    46a0:      	lsl	w9, w8, #3
    46a4:      	and	x8, x8, #0xff
    46a8:      	str	w9, [x0], #0x4
    46ac:      	mov	w9, #0x4                // =4
    46b0:      	ldrb	w1, [x25]
    46b4:      	blr	x9
    46b8:      	tbnz	x0, #0x3f, 0x5494 <generic_fentry_process_filter+0x22e4>
    46bc:      	mov	w8, #0x1                // =1
    46c0:      	mov	x0, x19
    46c4:      	mov	x1, x29
    46c8:      	b	0x4868 <generic_fentry_process_filter+0x16b8>
    46cc:      	str	wzr, [sp, #0xc8]
    46d0:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    46d4:      	mov	w8, #0x1                // =1
    46d8:      	add	x9, sp, #0xc8
    46dc:      	ldr	x0, [x0]
    46e0:      	add	x1, sp, #0xc8
    46e4:      	blr	x8
    46e8:      	cbz	x0, 0x481c <generic_fentry_process_filter+0x166c>
    46ec:      	ldr	x8, [x0]
    46f0:      	ldr	x9, [x25, #0x310]
    46f4:      	cmp	x8, x9
    46f8:      	b.eq	0x481c <generic_fentry_process_filter+0x166c>
    46fc:      	str	x0, [sp, #0x30]
    4700:      	adrp	x8, 0x4000 <generic_fentry_process_filter+0xe50>
    4704:      	add	x22, x25, #0x308
    4708:      	mov	w20, wzr
    470c:      	ldr	x8, [x8]
    4710:      	mov	x19, xzr
    4714:      	ldrb	w8, [x8]
    4718:      	cbz	w8, 0x47e8 <generic_fentry_process_filter+0x1638>
    471c:      	ldr	x8, [sp, #0x48]
    4720:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4724:      	add	x9, sp, #0x58
    4728:      	add	x1, sp, #0x58
    472c:      	ldr	w8, [x8, #0x10]
    4730:      	str	w8, [sp, #0x58]
    4734:      	mov	w8, #0x1                // =1
    4738:      	ldr	x0, [x0]
    473c:      	blr	x8
    4740:      	cbz	x0, 0x4810 <generic_fentry_process_filter+0x1660>
    4744:      	mov	x29, x0
    4748:      	add	x1, x0, #0x70
    474c:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4750:      	ldr	x0, [x0]
    4754:      	mov	w8, #0x1                // =1
    4758:      	blr	x8
    475c:      	cbz	x0, 0x4778 <generic_fentry_process_filter+0x15c8>
    4760:      	ldr	x8, [x0]
    4764:      	cbz	x8, 0x4778 <generic_fentry_process_filter+0x15c8>
    4768:      	ldaxr	x9, [x22]
    476c:      	orr	x9, x9, x8
    4770:      	stlxr	w10, x9, [x22]
    4774:      	cbnz	w10, 0x4768 <generic_fentry_process_filter+0x15b8>
    4778:      	cmp	x29, x19
    477c:      	b.eq	0x4810 <generic_fentry_process_filter+0x1660>
    4780:      	mov	w8, #0x86a0             // =34464
    4784:      	add	w20, w20, #0x1
    4788:      	mov	x19, x29
    478c:      	movk	w8, #0x1, lsl #16
    4790:      	cmp	w20, w8
    4794:      	b.ne	0x471c <generic_fentry_process_filter+0x156c>
    4798:      	b	0x4810 <generic_fentry_process_filter+0x1660>
    479c:      	mov	x29, x0
    47a0:      	add	x1, x0, #0x70
    47a4:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    47a8:      	ldr	x0, [x0]
    47ac:      	mov	w8, #0x1                // =1
    47b0:      	blr	x8
    47b4:      	cbz	x0, 0x47d0 <generic_fentry_process_filter+0x1620>
    47b8:      	ldr	x8, [x0]
    47bc:      	cbz	x8, 0x47d0 <generic_fentry_process_filter+0x1620>
    47c0:      	ldaxr	x9, [x22]
    47c4:      	orr	x9, x9, x8
    47c8:      	stlxr	w10, x9, [x22]
    47cc:      	cbnz	w10, 0x47c0 <generic_fentry_process_filter+0x1610>
    47d0:      	cmp	x29, x19
    47d4:      	b.eq	0x4810 <generic_fentry_process_filter+0x1660>
    47d8:      	add	w20, w20, #0x1
    47dc:      	mov	x19, x29
    47e0:      	cmp	w20, #0x400
    47e4:      	b.eq	0x4810 <generic_fentry_process_filter+0x1660>
    47e8:      	ldr	x8, [sp, #0x48]
    47ec:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    47f0:      	add	x9, sp, #0x58
    47f4:      	add	x1, sp, #0x58
    47f8:      	ldr	w8, [x8, #0x10]
    47fc:      	str	w8, [sp, #0x58]
    4800:      	mov	w8, #0x1                // =1
    4804:      	ldr	x0, [x0]
    4808:      	blr	x8
    480c:      	cbnz	x0, 0x479c <generic_fentry_process_filter+0x15ec>
    4810:      	ldr	x8, [sp, #0x30]
    4814:      	ldr	x8, [x8]
    4818:      	str	x8, [x25, #0x310]
    481c:      	ldr	w8, [x24, #0x8]
    4820:      	cmn	w8, #0x1
    4824:      	b.eq	0x4844 <generic_fentry_process_filter+0x1694>
    4828:      	ldr	x9, [x25, #0x308]
    482c:      	lsr	x8, x9, x8
    4830:      	tbz	w8, #0x0, 0x4844 <generic_fentry_process_filter+0x1694>
    4834:      	mov	x0, #0xffee             // =65518
    4838:      	movk	x0, #0xadc0, lsl #16
    483c:      	movk	x0, #0xb, lsl #32
    4840:      	b	0x486c <generic_fentry_process_filter+0x16bc>
    4844:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4848:      	mov	w8, #0x1                // =1
    484c:      	add	x9, sp, #0xd8
    4850:      	ldr	x0, [x0]
    4854:      	add	x1, sp, #0xd8
    4858:      	blr	x8
    485c:      	cbz	x0, 0x5494 <generic_fentry_process_filter+0x22e4>
    4860:      	add	x1, x25, #0x8
    4864:      	mov	w8, #0x1                // =1
    4868:      	blr	x8
    486c:      	ldr	w8, [x24]
    4870:      	cmp	w8, #0x25
    4874:      	b.hi	0x489c <generic_fentry_process_filter+0x16ec>
    4878:      	mov	w9, #0x1                // =1
    487c:      	lsl	x8, x9, x8
    4880:      	mov	x9, #0x50               // =80
    4884:      	movk	x9, #0xc00, lsl #16
    4888:      	movk	x9, #0x20, lsl #32
    488c:      	tst	x8, x9
    4890:      	b.eq	0x489c <generic_fentry_process_filter+0x16ec>
    4894:      	cbnz	x0, 0x5494 <generic_fentry_process_filter+0x22e4>
    4898:      	b	0x48a0 <generic_fentry_process_filter+0x16f0>
    489c:      	cbz	x0, 0x5494 <generic_fentry_process_filter+0x22e4>
    48a0:      	lsl	w8, w21, #2
    48a4:      	add	x9, x8, #0x4
    48a8:      	ldr	w8, [x9, x23]
    48ac:      	add	w9, w8, w9
    48b0:      	and	w11, w9, #0x3ff
    48b4:      	add	w9, w9, #0x4
    48b8:      	and	x9, x9, #0x3ff
    48bc:      	add	x10, x11, #0x8
    48c0:      	ldr	w9, [x9, x23]
    48c4:      	cmp	w9, #0x5
    48c8:      	b.lo	0x4958 <generic_fentry_process_filter+0x17a8>
    48cc:      	add	x9, x10, x23
    48d0:      	ldr	w10, [x9, #0x8]
    48d4:      	ldp	w12, w22, [x9]
    48d8:      	stp	x9, x11, [sp, #0x8]
    48dc:      	mov	w9, #0x4                // =4
    48e0:      	cmp	w10, #0x4
    48e4:      	stp	xzr, xzr, [sp, #0x58]
    48e8:      	csel	w9, w10, w9, lo
    48ec:      	cmp	w12, #0x6
    48f0:      	b.ne	0x48fc <generic_fentry_process_filter+0x174c>
    48f4:      	mov	x11, #0x100000001       // =4294967297
    48f8:      	stp	x11, x11, [sp, #0x58]
    48fc:      	cbz	w10, 0x4d60 <generic_fentry_process_filter+0x1bb0>
    4900:      	ldr	x10, [sp, #0x48]
    4904:      	add	w8, w8, w21, lsl #2
    4908:      	tst	x22, #0x1
    490c:      	add	x25, sp, #0x58
    4910:      	str	w12, [sp, #0x30]
    4914:      	add	w8, w8, #0x4
    4918:      	and	x8, x8, #0x3ff
    491c:      	add	x21, x8, #0x14
    4920:      	sub	x8, x9, #0x1
    4924:      	mov	w9, #0x3                // =3
    4928:      	add	x11, x10, #0x24
    492c:      	str	x11, [sp, #0x20]
    4930:      	csel	x11, x10, x11, eq
    4934:      	cmp	x8, #0x3
    4938:      	add	x10, x10, #0x10
    493c:      	csel	x8, x8, x9, lo
    4940:      	and	x9, x21, #0x7fc
    4944:      	mov	x20, x11
    4948:      	str	x10, [sp, #0x18]
    494c:      	add	x19, x23, x9
    4950:      	add	x24, x8, #0x1
    4954:      	b	0x4990 <generic_fentry_process_filter+0x17e0>
    4958:      	mov	w9, #0x1                // =1
    495c:      	mov	w8, w10
    4960:      	b	0x4da8 <generic_fentry_process_filter+0x1bf8>
    4964:      	mov	w8, #0x1                // =1
    4968:      	ldr	w12, [sp, #0x30]
    496c:      	mov	x11, x20
    4970:      	cmp	w12, #0x6
    4974:      	eor	w8, w8, #0x1
    4978:      	csinc	w9, w8, wzr, eq
    497c:      	str	w9, [x25], #0x4
    4980:      	add	x21, x21, #0x4
    4984:      	add	x19, x19, #0x4
    4988:      	subs	x24, x24, #0x1
    498c:      	b.eq	0x4d60 <generic_fentry_process_filter+0x1bb0>
    4990:      	cmp	x21, #0x3e8
    4994:      	b.ls	0x4bb8 <generic_fentry_process_filter+0x1a08>
    4998:      	mov	x29, xzr
    499c:      	tbz	w22, #0x1, 0x4bc0 <generic_fentry_process_filter+0x1a10>
    49a0:      	tbnz	w22, #0x0, 0x4bec <generic_fentry_process_filter+0x1a3c>
    49a4:      	ldr	x10, [sp, #0x48]
    49a8:      	mov	w8, #0x1                // =1
    49ac:      	ldr	w9, [x10]
    49b0:      	cmp	x29, x9
    49b4:      	b.eq	0x4970 <generic_fentry_process_filter+0x17c0>
    49b8:      	ldr	w9, [x10, #0x10]
    49bc:      	cmp	x29, x9
    49c0:      	b.eq	0x4970 <generic_fentry_process_filter+0x17c0>
    49c4:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    49c8:      	mov	w8, #0x1                // =1
    49cc:      	ldr	x0, [x0]
    49d0:      	ldr	x1, [sp, #0x18]
    49d4:      	blr	x8
    49d8:      	cbz	x0, 0x4d44 <generic_fentry_process_filter+0x1b94>
    49dc:      	ldr	w9, [x0]
    49e0:      	mov	x1, x0
    49e4:      	mov	w8, #0x1                // =1
    49e8:      	cmp	x29, x9
    49ec:      	b.eq	0x4968 <generic_fentry_process_filter+0x17b8>
    49f0:      	ldr	w9, [x1, #0x10]!
    49f4:      	ldr	w12, [sp, #0x30]
    49f8:      	mov	x11, x20
    49fc:      	cmp	x29, x9
    4a00:      	b.eq	0x4970 <generic_fentry_process_filter+0x17c0>
    4a04:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4a08:      	mov	w8, #0x1                // =1
    4a0c:      	ldr	x0, [x0]
    4a10:      	blr	x8
    4a14:      	cbz	x0, 0x4d44 <generic_fentry_process_filter+0x1b94>
    4a18:      	ldr	w9, [x0]
    4a1c:      	mov	x1, x0
    4a20:      	mov	w8, #0x1                // =1
    4a24:      	cmp	x29, x9
    4a28:      	b.eq	0x4968 <generic_fentry_process_filter+0x17b8>
    4a2c:      	ldr	w9, [x1, #0x10]!
    4a30:      	ldr	w12, [sp, #0x30]
    4a34:      	mov	x11, x20
    4a38:      	cmp	x29, x9
    4a3c:      	b.eq	0x4970 <generic_fentry_process_filter+0x17c0>
    4a40:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4a44:      	mov	w8, #0x1                // =1
    4a48:      	ldr	x0, [x0]
    4a4c:      	blr	x8
    4a50:      	cbz	x0, 0x4d44 <generic_fentry_process_filter+0x1b94>
    4a54:      	ldr	w9, [x0]
    4a58:      	mov	x1, x0
    4a5c:      	mov	w8, #0x1                // =1
    4a60:      	cmp	x29, x9
    4a64:      	b.eq	0x4968 <generic_fentry_process_filter+0x17b8>
    4a68:      	ldr	w9, [x1, #0x10]!
    4a6c:      	ldr	w12, [sp, #0x30]
    4a70:      	mov	x11, x20
    4a74:      	cmp	x29, x9
    4a78:      	b.eq	0x4970 <generic_fentry_process_filter+0x17c0>
    4a7c:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4a80:      	mov	w8, #0x1                // =1
    4a84:      	ldr	x0, [x0]
    4a88:      	blr	x8
    4a8c:      	cbz	x0, 0x4d44 <generic_fentry_process_filter+0x1b94>
    4a90:      	ldr	w9, [x0]
    4a94:      	mov	x1, x0
    4a98:      	mov	w8, #0x1                // =1
    4a9c:      	cmp	x29, x9
    4aa0:      	b.eq	0x4968 <generic_fentry_process_filter+0x17b8>
    4aa4:      	ldr	w9, [x1, #0x10]!
    4aa8:      	ldr	w12, [sp, #0x30]
    4aac:      	mov	x11, x20
    4ab0:      	cmp	x29, x9
    4ab4:      	b.eq	0x4970 <generic_fentry_process_filter+0x17c0>
    4ab8:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4abc:      	mov	w8, #0x1                // =1
    4ac0:      	ldr	x0, [x0]
    4ac4:      	blr	x8
    4ac8:      	cbz	x0, 0x4d44 <generic_fentry_process_filter+0x1b94>
    4acc:      	ldr	w9, [x0]
    4ad0:      	mov	x1, x0
    4ad4:      	mov	w8, #0x1                // =1
    4ad8:      	cmp	x29, x9
    4adc:      	b.eq	0x4968 <generic_fentry_process_filter+0x17b8>
    4ae0:      	ldr	w9, [x1, #0x10]!
    4ae4:      	ldr	w12, [sp, #0x30]
    4ae8:      	mov	x11, x20
    4aec:      	cmp	x29, x9
    4af0:      	b.eq	0x4970 <generic_fentry_process_filter+0x17c0>
    4af4:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4af8:      	mov	w8, #0x1                // =1
    4afc:      	ldr	x0, [x0]
    4b00:      	blr	x8
    4b04:      	cbz	x0, 0x4d44 <generic_fentry_process_filter+0x1b94>
    4b08:      	ldr	w9, [x0]
    4b0c:      	mov	x1, x0
    4b10:      	mov	w8, #0x1                // =1
    4b14:      	cmp	x29, x9
    4b18:      	b.eq	0x4968 <generic_fentry_process_filter+0x17b8>
    4b1c:      	ldr	w9, [x1, #0x10]!
    4b20:      	ldr	w12, [sp, #0x30]
    4b24:      	mov	x11, x20
    4b28:      	cmp	x29, x9
    4b2c:      	b.eq	0x4970 <generic_fentry_process_filter+0x17c0>
    4b30:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4b34:      	mov	w8, #0x1                // =1
    4b38:      	ldr	x0, [x0]
    4b3c:      	blr	x8
    4b40:      	cbz	x0, 0x4d44 <generic_fentry_process_filter+0x1b94>
    4b44:      	ldr	w9, [x0]
    4b48:      	mov	x1, x0
    4b4c:      	mov	w8, #0x1                // =1
    4b50:      	cmp	x29, x9
    4b54:      	b.eq	0x4968 <generic_fentry_process_filter+0x17b8>
    4b58:      	ldr	w9, [x1, #0x10]!
    4b5c:      	ldr	w12, [sp, #0x30]
    4b60:      	mov	x11, x20
    4b64:      	cmp	x29, x9
    4b68:      	b.eq	0x4970 <generic_fentry_process_filter+0x17c0>
    4b6c:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4b70:      	mov	w8, #0x1                // =1
    4b74:      	ldr	x0, [x0]
    4b78:      	blr	x8
    4b7c:      	cbz	x0, 0x4d44 <generic_fentry_process_filter+0x1b94>
    4b80:      	ldr	w9, [x0]
    4b84:      	mov	x1, x0
    4b88:      	mov	w8, #0x1                // =1
    4b8c:      	cmp	x29, x9
    4b90:      	b.eq	0x4968 <generic_fentry_process_filter+0x17b8>
    4b94:      	ldr	w9, [x1, #0x10]!
    4b98:      	ldr	w12, [sp, #0x30]
    4b9c:      	mov	x11, x20
    4ba0:      	cmp	x29, x9
    4ba4:      	b.eq	0x4970 <generic_fentry_process_filter+0x17c0>
    4ba8:      	adrp	x9, 0x4000 <generic_fentry_process_filter+0xe50>
    4bac:      	mov	w8, #0x1                // =1
    4bb0:      	ldr	x9, [x9]
    4bb4:      	b	0x4d38 <generic_fentry_process_filter+0x1b88>
    4bb8:      	ldr	w29, [x19]
    4bbc:      	tbnz	w22, #0x1, 0x49a0 <generic_fentry_process_filter+0x17f0>
    4bc0:      	ldr	w8, [x11]
    4bc4:      	cmp	w12, #0x5
    4bc8:      	b.ne	0x4bdc <generic_fentry_process_filter+0x1a2c>
    4bcc:      	cmp	x29, x8
    4bd0:      	b.eq	0x4bdc <generic_fentry_process_filter+0x1a2c>
    4bd4:      	mov	w9, wzr
    4bd8:      	b	0x497c <generic_fentry_process_filter+0x17cc>
    4bdc:      	cmp	w12, #0x6
    4be0:      	ccmp	x29, x8, #0x0, eq
    4be4:      	cset	w9, ne
    4be8:      	b	0x497c <generic_fentry_process_filter+0x17cc>
    4bec:      	ldr	x8, [sp, #0x20]
    4bf0:      	ldr	w9, [x8]
    4bf4:      	cbz	w9, 0x497c <generic_fentry_process_filter+0x17cc>
    4bf8:      	mov	w8, #0x1                // =1
    4bfc:      	cbz	x29, 0x4970 <generic_fentry_process_filter+0x17c0>
    4c00:      	cmp	x29, x9
    4c04:      	b.eq	0x4970 <generic_fentry_process_filter+0x17c0>
    4c08:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4c0c:      	mov	w8, #0x1                // =1
    4c10:      	ldr	x0, [x0]
    4c14:      	ldr	x1, [sp, #0x18]
    4c18:      	blr	x8
    4c1c:      	cbz	x0, 0x4d44 <generic_fentry_process_filter+0x1b94>
    4c20:      	ldr	w8, [x0, #0x24]
    4c24:      	cmp	x29, x8
    4c28:      	b.eq	0x4964 <generic_fentry_process_filter+0x17b4>
    4c2c:      	add	x1, x0, #0x10
    4c30:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4c34:      	mov	w8, #0x1                // =1
    4c38:      	ldr	x0, [x0]
    4c3c:      	blr	x8
    4c40:      	cbz	x0, 0x4d44 <generic_fentry_process_filter+0x1b94>
    4c44:      	ldr	w8, [x0, #0x24]
    4c48:      	cmp	x29, x8
    4c4c:      	b.eq	0x4964 <generic_fentry_process_filter+0x17b4>
    4c50:      	add	x1, x0, #0x10
    4c54:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4c58:      	mov	w8, #0x1                // =1
    4c5c:      	ldr	x0, [x0]
    4c60:      	blr	x8
    4c64:      	cbz	x0, 0x4d44 <generic_fentry_process_filter+0x1b94>
    4c68:      	ldr	w8, [x0, #0x24]
    4c6c:      	cmp	x29, x8
    4c70:      	b.eq	0x4964 <generic_fentry_process_filter+0x17b4>
    4c74:      	add	x1, x0, #0x10
    4c78:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4c7c:      	mov	w8, #0x1                // =1
    4c80:      	ldr	x0, [x0]
    4c84:      	blr	x8
    4c88:      	cbz	x0, 0x4d44 <generic_fentry_process_filter+0x1b94>
    4c8c:      	ldr	w8, [x0, #0x24]
    4c90:      	cmp	x29, x8
    4c94:      	b.eq	0x4964 <generic_fentry_process_filter+0x17b4>
    4c98:      	add	x1, x0, #0x10
    4c9c:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4ca0:      	mov	w8, #0x1                // =1
    4ca4:      	ldr	x0, [x0]
    4ca8:      	blr	x8
    4cac:      	cbz	x0, 0x4d44 <generic_fentry_process_filter+0x1b94>
    4cb0:      	ldr	w8, [x0, #0x24]
    4cb4:      	cmp	x29, x8
    4cb8:      	b.eq	0x4964 <generic_fentry_process_filter+0x17b4>
    4cbc:      	add	x1, x0, #0x10
    4cc0:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4cc4:      	mov	w8, #0x1                // =1
    4cc8:      	ldr	x0, [x0]
    4ccc:      	blr	x8
    4cd0:      	cbz	x0, 0x4d44 <generic_fentry_process_filter+0x1b94>
    4cd4:      	ldr	w8, [x0, #0x24]
    4cd8:      	cmp	x29, x8
    4cdc:      	b.eq	0x4964 <generic_fentry_process_filter+0x17b4>
    4ce0:      	add	x1, x0, #0x10
    4ce4:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4ce8:      	mov	w8, #0x1                // =1
    4cec:      	ldr	x0, [x0]
    4cf0:      	blr	x8
    4cf4:      	cbz	x0, 0x4d44 <generic_fentry_process_filter+0x1b94>
    4cf8:      	ldr	w8, [x0, #0x24]
    4cfc:      	cmp	x29, x8
    4d00:      	b.eq	0x4964 <generic_fentry_process_filter+0x17b4>
    4d04:      	add	x1, x0, #0x10
    4d08:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4d0c:      	mov	w8, #0x1                // =1
    4d10:      	ldr	x0, [x0]
    4d14:      	blr	x8
    4d18:      	cbz	x0, 0x4d44 <generic_fentry_process_filter+0x1b94>
    4d1c:      	ldr	w8, [x0, #0x24]
    4d20:      	cmp	x29, x8
    4d24:      	b.eq	0x4964 <generic_fentry_process_filter+0x17b4>
    4d28:      	adrp	x9, 0x4000 <generic_fentry_process_filter+0xe50>
    4d2c:      	add	x1, x0, #0x10
    4d30:      	mov	w8, #0x1                // =1
    4d34:      	ldr	x9, [x9]
    4d38:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0xe50>
    4d3c:      	ldr	x0, [x0]
    4d40:      	blr	x8
    4d44:      	ldr	w12, [sp, #0x30]
    4d48:      	mov	w8, wzr
    4d4c:      	mov	w9, wzr
    4d50:      	mov	x11, x20
    4d54:      	cmp	w12, #0x5
    4d58:      	b.ne	0x4970 <generic_fentry_process_filter+0x17c0>
    4d5c:      	b	0x497c <generic_fentry_process_filter+0x17cc>
    4d60:      	ldp	w8, w9, [sp, #0x58]
    4d64:      	ldp	w10, w11, [sp, #0x60]
    4d68:      	cmp	w12, #0x6
    4d6c:      	b.ne	0x4d80 <generic_fentry_process_filter+0x1bd0>
    4d70:      	and	w8, w9, w8
    4d74:      	and	w9, w10, w11
    4d78:      	and	w9, w8, w9
    4d7c:      	b	0x4d8c <generic_fentry_process_filter+0x1bdc>
    4d80:      	orr	w8, w9, w8
    4d84:      	orr	w9, w10, w11
    4d88:      	orr	w9, w8, w9
    4d8c:      	ldr	x8, [sp, #0x10]
    4d90:      	cbz	w9, 0x5494 <generic_fentry_process_filter+0x22e4>
    4d94:      	ldr	x10, [sp, #0x8]
    4d98:      	add	w8, w8, #0x14
    4d9c:      	ldr	w10, [x10, #0x8]
    4da0:      	ubfiz	w10, w10, #2, #3
    4da4:      	add	w8, w10, w8
    4da8:      	and	x10, x8, #0x3ff
    4dac:      	add	w8, w8, #0x4
    4db0:      	mov	w19, #0xa               // =10
    4db4:      	ldr	w10, [x10, x23]
    4db8:      	mov	w20, #0x4               // =4
    4dbc:      	mov	x25, #0x100000001       // =4294967297
    4dc0:      	sub	w22, w10, #0x4
    4dc4:      	ldr	x10, [sp, #0xe8]
    4dc8:      	add	x10, x10, #0x20
    4dcc:      	str	x10, [sp, #0x30]
    4dd0:      	b	0x4de8 <generic_fentry_process_filter+0x1c38>
    4dd4:      	nop
    4dd8:      	nop
    4ddc:      	nop
    4de0:      	subs	x19, x19, #0x1
    4de4:      	b.eq	0x4fb4 <generic_fentry_process_filter+0x1e04>
    4de8:      	cbz	w22, 0x4de0 <generic_fentry_process_filter+0x1c30>
    4dec:      	and	x9, x8, #0x3ff
    4df0:      	add	x10, x9, x23
    4df4:      	ldr	w29, [x10, #0x8]
    4df8:      	ldp	w9, w24, [x10]
    4dfc:      	stp	xzr, xzr, [sp, #0x58]
    4e00:      	cmp	w29, #0x4
    4e04:      	csel	w10, w29, w20, lo
    4e08:      	cmp	w24, #0x6
    4e0c:      	b.ne	0x4e14 <generic_fentry_process_filter+0x1c64>
    4e10:      	stp	x25, x25, [sp, #0x58]
    4e14:      	add	w21, w8, #0xc
    4e18:      	cbz	w29, 0x4f6c <generic_fentry_process_filter+0x1dbc>
    4e1c:      	and	x9, x9, #0xf
    4e20:      	cmp	w9, #0xa
    4e24:      	b.lo	0x4e50 <generic_fentry_process_filter+0x1ca0>
    4e28:      	sub	x8, x10, #0x1
    4e2c:      	mov	w9, #0x3                // =3
    4e30:      	add	x0, sp, #0x58
    4e34:      	mov	w1, wzr
    4e38:      	cmp	x8, #0x3
    4e3c:      	csel	x8, x8, x9, lo
    4e40:      	lsl	x8, x8, #2
    4e44:      	add	x2, x8, #0x4
    4e48:      	bl	0x4e48 <generic_fentry_process_filter+0x1c98>
    4e4c:      	b	0x4f6c <generic_fentry_process_filter+0x1dbc>
    4e50:      	cmp	w21, #0x3e8
    4e54:      	b.ls	0x4e60 <generic_fentry_process_filter+0x1cb0>
    4e58:      	mov	w11, wzr
    4e5c:      	b	0x4e68 <generic_fentry_process_filter+0x1cb8>
    4e60:      	and	w11, w21, #0xfffffffc
    4e64:      	ldr	w11, [x23, w11, uxtw]
    4e68:      	ldr	x12, [sp, #0x30]
    4e6c:      	cmp	w24, #0x5
    4e70:      	sub	x10, x10, #0x1
    4e74:      	ldr	w9, [x12, x9, lsl #2]
    4e78:      	cset	w12, ne
    4e7c:      	cmp	w24, #0x6
    4e80:      	cset	w13, ne
    4e84:      	cmp	w11, w9
    4e88:      	csinc	w11, w12, wzr, ne
    4e8c:      	csinc	w12, w13, wzr, eq
    4e90:      	and	w11, w11, w12
    4e94:      	str	w11, [sp, #0x58]
    4e98:      	cbz	x10, 0x4f6c <generic_fentry_process_filter+0x1dbc>
    4e9c:      	add	w11, w8, #0x10
    4ea0:      	cmp	w11, #0x3e8
    4ea4:      	b.ls	0x4eb0 <generic_fentry_process_filter+0x1d00>
    4ea8:      	mov	w11, wzr
    4eac:      	b	0x4eb8 <generic_fentry_process_filter+0x1d08>
    4eb0:      	and	w11, w11, #0xfffffffc
    4eb4:      	ldr	w11, [x23, w11, uxtw]
    4eb8:      	cmp	w24, #0x5
    4ebc:      	cset	w12, ne
    4ec0:      	cmp	w24, #0x6
    4ec4:      	cset	w13, ne
    4ec8:      	cmp	w11, w9
    4ecc:      	csinc	w11, w12, wzr, ne
    4ed0:      	csinc	w12, w13, wzr, eq
    4ed4:      	cmp	x10, #0x1
    4ed8:      	and	w11, w11, w12
    4edc:      	str	w11, [sp, #0x5c]
    4ee0:      	b.eq	0x4f6c <generic_fentry_process_filter+0x1dbc>
    4ee4:      	add	w11, w8, #0x14
    4ee8:      	cmp	w11, #0x3e8
    4eec:      	b.ls	0x4ef8 <generic_fentry_process_filter+0x1d48>
    4ef0:      	mov	w11, wzr
    4ef4:      	b	0x4f00 <generic_fentry_process_filter+0x1d50>
    4ef8:      	and	w11, w11, #0xfffffffc
    4efc:      	ldr	w11, [x23, w11, uxtw]
    4f00:      	cmp	w24, #0x5
    4f04:      	cset	w12, ne
    4f08:      	cmp	w24, #0x6
    4f0c:      	cset	w13, ne
    4f10:      	cmp	w11, w9
    4f14:      	csinc	w11, w12, wzr, ne
    4f18:      	csinc	w12, w13, wzr, eq
    4f1c:      	cmp	x10, #0x2
    4f20:      	and	w11, w11, w12
    4f24:      	str	w11, [sp, #0x60]
    4f28:      	b.eq	0x4f6c <generic_fentry_process_filter+0x1dbc>
    4f2c:      	add	w8, w8, #0x18
    4f30:      	cmp	w8, #0x3e8
    4f34:      	b.ls	0x4f40 <generic_fentry_process_filter+0x1d90>
    4f38:      	mov	w8, wzr
    4f3c:      	b	0x4f48 <generic_fentry_process_filter+0x1d98>
    4f40:      	and	w8, w8, #0xfffffffc
    4f44:      	ldr	w8, [x23, w8, uxtw]
    4f48:      	cmp	w24, #0x5
    4f4c:      	cset	w10, ne
    4f50:      	cmp	w24, #0x6
    4f54:      	cset	w11, ne
    4f58:      	cmp	w8, w9
    4f5c:      	csinc	w8, w10, wzr, ne
    4f60:      	csinc	w9, w11, wzr, eq
    4f64:      	and	w8, w8, w9
    4f68:      	str	w8, [sp, #0x64]
    4f6c:      	ldp	w8, w9, [sp, #0x58]
    4f70:      	ldp	w10, w11, [sp, #0x60]
    4f74:      	cmp	w24, #0x6
    4f78:      	b.ne	0x4f8c <generic_fentry_process_filter+0x1ddc>
    4f7c:      	and	w8, w9, w8
    4f80:      	and	w9, w10, w11
    4f84:      	and	w9, w8, w9
    4f88:      	b	0x4f98 <generic_fentry_process_filter+0x1de8>
    4f8c:      	orr	w8, w9, w8
    4f90:      	orr	w9, w10, w11
    4f94:      	orr	w9, w8, w9
    4f98:      	cbz	w9, 0x5494 <generic_fentry_process_filter+0x22e4>
    4f9c:      	lsl	w8, w29, #2
    4fa0:      	sub	w10, w22, w29, lsl #2
    4fa4:      	and	w8, w8, #0x1c
    4fa8:      	sub	w22, w10, #0xc
    4fac:      	add	w8, w8, w21
    4fb0:      	b	0x4de0 <generic_fentry_process_filter+0x1c30>
    4fb4:      	mov	w10, w8
    4fb8:      	add	w19, w8, #0x4
    4fbc:      	and	x10, x10, #0x3ff
    4fc0:      	ldr	w10, [x10, x23]
    4fc4:      	cmp	w10, #0x4
    4fc8:      	b.ne	0x5060 <generic_fentry_process_filter+0x1eb0>
    4fcc:      	cbz	w9, 0x5494 <generic_fentry_process_filter+0x22e4>
    4fd0:      	mov	w8, w19
    4fd4:      	and	x8, x8, #0x3ff
    4fd8:      	ldr	w9, [x8, x23]
    4fdc:      	add	w8, w19, #0x4
    4fe0:      	cmp	w9, #0x4
    4fe4:      	mov	w9, w8
    4fe8:      	b.eq	0x5390 <generic_fentry_process_filter+0x21e0>
    4fec:      	and	x8, x8, #0x3ff
    4ff0:      	add	x8, x8, x23
    4ff4:      	ldp	w20, w22, [x8]
    4ff8:      	mov	w8, #0xe                // =14
    4ffc:      	blr	x8
    5000:      	lsr	x8, x0, #32
    5004:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x1e50>
    5008:      	add	x9, sp, #0x58
    500c:      	str	w8, [sp, #0x58]
    5010:      	mov	w8, #0x1                // =1
    5014:      	add	x1, sp, #0x58
    5018:      	ldr	x0, [x0]
    501c:      	blr	x8
    5020:      	cbz	x0, 0x5494 <generic_fentry_process_filter+0x22e4>
    5024:      	cmp	w20, #0x5
    5028:      	b.eq	0x50dc <generic_fentry_process_filter+0x1f2c>
    502c:      	cmp	w20, #0x6
    5030:      	b.ne	0x5494 <generic_fentry_process_filter+0x22e4>
    5034:      	ldr	x11, [sp, #0xe8]
    5038:      	mov	w8, #0x5ee8             // =24296
    503c:      	add	x8, x11, x8
    5040:      	tbnz	w22, #0x0, 0x5110 <generic_fentry_process_filter+0x1f60>
    5044:      	ldr	w9, [x0, #0x28]
    5048:      	cbz	w9, 0x5108 <generic_fentry_process_filter+0x1f58>
    504c:      	ldr	x10, [sp, #0x30]
    5050:      	ldr	w10, [x10]
    5054:      	cmp	w9, w10
    5058:      	b.eq	0x5110 <generic_fentry_process_filter+0x1f60>
    505c:      	b	0x5384 <generic_fentry_process_filter+0x21d4>
    5060:      	and	x9, x19, #0x3ff
    5064:      	add	w19, w8, #0x18
    5068:      	add	x9, x9, x23
    506c:      	ldp	w8, w10, [x9]
    5070:      	ldr	w12, [x9, #0x8]
    5074:      	ldur	x11, [x9, #0xc]
    5078:      	cbz	w12, 0x509c <generic_fentry_process_filter+0x1eec>
    507c:      	ldr	x14, [sp, #0xe8]
    5080:      	mov	w9, wzr
    5084:      	cmp	w8, #0x2
    5088:      	b.hi	0x4fcc <generic_fentry_process_filter+0x1e1c>
    508c:      	ldr	w13, [x14, #0x44]
    5090:      	cmp	w13, w12
    5094:      	b.ne	0x50b0 <generic_fentry_process_filter+0x1f00>
    5098:      	b	0x4fcc <generic_fentry_process_filter+0x1e1c>
    509c:      	ldr	x14, [sp, #0xe8]
    50a0:      	cmp	w8, #0x2
    50a4:      	b.ls	0x50b0 <generic_fentry_process_filter+0x1f00>
    50a8:      	mov	w9, wzr
    50ac:      	b	0x4fcc <generic_fentry_process_filter+0x1e1c>
    50b0:      	add	x9, x14, #0x48
    50b4:      	cmp	w10, #0x5
    50b8:      	ldr	x8, [x9, x8, lsl #3]
    50bc:      	and	x8, x8, x11
    50c0:      	b.ne	0x50d0 <generic_fentry_process_filter+0x1f20>
    50c4:      	cmp	x8, #0x0
    50c8:      	cset	w9, ne
    50cc:      	b	0x4fcc <generic_fentry_process_filter+0x1e1c>
    50d0:      	cmp	x8, #0x0
    50d4:      	cset	w9, eq
    50d8:      	b	0x4fcc <generic_fentry_process_filter+0x1e1c>
    50dc:      	ldr	x11, [sp, #0xe8]
    50e0:      	mov	w8, #0x5ee8             // =24296
    50e4:      	add	x8, x11, x8
    50e8:      	tbz	w22, #0x0, 0x5134 <generic_fentry_process_filter+0x1f84>
    50ec:      	ldr	w9, [x0, #0x28]
    50f0:      	cbz	w9, 0x512c <generic_fentry_process_filter+0x1f7c>
    50f4:      	ldr	x10, [sp, #0x30]
    50f8:      	ldr	w10, [x10]
    50fc:      	cmp	w9, w10
    5100:      	b.eq	0x5134 <generic_fentry_process_filter+0x1f84>
    5104:      	b	0x5384 <generic_fentry_process_filter+0x21d4>
    5108:      	mov	w9, #0x1                // =1
    510c:      	str	x9, [x8]
    5110:      	tbnz	w22, #0x1, 0x5158 <generic_fentry_process_filter+0x1fa8>
    5114:      	ldr	w9, [x0, #0x2c]
    5118:      	cbz	w9, 0x5150 <generic_fentry_process_filter+0x1fa0>
    511c:      	ldr	w10, [x11, #0x24]
    5120:      	cmp	w9, w10
    5124:      	b.eq	0x5158 <generic_fentry_process_filter+0x1fa8>
    5128:      	b	0x5384 <generic_fentry_process_filter+0x21d4>
    512c:      	mov	w9, #0x1                // =1
    5130:      	str	x9, [x8]
    5134:      	tbz	w22, #0x1, 0x517c <generic_fentry_process_filter+0x1fcc>
    5138:      	ldr	w9, [x0, #0x2c]
    513c:      	cbz	w9, 0x5174 <generic_fentry_process_filter+0x1fc4>
    5140:      	ldr	w10, [x11, #0x24]
    5144:      	cmp	w9, w10
    5148:      	b.eq	0x517c <generic_fentry_process_filter+0x1fcc>
    514c:      	b	0x5384 <generic_fentry_process_filter+0x21d4>
    5150:      	mov	w9, #0x1                // =1
    5154:      	str	x9, [x8]
    5158:      	tbnz	w22, #0x2, 0x51a0 <generic_fentry_process_filter+0x1ff0>
    515c:      	ldr	w9, [x0, #0x30]
    5160:      	cbz	w9, 0x5198 <generic_fentry_process_filter+0x1fe8>
    5164:      	ldr	w10, [x11, #0x28]
    5168:      	cmp	w9, w10
    516c:      	b.eq	0x51a0 <generic_fentry_process_filter+0x1ff0>
    5170:      	b	0x5384 <generic_fentry_process_filter+0x21d4>
    5174:      	mov	w9, #0x1                // =1
    5178:      	str	x9, [x8]
    517c:      	tbz	w22, #0x2, 0x51c4 <generic_fentry_process_filter+0x2014>
    5180:      	ldr	w9, [x0, #0x30]
    5184:      	cbz	w9, 0x51bc <generic_fentry_process_filter+0x200c>
    5188:      	ldr	w10, [x11, #0x28]
    518c:      	cmp	w9, w10
    5190:      	b.eq	0x51c4 <generic_fentry_process_filter+0x2014>
    5194:      	b	0x5384 <generic_fentry_process_filter+0x21d4>
    5198:      	mov	w9, #0x1                // =1
    519c:      	str	x9, [x8]
    51a0:      	tbnz	w22, #0x3, 0x51e8 <generic_fentry_process_filter+0x2038>
    51a4:      	ldr	w9, [x0, #0x34]
    51a8:      	cbz	w9, 0x51e0 <generic_fentry_process_filter+0x2030>
    51ac:      	ldr	w10, [x11, #0x2c]
    51b0:      	cmp	w9, w10
    51b4:      	b.eq	0x51e8 <generic_fentry_process_filter+0x2038>
    51b8:      	b	0x5384 <generic_fentry_process_filter+0x21d4>
    51bc:      	mov	w9, #0x1                // =1
    51c0:      	str	x9, [x8]
    51c4:      	tbz	w22, #0x3, 0x520c <generic_fentry_process_filter+0x205c>
    51c8:      	ldr	w9, [x0, #0x34]
    51cc:      	cbz	w9, 0x5204 <generic_fentry_process_filter+0x2054>
    51d0:      	ldr	w10, [x11, #0x2c]
    51d4:      	cmp	w9, w10
    51d8:      	b.eq	0x520c <generic_fentry_process_filter+0x205c>
    51dc:      	b	0x5384 <generic_fentry_process_filter+0x21d4>
    51e0:      	mov	w9, #0x1                // =1
    51e4:      	str	x9, [x8]
    51e8:      	tbnz	w22, #0x4, 0x5230 <generic_fentry_process_filter+0x2080>
    51ec:      	ldr	w9, [x0, #0x38]
    51f0:      	cbz	w9, 0x5228 <generic_fentry_process_filter+0x2078>
    51f4:      	ldr	w10, [x11, #0x30]
    51f8:      	cmp	w9, w10
    51fc:      	b.eq	0x5230 <generic_fentry_process_filter+0x2080>
    5200:      	b	0x5384 <generic_fentry_process_filter+0x21d4>
    5204:      	mov	w9, #0x1                // =1
    5208:      	str	x9, [x8]
    520c:      	tbz	w22, #0x4, 0x5254 <generic_fentry_process_filter+0x20a4>
    5210:      	ldr	w9, [x0, #0x38]
    5214:      	cbz	w9, 0x524c <generic_fentry_process_filter+0x209c>
    5218:      	ldr	w10, [x11, #0x30]
    521c:      	cmp	w9, w10
    5220:      	b.eq	0x5254 <generic_fentry_process_filter+0x20a4>
    5224:      	b	0x5384 <generic_fentry_process_filter+0x21d4>
    5228:      	mov	w9, #0x1                // =1
    522c:      	str	x9, [x8]
    5230:      	tbnz	w22, #0x5, 0x5278 <generic_fentry_process_filter+0x20c8>
    5234:      	ldr	w9, [x0, #0x3c]
    5238:      	cbz	w9, 0x5270 <generic_fentry_process_filter+0x20c0>
    523c:      	ldr	w10, [x11, #0x34]
    5240:      	cmp	w9, w10
    5244:      	b.eq	0x5278 <generic_fentry_process_filter+0x20c8>
    5248:      	b	0x5384 <generic_fentry_process_filter+0x21d4>
    524c:      	mov	w9, #0x1                // =1
    5250:      	str	x9, [x8]
    5254:      	tbz	w22, #0x5, 0x529c <generic_fentry_process_filter+0x20ec>
    5258:      	ldr	w9, [x0, #0x3c]
    525c:      	cbz	w9, 0x5294 <generic_fentry_process_filter+0x20e4>
    5260:      	ldr	w10, [x11, #0x34]
    5264:      	cmp	w9, w10
    5268:      	b.eq	0x529c <generic_fentry_process_filter+0x20ec>
    526c:      	b	0x5384 <generic_fentry_process_filter+0x21d4>
    5270:      	mov	w9, #0x1                // =1
    5274:      	str	x9, [x8]
    5278:      	tbnz	w22, #0x6, 0x52c0 <generic_fentry_process_filter+0x2110>
    527c:      	ldr	w9, [x0, #0x40]
    5280:      	cbz	w9, 0x52b8 <generic_fentry_process_filter+0x2108>
    5284:      	ldr	w10, [x11, #0x38]
    5288:      	cmp	w9, w10
    528c:      	b.eq	0x52c0 <generic_fentry_process_filter+0x2110>
    5290:      	b	0x5384 <generic_fentry_process_filter+0x21d4>
    5294:      	mov	w9, #0x1                // =1
    5298:      	str	x9, [x8]
    529c:      	tbz	w22, #0x6, 0x52e4 <generic_fentry_process_filter+0x2134>
    52a0:      	ldr	w9, [x0, #0x40]
    52a4:      	cbz	w9, 0x52dc <generic_fentry_process_filter+0x212c>
    52a8:      	ldr	w10, [x11, #0x38]
    52ac:      	cmp	w9, w10
    52b0:      	b.eq	0x52e4 <generic_fentry_process_filter+0x2134>
    52b4:      	b	0x5384 <generic_fentry_process_filter+0x21d4>
    52b8:      	mov	w9, #0x1                // =1
    52bc:      	str	x9, [x8]
    52c0:      	tbnz	w22, #0x7, 0x5308 <generic_fentry_process_filter+0x2158>
    52c4:      	ldr	w9, [x0, #0x44]
    52c8:      	cbz	w9, 0x5300 <generic_fentry_process_filter+0x2150>
    52cc:      	ldr	w10, [x11, #0x3c]
    52d0:      	cmp	w9, w10
    52d4:      	b.eq	0x5308 <generic_fentry_process_filter+0x2158>
    52d8:      	b	0x5384 <generic_fentry_process_filter+0x21d4>
    52dc:      	mov	w9, #0x1                // =1
    52e0:      	str	x9, [x8]
    52e4:      	tbz	w22, #0x7, 0x5330 <generic_fentry_process_filter+0x2180>
    52e8:      	ldr	w9, [x0, #0x44]
    52ec:      	cbz	w9, 0x5328 <generic_fentry_process_filter+0x2178>
    52f0:      	ldr	w10, [x11, #0x3c]
    52f4:      	cmp	w9, w10
    52f8:      	b.eq	0x5330 <generic_fentry_process_filter+0x2180>
    52fc:      	b	0x5384 <generic_fentry_process_filter+0x21d4>
    5300:      	mov	w9, #0x1                // =1
    5304:      	str	x9, [x8]
    5308:      	tbnz	w22, #0x8, 0x5358 <generic_fentry_process_filter+0x21a8>
    530c:      	ldr	w9, [x0, #0x48]
    5310:      	cbz	w9, 0x5350 <generic_fentry_process_filter+0x21a0>
    5314:      	ldr	x10, [sp, #0xe8]
    5318:      	ldr	w10, [x10, #0x40]
    531c:      	cmp	w9, w10
    5320:      	b.eq	0x5358 <generic_fentry_process_filter+0x21a8>
    5324:      	b	0x5384 <generic_fentry_process_filter+0x21d4>
    5328:      	mov	w9, #0x1                // =1
    532c:      	str	x9, [x8]
    5330:      	tbz	w22, #0x8, 0x5368 <generic_fentry_process_filter+0x21b8>
    5334:      	ldr	w9, [x0, #0x48]
    5338:      	cbz	w9, 0x5360 <generic_fentry_process_filter+0x21b0>
    533c:      	ldr	x10, [sp, #0xe8]
    5340:      	ldr	w10, [x10, #0x40]
    5344:      	cmp	w9, w10
    5348:      	b.eq	0x5368 <generic_fentry_process_filter+0x21b8>
    534c:      	b	0x5384 <generic_fentry_process_filter+0x21d4>
    5350:      	mov	w9, #0x1                // =1
    5354:      	str	x9, [x8]
    5358:      	tbz	w22, #0x9, 0x536c <generic_fentry_process_filter+0x21bc>
    535c:      	b	0x5494 <generic_fentry_process_filter+0x22e4>
    5360:      	mov	w9, #0x1                // =1
    5364:      	str	x9, [x8]
    5368:      	tbz	w22, #0x9, 0x5494 <generic_fentry_process_filter+0x22e4>
    536c:      	ldr	w9, [x0, #0x4c]
    5370:      	cbz	w9, 0x548c <generic_fentry_process_filter+0x22dc>
    5374:      	ldr	x10, [sp, #0xe8]
    5378:      	ldr	w10, [x10, #0x44]
    537c:      	cmp	w9, w10
    5380:      	b.eq	0x5494 <generic_fentry_process_filter+0x22e4>
    5384:      	add	w9, w19, #0xc
    5388:      	mov	w10, #0x1               // =1
    538c:      	str	x10, [x8]
    5390:      	and	x8, x9, #0x3ff
    5394:      	adrp	x24, 0x5000 <generic_fentry_process_filter+0x1e50>
    5398:      	ldr	w8, [x8, x23]
    539c:      	ldr	x24, [x24]
    53a0:      	cmp	w8, #0x4
    53a4:      	b.ne	0x53d8 <generic_fentry_process_filter+0x2228>
    53a8:      	ldr	x9, [sp, #0xe8]
    53ac:      	mov	w8, #0x5eb8             // =24248
    53b0:      	add	x8, x9, x8
    53b4:      	ldr	x9, [x9, #0x5eb8]
    53b8:      	and	x9, x9, #0x1f
    53bc:      	add	x8, x8, x9
    53c0:      	mov	w9, #0x1                // =1
    53c4:      	strb	w9, [x8, #0x9]
    53c8:      	ldr	x8, [sp, #0x40]
    53cc:      	strb	w9, [x8, #0x20]
    53d0:      	strb	w9, [x8]
    53d4:      	b	0x5494 <generic_fentry_process_filter+0x22e4>
    53d8:      	add	w8, w9, #0x4
    53dc:      	and	x8, x8, #0x3ff
    53e0:      	add	x8, x8, x23
    53e4:      	ldp	w21, w19, [x8]
    53e8:      	ldr	w22, [x8, #0x8]
    53ec:      	ldur	x20, [x8, #0xc]
    53f0:      	mov	w8, #0xe                // =14
    53f4:      	blr	x8
    53f8:      	lsr	x8, x0, #32
    53fc:      	add	x9, sp, #0x58
    5400:      	add	x1, sp, #0x58
    5404:      	str	w8, [sp, #0x58]
    5408:      	mov	w8, #0x1                // =1
    540c:      	mov	x0, x24
    5410:      	blr	x8
    5414:      	cbz	x0, 0x5494 <generic_fentry_process_filter+0x22e4>
    5418:      	cmp	w21, #0x2
    541c:      	cbz	w22, 0x5438 <generic_fentry_process_filter+0x2288>
    5420:      	b.hi	0x5494 <generic_fentry_process_filter+0x22e4>
    5424:      	ldr	x8, [sp, #0xe8]
    5428:      	ldr	w8, [x8, #0x44]
    542c:      	cmp	w8, w22
    5430:      	b.ne	0x543c <generic_fentry_process_filter+0x228c>
    5434:      	b	0x5494 <generic_fentry_process_filter+0x22e4>
    5438:      	b.hi	0x5494 <generic_fentry_process_filter+0x22e4>
    543c:      	ldr	x8, [sp, #0xe8]
    5440:      	lsl	x10, x21, #3
    5444:      	add	x9, x8, #0x48
    5448:      	add	x8, x0, x21, lsl #3
    544c:      	ldr	x8, [x8, #0x50]
    5450:      	ldr	x9, [x9, x10]
    5454:      	eor	x10, x9, x8
    5458:      	tst	x10, x20
    545c:      	b.eq	0x546c <generic_fentry_process_filter+0x22bc>
    5460:      	cmp	w19, #0x5
    5464:      	b.eq	0x547c <generic_fentry_process_filter+0x22cc>
    5468:      	b	0x5494 <generic_fentry_process_filter+0x22e4>
    546c:      	cmp	x8, x9
    5470:      	b.eq	0x5494 <generic_fentry_process_filter+0x22e4>
    5474:      	cmp	w19, #0x6
    5478:      	b.ne	0x5494 <generic_fentry_process_filter+0x22e4>
    547c:      	ldr	x9, [sp, #0xe8]
    5480:      	mov	w8, #0x1                // =1
    5484:      	str	x8, [x9, #0x5ef0]
    5488:      	b	0x53a8 <generic_fentry_process_filter+0x21f8>
    548c:      	mov	w9, #0x1                // =1
    5490:      	str	x9, [x8]
    5494:      	ldr	x9, [sp, #0xe8]
    5498:      	ldr	x10, [sp, #0x28]
    549c:      	ldr	x8, [x9, #0x5eb8]
    54a0:      	add	x8, x8, #0x1
    54a4:      	cmp	x8, x10
    54a8:      	str	x8, [x9, #0x5eb8]
    54ac:      	b.ls	0x550c <generic_fentry_process_filter+0x235c>
    54b0:      	ldr	x10, [sp, #0x48]
    54b4:      	ldr	w8, [x10]
    54b8:      	str	w8, [x9, #0x10]
    54bc:      	ldr	x8, [x10, #0x8]
    54c0:      	str	x8, [x9, #0x18]
    54c4:      	ldp	x20, x8, [sp, #0x38]
    54c8:      	ldrb	w8, [x8]
    54cc:      	cbz	w8, 0x54ec <generic_fentry_process_filter+0x233c>
    54d0:      	adrp	x1, 0x5000 <generic_fentry_process_filter+0x1e50>
    54d4:      	mov	x8, xzr
    54d8:      	mov	w9, #0xc                // =12
    54dc:      	ldr	x1, [x1]
    54e0:      	mov	x0, x20
    54e4:      	mov	w2, wzr
    54e8:      	blr	x9
    54ec:      	ldp	x20, x19, [sp, #0x120]
    54f0:      	mov	w0, wzr
    54f4:      	ldr	x29, [sp, #0xe0]
    54f8:      	ldp	x22, x21, [sp, #0x110]
    54fc:      	ldp	x24, x23, [sp, #0x100]
    5500:      	ldp	x30, x25, [sp, #0xf0]
    5504:      	add	sp, sp, #0x130
    5508:      	ret
    550c:      	adrp	x1, 0x5000 <generic_fentry_process_filter+0x1e50>
    5510:      	mov	w8, #0x2                // =2
    5514:      	mov	w9, #0xc                // =12
    5518:      	ldr	x1, [x1]
    551c:      	ldr	x0, [sp, #0x38]
    5520:      	mov	w2, #0x2                // =2
    5524:      	b	0x54e8 <generic_fentry_process_filter+0x2338>
    5528:      	nop
    552c:      	nop

0000000000005530 <generic_fentry_filter_arg>:
    5530:      	sub	sp, sp, #0x70
    5534:      	str	x29, [sp, #0x20]
    5538:      	stp	x30, x25, [sp, #0x30]
    553c:      	stp	x24, x23, [sp, #0x40]
    5540:      	stp	x22, x21, [sp, #0x50]
    5544:      	stp	x20, x19, [sp, #0x60]
    5548:      	mov	x19, x0
    554c:      	str	wzr, [sp, #0x2c]
    5550:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x1e50>
    5554:      	mov	w8, #0x1                // =1
    5558:      	ldr	x0, [x0]
    555c:      	add	x9, sp, #0x2c
    5560:      	add	x1, sp, #0x2c
    5564:      	blr	x8
    5568:      	cbz	x0, 0x58f4 <generic_fentry_filter_arg+0x3c4>
    556c:      	mov	w8, #0x5ec1             // =24257
    5570:      	mov	x20, x0
    5574:      	add	x22, x0, x8
    5578:      	mov	w8, #0x5ef8             // =24312
    557c:      	add	x1, x0, x8
    5580:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x1e50>
    5584:      	ldur	w23, [x22, #0x3f]
    5588:      	mov	w8, #0x1                // =1
    558c:      	ldr	x0, [x0]
    5590:      	blr	x8
    5594:      	cbz	x0, 0x58d8 <generic_fentry_filter_arg+0x3a8>
    5598:      	ldrb	w8, [x22, #0x1f]
    559c:      	cbz	w8, 0x58d8 <generic_fentry_filter_arg+0x3a8>
    55a0:      	and	x8, x23, #0x7
    55a4:      	mov	w10, #0x5ec1            // =24257
    55a8:      	add	x9, x20, x8
    55ac:      	ldrb	w9, [x9, x10]
    55b0:      	cbz	w9, 0x5630 <generic_fentry_filter_arg+0x100>
    55b4:      	lsl	w8, w8, #2
    55b8:      	mov	x21, x0
    55bc:      	add	x8, x8, #0x4
    55c0:      	ldr	w9, [x8, x0]
    55c4:      	add	x8, x8, x9
    55c8:      	add	x8, x8, #0x4
    55cc:      	and	x9, x8, #0x3ff
    55d0:      	ldr	w9, [x9, x0]
    55d4:      	add	x8, x8, x9
    55d8:      	and	x9, x8, #0x3ff
    55dc:      	ldr	w9, [x9, x0]
    55e0:      	add	x8, x8, x9
    55e4:      	and	x9, x8, #0x3ff
    55e8:      	ldr	w9, [x9, x0]
    55ec:      	add	x8, x8, x9
    55f0:      	and	x9, x8, #0x3ff
    55f4:      	ldr	w9, [x9, x0]
    55f8:      	add	x8, x8, x9
    55fc:      	and	x9, x8, #0x3ff
    5600:      	ldr	w9, [x9, x0]
    5604:      	add	x25, x8, x9
    5608:      	and	x8, x25, #0x3ff
    560c:      	add	x29, x0, x8
    5610:      	str	x8, [sp, #0x8]
    5614:      	ldr	w8, [x29]
    5618:      	cmp	w8, #0x19
    561c:      	b.hs	0x5678 <generic_fentry_filter_arg+0x148>
    5620:      	ldr	x8, [sp, #0x8]
    5624:      	cmp	w8, #0x1
    5628:      	b.eq	0x58d8 <generic_fentry_filter_arg+0x3a8>
    562c:      	cbnz	w8, 0x58b4 <generic_fentry_filter_arg+0x384>
    5630:      	cmp	w23, #0x1
    5634:      	b.gt	0x5650 <generic_fentry_filter_arg+0x120>
    5638:      	cmn	w23, #0x1
    563c:      	b.eq	0x5914 <generic_fentry_filter_arg+0x3e4>
    5640:      	cbz	w23, 0x5924 <generic_fentry_filter_arg+0x3f4>
    5644:      	cmp	w23, #0x1
    5648:      	b.eq	0x5934 <generic_fentry_filter_arg+0x404>
    564c:      	b	0x5668 <generic_fentry_filter_arg+0x138>
    5650:      	cmp	w23, #0x2
    5654:      	b.eq	0x5944 <generic_fentry_filter_arg+0x414>
    5658:      	cmp	w23, #0x3
    565c:      	b.eq	0x5954 <generic_fentry_filter_arg+0x424>
    5660:      	cmp	w23, #0x4
    5664:      	b.eq	0x5964 <generic_fentry_filter_arg+0x434>
    5668:      	cmp	w23, #0x4
    566c:      	b.gt	0x5990 <generic_fentry_filter_arg+0x460>
    5670:      	add	w8, w23, #0x1
    5674:      	b	0x5970 <generic_fentry_filter_arg+0x440>
    5678:      	mov	w24, #0x4               // =4
    567c:      	nop
    5680:      	ldr	w8, [x29, x24]
    5684:      	tst	w8, #0x3ff
    5688:      	b.eq	0x5620 <generic_fentry_filter_arg+0xf0>
    568c:      	add	w8, w25, w8
    5690:      	and	x8, x8, #0x3ff
    5694:      	add	x0, x21, x8
    5698:      	ldr	w9, [x0, #0x4]
    569c:      	cmp	w9, #0x23
    56a0:      	b.eq	0x5630 <generic_fentry_filter_arg+0x100>
    56a4:      	ldr	w8, [x0]
    56a8:      	cmp	w8, #0x4
    56ac:      	b.hi	0x5630 <generic_fentry_filter_arg+0x100>
    56b0:      	add	x10, x20, x8, lsl #2
    56b4:      	mov	w11, #0x5ea0            // =24224
    56b8:      	ldr	w10, [x10, x11]
    56bc:      	cbnz	w10, 0x5630 <generic_fentry_filter_arg+0x100>
    56c0:      	add	x8, x20, x8, lsl #3
    56c4:      	ldr	x8, [x8, #0x5e78]
    56c8:      	and	x8, x8, #0x7ff
    56cc:      	add	x8, x20, x8
    56d0:      	add	x1, x8, #0x90
    56d4:      	ldr	w8, [x0, #0xc]
    56d8:      	cmp	w8, #0x1b
    56dc:      	b.le	0x5700 <generic_fentry_filter_arg+0x1d0>
    56e0:      	cmp	w8, #0x25
    56e4:      	b.gt	0x5734 <generic_fentry_filter_arg+0x204>
    56e8:      	sub	w10, w8, #0x1c
    56ec:      	cmp	w10, #0x9
    56f0:      	b.lo	0x5778 <generic_fentry_filter_arg+0x248>
    56f4:      	cmp	w8, #0x25
    56f8:      	b.eq	0x5860 <generic_fentry_filter_arg+0x330>
    56fc:      	b	0x58a4 <generic_fentry_filter_arg+0x374>
    5700:      	cmp	w8, #0x9
    5704:      	b.le	0x5758 <generic_fentry_filter_arg+0x228>
    5708:      	sub	w10, w8, #0xa
    570c:      	cmp	w10, #0x4
    5710:      	b.lo	0x5778 <generic_fentry_filter_arg+0x248>
    5714:      	sub	w9, w8, #0xf
    5718:      	cmp	w9, #0x2
    571c:      	b.lo	0x5860 <generic_fentry_filter_arg+0x330>
    5720:      	cmp	w8, #0x11
    5724:      	b.ne	0x58a4 <generic_fentry_filter_arg+0x374>
    5728:      	add	x1, x1, #0x4
    572c:      	bl	0x572c <generic_fentry_filter_arg+0x1fc>
    5730:      	b	0x58a0 <generic_fentry_filter_arg+0x370>
    5734:      	cmp	w8, #0x29
    5738:      	b.gt	0x5848 <generic_fentry_filter_arg+0x318>
    573c:      	sub	w9, w8, #0x26
    5740:      	cmp	w9, #0x2
    5744:      	b.lo	0x57fc <generic_fentry_filter_arg+0x2cc>
    5748:      	sub	w8, w8, #0x28
    574c:      	cmp	w8, #0x2
    5750:      	b.lo	0x57f4 <generic_fentry_filter_arg+0x2c4>
    5754:      	b	0x58a4 <generic_fentry_filter_arg+0x374>
    5758:      	cmp	w8, #0x4
    575c:      	b.gt	0x57dc <generic_fentry_filter_arg+0x2ac>
    5760:      	cmp	w8, #0x1
    5764:      	b.eq	0x5778 <generic_fentry_filter_arg+0x248>
    5768:      	cmp	w8, #0x2
    576c:      	b.eq	0x5884 <generic_fentry_filter_arg+0x354>
    5770:      	cmp	w8, #0x4
    5774:      	b.ne	0x58a4 <generic_fentry_filter_arg+0x374>
    5778:      	cmp	w8, #0xb
    577c:      	b.le	0x57bc <generic_fentry_filter_arg+0x28c>
    5780:      	cmp	w8, #0x24
    5784:      	b.hi	0x5868 <generic_fentry_filter_arg+0x338>
    5788:      	mov	w11, #0x1               // =1
    578c:      	lsl	x10, x11, x8
    5790:      	tst	x10, #0x1e00000000
    5794:      	b.ne	0x5804 <generic_fentry_filter_arg+0x2d4>
    5798:      	lsl	x9, x11, x8
    579c:      	tst	x9, #0x60000000
    57a0:      	mov	w9, #0x1                // =1
    57a4:      	b.ne	0x587c <generic_fentry_filter_arg+0x34c>
    57a8:      	lsl	x9, x9, x8
    57ac:      	tst	x9, #0x180000000
    57b0:      	b.eq	0x5868 <generic_fentry_filter_arg+0x338>
    57b4:      	bl	0x57b4 <generic_fentry_filter_arg+0x284>
    57b8:      	b	0x58a0 <generic_fentry_filter_arg+0x370>
    57bc:      	sub	w9, w8, #0xa
    57c0:      	cmp	w9, #0x2
    57c4:      	b.lo	0x5898 <generic_fentry_filter_arg+0x368>
    57c8:      	cmp	w8, #0x1
    57cc:      	b.eq	0x5874 <generic_fentry_filter_arg+0x344>
    57d0:      	cmp	w8, #0x4
    57d4:      	b.eq	0x5874 <generic_fentry_filter_arg+0x344>
    57d8:      	b	0x58a4 <generic_fentry_filter_arg+0x374>
    57dc:      	cmp	w8, #0x5
    57e0:      	b.eq	0x57f4 <generic_fentry_filter_arg+0x2c4>
    57e4:      	cmp	w8, #0x6
    57e8:      	b.eq	0x57fc <generic_fentry_filter_arg+0x2cc>
    57ec:      	cmp	w8, #0x7
    57f0:      	b.ne	0x58a4 <generic_fentry_filter_arg+0x374>
    57f4:      	bl	0x57f4 <generic_fentry_filter_arg+0x2c4>
    57f8:      	b	0x58a0 <generic_fentry_filter_arg+0x370>
    57fc:      	mov	w2, #0x4                // =4
    5800:      	b	0x5888 <generic_fentry_filter_arg+0x358>
    5804:      	cmp	w9, #0x1e
    5808:      	b.ne	0x5898 <generic_fentry_filter_arg+0x368>
    580c:      	ldr	w8, [x0, #0x10]
    5810:      	mov	w10, #0x5ea0            // =24224
    5814:      	and	x8, x8, #0x7
    5818:      	add	x9, x20, x8, lsl #2
    581c:      	ldr	w9, [x9, x10]
    5820:      	cbnz	w9, 0x5630 <generic_fentry_filter_arg+0x100>
    5824:      	add	x8, x20, x8, lsl #3
    5828:      	ldr	x9, [x1]
    582c:      	ldr	x8, [x8, #0x5e78]
    5830:      	and	x8, x8, #0x7ff
    5834:      	add	x8, x20, x8
    5838:      	ldr	x8, [x8, #0x90]
    583c:      	bics	xzr, x8, x9
    5840:      	cset	w0, ne
    5844:      	b	0x58a0 <generic_fentry_filter_arg+0x370>
    5848:      	cmp	w8, #0x2a
    584c:      	b.eq	0x5860 <generic_fentry_filter_arg+0x330>
    5850:      	cmp	w8, #0x2c
    5854:      	b.ne	0x58a4 <generic_fentry_filter_arg+0x374>
    5858:      	bl	0x5858 <generic_fentry_filter_arg+0x328>
    585c:      	b	0x58a0 <generic_fentry_filter_arg+0x370>
    5860:      	bl	0x5860 <generic_fentry_filter_arg+0x330>
    5864:      	b	0x58a0 <generic_fentry_filter_arg+0x370>
    5868:      	sub	w9, w8, #0xc
    586c:      	cmp	w9, #0x2
    5870:      	b.hs	0x5890 <generic_fentry_filter_arg+0x360>
    5874:      	bl	0x5874 <generic_fentry_filter_arg+0x344>
    5878:      	b	0x58a0 <generic_fentry_filter_arg+0x370>
    587c:      	bl	0x587c <generic_fentry_filter_arg+0x34c>
    5880:      	b	0x58a0 <generic_fentry_filter_arg+0x370>
    5884:      	mov	w2, #0x8                // =8
    5888:      	bl	0x5888 <generic_fentry_filter_arg+0x358>
    588c:      	b	0x58a0 <generic_fentry_filter_arg+0x370>
    5890:      	cmp	w8, #0x1c
    5894:      	b.ne	0x58a4 <generic_fentry_filter_arg+0x374>
    5898:      	bl	0x5898 <generic_fentry_filter_arg+0x368>
    589c:      	nop
    58a0:      	cbz	x0, 0x5630 <generic_fentry_filter_arg+0x100>
    58a4:      	add	x24, x24, #0x4
    58a8:      	cmp	x24, #0x18
    58ac:      	b.ne	0x5680 <generic_fentry_filter_arg+0x150>
    58b0:      	b	0x5620 <generic_fentry_filter_arg+0xf0>
    58b4:      	ldr	x8, [sp, #0x8]
    58b8:      	adrp	x1, 0x5000 <generic_fentry_process_filter+0x1e50>
    58bc:      	mov	w9, #0xc                // =12
    58c0:      	mov	x0, x19
    58c4:      	stur	w8, [x22, #0x43]
    58c8:      	mov	w8, #0x4                // =4
    58cc:      	mov	w2, #0x4                // =4
    58d0:      	ldr	x1, [x1]
    58d4:      	blr	x9
    58d8:      	adrp	x1, 0x5000 <generic_fentry_process_filter+0x1e50>
    58dc:      	mov	w8, #0x5                // =5
    58e0:      	mov	w9, #0xc                // =12
    58e4:      	ldr	x1, [x1]
    58e8:      	mov	x0, x19
    58ec:      	mov	w2, #0x5                // =5
    58f0:      	blr	x9
    58f4:      	ldp	x20, x19, [sp, #0x60]
    58f8:      	mov	w0, wzr
    58fc:      	ldr	x29, [sp, #0x20]
    5900:      	ldp	x22, x21, [sp, #0x50]
    5904:      	ldp	x24, x23, [sp, #0x40]
    5908:      	ldp	x30, x25, [sp, #0x30]
    590c:      	add	sp, sp, #0x70
    5910:      	ret
    5914:      	ldrb	w8, [x22]
    5918:      	cbz	w8, 0x5924 <generic_fentry_filter_arg+0x3f4>
    591c:      	mov	w8, wzr
    5920:      	b	0x5970 <generic_fentry_filter_arg+0x440>
    5924:      	ldrb	w8, [x22, #0x1]
    5928:      	cbz	w8, 0x5934 <generic_fentry_filter_arg+0x404>
    592c:      	mov	w8, #0x1                // =1
    5930:      	b	0x5970 <generic_fentry_filter_arg+0x440>
    5934:      	ldrb	w8, [x22, #0x2]
    5938:      	cbz	w8, 0x5944 <generic_fentry_filter_arg+0x414>
    593c:      	mov	w8, #0x2                // =2
    5940:      	b	0x5970 <generic_fentry_filter_arg+0x440>
    5944:      	ldrb	w8, [x22, #0x3]
    5948:      	cbz	w8, 0x5954 <generic_fentry_filter_arg+0x424>
    594c:      	mov	w8, #0x3                // =3
    5950:      	b	0x5970 <generic_fentry_filter_arg+0x440>
    5954:      	ldrb	w8, [x22, #0x4]
    5958:      	cbz	w8, 0x5964 <generic_fentry_filter_arg+0x434>
    595c:      	mov	w8, #0x4                // =4
    5960:      	b	0x5970 <generic_fentry_filter_arg+0x440>
    5964:      	ldrb	w8, [x22, #0x5]
    5968:      	cbz	w8, 0x5990 <generic_fentry_filter_arg+0x460>
    596c:      	mov	w8, #0x5                // =5
    5970:      	stur	w8, [x22, #0x3f]
    5974:      	adrp	x1, 0x5000 <generic_fentry_process_filter+0x1e50>
    5978:      	mov	w8, #0x3                // =3
    597c:      	mov	w9, #0xc                // =12
    5980:      	ldr	x1, [x1]
    5984:      	mov	x0, x19
    5988:      	mov	w2, #0x3                // =3
    598c:      	blr	x9
    5990:      	ldr	x19, [x20, #0x60]
    5994:      	mov	w8, #0xe                // =14
    5998:      	blr	x8
    599c:      	stp	x19, x0, [sp, #0x10]
    59a0:      	adrp	x19, 0x5000 <generic_fentry_process_filter+0x1e50>
    59a4:      	mov	w8, #0x1                // =1
    59a8:      	add	x9, sp, #0x10
    59ac:      	add	x1, sp, #0x10
    59b0:      	ldr	x19, [x19]
    59b4:      	mov	x0, x19
    59b8:      	blr	x8
    59bc:      	cbz	x0, 0x58f4 <generic_fentry_filter_arg+0x3c4>
    59c0:      	mov	w8, #0x3                // =3
    59c4:      	add	x9, sp, #0x10
    59c8:      	add	x1, sp, #0x10
    59cc:      	mov	x0, x19
    59d0:      	blr	x8
    59d4:      	b	0x58f4 <generic_fentry_filter_arg+0x3c4>
    59d8:      	nop
    59dc:      	nop

00000000000059e0 <generic_fentry_actions>:
    59e0:      	sub	sp, sp, #0x40
    59e4:      	str	x30, [sp, #0x10]
    59e8:      	stp	x22, x21, [sp, #0x20]
    59ec:      	stp	x20, x19, [sp, #0x30]
    59f0:      	mov	x19, x0
    59f4:      	str	wzr, [sp, #0xc]
    59f8:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x1e50>
    59fc:      	mov	w8, #0x1                // =1
    5a00:      	ldr	x0, [x0]
    5a04:      	add	x9, sp, #0xc
    5a08:      	add	x1, sp, #0xc
    5a0c:      	blr	x8
    5a10:      	cbz	x0, 0x5b28 <generic_fentry_actions+0x148>
    5a14:      	mov	w8, #0x5f04             // =24324
    5a18:      	ldr	w22, [x0, x8]
    5a1c:      	cmp	w22, #0x2
    5a20:      	b.lt	0x5b28 <generic_fentry_actions+0x148>
    5a24:      	mov	w8, #0x5ef8             // =24312
    5a28:      	mov	w20, #0x1               // =1
    5a2c:      	add	x1, x0, x8
    5a30:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x1e50>
    5a34:      	mov	w8, #0x1                // =1
    5a38:      	ldr	x0, [x0]
    5a3c:      	blr	x8
    5a40:      	cbz	x0, 0x5b28 <generic_fentry_actions+0x148>
    5a44:      	and	x8, x22, #0x7ff
    5a48:      	mov	x21, x0
    5a4c:      	strb	w20, [sp, #0x1c]
    5a50:      	mov	w9, #0x1                // =1
    5a54:      	ldr	w8, [x0, x8]
    5a58:      	str	wzr, [sp, #0x18]
    5a5c:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x1e50>
    5a60:      	add	x1, sp, #0x18
    5a64:      	ldr	x0, [x0]
    5a68:      	add	w8, w8, w22
    5a6c:      	and	w22, w8, #0x7ff
    5a70:      	add	x8, sp, #0x18
    5a74:      	blr	x9
    5a78:      	cbz	x0, 0x5a88 <generic_fentry_actions+0xa8>
    5a7c:      	ldrb	w8, [x0]
    5a80:      	cmp	w8, #0x0
    5a84:      	cset	w20, eq
    5a88:      	ldr	w8, [x21, x22]
    5a8c:      	cmp	w8, #0x5
    5a90:      	b.lo	0x5b04 <generic_fentry_actions+0x124>
    5a94:      	add	x2, x21, x22
    5a98:      	add	x3, sp, #0x1c
    5a9c:      	mov	x0, x19
    5aa0:      	mov	w1, wzr
    5aa4:      	mov	w4, w20
    5aa8:      	bl	0x5aa8 <generic_fentry_actions+0xc8>
    5aac:      	ldr	w9, [x21, x22]
    5ab0:      	lsl	w8, w0, #2
    5ab4:      	add	w8, w8, #0x4
    5ab8:      	cmp	w8, w9
    5abc:      	b.hs	0x5b04 <generic_fentry_actions+0x124>
    5ac0:      	mov	w1, w0
    5ac4:      	add	x2, x21, x22
    5ac8:      	add	x3, sp, #0x1c
    5acc:      	mov	x0, x19
    5ad0:      	mov	w4, w20
    5ad4:      	bl	0x5ad4 <generic_fentry_actions+0xf4>
    5ad8:      	ldr	w9, [x21, x22]
    5adc:      	lsl	w8, w0, #2
    5ae0:      	add	w8, w8, #0x4
    5ae4:      	cmp	w8, w9
    5ae8:      	b.hs	0x5b04 <generic_fentry_actions+0x124>
    5aec:      	mov	w1, w0
    5af0:      	add	x2, x21, x22
    5af4:      	add	x3, sp, #0x1c
    5af8:      	mov	x0, x19
    5afc:      	mov	w4, w20
    5b00:      	bl	0x5b00 <generic_fentry_actions+0x120>
    5b04:      	ldrb	w8, [sp, #0x1c]
    5b08:      	cbz	w8, 0x5b28 <generic_fentry_actions+0x148>
    5b0c:      	adrp	x1, 0x5000 <generic_fentry_process_filter+0x1e50>
    5b10:      	mov	w8, #0x5                // =5
    5b14:      	mov	w9, #0xc                // =12
    5b18:      	ldr	x1, [x1]
    5b1c:      	mov	x0, x19
    5b20:      	mov	w2, #0x5                // =5
    5b24:      	blr	x9
    5b28:      	ldp	x20, x19, [sp, #0x30]
    5b2c:      	mov	w0, wzr
    5b30:      	ldr	x30, [sp, #0x10]
    5b34:      	ldp	x22, x21, [sp, #0x20]
    5b38:      	add	sp, sp, #0x40
    5b3c:      	ret

0000000000005b40 <generic_fentry_output>:
    5b40:      	sub	sp, sp, #0xc0
    5b44:      	str	x29, [sp, #0x70]
    5b48:      	stp	x30, x25, [sp, #0x80]
    5b4c:      	stp	x24, x23, [sp, #0x90]
    5b50:      	stp	x22, x21, [sp, #0xa0]
    5b54:      	stp	x20, x19, [sp, #0xb0]
    5b58:      	mov	x20, x0
    5b5c:      	str	wzr, [sp, #0x4]
    5b60:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x1e50>
    5b64:      	mov	w8, #0x1                // =1
    5b68:      	ldr	x0, [x0]
    5b6c:      	add	x9, sp, #0x4
    5b70:      	add	x1, sp, #0x4
    5b74:      	blr	x8
    5b78:      	cbz	x0, 0x6110 <generic_fentry_output+0x5d0>
    5b7c:      	adrp	x21, 0x5000 <generic_fentry_process_filter+0x1e50>
    5b80:      	ldr	x8, [x0, #0x5ee8]
    5b84:      	mov	x19, x0
    5b88:      	ldr	x21, [x21]
    5b8c:      	cbz	x8, 0x5e18 <generic_fentry_output+0x2d8>
    5b90:      	mov	w8, #0xe                // =14
    5b94:      	blr	x8
    5b98:      	mov	w8, #0x23               // =35
    5b9c:      	lsr	x22, x0, #32
    5ba0:      	blr	x8
    5ba4:      	str	w22, [sp, #0x28]
    5ba8:      	mov	w8, #0x1                // =1
    5bac:      	add	x9, sp, #0x28
    5bb0:      	mov	x23, x0
    5bb4:      	add	x1, sp, #0x28
    5bb8:      	mov	x0, x21
    5bbc:      	blr	x8
    5bc0:      	cbz	x0, 0x5e18 <generic_fentry_output+0x2d8>
    5bc4:      	add	x2, x23, #0xb50
    5bc8:      	mov	w29, #0x8               // =8
    5bcc:      	add	x8, sp, #0x78
    5bd0:      	mov	w9, #0x4                // =4
    5bd4:      	mov	x22, x0
    5bd8:      	add	x24, x0, #0x28
    5bdc:      	add	x0, sp, #0x78
    5be0:      	mov	w1, #0x8                // =8
    5be4:      	mov	w25, #0x4               // =4
    5be8:      	blr	x9
    5bec:      	ldr	x8, [sp, #0x78]
    5bf0:      	mov	w9, #0x48               // =72
    5bf4:      	add	x10, sp, #0x28
    5bf8:      	mov	w11, #0x4               // =4
    5bfc:      	ldr	x2, [sp, #0x78]
    5c00:      	add	x0, sp, #0x28
    5c04:      	mov	w1, #0x48               // =72
    5c08:      	blr	x11
    5c0c:      	ldr	x8, [sp, #0x30]
    5c10:      	mov	w9, #0x4                // =4
    5c14:      	mov	x0, x24
    5c18:      	mov	w1, #0x4                // =4
    5c1c:      	add	x8, x8, #0x218
    5c20:      	ldr	x8, [sp, #0x30]
    5c24:      	add	x2, x8, #0x218
    5c28:      	blr	x9
    5c2c:      	ldr	x8, [sp, #0x38]
    5c30:      	add	x0, x22, #0x2c
    5c34:      	mov	w9, #0x4                // =4
    5c38:      	mov	w1, #0x4                // =4
    5c3c:      	add	x8, x8, #0x4d8
    5c40:      	ldr	x8, [sp, #0x38]
    5c44:      	add	x2, x8, #0x4d8
    5c48:      	blr	x9
    5c4c:      	ldr	x8, [sp, #0x40]
    5c50:      	add	x0, x22, #0x30
    5c54:      	mov	w9, #0x4                // =4
    5c58:      	mov	w1, #0x4                // =4
    5c5c:      	add	x8, x8, #0x58
    5c60:      	ldr	x8, [sp, #0x40]
    5c64:      	add	x2, x8, #0x58
    5c68:      	blr	x9
    5c6c:      	str	xzr, [sp, #0x20]
    5c70:      	add	x2, x23, #0x938
    5c74:      	add	x8, sp, #0x20
    5c78:      	add	x0, sp, #0x20
    5c7c:      	mov	w1, #0x8                // =8
    5c80:      	blr	x25
    5c84:      	ldr	x8, [sp, #0x20]
    5c88:      	cbz	x8, 0x5d0c <generic_fentry_output+0x1cc>
    5c8c:      	str	wzr, [sp, #0x1c]
    5c90:      	add	x8, x8, #0x4
    5c94:      	add	x9, sp, #0x1c
    5c98:      	mov	w10, #0x4               // =4
    5c9c:      	add	x0, sp, #0x1c
    5ca0:      	mov	w1, #0x4                // =4
    5ca4:      	mov	w24, #0x4               // =4
    5ca8:      	ldr	x8, [sp, #0x20]
    5cac:      	add	x2, x8, #0x4
    5cb0:      	blr	x10
    5cb4:      	ldr	x8, [sp, #0x20]
    5cb8:      	ldrsw	x9, [sp, #0x1c]
    5cbc:      	add	x10, sp, #0x8
    5cc0:      	mov	w11, #0x4               // =4
    5cc4:      	add	x0, sp, #0x8
    5cc8:      	mov	w1, #0x10               // =16
    5ccc:      	add	x8, x8, x9, lsl #4
    5cd0:      	mov	w9, #0x10               // =16
    5cd4:      	add	x8, x8, #0x80
    5cd8:      	ldr	x8, [sp, #0x20]
    5cdc:      	ldrsw	x9, [sp, #0x1c]
    5ce0:      	add	x8, x8, x9, lsl #4
    5ce4:      	add	x2, x8, #0x80
    5ce8:      	blr	x11
    5cec:      	ldr	x8, [sp, #0x10]
    5cf0:      	add	x0, x22, #0x34
    5cf4:      	mov	w1, #0x4                // =4
    5cf8:      	add	x8, x8, #0x158
    5cfc:      	ldr	x8, [sp, #0x10]
    5d00:      	add	x2, x8, #0x158
    5d04:      	blr	x24
    5d08:      	b	0x5d10 <generic_fentry_output+0x1d0>
    5d0c:      	str	wzr, [x22, #0x34]
    5d10:      	ldr	x8, [sp, #0x48]
    5d14:      	add	x0, x22, #0x38
    5d18:      	mov	w9, #0x4                // =4
    5d1c:      	mov	w1, #0x4                // =4
    5d20:      	mov	w24, #0x4               // =4
    5d24:      	add	x8, x8, #0x158
    5d28:      	ldr	x8, [sp, #0x48]
    5d2c:      	add	x2, x8, #0x158
    5d30:      	blr	x9
    5d34:      	ldr	x8, [sp, #0x50]
    5d38:      	add	x0, x22, #0x3c
    5d3c:      	mov	w9, #0x4                // =4
    5d40:      	mov	w1, #0x4                // =4
    5d44:      	add	x8, x8, #0x118
    5d48:      	ldr	x8, [sp, #0x50]
    5d4c:      	add	x2, x8, #0x118
    5d50:      	blr	x9
    5d54:      	ldr	x8, [sp, #0x58]
    5d58:      	add	x0, x22, #0x40
    5d5c:      	mov	w9, #0x4                // =4
    5d60:      	mov	w1, #0x4                // =4
    5d64:      	add	x8, x8, #0x98
    5d68:      	ldr	x8, [sp, #0x58]
    5d6c:      	add	x2, x8, #0x98
    5d70:      	blr	x9
    5d74:      	ldr	x8, [sp, #0x60]
    5d78:      	add	x0, x22, #0x44
    5d7c:      	mov	w9, #0x4                // =4
    5d80:      	mov	w1, #0x4                // =4
    5d84:      	add	x8, x8, #0x98
    5d88:      	ldr	x8, [sp, #0x60]
    5d8c:      	add	x2, x8, #0x98
    5d90:      	blr	x9
    5d94:      	ldr	x8, [sp, #0x68]
    5d98:      	add	x0, x22, #0x48
    5d9c:      	mov	w9, #0x4                // =4
    5da0:      	mov	w1, #0x4                // =4
    5da4:      	add	x8, x8, #0x58
    5da8:      	ldr	x8, [sp, #0x68]
    5dac:      	add	x2, x8, #0x58
    5db0:      	blr	x9
    5db4:      	str	xzr, [sp, #0x8]
    5db8:      	str	xzr, [sp, #0x20]
    5dbc:      	add	x2, x23, #0xae0
    5dc0:      	mov	w23, #0x8               // =8
    5dc4:      	add	x8, sp, #0x8
    5dc8:      	mov	w9, #0x4                // =4
    5dcc:      	add	x0, sp, #0x8
    5dd0:      	mov	w1, #0x8                // =8
    5dd4:      	blr	x9
    5dd8:      	ldr	x8, [sp, #0x8]
    5ddc:      	add	x9, sp, #0x20
    5de0:      	mov	w10, #0x4               // =4
    5de4:      	add	x0, sp, #0x20
    5de8:      	mov	w1, #0x8                // =8
    5dec:      	add	x8, x8, #0x90
    5df0:      	ldr	x8, [sp, #0x8]
    5df4:      	add	x2, x8, #0x90
    5df8:      	blr	x10
    5dfc:      	ldr	x8, [sp, #0x20]
    5e00:      	add	x0, x22, #0x4c
    5e04:      	mov	w1, #0x4                // =4
    5e08:      	add	x8, x8, #0x158
    5e0c:      	ldr	x8, [sp, #0x20]
    5e10:      	add	x2, x8, #0x158
    5e14:      	blr	x24
    5e18:      	ldr	x8, [x19, #0x5ef0]
    5e1c:      	cbz	x8, 0x5eb8 <generic_fentry_output+0x378>
    5e20:      	mov	w8, #0xe                // =14
    5e24:      	blr	x8
    5e28:      	mov	w8, #0x23               // =35
    5e2c:      	lsr	x23, x0, #32
    5e30:      	blr	x8
    5e34:      	str	w23, [sp, #0x28]
    5e38:      	mov	w8, #0x1                // =1
    5e3c:      	add	x9, sp, #0x28
    5e40:      	mov	x22, x0
    5e44:      	add	x1, sp, #0x28
    5e48:      	mov	x0, x21
    5e4c:      	blr	x8
    5e50:      	cbz	x0, 0x5eb8 <generic_fentry_output+0x378>
    5e54:      	add	x2, x22, #0xae0
    5e58:      	mov	w22, #0x8               // =8
    5e5c:      	add	x8, sp, #0x28
    5e60:      	mov	w9, #0x4                // =4
    5e64:      	add	x21, x0, #0x50
    5e68:      	mov	x24, x0
    5e6c:      	add	x0, sp, #0x28
    5e70:      	mov	w1, #0x8                // =8
    5e74:      	mov	w23, #0x4               // =4
    5e78:      	blr	x9
    5e7c:      	ldr	x25, [sp, #0x28]
    5e80:      	add	x0, x24, #0x58
    5e84:      	mov	w8, #0x4                // =4
    5e88:      	mov	w1, #0x8                // =8
    5e8c:      	add	x2, x25, #0x40
    5e90:      	blr	x8
    5e94:      	add	x0, x24, #0x60
    5e98:      	add	x2, x25, #0x30
    5e9c:      	mov	w8, #0x4                // =4
    5ea0:      	mov	w1, #0x8                // =8
    5ea4:      	blr	x8
    5ea8:      	add	x2, x25, #0x38
    5eac:      	mov	x0, x21
    5eb0:      	mov	w1, #0x8                // =8
    5eb4:      	blr	x23
    5eb8:      	ldr	w8, [x19, #0x4]
    5ebc:      	mov	w9, #0x2328             // =9000
    5ec0:      	str	wzr, [sp, #0x8]
    5ec4:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x1e50>
    5ec8:      	add	x1, sp, #0x8
    5ecc:      	add	w8, w8, #0x90
    5ed0:      	ldr	x0, [x0]
    5ed4:      	and	w8, w8, #0x7fff
    5ed8:      	cmp	w8, w9
    5edc:      	csel	w21, w8, w9, lo
    5ee0:      	mov	w8, #0x1                // =1
    5ee4:      	add	x9, sp, #0x8
    5ee8:      	blr	x8
    5eec:      	cbz	x0, 0x5f58 <generic_fentry_output+0x418>
    5ef0:      	ldrb	w8, [x0, #0x28]
    5ef4:      	cbz	w8, 0x5f58 <generic_fentry_output+0x418>
    5ef8:      	adrp	x1, 0x5000 <generic_fentry_process_filter+0x1e50>
    5efc:      	mov	w8, #-0x1               // =-1
    5f00:      	mov	w9, #0x19               // =25
    5f04:      	ldr	x1, [x1]
    5f08:      	mov	x0, x20
    5f0c:      	mov	w2, #-0x1               // =-1
    5f10:      	mov	x3, x19
    5f14:      	mov	x4, x21
    5f18:      	blr	x9
    5f1c:      	tbnz	x0, #0x3f, 0x6004 <generic_fentry_output+0x4c4>
    5f20:      	str	wzr, [sp, #0x28]
    5f24:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x1e50>
    5f28:      	mov	w8, #0x1                // =1
    5f2c:      	add	x9, sp, #0x28
    5f30:      	ldr	x0, [x0]
    5f34:      	add	x1, sp, #0x28
    5f38:      	blr	x8
    5f3c:      	cbz	x0, 0x6110 <generic_fentry_output+0x5d0>
    5f40:      	add	x8, x0, #0x8
    5f44:      	ldaxr	x9, [x8]
    5f48:      	add	x9, x9, #0x1
    5f4c:      	stlxr	w10, x9, [x8]
    5f50:      	cbnz	w10, 0x5f44 <generic_fentry_output+0x404>
    5f54:      	b	0x6110 <generic_fentry_output+0x5d0>
    5f58:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x1e50>
    5f5c:      	mov	x3, xzr
    5f60:      	mov	w8, #0x82               // =130
    5f64:      	ldr	x0, [x0]
    5f68:      	mov	x1, x19
    5f6c:      	mov	x2, x21
    5f70:      	blr	x8
    5f74:      	tbnz	x0, #0x3f, 0x5fb4 <generic_fentry_output+0x474>
    5f78:      	str	wzr, [sp, #0x28]
    5f7c:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x1e50>
    5f80:      	mov	w8, #0x1                // =1
    5f84:      	add	x9, sp, #0x28
    5f88:      	ldr	x0, [x0]
    5f8c:      	add	x1, sp, #0x28
    5f90:      	blr	x8
    5f94:      	cbz	x0, 0x6110 <generic_fentry_output+0x5d0>
    5f98:      	add	x8, x0, #0x8
    5f9c:      	nop
    5fa0:      	ldaxr	x9, [x8]
    5fa4:      	add	x9, x9, #0x1
    5fa8:      	stlxr	w10, x9, [x8]
    5fac:      	cbnz	w10, 0x5fa0 <generic_fentry_output+0x460>
    5fb0:      	b	0x6110 <generic_fentry_output+0x5d0>
    5fb4:      	mov	x19, x0
    5fb8:      	str	wzr, [sp, #0x28]
    5fbc:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x1e50>
    5fc0:      	mov	w8, #0x1                // =1
    5fc4:      	ldr	x0, [x0]
    5fc8:      	add	x9, sp, #0x28
    5fcc:      	add	x1, sp, #0x28
    5fd0:      	blr	x8
    5fd4:      	cbz	x0, 0x6110 <generic_fentry_output+0x5d0>
    5fd8:      	mov	x8, x19
    5fdc:      	cmn	x19, #0xc
    5fe0:      	b.gt	0x6054 <generic_fentry_output+0x514>
    5fe4:      	cmn	x8, #0x1c
    5fe8:      	b.eq	0x6094 <generic_fentry_output+0x554>
    5fec:      	cmn	x8, #0x16
    5ff0:      	b.eq	0x60ac <generic_fentry_output+0x56c>
    5ff4:      	cmn	x8, #0x10
    5ff8:      	b.ne	0x60a4 <generic_fentry_output+0x564>
    5ffc:      	add	x8, x0, #0x2f0
    6000:      	b	0x60c0 <generic_fentry_output+0x580>
    6004:      	mov	x19, x0
    6008:      	str	wzr, [sp, #0x28]
    600c:      	adrp	x0, 0x6000 <generic_fentry_output+0x4c0>
    6010:      	mov	w8, #0x1                // =1
    6014:      	ldr	x0, [x0]
    6018:      	add	x9, sp, #0x28
    601c:      	add	x1, sp, #0x28
    6020:      	blr	x8
    6024:      	cbz	x0, 0x6110 <generic_fentry_output+0x5d0>
    6028:      	mov	x8, x19
    602c:      	cmn	x19, #0xc
    6030:      	b.gt	0x6074 <generic_fentry_output+0x534>
    6034:      	cmn	x8, #0x1c
    6038:      	b.eq	0x60d4 <generic_fentry_output+0x594>
    603c:      	cmn	x8, #0x16
    6040:      	b.eq	0x60ec <generic_fentry_output+0x5ac>
    6044:      	cmn	x8, #0x10
    6048:      	b.ne	0x60e4 <generic_fentry_output+0x5a4>
    604c:      	add	x8, x0, #0x2f0
    6050:      	b	0x6100 <generic_fentry_output+0x5c0>
    6054:      	cmn	x8, #0xb
    6058:      	b.eq	0x609c <generic_fentry_output+0x55c>
    605c:      	cmn	x8, #0x7
    6060:      	b.eq	0x60b4 <generic_fentry_output+0x574>
    6064:      	cmn	x8, #0x2
    6068:      	b.ne	0x60a4 <generic_fentry_output+0x564>
    606c:      	add	x8, x0, #0x2e0
    6070:      	b	0x60c0 <generic_fentry_output+0x580>
    6074:      	cmn	x8, #0xb
    6078:      	b.eq	0x60dc <generic_fentry_output+0x59c>
    607c:      	cmn	x8, #0x7
    6080:      	b.eq	0x60f4 <generic_fentry_output+0x5b4>
    6084:      	cmn	x8, #0x2
    6088:      	b.ne	0x60e4 <generic_fentry_output+0x5a4>
    608c:      	add	x8, x0, #0x2e0
    6090:      	b	0x6100 <generic_fentry_output+0x5c0>
    6094:      	add	x8, x0, #0x300
    6098:      	b	0x60c0 <generic_fentry_output+0x580>
    609c:      	add	x8, x0, #0x308
    60a0:      	b	0x60c0 <generic_fentry_output+0x580>
    60a4:      	add	x8, x0, #0x2d8
    60a8:      	b	0x60c0 <generic_fentry_output+0x580>
    60ac:      	add	x8, x0, #0x2f8
    60b0:      	b	0x60c0 <generic_fentry_output+0x580>
    60b4:      	add	x8, x0, #0x2e8
    60b8:      	nop
    60bc:      	nop
    60c0:      	ldaxr	x9, [x8]
    60c4:      	add	x9, x9, #0x1
    60c8:      	stlxr	w10, x9, [x8]
    60cc:      	cbnz	w10, 0x60c0 <generic_fentry_output+0x580>
    60d0:      	b	0x6110 <generic_fentry_output+0x5d0>
    60d4:      	add	x8, x0, #0x300
    60d8:      	b	0x6100 <generic_fentry_output+0x5c0>
    60dc:      	add	x8, x0, #0x308
    60e0:      	b	0x6100 <generic_fentry_output+0x5c0>
    60e4:      	add	x8, x0, #0x2d8
    60e8:      	b	0x6100 <generic_fentry_output+0x5c0>
    60ec:      	add	x8, x0, #0x2f8
    60f0:      	b	0x6100 <generic_fentry_output+0x5c0>
    60f4:      	add	x8, x0, #0x2e8
    60f8:      	nop
    60fc:      	nop
    6100:      	ldaxr	x9, [x8]
    6104:      	add	x9, x9, #0x1
    6108:      	stlxr	w10, x9, [x8]
    610c:      	cbnz	w10, 0x6100 <generic_fentry_output+0x5c0>
    6110:      	ldp	x20, x19, [sp, #0xb0]
    6114:      	mov	w0, wzr
    6118:      	ldr	x29, [sp, #0x70]
    611c:      	ldp	x22, x21, [sp, #0xa0]
    6120:      	ldp	x24, x23, [sp, #0x90]
    6124:      	ldp	x30, x25, [sp, #0x80]
    6128:      	add	sp, sp, #0xc0
    612c:      	ret

Disassembly of section fentry/generic_fentry:

0000000000000000 <generic_fentry_event>:
       0:      	sub	sp, sp, #0xd0
       4:      	stp	x30, x25, [sp, #0x90]
       8:      	stp	x24, x23, [sp, #0xa0]
       c:      	stp	x22, x21, [sp, #0xb0]
      10:      	stp	x20, x19, [sp, #0xc0]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0xc]
      1c:      	adrp	x0, 0x0 <generic_fentry_event>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0xc
      2c:      	add	x1, sp, #0xc
      30:      	blr	x8
      34:      	cbz	x0, 0x538 <generic_fentry_event+0x538>
      38:      	add	x23, x0, #0x5, lsl #12  // =0x5000
      3c:      	mov	x20, x0
      40:      	adrp	x0, 0x0 <generic_fentry_event>
      44:      	str	wzr, [x23, #0xef8]
      48:      	add	x1, x23, #0xef8
      4c:      	mov	w8, #0x1                // =1
      50:      	ldr	x0, [x0]
      54:      	blr	x8
      58:      	cbz	x0, 0x538 <generic_fentry_event+0x538>
      5c:      	ldr	w8, [x0, #0x64]
      60:      	str	w8, [sp, #0x1c]
      64:      	cbz	w8, 0x220 <generic_fentry_event+0x220>
      68:      	adrp	x21, 0x0 <generic_fentry_event>
      6c:      	mov	w8, #0x1                // =1
      70:      	add	x9, sp, #0x1c
      74:      	ldr	x21, [x21]
      78:      	mov	x24, x0
      7c:      	add	x1, sp, #0x1c
      80:      	mov	x0, x21
      84:      	blr	x8
      88:      	cbz	x0, 0x538 <generic_fentry_event+0x538>
      8c:      	mov	x22, x0
      90:      	str	wzr, [sp, #0x84]
      94:      	adrp	x0, 0x0 <generic_fentry_event>
      98:      	mov	w8, #0x1                // =1
      9c:      	ldr	x0, [x0]
      a0:      	add	x9, sp, #0x84
      a4:      	add	x1, sp, #0x84
      a8:      	blr	x8
      ac:      	cbz	x0, 0xd8 <generic_fentry_event+0xd8>
      b0:      	ldr	x8, [x0, #0x20]
      b4:      	mov	w9, #0x7270             // =29296
      b8:      	movk	w9, #0x6367, lsl #16
      bc:      	cmp	x8, x9
      c0:      	b.ne	0xe0 <generic_fentry_event+0xe0>
      c4:      	mov	w8, #0x50               // =80
      c8:      	blr	x8
      cc:      	str	x0, [sp, #0x30]
      d0:      	cbnz	x0, 0x1d4 <generic_fentry_event+0x1d4>
      d4:      	b	0x538 <generic_fentry_event+0x538>
      d8:      	mov	w25, wzr
      dc:      	b	0xe4 <generic_fentry_event+0xe4>
      e0:      	ldr	w25, [x0, #0x10]
      e4:      	mov	w8, #0x23               // =35
      e8:      	blr	x8
      ec:      	str	xzr, [sp, #0x88]
      f0:      	add	x2, x0, #0xcd0
      f4:      	mov	w8, #0x8                // =8
      f8:      	mov	w9, #0x71               // =113
      fc:      	add	x10, sp, #0x20
     100:      	add	x0, sp, #0x20
     104:      	mov	w1, #0x8                // =8
     108:      	blr	x9
     10c:      	ldr	x8, [sp, #0x20]
     110:      	cbz	x8, 0x538 <generic_fentry_event+0x538>
     114:      	cmp	w25, #0xb
     118:      	b.hi	0x538 <generic_fentry_event+0x538>
     11c:      	ubfiz	x9, x25, #3, #32
     120:      	mov	w10, #0x8               // =8
     124:      	mov	w11, #0x71              // =113
     128:      	add	x12, sp, #0x38
     12c:      	add	x0, sp, #0x38
     130:      	mov	w1, #0x8                // =8
     134:      	add	x8, x8, x9
     138:      	ldr	x8, [sp, #0x20]
     13c:      	add	x2, x8, x9
     140:      	blr	x11
     144:      	ldr	x8, [sp, #0x38]
     148:      	cbz	x8, 0x538 <generic_fentry_event+0x538>
     14c:      	mov	w9, #0x8                // =8
     150:      	mov	w10, #0x71              // =113
     154:      	add	x11, sp, #0x88
     158:      	ldr	x2, [sp, #0x38]
     15c:      	add	x0, sp, #0x88
     160:      	mov	w1, #0x8                // =8
     164:      	blr	x10
     168:      	ldr	x8, [sp, #0x88]
     16c:      	cbz	x8, 0x538 <generic_fentry_event+0x538>
     170:      	str	xzr, [sp, #0x38]
     174:      	add	x2, x8, #0x100
     178:      	mov	w8, #0x8                // =8
     17c:      	mov	w9, #0x71               // =113
     180:      	add	x10, sp, #0x38
     184:      	add	x0, sp, #0x38
     188:      	mov	w1, #0x8                // =8
     18c:      	blr	x9
     190:      	ldr	x8, [sp, #0x38]
     194:      	str	xzr, [sp, #0x38]
     198:      	cbz	x8, 0x1c8 <generic_fentry_event+0x1c8>
     19c:      	add	x2, x8, #0x60
     1a0:      	mov	w8, #0x8                // =8
     1a4:      	mov	w9, #0x71               // =113
     1a8:      	add	x10, sp, #0x38
     1ac:      	add	x0, sp, #0x38
     1b0:      	mov	w1, #0x8                // =8
     1b4:      	blr	x9
     1b8:      	ldr	x0, [sp, #0x38]
     1bc:      	str	x0, [sp, #0x30]
     1c0:      	cbnz	x0, 0x1d4 <generic_fentry_event+0x1d4>
     1c4:      	b	0x538 <generic_fentry_event+0x538>
     1c8:      	mov	x0, xzr
     1cc:      	str	xzr, [sp, #0x30]
     1d0:      	cbz	xzr, 0x538 <generic_fentry_event+0x538>
     1d4:      	str	x0, [sp, #0x38]
     1d8:      	adrp	x0, 0x0 <generic_fentry_event>
     1dc:      	mov	w8, #0x1                // =1
     1e0:      	add	x9, sp, #0x38
     1e4:      	ldr	x0, [x0]
     1e8:      	add	x1, sp, #0x38
     1ec:      	blr	x8
     1f0:      	cbz	x0, 0x200 <generic_fentry_event+0x200>
     1f4:      	ldr	x8, [x0]
     1f8:      	cbz	x8, 0x200 <generic_fentry_event+0x200>
     1fc:      	str	x8, [sp, #0x30]
     200:      	mov	w8, #0x1                // =1
     204:      	add	x9, sp, #0x30
     208:      	add	x1, sp, #0x30
     20c:      	mov	x0, x22
     210:      	blr	x8
     214:      	mov	x8, x0
     218:      	mov	x0, x24
     21c:      	cbz	x8, 0x554 <generic_fentry_event+0x554>
     220:      	ldr	w8, [x0]
     224:      	add	x9, x23, #0xefc
     228:      	str	xzr, [x20, #0x5eb8]
     22c:      	str	xzr, [x20, #0x5ec0]
     230:      	str	xzr, [x20, #0x5ec8]
     234:      	str	xzr, [x9]
     238:      	str	xzr, [x20, #0x5ed0]
     23c:      	str	xzr, [x20, #0x5ed8]
     240:      	stp	x8, xzr, [x20, #0x60]
     244:      	mov	w8, #0x5eb8             // =24248
     248:      	add	x8, x20, x8
     24c:      	strb	wzr, [x8, #0x28]
     250:      	mov	w8, #0x23               // =35
     254:      	blr	x8
     258:      	add	x2, x0, #0xb50
     25c:      	mov	w25, #0x8               // =8
     260:      	add	x8, sp, #0x88
     264:      	mov	w9, #0x4                // =4
     268:      	mov	x21, x0
     26c:      	add	x0, sp, #0x88
     270:      	mov	w1, #0x8                // =8
     274:      	add	x22, x20, #0x20
     278:      	mov	w24, #0x4               // =4
     27c:      	blr	x9
     280:      	ldr	x8, [sp, #0x88]
     284:      	mov	w9, #0x48               // =72
     288:      	add	x10, sp, #0x38
     28c:      	mov	w11, #0x4               // =4
     290:      	ldr	x2, [sp, #0x88]
     294:      	add	x0, sp, #0x38
     298:      	mov	w1, #0x48               // =72
     29c:      	blr	x11
     2a0:      	ldr	x8, [sp, #0x40]
     2a4:      	mov	w9, #0x4                // =4
     2a8:      	mov	x0, x22
     2ac:      	mov	w1, #0x4                // =4
     2b0:      	add	x8, x8, #0x218
     2b4:      	ldr	x8, [sp, #0x40]
     2b8:      	add	x2, x8, #0x218
     2bc:      	blr	x9
     2c0:      	ldr	x8, [sp, #0x48]
     2c4:      	add	x0, x20, #0x24
     2c8:      	mov	w9, #0x4                // =4
     2cc:      	mov	w1, #0x4                // =4
     2d0:      	add	x8, x8, #0x4d8
     2d4:      	ldr	x8, [sp, #0x48]
     2d8:      	add	x2, x8, #0x4d8
     2dc:      	blr	x9
     2e0:      	ldr	x8, [sp, #0x50]
     2e4:      	add	x0, x20, #0x28
     2e8:      	mov	w9, #0x4                // =4
     2ec:      	mov	w1, #0x4                // =4
     2f0:      	add	x8, x8, #0x58
     2f4:      	ldr	x8, [sp, #0x50]
     2f8:      	add	x2, x8, #0x58
     2fc:      	blr	x9
     300:      	str	xzr, [sp, #0x30]
     304:      	add	x2, x21, #0x938
     308:      	add	x8, sp, #0x30
     30c:      	add	x0, sp, #0x30
     310:      	mov	w1, #0x8                // =8
     314:      	blr	x24
     318:      	ldr	x8, [sp, #0x30]
     31c:      	cbz	x8, 0x3a0 <generic_fentry_event+0x3a0>
     320:      	str	wzr, [sp, #0x10]
     324:      	add	x8, x8, #0x4
     328:      	add	x9, sp, #0x10
     32c:      	mov	w10, #0x4               // =4
     330:      	add	x0, sp, #0x10
     334:      	mov	w1, #0x4                // =4
     338:      	mov	w22, #0x4               // =4
     33c:      	ldr	x8, [sp, #0x30]
     340:      	add	x2, x8, #0x4
     344:      	blr	x10
     348:      	ldr	x8, [sp, #0x30]
     34c:      	ldrsw	x9, [sp, #0x10]
     350:      	add	x10, sp, #0x20
     354:      	mov	w11, #0x4               // =4
     358:      	add	x0, sp, #0x20
     35c:      	mov	w1, #0x10               // =16
     360:      	add	x8, x8, x9, lsl #4
     364:      	mov	w9, #0x10               // =16
     368:      	add	x8, x8, #0x80
     36c:      	ldr	x8, [sp, #0x30]
     370:      	ldrsw	x9, [sp, #0x10]
     374:      	add	x8, x8, x9, lsl #4
     378:      	add	x2, x8, #0x80
     37c:      	blr	x11
     380:      	ldr	x8, [sp, #0x28]
     384:      	add	x0, x20, #0x2c
     388:      	mov	w1, #0x4                // =4
     38c:      	add	x8, x8, #0x158
     390:      	ldr	x8, [sp, #0x28]
     394:      	add	x2, x8, #0x158
     398:      	blr	x22
     39c:      	b	0x3a4 <generic_fentry_event+0x3a4>
     3a0:      	str	wzr, [x20, #0x2c]
     3a4:      	ldr	x8, [sp, #0x58]
     3a8:      	add	x0, x20, #0x30
     3ac:      	mov	w9, #0x4                // =4
     3b0:      	mov	w1, #0x4                // =4
     3b4:      	mov	w24, #0x4               // =4
     3b8:      	add	x8, x8, #0x158
     3bc:      	ldr	x8, [sp, #0x58]
     3c0:      	add	x2, x8, #0x158
     3c4:      	blr	x9
     3c8:      	ldr	x8, [sp, #0x60]
     3cc:      	add	x0, x20, #0x34
     3d0:      	mov	w9, #0x4                // =4
     3d4:      	mov	w1, #0x4                // =4
     3d8:      	add	x8, x8, #0x118
     3dc:      	ldr	x8, [sp, #0x60]
     3e0:      	add	x2, x8, #0x118
     3e4:      	blr	x9
     3e8:      	ldr	x8, [sp, #0x68]
     3ec:      	add	x0, x20, #0x38
     3f0:      	mov	w9, #0x4                // =4
     3f4:      	mov	w1, #0x4                // =4
     3f8:      	add	x8, x8, #0x98
     3fc:      	ldr	x8, [sp, #0x68]
     400:      	add	x2, x8, #0x98
     404:      	blr	x9
     408:      	ldr	x8, [sp, #0x70]
     40c:      	add	x0, x20, #0x3c
     410:      	mov	w9, #0x4                // =4
     414:      	mov	w1, #0x4                // =4
     418:      	add	x8, x8, #0x98
     41c:      	ldr	x8, [sp, #0x70]
     420:      	add	x2, x8, #0x98
     424:      	blr	x9
     428:      	ldr	x8, [sp, #0x78]
     42c:      	add	x0, x20, #0x40
     430:      	mov	w9, #0x4                // =4
     434:      	mov	w1, #0x4                // =4
     438:      	add	x8, x8, #0x58
     43c:      	ldr	x8, [sp, #0x78]
     440:      	add	x2, x8, #0x58
     444:      	blr	x9
     448:      	str	xzr, [sp, #0x20]
     44c:      	str	xzr, [sp, #0x30]
     450:      	add	x21, x21, #0xae0
     454:      	mov	w25, #0x8               // =8
     458:      	add	x8, sp, #0x20
     45c:      	mov	w9, #0x4                // =4
     460:      	add	x0, sp, #0x20
     464:      	mov	w1, #0x8                // =8
     468:      	mov	x2, x21
     46c:      	blr	x9
     470:      	ldr	x8, [sp, #0x20]
     474:      	add	x9, sp, #0x30
     478:      	mov	w10, #0x4               // =4
     47c:      	add	x0, sp, #0x30
     480:      	mov	w1, #0x8                // =8
     484:      	add	x8, x8, #0x90
     488:      	ldr	x8, [sp, #0x20]
     48c:      	add	x2, x8, #0x90
     490:      	blr	x10
     494:      	ldr	x8, [sp, #0x30]
     498:      	add	x0, x20, #0x44
     49c:      	mov	w9, #0x4                // =4
     4a0:      	mov	w1, #0x4                // =4
     4a4:      	add	x8, x8, #0x158
     4a8:      	ldr	x8, [sp, #0x30]
     4ac:      	add	x2, x8, #0x158
     4b0:      	blr	x9
     4b4:      	add	x8, sp, #0x38
     4b8:      	mov	w9, #0x4                // =4
     4bc:      	add	x0, sp, #0x38
     4c0:      	mov	w1, #0x8                // =8
     4c4:      	mov	x2, x21
     4c8:      	add	x22, x20, #0x48
     4cc:      	blr	x9
     4d0:      	ldr	x21, [sp, #0x38]
     4d4:      	add	x0, x20, #0x50
     4d8:      	mov	w8, #0x4                // =4
     4dc:      	mov	w1, #0x8                // =8
     4e0:      	add	x2, x21, #0x40
     4e4:      	blr	x8
     4e8:      	add	x0, x20, #0x58
     4ec:      	add	x2, x21, #0x30
     4f0:      	mov	w8, #0x4                // =4
     4f4:      	mov	w1, #0x8                // =8
     4f8:      	blr	x8
     4fc:      	add	x2, x21, #0x38
     500:      	mov	x0, x22
     504:      	mov	w1, #0x8                // =8
     508:      	blr	x24
     50c:      	strb	wzr, [x23, #0xf08]
     510:      	strb	wzr, [x20, #0x1]
     514:      	adrp	x1, 0x0 <generic_fentry_event>
     518:      	mov	w8, #0x2                // =2
     51c:      	mov	w9, #0xc                // =12
     520:      	mov	x0, x19
     524:      	str	xzr, [x20, #0x5ee8]
     528:      	str	xzr, [x20, #0x5ef0]
     52c:      	ldr	x1, [x1]
     530:      	mov	w2, #0x2                // =2
     534:      	blr	x9
     538:      	ldp	x20, x19, [sp, #0xc0]
     53c:      	mov	w0, wzr
     540:      	ldp	x22, x21, [sp, #0xb0]
     544:      	ldp	x24, x23, [sp, #0xa0]
     548:      	ldp	x30, x25, [sp, #0x90]
     54c:      	add	sp, sp, #0xd0
     550:      	ret
     554:      	mov	x8, #-0x1               // =-1
     558:      	mov	w9, #0x1                // =1
     55c:      	add	x1, sp, #0x10
     560:      	str	x8, [sp, #0x10]
     564:      	add	x8, sp, #0x10
     568:      	mov	x0, x22
     56c:      	mov	w25, #0x1               // =1
     570:      	blr	x9
     574:      	cbz	x0, 0x538 <generic_fentry_event+0x538>
     578:      	str	w25, [sp, #0x1c]
     57c:      	add	x8, sp, #0x1c
     580:      	add	x1, sp, #0x1c
     584:      	mov	x0, x21
     588:      	blr	x25
     58c:      	cbz	x0, 0x538 <generic_fentry_event+0x538>
     590:      	mov	w8, #0x1                // =1
     594:      	add	x9, sp, #0x30
     598:      	add	x1, sp, #0x30
     59c:      	blr	x8
     5a0:      	mov	x8, x0
     5a4:      	mov	x0, x24
     5a8:      	cbnz	x8, 0x538 <generic_fentry_event+0x538>
     5ac:      	b	0x220 <generic_fentry_event+0x220>
