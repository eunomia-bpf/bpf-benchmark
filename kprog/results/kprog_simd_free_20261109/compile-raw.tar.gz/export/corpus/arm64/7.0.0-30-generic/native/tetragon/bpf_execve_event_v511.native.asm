
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_execve_event_v511.native.o:	file format elf64-littleaarch64

Disassembly of section tracepoint:

0000000000000000 <execve_rate>:
       0:      	sub	sp, sp, #0x90
       4:      	str	x30, [sp, #0x50]
       8:      	stp	x24, x23, [sp, #0x60]
       c:      	stp	x22, x21, [sp, #0x70]
      10:      	stp	x20, x19, [sp, #0x80]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0xc]
      1c:      	adrp	x0, 0x0 <execve_rate>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0xc
      2c:      	add	x1, sp, #0xc
      30:      	blr	x8
      34:      	cbz	x0, 0x37c <execve_rate+0x37c>
      38:      	ldr	x23, [x0, #0x8]
      3c:      	ldr	x8, [x0, #0x10]!
      40:      	add	x9, sp, #0x3c
      44:      	add	x1, sp, #0x3c
      48:      	mov	x20, x0
      4c:      	str	wzr, [sp, #0x3c]
      50:      	adrp	x0, 0x0 <execve_rate>
      54:      	str	x8, [sp, #0x40]
      58:      	mov	w8, #0x1                // =1
      5c:      	ldr	x0, [x0]
      60:      	blr	x8
      64:      	cbz	x0, 0x360 <execve_rate+0x360>
      68:      	ldr	x22, [x0, #0x8]
      6c:      	cbz	x22, 0x360 <execve_rate+0x360>
      70:      	adrp	x21, 0x0 <execve_rate>
      74:      	mov	w8, #0x1                // =1
      78:      	add	x9, sp, #0x40
      7c:      	ldr	x21, [x21]
      80:      	mov	x24, x0
      84:      	add	x1, sp, #0x40
      88:      	mov	x0, x21
      8c:      	blr	x8
      90:      	cbz	x0, 0xbc <execve_rate+0xbc>
      94:      	ldr	x8, [x0, #0x10]
      98:      	sub	x9, x23, x8
      9c:      	cmp	x9, x22
      a0:      	b.ls	0xf8 <execve_rate+0xf8>
      a4:      	cmp	x9, x22, lsl #1
      a8:      	b.ls	0x100 <execve_rate+0x100>
      ac:      	udiv	x8, x23, x22
      b0:      	mov	x9, xzr
      b4:      	mul	x8, x8, x22
      b8:      	b	0x108 <execve_rate+0x108>
      bc:      	mov	w8, #0x1                // =1
      c0:      	str	xzr, [sp, #0x30]
      c4:      	mov	x3, xzr
      c8:      	add	x9, sp, #0x40
      cc:      	stp	x8, xzr, [sp, #0x10]
      d0:      	udiv	x8, x23, x22
      d4:      	add	x10, sp, #0x10
      d8:      	add	x1, sp, #0x40
      dc:      	add	x2, sp, #0x10
      e0:      	mov	x0, x21
      e4:      	mul	x8, x8, x22
      e8:      	stp	x8, xzr, [sp, #0x20]
      ec:      	mov	w8, #0x2                // =2
      f0:      	blr	x8
      f4:      	b	0x360 <execve_rate+0x360>
      f8:      	ldp	x10, x9, [x0]
      fc:      	b	0x110 <execve_rate+0x110>
     100:      	ldr	x9, [x0]
     104:      	add	x8, x8, x22
     108:      	mov	x10, xzr
     10c:      	stp	x9, x8, [x0, #0x8]
     110:      	sub	x11, x22, x23
     114:      	add	x10, x10, #0x1
     118:      	add	x8, x11, x8
     11c:      	str	x10, [x0]
     120:      	mul	x8, x8, x9
     124:      	ldr	x9, [x0, #0x20]
     128:      	udiv	x8, x8, x22
     12c:      	add	x8, x8, x10
     130:      	str	x8, [x0, #0x18]
     134:      	cbnz	x9, 0x37c <execve_rate+0x37c>
     138:      	ldr	x9, [x24]
     13c:      	cmp	x8, x9
     140:      	b.lo	0x360 <execve_rate+0x360>
     144:      	mov	x22, x0
     148:      	str	x23, [x0, #0x20]
     14c:      	str	wzr, [sp, #0x58]
     150:      	adrp	x0, 0x0 <execve_rate>
     154:      	mov	w8, #0x1                // =1
     158:      	add	x9, sp, #0x58
     15c:      	ldr	x0, [x0]
     160:      	add	x1, sp, #0x4c
     164:      	str	wzr, [sp, #0x4c]
     168:      	blr	x8
     16c:      	cbz	x0, 0x358 <execve_rate+0x358>
     170:      	mov	w8, #0xa0               // =160
     174:      	mov	x21, x0
     178:      	str	x23, [x0, #0x8]
     17c:      	mov	x1, x20
     180:      	str	w8, [x0, #0x4]
     184:      	mov	w8, #0x1b               // =27
     188:      	mov	w2, #0x90               // =144
     18c:      	strh	w8, [x0], #0x10
     190:      	bl	0x190 <execve_rate+0x190>
     194:      	str	wzr, [sp, #0x5c]
     198:      	adrp	x0, 0x0 <execve_rate>
     19c:      	mov	w8, #0x1                // =1
     1a0:      	add	x9, sp, #0x5c
     1a4:      	ldr	x0, [x0]
     1a8:      	add	x1, sp, #0x5c
     1ac:      	blr	x8
     1b0:      	cbz	x0, 0x238 <execve_rate+0x238>
     1b4:      	ldrb	w8, [x0, #0x28]
     1b8:      	cbz	w8, 0x238 <execve_rate+0x238>
     1bc:      	adrp	x1, 0x0 <execve_rate>
     1c0:      	mov	w8, #-0x1               // =-1
     1c4:      	mov	w9, #0xa0               // =160
     1c8:      	ldr	x1, [x1]
     1cc:      	mov	w10, #0x19              // =25
     1d0:      	mov	x0, x19
     1d4:      	mov	w2, #-0x1               // =-1
     1d8:      	mov	x3, x21
     1dc:      	mov	w4, #0xa0               // =160
     1e0:      	blr	x10
     1e4:      	tbz	x0, #0x3f, 0x358 <execve_rate+0x358>
     1e8:      	mov	x20, x0
     1ec:      	str	wzr, [sp, #0x10]
     1f0:      	adrp	x0, 0x0 <execve_rate>
     1f4:      	mov	w8, #0x1                // =1
     1f8:      	ldr	x0, [x0]
     1fc:      	add	x9, sp, #0x10
     200:      	add	x1, sp, #0x10
     204:      	blr	x8
     208:      	cbz	x0, 0x358 <execve_rate+0x358>
     20c:      	mov	x8, x20
     210:      	cmn	x20, #0xc
     214:      	b.gt	0x2cc <execve_rate+0x2cc>
     218:      	cmn	x8, #0x1c
     21c:      	b.eq	0x324 <execve_rate+0x324>
     220:      	cmn	x8, #0x16
     224:      	b.eq	0x33c <execve_rate+0x33c>
     228:      	cmn	x8, #0x10
     22c:      	b.ne	0x334 <execve_rate+0x334>
     230:      	add	x8, x0, #0x600
     234:      	b	0x348 <execve_rate+0x348>
     238:      	adrp	x0, 0x0 <execve_rate>
     23c:      	mov	x3, xzr
     240:      	mov	w8, #0xa0               // =160
     244:      	ldr	x0, [x0]
     248:      	mov	w9, #0x82               // =130
     24c:      	mov	x1, x21
     250:      	mov	w2, #0xa0               // =160
     254:      	blr	x9
     258:      	tbz	x0, #0x3f, 0x358 <execve_rate+0x358>
     25c:      	mov	x20, x0
     260:      	str	wzr, [sp, #0x10]
     264:      	adrp	x0, 0x0 <execve_rate>
     268:      	mov	w8, #0x1                // =1
     26c:      	ldr	x0, [x0]
     270:      	add	x9, sp, #0x10
     274:      	add	x1, sp, #0x10
     278:      	blr	x8
     27c:      	cbz	x0, 0x358 <execve_rate+0x358>
     280:      	mov	x8, x20
     284:      	cmn	x20, #0xc
     288:      	b.gt	0x2ac <execve_rate+0x2ac>
     28c:      	cmn	x8, #0x1c
     290:      	b.eq	0x2ec <execve_rate+0x2ec>
     294:      	cmn	x8, #0x16
     298:      	b.eq	0x304 <execve_rate+0x304>
     29c:      	cmn	x8, #0x10
     2a0:      	b.ne	0x2fc <execve_rate+0x2fc>
     2a4:      	add	x8, x0, #0x600
     2a8:      	b	0x310 <execve_rate+0x310>
     2ac:      	cmn	x8, #0xb
     2b0:      	b.eq	0x2f4 <execve_rate+0x2f4>
     2b4:      	cmn	x8, #0x7
     2b8:      	b.eq	0x30c <execve_rate+0x30c>
     2bc:      	cmn	x8, #0x2
     2c0:      	b.ne	0x2fc <execve_rate+0x2fc>
     2c4:      	add	x8, x0, #0x5f0
     2c8:      	b	0x310 <execve_rate+0x310>
     2cc:      	cmn	x8, #0xb
     2d0:      	b.eq	0x32c <execve_rate+0x32c>
     2d4:      	cmn	x8, #0x7
     2d8:      	b.eq	0x344 <execve_rate+0x344>
     2dc:      	cmn	x8, #0x2
     2e0:      	b.ne	0x334 <execve_rate+0x334>
     2e4:      	add	x8, x0, #0x5f0
     2e8:      	b	0x348 <execve_rate+0x348>
     2ec:      	add	x8, x0, #0x610
     2f0:      	b	0x310 <execve_rate+0x310>
     2f4:      	add	x8, x0, #0x618
     2f8:      	b	0x310 <execve_rate+0x310>
     2fc:      	add	x8, x0, #0x5e8
     300:      	b	0x310 <execve_rate+0x310>
     304:      	add	x8, x0, #0x608
     308:      	b	0x310 <execve_rate+0x310>
     30c:      	add	x8, x0, #0x5f8
     310:      	ldaxr	x9, [x8]
     314:      	add	x9, x9, #0x1
     318:      	stlxr	w10, x9, [x8]
     31c:      	cbnz	w10, 0x310 <execve_rate+0x310>
     320:      	b	0x358 <execve_rate+0x358>
     324:      	add	x8, x0, #0x610
     328:      	b	0x348 <execve_rate+0x348>
     32c:      	add	x8, x0, #0x618
     330:      	b	0x348 <execve_rate+0x348>
     334:      	add	x8, x0, #0x5e8
     338:      	b	0x348 <execve_rate+0x348>
     33c:      	add	x8, x0, #0x608
     340:      	b	0x348 <execve_rate+0x348>
     344:      	add	x8, x0, #0x5f8
     348:      	ldaxr	x9, [x8]
     34c:      	add	x9, x9, #0x1
     350:      	stlxr	w10, x9, [x8]
     354:      	cbnz	w10, 0x348 <execve_rate+0x348>
     358:      	ldr	x8, [x22, #0x20]
     35c:      	cbnz	x8, 0x37c <execve_rate+0x37c>
     360:      	adrp	x1, 0x0 <execve_rate>
     364:      	mov	w8, #0x1                // =1
     368:      	mov	w9, #0xc                // =12
     36c:      	ldr	x1, [x1]
     370:      	mov	x0, x19
     374:      	mov	w2, #0x1                // =1
     378:      	blr	x9
     37c:      	ldp	x20, x19, [sp, #0x80]
     380:      	mov	w0, wzr
     384:      	ldr	x30, [sp, #0x50]
     388:      	ldp	x22, x21, [sp, #0x70]
     38c:      	ldp	x24, x23, [sp, #0x60]
     390:      	add	sp, sp, #0x90
     394:      	ret
     398:      	nop
     39c:      	nop

00000000000003a0 <execve_send>:
     3a0:      	sub	sp, sp, #0xf0
     3a4:      	str	x29, [sp, #0xa0]
     3a8:      	stp	x30, x25, [sp, #0xb0]
     3ac:      	stp	x24, x23, [sp, #0xc0]
     3b0:      	stp	x22, x21, [sp, #0xd0]
     3b4:      	stp	x20, x19, [sp, #0xe0]
     3b8:      	mov	x21, x0
     3bc:      	str	wzr, [sp, #0x28]
     3c0:      	adrp	x0, 0x0 <execve_rate>
     3c4:      	mov	w8, #0x1                // =1
     3c8:      	ldr	x0, [x0]
     3cc:      	add	x9, sp, #0x28
     3d0:      	add	x1, sp, #0x28
     3d4:      	blr	x8
     3d8:      	cbz	x0, 0x1450 <execve_send+0x10b0>
     3dc:      	mov	w8, #0x23               // =35
     3e0:      	mov	x29, x0
     3e4:      	blr	x8
     3e8:      	mov	w8, #0x16c0             // =5824
     3ec:      	add	x2, x0, #0x858
     3f0:      	mov	w19, #0x8               // =8
     3f4:      	mov	w9, #0x4                // =4
     3f8:      	add	x0, sp, #0x90
     3fc:      	mov	w1, #0x8                // =8
     400:      	mov	w20, #0x4               // =4
     404:      	add	x25, x29, x8
     408:      	add	x8, sp, #0x90
     40c:      	blr	x9
     410:      	ldr	x8, [sp, #0x90]
     414:      	add	x9, sp, #0x40
     418:      	add	x0, sp, #0x40
     41c:      	mov	w1, #0x8                // =8
     420:      	add	x8, x8, #0x528
     424:      	ldr	x8, [sp, #0x90]
     428:      	add	x2, x8, #0x528
     42c:      	blr	x20
     430:      	str	wzr, [sp, #0x2c]
     434:      	adrp	x0, 0x0 <execve_rate>
     438:      	ldr	x20, [sp, #0x40]
     43c:      	mov	w8, #0x1                // =1
     440:      	add	x9, sp, #0x2c
     444:      	add	x1, sp, #0x2c
     448:      	ldr	x0, [x0]
     44c:      	blr	x8
     450:      	str	x21, [sp, #0x18]
     454:      	cbz	x0, 0xa90 <execve_send+0x6f0>
     458:      	mov	w8, #0x1000             // =4096
     45c:      	str	x25, [sp, #0x10]
     460:      	str	x29, [sp, #0x20]
     464:      	mov	x22, x0
     468:      	add	x19, x0, #0x1, lsl #12  // =0x1000
     46c:      	str	w8, [x29, #0x1840]
     470:      	mov	w8, #0x23               // =35
     474:      	blr	x8
     478:      	add	x2, x0, #0xb30
     47c:      	mov	w25, #0x8               // =8
     480:      	add	x8, sp, #0x30
     484:      	mov	w9, #0x4                // =4
     488:      	add	x0, sp, #0x30
     48c:      	mov	w1, #0x8                // =8
     490:      	mov	w29, #0x4               // =4
     494:      	blr	x9
     498:      	ldr	x21, [sp, #0x30]
     49c:      	add	x23, x20, #0x48
     4a0:      	add	x8, sp, #0x38
     4a4:      	mov	w9, #0x4                // =4
     4a8:      	add	x0, sp, #0x38
     4ac:      	mov	w1, #0x8                // =8
     4b0:      	mov	x2, x23
     4b4:      	blr	x9
     4b8:      	ldr	x24, [sp, #0x38]
     4bc:      	add	x8, sp, #0x40
     4c0:      	add	x0, sp, #0x40
     4c4:      	mov	w1, #0x8                // =8
     4c8:      	add	x2, x24, #0x10
     4cc:      	blr	x29
     4d0:      	ldr	x8, [sp, #0x40]
     4d4:      	cbz	x8, 0x708 <execve_send+0x368>
     4d8:      	ldr	x8, [sp, #0x20]
     4dc:      	stp	xzr, xzr, [sp, #0x40]
     4e0:      	add	x25, x21, #0x18
     4e4:      	add	x9, sp, #0x40
     4e8:      	add	x2, x21, #0x20
     4ec:      	mov	w21, #0x8               // =8
     4f0:      	stp	x22, xzr, [sp, #0x50]
     4f4:      	add	x0, sp, #0x40
     4f8:      	mov	w1, #0x8                // =8
     4fc:      	add	x24, x20, #0x40
     500:      	add	x29, x9, #0x8
     504:      	ldr	w8, [x8, #0x1840]
     508:      	stp	xzr, xzr, [sp, #0x60]
     50c:      	str	x19, [sp, #0x8]
     510:      	str	x19, [sp, #0x70]
     514:      	add	x22, x9, #0x18
     518:      	add	x20, x9, #0x20
     51c:      	mov	w19, #0x4               // =4
     520:      	strb	wzr, [sp, #0x7c]
     524:      	str	w8, [sp, #0x78]
     528:      	mov	w8, #0x4                // =4
     52c:      	blr	x8
     530:      	mov	w8, #0x4                // =4
     534:      	mov	x0, x29
     538:      	mov	w1, #0x8                // =8
     53c:      	mov	x2, x25
     540:      	blr	x8
     544:      	mov	w8, #0x4                // =4
     548:      	mov	x0, x22
     54c:      	mov	w1, #0x8                // =8
     550:      	mov	x2, x23
     554:      	blr	x8
     558:      	mov	x0, x20
     55c:      	mov	w1, #0x8                // =8
     560:      	mov	x2, x24
     564:      	blr	x19
     568:      	ldr	x8, [sp, #0x60]
     56c:      	sub	x8, x8, #0x20
     570:      	str	x8, [sp, #0x68]
     574:      	adrp	x8, 0x0 <execve_rate>
     578:      	ldr	x8, [x8]
     57c:      	ldrb	w8, [x8]
     580:      	cbz	w8, 0x75c <execve_send+0x3bc>
     584:      	mov	w20, #0x80              // =128
     588:      	mov	w24, #0x8               // =8
     58c:      	add	x25, sp, #0x80
     590:      	add	x29, sp, #0xa8
     594:      	b	0x5a8 <execve_send+0x208>
     598:      	nop
     59c:      	nop
     5a0:      	subs	w20, w20, #0x1
     5a4:      	b.eq	0x8f8 <execve_send+0x558>
     5a8:      	ldp	x19, x2, [sp, #0x58]
     5ac:      	ldp	x8, x9, [sp, #0x40]
     5b0:      	cmp	x19, x8
     5b4:      	ccmp	x2, x9, #0x0, eq
     5b8:      	b.eq	0x8f0 <execve_send+0x550>
     5bc:      	ldr	x21, [sp, #0x68]
     5c0:      	mov	w8, #0x4                // =4
     5c4:      	add	x0, sp, #0x80
     5c8:      	mov	w1, #0x8                // =8
     5cc:      	blr	x8
     5d0:      	ldr	x8, [sp, #0x80]
     5d4:      	cmp	x19, x8
     5d8:      	b.eq	0x6c0 <execve_send+0x320>
     5dc:      	add	x23, x19, #0x18
     5e0:      	mov	w8, #0x4                // =4
     5e4:      	add	x0, sp, #0xa8
     5e8:      	mov	w1, #0x8                // =8
     5ec:      	mov	x2, x23
     5f0:      	blr	x8
     5f4:      	ldr	x8, [sp, #0xa8]
     5f8:      	cmp	x8, x19
     5fc:      	b.eq	0x6c0 <execve_send+0x320>
     600:      	mov	w8, #0x4                // =4
     604:      	add	x9, sp, #0x88
     608:      	add	x0, sp, #0x88
     60c:      	mov	w1, #0x8                // =8
     610:      	mov	x2, x23
     614:      	blr	x8
     618:      	add	x2, x19, #0x20
     61c:      	mov	w8, #0x4                // =4
     620:      	mov	w9, #0x10               // =16
     624:      	add	x10, sp, #0x90
     628:      	add	x0, sp, #0x90
     62c:      	mov	w1, #0x10               // =16
     630:      	blr	x8
     634:      	ldr	w19, [sp, #0x94]
     638:      	ldr	x8, [sp, #0x50]
     63c:      	ldr	x10, [sp, #0x70]
     640:      	sub	x12, x10, x8
     644:      	ldr	w21, [sp, #0x78]
     648:      	subs	w10, w19, w21
     64c:      	ldr	x9, [sp, #0x98]
     650:      	csel	w10, wzr, w10, lo
     654:      	cmp	w21, w19
     658:      	csel	w11, w21, w19, lo
     65c:      	cinc	w13, w11, hi
     660:      	sub	w14, w21, w13
     664:      	subs	x12, x12, x13
     668:      	str	w14, [sp, #0x78]
     66c:      	b.lo	0x8f8 <execve_send+0x558>
     670:      	cmp	x12, #0xfff
     674:      	b.hi	0x8f8 <execve_send+0x558>
     678:      	cmp	w21, w19
     67c:      	b.ls	0x688 <execve_send+0x2e8>
     680:      	mov	w13, #0x2f              // =47
     684:      	strb	w13, [x8, x12]
     688:      	add	x23, x8, x12
     68c:      	cmp	w21, w19
     690:      	add	x2, x9, x10
     694:      	and	w1, w11, #0xff
     698:      	mov	w8, #0x4                // =4
     69c:      	cinc	x0, x23, hi
     6a0:      	blr	x8
     6a4:      	cmp	w21, w19
     6a8:      	str	x23, [sp, #0x70]
     6ac:      	b.ls	0x8f8 <execve_send+0x558>
     6b0:      	ldr	x8, [sp, #0x88]
     6b4:      	str	x8, [sp, #0x58]
     6b8:      	b	0x5a0 <execve_send+0x200>
     6bc:      	nop
     6c0:      	add	x2, x21, #0x10
     6c4:      	mov	w8, #0x4                // =4
     6c8:      	add	x0, sp, #0xa8
     6cc:      	mov	w1, #0x8                // =8
     6d0:      	blr	x8
     6d4:      	ldr	x8, [sp, #0x68]
     6d8:      	ldr	x9, [sp, #0xa8]
     6dc:      	cmp	x8, x9
     6e0:      	b.eq	0x8f0 <execve_send+0x550>
     6e4:      	add	x2, x21, #0x18
     6e8:      	mov	w8, #0x4                // =4
     6ec:      	mov	x0, x22
     6f0:      	mov	w1, #0x8                // =8
     6f4:      	blr	x8
     6f8:      	ldr	x8, [sp, #0xa8]
     6fc:      	add	x9, x8, #0x20
     700:      	stp	x9, x8, [sp, #0x60]
     704:      	b	0x5a0 <execve_send+0x200>
     708:      	add	x2, x24, #0x18
     70c:      	mov	w8, #0x8                // =8
     710:      	mov	w9, #0x4                // =4
     714:      	add	x10, sp, #0x40
     718:      	add	x0, sp, #0x40
     71c:      	mov	w1, #0x8                // =8
     720:      	blr	x9
     724:      	ldr	x8, [sp, #0x40]
     728:      	cmp	x8, x24
     72c:      	b.eq	0x4d8 <execve_send+0x138>
     730:      	ldr	x29, [sp, #0x20]
     734:      	ldr	w9, [x29, #0x1840]
     738:      	sub	w8, w9, #0xa
     73c:      	cmp	w9, #0x9
     740:      	str	w8, [x29, #0x1840]
     744:      	b.gt	0xea8 <execve_send+0xb08>
     748:      	ldr	x25, [sp, #0x10]
     74c:      	mov	w9, #-0x24              // =-36
     750:      	mov	x22, x19
     754:      	str	w9, [x29, #0x1844]
     758:      	b	0x95c <execve_send+0x5bc>
     75c:      	mov	w20, #0x80              // =128
     760:      	mov	w24, #0x8               // =8
     764:      	add	x25, sp, #0x80
     768:      	add	x29, sp, #0xa8
     76c:      	b	0x7b8 <execve_send+0x418>
     770:      	nop
     774:      	nop
     778:      	nop
     77c:      	nop
     780:      	add	x23, x8, x12
     784:      	cmp	w21, w19
     788:      	add	x2, x9, x10
     78c:      	and	w1, w11, #0xff
     790:      	mov	w8, #0x4                // =4
     794:      	cinc	x0, x23, hi
     798:      	blr	x8
     79c:      	cmp	w21, w19
     7a0:      	str	x23, [sp, #0x70]
     7a4:      	b.ls	0x8f8 <execve_send+0x558>
     7a8:      	ldr	x8, [sp, #0x88]
     7ac:      	str	x8, [sp, #0x58]
     7b0:      	subs	w20, w20, #0x1
     7b4:      	b.eq	0x8f8 <execve_send+0x558>
     7b8:      	ldp	x19, x2, [sp, #0x58]
     7bc:      	ldp	x8, x9, [sp, #0x40]
     7c0:      	cmp	x19, x8
     7c4:      	ccmp	x2, x9, #0x0, eq
     7c8:      	b.eq	0x8f0 <execve_send+0x550>
     7cc:      	ldr	x21, [sp, #0x68]
     7d0:      	mov	w8, #0x4                // =4
     7d4:      	add	x0, sp, #0x80
     7d8:      	mov	w1, #0x8                // =8
     7dc:      	blr	x8
     7e0:      	ldr	x8, [sp, #0x80]
     7e4:      	cmp	x19, x8
     7e8:      	b.eq	0x8a0 <execve_send+0x500>
     7ec:      	add	x23, x19, #0x18
     7f0:      	mov	w8, #0x4                // =4
     7f4:      	add	x0, sp, #0xa8
     7f8:      	mov	w1, #0x8                // =8
     7fc:      	mov	x2, x23
     800:      	blr	x8
     804:      	ldr	x8, [sp, #0xa8]
     808:      	cmp	x8, x19
     80c:      	b.eq	0x8a0 <execve_send+0x500>
     810:      	mov	w8, #0x4                // =4
     814:      	add	x9, sp, #0x88
     818:      	add	x0, sp, #0x88
     81c:      	mov	w1, #0x8                // =8
     820:      	mov	x2, x23
     824:      	blr	x8
     828:      	add	x2, x19, #0x20
     82c:      	mov	w8, #0x4                // =4
     830:      	mov	w9, #0x10               // =16
     834:      	add	x10, sp, #0x90
     838:      	add	x0, sp, #0x90
     83c:      	mov	w1, #0x10               // =16
     840:      	blr	x8
     844:      	ldr	w19, [sp, #0x94]
     848:      	ldr	x8, [sp, #0x50]
     84c:      	ldr	x10, [sp, #0x70]
     850:      	sub	x12, x10, x8
     854:      	ldr	w21, [sp, #0x78]
     858:      	subs	w10, w19, w21
     85c:      	ldr	x9, [sp, #0x98]
     860:      	csel	w10, wzr, w10, lo
     864:      	cmp	w21, w19
     868:      	csel	w11, w21, w19, lo
     86c:      	cinc	w13, w11, hi
     870:      	sub	w14, w21, w13
     874:      	subs	x12, x12, x13
     878:      	str	w14, [sp, #0x78]
     87c:      	b.lo	0x8f8 <execve_send+0x558>
     880:      	cmp	x12, #0xfff
     884:      	b.hi	0x8f8 <execve_send+0x558>
     888:      	cmp	w21, w19
     88c:      	b.ls	0x780 <execve_send+0x3e0>
     890:      	mov	w13, #0x2f              // =47
     894:      	strb	w13, [x8, x12]
     898:      	b	0x780 <execve_send+0x3e0>
     89c:      	nop
     8a0:      	add	x2, x21, #0x10
     8a4:      	mov	w8, #0x4                // =4
     8a8:      	add	x0, sp, #0xa8
     8ac:      	mov	w1, #0x8                // =8
     8b0:      	blr	x8
     8b4:      	ldr	x8, [sp, #0x68]
     8b8:      	ldr	x9, [sp, #0xa8]
     8bc:      	cmp	x8, x9
     8c0:      	b.eq	0x8f0 <execve_send+0x550>
     8c4:      	add	x2, x21, #0x18
     8c8:      	mov	w8, #0x4                // =4
     8cc:      	mov	x0, x22
     8d0:      	mov	w1, #0x8                // =8
     8d4:      	blr	x8
     8d8:      	ldr	x8, [sp, #0xa8]
     8dc:      	add	x9, x8, #0x20
     8e0:      	stp	x9, x8, [sp, #0x60]
     8e4:      	subs	w20, w20, #0x1
     8e8:      	b.ne	0x7b8 <execve_send+0x418>
     8ec:      	b	0x8f8 <execve_send+0x558>
     8f0:      	mov	w8, #0x1                // =1
     8f4:      	strb	w8, [sp, #0x7c]
     8f8:      	ldr	x22, [sp, #0x70]
     8fc:      	ldr	x9, [sp, #0x8]
     900:      	cmp	x22, x9
     904:      	b.eq	0x948 <execve_send+0x5a8>
     908:      	ldrb	w8, [sp, #0x7c]
     90c:      	ldr	x29, [sp, #0x20]
     910:      	cmp	w8, #0x0
     914:      	ldr	x25, [sp, #0x10]
     918:      	cset	w8, eq
     91c:      	lsl	w9, w8, #1
     920:      	ldr	w8, [sp, #0x78]
     924:      	cmp	w8, #0x1
     928:      	str	w8, [x29, #0x1840]
     92c:      	str	w9, [x29, #0x1844]
     930:      	b.lt	0x940 <execve_send+0x5a0>
     934:      	mov	w9, #0x1000             // =4096
     938:      	sub	w8, w9, w8
     93c:      	str	w8, [x29, #0x1840]
     940:      	cbnz	x22, 0x95c <execve_send+0x5bc>
     944:      	b	0xa90 <execve_send+0x6f0>
     948:      	ldr	x29, [sp, #0x20]
     94c:      	ldr	x25, [sp, #0x10]
     950:      	mov	w8, wzr
     954:      	mov	x22, x9
     958:      	str	xzr, [x29, #0x1840]
     95c:      	subs	w9, w8, #0x7f
     960:      	mov	w10, #0x7f              // =127
     964:      	mov	x0, x25
     968:      	mov	x2, x22
     96c:      	csel	w24, w8, w10, lo
     970:      	csel	w19, wzr, w9, lo
     974:      	cmp	w8, #0xff
     978:      	mov	w9, #0xff               // =255
     97c:      	csel	w8, w8, w9, lo
     980:      	and	w1, w8, #0xff
     984:      	str	w1, [x29, #0x1840]
     988:      	mov	w8, #0x4                // =4
     98c:      	blr	x8
     990:      	adrp	x23, 0x0 <execve_rate>
     994:      	ldr	x23, [x23]
     998:      	cbz	x0, 0xa08 <execve_send+0x668>
     99c:      	neg	w8, w0
     9a0:      	mov	w9, #0x1                // =1
     9a4:      	add	x1, sp, #0x40
     9a8:      	strh	w8, [sp, #0x40]
     9ac:      	mov	w8, #0x8                // =8
     9b0:      	mov	x0, x23
     9b4:      	mov	w20, #0x1               // =1
     9b8:      	strh	w8, [sp, #0x42]
     9bc:      	mov	x8, #0x2de              // =734
     9c0:      	movk	x8, #0x4, lsl #32
     9c4:      	stur	x8, [sp, #0x44]
     9c8:      	add	x8, sp, #0x40
     9cc:      	blr	x9
     9d0:      	cbz	x0, 0x9e4 <execve_send+0x644>
     9d4:      	ldr	w8, [x0]
     9d8:      	add	w8, w8, #0x1
     9dc:      	str	w8, [x0]
     9e0:      	b	0xa08 <execve_send+0x668>
     9e4:      	str	w20, [sp, #0x90]
     9e8:      	mov	x3, xzr
     9ec:      	mov	w8, #0x2                // =2
     9f0:      	add	x9, sp, #0x40
     9f4:      	add	x10, sp, #0x90
     9f8:      	add	x1, sp, #0x40
     9fc:      	add	x2, sp, #0x90
     a00:      	mov	x0, x23
     a04:      	blr	x8
     a08:      	mov	w8, #0x17c0             // =6080
     a0c:      	add	x2, x22, x19
     a10:      	mov	w1, w24
     a14:      	add	x0, x29, x8
     a18:      	mov	w8, #0x4                // =4
     a1c:      	blr	x8
     a20:      	cbz	x0, 0xa90 <execve_send+0x6f0>
     a24:      	neg	w8, w0
     a28:      	mov	w9, #0x1                // =1
     a2c:      	add	x1, sp, #0x40
     a30:      	strh	w8, [sp, #0x40]
     a34:      	mov	w8, #0x8                // =8
     a38:      	mov	x0, x23
     a3c:      	mov	w19, #0x1               // =1
     a40:      	strh	w8, [sp, #0x42]
     a44:      	mov	x8, #0x2e0              // =736
     a48:      	movk	x8, #0x4, lsl #32
     a4c:      	stur	x8, [sp, #0x44]
     a50:      	add	x8, sp, #0x40
     a54:      	blr	x9
     a58:      	cbz	x0, 0xa6c <execve_send+0x6cc>
     a5c:      	ldr	w8, [x0]
     a60:      	add	w8, w8, #0x1
     a64:      	str	w8, [x0]
     a68:      	b	0xa90 <execve_send+0x6f0>
     a6c:      	str	w19, [sp, #0x90]
     a70:      	mov	x3, xzr
     a74:      	mov	w8, #0x2                // =2
     a78:      	add	x9, sp, #0x40
     a7c:      	add	x10, sp, #0x90
     a80:      	add	x1, sp, #0x40
     a84:      	add	x2, sp, #0x90
     a88:      	mov	x0, x23
     a8c:      	blr	x8
     a90:      	mov	w8, #0xe                // =14
     a94:      	blr	x8
     a98:      	lsr	x8, x0, #32
     a9c:      	adrp	x23, 0x0 <execve_rate>
     aa0:      	add	x9, sp, #0x40
     aa4:      	str	w8, [sp, #0x40]
     aa8:      	mov	w8, #0x1                // =1
     aac:      	add	x1, sp, #0x40
     ab0:      	ldr	x23, [x23]
     ab4:      	mov	x0, x23
     ab8:      	blr	x8
     abc:      	cbz	x0, 0x1270 <execve_send+0xed0>
     ac0:      	ldp	x8, x9, [x0]
     ac4:      	mov	x22, x0
     ac8:      	stp	x8, x9, [x29, #0x130]
     acc:      	ldr	w9, [x29, #0x144]
     ad0:      	ldr	w8, [x0, #0x20]
     ad4:      	str	w9, [x0]
     ad8:      	ldr	x9, [x29, #0x170]
     adc:      	str	x9, [x0, #0x8]
     ae0:      	ldr	w9, [x29, #0x14c]
     ae4:      	str	w9, [x0, #0x24]
     ae8:      	ldp	x11, x10, [x29, #0xa0]
     aec:      	stp	x11, x10, [x0, #0x10]
     af0:      	tbnz	w8, #0x0, 0xb28 <execve_send+0x788>
     af4:      	and	w10, w8, #0xfffffffe
     af8:      	cmp	w9, #0x1
     afc:      	orr	w11, w10, #0x2000000
     b00:      	csel	w9, w11, w10, eq
     b04:      	str	w9, [x22, #0x20]
     b08:      	tbnz	w9, #0x19, 0xb4c <execve_send+0x7ac>
     b0c:      	cmp	w8, #0x1
     b10:      	b.eq	0xb60 <execve_send+0x7c0>
     b14:      	adrp	x8, 0x0 <execve_rate>
     b18:      	ldr	x8, [x8]
     b1c:      	ldrb	w8, [x8]
     b20:      	cbnz	w8, 0xba0 <execve_send+0x800>
     b24:      	b	0xe08 <execve_send+0xa68>
     b28:      	ldr	w10, [x29, #0x15c]
     b2c:      	orr	w10, w10, #0x4000
     b30:      	str	w10, [x29, #0x15c]
     b34:      	and	w10, w8, #0xfffffffe
     b38:      	cmp	w9, #0x1
     b3c:      	orr	w11, w10, #0x2000000
     b40:      	csel	w9, w11, w10, eq
     b44:      	str	w9, [x22, #0x20]
     b48:      	tbz	w9, #0x19, 0xb0c <execve_send+0x76c>
     b4c:      	ldr	w9, [x29, #0x15c]
     b50:      	orr	w9, w9, #0x2000000
     b54:      	str	w9, [x29, #0x15c]
     b58:      	cmp	w8, #0x1
     b5c:      	b.ne	0xb14 <execve_send+0x774>
     b60:      	ldr	x8, [x29, #0x108]
     b64:      	str	x8, [x22, #0x28]
     b68:      	ldp	x8, x9, [x29, #0x110]
     b6c:      	ldp	x10, x11, [x29, #0x120]
     b70:      	stp	x10, x11, [x22, #0x40]
     b74:      	stp	x8, x9, [x22, #0x30]
     b78:      	ldr	x8, [x29, #0xe0]
     b7c:      	str	x8, [x22, #0x50]
     b80:      	ldr	x8, [x29, #0xe8]
     b84:      	str	x8, [x22, #0x58]
     b88:      	ldr	x8, [x29, #0xf0]
     b8c:      	str	x8, [x22, #0x60]
     b90:      	adrp	x8, 0x0 <execve_rate>
     b94:      	ldr	x8, [x8]
     b98:      	ldrb	w8, [x8]
     b9c:      	cbz	w8, 0xe08 <execve_send+0xa68>
     ba0:      	str	wzr, [sp, #0x88]
     ba4:      	adrp	x0, 0x0 <execve_rate>
     ba8:      	mov	w8, #0x1                // =1
     bac:      	add	x9, sp, #0x88
     bb0:      	ldr	x0, [x0]
     bb4:      	add	x1, sp, #0x88
     bb8:      	blr	x8
     bbc:      	cbz	x0, 0xe08 <execve_send+0xa68>
     bc0:      	ldrb	w8, [x29, #0x15d]
     bc4:      	tbnz	w8, #0x6, 0xbf4 <execve_send+0x854>
     bc8:      	add	x1, x22, #0x68
     bcc:      	mov	w2, #0x318              // =792
     bd0:      	mov	x20, x0
     bd4:      	bl	0xbd4 <execve_send+0x834>
     bd8:      	adrp	x0, 0x0 <execve_rate>
     bdc:      	mov	x3, xzr
     be0:      	mov	w8, #0x2                // =2
     be4:      	ldr	x0, [x0]
     be8:      	mov	x1, x22
     bec:      	mov	x2, x20
     bf0:      	b	0xe04 <execve_send+0xa64>
     bf4:      	mov	w8, #0x23               // =35
     bf8:      	blr	x8
     bfc:      	str	x0, [sp, #0x40]
     c00:      	add	x8, x0, #0x8e0
     c04:      	mov	w9, #0x8                // =8
     c08:      	mov	w10, #0x71              // =113
     c0c:      	add	x11, sp, #0x40
     c10:      	add	x0, sp, #0x40
     c14:      	mov	w1, #0x8                // =8
     c18:      	ldr	x8, [sp, #0x40]
     c1c:      	add	x2, x8, #0x8e0
     c20:      	blr	x10
     c24:      	ldr	x8, [sp, #0x40]
     c28:      	cbz	x8, 0xe08 <execve_send+0xa68>
     c2c:      	add	x8, x8, #0x8d4
     c30:      	mov	w9, #0x4                // =4
     c34:      	mov	w10, #0x71              // =113
     c38:      	add	x11, sp, #0xa8
     c3c:      	ldr	x8, [sp, #0x40]
     c40:      	add	x0, sp, #0xa8
     c44:      	mov	w1, #0x4                // =4
     c48:      	add	x2, x8, #0x8d4
     c4c:      	blr	x10
     c50:      	ldr	w8, [sp, #0xa8]
     c54:      	add	x9, sp, #0x90
     c58:      	add	x1, sp, #0x90
     c5c:      	mov	x0, x23
     c60:      	str	w8, [sp, #0x90]
     c64:      	mov	w8, #0x1                // =1
     c68:      	blr	x8
     c6c:      	cbz	x0, 0xc78 <execve_send+0x8d8>
     c70:      	ldr	x8, [x0, #0x8]
     c74:      	cbnz	x8, 0xdec <execve_send+0xa4c>
     c78:      	ldr	x8, [sp, #0x40]
     c7c:      	mov	w9, #0x8                // =8
     c80:      	mov	w10, #0x71              // =113
     c84:      	add	x11, sp, #0x40
     c88:      	add	x0, sp, #0x40
     c8c:      	mov	w1, #0x8                // =8
     c90:      	add	x8, x8, #0x8e0
     c94:      	ldr	x8, [sp, #0x40]
     c98:      	add	x2, x8, #0x8e0
     c9c:      	blr	x10
     ca0:      	ldr	x8, [sp, #0x40]
     ca4:      	cbz	x8, 0xe08 <execve_send+0xa68>
     ca8:      	add	x8, x8, #0x8d4
     cac:      	mov	w9, #0x4                // =4
     cb0:      	mov	w10, #0x71              // =113
     cb4:      	add	x11, sp, #0xa8
     cb8:      	ldr	x8, [sp, #0x40]
     cbc:      	add	x0, sp, #0xa8
     cc0:      	mov	w1, #0x4                // =4
     cc4:      	add	x2, x8, #0x8d4
     cc8:      	blr	x10
     ccc:      	ldr	w8, [sp, #0xa8]
     cd0:      	add	x9, sp, #0x90
     cd4:      	add	x1, sp, #0x90
     cd8:      	mov	x0, x23
     cdc:      	str	w8, [sp, #0x90]
     ce0:      	mov	w8, #0x1                // =1
     ce4:      	blr	x8
     ce8:      	cbz	x0, 0xcf4 <execve_send+0x954>
     cec:      	ldr	x8, [x0, #0x8]
     cf0:      	cbnz	x8, 0xdec <execve_send+0xa4c>
     cf4:      	ldr	x8, [sp, #0x40]
     cf8:      	mov	w9, #0x8                // =8
     cfc:      	mov	w10, #0x71              // =113
     d00:      	add	x11, sp, #0x40
     d04:      	add	x0, sp, #0x40
     d08:      	mov	w1, #0x8                // =8
     d0c:      	add	x8, x8, #0x8e0
     d10:      	ldr	x8, [sp, #0x40]
     d14:      	add	x2, x8, #0x8e0
     d18:      	blr	x10
     d1c:      	ldr	x8, [sp, #0x40]
     d20:      	cbz	x8, 0xe08 <execve_send+0xa68>
     d24:      	add	x8, x8, #0x8d4
     d28:      	mov	w9, #0x4                // =4
     d2c:      	mov	w10, #0x71              // =113
     d30:      	add	x11, sp, #0xa8
     d34:      	ldr	x8, [sp, #0x40]
     d38:      	add	x0, sp, #0xa8
     d3c:      	mov	w1, #0x4                // =4
     d40:      	add	x2, x8, #0x8d4
     d44:      	blr	x10
     d48:      	ldr	w8, [sp, #0xa8]
     d4c:      	add	x9, sp, #0x90
     d50:      	add	x1, sp, #0x90
     d54:      	mov	x0, x23
     d58:      	str	w8, [sp, #0x90]
     d5c:      	mov	w8, #0x1                // =1
     d60:      	blr	x8
     d64:      	cbz	x0, 0xd70 <execve_send+0x9d0>
     d68:      	ldr	x8, [x0, #0x8]
     d6c:      	cbnz	x8, 0xdec <execve_send+0xa4c>
     d70:      	ldr	x8, [sp, #0x40]
     d74:      	mov	w9, #0x8                // =8
     d78:      	mov	w10, #0x71              // =113
     d7c:      	add	x11, sp, #0x40
     d80:      	add	x0, sp, #0x40
     d84:      	mov	w1, #0x8                // =8
     d88:      	add	x8, x8, #0x8e0
     d8c:      	ldr	x8, [sp, #0x40]
     d90:      	add	x2, x8, #0x8e0
     d94:      	blr	x10
     d98:      	ldr	x8, [sp, #0x40]
     d9c:      	cbz	x8, 0xe08 <execve_send+0xa68>
     da0:      	add	x8, x8, #0x8d4
     da4:      	mov	w9, #0x4                // =4
     da8:      	mov	w10, #0x71              // =113
     dac:      	add	x11, sp, #0xa8
     db0:      	ldr	x8, [sp, #0x40]
     db4:      	add	x0, sp, #0xa8
     db8:      	mov	w1, #0x4                // =4
     dbc:      	add	x2, x8, #0x8d4
     dc0:      	blr	x10
     dc4:      	ldr	w8, [sp, #0xa8]
     dc8:      	add	x9, sp, #0x90
     dcc:      	add	x1, sp, #0x90
     dd0:      	mov	x0, x23
     dd4:      	str	w8, [sp, #0x90]
     dd8:      	mov	w8, #0x1                // =1
     ddc:      	blr	x8
     de0:      	cbz	x0, 0xe08 <execve_send+0xa68>
     de4:      	ldr	x8, [x0, #0x8]
     de8:      	cbz	x8, 0xe08 <execve_send+0xa68>
     dec:      	add	x2, x0, #0x68
     df0:      	adrp	x0, 0x0 <execve_rate>
     df4:      	mov	x3, xzr
     df8:      	ldr	x0, [x0]
     dfc:      	mov	w8, #0x2                // =2
     e00:      	mov	x1, x22
     e04:      	blr	x8
     e08:      	add	x0, x22, #0x68
     e0c:      	mov	w1, wzr
     e10:      	mov	w2, #0x308              // =776
     e14:      	add	x20, x29, #0x140
     e18:      	bl	0xe18 <execve_send+0xa78>
     e1c:      	ldr	w8, [x29, #0x1840]
     e20:      	sub	w9, w8, #0x101
     e24:      	cmn	w9, #0x101
     e28:      	b.hi	0xe38 <execve_send+0xa98>
     e2c:      	mov	w8, #-0x1               // =-1
     e30:      	stur	w8, [x22, #0x68]
     e34:      	b	0xf90 <execve_send+0xbf0>
     e38:      	and	x24, x8, #0xff
     e3c:      	add	x0, x22, #0x70
     e40:      	mov	w8, #0x4                // =4
     e44:      	mov	x2, x25
     e48:      	mov	w1, w24
     e4c:      	blr	x8
     e50:      	mov	x21, x0
     e54:      	cbz	x0, 0xeec <execve_send+0xb4c>
     e58:      	neg	w8, w21
     e5c:      	adrp	x25, 0x0 <execve_rate>
     e60:      	mov	w9, #0x1                // =1
     e64:      	strh	w8, [sp, #0x40]
     e68:      	mov	w8, #0xf                // =15
     e6c:      	add	x1, sp, #0x40
     e70:      	mov	w19, #0x1               // =1
     e74:      	strh	w8, [sp, #0x42]
     e78:      	mov	x8, #0x164              // =356
     e7c:      	movk	x8, #0x4, lsl #32
     e80:      	stur	x8, [sp, #0x44]
     e84:      	add	x8, sp, #0x40
     e88:      	ldr	x25, [x25]
     e8c:      	mov	x0, x25
     e90:      	blr	x9
     e94:      	cbz	x0, 0xec8 <execve_send+0xb28>
     e98:      	ldr	w8, [x0]
     e9c:      	add	w8, w8, #0x1
     ea0:      	str	w8, [x0]
     ea4:      	b	0xeec <execve_send+0xb4c>
     ea8:      	mov	w8, #0x2964             // =10596
     eac:      	add	x19, x22, #0xff6
     eb0:      	strh	w8, [x22, #0xffe]
     eb4:      	adrp	x8, 0x0 <execve_rate>
     eb8:      	add	x8, x8, #0x0
     ebc:      	ldr	x8, [x8]
     ec0:      	str	x8, [x19]
     ec4:      	b	0x4d8 <execve_send+0x138>
     ec8:      	str	w19, [sp, #0x90]
     ecc:      	mov	x3, xzr
     ed0:      	mov	w8, #0x2                // =2
     ed4:      	add	x9, sp, #0x40
     ed8:      	add	x10, sp, #0x90
     edc:      	add	x1, sp, #0x40
     ee0:      	add	x2, sp, #0x90
     ee4:      	mov	x0, x25
     ee8:      	blr	x8
     eec:      	cmp	w21, #0x0
     ef0:      	add	x0, x22, #0x170
     ef4:      	csel	w8, w24, w21, eq
     ef8:      	cmp	w24, #0x7f
     efc:      	str	w8, [x22, #0x68]
     f00:      	mov	w8, #0x7f               // =127
     f04:      	csel	w1, w24, w8, lo
     f08:      	mov	w8, #0x17c0             // =6080
     f0c:      	add	x2, x29, x8
     f10:      	mov	w8, #0x4                // =4
     f14:      	blr	x8
     f18:      	cbz	x0, 0xf90 <execve_send+0xbf0>
     f1c:      	neg	w8, w0
     f20:      	adrp	x21, 0x0 <execve_rate>
     f24:      	mov	w9, #0x1                // =1
     f28:      	strh	w8, [sp, #0x40]
     f2c:      	mov	w8, #0xf                // =15
     f30:      	add	x1, sp, #0x40
     f34:      	mov	w19, #0x1               // =1
     f38:      	strh	w8, [sp, #0x42]
     f3c:      	mov	x8, #0x16a              // =362
     f40:      	movk	x8, #0x4, lsl #32
     f44:      	stur	x8, [sp, #0x44]
     f48:      	add	x8, sp, #0x40
     f4c:      	ldr	x21, [x21]
     f50:      	mov	x0, x21
     f54:      	blr	x9
     f58:      	cbz	x0, 0xf6c <execve_send+0xbcc>
     f5c:      	ldr	w8, [x0]
     f60:      	add	w8, w8, #0x1
     f64:      	str	w8, [x0]
     f68:      	b	0xf90 <execve_send+0xbf0>
     f6c:      	str	w19, [sp, #0x90]
     f70:      	mov	x3, xzr
     f74:      	mov	w8, #0x2                // =2
     f78:      	add	x9, sp, #0x40
     f7c:      	add	x10, sp, #0x90
     f80:      	add	x1, sp, #0x40
     f84:      	add	x2, sp, #0x90
     f88:      	mov	x0, x21
     f8c:      	blr	x8
     f90:      	ldr	w9, [x29, #0x1848]
     f94:      	ldr	w8, [x29, #0x184c]
     f98:      	mov	w10, #0xfe              // =254
     f9c:      	add	x24, x22, #0x270
     fa0:      	mov	x0, x24
     fa4:      	cmp	w9, #0xfe
     fa8:      	add	x2, x20, x8
     fac:      	mov	w8, #0x4                // =4
     fb0:      	csel	w21, w9, w10, lo
     fb4:      	mov	w1, w21
     fb8:      	blr	x8
     fbc:      	cbz	x0, 0x1034 <execve_send+0xc94>
     fc0:      	neg	w8, w0
     fc4:      	adrp	x25, 0x0 <execve_rate>
     fc8:      	mov	w9, #0x1                // =1
     fcc:      	strh	w8, [sp, #0x40]
     fd0:      	mov	w8, #0x9                // =9
     fd4:      	add	x1, sp, #0x40
     fd8:      	mov	w19, #0x1               // =1
     fdc:      	strh	w8, [sp, #0x42]
     fe0:      	mov	x8, #0x1af              // =431
     fe4:      	movk	x8, #0x4, lsl #32
     fe8:      	stur	x8, [sp, #0x44]
     fec:      	add	x8, sp, #0x40
     ff0:      	ldr	x25, [x25]
     ff4:      	mov	x0, x25
     ff8:      	blr	x9
     ffc:      	cbz	x0, 0x1010 <execve_send+0xc70>
    1000:      	ldr	w8, [x0]
    1004:      	add	w8, w8, #0x1
    1008:      	str	w8, [x0]
    100c:      	b	0x1034 <execve_send+0xc94>
    1010:      	str	w19, [sp, #0x90]
    1014:      	mov	x3, xzr
    1018:      	mov	w8, #0x2                // =2
    101c:      	add	x9, sp, #0x40
    1020:      	add	x10, sp, #0x90
    1024:      	add	x1, sp, #0x40
    1028:      	add	x2, sp, #0x90
    102c:      	mov	x0, x25
    1030:      	blr	x8
    1034:      	add	w8, w21, #0x1
    1038:      	strb	wzr, [x24, x21]
    103c:      	strb	wzr, [x24, w8, uxtw]
    1040:      	mov	w8, #0x23               // =35
    1044:      	blr	x8
    1048:      	str	x0, [sp, #0x40]
    104c:      	add	x8, x0, #0x8e0
    1050:      	mov	w9, #0x8                // =8
    1054:      	mov	w10, #0x71              // =113
    1058:      	add	x11, sp, #0x40
    105c:      	add	x0, sp, #0x40
    1060:      	mov	w1, #0x8                // =8
    1064:      	ldr	x8, [sp, #0x40]
    1068:      	add	x2, x8, #0x8e0
    106c:      	blr	x10
    1070:      	ldr	x8, [sp, #0x40]
    1074:      	cbz	x8, 0x1248 <execve_send+0xea8>
    1078:      	add	x8, x8, #0x8d4
    107c:      	mov	w9, #0x4                // =4
    1080:      	mov	w10, #0x71              // =113
    1084:      	add	x11, sp, #0xa8
    1088:      	ldr	x8, [sp, #0x40]
    108c:      	add	x0, sp, #0xa8
    1090:      	mov	w1, #0x4                // =4
    1094:      	add	x2, x8, #0x8d4
    1098:      	blr	x10
    109c:      	ldr	w8, [sp, #0xa8]
    10a0:      	add	x9, sp, #0x90
    10a4:      	add	x1, sp, #0x90
    10a8:      	mov	x0, x23
    10ac:      	str	w8, [sp, #0x90]
    10b0:      	mov	w8, #0x1                // =1
    10b4:      	blr	x8
    10b8:      	cbz	x0, 0x10c4 <execve_send+0xd24>
    10bc:      	ldr	x8, [x0, #0x8]
    10c0:      	cbnz	x8, 0x1238 <execve_send+0xe98>
    10c4:      	ldr	x8, [sp, #0x40]
    10c8:      	mov	w9, #0x8                // =8
    10cc:      	mov	w10, #0x71              // =113
    10d0:      	add	x11, sp, #0x40
    10d4:      	add	x0, sp, #0x40
    10d8:      	mov	w1, #0x8                // =8
    10dc:      	add	x8, x8, #0x8e0
    10e0:      	ldr	x8, [sp, #0x40]
    10e4:      	add	x2, x8, #0x8e0
    10e8:      	blr	x10
    10ec:      	ldr	x8, [sp, #0x40]
    10f0:      	cbz	x8, 0x1248 <execve_send+0xea8>
    10f4:      	add	x8, x8, #0x8d4
    10f8:      	mov	w9, #0x4                // =4
    10fc:      	mov	w10, #0x71              // =113
    1100:      	add	x11, sp, #0xa8
    1104:      	ldr	x8, [sp, #0x40]
    1108:      	add	x0, sp, #0xa8
    110c:      	mov	w1, #0x4                // =4
    1110:      	add	x2, x8, #0x8d4
    1114:      	blr	x10
    1118:      	ldr	w8, [sp, #0xa8]
    111c:      	add	x9, sp, #0x90
    1120:      	add	x1, sp, #0x90
    1124:      	mov	x0, x23
    1128:      	str	w8, [sp, #0x90]
    112c:      	mov	w8, #0x1                // =1
    1130:      	blr	x8
    1134:      	cbz	x0, 0x1140 <execve_send+0xda0>
    1138:      	ldr	x8, [x0, #0x8]
    113c:      	cbnz	x8, 0x1238 <execve_send+0xe98>
    1140:      	ldr	x8, [sp, #0x40]
    1144:      	mov	w9, #0x8                // =8
    1148:      	mov	w10, #0x71              // =113
    114c:      	add	x11, sp, #0x40
    1150:      	add	x0, sp, #0x40
    1154:      	mov	w1, #0x8                // =8
    1158:      	add	x8, x8, #0x8e0
    115c:      	ldr	x8, [sp, #0x40]
    1160:      	add	x2, x8, #0x8e0
    1164:      	blr	x10
    1168:      	ldr	x8, [sp, #0x40]
    116c:      	cbz	x8, 0x1248 <execve_send+0xea8>
    1170:      	add	x8, x8, #0x8d4
    1174:      	mov	w9, #0x4                // =4
    1178:      	mov	w10, #0x71              // =113
    117c:      	add	x11, sp, #0xa8
    1180:      	ldr	x8, [sp, #0x40]
    1184:      	add	x0, sp, #0xa8
    1188:      	mov	w1, #0x4                // =4
    118c:      	add	x2, x8, #0x8d4
    1190:      	blr	x10
    1194:      	ldr	w8, [sp, #0xa8]
    1198:      	add	x9, sp, #0x90
    119c:      	add	x1, sp, #0x90
    11a0:      	mov	x0, x23
    11a4:      	str	w8, [sp, #0x90]
    11a8:      	mov	w8, #0x1                // =1
    11ac:      	blr	x8
    11b0:      	cbz	x0, 0x11bc <execve_send+0xe1c>
    11b4:      	ldr	x8, [x0, #0x8]
    11b8:      	cbnz	x8, 0x1238 <execve_send+0xe98>
    11bc:      	ldr	x8, [sp, #0x40]
    11c0:      	mov	w9, #0x8                // =8
    11c4:      	mov	w10, #0x71              // =113
    11c8:      	add	x11, sp, #0x40
    11cc:      	add	x0, sp, #0x40
    11d0:      	mov	w1, #0x8                // =8
    11d4:      	add	x8, x8, #0x8e0
    11d8:      	ldr	x8, [sp, #0x40]
    11dc:      	add	x2, x8, #0x8e0
    11e0:      	blr	x10
    11e4:      	ldr	x8, [sp, #0x40]
    11e8:      	cbz	x8, 0x1248 <execve_send+0xea8>
    11ec:      	add	x8, x8, #0x8d4
    11f0:      	mov	w9, #0x4                // =4
    11f4:      	mov	w10, #0x71              // =113
    11f8:      	add	x11, sp, #0xa8
    11fc:      	ldr	x8, [sp, #0x40]
    1200:      	add	x0, sp, #0xa8
    1204:      	mov	w1, #0x4                // =4
    1208:      	add	x2, x8, #0x8d4
    120c:      	blr	x10
    1210:      	ldr	w8, [sp, #0xa8]
    1214:      	add	x9, sp, #0x90
    1218:      	add	x1, sp, #0x90
    121c:      	mov	x0, x23
    1220:      	str	w8, [sp, #0x90]
    1224:      	mov	w8, #0x1                // =1
    1228:      	blr	x8
    122c:      	cbz	x0, 0x1248 <execve_send+0xea8>
    1230:      	ldr	x8, [x0, #0x8]
    1234:      	cbz	x8, 0x1248 <execve_send+0xea8>
    1238:      	ldr	x8, [x0, #0x370]
    123c:      	ldr	x9, [x22, #0x370]
    1240:      	orr	x8, x9, x8
    1244:      	str	x8, [x22, #0x370]
    1248:      	adrp	x0, 0x1000 <execve_send+0xc60>
    124c:      	add	x1, x22, #0x70
    1250:      	mov	w8, #0x1                // =1
    1254:      	ldr	x0, [x0]
    1258:      	blr	x8
    125c:      	cbz	x0, 0x1270 <execve_send+0xed0>
    1260:      	ldr	x8, [x0]
    1264:      	ldr	x9, [x22, #0x370]
    1268:      	orr	x8, x9, x8
    126c:      	str	x8, [x22, #0x370]
    1270:      	ldr	w8, [x29, #0x140]
    1274:      	strb	wzr, [x29, #0x1]
    1278:      	mov	w9, #0x1710             // =5904
    127c:      	adrp	x0, 0x1000 <execve_send+0xc60>
    1280:      	add	x1, sp, #0x90
    1284:      	str	wzr, [sp, #0x90]
    1288:      	ldr	x0, [x0]
    128c:      	cmp	w8, w9
    1290:      	csel	w8, w8, w9, lo
    1294:      	add	x9, sp, #0x90
    1298:      	add	w21, w8, #0x140
    129c:      	mov	w8, #0x1                // =1
    12a0:      	blr	x8
    12a4:      	cbz	x0, 0x1328 <execve_send+0xf88>
    12a8:      	ldrb	w8, [x0, #0x28]
    12ac:      	cbz	w8, 0x1328 <execve_send+0xf88>
    12b0:      	adrp	x1, 0x1000 <execve_send+0xc60>
    12b4:      	mov	w8, #-0x1               // =-1
    12b8:      	mov	w9, #0x19               // =25
    12bc:      	ldr	x1, [x1]
    12c0:      	ldr	x0, [sp, #0x18]
    12c4:      	mov	w2, #-0x1               // =-1
    12c8:      	mov	x3, x29
    12cc:      	mov	x4, x21
    12d0:      	blr	x9
    12d4:      	tbz	x0, #0x3f, 0x1450 <execve_send+0x10b0>
    12d8:      	mov	x19, x0
    12dc:      	str	wzr, [sp, #0x40]
    12e0:      	adrp	x0, 0x1000 <execve_send+0xc60>
    12e4:      	mov	w8, #0x1                // =1
    12e8:      	ldr	x0, [x0]
    12ec:      	add	x9, sp, #0x40
    12f0:      	add	x1, sp, #0x40
    12f4:      	blr	x8
    12f8:      	cbz	x0, 0x1450 <execve_send+0x10b0>
    12fc:      	mov	x8, x19
    1300:      	cmn	x19, #0xc
    1304:      	b.gt	0x13b8 <execve_send+0x1018>
    1308:      	cmn	x8, #0x1c
    130c:      	b.eq	0x1414 <execve_send+0x1074>
    1310:      	cmn	x8, #0x16
    1314:      	b.eq	0x142c <execve_send+0x108c>
    1318:      	cmn	x8, #0x10
    131c:      	b.ne	0x1424 <execve_send+0x1084>
    1320:      	add	x8, x0, #0x130
    1324:      	b	0x1440 <execve_send+0x10a0>
    1328:      	adrp	x0, 0x1000 <execve_send+0xc60>
    132c:      	mov	x3, xzr
    1330:      	mov	w8, #0x82               // =130
    1334:      	ldr	x0, [x0]
    1338:      	mov	x1, x29
    133c:      	mov	x2, x21
    1340:      	blr	x8
    1344:      	tbz	x0, #0x3f, 0x1450 <execve_send+0x10b0>
    1348:      	mov	x19, x0
    134c:      	str	wzr, [sp, #0x40]
    1350:      	adrp	x0, 0x1000 <execve_send+0xc60>
    1354:      	mov	w8, #0x1                // =1
    1358:      	ldr	x0, [x0]
    135c:      	add	x9, sp, #0x40
    1360:      	add	x1, sp, #0x40
    1364:      	blr	x8
    1368:      	cbz	x0, 0x1450 <execve_send+0x10b0>
    136c:      	mov	x8, x19
    1370:      	cmn	x19, #0xc
    1374:      	b.gt	0x1398 <execve_send+0xff8>
    1378:      	cmn	x8, #0x1c
    137c:      	b.eq	0x13d8 <execve_send+0x1038>
    1380:      	cmn	x8, #0x16
    1384:      	b.eq	0x13f0 <execve_send+0x1050>
    1388:      	cmn	x8, #0x10
    138c:      	b.ne	0x13e8 <execve_send+0x1048>
    1390:      	add	x8, x0, #0x130
    1394:      	b	0x1400 <execve_send+0x1060>
    1398:      	cmn	x8, #0xb
    139c:      	b.eq	0x13e0 <execve_send+0x1040>
    13a0:      	cmn	x8, #0x7
    13a4:      	b.eq	0x13f8 <execve_send+0x1058>
    13a8:      	cmn	x8, #0x2
    13ac:      	b.ne	0x13e8 <execve_send+0x1048>
    13b0:      	add	x8, x0, #0x120
    13b4:      	b	0x1400 <execve_send+0x1060>
    13b8:      	cmn	x8, #0xb
    13bc:      	b.eq	0x141c <execve_send+0x107c>
    13c0:      	cmn	x8, #0x7
    13c4:      	b.eq	0x1434 <execve_send+0x1094>
    13c8:      	cmn	x8, #0x2
    13cc:      	b.ne	0x1424 <execve_send+0x1084>
    13d0:      	add	x8, x0, #0x120
    13d4:      	b	0x1440 <execve_send+0x10a0>
    13d8:      	add	x8, x0, #0x140
    13dc:      	b	0x1400 <execve_send+0x1060>
    13e0:      	add	x8, x0, #0x148
    13e4:      	b	0x1400 <execve_send+0x1060>
    13e8:      	add	x8, x0, #0x118
    13ec:      	b	0x1400 <execve_send+0x1060>
    13f0:      	add	x8, x0, #0x138
    13f4:      	b	0x1400 <execve_send+0x1060>
    13f8:      	add	x8, x0, #0x128
    13fc:      	nop
    1400:      	ldaxr	x9, [x8]
    1404:      	add	x9, x9, #0x1
    1408:      	stlxr	w10, x9, [x8]
    140c:      	cbnz	w10, 0x1400 <execve_send+0x1060>
    1410:      	b	0x1450 <execve_send+0x10b0>
    1414:      	add	x8, x0, #0x140
    1418:      	b	0x1440 <execve_send+0x10a0>
    141c:      	add	x8, x0, #0x148
    1420:      	b	0x1440 <execve_send+0x10a0>
    1424:      	add	x8, x0, #0x118
    1428:      	b	0x1440 <execve_send+0x10a0>
    142c:      	add	x8, x0, #0x138
    1430:      	b	0x1440 <execve_send+0x10a0>
    1434:      	add	x8, x0, #0x128
    1438:      	nop
    143c:      	nop
    1440:      	ldaxr	x9, [x8]
    1444:      	add	x9, x9, #0x1
    1448:      	stlxr	w10, x9, [x8]
    144c:      	cbnz	w10, 0x1440 <execve_send+0x10a0>
    1450:      	ldp	x20, x19, [sp, #0xe0]
    1454:      	mov	w0, wzr
    1458:      	ldr	x29, [sp, #0xa0]
    145c:      	ldp	x22, x21, [sp, #0xd0]
    1460:      	ldp	x24, x23, [sp, #0xc0]
    1464:      	ldp	x30, x25, [sp, #0xb0]
    1468:      	add	sp, sp, #0xf0
    146c:      	ret

Disassembly of section tracepoint/sys_execve:

0000000000000000 <event_execve>:
       0:      	sub	sp, sp, #0x120
       4:      	str	x29, [sp, #0xd0]
       8:      	stp	x30, x25, [sp, #0xe0]
       c:      	stp	x24, x23, [sp, #0xf0]
      10:      	stp	x22, x21, [sp, #0x100]
      14:      	stp	x20, x19, [sp, #0x110]
      18:      	mov	w8, #0x23               // =35
      1c:      	mov	x29, x0
      20:      	blr	x8
      24:      	mov	x25, x0
      28:      	str	wzr, [sp, #0x3c]
      2c:      	adrp	x0, 0x0 <event_execve>
      30:      	ldrh	w19, [x29, #0x8]
      34:      	mov	w8, #0x1                // =1
      38:      	add	x9, sp, #0x3c
      3c:      	ldr	x0, [x0]
      40:      	add	x1, sp, #0x3c
      44:      	blr	x8
      48:      	cbz	x0, 0x28b0 <event_execve+0x28b0>
      4c:      	mov	w8, #0xe                // =14
      50:      	mov	x20, x0
      54:      	blr	x8
      58:      	mov	w8, #0x23               // =35
      5c:      	mov	x21, x0
      60:      	blr	x8
      64:      	str	x0, [sp, #0x40]
      68:      	add	x8, x0, #0x8e0
      6c:      	mov	w9, #0x8                // =8
      70:      	mov	w10, #0x71              // =113
      74:      	add	x11, sp, #0x40
      78:      	add	x0, sp, #0x40
      7c:      	mov	w1, #0x8                // =8
      80:      	ldr	x8, [sp, #0x40]
      84:      	add	x2, x8, #0x8e0
      88:      	blr	x10
      8c:      	ldr	x8, [sp, #0x40]
      90:      	cbz	x8, 0x340 <event_execve+0x340>
      94:      	add	x8, x8, #0x8d4
      98:      	mov	w9, #0x4                // =4
      9c:      	mov	w10, #0x71              // =113
      a0:      	add	x11, sp, #0xc8
      a4:      	ldr	x8, [sp, #0x40]
      a8:      	add	x0, sp, #0xc8
      ac:      	mov	w1, #0x4                // =4
      b0:      	add	x2, x8, #0x8d4
      b4:      	blr	x10
      b8:      	ldr	w8, [sp, #0xc8]
      bc:      	adrp	x23, 0x0 <event_execve>
      c0:      	add	x9, sp, #0xb8
      c4:      	add	x1, sp, #0xb8
      c8:      	str	w8, [sp, #0xb8]
      cc:      	mov	w8, #0x1                // =1
      d0:      	ldr	x23, [x23]
      d4:      	mov	x0, x23
      d8:      	blr	x8
      dc:      	cbz	x0, 0xec <event_execve+0xec>
      e0:      	ldr	x8, [x0, #0x8]
      e4:      	mov	x24, x0
      e8:      	cbnz	x8, 0x26c <event_execve+0x26c>
      ec:      	ldr	x8, [sp, #0x40]
      f0:      	mov	w9, #0x8                // =8
      f4:      	mov	w10, #0x71              // =113
      f8:      	add	x11, sp, #0x40
      fc:      	add	x0, sp, #0x40
     100:      	mov	w1, #0x8                // =8
     104:      	add	x8, x8, #0x8e0
     108:      	ldr	x8, [sp, #0x40]
     10c:      	add	x2, x8, #0x8e0
     110:      	blr	x10
     114:      	ldr	x8, [sp, #0x40]
     118:      	cbz	x8, 0x340 <event_execve+0x340>
     11c:      	add	x8, x8, #0x8d4
     120:      	mov	w9, #0x4                // =4
     124:      	mov	w10, #0x71              // =113
     128:      	add	x11, sp, #0xc8
     12c:      	ldr	x8, [sp, #0x40]
     130:      	add	x0, sp, #0xc8
     134:      	mov	w1, #0x4                // =4
     138:      	add	x2, x8, #0x8d4
     13c:      	blr	x10
     140:      	ldr	w8, [sp, #0xc8]
     144:      	add	x9, sp, #0xb8
     148:      	add	x1, sp, #0xb8
     14c:      	mov	x0, x23
     150:      	str	w8, [sp, #0xb8]
     154:      	mov	w8, #0x1                // =1
     158:      	blr	x8
     15c:      	cbz	x0, 0x16c <event_execve+0x16c>
     160:      	ldr	x8, [x0, #0x8]
     164:      	mov	x24, x0
     168:      	cbnz	x8, 0x26c <event_execve+0x26c>
     16c:      	ldr	x8, [sp, #0x40]
     170:      	mov	w9, #0x8                // =8
     174:      	mov	w10, #0x71              // =113
     178:      	add	x11, sp, #0x40
     17c:      	add	x0, sp, #0x40
     180:      	mov	w1, #0x8                // =8
     184:      	add	x8, x8, #0x8e0
     188:      	ldr	x8, [sp, #0x40]
     18c:      	add	x2, x8, #0x8e0
     190:      	blr	x10
     194:      	ldr	x8, [sp, #0x40]
     198:      	cbz	x8, 0x340 <event_execve+0x340>
     19c:      	add	x8, x8, #0x8d4
     1a0:      	mov	w9, #0x4                // =4
     1a4:      	mov	w10, #0x71              // =113
     1a8:      	add	x11, sp, #0xc8
     1ac:      	ldr	x8, [sp, #0x40]
     1b0:      	add	x0, sp, #0xc8
     1b4:      	mov	w1, #0x4                // =4
     1b8:      	add	x2, x8, #0x8d4
     1bc:      	blr	x10
     1c0:      	ldr	w8, [sp, #0xc8]
     1c4:      	add	x9, sp, #0xb8
     1c8:      	add	x1, sp, #0xb8
     1cc:      	mov	x0, x23
     1d0:      	str	w8, [sp, #0xb8]
     1d4:      	mov	w8, #0x1                // =1
     1d8:      	blr	x8
     1dc:      	cbz	x0, 0x1ec <event_execve+0x1ec>
     1e0:      	ldr	x8, [x0, #0x8]
     1e4:      	mov	x24, x0
     1e8:      	cbnz	x8, 0x26c <event_execve+0x26c>
     1ec:      	ldr	x8, [sp, #0x40]
     1f0:      	mov	w9, #0x8                // =8
     1f4:      	mov	w10, #0x71              // =113
     1f8:      	add	x11, sp, #0x40
     1fc:      	add	x0, sp, #0x40
     200:      	mov	w1, #0x8                // =8
     204:      	add	x8, x8, #0x8e0
     208:      	ldr	x8, [sp, #0x40]
     20c:      	add	x2, x8, #0x8e0
     210:      	blr	x10
     214:      	ldr	x8, [sp, #0x40]
     218:      	cbz	x8, 0x340 <event_execve+0x340>
     21c:      	add	x8, x8, #0x8d4
     220:      	mov	w9, #0x4                // =4
     224:      	mov	w10, #0x71              // =113
     228:      	add	x11, sp, #0xc8
     22c:      	ldr	x8, [sp, #0x40]
     230:      	add	x0, sp, #0xc8
     234:      	mov	w1, #0x4                // =4
     238:      	add	x2, x8, #0x8d4
     23c:      	blr	x10
     240:      	ldr	w8, [sp, #0xc8]
     244:      	add	x9, sp, #0xb8
     248:      	add	x1, sp, #0xb8
     24c:      	mov	x0, x23
     250:      	str	w8, [sp, #0xb8]
     254:      	mov	w8, #0x1                // =1
     258:      	blr	x8
     25c:      	cbz	x0, 0x340 <event_execve+0x340>
     260:      	ldr	x8, [x0, #0x8]
     264:      	mov	x24, x0
     268:      	cbz	x8, 0x340 <event_execve+0x340>
     26c:      	ldp	x8, x9, [x24]
     270:      	adrp	x0, 0x0 <event_execve>
     274:      	add	x1, sp, #0xb8
     278:      	str	wzr, [sp, #0xb8]
     27c:      	stp	x8, x9, [x20, #0xa0]
     280:      	mov	w8, #0x1                // =1
     284:      	add	x9, sp, #0xb8
     288:      	ldr	x0, [x0]
     28c:      	blr	x8
     290:      	cbz	x0, 0x418 <event_execve+0x418>
     294:      	ldr	x8, [x0]
     298:      	ldr	x9, [x24, #0x378]
     29c:      	cmp	x8, x9
     2a0:      	b.eq	0x418 <event_execve+0x418>
     2a4:      	stp	x19, x21, [sp, #0x18]
     2a8:      	adrp	x8, 0x0 <event_execve>
     2ac:      	str	x0, [sp, #0xd8]
     2b0:      	stp	x29, x25, [sp, #0x28]
     2b4:      	adrp	x25, 0x0 <event_execve>
     2b8:      	ldr	x8, [x8]
     2bc:      	ldrb	w8, [x8]
     2c0:      	ldr	x25, [x25]
     2c4:      	cbz	w8, 0x394 <event_execve+0x394>
     2c8:      	mov	w29, #0x869f            // =34463
     2cc:      	mov	x21, xzr
     2d0:      	add	x22, sp, #0x40
     2d4:      	movk	w29, #0x1, lsl #16
     2d8:      	b	0x2f4 <event_execve+0x2f4>
     2dc:      	nop
     2e0:      	cmp	x19, x21
     2e4:      	mov	x21, x19
     2e8:      	ccmp	w29, #0x0, #0x4, ne
     2ec:      	sub	w29, w29, #0x1
     2f0:      	b.eq	0x404 <event_execve+0x404>
     2f4:      	ldr	w8, [x24, #0x10]
     2f8:      	add	x1, sp, #0x40
     2fc:      	mov	x0, x23
     300:      	str	w8, [sp, #0x40]
     304:      	mov	w8, #0x1                // =1
     308:      	blr	x8
     30c:      	cbz	x0, 0x404 <event_execve+0x404>
     310:      	add	x1, x0, #0x70
     314:      	mov	w8, #0x1                // =1
     318:      	mov	x19, x0
     31c:      	mov	x0, x25
     320:      	blr	x8
     324:      	cbz	x0, 0x2e0 <event_execve+0x2e0>
     328:      	ldr	x8, [x0]
     32c:      	cbz	x8, 0x2e0 <event_execve+0x2e0>
     330:      	ldr	x9, [x24, #0x370]
     334:      	orr	x8, x9, x8
     338:      	str	x8, [x24, #0x370]
     33c:      	b	0x2e0 <event_execve+0x2e0>
     340:      	add	x2, x25, #0x8e0
     344:      	mov	w8, #0x8                // =8
     348:      	mov	w9, #0x71               // =113
     34c:      	add	x10, sp, #0x40
     350:      	add	x0, sp, #0x40
     354:      	mov	w1, #0x8                // =8
     358:      	blr	x9
     35c:      	ldr	x8, [sp, #0x40]
     360:      	cbz	x8, 0x384 <event_execve+0x384>
     364:      	add	x2, x8, #0x8d4
     368:      	mov	w8, #0x4                // =4
     36c:      	mov	w9, #0x71               // =113
     370:      	add	x10, sp, #0x40
     374:      	add	x0, sp, #0x40
     378:      	mov	w1, #0x4                // =4
     37c:      	blr	x9
     380:      	ldr	w8, [sp, #0x40]
     384:      	str	w8, [x20, #0xa0]
     388:      	mov	w8, #0x40               // =64
     38c:      	str	xzr, [x20, #0xa8]
     390:      	b	0x41c <event_execve+0x41c>
     394:      	mov	x29, xzr
     398:      	mov	w21, #0x3ff             // =1023
     39c:      	add	x22, sp, #0x40
     3a0:      	b	0x3b8 <event_execve+0x3b8>
     3a4:      	cmp	x19, x29
     3a8:      	mov	x29, x19
     3ac:      	ccmp	w21, #0x0, #0x4, ne
     3b0:      	sub	w21, w21, #0x1
     3b4:      	b.eq	0x404 <event_execve+0x404>
     3b8:      	ldr	w8, [x24, #0x10]
     3bc:      	add	x1, sp, #0x40
     3c0:      	mov	x0, x23
     3c4:      	str	w8, [sp, #0x40]
     3c8:      	mov	w8, #0x1                // =1
     3cc:      	blr	x8
     3d0:      	cbz	x0, 0x404 <event_execve+0x404>
     3d4:      	add	x1, x0, #0x70
     3d8:      	mov	w8, #0x1                // =1
     3dc:      	mov	x19, x0
     3e0:      	mov	x0, x25
     3e4:      	blr	x8
     3e8:      	cbz	x0, 0x3a4 <event_execve+0x3a4>
     3ec:      	ldr	x8, [x0]
     3f0:      	cbz	x8, 0x3a4 <event_execve+0x3a4>
     3f4:      	ldr	x9, [x24, #0x370]
     3f8:      	orr	x8, x9, x8
     3fc:      	str	x8, [x24, #0x370]
     400:      	b	0x3a4 <event_execve+0x3a4>
     404:      	ldr	x8, [sp, #0xd8]
     408:      	ldp	x29, x25, [sp, #0x28]
     40c:      	ldr	x8, [x8]
     410:      	ldp	x19, x21, [sp, #0x18]
     414:      	str	x8, [x24, #0x378]
     418:      	mov	x8, xzr
     41c:      	str	x8, [x20, #0xb0]
     420:      	mov	w8, #0x1                // =1
     424:      	str	xzr, [x20, #0x178]
     428:      	str	w21, [x20, #0x148]
     42c:      	str	w8, [x20, #0x15c]
     430:      	lsr	x8, x21, #32
     434:      	str	w8, [x20, #0x144]
     438:      	mov	w8, #0x23               // =35
     43c:      	blr	x8
     440:      	add	x2, x0, #0x60
     444:      	mov	w8, #0x8                // =8
     448:      	mov	w9, #0x71               // =113
     44c:      	add	x10, sp, #0xb8
     450:      	add	x0, sp, #0xb8
     454:      	mov	w1, #0x8                // =8
     458:      	blr	x9
     45c:      	ldr	x8, [sp, #0xb8]
     460:      	cbz	x8, 0x4d0 <event_execve+0x4d0>
     464:      	add	x8, x8, #0x4
     468:      	mov	w9, #0x4                // =4
     46c:      	mov	w10, #0x71              // =113
     470:      	add	x11, sp, #0xc8
     474:      	ldr	x8, [sp, #0xb8]
     478:      	add	x0, sp, #0xc8
     47c:      	mov	w1, #0x4                // =4
     480:      	add	x2, x8, #0x4
     484:      	blr	x10
     488:      	ldr	w8, [sp, #0xc8]
     48c:      	cbz	w8, 0x4d0 <event_execve+0x4d0>
     490:      	ldr	x9, [sp, #0xb8]
     494:      	lsl	w8, w8, #4
     498:      	mov	w10, #0x71              // =113
     49c:      	add	x11, sp, #0x40
     4a0:      	add	x0, sp, #0x40
     4a4:      	mov	w1, #0x10               // =16
     4a8:      	add	x8, x9, x8
     4ac:      	mov	w9, #0x10               // =16
     4b0:      	add	x8, x8, #0x80
     4b4:      	ldr	w9, [sp, #0xc8]
     4b8:      	ldr	x8, [sp, #0xb8]
     4bc:      	lsl	w9, w9, #4
     4c0:      	add	x8, x8, x9
     4c4:      	add	x2, x8, #0x80
     4c8:      	blr	x10
     4cc:      	ldr	w8, [sp, #0x40]
     4d0:      	str	w8, [x20, #0x14c]
     4d4:      	mov	w8, #0x7d               // =125
     4d8:      	add	x23, x29, x19
     4dc:      	blr	x8
     4e0:      	mov	w8, #0x40               // =64
     4e4:      	str	x0, [x20, #0x170]
     4e8:      	str	w8, [x20, #0x140]
     4ec:      	mov	w8, #0x23               // =35
     4f0:      	blr	x8
     4f4:      	str	xzr, [sp, #0x40]
     4f8:      	cbz	x0, 0x520 <event_execve+0x520>
     4fc:      	add	x2, x0, #0x70
     500:      	mov	w8, #0x8                // =8
     504:      	mov	w9, #0x4                // =4
     508:      	add	x10, sp, #0x40
     50c:      	add	x0, sp, #0x40
     510:      	mov	w1, #0x8                // =8
     514:      	blr	x9
     518:      	ldr	x8, [sp, #0x40]
     51c:      	b	0x524 <event_execve+0x524>
     520:      	mov	x8, xzr
     524:      	str	w8, [x20, #0x158]
     528:      	str	x21, [sp, #0x40]
     52c:      	adrp	x19, 0x0 <event_execve>
     530:      	mov	w8, #0x1                // =1
     534:      	add	x9, sp, #0x40
     538:      	add	x1, sp, #0x40
     53c:      	ldr	x19, [x19]
     540:      	mov	x0, x19
     544:      	blr	x8
     548:      	cbz	x0, 0x5b4 <event_execve+0x5b4>
     54c:      	ldr	w8, [x0]
     550:      	add	x9, sp, #0x40
     554:      	add	x1, sp, #0x40
     558:      	str	w8, [x20, #0x150]
     55c:      	ldr	x8, [x0, #0x8]
     560:      	str	x8, [x20, #0x168]
     564:      	ldr	w8, [x0, #0x4]
     568:      	str	x21, [sp, #0x40]
     56c:      	mov	x0, x19
     570:      	str	w8, [x20, #0x160]
     574:      	mov	w8, #0x3                // =3
     578:      	blr	x8
     57c:      	mov	x8, x0
     580:      	adrp	x0, 0x0 <event_execve>
     584:      	ldr	x0, [x0]
     588:      	cbz	w8, 0x5c4 <event_execve+0x5c4>
     58c:      	mov	w8, #0x2                // =2
     590:      	add	x9, sp, #0xb8
     594:      	add	x1, sp, #0xb8
     598:      	str	w8, [sp, #0xb8]
     59c:      	mov	w8, #0x1                // =1
     5a0:      	blr	x8
     5a4:      	cbz	x0, 0x5e8 <event_execve+0x5e8>
     5a8:      	ldr	x8, [x0]
     5ac:      	add	x8, x8, #0x1
     5b0:      	b	0x5e4 <event_execve+0x5e4>
     5b4:      	str	wzr, [x20, #0x150]
     5b8:      	str	xzr, [x20, #0x168]
     5bc:      	str	wzr, [x20, #0x160]
     5c0:      	b	0x5e8 <event_execve+0x5e8>
     5c4:      	str	wzr, [sp, #0xb8]
     5c8:      	mov	w8, #0x1                // =1
     5cc:      	add	x9, sp, #0xb8
     5d0:      	add	x1, sp, #0xb8
     5d4:      	blr	x8
     5d8:      	cbz	x0, 0x5e8 <event_execve+0x5e8>
     5dc:      	ldr	x8, [x0]
     5e0:      	sub	x8, x8, #0x1
     5e4:      	str	x8, [x0]
     5e8:      	add	x0, x20, #0x180
     5ec:      	mov	w8, #0xff               // =255
     5f0:      	mov	w9, #0x2d               // =45
     5f4:      	mov	w1, #0xff               // =255
     5f8:      	mov	x2, x23
     5fc:      	blr	x9
     600:      	tbnz	w0, #0x1f, 0x76c <event_execve+0x76c>
     604:      	cbz	w0, 0x778 <event_execve+0x778>
     608:      	cmp	w0, #0xff
     60c:      	b.ne	0x780 <event_execve+0x780>
     610:      	str	wzr, [sp, #0xc8]
     614:      	adrp	x0, 0x0 <event_execve>
     618:      	mov	w8, #0x1                // =1
     61c:      	add	x9, sp, #0xc8
     620:      	ldr	x0, [x0]
     624:      	add	x1, sp, #0xc8
     628:      	blr	x8
     62c:      	cbz	x0, 0x76c <event_execve+0x76c>
     630:      	mov	w8, #0x18               // =24
     634:      	mov	x24, x0
     638:      	mov	x21, x25
     63c:      	str	w8, [x0]
     640:      	mov	w8, #0xe                // =14
     644:      	blr	x8
     648:      	mov	x19, x24
     64c:      	cmn	x0, #0x16
     650:      	str	x0, [x19, #0x10]!
     654:      	b.ne	0x67c <event_execve+0x67c>
     658:      	add	x2, x29, #0xe8
     65c:      	mov	w8, #0x8                // =8
     660:      	mov	w9, #0x4                // =4
     664:      	add	x10, sp, #0x40
     668:      	add	x0, sp, #0x40
     66c:      	mov	w1, #0x8                // =8
     670:      	blr	x9
     674:      	ldr	x8, [sp, #0x40]
     678:      	str	x8, [x19]
     67c:      	mov	w8, #0x7d               // =125
     680:      	blr	x8
     684:      	str	x0, [x24, #0x18]
     688:      	add	x25, x24, #0x20
     68c:      	mov	w1, #0x7fdf             // =32735
     690:      	mov	x2, x23
     694:      	ldp	x8, x9, [x19]
     698:      	mov	x0, x25
     69c:      	stp	x8, x9, [x20, #0x190]
     6a0:      	mov	w8, #0x7fdf             // =32735
     6a4:      	mov	w9, #0x2d               // =45
     6a8:      	blr	x9
     6ac:      	tbnz	x0, #0x3f, 0xac8 <event_execve+0xac8>
     6b0:      	cbz	x0, 0x7fc <event_execve+0x7fc>
     6b4:      	sub	x8, x0, #0x1
     6b8:      	mov	x22, x0
     6bc:      	str	wzr, [sp, #0xb8]
     6c0:      	add	x9, sp, #0xb8
     6c4:      	str	x8, [sp, #0xd8]
     6c8:      	add	w8, w0, #0x1f
     6cc:      	adrp	x0, 0x0 <event_execve>
     6d0:      	add	x1, sp, #0xb8
     6d4:      	and	x19, x8, #0x7fff
     6d8:      	mov	w8, #0x1                // =1
     6dc:      	str	w19, [x24, #0x4]
     6e0:      	ldr	x0, [x0]
     6e4:      	blr	x8
     6e8:      	cbz	x0, 0x78c <event_execve+0x78c>
     6ec:      	ldrb	w8, [x0, #0x28]
     6f0:      	cbz	w8, 0x78c <event_execve+0x78c>
     6f4:      	adrp	x1, 0x0 <event_execve>
     6f8:      	mov	w8, #-0x1               // =-1
     6fc:      	mov	w9, #0x19               // =25
     700:      	ldr	x1, [x1]
     704:      	mov	x0, x29
     708:      	mov	w2, #-0x1               // =-1
     70c:      	mov	x3, x24
     710:      	mov	x4, x19
     714:      	blr	x9
     718:      	tbz	x0, #0x3f, 0x8b4 <event_execve+0x8b4>
     71c:      	mov	x19, x0
     720:      	str	wzr, [sp, #0x40]
     724:      	adrp	x0, 0x0 <event_execve>
     728:      	mov	w8, #0x1                // =1
     72c:      	ldr	x0, [x0]
     730:      	add	x9, sp, #0x40
     734:      	add	x1, sp, #0x40
     738:      	blr	x8
     73c:      	cbz	x0, 0x8b4 <event_execve+0x8b4>
     740:      	mov	x8, x19
     744:      	cmn	x19, #0xc
     748:      	b.gt	0x828 <event_execve+0x828>
     74c:      	cmn	x8, #0x1c
     750:      	b.eq	0x880 <event_execve+0x880>
     754:      	cmn	x8, #0x16
     758:      	b.eq	0x898 <event_execve+0x898>
     75c:      	cmn	x8, #0x10
     760:      	b.ne	0x890 <event_execve+0x890>
     764:      	add	x8, x0, #0x558
     768:      	b	0x8a4 <event_execve+0x8a4>
     76c:      	mov	w8, wzr
     770:      	mov	w0, #0x100              // =256
     774:      	b	0xaf0 <event_execve+0xaf0>
     778:      	mov	w8, w0
     77c:      	b	0xaf0 <event_execve+0xaf0>
     780:      	sub	w8, w0, #0x1
     784:      	mov	w0, wzr
     788:      	b	0xaf0 <event_execve+0xaf0>
     78c:      	adrp	x0, 0x0 <event_execve>
     790:      	mov	x3, xzr
     794:      	mov	w8, #0x82               // =130
     798:      	ldr	x0, [x0]
     79c:      	mov	x1, x24
     7a0:      	mov	x2, x19
     7a4:      	blr	x8
     7a8:      	tbz	x0, #0x3f, 0x8b4 <event_execve+0x8b4>
     7ac:      	mov	x19, x0
     7b0:      	str	wzr, [sp, #0x40]
     7b4:      	adrp	x0, 0x0 <event_execve>
     7b8:      	mov	w8, #0x1                // =1
     7bc:      	ldr	x0, [x0]
     7c0:      	add	x9, sp, #0x40
     7c4:      	add	x1, sp, #0x40
     7c8:      	blr	x8
     7cc:      	cbz	x0, 0x8b4 <event_execve+0x8b4>
     7d0:      	mov	x8, x19
     7d4:      	cmn	x19, #0xc
     7d8:      	b.gt	0x808 <event_execve+0x808>
     7dc:      	cmn	x8, #0x1c
     7e0:      	b.eq	0x848 <event_execve+0x848>
     7e4:      	cmn	x8, #0x16
     7e8:      	b.eq	0x860 <event_execve+0x860>
     7ec:      	cmn	x8, #0x10
     7f0:      	b.ne	0x858 <event_execve+0x858>
     7f4:      	add	x8, x0, #0x558
     7f8:      	b	0x86c <event_execve+0x86c>
     7fc:      	mov	w8, wzr
     800:      	mov	w9, wzr
     804:      	b	0xad4 <event_execve+0xad4>
     808:      	cmn	x8, #0xb
     80c:      	b.eq	0x850 <event_execve+0x850>
     810:      	cmn	x8, #0x7
     814:      	b.eq	0x868 <event_execve+0x868>
     818:      	cmn	x8, #0x2
     81c:      	b.ne	0x858 <event_execve+0x858>
     820:      	add	x8, x0, #0x548
     824:      	b	0x86c <event_execve+0x86c>
     828:      	cmn	x8, #0xb
     82c:      	b.eq	0x888 <event_execve+0x888>
     830:      	cmn	x8, #0x7
     834:      	b.eq	0x8a0 <event_execve+0x8a0>
     838:      	cmn	x8, #0x2
     83c:      	b.ne	0x890 <event_execve+0x890>
     840:      	add	x8, x0, #0x548
     844:      	b	0x8a4 <event_execve+0x8a4>
     848:      	add	x8, x0, #0x568
     84c:      	b	0x86c <event_execve+0x86c>
     850:      	add	x8, x0, #0x570
     854:      	b	0x86c <event_execve+0x86c>
     858:      	add	x8, x0, #0x540
     85c:      	b	0x86c <event_execve+0x86c>
     860:      	add	x8, x0, #0x560
     864:      	b	0x86c <event_execve+0x86c>
     868:      	add	x8, x0, #0x550
     86c:      	ldaxr	x9, [x8]
     870:      	add	x9, x9, #0x1
     874:      	stlxr	w10, x9, [x8]
     878:      	cbnz	w10, 0x86c <event_execve+0x86c>
     87c:      	b	0x8b4 <event_execve+0x8b4>
     880:      	add	x8, x0, #0x568
     884:      	b	0x8a4 <event_execve+0x8a4>
     888:      	add	x8, x0, #0x570
     88c:      	b	0x8a4 <event_execve+0x8a4>
     890:      	add	x8, x0, #0x540
     894:      	b	0x8a4 <event_execve+0x8a4>
     898:      	add	x8, x0, #0x560
     89c:      	b	0x8a4 <event_execve+0x8a4>
     8a0:      	add	x8, x0, #0x550
     8a4:      	ldaxr	x9, [x8]
     8a8:      	add	x9, x9, #0x1
     8ac:      	stlxr	w10, x9, [x8]
     8b0:      	cbnz	w10, 0x8a4 <event_execve+0x8a4>
     8b4:      	mov	w8, #0x7fdf             // =32735
     8b8:      	cmp	x22, x8
     8bc:      	ldr	x8, [sp, #0xd8]
     8c0:      	mov	x0, x8
     8c4:      	b.ne	0xac8 <event_execve+0xac8>
     8c8:      	add	x2, x8, x23
     8cc:      	mov	w8, #0x7fdf             // =32735
     8d0:      	mov	w9, #0x2d               // =45
     8d4:      	mov	x0, x25
     8d8:      	mov	w1, #0x7fdf             // =32735
     8dc:      	blr	x9
     8e0:      	tbnz	x0, #0x3f, 0xac8 <event_execve+0xac8>
     8e4:      	cbz	x0, 0xa08 <event_execve+0xa08>
     8e8:      	add	w8, w0, #0x1f
     8ec:      	sub	x22, x0, #0x1
     8f0:      	str	wzr, [sp, #0xb8]
     8f4:      	adrp	x0, 0x0 <event_execve>
     8f8:      	add	x9, sp, #0xb8
     8fc:      	add	x1, sp, #0xb8
     900:      	and	x19, x8, #0x7fff
     904:      	str	w19, [x24, #0x4]
     908:      	mov	w8, #0x1                // =1
     90c:      	ldr	x0, [x0]
     910:      	blr	x8
     914:      	cbz	x0, 0x998 <event_execve+0x998>
     918:      	ldrb	w8, [x0, #0x28]
     91c:      	cbz	w8, 0x998 <event_execve+0x998>
     920:      	adrp	x1, 0x0 <event_execve>
     924:      	mov	w8, #-0x1               // =-1
     928:      	mov	w9, #0x19               // =25
     92c:      	ldr	x1, [x1]
     930:      	mov	x0, x29
     934:      	mov	w2, #-0x1               // =-1
     938:      	mov	x3, x24
     93c:      	mov	x4, x19
     940:      	blr	x9
     944:      	tbz	x0, #0x3f, 0xac0 <event_execve+0xac0>
     948:      	mov	x19, x0
     94c:      	str	wzr, [sp, #0x40]
     950:      	adrp	x0, 0x0 <event_execve>
     954:      	mov	w8, #0x1                // =1
     958:      	ldr	x0, [x0]
     95c:      	add	x9, sp, #0x40
     960:      	add	x1, sp, #0x40
     964:      	blr	x8
     968:      	cbz	x0, 0xac0 <event_execve+0xac0>
     96c:      	mov	x8, x19
     970:      	cmn	x19, #0xc
     974:      	b.gt	0xa34 <event_execve+0xa34>
     978:      	cmn	x8, #0x1c
     97c:      	b.eq	0xa8c <event_execve+0xa8c>
     980:      	cmn	x8, #0x16
     984:      	b.eq	0xaa4 <event_execve+0xaa4>
     988:      	cmn	x8, #0x10
     98c:      	b.ne	0xa9c <event_execve+0xa9c>
     990:      	add	x8, x0, #0x558
     994:      	b	0xab0 <event_execve+0xab0>
     998:      	adrp	x0, 0x0 <event_execve>
     99c:      	mov	x3, xzr
     9a0:      	mov	w8, #0x82               // =130
     9a4:      	ldr	x0, [x0]
     9a8:      	mov	x1, x24
     9ac:      	mov	x2, x19
     9b0:      	blr	x8
     9b4:      	tbz	x0, #0x3f, 0xac0 <event_execve+0xac0>
     9b8:      	mov	x19, x0
     9bc:      	str	wzr, [sp, #0x40]
     9c0:      	adrp	x0, 0x0 <event_execve>
     9c4:      	mov	w8, #0x1                // =1
     9c8:      	ldr	x0, [x0]
     9cc:      	add	x9, sp, #0x40
     9d0:      	add	x1, sp, #0x40
     9d4:      	blr	x8
     9d8:      	cbz	x0, 0xac0 <event_execve+0xac0>
     9dc:      	mov	x8, x19
     9e0:      	cmn	x19, #0xc
     9e4:      	b.gt	0xa14 <event_execve+0xa14>
     9e8:      	cmn	x8, #0x1c
     9ec:      	b.eq	0xa54 <event_execve+0xa54>
     9f0:      	cmn	x8, #0x16
     9f4:      	b.eq	0xa6c <event_execve+0xa6c>
     9f8:      	cmn	x8, #0x10
     9fc:      	b.ne	0xa64 <event_execve+0xa64>
     a00:      	add	x8, x0, #0x558
     a04:      	b	0xa78 <event_execve+0xa78>
     a08:      	mov	w8, wzr
     a0c:      	mov	w9, #0x7fde             // =32734
     a10:      	b	0xad4 <event_execve+0xad4>
     a14:      	cmn	x8, #0xb
     a18:      	b.eq	0xa5c <event_execve+0xa5c>
     a1c:      	cmn	x8, #0x7
     a20:      	b.eq	0xa74 <event_execve+0xa74>
     a24:      	cmn	x8, #0x2
     a28:      	b.ne	0xa64 <event_execve+0xa64>
     a2c:      	add	x8, x0, #0x548
     a30:      	b	0xa78 <event_execve+0xa78>
     a34:      	cmn	x8, #0xb
     a38:      	b.eq	0xa94 <event_execve+0xa94>
     a3c:      	cmn	x8, #0x7
     a40:      	b.eq	0xaac <event_execve+0xaac>
     a44:      	cmn	x8, #0x2
     a48:      	b.ne	0xa9c <event_execve+0xa9c>
     a4c:      	add	x8, x0, #0x548
     a50:      	b	0xab0 <event_execve+0xab0>
     a54:      	add	x8, x0, #0x568
     a58:      	b	0xa78 <event_execve+0xa78>
     a5c:      	add	x8, x0, #0x570
     a60:      	b	0xa78 <event_execve+0xa78>
     a64:      	add	x8, x0, #0x540
     a68:      	b	0xa78 <event_execve+0xa78>
     a6c:      	add	x8, x0, #0x560
     a70:      	b	0xa78 <event_execve+0xa78>
     a74:      	add	x8, x0, #0x550
     a78:      	ldaxr	x9, [x8]
     a7c:      	add	x9, x9, #0x1
     a80:      	stlxr	w10, x9, [x8]
     a84:      	cbnz	w10, 0xa78 <event_execve+0xa78>
     a88:      	b	0xac0 <event_execve+0xac0>
     a8c:      	add	x8, x0, #0x568
     a90:      	b	0xab0 <event_execve+0xab0>
     a94:      	add	x8, x0, #0x570
     a98:      	b	0xab0 <event_execve+0xab0>
     a9c:      	add	x8, x0, #0x540
     aa0:      	b	0xab0 <event_execve+0xab0>
     aa4:      	add	x8, x0, #0x560
     aa8:      	b	0xab0 <event_execve+0xab0>
     aac:      	add	x8, x0, #0x550
     ab0:      	ldaxr	x9, [x8]
     ab4:      	add	x9, x9, #0x1
     ab8:      	stlxr	w10, x9, [x8]
     abc:      	cbnz	w10, 0xab0 <event_execve+0xab0>
     ac0:      	ldr	x8, [sp, #0xd8]
     ac4:      	add	x0, x22, x8
     ac8:      	asr	w9, w0, #31
     acc:      	and	w8, w0, w9
     ad0:      	bic	w9, w0, w9
     ad4:      	str	w8, [x20, #0x180]
     ad8:      	add	x8, x20, #0x184
     adc:      	str	w9, [x20, #0x18c]
     ae0:      	mov	w0, #0x800000           // =8388608
     ae4:      	mov	x25, x21
     ae8:      	str	xzr, [x8]
     aec:      	mov	w8, #0x20               // =32
     af0:      	ldr	w9, [x20, #0x15c]
     af4:      	strh	w8, [x20, #0x178]
     af8:      	orr	w9, w9, w0
     afc:      	str	w9, [x20, #0x15c]
     b00:      	ldr	w9, [x20, #0x140]
     b04:      	add	w8, w9, w8
     b08:      	str	w8, [x20, #0x140]
     b0c:      	mov	w8, #0x23               // =35
     b10:      	blr	x8
     b14:      	str	wzr, [sp, #0xa0]
     b18:      	add	x2, x0, #0x858
     b1c:      	mov	w8, #0x8                // =8
     b20:      	mov	w9, #0x4                // =4
     b24:      	add	x10, sp, #0xb0
     b28:      	add	x0, sp, #0xb0
     b2c:      	mov	w1, #0x8                // =8
     b30:      	blr	x9
     b34:      	adrp	x22, 0x0 <event_execve>
     b38:      	ldr	x22, [x22]
     b3c:      	cbz	x0, 0xb84 <event_execve+0xb84>
     b40:      	neg	w8, w0
     b44:      	mov	w9, #0x1                // =1
     b48:      	add	x1, sp, #0x40
     b4c:      	strh	w8, [sp, #0x40]
     b50:      	mov	w8, #0x9                // =9
     b54:      	mov	x0, x22
     b58:      	mov	w19, #0x1               // =1
     b5c:      	strh	w8, [sp, #0x42]
     b60:      	mov	x8, #0x42               // =66
     b64:      	movk	x8, #0x4, lsl #32
     b68:      	stur	x8, [sp, #0x44]
     b6c:      	add	x8, sp, #0x40
     b70:      	blr	x9
     b74:      	cbz	x0, 0xc04 <event_execve+0xc04>
     b78:      	ldr	w8, [x0]
     b7c:      	add	w8, w8, #0x1
     b80:      	str	w8, [x0]
     b84:      	ldr	x8, [sp, #0xb0]
     b88:      	add	x21, x20, #0x140
     b8c:      	add	x24, sp, #0xb8
     b90:      	cbz	x8, 0xdd4 <event_execve+0xdd4>
     b94:      	add	x8, x8, #0x278
     b98:      	mov	w9, #0x8                // =8
     b9c:      	mov	w10, #0x4               // =4
     ba0:      	add	x11, sp, #0xb8
     ba4:      	ldr	x8, [sp, #0xb0]
     ba8:      	add	x0, sp, #0xb8
     bac:      	mov	w1, #0x8                // =8
     bb0:      	add	x2, x8, #0x278
     bb4:      	blr	x10
     bb8:      	cbz	x0, 0xc60 <event_execve+0xc60>
     bbc:      	neg	w8, w0
     bc0:      	mov	w9, #0x1                // =1
     bc4:      	add	x1, sp, #0x40
     bc8:      	strh	w8, [sp, #0x40]
     bcc:      	mov	w8, #0x9                // =9
     bd0:      	mov	x0, x22
     bd4:      	mov	w19, #0x1               // =1
     bd8:      	strh	w8, [sp, #0x42]
     bdc:      	mov	x8, #0x47               // =71
     be0:      	movk	x8, #0x4, lsl #32
     be4:      	stur	x8, [sp, #0x44]
     be8:      	add	x8, sp, #0x40
     bec:      	blr	x9
     bf0:      	cbz	x0, 0xc3c <event_execve+0xc3c>
     bf4:      	ldr	w8, [x0]
     bf8:      	add	w8, w8, #0x1
     bfc:      	str	w8, [x0]
     c00:      	b	0xc60 <event_execve+0xc60>
     c04:      	str	w19, [sp, #0xb8]
     c08:      	mov	x3, xzr
     c0c:      	mov	w8, #0x2                // =2
     c10:      	add	x9, sp, #0x40
     c14:      	add	x10, sp, #0xb8
     c18:      	add	x1, sp, #0x40
     c1c:      	add	x2, sp, #0xb8
     c20:      	mov	x0, x22
     c24:      	blr	x8
     c28:      	ldr	x8, [sp, #0xb0]
     c2c:      	add	x21, x20, #0x140
     c30:      	add	x24, sp, #0xb8
     c34:      	cbnz	x8, 0xb94 <event_execve+0xb94>
     c38:      	b	0xdd4 <event_execve+0xdd4>
     c3c:      	str	w19, [sp, #0xc8]
     c40:      	mov	x3, xzr
     c44:      	mov	w8, #0x2                // =2
     c48:      	add	x9, sp, #0x40
     c4c:      	add	x10, sp, #0xc8
     c50:      	add	x1, sp, #0x40
     c54:      	add	x2, sp, #0xc8
     c58:      	mov	x0, x22
     c5c:      	blr	x8
     c60:      	ldr	x8, [sp, #0xb0]
     c64:      	mov	w9, #0x8                // =8
     c68:      	mov	w10, #0x4               // =4
     c6c:      	add	x11, sp, #0xc8
     c70:      	add	x0, sp, #0xc8
     c74:      	mov	w1, #0x8                // =8
     c78:      	add	x8, x8, #0x280
     c7c:      	ldr	x8, [sp, #0xb0]
     c80:      	add	x2, x8, #0x280
     c84:      	blr	x10
     c88:      	cbz	x0, 0xcd0 <event_execve+0xcd0>
     c8c:      	neg	w8, w0
     c90:      	mov	w9, #0x1                // =1
     c94:      	add	x1, sp, #0x40
     c98:      	strh	w8, [sp, #0x40]
     c9c:      	mov	w8, #0x9                // =9
     ca0:      	mov	x0, x22
     ca4:      	mov	w19, #0x1               // =1
     ca8:      	strh	w8, [sp, #0x42]
     cac:      	mov	x8, #0x48               // =72
     cb0:      	movk	x8, #0x4, lsl #32
     cb4:      	stur	x8, [sp, #0x44]
     cb8:      	add	x8, sp, #0x40
     cbc:      	blr	x9
     cc0:      	cbz	x0, 0xdf4 <event_execve+0xdf4>
     cc4:      	ldr	w8, [x0]
     cc8:      	add	w8, w8, #0x1
     ccc:      	str	w8, [x0]
     cd0:      	ldr	x8, [sp, #0xb8]
     cd4:      	mov	w19, wzr
     cd8:      	cbz	x8, 0xe2c <event_execve+0xe2c>
     cdc:      	ldr	x8, [x24, #0x10]
     ce0:      	cbz	x8, 0xe2c <event_execve+0xe2c>
     ce4:      	adrp	x0, 0x0 <event_execve>
     ce8:      	mov	w8, #0x1                // =1
     cec:      	add	x9, sp, #0xa0
     cf0:      	ldr	x0, [x0]
     cf4:      	add	x1, sp, #0xa0
     cf8:      	blr	x8
     cfc:      	cbz	x0, 0xdd4 <event_execve+0xdd4>
     d00:      	ldr	x8, [sp, #0xb8]
     d04:      	mov	w9, #0x1000             // =4096
     d08:      	mov	w10, #0x2d              // =45
     d0c:      	mov	w1, #0x1000             // =4096
     d10:      	ldr	x2, [sp, #0xb8]
     d14:      	blr	x10
     d18:      	tbnz	x0, #0x3f, 0xe28 <event_execve+0xe28>
     d1c:      	ldr	x8, [sp, #0xb8]
     d20:      	add	x23, x8, x0
     d24:      	ldr	w8, [x20, #0x140]
     d28:      	str	x23, [sp, #0xb8]
     d2c:      	and	x8, x8, #0x1ff
     d30:      	add	x10, x20, x8
     d34:      	str	w8, [x20, #0x184c]
     d38:      	ldr	x8, [x24, #0x10]
     d3c:      	sub	x22, x8, x23
     d40:      	cmp	x22, #0x3ff
     d44:      	b.hi	0x14b8 <event_execve+0x14b8>
     d48:      	add	x9, x20, #0x140
     d4c:      	add	x0, x10, #0x140
     d50:      	sub	x9, x9, x0
     d54:      	add	x9, x9, #0x400
     d58:      	cmp	x22, x9
     d5c:      	b.hs	0x14b8 <event_execve+0x14b8>
     d60:      	sub	w9, w22, #0x1
     d64:      	cmp	x8, x23
     d68:      	mov	w8, #0x4                // =4
     d6c:      	and	w9, w9, #0x3ff
     d70:      	csel	w19, wzr, w9, eq
     d74:      	ldr	x2, [sp, #0xb8]
     d78:      	mov	w1, w19
     d7c:      	blr	x8
     d80:      	cbz	x0, 0x177c <event_execve+0x177c>
     d84:      	mov	x22, x0
     d88:      	adrp	x23, 0x0 <event_execve>
     d8c:      	mov	w9, #0x1                // =1
     d90:      	add	x1, sp, #0x40
     d94:      	neg	w8, w22
     d98:      	strh	w8, [sp, #0x40]
     d9c:      	mov	w8, #0x9                // =9
     da0:      	strh	w8, [sp, #0x42]
     da4:      	mov	x8, #0x6c               // =108
     da8:      	movk	x8, #0x4, lsl #32
     dac:      	stur	x8, [sp, #0x44]
     db0:      	add	x8, sp, #0x40
     db4:      	ldr	x23, [x23]
     db8:      	mov	x0, x23
     dbc:      	blr	x9
     dc0:      	cbz	x0, 0x163c <event_execve+0x163c>
     dc4:      	ldr	w8, [x0]
     dc8:      	add	w8, w8, #0x1
     dcc:      	str	w8, [x0]
     dd0:      	b	0x1664 <event_execve+0x1664>
     dd4:      	mov	w19, wzr
     dd8:      	ldr	w8, [x20, #0x140]
     ddc:      	add	w9, w8, w19
     de0:      	ldrb	w8, [x20, #0x15d]
     de4:      	str	w9, [x20, #0x140]
     de8:      	tbz	w8, #0x5, 0xe40 <event_execve+0xe40>
     dec:      	mov	w8, wzr
     df0:      	b	0x1dac <event_execve+0x1dac>
     df4:      	str	w19, [sp, #0xa8]
     df8:      	mov	x3, xzr
     dfc:      	mov	w8, #0x2                // =2
     e00:      	add	x9, sp, #0x40
     e04:      	add	x10, sp, #0xa8
     e08:      	add	x1, sp, #0x40
     e0c:      	add	x2, sp, #0xa8
     e10:      	mov	x0, x22
     e14:      	blr	x8
     e18:      	ldr	x8, [sp, #0xb8]
     e1c:      	mov	w19, wzr
     e20:      	cbnz	x8, 0xcdc <event_execve+0xcdc>
     e24:      	b	0xe2c <event_execve+0xe2c>
     e28:      	mov	w19, wzr
     e2c:      	ldr	w8, [x20, #0x140]
     e30:      	add	w9, w8, w19
     e34:      	ldrb	w8, [x20, #0x15d]
     e38:      	str	w9, [x20, #0x140]
     e3c:      	tbnz	w8, #0x5, 0xdec <event_execve+0xdec>
     e40:      	str	w9, [sp, #0x18]
     e44:      	ldr	w19, [x20, #0x144]
     e48:      	mov	w8, #0x23               // =35
     e4c:      	blr	x8
     e50:      	mov	x24, x0
     e54:      	str	wzr, [sp, #0xb8]
     e58:      	str	x21, [sp, #0xd8]
     e5c:      	cbz	x0, 0x17ac <event_execve+0x17ac>
     e60:      	add	x2, x24, #0x8d4
     e64:      	mov	w8, #0x4                // =4
     e68:      	mov	w9, #0x71               // =113
     e6c:      	add	x10, sp, #0xb8
     e70:      	add	x0, sp, #0xb8
     e74:      	mov	w1, #0x4                // =4
     e78:      	blr	x9
     e7c:      	ldr	w8, [sp, #0xb8]
     e80:      	cmp	w8, w19
     e84:      	b.eq	0x17ac <event_execve+0x17ac>
     e88:      	add	x2, x24, #0x8e0
     e8c:      	mov	w8, #0x8                // =8
     e90:      	mov	w9, #0x71               // =113
     e94:      	add	x10, sp, #0x40
     e98:      	add	x0, sp, #0x40
     e9c:      	mov	w1, #0x8                // =8
     ea0:      	blr	x9
     ea4:      	ldr	x24, [sp, #0x40]
     ea8:      	cbz	x24, 0x17ac <event_execve+0x17ac>
     eac:      	add	x2, x24, #0x8d4
     eb0:      	mov	w8, #0x4                // =4
     eb4:      	mov	w9, #0x71               // =113
     eb8:      	add	x10, sp, #0xb8
     ebc:      	add	x0, sp, #0xb8
     ec0:      	mov	w1, #0x4                // =4
     ec4:      	blr	x9
     ec8:      	ldr	w8, [sp, #0xb8]
     ecc:      	cmp	w8, w19
     ed0:      	b.eq	0x17ac <event_execve+0x17ac>
     ed4:      	add	x2, x24, #0x8e0
     ed8:      	mov	w8, #0x8                // =8
     edc:      	mov	w9, #0x71               // =113
     ee0:      	add	x10, sp, #0x40
     ee4:      	add	x0, sp, #0x40
     ee8:      	mov	w1, #0x8                // =8
     eec:      	blr	x9
     ef0:      	ldr	x24, [sp, #0x40]
     ef4:      	cbz	x24, 0x17ac <event_execve+0x17ac>
     ef8:      	add	x2, x24, #0x8d4
     efc:      	mov	w8, #0x4                // =4
     f00:      	mov	w9, #0x71               // =113
     f04:      	add	x10, sp, #0xb8
     f08:      	add	x0, sp, #0xb8
     f0c:      	mov	w1, #0x4                // =4
     f10:      	blr	x9
     f14:      	ldr	w8, [sp, #0xb8]
     f18:      	cmp	w8, w19
     f1c:      	b.eq	0x17ac <event_execve+0x17ac>
     f20:      	add	x2, x24, #0x8e0
     f24:      	mov	w8, #0x8                // =8
     f28:      	mov	w9, #0x71               // =113
     f2c:      	add	x10, sp, #0x40
     f30:      	add	x0, sp, #0x40
     f34:      	mov	w1, #0x8                // =8
     f38:      	blr	x9
     f3c:      	ldr	x24, [sp, #0x40]
     f40:      	cbz	x24, 0x17ac <event_execve+0x17ac>
     f44:      	add	x2, x24, #0x8d4
     f48:      	mov	w8, #0x4                // =4
     f4c:      	mov	w9, #0x71               // =113
     f50:      	add	x10, sp, #0xb8
     f54:      	add	x0, sp, #0xb8
     f58:      	mov	w1, #0x4                // =4
     f5c:      	blr	x9
     f60:      	ldr	w8, [sp, #0xb8]
     f64:      	cmp	w8, w19
     f68:      	b.eq	0x17ac <event_execve+0x17ac>
     f6c:      	add	x2, x24, #0x8e0
     f70:      	mov	w8, #0x8                // =8
     f74:      	mov	w9, #0x71               // =113
     f78:      	add	x10, sp, #0x40
     f7c:      	add	x0, sp, #0x40
     f80:      	mov	w1, #0x8                // =8
     f84:      	blr	x9
     f88:      	ldr	x24, [sp, #0x40]
     f8c:      	cbz	x24, 0x17ac <event_execve+0x17ac>
     f90:      	add	x2, x24, #0x8d4
     f94:      	mov	w8, #0x4                // =4
     f98:      	mov	w9, #0x71               // =113
     f9c:      	add	x10, sp, #0xb8
     fa0:      	add	x0, sp, #0xb8
     fa4:      	mov	w1, #0x4                // =4
     fa8:      	blr	x9
     fac:      	ldr	w8, [sp, #0xb8]
     fb0:      	cmp	w8, w19
     fb4:      	b.eq	0x17ac <event_execve+0x17ac>
     fb8:      	add	x2, x24, #0x8e0
     fbc:      	mov	w8, #0x8                // =8
     fc0:      	mov	w9, #0x71               // =113
     fc4:      	add	x10, sp, #0x40
     fc8:      	add	x0, sp, #0x40
     fcc:      	mov	w1, #0x8                // =8
     fd0:      	blr	x9
     fd4:      	ldr	x24, [sp, #0x40]
     fd8:      	cbz	x24, 0x17ac <event_execve+0x17ac>
     fdc:      	add	x2, x24, #0x8d4
     fe0:      	mov	w8, #0x4                // =4
     fe4:      	mov	w9, #0x71               // =113
     fe8:      	add	x10, sp, #0xb8
     fec:      	add	x0, sp, #0xb8
     ff0:      	mov	w1, #0x4                // =4
     ff4:      	blr	x9
     ff8:      	ldr	w8, [sp, #0xb8]
     ffc:      	cmp	w8, w19
    1000:      	b.eq	0x17ac <event_execve+0x17ac>
    1004:      	add	x2, x24, #0x8e0
    1008:      	mov	w8, #0x8                // =8
    100c:      	mov	w9, #0x71               // =113
    1010:      	add	x10, sp, #0x40
    1014:      	add	x0, sp, #0x40
    1018:      	mov	w1, #0x8                // =8
    101c:      	blr	x9
    1020:      	ldr	x24, [sp, #0x40]
    1024:      	cbz	x24, 0x17ac <event_execve+0x17ac>
    1028:      	add	x2, x24, #0x8d4
    102c:      	mov	w8, #0x4                // =4
    1030:      	mov	w9, #0x71               // =113
    1034:      	add	x10, sp, #0xb8
    1038:      	add	x0, sp, #0xb8
    103c:      	mov	w1, #0x4                // =4
    1040:      	blr	x9
    1044:      	ldr	w8, [sp, #0xb8]
    1048:      	cmp	w8, w19
    104c:      	b.eq	0x17ac <event_execve+0x17ac>
    1050:      	add	x2, x24, #0x8e0
    1054:      	mov	w8, #0x8                // =8
    1058:      	mov	w9, #0x71               // =113
    105c:      	add	x10, sp, #0x40
    1060:      	add	x0, sp, #0x40
    1064:      	mov	w1, #0x8                // =8
    1068:      	blr	x9
    106c:      	ldr	x24, [sp, #0x40]
    1070:      	cbz	x24, 0x17ac <event_execve+0x17ac>
    1074:      	add	x2, x24, #0x8d4
    1078:      	mov	w8, #0x4                // =4
    107c:      	mov	w9, #0x71               // =113
    1080:      	add	x10, sp, #0xb8
    1084:      	add	x0, sp, #0xb8
    1088:      	mov	w1, #0x4                // =4
    108c:      	blr	x9
    1090:      	ldr	w8, [sp, #0xb8]
    1094:      	cmp	w8, w19
    1098:      	b.eq	0x17ac <event_execve+0x17ac>
    109c:      	add	x2, x24, #0x8e0
    10a0:      	mov	w8, #0x8                // =8
    10a4:      	mov	w9, #0x71               // =113
    10a8:      	add	x10, sp, #0x40
    10ac:      	add	x0, sp, #0x40
    10b0:      	mov	w1, #0x8                // =8
    10b4:      	mov	x22, x25
    10b8:      	mov	x21, x29
    10bc:      	blr	x9
    10c0:      	ldr	x24, [sp, #0x40]
    10c4:      	cbz	x24, 0x17a4 <event_execve+0x17a4>
    10c8:      	add	x2, x24, #0x8d4
    10cc:      	mov	w8, #0x4                // =4
    10d0:      	mov	w9, #0x71               // =113
    10d4:      	add	x10, sp, #0xb8
    10d8:      	add	x0, sp, #0xb8
    10dc:      	mov	w1, #0x4                // =4
    10e0:      	blr	x9
    10e4:      	ldr	w8, [sp, #0xb8]
    10e8:      	mov	x29, x21
    10ec:      	mov	x25, x22
    10f0:      	cmp	w8, w19
    10f4:      	b.eq	0x17ac <event_execve+0x17ac>
    10f8:      	add	x2, x24, #0x8e0
    10fc:      	mov	w8, #0x8                // =8
    1100:      	mov	w9, #0x71               // =113
    1104:      	add	x10, sp, #0x40
    1108:      	add	x0, sp, #0x40
    110c:      	mov	w1, #0x8                // =8
    1110:      	blr	x9
    1114:      	ldr	x24, [sp, #0x40]
    1118:      	cbz	x24, 0x17a4 <event_execve+0x17a4>
    111c:      	add	x2, x24, #0x8d4
    1120:      	mov	w8, #0x4                // =4
    1124:      	mov	w9, #0x71               // =113
    1128:      	add	x10, sp, #0xb8
    112c:      	add	x0, sp, #0xb8
    1130:      	mov	w1, #0x4                // =4
    1134:      	blr	x9
    1138:      	ldr	w8, [sp, #0xb8]
    113c:      	mov	x29, x21
    1140:      	mov	x25, x22
    1144:      	cmp	w8, w19
    1148:      	b.eq	0x17ac <event_execve+0x17ac>
    114c:      	add	x2, x24, #0x8e0
    1150:      	mov	w8, #0x8                // =8
    1154:      	mov	w9, #0x71               // =113
    1158:      	add	x10, sp, #0x40
    115c:      	add	x0, sp, #0x40
    1160:      	mov	w1, #0x8                // =8
    1164:      	blr	x9
    1168:      	ldr	x24, [sp, #0x40]
    116c:      	cbz	x24, 0x17a4 <event_execve+0x17a4>
    1170:      	add	x2, x24, #0x8d4
    1174:      	mov	w8, #0x4                // =4
    1178:      	mov	w9, #0x71               // =113
    117c:      	add	x10, sp, #0xb8
    1180:      	add	x0, sp, #0xb8
    1184:      	mov	w1, #0x4                // =4
    1188:      	blr	x9
    118c:      	ldr	w8, [sp, #0xb8]
    1190:      	mov	x29, x21
    1194:      	mov	x25, x22
    1198:      	cmp	w8, w19
    119c:      	b.eq	0x17ac <event_execve+0x17ac>
    11a0:      	add	x2, x24, #0x8e0
    11a4:      	mov	w8, #0x8                // =8
    11a8:      	mov	w9, #0x71               // =113
    11ac:      	add	x10, sp, #0x40
    11b0:      	add	x0, sp, #0x40
    11b4:      	mov	w1, #0x8                // =8
    11b8:      	blr	x9
    11bc:      	ldr	x24, [sp, #0x40]
    11c0:      	cbz	x24, 0x17a4 <event_execve+0x17a4>
    11c4:      	add	x2, x24, #0x8d4
    11c8:      	mov	w8, #0x4                // =4
    11cc:      	mov	w9, #0x71               // =113
    11d0:      	add	x10, sp, #0xb8
    11d4:      	add	x0, sp, #0xb8
    11d8:      	mov	w1, #0x4                // =4
    11dc:      	blr	x9
    11e0:      	ldr	w8, [sp, #0xb8]
    11e4:      	mov	x29, x21
    11e8:      	mov	x25, x22
    11ec:      	cmp	w8, w19
    11f0:      	b.eq	0x17ac <event_execve+0x17ac>
    11f4:      	add	x2, x24, #0x8e0
    11f8:      	mov	w8, #0x8                // =8
    11fc:      	mov	w9, #0x71               // =113
    1200:      	add	x10, sp, #0x40
    1204:      	add	x0, sp, #0x40
    1208:      	mov	w1, #0x8                // =8
    120c:      	blr	x9
    1210:      	ldr	x24, [sp, #0x40]
    1214:      	cbz	x24, 0x17a4 <event_execve+0x17a4>
    1218:      	add	x2, x24, #0x8d4
    121c:      	mov	w8, #0x4                // =4
    1220:      	mov	w9, #0x71               // =113
    1224:      	add	x10, sp, #0xb8
    1228:      	add	x0, sp, #0xb8
    122c:      	mov	w1, #0x4                // =4
    1230:      	blr	x9
    1234:      	ldr	w8, [sp, #0xb8]
    1238:      	mov	x29, x21
    123c:      	mov	x25, x22
    1240:      	cmp	w8, w19
    1244:      	b.eq	0x17ac <event_execve+0x17ac>
    1248:      	add	x2, x24, #0x8e0
    124c:      	mov	w8, #0x8                // =8
    1250:      	mov	w9, #0x71               // =113
    1254:      	add	x10, sp, #0x40
    1258:      	add	x0, sp, #0x40
    125c:      	mov	w1, #0x8                // =8
    1260:      	blr	x9
    1264:      	ldr	x24, [sp, #0x40]
    1268:      	cbz	x24, 0x17a4 <event_execve+0x17a4>
    126c:      	add	x2, x24, #0x8d4
    1270:      	mov	w8, #0x4                // =4
    1274:      	mov	w9, #0x71               // =113
    1278:      	add	x10, sp, #0xb8
    127c:      	add	x0, sp, #0xb8
    1280:      	mov	w1, #0x4                // =4
    1284:      	blr	x9
    1288:      	ldr	w8, [sp, #0xb8]
    128c:      	mov	x29, x21
    1290:      	mov	x25, x22
    1294:      	cmp	w8, w19
    1298:      	b.eq	0x17ac <event_execve+0x17ac>
    129c:      	add	x2, x24, #0x8e0
    12a0:      	mov	w8, #0x8                // =8
    12a4:      	mov	w9, #0x71               // =113
    12a8:      	add	x10, sp, #0x40
    12ac:      	add	x0, sp, #0x40
    12b0:      	mov	w1, #0x8                // =8
    12b4:      	blr	x9
    12b8:      	ldr	x24, [sp, #0x40]
    12bc:      	cbz	x24, 0x17a4 <event_execve+0x17a4>
    12c0:      	add	x2, x24, #0x8d4
    12c4:      	mov	w8, #0x4                // =4
    12c8:      	mov	w9, #0x71               // =113
    12cc:      	add	x10, sp, #0xb8
    12d0:      	add	x0, sp, #0xb8
    12d4:      	mov	w1, #0x4                // =4
    12d8:      	blr	x9
    12dc:      	ldr	w8, [sp, #0xb8]
    12e0:      	mov	x29, x21
    12e4:      	mov	x25, x22
    12e8:      	cmp	w8, w19
    12ec:      	b.eq	0x17ac <event_execve+0x17ac>
    12f0:      	add	x2, x24, #0x8e0
    12f4:      	mov	w8, #0x8                // =8
    12f8:      	mov	w9, #0x71               // =113
    12fc:      	add	x10, sp, #0x40
    1300:      	add	x0, sp, #0x40
    1304:      	mov	w1, #0x8                // =8
    1308:      	blr	x9
    130c:      	ldr	x24, [sp, #0x40]
    1310:      	cbz	x24, 0x17a4 <event_execve+0x17a4>
    1314:      	add	x2, x24, #0x8d4
    1318:      	mov	w8, #0x4                // =4
    131c:      	mov	w9, #0x71               // =113
    1320:      	add	x10, sp, #0xb8
    1324:      	add	x0, sp, #0xb8
    1328:      	mov	w1, #0x4                // =4
    132c:      	blr	x9
    1330:      	ldr	w8, [sp, #0xb8]
    1334:      	mov	x29, x21
    1338:      	mov	x25, x22
    133c:      	cmp	w8, w19
    1340:      	b.eq	0x17ac <event_execve+0x17ac>
    1344:      	add	x2, x24, #0x8e0
    1348:      	mov	w8, #0x8                // =8
    134c:      	mov	w9, #0x71               // =113
    1350:      	add	x10, sp, #0x40
    1354:      	add	x0, sp, #0x40
    1358:      	mov	w1, #0x8                // =8
    135c:      	blr	x9
    1360:      	ldr	x24, [sp, #0x40]
    1364:      	cbz	x24, 0x17a4 <event_execve+0x17a4>
    1368:      	add	x2, x24, #0x8d4
    136c:      	mov	w8, #0x4                // =4
    1370:      	mov	w9, #0x71               // =113
    1374:      	add	x10, sp, #0xb8
    1378:      	add	x0, sp, #0xb8
    137c:      	mov	w1, #0x4                // =4
    1380:      	blr	x9
    1384:      	ldr	w8, [sp, #0xb8]
    1388:      	mov	x29, x21
    138c:      	mov	x25, x22
    1390:      	cmp	w8, w19
    1394:      	b.eq	0x17ac <event_execve+0x17ac>
    1398:      	add	x2, x24, #0x8e0
    139c:      	mov	w8, #0x8                // =8
    13a0:      	mov	w9, #0x71               // =113
    13a4:      	add	x10, sp, #0x40
    13a8:      	add	x0, sp, #0x40
    13ac:      	mov	w1, #0x8                // =8
    13b0:      	blr	x9
    13b4:      	ldr	x24, [sp, #0x40]
    13b8:      	cbz	x24, 0x17a4 <event_execve+0x17a4>
    13bc:      	add	x2, x24, #0x8d4
    13c0:      	mov	w8, #0x4                // =4
    13c4:      	mov	w9, #0x71               // =113
    13c8:      	add	x10, sp, #0xb8
    13cc:      	add	x0, sp, #0xb8
    13d0:      	mov	w1, #0x4                // =4
    13d4:      	blr	x9
    13d8:      	ldr	w8, [sp, #0xb8]
    13dc:      	mov	x29, x21
    13e0:      	mov	x25, x22
    13e4:      	cmp	w8, w19
    13e8:      	b.eq	0x17ac <event_execve+0x17ac>
    13ec:      	add	x2, x24, #0x8e0
    13f0:      	mov	w8, #0x8                // =8
    13f4:      	mov	w9, #0x71               // =113
    13f8:      	add	x10, sp, #0x40
    13fc:      	add	x0, sp, #0x40
    1400:      	mov	w1, #0x8                // =8
    1404:      	blr	x9
    1408:      	ldr	x24, [sp, #0x40]
    140c:      	cbz	x24, 0x17a4 <event_execve+0x17a4>
    1410:      	add	x2, x24, #0x8d4
    1414:      	mov	w8, #0x4                // =4
    1418:      	mov	w9, #0x71               // =113
    141c:      	add	x10, sp, #0xb8
    1420:      	add	x0, sp, #0xb8
    1424:      	mov	w1, #0x4                // =4
    1428:      	blr	x9
    142c:      	ldr	w8, [sp, #0xb8]
    1430:      	mov	x29, x21
    1434:      	mov	x25, x22
    1438:      	cmp	w8, w19
    143c:      	b.eq	0x17ac <event_execve+0x17ac>
    1440:      	add	x2, x24, #0x8e0
    1444:      	mov	w8, #0x8                // =8
    1448:      	mov	w9, #0x71               // =113
    144c:      	add	x10, sp, #0x40
    1450:      	add	x0, sp, #0x40
    1454:      	mov	w1, #0x8                // =8
    1458:      	blr	x9
    145c:      	ldr	x24, [sp, #0x40]
    1460:      	cbz	x24, 0x17a4 <event_execve+0x17a4>
    1464:      	add	x2, x24, #0x8d4
    1468:      	mov	w8, #0x4                // =4
    146c:      	mov	w9, #0x71               // =113
    1470:      	add	x10, sp, #0xb8
    1474:      	add	x0, sp, #0xb8
    1478:      	mov	w1, #0x4                // =4
    147c:      	blr	x9
    1480:      	ldr	w8, [sp, #0xb8]
    1484:      	mov	x29, x21
    1488:      	mov	x25, x22
    148c:      	cmp	w8, w19
    1490:      	b.eq	0x17ac <event_execve+0x17ac>
    1494:      	add	x2, x24, #0x8e0
    1498:      	mov	w8, #0x8                // =8
    149c:      	mov	w9, #0x71               // =113
    14a0:      	add	x10, sp, #0x40
    14a4:      	add	x0, sp, #0x40
    14a8:      	mov	w1, #0x8                // =8
    14ac:      	blr	x9
    14b0:      	ldr	x24, [sp, #0x40]
    14b4:      	b	0x17ac <event_execve+0x17ac>
    14b8:      	str	x10, [sp, #0x18]
    14bc:      	str	wzr, [sp, #0xa8]
    14c0:      	adrp	x0, 0x1000 <event_execve+0x1000>
    14c4:      	mov	w8, #0x1                // =1
    14c8:      	add	x9, sp, #0xa8
    14cc:      	add	x1, sp, #0xa8
    14d0:      	ldr	x0, [x0]
    14d4:      	blr	x8
    14d8:      	cbz	x0, 0x1630 <event_execve+0x1630>
    14dc:      	mov	w8, #0x18               // =24
    14e0:      	str	x21, [sp, #0xd8]
    14e4:      	str	x25, [sp, #0x30]
    14e8:      	mov	x19, x0
    14ec:      	str	w8, [x0]
    14f0:      	mov	w8, #0xe                // =14
    14f4:      	blr	x8
    14f8:      	str	x19, [sp, #0x20]
    14fc:      	str	x0, [x19, #0x10]!
    1500:      	cmn	x0, #0x16
    1504:      	b.ne	0x152c <event_execve+0x152c>
    1508:      	add	x2, x29, #0xe8
    150c:      	mov	w8, #0x8                // =8
    1510:      	mov	w9, #0x4                // =4
    1514:      	add	x10, sp, #0x40
    1518:      	add	x0, sp, #0x40
    151c:      	mov	w1, #0x8                // =8
    1520:      	blr	x9
    1524:      	ldr	x8, [sp, #0x40]
    1528:      	str	x8, [x19]
    152c:      	str	x29, [sp, #0x28]
    1530:      	mov	w8, #0x7d               // =125
    1534:      	blr	x8
    1538:      	ldp	x10, x8, [sp, #0x18]
    153c:      	mov	x29, xzr
    1540:      	mov	w21, #0xa               // =10
    1544:      	mov	w24, #0x7fe0            // =32736
    1548:      	add	x25, x8, #0x20
    154c:      	str	x0, [x8, #0x18]
    1550:      	ldp	x8, x9, [x19]
    1554:      	stp	x8, x9, [x10, #0x150]
    1558:      	subs	x8, x22, x29
    155c:      	b.mi	0x1678 <event_execve+0x1678>
    1560:      	cmp	x8, x24
    1564:      	add	x2, x29, x23
    1568:      	mov	x0, x25
    156c:      	csel	x19, x8, x24, lo
    1570:      	mov	w8, #0x4                // =4
    1574:      	mov	w1, w19
    1578:      	blr	x8
    157c:      	tbnz	w0, #0x1f, 0x160c <event_execve+0x160c>
    1580:      	ldr	x8, [sp, #0x20]
    1584:      	mov	x24, x22
    1588:      	mov	x22, x23
    158c:      	add	w23, w19, #0x20
    1590:      	str	wzr, [sp, #0x40]
    1594:      	str	w23, [x8, #0x4]
    1598:      	adrp	x0, 0x1000 <event_execve+0x1000>
    159c:      	mov	w8, #0x1                // =1
    15a0:      	add	x9, sp, #0x40
    15a4:      	add	x1, sp, #0x40
    15a8:      	ldr	x0, [x0]
    15ac:      	blr	x8
    15b0:      	cbz	x0, 0x15e0 <event_execve+0x15e0>
    15b4:      	ldrb	w8, [x0, #0x28]
    15b8:      	cbz	w8, 0x15e0 <event_execve+0x15e0>
    15bc:      	adrp	x1, 0x1000 <event_execve+0x1000>
    15c0:      	ldp	x3, x0, [sp, #0x20]
    15c4:      	mov	w8, #0x19               // =25
    15c8:      	mov	w9, #-0x1               // =-1
    15cc:      	mov	w2, #-0x1               // =-1
    15d0:      	ldr	x1, [x1]
    15d4:      	mov	x4, x23
    15d8:      	blr	x8
    15dc:      	b	0x15fc <event_execve+0x15fc>
    15e0:      	adrp	x0, 0x1000 <event_execve+0x1000>
    15e4:      	ldr	x1, [sp, #0x20]
    15e8:      	mov	x3, xzr
    15ec:      	mov	w8, #0x82               // =130
    15f0:      	ldr	x0, [x0]
    15f4:      	mov	x2, x23
    15f8:      	blr	x8
    15fc:      	mov	x23, x22
    1600:      	mov	x22, x24
    1604:      	mov	w24, #0x7fe0            // =32736
    1608:      	tbz	w0, #0x1f, 0x1610 <event_execve+0x1610>
    160c:      	sxtw	x19, w0
    1610:      	tbnz	w19, #0x1f, 0x1680 <event_execve+0x1680>
    1614:      	and	x8, x19, #0x7fffffff
    1618:      	add	x29, x8, x29
    161c:      	cmp	x29, x22
    1620:      	b.eq	0x16cc <event_execve+0x16cc>
    1624:      	subs	w21, w21, #0x1
    1628:      	b.ne	0x1558 <event_execve+0x1558>
    162c:      	b	0x1730 <event_execve+0x1730>
    1630:      	mov	w19, wzr
    1634:      	add	x24, sp, #0xb8
    1638:      	b	0x177c <event_execve+0x177c>
    163c:      	mov	w8, #0x1                // =1
    1640:      	mov	x3, xzr
    1644:      	add	x9, sp, #0x40
    1648:      	str	w8, [sp, #0xa8]
    164c:      	mov	w8, #0x2                // =2
    1650:      	add	x10, sp, #0xa8
    1654:      	add	x1, sp, #0x40
    1658:      	add	x2, sp, #0xa8
    165c:      	mov	x0, x23
    1660:      	blr	x8
    1664:      	tbz	w22, #0x1f, 0x177c <event_execve+0x177c>
    1668:      	ldr	w8, [x20, #0x15c]
    166c:      	mov	w19, wzr
    1670:      	orr	w8, w8, #0x200
    1674:      	b	0x1778 <event_execve+0x1778>
    1678:      	mov	x29, #-0x1              // =-1
    167c:      	b	0x1684 <event_execve+0x1684>
    1680:      	mov	x29, x19
    1684:      	str	wzr, [sp, #0x40]
    1688:      	adrp	x0, 0x1000 <event_execve+0x1000>
    168c:      	mov	w8, #0x1                // =1
    1690:      	add	x9, sp, #0x40
    1694:      	ldr	x0, [x0]
    1698:      	add	x1, sp, #0x40
    169c:      	blr	x8
    16a0:      	cbz	x0, 0x1730 <event_execve+0x1730>
    16a4:      	cmn	x29, #0xc
    16a8:      	b.gt	0x16d4 <event_execve+0x16d4>
    16ac:      	cmn	x29, #0x1c
    16b0:      	b.eq	0x16f4 <event_execve+0x16f4>
    16b4:      	cmn	x29, #0x16
    16b8:      	b.eq	0x170c <event_execve+0x170c>
    16bc:      	cmn	x29, #0x10
    16c0:      	b.ne	0x1704 <event_execve+0x1704>
    16c4:      	add	x8, x0, #0x558
    16c8:      	b	0x1720 <event_execve+0x1720>
    16cc:      	mov	x29, x22
    16d0:      	b	0x1730 <event_execve+0x1730>
    16d4:      	cmn	x29, #0xb
    16d8:      	b.eq	0x16fc <event_execve+0x16fc>
    16dc:      	cmn	x29, #0x7
    16e0:      	b.eq	0x1714 <event_execve+0x1714>
    16e4:      	cmn	x29, #0x2
    16e8:      	b.ne	0x1704 <event_execve+0x1704>
    16ec:      	add	x8, x0, #0x548
    16f0:      	b	0x1720 <event_execve+0x1720>
    16f4:      	add	x8, x0, #0x568
    16f8:      	b	0x1720 <event_execve+0x1720>
    16fc:      	add	x8, x0, #0x570
    1700:      	b	0x1720 <event_execve+0x1720>
    1704:      	add	x8, x0, #0x540
    1708:      	b	0x1720 <event_execve+0x1720>
    170c:      	add	x8, x0, #0x560
    1710:      	b	0x1720 <event_execve+0x1720>
    1714:      	add	x8, x0, #0x550
    1718:      	nop
    171c:      	nop
    1720:      	ldaxr	x9, [x8]
    1724:      	add	x9, x9, #0x1
    1728:      	stlxr	w10, x9, [x8]
    172c:      	cbnz	w10, 0x1720 <event_execve+0x1720>
    1730:      	ldr	x11, [sp, #0x18]
    1734:      	cmn	x22, #0x1
    1738:      	sub	w8, w22, w29
    173c:      	asr	w9, w29, #31
    1740:      	ldr	x21, [sp, #0xd8]
    1744:      	str	wzr, [x11, #0x144]
    1748:      	ccmp	w29, #0x0, #0x8, ne
    174c:      	csel	w8, wzr, w8, lt
    1750:      	and	w10, w29, w9
    1754:      	str	w8, [x11, #0x148]
    1758:      	bic	w8, w29, w9
    175c:      	str	w10, [x11, #0x140]
    1760:      	mov	w19, #0x20              // =32
    1764:      	ldp	x29, x25, [sp, #0x28]
    1768:      	add	x24, sp, #0xb8
    176c:      	str	w8, [x11, #0x14c]
    1770:      	ldr	w8, [x20, #0x15c]
    1774:      	orr	w8, w8, #0x1000000
    1778:      	str	w8, [x20, #0x15c]
    177c:      	str	w19, [x20, #0x1848]
    1780:      	strh	w19, [x20, #0x17a]
    1784:      	adrp	x22, 0x1000 <event_execve+0x1000>
    1788:      	ldr	x22, [x22]
    178c:      	ldr	w8, [x20, #0x140]
    1790:      	add	w9, w8, w19
    1794:      	ldrb	w8, [x20, #0x15d]
    1798:      	str	w9, [x20, #0x140]
    179c:      	tbz	w8, #0x5, 0xe40 <event_execve+0xe40>
    17a0:      	b	0xdec <event_execve+0xdec>
    17a4:      	mov	x29, x21
    17a8:      	mov	x25, x22
    17ac:      	ldr	w8, [sp, #0xb8]
    17b0:      	mov	w9, #0x4                // =4
    17b4:      	add	x10, sp, #0x88
    17b8:      	add	x0, sp, #0x88
    17bc:      	mov	w1, #0x8                // =8
    17c0:      	cmp	w8, w19
    17c4:      	csel	x8, x24, xzr, eq
    17c8:      	add	x2, x8, #0xb30
    17cc:      	mov	w8, #0x8                // =8
    17d0:      	blr	x9
    17d4:      	ldr	x21, [sp, #0x88]
    17d8:      	cbz	x21, 0x1890 <event_execve+0x1890>
    17dc:      	str	wzr, [sp, #0x94]
    17e0:      	adrp	x0, 0x1000 <event_execve+0x1000>
    17e4:      	mov	w8, #0x1                // =1
    17e8:      	add	x9, sp, #0x94
    17ec:      	ldr	x0, [x0]
    17f0:      	add	x1, sp, #0x94
    17f4:      	blr	x8
    17f8:      	cbz	x0, 0x18a4 <event_execve+0x18a4>
    17fc:      	add	x8, x21, #0x28
    1800:      	stp	x29, x25, [sp, #0x28]
    1804:      	mov	x19, x0
    1808:      	str	x8, [sp, #0x10]
    180c:      	add	x8, x0, #0x1, lsl #12   // =0x1000
    1810:      	str	x8, [sp, #0x20]
    1814:      	mov	w8, #0x23               // =35
    1818:      	blr	x8
    181c:      	add	x2, x0, #0xb30
    1820:      	mov	w25, #0x8               // =8
    1824:      	add	x8, sp, #0x98
    1828:      	mov	w9, #0x4                // =4
    182c:      	add	x0, sp, #0x98
    1830:      	mov	w1, #0x8                // =8
    1834:      	mov	w23, #0x4               // =4
    1838:      	blr	x9
    183c:      	ldr	x24, [sp, #0x98]
    1840:      	add	x22, x21, #0x30
    1844:      	mov	w9, #0x4                // =4
    1848:      	add	x0, sp, #0xa0
    184c:      	mov	w1, #0x8                // =8
    1850:      	mov	x2, x22
    1854:      	add	x8, x24, #0x18
    1858:      	str	x8, [sp, #0x8]
    185c:      	add	x8, sp, #0xa0
    1860:      	blr	x9
    1864:      	ldr	x21, [sp, #0xa0]
    1868:      	add	x29, sp, #0x40
    186c:      	add	x0, sp, #0x40
    1870:      	mov	w1, #0x8                // =8
    1874:      	add	x2, x21, #0x10
    1878:      	blr	x23
    187c:      	ldr	x8, [sp, #0x40]
    1880:      	cbz	x8, 0x18b8 <event_execve+0x18b8>
    1884:      	ldr	x9, [sp, #0x20]
    1888:      	mov	w8, #0x1000             // =4096
    188c:      	b	0x1900 <event_execve+0x1900>
    1890:      	ldr	w9, [x20, #0x15c]
    1894:      	mov	w8, wzr
    1898:      	orr	w9, w9, #0x2000
    189c:      	str	w9, [x20, #0x15c]
    18a0:      	b	0x18a8 <event_execve+0x18a8>
    18a4:      	mov	w8, wzr
    18a8:      	adrp	x22, 0x1000 <event_execve+0x1000>
    18ac:      	add	x24, sp, #0xb8
    18b0:      	ldr	x22, [x22]
    18b4:      	b	0x1da4 <event_execve+0x1da4>
    18b8:      	add	x2, x21, #0x18
    18bc:      	mov	w8, #0x8                // =8
    18c0:      	mov	w9, #0x4                // =4
    18c4:      	add	x10, sp, #0x40
    18c8:      	add	x0, sp, #0x40
    18cc:      	mov	w1, #0x8                // =8
    18d0:      	blr	x9
    18d4:      	ldr	x8, [sp, #0x40]
    18d8:      	cmp	x8, x21
    18dc:      	b.eq	0x1884 <event_execve+0x1884>
    18e0:      	mov	w8, #0x2964             // =10596
    18e4:      	add	x9, x19, #0xff6
    18e8:      	strh	w8, [x19, #0xffe]
    18ec:      	adrp	x8, 0x1000 <event_execve+0x1000>
    18f0:      	add	x8, x8, #0x0
    18f4:      	ldr	x8, [x8]
    18f8:      	str	x8, [x9]
    18fc:      	mov	w8, #0xff6              // =4086
    1900:      	stp	xzr, xzr, [sp, #0x40]
    1904:      	add	x2, x24, #0x20
    1908:      	mov	w23, #0x8               // =8
    190c:      	add	x0, sp, #0x40
    1910:      	mov	w1, #0x8                // =8
    1914:      	add	x21, x29, #0x8
    1918:      	stp	x19, xzr, [sp, #0x50]
    191c:      	add	x25, x29, #0x18
    1920:      	add	x19, x29, #0x20
    1924:      	stp	xzr, xzr, [sp, #0x60]
    1928:      	mov	w24, #0x4               // =4
    192c:      	str	x9, [sp, #0x20]
    1930:      	str	x9, [sp, #0x70]
    1934:      	str	w8, [sp, #0x78]
    1938:      	mov	w8, #0x4                // =4
    193c:      	strb	wzr, [sp, #0x7c]
    1940:      	blr	x8
    1944:      	ldr	x2, [sp, #0x8]
    1948:      	mov	w8, #0x4                // =4
    194c:      	mov	x0, x21
    1950:      	mov	w1, #0x8                // =8
    1954:      	blr	x8
    1958:      	mov	w8, #0x4                // =4
    195c:      	mov	x0, x25
    1960:      	mov	w1, #0x8                // =8
    1964:      	mov	x2, x22
    1968:      	blr	x8
    196c:      	ldr	x2, [sp, #0x10]
    1970:      	mov	x0, x19
    1974:      	mov	w1, #0x8                // =8
    1978:      	blr	x24
    197c:      	ldr	x8, [sp, #0x60]
    1980:      	sub	x8, x8, #0x20
    1984:      	str	x8, [sp, #0x68]
    1988:      	adrp	x8, 0x1000 <event_execve+0x1000>
    198c:      	ldr	x8, [x8]
    1990:      	ldrb	w8, [x8]
    1994:      	cbz	w8, 0x1b38 <event_execve+0x1b38>
    1998:      	mov	w21, #0x80              // =128
    199c:      	mov	w22, #0x8               // =8
    19a0:      	ldp	x24, x2, [sp, #0x58]
    19a4:      	ldp	x8, x9, [sp, #0x40]
    19a8:      	cmp	x24, x8
    19ac:      	ccmp	x2, x9, #0x0, eq
    19b0:      	b.eq	0x1cd8 <event_execve+0x1cd8>
    19b4:      	ldr	x23, [sp, #0x68]
    19b8:      	mov	w8, #0x4                // =4
    19bc:      	add	x9, sp, #0xa8
    19c0:      	add	x0, sp, #0xa8
    19c4:      	mov	w1, #0x8                // =8
    19c8:      	blr	x8
    19cc:      	ldr	x8, [sp, #0xa8]
    19d0:      	add	x29, sp, #0xb8
    19d4:      	cmp	x24, x8
    19d8:      	b.eq	0x1ae0 <event_execve+0x1ae0>
    19dc:      	add	x19, x24, #0x18
    19e0:      	mov	w8, #0x4                // =4
    19e4:      	add	x9, sp, #0xc8
    19e8:      	add	x0, sp, #0xc8
    19ec:      	mov	w1, #0x8                // =8
    19f0:      	mov	x2, x19
    19f4:      	blr	x8
    19f8:      	ldr	x8, [x29, #0x10]
    19fc:      	cmp	x8, x24
    1a00:      	b.eq	0x1ae0 <event_execve+0x1ae0>
    1a04:      	mov	w8, #0x4                // =4
    1a08:      	add	x9, sp, #0xb0
    1a0c:      	add	x0, sp, #0xb0
    1a10:      	mov	w1, #0x8                // =8
    1a14:      	mov	x2, x19
    1a18:      	blr	x8
    1a1c:      	add	x2, x24, #0x20
    1a20:      	mov	w8, #0x4                // =4
    1a24:      	mov	w9, #0x10               // =16
    1a28:      	add	x10, sp, #0xb8
    1a2c:      	add	x0, sp, #0xb8
    1a30:      	mov	w1, #0x10               // =16
    1a34:      	blr	x8
    1a38:      	ldr	w19, [sp, #0xbc]
    1a3c:      	ldr	x8, [sp, #0x50]
    1a40:      	add	x24, sp, #0xb8
    1a44:      	ldr	x10, [sp, #0x70]
    1a48:      	sub	x12, x10, x8
    1a4c:      	ldr	w23, [sp, #0x78]
    1a50:      	subs	w10, w19, w23
    1a54:      	ldr	x9, [x29, #0x8]
    1a58:      	csel	w10, wzr, w10, lo
    1a5c:      	cmp	w23, w19
    1a60:      	csel	w11, w23, w19, lo
    1a64:      	cinc	w13, w11, hi
    1a68:      	sub	w14, w23, w13
    1a6c:      	subs	x12, x12, x13
    1a70:      	str	w14, [sp, #0x78]
    1a74:      	b.lo	0x1ce4 <event_execve+0x1ce4>
    1a78:      	cmp	x12, #0xfff
    1a7c:      	b.hi	0x1ce4 <event_execve+0x1ce4>
    1a80:      	cmp	w23, w19
    1a84:      	b.ls	0x1a90 <event_execve+0x1a90>
    1a88:      	mov	w13, #0x2f              // =47
    1a8c:      	strb	w13, [x8, x12]
    1a90:      	add	x24, x8, x12
    1a94:      	cmp	w23, w19
    1a98:      	add	x2, x9, x10
    1a9c:      	and	w1, w11, #0xff
    1aa0:      	mov	w8, #0x4                // =4
    1aa4:      	cinc	x0, x24, hi
    1aa8:      	blr	x8
    1aac:      	cmp	w23, w19
    1ab0:      	str	x24, [sp, #0x70]
    1ab4:      	add	x24, sp, #0xb8
    1ab8:      	b.ls	0x1ce4 <event_execve+0x1ce4>
    1abc:      	ldr	x8, [sp, #0xb0]
    1ac0:      	str	x8, [sp, #0x58]
    1ac4:      	subs	w21, w21, #0x1
    1ac8:      	b.ne	0x19a0 <event_execve+0x19a0>
    1acc:      	b	0x1ce4 <event_execve+0x1ce4>
    1ad0:      	nop
    1ad4:      	nop
    1ad8:      	nop
    1adc:      	nop
    1ae0:      	add	x2, x23, #0x10
    1ae4:      	mov	w8, #0x4                // =4
    1ae8:      	add	x9, sp, #0xc8
    1aec:      	add	x0, sp, #0xc8
    1af0:      	mov	w1, #0x8                // =8
    1af4:      	blr	x8
    1af8:      	ldr	x8, [sp, #0x68]
    1afc:      	ldr	x9, [x29, #0x10]
    1b00:      	add	x24, sp, #0xb8
    1b04:      	cmp	x8, x9
    1b08:      	b.eq	0x1d30 <event_execve+0x1d30>
    1b0c:      	add	x2, x23, #0x18
    1b10:      	mov	w8, #0x4                // =4
    1b14:      	mov	x0, x25
    1b18:      	mov	w1, #0x8                // =8
    1b1c:      	blr	x8
    1b20:      	ldr	x8, [x24, #0x10]
    1b24:      	add	x9, x8, #0x20
    1b28:      	stp	x9, x8, [sp, #0x60]
    1b2c:      	subs	w21, w21, #0x1
    1b30:      	b.ne	0x19a0 <event_execve+0x19a0>
    1b34:      	b	0x1ce4 <event_execve+0x1ce4>
    1b38:      	mov	w21, #0x80              // =128
    1b3c:      	mov	w22, #0x8               // =8
    1b40:      	ldp	x24, x2, [sp, #0x58]
    1b44:      	ldp	x8, x9, [sp, #0x40]
    1b48:      	cmp	x24, x8
    1b4c:      	ccmp	x2, x9, #0x0, eq
    1b50:      	b.eq	0x1cd8 <event_execve+0x1cd8>
    1b54:      	ldr	x23, [sp, #0x68]
    1b58:      	mov	w8, #0x4                // =4
    1b5c:      	add	x9, sp, #0xa8
    1b60:      	add	x0, sp, #0xa8
    1b64:      	mov	w1, #0x8                // =8
    1b68:      	blr	x8
    1b6c:      	ldr	x8, [sp, #0xa8]
    1b70:      	add	x29, sp, #0xb8
    1b74:      	cmp	x24, x8
    1b78:      	b.eq	0x1c80 <event_execve+0x1c80>
    1b7c:      	add	x19, x24, #0x18
    1b80:      	mov	w8, #0x4                // =4
    1b84:      	add	x9, sp, #0xc8
    1b88:      	add	x0, sp, #0xc8
    1b8c:      	mov	w1, #0x8                // =8
    1b90:      	mov	x2, x19
    1b94:      	blr	x8
    1b98:      	ldr	x8, [x29, #0x10]
    1b9c:      	cmp	x8, x24
    1ba0:      	b.eq	0x1c80 <event_execve+0x1c80>
    1ba4:      	mov	w8, #0x4                // =4
    1ba8:      	add	x9, sp, #0xb0
    1bac:      	add	x0, sp, #0xb0
    1bb0:      	mov	w1, #0x8                // =8
    1bb4:      	mov	x2, x19
    1bb8:      	blr	x8
    1bbc:      	add	x2, x24, #0x20
    1bc0:      	mov	w8, #0x4                // =4
    1bc4:      	mov	w9, #0x10               // =16
    1bc8:      	add	x10, sp, #0xb8
    1bcc:      	add	x0, sp, #0xb8
    1bd0:      	mov	w1, #0x10               // =16
    1bd4:      	blr	x8
    1bd8:      	ldr	w19, [sp, #0xbc]
    1bdc:      	ldr	x8, [sp, #0x50]
    1be0:      	add	x24, sp, #0xb8
    1be4:      	ldr	x10, [sp, #0x70]
    1be8:      	sub	x12, x10, x8
    1bec:      	ldr	w23, [sp, #0x78]
    1bf0:      	subs	w10, w19, w23
    1bf4:      	ldr	x9, [x29, #0x8]
    1bf8:      	csel	w10, wzr, w10, lo
    1bfc:      	cmp	w23, w19
    1c00:      	csel	w11, w23, w19, lo
    1c04:      	cinc	w13, w11, hi
    1c08:      	sub	w14, w23, w13
    1c0c:      	subs	x12, x12, x13
    1c10:      	str	w14, [sp, #0x78]
    1c14:      	b.lo	0x1ce4 <event_execve+0x1ce4>
    1c18:      	cmp	x12, #0xfff
    1c1c:      	b.hi	0x1ce4 <event_execve+0x1ce4>
    1c20:      	cmp	w23, w19
    1c24:      	b.ls	0x1c30 <event_execve+0x1c30>
    1c28:      	mov	w13, #0x2f              // =47
    1c2c:      	strb	w13, [x8, x12]
    1c30:      	add	x24, x8, x12
    1c34:      	cmp	w23, w19
    1c38:      	add	x2, x9, x10
    1c3c:      	and	w1, w11, #0xff
    1c40:      	mov	w8, #0x4                // =4
    1c44:      	cinc	x0, x24, hi
    1c48:      	blr	x8
    1c4c:      	cmp	w23, w19
    1c50:      	str	x24, [sp, #0x70]
    1c54:      	add	x24, sp, #0xb8
    1c58:      	b.ls	0x1ce4 <event_execve+0x1ce4>
    1c5c:      	ldr	x8, [sp, #0xb0]
    1c60:      	str	x8, [sp, #0x58]
    1c64:      	subs	w21, w21, #0x1
    1c68:      	b.ne	0x1b40 <event_execve+0x1b40>
    1c6c:      	b	0x1ce4 <event_execve+0x1ce4>
    1c70:      	nop
    1c74:      	nop
    1c78:      	nop
    1c7c:      	nop
    1c80:      	add	x2, x23, #0x10
    1c84:      	mov	w8, #0x4                // =4
    1c88:      	add	x9, sp, #0xc8
    1c8c:      	add	x0, sp, #0xc8
    1c90:      	mov	w1, #0x8                // =8
    1c94:      	blr	x8
    1c98:      	ldr	x8, [sp, #0x68]
    1c9c:      	ldr	x9, [x29, #0x10]
    1ca0:      	add	x24, sp, #0xb8
    1ca4:      	cmp	x8, x9
    1ca8:      	b.eq	0x1d30 <event_execve+0x1d30>
    1cac:      	add	x2, x23, #0x18
    1cb0:      	mov	w8, #0x4                // =4
    1cb4:      	mov	x0, x25
    1cb8:      	mov	w1, #0x8                // =8
    1cbc:      	blr	x8
    1cc0:      	ldr	x8, [x24, #0x10]
    1cc4:      	add	x9, x8, #0x20
    1cc8:      	stp	x9, x8, [sp, #0x60]
    1ccc:      	subs	w21, w21, #0x1
    1cd0:      	b.ne	0x1b40 <event_execve+0x1b40>
    1cd4:      	b	0x1ce4 <event_execve+0x1ce4>
    1cd8:      	mov	w8, #0x1                // =1
    1cdc:      	add	x24, sp, #0xb8
    1ce0:      	strb	w8, [sp, #0x7c]
    1ce4:      	ldr	x8, [sp, #0x70]
    1ce8:      	ldr	x2, [sp, #0x20]
    1cec:      	cmp	x8, x2
    1cf0:      	b.eq	0x1d48 <event_execve+0x1d48>
    1cf4:      	ldrb	w9, [sp, #0x7c]
    1cf8:      	ldr	w10, [sp, #0x78]
    1cfc:      	adrp	x22, 0x1000 <event_execve+0x1000>
    1d00:      	mov	w11, #0x1000            // =4096
    1d04:      	cmp	w9, #0x0
    1d08:      	ldp	x29, x25, [sp, #0x28]
    1d0c:      	ldr	x22, [x22]
    1d10:      	sub	w11, w11, w10
    1d14:      	cset	w9, eq
    1d18:      	cmp	w10, #0x0
    1d1c:      	csel	w21, w11, w10, gt
    1d20:      	cbz	x8, 0x1da4 <event_execve+0x1da4>
    1d24:      	lsl	w19, w9, #1
    1d28:      	mov	x2, x8
    1d2c:      	b	0x1d5c <event_execve+0x1d5c>
    1d30:      	mov	w8, #0x1                // =1
    1d34:      	strb	w8, [sp, #0x7c]
    1d38:      	ldr	x8, [sp, #0x70]
    1d3c:      	ldr	x2, [sp, #0x20]
    1d40:      	cmp	x8, x2
    1d44:      	b.ne	0x1cf4 <event_execve+0x1cf4>
    1d48:      	adrp	x22, 0x1000 <event_execve+0x1000>
    1d4c:      	ldp	x29, x25, [sp, #0x28]
    1d50:      	mov	w21, wzr
    1d54:      	mov	w19, wzr
    1d58:      	ldr	x22, [x22]
    1d5c:      	ldr	w8, [sp, #0x18]
    1d60:      	ldr	x9, [sp, #0xd8]
    1d64:      	ands	w1, w21, #0xfff
    1d68:      	and	w8, w8, #0x3ff
    1d6c:      	add	x0, x9, x8
    1d70:      	mov	w8, #0x4                // =4
    1d74:      	blr	x8
    1d78:      	ldr	w9, [x20, #0x15c]
    1d7c:      	ands	w8, w21, #0xfff
    1d80:      	strh	w8, [x20, #0x17c]
    1d84:      	orr	w10, w9, #0x1000
    1d88:      	csel	w9, w10, w9, eq
    1d8c:      	cmp	w19, #0x0
    1d90:      	orr	w10, w9, #0x400000
    1d94:      	csel	w9, w9, w10, eq
    1d98:      	mov	w10, #-0x2401           // =-9217
    1d9c:      	and	w9, w9, w10
    1da0:      	str	w9, [x20, #0x15c]
    1da4:      	ldr	x21, [sp, #0xd8]
    1da8:      	ldr	w9, [x21]
    1dac:      	add	w19, w9, w8
    1db0:      	str	xzr, [sp, #0xb8]
    1db4:      	adrp	x8, 0x1000 <event_execve+0x1000>
    1db8:      	str	w19, [x21]
    1dbc:      	ldr	x8, [x8]
    1dc0:      	ldrb	w8, [x8]
    1dc4:      	cbz	w8, 0x2228 <event_execve+0x2228>
    1dc8:      	cmp	w19, #0x3ff
    1dcc:      	b.hi	0x1e6c <event_execve+0x1e6c>
    1dd0:      	mov	w8, #0x23               // =35
    1dd4:      	blr	x8
    1dd8:      	add	x2, x0, #0x858
    1ddc:      	mov	w8, #0x8                // =8
    1de0:      	mov	w9, #0x4                // =4
    1de4:      	add	x10, sp, #0xb8
    1de8:      	add	x0, sp, #0xb8
    1dec:      	mov	w1, #0x8                // =8
    1df0:      	blr	x9
    1df4:      	ldr	x8, [sp, #0xb8]
    1df8:      	cbz	x8, 0x2228 <event_execve+0x2228>
    1dfc:      	add	x8, x8, #0x288
    1e00:      	mov	w9, #0x8                // =8
    1e04:      	mov	w10, #0x4               // =4
    1e08:      	add	x11, sp, #0xc8
    1e0c:      	ldr	x8, [sp, #0xb8]
    1e10:      	add	x0, sp, #0xc8
    1e14:      	mov	w1, #0x8                // =8
    1e18:      	add	x2, x8, #0x288
    1e1c:      	blr	x10
    1e20:      	cbz	x0, 0x1e98 <event_execve+0x1e98>
    1e24:      	neg	w8, w0
    1e28:      	mov	w9, #0x1                // =1
    1e2c:      	add	x1, sp, #0x40
    1e30:      	strh	w8, [sp, #0x40]
    1e34:      	mov	w8, #0x9                // =9
    1e38:      	mov	x0, x22
    1e3c:      	mov	w21, #0x1               // =1
    1e40:      	strh	w8, [sp, #0x42]
    1e44:      	mov	x8, #0x9a               // =154
    1e48:      	movk	x8, #0x4, lsl #32
    1e4c:      	stur	x8, [sp, #0x44]
    1e50:      	add	x8, sp, #0x40
    1e54:      	blr	x9
    1e58:      	cbz	x0, 0x1e74 <event_execve+0x1e74>
    1e5c:      	ldr	w8, [x0]
    1e60:      	add	w8, w8, #0x1
    1e64:      	str	w8, [x0]
    1e68:      	b	0x1e98 <event_execve+0x1e98>
    1e6c:      	mov	w8, wzr
    1e70:      	b	0x2228 <event_execve+0x2228>
    1e74:      	str	w21, [sp, #0xb0]
    1e78:      	mov	x3, xzr
    1e7c:      	mov	w8, #0x2                // =2
    1e80:      	add	x9, sp, #0x40
    1e84:      	add	x10, sp, #0xb0
    1e88:      	add	x1, sp, #0x40
    1e8c:      	add	x2, sp, #0xb0
    1e90:      	mov	x0, x22
    1e94:      	blr	x8
    1e98:      	ldr	x8, [sp, #0xb8]
    1e9c:      	mov	w9, #0x8                // =8
    1ea0:      	mov	w10, #0x4               // =4
    1ea4:      	add	x11, sp, #0xb0
    1ea8:      	add	x0, sp, #0xb0
    1eac:      	mov	w1, #0x8                // =8
    1eb0:      	add	x8, x8, #0x290
    1eb4:      	ldr	x8, [sp, #0xb8]
    1eb8:      	add	x2, x8, #0x290
    1ebc:      	blr	x10
    1ec0:      	cbz	x0, 0x1f08 <event_execve+0x1f08>
    1ec4:      	neg	w8, w0
    1ec8:      	mov	w9, #0x1                // =1
    1ecc:      	add	x1, sp, #0x40
    1ed0:      	strh	w8, [sp, #0x40]
    1ed4:      	mov	w8, #0x9                // =9
    1ed8:      	mov	x0, x22
    1edc:      	mov	w21, #0x1               // =1
    1ee0:      	strh	w8, [sp, #0x42]
    1ee4:      	mov	x8, #0x9b               // =155
    1ee8:      	movk	x8, #0x4, lsl #32
    1eec:      	stur	x8, [sp, #0x44]
    1ef0:      	add	x8, sp, #0x40
    1ef4:      	blr	x9
    1ef8:      	cbz	x0, 0x20e0 <event_execve+0x20e0>
    1efc:      	ldr	w8, [x0]
    1f00:      	add	w8, w8, #0x1
    1f04:      	str	w8, [x0]
    1f08:      	ldr	x21, [x24, #0x10]
    1f0c:      	mov	w8, wzr
    1f10:      	add	x10, sp, #0xb8
    1f14:      	cbz	x21, 0x2228 <event_execve+0x2228>
    1f18:      	ldr	x9, [sp, #0xb0]
    1f1c:      	cbz	x9, 0x2228 <event_execve+0x2228>
    1f20:      	add	x22, x20, w19, uxtw
    1f24:      	sub	x23, x9, x21
    1f28:      	cmp	x23, #0x3ff
    1f2c:      	b.hi	0x1f74 <event_execve+0x1f74>
    1f30:      	add	x0, x22, #0x140
    1f34:      	add	x8, x20, #0x540
    1f38:      	sub	x8, x8, x0
    1f3c:      	cmp	x23, x8
    1f40:      	b.hs	0x1f74 <event_execve+0x1f74>
    1f44:      	sub	w8, w23, #0x1
    1f48:      	cmp	x9, x21
    1f4c:      	and	w8, w8, #0x3ff
    1f50:      	csel	w19, wzr, w8, eq
    1f54:      	mov	w8, #0x4                // =4
    1f58:      	ldr	x2, [x10, #0x10]
    1f5c:      	mov	w1, w19
    1f60:      	blr	x8
    1f64:      	ands	x8, x0, #0x80000000
    1f68:      	lsr	x9, x8, #28
    1f6c:      	csel	w8, w19, wzr, eq
    1f70:      	b	0x2218 <event_execve+0x2218>
    1f74:      	str	wzr, [sp, #0xa8]
    1f78:      	adrp	x0, 0x1000 <event_execve+0x1000>
    1f7c:      	mov	w8, #0x1                // =1
    1f80:      	add	x9, sp, #0xa8
    1f84:      	ldr	x0, [x0]
    1f88:      	add	x1, sp, #0xa8
    1f8c:      	blr	x8
    1f90:      	cbz	x0, 0x2118 <event_execve+0x2118>
    1f94:      	mov	w8, #0x18               // =24
    1f98:      	str	x25, [sp, #0x30]
    1f9c:      	mov	x24, x0
    1fa0:      	str	w8, [x0]
    1fa4:      	mov	w8, #0xe                // =14
    1fa8:      	blr	x8
    1fac:      	mov	x19, x24
    1fb0:      	cmn	x0, #0x16
    1fb4:      	str	x0, [x19, #0x10]!
    1fb8:      	b.ne	0x1fe0 <event_execve+0x1fe0>
    1fbc:      	add	x2, x29, #0xe8
    1fc0:      	mov	w8, #0x8                // =8
    1fc4:      	mov	w9, #0x4                // =4
    1fc8:      	add	x10, sp, #0x40
    1fcc:      	add	x0, sp, #0x40
    1fd0:      	mov	w1, #0x8                // =8
    1fd4:      	blr	x9
    1fd8:      	ldr	x8, [sp, #0x40]
    1fdc:      	str	x8, [x19]
    1fe0:      	mov	w8, #0x7d               // =125
    1fe4:      	blr	x8
    1fe8:      	str	x0, [x24, #0x18]
    1fec:      	mov	x25, xzr
    1ff0:      	str	x24, [sp, #0xd8]
    1ff4:      	add	x24, x24, #0x20
    1ff8:      	ldp	x8, x9, [x19]
    1ffc:      	stp	x22, x23, [sp, #0x20]
    2000:      	stp	x8, x9, [x22, #0x150]
    2004:      	mov	w22, #0xa               // =10
    2008:      	subs	x8, x23, x25
    200c:      	b.mi	0x2124 <event_execve+0x2124>
    2010:      	mov	w9, #0x7fe0             // =32736
    2014:      	add	x2, x25, x21
    2018:      	mov	x0, x24
    201c:      	cmp	x8, x9
    2020:      	csel	x19, x8, x9, lo
    2024:      	mov	w8, #0x4                // =4
    2028:      	mov	w1, w19
    202c:      	blr	x8
    2030:      	tbnz	w0, #0x1f, 0x20bc <event_execve+0x20bc>
    2034:      	ldr	x8, [sp, #0xd8]
    2038:      	mov	x23, x29
    203c:      	add	w29, w19, #0x20
    2040:      	str	wzr, [sp, #0x40]
    2044:      	adrp	x0, 0x2000 <event_execve+0x2000>
    2048:      	add	x9, sp, #0x40
    204c:      	add	x1, sp, #0x40
    2050:      	str	w29, [x8, #0x4]
    2054:      	mov	w8, #0x1                // =1
    2058:      	ldr	x0, [x0]
    205c:      	blr	x8
    2060:      	cbz	x0, 0x2094 <event_execve+0x2094>
    2064:      	ldrb	w8, [x0, #0x28]
    2068:      	cbz	w8, 0x2094 <event_execve+0x2094>
    206c:      	adrp	x1, 0x2000 <event_execve+0x2000>
    2070:      	ldr	x3, [sp, #0xd8]
    2074:      	mov	w8, #0x19               // =25
    2078:      	mov	w9, #-0x1               // =-1
    207c:      	ldr	x1, [x1]
    2080:      	mov	x0, x23
    2084:      	mov	w2, #-0x1               // =-1
    2088:      	mov	x4, x29
    208c:      	blr	x8
    2090:      	b	0x20b0 <event_execve+0x20b0>
    2094:      	adrp	x0, 0x2000 <event_execve+0x2000>
    2098:      	ldr	x1, [sp, #0xd8]
    209c:      	mov	x3, xzr
    20a0:      	mov	w8, #0x82               // =130
    20a4:      	ldr	x0, [x0]
    20a8:      	mov	x2, x29
    20ac:      	blr	x8
    20b0:      	mov	x29, x23
    20b4:      	ldr	x23, [sp, #0x28]
    20b8:      	tbz	w0, #0x1f, 0x20c0 <event_execve+0x20c0>
    20bc:      	sxtw	x19, w0
    20c0:      	tbnz	w19, #0x1f, 0x212c <event_execve+0x212c>
    20c4:      	and	x8, x19, #0x7fffffff
    20c8:      	add	x25, x8, x25
    20cc:      	cmp	x25, x23
    20d0:      	b.eq	0x2178 <event_execve+0x2178>
    20d4:      	subs	w22, w22, #0x1
    20d8:      	b.ne	0x2008 <event_execve+0x2008>
    20dc:      	b	0x21d4 <event_execve+0x21d4>
    20e0:      	str	w21, [sp, #0xa8]
    20e4:      	mov	x3, xzr
    20e8:      	mov	w8, #0x2                // =2
    20ec:      	add	x9, sp, #0x40
    20f0:      	add	x10, sp, #0xa8
    20f4:      	add	x1, sp, #0x40
    20f8:      	add	x2, sp, #0xa8
    20fc:      	mov	x0, x22
    2100:      	blr	x8
    2104:      	ldr	x21, [x24, #0x10]
    2108:      	mov	w8, wzr
    210c:      	add	x10, sp, #0xb8
    2110:      	cbnz	x21, 0x1f18 <event_execve+0x1f18>
    2114:      	b	0x2228 <event_execve+0x2228>
    2118:      	mov	w9, wzr
    211c:      	mov	w8, wzr
    2120:      	b	0x2218 <event_execve+0x2218>
    2124:      	mov	x25, #-0x1              // =-1
    2128:      	b	0x2130 <event_execve+0x2130>
    212c:      	mov	x25, x19
    2130:      	str	wzr, [sp, #0x40]
    2134:      	adrp	x0, 0x2000 <event_execve+0x2000>
    2138:      	mov	w8, #0x1                // =1
    213c:      	add	x9, sp, #0x40
    2140:      	ldr	x0, [x0]
    2144:      	add	x1, sp, #0x40
    2148:      	blr	x8
    214c:      	cbz	x0, 0x21d4 <event_execve+0x21d4>
    2150:      	cmn	x25, #0xc
    2154:      	b.gt	0x2180 <event_execve+0x2180>
    2158:      	cmn	x25, #0x1c
    215c:      	b.eq	0x21a0 <event_execve+0x21a0>
    2160:      	cmn	x25, #0x16
    2164:      	b.eq	0x21b8 <event_execve+0x21b8>
    2168:      	cmn	x25, #0x10
    216c:      	b.ne	0x21b0 <event_execve+0x21b0>
    2170:      	add	x8, x0, #0x558
    2174:      	b	0x21c4 <event_execve+0x21c4>
    2178:      	mov	x25, x23
    217c:      	b	0x21d4 <event_execve+0x21d4>
    2180:      	cmn	x25, #0xb
    2184:      	b.eq	0x21a8 <event_execve+0x21a8>
    2188:      	cmn	x25, #0x7
    218c:      	b.eq	0x21c0 <event_execve+0x21c0>
    2190:      	cmn	x25, #0x2
    2194:      	b.ne	0x21b0 <event_execve+0x21b0>
    2198:      	add	x8, x0, #0x548
    219c:      	b	0x21c4 <event_execve+0x21c4>
    21a0:      	add	x8, x0, #0x568
    21a4:      	b	0x21c4 <event_execve+0x21c4>
    21a8:      	add	x8, x0, #0x570
    21ac:      	b	0x21c4 <event_execve+0x21c4>
    21b0:      	add	x8, x0, #0x540
    21b4:      	b	0x21c4 <event_execve+0x21c4>
    21b8:      	add	x8, x0, #0x560
    21bc:      	b	0x21c4 <event_execve+0x21c4>
    21c0:      	add	x8, x0, #0x550
    21c4:      	ldaxr	x9, [x8]
    21c8:      	add	x9, x9, #0x1
    21cc:      	stlxr	w10, x9, [x8]
    21d0:      	cbnz	w10, 0x21c4 <event_execve+0x21c4>
    21d4:      	tbnz	w25, #0x1f, 0x21f0 <event_execve+0x21f0>
    21d8:      	ldr	x9, [sp, #0x20]
    21dc:      	sub	w8, w23, w25
    21e0:      	cmn	x23, #0x1
    21e4:      	csel	w8, wzr, w8, eq
    21e8:      	str	xzr, [x9, #0x140]
    21ec:      	b	0x2204 <event_execve+0x2204>
    21f0:      	ldr	x9, [sp, #0x20]
    21f4:      	mov	w8, wzr
    21f8:      	str	w25, [x9, #0x140]
    21fc:      	str	wzr, [x9, #0x144]
    2200:      	mov	w25, wzr
    2204:      	str	w25, [x9, #0x14c]
    2208:      	ldr	x25, [sp, #0x30]
    220c:      	str	w8, [x9, #0x148]
    2210:      	mov	w8, #0x20               // =32
    2214:      	mov	w9, #0x2                // =2
    2218:      	ldr	w10, [x20, #0x15c]
    221c:      	strh	w8, [x20, #0x17e]
    2220:      	orr	w9, w10, w9
    2224:      	str	w9, [x20, #0x15c]
    2228:      	ldr	w9, [x20, #0x140]
    222c:      	add	x23, x25, #0xae0
    2230:      	mov	w22, #0x8               // =8
    2234:      	add	x0, sp, #0x40
    2238:      	mov	w1, #0x8                // =8
    223c:      	add	x19, x20, #0xb8
    2240:      	mov	w21, #0x4               // =4
    2244:      	mov	x2, x23
    2248:      	add	w8, w9, w8
    224c:      	mov	w9, #0x5                // =5
    2250:      	strh	w9, [x20]
    2254:      	ldr	x9, [x20, #0x170]
    2258:      	str	w8, [x20, #0x140]
    225c:      	add	w8, w8, #0x140
    2260:      	str	w8, [x20, #0x4]
    2264:      	add	x8, sp, #0x40
    2268:      	str	x9, [x20, #0x8]
    226c:      	mov	w9, #0x4                // =4
    2270:      	blr	x9
    2274:      	ldr	x8, [sp, #0x40]
    2278:      	mov	w9, #0x4                // =4
    227c:      	mov	x0, x19
    2280:      	mov	w1, #0x4                // =4
    2284:      	add	x8, x8, #0x8
    2288:      	ldr	x8, [sp, #0x40]
    228c:      	add	x2, x8, #0x8
    2290:      	blr	x9
    2294:      	ldr	x8, [sp, #0x40]
    2298:      	add	x0, x20, #0xbc
    229c:      	mov	w9, #0x4                // =4
    22a0:      	mov	w1, #0x4                // =4
    22a4:      	add	x8, x8, #0xc
    22a8:      	ldr	x8, [sp, #0x40]
    22ac:      	add	x2, x8, #0xc
    22b0:      	blr	x9
    22b4:      	ldr	x8, [sp, #0x40]
    22b8:      	add	x0, x20, #0xc8
    22bc:      	mov	w9, #0x4                // =4
    22c0:      	mov	w1, #0x4                // =4
    22c4:      	add	x8, x8, #0x18
    22c8:      	ldr	x8, [sp, #0x40]
    22cc:      	add	x2, x8, #0x18
    22d0:      	blr	x9
    22d4:      	ldr	x8, [sp, #0x40]
    22d8:      	add	x0, x20, #0xcc
    22dc:      	mov	w9, #0x4                // =4
    22e0:      	mov	w1, #0x4                // =4
    22e4:      	add	x8, x8, #0x1c
    22e8:      	ldr	x8, [sp, #0x40]
    22ec:      	add	x2, x8, #0x1c
    22f0:      	blr	x9
    22f4:      	ldr	x8, [sp, #0x40]
    22f8:      	add	x0, x20, #0xc0
    22fc:      	mov	w9, #0x4                // =4
    2300:      	mov	w1, #0x4                // =4
    2304:      	add	x8, x8, #0x10
    2308:      	ldr	x8, [sp, #0x40]
    230c:      	add	x2, x8, #0x10
    2310:      	blr	x9
    2314:      	ldr	x8, [sp, #0x40]
    2318:      	add	x0, x20, #0xc4
    231c:      	mov	w9, #0x4                // =4
    2320:      	mov	w1, #0x4                // =4
    2324:      	add	x8, x8, #0x14
    2328:      	ldr	x8, [sp, #0x40]
    232c:      	add	x2, x8, #0x14
    2330:      	blr	x9
    2334:      	ldr	x8, [sp, #0x40]
    2338:      	add	x0, x20, #0xd0
    233c:      	mov	w9, #0x4                // =4
    2340:      	mov	w1, #0x4                // =4
    2344:      	add	x8, x8, #0x20
    2348:      	ldr	x8, [sp, #0x40]
    234c:      	add	x2, x8, #0x20
    2350:      	blr	x9
    2354:      	ldr	x8, [sp, #0x40]
    2358:      	add	x0, x20, #0xd4
    235c:      	mov	w9, #0x4                // =4
    2360:      	mov	w1, #0x4                // =4
    2364:      	add	x8, x8, #0x24
    2368:      	ldr	x8, [sp, #0x40]
    236c:      	add	x2, x8, #0x24
    2370:      	blr	x9
    2374:      	ldr	x8, [sp, #0x40]
    2378:      	add	x0, x20, #0xd8
    237c:      	mov	w9, #0x4                // =4
    2380:      	mov	w1, #0x4                // =4
    2384:      	add	x8, x8, #0x28
    2388:      	ldr	x8, [sp, #0x40]
    238c:      	add	x2, x8, #0x28
    2390:      	blr	x9
    2394:      	ldr	x24, [sp, #0x40]
    2398:      	add	x0, x20, #0xe8
    239c:      	mov	w8, #0x4                // =4
    23a0:      	mov	w1, #0x8                // =8
    23a4:      	add	x19, x20, #0xe0
    23a8:      	add	x2, x24, #0x40
    23ac:      	blr	x8
    23b0:      	add	x0, x20, #0xf0
    23b4:      	add	x2, x24, #0x30
    23b8:      	mov	w8, #0x4                // =4
    23bc:      	mov	w1, #0x8                // =8
    23c0:      	blr	x8
    23c4:      	add	x2, x24, #0x38
    23c8:      	mov	w8, #0x4                // =4
    23cc:      	mov	x0, x19
    23d0:      	mov	w1, #0x8                // =8
    23d4:      	blr	x8
    23d8:      	ldr	w8, [x20, #0xc8]
    23dc:      	add	x2, x25, #0xb50
    23e0:      	mov	w9, #0x4                // =4
    23e4:      	add	x0, sp, #0xc8
    23e8:      	str	w8, [x20, #0x154]
    23ec:      	add	x8, sp, #0xc8
    23f0:      	mov	w1, #0x8                // =8
    23f4:      	add	x19, x20, #0x108
    23f8:      	blr	x9
    23fc:      	add	x24, sp, #0xb8
    2400:      	mov	w9, #0x48               // =72
    2404:      	add	x10, sp, #0x40
    2408:      	ldr	x8, [x24, #0x10]
    240c:      	mov	w11, #0x4               // =4
    2410:      	add	x0, sp, #0x40
    2414:      	mov	w1, #0x48               // =72
    2418:      	ldr	x2, [x24, #0x10]
    241c:      	blr	x11
    2420:      	ldr	x8, [sp, #0x48]
    2424:      	mov	w9, #0x4                // =4
    2428:      	mov	x0, x19
    242c:      	mov	w1, #0x4                // =4
    2430:      	add	x8, x8, #0x218
    2434:      	ldr	x8, [sp, #0x48]
    2438:      	add	x2, x8, #0x218
    243c:      	blr	x9
    2440:      	ldr	x8, [sp, #0x50]
    2444:      	add	x0, x20, #0x10c
    2448:      	mov	w9, #0x4                // =4
    244c:      	mov	w1, #0x4                // =4
    2450:      	add	x8, x8, #0x4d8
    2454:      	ldr	x8, [sp, #0x50]
    2458:      	add	x2, x8, #0x4d8
    245c:      	blr	x9
    2460:      	ldr	x8, [sp, #0x58]
    2464:      	add	x0, x20, #0x110
    2468:      	mov	w9, #0x4                // =4
    246c:      	mov	w1, #0x4                // =4
    2470:      	add	x8, x8, #0x58
    2474:      	ldr	x8, [sp, #0x58]
    2478:      	add	x2, x8, #0x58
    247c:      	blr	x9
    2480:      	str	xzr, [sp, #0xb0]
    2484:      	add	x2, x25, #0x938
    2488:      	add	x8, sp, #0xb0
    248c:      	add	x0, sp, #0xb0
    2490:      	mov	w1, #0x8                // =8
    2494:      	blr	x21
    2498:      	ldr	x8, [sp, #0xb0]
    249c:      	cbz	x8, 0x2520 <event_execve+0x2520>
    24a0:      	str	wzr, [sp, #0xa8]
    24a4:      	add	x8, x8, #0x4
    24a8:      	add	x9, sp, #0xa8
    24ac:      	mov	w10, #0x4               // =4
    24b0:      	add	x0, sp, #0xa8
    24b4:      	mov	w1, #0x4                // =4
    24b8:      	mov	w19, #0x4               // =4
    24bc:      	ldr	x8, [sp, #0xb0]
    24c0:      	add	x2, x8, #0x4
    24c4:      	blr	x10
    24c8:      	ldr	x8, [sp, #0xb0]
    24cc:      	ldrsw	x9, [sp, #0xa8]
    24d0:      	add	x10, sp, #0xb8
    24d4:      	mov	w11, #0x4               // =4
    24d8:      	add	x0, sp, #0xb8
    24dc:      	mov	w1, #0x10               // =16
    24e0:      	add	x8, x8, x9, lsl #4
    24e4:      	mov	w9, #0x10               // =16
    24e8:      	add	x8, x8, #0x80
    24ec:      	ldr	x8, [sp, #0xb0]
    24f0:      	ldrsw	x9, [sp, #0xa8]
    24f4:      	add	x8, x8, x9, lsl #4
    24f8:      	add	x2, x8, #0x80
    24fc:      	blr	x11
    2500:      	ldr	x8, [x24, #0x8]
    2504:      	add	x0, x20, #0x114
    2508:      	mov	w1, #0x4                // =4
    250c:      	add	x8, x8, #0x158
    2510:      	ldr	x8, [x24, #0x8]
    2514:      	add	x2, x8, #0x158
    2518:      	blr	x19
    251c:      	b	0x2524 <event_execve+0x2524>
    2520:      	str	wzr, [x20, #0x114]
    2524:      	ldr	x8, [sp, #0x60]
    2528:      	add	x0, x20, #0x118
    252c:      	mov	w9, #0x4                // =4
    2530:      	mov	w1, #0x4                // =4
    2534:      	mov	w19, #0x4               // =4
    2538:      	add	x8, x8, #0x158
    253c:      	ldr	x8, [sp, #0x60]
    2540:      	add	x2, x8, #0x158
    2544:      	blr	x9
    2548:      	ldr	x8, [sp, #0x68]
    254c:      	add	x0, x20, #0x11c
    2550:      	mov	w9, #0x4                // =4
    2554:      	mov	w1, #0x4                // =4
    2558:      	add	x8, x8, #0x118
    255c:      	ldr	x8, [sp, #0x68]
    2560:      	add	x2, x8, #0x118
    2564:      	blr	x9
    2568:      	ldr	x8, [sp, #0x70]
    256c:      	add	x0, x20, #0x120
    2570:      	mov	w9, #0x4                // =4
    2574:      	mov	w1, #0x4                // =4
    2578:      	add	x8, x8, #0x98
    257c:      	ldr	x8, [sp, #0x70]
    2580:      	add	x2, x8, #0x98
    2584:      	blr	x9
    2588:      	ldr	x8, [sp, #0x78]
    258c:      	add	x0, x20, #0x124
    2590:      	mov	w9, #0x4                // =4
    2594:      	mov	w1, #0x4                // =4
    2598:      	add	x8, x8, #0x98
    259c:      	ldr	x8, [sp, #0x78]
    25a0:      	add	x2, x8, #0x98
    25a4:      	blr	x9
    25a8:      	ldr	x8, [sp, #0x80]
    25ac:      	add	x0, x20, #0x128
    25b0:      	mov	w9, #0x4                // =4
    25b4:      	mov	w1, #0x4                // =4
    25b8:      	add	x8, x8, #0x58
    25bc:      	ldr	x8, [sp, #0x80]
    25c0:      	add	x2, x8, #0x58
    25c4:      	blr	x9
    25c8:      	stp	xzr, xzr, [sp, #0xb0]
    25cc:      	mov	w21, #0x8               // =8
    25d0:      	add	x8, sp, #0xb8
    25d4:      	mov	w9, #0x4                // =4
    25d8:      	add	x0, sp, #0xb8
    25dc:      	mov	w1, #0x8                // =8
    25e0:      	mov	x2, x23
    25e4:      	blr	x9
    25e8:      	ldr	x8, [sp, #0xb8]
    25ec:      	add	x9, sp, #0xb0
    25f0:      	mov	w10, #0x4               // =4
    25f4:      	add	x0, sp, #0xb0
    25f8:      	mov	w1, #0x8                // =8
    25fc:      	add	x8, x8, #0x90
    2600:      	ldr	x8, [sp, #0xb8]
    2604:      	add	x2, x8, #0x90
    2608:      	blr	x10
    260c:      	ldr	x8, [sp, #0xb0]
    2610:      	add	x0, x20, #0x12c
    2614:      	mov	w1, #0x4                // =4
    2618:      	add	x8, x8, #0x158
    261c:      	ldr	x8, [sp, #0xb0]
    2620:      	add	x2, x8, #0x158
    2624:      	blr	x19
    2628:      	mov	x19, x20
    262c:      	str	wzr, [sp, #0xb0]
    2630:      	adrp	x0, 0x2000 <event_execve+0x2000>
    2634:      	mov	w8, #0x1                // =1
    2638:      	add	x9, sp, #0xb0
    263c:      	add	x1, sp, #0xb0
    2640:      	stp	xzr, xzr, [x19, #0x10]!
    2644:      	stp	xzr, xzr, [x19, #0x10]
    2648:      	stp	xzr, xzr, [x19, #0x20]
    264c:      	stp	xzr, xzr, [x19, #0x30]
    2650:      	stp	xzr, xzr, [x19, #0x40]
    2654:      	stp	xzr, xzr, [x19, #0x50]
    2658:      	stp	xzr, xzr, [x19, #0x60]
    265c:      	stp	xzr, xzr, [x19, #0x70]
    2660:      	stp	xzr, xzr, [x19, #0x80]
    2664:      	ldr	x0, [x0]
    2668:      	blr	x8
    266c:      	cbz	x0, 0x268c <event_execve+0x268c>
    2670:      	ldr	x8, [x0, #0x20]
    2674:      	ldr	w21, [x0, #0x10]
    2678:      	mov	w9, #0x7270             // =29296
    267c:      	movk	w9, #0x6367, lsl #16
    2680:      	cmp	x8, x9
    2684:      	cset	w22, eq
    2688:      	b	0x2694 <event_execve+0x2694>
    268c:      	mov	w21, wzr
    2690:      	mov	w22, wzr
    2694:      	str	xzr, [x24, #0x10]
    2698:      	add	x2, x25, #0xcd0
    269c:      	mov	w8, #0x8                // =8
    26a0:      	mov	w9, #0x71               // =113
    26a4:      	add	x10, sp, #0xb8
    26a8:      	add	x0, sp, #0xb8
    26ac:      	mov	w1, #0x8                // =8
    26b0:      	blr	x9
    26b4:      	ldr	x8, [sp, #0xb8]
    26b8:      	cbz	x8, 0x2880 <event_execve+0x2880>
    26bc:      	cbz	w22, 0x272c <event_execve+0x272c>
    26c0:      	add	x8, x8, #0x78
    26c4:      	mov	w9, #0x8                // =8
    26c8:      	mov	w10, #0x71              // =113
    26cc:      	add	x11, sp, #0xc8
    26d0:      	ldr	x8, [sp, #0xb8]
    26d4:      	add	x0, sp, #0xc8
    26d8:      	mov	w1, #0x8                // =8
    26dc:      	add	x2, x8, #0x78
    26e0:      	blr	x10
    26e4:      	ldr	x22, [x24, #0x10]
    26e8:      	cbz	x22, 0x2880 <event_execve+0x2880>
    26ec:      	mov	w8, #0x50               // =80
    26f0:      	blr	x8
    26f4:      	mov	w21, wzr
    26f8:      	str	x0, [x19]
    26fc:      	cbz	x0, 0x27e0 <event_execve+0x27e0>
    2700:      	str	x0, [sp, #0x40]
    2704:      	adrp	x0, 0x2000 <event_execve+0x2000>
    2708:      	mov	w8, #0x1                // =1
    270c:      	add	x9, sp, #0x40
    2710:      	ldr	x0, [x0]
    2714:      	add	x1, sp, #0x40
    2718:      	blr	x8
    271c:      	cbz	x0, 0x27e8 <event_execve+0x27e8>
    2720:      	ldr	x8, [x0]
    2724:      	str	x8, [x20, #0x18]
    2728:      	b	0x27f0 <event_execve+0x27f0>
    272c:      	cmp	w21, #0xb
    2730:      	b.hi	0x2880 <event_execve+0x2880>
    2734:      	ubfiz	x9, x21, #3, #32
    2738:      	mov	w10, #0x8               // =8
    273c:      	mov	w11, #0x71              // =113
    2740:      	add	x12, sp, #0x40
    2744:      	add	x0, sp, #0x40
    2748:      	mov	w1, #0x8                // =8
    274c:      	add	x8, x8, x9
    2750:      	ldr	x8, [sp, #0xb8]
    2754:      	add	x2, x8, x9
    2758:      	blr	x11
    275c:      	ldr	x8, [sp, #0x40]
    2760:      	cbz	x8, 0x2870 <event_execve+0x2870>
    2764:      	mov	w9, #0x8                // =8
    2768:      	mov	w10, #0x71              // =113
    276c:      	add	x11, sp, #0xc8
    2770:      	ldr	x2, [sp, #0x40]
    2774:      	add	x0, sp, #0xc8
    2778:      	mov	w1, #0x8                // =8
    277c:      	blr	x10
    2780:      	ldr	x22, [x24, #0x10]
    2784:      	cbz	x22, 0x2880 <event_execve+0x2880>
    2788:      	mov	w21, wzr
    278c:      	str	xzr, [sp, #0x40]
    2790:      	add	x2, x22, #0x100
    2794:      	mov	w8, #0x8                // =8
    2798:      	mov	w9, #0x71               // =113
    279c:      	add	x10, sp, #0x40
    27a0:      	add	x0, sp, #0x40
    27a4:      	mov	w1, #0x8                // =8
    27a8:      	blr	x9
    27ac:      	ldr	x8, [sp, #0x40]
    27b0:      	str	xzr, [sp, #0x40]
    27b4:      	cbz	x8, 0x2860 <event_execve+0x2860>
    27b8:      	add	x2, x8, #0x60
    27bc:      	mov	w8, #0x8                // =8
    27c0:      	mov	w9, #0x71               // =113
    27c4:      	add	x10, sp, #0x40
    27c8:      	add	x0, sp, #0x40
    27cc:      	mov	w1, #0x8                // =8
    27d0:      	blr	x9
    27d4:      	ldr	x0, [sp, #0x40]
    27d8:      	str	x0, [x19]
    27dc:      	cbnz	x0, 0x2700 <event_execve+0x2700>
    27e0:      	orr	w21, w21, #0x200000
    27e4:      	b	0x27f0 <event_execve+0x27f0>
    27e8:      	mov	x8, xzr
    27ec:      	str	xzr, [x20, #0x18]
    27f0:      	add	x2, x22, #0x100
    27f4:      	mov	w19, #0x8               // =8
    27f8:      	add	x8, sp, #0xb8
    27fc:      	mov	w9, #0x4                // =4
    2800:      	add	x0, sp, #0xb8
    2804:      	mov	w1, #0x8                // =8
    2808:      	mov	w22, #0x4               // =4
    280c:      	blr	x9
    2810:      	ldr	x8, [sp, #0xb8]
    2814:      	add	x9, sp, #0x40
    2818:      	add	x0, sp, #0x40
    281c:      	mov	w1, #0x8                // =8
    2820:      	add	x8, x8, #0x10
    2824:      	ldr	x8, [sp, #0xb8]
    2828:      	add	x2, x8, #0x10
    282c:      	blr	x22
    2830:      	mov	w8, #0x10000            // =65536
    2834:      	cbnz	x0, 0x2858 <event_execve+0x2858>
    2838:      	ldr	x2, [sp, #0x40]
    283c:      	cbz	x2, 0x2858 <event_execve+0x2858>
    2840:      	add	x0, x20, #0x20
    2844:      	mov	w8, #0x80               // =128
    2848:      	mov	w9, #0x2d               // =45
    284c:      	mov	w1, #0x80               // =128
    2850:      	blr	x9
    2854:      	mov	w8, wzr
    2858:      	orr	w8, w8, w21
    285c:      	b	0x2884 <event_execve+0x2884>
    2860:      	mov	x0, xzr
    2864:      	str	xzr, [x19]
    2868:      	cbnz	xzr, 0x2700 <event_execve+0x2700>
    286c:      	b	0x27e0 <event_execve+0x27e0>
    2870:      	ldr	x22, [x24, #0x10]
    2874:      	cbz	x22, 0x2880 <event_execve+0x2880>
    2878:      	mov	w21, #0x80000           // =524288
    287c:      	b	0x278c <event_execve+0x278c>
    2880:      	mov	w8, wzr
    2884:      	ldr	w10, [x20, #0x15c]
    2888:      	stp	xzr, xzr, [x20, #0x130]
    288c:      	adrp	x1, 0x2000 <event_execve+0x2000>
    2890:      	mov	x9, xzr
    2894:      	mov	x0, x29
    2898:      	mov	w2, wzr
    289c:      	orr	w8, w10, w8
    28a0:      	str	w8, [x20, #0x15c]
    28a4:      	mov	w8, #0xc                // =12
    28a8:      	ldr	x1, [x1]
    28ac:      	blr	x8
    28b0:      	ldp	x20, x19, [sp, #0x110]
    28b4:      	mov	w0, wzr
    28b8:      	ldr	x29, [sp, #0xd0]
    28bc:      	ldp	x22, x21, [sp, #0x100]
    28c0:      	ldp	x24, x23, [sp, #0xf0]
    28c4:      	ldp	x30, x25, [sp, #0xe0]
    28c8:      	add	sp, sp, #0x120
    28cc:      	ret
