
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/otel/off_cpu.native.o:	file format elf64-littleaarch64

Disassembly of section tracepoint/sched/sched_switch:

0000000000000000 <tracepoint__sched_switch>:
       0:      	sub	sp, sp, #0x50
       4:      	str	x30, [sp, #0x40]
       8:      	mov	w8, #0xe                // =14
       c:      	blr	x8
      10:      	lsr	x9, x0, #32
      14:      	and	x8, x0, #0xffffffff
      18:      	str	x0, [sp, #0x48]
      1c:      	cmp	x9, #0x0
      20:      	ccmp	x8, #0x0, #0x4, ne
      24:      	b.eq	0x88 <tracepoint__sched_switch+0x88>
      28:      	mov	w8, #0x7                // =7
      2c:      	blr	x8
      30:      	adrp	x8, 0x0 <tracepoint__sched_switch>
      34:      	ldr	x8, [x8]
      38:      	ldr	w8, [x8]
      3c:      	cmp	x0, x8
      40:      	b.hi	0x88 <tracepoint__sched_switch+0x88>
      44:      	mov	w8, #0x5                // =5
      48:      	blr	x8
      4c:      	str	x0, [sp, #0x38]
      50:      	adrp	x0, 0x0 <tracepoint__sched_switch>
      54:      	mov	x3, xzr
      58:      	mov	w8, #0x2                // =2
      5c:      	ldr	x0, [x0]
      60:      	add	x9, sp, #0x48
      64:      	add	x10, sp, #0x38
      68:      	add	x1, sp, #0x48
      6c:      	add	x2, sp, #0x38
      70:      	blr	x8
      74:      	tbz	w0, #0x1f, 0x88 <tracepoint__sched_switch+0x88>
      78:      	adrp	x8, 0x0 <tracepoint__sched_switch>
      7c:      	ldr	x8, [x8]
      80:      	ldr	w8, [x8]
      84:      	cbnz	w8, 0x98 <tracepoint__sched_switch+0x98>
      88:      	ldr	x30, [sp, #0x40]
      8c:      	mov	w0, wzr
      90:      	add	sp, sp, #0x50
      94:      	ret
      98:      	mov	w8, #0x7972             // =31090
      9c:      	add	x0, sp, #0x8
      a0:      	mov	w1, #0x2b               // =43
      a4:      	movk	w8, #0xa, lsl #16
      a8:      	stur	w8, [sp, #0x2f]
      ac:      	adrp	x8, 0x0 <tracepoint__sched_switch>
      b0:      	add	x8, x8, #0x0
      b4:      	ldp	x9, x10, [x8, #0x10]
      b8:      	stp	x9, x10, [sp, #0x18]
      bc:      	ldr	x9, [x8, #0x20]
      c0:      	add	x10, sp, #0x8
      c4:      	str	x9, [sp, #0x28]
      c8:      	ldp	x8, x9, [x8]
      cc:      	stp	x8, x9, [sp, #0x8]
      d0:      	mov	w8, #0x2b               // =43
      d4:      	mov	w9, #0x6                // =6
      d8:      	blr	x9
      dc:      	ldr	x30, [sp, #0x40]
      e0:      	mov	w0, wzr
      e4:      	add	sp, sp, #0x50
      e8:      	ret

Disassembly of section kprobe/dummy:

0000000000000000 <kprobe__dummy>:
       0:      	str	x30, [sp, #-0x10]!
       4:      	adrp	x1, 0x0 <kprobe__dummy>
       8:      	mov	x8, xzr
       c:      	mov	w9, #0xc                // =12
      10:      	ldr	x1, [x1]
      14:      	mov	w2, wzr
      18:      	blr	x9
      1c:      	mov	w0, wzr
      20:      	ldr	x30, [sp], #0x10
      24:      	ret

Disassembly of section kprobe/finish_task_switch:

0000000000000000 <finish_task_switch>:
       0:      	sub	sp, sp, #0x1f0
       4:      	str	x29, [sp, #0x1a0]
       8:      	stp	x30, x25, [sp, #0x1b0]
       c:      	stp	x24, x23, [sp, #0x1c0]
      10:      	stp	x22, x21, [sp, #0x1d0]
      14:      	stp	x20, x19, [sp, #0x1e0]
      18:      	mov	w8, #0xe                // =14
      1c:      	mov	x19, x0
      20:      	blr	x8
      24:      	mov	x23, x0
      28:      	lsr	x22, x0, #32
      2c:      	str	x0, [sp, #0x8]
      30:      	cmp	w23, #0x0
      34:      	ccmp	w22, #0x0, #0x4, ne
      38:      	b.ne	0x44 <finish_task_switch+0x44>
      3c:      	mov	w0, wzr
      40:      	b	0x538 <finish_task_switch+0x538>
      44:      	mov	w8, #0x5                // =5
      48:      	blr	x8
      4c:      	adrp	x20, 0x0 <finish_task_switch>
      50:      	mov	w8, #0x1                // =1
      54:      	add	x9, sp, #0x8
      58:      	ldr	x20, [x20]
      5c:      	mov	x24, x0
      60:      	add	x1, sp, #0x8
      64:      	mov	x0, x20
      68:      	blr	x8
      6c:      	cbz	x0, 0x538 <finish_task_switch+0x538>
      70:      	ldr	x8, [x0]
      74:      	mov	x21, x0
      78:      	cbz	x8, 0x3c <finish_task_switch+0x3c>
      7c:      	mov	w8, #0x3                // =3
      80:      	add	x9, sp, #0x8
      84:      	add	x1, sp, #0x8
      88:      	mov	x0, x20
      8c:      	blr	x8
      90:      	adrp	x25, 0x0 <finish_task_switch>
      94:      	ldr	x29, [x21]
      98:      	ldr	x25, [x25]
      9c:      	ldr	w8, [x25]
      a0:      	cbnz	w8, 0x2ec <finish_task_switch+0x2ec>
      a4:      	str	wzr, [sp, #0x10]
      a8:      	adrp	x20, 0x0 <finish_task_switch>
      ac:      	mov	w8, #0x1                // =1
      b0:      	add	x9, sp, #0x10
      b4:      	ldr	x20, [x20]
      b8:      	add	x1, sp, #0x10
      bc:      	mov	x0, x20
      c0:      	blr	x8
      c4:      	cbz	x0, 0x534 <finish_task_switch+0x534>
      c8:      	mov	w8, #-0x1               // =-1
      cc:      	mov	w9, #0x100              // =256
      d0:      	mov	x21, x0
      d4:      	strh	wzr, [x0, #0xf20]
      d8:      	str	xzr, [x0, #0xed0]
      dc:      	mov	w1, wzr
      e0:      	str	xzr, [x0, #0xed8]
      e4:      	str	xzr, [x0, #0xee0]
      e8:      	mov	w2, #0x29c              // =668
      ec:      	sub	x29, x24, x29
      f0:      	str	xzr, [x0, #0xee8]
      f4:      	str	xzr, [x0, #0xef0]
      f8:      	str	xzr, [x0, #0xef8]
      fc:      	str	x8, [x0, #0xf18]
     100:      	str	wzr, [x0, #0x1370]
     104:      	strh	w9, [x0, #0x1374]
     108:      	add	x9, x0, #0x2bc
     10c:      	str	xzr, [x0, #0xf28]
     110:      	str	xzr, [x0, #0xf30]
     114:      	str	xzr, [x0, #0xf48]
     118:      	str	xzr, [x0, #0xf50]
     11c:      	str	xzr, [x0, #0xf58]
     120:      	str	xzr, [x0, #0xf60]
     124:      	str	xzr, [x0, #0xf68]
     128:      	add	x0, x0, #0x20
     12c:      	str	x8, [x9]
     130:      	bl	0x130 <finish_task_switch+0x130>
     134:      	mov	w8, #0x2                // =2
     138:      	stp	w22, w23, [x21]
     13c:      	str	x24, [x21, #0x8]
     140:      	add	x0, x21, #0x10
     144:      	mov	w1, #0x10               // =16
     148:      	str	w8, [x21, #0x2c4]
     14c:      	str	x29, [x21, #0x2c8]
     150:      	mov	w8, #0x10               // =16
     154:      	blr	x8
     158:      	tbz	w0, #0x1f, 0x198 <finish_task_switch+0x198>
     15c:      	mov	w8, #0x34               // =52
     160:      	adrp	x0, 0x0 <finish_task_switch>
     164:      	add	x9, sp, #0x160
     168:      	str	w8, [sp, #0x160]
     16c:      	mov	w8, #0x1                // =1
     170:      	add	x1, sp, #0x160
     174:      	ldr	x0, [x0]
     178:      	blr	x8
     17c:      	cbz	x0, 0x190 <finish_task_switch+0x190>
     180:      	ldr	x8, [x0]
     184:      	add	x8, x8, #0x1
     188:      	str	x8, [x0]
     18c:      	b	0x198 <finish_task_switch+0x198>
     190:      	ldr	w8, [x25]
     194:      	cbnz	w8, 0xa14 <finish_task_switch+0xa14>
     198:      	adrp	x1, 0x0 <finish_task_switch>
     19c:      	mov	w8, #0x400              // =1024
     1a0:      	mov	w9, #0x1b               // =27
     1a4:      	ldr	x1, [x1]
     1a8:      	mov	x0, x19
     1ac:      	mov	w2, #0x400              // =1024
     1b0:      	blr	x9
     1b4:      	ldr	w8, [x25]
     1b8:      	str	w0, [x21, #0x2bc]
     1bc:      	cbnz	w8, 0x360 <finish_task_switch+0x360>
     1c0:      	ldr	x8, [x19, #0x108]
     1c4:      	tst	x8, #0xf
     1c8:      	b.eq	0x3a0 <finish_task_switch+0x3a0>
     1cc:      	mov	w8, #0x23               // =35
     1d0:      	blr	x8
     1d4:      	adrp	x8, 0x0 <finish_task_switch>
     1d8:      	mov	w9, #0x71               // =113
     1dc:      	add	x10, sp, #0x10
     1e0:      	ldr	x8, [x8]
     1e4:      	mov	w1, #0x8                // =8
     1e8:      	ldr	w8, [x8]
     1ec:      	add	x2, x0, x8
     1f0:      	mov	w8, #0x8                // =8
     1f4:      	add	x0, sp, #0x10
     1f8:      	blr	x9
     1fc:      	cbnz	x0, 0x234 <finish_task_switch+0x234>
     200:      	adrp	x9, 0x0 <finish_task_switch>
     204:      	ldr	x8, [sp, #0x10]
     208:      	ldr	x9, [x9]
     20c:      	ldr	w9, [x9]
     210:      	add	x2, x8, x9
     214:      	cbz	x2, 0x234 <finish_task_switch+0x234>
     218:      	mov	w8, #0x150              // =336
     21c:      	mov	w9, #0x71               // =113
     220:      	add	x10, sp, #0x10
     224:      	add	x0, sp, #0x10
     228:      	mov	w1, #0x150              // =336
     22c:      	blr	x9
     230:      	cbz	x0, 0x27c <finish_task_switch+0x27c>
     234:      	mov	w8, #0x52               // =82
     238:      	adrp	x0, 0x0 <finish_task_switch>
     23c:      	add	x9, sp, #0x198
     240:      	str	w8, [sp, #0x198]
     244:      	mov	w8, #0x1                // =1
     248:      	add	x1, sp, #0x198
     24c:      	ldr	x0, [x0]
     250:      	blr	x8
     254:      	cbz	x0, 0x268 <finish_task_switch+0x268>
     258:      	ldr	x8, [x0]
     25c:      	add	x8, x8, #0x1
     260:      	str	x8, [x0]
     264:      	b	0x270 <finish_task_switch+0x270>
     268:      	ldr	w8, [x25]
     26c:      	cbnz	w8, 0x9c8 <finish_task_switch+0x9c8>
     270:      	mov	w22, wzr
     274:      	mov	w8, #0xfa9              // =4009
     278:      	b	0x464 <finish_task_switch+0x464>
     27c:      	ldr	x8, [sp, #0x118]
     280:      	tst	x8, #0xf
     284:      	b.eq	0x294 <finish_task_switch+0x294>
     288:      	mov	w22, wzr
     28c:      	mov	w8, wzr
     290:      	b	0x464 <finish_task_switch+0x464>
     294:      	tbnz	w8, #0x4, 0x45c <finish_task_switch+0x45c>
     298:      	ldp	x10, x8, [sp, #0x100]
     29c:      	str	x8, [x21, #0xed8]
     2a0:      	ldp	x9, x11, [sp, #0xf0]
     2a4:      	ldr	x8, [sp, #0xc0]
     2a8:      	str	x11, [x21, #0xee0]
     2ac:      	str	x8, [x21, #0xef0]
     2b0:      	adrp	x8, 0x0 <finish_task_switch>
     2b4:      	ldr	x8, [x8]
     2b8:      	str	x9, [x21, #0xef8]
     2bc:      	ldr	x9, [sp, #0x110]
     2c0:      	strb	wzr, [x21, #0xf21]
     2c4:      	ldr	x8, [x8]
     2c8:      	and	x9, x8, x9
     2cc:      	and	x8, x10, x8
     2d0:      	str	x8, [x21, #0xee8]
     2d4:      	ldr	w8, [sp, #0x128]
     2d8:      	str	x9, [x21, #0xed0]
     2dc:      	cmn	w8, #0x1
     2e0:      	cset	w8, ne
     2e4:      	strb	w8, [x21, #0xf20]
     2e8:      	b	0x3ec <finish_task_switch+0x3ec>
     2ec:      	adrp	x8, 0x0 <finish_task_switch>
     2f0:      	add	x8, x8, #0x0
     2f4:      	add	x0, sp, #0x10
     2f8:      	ldp	x9, x10, [x8]
     2fc:      	mov	w1, #0x1e               // =30
     300:      	stp	x9, x10, [sp, #0x10]
     304:      	ldr	x9, [x8, #0x10]
     308:      	ldur	x8, [x8, #0x16]
     30c:      	add	x10, sp, #0x10
     310:      	str	x9, [sp, #0x20]
     314:      	stur	x8, [sp, #0x26]
     318:      	mov	w8, #0x1e               // =30
     31c:      	mov	w9, #0x6                // =6
     320:      	blr	x9
     324:      	ldr	w8, [x25]
     328:      	cbz	w8, 0xa4 <finish_task_switch+0xa4>
     32c:      	adrp	x8, 0x0 <finish_task_switch>
     330:      	add	x8, x8, #0x0
     334:      	add	x0, sp, #0x10
     338:      	ldp	x9, x10, [x8]
     33c:      	ldur	x8, [x8, #0xe]
     340:      	mov	w1, #0x16               // =22
     344:      	stp	x9, x10, [sp, #0x10]
     348:      	stur	x8, [sp, #0x1e]
     34c:      	mov	w8, #0x16               // =22
     350:      	mov	w9, #0x6                // =6
     354:      	add	x10, sp, #0x10
     358:      	blr	x9
     35c:      	b	0xa4 <finish_task_switch+0xa4>
     360:      	adrp	x8, 0x0 <finish_task_switch>
     364:      	add	x8, x8, #0x0
     368:      	add	x0, sp, #0x10
     36c:      	ldp	x9, x10, [x8]
     370:      	ldur	x8, [x8, #0xe]
     374:      	mov	w1, #0x16               // =22
     378:      	stp	x9, x10, [sp, #0x10]
     37c:      	stur	x8, [sp, #0x1e]
     380:      	mov	w8, #0x16               // =22
     384:      	mov	w9, #0x6                // =6
     388:      	add	x10, sp, #0x10
     38c:      	ldr	w2, [x21, #0x2bc]
     390:      	blr	x9
     394:      	ldr	x8, [x19, #0x108]
     398:      	tst	x8, #0xf
     39c:      	b.ne	0x1cc <finish_task_switch+0x1cc>
     3a0:      	tbnz	w8, #0x4, 0x45c <finish_task_switch+0x45c>
     3a4:      	adrp	x8, 0x0 <finish_task_switch>
     3a8:      	ldr	x8, [x8]
     3ac:      	ldr	x9, [x19, #0x100]
     3b0:      	ldr	x8, [x8]
     3b4:      	and	x9, x8, x9
     3b8:      	str	x9, [x21, #0xed0]
     3bc:      	ldr	x9, [x19, #0xf8]
     3c0:      	str	x9, [x21, #0xed8]
     3c4:      	ldr	x9, [x19, #0xe8]
     3c8:      	str	x9, [x21, #0xee0]
     3cc:      	ldr	x9, [x19, #0xf0]
     3d0:      	and	x8, x9, x8
     3d4:      	str	x8, [x21, #0xee8]
     3d8:      	ldr	x8, [x19, #0xb0]
     3dc:      	str	x8, [x21, #0xef0]
     3e0:      	ldr	x8, [x19, #0xe0]
     3e4:      	strh	wzr, [x21, #0xf20]
     3e8:      	str	x8, [x21, #0xef8]
     3ec:      	ldr	w8, [x25]
     3f0:      	cbnz	w8, 0x980 <finish_task_switch+0x980>
     3f4:      	mov	w8, #0x60               // =96
     3f8:      	rev	w9, w22
     3fc:      	str	xzr, [sp, #0x18]
     400:      	adrp	x24, 0x0 <finish_task_switch>
     404:      	stp	w8, w9, [sp, #0x10]
     408:      	mov	w8, #0x1                // =1
     40c:      	add	x9, sp, #0x10
     410:      	add	x1, sp, #0x10
     414:      	ldr	x24, [x24]
     418:      	mov	x0, x24
     41c:      	blr	x8
     420:      	cbz	x0, 0x554 <finish_task_switch+0x554>
     424:      	add	x8, x21, #0xed0
     428:      	ldr	x23, [x8]
     42c:      	ldr	w8, [x25]
     430:      	cbz	x23, 0x5f0 <finish_task_switch+0x5f0>
     434:      	cbnz	w8, 0xaa4 <finish_task_switch+0xaa4>
     438:      	lsr	x8, x23, #56
     43c:      	cbz	x8, 0xaf0 <finish_task_switch+0xaf0>
     440:      	ldr	w8, [x25]
     444:      	cbnz	w8, 0xcac <finish_task_switch+0xcac>
     448:      	mov	w8, #0xb                // =11
     44c:      	mov	w22, wzr
     450:      	str	w8, [x21, #0xf18]
     454:      	mov	w8, #0xfab              // =4011
     458:      	b	0x464 <finish_task_switch+0x464>
     45c:      	mov	w22, wzr
     460:      	mov	w8, #0xfb0              // =4016
     464:      	str	w8, [x21, #0xf1c]
     468:      	str	wzr, [sp, #0x10]
     46c:      	mov	w8, #0x1                // =1
     470:      	add	x9, sp, #0x10
     474:      	add	x1, sp, #0x10
     478:      	mov	x0, x20
     47c:      	blr	x8
     480:      	cbz	x0, 0x4d8 <finish_task_switch+0x4d8>
     484:      	mov	w20, #0x1374            // =4980
     488:      	mov	w2, w22
     48c:      	ldrb	w8, [x0, x20]
     490:      	cmp	w8, #0x1d
     494:      	b.lo	0x504 <finish_task_switch+0x504>
     498:      	mov	w8, #0x5                // =5
     49c:      	mov	x21, x0
     4a0:      	add	x9, sp, #0x160
     4a4:      	str	w8, [x0, #0xf1c]
     4a8:      	mov	w8, #0x44               // =68
     4ac:      	adrp	x0, 0x0 <finish_task_switch>
     4b0:      	add	x1, sp, #0x160
     4b4:      	str	w8, [sp, #0x160]
     4b8:      	mov	w8, #0x1                // =1
     4bc:      	ldr	x0, [x0]
     4c0:      	blr	x8
     4c4:      	cbz	x0, 0x4f0 <finish_task_switch+0x4f0>
     4c8:      	ldr	x8, [x0]
     4cc:      	add	x8, x8, #0x1
     4d0:      	str	x8, [x0]
     4d4:      	b	0x4f8 <finish_task_switch+0x4f8>
     4d8:      	adrp	x10, 0x0 <finish_task_switch>
     4dc:      	mov	x9, xzr
     4e0:      	mov	w8, #0xc                // =12
     4e4:      	ldr	x10, [x10]
     4e8:      	mov	w2, wzr
     4ec:      	b	0x51c <finish_task_switch+0x51c>
     4f0:      	ldr	w8, [x25]
     4f4:      	cbnz	w8, 0xa5c <finish_task_switch+0xa5c>
     4f8:      	ldrb	w8, [x21, x20]
     4fc:      	mov	w2, wzr
     500:      	mov	x0, x21
     504:      	add	w8, w8, #0x1
     508:      	adrp	x10, 0x0 <finish_task_switch>
     50c:      	mov	w9, w2
     510:      	strb	w8, [x0, x20]
     514:      	mov	w8, #0xc                // =12
     518:      	ldr	x10, [x10]
     51c:      	adrp	x1, 0x0 <finish_task_switch>
     520:      	mov	x0, x19
     524:      	ldr	x1, [x1]
     528:      	blr	x8
     52c:      	ldr	w8, [x25]
     530:      	cbnz	w8, 0x934 <finish_task_switch+0x934>
     534:      	mov	w0, #-0x1               // =-1
     538:      	ldp	x20, x19, [sp, #0x1e0]
     53c:      	ldr	x29, [sp, #0x1a0]
     540:      	ldp	x22, x21, [sp, #0x1d0]
     544:      	ldp	x24, x23, [sp, #0x1c0]
     548:      	ldp	x30, x25, [sp, #0x1b0]
     54c:      	add	sp, sp, #0x1f0
     550:      	ret
     554:      	str	x23, [sp, #0x198]
     558:      	str	w22, [sp, #0x1a8]
     55c:      	adrp	x20, 0x0 <finish_task_switch>
     560:      	mov	w8, #0x1                // =1
     564:      	add	x9, sp, #0x1a8
     568:      	add	x1, sp, #0x1a8
     56c:      	ldr	x20, [x20]
     570:      	mov	x0, x20
     574:      	blr	x8
     578:      	mov	w8, #0x5                // =5
     57c:      	mov	x21, x0
     580:      	blr	x8
     584:      	cbz	x21, 0x644 <finish_task_switch+0x644>
     588:      	ldr	x8, [x21]
     58c:      	mov	w11, #0xe100            // =57600
     590:      	movk	w11, #0x5f5, lsl #16
     594:      	and	x9, x8, #0xffffffffffffffe0
     598:      	and	x10, x8, #0xf
     59c:      	sub	x9, x0, x9
     5a0:      	lsl	x10, x11, x10
     5a4:      	cmp	x9, x10
     5a8:      	b.hs	0x608 <finish_task_switch+0x608>
     5ac:      	ldr	w8, [x25]
     5b0:      	cbz	w8, 0x3c <finish_task_switch+0x3c>
     5b4:      	adrp	x8, 0x0 <finish_task_switch>
     5b8:      	add	x8, x8, #0x0
     5bc:      	add	x0, sp, #0x10
     5c0:      	ldp	x9, x10, [x8]
     5c4:      	mov	w1, #0x20               // =32
     5c8:      	stp	x9, x10, [sp, #0x10]
     5cc:      	ldp	x9, x8, [x8, #0x10]
     5d0:      	add	x10, sp, #0x10
     5d4:      	stp	x9, x8, [sp, #0x20]
     5d8:      	mov	w8, #0x20               // =32
     5dc:      	mov	w9, #0x6                // =6
     5e0:      	ldr	w2, [sp, #0x1a8]
     5e4:      	blr	x9
     5e8:      	mov	w0, wzr
     5ec:      	b	0x538 <finish_task_switch+0x538>
     5f0:      	cbnz	w8, 0xc6c <finish_task_switch+0xc6c>
     5f4:      	mov	w8, #0x1                // =1
     5f8:      	mov	w22, wzr
     5fc:      	str	w8, [x21, #0xf18]
     600:      	mov	w8, #0xfad              // =4013
     604:      	b	0x464 <finish_task_switch+0x464>
     608:      	mov	x11, #0xf200            // =61952
     60c:      	and	w21, w8, #0x10
     610:      	movk	x11, #0x2a05, lsl #16
     614:      	movk	x11, #0x1, lsl #32
     618:      	add	x10, x10, x11
     61c:      	cmp	x9, x10
     620:      	b.hs	0x644 <finish_task_switch+0x644>
     624:      	cmp	w21, #0x0
     628:      	mov	w9, #0x4                // =4
     62c:      	mov	w10, #0x8               // =8
     630:      	and	w8, w8, #0xf
     634:      	csel	w9, w10, w9, eq
     638:      	cmp	w9, w8
     63c:      	cinc	w23, w8, hi
     640:      	b	0x648 <finish_task_switch+0x648>
     644:      	mov	w23, wzr
     648:      	ldr	w8, [x25]
     64c:      	cbnz	w8, 0xc20 <finish_task_switch+0xc20>
     650:      	mov	w9, w21
     654:      	and	x10, x23, #0xff
     658:      	and	x8, x0, #0xffffffffffffffe0
     65c:      	mov	x3, xzr
     660:      	add	x1, sp, #0x1a8
     664:      	add	x2, sp, #0x160
     668:      	mov	x0, x20
     66c:      	orr	x9, x9, x10
     670:      	add	x10, sp, #0x160
     674:      	orr	x8, x8, x9
     678:      	str	x8, [sp, #0x160]
     67c:      	mov	w8, #0x2                // =2
     680:      	add	x9, sp, #0x1a8
     684:      	blr	x8
     688:      	cbz	w0, 0x6fc <finish_task_switch+0x6fc>
     68c:      	ldr	w8, [x25]
     690:      	cbnz	w8, 0xcec <finish_task_switch+0xcec>
     694:      	mov	w8, #0x3d               // =61
     698:      	adrp	x0, 0x0 <finish_task_switch>
     69c:      	add	x9, sp, #0x1ac
     6a0:      	str	w8, [sp, #0x1ac]
     6a4:      	mov	w8, #0x1                // =1
     6a8:      	add	x1, sp, #0x1ac
     6ac:      	ldr	x0, [x0]
     6b0:      	blr	x8
     6b4:      	cbnz	x0, 0x758 <finish_task_switch+0x758>
     6b8:      	ldr	w8, [x25]
     6bc:      	cbz	w8, 0x3c <finish_task_switch+0x3c>
     6c0:      	adrp	x8, 0x0 <finish_task_switch>
     6c4:      	add	x8, x8, #0x0
     6c8:      	ldp	x9, x10, [x8, #0x10]
     6cc:      	stp	x9, x10, [sp, #0x20]
     6d0:      	ldr	x9, [x8, #0x20]
     6d4:      	add	x10, sp, #0x10
     6d8:      	str	x9, [sp, #0x30]
     6dc:      	ldur	x9, [x8, #0x26]
     6e0:      	stur	x9, [sp, #0x36]
     6e4:      	ldp	x9, x8, [x8]
     6e8:      	stp	x9, x8, [sp, #0x10]
     6ec:      	mov	w8, #0x2e               // =46
     6f0:      	mov	w9, #0x6                // =6
     6f4:      	ldr	w2, [sp, #0x1ac]
     6f8:      	b	0x80c <finish_task_switch+0x80c>
     6fc:      	mov	w20, #0x1               // =1
     700:      	adrp	x0, 0x0 <finish_task_switch>
     704:      	mov	x3, xzr
     708:      	strb	w20, [sp, #0x194]
     70c:      	mov	w8, #0x2                // =2
     710:      	add	x9, sp, #0x198
     714:      	add	x10, sp, #0x194
     718:      	ldr	x0, [x0]
     71c:      	add	x1, sp, #0x198
     720:      	add	x2, sp, #0x194
     724:      	blr	x8
     728:      	cbz	w0, 0x768 <finish_task_switch+0x768>
     72c:      	ldr	w8, [x25]
     730:      	cbnz	w8, 0xe10 <finish_task_switch+0xe10>
     734:      	mov	w8, #0x3e               // =62
     738:      	adrp	x0, 0x0 <finish_task_switch>
     73c:      	add	x9, sp, #0x160
     740:      	str	w8, [sp, #0x160]
     744:      	mov	w8, #0x1                // =1
     748:      	add	x1, sp, #0x160
     74c:      	ldr	x0, [x0]
     750:      	blr	x8
     754:      	cbz	x0, 0x7cc <finish_task_switch+0x7cc>
     758:      	ldr	x8, [x0]
     75c:      	add	x8, x8, #0x1
     760:      	str	x8, [x0]
     764:      	b	0x3c <finish_task_switch+0x3c>
     768:      	str	w20, [sp, #0x1ac]
     76c:      	strb	w20, [sp, #0x1a8]
     770:      	adrp	x0, 0x0 <finish_task_switch>
     774:      	mov	w8, #0x2                // =2
     778:      	add	x9, sp, #0x1ac
     77c:      	add	x10, sp, #0x1a8
     780:      	ldr	x0, [x0]
     784:      	add	x1, sp, #0x1ac
     788:      	add	x2, sp, #0x1a8
     78c:      	mov	w3, #0x1                // =1
     790:      	blr	x8
     794:      	tbnz	w0, #0x1f, 0x820 <finish_task_switch+0x820>
     798:      	mov	w8, #0x42               // =66
     79c:      	adrp	x0, 0x0 <finish_task_switch>
     7a0:      	add	x9, sp, #0x160
     7a4:      	str	w8, [sp, #0x160]
     7a8:      	mov	w8, #0x1                // =1
     7ac:      	add	x1, sp, #0x160
     7b0:      	ldr	x0, [x0]
     7b4:      	blr	x8
     7b8:      	cbz	x0, 0x864 <finish_task_switch+0x864>
     7bc:      	ldr	x8, [x0]
     7c0:      	add	x8, x8, #0x1
     7c4:      	str	x8, [x0]
     7c8:      	b	0x86c <finish_task_switch+0x86c>
     7cc:      	ldr	w8, [x25]
     7d0:      	cbz	w8, 0x3c <finish_task_switch+0x3c>
     7d4:      	adrp	x8, 0x0 <finish_task_switch>
     7d8:      	add	x8, x8, #0x0
     7dc:      	ldp	x9, x10, [x8, #0x10]
     7e0:      	stp	x9, x10, [sp, #0x20]
     7e4:      	ldr	x9, [x8, #0x20]
     7e8:      	add	x10, sp, #0x10
     7ec:      	str	x9, [sp, #0x30]
     7f0:      	ldur	x9, [x8, #0x26]
     7f4:      	stur	x9, [sp, #0x36]
     7f8:      	ldp	x9, x8, [x8]
     7fc:      	stp	x9, x8, [sp, #0x10]
     800:      	mov	w8, #0x2e               // =46
     804:      	mov	w9, #0x6                // =6
     808:      	ldr	w2, [sp, #0x160]
     80c:      	add	x0, sp, #0x10
     810:      	mov	w1, #0x2e               // =46
     814:      	blr	x9
     818:      	mov	w0, wzr
     81c:      	b	0x538 <finish_task_switch+0x538>
     820:      	ldr	w8, [x25]
     824:      	cbz	w8, 0x8ac <finish_task_switch+0x8ac>
     828:      	adrp	x8, 0x0 <finish_task_switch>
     82c:      	add	x8, x8, #0x0
     830:      	strb	wzr, [sp, #0x28]
     834:      	add	x0, sp, #0x10
     838:      	ldp	x9, x10, [x8]
     83c:      	ldr	x8, [x8, #0x10]
     840:      	mov	w1, #0x19               // =25
     844:      	mov	w2, #0x1                // =1
     848:      	str	x8, [sp, #0x20]
     84c:      	stp	x9, x10, [sp, #0x10]
     850:      	mov	w8, #0x19               // =25
     854:      	mov	w9, #0x6                // =6
     858:      	add	x10, sp, #0x10
     85c:      	blr	x9
     860:      	b	0x8ac <finish_task_switch+0x8ac>
     864:      	ldr	w8, [x25]
     868:      	cbnz	w8, 0xef8 <finish_task_switch+0xef8>
     86c:      	mov	w8, #0x1                // =1
     870:      	adrp	x1, 0x0 <finish_task_switch>
     874:      	mov	w9, #0x4                // =4
     878:      	str	w8, [sp, #0x160]
     87c:      	mov	w8, #-0x1               // =-1
     880:      	mov	w10, #0x19              // =25
     884:      	add	x11, sp, #0x160
     888:      	ldr	x1, [x1]
     88c:      	add	x3, sp, #0x160
     890:      	mov	x0, x19
     894:      	mov	w2, #-0x1               // =-1
     898:      	mov	w4, #0x4                // =4
     89c:      	blr	x10
     8a0:      	tbz	w0, #0x1f, 0x8ac <finish_task_switch+0x8ac>
     8a4:      	ldr	w8, [x25]
     8a8:      	cbnz	w8, 0xeac <finish_task_switch+0xeac>
     8ac:      	mov	w8, #0x3f               // =63
     8b0:      	adrp	x0, 0x0 <finish_task_switch>
     8b4:      	add	x9, sp, #0x160
     8b8:      	str	w8, [sp, #0x160]
     8bc:      	mov	w8, #0x1                // =1
     8c0:      	add	x1, sp, #0x160
     8c4:      	ldr	x0, [x0]
     8c8:      	blr	x8
     8cc:      	cbz	x0, 0x8e4 <finish_task_switch+0x8e4>
     8d0:      	ldr	x8, [x0]
     8d4:      	add	x8, x8, #0x1
     8d8:      	str	x8, [x0]
     8dc:      	mov	w0, wzr
     8e0:      	b	0x538 <finish_task_switch+0x538>
     8e4:      	ldr	w8, [x25]
     8e8:      	cbz	w8, 0x3c <finish_task_switch+0x3c>
     8ec:      	adrp	x8, 0x0 <finish_task_switch>
     8f0:      	add	x8, x8, #0x0
     8f4:      	add	x0, sp, #0x10
     8f8:      	ldp	x9, x10, [x8, #0x10]
     8fc:      	mov	w1, #0x2e               // =46
     900:      	stp	x9, x10, [sp, #0x20]
     904:      	ldr	x9, [x8, #0x20]
     908:      	add	x10, sp, #0x10
     90c:      	str	x9, [sp, #0x30]
     910:      	ldur	x9, [x8, #0x26]
     914:      	stur	x9, [sp, #0x36]
     918:      	ldp	x9, x8, [x8]
     91c:      	stp	x9, x8, [sp, #0x10]
     920:      	mov	w8, #0x2e               // =46
     924:      	mov	w9, #0x6                // =6
     928:      	ldr	w2, [sp, #0x160]
     92c:      	blr	x9
     930:      	b	0x3c <finish_task_switch+0x3c>
     934:      	mov	w8, #0x7972             // =31090
     938:      	add	x0, sp, #0x10
     93c:      	mov	w1, #0x34               // =52
     940:      	mov	w2, w22
     944:      	movk	w8, #0xa, lsl #16
     948:      	str	w8, [sp, #0x40]
     94c:      	adrp	x8, 0x0 <finish_task_switch>
     950:      	add	x8, x8, #0x0
     954:      	ldp	x9, x10, [x8, #0x10]
     958:      	stp	x9, x10, [sp, #0x20]
     95c:      	ldp	x9, x10, [x8, #0x20]
     960:      	stp	x9, x10, [sp, #0x30]
     964:      	ldp	x9, x8, [x8]
     968:      	add	x10, sp, #0x10
     96c:      	stp	x9, x8, [sp, #0x10]
     970:      	mov	w8, #0x34               // =52
     974:      	mov	w9, #0x6                // =6
     978:      	blr	x9
     97c:      	b	0x534 <finish_task_switch+0x534>
     980:      	adrp	x8, 0x0 <finish_task_switch>
     984:      	add	x8, x8, #0x0
     988:      	add	x0, sp, #0x10
     98c:      	ldp	x9, x10, [x8, #0x10]
     990:      	mov	w1, #0x27               // =39
     994:      	stp	x9, x10, [sp, #0x20]
     998:      	ldur	x9, [x8, #0x1f]
     99c:      	add	x10, sp, #0x10
     9a0:      	stur	x9, [sp, #0x2f]
     9a4:      	ldp	x8, x9, [x8]
     9a8:      	stp	x8, x9, [sp, #0x10]
     9ac:      	mov	w8, #0x27               // =39
     9b0:      	mov	w9, #0x6                // =6
     9b4:      	ldr	x2, [x21, #0xed0]
     9b8:      	ldr	x3, [x21, #0xed8]
     9bc:      	ldr	x4, [x21, #0xee0]
     9c0:      	blr	x9
     9c4:      	b	0x3f4 <finish_task_switch+0x3f4>
     9c8:      	adrp	x8, 0x0 <finish_task_switch>
     9cc:      	add	x8, x8, #0x0
     9d0:      	add	x0, sp, #0x160
     9d4:      	ldp	x9, x10, [x8, #0x10]
     9d8:      	mov	w1, #0x2e               // =46
     9dc:      	stp	x9, x10, [sp, #0x170]
     9e0:      	ldr	x9, [x8, #0x20]
     9e4:      	add	x10, sp, #0x87
     9e8:      	str	x9, [sp, #0x180]
     9ec:      	ldur	x9, [x8, #0x26]
     9f0:      	stur	x9, [x10, #0xff]
     9f4:      	ldp	x9, x8, [x8]
     9f8:      	add	x10, sp, #0x160
     9fc:      	stp	x9, x8, [sp, #0x160]
     a00:      	mov	w8, #0x2e               // =46
     a04:      	mov	w9, #0x6                // =6
     a08:      	ldr	w2, [sp, #0x198]
     a0c:      	blr	x9
     a10:      	b	0x270 <finish_task_switch+0x270>
     a14:      	adrp	x8, 0x0 <finish_task_switch>
     a18:      	add	x8, x8, #0x0
     a1c:      	add	x0, sp, #0x10
     a20:      	ldp	x9, x10, [x8, #0x10]
     a24:      	mov	w1, #0x2e               // =46
     a28:      	stp	x9, x10, [sp, #0x20]
     a2c:      	ldr	x9, [x8, #0x20]
     a30:      	add	x10, sp, #0x10
     a34:      	str	x9, [sp, #0x30]
     a38:      	ldur	x9, [x8, #0x26]
     a3c:      	stur	x9, [sp, #0x36]
     a40:      	ldp	x9, x8, [x8]
     a44:      	stp	x9, x8, [sp, #0x10]
     a48:      	mov	w8, #0x2e               // =46
     a4c:      	mov	w9, #0x6                // =6
     a50:      	ldr	w2, [sp, #0x160]
     a54:      	blr	x9
     a58:      	b	0x198 <finish_task_switch+0x198>
     a5c:      	adrp	x8, 0x0 <finish_task_switch>
     a60:      	add	x8, x8, #0x0
     a64:      	add	x0, sp, #0x10
     a68:      	ldp	x9, x10, [x8, #0x10]
     a6c:      	mov	w1, #0x2e               // =46
     a70:      	stp	x9, x10, [sp, #0x20]
     a74:      	ldr	x9, [x8, #0x20]
     a78:      	add	x10, sp, #0x10
     a7c:      	str	x9, [sp, #0x30]
     a80:      	ldur	x9, [x8, #0x26]
     a84:      	stur	x9, [sp, #0x36]
     a88:      	ldp	x9, x8, [x8]
     a8c:      	stp	x9, x8, [sp, #0x10]
     a90:      	mov	w8, #0x2e               // =46
     a94:      	mov	w9, #0x6                // =6
     a98:      	ldr	w2, [sp, #0x160]
     a9c:      	blr	x9
     aa0:      	b	0x4f8 <finish_task_switch+0x4f8>
     aa4:      	adrp	x8, 0x0 <finish_task_switch>
     aa8:      	add	x8, x8, #0x0
     aac:      	strb	wzr, [sp, #0x40]
     ab0:      	add	x0, sp, #0x10
     ab4:      	ldp	x9, x10, [x8, #0x10]
     ab8:      	mov	w1, #0x31               // =49
     abc:      	stp	x9, x10, [sp, #0x20]
     ac0:      	ldp	x9, x10, [x8, #0x20]
     ac4:      	stp	x9, x10, [sp, #0x30]
     ac8:      	ldp	x9, x8, [x8]
     acc:      	add	x10, sp, #0x10
     ad0:      	stp	x9, x8, [sp, #0x10]
     ad4:      	mov	w8, #0x31               // =49
     ad8:      	mov	w9, #0x6                // =6
     adc:      	ldr	w2, [x21, #0x2c0]
     ae0:      	blr	x9
     ae4:      	ldr	x23, [x21, #0xed0]
     ae8:      	lsr	x8, x23, #56
     aec:      	cbnz	x8, 0x440 <finish_task_switch+0x440>
     af0:      	cmp	x23, #0xfff
     af4:      	b.hi	0xb14 <finish_task_switch+0xb14>
     af8:      	ldr	w8, [x25]
     afc:      	cbnz	w8, 0xd30 <finish_task_switch+0xd30>
     b00:      	mov	w8, #0x31               // =49
     b04:      	mov	w22, wzr
     b08:      	str	w8, [x21, #0xf18]
     b0c:      	mov	w8, #0xfae              // =4014
     b10:      	b	0x464 <finish_task_switch+0x464>
     b14:      	ldr	w8, [x21]
     b18:      	mov	w9, #0x60               // =96
     b1c:      	add	x1, sp, #0x160
     b20:      	mov	x0, x24
     b24:      	str	w9, [sp, #0x160]
     b28:      	add	x9, sp, #0x160
     b2c:      	rev	w8, w8
     b30:      	str	w8, [sp, #0x164]
     b34:      	rev	x8, x23
     b38:      	str	x8, [sp, #0x168]
     b3c:      	mov	w8, #0x1                // =1
     b40:      	blr	x8
     b44:      	cbz	x0, 0xbfc <finish_task_switch+0xbfc>
     b48:      	ldr	x8, [x0, #0x8]
     b4c:      	and	x9, x8, #0xffffffffffffff
     b50:      	lsr	x22, x8, #56
     b54:      	str	x9, [x21, #0xf10]
     b58:      	ldr	x8, [x0]
     b5c:      	str	x8, [x21, #0xf00]
     b60:      	sub	x8, x23, x9
     b64:      	str	x8, [x21, #0xf08]
     b68:      	ldr	w8, [x25]
     b6c:      	cbnz	w8, 0xd70 <finish_task_switch+0xd70>
     b70:      	cmp	w22, #0x1
     b74:      	b.ne	0x28c <finish_task_switch+0x28c>
     b78:      	ldr	x8, [x21, #0xf00]
     b7c:      	adrp	x0, 0x0 <finish_task_switch>
     b80:      	ldr	x22, [x21, #0xf08]
     b84:      	mov	w9, #0x1                // =1
     b88:      	add	x1, sp, #0x160
     b8c:      	mov	w23, #0x1               // =1
     b90:      	str	x8, [sp, #0x160]
     b94:      	add	x8, sp, #0x160
     b98:      	ldr	x0, [x0]
     b9c:      	blr	x9
     ba0:      	cbz	x0, 0xc18 <finish_task_switch+0xc18>
     ba4:      	ldr	x8, [x0]
     ba8:      	cmp	x8, x22
     bac:      	b.hi	0xbbc <finish_task_switch+0xbbc>
     bb0:      	ldr	x8, [x0, #0x8]
     bb4:      	cmp	x8, x22
     bb8:      	b.hs	0xbd4 <finish_task_switch+0xbd4>
     bbc:      	ldr	x8, [x0, #0x10]
     bc0:      	cmp	x8, x22
     bc4:      	b.hi	0xbf4 <finish_task_switch+0xbf4>
     bc8:      	ldr	x8, [x0, #0x18]
     bcc:      	cmp	x8, x22
     bd0:      	b.lo	0xbf4 <finish_task_switch+0xbf4>
     bd4:      	ldr	w8, [x25]
     bd8:      	cbnz	w8, 0xf40 <finish_task_switch+0xf40>
     bdc:      	ldrh	w8, [x0, #0x20]
     be0:      	ldr	w9, [x21, #0x1370]
     be4:      	lsr	w8, w9, w8
     be8:      	tbz	w8, #0x0, 0xf94 <finish_task_switch+0xf94>
     bec:      	ldr	w8, [x25]
     bf0:      	cbnz	w8, 0xfdc <finish_task_switch+0xfdc>
     bf4:      	mov	w22, #0x1               // =1
     bf8:      	b	0x28c <finish_task_switch+0x28c>
     bfc:      	ldr	w8, [x25]
     c00:      	cbnz	w8, 0xe60 <finish_task_switch+0xe60>
     c04:      	mov	w8, #0xc                // =12
     c08:      	mov	w22, wzr
     c0c:      	str	w8, [x21, #0xf18]
     c10:      	mov	w8, #0xfac              // =4012
     c14:      	b	0x464 <finish_task_switch+0x464>
     c18:      	mov	w22, w23
     c1c:      	b	0x28c <finish_task_switch+0x28c>
     c20:      	adrp	x8, 0x0 <finish_task_switch>
     c24:      	add	x8, x8, #0x0
     c28:      	mov	x24, x0
     c2c:      	ldp	x9, x10, [x8]
     c30:      	add	x0, sp, #0x10
     c34:      	and	w3, w23, #0xff
     c38:      	mov	w1, #0x1f               // =31
     c3c:      	stp	x9, x10, [sp, #0x10]
     c40:      	ldr	x9, [x8, #0x10]
     c44:      	ldur	x8, [x8, #0x17]
     c48:      	add	x10, sp, #0x10
     c4c:      	str	x9, [sp, #0x20]
     c50:      	stur	x8, [sp, #0x27]
     c54:      	mov	w8, #0x1f               // =31
     c58:      	mov	w9, #0x6                // =6
     c5c:      	ldr	w2, [sp, #0x1a8]
     c60:      	blr	x9
     c64:      	mov	x0, x24
     c68:      	b	0x650 <finish_task_switch+0x650>
     c6c:      	adrp	x8, 0x0 <finish_task_switch>
     c70:      	add	x8, x8, #0x0
     c74:      	strb	wzr, [sp, #0x40]
     c78:      	add	x0, sp, #0x10
     c7c:      	ldp	x9, x10, [x8, #0x10]
     c80:      	mov	w1, #0x31               // =49
     c84:      	stp	x9, x10, [sp, #0x20]
     c88:      	ldp	x9, x10, [x8, #0x20]
     c8c:      	stp	x9, x10, [sp, #0x30]
     c90:      	ldp	x9, x8, [x8]
     c94:      	add	x10, sp, #0x10
     c98:      	stp	x9, x8, [sp, #0x10]
     c9c:      	mov	w8, #0x31               // =49
     ca0:      	mov	w9, #0x6                // =6
     ca4:      	blr	x9
     ca8:      	b	0x5f4 <finish_task_switch+0x5f4>
     cac:      	mov	w8, #0xa                // =10
     cb0:      	add	x0, sp, #0x10
     cb4:      	mov	w1, #0x22               // =34
     cb8:      	strh	w8, [sp, #0x30]
     cbc:      	adrp	x8, 0x0 <finish_task_switch>
     cc0:      	add	x8, x8, #0x0
     cc4:      	mov	x2, x23
     cc8:      	ldp	x9, x10, [x8]
     ccc:      	stp	x9, x10, [sp, #0x10]
     cd0:      	ldp	x9, x8, [x8, #0x10]
     cd4:      	add	x10, sp, #0x10
     cd8:      	stp	x9, x8, [sp, #0x20]
     cdc:      	mov	w8, #0x22               // =34
     ce0:      	mov	w9, #0x6                // =6
     ce4:      	blr	x9
     ce8:      	b	0x448 <finish_task_switch+0x448>
     cec:      	adrp	x8, 0x0 <finish_task_switch>
     cf0:      	add	x8, x8, #0x0
     cf4:      	mov	w3, w0
     cf8:      	ldp	x9, x10, [x8]
     cfc:      	add	x0, sp, #0x10
     d00:      	mov	w1, #0x1d               // =29
     d04:      	stp	x9, x10, [sp, #0x10]
     d08:      	ldr	x9, [x8, #0x10]
     d0c:      	ldur	x8, [x8, #0x15]
     d10:      	add	x10, sp, #0x10
     d14:      	str	x9, [sp, #0x20]
     d18:      	stur	x8, [sp, #0x25]
     d1c:      	mov	w8, #0x1d               // =29
     d20:      	mov	w9, #0x6                // =6
     d24:      	ldr	w2, [sp, #0x1a8]
     d28:      	blr	x9
     d2c:      	b	0x694 <finish_task_switch+0x694>
     d30:      	adrp	x8, 0x0 <finish_task_switch>
     d34:      	add	x8, x8, #0x0
     d38:      	add	x0, sp, #0x10
     d3c:      	ldp	x9, x10, [x8]
     d40:      	mov	w1, #0x1e               // =30
     d44:      	mov	x2, x23
     d48:      	stp	x9, x10, [sp, #0x10]
     d4c:      	ldr	x9, [x8, #0x10]
     d50:      	ldur	x8, [x8, #0x16]
     d54:      	add	x10, sp, #0x10
     d58:      	str	x9, [sp, #0x20]
     d5c:      	stur	x8, [sp, #0x26]
     d60:      	mov	w8, #0x1e               // =30
     d64:      	mov	w9, #0x6                // =6
     d68:      	blr	x9
     d6c:      	b	0xb00 <finish_task_switch+0xb00>
     d70:      	mov	w8, #0xa                // =10
     d74:      	add	x0, sp, #0x10
     d78:      	mov	w1, #0x32               // =50
     d7c:      	strh	w8, [sp, #0x40]
     d80:      	adrp	x8, 0x0 <finish_task_switch>
     d84:      	add	x8, x8, #0x0
     d88:      	mov	x2, x23
     d8c:      	ldp	x9, x10, [x8, #0x10]
     d90:      	mov	w4, w22
     d94:      	stp	x9, x10, [sp, #0x20]
     d98:      	ldp	x9, x10, [x8, #0x20]
     d9c:      	stp	x9, x10, [sp, #0x30]
     da0:      	ldp	x9, x8, [x8]
     da4:      	add	x10, sp, #0x10
     da8:      	stp	x9, x8, [sp, #0x10]
     dac:      	mov	w8, #0x32               // =50
     db0:      	mov	w9, #0x6                // =6
     db4:      	ldr	x3, [x21, #0xf00]
     db8:      	blr	x9
     dbc:      	ldr	w8, [x25]
     dc0:      	cbz	w8, 0xb70 <finish_task_switch+0xb70>
     dc4:      	adrp	x8, 0x0 <finish_task_switch>
     dc8:      	add	x8, x8, #0x0
     dcc:      	add	x0, sp, #0x10
     dd0:      	ldp	x9, x10, [x8, #0x10]
     dd4:      	mov	w1, #0x2f               // =47
     dd8:      	stp	x9, x10, [sp, #0x20]
     ddc:      	ldr	x9, [x8, #0x20]
     de0:      	add	x10, sp, #0x10
     de4:      	str	x9, [sp, #0x30]
     de8:      	ldur	x9, [x8, #0x27]
     dec:      	stur	x9, [sp, #0x37]
     df0:      	ldp	x9, x8, [x8]
     df4:      	stp	x9, x8, [sp, #0x10]
     df8:      	mov	w8, #0x2f               // =47
     dfc:      	mov	w9, #0x6                // =6
     e00:      	ldr	x2, [x21, #0xf10]
     e04:      	ldr	x3, [x21, #0xf08]
     e08:      	blr	x9
     e0c:      	b	0xb70 <finish_task_switch+0xb70>
     e10:      	adrp	x8, 0x0 <finish_task_switch>
     e14:      	add	x8, x8, #0x0
     e18:      	ldr	w3, [sp, #0x198]
     e1c:      	mov	w4, w0
     e20:      	ldp	x9, x10, [x8, #0x20]
     e24:      	add	x0, sp, #0x10
     e28:      	mov	w1, #0x35               // =53
     e2c:      	mov	w2, w22
     e30:      	stp	x9, x10, [sp, #0x30]
     e34:      	ldur	x9, [x8, #0x2d]
     e38:      	stur	x9, [sp, #0x3d]
     e3c:      	ldp	x9, x10, [x8]
     e40:      	stp	x9, x10, [sp, #0x10]
     e44:      	ldp	x8, x9, [x8, #0x10]
     e48:      	add	x10, sp, #0x10
     e4c:      	stp	x8, x9, [sp, #0x20]
     e50:      	mov	w8, #0x35               // =53
     e54:      	mov	w9, #0x6                // =6
     e58:      	blr	x9
     e5c:      	b	0x734 <finish_task_switch+0x734>
     e60:      	adrp	x8, 0x0 <finish_task_switch>
     e64:      	add	x8, x8, #0x0
     e68:      	strb	wzr, [sp, #0x48]
     e6c:      	add	x0, sp, #0x10
     e70:      	ldp	x9, x10, [x8, #0x20]
     e74:      	mov	w1, #0x39               // =57
     e78:      	mov	x2, x23
     e7c:      	stp	x9, x10, [sp, #0x30]
     e80:      	ldr	x9, [x8, #0x30]
     e84:      	str	x9, [sp, #0x40]
     e88:      	ldp	x9, x10, [x8]
     e8c:      	stp	x9, x10, [sp, #0x10]
     e90:      	ldp	x8, x9, [x8, #0x10]
     e94:      	add	x10, sp, #0x10
     e98:      	stp	x8, x9, [sp, #0x20]
     e9c:      	mov	w8, #0x39               // =57
     ea0:      	mov	w9, #0x6                // =6
     ea4:      	blr	x9
     ea8:      	b	0xc04 <finish_task_switch+0xc04>
     eac:      	adrp	x8, 0x0 <finish_task_switch>
     eb0:      	add	x8, x8, #0x0
     eb4:      	mov	w3, w0
     eb8:      	ldp	x9, x10, [x8, #0x20]
     ebc:      	add	x0, sp, #0x10
     ec0:      	mov	w1, #0x36               // =54
     ec4:      	mov	w2, #0x1                // =1
     ec8:      	stp	x9, x10, [sp, #0x30]
     ecc:      	ldur	x9, [x8, #0x2e]
     ed0:      	stur	x9, [sp, #0x3e]
     ed4:      	ldp	x9, x10, [x8]
     ed8:      	stp	x9, x10, [sp, #0x10]
     edc:      	ldp	x8, x9, [x8, #0x10]
     ee0:      	add	x10, sp, #0x10
     ee4:      	stp	x8, x9, [sp, #0x20]
     ee8:      	mov	w8, #0x36               // =54
     eec:      	mov	w9, #0x6                // =6
     ef0:      	blr	x9
     ef4:      	b	0x8ac <finish_task_switch+0x8ac>
     ef8:      	adrp	x8, 0x0 <finish_task_switch>
     efc:      	add	x8, x8, #0x0
     f00:      	add	x0, sp, #0x10
     f04:      	ldp	x9, x10, [x8, #0x10]
     f08:      	mov	w1, #0x2e               // =46
     f0c:      	stp	x9, x10, [sp, #0x20]
     f10:      	ldr	x9, [x8, #0x20]
     f14:      	add	x10, sp, #0x10
     f18:      	str	x9, [sp, #0x30]
     f1c:      	ldur	x9, [x8, #0x26]
     f20:      	stur	x9, [sp, #0x36]
     f24:      	ldp	x9, x8, [x8]
     f28:      	stp	x9, x8, [sp, #0x10]
     f2c:      	mov	w8, #0x2e               // =46
     f30:      	mov	w9, #0x6                // =6
     f34:      	ldr	w2, [sp, #0x160]
     f38:      	blr	x9
     f3c:      	b	0x86c <finish_task_switch+0x86c>
     f40:      	adrp	x8, 0x0 <finish_task_switch>
     f44:      	add	x8, x8, #0x0
     f48:      	mov	x22, x0
     f4c:      	ldp	x9, x10, [x8]
     f50:      	mov	w1, #0x1e               // =30
     f54:      	stp	x9, x10, [sp, #0x10]
     f58:      	ldr	x9, [x8, #0x10]
     f5c:      	ldur	x8, [x8, #0x16]
     f60:      	add	x10, sp, #0x10
     f64:      	str	x9, [sp, #0x20]
     f68:      	stur	x8, [sp, #0x26]
     f6c:      	mov	w8, #0x1e               // =30
     f70:      	mov	w9, #0x6                // =6
     f74:      	ldrh	w2, [x0, #0x20]
     f78:      	add	x0, sp, #0x10
     f7c:      	blr	x9
     f80:      	mov	x0, x22
     f84:      	ldrh	w8, [x22, #0x20]
     f88:      	ldr	w9, [x21, #0x1370]
     f8c:      	lsr	w8, w9, w8
     f90:      	tbnz	w8, #0x0, 0xbec <finish_task_switch+0xbec>
     f94:      	mov	x22, x0
     f98:      	str	wzr, [sp, #0x198]
     f9c:      	adrp	x0, 0x0 <finish_task_switch>
     fa0:      	mov	w8, #0x1                // =1
     fa4:      	ldr	x0, [x0]
     fa8:      	add	x9, sp, #0x198
     fac:      	add	x1, sp, #0x198
     fb0:      	blr	x8
     fb4:      	cbz	x0, 0xfcc <finish_task_switch+0xfcc>
     fb8:      	ldr	x8, [x0]
     fbc:      	add	x8, x8, #0x1
     fc0:      	str	x8, [x0]
     fc4:      	ldrh	w22, [x22, #0x20]
     fc8:      	b	0x28c <finish_task_switch+0x28c>
     fcc:      	ldr	w8, [x25]
     fd0:      	cbnz	w8, 0x101c <finish_task_switch+0x101c>
     fd4:      	ldrh	w22, [x22, #0x20]
     fd8:      	b	0x28c <finish_task_switch+0x28c>
     fdc:      	mov	w8, #0x656e             // =25966
     fe0:      	add	x0, sp, #0x10
     fe4:      	mov	w1, #0x1b               // =27
     fe8:      	movk	w8, #0xa, lsl #16
     fec:      	stur	w8, [sp, #0x27]
     ff0:      	adrp	x8, 0x0 <finish_task_switch>
     ff4:      	add	x8, x8, #0x0
     ff8:      	ldp	x9, x10, [x8]
     ffc:      	ldr	x8, [x8, #0x10]
    1000:      	stp	x9, x10, [sp, #0x10]
    1004:      	str	x8, [sp, #0x20]
    1008:      	mov	w8, #0x1b               // =27
    100c:      	mov	w9, #0x6                // =6
    1010:      	add	x10, sp, #0x10
    1014:      	blr	x9
    1018:      	b	0xbf4 <finish_task_switch+0xbf4>
    101c:      	adrp	x8, 0x1000 <finish_task_switch+0x1000>
    1020:      	add	x8, x8, #0x0
    1024:      	add	x0, sp, #0x10
    1028:      	ldp	x9, x10, [x8, #0x10]
    102c:      	mov	w1, #0x2e               // =46
    1030:      	stp	x9, x10, [sp, #0x20]
    1034:      	ldr	x9, [x8, #0x20]
    1038:      	add	x10, sp, #0x10
    103c:      	str	x9, [sp, #0x30]
    1040:      	ldur	x9, [x8, #0x26]
    1044:      	stur	x9, [sp, #0x36]
    1048:      	ldp	x9, x8, [x8]
    104c:      	stp	x9, x8, [sp, #0x10]
    1050:      	mov	w8, #0x2e               // =46
    1054:      	mov	w9, #0x6                // =6
    1058:      	ldr	w2, [sp, #0x198]
    105c:      	blr	x9
    1060:      	b	0xfd4 <finish_task_switch+0xfd4>
