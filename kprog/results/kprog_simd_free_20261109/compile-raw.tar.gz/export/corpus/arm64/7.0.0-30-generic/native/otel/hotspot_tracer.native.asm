
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/otel/hotspot_tracer.native.o:	file format elf64-littleaarch64

Disassembly of section perf_event/unwind_hotspot:

0000000000000000 <perf_unwind_hotspot>:
       0:      	sub	sp, sp, #0x180
       4:      	str	x29, [sp, #0x130]
       8:      	stp	x30, x25, [sp, #0x140]
       c:      	stp	x24, x23, [sp, #0x150]
      10:      	stp	x22, x21, [sp, #0x160]
      14:      	stp	x20, x19, [sp, #0x170]
      18:      	mov	x19, x0
      1c:      	str	wzr, [sp, #0xc8]
      20:      	adrp	x0, 0x0 <perf_unwind_hotspot>
      24:      	mov	w8, #0x1                // =1
      28:      	ldr	x0, [x0]
      2c:      	add	x9, sp, #0xc8
      30:      	add	x1, sp, #0xc8
      34:      	blr	x8
      38:      	cbz	x0, 0x380 <perf_unwind_hotspot+0x380>
      3c:      	ldr	w8, [x0]
      40:      	adrp	x22, 0x0 <perf_unwind_hotspot>
      44:      	mov	x21, x0
      48:      	add	x20, sp, #0xc8
      4c:      	str	w8, [sp, #0x4c]
      50:      	ldr	x22, [x22]
      54:      	ldr	w8, [x22]
      58:      	cbnz	w8, 0x564 <perf_unwind_hotspot+0x564>
      5c:      	adrp	x0, 0x0 <perf_unwind_hotspot>
      60:      	mov	w8, #0x1                // =1
      64:      	add	x9, sp, #0x4c
      68:      	ldr	x0, [x0]
      6c:      	add	x1, sp, #0x4c
      70:      	blr	x8
      74:      	cbz	x0, 0x120 <perf_unwind_hotspot+0x120>
      78:      	mov	w8, #0x29               // =41
      7c:      	mov	x23, x0
      80:      	adrp	x0, 0x0 <perf_unwind_hotspot>
      84:      	str	w8, [sp, #0x50]
      88:      	mov	w8, #0x1                // =1
      8c:      	add	x9, sp, #0x50
      90:      	add	x1, sp, #0x50
      94:      	ldr	x0, [x0]
      98:      	blr	x8
      9c:      	str	x19, [sp, #0x138]
      a0:      	cbz	x0, 0x130 <perf_unwind_hotspot+0x130>
      a4:      	ldr	x8, [x0]
      a8:      	add	x8, x8, #0x1
      ac:      	str	x8, [x0]
      b0:      	ldr	w8, [x22]
      b4:      	ldr	x22, [x21, #0xed0]
      b8:      	ldr	x29, [x21, #0xed8]
      bc:      	ldr	x25, [x21, #0xee0]
      c0:      	cbz	w8, 0x144 <perf_unwind_hotspot+0x144>
      c4:      	mov	w8, #0x786c             // =30828
      c8:      	add	x13, sp, #0xc8
      cc:      	add	x0, sp, #0xc8
      d0:      	mov	w1, #0x2c               // =44
      d4:      	add	x20, sp, #0xc8
      d8:      	movk	w8, #0xa, lsl #16
      dc:      	str	w8, [sp, #0xf0]
      e0:      	adrp	x8, 0x0 <perf_unwind_hotspot>
      e4:      	add	x8, x8, #0x0
      e8:      	ldp	x9, x10, [x8, #0x10]
      ec:      	ldp	x12, x11, [x8]
      f0:      	ldr	x8, [x8, #0x20]
      f4:      	stp	x11, x9, [x13, #0x8]
      f8:      	stp	x10, x8, [x13, #0x18]
      fc:      	str	x12, [sp, #0xc8]
     100:      	mov	w8, #0x2c               // =44
     104:      	mov	w9, #0x6                // =6
     108:      	add	x10, sp, #0xc8
     10c:      	ldr	x2, [x21, #0xed0]
     110:      	ldr	x3, [x21, #0xf10]
     114:      	ldr	x4, [x21, #0xf08]
     118:      	blr	x9
     11c:      	b	0x144 <perf_unwind_hotspot+0x144>
     120:      	ldr	w8, [x22]
     124:      	cbnz	w8, 0x6ec <perf_unwind_hotspot+0x6ec>
     128:      	mov	w0, wzr
     12c:      	b	0x384 <perf_unwind_hotspot+0x384>
     130:      	ldr	w8, [x22]
     134:      	cbnz	w8, 0x7fc <perf_unwind_hotspot+0x7fc>
     138:      	ldr	x22, [x21, #0xed0]
     13c:      	ldr	x29, [x21, #0xed8]
     140:      	ldr	x25, [x21, #0xee0]
     144:      	ldr	x8, [x21, #0xf08]
     148:      	ldrb	w9, [x23, #0x20]
     14c:      	add	x10, sp, #0x88
     150:      	add	x0, sp, #0x88
     154:      	mov	w1, #0x1                // =1
     158:      	lsr	x24, x8, x9
     15c:      	ldr	x8, [x21, #0xf00]
     160:      	mov	w9, #0x70               // =112
     164:      	and	x19, x8, #0xffffffffffffff
     168:      	mov	w8, #0x1                // =1
     16c:      	add	x2, x24, x19
     170:      	blr	x9
     174:      	cbz	x0, 0x1d8 <perf_unwind_hotspot+0x1d8>
     178:      	str	xzr, [sp, #0x50]
     17c:      	adrp	x24, 0x0 <perf_unwind_hotspot>
     180:      	ldr	x24, [x24]
     184:      	ldr	w8, [x24]
     188:      	cbnz	w8, 0x6ac <perf_unwind_hotspot+0x6ac>
     18c:      	mov	w8, #0x2b               // =43
     190:      	adrp	x23, 0x0 <perf_unwind_hotspot>
     194:      	add	x9, sp, #0x88
     198:      	str	w8, [sp, #0x88]
     19c:      	mov	w8, #0x1                // =1
     1a0:      	add	x1, sp, #0x88
     1a4:      	ldr	x23, [x23]
     1a8:      	mov	x0, x23
     1ac:      	blr	x8
     1b0:      	adrp	x19, 0x0 <perf_unwind_hotspot>
     1b4:      	ldr	x22, [sp, #0x138]
     1b8:      	ldr	x19, [x19]
     1bc:      	cbz	x0, 0x2a4 <perf_unwind_hotspot+0x2a4>
     1c0:      	ldr	x8, [x0]
     1c4:      	mov	w25, wzr
     1c8:      	add	x8, x8, #0x1
     1cc:      	str	x8, [x0]
     1d0:      	mov	w8, #0x3e8              // =1000
     1d4:      	b	0x2b4 <perf_unwind_hotspot+0x2b4>
     1d8:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     1dc:      	ldr	x8, [x8]
     1e0:      	ldr	w8, [x8]
     1e4:      	cbnz	w8, 0x860 <perf_unwind_hotspot+0x860>
     1e8:      	ldrb	w8, [sp, #0x88]
     1ec:      	add	w9, w8, #0x1
     1f0:      	and	w9, w9, #0xff
     1f4:      	cmp	w9, #0x2
     1f8:      	b.hs	0x8bc <perf_unwind_hotspot+0x8bc>
     1fc:      	cbnz	w8, 0x178 <perf_unwind_hotspot+0x178>
     200:      	ldr	x8, [x21, #0xf10]
     204:      	ldrb	w9, [x23, #0x20]
     208:      	lsl	x9, x24, x9
     20c:      	ldrb	w10, [x23, #0x1b]
     210:      	add	x8, x8, x10
     214:      	add	x24, x9, x8
     218:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     21c:      	ldr	x8, [x8]
     220:      	ldr	w8, [x8]
     224:      	cbnz	w8, 0xd94 <perf_unwind_hotspot+0xd94>
     228:      	str	x24, [sp, #0x50]
     22c:      	cbz	x24, 0x17c <perf_unwind_hotspot+0x17c>
     230:      	add	x19, x21, #0xf70
     234:      	mov	w8, #0x200              // =512
     238:      	mov	w9, #0x70               // =112
     23c:      	ldr	x2, [sp, #0x50]
     240:      	mov	x0, x19
     244:      	mov	w1, #0x200              // =512
     248:      	blr	x9
     24c:      	adrp	x24, 0x0 <perf_unwind_hotspot>
     250:      	ldr	x24, [x24]
     254:      	cbz	x0, 0x3a0 <perf_unwind_hotspot+0x3a0>
     258:      	ldr	w8, [x24]
     25c:      	cbnz	w8, 0xfd0 <perf_unwind_hotspot+0xfd0>
     260:      	mov	w8, #0x2c               // =44
     264:      	adrp	x23, 0x0 <perf_unwind_hotspot>
     268:      	add	x9, sp, #0x88
     26c:      	str	w8, [sp, #0x88]
     270:      	mov	w8, #0x1                // =1
     274:      	add	x1, sp, #0x88
     278:      	ldr	x23, [x23]
     27c:      	mov	x0, x23
     280:      	blr	x8
     284:      	adrp	x19, 0x0 <perf_unwind_hotspot>
     288:      	ldr	x22, [sp, #0x138]
     28c:      	ldr	x19, [x19]
     290:      	cbz	x0, 0x3e4 <perf_unwind_hotspot+0x3e4>
     294:      	ldr	x8, [x0]
     298:      	add	x8, x8, #0x1
     29c:      	str	x8, [x0]
     2a0:      	b	0x3ec <perf_unwind_hotspot+0x3ec>
     2a4:      	ldr	w8, [x24]
     2a8:      	cbnz	w8, 0xc00 <perf_unwind_hotspot+0xc00>
     2ac:      	mov	w8, #0x3e8              // =1000
     2b0:      	mov	w25, wzr
     2b4:      	str	w8, [x21, #0xf1c]
     2b8:      	str	wzr, [sp, #0xc8]
     2bc:      	mov	w8, #0x1                // =1
     2c0:      	add	x9, sp, #0xc8
     2c4:      	add	x1, sp, #0xc8
     2c8:      	mov	x0, x19
     2cc:      	blr	x8
     2d0:      	cbz	x0, 0x324 <perf_unwind_hotspot+0x324>
     2d4:      	mov	w19, #0x1374            // =4980
     2d8:      	mov	w2, w25
     2dc:      	ldrb	w8, [x0, x19]
     2e0:      	cmp	w8, #0x1d
     2e4:      	b.lo	0x350 <perf_unwind_hotspot+0x350>
     2e8:      	mov	w8, #0x5                // =5
     2ec:      	add	x9, sp, #0x50
     2f0:      	mov	x20, x0
     2f4:      	str	w8, [x0, #0xf1c]
     2f8:      	mov	w8, #0x44               // =68
     2fc:      	add	x1, sp, #0x50
     300:      	mov	x0, x23
     304:      	str	w8, [sp, #0x50]
     308:      	mov	w8, #0x1                // =1
     30c:      	blr	x8
     310:      	cbz	x0, 0x33c <perf_unwind_hotspot+0x33c>
     314:      	ldr	x8, [x0]
     318:      	add	x8, x8, #0x1
     31c:      	str	x8, [x0]
     320:      	b	0x344 <perf_unwind_hotspot+0x344>
     324:      	adrp	x10, 0x0 <perf_unwind_hotspot>
     328:      	mov	x9, xzr
     32c:      	mov	w8, #0xc                // =12
     330:      	ldr	x10, [x10]
     334:      	mov	w2, wzr
     338:      	b	0x368 <perf_unwind_hotspot+0x368>
     33c:      	ldr	w8, [x24]
     340:      	cbnz	w8, 0xd48 <perf_unwind_hotspot+0xd48>
     344:      	ldrb	w8, [x20, x19]
     348:      	mov	w2, wzr
     34c:      	mov	x0, x20
     350:      	add	w8, w8, #0x1
     354:      	adrp	x10, 0x0 <perf_unwind_hotspot>
     358:      	mov	w9, w2
     35c:      	strb	w8, [x0, x19]
     360:      	mov	w8, #0xc                // =12
     364:      	ldr	x10, [x10]
     368:      	adrp	x1, 0x0 <perf_unwind_hotspot>
     36c:      	mov	x0, x22
     370:      	ldr	x1, [x1]
     374:      	blr	x8
     378:      	ldr	w8, [x24]
     37c:      	cbnz	w8, 0x5a8 <perf_unwind_hotspot+0x5a8>
     380:      	mov	w0, #-0x1               // =-1
     384:      	ldp	x20, x19, [sp, #0x170]
     388:      	ldr	x29, [sp, #0x130]
     38c:      	ldp	x22, x21, [sp, #0x160]
     390:      	ldp	x24, x23, [sp, #0x150]
     394:      	ldp	x30, x25, [sp, #0x140]
     398:      	add	sp, sp, #0x180
     39c:      	ret
     3a0:      	ldrh	w8, [x23, #0x10]
     3a4:      	cmp	x8, #0x1f8
     3a8:      	b.hi	0x3c4 <perf_unwind_hotspot+0x3c4>
     3ac:      	ldrh	w9, [x23, #0x12]
     3b0:      	cmp	x9, #0x1fc
     3b4:      	b.hi	0x3c4 <perf_unwind_hotspot+0x3c4>
     3b8:      	ldrh	w10, [x23, #0x14]
     3bc:      	cmp	x10, #0x1f8
     3c0:      	b.ls	0x3f4 <perf_unwind_hotspot+0x3f4>
     3c4:      	mov	w8, #0x1                // =1
     3c8:      	ldr	x22, [sp, #0x138]
     3cc:      	adrp	x19, 0x0 <perf_unwind_hotspot>
     3d0:      	adrp	x23, 0x0 <perf_unwind_hotspot>
     3d4:      	mov	w25, wzr
     3d8:      	ldr	x19, [x19]
     3dc:      	ldr	x23, [x23]
     3e0:      	b	0x2b4 <perf_unwind_hotspot+0x2b4>
     3e4:      	ldr	w8, [x24]
     3e8:      	cbnz	w8, 0x10b4 <perf_unwind_hotspot+0x10b4>
     3ec:      	mov	w8, #0x3eb              // =1003
     3f0:      	b	0x2b0 <perf_unwind_hotspot+0x2b0>
     3f4:      	ldrb	w12, [x23, #0x17]
     3f8:      	add	x11, sp, #0x50
     3fc:      	mov	w1, #0x4                // =4
     400:      	add	x0, x11, #0x20
     404:      	ldrb	w11, [x23, #0x1a]
     408:      	ldr	x12, [x19, x12]
     40c:      	str	x12, [sp, #0x58]
     410:      	ldrb	w12, [x23, #0x18]
     414:      	ldr	x12, [x19, x12]
     418:      	str	x12, [sp, #0x60]
     41c:      	ldr	w11, [x19, x11]
     420:      	lsl	w11, w11, #3
     424:      	str	w11, [sp, #0x78]
     428:      	ldrb	w11, [x23, #0x19]
     42c:      	ldrh	w11, [x19, x11]
     430:      	strh	w11, [sp, #0x80]
     434:      	ldr	w9, [x19, x9]
     438:      	str	w9, [sp, #0x7c]
     43c:      	ldr	w9, [x19, x10]
     440:      	str	w9, [sp, #0x74]
     444:      	mov	w9, #0x70               // =112
     448:      	ldr	x8, [x19, x8]
     44c:      	str	x8, [sp, #0x68]
     450:      	ldrb	w8, [x23, #0x16]
     454:      	ldr	x2, [x19, x8]
     458:      	mov	w8, #0x4                // =4
     45c:      	str	x0, [sp, #0x40]
     460:      	blr	x9
     464:      	cbnz	x0, 0x258 <perf_unwind_hotspot+0x258>
     468:      	ldrb	w8, [x23, #0x21]
     46c:      	str	x19, [sp, #0x8]
     470:      	cbz	w8, 0x48c <perf_unwind_hotspot+0x48c>
     474:      	ldr	x8, [sp, #0x50]
     478:      	ldr	w9, [sp, #0x58]
     47c:      	add	x9, x9, x8
     480:      	ldr	w10, [sp, #0x60]
     484:      	add	x8, x10, x8
     488:      	stp	x9, x8, [sp, #0x58]
     48c:      	add	x8, x21, #0xef0
     490:      	add	x19, sp, #0xc8
     494:      	str	x8, [sp, #0x20]
     498:      	ldr	w8, [x24]
     49c:      	cbnz	w8, 0x11c8 <perf_unwind_hotspot+0x11c8>
     4a0:      	add	x9, x19, #0x8
     4a4:      	add	x8, x19, #0x18
     4a8:      	ldr	w10, [sp, #0x70]
     4ac:      	stp	x8, x9, [sp, #0x10]
     4b0:      	ldp	x11, x8, [sp, #0x50]
     4b4:      	mov	w9, #0x616d             // =24941
     4b8:      	movk	w9, #0x6974, lsl #16
     4bc:      	cmp	w10, w9
     4c0:      	sub	w12, w22, w8
     4c4:      	b.gt	0x5fc <perf_unwind_hotspot+0x5fc>
     4c8:      	mov	w8, #0x7476             // =29814
     4cc:      	movk	w8, #0x6261, lsl #16
     4d0:      	cmp	w10, w8
     4d4:      	b.eq	0x798 <perf_unwind_hotspot+0x798>
     4d8:      	mov	w8, #0x6e49             // =28233
     4dc:      	movk	w8, #0x6574, lsl #16
     4e0:      	cmp	w10, w8
     4e4:      	b.ne	0x734 <perf_unwind_hotspot+0x734>
     4e8:      	cmp	x25, x29
     4ec:      	b.lo	0x52c0 <perf_unwind_hotspot+0x52c0>
     4f0:      	add	x8, x29, #0x1, lsl #12  // =0x1000
     4f4:      	cmp	x25, x8
     4f8:      	b.hs	0x52c0 <perf_unwind_hotspot+0x52c0>
     4fc:      	sub	x2, x25, #0x50
     500:      	mov	w8, #0x60               // =96
     504:      	mov	w9, #0x70               // =112
     508:      	add	x10, sp, #0xc8
     50c:      	add	x0, sp, #0xc8
     510:      	mov	w1, #0x60               // =96
     514:      	blr	x9
     518:      	cbz	x0, 0xec0 <perf_unwind_hotspot+0xec0>
     51c:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     520:      	ldr	x8, [x8]
     524:      	ldr	w8, [x8]
     528:      	cbz	w8, 0x52d0 <perf_unwind_hotspot+0x52d0>
     52c:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     530:      	add	x8, x8, #0x0
     534:      	add	x0, sp, #0x88
     538:      	ldp	x9, x10, [x8, #0x10]
     53c:      	mov	w1, #0x27               // =39
     540:      	stp	x9, x10, [sp, #0x98]
     544:      	ldur	x9, [x8, #0x1f]
     548:      	add	x10, sp, #0x88
     54c:      	stur	x9, [sp, #0xa7]
     550:      	ldp	x8, x9, [x8]
     554:      	stp	x8, x9, [sp, #0x88]
     558:      	mov	w8, #0x27               // =39
     55c:      	mov	w9, #0x6                // =6
     560:      	b	0x5364 <perf_unwind_hotspot+0x5364>
     564:      	mov	w8, #0xa                // =10
     568:      	add	x0, sp, #0xc8
     56c:      	mov	w1, #0x1a               // =26
     570:      	strh	w8, [sp, #0xe0]
     574:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     578:      	add	x8, x8, #0x0
     57c:      	ldp	x9, x10, [x8]
     580:      	ldr	x8, [x8, #0x10]
     584:      	str	x9, [sp, #0xc8]
     588:      	add	x9, sp, #0xc8
     58c:      	stp	x10, x8, [x9, #0x8]
     590:      	mov	w8, #0x1a               // =26
     594:      	mov	w9, #0x6                // =6
     598:      	add	x10, sp, #0xc8
     59c:      	ldr	w2, [x21, #0x2c0]
     5a0:      	blr	x9
     5a4:      	b	0x5c <perf_unwind_hotspot+0x5c>
     5a8:      	mov	w8, #0x6465             // =25701
     5ac:      	add	x13, sp, #0xc8
     5b0:      	add	x0, sp, #0xc8
     5b4:      	mov	w1, #0x34               // =52
     5b8:      	mov	w2, w25
     5bc:      	movk	w8, #0xa, lsl #16
     5c0:      	str	w8, [sp, #0xf8]
     5c4:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     5c8:      	add	x8, x8, #0x0
     5cc:      	ldp	x9, x10, [x8, #0x10]
     5d0:      	ldp	x11, x12, [x8, #0x20]
     5d4:      	str	x12, [x13, #0x28]
     5d8:      	stp	x10, x11, [x13, #0x18]
     5dc:      	ldp	x10, x8, [x8]
     5e0:      	str	x10, [sp, #0xc8]
     5e4:      	add	x10, sp, #0xc8
     5e8:      	stp	x8, x9, [x13, #0x8]
     5ec:      	mov	w8, #0x34               // =52
     5f0:      	mov	w9, #0x6                // =6
     5f4:      	blr	x9
     5f8:      	b	0x380 <perf_unwind_hotspot+0x380>
     5fc:      	mov	w9, #0x6d6e             // =28014
     600:      	movk	w9, #0x7465, lsl #16
     604:      	cmp	w10, w9
     608:      	b.eq	0x61c <perf_unwind_hotspot+0x61c>
     60c:      	mov	w9, #0x616e             // =24942
     610:      	movk	w9, #0x6974, lsl #16
     614:      	cmp	w10, w9
     618:      	b.ne	0x734 <perf_unwind_hotspot+0x734>
     61c:      	ldr	w9, [sp, #0x7c]
     620:      	ldrb	w10, [x23, #0x21]
     624:      	cmp	w10, #0x0
     628:      	str	x9, [sp, #0x28]
     62c:      	ldr	x9, [sp, #0x68]
     630:      	ldrb	w19, [x21, #0xf20]
     634:      	stp	x11, x12, [sp, #0x30]
     638:      	add	x11, x11, w9, uxtw
     63c:      	csel	x9, x9, x11, eq
     640:      	cmp	x22, x9
     644:      	b.ne	0x680 <perf_unwind_hotspot+0x680>
     648:      	ldr	w8, [sp, #0x74]
     64c:      	mov	w9, #0x8                // =8
     650:      	mov	w10, #0x70              // =112
     654:      	add	x11, sp, #0x88
     658:      	add	x0, sp, #0x88
     65c:      	mov	w1, #0x8                // =8
     660:      	add	x8, x29, x8
     664:      	ldr	w8, [sp, #0x74]
     668:      	add	x2, x29, x8
     66c:      	blr	x10
     670:      	cbz	x0, 0xcd4 <perf_unwind_hotspot+0xcd4>
     674:      	ldr	w8, [x24]
     678:      	cbnz	w8, 0x1310 <perf_unwind_hotspot+0x1310>
     67c:      	ldr	x8, [sp, #0x58]
     680:      	ldrh	w9, [sp, #0x80]
     684:      	add	x8, x8, x9
     688:      	cmp	x22, x8
     68c:      	b.hs	0x760 <perf_unwind_hotspot+0x760>
     690:      	sub	x8, x8, #0x4
     694:      	cmp	x22, x8
     698:      	b.ne	0x6a4 <perf_unwind_hotspot+0x6a4>
     69c:      	ldr	w8, [sp, #0x78]
     6a0:      	add	x29, x29, x8
     6a4:      	mov	x19, #0x3000000000000000 // =3458764513820540928
     6a8:      	b	0x7b4 <perf_unwind_hotspot+0x7b4>
     6ac:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     6b0:      	add	x8, x8, #0x0
     6b4:      	add	x11, sp, #0xc8
     6b8:      	strb	wzr, [sp, #0xe8]
     6bc:      	ldp	x9, x10, [x8]
     6c0:      	add	x0, sp, #0xc8
     6c4:      	mov	w1, #0x21               // =33
     6c8:      	str	x9, [sp, #0xc8]
     6cc:      	ldp	x9, x8, [x8, #0x10]
     6d0:      	stp	x10, x9, [x11, #0x8]
     6d4:      	str	x8, [x11, #0x18]
     6d8:      	mov	w8, #0x21               // =33
     6dc:      	mov	w9, #0x6                // =6
     6e0:      	add	x10, sp, #0xc8
     6e4:      	blr	x9
     6e8:      	b	0x18c <perf_unwind_hotspot+0x18c>
     6ec:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     6f0:      	add	x8, x8, #0x0
     6f4:      	add	x13, sp, #0xc8
     6f8:      	ldp	x9, x10, [x8, #0x10]
     6fc:      	ldp	x12, x11, [x8]
     700:      	add	x0, sp, #0xc8
     704:      	mov	w1, #0x26               // =38
     708:      	ldur	x8, [x8, #0x1e]
     70c:      	str	x10, [x13, #0x18]
     710:      	stp	x11, x9, [x13, #0x8]
     714:      	mov	w9, #0x6                // =6
     718:      	stur	x8, [x13, #0x1e]
     71c:      	str	x12, [sp, #0xc8]
     720:      	mov	w8, #0x26               // =38
     724:      	add	x10, sp, #0xc8
     728:      	blr	x9
     72c:      	mov	w0, wzr
     730:      	b	0x384 <perf_unwind_hotspot+0x384>
     734:      	mov	x8, x24
     738:      	ldr	x24, [x21, #0xf00]
     73c:      	stp	x11, x12, [sp, #0x30]
     740:      	str	x10, [sp, #0x28]
     744:      	ldr	w8, [x8]
     748:      	tbnz	x24, #0x3f, 0xcb8 <perf_unwind_hotspot+0xcb8>
     74c:      	cbnz	w8, 0x1358 <perf_unwind_hotspot+0x1358>
     750:      	ldr	w8, [sp, #0x78]
     754:      	mov	x19, xzr
     758:      	cbnz	w8, 0x14b8 <perf_unwind_hotspot+0x14b8>
     75c:      	b	0x14ac <perf_unwind_hotspot+0x14ac>
     760:      	cbz	w19, 0xd08 <perf_unwind_hotspot+0xd08>
     764:      	subs	x2, x25, x29
     768:      	b.lo	0xc54 <perf_unwind_hotspot+0xc54>
     76c:      	ldr	w8, [sp, #0x78]
     770:      	add	x8, x29, x8
     774:      	add	x8, x8, #0x30
     778:      	cmp	x25, x8
     77c:      	b.hs	0xc54 <perf_unwind_hotspot+0xc54>
     780:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     784:      	ldr	x8, [x8]
     788:      	ldr	w8, [x8]
     78c:      	cbnz	w8, 0x1d18 <perf_unwind_hotspot+0x1d18>
     790:      	mov	x19, #0x3000000000000000 // =3458764513820540928
     794:      	b	0x14ac <perf_unwind_hotspot+0x14ac>
     798:      	mov	w8, #0x7476             // =29814
     79c:      	stp	x11, x12, [sp, #0x30]
     7a0:      	movk	w8, #0x6261, lsl #16
     7a4:      	str	x8, [sp, #0x28]
     7a8:      	ldr	w8, [x24]
     7ac:      	cbnz	w8, 0x12d8 <perf_unwind_hotspot+0x12d8>
     7b0:      	mov	x19, #0x1000000000000000 // =1152921504606846976
     7b4:      	ldrb	w8, [x21, #0xf21]
     7b8:      	cbz	w8, 0xc4c <perf_unwind_hotspot+0xc4c>
     7bc:      	mov	w8, #0x2f               // =47
     7c0:      	adrp	x0, 0x0 <perf_unwind_hotspot>
     7c4:      	add	x9, sp, #0x88
     7c8:      	str	w8, [sp, #0x88]
     7cc:      	mov	w8, #0x1                // =1
     7d0:      	add	x1, sp, #0x88
     7d4:      	ldr	x0, [x0]
     7d8:      	blr	x8
     7dc:      	cbz	x0, 0xca0 <perf_unwind_hotspot+0xca0>
     7e0:      	ldr	x8, [x0]
     7e4:      	adrp	x24, 0x0 <perf_unwind_hotspot>
     7e8:      	add	x8, x8, #0x1
     7ec:      	str	x8, [x0]
     7f0:      	mov	w8, #0x3ec              // =1004
     7f4:      	ldr	x24, [x24]
     7f8:      	b	0x3c8 <perf_unwind_hotspot+0x3c8>
     7fc:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     800:      	add	x8, x8, #0x0
     804:      	add	x12, sp, #0xc8
     808:      	ldp	x9, x10, [x8, #0x10]
     80c:      	ldr	x11, [x8, #0x20]
     810:      	add	x0, sp, #0xc8
     814:      	mov	w1, #0x2e               // =46
     818:      	add	x20, sp, #0xc8
     81c:      	stp	x10, x11, [x12, #0x18]
     820:      	ldur	x10, [x8, #0x26]
     824:      	stur	x10, [x12, #0x26]
     828:      	ldp	x10, x8, [x8]
     82c:      	str	x10, [sp, #0xc8]
     830:      	stp	x8, x9, [x12, #0x8]
     834:      	mov	w8, #0x2e               // =46
     838:      	mov	w9, #0x6                // =6
     83c:      	add	x10, sp, #0xc8
     840:      	ldr	w2, [sp, #0x50]
     844:      	blr	x9
     848:      	ldr	w8, [x22]
     84c:      	ldr	x22, [x21, #0xed0]
     850:      	ldr	x29, [x21, #0xed8]
     854:      	ldr	x25, [x21, #0xee0]
     858:      	cbz	w8, 0x144 <perf_unwind_hotspot+0x144>
     85c:      	b	0xc4 <perf_unwind_hotspot+0xc4>
     860:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     864:      	add	x8, x8, #0x0
     868:      	add	x11, sp, #0xc8
     86c:      	ldp	x9, x10, [x8]
     870:      	add	x0, sp, #0xc8
     874:      	mov	w1, #0x1d               // =29
     878:      	mov	x2, x24
     87c:      	str	x9, [sp, #0xc8]
     880:      	ldr	x9, [x8, #0x10]
     884:      	ldur	x8, [x8, #0x15]
     888:      	add	x20, sp, #0xc8
     88c:      	stp	x10, x9, [x11, #0x8]
     890:      	stur	x8, [x11, #0x15]
     894:      	mov	w8, #0x1d               // =29
     898:      	mov	w9, #0x6                // =6
     89c:      	add	x10, sp, #0xc8
     8a0:      	ldrb	w3, [sp, #0x88]
     8a4:      	blr	x9
     8a8:      	ldrb	w8, [sp, #0x88]
     8ac:      	add	w9, w8, #0x1
     8b0:      	and	w9, w9, #0xff
     8b4:      	cmp	w9, #0x2
     8b8:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
     8bc:      	sub	x24, x24, x8
     8c0:      	mov	w8, #0x1                // =1
     8c4:      	mov	w9, #0x70               // =112
     8c8:      	add	x10, sp, #0x88
     8cc:      	add	x0, sp, #0x88
     8d0:      	mov	w1, #0x1                // =1
     8d4:      	add	x2, x24, x19
     8d8:      	blr	x9
     8dc:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
     8e0:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     8e4:      	ldr	x8, [x8]
     8e8:      	ldr	w8, [x8]
     8ec:      	cbnz	w8, 0xf6c <perf_unwind_hotspot+0xf6c>
     8f0:      	ldrb	w9, [sp, #0x88]
     8f4:      	add	w8, w9, #0x1
     8f8:      	and	w8, w8, #0xff
     8fc:      	cmp	w8, #0x2
     900:      	mov	w8, w9
     904:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
     908:      	sub	x24, x24, x9
     90c:      	mov	w8, #0x1                // =1
     910:      	mov	w9, #0x70               // =112
     914:      	add	x10, sp, #0x88
     918:      	add	x0, sp, #0x88
     91c:      	mov	w1, #0x1                // =1
     920:      	add	x2, x24, x19
     924:      	blr	x9
     928:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
     92c:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     930:      	ldr	x8, [x8]
     934:      	ldr	w8, [x8]
     938:      	cbnz	w8, 0x1100 <perf_unwind_hotspot+0x1100>
     93c:      	ldrb	w9, [sp, #0x88]
     940:      	add	w8, w9, #0x1
     944:      	and	w8, w8, #0xff
     948:      	cmp	w8, #0x2
     94c:      	mov	w8, w9
     950:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
     954:      	sub	x24, x24, x9
     958:      	mov	w8, #0x1                // =1
     95c:      	mov	w9, #0x70               // =112
     960:      	add	x10, sp, #0x88
     964:      	add	x0, sp, #0x88
     968:      	mov	w1, #0x1                // =1
     96c:      	add	x2, x24, x19
     970:      	blr	x9
     974:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
     978:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     97c:      	ldr	x8, [x8]
     980:      	ldr	w8, [x8]
     984:      	cbnz	w8, 0x1164 <perf_unwind_hotspot+0x1164>
     988:      	ldrb	w9, [sp, #0x88]
     98c:      	add	w8, w9, #0x1
     990:      	and	w8, w8, #0xff
     994:      	cmp	w8, #0x2
     998:      	mov	w8, w9
     99c:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
     9a0:      	sub	x24, x24, x9
     9a4:      	mov	w8, #0x1                // =1
     9a8:      	mov	w9, #0x70               // =112
     9ac:      	add	x10, sp, #0x88
     9b0:      	add	x0, sp, #0x88
     9b4:      	mov	w1, #0x1                // =1
     9b8:      	add	x2, x24, x19
     9bc:      	blr	x9
     9c0:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
     9c4:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     9c8:      	ldr	x8, [x8]
     9cc:      	ldr	w8, [x8]
     9d0:      	cbnz	w8, 0x1274 <perf_unwind_hotspot+0x1274>
     9d4:      	ldrb	w9, [sp, #0x88]
     9d8:      	add	w8, w9, #0x1
     9dc:      	and	w8, w8, #0xff
     9e0:      	cmp	w8, #0x2
     9e4:      	mov	w8, w9
     9e8:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
     9ec:      	sub	x24, x24, x9
     9f0:      	mov	w8, #0x1                // =1
     9f4:      	mov	w9, #0x70               // =112
     9f8:      	add	x10, sp, #0x88
     9fc:      	add	x0, sp, #0x88
     a00:      	mov	w1, #0x1                // =1
     a04:      	add	x2, x24, x19
     a08:      	blr	x9
     a0c:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
     a10:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     a14:      	ldr	x8, [x8]
     a18:      	ldr	w8, [x8]
     a1c:      	cbnz	w8, 0x13f8 <perf_unwind_hotspot+0x13f8>
     a20:      	ldrb	w9, [sp, #0x88]
     a24:      	add	w8, w9, #0x1
     a28:      	and	w8, w8, #0xff
     a2c:      	cmp	w8, #0x2
     a30:      	mov	w8, w9
     a34:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
     a38:      	sub	x24, x24, x9
     a3c:      	mov	w8, #0x1                // =1
     a40:      	mov	w9, #0x70               // =112
     a44:      	add	x10, sp, #0x88
     a48:      	add	x0, sp, #0x88
     a4c:      	mov	w1, #0x1                // =1
     a50:      	add	x2, x24, x19
     a54:      	blr	x9
     a58:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
     a5c:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     a60:      	ldr	x8, [x8]
     a64:      	ldr	w8, [x8]
     a68:      	cbnz	w8, 0x1eb8 <perf_unwind_hotspot+0x1eb8>
     a6c:      	ldrb	w9, [sp, #0x88]
     a70:      	add	w8, w9, #0x1
     a74:      	and	w8, w8, #0xff
     a78:      	cmp	w8, #0x2
     a7c:      	mov	w8, w9
     a80:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
     a84:      	sub	x24, x24, x9
     a88:      	mov	w8, #0x1                // =1
     a8c:      	mov	w9, #0x70               // =112
     a90:      	add	x10, sp, #0x88
     a94:      	add	x0, sp, #0x88
     a98:      	mov	w1, #0x1                // =1
     a9c:      	add	x2, x24, x19
     aa0:      	blr	x9
     aa4:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
     aa8:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     aac:      	ldr	x8, [x8]
     ab0:      	ldr	w8, [x8]
     ab4:      	cbnz	w8, 0x2580 <perf_unwind_hotspot+0x2580>
     ab8:      	ldrb	w9, [sp, #0x88]
     abc:      	add	w8, w9, #0x1
     ac0:      	and	w8, w8, #0xff
     ac4:      	cmp	w8, #0x2
     ac8:      	mov	w8, w9
     acc:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
     ad0:      	sub	x24, x24, x9
     ad4:      	mov	w8, #0x1                // =1
     ad8:      	mov	w9, #0x70               // =112
     adc:      	add	x10, sp, #0x88
     ae0:      	add	x0, sp, #0x88
     ae4:      	mov	w1, #0x1                // =1
     ae8:      	add	x2, x24, x19
     aec:      	blr	x9
     af0:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
     af4:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     af8:      	ldr	x8, [x8]
     afc:      	ldr	w8, [x8]
     b00:      	cbnz	w8, 0x2748 <perf_unwind_hotspot+0x2748>
     b04:      	ldrb	w9, [sp, #0x88]
     b08:      	add	w8, w9, #0x1
     b0c:      	and	w8, w8, #0xff
     b10:      	cmp	w8, #0x2
     b14:      	mov	w8, w9
     b18:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
     b1c:      	sub	x24, x24, x9
     b20:      	mov	w8, #0x1                // =1
     b24:      	mov	w9, #0x70               // =112
     b28:      	add	x10, sp, #0x88
     b2c:      	add	x0, sp, #0x88
     b30:      	mov	w1, #0x1                // =1
     b34:      	add	x2, x24, x19
     b38:      	blr	x9
     b3c:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
     b40:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     b44:      	ldr	x8, [x8]
     b48:      	ldr	w8, [x8]
     b4c:      	cbnz	w8, 0x2858 <perf_unwind_hotspot+0x2858>
     b50:      	ldrb	w9, [sp, #0x88]
     b54:      	add	w8, w9, #0x1
     b58:      	and	w8, w8, #0xff
     b5c:      	cmp	w8, #0x2
     b60:      	mov	w8, w9
     b64:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
     b68:      	sub	x24, x24, x9
     b6c:      	mov	w8, #0x1                // =1
     b70:      	mov	w9, #0x70               // =112
     b74:      	add	x10, sp, #0x88
     b78:      	add	x0, sp, #0x88
     b7c:      	mov	w1, #0x1                // =1
     b80:      	add	x2, x24, x19
     b84:      	blr	x9
     b88:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
     b8c:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     b90:      	ldr	x8, [x8]
     b94:      	ldr	w8, [x8]
     b98:      	cbnz	w8, 0x291c <perf_unwind_hotspot+0x291c>
     b9c:      	ldrb	w9, [sp, #0x88]
     ba0:      	add	w8, w9, #0x1
     ba4:      	and	w8, w8, #0xff
     ba8:      	cmp	w8, #0x2
     bac:      	mov	w8, w9
     bb0:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
     bb4:      	sub	x24, x24, x9
     bb8:      	mov	w8, #0x1                // =1
     bbc:      	mov	w9, #0x70               // =112
     bc0:      	add	x10, sp, #0x88
     bc4:      	add	x0, sp, #0x88
     bc8:      	mov	w1, #0x1                // =1
     bcc:      	add	x2, x24, x19
     bd0:      	blr	x9
     bd4:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
     bd8:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     bdc:      	ldr	x8, [x8]
     be0:      	ldr	w8, [x8]
     be4:      	cbnz	w8, 0x2a8c <perf_unwind_hotspot+0x2a8c>
     be8:      	ldrb	w8, [sp, #0x88]
     bec:      	add	w9, w8, #0x1
     bf0:      	and	w9, w9, #0xff
     bf4:      	cmp	w9, #0x1
     bf8:      	b.hi	0x178 <perf_unwind_hotspot+0x178>
     bfc:      	b	0x1fc <perf_unwind_hotspot+0x1fc>
     c00:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     c04:      	add	x8, x8, #0x0
     c08:      	add	x12, sp, #0xc8
     c0c:      	ldp	x9, x10, [x8, #0x10]
     c10:      	ldr	x11, [x8, #0x20]
     c14:      	add	x0, sp, #0xc8
     c18:      	mov	w1, #0x2e               // =46
     c1c:      	stp	x10, x11, [x12, #0x18]
     c20:      	ldur	x10, [x8, #0x26]
     c24:      	stur	x10, [x12, #0x26]
     c28:      	ldp	x10, x8, [x8]
     c2c:      	str	x10, [sp, #0xc8]
     c30:      	stp	x8, x9, [x12, #0x8]
     c34:      	mov	w8, #0x2e               // =46
     c38:      	mov	w9, #0x6                // =6
     c3c:      	add	x10, sp, #0xc8
     c40:      	ldr	w2, [sp, #0x88]
     c44:      	blr	x9
     c48:      	b	0x2ac <perf_unwind_hotspot+0x2ac>
     c4c:      	ldr	x20, [x21, #0xee8]
     c50:      	b	0x14fc <perf_unwind_hotspot+0x14fc>
     c54:      	sub	x2, x22, #0x8
     c58:      	mov	w8, #0x8                // =8
     c5c:      	mov	w9, #0x70               // =112
     c60:      	add	x10, sp, #0xc8
     c64:      	add	x0, sp, #0xc8
     c68:      	mov	w1, #0x8                // =8
     c6c:      	blr	x9
     c70:      	ldr	x8, [sp, #0xc8]
     c74:      	mov	x9, #0x27ff             // =10239
     c78:      	mov	x19, #0x3000000000000000 // =3458764513820540928
     c7c:      	movk	x9, #0xa9bf, lsl #16
     c80:      	movk	x9, #0x100, lsl #32
     c84:      	movk	x9, #0xd63f, lsl #48
     c88:      	cmp	x8, x9
     c8c:      	add	x8, x29, #0x10
     c90:      	ccmp	x0, #0x0, #0x0, eq
     c94:      	csel	x29, x8, x29, eq
     c98:      	ldr	w8, [sp, #0x78]
     c9c:      	b	0x14b8 <perf_unwind_hotspot+0x14b8>
     ca0:      	adrp	x24, 0x0 <perf_unwind_hotspot>
     ca4:      	ldr	x24, [x24]
     ca8:      	ldr	w8, [x24]
     cac:      	cbnz	w8, 0x13ac <perf_unwind_hotspot+0x13ac>
     cb0:      	mov	w8, #0x3ec              // =1004
     cb4:      	b	0x3c8 <perf_unwind_hotspot+0x3c8>
     cb8:      	cbnz	w8, 0x145c <perf_unwind_hotspot+0x145c>
     cbc:      	mov	x19, xzr
     cc0:      	tbnz	x24, #0x3e, 0x14ac <perf_unwind_hotspot+0x14ac>
     cc4:      	lsr	x8, x24, #53
     cc8:      	and	x8, x8, #0x1f8
     ccc:      	add	x29, x8, x29
     cd0:      	b	0x7b4 <perf_unwind_hotspot+0x7b4>
     cd4:      	ldr	x9, [sp, #0x88]
     cd8:      	ldr	x8, [sp, #0x58]
     cdc:      	cmp	x9, x8
     ce0:      	b.lo	0x674 <perf_unwind_hotspot+0x674>
     ce4:      	ldr	x10, [sp, #0x60]
     ce8:      	cmp	x9, x10
     cec:      	b.hs	0x674 <perf_unwind_hotspot+0x674>
     cf0:      	ldr	w10, [x24]
     cf4:      	cbnz	w10, 0x1da4 <perf_unwind_hotspot+0x1da4>
     cf8:      	mov	x22, x9
     cfc:      	sub	w8, w22, w8
     d00:      	str	x8, [sp, #0x38]
     d04:      	b	0x67c <perf_unwind_hotspot+0x67c>
     d08:      	ldr	w19, [sp, #0x78]
     d0c:      	cmp	w19, #0x210
     d10:      	b.lo	0xde4 <perf_unwind_hotspot+0xde4>
     d14:      	mov	w8, #0x30               // =48
     d18:      	adrp	x0, 0x0 <perf_unwind_hotspot>
     d1c:      	add	x9, sp, #0x88
     d20:      	str	w8, [sp, #0x88]
     d24:      	mov	w8, #0x1                // =1
     d28:      	add	x1, sp, #0x88
     d2c:      	ldr	x0, [x0]
     d30:      	blr	x8
     d34:      	cbz	x0, 0x1010 <perf_unwind_hotspot+0x1010>
     d38:      	ldr	x8, [x0]
     d3c:      	add	x8, x8, #0x1
     d40:      	str	x8, [x0]
     d44:      	b	0x764 <perf_unwind_hotspot+0x764>
     d48:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     d4c:      	add	x8, x8, #0x0
     d50:      	add	x12, sp, #0xc8
     d54:      	ldp	x9, x10, [x8, #0x10]
     d58:      	ldr	x11, [x8, #0x20]
     d5c:      	add	x0, sp, #0xc8
     d60:      	mov	w1, #0x2e               // =46
     d64:      	stp	x10, x11, [x12, #0x18]
     d68:      	ldur	x10, [x8, #0x26]
     d6c:      	stur	x10, [x12, #0x26]
     d70:      	ldp	x10, x8, [x8]
     d74:      	str	x10, [sp, #0xc8]
     d78:      	stp	x8, x9, [x12, #0x8]
     d7c:      	mov	w8, #0x2e               // =46
     d80:      	mov	w9, #0x6                // =6
     d84:      	add	x10, sp, #0xc8
     d88:      	ldr	w2, [sp, #0x50]
     d8c:      	blr	x9
     d90:      	b	0x344 <perf_unwind_hotspot+0x344>
     d94:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     d98:      	add	x8, x8, #0x0
     d9c:      	add	x11, sp, #0xc8
     da0:      	strb	wzr, [sp, #0xe8]
     da4:      	ldp	x9, x10, [x8]
     da8:      	add	x0, sp, #0xc8
     dac:      	mov	w1, #0x21               // =33
     db0:      	mov	x2, x24
     db4:      	str	x9, [sp, #0xc8]
     db8:      	ldp	x9, x8, [x8, #0x10]
     dbc:      	add	x20, sp, #0xc8
     dc0:      	stp	x10, x9, [x11, #0x8]
     dc4:      	str	x8, [x11, #0x18]
     dc8:      	mov	w8, #0x21               // =33
     dcc:      	mov	w9, #0x6                // =6
     dd0:      	add	x10, sp, #0xc8
     dd4:      	blr	x9
     dd8:      	str	x24, [sp, #0x50]
     ddc:      	cbnz	x24, 0x230 <perf_unwind_hotspot+0x230>
     de0:      	b	0x17c <perf_unwind_hotspot+0x17c>
     de4:      	sub	x2, x22, #0x14
     de8:      	mov	w8, #0x18               // =24
     dec:      	mov	w9, #0x70               // =112
     df0:      	add	x10, sp, #0xc8
     df4:      	add	x0, sp, #0xc8
     df8:      	mov	w1, #0x18               // =24
     dfc:      	blr	x9
     e00:      	cbnz	x0, 0x764 <perf_unwind_hotspot+0x764>
     e04:      	lsl	w9, w19, #12
     e08:      	mov	x10, #0x7fffffffffff0000 // =9223372036854710272
     e0c:      	mov	x8, xzr
     e10:      	and	x9, x9, #0x3f8000
     e14:      	add	x9, x9, x10
     e18:      	mov	x10, #0x7bfd            // =31741
     e1c:      	movk	x10, #0xa940, lsl #16
     e20:      	orr	x9, x9, x19, lsl #42
     e24:      	movk	x10, #0x3ff, lsl #32
     e28:      	movk	x10, #0x9100, lsl #48
     e2c:      	orr	x9, x9, x10
     e30:      	ldr	x10, [sp, #0xc8]
     e34:      	cmp	x10, x9
     e38:      	b.eq	0xe70 <perf_unwind_hotspot+0xe70>
     e3c:      	ldur	x10, [x20, #0x4]
     e40:      	cmp	x10, x9
     e44:      	b.eq	0xe70 <perf_unwind_hotspot+0xe70>
     e48:      	ldr	x10, [x20, #0x8]
     e4c:      	cmp	x10, x9
     e50:      	b.eq	0xe70 <perf_unwind_hotspot+0xe70>
     e54:      	ldur	x10, [x20, #0xc]
     e58:      	cmp	x10, x9
     e5c:      	b.eq	0xe70 <perf_unwind_hotspot+0xe70>
     e60:      	ldr	x8, [x20, #0x10]
     e64:      	cmp	x8, x9
     e68:      	b.ne	0x764 <perf_unwind_hotspot+0x764>
     e6c:      	ldr	w8, [sp, #0x78]
     e70:      	add	x29, x8, x29
     e74:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     e78:      	ldr	x8, [x8]
     e7c:      	ldr	w8, [x8]
     e80:      	cbz	w8, 0x6a4 <perf_unwind_hotspot+0x6a4>
     e84:      	mov	w8, #0x6573             // =25971
     e88:      	add	x10, sp, #0x88
     e8c:      	add	x0, sp, #0x88
     e90:      	mov	w1, #0x14               // =20
     e94:      	movk	w8, #0xa, lsl #16
     e98:      	str	w8, [sp, #0x98]
     e9c:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     ea0:      	add	x8, x8, #0x0
     ea4:      	ldp	x9, x8, [x8]
     ea8:      	stp	x9, x8, [sp, #0x88]
     eac:      	mov	w8, #0x14               // =20
     eb0:      	mov	w9, #0x6                // =6
     eb4:      	blr	x9
     eb8:      	mov	x19, #0x3000000000000000 // =3458764513820540928
     ebc:      	b	0x7b4 <perf_unwind_hotspot+0x7b4>
     ec0:      	ldr	w9, [x21, #0x2c0]
     ec4:      	ldr	x8, [sp, #0x20]
     ec8:      	cbz	w9, 0xedc <perf_unwind_hotspot+0xedc>
     ecc:      	ldrb	w8, [x23, #0x1f]
     ed0:      	cmp	w8, #0x0
     ed4:      	ldp	x9, x8, [sp, #0x10]
     ed8:      	csel	x8, x9, x8, eq
     edc:      	ldr	x19, [x8]
     ee0:      	add	x8, sp, #0xc8
     ee4:      	mov	w9, #0x8                // =8
     ee8:      	mov	w10, #0x70              // =112
     eec:      	ldr	x12, [x8, #0x38]
     ef0:      	ldp	x29, x25, [x8, #0x48]
     ef4:      	add	x11, sp, #0xc0
     ef8:      	add	x0, sp, #0xc0
     efc:      	mov	w1, #0x8                // =8
     f00:      	ldr	x20, [x8, #0x58]
     f04:      	ldrb	w8, [x23, #0x1c]
     f08:      	add	x8, x12, x8
     f0c:      	str	x12, [sp, #0x30]
     f10:      	ldrb	w8, [x23, #0x1c]
     f14:      	add	x2, x12, x8
     f18:      	blr	x10
     f1c:      	cbz	x0, 0x106c <perf_unwind_hotspot+0x106c>
     f20:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     f24:      	ldr	x8, [x8]
     f28:      	ldr	w8, [x8]
     f2c:      	cbz	w8, 0x52d0 <perf_unwind_hotspot+0x52d0>
     f30:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     f34:      	add	x8, x8, #0x0
     f38:      	strb	wzr, [sp, #0xb0]
     f3c:      	add	x0, sp, #0x88
     f40:      	ldp	x9, x10, [x8, #0x10]
     f44:      	mov	w1, #0x29               // =41
     f48:      	stp	x9, x10, [sp, #0x98]
     f4c:      	ldr	x9, [x8, #0x20]
     f50:      	add	x10, sp, #0x88
     f54:      	str	x9, [sp, #0xa8]
     f58:      	ldp	x8, x9, [x8]
     f5c:      	stp	x8, x9, [sp, #0x88]
     f60:      	mov	w8, #0x29               // =41
     f64:      	mov	w9, #0x6                // =6
     f68:      	b	0x5364 <perf_unwind_hotspot+0x5364>
     f6c:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     f70:      	add	x8, x8, #0x0
     f74:      	add	x11, sp, #0xc8
     f78:      	ldp	x9, x10, [x8]
     f7c:      	add	x0, sp, #0xc8
     f80:      	mov	w1, #0x1d               // =29
     f84:      	mov	x2, x24
     f88:      	str	x9, [sp, #0xc8]
     f8c:      	ldr	x9, [x8, #0x10]
     f90:      	ldur	x8, [x8, #0x15]
     f94:      	add	x20, sp, #0xc8
     f98:      	stp	x10, x9, [x11, #0x8]
     f9c:      	stur	x8, [x11, #0x15]
     fa0:      	mov	w8, #0x1d               // =29
     fa4:      	mov	w9, #0x6                // =6
     fa8:      	add	x10, sp, #0xc8
     fac:      	ldrb	w3, [sp, #0x88]
     fb0:      	blr	x9
     fb4:      	ldrb	w9, [sp, #0x88]
     fb8:      	add	w8, w9, #0x1
     fbc:      	and	w8, w8, #0xff
     fc0:      	cmp	w8, #0x2
     fc4:      	mov	w8, w9
     fc8:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
     fcc:      	b	0x908 <perf_unwind_hotspot+0x908>
     fd0:      	adrp	x8, 0x0 <perf_unwind_hotspot>
     fd4:      	add	x8, x8, #0x0
     fd8:      	add	x11, sp, #0xc8
     fdc:      	ldp	x9, x10, [x8]
     fe0:      	add	x0, sp, #0xc8
     fe4:      	mov	w1, #0x1e               // =30
     fe8:      	str	x9, [sp, #0xc8]
     fec:      	ldr	x9, [x8, #0x10]
     ff0:      	ldur	x8, [x8, #0x16]
     ff4:      	stp	x10, x9, [x11, #0x8]
     ff8:      	mov	w9, #0x6                // =6
     ffc:      	stur	x8, [x11, #0x16]
    1000:      	mov	w8, #0x1e               // =30
    1004:      	add	x10, sp, #0xc8
    1008:      	blr	x9
    100c:      	b	0x260 <perf_unwind_hotspot+0x260>
    1010:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1014:      	ldr	x8, [x8]
    1018:      	ldr	w8, [x8]
    101c:      	cbz	w8, 0x764 <perf_unwind_hotspot+0x764>
    1020:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1024:      	add	x8, x8, #0x0
    1028:      	add	x12, sp, #0xc8
    102c:      	ldp	x9, x10, [x8, #0x10]
    1030:      	ldr	x11, [x8, #0x20]
    1034:      	add	x0, sp, #0xc8
    1038:      	mov	w1, #0x2e               // =46
    103c:      	stp	x10, x11, [x12, #0x18]
    1040:      	ldur	x10, [x8, #0x26]
    1044:      	stur	x10, [x12, #0x26]
    1048:      	ldp	x10, x8, [x8]
    104c:      	str	x10, [sp, #0xc8]
    1050:      	stp	x8, x9, [x12, #0x8]
    1054:      	mov	w8, #0x2e               // =46
    1058:      	mov	w9, #0x6                // =6
    105c:      	add	x10, sp, #0xc8
    1060:      	ldr	w2, [sp, #0x88]
    1064:      	blr	x9
    1068:      	b	0x764 <perf_unwind_hotspot+0x764>
    106c:      	ldr	x8, [sp, #0xc0]
    1070:      	ldrb	w9, [x23, #0x1d]
    1074:      	add	x9, x8, x9
    1078:      	cmp	x19, x9
    107c:      	csel	x9, xzr, x9, lo
    1080:      	sub	x19, x19, x9
    1084:      	adrp	x9, 0x1000 <perf_unwind_hotspot+0x1000>
    1088:      	ldr	x9, [x9]
    108c:      	ldr	w9, [x9]
    1090:      	cbnz	w9, 0x1f1c <perf_unwind_hotspot+0x1f1c>
    1094:      	mov	w9, #0xffff             // =65535
    1098:      	lsr	x8, x8, #3
    109c:      	cmp	x19, x9
    10a0:      	str	x8, [sp, #0x28]
    10a4:      	csel	x9, x19, x9, lo
    10a8:      	mov	x19, #0x2000000000000000 // =2305843009213693952
    10ac:      	str	x9, [sp, #0x38]
    10b0:      	b	0x14fc <perf_unwind_hotspot+0x14fc>
    10b4:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    10b8:      	add	x8, x8, #0x0
    10bc:      	add	x12, sp, #0xc8
    10c0:      	ldp	x9, x10, [x8, #0x10]
    10c4:      	ldr	x11, [x8, #0x20]
    10c8:      	add	x0, sp, #0xc8
    10cc:      	mov	w1, #0x2e               // =46
    10d0:      	stp	x10, x11, [x12, #0x18]
    10d4:      	ldur	x10, [x8, #0x26]
    10d8:      	stur	x10, [x12, #0x26]
    10dc:      	ldp	x10, x8, [x8]
    10e0:      	str	x10, [sp, #0xc8]
    10e4:      	stp	x8, x9, [x12, #0x8]
    10e8:      	mov	w8, #0x2e               // =46
    10ec:      	mov	w9, #0x6                // =6
    10f0:      	add	x10, sp, #0xc8
    10f4:      	ldr	w2, [sp, #0x88]
    10f8:      	blr	x9
    10fc:      	b	0x3ec <perf_unwind_hotspot+0x3ec>
    1100:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1104:      	add	x8, x8, #0x0
    1108:      	add	x11, sp, #0xc8
    110c:      	ldp	x9, x10, [x8]
    1110:      	add	x0, sp, #0xc8
    1114:      	mov	w1, #0x1d               // =29
    1118:      	mov	x2, x24
    111c:      	str	x9, [sp, #0xc8]
    1120:      	ldr	x9, [x8, #0x10]
    1124:      	ldur	x8, [x8, #0x15]
    1128:      	add	x20, sp, #0xc8
    112c:      	stp	x10, x9, [x11, #0x8]
    1130:      	stur	x8, [x11, #0x15]
    1134:      	mov	w8, #0x1d               // =29
    1138:      	mov	w9, #0x6                // =6
    113c:      	add	x10, sp, #0xc8
    1140:      	ldrb	w3, [sp, #0x88]
    1144:      	blr	x9
    1148:      	ldrb	w9, [sp, #0x88]
    114c:      	add	w8, w9, #0x1
    1150:      	and	w8, w8, #0xff
    1154:      	cmp	w8, #0x2
    1158:      	mov	w8, w9
    115c:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
    1160:      	b	0x954 <perf_unwind_hotspot+0x954>
    1164:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1168:      	add	x8, x8, #0x0
    116c:      	add	x11, sp, #0xc8
    1170:      	ldp	x9, x10, [x8]
    1174:      	add	x0, sp, #0xc8
    1178:      	mov	w1, #0x1d               // =29
    117c:      	mov	x2, x24
    1180:      	str	x9, [sp, #0xc8]
    1184:      	ldr	x9, [x8, #0x10]
    1188:      	ldur	x8, [x8, #0x15]
    118c:      	add	x20, sp, #0xc8
    1190:      	stp	x10, x9, [x11, #0x8]
    1194:      	stur	x8, [x11, #0x15]
    1198:      	mov	w8, #0x1d               // =29
    119c:      	mov	w9, #0x6                // =6
    11a0:      	add	x10, sp, #0xc8
    11a4:      	ldrb	w3, [sp, #0x88]
    11a8:      	blr	x9
    11ac:      	ldrb	w9, [sp, #0x88]
    11b0:      	add	w8, w9, #0x1
    11b4:      	and	w8, w8, #0xff
    11b8:      	cmp	w8, #0x2
    11bc:      	mov	w8, w9
    11c0:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
    11c4:      	b	0x9a0 <perf_unwind_hotspot+0x9a0>
    11c8:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    11cc:      	add	x8, x8, #0x0
    11d0:      	add	x0, sp, #0xc8
    11d4:      	ldp	x9, x10, [x8]
    11d8:      	ldur	x8, [x8, #0xf]
    11dc:      	mov	w1, #0x17               // =23
    11e0:      	add	x20, sp, #0xc8
    11e4:      	str	x9, [sp, #0xc8]
    11e8:      	add	x9, sp, #0xc8
    11ec:      	str	x10, [x9, #0x8]
    11f0:      	stur	x8, [x9, #0xf]
    11f4:      	mov	w8, #0x17               // =23
    11f8:      	mov	w9, #0x6                // =6
    11fc:      	add	x10, sp, #0xc8
    1200:      	ldp	x2, x3, [sp, #0x58]
    1204:      	blr	x9
    1208:      	ldr	w8, [x24]
    120c:      	cbz	w8, 0x4a0 <perf_unwind_hotspot+0x4a0>
    1210:      	mov	w8, #0x7825             // =30757
    1214:      	add	x13, sp, #0xc8
    1218:      	add	x0, sp, #0xc8
    121c:      	mov	w1, #0x3c               // =60
    1220:      	add	x20, sp, #0xc8
    1224:      	movk	w8, #0xa, lsl #16
    1228:      	str	w8, [sp, #0x100]
    122c:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1230:      	add	x8, x8, #0x0
    1234:      	ldp	x9, x10, [x8, #0x20]
    1238:      	ldp	x12, x11, [x8, #0x10]
    123c:      	stp	x11, x9, [x13, #0x18]
    1240:      	ldr	x9, [x8, #0x30]
    1244:      	stp	x10, x9, [x13, #0x28]
    1248:      	add	x10, sp, #0xc8
    124c:      	ldp	x9, x8, [x8]
    1250:      	str	x9, [sp, #0xc8]
    1254:      	stp	x8, x12, [x13, #0x8]
    1258:      	mov	w8, #0x3c               // =60
    125c:      	mov	w9, #0x6                // =6
    1260:      	ldrh	w2, [sp, #0x80]
    1264:      	ldr	w3, [sp, #0x78]
    1268:      	ldr	w4, [sp, #0x70]
    126c:      	blr	x9
    1270:      	b	0x4a0 <perf_unwind_hotspot+0x4a0>
    1274:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1278:      	add	x8, x8, #0x0
    127c:      	add	x11, sp, #0xc8
    1280:      	ldp	x9, x10, [x8]
    1284:      	add	x0, sp, #0xc8
    1288:      	mov	w1, #0x1d               // =29
    128c:      	mov	x2, x24
    1290:      	str	x9, [sp, #0xc8]
    1294:      	ldr	x9, [x8, #0x10]
    1298:      	ldur	x8, [x8, #0x15]
    129c:      	add	x20, sp, #0xc8
    12a0:      	stp	x10, x9, [x11, #0x8]
    12a4:      	stur	x8, [x11, #0x15]
    12a8:      	mov	w8, #0x1d               // =29
    12ac:      	mov	w9, #0x6                // =6
    12b0:      	add	x10, sp, #0xc8
    12b4:      	ldrb	w3, [sp, #0x88]
    12b8:      	blr	x9
    12bc:      	ldrb	w9, [sp, #0x88]
    12c0:      	add	w8, w9, #0x1
    12c4:      	and	w8, w8, #0xff
    12c8:      	cmp	w8, #0x2
    12cc:      	mov	w8, w9
    12d0:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
    12d4:      	b	0x9ec <perf_unwind_hotspot+0x9ec>
    12d8:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    12dc:      	add	x8, x8, #0x0
    12e0:      	add	x0, sp, #0xc8
    12e4:      	ldp	x9, x10, [x8]
    12e8:      	ldr	x8, [x8, #0x10]
    12ec:      	mov	w1, #0x18               // =24
    12f0:      	str	x9, [sp, #0xc8]
    12f4:      	add	x9, sp, #0xc8
    12f8:      	stp	x10, x8, [x9, #0x8]
    12fc:      	mov	w8, #0x18               // =24
    1300:      	mov	w9, #0x6                // =6
    1304:      	add	x10, sp, #0xc8
    1308:      	blr	x9
    130c:      	b	0x7b0 <perf_unwind_hotspot+0x7b0>
    1310:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1314:      	add	x8, x8, #0x0
    1318:      	add	x13, sp, #0xc8
    131c:      	ldp	x9, x10, [x8, #0x10]
    1320:      	ldp	x11, x12, [x8, #0x20]
    1324:      	add	x0, sp, #0xc8
    1328:      	mov	w1, #0x30               // =48
    132c:      	add	x20, sp, #0xc8
    1330:      	str	x12, [x13, #0x28]
    1334:      	stp	x10, x11, [x13, #0x18]
    1338:      	ldp	x10, x8, [x8]
    133c:      	str	x10, [sp, #0xc8]
    1340:      	stp	x8, x9, [x13, #0x8]
    1344:      	mov	w8, #0x30               // =48
    1348:      	mov	w9, #0x6                // =6
    134c:      	add	x10, sp, #0xc8
    1350:      	blr	x9
    1354:      	b	0x67c <perf_unwind_hotspot+0x67c>
    1358:      	mov	w8, #0x6874             // =26740
    135c:      	add	x11, sp, #0xc8
    1360:      	add	x0, sp, #0xc8
    1364:      	mov	w1, #0x24               // =36
    1368:      	movk	w8, #0xa, lsl #16
    136c:      	str	w8, [sp, #0xe8]
    1370:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1374:      	add	x8, x8, #0x0
    1378:      	ldp	x9, x10, [x8]
    137c:      	str	x9, [sp, #0xc8]
    1380:      	ldp	x9, x8, [x8, #0x10]
    1384:      	stp	x10, x9, [x11, #0x8]
    1388:      	str	x8, [x11, #0x18]
    138c:      	mov	w8, #0x24               // =36
    1390:      	mov	w9, #0x6                // =6
    1394:      	add	x10, sp, #0xc8
    1398:      	blr	x9
    139c:      	ldr	w8, [sp, #0x78]
    13a0:      	mov	x19, xzr
    13a4:      	cbnz	w8, 0x14b8 <perf_unwind_hotspot+0x14b8>
    13a8:      	b	0x14ac <perf_unwind_hotspot+0x14ac>
    13ac:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    13b0:      	add	x8, x8, #0x0
    13b4:      	add	x12, sp, #0xc8
    13b8:      	ldp	x9, x10, [x8, #0x10]
    13bc:      	ldr	x11, [x8, #0x20]
    13c0:      	add	x0, sp, #0xc8
    13c4:      	mov	w1, #0x2e               // =46
    13c8:      	stp	x10, x11, [x12, #0x18]
    13cc:      	ldur	x10, [x8, #0x26]
    13d0:      	stur	x10, [x12, #0x26]
    13d4:      	ldp	x10, x8, [x8]
    13d8:      	str	x10, [sp, #0xc8]
    13dc:      	stp	x8, x9, [x12, #0x8]
    13e0:      	mov	w8, #0x2e               // =46
    13e4:      	mov	w9, #0x6                // =6
    13e8:      	add	x10, sp, #0xc8
    13ec:      	ldr	w2, [sp, #0x88]
    13f0:      	blr	x9
    13f4:      	b	0xcb0 <perf_unwind_hotspot+0xcb0>
    13f8:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    13fc:      	add	x8, x8, #0x0
    1400:      	add	x11, sp, #0xc8
    1404:      	ldp	x9, x10, [x8]
    1408:      	add	x0, sp, #0xc8
    140c:      	mov	w1, #0x1d               // =29
    1410:      	mov	x2, x24
    1414:      	str	x9, [sp, #0xc8]
    1418:      	ldr	x9, [x8, #0x10]
    141c:      	ldur	x8, [x8, #0x15]
    1420:      	add	x20, sp, #0xc8
    1424:      	stp	x10, x9, [x11, #0x8]
    1428:      	stur	x8, [x11, #0x15]
    142c:      	mov	w8, #0x1d               // =29
    1430:      	mov	w9, #0x6                // =6
    1434:      	add	x10, sp, #0xc8
    1438:      	ldrb	w3, [sp, #0x88]
    143c:      	blr	x9
    1440:      	ldrb	w9, [sp, #0x88]
    1444:      	add	w8, w9, #0x1
    1448:      	and	w8, w8, #0xff
    144c:      	cmp	w8, #0x2
    1450:      	mov	w8, w9
    1454:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
    1458:      	b	0xa38 <perf_unwind_hotspot+0xa38>
    145c:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1460:      	add	x8, x8, #0x0
    1464:      	add	x13, sp, #0xc8
    1468:      	strb	wzr, [sp, #0xf8]
    146c:      	ldp	x9, x10, [x8, #0x10]
    1470:      	add	x0, sp, #0xc8
    1474:      	ldp	x11, x12, [x8, #0x20]
    1478:      	mov	w1, #0x31               // =49
    147c:      	mov	x2, x24
    1480:      	str	x12, [x13, #0x28]
    1484:      	stp	x10, x11, [x13, #0x18]
    1488:      	ldp	x10, x8, [x8]
    148c:      	str	x10, [sp, #0xc8]
    1490:      	add	x10, sp, #0xc8
    1494:      	stp	x8, x9, [x13, #0x8]
    1498:      	mov	w8, #0x31               // =49
    149c:      	mov	w9, #0x6                // =6
    14a0:      	blr	x9
    14a4:      	mov	x19, xzr
    14a8:      	tbz	x24, #0x3e, 0xcc4 <perf_unwind_hotspot+0xcc4>
    14ac:      	mov	w8, #0x10               // =16
    14b0:      	mov	x29, x25
    14b4:      	str	w8, [sp, #0x78]
    14b8:      	add	x29, x29, w8, uxtw
    14bc:      	mov	w8, #0x10               // =16
    14c0:      	mov	w9, #0x70               // =112
    14c4:      	add	x10, sp, #0x88
    14c8:      	add	x0, sp, #0x88
    14cc:      	mov	w1, #0x10               // =16
    14d0:      	sub	x2, x29, #0x10
    14d4:      	blr	x9
    14d8:      	ldr	w8, [sp, #0x78]
    14dc:      	ldr	x20, [sp, #0x90]
    14e0:      	cmp	w8, #0x10
    14e4:      	b.lo	0x14fc <perf_unwind_hotspot+0x14fc>
    14e8:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    14ec:      	ldr	x8, [x8]
    14f0:      	ldr	w8, [x8]
    14f4:      	cbnz	w8, 0x1700 <perf_unwind_hotspot+0x1700>
    14f8:      	ldr	x25, [sp, #0x88]
    14fc:      	ldr	w8, [x21, #0x2c0]
    1500:      	cmp	w8, #0x7f
    1504:      	b.lo	0x1554 <perf_unwind_hotspot+0x1554>
    1508:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    150c:      	ldr	x8, [x8]
    1510:      	ldr	w8, [x8]
    1514:      	cbnz	w8, 0x1668 <perf_unwind_hotspot+0x1668>
    1518:      	mov	w8, #0x2                // =2
    151c:      	adrp	x0, 0x1000 <perf_unwind_hotspot+0x1000>
    1520:      	add	x9, sp, #0x88
    1524:      	str	w8, [sp, #0x88]
    1528:      	mov	w8, #0x1                // =1
    152c:      	add	x1, sp, #0x88
    1530:      	ldr	x0, [x0]
    1534:      	blr	x8
    1538:      	cbz	x0, 0x1608 <perf_unwind_hotspot+0x1608>
    153c:      	ldr	x8, [x0]
    1540:      	adrp	x24, 0x1000 <perf_unwind_hotspot+0x1000>
    1544:      	add	x8, x8, #0x1
    1548:      	str	x8, [x0]
    154c:      	ldr	x24, [x24]
    1550:      	b	0x1618 <perf_unwind_hotspot+0x1618>
    1554:      	ldr	x12, [sp, #0x28]
    1558:      	and	x10, x19, #0x3000000000000000
    155c:      	ldr	x11, [sp, #0x38]
    1560:      	mov	w12, w12
    1564:      	ldrb	w9, [x21, #0xf20]
    1568:      	orr	x11, x12, x11, lsl #32
    156c:      	orr	x10, x11, x10
    1570:      	add	w11, w8, #0x1
    1574:      	str	w11, [x21, #0x2c0]
    1578:      	mov	w11, #0x18              // =24
    157c:      	umaddl	x8, w8, w11, x21
    1580:      	ldr	x11, [sp, #0x30]
    1584:      	str	x10, [x8, #0x2d8]
    1588:      	mov	w10, #0x5               // =5
    158c:      	strb	w9, [x8, #0x2e1]
    1590:      	strh	wzr, [x8, #0x2e6]
    1594:      	strb	w10, [x8, #0x2e0]
    1598:      	add	x10, x8, #0x2d0
    159c:      	str	x11, [x8, #0x2d0]
    15a0:      	stur	wzr, [x10, #0x12]
    15a4:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    15a8:      	ldr	x8, [x8]
    15ac:      	ldr	w8, [x8]
    15b0:      	cbnz	w8, 0x16ac <perf_unwind_hotspot+0x16ac>
    15b4:      	mov	w8, #0x101              // =257
    15b8:      	str	x20, [x21, #0xed0]
    15bc:      	str	x29, [x21, #0xed8]
    15c0:      	adrp	x0, 0x1000 <perf_unwind_hotspot+0x1000>
    15c4:      	add	x9, sp, #0x88
    15c8:      	add	x1, sp, #0x88
    15cc:      	strh	w8, [x21, #0xf20]
    15d0:      	mov	w8, #0x2a               // =42
    15d4:      	str	x25, [x21, #0xee0]
    15d8:      	str	w8, [sp, #0x88]
    15dc:      	mov	w8, #0x1                // =1
    15e0:      	ldr	x0, [x0]
    15e4:      	blr	x8
    15e8:      	cbz	x0, 0x1620 <perf_unwind_hotspot+0x1620>
    15ec:      	ldr	x8, [x0]
    15f0:      	add	x8, x8, #0x1
    15f4:      	str	x8, [x0]
    15f8:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    15fc:      	ldr	x8, [x8]
    1600:      	ldr	w8, [x8]
    1604:      	b	0x1630 <perf_unwind_hotspot+0x1630>
    1608:      	adrp	x24, 0x1000 <perf_unwind_hotspot+0x1000>
    160c:      	ldr	x24, [x24]
    1610:      	ldr	w8, [x24]
    1614:      	cbnz	w8, 0x1c38 <perf_unwind_hotspot+0x1c38>
    1618:      	mov	w8, #0x2                // =2
    161c:      	b	0x3c8 <perf_unwind_hotspot+0x3c8>
    1620:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1624:      	ldr	x8, [x8]
    1628:      	ldr	w8, [x8]
    162c:      	cbnz	w8, 0x1c84 <perf_unwind_hotspot+0x1c84>
    1630:      	ldr	x29, [x21, #0xed0]
    1634:      	cbz	x29, 0x5eac <perf_unwind_hotspot+0x5eac>
    1638:      	cbnz	w8, 0x173c <perf_unwind_hotspot+0x173c>
    163c:      	lsr	x8, x29, #56
    1640:      	cbz	x8, 0x1790 <perf_unwind_hotspot+0x1790>
    1644:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1648:      	ldr	x8, [x8]
    164c:      	ldr	w8, [x8]
    1650:      	cbnz	w8, 0x1cd0 <perf_unwind_hotspot+0x1cd0>
    1654:      	mov	w8, #0xb                // =11
    1658:      	mov	w25, wzr
    165c:      	str	w8, [x21, #0xf18]
    1660:      	mov	w8, #0xfab              // =4011
    1664:      	b	0x5ec0 <perf_unwind_hotspot+0x5ec0>
    1668:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    166c:      	add	x8, x8, #0x0
    1670:      	add	x13, sp, #0xc8
    1674:      	ldp	x9, x10, [x8, #0x10]
    1678:      	ldp	x12, x11, [x8]
    167c:      	add	x0, sp, #0xc8
    1680:      	mov	w1, #0x25               // =37
    1684:      	ldur	x8, [x8, #0x1d]
    1688:      	str	x10, [x13, #0x18]
    168c:      	stp	x11, x9, [x13, #0x8]
    1690:      	mov	w9, #0x6                // =6
    1694:      	stur	x8, [x13, #0x1d]
    1698:      	str	x12, [sp, #0xc8]
    169c:      	mov	w8, #0x25               // =37
    16a0:      	add	x10, sp, #0xc8
    16a4:      	blr	x9
    16a8:      	b	0x1518 <perf_unwind_hotspot+0x1518>
    16ac:      	mov	w8, #0x786c             // =30828
    16b0:      	add	x11, sp, #0xc8
    16b4:      	add	x0, sp, #0xc8
    16b8:      	mov	w1, #0x24               // =36
    16bc:      	mov	x2, x20
    16c0:      	mov	x3, x29
    16c4:      	mov	x4, x25
    16c8:      	movk	w8, #0xa, lsl #16
    16cc:      	str	w8, [sp, #0xe8]
    16d0:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    16d4:      	add	x8, x8, #0x0
    16d8:      	ldp	x9, x10, [x8]
    16dc:      	str	x9, [sp, #0xc8]
    16e0:      	ldp	x9, x8, [x8, #0x10]
    16e4:      	stp	x10, x9, [x11, #0x8]
    16e8:      	str	x8, [x11, #0x18]
    16ec:      	mov	w8, #0x24               // =36
    16f0:      	mov	w9, #0x6                // =6
    16f4:      	add	x10, sp, #0xc8
    16f8:      	blr	x9
    16fc:      	b	0x15b4 <perf_unwind_hotspot+0x15b4>
    1700:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1704:      	add	x8, x8, #0x0
    1708:      	add	x0, sp, #0xc8
    170c:      	ldp	x9, x10, [x8]
    1710:      	ldur	x8, [x8, #0xd]
    1714:      	mov	w1, #0x15               // =21
    1718:      	str	x9, [sp, #0xc8]
    171c:      	add	x9, sp, #0xc8
    1720:      	str	x10, [x9, #0x8]
    1724:      	stur	x8, [x9, #0xd]
    1728:      	mov	w8, #0x15               // =21
    172c:      	mov	w9, #0x6                // =6
    1730:      	add	x10, sp, #0xc8
    1734:      	blr	x9
    1738:      	b	0x14f8 <perf_unwind_hotspot+0x14f8>
    173c:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1740:      	add	x8, x8, #0x0
    1744:      	add	x13, sp, #0xc8
    1748:      	strb	wzr, [sp, #0xf8]
    174c:      	ldp	x9, x10, [x8, #0x10]
    1750:      	add	x0, sp, #0xc8
    1754:      	ldp	x11, x12, [x8, #0x20]
    1758:      	mov	w1, #0x31               // =49
    175c:      	str	x12, [x13, #0x28]
    1760:      	stp	x10, x11, [x13, #0x18]
    1764:      	ldp	x10, x8, [x8]
    1768:      	str	x10, [sp, #0xc8]
    176c:      	stp	x8, x9, [x13, #0x8]
    1770:      	mov	w8, #0x31               // =49
    1774:      	mov	w9, #0x6                // =6
    1778:      	add	x10, sp, #0xc8
    177c:      	ldr	w2, [x21, #0x2c0]
    1780:      	blr	x9
    1784:      	ldr	x29, [x21, #0xed0]
    1788:      	lsr	x8, x29, #56
    178c:      	cbnz	x8, 0x1644 <perf_unwind_hotspot+0x1644>
    1790:      	cmp	x29, #0xfff
    1794:      	b.hi	0x17bc <perf_unwind_hotspot+0x17bc>
    1798:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    179c:      	ldr	x8, [x8]
    17a0:      	ldr	w8, [x8]
    17a4:      	cbnz	w8, 0x1d60 <perf_unwind_hotspot+0x1d60>
    17a8:      	mov	w8, #0x31               // =49
    17ac:      	mov	w25, wzr
    17b0:      	str	w8, [x21, #0xf18]
    17b4:      	mov	w8, #0xfae              // =4014
    17b8:      	b	0x5ec0 <perf_unwind_hotspot+0x5ec0>
    17bc:      	ldr	w8, [x21]
    17c0:      	mov	w9, #0x60               // =96
    17c4:      	adrp	x20, 0x1000 <perf_unwind_hotspot+0x1000>
    17c8:      	add	x1, sp, #0x50
    17cc:      	rev	w8, w8
    17d0:      	stp	w9, w8, [sp, #0x50]
    17d4:      	rev	x8, x29
    17d8:      	add	x9, sp, #0x50
    17dc:      	str	x8, [sp, #0x58]
    17e0:      	mov	w8, #0x1                // =1
    17e4:      	ldr	x20, [x20]
    17e8:      	mov	x0, x20
    17ec:      	blr	x8
    17f0:      	cbz	x0, 0x5ee0 <perf_unwind_hotspot+0x5ee0>
    17f4:      	ldr	x8, [x0, #0x8]
    17f8:      	and	x9, x8, #0xffffffffffffff
    17fc:      	lsr	x25, x8, #56
    1800:      	str	x9, [x21, #0xf10]
    1804:      	ldr	x8, [x0]
    1808:      	str	x8, [x21, #0xf00]
    180c:      	sub	x8, x29, x9
    1810:      	str	x8, [x21, #0xf08]
    1814:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1818:      	ldr	x8, [x8]
    181c:      	ldr	w8, [x8]
    1820:      	cbnz	w8, 0x1e04 <perf_unwind_hotspot+0x1e04>
    1824:      	cmp	w25, #0x1
    1828:      	b.ne	0x18c8 <perf_unwind_hotspot+0x18c8>
    182c:      	ldr	x8, [x21, #0xf00]
    1830:      	adrp	x0, 0x1000 <perf_unwind_hotspot+0x1000>
    1834:      	ldr	x19, [x21, #0xf08]
    1838:      	mov	w9, #0x1                // =1
    183c:      	add	x1, sp, #0x50
    1840:      	mov	w22, #0x1               // =1
    1844:      	str	x8, [sp, #0x50]
    1848:      	add	x8, sp, #0x50
    184c:      	ldr	x0, [x0]
    1850:      	blr	x9
    1854:      	cbz	x0, 0x18c4 <perf_unwind_hotspot+0x18c4>
    1858:      	ldr	x8, [x0]
    185c:      	mov	x25, x0
    1860:      	cmp	x8, x19
    1864:      	b.hi	0x1874 <perf_unwind_hotspot+0x1874>
    1868:      	ldr	x8, [x25, #0x8]
    186c:      	cmp	x8, x19
    1870:      	b.hs	0x188c <perf_unwind_hotspot+0x188c>
    1874:      	ldr	x8, [x25, #0x10]
    1878:      	cmp	x8, x19
    187c:      	b.hi	0x18bc <perf_unwind_hotspot+0x18bc>
    1880:      	ldr	x8, [x25, #0x18]
    1884:      	cmp	x8, x19
    1888:      	b.lo	0x18bc <perf_unwind_hotspot+0x18bc>
    188c:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1890:      	ldr	x8, [x8]
    1894:      	ldr	w8, [x8]
    1898:      	cbnz	w8, 0x24e4 <perf_unwind_hotspot+0x24e4>
    189c:      	ldrh	w8, [x25, #0x20]
    18a0:      	ldr	w9, [x21, #0x1370]
    18a4:      	lsr	w8, w9, w8
    18a8:      	tbz	w8, #0x0, 0x2534 <perf_unwind_hotspot+0x2534>
    18ac:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    18b0:      	ldr	x8, [x8]
    18b4:      	ldr	w8, [x8]
    18b8:      	cbnz	w8, 0x25f4 <perf_unwind_hotspot+0x25f4>
    18bc:      	mov	w25, #0x1               // =1
    18c0:      	b	0x18c8 <perf_unwind_hotspot+0x18c8>
    18c4:      	mov	w25, w22
    18c8:      	cmp	w25, #0x2
    18cc:      	b.ne	0x6074 <perf_unwind_hotspot+0x6074>
    18d0:      	mov	w8, #0x29               // =41
    18d4:      	adrp	x0, 0x1000 <perf_unwind_hotspot+0x1000>
    18d8:      	add	x9, sp, #0x50
    18dc:      	str	w8, [sp, #0x50]
    18e0:      	mov	w8, #0x1                // =1
    18e4:      	add	x1, sp, #0x50
    18e8:      	ldr	x0, [x0]
    18ec:      	blr	x8
    18f0:      	cbz	x0, 0x1978 <perf_unwind_hotspot+0x1978>
    18f4:      	ldr	x8, [x0]
    18f8:      	add	x8, x8, #0x1
    18fc:      	str	x8, [x0]
    1900:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1904:      	ldr	x8, [x8]
    1908:      	ldr	x22, [x21, #0xed0]
    190c:      	ldr	x29, [x21, #0xed8]
    1910:      	ldr	x9, [x21, #0xee0]
    1914:      	ldr	w8, [x8]
    1918:      	str	x9, [sp, #0x38]
    191c:      	cbz	w8, 0x1998 <perf_unwind_hotspot+0x1998>
    1920:      	mov	w8, #0x786c             // =30828
    1924:      	add	x13, sp, #0xc8
    1928:      	add	x0, sp, #0xc8
    192c:      	mov	w1, #0x2c               // =44
    1930:      	movk	w8, #0xa, lsl #16
    1934:      	str	w8, [sp, #0xf0]
    1938:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    193c:      	add	x8, x8, #0x0
    1940:      	ldp	x9, x10, [x8, #0x10]
    1944:      	ldp	x12, x11, [x8]
    1948:      	ldr	x8, [x8, #0x20]
    194c:      	str	x12, [sp, #0xc8]
    1950:      	stp	x11, x9, [x13, #0x8]
    1954:      	stp	x10, x8, [x13, #0x18]
    1958:      	mov	w8, #0x2c               // =44
    195c:      	mov	w9, #0x6                // =6
    1960:      	add	x10, sp, #0xc8
    1964:      	ldr	x2, [x21, #0xed0]
    1968:      	ldr	x3, [x21, #0xf10]
    196c:      	ldr	x4, [x21, #0xf08]
    1970:      	blr	x9
    1974:      	b	0x1998 <perf_unwind_hotspot+0x1998>
    1978:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    197c:      	ldr	x8, [x8]
    1980:      	ldr	w8, [x8]
    1984:      	cbnz	w8, 0x20b0 <perf_unwind_hotspot+0x20b0>
    1988:      	ldr	x8, [x21, #0xee0]
    198c:      	ldr	x22, [x21, #0xed0]
    1990:      	ldr	x29, [x21, #0xed8]
    1994:      	str	x8, [sp, #0x38]
    1998:      	ldr	x8, [x21, #0xf08]
    199c:      	ldrb	w9, [x23, #0x20]
    19a0:      	add	x10, sp, #0x88
    19a4:      	add	x0, sp, #0x88
    19a8:      	mov	w1, #0x1                // =1
    19ac:      	lsr	x25, x8, x9
    19b0:      	ldr	x8, [x21, #0xf00]
    19b4:      	mov	w9, #0x70               // =112
    19b8:      	and	x19, x8, #0xffffffffffffff
    19bc:      	mov	w8, #0x1                // =1
    19c0:      	add	x2, x25, x19
    19c4:      	blr	x9
    19c8:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    19cc:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    19d0:      	ldr	x8, [x8]
    19d4:      	ldr	w8, [x8]
    19d8:      	cbnz	w8, 0x20fc <perf_unwind_hotspot+0x20fc>
    19dc:      	ldrb	w8, [sp, #0x88]
    19e0:      	add	w9, w8, #0x1
    19e4:      	and	w9, w9, #0xff
    19e8:      	cmp	w9, #0x2
    19ec:      	b.hs	0x2154 <perf_unwind_hotspot+0x2154>
    19f0:      	cbnz	w8, 0x178 <perf_unwind_hotspot+0x178>
    19f4:      	ldr	x8, [x21, #0xf10]
    19f8:      	ldrb	w9, [x23, #0x20]
    19fc:      	lsl	x9, x25, x9
    1a00:      	ldrb	w10, [x23, #0x1b]
    1a04:      	add	x8, x8, x10
    1a08:      	add	x24, x9, x8
    1a0c:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1a10:      	ldr	x8, [x8]
    1a14:      	ldr	w8, [x8]
    1a18:      	cbnz	w8, 0x269c <perf_unwind_hotspot+0x269c>
    1a1c:      	str	x24, [sp, #0x50]
    1a20:      	cbz	x24, 0x17c <perf_unwind_hotspot+0x17c>
    1a24:      	mov	w8, #0x200              // =512
    1a28:      	mov	w9, #0x70               // =112
    1a2c:      	ldr	x0, [sp, #0x8]
    1a30:      	mov	w1, #0x200              // =512
    1a34:      	ldr	x2, [sp, #0x50]
    1a38:      	blr	x9
    1a3c:      	adrp	x24, 0x1000 <perf_unwind_hotspot+0x1000>
    1a40:      	ldr	x24, [x24]
    1a44:      	cbnz	x0, 0x258 <perf_unwind_hotspot+0x258>
    1a48:      	ldrh	w8, [x23, #0x10]
    1a4c:      	cmp	x8, #0x1f8
    1a50:      	b.hi	0x3c4 <perf_unwind_hotspot+0x3c4>
    1a54:      	ldrh	w9, [x23, #0x12]
    1a58:      	cmp	x9, #0x1fc
    1a5c:      	b.hi	0x3c4 <perf_unwind_hotspot+0x3c4>
    1a60:      	ldrh	w10, [x23, #0x14]
    1a64:      	cmp	x10, #0x1f8
    1a68:      	b.hi	0x3c4 <perf_unwind_hotspot+0x3c4>
    1a6c:      	ldrb	w11, [x23, #0x17]
    1a70:      	ldr	x12, [sp, #0x8]
    1a74:      	mov	w1, #0x4                // =4
    1a78:      	ldr	x0, [sp, #0x40]
    1a7c:      	ldr	x11, [x12, x11]
    1a80:      	str	x11, [sp, #0x58]
    1a84:      	ldrb	w11, [x23, #0x18]
    1a88:      	ldr	x11, [x12, x11]
    1a8c:      	str	x11, [sp, #0x60]
    1a90:      	ldrb	w11, [x23, #0x1a]
    1a94:      	ldr	w11, [x12, x11]
    1a98:      	lsl	w11, w11, #3
    1a9c:      	str	w11, [sp, #0x78]
    1aa0:      	ldrb	w11, [x23, #0x19]
    1aa4:      	ldrh	w11, [x12, x11]
    1aa8:      	strh	w11, [sp, #0x80]
    1aac:      	ldr	w9, [x12, x9]
    1ab0:      	str	w9, [sp, #0x7c]
    1ab4:      	ldr	w9, [x12, x10]
    1ab8:      	str	w9, [sp, #0x74]
    1abc:      	mov	w9, #0x70               // =112
    1ac0:      	ldr	x8, [x12, x8]
    1ac4:      	str	x8, [sp, #0x68]
    1ac8:      	ldrb	w8, [x23, #0x16]
    1acc:      	ldr	x2, [x12, x8]
    1ad0:      	mov	w8, #0x4                // =4
    1ad4:      	blr	x9
    1ad8:      	adrp	x24, 0x1000 <perf_unwind_hotspot+0x1000>
    1adc:      	ldr	x24, [x24]
    1ae0:      	cbnz	x0, 0x258 <perf_unwind_hotspot+0x258>
    1ae4:      	ldrb	w8, [x23, #0x21]
    1ae8:      	cbz	w8, 0x1b04 <perf_unwind_hotspot+0x1b04>
    1aec:      	ldr	x8, [sp, #0x50]
    1af0:      	ldr	w9, [sp, #0x58]
    1af4:      	add	x9, x9, x8
    1af8:      	ldr	w10, [sp, #0x60]
    1afc:      	add	x8, x10, x8
    1b00:      	stp	x9, x8, [sp, #0x58]
    1b04:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1b08:      	ldr	x8, [x8]
    1b0c:      	ldr	w8, [x8]
    1b10:      	cbnz	w8, 0x2980 <perf_unwind_hotspot+0x2980>
    1b14:      	ldp	x25, x8, [sp, #0x50]
    1b18:      	sub	w9, w22, w8
    1b1c:      	ldr	w19, [sp, #0x70]
    1b20:      	str	x9, [sp, #0x30]
    1b24:      	mov	w9, #0x616d             // =24941
    1b28:      	movk	w9, #0x6974, lsl #16
    1b2c:      	cmp	w19, w9
    1b30:      	b.gt	0x1f70 <perf_unwind_hotspot+0x1f70>
    1b34:      	mov	w8, #0x7476             // =29814
    1b38:      	movk	w8, #0x6261, lsl #16
    1b3c:      	cmp	w19, w8
    1b40:      	b.eq	0x2024 <perf_unwind_hotspot+0x2024>
    1b44:      	mov	w8, #0x6e49             // =28233
    1b48:      	movk	w8, #0x6574, lsl #16
    1b4c:      	cmp	w19, w8
    1b50:      	b.ne	0x204c <perf_unwind_hotspot+0x204c>
    1b54:      	ldr	x8, [sp, #0x38]
    1b58:      	cmp	x8, x29
    1b5c:      	b.lo	0x52c0 <perf_unwind_hotspot+0x52c0>
    1b60:      	ldr	x9, [sp, #0x38]
    1b64:      	add	x8, x29, #0x1, lsl #12  // =0x1000
    1b68:      	cmp	x9, x8
    1b6c:      	b.hs	0x52c0 <perf_unwind_hotspot+0x52c0>
    1b70:      	ldr	x8, [sp, #0x38]
    1b74:      	mov	w9, #0x70               // =112
    1b78:      	add	x10, sp, #0xc8
    1b7c:      	add	x0, sp, #0xc8
    1b80:      	mov	w1, #0x60               // =96
    1b84:      	sub	x2, x8, #0x50
    1b88:      	mov	w8, #0x60               // =96
    1b8c:      	blr	x9
    1b90:      	cbnz	x0, 0x51c <perf_unwind_hotspot+0x51c>
    1b94:      	ldr	w9, [x21, #0x2c0]
    1b98:      	ldr	x8, [sp, #0x20]
    1b9c:      	cbz	w9, 0x1bb0 <perf_unwind_hotspot+0x1bb0>
    1ba0:      	ldrb	w8, [x23, #0x1f]
    1ba4:      	cmp	w8, #0x0
    1ba8:      	ldp	x9, x8, [sp, #0x10]
    1bac:      	csel	x8, x9, x8, eq
    1bb0:      	ldr	x19, [x8]
    1bb4:      	add	x8, sp, #0xc8
    1bb8:      	mov	w10, #0x70              // =112
    1bbc:      	add	x11, sp, #0xc0
    1bc0:      	ldp	x29, x9, [x8, #0x48]
    1bc4:      	ldr	x25, [x8, #0x38]
    1bc8:      	add	x0, sp, #0xc0
    1bcc:      	mov	w1, #0x8                // =8
    1bd0:      	ldr	x24, [x8, #0x58]
    1bd4:      	ldrb	w8, [x23, #0x1c]
    1bd8:      	add	x8, x25, x8
    1bdc:      	str	x9, [sp, #0x38]
    1be0:      	mov	w9, #0x8                // =8
    1be4:      	ldrb	w8, [x23, #0x1c]
    1be8:      	add	x2, x25, x8
    1bec:      	blr	x10
    1bf0:      	cbnz	x0, 0xf20 <perf_unwind_hotspot+0xf20>
    1bf4:      	ldr	x8, [sp, #0xc0]
    1bf8:      	ldrb	w9, [x23, #0x1d]
    1bfc:      	add	x9, x8, x9
    1c00:      	cmp	x19, x9
    1c04:      	csel	x9, xzr, x9, lo
    1c08:      	sub	x19, x19, x9
    1c0c:      	adrp	x9, 0x1000 <perf_unwind_hotspot+0x1000>
    1c10:      	ldr	x9, [x9]
    1c14:      	ldr	w9, [x9]
    1c18:      	cbnz	w9, 0x31bc <perf_unwind_hotspot+0x31bc>
    1c1c:      	mov	w9, #0xffff             // =65535
    1c20:      	mov	x22, #0x2000000000000000 // =2305843009213693952
    1c24:      	cmp	x19, x9
    1c28:      	csel	x9, x19, x9, lo
    1c2c:      	lsr	x19, x8, #3
    1c30:      	str	x9, [sp, #0x30]
    1c34:      	b	0x2cd0 <perf_unwind_hotspot+0x2cd0>
    1c38:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1c3c:      	add	x8, x8, #0x0
    1c40:      	add	x12, sp, #0xc8
    1c44:      	ldp	x9, x10, [x8, #0x10]
    1c48:      	ldr	x11, [x8, #0x20]
    1c4c:      	add	x0, sp, #0xc8
    1c50:      	mov	w1, #0x2e               // =46
    1c54:      	stp	x10, x11, [x12, #0x18]
    1c58:      	ldur	x10, [x8, #0x26]
    1c5c:      	stur	x10, [x12, #0x26]
    1c60:      	ldp	x10, x8, [x8]
    1c64:      	str	x10, [sp, #0xc8]
    1c68:      	stp	x8, x9, [x12, #0x8]
    1c6c:      	mov	w8, #0x2e               // =46
    1c70:      	mov	w9, #0x6                // =6
    1c74:      	add	x10, sp, #0xc8
    1c78:      	ldr	w2, [sp, #0x88]
    1c7c:      	blr	x9
    1c80:      	b	0x1618 <perf_unwind_hotspot+0x1618>
    1c84:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1c88:      	add	x8, x8, #0x0
    1c8c:      	add	x12, sp, #0xc8
    1c90:      	ldp	x9, x10, [x8, #0x10]
    1c94:      	ldr	x11, [x8, #0x20]
    1c98:      	add	x0, sp, #0xc8
    1c9c:      	mov	w1, #0x2e               // =46
    1ca0:      	stp	x10, x11, [x12, #0x18]
    1ca4:      	ldur	x10, [x8, #0x26]
    1ca8:      	stur	x10, [x12, #0x26]
    1cac:      	ldp	x10, x8, [x8]
    1cb0:      	str	x10, [sp, #0xc8]
    1cb4:      	stp	x8, x9, [x12, #0x8]
    1cb8:      	mov	w8, #0x2e               // =46
    1cbc:      	mov	w9, #0x6                // =6
    1cc0:      	add	x10, sp, #0xc8
    1cc4:      	ldr	w2, [sp, #0x88]
    1cc8:      	blr	x9
    1ccc:      	b	0x15f8 <perf_unwind_hotspot+0x15f8>
    1cd0:      	mov	w8, #0xa                // =10
    1cd4:      	add	x11, sp, #0xc8
    1cd8:      	add	x0, sp, #0xc8
    1cdc:      	strh	w8, [sp, #0xe8]
    1ce0:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1ce4:      	add	x8, x8, #0x0
    1ce8:      	mov	w1, #0x22               // =34
    1cec:      	ldp	x9, x10, [x8]
    1cf0:      	mov	x2, x29
    1cf4:      	str	x9, [sp, #0xc8]
    1cf8:      	ldp	x9, x8, [x8, #0x10]
    1cfc:      	stp	x10, x9, [x11, #0x8]
    1d00:      	str	x8, [x11, #0x18]
    1d04:      	mov	w8, #0x22               // =34
    1d08:      	mov	w9, #0x6                // =6
    1d0c:      	add	x10, sp, #0xc8
    1d10:      	blr	x9
    1d14:      	b	0x1654 <perf_unwind_hotspot+0x1654>
    1d18:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1d1c:      	add	x8, x8, #0x0
    1d20:      	add	x11, sp, #0xc8
    1d24:      	ldp	x9, x10, [x8, #0x18]
    1d28:      	add	x0, sp, #0xc8
    1d2c:      	mov	w1, #0x2f               // =47
    1d30:      	stp	x9, x10, [x11, #0x18]
    1d34:      	ldur	x10, [x8, #0x27]
    1d38:      	stur	x10, [x11, #0x27]
    1d3c:      	ldr	x10, [x8]
    1d40:      	ldp	x8, x9, [x8, #0x8]
    1d44:      	str	x10, [sp, #0xc8]
    1d48:      	stp	x8, x9, [x11, #0x8]
    1d4c:      	mov	w8, #0x2f               // =47
    1d50:      	mov	w9, #0x6                // =6
    1d54:      	add	x10, sp, #0xc8
    1d58:      	blr	x9
    1d5c:      	b	0x790 <perf_unwind_hotspot+0x790>
    1d60:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1d64:      	add	x8, x8, #0x0
    1d68:      	add	x11, sp, #0xc8
    1d6c:      	ldp	x9, x10, [x8]
    1d70:      	add	x0, sp, #0xc8
    1d74:      	mov	w1, #0x1e               // =30
    1d78:      	mov	x2, x29
    1d7c:      	str	x9, [sp, #0xc8]
    1d80:      	ldr	x9, [x8, #0x10]
    1d84:      	ldur	x8, [x8, #0x16]
    1d88:      	stp	x10, x9, [x11, #0x8]
    1d8c:      	mov	w9, #0x6                // =6
    1d90:      	stur	x8, [x11, #0x16]
    1d94:      	mov	w8, #0x1e               // =30
    1d98:      	add	x10, sp, #0xc8
    1d9c:      	blr	x9
    1da0:      	b	0x17a8 <perf_unwind_hotspot+0x17a8>
    1da4:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1da8:      	add	x8, x8, #0x0
    1dac:      	add	x13, sp, #0xc8
    1db0:      	ldp	x9, x10, [x8, #0x20]
    1db4:      	ldp	x11, x12, [x8, #0x30]
    1db8:      	add	x0, sp, #0xc8
    1dbc:      	mov	w1, #0x40               // =64
    1dc0:      	add	x20, sp, #0xc8
    1dc4:      	str	x12, [x13, #0x38]
    1dc8:      	stp	x10, x11, [x13, #0x28]
    1dcc:      	ldp	x10, x11, [x8]
    1dd0:      	str	x10, [sp, #0xc8]
    1dd4:      	ldp	x10, x8, [x8, #0x10]
    1dd8:      	stp	x11, x10, [x13, #0x8]
    1ddc:      	stp	x8, x9, [x13, #0x18]
    1de0:      	mov	w8, #0x40               // =64
    1de4:      	mov	w9, #0x6                // =6
    1de8:      	add	x10, sp, #0xc8
    1dec:      	ldr	x2, [sp, #0x88]
    1df0:      	ldr	w3, [sp, #0x74]
    1df4:      	blr	x9
    1df8:      	ldr	x22, [sp, #0x88]
    1dfc:      	ldr	x8, [sp, #0x58]
    1e00:      	b	0xcfc <perf_unwind_hotspot+0xcfc>
    1e04:      	mov	w8, #0xa                // =10
    1e08:      	add	x13, sp, #0xc8
    1e0c:      	add	x0, sp, #0xc8
    1e10:      	strh	w8, [sp, #0xf8]
    1e14:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1e18:      	add	x8, x8, #0x0
    1e1c:      	mov	w1, #0x32               // =50
    1e20:      	ldp	x9, x10, [x8, #0x10]
    1e24:      	ldp	x11, x12, [x8, #0x20]
    1e28:      	mov	x2, x29
    1e2c:      	mov	w4, w25
    1e30:      	str	x12, [x13, #0x28]
    1e34:      	stp	x10, x11, [x13, #0x18]
    1e38:      	ldp	x10, x8, [x8]
    1e3c:      	str	x10, [sp, #0xc8]
    1e40:      	add	x10, sp, #0xc8
    1e44:      	stp	x8, x9, [x13, #0x8]
    1e48:      	mov	w8, #0x32               // =50
    1e4c:      	mov	w9, #0x6                // =6
    1e50:      	ldr	x3, [x21, #0xf00]
    1e54:      	blr	x9
    1e58:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1e5c:      	ldr	x8, [x8]
    1e60:      	ldr	w8, [x8]
    1e64:      	cbz	w8, 0x1824 <perf_unwind_hotspot+0x1824>
    1e68:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1e6c:      	add	x8, x8, #0x0
    1e70:      	add	x12, sp, #0xc8
    1e74:      	ldp	x9, x10, [x8, #0x10]
    1e78:      	ldr	x11, [x8, #0x20]
    1e7c:      	add	x0, sp, #0xc8
    1e80:      	mov	w1, #0x2f               // =47
    1e84:      	stp	x10, x11, [x12, #0x18]
    1e88:      	ldur	x10, [x8, #0x27]
    1e8c:      	stur	x10, [x12, #0x27]
    1e90:      	ldp	x10, x8, [x8]
    1e94:      	str	x10, [sp, #0xc8]
    1e98:      	stp	x8, x9, [x12, #0x8]
    1e9c:      	mov	w8, #0x2f               // =47
    1ea0:      	mov	w9, #0x6                // =6
    1ea4:      	add	x10, sp, #0xc8
    1ea8:      	ldr	x2, [x21, #0xf10]
    1eac:      	ldr	x3, [x21, #0xf08]
    1eb0:      	blr	x9
    1eb4:      	b	0x1824 <perf_unwind_hotspot+0x1824>
    1eb8:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1ebc:      	add	x8, x8, #0x0
    1ec0:      	add	x11, sp, #0xc8
    1ec4:      	ldp	x9, x10, [x8]
    1ec8:      	add	x0, sp, #0xc8
    1ecc:      	mov	w1, #0x1d               // =29
    1ed0:      	mov	x2, x24
    1ed4:      	str	x9, [sp, #0xc8]
    1ed8:      	ldr	x9, [x8, #0x10]
    1edc:      	ldur	x8, [x8, #0x15]
    1ee0:      	add	x20, sp, #0xc8
    1ee4:      	stp	x10, x9, [x11, #0x8]
    1ee8:      	stur	x8, [x11, #0x15]
    1eec:      	mov	w8, #0x1d               // =29
    1ef0:      	mov	w9, #0x6                // =6
    1ef4:      	add	x10, sp, #0xc8
    1ef8:      	ldrb	w3, [sp, #0x88]
    1efc:      	blr	x9
    1f00:      	ldrb	w9, [sp, #0x88]
    1f04:      	add	w8, w9, #0x1
    1f08:      	and	w8, w8, #0xff
    1f0c:      	cmp	w8, #0x2
    1f10:      	mov	w8, w9
    1f14:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
    1f18:      	b	0xa84 <perf_unwind_hotspot+0xa84>
    1f1c:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1f20:      	add	x8, x8, #0x0
    1f24:      	add	x0, sp, #0x88
    1f28:      	ldp	x9, x10, [x8, #0x20]
    1f2c:      	mov	w1, #0x35               // =53
    1f30:      	mov	x4, x19
    1f34:      	stp	x9, x10, [sp, #0xa8]
    1f38:      	ldur	x9, [x8, #0x2d]
    1f3c:      	stur	x9, [sp, #0xb5]
    1f40:      	ldp	x9, x10, [x8]
    1f44:      	stp	x9, x10, [sp, #0x88]
    1f48:      	ldp	x8, x9, [x8, #0x10]
    1f4c:      	add	x10, sp, #0x88
    1f50:      	stp	x8, x9, [sp, #0x98]
    1f54:      	mov	w8, #0x35               // =53
    1f58:      	mov	w9, #0x6                // =6
    1f5c:      	ldr	x3, [sp, #0xc0]
    1f60:      	ldr	x2, [sp, #0x30]
    1f64:      	blr	x9
    1f68:      	ldr	x8, [sp, #0xc0]
    1f6c:      	b	0x1094 <perf_unwind_hotspot+0x1094>
    1f70:      	mov	w9, #0x616e             // =24942
    1f74:      	movk	w9, #0x6974, lsl #16
    1f78:      	cmp	w19, w9
    1f7c:      	b.eq	0x1f90 <perf_unwind_hotspot+0x1f90>
    1f80:      	mov	w9, #0x6d6e             // =28014
    1f84:      	movk	w9, #0x7465, lsl #16
    1f88:      	cmp	w19, w9
    1f8c:      	b.ne	0x204c <perf_unwind_hotspot+0x204c>
    1f90:      	ldr	x9, [sp, #0x68]
    1f94:      	ldrb	w10, [x23, #0x21]
    1f98:      	add	x11, x25, w9, uxtw
    1f9c:      	ldr	w19, [sp, #0x7c]
    1fa0:      	cmp	w10, #0x0
    1fa4:      	csel	x9, x9, x11, eq
    1fa8:      	cmp	x22, x9
    1fac:      	b.ne	0x1ff0 <perf_unwind_hotspot+0x1ff0>
    1fb0:      	ldr	w8, [sp, #0x74]
    1fb4:      	mov	w9, #0x8                // =8
    1fb8:      	mov	w10, #0x70              // =112
    1fbc:      	add	x11, sp, #0x88
    1fc0:      	add	x0, sp, #0x88
    1fc4:      	mov	w1, #0x8                // =8
    1fc8:      	add	x8, x29, x8
    1fcc:      	ldr	w8, [sp, #0x74]
    1fd0:      	add	x2, x29, x8
    1fd4:      	blr	x10
    1fd8:      	cbz	x0, 0x2638 <perf_unwind_hotspot+0x2638>
    1fdc:      	adrp	x8, 0x1000 <perf_unwind_hotspot+0x1000>
    1fe0:      	ldr	x8, [x8]
    1fe4:      	ldr	w8, [x8]
    1fe8:      	cbnz	w8, 0x2b30 <perf_unwind_hotspot+0x2b30>
    1fec:      	ldr	x8, [sp, #0x58]
    1ff0:      	ldrh	w9, [sp, #0x80]
    1ff4:      	add	x8, x8, x9
    1ff8:      	cmp	x22, x8
    1ffc:      	b.hs	0x2074 <perf_unwind_hotspot+0x2074>
    2000:      	sub	x8, x8, #0x4
    2004:      	cmp	x22, x8
    2008:      	b.ne	0x25e4 <perf_unwind_hotspot+0x25e4>
    200c:      	ldr	w8, [sp, #0x78]
    2010:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    2014:      	add	x29, x29, x8
    2018:      	ldrb	w8, [x21, #0xf21]
    201c:      	cbnz	w8, 0x7bc <perf_unwind_hotspot+0x7bc>
    2020:      	b	0x2694 <perf_unwind_hotspot+0x2694>
    2024:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2028:      	mov	w19, #0x7476            // =29814
    202c:      	ldr	x8, [x8]
    2030:      	movk	w19, #0x6261, lsl #16
    2034:      	ldr	w8, [x8]
    2038:      	cbnz	w8, 0x2aec <perf_unwind_hotspot+0x2aec>
    203c:      	mov	x22, #0x1000000000000000 // =1152921504606846976
    2040:      	ldrb	w8, [x21, #0xf21]
    2044:      	cbnz	w8, 0x7bc <perf_unwind_hotspot+0x7bc>
    2048:      	b	0x2694 <perf_unwind_hotspot+0x2694>
    204c:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2050:      	ldr	x24, [x21, #0xf00]
    2054:      	ldr	x8, [x8]
    2058:      	ldr	w8, [x8]
    205c:      	tbnz	x24, #0x3f, 0x2674 <perf_unwind_hotspot+0x2674>
    2060:      	cbnz	w8, 0x2b74 <perf_unwind_hotspot+0x2b74>
    2064:      	ldr	w8, [sp, #0x78]
    2068:      	mov	x22, xzr
    206c:      	cbnz	w8, 0x2c84 <perf_unwind_hotspot+0x2c84>
    2070:      	b	0x2c78 <perf_unwind_hotspot+0x2c78>
    2074:      	ldr	x8, [sp, #0x38]
    2078:      	subs	x2, x8, x29
    207c:      	b.lo	0x2498 <perf_unwind_hotspot+0x2498>
    2080:      	ldr	w8, [sp, #0x78]
    2084:      	ldr	x9, [sp, #0x38]
    2088:      	add	x8, x29, x8
    208c:      	add	x8, x8, #0x30
    2090:      	cmp	x9, x8
    2094:      	b.hs	0x2498 <perf_unwind_hotspot+0x2498>
    2098:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    209c:      	ldr	x8, [x8]
    20a0:      	ldr	w8, [x8]
    20a4:      	cbnz	w8, 0x3004 <perf_unwind_hotspot+0x3004>
    20a8:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    20ac:      	b	0x2c78 <perf_unwind_hotspot+0x2c78>
    20b0:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    20b4:      	add	x8, x8, #0x0
    20b8:      	add	x12, sp, #0xc8
    20bc:      	ldp	x9, x10, [x8, #0x10]
    20c0:      	ldr	x11, [x8, #0x20]
    20c4:      	add	x0, sp, #0xc8
    20c8:      	mov	w1, #0x2e               // =46
    20cc:      	stp	x10, x11, [x12, #0x18]
    20d0:      	ldur	x10, [x8, #0x26]
    20d4:      	stur	x10, [x12, #0x26]
    20d8:      	ldp	x10, x8, [x8]
    20dc:      	str	x10, [sp, #0xc8]
    20e0:      	stp	x8, x9, [x12, #0x8]
    20e4:      	mov	w8, #0x2e               // =46
    20e8:      	mov	w9, #0x6                // =6
    20ec:      	add	x10, sp, #0xc8
    20f0:      	ldr	w2, [sp, #0x50]
    20f4:      	blr	x9
    20f8:      	b	0x1900 <perf_unwind_hotspot+0x1900>
    20fc:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2100:      	add	x8, x8, #0x0
    2104:      	add	x11, sp, #0xc8
    2108:      	ldp	x9, x10, [x8]
    210c:      	add	x0, sp, #0xc8
    2110:      	mov	w1, #0x1d               // =29
    2114:      	mov	x2, x25
    2118:      	str	x9, [sp, #0xc8]
    211c:      	ldr	x9, [x8, #0x10]
    2120:      	ldur	x8, [x8, #0x15]
    2124:      	stp	x10, x9, [x11, #0x8]
    2128:      	mov	w9, #0x6                // =6
    212c:      	stur	x8, [x11, #0x15]
    2130:      	mov	w8, #0x1d               // =29
    2134:      	add	x10, sp, #0xc8
    2138:      	ldrb	w3, [sp, #0x88]
    213c:      	blr	x9
    2140:      	ldrb	w8, [sp, #0x88]
    2144:      	add	w9, w8, #0x1
    2148:      	and	w9, w9, #0xff
    214c:      	cmp	w9, #0x2
    2150:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    2154:      	sub	x25, x25, x8
    2158:      	mov	w8, #0x1                // =1
    215c:      	mov	w9, #0x70               // =112
    2160:      	add	x10, sp, #0x88
    2164:      	add	x0, sp, #0x88
    2168:      	mov	w1, #0x1                // =1
    216c:      	add	x2, x25, x19
    2170:      	blr	x9
    2174:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    2178:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    217c:      	ldr	x8, [x8]
    2180:      	ldr	w8, [x8]
    2184:      	cbnz	w8, 0x26e8 <perf_unwind_hotspot+0x26e8>
    2188:      	ldrb	w9, [sp, #0x88]
    218c:      	add	w8, w9, #0x1
    2190:      	and	w8, w8, #0xff
    2194:      	cmp	w8, #0x2
    2198:      	mov	w8, w9
    219c:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    21a0:      	sub	x25, x25, x9
    21a4:      	mov	w8, #0x1                // =1
    21a8:      	mov	w9, #0x70               // =112
    21ac:      	add	x10, sp, #0x88
    21b0:      	add	x0, sp, #0x88
    21b4:      	mov	w1, #0x1                // =1
    21b8:      	add	x2, x25, x19
    21bc:      	blr	x9
    21c0:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    21c4:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    21c8:      	ldr	x8, [x8]
    21cc:      	ldr	w8, [x8]
    21d0:      	cbnz	w8, 0x27f8 <perf_unwind_hotspot+0x27f8>
    21d4:      	ldrb	w9, [sp, #0x88]
    21d8:      	add	w8, w9, #0x1
    21dc:      	and	w8, w8, #0xff
    21e0:      	cmp	w8, #0x2
    21e4:      	mov	w8, w9
    21e8:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    21ec:      	sub	x25, x25, x9
    21f0:      	mov	w8, #0x1                // =1
    21f4:      	mov	w9, #0x70               // =112
    21f8:      	add	x10, sp, #0x88
    21fc:      	add	x0, sp, #0x88
    2200:      	mov	w1, #0x1                // =1
    2204:      	add	x2, x25, x19
    2208:      	blr	x9
    220c:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    2210:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2214:      	ldr	x8, [x8]
    2218:      	ldr	w8, [x8]
    221c:      	cbnz	w8, 0x28bc <perf_unwind_hotspot+0x28bc>
    2220:      	ldrb	w9, [sp, #0x88]
    2224:      	add	w8, w9, #0x1
    2228:      	and	w8, w8, #0xff
    222c:      	cmp	w8, #0x2
    2230:      	mov	w8, w9
    2234:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    2238:      	sub	x25, x25, x9
    223c:      	mov	w8, #0x1                // =1
    2240:      	mov	w9, #0x70               // =112
    2244:      	add	x10, sp, #0x88
    2248:      	add	x0, sp, #0x88
    224c:      	mov	w1, #0x1                // =1
    2250:      	add	x2, x25, x19
    2254:      	blr	x9
    2258:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    225c:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2260:      	ldr	x8, [x8]
    2264:      	ldr	w8, [x8]
    2268:      	cbnz	w8, 0x2a2c <perf_unwind_hotspot+0x2a2c>
    226c:      	ldrb	w9, [sp, #0x88]
    2270:      	add	w8, w9, #0x1
    2274:      	and	w8, w8, #0xff
    2278:      	cmp	w8, #0x2
    227c:      	mov	w8, w9
    2280:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    2284:      	sub	x25, x25, x9
    2288:      	mov	w8, #0x1                // =1
    228c:      	mov	w9, #0x70               // =112
    2290:      	add	x10, sp, #0x88
    2294:      	add	x0, sp, #0x88
    2298:      	mov	w1, #0x1                // =1
    229c:      	add	x2, x25, x19
    22a0:      	blr	x9
    22a4:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    22a8:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    22ac:      	ldr	x8, [x8]
    22b0:      	ldr	w8, [x8]
    22b4:      	cbnz	w8, 0x2bc8 <perf_unwind_hotspot+0x2bc8>
    22b8:      	ldrb	w9, [sp, #0x88]
    22bc:      	add	w8, w9, #0x1
    22c0:      	and	w8, w8, #0xff
    22c4:      	cmp	w8, #0x2
    22c8:      	mov	w8, w9
    22cc:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    22d0:      	sub	x25, x25, x9
    22d4:      	mov	w8, #0x1                // =1
    22d8:      	mov	w9, #0x70               // =112
    22dc:      	add	x10, sp, #0x88
    22e0:      	add	x0, sp, #0x88
    22e4:      	mov	w1, #0x1                // =1
    22e8:      	add	x2, x25, x19
    22ec:      	blr	x9
    22f0:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    22f4:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    22f8:      	ldr	x8, [x8]
    22fc:      	ldr	w8, [x8]
    2300:      	cbnz	w8, 0x315c <perf_unwind_hotspot+0x315c>
    2304:      	ldrb	w9, [sp, #0x88]
    2308:      	add	w8, w9, #0x1
    230c:      	and	w8, w8, #0xff
    2310:      	cmp	w8, #0x2
    2314:      	mov	w8, w9
    2318:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    231c:      	sub	x25, x25, x9
    2320:      	mov	w8, #0x1                // =1
    2324:      	mov	w9, #0x70               // =112
    2328:      	add	x10, sp, #0x88
    232c:      	add	x0, sp, #0x88
    2330:      	mov	w1, #0x1                // =1
    2334:      	add	x2, x25, x19
    2338:      	blr	x9
    233c:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    2340:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2344:      	ldr	x8, [x8]
    2348:      	ldr	w8, [x8]
    234c:      	cbnz	w8, 0x3cdc <perf_unwind_hotspot+0x3cdc>
    2350:      	ldrb	w9, [sp, #0x88]
    2354:      	add	w8, w9, #0x1
    2358:      	and	w8, w8, #0xff
    235c:      	cmp	w8, #0x2
    2360:      	mov	w8, w9
    2364:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    2368:      	sub	x25, x25, x9
    236c:      	mov	w8, #0x1                // =1
    2370:      	mov	w9, #0x70               // =112
    2374:      	add	x10, sp, #0x88
    2378:      	add	x0, sp, #0x88
    237c:      	mov	w1, #0x1                // =1
    2380:      	add	x2, x25, x19
    2384:      	blr	x9
    2388:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    238c:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2390:      	ldr	x8, [x8]
    2394:      	ldr	w8, [x8]
    2398:      	cbnz	w8, 0x3eac <perf_unwind_hotspot+0x3eac>
    239c:      	ldrb	w9, [sp, #0x88]
    23a0:      	add	w8, w9, #0x1
    23a4:      	and	w8, w8, #0xff
    23a8:      	cmp	w8, #0x2
    23ac:      	mov	w8, w9
    23b0:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    23b4:      	sub	x25, x25, x9
    23b8:      	mov	w8, #0x1                // =1
    23bc:      	mov	w9, #0x70               // =112
    23c0:      	add	x10, sp, #0x88
    23c4:      	add	x0, sp, #0x88
    23c8:      	mov	w1, #0x1                // =1
    23cc:      	add	x2, x25, x19
    23d0:      	blr	x9
    23d4:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    23d8:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    23dc:      	ldr	x8, [x8]
    23e0:      	ldr	w8, [x8]
    23e4:      	cbnz	w8, 0x3fb8 <perf_unwind_hotspot+0x3fb8>
    23e8:      	ldrb	w9, [sp, #0x88]
    23ec:      	add	w8, w9, #0x1
    23f0:      	and	w8, w8, #0xff
    23f4:      	cmp	w8, #0x2
    23f8:      	mov	w8, w9
    23fc:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    2400:      	sub	x25, x25, x9
    2404:      	mov	w8, #0x1                // =1
    2408:      	mov	w9, #0x70               // =112
    240c:      	add	x10, sp, #0x88
    2410:      	add	x0, sp, #0x88
    2414:      	mov	w1, #0x1                // =1
    2418:      	add	x2, x25, x19
    241c:      	blr	x9
    2420:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    2424:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2428:      	ldr	x8, [x8]
    242c:      	ldr	w8, [x8]
    2430:      	cbnz	w8, 0x4018 <perf_unwind_hotspot+0x4018>
    2434:      	ldrb	w9, [sp, #0x88]
    2438:      	add	w8, w9, #0x1
    243c:      	and	w8, w8, #0xff
    2440:      	cmp	w8, #0x2
    2444:      	mov	w8, w9
    2448:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    244c:      	sub	x25, x25, x9
    2450:      	mov	w8, #0x1                // =1
    2454:      	mov	w9, #0x70               // =112
    2458:      	add	x10, sp, #0x88
    245c:      	add	x0, sp, #0x88
    2460:      	mov	w1, #0x1                // =1
    2464:      	add	x2, x25, x19
    2468:      	blr	x9
    246c:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    2470:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2474:      	ldr	x8, [x8]
    2478:      	ldr	w8, [x8]
    247c:      	cbnz	w8, 0x4078 <perf_unwind_hotspot+0x4078>
    2480:      	ldrb	w8, [sp, #0x88]
    2484:      	add	w9, w8, #0x1
    2488:      	and	w9, w9, #0xff
    248c:      	cmp	w9, #0x1
    2490:      	b.hi	0x178 <perf_unwind_hotspot+0x178>
    2494:      	b	0x19f0 <perf_unwind_hotspot+0x19f0>
    2498:      	sub	x2, x22, #0x8
    249c:      	mov	w8, #0x8                // =8
    24a0:      	mov	w9, #0x70               // =112
    24a4:      	add	x10, sp, #0xc8
    24a8:      	add	x0, sp, #0xc8
    24ac:      	mov	w1, #0x8                // =8
    24b0:      	blr	x9
    24b4:      	ldr	x8, [sp, #0xc8]
    24b8:      	mov	x9, #0x27ff             // =10239
    24bc:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    24c0:      	movk	x9, #0xa9bf, lsl #16
    24c4:      	movk	x9, #0x100, lsl #32
    24c8:      	movk	x9, #0xd63f, lsl #48
    24cc:      	cmp	x8, x9
    24d0:      	add	x8, x29, #0x10
    24d4:      	ccmp	x0, #0x0, #0x0, eq
    24d8:      	csel	x29, x8, x29, eq
    24dc:      	ldr	w8, [sp, #0x78]
    24e0:      	b	0x2c84 <perf_unwind_hotspot+0x2c84>
    24e4:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    24e8:      	add	x8, x8, #0x0
    24ec:      	add	x11, sp, #0xc8
    24f0:      	ldp	x9, x10, [x8]
    24f4:      	add	x0, sp, #0xc8
    24f8:      	mov	w1, #0x1e               // =30
    24fc:      	str	x9, [sp, #0xc8]
    2500:      	ldr	x9, [x8, #0x10]
    2504:      	ldur	x8, [x8, #0x16]
    2508:      	stp	x10, x9, [x11, #0x8]
    250c:      	mov	w9, #0x6                // =6
    2510:      	stur	x8, [x11, #0x16]
    2514:      	mov	w8, #0x1e               // =30
    2518:      	add	x10, sp, #0xc8
    251c:      	ldrh	w2, [x25, #0x20]
    2520:      	blr	x9
    2524:      	ldrh	w8, [x25, #0x20]
    2528:      	ldr	w9, [x21, #0x1370]
    252c:      	lsr	w8, w9, w8
    2530:      	tbnz	w8, #0x0, 0x18ac <perf_unwind_hotspot+0x18ac>
    2534:      	str	wzr, [sp, #0x88]
    2538:      	adrp	x0, 0x2000 <perf_unwind_hotspot+0x2000>
    253c:      	mov	w8, #0x1                // =1
    2540:      	add	x9, sp, #0x88
    2544:      	ldr	x0, [x0]
    2548:      	add	x1, sp, #0x88
    254c:      	blr	x8
    2550:      	cbz	x0, 0x2568 <perf_unwind_hotspot+0x2568>
    2554:      	ldr	x8, [x0]
    2558:      	add	x8, x8, #0x1
    255c:      	str	x8, [x0]
    2560:      	ldrh	w25, [x25, #0x20]
    2564:      	b	0x18c8 <perf_unwind_hotspot+0x18c8>
    2568:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    256c:      	ldr	x8, [x8]
    2570:      	ldr	w8, [x8]
    2574:      	cbnz	w8, 0x27ac <perf_unwind_hotspot+0x27ac>
    2578:      	ldrh	w25, [x25, #0x20]
    257c:      	b	0x18c8 <perf_unwind_hotspot+0x18c8>
    2580:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2584:      	add	x8, x8, #0x0
    2588:      	add	x11, sp, #0xc8
    258c:      	ldp	x9, x10, [x8]
    2590:      	add	x0, sp, #0xc8
    2594:      	mov	w1, #0x1d               // =29
    2598:      	mov	x2, x24
    259c:      	str	x9, [sp, #0xc8]
    25a0:      	ldr	x9, [x8, #0x10]
    25a4:      	ldur	x8, [x8, #0x15]
    25a8:      	add	x20, sp, #0xc8
    25ac:      	stp	x10, x9, [x11, #0x8]
    25b0:      	stur	x8, [x11, #0x15]
    25b4:      	mov	w8, #0x1d               // =29
    25b8:      	mov	w9, #0x6                // =6
    25bc:      	add	x10, sp, #0xc8
    25c0:      	ldrb	w3, [sp, #0x88]
    25c4:      	blr	x9
    25c8:      	ldrb	w9, [sp, #0x88]
    25cc:      	add	w8, w9, #0x1
    25d0:      	and	w8, w8, #0xff
    25d4:      	cmp	w8, #0x2
    25d8:      	mov	w8, w9
    25dc:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
    25e0:      	b	0xad0 <perf_unwind_hotspot+0xad0>
    25e4:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    25e8:      	ldrb	w8, [x21, #0xf21]
    25ec:      	cbnz	w8, 0x7bc <perf_unwind_hotspot+0x7bc>
    25f0:      	b	0x2694 <perf_unwind_hotspot+0x2694>
    25f4:      	mov	w8, #0x656e             // =25966
    25f8:      	add	x11, sp, #0xc8
    25fc:      	add	x0, sp, #0xc8
    2600:      	mov	w1, #0x1b               // =27
    2604:      	movk	w8, #0xa, lsl #16
    2608:      	stur	w8, [x11, #0x17]
    260c:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2610:      	add	x8, x8, #0x0
    2614:      	ldp	x9, x10, [x8]
    2618:      	ldr	x8, [x8, #0x10]
    261c:      	str	x9, [sp, #0xc8]
    2620:      	mov	w9, #0x6                // =6
    2624:      	stp	x10, x8, [x11, #0x8]
    2628:      	mov	w8, #0x1b               // =27
    262c:      	add	x10, sp, #0xc8
    2630:      	blr	x9
    2634:      	b	0x18bc <perf_unwind_hotspot+0x18bc>
    2638:      	ldr	x9, [sp, #0x88]
    263c:      	ldr	x8, [sp, #0x58]
    2640:      	cmp	x9, x8
    2644:      	b.lo	0x1fdc <perf_unwind_hotspot+0x1fdc>
    2648:      	ldr	x10, [sp, #0x60]
    264c:      	cmp	x9, x10
    2650:      	b.hs	0x1fdc <perf_unwind_hotspot+0x1fdc>
    2654:      	adrp	x10, 0x2000 <perf_unwind_hotspot+0x2000>
    2658:      	ldr	x10, [x10]
    265c:      	ldr	w10, [x10]
    2660:      	cbnz	w10, 0x304c <perf_unwind_hotspot+0x304c>
    2664:      	mov	x22, x9
    2668:      	sub	w8, w22, w8
    266c:      	str	x8, [sp, #0x30]
    2670:      	b	0x1fec <perf_unwind_hotspot+0x1fec>
    2674:      	cbnz	w8, 0x2c28 <perf_unwind_hotspot+0x2c28>
    2678:      	mov	x22, xzr
    267c:      	tbnz	x24, #0x3e, 0x2c78 <perf_unwind_hotspot+0x2c78>
    2680:      	lsr	x8, x24, #53
    2684:      	and	x8, x8, #0x1f8
    2688:      	add	x29, x8, x29
    268c:      	ldrb	w8, [x21, #0xf21]
    2690:      	cbnz	w8, 0x7bc <perf_unwind_hotspot+0x7bc>
    2694:      	ldr	x24, [x21, #0xee8]
    2698:      	b	0x2cd0 <perf_unwind_hotspot+0x2cd0>
    269c:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    26a0:      	add	x8, x8, #0x0
    26a4:      	add	x11, sp, #0xc8
    26a8:      	strb	wzr, [sp, #0xe8]
    26ac:      	ldp	x9, x10, [x8]
    26b0:      	add	x0, sp, #0xc8
    26b4:      	mov	w1, #0x21               // =33
    26b8:      	mov	x2, x24
    26bc:      	str	x9, [sp, #0xc8]
    26c0:      	ldp	x9, x8, [x8, #0x10]
    26c4:      	str	x8, [x11, #0x18]
    26c8:      	stp	x10, x9, [x11, #0x8]
    26cc:      	mov	w8, #0x21               // =33
    26d0:      	mov	w9, #0x6                // =6
    26d4:      	add	x10, sp, #0xc8
    26d8:      	blr	x9
    26dc:      	str	x24, [sp, #0x50]
    26e0:      	cbnz	x24, 0x1a24 <perf_unwind_hotspot+0x1a24>
    26e4:      	b	0x17c <perf_unwind_hotspot+0x17c>
    26e8:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    26ec:      	add	x8, x8, #0x0
    26f0:      	add	x11, sp, #0xc8
    26f4:      	ldp	x9, x10, [x8]
    26f8:      	add	x0, sp, #0xc8
    26fc:      	mov	w1, #0x1d               // =29
    2700:      	mov	x2, x25
    2704:      	str	x9, [sp, #0xc8]
    2708:      	ldr	x9, [x8, #0x10]
    270c:      	ldur	x8, [x8, #0x15]
    2710:      	stp	x10, x9, [x11, #0x8]
    2714:      	mov	w9, #0x6                // =6
    2718:      	stur	x8, [x11, #0x15]
    271c:      	mov	w8, #0x1d               // =29
    2720:      	add	x10, sp, #0xc8
    2724:      	ldrb	w3, [sp, #0x88]
    2728:      	blr	x9
    272c:      	ldrb	w9, [sp, #0x88]
    2730:      	add	w8, w9, #0x1
    2734:      	and	w8, w8, #0xff
    2738:      	cmp	w8, #0x2
    273c:      	mov	w8, w9
    2740:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    2744:      	b	0x21a0 <perf_unwind_hotspot+0x21a0>
    2748:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    274c:      	add	x8, x8, #0x0
    2750:      	add	x11, sp, #0xc8
    2754:      	ldp	x9, x10, [x8]
    2758:      	add	x0, sp, #0xc8
    275c:      	mov	w1, #0x1d               // =29
    2760:      	mov	x2, x24
    2764:      	str	x9, [sp, #0xc8]
    2768:      	ldr	x9, [x8, #0x10]
    276c:      	ldur	x8, [x8, #0x15]
    2770:      	add	x20, sp, #0xc8
    2774:      	stp	x10, x9, [x11, #0x8]
    2778:      	stur	x8, [x11, #0x15]
    277c:      	mov	w8, #0x1d               // =29
    2780:      	mov	w9, #0x6                // =6
    2784:      	add	x10, sp, #0xc8
    2788:      	ldrb	w3, [sp, #0x88]
    278c:      	blr	x9
    2790:      	ldrb	w9, [sp, #0x88]
    2794:      	add	w8, w9, #0x1
    2798:      	and	w8, w8, #0xff
    279c:      	cmp	w8, #0x2
    27a0:      	mov	w8, w9
    27a4:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
    27a8:      	b	0xb1c <perf_unwind_hotspot+0xb1c>
    27ac:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    27b0:      	add	x8, x8, #0x0
    27b4:      	add	x12, sp, #0xc8
    27b8:      	ldp	x9, x10, [x8, #0x10]
    27bc:      	ldr	x11, [x8, #0x20]
    27c0:      	add	x0, sp, #0xc8
    27c4:      	mov	w1, #0x2e               // =46
    27c8:      	stp	x10, x11, [x12, #0x18]
    27cc:      	ldur	x10, [x8, #0x26]
    27d0:      	stur	x10, [x12, #0x26]
    27d4:      	ldp	x10, x8, [x8]
    27d8:      	str	x10, [sp, #0xc8]
    27dc:      	stp	x8, x9, [x12, #0x8]
    27e0:      	mov	w8, #0x2e               // =46
    27e4:      	mov	w9, #0x6                // =6
    27e8:      	add	x10, sp, #0xc8
    27ec:      	ldr	w2, [sp, #0x88]
    27f0:      	blr	x9
    27f4:      	b	0x2578 <perf_unwind_hotspot+0x2578>
    27f8:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    27fc:      	add	x8, x8, #0x0
    2800:      	add	x11, sp, #0xc8
    2804:      	ldp	x9, x10, [x8]
    2808:      	add	x0, sp, #0xc8
    280c:      	mov	w1, #0x1d               // =29
    2810:      	mov	x2, x25
    2814:      	str	x9, [sp, #0xc8]
    2818:      	ldr	x9, [x8, #0x10]
    281c:      	ldur	x8, [x8, #0x15]
    2820:      	stp	x10, x9, [x11, #0x8]
    2824:      	mov	w9, #0x6                // =6
    2828:      	stur	x8, [x11, #0x15]
    282c:      	mov	w8, #0x1d               // =29
    2830:      	add	x10, sp, #0xc8
    2834:      	ldrb	w3, [sp, #0x88]
    2838:      	blr	x9
    283c:      	ldrb	w9, [sp, #0x88]
    2840:      	add	w8, w9, #0x1
    2844:      	and	w8, w8, #0xff
    2848:      	cmp	w8, #0x2
    284c:      	mov	w8, w9
    2850:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    2854:      	b	0x21ec <perf_unwind_hotspot+0x21ec>
    2858:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    285c:      	add	x8, x8, #0x0
    2860:      	add	x11, sp, #0xc8
    2864:      	ldp	x9, x10, [x8]
    2868:      	add	x0, sp, #0xc8
    286c:      	mov	w1, #0x1d               // =29
    2870:      	mov	x2, x24
    2874:      	str	x9, [sp, #0xc8]
    2878:      	ldr	x9, [x8, #0x10]
    287c:      	ldur	x8, [x8, #0x15]
    2880:      	add	x20, sp, #0xc8
    2884:      	stp	x10, x9, [x11, #0x8]
    2888:      	stur	x8, [x11, #0x15]
    288c:      	mov	w8, #0x1d               // =29
    2890:      	mov	w9, #0x6                // =6
    2894:      	add	x10, sp, #0xc8
    2898:      	ldrb	w3, [sp, #0x88]
    289c:      	blr	x9
    28a0:      	ldrb	w9, [sp, #0x88]
    28a4:      	add	w8, w9, #0x1
    28a8:      	and	w8, w8, #0xff
    28ac:      	cmp	w8, #0x2
    28b0:      	mov	w8, w9
    28b4:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
    28b8:      	b	0xb68 <perf_unwind_hotspot+0xb68>
    28bc:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    28c0:      	add	x8, x8, #0x0
    28c4:      	add	x11, sp, #0xc8
    28c8:      	ldp	x9, x10, [x8]
    28cc:      	add	x0, sp, #0xc8
    28d0:      	mov	w1, #0x1d               // =29
    28d4:      	mov	x2, x25
    28d8:      	str	x9, [sp, #0xc8]
    28dc:      	ldr	x9, [x8, #0x10]
    28e0:      	ldur	x8, [x8, #0x15]
    28e4:      	stp	x10, x9, [x11, #0x8]
    28e8:      	mov	w9, #0x6                // =6
    28ec:      	stur	x8, [x11, #0x15]
    28f0:      	mov	w8, #0x1d               // =29
    28f4:      	add	x10, sp, #0xc8
    28f8:      	ldrb	w3, [sp, #0x88]
    28fc:      	blr	x9
    2900:      	ldrb	w9, [sp, #0x88]
    2904:      	add	w8, w9, #0x1
    2908:      	and	w8, w8, #0xff
    290c:      	cmp	w8, #0x2
    2910:      	mov	w8, w9
    2914:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    2918:      	b	0x2238 <perf_unwind_hotspot+0x2238>
    291c:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2920:      	add	x8, x8, #0x0
    2924:      	add	x11, sp, #0xc8
    2928:      	ldp	x9, x10, [x8]
    292c:      	add	x0, sp, #0xc8
    2930:      	mov	w1, #0x1d               // =29
    2934:      	mov	x2, x24
    2938:      	str	x9, [sp, #0xc8]
    293c:      	ldr	x9, [x8, #0x10]
    2940:      	ldur	x8, [x8, #0x15]
    2944:      	add	x20, sp, #0xc8
    2948:      	stp	x10, x9, [x11, #0x8]
    294c:      	stur	x8, [x11, #0x15]
    2950:      	mov	w8, #0x1d               // =29
    2954:      	mov	w9, #0x6                // =6
    2958:      	add	x10, sp, #0xc8
    295c:      	ldrb	w3, [sp, #0x88]
    2960:      	blr	x9
    2964:      	ldrb	w9, [sp, #0x88]
    2968:      	add	w8, w9, #0x1
    296c:      	and	w8, w8, #0xff
    2970:      	cmp	w8, #0x2
    2974:      	mov	w8, w9
    2978:      	b.lo	0x1fc <perf_unwind_hotspot+0x1fc>
    297c:      	b	0xbb4 <perf_unwind_hotspot+0xbb4>
    2980:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2984:      	add	x8, x8, #0x0
    2988:      	add	x0, sp, #0xc8
    298c:      	ldp	x9, x10, [x8]
    2990:      	ldur	x8, [x8, #0xf]
    2994:      	mov	w1, #0x17               // =23
    2998:      	str	x9, [sp, #0xc8]
    299c:      	add	x9, sp, #0xc8
    29a0:      	str	x10, [x9, #0x8]
    29a4:      	stur	x8, [x9, #0xf]
    29a8:      	mov	w8, #0x17               // =23
    29ac:      	mov	w9, #0x6                // =6
    29b0:      	add	x10, sp, #0xc8
    29b4:      	ldp	x2, x3, [sp, #0x58]
    29b8:      	blr	x9
    29bc:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    29c0:      	ldr	x8, [x8]
    29c4:      	ldr	w8, [x8]
    29c8:      	cbz	w8, 0x1b14 <perf_unwind_hotspot+0x1b14>
    29cc:      	mov	w8, #0x7825             // =30757
    29d0:      	add	x13, sp, #0xc8
    29d4:      	add	x0, sp, #0xc8
    29d8:      	mov	w1, #0x3c               // =60
    29dc:      	movk	w8, #0xa, lsl #16
    29e0:      	str	w8, [sp, #0x100]
    29e4:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    29e8:      	add	x8, x8, #0x0
    29ec:      	ldp	x9, x10, [x8, #0x20]
    29f0:      	ldp	x12, x11, [x8, #0x10]
    29f4:      	stp	x11, x9, [x13, #0x18]
    29f8:      	ldr	x9, [x8, #0x30]
    29fc:      	stp	x10, x9, [x13, #0x28]
    2a00:      	ldp	x9, x8, [x8]
    2a04:      	add	x10, sp, #0xc8
    2a08:      	str	x9, [sp, #0xc8]
    2a0c:      	stp	x8, x12, [x13, #0x8]
    2a10:      	mov	w8, #0x3c               // =60
    2a14:      	mov	w9, #0x6                // =6
    2a18:      	ldrh	w2, [sp, #0x80]
    2a1c:      	ldr	w3, [sp, #0x78]
    2a20:      	ldr	w4, [sp, #0x70]
    2a24:      	blr	x9
    2a28:      	b	0x1b14 <perf_unwind_hotspot+0x1b14>
    2a2c:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2a30:      	add	x8, x8, #0x0
    2a34:      	add	x11, sp, #0xc8
    2a38:      	ldp	x9, x10, [x8]
    2a3c:      	add	x0, sp, #0xc8
    2a40:      	mov	w1, #0x1d               // =29
    2a44:      	mov	x2, x25
    2a48:      	str	x9, [sp, #0xc8]
    2a4c:      	ldr	x9, [x8, #0x10]
    2a50:      	ldur	x8, [x8, #0x15]
    2a54:      	stp	x10, x9, [x11, #0x8]
    2a58:      	mov	w9, #0x6                // =6
    2a5c:      	stur	x8, [x11, #0x15]
    2a60:      	mov	w8, #0x1d               // =29
    2a64:      	add	x10, sp, #0xc8
    2a68:      	ldrb	w3, [sp, #0x88]
    2a6c:      	blr	x9
    2a70:      	ldrb	w9, [sp, #0x88]
    2a74:      	add	w8, w9, #0x1
    2a78:      	and	w8, w8, #0xff
    2a7c:      	cmp	w8, #0x2
    2a80:      	mov	w8, w9
    2a84:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    2a88:      	b	0x2284 <perf_unwind_hotspot+0x2284>
    2a8c:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2a90:      	add	x8, x8, #0x0
    2a94:      	add	x11, sp, #0xc8
    2a98:      	ldp	x9, x10, [x8]
    2a9c:      	add	x0, sp, #0xc8
    2aa0:      	mov	w1, #0x1d               // =29
    2aa4:      	mov	x2, x24
    2aa8:      	str	x9, [sp, #0xc8]
    2aac:      	ldr	x9, [x8, #0x10]
    2ab0:      	ldur	x8, [x8, #0x15]
    2ab4:      	add	x20, sp, #0xc8
    2ab8:      	stp	x10, x9, [x11, #0x8]
    2abc:      	stur	x8, [x11, #0x15]
    2ac0:      	mov	w8, #0x1d               // =29
    2ac4:      	mov	w9, #0x6                // =6
    2ac8:      	add	x10, sp, #0xc8
    2acc:      	ldrb	w3, [sp, #0x88]
    2ad0:      	blr	x9
    2ad4:      	ldrb	w8, [sp, #0x88]
    2ad8:      	add	w9, w8, #0x1
    2adc:      	and	w9, w9, #0xff
    2ae0:      	cmp	w9, #0x1
    2ae4:      	b.hi	0x178 <perf_unwind_hotspot+0x178>
    2ae8:      	b	0x1fc <perf_unwind_hotspot+0x1fc>
    2aec:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2af0:      	add	x8, x8, #0x0
    2af4:      	add	x0, sp, #0xc8
    2af8:      	ldp	x9, x10, [x8]
    2afc:      	ldr	x8, [x8, #0x10]
    2b00:      	mov	w1, #0x18               // =24
    2b04:      	str	x9, [sp, #0xc8]
    2b08:      	add	x9, sp, #0xc8
    2b0c:      	stp	x10, x8, [x9, #0x8]
    2b10:      	mov	w8, #0x18               // =24
    2b14:      	mov	w9, #0x6                // =6
    2b18:      	add	x10, sp, #0xc8
    2b1c:      	blr	x9
    2b20:      	mov	x22, #0x1000000000000000 // =1152921504606846976
    2b24:      	ldrb	w8, [x21, #0xf21]
    2b28:      	cbnz	w8, 0x7bc <perf_unwind_hotspot+0x7bc>
    2b2c:      	b	0x2694 <perf_unwind_hotspot+0x2694>
    2b30:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2b34:      	add	x8, x8, #0x0
    2b38:      	add	x13, sp, #0xc8
    2b3c:      	ldp	x9, x10, [x8, #0x10]
    2b40:      	ldp	x11, x12, [x8, #0x20]
    2b44:      	add	x0, sp, #0xc8
    2b48:      	mov	w1, #0x30               // =48
    2b4c:      	str	x12, [x13, #0x28]
    2b50:      	stp	x10, x11, [x13, #0x18]
    2b54:      	ldp	x10, x8, [x8]
    2b58:      	str	x10, [sp, #0xc8]
    2b5c:      	stp	x8, x9, [x13, #0x8]
    2b60:      	mov	w8, #0x30               // =48
    2b64:      	mov	w9, #0x6                // =6
    2b68:      	add	x10, sp, #0xc8
    2b6c:      	blr	x9
    2b70:      	b	0x1fec <perf_unwind_hotspot+0x1fec>
    2b74:      	mov	w8, #0x6874             // =26740
    2b78:      	add	x11, sp, #0xc8
    2b7c:      	add	x0, sp, #0xc8
    2b80:      	mov	w1, #0x24               // =36
    2b84:      	movk	w8, #0xa, lsl #16
    2b88:      	str	w8, [sp, #0xe8]
    2b8c:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2b90:      	add	x8, x8, #0x0
    2b94:      	ldp	x9, x10, [x8]
    2b98:      	str	x9, [sp, #0xc8]
    2b9c:      	ldp	x9, x8, [x8, #0x10]
    2ba0:      	stp	x10, x9, [x11, #0x8]
    2ba4:      	str	x8, [x11, #0x18]
    2ba8:      	mov	w8, #0x24               // =36
    2bac:      	mov	w9, #0x6                // =6
    2bb0:      	add	x10, sp, #0xc8
    2bb4:      	blr	x9
    2bb8:      	ldr	w8, [sp, #0x78]
    2bbc:      	mov	x22, xzr
    2bc0:      	cbnz	w8, 0x2c84 <perf_unwind_hotspot+0x2c84>
    2bc4:      	b	0x2c78 <perf_unwind_hotspot+0x2c78>
    2bc8:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2bcc:      	add	x8, x8, #0x0
    2bd0:      	add	x11, sp, #0xc8
    2bd4:      	ldp	x9, x10, [x8]
    2bd8:      	add	x0, sp, #0xc8
    2bdc:      	mov	w1, #0x1d               // =29
    2be0:      	mov	x2, x25
    2be4:      	str	x9, [sp, #0xc8]
    2be8:      	ldr	x9, [x8, #0x10]
    2bec:      	ldur	x8, [x8, #0x15]
    2bf0:      	stp	x10, x9, [x11, #0x8]
    2bf4:      	mov	w9, #0x6                // =6
    2bf8:      	stur	x8, [x11, #0x15]
    2bfc:      	mov	w8, #0x1d               // =29
    2c00:      	add	x10, sp, #0xc8
    2c04:      	ldrb	w3, [sp, #0x88]
    2c08:      	blr	x9
    2c0c:      	ldrb	w9, [sp, #0x88]
    2c10:      	add	w8, w9, #0x1
    2c14:      	and	w8, w8, #0xff
    2c18:      	cmp	w8, #0x2
    2c1c:      	mov	w8, w9
    2c20:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    2c24:      	b	0x22d0 <perf_unwind_hotspot+0x22d0>
    2c28:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2c2c:      	add	x8, x8, #0x0
    2c30:      	add	x13, sp, #0xc8
    2c34:      	strb	wzr, [sp, #0xf8]
    2c38:      	ldp	x9, x10, [x8, #0x10]
    2c3c:      	add	x0, sp, #0xc8
    2c40:      	ldp	x11, x12, [x8, #0x20]
    2c44:      	mov	w1, #0x31               // =49
    2c48:      	mov	x2, x24
    2c4c:      	str	x12, [x13, #0x28]
    2c50:      	stp	x10, x11, [x13, #0x18]
    2c54:      	ldp	x10, x8, [x8]
    2c58:      	str	x10, [sp, #0xc8]
    2c5c:      	add	x10, sp, #0xc8
    2c60:      	stp	x8, x9, [x13, #0x8]
    2c64:      	mov	w8, #0x31               // =49
    2c68:      	mov	w9, #0x6                // =6
    2c6c:      	blr	x9
    2c70:      	mov	x22, xzr
    2c74:      	tbz	x24, #0x3e, 0x2680 <perf_unwind_hotspot+0x2680>
    2c78:      	ldr	x29, [sp, #0x38]
    2c7c:      	mov	w8, #0x10               // =16
    2c80:      	str	w8, [sp, #0x78]
    2c84:      	add	x9, x29, w8, uxtw
    2c88:      	mov	w8, #0x10               // =16
    2c8c:      	add	x10, sp, #0x88
    2c90:      	add	x0, sp, #0x88
    2c94:      	mov	w1, #0x10               // =16
    2c98:      	mov	x29, x9
    2c9c:      	sub	x2, x9, #0x10
    2ca0:      	mov	w9, #0x70               // =112
    2ca4:      	blr	x9
    2ca8:      	ldr	w8, [sp, #0x78]
    2cac:      	ldr	x24, [sp, #0x90]
    2cb0:      	cmp	w8, #0x10
    2cb4:      	b.lo	0x2cd0 <perf_unwind_hotspot+0x2cd0>
    2cb8:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2cbc:      	ldr	x8, [x8]
    2cc0:      	ldr	w8, [x8]
    2cc4:      	cbnz	w8, 0x2f24 <perf_unwind_hotspot+0x2f24>
    2cc8:      	ldr	x8, [sp, #0x88]
    2ccc:      	str	x8, [sp, #0x38]
    2cd0:      	ldr	w8, [x21, #0x2c0]
    2cd4:      	cmp	w8, #0x7e
    2cd8:      	b.hi	0x1508 <perf_unwind_hotspot+0x1508>
    2cdc:      	mov	w12, w19
    2ce0:      	and	x10, x22, #0x3000000000000000
    2ce4:      	ldr	x11, [sp, #0x30]
    2ce8:      	ldrb	w9, [x21, #0xf20]
    2cec:      	orr	x11, x12, x11, lsl #32
    2cf0:      	orr	x10, x11, x10
    2cf4:      	add	w11, w8, #0x1
    2cf8:      	str	w11, [x21, #0x2c0]
    2cfc:      	mov	w11, #0x18              // =24
    2d00:      	umaddl	x8, w8, w11, x21
    2d04:      	str	x10, [x8, #0x2d8]
    2d08:      	mov	w10, #0x5               // =5
    2d0c:      	str	x25, [x8, #0x2d0]
    2d10:      	strb	w9, [x8, #0x2e1]
    2d14:      	strh	wzr, [x8, #0x2e6]
    2d18:      	strb	w10, [x8, #0x2e0]
    2d1c:      	add	x10, x8, #0x2d0
    2d20:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2d24:      	stur	wzr, [x10, #0x12]
    2d28:      	ldr	x8, [x8]
    2d2c:      	ldr	w8, [x8]
    2d30:      	cbnz	w8, 0x2ed0 <perf_unwind_hotspot+0x2ed0>
    2d34:      	ldr	x8, [sp, #0x38]
    2d38:      	str	x24, [x21, #0xed0]
    2d3c:      	adrp	x0, 0x2000 <perf_unwind_hotspot+0x2000>
    2d40:      	add	x9, sp, #0x88
    2d44:      	add	x1, sp, #0x88
    2d48:      	str	x29, [x21, #0xed8]
    2d4c:      	str	x8, [x21, #0xee0]
    2d50:      	mov	w8, #0x101              // =257
    2d54:      	strh	w8, [x21, #0xf20]
    2d58:      	mov	w8, #0x2a               // =42
    2d5c:      	str	w8, [sp, #0x88]
    2d60:      	mov	w8, #0x1                // =1
    2d64:      	ldr	x0, [x0]
    2d68:      	blr	x8
    2d6c:      	cbz	x0, 0x2d8c <perf_unwind_hotspot+0x2d8c>
    2d70:      	ldr	x8, [x0]
    2d74:      	add	x8, x8, #0x1
    2d78:      	str	x8, [x0]
    2d7c:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2d80:      	ldr	x8, [x8]
    2d84:      	ldr	w8, [x8]
    2d88:      	b	0x2d9c <perf_unwind_hotspot+0x2d9c>
    2d8c:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2d90:      	ldr	x8, [x8]
    2d94:      	ldr	w8, [x8]
    2d98:      	cbnz	w8, 0x2fb8 <perf_unwind_hotspot+0x2fb8>
    2d9c:      	ldr	x29, [x21, #0xed0]
    2da0:      	cbz	x29, 0x5eac <perf_unwind_hotspot+0x5eac>
    2da4:      	cbnz	w8, 0x2f60 <perf_unwind_hotspot+0x2f60>
    2da8:      	lsr	x8, x29, #56
    2dac:      	cbnz	x8, 0x1644 <perf_unwind_hotspot+0x1644>
    2db0:      	cmp	x29, #0x1, lsl #12      // =0x1000
    2db4:      	b.lo	0x1798 <perf_unwind_hotspot+0x1798>
    2db8:      	ldr	w8, [x21]
    2dbc:      	mov	w9, #0x60               // =96
    2dc0:      	add	x1, sp, #0x50
    2dc4:      	mov	x0, x20
    2dc8:      	rev	w8, w8
    2dcc:      	stp	w9, w8, [sp, #0x50]
    2dd0:      	rev	x8, x29
    2dd4:      	add	x9, sp, #0x50
    2dd8:      	str	x8, [sp, #0x58]
    2ddc:      	mov	w8, #0x1                // =1
    2de0:      	blr	x8
    2de4:      	cbz	x0, 0x5ee0 <perf_unwind_hotspot+0x5ee0>
    2de8:      	ldr	x8, [x0, #0x8]
    2dec:      	and	x9, x8, #0xffffffffffffff
    2df0:      	lsr	x25, x8, #56
    2df4:      	str	x9, [x21, #0xf10]
    2df8:      	ldr	x8, [x0]
    2dfc:      	str	x8, [x21, #0xf00]
    2e00:      	sub	x8, x29, x9
    2e04:      	str	x8, [x21, #0xf08]
    2e08:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2e0c:      	ldr	x8, [x8]
    2e10:      	ldr	w8, [x8]
    2e14:      	cbnz	w8, 0x30a8 <perf_unwind_hotspot+0x30a8>
    2e18:      	cmp	w25, #0x1
    2e1c:      	b.ne	0x32a4 <perf_unwind_hotspot+0x32a4>
    2e20:      	ldr	x8, [x21, #0xf00]
    2e24:      	adrp	x0, 0x2000 <perf_unwind_hotspot+0x2000>
    2e28:      	ldr	x19, [x21, #0xf08]
    2e2c:      	mov	w9, #0x1                // =1
    2e30:      	add	x1, sp, #0x50
    2e34:      	mov	w22, #0x1               // =1
    2e38:      	str	x8, [sp, #0x50]
    2e3c:      	add	x8, sp, #0x50
    2e40:      	ldr	x0, [x0]
    2e44:      	blr	x9
    2e48:      	cbz	x0, 0x2ec0 <perf_unwind_hotspot+0x2ec0>
    2e4c:      	ldr	x8, [x0]
    2e50:      	mov	x25, x0
    2e54:      	cmp	x8, x19
    2e58:      	b.hi	0x2e68 <perf_unwind_hotspot+0x2e68>
    2e5c:      	ldr	x8, [x25, #0x8]
    2e60:      	cmp	x8, x19
    2e64:      	b.hs	0x2e80 <perf_unwind_hotspot+0x2e80>
    2e68:      	ldr	x8, [x25, #0x10]
    2e6c:      	cmp	x8, x19
    2e70:      	b.hi	0x2eb0 <perf_unwind_hotspot+0x2eb0>
    2e74:      	ldr	x8, [x25, #0x18]
    2e78:      	cmp	x8, x19
    2e7c:      	b.lo	0x2eb0 <perf_unwind_hotspot+0x2eb0>
    2e80:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2e84:      	ldr	x8, [x8]
    2e88:      	ldr	w8, [x8]
    2e8c:      	cbnz	w8, 0x3210 <perf_unwind_hotspot+0x3210>
    2e90:      	ldrh	w8, [x25, #0x20]
    2e94:      	ldr	w9, [x21, #0x1370]
    2e98:      	lsr	w8, w9, w8
    2e9c:      	tbz	w8, #0x0, 0x3260 <perf_unwind_hotspot+0x3260>
    2ea0:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2ea4:      	ldr	x8, [x8]
    2ea8:      	ldr	w8, [x8]
    2eac:      	cbnz	w8, 0x3d4c <perf_unwind_hotspot+0x3d4c>
    2eb0:      	mov	w25, #0x1               // =1
    2eb4:      	cmp	w25, #0x2
    2eb8:      	b.eq	0x32ac <perf_unwind_hotspot+0x32ac>
    2ebc:      	b	0x6074 <perf_unwind_hotspot+0x6074>
    2ec0:      	mov	w25, w22
    2ec4:      	cmp	w25, #0x2
    2ec8:      	b.eq	0x32ac <perf_unwind_hotspot+0x32ac>
    2ecc:      	b	0x6074 <perf_unwind_hotspot+0x6074>
    2ed0:      	mov	w8, #0x786c             // =30828
    2ed4:      	add	x11, sp, #0xc8
    2ed8:      	add	x0, sp, #0xc8
    2edc:      	mov	w1, #0x24               // =36
    2ee0:      	mov	x2, x24
    2ee4:      	mov	x3, x29
    2ee8:      	movk	w8, #0xa, lsl #16
    2eec:      	str	w8, [sp, #0xe8]
    2ef0:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2ef4:      	add	x8, x8, #0x0
    2ef8:      	ldp	x9, x10, [x8]
    2efc:      	str	x9, [sp, #0xc8]
    2f00:      	ldp	x9, x8, [x8, #0x10]
    2f04:      	stp	x10, x9, [x11, #0x8]
    2f08:      	str	x8, [x11, #0x18]
    2f0c:      	mov	w8, #0x24               // =36
    2f10:      	mov	w9, #0x6                // =6
    2f14:      	add	x10, sp, #0xc8
    2f18:      	ldr	x4, [sp, #0x38]
    2f1c:      	blr	x9
    2f20:      	b	0x2d34 <perf_unwind_hotspot+0x2d34>
    2f24:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2f28:      	add	x8, x8, #0x0
    2f2c:      	add	x0, sp, #0xc8
    2f30:      	ldp	x9, x10, [x8]
    2f34:      	ldur	x8, [x8, #0xd]
    2f38:      	mov	w1, #0x15               // =21
    2f3c:      	str	x9, [sp, #0xc8]
    2f40:      	add	x9, sp, #0xc8
    2f44:      	str	x10, [x9, #0x8]
    2f48:      	stur	x8, [x9, #0xd]
    2f4c:      	mov	w8, #0x15               // =21
    2f50:      	mov	w9, #0x6                // =6
    2f54:      	add	x10, sp, #0xc8
    2f58:      	blr	x9
    2f5c:      	b	0x2cc8 <perf_unwind_hotspot+0x2cc8>
    2f60:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2f64:      	add	x8, x8, #0x0
    2f68:      	add	x13, sp, #0xc8
    2f6c:      	strb	wzr, [sp, #0xf8]
    2f70:      	ldp	x9, x10, [x8, #0x10]
    2f74:      	add	x0, sp, #0xc8
    2f78:      	ldp	x11, x12, [x8, #0x20]
    2f7c:      	mov	w1, #0x31               // =49
    2f80:      	str	x12, [x13, #0x28]
    2f84:      	stp	x10, x11, [x13, #0x18]
    2f88:      	ldp	x10, x8, [x8]
    2f8c:      	str	x10, [sp, #0xc8]
    2f90:      	stp	x8, x9, [x13, #0x8]
    2f94:      	mov	w8, #0x31               // =49
    2f98:      	mov	w9, #0x6                // =6
    2f9c:      	add	x10, sp, #0xc8
    2fa0:      	ldr	w2, [x21, #0x2c0]
    2fa4:      	blr	x9
    2fa8:      	ldr	x29, [x21, #0xed0]
    2fac:      	lsr	x8, x29, #56
    2fb0:      	cbnz	x8, 0x1644 <perf_unwind_hotspot+0x1644>
    2fb4:      	b	0x2db0 <perf_unwind_hotspot+0x2db0>
    2fb8:      	adrp	x8, 0x2000 <perf_unwind_hotspot+0x2000>
    2fbc:      	add	x8, x8, #0x0
    2fc0:      	add	x12, sp, #0xc8
    2fc4:      	ldp	x9, x10, [x8, #0x10]
    2fc8:      	ldr	x11, [x8, #0x20]
    2fcc:      	add	x0, sp, #0xc8
    2fd0:      	mov	w1, #0x2e               // =46
    2fd4:      	stp	x10, x11, [x12, #0x18]
    2fd8:      	ldur	x10, [x8, #0x26]
    2fdc:      	stur	x10, [x12, #0x26]
    2fe0:      	ldp	x10, x8, [x8]
    2fe4:      	str	x10, [sp, #0xc8]
    2fe8:      	stp	x8, x9, [x12, #0x8]
    2fec:      	mov	w8, #0x2e               // =46
    2ff0:      	mov	w9, #0x6                // =6
    2ff4:      	add	x10, sp, #0xc8
    2ff8:      	ldr	w2, [sp, #0x88]
    2ffc:      	blr	x9
    3000:      	b	0x2d7c <perf_unwind_hotspot+0x2d7c>
    3004:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3008:      	add	x8, x8, #0x0
    300c:      	add	x11, sp, #0xc8
    3010:      	ldp	x9, x10, [x8, #0x18]
    3014:      	add	x0, sp, #0xc8
    3018:      	mov	w1, #0x2f               // =47
    301c:      	stp	x9, x10, [x11, #0x18]
    3020:      	ldur	x10, [x8, #0x27]
    3024:      	stur	x10, [x11, #0x27]
    3028:      	ldr	x10, [x8]
    302c:      	ldp	x8, x9, [x8, #0x8]
    3030:      	str	x10, [sp, #0xc8]
    3034:      	stp	x8, x9, [x11, #0x8]
    3038:      	mov	w8, #0x2f               // =47
    303c:      	mov	w9, #0x6                // =6
    3040:      	add	x10, sp, #0xc8
    3044:      	blr	x9
    3048:      	b	0x20a8 <perf_unwind_hotspot+0x20a8>
    304c:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3050:      	add	x8, x8, #0x0
    3054:      	add	x13, sp, #0xc8
    3058:      	ldp	x9, x10, [x8, #0x20]
    305c:      	ldp	x11, x12, [x8, #0x30]
    3060:      	add	x0, sp, #0xc8
    3064:      	mov	w1, #0x40               // =64
    3068:      	str	x12, [x13, #0x38]
    306c:      	stp	x10, x11, [x13, #0x28]
    3070:      	ldp	x10, x11, [x8]
    3074:      	str	x10, [sp, #0xc8]
    3078:      	ldp	x10, x8, [x8, #0x10]
    307c:      	stp	x11, x10, [x13, #0x8]
    3080:      	add	x10, sp, #0xc8
    3084:      	stp	x8, x9, [x13, #0x18]
    3088:      	mov	w8, #0x40               // =64
    308c:      	mov	w9, #0x6                // =6
    3090:      	ldr	x2, [sp, #0x88]
    3094:      	ldr	w3, [sp, #0x74]
    3098:      	blr	x9
    309c:      	ldr	x22, [sp, #0x88]
    30a0:      	ldr	x8, [sp, #0x58]
    30a4:      	b	0x2668 <perf_unwind_hotspot+0x2668>
    30a8:      	mov	w8, #0xa                // =10
    30ac:      	add	x13, sp, #0xc8
    30b0:      	add	x0, sp, #0xc8
    30b4:      	strh	w8, [sp, #0xf8]
    30b8:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    30bc:      	add	x8, x8, #0x0
    30c0:      	mov	w1, #0x32               // =50
    30c4:      	ldp	x9, x10, [x8, #0x10]
    30c8:      	ldp	x11, x12, [x8, #0x20]
    30cc:      	mov	x2, x29
    30d0:      	mov	w4, w25
    30d4:      	str	x12, [x13, #0x28]
    30d8:      	stp	x10, x11, [x13, #0x18]
    30dc:      	ldp	x10, x8, [x8]
    30e0:      	str	x10, [sp, #0xc8]
    30e4:      	add	x10, sp, #0xc8
    30e8:      	stp	x8, x9, [x13, #0x8]
    30ec:      	mov	w8, #0x32               // =50
    30f0:      	mov	w9, #0x6                // =6
    30f4:      	ldr	x3, [x21, #0xf00]
    30f8:      	blr	x9
    30fc:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3100:      	ldr	x8, [x8]
    3104:      	ldr	w8, [x8]
    3108:      	cbz	w8, 0x2e18 <perf_unwind_hotspot+0x2e18>
    310c:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3110:      	add	x8, x8, #0x0
    3114:      	add	x12, sp, #0xc8
    3118:      	ldp	x9, x10, [x8, #0x10]
    311c:      	ldr	x11, [x8, #0x20]
    3120:      	add	x0, sp, #0xc8
    3124:      	mov	w1, #0x2f               // =47
    3128:      	stp	x10, x11, [x12, #0x18]
    312c:      	ldur	x10, [x8, #0x27]
    3130:      	stur	x10, [x12, #0x27]
    3134:      	ldp	x10, x8, [x8]
    3138:      	str	x10, [sp, #0xc8]
    313c:      	stp	x8, x9, [x12, #0x8]
    3140:      	mov	w8, #0x2f               // =47
    3144:      	mov	w9, #0x6                // =6
    3148:      	add	x10, sp, #0xc8
    314c:      	ldr	x2, [x21, #0xf10]
    3150:      	ldr	x3, [x21, #0xf08]
    3154:      	blr	x9
    3158:      	b	0x2e18 <perf_unwind_hotspot+0x2e18>
    315c:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3160:      	add	x8, x8, #0x0
    3164:      	add	x11, sp, #0xc8
    3168:      	ldp	x9, x10, [x8]
    316c:      	add	x0, sp, #0xc8
    3170:      	mov	w1, #0x1d               // =29
    3174:      	mov	x2, x25
    3178:      	str	x9, [sp, #0xc8]
    317c:      	ldr	x9, [x8, #0x10]
    3180:      	ldur	x8, [x8, #0x15]
    3184:      	stp	x10, x9, [x11, #0x8]
    3188:      	mov	w9, #0x6                // =6
    318c:      	stur	x8, [x11, #0x15]
    3190:      	mov	w8, #0x1d               // =29
    3194:      	add	x10, sp, #0xc8
    3198:      	ldrb	w3, [sp, #0x88]
    319c:      	blr	x9
    31a0:      	ldrb	w9, [sp, #0x88]
    31a4:      	add	w8, w9, #0x1
    31a8:      	and	w8, w8, #0xff
    31ac:      	cmp	w8, #0x2
    31b0:      	mov	w8, w9
    31b4:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    31b8:      	b	0x231c <perf_unwind_hotspot+0x231c>
    31bc:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    31c0:      	add	x8, x8, #0x0
    31c4:      	add	x0, sp, #0x88
    31c8:      	ldp	x9, x10, [x8, #0x20]
    31cc:      	mov	w1, #0x35               // =53
    31d0:      	mov	x2, x25
    31d4:      	mov	x4, x19
    31d8:      	stp	x9, x10, [sp, #0xa8]
    31dc:      	ldur	x9, [x8, #0x2d]
    31e0:      	stur	x9, [sp, #0xb5]
    31e4:      	ldp	x9, x10, [x8]
    31e8:      	stp	x9, x10, [sp, #0x88]
    31ec:      	ldp	x8, x9, [x8, #0x10]
    31f0:      	add	x10, sp, #0x88
    31f4:      	stp	x8, x9, [sp, #0x98]
    31f8:      	mov	w8, #0x35               // =53
    31fc:      	mov	w9, #0x6                // =6
    3200:      	ldr	x3, [sp, #0xc0]
    3204:      	blr	x9
    3208:      	ldr	x8, [sp, #0xc0]
    320c:      	b	0x1c1c <perf_unwind_hotspot+0x1c1c>
    3210:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3214:      	add	x8, x8, #0x0
    3218:      	add	x11, sp, #0xc8
    321c:      	ldp	x9, x10, [x8]
    3220:      	add	x0, sp, #0xc8
    3224:      	mov	w1, #0x1e               // =30
    3228:      	str	x9, [sp, #0xc8]
    322c:      	ldr	x9, [x8, #0x10]
    3230:      	ldur	x8, [x8, #0x16]
    3234:      	stp	x10, x9, [x11, #0x8]
    3238:      	mov	w9, #0x6                // =6
    323c:      	stur	x8, [x11, #0x16]
    3240:      	mov	w8, #0x1e               // =30
    3244:      	add	x10, sp, #0xc8
    3248:      	ldrh	w2, [x25, #0x20]
    324c:      	blr	x9
    3250:      	ldrh	w8, [x25, #0x20]
    3254:      	ldr	w9, [x21, #0x1370]
    3258:      	lsr	w8, w9, w8
    325c:      	tbnz	w8, #0x0, 0x2ea0 <perf_unwind_hotspot+0x2ea0>
    3260:      	str	wzr, [sp, #0x88]
    3264:      	adrp	x0, 0x3000 <perf_unwind_hotspot+0x3000>
    3268:      	mov	w8, #0x1                // =1
    326c:      	add	x9, sp, #0x88
    3270:      	ldr	x0, [x0]
    3274:      	add	x1, sp, #0x88
    3278:      	blr	x8
    327c:      	cbz	x0, 0x3290 <perf_unwind_hotspot+0x3290>
    3280:      	ldr	x8, [x0]
    3284:      	add	x8, x8, #0x1
    3288:      	str	x8, [x0]
    328c:      	b	0x32a0 <perf_unwind_hotspot+0x32a0>
    3290:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3294:      	ldr	x8, [x8]
    3298:      	ldr	w8, [x8]
    329c:      	cbnz	w8, 0x3f0c <perf_unwind_hotspot+0x3f0c>
    32a0:      	ldrh	w25, [x25, #0x20]
    32a4:      	cmp	w25, #0x2
    32a8:      	b.ne	0x6074 <perf_unwind_hotspot+0x6074>
    32ac:      	mov	w8, #0x29               // =41
    32b0:      	adrp	x0, 0x3000 <perf_unwind_hotspot+0x3000>
    32b4:      	add	x9, sp, #0x50
    32b8:      	str	w8, [sp, #0x50]
    32bc:      	mov	w8, #0x1                // =1
    32c0:      	add	x1, sp, #0x50
    32c4:      	ldr	x0, [x0]
    32c8:      	blr	x8
    32cc:      	cbz	x0, 0x3354 <perf_unwind_hotspot+0x3354>
    32d0:      	ldr	x8, [x0]
    32d4:      	add	x8, x8, #0x1
    32d8:      	str	x8, [x0]
    32dc:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    32e0:      	ldr	x8, [x8]
    32e4:      	ldr	x22, [x21, #0xed0]
    32e8:      	ldr	x29, [x21, #0xed8]
    32ec:      	ldr	x9, [x21, #0xee0]
    32f0:      	ldr	w8, [x8]
    32f4:      	str	x9, [sp, #0x38]
    32f8:      	cbz	w8, 0x3374 <perf_unwind_hotspot+0x3374>
    32fc:      	mov	w8, #0x786c             // =30828
    3300:      	add	x13, sp, #0xc8
    3304:      	add	x0, sp, #0xc8
    3308:      	mov	w1, #0x2c               // =44
    330c:      	movk	w8, #0xa, lsl #16
    3310:      	str	w8, [sp, #0xf0]
    3314:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3318:      	add	x8, x8, #0x0
    331c:      	ldp	x9, x10, [x8, #0x10]
    3320:      	ldp	x12, x11, [x8]
    3324:      	ldr	x8, [x8, #0x20]
    3328:      	str	x12, [sp, #0xc8]
    332c:      	stp	x11, x9, [x13, #0x8]
    3330:      	stp	x10, x8, [x13, #0x18]
    3334:      	mov	w8, #0x2c               // =44
    3338:      	mov	w9, #0x6                // =6
    333c:      	add	x10, sp, #0xc8
    3340:      	ldr	x2, [x21, #0xed0]
    3344:      	ldr	x3, [x21, #0xf10]
    3348:      	ldr	x4, [x21, #0xf08]
    334c:      	blr	x9
    3350:      	b	0x3374 <perf_unwind_hotspot+0x3374>
    3354:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3358:      	ldr	x8, [x8]
    335c:      	ldr	w8, [x8]
    3360:      	cbnz	w8, 0x3754 <perf_unwind_hotspot+0x3754>
    3364:      	ldr	x8, [x21, #0xee0]
    3368:      	ldr	x22, [x21, #0xed0]
    336c:      	ldr	x29, [x21, #0xed8]
    3370:      	str	x8, [sp, #0x38]
    3374:      	ldr	x8, [x21, #0xf08]
    3378:      	ldrb	w9, [x23, #0x20]
    337c:      	add	x10, sp, #0x88
    3380:      	add	x0, sp, #0x88
    3384:      	mov	w1, #0x1                // =1
    3388:      	lsr	x25, x8, x9
    338c:      	ldr	x8, [x21, #0xf00]
    3390:      	mov	w9, #0x70               // =112
    3394:      	and	x19, x8, #0xffffffffffffff
    3398:      	mov	w8, #0x1                // =1
    339c:      	add	x2, x25, x19
    33a0:      	blr	x9
    33a4:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    33a8:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    33ac:      	ldr	x8, [x8]
    33b0:      	ldr	w8, [x8]
    33b4:      	cbnz	w8, 0x37a0 <perf_unwind_hotspot+0x37a0>
    33b8:      	ldrb	w8, [sp, #0x88]
    33bc:      	add	w9, w8, #0x1
    33c0:      	and	w9, w9, #0xff
    33c4:      	cmp	w9, #0x2
    33c8:      	b.hs	0x37f8 <perf_unwind_hotspot+0x37f8>
    33cc:      	cbnz	w8, 0x178 <perf_unwind_hotspot+0x178>
    33d0:      	ldr	x8, [x21, #0xf10]
    33d4:      	ldrb	w9, [x23, #0x20]
    33d8:      	lsl	x9, x25, x9
    33dc:      	ldrb	w10, [x23, #0x1b]
    33e0:      	add	x8, x8, x10
    33e4:      	add	x24, x9, x8
    33e8:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    33ec:      	ldr	x8, [x8]
    33f0:      	ldr	w8, [x8]
    33f4:      	cbnz	w8, 0x3e00 <perf_unwind_hotspot+0x3e00>
    33f8:      	str	x24, [sp, #0x50]
    33fc:      	cbz	x24, 0x17c <perf_unwind_hotspot+0x17c>
    3400:      	mov	w8, #0x200              // =512
    3404:      	mov	w9, #0x70               // =112
    3408:      	ldr	x0, [sp, #0x8]
    340c:      	mov	w1, #0x200              // =512
    3410:      	ldr	x2, [sp, #0x50]
    3414:      	blr	x9
    3418:      	adrp	x24, 0x3000 <perf_unwind_hotspot+0x3000>
    341c:      	ldr	x24, [x24]
    3420:      	cbnz	x0, 0x258 <perf_unwind_hotspot+0x258>
    3424:      	ldrh	w8, [x23, #0x10]
    3428:      	cmp	x8, #0x1f8
    342c:      	b.hi	0x3c4 <perf_unwind_hotspot+0x3c4>
    3430:      	ldrh	w9, [x23, #0x12]
    3434:      	cmp	x9, #0x1fc
    3438:      	b.hi	0x3c4 <perf_unwind_hotspot+0x3c4>
    343c:      	ldrh	w10, [x23, #0x14]
    3440:      	cmp	x10, #0x1f8
    3444:      	b.hi	0x3c4 <perf_unwind_hotspot+0x3c4>
    3448:      	ldrb	w11, [x23, #0x17]
    344c:      	ldr	x12, [sp, #0x8]
    3450:      	mov	w1, #0x4                // =4
    3454:      	ldr	x0, [sp, #0x40]
    3458:      	ldr	x11, [x12, x11]
    345c:      	str	x11, [sp, #0x58]
    3460:      	ldrb	w11, [x23, #0x18]
    3464:      	ldr	x11, [x12, x11]
    3468:      	str	x11, [sp, #0x60]
    346c:      	ldrb	w11, [x23, #0x1a]
    3470:      	ldr	w11, [x12, x11]
    3474:      	lsl	w11, w11, #3
    3478:      	str	w11, [sp, #0x78]
    347c:      	ldrb	w11, [x23, #0x19]
    3480:      	ldrh	w11, [x12, x11]
    3484:      	strh	w11, [sp, #0x80]
    3488:      	ldr	w9, [x12, x9]
    348c:      	str	w9, [sp, #0x7c]
    3490:      	ldr	w9, [x12, x10]
    3494:      	str	w9, [sp, #0x74]
    3498:      	mov	w9, #0x70               // =112
    349c:      	ldr	x8, [x12, x8]
    34a0:      	str	x8, [sp, #0x68]
    34a4:      	ldrb	w8, [x23, #0x16]
    34a8:      	ldr	x2, [x12, x8]
    34ac:      	mov	w8, #0x4                // =4
    34b0:      	blr	x9
    34b4:      	adrp	x24, 0x3000 <perf_unwind_hotspot+0x3000>
    34b8:      	ldr	x24, [x24]
    34bc:      	cbnz	x0, 0x258 <perf_unwind_hotspot+0x258>
    34c0:      	ldrb	w8, [x23, #0x21]
    34c4:      	cbz	w8, 0x34e0 <perf_unwind_hotspot+0x34e0>
    34c8:      	ldr	x8, [sp, #0x50]
    34cc:      	ldr	w9, [sp, #0x58]
    34d0:      	add	x9, x9, x8
    34d4:      	ldr	w10, [sp, #0x60]
    34d8:      	add	x8, x10, x8
    34dc:      	stp	x9, x8, [sp, #0x58]
    34e0:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    34e4:      	ldr	x8, [x8]
    34e8:      	ldr	w8, [x8]
    34ec:      	cbnz	w8, 0x40d4 <perf_unwind_hotspot+0x40d4>
    34f0:      	ldp	x25, x8, [sp, #0x50]
    34f4:      	sub	w9, w22, w8
    34f8:      	ldr	w19, [sp, #0x70]
    34fc:      	str	x9, [sp, #0x30]
    3500:      	mov	w9, #0x616d             // =24941
    3504:      	movk	w9, #0x6974, lsl #16
    3508:      	cmp	w19, w9
    350c:      	b.gt	0x3614 <perf_unwind_hotspot+0x3614>
    3510:      	mov	w8, #0x7476             // =29814
    3514:      	movk	w8, #0x6261, lsl #16
    3518:      	cmp	w19, w8
    351c:      	b.eq	0x36c8 <perf_unwind_hotspot+0x36c8>
    3520:      	mov	w8, #0x6e49             // =28233
    3524:      	movk	w8, #0x6574, lsl #16
    3528:      	cmp	w19, w8
    352c:      	b.ne	0x36f0 <perf_unwind_hotspot+0x36f0>
    3530:      	ldr	x8, [sp, #0x38]
    3534:      	cmp	x8, x29
    3538:      	b.lo	0x52c0 <perf_unwind_hotspot+0x52c0>
    353c:      	ldr	x9, [sp, #0x38]
    3540:      	add	x8, x29, #0x1, lsl #12  // =0x1000
    3544:      	cmp	x9, x8
    3548:      	b.hs	0x52c0 <perf_unwind_hotspot+0x52c0>
    354c:      	ldr	x8, [sp, #0x38]
    3550:      	mov	w9, #0x70               // =112
    3554:      	add	x10, sp, #0xc8
    3558:      	add	x0, sp, #0xc8
    355c:      	mov	w1, #0x60               // =96
    3560:      	sub	x2, x8, #0x50
    3564:      	mov	w8, #0x60               // =96
    3568:      	blr	x9
    356c:      	cbnz	x0, 0x51c <perf_unwind_hotspot+0x51c>
    3570:      	ldr	w9, [x21, #0x2c0]
    3574:      	ldr	x8, [sp, #0x20]
    3578:      	cbz	w9, 0x358c <perf_unwind_hotspot+0x358c>
    357c:      	ldrb	w8, [x23, #0x1f]
    3580:      	cmp	w8, #0x0
    3584:      	ldp	x9, x8, [sp, #0x10]
    3588:      	csel	x8, x9, x8, eq
    358c:      	ldr	x19, [x8]
    3590:      	add	x8, sp, #0xc8
    3594:      	mov	w10, #0x70              // =112
    3598:      	add	x11, sp, #0xc0
    359c:      	ldp	x29, x9, [x8, #0x48]
    35a0:      	ldr	x25, [x8, #0x38]
    35a4:      	add	x0, sp, #0xc0
    35a8:      	mov	w1, #0x8                // =8
    35ac:      	ldr	x24, [x8, #0x58]
    35b0:      	ldrb	w8, [x23, #0x1c]
    35b4:      	add	x8, x25, x8
    35b8:      	str	x9, [sp, #0x38]
    35bc:      	mov	w9, #0x8                // =8
    35c0:      	ldrb	w8, [x23, #0x1c]
    35c4:      	add	x2, x25, x8
    35c8:      	blr	x10
    35cc:      	cbnz	x0, 0xf20 <perf_unwind_hotspot+0xf20>
    35d0:      	ldr	x8, [sp, #0xc0]
    35d4:      	ldrb	w9, [x23, #0x1d]
    35d8:      	add	x9, x8, x9
    35dc:      	cmp	x19, x9
    35e0:      	csel	x9, xzr, x9, lo
    35e4:      	sub	x19, x19, x9
    35e8:      	adrp	x9, 0x3000 <perf_unwind_hotspot+0x3000>
    35ec:      	ldr	x9, [x9]
    35f0:      	ldr	w9, [x9]
    35f4:      	cbnz	w9, 0x4180 <perf_unwind_hotspot+0x4180>
    35f8:      	mov	w9, #0xffff             // =65535
    35fc:      	mov	x22, #0x2000000000000000 // =2305843009213693952
    3600:      	cmp	x19, x9
    3604:      	csel	x9, x19, x9, lo
    3608:      	lsr	x19, x8, #3
    360c:      	str	x9, [sp, #0x30]
    3610:      	b	0x4580 <perf_unwind_hotspot+0x4580>
    3614:      	mov	w9, #0x616e             // =24942
    3618:      	movk	w9, #0x6974, lsl #16
    361c:      	cmp	w19, w9
    3620:      	b.eq	0x3634 <perf_unwind_hotspot+0x3634>
    3624:      	mov	w9, #0x6d6e             // =28014
    3628:      	movk	w9, #0x7465, lsl #16
    362c:      	cmp	w19, w9
    3630:      	b.ne	0x36f0 <perf_unwind_hotspot+0x36f0>
    3634:      	ldr	x9, [sp, #0x68]
    3638:      	ldrb	w10, [x23, #0x21]
    363c:      	add	x11, x25, w9, uxtw
    3640:      	ldr	w19, [sp, #0x7c]
    3644:      	cmp	w10, #0x0
    3648:      	csel	x9, x9, x11, eq
    364c:      	cmp	x22, x9
    3650:      	b.ne	0x3694 <perf_unwind_hotspot+0x3694>
    3654:      	ldr	w8, [sp, #0x74]
    3658:      	mov	w9, #0x8                // =8
    365c:      	mov	w10, #0x70              // =112
    3660:      	add	x11, sp, #0x88
    3664:      	add	x0, sp, #0x88
    3668:      	mov	w1, #0x8                // =8
    366c:      	add	x8, x29, x8
    3670:      	ldr	w8, [sp, #0x74]
    3674:      	add	x2, x29, x8
    3678:      	blr	x10
    367c:      	cbz	x0, 0x3d9c <perf_unwind_hotspot+0x3d9c>
    3680:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3684:      	ldr	x8, [x8]
    3688:      	ldr	w8, [x8]
    368c:      	cbnz	w8, 0x41d4 <perf_unwind_hotspot+0x41d4>
    3690:      	ldr	x8, [sp, #0x58]
    3694:      	ldrh	w9, [sp, #0x80]
    3698:      	add	x8, x8, x9
    369c:      	cmp	x22, x8
    36a0:      	b.hs	0x3718 <perf_unwind_hotspot+0x3718>
    36a4:      	sub	x8, x8, #0x4
    36a8:      	cmp	x22, x8
    36ac:      	b.ne	0x3d3c <perf_unwind_hotspot+0x3d3c>
    36b0:      	ldr	w8, [sp, #0x78]
    36b4:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    36b8:      	add	x29, x29, x8
    36bc:      	ldrb	w8, [x21, #0xf21]
    36c0:      	cbnz	w8, 0x7bc <perf_unwind_hotspot+0x7bc>
    36c4:      	b	0x3df8 <perf_unwind_hotspot+0x3df8>
    36c8:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    36cc:      	mov	w19, #0x7476            // =29814
    36d0:      	ldr	x8, [x8]
    36d4:      	movk	w19, #0x6261, lsl #16
    36d8:      	ldr	w8, [x8]
    36dc:      	cbnz	w8, 0x4218 <perf_unwind_hotspot+0x4218>
    36e0:      	mov	x22, #0x1000000000000000 // =1152921504606846976
    36e4:      	ldrb	w8, [x21, #0xf21]
    36e8:      	cbnz	w8, 0x7bc <perf_unwind_hotspot+0x7bc>
    36ec:      	b	0x3df8 <perf_unwind_hotspot+0x3df8>
    36f0:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    36f4:      	ldr	x24, [x21, #0xf00]
    36f8:      	ldr	x8, [x8]
    36fc:      	ldr	w8, [x8]
    3700:      	tbnz	x24, #0x3f, 0x3dd8 <perf_unwind_hotspot+0x3dd8>
    3704:      	cbnz	w8, 0x425c <perf_unwind_hotspot+0x425c>
    3708:      	ldr	w8, [sp, #0x78]
    370c:      	mov	x22, xzr
    3710:      	cbnz	w8, 0x4534 <perf_unwind_hotspot+0x4534>
    3714:      	b	0x4528 <perf_unwind_hotspot+0x4528>
    3718:      	ldr	x8, [sp, #0x38]
    371c:      	subs	x2, x8, x29
    3720:      	b.lo	0x3c90 <perf_unwind_hotspot+0x3c90>
    3724:      	ldr	w8, [sp, #0x78]
    3728:      	ldr	x9, [sp, #0x38]
    372c:      	add	x8, x29, x8
    3730:      	add	x8, x8, #0x30
    3734:      	cmp	x9, x8
    3738:      	b.hs	0x3c90 <perf_unwind_hotspot+0x3c90>
    373c:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3740:      	ldr	x8, [x8]
    3744:      	ldr	w8, [x8]
    3748:      	cbnz	w8, 0x42b0 <perf_unwind_hotspot+0x42b0>
    374c:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    3750:      	b	0x4528 <perf_unwind_hotspot+0x4528>
    3754:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3758:      	add	x8, x8, #0x0
    375c:      	add	x12, sp, #0xc8
    3760:      	ldp	x9, x10, [x8, #0x10]
    3764:      	ldr	x11, [x8, #0x20]
    3768:      	add	x0, sp, #0xc8
    376c:      	mov	w1, #0x2e               // =46
    3770:      	stp	x10, x11, [x12, #0x18]
    3774:      	ldur	x10, [x8, #0x26]
    3778:      	stur	x10, [x12, #0x26]
    377c:      	ldp	x10, x8, [x8]
    3780:      	str	x10, [sp, #0xc8]
    3784:      	stp	x8, x9, [x12, #0x8]
    3788:      	mov	w8, #0x2e               // =46
    378c:      	mov	w9, #0x6                // =6
    3790:      	add	x10, sp, #0xc8
    3794:      	ldr	w2, [sp, #0x50]
    3798:      	blr	x9
    379c:      	b	0x32dc <perf_unwind_hotspot+0x32dc>
    37a0:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    37a4:      	add	x8, x8, #0x0
    37a8:      	add	x11, sp, #0xc8
    37ac:      	ldp	x9, x10, [x8]
    37b0:      	add	x0, sp, #0xc8
    37b4:      	mov	w1, #0x1d               // =29
    37b8:      	mov	x2, x25
    37bc:      	str	x9, [sp, #0xc8]
    37c0:      	ldr	x9, [x8, #0x10]
    37c4:      	ldur	x8, [x8, #0x15]
    37c8:      	stp	x10, x9, [x11, #0x8]
    37cc:      	mov	w9, #0x6                // =6
    37d0:      	stur	x8, [x11, #0x15]
    37d4:      	mov	w8, #0x1d               // =29
    37d8:      	add	x10, sp, #0xc8
    37dc:      	ldrb	w3, [sp, #0x88]
    37e0:      	blr	x9
    37e4:      	ldrb	w8, [sp, #0x88]
    37e8:      	add	w9, w8, #0x1
    37ec:      	and	w9, w9, #0xff
    37f0:      	cmp	w9, #0x2
    37f4:      	b.lo	0x33cc <perf_unwind_hotspot+0x33cc>
    37f8:      	sub	x25, x25, x8
    37fc:      	mov	w8, #0x1                // =1
    3800:      	mov	w9, #0x70               // =112
    3804:      	add	x10, sp, #0x88
    3808:      	add	x0, sp, #0x88
    380c:      	mov	w1, #0x1                // =1
    3810:      	add	x2, x25, x19
    3814:      	blr	x9
    3818:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    381c:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3820:      	ldr	x8, [x8]
    3824:      	ldr	w8, [x8]
    3828:      	cbnz	w8, 0x3e4c <perf_unwind_hotspot+0x3e4c>
    382c:      	ldrb	w9, [sp, #0x88]
    3830:      	add	w8, w9, #0x1
    3834:      	and	w8, w8, #0xff
    3838:      	cmp	w8, #0x2
    383c:      	mov	w8, w9
    3840:      	b.lo	0x33cc <perf_unwind_hotspot+0x33cc>
    3844:      	sub	x25, x25, x9
    3848:      	mov	w8, #0x1                // =1
    384c:      	mov	w9, #0x70               // =112
    3850:      	add	x10, sp, #0x88
    3854:      	add	x0, sp, #0x88
    3858:      	mov	w1, #0x1                // =1
    385c:      	add	x2, x25, x19
    3860:      	blr	x9
    3864:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    3868:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    386c:      	ldr	x8, [x8]
    3870:      	ldr	w8, [x8]
    3874:      	cbnz	w8, 0x3f58 <perf_unwind_hotspot+0x3f58>
    3878:      	ldrb	w9, [sp, #0x88]
    387c:      	add	w8, w9, #0x1
    3880:      	and	w8, w8, #0xff
    3884:      	cmp	w8, #0x2
    3888:      	mov	w8, w9
    388c:      	b.lo	0x33cc <perf_unwind_hotspot+0x33cc>
    3890:      	sub	x25, x25, x9
    3894:      	mov	w8, #0x1                // =1
    3898:      	mov	w9, #0x70               // =112
    389c:      	add	x10, sp, #0x88
    38a0:      	add	x0, sp, #0x88
    38a4:      	mov	w1, #0x1                // =1
    38a8:      	add	x2, x25, x19
    38ac:      	blr	x9
    38b0:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    38b4:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    38b8:      	ldr	x8, [x8]
    38bc:      	ldr	w8, [x8]
    38c0:      	cbnz	w8, 0x42fc <perf_unwind_hotspot+0x42fc>
    38c4:      	ldrb	w9, [sp, #0x88]
    38c8:      	add	w8, w9, #0x1
    38cc:      	and	w8, w8, #0xff
    38d0:      	cmp	w8, #0x2
    38d4:      	mov	w8, w9
    38d8:      	b.lo	0x33cc <perf_unwind_hotspot+0x33cc>
    38dc:      	sub	x25, x25, x9
    38e0:      	mov	w8, #0x1                // =1
    38e4:      	mov	w9, #0x70               // =112
    38e8:      	add	x10, sp, #0x88
    38ec:      	add	x0, sp, #0x88
    38f0:      	mov	w1, #0x1                // =1
    38f4:      	add	x2, x25, x19
    38f8:      	blr	x9
    38fc:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    3900:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3904:      	ldr	x8, [x8]
    3908:      	ldr	w8, [x8]
    390c:      	cbnz	w8, 0x435c <perf_unwind_hotspot+0x435c>
    3910:      	ldrb	w9, [sp, #0x88]
    3914:      	add	w8, w9, #0x1
    3918:      	and	w8, w8, #0xff
    391c:      	cmp	w8, #0x2
    3920:      	mov	w8, w9
    3924:      	b.lo	0x33cc <perf_unwind_hotspot+0x33cc>
    3928:      	sub	x25, x25, x9
    392c:      	mov	w8, #0x1                // =1
    3930:      	mov	w9, #0x70               // =112
    3934:      	add	x10, sp, #0x88
    3938:      	add	x0, sp, #0x88
    393c:      	mov	w1, #0x1                // =1
    3940:      	add	x2, x25, x19
    3944:      	blr	x9
    3948:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    394c:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3950:      	ldr	x8, [x8]
    3954:      	ldr	w8, [x8]
    3958:      	cbnz	w8, 0x43bc <perf_unwind_hotspot+0x43bc>
    395c:      	ldrb	w9, [sp, #0x88]
    3960:      	add	w8, w9, #0x1
    3964:      	and	w8, w8, #0xff
    3968:      	cmp	w8, #0x2
    396c:      	mov	w8, w9
    3970:      	b.lo	0x33cc <perf_unwind_hotspot+0x33cc>
    3974:      	sub	x25, x25, x9
    3978:      	mov	w8, #0x1                // =1
    397c:      	mov	w9, #0x70               // =112
    3980:      	add	x10, sp, #0x88
    3984:      	add	x0, sp, #0x88
    3988:      	mov	w1, #0x1                // =1
    398c:      	add	x2, x25, x19
    3990:      	blr	x9
    3994:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    3998:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    399c:      	ldr	x8, [x8]
    39a0:      	ldr	w8, [x8]
    39a4:      	cbnz	w8, 0x441c <perf_unwind_hotspot+0x441c>
    39a8:      	ldrb	w9, [sp, #0x88]
    39ac:      	add	w8, w9, #0x1
    39b0:      	and	w8, w8, #0xff
    39b4:      	cmp	w8, #0x2
    39b8:      	mov	w8, w9
    39bc:      	b.lo	0x33cc <perf_unwind_hotspot+0x33cc>
    39c0:      	sub	x25, x25, x9
    39c4:      	mov	w8, #0x1                // =1
    39c8:      	mov	w9, #0x70               // =112
    39cc:      	add	x10, sp, #0x88
    39d0:      	add	x0, sp, #0x88
    39d4:      	mov	w1, #0x1                // =1
    39d8:      	add	x2, x25, x19
    39dc:      	blr	x9
    39e0:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    39e4:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    39e8:      	ldr	x8, [x8]
    39ec:      	ldr	w8, [x8]
    39f0:      	cbz	w8, 0x3a38 <perf_unwind_hotspot+0x3a38>
    39f4:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    39f8:      	add	x8, x8, #0x0
    39fc:      	add	x11, sp, #0xc8
    3a00:      	ldp	x9, x10, [x8]
    3a04:      	add	x0, sp, #0xc8
    3a08:      	mov	w1, #0x1d               // =29
    3a0c:      	mov	x2, x25
    3a10:      	str	x9, [sp, #0xc8]
    3a14:      	ldr	x9, [x8, #0x10]
    3a18:      	ldur	x8, [x8, #0x15]
    3a1c:      	stp	x10, x9, [x11, #0x8]
    3a20:      	mov	w9, #0x6                // =6
    3a24:      	stur	x8, [x11, #0x15]
    3a28:      	mov	w8, #0x1d               // =29
    3a2c:      	add	x10, sp, #0xc8
    3a30:      	ldrb	w3, [sp, #0x88]
    3a34:      	blr	x9
    3a38:      	ldrb	w9, [sp, #0x88]
    3a3c:      	add	w8, w9, #0x1
    3a40:      	and	w8, w8, #0xff
    3a44:      	cmp	w8, #0x2
    3a48:      	mov	w8, w9
    3a4c:      	b.lo	0x33cc <perf_unwind_hotspot+0x33cc>
    3a50:      	sub	x25, x25, x9
    3a54:      	mov	w8, #0x1                // =1
    3a58:      	mov	w9, #0x70               // =112
    3a5c:      	add	x10, sp, #0x88
    3a60:      	add	x0, sp, #0x88
    3a64:      	mov	w1, #0x1                // =1
    3a68:      	add	x2, x25, x19
    3a6c:      	blr	x9
    3a70:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    3a74:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3a78:      	ldr	x8, [x8]
    3a7c:      	ldr	w8, [x8]
    3a80:      	cbz	w8, 0x3ac8 <perf_unwind_hotspot+0x3ac8>
    3a84:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3a88:      	add	x8, x8, #0x0
    3a8c:      	add	x11, sp, #0xc8
    3a90:      	ldp	x9, x10, [x8]
    3a94:      	add	x0, sp, #0xc8
    3a98:      	mov	w1, #0x1d               // =29
    3a9c:      	mov	x2, x25
    3aa0:      	str	x9, [sp, #0xc8]
    3aa4:      	ldr	x9, [x8, #0x10]
    3aa8:      	ldur	x8, [x8, #0x15]
    3aac:      	stp	x10, x9, [x11, #0x8]
    3ab0:      	mov	w9, #0x6                // =6
    3ab4:      	stur	x8, [x11, #0x15]
    3ab8:      	mov	w8, #0x1d               // =29
    3abc:      	add	x10, sp, #0xc8
    3ac0:      	ldrb	w3, [sp, #0x88]
    3ac4:      	blr	x9
    3ac8:      	ldrb	w9, [sp, #0x88]
    3acc:      	add	w8, w9, #0x1
    3ad0:      	and	w8, w8, #0xff
    3ad4:      	cmp	w8, #0x2
    3ad8:      	mov	w8, w9
    3adc:      	b.lo	0x33cc <perf_unwind_hotspot+0x33cc>
    3ae0:      	sub	x25, x25, x9
    3ae4:      	mov	w8, #0x1                // =1
    3ae8:      	mov	w9, #0x70               // =112
    3aec:      	add	x10, sp, #0x88
    3af0:      	add	x0, sp, #0x88
    3af4:      	mov	w1, #0x1                // =1
    3af8:      	add	x2, x25, x19
    3afc:      	blr	x9
    3b00:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    3b04:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3b08:      	ldr	x8, [x8]
    3b0c:      	ldr	w8, [x8]
    3b10:      	cbz	w8, 0x3b58 <perf_unwind_hotspot+0x3b58>
    3b14:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3b18:      	add	x8, x8, #0x0
    3b1c:      	add	x11, sp, #0xc8
    3b20:      	ldp	x9, x10, [x8]
    3b24:      	add	x0, sp, #0xc8
    3b28:      	mov	w1, #0x1d               // =29
    3b2c:      	mov	x2, x25
    3b30:      	str	x9, [sp, #0xc8]
    3b34:      	ldr	x9, [x8, #0x10]
    3b38:      	ldur	x8, [x8, #0x15]
    3b3c:      	stp	x10, x9, [x11, #0x8]
    3b40:      	mov	w9, #0x6                // =6
    3b44:      	stur	x8, [x11, #0x15]
    3b48:      	mov	w8, #0x1d               // =29
    3b4c:      	add	x10, sp, #0xc8
    3b50:      	ldrb	w3, [sp, #0x88]
    3b54:      	blr	x9
    3b58:      	ldrb	w9, [sp, #0x88]
    3b5c:      	add	w8, w9, #0x1
    3b60:      	and	w8, w8, #0xff
    3b64:      	cmp	w8, #0x2
    3b68:      	mov	w8, w9
    3b6c:      	b.lo	0x33cc <perf_unwind_hotspot+0x33cc>
    3b70:      	sub	x25, x25, x9
    3b74:      	mov	w8, #0x1                // =1
    3b78:      	mov	w9, #0x70               // =112
    3b7c:      	add	x10, sp, #0x88
    3b80:      	add	x0, sp, #0x88
    3b84:      	mov	w1, #0x1                // =1
    3b88:      	add	x2, x25, x19
    3b8c:      	blr	x9
    3b90:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    3b94:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3b98:      	ldr	x8, [x8]
    3b9c:      	ldr	w8, [x8]
    3ba0:      	cbz	w8, 0x3be8 <perf_unwind_hotspot+0x3be8>
    3ba4:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3ba8:      	add	x8, x8, #0x0
    3bac:      	add	x11, sp, #0xc8
    3bb0:      	ldp	x9, x10, [x8]
    3bb4:      	add	x0, sp, #0xc8
    3bb8:      	mov	w1, #0x1d               // =29
    3bbc:      	mov	x2, x25
    3bc0:      	str	x9, [sp, #0xc8]
    3bc4:      	ldr	x9, [x8, #0x10]
    3bc8:      	ldur	x8, [x8, #0x15]
    3bcc:      	stp	x10, x9, [x11, #0x8]
    3bd0:      	mov	w9, #0x6                // =6
    3bd4:      	stur	x8, [x11, #0x15]
    3bd8:      	mov	w8, #0x1d               // =29
    3bdc:      	add	x10, sp, #0xc8
    3be0:      	ldrb	w3, [sp, #0x88]
    3be4:      	blr	x9
    3be8:      	ldrb	w9, [sp, #0x88]
    3bec:      	add	w8, w9, #0x1
    3bf0:      	and	w8, w8, #0xff
    3bf4:      	cmp	w8, #0x2
    3bf8:      	mov	w8, w9
    3bfc:      	b.lo	0x33cc <perf_unwind_hotspot+0x33cc>
    3c00:      	sub	x25, x25, x9
    3c04:      	mov	w8, #0x1                // =1
    3c08:      	mov	w9, #0x70               // =112
    3c0c:      	add	x10, sp, #0x88
    3c10:      	add	x0, sp, #0x88
    3c14:      	mov	w1, #0x1                // =1
    3c18:      	add	x2, x25, x19
    3c1c:      	blr	x9
    3c20:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    3c24:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3c28:      	ldr	x8, [x8]
    3c2c:      	ldr	w8, [x8]
    3c30:      	cbz	w8, 0x3c78 <perf_unwind_hotspot+0x3c78>
    3c34:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3c38:      	add	x8, x8, #0x0
    3c3c:      	add	x11, sp, #0xc8
    3c40:      	ldp	x9, x10, [x8]
    3c44:      	add	x0, sp, #0xc8
    3c48:      	mov	w1, #0x1d               // =29
    3c4c:      	mov	x2, x25
    3c50:      	str	x9, [sp, #0xc8]
    3c54:      	ldr	x9, [x8, #0x10]
    3c58:      	ldur	x8, [x8, #0x15]
    3c5c:      	stp	x10, x9, [x11, #0x8]
    3c60:      	mov	w9, #0x6                // =6
    3c64:      	stur	x8, [x11, #0x15]
    3c68:      	mov	w8, #0x1d               // =29
    3c6c:      	add	x10, sp, #0xc8
    3c70:      	ldrb	w3, [sp, #0x88]
    3c74:      	blr	x9
    3c78:      	ldrb	w8, [sp, #0x88]
    3c7c:      	add	w9, w8, #0x1
    3c80:      	and	w9, w9, #0xff
    3c84:      	cmp	w9, #0x1
    3c88:      	b.hi	0x178 <perf_unwind_hotspot+0x178>
    3c8c:      	b	0x33cc <perf_unwind_hotspot+0x33cc>
    3c90:      	sub	x2, x22, #0x8
    3c94:      	mov	w8, #0x8                // =8
    3c98:      	mov	w9, #0x70               // =112
    3c9c:      	add	x10, sp, #0xc8
    3ca0:      	add	x0, sp, #0xc8
    3ca4:      	mov	w1, #0x8                // =8
    3ca8:      	blr	x9
    3cac:      	ldr	x8, [sp, #0xc8]
    3cb0:      	mov	x9, #0x27ff             // =10239
    3cb4:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    3cb8:      	movk	x9, #0xa9bf, lsl #16
    3cbc:      	movk	x9, #0x100, lsl #32
    3cc0:      	movk	x9, #0xd63f, lsl #48
    3cc4:      	cmp	x8, x9
    3cc8:      	add	x8, x29, #0x10
    3ccc:      	ccmp	x0, #0x0, #0x0, eq
    3cd0:      	csel	x29, x8, x29, eq
    3cd4:      	ldr	w8, [sp, #0x78]
    3cd8:      	b	0x4534 <perf_unwind_hotspot+0x4534>
    3cdc:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3ce0:      	add	x8, x8, #0x0
    3ce4:      	add	x11, sp, #0xc8
    3ce8:      	ldp	x9, x10, [x8]
    3cec:      	add	x0, sp, #0xc8
    3cf0:      	mov	w1, #0x1d               // =29
    3cf4:      	mov	x2, x25
    3cf8:      	str	x9, [sp, #0xc8]
    3cfc:      	ldr	x9, [x8, #0x10]
    3d00:      	ldur	x8, [x8, #0x15]
    3d04:      	stp	x10, x9, [x11, #0x8]
    3d08:      	mov	w9, #0x6                // =6
    3d0c:      	stur	x8, [x11, #0x15]
    3d10:      	mov	w8, #0x1d               // =29
    3d14:      	add	x10, sp, #0xc8
    3d18:      	ldrb	w3, [sp, #0x88]
    3d1c:      	blr	x9
    3d20:      	ldrb	w9, [sp, #0x88]
    3d24:      	add	w8, w9, #0x1
    3d28:      	and	w8, w8, #0xff
    3d2c:      	cmp	w8, #0x2
    3d30:      	mov	w8, w9
    3d34:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    3d38:      	b	0x2368 <perf_unwind_hotspot+0x2368>
    3d3c:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    3d40:      	ldrb	w8, [x21, #0xf21]
    3d44:      	cbnz	w8, 0x7bc <perf_unwind_hotspot+0x7bc>
    3d48:      	b	0x3df8 <perf_unwind_hotspot+0x3df8>
    3d4c:      	mov	w8, #0x656e             // =25966
    3d50:      	add	x11, sp, #0xc8
    3d54:      	add	x0, sp, #0xc8
    3d58:      	mov	w1, #0x1b               // =27
    3d5c:      	movk	w8, #0xa, lsl #16
    3d60:      	stur	w8, [x11, #0x17]
    3d64:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3d68:      	add	x8, x8, #0x0
    3d6c:      	ldp	x9, x10, [x8]
    3d70:      	ldr	x8, [x8, #0x10]
    3d74:      	str	x9, [sp, #0xc8]
    3d78:      	mov	w9, #0x6                // =6
    3d7c:      	stp	x10, x8, [x11, #0x8]
    3d80:      	mov	w8, #0x1b               // =27
    3d84:      	add	x10, sp, #0xc8
    3d88:      	blr	x9
    3d8c:      	mov	w25, #0x1               // =1
    3d90:      	cmp	w25, #0x2
    3d94:      	b.eq	0x32ac <perf_unwind_hotspot+0x32ac>
    3d98:      	b	0x6074 <perf_unwind_hotspot+0x6074>
    3d9c:      	ldr	x9, [sp, #0x88]
    3da0:      	ldr	x8, [sp, #0x58]
    3da4:      	cmp	x9, x8
    3da8:      	b.lo	0x3680 <perf_unwind_hotspot+0x3680>
    3dac:      	ldr	x10, [sp, #0x60]
    3db0:      	cmp	x9, x10
    3db4:      	b.hs	0x3680 <perf_unwind_hotspot+0x3680>
    3db8:      	adrp	x10, 0x3000 <perf_unwind_hotspot+0x3000>
    3dbc:      	ldr	x10, [x10]
    3dc0:      	ldr	w10, [x10]
    3dc4:      	cbnz	w10, 0x447c <perf_unwind_hotspot+0x447c>
    3dc8:      	mov	x22, x9
    3dcc:      	sub	w8, w22, w8
    3dd0:      	str	x8, [sp, #0x30]
    3dd4:      	b	0x3690 <perf_unwind_hotspot+0x3690>
    3dd8:      	cbnz	w8, 0x44d8 <perf_unwind_hotspot+0x44d8>
    3ddc:      	mov	x22, xzr
    3de0:      	tbnz	x24, #0x3e, 0x4528 <perf_unwind_hotspot+0x4528>
    3de4:      	lsr	x8, x24, #53
    3de8:      	and	x8, x8, #0x1f8
    3dec:      	add	x29, x8, x29
    3df0:      	ldrb	w8, [x21, #0xf21]
    3df4:      	cbnz	w8, 0x7bc <perf_unwind_hotspot+0x7bc>
    3df8:      	ldr	x24, [x21, #0xee8]
    3dfc:      	b	0x4580 <perf_unwind_hotspot+0x4580>
    3e00:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3e04:      	add	x8, x8, #0x0
    3e08:      	add	x11, sp, #0xc8
    3e0c:      	strb	wzr, [sp, #0xe8]
    3e10:      	ldp	x9, x10, [x8]
    3e14:      	add	x0, sp, #0xc8
    3e18:      	mov	w1, #0x21               // =33
    3e1c:      	mov	x2, x24
    3e20:      	str	x9, [sp, #0xc8]
    3e24:      	ldp	x9, x8, [x8, #0x10]
    3e28:      	str	x8, [x11, #0x18]
    3e2c:      	stp	x10, x9, [x11, #0x8]
    3e30:      	mov	w8, #0x21               // =33
    3e34:      	mov	w9, #0x6                // =6
    3e38:      	add	x10, sp, #0xc8
    3e3c:      	blr	x9
    3e40:      	str	x24, [sp, #0x50]
    3e44:      	cbnz	x24, 0x3400 <perf_unwind_hotspot+0x3400>
    3e48:      	b	0x17c <perf_unwind_hotspot+0x17c>
    3e4c:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3e50:      	add	x8, x8, #0x0
    3e54:      	add	x11, sp, #0xc8
    3e58:      	ldp	x9, x10, [x8]
    3e5c:      	add	x0, sp, #0xc8
    3e60:      	mov	w1, #0x1d               // =29
    3e64:      	mov	x2, x25
    3e68:      	str	x9, [sp, #0xc8]
    3e6c:      	ldr	x9, [x8, #0x10]
    3e70:      	ldur	x8, [x8, #0x15]
    3e74:      	stp	x10, x9, [x11, #0x8]
    3e78:      	mov	w9, #0x6                // =6
    3e7c:      	stur	x8, [x11, #0x15]
    3e80:      	mov	w8, #0x1d               // =29
    3e84:      	add	x10, sp, #0xc8
    3e88:      	ldrb	w3, [sp, #0x88]
    3e8c:      	blr	x9
    3e90:      	ldrb	w9, [sp, #0x88]
    3e94:      	add	w8, w9, #0x1
    3e98:      	and	w8, w8, #0xff
    3e9c:      	cmp	w8, #0x2
    3ea0:      	mov	w8, w9
    3ea4:      	b.lo	0x33cc <perf_unwind_hotspot+0x33cc>
    3ea8:      	b	0x3844 <perf_unwind_hotspot+0x3844>
    3eac:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3eb0:      	add	x8, x8, #0x0
    3eb4:      	add	x11, sp, #0xc8
    3eb8:      	ldp	x9, x10, [x8]
    3ebc:      	add	x0, sp, #0xc8
    3ec0:      	mov	w1, #0x1d               // =29
    3ec4:      	mov	x2, x25
    3ec8:      	str	x9, [sp, #0xc8]
    3ecc:      	ldr	x9, [x8, #0x10]
    3ed0:      	ldur	x8, [x8, #0x15]
    3ed4:      	stp	x10, x9, [x11, #0x8]
    3ed8:      	mov	w9, #0x6                // =6
    3edc:      	stur	x8, [x11, #0x15]
    3ee0:      	mov	w8, #0x1d               // =29
    3ee4:      	add	x10, sp, #0xc8
    3ee8:      	ldrb	w3, [sp, #0x88]
    3eec:      	blr	x9
    3ef0:      	ldrb	w9, [sp, #0x88]
    3ef4:      	add	w8, w9, #0x1
    3ef8:      	and	w8, w8, #0xff
    3efc:      	cmp	w8, #0x2
    3f00:      	mov	w8, w9
    3f04:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    3f08:      	b	0x23b4 <perf_unwind_hotspot+0x23b4>
    3f0c:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3f10:      	add	x8, x8, #0x0
    3f14:      	add	x12, sp, #0xc8
    3f18:      	ldp	x9, x10, [x8, #0x10]
    3f1c:      	ldr	x11, [x8, #0x20]
    3f20:      	add	x0, sp, #0xc8
    3f24:      	mov	w1, #0x2e               // =46
    3f28:      	stp	x10, x11, [x12, #0x18]
    3f2c:      	ldur	x10, [x8, #0x26]
    3f30:      	stur	x10, [x12, #0x26]
    3f34:      	ldp	x10, x8, [x8]
    3f38:      	str	x10, [sp, #0xc8]
    3f3c:      	stp	x8, x9, [x12, #0x8]
    3f40:      	mov	w8, #0x2e               // =46
    3f44:      	mov	w9, #0x6                // =6
    3f48:      	add	x10, sp, #0xc8
    3f4c:      	ldr	w2, [sp, #0x88]
    3f50:      	blr	x9
    3f54:      	b	0x32a0 <perf_unwind_hotspot+0x32a0>
    3f58:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3f5c:      	add	x8, x8, #0x0
    3f60:      	add	x11, sp, #0xc8
    3f64:      	ldp	x9, x10, [x8]
    3f68:      	add	x0, sp, #0xc8
    3f6c:      	mov	w1, #0x1d               // =29
    3f70:      	mov	x2, x25
    3f74:      	str	x9, [sp, #0xc8]
    3f78:      	ldr	x9, [x8, #0x10]
    3f7c:      	ldur	x8, [x8, #0x15]
    3f80:      	stp	x10, x9, [x11, #0x8]
    3f84:      	mov	w9, #0x6                // =6
    3f88:      	stur	x8, [x11, #0x15]
    3f8c:      	mov	w8, #0x1d               // =29
    3f90:      	add	x10, sp, #0xc8
    3f94:      	ldrb	w3, [sp, #0x88]
    3f98:      	blr	x9
    3f9c:      	ldrb	w9, [sp, #0x88]
    3fa0:      	add	w8, w9, #0x1
    3fa4:      	and	w8, w8, #0xff
    3fa8:      	cmp	w8, #0x2
    3fac:      	mov	w8, w9
    3fb0:      	b.lo	0x33cc <perf_unwind_hotspot+0x33cc>
    3fb4:      	b	0x3890 <perf_unwind_hotspot+0x3890>
    3fb8:      	adrp	x8, 0x3000 <perf_unwind_hotspot+0x3000>
    3fbc:      	add	x8, x8, #0x0
    3fc0:      	add	x11, sp, #0xc8
    3fc4:      	ldp	x9, x10, [x8]
    3fc8:      	add	x0, sp, #0xc8
    3fcc:      	mov	w1, #0x1d               // =29
    3fd0:      	mov	x2, x25
    3fd4:      	str	x9, [sp, #0xc8]
    3fd8:      	ldr	x9, [x8, #0x10]
    3fdc:      	ldur	x8, [x8, #0x15]
    3fe0:      	stp	x10, x9, [x11, #0x8]
    3fe4:      	mov	w9, #0x6                // =6
    3fe8:      	stur	x8, [x11, #0x15]
    3fec:      	mov	w8, #0x1d               // =29
    3ff0:      	add	x10, sp, #0xc8
    3ff4:      	ldrb	w3, [sp, #0x88]
    3ff8:      	blr	x9
    3ffc:      	ldrb	w9, [sp, #0x88]
    4000:      	add	w8, w9, #0x1
    4004:      	and	w8, w8, #0xff
    4008:      	cmp	w8, #0x2
    400c:      	mov	w8, w9
    4010:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    4014:      	b	0x2400 <perf_unwind_hotspot+0x2400>
    4018:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    401c:      	add	x8, x8, #0x0
    4020:      	add	x11, sp, #0xc8
    4024:      	ldp	x9, x10, [x8]
    4028:      	add	x0, sp, #0xc8
    402c:      	mov	w1, #0x1d               // =29
    4030:      	mov	x2, x25
    4034:      	str	x9, [sp, #0xc8]
    4038:      	ldr	x9, [x8, #0x10]
    403c:      	ldur	x8, [x8, #0x15]
    4040:      	stp	x10, x9, [x11, #0x8]
    4044:      	mov	w9, #0x6                // =6
    4048:      	stur	x8, [x11, #0x15]
    404c:      	mov	w8, #0x1d               // =29
    4050:      	add	x10, sp, #0xc8
    4054:      	ldrb	w3, [sp, #0x88]
    4058:      	blr	x9
    405c:      	ldrb	w9, [sp, #0x88]
    4060:      	add	w8, w9, #0x1
    4064:      	and	w8, w8, #0xff
    4068:      	cmp	w8, #0x2
    406c:      	mov	w8, w9
    4070:      	b.lo	0x19f0 <perf_unwind_hotspot+0x19f0>
    4074:      	b	0x244c <perf_unwind_hotspot+0x244c>
    4078:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    407c:      	add	x8, x8, #0x0
    4080:      	add	x11, sp, #0xc8
    4084:      	ldp	x9, x10, [x8]
    4088:      	add	x0, sp, #0xc8
    408c:      	mov	w1, #0x1d               // =29
    4090:      	mov	x2, x25
    4094:      	str	x9, [sp, #0xc8]
    4098:      	ldr	x9, [x8, #0x10]
    409c:      	ldur	x8, [x8, #0x15]
    40a0:      	stp	x10, x9, [x11, #0x8]
    40a4:      	mov	w9, #0x6                // =6
    40a8:      	stur	x8, [x11, #0x15]
    40ac:      	mov	w8, #0x1d               // =29
    40b0:      	add	x10, sp, #0xc8
    40b4:      	ldrb	w3, [sp, #0x88]
    40b8:      	blr	x9
    40bc:      	ldrb	w8, [sp, #0x88]
    40c0:      	add	w9, w8, #0x1
    40c4:      	and	w9, w9, #0xff
    40c8:      	cmp	w9, #0x1
    40cc:      	b.hi	0x178 <perf_unwind_hotspot+0x178>
    40d0:      	b	0x19f0 <perf_unwind_hotspot+0x19f0>
    40d4:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    40d8:      	add	x8, x8, #0x0
    40dc:      	add	x0, sp, #0xc8
    40e0:      	ldp	x9, x10, [x8]
    40e4:      	ldur	x8, [x8, #0xf]
    40e8:      	mov	w1, #0x17               // =23
    40ec:      	str	x9, [sp, #0xc8]
    40f0:      	add	x9, sp, #0xc8
    40f4:      	str	x10, [x9, #0x8]
    40f8:      	stur	x8, [x9, #0xf]
    40fc:      	mov	w8, #0x17               // =23
    4100:      	mov	w9, #0x6                // =6
    4104:      	add	x10, sp, #0xc8
    4108:      	ldp	x2, x3, [sp, #0x58]
    410c:      	blr	x9
    4110:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4114:      	ldr	x8, [x8]
    4118:      	ldr	w8, [x8]
    411c:      	cbz	w8, 0x34f0 <perf_unwind_hotspot+0x34f0>
    4120:      	mov	w8, #0x7825             // =30757
    4124:      	add	x13, sp, #0xc8
    4128:      	add	x0, sp, #0xc8
    412c:      	mov	w1, #0x3c               // =60
    4130:      	movk	w8, #0xa, lsl #16
    4134:      	str	w8, [sp, #0x100]
    4138:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    413c:      	add	x8, x8, #0x0
    4140:      	ldp	x9, x10, [x8, #0x20]
    4144:      	ldp	x12, x11, [x8, #0x10]
    4148:      	stp	x11, x9, [x13, #0x18]
    414c:      	ldr	x9, [x8, #0x30]
    4150:      	stp	x10, x9, [x13, #0x28]
    4154:      	ldp	x9, x8, [x8]
    4158:      	add	x10, sp, #0xc8
    415c:      	str	x9, [sp, #0xc8]
    4160:      	stp	x8, x12, [x13, #0x8]
    4164:      	mov	w8, #0x3c               // =60
    4168:      	mov	w9, #0x6                // =6
    416c:      	ldrh	w2, [sp, #0x80]
    4170:      	ldr	w3, [sp, #0x78]
    4174:      	ldr	w4, [sp, #0x70]
    4178:      	blr	x9
    417c:      	b	0x34f0 <perf_unwind_hotspot+0x34f0>
    4180:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4184:      	add	x8, x8, #0x0
    4188:      	add	x0, sp, #0x88
    418c:      	ldp	x9, x10, [x8, #0x20]
    4190:      	mov	w1, #0x35               // =53
    4194:      	mov	x2, x25
    4198:      	mov	x4, x19
    419c:      	stp	x9, x10, [sp, #0xa8]
    41a0:      	ldur	x9, [x8, #0x2d]
    41a4:      	stur	x9, [sp, #0xb5]
    41a8:      	ldp	x9, x10, [x8]
    41ac:      	stp	x9, x10, [sp, #0x88]
    41b0:      	ldp	x8, x9, [x8, #0x10]
    41b4:      	add	x10, sp, #0x88
    41b8:      	stp	x8, x9, [sp, #0x98]
    41bc:      	mov	w8, #0x35               // =53
    41c0:      	mov	w9, #0x6                // =6
    41c4:      	ldr	x3, [sp, #0xc0]
    41c8:      	blr	x9
    41cc:      	ldr	x8, [sp, #0xc0]
    41d0:      	b	0x35f8 <perf_unwind_hotspot+0x35f8>
    41d4:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    41d8:      	add	x8, x8, #0x0
    41dc:      	add	x13, sp, #0xc8
    41e0:      	ldp	x9, x10, [x8, #0x10]
    41e4:      	ldp	x11, x12, [x8, #0x20]
    41e8:      	add	x0, sp, #0xc8
    41ec:      	mov	w1, #0x30               // =48
    41f0:      	str	x12, [x13, #0x28]
    41f4:      	stp	x10, x11, [x13, #0x18]
    41f8:      	ldp	x10, x8, [x8]
    41fc:      	str	x10, [sp, #0xc8]
    4200:      	stp	x8, x9, [x13, #0x8]
    4204:      	mov	w8, #0x30               // =48
    4208:      	mov	w9, #0x6                // =6
    420c:      	add	x10, sp, #0xc8
    4210:      	blr	x9
    4214:      	b	0x3690 <perf_unwind_hotspot+0x3690>
    4218:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    421c:      	add	x8, x8, #0x0
    4220:      	add	x0, sp, #0xc8
    4224:      	ldp	x9, x10, [x8]
    4228:      	ldr	x8, [x8, #0x10]
    422c:      	mov	w1, #0x18               // =24
    4230:      	str	x9, [sp, #0xc8]
    4234:      	add	x9, sp, #0xc8
    4238:      	stp	x10, x8, [x9, #0x8]
    423c:      	mov	w8, #0x18               // =24
    4240:      	mov	w9, #0x6                // =6
    4244:      	add	x10, sp, #0xc8
    4248:      	blr	x9
    424c:      	mov	x22, #0x1000000000000000 // =1152921504606846976
    4250:      	ldrb	w8, [x21, #0xf21]
    4254:      	cbnz	w8, 0x7bc <perf_unwind_hotspot+0x7bc>
    4258:      	b	0x3df8 <perf_unwind_hotspot+0x3df8>
    425c:      	mov	w8, #0x6874             // =26740
    4260:      	add	x11, sp, #0xc8
    4264:      	add	x0, sp, #0xc8
    4268:      	mov	w1, #0x24               // =36
    426c:      	movk	w8, #0xa, lsl #16
    4270:      	str	w8, [sp, #0xe8]
    4274:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4278:      	add	x8, x8, #0x0
    427c:      	ldp	x9, x10, [x8]
    4280:      	str	x9, [sp, #0xc8]
    4284:      	ldp	x9, x8, [x8, #0x10]
    4288:      	stp	x10, x9, [x11, #0x8]
    428c:      	str	x8, [x11, #0x18]
    4290:      	mov	w8, #0x24               // =36
    4294:      	mov	w9, #0x6                // =6
    4298:      	add	x10, sp, #0xc8
    429c:      	blr	x9
    42a0:      	ldr	w8, [sp, #0x78]
    42a4:      	mov	x22, xzr
    42a8:      	cbnz	w8, 0x4534 <perf_unwind_hotspot+0x4534>
    42ac:      	b	0x4528 <perf_unwind_hotspot+0x4528>
    42b0:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    42b4:      	add	x8, x8, #0x0
    42b8:      	add	x11, sp, #0xc8
    42bc:      	ldp	x9, x10, [x8, #0x18]
    42c0:      	add	x0, sp, #0xc8
    42c4:      	mov	w1, #0x2f               // =47
    42c8:      	stp	x9, x10, [x11, #0x18]
    42cc:      	ldur	x10, [x8, #0x27]
    42d0:      	stur	x10, [x11, #0x27]
    42d4:      	ldr	x10, [x8]
    42d8:      	ldp	x8, x9, [x8, #0x8]
    42dc:      	str	x10, [sp, #0xc8]
    42e0:      	stp	x8, x9, [x11, #0x8]
    42e4:      	mov	w8, #0x2f               // =47
    42e8:      	mov	w9, #0x6                // =6
    42ec:      	add	x10, sp, #0xc8
    42f0:      	blr	x9
    42f4:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    42f8:      	b	0x4528 <perf_unwind_hotspot+0x4528>
    42fc:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4300:      	add	x8, x8, #0x0
    4304:      	add	x11, sp, #0xc8
    4308:      	ldp	x9, x10, [x8]
    430c:      	add	x0, sp, #0xc8
    4310:      	mov	w1, #0x1d               // =29
    4314:      	mov	x2, x25
    4318:      	str	x9, [sp, #0xc8]
    431c:      	ldr	x9, [x8, #0x10]
    4320:      	ldur	x8, [x8, #0x15]
    4324:      	stp	x10, x9, [x11, #0x8]
    4328:      	mov	w9, #0x6                // =6
    432c:      	stur	x8, [x11, #0x15]
    4330:      	mov	w8, #0x1d               // =29
    4334:      	add	x10, sp, #0xc8
    4338:      	ldrb	w3, [sp, #0x88]
    433c:      	blr	x9
    4340:      	ldrb	w9, [sp, #0x88]
    4344:      	add	w8, w9, #0x1
    4348:      	and	w8, w8, #0xff
    434c:      	cmp	w8, #0x2
    4350:      	mov	w8, w9
    4354:      	b.lo	0x33cc <perf_unwind_hotspot+0x33cc>
    4358:      	b	0x38dc <perf_unwind_hotspot+0x38dc>
    435c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4360:      	add	x8, x8, #0x0
    4364:      	add	x11, sp, #0xc8
    4368:      	ldp	x9, x10, [x8]
    436c:      	add	x0, sp, #0xc8
    4370:      	mov	w1, #0x1d               // =29
    4374:      	mov	x2, x25
    4378:      	str	x9, [sp, #0xc8]
    437c:      	ldr	x9, [x8, #0x10]
    4380:      	ldur	x8, [x8, #0x15]
    4384:      	stp	x10, x9, [x11, #0x8]
    4388:      	mov	w9, #0x6                // =6
    438c:      	stur	x8, [x11, #0x15]
    4390:      	mov	w8, #0x1d               // =29
    4394:      	add	x10, sp, #0xc8
    4398:      	ldrb	w3, [sp, #0x88]
    439c:      	blr	x9
    43a0:      	ldrb	w9, [sp, #0x88]
    43a4:      	add	w8, w9, #0x1
    43a8:      	and	w8, w8, #0xff
    43ac:      	cmp	w8, #0x2
    43b0:      	mov	w8, w9
    43b4:      	b.lo	0x33cc <perf_unwind_hotspot+0x33cc>
    43b8:      	b	0x3928 <perf_unwind_hotspot+0x3928>
    43bc:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    43c0:      	add	x8, x8, #0x0
    43c4:      	add	x11, sp, #0xc8
    43c8:      	ldp	x9, x10, [x8]
    43cc:      	add	x0, sp, #0xc8
    43d0:      	mov	w1, #0x1d               // =29
    43d4:      	mov	x2, x25
    43d8:      	str	x9, [sp, #0xc8]
    43dc:      	ldr	x9, [x8, #0x10]
    43e0:      	ldur	x8, [x8, #0x15]
    43e4:      	stp	x10, x9, [x11, #0x8]
    43e8:      	mov	w9, #0x6                // =6
    43ec:      	stur	x8, [x11, #0x15]
    43f0:      	mov	w8, #0x1d               // =29
    43f4:      	add	x10, sp, #0xc8
    43f8:      	ldrb	w3, [sp, #0x88]
    43fc:      	blr	x9
    4400:      	ldrb	w9, [sp, #0x88]
    4404:      	add	w8, w9, #0x1
    4408:      	and	w8, w8, #0xff
    440c:      	cmp	w8, #0x2
    4410:      	mov	w8, w9
    4414:      	b.lo	0x33cc <perf_unwind_hotspot+0x33cc>
    4418:      	b	0x3974 <perf_unwind_hotspot+0x3974>
    441c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4420:      	add	x8, x8, #0x0
    4424:      	add	x11, sp, #0xc8
    4428:      	ldp	x9, x10, [x8]
    442c:      	add	x0, sp, #0xc8
    4430:      	mov	w1, #0x1d               // =29
    4434:      	mov	x2, x25
    4438:      	str	x9, [sp, #0xc8]
    443c:      	ldr	x9, [x8, #0x10]
    4440:      	ldur	x8, [x8, #0x15]
    4444:      	stp	x10, x9, [x11, #0x8]
    4448:      	mov	w9, #0x6                // =6
    444c:      	stur	x8, [x11, #0x15]
    4450:      	mov	w8, #0x1d               // =29
    4454:      	add	x10, sp, #0xc8
    4458:      	ldrb	w3, [sp, #0x88]
    445c:      	blr	x9
    4460:      	ldrb	w9, [sp, #0x88]
    4464:      	add	w8, w9, #0x1
    4468:      	and	w8, w8, #0xff
    446c:      	cmp	w8, #0x2
    4470:      	mov	w8, w9
    4474:      	b.lo	0x33cc <perf_unwind_hotspot+0x33cc>
    4478:      	b	0x39c0 <perf_unwind_hotspot+0x39c0>
    447c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4480:      	add	x8, x8, #0x0
    4484:      	add	x13, sp, #0xc8
    4488:      	ldp	x9, x10, [x8, #0x20]
    448c:      	ldp	x11, x12, [x8, #0x30]
    4490:      	add	x0, sp, #0xc8
    4494:      	mov	w1, #0x40               // =64
    4498:      	str	x12, [x13, #0x38]
    449c:      	stp	x10, x11, [x13, #0x28]
    44a0:      	ldp	x10, x11, [x8]
    44a4:      	str	x10, [sp, #0xc8]
    44a8:      	ldp	x10, x8, [x8, #0x10]
    44ac:      	stp	x11, x10, [x13, #0x8]
    44b0:      	add	x10, sp, #0xc8
    44b4:      	stp	x8, x9, [x13, #0x18]
    44b8:      	mov	w8, #0x40               // =64
    44bc:      	mov	w9, #0x6                // =6
    44c0:      	ldr	x2, [sp, #0x88]
    44c4:      	ldr	w3, [sp, #0x74]
    44c8:      	blr	x9
    44cc:      	ldr	x22, [sp, #0x88]
    44d0:      	ldr	x8, [sp, #0x58]
    44d4:      	b	0x3dcc <perf_unwind_hotspot+0x3dcc>
    44d8:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    44dc:      	add	x8, x8, #0x0
    44e0:      	add	x13, sp, #0xc8
    44e4:      	strb	wzr, [sp, #0xf8]
    44e8:      	ldp	x9, x10, [x8, #0x10]
    44ec:      	add	x0, sp, #0xc8
    44f0:      	ldp	x11, x12, [x8, #0x20]
    44f4:      	mov	w1, #0x31               // =49
    44f8:      	mov	x2, x24
    44fc:      	str	x12, [x13, #0x28]
    4500:      	stp	x10, x11, [x13, #0x18]
    4504:      	ldp	x10, x8, [x8]
    4508:      	str	x10, [sp, #0xc8]
    450c:      	add	x10, sp, #0xc8
    4510:      	stp	x8, x9, [x13, #0x8]
    4514:      	mov	w8, #0x31               // =49
    4518:      	mov	w9, #0x6                // =6
    451c:      	blr	x9
    4520:      	mov	x22, xzr
    4524:      	tbz	x24, #0x3e, 0x3de4 <perf_unwind_hotspot+0x3de4>
    4528:      	ldr	x29, [sp, #0x38]
    452c:      	mov	w8, #0x10               // =16
    4530:      	str	w8, [sp, #0x78]
    4534:      	add	x9, x29, w8, uxtw
    4538:      	mov	w8, #0x10               // =16
    453c:      	add	x10, sp, #0x88
    4540:      	add	x0, sp, #0x88
    4544:      	mov	w1, #0x10               // =16
    4548:      	mov	x29, x9
    454c:      	sub	x2, x9, #0x10
    4550:      	mov	w9, #0x70               // =112
    4554:      	blr	x9
    4558:      	ldr	w8, [sp, #0x78]
    455c:      	ldr	x24, [sp, #0x90]
    4560:      	cmp	w8, #0x10
    4564:      	b.lo	0x4580 <perf_unwind_hotspot+0x4580>
    4568:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    456c:      	ldr	x8, [x8]
    4570:      	ldr	w8, [x8]
    4574:      	cbnz	w8, 0x53b4 <perf_unwind_hotspot+0x53b4>
    4578:      	ldr	x8, [sp, #0x88]
    457c:      	str	x8, [sp, #0x38]
    4580:      	ldr	w8, [x21, #0x2c0]
    4584:      	cmp	w8, #0x7e
    4588:      	b.hi	0x1508 <perf_unwind_hotspot+0x1508>
    458c:      	mov	w12, w19
    4590:      	and	x10, x22, #0x3000000000000000
    4594:      	ldr	x11, [sp, #0x30]
    4598:      	ldrb	w9, [x21, #0xf20]
    459c:      	orr	x11, x12, x11, lsl #32
    45a0:      	orr	x10, x11, x10
    45a4:      	add	w11, w8, #0x1
    45a8:      	str	w11, [x21, #0x2c0]
    45ac:      	mov	w11, #0x18              // =24
    45b0:      	umaddl	x8, w8, w11, x21
    45b4:      	str	x10, [x8, #0x2d8]
    45b8:      	mov	w10, #0x5               // =5
    45bc:      	str	x25, [x8, #0x2d0]
    45c0:      	strb	w9, [x8, #0x2e1]
    45c4:      	strh	wzr, [x8, #0x2e6]
    45c8:      	strb	w10, [x8, #0x2e0]
    45cc:      	add	x10, x8, #0x2d0
    45d0:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    45d4:      	stur	wzr, [x10, #0x12]
    45d8:      	ldr	x8, [x8]
    45dc:      	ldr	w8, [x8]
    45e0:      	cbnz	w8, 0x53f0 <perf_unwind_hotspot+0x53f0>
    45e4:      	ldr	x8, [sp, #0x38]
    45e8:      	str	x24, [x21, #0xed0]
    45ec:      	adrp	x0, 0x4000 <perf_unwind_hotspot+0x4000>
    45f0:      	add	x9, sp, #0x88
    45f4:      	add	x1, sp, #0x88
    45f8:      	str	x29, [x21, #0xed8]
    45fc:      	str	x8, [x21, #0xee0]
    4600:      	mov	w8, #0x101              // =257
    4604:      	strh	w8, [x21, #0xf20]
    4608:      	mov	w8, #0x2a               // =42
    460c:      	str	w8, [sp, #0x88]
    4610:      	mov	w8, #0x1                // =1
    4614:      	ldr	x0, [x0]
    4618:      	blr	x8
    461c:      	cbz	x0, 0x463c <perf_unwind_hotspot+0x463c>
    4620:      	ldr	x8, [x0]
    4624:      	add	x8, x8, #0x1
    4628:      	str	x8, [x0]
    462c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4630:      	ldr	x8, [x8]
    4634:      	ldr	w8, [x8]
    4638:      	b	0x464c <perf_unwind_hotspot+0x464c>
    463c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4640:      	ldr	x8, [x8]
    4644:      	ldr	w8, [x8]
    4648:      	cbnz	w8, 0x5444 <perf_unwind_hotspot+0x5444>
    464c:      	ldr	x29, [x21, #0xed0]
    4650:      	cbz	x29, 0x5eac <perf_unwind_hotspot+0x5eac>
    4654:      	cbnz	w8, 0x5490 <perf_unwind_hotspot+0x5490>
    4658:      	lsr	x8, x29, #56
    465c:      	cbnz	x8, 0x1644 <perf_unwind_hotspot+0x1644>
    4660:      	cmp	x29, #0x1, lsl #12      // =0x1000
    4664:      	b.lo	0x1798 <perf_unwind_hotspot+0x1798>
    4668:      	ldr	w8, [x21]
    466c:      	mov	w9, #0x60               // =96
    4670:      	add	x1, sp, #0x50
    4674:      	mov	x0, x20
    4678:      	rev	w8, w8
    467c:      	stp	w9, w8, [sp, #0x50]
    4680:      	rev	x8, x29
    4684:      	add	x9, sp, #0x50
    4688:      	str	x8, [sp, #0x58]
    468c:      	mov	w8, #0x1                // =1
    4690:      	blr	x8
    4694:      	cbz	x0, 0x5ee0 <perf_unwind_hotspot+0x5ee0>
    4698:      	ldr	x8, [x0, #0x8]
    469c:      	and	x9, x8, #0xffffffffffffff
    46a0:      	lsr	x25, x8, #56
    46a4:      	str	x9, [x21, #0xf10]
    46a8:      	ldr	x8, [x0]
    46ac:      	str	x8, [x21, #0xf00]
    46b0:      	sub	x8, x29, x9
    46b4:      	str	x8, [x21, #0xf08]
    46b8:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    46bc:      	ldr	x8, [x8]
    46c0:      	ldr	w8, [x8]
    46c4:      	cbnz	w8, 0x54e8 <perf_unwind_hotspot+0x54e8>
    46c8:      	cmp	w25, #0x1
    46cc:      	b.ne	0x47ac <perf_unwind_hotspot+0x47ac>
    46d0:      	ldr	x8, [x21, #0xf00]
    46d4:      	adrp	x0, 0x4000 <perf_unwind_hotspot+0x4000>
    46d8:      	ldr	x19, [x21, #0xf08]
    46dc:      	mov	w9, #0x1                // =1
    46e0:      	add	x1, sp, #0x50
    46e4:      	mov	w22, #0x1               // =1
    46e8:      	str	x8, [sp, #0x50]
    46ec:      	add	x8, sp, #0x50
    46f0:      	ldr	x0, [x0]
    46f4:      	blr	x9
    46f8:      	cbz	x0, 0x47a8 <perf_unwind_hotspot+0x47a8>
    46fc:      	ldr	x8, [x0]
    4700:      	mov	x25, x0
    4704:      	cmp	x8, x19
    4708:      	b.hi	0x4718 <perf_unwind_hotspot+0x4718>
    470c:      	ldr	x8, [x25, #0x8]
    4710:      	cmp	x8, x19
    4714:      	b.hs	0x4730 <perf_unwind_hotspot+0x4730>
    4718:      	ldr	x8, [x25, #0x10]
    471c:      	cmp	x8, x19
    4720:      	b.hi	0x47a0 <perf_unwind_hotspot+0x47a0>
    4724:      	ldr	x8, [x25, #0x18]
    4728:      	cmp	x8, x19
    472c:      	b.lo	0x47a0 <perf_unwind_hotspot+0x47a0>
    4730:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4734:      	ldr	x8, [x8]
    4738:      	ldr	w8, [x8]
    473c:      	cbz	w8, 0x4780 <perf_unwind_hotspot+0x4780>
    4740:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4744:      	add	x8, x8, #0x0
    4748:      	add	x11, sp, #0xc8
    474c:      	ldp	x9, x10, [x8]
    4750:      	add	x0, sp, #0xc8
    4754:      	mov	w1, #0x1e               // =30
    4758:      	str	x9, [sp, #0xc8]
    475c:      	ldr	x9, [x8, #0x10]
    4760:      	ldur	x8, [x8, #0x16]
    4764:      	stp	x10, x9, [x11, #0x8]
    4768:      	mov	w9, #0x6                // =6
    476c:      	stur	x8, [x11, #0x16]
    4770:      	mov	w8, #0x1e               // =30
    4774:      	add	x10, sp, #0xc8
    4778:      	ldrh	w2, [x25, #0x20]
    477c:      	blr	x9
    4780:      	ldrh	w8, [x25, #0x20]
    4784:      	ldr	w9, [x21, #0x1370]
    4788:      	lsr	w8, w9, w8
    478c:      	tbz	w8, #0x0, 0x559c <perf_unwind_hotspot+0x559c>
    4790:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4794:      	ldr	x8, [x8]
    4798:      	ldr	w8, [x8]
    479c:      	cbnz	w8, 0x55cc <perf_unwind_hotspot+0x55cc>
    47a0:      	mov	w25, #0x1               // =1
    47a4:      	b	0x47ac <perf_unwind_hotspot+0x47ac>
    47a8:      	mov	w25, w22
    47ac:      	cmp	w25, #0x2
    47b0:      	b.ne	0x6074 <perf_unwind_hotspot+0x6074>
    47b4:      	mov	w8, #0x29               // =41
    47b8:      	adrp	x0, 0x4000 <perf_unwind_hotspot+0x4000>
    47bc:      	add	x9, sp, #0x50
    47c0:      	str	w8, [sp, #0x50]
    47c4:      	mov	w8, #0x1                // =1
    47c8:      	add	x1, sp, #0x50
    47cc:      	ldr	x0, [x0]
    47d0:      	blr	x8
    47d4:      	cbz	x0, 0x485c <perf_unwind_hotspot+0x485c>
    47d8:      	ldr	x8, [x0]
    47dc:      	add	x8, x8, #0x1
    47e0:      	str	x8, [x0]
    47e4:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    47e8:      	ldr	x8, [x8]
    47ec:      	ldr	x22, [x21, #0xed0]
    47f0:      	ldr	x10, [x21, #0xed8]
    47f4:      	ldr	x9, [x21, #0xee0]
    47f8:      	ldr	w8, [x8]
    47fc:      	stp	x9, x10, [sp, #0x30]
    4800:      	cbz	w8, 0x487c <perf_unwind_hotspot+0x487c>
    4804:      	mov	w8, #0x786c             // =30828
    4808:      	add	x13, sp, #0xc8
    480c:      	add	x0, sp, #0xc8
    4810:      	mov	w1, #0x2c               // =44
    4814:      	movk	w8, #0xa, lsl #16
    4818:      	str	w8, [sp, #0xf0]
    481c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4820:      	add	x8, x8, #0x0
    4824:      	ldp	x9, x10, [x8, #0x10]
    4828:      	ldp	x12, x11, [x8]
    482c:      	ldr	x8, [x8, #0x20]
    4830:      	str	x12, [sp, #0xc8]
    4834:      	stp	x11, x9, [x13, #0x8]
    4838:      	stp	x10, x8, [x13, #0x18]
    483c:      	mov	w8, #0x2c               // =44
    4840:      	mov	w9, #0x6                // =6
    4844:      	add	x10, sp, #0xc8
    4848:      	ldr	x2, [x21, #0xed0]
    484c:      	ldr	x3, [x21, #0xf10]
    4850:      	ldr	x4, [x21, #0xf08]
    4854:      	blr	x9
    4858:      	b	0x487c <perf_unwind_hotspot+0x487c>
    485c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4860:      	ldr	x8, [x8]
    4864:      	ldr	w8, [x8]
    4868:      	cbnz	w8, 0x5614 <perf_unwind_hotspot+0x5614>
    486c:      	ldr	x9, [x21, #0xed8]
    4870:      	ldr	x8, [x21, #0xee0]
    4874:      	ldr	x22, [x21, #0xed0]
    4878:      	stp	x8, x9, [sp, #0x30]
    487c:      	ldr	x8, [x21, #0xf08]
    4880:      	ldrb	w9, [x23, #0x20]
    4884:      	add	x10, sp, #0x88
    4888:      	add	x0, sp, #0x88
    488c:      	mov	w1, #0x1                // =1
    4890:      	lsr	x25, x8, x9
    4894:      	ldr	x8, [x21, #0xf00]
    4898:      	mov	w9, #0x70               // =112
    489c:      	and	x19, x8, #0xffffffffffffff
    48a0:      	mov	w8, #0x1                // =1
    48a4:      	add	x2, x25, x19
    48a8:      	blr	x9
    48ac:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    48b0:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    48b4:      	ldr	x8, [x8]
    48b8:      	ldr	w8, [x8]
    48bc:      	cbz	w8, 0x4904 <perf_unwind_hotspot+0x4904>
    48c0:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    48c4:      	add	x8, x8, #0x0
    48c8:      	add	x11, sp, #0xc8
    48cc:      	ldp	x9, x10, [x8]
    48d0:      	add	x0, sp, #0xc8
    48d4:      	mov	w1, #0x1d               // =29
    48d8:      	mov	x2, x25
    48dc:      	str	x9, [sp, #0xc8]
    48e0:      	ldr	x9, [x8, #0x10]
    48e4:      	ldur	x8, [x8, #0x15]
    48e8:      	stp	x10, x9, [x11, #0x8]
    48ec:      	mov	w9, #0x6                // =6
    48f0:      	stur	x8, [x11, #0x15]
    48f4:      	mov	w8, #0x1d               // =29
    48f8:      	add	x10, sp, #0xc8
    48fc:      	ldrb	w3, [sp, #0x88]
    4900:      	blr	x9
    4904:      	ldrb	w8, [sp, #0x88]
    4908:      	add	w9, w8, #0x1
    490c:      	and	w9, w9, #0xff
    4910:      	cmp	w9, #0x2
    4914:      	b.lo	0x4f44 <perf_unwind_hotspot+0x4f44>
    4918:      	sub	x25, x25, x8
    491c:      	mov	w8, #0x1                // =1
    4920:      	mov	w9, #0x70               // =112
    4924:      	add	x10, sp, #0x88
    4928:      	add	x0, sp, #0x88
    492c:      	mov	w1, #0x1                // =1
    4930:      	add	x2, x25, x19
    4934:      	blr	x9
    4938:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    493c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4940:      	ldr	x8, [x8]
    4944:      	ldr	w8, [x8]
    4948:      	cbz	w8, 0x4990 <perf_unwind_hotspot+0x4990>
    494c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4950:      	add	x8, x8, #0x0
    4954:      	add	x11, sp, #0xc8
    4958:      	ldp	x9, x10, [x8]
    495c:      	add	x0, sp, #0xc8
    4960:      	mov	w1, #0x1d               // =29
    4964:      	mov	x2, x25
    4968:      	str	x9, [sp, #0xc8]
    496c:      	ldr	x9, [x8, #0x10]
    4970:      	ldur	x8, [x8, #0x15]
    4974:      	stp	x10, x9, [x11, #0x8]
    4978:      	mov	w9, #0x6                // =6
    497c:      	stur	x8, [x11, #0x15]
    4980:      	mov	w8, #0x1d               // =29
    4984:      	add	x10, sp, #0xc8
    4988:      	ldrb	w3, [sp, #0x88]
    498c:      	blr	x9
    4990:      	ldrb	w9, [sp, #0x88]
    4994:      	add	w8, w9, #0x1
    4998:      	and	w8, w8, #0xff
    499c:      	cmp	w8, #0x2
    49a0:      	mov	w8, w9
    49a4:      	b.lo	0x4f44 <perf_unwind_hotspot+0x4f44>
    49a8:      	sub	x25, x25, x9
    49ac:      	mov	w8, #0x1                // =1
    49b0:      	mov	w9, #0x70               // =112
    49b4:      	add	x10, sp, #0x88
    49b8:      	add	x0, sp, #0x88
    49bc:      	mov	w1, #0x1                // =1
    49c0:      	add	x2, x25, x19
    49c4:      	blr	x9
    49c8:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    49cc:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    49d0:      	ldr	x8, [x8]
    49d4:      	ldr	w8, [x8]
    49d8:      	cbz	w8, 0x4a20 <perf_unwind_hotspot+0x4a20>
    49dc:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    49e0:      	add	x8, x8, #0x0
    49e4:      	add	x11, sp, #0xc8
    49e8:      	ldp	x9, x10, [x8]
    49ec:      	add	x0, sp, #0xc8
    49f0:      	mov	w1, #0x1d               // =29
    49f4:      	mov	x2, x25
    49f8:      	str	x9, [sp, #0xc8]
    49fc:      	ldr	x9, [x8, #0x10]
    4a00:      	ldur	x8, [x8, #0x15]
    4a04:      	stp	x10, x9, [x11, #0x8]
    4a08:      	mov	w9, #0x6                // =6
    4a0c:      	stur	x8, [x11, #0x15]
    4a10:      	mov	w8, #0x1d               // =29
    4a14:      	add	x10, sp, #0xc8
    4a18:      	ldrb	w3, [sp, #0x88]
    4a1c:      	blr	x9
    4a20:      	ldrb	w9, [sp, #0x88]
    4a24:      	add	w8, w9, #0x1
    4a28:      	and	w8, w8, #0xff
    4a2c:      	cmp	w8, #0x2
    4a30:      	mov	w8, w9
    4a34:      	b.lo	0x4f44 <perf_unwind_hotspot+0x4f44>
    4a38:      	sub	x25, x25, x9
    4a3c:      	mov	w8, #0x1                // =1
    4a40:      	mov	w9, #0x70               // =112
    4a44:      	add	x10, sp, #0x88
    4a48:      	add	x0, sp, #0x88
    4a4c:      	mov	w1, #0x1                // =1
    4a50:      	add	x2, x25, x19
    4a54:      	blr	x9
    4a58:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    4a5c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4a60:      	ldr	x8, [x8]
    4a64:      	ldr	w8, [x8]
    4a68:      	cbz	w8, 0x4ab0 <perf_unwind_hotspot+0x4ab0>
    4a6c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4a70:      	add	x8, x8, #0x0
    4a74:      	add	x11, sp, #0xc8
    4a78:      	ldp	x9, x10, [x8]
    4a7c:      	add	x0, sp, #0xc8
    4a80:      	mov	w1, #0x1d               // =29
    4a84:      	mov	x2, x25
    4a88:      	str	x9, [sp, #0xc8]
    4a8c:      	ldr	x9, [x8, #0x10]
    4a90:      	ldur	x8, [x8, #0x15]
    4a94:      	stp	x10, x9, [x11, #0x8]
    4a98:      	mov	w9, #0x6                // =6
    4a9c:      	stur	x8, [x11, #0x15]
    4aa0:      	mov	w8, #0x1d               // =29
    4aa4:      	add	x10, sp, #0xc8
    4aa8:      	ldrb	w3, [sp, #0x88]
    4aac:      	blr	x9
    4ab0:      	ldrb	w9, [sp, #0x88]
    4ab4:      	add	w8, w9, #0x1
    4ab8:      	and	w8, w8, #0xff
    4abc:      	cmp	w8, #0x2
    4ac0:      	mov	w8, w9
    4ac4:      	b.lo	0x4f44 <perf_unwind_hotspot+0x4f44>
    4ac8:      	sub	x25, x25, x9
    4acc:      	mov	w8, #0x1                // =1
    4ad0:      	mov	w9, #0x70               // =112
    4ad4:      	add	x10, sp, #0x88
    4ad8:      	add	x0, sp, #0x88
    4adc:      	mov	w1, #0x1                // =1
    4ae0:      	add	x2, x25, x19
    4ae4:      	blr	x9
    4ae8:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    4aec:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4af0:      	ldr	x8, [x8]
    4af4:      	ldr	w8, [x8]
    4af8:      	cbz	w8, 0x4b40 <perf_unwind_hotspot+0x4b40>
    4afc:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4b00:      	add	x8, x8, #0x0
    4b04:      	add	x11, sp, #0xc8
    4b08:      	ldp	x9, x10, [x8]
    4b0c:      	add	x0, sp, #0xc8
    4b10:      	mov	w1, #0x1d               // =29
    4b14:      	mov	x2, x25
    4b18:      	str	x9, [sp, #0xc8]
    4b1c:      	ldr	x9, [x8, #0x10]
    4b20:      	ldur	x8, [x8, #0x15]
    4b24:      	stp	x10, x9, [x11, #0x8]
    4b28:      	mov	w9, #0x6                // =6
    4b2c:      	stur	x8, [x11, #0x15]
    4b30:      	mov	w8, #0x1d               // =29
    4b34:      	add	x10, sp, #0xc8
    4b38:      	ldrb	w3, [sp, #0x88]
    4b3c:      	blr	x9
    4b40:      	ldrb	w9, [sp, #0x88]
    4b44:      	add	w8, w9, #0x1
    4b48:      	and	w8, w8, #0xff
    4b4c:      	cmp	w8, #0x2
    4b50:      	mov	w8, w9
    4b54:      	b.lo	0x4f44 <perf_unwind_hotspot+0x4f44>
    4b58:      	sub	x25, x25, x9
    4b5c:      	mov	w8, #0x1                // =1
    4b60:      	mov	w9, #0x70               // =112
    4b64:      	add	x10, sp, #0x88
    4b68:      	add	x0, sp, #0x88
    4b6c:      	mov	w1, #0x1                // =1
    4b70:      	add	x2, x25, x19
    4b74:      	blr	x9
    4b78:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    4b7c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4b80:      	ldr	x8, [x8]
    4b84:      	ldr	w8, [x8]
    4b88:      	cbz	w8, 0x4bd0 <perf_unwind_hotspot+0x4bd0>
    4b8c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4b90:      	add	x8, x8, #0x0
    4b94:      	add	x11, sp, #0xc8
    4b98:      	ldp	x9, x10, [x8]
    4b9c:      	add	x0, sp, #0xc8
    4ba0:      	mov	w1, #0x1d               // =29
    4ba4:      	mov	x2, x25
    4ba8:      	str	x9, [sp, #0xc8]
    4bac:      	ldr	x9, [x8, #0x10]
    4bb0:      	ldur	x8, [x8, #0x15]
    4bb4:      	stp	x10, x9, [x11, #0x8]
    4bb8:      	mov	w9, #0x6                // =6
    4bbc:      	stur	x8, [x11, #0x15]
    4bc0:      	mov	w8, #0x1d               // =29
    4bc4:      	add	x10, sp, #0xc8
    4bc8:      	ldrb	w3, [sp, #0x88]
    4bcc:      	blr	x9
    4bd0:      	ldrb	w9, [sp, #0x88]
    4bd4:      	add	w8, w9, #0x1
    4bd8:      	and	w8, w8, #0xff
    4bdc:      	cmp	w8, #0x2
    4be0:      	mov	w8, w9
    4be4:      	b.lo	0x4f44 <perf_unwind_hotspot+0x4f44>
    4be8:      	sub	x25, x25, x9
    4bec:      	mov	w8, #0x1                // =1
    4bf0:      	mov	w9, #0x70               // =112
    4bf4:      	add	x10, sp, #0x88
    4bf8:      	add	x0, sp, #0x88
    4bfc:      	mov	w1, #0x1                // =1
    4c00:      	add	x2, x25, x19
    4c04:      	blr	x9
    4c08:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    4c0c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4c10:      	ldr	x8, [x8]
    4c14:      	ldr	w8, [x8]
    4c18:      	cbz	w8, 0x4c60 <perf_unwind_hotspot+0x4c60>
    4c1c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4c20:      	add	x8, x8, #0x0
    4c24:      	add	x11, sp, #0xc8
    4c28:      	ldp	x9, x10, [x8]
    4c2c:      	add	x0, sp, #0xc8
    4c30:      	mov	w1, #0x1d               // =29
    4c34:      	mov	x2, x25
    4c38:      	str	x9, [sp, #0xc8]
    4c3c:      	ldr	x9, [x8, #0x10]
    4c40:      	ldur	x8, [x8, #0x15]
    4c44:      	stp	x10, x9, [x11, #0x8]
    4c48:      	mov	w9, #0x6                // =6
    4c4c:      	stur	x8, [x11, #0x15]
    4c50:      	mov	w8, #0x1d               // =29
    4c54:      	add	x10, sp, #0xc8
    4c58:      	ldrb	w3, [sp, #0x88]
    4c5c:      	blr	x9
    4c60:      	ldrb	w9, [sp, #0x88]
    4c64:      	add	w8, w9, #0x1
    4c68:      	and	w8, w8, #0xff
    4c6c:      	cmp	w8, #0x2
    4c70:      	mov	w8, w9
    4c74:      	b.lo	0x4f44 <perf_unwind_hotspot+0x4f44>
    4c78:      	sub	x25, x25, x9
    4c7c:      	mov	w8, #0x1                // =1
    4c80:      	mov	w9, #0x70               // =112
    4c84:      	add	x10, sp, #0x88
    4c88:      	add	x0, sp, #0x88
    4c8c:      	mov	w1, #0x1                // =1
    4c90:      	add	x2, x25, x19
    4c94:      	blr	x9
    4c98:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    4c9c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4ca0:      	ldr	x8, [x8]
    4ca4:      	ldr	w8, [x8]
    4ca8:      	cbz	w8, 0x4cf0 <perf_unwind_hotspot+0x4cf0>
    4cac:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4cb0:      	add	x8, x8, #0x0
    4cb4:      	add	x11, sp, #0xc8
    4cb8:      	ldp	x9, x10, [x8]
    4cbc:      	add	x0, sp, #0xc8
    4cc0:      	mov	w1, #0x1d               // =29
    4cc4:      	mov	x2, x25
    4cc8:      	str	x9, [sp, #0xc8]
    4ccc:      	ldr	x9, [x8, #0x10]
    4cd0:      	ldur	x8, [x8, #0x15]
    4cd4:      	stp	x10, x9, [x11, #0x8]
    4cd8:      	mov	w9, #0x6                // =6
    4cdc:      	stur	x8, [x11, #0x15]
    4ce0:      	mov	w8, #0x1d               // =29
    4ce4:      	add	x10, sp, #0xc8
    4ce8:      	ldrb	w3, [sp, #0x88]
    4cec:      	blr	x9
    4cf0:      	ldrb	w9, [sp, #0x88]
    4cf4:      	add	w8, w9, #0x1
    4cf8:      	and	w8, w8, #0xff
    4cfc:      	cmp	w8, #0x2
    4d00:      	mov	w8, w9
    4d04:      	b.lo	0x4f44 <perf_unwind_hotspot+0x4f44>
    4d08:      	sub	x25, x25, x9
    4d0c:      	mov	w8, #0x1                // =1
    4d10:      	mov	w9, #0x70               // =112
    4d14:      	add	x10, sp, #0x88
    4d18:      	add	x0, sp, #0x88
    4d1c:      	mov	w1, #0x1                // =1
    4d20:      	add	x2, x25, x19
    4d24:      	blr	x9
    4d28:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    4d2c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4d30:      	ldr	x8, [x8]
    4d34:      	ldr	w8, [x8]
    4d38:      	cbz	w8, 0x4d80 <perf_unwind_hotspot+0x4d80>
    4d3c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4d40:      	add	x8, x8, #0x0
    4d44:      	add	x11, sp, #0xc8
    4d48:      	ldp	x9, x10, [x8]
    4d4c:      	add	x0, sp, #0xc8
    4d50:      	mov	w1, #0x1d               // =29
    4d54:      	mov	x2, x25
    4d58:      	str	x9, [sp, #0xc8]
    4d5c:      	ldr	x9, [x8, #0x10]
    4d60:      	ldur	x8, [x8, #0x15]
    4d64:      	stp	x10, x9, [x11, #0x8]
    4d68:      	mov	w9, #0x6                // =6
    4d6c:      	stur	x8, [x11, #0x15]
    4d70:      	mov	w8, #0x1d               // =29
    4d74:      	add	x10, sp, #0xc8
    4d78:      	ldrb	w3, [sp, #0x88]
    4d7c:      	blr	x9
    4d80:      	ldrb	w9, [sp, #0x88]
    4d84:      	add	w8, w9, #0x1
    4d88:      	and	w8, w8, #0xff
    4d8c:      	cmp	w8, #0x2
    4d90:      	mov	w8, w9
    4d94:      	b.lo	0x4f44 <perf_unwind_hotspot+0x4f44>
    4d98:      	sub	x25, x25, x9
    4d9c:      	mov	w8, #0x1                // =1
    4da0:      	mov	w9, #0x70               // =112
    4da4:      	add	x10, sp, #0x88
    4da8:      	add	x0, sp, #0x88
    4dac:      	mov	w1, #0x1                // =1
    4db0:      	add	x2, x25, x19
    4db4:      	blr	x9
    4db8:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    4dbc:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4dc0:      	ldr	x8, [x8]
    4dc4:      	ldr	w8, [x8]
    4dc8:      	cbz	w8, 0x4e10 <perf_unwind_hotspot+0x4e10>
    4dcc:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4dd0:      	add	x8, x8, #0x0
    4dd4:      	add	x11, sp, #0xc8
    4dd8:      	ldp	x9, x10, [x8]
    4ddc:      	add	x0, sp, #0xc8
    4de0:      	mov	w1, #0x1d               // =29
    4de4:      	mov	x2, x25
    4de8:      	str	x9, [sp, #0xc8]
    4dec:      	ldr	x9, [x8, #0x10]
    4df0:      	ldur	x8, [x8, #0x15]
    4df4:      	stp	x10, x9, [x11, #0x8]
    4df8:      	mov	w9, #0x6                // =6
    4dfc:      	stur	x8, [x11, #0x15]
    4e00:      	mov	w8, #0x1d               // =29
    4e04:      	add	x10, sp, #0xc8
    4e08:      	ldrb	w3, [sp, #0x88]
    4e0c:      	blr	x9
    4e10:      	ldrb	w9, [sp, #0x88]
    4e14:      	add	w8, w9, #0x1
    4e18:      	and	w8, w8, #0xff
    4e1c:      	cmp	w8, #0x2
    4e20:      	mov	w8, w9
    4e24:      	b.lo	0x4f44 <perf_unwind_hotspot+0x4f44>
    4e28:      	sub	x25, x25, x9
    4e2c:      	mov	w8, #0x1                // =1
    4e30:      	mov	w9, #0x70               // =112
    4e34:      	add	x10, sp, #0x88
    4e38:      	add	x0, sp, #0x88
    4e3c:      	mov	w1, #0x1                // =1
    4e40:      	add	x2, x25, x19
    4e44:      	blr	x9
    4e48:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    4e4c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4e50:      	ldr	x8, [x8]
    4e54:      	ldr	w8, [x8]
    4e58:      	cbz	w8, 0x4ea0 <perf_unwind_hotspot+0x4ea0>
    4e5c:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4e60:      	add	x8, x8, #0x0
    4e64:      	add	x11, sp, #0xc8
    4e68:      	ldp	x9, x10, [x8]
    4e6c:      	add	x0, sp, #0xc8
    4e70:      	mov	w1, #0x1d               // =29
    4e74:      	mov	x2, x25
    4e78:      	str	x9, [sp, #0xc8]
    4e7c:      	ldr	x9, [x8, #0x10]
    4e80:      	ldur	x8, [x8, #0x15]
    4e84:      	stp	x10, x9, [x11, #0x8]
    4e88:      	mov	w9, #0x6                // =6
    4e8c:      	stur	x8, [x11, #0x15]
    4e90:      	mov	w8, #0x1d               // =29
    4e94:      	add	x10, sp, #0xc8
    4e98:      	ldrb	w3, [sp, #0x88]
    4e9c:      	blr	x9
    4ea0:      	ldrb	w9, [sp, #0x88]
    4ea4:      	add	w8, w9, #0x1
    4ea8:      	and	w8, w8, #0xff
    4eac:      	cmp	w8, #0x2
    4eb0:      	mov	w8, w9
    4eb4:      	b.lo	0x4f44 <perf_unwind_hotspot+0x4f44>
    4eb8:      	sub	x25, x25, x9
    4ebc:      	mov	w8, #0x1                // =1
    4ec0:      	mov	w9, #0x70               // =112
    4ec4:      	add	x10, sp, #0x88
    4ec8:      	add	x0, sp, #0x88
    4ecc:      	mov	w1, #0x1                // =1
    4ed0:      	add	x2, x25, x19
    4ed4:      	blr	x9
    4ed8:      	cbnz	x0, 0x178 <perf_unwind_hotspot+0x178>
    4edc:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4ee0:      	ldr	x8, [x8]
    4ee4:      	ldr	w8, [x8]
    4ee8:      	cbz	w8, 0x4f30 <perf_unwind_hotspot+0x4f30>
    4eec:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4ef0:      	add	x8, x8, #0x0
    4ef4:      	add	x11, sp, #0xc8
    4ef8:      	ldp	x9, x10, [x8]
    4efc:      	add	x0, sp, #0xc8
    4f00:      	mov	w1, #0x1d               // =29
    4f04:      	mov	x2, x25
    4f08:      	str	x9, [sp, #0xc8]
    4f0c:      	ldr	x9, [x8, #0x10]
    4f10:      	ldur	x8, [x8, #0x15]
    4f14:      	stp	x10, x9, [x11, #0x8]
    4f18:      	mov	w9, #0x6                // =6
    4f1c:      	stur	x8, [x11, #0x15]
    4f20:      	mov	w8, #0x1d               // =29
    4f24:      	add	x10, sp, #0xc8
    4f28:      	ldrb	w3, [sp, #0x88]
    4f2c:      	blr	x9
    4f30:      	ldrb	w8, [sp, #0x88]
    4f34:      	add	w9, w8, #0x1
    4f38:      	and	w9, w9, #0xff
    4f3c:      	cmp	w9, #0x1
    4f40:      	b.hi	0x178 <perf_unwind_hotspot+0x178>
    4f44:      	cbnz	w8, 0x178 <perf_unwind_hotspot+0x178>
    4f48:      	ldr	x8, [x21, #0xf10]
    4f4c:      	ldrb	w9, [x23, #0x20]
    4f50:      	lsl	x9, x25, x9
    4f54:      	ldrb	w10, [x23, #0x1b]
    4f58:      	add	x8, x8, x10
    4f5c:      	add	x24, x9, x8
    4f60:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4f64:      	ldr	x8, [x8]
    4f68:      	ldr	w8, [x8]
    4f6c:      	cbz	w8, 0x4fb0 <perf_unwind_hotspot+0x4fb0>
    4f70:      	adrp	x8, 0x4000 <perf_unwind_hotspot+0x4000>
    4f74:      	add	x8, x8, #0x0
    4f78:      	add	x11, sp, #0xc8
    4f7c:      	strb	wzr, [sp, #0xe8]
    4f80:      	ldp	x9, x10, [x8]
    4f84:      	add	x0, sp, #0xc8
    4f88:      	mov	w1, #0x21               // =33
    4f8c:      	mov	x2, x24
    4f90:      	str	x9, [sp, #0xc8]
    4f94:      	ldp	x9, x8, [x8, #0x10]
    4f98:      	str	x8, [x11, #0x18]
    4f9c:      	stp	x10, x9, [x11, #0x8]
    4fa0:      	mov	w8, #0x21               // =33
    4fa4:      	mov	w9, #0x6                // =6
    4fa8:      	add	x10, sp, #0xc8
    4fac:      	blr	x9
    4fb0:      	str	x24, [sp, #0x50]
    4fb4:      	cbz	x24, 0x17c <perf_unwind_hotspot+0x17c>
    4fb8:      	mov	w8, #0x200              // =512
    4fbc:      	mov	w9, #0x70               // =112
    4fc0:      	ldr	x0, [sp, #0x8]
    4fc4:      	mov	w1, #0x200              // =512
    4fc8:      	ldr	x2, [sp, #0x50]
    4fcc:      	blr	x9
    4fd0:      	adrp	x24, 0x4000 <perf_unwind_hotspot+0x4000>
    4fd4:      	ldr	x24, [x24]
    4fd8:      	cbnz	x0, 0x258 <perf_unwind_hotspot+0x258>
    4fdc:      	ldrh	w8, [x23, #0x10]
    4fe0:      	cmp	x8, #0x1f8
    4fe4:      	b.hi	0x3c4 <perf_unwind_hotspot+0x3c4>
    4fe8:      	ldrh	w9, [x23, #0x12]
    4fec:      	cmp	x9, #0x1fc
    4ff0:      	b.hi	0x3c4 <perf_unwind_hotspot+0x3c4>
    4ff4:      	ldrh	w10, [x23, #0x14]
    4ff8:      	cmp	x10, #0x1f8
    4ffc:      	b.hi	0x3c4 <perf_unwind_hotspot+0x3c4>
    5000:      	ldrb	w11, [x23, #0x17]
    5004:      	ldr	x12, [sp, #0x8]
    5008:      	mov	w1, #0x4                // =4
    500c:      	ldr	x0, [sp, #0x40]
    5010:      	ldr	x11, [x12, x11]
    5014:      	str	x11, [sp, #0x58]
    5018:      	ldrb	w11, [x23, #0x18]
    501c:      	ldr	x11, [x12, x11]
    5020:      	str	x11, [sp, #0x60]
    5024:      	ldrb	w11, [x23, #0x1a]
    5028:      	ldr	w11, [x12, x11]
    502c:      	lsl	w11, w11, #3
    5030:      	str	w11, [sp, #0x78]
    5034:      	ldrb	w11, [x23, #0x19]
    5038:      	ldrh	w11, [x12, x11]
    503c:      	strh	w11, [sp, #0x80]
    5040:      	ldr	w9, [x12, x9]
    5044:      	str	w9, [sp, #0x7c]
    5048:      	ldr	w9, [x12, x10]
    504c:      	str	w9, [sp, #0x74]
    5050:      	mov	w9, #0x70               // =112
    5054:      	ldr	x8, [x12, x8]
    5058:      	str	x8, [sp, #0x68]
    505c:      	ldrb	w8, [x23, #0x16]
    5060:      	ldr	x2, [x12, x8]
    5064:      	mov	w8, #0x4                // =4
    5068:      	blr	x9
    506c:      	adrp	x24, 0x5000 <perf_unwind_hotspot+0x5000>
    5070:      	ldr	x24, [x24]
    5074:      	cbnz	x0, 0x258 <perf_unwind_hotspot+0x258>
    5078:      	ldrb	w8, [x23, #0x21]
    507c:      	cbz	w8, 0x5098 <perf_unwind_hotspot+0x5098>
    5080:      	ldr	x8, [sp, #0x50]
    5084:      	ldr	w9, [sp, #0x58]
    5088:      	add	x9, x9, x8
    508c:      	ldr	w10, [sp, #0x60]
    5090:      	add	x8, x10, x8
    5094:      	stp	x9, x8, [sp, #0x58]
    5098:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    509c:      	ldr	x8, [x8]
    50a0:      	ldr	w8, [x8]
    50a4:      	cbz	w8, 0x5150 <perf_unwind_hotspot+0x5150>
    50a8:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    50ac:      	add	x8, x8, #0x0
    50b0:      	add	x0, sp, #0xc8
    50b4:      	ldp	x9, x10, [x8]
    50b8:      	ldur	x8, [x8, #0xf]
    50bc:      	mov	w1, #0x17               // =23
    50c0:      	str	x9, [sp, #0xc8]
    50c4:      	add	x9, sp, #0xc8
    50c8:      	str	x10, [x9, #0x8]
    50cc:      	stur	x8, [x9, #0xf]
    50d0:      	mov	w8, #0x17               // =23
    50d4:      	mov	w9, #0x6                // =6
    50d8:      	add	x10, sp, #0xc8
    50dc:      	ldp	x2, x3, [sp, #0x58]
    50e0:      	blr	x9
    50e4:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    50e8:      	ldr	x8, [x8]
    50ec:      	ldr	w8, [x8]
    50f0:      	cbz	w8, 0x5150 <perf_unwind_hotspot+0x5150>
    50f4:      	mov	w8, #0x7825             // =30757
    50f8:      	add	x13, sp, #0xc8
    50fc:      	add	x0, sp, #0xc8
    5100:      	mov	w1, #0x3c               // =60
    5104:      	movk	w8, #0xa, lsl #16
    5108:      	str	w8, [sp, #0x100]
    510c:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5110:      	add	x8, x8, #0x0
    5114:      	ldp	x9, x10, [x8, #0x20]
    5118:      	ldp	x12, x11, [x8, #0x10]
    511c:      	stp	x11, x9, [x13, #0x18]
    5120:      	ldr	x9, [x8, #0x30]
    5124:      	stp	x10, x9, [x13, #0x28]
    5128:      	ldp	x9, x8, [x8]
    512c:      	add	x10, sp, #0xc8
    5130:      	str	x9, [sp, #0xc8]
    5134:      	stp	x8, x12, [x13, #0x8]
    5138:      	mov	w8, #0x3c               // =60
    513c:      	mov	w9, #0x6                // =6
    5140:      	ldrh	w2, [sp, #0x80]
    5144:      	ldr	w3, [sp, #0x78]
    5148:      	ldr	w4, [sp, #0x70]
    514c:      	blr	x9
    5150:      	ldr	w19, [sp, #0x70]
    5154:      	ldp	x24, x8, [sp, #0x50]
    5158:      	mov	w9, #0x616d             // =24941
    515c:      	movk	w9, #0x6974, lsl #16
    5160:      	sub	w29, w22, w8
    5164:      	cmp	w19, w9
    5168:      	b.gt	0x5660 <perf_unwind_hotspot+0x5660>
    516c:      	mov	w8, #0x7476             // =29814
    5170:      	movk	w8, #0x6261, lsl #16
    5174:      	cmp	w19, w8
    5178:      	b.eq	0x5704 <perf_unwind_hotspot+0x5704>
    517c:      	mov	w8, #0x6e49             // =28233
    5180:      	movk	w8, #0x6574, lsl #16
    5184:      	cmp	w19, w8
    5188:      	b.ne	0x5784 <perf_unwind_hotspot+0x5784>
    518c:      	ldp	x8, x9, [sp, #0x30]
    5190:      	cmp	x8, x9
    5194:      	b.lo	0x52c0 <perf_unwind_hotspot+0x52c0>
    5198:      	ldp	x9, x8, [sp, #0x30]
    519c:      	add	x8, x8, #0x1, lsl #12   // =0x1000
    51a0:      	cmp	x9, x8
    51a4:      	b.hs	0x52c0 <perf_unwind_hotspot+0x52c0>
    51a8:      	ldr	x8, [sp, #0x30]
    51ac:      	mov	w9, #0x70               // =112
    51b0:      	add	x10, sp, #0xc8
    51b4:      	add	x0, sp, #0xc8
    51b8:      	mov	w1, #0x60               // =96
    51bc:      	sub	x2, x8, #0x50
    51c0:      	mov	w8, #0x60               // =96
    51c4:      	blr	x9
    51c8:      	cbnz	x0, 0x51c <perf_unwind_hotspot+0x51c>
    51cc:      	ldr	w8, [x21, #0x2c0]
    51d0:      	cbz	w8, 0x51e8 <perf_unwind_hotspot+0x51e8>
    51d4:      	ldrb	w8, [x23, #0x1f]
    51d8:      	cmp	w8, #0x0
    51dc:      	ldp	x9, x8, [sp, #0x10]
    51e0:      	csel	x8, x9, x8, eq
    51e4:      	str	x8, [sp, #0x20]
    51e8:      	ldr	x8, [sp, #0x20]
    51ec:      	add	x11, sp, #0xc0
    51f0:      	add	x0, sp, #0xc0
    51f4:      	mov	w1, #0x8                // =8
    51f8:      	ldr	x19, [x8]
    51fc:      	add	x8, sp, #0xc8
    5200:      	ldp	x10, x9, [x8, #0x48]
    5204:      	ldr	x24, [x8, #0x38]
    5208:      	ldr	x25, [x8, #0x58]
    520c:      	ldrb	w8, [x23, #0x1c]
    5210:      	stp	x9, x10, [sp, #0x30]
    5214:      	add	x8, x24, x8
    5218:      	mov	w9, #0x8                // =8
    521c:      	mov	w10, #0x70              // =112
    5220:      	ldrb	w8, [x23, #0x1c]
    5224:      	add	x2, x24, x8
    5228:      	blr	x10
    522c:      	cbnz	x0, 0xf20 <perf_unwind_hotspot+0xf20>
    5230:      	ldr	x8, [sp, #0xc0]
    5234:      	ldrb	w9, [x23, #0x1d]
    5238:      	add	x9, x8, x9
    523c:      	cmp	x19, x9
    5240:      	csel	x9, xzr, x9, lo
    5244:      	sub	x23, x19, x9
    5248:      	adrp	x9, 0x5000 <perf_unwind_hotspot+0x5000>
    524c:      	ldr	x9, [x9]
    5250:      	ldr	w9, [x9]
    5254:      	cbz	w9, 0x52a8 <perf_unwind_hotspot+0x52a8>
    5258:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    525c:      	add	x8, x8, #0x0
    5260:      	add	x0, sp, #0x88
    5264:      	ldp	x9, x10, [x8, #0x20]
    5268:      	mov	w1, #0x35               // =53
    526c:      	mov	x2, x24
    5270:      	mov	x4, x23
    5274:      	stp	x9, x10, [sp, #0xa8]
    5278:      	ldur	x9, [x8, #0x2d]
    527c:      	stur	x9, [sp, #0xb5]
    5280:      	ldp	x9, x10, [x8]
    5284:      	stp	x9, x10, [sp, #0x88]
    5288:      	ldp	x8, x9, [x8, #0x10]
    528c:      	add	x10, sp, #0x88
    5290:      	stp	x8, x9, [sp, #0x98]
    5294:      	mov	w8, #0x35               // =53
    5298:      	mov	w9, #0x6                // =6
    529c:      	ldr	x3, [sp, #0xc0]
    52a0:      	blr	x9
    52a4:      	ldr	x8, [sp, #0xc0]
    52a8:      	mov	w9, #0xffff             // =65535
    52ac:      	lsr	x19, x8, #3
    52b0:      	mov	x22, #0x2000000000000000 // =2305843009213693952
    52b4:      	cmp	x23, x9
    52b8:      	csel	x29, x23, x9, lo
    52bc:      	b	0x5af8 <perf_unwind_hotspot+0x5af8>
    52c0:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    52c4:      	ldr	x8, [x8]
    52c8:      	ldr	w8, [x8]
    52cc:      	cbnz	w8, 0x5328 <perf_unwind_hotspot+0x5328>
    52d0:      	mov	w8, #0x2d               // =45
    52d4:      	adrp	x0, 0x5000 <perf_unwind_hotspot+0x5000>
    52d8:      	add	x9, sp, #0x12c
    52dc:      	str	w8, [sp, #0x12c]
    52e0:      	mov	w8, #0x1                // =1
    52e4:      	add	x1, sp, #0x12c
    52e8:      	ldr	x0, [x0]
    52ec:      	blr	x8
    52f0:      	cbz	x0, 0x5304 <perf_unwind_hotspot+0x5304>
    52f4:      	ldr	x8, [x0]
    52f8:      	add	x8, x8, #0x1
    52fc:      	str	x8, [x0]
    5300:      	b	0x5314 <perf_unwind_hotspot+0x5314>
    5304:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5308:      	ldr	x8, [x8]
    530c:      	ldr	w8, [x8]
    5310:      	cbnz	w8, 0x536c <perf_unwind_hotspot+0x536c>
    5314:      	adrp	x24, 0x5000 <perf_unwind_hotspot+0x5000>
    5318:      	ldr	x22, [sp, #0x138]
    531c:      	mov	w8, #0x3e9              // =1001
    5320:      	ldr	x24, [x24]
    5324:      	b	0x3cc <perf_unwind_hotspot+0x3cc>
    5328:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    532c:      	add	x8, x8, #0x0
    5330:      	add	x0, sp, #0x88
    5334:      	ldp	x9, x10, [x8, #0x10]
    5338:      	mov	w1, #0x2e               // =46
    533c:      	stp	x9, x10, [sp, #0x98]
    5340:      	ldr	x9, [x8, #0x20]
    5344:      	add	x10, sp, #0x88
    5348:      	str	x9, [sp, #0xa8]
    534c:      	ldur	x9, [x8, #0x26]
    5350:      	stur	x9, [sp, #0xae]
    5354:      	ldp	x9, x8, [x8]
    5358:      	stp	x9, x8, [sp, #0x88]
    535c:      	mov	w8, #0x2e               // =46
    5360:      	mov	w9, #0x6                // =6
    5364:      	blr	x9
    5368:      	b	0x52d0 <perf_unwind_hotspot+0x52d0>
    536c:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5370:      	add	x8, x8, #0x0
    5374:      	add	x0, sp, #0x88
    5378:      	ldp	x9, x10, [x8, #0x10]
    537c:      	mov	w1, #0x2e               // =46
    5380:      	stp	x9, x10, [sp, #0x98]
    5384:      	ldr	x9, [x8, #0x20]
    5388:      	add	x10, sp, #0x88
    538c:      	str	x9, [sp, #0xa8]
    5390:      	ldur	x9, [x8, #0x26]
    5394:      	stur	x9, [sp, #0xae]
    5398:      	ldp	x9, x8, [x8]
    539c:      	stp	x9, x8, [sp, #0x88]
    53a0:      	mov	w8, #0x2e               // =46
    53a4:      	mov	w9, #0x6                // =6
    53a8:      	ldr	w2, [sp, #0x12c]
    53ac:      	blr	x9
    53b0:      	b	0x5314 <perf_unwind_hotspot+0x5314>
    53b4:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    53b8:      	add	x8, x8, #0x0
    53bc:      	add	x0, sp, #0xc8
    53c0:      	ldp	x9, x10, [x8]
    53c4:      	ldur	x8, [x8, #0xd]
    53c8:      	mov	w1, #0x15               // =21
    53cc:      	str	x9, [sp, #0xc8]
    53d0:      	add	x9, sp, #0xc8
    53d4:      	str	x10, [x9, #0x8]
    53d8:      	stur	x8, [x9, #0xd]
    53dc:      	mov	w8, #0x15               // =21
    53e0:      	mov	w9, #0x6                // =6
    53e4:      	add	x10, sp, #0xc8
    53e8:      	blr	x9
    53ec:      	b	0x4578 <perf_unwind_hotspot+0x4578>
    53f0:      	mov	w8, #0x786c             // =30828
    53f4:      	add	x11, sp, #0xc8
    53f8:      	add	x0, sp, #0xc8
    53fc:      	mov	w1, #0x24               // =36
    5400:      	mov	x2, x24
    5404:      	mov	x3, x29
    5408:      	movk	w8, #0xa, lsl #16
    540c:      	str	w8, [sp, #0xe8]
    5410:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5414:      	add	x8, x8, #0x0
    5418:      	ldp	x9, x10, [x8]
    541c:      	str	x9, [sp, #0xc8]
    5420:      	ldp	x9, x8, [x8, #0x10]
    5424:      	stp	x10, x9, [x11, #0x8]
    5428:      	str	x8, [x11, #0x18]
    542c:      	mov	w8, #0x24               // =36
    5430:      	mov	w9, #0x6                // =6
    5434:      	add	x10, sp, #0xc8
    5438:      	ldr	x4, [sp, #0x38]
    543c:      	blr	x9
    5440:      	b	0x45e4 <perf_unwind_hotspot+0x45e4>
    5444:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5448:      	add	x8, x8, #0x0
    544c:      	add	x12, sp, #0xc8
    5450:      	ldp	x9, x10, [x8, #0x10]
    5454:      	ldr	x11, [x8, #0x20]
    5458:      	add	x0, sp, #0xc8
    545c:      	mov	w1, #0x2e               // =46
    5460:      	stp	x10, x11, [x12, #0x18]
    5464:      	ldur	x10, [x8, #0x26]
    5468:      	stur	x10, [x12, #0x26]
    546c:      	ldp	x10, x8, [x8]
    5470:      	str	x10, [sp, #0xc8]
    5474:      	stp	x8, x9, [x12, #0x8]
    5478:      	mov	w8, #0x2e               // =46
    547c:      	mov	w9, #0x6                // =6
    5480:      	add	x10, sp, #0xc8
    5484:      	ldr	w2, [sp, #0x88]
    5488:      	blr	x9
    548c:      	b	0x462c <perf_unwind_hotspot+0x462c>
    5490:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5494:      	add	x8, x8, #0x0
    5498:      	add	x13, sp, #0xc8
    549c:      	strb	wzr, [sp, #0xf8]
    54a0:      	ldp	x9, x10, [x8, #0x10]
    54a4:      	add	x0, sp, #0xc8
    54a8:      	ldp	x11, x12, [x8, #0x20]
    54ac:      	mov	w1, #0x31               // =49
    54b0:      	str	x12, [x13, #0x28]
    54b4:      	stp	x10, x11, [x13, #0x18]
    54b8:      	ldp	x10, x8, [x8]
    54bc:      	str	x10, [sp, #0xc8]
    54c0:      	stp	x8, x9, [x13, #0x8]
    54c4:      	mov	w8, #0x31               // =49
    54c8:      	mov	w9, #0x6                // =6
    54cc:      	add	x10, sp, #0xc8
    54d0:      	ldr	w2, [x21, #0x2c0]
    54d4:      	blr	x9
    54d8:      	ldr	x29, [x21, #0xed0]
    54dc:      	lsr	x8, x29, #56
    54e0:      	cbnz	x8, 0x1644 <perf_unwind_hotspot+0x1644>
    54e4:      	b	0x4660 <perf_unwind_hotspot+0x4660>
    54e8:      	mov	w8, #0xa                // =10
    54ec:      	add	x13, sp, #0xc8
    54f0:      	add	x0, sp, #0xc8
    54f4:      	strh	w8, [sp, #0xf8]
    54f8:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    54fc:      	add	x8, x8, #0x0
    5500:      	mov	w1, #0x32               // =50
    5504:      	ldp	x9, x10, [x8, #0x10]
    5508:      	ldp	x11, x12, [x8, #0x20]
    550c:      	mov	x2, x29
    5510:      	mov	w4, w25
    5514:      	str	x12, [x13, #0x28]
    5518:      	stp	x10, x11, [x13, #0x18]
    551c:      	ldp	x10, x8, [x8]
    5520:      	str	x10, [sp, #0xc8]
    5524:      	add	x10, sp, #0xc8
    5528:      	stp	x8, x9, [x13, #0x8]
    552c:      	mov	w8, #0x32               // =50
    5530:      	mov	w9, #0x6                // =6
    5534:      	ldr	x3, [x21, #0xf00]
    5538:      	blr	x9
    553c:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5540:      	ldr	x8, [x8]
    5544:      	ldr	w8, [x8]
    5548:      	cbz	w8, 0x46c8 <perf_unwind_hotspot+0x46c8>
    554c:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5550:      	add	x8, x8, #0x0
    5554:      	add	x12, sp, #0xc8
    5558:      	ldp	x9, x10, [x8, #0x10]
    555c:      	ldr	x11, [x8, #0x20]
    5560:      	add	x0, sp, #0xc8
    5564:      	mov	w1, #0x2f               // =47
    5568:      	stp	x10, x11, [x12, #0x18]
    556c:      	ldur	x10, [x8, #0x27]
    5570:      	stur	x10, [x12, #0x27]
    5574:      	ldp	x10, x8, [x8]
    5578:      	str	x10, [sp, #0xc8]
    557c:      	stp	x8, x9, [x12, #0x8]
    5580:      	mov	w8, #0x2f               // =47
    5584:      	mov	w9, #0x6                // =6
    5588:      	add	x10, sp, #0xc8
    558c:      	ldr	x2, [x21, #0xf10]
    5590:      	ldr	x3, [x21, #0xf08]
    5594:      	blr	x9
    5598:      	b	0x46c8 <perf_unwind_hotspot+0x46c8>
    559c:      	str	wzr, [sp, #0x88]
    55a0:      	adrp	x0, 0x5000 <perf_unwind_hotspot+0x5000>
    55a4:      	mov	w8, #0x1                // =1
    55a8:      	add	x9, sp, #0x88
    55ac:      	ldr	x0, [x0]
    55b0:      	add	x1, sp, #0x88
    55b4:      	blr	x8
    55b8:      	cbz	x0, 0x5724 <perf_unwind_hotspot+0x5724>
    55bc:      	ldr	x8, [x0]
    55c0:      	add	x8, x8, #0x1
    55c4:      	str	x8, [x0]
    55c8:      	b	0x577c <perf_unwind_hotspot+0x577c>
    55cc:      	mov	w8, #0x656e             // =25966
    55d0:      	add	x11, sp, #0xc8
    55d4:      	add	x0, sp, #0xc8
    55d8:      	mov	w1, #0x1b               // =27
    55dc:      	movk	w8, #0xa, lsl #16
    55e0:      	stur	w8, [x11, #0x17]
    55e4:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    55e8:      	add	x8, x8, #0x0
    55ec:      	ldp	x9, x10, [x8]
    55f0:      	ldr	x8, [x8, #0x10]
    55f4:      	str	x9, [sp, #0xc8]
    55f8:      	mov	w9, #0x6                // =6
    55fc:      	stp	x10, x8, [x11, #0x8]
    5600:      	mov	w8, #0x1b               // =27
    5604:      	add	x10, sp, #0xc8
    5608:      	blr	x9
    560c:      	mov	w25, #0x1               // =1
    5610:      	b	0x47ac <perf_unwind_hotspot+0x47ac>
    5614:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5618:      	add	x8, x8, #0x0
    561c:      	add	x12, sp, #0xc8
    5620:      	ldp	x9, x10, [x8, #0x10]
    5624:      	ldr	x11, [x8, #0x20]
    5628:      	add	x0, sp, #0xc8
    562c:      	mov	w1, #0x2e               // =46
    5630:      	stp	x10, x11, [x12, #0x18]
    5634:      	ldur	x10, [x8, #0x26]
    5638:      	stur	x10, [x12, #0x26]
    563c:      	ldp	x10, x8, [x8]
    5640:      	str	x10, [sp, #0xc8]
    5644:      	stp	x8, x9, [x12, #0x8]
    5648:      	mov	w8, #0x2e               // =46
    564c:      	mov	w9, #0x6                // =6
    5650:      	add	x10, sp, #0xc8
    5654:      	ldr	w2, [sp, #0x50]
    5658:      	blr	x9
    565c:      	b	0x47e4 <perf_unwind_hotspot+0x47e4>
    5660:      	mov	w9, #0x616e             // =24942
    5664:      	movk	w9, #0x6974, lsl #16
    5668:      	cmp	w19, w9
    566c:      	b.eq	0x5680 <perf_unwind_hotspot+0x5680>
    5670:      	mov	w9, #0x6d6e             // =28014
    5674:      	movk	w9, #0x7465, lsl #16
    5678:      	cmp	w19, w9
    567c:      	b.ne	0x5784 <perf_unwind_hotspot+0x5784>
    5680:      	ldr	x9, [sp, #0x68]
    5684:      	ldrb	w10, [x23, #0x21]
    5688:      	add	x11, x24, w9, uxtw
    568c:      	ldr	w19, [sp, #0x7c]
    5690:      	cmp	w10, #0x0
    5694:      	csel	x9, x9, x11, eq
    5698:      	cmp	x22, x9
    569c:      	b.ne	0x58a4 <perf_unwind_hotspot+0x58a4>
    56a0:      	ldr	w8, [sp, #0x74]
    56a4:      	ldr	x12, [sp, #0x38]
    56a8:      	mov	w9, #0x8                // =8
    56ac:      	mov	w10, #0x70              // =112
    56b0:      	add	x11, sp, #0x88
    56b4:      	add	x0, sp, #0x88
    56b8:      	mov	w1, #0x8                // =8
    56bc:      	add	x8, x12, x8
    56c0:      	ldr	w8, [sp, #0x74]
    56c4:      	add	x2, x12, x8
    56c8:      	blr	x10
    56cc:      	cbnz	x0, 0x57f0 <perf_unwind_hotspot+0x57f0>
    56d0:      	ldr	x9, [sp, #0x88]
    56d4:      	ldr	x8, [sp, #0x58]
    56d8:      	cmp	x9, x8
    56dc:      	b.lo	0x57f0 <perf_unwind_hotspot+0x57f0>
    56e0:      	ldr	x10, [sp, #0x60]
    56e4:      	cmp	x9, x10
    56e8:      	b.hs	0x57f0 <perf_unwind_hotspot+0x57f0>
    56ec:      	adrp	x10, 0x5000 <perf_unwind_hotspot+0x5000>
    56f0:      	ldr	x10, [x10]
    56f4:      	ldr	w10, [x10]
    56f8:      	cbnz	w10, 0x5844 <perf_unwind_hotspot+0x5844>
    56fc:      	mov	x22, x9
    5700:      	b	0x589c <perf_unwind_hotspot+0x589c>
    5704:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5708:      	mov	w19, #0x7476            // =29814
    570c:      	ldr	x8, [x8]
    5710:      	movk	w19, #0x6261, lsl #16
    5714:      	ldr	w8, [x8]
    5718:      	cbnz	w8, 0x58d8 <perf_unwind_hotspot+0x58d8>
    571c:      	mov	x22, #0x1000000000000000 // =1152921504606846976
    5720:      	b	0x5a10 <perf_unwind_hotspot+0x5a10>
    5724:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5728:      	ldr	x8, [x8]
    572c:      	ldr	w8, [x8]
    5730:      	cbz	w8, 0x577c <perf_unwind_hotspot+0x577c>
    5734:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5738:      	add	x8, x8, #0x0
    573c:      	add	x12, sp, #0xc8
    5740:      	ldp	x9, x10, [x8, #0x10]
    5744:      	ldr	x11, [x8, #0x20]
    5748:      	add	x0, sp, #0xc8
    574c:      	mov	w1, #0x2e               // =46
    5750:      	stp	x10, x11, [x12, #0x18]
    5754:      	ldur	x10, [x8, #0x26]
    5758:      	stur	x10, [x12, #0x26]
    575c:      	ldp	x10, x8, [x8]
    5760:      	str	x10, [sp, #0xc8]
    5764:      	stp	x8, x9, [x12, #0x8]
    5768:      	mov	w8, #0x2e               // =46
    576c:      	mov	w9, #0x6                // =6
    5770:      	add	x10, sp, #0xc8
    5774:      	ldr	w2, [sp, #0x88]
    5778:      	blr	x9
    577c:      	ldrh	w25, [x25, #0x20]
    5780:      	b	0x47ac <perf_unwind_hotspot+0x47ac>
    5784:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5788:      	ldr	x23, [x21, #0xf00]
    578c:      	ldr	x8, [x8]
    5790:      	ldr	w8, [x8]
    5794:      	tbnz	x23, #0x3f, 0x5914 <perf_unwind_hotspot+0x5914>
    5798:      	cbz	w8, 0x57e0 <perf_unwind_hotspot+0x57e0>
    579c:      	mov	w8, #0x6874             // =26740
    57a0:      	add	x11, sp, #0xc8
    57a4:      	add	x0, sp, #0xc8
    57a8:      	mov	w1, #0x24               // =36
    57ac:      	movk	w8, #0xa, lsl #16
    57b0:      	str	w8, [sp, #0xe8]
    57b4:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    57b8:      	add	x8, x8, #0x0
    57bc:      	ldp	x9, x10, [x8]
    57c0:      	str	x9, [sp, #0xc8]
    57c4:      	ldp	x9, x8, [x8, #0x10]
    57c8:      	stp	x10, x9, [x11, #0x8]
    57cc:      	str	x8, [x11, #0x18]
    57d0:      	mov	w8, #0x24               // =36
    57d4:      	mov	w9, #0x6                // =6
    57d8:      	add	x10, sp, #0xc8
    57dc:      	blr	x9
    57e0:      	ldr	w8, [sp, #0x78]
    57e4:      	mov	x22, xzr
    57e8:      	cbnz	w8, 0x5a70 <perf_unwind_hotspot+0x5a70>
    57ec:      	b	0x59fc <perf_unwind_hotspot+0x59fc>
    57f0:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    57f4:      	ldr	x8, [x8]
    57f8:      	ldr	w8, [x8]
    57fc:      	cbz	w8, 0x58a0 <perf_unwind_hotspot+0x58a0>
    5800:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5804:      	add	x8, x8, #0x0
    5808:      	add	x13, sp, #0xc8
    580c:      	ldp	x9, x10, [x8, #0x10]
    5810:      	ldp	x11, x12, [x8, #0x20]
    5814:      	add	x0, sp, #0xc8
    5818:      	mov	w1, #0x30               // =48
    581c:      	str	x12, [x13, #0x28]
    5820:      	stp	x10, x11, [x13, #0x18]
    5824:      	ldp	x10, x8, [x8]
    5828:      	str	x10, [sp, #0xc8]
    582c:      	stp	x8, x9, [x13, #0x8]
    5830:      	mov	w8, #0x30               // =48
    5834:      	mov	w9, #0x6                // =6
    5838:      	add	x10, sp, #0xc8
    583c:      	blr	x9
    5840:      	b	0x58a0 <perf_unwind_hotspot+0x58a0>
    5844:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5848:      	add	x8, x8, #0x0
    584c:      	add	x13, sp, #0xc8
    5850:      	ldp	x9, x10, [x8, #0x20]
    5854:      	ldp	x11, x12, [x8, #0x30]
    5858:      	add	x0, sp, #0xc8
    585c:      	mov	w1, #0x40               // =64
    5860:      	str	x12, [x13, #0x38]
    5864:      	stp	x10, x11, [x13, #0x28]
    5868:      	ldp	x10, x11, [x8]
    586c:      	str	x10, [sp, #0xc8]
    5870:      	ldp	x10, x8, [x8, #0x10]
    5874:      	stp	x11, x10, [x13, #0x8]
    5878:      	add	x10, sp, #0xc8
    587c:      	stp	x8, x9, [x13, #0x18]
    5880:      	mov	w8, #0x40               // =64
    5884:      	mov	w9, #0x6                // =6
    5888:      	ldr	x2, [sp, #0x88]
    588c:      	ldr	w3, [sp, #0x74]
    5890:      	blr	x9
    5894:      	ldr	x22, [sp, #0x88]
    5898:      	ldr	x8, [sp, #0x58]
    589c:      	sub	w29, w22, w8
    58a0:      	ldr	x8, [sp, #0x58]
    58a4:      	ldrh	w9, [sp, #0x80]
    58a8:      	add	x8, x8, x9
    58ac:      	cmp	x22, x8
    58b0:      	b.hs	0x5980 <perf_unwind_hotspot+0x5980>
    58b4:      	sub	x8, x8, #0x4
    58b8:      	cmp	x22, x8
    58bc:      	b.ne	0x5a0c <perf_unwind_hotspot+0x5a0c>
    58c0:      	ldr	w8, [sp, #0x78]
    58c4:      	ldr	x9, [sp, #0x38]
    58c8:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    58cc:      	add	x9, x9, x8
    58d0:      	str	x9, [sp, #0x38]
    58d4:      	b	0x5a10 <perf_unwind_hotspot+0x5a10>
    58d8:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    58dc:      	add	x8, x8, #0x0
    58e0:      	add	x0, sp, #0xc8
    58e4:      	ldp	x9, x10, [x8]
    58e8:      	ldr	x8, [x8, #0x10]
    58ec:      	mov	w1, #0x18               // =24
    58f0:      	str	x9, [sp, #0xc8]
    58f4:      	add	x9, sp, #0xc8
    58f8:      	stp	x10, x8, [x9, #0x8]
    58fc:      	mov	w8, #0x18               // =24
    5900:      	mov	w9, #0x6                // =6
    5904:      	add	x10, sp, #0xc8
    5908:      	blr	x9
    590c:      	mov	x22, #0x1000000000000000 // =1152921504606846976
    5910:      	b	0x5a10 <perf_unwind_hotspot+0x5a10>
    5914:      	cbz	w8, 0x5960 <perf_unwind_hotspot+0x5960>
    5918:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    591c:      	add	x8, x8, #0x0
    5920:      	add	x13, sp, #0xc8
    5924:      	strb	wzr, [sp, #0xf8]
    5928:      	ldp	x9, x10, [x8, #0x10]
    592c:      	add	x0, sp, #0xc8
    5930:      	ldp	x11, x12, [x8, #0x20]
    5934:      	mov	w1, #0x31               // =49
    5938:      	mov	x2, x23
    593c:      	str	x12, [x13, #0x28]
    5940:      	stp	x10, x11, [x13, #0x18]
    5944:      	ldp	x10, x8, [x8]
    5948:      	str	x10, [sp, #0xc8]
    594c:      	add	x10, sp, #0xc8
    5950:      	stp	x8, x9, [x13, #0x8]
    5954:      	mov	w8, #0x31               // =49
    5958:      	mov	w9, #0x6                // =6
    595c:      	blr	x9
    5960:      	mov	x22, xzr
    5964:      	tbnz	x23, #0x3e, 0x59fc <perf_unwind_hotspot+0x59fc>
    5968:      	ldr	x9, [sp, #0x38]
    596c:      	lsr	x8, x23, #53
    5970:      	and	x8, x8, #0x1f8
    5974:      	add	x9, x8, x9
    5978:      	str	x9, [sp, #0x38]
    597c:      	b	0x5a10 <perf_unwind_hotspot+0x5a10>
    5980:      	ldp	x8, x9, [sp, #0x30]
    5984:      	subs	x2, x8, x9
    5988:      	b.lo	0x5a20 <perf_unwind_hotspot+0x5a20>
    598c:      	ldr	w8, [sp, #0x78]
    5990:      	ldp	x9, x10, [sp, #0x30]
    5994:      	add	x8, x10, x8
    5998:      	add	x8, x8, #0x30
    599c:      	cmp	x9, x8
    59a0:      	b.hs	0x5a20 <perf_unwind_hotspot+0x5a20>
    59a4:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    59a8:      	ldr	x8, [x8]
    59ac:      	ldr	w8, [x8]
    59b0:      	cbz	w8, 0x59f8 <perf_unwind_hotspot+0x59f8>
    59b4:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    59b8:      	add	x8, x8, #0x0
    59bc:      	add	x11, sp, #0xc8
    59c0:      	ldp	x9, x10, [x8, #0x18]
    59c4:      	add	x0, sp, #0xc8
    59c8:      	mov	w1, #0x2f               // =47
    59cc:      	stp	x9, x10, [x11, #0x18]
    59d0:      	ldur	x10, [x8, #0x27]
    59d4:      	stur	x10, [x11, #0x27]
    59d8:      	ldr	x10, [x8]
    59dc:      	ldp	x8, x9, [x8, #0x8]
    59e0:      	str	x10, [sp, #0xc8]
    59e4:      	stp	x8, x9, [x11, #0x8]
    59e8:      	mov	w8, #0x2f               // =47
    59ec:      	mov	w9, #0x6                // =6
    59f0:      	add	x10, sp, #0xc8
    59f4:      	blr	x9
    59f8:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    59fc:      	ldr	x9, [sp, #0x30]
    5a00:      	mov	w8, #0x10               // =16
    5a04:      	str	w8, [sp, #0x78]
    5a08:      	b	0x5a6c <perf_unwind_hotspot+0x5a6c>
    5a0c:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    5a10:      	ldrb	w8, [x21, #0xf21]
    5a14:      	cbnz	w8, 0x7bc <perf_unwind_hotspot+0x7bc>
    5a18:      	ldr	x25, [x21, #0xee8]
    5a1c:      	b	0x5af8 <perf_unwind_hotspot+0x5af8>
    5a20:      	sub	x2, x22, #0x8
    5a24:      	mov	w8, #0x8                // =8
    5a28:      	mov	w9, #0x70               // =112
    5a2c:      	add	x10, sp, #0xc8
    5a30:      	add	x0, sp, #0xc8
    5a34:      	mov	w1, #0x8                // =8
    5a38:      	blr	x9
    5a3c:      	ldr	x8, [sp, #0xc8]
    5a40:      	mov	x9, #0x27ff             // =10239
    5a44:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    5a48:      	movk	x9, #0xa9bf, lsl #16
    5a4c:      	movk	x9, #0x100, lsl #32
    5a50:      	movk	x9, #0xd63f, lsl #48
    5a54:      	cmp	x8, x9
    5a58:      	ldr	x9, [sp, #0x38]
    5a5c:      	ccmp	x0, #0x0, #0x0, eq
    5a60:      	add	x8, x9, #0x10
    5a64:      	csel	x9, x8, x9, eq
    5a68:      	ldr	w8, [sp, #0x78]
    5a6c:      	str	x9, [sp, #0x38]
    5a70:      	ldr	x9, [sp, #0x38]
    5a74:      	add	x10, sp, #0x88
    5a78:      	add	x0, sp, #0x88
    5a7c:      	mov	w1, #0x10               // =16
    5a80:      	add	x9, x9, w8, uxtw
    5a84:      	mov	w8, #0x10               // =16
    5a88:      	str	x9, [sp, #0x38]
    5a8c:      	sub	x2, x9, #0x10
    5a90:      	mov	w9, #0x70               // =112
    5a94:      	blr	x9
    5a98:      	ldr	w8, [sp, #0x78]
    5a9c:      	ldr	x25, [sp, #0x90]
    5aa0:      	cmp	w8, #0x10
    5aa4:      	b.lo	0x5af8 <perf_unwind_hotspot+0x5af8>
    5aa8:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5aac:      	ldr	x8, [x8]
    5ab0:      	ldr	w8, [x8]
    5ab4:      	cbz	w8, 0x5af0 <perf_unwind_hotspot+0x5af0>
    5ab8:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5abc:      	add	x8, x8, #0x0
    5ac0:      	add	x0, sp, #0xc8
    5ac4:      	ldp	x9, x10, [x8]
    5ac8:      	ldur	x8, [x8, #0xd]
    5acc:      	mov	w1, #0x15               // =21
    5ad0:      	str	x9, [sp, #0xc8]
    5ad4:      	add	x9, sp, #0xc8
    5ad8:      	str	x10, [x9, #0x8]
    5adc:      	stur	x8, [x9, #0xd]
    5ae0:      	mov	w8, #0x15               // =21
    5ae4:      	mov	w9, #0x6                // =6
    5ae8:      	add	x10, sp, #0xc8
    5aec:      	blr	x9
    5af0:      	ldr	x8, [sp, #0x88]
    5af4:      	str	x8, [sp, #0x30]
    5af8:      	ldr	w8, [x21, #0x2c0]
    5afc:      	cmp	w8, #0x7e
    5b00:      	b.hi	0x1508 <perf_unwind_hotspot+0x1508>
    5b04:      	mov	w11, w19
    5b08:      	and	x10, x22, #0x3000000000000000
    5b0c:      	ldrb	w9, [x21, #0xf20]
    5b10:      	orr	x11, x11, x29, lsl #32
    5b14:      	orr	x10, x11, x10
    5b18:      	add	w11, w8, #0x1
    5b1c:      	str	w11, [x21, #0x2c0]
    5b20:      	mov	w11, #0x18              // =24
    5b24:      	umaddl	x8, w8, w11, x21
    5b28:      	str	x10, [x8, #0x2d8]
    5b2c:      	mov	w10, #0x5               // =5
    5b30:      	str	x24, [x8, #0x2d0]
    5b34:      	strb	w9, [x8, #0x2e1]
    5b38:      	strh	wzr, [x8, #0x2e6]
    5b3c:      	strb	w10, [x8, #0x2e0]
    5b40:      	add	x10, x8, #0x2d0
    5b44:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5b48:      	stur	wzr, [x10, #0x12]
    5b4c:      	ldr	x8, [x8]
    5b50:      	ldr	w8, [x8]
    5b54:      	cbz	w8, 0x5ba4 <perf_unwind_hotspot+0x5ba4>
    5b58:      	mov	w8, #0x786c             // =30828
    5b5c:      	add	x11, sp, #0xc8
    5b60:      	add	x0, sp, #0xc8
    5b64:      	mov	w1, #0x24               // =36
    5b68:      	mov	x2, x25
    5b6c:      	movk	w8, #0xa, lsl #16
    5b70:      	str	w8, [sp, #0xe8]
    5b74:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5b78:      	add	x8, x8, #0x0
    5b7c:      	ldp	x9, x10, [x8]
    5b80:      	str	x9, [sp, #0xc8]
    5b84:      	ldp	x9, x8, [x8, #0x10]
    5b88:      	stp	x10, x9, [x11, #0x8]
    5b8c:      	str	x8, [x11, #0x18]
    5b90:      	mov	w8, #0x24               // =36
    5b94:      	mov	w9, #0x6                // =6
    5b98:      	add	x10, sp, #0xc8
    5b9c:      	ldp	x4, x3, [sp, #0x30]
    5ba0:      	blr	x9
    5ba4:      	ldp	x8, x9, [sp, #0x30]
    5ba8:      	adrp	x0, 0x5000 <perf_unwind_hotspot+0x5000>
    5bac:      	add	x1, sp, #0x88
    5bb0:      	str	x25, [x21, #0xed0]
    5bb4:      	str	x8, [x21, #0xee0]
    5bb8:      	mov	w8, #0x101              // =257
    5bbc:      	str	x9, [x21, #0xed8]
    5bc0:      	add	x9, sp, #0x88
    5bc4:      	strh	w8, [x21, #0xf20]
    5bc8:      	mov	w8, #0x2a               // =42
    5bcc:      	str	w8, [sp, #0x88]
    5bd0:      	mov	w8, #0x1                // =1
    5bd4:      	ldr	x0, [x0]
    5bd8:      	blr	x8
    5bdc:      	cbz	x0, 0x5bf0 <perf_unwind_hotspot+0x5bf0>
    5be0:      	ldr	x8, [x0]
    5be4:      	add	x8, x8, #0x1
    5be8:      	str	x8, [x0]
    5bec:      	b	0x5c48 <perf_unwind_hotspot+0x5c48>
    5bf0:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5bf4:      	ldr	x8, [x8]
    5bf8:      	ldr	w8, [x8]
    5bfc:      	cbz	w8, 0x5c54 <perf_unwind_hotspot+0x5c54>
    5c00:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5c04:      	add	x8, x8, #0x0
    5c08:      	add	x12, sp, #0xc8
    5c0c:      	ldp	x9, x10, [x8, #0x10]
    5c10:      	ldr	x11, [x8, #0x20]
    5c14:      	add	x0, sp, #0xc8
    5c18:      	mov	w1, #0x2e               // =46
    5c1c:      	stp	x10, x11, [x12, #0x18]
    5c20:      	ldur	x10, [x8, #0x26]
    5c24:      	stur	x10, [x12, #0x26]
    5c28:      	ldp	x10, x8, [x8]
    5c2c:      	str	x10, [sp, #0xc8]
    5c30:      	stp	x8, x9, [x12, #0x8]
    5c34:      	mov	w8, #0x2e               // =46
    5c38:      	mov	w9, #0x6                // =6
    5c3c:      	add	x10, sp, #0xc8
    5c40:      	ldr	w2, [sp, #0x88]
    5c44:      	blr	x9
    5c48:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5c4c:      	ldr	x8, [x8]
    5c50:      	ldr	w8, [x8]
    5c54:      	ldr	x29, [x21, #0xed0]
    5c58:      	cbz	x29, 0x5eac <perf_unwind_hotspot+0x5eac>
    5c5c:      	cbz	w8, 0x5cac <perf_unwind_hotspot+0x5cac>
    5c60:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5c64:      	add	x8, x8, #0x0
    5c68:      	add	x13, sp, #0xc8
    5c6c:      	strb	wzr, [sp, #0xf8]
    5c70:      	ldp	x9, x10, [x8, #0x10]
    5c74:      	add	x0, sp, #0xc8
    5c78:      	ldp	x11, x12, [x8, #0x20]
    5c7c:      	mov	w1, #0x31               // =49
    5c80:      	str	x12, [x13, #0x28]
    5c84:      	stp	x10, x11, [x13, #0x18]
    5c88:      	ldp	x10, x8, [x8]
    5c8c:      	str	x10, [sp, #0xc8]
    5c90:      	stp	x8, x9, [x13, #0x8]
    5c94:      	mov	w8, #0x31               // =49
    5c98:      	mov	w9, #0x6                // =6
    5c9c:      	add	x10, sp, #0xc8
    5ca0:      	ldr	w2, [x21, #0x2c0]
    5ca4:      	blr	x9
    5ca8:      	ldr	x29, [x21, #0xed0]
    5cac:      	lsr	x8, x29, #56
    5cb0:      	cbnz	x8, 0x1644 <perf_unwind_hotspot+0x1644>
    5cb4:      	cmp	x29, #0x1, lsl #12      // =0x1000
    5cb8:      	b.lo	0x1798 <perf_unwind_hotspot+0x1798>
    5cbc:      	ldr	w8, [x21]
    5cc0:      	mov	w9, #0x60               // =96
    5cc4:      	add	x1, sp, #0x50
    5cc8:      	mov	x0, x20
    5ccc:      	rev	w8, w8
    5cd0:      	stp	w9, w8, [sp, #0x50]
    5cd4:      	rev	x8, x29
    5cd8:      	add	x9, sp, #0x50
    5cdc:      	str	x8, [sp, #0x58]
    5ce0:      	mov	w8, #0x1                // =1
    5ce4:      	blr	x8
    5ce8:      	cbz	x0, 0x5ee0 <perf_unwind_hotspot+0x5ee0>
    5cec:      	ldr	x8, [x0, #0x8]
    5cf0:      	and	x9, x8, #0xffffffffffffff
    5cf4:      	lsr	x25, x8, #56
    5cf8:      	str	x9, [x21, #0xf10]
    5cfc:      	ldr	x8, [x0]
    5d00:      	str	x8, [x21, #0xf00]
    5d04:      	sub	x8, x29, x9
    5d08:      	str	x8, [x21, #0xf08]
    5d0c:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5d10:      	ldr	x8, [x8]
    5d14:      	ldr	w8, [x8]
    5d18:      	cbz	w8, 0x5dcc <perf_unwind_hotspot+0x5dcc>
    5d1c:      	mov	w8, #0xa                // =10
    5d20:      	add	x13, sp, #0xc8
    5d24:      	add	x0, sp, #0xc8
    5d28:      	strh	w8, [sp, #0xf8]
    5d2c:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5d30:      	add	x8, x8, #0x0
    5d34:      	mov	w1, #0x32               // =50
    5d38:      	ldp	x9, x10, [x8, #0x10]
    5d3c:      	ldp	x11, x12, [x8, #0x20]
    5d40:      	mov	x2, x29
    5d44:      	mov	w4, w25
    5d48:      	str	x12, [x13, #0x28]
    5d4c:      	stp	x10, x11, [x13, #0x18]
    5d50:      	ldp	x10, x8, [x8]
    5d54:      	str	x10, [sp, #0xc8]
    5d58:      	add	x10, sp, #0xc8
    5d5c:      	stp	x8, x9, [x13, #0x8]
    5d60:      	mov	w8, #0x32               // =50
    5d64:      	mov	w9, #0x6                // =6
    5d68:      	ldr	x3, [x21, #0xf00]
    5d6c:      	blr	x9
    5d70:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5d74:      	ldr	x8, [x8]
    5d78:      	ldr	w8, [x8]
    5d7c:      	cbz	w8, 0x5dcc <perf_unwind_hotspot+0x5dcc>
    5d80:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5d84:      	add	x8, x8, #0x0
    5d88:      	add	x12, sp, #0xc8
    5d8c:      	ldp	x9, x10, [x8, #0x10]
    5d90:      	ldr	x11, [x8, #0x20]
    5d94:      	add	x0, sp, #0xc8
    5d98:      	mov	w1, #0x2f               // =47
    5d9c:      	stp	x10, x11, [x12, #0x18]
    5da0:      	ldur	x10, [x8, #0x27]
    5da4:      	stur	x10, [x12, #0x27]
    5da8:      	ldp	x10, x8, [x8]
    5dac:      	str	x10, [sp, #0xc8]
    5db0:      	stp	x8, x9, [x12, #0x8]
    5db4:      	mov	w8, #0x2f               // =47
    5db8:      	mov	w9, #0x6                // =6
    5dbc:      	add	x10, sp, #0xc8
    5dc0:      	ldr	x2, [x21, #0xf10]
    5dc4:      	ldr	x3, [x21, #0xf08]
    5dc8:      	blr	x9
    5dcc:      	cmp	w25, #0x1
    5dd0:      	b.ne	0x6074 <perf_unwind_hotspot+0x6074>
    5dd4:      	ldr	x8, [x21, #0xf00]
    5dd8:      	adrp	x0, 0x5000 <perf_unwind_hotspot+0x5000>
    5ddc:      	ldr	x19, [x21, #0xf08]
    5de0:      	mov	w9, #0x1                // =1
    5de4:      	add	x1, sp, #0x50
    5de8:      	mov	w25, #0x1               // =1
    5dec:      	str	x8, [sp, #0x50]
    5df0:      	add	x8, sp, #0x50
    5df4:      	ldr	x0, [x0]
    5df8:      	blr	x9
    5dfc:      	cbz	x0, 0x5f9c <perf_unwind_hotspot+0x5f9c>
    5e00:      	ldr	x8, [x0]
    5e04:      	mov	x23, x0
    5e08:      	cmp	x8, x19
    5e0c:      	b.hi	0x5e1c <perf_unwind_hotspot+0x5e1c>
    5e10:      	ldr	x8, [x23, #0x8]
    5e14:      	cmp	x8, x19
    5e18:      	b.hs	0x5e34 <perf_unwind_hotspot+0x5e34>
    5e1c:      	ldr	x8, [x23, #0x10]
    5e20:      	cmp	x8, x19
    5e24:      	b.hi	0x5ea4 <perf_unwind_hotspot+0x5ea4>
    5e28:      	ldr	x8, [x23, #0x18]
    5e2c:      	cmp	x8, x19
    5e30:      	b.lo	0x5ea4 <perf_unwind_hotspot+0x5ea4>
    5e34:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5e38:      	ldr	x8, [x8]
    5e3c:      	ldr	w8, [x8]
    5e40:      	cbz	w8, 0x5e84 <perf_unwind_hotspot+0x5e84>
    5e44:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5e48:      	add	x8, x8, #0x0
    5e4c:      	add	x11, sp, #0xc8
    5e50:      	ldp	x9, x10, [x8]
    5e54:      	add	x0, sp, #0xc8
    5e58:      	mov	w1, #0x1e               // =30
    5e5c:      	str	x9, [sp, #0xc8]
    5e60:      	ldr	x9, [x8, #0x10]
    5e64:      	ldur	x8, [x8, #0x16]
    5e68:      	stp	x10, x9, [x11, #0x8]
    5e6c:      	mov	w9, #0x6                // =6
    5e70:      	stur	x8, [x11, #0x16]
    5e74:      	mov	w8, #0x1e               // =30
    5e78:      	add	x10, sp, #0xc8
    5e7c:      	ldrh	w2, [x23, #0x20]
    5e80:      	blr	x9
    5e84:      	ldrh	w8, [x23, #0x20]
    5e88:      	ldr	w9, [x21, #0x1370]
    5e8c:      	lsr	w8, w9, w8
    5e90:      	tbz	w8, #0x0, 0x5fa0 <perf_unwind_hotspot+0x5fa0>
    5e94:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5e98:      	ldr	x8, [x8]
    5e9c:      	ldr	w8, [x8]
    5ea0:      	cbnz	w8, 0x5fd0 <perf_unwind_hotspot+0x5fd0>
    5ea4:      	mov	w25, #0x1               // =1
    5ea8:      	b	0x6074 <perf_unwind_hotspot+0x6074>
    5eac:      	cbnz	w8, 0x5f04 <perf_unwind_hotspot+0x5f04>
    5eb0:      	mov	w8, #0x1                // =1
    5eb4:      	mov	w25, wzr
    5eb8:      	str	w8, [x21, #0xf18]
    5ebc:      	mov	w8, #0xfad              // =4013
    5ec0:      	adrp	x24, 0x5000 <perf_unwind_hotspot+0x5000>
    5ec4:      	adrp	x19, 0x5000 <perf_unwind_hotspot+0x5000>
    5ec8:      	adrp	x23, 0x5000 <perf_unwind_hotspot+0x5000>
    5ecc:      	ldr	x22, [sp, #0x138]
    5ed0:      	ldr	x24, [x24]
    5ed4:      	ldr	x19, [x19]
    5ed8:      	ldr	x23, [x23]
    5edc:      	b	0x2b4 <perf_unwind_hotspot+0x2b4>
    5ee0:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5ee4:      	ldr	x8, [x8]
    5ee8:      	ldr	w8, [x8]
    5eec:      	cbnz	w8, 0x5f4c <perf_unwind_hotspot+0x5f4c>
    5ef0:      	mov	w8, #0xc                // =12
    5ef4:      	mov	w25, wzr
    5ef8:      	str	w8, [x21, #0xf18]
    5efc:      	mov	w8, #0xfac              // =4012
    5f00:      	b	0x5ec0 <perf_unwind_hotspot+0x5ec0>
    5f04:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5f08:      	add	x8, x8, #0x0
    5f0c:      	add	x13, sp, #0xc8
    5f10:      	strb	wzr, [sp, #0xf8]
    5f14:      	ldp	x9, x10, [x8, #0x10]
    5f18:      	add	x0, sp, #0xc8
    5f1c:      	ldp	x11, x12, [x8, #0x20]
    5f20:      	mov	w1, #0x31               // =49
    5f24:      	str	x12, [x13, #0x28]
    5f28:      	stp	x10, x11, [x13, #0x18]
    5f2c:      	ldp	x10, x8, [x8]
    5f30:      	str	x10, [sp, #0xc8]
    5f34:      	stp	x8, x9, [x13, #0x8]
    5f38:      	mov	w8, #0x31               // =49
    5f3c:      	mov	w9, #0x6                // =6
    5f40:      	add	x10, sp, #0xc8
    5f44:      	blr	x9
    5f48:      	b	0x5eb0 <perf_unwind_hotspot+0x5eb0>
    5f4c:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5f50:      	add	x8, x8, #0x0
    5f54:      	add	x13, sp, #0xc8
    5f58:      	strb	wzr, [sp, #0x100]
    5f5c:      	ldp	x9, x10, [x8, #0x20]
    5f60:      	add	x0, sp, #0xc8
    5f64:      	ldp	x12, x11, [x8, #0x10]
    5f68:      	mov	w1, #0x39               // =57
    5f6c:      	mov	x2, x29
    5f70:      	stp	x11, x9, [x13, #0x18]
    5f74:      	ldr	x9, [x8, #0x30]
    5f78:      	stp	x10, x9, [x13, #0x28]
    5f7c:      	ldp	x9, x8, [x8]
    5f80:      	add	x10, sp, #0xc8
    5f84:      	str	x9, [sp, #0xc8]
    5f88:      	stp	x8, x12, [x13, #0x8]
    5f8c:      	mov	w8, #0x39               // =57
    5f90:      	mov	w9, #0x6                // =6
    5f94:      	blr	x9
    5f98:      	b	0x5ef0 <perf_unwind_hotspot+0x5ef0>
    5f9c:      	b	0x6074 <perf_unwind_hotspot+0x6074>
    5fa0:      	str	wzr, [sp, #0x88]
    5fa4:      	adrp	x0, 0x5000 <perf_unwind_hotspot+0x5000>
    5fa8:      	mov	w8, #0x1                // =1
    5fac:      	add	x9, sp, #0x88
    5fb0:      	ldr	x0, [x0]
    5fb4:      	add	x1, sp, #0x88
    5fb8:      	blr	x8
    5fbc:      	cbz	x0, 0x6018 <perf_unwind_hotspot+0x6018>
    5fc0:      	ldr	x8, [x0]
    5fc4:      	add	x8, x8, #0x1
    5fc8:      	str	x8, [x0]
    5fcc:      	b	0x6070 <perf_unwind_hotspot+0x6070>
    5fd0:      	mov	w8, #0x656e             // =25966
    5fd4:      	add	x11, sp, #0xc8
    5fd8:      	add	x0, sp, #0xc8
    5fdc:      	mov	w1, #0x1b               // =27
    5fe0:      	movk	w8, #0xa, lsl #16
    5fe4:      	stur	w8, [x11, #0x17]
    5fe8:      	adrp	x8, 0x5000 <perf_unwind_hotspot+0x5000>
    5fec:      	add	x8, x8, #0x0
    5ff0:      	ldp	x9, x10, [x8]
    5ff4:      	ldr	x8, [x8, #0x10]
    5ff8:      	str	x9, [sp, #0xc8]
    5ffc:      	mov	w9, #0x6                // =6
    6000:      	stp	x10, x8, [x11, #0x8]
    6004:      	mov	w8, #0x1b               // =27
    6008:      	add	x10, sp, #0xc8
    600c:      	blr	x9
    6010:      	mov	w25, #0x1               // =1
    6014:      	b	0x6074 <perf_unwind_hotspot+0x6074>
    6018:      	adrp	x8, 0x6000 <perf_unwind_hotspot+0x6000>
    601c:      	ldr	x8, [x8]
    6020:      	ldr	w8, [x8]
    6024:      	cbz	w8, 0x6070 <perf_unwind_hotspot+0x6070>
    6028:      	adrp	x8, 0x6000 <perf_unwind_hotspot+0x6000>
    602c:      	add	x8, x8, #0x0
    6030:      	add	x12, sp, #0xc8
    6034:      	ldp	x9, x10, [x8, #0x10]
    6038:      	ldr	x11, [x8, #0x20]
    603c:      	add	x0, sp, #0xc8
    6040:      	mov	w1, #0x2e               // =46
    6044:      	stp	x10, x11, [x12, #0x18]
    6048:      	ldur	x10, [x8, #0x26]
    604c:      	stur	x10, [x12, #0x26]
    6050:      	ldp	x10, x8, [x8]
    6054:      	str	x10, [sp, #0xc8]
    6058:      	stp	x8, x9, [x12, #0x8]
    605c:      	mov	w8, #0x2e               // =46
    6060:      	mov	w9, #0x6                // =6
    6064:      	add	x10, sp, #0xc8
    6068:      	ldr	w2, [sp, #0x88]
    606c:      	blr	x9
    6070:      	ldrh	w25, [x23, #0x20]
    6074:      	mov	w8, wzr
    6078:      	b	0x5ec0 <perf_unwind_hotspot+0x5ec0>

Disassembly of section kprobe/unwind_hotspot:

0000000000000000 <kprobe_unwind_hotspot>:
       0:      	sub	sp, sp, #0x180
       4:      	str	x29, [sp, #0x130]
       8:      	stp	x30, x25, [sp, #0x140]
       c:      	stp	x24, x23, [sp, #0x150]
      10:      	stp	x22, x21, [sp, #0x160]
      14:      	stp	x20, x19, [sp, #0x170]
      18:      	mov	x19, x0
      1c:      	str	wzr, [sp, #0xc8]
      20:      	adrp	x0, 0x0 <kprobe_unwind_hotspot>
      24:      	mov	w8, #0x1                // =1
      28:      	ldr	x0, [x0]
      2c:      	add	x9, sp, #0xc8
      30:      	add	x1, sp, #0xc8
      34:      	blr	x8
      38:      	cbz	x0, 0x380 <kprobe_unwind_hotspot+0x380>
      3c:      	ldr	w8, [x0]
      40:      	adrp	x22, 0x0 <kprobe_unwind_hotspot>
      44:      	mov	x21, x0
      48:      	add	x20, sp, #0xc8
      4c:      	str	w8, [sp, #0x4c]
      50:      	ldr	x22, [x22]
      54:      	ldr	w8, [x22]
      58:      	cbnz	w8, 0x564 <kprobe_unwind_hotspot+0x564>
      5c:      	adrp	x0, 0x0 <kprobe_unwind_hotspot>
      60:      	mov	w8, #0x1                // =1
      64:      	add	x9, sp, #0x4c
      68:      	ldr	x0, [x0]
      6c:      	add	x1, sp, #0x4c
      70:      	blr	x8
      74:      	cbz	x0, 0x120 <kprobe_unwind_hotspot+0x120>
      78:      	mov	w8, #0x29               // =41
      7c:      	mov	x23, x0
      80:      	adrp	x0, 0x0 <kprobe_unwind_hotspot>
      84:      	str	w8, [sp, #0x50]
      88:      	mov	w8, #0x1                // =1
      8c:      	add	x9, sp, #0x50
      90:      	add	x1, sp, #0x50
      94:      	ldr	x0, [x0]
      98:      	blr	x8
      9c:      	str	x19, [sp, #0x138]
      a0:      	cbz	x0, 0x130 <kprobe_unwind_hotspot+0x130>
      a4:      	ldr	x8, [x0]
      a8:      	add	x8, x8, #0x1
      ac:      	str	x8, [x0]
      b0:      	ldr	w8, [x22]
      b4:      	ldr	x22, [x21, #0xed0]
      b8:      	ldr	x29, [x21, #0xed8]
      bc:      	ldr	x25, [x21, #0xee0]
      c0:      	cbz	w8, 0x144 <kprobe_unwind_hotspot+0x144>
      c4:      	mov	w8, #0x786c             // =30828
      c8:      	add	x13, sp, #0xc8
      cc:      	add	x0, sp, #0xc8
      d0:      	mov	w1, #0x2c               // =44
      d4:      	add	x20, sp, #0xc8
      d8:      	movk	w8, #0xa, lsl #16
      dc:      	str	w8, [sp, #0xf0]
      e0:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
      e4:      	add	x8, x8, #0x0
      e8:      	ldp	x9, x10, [x8, #0x10]
      ec:      	ldp	x12, x11, [x8]
      f0:      	ldr	x8, [x8, #0x20]
      f4:      	stp	x11, x9, [x13, #0x8]
      f8:      	stp	x10, x8, [x13, #0x18]
      fc:      	str	x12, [sp, #0xc8]
     100:      	mov	w8, #0x2c               // =44
     104:      	mov	w9, #0x6                // =6
     108:      	add	x10, sp, #0xc8
     10c:      	ldr	x2, [x21, #0xed0]
     110:      	ldr	x3, [x21, #0xf10]
     114:      	ldr	x4, [x21, #0xf08]
     118:      	blr	x9
     11c:      	b	0x144 <kprobe_unwind_hotspot+0x144>
     120:      	ldr	w8, [x22]
     124:      	cbnz	w8, 0x6ec <kprobe_unwind_hotspot+0x6ec>
     128:      	mov	w0, wzr
     12c:      	b	0x384 <kprobe_unwind_hotspot+0x384>
     130:      	ldr	w8, [x22]
     134:      	cbnz	w8, 0x7fc <kprobe_unwind_hotspot+0x7fc>
     138:      	ldr	x22, [x21, #0xed0]
     13c:      	ldr	x29, [x21, #0xed8]
     140:      	ldr	x25, [x21, #0xee0]
     144:      	ldr	x8, [x21, #0xf08]
     148:      	ldrb	w9, [x23, #0x20]
     14c:      	add	x10, sp, #0x88
     150:      	add	x0, sp, #0x88
     154:      	mov	w1, #0x1                // =1
     158:      	lsr	x24, x8, x9
     15c:      	ldr	x8, [x21, #0xf00]
     160:      	mov	w9, #0x70               // =112
     164:      	and	x19, x8, #0xffffffffffffff
     168:      	mov	w8, #0x1                // =1
     16c:      	add	x2, x24, x19
     170:      	blr	x9
     174:      	cbz	x0, 0x1d8 <kprobe_unwind_hotspot+0x1d8>
     178:      	str	xzr, [sp, #0x50]
     17c:      	adrp	x24, 0x0 <kprobe_unwind_hotspot>
     180:      	ldr	x24, [x24]
     184:      	ldr	w8, [x24]
     188:      	cbnz	w8, 0x6ac <kprobe_unwind_hotspot+0x6ac>
     18c:      	mov	w8, #0x2b               // =43
     190:      	adrp	x23, 0x0 <kprobe_unwind_hotspot>
     194:      	add	x9, sp, #0x88
     198:      	str	w8, [sp, #0x88]
     19c:      	mov	w8, #0x1                // =1
     1a0:      	add	x1, sp, #0x88
     1a4:      	ldr	x23, [x23]
     1a8:      	mov	x0, x23
     1ac:      	blr	x8
     1b0:      	adrp	x19, 0x0 <kprobe_unwind_hotspot>
     1b4:      	ldr	x22, [sp, #0x138]
     1b8:      	ldr	x19, [x19]
     1bc:      	cbz	x0, 0x2a4 <kprobe_unwind_hotspot+0x2a4>
     1c0:      	ldr	x8, [x0]
     1c4:      	mov	w25, wzr
     1c8:      	add	x8, x8, #0x1
     1cc:      	str	x8, [x0]
     1d0:      	mov	w8, #0x3e8              // =1000
     1d4:      	b	0x2b4 <kprobe_unwind_hotspot+0x2b4>
     1d8:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     1dc:      	ldr	x8, [x8]
     1e0:      	ldr	w8, [x8]
     1e4:      	cbnz	w8, 0x860 <kprobe_unwind_hotspot+0x860>
     1e8:      	ldrb	w8, [sp, #0x88]
     1ec:      	add	w9, w8, #0x1
     1f0:      	and	w9, w9, #0xff
     1f4:      	cmp	w9, #0x2
     1f8:      	b.hs	0x8bc <kprobe_unwind_hotspot+0x8bc>
     1fc:      	cbnz	w8, 0x178 <kprobe_unwind_hotspot+0x178>
     200:      	ldr	x8, [x21, #0xf10]
     204:      	ldrb	w9, [x23, #0x20]
     208:      	lsl	x9, x24, x9
     20c:      	ldrb	w10, [x23, #0x1b]
     210:      	add	x8, x8, x10
     214:      	add	x24, x9, x8
     218:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     21c:      	ldr	x8, [x8]
     220:      	ldr	w8, [x8]
     224:      	cbnz	w8, 0xd94 <kprobe_unwind_hotspot+0xd94>
     228:      	str	x24, [sp, #0x50]
     22c:      	cbz	x24, 0x17c <kprobe_unwind_hotspot+0x17c>
     230:      	add	x19, x21, #0xf70
     234:      	mov	w8, #0x200              // =512
     238:      	mov	w9, #0x70               // =112
     23c:      	ldr	x2, [sp, #0x50]
     240:      	mov	x0, x19
     244:      	mov	w1, #0x200              // =512
     248:      	blr	x9
     24c:      	adrp	x24, 0x0 <kprobe_unwind_hotspot>
     250:      	ldr	x24, [x24]
     254:      	cbz	x0, 0x3a0 <kprobe_unwind_hotspot+0x3a0>
     258:      	ldr	w8, [x24]
     25c:      	cbnz	w8, 0xfd0 <kprobe_unwind_hotspot+0xfd0>
     260:      	mov	w8, #0x2c               // =44
     264:      	adrp	x23, 0x0 <kprobe_unwind_hotspot>
     268:      	add	x9, sp, #0x88
     26c:      	str	w8, [sp, #0x88]
     270:      	mov	w8, #0x1                // =1
     274:      	add	x1, sp, #0x88
     278:      	ldr	x23, [x23]
     27c:      	mov	x0, x23
     280:      	blr	x8
     284:      	adrp	x19, 0x0 <kprobe_unwind_hotspot>
     288:      	ldr	x22, [sp, #0x138]
     28c:      	ldr	x19, [x19]
     290:      	cbz	x0, 0x3e4 <kprobe_unwind_hotspot+0x3e4>
     294:      	ldr	x8, [x0]
     298:      	add	x8, x8, #0x1
     29c:      	str	x8, [x0]
     2a0:      	b	0x3ec <kprobe_unwind_hotspot+0x3ec>
     2a4:      	ldr	w8, [x24]
     2a8:      	cbnz	w8, 0xc00 <kprobe_unwind_hotspot+0xc00>
     2ac:      	mov	w8, #0x3e8              // =1000
     2b0:      	mov	w25, wzr
     2b4:      	str	w8, [x21, #0xf1c]
     2b8:      	str	wzr, [sp, #0xc8]
     2bc:      	mov	w8, #0x1                // =1
     2c0:      	add	x9, sp, #0xc8
     2c4:      	add	x1, sp, #0xc8
     2c8:      	mov	x0, x19
     2cc:      	blr	x8
     2d0:      	cbz	x0, 0x324 <kprobe_unwind_hotspot+0x324>
     2d4:      	mov	w19, #0x1374            // =4980
     2d8:      	mov	w2, w25
     2dc:      	ldrb	w8, [x0, x19]
     2e0:      	cmp	w8, #0x1d
     2e4:      	b.lo	0x350 <kprobe_unwind_hotspot+0x350>
     2e8:      	mov	w8, #0x5                // =5
     2ec:      	add	x9, sp, #0x50
     2f0:      	mov	x20, x0
     2f4:      	str	w8, [x0, #0xf1c]
     2f8:      	mov	w8, #0x44               // =68
     2fc:      	add	x1, sp, #0x50
     300:      	mov	x0, x23
     304:      	str	w8, [sp, #0x50]
     308:      	mov	w8, #0x1                // =1
     30c:      	blr	x8
     310:      	cbz	x0, 0x33c <kprobe_unwind_hotspot+0x33c>
     314:      	ldr	x8, [x0]
     318:      	add	x8, x8, #0x1
     31c:      	str	x8, [x0]
     320:      	b	0x344 <kprobe_unwind_hotspot+0x344>
     324:      	adrp	x10, 0x0 <kprobe_unwind_hotspot>
     328:      	mov	x9, xzr
     32c:      	mov	w8, #0xc                // =12
     330:      	ldr	x10, [x10]
     334:      	mov	w2, wzr
     338:      	b	0x368 <kprobe_unwind_hotspot+0x368>
     33c:      	ldr	w8, [x24]
     340:      	cbnz	w8, 0xd48 <kprobe_unwind_hotspot+0xd48>
     344:      	ldrb	w8, [x20, x19]
     348:      	mov	w2, wzr
     34c:      	mov	x0, x20
     350:      	add	w8, w8, #0x1
     354:      	adrp	x10, 0x0 <kprobe_unwind_hotspot>
     358:      	mov	w9, w2
     35c:      	strb	w8, [x0, x19]
     360:      	mov	w8, #0xc                // =12
     364:      	ldr	x10, [x10]
     368:      	adrp	x1, 0x0 <kprobe_unwind_hotspot>
     36c:      	mov	x0, x22
     370:      	ldr	x1, [x1]
     374:      	blr	x8
     378:      	ldr	w8, [x24]
     37c:      	cbnz	w8, 0x5a8 <kprobe_unwind_hotspot+0x5a8>
     380:      	mov	w0, #-0x1               // =-1
     384:      	ldp	x20, x19, [sp, #0x170]
     388:      	ldr	x29, [sp, #0x130]
     38c:      	ldp	x22, x21, [sp, #0x160]
     390:      	ldp	x24, x23, [sp, #0x150]
     394:      	ldp	x30, x25, [sp, #0x140]
     398:      	add	sp, sp, #0x180
     39c:      	ret
     3a0:      	ldrh	w8, [x23, #0x10]
     3a4:      	cmp	x8, #0x1f8
     3a8:      	b.hi	0x3c4 <kprobe_unwind_hotspot+0x3c4>
     3ac:      	ldrh	w9, [x23, #0x12]
     3b0:      	cmp	x9, #0x1fc
     3b4:      	b.hi	0x3c4 <kprobe_unwind_hotspot+0x3c4>
     3b8:      	ldrh	w10, [x23, #0x14]
     3bc:      	cmp	x10, #0x1f8
     3c0:      	b.ls	0x3f4 <kprobe_unwind_hotspot+0x3f4>
     3c4:      	mov	w8, #0x1                // =1
     3c8:      	ldr	x22, [sp, #0x138]
     3cc:      	adrp	x19, 0x0 <kprobe_unwind_hotspot>
     3d0:      	adrp	x23, 0x0 <kprobe_unwind_hotspot>
     3d4:      	mov	w25, wzr
     3d8:      	ldr	x19, [x19]
     3dc:      	ldr	x23, [x23]
     3e0:      	b	0x2b4 <kprobe_unwind_hotspot+0x2b4>
     3e4:      	ldr	w8, [x24]
     3e8:      	cbnz	w8, 0x10b4 <kprobe_unwind_hotspot+0x10b4>
     3ec:      	mov	w8, #0x3eb              // =1003
     3f0:      	b	0x2b0 <kprobe_unwind_hotspot+0x2b0>
     3f4:      	ldrb	w12, [x23, #0x17]
     3f8:      	add	x11, sp, #0x50
     3fc:      	mov	w1, #0x4                // =4
     400:      	add	x0, x11, #0x20
     404:      	ldrb	w11, [x23, #0x1a]
     408:      	ldr	x12, [x19, x12]
     40c:      	str	x12, [sp, #0x58]
     410:      	ldrb	w12, [x23, #0x18]
     414:      	ldr	x12, [x19, x12]
     418:      	str	x12, [sp, #0x60]
     41c:      	ldr	w11, [x19, x11]
     420:      	lsl	w11, w11, #3
     424:      	str	w11, [sp, #0x78]
     428:      	ldrb	w11, [x23, #0x19]
     42c:      	ldrh	w11, [x19, x11]
     430:      	strh	w11, [sp, #0x80]
     434:      	ldr	w9, [x19, x9]
     438:      	str	w9, [sp, #0x7c]
     43c:      	ldr	w9, [x19, x10]
     440:      	str	w9, [sp, #0x74]
     444:      	mov	w9, #0x70               // =112
     448:      	ldr	x8, [x19, x8]
     44c:      	str	x8, [sp, #0x68]
     450:      	ldrb	w8, [x23, #0x16]
     454:      	ldr	x2, [x19, x8]
     458:      	mov	w8, #0x4                // =4
     45c:      	str	x0, [sp, #0x40]
     460:      	blr	x9
     464:      	cbnz	x0, 0x258 <kprobe_unwind_hotspot+0x258>
     468:      	ldrb	w8, [x23, #0x21]
     46c:      	str	x19, [sp, #0x8]
     470:      	cbz	w8, 0x48c <kprobe_unwind_hotspot+0x48c>
     474:      	ldr	x8, [sp, #0x50]
     478:      	ldr	w9, [sp, #0x58]
     47c:      	add	x9, x9, x8
     480:      	ldr	w10, [sp, #0x60]
     484:      	add	x8, x10, x8
     488:      	stp	x9, x8, [sp, #0x58]
     48c:      	add	x8, x21, #0xef0
     490:      	add	x19, sp, #0xc8
     494:      	str	x8, [sp, #0x20]
     498:      	ldr	w8, [x24]
     49c:      	cbnz	w8, 0x11c8 <kprobe_unwind_hotspot+0x11c8>
     4a0:      	add	x9, x19, #0x8
     4a4:      	add	x8, x19, #0x18
     4a8:      	ldr	w10, [sp, #0x70]
     4ac:      	stp	x8, x9, [sp, #0x10]
     4b0:      	ldp	x11, x8, [sp, #0x50]
     4b4:      	mov	w9, #0x616d             // =24941
     4b8:      	movk	w9, #0x6974, lsl #16
     4bc:      	cmp	w10, w9
     4c0:      	sub	w12, w22, w8
     4c4:      	b.gt	0x5fc <kprobe_unwind_hotspot+0x5fc>
     4c8:      	mov	w8, #0x7476             // =29814
     4cc:      	movk	w8, #0x6261, lsl #16
     4d0:      	cmp	w10, w8
     4d4:      	b.eq	0x798 <kprobe_unwind_hotspot+0x798>
     4d8:      	mov	w8, #0x6e49             // =28233
     4dc:      	movk	w8, #0x6574, lsl #16
     4e0:      	cmp	w10, w8
     4e4:      	b.ne	0x734 <kprobe_unwind_hotspot+0x734>
     4e8:      	cmp	x25, x29
     4ec:      	b.lo	0x52c0 <kprobe_unwind_hotspot+0x52c0>
     4f0:      	add	x8, x29, #0x1, lsl #12  // =0x1000
     4f4:      	cmp	x25, x8
     4f8:      	b.hs	0x52c0 <kprobe_unwind_hotspot+0x52c0>
     4fc:      	sub	x2, x25, #0x50
     500:      	mov	w8, #0x60               // =96
     504:      	mov	w9, #0x70               // =112
     508:      	add	x10, sp, #0xc8
     50c:      	add	x0, sp, #0xc8
     510:      	mov	w1, #0x60               // =96
     514:      	blr	x9
     518:      	cbz	x0, 0xec0 <kprobe_unwind_hotspot+0xec0>
     51c:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     520:      	ldr	x8, [x8]
     524:      	ldr	w8, [x8]
     528:      	cbz	w8, 0x52d0 <kprobe_unwind_hotspot+0x52d0>
     52c:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     530:      	add	x8, x8, #0x0
     534:      	add	x0, sp, #0x88
     538:      	ldp	x9, x10, [x8, #0x10]
     53c:      	mov	w1, #0x27               // =39
     540:      	stp	x9, x10, [sp, #0x98]
     544:      	ldur	x9, [x8, #0x1f]
     548:      	add	x10, sp, #0x88
     54c:      	stur	x9, [sp, #0xa7]
     550:      	ldp	x8, x9, [x8]
     554:      	stp	x8, x9, [sp, #0x88]
     558:      	mov	w8, #0x27               // =39
     55c:      	mov	w9, #0x6                // =6
     560:      	b	0x5364 <kprobe_unwind_hotspot+0x5364>
     564:      	mov	w8, #0xa                // =10
     568:      	add	x0, sp, #0xc8
     56c:      	mov	w1, #0x1a               // =26
     570:      	strh	w8, [sp, #0xe0]
     574:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     578:      	add	x8, x8, #0x0
     57c:      	ldp	x9, x10, [x8]
     580:      	ldr	x8, [x8, #0x10]
     584:      	str	x9, [sp, #0xc8]
     588:      	add	x9, sp, #0xc8
     58c:      	stp	x10, x8, [x9, #0x8]
     590:      	mov	w8, #0x1a               // =26
     594:      	mov	w9, #0x6                // =6
     598:      	add	x10, sp, #0xc8
     59c:      	ldr	w2, [x21, #0x2c0]
     5a0:      	blr	x9
     5a4:      	b	0x5c <kprobe_unwind_hotspot+0x5c>
     5a8:      	mov	w8, #0x6465             // =25701
     5ac:      	add	x13, sp, #0xc8
     5b0:      	add	x0, sp, #0xc8
     5b4:      	mov	w1, #0x34               // =52
     5b8:      	mov	w2, w25
     5bc:      	movk	w8, #0xa, lsl #16
     5c0:      	str	w8, [sp, #0xf8]
     5c4:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     5c8:      	add	x8, x8, #0x0
     5cc:      	ldp	x9, x10, [x8, #0x10]
     5d0:      	ldp	x11, x12, [x8, #0x20]
     5d4:      	str	x12, [x13, #0x28]
     5d8:      	stp	x10, x11, [x13, #0x18]
     5dc:      	ldp	x10, x8, [x8]
     5e0:      	str	x10, [sp, #0xc8]
     5e4:      	add	x10, sp, #0xc8
     5e8:      	stp	x8, x9, [x13, #0x8]
     5ec:      	mov	w8, #0x34               // =52
     5f0:      	mov	w9, #0x6                // =6
     5f4:      	blr	x9
     5f8:      	b	0x380 <kprobe_unwind_hotspot+0x380>
     5fc:      	mov	w9, #0x6d6e             // =28014
     600:      	movk	w9, #0x7465, lsl #16
     604:      	cmp	w10, w9
     608:      	b.eq	0x61c <kprobe_unwind_hotspot+0x61c>
     60c:      	mov	w9, #0x616e             // =24942
     610:      	movk	w9, #0x6974, lsl #16
     614:      	cmp	w10, w9
     618:      	b.ne	0x734 <kprobe_unwind_hotspot+0x734>
     61c:      	ldr	w9, [sp, #0x7c]
     620:      	ldrb	w10, [x23, #0x21]
     624:      	cmp	w10, #0x0
     628:      	str	x9, [sp, #0x28]
     62c:      	ldr	x9, [sp, #0x68]
     630:      	ldrb	w19, [x21, #0xf20]
     634:      	stp	x11, x12, [sp, #0x30]
     638:      	add	x11, x11, w9, uxtw
     63c:      	csel	x9, x9, x11, eq
     640:      	cmp	x22, x9
     644:      	b.ne	0x680 <kprobe_unwind_hotspot+0x680>
     648:      	ldr	w8, [sp, #0x74]
     64c:      	mov	w9, #0x8                // =8
     650:      	mov	w10, #0x70              // =112
     654:      	add	x11, sp, #0x88
     658:      	add	x0, sp, #0x88
     65c:      	mov	w1, #0x8                // =8
     660:      	add	x8, x29, x8
     664:      	ldr	w8, [sp, #0x74]
     668:      	add	x2, x29, x8
     66c:      	blr	x10
     670:      	cbz	x0, 0xcd4 <kprobe_unwind_hotspot+0xcd4>
     674:      	ldr	w8, [x24]
     678:      	cbnz	w8, 0x1310 <kprobe_unwind_hotspot+0x1310>
     67c:      	ldr	x8, [sp, #0x58]
     680:      	ldrh	w9, [sp, #0x80]
     684:      	add	x8, x8, x9
     688:      	cmp	x22, x8
     68c:      	b.hs	0x760 <kprobe_unwind_hotspot+0x760>
     690:      	sub	x8, x8, #0x4
     694:      	cmp	x22, x8
     698:      	b.ne	0x6a4 <kprobe_unwind_hotspot+0x6a4>
     69c:      	ldr	w8, [sp, #0x78]
     6a0:      	add	x29, x29, x8
     6a4:      	mov	x19, #0x3000000000000000 // =3458764513820540928
     6a8:      	b	0x7b4 <kprobe_unwind_hotspot+0x7b4>
     6ac:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     6b0:      	add	x8, x8, #0x0
     6b4:      	add	x11, sp, #0xc8
     6b8:      	strb	wzr, [sp, #0xe8]
     6bc:      	ldp	x9, x10, [x8]
     6c0:      	add	x0, sp, #0xc8
     6c4:      	mov	w1, #0x21               // =33
     6c8:      	str	x9, [sp, #0xc8]
     6cc:      	ldp	x9, x8, [x8, #0x10]
     6d0:      	stp	x10, x9, [x11, #0x8]
     6d4:      	str	x8, [x11, #0x18]
     6d8:      	mov	w8, #0x21               // =33
     6dc:      	mov	w9, #0x6                // =6
     6e0:      	add	x10, sp, #0xc8
     6e4:      	blr	x9
     6e8:      	b	0x18c <kprobe_unwind_hotspot+0x18c>
     6ec:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     6f0:      	add	x8, x8, #0x0
     6f4:      	add	x13, sp, #0xc8
     6f8:      	ldp	x9, x10, [x8, #0x10]
     6fc:      	ldp	x12, x11, [x8]
     700:      	add	x0, sp, #0xc8
     704:      	mov	w1, #0x26               // =38
     708:      	ldur	x8, [x8, #0x1e]
     70c:      	str	x10, [x13, #0x18]
     710:      	stp	x11, x9, [x13, #0x8]
     714:      	mov	w9, #0x6                // =6
     718:      	stur	x8, [x13, #0x1e]
     71c:      	str	x12, [sp, #0xc8]
     720:      	mov	w8, #0x26               // =38
     724:      	add	x10, sp, #0xc8
     728:      	blr	x9
     72c:      	mov	w0, wzr
     730:      	b	0x384 <kprobe_unwind_hotspot+0x384>
     734:      	mov	x8, x24
     738:      	ldr	x24, [x21, #0xf00]
     73c:      	stp	x11, x12, [sp, #0x30]
     740:      	str	x10, [sp, #0x28]
     744:      	ldr	w8, [x8]
     748:      	tbnz	x24, #0x3f, 0xcb8 <kprobe_unwind_hotspot+0xcb8>
     74c:      	cbnz	w8, 0x1358 <kprobe_unwind_hotspot+0x1358>
     750:      	ldr	w8, [sp, #0x78]
     754:      	mov	x19, xzr
     758:      	cbnz	w8, 0x14b8 <kprobe_unwind_hotspot+0x14b8>
     75c:      	b	0x14ac <kprobe_unwind_hotspot+0x14ac>
     760:      	cbz	w19, 0xd08 <kprobe_unwind_hotspot+0xd08>
     764:      	subs	x2, x25, x29
     768:      	b.lo	0xc54 <kprobe_unwind_hotspot+0xc54>
     76c:      	ldr	w8, [sp, #0x78]
     770:      	add	x8, x29, x8
     774:      	add	x8, x8, #0x30
     778:      	cmp	x25, x8
     77c:      	b.hs	0xc54 <kprobe_unwind_hotspot+0xc54>
     780:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     784:      	ldr	x8, [x8]
     788:      	ldr	w8, [x8]
     78c:      	cbnz	w8, 0x1d18 <kprobe_unwind_hotspot+0x1d18>
     790:      	mov	x19, #0x3000000000000000 // =3458764513820540928
     794:      	b	0x14ac <kprobe_unwind_hotspot+0x14ac>
     798:      	mov	w8, #0x7476             // =29814
     79c:      	stp	x11, x12, [sp, #0x30]
     7a0:      	movk	w8, #0x6261, lsl #16
     7a4:      	str	x8, [sp, #0x28]
     7a8:      	ldr	w8, [x24]
     7ac:      	cbnz	w8, 0x12d8 <kprobe_unwind_hotspot+0x12d8>
     7b0:      	mov	x19, #0x1000000000000000 // =1152921504606846976
     7b4:      	ldrb	w8, [x21, #0xf21]
     7b8:      	cbz	w8, 0xc4c <kprobe_unwind_hotspot+0xc4c>
     7bc:      	mov	w8, #0x2f               // =47
     7c0:      	adrp	x0, 0x0 <kprobe_unwind_hotspot>
     7c4:      	add	x9, sp, #0x88
     7c8:      	str	w8, [sp, #0x88]
     7cc:      	mov	w8, #0x1                // =1
     7d0:      	add	x1, sp, #0x88
     7d4:      	ldr	x0, [x0]
     7d8:      	blr	x8
     7dc:      	cbz	x0, 0xca0 <kprobe_unwind_hotspot+0xca0>
     7e0:      	ldr	x8, [x0]
     7e4:      	adrp	x24, 0x0 <kprobe_unwind_hotspot>
     7e8:      	add	x8, x8, #0x1
     7ec:      	str	x8, [x0]
     7f0:      	mov	w8, #0x3ec              // =1004
     7f4:      	ldr	x24, [x24]
     7f8:      	b	0x3c8 <kprobe_unwind_hotspot+0x3c8>
     7fc:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     800:      	add	x8, x8, #0x0
     804:      	add	x12, sp, #0xc8
     808:      	ldp	x9, x10, [x8, #0x10]
     80c:      	ldr	x11, [x8, #0x20]
     810:      	add	x0, sp, #0xc8
     814:      	mov	w1, #0x2e               // =46
     818:      	add	x20, sp, #0xc8
     81c:      	stp	x10, x11, [x12, #0x18]
     820:      	ldur	x10, [x8, #0x26]
     824:      	stur	x10, [x12, #0x26]
     828:      	ldp	x10, x8, [x8]
     82c:      	str	x10, [sp, #0xc8]
     830:      	stp	x8, x9, [x12, #0x8]
     834:      	mov	w8, #0x2e               // =46
     838:      	mov	w9, #0x6                // =6
     83c:      	add	x10, sp, #0xc8
     840:      	ldr	w2, [sp, #0x50]
     844:      	blr	x9
     848:      	ldr	w8, [x22]
     84c:      	ldr	x22, [x21, #0xed0]
     850:      	ldr	x29, [x21, #0xed8]
     854:      	ldr	x25, [x21, #0xee0]
     858:      	cbz	w8, 0x144 <kprobe_unwind_hotspot+0x144>
     85c:      	b	0xc4 <kprobe_unwind_hotspot+0xc4>
     860:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     864:      	add	x8, x8, #0x0
     868:      	add	x11, sp, #0xc8
     86c:      	ldp	x9, x10, [x8]
     870:      	add	x0, sp, #0xc8
     874:      	mov	w1, #0x1d               // =29
     878:      	mov	x2, x24
     87c:      	str	x9, [sp, #0xc8]
     880:      	ldr	x9, [x8, #0x10]
     884:      	ldur	x8, [x8, #0x15]
     888:      	add	x20, sp, #0xc8
     88c:      	stp	x10, x9, [x11, #0x8]
     890:      	stur	x8, [x11, #0x15]
     894:      	mov	w8, #0x1d               // =29
     898:      	mov	w9, #0x6                // =6
     89c:      	add	x10, sp, #0xc8
     8a0:      	ldrb	w3, [sp, #0x88]
     8a4:      	blr	x9
     8a8:      	ldrb	w8, [sp, #0x88]
     8ac:      	add	w9, w8, #0x1
     8b0:      	and	w9, w9, #0xff
     8b4:      	cmp	w9, #0x2
     8b8:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
     8bc:      	sub	x24, x24, x8
     8c0:      	mov	w8, #0x1                // =1
     8c4:      	mov	w9, #0x70               // =112
     8c8:      	add	x10, sp, #0x88
     8cc:      	add	x0, sp, #0x88
     8d0:      	mov	w1, #0x1                // =1
     8d4:      	add	x2, x24, x19
     8d8:      	blr	x9
     8dc:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
     8e0:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     8e4:      	ldr	x8, [x8]
     8e8:      	ldr	w8, [x8]
     8ec:      	cbnz	w8, 0xf6c <kprobe_unwind_hotspot+0xf6c>
     8f0:      	ldrb	w9, [sp, #0x88]
     8f4:      	add	w8, w9, #0x1
     8f8:      	and	w8, w8, #0xff
     8fc:      	cmp	w8, #0x2
     900:      	mov	w8, w9
     904:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
     908:      	sub	x24, x24, x9
     90c:      	mov	w8, #0x1                // =1
     910:      	mov	w9, #0x70               // =112
     914:      	add	x10, sp, #0x88
     918:      	add	x0, sp, #0x88
     91c:      	mov	w1, #0x1                // =1
     920:      	add	x2, x24, x19
     924:      	blr	x9
     928:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
     92c:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     930:      	ldr	x8, [x8]
     934:      	ldr	w8, [x8]
     938:      	cbnz	w8, 0x1100 <kprobe_unwind_hotspot+0x1100>
     93c:      	ldrb	w9, [sp, #0x88]
     940:      	add	w8, w9, #0x1
     944:      	and	w8, w8, #0xff
     948:      	cmp	w8, #0x2
     94c:      	mov	w8, w9
     950:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
     954:      	sub	x24, x24, x9
     958:      	mov	w8, #0x1                // =1
     95c:      	mov	w9, #0x70               // =112
     960:      	add	x10, sp, #0x88
     964:      	add	x0, sp, #0x88
     968:      	mov	w1, #0x1                // =1
     96c:      	add	x2, x24, x19
     970:      	blr	x9
     974:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
     978:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     97c:      	ldr	x8, [x8]
     980:      	ldr	w8, [x8]
     984:      	cbnz	w8, 0x1164 <kprobe_unwind_hotspot+0x1164>
     988:      	ldrb	w9, [sp, #0x88]
     98c:      	add	w8, w9, #0x1
     990:      	and	w8, w8, #0xff
     994:      	cmp	w8, #0x2
     998:      	mov	w8, w9
     99c:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
     9a0:      	sub	x24, x24, x9
     9a4:      	mov	w8, #0x1                // =1
     9a8:      	mov	w9, #0x70               // =112
     9ac:      	add	x10, sp, #0x88
     9b0:      	add	x0, sp, #0x88
     9b4:      	mov	w1, #0x1                // =1
     9b8:      	add	x2, x24, x19
     9bc:      	blr	x9
     9c0:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
     9c4:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     9c8:      	ldr	x8, [x8]
     9cc:      	ldr	w8, [x8]
     9d0:      	cbnz	w8, 0x1274 <kprobe_unwind_hotspot+0x1274>
     9d4:      	ldrb	w9, [sp, #0x88]
     9d8:      	add	w8, w9, #0x1
     9dc:      	and	w8, w8, #0xff
     9e0:      	cmp	w8, #0x2
     9e4:      	mov	w8, w9
     9e8:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
     9ec:      	sub	x24, x24, x9
     9f0:      	mov	w8, #0x1                // =1
     9f4:      	mov	w9, #0x70               // =112
     9f8:      	add	x10, sp, #0x88
     9fc:      	add	x0, sp, #0x88
     a00:      	mov	w1, #0x1                // =1
     a04:      	add	x2, x24, x19
     a08:      	blr	x9
     a0c:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
     a10:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     a14:      	ldr	x8, [x8]
     a18:      	ldr	w8, [x8]
     a1c:      	cbnz	w8, 0x13f8 <kprobe_unwind_hotspot+0x13f8>
     a20:      	ldrb	w9, [sp, #0x88]
     a24:      	add	w8, w9, #0x1
     a28:      	and	w8, w8, #0xff
     a2c:      	cmp	w8, #0x2
     a30:      	mov	w8, w9
     a34:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
     a38:      	sub	x24, x24, x9
     a3c:      	mov	w8, #0x1                // =1
     a40:      	mov	w9, #0x70               // =112
     a44:      	add	x10, sp, #0x88
     a48:      	add	x0, sp, #0x88
     a4c:      	mov	w1, #0x1                // =1
     a50:      	add	x2, x24, x19
     a54:      	blr	x9
     a58:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
     a5c:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     a60:      	ldr	x8, [x8]
     a64:      	ldr	w8, [x8]
     a68:      	cbnz	w8, 0x1eb8 <kprobe_unwind_hotspot+0x1eb8>
     a6c:      	ldrb	w9, [sp, #0x88]
     a70:      	add	w8, w9, #0x1
     a74:      	and	w8, w8, #0xff
     a78:      	cmp	w8, #0x2
     a7c:      	mov	w8, w9
     a80:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
     a84:      	sub	x24, x24, x9
     a88:      	mov	w8, #0x1                // =1
     a8c:      	mov	w9, #0x70               // =112
     a90:      	add	x10, sp, #0x88
     a94:      	add	x0, sp, #0x88
     a98:      	mov	w1, #0x1                // =1
     a9c:      	add	x2, x24, x19
     aa0:      	blr	x9
     aa4:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
     aa8:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     aac:      	ldr	x8, [x8]
     ab0:      	ldr	w8, [x8]
     ab4:      	cbnz	w8, 0x2580 <kprobe_unwind_hotspot+0x2580>
     ab8:      	ldrb	w9, [sp, #0x88]
     abc:      	add	w8, w9, #0x1
     ac0:      	and	w8, w8, #0xff
     ac4:      	cmp	w8, #0x2
     ac8:      	mov	w8, w9
     acc:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
     ad0:      	sub	x24, x24, x9
     ad4:      	mov	w8, #0x1                // =1
     ad8:      	mov	w9, #0x70               // =112
     adc:      	add	x10, sp, #0x88
     ae0:      	add	x0, sp, #0x88
     ae4:      	mov	w1, #0x1                // =1
     ae8:      	add	x2, x24, x19
     aec:      	blr	x9
     af0:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
     af4:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     af8:      	ldr	x8, [x8]
     afc:      	ldr	w8, [x8]
     b00:      	cbnz	w8, 0x2748 <kprobe_unwind_hotspot+0x2748>
     b04:      	ldrb	w9, [sp, #0x88]
     b08:      	add	w8, w9, #0x1
     b0c:      	and	w8, w8, #0xff
     b10:      	cmp	w8, #0x2
     b14:      	mov	w8, w9
     b18:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
     b1c:      	sub	x24, x24, x9
     b20:      	mov	w8, #0x1                // =1
     b24:      	mov	w9, #0x70               // =112
     b28:      	add	x10, sp, #0x88
     b2c:      	add	x0, sp, #0x88
     b30:      	mov	w1, #0x1                // =1
     b34:      	add	x2, x24, x19
     b38:      	blr	x9
     b3c:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
     b40:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     b44:      	ldr	x8, [x8]
     b48:      	ldr	w8, [x8]
     b4c:      	cbnz	w8, 0x2858 <kprobe_unwind_hotspot+0x2858>
     b50:      	ldrb	w9, [sp, #0x88]
     b54:      	add	w8, w9, #0x1
     b58:      	and	w8, w8, #0xff
     b5c:      	cmp	w8, #0x2
     b60:      	mov	w8, w9
     b64:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
     b68:      	sub	x24, x24, x9
     b6c:      	mov	w8, #0x1                // =1
     b70:      	mov	w9, #0x70               // =112
     b74:      	add	x10, sp, #0x88
     b78:      	add	x0, sp, #0x88
     b7c:      	mov	w1, #0x1                // =1
     b80:      	add	x2, x24, x19
     b84:      	blr	x9
     b88:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
     b8c:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     b90:      	ldr	x8, [x8]
     b94:      	ldr	w8, [x8]
     b98:      	cbnz	w8, 0x291c <kprobe_unwind_hotspot+0x291c>
     b9c:      	ldrb	w9, [sp, #0x88]
     ba0:      	add	w8, w9, #0x1
     ba4:      	and	w8, w8, #0xff
     ba8:      	cmp	w8, #0x2
     bac:      	mov	w8, w9
     bb0:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
     bb4:      	sub	x24, x24, x9
     bb8:      	mov	w8, #0x1                // =1
     bbc:      	mov	w9, #0x70               // =112
     bc0:      	add	x10, sp, #0x88
     bc4:      	add	x0, sp, #0x88
     bc8:      	mov	w1, #0x1                // =1
     bcc:      	add	x2, x24, x19
     bd0:      	blr	x9
     bd4:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
     bd8:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     bdc:      	ldr	x8, [x8]
     be0:      	ldr	w8, [x8]
     be4:      	cbnz	w8, 0x2a8c <kprobe_unwind_hotspot+0x2a8c>
     be8:      	ldrb	w8, [sp, #0x88]
     bec:      	add	w9, w8, #0x1
     bf0:      	and	w9, w9, #0xff
     bf4:      	cmp	w9, #0x1
     bf8:      	b.hi	0x178 <kprobe_unwind_hotspot+0x178>
     bfc:      	b	0x1fc <kprobe_unwind_hotspot+0x1fc>
     c00:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     c04:      	add	x8, x8, #0x0
     c08:      	add	x12, sp, #0xc8
     c0c:      	ldp	x9, x10, [x8, #0x10]
     c10:      	ldr	x11, [x8, #0x20]
     c14:      	add	x0, sp, #0xc8
     c18:      	mov	w1, #0x2e               // =46
     c1c:      	stp	x10, x11, [x12, #0x18]
     c20:      	ldur	x10, [x8, #0x26]
     c24:      	stur	x10, [x12, #0x26]
     c28:      	ldp	x10, x8, [x8]
     c2c:      	str	x10, [sp, #0xc8]
     c30:      	stp	x8, x9, [x12, #0x8]
     c34:      	mov	w8, #0x2e               // =46
     c38:      	mov	w9, #0x6                // =6
     c3c:      	add	x10, sp, #0xc8
     c40:      	ldr	w2, [sp, #0x88]
     c44:      	blr	x9
     c48:      	b	0x2ac <kprobe_unwind_hotspot+0x2ac>
     c4c:      	ldr	x20, [x21, #0xee8]
     c50:      	b	0x14fc <kprobe_unwind_hotspot+0x14fc>
     c54:      	sub	x2, x22, #0x8
     c58:      	mov	w8, #0x8                // =8
     c5c:      	mov	w9, #0x70               // =112
     c60:      	add	x10, sp, #0xc8
     c64:      	add	x0, sp, #0xc8
     c68:      	mov	w1, #0x8                // =8
     c6c:      	blr	x9
     c70:      	ldr	x8, [sp, #0xc8]
     c74:      	mov	x9, #0x27ff             // =10239
     c78:      	mov	x19, #0x3000000000000000 // =3458764513820540928
     c7c:      	movk	x9, #0xa9bf, lsl #16
     c80:      	movk	x9, #0x100, lsl #32
     c84:      	movk	x9, #0xd63f, lsl #48
     c88:      	cmp	x8, x9
     c8c:      	add	x8, x29, #0x10
     c90:      	ccmp	x0, #0x0, #0x0, eq
     c94:      	csel	x29, x8, x29, eq
     c98:      	ldr	w8, [sp, #0x78]
     c9c:      	b	0x14b8 <kprobe_unwind_hotspot+0x14b8>
     ca0:      	adrp	x24, 0x0 <kprobe_unwind_hotspot>
     ca4:      	ldr	x24, [x24]
     ca8:      	ldr	w8, [x24]
     cac:      	cbnz	w8, 0x13ac <kprobe_unwind_hotspot+0x13ac>
     cb0:      	mov	w8, #0x3ec              // =1004
     cb4:      	b	0x3c8 <kprobe_unwind_hotspot+0x3c8>
     cb8:      	cbnz	w8, 0x145c <kprobe_unwind_hotspot+0x145c>
     cbc:      	mov	x19, xzr
     cc0:      	tbnz	x24, #0x3e, 0x14ac <kprobe_unwind_hotspot+0x14ac>
     cc4:      	lsr	x8, x24, #53
     cc8:      	and	x8, x8, #0x1f8
     ccc:      	add	x29, x8, x29
     cd0:      	b	0x7b4 <kprobe_unwind_hotspot+0x7b4>
     cd4:      	ldr	x9, [sp, #0x88]
     cd8:      	ldr	x8, [sp, #0x58]
     cdc:      	cmp	x9, x8
     ce0:      	b.lo	0x674 <kprobe_unwind_hotspot+0x674>
     ce4:      	ldr	x10, [sp, #0x60]
     ce8:      	cmp	x9, x10
     cec:      	b.hs	0x674 <kprobe_unwind_hotspot+0x674>
     cf0:      	ldr	w10, [x24]
     cf4:      	cbnz	w10, 0x1da4 <kprobe_unwind_hotspot+0x1da4>
     cf8:      	mov	x22, x9
     cfc:      	sub	w8, w22, w8
     d00:      	str	x8, [sp, #0x38]
     d04:      	b	0x67c <kprobe_unwind_hotspot+0x67c>
     d08:      	ldr	w19, [sp, #0x78]
     d0c:      	cmp	w19, #0x210
     d10:      	b.lo	0xde4 <kprobe_unwind_hotspot+0xde4>
     d14:      	mov	w8, #0x30               // =48
     d18:      	adrp	x0, 0x0 <kprobe_unwind_hotspot>
     d1c:      	add	x9, sp, #0x88
     d20:      	str	w8, [sp, #0x88]
     d24:      	mov	w8, #0x1                // =1
     d28:      	add	x1, sp, #0x88
     d2c:      	ldr	x0, [x0]
     d30:      	blr	x8
     d34:      	cbz	x0, 0x1010 <kprobe_unwind_hotspot+0x1010>
     d38:      	ldr	x8, [x0]
     d3c:      	add	x8, x8, #0x1
     d40:      	str	x8, [x0]
     d44:      	b	0x764 <kprobe_unwind_hotspot+0x764>
     d48:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     d4c:      	add	x8, x8, #0x0
     d50:      	add	x12, sp, #0xc8
     d54:      	ldp	x9, x10, [x8, #0x10]
     d58:      	ldr	x11, [x8, #0x20]
     d5c:      	add	x0, sp, #0xc8
     d60:      	mov	w1, #0x2e               // =46
     d64:      	stp	x10, x11, [x12, #0x18]
     d68:      	ldur	x10, [x8, #0x26]
     d6c:      	stur	x10, [x12, #0x26]
     d70:      	ldp	x10, x8, [x8]
     d74:      	str	x10, [sp, #0xc8]
     d78:      	stp	x8, x9, [x12, #0x8]
     d7c:      	mov	w8, #0x2e               // =46
     d80:      	mov	w9, #0x6                // =6
     d84:      	add	x10, sp, #0xc8
     d88:      	ldr	w2, [sp, #0x50]
     d8c:      	blr	x9
     d90:      	b	0x344 <kprobe_unwind_hotspot+0x344>
     d94:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     d98:      	add	x8, x8, #0x0
     d9c:      	add	x11, sp, #0xc8
     da0:      	strb	wzr, [sp, #0xe8]
     da4:      	ldp	x9, x10, [x8]
     da8:      	add	x0, sp, #0xc8
     dac:      	mov	w1, #0x21               // =33
     db0:      	mov	x2, x24
     db4:      	str	x9, [sp, #0xc8]
     db8:      	ldp	x9, x8, [x8, #0x10]
     dbc:      	add	x20, sp, #0xc8
     dc0:      	stp	x10, x9, [x11, #0x8]
     dc4:      	str	x8, [x11, #0x18]
     dc8:      	mov	w8, #0x21               // =33
     dcc:      	mov	w9, #0x6                // =6
     dd0:      	add	x10, sp, #0xc8
     dd4:      	blr	x9
     dd8:      	str	x24, [sp, #0x50]
     ddc:      	cbnz	x24, 0x230 <kprobe_unwind_hotspot+0x230>
     de0:      	b	0x17c <kprobe_unwind_hotspot+0x17c>
     de4:      	sub	x2, x22, #0x14
     de8:      	mov	w8, #0x18               // =24
     dec:      	mov	w9, #0x70               // =112
     df0:      	add	x10, sp, #0xc8
     df4:      	add	x0, sp, #0xc8
     df8:      	mov	w1, #0x18               // =24
     dfc:      	blr	x9
     e00:      	cbnz	x0, 0x764 <kprobe_unwind_hotspot+0x764>
     e04:      	lsl	w9, w19, #12
     e08:      	mov	x10, #0x7fffffffffff0000 // =9223372036854710272
     e0c:      	mov	x8, xzr
     e10:      	and	x9, x9, #0x3f8000
     e14:      	add	x9, x9, x10
     e18:      	mov	x10, #0x7bfd            // =31741
     e1c:      	movk	x10, #0xa940, lsl #16
     e20:      	orr	x9, x9, x19, lsl #42
     e24:      	movk	x10, #0x3ff, lsl #32
     e28:      	movk	x10, #0x9100, lsl #48
     e2c:      	orr	x9, x9, x10
     e30:      	ldr	x10, [sp, #0xc8]
     e34:      	cmp	x10, x9
     e38:      	b.eq	0xe70 <kprobe_unwind_hotspot+0xe70>
     e3c:      	ldur	x10, [x20, #0x4]
     e40:      	cmp	x10, x9
     e44:      	b.eq	0xe70 <kprobe_unwind_hotspot+0xe70>
     e48:      	ldr	x10, [x20, #0x8]
     e4c:      	cmp	x10, x9
     e50:      	b.eq	0xe70 <kprobe_unwind_hotspot+0xe70>
     e54:      	ldur	x10, [x20, #0xc]
     e58:      	cmp	x10, x9
     e5c:      	b.eq	0xe70 <kprobe_unwind_hotspot+0xe70>
     e60:      	ldr	x8, [x20, #0x10]
     e64:      	cmp	x8, x9
     e68:      	b.ne	0x764 <kprobe_unwind_hotspot+0x764>
     e6c:      	ldr	w8, [sp, #0x78]
     e70:      	add	x29, x8, x29
     e74:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     e78:      	ldr	x8, [x8]
     e7c:      	ldr	w8, [x8]
     e80:      	cbz	w8, 0x6a4 <kprobe_unwind_hotspot+0x6a4>
     e84:      	mov	w8, #0x6573             // =25971
     e88:      	add	x10, sp, #0x88
     e8c:      	add	x0, sp, #0x88
     e90:      	mov	w1, #0x14               // =20
     e94:      	movk	w8, #0xa, lsl #16
     e98:      	str	w8, [sp, #0x98]
     e9c:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     ea0:      	add	x8, x8, #0x0
     ea4:      	ldp	x9, x8, [x8]
     ea8:      	stp	x9, x8, [sp, #0x88]
     eac:      	mov	w8, #0x14               // =20
     eb0:      	mov	w9, #0x6                // =6
     eb4:      	blr	x9
     eb8:      	mov	x19, #0x3000000000000000 // =3458764513820540928
     ebc:      	b	0x7b4 <kprobe_unwind_hotspot+0x7b4>
     ec0:      	ldr	w9, [x21, #0x2c0]
     ec4:      	ldr	x8, [sp, #0x20]
     ec8:      	cbz	w9, 0xedc <kprobe_unwind_hotspot+0xedc>
     ecc:      	ldrb	w8, [x23, #0x1f]
     ed0:      	cmp	w8, #0x0
     ed4:      	ldp	x9, x8, [sp, #0x10]
     ed8:      	csel	x8, x9, x8, eq
     edc:      	ldr	x19, [x8]
     ee0:      	add	x8, sp, #0xc8
     ee4:      	mov	w9, #0x8                // =8
     ee8:      	mov	w10, #0x70              // =112
     eec:      	ldr	x12, [x8, #0x38]
     ef0:      	ldp	x29, x25, [x8, #0x48]
     ef4:      	add	x11, sp, #0xc0
     ef8:      	add	x0, sp, #0xc0
     efc:      	mov	w1, #0x8                // =8
     f00:      	ldr	x20, [x8, #0x58]
     f04:      	ldrb	w8, [x23, #0x1c]
     f08:      	add	x8, x12, x8
     f0c:      	str	x12, [sp, #0x30]
     f10:      	ldrb	w8, [x23, #0x1c]
     f14:      	add	x2, x12, x8
     f18:      	blr	x10
     f1c:      	cbz	x0, 0x106c <kprobe_unwind_hotspot+0x106c>
     f20:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     f24:      	ldr	x8, [x8]
     f28:      	ldr	w8, [x8]
     f2c:      	cbz	w8, 0x52d0 <kprobe_unwind_hotspot+0x52d0>
     f30:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     f34:      	add	x8, x8, #0x0
     f38:      	strb	wzr, [sp, #0xb0]
     f3c:      	add	x0, sp, #0x88
     f40:      	ldp	x9, x10, [x8, #0x10]
     f44:      	mov	w1, #0x29               // =41
     f48:      	stp	x9, x10, [sp, #0x98]
     f4c:      	ldr	x9, [x8, #0x20]
     f50:      	add	x10, sp, #0x88
     f54:      	str	x9, [sp, #0xa8]
     f58:      	ldp	x8, x9, [x8]
     f5c:      	stp	x8, x9, [sp, #0x88]
     f60:      	mov	w8, #0x29               // =41
     f64:      	mov	w9, #0x6                // =6
     f68:      	b	0x5364 <kprobe_unwind_hotspot+0x5364>
     f6c:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     f70:      	add	x8, x8, #0x0
     f74:      	add	x11, sp, #0xc8
     f78:      	ldp	x9, x10, [x8]
     f7c:      	add	x0, sp, #0xc8
     f80:      	mov	w1, #0x1d               // =29
     f84:      	mov	x2, x24
     f88:      	str	x9, [sp, #0xc8]
     f8c:      	ldr	x9, [x8, #0x10]
     f90:      	ldur	x8, [x8, #0x15]
     f94:      	add	x20, sp, #0xc8
     f98:      	stp	x10, x9, [x11, #0x8]
     f9c:      	stur	x8, [x11, #0x15]
     fa0:      	mov	w8, #0x1d               // =29
     fa4:      	mov	w9, #0x6                // =6
     fa8:      	add	x10, sp, #0xc8
     fac:      	ldrb	w3, [sp, #0x88]
     fb0:      	blr	x9
     fb4:      	ldrb	w9, [sp, #0x88]
     fb8:      	add	w8, w9, #0x1
     fbc:      	and	w8, w8, #0xff
     fc0:      	cmp	w8, #0x2
     fc4:      	mov	w8, w9
     fc8:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
     fcc:      	b	0x908 <kprobe_unwind_hotspot+0x908>
     fd0:      	adrp	x8, 0x0 <kprobe_unwind_hotspot>
     fd4:      	add	x8, x8, #0x0
     fd8:      	add	x11, sp, #0xc8
     fdc:      	ldp	x9, x10, [x8]
     fe0:      	add	x0, sp, #0xc8
     fe4:      	mov	w1, #0x1e               // =30
     fe8:      	str	x9, [sp, #0xc8]
     fec:      	ldr	x9, [x8, #0x10]
     ff0:      	ldur	x8, [x8, #0x16]
     ff4:      	stp	x10, x9, [x11, #0x8]
     ff8:      	mov	w9, #0x6                // =6
     ffc:      	stur	x8, [x11, #0x16]
    1000:      	mov	w8, #0x1e               // =30
    1004:      	add	x10, sp, #0xc8
    1008:      	blr	x9
    100c:      	b	0x260 <kprobe_unwind_hotspot+0x260>
    1010:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1014:      	ldr	x8, [x8]
    1018:      	ldr	w8, [x8]
    101c:      	cbz	w8, 0x764 <kprobe_unwind_hotspot+0x764>
    1020:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1024:      	add	x8, x8, #0x0
    1028:      	add	x12, sp, #0xc8
    102c:      	ldp	x9, x10, [x8, #0x10]
    1030:      	ldr	x11, [x8, #0x20]
    1034:      	add	x0, sp, #0xc8
    1038:      	mov	w1, #0x2e               // =46
    103c:      	stp	x10, x11, [x12, #0x18]
    1040:      	ldur	x10, [x8, #0x26]
    1044:      	stur	x10, [x12, #0x26]
    1048:      	ldp	x10, x8, [x8]
    104c:      	str	x10, [sp, #0xc8]
    1050:      	stp	x8, x9, [x12, #0x8]
    1054:      	mov	w8, #0x2e               // =46
    1058:      	mov	w9, #0x6                // =6
    105c:      	add	x10, sp, #0xc8
    1060:      	ldr	w2, [sp, #0x88]
    1064:      	blr	x9
    1068:      	b	0x764 <kprobe_unwind_hotspot+0x764>
    106c:      	ldr	x8, [sp, #0xc0]
    1070:      	ldrb	w9, [x23, #0x1d]
    1074:      	add	x9, x8, x9
    1078:      	cmp	x19, x9
    107c:      	csel	x9, xzr, x9, lo
    1080:      	sub	x19, x19, x9
    1084:      	adrp	x9, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1088:      	ldr	x9, [x9]
    108c:      	ldr	w9, [x9]
    1090:      	cbnz	w9, 0x1f1c <kprobe_unwind_hotspot+0x1f1c>
    1094:      	mov	w9, #0xffff             // =65535
    1098:      	lsr	x8, x8, #3
    109c:      	cmp	x19, x9
    10a0:      	str	x8, [sp, #0x28]
    10a4:      	csel	x9, x19, x9, lo
    10a8:      	mov	x19, #0x2000000000000000 // =2305843009213693952
    10ac:      	str	x9, [sp, #0x38]
    10b0:      	b	0x14fc <kprobe_unwind_hotspot+0x14fc>
    10b4:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    10b8:      	add	x8, x8, #0x0
    10bc:      	add	x12, sp, #0xc8
    10c0:      	ldp	x9, x10, [x8, #0x10]
    10c4:      	ldr	x11, [x8, #0x20]
    10c8:      	add	x0, sp, #0xc8
    10cc:      	mov	w1, #0x2e               // =46
    10d0:      	stp	x10, x11, [x12, #0x18]
    10d4:      	ldur	x10, [x8, #0x26]
    10d8:      	stur	x10, [x12, #0x26]
    10dc:      	ldp	x10, x8, [x8]
    10e0:      	str	x10, [sp, #0xc8]
    10e4:      	stp	x8, x9, [x12, #0x8]
    10e8:      	mov	w8, #0x2e               // =46
    10ec:      	mov	w9, #0x6                // =6
    10f0:      	add	x10, sp, #0xc8
    10f4:      	ldr	w2, [sp, #0x88]
    10f8:      	blr	x9
    10fc:      	b	0x3ec <kprobe_unwind_hotspot+0x3ec>
    1100:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1104:      	add	x8, x8, #0x0
    1108:      	add	x11, sp, #0xc8
    110c:      	ldp	x9, x10, [x8]
    1110:      	add	x0, sp, #0xc8
    1114:      	mov	w1, #0x1d               // =29
    1118:      	mov	x2, x24
    111c:      	str	x9, [sp, #0xc8]
    1120:      	ldr	x9, [x8, #0x10]
    1124:      	ldur	x8, [x8, #0x15]
    1128:      	add	x20, sp, #0xc8
    112c:      	stp	x10, x9, [x11, #0x8]
    1130:      	stur	x8, [x11, #0x15]
    1134:      	mov	w8, #0x1d               // =29
    1138:      	mov	w9, #0x6                // =6
    113c:      	add	x10, sp, #0xc8
    1140:      	ldrb	w3, [sp, #0x88]
    1144:      	blr	x9
    1148:      	ldrb	w9, [sp, #0x88]
    114c:      	add	w8, w9, #0x1
    1150:      	and	w8, w8, #0xff
    1154:      	cmp	w8, #0x2
    1158:      	mov	w8, w9
    115c:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
    1160:      	b	0x954 <kprobe_unwind_hotspot+0x954>
    1164:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1168:      	add	x8, x8, #0x0
    116c:      	add	x11, sp, #0xc8
    1170:      	ldp	x9, x10, [x8]
    1174:      	add	x0, sp, #0xc8
    1178:      	mov	w1, #0x1d               // =29
    117c:      	mov	x2, x24
    1180:      	str	x9, [sp, #0xc8]
    1184:      	ldr	x9, [x8, #0x10]
    1188:      	ldur	x8, [x8, #0x15]
    118c:      	add	x20, sp, #0xc8
    1190:      	stp	x10, x9, [x11, #0x8]
    1194:      	stur	x8, [x11, #0x15]
    1198:      	mov	w8, #0x1d               // =29
    119c:      	mov	w9, #0x6                // =6
    11a0:      	add	x10, sp, #0xc8
    11a4:      	ldrb	w3, [sp, #0x88]
    11a8:      	blr	x9
    11ac:      	ldrb	w9, [sp, #0x88]
    11b0:      	add	w8, w9, #0x1
    11b4:      	and	w8, w8, #0xff
    11b8:      	cmp	w8, #0x2
    11bc:      	mov	w8, w9
    11c0:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
    11c4:      	b	0x9a0 <kprobe_unwind_hotspot+0x9a0>
    11c8:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    11cc:      	add	x8, x8, #0x0
    11d0:      	add	x0, sp, #0xc8
    11d4:      	ldp	x9, x10, [x8]
    11d8:      	ldur	x8, [x8, #0xf]
    11dc:      	mov	w1, #0x17               // =23
    11e0:      	add	x20, sp, #0xc8
    11e4:      	str	x9, [sp, #0xc8]
    11e8:      	add	x9, sp, #0xc8
    11ec:      	str	x10, [x9, #0x8]
    11f0:      	stur	x8, [x9, #0xf]
    11f4:      	mov	w8, #0x17               // =23
    11f8:      	mov	w9, #0x6                // =6
    11fc:      	add	x10, sp, #0xc8
    1200:      	ldp	x2, x3, [sp, #0x58]
    1204:      	blr	x9
    1208:      	ldr	w8, [x24]
    120c:      	cbz	w8, 0x4a0 <kprobe_unwind_hotspot+0x4a0>
    1210:      	mov	w8, #0x7825             // =30757
    1214:      	add	x13, sp, #0xc8
    1218:      	add	x0, sp, #0xc8
    121c:      	mov	w1, #0x3c               // =60
    1220:      	add	x20, sp, #0xc8
    1224:      	movk	w8, #0xa, lsl #16
    1228:      	str	w8, [sp, #0x100]
    122c:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1230:      	add	x8, x8, #0x0
    1234:      	ldp	x9, x10, [x8, #0x20]
    1238:      	ldp	x12, x11, [x8, #0x10]
    123c:      	stp	x11, x9, [x13, #0x18]
    1240:      	ldr	x9, [x8, #0x30]
    1244:      	stp	x10, x9, [x13, #0x28]
    1248:      	add	x10, sp, #0xc8
    124c:      	ldp	x9, x8, [x8]
    1250:      	str	x9, [sp, #0xc8]
    1254:      	stp	x8, x12, [x13, #0x8]
    1258:      	mov	w8, #0x3c               // =60
    125c:      	mov	w9, #0x6                // =6
    1260:      	ldrh	w2, [sp, #0x80]
    1264:      	ldr	w3, [sp, #0x78]
    1268:      	ldr	w4, [sp, #0x70]
    126c:      	blr	x9
    1270:      	b	0x4a0 <kprobe_unwind_hotspot+0x4a0>
    1274:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1278:      	add	x8, x8, #0x0
    127c:      	add	x11, sp, #0xc8
    1280:      	ldp	x9, x10, [x8]
    1284:      	add	x0, sp, #0xc8
    1288:      	mov	w1, #0x1d               // =29
    128c:      	mov	x2, x24
    1290:      	str	x9, [sp, #0xc8]
    1294:      	ldr	x9, [x8, #0x10]
    1298:      	ldur	x8, [x8, #0x15]
    129c:      	add	x20, sp, #0xc8
    12a0:      	stp	x10, x9, [x11, #0x8]
    12a4:      	stur	x8, [x11, #0x15]
    12a8:      	mov	w8, #0x1d               // =29
    12ac:      	mov	w9, #0x6                // =6
    12b0:      	add	x10, sp, #0xc8
    12b4:      	ldrb	w3, [sp, #0x88]
    12b8:      	blr	x9
    12bc:      	ldrb	w9, [sp, #0x88]
    12c0:      	add	w8, w9, #0x1
    12c4:      	and	w8, w8, #0xff
    12c8:      	cmp	w8, #0x2
    12cc:      	mov	w8, w9
    12d0:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
    12d4:      	b	0x9ec <kprobe_unwind_hotspot+0x9ec>
    12d8:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    12dc:      	add	x8, x8, #0x0
    12e0:      	add	x0, sp, #0xc8
    12e4:      	ldp	x9, x10, [x8]
    12e8:      	ldr	x8, [x8, #0x10]
    12ec:      	mov	w1, #0x18               // =24
    12f0:      	str	x9, [sp, #0xc8]
    12f4:      	add	x9, sp, #0xc8
    12f8:      	stp	x10, x8, [x9, #0x8]
    12fc:      	mov	w8, #0x18               // =24
    1300:      	mov	w9, #0x6                // =6
    1304:      	add	x10, sp, #0xc8
    1308:      	blr	x9
    130c:      	b	0x7b0 <kprobe_unwind_hotspot+0x7b0>
    1310:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1314:      	add	x8, x8, #0x0
    1318:      	add	x13, sp, #0xc8
    131c:      	ldp	x9, x10, [x8, #0x10]
    1320:      	ldp	x11, x12, [x8, #0x20]
    1324:      	add	x0, sp, #0xc8
    1328:      	mov	w1, #0x30               // =48
    132c:      	add	x20, sp, #0xc8
    1330:      	str	x12, [x13, #0x28]
    1334:      	stp	x10, x11, [x13, #0x18]
    1338:      	ldp	x10, x8, [x8]
    133c:      	str	x10, [sp, #0xc8]
    1340:      	stp	x8, x9, [x13, #0x8]
    1344:      	mov	w8, #0x30               // =48
    1348:      	mov	w9, #0x6                // =6
    134c:      	add	x10, sp, #0xc8
    1350:      	blr	x9
    1354:      	b	0x67c <kprobe_unwind_hotspot+0x67c>
    1358:      	mov	w8, #0x6874             // =26740
    135c:      	add	x11, sp, #0xc8
    1360:      	add	x0, sp, #0xc8
    1364:      	mov	w1, #0x24               // =36
    1368:      	movk	w8, #0xa, lsl #16
    136c:      	str	w8, [sp, #0xe8]
    1370:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1374:      	add	x8, x8, #0x0
    1378:      	ldp	x9, x10, [x8]
    137c:      	str	x9, [sp, #0xc8]
    1380:      	ldp	x9, x8, [x8, #0x10]
    1384:      	stp	x10, x9, [x11, #0x8]
    1388:      	str	x8, [x11, #0x18]
    138c:      	mov	w8, #0x24               // =36
    1390:      	mov	w9, #0x6                // =6
    1394:      	add	x10, sp, #0xc8
    1398:      	blr	x9
    139c:      	ldr	w8, [sp, #0x78]
    13a0:      	mov	x19, xzr
    13a4:      	cbnz	w8, 0x14b8 <kprobe_unwind_hotspot+0x14b8>
    13a8:      	b	0x14ac <kprobe_unwind_hotspot+0x14ac>
    13ac:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    13b0:      	add	x8, x8, #0x0
    13b4:      	add	x12, sp, #0xc8
    13b8:      	ldp	x9, x10, [x8, #0x10]
    13bc:      	ldr	x11, [x8, #0x20]
    13c0:      	add	x0, sp, #0xc8
    13c4:      	mov	w1, #0x2e               // =46
    13c8:      	stp	x10, x11, [x12, #0x18]
    13cc:      	ldur	x10, [x8, #0x26]
    13d0:      	stur	x10, [x12, #0x26]
    13d4:      	ldp	x10, x8, [x8]
    13d8:      	str	x10, [sp, #0xc8]
    13dc:      	stp	x8, x9, [x12, #0x8]
    13e0:      	mov	w8, #0x2e               // =46
    13e4:      	mov	w9, #0x6                // =6
    13e8:      	add	x10, sp, #0xc8
    13ec:      	ldr	w2, [sp, #0x88]
    13f0:      	blr	x9
    13f4:      	b	0xcb0 <kprobe_unwind_hotspot+0xcb0>
    13f8:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    13fc:      	add	x8, x8, #0x0
    1400:      	add	x11, sp, #0xc8
    1404:      	ldp	x9, x10, [x8]
    1408:      	add	x0, sp, #0xc8
    140c:      	mov	w1, #0x1d               // =29
    1410:      	mov	x2, x24
    1414:      	str	x9, [sp, #0xc8]
    1418:      	ldr	x9, [x8, #0x10]
    141c:      	ldur	x8, [x8, #0x15]
    1420:      	add	x20, sp, #0xc8
    1424:      	stp	x10, x9, [x11, #0x8]
    1428:      	stur	x8, [x11, #0x15]
    142c:      	mov	w8, #0x1d               // =29
    1430:      	mov	w9, #0x6                // =6
    1434:      	add	x10, sp, #0xc8
    1438:      	ldrb	w3, [sp, #0x88]
    143c:      	blr	x9
    1440:      	ldrb	w9, [sp, #0x88]
    1444:      	add	w8, w9, #0x1
    1448:      	and	w8, w8, #0xff
    144c:      	cmp	w8, #0x2
    1450:      	mov	w8, w9
    1454:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
    1458:      	b	0xa38 <kprobe_unwind_hotspot+0xa38>
    145c:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1460:      	add	x8, x8, #0x0
    1464:      	add	x13, sp, #0xc8
    1468:      	strb	wzr, [sp, #0xf8]
    146c:      	ldp	x9, x10, [x8, #0x10]
    1470:      	add	x0, sp, #0xc8
    1474:      	ldp	x11, x12, [x8, #0x20]
    1478:      	mov	w1, #0x31               // =49
    147c:      	mov	x2, x24
    1480:      	str	x12, [x13, #0x28]
    1484:      	stp	x10, x11, [x13, #0x18]
    1488:      	ldp	x10, x8, [x8]
    148c:      	str	x10, [sp, #0xc8]
    1490:      	add	x10, sp, #0xc8
    1494:      	stp	x8, x9, [x13, #0x8]
    1498:      	mov	w8, #0x31               // =49
    149c:      	mov	w9, #0x6                // =6
    14a0:      	blr	x9
    14a4:      	mov	x19, xzr
    14a8:      	tbz	x24, #0x3e, 0xcc4 <kprobe_unwind_hotspot+0xcc4>
    14ac:      	mov	w8, #0x10               // =16
    14b0:      	mov	x29, x25
    14b4:      	str	w8, [sp, #0x78]
    14b8:      	add	x29, x29, w8, uxtw
    14bc:      	mov	w8, #0x10               // =16
    14c0:      	mov	w9, #0x70               // =112
    14c4:      	add	x10, sp, #0x88
    14c8:      	add	x0, sp, #0x88
    14cc:      	mov	w1, #0x10               // =16
    14d0:      	sub	x2, x29, #0x10
    14d4:      	blr	x9
    14d8:      	ldr	w8, [sp, #0x78]
    14dc:      	ldr	x20, [sp, #0x90]
    14e0:      	cmp	w8, #0x10
    14e4:      	b.lo	0x14fc <kprobe_unwind_hotspot+0x14fc>
    14e8:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    14ec:      	ldr	x8, [x8]
    14f0:      	ldr	w8, [x8]
    14f4:      	cbnz	w8, 0x1700 <kprobe_unwind_hotspot+0x1700>
    14f8:      	ldr	x25, [sp, #0x88]
    14fc:      	ldr	w8, [x21, #0x2c0]
    1500:      	cmp	w8, #0x7f
    1504:      	b.lo	0x1554 <kprobe_unwind_hotspot+0x1554>
    1508:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    150c:      	ldr	x8, [x8]
    1510:      	ldr	w8, [x8]
    1514:      	cbnz	w8, 0x1668 <kprobe_unwind_hotspot+0x1668>
    1518:      	mov	w8, #0x2                // =2
    151c:      	adrp	x0, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1520:      	add	x9, sp, #0x88
    1524:      	str	w8, [sp, #0x88]
    1528:      	mov	w8, #0x1                // =1
    152c:      	add	x1, sp, #0x88
    1530:      	ldr	x0, [x0]
    1534:      	blr	x8
    1538:      	cbz	x0, 0x1608 <kprobe_unwind_hotspot+0x1608>
    153c:      	ldr	x8, [x0]
    1540:      	adrp	x24, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1544:      	add	x8, x8, #0x1
    1548:      	str	x8, [x0]
    154c:      	ldr	x24, [x24]
    1550:      	b	0x1618 <kprobe_unwind_hotspot+0x1618>
    1554:      	ldr	x12, [sp, #0x28]
    1558:      	and	x10, x19, #0x3000000000000000
    155c:      	ldr	x11, [sp, #0x38]
    1560:      	mov	w12, w12
    1564:      	ldrb	w9, [x21, #0xf20]
    1568:      	orr	x11, x12, x11, lsl #32
    156c:      	orr	x10, x11, x10
    1570:      	add	w11, w8, #0x1
    1574:      	str	w11, [x21, #0x2c0]
    1578:      	mov	w11, #0x18              // =24
    157c:      	umaddl	x8, w8, w11, x21
    1580:      	ldr	x11, [sp, #0x30]
    1584:      	str	x10, [x8, #0x2d8]
    1588:      	mov	w10, #0x5               // =5
    158c:      	strb	w9, [x8, #0x2e1]
    1590:      	strh	wzr, [x8, #0x2e6]
    1594:      	strb	w10, [x8, #0x2e0]
    1598:      	add	x10, x8, #0x2d0
    159c:      	str	x11, [x8, #0x2d0]
    15a0:      	stur	wzr, [x10, #0x12]
    15a4:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    15a8:      	ldr	x8, [x8]
    15ac:      	ldr	w8, [x8]
    15b0:      	cbnz	w8, 0x16ac <kprobe_unwind_hotspot+0x16ac>
    15b4:      	mov	w8, #0x101              // =257
    15b8:      	str	x20, [x21, #0xed0]
    15bc:      	str	x29, [x21, #0xed8]
    15c0:      	adrp	x0, 0x1000 <kprobe_unwind_hotspot+0x1000>
    15c4:      	add	x9, sp, #0x88
    15c8:      	add	x1, sp, #0x88
    15cc:      	strh	w8, [x21, #0xf20]
    15d0:      	mov	w8, #0x2a               // =42
    15d4:      	str	x25, [x21, #0xee0]
    15d8:      	str	w8, [sp, #0x88]
    15dc:      	mov	w8, #0x1                // =1
    15e0:      	ldr	x0, [x0]
    15e4:      	blr	x8
    15e8:      	cbz	x0, 0x1620 <kprobe_unwind_hotspot+0x1620>
    15ec:      	ldr	x8, [x0]
    15f0:      	add	x8, x8, #0x1
    15f4:      	str	x8, [x0]
    15f8:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    15fc:      	ldr	x8, [x8]
    1600:      	ldr	w8, [x8]
    1604:      	b	0x1630 <kprobe_unwind_hotspot+0x1630>
    1608:      	adrp	x24, 0x1000 <kprobe_unwind_hotspot+0x1000>
    160c:      	ldr	x24, [x24]
    1610:      	ldr	w8, [x24]
    1614:      	cbnz	w8, 0x1c38 <kprobe_unwind_hotspot+0x1c38>
    1618:      	mov	w8, #0x2                // =2
    161c:      	b	0x3c8 <kprobe_unwind_hotspot+0x3c8>
    1620:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1624:      	ldr	x8, [x8]
    1628:      	ldr	w8, [x8]
    162c:      	cbnz	w8, 0x1c84 <kprobe_unwind_hotspot+0x1c84>
    1630:      	ldr	x29, [x21, #0xed0]
    1634:      	cbz	x29, 0x5eac <kprobe_unwind_hotspot+0x5eac>
    1638:      	cbnz	w8, 0x173c <kprobe_unwind_hotspot+0x173c>
    163c:      	lsr	x8, x29, #56
    1640:      	cbz	x8, 0x1790 <kprobe_unwind_hotspot+0x1790>
    1644:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1648:      	ldr	x8, [x8]
    164c:      	ldr	w8, [x8]
    1650:      	cbnz	w8, 0x1cd0 <kprobe_unwind_hotspot+0x1cd0>
    1654:      	mov	w8, #0xb                // =11
    1658:      	mov	w25, wzr
    165c:      	str	w8, [x21, #0xf18]
    1660:      	mov	w8, #0xfab              // =4011
    1664:      	b	0x5ec0 <kprobe_unwind_hotspot+0x5ec0>
    1668:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    166c:      	add	x8, x8, #0x0
    1670:      	add	x13, sp, #0xc8
    1674:      	ldp	x9, x10, [x8, #0x10]
    1678:      	ldp	x12, x11, [x8]
    167c:      	add	x0, sp, #0xc8
    1680:      	mov	w1, #0x25               // =37
    1684:      	ldur	x8, [x8, #0x1d]
    1688:      	str	x10, [x13, #0x18]
    168c:      	stp	x11, x9, [x13, #0x8]
    1690:      	mov	w9, #0x6                // =6
    1694:      	stur	x8, [x13, #0x1d]
    1698:      	str	x12, [sp, #0xc8]
    169c:      	mov	w8, #0x25               // =37
    16a0:      	add	x10, sp, #0xc8
    16a4:      	blr	x9
    16a8:      	b	0x1518 <kprobe_unwind_hotspot+0x1518>
    16ac:      	mov	w8, #0x786c             // =30828
    16b0:      	add	x11, sp, #0xc8
    16b4:      	add	x0, sp, #0xc8
    16b8:      	mov	w1, #0x24               // =36
    16bc:      	mov	x2, x20
    16c0:      	mov	x3, x29
    16c4:      	mov	x4, x25
    16c8:      	movk	w8, #0xa, lsl #16
    16cc:      	str	w8, [sp, #0xe8]
    16d0:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    16d4:      	add	x8, x8, #0x0
    16d8:      	ldp	x9, x10, [x8]
    16dc:      	str	x9, [sp, #0xc8]
    16e0:      	ldp	x9, x8, [x8, #0x10]
    16e4:      	stp	x10, x9, [x11, #0x8]
    16e8:      	str	x8, [x11, #0x18]
    16ec:      	mov	w8, #0x24               // =36
    16f0:      	mov	w9, #0x6                // =6
    16f4:      	add	x10, sp, #0xc8
    16f8:      	blr	x9
    16fc:      	b	0x15b4 <kprobe_unwind_hotspot+0x15b4>
    1700:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1704:      	add	x8, x8, #0x0
    1708:      	add	x0, sp, #0xc8
    170c:      	ldp	x9, x10, [x8]
    1710:      	ldur	x8, [x8, #0xd]
    1714:      	mov	w1, #0x15               // =21
    1718:      	str	x9, [sp, #0xc8]
    171c:      	add	x9, sp, #0xc8
    1720:      	str	x10, [x9, #0x8]
    1724:      	stur	x8, [x9, #0xd]
    1728:      	mov	w8, #0x15               // =21
    172c:      	mov	w9, #0x6                // =6
    1730:      	add	x10, sp, #0xc8
    1734:      	blr	x9
    1738:      	b	0x14f8 <kprobe_unwind_hotspot+0x14f8>
    173c:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1740:      	add	x8, x8, #0x0
    1744:      	add	x13, sp, #0xc8
    1748:      	strb	wzr, [sp, #0xf8]
    174c:      	ldp	x9, x10, [x8, #0x10]
    1750:      	add	x0, sp, #0xc8
    1754:      	ldp	x11, x12, [x8, #0x20]
    1758:      	mov	w1, #0x31               // =49
    175c:      	str	x12, [x13, #0x28]
    1760:      	stp	x10, x11, [x13, #0x18]
    1764:      	ldp	x10, x8, [x8]
    1768:      	str	x10, [sp, #0xc8]
    176c:      	stp	x8, x9, [x13, #0x8]
    1770:      	mov	w8, #0x31               // =49
    1774:      	mov	w9, #0x6                // =6
    1778:      	add	x10, sp, #0xc8
    177c:      	ldr	w2, [x21, #0x2c0]
    1780:      	blr	x9
    1784:      	ldr	x29, [x21, #0xed0]
    1788:      	lsr	x8, x29, #56
    178c:      	cbnz	x8, 0x1644 <kprobe_unwind_hotspot+0x1644>
    1790:      	cmp	x29, #0xfff
    1794:      	b.hi	0x17bc <kprobe_unwind_hotspot+0x17bc>
    1798:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    179c:      	ldr	x8, [x8]
    17a0:      	ldr	w8, [x8]
    17a4:      	cbnz	w8, 0x1d60 <kprobe_unwind_hotspot+0x1d60>
    17a8:      	mov	w8, #0x31               // =49
    17ac:      	mov	w25, wzr
    17b0:      	str	w8, [x21, #0xf18]
    17b4:      	mov	w8, #0xfae              // =4014
    17b8:      	b	0x5ec0 <kprobe_unwind_hotspot+0x5ec0>
    17bc:      	ldr	w8, [x21]
    17c0:      	mov	w9, #0x60               // =96
    17c4:      	adrp	x20, 0x1000 <kprobe_unwind_hotspot+0x1000>
    17c8:      	add	x1, sp, #0x50
    17cc:      	rev	w8, w8
    17d0:      	stp	w9, w8, [sp, #0x50]
    17d4:      	rev	x8, x29
    17d8:      	add	x9, sp, #0x50
    17dc:      	str	x8, [sp, #0x58]
    17e0:      	mov	w8, #0x1                // =1
    17e4:      	ldr	x20, [x20]
    17e8:      	mov	x0, x20
    17ec:      	blr	x8
    17f0:      	cbz	x0, 0x5ee0 <kprobe_unwind_hotspot+0x5ee0>
    17f4:      	ldr	x8, [x0, #0x8]
    17f8:      	and	x9, x8, #0xffffffffffffff
    17fc:      	lsr	x25, x8, #56
    1800:      	str	x9, [x21, #0xf10]
    1804:      	ldr	x8, [x0]
    1808:      	str	x8, [x21, #0xf00]
    180c:      	sub	x8, x29, x9
    1810:      	str	x8, [x21, #0xf08]
    1814:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1818:      	ldr	x8, [x8]
    181c:      	ldr	w8, [x8]
    1820:      	cbnz	w8, 0x1e04 <kprobe_unwind_hotspot+0x1e04>
    1824:      	cmp	w25, #0x1
    1828:      	b.ne	0x18c8 <kprobe_unwind_hotspot+0x18c8>
    182c:      	ldr	x8, [x21, #0xf00]
    1830:      	adrp	x0, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1834:      	ldr	x19, [x21, #0xf08]
    1838:      	mov	w9, #0x1                // =1
    183c:      	add	x1, sp, #0x50
    1840:      	mov	w22, #0x1               // =1
    1844:      	str	x8, [sp, #0x50]
    1848:      	add	x8, sp, #0x50
    184c:      	ldr	x0, [x0]
    1850:      	blr	x9
    1854:      	cbz	x0, 0x18c4 <kprobe_unwind_hotspot+0x18c4>
    1858:      	ldr	x8, [x0]
    185c:      	mov	x25, x0
    1860:      	cmp	x8, x19
    1864:      	b.hi	0x1874 <kprobe_unwind_hotspot+0x1874>
    1868:      	ldr	x8, [x25, #0x8]
    186c:      	cmp	x8, x19
    1870:      	b.hs	0x188c <kprobe_unwind_hotspot+0x188c>
    1874:      	ldr	x8, [x25, #0x10]
    1878:      	cmp	x8, x19
    187c:      	b.hi	0x18bc <kprobe_unwind_hotspot+0x18bc>
    1880:      	ldr	x8, [x25, #0x18]
    1884:      	cmp	x8, x19
    1888:      	b.lo	0x18bc <kprobe_unwind_hotspot+0x18bc>
    188c:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1890:      	ldr	x8, [x8]
    1894:      	ldr	w8, [x8]
    1898:      	cbnz	w8, 0x24e4 <kprobe_unwind_hotspot+0x24e4>
    189c:      	ldrh	w8, [x25, #0x20]
    18a0:      	ldr	w9, [x21, #0x1370]
    18a4:      	lsr	w8, w9, w8
    18a8:      	tbz	w8, #0x0, 0x2534 <kprobe_unwind_hotspot+0x2534>
    18ac:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    18b0:      	ldr	x8, [x8]
    18b4:      	ldr	w8, [x8]
    18b8:      	cbnz	w8, 0x25f4 <kprobe_unwind_hotspot+0x25f4>
    18bc:      	mov	w25, #0x1               // =1
    18c0:      	b	0x18c8 <kprobe_unwind_hotspot+0x18c8>
    18c4:      	mov	w25, w22
    18c8:      	cmp	w25, #0x2
    18cc:      	b.ne	0x6074 <kprobe_unwind_hotspot+0x6074>
    18d0:      	mov	w8, #0x29               // =41
    18d4:      	adrp	x0, 0x1000 <kprobe_unwind_hotspot+0x1000>
    18d8:      	add	x9, sp, #0x50
    18dc:      	str	w8, [sp, #0x50]
    18e0:      	mov	w8, #0x1                // =1
    18e4:      	add	x1, sp, #0x50
    18e8:      	ldr	x0, [x0]
    18ec:      	blr	x8
    18f0:      	cbz	x0, 0x1978 <kprobe_unwind_hotspot+0x1978>
    18f4:      	ldr	x8, [x0]
    18f8:      	add	x8, x8, #0x1
    18fc:      	str	x8, [x0]
    1900:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1904:      	ldr	x8, [x8]
    1908:      	ldr	x22, [x21, #0xed0]
    190c:      	ldr	x29, [x21, #0xed8]
    1910:      	ldr	x9, [x21, #0xee0]
    1914:      	ldr	w8, [x8]
    1918:      	str	x9, [sp, #0x38]
    191c:      	cbz	w8, 0x1998 <kprobe_unwind_hotspot+0x1998>
    1920:      	mov	w8, #0x786c             // =30828
    1924:      	add	x13, sp, #0xc8
    1928:      	add	x0, sp, #0xc8
    192c:      	mov	w1, #0x2c               // =44
    1930:      	movk	w8, #0xa, lsl #16
    1934:      	str	w8, [sp, #0xf0]
    1938:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    193c:      	add	x8, x8, #0x0
    1940:      	ldp	x9, x10, [x8, #0x10]
    1944:      	ldp	x12, x11, [x8]
    1948:      	ldr	x8, [x8, #0x20]
    194c:      	str	x12, [sp, #0xc8]
    1950:      	stp	x11, x9, [x13, #0x8]
    1954:      	stp	x10, x8, [x13, #0x18]
    1958:      	mov	w8, #0x2c               // =44
    195c:      	mov	w9, #0x6                // =6
    1960:      	add	x10, sp, #0xc8
    1964:      	ldr	x2, [x21, #0xed0]
    1968:      	ldr	x3, [x21, #0xf10]
    196c:      	ldr	x4, [x21, #0xf08]
    1970:      	blr	x9
    1974:      	b	0x1998 <kprobe_unwind_hotspot+0x1998>
    1978:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    197c:      	ldr	x8, [x8]
    1980:      	ldr	w8, [x8]
    1984:      	cbnz	w8, 0x20b0 <kprobe_unwind_hotspot+0x20b0>
    1988:      	ldr	x8, [x21, #0xee0]
    198c:      	ldr	x22, [x21, #0xed0]
    1990:      	ldr	x29, [x21, #0xed8]
    1994:      	str	x8, [sp, #0x38]
    1998:      	ldr	x8, [x21, #0xf08]
    199c:      	ldrb	w9, [x23, #0x20]
    19a0:      	add	x10, sp, #0x88
    19a4:      	add	x0, sp, #0x88
    19a8:      	mov	w1, #0x1                // =1
    19ac:      	lsr	x25, x8, x9
    19b0:      	ldr	x8, [x21, #0xf00]
    19b4:      	mov	w9, #0x70               // =112
    19b8:      	and	x19, x8, #0xffffffffffffff
    19bc:      	mov	w8, #0x1                // =1
    19c0:      	add	x2, x25, x19
    19c4:      	blr	x9
    19c8:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    19cc:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    19d0:      	ldr	x8, [x8]
    19d4:      	ldr	w8, [x8]
    19d8:      	cbnz	w8, 0x20fc <kprobe_unwind_hotspot+0x20fc>
    19dc:      	ldrb	w8, [sp, #0x88]
    19e0:      	add	w9, w8, #0x1
    19e4:      	and	w9, w9, #0xff
    19e8:      	cmp	w9, #0x2
    19ec:      	b.hs	0x2154 <kprobe_unwind_hotspot+0x2154>
    19f0:      	cbnz	w8, 0x178 <kprobe_unwind_hotspot+0x178>
    19f4:      	ldr	x8, [x21, #0xf10]
    19f8:      	ldrb	w9, [x23, #0x20]
    19fc:      	lsl	x9, x25, x9
    1a00:      	ldrb	w10, [x23, #0x1b]
    1a04:      	add	x8, x8, x10
    1a08:      	add	x24, x9, x8
    1a0c:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1a10:      	ldr	x8, [x8]
    1a14:      	ldr	w8, [x8]
    1a18:      	cbnz	w8, 0x269c <kprobe_unwind_hotspot+0x269c>
    1a1c:      	str	x24, [sp, #0x50]
    1a20:      	cbz	x24, 0x17c <kprobe_unwind_hotspot+0x17c>
    1a24:      	mov	w8, #0x200              // =512
    1a28:      	mov	w9, #0x70               // =112
    1a2c:      	ldr	x0, [sp, #0x8]
    1a30:      	mov	w1, #0x200              // =512
    1a34:      	ldr	x2, [sp, #0x50]
    1a38:      	blr	x9
    1a3c:      	adrp	x24, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1a40:      	ldr	x24, [x24]
    1a44:      	cbnz	x0, 0x258 <kprobe_unwind_hotspot+0x258>
    1a48:      	ldrh	w8, [x23, #0x10]
    1a4c:      	cmp	x8, #0x1f8
    1a50:      	b.hi	0x3c4 <kprobe_unwind_hotspot+0x3c4>
    1a54:      	ldrh	w9, [x23, #0x12]
    1a58:      	cmp	x9, #0x1fc
    1a5c:      	b.hi	0x3c4 <kprobe_unwind_hotspot+0x3c4>
    1a60:      	ldrh	w10, [x23, #0x14]
    1a64:      	cmp	x10, #0x1f8
    1a68:      	b.hi	0x3c4 <kprobe_unwind_hotspot+0x3c4>
    1a6c:      	ldrb	w11, [x23, #0x17]
    1a70:      	ldr	x12, [sp, #0x8]
    1a74:      	mov	w1, #0x4                // =4
    1a78:      	ldr	x0, [sp, #0x40]
    1a7c:      	ldr	x11, [x12, x11]
    1a80:      	str	x11, [sp, #0x58]
    1a84:      	ldrb	w11, [x23, #0x18]
    1a88:      	ldr	x11, [x12, x11]
    1a8c:      	str	x11, [sp, #0x60]
    1a90:      	ldrb	w11, [x23, #0x1a]
    1a94:      	ldr	w11, [x12, x11]
    1a98:      	lsl	w11, w11, #3
    1a9c:      	str	w11, [sp, #0x78]
    1aa0:      	ldrb	w11, [x23, #0x19]
    1aa4:      	ldrh	w11, [x12, x11]
    1aa8:      	strh	w11, [sp, #0x80]
    1aac:      	ldr	w9, [x12, x9]
    1ab0:      	str	w9, [sp, #0x7c]
    1ab4:      	ldr	w9, [x12, x10]
    1ab8:      	str	w9, [sp, #0x74]
    1abc:      	mov	w9, #0x70               // =112
    1ac0:      	ldr	x8, [x12, x8]
    1ac4:      	str	x8, [sp, #0x68]
    1ac8:      	ldrb	w8, [x23, #0x16]
    1acc:      	ldr	x2, [x12, x8]
    1ad0:      	mov	w8, #0x4                // =4
    1ad4:      	blr	x9
    1ad8:      	adrp	x24, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1adc:      	ldr	x24, [x24]
    1ae0:      	cbnz	x0, 0x258 <kprobe_unwind_hotspot+0x258>
    1ae4:      	ldrb	w8, [x23, #0x21]
    1ae8:      	cbz	w8, 0x1b04 <kprobe_unwind_hotspot+0x1b04>
    1aec:      	ldr	x8, [sp, #0x50]
    1af0:      	ldr	w9, [sp, #0x58]
    1af4:      	add	x9, x9, x8
    1af8:      	ldr	w10, [sp, #0x60]
    1afc:      	add	x8, x10, x8
    1b00:      	stp	x9, x8, [sp, #0x58]
    1b04:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1b08:      	ldr	x8, [x8]
    1b0c:      	ldr	w8, [x8]
    1b10:      	cbnz	w8, 0x2980 <kprobe_unwind_hotspot+0x2980>
    1b14:      	ldp	x25, x8, [sp, #0x50]
    1b18:      	sub	w9, w22, w8
    1b1c:      	ldr	w19, [sp, #0x70]
    1b20:      	str	x9, [sp, #0x30]
    1b24:      	mov	w9, #0x616d             // =24941
    1b28:      	movk	w9, #0x6974, lsl #16
    1b2c:      	cmp	w19, w9
    1b30:      	b.gt	0x1f70 <kprobe_unwind_hotspot+0x1f70>
    1b34:      	mov	w8, #0x7476             // =29814
    1b38:      	movk	w8, #0x6261, lsl #16
    1b3c:      	cmp	w19, w8
    1b40:      	b.eq	0x2024 <kprobe_unwind_hotspot+0x2024>
    1b44:      	mov	w8, #0x6e49             // =28233
    1b48:      	movk	w8, #0x6574, lsl #16
    1b4c:      	cmp	w19, w8
    1b50:      	b.ne	0x204c <kprobe_unwind_hotspot+0x204c>
    1b54:      	ldr	x8, [sp, #0x38]
    1b58:      	cmp	x8, x29
    1b5c:      	b.lo	0x52c0 <kprobe_unwind_hotspot+0x52c0>
    1b60:      	ldr	x9, [sp, #0x38]
    1b64:      	add	x8, x29, #0x1, lsl #12  // =0x1000
    1b68:      	cmp	x9, x8
    1b6c:      	b.hs	0x52c0 <kprobe_unwind_hotspot+0x52c0>
    1b70:      	ldr	x8, [sp, #0x38]
    1b74:      	mov	w9, #0x70               // =112
    1b78:      	add	x10, sp, #0xc8
    1b7c:      	add	x0, sp, #0xc8
    1b80:      	mov	w1, #0x60               // =96
    1b84:      	sub	x2, x8, #0x50
    1b88:      	mov	w8, #0x60               // =96
    1b8c:      	blr	x9
    1b90:      	cbnz	x0, 0x51c <kprobe_unwind_hotspot+0x51c>
    1b94:      	ldr	w9, [x21, #0x2c0]
    1b98:      	ldr	x8, [sp, #0x20]
    1b9c:      	cbz	w9, 0x1bb0 <kprobe_unwind_hotspot+0x1bb0>
    1ba0:      	ldrb	w8, [x23, #0x1f]
    1ba4:      	cmp	w8, #0x0
    1ba8:      	ldp	x9, x8, [sp, #0x10]
    1bac:      	csel	x8, x9, x8, eq
    1bb0:      	ldr	x19, [x8]
    1bb4:      	add	x8, sp, #0xc8
    1bb8:      	mov	w10, #0x70              // =112
    1bbc:      	add	x11, sp, #0xc0
    1bc0:      	ldp	x29, x9, [x8, #0x48]
    1bc4:      	ldr	x25, [x8, #0x38]
    1bc8:      	add	x0, sp, #0xc0
    1bcc:      	mov	w1, #0x8                // =8
    1bd0:      	ldr	x24, [x8, #0x58]
    1bd4:      	ldrb	w8, [x23, #0x1c]
    1bd8:      	add	x8, x25, x8
    1bdc:      	str	x9, [sp, #0x38]
    1be0:      	mov	w9, #0x8                // =8
    1be4:      	ldrb	w8, [x23, #0x1c]
    1be8:      	add	x2, x25, x8
    1bec:      	blr	x10
    1bf0:      	cbnz	x0, 0xf20 <kprobe_unwind_hotspot+0xf20>
    1bf4:      	ldr	x8, [sp, #0xc0]
    1bf8:      	ldrb	w9, [x23, #0x1d]
    1bfc:      	add	x9, x8, x9
    1c00:      	cmp	x19, x9
    1c04:      	csel	x9, xzr, x9, lo
    1c08:      	sub	x19, x19, x9
    1c0c:      	adrp	x9, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1c10:      	ldr	x9, [x9]
    1c14:      	ldr	w9, [x9]
    1c18:      	cbnz	w9, 0x31bc <kprobe_unwind_hotspot+0x31bc>
    1c1c:      	mov	w9, #0xffff             // =65535
    1c20:      	mov	x22, #0x2000000000000000 // =2305843009213693952
    1c24:      	cmp	x19, x9
    1c28:      	csel	x9, x19, x9, lo
    1c2c:      	lsr	x19, x8, #3
    1c30:      	str	x9, [sp, #0x30]
    1c34:      	b	0x2cd0 <kprobe_unwind_hotspot+0x2cd0>
    1c38:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1c3c:      	add	x8, x8, #0x0
    1c40:      	add	x12, sp, #0xc8
    1c44:      	ldp	x9, x10, [x8, #0x10]
    1c48:      	ldr	x11, [x8, #0x20]
    1c4c:      	add	x0, sp, #0xc8
    1c50:      	mov	w1, #0x2e               // =46
    1c54:      	stp	x10, x11, [x12, #0x18]
    1c58:      	ldur	x10, [x8, #0x26]
    1c5c:      	stur	x10, [x12, #0x26]
    1c60:      	ldp	x10, x8, [x8]
    1c64:      	str	x10, [sp, #0xc8]
    1c68:      	stp	x8, x9, [x12, #0x8]
    1c6c:      	mov	w8, #0x2e               // =46
    1c70:      	mov	w9, #0x6                // =6
    1c74:      	add	x10, sp, #0xc8
    1c78:      	ldr	w2, [sp, #0x88]
    1c7c:      	blr	x9
    1c80:      	b	0x1618 <kprobe_unwind_hotspot+0x1618>
    1c84:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1c88:      	add	x8, x8, #0x0
    1c8c:      	add	x12, sp, #0xc8
    1c90:      	ldp	x9, x10, [x8, #0x10]
    1c94:      	ldr	x11, [x8, #0x20]
    1c98:      	add	x0, sp, #0xc8
    1c9c:      	mov	w1, #0x2e               // =46
    1ca0:      	stp	x10, x11, [x12, #0x18]
    1ca4:      	ldur	x10, [x8, #0x26]
    1ca8:      	stur	x10, [x12, #0x26]
    1cac:      	ldp	x10, x8, [x8]
    1cb0:      	str	x10, [sp, #0xc8]
    1cb4:      	stp	x8, x9, [x12, #0x8]
    1cb8:      	mov	w8, #0x2e               // =46
    1cbc:      	mov	w9, #0x6                // =6
    1cc0:      	add	x10, sp, #0xc8
    1cc4:      	ldr	w2, [sp, #0x88]
    1cc8:      	blr	x9
    1ccc:      	b	0x15f8 <kprobe_unwind_hotspot+0x15f8>
    1cd0:      	mov	w8, #0xa                // =10
    1cd4:      	add	x11, sp, #0xc8
    1cd8:      	add	x0, sp, #0xc8
    1cdc:      	strh	w8, [sp, #0xe8]
    1ce0:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1ce4:      	add	x8, x8, #0x0
    1ce8:      	mov	w1, #0x22               // =34
    1cec:      	ldp	x9, x10, [x8]
    1cf0:      	mov	x2, x29
    1cf4:      	str	x9, [sp, #0xc8]
    1cf8:      	ldp	x9, x8, [x8, #0x10]
    1cfc:      	stp	x10, x9, [x11, #0x8]
    1d00:      	str	x8, [x11, #0x18]
    1d04:      	mov	w8, #0x22               // =34
    1d08:      	mov	w9, #0x6                // =6
    1d0c:      	add	x10, sp, #0xc8
    1d10:      	blr	x9
    1d14:      	b	0x1654 <kprobe_unwind_hotspot+0x1654>
    1d18:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1d1c:      	add	x8, x8, #0x0
    1d20:      	add	x11, sp, #0xc8
    1d24:      	ldp	x9, x10, [x8, #0x18]
    1d28:      	add	x0, sp, #0xc8
    1d2c:      	mov	w1, #0x2f               // =47
    1d30:      	stp	x9, x10, [x11, #0x18]
    1d34:      	ldur	x10, [x8, #0x27]
    1d38:      	stur	x10, [x11, #0x27]
    1d3c:      	ldr	x10, [x8]
    1d40:      	ldp	x8, x9, [x8, #0x8]
    1d44:      	str	x10, [sp, #0xc8]
    1d48:      	stp	x8, x9, [x11, #0x8]
    1d4c:      	mov	w8, #0x2f               // =47
    1d50:      	mov	w9, #0x6                // =6
    1d54:      	add	x10, sp, #0xc8
    1d58:      	blr	x9
    1d5c:      	b	0x790 <kprobe_unwind_hotspot+0x790>
    1d60:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1d64:      	add	x8, x8, #0x0
    1d68:      	add	x11, sp, #0xc8
    1d6c:      	ldp	x9, x10, [x8]
    1d70:      	add	x0, sp, #0xc8
    1d74:      	mov	w1, #0x1e               // =30
    1d78:      	mov	x2, x29
    1d7c:      	str	x9, [sp, #0xc8]
    1d80:      	ldr	x9, [x8, #0x10]
    1d84:      	ldur	x8, [x8, #0x16]
    1d88:      	stp	x10, x9, [x11, #0x8]
    1d8c:      	mov	w9, #0x6                // =6
    1d90:      	stur	x8, [x11, #0x16]
    1d94:      	mov	w8, #0x1e               // =30
    1d98:      	add	x10, sp, #0xc8
    1d9c:      	blr	x9
    1da0:      	b	0x17a8 <kprobe_unwind_hotspot+0x17a8>
    1da4:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1da8:      	add	x8, x8, #0x0
    1dac:      	add	x13, sp, #0xc8
    1db0:      	ldp	x9, x10, [x8, #0x20]
    1db4:      	ldp	x11, x12, [x8, #0x30]
    1db8:      	add	x0, sp, #0xc8
    1dbc:      	mov	w1, #0x40               // =64
    1dc0:      	add	x20, sp, #0xc8
    1dc4:      	str	x12, [x13, #0x38]
    1dc8:      	stp	x10, x11, [x13, #0x28]
    1dcc:      	ldp	x10, x11, [x8]
    1dd0:      	str	x10, [sp, #0xc8]
    1dd4:      	ldp	x10, x8, [x8, #0x10]
    1dd8:      	stp	x11, x10, [x13, #0x8]
    1ddc:      	stp	x8, x9, [x13, #0x18]
    1de0:      	mov	w8, #0x40               // =64
    1de4:      	mov	w9, #0x6                // =6
    1de8:      	add	x10, sp, #0xc8
    1dec:      	ldr	x2, [sp, #0x88]
    1df0:      	ldr	w3, [sp, #0x74]
    1df4:      	blr	x9
    1df8:      	ldr	x22, [sp, #0x88]
    1dfc:      	ldr	x8, [sp, #0x58]
    1e00:      	b	0xcfc <kprobe_unwind_hotspot+0xcfc>
    1e04:      	mov	w8, #0xa                // =10
    1e08:      	add	x13, sp, #0xc8
    1e0c:      	add	x0, sp, #0xc8
    1e10:      	strh	w8, [sp, #0xf8]
    1e14:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1e18:      	add	x8, x8, #0x0
    1e1c:      	mov	w1, #0x32               // =50
    1e20:      	ldp	x9, x10, [x8, #0x10]
    1e24:      	ldp	x11, x12, [x8, #0x20]
    1e28:      	mov	x2, x29
    1e2c:      	mov	w4, w25
    1e30:      	str	x12, [x13, #0x28]
    1e34:      	stp	x10, x11, [x13, #0x18]
    1e38:      	ldp	x10, x8, [x8]
    1e3c:      	str	x10, [sp, #0xc8]
    1e40:      	add	x10, sp, #0xc8
    1e44:      	stp	x8, x9, [x13, #0x8]
    1e48:      	mov	w8, #0x32               // =50
    1e4c:      	mov	w9, #0x6                // =6
    1e50:      	ldr	x3, [x21, #0xf00]
    1e54:      	blr	x9
    1e58:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1e5c:      	ldr	x8, [x8]
    1e60:      	ldr	w8, [x8]
    1e64:      	cbz	w8, 0x1824 <kprobe_unwind_hotspot+0x1824>
    1e68:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1e6c:      	add	x8, x8, #0x0
    1e70:      	add	x12, sp, #0xc8
    1e74:      	ldp	x9, x10, [x8, #0x10]
    1e78:      	ldr	x11, [x8, #0x20]
    1e7c:      	add	x0, sp, #0xc8
    1e80:      	mov	w1, #0x2f               // =47
    1e84:      	stp	x10, x11, [x12, #0x18]
    1e88:      	ldur	x10, [x8, #0x27]
    1e8c:      	stur	x10, [x12, #0x27]
    1e90:      	ldp	x10, x8, [x8]
    1e94:      	str	x10, [sp, #0xc8]
    1e98:      	stp	x8, x9, [x12, #0x8]
    1e9c:      	mov	w8, #0x2f               // =47
    1ea0:      	mov	w9, #0x6                // =6
    1ea4:      	add	x10, sp, #0xc8
    1ea8:      	ldr	x2, [x21, #0xf10]
    1eac:      	ldr	x3, [x21, #0xf08]
    1eb0:      	blr	x9
    1eb4:      	b	0x1824 <kprobe_unwind_hotspot+0x1824>
    1eb8:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1ebc:      	add	x8, x8, #0x0
    1ec0:      	add	x11, sp, #0xc8
    1ec4:      	ldp	x9, x10, [x8]
    1ec8:      	add	x0, sp, #0xc8
    1ecc:      	mov	w1, #0x1d               // =29
    1ed0:      	mov	x2, x24
    1ed4:      	str	x9, [sp, #0xc8]
    1ed8:      	ldr	x9, [x8, #0x10]
    1edc:      	ldur	x8, [x8, #0x15]
    1ee0:      	add	x20, sp, #0xc8
    1ee4:      	stp	x10, x9, [x11, #0x8]
    1ee8:      	stur	x8, [x11, #0x15]
    1eec:      	mov	w8, #0x1d               // =29
    1ef0:      	mov	w9, #0x6                // =6
    1ef4:      	add	x10, sp, #0xc8
    1ef8:      	ldrb	w3, [sp, #0x88]
    1efc:      	blr	x9
    1f00:      	ldrb	w9, [sp, #0x88]
    1f04:      	add	w8, w9, #0x1
    1f08:      	and	w8, w8, #0xff
    1f0c:      	cmp	w8, #0x2
    1f10:      	mov	w8, w9
    1f14:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
    1f18:      	b	0xa84 <kprobe_unwind_hotspot+0xa84>
    1f1c:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1f20:      	add	x8, x8, #0x0
    1f24:      	add	x0, sp, #0x88
    1f28:      	ldp	x9, x10, [x8, #0x20]
    1f2c:      	mov	w1, #0x35               // =53
    1f30:      	mov	x4, x19
    1f34:      	stp	x9, x10, [sp, #0xa8]
    1f38:      	ldur	x9, [x8, #0x2d]
    1f3c:      	stur	x9, [sp, #0xb5]
    1f40:      	ldp	x9, x10, [x8]
    1f44:      	stp	x9, x10, [sp, #0x88]
    1f48:      	ldp	x8, x9, [x8, #0x10]
    1f4c:      	add	x10, sp, #0x88
    1f50:      	stp	x8, x9, [sp, #0x98]
    1f54:      	mov	w8, #0x35               // =53
    1f58:      	mov	w9, #0x6                // =6
    1f5c:      	ldr	x3, [sp, #0xc0]
    1f60:      	ldr	x2, [sp, #0x30]
    1f64:      	blr	x9
    1f68:      	ldr	x8, [sp, #0xc0]
    1f6c:      	b	0x1094 <kprobe_unwind_hotspot+0x1094>
    1f70:      	mov	w9, #0x616e             // =24942
    1f74:      	movk	w9, #0x6974, lsl #16
    1f78:      	cmp	w19, w9
    1f7c:      	b.eq	0x1f90 <kprobe_unwind_hotspot+0x1f90>
    1f80:      	mov	w9, #0x6d6e             // =28014
    1f84:      	movk	w9, #0x7465, lsl #16
    1f88:      	cmp	w19, w9
    1f8c:      	b.ne	0x204c <kprobe_unwind_hotspot+0x204c>
    1f90:      	ldr	x9, [sp, #0x68]
    1f94:      	ldrb	w10, [x23, #0x21]
    1f98:      	add	x11, x25, w9, uxtw
    1f9c:      	ldr	w19, [sp, #0x7c]
    1fa0:      	cmp	w10, #0x0
    1fa4:      	csel	x9, x9, x11, eq
    1fa8:      	cmp	x22, x9
    1fac:      	b.ne	0x1ff0 <kprobe_unwind_hotspot+0x1ff0>
    1fb0:      	ldr	w8, [sp, #0x74]
    1fb4:      	mov	w9, #0x8                // =8
    1fb8:      	mov	w10, #0x70              // =112
    1fbc:      	add	x11, sp, #0x88
    1fc0:      	add	x0, sp, #0x88
    1fc4:      	mov	w1, #0x8                // =8
    1fc8:      	add	x8, x29, x8
    1fcc:      	ldr	w8, [sp, #0x74]
    1fd0:      	add	x2, x29, x8
    1fd4:      	blr	x10
    1fd8:      	cbz	x0, 0x2638 <kprobe_unwind_hotspot+0x2638>
    1fdc:      	adrp	x8, 0x1000 <kprobe_unwind_hotspot+0x1000>
    1fe0:      	ldr	x8, [x8]
    1fe4:      	ldr	w8, [x8]
    1fe8:      	cbnz	w8, 0x2b30 <kprobe_unwind_hotspot+0x2b30>
    1fec:      	ldr	x8, [sp, #0x58]
    1ff0:      	ldrh	w9, [sp, #0x80]
    1ff4:      	add	x8, x8, x9
    1ff8:      	cmp	x22, x8
    1ffc:      	b.hs	0x2074 <kprobe_unwind_hotspot+0x2074>
    2000:      	sub	x8, x8, #0x4
    2004:      	cmp	x22, x8
    2008:      	b.ne	0x25e4 <kprobe_unwind_hotspot+0x25e4>
    200c:      	ldr	w8, [sp, #0x78]
    2010:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    2014:      	add	x29, x29, x8
    2018:      	ldrb	w8, [x21, #0xf21]
    201c:      	cbnz	w8, 0x7bc <kprobe_unwind_hotspot+0x7bc>
    2020:      	b	0x2694 <kprobe_unwind_hotspot+0x2694>
    2024:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2028:      	mov	w19, #0x7476            // =29814
    202c:      	ldr	x8, [x8]
    2030:      	movk	w19, #0x6261, lsl #16
    2034:      	ldr	w8, [x8]
    2038:      	cbnz	w8, 0x2aec <kprobe_unwind_hotspot+0x2aec>
    203c:      	mov	x22, #0x1000000000000000 // =1152921504606846976
    2040:      	ldrb	w8, [x21, #0xf21]
    2044:      	cbnz	w8, 0x7bc <kprobe_unwind_hotspot+0x7bc>
    2048:      	b	0x2694 <kprobe_unwind_hotspot+0x2694>
    204c:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2050:      	ldr	x24, [x21, #0xf00]
    2054:      	ldr	x8, [x8]
    2058:      	ldr	w8, [x8]
    205c:      	tbnz	x24, #0x3f, 0x2674 <kprobe_unwind_hotspot+0x2674>
    2060:      	cbnz	w8, 0x2b74 <kprobe_unwind_hotspot+0x2b74>
    2064:      	ldr	w8, [sp, #0x78]
    2068:      	mov	x22, xzr
    206c:      	cbnz	w8, 0x2c84 <kprobe_unwind_hotspot+0x2c84>
    2070:      	b	0x2c78 <kprobe_unwind_hotspot+0x2c78>
    2074:      	ldr	x8, [sp, #0x38]
    2078:      	subs	x2, x8, x29
    207c:      	b.lo	0x2498 <kprobe_unwind_hotspot+0x2498>
    2080:      	ldr	w8, [sp, #0x78]
    2084:      	ldr	x9, [sp, #0x38]
    2088:      	add	x8, x29, x8
    208c:      	add	x8, x8, #0x30
    2090:      	cmp	x9, x8
    2094:      	b.hs	0x2498 <kprobe_unwind_hotspot+0x2498>
    2098:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    209c:      	ldr	x8, [x8]
    20a0:      	ldr	w8, [x8]
    20a4:      	cbnz	w8, 0x3004 <kprobe_unwind_hotspot+0x3004>
    20a8:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    20ac:      	b	0x2c78 <kprobe_unwind_hotspot+0x2c78>
    20b0:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    20b4:      	add	x8, x8, #0x0
    20b8:      	add	x12, sp, #0xc8
    20bc:      	ldp	x9, x10, [x8, #0x10]
    20c0:      	ldr	x11, [x8, #0x20]
    20c4:      	add	x0, sp, #0xc8
    20c8:      	mov	w1, #0x2e               // =46
    20cc:      	stp	x10, x11, [x12, #0x18]
    20d0:      	ldur	x10, [x8, #0x26]
    20d4:      	stur	x10, [x12, #0x26]
    20d8:      	ldp	x10, x8, [x8]
    20dc:      	str	x10, [sp, #0xc8]
    20e0:      	stp	x8, x9, [x12, #0x8]
    20e4:      	mov	w8, #0x2e               // =46
    20e8:      	mov	w9, #0x6                // =6
    20ec:      	add	x10, sp, #0xc8
    20f0:      	ldr	w2, [sp, #0x50]
    20f4:      	blr	x9
    20f8:      	b	0x1900 <kprobe_unwind_hotspot+0x1900>
    20fc:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2100:      	add	x8, x8, #0x0
    2104:      	add	x11, sp, #0xc8
    2108:      	ldp	x9, x10, [x8]
    210c:      	add	x0, sp, #0xc8
    2110:      	mov	w1, #0x1d               // =29
    2114:      	mov	x2, x25
    2118:      	str	x9, [sp, #0xc8]
    211c:      	ldr	x9, [x8, #0x10]
    2120:      	ldur	x8, [x8, #0x15]
    2124:      	stp	x10, x9, [x11, #0x8]
    2128:      	mov	w9, #0x6                // =6
    212c:      	stur	x8, [x11, #0x15]
    2130:      	mov	w8, #0x1d               // =29
    2134:      	add	x10, sp, #0xc8
    2138:      	ldrb	w3, [sp, #0x88]
    213c:      	blr	x9
    2140:      	ldrb	w8, [sp, #0x88]
    2144:      	add	w9, w8, #0x1
    2148:      	and	w9, w9, #0xff
    214c:      	cmp	w9, #0x2
    2150:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    2154:      	sub	x25, x25, x8
    2158:      	mov	w8, #0x1                // =1
    215c:      	mov	w9, #0x70               // =112
    2160:      	add	x10, sp, #0x88
    2164:      	add	x0, sp, #0x88
    2168:      	mov	w1, #0x1                // =1
    216c:      	add	x2, x25, x19
    2170:      	blr	x9
    2174:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    2178:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    217c:      	ldr	x8, [x8]
    2180:      	ldr	w8, [x8]
    2184:      	cbnz	w8, 0x26e8 <kprobe_unwind_hotspot+0x26e8>
    2188:      	ldrb	w9, [sp, #0x88]
    218c:      	add	w8, w9, #0x1
    2190:      	and	w8, w8, #0xff
    2194:      	cmp	w8, #0x2
    2198:      	mov	w8, w9
    219c:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    21a0:      	sub	x25, x25, x9
    21a4:      	mov	w8, #0x1                // =1
    21a8:      	mov	w9, #0x70               // =112
    21ac:      	add	x10, sp, #0x88
    21b0:      	add	x0, sp, #0x88
    21b4:      	mov	w1, #0x1                // =1
    21b8:      	add	x2, x25, x19
    21bc:      	blr	x9
    21c0:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    21c4:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    21c8:      	ldr	x8, [x8]
    21cc:      	ldr	w8, [x8]
    21d0:      	cbnz	w8, 0x27f8 <kprobe_unwind_hotspot+0x27f8>
    21d4:      	ldrb	w9, [sp, #0x88]
    21d8:      	add	w8, w9, #0x1
    21dc:      	and	w8, w8, #0xff
    21e0:      	cmp	w8, #0x2
    21e4:      	mov	w8, w9
    21e8:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    21ec:      	sub	x25, x25, x9
    21f0:      	mov	w8, #0x1                // =1
    21f4:      	mov	w9, #0x70               // =112
    21f8:      	add	x10, sp, #0x88
    21fc:      	add	x0, sp, #0x88
    2200:      	mov	w1, #0x1                // =1
    2204:      	add	x2, x25, x19
    2208:      	blr	x9
    220c:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    2210:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2214:      	ldr	x8, [x8]
    2218:      	ldr	w8, [x8]
    221c:      	cbnz	w8, 0x28bc <kprobe_unwind_hotspot+0x28bc>
    2220:      	ldrb	w9, [sp, #0x88]
    2224:      	add	w8, w9, #0x1
    2228:      	and	w8, w8, #0xff
    222c:      	cmp	w8, #0x2
    2230:      	mov	w8, w9
    2234:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    2238:      	sub	x25, x25, x9
    223c:      	mov	w8, #0x1                // =1
    2240:      	mov	w9, #0x70               // =112
    2244:      	add	x10, sp, #0x88
    2248:      	add	x0, sp, #0x88
    224c:      	mov	w1, #0x1                // =1
    2250:      	add	x2, x25, x19
    2254:      	blr	x9
    2258:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    225c:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2260:      	ldr	x8, [x8]
    2264:      	ldr	w8, [x8]
    2268:      	cbnz	w8, 0x2a2c <kprobe_unwind_hotspot+0x2a2c>
    226c:      	ldrb	w9, [sp, #0x88]
    2270:      	add	w8, w9, #0x1
    2274:      	and	w8, w8, #0xff
    2278:      	cmp	w8, #0x2
    227c:      	mov	w8, w9
    2280:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    2284:      	sub	x25, x25, x9
    2288:      	mov	w8, #0x1                // =1
    228c:      	mov	w9, #0x70               // =112
    2290:      	add	x10, sp, #0x88
    2294:      	add	x0, sp, #0x88
    2298:      	mov	w1, #0x1                // =1
    229c:      	add	x2, x25, x19
    22a0:      	blr	x9
    22a4:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    22a8:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    22ac:      	ldr	x8, [x8]
    22b0:      	ldr	w8, [x8]
    22b4:      	cbnz	w8, 0x2bc8 <kprobe_unwind_hotspot+0x2bc8>
    22b8:      	ldrb	w9, [sp, #0x88]
    22bc:      	add	w8, w9, #0x1
    22c0:      	and	w8, w8, #0xff
    22c4:      	cmp	w8, #0x2
    22c8:      	mov	w8, w9
    22cc:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    22d0:      	sub	x25, x25, x9
    22d4:      	mov	w8, #0x1                // =1
    22d8:      	mov	w9, #0x70               // =112
    22dc:      	add	x10, sp, #0x88
    22e0:      	add	x0, sp, #0x88
    22e4:      	mov	w1, #0x1                // =1
    22e8:      	add	x2, x25, x19
    22ec:      	blr	x9
    22f0:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    22f4:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    22f8:      	ldr	x8, [x8]
    22fc:      	ldr	w8, [x8]
    2300:      	cbnz	w8, 0x315c <kprobe_unwind_hotspot+0x315c>
    2304:      	ldrb	w9, [sp, #0x88]
    2308:      	add	w8, w9, #0x1
    230c:      	and	w8, w8, #0xff
    2310:      	cmp	w8, #0x2
    2314:      	mov	w8, w9
    2318:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    231c:      	sub	x25, x25, x9
    2320:      	mov	w8, #0x1                // =1
    2324:      	mov	w9, #0x70               // =112
    2328:      	add	x10, sp, #0x88
    232c:      	add	x0, sp, #0x88
    2330:      	mov	w1, #0x1                // =1
    2334:      	add	x2, x25, x19
    2338:      	blr	x9
    233c:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    2340:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2344:      	ldr	x8, [x8]
    2348:      	ldr	w8, [x8]
    234c:      	cbnz	w8, 0x3cdc <kprobe_unwind_hotspot+0x3cdc>
    2350:      	ldrb	w9, [sp, #0x88]
    2354:      	add	w8, w9, #0x1
    2358:      	and	w8, w8, #0xff
    235c:      	cmp	w8, #0x2
    2360:      	mov	w8, w9
    2364:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    2368:      	sub	x25, x25, x9
    236c:      	mov	w8, #0x1                // =1
    2370:      	mov	w9, #0x70               // =112
    2374:      	add	x10, sp, #0x88
    2378:      	add	x0, sp, #0x88
    237c:      	mov	w1, #0x1                // =1
    2380:      	add	x2, x25, x19
    2384:      	blr	x9
    2388:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    238c:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2390:      	ldr	x8, [x8]
    2394:      	ldr	w8, [x8]
    2398:      	cbnz	w8, 0x3eac <kprobe_unwind_hotspot+0x3eac>
    239c:      	ldrb	w9, [sp, #0x88]
    23a0:      	add	w8, w9, #0x1
    23a4:      	and	w8, w8, #0xff
    23a8:      	cmp	w8, #0x2
    23ac:      	mov	w8, w9
    23b0:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    23b4:      	sub	x25, x25, x9
    23b8:      	mov	w8, #0x1                // =1
    23bc:      	mov	w9, #0x70               // =112
    23c0:      	add	x10, sp, #0x88
    23c4:      	add	x0, sp, #0x88
    23c8:      	mov	w1, #0x1                // =1
    23cc:      	add	x2, x25, x19
    23d0:      	blr	x9
    23d4:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    23d8:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    23dc:      	ldr	x8, [x8]
    23e0:      	ldr	w8, [x8]
    23e4:      	cbnz	w8, 0x3fb8 <kprobe_unwind_hotspot+0x3fb8>
    23e8:      	ldrb	w9, [sp, #0x88]
    23ec:      	add	w8, w9, #0x1
    23f0:      	and	w8, w8, #0xff
    23f4:      	cmp	w8, #0x2
    23f8:      	mov	w8, w9
    23fc:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    2400:      	sub	x25, x25, x9
    2404:      	mov	w8, #0x1                // =1
    2408:      	mov	w9, #0x70               // =112
    240c:      	add	x10, sp, #0x88
    2410:      	add	x0, sp, #0x88
    2414:      	mov	w1, #0x1                // =1
    2418:      	add	x2, x25, x19
    241c:      	blr	x9
    2420:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    2424:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2428:      	ldr	x8, [x8]
    242c:      	ldr	w8, [x8]
    2430:      	cbnz	w8, 0x4018 <kprobe_unwind_hotspot+0x4018>
    2434:      	ldrb	w9, [sp, #0x88]
    2438:      	add	w8, w9, #0x1
    243c:      	and	w8, w8, #0xff
    2440:      	cmp	w8, #0x2
    2444:      	mov	w8, w9
    2448:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    244c:      	sub	x25, x25, x9
    2450:      	mov	w8, #0x1                // =1
    2454:      	mov	w9, #0x70               // =112
    2458:      	add	x10, sp, #0x88
    245c:      	add	x0, sp, #0x88
    2460:      	mov	w1, #0x1                // =1
    2464:      	add	x2, x25, x19
    2468:      	blr	x9
    246c:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    2470:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2474:      	ldr	x8, [x8]
    2478:      	ldr	w8, [x8]
    247c:      	cbnz	w8, 0x4078 <kprobe_unwind_hotspot+0x4078>
    2480:      	ldrb	w8, [sp, #0x88]
    2484:      	add	w9, w8, #0x1
    2488:      	and	w9, w9, #0xff
    248c:      	cmp	w9, #0x1
    2490:      	b.hi	0x178 <kprobe_unwind_hotspot+0x178>
    2494:      	b	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    2498:      	sub	x2, x22, #0x8
    249c:      	mov	w8, #0x8                // =8
    24a0:      	mov	w9, #0x70               // =112
    24a4:      	add	x10, sp, #0xc8
    24a8:      	add	x0, sp, #0xc8
    24ac:      	mov	w1, #0x8                // =8
    24b0:      	blr	x9
    24b4:      	ldr	x8, [sp, #0xc8]
    24b8:      	mov	x9, #0x27ff             // =10239
    24bc:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    24c0:      	movk	x9, #0xa9bf, lsl #16
    24c4:      	movk	x9, #0x100, lsl #32
    24c8:      	movk	x9, #0xd63f, lsl #48
    24cc:      	cmp	x8, x9
    24d0:      	add	x8, x29, #0x10
    24d4:      	ccmp	x0, #0x0, #0x0, eq
    24d8:      	csel	x29, x8, x29, eq
    24dc:      	ldr	w8, [sp, #0x78]
    24e0:      	b	0x2c84 <kprobe_unwind_hotspot+0x2c84>
    24e4:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    24e8:      	add	x8, x8, #0x0
    24ec:      	add	x11, sp, #0xc8
    24f0:      	ldp	x9, x10, [x8]
    24f4:      	add	x0, sp, #0xc8
    24f8:      	mov	w1, #0x1e               // =30
    24fc:      	str	x9, [sp, #0xc8]
    2500:      	ldr	x9, [x8, #0x10]
    2504:      	ldur	x8, [x8, #0x16]
    2508:      	stp	x10, x9, [x11, #0x8]
    250c:      	mov	w9, #0x6                // =6
    2510:      	stur	x8, [x11, #0x16]
    2514:      	mov	w8, #0x1e               // =30
    2518:      	add	x10, sp, #0xc8
    251c:      	ldrh	w2, [x25, #0x20]
    2520:      	blr	x9
    2524:      	ldrh	w8, [x25, #0x20]
    2528:      	ldr	w9, [x21, #0x1370]
    252c:      	lsr	w8, w9, w8
    2530:      	tbnz	w8, #0x0, 0x18ac <kprobe_unwind_hotspot+0x18ac>
    2534:      	str	wzr, [sp, #0x88]
    2538:      	adrp	x0, 0x2000 <kprobe_unwind_hotspot+0x2000>
    253c:      	mov	w8, #0x1                // =1
    2540:      	add	x9, sp, #0x88
    2544:      	ldr	x0, [x0]
    2548:      	add	x1, sp, #0x88
    254c:      	blr	x8
    2550:      	cbz	x0, 0x2568 <kprobe_unwind_hotspot+0x2568>
    2554:      	ldr	x8, [x0]
    2558:      	add	x8, x8, #0x1
    255c:      	str	x8, [x0]
    2560:      	ldrh	w25, [x25, #0x20]
    2564:      	b	0x18c8 <kprobe_unwind_hotspot+0x18c8>
    2568:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    256c:      	ldr	x8, [x8]
    2570:      	ldr	w8, [x8]
    2574:      	cbnz	w8, 0x27ac <kprobe_unwind_hotspot+0x27ac>
    2578:      	ldrh	w25, [x25, #0x20]
    257c:      	b	0x18c8 <kprobe_unwind_hotspot+0x18c8>
    2580:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2584:      	add	x8, x8, #0x0
    2588:      	add	x11, sp, #0xc8
    258c:      	ldp	x9, x10, [x8]
    2590:      	add	x0, sp, #0xc8
    2594:      	mov	w1, #0x1d               // =29
    2598:      	mov	x2, x24
    259c:      	str	x9, [sp, #0xc8]
    25a0:      	ldr	x9, [x8, #0x10]
    25a4:      	ldur	x8, [x8, #0x15]
    25a8:      	add	x20, sp, #0xc8
    25ac:      	stp	x10, x9, [x11, #0x8]
    25b0:      	stur	x8, [x11, #0x15]
    25b4:      	mov	w8, #0x1d               // =29
    25b8:      	mov	w9, #0x6                // =6
    25bc:      	add	x10, sp, #0xc8
    25c0:      	ldrb	w3, [sp, #0x88]
    25c4:      	blr	x9
    25c8:      	ldrb	w9, [sp, #0x88]
    25cc:      	add	w8, w9, #0x1
    25d0:      	and	w8, w8, #0xff
    25d4:      	cmp	w8, #0x2
    25d8:      	mov	w8, w9
    25dc:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
    25e0:      	b	0xad0 <kprobe_unwind_hotspot+0xad0>
    25e4:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    25e8:      	ldrb	w8, [x21, #0xf21]
    25ec:      	cbnz	w8, 0x7bc <kprobe_unwind_hotspot+0x7bc>
    25f0:      	b	0x2694 <kprobe_unwind_hotspot+0x2694>
    25f4:      	mov	w8, #0x656e             // =25966
    25f8:      	add	x11, sp, #0xc8
    25fc:      	add	x0, sp, #0xc8
    2600:      	mov	w1, #0x1b               // =27
    2604:      	movk	w8, #0xa, lsl #16
    2608:      	stur	w8, [x11, #0x17]
    260c:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2610:      	add	x8, x8, #0x0
    2614:      	ldp	x9, x10, [x8]
    2618:      	ldr	x8, [x8, #0x10]
    261c:      	str	x9, [sp, #0xc8]
    2620:      	mov	w9, #0x6                // =6
    2624:      	stp	x10, x8, [x11, #0x8]
    2628:      	mov	w8, #0x1b               // =27
    262c:      	add	x10, sp, #0xc8
    2630:      	blr	x9
    2634:      	b	0x18bc <kprobe_unwind_hotspot+0x18bc>
    2638:      	ldr	x9, [sp, #0x88]
    263c:      	ldr	x8, [sp, #0x58]
    2640:      	cmp	x9, x8
    2644:      	b.lo	0x1fdc <kprobe_unwind_hotspot+0x1fdc>
    2648:      	ldr	x10, [sp, #0x60]
    264c:      	cmp	x9, x10
    2650:      	b.hs	0x1fdc <kprobe_unwind_hotspot+0x1fdc>
    2654:      	adrp	x10, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2658:      	ldr	x10, [x10]
    265c:      	ldr	w10, [x10]
    2660:      	cbnz	w10, 0x304c <kprobe_unwind_hotspot+0x304c>
    2664:      	mov	x22, x9
    2668:      	sub	w8, w22, w8
    266c:      	str	x8, [sp, #0x30]
    2670:      	b	0x1fec <kprobe_unwind_hotspot+0x1fec>
    2674:      	cbnz	w8, 0x2c28 <kprobe_unwind_hotspot+0x2c28>
    2678:      	mov	x22, xzr
    267c:      	tbnz	x24, #0x3e, 0x2c78 <kprobe_unwind_hotspot+0x2c78>
    2680:      	lsr	x8, x24, #53
    2684:      	and	x8, x8, #0x1f8
    2688:      	add	x29, x8, x29
    268c:      	ldrb	w8, [x21, #0xf21]
    2690:      	cbnz	w8, 0x7bc <kprobe_unwind_hotspot+0x7bc>
    2694:      	ldr	x24, [x21, #0xee8]
    2698:      	b	0x2cd0 <kprobe_unwind_hotspot+0x2cd0>
    269c:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    26a0:      	add	x8, x8, #0x0
    26a4:      	add	x11, sp, #0xc8
    26a8:      	strb	wzr, [sp, #0xe8]
    26ac:      	ldp	x9, x10, [x8]
    26b0:      	add	x0, sp, #0xc8
    26b4:      	mov	w1, #0x21               // =33
    26b8:      	mov	x2, x24
    26bc:      	str	x9, [sp, #0xc8]
    26c0:      	ldp	x9, x8, [x8, #0x10]
    26c4:      	str	x8, [x11, #0x18]
    26c8:      	stp	x10, x9, [x11, #0x8]
    26cc:      	mov	w8, #0x21               // =33
    26d0:      	mov	w9, #0x6                // =6
    26d4:      	add	x10, sp, #0xc8
    26d8:      	blr	x9
    26dc:      	str	x24, [sp, #0x50]
    26e0:      	cbnz	x24, 0x1a24 <kprobe_unwind_hotspot+0x1a24>
    26e4:      	b	0x17c <kprobe_unwind_hotspot+0x17c>
    26e8:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    26ec:      	add	x8, x8, #0x0
    26f0:      	add	x11, sp, #0xc8
    26f4:      	ldp	x9, x10, [x8]
    26f8:      	add	x0, sp, #0xc8
    26fc:      	mov	w1, #0x1d               // =29
    2700:      	mov	x2, x25
    2704:      	str	x9, [sp, #0xc8]
    2708:      	ldr	x9, [x8, #0x10]
    270c:      	ldur	x8, [x8, #0x15]
    2710:      	stp	x10, x9, [x11, #0x8]
    2714:      	mov	w9, #0x6                // =6
    2718:      	stur	x8, [x11, #0x15]
    271c:      	mov	w8, #0x1d               // =29
    2720:      	add	x10, sp, #0xc8
    2724:      	ldrb	w3, [sp, #0x88]
    2728:      	blr	x9
    272c:      	ldrb	w9, [sp, #0x88]
    2730:      	add	w8, w9, #0x1
    2734:      	and	w8, w8, #0xff
    2738:      	cmp	w8, #0x2
    273c:      	mov	w8, w9
    2740:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    2744:      	b	0x21a0 <kprobe_unwind_hotspot+0x21a0>
    2748:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    274c:      	add	x8, x8, #0x0
    2750:      	add	x11, sp, #0xc8
    2754:      	ldp	x9, x10, [x8]
    2758:      	add	x0, sp, #0xc8
    275c:      	mov	w1, #0x1d               // =29
    2760:      	mov	x2, x24
    2764:      	str	x9, [sp, #0xc8]
    2768:      	ldr	x9, [x8, #0x10]
    276c:      	ldur	x8, [x8, #0x15]
    2770:      	add	x20, sp, #0xc8
    2774:      	stp	x10, x9, [x11, #0x8]
    2778:      	stur	x8, [x11, #0x15]
    277c:      	mov	w8, #0x1d               // =29
    2780:      	mov	w9, #0x6                // =6
    2784:      	add	x10, sp, #0xc8
    2788:      	ldrb	w3, [sp, #0x88]
    278c:      	blr	x9
    2790:      	ldrb	w9, [sp, #0x88]
    2794:      	add	w8, w9, #0x1
    2798:      	and	w8, w8, #0xff
    279c:      	cmp	w8, #0x2
    27a0:      	mov	w8, w9
    27a4:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
    27a8:      	b	0xb1c <kprobe_unwind_hotspot+0xb1c>
    27ac:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    27b0:      	add	x8, x8, #0x0
    27b4:      	add	x12, sp, #0xc8
    27b8:      	ldp	x9, x10, [x8, #0x10]
    27bc:      	ldr	x11, [x8, #0x20]
    27c0:      	add	x0, sp, #0xc8
    27c4:      	mov	w1, #0x2e               // =46
    27c8:      	stp	x10, x11, [x12, #0x18]
    27cc:      	ldur	x10, [x8, #0x26]
    27d0:      	stur	x10, [x12, #0x26]
    27d4:      	ldp	x10, x8, [x8]
    27d8:      	str	x10, [sp, #0xc8]
    27dc:      	stp	x8, x9, [x12, #0x8]
    27e0:      	mov	w8, #0x2e               // =46
    27e4:      	mov	w9, #0x6                // =6
    27e8:      	add	x10, sp, #0xc8
    27ec:      	ldr	w2, [sp, #0x88]
    27f0:      	blr	x9
    27f4:      	b	0x2578 <kprobe_unwind_hotspot+0x2578>
    27f8:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    27fc:      	add	x8, x8, #0x0
    2800:      	add	x11, sp, #0xc8
    2804:      	ldp	x9, x10, [x8]
    2808:      	add	x0, sp, #0xc8
    280c:      	mov	w1, #0x1d               // =29
    2810:      	mov	x2, x25
    2814:      	str	x9, [sp, #0xc8]
    2818:      	ldr	x9, [x8, #0x10]
    281c:      	ldur	x8, [x8, #0x15]
    2820:      	stp	x10, x9, [x11, #0x8]
    2824:      	mov	w9, #0x6                // =6
    2828:      	stur	x8, [x11, #0x15]
    282c:      	mov	w8, #0x1d               // =29
    2830:      	add	x10, sp, #0xc8
    2834:      	ldrb	w3, [sp, #0x88]
    2838:      	blr	x9
    283c:      	ldrb	w9, [sp, #0x88]
    2840:      	add	w8, w9, #0x1
    2844:      	and	w8, w8, #0xff
    2848:      	cmp	w8, #0x2
    284c:      	mov	w8, w9
    2850:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    2854:      	b	0x21ec <kprobe_unwind_hotspot+0x21ec>
    2858:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    285c:      	add	x8, x8, #0x0
    2860:      	add	x11, sp, #0xc8
    2864:      	ldp	x9, x10, [x8]
    2868:      	add	x0, sp, #0xc8
    286c:      	mov	w1, #0x1d               // =29
    2870:      	mov	x2, x24
    2874:      	str	x9, [sp, #0xc8]
    2878:      	ldr	x9, [x8, #0x10]
    287c:      	ldur	x8, [x8, #0x15]
    2880:      	add	x20, sp, #0xc8
    2884:      	stp	x10, x9, [x11, #0x8]
    2888:      	stur	x8, [x11, #0x15]
    288c:      	mov	w8, #0x1d               // =29
    2890:      	mov	w9, #0x6                // =6
    2894:      	add	x10, sp, #0xc8
    2898:      	ldrb	w3, [sp, #0x88]
    289c:      	blr	x9
    28a0:      	ldrb	w9, [sp, #0x88]
    28a4:      	add	w8, w9, #0x1
    28a8:      	and	w8, w8, #0xff
    28ac:      	cmp	w8, #0x2
    28b0:      	mov	w8, w9
    28b4:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
    28b8:      	b	0xb68 <kprobe_unwind_hotspot+0xb68>
    28bc:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    28c0:      	add	x8, x8, #0x0
    28c4:      	add	x11, sp, #0xc8
    28c8:      	ldp	x9, x10, [x8]
    28cc:      	add	x0, sp, #0xc8
    28d0:      	mov	w1, #0x1d               // =29
    28d4:      	mov	x2, x25
    28d8:      	str	x9, [sp, #0xc8]
    28dc:      	ldr	x9, [x8, #0x10]
    28e0:      	ldur	x8, [x8, #0x15]
    28e4:      	stp	x10, x9, [x11, #0x8]
    28e8:      	mov	w9, #0x6                // =6
    28ec:      	stur	x8, [x11, #0x15]
    28f0:      	mov	w8, #0x1d               // =29
    28f4:      	add	x10, sp, #0xc8
    28f8:      	ldrb	w3, [sp, #0x88]
    28fc:      	blr	x9
    2900:      	ldrb	w9, [sp, #0x88]
    2904:      	add	w8, w9, #0x1
    2908:      	and	w8, w8, #0xff
    290c:      	cmp	w8, #0x2
    2910:      	mov	w8, w9
    2914:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    2918:      	b	0x2238 <kprobe_unwind_hotspot+0x2238>
    291c:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2920:      	add	x8, x8, #0x0
    2924:      	add	x11, sp, #0xc8
    2928:      	ldp	x9, x10, [x8]
    292c:      	add	x0, sp, #0xc8
    2930:      	mov	w1, #0x1d               // =29
    2934:      	mov	x2, x24
    2938:      	str	x9, [sp, #0xc8]
    293c:      	ldr	x9, [x8, #0x10]
    2940:      	ldur	x8, [x8, #0x15]
    2944:      	add	x20, sp, #0xc8
    2948:      	stp	x10, x9, [x11, #0x8]
    294c:      	stur	x8, [x11, #0x15]
    2950:      	mov	w8, #0x1d               // =29
    2954:      	mov	w9, #0x6                // =6
    2958:      	add	x10, sp, #0xc8
    295c:      	ldrb	w3, [sp, #0x88]
    2960:      	blr	x9
    2964:      	ldrb	w9, [sp, #0x88]
    2968:      	add	w8, w9, #0x1
    296c:      	and	w8, w8, #0xff
    2970:      	cmp	w8, #0x2
    2974:      	mov	w8, w9
    2978:      	b.lo	0x1fc <kprobe_unwind_hotspot+0x1fc>
    297c:      	b	0xbb4 <kprobe_unwind_hotspot+0xbb4>
    2980:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2984:      	add	x8, x8, #0x0
    2988:      	add	x0, sp, #0xc8
    298c:      	ldp	x9, x10, [x8]
    2990:      	ldur	x8, [x8, #0xf]
    2994:      	mov	w1, #0x17               // =23
    2998:      	str	x9, [sp, #0xc8]
    299c:      	add	x9, sp, #0xc8
    29a0:      	str	x10, [x9, #0x8]
    29a4:      	stur	x8, [x9, #0xf]
    29a8:      	mov	w8, #0x17               // =23
    29ac:      	mov	w9, #0x6                // =6
    29b0:      	add	x10, sp, #0xc8
    29b4:      	ldp	x2, x3, [sp, #0x58]
    29b8:      	blr	x9
    29bc:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    29c0:      	ldr	x8, [x8]
    29c4:      	ldr	w8, [x8]
    29c8:      	cbz	w8, 0x1b14 <kprobe_unwind_hotspot+0x1b14>
    29cc:      	mov	w8, #0x7825             // =30757
    29d0:      	add	x13, sp, #0xc8
    29d4:      	add	x0, sp, #0xc8
    29d8:      	mov	w1, #0x3c               // =60
    29dc:      	movk	w8, #0xa, lsl #16
    29e0:      	str	w8, [sp, #0x100]
    29e4:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    29e8:      	add	x8, x8, #0x0
    29ec:      	ldp	x9, x10, [x8, #0x20]
    29f0:      	ldp	x12, x11, [x8, #0x10]
    29f4:      	stp	x11, x9, [x13, #0x18]
    29f8:      	ldr	x9, [x8, #0x30]
    29fc:      	stp	x10, x9, [x13, #0x28]
    2a00:      	ldp	x9, x8, [x8]
    2a04:      	add	x10, sp, #0xc8
    2a08:      	str	x9, [sp, #0xc8]
    2a0c:      	stp	x8, x12, [x13, #0x8]
    2a10:      	mov	w8, #0x3c               // =60
    2a14:      	mov	w9, #0x6                // =6
    2a18:      	ldrh	w2, [sp, #0x80]
    2a1c:      	ldr	w3, [sp, #0x78]
    2a20:      	ldr	w4, [sp, #0x70]
    2a24:      	blr	x9
    2a28:      	b	0x1b14 <kprobe_unwind_hotspot+0x1b14>
    2a2c:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2a30:      	add	x8, x8, #0x0
    2a34:      	add	x11, sp, #0xc8
    2a38:      	ldp	x9, x10, [x8]
    2a3c:      	add	x0, sp, #0xc8
    2a40:      	mov	w1, #0x1d               // =29
    2a44:      	mov	x2, x25
    2a48:      	str	x9, [sp, #0xc8]
    2a4c:      	ldr	x9, [x8, #0x10]
    2a50:      	ldur	x8, [x8, #0x15]
    2a54:      	stp	x10, x9, [x11, #0x8]
    2a58:      	mov	w9, #0x6                // =6
    2a5c:      	stur	x8, [x11, #0x15]
    2a60:      	mov	w8, #0x1d               // =29
    2a64:      	add	x10, sp, #0xc8
    2a68:      	ldrb	w3, [sp, #0x88]
    2a6c:      	blr	x9
    2a70:      	ldrb	w9, [sp, #0x88]
    2a74:      	add	w8, w9, #0x1
    2a78:      	and	w8, w8, #0xff
    2a7c:      	cmp	w8, #0x2
    2a80:      	mov	w8, w9
    2a84:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    2a88:      	b	0x2284 <kprobe_unwind_hotspot+0x2284>
    2a8c:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2a90:      	add	x8, x8, #0x0
    2a94:      	add	x11, sp, #0xc8
    2a98:      	ldp	x9, x10, [x8]
    2a9c:      	add	x0, sp, #0xc8
    2aa0:      	mov	w1, #0x1d               // =29
    2aa4:      	mov	x2, x24
    2aa8:      	str	x9, [sp, #0xc8]
    2aac:      	ldr	x9, [x8, #0x10]
    2ab0:      	ldur	x8, [x8, #0x15]
    2ab4:      	add	x20, sp, #0xc8
    2ab8:      	stp	x10, x9, [x11, #0x8]
    2abc:      	stur	x8, [x11, #0x15]
    2ac0:      	mov	w8, #0x1d               // =29
    2ac4:      	mov	w9, #0x6                // =6
    2ac8:      	add	x10, sp, #0xc8
    2acc:      	ldrb	w3, [sp, #0x88]
    2ad0:      	blr	x9
    2ad4:      	ldrb	w8, [sp, #0x88]
    2ad8:      	add	w9, w8, #0x1
    2adc:      	and	w9, w9, #0xff
    2ae0:      	cmp	w9, #0x1
    2ae4:      	b.hi	0x178 <kprobe_unwind_hotspot+0x178>
    2ae8:      	b	0x1fc <kprobe_unwind_hotspot+0x1fc>
    2aec:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2af0:      	add	x8, x8, #0x0
    2af4:      	add	x0, sp, #0xc8
    2af8:      	ldp	x9, x10, [x8]
    2afc:      	ldr	x8, [x8, #0x10]
    2b00:      	mov	w1, #0x18               // =24
    2b04:      	str	x9, [sp, #0xc8]
    2b08:      	add	x9, sp, #0xc8
    2b0c:      	stp	x10, x8, [x9, #0x8]
    2b10:      	mov	w8, #0x18               // =24
    2b14:      	mov	w9, #0x6                // =6
    2b18:      	add	x10, sp, #0xc8
    2b1c:      	blr	x9
    2b20:      	mov	x22, #0x1000000000000000 // =1152921504606846976
    2b24:      	ldrb	w8, [x21, #0xf21]
    2b28:      	cbnz	w8, 0x7bc <kprobe_unwind_hotspot+0x7bc>
    2b2c:      	b	0x2694 <kprobe_unwind_hotspot+0x2694>
    2b30:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2b34:      	add	x8, x8, #0x0
    2b38:      	add	x13, sp, #0xc8
    2b3c:      	ldp	x9, x10, [x8, #0x10]
    2b40:      	ldp	x11, x12, [x8, #0x20]
    2b44:      	add	x0, sp, #0xc8
    2b48:      	mov	w1, #0x30               // =48
    2b4c:      	str	x12, [x13, #0x28]
    2b50:      	stp	x10, x11, [x13, #0x18]
    2b54:      	ldp	x10, x8, [x8]
    2b58:      	str	x10, [sp, #0xc8]
    2b5c:      	stp	x8, x9, [x13, #0x8]
    2b60:      	mov	w8, #0x30               // =48
    2b64:      	mov	w9, #0x6                // =6
    2b68:      	add	x10, sp, #0xc8
    2b6c:      	blr	x9
    2b70:      	b	0x1fec <kprobe_unwind_hotspot+0x1fec>
    2b74:      	mov	w8, #0x6874             // =26740
    2b78:      	add	x11, sp, #0xc8
    2b7c:      	add	x0, sp, #0xc8
    2b80:      	mov	w1, #0x24               // =36
    2b84:      	movk	w8, #0xa, lsl #16
    2b88:      	str	w8, [sp, #0xe8]
    2b8c:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2b90:      	add	x8, x8, #0x0
    2b94:      	ldp	x9, x10, [x8]
    2b98:      	str	x9, [sp, #0xc8]
    2b9c:      	ldp	x9, x8, [x8, #0x10]
    2ba0:      	stp	x10, x9, [x11, #0x8]
    2ba4:      	str	x8, [x11, #0x18]
    2ba8:      	mov	w8, #0x24               // =36
    2bac:      	mov	w9, #0x6                // =6
    2bb0:      	add	x10, sp, #0xc8
    2bb4:      	blr	x9
    2bb8:      	ldr	w8, [sp, #0x78]
    2bbc:      	mov	x22, xzr
    2bc0:      	cbnz	w8, 0x2c84 <kprobe_unwind_hotspot+0x2c84>
    2bc4:      	b	0x2c78 <kprobe_unwind_hotspot+0x2c78>
    2bc8:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2bcc:      	add	x8, x8, #0x0
    2bd0:      	add	x11, sp, #0xc8
    2bd4:      	ldp	x9, x10, [x8]
    2bd8:      	add	x0, sp, #0xc8
    2bdc:      	mov	w1, #0x1d               // =29
    2be0:      	mov	x2, x25
    2be4:      	str	x9, [sp, #0xc8]
    2be8:      	ldr	x9, [x8, #0x10]
    2bec:      	ldur	x8, [x8, #0x15]
    2bf0:      	stp	x10, x9, [x11, #0x8]
    2bf4:      	mov	w9, #0x6                // =6
    2bf8:      	stur	x8, [x11, #0x15]
    2bfc:      	mov	w8, #0x1d               // =29
    2c00:      	add	x10, sp, #0xc8
    2c04:      	ldrb	w3, [sp, #0x88]
    2c08:      	blr	x9
    2c0c:      	ldrb	w9, [sp, #0x88]
    2c10:      	add	w8, w9, #0x1
    2c14:      	and	w8, w8, #0xff
    2c18:      	cmp	w8, #0x2
    2c1c:      	mov	w8, w9
    2c20:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    2c24:      	b	0x22d0 <kprobe_unwind_hotspot+0x22d0>
    2c28:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2c2c:      	add	x8, x8, #0x0
    2c30:      	add	x13, sp, #0xc8
    2c34:      	strb	wzr, [sp, #0xf8]
    2c38:      	ldp	x9, x10, [x8, #0x10]
    2c3c:      	add	x0, sp, #0xc8
    2c40:      	ldp	x11, x12, [x8, #0x20]
    2c44:      	mov	w1, #0x31               // =49
    2c48:      	mov	x2, x24
    2c4c:      	str	x12, [x13, #0x28]
    2c50:      	stp	x10, x11, [x13, #0x18]
    2c54:      	ldp	x10, x8, [x8]
    2c58:      	str	x10, [sp, #0xc8]
    2c5c:      	add	x10, sp, #0xc8
    2c60:      	stp	x8, x9, [x13, #0x8]
    2c64:      	mov	w8, #0x31               // =49
    2c68:      	mov	w9, #0x6                // =6
    2c6c:      	blr	x9
    2c70:      	mov	x22, xzr
    2c74:      	tbz	x24, #0x3e, 0x2680 <kprobe_unwind_hotspot+0x2680>
    2c78:      	ldr	x29, [sp, #0x38]
    2c7c:      	mov	w8, #0x10               // =16
    2c80:      	str	w8, [sp, #0x78]
    2c84:      	add	x9, x29, w8, uxtw
    2c88:      	mov	w8, #0x10               // =16
    2c8c:      	add	x10, sp, #0x88
    2c90:      	add	x0, sp, #0x88
    2c94:      	mov	w1, #0x10               // =16
    2c98:      	mov	x29, x9
    2c9c:      	sub	x2, x9, #0x10
    2ca0:      	mov	w9, #0x70               // =112
    2ca4:      	blr	x9
    2ca8:      	ldr	w8, [sp, #0x78]
    2cac:      	ldr	x24, [sp, #0x90]
    2cb0:      	cmp	w8, #0x10
    2cb4:      	b.lo	0x2cd0 <kprobe_unwind_hotspot+0x2cd0>
    2cb8:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2cbc:      	ldr	x8, [x8]
    2cc0:      	ldr	w8, [x8]
    2cc4:      	cbnz	w8, 0x2f24 <kprobe_unwind_hotspot+0x2f24>
    2cc8:      	ldr	x8, [sp, #0x88]
    2ccc:      	str	x8, [sp, #0x38]
    2cd0:      	ldr	w8, [x21, #0x2c0]
    2cd4:      	cmp	w8, #0x7e
    2cd8:      	b.hi	0x1508 <kprobe_unwind_hotspot+0x1508>
    2cdc:      	mov	w12, w19
    2ce0:      	and	x10, x22, #0x3000000000000000
    2ce4:      	ldr	x11, [sp, #0x30]
    2ce8:      	ldrb	w9, [x21, #0xf20]
    2cec:      	orr	x11, x12, x11, lsl #32
    2cf0:      	orr	x10, x11, x10
    2cf4:      	add	w11, w8, #0x1
    2cf8:      	str	w11, [x21, #0x2c0]
    2cfc:      	mov	w11, #0x18              // =24
    2d00:      	umaddl	x8, w8, w11, x21
    2d04:      	str	x10, [x8, #0x2d8]
    2d08:      	mov	w10, #0x5               // =5
    2d0c:      	str	x25, [x8, #0x2d0]
    2d10:      	strb	w9, [x8, #0x2e1]
    2d14:      	strh	wzr, [x8, #0x2e6]
    2d18:      	strb	w10, [x8, #0x2e0]
    2d1c:      	add	x10, x8, #0x2d0
    2d20:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2d24:      	stur	wzr, [x10, #0x12]
    2d28:      	ldr	x8, [x8]
    2d2c:      	ldr	w8, [x8]
    2d30:      	cbnz	w8, 0x2ed0 <kprobe_unwind_hotspot+0x2ed0>
    2d34:      	ldr	x8, [sp, #0x38]
    2d38:      	str	x24, [x21, #0xed0]
    2d3c:      	adrp	x0, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2d40:      	add	x9, sp, #0x88
    2d44:      	add	x1, sp, #0x88
    2d48:      	str	x29, [x21, #0xed8]
    2d4c:      	str	x8, [x21, #0xee0]
    2d50:      	mov	w8, #0x101              // =257
    2d54:      	strh	w8, [x21, #0xf20]
    2d58:      	mov	w8, #0x2a               // =42
    2d5c:      	str	w8, [sp, #0x88]
    2d60:      	mov	w8, #0x1                // =1
    2d64:      	ldr	x0, [x0]
    2d68:      	blr	x8
    2d6c:      	cbz	x0, 0x2d8c <kprobe_unwind_hotspot+0x2d8c>
    2d70:      	ldr	x8, [x0]
    2d74:      	add	x8, x8, #0x1
    2d78:      	str	x8, [x0]
    2d7c:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2d80:      	ldr	x8, [x8]
    2d84:      	ldr	w8, [x8]
    2d88:      	b	0x2d9c <kprobe_unwind_hotspot+0x2d9c>
    2d8c:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2d90:      	ldr	x8, [x8]
    2d94:      	ldr	w8, [x8]
    2d98:      	cbnz	w8, 0x2fb8 <kprobe_unwind_hotspot+0x2fb8>
    2d9c:      	ldr	x29, [x21, #0xed0]
    2da0:      	cbz	x29, 0x5eac <kprobe_unwind_hotspot+0x5eac>
    2da4:      	cbnz	w8, 0x2f60 <kprobe_unwind_hotspot+0x2f60>
    2da8:      	lsr	x8, x29, #56
    2dac:      	cbnz	x8, 0x1644 <kprobe_unwind_hotspot+0x1644>
    2db0:      	cmp	x29, #0x1, lsl #12      // =0x1000
    2db4:      	b.lo	0x1798 <kprobe_unwind_hotspot+0x1798>
    2db8:      	ldr	w8, [x21]
    2dbc:      	mov	w9, #0x60               // =96
    2dc0:      	add	x1, sp, #0x50
    2dc4:      	mov	x0, x20
    2dc8:      	rev	w8, w8
    2dcc:      	stp	w9, w8, [sp, #0x50]
    2dd0:      	rev	x8, x29
    2dd4:      	add	x9, sp, #0x50
    2dd8:      	str	x8, [sp, #0x58]
    2ddc:      	mov	w8, #0x1                // =1
    2de0:      	blr	x8
    2de4:      	cbz	x0, 0x5ee0 <kprobe_unwind_hotspot+0x5ee0>
    2de8:      	ldr	x8, [x0, #0x8]
    2dec:      	and	x9, x8, #0xffffffffffffff
    2df0:      	lsr	x25, x8, #56
    2df4:      	str	x9, [x21, #0xf10]
    2df8:      	ldr	x8, [x0]
    2dfc:      	str	x8, [x21, #0xf00]
    2e00:      	sub	x8, x29, x9
    2e04:      	str	x8, [x21, #0xf08]
    2e08:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2e0c:      	ldr	x8, [x8]
    2e10:      	ldr	w8, [x8]
    2e14:      	cbnz	w8, 0x30a8 <kprobe_unwind_hotspot+0x30a8>
    2e18:      	cmp	w25, #0x1
    2e1c:      	b.ne	0x32a4 <kprobe_unwind_hotspot+0x32a4>
    2e20:      	ldr	x8, [x21, #0xf00]
    2e24:      	adrp	x0, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2e28:      	ldr	x19, [x21, #0xf08]
    2e2c:      	mov	w9, #0x1                // =1
    2e30:      	add	x1, sp, #0x50
    2e34:      	mov	w22, #0x1               // =1
    2e38:      	str	x8, [sp, #0x50]
    2e3c:      	add	x8, sp, #0x50
    2e40:      	ldr	x0, [x0]
    2e44:      	blr	x9
    2e48:      	cbz	x0, 0x2ec0 <kprobe_unwind_hotspot+0x2ec0>
    2e4c:      	ldr	x8, [x0]
    2e50:      	mov	x25, x0
    2e54:      	cmp	x8, x19
    2e58:      	b.hi	0x2e68 <kprobe_unwind_hotspot+0x2e68>
    2e5c:      	ldr	x8, [x25, #0x8]
    2e60:      	cmp	x8, x19
    2e64:      	b.hs	0x2e80 <kprobe_unwind_hotspot+0x2e80>
    2e68:      	ldr	x8, [x25, #0x10]
    2e6c:      	cmp	x8, x19
    2e70:      	b.hi	0x2eb0 <kprobe_unwind_hotspot+0x2eb0>
    2e74:      	ldr	x8, [x25, #0x18]
    2e78:      	cmp	x8, x19
    2e7c:      	b.lo	0x2eb0 <kprobe_unwind_hotspot+0x2eb0>
    2e80:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2e84:      	ldr	x8, [x8]
    2e88:      	ldr	w8, [x8]
    2e8c:      	cbnz	w8, 0x3210 <kprobe_unwind_hotspot+0x3210>
    2e90:      	ldrh	w8, [x25, #0x20]
    2e94:      	ldr	w9, [x21, #0x1370]
    2e98:      	lsr	w8, w9, w8
    2e9c:      	tbz	w8, #0x0, 0x3260 <kprobe_unwind_hotspot+0x3260>
    2ea0:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2ea4:      	ldr	x8, [x8]
    2ea8:      	ldr	w8, [x8]
    2eac:      	cbnz	w8, 0x3d4c <kprobe_unwind_hotspot+0x3d4c>
    2eb0:      	mov	w25, #0x1               // =1
    2eb4:      	cmp	w25, #0x2
    2eb8:      	b.eq	0x32ac <kprobe_unwind_hotspot+0x32ac>
    2ebc:      	b	0x6074 <kprobe_unwind_hotspot+0x6074>
    2ec0:      	mov	w25, w22
    2ec4:      	cmp	w25, #0x2
    2ec8:      	b.eq	0x32ac <kprobe_unwind_hotspot+0x32ac>
    2ecc:      	b	0x6074 <kprobe_unwind_hotspot+0x6074>
    2ed0:      	mov	w8, #0x786c             // =30828
    2ed4:      	add	x11, sp, #0xc8
    2ed8:      	add	x0, sp, #0xc8
    2edc:      	mov	w1, #0x24               // =36
    2ee0:      	mov	x2, x24
    2ee4:      	mov	x3, x29
    2ee8:      	movk	w8, #0xa, lsl #16
    2eec:      	str	w8, [sp, #0xe8]
    2ef0:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2ef4:      	add	x8, x8, #0x0
    2ef8:      	ldp	x9, x10, [x8]
    2efc:      	str	x9, [sp, #0xc8]
    2f00:      	ldp	x9, x8, [x8, #0x10]
    2f04:      	stp	x10, x9, [x11, #0x8]
    2f08:      	str	x8, [x11, #0x18]
    2f0c:      	mov	w8, #0x24               // =36
    2f10:      	mov	w9, #0x6                // =6
    2f14:      	add	x10, sp, #0xc8
    2f18:      	ldr	x4, [sp, #0x38]
    2f1c:      	blr	x9
    2f20:      	b	0x2d34 <kprobe_unwind_hotspot+0x2d34>
    2f24:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2f28:      	add	x8, x8, #0x0
    2f2c:      	add	x0, sp, #0xc8
    2f30:      	ldp	x9, x10, [x8]
    2f34:      	ldur	x8, [x8, #0xd]
    2f38:      	mov	w1, #0x15               // =21
    2f3c:      	str	x9, [sp, #0xc8]
    2f40:      	add	x9, sp, #0xc8
    2f44:      	str	x10, [x9, #0x8]
    2f48:      	stur	x8, [x9, #0xd]
    2f4c:      	mov	w8, #0x15               // =21
    2f50:      	mov	w9, #0x6                // =6
    2f54:      	add	x10, sp, #0xc8
    2f58:      	blr	x9
    2f5c:      	b	0x2cc8 <kprobe_unwind_hotspot+0x2cc8>
    2f60:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2f64:      	add	x8, x8, #0x0
    2f68:      	add	x13, sp, #0xc8
    2f6c:      	strb	wzr, [sp, #0xf8]
    2f70:      	ldp	x9, x10, [x8, #0x10]
    2f74:      	add	x0, sp, #0xc8
    2f78:      	ldp	x11, x12, [x8, #0x20]
    2f7c:      	mov	w1, #0x31               // =49
    2f80:      	str	x12, [x13, #0x28]
    2f84:      	stp	x10, x11, [x13, #0x18]
    2f88:      	ldp	x10, x8, [x8]
    2f8c:      	str	x10, [sp, #0xc8]
    2f90:      	stp	x8, x9, [x13, #0x8]
    2f94:      	mov	w8, #0x31               // =49
    2f98:      	mov	w9, #0x6                // =6
    2f9c:      	add	x10, sp, #0xc8
    2fa0:      	ldr	w2, [x21, #0x2c0]
    2fa4:      	blr	x9
    2fa8:      	ldr	x29, [x21, #0xed0]
    2fac:      	lsr	x8, x29, #56
    2fb0:      	cbnz	x8, 0x1644 <kprobe_unwind_hotspot+0x1644>
    2fb4:      	b	0x2db0 <kprobe_unwind_hotspot+0x2db0>
    2fb8:      	adrp	x8, 0x2000 <kprobe_unwind_hotspot+0x2000>
    2fbc:      	add	x8, x8, #0x0
    2fc0:      	add	x12, sp, #0xc8
    2fc4:      	ldp	x9, x10, [x8, #0x10]
    2fc8:      	ldr	x11, [x8, #0x20]
    2fcc:      	add	x0, sp, #0xc8
    2fd0:      	mov	w1, #0x2e               // =46
    2fd4:      	stp	x10, x11, [x12, #0x18]
    2fd8:      	ldur	x10, [x8, #0x26]
    2fdc:      	stur	x10, [x12, #0x26]
    2fe0:      	ldp	x10, x8, [x8]
    2fe4:      	str	x10, [sp, #0xc8]
    2fe8:      	stp	x8, x9, [x12, #0x8]
    2fec:      	mov	w8, #0x2e               // =46
    2ff0:      	mov	w9, #0x6                // =6
    2ff4:      	add	x10, sp, #0xc8
    2ff8:      	ldr	w2, [sp, #0x88]
    2ffc:      	blr	x9
    3000:      	b	0x2d7c <kprobe_unwind_hotspot+0x2d7c>
    3004:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3008:      	add	x8, x8, #0x0
    300c:      	add	x11, sp, #0xc8
    3010:      	ldp	x9, x10, [x8, #0x18]
    3014:      	add	x0, sp, #0xc8
    3018:      	mov	w1, #0x2f               // =47
    301c:      	stp	x9, x10, [x11, #0x18]
    3020:      	ldur	x10, [x8, #0x27]
    3024:      	stur	x10, [x11, #0x27]
    3028:      	ldr	x10, [x8]
    302c:      	ldp	x8, x9, [x8, #0x8]
    3030:      	str	x10, [sp, #0xc8]
    3034:      	stp	x8, x9, [x11, #0x8]
    3038:      	mov	w8, #0x2f               // =47
    303c:      	mov	w9, #0x6                // =6
    3040:      	add	x10, sp, #0xc8
    3044:      	blr	x9
    3048:      	b	0x20a8 <kprobe_unwind_hotspot+0x20a8>
    304c:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3050:      	add	x8, x8, #0x0
    3054:      	add	x13, sp, #0xc8
    3058:      	ldp	x9, x10, [x8, #0x20]
    305c:      	ldp	x11, x12, [x8, #0x30]
    3060:      	add	x0, sp, #0xc8
    3064:      	mov	w1, #0x40               // =64
    3068:      	str	x12, [x13, #0x38]
    306c:      	stp	x10, x11, [x13, #0x28]
    3070:      	ldp	x10, x11, [x8]
    3074:      	str	x10, [sp, #0xc8]
    3078:      	ldp	x10, x8, [x8, #0x10]
    307c:      	stp	x11, x10, [x13, #0x8]
    3080:      	add	x10, sp, #0xc8
    3084:      	stp	x8, x9, [x13, #0x18]
    3088:      	mov	w8, #0x40               // =64
    308c:      	mov	w9, #0x6                // =6
    3090:      	ldr	x2, [sp, #0x88]
    3094:      	ldr	w3, [sp, #0x74]
    3098:      	blr	x9
    309c:      	ldr	x22, [sp, #0x88]
    30a0:      	ldr	x8, [sp, #0x58]
    30a4:      	b	0x2668 <kprobe_unwind_hotspot+0x2668>
    30a8:      	mov	w8, #0xa                // =10
    30ac:      	add	x13, sp, #0xc8
    30b0:      	add	x0, sp, #0xc8
    30b4:      	strh	w8, [sp, #0xf8]
    30b8:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    30bc:      	add	x8, x8, #0x0
    30c0:      	mov	w1, #0x32               // =50
    30c4:      	ldp	x9, x10, [x8, #0x10]
    30c8:      	ldp	x11, x12, [x8, #0x20]
    30cc:      	mov	x2, x29
    30d0:      	mov	w4, w25
    30d4:      	str	x12, [x13, #0x28]
    30d8:      	stp	x10, x11, [x13, #0x18]
    30dc:      	ldp	x10, x8, [x8]
    30e0:      	str	x10, [sp, #0xc8]
    30e4:      	add	x10, sp, #0xc8
    30e8:      	stp	x8, x9, [x13, #0x8]
    30ec:      	mov	w8, #0x32               // =50
    30f0:      	mov	w9, #0x6                // =6
    30f4:      	ldr	x3, [x21, #0xf00]
    30f8:      	blr	x9
    30fc:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3100:      	ldr	x8, [x8]
    3104:      	ldr	w8, [x8]
    3108:      	cbz	w8, 0x2e18 <kprobe_unwind_hotspot+0x2e18>
    310c:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3110:      	add	x8, x8, #0x0
    3114:      	add	x12, sp, #0xc8
    3118:      	ldp	x9, x10, [x8, #0x10]
    311c:      	ldr	x11, [x8, #0x20]
    3120:      	add	x0, sp, #0xc8
    3124:      	mov	w1, #0x2f               // =47
    3128:      	stp	x10, x11, [x12, #0x18]
    312c:      	ldur	x10, [x8, #0x27]
    3130:      	stur	x10, [x12, #0x27]
    3134:      	ldp	x10, x8, [x8]
    3138:      	str	x10, [sp, #0xc8]
    313c:      	stp	x8, x9, [x12, #0x8]
    3140:      	mov	w8, #0x2f               // =47
    3144:      	mov	w9, #0x6                // =6
    3148:      	add	x10, sp, #0xc8
    314c:      	ldr	x2, [x21, #0xf10]
    3150:      	ldr	x3, [x21, #0xf08]
    3154:      	blr	x9
    3158:      	b	0x2e18 <kprobe_unwind_hotspot+0x2e18>
    315c:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3160:      	add	x8, x8, #0x0
    3164:      	add	x11, sp, #0xc8
    3168:      	ldp	x9, x10, [x8]
    316c:      	add	x0, sp, #0xc8
    3170:      	mov	w1, #0x1d               // =29
    3174:      	mov	x2, x25
    3178:      	str	x9, [sp, #0xc8]
    317c:      	ldr	x9, [x8, #0x10]
    3180:      	ldur	x8, [x8, #0x15]
    3184:      	stp	x10, x9, [x11, #0x8]
    3188:      	mov	w9, #0x6                // =6
    318c:      	stur	x8, [x11, #0x15]
    3190:      	mov	w8, #0x1d               // =29
    3194:      	add	x10, sp, #0xc8
    3198:      	ldrb	w3, [sp, #0x88]
    319c:      	blr	x9
    31a0:      	ldrb	w9, [sp, #0x88]
    31a4:      	add	w8, w9, #0x1
    31a8:      	and	w8, w8, #0xff
    31ac:      	cmp	w8, #0x2
    31b0:      	mov	w8, w9
    31b4:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    31b8:      	b	0x231c <kprobe_unwind_hotspot+0x231c>
    31bc:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    31c0:      	add	x8, x8, #0x0
    31c4:      	add	x0, sp, #0x88
    31c8:      	ldp	x9, x10, [x8, #0x20]
    31cc:      	mov	w1, #0x35               // =53
    31d0:      	mov	x2, x25
    31d4:      	mov	x4, x19
    31d8:      	stp	x9, x10, [sp, #0xa8]
    31dc:      	ldur	x9, [x8, #0x2d]
    31e0:      	stur	x9, [sp, #0xb5]
    31e4:      	ldp	x9, x10, [x8]
    31e8:      	stp	x9, x10, [sp, #0x88]
    31ec:      	ldp	x8, x9, [x8, #0x10]
    31f0:      	add	x10, sp, #0x88
    31f4:      	stp	x8, x9, [sp, #0x98]
    31f8:      	mov	w8, #0x35               // =53
    31fc:      	mov	w9, #0x6                // =6
    3200:      	ldr	x3, [sp, #0xc0]
    3204:      	blr	x9
    3208:      	ldr	x8, [sp, #0xc0]
    320c:      	b	0x1c1c <kprobe_unwind_hotspot+0x1c1c>
    3210:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3214:      	add	x8, x8, #0x0
    3218:      	add	x11, sp, #0xc8
    321c:      	ldp	x9, x10, [x8]
    3220:      	add	x0, sp, #0xc8
    3224:      	mov	w1, #0x1e               // =30
    3228:      	str	x9, [sp, #0xc8]
    322c:      	ldr	x9, [x8, #0x10]
    3230:      	ldur	x8, [x8, #0x16]
    3234:      	stp	x10, x9, [x11, #0x8]
    3238:      	mov	w9, #0x6                // =6
    323c:      	stur	x8, [x11, #0x16]
    3240:      	mov	w8, #0x1e               // =30
    3244:      	add	x10, sp, #0xc8
    3248:      	ldrh	w2, [x25, #0x20]
    324c:      	blr	x9
    3250:      	ldrh	w8, [x25, #0x20]
    3254:      	ldr	w9, [x21, #0x1370]
    3258:      	lsr	w8, w9, w8
    325c:      	tbnz	w8, #0x0, 0x2ea0 <kprobe_unwind_hotspot+0x2ea0>
    3260:      	str	wzr, [sp, #0x88]
    3264:      	adrp	x0, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3268:      	mov	w8, #0x1                // =1
    326c:      	add	x9, sp, #0x88
    3270:      	ldr	x0, [x0]
    3274:      	add	x1, sp, #0x88
    3278:      	blr	x8
    327c:      	cbz	x0, 0x3290 <kprobe_unwind_hotspot+0x3290>
    3280:      	ldr	x8, [x0]
    3284:      	add	x8, x8, #0x1
    3288:      	str	x8, [x0]
    328c:      	b	0x32a0 <kprobe_unwind_hotspot+0x32a0>
    3290:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3294:      	ldr	x8, [x8]
    3298:      	ldr	w8, [x8]
    329c:      	cbnz	w8, 0x3f0c <kprobe_unwind_hotspot+0x3f0c>
    32a0:      	ldrh	w25, [x25, #0x20]
    32a4:      	cmp	w25, #0x2
    32a8:      	b.ne	0x6074 <kprobe_unwind_hotspot+0x6074>
    32ac:      	mov	w8, #0x29               // =41
    32b0:      	adrp	x0, 0x3000 <kprobe_unwind_hotspot+0x3000>
    32b4:      	add	x9, sp, #0x50
    32b8:      	str	w8, [sp, #0x50]
    32bc:      	mov	w8, #0x1                // =1
    32c0:      	add	x1, sp, #0x50
    32c4:      	ldr	x0, [x0]
    32c8:      	blr	x8
    32cc:      	cbz	x0, 0x3354 <kprobe_unwind_hotspot+0x3354>
    32d0:      	ldr	x8, [x0]
    32d4:      	add	x8, x8, #0x1
    32d8:      	str	x8, [x0]
    32dc:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    32e0:      	ldr	x8, [x8]
    32e4:      	ldr	x22, [x21, #0xed0]
    32e8:      	ldr	x29, [x21, #0xed8]
    32ec:      	ldr	x9, [x21, #0xee0]
    32f0:      	ldr	w8, [x8]
    32f4:      	str	x9, [sp, #0x38]
    32f8:      	cbz	w8, 0x3374 <kprobe_unwind_hotspot+0x3374>
    32fc:      	mov	w8, #0x786c             // =30828
    3300:      	add	x13, sp, #0xc8
    3304:      	add	x0, sp, #0xc8
    3308:      	mov	w1, #0x2c               // =44
    330c:      	movk	w8, #0xa, lsl #16
    3310:      	str	w8, [sp, #0xf0]
    3314:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3318:      	add	x8, x8, #0x0
    331c:      	ldp	x9, x10, [x8, #0x10]
    3320:      	ldp	x12, x11, [x8]
    3324:      	ldr	x8, [x8, #0x20]
    3328:      	str	x12, [sp, #0xc8]
    332c:      	stp	x11, x9, [x13, #0x8]
    3330:      	stp	x10, x8, [x13, #0x18]
    3334:      	mov	w8, #0x2c               // =44
    3338:      	mov	w9, #0x6                // =6
    333c:      	add	x10, sp, #0xc8
    3340:      	ldr	x2, [x21, #0xed0]
    3344:      	ldr	x3, [x21, #0xf10]
    3348:      	ldr	x4, [x21, #0xf08]
    334c:      	blr	x9
    3350:      	b	0x3374 <kprobe_unwind_hotspot+0x3374>
    3354:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3358:      	ldr	x8, [x8]
    335c:      	ldr	w8, [x8]
    3360:      	cbnz	w8, 0x3754 <kprobe_unwind_hotspot+0x3754>
    3364:      	ldr	x8, [x21, #0xee0]
    3368:      	ldr	x22, [x21, #0xed0]
    336c:      	ldr	x29, [x21, #0xed8]
    3370:      	str	x8, [sp, #0x38]
    3374:      	ldr	x8, [x21, #0xf08]
    3378:      	ldrb	w9, [x23, #0x20]
    337c:      	add	x10, sp, #0x88
    3380:      	add	x0, sp, #0x88
    3384:      	mov	w1, #0x1                // =1
    3388:      	lsr	x25, x8, x9
    338c:      	ldr	x8, [x21, #0xf00]
    3390:      	mov	w9, #0x70               // =112
    3394:      	and	x19, x8, #0xffffffffffffff
    3398:      	mov	w8, #0x1                // =1
    339c:      	add	x2, x25, x19
    33a0:      	blr	x9
    33a4:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    33a8:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    33ac:      	ldr	x8, [x8]
    33b0:      	ldr	w8, [x8]
    33b4:      	cbnz	w8, 0x37a0 <kprobe_unwind_hotspot+0x37a0>
    33b8:      	ldrb	w8, [sp, #0x88]
    33bc:      	add	w9, w8, #0x1
    33c0:      	and	w9, w9, #0xff
    33c4:      	cmp	w9, #0x2
    33c8:      	b.hs	0x37f8 <kprobe_unwind_hotspot+0x37f8>
    33cc:      	cbnz	w8, 0x178 <kprobe_unwind_hotspot+0x178>
    33d0:      	ldr	x8, [x21, #0xf10]
    33d4:      	ldrb	w9, [x23, #0x20]
    33d8:      	lsl	x9, x25, x9
    33dc:      	ldrb	w10, [x23, #0x1b]
    33e0:      	add	x8, x8, x10
    33e4:      	add	x24, x9, x8
    33e8:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    33ec:      	ldr	x8, [x8]
    33f0:      	ldr	w8, [x8]
    33f4:      	cbnz	w8, 0x3e00 <kprobe_unwind_hotspot+0x3e00>
    33f8:      	str	x24, [sp, #0x50]
    33fc:      	cbz	x24, 0x17c <kprobe_unwind_hotspot+0x17c>
    3400:      	mov	w8, #0x200              // =512
    3404:      	mov	w9, #0x70               // =112
    3408:      	ldr	x0, [sp, #0x8]
    340c:      	mov	w1, #0x200              // =512
    3410:      	ldr	x2, [sp, #0x50]
    3414:      	blr	x9
    3418:      	adrp	x24, 0x3000 <kprobe_unwind_hotspot+0x3000>
    341c:      	ldr	x24, [x24]
    3420:      	cbnz	x0, 0x258 <kprobe_unwind_hotspot+0x258>
    3424:      	ldrh	w8, [x23, #0x10]
    3428:      	cmp	x8, #0x1f8
    342c:      	b.hi	0x3c4 <kprobe_unwind_hotspot+0x3c4>
    3430:      	ldrh	w9, [x23, #0x12]
    3434:      	cmp	x9, #0x1fc
    3438:      	b.hi	0x3c4 <kprobe_unwind_hotspot+0x3c4>
    343c:      	ldrh	w10, [x23, #0x14]
    3440:      	cmp	x10, #0x1f8
    3444:      	b.hi	0x3c4 <kprobe_unwind_hotspot+0x3c4>
    3448:      	ldrb	w11, [x23, #0x17]
    344c:      	ldr	x12, [sp, #0x8]
    3450:      	mov	w1, #0x4                // =4
    3454:      	ldr	x0, [sp, #0x40]
    3458:      	ldr	x11, [x12, x11]
    345c:      	str	x11, [sp, #0x58]
    3460:      	ldrb	w11, [x23, #0x18]
    3464:      	ldr	x11, [x12, x11]
    3468:      	str	x11, [sp, #0x60]
    346c:      	ldrb	w11, [x23, #0x1a]
    3470:      	ldr	w11, [x12, x11]
    3474:      	lsl	w11, w11, #3
    3478:      	str	w11, [sp, #0x78]
    347c:      	ldrb	w11, [x23, #0x19]
    3480:      	ldrh	w11, [x12, x11]
    3484:      	strh	w11, [sp, #0x80]
    3488:      	ldr	w9, [x12, x9]
    348c:      	str	w9, [sp, #0x7c]
    3490:      	ldr	w9, [x12, x10]
    3494:      	str	w9, [sp, #0x74]
    3498:      	mov	w9, #0x70               // =112
    349c:      	ldr	x8, [x12, x8]
    34a0:      	str	x8, [sp, #0x68]
    34a4:      	ldrb	w8, [x23, #0x16]
    34a8:      	ldr	x2, [x12, x8]
    34ac:      	mov	w8, #0x4                // =4
    34b0:      	blr	x9
    34b4:      	adrp	x24, 0x3000 <kprobe_unwind_hotspot+0x3000>
    34b8:      	ldr	x24, [x24]
    34bc:      	cbnz	x0, 0x258 <kprobe_unwind_hotspot+0x258>
    34c0:      	ldrb	w8, [x23, #0x21]
    34c4:      	cbz	w8, 0x34e0 <kprobe_unwind_hotspot+0x34e0>
    34c8:      	ldr	x8, [sp, #0x50]
    34cc:      	ldr	w9, [sp, #0x58]
    34d0:      	add	x9, x9, x8
    34d4:      	ldr	w10, [sp, #0x60]
    34d8:      	add	x8, x10, x8
    34dc:      	stp	x9, x8, [sp, #0x58]
    34e0:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    34e4:      	ldr	x8, [x8]
    34e8:      	ldr	w8, [x8]
    34ec:      	cbnz	w8, 0x40d4 <kprobe_unwind_hotspot+0x40d4>
    34f0:      	ldp	x25, x8, [sp, #0x50]
    34f4:      	sub	w9, w22, w8
    34f8:      	ldr	w19, [sp, #0x70]
    34fc:      	str	x9, [sp, #0x30]
    3500:      	mov	w9, #0x616d             // =24941
    3504:      	movk	w9, #0x6974, lsl #16
    3508:      	cmp	w19, w9
    350c:      	b.gt	0x3614 <kprobe_unwind_hotspot+0x3614>
    3510:      	mov	w8, #0x7476             // =29814
    3514:      	movk	w8, #0x6261, lsl #16
    3518:      	cmp	w19, w8
    351c:      	b.eq	0x36c8 <kprobe_unwind_hotspot+0x36c8>
    3520:      	mov	w8, #0x6e49             // =28233
    3524:      	movk	w8, #0x6574, lsl #16
    3528:      	cmp	w19, w8
    352c:      	b.ne	0x36f0 <kprobe_unwind_hotspot+0x36f0>
    3530:      	ldr	x8, [sp, #0x38]
    3534:      	cmp	x8, x29
    3538:      	b.lo	0x52c0 <kprobe_unwind_hotspot+0x52c0>
    353c:      	ldr	x9, [sp, #0x38]
    3540:      	add	x8, x29, #0x1, lsl #12  // =0x1000
    3544:      	cmp	x9, x8
    3548:      	b.hs	0x52c0 <kprobe_unwind_hotspot+0x52c0>
    354c:      	ldr	x8, [sp, #0x38]
    3550:      	mov	w9, #0x70               // =112
    3554:      	add	x10, sp, #0xc8
    3558:      	add	x0, sp, #0xc8
    355c:      	mov	w1, #0x60               // =96
    3560:      	sub	x2, x8, #0x50
    3564:      	mov	w8, #0x60               // =96
    3568:      	blr	x9
    356c:      	cbnz	x0, 0x51c <kprobe_unwind_hotspot+0x51c>
    3570:      	ldr	w9, [x21, #0x2c0]
    3574:      	ldr	x8, [sp, #0x20]
    3578:      	cbz	w9, 0x358c <kprobe_unwind_hotspot+0x358c>
    357c:      	ldrb	w8, [x23, #0x1f]
    3580:      	cmp	w8, #0x0
    3584:      	ldp	x9, x8, [sp, #0x10]
    3588:      	csel	x8, x9, x8, eq
    358c:      	ldr	x19, [x8]
    3590:      	add	x8, sp, #0xc8
    3594:      	mov	w10, #0x70              // =112
    3598:      	add	x11, sp, #0xc0
    359c:      	ldp	x29, x9, [x8, #0x48]
    35a0:      	ldr	x25, [x8, #0x38]
    35a4:      	add	x0, sp, #0xc0
    35a8:      	mov	w1, #0x8                // =8
    35ac:      	ldr	x24, [x8, #0x58]
    35b0:      	ldrb	w8, [x23, #0x1c]
    35b4:      	add	x8, x25, x8
    35b8:      	str	x9, [sp, #0x38]
    35bc:      	mov	w9, #0x8                // =8
    35c0:      	ldrb	w8, [x23, #0x1c]
    35c4:      	add	x2, x25, x8
    35c8:      	blr	x10
    35cc:      	cbnz	x0, 0xf20 <kprobe_unwind_hotspot+0xf20>
    35d0:      	ldr	x8, [sp, #0xc0]
    35d4:      	ldrb	w9, [x23, #0x1d]
    35d8:      	add	x9, x8, x9
    35dc:      	cmp	x19, x9
    35e0:      	csel	x9, xzr, x9, lo
    35e4:      	sub	x19, x19, x9
    35e8:      	adrp	x9, 0x3000 <kprobe_unwind_hotspot+0x3000>
    35ec:      	ldr	x9, [x9]
    35f0:      	ldr	w9, [x9]
    35f4:      	cbnz	w9, 0x4180 <kprobe_unwind_hotspot+0x4180>
    35f8:      	mov	w9, #0xffff             // =65535
    35fc:      	mov	x22, #0x2000000000000000 // =2305843009213693952
    3600:      	cmp	x19, x9
    3604:      	csel	x9, x19, x9, lo
    3608:      	lsr	x19, x8, #3
    360c:      	str	x9, [sp, #0x30]
    3610:      	b	0x4580 <kprobe_unwind_hotspot+0x4580>
    3614:      	mov	w9, #0x616e             // =24942
    3618:      	movk	w9, #0x6974, lsl #16
    361c:      	cmp	w19, w9
    3620:      	b.eq	0x3634 <kprobe_unwind_hotspot+0x3634>
    3624:      	mov	w9, #0x6d6e             // =28014
    3628:      	movk	w9, #0x7465, lsl #16
    362c:      	cmp	w19, w9
    3630:      	b.ne	0x36f0 <kprobe_unwind_hotspot+0x36f0>
    3634:      	ldr	x9, [sp, #0x68]
    3638:      	ldrb	w10, [x23, #0x21]
    363c:      	add	x11, x25, w9, uxtw
    3640:      	ldr	w19, [sp, #0x7c]
    3644:      	cmp	w10, #0x0
    3648:      	csel	x9, x9, x11, eq
    364c:      	cmp	x22, x9
    3650:      	b.ne	0x3694 <kprobe_unwind_hotspot+0x3694>
    3654:      	ldr	w8, [sp, #0x74]
    3658:      	mov	w9, #0x8                // =8
    365c:      	mov	w10, #0x70              // =112
    3660:      	add	x11, sp, #0x88
    3664:      	add	x0, sp, #0x88
    3668:      	mov	w1, #0x8                // =8
    366c:      	add	x8, x29, x8
    3670:      	ldr	w8, [sp, #0x74]
    3674:      	add	x2, x29, x8
    3678:      	blr	x10
    367c:      	cbz	x0, 0x3d9c <kprobe_unwind_hotspot+0x3d9c>
    3680:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3684:      	ldr	x8, [x8]
    3688:      	ldr	w8, [x8]
    368c:      	cbnz	w8, 0x41d4 <kprobe_unwind_hotspot+0x41d4>
    3690:      	ldr	x8, [sp, #0x58]
    3694:      	ldrh	w9, [sp, #0x80]
    3698:      	add	x8, x8, x9
    369c:      	cmp	x22, x8
    36a0:      	b.hs	0x3718 <kprobe_unwind_hotspot+0x3718>
    36a4:      	sub	x8, x8, #0x4
    36a8:      	cmp	x22, x8
    36ac:      	b.ne	0x3d3c <kprobe_unwind_hotspot+0x3d3c>
    36b0:      	ldr	w8, [sp, #0x78]
    36b4:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    36b8:      	add	x29, x29, x8
    36bc:      	ldrb	w8, [x21, #0xf21]
    36c0:      	cbnz	w8, 0x7bc <kprobe_unwind_hotspot+0x7bc>
    36c4:      	b	0x3df8 <kprobe_unwind_hotspot+0x3df8>
    36c8:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    36cc:      	mov	w19, #0x7476            // =29814
    36d0:      	ldr	x8, [x8]
    36d4:      	movk	w19, #0x6261, lsl #16
    36d8:      	ldr	w8, [x8]
    36dc:      	cbnz	w8, 0x4218 <kprobe_unwind_hotspot+0x4218>
    36e0:      	mov	x22, #0x1000000000000000 // =1152921504606846976
    36e4:      	ldrb	w8, [x21, #0xf21]
    36e8:      	cbnz	w8, 0x7bc <kprobe_unwind_hotspot+0x7bc>
    36ec:      	b	0x3df8 <kprobe_unwind_hotspot+0x3df8>
    36f0:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    36f4:      	ldr	x24, [x21, #0xf00]
    36f8:      	ldr	x8, [x8]
    36fc:      	ldr	w8, [x8]
    3700:      	tbnz	x24, #0x3f, 0x3dd8 <kprobe_unwind_hotspot+0x3dd8>
    3704:      	cbnz	w8, 0x425c <kprobe_unwind_hotspot+0x425c>
    3708:      	ldr	w8, [sp, #0x78]
    370c:      	mov	x22, xzr
    3710:      	cbnz	w8, 0x4534 <kprobe_unwind_hotspot+0x4534>
    3714:      	b	0x4528 <kprobe_unwind_hotspot+0x4528>
    3718:      	ldr	x8, [sp, #0x38]
    371c:      	subs	x2, x8, x29
    3720:      	b.lo	0x3c90 <kprobe_unwind_hotspot+0x3c90>
    3724:      	ldr	w8, [sp, #0x78]
    3728:      	ldr	x9, [sp, #0x38]
    372c:      	add	x8, x29, x8
    3730:      	add	x8, x8, #0x30
    3734:      	cmp	x9, x8
    3738:      	b.hs	0x3c90 <kprobe_unwind_hotspot+0x3c90>
    373c:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3740:      	ldr	x8, [x8]
    3744:      	ldr	w8, [x8]
    3748:      	cbnz	w8, 0x42b0 <kprobe_unwind_hotspot+0x42b0>
    374c:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    3750:      	b	0x4528 <kprobe_unwind_hotspot+0x4528>
    3754:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3758:      	add	x8, x8, #0x0
    375c:      	add	x12, sp, #0xc8
    3760:      	ldp	x9, x10, [x8, #0x10]
    3764:      	ldr	x11, [x8, #0x20]
    3768:      	add	x0, sp, #0xc8
    376c:      	mov	w1, #0x2e               // =46
    3770:      	stp	x10, x11, [x12, #0x18]
    3774:      	ldur	x10, [x8, #0x26]
    3778:      	stur	x10, [x12, #0x26]
    377c:      	ldp	x10, x8, [x8]
    3780:      	str	x10, [sp, #0xc8]
    3784:      	stp	x8, x9, [x12, #0x8]
    3788:      	mov	w8, #0x2e               // =46
    378c:      	mov	w9, #0x6                // =6
    3790:      	add	x10, sp, #0xc8
    3794:      	ldr	w2, [sp, #0x50]
    3798:      	blr	x9
    379c:      	b	0x32dc <kprobe_unwind_hotspot+0x32dc>
    37a0:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    37a4:      	add	x8, x8, #0x0
    37a8:      	add	x11, sp, #0xc8
    37ac:      	ldp	x9, x10, [x8]
    37b0:      	add	x0, sp, #0xc8
    37b4:      	mov	w1, #0x1d               // =29
    37b8:      	mov	x2, x25
    37bc:      	str	x9, [sp, #0xc8]
    37c0:      	ldr	x9, [x8, #0x10]
    37c4:      	ldur	x8, [x8, #0x15]
    37c8:      	stp	x10, x9, [x11, #0x8]
    37cc:      	mov	w9, #0x6                // =6
    37d0:      	stur	x8, [x11, #0x15]
    37d4:      	mov	w8, #0x1d               // =29
    37d8:      	add	x10, sp, #0xc8
    37dc:      	ldrb	w3, [sp, #0x88]
    37e0:      	blr	x9
    37e4:      	ldrb	w8, [sp, #0x88]
    37e8:      	add	w9, w8, #0x1
    37ec:      	and	w9, w9, #0xff
    37f0:      	cmp	w9, #0x2
    37f4:      	b.lo	0x33cc <kprobe_unwind_hotspot+0x33cc>
    37f8:      	sub	x25, x25, x8
    37fc:      	mov	w8, #0x1                // =1
    3800:      	mov	w9, #0x70               // =112
    3804:      	add	x10, sp, #0x88
    3808:      	add	x0, sp, #0x88
    380c:      	mov	w1, #0x1                // =1
    3810:      	add	x2, x25, x19
    3814:      	blr	x9
    3818:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    381c:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3820:      	ldr	x8, [x8]
    3824:      	ldr	w8, [x8]
    3828:      	cbnz	w8, 0x3e4c <kprobe_unwind_hotspot+0x3e4c>
    382c:      	ldrb	w9, [sp, #0x88]
    3830:      	add	w8, w9, #0x1
    3834:      	and	w8, w8, #0xff
    3838:      	cmp	w8, #0x2
    383c:      	mov	w8, w9
    3840:      	b.lo	0x33cc <kprobe_unwind_hotspot+0x33cc>
    3844:      	sub	x25, x25, x9
    3848:      	mov	w8, #0x1                // =1
    384c:      	mov	w9, #0x70               // =112
    3850:      	add	x10, sp, #0x88
    3854:      	add	x0, sp, #0x88
    3858:      	mov	w1, #0x1                // =1
    385c:      	add	x2, x25, x19
    3860:      	blr	x9
    3864:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    3868:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    386c:      	ldr	x8, [x8]
    3870:      	ldr	w8, [x8]
    3874:      	cbnz	w8, 0x3f58 <kprobe_unwind_hotspot+0x3f58>
    3878:      	ldrb	w9, [sp, #0x88]
    387c:      	add	w8, w9, #0x1
    3880:      	and	w8, w8, #0xff
    3884:      	cmp	w8, #0x2
    3888:      	mov	w8, w9
    388c:      	b.lo	0x33cc <kprobe_unwind_hotspot+0x33cc>
    3890:      	sub	x25, x25, x9
    3894:      	mov	w8, #0x1                // =1
    3898:      	mov	w9, #0x70               // =112
    389c:      	add	x10, sp, #0x88
    38a0:      	add	x0, sp, #0x88
    38a4:      	mov	w1, #0x1                // =1
    38a8:      	add	x2, x25, x19
    38ac:      	blr	x9
    38b0:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    38b4:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    38b8:      	ldr	x8, [x8]
    38bc:      	ldr	w8, [x8]
    38c0:      	cbnz	w8, 0x42fc <kprobe_unwind_hotspot+0x42fc>
    38c4:      	ldrb	w9, [sp, #0x88]
    38c8:      	add	w8, w9, #0x1
    38cc:      	and	w8, w8, #0xff
    38d0:      	cmp	w8, #0x2
    38d4:      	mov	w8, w9
    38d8:      	b.lo	0x33cc <kprobe_unwind_hotspot+0x33cc>
    38dc:      	sub	x25, x25, x9
    38e0:      	mov	w8, #0x1                // =1
    38e4:      	mov	w9, #0x70               // =112
    38e8:      	add	x10, sp, #0x88
    38ec:      	add	x0, sp, #0x88
    38f0:      	mov	w1, #0x1                // =1
    38f4:      	add	x2, x25, x19
    38f8:      	blr	x9
    38fc:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    3900:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3904:      	ldr	x8, [x8]
    3908:      	ldr	w8, [x8]
    390c:      	cbnz	w8, 0x435c <kprobe_unwind_hotspot+0x435c>
    3910:      	ldrb	w9, [sp, #0x88]
    3914:      	add	w8, w9, #0x1
    3918:      	and	w8, w8, #0xff
    391c:      	cmp	w8, #0x2
    3920:      	mov	w8, w9
    3924:      	b.lo	0x33cc <kprobe_unwind_hotspot+0x33cc>
    3928:      	sub	x25, x25, x9
    392c:      	mov	w8, #0x1                // =1
    3930:      	mov	w9, #0x70               // =112
    3934:      	add	x10, sp, #0x88
    3938:      	add	x0, sp, #0x88
    393c:      	mov	w1, #0x1                // =1
    3940:      	add	x2, x25, x19
    3944:      	blr	x9
    3948:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    394c:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3950:      	ldr	x8, [x8]
    3954:      	ldr	w8, [x8]
    3958:      	cbnz	w8, 0x43bc <kprobe_unwind_hotspot+0x43bc>
    395c:      	ldrb	w9, [sp, #0x88]
    3960:      	add	w8, w9, #0x1
    3964:      	and	w8, w8, #0xff
    3968:      	cmp	w8, #0x2
    396c:      	mov	w8, w9
    3970:      	b.lo	0x33cc <kprobe_unwind_hotspot+0x33cc>
    3974:      	sub	x25, x25, x9
    3978:      	mov	w8, #0x1                // =1
    397c:      	mov	w9, #0x70               // =112
    3980:      	add	x10, sp, #0x88
    3984:      	add	x0, sp, #0x88
    3988:      	mov	w1, #0x1                // =1
    398c:      	add	x2, x25, x19
    3990:      	blr	x9
    3994:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    3998:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    399c:      	ldr	x8, [x8]
    39a0:      	ldr	w8, [x8]
    39a4:      	cbnz	w8, 0x441c <kprobe_unwind_hotspot+0x441c>
    39a8:      	ldrb	w9, [sp, #0x88]
    39ac:      	add	w8, w9, #0x1
    39b0:      	and	w8, w8, #0xff
    39b4:      	cmp	w8, #0x2
    39b8:      	mov	w8, w9
    39bc:      	b.lo	0x33cc <kprobe_unwind_hotspot+0x33cc>
    39c0:      	sub	x25, x25, x9
    39c4:      	mov	w8, #0x1                // =1
    39c8:      	mov	w9, #0x70               // =112
    39cc:      	add	x10, sp, #0x88
    39d0:      	add	x0, sp, #0x88
    39d4:      	mov	w1, #0x1                // =1
    39d8:      	add	x2, x25, x19
    39dc:      	blr	x9
    39e0:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    39e4:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    39e8:      	ldr	x8, [x8]
    39ec:      	ldr	w8, [x8]
    39f0:      	cbz	w8, 0x3a38 <kprobe_unwind_hotspot+0x3a38>
    39f4:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    39f8:      	add	x8, x8, #0x0
    39fc:      	add	x11, sp, #0xc8
    3a00:      	ldp	x9, x10, [x8]
    3a04:      	add	x0, sp, #0xc8
    3a08:      	mov	w1, #0x1d               // =29
    3a0c:      	mov	x2, x25
    3a10:      	str	x9, [sp, #0xc8]
    3a14:      	ldr	x9, [x8, #0x10]
    3a18:      	ldur	x8, [x8, #0x15]
    3a1c:      	stp	x10, x9, [x11, #0x8]
    3a20:      	mov	w9, #0x6                // =6
    3a24:      	stur	x8, [x11, #0x15]
    3a28:      	mov	w8, #0x1d               // =29
    3a2c:      	add	x10, sp, #0xc8
    3a30:      	ldrb	w3, [sp, #0x88]
    3a34:      	blr	x9
    3a38:      	ldrb	w9, [sp, #0x88]
    3a3c:      	add	w8, w9, #0x1
    3a40:      	and	w8, w8, #0xff
    3a44:      	cmp	w8, #0x2
    3a48:      	mov	w8, w9
    3a4c:      	b.lo	0x33cc <kprobe_unwind_hotspot+0x33cc>
    3a50:      	sub	x25, x25, x9
    3a54:      	mov	w8, #0x1                // =1
    3a58:      	mov	w9, #0x70               // =112
    3a5c:      	add	x10, sp, #0x88
    3a60:      	add	x0, sp, #0x88
    3a64:      	mov	w1, #0x1                // =1
    3a68:      	add	x2, x25, x19
    3a6c:      	blr	x9
    3a70:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    3a74:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3a78:      	ldr	x8, [x8]
    3a7c:      	ldr	w8, [x8]
    3a80:      	cbz	w8, 0x3ac8 <kprobe_unwind_hotspot+0x3ac8>
    3a84:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3a88:      	add	x8, x8, #0x0
    3a8c:      	add	x11, sp, #0xc8
    3a90:      	ldp	x9, x10, [x8]
    3a94:      	add	x0, sp, #0xc8
    3a98:      	mov	w1, #0x1d               // =29
    3a9c:      	mov	x2, x25
    3aa0:      	str	x9, [sp, #0xc8]
    3aa4:      	ldr	x9, [x8, #0x10]
    3aa8:      	ldur	x8, [x8, #0x15]
    3aac:      	stp	x10, x9, [x11, #0x8]
    3ab0:      	mov	w9, #0x6                // =6
    3ab4:      	stur	x8, [x11, #0x15]
    3ab8:      	mov	w8, #0x1d               // =29
    3abc:      	add	x10, sp, #0xc8
    3ac0:      	ldrb	w3, [sp, #0x88]
    3ac4:      	blr	x9
    3ac8:      	ldrb	w9, [sp, #0x88]
    3acc:      	add	w8, w9, #0x1
    3ad0:      	and	w8, w8, #0xff
    3ad4:      	cmp	w8, #0x2
    3ad8:      	mov	w8, w9
    3adc:      	b.lo	0x33cc <kprobe_unwind_hotspot+0x33cc>
    3ae0:      	sub	x25, x25, x9
    3ae4:      	mov	w8, #0x1                // =1
    3ae8:      	mov	w9, #0x70               // =112
    3aec:      	add	x10, sp, #0x88
    3af0:      	add	x0, sp, #0x88
    3af4:      	mov	w1, #0x1                // =1
    3af8:      	add	x2, x25, x19
    3afc:      	blr	x9
    3b00:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    3b04:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3b08:      	ldr	x8, [x8]
    3b0c:      	ldr	w8, [x8]
    3b10:      	cbz	w8, 0x3b58 <kprobe_unwind_hotspot+0x3b58>
    3b14:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3b18:      	add	x8, x8, #0x0
    3b1c:      	add	x11, sp, #0xc8
    3b20:      	ldp	x9, x10, [x8]
    3b24:      	add	x0, sp, #0xc8
    3b28:      	mov	w1, #0x1d               // =29
    3b2c:      	mov	x2, x25
    3b30:      	str	x9, [sp, #0xc8]
    3b34:      	ldr	x9, [x8, #0x10]
    3b38:      	ldur	x8, [x8, #0x15]
    3b3c:      	stp	x10, x9, [x11, #0x8]
    3b40:      	mov	w9, #0x6                // =6
    3b44:      	stur	x8, [x11, #0x15]
    3b48:      	mov	w8, #0x1d               // =29
    3b4c:      	add	x10, sp, #0xc8
    3b50:      	ldrb	w3, [sp, #0x88]
    3b54:      	blr	x9
    3b58:      	ldrb	w9, [sp, #0x88]
    3b5c:      	add	w8, w9, #0x1
    3b60:      	and	w8, w8, #0xff
    3b64:      	cmp	w8, #0x2
    3b68:      	mov	w8, w9
    3b6c:      	b.lo	0x33cc <kprobe_unwind_hotspot+0x33cc>
    3b70:      	sub	x25, x25, x9
    3b74:      	mov	w8, #0x1                // =1
    3b78:      	mov	w9, #0x70               // =112
    3b7c:      	add	x10, sp, #0x88
    3b80:      	add	x0, sp, #0x88
    3b84:      	mov	w1, #0x1                // =1
    3b88:      	add	x2, x25, x19
    3b8c:      	blr	x9
    3b90:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    3b94:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3b98:      	ldr	x8, [x8]
    3b9c:      	ldr	w8, [x8]
    3ba0:      	cbz	w8, 0x3be8 <kprobe_unwind_hotspot+0x3be8>
    3ba4:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3ba8:      	add	x8, x8, #0x0
    3bac:      	add	x11, sp, #0xc8
    3bb0:      	ldp	x9, x10, [x8]
    3bb4:      	add	x0, sp, #0xc8
    3bb8:      	mov	w1, #0x1d               // =29
    3bbc:      	mov	x2, x25
    3bc0:      	str	x9, [sp, #0xc8]
    3bc4:      	ldr	x9, [x8, #0x10]
    3bc8:      	ldur	x8, [x8, #0x15]
    3bcc:      	stp	x10, x9, [x11, #0x8]
    3bd0:      	mov	w9, #0x6                // =6
    3bd4:      	stur	x8, [x11, #0x15]
    3bd8:      	mov	w8, #0x1d               // =29
    3bdc:      	add	x10, sp, #0xc8
    3be0:      	ldrb	w3, [sp, #0x88]
    3be4:      	blr	x9
    3be8:      	ldrb	w9, [sp, #0x88]
    3bec:      	add	w8, w9, #0x1
    3bf0:      	and	w8, w8, #0xff
    3bf4:      	cmp	w8, #0x2
    3bf8:      	mov	w8, w9
    3bfc:      	b.lo	0x33cc <kprobe_unwind_hotspot+0x33cc>
    3c00:      	sub	x25, x25, x9
    3c04:      	mov	w8, #0x1                // =1
    3c08:      	mov	w9, #0x70               // =112
    3c0c:      	add	x10, sp, #0x88
    3c10:      	add	x0, sp, #0x88
    3c14:      	mov	w1, #0x1                // =1
    3c18:      	add	x2, x25, x19
    3c1c:      	blr	x9
    3c20:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    3c24:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3c28:      	ldr	x8, [x8]
    3c2c:      	ldr	w8, [x8]
    3c30:      	cbz	w8, 0x3c78 <kprobe_unwind_hotspot+0x3c78>
    3c34:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3c38:      	add	x8, x8, #0x0
    3c3c:      	add	x11, sp, #0xc8
    3c40:      	ldp	x9, x10, [x8]
    3c44:      	add	x0, sp, #0xc8
    3c48:      	mov	w1, #0x1d               // =29
    3c4c:      	mov	x2, x25
    3c50:      	str	x9, [sp, #0xc8]
    3c54:      	ldr	x9, [x8, #0x10]
    3c58:      	ldur	x8, [x8, #0x15]
    3c5c:      	stp	x10, x9, [x11, #0x8]
    3c60:      	mov	w9, #0x6                // =6
    3c64:      	stur	x8, [x11, #0x15]
    3c68:      	mov	w8, #0x1d               // =29
    3c6c:      	add	x10, sp, #0xc8
    3c70:      	ldrb	w3, [sp, #0x88]
    3c74:      	blr	x9
    3c78:      	ldrb	w8, [sp, #0x88]
    3c7c:      	add	w9, w8, #0x1
    3c80:      	and	w9, w9, #0xff
    3c84:      	cmp	w9, #0x1
    3c88:      	b.hi	0x178 <kprobe_unwind_hotspot+0x178>
    3c8c:      	b	0x33cc <kprobe_unwind_hotspot+0x33cc>
    3c90:      	sub	x2, x22, #0x8
    3c94:      	mov	w8, #0x8                // =8
    3c98:      	mov	w9, #0x70               // =112
    3c9c:      	add	x10, sp, #0xc8
    3ca0:      	add	x0, sp, #0xc8
    3ca4:      	mov	w1, #0x8                // =8
    3ca8:      	blr	x9
    3cac:      	ldr	x8, [sp, #0xc8]
    3cb0:      	mov	x9, #0x27ff             // =10239
    3cb4:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    3cb8:      	movk	x9, #0xa9bf, lsl #16
    3cbc:      	movk	x9, #0x100, lsl #32
    3cc0:      	movk	x9, #0xd63f, lsl #48
    3cc4:      	cmp	x8, x9
    3cc8:      	add	x8, x29, #0x10
    3ccc:      	ccmp	x0, #0x0, #0x0, eq
    3cd0:      	csel	x29, x8, x29, eq
    3cd4:      	ldr	w8, [sp, #0x78]
    3cd8:      	b	0x4534 <kprobe_unwind_hotspot+0x4534>
    3cdc:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3ce0:      	add	x8, x8, #0x0
    3ce4:      	add	x11, sp, #0xc8
    3ce8:      	ldp	x9, x10, [x8]
    3cec:      	add	x0, sp, #0xc8
    3cf0:      	mov	w1, #0x1d               // =29
    3cf4:      	mov	x2, x25
    3cf8:      	str	x9, [sp, #0xc8]
    3cfc:      	ldr	x9, [x8, #0x10]
    3d00:      	ldur	x8, [x8, #0x15]
    3d04:      	stp	x10, x9, [x11, #0x8]
    3d08:      	mov	w9, #0x6                // =6
    3d0c:      	stur	x8, [x11, #0x15]
    3d10:      	mov	w8, #0x1d               // =29
    3d14:      	add	x10, sp, #0xc8
    3d18:      	ldrb	w3, [sp, #0x88]
    3d1c:      	blr	x9
    3d20:      	ldrb	w9, [sp, #0x88]
    3d24:      	add	w8, w9, #0x1
    3d28:      	and	w8, w8, #0xff
    3d2c:      	cmp	w8, #0x2
    3d30:      	mov	w8, w9
    3d34:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    3d38:      	b	0x2368 <kprobe_unwind_hotspot+0x2368>
    3d3c:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    3d40:      	ldrb	w8, [x21, #0xf21]
    3d44:      	cbnz	w8, 0x7bc <kprobe_unwind_hotspot+0x7bc>
    3d48:      	b	0x3df8 <kprobe_unwind_hotspot+0x3df8>
    3d4c:      	mov	w8, #0x656e             // =25966
    3d50:      	add	x11, sp, #0xc8
    3d54:      	add	x0, sp, #0xc8
    3d58:      	mov	w1, #0x1b               // =27
    3d5c:      	movk	w8, #0xa, lsl #16
    3d60:      	stur	w8, [x11, #0x17]
    3d64:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3d68:      	add	x8, x8, #0x0
    3d6c:      	ldp	x9, x10, [x8]
    3d70:      	ldr	x8, [x8, #0x10]
    3d74:      	str	x9, [sp, #0xc8]
    3d78:      	mov	w9, #0x6                // =6
    3d7c:      	stp	x10, x8, [x11, #0x8]
    3d80:      	mov	w8, #0x1b               // =27
    3d84:      	add	x10, sp, #0xc8
    3d88:      	blr	x9
    3d8c:      	mov	w25, #0x1               // =1
    3d90:      	cmp	w25, #0x2
    3d94:      	b.eq	0x32ac <kprobe_unwind_hotspot+0x32ac>
    3d98:      	b	0x6074 <kprobe_unwind_hotspot+0x6074>
    3d9c:      	ldr	x9, [sp, #0x88]
    3da0:      	ldr	x8, [sp, #0x58]
    3da4:      	cmp	x9, x8
    3da8:      	b.lo	0x3680 <kprobe_unwind_hotspot+0x3680>
    3dac:      	ldr	x10, [sp, #0x60]
    3db0:      	cmp	x9, x10
    3db4:      	b.hs	0x3680 <kprobe_unwind_hotspot+0x3680>
    3db8:      	adrp	x10, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3dbc:      	ldr	x10, [x10]
    3dc0:      	ldr	w10, [x10]
    3dc4:      	cbnz	w10, 0x447c <kprobe_unwind_hotspot+0x447c>
    3dc8:      	mov	x22, x9
    3dcc:      	sub	w8, w22, w8
    3dd0:      	str	x8, [sp, #0x30]
    3dd4:      	b	0x3690 <kprobe_unwind_hotspot+0x3690>
    3dd8:      	cbnz	w8, 0x44d8 <kprobe_unwind_hotspot+0x44d8>
    3ddc:      	mov	x22, xzr
    3de0:      	tbnz	x24, #0x3e, 0x4528 <kprobe_unwind_hotspot+0x4528>
    3de4:      	lsr	x8, x24, #53
    3de8:      	and	x8, x8, #0x1f8
    3dec:      	add	x29, x8, x29
    3df0:      	ldrb	w8, [x21, #0xf21]
    3df4:      	cbnz	w8, 0x7bc <kprobe_unwind_hotspot+0x7bc>
    3df8:      	ldr	x24, [x21, #0xee8]
    3dfc:      	b	0x4580 <kprobe_unwind_hotspot+0x4580>
    3e00:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3e04:      	add	x8, x8, #0x0
    3e08:      	add	x11, sp, #0xc8
    3e0c:      	strb	wzr, [sp, #0xe8]
    3e10:      	ldp	x9, x10, [x8]
    3e14:      	add	x0, sp, #0xc8
    3e18:      	mov	w1, #0x21               // =33
    3e1c:      	mov	x2, x24
    3e20:      	str	x9, [sp, #0xc8]
    3e24:      	ldp	x9, x8, [x8, #0x10]
    3e28:      	str	x8, [x11, #0x18]
    3e2c:      	stp	x10, x9, [x11, #0x8]
    3e30:      	mov	w8, #0x21               // =33
    3e34:      	mov	w9, #0x6                // =6
    3e38:      	add	x10, sp, #0xc8
    3e3c:      	blr	x9
    3e40:      	str	x24, [sp, #0x50]
    3e44:      	cbnz	x24, 0x3400 <kprobe_unwind_hotspot+0x3400>
    3e48:      	b	0x17c <kprobe_unwind_hotspot+0x17c>
    3e4c:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3e50:      	add	x8, x8, #0x0
    3e54:      	add	x11, sp, #0xc8
    3e58:      	ldp	x9, x10, [x8]
    3e5c:      	add	x0, sp, #0xc8
    3e60:      	mov	w1, #0x1d               // =29
    3e64:      	mov	x2, x25
    3e68:      	str	x9, [sp, #0xc8]
    3e6c:      	ldr	x9, [x8, #0x10]
    3e70:      	ldur	x8, [x8, #0x15]
    3e74:      	stp	x10, x9, [x11, #0x8]
    3e78:      	mov	w9, #0x6                // =6
    3e7c:      	stur	x8, [x11, #0x15]
    3e80:      	mov	w8, #0x1d               // =29
    3e84:      	add	x10, sp, #0xc8
    3e88:      	ldrb	w3, [sp, #0x88]
    3e8c:      	blr	x9
    3e90:      	ldrb	w9, [sp, #0x88]
    3e94:      	add	w8, w9, #0x1
    3e98:      	and	w8, w8, #0xff
    3e9c:      	cmp	w8, #0x2
    3ea0:      	mov	w8, w9
    3ea4:      	b.lo	0x33cc <kprobe_unwind_hotspot+0x33cc>
    3ea8:      	b	0x3844 <kprobe_unwind_hotspot+0x3844>
    3eac:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3eb0:      	add	x8, x8, #0x0
    3eb4:      	add	x11, sp, #0xc8
    3eb8:      	ldp	x9, x10, [x8]
    3ebc:      	add	x0, sp, #0xc8
    3ec0:      	mov	w1, #0x1d               // =29
    3ec4:      	mov	x2, x25
    3ec8:      	str	x9, [sp, #0xc8]
    3ecc:      	ldr	x9, [x8, #0x10]
    3ed0:      	ldur	x8, [x8, #0x15]
    3ed4:      	stp	x10, x9, [x11, #0x8]
    3ed8:      	mov	w9, #0x6                // =6
    3edc:      	stur	x8, [x11, #0x15]
    3ee0:      	mov	w8, #0x1d               // =29
    3ee4:      	add	x10, sp, #0xc8
    3ee8:      	ldrb	w3, [sp, #0x88]
    3eec:      	blr	x9
    3ef0:      	ldrb	w9, [sp, #0x88]
    3ef4:      	add	w8, w9, #0x1
    3ef8:      	and	w8, w8, #0xff
    3efc:      	cmp	w8, #0x2
    3f00:      	mov	w8, w9
    3f04:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    3f08:      	b	0x23b4 <kprobe_unwind_hotspot+0x23b4>
    3f0c:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3f10:      	add	x8, x8, #0x0
    3f14:      	add	x12, sp, #0xc8
    3f18:      	ldp	x9, x10, [x8, #0x10]
    3f1c:      	ldr	x11, [x8, #0x20]
    3f20:      	add	x0, sp, #0xc8
    3f24:      	mov	w1, #0x2e               // =46
    3f28:      	stp	x10, x11, [x12, #0x18]
    3f2c:      	ldur	x10, [x8, #0x26]
    3f30:      	stur	x10, [x12, #0x26]
    3f34:      	ldp	x10, x8, [x8]
    3f38:      	str	x10, [sp, #0xc8]
    3f3c:      	stp	x8, x9, [x12, #0x8]
    3f40:      	mov	w8, #0x2e               // =46
    3f44:      	mov	w9, #0x6                // =6
    3f48:      	add	x10, sp, #0xc8
    3f4c:      	ldr	w2, [sp, #0x88]
    3f50:      	blr	x9
    3f54:      	b	0x32a0 <kprobe_unwind_hotspot+0x32a0>
    3f58:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3f5c:      	add	x8, x8, #0x0
    3f60:      	add	x11, sp, #0xc8
    3f64:      	ldp	x9, x10, [x8]
    3f68:      	add	x0, sp, #0xc8
    3f6c:      	mov	w1, #0x1d               // =29
    3f70:      	mov	x2, x25
    3f74:      	str	x9, [sp, #0xc8]
    3f78:      	ldr	x9, [x8, #0x10]
    3f7c:      	ldur	x8, [x8, #0x15]
    3f80:      	stp	x10, x9, [x11, #0x8]
    3f84:      	mov	w9, #0x6                // =6
    3f88:      	stur	x8, [x11, #0x15]
    3f8c:      	mov	w8, #0x1d               // =29
    3f90:      	add	x10, sp, #0xc8
    3f94:      	ldrb	w3, [sp, #0x88]
    3f98:      	blr	x9
    3f9c:      	ldrb	w9, [sp, #0x88]
    3fa0:      	add	w8, w9, #0x1
    3fa4:      	and	w8, w8, #0xff
    3fa8:      	cmp	w8, #0x2
    3fac:      	mov	w8, w9
    3fb0:      	b.lo	0x33cc <kprobe_unwind_hotspot+0x33cc>
    3fb4:      	b	0x3890 <kprobe_unwind_hotspot+0x3890>
    3fb8:      	adrp	x8, 0x3000 <kprobe_unwind_hotspot+0x3000>
    3fbc:      	add	x8, x8, #0x0
    3fc0:      	add	x11, sp, #0xc8
    3fc4:      	ldp	x9, x10, [x8]
    3fc8:      	add	x0, sp, #0xc8
    3fcc:      	mov	w1, #0x1d               // =29
    3fd0:      	mov	x2, x25
    3fd4:      	str	x9, [sp, #0xc8]
    3fd8:      	ldr	x9, [x8, #0x10]
    3fdc:      	ldur	x8, [x8, #0x15]
    3fe0:      	stp	x10, x9, [x11, #0x8]
    3fe4:      	mov	w9, #0x6                // =6
    3fe8:      	stur	x8, [x11, #0x15]
    3fec:      	mov	w8, #0x1d               // =29
    3ff0:      	add	x10, sp, #0xc8
    3ff4:      	ldrb	w3, [sp, #0x88]
    3ff8:      	blr	x9
    3ffc:      	ldrb	w9, [sp, #0x88]
    4000:      	add	w8, w9, #0x1
    4004:      	and	w8, w8, #0xff
    4008:      	cmp	w8, #0x2
    400c:      	mov	w8, w9
    4010:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    4014:      	b	0x2400 <kprobe_unwind_hotspot+0x2400>
    4018:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    401c:      	add	x8, x8, #0x0
    4020:      	add	x11, sp, #0xc8
    4024:      	ldp	x9, x10, [x8]
    4028:      	add	x0, sp, #0xc8
    402c:      	mov	w1, #0x1d               // =29
    4030:      	mov	x2, x25
    4034:      	str	x9, [sp, #0xc8]
    4038:      	ldr	x9, [x8, #0x10]
    403c:      	ldur	x8, [x8, #0x15]
    4040:      	stp	x10, x9, [x11, #0x8]
    4044:      	mov	w9, #0x6                // =6
    4048:      	stur	x8, [x11, #0x15]
    404c:      	mov	w8, #0x1d               // =29
    4050:      	add	x10, sp, #0xc8
    4054:      	ldrb	w3, [sp, #0x88]
    4058:      	blr	x9
    405c:      	ldrb	w9, [sp, #0x88]
    4060:      	add	w8, w9, #0x1
    4064:      	and	w8, w8, #0xff
    4068:      	cmp	w8, #0x2
    406c:      	mov	w8, w9
    4070:      	b.lo	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    4074:      	b	0x244c <kprobe_unwind_hotspot+0x244c>
    4078:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    407c:      	add	x8, x8, #0x0
    4080:      	add	x11, sp, #0xc8
    4084:      	ldp	x9, x10, [x8]
    4088:      	add	x0, sp, #0xc8
    408c:      	mov	w1, #0x1d               // =29
    4090:      	mov	x2, x25
    4094:      	str	x9, [sp, #0xc8]
    4098:      	ldr	x9, [x8, #0x10]
    409c:      	ldur	x8, [x8, #0x15]
    40a0:      	stp	x10, x9, [x11, #0x8]
    40a4:      	mov	w9, #0x6                // =6
    40a8:      	stur	x8, [x11, #0x15]
    40ac:      	mov	w8, #0x1d               // =29
    40b0:      	add	x10, sp, #0xc8
    40b4:      	ldrb	w3, [sp, #0x88]
    40b8:      	blr	x9
    40bc:      	ldrb	w8, [sp, #0x88]
    40c0:      	add	w9, w8, #0x1
    40c4:      	and	w9, w9, #0xff
    40c8:      	cmp	w9, #0x1
    40cc:      	b.hi	0x178 <kprobe_unwind_hotspot+0x178>
    40d0:      	b	0x19f0 <kprobe_unwind_hotspot+0x19f0>
    40d4:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    40d8:      	add	x8, x8, #0x0
    40dc:      	add	x0, sp, #0xc8
    40e0:      	ldp	x9, x10, [x8]
    40e4:      	ldur	x8, [x8, #0xf]
    40e8:      	mov	w1, #0x17               // =23
    40ec:      	str	x9, [sp, #0xc8]
    40f0:      	add	x9, sp, #0xc8
    40f4:      	str	x10, [x9, #0x8]
    40f8:      	stur	x8, [x9, #0xf]
    40fc:      	mov	w8, #0x17               // =23
    4100:      	mov	w9, #0x6                // =6
    4104:      	add	x10, sp, #0xc8
    4108:      	ldp	x2, x3, [sp, #0x58]
    410c:      	blr	x9
    4110:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4114:      	ldr	x8, [x8]
    4118:      	ldr	w8, [x8]
    411c:      	cbz	w8, 0x34f0 <kprobe_unwind_hotspot+0x34f0>
    4120:      	mov	w8, #0x7825             // =30757
    4124:      	add	x13, sp, #0xc8
    4128:      	add	x0, sp, #0xc8
    412c:      	mov	w1, #0x3c               // =60
    4130:      	movk	w8, #0xa, lsl #16
    4134:      	str	w8, [sp, #0x100]
    4138:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    413c:      	add	x8, x8, #0x0
    4140:      	ldp	x9, x10, [x8, #0x20]
    4144:      	ldp	x12, x11, [x8, #0x10]
    4148:      	stp	x11, x9, [x13, #0x18]
    414c:      	ldr	x9, [x8, #0x30]
    4150:      	stp	x10, x9, [x13, #0x28]
    4154:      	ldp	x9, x8, [x8]
    4158:      	add	x10, sp, #0xc8
    415c:      	str	x9, [sp, #0xc8]
    4160:      	stp	x8, x12, [x13, #0x8]
    4164:      	mov	w8, #0x3c               // =60
    4168:      	mov	w9, #0x6                // =6
    416c:      	ldrh	w2, [sp, #0x80]
    4170:      	ldr	w3, [sp, #0x78]
    4174:      	ldr	w4, [sp, #0x70]
    4178:      	blr	x9
    417c:      	b	0x34f0 <kprobe_unwind_hotspot+0x34f0>
    4180:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4184:      	add	x8, x8, #0x0
    4188:      	add	x0, sp, #0x88
    418c:      	ldp	x9, x10, [x8, #0x20]
    4190:      	mov	w1, #0x35               // =53
    4194:      	mov	x2, x25
    4198:      	mov	x4, x19
    419c:      	stp	x9, x10, [sp, #0xa8]
    41a0:      	ldur	x9, [x8, #0x2d]
    41a4:      	stur	x9, [sp, #0xb5]
    41a8:      	ldp	x9, x10, [x8]
    41ac:      	stp	x9, x10, [sp, #0x88]
    41b0:      	ldp	x8, x9, [x8, #0x10]
    41b4:      	add	x10, sp, #0x88
    41b8:      	stp	x8, x9, [sp, #0x98]
    41bc:      	mov	w8, #0x35               // =53
    41c0:      	mov	w9, #0x6                // =6
    41c4:      	ldr	x3, [sp, #0xc0]
    41c8:      	blr	x9
    41cc:      	ldr	x8, [sp, #0xc0]
    41d0:      	b	0x35f8 <kprobe_unwind_hotspot+0x35f8>
    41d4:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    41d8:      	add	x8, x8, #0x0
    41dc:      	add	x13, sp, #0xc8
    41e0:      	ldp	x9, x10, [x8, #0x10]
    41e4:      	ldp	x11, x12, [x8, #0x20]
    41e8:      	add	x0, sp, #0xc8
    41ec:      	mov	w1, #0x30               // =48
    41f0:      	str	x12, [x13, #0x28]
    41f4:      	stp	x10, x11, [x13, #0x18]
    41f8:      	ldp	x10, x8, [x8]
    41fc:      	str	x10, [sp, #0xc8]
    4200:      	stp	x8, x9, [x13, #0x8]
    4204:      	mov	w8, #0x30               // =48
    4208:      	mov	w9, #0x6                // =6
    420c:      	add	x10, sp, #0xc8
    4210:      	blr	x9
    4214:      	b	0x3690 <kprobe_unwind_hotspot+0x3690>
    4218:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    421c:      	add	x8, x8, #0x0
    4220:      	add	x0, sp, #0xc8
    4224:      	ldp	x9, x10, [x8]
    4228:      	ldr	x8, [x8, #0x10]
    422c:      	mov	w1, #0x18               // =24
    4230:      	str	x9, [sp, #0xc8]
    4234:      	add	x9, sp, #0xc8
    4238:      	stp	x10, x8, [x9, #0x8]
    423c:      	mov	w8, #0x18               // =24
    4240:      	mov	w9, #0x6                // =6
    4244:      	add	x10, sp, #0xc8
    4248:      	blr	x9
    424c:      	mov	x22, #0x1000000000000000 // =1152921504606846976
    4250:      	ldrb	w8, [x21, #0xf21]
    4254:      	cbnz	w8, 0x7bc <kprobe_unwind_hotspot+0x7bc>
    4258:      	b	0x3df8 <kprobe_unwind_hotspot+0x3df8>
    425c:      	mov	w8, #0x6874             // =26740
    4260:      	add	x11, sp, #0xc8
    4264:      	add	x0, sp, #0xc8
    4268:      	mov	w1, #0x24               // =36
    426c:      	movk	w8, #0xa, lsl #16
    4270:      	str	w8, [sp, #0xe8]
    4274:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4278:      	add	x8, x8, #0x0
    427c:      	ldp	x9, x10, [x8]
    4280:      	str	x9, [sp, #0xc8]
    4284:      	ldp	x9, x8, [x8, #0x10]
    4288:      	stp	x10, x9, [x11, #0x8]
    428c:      	str	x8, [x11, #0x18]
    4290:      	mov	w8, #0x24               // =36
    4294:      	mov	w9, #0x6                // =6
    4298:      	add	x10, sp, #0xc8
    429c:      	blr	x9
    42a0:      	ldr	w8, [sp, #0x78]
    42a4:      	mov	x22, xzr
    42a8:      	cbnz	w8, 0x4534 <kprobe_unwind_hotspot+0x4534>
    42ac:      	b	0x4528 <kprobe_unwind_hotspot+0x4528>
    42b0:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    42b4:      	add	x8, x8, #0x0
    42b8:      	add	x11, sp, #0xc8
    42bc:      	ldp	x9, x10, [x8, #0x18]
    42c0:      	add	x0, sp, #0xc8
    42c4:      	mov	w1, #0x2f               // =47
    42c8:      	stp	x9, x10, [x11, #0x18]
    42cc:      	ldur	x10, [x8, #0x27]
    42d0:      	stur	x10, [x11, #0x27]
    42d4:      	ldr	x10, [x8]
    42d8:      	ldp	x8, x9, [x8, #0x8]
    42dc:      	str	x10, [sp, #0xc8]
    42e0:      	stp	x8, x9, [x11, #0x8]
    42e4:      	mov	w8, #0x2f               // =47
    42e8:      	mov	w9, #0x6                // =6
    42ec:      	add	x10, sp, #0xc8
    42f0:      	blr	x9
    42f4:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    42f8:      	b	0x4528 <kprobe_unwind_hotspot+0x4528>
    42fc:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4300:      	add	x8, x8, #0x0
    4304:      	add	x11, sp, #0xc8
    4308:      	ldp	x9, x10, [x8]
    430c:      	add	x0, sp, #0xc8
    4310:      	mov	w1, #0x1d               // =29
    4314:      	mov	x2, x25
    4318:      	str	x9, [sp, #0xc8]
    431c:      	ldr	x9, [x8, #0x10]
    4320:      	ldur	x8, [x8, #0x15]
    4324:      	stp	x10, x9, [x11, #0x8]
    4328:      	mov	w9, #0x6                // =6
    432c:      	stur	x8, [x11, #0x15]
    4330:      	mov	w8, #0x1d               // =29
    4334:      	add	x10, sp, #0xc8
    4338:      	ldrb	w3, [sp, #0x88]
    433c:      	blr	x9
    4340:      	ldrb	w9, [sp, #0x88]
    4344:      	add	w8, w9, #0x1
    4348:      	and	w8, w8, #0xff
    434c:      	cmp	w8, #0x2
    4350:      	mov	w8, w9
    4354:      	b.lo	0x33cc <kprobe_unwind_hotspot+0x33cc>
    4358:      	b	0x38dc <kprobe_unwind_hotspot+0x38dc>
    435c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4360:      	add	x8, x8, #0x0
    4364:      	add	x11, sp, #0xc8
    4368:      	ldp	x9, x10, [x8]
    436c:      	add	x0, sp, #0xc8
    4370:      	mov	w1, #0x1d               // =29
    4374:      	mov	x2, x25
    4378:      	str	x9, [sp, #0xc8]
    437c:      	ldr	x9, [x8, #0x10]
    4380:      	ldur	x8, [x8, #0x15]
    4384:      	stp	x10, x9, [x11, #0x8]
    4388:      	mov	w9, #0x6                // =6
    438c:      	stur	x8, [x11, #0x15]
    4390:      	mov	w8, #0x1d               // =29
    4394:      	add	x10, sp, #0xc8
    4398:      	ldrb	w3, [sp, #0x88]
    439c:      	blr	x9
    43a0:      	ldrb	w9, [sp, #0x88]
    43a4:      	add	w8, w9, #0x1
    43a8:      	and	w8, w8, #0xff
    43ac:      	cmp	w8, #0x2
    43b0:      	mov	w8, w9
    43b4:      	b.lo	0x33cc <kprobe_unwind_hotspot+0x33cc>
    43b8:      	b	0x3928 <kprobe_unwind_hotspot+0x3928>
    43bc:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    43c0:      	add	x8, x8, #0x0
    43c4:      	add	x11, sp, #0xc8
    43c8:      	ldp	x9, x10, [x8]
    43cc:      	add	x0, sp, #0xc8
    43d0:      	mov	w1, #0x1d               // =29
    43d4:      	mov	x2, x25
    43d8:      	str	x9, [sp, #0xc8]
    43dc:      	ldr	x9, [x8, #0x10]
    43e0:      	ldur	x8, [x8, #0x15]
    43e4:      	stp	x10, x9, [x11, #0x8]
    43e8:      	mov	w9, #0x6                // =6
    43ec:      	stur	x8, [x11, #0x15]
    43f0:      	mov	w8, #0x1d               // =29
    43f4:      	add	x10, sp, #0xc8
    43f8:      	ldrb	w3, [sp, #0x88]
    43fc:      	blr	x9
    4400:      	ldrb	w9, [sp, #0x88]
    4404:      	add	w8, w9, #0x1
    4408:      	and	w8, w8, #0xff
    440c:      	cmp	w8, #0x2
    4410:      	mov	w8, w9
    4414:      	b.lo	0x33cc <kprobe_unwind_hotspot+0x33cc>
    4418:      	b	0x3974 <kprobe_unwind_hotspot+0x3974>
    441c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4420:      	add	x8, x8, #0x0
    4424:      	add	x11, sp, #0xc8
    4428:      	ldp	x9, x10, [x8]
    442c:      	add	x0, sp, #0xc8
    4430:      	mov	w1, #0x1d               // =29
    4434:      	mov	x2, x25
    4438:      	str	x9, [sp, #0xc8]
    443c:      	ldr	x9, [x8, #0x10]
    4440:      	ldur	x8, [x8, #0x15]
    4444:      	stp	x10, x9, [x11, #0x8]
    4448:      	mov	w9, #0x6                // =6
    444c:      	stur	x8, [x11, #0x15]
    4450:      	mov	w8, #0x1d               // =29
    4454:      	add	x10, sp, #0xc8
    4458:      	ldrb	w3, [sp, #0x88]
    445c:      	blr	x9
    4460:      	ldrb	w9, [sp, #0x88]
    4464:      	add	w8, w9, #0x1
    4468:      	and	w8, w8, #0xff
    446c:      	cmp	w8, #0x2
    4470:      	mov	w8, w9
    4474:      	b.lo	0x33cc <kprobe_unwind_hotspot+0x33cc>
    4478:      	b	0x39c0 <kprobe_unwind_hotspot+0x39c0>
    447c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4480:      	add	x8, x8, #0x0
    4484:      	add	x13, sp, #0xc8
    4488:      	ldp	x9, x10, [x8, #0x20]
    448c:      	ldp	x11, x12, [x8, #0x30]
    4490:      	add	x0, sp, #0xc8
    4494:      	mov	w1, #0x40               // =64
    4498:      	str	x12, [x13, #0x38]
    449c:      	stp	x10, x11, [x13, #0x28]
    44a0:      	ldp	x10, x11, [x8]
    44a4:      	str	x10, [sp, #0xc8]
    44a8:      	ldp	x10, x8, [x8, #0x10]
    44ac:      	stp	x11, x10, [x13, #0x8]
    44b0:      	add	x10, sp, #0xc8
    44b4:      	stp	x8, x9, [x13, #0x18]
    44b8:      	mov	w8, #0x40               // =64
    44bc:      	mov	w9, #0x6                // =6
    44c0:      	ldr	x2, [sp, #0x88]
    44c4:      	ldr	w3, [sp, #0x74]
    44c8:      	blr	x9
    44cc:      	ldr	x22, [sp, #0x88]
    44d0:      	ldr	x8, [sp, #0x58]
    44d4:      	b	0x3dcc <kprobe_unwind_hotspot+0x3dcc>
    44d8:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    44dc:      	add	x8, x8, #0x0
    44e0:      	add	x13, sp, #0xc8
    44e4:      	strb	wzr, [sp, #0xf8]
    44e8:      	ldp	x9, x10, [x8, #0x10]
    44ec:      	add	x0, sp, #0xc8
    44f0:      	ldp	x11, x12, [x8, #0x20]
    44f4:      	mov	w1, #0x31               // =49
    44f8:      	mov	x2, x24
    44fc:      	str	x12, [x13, #0x28]
    4500:      	stp	x10, x11, [x13, #0x18]
    4504:      	ldp	x10, x8, [x8]
    4508:      	str	x10, [sp, #0xc8]
    450c:      	add	x10, sp, #0xc8
    4510:      	stp	x8, x9, [x13, #0x8]
    4514:      	mov	w8, #0x31               // =49
    4518:      	mov	w9, #0x6                // =6
    451c:      	blr	x9
    4520:      	mov	x22, xzr
    4524:      	tbz	x24, #0x3e, 0x3de4 <kprobe_unwind_hotspot+0x3de4>
    4528:      	ldr	x29, [sp, #0x38]
    452c:      	mov	w8, #0x10               // =16
    4530:      	str	w8, [sp, #0x78]
    4534:      	add	x9, x29, w8, uxtw
    4538:      	mov	w8, #0x10               // =16
    453c:      	add	x10, sp, #0x88
    4540:      	add	x0, sp, #0x88
    4544:      	mov	w1, #0x10               // =16
    4548:      	mov	x29, x9
    454c:      	sub	x2, x9, #0x10
    4550:      	mov	w9, #0x70               // =112
    4554:      	blr	x9
    4558:      	ldr	w8, [sp, #0x78]
    455c:      	ldr	x24, [sp, #0x90]
    4560:      	cmp	w8, #0x10
    4564:      	b.lo	0x4580 <kprobe_unwind_hotspot+0x4580>
    4568:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    456c:      	ldr	x8, [x8]
    4570:      	ldr	w8, [x8]
    4574:      	cbnz	w8, 0x53b4 <kprobe_unwind_hotspot+0x53b4>
    4578:      	ldr	x8, [sp, #0x88]
    457c:      	str	x8, [sp, #0x38]
    4580:      	ldr	w8, [x21, #0x2c0]
    4584:      	cmp	w8, #0x7e
    4588:      	b.hi	0x1508 <kprobe_unwind_hotspot+0x1508>
    458c:      	mov	w12, w19
    4590:      	and	x10, x22, #0x3000000000000000
    4594:      	ldr	x11, [sp, #0x30]
    4598:      	ldrb	w9, [x21, #0xf20]
    459c:      	orr	x11, x12, x11, lsl #32
    45a0:      	orr	x10, x11, x10
    45a4:      	add	w11, w8, #0x1
    45a8:      	str	w11, [x21, #0x2c0]
    45ac:      	mov	w11, #0x18              // =24
    45b0:      	umaddl	x8, w8, w11, x21
    45b4:      	str	x10, [x8, #0x2d8]
    45b8:      	mov	w10, #0x5               // =5
    45bc:      	str	x25, [x8, #0x2d0]
    45c0:      	strb	w9, [x8, #0x2e1]
    45c4:      	strh	wzr, [x8, #0x2e6]
    45c8:      	strb	w10, [x8, #0x2e0]
    45cc:      	add	x10, x8, #0x2d0
    45d0:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    45d4:      	stur	wzr, [x10, #0x12]
    45d8:      	ldr	x8, [x8]
    45dc:      	ldr	w8, [x8]
    45e0:      	cbnz	w8, 0x53f0 <kprobe_unwind_hotspot+0x53f0>
    45e4:      	ldr	x8, [sp, #0x38]
    45e8:      	str	x24, [x21, #0xed0]
    45ec:      	adrp	x0, 0x4000 <kprobe_unwind_hotspot+0x4000>
    45f0:      	add	x9, sp, #0x88
    45f4:      	add	x1, sp, #0x88
    45f8:      	str	x29, [x21, #0xed8]
    45fc:      	str	x8, [x21, #0xee0]
    4600:      	mov	w8, #0x101              // =257
    4604:      	strh	w8, [x21, #0xf20]
    4608:      	mov	w8, #0x2a               // =42
    460c:      	str	w8, [sp, #0x88]
    4610:      	mov	w8, #0x1                // =1
    4614:      	ldr	x0, [x0]
    4618:      	blr	x8
    461c:      	cbz	x0, 0x463c <kprobe_unwind_hotspot+0x463c>
    4620:      	ldr	x8, [x0]
    4624:      	add	x8, x8, #0x1
    4628:      	str	x8, [x0]
    462c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4630:      	ldr	x8, [x8]
    4634:      	ldr	w8, [x8]
    4638:      	b	0x464c <kprobe_unwind_hotspot+0x464c>
    463c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4640:      	ldr	x8, [x8]
    4644:      	ldr	w8, [x8]
    4648:      	cbnz	w8, 0x5444 <kprobe_unwind_hotspot+0x5444>
    464c:      	ldr	x29, [x21, #0xed0]
    4650:      	cbz	x29, 0x5eac <kprobe_unwind_hotspot+0x5eac>
    4654:      	cbnz	w8, 0x5490 <kprobe_unwind_hotspot+0x5490>
    4658:      	lsr	x8, x29, #56
    465c:      	cbnz	x8, 0x1644 <kprobe_unwind_hotspot+0x1644>
    4660:      	cmp	x29, #0x1, lsl #12      // =0x1000
    4664:      	b.lo	0x1798 <kprobe_unwind_hotspot+0x1798>
    4668:      	ldr	w8, [x21]
    466c:      	mov	w9, #0x60               // =96
    4670:      	add	x1, sp, #0x50
    4674:      	mov	x0, x20
    4678:      	rev	w8, w8
    467c:      	stp	w9, w8, [sp, #0x50]
    4680:      	rev	x8, x29
    4684:      	add	x9, sp, #0x50
    4688:      	str	x8, [sp, #0x58]
    468c:      	mov	w8, #0x1                // =1
    4690:      	blr	x8
    4694:      	cbz	x0, 0x5ee0 <kprobe_unwind_hotspot+0x5ee0>
    4698:      	ldr	x8, [x0, #0x8]
    469c:      	and	x9, x8, #0xffffffffffffff
    46a0:      	lsr	x25, x8, #56
    46a4:      	str	x9, [x21, #0xf10]
    46a8:      	ldr	x8, [x0]
    46ac:      	str	x8, [x21, #0xf00]
    46b0:      	sub	x8, x29, x9
    46b4:      	str	x8, [x21, #0xf08]
    46b8:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    46bc:      	ldr	x8, [x8]
    46c0:      	ldr	w8, [x8]
    46c4:      	cbnz	w8, 0x54e8 <kprobe_unwind_hotspot+0x54e8>
    46c8:      	cmp	w25, #0x1
    46cc:      	b.ne	0x47ac <kprobe_unwind_hotspot+0x47ac>
    46d0:      	ldr	x8, [x21, #0xf00]
    46d4:      	adrp	x0, 0x4000 <kprobe_unwind_hotspot+0x4000>
    46d8:      	ldr	x19, [x21, #0xf08]
    46dc:      	mov	w9, #0x1                // =1
    46e0:      	add	x1, sp, #0x50
    46e4:      	mov	w22, #0x1               // =1
    46e8:      	str	x8, [sp, #0x50]
    46ec:      	add	x8, sp, #0x50
    46f0:      	ldr	x0, [x0]
    46f4:      	blr	x9
    46f8:      	cbz	x0, 0x47a8 <kprobe_unwind_hotspot+0x47a8>
    46fc:      	ldr	x8, [x0]
    4700:      	mov	x25, x0
    4704:      	cmp	x8, x19
    4708:      	b.hi	0x4718 <kprobe_unwind_hotspot+0x4718>
    470c:      	ldr	x8, [x25, #0x8]
    4710:      	cmp	x8, x19
    4714:      	b.hs	0x4730 <kprobe_unwind_hotspot+0x4730>
    4718:      	ldr	x8, [x25, #0x10]
    471c:      	cmp	x8, x19
    4720:      	b.hi	0x47a0 <kprobe_unwind_hotspot+0x47a0>
    4724:      	ldr	x8, [x25, #0x18]
    4728:      	cmp	x8, x19
    472c:      	b.lo	0x47a0 <kprobe_unwind_hotspot+0x47a0>
    4730:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4734:      	ldr	x8, [x8]
    4738:      	ldr	w8, [x8]
    473c:      	cbz	w8, 0x4780 <kprobe_unwind_hotspot+0x4780>
    4740:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4744:      	add	x8, x8, #0x0
    4748:      	add	x11, sp, #0xc8
    474c:      	ldp	x9, x10, [x8]
    4750:      	add	x0, sp, #0xc8
    4754:      	mov	w1, #0x1e               // =30
    4758:      	str	x9, [sp, #0xc8]
    475c:      	ldr	x9, [x8, #0x10]
    4760:      	ldur	x8, [x8, #0x16]
    4764:      	stp	x10, x9, [x11, #0x8]
    4768:      	mov	w9, #0x6                // =6
    476c:      	stur	x8, [x11, #0x16]
    4770:      	mov	w8, #0x1e               // =30
    4774:      	add	x10, sp, #0xc8
    4778:      	ldrh	w2, [x25, #0x20]
    477c:      	blr	x9
    4780:      	ldrh	w8, [x25, #0x20]
    4784:      	ldr	w9, [x21, #0x1370]
    4788:      	lsr	w8, w9, w8
    478c:      	tbz	w8, #0x0, 0x559c <kprobe_unwind_hotspot+0x559c>
    4790:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4794:      	ldr	x8, [x8]
    4798:      	ldr	w8, [x8]
    479c:      	cbnz	w8, 0x55cc <kprobe_unwind_hotspot+0x55cc>
    47a0:      	mov	w25, #0x1               // =1
    47a4:      	b	0x47ac <kprobe_unwind_hotspot+0x47ac>
    47a8:      	mov	w25, w22
    47ac:      	cmp	w25, #0x2
    47b0:      	b.ne	0x6074 <kprobe_unwind_hotspot+0x6074>
    47b4:      	mov	w8, #0x29               // =41
    47b8:      	adrp	x0, 0x4000 <kprobe_unwind_hotspot+0x4000>
    47bc:      	add	x9, sp, #0x50
    47c0:      	str	w8, [sp, #0x50]
    47c4:      	mov	w8, #0x1                // =1
    47c8:      	add	x1, sp, #0x50
    47cc:      	ldr	x0, [x0]
    47d0:      	blr	x8
    47d4:      	cbz	x0, 0x485c <kprobe_unwind_hotspot+0x485c>
    47d8:      	ldr	x8, [x0]
    47dc:      	add	x8, x8, #0x1
    47e0:      	str	x8, [x0]
    47e4:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    47e8:      	ldr	x8, [x8]
    47ec:      	ldr	x22, [x21, #0xed0]
    47f0:      	ldr	x10, [x21, #0xed8]
    47f4:      	ldr	x9, [x21, #0xee0]
    47f8:      	ldr	w8, [x8]
    47fc:      	stp	x9, x10, [sp, #0x30]
    4800:      	cbz	w8, 0x487c <kprobe_unwind_hotspot+0x487c>
    4804:      	mov	w8, #0x786c             // =30828
    4808:      	add	x13, sp, #0xc8
    480c:      	add	x0, sp, #0xc8
    4810:      	mov	w1, #0x2c               // =44
    4814:      	movk	w8, #0xa, lsl #16
    4818:      	str	w8, [sp, #0xf0]
    481c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4820:      	add	x8, x8, #0x0
    4824:      	ldp	x9, x10, [x8, #0x10]
    4828:      	ldp	x12, x11, [x8]
    482c:      	ldr	x8, [x8, #0x20]
    4830:      	str	x12, [sp, #0xc8]
    4834:      	stp	x11, x9, [x13, #0x8]
    4838:      	stp	x10, x8, [x13, #0x18]
    483c:      	mov	w8, #0x2c               // =44
    4840:      	mov	w9, #0x6                // =6
    4844:      	add	x10, sp, #0xc8
    4848:      	ldr	x2, [x21, #0xed0]
    484c:      	ldr	x3, [x21, #0xf10]
    4850:      	ldr	x4, [x21, #0xf08]
    4854:      	blr	x9
    4858:      	b	0x487c <kprobe_unwind_hotspot+0x487c>
    485c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4860:      	ldr	x8, [x8]
    4864:      	ldr	w8, [x8]
    4868:      	cbnz	w8, 0x5614 <kprobe_unwind_hotspot+0x5614>
    486c:      	ldr	x9, [x21, #0xed8]
    4870:      	ldr	x8, [x21, #0xee0]
    4874:      	ldr	x22, [x21, #0xed0]
    4878:      	stp	x8, x9, [sp, #0x30]
    487c:      	ldr	x8, [x21, #0xf08]
    4880:      	ldrb	w9, [x23, #0x20]
    4884:      	add	x10, sp, #0x88
    4888:      	add	x0, sp, #0x88
    488c:      	mov	w1, #0x1                // =1
    4890:      	lsr	x25, x8, x9
    4894:      	ldr	x8, [x21, #0xf00]
    4898:      	mov	w9, #0x70               // =112
    489c:      	and	x19, x8, #0xffffffffffffff
    48a0:      	mov	w8, #0x1                // =1
    48a4:      	add	x2, x25, x19
    48a8:      	blr	x9
    48ac:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    48b0:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    48b4:      	ldr	x8, [x8]
    48b8:      	ldr	w8, [x8]
    48bc:      	cbz	w8, 0x4904 <kprobe_unwind_hotspot+0x4904>
    48c0:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    48c4:      	add	x8, x8, #0x0
    48c8:      	add	x11, sp, #0xc8
    48cc:      	ldp	x9, x10, [x8]
    48d0:      	add	x0, sp, #0xc8
    48d4:      	mov	w1, #0x1d               // =29
    48d8:      	mov	x2, x25
    48dc:      	str	x9, [sp, #0xc8]
    48e0:      	ldr	x9, [x8, #0x10]
    48e4:      	ldur	x8, [x8, #0x15]
    48e8:      	stp	x10, x9, [x11, #0x8]
    48ec:      	mov	w9, #0x6                // =6
    48f0:      	stur	x8, [x11, #0x15]
    48f4:      	mov	w8, #0x1d               // =29
    48f8:      	add	x10, sp, #0xc8
    48fc:      	ldrb	w3, [sp, #0x88]
    4900:      	blr	x9
    4904:      	ldrb	w8, [sp, #0x88]
    4908:      	add	w9, w8, #0x1
    490c:      	and	w9, w9, #0xff
    4910:      	cmp	w9, #0x2
    4914:      	b.lo	0x4f44 <kprobe_unwind_hotspot+0x4f44>
    4918:      	sub	x25, x25, x8
    491c:      	mov	w8, #0x1                // =1
    4920:      	mov	w9, #0x70               // =112
    4924:      	add	x10, sp, #0x88
    4928:      	add	x0, sp, #0x88
    492c:      	mov	w1, #0x1                // =1
    4930:      	add	x2, x25, x19
    4934:      	blr	x9
    4938:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    493c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4940:      	ldr	x8, [x8]
    4944:      	ldr	w8, [x8]
    4948:      	cbz	w8, 0x4990 <kprobe_unwind_hotspot+0x4990>
    494c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4950:      	add	x8, x8, #0x0
    4954:      	add	x11, sp, #0xc8
    4958:      	ldp	x9, x10, [x8]
    495c:      	add	x0, sp, #0xc8
    4960:      	mov	w1, #0x1d               // =29
    4964:      	mov	x2, x25
    4968:      	str	x9, [sp, #0xc8]
    496c:      	ldr	x9, [x8, #0x10]
    4970:      	ldur	x8, [x8, #0x15]
    4974:      	stp	x10, x9, [x11, #0x8]
    4978:      	mov	w9, #0x6                // =6
    497c:      	stur	x8, [x11, #0x15]
    4980:      	mov	w8, #0x1d               // =29
    4984:      	add	x10, sp, #0xc8
    4988:      	ldrb	w3, [sp, #0x88]
    498c:      	blr	x9
    4990:      	ldrb	w9, [sp, #0x88]
    4994:      	add	w8, w9, #0x1
    4998:      	and	w8, w8, #0xff
    499c:      	cmp	w8, #0x2
    49a0:      	mov	w8, w9
    49a4:      	b.lo	0x4f44 <kprobe_unwind_hotspot+0x4f44>
    49a8:      	sub	x25, x25, x9
    49ac:      	mov	w8, #0x1                // =1
    49b0:      	mov	w9, #0x70               // =112
    49b4:      	add	x10, sp, #0x88
    49b8:      	add	x0, sp, #0x88
    49bc:      	mov	w1, #0x1                // =1
    49c0:      	add	x2, x25, x19
    49c4:      	blr	x9
    49c8:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    49cc:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    49d0:      	ldr	x8, [x8]
    49d4:      	ldr	w8, [x8]
    49d8:      	cbz	w8, 0x4a20 <kprobe_unwind_hotspot+0x4a20>
    49dc:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    49e0:      	add	x8, x8, #0x0
    49e4:      	add	x11, sp, #0xc8
    49e8:      	ldp	x9, x10, [x8]
    49ec:      	add	x0, sp, #0xc8
    49f0:      	mov	w1, #0x1d               // =29
    49f4:      	mov	x2, x25
    49f8:      	str	x9, [sp, #0xc8]
    49fc:      	ldr	x9, [x8, #0x10]
    4a00:      	ldur	x8, [x8, #0x15]
    4a04:      	stp	x10, x9, [x11, #0x8]
    4a08:      	mov	w9, #0x6                // =6
    4a0c:      	stur	x8, [x11, #0x15]
    4a10:      	mov	w8, #0x1d               // =29
    4a14:      	add	x10, sp, #0xc8
    4a18:      	ldrb	w3, [sp, #0x88]
    4a1c:      	blr	x9
    4a20:      	ldrb	w9, [sp, #0x88]
    4a24:      	add	w8, w9, #0x1
    4a28:      	and	w8, w8, #0xff
    4a2c:      	cmp	w8, #0x2
    4a30:      	mov	w8, w9
    4a34:      	b.lo	0x4f44 <kprobe_unwind_hotspot+0x4f44>
    4a38:      	sub	x25, x25, x9
    4a3c:      	mov	w8, #0x1                // =1
    4a40:      	mov	w9, #0x70               // =112
    4a44:      	add	x10, sp, #0x88
    4a48:      	add	x0, sp, #0x88
    4a4c:      	mov	w1, #0x1                // =1
    4a50:      	add	x2, x25, x19
    4a54:      	blr	x9
    4a58:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    4a5c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4a60:      	ldr	x8, [x8]
    4a64:      	ldr	w8, [x8]
    4a68:      	cbz	w8, 0x4ab0 <kprobe_unwind_hotspot+0x4ab0>
    4a6c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4a70:      	add	x8, x8, #0x0
    4a74:      	add	x11, sp, #0xc8
    4a78:      	ldp	x9, x10, [x8]
    4a7c:      	add	x0, sp, #0xc8
    4a80:      	mov	w1, #0x1d               // =29
    4a84:      	mov	x2, x25
    4a88:      	str	x9, [sp, #0xc8]
    4a8c:      	ldr	x9, [x8, #0x10]
    4a90:      	ldur	x8, [x8, #0x15]
    4a94:      	stp	x10, x9, [x11, #0x8]
    4a98:      	mov	w9, #0x6                // =6
    4a9c:      	stur	x8, [x11, #0x15]
    4aa0:      	mov	w8, #0x1d               // =29
    4aa4:      	add	x10, sp, #0xc8
    4aa8:      	ldrb	w3, [sp, #0x88]
    4aac:      	blr	x9
    4ab0:      	ldrb	w9, [sp, #0x88]
    4ab4:      	add	w8, w9, #0x1
    4ab8:      	and	w8, w8, #0xff
    4abc:      	cmp	w8, #0x2
    4ac0:      	mov	w8, w9
    4ac4:      	b.lo	0x4f44 <kprobe_unwind_hotspot+0x4f44>
    4ac8:      	sub	x25, x25, x9
    4acc:      	mov	w8, #0x1                // =1
    4ad0:      	mov	w9, #0x70               // =112
    4ad4:      	add	x10, sp, #0x88
    4ad8:      	add	x0, sp, #0x88
    4adc:      	mov	w1, #0x1                // =1
    4ae0:      	add	x2, x25, x19
    4ae4:      	blr	x9
    4ae8:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    4aec:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4af0:      	ldr	x8, [x8]
    4af4:      	ldr	w8, [x8]
    4af8:      	cbz	w8, 0x4b40 <kprobe_unwind_hotspot+0x4b40>
    4afc:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4b00:      	add	x8, x8, #0x0
    4b04:      	add	x11, sp, #0xc8
    4b08:      	ldp	x9, x10, [x8]
    4b0c:      	add	x0, sp, #0xc8
    4b10:      	mov	w1, #0x1d               // =29
    4b14:      	mov	x2, x25
    4b18:      	str	x9, [sp, #0xc8]
    4b1c:      	ldr	x9, [x8, #0x10]
    4b20:      	ldur	x8, [x8, #0x15]
    4b24:      	stp	x10, x9, [x11, #0x8]
    4b28:      	mov	w9, #0x6                // =6
    4b2c:      	stur	x8, [x11, #0x15]
    4b30:      	mov	w8, #0x1d               // =29
    4b34:      	add	x10, sp, #0xc8
    4b38:      	ldrb	w3, [sp, #0x88]
    4b3c:      	blr	x9
    4b40:      	ldrb	w9, [sp, #0x88]
    4b44:      	add	w8, w9, #0x1
    4b48:      	and	w8, w8, #0xff
    4b4c:      	cmp	w8, #0x2
    4b50:      	mov	w8, w9
    4b54:      	b.lo	0x4f44 <kprobe_unwind_hotspot+0x4f44>
    4b58:      	sub	x25, x25, x9
    4b5c:      	mov	w8, #0x1                // =1
    4b60:      	mov	w9, #0x70               // =112
    4b64:      	add	x10, sp, #0x88
    4b68:      	add	x0, sp, #0x88
    4b6c:      	mov	w1, #0x1                // =1
    4b70:      	add	x2, x25, x19
    4b74:      	blr	x9
    4b78:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    4b7c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4b80:      	ldr	x8, [x8]
    4b84:      	ldr	w8, [x8]
    4b88:      	cbz	w8, 0x4bd0 <kprobe_unwind_hotspot+0x4bd0>
    4b8c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4b90:      	add	x8, x8, #0x0
    4b94:      	add	x11, sp, #0xc8
    4b98:      	ldp	x9, x10, [x8]
    4b9c:      	add	x0, sp, #0xc8
    4ba0:      	mov	w1, #0x1d               // =29
    4ba4:      	mov	x2, x25
    4ba8:      	str	x9, [sp, #0xc8]
    4bac:      	ldr	x9, [x8, #0x10]
    4bb0:      	ldur	x8, [x8, #0x15]
    4bb4:      	stp	x10, x9, [x11, #0x8]
    4bb8:      	mov	w9, #0x6                // =6
    4bbc:      	stur	x8, [x11, #0x15]
    4bc0:      	mov	w8, #0x1d               // =29
    4bc4:      	add	x10, sp, #0xc8
    4bc8:      	ldrb	w3, [sp, #0x88]
    4bcc:      	blr	x9
    4bd0:      	ldrb	w9, [sp, #0x88]
    4bd4:      	add	w8, w9, #0x1
    4bd8:      	and	w8, w8, #0xff
    4bdc:      	cmp	w8, #0x2
    4be0:      	mov	w8, w9
    4be4:      	b.lo	0x4f44 <kprobe_unwind_hotspot+0x4f44>
    4be8:      	sub	x25, x25, x9
    4bec:      	mov	w8, #0x1                // =1
    4bf0:      	mov	w9, #0x70               // =112
    4bf4:      	add	x10, sp, #0x88
    4bf8:      	add	x0, sp, #0x88
    4bfc:      	mov	w1, #0x1                // =1
    4c00:      	add	x2, x25, x19
    4c04:      	blr	x9
    4c08:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    4c0c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4c10:      	ldr	x8, [x8]
    4c14:      	ldr	w8, [x8]
    4c18:      	cbz	w8, 0x4c60 <kprobe_unwind_hotspot+0x4c60>
    4c1c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4c20:      	add	x8, x8, #0x0
    4c24:      	add	x11, sp, #0xc8
    4c28:      	ldp	x9, x10, [x8]
    4c2c:      	add	x0, sp, #0xc8
    4c30:      	mov	w1, #0x1d               // =29
    4c34:      	mov	x2, x25
    4c38:      	str	x9, [sp, #0xc8]
    4c3c:      	ldr	x9, [x8, #0x10]
    4c40:      	ldur	x8, [x8, #0x15]
    4c44:      	stp	x10, x9, [x11, #0x8]
    4c48:      	mov	w9, #0x6                // =6
    4c4c:      	stur	x8, [x11, #0x15]
    4c50:      	mov	w8, #0x1d               // =29
    4c54:      	add	x10, sp, #0xc8
    4c58:      	ldrb	w3, [sp, #0x88]
    4c5c:      	blr	x9
    4c60:      	ldrb	w9, [sp, #0x88]
    4c64:      	add	w8, w9, #0x1
    4c68:      	and	w8, w8, #0xff
    4c6c:      	cmp	w8, #0x2
    4c70:      	mov	w8, w9
    4c74:      	b.lo	0x4f44 <kprobe_unwind_hotspot+0x4f44>
    4c78:      	sub	x25, x25, x9
    4c7c:      	mov	w8, #0x1                // =1
    4c80:      	mov	w9, #0x70               // =112
    4c84:      	add	x10, sp, #0x88
    4c88:      	add	x0, sp, #0x88
    4c8c:      	mov	w1, #0x1                // =1
    4c90:      	add	x2, x25, x19
    4c94:      	blr	x9
    4c98:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    4c9c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4ca0:      	ldr	x8, [x8]
    4ca4:      	ldr	w8, [x8]
    4ca8:      	cbz	w8, 0x4cf0 <kprobe_unwind_hotspot+0x4cf0>
    4cac:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4cb0:      	add	x8, x8, #0x0
    4cb4:      	add	x11, sp, #0xc8
    4cb8:      	ldp	x9, x10, [x8]
    4cbc:      	add	x0, sp, #0xc8
    4cc0:      	mov	w1, #0x1d               // =29
    4cc4:      	mov	x2, x25
    4cc8:      	str	x9, [sp, #0xc8]
    4ccc:      	ldr	x9, [x8, #0x10]
    4cd0:      	ldur	x8, [x8, #0x15]
    4cd4:      	stp	x10, x9, [x11, #0x8]
    4cd8:      	mov	w9, #0x6                // =6
    4cdc:      	stur	x8, [x11, #0x15]
    4ce0:      	mov	w8, #0x1d               // =29
    4ce4:      	add	x10, sp, #0xc8
    4ce8:      	ldrb	w3, [sp, #0x88]
    4cec:      	blr	x9
    4cf0:      	ldrb	w9, [sp, #0x88]
    4cf4:      	add	w8, w9, #0x1
    4cf8:      	and	w8, w8, #0xff
    4cfc:      	cmp	w8, #0x2
    4d00:      	mov	w8, w9
    4d04:      	b.lo	0x4f44 <kprobe_unwind_hotspot+0x4f44>
    4d08:      	sub	x25, x25, x9
    4d0c:      	mov	w8, #0x1                // =1
    4d10:      	mov	w9, #0x70               // =112
    4d14:      	add	x10, sp, #0x88
    4d18:      	add	x0, sp, #0x88
    4d1c:      	mov	w1, #0x1                // =1
    4d20:      	add	x2, x25, x19
    4d24:      	blr	x9
    4d28:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    4d2c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4d30:      	ldr	x8, [x8]
    4d34:      	ldr	w8, [x8]
    4d38:      	cbz	w8, 0x4d80 <kprobe_unwind_hotspot+0x4d80>
    4d3c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4d40:      	add	x8, x8, #0x0
    4d44:      	add	x11, sp, #0xc8
    4d48:      	ldp	x9, x10, [x8]
    4d4c:      	add	x0, sp, #0xc8
    4d50:      	mov	w1, #0x1d               // =29
    4d54:      	mov	x2, x25
    4d58:      	str	x9, [sp, #0xc8]
    4d5c:      	ldr	x9, [x8, #0x10]
    4d60:      	ldur	x8, [x8, #0x15]
    4d64:      	stp	x10, x9, [x11, #0x8]
    4d68:      	mov	w9, #0x6                // =6
    4d6c:      	stur	x8, [x11, #0x15]
    4d70:      	mov	w8, #0x1d               // =29
    4d74:      	add	x10, sp, #0xc8
    4d78:      	ldrb	w3, [sp, #0x88]
    4d7c:      	blr	x9
    4d80:      	ldrb	w9, [sp, #0x88]
    4d84:      	add	w8, w9, #0x1
    4d88:      	and	w8, w8, #0xff
    4d8c:      	cmp	w8, #0x2
    4d90:      	mov	w8, w9
    4d94:      	b.lo	0x4f44 <kprobe_unwind_hotspot+0x4f44>
    4d98:      	sub	x25, x25, x9
    4d9c:      	mov	w8, #0x1                // =1
    4da0:      	mov	w9, #0x70               // =112
    4da4:      	add	x10, sp, #0x88
    4da8:      	add	x0, sp, #0x88
    4dac:      	mov	w1, #0x1                // =1
    4db0:      	add	x2, x25, x19
    4db4:      	blr	x9
    4db8:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    4dbc:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4dc0:      	ldr	x8, [x8]
    4dc4:      	ldr	w8, [x8]
    4dc8:      	cbz	w8, 0x4e10 <kprobe_unwind_hotspot+0x4e10>
    4dcc:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4dd0:      	add	x8, x8, #0x0
    4dd4:      	add	x11, sp, #0xc8
    4dd8:      	ldp	x9, x10, [x8]
    4ddc:      	add	x0, sp, #0xc8
    4de0:      	mov	w1, #0x1d               // =29
    4de4:      	mov	x2, x25
    4de8:      	str	x9, [sp, #0xc8]
    4dec:      	ldr	x9, [x8, #0x10]
    4df0:      	ldur	x8, [x8, #0x15]
    4df4:      	stp	x10, x9, [x11, #0x8]
    4df8:      	mov	w9, #0x6                // =6
    4dfc:      	stur	x8, [x11, #0x15]
    4e00:      	mov	w8, #0x1d               // =29
    4e04:      	add	x10, sp, #0xc8
    4e08:      	ldrb	w3, [sp, #0x88]
    4e0c:      	blr	x9
    4e10:      	ldrb	w9, [sp, #0x88]
    4e14:      	add	w8, w9, #0x1
    4e18:      	and	w8, w8, #0xff
    4e1c:      	cmp	w8, #0x2
    4e20:      	mov	w8, w9
    4e24:      	b.lo	0x4f44 <kprobe_unwind_hotspot+0x4f44>
    4e28:      	sub	x25, x25, x9
    4e2c:      	mov	w8, #0x1                // =1
    4e30:      	mov	w9, #0x70               // =112
    4e34:      	add	x10, sp, #0x88
    4e38:      	add	x0, sp, #0x88
    4e3c:      	mov	w1, #0x1                // =1
    4e40:      	add	x2, x25, x19
    4e44:      	blr	x9
    4e48:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    4e4c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4e50:      	ldr	x8, [x8]
    4e54:      	ldr	w8, [x8]
    4e58:      	cbz	w8, 0x4ea0 <kprobe_unwind_hotspot+0x4ea0>
    4e5c:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4e60:      	add	x8, x8, #0x0
    4e64:      	add	x11, sp, #0xc8
    4e68:      	ldp	x9, x10, [x8]
    4e6c:      	add	x0, sp, #0xc8
    4e70:      	mov	w1, #0x1d               // =29
    4e74:      	mov	x2, x25
    4e78:      	str	x9, [sp, #0xc8]
    4e7c:      	ldr	x9, [x8, #0x10]
    4e80:      	ldur	x8, [x8, #0x15]
    4e84:      	stp	x10, x9, [x11, #0x8]
    4e88:      	mov	w9, #0x6                // =6
    4e8c:      	stur	x8, [x11, #0x15]
    4e90:      	mov	w8, #0x1d               // =29
    4e94:      	add	x10, sp, #0xc8
    4e98:      	ldrb	w3, [sp, #0x88]
    4e9c:      	blr	x9
    4ea0:      	ldrb	w9, [sp, #0x88]
    4ea4:      	add	w8, w9, #0x1
    4ea8:      	and	w8, w8, #0xff
    4eac:      	cmp	w8, #0x2
    4eb0:      	mov	w8, w9
    4eb4:      	b.lo	0x4f44 <kprobe_unwind_hotspot+0x4f44>
    4eb8:      	sub	x25, x25, x9
    4ebc:      	mov	w8, #0x1                // =1
    4ec0:      	mov	w9, #0x70               // =112
    4ec4:      	add	x10, sp, #0x88
    4ec8:      	add	x0, sp, #0x88
    4ecc:      	mov	w1, #0x1                // =1
    4ed0:      	add	x2, x25, x19
    4ed4:      	blr	x9
    4ed8:      	cbnz	x0, 0x178 <kprobe_unwind_hotspot+0x178>
    4edc:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4ee0:      	ldr	x8, [x8]
    4ee4:      	ldr	w8, [x8]
    4ee8:      	cbz	w8, 0x4f30 <kprobe_unwind_hotspot+0x4f30>
    4eec:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4ef0:      	add	x8, x8, #0x0
    4ef4:      	add	x11, sp, #0xc8
    4ef8:      	ldp	x9, x10, [x8]
    4efc:      	add	x0, sp, #0xc8
    4f00:      	mov	w1, #0x1d               // =29
    4f04:      	mov	x2, x25
    4f08:      	str	x9, [sp, #0xc8]
    4f0c:      	ldr	x9, [x8, #0x10]
    4f10:      	ldur	x8, [x8, #0x15]
    4f14:      	stp	x10, x9, [x11, #0x8]
    4f18:      	mov	w9, #0x6                // =6
    4f1c:      	stur	x8, [x11, #0x15]
    4f20:      	mov	w8, #0x1d               // =29
    4f24:      	add	x10, sp, #0xc8
    4f28:      	ldrb	w3, [sp, #0x88]
    4f2c:      	blr	x9
    4f30:      	ldrb	w8, [sp, #0x88]
    4f34:      	add	w9, w8, #0x1
    4f38:      	and	w9, w9, #0xff
    4f3c:      	cmp	w9, #0x1
    4f40:      	b.hi	0x178 <kprobe_unwind_hotspot+0x178>
    4f44:      	cbnz	w8, 0x178 <kprobe_unwind_hotspot+0x178>
    4f48:      	ldr	x8, [x21, #0xf10]
    4f4c:      	ldrb	w9, [x23, #0x20]
    4f50:      	lsl	x9, x25, x9
    4f54:      	ldrb	w10, [x23, #0x1b]
    4f58:      	add	x8, x8, x10
    4f5c:      	add	x24, x9, x8
    4f60:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4f64:      	ldr	x8, [x8]
    4f68:      	ldr	w8, [x8]
    4f6c:      	cbz	w8, 0x4fb0 <kprobe_unwind_hotspot+0x4fb0>
    4f70:      	adrp	x8, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4f74:      	add	x8, x8, #0x0
    4f78:      	add	x11, sp, #0xc8
    4f7c:      	strb	wzr, [sp, #0xe8]
    4f80:      	ldp	x9, x10, [x8]
    4f84:      	add	x0, sp, #0xc8
    4f88:      	mov	w1, #0x21               // =33
    4f8c:      	mov	x2, x24
    4f90:      	str	x9, [sp, #0xc8]
    4f94:      	ldp	x9, x8, [x8, #0x10]
    4f98:      	str	x8, [x11, #0x18]
    4f9c:      	stp	x10, x9, [x11, #0x8]
    4fa0:      	mov	w8, #0x21               // =33
    4fa4:      	mov	w9, #0x6                // =6
    4fa8:      	add	x10, sp, #0xc8
    4fac:      	blr	x9
    4fb0:      	str	x24, [sp, #0x50]
    4fb4:      	cbz	x24, 0x17c <kprobe_unwind_hotspot+0x17c>
    4fb8:      	mov	w8, #0x200              // =512
    4fbc:      	mov	w9, #0x70               // =112
    4fc0:      	ldr	x0, [sp, #0x8]
    4fc4:      	mov	w1, #0x200              // =512
    4fc8:      	ldr	x2, [sp, #0x50]
    4fcc:      	blr	x9
    4fd0:      	adrp	x24, 0x4000 <kprobe_unwind_hotspot+0x4000>
    4fd4:      	ldr	x24, [x24]
    4fd8:      	cbnz	x0, 0x258 <kprobe_unwind_hotspot+0x258>
    4fdc:      	ldrh	w8, [x23, #0x10]
    4fe0:      	cmp	x8, #0x1f8
    4fe4:      	b.hi	0x3c4 <kprobe_unwind_hotspot+0x3c4>
    4fe8:      	ldrh	w9, [x23, #0x12]
    4fec:      	cmp	x9, #0x1fc
    4ff0:      	b.hi	0x3c4 <kprobe_unwind_hotspot+0x3c4>
    4ff4:      	ldrh	w10, [x23, #0x14]
    4ff8:      	cmp	x10, #0x1f8
    4ffc:      	b.hi	0x3c4 <kprobe_unwind_hotspot+0x3c4>
    5000:      	ldrb	w11, [x23, #0x17]
    5004:      	ldr	x12, [sp, #0x8]
    5008:      	mov	w1, #0x4                // =4
    500c:      	ldr	x0, [sp, #0x40]
    5010:      	ldr	x11, [x12, x11]
    5014:      	str	x11, [sp, #0x58]
    5018:      	ldrb	w11, [x23, #0x18]
    501c:      	ldr	x11, [x12, x11]
    5020:      	str	x11, [sp, #0x60]
    5024:      	ldrb	w11, [x23, #0x1a]
    5028:      	ldr	w11, [x12, x11]
    502c:      	lsl	w11, w11, #3
    5030:      	str	w11, [sp, #0x78]
    5034:      	ldrb	w11, [x23, #0x19]
    5038:      	ldrh	w11, [x12, x11]
    503c:      	strh	w11, [sp, #0x80]
    5040:      	ldr	w9, [x12, x9]
    5044:      	str	w9, [sp, #0x7c]
    5048:      	ldr	w9, [x12, x10]
    504c:      	str	w9, [sp, #0x74]
    5050:      	mov	w9, #0x70               // =112
    5054:      	ldr	x8, [x12, x8]
    5058:      	str	x8, [sp, #0x68]
    505c:      	ldrb	w8, [x23, #0x16]
    5060:      	ldr	x2, [x12, x8]
    5064:      	mov	w8, #0x4                // =4
    5068:      	blr	x9
    506c:      	adrp	x24, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5070:      	ldr	x24, [x24]
    5074:      	cbnz	x0, 0x258 <kprobe_unwind_hotspot+0x258>
    5078:      	ldrb	w8, [x23, #0x21]
    507c:      	cbz	w8, 0x5098 <kprobe_unwind_hotspot+0x5098>
    5080:      	ldr	x8, [sp, #0x50]
    5084:      	ldr	w9, [sp, #0x58]
    5088:      	add	x9, x9, x8
    508c:      	ldr	w10, [sp, #0x60]
    5090:      	add	x8, x10, x8
    5094:      	stp	x9, x8, [sp, #0x58]
    5098:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    509c:      	ldr	x8, [x8]
    50a0:      	ldr	w8, [x8]
    50a4:      	cbz	w8, 0x5150 <kprobe_unwind_hotspot+0x5150>
    50a8:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    50ac:      	add	x8, x8, #0x0
    50b0:      	add	x0, sp, #0xc8
    50b4:      	ldp	x9, x10, [x8]
    50b8:      	ldur	x8, [x8, #0xf]
    50bc:      	mov	w1, #0x17               // =23
    50c0:      	str	x9, [sp, #0xc8]
    50c4:      	add	x9, sp, #0xc8
    50c8:      	str	x10, [x9, #0x8]
    50cc:      	stur	x8, [x9, #0xf]
    50d0:      	mov	w8, #0x17               // =23
    50d4:      	mov	w9, #0x6                // =6
    50d8:      	add	x10, sp, #0xc8
    50dc:      	ldp	x2, x3, [sp, #0x58]
    50e0:      	blr	x9
    50e4:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    50e8:      	ldr	x8, [x8]
    50ec:      	ldr	w8, [x8]
    50f0:      	cbz	w8, 0x5150 <kprobe_unwind_hotspot+0x5150>
    50f4:      	mov	w8, #0x7825             // =30757
    50f8:      	add	x13, sp, #0xc8
    50fc:      	add	x0, sp, #0xc8
    5100:      	mov	w1, #0x3c               // =60
    5104:      	movk	w8, #0xa, lsl #16
    5108:      	str	w8, [sp, #0x100]
    510c:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5110:      	add	x8, x8, #0x0
    5114:      	ldp	x9, x10, [x8, #0x20]
    5118:      	ldp	x12, x11, [x8, #0x10]
    511c:      	stp	x11, x9, [x13, #0x18]
    5120:      	ldr	x9, [x8, #0x30]
    5124:      	stp	x10, x9, [x13, #0x28]
    5128:      	ldp	x9, x8, [x8]
    512c:      	add	x10, sp, #0xc8
    5130:      	str	x9, [sp, #0xc8]
    5134:      	stp	x8, x12, [x13, #0x8]
    5138:      	mov	w8, #0x3c               // =60
    513c:      	mov	w9, #0x6                // =6
    5140:      	ldrh	w2, [sp, #0x80]
    5144:      	ldr	w3, [sp, #0x78]
    5148:      	ldr	w4, [sp, #0x70]
    514c:      	blr	x9
    5150:      	ldr	w19, [sp, #0x70]
    5154:      	ldp	x24, x8, [sp, #0x50]
    5158:      	mov	w9, #0x616d             // =24941
    515c:      	movk	w9, #0x6974, lsl #16
    5160:      	sub	w29, w22, w8
    5164:      	cmp	w19, w9
    5168:      	b.gt	0x5660 <kprobe_unwind_hotspot+0x5660>
    516c:      	mov	w8, #0x7476             // =29814
    5170:      	movk	w8, #0x6261, lsl #16
    5174:      	cmp	w19, w8
    5178:      	b.eq	0x5704 <kprobe_unwind_hotspot+0x5704>
    517c:      	mov	w8, #0x6e49             // =28233
    5180:      	movk	w8, #0x6574, lsl #16
    5184:      	cmp	w19, w8
    5188:      	b.ne	0x5784 <kprobe_unwind_hotspot+0x5784>
    518c:      	ldp	x8, x9, [sp, #0x30]
    5190:      	cmp	x8, x9
    5194:      	b.lo	0x52c0 <kprobe_unwind_hotspot+0x52c0>
    5198:      	ldp	x9, x8, [sp, #0x30]
    519c:      	add	x8, x8, #0x1, lsl #12   // =0x1000
    51a0:      	cmp	x9, x8
    51a4:      	b.hs	0x52c0 <kprobe_unwind_hotspot+0x52c0>
    51a8:      	ldr	x8, [sp, #0x30]
    51ac:      	mov	w9, #0x70               // =112
    51b0:      	add	x10, sp, #0xc8
    51b4:      	add	x0, sp, #0xc8
    51b8:      	mov	w1, #0x60               // =96
    51bc:      	sub	x2, x8, #0x50
    51c0:      	mov	w8, #0x60               // =96
    51c4:      	blr	x9
    51c8:      	cbnz	x0, 0x51c <kprobe_unwind_hotspot+0x51c>
    51cc:      	ldr	w8, [x21, #0x2c0]
    51d0:      	cbz	w8, 0x51e8 <kprobe_unwind_hotspot+0x51e8>
    51d4:      	ldrb	w8, [x23, #0x1f]
    51d8:      	cmp	w8, #0x0
    51dc:      	ldp	x9, x8, [sp, #0x10]
    51e0:      	csel	x8, x9, x8, eq
    51e4:      	str	x8, [sp, #0x20]
    51e8:      	ldr	x8, [sp, #0x20]
    51ec:      	add	x11, sp, #0xc0
    51f0:      	add	x0, sp, #0xc0
    51f4:      	mov	w1, #0x8                // =8
    51f8:      	ldr	x19, [x8]
    51fc:      	add	x8, sp, #0xc8
    5200:      	ldp	x10, x9, [x8, #0x48]
    5204:      	ldr	x24, [x8, #0x38]
    5208:      	ldr	x25, [x8, #0x58]
    520c:      	ldrb	w8, [x23, #0x1c]
    5210:      	stp	x9, x10, [sp, #0x30]
    5214:      	add	x8, x24, x8
    5218:      	mov	w9, #0x8                // =8
    521c:      	mov	w10, #0x70              // =112
    5220:      	ldrb	w8, [x23, #0x1c]
    5224:      	add	x2, x24, x8
    5228:      	blr	x10
    522c:      	cbnz	x0, 0xf20 <kprobe_unwind_hotspot+0xf20>
    5230:      	ldr	x8, [sp, #0xc0]
    5234:      	ldrb	w9, [x23, #0x1d]
    5238:      	add	x9, x8, x9
    523c:      	cmp	x19, x9
    5240:      	csel	x9, xzr, x9, lo
    5244:      	sub	x23, x19, x9
    5248:      	adrp	x9, 0x5000 <kprobe_unwind_hotspot+0x5000>
    524c:      	ldr	x9, [x9]
    5250:      	ldr	w9, [x9]
    5254:      	cbz	w9, 0x52a8 <kprobe_unwind_hotspot+0x52a8>
    5258:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    525c:      	add	x8, x8, #0x0
    5260:      	add	x0, sp, #0x88
    5264:      	ldp	x9, x10, [x8, #0x20]
    5268:      	mov	w1, #0x35               // =53
    526c:      	mov	x2, x24
    5270:      	mov	x4, x23
    5274:      	stp	x9, x10, [sp, #0xa8]
    5278:      	ldur	x9, [x8, #0x2d]
    527c:      	stur	x9, [sp, #0xb5]
    5280:      	ldp	x9, x10, [x8]
    5284:      	stp	x9, x10, [sp, #0x88]
    5288:      	ldp	x8, x9, [x8, #0x10]
    528c:      	add	x10, sp, #0x88
    5290:      	stp	x8, x9, [sp, #0x98]
    5294:      	mov	w8, #0x35               // =53
    5298:      	mov	w9, #0x6                // =6
    529c:      	ldr	x3, [sp, #0xc0]
    52a0:      	blr	x9
    52a4:      	ldr	x8, [sp, #0xc0]
    52a8:      	mov	w9, #0xffff             // =65535
    52ac:      	lsr	x19, x8, #3
    52b0:      	mov	x22, #0x2000000000000000 // =2305843009213693952
    52b4:      	cmp	x23, x9
    52b8:      	csel	x29, x23, x9, lo
    52bc:      	b	0x5af8 <kprobe_unwind_hotspot+0x5af8>
    52c0:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    52c4:      	ldr	x8, [x8]
    52c8:      	ldr	w8, [x8]
    52cc:      	cbnz	w8, 0x5328 <kprobe_unwind_hotspot+0x5328>
    52d0:      	mov	w8, #0x2d               // =45
    52d4:      	adrp	x0, 0x5000 <kprobe_unwind_hotspot+0x5000>
    52d8:      	add	x9, sp, #0x12c
    52dc:      	str	w8, [sp, #0x12c]
    52e0:      	mov	w8, #0x1                // =1
    52e4:      	add	x1, sp, #0x12c
    52e8:      	ldr	x0, [x0]
    52ec:      	blr	x8
    52f0:      	cbz	x0, 0x5304 <kprobe_unwind_hotspot+0x5304>
    52f4:      	ldr	x8, [x0]
    52f8:      	add	x8, x8, #0x1
    52fc:      	str	x8, [x0]
    5300:      	b	0x5314 <kprobe_unwind_hotspot+0x5314>
    5304:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5308:      	ldr	x8, [x8]
    530c:      	ldr	w8, [x8]
    5310:      	cbnz	w8, 0x536c <kprobe_unwind_hotspot+0x536c>
    5314:      	adrp	x24, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5318:      	ldr	x22, [sp, #0x138]
    531c:      	mov	w8, #0x3e9              // =1001
    5320:      	ldr	x24, [x24]
    5324:      	b	0x3cc <kprobe_unwind_hotspot+0x3cc>
    5328:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    532c:      	add	x8, x8, #0x0
    5330:      	add	x0, sp, #0x88
    5334:      	ldp	x9, x10, [x8, #0x10]
    5338:      	mov	w1, #0x2e               // =46
    533c:      	stp	x9, x10, [sp, #0x98]
    5340:      	ldr	x9, [x8, #0x20]
    5344:      	add	x10, sp, #0x88
    5348:      	str	x9, [sp, #0xa8]
    534c:      	ldur	x9, [x8, #0x26]
    5350:      	stur	x9, [sp, #0xae]
    5354:      	ldp	x9, x8, [x8]
    5358:      	stp	x9, x8, [sp, #0x88]
    535c:      	mov	w8, #0x2e               // =46
    5360:      	mov	w9, #0x6                // =6
    5364:      	blr	x9
    5368:      	b	0x52d0 <kprobe_unwind_hotspot+0x52d0>
    536c:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5370:      	add	x8, x8, #0x0
    5374:      	add	x0, sp, #0x88
    5378:      	ldp	x9, x10, [x8, #0x10]
    537c:      	mov	w1, #0x2e               // =46
    5380:      	stp	x9, x10, [sp, #0x98]
    5384:      	ldr	x9, [x8, #0x20]
    5388:      	add	x10, sp, #0x88
    538c:      	str	x9, [sp, #0xa8]
    5390:      	ldur	x9, [x8, #0x26]
    5394:      	stur	x9, [sp, #0xae]
    5398:      	ldp	x9, x8, [x8]
    539c:      	stp	x9, x8, [sp, #0x88]
    53a0:      	mov	w8, #0x2e               // =46
    53a4:      	mov	w9, #0x6                // =6
    53a8:      	ldr	w2, [sp, #0x12c]
    53ac:      	blr	x9
    53b0:      	b	0x5314 <kprobe_unwind_hotspot+0x5314>
    53b4:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    53b8:      	add	x8, x8, #0x0
    53bc:      	add	x0, sp, #0xc8
    53c0:      	ldp	x9, x10, [x8]
    53c4:      	ldur	x8, [x8, #0xd]
    53c8:      	mov	w1, #0x15               // =21
    53cc:      	str	x9, [sp, #0xc8]
    53d0:      	add	x9, sp, #0xc8
    53d4:      	str	x10, [x9, #0x8]
    53d8:      	stur	x8, [x9, #0xd]
    53dc:      	mov	w8, #0x15               // =21
    53e0:      	mov	w9, #0x6                // =6
    53e4:      	add	x10, sp, #0xc8
    53e8:      	blr	x9
    53ec:      	b	0x4578 <kprobe_unwind_hotspot+0x4578>
    53f0:      	mov	w8, #0x786c             // =30828
    53f4:      	add	x11, sp, #0xc8
    53f8:      	add	x0, sp, #0xc8
    53fc:      	mov	w1, #0x24               // =36
    5400:      	mov	x2, x24
    5404:      	mov	x3, x29
    5408:      	movk	w8, #0xa, lsl #16
    540c:      	str	w8, [sp, #0xe8]
    5410:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5414:      	add	x8, x8, #0x0
    5418:      	ldp	x9, x10, [x8]
    541c:      	str	x9, [sp, #0xc8]
    5420:      	ldp	x9, x8, [x8, #0x10]
    5424:      	stp	x10, x9, [x11, #0x8]
    5428:      	str	x8, [x11, #0x18]
    542c:      	mov	w8, #0x24               // =36
    5430:      	mov	w9, #0x6                // =6
    5434:      	add	x10, sp, #0xc8
    5438:      	ldr	x4, [sp, #0x38]
    543c:      	blr	x9
    5440:      	b	0x45e4 <kprobe_unwind_hotspot+0x45e4>
    5444:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5448:      	add	x8, x8, #0x0
    544c:      	add	x12, sp, #0xc8
    5450:      	ldp	x9, x10, [x8, #0x10]
    5454:      	ldr	x11, [x8, #0x20]
    5458:      	add	x0, sp, #0xc8
    545c:      	mov	w1, #0x2e               // =46
    5460:      	stp	x10, x11, [x12, #0x18]
    5464:      	ldur	x10, [x8, #0x26]
    5468:      	stur	x10, [x12, #0x26]
    546c:      	ldp	x10, x8, [x8]
    5470:      	str	x10, [sp, #0xc8]
    5474:      	stp	x8, x9, [x12, #0x8]
    5478:      	mov	w8, #0x2e               // =46
    547c:      	mov	w9, #0x6                // =6
    5480:      	add	x10, sp, #0xc8
    5484:      	ldr	w2, [sp, #0x88]
    5488:      	blr	x9
    548c:      	b	0x462c <kprobe_unwind_hotspot+0x462c>
    5490:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5494:      	add	x8, x8, #0x0
    5498:      	add	x13, sp, #0xc8
    549c:      	strb	wzr, [sp, #0xf8]
    54a0:      	ldp	x9, x10, [x8, #0x10]
    54a4:      	add	x0, sp, #0xc8
    54a8:      	ldp	x11, x12, [x8, #0x20]
    54ac:      	mov	w1, #0x31               // =49
    54b0:      	str	x12, [x13, #0x28]
    54b4:      	stp	x10, x11, [x13, #0x18]
    54b8:      	ldp	x10, x8, [x8]
    54bc:      	str	x10, [sp, #0xc8]
    54c0:      	stp	x8, x9, [x13, #0x8]
    54c4:      	mov	w8, #0x31               // =49
    54c8:      	mov	w9, #0x6                // =6
    54cc:      	add	x10, sp, #0xc8
    54d0:      	ldr	w2, [x21, #0x2c0]
    54d4:      	blr	x9
    54d8:      	ldr	x29, [x21, #0xed0]
    54dc:      	lsr	x8, x29, #56
    54e0:      	cbnz	x8, 0x1644 <kprobe_unwind_hotspot+0x1644>
    54e4:      	b	0x4660 <kprobe_unwind_hotspot+0x4660>
    54e8:      	mov	w8, #0xa                // =10
    54ec:      	add	x13, sp, #0xc8
    54f0:      	add	x0, sp, #0xc8
    54f4:      	strh	w8, [sp, #0xf8]
    54f8:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    54fc:      	add	x8, x8, #0x0
    5500:      	mov	w1, #0x32               // =50
    5504:      	ldp	x9, x10, [x8, #0x10]
    5508:      	ldp	x11, x12, [x8, #0x20]
    550c:      	mov	x2, x29
    5510:      	mov	w4, w25
    5514:      	str	x12, [x13, #0x28]
    5518:      	stp	x10, x11, [x13, #0x18]
    551c:      	ldp	x10, x8, [x8]
    5520:      	str	x10, [sp, #0xc8]
    5524:      	add	x10, sp, #0xc8
    5528:      	stp	x8, x9, [x13, #0x8]
    552c:      	mov	w8, #0x32               // =50
    5530:      	mov	w9, #0x6                // =6
    5534:      	ldr	x3, [x21, #0xf00]
    5538:      	blr	x9
    553c:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5540:      	ldr	x8, [x8]
    5544:      	ldr	w8, [x8]
    5548:      	cbz	w8, 0x46c8 <kprobe_unwind_hotspot+0x46c8>
    554c:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5550:      	add	x8, x8, #0x0
    5554:      	add	x12, sp, #0xc8
    5558:      	ldp	x9, x10, [x8, #0x10]
    555c:      	ldr	x11, [x8, #0x20]
    5560:      	add	x0, sp, #0xc8
    5564:      	mov	w1, #0x2f               // =47
    5568:      	stp	x10, x11, [x12, #0x18]
    556c:      	ldur	x10, [x8, #0x27]
    5570:      	stur	x10, [x12, #0x27]
    5574:      	ldp	x10, x8, [x8]
    5578:      	str	x10, [sp, #0xc8]
    557c:      	stp	x8, x9, [x12, #0x8]
    5580:      	mov	w8, #0x2f               // =47
    5584:      	mov	w9, #0x6                // =6
    5588:      	add	x10, sp, #0xc8
    558c:      	ldr	x2, [x21, #0xf10]
    5590:      	ldr	x3, [x21, #0xf08]
    5594:      	blr	x9
    5598:      	b	0x46c8 <kprobe_unwind_hotspot+0x46c8>
    559c:      	str	wzr, [sp, #0x88]
    55a0:      	adrp	x0, 0x5000 <kprobe_unwind_hotspot+0x5000>
    55a4:      	mov	w8, #0x1                // =1
    55a8:      	add	x9, sp, #0x88
    55ac:      	ldr	x0, [x0]
    55b0:      	add	x1, sp, #0x88
    55b4:      	blr	x8
    55b8:      	cbz	x0, 0x5724 <kprobe_unwind_hotspot+0x5724>
    55bc:      	ldr	x8, [x0]
    55c0:      	add	x8, x8, #0x1
    55c4:      	str	x8, [x0]
    55c8:      	b	0x577c <kprobe_unwind_hotspot+0x577c>
    55cc:      	mov	w8, #0x656e             // =25966
    55d0:      	add	x11, sp, #0xc8
    55d4:      	add	x0, sp, #0xc8
    55d8:      	mov	w1, #0x1b               // =27
    55dc:      	movk	w8, #0xa, lsl #16
    55e0:      	stur	w8, [x11, #0x17]
    55e4:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    55e8:      	add	x8, x8, #0x0
    55ec:      	ldp	x9, x10, [x8]
    55f0:      	ldr	x8, [x8, #0x10]
    55f4:      	str	x9, [sp, #0xc8]
    55f8:      	mov	w9, #0x6                // =6
    55fc:      	stp	x10, x8, [x11, #0x8]
    5600:      	mov	w8, #0x1b               // =27
    5604:      	add	x10, sp, #0xc8
    5608:      	blr	x9
    560c:      	mov	w25, #0x1               // =1
    5610:      	b	0x47ac <kprobe_unwind_hotspot+0x47ac>
    5614:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5618:      	add	x8, x8, #0x0
    561c:      	add	x12, sp, #0xc8
    5620:      	ldp	x9, x10, [x8, #0x10]
    5624:      	ldr	x11, [x8, #0x20]
    5628:      	add	x0, sp, #0xc8
    562c:      	mov	w1, #0x2e               // =46
    5630:      	stp	x10, x11, [x12, #0x18]
    5634:      	ldur	x10, [x8, #0x26]
    5638:      	stur	x10, [x12, #0x26]
    563c:      	ldp	x10, x8, [x8]
    5640:      	str	x10, [sp, #0xc8]
    5644:      	stp	x8, x9, [x12, #0x8]
    5648:      	mov	w8, #0x2e               // =46
    564c:      	mov	w9, #0x6                // =6
    5650:      	add	x10, sp, #0xc8
    5654:      	ldr	w2, [sp, #0x50]
    5658:      	blr	x9
    565c:      	b	0x47e4 <kprobe_unwind_hotspot+0x47e4>
    5660:      	mov	w9, #0x616e             // =24942
    5664:      	movk	w9, #0x6974, lsl #16
    5668:      	cmp	w19, w9
    566c:      	b.eq	0x5680 <kprobe_unwind_hotspot+0x5680>
    5670:      	mov	w9, #0x6d6e             // =28014
    5674:      	movk	w9, #0x7465, lsl #16
    5678:      	cmp	w19, w9
    567c:      	b.ne	0x5784 <kprobe_unwind_hotspot+0x5784>
    5680:      	ldr	x9, [sp, #0x68]
    5684:      	ldrb	w10, [x23, #0x21]
    5688:      	add	x11, x24, w9, uxtw
    568c:      	ldr	w19, [sp, #0x7c]
    5690:      	cmp	w10, #0x0
    5694:      	csel	x9, x9, x11, eq
    5698:      	cmp	x22, x9
    569c:      	b.ne	0x58a4 <kprobe_unwind_hotspot+0x58a4>
    56a0:      	ldr	w8, [sp, #0x74]
    56a4:      	ldr	x12, [sp, #0x38]
    56a8:      	mov	w9, #0x8                // =8
    56ac:      	mov	w10, #0x70              // =112
    56b0:      	add	x11, sp, #0x88
    56b4:      	add	x0, sp, #0x88
    56b8:      	mov	w1, #0x8                // =8
    56bc:      	add	x8, x12, x8
    56c0:      	ldr	w8, [sp, #0x74]
    56c4:      	add	x2, x12, x8
    56c8:      	blr	x10
    56cc:      	cbnz	x0, 0x57f0 <kprobe_unwind_hotspot+0x57f0>
    56d0:      	ldr	x9, [sp, #0x88]
    56d4:      	ldr	x8, [sp, #0x58]
    56d8:      	cmp	x9, x8
    56dc:      	b.lo	0x57f0 <kprobe_unwind_hotspot+0x57f0>
    56e0:      	ldr	x10, [sp, #0x60]
    56e4:      	cmp	x9, x10
    56e8:      	b.hs	0x57f0 <kprobe_unwind_hotspot+0x57f0>
    56ec:      	adrp	x10, 0x5000 <kprobe_unwind_hotspot+0x5000>
    56f0:      	ldr	x10, [x10]
    56f4:      	ldr	w10, [x10]
    56f8:      	cbnz	w10, 0x5844 <kprobe_unwind_hotspot+0x5844>
    56fc:      	mov	x22, x9
    5700:      	b	0x589c <kprobe_unwind_hotspot+0x589c>
    5704:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5708:      	mov	w19, #0x7476            // =29814
    570c:      	ldr	x8, [x8]
    5710:      	movk	w19, #0x6261, lsl #16
    5714:      	ldr	w8, [x8]
    5718:      	cbnz	w8, 0x58d8 <kprobe_unwind_hotspot+0x58d8>
    571c:      	mov	x22, #0x1000000000000000 // =1152921504606846976
    5720:      	b	0x5a10 <kprobe_unwind_hotspot+0x5a10>
    5724:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5728:      	ldr	x8, [x8]
    572c:      	ldr	w8, [x8]
    5730:      	cbz	w8, 0x577c <kprobe_unwind_hotspot+0x577c>
    5734:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5738:      	add	x8, x8, #0x0
    573c:      	add	x12, sp, #0xc8
    5740:      	ldp	x9, x10, [x8, #0x10]
    5744:      	ldr	x11, [x8, #0x20]
    5748:      	add	x0, sp, #0xc8
    574c:      	mov	w1, #0x2e               // =46
    5750:      	stp	x10, x11, [x12, #0x18]
    5754:      	ldur	x10, [x8, #0x26]
    5758:      	stur	x10, [x12, #0x26]
    575c:      	ldp	x10, x8, [x8]
    5760:      	str	x10, [sp, #0xc8]
    5764:      	stp	x8, x9, [x12, #0x8]
    5768:      	mov	w8, #0x2e               // =46
    576c:      	mov	w9, #0x6                // =6
    5770:      	add	x10, sp, #0xc8
    5774:      	ldr	w2, [sp, #0x88]
    5778:      	blr	x9
    577c:      	ldrh	w25, [x25, #0x20]
    5780:      	b	0x47ac <kprobe_unwind_hotspot+0x47ac>
    5784:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5788:      	ldr	x23, [x21, #0xf00]
    578c:      	ldr	x8, [x8]
    5790:      	ldr	w8, [x8]
    5794:      	tbnz	x23, #0x3f, 0x5914 <kprobe_unwind_hotspot+0x5914>
    5798:      	cbz	w8, 0x57e0 <kprobe_unwind_hotspot+0x57e0>
    579c:      	mov	w8, #0x6874             // =26740
    57a0:      	add	x11, sp, #0xc8
    57a4:      	add	x0, sp, #0xc8
    57a8:      	mov	w1, #0x24               // =36
    57ac:      	movk	w8, #0xa, lsl #16
    57b0:      	str	w8, [sp, #0xe8]
    57b4:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    57b8:      	add	x8, x8, #0x0
    57bc:      	ldp	x9, x10, [x8]
    57c0:      	str	x9, [sp, #0xc8]
    57c4:      	ldp	x9, x8, [x8, #0x10]
    57c8:      	stp	x10, x9, [x11, #0x8]
    57cc:      	str	x8, [x11, #0x18]
    57d0:      	mov	w8, #0x24               // =36
    57d4:      	mov	w9, #0x6                // =6
    57d8:      	add	x10, sp, #0xc8
    57dc:      	blr	x9
    57e0:      	ldr	w8, [sp, #0x78]
    57e4:      	mov	x22, xzr
    57e8:      	cbnz	w8, 0x5a70 <kprobe_unwind_hotspot+0x5a70>
    57ec:      	b	0x59fc <kprobe_unwind_hotspot+0x59fc>
    57f0:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    57f4:      	ldr	x8, [x8]
    57f8:      	ldr	w8, [x8]
    57fc:      	cbz	w8, 0x58a0 <kprobe_unwind_hotspot+0x58a0>
    5800:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5804:      	add	x8, x8, #0x0
    5808:      	add	x13, sp, #0xc8
    580c:      	ldp	x9, x10, [x8, #0x10]
    5810:      	ldp	x11, x12, [x8, #0x20]
    5814:      	add	x0, sp, #0xc8
    5818:      	mov	w1, #0x30               // =48
    581c:      	str	x12, [x13, #0x28]
    5820:      	stp	x10, x11, [x13, #0x18]
    5824:      	ldp	x10, x8, [x8]
    5828:      	str	x10, [sp, #0xc8]
    582c:      	stp	x8, x9, [x13, #0x8]
    5830:      	mov	w8, #0x30               // =48
    5834:      	mov	w9, #0x6                // =6
    5838:      	add	x10, sp, #0xc8
    583c:      	blr	x9
    5840:      	b	0x58a0 <kprobe_unwind_hotspot+0x58a0>
    5844:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5848:      	add	x8, x8, #0x0
    584c:      	add	x13, sp, #0xc8
    5850:      	ldp	x9, x10, [x8, #0x20]
    5854:      	ldp	x11, x12, [x8, #0x30]
    5858:      	add	x0, sp, #0xc8
    585c:      	mov	w1, #0x40               // =64
    5860:      	str	x12, [x13, #0x38]
    5864:      	stp	x10, x11, [x13, #0x28]
    5868:      	ldp	x10, x11, [x8]
    586c:      	str	x10, [sp, #0xc8]
    5870:      	ldp	x10, x8, [x8, #0x10]
    5874:      	stp	x11, x10, [x13, #0x8]
    5878:      	add	x10, sp, #0xc8
    587c:      	stp	x8, x9, [x13, #0x18]
    5880:      	mov	w8, #0x40               // =64
    5884:      	mov	w9, #0x6                // =6
    5888:      	ldr	x2, [sp, #0x88]
    588c:      	ldr	w3, [sp, #0x74]
    5890:      	blr	x9
    5894:      	ldr	x22, [sp, #0x88]
    5898:      	ldr	x8, [sp, #0x58]
    589c:      	sub	w29, w22, w8
    58a0:      	ldr	x8, [sp, #0x58]
    58a4:      	ldrh	w9, [sp, #0x80]
    58a8:      	add	x8, x8, x9
    58ac:      	cmp	x22, x8
    58b0:      	b.hs	0x5980 <kprobe_unwind_hotspot+0x5980>
    58b4:      	sub	x8, x8, #0x4
    58b8:      	cmp	x22, x8
    58bc:      	b.ne	0x5a0c <kprobe_unwind_hotspot+0x5a0c>
    58c0:      	ldr	w8, [sp, #0x78]
    58c4:      	ldr	x9, [sp, #0x38]
    58c8:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    58cc:      	add	x9, x9, x8
    58d0:      	str	x9, [sp, #0x38]
    58d4:      	b	0x5a10 <kprobe_unwind_hotspot+0x5a10>
    58d8:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    58dc:      	add	x8, x8, #0x0
    58e0:      	add	x0, sp, #0xc8
    58e4:      	ldp	x9, x10, [x8]
    58e8:      	ldr	x8, [x8, #0x10]
    58ec:      	mov	w1, #0x18               // =24
    58f0:      	str	x9, [sp, #0xc8]
    58f4:      	add	x9, sp, #0xc8
    58f8:      	stp	x10, x8, [x9, #0x8]
    58fc:      	mov	w8, #0x18               // =24
    5900:      	mov	w9, #0x6                // =6
    5904:      	add	x10, sp, #0xc8
    5908:      	blr	x9
    590c:      	mov	x22, #0x1000000000000000 // =1152921504606846976
    5910:      	b	0x5a10 <kprobe_unwind_hotspot+0x5a10>
    5914:      	cbz	w8, 0x5960 <kprobe_unwind_hotspot+0x5960>
    5918:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    591c:      	add	x8, x8, #0x0
    5920:      	add	x13, sp, #0xc8
    5924:      	strb	wzr, [sp, #0xf8]
    5928:      	ldp	x9, x10, [x8, #0x10]
    592c:      	add	x0, sp, #0xc8
    5930:      	ldp	x11, x12, [x8, #0x20]
    5934:      	mov	w1, #0x31               // =49
    5938:      	mov	x2, x23
    593c:      	str	x12, [x13, #0x28]
    5940:      	stp	x10, x11, [x13, #0x18]
    5944:      	ldp	x10, x8, [x8]
    5948:      	str	x10, [sp, #0xc8]
    594c:      	add	x10, sp, #0xc8
    5950:      	stp	x8, x9, [x13, #0x8]
    5954:      	mov	w8, #0x31               // =49
    5958:      	mov	w9, #0x6                // =6
    595c:      	blr	x9
    5960:      	mov	x22, xzr
    5964:      	tbnz	x23, #0x3e, 0x59fc <kprobe_unwind_hotspot+0x59fc>
    5968:      	ldr	x9, [sp, #0x38]
    596c:      	lsr	x8, x23, #53
    5970:      	and	x8, x8, #0x1f8
    5974:      	add	x9, x8, x9
    5978:      	str	x9, [sp, #0x38]
    597c:      	b	0x5a10 <kprobe_unwind_hotspot+0x5a10>
    5980:      	ldp	x8, x9, [sp, #0x30]
    5984:      	subs	x2, x8, x9
    5988:      	b.lo	0x5a20 <kprobe_unwind_hotspot+0x5a20>
    598c:      	ldr	w8, [sp, #0x78]
    5990:      	ldp	x9, x10, [sp, #0x30]
    5994:      	add	x8, x10, x8
    5998:      	add	x8, x8, #0x30
    599c:      	cmp	x9, x8
    59a0:      	b.hs	0x5a20 <kprobe_unwind_hotspot+0x5a20>
    59a4:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    59a8:      	ldr	x8, [x8]
    59ac:      	ldr	w8, [x8]
    59b0:      	cbz	w8, 0x59f8 <kprobe_unwind_hotspot+0x59f8>
    59b4:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    59b8:      	add	x8, x8, #0x0
    59bc:      	add	x11, sp, #0xc8
    59c0:      	ldp	x9, x10, [x8, #0x18]
    59c4:      	add	x0, sp, #0xc8
    59c8:      	mov	w1, #0x2f               // =47
    59cc:      	stp	x9, x10, [x11, #0x18]
    59d0:      	ldur	x10, [x8, #0x27]
    59d4:      	stur	x10, [x11, #0x27]
    59d8:      	ldr	x10, [x8]
    59dc:      	ldp	x8, x9, [x8, #0x8]
    59e0:      	str	x10, [sp, #0xc8]
    59e4:      	stp	x8, x9, [x11, #0x8]
    59e8:      	mov	w8, #0x2f               // =47
    59ec:      	mov	w9, #0x6                // =6
    59f0:      	add	x10, sp, #0xc8
    59f4:      	blr	x9
    59f8:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    59fc:      	ldr	x9, [sp, #0x30]
    5a00:      	mov	w8, #0x10               // =16
    5a04:      	str	w8, [sp, #0x78]
    5a08:      	b	0x5a6c <kprobe_unwind_hotspot+0x5a6c>
    5a0c:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    5a10:      	ldrb	w8, [x21, #0xf21]
    5a14:      	cbnz	w8, 0x7bc <kprobe_unwind_hotspot+0x7bc>
    5a18:      	ldr	x25, [x21, #0xee8]
    5a1c:      	b	0x5af8 <kprobe_unwind_hotspot+0x5af8>
    5a20:      	sub	x2, x22, #0x8
    5a24:      	mov	w8, #0x8                // =8
    5a28:      	mov	w9, #0x70               // =112
    5a2c:      	add	x10, sp, #0xc8
    5a30:      	add	x0, sp, #0xc8
    5a34:      	mov	w1, #0x8                // =8
    5a38:      	blr	x9
    5a3c:      	ldr	x8, [sp, #0xc8]
    5a40:      	mov	x9, #0x27ff             // =10239
    5a44:      	mov	x22, #0x3000000000000000 // =3458764513820540928
    5a48:      	movk	x9, #0xa9bf, lsl #16
    5a4c:      	movk	x9, #0x100, lsl #32
    5a50:      	movk	x9, #0xd63f, lsl #48
    5a54:      	cmp	x8, x9
    5a58:      	ldr	x9, [sp, #0x38]
    5a5c:      	ccmp	x0, #0x0, #0x0, eq
    5a60:      	add	x8, x9, #0x10
    5a64:      	csel	x9, x8, x9, eq
    5a68:      	ldr	w8, [sp, #0x78]
    5a6c:      	str	x9, [sp, #0x38]
    5a70:      	ldr	x9, [sp, #0x38]
    5a74:      	add	x10, sp, #0x88
    5a78:      	add	x0, sp, #0x88
    5a7c:      	mov	w1, #0x10               // =16
    5a80:      	add	x9, x9, w8, uxtw
    5a84:      	mov	w8, #0x10               // =16
    5a88:      	str	x9, [sp, #0x38]
    5a8c:      	sub	x2, x9, #0x10
    5a90:      	mov	w9, #0x70               // =112
    5a94:      	blr	x9
    5a98:      	ldr	w8, [sp, #0x78]
    5a9c:      	ldr	x25, [sp, #0x90]
    5aa0:      	cmp	w8, #0x10
    5aa4:      	b.lo	0x5af8 <kprobe_unwind_hotspot+0x5af8>
    5aa8:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5aac:      	ldr	x8, [x8]
    5ab0:      	ldr	w8, [x8]
    5ab4:      	cbz	w8, 0x5af0 <kprobe_unwind_hotspot+0x5af0>
    5ab8:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5abc:      	add	x8, x8, #0x0
    5ac0:      	add	x0, sp, #0xc8
    5ac4:      	ldp	x9, x10, [x8]
    5ac8:      	ldur	x8, [x8, #0xd]
    5acc:      	mov	w1, #0x15               // =21
    5ad0:      	str	x9, [sp, #0xc8]
    5ad4:      	add	x9, sp, #0xc8
    5ad8:      	str	x10, [x9, #0x8]
    5adc:      	stur	x8, [x9, #0xd]
    5ae0:      	mov	w8, #0x15               // =21
    5ae4:      	mov	w9, #0x6                // =6
    5ae8:      	add	x10, sp, #0xc8
    5aec:      	blr	x9
    5af0:      	ldr	x8, [sp, #0x88]
    5af4:      	str	x8, [sp, #0x30]
    5af8:      	ldr	w8, [x21, #0x2c0]
    5afc:      	cmp	w8, #0x7e
    5b00:      	b.hi	0x1508 <kprobe_unwind_hotspot+0x1508>
    5b04:      	mov	w11, w19
    5b08:      	and	x10, x22, #0x3000000000000000
    5b0c:      	ldrb	w9, [x21, #0xf20]
    5b10:      	orr	x11, x11, x29, lsl #32
    5b14:      	orr	x10, x11, x10
    5b18:      	add	w11, w8, #0x1
    5b1c:      	str	w11, [x21, #0x2c0]
    5b20:      	mov	w11, #0x18              // =24
    5b24:      	umaddl	x8, w8, w11, x21
    5b28:      	str	x10, [x8, #0x2d8]
    5b2c:      	mov	w10, #0x5               // =5
    5b30:      	str	x24, [x8, #0x2d0]
    5b34:      	strb	w9, [x8, #0x2e1]
    5b38:      	strh	wzr, [x8, #0x2e6]
    5b3c:      	strb	w10, [x8, #0x2e0]
    5b40:      	add	x10, x8, #0x2d0
    5b44:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5b48:      	stur	wzr, [x10, #0x12]
    5b4c:      	ldr	x8, [x8]
    5b50:      	ldr	w8, [x8]
    5b54:      	cbz	w8, 0x5ba4 <kprobe_unwind_hotspot+0x5ba4>
    5b58:      	mov	w8, #0x786c             // =30828
    5b5c:      	add	x11, sp, #0xc8
    5b60:      	add	x0, sp, #0xc8
    5b64:      	mov	w1, #0x24               // =36
    5b68:      	mov	x2, x25
    5b6c:      	movk	w8, #0xa, lsl #16
    5b70:      	str	w8, [sp, #0xe8]
    5b74:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5b78:      	add	x8, x8, #0x0
    5b7c:      	ldp	x9, x10, [x8]
    5b80:      	str	x9, [sp, #0xc8]
    5b84:      	ldp	x9, x8, [x8, #0x10]
    5b88:      	stp	x10, x9, [x11, #0x8]
    5b8c:      	str	x8, [x11, #0x18]
    5b90:      	mov	w8, #0x24               // =36
    5b94:      	mov	w9, #0x6                // =6
    5b98:      	add	x10, sp, #0xc8
    5b9c:      	ldp	x4, x3, [sp, #0x30]
    5ba0:      	blr	x9
    5ba4:      	ldp	x8, x9, [sp, #0x30]
    5ba8:      	adrp	x0, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5bac:      	add	x1, sp, #0x88
    5bb0:      	str	x25, [x21, #0xed0]
    5bb4:      	str	x8, [x21, #0xee0]
    5bb8:      	mov	w8, #0x101              // =257
    5bbc:      	str	x9, [x21, #0xed8]
    5bc0:      	add	x9, sp, #0x88
    5bc4:      	strh	w8, [x21, #0xf20]
    5bc8:      	mov	w8, #0x2a               // =42
    5bcc:      	str	w8, [sp, #0x88]
    5bd0:      	mov	w8, #0x1                // =1
    5bd4:      	ldr	x0, [x0]
    5bd8:      	blr	x8
    5bdc:      	cbz	x0, 0x5bf0 <kprobe_unwind_hotspot+0x5bf0>
    5be0:      	ldr	x8, [x0]
    5be4:      	add	x8, x8, #0x1
    5be8:      	str	x8, [x0]
    5bec:      	b	0x5c48 <kprobe_unwind_hotspot+0x5c48>
    5bf0:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5bf4:      	ldr	x8, [x8]
    5bf8:      	ldr	w8, [x8]
    5bfc:      	cbz	w8, 0x5c54 <kprobe_unwind_hotspot+0x5c54>
    5c00:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5c04:      	add	x8, x8, #0x0
    5c08:      	add	x12, sp, #0xc8
    5c0c:      	ldp	x9, x10, [x8, #0x10]
    5c10:      	ldr	x11, [x8, #0x20]
    5c14:      	add	x0, sp, #0xc8
    5c18:      	mov	w1, #0x2e               // =46
    5c1c:      	stp	x10, x11, [x12, #0x18]
    5c20:      	ldur	x10, [x8, #0x26]
    5c24:      	stur	x10, [x12, #0x26]
    5c28:      	ldp	x10, x8, [x8]
    5c2c:      	str	x10, [sp, #0xc8]
    5c30:      	stp	x8, x9, [x12, #0x8]
    5c34:      	mov	w8, #0x2e               // =46
    5c38:      	mov	w9, #0x6                // =6
    5c3c:      	add	x10, sp, #0xc8
    5c40:      	ldr	w2, [sp, #0x88]
    5c44:      	blr	x9
    5c48:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5c4c:      	ldr	x8, [x8]
    5c50:      	ldr	w8, [x8]
    5c54:      	ldr	x29, [x21, #0xed0]
    5c58:      	cbz	x29, 0x5eac <kprobe_unwind_hotspot+0x5eac>
    5c5c:      	cbz	w8, 0x5cac <kprobe_unwind_hotspot+0x5cac>
    5c60:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5c64:      	add	x8, x8, #0x0
    5c68:      	add	x13, sp, #0xc8
    5c6c:      	strb	wzr, [sp, #0xf8]
    5c70:      	ldp	x9, x10, [x8, #0x10]
    5c74:      	add	x0, sp, #0xc8
    5c78:      	ldp	x11, x12, [x8, #0x20]
    5c7c:      	mov	w1, #0x31               // =49
    5c80:      	str	x12, [x13, #0x28]
    5c84:      	stp	x10, x11, [x13, #0x18]
    5c88:      	ldp	x10, x8, [x8]
    5c8c:      	str	x10, [sp, #0xc8]
    5c90:      	stp	x8, x9, [x13, #0x8]
    5c94:      	mov	w8, #0x31               // =49
    5c98:      	mov	w9, #0x6                // =6
    5c9c:      	add	x10, sp, #0xc8
    5ca0:      	ldr	w2, [x21, #0x2c0]
    5ca4:      	blr	x9
    5ca8:      	ldr	x29, [x21, #0xed0]
    5cac:      	lsr	x8, x29, #56
    5cb0:      	cbnz	x8, 0x1644 <kprobe_unwind_hotspot+0x1644>
    5cb4:      	cmp	x29, #0x1, lsl #12      // =0x1000
    5cb8:      	b.lo	0x1798 <kprobe_unwind_hotspot+0x1798>
    5cbc:      	ldr	w8, [x21]
    5cc0:      	mov	w9, #0x60               // =96
    5cc4:      	add	x1, sp, #0x50
    5cc8:      	mov	x0, x20
    5ccc:      	rev	w8, w8
    5cd0:      	stp	w9, w8, [sp, #0x50]
    5cd4:      	rev	x8, x29
    5cd8:      	add	x9, sp, #0x50
    5cdc:      	str	x8, [sp, #0x58]
    5ce0:      	mov	w8, #0x1                // =1
    5ce4:      	blr	x8
    5ce8:      	cbz	x0, 0x5ee0 <kprobe_unwind_hotspot+0x5ee0>
    5cec:      	ldr	x8, [x0, #0x8]
    5cf0:      	and	x9, x8, #0xffffffffffffff
    5cf4:      	lsr	x25, x8, #56
    5cf8:      	str	x9, [x21, #0xf10]
    5cfc:      	ldr	x8, [x0]
    5d00:      	str	x8, [x21, #0xf00]
    5d04:      	sub	x8, x29, x9
    5d08:      	str	x8, [x21, #0xf08]
    5d0c:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5d10:      	ldr	x8, [x8]
    5d14:      	ldr	w8, [x8]
    5d18:      	cbz	w8, 0x5dcc <kprobe_unwind_hotspot+0x5dcc>
    5d1c:      	mov	w8, #0xa                // =10
    5d20:      	add	x13, sp, #0xc8
    5d24:      	add	x0, sp, #0xc8
    5d28:      	strh	w8, [sp, #0xf8]
    5d2c:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5d30:      	add	x8, x8, #0x0
    5d34:      	mov	w1, #0x32               // =50
    5d38:      	ldp	x9, x10, [x8, #0x10]
    5d3c:      	ldp	x11, x12, [x8, #0x20]
    5d40:      	mov	x2, x29
    5d44:      	mov	w4, w25
    5d48:      	str	x12, [x13, #0x28]
    5d4c:      	stp	x10, x11, [x13, #0x18]
    5d50:      	ldp	x10, x8, [x8]
    5d54:      	str	x10, [sp, #0xc8]
    5d58:      	add	x10, sp, #0xc8
    5d5c:      	stp	x8, x9, [x13, #0x8]
    5d60:      	mov	w8, #0x32               // =50
    5d64:      	mov	w9, #0x6                // =6
    5d68:      	ldr	x3, [x21, #0xf00]
    5d6c:      	blr	x9
    5d70:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5d74:      	ldr	x8, [x8]
    5d78:      	ldr	w8, [x8]
    5d7c:      	cbz	w8, 0x5dcc <kprobe_unwind_hotspot+0x5dcc>
    5d80:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5d84:      	add	x8, x8, #0x0
    5d88:      	add	x12, sp, #0xc8
    5d8c:      	ldp	x9, x10, [x8, #0x10]
    5d90:      	ldr	x11, [x8, #0x20]
    5d94:      	add	x0, sp, #0xc8
    5d98:      	mov	w1, #0x2f               // =47
    5d9c:      	stp	x10, x11, [x12, #0x18]
    5da0:      	ldur	x10, [x8, #0x27]
    5da4:      	stur	x10, [x12, #0x27]
    5da8:      	ldp	x10, x8, [x8]
    5dac:      	str	x10, [sp, #0xc8]
    5db0:      	stp	x8, x9, [x12, #0x8]
    5db4:      	mov	w8, #0x2f               // =47
    5db8:      	mov	w9, #0x6                // =6
    5dbc:      	add	x10, sp, #0xc8
    5dc0:      	ldr	x2, [x21, #0xf10]
    5dc4:      	ldr	x3, [x21, #0xf08]
    5dc8:      	blr	x9
    5dcc:      	cmp	w25, #0x1
    5dd0:      	b.ne	0x6074 <kprobe_unwind_hotspot+0x6074>
    5dd4:      	ldr	x8, [x21, #0xf00]
    5dd8:      	adrp	x0, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5ddc:      	ldr	x19, [x21, #0xf08]
    5de0:      	mov	w9, #0x1                // =1
    5de4:      	add	x1, sp, #0x50
    5de8:      	mov	w25, #0x1               // =1
    5dec:      	str	x8, [sp, #0x50]
    5df0:      	add	x8, sp, #0x50
    5df4:      	ldr	x0, [x0]
    5df8:      	blr	x9
    5dfc:      	cbz	x0, 0x5f9c <kprobe_unwind_hotspot+0x5f9c>
    5e00:      	ldr	x8, [x0]
    5e04:      	mov	x23, x0
    5e08:      	cmp	x8, x19
    5e0c:      	b.hi	0x5e1c <kprobe_unwind_hotspot+0x5e1c>
    5e10:      	ldr	x8, [x23, #0x8]
    5e14:      	cmp	x8, x19
    5e18:      	b.hs	0x5e34 <kprobe_unwind_hotspot+0x5e34>
    5e1c:      	ldr	x8, [x23, #0x10]
    5e20:      	cmp	x8, x19
    5e24:      	b.hi	0x5ea4 <kprobe_unwind_hotspot+0x5ea4>
    5e28:      	ldr	x8, [x23, #0x18]
    5e2c:      	cmp	x8, x19
    5e30:      	b.lo	0x5ea4 <kprobe_unwind_hotspot+0x5ea4>
    5e34:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5e38:      	ldr	x8, [x8]
    5e3c:      	ldr	w8, [x8]
    5e40:      	cbz	w8, 0x5e84 <kprobe_unwind_hotspot+0x5e84>
    5e44:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5e48:      	add	x8, x8, #0x0
    5e4c:      	add	x11, sp, #0xc8
    5e50:      	ldp	x9, x10, [x8]
    5e54:      	add	x0, sp, #0xc8
    5e58:      	mov	w1, #0x1e               // =30
    5e5c:      	str	x9, [sp, #0xc8]
    5e60:      	ldr	x9, [x8, #0x10]
    5e64:      	ldur	x8, [x8, #0x16]
    5e68:      	stp	x10, x9, [x11, #0x8]
    5e6c:      	mov	w9, #0x6                // =6
    5e70:      	stur	x8, [x11, #0x16]
    5e74:      	mov	w8, #0x1e               // =30
    5e78:      	add	x10, sp, #0xc8
    5e7c:      	ldrh	w2, [x23, #0x20]
    5e80:      	blr	x9
    5e84:      	ldrh	w8, [x23, #0x20]
    5e88:      	ldr	w9, [x21, #0x1370]
    5e8c:      	lsr	w8, w9, w8
    5e90:      	tbz	w8, #0x0, 0x5fa0 <kprobe_unwind_hotspot+0x5fa0>
    5e94:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5e98:      	ldr	x8, [x8]
    5e9c:      	ldr	w8, [x8]
    5ea0:      	cbnz	w8, 0x5fd0 <kprobe_unwind_hotspot+0x5fd0>
    5ea4:      	mov	w25, #0x1               // =1
    5ea8:      	b	0x6074 <kprobe_unwind_hotspot+0x6074>
    5eac:      	cbnz	w8, 0x5f04 <kprobe_unwind_hotspot+0x5f04>
    5eb0:      	mov	w8, #0x1                // =1
    5eb4:      	mov	w25, wzr
    5eb8:      	str	w8, [x21, #0xf18]
    5ebc:      	mov	w8, #0xfad              // =4013
    5ec0:      	adrp	x24, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5ec4:      	adrp	x19, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5ec8:      	adrp	x23, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5ecc:      	ldr	x22, [sp, #0x138]
    5ed0:      	ldr	x24, [x24]
    5ed4:      	ldr	x19, [x19]
    5ed8:      	ldr	x23, [x23]
    5edc:      	b	0x2b4 <kprobe_unwind_hotspot+0x2b4>
    5ee0:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5ee4:      	ldr	x8, [x8]
    5ee8:      	ldr	w8, [x8]
    5eec:      	cbnz	w8, 0x5f4c <kprobe_unwind_hotspot+0x5f4c>
    5ef0:      	mov	w8, #0xc                // =12
    5ef4:      	mov	w25, wzr
    5ef8:      	str	w8, [x21, #0xf18]
    5efc:      	mov	w8, #0xfac              // =4012
    5f00:      	b	0x5ec0 <kprobe_unwind_hotspot+0x5ec0>
    5f04:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5f08:      	add	x8, x8, #0x0
    5f0c:      	add	x13, sp, #0xc8
    5f10:      	strb	wzr, [sp, #0xf8]
    5f14:      	ldp	x9, x10, [x8, #0x10]
    5f18:      	add	x0, sp, #0xc8
    5f1c:      	ldp	x11, x12, [x8, #0x20]
    5f20:      	mov	w1, #0x31               // =49
    5f24:      	str	x12, [x13, #0x28]
    5f28:      	stp	x10, x11, [x13, #0x18]
    5f2c:      	ldp	x10, x8, [x8]
    5f30:      	str	x10, [sp, #0xc8]
    5f34:      	stp	x8, x9, [x13, #0x8]
    5f38:      	mov	w8, #0x31               // =49
    5f3c:      	mov	w9, #0x6                // =6
    5f40:      	add	x10, sp, #0xc8
    5f44:      	blr	x9
    5f48:      	b	0x5eb0 <kprobe_unwind_hotspot+0x5eb0>
    5f4c:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5f50:      	add	x8, x8, #0x0
    5f54:      	add	x13, sp, #0xc8
    5f58:      	strb	wzr, [sp, #0x100]
    5f5c:      	ldp	x9, x10, [x8, #0x20]
    5f60:      	add	x0, sp, #0xc8
    5f64:      	ldp	x12, x11, [x8, #0x10]
    5f68:      	mov	w1, #0x39               // =57
    5f6c:      	mov	x2, x29
    5f70:      	stp	x11, x9, [x13, #0x18]
    5f74:      	ldr	x9, [x8, #0x30]
    5f78:      	stp	x10, x9, [x13, #0x28]
    5f7c:      	ldp	x9, x8, [x8]
    5f80:      	add	x10, sp, #0xc8
    5f84:      	str	x9, [sp, #0xc8]
    5f88:      	stp	x8, x12, [x13, #0x8]
    5f8c:      	mov	w8, #0x39               // =57
    5f90:      	mov	w9, #0x6                // =6
    5f94:      	blr	x9
    5f98:      	b	0x5ef0 <kprobe_unwind_hotspot+0x5ef0>
    5f9c:      	b	0x6074 <kprobe_unwind_hotspot+0x6074>
    5fa0:      	str	wzr, [sp, #0x88]
    5fa4:      	adrp	x0, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5fa8:      	mov	w8, #0x1                // =1
    5fac:      	add	x9, sp, #0x88
    5fb0:      	ldr	x0, [x0]
    5fb4:      	add	x1, sp, #0x88
    5fb8:      	blr	x8
    5fbc:      	cbz	x0, 0x6018 <kprobe_unwind_hotspot+0x6018>
    5fc0:      	ldr	x8, [x0]
    5fc4:      	add	x8, x8, #0x1
    5fc8:      	str	x8, [x0]
    5fcc:      	b	0x6070 <kprobe_unwind_hotspot+0x6070>
    5fd0:      	mov	w8, #0x656e             // =25966
    5fd4:      	add	x11, sp, #0xc8
    5fd8:      	add	x0, sp, #0xc8
    5fdc:      	mov	w1, #0x1b               // =27
    5fe0:      	movk	w8, #0xa, lsl #16
    5fe4:      	stur	w8, [x11, #0x17]
    5fe8:      	adrp	x8, 0x5000 <kprobe_unwind_hotspot+0x5000>
    5fec:      	add	x8, x8, #0x0
    5ff0:      	ldp	x9, x10, [x8]
    5ff4:      	ldr	x8, [x8, #0x10]
    5ff8:      	str	x9, [sp, #0xc8]
    5ffc:      	mov	w9, #0x6                // =6
    6000:      	stp	x10, x8, [x11, #0x8]
    6004:      	mov	w8, #0x1b               // =27
    6008:      	add	x10, sp, #0xc8
    600c:      	blr	x9
    6010:      	mov	w25, #0x1               // =1
    6014:      	b	0x6074 <kprobe_unwind_hotspot+0x6074>
    6018:      	adrp	x8, 0x6000 <kprobe_unwind_hotspot+0x6000>
    601c:      	ldr	x8, [x8]
    6020:      	ldr	w8, [x8]
    6024:      	cbz	w8, 0x6070 <kprobe_unwind_hotspot+0x6070>
    6028:      	adrp	x8, 0x6000 <kprobe_unwind_hotspot+0x6000>
    602c:      	add	x8, x8, #0x0
    6030:      	add	x12, sp, #0xc8
    6034:      	ldp	x9, x10, [x8, #0x10]
    6038:      	ldr	x11, [x8, #0x20]
    603c:      	add	x0, sp, #0xc8
    6040:      	mov	w1, #0x2e               // =46
    6044:      	stp	x10, x11, [x12, #0x18]
    6048:      	ldur	x10, [x8, #0x26]
    604c:      	stur	x10, [x12, #0x26]
    6050:      	ldp	x10, x8, [x8]
    6054:      	str	x10, [sp, #0xc8]
    6058:      	stp	x8, x9, [x12, #0x8]
    605c:      	mov	w8, #0x2e               // =46
    6060:      	mov	w9, #0x6                // =6
    6064:      	add	x10, sp, #0xc8
    6068:      	ldr	w2, [sp, #0x88]
    606c:      	blr	x9
    6070:      	ldrh	w25, [x23, #0x20]
    6074:      	mov	w8, wzr
    6078:      	b	0x5ec0 <kprobe_unwind_hotspot+0x5ec0>
