
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_fexit_v511.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	cbz	x2, 0x8c <native_bpf_strncasestr+0x8c>
       4:      	mov	x8, x0
       8:      	mov	x0, xzr
       c:      	mov	x9, x2
      10:      	b	0x34 <native_bpf_strncasestr+0x34>
      14:      	nop
      18:      	nop
      1c:      	nop
      20:      	add	x0, x0, #0x1
      24:      	sub	x9, x9, #0x1
      28:      	add	x8, x8, #0x1
      2c:      	cmp	x0, x2
      30:      	b.eq	0x8c <native_bpf_strncasestr+0x8c>
      34:      	mov	x10, xzr
      38:      	nop
      3c:      	nop
      40:      	cmp	x9, x10
      44:      	b.eq	0x20 <native_bpf_strncasestr+0x20>
      48:      	ldrb	w11, [x1, x10]
      4c:      	cbz	w11, 0x90 <native_bpf_strncasestr+0x90>
      50:      	ldrb	w12, [x8, x10]
      54:      	sub	w13, w12, #0x41
      58:      	orr	w14, w12, #0x20
      5c:      	cmp	w13, #0x1a
      60:      	sub	w13, w11, #0x41
      64:      	csel	w12, w14, w12, lo
      68:      	orr	w14, w11, #0x20
      6c:      	cmp	w13, #0x1a
      70:      	csel	w11, w14, w11, lo
      74:      	cmp	w12, w11
      78:      	b.ne	0x20 <native_bpf_strncasestr+0x20>
      7c:      	cmp	x10, #0x63
      80:      	add	x10, x10, #0x1
      84:      	b.lo	0x40 <native_bpf_strncasestr+0x40>
      88:      	b	0x20 <native_bpf_strncasestr+0x20>
      8c:      	mov	w0, #-0x1               // =-1
      90:      	ret

Disassembly of section fexit/generic_fexit_tail:

0000000000000000 <generic_fexit_filter_arg>:
       0:      	sub	sp, sp, #0xf0
       4:      	str	x29, [sp, #0xa0]
       8:      	stp	x30, x25, [sp, #0xb0]
       c:      	stp	x24, x23, [sp, #0xc0]
      10:      	stp	x22, x21, [sp, #0xd0]
      14:      	stp	x20, x19, [sp, #0xe0]
      18:      	mov	x23, x0
      1c:      	str	wzr, [sp, #0xa8]
      20:      	adrp	x0, 0x0 <generic_fexit_filter_arg>
      24:      	mov	w8, #0x1                // =1
      28:      	ldr	x0, [x0]
      2c:      	add	x9, sp, #0xa8
      30:      	add	x1, sp, #0xa8
      34:      	blr	x8
      38:      	cbz	x0, 0x337c <generic_fexit_filter_arg+0x337c>
      3c:      	mov	w8, #0x5ec1             // =24257
      40:      	mov	x20, x0
      44:      	add	x19, x0, x8
      48:      	mov	w8, #0x5ef8             // =24312
      4c:      	add	x1, x0, x8
      50:      	adrp	x0, 0x0 <generic_fexit_filter_arg>
      54:      	ldur	w21, [x19, #0x3f]
      58:      	mov	w8, #0x1                // =1
      5c:      	ldr	x0, [x0]
      60:      	blr	x8
      64:      	cbz	x0, 0x3360 <generic_fexit_filter_arg+0x3360>
      68:      	ldrb	w8, [x19, #0x1f]
      6c:      	cbz	w8, 0x3360 <generic_fexit_filter_arg+0x3360>
      70:      	and	x8, x21, #0x7
      74:      	mov	w10, #0x5ec1            // =24257
      78:      	str	x21, [sp, #0x58]
      7c:      	add	x9, x20, x8
      80:      	ldrb	w9, [x9, x10]
      84:      	cbz	w9, 0xc4 <generic_fexit_filter_arg+0xc4>
      88:      	lsl	w8, w8, #2
      8c:      	add	x8, x8, #0x4
      90:      	ldr	w9, [x8, x0]
      94:      	add	x8, x8, x9
      98:      	add	x12, x8, #0x4
      9c:      	and	x8, x12, #0x3ff
      a0:      	add	x16, x0, x8
      a4:      	str	x8, [sp, #0x40]
      a8:      	ldr	w8, [x16]
      ac:      	cmp	w8, #0x19
      b0:      	b.hs	0x110 <generic_fexit_filter_arg+0x110>
      b4:      	ldr	x8, [sp, #0x40]
      b8:      	cmp	w8, #0x1
      bc:      	b.eq	0x3360 <generic_fexit_filter_arg+0x3360>
      c0:      	cbnz	w8, 0x333c <generic_fexit_filter_arg+0x333c>
      c4:      	ldr	x8, [sp, #0x58]
      c8:      	cmp	w8, #0x1
      cc:      	b.gt	0xe8 <generic_fexit_filter_arg+0xe8>
      d0:      	cmn	w8, #0x1
      d4:      	b.eq	0x339c <generic_fexit_filter_arg+0x339c>
      d8:      	cbz	w8, 0x33ac <generic_fexit_filter_arg+0x33ac>
      dc:      	cmp	w8, #0x1
      e0:      	b.eq	0x33bc <generic_fexit_filter_arg+0x33bc>
      e4:      	b	0x100 <generic_fexit_filter_arg+0x100>
      e8:      	cmp	w8, #0x2
      ec:      	b.eq	0x33cc <generic_fexit_filter_arg+0x33cc>
      f0:      	cmp	w8, #0x3
      f4:      	b.eq	0x33dc <generic_fexit_filter_arg+0x33dc>
      f8:      	cmp	w8, #0x4
      fc:      	b.eq	0x33ec <generic_fexit_filter_arg+0x33ec>
     100:      	cmp	w8, #0x4
     104:      	b.gt	0x3418 <generic_fexit_filter_arg+0x3418>
     108:      	add	w8, w8, #0x1
     10c:      	b	0x33f8 <generic_fexit_filter_arg+0x33f8>
     110:      	mov	x24, xzr
     114:      	mov	w17, #0x1               // =1
     118:      	stp	x19, x0, [sp, #0x30]
     11c:      	stp	x12, x16, [sp, #0x48]
     120:      	b	0x14c <generic_fexit_filter_arg+0x14c>
     124:      	orr	w8, w8, #0x2
     128:      	cmp	w8, #0x6
     12c:      	b.ne	0xc4 <generic_fexit_filter_arg+0xc4>
     130:      	nop
     134:      	nop
     138:      	nop
     13c:      	nop
     140:      	add	x24, x24, #0x1
     144:      	cmp	x24, #0x5
     148:      	b.eq	0xb4 <generic_fexit_filter_arg+0xb4>
     14c:      	add	x8, x16, x24, lsl #2
     150:      	ldr	w8, [x8, #0x4]
     154:      	tst	w8, #0x3ff
     158:      	b.eq	0xb4 <generic_fexit_filter_arg+0xb4>
     15c:      	add	w8, w12, w8
     160:      	and	x8, x8, #0x3ff
     164:      	add	x21, x0, x8
     168:      	ldr	w8, [x21, #0x4]
     16c:      	cmp	w8, #0x23
     170:      	b.eq	0xc4 <generic_fexit_filter_arg+0xc4>
     174:      	ldr	w9, [x21]
     178:      	cmp	w9, #0x4
     17c:      	b.hi	0xc4 <generic_fexit_filter_arg+0xc4>
     180:      	add	x10, x20, x9, lsl #2
     184:      	mov	w11, #0x5ea0            // =24224
     188:      	ldr	w10, [x10, x11]
     18c:      	cbnz	w10, 0xc4 <generic_fexit_filter_arg+0xc4>
     190:      	add	x9, x20, x9, lsl #3
     194:      	ldr	x9, [x9, #0x5e78]
     198:      	and	x9, x9, #0x7ff
     19c:      	add	x9, x20, x9
     1a0:      	add	x25, x9, #0x90
     1a4:      	ldr	w9, [x21, #0xc]
     1a8:      	cmp	w9, #0x1b
     1ac:      	b.le	0x1d0 <generic_fexit_filter_arg+0x1d0>
     1b0:      	cmp	w9, #0x25
     1b4:      	b.gt	0x200 <generic_fexit_filter_arg+0x200>
     1b8:      	sub	w10, w9, #0x1c
     1bc:      	cmp	w10, #0x9
     1c0:      	b.lo	0x244 <generic_fexit_filter_arg+0x244>
     1c4:      	cmp	w9, #0x25
     1c8:      	b.eq	0x3f8 <generic_fexit_filter_arg+0x3f8>
     1cc:      	b	0x140 <generic_fexit_filter_arg+0x140>
     1d0:      	cmp	w9, #0x9
     1d4:      	b.le	0x224 <generic_fexit_filter_arg+0x224>
     1d8:      	sub	w10, w9, #0xa
     1dc:      	cmp	w10, #0x4
     1e0:      	b.lo	0x244 <generic_fexit_filter_arg+0x244>
     1e4:      	sub	w10, w9, #0xf
     1e8:      	cmp	w10, #0x2
     1ec:      	b.lo	0x3f8 <generic_fexit_filter_arg+0x3f8>
     1f0:      	cmp	w9, #0x11
     1f4:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
     1f8:      	add	x25, x25, #0x4
     1fc:      	b	0x3f8 <generic_fexit_filter_arg+0x3f8>
     200:      	cmp	w9, #0x29
     204:      	b.gt	0x370 <generic_fexit_filter_arg+0x370>
     208:      	sub	w10, w9, #0x26
     20c:      	cmp	w10, #0x2
     210:      	b.lo	0x318 <generic_fexit_filter_arg+0x318>
     214:      	sub	w10, w9, #0x28
     218:      	cmp	w10, #0x2
     21c:      	b.lo	0x2f0 <generic_fexit_filter_arg+0x2f0>
     220:      	b	0x140 <generic_fexit_filter_arg+0x140>
     224:      	cmp	w9, #0x4
     228:      	b.gt	0x2d8 <generic_fexit_filter_arg+0x2d8>
     22c:      	cmp	w9, #0x1
     230:      	b.eq	0x244 <generic_fexit_filter_arg+0x244>
     234:      	cmp	w9, #0x2
     238:      	b.eq	0x824 <generic_fexit_filter_arg+0x824>
     23c:      	cmp	w9, #0x4
     240:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
     244:      	cmp	w9, #0xb
     248:      	b.le	0x2b8 <generic_fexit_filter_arg+0x2b8>
     24c:      	cmp	w9, #0x24
     250:      	b.hi	0x4b0 <generic_fexit_filter_arg+0x4b0>
     254:      	lsl	x10, x17, x9
     258:      	tst	x10, #0x1e00000000
     25c:      	b.ne	0x348 <generic_fexit_filter_arg+0x348>
     260:      	lsl	x10, x17, x9
     264:      	tst	x10, #0x60000000
     268:      	b.ne	0x66c <generic_fexit_filter_arg+0x66c>
     26c:      	lsl	x10, x17, x9
     270:      	tst	x10, #0x180000000
     274:      	b.eq	0x4b0 <generic_fexit_filter_arg+0x4b0>
     278:      	cmp	w8, #0x20
     27c:      	b.hi	0xc4 <generic_fexit_filter_arg+0xc4>
     280:      	lsl	x9, x17, x8
     284:      	mov	w10, #0x101e            // =4126
     288:      	tst	x9, x10
     28c:      	b.eq	0xcb8 <generic_fexit_filter_arg+0xcb8>
     290:      	ldr	w9, [x21, #0x10]
     294:      	cmp	w8, #0x2
     298:      	b.le	0x1230 <generic_fexit_filter_arg+0x1230>
     29c:      	sub	w10, w8, #0x3
     2a0:      	cmp	w10, #0x2
     2a4:      	b.hs	0x1844 <generic_fexit_filter_arg+0x1844>
     2a8:      	ldrb	w10, [x25]
     2ac:      	cmp	w9, w10
     2b0:      	b.ne	0x19d0 <generic_fexit_filter_arg+0x19d0>
     2b4:      	b	0x31dc <generic_fexit_filter_arg+0x31dc>
     2b8:      	sub	w10, w9, #0xa
     2bc:      	cmp	w10, #0x2
     2c0:      	b.lo	0x898 <generic_fexit_filter_arg+0x898>
     2c4:      	cmp	w9, #0x1
     2c8:      	b.eq	0x4bc <generic_fexit_filter_arg+0x4bc>
     2cc:      	cmp	w9, #0x4
     2d0:      	b.eq	0x4bc <generic_fexit_filter_arg+0x4bc>
     2d4:      	b	0x140 <generic_fexit_filter_arg+0x140>
     2d8:      	cmp	w9, #0x5
     2dc:      	b.eq	0x2f0 <generic_fexit_filter_arg+0x2f0>
     2e0:      	cmp	w9, #0x6
     2e4:      	b.eq	0x318 <generic_fexit_filter_arg+0x318>
     2e8:      	cmp	w9, #0x7
     2ec:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
     2f0:      	mov	x22, xzr
     2f4:      	cmp	w9, #0x27
     2f8:      	stp	xzr, xzr, [sp, #0x78]
     2fc:      	str	xzr, [sp, #0x60]
     300:      	stp	xzr, xzr, [sp, #0x68]
     304:      	b.gt	0x4fc <generic_fexit_filter_arg+0x4fc>
     308:      	cmp	w9, #0x5
     30c:      	b.eq	0x9c8 <generic_fexit_filter_arg+0x9c8>
     310:      	cmp	w9, #0x7
     314:      	b	0x508 <generic_fexit_filter_arg+0x508>
     318:      	ldr	w29, [x25], #0x4
     31c:      	mov	x22, xzr
     320:      	cmp	w8, #0x19
     324:      	b.gt	0x568 <generic_fexit_filter_arg+0x568>
     328:      	sub	w9, w8, #0x3
     32c:      	cmp	w9, #0x2
     330:      	b.lo	0xc48 <generic_fexit_filter_arg+0xc48>
     334:      	cmp	w8, #0x8
     338:      	b.eq	0xbb0 <generic_fexit_filter_arg+0xbb0>
     33c:      	cmp	w8, #0x9
     340:      	b.eq	0x580 <generic_fexit_filter_arg+0x580>
     344:      	b	0x1d18 <generic_fexit_filter_arg+0x1d18>
     348:      	cmp	w8, #0x9
     34c:      	b.le	0x814 <generic_fexit_filter_arg+0x814>
     350:      	cmp	w8, #0x1d
     354:      	b.gt	0xb70 <generic_fexit_filter_arg+0xb70>
     358:      	sub	w10, w8, #0xa
     35c:      	cmp	w10, #0x2
     360:      	b.lo	0x924 <generic_fexit_filter_arg+0x924>
     364:      	cmp	w8, #0xc
     368:      	b.eq	0x8b0 <generic_fexit_filter_arg+0x8b0>
     36c:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
     370:      	cmp	w9, #0x2a
     374:      	b.eq	0x3f8 <generic_fexit_filter_arg+0x3f8>
     378:      	cmp	w9, #0x2c
     37c:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
     380:      	ldrb	w29, [x25, #0x3]
     384:      	add	x10, x25, #0x4
     388:      	cmp	w8, #0x19
     38c:      	b.gt	0xf44 <generic_fexit_filter_arg+0xf44>
     390:      	sub	w9, w8, #0x3
     394:      	cmp	w9, #0x2
     398:      	b.hs	0x14b4 <generic_fexit_filter_arg+0x14b4>
     39c:      	cmp	w29, #0x90
     3a0:      	str	wzr, [sp, #0x88]
     3a4:      	b.hi	0x1550 <generic_fexit_filter_arg+0x1550>
     3a8:      	mov	w8, #0xaaab             // =43691
     3ac:      	mov	w9, #0x18               // =24
     3b0:      	movk	w8, #0xaaa, lsl #16
     3b4:      	umull	x8, w29, w8
     3b8:      	lsr	x8, x8, #32
     3bc:      	msub	w8, w8, w9, w29
     3c0:      	cbz	w29, 0x3cc <generic_fexit_filter_arg+0x3cc>
     3c4:      	mov	w13, w29
     3c8:      	cbz	w8, 0x3e0 <generic_fexit_filter_arg+0x3e0>
     3cc:      	sub	w8, w29, w8, uxtb
     3d0:      	add	w9, w8, #0x18
     3d4:      	cmp	w8, #0x78
     3d8:      	and	w13, w9, #0xffff
     3dc:      	b.hi	0x1554 <generic_fexit_filter_arg+0x1554>
     3e0:      	and	w8, w13, #0xff
     3e4:      	mov	w9, #0xab               // =171
     3e8:      	mul	w8, w8, w9
     3ec:      	lsr	w8, w8, #12
     3f0:      	sub	w11, w8, #0x1
     3f4:      	b	0x1fd0 <generic_fexit_filter_arg+0x1fd0>
     3f8:      	ldr	w29, [x25]
     3fc:      	and	w9, w8, #0xfffffffe
     400:      	cmp	w9, #0x24
     404:      	b.eq	0x40c <generic_fexit_filter_arg+0x40c>
     408:      	cbz	w29, 0xc4 <generic_fexit_filter_arg+0xc4>
     40c:      	cmp	w8, #0x25
     410:      	b.hi	0x64c <generic_fexit_filter_arg+0x64c>
     414:      	mov	w10, #0x100             // =256
     418:      	lsl	x9, x17, x8
     41c:      	movk	w10, #0x400, lsl #16
     420:      	tst	x9, x10
     424:      	b.ne	0x77c <generic_fexit_filter_arg+0x77c>
     428:      	mov	w10, #0x200             // =512
     42c:      	lsl	x9, x17, x8
     430:      	movk	w10, #0x800, lsl #16
     434:      	tst	x9, x10
     438:      	b.ne	0x6ac <generic_fexit_filter_arg+0x6ac>
     43c:      	lsl	x9, x17, x8
     440:      	tst	x9, #0x3000000000
     444:      	b.eq	0x64c <generic_fexit_filter_arg+0x64c>
     448:      	cmp	w29, #0x1, lsl #12      // =0x1000
     44c:      	strh	wzr, [sp, #0x60]
     450:      	b.hi	0x664 <generic_fexit_filter_arg+0x664>
     454:      	add	x8, x25, #0x4
     458:      	mov	w10, #0x4               // =4
     45c:      	add	x11, sp, #0x60
     460:      	mov	w12, #0x2               // =2
     464:      	add	x0, sp, #0x60
     468:      	mov	w1, #0x2                // =2
     46c:      	add	x9, x8, x29
     470:      	add	x9, x9, #0x4
     474:      	ldr	w9, [x25]
     478:      	add	x8, x8, x9
     47c:      	add	x2, x8, #0x4
     480:      	blr	x10
     484:      	ldr	w9, [x21, #0x10]
     488:      	cbz	w9, 0x2d1c <generic_fexit_filter_arg+0x2d1c>
     48c:      	ldrh	w8, [sp, #0x60]
     490:      	ldr	x0, [sp, #0x38]
     494:      	mov	w17, #0x1               // =1
     498:      	and	w8, w8, #0xf000
     49c:      	ldp	x12, x16, [sp, #0x48]
     4a0:      	cmp	w9, w8
     4a4:      	b.ne	0x1874 <generic_fexit_filter_arg+0x1874>
     4a8:      	mov	w22, #0x1               // =1
     4ac:      	b	0x2d2c <generic_fexit_filter_arg+0x2d2c>
     4b0:      	sub	w10, w9, #0xc
     4b4:      	cmp	w10, #0x2
     4b8:      	b.hs	0x890 <generic_fexit_filter_arg+0x890>
     4bc:      	cmp	w8, #0x20
     4c0:      	b.hi	0xc4 <generic_fexit_filter_arg+0xc4>
     4c4:      	lsl	x10, x17, x8
     4c8:      	mov	w11, #0x101e            // =4126
     4cc:      	tst	x10, x11
     4d0:      	b.eq	0x514 <generic_fexit_filter_arg+0x514>
     4d4:      	ldr	w10, [x21, #0x10]
     4d8:      	cmp	w8, #0x2
     4dc:      	b.le	0x858 <generic_fexit_filter_arg+0x858>
     4e0:      	sub	w11, w8, #0x3
     4e4:      	cmp	w11, #0x2
     4e8:      	b.hs	0xca0 <generic_fexit_filter_arg+0xca0>
     4ec:      	ldr	w11, [x25]
     4f0:      	cmp	w11, w10
     4f4:      	b.ne	0x1df4 <generic_fexit_filter_arg+0x1df4>
     4f8:      	b	0x31dc <generic_fexit_filter_arg+0x31dc>
     4fc:      	cmp	w9, #0x28
     500:      	b.eq	0x9d0 <generic_fexit_filter_arg+0x9d0>
     504:      	cmp	w9, #0x29
     508:      	mov	x10, x25
     50c:      	b.eq	0x9f8 <generic_fexit_filter_arg+0x9f8>
     510:      	b	0x1ce4 <generic_fexit_filter_arg+0x1ce4>
     514:      	lsl	x10, x17, x8
     518:      	tst	x10, #0xc00
     51c:      	b.ne	0x990 <generic_fexit_filter_arg+0x990>
     520:      	lsl	x10, x17, x8
     524:      	tst	x10, #0x180000000
     528:      	b.eq	0xc4 <generic_fexit_filter_arg+0xc4>
     52c:      	cmp	w8, #0x1f
     530:      	b.ne	0xf14 <generic_fexit_filter_arg+0xf14>
     534:      	ldp	w11, w10, [x21, #0x10]
     538:      	cmp	w9, #0xc
     53c:      	b.hi	0x1a44 <generic_fexit_filter_arg+0x1a44>
     540:      	lsl	w8, w17, w9
     544:      	mov	w13, #0x1402            // =5122
     548:      	tst	w8, w13
     54c:      	b.eq	0x1a44 <generic_fexit_filter_arg+0x1a44>
     550:      	ldr	w8, [x25]
     554:      	cmp	w11, w8
     558:      	b.gt	0x1a58 <generic_fexit_filter_arg+0x1a58>
     55c:      	cmp	w8, w10
     560:      	b.le	0x140 <generic_fexit_filter_arg+0x140>
     564:      	b	0x1a58 <generic_fexit_filter_arg+0x1a58>
     568:      	cmp	w8, #0x20
     56c:      	b.gt	0xa6c <generic_fexit_filter_arg+0xa6c>
     570:      	cmp	w8, #0x1a
     574:      	b.eq	0xbb0 <generic_fexit_filter_arg+0xbb0>
     578:      	cmp	w8, #0x1b
     57c:      	b.ne	0x1d18 <generic_fexit_filter_arg+0x1d18>
     580:      	ldr	w8, [x21, #0x10]
     584:      	str	wzr, [sp, #0x88]
     588:      	adrp	x0, 0x0 <generic_fexit_filter_arg>
     58c:      	add	x9, sp, #0x60
     590:      	add	x1, sp, #0x60
     594:      	str	w8, [sp, #0x60]
     598:      	mov	w8, #0x1                // =1
     59c:      	ldr	x0, [x0]
     5a0:      	blr	x8
     5a4:      	mov	x22, xzr
     5a8:      	cbz	w29, 0x1314 <generic_fexit_filter_arg+0x1314>
     5ac:      	cbz	x0, 0x1314 <generic_fexit_filter_arg+0x1314>
     5b0:      	mov	x19, x0
     5b4:      	adrp	x0, 0x0 <generic_fexit_filter_arg>
     5b8:      	mov	w8, #0x1                // =1
     5bc:      	ldr	x0, [x0]
     5c0:      	add	x9, sp, #0x88
     5c4:      	add	x1, sp, #0x88
     5c8:      	blr	x8
     5cc:      	cbz	x0, 0x130c <generic_fexit_filter_arg+0x130c>
     5d0:      	cmp	w29, #0x7f
     5d4:      	mov	w9, #0x7f               // =127
     5d8:      	mov	w11, #0x1               // =1
     5dc:      	mov	x1, x0
     5e0:      	mov	x8, xzr
     5e4:      	sub	w12, w29, #0x2
     5e8:      	sub	w13, w29, #0x1
     5ec:      	csel	w9, w29, w9, lo
     5f0:      	sub	x11, x11, x29
     5f4:      	lsl	w10, w9, #3
     5f8:      	mov	x9, x0
     5fc:      	str	w10, [x9], #0x5
     600:      	neg	x10, x29
     604:      	add	w14, w13, w8
     608:      	cmp	x11, x8
     60c:      	and	x14, x14, #0xfff
     610:      	ldrb	w14, [x25, x14]
     614:      	sturb	w14, [x9, #-0x1]
     618:      	b.eq	0x640 <generic_fexit_filter_arg+0x640>
     61c:      	cmn	x8, #0x7e
     620:      	b.eq	0x640 <generic_fexit_filter_arg+0x640>
     624:      	add	w14, w12, w8
     628:      	sub	x8, x8, #0x2
     62c:      	and	x14, x14, #0xfff
     630:      	cmp	x10, x8
     634:      	ldrb	w14, [x25, x14]
     638:      	strb	w14, [x9], #0x2
     63c:      	b.ne	0x604 <generic_fexit_filter_arg+0x604>
     640:      	mov	w8, #0x1                // =1
     644:      	mov	x0, x19
     648:      	b	0xc38 <generic_fexit_filter_arg+0xc38>
     64c:      	sub	w8, w8, #0x3
     650:      	cmp	w8, #0x2
     654:      	b.hs	0x664 <generic_fexit_filter_arg+0x664>
     658:      	cmp	w29, #0x1, lsl #12      // =0x1000
     65c:      	str	wzr, [sp, #0x88]
     660:      	b.ls	0xda8 <generic_fexit_filter_arg+0xda8>
     664:      	mov	x22, xzr
     668:      	b	0x2d2c <generic_fexit_filter_arg+0x2d2c>
     66c:      	cmp	w8, #0x20
     670:      	b.hi	0xc4 <generic_fexit_filter_arg+0xc4>
     674:      	lsl	x9, x17, x8
     678:      	mov	w10, #0x101e            // =4126
     67c:      	tst	x9, x10
     680:      	b.eq	0xce4 <generic_fexit_filter_arg+0xce4>
     684:      	ldr	w9, [x21, #0x10]
     688:      	cmp	w8, #0x2
     68c:      	b.le	0x1250 <generic_fexit_filter_arg+0x1250>
     690:      	sub	w10, w8, #0x3
     694:      	cmp	w10, #0x2
     698:      	b.hs	0x185c <generic_fexit_filter_arg+0x185c>
     69c:      	ldrh	w10, [x25]
     6a0:      	cmp	w9, w10
     6a4:      	b.ne	0x1a10 <generic_fexit_filter_arg+0x1a10>
     6a8:      	b	0x31dc <generic_fexit_filter_arg+0x31dc>
     6ac:      	ldr	w8, [x21, #0x10]
     6b0:      	str	wzr, [sp, #0x88]
     6b4:      	adrp	x0, 0x0 <generic_fexit_filter_arg>
     6b8:      	add	x9, sp, #0x60
     6bc:      	add	x1, sp, #0x60
     6c0:      	str	w8, [sp, #0x60]
     6c4:      	mov	w8, #0x1                // =1
     6c8:      	ldr	x0, [x0]
     6cc:      	blr	x8
     6d0:      	mov	x22, xzr
     6d4:      	cbz	w29, 0x2d20 <generic_fexit_filter_arg+0x2d20>
     6d8:      	cbz	x0, 0x2d20 <generic_fexit_filter_arg+0x2d20>
     6dc:      	mov	x19, x0
     6e0:      	adrp	x0, 0x0 <generic_fexit_filter_arg>
     6e4:      	mov	w8, #0x1                // =1
     6e8:      	ldr	x0, [x0]
     6ec:      	add	x9, sp, #0x88
     6f0:      	add	x1, sp, #0x88
     6f4:      	blr	x8
     6f8:      	cbz	x0, 0x18c4 <generic_fexit_filter_arg+0x18c4>
     6fc:      	cmp	w29, #0x7f
     700:      	mov	w10, #0x7f              // =127
     704:      	mov	w12, #0x1               // =1
     708:      	mov	x1, x0
     70c:      	mov	x8, xzr
     710:      	add	x9, x25, #0x4
     714:      	sub	w13, w29, #0x2
     718:      	sub	w14, w29, #0x1
     71c:      	csel	w10, w29, w10, lo
     720:      	sub	x12, x12, x29
     724:      	lsl	w11, w10, #3
     728:      	mov	x10, x0
     72c:      	str	w11, [x10], #0x5
     730:      	neg	x11, x29
     734:      	add	w15, w14, w8
     738:      	cmp	x12, x8
     73c:      	and	x15, x15, #0xfff
     740:      	ldrb	w15, [x9, x15]
     744:      	sturb	w15, [x10, #-0x1]
     748:      	b.eq	0x770 <generic_fexit_filter_arg+0x770>
     74c:      	cmn	x8, #0x7e
     750:      	b.eq	0x770 <generic_fexit_filter_arg+0x770>
     754:      	add	w15, w13, w8
     758:      	sub	x8, x8, #0x2
     75c:      	and	x15, x15, #0xfff
     760:      	cmp	x11, x8
     764:      	ldrb	w15, [x9, x15]
     768:      	strb	w15, [x10], #0x2
     76c:      	b.ne	0x734 <generic_fexit_filter_arg+0x734>
     770:      	mov	w8, #0x1                // =1
     774:      	mov	x0, x19
     778:      	b	0x804 <generic_fexit_filter_arg+0x804>
     77c:      	ldr	w8, [x21, #0x10]
     780:      	str	wzr, [sp, #0x88]
     784:      	adrp	x0, 0x0 <generic_fexit_filter_arg>
     788:      	add	x9, sp, #0x60
     78c:      	add	x1, sp, #0x60
     790:      	str	w8, [sp, #0x60]
     794:      	mov	w8, #0x1                // =1
     798:      	ldr	x0, [x0]
     79c:      	blr	x8
     7a0:      	mov	x22, xzr
     7a4:      	cbz	w29, 0x2d20 <generic_fexit_filter_arg+0x2d20>
     7a8:      	cbz	x0, 0x2d20 <generic_fexit_filter_arg+0x2d20>
     7ac:      	mov	x19, x0
     7b0:      	adrp	x0, 0x0 <generic_fexit_filter_arg>
     7b4:      	mov	w8, #0x1                // =1
     7b8:      	ldr	x0, [x0]
     7bc:      	add	x9, sp, #0x88
     7c0:      	add	x1, sp, #0x88
     7c4:      	blr	x8
     7c8:      	cbz	x0, 0x18c4 <generic_fexit_filter_arg+0x18c4>
     7cc:      	cmp	w29, #0xff
     7d0:      	mov	w8, #0xff               // =255
     7d4:      	add	x2, x25, #0x4
     7d8:      	mov	x22, x0
     7dc:      	csel	w1, w29, w8, lo
     7e0:      	mov	x8, x0
     7e4:      	lsl	w9, w1, #3
     7e8:      	str	w9, [x8], #0x4
     7ec:      	mov	w9, #0x4                // =4
     7f0:      	mov	x0, x8
     7f4:      	blr	x9
     7f8:      	mov	w8, #0x1                // =1
     7fc:      	mov	x0, x19
     800:      	mov	x1, x22
     804:      	blr	x8
     808:      	cmp	x0, #0x0
     80c:      	cset	w22, ne
     810:      	b	0x18c8 <generic_fexit_filter_arg+0x18c8>
     814:      	sub	w10, w8, #0x1
     818:      	cmp	w10, #0x4
     81c:      	b.lo	0x8b0 <generic_fexit_filter_arg+0x8b0>
     820:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
     824:      	add	x29, x25, #0x8
     828:      	ldr	w25, [x25, #0x4]
     82c:      	mov	x22, xzr
     830:      	cmp	w8, #0x19
     834:      	b.gt	0xe18 <generic_fexit_filter_arg+0xe18>
     838:      	sub	w9, w8, #0x3
     83c:      	cmp	w9, #0x2
     840:      	b.lo	0x1658 <generic_fexit_filter_arg+0x1658>
     844:      	cmp	w8, #0x8
     848:      	b.eq	0x15cc <generic_fexit_filter_arg+0x15cc>
     84c:      	cmp	w8, #0x9
     850:      	b.eq	0xe30 <generic_fexit_filter_arg+0xe30>
     854:      	b	0x32c4 <generic_fexit_filter_arg+0x32c4>
     858:      	cmp	w8, #0x1
     85c:      	b.eq	0x1080 <generic_fexit_filter_arg+0x1080>
     860:      	cmp	w8, #0x2
     864:      	b.ne	0x1df4 <generic_fexit_filter_arg+0x1df4>
     868:      	cmp	w9, #0xc
     86c:      	b.hi	0x1de8 <generic_fexit_filter_arg+0x1de8>
     870:      	lsl	w11, w17, w9
     874:      	mov	w13, #0x1402            // =5122
     878:      	tst	w11, w13
     87c:      	b.eq	0x1de8 <generic_fexit_filter_arg+0x1de8>
     880:      	ldr	w11, [x25]
     884:      	cmp	w11, w10
     888:      	b.lt	0x140 <generic_fexit_filter_arg+0x140>
     88c:      	b	0x1df4 <generic_fexit_filter_arg+0x1df4>
     890:      	cmp	w9, #0x1c
     894:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
     898:      	cmp	w8, #0x20
     89c:      	b.hi	0xc4 <generic_fexit_filter_arg+0xc4>
     8a0:      	lsl	x10, x17, x8
     8a4:      	mov	w11, #0x101e            // =4126
     8a8:      	tst	x10, x11
     8ac:      	b.eq	0x8d8 <generic_fexit_filter_arg+0x8d8>
     8b0:      	ldr	x10, [x21, #0x10]
     8b4:      	cmp	w8, #0x2
     8b8:      	b.le	0x8f4 <generic_fexit_filter_arg+0x8f4>
     8bc:      	sub	w11, w8, #0x3
     8c0:      	cmp	w11, #0x2
     8c4:      	b.hs	0xb58 <generic_fexit_filter_arg+0xb58>
     8c8:      	ldr	x11, [x25]
     8cc:      	cmp	x11, x10
     8d0:      	b.ne	0x17b8 <generic_fexit_filter_arg+0x17b8>
     8d4:      	b	0x31dc <generic_fexit_filter_arg+0x31dc>
     8d8:      	lsl	x10, x17, x8
     8dc:      	tst	x10, #0xc00
     8e0:      	b.ne	0x924 <generic_fexit_filter_arg+0x924>
     8e4:      	lsl	x10, x17, x8
     8e8:      	tst	x10, #0x180000000
     8ec:      	b.ne	0xb7c <generic_fexit_filter_arg+0xb7c>
     8f0:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
     8f4:      	cmp	w8, #0x1
     8f8:      	b.eq	0xd88 <generic_fexit_filter_arg+0xd88>
     8fc:      	cmp	w8, #0x2
     900:      	b.ne	0x17b8 <generic_fexit_filter_arg+0x17b8>
     904:      	cmp	w9, #0xc
     908:      	b.eq	0x914 <generic_fexit_filter_arg+0x914>
     90c:      	cmp	w9, #0xa
     910:      	b.ne	0x17ac <generic_fexit_filter_arg+0x17ac>
     914:      	ldr	x11, [x25]
     918:      	cmp	x11, x10
     91c:      	b.lt	0x140 <generic_fexit_filter_arg+0x140>
     920:      	b	0x17b8 <generic_fexit_filter_arg+0x17b8>
     924:      	ldrb	w8, [x21, #0x10]
     928:      	adrp	x0, 0x0 <generic_fexit_filter_arg>
     92c:      	add	x9, sp, #0x88
     930:      	add	x1, sp, #0x88
     934:      	str	w8, [sp, #0x88]
     938:      	mov	w8, #0x1                // =1
     93c:      	ldr	x0, [x0]
     940:      	blr	x8
     944:      	cbz	x0, 0xefc <generic_fexit_filter_arg+0xefc>
     948:      	ldr	x8, [x25]
     94c:      	add	x9, sp, #0x60
     950:      	add	x1, sp, #0x60
     954:      	str	x8, [sp, #0x60]
     958:      	mov	w8, #0x1                // =1
     95c:      	blr	x8
     960:      	ldr	w8, [x21, #0x4]
     964:      	cmp	w8, #0xb
     968:      	b.eq	0x1324 <generic_fexit_filter_arg+0x1324>
     96c:      	ldp	x12, x16, [sp, #0x48]
     970:      	cmp	w8, #0xa
     974:      	mov	w17, #0x1               // =1
     978:      	b.eq	0x13c8 <generic_fexit_filter_arg+0x13c8>
     97c:      	ldr	x0, [sp, #0x38]
     980:      	mov	w22, wzr
     984:      	mov	w8, wzr
     988:      	cbnz	x22, 0x140 <generic_fexit_filter_arg+0x140>
     98c:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
     990:      	ldrb	w8, [x21, #0x10]
     994:      	adrp	x0, 0x0 <generic_fexit_filter_arg>
     998:      	add	x9, sp, #0x88
     99c:      	add	x1, sp, #0x88
     9a0:      	str	w8, [sp, #0x88]
     9a4:      	mov	w8, #0x1                // =1
     9a8:      	ldr	x0, [x0]
     9ac:      	blr	x8
     9b0:      	cbz	x0, 0x1cd4 <generic_fexit_filter_arg+0x1cd4>
     9b4:      	ldr	w8, [x25]
     9b8:      	add	x9, sp, #0x60
     9bc:      	str	x8, [sp, #0x60]
     9c0:      	mov	w8, #0x1                // =1
     9c4:      	b	0x12dc <generic_fexit_filter_arg+0x12dc>
     9c8:      	mov	x10, xzr
     9cc:      	b	0x9f8 <generic_fexit_filter_arg+0x9f8>
     9d0:      	ldrh	w11, [x25]
     9d4:      	mov	x10, xzr
     9d8:      	strh	w11, [sp, #0x86]
     9dc:      	ldrh	w11, [x25, #0x2]
     9e0:      	strh	w11, [sp, #0x80]
     9e4:      	ldr	x11, [x25, #0x8]
     9e8:      	str	x11, [sp, #0x60]
     9ec:      	ldr	x11, [x25, #0x10]
     9f0:      	add	x25, sp, #0x60
     9f4:      	str	x11, [sp, #0x68]
     9f8:      	mov	x22, xzr
     9fc:      	cmp	w8, #0x13
     a00:      	b.le	0xa28 <generic_fexit_filter_arg+0xa28>
     a04:      	cmp	w8, #0x17
     a08:      	b.gt	0xa50 <generic_fexit_filter_arg+0xa50>
     a0c:      	sub	w9, w8, #0x14
     a10:      	cmp	w9, #0x2
     a14:      	b.lo	0xf80 <generic_fexit_filter_arg+0xf80>
     a18:      	sub	w9, w8, #0x16
     a1c:      	cmp	w9, #0x2
     a20:      	b.lo	0xf6c <generic_fexit_filter_arg+0xf6c>
     a24:      	b	0x1ce4 <generic_fexit_filter_arg+0x1ce4>
     a28:      	cmp	w8, #0xf
     a2c:      	b.le	0xc5c <generic_fexit_filter_arg+0xc5c>
     a30:      	cmp	w8, #0x11
     a34:      	b.gt	0xf5c <generic_fexit_filter_arg+0xf5c>
     a38:      	cmp	w8, #0x10
     a3c:      	b.eq	0xf6c <generic_fexit_filter_arg+0xf6c>
     a40:      	cmp	w8, #0x11
     a44:      	b.ne	0x1ce4 <generic_fexit_filter_arg+0x1ce4>
     a48:      	ldrh	w22, [x25, #0x24]
     a4c:      	b	0x16fc <generic_fexit_filter_arg+0x16fc>
     a50:      	cmp	w8, #0x1b
     a54:      	b.gt	0xf94 <generic_fexit_filter_arg+0xf94>
     a58:      	cmp	w8, #0x18
     a5c:      	b.eq	0xfc4 <generic_fexit_filter_arg+0xfc4>
     a60:      	cmp	w8, #0x19
     a64:      	b.eq	0xfb8 <generic_fexit_filter_arg+0xfb8>
     a68:      	b	0x1ce4 <generic_fexit_filter_arg+0x1ce4>
     a6c:      	cmp	w8, #0x21
     a70:      	b.eq	0x10a8 <generic_fexit_filter_arg+0x10a8>
     a74:      	cmp	w8, #0x22
     a78:      	b.ne	0x1d18 <generic_fexit_filter_arg+0x1d18>
     a7c:      	str	x23, [sp, #0x28]
     a80:      	mov	x22, xzr
     a84:      	mov	w23, wzr
     a88:      	add	x19, x21, #0x10
     a8c:      	ldr	w8, [x19, x22, lsl #2]
     a90:      	adrp	x0, 0x0 <generic_fexit_filter_arg>
     a94:      	add	x9, sp, #0x60
     a98:      	add	x1, sp, #0x60
     a9c:      	str	w8, [sp, #0x60]
     aa0:      	mov	w8, #0x1                // =1
     aa4:      	ldr	x0, [x0]
     aa8:      	blr	x8
     aac:      	cbz	x0, 0x1d00 <generic_fexit_filter_arg+0x1d00>
     ab0:      	ldr	x16, [sp, #0x50]
     ab4:      	mov	w17, #0x1               // =1
     ab8:      	cbz	w29, 0xb34 <generic_fexit_filter_arg+0xb34>
     abc:      	mov	x8, xzr
     ac0:      	mov	x9, x25
     ac4:      	mov	x10, x29
     ac8:      	b	0xae0 <generic_fexit_filter_arg+0xae0>
     acc:      	add	x8, x8, #0x1
     ad0:      	sub	x10, x10, #0x1
     ad4:      	add	x9, x9, #0x1
     ad8:      	cmp	x8, x29
     adc:      	b.eq	0xb34 <generic_fexit_filter_arg+0xb34>
     ae0:      	mov	x11, xzr
     ae4:      	cmp	x10, x11
     ae8:      	b.eq	0xacc <generic_fexit_filter_arg+0xacc>
     aec:      	ldrb	w12, [x0, x11]
     af0:      	cbz	w12, 0xb30 <generic_fexit_filter_arg+0xb30>
     af4:      	ldrb	w13, [x9, x11]
     af8:      	sub	w14, w13, #0x41
     afc:      	orr	w15, w13, #0x20
     b00:      	cmp	w14, #0x1a
     b04:      	sub	w14, w12, #0x41
     b08:      	csel	w13, w15, w13, lo
     b0c:      	orr	w15, w12, #0x20
     b10:      	cmp	w14, #0x1a
     b14:      	csel	w12, w15, w12, lo
     b18:      	cmp	x11, #0x62
     b1c:      	b.hi	0xacc <generic_fexit_filter_arg+0xacc>
     b20:      	add	x11, x11, #0x1
     b24:      	cmp	w13, w12
     b28:      	b.eq	0xae4 <generic_fexit_filter_arg+0xae4>
     b2c:      	b	0xacc <generic_fexit_filter_arg+0xacc>
     b30:      	tbz	w8, #0x1f, 0x19bc <generic_fexit_filter_arg+0x19bc>
     b34:      	ldr	w9, [x21, #0x8]
     b38:      	add	w8, w23, #0xc
     b3c:      	cmp	w8, w9
     b40:      	b.hs	0x1170 <generic_fexit_filter_arg+0x1170>
     b44:      	add	x22, x22, #0x1
     b48:      	add	w23, w23, #0x4
     b4c:      	cmp	x22, #0x64
     b50:      	b.ne	0xa8c <generic_fexit_filter_arg+0xa8c>
     b54:      	b	0x1170 <generic_fexit_filter_arg+0x1170>
     b58:      	cmp	w8, #0xc
     b5c:      	b.ne	0x17b8 <generic_fexit_filter_arg+0x17b8>
     b60:      	ldr	x11, [x25]
     b64:      	tst	x11, x10
     b68:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
     b6c:      	b	0x17b8 <generic_fexit_filter_arg+0x17b8>
     b70:      	sub	w10, w8, #0x1f
     b74:      	cmp	w10, #0x2
     b78:      	b.hs	0x13f4 <generic_fexit_filter_arg+0x13f4>
     b7c:      	cmp	w8, #0x1f
     b80:      	b.ne	0xc78 <generic_fexit_filter_arg+0xc78>
     b84:      	ldp	x11, x10, [x21, #0x10]
     b88:      	cmp	w9, #0xa
     b8c:      	b.eq	0xb98 <generic_fexit_filter_arg+0xb98>
     b90:      	cmp	w9, #0xc
     b94:      	b.ne	0x166c <generic_fexit_filter_arg+0x166c>
     b98:      	ldr	x8, [x25]
     b9c:      	cmp	x11, x8
     ba0:      	b.gt	0x1680 <generic_fexit_filter_arg+0x1680>
     ba4:      	cmp	x8, x10
     ba8:      	b.le	0x140 <generic_fexit_filter_arg+0x140>
     bac:      	b	0x1680 <generic_fexit_filter_arg+0x1680>
     bb0:      	ldr	w8, [x21, #0x10]
     bb4:      	str	wzr, [sp, #0x88]
     bb8:      	adrp	x0, 0x0 <generic_fexit_filter_arg>
     bbc:      	add	x9, sp, #0x60
     bc0:      	add	x1, sp, #0x60
     bc4:      	str	w8, [sp, #0x60]
     bc8:      	mov	w8, #0x1                // =1
     bcc:      	ldr	x0, [x0]
     bd0:      	blr	x8
     bd4:      	mov	x22, xzr
     bd8:      	cbz	w29, 0x1314 <generic_fexit_filter_arg+0x1314>
     bdc:      	cbz	x0, 0x1314 <generic_fexit_filter_arg+0x1314>
     be0:      	mov	x19, x0
     be4:      	adrp	x0, 0x0 <generic_fexit_filter_arg>
     be8:      	mov	w8, #0x1                // =1
     bec:      	ldr	x0, [x0]
     bf0:      	add	x9, sp, #0x88
     bf4:      	add	x1, sp, #0x88
     bf8:      	blr	x8
     bfc:      	cbz	x0, 0x130c <generic_fexit_filter_arg+0x130c>
     c00:      	cmp	w29, #0xff
     c04:      	mov	w8, #0xff               // =255
     c08:      	mov	x22, x0
     c0c:      	mov	x2, x25
     c10:      	csel	w1, w29, w8, lo
     c14:      	mov	x8, x0
     c18:      	lsl	w9, w1, #3
     c1c:      	str	w9, [x8], #0x4
     c20:      	mov	w9, #0x4                // =4
     c24:      	mov	x0, x8
     c28:      	blr	x9
     c2c:      	mov	w8, #0x1                // =1
     c30:      	mov	x0, x19
     c34:      	mov	x1, x22
     c38:      	blr	x8
     c3c:      	cmp	x0, #0x0
     c40:      	cset	w22, ne
     c44:      	b	0x1310 <generic_fexit_filter_arg+0x1310>
     c48:      	cmp	w29, #0x1, lsl #12      // =0x1000
     c4c:      	str	wzr, [sp, #0x88]
     c50:      	b.ls	0x1178 <generic_fexit_filter_arg+0x1178>
     c54:      	mov	x22, xzr
     c58:      	b	0x1d18 <generic_fexit_filter_arg+0x1d18>
     c5c:      	cmp	w8, #0xd
     c60:      	b.eq	0xfc4 <generic_fexit_filter_arg+0xfc4>
     c64:      	cmp	w8, #0xe
     c68:      	b.eq	0xfb8 <generic_fexit_filter_arg+0xfb8>
     c6c:      	cmp	w8, #0xf
     c70:      	b.eq	0xf80 <generic_fexit_filter_arg+0xf80>
     c74:      	b	0x1ce4 <generic_fexit_filter_arg+0x1ce4>
     c78:      	ldp	x11, x8, [x21, #0x10]
     c7c:      	cmp	w9, #0xc
     c80:      	b.eq	0xc8c <generic_fexit_filter_arg+0xc8c>
     c84:      	cmp	w9, #0xa
     c88:      	b.ne	0x16b8 <generic_fexit_filter_arg+0x16b8>
     c8c:      	ldr	x10, [x25]
     c90:      	cmp	x11, x10
     c94:      	ccmp	x10, x8, #0x0, le
     c98:      	cset	w8, le
     c9c:      	b	0x16c8 <generic_fexit_filter_arg+0x16c8>
     ca0:      	cmp	w8, #0xc
     ca4:      	b.ne	0x1df4 <generic_fexit_filter_arg+0x1df4>
     ca8:      	ldr	w11, [x25]
     cac:      	tst	w11, w10
     cb0:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
     cb4:      	b	0x1df4 <generic_fexit_filter_arg+0x1df4>
     cb8:      	lsl	x9, x17, x8
     cbc:      	tst	x9, #0xc00
     cc0:      	b.ne	0x1270 <generic_fexit_filter_arg+0x1270>
     cc4:      	lsl	x9, x17, x8
     cc8:      	tst	x9, #0x180000000
     ccc:      	b.eq	0xc4 <generic_fexit_filter_arg+0xc4>
     cd0:      	cmp	w8, #0x1f
     cd4:      	b.ne	0x18f4 <generic_fexit_filter_arg+0x18f4>
     cd8:      	ldr	w9, [x21, #0x10]
     cdc:      	ldrb	w8, [x25]
     ce0:      	b	0xd0c <generic_fexit_filter_arg+0xd0c>
     ce4:      	lsl	x9, x17, x8
     ce8:      	tst	x9, #0xc00
     cec:      	b.ne	0x12a8 <generic_fexit_filter_arg+0x12a8>
     cf0:      	lsl	x9, x17, x8
     cf4:      	tst	x9, #0x180000000
     cf8:      	b.eq	0xc4 <generic_fexit_filter_arg+0xc4>
     cfc:      	cmp	w8, #0x1f
     d00:      	b.ne	0x1918 <generic_fexit_filter_arg+0x1918>
     d04:      	ldr	w9, [x21, #0x10]
     d08:      	ldrh	w8, [x25]
     d0c:      	cmp	w9, w8
     d10:      	b.hi	0xd20 <generic_fexit_filter_arg+0xd20>
     d14:      	ldr	w9, [x21, #0x14]
     d18:      	cmp	w9, w8
     d1c:      	b.hs	0x140 <generic_fexit_filter_arg+0x140>
     d20:      	ldr	w9, [x21, #0x8]
     d24:      	cmp	w9, #0x11
     d28:      	b.lo	0xc4 <generic_fexit_filter_arg+0xc4>
     d2c:      	ldr	w10, [x21, #0x18]
     d30:      	cmp	w10, w8
     d34:      	b.hi	0xd44 <generic_fexit_filter_arg+0xd44>
     d38:      	ldr	w10, [x21, #0x1c]
     d3c:      	cmp	w10, w8
     d40:      	b.hs	0x140 <generic_fexit_filter_arg+0x140>
     d44:      	cmp	w9, #0x19
     d48:      	b.lo	0xc4 <generic_fexit_filter_arg+0xc4>
     d4c:      	ldr	w10, [x21, #0x20]
     d50:      	cmp	w10, w8
     d54:      	b.hi	0xd64 <generic_fexit_filter_arg+0xd64>
     d58:      	ldr	w10, [x21, #0x24]
     d5c:      	cmp	w10, w8
     d60:      	b.hs	0x140 <generic_fexit_filter_arg+0x140>
     d64:      	cmp	w9, #0x21
     d68:      	b.lo	0xc4 <generic_fexit_filter_arg+0xc4>
     d6c:      	ldr	w9, [x21, #0x28]
     d70:      	cmp	w9, w8
     d74:      	b.hi	0xc4 <generic_fexit_filter_arg+0xc4>
     d78:      	ldr	w9, [x21, #0x2c]
     d7c:      	cmp	w9, w8
     d80:      	b.hs	0x140 <generic_fexit_filter_arg+0x140>
     d84:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
     d88:      	cmp	w9, #0xc
     d8c:      	b.eq	0xd98 <generic_fexit_filter_arg+0xd98>
     d90:      	cmp	w9, #0xa
     d94:      	b.ne	0x179c <generic_fexit_filter_arg+0x179c>
     d98:      	ldr	x11, [x25]
     d9c:      	cmp	x11, x10
     da0:      	b.gt	0x140 <generic_fexit_filter_arg+0x140>
     da4:      	b	0x17b8 <generic_fexit_filter_arg+0x17b8>
     da8:      	and	w8, w29, #0xffff
     dac:      	cmp	w8, #0x90
     db0:      	b.hi	0x1344 <generic_fexit_filter_arg+0x1344>
     db4:      	and	w8, w29, #0xff
     db8:      	mov	w9, #0xab               // =171
     dbc:      	tst	w29, #0xffff
     dc0:      	mul	w8, w8, w9
     dc4:      	mov	w9, #0x18               // =24
     dc8:      	lsr	w8, w8, #12
     dcc:      	msub	w8, w8, w9, w29
     dd0:      	b.eq	0xde4 <generic_fexit_filter_arg+0xde4>
     dd4:      	tst	w8, #0xff
     dd8:      	mov	w9, w29
     ddc:      	mov	w11, w29
     de0:      	b.eq	0xe00 <generic_fexit_filter_arg+0xe00>
     de4:      	sub	w8, w29, w8, uxtb
     de8:      	and	w9, w8, #0xffff
     dec:      	add	w8, w8, #0x18
     df0:      	and	w11, w8, #0xffff
     df4:      	cmp	w9, #0x78
     df8:      	b.hi	0x2390 <generic_fexit_filter_arg+0x2390>
     dfc:      	mov	w9, w11
     e00:      	and	w8, w9, #0xff
     e04:      	mov	w9, #0xab               // =171
     e08:      	mul	w8, w8, w9
     e0c:      	lsr	w8, w8, #12
     e10:      	sub	w10, w8, #0x1
     e14:      	b	0x23e0 <generic_fexit_filter_arg+0x23e0>
     e18:      	cmp	w8, #0x20
     e1c:      	b.gt	0x143c <generic_fexit_filter_arg+0x143c>
     e20:      	cmp	w8, #0x1a
     e24:      	b.eq	0x15cc <generic_fexit_filter_arg+0x15cc>
     e28:      	cmp	w8, #0x1b
     e2c:      	b.ne	0x32c4 <generic_fexit_filter_arg+0x32c4>
     e30:      	ldr	w8, [x21, #0x10]
     e34:      	str	wzr, [sp, #0x88]
     e38:      	adrp	x0, 0x0 <generic_fexit_filter_arg>
     e3c:      	add	x9, sp, #0x60
     e40:      	add	x1, sp, #0x60
     e44:      	mov	w19, #0x1               // =1
     e48:      	str	w8, [sp, #0x60]
     e4c:      	mov	w8, #0x1                // =1
     e50:      	ldr	x0, [x0]
     e54:      	blr	x8
     e58:      	mov	x22, xzr
     e5c:      	cbz	w25, 0x32bc <generic_fexit_filter_arg+0x32bc>
     e60:      	cbz	x0, 0x32bc <generic_fexit_filter_arg+0x32bc>
     e64:      	mov	x22, x0
     e68:      	adrp	x0, 0x0 <generic_fexit_filter_arg>
     e6c:      	mov	w8, #0x1                // =1
     e70:      	ldr	x0, [x0]
     e74:      	add	x9, sp, #0x88
     e78:      	add	x1, sp, #0x88
     e7c:      	blr	x8
     e80:      	cbz	x0, 0x32b8 <generic_fexit_filter_arg+0x32b8>
     e84:      	cmp	w25, #0x7f
     e88:      	mov	w9, #0x7f               // =127
     e8c:      	mov	x1, x0
     e90:      	mov	x8, xzr
     e94:      	sub	x11, x19, x25
     e98:      	sub	w12, w25, #0x2
     e9c:      	sub	w13, w25, #0x1
     ea0:      	csel	w9, w25, w9, lo
     ea4:      	lsl	w10, w9, #3
     ea8:      	mov	x9, x0
     eac:      	str	w10, [x9], #0x5
     eb0:      	neg	x10, x25
     eb4:      	add	w14, w13, w8
     eb8:      	cmp	x11, x8
     ebc:      	and	x14, x14, #0xfff
     ec0:      	ldrb	w14, [x29, x14]
     ec4:      	sturb	w14, [x9, #-0x1]
     ec8:      	b.eq	0xef0 <generic_fexit_filter_arg+0xef0>
     ecc:      	cmn	x8, #0x7e
     ed0:      	b.eq	0xef0 <generic_fexit_filter_arg+0xef0>
     ed4:      	add	w14, w12, w8
     ed8:      	sub	x8, x8, #0x2
     edc:      	and	x14, x14, #0xfff
     ee0:      	cmp	x10, x8
     ee4:      	ldrb	w14, [x29, x14]
     ee8:      	strb	w14, [x9], #0x2
     eec:      	b.ne	0xeb4 <generic_fexit_filter_arg+0xeb4>
     ef0:      	mov	w8, #0x1                // =1
     ef4:      	mov	x0, x22
     ef8:      	b	0x32a8 <generic_fexit_filter_arg+0x32a8>
     efc:      	mov	x22, xzr
     f00:      	ldr	x0, [sp, #0x38]
     f04:      	ldp	x12, x16, [sp, #0x48]
     f08:      	mov	w17, #0x1               // =1
     f0c:      	cbnz	x22, 0x140 <generic_fexit_filter_arg+0x140>
     f10:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
     f14:      	ldp	w11, w8, [x21, #0x10]
     f18:      	cmp	w9, #0xc
     f1c:      	b.hi	0x1a98 <generic_fexit_filter_arg+0x1a98>
     f20:      	lsl	w10, w17, w9
     f24:      	mov	w12, #0x1402            // =5122
     f28:      	tst	w10, w12
     f2c:      	b.eq	0x1a98 <generic_fexit_filter_arg+0x1a98>
     f30:      	ldr	w10, [x25]
     f34:      	cmp	w11, w10
     f38:      	ccmp	w10, w8, #0x0, le
     f3c:      	cset	w8, le
     f40:      	b	0x1aa8 <generic_fexit_filter_arg+0x1aa8>
     f44:      	cmp	w8, #0x1c
     f48:      	b.eq	0x1578 <generic_fexit_filter_arg+0x1578>
     f4c:      	mov	x25, x10
     f50:      	cmp	w8, #0x1a
     f54:      	b.eq	0x14c0 <generic_fexit_filter_arg+0x14c0>
     f58:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
     f5c:      	cmp	w8, #0x12
     f60:      	b.eq	0xf80 <generic_fexit_filter_arg+0xf80>
     f64:      	cmp	w8, #0x13
     f68:      	b.ne	0x1ce4 <generic_fexit_filter_arg+0x1ce4>
     f6c:      	ldrh	w29, [x25, #0x22]
     f70:      	mov	w11, wzr
     f74:      	mov	w13, wzr
     f78:      	mov	x19, xzr
     f7c:      	b	0xfd0 <generic_fexit_filter_arg+0xfd0>
     f80:      	ldrh	w29, [x25, #0x20]
     f84:      	mov	w11, wzr
     f88:      	mov	w13, wzr
     f8c:      	mov	x19, xzr
     f90:      	b	0xfd0 <generic_fexit_filter_arg+0xfd0>
     f94:      	cmp	w8, #0x1c
     f98:      	b.eq	0x16f8 <generic_fexit_filter_arg+0x16f8>
     f9c:      	cmp	w8, #0x1d
     fa0:      	b.ne	0x1ce4 <generic_fexit_filter_arg+0x1ce4>
     fa4:      	cmp	w9, #0x7
     fa8:      	b.ne	0x1c54 <generic_fexit_filter_arg+0x1c54>
     fac:      	cbnz	x10, 0x1c64 <generic_fexit_filter_arg+0x1c64>
     fb0:      	mov	x19, xzr
     fb4:      	b	0x1c78 <generic_fexit_filter_arg+0x1c78>
     fb8:      	ldp	w11, w13, [x25, #0x10]
     fbc:      	ldr	x19, [x25, #0x18]
     fc0:      	b	0xfcc <generic_fexit_filter_arg+0xfcc>
     fc4:      	ldp	w11, w13, [x25]
     fc8:      	ldr	x19, [x25, #0x8]
     fcc:      	mov	x29, xzr
     fd0:      	mov	x22, xzr
     fd4:      	cmp	w8, #0x11
     fd8:      	b.gt	0x1004 <generic_fexit_filter_arg+0x1004>
     fdc:      	sub	w9, w8, #0xd
     fe0:      	cmp	w9, #0x2
     fe4:      	b.lo	0x1030 <generic_fexit_filter_arg+0x1030>
     fe8:      	ldr	x19, [sp, #0x30]
     fec:      	sub	w9, w8, #0xf
     ff0:      	cmp	w9, #0x2
     ff4:      	b.lo	0x11f8 <generic_fexit_filter_arg+0x11f8>
     ff8:      	cmp	w8, #0x11
     ffc:      	b.eq	0x16fc <generic_fexit_filter_arg+0x16fc>
    1000:      	b	0x1ce4 <generic_fexit_filter_arg+0x1ce4>
    1004:      	cmp	w8, #0x19
    1008:      	b.hi	0x11e8 <generic_fexit_filter_arg+0x11e8>
    100c:      	lsl	w9, w17, w8
    1010:      	mov	w10, #0x500000          // =5242880
    1014:      	tst	w9, w10
    1018:      	b.ne	0x12e4 <generic_fexit_filter_arg+0x12e4>
    101c:      	mov	w10, #0xa00000          // =10485760
    1020:      	tst	w9, w10
    1024:      	b.ne	0x12f8 <generic_fexit_filter_arg+0x12f8>
    1028:      	tst	w9, #0x3000000
    102c:      	b.eq	0x11e8 <generic_fexit_filter_arg+0x11e8>
    1030:      	ldrh	w8, [x25, #0x26]
    1034:      	cmp	w8, #0xa
    1038:      	b.eq	0x1354 <generic_fexit_filter_arg+0x1354>
    103c:      	cmp	w8, #0x2
    1040:      	b.ne	0x13e0 <generic_fexit_filter_arg+0x13e0>
    1044:      	ldr	w8, [x21, #0x10]
    1048:      	adrp	x0, 0x1000 <generic_fexit_filter_arg+0x1000>
    104c:      	add	x9, sp, #0xac
    1050:      	add	x1, sp, #0xac
    1054:      	str	w8, [sp, #0xac]
    1058:      	mov	w8, #0x1                // =1
    105c:      	mov	w22, w11
    1060:      	ldr	x0, [x0]
    1064:      	blr	x8
    1068:      	ldr	x19, [sp, #0x30]
    106c:      	cbz	x0, 0x1d88 <generic_fexit_filter_arg+0x1d88>
    1070:      	mov	w8, #0x20               // =32
    1074:      	add	x1, sp, #0x88
    1078:      	stp	w8, w22, [sp, #0x88]
    107c:      	b	0x139c <generic_fexit_filter_arg+0x139c>
    1080:      	cmp	w9, #0xc
    1084:      	b.hi	0x1dd8 <generic_fexit_filter_arg+0x1dd8>
    1088:      	lsl	w11, w17, w9
    108c:      	mov	w13, #0x1402            // =5122
    1090:      	tst	w11, w13
    1094:      	b.eq	0x1dd8 <generic_fexit_filter_arg+0x1dd8>
    1098:      	ldr	w11, [x25]
    109c:      	cmp	w11, w10
    10a0:      	b.gt	0x140 <generic_fexit_filter_arg+0x140>
    10a4:      	b	0x1df4 <generic_fexit_filter_arg+0x1df4>
    10a8:      	str	x23, [sp, #0x28]
    10ac:      	mov	x19, xzr
    10b0:      	mov	w22, wzr
    10b4:      	add	x23, x21, #0x10
    10b8:      	ldr	w8, [x23, x19, lsl #2]
    10bc:      	adrp	x0, 0x1000 <generic_fexit_filter_arg+0x1000>
    10c0:      	add	x9, sp, #0x60
    10c4:      	add	x1, sp, #0x60
    10c8:      	str	w8, [sp, #0x60]
    10cc:      	mov	w8, #0x1                // =1
    10d0:      	ldr	x0, [x0]
    10d4:      	blr	x8
    10d8:      	cbz	x0, 0x1cec <generic_fexit_filter_arg+0x1cec>
    10dc:      	ldr	x16, [sp, #0x50]
    10e0:      	mov	w17, #0x1               // =1
    10e4:      	cbz	w29, 0x1150 <generic_fexit_filter_arg+0x1150>
    10e8:      	mov	x8, xzr
    10ec:      	mov	x9, x25
    10f0:      	mov	x10, x29
    10f4:      	b	0x110c <generic_fexit_filter_arg+0x110c>
    10f8:      	add	x8, x8, #0x1
    10fc:      	sub	x10, x10, #0x1
    1100:      	add	x9, x9, #0x1
    1104:      	cmp	x8, x29
    1108:      	b.eq	0x1150 <generic_fexit_filter_arg+0x1150>
    110c:      	mov	x11, xzr
    1110:      	nop
    1114:      	nop
    1118:      	nop
    111c:      	nop
    1120:      	cmp	x10, x11
    1124:      	b.eq	0x10f8 <generic_fexit_filter_arg+0x10f8>
    1128:      	ldrb	w12, [x0, x11]
    112c:      	cbz	w12, 0x114c <generic_fexit_filter_arg+0x114c>
    1130:      	cmp	x11, #0x62
    1134:      	b.hi	0x10f8 <generic_fexit_filter_arg+0x10f8>
    1138:      	ldrb	w13, [x9, x11]
    113c:      	add	x11, x11, #0x1
    1140:      	cmp	w13, w12
    1144:      	b.eq	0x1120 <generic_fexit_filter_arg+0x1120>
    1148:      	b	0x10f8 <generic_fexit_filter_arg+0x10f8>
    114c:      	tbz	w8, #0x1f, 0x19bc <generic_fexit_filter_arg+0x19bc>
    1150:      	ldr	w9, [x21, #0x8]
    1154:      	add	w8, w22, #0xc
    1158:      	cmp	w8, w9
    115c:      	b.hs	0x1170 <generic_fexit_filter_arg+0x1170>
    1160:      	add	x19, x19, #0x1
    1164:      	add	w22, w22, #0x4
    1168:      	cmp	x19, #0x64
    116c:      	b.ne	0x10b8 <generic_fexit_filter_arg+0x10b8>
    1170:      	mov	x22, xzr
    1174:      	b	0x1d0c <generic_fexit_filter_arg+0x1d0c>
    1178:      	and	w8, w29, #0xffff
    117c:      	cmp	w8, #0x90
    1180:      	b.hi	0x178c <generic_fexit_filter_arg+0x178c>
    1184:      	and	w8, w29, #0xff
    1188:      	mov	w9, #0xab               // =171
    118c:      	tst	w29, #0xffff
    1190:      	mul	w8, w8, w9
    1194:      	mov	w9, #0x18               // =24
    1198:      	lsr	w8, w8, #12
    119c:      	msub	w8, w8, w9, w29
    11a0:      	b.eq	0x11b4 <generic_fexit_filter_arg+0x11b4>
    11a4:      	tst	w8, #0xff
    11a8:      	mov	w9, w29
    11ac:      	mov	w11, w29
    11b0:      	b.eq	0x11d0 <generic_fexit_filter_arg+0x11d0>
    11b4:      	sub	w8, w29, w8, uxtb
    11b8:      	and	w9, w8, #0xffff
    11bc:      	add	w8, w8, #0x18
    11c0:      	and	w11, w8, #0xffff
    11c4:      	cmp	w9, #0x78
    11c8:      	b.hi	0x2850 <generic_fexit_filter_arg+0x2850>
    11cc:      	mov	w9, w11
    11d0:      	and	w8, w9, #0xff
    11d4:      	mov	w9, #0xab               // =171
    11d8:      	mul	w8, w8, w9
    11dc:      	lsr	w8, w8, #12
    11e0:      	sub	w10, w8, #0x1
    11e4:      	b	0x28a0 <generic_fexit_filter_arg+0x28a0>
    11e8:      	ldr	x19, [sp, #0x30]
    11ec:      	sub	w8, w8, #0x12
    11f0:      	cmp	w8, #0x2
    11f4:      	b.hs	0x1ce4 <generic_fexit_filter_arg+0x1ce4>
    11f8:      	ldrb	w8, [x21, #0x10]
    11fc:      	adrp	x0, 0x1000 <generic_fexit_filter_arg+0x1000>
    1200:      	add	x9, sp, #0xac
    1204:      	add	x1, sp, #0xac
    1208:      	str	w8, [sp, #0xac]
    120c:      	mov	w8, #0x1                // =1
    1210:      	ldr	x0, [x0]
    1214:      	blr	x8
    1218:      	cbz	x0, 0x1cd4 <generic_fexit_filter_arg+0x1cd4>
    121c:      	str	x29, [sp, #0x88]
    1220:      	mov	w8, #0x1                // =1
    1224:      	add	x9, sp, #0x88
    1228:      	add	x1, sp, #0x88
    122c:      	b	0x1730 <generic_fexit_filter_arg+0x1730>
    1230:      	cmp	w8, #0x1
    1234:      	b.eq	0x19c4 <generic_fexit_filter_arg+0x19c4>
    1238:      	cmp	w8, #0x2
    123c:      	b.ne	0x19d0 <generic_fexit_filter_arg+0x19d0>
    1240:      	ldrb	w10, [x25]
    1244:      	cmp	w9, w10
    1248:      	b.hi	0x140 <generic_fexit_filter_arg+0x140>
    124c:      	b	0x19d0 <generic_fexit_filter_arg+0x19d0>
    1250:      	cmp	w8, #0x1
    1254:      	b.eq	0x1a04 <generic_fexit_filter_arg+0x1a04>
    1258:      	cmp	w8, #0x2
    125c:      	b.ne	0x1a10 <generic_fexit_filter_arg+0x1a10>
    1260:      	ldrh	w10, [x25]
    1264:      	cmp	w9, w10
    1268:      	b.hi	0x140 <generic_fexit_filter_arg+0x140>
    126c:      	b	0x1a10 <generic_fexit_filter_arg+0x1a10>
    1270:      	ldrb	w8, [x21, #0x10]
    1274:      	adrp	x0, 0x1000 <generic_fexit_filter_arg+0x1000>
    1278:      	add	x9, sp, #0x88
    127c:      	add	x1, sp, #0x88
    1280:      	str	w8, [sp, #0x88]
    1284:      	mov	w8, #0x1                // =1
    1288:      	ldr	x0, [x0]
    128c:      	blr	x8
    1290:      	cbz	x0, 0x1cd4 <generic_fexit_filter_arg+0x1cd4>
    1294:      	ldrb	w8, [x25]
    1298:      	add	x9, sp, #0x60
    129c:      	str	x8, [sp, #0x60]
    12a0:      	mov	w8, #0x1                // =1
    12a4:      	b	0x12dc <generic_fexit_filter_arg+0x12dc>
    12a8:      	ldrb	w8, [x21, #0x10]
    12ac:      	adrp	x0, 0x1000 <generic_fexit_filter_arg+0x1000>
    12b0:      	add	x9, sp, #0x88
    12b4:      	add	x1, sp, #0x88
    12b8:      	str	w8, [sp, #0x88]
    12bc:      	mov	w8, #0x1                // =1
    12c0:      	ldr	x0, [x0]
    12c4:      	blr	x8
    12c8:      	cbz	x0, 0x1cd4 <generic_fexit_filter_arg+0x1cd4>
    12cc:      	ldrh	w8, [x25]
    12d0:      	add	x9, sp, #0x60
    12d4:      	str	x8, [sp, #0x60]
    12d8:      	mov	w8, #0x1                // =1
    12dc:      	add	x1, sp, #0x60
    12e0:      	b	0x1730 <generic_fexit_filter_arg+0x1730>
    12e4:      	ldr	x19, [sp, #0x30]
    12e8:      	cmp	x29, #0x400
    12ec:      	cset	w22, lo
    12f0:      	cbnz	x22, 0x140 <generic_fexit_filter_arg+0x140>
    12f4:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    12f8:      	ldr	x19, [sp, #0x30]
    12fc:      	cmp	x29, #0x3ff
    1300:      	cset	w22, hi
    1304:      	cbnz	x22, 0x140 <generic_fexit_filter_arg+0x140>
    1308:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    130c:      	mov	x22, xzr
    1310:      	ldr	x19, [sp, #0x30]
    1314:      	ldr	x0, [sp, #0x38]
    1318:      	ldp	x12, x16, [sp, #0x48]
    131c:      	mov	w17, #0x1               // =1
    1320:      	b	0x1d18 <generic_fexit_filter_arg+0x1d18>
    1324:      	cmp	x0, #0x0
    1328:      	ldr	x0, [sp, #0x38]
    132c:      	ldp	x12, x16, [sp, #0x48]
    1330:      	mov	w17, #0x1               // =1
    1334:      	cset	w8, eq
    1338:      	mov	w22, w8
    133c:      	cbnz	x22, 0x140 <generic_fexit_filter_arg+0x140>
    1340:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    1344:      	cmp	w8, #0x101
    1348:      	b.hs	0x19a0 <generic_fexit_filter_arg+0x19a0>
    134c:      	mov	w11, #0x100             // =256
    1350:      	b	0x2390 <generic_fexit_filter_arg+0x2390>
    1354:      	ldr	w8, [x21, #0x14]
    1358:      	adrp	x0, 0x1000 <generic_fexit_filter_arg+0x1000>
    135c:      	add	x9, sp, #0xac
    1360:      	add	x1, sp, #0xac
    1364:      	str	w8, [sp, #0xac]
    1368:      	mov	w8, #0x1                // =1
    136c:      	mov	w25, w13
    1370:      	mov	w22, w11
    1374:      	ldr	x0, [x0]
    1378:      	blr	x8
    137c:      	cbz	x0, 0x1db0 <generic_fexit_filter_arg+0x1db0>
    1380:      	mov	w8, #0x80               // =128
    1384:      	stp	w25, w19, [sp, #0x90]
    1388:      	add	x1, sp, #0x88
    138c:      	stp	w8, w22, [sp, #0x88]
    1390:      	lsr	x8, x19, #32
    1394:      	ldr	x19, [sp, #0x30]
    1398:      	str	w8, [sp, #0x98]
    139c:      	mov	w8, #0x1                // =1
    13a0:      	blr	x8
    13a4:      	ldr	w8, [x21, #0x4]
    13a8:      	sub	w9, w8, #0x18
    13ac:      	cmp	w9, #0x2
    13b0:      	b.lo	0x19b4 <generic_fexit_filter_arg+0x19b4>
    13b4:      	ldp	x12, x16, [sp, #0x48]
    13b8:      	sub	w8, w8, #0xd
    13bc:      	mov	w17, #0x1               // =1
    13c0:      	cmp	w8, #0x1
    13c4:      	b.hi	0x1f54 <generic_fexit_filter_arg+0x1f54>
    13c8:      	cmp	x0, #0x0
    13cc:      	ldr	x0, [sp, #0x38]
    13d0:      	cset	w8, ne
    13d4:      	mov	w22, w8
    13d8:      	cbnz	x22, 0x140 <generic_fexit_filter_arg+0x140>
    13dc:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    13e0:      	ldr	x19, [sp, #0x30]
    13e4:      	mov	w8, wzr
    13e8:      	mov	w22, wzr
    13ec:      	cbnz	x22, 0x140 <generic_fexit_filter_arg+0x140>
    13f0:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    13f4:      	cmp	w8, #0x1e
    13f8:      	b.ne	0xc4 <generic_fexit_filter_arg+0xc4>
    13fc:      	ldr	w8, [x21, #0x10]
    1400:      	mov	w10, #0x5ea0            // =24224
    1404:      	and	x8, x8, #0x7
    1408:      	add	x9, x20, x8, lsl #2
    140c:      	ldr	w9, [x9, x10]
    1410:      	cbnz	w9, 0xc4 <generic_fexit_filter_arg+0xc4>
    1414:      	add	x8, x20, x8, lsl #3
    1418:      	ldr	x9, [x25]
    141c:      	ldr	x8, [x8, #0x5e78]
    1420:      	and	x8, x8, #0x7ff
    1424:      	add	x8, x20, x8
    1428:      	ldr	x8, [x8, #0x90]
    142c:      	bics	xzr, x8, x9
    1430:      	cset	w22, ne
    1434:      	cbnz	x22, 0x140 <generic_fexit_filter_arg+0x140>
    1438:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    143c:      	cmp	w8, #0x21
    1440:      	b.eq	0x1ae0 <generic_fexit_filter_arg+0x1ae0>
    1444:      	cmp	w8, #0x22
    1448:      	b.ne	0x32c4 <generic_fexit_filter_arg+0x32c4>
    144c:      	mov	w19, #0x10              // =16
    1450:      	ldr	w8, [x21, x19]
    1454:      	adrp	x0, 0x1000 <generic_fexit_filter_arg+0x1000>
    1458:      	add	x9, sp, #0x60
    145c:      	add	x1, sp, #0x60
    1460:      	str	w8, [sp, #0x60]
    1464:      	mov	w8, #0x1                // =1
    1468:      	ldr	x0, [x0]
    146c:      	blr	x8
    1470:      	cbz	x0, 0x32b8 <generic_fexit_filter_arg+0x32b8>
    1474:      	mov	x1, x0
    1478:      	mov	x0, x29
    147c:      	mov	x2, x25
    1480:      	bl	0x1480 <generic_fexit_filter_arg+0x1480>
    1484:      	tbz	w0, #0x1f, 0x2674 <generic_fexit_filter_arg+0x2674>
    1488:      	ldr	w8, [x21, #0x8]
    148c:      	ldp	x12, x16, [sp, #0x48]
    1490:      	add	x19, x19, #0x4
    1494:      	mov	w17, #0x1               // =1
    1498:      	mov	x22, xzr
    149c:      	sub	w9, w19, #0x8
    14a0:      	cmp	w9, w8
    14a4:      	b.hs	0x32c4 <generic_fexit_filter_arg+0x32c4>
    14a8:      	cmp	x19, #0x1a0
    14ac:      	b.ne	0x1450 <generic_fexit_filter_arg+0x1450>
    14b0:      	b	0x32c4 <generic_fexit_filter_arg+0x32c4>
    14b4:      	mov	x25, x10
    14b8:      	cmp	w8, #0x8
    14bc:      	b.ne	0xc4 <generic_fexit_filter_arg+0xc4>
    14c0:      	ldr	w8, [x21, #0x10]
    14c4:      	str	wzr, [sp, #0x88]
    14c8:      	adrp	x0, 0x1000 <generic_fexit_filter_arg+0x1000>
    14cc:      	add	x9, sp, #0x60
    14d0:      	add	x1, sp, #0x60
    14d4:      	str	w8, [sp, #0x60]
    14d8:      	mov	w8, #0x1                // =1
    14dc:      	ldr	x0, [x0]
    14e0:      	blr	x8
    14e4:      	mov	x22, xzr
    14e8:      	cbz	w29, 0x1ed0 <generic_fexit_filter_arg+0x1ed0>
    14ec:      	cbz	x0, 0x1ed0 <generic_fexit_filter_arg+0x1ed0>
    14f0:      	mov	x19, x0
    14f4:      	adrp	x0, 0x1000 <generic_fexit_filter_arg+0x1000>
    14f8:      	mov	w8, #0x1                // =1
    14fc:      	ldr	x0, [x0]
    1500:      	add	x9, sp, #0x88
    1504:      	add	x1, sp, #0x88
    1508:      	blr	x8
    150c:      	cbz	x0, 0x1ec8 <generic_fexit_filter_arg+0x1ec8>
    1510:      	lsl	w9, w29, #3
    1514:      	mov	x8, x0
    1518:      	mov	x2, x25
    151c:      	mov	w1, w29
    1520:      	str	w9, [x8], #0x4
    1524:      	mov	w9, #0x4                // =4
    1528:      	mov	x25, x0
    152c:      	mov	x0, x8
    1530:      	blr	x9
    1534:      	mov	w8, #0x1                // =1
    1538:      	mov	x0, x19
    153c:      	mov	x1, x25
    1540:      	blr	x8
    1544:      	cmp	x0, #0x0
    1548:      	cset	w22, ne
    154c:      	b	0x1ecc <generic_fexit_filter_arg+0x1ecc>
    1550:      	mov	w13, #0x100             // =256
    1554:      	sub	w8, w13, #0x100
    1558:      	ror	w8, w8, #0x8
    155c:      	cmp	w8, #0x2
    1560:      	b.gt	0x1988 <generic_fexit_filter_arg+0x1988>
    1564:      	cbz	w8, 0x1fc4 <generic_fexit_filter_arg+0x1fc4>
    1568:      	cmp	w8, #0x1
    156c:      	b.ne	0x1fbc <generic_fexit_filter_arg+0x1fbc>
    1570:      	mov	w11, #0x7               // =7
    1574:      	b	0x1fd0 <generic_fexit_filter_arg+0x1fd0>
    1578:      	ldrb	w8, [x21, #0x10]
    157c:      	ldrh	w19, [x25]
    1580:      	adrp	x0, 0x1000 <generic_fexit_filter_arg+0x1000>
    1584:      	add	x9, sp, #0x88
    1588:      	add	x1, sp, #0x88
    158c:      	str	w8, [sp, #0x88]
    1590:      	mov	w8, #0x1                // =1
    1594:      	ldr	x0, [x0]
    1598:      	blr	x8
    159c:      	cbz	x0, 0x1cd0 <generic_fexit_filter_arg+0x1cd0>
    15a0:      	str	x19, [sp, #0x60]
    15a4:      	mov	w8, #0x1                // =1
    15a8:      	add	x9, sp, #0x60
    15ac:      	add	x1, sp, #0x60
    15b0:      	blr	x8
    15b4:      	ldr	w9, [x21, #0x4]
    15b8:      	mov	w8, wzr
    15bc:      	cmp	w9, #0x1d
    15c0:      	b.hi	0x1cc0 <generic_fexit_filter_arg+0x1cc0>
    15c4:      	ldr	x19, [sp, #0x30]
    15c8:      	b	0x1744 <generic_fexit_filter_arg+0x1744>
    15cc:      	ldr	w8, [x21, #0x10]
    15d0:      	str	wzr, [sp, #0x88]
    15d4:      	adrp	x0, 0x1000 <generic_fexit_filter_arg+0x1000>
    15d8:      	add	x9, sp, #0x60
    15dc:      	add	x1, sp, #0x60
    15e0:      	str	w8, [sp, #0x60]
    15e4:      	mov	w8, #0x1                // =1
    15e8:      	ldr	x0, [x0]
    15ec:      	blr	x8
    15f0:      	mov	x22, xzr
    15f4:      	cbz	w25, 0x32bc <generic_fexit_filter_arg+0x32bc>
    15f8:      	cbz	x0, 0x32bc <generic_fexit_filter_arg+0x32bc>
    15fc:      	mov	x19, x0
    1600:      	adrp	x0, 0x1000 <generic_fexit_filter_arg+0x1000>
    1604:      	mov	w8, #0x1                // =1
    1608:      	ldr	x0, [x0]
    160c:      	add	x9, sp, #0x88
    1610:      	add	x1, sp, #0x88
    1614:      	blr	x8
    1618:      	cbz	x0, 0x32b8 <generic_fexit_filter_arg+0x32b8>
    161c:      	cmp	w25, #0xff
    1620:      	mov	w8, #0xff               // =255
    1624:      	mov	x22, x0
    1628:      	mov	x2, x29
    162c:      	csel	w1, w25, w8, lo
    1630:      	mov	x8, x0
    1634:      	lsl	w9, w1, #3
    1638:      	str	w9, [x8], #0x4
    163c:      	mov	w9, #0x4                // =4
    1640:      	mov	x0, x8
    1644:      	blr	x9
    1648:      	mov	w8, #0x1                // =1
    164c:      	mov	x0, x19
    1650:      	mov	x1, x22
    1654:      	b	0x32a8 <generic_fexit_filter_arg+0x32a8>
    1658:      	cmp	w25, #0x1, lsl #12      // =0x1000
    165c:      	str	wzr, [sp, #0x88]
    1660:      	b.ls	0x1ba8 <generic_fexit_filter_arg+0x1ba8>
    1664:      	mov	x22, xzr
    1668:      	b	0x32c4 <generic_fexit_filter_arg+0x32c4>
    166c:      	ldr	x8, [x25]
    1670:      	cmp	x11, x8
    1674:      	b.hi	0x1680 <generic_fexit_filter_arg+0x1680>
    1678:      	cmp	x8, x10
    167c:      	b.ls	0x140 <generic_fexit_filter_arg+0x140>
    1680:      	ldr	w10, [x21, #0x8]
    1684:      	cmp	w10, #0x19
    1688:      	b.lo	0xc4 <generic_fexit_filter_arg+0xc4>
    168c:      	ldp	x12, x11, [x21, #0x20]
    1690:      	cmp	w9, #0xc
    1694:      	b.eq	0x16a0 <generic_fexit_filter_arg+0x16a0>
    1698:      	cmp	w9, #0xa
    169c:      	b.ne	0x1d40 <generic_fexit_filter_arg+0x1d40>
    16a0:      	cmp	x12, x8
    16a4:      	ldr	x12, [sp, #0x48]
    16a8:      	b.gt	0x1d54 <generic_fexit_filter_arg+0x1d54>
    16ac:      	cmp	x8, x11
    16b0:      	b.le	0x140 <generic_fexit_filter_arg+0x140>
    16b4:      	b	0x1d54 <generic_fexit_filter_arg+0x1d54>
    16b8:      	ldr	x10, [x25]
    16bc:      	cmp	x11, x10
    16c0:      	ccmp	x10, x8, #0x2, ls
    16c4:      	cset	w8, ls
    16c8:      	ldr	w11, [x21, #0x8]
    16cc:      	cmp	w11, #0x19
    16d0:      	b.lo	0x2aa0 <generic_fexit_filter_arg+0x2aa0>
    16d4:      	ldp	x13, x12, [x21, #0x20]
    16d8:      	cmp	w9, #0xc
    16dc:      	b.eq	0x16e8 <generic_fexit_filter_arg+0x16e8>
    16e0:      	cmp	w9, #0xa
    16e4:      	b.ne	0x1c18 <generic_fexit_filter_arg+0x1c18>
    16e8:      	cmp	x13, x10
    16ec:      	ccmp	x10, x12, #0x0, le
    16f0:      	cset	w12, le
    16f4:      	b	0x1c24 <generic_fexit_filter_arg+0x1c24>
    16f8:      	ldrh	w22, [x25, #0x26]
    16fc:      	ldrb	w8, [x21, #0x10]
    1700:      	adrp	x0, 0x1000 <generic_fexit_filter_arg+0x1000>
    1704:      	add	x9, sp, #0xac
    1708:      	add	x1, sp, #0xac
    170c:      	str	w8, [sp, #0xac]
    1710:      	mov	w8, #0x1                // =1
    1714:      	ldr	x0, [x0]
    1718:      	blr	x8
    171c:      	cbz	x0, 0x1cd4 <generic_fexit_filter_arg+0x1cd4>
    1720:      	str	x22, [sp, #0x88]
    1724:      	mov	w8, #0x1                // =1
    1728:      	add	x9, sp, #0x88
    172c:      	add	x1, sp, #0x88
    1730:      	blr	x8
    1734:      	ldr	w9, [x21, #0x4]
    1738:      	mov	w8, wzr
    173c:      	cmp	w9, #0x1d
    1740:      	b.hi	0x1cc4 <generic_fexit_filter_arg+0x1cc4>
    1744:      	mov	w17, #0x1               // =1
    1748:      	mov	w10, #0x8400            // =33792
    174c:      	lsl	w9, w17, w9
    1750:      	movk	w10, #0x3003, lsl #16
    1754:      	tst	w9, w10
    1758:      	ldp	x12, x16, [sp, #0x48]
    175c:      	b.eq	0x176c <generic_fexit_filter_arg+0x176c>
    1760:      	cmp	x0, #0x0
    1764:      	cset	w8, ne
    1768:      	b	0x1784 <generic_fexit_filter_arg+0x1784>
    176c:      	mov	w10, #0x800             // =2048
    1770:      	movk	w10, #0xc, lsl #16
    1774:      	tst	w9, w10
    1778:      	b.eq	0x1784 <generic_fexit_filter_arg+0x1784>
    177c:      	cmp	x0, #0x0
    1780:      	cset	w8, eq
    1784:      	mov	w22, w8
    1788:      	b	0x1ce0 <generic_fexit_filter_arg+0x1ce0>
    178c:      	cmp	w8, #0x101
    1790:      	b.hs	0x1eb4 <generic_fexit_filter_arg+0x1eb4>
    1794:      	mov	w11, #0x100             // =256
    1798:      	b	0x2850 <generic_fexit_filter_arg+0x2850>
    179c:      	ldr	x11, [x25]
    17a0:      	cmp	x11, x10
    17a4:      	b.hi	0x140 <generic_fexit_filter_arg+0x140>
    17a8:      	b	0x17b8 <generic_fexit_filter_arg+0x17b8>
    17ac:      	ldr	x11, [x25]
    17b0:      	cmp	x11, x10
    17b4:      	b.lo	0x140 <generic_fexit_filter_arg+0x140>
    17b8:      	ldr	w10, [x21, #0x8]
    17bc:      	cmp	w10, #0x11
    17c0:      	b.lo	0x124 <generic_fexit_filter_arg+0x124>
    17c4:      	ldr	x11, [x21, #0x18]
    17c8:      	cmp	w8, #0x2
    17cc:      	b.le	0x17f0 <generic_fexit_filter_arg+0x17f0>
    17d0:      	sub	w12, w8, #0x3
    17d4:      	cmp	w12, #0x2
    17d8:      	b.hs	0x1824 <generic_fexit_filter_arg+0x1824>
    17dc:      	ldr	x12, [x25]
    17e0:      	cmp	x12, x11
    17e4:      	ldr	x12, [sp, #0x48]
    17e8:      	b.ne	0x2264 <generic_fexit_filter_arg+0x2264>
    17ec:      	b	0x31dc <generic_fexit_filter_arg+0x31dc>
    17f0:      	cmp	w8, #0x1
    17f4:      	b.eq	0x18d0 <generic_fexit_filter_arg+0x18d0>
    17f8:      	cmp	w8, #0x2
    17fc:      	b.ne	0x2264 <generic_fexit_filter_arg+0x2264>
    1800:      	cmp	w9, #0xc
    1804:      	b.eq	0x1810 <generic_fexit_filter_arg+0x1810>
    1808:      	cmp	w9, #0xa
    180c:      	b.ne	0x2254 <generic_fexit_filter_arg+0x2254>
    1810:      	ldr	x12, [x25]
    1814:      	cmp	x12, x11
    1818:      	ldr	x12, [sp, #0x48]
    181c:      	b.lt	0x140 <generic_fexit_filter_arg+0x140>
    1820:      	b	0x2264 <generic_fexit_filter_arg+0x2264>
    1824:      	ldr	x12, [sp, #0x48]
    1828:      	cmp	w8, #0xc
    182c:      	b.ne	0x2264 <generic_fexit_filter_arg+0x2264>
    1830:      	ldr	x12, [x25]
    1834:      	tst	x12, x11
    1838:      	ldr	x12, [sp, #0x48]
    183c:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
    1840:      	b	0x2264 <generic_fexit_filter_arg+0x2264>
    1844:      	cmp	w8, #0xc
    1848:      	b.ne	0x19d0 <generic_fexit_filter_arg+0x19d0>
    184c:      	ldrb	w10, [x25]
    1850:      	tst	w9, w10
    1854:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
    1858:      	b	0x19d0 <generic_fexit_filter_arg+0x19d0>
    185c:      	cmp	w8, #0xc
    1860:      	b.ne	0x1a10 <generic_fexit_filter_arg+0x1a10>
    1864:      	ldrh	w10, [x25]
    1868:      	tst	w9, w10
    186c:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
    1870:      	b	0x1a10 <generic_fexit_filter_arg+0x1a10>
    1874:      	ldr	w9, [x21, #0x8]
    1878:      	cmp	w9, #0xd
    187c:      	b.lo	0x664 <generic_fexit_filter_arg+0x664>
    1880:      	ldr	w10, [x21, #0x14]
    1884:      	cbz	w10, 0x664 <generic_fexit_filter_arg+0x664>
    1888:      	cmp	w10, w8
    188c:      	b.eq	0x4a8 <generic_fexit_filter_arg+0x4a8>
    1890:      	cmp	w9, #0x11
    1894:      	b.lo	0x664 <generic_fexit_filter_arg+0x664>
    1898:      	ldr	w10, [x21, #0x18]
    189c:      	cbz	w10, 0x664 <generic_fexit_filter_arg+0x664>
    18a0:      	cmp	w10, w8
    18a4:      	b.eq	0x4a8 <generic_fexit_filter_arg+0x4a8>
    18a8:      	cmp	w9, #0x15
    18ac:      	b.lo	0x18c4 <generic_fexit_filter_arg+0x18c4>
    18b0:      	ldr	w9, [x21, #0x1c]
    18b4:      	cbz	w9, 0x18c4 <generic_fexit_filter_arg+0x18c4>
    18b8:      	cmp	w9, w8
    18bc:      	cset	w22, eq
    18c0:      	b	0x18c8 <generic_fexit_filter_arg+0x18c8>
    18c4:      	mov	x22, xzr
    18c8:      	ldr	x19, [sp, #0x30]
    18cc:      	b	0x2d20 <generic_fexit_filter_arg+0x2d20>
    18d0:      	cmp	w9, #0xc
    18d4:      	b.eq	0x18e0 <generic_fexit_filter_arg+0x18e0>
    18d8:      	cmp	w9, #0xa
    18dc:      	b.ne	0x2240 <generic_fexit_filter_arg+0x2240>
    18e0:      	ldr	x12, [x25]
    18e4:      	cmp	x12, x11
    18e8:      	ldr	x12, [sp, #0x48]
    18ec:      	b.gt	0x140 <generic_fexit_filter_arg+0x140>
    18f0:      	b	0x2264 <generic_fexit_filter_arg+0x2264>
    18f4:      	ldp	w8, w11, [x21, #0x10]
    18f8:      	ldrb	w9, [x25]
    18fc:      	cmp	w8, w9
    1900:      	ldr	w10, [x21, #0x8]
    1904:      	ccmp	w11, w9, #0x0, ls
    1908:      	cset	w8, hs
    190c:      	cmp	w10, #0x11
    1910:      	b.hs	0x1938 <generic_fexit_filter_arg+0x1938>
    1914:      	b	0x1980 <generic_fexit_filter_arg+0x1980>
    1918:      	ldp	w8, w11, [x21, #0x10]
    191c:      	ldrh	w9, [x25]
    1920:      	cmp	w8, w9
    1924:      	ldr	w10, [x21, #0x8]
    1928:      	ccmp	w11, w9, #0x0, ls
    192c:      	cset	w8, hs
    1930:      	cmp	w10, #0x11
    1934:      	b.lo	0x1980 <generic_fexit_filter_arg+0x1980>
    1938:      	ldp	w11, w12, [x21, #0x18]
    193c:      	cmp	w11, w9
    1940:      	ccmp	w12, w9, #0x0, ls
    1944:      	ldr	x12, [sp, #0x48]
    1948:      	csinc	w8, w8, wzr, lo
    194c:      	cmp	w10, #0x19
    1950:      	b.lo	0x1980 <generic_fexit_filter_arg+0x1980>
    1954:      	ldp	w11, w12, [x21, #0x20]
    1958:      	cmp	w11, w9
    195c:      	ccmp	w12, w9, #0x0, ls
    1960:      	ldr	x12, [sp, #0x48]
    1964:      	csinc	w8, w8, wzr, lo
    1968:      	cmp	w10, #0x21
    196c:      	b.lo	0x1980 <generic_fexit_filter_arg+0x1980>
    1970:      	ldp	w10, w11, [x21, #0x28]
    1974:      	cmp	w10, w9
    1978:      	ccmp	w11, w9, #0x0, ls
    197c:      	csinc	w8, w8, wzr, lo
    1980:      	tbz	w8, #0x0, 0x140 <generic_fexit_filter_arg+0x140>
    1984:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    1988:      	cmp	w8, #0x3
    198c:      	b.eq	0x1fcc <generic_fexit_filter_arg+0x1fcc>
    1990:      	cmp	w8, #0x7
    1994:      	b.ne	0x1fbc <generic_fexit_filter_arg+0x1fbc>
    1998:      	mov	w11, #0x9               // =9
    199c:      	b	0x1fd0 <generic_fexit_filter_arg+0x1fd0>
    19a0:      	and	w8, w29, #0xffff
    19a4:      	cmp	w8, #0x201
    19a8:      	b.hs	0x1f44 <generic_fexit_filter_arg+0x1f44>
    19ac:      	mov	w11, #0x200             // =512
    19b0:      	b	0x2390 <generic_fexit_filter_arg+0x2390>
    19b4:      	cmp	x0, #0x0
    19b8:      	b	0x1d94 <generic_fexit_filter_arg+0x1d94>
    19bc:      	mov	w22, #0x1               // =1
    19c0:      	b	0x1d0c <generic_fexit_filter_arg+0x1d0c>
    19c4:      	ldrb	w10, [x25]
    19c8:      	cmp	w9, w10
    19cc:      	b.lo	0x140 <generic_fexit_filter_arg+0x140>
    19d0:      	ldr	w9, [x21, #0x8]
    19d4:      	cmp	w9, #0xd
    19d8:      	b.lo	0x124 <generic_fexit_filter_arg+0x124>
    19dc:      	ldr	w10, [x21, #0x14]
    19e0:      	cmp	w8, #0x2
    19e4:      	b.le	0x1f04 <generic_fexit_filter_arg+0x1f04>
    19e8:      	sub	w11, w8, #0x3
    19ec:      	cmp	w11, #0x2
    19f0:      	b.hs	0x22ec <generic_fexit_filter_arg+0x22ec>
    19f4:      	ldrb	w11, [x25]
    19f8:      	cmp	w10, w11
    19fc:      	b.ne	0x2594 <generic_fexit_filter_arg+0x2594>
    1a00:      	b	0x31dc <generic_fexit_filter_arg+0x31dc>
    1a04:      	ldrh	w10, [x25]
    1a08:      	cmp	w9, w10
    1a0c:      	b.lo	0x140 <generic_fexit_filter_arg+0x140>
    1a10:      	ldr	w9, [x21, #0x8]
    1a14:      	cmp	w9, #0xd
    1a18:      	b.lo	0x124 <generic_fexit_filter_arg+0x124>
    1a1c:      	ldr	w10, [x21, #0x14]
    1a20:      	cmp	w8, #0x2
    1a24:      	b.le	0x1f24 <generic_fexit_filter_arg+0x1f24>
    1a28:      	sub	w11, w8, #0x3
    1a2c:      	cmp	w11, #0x2
    1a30:      	b.hs	0x2304 <generic_fexit_filter_arg+0x2304>
    1a34:      	ldrh	w11, [x25]
    1a38:      	cmp	w10, w11
    1a3c:      	b.ne	0x25d0 <generic_fexit_filter_arg+0x25d0>
    1a40:      	b	0x31dc <generic_fexit_filter_arg+0x31dc>
    1a44:      	ldr	w8, [x25]
    1a48:      	cmp	w11, w8
    1a4c:      	b.hi	0x1a58 <generic_fexit_filter_arg+0x1a58>
    1a50:      	cmp	w8, w10
    1a54:      	b.ls	0x140 <generic_fexit_filter_arg+0x140>
    1a58:      	ldr	w10, [x21, #0x8]
    1a5c:      	cmp	w10, #0x11
    1a60:      	b.lo	0xc4 <generic_fexit_filter_arg+0xc4>
    1a64:      	ldp	w12, w11, [x21, #0x18]
    1a68:      	cmp	w9, #0xc
    1a6c:      	b.hi	0x2160 <generic_fexit_filter_arg+0x2160>
    1a70:      	lsl	w13, w17, w9
    1a74:      	mov	w14, #0x1402            // =5122
    1a78:      	tst	w13, w14
    1a7c:      	b.eq	0x2160 <generic_fexit_filter_arg+0x2160>
    1a80:      	cmp	w12, w8
    1a84:      	ldr	x12, [sp, #0x48]
    1a88:      	b.gt	0x2174 <generic_fexit_filter_arg+0x2174>
    1a8c:      	cmp	w8, w11
    1a90:      	b.le	0x140 <generic_fexit_filter_arg+0x140>
    1a94:      	b	0x2174 <generic_fexit_filter_arg+0x2174>
    1a98:      	ldr	w10, [x25]
    1a9c:      	cmp	w11, w10
    1aa0:      	ccmp	w10, w8, #0x2, ls
    1aa4:      	cset	w8, ls
    1aa8:      	ldr	w11, [x21, #0x8]
    1aac:      	cmp	w11, #0x11
    1ab0:      	b.lo	0x2aa0 <generic_fexit_filter_arg+0x2aa0>
    1ab4:      	ldp	w13, w12, [x21, #0x18]
    1ab8:      	cmp	w9, #0xc
    1abc:      	b.hi	0x1f68 <generic_fexit_filter_arg+0x1f68>
    1ac0:      	lsl	w14, w17, w9
    1ac4:      	mov	w15, #0x1402            // =5122
    1ac8:      	tst	w14, w15
    1acc:      	b.eq	0x1f68 <generic_fexit_filter_arg+0x1f68>
    1ad0:      	cmp	w13, w10
    1ad4:      	ccmp	w10, w12, #0x0, le
    1ad8:      	cset	w12, le
    1adc:      	b	0x1f74 <generic_fexit_filter_arg+0x1f74>
    1ae0:      	str	x23, [sp, #0x28]
    1ae4:      	mov	x19, xzr
    1ae8:      	mov	w22, wzr
    1aec:      	add	x23, x21, #0x10
    1af0:      	ldr	w8, [x23, x19, lsl #2]
    1af4:      	adrp	x0, 0x1000 <generic_fexit_filter_arg+0x1000>
    1af8:      	add	x9, sp, #0x60
    1afc:      	add	x1, sp, #0x60
    1b00:      	str	w8, [sp, #0x60]
    1b04:      	mov	w8, #0x1                // =1
    1b08:      	ldr	x0, [x0]
    1b0c:      	blr	x8
    1b10:      	cbz	x0, 0x2600 <generic_fexit_filter_arg+0x2600>
    1b14:      	ldr	x16, [sp, #0x50]
    1b18:      	mov	w17, #0x1               // =1
    1b1c:      	cbz	w25, 0x1b78 <generic_fexit_filter_arg+0x1b78>
    1b20:      	mov	x8, xzr
    1b24:      	mov	x9, x29
    1b28:      	mov	x10, x25
    1b2c:      	b	0x1b44 <generic_fexit_filter_arg+0x1b44>
    1b30:      	add	x8, x8, #0x1
    1b34:      	sub	x10, x10, #0x1
    1b38:      	add	x9, x9, #0x1
    1b3c:      	cmp	x8, x25
    1b40:      	b.eq	0x1b78 <generic_fexit_filter_arg+0x1b78>
    1b44:      	mov	x11, xzr
    1b48:      	cmp	x10, x11
    1b4c:      	b.eq	0x1b30 <generic_fexit_filter_arg+0x1b30>
    1b50:      	ldrb	w12, [x0, x11]
    1b54:      	cbz	w12, 0x1b74 <generic_fexit_filter_arg+0x1b74>
    1b58:      	cmp	x11, #0x62
    1b5c:      	b.hi	0x1b30 <generic_fexit_filter_arg+0x1b30>
    1b60:      	ldrb	w13, [x9, x11]
    1b64:      	add	x11, x11, #0x1
    1b68:      	cmp	w13, w12
    1b6c:      	b.eq	0x1b48 <generic_fexit_filter_arg+0x1b48>
    1b70:      	b	0x1b30 <generic_fexit_filter_arg+0x1b30>
    1b74:      	tbz	w8, #0x1f, 0x2a80 <generic_fexit_filter_arg+0x2a80>
    1b78:      	ldr	w9, [x21, #0x8]
    1b7c:      	add	w8, w22, #0xc
    1b80:      	cmp	w8, w9
    1b84:      	b.hs	0x1b98 <generic_fexit_filter_arg+0x1b98>
    1b88:      	add	x19, x19, #0x1
    1b8c:      	add	w22, w22, #0x4
    1b90:      	cmp	x19, #0x64
    1b94:      	b.ne	0x1af0 <generic_fexit_filter_arg+0x1af0>
    1b98:      	ldr	x23, [sp, #0x28]
    1b9c:      	ldr	x12, [sp, #0x48]
    1ba0:      	mov	x22, xzr
    1ba4:      	b	0x32c4 <generic_fexit_filter_arg+0x32c4>
    1ba8:      	and	w8, w25, #0xffff
    1bac:      	cmp	w8, #0x90
    1bb0:      	b.hi	0x21b0 <generic_fexit_filter_arg+0x21b0>
    1bb4:      	and	w8, w25, #0xff
    1bb8:      	mov	w9, #0xab               // =171
    1bbc:      	tst	w25, #0xffff
    1bc0:      	mul	w8, w8, w9
    1bc4:      	mov	w9, #0x18               // =24
    1bc8:      	lsr	w8, w8, #12
    1bcc:      	msub	w8, w8, w9, w25
    1bd0:      	b.eq	0x1be4 <generic_fexit_filter_arg+0x1be4>
    1bd4:      	tst	w8, #0xff
    1bd8:      	mov	w9, w25
    1bdc:      	mov	w11, w25
    1be0:      	b.eq	0x1c00 <generic_fexit_filter_arg+0x1c00>
    1be4:      	sub	w8, w25, w8, uxtb
    1be8:      	and	w9, w8, #0xffff
    1bec:      	add	w8, w8, #0x18
    1bf0:      	and	w11, w8, #0xffff
    1bf4:      	cmp	w9, #0x78
    1bf8:      	b.hi	0x2f9c <generic_fexit_filter_arg+0x2f9c>
    1bfc:      	mov	w9, w11
    1c00:      	and	w8, w9, #0xff
    1c04:      	mov	w9, #0xab               // =171
    1c08:      	mul	w8, w8, w9
    1c0c:      	lsr	w8, w8, #12
    1c10:      	sub	w10, w8, #0x1
    1c14:      	b	0x2fec <generic_fexit_filter_arg+0x2fec>
    1c18:      	cmp	x13, x10
    1c1c:      	ccmp	x10, x12, #0x2, ls
    1c20:      	cset	w12, ls
    1c24:      	orr	w8, w8, w12
    1c28:      	cmp	w11, #0x29
    1c2c:      	b.lo	0x2aa0 <generic_fexit_filter_arg+0x2aa0>
    1c30:      	ldp	x13, x12, [x21, #0x30]
    1c34:      	cmp	w9, #0xc
    1c38:      	b.eq	0x1c44 <generic_fexit_filter_arg+0x1c44>
    1c3c:      	cmp	w9, #0xa
    1c40:      	b.ne	0x21c0 <generic_fexit_filter_arg+0x21c0>
    1c44:      	cmp	x13, x10
    1c48:      	ccmp	x10, x12, #0x0, le
    1c4c:      	cset	w12, le
    1c50:      	b	0x21cc <generic_fexit_filter_arg+0x21cc>
    1c54:      	mov	x19, xzr
    1c58:      	cmp	w9, #0x29
    1c5c:      	b.ne	0x1c68 <generic_fexit_filter_arg+0x1c68>
    1c60:      	cbz	x10, 0x1c68 <generic_fexit_filter_arg+0x1c68>
    1c64:      	ldrb	w19, [x10, #0x3a]
    1c68:      	cmp	w9, #0x29
    1c6c:      	b.eq	0x1c78 <generic_fexit_filter_arg+0x1c78>
    1c70:      	cmp	w9, #0x7
    1c74:      	b.ne	0x1fac <generic_fexit_filter_arg+0x1fac>
    1c78:      	ldrb	w8, [x21, #0x10]
    1c7c:      	adrp	x0, 0x1000 <generic_fexit_filter_arg+0x1000>
    1c80:      	add	x9, sp, #0xac
    1c84:      	add	x1, sp, #0xac
    1c88:      	str	w8, [sp, #0xac]
    1c8c:      	mov	w8, #0x1                // =1
    1c90:      	ldr	x0, [x0]
    1c94:      	blr	x8
    1c98:      	cbz	x0, 0x1cd0 <generic_fexit_filter_arg+0x1cd0>
    1c9c:      	str	x19, [sp, #0x88]
    1ca0:      	mov	w8, #0x1                // =1
    1ca4:      	add	x9, sp, #0x88
    1ca8:      	add	x1, sp, #0x88
    1cac:      	blr	x8
    1cb0:      	ldr	w9, [x21, #0x4]
    1cb4:      	mov	w8, wzr
    1cb8:      	cmp	w9, #0x1d
    1cbc:      	b.ls	0x15c4 <generic_fexit_filter_arg+0x15c4>
    1cc0:      	ldr	x19, [sp, #0x30]
    1cc4:      	ldp	x12, x16, [sp, #0x48]
    1cc8:      	mov	w17, #0x1               // =1
    1ccc:      	b	0x1784 <generic_fexit_filter_arg+0x1784>
    1cd0:      	ldr	x19, [sp, #0x30]
    1cd4:      	mov	x22, xzr
    1cd8:      	ldp	x12, x16, [sp, #0x48]
    1cdc:      	mov	w17, #0x1               // =1
    1ce0:      	ldr	x0, [sp, #0x38]
    1ce4:      	cbnz	x22, 0x140 <generic_fexit_filter_arg+0x140>
    1ce8:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    1cec:      	ldp	x23, x19, [sp, #0x28]
    1cf0:      	mov	x22, xzr
    1cf4:      	mov	w17, #0x1               // =1
    1cf8:      	ldr	x16, [sp, #0x50]
    1cfc:      	b	0x1d10 <generic_fexit_filter_arg+0x1d10>
    1d00:      	ldr	x16, [sp, #0x50]
    1d04:      	mov	x22, xzr
    1d08:      	mov	w17, #0x1               // =1
    1d0c:      	ldp	x23, x19, [sp, #0x28]
    1d10:      	ldr	x0, [sp, #0x38]
    1d14:      	ldr	x12, [sp, #0x48]
    1d18:      	ldr	w8, [x21, #0x4]
    1d1c:      	cmp	w8, #0x25
    1d20:      	b.hi	0x1ce4 <generic_fexit_filter_arg+0x1ce4>
    1d24:      	mov	x9, #0x50               // =80
    1d28:      	lsl	x8, x17, x8
    1d2c:      	movk	x9, #0xc00, lsl #16
    1d30:      	movk	x9, #0x20, lsl #32
    1d34:      	tst	x8, x9
    1d38:      	b.ne	0x32f0 <generic_fexit_filter_arg+0x32f0>
    1d3c:      	b	0x1ce4 <generic_fexit_filter_arg+0x1ce4>
    1d40:      	cmp	x12, x8
    1d44:      	ldr	x12, [sp, #0x48]
    1d48:      	b.hi	0x1d54 <generic_fexit_filter_arg+0x1d54>
    1d4c:      	cmp	x8, x11
    1d50:      	b.ls	0x140 <generic_fexit_filter_arg+0x140>
    1d54:      	cmp	w10, #0x29
    1d58:      	b.lo	0xc4 <generic_fexit_filter_arg+0xc4>
    1d5c:      	ldp	x12, x11, [x21, #0x30]
    1d60:      	cmp	w9, #0xc
    1d64:      	b.eq	0x1d70 <generic_fexit_filter_arg+0x1d70>
    1d68:      	cmp	w9, #0xa
    1d6c:      	b.ne	0x21fc <generic_fexit_filter_arg+0x21fc>
    1d70:      	cmp	x12, x8
    1d74:      	ldr	x12, [sp, #0x48]
    1d78:      	b.gt	0x2210 <generic_fexit_filter_arg+0x2210>
    1d7c:      	cmp	x8, x11
    1d80:      	b.le	0x140 <generic_fexit_filter_arg+0x140>
    1d84:      	b	0x2210 <generic_fexit_filter_arg+0x2210>
    1d88:      	ldr	w8, [x21, #0x4]
    1d8c:      	and	w8, w8, #0xfffffffe
    1d90:      	cmp	w8, #0x18
    1d94:      	cset	w8, eq
    1d98:      	ldr	x0, [sp, #0x38]
    1d9c:      	ldp	x12, x16, [sp, #0x48]
    1da0:      	mov	w17, #0x1               // =1
    1da4:      	mov	w22, w8
    1da8:      	cbnz	x22, 0x140 <generic_fexit_filter_arg+0x140>
    1dac:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    1db0:      	ldr	w8, [x21, #0x4]
    1db4:      	ldp	x19, x0, [sp, #0x30]
    1db8:      	and	w8, w8, #0xfffffffe
    1dbc:      	cmp	w8, #0x18
    1dc0:      	cset	w8, eq
    1dc4:      	ldp	x12, x16, [sp, #0x48]
    1dc8:      	mov	w17, #0x1               // =1
    1dcc:      	mov	w22, w8
    1dd0:      	cbnz	x22, 0x140 <generic_fexit_filter_arg+0x140>
    1dd4:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    1dd8:      	ldr	w11, [x25]
    1ddc:      	cmp	w11, w10
    1de0:      	b.hi	0x140 <generic_fexit_filter_arg+0x140>
    1de4:      	b	0x1df4 <generic_fexit_filter_arg+0x1df4>
    1de8:      	ldr	w11, [x25]
    1dec:      	cmp	w11, w10
    1df0:      	b.lo	0x140 <generic_fexit_filter_arg+0x140>
    1df4:      	ldr	w10, [x21, #0x8]
    1df8:      	cmp	w10, #0xd
    1dfc:      	b.lo	0x124 <generic_fexit_filter_arg+0x124>
    1e00:      	ldr	w11, [x21, #0x14]
    1e04:      	cmp	w8, #0x2
    1e08:      	b.le	0x1e2c <generic_fexit_filter_arg+0x1e2c>
    1e0c:      	sub	w12, w8, #0x3
    1e10:      	cmp	w12, #0x2
    1e14:      	b.hs	0x1e68 <generic_fexit_filter_arg+0x1e68>
    1e18:      	ldr	w12, [x25]
    1e1c:      	cmp	w12, w11
    1e20:      	ldr	x12, [sp, #0x48]
    1e24:      	b.ne	0x2700 <generic_fexit_filter_arg+0x2700>
    1e28:      	b	0x31dc <generic_fexit_filter_arg+0x31dc>
    1e2c:      	cmp	w8, #0x1
    1e30:      	b.eq	0x1e88 <generic_fexit_filter_arg+0x1e88>
    1e34:      	cmp	w8, #0x2
    1e38:      	b.ne	0x2700 <generic_fexit_filter_arg+0x2700>
    1e3c:      	cmp	w9, #0xc
    1e40:      	b.hi	0x26f0 <generic_fexit_filter_arg+0x26f0>
    1e44:      	lsl	w12, w17, w9
    1e48:      	mov	w13, #0x1402            // =5122
    1e4c:      	tst	w12, w13
    1e50:      	b.eq	0x26f0 <generic_fexit_filter_arg+0x26f0>
    1e54:      	ldr	w12, [x25]
    1e58:      	cmp	w12, w11
    1e5c:      	ldr	x12, [sp, #0x48]
    1e60:      	b.lt	0x140 <generic_fexit_filter_arg+0x140>
    1e64:      	b	0x2700 <generic_fexit_filter_arg+0x2700>
    1e68:      	ldr	x12, [sp, #0x48]
    1e6c:      	cmp	w8, #0xc
    1e70:      	b.ne	0x2700 <generic_fexit_filter_arg+0x2700>
    1e74:      	ldr	w12, [x25]
    1e78:      	tst	w12, w11
    1e7c:      	ldr	x12, [sp, #0x48]
    1e80:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
    1e84:      	b	0x2700 <generic_fexit_filter_arg+0x2700>
    1e88:      	cmp	w9, #0xc
    1e8c:      	b.hi	0x26dc <generic_fexit_filter_arg+0x26dc>
    1e90:      	lsl	w12, w17, w9
    1e94:      	mov	w13, #0x1402            // =5122
    1e98:      	tst	w12, w13
    1e9c:      	b.eq	0x26dc <generic_fexit_filter_arg+0x26dc>
    1ea0:      	ldr	w12, [x25]
    1ea4:      	cmp	w12, w11
    1ea8:      	ldr	x12, [sp, #0x48]
    1eac:      	b.gt	0x140 <generic_fexit_filter_arg+0x140>
    1eb0:      	b	0x2700 <generic_fexit_filter_arg+0x2700>
    1eb4:      	and	w8, w29, #0xffff
    1eb8:      	cmp	w8, #0x201
    1ebc:      	b.hs	0x231c <generic_fexit_filter_arg+0x231c>
    1ec0:      	mov	w11, #0x200             // =512
    1ec4:      	b	0x2850 <generic_fexit_filter_arg+0x2850>
    1ec8:      	mov	x22, xzr
    1ecc:      	ldr	x19, [sp, #0x30]
    1ed0:      	ldr	w8, [x21, #0x4]
    1ed4:      	cmp	w8, #0x25
    1ed8:      	b.hi	0xf00 <generic_fexit_filter_arg+0xf00>
    1edc:      	mov	x9, #0x50               // =80
    1ee0:      	ldr	x0, [sp, #0x38]
    1ee4:      	ldp	x12, x16, [sp, #0x48]
    1ee8:      	mov	w17, #0x1               // =1
    1eec:      	movk	x9, #0xc00, lsl #16
    1ef0:      	lsl	x8, x17, x8
    1ef4:      	movk	x9, #0x20, lsl #32
    1ef8:      	tst	x8, x9
    1efc:      	b.ne	0x2d50 <generic_fexit_filter_arg+0x2d50>
    1f00:      	b	0x1ce4 <generic_fexit_filter_arg+0x1ce4>
    1f04:      	cmp	w8, #0x1
    1f08:      	b.eq	0x2588 <generic_fexit_filter_arg+0x2588>
    1f0c:      	cmp	w8, #0x2
    1f10:      	b.ne	0x2594 <generic_fexit_filter_arg+0x2594>
    1f14:      	ldrb	w11, [x25]
    1f18:      	cmp	w10, w11
    1f1c:      	b.hi	0x140 <generic_fexit_filter_arg+0x140>
    1f20:      	b	0x2594 <generic_fexit_filter_arg+0x2594>
    1f24:      	cmp	w8, #0x1
    1f28:      	b.eq	0x25c4 <generic_fexit_filter_arg+0x25c4>
    1f2c:      	cmp	w8, #0x2
    1f30:      	b.ne	0x25d0 <generic_fexit_filter_arg+0x25d0>
    1f34:      	ldrh	w11, [x25]
    1f38:      	cmp	w10, w11
    1f3c:      	b.hi	0x140 <generic_fexit_filter_arg+0x140>
    1f40:      	b	0x25d0 <generic_fexit_filter_arg+0x25d0>
    1f44:      	cmp	w8, #0x401
    1f48:      	b.hs	0x237c <generic_fexit_filter_arg+0x237c>
    1f4c:      	mov	w11, #0x400             // =1024
    1f50:      	b	0x2390 <generic_fexit_filter_arg+0x2390>
    1f54:      	ldr	x0, [sp, #0x38]
    1f58:      	mov	w8, wzr
    1f5c:      	mov	w22, wzr
    1f60:      	cbnz	x22, 0x140 <generic_fexit_filter_arg+0x140>
    1f64:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    1f68:      	cmp	w13, w10
    1f6c:      	ccmp	w10, w12, #0x2, ls
    1f70:      	cset	w12, ls
    1f74:      	orr	w8, w8, w12
    1f78:      	cmp	w11, #0x19
    1f7c:      	b.lo	0x2aa0 <generic_fexit_filter_arg+0x2aa0>
    1f80:      	ldp	w13, w12, [x21, #0x20]
    1f84:      	cmp	w9, #0xc
    1f88:      	b.hi	0x2630 <generic_fexit_filter_arg+0x2630>
    1f8c:      	lsl	w14, w17, w9
    1f90:      	mov	w15, #0x1402            // =5122
    1f94:      	tst	w14, w15
    1f98:      	b.eq	0x2630 <generic_fexit_filter_arg+0x2630>
    1f9c:      	cmp	w13, w10
    1fa0:      	ccmp	w10, w12, #0x0, le
    1fa4:      	cset	w12, le
    1fa8:      	b	0x263c <generic_fexit_filter_arg+0x263c>
    1fac:      	ldr	x19, [sp, #0x30]
    1fb0:      	mov	x22, xzr
    1fb4:      	cbnz	xzr, 0x140 <generic_fexit_filter_arg+0x140>
    1fb8:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    1fbc:      	mov	w11, #0xa               // =10
    1fc0:      	b	0x1fd0 <generic_fexit_filter_arg+0x1fd0>
    1fc4:      	mov	w11, #0x6               // =6
    1fc8:      	b	0x1fd0 <generic_fexit_filter_arg+0x1fd0>
    1fcc:      	mov	w11, #0x8               // =8
    1fd0:      	add	x8, x21, #0x10
    1fd4:      	and	w9, w11, #0xf
    1fd8:      	ldr	w8, [x8, w9, uxtw #2]
    1fdc:      	cmn	w8, #0x1
    1fe0:      	b.eq	0x2090 <generic_fexit_filter_arg+0x2090>
    1fe4:      	str	w8, [sp, #0x10]
    1fe8:      	stp	w13, w11, [sp, #0x1c]
    1fec:      	adrp	x0, 0x1000 <generic_fexit_filter_arg+0x1000>
    1ff0:      	mov	w8, #0x1                // =1
    1ff4:      	add	x22, sp, #0x88
    1ff8:      	add	x1, sp, #0x88
    1ffc:      	str	x10, [sp, #0x28]
    2000:      	ldr	x0, [x0]
    2004:      	blr	x8
    2008:      	mov	x25, x0
    200c:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2010:      	mov	w8, #0x1                // =1
    2014:      	ldr	x0, [x0]
    2018:      	add	x1, sp, #0x88
    201c:      	blr	x8
    2020:      	mov	x22, xzr
    2024:      	cbz	x25, 0x2d20 <generic_fexit_filter_arg+0x2d20>
    2028:      	mov	x9, x0
    202c:      	ldr	x0, [sp, #0x38]
    2030:      	ldp	x12, x16, [sp, #0x48]
    2034:      	mov	w17, #0x1               // =1
    2038:      	cbz	x9, 0x2d2c <generic_fexit_filter_arg+0x2d2c>
    203c:      	mov	x8, x25
    2040:      	ldr	w25, [sp, #0x20]
    2044:      	mov	x22, x9
    2048:      	mov	x0, x8
    204c:      	str	x8, [sp, #0x8]
    2050:      	cmp	w25, #0x5
    2054:      	b.gt	0x20a4 <generic_fexit_filter_arg+0x20a4>
    2058:      	strb	w29, [x0], #0x1
    205c:      	ldr	x2, [sp, #0x28]
    2060:      	mov	w8, #0x4                // =4
    2064:      	mov	w1, w29
    2068:      	blr	x8
    206c:      	ldr	w8, [sp, #0x1c]
    2070:      	subs	w8, w8, w29
    2074:      	b.ls	0x20e0 <generic_fexit_filter_arg+0x20e0>
    2078:      	ldr	x9, [sp, #0x8]
    207c:      	and	w1, w8, #0xfff
    2080:      	mov	w8, #0x4                // =4
    2084:      	add	x9, x9, x29
    2088:      	add	x0, x9, #0x1
    208c:      	b	0x20d8 <generic_fexit_filter_arg+0x20d8>
    2090:      	mov	x22, xzr
    2094:      	ldr	w8, [x21, #0x4]
    2098:      	cmp	w8, #0x25
    209c:      	b.ls	0x2d38 <generic_fexit_filter_arg+0x2d38>
    20a0:      	b	0x1ce4 <generic_fexit_filter_arg+0x1ce4>
    20a4:      	strh	w29, [x0], #0x2
    20a8:      	ldr	x2, [sp, #0x28]
    20ac:      	mov	w8, #0x4                // =4
    20b0:      	mov	w1, w29
    20b4:      	blr	x8
    20b8:      	ldr	w8, [sp, #0x1c]
    20bc:      	subs	w8, w8, w29
    20c0:      	b.ls	0x20e0 <generic_fexit_filter_arg+0x20e0>
    20c4:      	ldr	x9, [sp, #0x8]
    20c8:      	and	w1, w8, #0xfff
    20cc:      	mov	w8, #0x4                // =4
    20d0:      	add	x9, x9, x29
    20d4:      	add	x0, x9, #0x2
    20d8:      	mov	x2, x22
    20dc:      	blr	x8
    20e0:      	ldr	w8, [sp, #0x10]
    20e4:      	ldp	x12, x16, [sp, #0x48]
    20e8:      	cmp	w25, #0x4
    20ec:      	mov	w17, #0x1               // =1
    20f0:      	str	w8, [sp, #0x60]
    20f4:      	b.le	0x212c <generic_fexit_filter_arg+0x212c>
    20f8:      	cmp	w25, #0x7
    20fc:      	b.gt	0x2350 <generic_fexit_filter_arg+0x2350>
    2100:      	cmp	w25, #0x5
    2104:      	b.eq	0x2cd4 <generic_fexit_filter_arg+0x2cd4>
    2108:      	cmp	w25, #0x6
    210c:      	b.eq	0x2c98 <generic_fexit_filter_arg+0x2c98>
    2110:      	cmp	w25, #0x7
    2114:      	b.ne	0x2d5c <generic_fexit_filter_arg+0x2d5c>
    2118:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    211c:      	mov	w8, #0x1                // =1
    2120:      	add	x9, sp, #0x60
    2124:      	ldr	x0, [x0]
    2128:      	b	0x2cf8 <generic_fexit_filter_arg+0x2cf8>
    212c:      	cmp	w25, #0x1
    2130:      	b.le	0x27c8 <generic_fexit_filter_arg+0x27c8>
    2134:      	cmp	w25, #0x2
    2138:      	b.eq	0x2cc0 <generic_fexit_filter_arg+0x2cc0>
    213c:      	cmp	w25, #0x3
    2140:      	b.eq	0x2c84 <generic_fexit_filter_arg+0x2c84>
    2144:      	cmp	w25, #0x4
    2148:      	b.ne	0x2d5c <generic_fexit_filter_arg+0x2d5c>
    214c:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2150:      	mov	w8, #0x1                // =1
    2154:      	add	x9, sp, #0x60
    2158:      	ldr	x0, [x0]
    215c:      	b	0x2cf8 <generic_fexit_filter_arg+0x2cf8>
    2160:      	cmp	w12, w8
    2164:      	ldr	x12, [sp, #0x48]
    2168:      	b.hi	0x2174 <generic_fexit_filter_arg+0x2174>
    216c:      	cmp	w8, w11
    2170:      	b.ls	0x140 <generic_fexit_filter_arg+0x140>
    2174:      	cmp	w10, #0x19
    2178:      	b.lo	0xc4 <generic_fexit_filter_arg+0xc4>
    217c:      	ldp	w12, w11, [x21, #0x20]
    2180:      	cmp	w9, #0xc
    2184:      	b.hi	0x2690 <generic_fexit_filter_arg+0x2690>
    2188:      	lsl	w13, w17, w9
    218c:      	mov	w14, #0x1402            // =5122
    2190:      	tst	w13, w14
    2194:      	b.eq	0x2690 <generic_fexit_filter_arg+0x2690>
    2198:      	cmp	w12, w8
    219c:      	ldr	x12, [sp, #0x48]
    21a0:      	b.gt	0x26a4 <generic_fexit_filter_arg+0x26a4>
    21a4:      	cmp	w8, w11
    21a8:      	b.le	0x140 <generic_fexit_filter_arg+0x140>
    21ac:      	b	0x26a4 <generic_fexit_filter_arg+0x26a4>
    21b0:      	cmp	w8, #0x101
    21b4:      	b.hs	0x267c <generic_fexit_filter_arg+0x267c>
    21b8:      	mov	w11, #0x100             // =256
    21bc:      	b	0x2f9c <generic_fexit_filter_arg+0x2f9c>
    21c0:      	cmp	x13, x10
    21c4:      	ccmp	x10, x12, #0x2, ls
    21c8:      	cset	w12, ls
    21cc:      	orr	w8, w8, w12
    21d0:      	cmp	w11, #0x39
    21d4:      	b.lo	0x2aa0 <generic_fexit_filter_arg+0x2aa0>
    21d8:      	ldp	x12, x11, [x21, #0x40]
    21dc:      	cmp	w9, #0xc
    21e0:      	b.eq	0x21ec <generic_fexit_filter_arg+0x21ec>
    21e4:      	cmp	w9, #0xa
    21e8:      	b.ne	0x27bc <generic_fexit_filter_arg+0x27bc>
    21ec:      	cmp	x12, x10
    21f0:      	ccmp	x10, x11, #0x0, le
    21f4:      	cset	w9, le
    21f8:      	b	0x2a9c <generic_fexit_filter_arg+0x2a9c>
    21fc:      	cmp	x12, x8
    2200:      	ldr	x12, [sp, #0x48]
    2204:      	b.hi	0x2210 <generic_fexit_filter_arg+0x2210>
    2208:      	cmp	x8, x11
    220c:      	b.ls	0x140 <generic_fexit_filter_arg+0x140>
    2210:      	cmp	w10, #0x39
    2214:      	b.lo	0xc4 <generic_fexit_filter_arg+0xc4>
    2218:      	ldp	x11, x10, [x21, #0x40]
    221c:      	cmp	w9, #0xc
    2220:      	b.eq	0x222c <generic_fexit_filter_arg+0x222c>
    2224:      	cmp	w9, #0xa
    2228:      	b.ne	0x27e8 <generic_fexit_filter_arg+0x27e8>
    222c:      	cmp	x11, x8
    2230:      	b.gt	0xc4 <generic_fexit_filter_arg+0xc4>
    2234:      	cmp	x8, x10
    2238:      	b.le	0x140 <generic_fexit_filter_arg+0x140>
    223c:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    2240:      	ldr	x12, [x25]
    2244:      	cmp	x12, x11
    2248:      	ldr	x12, [sp, #0x48]
    224c:      	b.hi	0x140 <generic_fexit_filter_arg+0x140>
    2250:      	b	0x2264 <generic_fexit_filter_arg+0x2264>
    2254:      	ldr	x12, [x25]
    2258:      	cmp	x12, x11
    225c:      	ldr	x12, [sp, #0x48]
    2260:      	b.lo	0x140 <generic_fexit_filter_arg+0x140>
    2264:      	cmp	w10, #0x19
    2268:      	b.lo	0x124 <generic_fexit_filter_arg+0x124>
    226c:      	ldr	x11, [x21, #0x20]
    2270:      	cmp	w8, #0x2
    2274:      	b.le	0x2298 <generic_fexit_filter_arg+0x2298>
    2278:      	sub	w12, w8, #0x3
    227c:      	cmp	w12, #0x2
    2280:      	b.hs	0x22cc <generic_fexit_filter_arg+0x22cc>
    2284:      	ldr	x12, [x25]
    2288:      	cmp	x12, x11
    228c:      	ldr	x12, [sp, #0x48]
    2290:      	b.ne	0x2ad0 <generic_fexit_filter_arg+0x2ad0>
    2294:      	b	0x31dc <generic_fexit_filter_arg+0x31dc>
    2298:      	cmp	w8, #0x1
    229c:      	b.eq	0x232c <generic_fexit_filter_arg+0x232c>
    22a0:      	cmp	w8, #0x2
    22a4:      	b.ne	0x2ad0 <generic_fexit_filter_arg+0x2ad0>
    22a8:      	cmp	w9, #0xc
    22ac:      	b.eq	0x22b8 <generic_fexit_filter_arg+0x22b8>
    22b0:      	cmp	w9, #0xa
    22b4:      	b.ne	0x2ac0 <generic_fexit_filter_arg+0x2ac0>
    22b8:      	ldr	x12, [x25]
    22bc:      	cmp	x12, x11
    22c0:      	ldr	x12, [sp, #0x48]
    22c4:      	b.lt	0x140 <generic_fexit_filter_arg+0x140>
    22c8:      	b	0x2ad0 <generic_fexit_filter_arg+0x2ad0>
    22cc:      	ldr	x12, [sp, #0x48]
    22d0:      	cmp	w8, #0xc
    22d4:      	b.ne	0x2ad0 <generic_fexit_filter_arg+0x2ad0>
    22d8:      	ldr	x12, [x25]
    22dc:      	tst	x12, x11
    22e0:      	ldr	x12, [sp, #0x48]
    22e4:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
    22e8:      	b	0x2ad0 <generic_fexit_filter_arg+0x2ad0>
    22ec:      	cmp	w8, #0xc
    22f0:      	b.ne	0x2594 <generic_fexit_filter_arg+0x2594>
    22f4:      	ldrb	w11, [x25]
    22f8:      	tst	w10, w11
    22fc:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
    2300:      	b	0x2594 <generic_fexit_filter_arg+0x2594>
    2304:      	cmp	w8, #0xc
    2308:      	b.ne	0x25d0 <generic_fexit_filter_arg+0x25d0>
    230c:      	ldrh	w11, [x25]
    2310:      	tst	w10, w11
    2314:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
    2318:      	b	0x25d0 <generic_fexit_filter_arg+0x25d0>
    231c:      	cmp	w8, #0x401
    2320:      	b.hs	0x283c <generic_fexit_filter_arg+0x283c>
    2324:      	mov	w11, #0x400             // =1024
    2328:      	b	0x2850 <generic_fexit_filter_arg+0x2850>
    232c:      	cmp	w9, #0xc
    2330:      	b.eq	0x233c <generic_fexit_filter_arg+0x233c>
    2334:      	cmp	w9, #0xa
    2338:      	b.ne	0x2aac <generic_fexit_filter_arg+0x2aac>
    233c:      	ldr	x12, [x25]
    2340:      	cmp	x12, x11
    2344:      	ldr	x12, [sp, #0x48]
    2348:      	b.gt	0x140 <generic_fexit_filter_arg+0x140>
    234c:      	b	0x2ad0 <generic_fexit_filter_arg+0x2ad0>
    2350:      	cmp	w25, #0x8
    2354:      	b.eq	0x2ce8 <generic_fexit_filter_arg+0x2ce8>
    2358:      	cmp	w25, #0x9
    235c:      	b.eq	0x2cac <generic_fexit_filter_arg+0x2cac>
    2360:      	cmp	w25, #0xa
    2364:      	b.ne	0x2d5c <generic_fexit_filter_arg+0x2d5c>
    2368:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    236c:      	mov	w8, #0x1                // =1
    2370:      	add	x9, sp, #0x60
    2374:      	ldr	x0, [x0]
    2378:      	b	0x2cf8 <generic_fexit_filter_arg+0x2cf8>
    237c:      	and	w8, w29, #0xffff
    2380:      	mov	w9, #0x1000             // =4096
    2384:      	cmp	w8, #0x800
    2388:      	mov	w8, #0x800              // =2048
    238c:      	csel	w11, w9, w8, hi
    2390:      	sub	w8, w11, #0x100
    2394:      	ror	w8, w8, #0x8
    2398:      	cmp	w8, #0x2
    239c:      	b.gt	0x23b4 <generic_fexit_filter_arg+0x23b4>
    23a0:      	cbz	w8, 0x23d4 <generic_fexit_filter_arg+0x23d4>
    23a4:      	cmp	w8, #0x1
    23a8:      	b.ne	0x23cc <generic_fexit_filter_arg+0x23cc>
    23ac:      	mov	w10, #0x7               // =7
    23b0:      	b	0x23e0 <generic_fexit_filter_arg+0x23e0>
    23b4:      	cmp	w8, #0x3
    23b8:      	b.eq	0x23dc <generic_fexit_filter_arg+0x23dc>
    23bc:      	cmp	w8, #0x7
    23c0:      	b.ne	0x23cc <generic_fexit_filter_arg+0x23cc>
    23c4:      	mov	w10, #0x9               // =9
    23c8:      	b	0x23e0 <generic_fexit_filter_arg+0x23e0>
    23cc:      	mov	w10, #0xa               // =10
    23d0:      	b	0x23e0 <generic_fexit_filter_arg+0x23e0>
    23d4:      	mov	w10, #0x6               // =6
    23d8:      	b	0x23e0 <generic_fexit_filter_arg+0x23e0>
    23dc:      	mov	w10, #0x8               // =8
    23e0:      	add	x8, x21, #0x10
    23e4:      	and	w9, w10, #0xf
    23e8:      	ldr	w8, [x8, w9, uxtw #2]
    23ec:      	cmn	w8, #0x1
    23f0:      	b.eq	0x2d1c <generic_fexit_filter_arg+0x2d1c>
    23f4:      	str	w8, [sp, #0x10]
    23f8:      	str	w11, [sp, #0x1c]
    23fc:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2400:      	mov	w8, #0x1                // =1
    2404:      	add	x22, sp, #0x88
    2408:      	add	x1, sp, #0x88
    240c:      	str	w10, [sp, #0x28]
    2410:      	ldr	x0, [x0]
    2414:      	blr	x8
    2418:      	str	x0, [sp, #0x20]
    241c:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2420:      	mov	w8, #0x1                // =1
    2424:      	add	x1, sp, #0x88
    2428:      	ldr	x0, [x0]
    242c:      	blr	x8
    2430:      	ldr	x10, [sp, #0x20]
    2434:      	mov	x22, xzr
    2438:      	cbz	x10, 0x2d20 <generic_fexit_filter_arg+0x2d20>
    243c:      	mov	x9, x0
    2440:      	ldr	x0, [sp, #0x38]
    2444:      	ldp	x12, x16, [sp, #0x48]
    2448:      	mov	w17, #0x1               // =1
    244c:      	cbz	x9, 0x2d2c <generic_fexit_filter_arg+0x2d2c>
    2450:      	mov	x22, x9
    2454:      	ldr	w9, [sp, #0x28]
    2458:      	mov	x8, x10
    245c:      	add	x2, x25, #0x4
    2460:      	mov	x25, x10
    2464:      	mov	x0, x8
    2468:      	cmp	w9, #0x5
    246c:      	b.gt	0x24a0 <generic_fexit_filter_arg+0x24a0>
    2470:      	strb	w29, [x0], #0x1
    2474:      	mov	w8, #0x4                // =4
    2478:      	mov	w1, w29
    247c:      	blr	x8
    2480:      	ldr	w8, [sp, #0x1c]
    2484:      	subs	w8, w8, w29
    2488:      	b.ls	0x24d4 <generic_fexit_filter_arg+0x24d4>
    248c:      	add	x9, x25, x29
    2490:      	and	w1, w8, #0xfff
    2494:      	mov	w8, #0x4                // =4
    2498:      	add	x0, x9, #0x1
    249c:      	b	0x24cc <generic_fexit_filter_arg+0x24cc>
    24a0:      	strh	w29, [x0], #0x2
    24a4:      	mov	w8, #0x4                // =4
    24a8:      	mov	w1, w29
    24ac:      	blr	x8
    24b0:      	ldr	w8, [sp, #0x1c]
    24b4:      	subs	w8, w8, w29
    24b8:      	b.ls	0x24d4 <generic_fexit_filter_arg+0x24d4>
    24bc:      	add	x9, x25, x29
    24c0:      	and	w1, w8, #0xfff
    24c4:      	mov	w8, #0x4                // =4
    24c8:      	add	x0, x9, #0x2
    24cc:      	mov	x2, x22
    24d0:      	blr	x8
    24d4:      	ldr	w8, [sp, #0x10]
    24d8:      	ldr	x0, [sp, #0x38]
    24dc:      	mov	w17, #0x1               // =1
    24e0:      	str	w8, [sp, #0x60]
    24e4:      	ldr	w8, [sp, #0x28]
    24e8:      	ldp	x12, x16, [sp, #0x48]
    24ec:      	cmp	w8, #0x4
    24f0:      	b.le	0x2528 <generic_fexit_filter_arg+0x2528>
    24f4:      	cmp	w8, #0x7
    24f8:      	b.gt	0x255c <generic_fexit_filter_arg+0x255c>
    24fc:      	cmp	w8, #0x5
    2500:      	b.eq	0x2be4 <generic_fexit_filter_arg+0x2be4>
    2504:      	cmp	w8, #0x6
    2508:      	b.eq	0x2ba8 <generic_fexit_filter_arg+0x2ba8>
    250c:      	cmp	w8, #0x7
    2510:      	b.ne	0x664 <generic_fexit_filter_arg+0x664>
    2514:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2518:      	mov	w8, #0x1                // =1
    251c:      	add	x9, sp, #0x60
    2520:      	ldr	x0, [x0]
    2524:      	b	0x2c08 <generic_fexit_filter_arg+0x2c08>
    2528:      	cmp	w8, #0x1
    252c:      	b.le	0x2610 <generic_fexit_filter_arg+0x2610>
    2530:      	cmp	w8, #0x2
    2534:      	b.eq	0x2bd0 <generic_fexit_filter_arg+0x2bd0>
    2538:      	cmp	w8, #0x3
    253c:      	b.eq	0x2b94 <generic_fexit_filter_arg+0x2b94>
    2540:      	cmp	w8, #0x4
    2544:      	b.ne	0x664 <generic_fexit_filter_arg+0x664>
    2548:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    254c:      	mov	w8, #0x1                // =1
    2550:      	add	x9, sp, #0x60
    2554:      	ldr	x0, [x0]
    2558:      	b	0x2c08 <generic_fexit_filter_arg+0x2c08>
    255c:      	cmp	w8, #0x8
    2560:      	b.eq	0x2bf8 <generic_fexit_filter_arg+0x2bf8>
    2564:      	cmp	w8, #0x9
    2568:      	b.eq	0x2bbc <generic_fexit_filter_arg+0x2bbc>
    256c:      	cmp	w8, #0xa
    2570:      	b.ne	0x664 <generic_fexit_filter_arg+0x664>
    2574:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2578:      	mov	w8, #0x1                // =1
    257c:      	add	x9, sp, #0x60
    2580:      	ldr	x0, [x0]
    2584:      	b	0x2c08 <generic_fexit_filter_arg+0x2c08>
    2588:      	ldrb	w11, [x25]
    258c:      	cmp	w10, w11
    2590:      	b.lo	0x140 <generic_fexit_filter_arg+0x140>
    2594:      	cmp	w9, #0x11
    2598:      	b.lo	0x124 <generic_fexit_filter_arg+0x124>
    259c:      	ldr	w10, [x21, #0x18]
    25a0:      	cmp	w8, #0x2
    25a4:      	b.le	0x27fc <generic_fexit_filter_arg+0x27fc>
    25a8:      	sub	w11, w8, #0x3
    25ac:      	cmp	w11, #0x2
    25b0:      	b.hs	0x2b50 <generic_fexit_filter_arg+0x2b50>
    25b4:      	ldrb	w11, [x25]
    25b8:      	cmp	w10, w11
    25bc:      	b.ne	0x2e40 <generic_fexit_filter_arg+0x2e40>
    25c0:      	b	0x31dc <generic_fexit_filter_arg+0x31dc>
    25c4:      	ldrh	w11, [x25]
    25c8:      	cmp	w10, w11
    25cc:      	b.lo	0x140 <generic_fexit_filter_arg+0x140>
    25d0:      	cmp	w9, #0x11
    25d4:      	b.lo	0x124 <generic_fexit_filter_arg+0x124>
    25d8:      	ldr	w10, [x21, #0x18]
    25dc:      	cmp	w8, #0x2
    25e0:      	b.le	0x281c <generic_fexit_filter_arg+0x281c>
    25e4:      	sub	w11, w8, #0x3
    25e8:      	cmp	w11, #0x2
    25ec:      	b.hs	0x2b68 <generic_fexit_filter_arg+0x2b68>
    25f0:      	ldrh	w11, [x25]
    25f4:      	cmp	w10, w11
    25f8:      	b.ne	0x2e84 <generic_fexit_filter_arg+0x2e84>
    25fc:      	b	0x31dc <generic_fexit_filter_arg+0x31dc>
    2600:      	ldr	x23, [sp, #0x28]
    2604:      	ldp	x12, x16, [sp, #0x48]
    2608:      	mov	x22, xzr
    260c:      	b	0x32c0 <generic_fexit_filter_arg+0x32c0>
    2610:      	cbz	w8, 0x2b80 <generic_fexit_filter_arg+0x2b80>
    2614:      	cmp	w8, #0x1
    2618:      	b.ne	0x664 <generic_fexit_filter_arg+0x664>
    261c:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2620:      	mov	w8, #0x1                // =1
    2624:      	add	x9, sp, #0x60
    2628:      	ldr	x0, [x0]
    262c:      	b	0x2c08 <generic_fexit_filter_arg+0x2c08>
    2630:      	cmp	w13, w10
    2634:      	ccmp	w10, w12, #0x2, ls
    2638:      	cset	w12, ls
    263c:      	orr	w8, w8, w12
    2640:      	cmp	w11, #0x21
    2644:      	b.lo	0x2aa0 <generic_fexit_filter_arg+0x2aa0>
    2648:      	ldp	w12, w11, [x21, #0x28]
    264c:      	cmp	w9, #0xc
    2650:      	b.hi	0x2a90 <generic_fexit_filter_arg+0x2a90>
    2654:      	lsl	w9, w17, w9
    2658:      	mov	w13, #0x1402            // =5122
    265c:      	tst	w9, w13
    2660:      	b.eq	0x2a90 <generic_fexit_filter_arg+0x2a90>
    2664:      	cmp	w12, w10
    2668:      	ccmp	w10, w11, #0x0, le
    266c:      	cset	w9, le
    2670:      	b	0x2a9c <generic_fexit_filter_arg+0x2a9c>
    2674:      	mov	w22, #0x1               // =1
    2678:      	b	0x32bc <generic_fexit_filter_arg+0x32bc>
    267c:      	and	w8, w25, #0xffff
    2680:      	cmp	w8, #0x201
    2684:      	b.hs	0x2c2c <generic_fexit_filter_arg+0x2c2c>
    2688:      	mov	w11, #0x200             // =512
    268c:      	b	0x2f9c <generic_fexit_filter_arg+0x2f9c>
    2690:      	cmp	w12, w8
    2694:      	ldr	x12, [sp, #0x48]
    2698:      	b.hi	0x26a4 <generic_fexit_filter_arg+0x26a4>
    269c:      	cmp	w8, w11
    26a0:      	b.ls	0x140 <generic_fexit_filter_arg+0x140>
    26a4:      	cmp	w10, #0x21
    26a8:      	b.lo	0xc4 <generic_fexit_filter_arg+0xc4>
    26ac:      	ldp	w11, w10, [x21, #0x28]
    26b0:      	cmp	w9, #0xc
    26b4:      	b.hi	0x2c3c <generic_fexit_filter_arg+0x2c3c>
    26b8:      	lsl	w9, w17, w9
    26bc:      	mov	w13, #0x1402            // =5122
    26c0:      	tst	w9, w13
    26c4:      	b.eq	0x2c3c <generic_fexit_filter_arg+0x2c3c>
    26c8:      	cmp	w11, w8
    26cc:      	b.gt	0xc4 <generic_fexit_filter_arg+0xc4>
    26d0:      	cmp	w8, w10
    26d4:      	b.le	0x140 <generic_fexit_filter_arg+0x140>
    26d8:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    26dc:      	ldr	w12, [x25]
    26e0:      	cmp	w12, w11
    26e4:      	ldr	x12, [sp, #0x48]
    26e8:      	b.hi	0x140 <generic_fexit_filter_arg+0x140>
    26ec:      	b	0x2700 <generic_fexit_filter_arg+0x2700>
    26f0:      	ldr	w12, [x25]
    26f4:      	cmp	w12, w11
    26f8:      	ldr	x12, [sp, #0x48]
    26fc:      	b.lo	0x140 <generic_fexit_filter_arg+0x140>
    2700:      	cmp	w10, #0x11
    2704:      	b.lo	0x124 <generic_fexit_filter_arg+0x124>
    2708:      	ldr	w11, [x21, #0x18]
    270c:      	cmp	w8, #0x2
    2710:      	b.le	0x2734 <generic_fexit_filter_arg+0x2734>
    2714:      	sub	w12, w8, #0x3
    2718:      	cmp	w12, #0x2
    271c:      	b.hs	0x2770 <generic_fexit_filter_arg+0x2770>
    2720:      	ldr	w12, [x25]
    2724:      	cmp	w12, w11
    2728:      	ldr	x12, [sp, #0x48]
    272c:      	b.ne	0x2ee0 <generic_fexit_filter_arg+0x2ee0>
    2730:      	b	0x31dc <generic_fexit_filter_arg+0x31dc>
    2734:      	cmp	w8, #0x1
    2738:      	b.eq	0x2790 <generic_fexit_filter_arg+0x2790>
    273c:      	cmp	w8, #0x2
    2740:      	b.ne	0x2ee0 <generic_fexit_filter_arg+0x2ee0>
    2744:      	cmp	w9, #0xc
    2748:      	b.hi	0x2ed0 <generic_fexit_filter_arg+0x2ed0>
    274c:      	lsl	w12, w17, w9
    2750:      	mov	w13, #0x1402            // =5122
    2754:      	tst	w12, w13
    2758:      	b.eq	0x2ed0 <generic_fexit_filter_arg+0x2ed0>
    275c:      	ldr	w12, [x25]
    2760:      	cmp	w12, w11
    2764:      	ldr	x12, [sp, #0x48]
    2768:      	b.lt	0x140 <generic_fexit_filter_arg+0x140>
    276c:      	b	0x2ee0 <generic_fexit_filter_arg+0x2ee0>
    2770:      	ldr	x12, [sp, #0x48]
    2774:      	cmp	w8, #0xc
    2778:      	b.ne	0x2ee0 <generic_fexit_filter_arg+0x2ee0>
    277c:      	ldr	w12, [x25]
    2780:      	tst	w12, w11
    2784:      	ldr	x12, [sp, #0x48]
    2788:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
    278c:      	b	0x2ee0 <generic_fexit_filter_arg+0x2ee0>
    2790:      	cmp	w9, #0xc
    2794:      	b.hi	0x2ebc <generic_fexit_filter_arg+0x2ebc>
    2798:      	lsl	w12, w17, w9
    279c:      	mov	w13, #0x1402            // =5122
    27a0:      	tst	w12, w13
    27a4:      	b.eq	0x2ebc <generic_fexit_filter_arg+0x2ebc>
    27a8:      	ldr	w12, [x25]
    27ac:      	cmp	w12, w11
    27b0:      	ldr	x12, [sp, #0x48]
    27b4:      	b.gt	0x140 <generic_fexit_filter_arg+0x140>
    27b8:      	b	0x2ee0 <generic_fexit_filter_arg+0x2ee0>
    27bc:      	cmp	x12, x10
    27c0:      	ccmp	x10, x11, #0x2, ls
    27c4:      	b	0x2a98 <generic_fexit_filter_arg+0x2a98>
    27c8:      	cbz	w25, 0x2c70 <generic_fexit_filter_arg+0x2c70>
    27cc:      	cmp	w25, #0x1
    27d0:      	b.ne	0x2d5c <generic_fexit_filter_arg+0x2d5c>
    27d4:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    27d8:      	mov	w8, #0x1                // =1
    27dc:      	add	x9, sp, #0x60
    27e0:      	ldr	x0, [x0]
    27e4:      	b	0x2cf8 <generic_fexit_filter_arg+0x2cf8>
    27e8:      	cmp	x11, x8
    27ec:      	b.hi	0xc4 <generic_fexit_filter_arg+0xc4>
    27f0:      	cmp	x8, x10
    27f4:      	b.ls	0x140 <generic_fexit_filter_arg+0x140>
    27f8:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    27fc:      	cmp	w8, #0x1
    2800:      	b.eq	0x2e34 <generic_fexit_filter_arg+0x2e34>
    2804:      	cmp	w8, #0x2
    2808:      	b.ne	0x2e40 <generic_fexit_filter_arg+0x2e40>
    280c:      	ldrb	w11, [x25]
    2810:      	cmp	w10, w11
    2814:      	b.hi	0x140 <generic_fexit_filter_arg+0x140>
    2818:      	b	0x2e40 <generic_fexit_filter_arg+0x2e40>
    281c:      	cmp	w8, #0x1
    2820:      	b.eq	0x2e78 <generic_fexit_filter_arg+0x2e78>
    2824:      	cmp	w8, #0x2
    2828:      	b.ne	0x2e84 <generic_fexit_filter_arg+0x2e84>
    282c:      	ldrh	w11, [x25]
    2830:      	cmp	w10, w11
    2834:      	b.hi	0x140 <generic_fexit_filter_arg+0x140>
    2838:      	b	0x2e84 <generic_fexit_filter_arg+0x2e84>
    283c:      	and	w8, w29, #0xffff
    2840:      	mov	w9, #0x1000             // =4096
    2844:      	cmp	w8, #0x800
    2848:      	mov	w8, #0x800              // =2048
    284c:      	csel	w11, w9, w8, hi
    2850:      	sub	w8, w11, #0x100
    2854:      	ror	w8, w8, #0x8
    2858:      	cmp	w8, #0x2
    285c:      	b.gt	0x2874 <generic_fexit_filter_arg+0x2874>
    2860:      	cbz	w8, 0x2894 <generic_fexit_filter_arg+0x2894>
    2864:      	cmp	w8, #0x1
    2868:      	b.ne	0x288c <generic_fexit_filter_arg+0x288c>
    286c:      	mov	w10, #0x7               // =7
    2870:      	b	0x28a0 <generic_fexit_filter_arg+0x28a0>
    2874:      	cmp	w8, #0x3
    2878:      	b.eq	0x289c <generic_fexit_filter_arg+0x289c>
    287c:      	cmp	w8, #0x7
    2880:      	b.ne	0x288c <generic_fexit_filter_arg+0x288c>
    2884:      	mov	w10, #0x9               // =9
    2888:      	b	0x28a0 <generic_fexit_filter_arg+0x28a0>
    288c:      	mov	w10, #0xa               // =10
    2890:      	b	0x28a0 <generic_fexit_filter_arg+0x28a0>
    2894:      	mov	w10, #0x6               // =6
    2898:      	b	0x28a0 <generic_fexit_filter_arg+0x28a0>
    289c:      	mov	w10, #0x8               // =8
    28a0:      	add	x8, x21, #0x10
    28a4:      	and	w9, w10, #0xf
    28a8:      	ldr	w8, [x8, w9, uxtw #2]
    28ac:      	cmn	w8, #0x1
    28b0:      	b.eq	0x2964 <generic_fexit_filter_arg+0x2964>
    28b4:      	str	w8, [sp, #0x1c]
    28b8:      	str	w11, [sp, #0x10]
    28bc:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    28c0:      	mov	w8, #0x1                // =1
    28c4:      	add	x22, sp, #0x88
    28c8:      	add	x1, sp, #0x88
    28cc:      	str	w10, [sp, #0x28]
    28d0:      	ldr	x0, [x0]
    28d4:      	blr	x8
    28d8:      	str	x0, [sp, #0x20]
    28dc:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    28e0:      	mov	w8, #0x1                // =1
    28e4:      	add	x1, sp, #0x88
    28e8:      	ldr	x0, [x0]
    28ec:      	blr	x8
    28f0:      	ldr	x10, [sp, #0x20]
    28f4:      	mov	x22, xzr
    28f8:      	cbz	x10, 0x1314 <generic_fexit_filter_arg+0x1314>
    28fc:      	mov	x9, x0
    2900:      	ldr	x0, [sp, #0x38]
    2904:      	ldp	x12, x16, [sp, #0x48]
    2908:      	mov	w17, #0x1               // =1
    290c:      	cbz	x9, 0x1d18 <generic_fexit_filter_arg+0x1d18>
    2910:      	mov	x22, x9
    2914:      	ldr	w9, [sp, #0x28]
    2918:      	mov	x8, x10
    291c:      	cmp	w9, #0x5
    2920:      	b.gt	0x296c <generic_fexit_filter_arg+0x296c>
    2924:      	mov	x0, x8
    2928:      	mov	x9, x8
    292c:      	mov	w8, #0x4                // =4
    2930:      	mov	w1, w29
    2934:      	mov	x2, x25
    2938:      	strb	w29, [x0], #0x1
    293c:      	mov	x25, x9
    2940:      	blr	x8
    2944:      	ldr	w8, [sp, #0x10]
    2948:      	subs	w8, w8, w29
    294c:      	b.ls	0x29b0 <generic_fexit_filter_arg+0x29b0>
    2950:      	add	x9, x25, x29
    2954:      	and	w1, w8, #0xfff
    2958:      	mov	w8, #0x4                // =4
    295c:      	add	x0, x9, #0x1
    2960:      	b	0x29a8 <generic_fexit_filter_arg+0x29a8>
    2964:      	mov	x22, xzr
    2968:      	b	0x131c <generic_fexit_filter_arg+0x131c>
    296c:      	mov	x0, x8
    2970:      	mov	x9, x8
    2974:      	mov	w8, #0x4                // =4
    2978:      	mov	w1, w29
    297c:      	mov	x2, x25
    2980:      	strh	w29, [x0], #0x2
    2984:      	mov	x25, x9
    2988:      	blr	x8
    298c:      	ldr	w8, [sp, #0x10]
    2990:      	subs	w8, w8, w29
    2994:      	b.ls	0x29b0 <generic_fexit_filter_arg+0x29b0>
    2998:      	add	x9, x25, x29
    299c:      	and	w1, w8, #0xfff
    29a0:      	mov	w8, #0x4                // =4
    29a4:      	add	x0, x9, #0x2
    29a8:      	mov	x2, x22
    29ac:      	blr	x8
    29b0:      	ldr	w8, [sp, #0x1c]
    29b4:      	ldp	x12, x16, [sp, #0x48]
    29b8:      	mov	w17, #0x1               // =1
    29bc:      	str	w8, [sp, #0x60]
    29c0:      	ldr	w8, [sp, #0x28]
    29c4:      	cmp	w8, #0x4
    29c8:      	b.le	0x2a00 <generic_fexit_filter_arg+0x2a00>
    29cc:      	cmp	w8, #0x7
    29d0:      	b.gt	0x2a34 <generic_fexit_filter_arg+0x2a34>
    29d4:      	cmp	w8, #0x5
    29d8:      	b.eq	0x2dd8 <generic_fexit_filter_arg+0x2dd8>
    29dc:      	cmp	w8, #0x6
    29e0:      	b.eq	0x2d9c <generic_fexit_filter_arg+0x2d9c>
    29e4:      	cmp	w8, #0x7
    29e8:      	b.ne	0x2e28 <generic_fexit_filter_arg+0x2e28>
    29ec:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    29f0:      	mov	w8, #0x1                // =1
    29f4:      	add	x9, sp, #0x60
    29f8:      	ldr	x0, [x0]
    29fc:      	b	0x2dfc <generic_fexit_filter_arg+0x2dfc>
    2a00:      	cmp	w8, #0x1
    2a04:      	b.le	0x2a60 <generic_fexit_filter_arg+0x2a60>
    2a08:      	cmp	w8, #0x2
    2a0c:      	b.eq	0x2dc4 <generic_fexit_filter_arg+0x2dc4>
    2a10:      	cmp	w8, #0x3
    2a14:      	b.eq	0x2d88 <generic_fexit_filter_arg+0x2d88>
    2a18:      	cmp	w8, #0x4
    2a1c:      	b.ne	0x2e28 <generic_fexit_filter_arg+0x2e28>
    2a20:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2a24:      	mov	w8, #0x1                // =1
    2a28:      	add	x9, sp, #0x60
    2a2c:      	ldr	x0, [x0]
    2a30:      	b	0x2dfc <generic_fexit_filter_arg+0x2dfc>
    2a34:      	cmp	w8, #0x8
    2a38:      	b.eq	0x2dec <generic_fexit_filter_arg+0x2dec>
    2a3c:      	cmp	w8, #0x9
    2a40:      	b.eq	0x2db0 <generic_fexit_filter_arg+0x2db0>
    2a44:      	cmp	w8, #0xa
    2a48:      	b.ne	0x2e28 <generic_fexit_filter_arg+0x2e28>
    2a4c:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2a50:      	mov	w8, #0x1                // =1
    2a54:      	add	x9, sp, #0x60
    2a58:      	ldr	x0, [x0]
    2a5c:      	b	0x2dfc <generic_fexit_filter_arg+0x2dfc>
    2a60:      	cbz	w8, 0x2d74 <generic_fexit_filter_arg+0x2d74>
    2a64:      	cmp	w8, #0x1
    2a68:      	b.ne	0x2e28 <generic_fexit_filter_arg+0x2e28>
    2a6c:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2a70:      	mov	w8, #0x1                // =1
    2a74:      	add	x9, sp, #0x60
    2a78:      	ldr	x0, [x0]
    2a7c:      	b	0x2dfc <generic_fexit_filter_arg+0x2dfc>
    2a80:      	ldr	x23, [sp, #0x28]
    2a84:      	ldr	x12, [sp, #0x48]
    2a88:      	mov	w22, #0x1               // =1
    2a8c:      	b	0x32c4 <generic_fexit_filter_arg+0x32c4>
    2a90:      	cmp	w12, w10
    2a94:      	ccmp	w10, w11, #0x2, ls
    2a98:      	cset	w9, ls
    2a9c:      	orr	w8, w8, w9
    2aa0:      	ldr	x12, [sp, #0x48]
    2aa4:      	tbz	w8, #0x0, 0x140 <generic_fexit_filter_arg+0x140>
    2aa8:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    2aac:      	ldr	x12, [x25]
    2ab0:      	cmp	x12, x11
    2ab4:      	ldr	x12, [sp, #0x48]
    2ab8:      	b.hi	0x140 <generic_fexit_filter_arg+0x140>
    2abc:      	b	0x2ad0 <generic_fexit_filter_arg+0x2ad0>
    2ac0:      	ldr	x12, [x25]
    2ac4:      	cmp	x12, x11
    2ac8:      	ldr	x12, [sp, #0x48]
    2acc:      	b.lo	0x140 <generic_fexit_filter_arg+0x140>
    2ad0:      	cmp	w10, #0x21
    2ad4:      	b.lo	0x124 <generic_fexit_filter_arg+0x124>
    2ad8:      	ldr	x10, [x21, #0x28]
    2adc:      	cmp	w8, #0x2
    2ae0:      	b.le	0x2b10 <generic_fexit_filter_arg+0x2b10>
    2ae4:      	sub	w9, w8, #0x3
    2ae8:      	cmp	w9, #0x2
    2aec:      	b.lo	0x2b40 <generic_fexit_filter_arg+0x2b40>
    2af0:      	cmp	w8, #0x6
    2af4:      	b.eq	0x140 <generic_fexit_filter_arg+0x140>
    2af8:      	cmp	w8, #0xc
    2afc:      	b.ne	0xc4 <generic_fexit_filter_arg+0xc4>
    2b00:      	ldr	x9, [x25]
    2b04:      	tst	x9, x10
    2b08:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
    2b0c:      	b	0x124 <generic_fexit_filter_arg+0x124>
    2b10:      	cmp	w8, #0x1
    2b14:      	b.eq	0x2c50 <generic_fexit_filter_arg+0x2c50>
    2b18:      	cmp	w8, #0x2
    2b1c:      	b.ne	0xc4 <generic_fexit_filter_arg+0xc4>
    2b20:      	cmp	w9, #0xc
    2b24:      	b.eq	0x2b30 <generic_fexit_filter_arg+0x2b30>
    2b28:      	cmp	w9, #0xa
    2b2c:      	b.ne	0x31ec <generic_fexit_filter_arg+0x31ec>
    2b30:      	ldr	x9, [x25]
    2b34:      	cmp	x9, x10
    2b38:      	b.ge	0x124 <generic_fexit_filter_arg+0x124>
    2b3c:      	b	0x140 <generic_fexit_filter_arg+0x140>
    2b40:      	ldr	x9, [x25]
    2b44:      	cmp	x9, x10
    2b48:      	b.eq	0x31dc <generic_fexit_filter_arg+0x31dc>
    2b4c:      	b	0x124 <generic_fexit_filter_arg+0x124>
    2b50:      	cmp	w8, #0xc
    2b54:      	b.ne	0x2e40 <generic_fexit_filter_arg+0x2e40>
    2b58:      	ldrb	w11, [x25]
    2b5c:      	tst	w10, w11
    2b60:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
    2b64:      	b	0x2e40 <generic_fexit_filter_arg+0x2e40>
    2b68:      	cmp	w8, #0xc
    2b6c:      	b.ne	0x2e84 <generic_fexit_filter_arg+0x2e84>
    2b70:      	ldrh	w11, [x25]
    2b74:      	tst	w10, w11
    2b78:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
    2b7c:      	b	0x2e84 <generic_fexit_filter_arg+0x2e84>
    2b80:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2b84:      	mov	w8, #0x1                // =1
    2b88:      	add	x9, sp, #0x60
    2b8c:      	ldr	x0, [x0]
    2b90:      	b	0x2c08 <generic_fexit_filter_arg+0x2c08>
    2b94:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2b98:      	mov	w8, #0x1                // =1
    2b9c:      	add	x9, sp, #0x60
    2ba0:      	ldr	x0, [x0]
    2ba4:      	b	0x2c08 <generic_fexit_filter_arg+0x2c08>
    2ba8:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2bac:      	mov	w8, #0x1                // =1
    2bb0:      	add	x9, sp, #0x60
    2bb4:      	ldr	x0, [x0]
    2bb8:      	b	0x2c08 <generic_fexit_filter_arg+0x2c08>
    2bbc:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2bc0:      	mov	w8, #0x1                // =1
    2bc4:      	add	x9, sp, #0x60
    2bc8:      	ldr	x0, [x0]
    2bcc:      	b	0x2c08 <generic_fexit_filter_arg+0x2c08>
    2bd0:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2bd4:      	mov	w8, #0x1                // =1
    2bd8:      	add	x9, sp, #0x60
    2bdc:      	ldr	x0, [x0]
    2be0:      	b	0x2c08 <generic_fexit_filter_arg+0x2c08>
    2be4:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2be8:      	mov	w8, #0x1                // =1
    2bec:      	add	x9, sp, #0x60
    2bf0:      	ldr	x0, [x0]
    2bf4:      	b	0x2c08 <generic_fexit_filter_arg+0x2c08>
    2bf8:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2bfc:      	mov	w8, #0x1                // =1
    2c00:      	add	x9, sp, #0x60
    2c04:      	ldr	x0, [x0]
    2c08:      	add	x1, sp, #0x60
    2c0c:      	blr	x8
    2c10:      	cbz	x0, 0x2d1c <generic_fexit_filter_arg+0x2d1c>
    2c14:      	mov	w8, #0x1                // =1
    2c18:      	mov	x1, x25
    2c1c:      	blr	x8
    2c20:      	cmp	x0, #0x0
    2c24:      	cset	w22, ne
    2c28:      	b	0x2d20 <generic_fexit_filter_arg+0x2d20>
    2c2c:      	cmp	w8, #0x401
    2c30:      	b.hs	0x2f88 <generic_fexit_filter_arg+0x2f88>
    2c34:      	mov	w11, #0x400             // =1024
    2c38:      	b	0x2f9c <generic_fexit_filter_arg+0x2f9c>
    2c3c:      	cmp	w11, w8
    2c40:      	b.hi	0xc4 <generic_fexit_filter_arg+0xc4>
    2c44:      	cmp	w8, w10
    2c48:      	b.ls	0x140 <generic_fexit_filter_arg+0x140>
    2c4c:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    2c50:      	cmp	w9, #0xc
    2c54:      	b.eq	0x2c60 <generic_fexit_filter_arg+0x2c60>
    2c58:      	cmp	w9, #0xa
    2c5c:      	b.ne	0x31fc <generic_fexit_filter_arg+0x31fc>
    2c60:      	ldr	x9, [x25]
    2c64:      	cmp	x9, x10
    2c68:      	b.le	0x124 <generic_fexit_filter_arg+0x124>
    2c6c:      	b	0x140 <generic_fexit_filter_arg+0x140>
    2c70:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2c74:      	mov	w8, #0x1                // =1
    2c78:      	add	x9, sp, #0x60
    2c7c:      	ldr	x0, [x0]
    2c80:      	b	0x2cf8 <generic_fexit_filter_arg+0x2cf8>
    2c84:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2c88:      	mov	w8, #0x1                // =1
    2c8c:      	add	x9, sp, #0x60
    2c90:      	ldr	x0, [x0]
    2c94:      	b	0x2cf8 <generic_fexit_filter_arg+0x2cf8>
    2c98:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2c9c:      	mov	w8, #0x1                // =1
    2ca0:      	add	x9, sp, #0x60
    2ca4:      	ldr	x0, [x0]
    2ca8:      	b	0x2cf8 <generic_fexit_filter_arg+0x2cf8>
    2cac:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2cb0:      	mov	w8, #0x1                // =1
    2cb4:      	add	x9, sp, #0x60
    2cb8:      	ldr	x0, [x0]
    2cbc:      	b	0x2cf8 <generic_fexit_filter_arg+0x2cf8>
    2cc0:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2cc4:      	mov	w8, #0x1                // =1
    2cc8:      	add	x9, sp, #0x60
    2ccc:      	ldr	x0, [x0]
    2cd0:      	b	0x2cf8 <generic_fexit_filter_arg+0x2cf8>
    2cd4:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2cd8:      	mov	w8, #0x1                // =1
    2cdc:      	add	x9, sp, #0x60
    2ce0:      	ldr	x0, [x0]
    2ce4:      	b	0x2cf8 <generic_fexit_filter_arg+0x2cf8>
    2ce8:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2cec:      	mov	w8, #0x1                // =1
    2cf0:      	add	x9, sp, #0x60
    2cf4:      	ldr	x0, [x0]
    2cf8:      	add	x1, sp, #0x60
    2cfc:      	blr	x8
    2d00:      	cbz	x0, 0x2d1c <generic_fexit_filter_arg+0x2d1c>
    2d04:      	ldr	x1, [sp, #0x8]
    2d08:      	mov	w8, #0x1                // =1
    2d0c:      	blr	x8
    2d10:      	cmp	x0, #0x0
    2d14:      	cset	w22, ne
    2d18:      	b	0x2d20 <generic_fexit_filter_arg+0x2d20>
    2d1c:      	mov	x22, xzr
    2d20:      	ldr	x0, [sp, #0x38]
    2d24:      	ldp	x12, x16, [sp, #0x48]
    2d28:      	mov	w17, #0x1               // =1
    2d2c:      	ldr	w8, [x21, #0x4]
    2d30:      	cmp	w8, #0x25
    2d34:      	b.hi	0x1ce4 <generic_fexit_filter_arg+0x1ce4>
    2d38:      	mov	x9, #0x50               // =80
    2d3c:      	lsl	x8, x17, x8
    2d40:      	movk	x9, #0xc00, lsl #16
    2d44:      	movk	x9, #0x20, lsl #32
    2d48:      	tst	x8, x9
    2d4c:      	b.eq	0x1ce4 <generic_fexit_filter_arg+0x1ce4>
    2d50:      	eor	x22, x22, #0x1
    2d54:      	cbnz	x22, 0x140 <generic_fexit_filter_arg+0x140>
    2d58:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    2d5c:      	ldr	x0, [sp, #0x38]
    2d60:      	mov	x22, xzr
    2d64:      	ldr	w8, [x21, #0x4]
    2d68:      	cmp	w8, #0x25
    2d6c:      	b.ls	0x2d38 <generic_fexit_filter_arg+0x2d38>
    2d70:      	b	0x1ce4 <generic_fexit_filter_arg+0x1ce4>
    2d74:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2d78:      	mov	w8, #0x1                // =1
    2d7c:      	add	x9, sp, #0x60
    2d80:      	ldr	x0, [x0]
    2d84:      	b	0x2dfc <generic_fexit_filter_arg+0x2dfc>
    2d88:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2d8c:      	mov	w8, #0x1                // =1
    2d90:      	add	x9, sp, #0x60
    2d94:      	ldr	x0, [x0]
    2d98:      	b	0x2dfc <generic_fexit_filter_arg+0x2dfc>
    2d9c:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2da0:      	mov	w8, #0x1                // =1
    2da4:      	add	x9, sp, #0x60
    2da8:      	ldr	x0, [x0]
    2dac:      	b	0x2dfc <generic_fexit_filter_arg+0x2dfc>
    2db0:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2db4:      	mov	w8, #0x1                // =1
    2db8:      	add	x9, sp, #0x60
    2dbc:      	ldr	x0, [x0]
    2dc0:      	b	0x2dfc <generic_fexit_filter_arg+0x2dfc>
    2dc4:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2dc8:      	mov	w8, #0x1                // =1
    2dcc:      	add	x9, sp, #0x60
    2dd0:      	ldr	x0, [x0]
    2dd4:      	b	0x2dfc <generic_fexit_filter_arg+0x2dfc>
    2dd8:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2ddc:      	mov	w8, #0x1                // =1
    2de0:      	add	x9, sp, #0x60
    2de4:      	ldr	x0, [x0]
    2de8:      	b	0x2dfc <generic_fexit_filter_arg+0x2dfc>
    2dec:      	adrp	x0, 0x2000 <generic_fexit_filter_arg+0x2000>
    2df0:      	mov	w8, #0x1                // =1
    2df4:      	add	x9, sp, #0x60
    2df8:      	ldr	x0, [x0]
    2dfc:      	add	x1, sp, #0x60
    2e00:      	blr	x8
    2e04:      	cbz	x0, 0x2e20 <generic_fexit_filter_arg+0x2e20>
    2e08:      	mov	w8, #0x1                // =1
    2e0c:      	mov	x1, x25
    2e10:      	blr	x8
    2e14:      	cmp	x0, #0x0
    2e18:      	cset	w22, ne
    2e1c:      	b	0x1314 <generic_fexit_filter_arg+0x1314>
    2e20:      	mov	x22, xzr
    2e24:      	b	0x1314 <generic_fexit_filter_arg+0x1314>
    2e28:      	ldr	x0, [sp, #0x38]
    2e2c:      	mov	x22, xzr
    2e30:      	b	0x1d18 <generic_fexit_filter_arg+0x1d18>
    2e34:      	ldrb	w11, [x25]
    2e38:      	cmp	w10, w11
    2e3c:      	b.lo	0x140 <generic_fexit_filter_arg+0x140>
    2e40:      	cmp	w9, #0x15
    2e44:      	b.lo	0x124 <generic_fexit_filter_arg+0x124>
    2e48:      	ldr	w9, [x21, #0x1c]
    2e4c:      	cmp	w8, #0x2
    2e50:      	b.le	0x3198 <generic_fexit_filter_arg+0x3198>
    2e54:      	sub	w10, w8, #0x3
    2e58:      	cmp	w10, #0x2
    2e5c:      	b.lo	0x31c8 <generic_fexit_filter_arg+0x31c8>
    2e60:      	cmp	w8, #0x6
    2e64:      	b.eq	0x140 <generic_fexit_filter_arg+0x140>
    2e68:      	cmp	w8, #0xc
    2e6c:      	b.ne	0xc4 <generic_fexit_filter_arg+0xc4>
    2e70:      	ldrb	w10, [x25]
    2e74:      	b	0x2f14 <generic_fexit_filter_arg+0x2f14>
    2e78:      	ldrh	w11, [x25]
    2e7c:      	cmp	w10, w11
    2e80:      	b.lo	0x140 <generic_fexit_filter_arg+0x140>
    2e84:      	cmp	w9, #0x15
    2e88:      	b.lo	0x124 <generic_fexit_filter_arg+0x124>
    2e8c:      	ldr	w9, [x21, #0x1c]
    2e90:      	cmp	w8, #0x2
    2e94:      	b.le	0x31b0 <generic_fexit_filter_arg+0x31b0>
    2e98:      	sub	w10, w8, #0x3
    2e9c:      	cmp	w10, #0x2
    2ea0:      	b.lo	0x31d0 <generic_fexit_filter_arg+0x31d0>
    2ea4:      	cmp	w8, #0x6
    2ea8:      	b.eq	0x140 <generic_fexit_filter_arg+0x140>
    2eac:      	cmp	w8, #0xc
    2eb0:      	b.ne	0xc4 <generic_fexit_filter_arg+0xc4>
    2eb4:      	ldrh	w10, [x25]
    2eb8:      	b	0x2f14 <generic_fexit_filter_arg+0x2f14>
    2ebc:      	ldr	w12, [x25]
    2ec0:      	cmp	w12, w11
    2ec4:      	ldr	x12, [sp, #0x48]
    2ec8:      	b.hi	0x140 <generic_fexit_filter_arg+0x140>
    2ecc:      	b	0x2ee0 <generic_fexit_filter_arg+0x2ee0>
    2ed0:      	ldr	w12, [x25]
    2ed4:      	cmp	w12, w11
    2ed8:      	ldr	x12, [sp, #0x48]
    2edc:      	b.lo	0x140 <generic_fexit_filter_arg+0x140>
    2ee0:      	cmp	w10, #0x15
    2ee4:      	b.lo	0x124 <generic_fexit_filter_arg+0x124>
    2ee8:      	ldr	w10, [x21, #0x1c]
    2eec:      	cmp	w8, #0x2
    2ef0:      	b.le	0x2f20 <generic_fexit_filter_arg+0x2f20>
    2ef4:      	sub	w9, w8, #0x3
    2ef8:      	cmp	w9, #0x2
    2efc:      	b.lo	0x2f58 <generic_fexit_filter_arg+0x2f58>
    2f00:      	cmp	w8, #0x6
    2f04:      	b.eq	0x140 <generic_fexit_filter_arg+0x140>
    2f08:      	cmp	w8, #0xc
    2f0c:      	b.ne	0xc4 <generic_fexit_filter_arg+0xc4>
    2f10:      	ldr	w9, [x25]
    2f14:      	tst	w9, w10
    2f18:      	b.ne	0x140 <generic_fexit_filter_arg+0x140>
    2f1c:      	b	0x124 <generic_fexit_filter_arg+0x124>
    2f20:      	cmp	w8, #0x1
    2f24:      	b.eq	0x2f60 <generic_fexit_filter_arg+0x2f60>
    2f28:      	cmp	w8, #0x2
    2f2c:      	b.ne	0xc4 <generic_fexit_filter_arg+0xc4>
    2f30:      	cmp	w9, #0xc
    2f34:      	b.hi	0x331c <generic_fexit_filter_arg+0x331c>
    2f38:      	lsl	w9, w17, w9
    2f3c:      	mov	w11, #0x1402            // =5122
    2f40:      	tst	w9, w11
    2f44:      	b.eq	0x331c <generic_fexit_filter_arg+0x331c>
    2f48:      	ldr	w9, [x25]
    2f4c:      	cmp	w9, w10
    2f50:      	b.ge	0x124 <generic_fexit_filter_arg+0x124>
    2f54:      	b	0x140 <generic_fexit_filter_arg+0x140>
    2f58:      	ldr	w9, [x25]
    2f5c:      	b	0x31d4 <generic_fexit_filter_arg+0x31d4>
    2f60:      	cmp	w9, #0xc
    2f64:      	b.hi	0x332c <generic_fexit_filter_arg+0x332c>
    2f68:      	lsl	w9, w17, w9
    2f6c:      	mov	w11, #0x1402            // =5122
    2f70:      	tst	w9, w11
    2f74:      	b.eq	0x332c <generic_fexit_filter_arg+0x332c>
    2f78:      	ldr	w9, [x25]
    2f7c:      	cmp	w9, w10
    2f80:      	b.le	0x124 <generic_fexit_filter_arg+0x124>
    2f84:      	b	0x140 <generic_fexit_filter_arg+0x140>
    2f88:      	and	w8, w25, #0xffff
    2f8c:      	mov	w9, #0x1000             // =4096
    2f90:      	cmp	w8, #0x800
    2f94:      	mov	w8, #0x800              // =2048
    2f98:      	csel	w11, w9, w8, hi
    2f9c:      	sub	w8, w11, #0x100
    2fa0:      	ror	w8, w8, #0x8
    2fa4:      	cmp	w8, #0x2
    2fa8:      	b.gt	0x2fc0 <generic_fexit_filter_arg+0x2fc0>
    2fac:      	cbz	w8, 0x2fe0 <generic_fexit_filter_arg+0x2fe0>
    2fb0:      	cmp	w8, #0x1
    2fb4:      	b.ne	0x2fd8 <generic_fexit_filter_arg+0x2fd8>
    2fb8:      	mov	w10, #0x7               // =7
    2fbc:      	b	0x2fec <generic_fexit_filter_arg+0x2fec>
    2fc0:      	cmp	w8, #0x3
    2fc4:      	b.eq	0x2fe8 <generic_fexit_filter_arg+0x2fe8>
    2fc8:      	cmp	w8, #0x7
    2fcc:      	b.ne	0x2fd8 <generic_fexit_filter_arg+0x2fd8>
    2fd0:      	mov	w10, #0x9               // =9
    2fd4:      	b	0x2fec <generic_fexit_filter_arg+0x2fec>
    2fd8:      	mov	w10, #0xa               // =10
    2fdc:      	b	0x2fec <generic_fexit_filter_arg+0x2fec>
    2fe0:      	mov	w10, #0x6               // =6
    2fe4:      	b	0x2fec <generic_fexit_filter_arg+0x2fec>
    2fe8:      	mov	w10, #0x8               // =8
    2fec:      	add	x8, x21, #0x10
    2ff0:      	and	w9, w10, #0xf
    2ff4:      	ldr	w8, [x8, w9, uxtw #2]
    2ff8:      	cmn	w8, #0x1
    2ffc:      	b.eq	0x32b8 <generic_fexit_filter_arg+0x32b8>
    3000:      	stp	w8, w11, [sp, #0x1c]
    3004:      	str	w10, [sp, #0x28]
    3008:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    300c:      	mov	w8, #0x1                // =1
    3010:      	add	x19, sp, #0x88
    3014:      	add	x1, sp, #0x88
    3018:      	ldr	x0, [x0]
    301c:      	blr	x8
    3020:      	mov	x9, x0
    3024:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3028:      	mov	w8, #0x1                // =1
    302c:      	ldr	x0, [x0]
    3030:      	add	x1, sp, #0x88
    3034:      	mov	x19, x9
    3038:      	blr	x8
    303c:      	mov	x22, xzr
    3040:      	cbz	x19, 0x32bc <generic_fexit_filter_arg+0x32bc>
    3044:      	ldp	x12, x16, [sp, #0x48]
    3048:      	mov	w17, #0x1               // =1
    304c:      	cbz	x0, 0x32c4 <generic_fexit_filter_arg+0x32c4>
    3050:      	ldr	w22, [sp, #0x28]
    3054:      	str	x0, [sp, #0x10]
    3058:      	mov	x0, x19
    305c:      	cmp	w22, #0x5
    3060:      	b.gt	0x309c <generic_fexit_filter_arg+0x309c>
    3064:      	strb	w25, [x0], #0x1
    3068:      	mov	w8, #0x4                // =4
    306c:      	mov	w1, w25
    3070:      	mov	x2, x29
    3074:      	blr	x8
    3078:      	ldr	w8, [sp, #0x20]
    307c:      	subs	w8, w8, w25
    3080:      	b.ls	0x30d4 <generic_fexit_filter_arg+0x30d4>
    3084:      	add	x9, x19, x25
    3088:      	and	w1, w8, #0xfff
    308c:      	mov	w8, #0x4                // =4
    3090:      	ldr	x2, [sp, #0x10]
    3094:      	add	x0, x9, #0x1
    3098:      	b	0x30d0 <generic_fexit_filter_arg+0x30d0>
    309c:      	strh	w25, [x0], #0x2
    30a0:      	mov	w8, #0x4                // =4
    30a4:      	mov	w1, w25
    30a8:      	mov	x2, x29
    30ac:      	blr	x8
    30b0:      	ldr	w8, [sp, #0x20]
    30b4:      	subs	w8, w8, w25
    30b8:      	b.ls	0x30d4 <generic_fexit_filter_arg+0x30d4>
    30bc:      	add	x9, x19, x25
    30c0:      	ldr	x2, [sp, #0x10]
    30c4:      	and	w1, w8, #0xfff
    30c8:      	mov	w8, #0x4                // =4
    30cc:      	add	x0, x9, #0x2
    30d0:      	blr	x8
    30d4:      	ldr	w8, [sp, #0x1c]
    30d8:      	cmp	w22, #0x4
    30dc:      	str	w8, [sp, #0x60]
    30e0:      	b.le	0x3118 <generic_fexit_filter_arg+0x3118>
    30e4:      	cmp	w22, #0x7
    30e8:      	b.gt	0x314c <generic_fexit_filter_arg+0x314c>
    30ec:      	cmp	w22, #0x5
    30f0:      	b.eq	0x3270 <generic_fexit_filter_arg+0x3270>
    30f4:      	cmp	w22, #0x6
    30f8:      	b.eq	0x3234 <generic_fexit_filter_arg+0x3234>
    30fc:      	cmp	w22, #0x7
    3100:      	b.ne	0x32b8 <generic_fexit_filter_arg+0x32b8>
    3104:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3108:      	mov	w8, #0x1                // =1
    310c:      	add	x9, sp, #0x60
    3110:      	ldr	x0, [x0]
    3114:      	b	0x3294 <generic_fexit_filter_arg+0x3294>
    3118:      	cmp	w22, #0x1
    311c:      	b.le	0x3178 <generic_fexit_filter_arg+0x3178>
    3120:      	cmp	w22, #0x2
    3124:      	b.eq	0x325c <generic_fexit_filter_arg+0x325c>
    3128:      	cmp	w22, #0x3
    312c:      	b.eq	0x3220 <generic_fexit_filter_arg+0x3220>
    3130:      	cmp	w22, #0x4
    3134:      	b.ne	0x32b8 <generic_fexit_filter_arg+0x32b8>
    3138:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    313c:      	mov	w8, #0x1                // =1
    3140:      	add	x9, sp, #0x60
    3144:      	ldr	x0, [x0]
    3148:      	b	0x3294 <generic_fexit_filter_arg+0x3294>
    314c:      	cmp	w22, #0x8
    3150:      	b.eq	0x3284 <generic_fexit_filter_arg+0x3284>
    3154:      	cmp	w22, #0x9
    3158:      	b.eq	0x3248 <generic_fexit_filter_arg+0x3248>
    315c:      	cmp	w22, #0xa
    3160:      	b.ne	0x32b8 <generic_fexit_filter_arg+0x32b8>
    3164:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3168:      	mov	w8, #0x1                // =1
    316c:      	add	x9, sp, #0x60
    3170:      	ldr	x0, [x0]
    3174:      	b	0x3294 <generic_fexit_filter_arg+0x3294>
    3178:      	cbz	w22, 0x320c <generic_fexit_filter_arg+0x320c>
    317c:      	cmp	w22, #0x1
    3180:      	b.ne	0x32b8 <generic_fexit_filter_arg+0x32b8>
    3184:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3188:      	mov	w8, #0x1                // =1
    318c:      	add	x9, sp, #0x60
    3190:      	ldr	x0, [x0]
    3194:      	b	0x3294 <generic_fexit_filter_arg+0x3294>
    3198:      	cmp	w8, #0x1
    319c:      	b.eq	0x330c <generic_fexit_filter_arg+0x330c>
    31a0:      	cmp	w8, #0x2
    31a4:      	b.ne	0xc4 <generic_fexit_filter_arg+0xc4>
    31a8:      	ldrb	w10, [x25]
    31ac:      	b	0x3330 <generic_fexit_filter_arg+0x3330>
    31b0:      	cmp	w8, #0x1
    31b4:      	b.eq	0x3314 <generic_fexit_filter_arg+0x3314>
    31b8:      	cmp	w8, #0x2
    31bc:      	b.ne	0xc4 <generic_fexit_filter_arg+0xc4>
    31c0:      	ldrh	w10, [x25]
    31c4:      	b	0x3330 <generic_fexit_filter_arg+0x3330>
    31c8:      	ldrb	w10, [x25]
    31cc:      	b	0x31d4 <generic_fexit_filter_arg+0x31d4>
    31d0:      	ldrh	w10, [x25]
    31d4:      	cmp	w9, w10
    31d8:      	b.ne	0x124 <generic_fexit_filter_arg+0x124>
    31dc:      	cmp	w8, #0x3
    31e0:      	cset	w22, eq
    31e4:      	cbnz	x22, 0x140 <generic_fexit_filter_arg+0x140>
    31e8:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    31ec:      	ldr	x9, [x25]
    31f0:      	cmp	x9, x10
    31f4:      	b.hs	0x124 <generic_fexit_filter_arg+0x124>
    31f8:      	b	0x140 <generic_fexit_filter_arg+0x140>
    31fc:      	ldr	x9, [x25]
    3200:      	cmp	x9, x10
    3204:      	b.ls	0x124 <generic_fexit_filter_arg+0x124>
    3208:      	b	0x140 <generic_fexit_filter_arg+0x140>
    320c:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3210:      	mov	w8, #0x1                // =1
    3214:      	add	x9, sp, #0x60
    3218:      	ldr	x0, [x0]
    321c:      	b	0x3294 <generic_fexit_filter_arg+0x3294>
    3220:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3224:      	mov	w8, #0x1                // =1
    3228:      	add	x9, sp, #0x60
    322c:      	ldr	x0, [x0]
    3230:      	b	0x3294 <generic_fexit_filter_arg+0x3294>
    3234:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3238:      	mov	w8, #0x1                // =1
    323c:      	add	x9, sp, #0x60
    3240:      	ldr	x0, [x0]
    3244:      	b	0x3294 <generic_fexit_filter_arg+0x3294>
    3248:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    324c:      	mov	w8, #0x1                // =1
    3250:      	add	x9, sp, #0x60
    3254:      	ldr	x0, [x0]
    3258:      	b	0x3294 <generic_fexit_filter_arg+0x3294>
    325c:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3260:      	mov	w8, #0x1                // =1
    3264:      	add	x9, sp, #0x60
    3268:      	ldr	x0, [x0]
    326c:      	b	0x3294 <generic_fexit_filter_arg+0x3294>
    3270:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3274:      	mov	w8, #0x1                // =1
    3278:      	add	x9, sp, #0x60
    327c:      	ldr	x0, [x0]
    3280:      	b	0x3294 <generic_fexit_filter_arg+0x3294>
    3284:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3288:      	mov	w8, #0x1                // =1
    328c:      	add	x9, sp, #0x60
    3290:      	ldr	x0, [x0]
    3294:      	add	x1, sp, #0x60
    3298:      	blr	x8
    329c:      	cbz	x0, 0x32b8 <generic_fexit_filter_arg+0x32b8>
    32a0:      	mov	w8, #0x1                // =1
    32a4:      	mov	x1, x19
    32a8:      	blr	x8
    32ac:      	cmp	x0, #0x0
    32b0:      	cset	w22, ne
    32b4:      	b	0x32bc <generic_fexit_filter_arg+0x32bc>
    32b8:      	mov	x22, xzr
    32bc:      	ldp	x12, x16, [sp, #0x48]
    32c0:      	mov	w17, #0x1               // =1
    32c4:      	ldr	w8, [x21, #0x4]
    32c8:      	ldr	x0, [sp, #0x38]
    32cc:      	cmp	w8, #0x25
    32d0:      	b.hi	0x3300 <generic_fexit_filter_arg+0x3300>
    32d4:      	mov	x9, #0x50               // =80
    32d8:      	ldr	x19, [sp, #0x30]
    32dc:      	lsl	x8, x17, x8
    32e0:      	movk	x9, #0xc00, lsl #16
    32e4:      	movk	x9, #0x20, lsl #32
    32e8:      	tst	x8, x9
    32ec:      	b.eq	0x1ce4 <generic_fexit_filter_arg+0x1ce4>
    32f0:      	cmp	x22, #0x0
    32f4:      	cset	w22, eq
    32f8:      	cbnz	x22, 0x140 <generic_fexit_filter_arg+0x140>
    32fc:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    3300:      	ldr	x19, [sp, #0x30]
    3304:      	cbnz	x22, 0x140 <generic_fexit_filter_arg+0x140>
    3308:      	b	0xc4 <generic_fexit_filter_arg+0xc4>
    330c:      	ldrb	w10, [x25]
    3310:      	b	0x3320 <generic_fexit_filter_arg+0x3320>
    3314:      	ldrh	w10, [x25]
    3318:      	b	0x3320 <generic_fexit_filter_arg+0x3320>
    331c:      	ldr	w9, [x25]
    3320:      	cmp	w9, w10
    3324:      	b.hs	0x124 <generic_fexit_filter_arg+0x124>
    3328:      	b	0x140 <generic_fexit_filter_arg+0x140>
    332c:      	ldr	w9, [x25]
    3330:      	cmp	w9, w10
    3334:      	b.ls	0x124 <generic_fexit_filter_arg+0x124>
    3338:      	b	0x140 <generic_fexit_filter_arg+0x140>
    333c:      	ldr	x8, [sp, #0x40]
    3340:      	adrp	x1, 0x3000 <generic_fexit_filter_arg+0x3000>
    3344:      	mov	w9, #0xc                // =12
    3348:      	mov	x0, x23
    334c:      	stur	w8, [x19, #0x43]
    3350:      	mov	w8, #0x4                // =4
    3354:      	mov	w2, #0x4                // =4
    3358:      	ldr	x1, [x1]
    335c:      	blr	x9
    3360:      	adrp	x1, 0x3000 <generic_fexit_filter_arg+0x3000>
    3364:      	mov	w8, #0x5                // =5
    3368:      	mov	w9, #0xc                // =12
    336c:      	ldr	x1, [x1]
    3370:      	mov	x0, x23
    3374:      	mov	w2, #0x5                // =5
    3378:      	blr	x9
    337c:      	ldp	x20, x19, [sp, #0xe0]
    3380:      	mov	w0, wzr
    3384:      	ldr	x29, [sp, #0xa0]
    3388:      	ldp	x22, x21, [sp, #0xd0]
    338c:      	ldp	x24, x23, [sp, #0xc0]
    3390:      	ldp	x30, x25, [sp, #0xb0]
    3394:      	add	sp, sp, #0xf0
    3398:      	ret
    339c:      	ldrb	w8, [x19]
    33a0:      	cbz	w8, 0x33ac <generic_fexit_filter_arg+0x33ac>
    33a4:      	mov	w8, wzr
    33a8:      	b	0x33f8 <generic_fexit_filter_arg+0x33f8>
    33ac:      	ldrb	w8, [x19, #0x1]
    33b0:      	cbz	w8, 0x33bc <generic_fexit_filter_arg+0x33bc>
    33b4:      	mov	w8, #0x1                // =1
    33b8:      	b	0x33f8 <generic_fexit_filter_arg+0x33f8>
    33bc:      	ldrb	w8, [x19, #0x2]
    33c0:      	cbz	w8, 0x33cc <generic_fexit_filter_arg+0x33cc>
    33c4:      	mov	w8, #0x2                // =2
    33c8:      	b	0x33f8 <generic_fexit_filter_arg+0x33f8>
    33cc:      	ldrb	w8, [x19, #0x3]
    33d0:      	cbz	w8, 0x33dc <generic_fexit_filter_arg+0x33dc>
    33d4:      	mov	w8, #0x3                // =3
    33d8:      	b	0x33f8 <generic_fexit_filter_arg+0x33f8>
    33dc:      	ldrb	w8, [x19, #0x4]
    33e0:      	cbz	w8, 0x33ec <generic_fexit_filter_arg+0x33ec>
    33e4:      	mov	w8, #0x4                // =4
    33e8:      	b	0x33f8 <generic_fexit_filter_arg+0x33f8>
    33ec:      	ldrb	w8, [x19, #0x5]
    33f0:      	cbz	w8, 0x3418 <generic_fexit_filter_arg+0x3418>
    33f4:      	mov	w8, #0x5                // =5
    33f8:      	stur	w8, [x19, #0x3f]
    33fc:      	adrp	x1, 0x3000 <generic_fexit_filter_arg+0x3000>
    3400:      	mov	w8, #0x3                // =3
    3404:      	mov	w9, #0xc                // =12
    3408:      	ldr	x1, [x1]
    340c:      	mov	x0, x23
    3410:      	mov	w2, #0x3                // =3
    3414:      	blr	x9
    3418:      	ldr	x19, [x20, #0x60]
    341c:      	mov	w8, #0xe                // =14
    3420:      	blr	x8
    3424:      	stp	x19, x0, [sp, #0x60]
    3428:      	adrp	x19, 0x3000 <generic_fexit_filter_arg+0x3000>
    342c:      	mov	w8, #0x1                // =1
    3430:      	add	x9, sp, #0x60
    3434:      	add	x1, sp, #0x60
    3438:      	ldr	x19, [x19]
    343c:      	mov	x0, x19
    3440:      	blr	x8
    3444:      	cbz	x0, 0x337c <generic_fexit_filter_arg+0x337c>
    3448:      	mov	w8, #0x3                // =3
    344c:      	add	x9, sp, #0x60
    3450:      	add	x1, sp, #0x60
    3454:      	mov	x0, x19
    3458:      	blr	x8
    345c:      	b	0x337c <generic_fexit_filter_arg+0x337c>

0000000000003460 <generic_fexit_actions>:
    3460:      	sub	sp, sp, #0xe0
    3464:      	str	x29, [sp, #0x90]
    3468:      	stp	x30, x25, [sp, #0xa0]
    346c:      	stp	x24, x23, [sp, #0xb0]
    3470:      	stp	x22, x21, [sp, #0xc0]
    3474:      	stp	x20, x19, [sp, #0xd0]
    3478:      	str	x0, [sp, #0x50]
    347c:      	str	wzr, [sp, #0x5c]
    3480:      	adrp	x29, 0x3000 <generic_fexit_filter_arg+0x3000>
    3484:      	mov	w8, #0x1                // =1
    3488:      	add	x9, sp, #0x5c
    348c:      	add	x1, sp, #0x5c
    3490:      	ldr	x29, [x29]
    3494:      	mov	x0, x29
    3498:      	blr	x8
    349c:      	cbz	x0, 0x3f24 <generic_fexit_actions+0xac4>
    34a0:      	mov	w8, #0x5f04             // =24324
    34a4:      	ldr	w19, [x0, x8]
    34a8:      	cmp	w19, #0x2
    34ac:      	b.lt	0x3f24 <generic_fexit_actions+0xac4>
    34b0:      	mov	w8, #0x5ef8             // =24312
    34b4:      	add	x1, x0, x8
    34b8:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    34bc:      	mov	w8, #0x1                // =1
    34c0:      	ldr	x0, [x0]
    34c4:      	blr	x8
    34c8:      	cbz	x0, 0x3f24 <generic_fexit_actions+0xac4>
    34cc:      	and	x8, x19, #0x7ff
    34d0:      	add	x9, sp, #0x60
    34d4:      	add	x1, sp, #0x60
    34d8:      	ldr	w8, [x0, x8]
    34dc:      	str	wzr, [sp, #0x60]
    34e0:      	add	w8, w8, w19
    34e4:      	and	w8, w8, #0x7ff
    34e8:      	add	x21, x0, x8
    34ec:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    34f0:      	mov	w8, #0x1                // =1
    34f4:      	ldr	x0, [x0]
    34f8:      	blr	x8
    34fc:      	cbz	x0, 0x3544 <generic_fexit_actions+0xe4>
    3500:      	ldrb	w8, [x0]
    3504:      	mov	w11, #0x6               // =6
    3508:      	mov	w14, #0x7               // =7
    350c:      	mov	w10, #0x8               // =8
    3510:      	mov	w12, #0x5               // =5
    3514:      	mov	w13, #0x9               // =9
    3518:      	ands	w8, w8, #0xff
    351c:      	cset	w9, eq
    3520:      	cmp	w8, #0x0
    3524:      	str	w9, [sp, #0x48]
    3528:      	mov	w9, #0x4                // =4
    352c:      	csel	x8, x11, x14, eq
    3530:      	csel	x11, x10, x13, eq
    3534:      	str	x8, [sp, #0x30]
    3538:      	csel	x8, x9, x12, eq
    353c:      	stp	x11, x8, [sp, #0x38]
    3540:      	b	0x3564 <generic_fexit_actions+0x104>
    3544:      	mov	w8, #0x1                // =1
    3548:      	str	w8, [sp, #0x48]
    354c:      	mov	w8, #0x4                // =4
    3550:      	str	x8, [sp, #0x40]
    3554:      	mov	w8, #0x8                // =8
    3558:      	str	x8, [sp, #0x38]
    355c:      	mov	w8, #0x6                // =6
    3560:      	str	x8, [sp, #0x30]
    3564:      	adrp	x25, 0x3000 <generic_fexit_filter_arg+0x3000>
    3568:      	mov	w23, wzr
    356c:      	mov	w19, wzr
    3570:      	ldr	x25, [x25]
    3574:      	add	x20, sp, #0x64
    3578:      	mov	w8, #0x1                // =1
    357c:      	str	w8, [sp, #0x4c]
    3580:      	b	0x3594 <generic_fexit_actions+0x134>
    3584:      	mov	w19, wzr
    3588:      	add	w23, w23, #0x1
    358c:      	cmp	w23, #0x3
    3590:      	b.eq	0x3f00 <generic_fexit_actions+0xaa0>
    3594:      	ldr	w9, [x21]
    3598:      	lsl	w8, w19, #2
    359c:      	add	w8, w8, #0x4
    35a0:      	cmp	w8, w9
    35a4:      	b.hs	0x3f00 <generic_fexit_actions+0xaa0>
    35a8:      	add	x8, x21, w19, uxtw #2
    35ac:      	add	x1, sp, #0x64
    35b0:      	mov	x0, x29
    35b4:      	ldrsw	x24, [x8, #0x4]
    35b8:      	str	wzr, [sp, #0x64]
    35bc:      	mov	w8, #0x1                // =1
    35c0:      	blr	x8
    35c4:      	cbz	x0, 0x3584 <generic_fexit_actions+0x124>
    35c8:      	mov	x22, x0
    35cc:      	cmp	w24, #0x7
    35d0:      	b.gt	0x3600 <generic_fexit_actions+0x1a0>
    35d4:      	cmp	w24, #0x3
    35d8:      	b.gt	0x3650 <generic_fexit_actions+0x1f0>
    35dc:      	cmp	w24, #0x1
    35e0:      	b.gt	0x36d0 <generic_fexit_actions+0x270>
    35e4:      	cbz	w24, 0x3834 <generic_fexit_actions+0x3d4>
    35e8:      	cmp	w24, #0x1
    35ec:      	b.eq	0x36e0 <generic_fexit_actions+0x280>
    35f0:      	adrp	x25, 0x3000 <generic_fexit_filter_arg+0x3000>
    35f4:      	b	0x3938 <generic_fexit_actions+0x4d8>
    35f8:      	nop
    35fc:      	nop
    3600:      	cmp	w24, #0xb
    3604:      	b.gt	0x36a8 <generic_fexit_actions+0x248>
    3608:      	sub	w8, w24, #0xa
    360c:      	cmp	w8, #0x2
    3610:      	b.lo	0x3744 <generic_fexit_actions+0x2e4>
    3614:      	cmp	w24, #0x8
    3618:      	b.eq	0x378c <generic_fexit_actions+0x32c>
    361c:      	cmp	w24, #0x9
    3620:      	b.ne	0x393c <generic_fexit_actions+0x4dc>
    3624:      	add	w19, w19, #0x1
    3628:      	add	x8, x21, w19, uxtw #2
    362c:      	ldr	w0, [x8, #0x4]
    3630:      	ldr	w8, [sp, #0x48]
    3634:      	add	x25, sp, #0x68
    3638:      	cbz	w8, 0x38dc <generic_fexit_actions+0x47c>
    363c:      	sxtw	x8, w0
    3640:      	mov	w9, #0x6d               // =109
    3644:      	blr	x9
    3648:      	mov	w20, #0x2               // =2
    364c:      	b	0x38f0 <generic_fexit_actions+0x490>
    3650:      	sub	w8, w24, #0x6
    3654:      	cmp	w8, #0x2
    3658:      	b.lo	0x3778 <generic_fexit_actions+0x318>
    365c:      	cmp	w24, #0x4
    3660:      	b.eq	0x3794 <generic_fexit_actions+0x334>
    3664:      	cmp	w24, #0x5
    3668:      	b.ne	0x393c <generic_fexit_actions+0x4dc>
    366c:      	add	w8, w19, #0x1
    3670:      	add	x9, x21, #0x4
    3674:      	add	w19, w19, #0x2
    3678:      	ldr	w8, [x9, w8, uxtw #2]
    367c:      	ldr	w20, [x9, w19, uxtw #2]
    3680:      	stp	xzr, xzr, [sp, #0x68]
    3684:      	and	x8, x8, #0x7
    3688:      	cmp	w8, #0x4
    368c:      	b.hi	0x36a0 <generic_fexit_actions+0x240>
    3690:      	add	x9, x22, x8, lsl #2
    3694:      	mov	w10, #0x5ea0            // =24224
    3698:      	ldr	w9, [x9, x10]
    369c:      	cbz	w9, 0x3b18 <generic_fexit_actions+0x6b8>
    36a0:      	add	x20, sp, #0x64
    36a4:      	b	0x393c <generic_fexit_actions+0x4dc>
    36a8:      	cmp	w24, #0xc
    36ac:      	b.eq	0x38e4 <generic_fexit_actions+0x484>
    36b0:      	cmp	w24, #0xd
    36b4:      	b.eq	0x37a4 <generic_fexit_actions+0x344>
    36b8:      	cmp	w24, #0xe
    36bc:      	b.ne	0x393c <generic_fexit_actions+0x4dc>
    36c0:      	ldr	x20, [sp, #0x38]
    36c4:      	add	x25, sp, #0x68
    36c8:      	add	w19, w19, #0x2
    36cc:      	b	0x38f0 <generic_fexit_actions+0x490>
    36d0:      	cmp	w24, #0x2
    36d4:      	b.eq	0x38cc <generic_fexit_actions+0x46c>
    36d8:      	cmp	w24, #0x3
    36dc:      	b.ne	0x35f0 <generic_fexit_actions+0x190>
    36e0:      	add	w8, w19, #0x1
    36e4:      	add	x9, x21, #0x4
    36e8:      	add	w19, w19, #0x2
    36ec:      	ldr	w20, [x9, w19, uxtw #2]
    36f0:      	mov	x25, x21
    36f4:      	ldr	w21, [x9, w8, uxtw #2]
    36f8:      	str	wzr, [sp, #0x78]
    36fc:      	stp	xzr, xzr, [sp, #0x68]
    3700:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3704:      	mov	w8, #0x1                // =1
    3708:      	add	x9, sp, #0x78
    370c:      	add	x1, sp, #0x78
    3710:      	ldr	x0, [x0]
    3714:      	blr	x8
    3718:      	cbz	x0, 0x372c <generic_fexit_actions+0x2cc>
    371c:      	and	x8, x21, #0x7
    3720:      	cmp	w8, #0x4
    3724:      	b.ls	0x3954 <generic_fexit_actions+0x4f4>
    3728:      	mov	w0, wzr
    372c:      	mov	x21, x25
    3730:      	adrp	x25, 0x3000 <generic_fexit_filter_arg+0x3000>
    3734:      	add	x20, sp, #0x64
    3738:      	ldr	x25, [x25]
    373c:      	cbnz	w0, 0x3584 <generic_fexit_actions+0x124>
    3740:      	b	0x393c <generic_fexit_actions+0x4dc>
    3744:      	add	w19, w19, #0x1
    3748:      	add	x8, x21, w19, uxtw #2
    374c:      	ldr	w8, [x8, #0x4]
    3750:      	and	x8, x8, #0x7
    3754:      	cmp	w8, #0x4
    3758:      	b.hi	0x376c <generic_fexit_actions+0x30c>
    375c:      	add	x9, x22, x8, lsl #2
    3760:      	mov	w10, #0x5ea0            // =24224
    3764:      	ldr	w9, [x9, x10]
    3768:      	cbz	w9, 0x3970 <generic_fexit_actions+0x510>
    376c:      	mov	w0, wzr
    3770:      	cbnz	w0, 0x3584 <generic_fexit_actions+0x124>
    3774:      	b	0x393c <generic_fexit_actions+0x4dc>
    3778:      	add	w19, w19, #0x1
    377c:      	add	x8, x21, w19, uxtw #2
    3780:      	ldr	w8, [x8, #0x4]
    3784:      	str	w8, [x22, #0x78]
    3788:      	b	0x393c <generic_fexit_actions+0x4dc>
    378c:      	str	wzr, [sp, #0x4c]
    3790:      	b	0x393c <generic_fexit_actions+0x4dc>
    3794:      	ldr	x20, [sp, #0x40]
    3798:      	add	x25, sp, #0x68
    379c:      	add	w19, w19, #0x1
    37a0:      	b	0x38f0 <generic_fexit_actions+0x490>
    37a4:      	mov	w8, #0xe                // =14
    37a8:      	blr	x8
    37ac:      	str	x0, [sp, #0x88]
    37b0:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    37b4:      	mov	w8, #0x1                // =1
    37b8:      	add	x9, sp, #0x88
    37bc:      	ldr	x0, [x0]
    37c0:      	add	x1, sp, #0x88
    37c4:      	blr	x8
    37c8:      	cbz	x0, 0x393c <generic_fexit_actions+0x4dc>
    37cc:      	ldur	x8, [x0, #0x4]
    37d0:      	mov	x20, x21
    37d4:      	add	x21, sp, #0x78
    37d8:      	add	x1, sp, #0x78
    37dc:      	str	x8, [sp, #0x78]
    37e0:      	mov	w8, #0x2                // =2
    37e4:      	mov	x0, x25
    37e8:      	str	w8, [sp, #0x80]
    37ec:      	mov	w8, #0x1                // =1
    37f0:      	blr	x8
    37f4:      	mov	w9, #0x1                // =1
    37f8:      	str	w9, [sp, #0x98]
    37fc:      	cbz	x0, 0x3aa8 <generic_fexit_actions+0x648>
    3800:      	ldaxr	w8, [x0]
    3804:      	add	w8, w8, #0x1
    3808:      	stlxr	w9, w8, [x0]
    380c:      	cbnz	w9, 0x3800 <generic_fexit_actions+0x3a0>
    3810:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3814:      	mov	w8, #0x3                // =3
    3818:      	add	x9, sp, #0x88
    381c:      	ldr	x0, [x0]
    3820:      	add	x1, sp, #0x88
    3824:      	blr	x8
    3828:      	mov	x21, x20
    382c:      	add	x20, sp, #0x64
    3830:      	b	0x393c <generic_fexit_actions+0x4dc>
    3834:      	add	w8, w19, #0x1
    3838:      	add	x9, x21, #0x4
    383c:      	ldr	w25, [x9, w8, uxtw #2]
    3840:      	add	w8, w19, #0x2
    3844:      	ldr	w20, [x9, w8, uxtw #2]
    3848:      	mov	w8, #0x7d               // =125
    384c:      	blr	x8
    3850:      	str	x0, [sp, #0x68]
    3854:      	str	wzr, [sp, #0x88]
    3858:      	str	x25, [sp, #0x18]
    385c:      	cbz	w25, 0x3dfc <generic_fexit_actions+0x99c>
    3860:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3864:      	mov	w8, #0x1                // =1
    3868:      	add	x9, sp, #0x88
    386c:      	ldr	x0, [x0]
    3870:      	add	x1, sp, #0x88
    3874:      	blr	x8
    3878:      	cbz	x0, 0x3dfc <generic_fexit_actions+0x99c>
    387c:      	mov	x25, x0
    3880:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3884:      	mov	w8, #0x1                // =1
    3888:      	ldr	x0, [x0]
    388c:      	add	x9, sp, #0x88
    3890:      	add	x1, sp, #0x88
    3894:      	blr	x8
    3898:      	ldr	x8, [x22, #0x60]
    389c:      	mov	x2, x0
    38a0:      	cmp	w20, #0x2
    38a4:      	str	x8, [x25]
    38a8:      	ldr	x8, [x22, #0x70]
    38ac:      	str	x8, [x25, #0x8]
    38b0:      	b.eq	0x3c1c <generic_fexit_actions+0x7bc>
    38b4:      	cmp	w20, #0x1
    38b8:      	b.eq	0x3c10 <generic_fexit_actions+0x7b0>
    38bc:      	cbnz	w20, 0x3dfc <generic_fexit_actions+0x99c>
    38c0:      	ldr	w8, [x22, #0x7c]
    38c4:      	str	x21, [sp, #0x8]
    38c8:      	b	0x3c24 <generic_fexit_actions+0x7c4>
    38cc:      	mov	w0, #0x9                // =9
    38d0:      	ldr	w8, [sp, #0x48]
    38d4:      	add	x25, sp, #0x68
    38d8:      	cbnz	w8, 0x363c <generic_fexit_actions+0x1dc>
    38dc:      	mov	w20, #0x3               // =3
    38e0:      	b	0x38f0 <generic_fexit_actions+0x490>
    38e4:      	ldr	x20, [sp, #0x30]
    38e8:      	add	x25, sp, #0x68
    38ec:      	add	w19, w19, #0x3
    38f0:      	str	wzr, [sp, #0x68]
    38f4:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    38f8:      	mov	w8, #0x1                // =1
    38fc:      	add	x1, sp, #0x68
    3900:      	ldr	x0, [x0]
    3904:      	blr	x8
    3908:      	cbz	x0, 0x3930 <generic_fexit_actions+0x4d0>
    390c:      	add	x8, x0, x20, lsl #3
    3910:      	nop
    3914:      	nop
    3918:      	nop
    391c:      	nop
    3920:      	ldaxr	x9, [x8]
    3924:      	add	x9, x9, #0x1
    3928:      	stlxr	w10, x9, [x8]
    392c:      	cbnz	w10, 0x3920 <generic_fexit_actions+0x4c0>
    3930:      	adrp	x25, 0x3000 <generic_fexit_filter_arg+0x3000>
    3934:      	add	x20, sp, #0x64
    3938:      	ldr	x25, [x25]
    393c:      	add	w19, w19, #0x1
    3940:      	str	x24, [x22, #0x70]
    3944:      	add	w23, w23, #0x1
    3948:      	cmp	w23, #0x3
    394c:      	b.ne	0x3594 <generic_fexit_actions+0x134>
    3950:      	b	0x3f00 <generic_fexit_actions+0xaa0>
    3954:      	add	x9, x22, x8, lsl #2
    3958:      	mov	w10, #0x5ea0            // =24224
    395c:      	ldr	w9, [x9, x10]
    3960:      	cbz	w9, 0x3a08 <generic_fexit_actions+0x5a8>
    3964:      	mov	x21, x25
    3968:      	mov	w0, wzr
    396c:      	b	0x3730 <generic_fexit_actions+0x2d0>
    3970:      	add	x8, x22, x8, lsl #3
    3974:      	ldr	x8, [x8, #0x5e78]
    3978:      	and	x8, x8, #0x7ff
    397c:      	add	x8, x22, x8
    3980:      	ldr	x8, [x8, #0xb8]
    3984:      	str	x8, [sp, #0x78]
    3988:      	cbz	x8, 0x376c <generic_fexit_actions+0x30c>
    398c:      	cmp	w24, #0xa
    3990:      	b.ne	0x3bf0 <generic_fexit_actions+0x790>
    3994:      	mov	w8, #0xe                // =14
    3998:      	add	x25, sp, #0x68
    399c:      	mov	x20, x21
    39a0:      	blr	x8
    39a4:      	lsr	x8, x0, #32
    39a8:      	mov	x21, x0
    39ac:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    39b0:      	str	w8, [sp, #0x68]
    39b4:      	mov	w8, #0x1                // =1
    39b8:      	add	x1, sp, #0x68
    39bc:      	ldr	x0, [x0]
    39c0:      	blr	x8
    39c4:      	cbz	x0, 0x39fc <generic_fexit_actions+0x59c>
    39c8:      	ldr	w8, [x0]
    39cc:      	mov	x3, xzr
    39d0:      	add	x9, sp, #0x78
    39d4:      	add	x1, sp, #0x78
    39d8:      	stp	w8, w21, [sp, #0x68]
    39dc:      	ldr	x8, [x0, #0x8]
    39e0:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    39e4:      	add	x2, sp, #0x68
    39e8:      	str	x8, [sp, #0x70]
    39ec:      	mov	w8, #0x2                // =2
    39f0:      	ldr	x0, [x0]
    39f4:      	blr	x8
    39f8:      	mov	w0, wzr
    39fc:      	adrp	x25, 0x3000 <generic_fexit_filter_arg+0x3000>
    3a00:      	mov	x21, x20
    3a04:      	b	0x3734 <generic_fexit_actions+0x2d4>
    3a08:      	add	x8, x22, x8, lsl #3
    3a0c:      	mov	x21, x0
    3a10:      	ldr	x8, [x8, #0x5e78]
    3a14:      	str	wzr, [sp, #0x74]
    3a18:      	and	x8, x8, #0x7ff
    3a1c:      	add	x8, x22, x8
    3a20:      	ldr	w8, [x8, #0x90]
    3a24:      	str	w8, [sp, #0x70]
    3a28:      	mov	w8, #0xe                // =14
    3a2c:      	blr	x8
    3a30:      	lsr	x8, x0, #32
    3a34:      	cmp	w24, #0x1
    3a38:      	str	x8, [sp, #0x68]
    3a3c:      	b.ne	0x3bd4 <generic_fexit_actions+0x774>
    3a40:      	and	x8, x20, #0x7
    3a44:      	cmp	w8, #0x4
    3a48:      	b.hi	0x3728 <generic_fexit_actions+0x2c8>
    3a4c:      	add	x9, x22, x8, lsl #2
    3a50:      	mov	w10, #0x5ea0            // =24224
    3a54:      	add	x20, sp, #0x68
    3a58:      	ldr	w9, [x9, x10]
    3a5c:      	cbnz	w9, 0x3728 <generic_fexit_actions+0x2c8>
    3a60:      	add	x8, x22, x8, lsl #3
    3a64:      	mov	x0, x21
    3a68:      	ldr	x8, [x8, #0x5e78]
    3a6c:      	and	x8, x8, #0x7ff
    3a70:      	add	x2, x22, x8
    3a74:      	ldr	w8, [x2, #0x90]!
    3a78:      	and	x8, x8, #0xfff
    3a7c:      	add	x1, x8, #0x8
    3a80:      	mov	w8, #0x4                // =4
    3a84:      	blr	x8
    3a88:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3a8c:      	mov	x3, xzr
    3a90:      	mov	w8, #0x2                // =2
    3a94:      	ldr	x0, [x0]
    3a98:      	add	x1, sp, #0x68
    3a9c:      	mov	x2, x21
    3aa0:      	blr	x8
    3aa4:      	b	0x3728 <generic_fexit_actions+0x2c8>
    3aa8:      	mov	w8, #0x2                // =2
    3aac:      	add	x10, sp, #0x98
    3ab0:      	add	x1, sp, #0x78
    3ab4:      	add	x2, sp, #0x98
    3ab8:      	mov	x0, x25
    3abc:      	mov	w3, #0x1                // =1
    3ac0:      	blr	x8
    3ac4:      	cbz	x0, 0x3810 <generic_fexit_actions+0x3b0>
    3ac8:      	mov	x21, x0
    3acc:      	adrp	x25, 0x3000 <generic_fexit_filter_arg+0x3000>
    3ad0:      	add	x9, sp, #0x68
    3ad4:      	add	x1, sp, #0x68
    3ad8:      	neg	w8, w21
    3adc:      	strh	w8, [sp, #0x68]
    3ae0:      	mov	w8, #0x3                // =3
    3ae4:      	strh	w8, [sp, #0x6a]
    3ae8:      	mov	x8, #0x3b               // =59
    3aec:      	movk	x8, #0x2, lsl #32
    3af0:      	stur	x8, [sp, #0x6c]
    3af4:      	mov	w8, #0x1                // =1
    3af8:      	ldr	x25, [x25]
    3afc:      	mov	x0, x25
    3b00:      	blr	x8
    3b04:      	cbz	x0, 0x3e9c <generic_fexit_actions+0xa3c>
    3b08:      	ldr	w8, [x0]
    3b0c:      	add	w8, w8, #0x1
    3b10:      	str	w8, [x0]
    3b14:      	b	0x3ec4 <generic_fexit_actions+0xa64>
    3b18:      	add	x8, x22, x8, lsl #3
    3b1c:      	ldr	x8, [x8, #0x5e78]
    3b20:      	and	x8, x8, #0x7ff
    3b24:      	add	x8, x22, x8
    3b28:      	ldr	w8, [x8, #0x90]
    3b2c:      	str	w8, [sp, #0x70]
    3b30:      	mov	w8, #0xe                // =14
    3b34:      	blr	x8
    3b38:      	lsr	x8, x0, #32
    3b3c:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3b40:      	add	x9, sp, #0x68
    3b44:      	str	x8, [sp, #0x68]
    3b48:      	mov	w8, #0x1                // =1
    3b4c:      	add	x1, sp, #0x68
    3b50:      	ldr	x0, [x0]
    3b54:      	blr	x8
    3b58:      	cbz	x0, 0x36a0 <generic_fexit_actions+0x240>
    3b5c:      	and	x8, x20, #0x7
    3b60:      	cmp	w8, #0x4
    3b64:      	b.hi	0x36a0 <generic_fexit_actions+0x240>
    3b68:      	add	x9, x22, x8, lsl #2
    3b6c:      	mov	w10, #0x5ea0            // =24224
    3b70:      	ldr	w9, [x9, x10]
    3b74:      	cbnz	w9, 0x36a0 <generic_fexit_actions+0x240>
    3b78:      	add	x8, x22, x8, lsl #3
    3b7c:      	mov	x20, x21
    3b80:      	mov	x21, x0
    3b84:      	ldr	x8, [x8, #0x5e78]
    3b88:      	str	wzr, [sp, #0x74]
    3b8c:      	and	x8, x8, #0x7ff
    3b90:      	add	x8, x22, x8
    3b94:      	ldr	w8, [x8, #0x90]
    3b98:      	str	w8, [sp, #0x70]
    3b9c:      	mov	w8, #0xe                // =14
    3ba0:      	blr	x8
    3ba4:      	lsr	x8, x0, #32
    3ba8:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3bac:      	mov	x3, xzr
    3bb0:      	str	x8, [sp, #0x68]
    3bb4:      	mov	w8, #0x2                // =2
    3bb8:      	add	x9, sp, #0x68
    3bbc:      	add	x1, sp, #0x68
    3bc0:      	ldr	x0, [x0]
    3bc4:      	mov	x2, x21
    3bc8:      	mov	x21, x20
    3bcc:      	blr	x8
    3bd0:      	b	0x36a0 <generic_fexit_actions+0x240>
    3bd4:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3bd8:      	mov	w8, #0x3                // =3
    3bdc:      	add	x9, sp, #0x68
    3be0:      	ldr	x0, [x0]
    3be4:      	add	x1, sp, #0x68
    3be8:      	blr	x8
    3bec:      	b	0x372c <generic_fexit_actions+0x2cc>
    3bf0:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3bf4:      	mov	w8, #0x3                // =3
    3bf8:      	add	x9, sp, #0x78
    3bfc:      	ldr	x0, [x0]
    3c00:      	add	x1, sp, #0x78
    3c04:      	blr	x8
    3c08:      	cbnz	w0, 0x3584 <generic_fexit_actions+0x124>
    3c0c:      	b	0x393c <generic_fexit_actions+0x4dc>
    3c10:      	ldr	w8, [x22, #0x10]
    3c14:      	str	x21, [sp, #0x8]
    3c18:      	b	0x3c24 <generic_fexit_actions+0x7c4>
    3c1c:      	str	x21, [sp, #0x8]
    3c20:      	mov	x8, xzr
    3c24:      	str	x8, [x25, #0x10]
    3c28:      	str	x25, [sp, #0x10]
    3c2c:      	add	x0, x25, #0x18
    3c30:      	mov	w8, #0x4                // =4
    3c34:      	mov	w9, #0xc8               // =200
    3c38:      	mov	w1, #0xc8               // =200
    3c3c:      	str	x0, [sp, #0x20]
    3c40:      	blr	x8
    3c44:      	str	wzr, [sp, #0x2c]
    3c48:      	adrp	x25, 0x3000 <generic_fexit_filter_arg+0x3000>
    3c4c:      	mov	w8, #0x5e78             // =24184
    3c50:      	mov	x21, xzr
    3c54:      	ldr	x25, [x25]
    3c58:      	add	x20, x22, x8
    3c5c:      	b	0x3c70 <generic_fexit_actions+0x810>
    3c60:      	add	x21, x21, #0x4
    3c64:      	add	x20, x20, #0x8
    3c68:      	cmp	x21, #0x14
    3c6c:      	b.eq	0x3d98 <generic_fexit_actions+0x938>
    3c70:      	str	wzr, [sp, #0x78]
    3c74:      	mov	w8, #0x1                // =1
    3c78:      	add	x9, sp, #0x78
    3c7c:      	add	x1, sp, #0x78
    3c80:      	mov	x0, x29
    3c84:      	blr	x8
    3c88:      	cbz	x0, 0x3d98 <generic_fexit_actions+0x938>
    3c8c:      	mov	w8, #0x5ef8             // =24312
    3c90:      	add	x1, x0, x8
    3c94:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3c98:      	mov	w8, #0x1                // =1
    3c9c:      	ldr	x0, [x0]
    3ca0:      	blr	x8
    3ca4:      	cbz	x0, 0x3d98 <generic_fexit_actions+0x938>
    3ca8:      	add	x8, x0, x21
    3cac:      	ldr	w8, [x8, #0x40]
    3cb0:      	cmn	w8, #0x1
    3cb4:      	b.eq	0x3d98 <generic_fexit_actions+0x938>
    3cb8:      	ldr	x8, [x20]
    3cbc:      	ldr	w9, [x22, #0x4]
    3cc0:      	cmp	x8, x9
    3cc4:      	b.ge	0x3d98 <generic_fexit_actions+0x938>
    3cc8:      	cmp	x21, #0x10
    3ccc:      	b.eq	0x3d2c <generic_fexit_actions+0x8cc>
    3cd0:      	str	wzr, [sp, #0x78]
    3cd4:      	mov	w8, #0x1                // =1
    3cd8:      	add	x9, sp, #0x78
    3cdc:      	add	x1, sp, #0x78
    3ce0:      	mov	x0, x29
    3ce4:      	blr	x8
    3ce8:      	cbz	x0, 0x3d28 <generic_fexit_actions+0x8c8>
    3cec:      	mov	w8, #0x5ef8             // =24312
    3cf0:      	add	x1, x0, x8
    3cf4:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3cf8:      	mov	w8, #0x1                // =1
    3cfc:      	ldr	x0, [x0]
    3d00:      	blr	x8
    3d04:      	cbz	x0, 0x3d28 <generic_fexit_actions+0x8c8>
    3d08:      	add	x8, x0, x21
    3d0c:      	ldr	w9, [x8, #0x44]
    3d10:      	ldr	x8, [x20]
    3d14:      	cmn	w9, #0x1
    3d18:      	b.eq	0x3d2c <generic_fexit_actions+0x8cc>
    3d1c:      	ldr	w9, [x20, #0x8]
    3d20:      	sub	w9, w9, w8
    3d24:      	b	0x3d38 <generic_fexit_actions+0x8d8>
    3d28:      	ldr	x8, [x20]
    3d2c:      	ldr	w9, [x22, #0x4]
    3d30:      	sub	w9, w9, w8
    3d34:      	add	w9, w9, #0x4
    3d38:      	cmp	w9, #0x1
    3d3c:      	b.lt	0x3c60 <generic_fexit_actions+0x800>
    3d40:      	mov	w10, #0x3ffc            // =16380
    3d44:      	cmp	w9, #0x28
    3d48:      	add	w8, w8, w10
    3d4c:      	mov	w10, #0x28              // =40
    3d50:      	csel	w29, w9, w10, lt
    3d54:      	ldr	w9, [sp, #0x2c]
    3d58:      	and	x8, x8, #0x3fff
    3d5c:      	add	x8, x22, x8
    3d60:      	mov	w1, w29
    3d64:      	add	x2, x8, #0x90
    3d68:      	mov	w8, #0x4                // =4
    3d6c:      	and	w25, w9, #0xff
    3d70:      	ldr	x9, [sp, #0x20]
    3d74:      	add	x0, x9, x25
    3d78:      	blr	x8
    3d7c:      	add	w8, w29, w25
    3d80:      	adrp	x25, 0x3000 <generic_fexit_filter_arg+0x3000>
    3d84:      	adrp	x29, 0x3000 <generic_fexit_filter_arg+0x3000>
    3d88:      	str	w8, [sp, #0x2c]
    3d8c:      	ldr	x25, [x25]
    3d90:      	ldr	x29, [x29]
    3d94:      	b	0x3c60 <generic_fexit_actions+0x800>
    3d98:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3d9c:      	mov	w8, #0x1                // =1
    3da0:      	ldr	x0, [x0]
    3da4:      	ldr	x1, [sp, #0x10]
    3da8:      	blr	x8
    3dac:      	ldr	x21, [sp, #0x8]
    3db0:      	cbz	x0, 0x3ddc <generic_fexit_actions+0x97c>
    3db4:      	ldr	x9, [sp, #0x68]
    3db8:      	ldr	x11, [sp, #0x18]
    3dbc:      	mov	x10, #-0x4240           // =-16960
    3dc0:      	movk	x10, #0xfff0, lsl #16
    3dc4:      	ldr	x8, [x0]
    3dc8:      	madd	x9, x11, x10, x9
    3dcc:      	cmp	x8, x9
    3dd0:      	b.ls	0x3ddc <generic_fexit_actions+0x97c>
    3dd4:      	str	wzr, [sp, #0x4c]
    3dd8:      	b	0x3e04 <generic_fexit_actions+0x9a4>
    3ddc:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3de0:      	mov	x3, xzr
    3de4:      	mov	w8, #0x2                // =2
    3de8:      	ldr	x0, [x0]
    3dec:      	ldr	x1, [sp, #0x10]
    3df0:      	add	x9, sp, #0x68
    3df4:      	add	x2, sp, #0x68
    3df8:      	blr	x8
    3dfc:      	adrp	x25, 0x3000 <generic_fexit_filter_arg+0x3000>
    3e00:      	ldr	x25, [x25]
    3e04:      	add	w8, w19, #0x3
    3e08:      	add	x20, sp, #0x64
    3e0c:      	add	x8, x21, w8, uxtw #2
    3e10:      	ldr	w8, [x8, #0x4]
    3e14:      	cbz	w8, 0x3e40 <generic_fexit_actions+0x9e0>
    3e18:      	ldrb	w8, [x22, #0x1]
    3e1c:      	adrp	x1, 0x3000 <generic_fexit_filter_arg+0x3000>
    3e20:      	ldr	x0, [sp, #0x50]
    3e24:      	mov	x2, xzr
    3e28:      	orr	w8, w8, #0x2
    3e2c:      	strb	w8, [x22, #0x1]
    3e30:      	mov	w8, #0x1b               // =27
    3e34:      	ldr	x1, [x1]
    3e38:      	blr	x8
    3e3c:      	str	x0, [x22, #0x80]
    3e40:      	add	w8, w19, #0x4
    3e44:      	add	x8, x21, w8, uxtw #2
    3e48:      	ldr	w8, [x8, #0x4]
    3e4c:      	cbz	w8, 0x3e7c <generic_fexit_actions+0xa1c>
    3e50:      	ldrb	w8, [x22, #0x1]
    3e54:      	adrp	x1, 0x3000 <generic_fexit_filter_arg+0x3000>
    3e58:      	ldr	x0, [sp, #0x50]
    3e5c:      	mov	w9, #0x100              // =256
    3e60:      	mov	w2, #0x100              // =256
    3e64:      	orr	w8, w8, #0x4
    3e68:      	strb	w8, [x22, #0x1]
    3e6c:      	mov	w8, #0x1b               // =27
    3e70:      	ldr	x1, [x1]
    3e74:      	blr	x8
    3e78:      	str	x0, [x22, #0x88]
    3e7c:      	add	w19, w19, #0x5
    3e80:      	add	x8, x21, w19, uxtw #2
    3e84:      	ldr	w8, [x8, #0x4]
    3e88:      	cbz	w8, 0x393c <generic_fexit_actions+0x4dc>
    3e8c:      	ldrb	w8, [x22, #0x1]
    3e90:      	orr	w8, w8, #0x8
    3e94:      	strb	w8, [x22, #0x1]
    3e98:      	b	0x393c <generic_fexit_actions+0x4dc>
    3e9c:      	mov	w8, #0x1                // =1
    3ea0:      	mov	x3, xzr
    3ea4:      	add	x9, sp, #0x9c
    3ea8:      	str	w8, [sp, #0x9c]
    3eac:      	mov	w8, #0x2                // =2
    3eb0:      	add	x10, sp, #0x68
    3eb4:      	add	x1, sp, #0x68
    3eb8:      	add	x2, sp, #0x9c
    3ebc:      	mov	x0, x25
    3ec0:      	blr	x8
    3ec4:      	adrp	x25, 0x3000 <generic_fexit_filter_arg+0x3000>
    3ec8:      	ldr	x25, [x25]
    3ecc:      	cbz	w21, 0x3810 <generic_fexit_actions+0x3b0>
    3ed0:      	mov	w8, #0x1                // =1
    3ed4:      	add	x9, sp, #0x78
    3ed8:      	add	x1, sp, #0x78
    3edc:      	mov	x0, x25
    3ee0:      	blr	x8
    3ee4:      	cbz	x0, 0x3810 <generic_fexit_actions+0x3b0>
    3ee8:      	ldr	w8, [sp, #0x98]
    3eec:      	ldaxr	w9, [x0]
    3ef0:      	add	w9, w9, w8
    3ef4:      	stlxr	w10, w9, [x0]
    3ef8:      	cbnz	w10, 0x3eec <generic_fexit_actions+0xa8c>
    3efc:      	b	0x3810 <generic_fexit_actions+0x3b0>
    3f00:      	ldr	w8, [sp, #0x4c]
    3f04:      	cbz	w8, 0x3f24 <generic_fexit_actions+0xac4>
    3f08:      	adrp	x1, 0x3000 <generic_fexit_filter_arg+0x3000>
    3f0c:      	mov	w8, #0x5                // =5
    3f10:      	mov	w9, #0xc                // =12
    3f14:      	ldr	x1, [x1]
    3f18:      	ldr	x0, [sp, #0x50]
    3f1c:      	mov	w2, #0x5                // =5
    3f20:      	blr	x9
    3f24:      	ldp	x20, x19, [sp, #0xd0]
    3f28:      	mov	w0, wzr
    3f2c:      	ldr	x29, [sp, #0x90]
    3f30:      	ldp	x22, x21, [sp, #0xc0]
    3f34:      	ldp	x24, x23, [sp, #0xb0]
    3f38:      	ldp	x30, x25, [sp, #0xa0]
    3f3c:      	add	sp, sp, #0xe0
    3f40:      	ret
    3f44:      	nop
    3f48:      	nop
    3f4c:      	nop

0000000000003f50 <generic_fexit_output>:
    3f50:      	sub	sp, sp, #0x30
    3f54:      	stp	x30, x21, [sp, #0x10]
    3f58:      	stp	x20, x19, [sp, #0x20]
    3f5c:      	mov	x20, x0
    3f60:      	str	wzr, [sp, #0x4]
    3f64:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3f68:      	mov	w8, #0x1                // =1
    3f6c:      	ldr	x0, [x0]
    3f70:      	add	x9, sp, #0x4
    3f74:      	add	x1, sp, #0x4
    3f78:      	blr	x8
    3f7c:      	cbz	x0, 0x41f0 <generic_fexit_output+0x2a0>
    3f80:      	ldr	w8, [x0, #0x4]
    3f84:      	mov	x19, x0
    3f88:      	mov	w9, #0x2328             // =9000
    3f8c:      	str	wzr, [sp, #0x8]
    3f90:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3f94:      	add	x1, sp, #0x8
    3f98:      	ldr	x0, [x0]
    3f9c:      	add	w8, w8, #0x90
    3fa0:      	and	w8, w8, #0x7fff
    3fa4:      	cmp	w8, w9
    3fa8:      	csel	w21, w8, w9, lo
    3fac:      	mov	w8, #0x1                // =1
    3fb0:      	add	x9, sp, #0x8
    3fb4:      	blr	x8
    3fb8:      	cbz	x0, 0x4034 <generic_fexit_output+0xe4>
    3fbc:      	ldrb	w8, [x0, #0x28]
    3fc0:      	cbz	w8, 0x4034 <generic_fexit_output+0xe4>
    3fc4:      	adrp	x1, 0x3000 <generic_fexit_filter_arg+0x3000>
    3fc8:      	mov	w8, #-0x1               // =-1
    3fcc:      	mov	w9, #0x19               // =25
    3fd0:      	ldr	x1, [x1]
    3fd4:      	mov	x0, x20
    3fd8:      	mov	w2, #-0x1               // =-1
    3fdc:      	mov	x3, x19
    3fe0:      	mov	x4, x21
    3fe4:      	blr	x9
    3fe8:      	tbnz	x0, #0x3f, 0x40e4 <generic_fexit_output+0x194>
    3fec:      	str	wzr, [sp, #0xc]
    3ff0:      	adrp	x0, 0x3000 <generic_fexit_filter_arg+0x3000>
    3ff4:      	mov	w8, #0x1                // =1
    3ff8:      	add	x9, sp, #0xc
    3ffc:      	ldr	x0, [x0]
    4000:      	add	x1, sp, #0xc
    4004:      	blr	x8
    4008:      	cbz	x0, 0x41f0 <generic_fexit_output+0x2a0>
    400c:      	add	x8, x0, #0x8
    4010:      	nop
    4014:      	nop
    4018:      	nop
    401c:      	nop
    4020:      	ldaxr	x9, [x8]
    4024:      	add	x9, x9, #0x1
    4028:      	stlxr	w10, x9, [x8]
    402c:      	cbnz	w10, 0x4020 <generic_fexit_output+0xd0>
    4030:      	b	0x41f0 <generic_fexit_output+0x2a0>
    4034:      	adrp	x0, 0x4000 <generic_fexit_output+0xb0>
    4038:      	mov	x3, xzr
    403c:      	mov	w8, #0x82               // =130
    4040:      	ldr	x0, [x0]
    4044:      	mov	x1, x19
    4048:      	mov	x2, x21
    404c:      	blr	x8
    4050:      	tbnz	x0, #0x3f, 0x4094 <generic_fexit_output+0x144>
    4054:      	str	wzr, [sp, #0xc]
    4058:      	adrp	x0, 0x4000 <generic_fexit_output+0xb0>
    405c:      	mov	w8, #0x1                // =1
    4060:      	add	x9, sp, #0xc
    4064:      	ldr	x0, [x0]
    4068:      	add	x1, sp, #0xc
    406c:      	blr	x8
    4070:      	cbz	x0, 0x41f0 <generic_fexit_output+0x2a0>
    4074:      	add	x8, x0, #0x8
    4078:      	nop
    407c:      	nop
    4080:      	ldaxr	x9, [x8]
    4084:      	add	x9, x9, #0x1
    4088:      	stlxr	w10, x9, [x8]
    408c:      	cbnz	w10, 0x4080 <generic_fexit_output+0x130>
    4090:      	b	0x41f0 <generic_fexit_output+0x2a0>
    4094:      	mov	x19, x0
    4098:      	str	wzr, [sp, #0xc]
    409c:      	adrp	x0, 0x4000 <generic_fexit_output+0xb0>
    40a0:      	mov	w8, #0x1                // =1
    40a4:      	ldr	x0, [x0]
    40a8:      	add	x9, sp, #0xc
    40ac:      	add	x1, sp, #0xc
    40b0:      	blr	x8
    40b4:      	cbz	x0, 0x41f0 <generic_fexit_output+0x2a0>
    40b8:      	mov	x8, x19
    40bc:      	cmn	x19, #0xc
    40c0:      	b.gt	0x4134 <generic_fexit_output+0x1e4>
    40c4:      	cmn	x8, #0x1c
    40c8:      	b.eq	0x4174 <generic_fexit_output+0x224>
    40cc:      	cmn	x8, #0x16
    40d0:      	b.eq	0x418c <generic_fexit_output+0x23c>
    40d4:      	cmn	x8, #0x10
    40d8:      	b.ne	0x4184 <generic_fexit_output+0x234>
    40dc:      	add	x8, x0, #0x2f0
    40e0:      	b	0x41a0 <generic_fexit_output+0x250>
    40e4:      	mov	x19, x0
    40e8:      	str	wzr, [sp, #0xc]
    40ec:      	adrp	x0, 0x4000 <generic_fexit_output+0xb0>
    40f0:      	mov	w8, #0x1                // =1
    40f4:      	ldr	x0, [x0]
    40f8:      	add	x9, sp, #0xc
    40fc:      	add	x1, sp, #0xc
    4100:      	blr	x8
    4104:      	cbz	x0, 0x41f0 <generic_fexit_output+0x2a0>
    4108:      	mov	x8, x19
    410c:      	cmn	x19, #0xc
    4110:      	b.gt	0x4154 <generic_fexit_output+0x204>
    4114:      	cmn	x8, #0x1c
    4118:      	b.eq	0x41b4 <generic_fexit_output+0x264>
    411c:      	cmn	x8, #0x16
    4120:      	b.eq	0x41cc <generic_fexit_output+0x27c>
    4124:      	cmn	x8, #0x10
    4128:      	b.ne	0x41c4 <generic_fexit_output+0x274>
    412c:      	add	x8, x0, #0x2f0
    4130:      	b	0x41e0 <generic_fexit_output+0x290>
    4134:      	cmn	x8, #0xb
    4138:      	b.eq	0x417c <generic_fexit_output+0x22c>
    413c:      	cmn	x8, #0x7
    4140:      	b.eq	0x4194 <generic_fexit_output+0x244>
    4144:      	cmn	x8, #0x2
    4148:      	b.ne	0x4184 <generic_fexit_output+0x234>
    414c:      	add	x8, x0, #0x2e0
    4150:      	b	0x41a0 <generic_fexit_output+0x250>
    4154:      	cmn	x8, #0xb
    4158:      	b.eq	0x41bc <generic_fexit_output+0x26c>
    415c:      	cmn	x8, #0x7
    4160:      	b.eq	0x41d4 <generic_fexit_output+0x284>
    4164:      	cmn	x8, #0x2
    4168:      	b.ne	0x41c4 <generic_fexit_output+0x274>
    416c:      	add	x8, x0, #0x2e0
    4170:      	b	0x41e0 <generic_fexit_output+0x290>
    4174:      	add	x8, x0, #0x300
    4178:      	b	0x41a0 <generic_fexit_output+0x250>
    417c:      	add	x8, x0, #0x308
    4180:      	b	0x41a0 <generic_fexit_output+0x250>
    4184:      	add	x8, x0, #0x2d8
    4188:      	b	0x41a0 <generic_fexit_output+0x250>
    418c:      	add	x8, x0, #0x2f8
    4190:      	b	0x41a0 <generic_fexit_output+0x250>
    4194:      	add	x8, x0, #0x2e8
    4198:      	nop
    419c:      	nop
    41a0:      	ldaxr	x9, [x8]
    41a4:      	add	x9, x9, #0x1
    41a8:      	stlxr	w10, x9, [x8]
    41ac:      	cbnz	w10, 0x41a0 <generic_fexit_output+0x250>
    41b0:      	b	0x41f0 <generic_fexit_output+0x2a0>
    41b4:      	add	x8, x0, #0x300
    41b8:      	b	0x41e0 <generic_fexit_output+0x290>
    41bc:      	add	x8, x0, #0x308
    41c0:      	b	0x41e0 <generic_fexit_output+0x290>
    41c4:      	add	x8, x0, #0x2d8
    41c8:      	b	0x41e0 <generic_fexit_output+0x290>
    41cc:      	add	x8, x0, #0x2f8
    41d0:      	b	0x41e0 <generic_fexit_output+0x290>
    41d4:      	add	x8, x0, #0x2e8
    41d8:      	nop
    41dc:      	nop
    41e0:      	ldaxr	x9, [x8]
    41e4:      	add	x9, x9, #0x1
    41e8:      	stlxr	w10, x9, [x8]
    41ec:      	cbnz	w10, 0x41e0 <generic_fexit_output+0x290>
    41f0:      	ldp	x20, x19, [sp, #0x20]
    41f4:      	mov	w0, wzr
    41f8:      	ldp	x30, x21, [sp, #0x10]
    41fc:      	add	sp, sp, #0x30
    4200:      	ret

Disassembly of section fexit/generic_fexit:

0000000000000000 <generic_fexit_event>:
       0:      	sub	sp, sp, #0x160
       4:      	str	x29, [sp, #0x110]
       8:      	stp	x30, x25, [sp, #0x120]
       c:      	stp	x24, x23, [sp, #0x130]
      10:      	stp	x22, x21, [sp, #0x140]
      14:      	stp	x20, x19, [sp, #0x150]
      18:      	mov	w8, #0xb8               // =184
      1c:      	add	x9, sp, #0x68
      20:      	add	x1, sp, #0x68
      24:      	mov	x19, x0
      28:      	blr	x8
      2c:      	ldr	x8, [sp, #0x68]
      30:      	str	wzr, [sp, #0x74]
      34:      	adrp	x24, 0x0 <generic_fexit_event>
      38:      	add	x9, sp, #0x74
      3c:      	add	x1, sp, #0x74
      40:      	str	x8, [sp, #0x78]
      44:      	mov	w8, #0x1                // =1
      48:      	ldr	x24, [x24]
      4c:      	mov	x0, x24
      50:      	blr	x8
      54:      	cbz	x0, 0x5a4 <generic_fexit_event+0x5a4>
      58:      	mov	w8, #0x5ea0             // =24224
      5c:      	mov	x20, x0
      60:      	add	x25, x0, x8
      64:      	adrp	x0, 0x0 <generic_fexit_event>
      68:      	mov	w8, #0x1                // =1
      6c:      	mov	x1, x25
      70:      	str	wzr, [x1, #0x58]!
      74:      	ldr	x0, [x0]
      78:      	blr	x8
      7c:      	cbz	x0, 0x5a4 <generic_fexit_event+0x5a4>
      80:      	ldr	w8, [x0]
      84:      	mov	x29, x0
      88:      	str	x8, [x20, #0x60]
      8c:      	mov	w8, #0xe                // =14
      90:      	blr	x8
      94:      	cmn	x0, #0x16
      98:      	b.ne	0xbc <generic_fexit_event+0xbc>
      9c:      	add	x2, x19, #0xe8
      a0:      	mov	w8, #0x8                // =8
      a4:      	mov	w9, #0x4                // =4
      a8:      	add	x10, sp, #0xb0
      ac:      	add	x0, sp, #0xb0
      b0:      	mov	w1, #0x8                // =8
      b4:      	blr	x9
      b8:      	ldr	x0, [sp, #0xb0]
      bc:      	str	x0, [x20, #0x68]
      c0:      	mov	w8, #0xe                // =14
      c4:      	blr	x8
      c8:      	ldp	x8, x9, [x20, #0x60]
      cc:      	adrp	x22, 0x0 <generic_fexit_event>
      d0:      	add	x1, sp, #0xb0
      d4:      	str	w0, [x20, #0x7c]
      d8:      	stp	x8, x9, [sp, #0xb0]
      dc:      	mov	w8, #0x1                // =1
      e0:      	add	x9, sp, #0xb0
      e4:      	ldr	x22, [x22]
      e8:      	mov	x0, x22
      ec:      	blr	x8
      f0:      	cbz	x0, 0x5a4 <generic_fexit_event+0x5a4>
      f4:      	ldp	x21, x9, [x0]
      f8:      	add	x1, sp, #0xb0
      fc:      	ldr	x8, [x0, #0x10]
     100:      	mov	x0, x22
     104:      	stp	x8, x9, [sp, #0x58]
     108:      	mov	w8, #0x3                // =3
     10c:      	add	x9, sp, #0xb0
     110:      	blr	x8
     114:      	mov	x22, x20
     118:      	str	x21, [x22, #0x90]!
     11c:      	ldp	w8, w23, [x29, #0x58]
     120:      	cbz	w23, 0x214 <generic_fexit_event+0x214>
     124:      	str	w8, [sp, #0x50]
     128:      	str	wzr, [x25]
     12c:      	mov	w8, #0x1                // =1
     130:      	add	x9, sp, #0x84
     134:      	add	x1, sp, #0x84
     138:      	mov	x0, x24
     13c:      	str	wzr, [sp, #0x84]
     140:      	ldr	x25, [sp, #0x78]
     144:      	blr	x8
     148:      	cbz	x0, 0x280 <generic_fexit_event+0x280>
     14c:      	mov	w21, #0x5ea0            // =24224
     150:      	mov	w9, #0xc                // =12
     154:      	ldr	w8, [x0, x21]
     158:      	str	x9, [x0, #0x5e78]
     15c:      	str	w8, [x0, #0x98]
     160:      	cbz	w8, 0x2d0 <generic_fexit_event+0x2d0>
     164:      	mov	w8, #0x4                // =4
     168:      	add	x21, x8, #0x8
     16c:      	ldr	w8, [x29, #0x60]
     170:      	cmp	w8, #0xb
     174:      	b.eq	0x294 <generic_fexit_event+0x294>
     178:      	cmp	w8, #0xa
     17c:      	b.ne	0x1b8 <generic_fexit_event+0x1b8>
     180:      	ldr	w8, [x20, #0x10]
     184:      	ldr	w9, [x20, #0x7c]
     188:      	adrp	x0, 0x0 <generic_fexit_event>
     18c:      	mov	x3, xzr
     190:      	add	x10, sp, #0xb0
     194:      	add	x1, sp, #0x78
     198:      	stp	w8, w9, [sp, #0xb0]
     19c:      	ldr	x8, [x20, #0x18]
     1a0:      	add	x9, sp, #0x78
     1a4:      	add	x2, sp, #0xb0
     1a8:      	str	x8, [sp, #0xb8]
     1ac:      	mov	w8, #0x2                // =2
     1b0:      	ldr	x0, [x0]
     1b4:      	blr	x8
     1b8:      	ldr	w8, [sp, #0x50]
     1bc:      	and	x24, x21, #0x1fff
     1c0:      	cmp	w8, #0x3
     1c4:      	b.eq	0x220 <generic_fexit_event+0x220>
     1c8:      	cmp	w8, #0x2
     1cc:      	b.ne	0x340 <generic_fexit_event+0x340>
     1d0:      	str	wzr, [x22, x24]
     1d4:      	add	x21, x24, #0x4
     1d8:      	mov	w8, #0xfff              // =4095
     1dc:      	ldr	x2, [sp, #0x60]
     1e0:      	mov	w25, #0x4               // =4
     1e4:      	add	x23, x22, x21
     1e8:      	ldr	x24, [sp, #0x78]
     1ec:      	add	x0, x23, #0x8
     1f0:      	cmp	x24, #0xfff
     1f4:      	csel	x22, x24, x8, lo
     1f8:      	mov	w8, #0x4                // =4
     1fc:      	mov	w1, w22
     200:      	blr	x8
     204:      	tbnz	w0, #0x1f, 0x2c0 <generic_fexit_event+0x2c0>
     208:      	add	x25, x22, #0x8
     20c:      	str	w22, [x23, #0x4]
     210:      	b	0x2c4 <generic_fexit_event+0x2c4>
     214:      	mov	w24, #0x8               // =8
     218:      	cmp	w8, #0x3
     21c:      	b.ne	0x1c8 <generic_fexit_event+0x1c8>
     220:      	ldr	x8, [sp, #0x58]
     224:      	add	x25, x24, #0x4
     228:      	str	wzr, [x22, x24]
     22c:      	cbz	x8, 0x310 <generic_fexit_event+0x310>
     230:      	ldr	x2, [sp, #0x60]
     234:      	ldr	x21, [sp, #0x78]
     238:      	mov	w8, #0x10               // =16
     23c:      	mov	w9, #0x4                // =4
     240:      	add	x10, sp, #0xb0
     244:      	add	x0, sp, #0xb0
     248:      	mov	w1, #0x10               // =16
     24c:      	blr	x9
     250:      	tbnz	w0, #0x1f, 0x330 <generic_fexit_event+0x330>
     254:      	ldr	x8, [sp, #0xb8]
     258:      	str	x29, [sp, #0x48]
     25c:      	cmp	x8, x21
     260:      	csel	x23, x8, x21, lo
     264:      	cmp	x21, #0x0
     268:      	csel	x29, x8, x23, eq
     26c:      	cmp	x29, #0xffe
     270:      	b.ls	0x5dc <generic_fexit_event+0x5dc>
     274:      	ldr	x29, [sp, #0x48]
     278:      	mov	w8, #-0x3               // =-3
     27c:      	b	0x334 <generic_fexit_event+0x334>
     280:      	mov	x8, xzr
     284:      	add	x21, x8, #0x8
     288:      	ldr	w8, [x29, #0x60]
     28c:      	cmp	w8, #0xb
     290:      	b.ne	0x178 <generic_fexit_event+0x178>
     294:      	adrp	x0, 0x0 <generic_fexit_event>
     298:      	mov	w8, #0x3                // =3
     29c:      	add	x9, sp, #0x78
     2a0:      	ldr	x0, [x0]
     2a4:      	add	x1, sp, #0x78
     2a8:      	blr	x8
     2ac:      	ldr	w8, [sp, #0x50]
     2b0:      	and	x24, x21, #0x1fff
     2b4:      	cmp	w8, #0x3
     2b8:      	b.ne	0x1c8 <generic_fexit_event+0x1c8>
     2bc:      	b	0x220 <generic_fexit_event+0x220>
     2c0:      	mov	w24, #-0x2              // =-2
     2c4:      	str	w24, [x23]
     2c8:      	add	x24, x25, x21
     2cc:      	b	0x340 <generic_fexit_event+0x340>
     2d0:      	add	x8, x0, #0x9c
     2d4:      	cmp	w23, #0x17
     2d8:      	str	x25, [sp, #0xb0]
     2dc:      	str	xzr, [sp, #0x100]
     2e0:      	str	x29, [sp, #0x48]
     2e4:      	stp	x8, x0, [sp, #0x28]
     2e8:      	b.le	0x5c4 <generic_fexit_event+0x5c4>
     2ec:      	cmp	w23, #0x18
     2f0:      	b.eq	0x674 <generic_fexit_event+0x674>
     2f4:      	cmp	w23, #0x25
     2f8:      	b.eq	0x6b8 <generic_fexit_event+0x6b8>
     2fc:      	cmp	w23, #0x2a
     300:      	b.ne	0xd0c <generic_fexit_event+0xd0c>
     304:      	add	x8, sp, #0x88
     308:      	stp	xzr, x25, [sp, #0x88]
     30c:      	b	0x6e4 <generic_fexit_event+0x6e4>
     310:      	mov	x24, x22
     314:      	str	x29, [sp, #0x48]
     318:      	mov	x29, xzr
     31c:      	add	x8, x24, x25
     320:      	stp	w29, w29, [x8]
     324:      	add	x8, x29, #0x8
     328:      	ldr	x29, [sp, #0x48]
     32c:      	b	0x33c <generic_fexit_event+0x33c>
     330:      	mov	w8, #-0x2               // =-2
     334:      	str	w8, [x22, x25]
     338:      	mov	w8, #0x4                // =4
     33c:      	add	x24, x8, x25
     340:      	mov	w8, #0x23               // =35
     344:      	blr	x8
     348:      	str	x0, [sp, #0xb0]
     34c:      	add	x8, x0, #0x8d4
     350:      	mov	w9, #0x4                // =4
     354:      	mov	w10, #0x71              // =113
     358:      	add	x11, sp, #0x88
     35c:      	add	x0, sp, #0x88
     360:      	mov	w1, #0x4                // =4
     364:      	ldr	x8, [sp, #0xb0]
     368:      	add	x2, x8, #0x8d4
     36c:      	blr	x10
     370:      	ldr	w8, [sp, #0x88]
     374:      	adrp	x22, 0x0 <generic_fexit_event>
     378:      	add	x9, sp, #0x100
     37c:      	add	x1, sp, #0x100
     380:      	str	w8, [sp, #0x100]
     384:      	mov	w8, #0x1                // =1
     388:      	ldr	x22, [x22]
     38c:      	mov	x0, x22
     390:      	blr	x8
     394:      	cbz	x0, 0x3a4 <generic_fexit_event+0x3a4>
     398:      	ldr	x8, [x0, #0x8]
     39c:      	mov	x23, x0
     3a0:      	cbnz	x8, 0x550 <generic_fexit_event+0x550>
     3a4:      	ldr	x8, [sp, #0xb0]
     3a8:      	mov	w9, #0x8                // =8
     3ac:      	mov	w10, #0x71              // =113
     3b0:      	add	x11, sp, #0xb0
     3b4:      	add	x0, sp, #0xb0
     3b8:      	mov	w1, #0x8                // =8
     3bc:      	add	x8, x8, #0x8e0
     3c0:      	ldr	x8, [sp, #0xb0]
     3c4:      	add	x2, x8, #0x8e0
     3c8:      	blr	x10
     3cc:      	ldr	x8, [sp, #0xb0]
     3d0:      	cbz	x8, 0x54c <generic_fexit_event+0x54c>
     3d4:      	add	x8, x8, #0x8d4
     3d8:      	mov	w9, #0x4                // =4
     3dc:      	mov	w10, #0x71              // =113
     3e0:      	add	x11, sp, #0x88
     3e4:      	ldr	x8, [sp, #0xb0]
     3e8:      	add	x0, sp, #0x88
     3ec:      	mov	w1, #0x4                // =4
     3f0:      	add	x2, x8, #0x8d4
     3f4:      	blr	x10
     3f8:      	ldr	w8, [sp, #0x88]
     3fc:      	add	x9, sp, #0x100
     400:      	add	x1, sp, #0x100
     404:      	mov	x0, x22
     408:      	str	w8, [sp, #0x100]
     40c:      	mov	w8, #0x1                // =1
     410:      	blr	x8
     414:      	cbz	x0, 0x424 <generic_fexit_event+0x424>
     418:      	ldr	x8, [x0, #0x8]
     41c:      	mov	x23, x0
     420:      	cbnz	x8, 0x550 <generic_fexit_event+0x550>
     424:      	ldr	x8, [sp, #0xb0]
     428:      	mov	w9, #0x8                // =8
     42c:      	mov	w10, #0x71              // =113
     430:      	add	x11, sp, #0xb0
     434:      	add	x0, sp, #0xb0
     438:      	mov	w1, #0x8                // =8
     43c:      	add	x8, x8, #0x8e0
     440:      	ldr	x8, [sp, #0xb0]
     444:      	add	x2, x8, #0x8e0
     448:      	blr	x10
     44c:      	ldr	x8, [sp, #0xb0]
     450:      	cbz	x8, 0x54c <generic_fexit_event+0x54c>
     454:      	add	x8, x8, #0x8d4
     458:      	mov	w9, #0x4                // =4
     45c:      	mov	w10, #0x71              // =113
     460:      	add	x11, sp, #0x88
     464:      	ldr	x8, [sp, #0xb0]
     468:      	add	x0, sp, #0x88
     46c:      	mov	w1, #0x4                // =4
     470:      	add	x2, x8, #0x8d4
     474:      	blr	x10
     478:      	ldr	w8, [sp, #0x88]
     47c:      	add	x9, sp, #0x100
     480:      	add	x1, sp, #0x100
     484:      	mov	x0, x22
     488:      	str	w8, [sp, #0x100]
     48c:      	mov	w8, #0x1                // =1
     490:      	blr	x8
     494:      	cbz	x0, 0x4a4 <generic_fexit_event+0x4a4>
     498:      	ldr	x8, [x0, #0x8]
     49c:      	mov	x23, x0
     4a0:      	cbnz	x8, 0x550 <generic_fexit_event+0x550>
     4a4:      	ldr	x8, [sp, #0xb0]
     4a8:      	mov	w9, #0x8                // =8
     4ac:      	mov	w10, #0x71              // =113
     4b0:      	add	x11, sp, #0xb0
     4b4:      	add	x0, sp, #0xb0
     4b8:      	mov	w1, #0x8                // =8
     4bc:      	add	x8, x8, #0x8e0
     4c0:      	ldr	x8, [sp, #0xb0]
     4c4:      	add	x2, x8, #0x8e0
     4c8:      	blr	x10
     4cc:      	ldr	x8, [sp, #0xb0]
     4d0:      	cbz	x8, 0x54c <generic_fexit_event+0x54c>
     4d4:      	add	x8, x8, #0x8d4
     4d8:      	mov	w9, #0x4                // =4
     4dc:      	mov	w10, #0x71              // =113
     4e0:      	add	x11, sp, #0x88
     4e4:      	ldr	x8, [sp, #0xb0]
     4e8:      	add	x0, sp, #0x88
     4ec:      	mov	w1, #0x4                // =4
     4f0:      	add	x2, x8, #0x8d4
     4f4:      	blr	x10
     4f8:      	ldr	w8, [sp, #0x88]
     4fc:      	add	x9, sp, #0x100
     500:      	add	x1, sp, #0x100
     504:      	mov	x0, x22
     508:      	str	w8, [sp, #0x100]
     50c:      	mov	w8, #0x1                // =1
     510:      	blr	x8
     514:      	cbz	x0, 0x524 <generic_fexit_event+0x524>
     518:      	ldr	x8, [x0, #0x8]
     51c:      	mov	x23, x0
     520:      	cbnz	x8, 0x550 <generic_fexit_event+0x550>
     524:      	ldr	x8, [sp, #0xb0]
     528:      	mov	w9, #0x8                // =8
     52c:      	mov	w10, #0x71              // =113
     530:      	add	x11, sp, #0xb0
     534:      	add	x0, sp, #0xb0
     538:      	mov	w1, #0x8                // =8
     53c:      	add	x8, x8, #0x8e0
     540:      	ldr	x8, [sp, #0xb0]
     544:      	add	x2, x8, #0x8e0
     548:      	blr	x10
     54c:      	mov	x23, xzr
     550:      	mov	w8, #0x10d              // =269
     554:      	stp	w8, w24, [x20]
     558:      	mov	w8, #0x7d               // =125
     55c:      	blr	x8
     560:      	str	x0, [x20, #0x8]
     564:      	cbz	x23, 0x578 <generic_fexit_event+0x578>
     568:      	ldr	w8, [x23]
     56c:      	str	w8, [x20, #0x10]
     570:      	ldr	x8, [x23, #0x8]
     574:      	str	x8, [x20, #0x18]
     578:      	str	wzr, [x20, #0x14]
     57c:      	adrp	x1, 0x0 <generic_fexit_event>
     580:      	mov	w9, #0xc                // =12
     584:      	mov	x0, x19
     588:      	ldr	w8, [x29]
     58c:      	str	w24, [x20, #0x4]
     590:      	mov	w2, #0x3                // =3
     594:      	str	x8, [x20, #0x60]
     598:      	mov	w8, #0x3                // =3
     59c:      	ldr	x1, [x1]
     5a0:      	blr	x9
     5a4:      	ldp	x20, x19, [sp, #0x150]
     5a8:      	mov	w0, wzr
     5ac:      	ldr	x29, [sp, #0x110]
     5b0:      	ldp	x22, x21, [sp, #0x140]
     5b4:      	ldp	x24, x23, [sp, #0x130]
     5b8:      	ldp	x30, x25, [sp, #0x120]
     5bc:      	add	sp, sp, #0x160
     5c0:      	ret
     5c4:      	cmp	w23, #0xf
     5c8:      	b.eq	0xc80 <generic_fexit_event+0xc80>
     5cc:      	cmp	w23, #0x10
     5d0:      	b.ne	0xd0c <generic_fexit_event+0xd0c>
     5d4:      	add	x21, sp, #0x118
     5d8:      	b	0x698 <generic_fexit_event+0x698>
     5dc:      	mov	x8, x22
     5e0:      	add	x22, x24, #0xc
     5e4:      	mov	w9, #0x4                // =4
     5e8:      	mov	w1, w29
     5ec:      	mov	x24, x8
     5f0:      	add	x0, x8, x22
     5f4:      	ldr	x8, [sp, #0xb0]
     5f8:      	ldr	x2, [sp, #0xb0]
     5fc:      	blr	x9
     600:      	tbnz	w0, #0x1f, 0x664 <generic_fexit_event+0x664>
     604:      	cbz	x21, 0x610 <generic_fexit_event+0x610>
     608:      	subs	x21, x21, x23
     60c:      	b.eq	0xecc <generic_fexit_event+0xecc>
     610:      	ldr	x8, [sp, #0x58]
     614:      	cmp	x8, #0x1
     618:      	b.eq	0x31c <generic_fexit_event+0x31c>
     61c:      	ldr	x8, [sp, #0x60]
     620:      	mov	w9, #0x4                // =4
     624:      	add	x10, sp, #0xb0
     628:      	add	x0, sp, #0xb0
     62c:      	mov	w1, #0x10               // =16
     630:      	add	x2, x8, #0x10
     634:      	mov	w8, #0x10               // =16
     638:      	blr	x9
     63c:      	tbnz	w0, #0x1f, 0x128c <generic_fexit_event+0x128c>
     640:      	ldr	x8, [sp, #0xb8]
     644:      	cmp	x8, x21
     648:      	csel	x23, x8, x21, lo
     64c:      	cmp	x21, #0x0
     650:      	csel	x10, x8, x23, eq
     654:      	cmp	x10, #0xffe
     658:      	b.ls	0xfa8 <generic_fexit_event+0xfa8>
     65c:      	mov	w8, #-0x3               // =-3
     660:      	b	0x1290 <generic_fexit_event+0x1290>
     664:      	ldr	x29, [sp, #0x48]
     668:      	mov	w8, #-0x2               // =-2
     66c:      	mov	x22, x24
     670:      	b	0x334 <generic_fexit_event+0x334>
     674:      	add	x21, sp, #0x118
     678:      	mov	w8, #0x8                // =8
     67c:      	mov	w9, #0x4                // =4
     680:      	ldr	x2, [sp, #0xb0]
     684:      	add	x0, sp, #0x118
     688:      	mov	w1, #0x8                // =8
     68c:      	blr	x9
     690:      	ldr	x8, [sp, #0x118]
     694:      	str	x8, [sp, #0xb0]
     698:      	mov	w8, #0x8                // =8
     69c:      	mov	w9, #0x4                // =4
     6a0:      	add	x10, sp, #0xb0
     6a4:      	add	x0, sp, #0x118
     6a8:      	add	x2, sp, #0xb0
     6ac:      	mov	w1, #0x8                // =8
     6b0:      	blr	x9
     6b4:      	b	0x6dc <generic_fexit_event+0x6dc>
     6b8:      	add	x8, x25, #0x40
     6bc:      	mov	w9, #0x8                // =8
     6c0:      	mov	w10, #0x4               // =4
     6c4:      	str	x8, [sp, #0xb0]
     6c8:      	add	x11, sp, #0x118
     6cc:      	add	x0, sp, #0x118
     6d0:      	mov	w1, #0x8                // =8
     6d4:      	ldr	x2, [sp, #0xb0]
     6d8:      	blr	x10
     6dc:      	ldr	x8, [sp, #0x118]
     6e0:      	add	x8, x8, #0x40
     6e4:      	str	x8, [sp, #0x38]
     6e8:      	str	wzr, [sp, #0x9c]
     6ec:      	adrp	x0, 0x0 <generic_fexit_event>
     6f0:      	mov	w8, #0x1                // =1
     6f4:      	add	x9, sp, #0x9c
     6f8:      	ldr	x0, [x0]
     6fc:      	add	x1, sp, #0x9c
     700:      	blr	x8
     704:      	cbz	x0, 0xda0 <generic_fexit_event+0xda0>
     708:      	add	x8, x0, #0x1, lsl #12   // =0x1000
     70c:      	str	x22, [sp, #0x18]
     710:      	mov	x23, x0
     714:      	str	x8, [sp, #0x40]
     718:      	mov	w8, #0x23               // =35
     71c:      	blr	x8
     720:      	add	x2, x0, #0xb30
     724:      	mov	w24, #0x8               // =8
     728:      	add	x8, sp, #0xa0
     72c:      	mov	w9, #0x4                // =4
     730:      	add	x0, sp, #0xa0
     734:      	mov	w1, #0x8                // =8
     738:      	mov	w25, #0x4               // =4
     73c:      	blr	x9
     740:      	ldr	x29, [sp, #0xa0]
     744:      	mov	w9, #0x4                // =4
     748:      	add	x0, sp, #0xa8
     74c:      	mov	w1, #0x8                // =8
     750:      	add	x8, x29, #0x18
     754:      	str	x8, [sp, #0x10]
     758:      	ldr	x8, [sp, #0x38]
     75c:      	add	x2, x8, #0x8
     760:      	add	x8, sp, #0xa8
     764:      	str	x2, [sp, #0x20]
     768:      	blr	x9
     76c:      	ldr	x21, [sp, #0xa8]
     770:      	add	x22, sp, #0xb0
     774:      	add	x0, sp, #0xb0
     778:      	mov	w1, #0x8                // =8
     77c:      	add	x2, x21, #0x10
     780:      	blr	x25
     784:      	ldr	x8, [sp, #0xb0]
     788:      	cbz	x8, 0x798 <generic_fexit_event+0x798>
     78c:      	ldr	x9, [sp, #0x40]
     790:      	mov	w8, #0x1000             // =4096
     794:      	b	0x7e0 <generic_fexit_event+0x7e0>
     798:      	add	x2, x21, #0x18
     79c:      	mov	w8, #0x8                // =8
     7a0:      	mov	w9, #0x4                // =4
     7a4:      	add	x10, sp, #0xb0
     7a8:      	add	x0, sp, #0xb0
     7ac:      	mov	w1, #0x8                // =8
     7b0:      	blr	x9
     7b4:      	ldr	x8, [sp, #0xb0]
     7b8:      	cmp	x8, x21
     7bc:      	b.eq	0x78c <generic_fexit_event+0x78c>
     7c0:      	mov	w8, #0x2964             // =10596
     7c4:      	add	x9, x23, #0xff6
     7c8:      	strh	w8, [x23, #0xffe]
     7cc:      	adrp	x8, 0x0 <generic_fexit_event>
     7d0:      	add	x8, x8, #0x0
     7d4:      	ldr	x8, [x8]
     7d8:      	str	x8, [x9]
     7dc:      	mov	w8, #0xff6              // =4086
     7e0:      	stp	xzr, xzr, [sp, #0xb0]
     7e4:      	add	x2, x29, #0x20
     7e8:      	mov	w21, #0x8               // =8
     7ec:      	add	x0, sp, #0xb0
     7f0:      	mov	w1, #0x8                // =8
     7f4:      	add	x25, x22, #0x8
     7f8:      	stp	x23, xzr, [sp, #0xc0]
     7fc:      	add	x24, x22, #0x18
     800:      	add	x23, x22, #0x20
     804:      	stp	xzr, xzr, [sp, #0xd0]
     808:      	mov	w29, #0x4               // =4
     80c:      	str	x9, [sp, #0x40]
     810:      	str	x9, [sp, #0xe0]
     814:      	str	w8, [sp, #0xe8]
     818:      	mov	w8, #0x4                // =4
     81c:      	strb	wzr, [sp, #0xec]
     820:      	blr	x8
     824:      	ldr	x2, [sp, #0x10]
     828:      	mov	w8, #0x4                // =4
     82c:      	mov	x0, x25
     830:      	mov	w1, #0x8                // =8
     834:      	blr	x8
     838:      	ldr	x2, [sp, #0x20]
     83c:      	mov	w8, #0x4                // =4
     840:      	mov	x0, x24
     844:      	mov	w1, #0x8                // =8
     848:      	blr	x8
     84c:      	ldr	x2, [sp, #0x38]
     850:      	mov	x0, x23
     854:      	mov	w1, #0x8                // =8
     858:      	blr	x29
     85c:      	ldr	x8, [sp, #0xd0]
     860:      	sub	x8, x8, #0x20
     864:      	str	x8, [sp, #0xd8]
     868:      	adrp	x8, 0x0 <generic_fexit_event>
     86c:      	ldr	x8, [x8]
     870:      	ldrb	w8, [x8]
     874:      	cbz	w8, 0x9f8 <generic_fexit_event+0x9f8>
     878:      	mov	w23, #0x80              // =128
     87c:      	mov	w25, #0x8               // =8
     880:      	ldp	x29, x2, [sp, #0xc8]
     884:      	ldp	x8, x9, [sp, #0xb0]
     888:      	cmp	x29, x8
     88c:      	ccmp	x2, x9, #0x0, eq
     890:      	b.eq	0xb78 <generic_fexit_event+0xb78>
     894:      	ldr	x21, [sp, #0xd8]
     898:      	mov	w8, #0x4                // =4
     89c:      	add	x9, sp, #0xf0
     8a0:      	add	x0, sp, #0xf0
     8a4:      	mov	w1, #0x8                // =8
     8a8:      	blr	x8
     8ac:      	ldr	x8, [sp, #0xf0]
     8b0:      	cmp	x29, x8
     8b4:      	b.eq	0x9a4 <generic_fexit_event+0x9a4>
     8b8:      	add	x22, x29, #0x18
     8bc:      	mov	w8, #0x4                // =4
     8c0:      	add	x9, sp, #0x118
     8c4:      	add	x0, sp, #0x118
     8c8:      	mov	w1, #0x8                // =8
     8cc:      	mov	x2, x22
     8d0:      	blr	x8
     8d4:      	ldr	x8, [sp, #0x118]
     8d8:      	cmp	x8, x29
     8dc:      	b.eq	0x9a4 <generic_fexit_event+0x9a4>
     8e0:      	mov	w8, #0x4                // =4
     8e4:      	add	x9, sp, #0xf8
     8e8:      	add	x0, sp, #0xf8
     8ec:      	mov	w1, #0x8                // =8
     8f0:      	mov	x2, x22
     8f4:      	blr	x8
     8f8:      	add	x2, x29, #0x20
     8fc:      	mov	w8, #0x4                // =4
     900:      	mov	w9, #0x10               // =16
     904:      	add	x10, sp, #0x100
     908:      	add	x0, sp, #0x100
     90c:      	mov	w1, #0x10               // =16
     910:      	blr	x8
     914:      	ldr	w21, [sp, #0x104]
     918:      	ldr	x8, [sp, #0xc0]
     91c:      	ldr	x10, [sp, #0xe0]
     920:      	sub	x12, x10, x8
     924:      	ldr	w22, [sp, #0xe8]
     928:      	subs	w10, w21, w22
     92c:      	ldr	x9, [sp, #0x108]
     930:      	csel	w10, wzr, w10, lo
     934:      	cmp	w22, w21
     938:      	csel	w11, w22, w21, lo
     93c:      	cinc	w13, w11, hi
     940:      	sub	w14, w22, w13
     944:      	subs	x12, x12, x13
     948:      	str	w14, [sp, #0xe8]
     94c:      	b.lo	0xb80 <generic_fexit_event+0xb80>
     950:      	cmp	x12, #0xfff
     954:      	b.hi	0xb80 <generic_fexit_event+0xb80>
     958:      	cmp	w22, w21
     95c:      	b.ls	0x968 <generic_fexit_event+0x968>
     960:      	mov	w13, #0x2f              // =47
     964:      	strb	w13, [x8, x12]
     968:      	add	x29, x8, x12
     96c:      	cmp	w22, w21
     970:      	add	x2, x9, x10
     974:      	and	w1, w11, #0xff
     978:      	mov	w8, #0x4                // =4
     97c:      	cinc	x0, x29, hi
     980:      	blr	x8
     984:      	cmp	w22, w21
     988:      	str	x29, [sp, #0xe0]
     98c:      	b.ls	0xb80 <generic_fexit_event+0xb80>
     990:      	ldr	x8, [sp, #0xf8]
     994:      	str	x8, [sp, #0xc8]
     998:      	subs	w23, w23, #0x1
     99c:      	b.ne	0x880 <generic_fexit_event+0x880>
     9a0:      	b	0xb80 <generic_fexit_event+0xb80>
     9a4:      	add	x2, x21, #0x10
     9a8:      	mov	w8, #0x4                // =4
     9ac:      	add	x9, sp, #0x118
     9b0:      	add	x0, sp, #0x118
     9b4:      	mov	w1, #0x8                // =8
     9b8:      	blr	x8
     9bc:      	ldr	x8, [sp, #0xd8]
     9c0:      	ldr	x9, [sp, #0x118]
     9c4:      	cmp	x8, x9
     9c8:      	b.eq	0xb78 <generic_fexit_event+0xb78>
     9cc:      	add	x2, x21, #0x18
     9d0:      	mov	w8, #0x4                // =4
     9d4:      	mov	x0, x24
     9d8:      	mov	w1, #0x8                // =8
     9dc:      	blr	x8
     9e0:      	ldr	x8, [sp, #0x118]
     9e4:      	add	x9, x8, #0x20
     9e8:      	stp	x9, x8, [sp, #0xd0]
     9ec:      	subs	w23, w23, #0x1
     9f0:      	b.ne	0x880 <generic_fexit_event+0x880>
     9f4:      	b	0xb80 <generic_fexit_event+0xb80>
     9f8:      	mov	w23, #0x80              // =128
     9fc:      	mov	w25, #0x8               // =8
     a00:      	ldp	x29, x2, [sp, #0xc8]
     a04:      	ldp	x8, x9, [sp, #0xb0]
     a08:      	cmp	x29, x8
     a0c:      	ccmp	x2, x9, #0x0, eq
     a10:      	b.eq	0xb78 <generic_fexit_event+0xb78>
     a14:      	ldr	x21, [sp, #0xd8]
     a18:      	mov	w8, #0x4                // =4
     a1c:      	add	x9, sp, #0xf0
     a20:      	add	x0, sp, #0xf0
     a24:      	mov	w1, #0x8                // =8
     a28:      	blr	x8
     a2c:      	ldr	x8, [sp, #0xf0]
     a30:      	cmp	x29, x8
     a34:      	b.eq	0xb24 <generic_fexit_event+0xb24>
     a38:      	add	x22, x29, #0x18
     a3c:      	mov	w8, #0x4                // =4
     a40:      	add	x9, sp, #0x118
     a44:      	add	x0, sp, #0x118
     a48:      	mov	w1, #0x8                // =8
     a4c:      	mov	x2, x22
     a50:      	blr	x8
     a54:      	ldr	x8, [sp, #0x118]
     a58:      	cmp	x8, x29
     a5c:      	b.eq	0xb24 <generic_fexit_event+0xb24>
     a60:      	mov	w8, #0x4                // =4
     a64:      	add	x9, sp, #0xf8
     a68:      	add	x0, sp, #0xf8
     a6c:      	mov	w1, #0x8                // =8
     a70:      	mov	x2, x22
     a74:      	blr	x8
     a78:      	add	x2, x29, #0x20
     a7c:      	mov	w8, #0x4                // =4
     a80:      	mov	w9, #0x10               // =16
     a84:      	add	x10, sp, #0x100
     a88:      	add	x0, sp, #0x100
     a8c:      	mov	w1, #0x10               // =16
     a90:      	blr	x8
     a94:      	ldr	w21, [sp, #0x104]
     a98:      	ldr	x8, [sp, #0xc0]
     a9c:      	ldr	x10, [sp, #0xe0]
     aa0:      	sub	x12, x10, x8
     aa4:      	ldr	w22, [sp, #0xe8]
     aa8:      	subs	w10, w21, w22
     aac:      	ldr	x9, [sp, #0x108]
     ab0:      	csel	w10, wzr, w10, lo
     ab4:      	cmp	w22, w21
     ab8:      	csel	w11, w22, w21, lo
     abc:      	cinc	w13, w11, hi
     ac0:      	sub	w14, w22, w13
     ac4:      	subs	x12, x12, x13
     ac8:      	str	w14, [sp, #0xe8]
     acc:      	b.lo	0xb80 <generic_fexit_event+0xb80>
     ad0:      	cmp	x12, #0xfff
     ad4:      	b.hi	0xb80 <generic_fexit_event+0xb80>
     ad8:      	cmp	w22, w21
     adc:      	b.ls	0xae8 <generic_fexit_event+0xae8>
     ae0:      	mov	w13, #0x2f              // =47
     ae4:      	strb	w13, [x8, x12]
     ae8:      	add	x29, x8, x12
     aec:      	cmp	w22, w21
     af0:      	add	x2, x9, x10
     af4:      	and	w1, w11, #0xff
     af8:      	mov	w8, #0x4                // =4
     afc:      	cinc	x0, x29, hi
     b00:      	blr	x8
     b04:      	cmp	w22, w21
     b08:      	str	x29, [sp, #0xe0]
     b0c:      	b.ls	0xb80 <generic_fexit_event+0xb80>
     b10:      	ldr	x8, [sp, #0xf8]
     b14:      	str	x8, [sp, #0xc8]
     b18:      	subs	w23, w23, #0x1
     b1c:      	b.ne	0xa00 <generic_fexit_event+0xa00>
     b20:      	b	0xb80 <generic_fexit_event+0xb80>
     b24:      	add	x2, x21, #0x10
     b28:      	mov	w8, #0x4                // =4
     b2c:      	add	x9, sp, #0x118
     b30:      	add	x0, sp, #0x118
     b34:      	mov	w1, #0x8                // =8
     b38:      	blr	x8
     b3c:      	ldr	x8, [sp, #0xd8]
     b40:      	ldr	x9, [sp, #0x118]
     b44:      	cmp	x8, x9
     b48:      	b.eq	0xb78 <generic_fexit_event+0xb78>
     b4c:      	add	x2, x21, #0x18
     b50:      	mov	w8, #0x4                // =4
     b54:      	mov	x0, x24
     b58:      	mov	w1, #0x8                // =8
     b5c:      	blr	x8
     b60:      	ldr	x8, [sp, #0x118]
     b64:      	add	x9, x8, #0x20
     b68:      	stp	x9, x8, [sp, #0xd0]
     b6c:      	subs	w23, w23, #0x1
     b70:      	b.ne	0xa00 <generic_fexit_event+0xa00>
     b74:      	b	0xb80 <generic_fexit_event+0xb80>
     b78:      	mov	w8, #0x1                // =1
     b7c:      	strb	w8, [sp, #0xec]
     b80:      	ldr	x8, [sp, #0xe0]
     b84:      	ldr	x2, [sp, #0x40]
     b88:      	cmp	x8, x2
     b8c:      	b.eq	0xbc0 <generic_fexit_event+0xbc0>
     b90:      	ldrb	w9, [sp, #0xec]
     b94:      	mov	w11, #0x1000            // =4096
     b98:      	cmp	w9, #0x0
     b9c:      	ldr	w9, [sp, #0xe8]
     ba0:      	cset	w10, eq
     ba4:      	sub	w11, w11, w9
     ba8:      	cmp	w9, #0x0
     bac:      	csel	w9, w11, w9, gt
     bb0:      	cbz	x8, 0xd9c <generic_fexit_event+0xd9c>
     bb4:      	lsl	w23, w10, #1
     bb8:      	mov	x2, x8
     bbc:      	b	0xbc8 <generic_fexit_event+0xbc8>
     bc0:      	mov	w23, wzr
     bc4:      	mov	w9, wzr
     bc8:      	ldr	x21, [sp, #0x30]
     bcc:      	and	w22, w9, #0xfff
     bd0:      	mov	w8, #0x4                // =4
     bd4:      	mov	w24, #0x4               // =4
     bd8:      	mov	w1, w22
     bdc:      	add	x0, x21, #0xa0
     be0:      	blr	x8
     be4:      	str	w22, [x21, #0x9c]
     be8:      	ldr	x2, [sp, #0x20]
     bec:      	mov	w21, #0x8               // =8
     bf0:      	add	x8, sp, #0xb0
     bf4:      	mov	w9, #0x4                // =4
     bf8:      	add	x0, sp, #0xb0
     bfc:      	mov	w1, #0x8                // =8
     c00:      	blr	x9
     c04:      	ldr	x8, [sp, #0xb0]
     c08:      	add	x9, sp, #0x100
     c0c:      	mov	w10, #0x4               // =4
     c10:      	add	x0, sp, #0x100
     c14:      	mov	w1, #0x8                // =8
     c18:      	add	x8, x8, #0x30
     c1c:      	ldr	x8, [sp, #0xb0]
     c20:      	add	x2, x8, #0x30
     c24:      	blr	x10
     c28:      	ldr	x8, [sp, #0x100]
     c2c:      	mov	w9, #0x2                // =2
     c30:      	add	x10, sp, #0x118
     c34:      	add	x0, sp, #0x118
     c38:      	ldr	x2, [sp, #0x100]
     c3c:      	mov	w1, #0x2                // =2
     c40:      	blr	x24
     c44:      	ldr	x8, [sp, #0x28]
     c48:      	add	w29, w22, #0xa
     c4c:      	add	x8, x8, x22
     c50:      	str	w23, [x8, #0x4]
     c54:      	ldrh	w9, [sp, #0x118]
     c58:      	strh	w9, [x8, #0x8]
     c5c:      	ldr	x22, [sp, #0x18]
     c60:      	mov	w21, #0x5ea0            // =24224
     c64:      	tbz	w29, #0x1f, 0xda4 <generic_fexit_event+0xda4>
     c68:      	ldr	x9, [sp, #0x30]
     c6c:      	mov	w8, #-0x1               // =-1
     c70:      	str	w8, [x9, x21]
     c74:      	str	w8, [x9, #0x98]
     c78:      	mov	w8, #0x4                // =4
     c7c:      	b	0xdac <generic_fexit_event+0xdac>
     c80:      	mov	w8, #0x8                // =8
     c84:      	mov	w9, #0x4                // =4
     c88:      	add	x10, sp, #0x100
     c8c:      	add	x11, sp, #0xb0
     c90:      	add	x0, sp, #0x100
     c94:      	add	x2, sp, #0xb0
     c98:      	mov	w1, #0x8                // =8
     c9c:      	blr	x9
     ca0:      	ldr	x8, [sp, #0x100]
     ca4:      	str	x8, [sp, #0x38]
     ca8:      	cbnz	x8, 0x6e8 <generic_fexit_event+0x6e8>
     cac:      	str	wzr, [sp, #0x88]
     cb0:      	mov	w8, #0x1                // =1
     cb4:      	add	x9, sp, #0x88
     cb8:      	add	x1, sp, #0x88
     cbc:      	mov	x0, x24
     cc0:      	blr	x8
     cc4:      	mov	x29, xzr
     cc8:      	cbz	x0, 0xc64 <generic_fexit_event+0xc64>
     ccc:      	cmp	w23, #0x19
     cd0:      	b.gt	0xf80 <generic_fexit_event+0xf80>
     cd4:      	cmp	w23, #0x12
     cd8:      	b.le	0x1358 <generic_fexit_event+0x1358>
     cdc:      	cmp	w23, #0x14
     ce0:      	b.le	0x1590 <generic_fexit_event+0x1590>
     ce4:      	cmp	w23, #0x15
     ce8:      	b.eq	0x1c2c <generic_fexit_event+0x1c2c>
     cec:      	cmp	w23, #0x16
     cf0:      	b.eq	0x1bcc <generic_fexit_event+0x1bcc>
     cf4:      	cmp	w23, #0x17
     cf8:      	b.ne	0xc64 <generic_fexit_event+0xc64>
     cfc:      	ldr	x8, [sp, #0x30]
     d00:      	mov	w29, #0x8               // =8
     d04:      	stp	w25, wzr, [x8, #0x9c]
     d08:      	b	0xc64 <generic_fexit_event+0xc64>
     d0c:      	cmp	w23, #0x2c
     d10:      	b.hi	0xcac <generic_fexit_event+0xcac>
     d14:      	mov	x9, #0x7cf2             // =31986
     d18:      	mov	w8, #0x1                // =1
     d1c:      	movk	x9, #0xf202, lsl #16
     d20:      	lsl	x8, x8, x23
     d24:      	movk	x9, #0x11c1, lsl #32
     d28:      	tst	x8, x9
     d2c:      	b.eq	0xcac <generic_fexit_event+0xcac>
     d30:      	str	x25, [sp, #0x118]
     d34:      	str	wzr, [sp, #0xf8]
     d38:      	mov	w8, #0x1                // =1
     d3c:      	add	x9, sp, #0xf8
     d40:      	add	x1, sp, #0xf8
     d44:      	mov	x0, x24
     d48:      	blr	x8
     d4c:      	mov	x29, xzr
     d50:      	cbz	x0, 0xc64 <generic_fexit_event+0xc64>
     d54:      	cmp	w23, #0x10
     d58:      	b.le	0xdc4 <generic_fexit_event+0xdc4>
     d5c:      	cmp	w23, #0x1e
     d60:      	b.le	0xed4 <generic_fexit_event+0xed4>
     d64:      	cmp	w23, #0x26
     d68:      	b.gt	0x129c <generic_fexit_event+0x129c>
     d6c:      	ldr	x0, [sp, #0x28]
     d70:      	sub	w8, w23, #0x1f
     d74:      	cmp	w8, #0x2
     d78:      	b.hs	0x1634 <generic_fexit_event+0x1634>
     d7c:      	mov	w8, #0x1                // =1
     d80:      	add	x9, sp, #0x118
     d84:      	mov	w10, #0x4               // =4
     d88:      	add	x2, sp, #0x118
     d8c:      	mov	w1, #0x1                // =1
     d90:      	mov	w29, #0x4               // =4
     d94:      	blr	x10
     d98:      	b	0xc64 <generic_fexit_event+0xc64>
     d9c:      	ldr	x22, [sp, #0x18]
     da0:      	mov	x29, xzr
     da4:      	and	x8, x29, #0x7fffffff
     da8:      	add	x8, x8, #0x4
     dac:      	ldr	x29, [sp, #0x48]
     db0:      	add	x21, x8, #0x8
     db4:      	ldr	w8, [x29, #0x60]
     db8:      	cmp	w8, #0xb
     dbc:      	b.ne	0x178 <generic_fexit_event+0x178>
     dc0:      	b	0x294 <generic_fexit_event+0x294>
     dc4:      	cmp	w23, #0x9
     dc8:      	b.gt	0xefc <generic_fexit_event+0xefc>
     dcc:      	cmp	w23, #0x4
     dd0:      	b.le	0x13a0 <generic_fexit_event+0x13a0>
     dd4:      	cmp	w23, #0x5
     dd8:      	b.eq	0x17d8 <generic_fexit_event+0x17d8>
     ddc:      	cmp	w23, #0x6
     de0:      	b.eq	0xf64 <generic_fexit_event+0xf64>
     de4:      	cmp	w23, #0x7
     de8:      	b.ne	0xc64 <generic_fexit_event+0xc64>
     dec:      	str	x22, [sp, #0x18]
     df0:      	ldr	x22, [sp, #0x118]
     df4:      	mov	x24, x0
     df8:      	mov	w21, #0x2               // =2
     dfc:      	mov	w8, #0x4                // =4
     e00:      	mov	w1, #0x2                // =2
     e04:      	ldr	x25, [sp, #0x30]
     e08:      	mov	w23, #0x4               // =4
     e0c:      	stur	x22, [x25, #0xc4]
     e10:      	add	x0, x25, #0xc2
     e14:      	add	x2, x22, #0x10
     e18:      	blr	x8
     e1c:      	add	x0, x25, #0xd6
     e20:      	add	x2, x22, #0x12
     e24:      	mov	w8, #0x1                // =1
     e28:      	mov	w9, #0x4                // =4
     e2c:      	mov	w1, #0x1                // =1
     e30:      	blr	x9
     e34:      	add	x0, x25, #0xd4
     e38:      	add	x2, x22, #0x21e
     e3c:      	mov	w8, #0x4                // =4
     e40:      	mov	w1, #0x2                // =2
     e44:      	blr	x8
     e48:      	add	x0, x25, #0xc0
     e4c:      	add	x2, x22, #0x21c
     e50:      	mov	w8, #0x4                // =4
     e54:      	mov	w1, #0x2                // =2
     e58:      	blr	x8
     e5c:      	add	x0, x25, #0xcc
     e60:      	add	x2, x22, #0x214
     e64:      	mov	w8, #0x4                // =4
     e68:      	mov	w1, #0x4                // =4
     e6c:      	blr	x8
     e70:      	add	x0, x25, #0xd0
     e74:      	add	x2, x22, #0x210
     e78:      	mov	w1, #0x4                // =4
     e7c:      	blr	x23
     e80:      	ldrh	w8, [x25, #0xc2]
     e84:      	ldr	x0, [sp, #0x28]
     e88:      	add	x23, x25, #0xac
     e8c:      	cmp	w8, #0xa
     e90:      	stp	xzr, xzr, [x0]
     e94:      	stp	xzr, xzr, [x0, #0x10]
     e98:      	b.eq	0x1ef8 <generic_fexit_event+0x1ef8>
     e9c:      	cmp	w8, #0x2
     ea0:      	b.ne	0x1f20 <generic_fexit_event+0x1f20>
     ea4:      	add	x2, x22, #0x4
     ea8:      	mov	w8, #0x4                // =4
     eac:      	mov	w1, #0x4                // =4
     eb0:      	mov	w21, #0x4               // =4
     eb4:      	blr	x8
     eb8:      	mov	x0, x23
     ebc:      	mov	w1, #0x4                // =4
     ec0:      	mov	x2, x22
     ec4:      	blr	x21
     ec8:      	b	0x1f20 <generic_fexit_event+0x1f20>
     ecc:      	mov	x29, x23
     ed0:      	b	0x31c <generic_fexit_event+0x31c>
     ed4:      	cmp	w23, #0x1c
     ed8:      	b.gt	0x137c <generic_fexit_event+0x137c>
     edc:      	cmp	w23, #0x11
     ee0:      	b.eq	0x1660 <generic_fexit_event+0x1660>
     ee4:      	cmp	w23, #0x19
     ee8:      	b.eq	0x171c <generic_fexit_event+0x171c>
     eec:      	ldr	x0, [sp, #0x28]
     ef0:      	cmp	w23, #0x1c
     ef4:      	b.eq	0x13b4 <generic_fexit_event+0x13b4>
     ef8:      	b	0xc64 <generic_fexit_event+0xc64>
     efc:      	ldr	x0, [sp, #0x28]
     f00:      	sub	w8, w23, #0xa
     f04:      	cmp	w8, #0x2
     f08:      	b.lo	0x13b4 <generic_fexit_event+0x13b4>
     f0c:      	sub	w8, w23, #0xc
     f10:      	cmp	w8, #0x2
     f14:      	b.lo	0x13cc <generic_fexit_event+0x13cc>
     f18:      	cmp	w23, #0xe
     f1c:      	b.ne	0xc64 <generic_fexit_event+0xc64>
     f20:      	mov	w21, #0x8               // =8
     f24:      	add	x8, sp, #0xb0
     f28:      	add	x23, sp, #0x118
     f2c:      	mov	w9, #0x4                // =4
     f30:      	add	x0, sp, #0xb0
     f34:      	add	x2, sp, #0x118
     f38:      	mov	w1, #0x8                // =8
     f3c:      	mov	x24, x22
     f40:      	mov	w22, #0x4               // =4
     f44:      	blr	x9
     f48:      	ldr	x8, [sp, #0xb0]
     f4c:      	add	x0, sp, #0x118
     f50:      	mov	w1, #0x8                // =8
     f54:      	mov	w21, #0x5ea0            // =24224
     f58:      	ldr	x2, [sp, #0xb0]
     f5c:      	blr	x22
     f60:      	mov	x22, x24
     f64:      	ldr	x8, [sp, #0x30]
     f68:      	ldr	x2, [sp, #0x118]
     f6c:      	mov	w9, #0x2d               // =45
     f70:      	mov	w1, #0x1001             // =4097
     f74:      	add	x0, x8, #0xa0
     f78:      	mov	w8, #0x1001             // =4097
     f7c:      	b	0x1948 <generic_fexit_event+0x1948>
     f80:      	cmp	w23, #0x20
     f84:      	b.le	0x14fc <generic_fexit_event+0x14fc>
     f88:      	sub	w8, w23, #0x21
     f8c:      	cmp	w8, #0x4
     f90:      	b.hs	0x13e8 <generic_fexit_event+0x13e8>
     f94:      	ldr	x0, [sp, #0x28]
     f98:      	mov	w29, #0x8               // =8
     f9c:      	mov	w8, #0x4                // =4
     fa0:      	mov	w1, #0x8                // =8
     fa4:      	b	0x1584 <generic_fexit_event+0x1584>
     fa8:      	add	x8, x29, x22
     fac:      	mov	w9, #0x4                // =4
     fb0:      	mov	x22, x10
     fb4:      	str	x8, [sp, #0x50]
     fb8:      	add	x0, x24, x8
     fbc:      	ldr	x8, [sp, #0xb0]
     fc0:      	mov	w1, w22
     fc4:      	ldr	x2, [sp, #0xb0]
     fc8:      	blr	x9
     fcc:      	tbnz	w0, #0x1f, 0x128c <generic_fexit_event+0x128c>
     fd0:      	add	x29, x22, x29
     fd4:      	cbz	x21, 0xfe0 <generic_fexit_event+0xfe0>
     fd8:      	subs	x21, x21, x23
     fdc:      	b.eq	0x31c <generic_fexit_event+0x31c>
     fe0:      	ldr	x8, [sp, #0x58]
     fe4:      	cmp	x8, #0x3
     fe8:      	b.lo	0x31c <generic_fexit_event+0x31c>
     fec:      	ldr	x8, [sp, #0x60]
     ff0:      	mov	w9, #0x4                // =4
     ff4:      	add	x10, sp, #0xb0
     ff8:      	add	x0, sp, #0xb0
     ffc:      	mov	w1, #0x10               // =16
    1000:      	add	x2, x8, #0x20
    1004:      	mov	w8, #0x10               // =16
    1008:      	blr	x9
    100c:      	tbnz	w0, #0x1f, 0x128c <generic_fexit_event+0x128c>
    1010:      	ldr	x8, [sp, #0xb8]
    1014:      	cmp	x8, x21
    1018:      	csel	x23, x8, x21, lo
    101c:      	cmp	x21, #0x0
    1020:      	csel	x8, x8, x23, eq
    1024:      	cmp	x8, #0xffe
    1028:      	str	x8, [sp, #0x40]
    102c:      	b.hi	0x65c <generic_fexit_event+0x65c>
    1030:      	ldr	x8, [sp, #0x50]
    1034:      	mov	w9, #0x4                // =4
    1038:      	ldr	x1, [sp, #0x40]
    103c:      	add	x22, x22, x8
    1040:      	and	x8, x22, #0x3fff
    1044:      	add	x0, x24, x8
    1048:      	ldr	x8, [sp, #0xb0]
    104c:      	ldr	x2, [sp, #0xb0]
    1050:      	blr	x9
    1054:      	tbnz	w0, #0x1f, 0x128c <generic_fexit_event+0x128c>
    1058:      	ldr	x8, [sp, #0x40]
    105c:      	add	x29, x8, x29
    1060:      	cbz	x21, 0x106c <generic_fexit_event+0x106c>
    1064:      	subs	x21, x21, x23
    1068:      	b.eq	0x31c <generic_fexit_event+0x31c>
    106c:      	ldr	x8, [sp, #0x58]
    1070:      	cmp	x8, #0x3
    1074:      	b.eq	0x31c <generic_fexit_event+0x31c>
    1078:      	ldr	x8, [sp, #0x60]
    107c:      	mov	w9, #0x4                // =4
    1080:      	add	x10, sp, #0xb0
    1084:      	add	x0, sp, #0xb0
    1088:      	mov	w1, #0x10               // =16
    108c:      	add	x2, x8, #0x30
    1090:      	mov	w8, #0x10               // =16
    1094:      	blr	x9
    1098:      	tbnz	w0, #0x1f, 0x128c <generic_fexit_event+0x128c>
    109c:      	ldr	x8, [sp, #0xb8]
    10a0:      	cmp	x8, x21
    10a4:      	csel	x23, x8, x21, lo
    10a8:      	cmp	x21, #0x0
    10ac:      	csel	x8, x8, x23, eq
    10b0:      	cmp	x8, #0xffe
    10b4:      	str	x8, [sp, #0x50]
    10b8:      	b.hi	0x65c <generic_fexit_event+0x65c>
    10bc:      	ldr	x8, [sp, #0x40]
    10c0:      	mov	w9, #0x4                // =4
    10c4:      	ldr	x1, [sp, #0x50]
    10c8:      	add	x22, x8, x22
    10cc:      	and	x8, x22, #0x3fff
    10d0:      	add	x0, x24, x8
    10d4:      	ldr	x8, [sp, #0xb0]
    10d8:      	ldr	x2, [sp, #0xb0]
    10dc:      	blr	x9
    10e0:      	tbnz	w0, #0x1f, 0x128c <generic_fexit_event+0x128c>
    10e4:      	ldr	x8, [sp, #0x50]
    10e8:      	add	x29, x8, x29
    10ec:      	cbz	x21, 0x10f8 <generic_fexit_event+0x10f8>
    10f0:      	subs	x21, x21, x23
    10f4:      	b.eq	0x31c <generic_fexit_event+0x31c>
    10f8:      	ldr	x8, [sp, #0x58]
    10fc:      	cmp	x8, #0x5
    1100:      	b.lo	0x31c <generic_fexit_event+0x31c>
    1104:      	ldr	x8, [sp, #0x60]
    1108:      	mov	w9, #0x4                // =4
    110c:      	add	x10, sp, #0xb0
    1110:      	add	x0, sp, #0xb0
    1114:      	mov	w1, #0x10               // =16
    1118:      	add	x2, x8, #0x40
    111c:      	mov	w8, #0x10               // =16
    1120:      	blr	x9
    1124:      	tbnz	w0, #0x1f, 0x128c <generic_fexit_event+0x128c>
    1128:      	ldr	x8, [sp, #0xb8]
    112c:      	cmp	x8, x21
    1130:      	csel	x23, x8, x21, lo
    1134:      	cmp	x21, #0x0
    1138:      	csel	x8, x8, x23, eq
    113c:      	cmp	x8, #0xffe
    1140:      	str	x8, [sp, #0x40]
    1144:      	b.hi	0x65c <generic_fexit_event+0x65c>
    1148:      	ldr	x8, [sp, #0x50]
    114c:      	mov	w9, #0x4                // =4
    1150:      	ldr	x1, [sp, #0x40]
    1154:      	add	x22, x8, x22
    1158:      	and	x8, x22, #0x3fff
    115c:      	add	x0, x24, x8
    1160:      	ldr	x8, [sp, #0xb0]
    1164:      	ldr	x2, [sp, #0xb0]
    1168:      	blr	x9
    116c:      	tbnz	w0, #0x1f, 0x128c <generic_fexit_event+0x128c>
    1170:      	ldr	x8, [sp, #0x40]
    1174:      	add	x29, x8, x29
    1178:      	cbz	x21, 0x1184 <generic_fexit_event+0x1184>
    117c:      	subs	x21, x21, x23
    1180:      	b.eq	0x31c <generic_fexit_event+0x31c>
    1184:      	ldr	x8, [sp, #0x58]
    1188:      	cmp	x8, #0x5
    118c:      	b.eq	0x31c <generic_fexit_event+0x31c>
    1190:      	ldr	x8, [sp, #0x60]
    1194:      	mov	w9, #0x4                // =4
    1198:      	add	x10, sp, #0xb0
    119c:      	add	x0, sp, #0xb0
    11a0:      	mov	w1, #0x10               // =16
    11a4:      	add	x2, x8, #0x50
    11a8:      	mov	w8, #0x10               // =16
    11ac:      	blr	x9
    11b0:      	tbnz	w0, #0x1f, 0x128c <generic_fexit_event+0x128c>
    11b4:      	ldr	x8, [sp, #0xb8]
    11b8:      	cmp	x8, x21
    11bc:      	csel	x23, x8, x21, lo
    11c0:      	cmp	x21, #0x0
    11c4:      	csel	x8, x8, x23, eq
    11c8:      	cmp	x8, #0xffe
    11cc:      	str	x8, [sp, #0x50]
    11d0:      	b.hi	0x65c <generic_fexit_event+0x65c>
    11d4:      	ldr	x8, [sp, #0x40]
    11d8:      	mov	w9, #0x4                // =4
    11dc:      	ldr	x1, [sp, #0x50]
    11e0:      	add	x22, x8, x22
    11e4:      	and	x8, x22, #0x3fff
    11e8:      	add	x0, x24, x8
    11ec:      	ldr	x8, [sp, #0xb0]
    11f0:      	ldr	x2, [sp, #0xb0]
    11f4:      	blr	x9
    11f8:      	tbnz	w0, #0x1f, 0x128c <generic_fexit_event+0x128c>
    11fc:      	ldr	x8, [sp, #0x50]
    1200:      	add	x29, x8, x29
    1204:      	cbz	x21, 0x1210 <generic_fexit_event+0x1210>
    1208:      	subs	x21, x21, x23
    120c:      	b.eq	0x31c <generic_fexit_event+0x31c>
    1210:      	ldr	x8, [sp, #0x58]
    1214:      	cmp	x8, #0x7
    1218:      	b.lo	0x31c <generic_fexit_event+0x31c>
    121c:      	ldr	x8, [sp, #0x60]
    1220:      	mov	w9, #0x4                // =4
    1224:      	add	x10, sp, #0xb0
    1228:      	add	x0, sp, #0xb0
    122c:      	mov	w1, #0x10               // =16
    1230:      	add	x2, x8, #0x60
    1234:      	mov	w8, #0x10               // =16
    1238:      	blr	x9
    123c:      	tbnz	w0, #0x1f, 0x128c <generic_fexit_event+0x128c>
    1240:      	ldr	x8, [sp, #0xb8]
    1244:      	cmp	x8, x21
    1248:      	csel	x9, x8, x21, lo
    124c:      	cmp	x21, #0x0
    1250:      	csel	x21, x8, x9, eq
    1254:      	cmp	x21, #0xffe
    1258:      	b.hi	0x65c <generic_fexit_event+0x65c>
    125c:      	ldr	x8, [sp, #0x50]
    1260:      	mov	w9, #0x4                // =4
    1264:      	mov	w1, w21
    1268:      	add	x8, x8, x22
    126c:      	and	x8, x8, #0x3fff
    1270:      	add	x0, x24, x8
    1274:      	ldr	x8, [sp, #0xb0]
    1278:      	ldr	x2, [sp, #0xb0]
    127c:      	blr	x9
    1280:      	tbnz	w0, #0x1f, 0x128c <generic_fexit_event+0x128c>
    1284:      	add	x29, x21, x29
    1288:      	b	0x31c <generic_fexit_event+0x31c>
    128c:      	mov	w8, #-0x2               // =-2
    1290:      	str	w8, [x24, x25]
    1294:      	mov	w8, #0x4                // =4
    1298:      	b	0x328 <generic_fexit_event+0x328>
    129c:      	ldr	x0, [sp, #0x28]
    12a0:      	cmp	w23, #0x27
    12a4:      	b.eq	0x192c <generic_fexit_event+0x192c>
    12a8:      	cmp	w23, #0x28
    12ac:      	b.eq	0x1968 <generic_fexit_event+0x1968>
    12b0:      	cmp	w23, #0x2c
    12b4:      	b.ne	0xc64 <generic_fexit_event+0xc64>
    12b8:      	mov	x24, x22
    12bc:      	ldr	x22, [sp, #0x118]
    12c0:      	strb	wzr, [sp, #0xb0]
    12c4:      	mov	w8, #0x2                // =2
    12c8:      	mov	w9, #0x4                // =4
    12cc:      	mov	w1, #0x2                // =2
    12d0:      	mov	x2, x22
    12d4:      	stp	xzr, xzr, [x0]
    12d8:      	stp	xzr, xzr, [x0, #0x10]
    12dc:      	stp	xzr, xzr, [x0, #0x20]
    12e0:      	stp	xzr, xzr, [x0, #0x30]
    12e4:      	stp	xzr, xzr, [x0, #0x40]
    12e8:      	stp	xzr, xzr, [x0, #0x50]
    12ec:      	stp	xzr, xzr, [x0, #0x60]
    12f0:      	blr	x9
    12f4:      	tbnz	x0, #0x3f, 0x2044 <generic_fexit_event+0x2044>
    12f8:      	add	x23, x22, #0x2
    12fc:      	mov	w8, #0x1                // =1
    1300:      	mov	w9, #0x4                // =4
    1304:      	add	x10, sp, #0xb0
    1308:      	add	x0, sp, #0xb0
    130c:      	mov	w1, #0x1                // =1
    1310:      	mov	x2, x23
    1314:      	blr	x9
    1318:      	tbnz	x0, #0x3f, 0x2044 <generic_fexit_event+0x2044>
    131c:      	ldrb	w8, [sp, #0xb0]
    1320:      	ldr	x10, [sp, #0x30]
    1324:      	cmp	w8, #0x0
    1328:      	add	x0, x10, #0xa0
    132c:      	cset	w9, eq
    1330:      	strb	w9, [x10, #0x9e]
    1334:      	cbz	w8, 0x2024 <generic_fexit_event+0x2024>
    1338:      	mov	w8, #0x6c               // =108
    133c:      	mov	w9, #0x2d               // =45
    1340:      	mov	w1, #0x6c               // =108
    1344:      	mov	x2, x23
    1348:      	blr	x9
    134c:      	tbnz	w0, #0x1f, 0x2044 <generic_fexit_event+0x2044>
    1350:      	sub	w21, w0, #0x1
    1354:      	b	0x203c <generic_fexit_event+0x203c>
    1358:      	cmp	w23, #0x7
    135c:      	b.gt	0x1564 <generic_fexit_event+0x1564>
    1360:      	cmp	w23, #0x2
    1364:      	b.eq	0x19e0 <generic_fexit_event+0x19e0>
    1368:      	cmp	w23, #0x3
    136c:      	b.ne	0xc64 <generic_fexit_event+0xc64>
    1370:      	stur	xzr, [x0, #0x9c]
    1374:      	mov	w29, #0x8               // =8
    1378:      	b	0xc64 <generic_fexit_event+0xc64>
    137c:      	ldr	x0, [sp, #0x28]
    1380:      	mov	w8, #0x2                // =2
    1384:      	add	x9, sp, #0x118
    1388:      	mov	w10, #0x4               // =4
    138c:      	add	x2, sp, #0x118
    1390:      	mov	w1, #0x2                // =2
    1394:      	mov	w29, #0x4               // =4
    1398:      	blr	x10
    139c:      	b	0xc64 <generic_fexit_event+0xc64>
    13a0:      	ldr	x0, [sp, #0x28]
    13a4:      	cmp	w23, #0x1
    13a8:      	b.eq	0x13cc <generic_fexit_event+0x13cc>
    13ac:      	cmp	w23, #0x4
    13b0:      	b.ne	0xc64 <generic_fexit_event+0xc64>
    13b4:      	mov	w29, #0x8               // =8
    13b8:      	mov	w8, #0x4                // =4
    13bc:      	add	x9, sp, #0x118
    13c0:      	add	x2, sp, #0x118
    13c4:      	mov	w1, #0x8                // =8
    13c8:      	b	0x1588 <generic_fexit_event+0x1588>
    13cc:      	add	x8, sp, #0x118
    13d0:      	mov	w9, #0x4                // =4
    13d4:      	add	x2, sp, #0x118
    13d8:      	mov	w1, #0x4                // =4
    13dc:      	mov	w29, #0x4               // =4
    13e0:      	blr	x9
    13e4:      	b	0xc64 <generic_fexit_event+0xc64>
    13e8:      	cmp	w23, #0x2b
    13ec:      	b.eq	0x1cec <generic_fexit_event+0x1cec>
    13f0:      	cmp	w23, #0x29
    13f4:      	b.ne	0xc64 <generic_fexit_event+0xc64>
    13f8:      	str	x22, [sp, #0x18]
    13fc:      	add	x2, x25, #0x18
    1400:      	mov	w8, #0x8                // =8
    1404:      	mov	w9, #0x4                // =4
    1408:      	add	x10, sp, #0xb0
    140c:      	mov	x24, x0
    1410:      	add	x0, sp, #0xb0
    1414:      	mov	w1, #0x8                // =8
    1418:      	blr	x9
    141c:      	ldr	x22, [sp, #0xb0]
    1420:      	cbz	x22, 0x20c0 <generic_fexit_event+0x20c0>
    1424:      	ldr	x25, [sp, #0x30]
    1428:      	add	x2, x22, #0x10
    142c:      	mov	w21, #0x2               // =2
    1430:      	mov	w8, #0x4                // =4
    1434:      	stur	x22, [x25, #0xc4]
    1438:      	add	x0, x25, #0xc2
    143c:      	mov	w1, #0x2                // =2
    1440:      	mov	w23, #0x4               // =4
    1444:      	blr	x8
    1448:      	add	x0, x25, #0xd6
    144c:      	add	x2, x22, #0x12
    1450:      	mov	w8, #0x1                // =1
    1454:      	mov	w9, #0x4                // =4
    1458:      	mov	w1, #0x1                // =1
    145c:      	blr	x9
    1460:      	add	x0, x25, #0xd4
    1464:      	add	x2, x22, #0x21e
    1468:      	mov	w8, #0x4                // =4
    146c:      	mov	w1, #0x2                // =2
    1470:      	blr	x8
    1474:      	add	x0, x25, #0xc0
    1478:      	add	x2, x22, #0x21c
    147c:      	mov	w8, #0x4                // =4
    1480:      	mov	w1, #0x2                // =2
    1484:      	blr	x8
    1488:      	add	x0, x25, #0xcc
    148c:      	add	x2, x22, #0x214
    1490:      	mov	w8, #0x4                // =4
    1494:      	mov	w1, #0x4                // =4
    1498:      	blr	x8
    149c:      	add	x0, x25, #0xd0
    14a0:      	add	x2, x22, #0x210
    14a4:      	mov	w1, #0x4                // =4
    14a8:      	blr	x23
    14ac:      	ldr	x8, [sp, #0x28]
    14b0:      	add	x23, x25, #0xac
    14b4:      	stp	xzr, xzr, [x8]
    14b8:      	stp	xzr, xzr, [x8, #0x10]
    14bc:      	ldrh	w8, [x25, #0xc2]
    14c0:      	cmp	w8, #0xa
    14c4:      	b.eq	0x2050 <generic_fexit_event+0x2050>
    14c8:      	cmp	w8, #0x2
    14cc:      	b.ne	0x207c <generic_fexit_event+0x207c>
    14d0:      	ldr	x0, [sp, #0x28]
    14d4:      	add	x2, x22, #0x4
    14d8:      	mov	w8, #0x4                // =4
    14dc:      	mov	w1, #0x4                // =4
    14e0:      	mov	w21, #0x4               // =4
    14e4:      	blr	x8
    14e8:      	mov	x0, x23
    14ec:      	mov	w1, #0x4                // =4
    14f0:      	mov	x2, x22
    14f4:      	blr	x21
    14f8:      	b	0x207c <generic_fexit_event+0x207c>
    14fc:      	cmp	w23, #0x1a
    1500:      	b.eq	0x1d7c <generic_fexit_event+0x1d7c>
    1504:      	cmp	w23, #0x1b
    1508:      	b.ne	0xc64 <generic_fexit_event+0xc64>
    150c:      	ldp	x9, x8, [sp, #0x28]
    1510:      	add	x2, x25, #0x18
    1514:      	mov	w1, #0x3f               // =63
    1518:      	add	x0, x8, #0xac
    151c:      	stp	xzr, xzr, [x9, #0x40]
    1520:      	stp	xzr, xzr, [x9, #0x30]
    1524:      	stp	xzr, xzr, [x9, #0x20]
    1528:      	mov	w8, #0x3f               // =63
    152c:      	stp	xzr, xzr, [x9, #0x10]
    1530:      	stp	xzr, xzr, [x9]
    1534:      	mov	w9, #0x2d               // =45
    1538:      	blr	x9
    153c:      	tbnz	x0, #0x3f, 0x201c <generic_fexit_event+0x201c>
    1540:      	ldr	x8, [sp, #0x30]
    1544:      	add	x2, x25, #0x360
    1548:      	mov	w9, #0x4                // =4
    154c:      	mov	w1, #0x8                // =8
    1550:      	add	x0, x8, #0xa4
    1554:      	mov	w8, #0x8                // =8
    1558:      	blr	x9
    155c:      	mov	w29, #0x50              // =80
    1560:      	b	0xc64 <generic_fexit_event+0xc64>
    1564:      	cmp	w23, #0x8
    1568:      	b.eq	0x1a4c <generic_fexit_event+0x1a4c>
    156c:      	cmp	w23, #0x12
    1570:      	b.ne	0xc64 <generic_fexit_event+0xc64>
    1574:      	mov	x29, xzr
    1578:      	mov	w8, #0x4                // =4
    157c:      	ldr	x0, [sp, #0x28]
    1580:      	mov	w1, wzr
    1584:      	mov	x2, x25
    1588:      	blr	x8
    158c:      	b	0xc64 <generic_fexit_event+0xc64>
    1590:      	cmp	w23, #0x13
    1594:      	b.eq	0x1cac <generic_fexit_event+0x1cac>
    1598:      	cmp	w23, #0x14
    159c:      	b.ne	0xc64 <generic_fexit_event+0xc64>
    15a0:      	str	xzr, [sp, #0xb0]
    15a4:      	add	x2, x25, #0x110
    15a8:      	mov	w24, #0x8               // =8
    15ac:      	add	x8, sp, #0xb0
    15b0:      	mov	w9, #0x4                // =4
    15b4:      	add	x0, sp, #0xb0
    15b8:      	mov	w1, #0x8                // =8
    15bc:      	mov	x21, x22
    15c0:      	add	x22, x25, #0xd8
    15c4:      	mov	w23, #0x4               // =4
    15c8:      	blr	x9
    15cc:      	ldr	x8, [sp, #0xb0]
    15d0:      	mov	w9, #0x80               // =128
    15d4:      	mov	w10, #0x2d              // =45
    15d8:      	ldr	x0, [sp, #0x28]
    15dc:      	mov	w1, #0x80               // =128
    15e0:      	ldr	x2, [sp, #0xb0]
    15e4:      	blr	x10
    15e8:      	ldr	x29, [sp, #0x30]
    15ec:      	mov	w8, #0x4                // =4
    15f0:      	mov	w1, #0x4                // =4
    15f4:      	mov	x2, x22
    15f8:      	add	x0, x29, #0x12c
    15fc:      	mov	x22, x21
    1600:      	mov	w21, #0x5ea0            // =24224
    1604:      	blr	x8
    1608:      	add	x0, x29, #0x11c
    160c:      	add	x2, x25, #0xe0
    1610:      	mov	w8, #0x4                // =4
    1614:      	mov	w1, #0x8                // =8
    1618:      	blr	x8
    161c:      	add	x0, x29, #0x124
    1620:      	add	x2, x25, #0x118
    1624:      	mov	w1, #0x8                // =8
    1628:      	blr	x23
    162c:      	mov	w29, #0x98              // =152
    1630:      	b	0xc64 <generic_fexit_event+0xc64>
    1634:      	cmp	w23, #0x26
    1638:      	b.ne	0xc64 <generic_fexit_event+0xc64>
    163c:      	ldr	x8, [sp, #0x118]
    1640:      	ldr	x9, [sp, #0x30]
    1644:      	add	x2, x19, w8, uxth
    1648:      	ubfx	w8, w8, #16, #12
    164c:      	add	x0, x9, #0xa0
    1650:      	add	w1, w8, #0x1
    1654:      	mov	w8, #0x2d               // =45
    1658:      	blr	x8
    165c:      	b	0x194c <generic_fexit_event+0x194c>
    1660:      	stp	xzr, xzr, [sp, #0xb0]
    1664:      	mov	w8, #0xe                // =14
    1668:      	mov	x24, x22
    166c:      	blr	x8
    1670:      	lsr	x8, x0, #32
    1674:      	add	x9, sp, #0x100
    1678:      	add	x10, sp, #0x118
    167c:      	str	x8, [sp, #0xb0]
    1680:      	mov	w8, #0x4                // =4
    1684:      	add	x0, sp, #0x100
    1688:      	add	x2, sp, #0x118
    168c:      	mov	w1, #0x4                // =4
    1690:      	blr	x8
    1694:      	ldr	w8, [sp, #0x100]
    1698:      	adrp	x0, 0x1000 <generic_fexit_event+0x1000>
    169c:      	add	x9, sp, #0xb0
    16a0:      	add	x1, sp, #0xb0
    16a4:      	str	w8, [sp, #0xb8]
    16a8:      	mov	w8, #0x1                // =1
    16ac:      	ldr	x0, [x0]
    16b0:      	blr	x8
    16b4:      	cbz	x0, 0x1e68 <generic_fexit_event+0x1e68>
    16b8:      	ldr	x25, [sp, #0x28]
    16bc:      	ldr	w21, [x0]
    16c0:      	add	x8, sp, #0x100
    16c4:      	mov	w9, #0x4                // =4
    16c8:      	add	x2, sp, #0x100
    16cc:      	mov	x22, x0
    16d0:      	mov	w1, #0x4                // =4
    16d4:      	mov	w23, #0x4               // =4
    16d8:      	mov	x0, x25
    16dc:      	blr	x9
    16e0:      	ldr	x8, [sp, #0x30]
    16e4:      	and	x21, x21, #0xfff
    16e8:      	mov	x2, x22
    16ec:      	add	x1, x21, #0x4
    16f0:      	add	x0, x8, #0xa0
    16f4:      	mov	w8, #0x4                // =4
    16f8:      	blr	x8
    16fc:      	add	w21, w21, #0x8
    1700:      	mov	w1, #0x4                // =4
    1704:      	add	x8, x21, x22
    1708:      	add	x0, x25, x21
    170c:      	sub	x2, x8, #0x4
    1710:      	blr	x23
    1714:      	add	x29, x21, #0x4
    1718:      	b	0x2048 <generic_fexit_event+0x2048>
    171c:      	mov	x25, x22
    1720:      	ldr	x22, [sp, #0x118]
    1724:      	mov	w8, #0x1                // =1
    1728:      	mov	w9, #0x4                // =4
    172c:      	add	x10, sp, #0xf0
    1730:      	mov	x23, x0
    1734:      	add	x0, sp, #0xf0
    1738:      	mov	w1, #0x1                // =1
    173c:      	mov	x2, x22
    1740:      	blr	x9
    1744:      	ldrb	w8, [sp, #0xf0]
    1748:      	cmp	w8, #0x1
    174c:      	b.ne	0x1e58 <generic_fexit_event+0x1e58>
    1750:      	add	x2, x22, #0x10
    1754:      	mov	w21, #0x8               // =8
    1758:      	add	x8, sp, #0xb0
    175c:      	mov	w9, #0x4                // =4
    1760:      	add	x0, sp, #0xb0
    1764:      	mov	w1, #0x8                // =8
    1768:      	mov	w24, #0x4               // =4
    176c:      	blr	x9
    1770:      	ldr	x2, [sp, #0xb0]
    1774:      	add	x8, sp, #0x100
    1778:      	mov	w9, #0x4                // =4
    177c:      	add	x0, sp, #0x100
    1780:      	mov	w1, #0x8                // =8
    1784:      	blr	x9
    1788:      	ldr	x8, [sp, #0xb0]
    178c:      	mov	w9, #0x4                // =4
    1790:      	add	x0, sp, #0x88
    1794:      	mov	w1, #0x8                // =8
    1798:      	add	x2, x8, #0x8
    179c:      	add	x8, sp, #0x88
    17a0:      	blr	x9
    17a4:      	ldr	x21, [sp, #0x88]
    17a8:      	ldr	x2, [sp, #0x100]
    17ac:      	mov	w8, #0xfff              // =4095
    17b0:      	add	x0, x23, #0xa4
    17b4:      	cmp	x21, #0xfff
    17b8:      	csel	x22, x21, x8, lo
    17bc:      	mov	w1, w22
    17c0:      	blr	x24
    17c4:      	tbnz	w0, #0x1f, 0x1fb0 <generic_fexit_event+0x1fb0>
    17c8:      	stp	w21, w22, [x23, #0x9c]
    17cc:      	add	x29, x22, #0x8
    17d0:      	mov	x22, x25
    17d4:      	b	0xc60 <generic_fexit_event+0xc60>
    17d8:      	ldr	x24, [sp, #0x118]
    17dc:      	ldr	x21, [sp, #0x30]
    17e0:      	mov	w8, #0x4                // =4
    17e4:      	mov	w1, #0x4                // =4
    17e8:      	mov	w23, #0x4               // =4
    17ec:      	add	x0, x21, #0xc4
    17f0:      	str	x22, [sp, #0x18]
    17f4:      	add	x2, x24, #0x98
    17f8:      	blr	x8
    17fc:      	add	x0, x21, #0xc8
    1800:      	add	x2, x24, #0x70
    1804:      	mov	w8, #0x4                // =4
    1808:      	mov	w1, #0x4                // =4
    180c:      	blr	x8
    1810:      	add	x0, x21, #0xcc
    1814:      	add	x2, x24, #0x90
    1818:      	mov	w8, #0x4                // =4
    181c:      	mov	w1, #0x4                // =4
    1820:      	blr	x8
    1824:      	add	x0, x21, #0xd0
    1828:      	add	x2, x24, #0xa8
    182c:      	mov	w8, #0x4                // =4
    1830:      	mov	w1, #0x4                // =4
    1834:      	blr	x8
    1838:      	str	xzr, [sp, #0xb0]
    183c:      	add	x2, x24, #0xc8
    1840:      	mov	w8, #0x8                // =8
    1844:      	add	x9, sp, #0xb0
    1848:      	mov	w10, #0x4               // =4
    184c:      	add	x0, sp, #0xb0
    1850:      	mov	w1, #0x8                // =8
    1854:      	blr	x10
    1858:      	add	x2, x24, #0xb8
    185c:      	mov	w8, #0x2                // =2
    1860:      	add	x9, sp, #0xf0
    1864:      	mov	w10, #0x4               // =4
    1868:      	add	x0, sp, #0xf0
    186c:      	mov	w1, #0x2                // =2
    1870:      	blr	x10
    1874:      	ldr	x8, [sp, #0xb0]
    1878:      	ldrh	w9, [sp, #0xf0]
    187c:      	add	x0, sp, #0x9c
    1880:      	mov	w1, #0x1                // =1
    1884:      	add	x22, x8, x9
    1888:      	mov	w8, #0x1                // =1
    188c:      	add	x9, sp, #0x9c
    1890:      	mov	x2, x22
    1894:      	blr	x23
    1898:      	ldrb	w8, [sp, #0x9c]
    189c:      	lsr	w8, w8, #4
    18a0:      	cmp	w8, #0x6
    18a4:      	b.eq	0x1e70 <generic_fexit_event+0x1e70>
    18a8:      	cmp	w8, #0x4
    18ac:      	b.ne	0x2818 <generic_fexit_event+0x2818>
    18b0:      	add	x2, x22, #0x9
    18b4:      	mov	w8, #0x1                // =1
    18b8:      	add	x9, sp, #0xa0
    18bc:      	mov	w10, #0x4               // =4
    18c0:      	add	x0, sp, #0xa0
    18c4:      	mov	w1, #0x1                // =1
    18c8:      	mov	w25, #0x4               // =4
    18cc:      	blr	x10
    18d0:      	ldrb	w8, [sp, #0xa0]
    18d4:      	ldp	x0, x9, [sp, #0x28]
    18d8:      	mov	w21, #0x2               // =2
    18dc:      	add	x2, x22, #0xc
    18e0:      	mov	w1, #0x4                // =4
    18e4:      	add	x23, x9, #0xac
    18e8:      	strh	w8, [x9, #0xc0]
    18ec:      	strh	w21, [x9, #0xc2]
    18f0:      	stp	xzr, xzr, [x0]
    18f4:      	mov	w8, #0x4                // =4
    18f8:      	stp	xzr, xzr, [x0, #0x10]
    18fc:      	blr	x8
    1900:      	add	x2, x22, #0x10
    1904:      	mov	w8, #0x4                // =4
    1908:      	mov	x0, x23
    190c:      	mov	w1, #0x4                // =4
    1910:      	blr	x8
    1914:      	add	x2, x24, #0xb6
    1918:      	add	x8, sp, #0xa8
    191c:      	add	x0, sp, #0xa8
    1920:      	mov	w1, #0x2                // =2
    1924:      	blr	x25
    1928:      	b	0x26e4 <generic_fexit_event+0x26e4>
    192c:      	ldr	x8, [sp, #0x118]
    1930:      	mov	w9, #0x2d               // =45
    1934:      	mov	w1, #0x11               // =17
    1938:      	add	x2, x8, #0x118
    193c:      	ldr	x8, [sp, #0x30]
    1940:      	add	x0, x8, #0xa0
    1944:      	mov	w8, #0x11               // =17
    1948:      	blr	x9
    194c:      	mov	x29, x0
    1950:      	tbnz	x0, #0x3f, 0xc64 <generic_fexit_event+0xc64>
    1954:      	ldr	x9, [sp, #0x28]
    1958:      	sub	w8, w29, #0x1
    195c:      	add	x29, x29, #0x3
    1960:      	str	w8, [x9]
    1964:      	b	0xc64 <generic_fexit_event+0xc64>
    1968:      	mov	x23, x22
    196c:      	ldr	x22, [sp, #0x118]
    1970:      	stp	xzr, xzr, [x0, #0x8]
    1974:      	mov	w8, #0x2                // =2
    1978:      	mov	w9, #0x4                // =4
    197c:      	mov	w1, #0x2                // =2
    1980:      	str	xzr, [x0]
    1984:      	mov	x24, x0
    1988:      	mov	x2, x22
    198c:      	blr	x9
    1990:      	tbnz	x0, #0x3f, 0x2010 <generic_fexit_event+0x2010>
    1994:      	ldrh	w8, [x24]
    1998:      	cmp	w8, #0xa
    199c:      	b.eq	0x1fc4 <generic_fexit_event+0x1fc4>
    19a0:      	cmp	w8, #0x2
    19a4:      	b.ne	0x1ff8 <generic_fexit_event+0x1ff8>
    19a8:      	add	x2, x22, #0x4
    19ac:      	add	x8, sp, #0xb0
    19b0:      	mov	w9, #0x4                // =4
    19b4:      	add	x0, sp, #0xb0
    19b8:      	mov	w1, #0x4                // =4
    19bc:      	mov	w21, #0x4               // =4
    19c0:      	blr	x9
    19c4:      	ldr	w8, [sp, #0xb0]
    19c8:      	ldr	x9, [sp, #0x30]
    19cc:      	add	x2, x22, #0x2
    19d0:      	add	x0, x9, #0x9e
    19d4:      	stur	x8, [x9, #0xa4]
    19d8:      	mov	w8, #0x2                // =2
    19dc:      	b	0x1ff0 <generic_fexit_event+0x1ff0>
    19e0:      	str	x22, [sp, #0x18]
    19e4:      	str	xzr, [sp, #0x100]
    19e8:      	mov	w8, #0x8                // =8
    19ec:      	add	x9, sp, #0x100
    19f0:      	add	x10, sp, #0xb0
    19f4:      	mov	w11, #0x4               // =4
    19f8:      	str	xzr, [sp, #0xb0]
    19fc:      	mov	x24, x0
    1a00:      	add	x0, sp, #0x100
    1a04:      	add	x2, sp, #0xb0
    1a08:      	mov	w1, #0x8                // =8
    1a0c:      	mov	w29, #0x4               // =4
    1a10:      	blr	x11
    1a14:      	ldr	x21, [sp, #0x100]
    1a18:      	mov	w8, #0xfff              // =4095
    1a1c:      	add	x0, x24, #0xa4
    1a20:      	mov	x2, x25
    1a24:      	mov	x23, x24
    1a28:      	cmp	x21, #0xfff
    1a2c:      	csel	x22, x21, x8, lo
    1a30:      	mov	w8, #0x4                // =4
    1a34:      	mov	w1, w22
    1a38:      	blr	x8
    1a3c:      	tbnz	w0, #0x1f, 0x1fa4 <generic_fexit_event+0x1fa4>
    1a40:      	stp	w21, w22, [x23, #0x9c]
    1a44:      	add	x29, x22, #0x8
    1a48:      	b	0xc5c <generic_fexit_event+0xc5c>
    1a4c:      	ldp	x0, x29, [sp, #0x28]
    1a50:      	add	x2, x25, #0x8
    1a54:      	mov	w8, #0x4                // =4
    1a58:      	mov	w1, #0x4                // =4
    1a5c:      	mov	w23, #0x4               // =4
    1a60:      	str	x22, [sp, #0x18]
    1a64:      	add	x24, x29, #0xc4
    1a68:      	add	x22, x29, #0xdc
    1a6c:      	blr	x8
    1a70:      	add	x0, x29, #0xa0
    1a74:      	add	x2, x25, #0xc
    1a78:      	mov	w8, #0x4                // =4
    1a7c:      	mov	w1, #0x4                // =4
    1a80:      	blr	x8
    1a84:      	add	x0, x29, #0xac
    1a88:      	add	x2, x25, #0x18
    1a8c:      	mov	w8, #0x4                // =4
    1a90:      	mov	w1, #0x4                // =4
    1a94:      	blr	x8
    1a98:      	add	x0, x29, #0xb0
    1a9c:      	add	x2, x25, #0x1c
    1aa0:      	mov	w8, #0x4                // =4
    1aa4:      	mov	w1, #0x4                // =4
    1aa8:      	blr	x8
    1aac:      	add	x0, x29, #0xa4
    1ab0:      	add	x2, x25, #0x10
    1ab4:      	mov	w8, #0x4                // =4
    1ab8:      	mov	w1, #0x4                // =4
    1abc:      	blr	x8
    1ac0:      	add	x0, x29, #0xa8
    1ac4:      	add	x2, x25, #0x14
    1ac8:      	mov	w8, #0x4                // =4
    1acc:      	mov	w1, #0x4                // =4
    1ad0:      	blr	x8
    1ad4:      	add	x0, x29, #0xb4
    1ad8:      	add	x2, x25, #0x20
    1adc:      	mov	w8, #0x4                // =4
    1ae0:      	mov	w1, #0x4                // =4
    1ae4:      	blr	x8
    1ae8:      	add	x0, x29, #0xb8
    1aec:      	add	x2, x25, #0x24
    1af0:      	mov	w8, #0x4                // =4
    1af4:      	mov	w1, #0x4                // =4
    1af8:      	blr	x8
    1afc:      	str	wzr, [x29, #0xc0]
    1b00:      	add	x0, x29, #0xbc
    1b04:      	add	x2, x25, #0x28
    1b08:      	mov	w8, #0x4                // =4
    1b0c:      	mov	w1, #0x4                // =4
    1b10:      	blr	x8
    1b14:      	add	x0, x29, #0xcc
    1b18:      	add	x2, x25, #0x40
    1b1c:      	mov	w21, #0x8               // =8
    1b20:      	mov	w8, #0x4                // =4
    1b24:      	mov	w1, #0x8                // =8
    1b28:      	blr	x8
    1b2c:      	add	x0, x29, #0xd4
    1b30:      	add	x2, x25, #0x30
    1b34:      	mov	w8, #0x4                // =4
    1b38:      	mov	w1, #0x8                // =8
    1b3c:      	blr	x8
    1b40:      	add	x2, x25, #0x38
    1b44:      	mov	w8, #0x4                // =4
    1b48:      	mov	x0, x24
    1b4c:      	mov	w1, #0x8                // =8
    1b50:      	blr	x8
    1b54:      	add	x2, x25, #0x90
    1b58:      	add	x8, sp, #0xb0
    1b5c:      	mov	w9, #0x4                // =4
    1b60:      	add	x0, sp, #0xb0
    1b64:      	mov	w1, #0x8                // =8
    1b68:      	blr	x9
    1b6c:      	ldr	x21, [sp, #0xb0]
    1b70:      	mov	w8, #0x4                // =4
    1b74:      	mov	x0, x22
    1b78:      	mov	w1, #0x4                // =4
    1b7c:      	add	x2, x21, #0xc8
    1b80:      	ldr	x22, [sp, #0x18]
    1b84:      	blr	x8
    1b88:      	add	x0, x29, #0xe0
    1b8c:      	add	x2, x21, #0xcc
    1b90:      	mov	w8, #0x4                // =4
    1b94:      	mov	w1, #0x4                // =4
    1b98:      	blr	x8
    1b9c:      	add	x0, x29, #0xe4
    1ba0:      	add	x2, x21, #0xd0
    1ba4:      	mov	w8, #0x4                // =4
    1ba8:      	mov	w1, #0x4                // =4
    1bac:      	blr	x8
    1bb0:      	add	x0, x29, #0xe8
    1bb4:      	add	x2, x21, #0x158
    1bb8:      	mov	w1, #0x4                // =4
    1bbc:      	mov	w21, #0x5ea0            // =24224
    1bc0:      	blr	x23
    1bc4:      	mov	w29, #0x50              // =80
    1bc8:      	b	0xc64 <generic_fexit_event+0xc64>
    1bcc:      	ldr	x0, [sp, #0x28]
    1bd0:      	add	x2, x25, #0xc8
    1bd4:      	mov	w8, #0x4                // =4
    1bd8:      	mov	w1, #0x4                // =4
    1bdc:      	mov	w21, #0x4               // =4
    1be0:      	blr	x8
    1be4:      	ldr	x23, [sp, #0x30]
    1be8:      	add	x2, x25, #0xcc
    1bec:      	mov	w8, #0x4                // =4
    1bf0:      	mov	w1, #0x4                // =4
    1bf4:      	add	x0, x23, #0xa0
    1bf8:      	blr	x8
    1bfc:      	add	x0, x23, #0xa4
    1c00:      	add	x2, x25, #0xd0
    1c04:      	mov	w8, #0x4                // =4
    1c08:      	mov	w1, #0x4                // =4
    1c0c:      	blr	x8
    1c10:      	add	x0, x23, #0xa8
    1c14:      	add	x2, x25, #0x158
    1c18:      	mov	w1, #0x4                // =4
    1c1c:      	blr	x21
    1c20:      	mov	w21, #0x5ea0            // =24224
    1c24:      	mov	w29, #0x10              // =16
    1c28:      	b	0xc64 <generic_fexit_event+0xc64>
    1c2c:      	ldr	x0, [sp, #0x28]
    1c30:      	add	x2, x25, #0x38
    1c34:      	mov	w8, #0x4                // =4
    1c38:      	mov	w1, #0x4                // =4
    1c3c:      	mov	x21, x22
    1c40:      	mov	w22, #0x4               // =4
    1c44:      	blr	x8
    1c48:      	ldr	x23, [sp, #0x30]
    1c4c:      	add	x2, x25, #0x3c
    1c50:      	mov	w8, #0x4                // =4
    1c54:      	mov	w1, #0x4                // =4
    1c58:      	add	x0, x23, #0xa0
    1c5c:      	blr	x8
    1c60:      	add	x0, x23, #0xa4
    1c64:      	add	x2, x25, #0x40
    1c68:      	mov	w8, #0x4                // =4
    1c6c:      	mov	w1, #0x4                // =4
    1c70:      	blr	x8
    1c74:      	add	x0, x23, #0xa8
    1c78:      	add	x2, x25, #0x44
    1c7c:      	mov	w8, #0x4                // =4
    1c80:      	mov	w1, #0x4                // =4
    1c84:      	blr	x8
    1c88:      	add	x0, x23, #0xac
    1c8c:      	add	x2, x25, #0x80
    1c90:      	mov	w8, #0x10               // =16
    1c94:      	mov	w1, #0x10               // =16
    1c98:      	blr	x22
    1c9c:      	mov	x22, x21
    1ca0:      	mov	w21, #0x5ea0            // =24224
    1ca4:      	mov	w29, #0x20              // =32
    1ca8:      	b	0xc64 <generic_fexit_event+0xc64>
    1cac:      	ldr	x0, [sp, #0x28]
    1cb0:      	mov	w8, #0x4                // =4
    1cb4:      	mov	w1, #0x4                // =4
    1cb8:      	mov	x2, x25
    1cbc:      	mov	w21, #0x4               // =4
    1cc0:      	blr	x8
    1cc4:      	ldr	x23, [sp, #0x30]
    1cc8:      	add	x2, x25, #0x4
    1ccc:      	mov	w8, #0x4                // =4
    1cd0:      	mov	w1, #0x4                // =4
    1cd4:      	add	x0, x23, #0xa0
    1cd8:      	blr	x8
    1cdc:      	add	x0, x23, #0xa4
    1ce0:      	add	x2, x25, #0x30
    1ce4:      	mov	w8, #0x10               // =16
    1ce8:      	b	0x1d68 <generic_fexit_event+0x1d68>
    1cec:      	add	x2, x25, #0x4
    1cf0:      	add	x8, sp, #0xb0
    1cf4:      	mov	w9, #0x4                // =4
    1cf8:      	add	x0, sp, #0xb0
    1cfc:      	mov	w1, #0x4                // =4
    1d00:      	mov	w21, #0x4               // =4
    1d04:      	blr	x9
    1d08:      	ldr	w8, [sp, #0xb0]
    1d0c:      	ldr	x23, [sp, #0x30]
    1d10:      	add	x2, x25, #0xc
    1d14:      	add	x0, sp, #0xb0
    1d18:      	mov	w1, #0x4                // =4
    1d1c:      	str	w8, [x23, #0x9c]
    1d20:      	add	x8, sp, #0xb0
    1d24:      	blr	x21
    1d28:      	ldr	w8, [sp, #0xb0]
    1d2c:      	add	x2, x25, #0x50
    1d30:      	add	x9, sp, #0xb0
    1d34:      	mov	w10, #0x2d              // =45
    1d38:      	str	w8, [x23, #0xa0]
    1d3c:      	mov	w8, #0x8                // =8
    1d40:      	add	x0, sp, #0xb0
    1d44:      	mov	w1, #0x8                // =8
    1d48:      	mov	w21, #0x2d              // =45
    1d4c:      	blr	x10
    1d50:      	ldr	x8, [sp, #0xb0]
    1d54:      	add	x0, x23, #0xa4
    1d58:      	mov	w9, #0x10               // =16
    1d5c:      	add	x8, x8, #0x3f8
    1d60:      	ldr	x8, [sp, #0xb0]
    1d64:      	add	x2, x8, #0x3f8
    1d68:      	mov	w1, #0x10               // =16
    1d6c:      	blr	x21
    1d70:      	mov	w21, #0x5ea0            // =24224
    1d74:      	mov	w29, #0x18              // =24
    1d78:      	b	0xc64 <generic_fexit_event+0xc64>
    1d7c:      	ldr	x11, [sp, #0x28]
    1d80:      	mov	w8, #0x8                // =8
    1d84:      	mov	w9, #0x4                // =4
    1d88:      	add	x10, sp, #0xb0
    1d8c:      	stp	xzr, xzr, [x11, #0x40]
    1d90:      	add	x0, sp, #0xb0
    1d94:      	stp	xzr, xzr, [x11, #0x30]
    1d98:      	stp	xzr, xzr, [x11, #0x20]
    1d9c:      	mov	w1, #0x8                // =8
    1da0:      	mov	x2, x25
    1da4:      	stp	xzr, xzr, [x11, #0x10]
    1da8:      	stp	xzr, xzr, [x11]
    1dac:      	blr	x9
    1db0:      	mov	x29, xzr
    1db4:      	cbnz	x0, 0xc64 <generic_fexit_event+0xc64>
    1db8:      	ldr	x8, [sp, #0x30]
    1dbc:      	mov	w9, #0x3f               // =63
    1dc0:      	mov	w10, #0x2d              // =45
    1dc4:      	mov	w1, #0x3f               // =63
    1dc8:      	mov	x23, x22
    1dcc:      	add	x0, x8, #0xac
    1dd0:      	ldr	x8, [sp, #0xb0]
    1dd4:      	ldr	x2, [sp, #0xb0]
    1dd8:      	blr	x10
    1ddc:      	tbnz	x0, #0x3f, 0x2108 <generic_fexit_event+0x2108>
    1de0:      	add	x2, x25, #0x8
    1de4:      	mov	w21, #0x8               // =8
    1de8:      	add	x8, sp, #0x100
    1dec:      	mov	w9, #0x4                // =4
    1df0:      	add	x0, sp, #0x100
    1df4:      	mov	w1, #0x8                // =8
    1df8:      	mov	w22, #0x4               // =4
    1dfc:      	blr	x9
    1e00:      	ldr	x8, [sp, #0x30]
    1e04:      	mov	w9, #0x4                // =4
    1e08:      	mov	w1, #0x8                // =8
    1e0c:      	add	x0, x8, #0xa4
    1e10:      	ldr	x8, [sp, #0x100]
    1e14:      	add	x8, x8, #0x360
    1e18:      	ldr	x8, [sp, #0x100]
    1e1c:      	add	x2, x8, #0x360
    1e20:      	blr	x9
    1e24:      	add	x2, x25, #0x58
    1e28:      	add	x8, sp, #0x100
    1e2c:      	add	x0, sp, #0x100
    1e30:      	mov	w1, #0x4                // =4
    1e34:      	blr	x22
    1e38:      	cbnz	x0, 0x1e50 <generic_fexit_event+0x1e50>
    1e3c:      	ldr	w8, [sp, #0x100]
    1e40:      	ldr	x9, [sp, #0x28]
    1e44:      	cmp	w8, #0x0
    1e48:      	cset	w8, ne
    1e4c:      	str	w8, [x9]
    1e50:      	mov	w29, #0x50              // =80
    1e54:      	b	0x210c <generic_fexit_event+0x210c>
    1e58:      	stur	xzr, [x23, #0x9c]
    1e5c:      	mov	w29, #0x8               // =8
    1e60:      	mov	x22, x25
    1e64:      	b	0xc64 <generic_fexit_event+0xc64>
    1e68:      	mov	x29, #-0x1              // =-1
    1e6c:      	b	0x2048 <generic_fexit_event+0x2048>
    1e70:      	str	wzr, [sp, #0x100]
    1e74:      	adrp	x0, 0x1000 <generic_fexit_event+0x1000>
    1e78:      	ldr	x23, [sp, #0xb0]
    1e7c:      	mov	w8, #0x1                // =1
    1e80:      	add	x9, sp, #0x100
    1e84:      	add	x1, sp, #0x100
    1e88:      	ldrh	w21, [sp, #0xf0]
    1e8c:      	ldr	x0, [x0]
    1e90:      	add	x22, x23, x21
    1e94:      	blr	x8
    1e98:      	cbz	x0, 0x26a4 <generic_fexit_event+0x26a4>
    1e9c:      	mov	w8, #0xff               // =255
    1ea0:      	strh	w21, [x0]
    1ea4:      	strb	wzr, [x0, #0x7]
    1ea8:      	add	x29, x0, #0x6
    1eac:      	add	x2, x22, #0x6
    1eb0:      	mov	w9, #0x4                // =4
    1eb4:      	strb	w8, [x0, #0x5]
    1eb8:      	mov	w8, #0x1                // =1
    1ebc:      	mov	x25, x0
    1ec0:      	mov	x0, x29
    1ec4:      	mov	w1, #0x1                // =1
    1ec8:      	blr	x9
    1ecc:      	tbnz	x0, #0x3f, 0x26a4 <generic_fexit_event+0x26a4>
    1ed0:      	ldrb	w8, [x25, #0x5]
    1ed4:      	cmp	w8, #0x32
    1ed8:      	b.gt	0x2114 <generic_fexit_event+0x2114>
    1edc:      	cbz	w8, 0x2134 <generic_fexit_event+0x2134>
    1ee0:      	cmp	w8, #0x2b
    1ee4:      	b.eq	0x2134 <generic_fexit_event+0x2134>
    1ee8:      	cmp	w8, #0x2c
    1eec:      	b.ne	0x2200 <generic_fexit_event+0x2200>
    1ef0:      	mov	w8, #0x8                // =8
    1ef4:      	b	0x214c <generic_fexit_event+0x214c>
    1ef8:      	add	x2, x22, #0x48
    1efc:      	mov	w21, #0x10              // =16
    1f00:      	mov	w8, #0x4                // =4
    1f04:      	mov	w1, #0x10               // =16
    1f08:      	mov	w25, #0x4               // =4
    1f0c:      	blr	x8
    1f10:      	add	x2, x22, #0x38
    1f14:      	mov	x0, x23
    1f18:      	mov	w1, #0x10               // =16
    1f1c:      	blr	x25
    1f20:      	ldr	x25, [sp, #0x30]
    1f24:      	add	x2, x22, #0xe
    1f28:      	mov	w21, #0x2               // =2
    1f2c:      	mov	w8, #0x4                // =4
    1f30:      	mov	w1, #0x2                // =2
    1f34:      	add	x23, x22, #0xc
    1f38:      	mov	w22, #0x4               // =4
    1f3c:      	add	x0, x25, #0xbc
    1f40:      	blr	x8
    1f44:      	add	x0, x25, #0xbe
    1f48:      	mov	w1, #0x2                // =2
    1f4c:      	mov	x2, x23
    1f50:      	blr	x22
    1f54:      	ldrh	w8, [x25, #0xbe]
    1f58:      	adrp	x0, 0x1000 <generic_fexit_event+0x1000>
    1f5c:      	add	x9, sp, #0xb0
    1f60:      	add	x1, sp, #0xb0
    1f64:      	rev	w8, w8
    1f68:      	lsr	w8, w8, #16
    1f6c:      	strh	w8, [x25, #0xbe]
    1f70:      	ldr	x8, [sp, #0x118]
    1f74:      	str	x8, [sp, #0xb0]
    1f78:      	mov	w8, #0x1                // =1
    1f7c:      	ldr	x0, [x0]
    1f80:      	blr	x8
    1f84:      	cbz	x0, 0x2818 <generic_fexit_event+0x2818>
    1f88:      	ldr	w8, [x0]
    1f8c:      	str	w8, [x24, #0x10]
    1f90:      	ldr	x8, [x0, #0x8]
    1f94:      	str	x8, [x24, #0x18]
    1f98:      	ldr	w8, [x0, #0x4]
    1f9c:      	str	w8, [x24, #0x7c]
    1fa0:      	b	0x2818 <generic_fexit_event+0x2818>
    1fa4:      	mov	w21, #-0x2              // =-2
    1fa8:      	str	w21, [x23, #0x9c]
    1fac:      	b	0xc5c <generic_fexit_event+0xc5c>
    1fb0:      	mov	w8, #-0x2               // =-2
    1fb4:      	mov	w29, #0x4               // =4
    1fb8:      	mov	x22, x25
    1fbc:      	str	w8, [x23, #0x9c]
    1fc0:      	b	0xc60 <generic_fexit_event+0xc60>
    1fc4:      	ldr	x24, [sp, #0x30]
    1fc8:      	add	x2, x22, #0x8
    1fcc:      	mov	w8, #0x10               // =16
    1fd0:      	mov	w9, #0x4                // =4
    1fd4:      	mov	w1, #0x10               // =16
    1fd8:      	mov	w21, #0x4               // =4
    1fdc:      	add	x0, x24, #0xa4
    1fe0:      	blr	x9
    1fe4:      	add	x0, x24, #0x9e
    1fe8:      	add	x2, x22, #0x2
    1fec:      	mov	w8, #0x2                // =2
    1ff0:      	mov	w1, #0x2                // =2
    1ff4:      	blr	x21
    1ff8:      	ldr	x9, [sp, #0x30]
    1ffc:      	mov	w21, #0x5ea0            // =24224
    2000:      	ldrh	w8, [x9, #0x9e]
    2004:      	rev	w8, w8
    2008:      	lsr	w8, w8, #16
    200c:      	strh	w8, [x9, #0x9e]
    2010:      	mov	w29, #0x18              // =24
    2014:      	mov	x22, x23
    2018:      	b	0xc64 <generic_fexit_event+0xc64>
    201c:      	mov	x29, xzr
    2020:      	b	0xc64 <generic_fexit_event+0xc64>
    2024:      	add	x2, x22, #0x3
    2028:      	mov	w21, #0x6b              // =107
    202c:      	mov	w8, #0x71               // =113
    2030:      	mov	w1, #0x6b               // =107
    2034:      	blr	x8
    2038:      	tbnz	w0, #0x1f, 0x2044 <generic_fexit_event+0x2044>
    203c:      	ldr	x8, [sp, #0x30]
    2040:      	strb	w21, [x8, #0x9f]
    2044:      	mov	w29, #0x70              // =112
    2048:      	mov	x22, x24
    204c:      	b	0xc60 <generic_fexit_event+0xc60>
    2050:      	ldr	x0, [sp, #0x28]
    2054:      	add	x2, x22, #0x48
    2058:      	mov	w21, #0x10              // =16
    205c:      	mov	w8, #0x4                // =4
    2060:      	mov	w1, #0x10               // =16
    2064:      	mov	w25, #0x4               // =4
    2068:      	blr	x8
    206c:      	add	x2, x22, #0x38
    2070:      	mov	x0, x23
    2074:      	mov	w1, #0x10               // =16
    2078:      	blr	x25
    207c:      	ldr	x25, [sp, #0x30]
    2080:      	add	x2, x22, #0xe
    2084:      	mov	w21, #0x2               // =2
    2088:      	mov	w8, #0x4                // =4
    208c:      	mov	w1, #0x2                // =2
    2090:      	add	x23, x22, #0xc
    2094:      	mov	w22, #0x4               // =4
    2098:      	add	x0, x25, #0xbc
    209c:      	blr	x8
    20a0:      	add	x0, x25, #0xbe
    20a4:      	mov	w1, #0x2                // =2
    20a8:      	mov	x2, x23
    20ac:      	blr	x22
    20b0:      	ldrh	w8, [x25, #0xbe]
    20b4:      	rev	w8, w8
    20b8:      	lsr	w8, w8, #16
    20bc:      	strh	w8, [x25, #0xbe]
    20c0:      	ldr	x8, [sp, #0x30]
    20c4:      	adrp	x0, 0x2000 <generic_fexit_event+0x2000>
    20c8:      	add	x9, sp, #0xb0
    20cc:      	add	x1, sp, #0xb0
    20d0:      	ldur	x8, [x8, #0xc4]
    20d4:      	str	x8, [sp, #0xb0]
    20d8:      	mov	w8, #0x1                // =1
    20dc:      	ldr	x0, [x0]
    20e0:      	blr	x8
    20e4:      	cbz	x0, 0x2100 <generic_fexit_event+0x2100>
    20e8:      	ldr	w8, [x0]
    20ec:      	str	w8, [x24, #0x10]
    20f0:      	ldr	x8, [x0, #0x8]
    20f4:      	str	x8, [x24, #0x18]
    20f8:      	ldr	w8, [x0, #0x4]
    20fc:      	str	w8, [x24, #0x7c]
    2100:      	mov	w29, #0x40              // =64
    2104:      	b	0xc5c <generic_fexit_event+0xc5c>
    2108:      	mov	x29, xzr
    210c:      	mov	x22, x23
    2110:      	b	0xc60 <generic_fexit_event+0xc60>
    2114:      	cmp	w8, #0x33
    2118:      	b.eq	0x2140 <generic_fexit_event+0x2140>
    211c:      	cmp	w8, #0x3c
    2120:      	b.eq	0x2134 <generic_fexit_event+0x2134>
    2124:      	cmp	w8, #0xff
    2128:      	b.ne	0x2200 <generic_fexit_event+0x2200>
    212c:      	mov	w8, #0x28               // =40
    2130:      	b	0x214c <generic_fexit_event+0x214c>
    2134:      	ldrb	w8, [x25, #0x7]
    2138:      	lsl	w8, w8, #3
    213c:      	b	0x2148 <generic_fexit_event+0x2148>
    2140:      	ldrb	w8, [x25, #0x7]
    2144:      	lsl	w8, w8, #2
    2148:      	add	w8, w8, #0x8
    214c:      	strh	w8, [x25, #0x2]
    2150:      	ldrh	w9, [x25]
    2154:      	add	w9, w9, w8
    2158:      	ldrb	w8, [x25, #0x6]
    215c:      	strh	w9, [x25]
    2160:      	cmp	w8, #0x3c
    2164:      	b.hi	0x221c <generic_fexit_event+0x221c>
    2168:      	mov	x21, #0x1               // =1
    216c:      	mov	w10, #0x1               // =1
    2170:      	movk	x21, #0x1800, lsl #32
    2174:      	lsl	x10, x10, x8
    2178:      	movk	x21, #0x1008, lsl #48
    217c:      	tst	x10, x21
    2180:      	b.eq	0x221c <generic_fexit_event+0x221c>
    2184:      	strb	w8, [x25, #0x5]
    2188:      	add	x8, x23, w9, uxth
    218c:      	mov	w9, #0x2                // =2
    2190:      	mov	w10, #0x4               // =4
    2194:      	mov	x0, x29
    2198:      	mov	w1, #0x2                // =2
    219c:      	ldrh	w8, [x25]
    21a0:      	add	x2, x23, x8
    21a4:      	blr	x10
    21a8:      	tbnz	x0, #0x3f, 0x26a4 <generic_fexit_event+0x26a4>
    21ac:      	ldrb	w8, [x25, #0x5]
    21b0:      	cmp	w8, #0x32
    21b4:      	b.gt	0x21d4 <generic_fexit_event+0x21d4>
    21b8:      	cbz	w8, 0x21f4 <generic_fexit_event+0x21f4>
    21bc:      	cmp	w8, #0x2b
    21c0:      	b.eq	0x21f4 <generic_fexit_event+0x21f4>
    21c4:      	cmp	w8, #0x2c
    21c8:      	b.ne	0x22d8 <generic_fexit_event+0x22d8>
    21cc:      	mov	w8, #0x8                // =8
    21d0:      	b	0x2230 <generic_fexit_event+0x2230>
    21d4:      	cmp	w8, #0x33
    21d8:      	b.eq	0x2224 <generic_fexit_event+0x2224>
    21dc:      	cmp	w8, #0x3c
    21e0:      	b.eq	0x21f4 <generic_fexit_event+0x21f4>
    21e4:      	cmp	w8, #0xff
    21e8:      	b.ne	0x22d8 <generic_fexit_event+0x22d8>
    21ec:      	mov	w8, #0x28               // =40
    21f0:      	b	0x2230 <generic_fexit_event+0x2230>
    21f4:      	ldrb	w8, [x25, #0x7]
    21f8:      	lsl	w8, w8, #3
    21fc:      	b	0x222c <generic_fexit_event+0x222c>
    2200:      	ldrh	w8, [x25, #0x2]
    2204:      	ldrh	w9, [x25]
    2208:      	add	w9, w9, w8
    220c:      	ldrb	w8, [x25, #0x6]
    2210:      	strh	w9, [x25]
    2214:      	cmp	w8, #0x3c
    2218:      	b.ls	0x2168 <generic_fexit_event+0x2168>
    221c:      	strh	w9, [sp, #0xa8]
    2220:      	b	0x26a8 <generic_fexit_event+0x26a8>
    2224:      	ldrb	w8, [x25, #0x7]
    2228:      	lsl	w8, w8, #2
    222c:      	add	w8, w8, #0x8
    2230:      	strh	w8, [x25, #0x2]
    2234:      	ldrh	w9, [x25]
    2238:      	add	w9, w9, w8
    223c:      	ldrb	w8, [x25, #0x6]
    2240:      	strh	w9, [x25]
    2244:      	cmp	w8, #0x3c
    2248:      	b.hi	0x2840 <generic_fexit_event+0x2840>
    224c:      	mov	w10, #0x1               // =1
    2250:      	lsl	x10, x10, x8
    2254:      	tst	x10, x21
    2258:      	b.eq	0x2840 <generic_fexit_event+0x2840>
    225c:      	strb	w8, [x25, #0x5]
    2260:      	add	x8, x23, w9, uxth
    2264:      	mov	w9, #0x2                // =2
    2268:      	mov	w10, #0x4               // =4
    226c:      	mov	x0, x29
    2270:      	mov	w1, #0x2                // =2
    2274:      	ldrh	w8, [x25]
    2278:      	add	x2, x23, x8
    227c:      	blr	x10
    2280:      	tbnz	x0, #0x3f, 0x26a4 <generic_fexit_event+0x26a4>
    2284:      	ldrb	w8, [x25, #0x5]
    2288:      	cmp	w8, #0x32
    228c:      	b.gt	0x22ac <generic_fexit_event+0x22ac>
    2290:      	cbz	w8, 0x22cc <generic_fexit_event+0x22cc>
    2294:      	cmp	w8, #0x2b
    2298:      	b.eq	0x22cc <generic_fexit_event+0x22cc>
    229c:      	cmp	w8, #0x2c
    22a0:      	b.ne	0x23ac <generic_fexit_event+0x23ac>
    22a4:      	mov	w8, #0x8                // =8
    22a8:      	b	0x2304 <generic_fexit_event+0x2304>
    22ac:      	cmp	w8, #0x33
    22b0:      	b.eq	0x22f8 <generic_fexit_event+0x22f8>
    22b4:      	cmp	w8, #0x3c
    22b8:      	b.eq	0x22cc <generic_fexit_event+0x22cc>
    22bc:      	cmp	w8, #0xff
    22c0:      	b.ne	0x23ac <generic_fexit_event+0x23ac>
    22c4:      	mov	w8, #0x28               // =40
    22c8:      	b	0x2304 <generic_fexit_event+0x2304>
    22cc:      	ldrb	w8, [x25, #0x7]
    22d0:      	lsl	w8, w8, #3
    22d4:      	b	0x2300 <generic_fexit_event+0x2300>
    22d8:      	ldrh	w8, [x25, #0x2]
    22dc:      	ldrh	w9, [x25]
    22e0:      	add	w9, w9, w8
    22e4:      	ldrb	w8, [x25, #0x6]
    22e8:      	strh	w9, [x25]
    22ec:      	cmp	w8, #0x3c
    22f0:      	b.ls	0x224c <generic_fexit_event+0x224c>
    22f4:      	b	0x2840 <generic_fexit_event+0x2840>
    22f8:      	ldrb	w8, [x25, #0x7]
    22fc:      	lsl	w8, w8, #2
    2300:      	add	w8, w8, #0x8
    2304:      	strh	w8, [x25, #0x2]
    2308:      	ldrh	w9, [x25]
    230c:      	add	w9, w9, w8
    2310:      	ldrb	w8, [x25, #0x6]
    2314:      	strh	w9, [x25]
    2318:      	cmp	w8, #0x3c
    231c:      	b.hi	0x2840 <generic_fexit_event+0x2840>
    2320:      	mov	w10, #0x1               // =1
    2324:      	lsl	x10, x10, x8
    2328:      	tst	x10, x21
    232c:      	b.eq	0x2840 <generic_fexit_event+0x2840>
    2330:      	strb	w8, [x25, #0x5]
    2334:      	add	x8, x23, w9, uxth
    2338:      	mov	w9, #0x2                // =2
    233c:      	mov	w10, #0x4               // =4
    2340:      	mov	x0, x29
    2344:      	mov	w1, #0x2                // =2
    2348:      	ldrh	w8, [x25]
    234c:      	add	x2, x23, x8
    2350:      	blr	x10
    2354:      	tbnz	x0, #0x3f, 0x26a4 <generic_fexit_event+0x26a4>
    2358:      	ldrb	w8, [x25, #0x5]
    235c:      	cmp	w8, #0x32
    2360:      	b.gt	0x2380 <generic_fexit_event+0x2380>
    2364:      	cbz	w8, 0x23a0 <generic_fexit_event+0x23a0>
    2368:      	cmp	w8, #0x2b
    236c:      	b.eq	0x23a0 <generic_fexit_event+0x23a0>
    2370:      	cmp	w8, #0x2c
    2374:      	b.ne	0x2480 <generic_fexit_event+0x2480>
    2378:      	mov	w8, #0x8                // =8
    237c:      	b	0x23d8 <generic_fexit_event+0x23d8>
    2380:      	cmp	w8, #0x33
    2384:      	b.eq	0x23cc <generic_fexit_event+0x23cc>
    2388:      	cmp	w8, #0x3c
    238c:      	b.eq	0x23a0 <generic_fexit_event+0x23a0>
    2390:      	cmp	w8, #0xff
    2394:      	b.ne	0x2480 <generic_fexit_event+0x2480>
    2398:      	mov	w8, #0x28               // =40
    239c:      	b	0x23d8 <generic_fexit_event+0x23d8>
    23a0:      	ldrb	w8, [x25, #0x7]
    23a4:      	lsl	w8, w8, #3
    23a8:      	b	0x23d4 <generic_fexit_event+0x23d4>
    23ac:      	ldrh	w8, [x25, #0x2]
    23b0:      	ldrh	w9, [x25]
    23b4:      	add	w9, w9, w8
    23b8:      	ldrb	w8, [x25, #0x6]
    23bc:      	strh	w9, [x25]
    23c0:      	cmp	w8, #0x3c
    23c4:      	b.ls	0x2320 <generic_fexit_event+0x2320>
    23c8:      	b	0x2840 <generic_fexit_event+0x2840>
    23cc:      	ldrb	w8, [x25, #0x7]
    23d0:      	lsl	w8, w8, #2
    23d4:      	add	w8, w8, #0x8
    23d8:      	strh	w8, [x25, #0x2]
    23dc:      	ldrh	w9, [x25]
    23e0:      	add	w9, w9, w8
    23e4:      	ldrb	w8, [x25, #0x6]
    23e8:      	strh	w9, [x25]
    23ec:      	cmp	w8, #0x3c
    23f0:      	b.hi	0x2840 <generic_fexit_event+0x2840>
    23f4:      	mov	w10, #0x1               // =1
    23f8:      	lsl	x10, x10, x8
    23fc:      	tst	x10, x21
    2400:      	b.eq	0x2840 <generic_fexit_event+0x2840>
    2404:      	strb	w8, [x25, #0x5]
    2408:      	add	x8, x23, w9, uxth
    240c:      	mov	w9, #0x2                // =2
    2410:      	mov	w10, #0x4               // =4
    2414:      	mov	x0, x29
    2418:      	mov	w1, #0x2                // =2
    241c:      	ldrh	w8, [x25]
    2420:      	add	x2, x23, x8
    2424:      	blr	x10
    2428:      	tbnz	x0, #0x3f, 0x26a4 <generic_fexit_event+0x26a4>
    242c:      	ldrb	w8, [x25, #0x5]
    2430:      	cmp	w8, #0x32
    2434:      	b.gt	0x2454 <generic_fexit_event+0x2454>
    2438:      	cbz	w8, 0x2474 <generic_fexit_event+0x2474>
    243c:      	cmp	w8, #0x2b
    2440:      	b.eq	0x2474 <generic_fexit_event+0x2474>
    2444:      	cmp	w8, #0x2c
    2448:      	b.ne	0x2554 <generic_fexit_event+0x2554>
    244c:      	mov	w8, #0x8                // =8
    2450:      	b	0x24ac <generic_fexit_event+0x24ac>
    2454:      	cmp	w8, #0x33
    2458:      	b.eq	0x24a0 <generic_fexit_event+0x24a0>
    245c:      	cmp	w8, #0x3c
    2460:      	b.eq	0x2474 <generic_fexit_event+0x2474>
    2464:      	cmp	w8, #0xff
    2468:      	b.ne	0x2554 <generic_fexit_event+0x2554>
    246c:      	mov	w8, #0x28               // =40
    2470:      	b	0x24ac <generic_fexit_event+0x24ac>
    2474:      	ldrb	w8, [x25, #0x7]
    2478:      	lsl	w8, w8, #3
    247c:      	b	0x24a8 <generic_fexit_event+0x24a8>
    2480:      	ldrh	w8, [x25, #0x2]
    2484:      	ldrh	w9, [x25]
    2488:      	add	w9, w9, w8
    248c:      	ldrb	w8, [x25, #0x6]
    2490:      	strh	w9, [x25]
    2494:      	cmp	w8, #0x3c
    2498:      	b.ls	0x23f4 <generic_fexit_event+0x23f4>
    249c:      	b	0x2840 <generic_fexit_event+0x2840>
    24a0:      	ldrb	w8, [x25, #0x7]
    24a4:      	lsl	w8, w8, #2
    24a8:      	add	w8, w8, #0x8
    24ac:      	strh	w8, [x25, #0x2]
    24b0:      	ldrh	w9, [x25]
    24b4:      	add	w9, w9, w8
    24b8:      	ldrb	w8, [x25, #0x6]
    24bc:      	strh	w9, [x25]
    24c0:      	cmp	w8, #0x3c
    24c4:      	b.hi	0x2840 <generic_fexit_event+0x2840>
    24c8:      	mov	w10, #0x1               // =1
    24cc:      	lsl	x10, x10, x8
    24d0:      	tst	x10, x21
    24d4:      	b.eq	0x2840 <generic_fexit_event+0x2840>
    24d8:      	strb	w8, [x25, #0x5]
    24dc:      	add	x8, x23, w9, uxth
    24e0:      	mov	w9, #0x2                // =2
    24e4:      	mov	w10, #0x4               // =4
    24e8:      	mov	x0, x29
    24ec:      	mov	w1, #0x2                // =2
    24f0:      	ldrh	w8, [x25]
    24f4:      	add	x2, x23, x8
    24f8:      	blr	x10
    24fc:      	tbnz	x0, #0x3f, 0x26a4 <generic_fexit_event+0x26a4>
    2500:      	ldrb	w8, [x25, #0x5]
    2504:      	cmp	w8, #0x32
    2508:      	b.gt	0x2528 <generic_fexit_event+0x2528>
    250c:      	cbz	w8, 0x2548 <generic_fexit_event+0x2548>
    2510:      	cmp	w8, #0x2b
    2514:      	b.eq	0x2548 <generic_fexit_event+0x2548>
    2518:      	cmp	w8, #0x2c
    251c:      	b.ne	0x2628 <generic_fexit_event+0x2628>
    2520:      	mov	w8, #0x8                // =8
    2524:      	b	0x2580 <generic_fexit_event+0x2580>
    2528:      	cmp	w8, #0x33
    252c:      	b.eq	0x2574 <generic_fexit_event+0x2574>
    2530:      	cmp	w8, #0x3c
    2534:      	b.eq	0x2548 <generic_fexit_event+0x2548>
    2538:      	cmp	w8, #0xff
    253c:      	b.ne	0x2628 <generic_fexit_event+0x2628>
    2540:      	mov	w8, #0x28               // =40
    2544:      	b	0x2580 <generic_fexit_event+0x2580>
    2548:      	ldrb	w8, [x25, #0x7]
    254c:      	lsl	w8, w8, #3
    2550:      	b	0x257c <generic_fexit_event+0x257c>
    2554:      	ldrh	w8, [x25, #0x2]
    2558:      	ldrh	w9, [x25]
    255c:      	add	w9, w9, w8
    2560:      	ldrb	w8, [x25, #0x6]
    2564:      	strh	w9, [x25]
    2568:      	cmp	w8, #0x3c
    256c:      	b.ls	0x24c8 <generic_fexit_event+0x24c8>
    2570:      	b	0x2840 <generic_fexit_event+0x2840>
    2574:      	ldrb	w8, [x25, #0x7]
    2578:      	lsl	w8, w8, #2
    257c:      	add	w8, w8, #0x8
    2580:      	strh	w8, [x25, #0x2]
    2584:      	ldrh	w9, [x25]
    2588:      	add	w9, w9, w8
    258c:      	ldrb	w8, [x25, #0x6]
    2590:      	strh	w9, [x25]
    2594:      	cmp	w8, #0x3c
    2598:      	b.hi	0x2840 <generic_fexit_event+0x2840>
    259c:      	mov	w10, #0x1               // =1
    25a0:      	lsl	x10, x10, x8
    25a4:      	tst	x10, x21
    25a8:      	b.eq	0x2840 <generic_fexit_event+0x2840>
    25ac:      	strb	w8, [x25, #0x5]
    25b0:      	add	x8, x23, w9, uxth
    25b4:      	mov	w9, #0x2                // =2
    25b8:      	mov	w10, #0x4               // =4
    25bc:      	mov	x0, x29
    25c0:      	mov	w1, #0x2                // =2
    25c4:      	ldrh	w8, [x25]
    25c8:      	add	x2, x23, x8
    25cc:      	blr	x10
    25d0:      	tbnz	x0, #0x3f, 0x26a4 <generic_fexit_event+0x26a4>
    25d4:      	ldrb	w8, [x25, #0x5]
    25d8:      	cmp	w8, #0x32
    25dc:      	b.gt	0x25fc <generic_fexit_event+0x25fc>
    25e0:      	cbz	w8, 0x261c <generic_fexit_event+0x261c>
    25e4:      	cmp	w8, #0x2b
    25e8:      	b.eq	0x261c <generic_fexit_event+0x261c>
    25ec:      	cmp	w8, #0x2c
    25f0:      	b.ne	0x2824 <generic_fexit_event+0x2824>
    25f4:      	mov	w8, #0x8                // =8
    25f8:      	b	0x2654 <generic_fexit_event+0x2654>
    25fc:      	cmp	w8, #0x33
    2600:      	b.eq	0x2648 <generic_fexit_event+0x2648>
    2604:      	cmp	w8, #0x3c
    2608:      	b.eq	0x261c <generic_fexit_event+0x261c>
    260c:      	cmp	w8, #0xff
    2610:      	b.ne	0x2824 <generic_fexit_event+0x2824>
    2614:      	mov	w8, #0x28               // =40
    2618:      	b	0x2654 <generic_fexit_event+0x2654>
    261c:      	ldrb	w8, [x25, #0x7]
    2620:      	lsl	w8, w8, #3
    2624:      	b	0x2650 <generic_fexit_event+0x2650>
    2628:      	ldrh	w8, [x25, #0x2]
    262c:      	ldrh	w9, [x25]
    2630:      	add	w9, w9, w8
    2634:      	ldrb	w8, [x25, #0x6]
    2638:      	strh	w9, [x25]
    263c:      	cmp	w8, #0x3c
    2640:      	b.ls	0x259c <generic_fexit_event+0x259c>
    2644:      	b	0x2840 <generic_fexit_event+0x2840>
    2648:      	ldrb	w8, [x25, #0x7]
    264c:      	lsl	w8, w8, #2
    2650:      	add	w8, w8, #0x8
    2654:      	strh	w8, [x25, #0x2]
    2658:      	ldrh	w9, [x25]
    265c:      	add	w9, w9, w8
    2660:      	ldrb	w8, [x25, #0x6]
    2664:      	strh	w9, [x25]
    2668:      	cmp	w8, #0x3c
    266c:      	b.hi	0x2840 <generic_fexit_event+0x2840>
    2670:      	mov	w10, #0x1               // =1
    2674:      	lsl	x10, x10, x8
    2678:      	tst	x10, x21
    267c:      	b.eq	0x2840 <generic_fexit_event+0x2840>
    2680:      	strb	w8, [x25, #0x5]
    2684:      	add	x8, x23, w9, uxth
    2688:      	mov	w9, #0x2                // =2
    268c:      	mov	w10, #0x4               // =4
    2690:      	mov	x0, x29
    2694:      	mov	w1, #0x2                // =2
    2698:      	ldrh	w8, [x25]
    269c:      	add	x2, x23, x8
    26a0:      	blr	x10
    26a4:      	mov	w8, wzr
    26a8:      	ldp	x0, x25, [sp, #0x28]
    26ac:      	add	x2, x22, #0x8
    26b0:      	mov	w21, #0x10              // =16
    26b4:      	mov	w1, #0x10               // =16
    26b8:      	mov	w23, #0x4               // =4
    26bc:      	strb	w8, [sp, #0xa0]
    26c0:      	strh	w8, [x25, #0xc0]
    26c4:      	mov	w8, #0xa                // =10
    26c8:      	strh	w8, [x25, #0xc2]
    26cc:      	mov	w8, #0x4                // =4
    26d0:      	blr	x8
    26d4:      	add	x0, x25, #0xac
    26d8:      	add	x2, x22, #0x18
    26dc:      	mov	w1, #0x10               // =16
    26e0:      	blr	x23
    26e4:      	ldrb	w8, [sp, #0xa0]
    26e8:      	cmp	w8, #0x11
    26ec:      	b.eq	0x2730 <generic_fexit_event+0x2730>
    26f0:      	cmp	w8, #0x6
    26f4:      	b.ne	0x2770 <generic_fexit_event+0x2770>
    26f8:      	ldr	x8, [sp, #0xb0]
    26fc:      	ldrh	w9, [sp, #0xa8]
    2700:      	mov	w21, #0x2               // =2
    2704:      	mov	w1, #0x2                // =2
    2708:      	mov	w23, #0x4               // =4
    270c:      	add	x22, x8, x9
    2710:      	ldr	x25, [sp, #0x30]
    2714:      	add	x0, x25, #0xbc
    2718:      	mov	w8, #0x4                // =4
    271c:      	mov	x2, x22
    2720:      	blr	x8
    2724:      	add	x0, x25, #0xbe
    2728:      	add	x2, x22, #0x2
    272c:      	b	0x2764 <generic_fexit_event+0x2764>
    2730:      	ldr	x8, [sp, #0xb0]
    2734:      	ldrh	w9, [sp, #0xa8]
    2738:      	mov	w21, #0x2               // =2
    273c:      	mov	w1, #0x2                // =2
    2740:      	mov	w23, #0x4               // =4
    2744:      	add	x22, x8, x9
    2748:      	ldr	x25, [sp, #0x30]
    274c:      	add	x0, x25, #0xbc
    2750:      	mov	w8, #0x4                // =4
    2754:      	mov	x2, x22
    2758:      	blr	x8
    275c:      	add	x0, x25, #0xbe
    2760:      	add	x2, x22, #0x2
    2764:      	mov	w1, #0x2                // =2
    2768:      	blr	x23
    276c:      	b	0x2778 <generic_fexit_event+0x2778>
    2770:      	ldr	x25, [sp, #0x30]
    2774:      	str	wzr, [x25, #0xbc]
    2778:      	ldrh	w8, [x25, #0xbc]
    277c:      	add	x2, x24, #0xe0
    2780:      	mov	w9, #0x4                // =4
    2784:      	add	x10, sp, #0x100
    2788:      	add	x0, sp, #0x100
    278c:      	mov	w1, #0x8                // =8
    2790:      	rev	w8, w8
    2794:      	lsr	w8, w8, #16
    2798:      	strh	w8, [x25, #0xbc]
    279c:      	ldrh	w8, [x25, #0xbe]
    27a0:      	rev	w8, w8
    27a4:      	lsr	w8, w8, #16
    27a8:      	strh	w8, [x25, #0xbe]
    27ac:      	mov	w8, #0x8                // =8
    27b0:      	blr	x9
    27b4:      	ldr	x8, [sp, #0x100]
    27b8:      	cbz	x8, 0x2818 <generic_fexit_event+0x2818>
    27bc:      	add	x8, x8, #0x5
    27c0:      	mov	w9, #0x8                // =8
    27c4:      	add	x10, sp, #0x88
    27c8:      	mov	w11, #0x4               // =4
    27cc:      	ldr	x8, [sp, #0x100]
    27d0:      	add	x0, sp, #0x88
    27d4:      	mov	w1, #0x8                // =8
    27d8:      	mov	w21, #0x4               // =4
    27dc:      	add	x2, x8, #0x5
    27e0:      	blr	x11
    27e4:      	ldr	x8, [sp, #0x100]
    27e8:      	ldr	x9, [sp, #0x88]
    27ec:      	mov	w1, #0x4                // =4
    27f0:      	add	x22, x8, x9, lsl #3
    27f4:      	ldr	x23, [sp, #0x30]
    27f8:      	add	x0, x23, #0xd4
    27fc:      	mov	w8, #0x4                // =4
    2800:      	add	x2, x22, #0x44
    2804:      	blr	x8
    2808:      	add	x0, x23, #0xd8
    280c:      	add	x2, x22, #0x45
    2810:      	mov	w1, #0x4                // =4
    2814:      	blr	x21
    2818:      	ldr	x22, [sp, #0x18]
    281c:      	mov	w29, #0x40              // =64
    2820:      	b	0xc60 <generic_fexit_event+0xc60>
    2824:      	ldrh	w8, [x25, #0x2]
    2828:      	ldrh	w9, [x25]
    282c:      	add	w9, w9, w8
    2830:      	ldrb	w8, [x25, #0x6]
    2834:      	strh	w9, [x25]
    2838:      	cmp	w8, #0x3c
    283c:      	b.ls	0x2670 <generic_fexit_event+0x2670>
    2840:      	strh	w9, [sp, #0xa8]
    2844:      	b	0x26a8 <generic_fexit_event+0x26a8>
