
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/cilium/bpf_alignchecker.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <__check_cluster_id_bits>:
       0:      	adrp	x8, 0x0 <__check_cluster_id_bits>
       4:      	ldr	x8, [x8]
       8:      	ldr	wzr, [x8]
       c:      	ret

Disassembly of section tc/tail:

0000000000000000 <tail_icmp6_send_time_exceeded>:
       0:      	sub	sp, sp, #0xe0
       4:      	stp	x30, x23, [sp, #0xb0]
       8:      	stp	x22, x21, [sp, #0xc0]
       c:      	stp	x20, x19, [sp, #0xd0]
      10:      	mov	w8, #0x3a               // =58
      14:      	ldp	w20, w22, [x0, #0x30]
      18:      	str	wzr, [x0, #0x30]
      1c:      	add	x21, sp, #0x20
      20:      	mov	w3, #0x28               // =40
      24:      	mov	x19, x0
      28:      	add	x2, x21, #0x8
      2c:      	stp	xzr, xzr, [sp, #0x60]
      30:      	mov	w1, w20
      34:      	stp	xzr, xzr, [sp, #0x50]
      38:      	stp	xzr, xzr, [sp, #0x40]
      3c:      	stp	xzr, xzr, [sp, #0x30]
      40:      	str	xzr, [sp, #0x28]
      44:      	strh	wzr, [sp, #0x1c]
      48:      	strb	w8, [sp, #0x18]
      4c:      	adrp	x8, 0x0 <tail_icmp6_send_time_exceeded>
      50:      	ldr	x8, [x8]
      54:      	ldr	x9, [x8]
      58:      	str	x9, [sp, #0x10]
      5c:      	ldr	x8, [x8, #0x8]
      60:      	str	x8, [sp, #0x8]
      64:      	mov	w8, #0x3                // =3
      68:      	str	x8, [sp, #0x20]
      6c:      	mov	w8, #0x1a               // =26
      70:      	blr	x8
      74:      	tbnz	w0, #0x1f, 0x490 <tail_icmp6_send_time_exceeded+0x490>
      78:      	mov	w8, #0x9                // =9
      7c:      	add	w1, w20, #0x6
      80:      	add	x2, sp, #0x18
      84:      	mov	x0, x19
      88:      	mov	w3, #0x1                // =1
      8c:      	mov	w4, wzr
      90:      	blr	x8
      94:      	tbnz	w0, #0x1f, 0x498 <tail_icmp6_send_time_exceeded+0x498>
      98:      	ldrb	w8, [sp, #0x2e]
      9c:      	cmp	w8, #0x6
      a0:      	b.eq	0x1cc <tail_icmp6_send_time_exceeded+0x1cc>
      a4:      	cmp	w8, #0x3a
      a8:      	b.eq	0xb4 <tail_icmp6_send_time_exceeded+0xb4>
      ac:      	cmp	w8, #0x11
      b0:      	b.ne	0x4a0 <tail_icmp6_send_time_exceeded+0x4a0>
      b4:      	mov	w8, #0x1a               // =26
      b8:      	add	w1, w20, #0x28
      bc:      	add	x2, x21, #0x30
      c0:      	mov	x0, x19
      c4:      	mov	w3, #0x8                // =8
      c8:      	blr	x8
      cc:      	tbnz	w0, #0x1f, 0x490 <tail_icmp6_send_time_exceeded+0x490>
      d0:      	mov	w8, #0x1c               // =28
      d4:      	add	x2, sp, #0x20
      d8:      	mov	x0, xzr
      dc:      	mov	w1, wzr
      e0:      	mov	w3, #0x38               // =56
      e4:      	mov	w4, wzr
      e8:      	mov	w21, #0x1c              // =28
      ec:      	add	x23, sp, #0x20
      f0:      	blr	x8
      f4:      	mov	w8, #0x38000000         // =939524096
      f8:      	mov	w4, w0
      fc:      	add	x2, x23, #0x10
     100:      	str	w8, [sp, #0xa0]
     104:      	mov	w8, #0x3a000000         // =973078528
     108:      	mov	x0, xzr
     10c:      	mov	w1, wzr
     110:      	str	w8, [sp, #0x80]
     114:      	mov	w8, #0x1c               // =28
     118:      	mov	w3, #0x10               // =16
     11c:      	blr	x8
     120:      	mov	w8, #0x1c               // =28
     124:      	mov	w4, w0
     128:      	add	x2, x23, #0x20
     12c:      	mov	x0, xzr
     130:      	mov	w1, wzr
     134:      	mov	w3, #0x10               // =16
     138:      	blr	x8
     13c:      	mov	w8, #0x1c               // =28
     140:      	mov	w4, w0
     144:      	add	x2, sp, #0xa0
     148:      	mov	x0, xzr
     14c:      	mov	w1, wzr
     150:      	mov	w3, #0x4                // =4
     154:      	blr	x8
     158:      	mov	w4, w0
     15c:      	add	x2, sp, #0x80
     160:      	mov	x0, xzr
     164:      	mov	w1, wzr
     168:      	mov	w3, #0x4                // =4
     16c:      	blr	x21
     170:      	mov	w8, #0x3800             // =14336
     174:      	mov	w9, #0x26               // =38
     178:      	mov	w21, w0
     17c:      	strh	w8, [sp, #0x1c]
     180:      	ldrh	w8, [sp, #0x2c]
     184:      	mov	x0, x19
     188:      	mov	w2, wzr
     18c:      	ldr	w10, [x19, #0x70]
     190:      	rev	w8, w8
     194:      	sub	w8, w10, w8, lsr #16
     198:      	add	w1, w8, #0x38
     19c:      	blr	x9
     1a0:      	tbnz	w0, #0x1f, 0x498 <tail_icmp6_send_time_exceeded+0x498>
     1a4:      	mov	w8, #0x9                // =9
     1a8:      	add	w1, w20, #0x28
     1ac:      	add	x2, sp, #0x20
     1b0:      	mov	x0, x19
     1b4:      	mov	w3, #0x38               // =56
     1b8:      	mov	w4, wzr
     1bc:      	blr	x8
     1c0:      	tbnz	w0, #0x1f, 0x498 <tail_icmp6_send_time_exceeded+0x498>
     1c4:      	mov	w8, #0x9                // =9
     1c8:      	b	0x2e0 <tail_icmp6_send_time_exceeded+0x2e0>
     1cc:      	mov	w8, #0x1a               // =26
     1d0:      	add	w1, w20, #0x28
     1d4:      	add	x2, x21, #0x30
     1d8:      	mov	x0, x19
     1dc:      	mov	w3, #0x14               // =20
     1e0:      	blr	x8
     1e4:      	tbnz	w0, #0x1f, 0x490 <tail_icmp6_send_time_exceeded+0x490>
     1e8:      	mov	w8, #0x1c               // =28
     1ec:      	add	x2, sp, #0x20
     1f0:      	mov	x0, xzr
     1f4:      	mov	w1, wzr
     1f8:      	mov	w3, #0x44               // =68
     1fc:      	mov	w4, wzr
     200:      	mov	w21, #0x1c              // =28
     204:      	add	x23, sp, #0x20
     208:      	blr	x8
     20c:      	mov	w8, #0x44000000         // =1140850688
     210:      	mov	w4, w0
     214:      	add	x2, x23, #0x10
     218:      	str	w8, [sp, #0xa0]
     21c:      	mov	w8, #0x3a000000         // =973078528
     220:      	mov	x0, xzr
     224:      	mov	w1, wzr
     228:      	str	w8, [sp, #0x80]
     22c:      	mov	w8, #0x1c               // =28
     230:      	mov	w3, #0x10               // =16
     234:      	blr	x8
     238:      	mov	w8, #0x1c               // =28
     23c:      	mov	w4, w0
     240:      	add	x2, x23, #0x20
     244:      	mov	x0, xzr
     248:      	mov	w1, wzr
     24c:      	mov	w3, #0x10               // =16
     250:      	blr	x8
     254:      	mov	w8, #0x1c               // =28
     258:      	mov	w4, w0
     25c:      	add	x2, sp, #0xa0
     260:      	mov	x0, xzr
     264:      	mov	w1, wzr
     268:      	mov	w3, #0x4                // =4
     26c:      	blr	x8
     270:      	mov	w4, w0
     274:      	add	x2, sp, #0x80
     278:      	mov	x0, xzr
     27c:      	mov	w1, wzr
     280:      	mov	w3, #0x4                // =4
     284:      	blr	x21
     288:      	mov	w8, #0x4400             // =17408
     28c:      	mov	w9, #0x26               // =38
     290:      	mov	w21, w0
     294:      	strh	w8, [sp, #0x1c]
     298:      	ldrh	w8, [sp, #0x2c]
     29c:      	mov	x0, x19
     2a0:      	mov	w2, wzr
     2a4:      	ldr	w10, [x19, #0x70]
     2a8:      	rev	w8, w8
     2ac:      	sub	w8, w10, w8, lsr #16
     2b0:      	add	w1, w8, #0x44
     2b4:      	blr	x9
     2b8:      	tbnz	w0, #0x1f, 0x498 <tail_icmp6_send_time_exceeded+0x498>
     2bc:      	mov	w8, #0x9                // =9
     2c0:      	add	w1, w20, #0x28
     2c4:      	add	x2, sp, #0x20
     2c8:      	mov	x0, x19
     2cc:      	mov	w3, #0x44               // =68
     2d0:      	mov	w4, wzr
     2d4:      	blr	x8
     2d8:      	tbnz	w0, #0x1f, 0x498 <tail_icmp6_send_time_exceeded+0x498>
     2dc:      	mov	w8, #0x9                // =9
     2e0:      	add	w1, w20, #0x4
     2e4:      	add	x2, sp, #0x1c
     2e8:      	mov	x0, x19
     2ec:      	mov	w3, #0x2                // =2
     2f0:      	mov	w4, wzr
     2f4:      	blr	x8
     2f8:      	tbnz	w0, #0x1f, 0x498 <tail_icmp6_send_time_exceeded+0x498>
     2fc:      	mov	w8, #0xb                // =11
     300:      	add	w1, w20, #0x2a
     304:      	mov	x0, x19
     308:      	mov	w2, wzr
     30c:      	mov	w3, w21
     310:      	mov	w4, #0x10               // =16
     314:      	blr	x8
     318:      	tbnz	w0, #0x1f, 0x530 <tail_icmp6_send_time_exceeded+0x530>
     31c:      	ldp	x9, x8, [sp, #0x8]
     320:      	add	w1, w20, #0x8
     324:      	add	x2, sp, #0x80
     328:      	mov	x0, x19
     32c:      	mov	w3, #0x10               // =16
     330:      	stp	x8, x9, [sp, #0xa0]
     334:      	adrp	x8, 0x0 <tail_icmp6_send_time_exceeded>
     338:      	ldr	x8, [x8]
     33c:      	ldr	x8, [x8]
     340:      	str	x8, [sp, #0x90]
     344:      	mov	w8, #0x1a               // =26
     348:      	blr	x8
     34c:      	tbnz	w0, #0x1f, 0x490 <tail_icmp6_send_time_exceeded+0x490>
     350:      	mov	w8, #0x1a               // =26
     354:      	add	w1, w20, #0x18
     358:      	add	x2, sp, #0x70
     35c:      	mov	x0, x19
     360:      	mov	w3, #0x10               // =16
     364:      	blr	x8
     368:      	tbnz	w0, #0x1f, 0x490 <tail_icmp6_send_time_exceeded+0x490>
     36c:      	mov	w8, #0x9                // =9
     370:      	add	w1, w20, #0x8
     374:      	add	x2, sp, #0xa0
     378:      	mov	x0, x19
     37c:      	mov	w3, #0x10               // =16
     380:      	mov	w4, wzr
     384:      	blr	x8
     388:      	tbnz	w0, #0x1f, 0x498 <tail_icmp6_send_time_exceeded+0x498>
     38c:      	mov	w8, #0x9                // =9
     390:      	add	w1, w20, #0x18
     394:      	add	x2, sp, #0x80
     398:      	mov	x0, x19
     39c:      	mov	w3, #0x10               // =16
     3a0:      	mov	w4, wzr
     3a4:      	blr	x8
     3a8:      	tbnz	w0, #0x1f, 0x498 <tail_icmp6_send_time_exceeded+0x498>
     3ac:      	mov	w8, #0x1c               // =28
     3b0:      	add	x0, sp, #0x80
     3b4:      	add	x2, sp, #0xa0
     3b8:      	mov	w1, #0x10               // =16
     3bc:      	mov	w3, #0x10               // =16
     3c0:      	mov	w4, wzr
     3c4:      	blr	x8
     3c8:      	mov	w3, w0
     3cc:      	mov	w8, #0xb                // =11
     3d0:      	add	w1, w20, #0x2a
     3d4:      	mov	x0, x19
     3d8:      	mov	w2, wzr
     3dc:      	mov	w4, #0x10               // =16
     3e0:      	blr	x8
     3e4:      	tbnz	w0, #0x1f, 0x530 <tail_icmp6_send_time_exceeded+0x530>
     3e8:      	mov	w8, #0x1c               // =28
     3ec:      	add	x0, sp, #0x70
     3f0:      	add	x2, sp, #0x80
     3f4:      	mov	w1, #0x10               // =16
     3f8:      	mov	w3, #0x10               // =16
     3fc:      	mov	w4, wzr
     400:      	blr	x8
     404:      	mov	w3, w0
     408:      	mov	w8, #0xb                // =11
     40c:      	add	w1, w20, #0x2a
     410:      	mov	x0, x19
     414:      	mov	w2, wzr
     418:      	mov	w4, #0x10               // =16
     41c:      	blr	x8
     420:      	tbnz	w0, #0x1f, 0x530 <tail_icmp6_send_time_exceeded+0x530>
     424:      	mov	w8, #0x1a               // =26
     428:      	add	x2, sp, #0x98
     42c:      	mov	x0, x19
     430:      	mov	w1, #0x6                // =6
     434:      	mov	w3, #0x6                // =6
     438:      	blr	x8
     43c:      	tbnz	w0, #0x1f, 0x490 <tail_icmp6_send_time_exceeded+0x490>
     440:      	mov	w8, #0x9                // =9
     444:      	add	x2, sp, #0x98
     448:      	mov	x0, x19
     44c:      	mov	w1, wzr
     450:      	mov	w3, #0x6                // =6
     454:      	mov	w4, wzr
     458:      	blr	x8
     45c:      	tbnz	w0, #0x1f, 0x498 <tail_icmp6_send_time_exceeded+0x498>
     460:      	mov	w8, #0x9                // =9
     464:      	add	x2, sp, #0x90
     468:      	mov	x0, x19
     46c:      	mov	w1, #0x6                // =6
     470:      	mov	w3, #0x6                // =6
     474:      	mov	w4, wzr
     478:      	blr	x8
     47c:      	tbnz	w0, #0x1f, 0x498 <tail_icmp6_send_time_exceeded+0x498>
     480:      	ldr	x8, [x19, #0x10]
     484:      	cbz	x8, 0x538 <tail_icmp6_send_time_exceeded+0x538>
     488:      	ldr	w0, [x8, #0xe0]
     48c:      	b	0x53c <tail_icmp6_send_time_exceeded+0x53c>
     490:      	mov	w0, #-0x86              // =-134
     494:      	b	0x4a4 <tail_icmp6_send_time_exceeded+0x4a4>
     498:      	mov	w0, #-0x8d              // =-141
     49c:      	b	0x4a4 <tail_icmp6_send_time_exceeded+0x4a4>
     4a0:      	mov	w0, #-0x8e              // =-142
     4a4:      	cmp	w0, #0x0
     4a8:      	mov	x9, #0x1420000          // =21102592
     4ac:      	ldr	w19, [x19, #0x70]
     4b0:      	add	x1, sp, #0xa0
     4b4:      	cneg	w8, w0, mi
     4b8:      	movk	x9, #0x67, lsl #32
     4bc:      	adrp	x0, 0x0 <tail_icmp6_send_time_exceeded>
     4c0:      	str	x9, [sp, #0xa0]
     4c4:      	strb	w8, [sp, #0xa0]
     4c8:      	and	w8, w22, #0x3
     4cc:      	strb	w8, [sp, #0xa1]
     4d0:      	mov	w8, #0x1                // =1
     4d4:      	ldr	x0, [x0]
     4d8:      	blr	x8
     4dc:      	cbz	x0, 0x4f4 <tail_icmp6_send_time_exceeded+0x4f4>
     4e0:      	ldp	x8, x9, [x0]
     4e4:      	add	x8, x8, #0x1
     4e8:      	add	x9, x9, x19
     4ec:      	stp	x8, x9, [x0]
     4f0:      	b	0x518 <tail_icmp6_send_time_exceeded+0x518>
     4f4:      	mov	w8, #0x1                // =1
     4f8:      	adrp	x0, 0x0 <tail_icmp6_send_time_exceeded>
     4fc:      	add	x1, sp, #0xa0
     500:      	stp	x8, x19, [sp, #0x20]
     504:      	mov	w8, #0x2                // =2
     508:      	add	x2, sp, #0x20
     50c:      	mov	w3, wzr
     510:      	ldr	x0, [x0]
     514:      	blr	x8
     518:      	mov	w0, #0x2                // =2
     51c:      	ldp	x20, x19, [sp, #0xd0]
     520:      	ldp	x22, x21, [sp, #0xc0]
     524:      	ldp	x30, x23, [sp, #0xb0]
     528:      	add	sp, sp, #0xe0
     52c:      	ret
     530:      	mov	w0, #-0x9a              // =-154
     534:      	b	0x4a4 <tail_icmp6_send_time_exceeded+0x4a4>
     538:      	mov	w0, wzr
     53c:      	mov	w8, #0x17               // =23
     540:      	mov	w1, wzr
     544:      	blr	x8
     548:      	tbnz	w0, #0x1f, 0x4a4 <tail_icmp6_send_time_exceeded+0x4a4>
     54c:      	cmp	w0, #0x2
     550:      	b.ne	0x51c <tail_icmp6_send_time_exceeded+0x51c>
     554:      	b	0x4a4 <tail_icmp6_send_time_exceeded+0x4a4>
     558:      	nop
     55c:      	nop

0000000000000560 <tail_icmp6_handle_ns>:
     560:      	sub	sp, sp, #0x100
     564:      	str	x30, [sp, #0xc0]
     568:      	stp	x24, x23, [sp, #0xd0]
     56c:      	stp	x22, x21, [sp, #0xe0]
     570:      	stp	x20, x19, [sp, #0xf0]
     574:      	ldp	w23, w22, [x0, #0x30]
     578:      	str	wzr, [x0, #0x30]
     57c:      	adrp	x8, 0x0 <tail_icmp6_send_time_exceeded>
     580:      	adrp	x24, 0x0 <tail_icmp6_send_time_exceeded>
     584:      	add	x2, sp, #0x38
     588:      	mov	w3, #0x10               // =16
     58c:      	ldr	x8, [x8]
     590:      	mov	x19, x0
     594:      	add	x21, sp, #0x98
     598:      	ldr	x9, [x8]
     59c:      	add	w1, w23, #0x30
     5a0:      	str	x9, [sp, #0x30]
     5a4:      	ldr	x8, [x8, #0x8]
     5a8:      	str	x8, [sp, #0x28]
     5ac:      	ldr	x24, [x24]
     5b0:      	ldrb	w8, [x24]
     5b4:      	strb	w8, [sp, #0x20]
     5b8:      	ldrb	w8, [x24, #0x1]
     5bc:      	strb	w8, [sp, #0x1c]
     5c0:      	ldrb	w8, [x24, #0x2]
     5c4:      	strb	w8, [sp, #0x18]
     5c8:      	ldrb	w8, [x24, #0x3]
     5cc:      	strb	w8, [sp, #0x14]
     5d0:      	ldrb	w8, [x24, #0x4]
     5d4:      	strb	w8, [sp, #0x10]
     5d8:      	ldrb	w8, [x24, #0x5]
     5dc:      	strb	w8, [sp, #0xc]
     5e0:      	ldrh	w8, [x24, #0x6]
     5e4:      	strh	w8, [sp, #0xa]
     5e8:      	mov	w8, #0x1a               // =26
     5ec:      	blr	x8
     5f0:      	tbnz	w0, #0x1f, 0xbd4 <tail_icmp6_handle_ns+0x674>
     5f4:      	ldp	x9, x8, [sp, #0x30]
     5f8:      	cmp	x8, x9
     5fc:      	b.ne	0x8d8 <tail_icmp6_handle_ns+0x378>
     600:      	ldr	x8, [sp, #0x40]
     604:      	ldr	x9, [sp, #0x28]
     608:      	cmp	x8, x9
     60c:      	b.ne	0x8d8 <tail_icmp6_handle_ns+0x378>
     610:      	mov	x8, #0x88               // =136
     614:      	add	w1, w23, #0x40
     618:      	add	x2, sp, #0x58
     61c:      	mov	x0, x19
     620:      	mov	w3, #0x8                // =8
     624:      	movk	x8, #0xc0, lsl #32
     628:      	str	x8, [sp, #0x70]
     62c:      	mov	w8, #0x1a               // =26
     630:      	blr	x8
     634:      	tbnz	w0, #0x1f, 0xc80 <tail_icmp6_handle_ns+0x720>
     638:      	mov	w20, wzr
     63c:      	mov	w8, #0x1a               // =26
     640:      	add	w1, w23, #0x28
     644:      	add	x2, sp, #0x68
     648:      	mov	x0, x19
     64c:      	mov	w3, #0x8                // =8
     650:      	blr	x8
     654:      	tbnz	w0, #0x1f, 0xd3c <tail_icmp6_handle_ns+0x7dc>
     658:      	ldrh	w8, [sp, #0x6a]
     65c:      	add	w1, w23, #0x30
     660:      	add	x2, sp, #0x48
     664:      	mov	x0, x19
     668:      	strh	w8, [sp, #0x72]
     66c:      	mov	w8, #0x1a               // =26
     670:      	mov	w3, #0x10               // =16
     674:      	blr	x8
     678:      	tbnz	w0, #0x1f, 0xc78 <tail_icmp6_handle_ns+0x718>
     67c:      	mov	w8, #0x9                // =9
     680:      	add	w1, w23, #0x28
     684:      	add	x2, sp, #0x70
     688:      	mov	x0, x19
     68c:      	mov	w3, #0x8                // =8
     690:      	mov	w4, wzr
     694:      	blr	x8
     698:      	tbnz	w0, #0x1f, 0xc78 <tail_icmp6_handle_ns+0x718>
     69c:      	mov	w8, #0x1c               // =28
     6a0:      	add	x0, sp, #0x68
     6a4:      	add	x2, sp, #0x70
     6a8:      	mov	w1, #0x8                // =8
     6ac:      	mov	w3, #0x8                // =8
     6b0:      	mov	w4, w20
     6b4:      	blr	x8
     6b8:      	mov	w8, #0x1a               // =26
     6bc:      	mov	w20, w0
     6c0:      	add	w1, w23, #0x40
     6c4:      	add	x2, sp, #0x58
     6c8:      	mov	x0, x19
     6cc:      	mov	w3, #0x8                // =8
     6d0:      	blr	x8
     6d4:      	tbnz	w0, #0x1f, 0xd3c <tail_icmp6_handle_ns+0x7dc>
     6d8:      	mov	w8, #0x102              // =258
     6dc:      	add	w1, w23, #0x40
     6e0:      	add	x2, sp, #0x60
     6e4:      	strh	w8, [sp, #0x60]
     6e8:      	ldrb	w8, [sp, #0x20]
     6ec:      	mov	x0, x19
     6f0:      	mov	w3, #0x8                // =8
     6f4:      	mov	w4, wzr
     6f8:      	strb	w8, [sp, #0x62]
     6fc:      	ldrb	w8, [sp, #0x1c]
     700:      	strb	w8, [sp, #0x63]
     704:      	ldrb	w8, [sp, #0x18]
     708:      	strb	w8, [sp, #0x64]
     70c:      	ldrb	w8, [sp, #0x14]
     710:      	strb	w8, [sp, #0x65]
     714:      	ldrb	w8, [sp, #0x10]
     718:      	strb	w8, [sp, #0x66]
     71c:      	ldrb	w8, [sp, #0xc]
     720:      	strb	w8, [sp, #0x67]
     724:      	mov	w8, #0x9                // =9
     728:      	blr	x8
     72c:      	tbnz	w0, #0x1f, 0xc78 <tail_icmp6_handle_ns+0x718>
     730:      	mov	w8, #0x1c               // =28
     734:      	add	x0, sp, #0x58
     738:      	add	x2, sp, #0x60
     73c:      	mov	w1, #0x8                // =8
     740:      	mov	w3, #0x8                // =8
     744:      	mov	w4, w20
     748:      	blr	x8
     74c:      	mov	w3, w0
     750:      	mov	w8, #0xb                // =11
     754:      	add	w1, w23, #0x2a
     758:      	mov	x0, x19
     75c:      	mov	w2, wzr
     760:      	mov	w4, #0x10               // =16
     764:      	blr	x8
     768:      	tbnz	w0, #0x1f, 0xd70 <tail_icmp6_handle_ns+0x810>
     76c:      	ldp	x8, x9, [sp, #0x48]
     770:      	add	w1, w23, #0x8
     774:      	add	x2, sp, #0x88
     778:      	mov	x0, x19
     77c:      	mov	w3, #0x10               // =16
     780:      	stp	x8, x9, [x21, #0x10]
     784:      	ldr	x8, [x24]
     788:      	str	x8, [x21]
     78c:      	mov	w8, #0x1a               // =26
     790:      	blr	x8
     794:      	tbnz	w0, #0x1f, 0xd3c <tail_icmp6_handle_ns+0x7dc>
     798:      	mov	w8, #0x1a               // =26
     79c:      	add	w1, w23, #0x18
     7a0:      	add	x2, sp, #0x78
     7a4:      	mov	x0, x19
     7a8:      	mov	w3, #0x10               // =16
     7ac:      	blr	x8
     7b0:      	tbnz	w0, #0x1f, 0xd3c <tail_icmp6_handle_ns+0x7dc>
     7b4:      	mov	w8, #0x9                // =9
     7b8:      	add	w1, w23, #0x8
     7bc:      	add	x2, sp, #0xa8
     7c0:      	mov	x0, x19
     7c4:      	mov	w3, #0x10               // =16
     7c8:      	mov	w4, wzr
     7cc:      	blr	x8
     7d0:      	tbnz	w0, #0x1f, 0xc78 <tail_icmp6_handle_ns+0x718>
     7d4:      	mov	w8, #0x9                // =9
     7d8:      	add	w1, w23, #0x18
     7dc:      	add	x2, sp, #0x88
     7e0:      	mov	x0, x19
     7e4:      	mov	w3, #0x10               // =16
     7e8:      	mov	w4, wzr
     7ec:      	blr	x8
     7f0:      	tbnz	w0, #0x1f, 0xc78 <tail_icmp6_handle_ns+0x718>
     7f4:      	mov	w8, #0x1c               // =28
     7f8:      	add	x0, sp, #0x88
     7fc:      	add	x2, sp, #0xa8
     800:      	mov	w1, #0x10               // =16
     804:      	mov	w3, #0x10               // =16
     808:      	mov	w4, wzr
     80c:      	blr	x8
     810:      	mov	w3, w0
     814:      	mov	w8, #0xb                // =11
     818:      	add	w1, w23, #0x2a
     81c:      	mov	x0, x19
     820:      	mov	w2, wzr
     824:      	mov	w4, #0x10               // =16
     828:      	blr	x8
     82c:      	tbnz	w0, #0x1f, 0xd70 <tail_icmp6_handle_ns+0x810>
     830:      	mov	w8, #0x1c               // =28
     834:      	add	x0, sp, #0x78
     838:      	add	x2, sp, #0x88
     83c:      	mov	w1, #0x10               // =16
     840:      	mov	w3, #0x10               // =16
     844:      	mov	w4, wzr
     848:      	blr	x8
     84c:      	mov	w3, w0
     850:      	mov	w8, #0xb                // =11
     854:      	add	w1, w23, #0x2a
     858:      	mov	x0, x19
     85c:      	mov	w2, wzr
     860:      	mov	w4, #0x10               // =16
     864:      	blr	x8
     868:      	tbnz	w0, #0x1f, 0xd70 <tail_icmp6_handle_ns+0x810>
     86c:      	mov	w8, #0x1a               // =26
     870:      	add	x2, sp, #0xa0
     874:      	mov	x0, x19
     878:      	mov	w1, #0x6                // =6
     87c:      	mov	w3, #0x6                // =6
     880:      	blr	x8
     884:      	tbnz	w0, #0x1f, 0xd3c <tail_icmp6_handle_ns+0x7dc>
     888:      	mov	w8, #0x9                // =9
     88c:      	add	x2, sp, #0xa0
     890:      	mov	x0, x19
     894:      	mov	w1, wzr
     898:      	mov	w3, #0x6                // =6
     89c:      	mov	w4, wzr
     8a0:      	blr	x8
     8a4:      	tbnz	w0, #0x1f, 0xc78 <tail_icmp6_handle_ns+0x718>
     8a8:      	mov	w8, #0x9                // =9
     8ac:      	add	x2, sp, #0x98
     8b0:      	mov	x0, x19
     8b4:      	mov	w1, #0x6                // =6
     8b8:      	mov	w3, #0x6                // =6
     8bc:      	mov	w4, wzr
     8c0:      	blr	x8
     8c4:      	tbnz	w0, #0x1f, 0xc78 <tail_icmp6_handle_ns+0x718>
     8c8:      	ldr	x8, [x19, #0x10]
     8cc:      	cbz	x8, 0xd78 <tail_icmp6_handle_ns+0x818>
     8d0:      	ldr	w0, [x8, #0xe0]
     8d4:      	b	0xd7c <tail_icmp6_handle_ns+0x81c>
     8d8:      	ldp	x8, x9, [sp, #0x38]
     8dc:      	adrp	x0, 0x0 <tail_icmp6_send_time_exceeded>
     8e0:      	add	x1, sp, #0xa8
     8e4:      	str	wzr, [x21, #0x20]
     8e8:      	stp	x8, x9, [x21, #0x10]
     8ec:      	mov	w8, #0x2                // =2
     8f0:      	strb	w8, [sp, #0xb8]
     8f4:      	mov	w8, #0x1                // =1
     8f8:      	ldr	x0, [x0]
     8fc:      	blr	x8
     900:      	cbz	x0, 0xbdc <tail_icmp6_handle_ns+0x67c>
     904:      	ldrb	w8, [x0, #0x8]
     908:      	tbnz	w8, #0x0, 0xc70 <tail_icmp6_handle_ns+0x710>
     90c:      	mov	x8, #0x88               // =136
     910:      	add	w1, w23, #0x40
     914:      	add	x2, sp, #0x58
     918:      	mov	x0, x19
     91c:      	mov	w3, #0x8                // =8
     920:      	movk	x8, #0x60, lsl #32
     924:      	str	x8, [sp, #0x70]
     928:      	mov	w8, #0x1a               // =26
     92c:      	blr	x8
     930:      	tbnz	w0, #0x1f, 0xce4 <tail_icmp6_handle_ns+0x784>
     934:      	mov	w20, wzr
     938:      	mov	w8, #0x1a               // =26
     93c:      	add	w1, w23, #0x28
     940:      	add	x2, sp, #0x68
     944:      	mov	x0, x19
     948:      	mov	w3, #0x8                // =8
     94c:      	blr	x8
     950:      	tbnz	w0, #0x1f, 0xd3c <tail_icmp6_handle_ns+0x7dc>
     954:      	ldrh	w8, [sp, #0x6a]
     958:      	add	w1, w23, #0x30
     95c:      	add	x2, sp, #0x48
     960:      	mov	x0, x19
     964:      	strh	w8, [sp, #0x72]
     968:      	mov	w8, #0x1a               // =26
     96c:      	mov	w3, #0x10               // =16
     970:      	blr	x8
     974:      	tbnz	w0, #0x1f, 0xc78 <tail_icmp6_handle_ns+0x718>
     978:      	mov	w8, #0x9                // =9
     97c:      	add	w1, w23, #0x28
     980:      	add	x2, sp, #0x70
     984:      	mov	x0, x19
     988:      	mov	w3, #0x8                // =8
     98c:      	mov	w4, wzr
     990:      	blr	x8
     994:      	tbnz	w0, #0x1f, 0xc78 <tail_icmp6_handle_ns+0x718>
     998:      	mov	w8, #0x1c               // =28
     99c:      	add	x0, sp, #0x68
     9a0:      	add	x2, sp, #0x70
     9a4:      	mov	w1, #0x8                // =8
     9a8:      	mov	w3, #0x8                // =8
     9ac:      	mov	w4, w20
     9b0:      	blr	x8
     9b4:      	mov	w8, #0x1a               // =26
     9b8:      	mov	w20, w0
     9bc:      	add	w1, w23, #0x40
     9c0:      	add	x2, sp, #0x58
     9c4:      	mov	x0, x19
     9c8:      	mov	w3, #0x8                // =8
     9cc:      	blr	x8
     9d0:      	tbnz	w0, #0x1f, 0xd3c <tail_icmp6_handle_ns+0x7dc>
     9d4:      	mov	w8, #0x102              // =258
     9d8:      	add	w1, w23, #0x40
     9dc:      	add	x2, sp, #0x60
     9e0:      	strh	w8, [sp, #0x60]
     9e4:      	ldrb	w8, [sp, #0x20]
     9e8:      	mov	x0, x19
     9ec:      	mov	w3, #0x8                // =8
     9f0:      	mov	w4, wzr
     9f4:      	strb	w8, [sp, #0x62]
     9f8:      	ldrb	w8, [sp, #0x1c]
     9fc:      	strb	w8, [sp, #0x63]
     a00:      	ldrb	w8, [sp, #0x18]
     a04:      	strb	w8, [sp, #0x64]
     a08:      	ldrb	w8, [sp, #0x14]
     a0c:      	strb	w8, [sp, #0x65]
     a10:      	ldrb	w8, [sp, #0x10]
     a14:      	strb	w8, [sp, #0x66]
     a18:      	ldrb	w8, [sp, #0xc]
     a1c:      	strb	w8, [sp, #0x67]
     a20:      	mov	w8, #0x9                // =9
     a24:      	blr	x8
     a28:      	tbnz	w0, #0x1f, 0xc78 <tail_icmp6_handle_ns+0x718>
     a2c:      	mov	w8, #0x1c               // =28
     a30:      	add	x0, sp, #0x58
     a34:      	add	x2, sp, #0x60
     a38:      	mov	w1, #0x8                // =8
     a3c:      	mov	w3, #0x8                // =8
     a40:      	mov	w4, w20
     a44:      	blr	x8
     a48:      	mov	w3, w0
     a4c:      	mov	w8, #0xb                // =11
     a50:      	add	w1, w23, #0x2a
     a54:      	mov	x0, x19
     a58:      	mov	w2, wzr
     a5c:      	mov	w4, #0x10               // =16
     a60:      	blr	x8
     a64:      	tbnz	w0, #0x1f, 0xd70 <tail_icmp6_handle_ns+0x810>
     a68:      	ldp	x8, x9, [sp, #0x48]
     a6c:      	add	w1, w23, #0x8
     a70:      	add	x2, sp, #0x88
     a74:      	mov	x0, x19
     a78:      	mov	w3, #0x10               // =16
     a7c:      	stp	x8, x9, [x21, #0x10]
     a80:      	ldr	x8, [x24]
     a84:      	str	x8, [x21]
     a88:      	mov	w8, #0x1a               // =26
     a8c:      	blr	x8
     a90:      	tbnz	w0, #0x1f, 0xd3c <tail_icmp6_handle_ns+0x7dc>
     a94:      	mov	w8, #0x1a               // =26
     a98:      	add	w1, w23, #0x18
     a9c:      	add	x2, sp, #0x78
     aa0:      	mov	x0, x19
     aa4:      	mov	w3, #0x10               // =16
     aa8:      	blr	x8
     aac:      	tbnz	w0, #0x1f, 0xd3c <tail_icmp6_handle_ns+0x7dc>
     ab0:      	mov	w8, #0x9                // =9
     ab4:      	add	w1, w23, #0x8
     ab8:      	add	x2, sp, #0xa8
     abc:      	mov	x0, x19
     ac0:      	mov	w3, #0x10               // =16
     ac4:      	mov	w4, wzr
     ac8:      	blr	x8
     acc:      	tbnz	w0, #0x1f, 0xc78 <tail_icmp6_handle_ns+0x718>
     ad0:      	mov	w8, #0x9                // =9
     ad4:      	add	w1, w23, #0x18
     ad8:      	add	x2, sp, #0x88
     adc:      	mov	x0, x19
     ae0:      	mov	w3, #0x10               // =16
     ae4:      	mov	w4, wzr
     ae8:      	blr	x8
     aec:      	tbnz	w0, #0x1f, 0xc78 <tail_icmp6_handle_ns+0x718>
     af0:      	mov	w8, #0x1c               // =28
     af4:      	add	x0, sp, #0x88
     af8:      	add	x2, sp, #0xa8
     afc:      	mov	w1, #0x10               // =16
     b00:      	mov	w3, #0x10               // =16
     b04:      	mov	w4, wzr
     b08:      	blr	x8
     b0c:      	mov	w3, w0
     b10:      	mov	w8, #0xb                // =11
     b14:      	add	w1, w23, #0x2a
     b18:      	mov	x0, x19
     b1c:      	mov	w2, wzr
     b20:      	mov	w4, #0x10               // =16
     b24:      	blr	x8
     b28:      	tbnz	w0, #0x1f, 0xd70 <tail_icmp6_handle_ns+0x810>
     b2c:      	mov	w8, #0x1c               // =28
     b30:      	add	x0, sp, #0x78
     b34:      	add	x2, sp, #0x88
     b38:      	mov	w1, #0x10               // =16
     b3c:      	mov	w3, #0x10               // =16
     b40:      	mov	w4, wzr
     b44:      	blr	x8
     b48:      	mov	w3, w0
     b4c:      	mov	w8, #0xb                // =11
     b50:      	add	w1, w23, #0x2a
     b54:      	mov	x0, x19
     b58:      	mov	w2, wzr
     b5c:      	mov	w4, #0x10               // =16
     b60:      	blr	x8
     b64:      	tbnz	w0, #0x1f, 0xd70 <tail_icmp6_handle_ns+0x810>
     b68:      	mov	w8, #0x1a               // =26
     b6c:      	add	x2, sp, #0xa0
     b70:      	mov	x0, x19
     b74:      	mov	w1, #0x6                // =6
     b78:      	mov	w3, #0x6                // =6
     b7c:      	blr	x8
     b80:      	tbnz	w0, #0x1f, 0xd3c <tail_icmp6_handle_ns+0x7dc>
     b84:      	mov	w8, #0x9                // =9
     b88:      	add	x2, sp, #0xa0
     b8c:      	mov	x0, x19
     b90:      	mov	w1, wzr
     b94:      	mov	w3, #0x6                // =6
     b98:      	mov	w4, wzr
     b9c:      	blr	x8
     ba0:      	tbnz	w0, #0x1f, 0xc78 <tail_icmp6_handle_ns+0x718>
     ba4:      	mov	w8, #0x9                // =9
     ba8:      	add	x2, sp, #0x98
     bac:      	mov	x0, x19
     bb0:      	mov	w1, #0x6                // =6
     bb4:      	mov	w3, #0x6                // =6
     bb8:      	mov	w4, wzr
     bbc:      	blr	x8
     bc0:      	tbnz	w0, #0x1f, 0xc78 <tail_icmp6_handle_ns+0x718>
     bc4:      	ldr	x8, [x19, #0x10]
     bc8:      	cbz	x8, 0xd84 <tail_icmp6_handle_ns+0x824>
     bcc:      	ldr	w0, [x8, #0xe0]
     bd0:      	b	0xd88 <tail_icmp6_handle_ns+0x828>
     bd4:      	mov	w0, #-0x86              // =-134
     bd8:      	b	0xbe0 <tail_icmp6_handle_ns+0x680>
     bdc:      	mov	w0, #-0x96              // =-150
     be0:      	cmp	w0, #0x0
     be4:      	mov	x9, #0x1960000          // =26607616
     be8:      	ldr	w19, [x19, #0x70]
     bec:      	add	x1, sp, #0x88
     bf0:      	cneg	w8, w0, mi
     bf4:      	movk	x9, #0x67, lsl #32
     bf8:      	adrp	x0, 0x0 <tail_icmp6_send_time_exceeded>
     bfc:      	str	x9, [sp, #0x88]
     c00:      	strb	w8, [sp, #0x88]
     c04:      	and	w8, w22, #0x3
     c08:      	strb	w8, [sp, #0x89]
     c0c:      	mov	w8, #0x1                // =1
     c10:      	ldr	x0, [x0]
     c14:      	blr	x8
     c18:      	cbz	x0, 0xc30 <tail_icmp6_handle_ns+0x6d0>
     c1c:      	ldp	x8, x9, [x0]
     c20:      	add	x8, x8, #0x1
     c24:      	add	x9, x9, x19
     c28:      	stp	x8, x9, [x0]
     c2c:      	b	0xc54 <tail_icmp6_handle_ns+0x6f4>
     c30:      	mov	w8, #0x1                // =1
     c34:      	adrp	x0, 0x0 <tail_icmp6_send_time_exceeded>
     c38:      	add	x1, sp, #0x88
     c3c:      	stp	x8, x19, [x21, #0x10]
     c40:      	mov	w8, #0x2                // =2
     c44:      	add	x2, sp, #0xa8
     c48:      	mov	w3, wzr
     c4c:      	ldr	x0, [x0]
     c50:      	blr	x8
     c54:      	mov	w0, #0x2                // =2
     c58:      	ldp	x20, x19, [sp, #0xf0]
     c5c:      	ldr	x30, [sp, #0xc0]
     c60:      	ldp	x22, x21, [sp, #0xe0]
     c64:      	ldp	x24, x23, [sp, #0xd0]
     c68:      	add	sp, sp, #0x100
     c6c:      	ret
     c70:      	mov	w0, wzr
     c74:      	b	0xd40 <tail_icmp6_handle_ns+0x7e0>
     c78:      	mov	w0, #-0x8d              // =-141
     c7c:      	b	0xd40 <tail_icmp6_handle_ns+0x7e0>
     c80:      	mov	w8, #0x26               // =38
     c84:      	mov	x0, x19
     c88:      	mov	w2, wzr
     c8c:      	ldr	w9, [x19, #0x70]
     c90:      	add	w1, w9, #0x8
     c94:      	blr	x8
     c98:      	tbnz	w0, #0x1f, 0xd3c <tail_icmp6_handle_ns+0x7dc>
     c9c:      	ldr	x8, [x19, #0xd0]
     ca0:      	ldr	x9, [x19, #0x50]
     ca4:      	add	x10, x8, #0x36
     ca8:      	cmp	x10, x9
     cac:      	b.hi	0xd3c <tail_icmp6_handle_ns+0x7dc>
     cb0:      	ldrh	w10, [x8, #0x12]
     cb4:      	rev	w10, w10
     cb8:      	lsr	w10, w10, #16
     cbc:      	add	w10, w10, #0x8
     cc0:      	rev	w10, w10
     cc4:      	lsr	w10, w10, #16
     cc8:      	strh	w10, [x8, #0x12]
     ccc:      	add	x10, x8, #0x56
     cd0:      	cmp	x10, x9
     cd4:      	b.hi	0xd3c <tail_icmp6_handle_ns+0x7dc>
     cd8:      	mov	w20, #0x8000000         // =134217728
     cdc:      	stur	xzr, [x8, #0x4e]
     ce0:      	b	0x63c <tail_icmp6_handle_ns+0xdc>
     ce4:      	mov	w8, #0x26               // =38
     ce8:      	mov	x0, x19
     cec:      	mov	w2, wzr
     cf0:      	ldr	w9, [x19, #0x70]
     cf4:      	add	w1, w9, #0x8
     cf8:      	blr	x8
     cfc:      	tbnz	w0, #0x1f, 0xd3c <tail_icmp6_handle_ns+0x7dc>
     d00:      	ldr	x8, [x19, #0xd0]
     d04:      	ldr	x9, [x19, #0x50]
     d08:      	add	x10, x8, #0x36
     d0c:      	cmp	x10, x9
     d10:      	b.hi	0xd3c <tail_icmp6_handle_ns+0x7dc>
     d14:      	ldrh	w10, [x8, #0x12]
     d18:      	rev	w10, w10
     d1c:      	lsr	w10, w10, #16
     d20:      	add	w10, w10, #0x8
     d24:      	rev	w10, w10
     d28:      	lsr	w10, w10, #16
     d2c:      	strh	w10, [x8, #0x12]
     d30:      	add	x10, x8, #0x56
     d34:      	cmp	x10, x9
     d38:      	b.ls	0xd64 <tail_icmp6_handle_ns+0x804>
     d3c:      	mov	w0, #-0x86              // =-134
     d40:      	tbnz	w0, #0x1f, 0xbe0 <tail_icmp6_handle_ns+0x680>
     d44:      	cmp	w0, #0x2
     d48:      	b.eq	0xbe0 <tail_icmp6_handle_ns+0x680>
     d4c:      	ldp	x20, x19, [sp, #0xf0]
     d50:      	ldr	x30, [sp, #0xc0]
     d54:      	ldp	x22, x21, [sp, #0xe0]
     d58:      	ldp	x24, x23, [sp, #0xd0]
     d5c:      	add	sp, sp, #0x100
     d60:      	ret
     d64:      	mov	w20, #0x8000000         // =134217728
     d68:      	stur	xzr, [x8, #0x4e]
     d6c:      	b	0x938 <tail_icmp6_handle_ns+0x3d8>
     d70:      	mov	w0, #-0x9a              // =-154
     d74:      	b	0xd40 <tail_icmp6_handle_ns+0x7e0>
     d78:      	mov	w0, wzr
     d7c:      	mov	w8, #0x17               // =23
     d80:      	b	0xd8c <tail_icmp6_handle_ns+0x82c>
     d84:      	mov	w0, wzr
     d88:      	mov	w8, #0x17               // =23
     d8c:      	mov	w1, wzr
     d90:      	blr	x8
     d94:      	b	0xd40 <tail_icmp6_handle_ns+0x7e0>
