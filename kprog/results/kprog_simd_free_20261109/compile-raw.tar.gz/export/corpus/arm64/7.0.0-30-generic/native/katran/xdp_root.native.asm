
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/katran/xdp_root.native.o:	file format elf64-littleaarch64

Disassembly of section xdp:

0000000000000000 <xdp_root>:
       0:      	stp	x30, x21, [sp, #-0x20]!
       4:      	stp	x20, x19, [sp, #0x10]
       8:      	adrp	x20, 0x0 <xdp_root>
       c:      	mov	w21, #0xc               // =12
      10:      	mov	w2, wzr
      14:      	ldr	x20, [x20]
      18:      	mov	x19, x0
      1c:      	mov	x1, x20
      20:      	blr	x21
      24:      	mov	x0, x19
      28:      	mov	x1, x20
      2c:      	mov	w2, #0x1                // =1
      30:      	blr	x21
      34:      	mov	x0, x19
      38:      	mov	x1, x20
      3c:      	mov	w2, #0x2                // =2
      40:      	blr	x21
      44:      	ldp	x20, x19, [sp, #0x10]
      48:      	mov	w0, #0x2                // =2
      4c:      	ldp	x30, x21, [sp], #0x20
      50:      	ret
