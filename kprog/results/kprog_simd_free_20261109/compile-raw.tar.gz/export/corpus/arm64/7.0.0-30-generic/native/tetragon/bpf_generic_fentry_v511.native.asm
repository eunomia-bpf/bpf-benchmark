
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_fentry_v511.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	cbz	x2, 0x8c <native_bpf_strncasestr+0x8c>
       4:      	mov	x8, x0
       8:      	mov	x0, xzr
       c:      	mov	x9, x2
      10:      	b	0x34 <native_bpf_strncasestr+0x34>
      14:      	nop
      18:      	nop
      1c:      	nop
      20:      	add	x0, x0, #0x1
      24:      	sub	x9, x9, #0x1
      28:      	add	x8, x8, #0x1
      2c:      	cmp	x0, x2
      30:      	b.eq	0x8c <native_bpf_strncasestr+0x8c>
      34:      	mov	x10, xzr
      38:      	nop
      3c:      	nop
      40:      	cmp	x9, x10
      44:      	b.eq	0x20 <native_bpf_strncasestr+0x20>
      48:      	ldrb	w11, [x1, x10]
      4c:      	cbz	w11, 0x90 <native_bpf_strncasestr+0x90>
      50:      	ldrb	w12, [x8, x10]
      54:      	sub	w13, w12, #0x41
      58:      	orr	w14, w12, #0x20
      5c:      	cmp	w13, #0x1a
      60:      	sub	w13, w11, #0x41
      64:      	csel	w12, w14, w12, lo
      68:      	orr	w14, w11, #0x20
      6c:      	cmp	w13, #0x1a
      70:      	csel	w11, w14, w11, lo
      74:      	cmp	w12, w11
      78:      	b.ne	0x20 <native_bpf_strncasestr+0x20>
      7c:      	cmp	x10, #0x63
      80:      	add	x10, x10, #0x1
      84:      	b.lo	0x40 <native_bpf_strncasestr+0x40>
      88:      	b	0x20 <native_bpf_strncasestr+0x20>
      8c:      	mov	w0, #-0x1               // =-1
      90:      	ret

Disassembly of section fentry/generic_fentry_tail:

0000000000000000 <generic_fentry_setup_event>:
       0:      	sub	sp, sp, #0x90
       4:      	str	x29, [sp, #0x40]
       8:      	stp	x30, x25, [sp, #0x50]
       c:      	stp	x24, x23, [sp, #0x60]
      10:      	stp	x22, x21, [sp, #0x70]
      14:      	stp	x20, x19, [sp, #0x80]
      18:      	str	wzr, [sp, #0x48]
      1c:      	adrp	x20, 0x0 <generic_fentry_setup_event>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x48
      28:      	ldr	x20, [x20]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0x48
      34:      	mov	x0, x20
      38:      	blr	x8
      3c:      	cbz	x0, 0x368 <generic_fentry_setup_event+0x368>
      40:      	adrp	x21, 0x0 <generic_fentry_setup_event>
      44:      	mov	w8, #0x5ef8             // =24312
      48:      	mov	x22, x0
      4c:      	ldr	x21, [x21]
      50:      	add	x1, x0, x8
      54:      	mov	w8, #0x1                // =1
      58:      	mov	x0, x21
      5c:      	blr	x8
      60:      	cbz	x0, 0x368 <generic_fentry_setup_event+0x368>
      64:      	ldr	w8, [x0, #0x54]
      68:      	mov	x23, x0
      6c:      	cbz	w8, 0x128 <generic_fentry_setup_event+0x128>
      70:      	mov	w8, #0x8                // =8
      74:      	mov	w9, #0x4                // =4
      78:      	add	x10, sp, #0x18
      7c:      	add	x0, sp, #0x18
      80:      	mov	w1, #0x8                // =8
      84:      	mov	x2, x19
      88:      	blr	x9
      8c:      	ldr	x25, [sp, #0x18]
      90:      	cbz	x25, 0x368 <generic_fentry_setup_event+0x368>
      94:      	add	x2, x25, #0x110
      98:      	mov	w29, #0x8               // =8
      9c:      	add	x8, sp, #0x18
      a0:      	mov	w9, #0x4                // =4
      a4:      	add	x0, sp, #0x18
      a8:      	mov	w1, #0x8                // =8
      ac:      	mov	w24, #0x4               // =4
      b0:      	blr	x9
      b4:      	ldr	x8, [sp, #0x18]
      b8:      	add	x2, x25, #0x8
      bc:      	mov	w9, #0x4                // =4
      c0:      	add	x0, sp, #0x18
      c4:      	str	x8, [x22, #0x5e50]
      c8:      	add	x8, sp, #0x18
      cc:      	mov	w1, #0x8                // =8
      d0:      	blr	x9
      d4:      	ldr	x8, [sp, #0x18]
      d8:      	add	x2, x25, #0x10
      dc:      	mov	w9, #0x4                // =4
      e0:      	add	x0, sp, #0x18
      e4:      	str	x8, [x22, #0x5e58]
      e8:      	add	x8, sp, #0x18
      ec:      	mov	w1, #0x8                // =8
      f0:      	blr	x9
      f4:      	ldr	x8, [sp, #0x18]
      f8:      	add	x2, x25, #0x18
      fc:      	mov	w9, #0x4                // =4
     100:      	add	x0, sp, #0x18
     104:      	str	x8, [x22, #0x5e60]
     108:      	add	x8, sp, #0x18
     10c:      	mov	w1, #0x8                // =8
     110:      	blr	x9
     114:      	ldr	x8, [sp, #0x18]
     118:      	add	x2, x25, #0x20
     11c:      	str	x8, [x22, #0x5e68]
     120:      	add	x8, sp, #0x18
     124:      	b	0x1b8 <generic_fentry_setup_event+0x1b8>
     128:      	mov	w25, #0x8               // =8
     12c:      	add	x8, sp, #0x18
     130:      	mov	w9, #0x4                // =4
     134:      	add	x0, sp, #0x18
     138:      	mov	w1, #0x8                // =8
     13c:      	mov	x2, x19
     140:      	mov	w24, #0x4               // =4
     144:      	blr	x9
     148:      	ldr	x8, [sp, #0x18]
     14c:      	add	x2, x19, #0x8
     150:      	mov	w9, #0x4                // =4
     154:      	add	x0, sp, #0x18
     158:      	str	x8, [x22, #0x5e50]
     15c:      	add	x8, sp, #0x18
     160:      	mov	w1, #0x8                // =8
     164:      	blr	x9
     168:      	ldr	x8, [sp, #0x18]
     16c:      	add	x2, x19, #0x10
     170:      	mov	w9, #0x4                // =4
     174:      	add	x0, sp, #0x18
     178:      	str	x8, [x22, #0x5e58]
     17c:      	add	x8, sp, #0x18
     180:      	mov	w1, #0x8                // =8
     184:      	blr	x9
     188:      	ldr	x8, [sp, #0x18]
     18c:      	add	x2, x19, #0x18
     190:      	mov	w9, #0x4                // =4
     194:      	add	x0, sp, #0x18
     198:      	str	x8, [x22, #0x5e60]
     19c:      	add	x8, sp, #0x18
     1a0:      	mov	w1, #0x8                // =8
     1a4:      	blr	x9
     1a8:      	ldr	x8, [sp, #0x18]
     1ac:      	add	x2, x19, #0x20
     1b0:      	str	x8, [x22, #0x5e68]
     1b4:      	add	x8, sp, #0x18
     1b8:      	add	x0, sp, #0x18
     1bc:      	mov	w1, #0x8                // =8
     1c0:      	blr	x24
     1c4:      	ldr	x8, [sp, #0x18]
     1c8:      	strh	wzr, [x22, #0x2]
     1cc:      	str	wzr, [x22, #0x4]
     1d0:      	str	x8, [x22, #0x5e70]
     1d4:      	mov	w8, #0xd                // =13
     1d8:      	strb	w8, [x22]
     1dc:      	mov	w8, #0x7d               // =125
     1e0:      	blr	x8
     1e4:      	str	x0, [x22, #0x8]
     1e8:      	str	xzr, [x22, #0x70]
     1ec:      	mov	w8, #0xe                // =14
     1f0:      	mov	w24, #0xe               // =14
     1f4:      	str	wzr, [x22, #0x14]
     1f8:      	blr	x8
     1fc:      	str	w0, [x22, #0x7c]
     200:      	blr	x24
     204:      	cmn	x0, #0x16
     208:      	b.ne	0x22c <generic_fentry_setup_event+0x22c>
     20c:      	add	x2, x19, #0xe8
     210:      	mov	w8, #0x8                // =8
     214:      	mov	w9, #0x4                // =4
     218:      	add	x10, sp, #0x18
     21c:      	add	x0, sp, #0x18
     220:      	mov	w1, #0x8                // =8
     224:      	blr	x9
     228:      	ldr	x0, [sp, #0x18]
     22c:      	str	x0, [x22, #0x68]
     230:      	ldr	w8, [x23, #0x5c]
     234:      	cmp	w8, #0x1
     238:      	b.lt	0x2f0 <generic_fentry_setup_event+0x2f0>
     23c:      	ldr	x8, [x22, #0x60]
     240:      	ldr	x9, [x22, #0x8]
     244:      	mov	w10, #0x1               // =1
     248:      	mov	x3, xzr
     24c:      	add	x1, sp, #0x8
     250:      	add	x2, sp, #0x18
     254:      	str	xzr, [sp, #0x28]
     258:      	stp	x9, x10, [sp, #0x18]
     25c:      	stp	x8, x0, [sp, #0x8]
     260:      	adrp	x0, 0x0 <generic_fentry_setup_event>
     264:      	mov	w8, #0x2                // =2
     268:      	add	x9, sp, #0x8
     26c:      	add	x10, sp, #0x18
     270:      	ldr	x0, [x0]
     274:      	blr	x8
     278:      	cbz	x0, 0x2f0 <generic_fentry_setup_event+0x2f0>
     27c:      	neg	w8, w0
     280:      	adrp	x22, 0x0 <generic_fentry_setup_event>
     284:      	mov	w9, #0x1                // =1
     288:      	strh	w8, [sp, #0x34]
     28c:      	mov	w8, #0x5                // =5
     290:      	add	x1, sp, #0x34
     294:      	mov	w23, #0x1               // =1
     298:      	strh	w8, [sp, #0x36]
     29c:      	mov	x8, #0x46               // =70
     2a0:      	movk	x8, #0x2, lsl #32
     2a4:      	stur	x8, [sp, #0x38]
     2a8:      	add	x8, sp, #0x34
     2ac:      	ldr	x22, [x22]
     2b0:      	mov	x0, x22
     2b4:      	blr	x9
     2b8:      	cbz	x0, 0x2cc <generic_fentry_setup_event+0x2cc>
     2bc:      	ldr	w8, [x0]
     2c0:      	add	w8, w8, #0x1
     2c4:      	str	w8, [x0]
     2c8:      	b	0x2f0 <generic_fentry_setup_event+0x2f0>
     2cc:      	str	w23, [sp, #0x4c]
     2d0:      	mov	x3, xzr
     2d4:      	mov	w8, #0x2                // =2
     2d8:      	add	x9, sp, #0x34
     2dc:      	add	x10, sp, #0x4c
     2e0:      	add	x1, sp, #0x34
     2e4:      	add	x2, sp, #0x4c
     2e8:      	mov	x0, x22
     2ec:      	blr	x8
     2f0:      	str	wzr, [sp, #0x18]
     2f4:      	mov	w8, #0x1                // =1
     2f8:      	add	x9, sp, #0x18
     2fc:      	add	x1, sp, #0x18
     300:      	mov	x0, x20
     304:      	blr	x8
     308:      	adrp	x20, 0x0 <generic_fentry_setup_event>
     30c:      	ldr	x20, [x20]
     310:      	cbz	x0, 0x338 <generic_fentry_setup_event+0x338>
     314:      	mov	w8, #0x5ef8             // =24312
     318:      	add	x1, x0, x8
     31c:      	mov	w8, #0x1                // =1
     320:      	mov	x0, x21
     324:      	blr	x8
     328:      	cbz	x0, 0x338 <generic_fentry_setup_event+0x338>
     32c:      	ldr	w8, [x0, #0x40]
     330:      	cmn	w8, #0x1
     334:      	b.ne	0x350 <generic_fentry_setup_event+0x350>
     338:      	mov	w8, #0x3                // =3
     33c:      	mov	w9, #0xc                // =12
     340:      	mov	x0, x19
     344:      	mov	x1, x20
     348:      	mov	w2, #0x3                // =3
     34c:      	blr	x9
     350:      	mov	w8, #0x1                // =1
     354:      	mov	w9, #0xc                // =12
     358:      	mov	x0, x19
     35c:      	mov	x1, x20
     360:      	mov	w2, #0x1                // =1
     364:      	blr	x9
     368:      	ldp	x20, x19, [sp, #0x80]
     36c:      	mov	w0, wzr
     370:      	ldr	x29, [sp, #0x40]
     374:      	ldp	x22, x21, [sp, #0x70]
     378:      	ldp	x24, x23, [sp, #0x60]
     37c:      	ldp	x30, x25, [sp, #0x50]
     380:      	add	sp, sp, #0x90
     384:      	ret
     388:      	nop
     38c:      	nop

0000000000000390 <generic_fentry_process_event>:
     390:      	sub	sp, sp, #0x140
     394:      	str	x29, [sp, #0xf0]
     398:      	stp	x30, x25, [sp, #0x100]
     39c:      	stp	x24, x23, [sp, #0x110]
     3a0:      	stp	x22, x21, [sp, #0x120]
     3a4:      	stp	x20, x19, [sp, #0x130]
     3a8:      	str	wzr, [sp, #0x4c]
     3ac:      	adrp	x21, 0x0 <generic_fentry_setup_event>
     3b0:      	mov	w8, #0x1                // =1
     3b4:      	add	x9, sp, #0x4c
     3b8:      	ldr	x21, [x21]
     3bc:      	mov	x19, x0
     3c0:      	add	x1, sp, #0x4c
     3c4:      	mov	x0, x21
     3c8:      	blr	x8
     3cc:      	cbz	x0, 0x3be0 <generic_fentry_process_event+0x3850>
     3d0:      	ldr	w24, [x0, #0x4]
     3d4:      	mov	w22, #0x5efc            // =24316
     3d8:      	adrp	x29, 0x0 <generic_fentry_setup_event>
     3dc:      	mov	x20, x0
     3e0:      	ldr	w25, [x0, x22]
     3e4:      	ldr	x29, [x29]
     3e8:      	lsr	w8, w24, #3
     3ec:      	cmp	w8, #0x464
     3f0:      	b.hi	0x3b4c <generic_fentry_process_event+0x37bc>
     3f4:      	str	wzr, [sp, #0x58]
     3f8:      	mov	w8, #0x1                // =1
     3fc:      	add	x9, sp, #0x58
     400:      	add	x1, sp, #0x58
     404:      	mov	x0, x21
     408:      	blr	x8
     40c:      	cbz	x0, 0x3b4c <generic_fentry_process_event+0x37bc>
     410:      	mov	w8, #0x5ef8             // =24312
     414:      	mov	x23, x0
     418:      	add	x1, x0, x8
     41c:      	adrp	x0, 0x0 <generic_fentry_setup_event>
     420:      	mov	w8, #0x1                // =1
     424:      	ldr	x0, [x0]
     428:      	blr	x8
     42c:      	cmp	w25, #0x4
     430:      	ccmp	x0, #0x0, #0x4, le
     434:      	b.eq	0x3b4c <generic_fentry_process_event+0x37bc>
     438:      	str	x25, [sp, #0x40]
     43c:      	and	x25, x25, #0x7
     440:      	str	x24, [sp, #0xf8]
     444:      	mov	w9, #0x5ea0             // =24224
     448:      	add	x8, x0, x25, lsl #2
     44c:      	ldrsw	x21, [x8, #0x18]
     450:      	ldr	w24, [x8, #0x4]
     454:      	add	x8, x23, x25, lsl #2
     458:      	str	wzr, [x8, x9]
     45c:      	and	x11, x21, #0xffffffff
     460:      	tbnz	w21, #0x8, 0x488 <generic_fentry_process_event+0xf8>
     464:      	str	x8, [sp, #0x38]
     468:      	tbnz	w21, #0x7, 0x490 <generic_fentry_process_event+0x100>
     46c:      	tbnz	w11, #0x6, 0x49c <generic_fentry_process_event+0x10c>
     470:      	add	x8, x0, x25, lsl #2
     474:      	ldr	w8, [x8, #0x40]
     478:      	and	x8, x8, #0x7
     47c:      	add	x8, x23, x8, lsl #3
     480:      	ldr	x8, [x8, #0x5e50]
     484:      	b	0x4b8 <generic_fentry_process_event+0x128>
     488:      	str	xzr, [sp, #0x50]
     48c:      	b	0xaa8 <generic_fentry_process_event+0x718>
     490:      	mov	x8, xzr
     494:      	str	xzr, [sp, #0x50]
     498:      	b	0x4bc <generic_fentry_process_event+0x12c>
     49c:      	mov	w8, #0x23               // =35
     4a0:      	mov	x23, x0
     4a4:      	mov	x22, x11
     4a8:      	blr	x8
     4ac:      	mov	x11, x22
     4b0:      	mov	x8, x0
     4b4:      	mov	x0, x23
     4b8:      	str	x8, [sp, #0x50]
     4bc:      	cmp	w25, #0x4
     4c0:      	b.hi	0xaa8 <generic_fentry_process_event+0x718>
     4c4:      	mov	w9, #0x50               // =80
     4c8:      	umaddl	x23, w25, w9, x0
     4cc:      	ldrh	w9, [x23, #0x76]
     4d0:      	cbz	w9, 0xaa8 <generic_fentry_process_event+0x718>
     4d4:      	adrp	x9, 0x0 <generic_fentry_setup_event>
     4d8:      	ldr	x9, [x9]
     4dc:      	ldrb	w10, [x9]
     4e0:      	ldur	w9, [x23, #0x70]
     4e4:      	add	x8, x8, x9
     4e8:      	str	x8, [sp, #0x50]
     4ec:      	ldurh	w9, [x23, #0x74]
     4f0:      	cbz	w10, 0x7bc <generic_fentry_process_event+0x42c>
     4f4:      	cbz	w9, 0x520 <generic_fentry_process_event+0x190>
     4f8:      	mov	w9, #0x8                // =8
     4fc:      	mov	w10, #0x4               // =4
     500:      	mov	x22, x11
     504:      	add	x11, sp, #0x50
     508:      	ldr	x2, [sp, #0x50]
     50c:      	add	x0, sp, #0x50
     510:      	mov	w1, #0x8                // =8
     514:      	blr	x10
     518:      	mov	x11, x22
     51c:      	tbnz	w0, #0x1f, 0xa88 <generic_fentry_process_event+0x6f8>
     520:      	ldurh	w8, [x23, #0x7e]
     524:      	cbz	w8, 0xaa8 <generic_fentry_process_event+0x718>
     528:      	ldr	x8, [sp, #0x50]
     52c:      	ldur	w9, [x23, #0x78]
     530:      	add	x8, x8, x9
     534:      	str	x8, [sp, #0x50]
     538:      	ldurh	w9, [x23, #0x7c]
     53c:      	cbz	w9, 0x568 <generic_fentry_process_event+0x1d8>
     540:      	mov	w9, #0x8                // =8
     544:      	mov	w10, #0x4               // =4
     548:      	mov	x22, x11
     54c:      	add	x11, sp, #0x50
     550:      	ldr	x2, [sp, #0x50]
     554:      	add	x0, sp, #0x50
     558:      	mov	w1, #0x8                // =8
     55c:      	blr	x10
     560:      	mov	x11, x22
     564:      	tbnz	w0, #0x1f, 0xa90 <generic_fentry_process_event+0x700>
     568:      	ldurh	w8, [x23, #0x86]
     56c:      	cbz	w8, 0xaa8 <generic_fentry_process_event+0x718>
     570:      	ldr	x8, [sp, #0x50]
     574:      	ldur	w9, [x23, #0x80]
     578:      	add	x8, x8, x9
     57c:      	str	x8, [sp, #0x50]
     580:      	ldurh	w9, [x23, #0x84]
     584:      	cbz	w9, 0x5b0 <generic_fentry_process_event+0x220>
     588:      	mov	w9, #0x8                // =8
     58c:      	mov	w10, #0x4               // =4
     590:      	mov	x22, x11
     594:      	add	x11, sp, #0x50
     598:      	ldr	x2, [sp, #0x50]
     59c:      	add	x0, sp, #0x50
     5a0:      	mov	w1, #0x8                // =8
     5a4:      	blr	x10
     5a8:      	mov	x11, x22
     5ac:      	tbnz	w0, #0x1f, 0xa98 <generic_fentry_process_event+0x708>
     5b0:      	ldurh	w8, [x23, #0x8e]
     5b4:      	cbz	w8, 0xaa8 <generic_fentry_process_event+0x718>
     5b8:      	ldr	x8, [sp, #0x50]
     5bc:      	ldur	w9, [x23, #0x88]
     5c0:      	add	x8, x8, x9
     5c4:      	str	x8, [sp, #0x50]
     5c8:      	ldurh	w9, [x23, #0x8c]
     5cc:      	cbz	w9, 0x5fc <generic_fentry_process_event+0x26c>
     5d0:      	mov	w9, #0x8                // =8
     5d4:      	add	x10, sp, #0x50
     5d8:      	mov	x22, x11
     5dc:      	mov	w11, #0x4               // =4
     5e0:      	ldr	x2, [sp, #0x50]
     5e4:      	add	x0, sp, #0x50
     5e8:      	mov	w1, #0x8                // =8
     5ec:      	blr	x11
     5f0:      	mov	w10, #0x4               // =4
     5f4:      	mov	x11, x22
     5f8:      	tbnz	w0, #0x1f, 0xa9c <generic_fentry_process_event+0x70c>
     5fc:      	ldurh	w8, [x23, #0x96]
     600:      	cbz	w8, 0xaa8 <generic_fentry_process_event+0x718>
     604:      	ldr	x8, [sp, #0x50]
     608:      	ldur	w9, [x23, #0x90]
     60c:      	add	x8, x8, x9
     610:      	str	x8, [sp, #0x50]
     614:      	ldurh	w9, [x23, #0x94]
     618:      	cbz	w9, 0x644 <generic_fentry_process_event+0x2b4>
     61c:      	mov	w9, #0x8                // =8
     620:      	mov	w10, #0x4               // =4
     624:      	mov	x22, x11
     628:      	add	x11, sp, #0x50
     62c:      	ldr	x2, [sp, #0x50]
     630:      	add	x0, sp, #0x50
     634:      	mov	w1, #0x8                // =8
     638:      	blr	x10
     63c:      	mov	x11, x22
     640:      	tbnz	w0, #0x1f, 0x1784 <generic_fentry_process_event+0x13f4>
     644:      	ldurh	w8, [x23, #0x9e]
     648:      	cbz	w8, 0xaa8 <generic_fentry_process_event+0x718>
     64c:      	ldr	x8, [sp, #0x50]
     650:      	ldur	w9, [x23, #0x98]
     654:      	mov	x22, x11
     658:      	add	x8, x8, x9
     65c:      	str	x8, [sp, #0x50]
     660:      	ldurh	w9, [x23, #0x9c]
     664:      	cbz	w9, 0x688 <generic_fentry_process_event+0x2f8>
     668:      	mov	w9, #0x8                // =8
     66c:      	mov	w10, #0x4               // =4
     670:      	add	x11, sp, #0x50
     674:      	ldr	x2, [sp, #0x50]
     678:      	add	x0, sp, #0x50
     67c:      	mov	w1, #0x8                // =8
     680:      	blr	x10
     684:      	tbnz	w0, #0x1f, 0x1970 <generic_fentry_process_event+0x15e0>
     688:      	ldurh	w8, [x23, #0xa6]
     68c:      	mov	x11, x22
     690:      	cbz	w8, 0xaa8 <generic_fentry_process_event+0x718>
     694:      	ldr	x8, [sp, #0x50]
     698:      	ldur	w9, [x23, #0xa0]
     69c:      	add	x8, x8, x9
     6a0:      	str	x8, [sp, #0x50]
     6a4:      	ldurh	w9, [x23, #0xa4]
     6a8:      	cbz	w9, 0x6cc <generic_fentry_process_event+0x33c>
     6ac:      	mov	w9, #0x8                // =8
     6b0:      	mov	w10, #0x4               // =4
     6b4:      	add	x11, sp, #0x50
     6b8:      	ldr	x2, [sp, #0x50]
     6bc:      	add	x0, sp, #0x50
     6c0:      	mov	w1, #0x8                // =8
     6c4:      	blr	x10
     6c8:      	tbnz	w0, #0x1f, 0x1acc <generic_fentry_process_event+0x173c>
     6cc:      	adrp	x29, 0x0 <generic_fentry_setup_event>
     6d0:      	ldurh	w8, [x23, #0xae]
     6d4:      	mov	x11, x22
     6d8:      	ldr	x29, [x29]
     6dc:      	cbz	w8, 0xaa8 <generic_fentry_process_event+0x718>
     6e0:      	ldr	x8, [sp, #0x50]
     6e4:      	ldur	w9, [x23, #0xa8]
     6e8:      	add	x8, x8, x9
     6ec:      	str	x8, [sp, #0x50]
     6f0:      	ldurh	w9, [x23, #0xac]
     6f4:      	cbz	w9, 0x728 <generic_fentry_process_event+0x398>
     6f8:      	mov	w29, #0x8               // =8
     6fc:      	mov	w9, #0x4                // =4
     700:      	add	x10, sp, #0x50
     704:      	ldr	x2, [sp, #0x50]
     708:      	add	x0, sp, #0x50
     70c:      	mov	w1, #0x8                // =8
     710:      	blr	x9
     714:      	mov	w10, w29
     718:      	adrp	x29, 0x0 <generic_fentry_setup_event>
     71c:      	mov	x11, x22
     720:      	ldr	x29, [x29]
     724:      	tbnz	w0, #0x1f, 0xa9c <generic_fentry_process_event+0x70c>
     728:      	ldurh	w8, [x23, #0xb6]
     72c:      	cbz	w8, 0xaa8 <generic_fentry_process_event+0x718>
     730:      	ldr	x8, [sp, #0x50]
     734:      	ldur	w9, [x23, #0xb0]
     738:      	add	x8, x8, x9
     73c:      	str	x8, [sp, #0x50]
     740:      	ldurh	w9, [x23, #0xb4]
     744:      	cbz	w9, 0x768 <generic_fentry_process_event+0x3d8>
     748:      	mov	w9, #0x8                // =8
     74c:      	mov	w10, #0x4               // =4
     750:      	add	x11, sp, #0x50
     754:      	ldr	x2, [sp, #0x50]
     758:      	add	x0, sp, #0x50
     75c:      	mov	w1, #0x8                // =8
     760:      	blr	x10
     764:      	tbnz	w0, #0x1f, 0x2788 <generic_fentry_process_event+0x23f8>
     768:      	adrp	x29, 0x0 <generic_fentry_setup_event>
     76c:      	ldurh	w8, [x23, #0xbe]
     770:      	mov	x11, x22
     774:      	ldr	x29, [x29]
     778:      	cbz	w8, 0xaa8 <generic_fentry_process_event+0x718>
     77c:      	ldr	x8, [sp, #0x50]
     780:      	ldur	w9, [x23, #0xb8]
     784:      	add	x8, x8, x9
     788:      	str	x8, [sp, #0x50]
     78c:      	ldurh	w9, [x23, #0xbc]
     790:      	cbz	w9, 0xaa8 <generic_fentry_process_event+0x718>
     794:      	mov	w9, #0x8                // =8
     798:      	mov	w10, #0x4               // =4
     79c:      	add	x11, sp, #0x50
     7a0:      	ldr	x2, [sp, #0x50]
     7a4:      	add	x0, sp, #0x50
     7a8:      	mov	w1, #0x8                // =8
     7ac:      	blr	x10
     7b0:      	mov	x11, x22
     7b4:      	tbz	w0, #0x1f, 0xaa8 <generic_fentry_process_event+0x718>
     7b8:      	b	0xa80 <generic_fentry_process_event+0x6f0>
     7bc:      	cbz	w9, 0x7e8 <generic_fentry_process_event+0x458>
     7c0:      	mov	w9, #0x8                // =8
     7c4:      	mov	w10, #0x4               // =4
     7c8:      	mov	x22, x11
     7cc:      	add	x11, sp, #0x50
     7d0:      	ldr	x2, [sp, #0x50]
     7d4:      	add	x0, sp, #0x50
     7d8:      	mov	w1, #0x8                // =8
     7dc:      	blr	x10
     7e0:      	mov	x11, x22
     7e4:      	tbnz	w0, #0x1f, 0xa88 <generic_fentry_process_event+0x6f8>
     7e8:      	ldurh	w8, [x23, #0x7e]
     7ec:      	cbz	w8, 0xaa8 <generic_fentry_process_event+0x718>
     7f0:      	ldr	x8, [sp, #0x50]
     7f4:      	ldur	w9, [x23, #0x78]
     7f8:      	add	x8, x8, x9
     7fc:      	str	x8, [sp, #0x50]
     800:      	ldurh	w9, [x23, #0x7c]
     804:      	cbz	w9, 0x830 <generic_fentry_process_event+0x4a0>
     808:      	mov	w9, #0x8                // =8
     80c:      	mov	w10, #0x4               // =4
     810:      	mov	x22, x11
     814:      	add	x11, sp, #0x50
     818:      	ldr	x2, [sp, #0x50]
     81c:      	add	x0, sp, #0x50
     820:      	mov	w1, #0x8                // =8
     824:      	blr	x10
     828:      	mov	x11, x22
     82c:      	tbnz	w0, #0x1f, 0xa90 <generic_fentry_process_event+0x700>
     830:      	ldurh	w8, [x23, #0x86]
     834:      	cbz	w8, 0xaa8 <generic_fentry_process_event+0x718>
     838:      	ldr	x8, [sp, #0x50]
     83c:      	ldur	w9, [x23, #0x80]
     840:      	add	x8, x8, x9
     844:      	str	x8, [sp, #0x50]
     848:      	ldurh	w9, [x23, #0x84]
     84c:      	cbz	w9, 0x878 <generic_fentry_process_event+0x4e8>
     850:      	mov	w9, #0x8                // =8
     854:      	mov	w10, #0x4               // =4
     858:      	mov	x22, x11
     85c:      	add	x11, sp, #0x50
     860:      	ldr	x2, [sp, #0x50]
     864:      	add	x0, sp, #0x50
     868:      	mov	w1, #0x8                // =8
     86c:      	blr	x10
     870:      	mov	x11, x22
     874:      	tbnz	w0, #0x1f, 0xa98 <generic_fentry_process_event+0x708>
     878:      	ldurh	w8, [x23, #0x8e]
     87c:      	cbz	w8, 0xaa8 <generic_fentry_process_event+0x718>
     880:      	ldr	x8, [sp, #0x50]
     884:      	ldur	w9, [x23, #0x88]
     888:      	add	x8, x8, x9
     88c:      	str	x8, [sp, #0x50]
     890:      	ldurh	w9, [x23, #0x8c]
     894:      	cbz	w9, 0x8c4 <generic_fentry_process_event+0x534>
     898:      	mov	w9, #0x8                // =8
     89c:      	add	x10, sp, #0x50
     8a0:      	mov	x22, x11
     8a4:      	mov	w11, #0x4               // =4
     8a8:      	ldr	x2, [sp, #0x50]
     8ac:      	add	x0, sp, #0x50
     8b0:      	mov	w1, #0x8                // =8
     8b4:      	blr	x11
     8b8:      	mov	w10, #0x4               // =4
     8bc:      	mov	x11, x22
     8c0:      	tbnz	w0, #0x1f, 0xa9c <generic_fentry_process_event+0x70c>
     8c4:      	ldurh	w8, [x23, #0x96]
     8c8:      	cbz	w8, 0xaa8 <generic_fentry_process_event+0x718>
     8cc:      	ldr	x8, [sp, #0x50]
     8d0:      	ldur	w9, [x23, #0x90]
     8d4:      	add	x8, x8, x9
     8d8:      	str	x8, [sp, #0x50]
     8dc:      	ldurh	w9, [x23, #0x94]
     8e0:      	cbz	w9, 0x90c <generic_fentry_process_event+0x57c>
     8e4:      	mov	w9, #0x8                // =8
     8e8:      	mov	w10, #0x4               // =4
     8ec:      	mov	x22, x11
     8f0:      	add	x11, sp, #0x50
     8f4:      	ldr	x2, [sp, #0x50]
     8f8:      	add	x0, sp, #0x50
     8fc:      	mov	w1, #0x8                // =8
     900:      	blr	x10
     904:      	mov	x11, x22
     908:      	tbnz	w0, #0x1f, 0x1784 <generic_fentry_process_event+0x13f4>
     90c:      	ldurh	w8, [x23, #0x9e]
     910:      	cbz	w8, 0xaa8 <generic_fentry_process_event+0x718>
     914:      	ldr	x8, [sp, #0x50]
     918:      	ldur	w9, [x23, #0x98]
     91c:      	mov	x22, x11
     920:      	add	x8, x8, x9
     924:      	str	x8, [sp, #0x50]
     928:      	ldurh	w9, [x23, #0x9c]
     92c:      	cbz	w9, 0x950 <generic_fentry_process_event+0x5c0>
     930:      	mov	w9, #0x8                // =8
     934:      	mov	w10, #0x4               // =4
     938:      	add	x11, sp, #0x50
     93c:      	ldr	x2, [sp, #0x50]
     940:      	add	x0, sp, #0x50
     944:      	mov	w1, #0x8                // =8
     948:      	blr	x10
     94c:      	tbnz	w0, #0x1f, 0x1970 <generic_fentry_process_event+0x15e0>
     950:      	ldurh	w8, [x23, #0xa6]
     954:      	mov	x11, x22
     958:      	cbz	w8, 0xaa8 <generic_fentry_process_event+0x718>
     95c:      	ldr	x8, [sp, #0x50]
     960:      	ldur	w9, [x23, #0xa0]
     964:      	add	x8, x8, x9
     968:      	str	x8, [sp, #0x50]
     96c:      	ldurh	w9, [x23, #0xa4]
     970:      	cbz	w9, 0x994 <generic_fentry_process_event+0x604>
     974:      	mov	w9, #0x8                // =8
     978:      	mov	w10, #0x4               // =4
     97c:      	add	x11, sp, #0x50
     980:      	ldr	x2, [sp, #0x50]
     984:      	add	x0, sp, #0x50
     988:      	mov	w1, #0x8                // =8
     98c:      	blr	x10
     990:      	tbnz	w0, #0x1f, 0x1acc <generic_fentry_process_event+0x173c>
     994:      	adrp	x29, 0x0 <generic_fentry_setup_event>
     998:      	ldurh	w8, [x23, #0xae]
     99c:      	mov	x11, x22
     9a0:      	ldr	x29, [x29]
     9a4:      	cbz	w8, 0xaa8 <generic_fentry_process_event+0x718>
     9a8:      	ldr	x8, [sp, #0x50]
     9ac:      	ldur	w9, [x23, #0xa8]
     9b0:      	add	x8, x8, x9
     9b4:      	str	x8, [sp, #0x50]
     9b8:      	ldurh	w9, [x23, #0xac]
     9bc:      	cbz	w9, 0x9f0 <generic_fentry_process_event+0x660>
     9c0:      	mov	w29, #0x8               // =8
     9c4:      	mov	w9, #0x4                // =4
     9c8:      	add	x10, sp, #0x50
     9cc:      	ldr	x2, [sp, #0x50]
     9d0:      	add	x0, sp, #0x50
     9d4:      	mov	w1, #0x8                // =8
     9d8:      	blr	x9
     9dc:      	mov	w10, w29
     9e0:      	adrp	x29, 0x0 <generic_fentry_setup_event>
     9e4:      	mov	x11, x22
     9e8:      	ldr	x29, [x29]
     9ec:      	tbnz	w0, #0x1f, 0xa9c <generic_fentry_process_event+0x70c>
     9f0:      	ldurh	w8, [x23, #0xb6]
     9f4:      	cbz	w8, 0xaa8 <generic_fentry_process_event+0x718>
     9f8:      	ldr	x8, [sp, #0x50]
     9fc:      	ldur	w9, [x23, #0xb0]
     a00:      	add	x8, x8, x9
     a04:      	str	x8, [sp, #0x50]
     a08:      	ldurh	w9, [x23, #0xb4]
     a0c:      	cbz	w9, 0xa30 <generic_fentry_process_event+0x6a0>
     a10:      	mov	w9, #0x8                // =8
     a14:      	mov	w10, #0x4               // =4
     a18:      	add	x11, sp, #0x50
     a1c:      	ldr	x2, [sp, #0x50]
     a20:      	add	x0, sp, #0x50
     a24:      	mov	w1, #0x8                // =8
     a28:      	blr	x10
     a2c:      	tbnz	w0, #0x1f, 0x2788 <generic_fentry_process_event+0x23f8>
     a30:      	adrp	x29, 0x0 <generic_fentry_setup_event>
     a34:      	ldurh	w8, [x23, #0xbe]
     a38:      	mov	x11, x22
     a3c:      	ldr	x29, [x29]
     a40:      	cbz	w8, 0xaa8 <generic_fentry_process_event+0x718>
     a44:      	ldr	x8, [sp, #0x50]
     a48:      	ldur	w9, [x23, #0xb8]
     a4c:      	add	x8, x8, x9
     a50:      	str	x8, [sp, #0x50]
     a54:      	ldurh	w9, [x23, #0xbc]
     a58:      	cbz	w9, 0xaa8 <generic_fentry_process_event+0x718>
     a5c:      	mov	w9, #0x8                // =8
     a60:      	mov	w10, #0x4               // =4
     a64:      	add	x11, sp, #0x50
     a68:      	ldr	x2, [sp, #0x50]
     a6c:      	add	x0, sp, #0x50
     a70:      	mov	w1, #0x8                // =8
     a74:      	blr	x10
     a78:      	mov	x11, x22
     a7c:      	tbz	w0, #0x1f, 0xaa8 <generic_fentry_process_event+0x718>
     a80:      	mov	w10, #0xa               // =10
     a84:      	b	0xa9c <generic_fentry_process_event+0x70c>
     a88:      	mov	w10, #0x1               // =1
     a8c:      	b	0xa9c <generic_fentry_process_event+0x70c>
     a90:      	mov	w10, #0x2               // =2
     a94:      	b	0xa9c <generic_fentry_process_event+0x70c>
     a98:      	mov	w10, #0x3               // =3
     a9c:      	ldr	x8, [sp, #0x38]
     aa0:      	mov	w9, #0x5ea0             // =24224
     aa4:      	str	w10, [x8, x9]
     aa8:      	mov	x9, #0x8000             // =32768
     aac:      	mov	w8, #0x1                // =1
     ab0:      	cmp	w24, #0x2a
     ab4:      	add	x22, sp, #0xd0
     ab8:      	movk	x9, #0x101, lsl #16
     abc:      	lsl	x8, x8, x24
     ac0:      	movk	x9, #0x420, lsl #32
     ac4:      	and	x8, x8, x9
     ac8:      	ccmp	x8, #0x0, #0x4, ls
     acc:      	b.eq	0xbb8 <generic_fentry_process_event+0x828>
     ad0:      	str	wzr, [sp, #0xd8]
     ad4:      	adrp	x0, 0x0 <generic_fentry_setup_event>
     ad8:      	ldr	x21, [sp, #0x50]
     adc:      	mov	w8, #0x1                // =1
     ae0:      	add	x9, sp, #0xd8
     ae4:      	add	x1, sp, #0xd8
     ae8:      	ldr	x0, [x0]
     aec:      	blr	x8
     af0:      	cbz	x0, 0xb64 <generic_fentry_process_event+0x7d4>
     af4:      	mov	w8, #0x6420             // =25632
     af8:      	mov	x22, x29
     afc:      	mov	x23, x0
     b00:      	add	x29, x0, x8
     b04:      	ldr	w8, [x29]
     b08:      	cbz	w8, 0xb6c <generic_fentry_process_event+0x7dc>
     b0c:      	str	wzr, [x29]
     b10:      	adrp	x0, 0x0 <generic_fentry_setup_event>
     b14:      	mov	w8, #0x1                // =1
     b18:      	add	x9, sp, #0xd8
     b1c:      	ldr	x0, [x0]
     b20:      	add	x1, sp, #0xd8
     b24:      	blr	x8
     b28:      	cbz	x0, 0xc04 <generic_fentry_process_event+0x874>
     b2c:      	add	x8, x23, x25, lsl #2
     b30:      	mov	w9, #0x5ea0             // =24224
     b34:      	ldr	x24, [sp, #0xf8]
     b38:      	add	x11, x23, x25, lsl #3
     b3c:      	ldr	w10, [x8, x9]
     b40:      	add	x8, x23, #0x90
     b44:      	adrp	x21, 0x0 <generic_fentry_setup_event>
     b48:      	add	x9, x24, #0x4
     b4c:      	str	w10, [x8, x24]
     b50:      	str	x9, [x11, #0x5e78]
     b54:      	ldr	x21, [x21]
     b58:      	cbz	w10, 0xc60 <generic_fentry_process_event+0x8d0>
     b5c:      	mov	w8, #0x4                // =4
     b60:      	b	0xd18 <generic_fentry_process_event+0x988>
     b64:      	mov	x8, xzr
     b68:      	b	0x3b34 <generic_fentry_process_event+0x37a4>
     b6c:      	add	x8, sp, #0xd0
     b70:      	cmp	w24, #0x17
     b74:      	str	x21, [sp, #0x88]
     b78:      	str	xzr, [x8, #0x10]
     b7c:      	b.le	0xc38 <generic_fentry_process_event+0x8a8>
     b80:      	ldr	x25, [sp, #0x40]
     b84:      	cmp	w24, #0x18
     b88:      	mov	x29, x22
     b8c:      	mov	w22, #0x5efc            // =24316
     b90:      	b.eq	0xd74 <generic_fentry_process_event+0x9e4>
     b94:      	cmp	w24, #0x25
     b98:      	b.eq	0xdb8 <generic_fentry_process_event+0xa28>
     b9c:      	cmp	w24, #0x2a
     ba0:      	b.ne	0xe44 <generic_fentry_process_event+0xab4>
     ba4:      	mov	w8, #0x6430             // =25648
     ba8:      	str	xzr, [x23, #0x6430]
     bac:      	str	x21, [x23, #0x6438]
     bb0:      	add	x8, x23, x8
     bb4:      	b	0xde4 <generic_fentry_process_event+0xa54>
     bb8:      	ldr	x8, [sp, #0x50]
     bbc:      	cmp	w24, #0x15
     bc0:      	stp	x11, x8, [sp, #0x30]
     bc4:      	b.gt	0xc10 <generic_fentry_process_event+0x880>
     bc8:      	mov	w23, #0x1000            // =4096
     bcc:      	cmp	w24, #0x9
     bd0:      	b.le	0xd28 <generic_fentry_process_event+0x998>
     bd4:      	cmp	w24, #0x10
     bd8:      	b.le	0xe4c <generic_fentry_process_event+0xabc>
     bdc:      	cmp	w24, #0x12
     be0:      	b.le	0xee4 <generic_fentry_process_event+0xb54>
     be4:      	cmp	w24, #0x13
     be8:      	b.eq	0xedc <generic_fentry_process_event+0xb4c>
     bec:      	cmp	w24, #0x14
     bf0:      	b.eq	0xf1c <generic_fentry_process_event+0xb8c>
     bf4:      	cmp	w24, #0x15
     bf8:      	b.ne	0xf2c <generic_fentry_process_event+0xb9c>
     bfc:      	mov	w23, #0x20              // =32
     c00:      	b	0xf30 <generic_fentry_process_event+0xba0>
     c04:      	mov	x8, xzr
     c08:      	mov	x29, x22
     c0c:      	b	0x3b34 <generic_fentry_process_event+0x37a4>
     c10:      	cmp	w24, #0x20
     c14:      	b.le	0xd50 <generic_fentry_process_event+0x9c0>
     c18:      	cmp	w24, #0x27
     c1c:      	b.gt	0xe70 <generic_fentry_process_event+0xae0>
     c20:      	sub	w8, w24, #0x21
     c24:      	cmp	w8, #0x4
     c28:      	b.lo	0xe68 <generic_fentry_process_event+0xad8>
     c2c:      	cmp	w24, #0x27
     c30:      	b.eq	0xebc <generic_fentry_process_event+0xb2c>
     c34:      	b	0xf2c <generic_fentry_process_event+0xb9c>
     c38:      	ldr	x25, [sp, #0x40]
     c3c:      	add	x21, sp, #0xd0
     c40:      	cmp	w24, #0xf
     c44:      	mov	x29, x22
     c48:      	mov	w22, #0x5efc            // =24316
     c4c:      	b.eq	0xe10 <generic_fentry_process_event+0xa80>
     c50:      	cmp	w24, #0x10
     c54:      	b.ne	0xe44 <generic_fentry_process_event+0xab4>
     c58:      	add	x24, sp, #0x60
     c5c:      	b	0xd98 <generic_fentry_process_event+0xa08>
     c60:      	add	x21, x8, x9
     c64:      	ldr	w8, [x29, #0x4]
     c68:      	ldr	x25, [x23, #0x6440]
     c6c:      	mov	w24, #0x4               // =4
     c70:      	and	x9, x8, #0xfff
     c74:      	add	x2, x0, x9
     c78:      	mov	w9, #0xfff              // =4095
     c7c:      	add	x0, x21, #0x4
     c80:      	sub	w8, w9, w8
     c84:      	and	w23, w8, #0xfff
     c88:      	mov	w8, #0x4                // =4
     c8c:      	mov	w1, w23
     c90:      	blr	x8
     c94:      	str	w23, [x21]
     c98:      	add	x2, x25, #0x8
     c9c:      	mov	w25, #0x8               // =8
     ca0:      	add	x8, sp, #0x88
     ca4:      	mov	w9, #0x4                // =4
     ca8:      	add	x0, sp, #0x88
     cac:      	mov	w1, #0x8                // =8
     cb0:      	blr	x9
     cb4:      	ldr	x8, [sp, #0x88]
     cb8:      	add	x9, sp, #0xe0
     cbc:      	mov	w10, #0x4               // =4
     cc0:      	add	x0, sp, #0xe0
     cc4:      	mov	w1, #0x8                // =8
     cc8:      	add	x8, x8, #0x30
     ccc:      	ldr	x8, [sp, #0x88]
     cd0:      	add	x2, x8, #0x30
     cd4:      	blr	x10
     cd8:      	add	x11, sp, #0xd0
     cdc:      	mov	w9, #0x2                // =2
     ce0:      	add	x10, sp, #0x60
     ce4:      	ldr	x8, [x11, #0x10]
     ce8:      	add	x0, sp, #0x60
     cec:      	mov	w1, #0x2                // =2
     cf0:      	ldr	x2, [x11, #0x10]
     cf4:      	blr	x24
     cf8:      	add	x8, x21, x23
     cfc:      	adrp	x21, 0x0 <generic_fentry_setup_event>
     d00:      	ldr	x24, [sp, #0xf8]
     d04:      	ldr	x21, [x21]
     d08:      	str	wzr, [x8, #0x4]
     d0c:      	ldrh	w9, [sp, #0x60]
     d10:      	strh	w9, [x8, #0x8]
     d14:      	add	w8, w23, #0xe
     d18:      	ldr	x25, [sp, #0x40]
     d1c:      	mov	x29, x22
     d20:      	mov	w22, #0x5efc            // =24316
     d24:      	b	0x3b48 <generic_fentry_process_event+0x37b8>
     d28:      	cmp	w24, #0x4
     d2c:      	b.gt	0xe8c <generic_fentry_process_event+0xafc>
     d30:      	sub	w8, w24, #0x2
     d34:      	cmp	w8, #0x2
     d38:      	b.lo	0xeb4 <generic_fentry_process_event+0xb24>
     d3c:      	cmp	w24, #0x1
     d40:      	b.eq	0xeb4 <generic_fentry_process_event+0xb24>
     d44:      	cmp	w24, #0x4
     d48:      	b.eq	0xe68 <generic_fentry_process_event+0xad8>
     d4c:      	b	0xf2c <generic_fentry_process_event+0xb9c>
     d50:      	cmp	w24, #0x1a
     d54:      	b.gt	0xea8 <generic_fentry_process_event+0xb18>
     d58:      	cmp	w24, #0x16
     d5c:      	b.eq	0xebc <generic_fentry_process_event+0xb2c>
     d60:      	cmp	w24, #0x17
     d64:      	b.eq	0xe68 <generic_fentry_process_event+0xad8>
     d68:      	cmp	w24, #0x1a
     d6c:      	b.eq	0xf0c <generic_fentry_process_event+0xb7c>
     d70:      	b	0xf2c <generic_fentry_process_event+0xb9c>
     d74:      	add	x24, sp, #0x60
     d78:      	mov	w8, #0x8                // =8
     d7c:      	mov	w9, #0x4                // =4
     d80:      	ldr	x2, [sp, #0x88]
     d84:      	add	x0, sp, #0x60
     d88:      	mov	w1, #0x8                // =8
     d8c:      	blr	x9
     d90:      	ldr	x8, [sp, #0x60]
     d94:      	str	x8, [sp, #0x88]
     d98:      	mov	w8, #0x8                // =8
     d9c:      	mov	w9, #0x4                // =4
     da0:      	add	x10, sp, #0x88
     da4:      	add	x0, sp, #0x60
     da8:      	add	x2, sp, #0x88
     dac:      	mov	w1, #0x8                // =8
     db0:      	blr	x9
     db4:      	b	0xddc <generic_fentry_process_event+0xa4c>
     db8:      	add	x8, x21, #0x40
     dbc:      	mov	w9, #0x8                // =8
     dc0:      	mov	w10, #0x4               // =4
     dc4:      	str	x8, [sp, #0x88]
     dc8:      	add	x11, sp, #0x60
     dcc:      	add	x0, sp, #0x60
     dd0:      	mov	w1, #0x8                // =8
     dd4:      	ldr	x2, [sp, #0x88]
     dd8:      	blr	x10
     ddc:      	ldr	x8, [sp, #0x60]
     de0:      	add	x8, x8, #0x40
     de4:      	adrp	x21, 0x0 <generic_fentry_setup_event>
     de8:      	ldr	x21, [x21]
     dec:      	str	x8, [x23, #0x6440]
     df0:      	mov	w8, #0x6                // =6
     df4:      	mov	w9, #0xc                // =12
     df8:      	mov	x0, x19
     dfc:      	mov	x1, x29
     e00:      	mov	w2, #0x6                // =6
     e04:      	blr	x9
     e08:      	mov	x8, xzr
     e0c:      	b	0x3b44 <generic_fentry_process_event+0x37b4>
     e10:      	mov	w8, #0x8                // =8
     e14:      	mov	w9, #0x4                // =4
     e18:      	add	x10, sp, #0xe0
     e1c:      	add	x11, sp, #0x88
     e20:      	add	x0, sp, #0xe0
     e24:      	add	x2, sp, #0x88
     e28:      	mov	w1, #0x8                // =8
     e2c:      	blr	x9
     e30:      	ldr	x8, [x21, #0x10]
     e34:      	adrp	x21, 0x0 <generic_fentry_setup_event>
     e38:      	ldr	x21, [x21]
     e3c:      	cbnz	x8, 0xdec <generic_fentry_process_event+0xa5c>
     e40:      	b	0x3b44 <generic_fentry_process_event+0x37b4>
     e44:      	mov	x8, xzr
     e48:      	b	0x3b3c <generic_fentry_process_event+0x37ac>
     e4c:      	sub	w8, w24, #0xa
     e50:      	cmp	w8, #0x2
     e54:      	b.lo	0xe68 <generic_fentry_process_event+0xad8>
     e58:      	sub	w8, w24, #0xc
     e5c:      	cmp	w8, #0x2
     e60:      	b.lo	0xeb4 <generic_fentry_process_event+0xb24>
     e64:      	b	0xf2c <generic_fentry_process_event+0xb9c>
     e68:      	mov	w23, #0x8               // =8
     e6c:      	b	0xf30 <generic_fentry_process_event+0xba0>
     e70:      	cmp	w24, #0x2a
     e74:      	b.gt	0xec4 <generic_fentry_process_event+0xb34>
     e78:      	cmp	w24, #0x28
     e7c:      	b.eq	0xedc <generic_fentry_process_event+0xb4c>
     e80:      	cmp	w24, #0x29
     e84:      	b.eq	0xf14 <generic_fentry_process_event+0xb84>
     e88:      	b	0xf2c <generic_fentry_process_event+0xb9c>
     e8c:      	cmp	w24, #0x6
     e90:      	b.gt	0xefc <generic_fentry_process_event+0xb6c>
     e94:      	cmp	w24, #0x5
     e98:      	b.eq	0xf14 <generic_fentry_process_event+0xb84>
     e9c:      	cmp	w24, #0x6
     ea0:      	b.eq	0xf30 <generic_fentry_process_event+0xba0>
     ea4:      	b	0xf2c <generic_fentry_process_event+0xb9c>
     ea8:      	sub	w8, w24, #0x1d
     eac:      	cmp	w8, #0x4
     eb0:      	b.hs	0xf24 <generic_fentry_process_event+0xb94>
     eb4:      	mov	w23, #0x4               // =4
     eb8:      	b	0xf30 <generic_fentry_process_event+0xba0>
     ebc:      	mov	w23, #0x10              // =16
     ec0:      	b	0xf30 <generic_fentry_process_event+0xba0>
     ec4:      	cmp	w24, #0x2b
     ec8:      	b.eq	0xedc <generic_fentry_process_event+0xb4c>
     ecc:      	cmp	w24, #0x2c
     ed0:      	b.ne	0xf2c <generic_fentry_process_event+0xb9c>
     ed4:      	mov	w23, #0x70              // =112
     ed8:      	b	0xf30 <generic_fentry_process_event+0xba0>
     edc:      	mov	w23, #0x18              // =24
     ee0:      	b	0xf30 <generic_fentry_process_event+0xba0>
     ee4:      	cmp	w24, #0x11
     ee8:      	b.eq	0xf30 <generic_fentry_process_event+0xba0>
     eec:      	cmp	w24, #0x12
     ef0:      	mov	x23, x21
     ef4:      	b.eq	0xf30 <generic_fentry_process_event+0xba0>
     ef8:      	b	0xf2c <generic_fentry_process_event+0xb9c>
     efc:      	cmp	w24, #0x7
     f00:      	b.eq	0xf14 <generic_fentry_process_event+0xb84>
     f04:      	cmp	w24, #0x8
     f08:      	b.ne	0xf2c <generic_fentry_process_event+0xb9c>
     f0c:      	mov	w23, #0x50              // =80
     f10:      	b	0xf30 <generic_fentry_process_event+0xba0>
     f14:      	mov	w23, #0x40              // =64
     f18:      	b	0xf30 <generic_fentry_process_event+0xba0>
     f1c:      	mov	w23, #0x98              // =152
     f20:      	b	0xf30 <generic_fentry_process_event+0xba0>
     f24:      	cmp	w24, #0x1b
     f28:      	b.eq	0xf0c <generic_fentry_process_event+0xb7c>
     f2c:      	mov	x23, xzr
     f30:      	str	wzr, [sp, #0x5c]
     f34:      	adrp	x0, 0x0 <generic_fentry_setup_event>
     f38:      	mov	w8, #0x1                // =1
     f3c:      	add	x9, sp, #0x5c
     f40:      	ldr	x0, [x0]
     f44:      	add	x1, sp, #0x5c
     f48:      	blr	x8
     f4c:      	mov	x8, xzr
     f50:      	cbz	x0, 0x3b34 <generic_fentry_process_event+0x37a4>
     f54:      	ldr	x10, [sp, #0xf8]
     f58:      	mov	w9, #0x3ffb             // =16379
     f5c:      	sub	x9, x9, x23
     f60:      	cmp	x9, x10
     f64:      	b.ls	0x3b34 <generic_fentry_process_event+0x37a4>
     f68:      	add	x12, x0, x25, lsl #2
     f6c:      	mov	w8, #0x5ea0             // =24224
     f70:      	ldr	x9, [sp, #0xf8]
     f74:      	add	x10, x0, #0x90
     f78:      	ldr	w8, [x12, x8]
     f7c:      	add	x23, x9, #0x4
     f80:      	str	w8, [x10, x9]
     f84:      	add	x9, x0, x25, lsl #3
     f88:      	str	x23, [x9, #0x5e78]
     f8c:      	cbz	w8, 0xf98 <generic_fentry_process_event+0xc08>
     f90:      	mov	w8, #0x4                // =4
     f94:      	b	0x3b34 <generic_fentry_process_event+0x37a4>
     f98:      	ldr	x11, [sp, #0x38]
     f9c:      	add	x8, x10, x23
     fa0:      	cmp	w24, #0x17
     fa4:      	str	xzr, [x22, #0x10]
     fa8:      	str	x12, [sp, #0x28]
     fac:      	stp	x8, x10, [sp, #0x18]
     fb0:      	str	x11, [sp, #0x88]
     fb4:      	b.le	0xfdc <generic_fentry_process_event+0xc4c>
     fb8:      	cmp	w24, #0x18
     fbc:      	b.eq	0xff4 <generic_fentry_process_event+0xc64>
     fc0:      	cmp	w24, #0x25
     fc4:      	b.eq	0x1038 <generic_fentry_process_event+0xca8>
     fc8:      	cmp	w24, #0x2a
     fcc:      	b.ne	0x16e0 <generic_fentry_process_event+0x1350>
     fd0:      	stp	xzr, x11, [sp, #0x60]
     fd4:      	add	x25, sp, #0x60
     fd8:      	b	0x1064 <generic_fentry_process_event+0xcd4>
     fdc:      	cmp	w24, #0xf
     fe0:      	b.eq	0x163c <generic_fentry_process_event+0x12ac>
     fe4:      	cmp	w24, #0x10
     fe8:      	b.ne	0x16e0 <generic_fentry_process_event+0x1350>
     fec:      	add	x21, sp, #0xd8
     ff0:      	b	0x1018 <generic_fentry_process_event+0xc88>
     ff4:      	add	x21, sp, #0xd8
     ff8:      	mov	w8, #0x8                // =8
     ffc:      	mov	w9, #0x4                // =4
    1000:      	ldr	x2, [sp, #0x88]
    1004:      	add	x0, sp, #0xd8
    1008:      	mov	w1, #0x8                // =8
    100c:      	blr	x9
    1010:      	ldr	x8, [x22, #0x8]
    1014:      	str	x8, [sp, #0x88]
    1018:      	mov	w8, #0x8                // =8
    101c:      	mov	w9, #0x4                // =4
    1020:      	add	x10, sp, #0x88
    1024:      	add	x0, sp, #0xd8
    1028:      	add	x2, sp, #0x88
    102c:      	mov	w1, #0x8                // =8
    1030:      	blr	x9
    1034:      	b	0x105c <generic_fentry_process_event+0xccc>
    1038:      	add	x8, x11, #0x40
    103c:      	mov	w9, #0x8                // =8
    1040:      	mov	w10, #0x4               // =4
    1044:      	str	x8, [sp, #0x88]
    1048:      	add	x11, sp, #0xd8
    104c:      	add	x0, sp, #0xd8
    1050:      	mov	w1, #0x8                // =8
    1054:      	ldr	x2, [sp, #0x88]
    1058:      	blr	x10
    105c:      	ldr	x8, [x22, #0x8]
    1060:      	add	x25, x8, #0x40
    1064:      	str	wzr, [sp, #0x74]
    1068:      	adrp	x0, 0x1000 <generic_fentry_process_event+0xc70>
    106c:      	mov	w8, #0x1                // =1
    1070:      	add	x9, sp, #0x74
    1074:      	ldr	x0, [x0]
    1078:      	add	x1, sp, #0x74
    107c:      	blr	x8
    1080:      	cbz	x0, 0x1590 <generic_fentry_process_event+0x1200>
    1084:      	add	x8, x0, #0x1, lsl #12   // =0x1000
    1088:      	mov	x24, x0
    108c:      	str	x8, [sp, #0x30]
    1090:      	mov	w8, #0x23               // =35
    1094:      	blr	x8
    1098:      	add	x2, x0, #0xb30
    109c:      	mov	w29, #0x8               // =8
    10a0:      	add	x8, sp, #0x78
    10a4:      	mov	w9, #0x4                // =4
    10a8:      	add	x0, sp, #0x78
    10ac:      	mov	w1, #0x8                // =8
    10b0:      	mov	w21, #0x4               // =4
    10b4:      	blr	x9
    10b8:      	ldr	x8, [sp, #0x78]
    10bc:      	add	x2, x25, #0x8
    10c0:      	mov	w9, #0x4                // =4
    10c4:      	add	x0, sp, #0x80
    10c8:      	mov	w1, #0x8                // =8
    10cc:      	mov	x22, x8
    10d0:      	add	x8, x8, #0x18
    10d4:      	str	x8, [sp, #0x38]
    10d8:      	add	x8, sp, #0x80
    10dc:      	str	x2, [sp, #0x10]
    10e0:      	blr	x9
    10e4:      	ldr	x23, [sp, #0x80]
    10e8:      	add	x8, sp, #0x88
    10ec:      	add	x0, sp, #0x88
    10f0:      	mov	w1, #0x8                // =8
    10f4:      	add	x2, x23, #0x10
    10f8:      	blr	x21
    10fc:      	ldr	x8, [sp, #0x88]
    1100:      	str	x25, [sp, #0x8]
    1104:      	cbz	x8, 0x1114 <generic_fentry_process_event+0xd84>
    1108:      	ldr	x9, [sp, #0x30]
    110c:      	mov	w8, #0x1000             // =4096
    1110:      	b	0x115c <generic_fentry_process_event+0xdcc>
    1114:      	add	x2, x23, #0x18
    1118:      	mov	w8, #0x8                // =8
    111c:      	mov	w9, #0x4                // =4
    1120:      	add	x10, sp, #0x88
    1124:      	add	x0, sp, #0x88
    1128:      	mov	w1, #0x8                // =8
    112c:      	blr	x9
    1130:      	ldr	x8, [sp, #0x88]
    1134:      	cmp	x8, x23
    1138:      	b.eq	0x1108 <generic_fentry_process_event+0xd78>
    113c:      	mov	w8, #0x2964             // =10596
    1140:      	add	x9, x24, #0xff6
    1144:      	strh	w8, [x24, #0xffe]
    1148:      	adrp	x8, 0x1000 <generic_fentry_process_event+0xc70>
    114c:      	add	x8, x8, #0x0
    1150:      	ldr	x8, [x8]
    1154:      	str	x8, [x9]
    1158:      	mov	w8, #0xff6              // =4086
    115c:      	stp	xzr, xzr, [sp, #0x88]
    1160:      	add	x10, sp, #0x88
    1164:      	add	x2, x22, #0x20
    1168:      	mov	w21, #0x8               // =8
    116c:      	add	x0, sp, #0x88
    1170:      	mov	w1, #0x8                // =8
    1174:      	stp	x24, xzr, [sp, #0x98]
    1178:      	add	x23, x10, #0x8
    117c:      	add	x25, x10, #0x18
    1180:      	stp	xzr, xzr, [sp, #0xa8]
    1184:      	add	x24, x10, #0x20
    1188:      	mov	w29, #0x4               // =4
    118c:      	str	x9, [sp, #0x30]
    1190:      	str	x9, [sp, #0xb8]
    1194:      	str	w8, [sp, #0xc0]
    1198:      	mov	w8, #0x4                // =4
    119c:      	strb	wzr, [sp, #0xc4]
    11a0:      	blr	x8
    11a4:      	ldr	x2, [sp, #0x38]
    11a8:      	mov	w8, #0x4                // =4
    11ac:      	mov	x0, x23
    11b0:      	mov	w1, #0x8                // =8
    11b4:      	blr	x8
    11b8:      	ldr	x2, [sp, #0x10]
    11bc:      	mov	w8, #0x4                // =4
    11c0:      	mov	x0, x25
    11c4:      	mov	w1, #0x8                // =8
    11c8:      	str	x25, [sp, #0x38]
    11cc:      	blr	x8
    11d0:      	ldr	x2, [sp, #0x8]
    11d4:      	mov	x0, x24
    11d8:      	mov	w1, #0x8                // =8
    11dc:      	blr	x29
    11e0:      	ldr	x8, [sp, #0xa8]
    11e4:      	sub	x8, x8, #0x20
    11e8:      	str	x8, [sp, #0xb0]
    11ec:      	adrp	x8, 0x1000 <generic_fentry_process_event+0xc70>
    11f0:      	ldr	x8, [x8]
    11f4:      	ldrb	w8, [x8]
    11f8:      	cbz	w8, 0x13a0 <generic_fentry_process_event+0x1010>
    11fc:      	adrp	x29, 0x1000 <generic_fentry_process_event+0xc70>
    1200:      	mov	w21, #0x80              // =128
    1204:      	mov	w23, #0x8               // =8
    1208:      	ldr	x29, [x29]
    120c:      	b	0x1218 <generic_fentry_process_event+0xe88>
    1210:      	subs	w21, w21, #0x1
    1214:      	b.eq	0x1550 <generic_fentry_process_event+0x11c0>
    1218:      	ldp	x25, x2, [sp, #0xa0]
    121c:      	ldp	x8, x9, [sp, #0x88]
    1220:      	cmp	x25, x8
    1224:      	ccmp	x2, x9, #0x0, eq
    1228:      	b.eq	0x1548 <generic_fentry_process_event+0x11b8>
    122c:      	ldr	x24, [sp, #0xb0]
    1230:      	mov	w8, #0x4                // =4
    1234:      	add	x9, sp, #0xc8
    1238:      	add	x0, sp, #0xc8
    123c:      	mov	w1, #0x8                // =8
    1240:      	blr	x8
    1244:      	ldr	x8, [sp, #0xc8]
    1248:      	mov	w22, #0x8               // =8
    124c:      	cmp	x25, x8
    1250:      	b.eq	0x1348 <generic_fentry_process_event+0xfb8>
    1254:      	add	x23, x25, #0x18
    1258:      	mov	w8, #0x4                // =4
    125c:      	add	x9, sp, #0xd8
    1260:      	add	x0, sp, #0xd8
    1264:      	mov	w1, #0x8                // =8
    1268:      	mov	x2, x23
    126c:      	blr	x8
    1270:      	add	x8, sp, #0xd0
    1274:      	ldr	x8, [x8, #0x8]
    1278:      	cmp	x8, x25
    127c:      	b.eq	0x1348 <generic_fentry_process_event+0xfb8>
    1280:      	mov	w8, #0x4                // =4
    1284:      	add	x9, sp, #0xd0
    1288:      	add	x0, sp, #0xd0
    128c:      	mov	w1, #0x8                // =8
    1290:      	mov	x2, x23
    1294:      	blr	x8
    1298:      	add	x2, x25, #0x20
    129c:      	mov	w8, #0x4                // =4
    12a0:      	mov	w9, #0x10               // =16
    12a4:      	add	x10, sp, #0xe0
    12a8:      	add	x0, sp, #0xe0
    12ac:      	mov	w1, #0x10               // =16
    12b0:      	blr	x8
    12b4:      	add	x8, sp, #0xd0
    12b8:      	ldr	w23, [sp, #0xe4]
    12bc:      	ldr	x10, [sp, #0xb8]
    12c0:      	add	x22, sp, #0xd0
    12c4:      	ldr	w24, [sp, #0xc0]
    12c8:      	ldr	x9, [x8, #0x18]
    12cc:      	ldr	x8, [sp, #0x98]
    12d0:      	sub	x12, x10, x8
    12d4:      	subs	w10, w23, w24
    12d8:      	csel	w10, wzr, w10, lo
    12dc:      	cmp	w24, w23
    12e0:      	csel	w11, w24, w23, lo
    12e4:      	cinc	w13, w11, hi
    12e8:      	sub	w14, w24, w13
    12ec:      	subs	x12, x12, x13
    12f0:      	str	w14, [sp, #0xc0]
    12f4:      	b.lo	0x1550 <generic_fentry_process_event+0x11c0>
    12f8:      	cmp	x12, #0xfff
    12fc:      	b.hi	0x1550 <generic_fentry_process_event+0x11c0>
    1300:      	cmp	w24, w23
    1304:      	b.ls	0x1310 <generic_fentry_process_event+0xf80>
    1308:      	mov	w13, #0x2f              // =47
    130c:      	strb	w13, [x8, x12]
    1310:      	add	x25, x8, x12
    1314:      	cmp	w24, w23
    1318:      	add	x2, x9, x10
    131c:      	and	w1, w11, #0xff
    1320:      	mov	w8, #0x4                // =4
    1324:      	cinc	x0, x25, hi
    1328:      	blr	x8
    132c:      	cmp	w24, w23
    1330:      	str	x25, [sp, #0xb8]
    1334:      	b.ls	0x1550 <generic_fentry_process_event+0x11c0>
    1338:      	ldr	x8, [x22]
    133c:      	mov	w23, #0x8               // =8
    1340:      	str	x8, [sp, #0xa0]
    1344:      	b	0x1210 <generic_fentry_process_event+0xe80>
    1348:      	add	x2, x24, #0x10
    134c:      	mov	w8, #0x4                // =4
    1350:      	add	x9, sp, #0xd8
    1354:      	add	x0, sp, #0xd8
    1358:      	mov	w1, #0x8                // =8
    135c:      	blr	x8
    1360:      	add	x9, sp, #0xd0
    1364:      	ldr	x8, [sp, #0xb0]
    1368:      	mov	w23, #0x8               // =8
    136c:      	add	x22, sp, #0xd0
    1370:      	ldr	x9, [x9, #0x8]
    1374:      	cmp	x8, x9
    1378:      	b.eq	0x1548 <generic_fentry_process_event+0x11b8>
    137c:      	ldr	x0, [sp, #0x38]
    1380:      	add	x2, x24, #0x18
    1384:      	mov	w8, #0x4                // =4
    1388:      	mov	w1, #0x8                // =8
    138c:      	blr	x8
    1390:      	ldr	x8, [x22, #0x8]
    1394:      	add	x9, x8, #0x20
    1398:      	stp	x9, x8, [sp, #0xa8]
    139c:      	b	0x1210 <generic_fentry_process_event+0xe80>
    13a0:      	adrp	x29, 0x1000 <generic_fentry_process_event+0xc70>
    13a4:      	mov	w21, #0x80              // =128
    13a8:      	mov	w23, #0x8               // =8
    13ac:      	ldr	x29, [x29]
    13b0:      	ldp	x25, x2, [sp, #0xa0]
    13b4:      	ldp	x8, x9, [sp, #0x88]
    13b8:      	cmp	x25, x8
    13bc:      	ccmp	x2, x9, #0x0, eq
    13c0:      	b.eq	0x1548 <generic_fentry_process_event+0x11b8>
    13c4:      	ldr	x24, [sp, #0xb0]
    13c8:      	mov	w8, #0x4                // =4
    13cc:      	add	x9, sp, #0xc8
    13d0:      	add	x0, sp, #0xc8
    13d4:      	mov	w1, #0x8                // =8
    13d8:      	blr	x8
    13dc:      	ldr	x8, [sp, #0xc8]
    13e0:      	mov	w22, #0x8               // =8
    13e4:      	cmp	x25, x8
    13e8:      	b.eq	0x14e8 <generic_fentry_process_event+0x1158>
    13ec:      	add	x23, x25, #0x18
    13f0:      	mov	w8, #0x4                // =4
    13f4:      	add	x9, sp, #0xd8
    13f8:      	add	x0, sp, #0xd8
    13fc:      	mov	w1, #0x8                // =8
    1400:      	mov	x2, x23
    1404:      	blr	x8
    1408:      	add	x8, sp, #0xd0
    140c:      	ldr	x8, [x8, #0x8]
    1410:      	cmp	x8, x25
    1414:      	b.eq	0x14e8 <generic_fentry_process_event+0x1158>
    1418:      	mov	w8, #0x4                // =4
    141c:      	add	x9, sp, #0xd0
    1420:      	add	x0, sp, #0xd0
    1424:      	mov	w1, #0x8                // =8
    1428:      	mov	x2, x23
    142c:      	blr	x8
    1430:      	add	x2, x25, #0x20
    1434:      	mov	w8, #0x4                // =4
    1438:      	mov	w9, #0x10               // =16
    143c:      	add	x10, sp, #0xe0
    1440:      	add	x0, sp, #0xe0
    1444:      	mov	w1, #0x10               // =16
    1448:      	blr	x8
    144c:      	add	x8, sp, #0xd0
    1450:      	ldr	w23, [sp, #0xe4]
    1454:      	ldr	x10, [sp, #0xb8]
    1458:      	add	x22, sp, #0xd0
    145c:      	ldr	w24, [sp, #0xc0]
    1460:      	ldr	x9, [x8, #0x18]
    1464:      	ldr	x8, [sp, #0x98]
    1468:      	sub	x12, x10, x8
    146c:      	subs	w10, w23, w24
    1470:      	csel	w10, wzr, w10, lo
    1474:      	cmp	w24, w23
    1478:      	csel	w11, w24, w23, lo
    147c:      	cinc	w13, w11, hi
    1480:      	sub	w14, w24, w13
    1484:      	subs	x12, x12, x13
    1488:      	str	w14, [sp, #0xc0]
    148c:      	b.lo	0x1550 <generic_fentry_process_event+0x11c0>
    1490:      	cmp	x12, #0xfff
    1494:      	b.hi	0x1550 <generic_fentry_process_event+0x11c0>
    1498:      	cmp	w24, w23
    149c:      	b.ls	0x14a8 <generic_fentry_process_event+0x1118>
    14a0:      	mov	w13, #0x2f              // =47
    14a4:      	strb	w13, [x8, x12]
    14a8:      	add	x25, x8, x12
    14ac:      	cmp	w24, w23
    14b0:      	add	x2, x9, x10
    14b4:      	and	w1, w11, #0xff
    14b8:      	mov	w8, #0x4                // =4
    14bc:      	cinc	x0, x25, hi
    14c0:      	blr	x8
    14c4:      	cmp	w24, w23
    14c8:      	str	x25, [sp, #0xb8]
    14cc:      	b.ls	0x1550 <generic_fentry_process_event+0x11c0>
    14d0:      	ldr	x8, [x22]
    14d4:      	mov	w23, #0x8               // =8
    14d8:      	str	x8, [sp, #0xa0]
    14dc:      	subs	w21, w21, #0x1
    14e0:      	b.ne	0x13b0 <generic_fentry_process_event+0x1020>
    14e4:      	b	0x1550 <generic_fentry_process_event+0x11c0>
    14e8:      	add	x2, x24, #0x10
    14ec:      	mov	w8, #0x4                // =4
    14f0:      	add	x9, sp, #0xd8
    14f4:      	add	x0, sp, #0xd8
    14f8:      	mov	w1, #0x8                // =8
    14fc:      	blr	x8
    1500:      	add	x9, sp, #0xd0
    1504:      	ldr	x8, [sp, #0xb0]
    1508:      	mov	w23, #0x8               // =8
    150c:      	add	x22, sp, #0xd0
    1510:      	ldr	x9, [x9, #0x8]
    1514:      	cmp	x8, x9
    1518:      	b.eq	0x1548 <generic_fentry_process_event+0x11b8>
    151c:      	ldr	x0, [sp, #0x38]
    1520:      	add	x2, x24, #0x18
    1524:      	mov	w8, #0x4                // =4
    1528:      	mov	w1, #0x8                // =8
    152c:      	blr	x8
    1530:      	ldr	x8, [x22, #0x8]
    1534:      	add	x9, x8, #0x20
    1538:      	stp	x9, x8, [sp, #0xa8]
    153c:      	subs	w21, w21, #0x1
    1540:      	b.ne	0x13b0 <generic_fentry_process_event+0x1020>
    1544:      	b	0x1550 <generic_fentry_process_event+0x11c0>
    1548:      	mov	w8, #0x1                // =1
    154c:      	strb	w8, [sp, #0xc4]
    1550:      	ldr	x8, [sp, #0xb8]
    1554:      	ldr	x2, [sp, #0x30]
    1558:      	cmp	x8, x2
    155c:      	b.eq	0x1598 <generic_fentry_process_event+0x1208>
    1560:      	ldrb	w9, [sp, #0xc4]
    1564:      	mov	w11, #0x1000            // =4096
    1568:      	cmp	w9, #0x0
    156c:      	ldr	w9, [sp, #0xc0]
    1570:      	cset	w10, eq
    1574:      	sub	w11, w11, w9
    1578:      	cmp	w9, #0x0
    157c:      	csel	w9, w11, w9, gt
    1580:      	cbz	x8, 0x1590 <generic_fentry_process_event+0x1200>
    1584:      	lsl	w21, w10, #1
    1588:      	mov	x2, x8
    158c:      	b	0x15a0 <generic_fentry_process_event+0x1210>
    1590:      	mov	x25, xzr
    1594:      	b	0x3b2c <generic_fentry_process_event+0x379c>
    1598:      	mov	w9, wzr
    159c:      	mov	w21, wzr
    15a0:      	ldr	x22, [sp, #0x18]
    15a4:      	and	w23, w9, #0xfff
    15a8:      	mov	w8, #0x4                // =4
    15ac:      	mov	w24, #0x4               // =4
    15b0:      	mov	w1, w23
    15b4:      	add	x0, x22, #0x4
    15b8:      	blr	x8
    15bc:      	str	w23, [x22]
    15c0:      	ldr	x2, [sp, #0x10]
    15c4:      	mov	w25, #0x8               // =8
    15c8:      	add	x8, sp, #0x88
    15cc:      	mov	w9, #0x4                // =4
    15d0:      	add	x0, sp, #0x88
    15d4:      	mov	w1, #0x8                // =8
    15d8:      	blr	x9
    15dc:      	ldr	x8, [sp, #0x88]
    15e0:      	add	x9, sp, #0xe0
    15e4:      	mov	w10, #0x4               // =4
    15e8:      	add	x0, sp, #0xe0
    15ec:      	mov	w1, #0x8                // =8
    15f0:      	add	x8, x8, #0x30
    15f4:      	ldr	x8, [sp, #0x88]
    15f8:      	add	x2, x8, #0x30
    15fc:      	blr	x10
    1600:      	add	x11, sp, #0xd0
    1604:      	mov	w9, #0x2                // =2
    1608:      	add	x10, sp, #0xd8
    160c:      	ldr	x8, [x11, #0x10]
    1610:      	add	x0, sp, #0xd8
    1614:      	mov	w1, #0x2                // =2
    1618:      	ldr	x2, [x11, #0x10]
    161c:      	blr	x24
    1620:      	add	x8, x22, x23
    1624:      	add	w25, w23, #0xa
    1628:      	str	w21, [x8, #0x4]
    162c:      	ldrh	w9, [sp, #0xd8]
    1630:      	strh	w9, [x8, #0x8]
    1634:      	ldp	x10, x12, [sp, #0x20]
    1638:      	b	0x3b24 <generic_fentry_process_event+0x3794>
    163c:      	mov	w8, #0x8                // =8
    1640:      	mov	w9, #0x4                // =4
    1644:      	add	x10, sp, #0xe0
    1648:      	add	x11, sp, #0x88
    164c:      	add	x0, sp, #0xe0
    1650:      	add	x2, sp, #0x88
    1654:      	mov	w1, #0x8                // =8
    1658:      	blr	x9
    165c:      	ldr	x25, [x22, #0x10]
    1660:      	cbnz	x25, 0x1064 <generic_fentry_process_event+0xcd4>
    1664:      	str	wzr, [sp, #0x80]
    1668:      	adrp	x0, 0x1000 <generic_fentry_process_event+0xc70>
    166c:      	mov	w8, #0x1                // =1
    1670:      	add	x9, sp, #0x80
    1674:      	ldr	x0, [x0]
    1678:      	add	x1, sp, #0x80
    167c:      	blr	x8
    1680:      	mov	x25, xzr
    1684:      	cbz	x0, 0x3b1c <generic_fentry_process_event+0x378c>
    1688:      	cmp	w24, #0x19
    168c:      	b.gt	0x197c <generic_fentry_process_event+0x15ec>
    1690:      	add	x9, sp, #0xd0
    1694:      	cmp	w24, #0x12
    1698:      	str	x0, [sp, #0x10]
    169c:      	b.le	0x1a70 <generic_fentry_process_event+0x16e0>
    16a0:      	cmp	w24, #0x14
    16a4:      	b.le	0x1d50 <generic_fentry_process_event+0x19c0>
    16a8:      	cmp	w24, #0x15
    16ac:      	b.eq	0x2548 <generic_fentry_process_event+0x21b8>
    16b0:      	cmp	w24, #0x16
    16b4:      	b.eq	0x24e8 <generic_fentry_process_event+0x2158>
    16b8:      	adrp	x29, 0x1000 <generic_fentry_process_event+0xc70>
    16bc:      	cmp	w24, #0x17
    16c0:      	ldr	x29, [x29]
    16c4:      	ldr	x12, [sp, #0x28]
    16c8:      	b.ne	0x3b20 <generic_fentry_process_event+0x3790>
    16cc:      	ldr	x8, [sp, #0x18]
    16d0:      	ldr	x9, [sp, #0x38]
    16d4:      	mov	w25, #0x8               // =8
    16d8:      	stp	w9, wzr, [x8]
    16dc:      	b	0x3b20 <generic_fentry_process_event+0x3790>
    16e0:      	cmp	w24, #0x2c
    16e4:      	b.hi	0x1664 <generic_fentry_process_event+0x12d4>
    16e8:      	mov	x9, #0x7cf2             // =31986
    16ec:      	mov	w8, #0x1                // =1
    16f0:      	movk	x9, #0xf202, lsl #16
    16f4:      	lsl	x8, x8, x24
    16f8:      	movk	x9, #0x11c1, lsl #32
    16fc:      	tst	x8, x9
    1700:      	b.eq	0x1664 <generic_fentry_process_event+0x12d4>
    1704:      	str	x11, [x22]
    1708:      	str	wzr, [sp, #0x80]
    170c:      	adrp	x0, 0x1000 <generic_fentry_process_event+0xc70>
    1710:      	mov	w8, #0x1                // =1
    1714:      	add	x9, sp, #0x80
    1718:      	add	x1, sp, #0x80
    171c:      	ldr	x0, [x0]
    1720:      	blr	x8
    1724:      	mov	x25, xzr
    1728:      	cbz	x0, 0x1634 <generic_fentry_process_event+0x12a4>
    172c:      	ldr	x12, [sp, #0x28]
    1730:      	cmp	w24, #0x10
    1734:      	b.le	0x178c <generic_fentry_process_event+0x13fc>
    1738:      	add	x11, sp, #0xd0
    173c:      	cmp	w24, #0x1e
    1740:      	b.le	0x18a8 <generic_fentry_process_event+0x1518>
    1744:      	mov	x21, x29
    1748:      	cmp	w24, #0x26
    174c:      	b.gt	0x19ac <generic_fentry_process_event+0x161c>
    1750:      	sub	w8, w24, #0x1f
    1754:      	cmp	w8, #0x2
    1758:      	b.hs	0x1e08 <generic_fentry_process_event+0x1a78>
    175c:      	ldr	x0, [sp, #0x18]
    1760:      	mov	w8, #0x1                // =1
    1764:      	add	x9, sp, #0xd0
    1768:      	mov	w10, #0x4               // =4
    176c:      	add	x2, sp, #0xd0
    1770:      	mov	w1, #0x1                // =1
    1774:      	mov	w25, #0x4               // =4
    1778:      	blr	x10
    177c:      	mov	x29, x21
    1780:      	b	0x3b1c <generic_fentry_process_event+0x378c>
    1784:      	mov	w10, #0x5               // =5
    1788:      	b	0xa9c <generic_fentry_process_event+0x70c>
    178c:      	cmp	w24, #0x9
    1790:      	b.gt	0x18cc <generic_fentry_process_event+0x153c>
    1794:      	cmp	w24, #0x4
    1798:      	b.le	0x1b04 <generic_fentry_process_event+0x1774>
    179c:      	cmp	w24, #0x5
    17a0:      	b.eq	0x2108 <generic_fentry_process_event+0x1d78>
    17a4:      	cmp	w24, #0x6
    17a8:      	b.eq	0x1934 <generic_fentry_process_event+0x15a4>
    17ac:      	adrp	x29, 0x1000 <generic_fentry_process_event+0xc70>
    17b0:      	cmp	w24, #0x7
    17b4:      	mov	w9, #0x5ea0             // =24224
    17b8:      	ldr	x29, [x29]
    17bc:      	ldp	x10, x12, [sp, #0x20]
    17c0:      	b.ne	0x3b28 <generic_fentry_process_event+0x3798>
    17c4:      	add	x8, sp, #0xd0
    17c8:      	ldr	x22, [sp, #0x18]
    17cc:      	mov	x21, x0
    17d0:      	mov	w25, #0x2               // =2
    17d4:      	ldr	x23, [x8]
    17d8:      	mov	w8, #0x4                // =4
    17dc:      	mov	w1, #0x2                // =2
    17e0:      	mov	w24, #0x4               // =4
    17e4:      	str	x23, [x22, #0x28]
    17e8:      	add	x0, x22, #0x26
    17ec:      	add	x2, x23, #0x10
    17f0:      	blr	x8
    17f4:      	add	x0, x22, #0x3a
    17f8:      	add	x2, x23, #0x12
    17fc:      	mov	w8, #0x1                // =1
    1800:      	mov	w9, #0x4                // =4
    1804:      	mov	w1, #0x1                // =1
    1808:      	blr	x9
    180c:      	add	x0, x22, #0x38
    1810:      	add	x2, x23, #0x21e
    1814:      	mov	w8, #0x4                // =4
    1818:      	mov	w1, #0x2                // =2
    181c:      	blr	x8
    1820:      	add	x0, x22, #0x24
    1824:      	add	x2, x23, #0x21c
    1828:      	mov	w8, #0x4                // =4
    182c:      	mov	w1, #0x2                // =2
    1830:      	blr	x8
    1834:      	add	x0, x22, #0x30
    1838:      	add	x2, x23, #0x214
    183c:      	mov	w8, #0x4                // =4
    1840:      	mov	w1, #0x4                // =4
    1844:      	blr	x8
    1848:      	add	x0, x22, #0x34
    184c:      	add	x2, x23, #0x210
    1850:      	mov	w1, #0x4                // =4
    1854:      	blr	x24
    1858:      	ldrh	w8, [x22, #0x26]
    185c:      	mov	x24, x22
    1860:      	stp	xzr, xzr, [x22]
    1864:      	cmp	w8, #0xa
    1868:      	str	xzr, [x22, #0x18]
    186c:      	str	xzr, [x24, #0x10]!
    1870:      	b.eq	0x2820 <generic_fentry_process_event+0x2490>
    1874:      	cmp	w8, #0x2
    1878:      	b.ne	0x284c <generic_fentry_process_event+0x24bc>
    187c:      	ldr	x0, [sp, #0x18]
    1880:      	add	x2, x23, #0x4
    1884:      	mov	w8, #0x4                // =4
    1888:      	mov	w1, #0x4                // =4
    188c:      	mov	w25, #0x4               // =4
    1890:      	blr	x8
    1894:      	mov	x0, x24
    1898:      	mov	w1, #0x4                // =4
    189c:      	mov	x2, x23
    18a0:      	blr	x25
    18a4:      	b	0x284c <generic_fentry_process_event+0x24bc>
    18a8:      	cmp	w24, #0x1c
    18ac:      	str	x0, [sp, #0x38]
    18b0:      	b.gt	0x1ae0 <generic_fentry_process_event+0x1750>
    18b4:      	cmp	w24, #0x11
    18b8:      	b.eq	0x1e40 <generic_fentry_process_event+0x1ab0>
    18bc:      	cmp	w24, #0x19
    18c0:      	b.eq	0x1ef4 <generic_fentry_process_event+0x1b64>
    18c4:      	cmp	w24, #0x1c
    18c8:      	b	0x1b18 <generic_fentry_process_event+0x1788>
    18cc:      	sub	w8, w24, #0xa
    18d0:      	cmp	w8, #0x2
    18d4:      	b.lo	0x1b24 <generic_fentry_process_event+0x1794>
    18d8:      	sub	w8, w24, #0xc
    18dc:      	cmp	w8, #0x2
    18e0:      	b.lo	0x1b50 <generic_fentry_process_event+0x17c0>
    18e4:      	adrp	x29, 0x1000 <generic_fentry_process_event+0xc70>
    18e8:      	cmp	w24, #0xe
    18ec:      	mov	w9, #0x5ea0             // =24224
    18f0:      	ldr	x29, [x29]
    18f4:      	ldp	x10, x12, [sp, #0x20]
    18f8:      	b.ne	0x3b28 <generic_fentry_process_event+0x3798>
    18fc:      	mov	w21, #0x8               // =8
    1900:      	add	x8, sp, #0x88
    1904:      	add	x24, sp, #0xd0
    1908:      	mov	w9, #0x4                // =4
    190c:      	add	x0, sp, #0x88
    1910:      	add	x2, sp, #0xd0
    1914:      	mov	w1, #0x8                // =8
    1918:      	mov	w23, #0x4               // =4
    191c:      	blr	x9
    1920:      	ldr	x8, [sp, #0x88]
    1924:      	add	x0, sp, #0xd0
    1928:      	mov	w1, #0x8                // =8
    192c:      	ldr	x2, [sp, #0x88]
    1930:      	blr	x23
    1934:      	add	x8, sp, #0xd0
    1938:      	mov	w9, #0x2d               // =45
    193c:      	mov	w1, #0x1001             // =4097
    1940:      	ldr	x2, [x8]
    1944:      	ldr	x8, [sp, #0x18]
    1948:      	add	x0, x8, #0x4
    194c:      	mov	w8, #0x1001             // =4097
    1950:      	blr	x9
    1954:      	mov	x25, x0
    1958:      	tbnz	x0, #0x3f, 0x3b14 <generic_fentry_process_event+0x3784>
    195c:      	ldr	x9, [sp, #0x18]
    1960:      	sub	w8, w25, #0x1
    1964:      	add	x25, x25, #0x3
    1968:      	str	w8, [x9]
    196c:      	b	0x3b14 <generic_fentry_process_event+0x3784>
    1970:      	mov	w10, #0x6               // =6
    1974:      	mov	x11, x22
    1978:      	b	0xa9c <generic_fentry_process_event+0x70c>
    197c:      	cmp	w24, #0x20
    1980:      	b.le	0x1c90 <generic_fentry_process_event+0x1900>
    1984:      	sub	w8, w24, #0x21
    1988:      	cmp	w8, #0x4
    198c:      	b.hs	0x1b70 <generic_fentry_process_event+0x17e0>
    1990:      	ldr	x0, [sp, #0x18]
    1994:      	ldr	x2, [sp, #0x38]
    1998:      	mov	w25, #0x8               // =8
    199c:      	mov	w8, #0x4                // =4
    19a0:      	mov	w1, #0x8                // =8
    19a4:      	blr	x8
    19a8:      	b	0x3b14 <generic_fentry_process_event+0x3784>
    19ac:      	cmp	w24, #0x27
    19b0:      	b.eq	0x2264 <generic_fentry_process_event+0x1ed4>
    19b4:      	cmp	w24, #0x28
    19b8:      	b.eq	0x22a4 <generic_fentry_process_event+0x1f14>
    19bc:      	ldp	x10, x12, [sp, #0x20]
    19c0:      	cmp	w24, #0x2c
    19c4:      	mov	x29, x21
    19c8:      	mov	w9, #0x5ea0             // =24224
    19cc:      	b.ne	0x3b28 <generic_fentry_process_event+0x3798>
    19d0:      	ldr	x0, [sp, #0x18]
    19d4:      	ldr	x23, [x11]
    19d8:      	mov	w8, #0x2                // =2
    19dc:      	mov	w9, #0x4                // =4
    19e0:      	mov	w1, #0x2                // =2
    19e4:      	mov	x2, x23
    19e8:      	strb	wzr, [sp, #0x88]
    19ec:      	stp	xzr, xzr, [x0]
    19f0:      	stp	xzr, xzr, [x0, #0x10]
    19f4:      	stp	xzr, xzr, [x0, #0x20]
    19f8:      	stp	xzr, xzr, [x0, #0x30]
    19fc:      	stp	xzr, xzr, [x0, #0x40]
    1a00:      	stp	xzr, xzr, [x0, #0x50]
    1a04:      	stp	xzr, xzr, [x0, #0x60]
    1a08:      	blr	x9
    1a0c:      	tbnz	x0, #0x3f, 0x2a34 <generic_fentry_process_event+0x26a4>
    1a10:      	add	x24, x23, #0x2
    1a14:      	mov	w8, #0x1                // =1
    1a18:      	mov	w9, #0x4                // =4
    1a1c:      	add	x10, sp, #0x88
    1a20:      	add	x0, sp, #0x88
    1a24:      	mov	w1, #0x1                // =1
    1a28:      	mov	x2, x24
    1a2c:      	blr	x9
    1a30:      	tbnz	x0, #0x3f, 0x2a34 <generic_fentry_process_event+0x26a4>
    1a34:      	ldrb	w8, [sp, #0x88]
    1a38:      	ldr	x10, [sp, #0x18]
    1a3c:      	cmp	w8, #0x0
    1a40:      	add	x0, x10, #0x4
    1a44:      	cset	w9, eq
    1a48:      	strb	w9, [x10, #0x2]
    1a4c:      	cbz	w8, 0x2a14 <generic_fentry_process_event+0x2684>
    1a50:      	mov	w8, #0x6c               // =108
    1a54:      	mov	w9, #0x2d               // =45
    1a58:      	mov	w1, #0x6c               // =108
    1a5c:      	mov	x2, x24
    1a60:      	blr	x9
    1a64:      	tbnz	w0, #0x1f, 0x2a34 <generic_fentry_process_event+0x26a4>
    1a68:      	sub	w22, w0, #0x1
    1a6c:      	b	0x2a2c <generic_fentry_process_event+0x269c>
    1a70:      	cmp	w24, #0x7
    1a74:      	b.gt	0x1d10 <generic_fentry_process_event+0x1980>
    1a78:      	cmp	w24, #0x2
    1a7c:      	b.eq	0x231c <generic_fentry_process_event+0x1f8c>
    1a80:      	adrp	x29, 0x1000 <generic_fentry_process_event+0xc70>
    1a84:      	cmp	w24, #0x3
    1a88:      	ldr	x29, [x29]
    1a8c:      	ldr	x12, [sp, #0x28]
    1a90:      	b.ne	0x3b20 <generic_fentry_process_event+0x3790>
    1a94:      	ldr	x8, [sp, #0x10]
    1a98:      	add	x24, x8, #0x90
    1a9c:      	and	w8, w21, #0xf
    1aa0:      	add	x22, x24, x23
    1aa4:      	cmp	w8, #0x2
    1aa8:      	b.le	0x29a8 <generic_fentry_process_event+0x2618>
    1aac:      	cmp	w8, #0x3
    1ab0:      	b.eq	0x2b70 <generic_fentry_process_event+0x27e0>
    1ab4:      	cmp	w8, #0x4
    1ab8:      	b.eq	0x2b78 <generic_fentry_process_event+0x27e8>
    1abc:      	cmp	w8, #0x5
    1ac0:      	b.ne	0x2bd0 <generic_fentry_process_event+0x2840>
    1ac4:      	mov	w9, #0x5e70             // =24176
    1ac8:      	b	0x2b84 <generic_fentry_process_event+0x27f4>
    1acc:      	mov	w10, #0x7               // =7
    1ad0:      	adrp	x29, 0x1000 <generic_fentry_process_event+0xc70>
    1ad4:      	mov	x11, x22
    1ad8:      	ldr	x29, [x29]
    1adc:      	b	0xa9c <generic_fentry_process_event+0x70c>
    1ae0:      	ldr	x0, [sp, #0x18]
    1ae4:      	mov	w8, #0x2                // =2
    1ae8:      	add	x9, sp, #0xd0
    1aec:      	mov	w10, #0x4               // =4
    1af0:      	add	x2, sp, #0xd0
    1af4:      	mov	w1, #0x2                // =2
    1af8:      	mov	w25, #0x4               // =4
    1afc:      	blr	x10
    1b00:      	b	0x3b1c <generic_fentry_process_event+0x378c>
    1b04:      	cmp	w24, #0x1
    1b08:      	b.eq	0x1b50 <generic_fentry_process_event+0x17c0>
    1b0c:      	adrp	x29, 0x1000 <generic_fentry_process_event+0xc70>
    1b10:      	cmp	w24, #0x4
    1b14:      	ldr	x29, [x29]
    1b18:      	ldp	x10, x12, [sp, #0x20]
    1b1c:      	mov	w9, #0x5ea0             // =24224
    1b20:      	b.ne	0x3b28 <generic_fentry_process_event+0x3798>
    1b24:      	ldr	x0, [sp, #0x18]
    1b28:      	mov	w25, #0x8               // =8
    1b2c:      	mov	w8, #0x4                // =4
    1b30:      	add	x9, sp, #0xd0
    1b34:      	add	x2, sp, #0xd0
    1b38:      	mov	w1, #0x8                // =8
    1b3c:      	mov	x21, x12
    1b40:      	blr	x8
    1b44:      	ldr	x10, [sp, #0x20]
    1b48:      	mov	x12, x21
    1b4c:      	b	0x3b24 <generic_fentry_process_event+0x3794>
    1b50:      	ldr	x0, [sp, #0x18]
    1b54:      	add	x8, sp, #0xd0
    1b58:      	mov	w9, #0x4                // =4
    1b5c:      	add	x2, sp, #0xd0
    1b60:      	mov	w1, #0x4                // =4
    1b64:      	mov	w25, #0x4               // =4
    1b68:      	blr	x9
    1b6c:      	b	0x3b14 <generic_fentry_process_event+0x3784>
    1b70:      	cmp	w24, #0x2b
    1b74:      	b.eq	0x2604 <generic_fentry_process_event+0x2274>
    1b78:      	adrp	x29, 0x1000 <generic_fentry_process_event+0xc70>
    1b7c:      	cmp	w24, #0x29
    1b80:      	ldr	x29, [x29]
    1b84:      	ldr	x12, [sp, #0x28]
    1b88:      	b.ne	0x3b20 <generic_fentry_process_event+0x3790>
    1b8c:      	ldr	x8, [sp, #0x38]
    1b90:      	mov	w9, #0x4                // =4
    1b94:      	add	x10, sp, #0x88
    1b98:      	mov	x21, x0
    1b9c:      	add	x0, sp, #0x88
    1ba0:      	mov	w1, #0x8                // =8
    1ba4:      	add	x2, x8, #0x18
    1ba8:      	mov	w8, #0x8                // =8
    1bac:      	blr	x9
    1bb0:      	ldr	x23, [sp, #0x88]
    1bb4:      	cbz	x23, 0x2b2c <generic_fentry_process_event+0x279c>
    1bb8:      	ldr	x22, [sp, #0x18]
    1bbc:      	add	x2, x23, #0x10
    1bc0:      	mov	w25, #0x2               // =2
    1bc4:      	mov	w8, #0x4                // =4
    1bc8:      	str	x23, [x22, #0x28]
    1bcc:      	add	x0, x22, #0x26
    1bd0:      	mov	w1, #0x2                // =2
    1bd4:      	mov	w24, #0x4               // =4
    1bd8:      	blr	x8
    1bdc:      	add	x0, x22, #0x3a
    1be0:      	add	x2, x23, #0x12
    1be4:      	mov	w8, #0x1                // =1
    1be8:      	mov	w9, #0x4                // =4
    1bec:      	mov	w1, #0x1                // =1
    1bf0:      	blr	x9
    1bf4:      	add	x0, x22, #0x38
    1bf8:      	add	x2, x23, #0x21e
    1bfc:      	mov	w8, #0x4                // =4
    1c00:      	mov	w1, #0x2                // =2
    1c04:      	blr	x8
    1c08:      	add	x0, x22, #0x24
    1c0c:      	add	x2, x23, #0x21c
    1c10:      	mov	w8, #0x4                // =4
    1c14:      	mov	w1, #0x2                // =2
    1c18:      	blr	x8
    1c1c:      	add	x0, x22, #0x30
    1c20:      	add	x2, x23, #0x214
    1c24:      	mov	w8, #0x4                // =4
    1c28:      	mov	w1, #0x4                // =4
    1c2c:      	blr	x8
    1c30:      	add	x0, x22, #0x34
    1c34:      	add	x2, x23, #0x210
    1c38:      	mov	w1, #0x4                // =4
    1c3c:      	blr	x24
    1c40:      	ldrh	w8, [x22, #0x26]
    1c44:      	mov	x24, x22
    1c48:      	stp	xzr, xzr, [x22]
    1c4c:      	cmp	w8, #0xa
    1c50:      	str	xzr, [x22, #0x18]
    1c54:      	str	xzr, [x24, #0x10]!
    1c58:      	b.eq	0x2abc <generic_fentry_process_event+0x272c>
    1c5c:      	cmp	w8, #0x2
    1c60:      	b.ne	0x2ae8 <generic_fentry_process_event+0x2758>
    1c64:      	ldr	x0, [sp, #0x18]
    1c68:      	add	x2, x23, #0x4
    1c6c:      	mov	w8, #0x4                // =4
    1c70:      	mov	w1, #0x4                // =4
    1c74:      	mov	w25, #0x4               // =4
    1c78:      	blr	x8
    1c7c:      	mov	x0, x24
    1c80:      	mov	w1, #0x4                // =4
    1c84:      	mov	x2, x23
    1c88:      	blr	x25
    1c8c:      	b	0x2ae8 <generic_fentry_process_event+0x2758>
    1c90:      	cmp	w24, #0x1a
    1c94:      	b.eq	0x2694 <generic_fentry_process_event+0x2304>
    1c98:      	adrp	x29, 0x1000 <generic_fentry_process_event+0xc70>
    1c9c:      	cmp	w24, #0x1b
    1ca0:      	ldr	x29, [x29]
    1ca4:      	ldr	x12, [sp, #0x28]
    1ca8:      	b.ne	0x3b20 <generic_fentry_process_event+0x3790>
    1cac:      	ldr	x10, [sp, #0x18]
    1cb0:      	ldr	x8, [sp, #0x38]
    1cb4:      	mov	w9, #0x2d               // =45
    1cb8:      	mov	w1, #0x3f               // =63
    1cbc:      	mov	x0, x10
    1cc0:      	stp	xzr, xzr, [x10, #0x40]
    1cc4:      	stp	xzr, xzr, [x10, #0x30]
    1cc8:      	stp	xzr, xzr, [x10, #0x20]
    1ccc:      	str	xzr, [x10, #0x18]
    1cd0:      	stp	xzr, xzr, [x10]
    1cd4:      	add	x2, x8, #0x18
    1cd8:      	mov	w8, #0x3f               // =63
    1cdc:      	str	xzr, [x0, #0x10]!
    1ce0:      	blr	x9
    1ce4:      	tbnz	x0, #0x3f, 0x28d8 <generic_fentry_process_event+0x2548>
    1ce8:      	ldr	x8, [sp, #0x18]
    1cec:      	mov	w9, #0x4                // =4
    1cf0:      	mov	w1, #0x8                // =8
    1cf4:      	add	x0, x8, #0x8
    1cf8:      	ldr	x8, [sp, #0x38]
    1cfc:      	add	x2, x8, #0x360
    1d00:      	mov	w8, #0x8                // =8
    1d04:      	blr	x9
    1d08:      	mov	w25, #0x50              // =80
    1d0c:      	b	0x3b14 <generic_fentry_process_event+0x3784>
    1d10:      	cmp	w24, #0x8
    1d14:      	b.eq	0x236c <generic_fentry_process_event+0x1fdc>
    1d18:      	adrp	x29, 0x1000 <generic_fentry_process_event+0xc70>
    1d1c:      	cmp	w24, #0x12
    1d20:      	ldr	x29, [x29]
    1d24:      	ldr	x12, [sp, #0x28]
    1d28:      	b.ne	0x3b20 <generic_fentry_process_event+0x3790>
    1d2c:      	ldp	x8, x2, [sp, #0x30]
    1d30:      	mov	x21, x12
    1d34:      	and	x25, x8, #0x3ff
    1d38:      	ldr	x0, [sp, #0x18]
    1d3c:      	mov	w8, #0x4                // =4
    1d40:      	mov	w1, w25
    1d44:      	blr	x8
    1d48:      	mov	x12, x21
    1d4c:      	b	0x3b20 <generic_fentry_process_event+0x3790>
    1d50:      	cmp	w24, #0x13
    1d54:      	b.eq	0x25c0 <generic_fentry_process_event+0x2230>
    1d58:      	adrp	x29, 0x1000 <generic_fentry_process_event+0xc70>
    1d5c:      	cmp	w24, #0x14
    1d60:      	ldr	x29, [x29]
    1d64:      	ldr	x12, [sp, #0x28]
    1d68:      	b.ne	0x3b20 <generic_fentry_process_event+0x3790>
    1d6c:      	ldr	x22, [sp, #0x38]
    1d70:      	str	xzr, [sp, #0x88]
    1d74:      	mov	w10, #0x8               // =8
    1d78:      	add	x8, sp, #0x88
    1d7c:      	mov	w9, #0x4                // =4
    1d80:      	add	x0, sp, #0x88
    1d84:      	mov	w1, #0x8                // =8
    1d88:      	mov	w21, #0x4               // =4
    1d8c:      	mov	x24, x12
    1d90:      	add	x2, x22, #0x110
    1d94:      	add	x23, x22, #0xd8
    1d98:      	blr	x9
    1d9c:      	ldr	x8, [sp, #0x88]
    1da0:      	mov	w9, #0x80               // =128
    1da4:      	mov	w10, #0x2d              // =45
    1da8:      	ldr	x25, [sp, #0x18]
    1dac:      	mov	w1, #0x80               // =128
    1db0:      	mov	x0, x25
    1db4:      	ldr	x2, [sp, #0x88]
    1db8:      	blr	x10
    1dbc:      	add	x0, x25, #0x90
    1dc0:      	mov	w8, #0x4                // =4
    1dc4:      	mov	w1, #0x4                // =4
    1dc8:      	mov	x2, x23
    1dcc:      	blr	x8
    1dd0:      	add	x0, x25, #0x80
    1dd4:      	add	x2, x22, #0xe0
    1dd8:      	mov	w8, #0x4                // =4
    1ddc:      	mov	w9, #0x8                // =8
    1de0:      	mov	w1, #0x8                // =8
    1de4:      	mov	w23, #0x8               // =8
    1de8:      	blr	x8
    1dec:      	add	x0, x25, #0x88
    1df0:      	add	x2, x22, #0x118
    1df4:      	mov	w1, #0x8                // =8
    1df8:      	blr	x21
    1dfc:      	mov	x12, x24
    1e00:      	mov	w25, #0x98              // =152
    1e04:      	b	0x3b20 <generic_fentry_process_event+0x3790>
    1e08:      	ldp	x10, x12, [sp, #0x20]
    1e0c:      	cmp	w24, #0x26
    1e10:      	mov	x29, x21
    1e14:      	mov	w9, #0x5ea0             // =24224
    1e18:      	b.ne	0x3b28 <generic_fentry_process_event+0x3798>
    1e1c:      	ldr	x8, [x11]
    1e20:      	ldr	x9, [sp, #0x18]
    1e24:      	add	x2, x19, w8, uxth
    1e28:      	ubfx	w8, w8, #16, #12
    1e2c:      	add	x0, x9, #0x4
    1e30:      	add	w1, w8, #0x1
    1e34:      	mov	w8, #0x2d               // =45
    1e38:      	blr	x8
    1e3c:      	b	0x2284 <generic_fentry_process_event+0x1ef4>
    1e40:      	str	xzr, [sp, #0x90]
    1e44:      	mov	w8, #0xe                // =14
    1e48:      	blr	x8
    1e4c:      	lsr	x8, x0, #32
    1e50:      	add	x9, sp, #0xe0
    1e54:      	add	x10, sp, #0xd0
    1e58:      	str	x8, [sp, #0x88]
    1e5c:      	mov	w8, #0x4                // =4
    1e60:      	add	x0, sp, #0xe0
    1e64:      	add	x2, sp, #0xd0
    1e68:      	mov	w1, #0x4                // =4
    1e6c:      	blr	x8
    1e70:      	ldr	w8, [sp, #0xe0]
    1e74:      	adrp	x0, 0x1000 <generic_fentry_process_event+0xc70>
    1e78:      	add	x9, sp, #0x88
    1e7c:      	add	x1, sp, #0x88
    1e80:      	str	w8, [sp, #0x90]
    1e84:      	mov	w8, #0x1                // =1
    1e88:      	ldr	x0, [x0]
    1e8c:      	blr	x8
    1e90:      	cbz	x0, 0x2790 <generic_fentry_process_event+0x2400>
    1e94:      	ldr	x25, [sp, #0x18]
    1e98:      	ldr	w21, [x0]
    1e9c:      	add	x8, sp, #0xe0
    1ea0:      	mov	w9, #0x4                // =4
    1ea4:      	mov	x23, x0
    1ea8:      	add	x2, sp, #0xe0
    1eac:      	mov	w1, #0x4                // =4
    1eb0:      	mov	w24, #0x4               // =4
    1eb4:      	mov	x0, x25
    1eb8:      	blr	x9
    1ebc:      	and	x21, x21, #0xfff
    1ec0:      	add	x0, x25, #0x4
    1ec4:      	mov	w8, #0x4                // =4
    1ec8:      	mov	x2, x23
    1ecc:      	add	x1, x21, #0x4
    1ed0:      	blr	x8
    1ed4:      	add	w21, w21, #0x8
    1ed8:      	mov	w1, #0x4                // =4
    1edc:      	add	x8, x21, x23
    1ee0:      	add	x0, x25, x21
    1ee4:      	sub	x2, x8, #0x4
    1ee8:      	blr	x24
    1eec:      	add	x25, x21, #0x4
    1ef0:      	b	0x3b1c <generic_fentry_process_event+0x378c>
    1ef4:      	ldr	x24, [x11]
    1ef8:      	mov	w8, #0x1                // =1
    1efc:      	mov	w9, #0x4                // =4
    1f00:      	add	x10, sp, #0x78
    1f04:      	add	x0, sp, #0x78
    1f08:      	mov	w1, #0x1                // =1
    1f0c:      	mov	x2, x24
    1f10:      	blr	x9
    1f14:      	ldrb	w8, [sp, #0x78]
    1f18:      	cmp	w8, #0x1
    1f1c:      	b.ne	0x2774 <generic_fentry_process_event+0x23e4>
    1f20:      	add	x2, x24, #0x10
    1f24:      	mov	w24, #0x8               // =8
    1f28:      	add	x8, sp, #0xe0
    1f2c:      	mov	w9, #0x4                // =4
    1f30:      	add	x0, sp, #0xe0
    1f34:      	mov	w1, #0x8                // =8
    1f38:      	mov	w25, #0x4               // =4
    1f3c:      	blr	x9
    1f40:      	add	x22, sp, #0xd0
    1f44:      	add	x8, sp, #0x60
    1f48:      	mov	w9, #0x4                // =4
    1f4c:      	ldr	x2, [x22, #0x10]
    1f50:      	add	x0, sp, #0x60
    1f54:      	mov	w1, #0x8                // =8
    1f58:      	blr	x9
    1f5c:      	ldr	x8, [x22, #0x10]
    1f60:      	add	x0, sp, #0xd8
    1f64:      	mov	w1, #0x8                // =8
    1f68:      	add	x2, x8, #0x8
    1f6c:      	add	x8, sp, #0xd8
    1f70:      	blr	x25
    1f74:      	ldr	x8, [sp, #0x38]
    1f78:      	ldr	x10, [sp, #0x60]
    1f7c:      	add	x8, x8, #0x90
    1f80:      	ldr	x22, [x22, #0x8]
    1f84:      	add	x9, x8, x23
    1f88:      	stp	x10, x9, [sp, #0x30]
    1f8c:      	tbz	w21, #0x5, 0x2a5c <generic_fentry_process_event+0x26cc>
    1f90:      	cmp	x22, #0x1, lsl #12      // =0x1000
    1f94:      	b.lo	0x2a40 <generic_fentry_process_event+0x26b0>
    1f98:      	ldr	x9, [sp, #0x38]
    1f9c:      	mov	w8, #0x1                // =1
    1fa0:      	adrp	x0, 0x1000 <generic_fentry_process_event+0xc70>
    1fa4:      	add	x1, sp, #0xc8
    1fa8:      	str	w8, [x9]
    1fac:      	str	wzr, [sp, #0xc8]
    1fb0:      	add	x9, sp, #0xc8
    1fb4:      	ldr	x0, [x0]
    1fb8:      	blr	x8
    1fbc:      	str	x0, [sp, #0x18]
    1fc0:      	cbz	x0, 0x2d40 <generic_fentry_process_event+0x29b0>
    1fc4:      	ldr	x23, [sp, #0x18]
    1fc8:      	mov	w8, #0x18               // =24
    1fcc:      	str	w8, [x23]
    1fd0:      	mov	w8, #0xe                // =14
    1fd4:      	blr	x8
    1fd8:      	str	x0, [x23, #0x10]!
    1fdc:      	cmn	x0, #0x16
    1fe0:      	b.ne	0x2008 <generic_fentry_process_event+0x1c78>
    1fe4:      	add	x2, x19, #0xe8
    1fe8:      	mov	w8, #0x8                // =8
    1fec:      	mov	w9, #0x4                // =4
    1ff0:      	add	x10, sp, #0x88
    1ff4:      	add	x0, sp, #0x88
    1ff8:      	mov	w1, #0x8                // =8
    1ffc:      	blr	x9
    2000:      	ldr	x8, [sp, #0x88]
    2004:      	str	x8, [x23]
    2008:      	mov	w8, #0x7d               // =125
    200c:      	blr	x8
    2010:      	ldr	x8, [sp, #0x18]
    2014:      	ldr	x10, [sp, #0x38]
    2018:      	mov	x21, xzr
    201c:      	mov	w25, #0xa               // =10
    2020:      	str	x0, [x8, #0x18]
    2024:      	add	x8, x8, #0x20
    2028:      	str	x8, [sp, #0x10]
    202c:      	ldp	x8, x9, [x23]
    2030:      	stur	x8, [x10, #0x14]
    2034:      	stur	x9, [x10, #0x1c]
    2038:      	subs	x8, x22, x21
    203c:      	b.mi	0x320c <generic_fentry_process_event+0x2e7c>
    2040:      	ldr	x9, [sp, #0x30]
    2044:      	ldr	x0, [sp, #0x10]
    2048:      	add	x2, x21, x9
    204c:      	mov	w9, #0x7fe0             // =32736
    2050:      	cmp	x8, x9
    2054:      	csel	x24, x8, x9, lo
    2058:      	mov	w8, #0x4                // =4
    205c:      	mov	w1, w24
    2060:      	blr	x8
    2064:      	tbnz	w0, #0x1f, 0x20e4 <generic_fentry_process_event+0x1d54>
    2068:      	ldr	x8, [sp, #0x18]
    206c:      	add	w23, w24, #0x20
    2070:      	str	wzr, [sp, #0x88]
    2074:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    2078:      	add	x9, sp, #0x88
    207c:      	add	x1, sp, #0x88
    2080:      	str	w23, [x8, #0x4]
    2084:      	mov	w8, #0x1                // =1
    2088:      	ldr	x0, [x0]
    208c:      	blr	x8
    2090:      	cbz	x0, 0x20c4 <generic_fentry_process_event+0x1d34>
    2094:      	ldrb	w8, [x0, #0x28]
    2098:      	cbz	w8, 0x20c4 <generic_fentry_process_event+0x1d34>
    209c:      	adrp	x1, 0x2000 <generic_fentry_process_event+0x1c70>
    20a0:      	ldr	x3, [sp, #0x18]
    20a4:      	mov	w8, #0x19               // =25
    20a8:      	mov	w9, #-0x1               // =-1
    20ac:      	ldr	x1, [x1]
    20b0:      	mov	x0, x19
    20b4:      	mov	w2, #-0x1               // =-1
    20b8:      	mov	x4, x23
    20bc:      	blr	x8
    20c0:      	b	0x20e0 <generic_fentry_process_event+0x1d50>
    20c4:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    20c8:      	ldr	x1, [sp, #0x18]
    20cc:      	mov	x3, xzr
    20d0:      	mov	w8, #0x82               // =130
    20d4:      	ldr	x0, [x0]
    20d8:      	mov	x2, x23
    20dc:      	blr	x8
    20e0:      	tbz	w0, #0x1f, 0x20e8 <generic_fentry_process_event+0x1d58>
    20e4:      	sxtw	x24, w0
    20e8:      	tbnz	w24, #0x1f, 0x3214 <generic_fentry_process_event+0x2e84>
    20ec:      	and	x8, x24, #0x7fffffff
    20f0:      	add	x21, x8, x21
    20f4:      	cmp	x21, x22
    20f8:      	b.eq	0x3260 <generic_fentry_process_event+0x2ed0>
    20fc:      	subs	w25, w25, #0x1
    2100:      	b.ne	0x2038 <generic_fentry_process_event+0x1ca8>
    2104:      	b	0x35dc <generic_fentry_process_event+0x324c>
    2108:      	add	x8, sp, #0xd0
    210c:      	ldr	x22, [sp, #0x18]
    2110:      	mov	w1, #0x4                // =4
    2114:      	mov	w24, #0x4               // =4
    2118:      	ldr	x21, [x8]
    211c:      	mov	w8, #0x4                // =4
    2120:      	add	x0, x22, #0x28
    2124:      	add	x2, x21, #0x98
    2128:      	blr	x8
    212c:      	add	x0, x22, #0x2c
    2130:      	add	x2, x21, #0x70
    2134:      	mov	w8, #0x4                // =4
    2138:      	mov	w1, #0x4                // =4
    213c:      	blr	x8
    2140:      	add	x0, x22, #0x30
    2144:      	add	x2, x21, #0x90
    2148:      	mov	w8, #0x4                // =4
    214c:      	mov	w1, #0x4                // =4
    2150:      	blr	x8
    2154:      	add	x0, x22, #0x34
    2158:      	add	x2, x21, #0xa8
    215c:      	mov	w8, #0x4                // =4
    2160:      	mov	w1, #0x4                // =4
    2164:      	blr	x8
    2168:      	str	xzr, [sp, #0x88]
    216c:      	add	x2, x21, #0xc8
    2170:      	mov	w8, #0x8                // =8
    2174:      	add	x9, sp, #0x88
    2178:      	mov	w10, #0x4               // =4
    217c:      	add	x0, sp, #0x88
    2180:      	mov	w1, #0x8                // =8
    2184:      	blr	x10
    2188:      	add	x2, x21, #0xb8
    218c:      	mov	w8, #0x2                // =2
    2190:      	add	x9, sp, #0xd8
    2194:      	mov	w10, #0x4               // =4
    2198:      	add	x0, sp, #0xd8
    219c:      	mov	w1, #0x2                // =2
    21a0:      	blr	x10
    21a4:      	ldr	x8, [sp, #0x88]
    21a8:      	ldrh	w9, [sp, #0xd8]
    21ac:      	add	x0, sp, #0x74
    21b0:      	mov	w1, #0x1                // =1
    21b4:      	add	x23, x8, x9
    21b8:      	mov	w8, #0x1                // =1
    21bc:      	add	x9, sp, #0x74
    21c0:      	mov	x2, x23
    21c4:      	blr	x24
    21c8:      	ldrb	w8, [sp, #0x74]
    21cc:      	lsr	w8, w8, #4
    21d0:      	cmp	w8, #0x6
    21d4:      	b.eq	0x2798 <generic_fentry_process_event+0x2408>
    21d8:      	cmp	w8, #0x4
    21dc:      	b.ne	0x3b10 <generic_fentry_process_event+0x3780>
    21e0:      	add	x2, x23, #0x9
    21e4:      	mov	w8, #0x1                // =1
    21e8:      	add	x9, sp, #0x78
    21ec:      	mov	w10, #0x4               // =4
    21f0:      	add	x0, sp, #0x78
    21f4:      	mov	w1, #0x1                // =1
    21f8:      	mov	w25, #0x4               // =4
    21fc:      	blr	x10
    2200:      	ldr	x0, [sp, #0x18]
    2204:      	ldrb	w8, [sp, #0x78]
    2208:      	mov	w29, #0x2               // =2
    220c:      	add	x2, x23, #0xc
    2210:      	mov	w1, #0x4                // =4
    2214:      	mov	x24, x0
    2218:      	strh	w8, [x0, #0x24]
    221c:      	strh	w29, [x0, #0x26]
    2220:      	stp	xzr, xzr, [x0]
    2224:      	str	xzr, [x0, #0x18]
    2228:      	mov	w8, #0x4                // =4
    222c:      	str	xzr, [x24, #0x10]!
    2230:      	blr	x8
    2234:      	add	x2, x23, #0x10
    2238:      	mov	w8, #0x4                // =4
    223c:      	mov	x0, x24
    2240:      	mov	w1, #0x4                // =4
    2244:      	blr	x8
    2248:      	add	x2, x21, #0xb6
    224c:      	add	x8, sp, #0xc8
    2250:      	add	x0, sp, #0xc8
    2254:      	mov	w1, #0x2                // =2
    2258:      	blr	x25
    225c:      	ldrb	w25, [sp, #0x78]
    2260:      	b	0x39d4 <generic_fentry_process_event+0x3644>
    2264:      	ldr	x8, [x11]
    2268:      	mov	w9, #0x2d               // =45
    226c:      	mov	w1, #0x11               // =17
    2270:      	add	x2, x8, #0x118
    2274:      	ldr	x8, [sp, #0x18]
    2278:      	add	x0, x8, #0x4
    227c:      	mov	w8, #0x11               // =17
    2280:      	blr	x9
    2284:      	mov	x25, x0
    2288:      	tbnz	x0, #0x3f, 0x2a38 <generic_fentry_process_event+0x26a8>
    228c:      	ldr	x9, [sp, #0x18]
    2290:      	sub	w8, w25, #0x1
    2294:      	add	x25, x25, #0x3
    2298:      	mov	x29, x21
    229c:      	str	w8, [x9]
    22a0:      	b	0x3b1c <generic_fentry_process_event+0x378c>
    22a4:      	ldr	x0, [sp, #0x18]
    22a8:      	ldr	x23, [x11]
    22ac:      	mov	w8, #0x2                // =2
    22b0:      	mov	w9, #0x4                // =4
    22b4:      	mov	w1, #0x2                // =2
    22b8:      	mov	x2, x23
    22bc:      	str	xzr, [x0]
    22c0:      	stp	xzr, xzr, [x0, #0x8]
    22c4:      	blr	x9
    22c8:      	tbnz	x0, #0x3f, 0x2a08 <generic_fentry_process_event+0x2678>
    22cc:      	ldr	x8, [sp, #0x18]
    22d0:      	ldrh	w8, [x8]
    22d4:      	cmp	w8, #0xa
    22d8:      	b.eq	0x29c0 <generic_fentry_process_event+0x2630>
    22dc:      	cmp	w8, #0x2
    22e0:      	b.ne	0x29f4 <generic_fentry_process_event+0x2664>
    22e4:      	add	x2, x23, #0x4
    22e8:      	add	x8, sp, #0x88
    22ec:      	mov	w9, #0x4                // =4
    22f0:      	add	x0, sp, #0x88
    22f4:      	mov	w1, #0x4                // =4
    22f8:      	mov	w22, #0x4               // =4
    22fc:      	blr	x9
    2300:      	ldr	w8, [sp, #0x88]
    2304:      	ldr	x9, [sp, #0x18]
    2308:      	add	x2, x23, #0x2
    230c:      	add	x0, x9, #0x2
    2310:      	str	x8, [x9, #0x8]
    2314:      	mov	w8, #0x2                // =2
    2318:      	b	0x29ec <generic_fentry_process_event+0x265c>
    231c:      	ldr	x8, [sp, #0x10]
    2320:      	str	xzr, [x9]
    2324:      	add	x24, x8, #0x90
    2328:      	add	x8, x24, x23
    232c:      	str	x8, [sp, #0x18]
    2330:      	tbnz	w21, #0x4, 0x28e0 <generic_fentry_process_event+0x2550>
    2334:      	ldr	x9, [sp, #0x30]
    2338:      	mov	x8, xzr
    233c:      	and	x23, x21, #0xffffffff
    2340:      	and	w9, w9, #0xf
    2344:      	cmp	w9, #0x2
    2348:      	b.le	0x2aa4 <generic_fentry_process_event+0x2714>
    234c:      	cmp	w9, #0x3
    2350:      	b.eq	0x2d48 <generic_fentry_process_event+0x29b8>
    2354:      	cmp	w9, #0x4
    2358:      	b.eq	0x2d50 <generic_fentry_process_event+0x29c0>
    235c:      	cmp	w9, #0x5
    2360:      	b.ne	0x2d68 <generic_fentry_process_event+0x29d8>
    2364:      	mov	w9, #0x5e70             // =24176
    2368:      	b	0x2d5c <generic_fentry_process_event+0x29cc>
    236c:      	ldr	x25, [sp, #0x38]
    2370:      	ldr	x22, [sp, #0x18]
    2374:      	mov	w8, #0x4                // =4
    2378:      	mov	w1, #0x4                // =4
    237c:      	mov	w21, #0x4               // =4
    2380:      	add	x2, x25, #0x8
    2384:      	mov	x0, x22
    2388:      	add	x23, x22, #0x28
    238c:      	add	x29, x22, #0x40
    2390:      	blr	x8
    2394:      	add	x0, x22, #0x4
    2398:      	add	x2, x25, #0xc
    239c:      	mov	w8, #0x4                // =4
    23a0:      	mov	w1, #0x4                // =4
    23a4:      	blr	x8
    23a8:      	add	x0, x22, #0x10
    23ac:      	add	x2, x25, #0x18
    23b0:      	mov	w8, #0x4                // =4
    23b4:      	mov	w1, #0x4                // =4
    23b8:      	blr	x8
    23bc:      	add	x0, x22, #0x14
    23c0:      	add	x2, x25, #0x1c
    23c4:      	mov	w8, #0x4                // =4
    23c8:      	mov	w1, #0x4                // =4
    23cc:      	blr	x8
    23d0:      	add	x0, x22, #0x8
    23d4:      	add	x2, x25, #0x10
    23d8:      	mov	w8, #0x4                // =4
    23dc:      	mov	w1, #0x4                // =4
    23e0:      	blr	x8
    23e4:      	add	x0, x22, #0xc
    23e8:      	add	x2, x25, #0x14
    23ec:      	mov	w8, #0x4                // =4
    23f0:      	mov	w1, #0x4                // =4
    23f4:      	blr	x8
    23f8:      	add	x0, x22, #0x18
    23fc:      	add	x2, x25, #0x20
    2400:      	mov	w8, #0x4                // =4
    2404:      	mov	w1, #0x4                // =4
    2408:      	blr	x8
    240c:      	add	x0, x22, #0x1c
    2410:      	add	x2, x25, #0x24
    2414:      	mov	w8, #0x4                // =4
    2418:      	mov	w1, #0x4                // =4
    241c:      	blr	x8
    2420:      	str	wzr, [x22, #0x24]
    2424:      	add	x0, x22, #0x20
    2428:      	add	x2, x25, #0x28
    242c:      	mov	w8, #0x4                // =4
    2430:      	mov	w1, #0x4                // =4
    2434:      	blr	x8
    2438:      	add	x0, x22, #0x30
    243c:      	add	x2, x25, #0x40
    2440:      	mov	w24, #0x8               // =8
    2444:      	mov	w8, #0x4                // =4
    2448:      	mov	w1, #0x8                // =8
    244c:      	blr	x8
    2450:      	add	x0, x22, #0x38
    2454:      	add	x2, x25, #0x30
    2458:      	mov	w8, #0x4                // =4
    245c:      	mov	w1, #0x8                // =8
    2460:      	blr	x8
    2464:      	add	x2, x25, #0x38
    2468:      	mov	w8, #0x4                // =4
    246c:      	mov	x0, x23
    2470:      	mov	w1, #0x8                // =8
    2474:      	blr	x8
    2478:      	add	x2, x25, #0x90
    247c:      	add	x8, sp, #0x88
    2480:      	mov	w9, #0x4                // =4
    2484:      	add	x0, sp, #0x88
    2488:      	mov	w1, #0x8                // =8
    248c:      	blr	x9
    2490:      	ldr	x23, [sp, #0x88]
    2494:      	mov	w8, #0x4                // =4
    2498:      	mov	x0, x29
    249c:      	mov	w1, #0x4                // =4
    24a0:      	add	x2, x23, #0xc8
    24a4:      	blr	x8
    24a8:      	add	x0, x22, #0x44
    24ac:      	add	x2, x23, #0xcc
    24b0:      	mov	w8, #0x4                // =4
    24b4:      	mov	w1, #0x4                // =4
    24b8:      	blr	x8
    24bc:      	add	x0, x22, #0x48
    24c0:      	add	x2, x23, #0xd0
    24c4:      	mov	w8, #0x4                // =4
    24c8:      	mov	w1, #0x4                // =4
    24cc:      	blr	x8
    24d0:      	add	x0, x22, #0x4c
    24d4:      	add	x2, x23, #0x158
    24d8:      	mov	w1, #0x4                // =4
    24dc:      	blr	x21
    24e0:      	mov	w25, #0x50              // =80
    24e4:      	b	0x3b14 <generic_fentry_process_event+0x3784>
    24e8:      	ldr	x23, [sp, #0x38]
    24ec:      	ldr	x22, [sp, #0x18]
    24f0:      	mov	w8, #0x4                // =4
    24f4:      	mov	w1, #0x4                // =4
    24f8:      	mov	w21, #0x4               // =4
    24fc:      	add	x2, x23, #0xc8
    2500:      	mov	x0, x22
    2504:      	blr	x8
    2508:      	add	x0, x22, #0x4
    250c:      	add	x2, x23, #0xcc
    2510:      	mov	w8, #0x4                // =4
    2514:      	mov	w1, #0x4                // =4
    2518:      	blr	x8
    251c:      	add	x0, x22, #0x8
    2520:      	add	x2, x23, #0xd0
    2524:      	mov	w8, #0x4                // =4
    2528:      	mov	w1, #0x4                // =4
    252c:      	blr	x8
    2530:      	add	x0, x22, #0xc
    2534:      	add	x2, x23, #0x158
    2538:      	mov	w1, #0x4                // =4
    253c:      	blr	x21
    2540:      	mov	w25, #0x10              // =16
    2544:      	b	0x3b14 <generic_fentry_process_event+0x3784>
    2548:      	ldr	x23, [sp, #0x38]
    254c:      	ldr	x22, [sp, #0x18]
    2550:      	mov	w8, #0x4                // =4
    2554:      	mov	w1, #0x4                // =4
    2558:      	mov	w21, #0x4               // =4
    255c:      	add	x2, x23, #0x38
    2560:      	mov	x0, x22
    2564:      	blr	x8
    2568:      	add	x0, x22, #0x4
    256c:      	add	x2, x23, #0x3c
    2570:      	mov	w8, #0x4                // =4
    2574:      	mov	w1, #0x4                // =4
    2578:      	blr	x8
    257c:      	add	x0, x22, #0x8
    2580:      	add	x2, x23, #0x40
    2584:      	mov	w8, #0x4                // =4
    2588:      	mov	w1, #0x4                // =4
    258c:      	blr	x8
    2590:      	add	x0, x22, #0xc
    2594:      	add	x2, x23, #0x44
    2598:      	mov	w8, #0x4                // =4
    259c:      	mov	w1, #0x4                // =4
    25a0:      	blr	x8
    25a4:      	add	x0, x22, #0x10
    25a8:      	add	x2, x23, #0x80
    25ac:      	mov	w8, #0x10               // =16
    25b0:      	mov	w1, #0x10               // =16
    25b4:      	blr	x21
    25b8:      	mov	w25, #0x20              // =32
    25bc:      	b	0x3b14 <generic_fentry_process_event+0x3784>
    25c0:      	ldr	x22, [sp, #0x18]
    25c4:      	ldr	x23, [sp, #0x38]
    25c8:      	mov	w8, #0x4                // =4
    25cc:      	mov	w1, #0x4                // =4
    25d0:      	mov	w21, #0x4               // =4
    25d4:      	mov	x0, x22
    25d8:      	mov	x2, x23
    25dc:      	blr	x8
    25e0:      	add	x0, x22, #0x4
    25e4:      	add	x2, x23, #0x4
    25e8:      	mov	w8, #0x4                // =4
    25ec:      	mov	w1, #0x4                // =4
    25f0:      	blr	x8
    25f4:      	add	x0, x22, #0x8
    25f8:      	add	x2, x23, #0x30
    25fc:      	mov	w8, #0x10               // =16
    2600:      	b	0x2684 <generic_fentry_process_event+0x22f4>
    2604:      	ldr	x23, [sp, #0x38]
    2608:      	add	x8, sp, #0x88
    260c:      	mov	w9, #0x4                // =4
    2610:      	add	x0, sp, #0x88
    2614:      	mov	w1, #0x4                // =4
    2618:      	mov	w21, #0x4               // =4
    261c:      	add	x2, x23, #0x4
    2620:      	blr	x9
    2624:      	ldr	w8, [sp, #0x88]
    2628:      	ldr	x22, [sp, #0x18]
    262c:      	add	x2, x23, #0xc
    2630:      	add	x0, sp, #0x88
    2634:      	mov	w1, #0x4                // =4
    2638:      	str	w8, [x22]
    263c:      	add	x8, sp, #0x88
    2640:      	blr	x21
    2644:      	ldr	w8, [sp, #0x88]
    2648:      	add	x2, x23, #0x50
    264c:      	add	x9, sp, #0x88
    2650:      	mov	w10, #0x2d              // =45
    2654:      	str	w8, [x22, #0x4]
    2658:      	mov	w8, #0x8                // =8
    265c:      	add	x0, sp, #0x88
    2660:      	mov	w1, #0x8                // =8
    2664:      	mov	w21, #0x2d              // =45
    2668:      	blr	x10
    266c:      	ldr	x8, [sp, #0x88]
    2670:      	add	x0, x22, #0x8
    2674:      	mov	w9, #0x10               // =16
    2678:      	add	x8, x8, #0x3f8
    267c:      	ldr	x8, [sp, #0x88]
    2680:      	add	x2, x8, #0x3f8
    2684:      	mov	w1, #0x10               // =16
    2688:      	blr	x21
    268c:      	mov	w25, #0x18              // =24
    2690:      	b	0x3b14 <generic_fentry_process_event+0x3784>
    2694:      	ldr	x11, [sp, #0x18]
    2698:      	ldr	x2, [sp, #0x38]
    269c:      	mov	w8, #0x8                // =8
    26a0:      	mov	w9, #0x4                // =4
    26a4:      	add	x10, sp, #0x88
    26a8:      	add	x0, sp, #0x88
    26ac:      	mov	w1, #0x8                // =8
    26b0:      	stp	xzr, xzr, [x11, #0x40]
    26b4:      	stp	xzr, xzr, [x11, #0x30]
    26b8:      	stp	xzr, xzr, [x11, #0x20]
    26bc:      	stp	xzr, xzr, [x11, #0x10]
    26c0:      	stp	xzr, xzr, [x11]
    26c4:      	blr	x9
    26c8:      	mov	x25, xzr
    26cc:      	cbnz	x0, 0x3b14 <generic_fentry_process_event+0x3784>
    26d0:      	ldr	x8, [sp, #0x18]
    26d4:      	mov	w9, #0x3f               // =63
    26d8:      	mov	w10, #0x2d              // =45
    26dc:      	mov	w1, #0x3f               // =63
    26e0:      	add	x0, x8, #0x10
    26e4:      	ldr	x8, [sp, #0x88]
    26e8:      	ldr	x2, [sp, #0x88]
    26ec:      	blr	x10
    26f0:      	tbnz	x0, #0x3f, 0x28d8 <generic_fentry_process_event+0x2548>
    26f4:      	ldr	x22, [sp, #0x38]
    26f8:      	mov	w21, #0x8               // =8
    26fc:      	add	x8, sp, #0xe0
    2700:      	mov	w9, #0x4                // =4
    2704:      	add	x0, sp, #0xe0
    2708:      	mov	w1, #0x8                // =8
    270c:      	mov	w23, #0x4               // =4
    2710:      	add	x2, x22, #0x8
    2714:      	blr	x9
    2718:      	ldr	x8, [sp, #0x18]
    271c:      	add	x10, sp, #0xd0
    2720:      	mov	w9, #0x4                // =4
    2724:      	mov	w1, #0x8                // =8
    2728:      	add	x0, x8, #0x8
    272c:      	ldr	x8, [x10, #0x10]
    2730:      	add	x8, x8, #0x360
    2734:      	ldr	x8, [x10, #0x10]
    2738:      	add	x2, x8, #0x360
    273c:      	blr	x9
    2740:      	add	x2, x22, #0x58
    2744:      	add	x8, sp, #0xe0
    2748:      	add	x0, sp, #0xe0
    274c:      	mov	w1, #0x4                // =4
    2750:      	blr	x23
    2754:      	cbnz	x0, 0x276c <generic_fentry_process_event+0x23dc>
    2758:      	ldr	w8, [sp, #0xe0]
    275c:      	ldr	x9, [sp, #0x18]
    2760:      	cmp	w8, #0x0
    2764:      	cset	w8, ne
    2768:      	str	w8, [x9]
    276c:      	mov	w25, #0x50              // =80
    2770:      	b	0x3b14 <generic_fentry_process_event+0x3784>
    2774:      	ldr	x8, [sp, #0x38]
    2778:      	mov	w25, #0x8               // =8
    277c:      	add	x8, x8, x23
    2780:      	str	xzr, [x8, #0x90]
    2784:      	b	0x3b1c <generic_fentry_process_event+0x378c>
    2788:      	mov	w10, #0x9               // =9
    278c:      	b	0x1ad0 <generic_fentry_process_event+0x1740>
    2790:      	mov	x25, #-0x1              // =-1
    2794:      	b	0x3b1c <generic_fentry_process_event+0x378c>
    2798:      	str	wzr, [sp, #0xe0]
    279c:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    27a0:      	ldr	x22, [sp, #0x88]
    27a4:      	mov	w8, #0x1                // =1
    27a8:      	add	x9, sp, #0xe0
    27ac:      	add	x1, sp, #0xe0
    27b0:      	ldrh	w23, [sp, #0xd8]
    27b4:      	ldr	x0, [x0]
    27b8:      	add	x29, x22, x23
    27bc:      	blr	x8
    27c0:      	cbz	x0, 0x3990 <generic_fentry_process_event+0x3600>
    27c4:      	mov	w8, #0xff               // =255
    27c8:      	strh	w23, [x0]
    27cc:      	strb	wzr, [x0, #0x7]
    27d0:      	add	x23, x0, #0x6
    27d4:      	add	x2, x29, #0x6
    27d8:      	mov	w9, #0x4                // =4
    27dc:      	strb	w8, [x0, #0x5]
    27e0:      	mov	w8, #0x1                // =1
    27e4:      	mov	x24, x0
    27e8:      	mov	x0, x23
    27ec:      	mov	w1, #0x1                // =1
    27f0:      	blr	x9
    27f4:      	tbnz	x0, #0x3f, 0x3990 <generic_fentry_process_event+0x3600>
    27f8:      	ldrb	w8, [x24, #0x5]
    27fc:      	cmp	w8, #0x32
    2800:      	b.gt	0x2cbc <generic_fentry_process_event+0x292c>
    2804:      	cbz	w8, 0x2d34 <generic_fentry_process_event+0x29a4>
    2808:      	cmp	w8, #0x2b
    280c:      	b.eq	0x2d34 <generic_fentry_process_event+0x29a4>
    2810:      	cmp	w8, #0x2c
    2814:      	b.ne	0x3328 <generic_fentry_process_event+0x2f98>
    2818:      	mov	w8, #0x8                // =8
    281c:      	b	0x3274 <generic_fentry_process_event+0x2ee4>
    2820:      	ldr	x0, [sp, #0x18]
    2824:      	add	x2, x23, #0x48
    2828:      	mov	w25, #0x10              // =16
    282c:      	mov	w8, #0x4                // =4
    2830:      	mov	w1, #0x10               // =16
    2834:      	mov	w29, #0x4               // =4
    2838:      	blr	x8
    283c:      	add	x2, x23, #0x38
    2840:      	mov	x0, x24
    2844:      	mov	w1, #0x10               // =16
    2848:      	blr	x29
    284c:      	ldr	x22, [sp, #0x18]
    2850:      	add	x24, x23, #0xc
    2854:      	add	x2, x23, #0xe
    2858:      	mov	w23, #0x2               // =2
    285c:      	mov	w8, #0x4                // =4
    2860:      	mov	w1, #0x2                // =2
    2864:      	mov	w25, #0x4               // =4
    2868:      	add	x0, x22, #0x20
    286c:      	blr	x8
    2870:      	add	x0, x22, #0x22
    2874:      	mov	w1, #0x2                // =2
    2878:      	mov	x2, x24
    287c:      	blr	x25
    2880:      	ldrh	w8, [x22, #0x22]
    2884:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    2888:      	add	x9, sp, #0x88
    288c:      	add	x1, sp, #0x88
    2890:      	rev	w8, w8
    2894:      	lsr	w8, w8, #16
    2898:      	strh	w8, [x22, #0x22]
    289c:      	add	x8, sp, #0xd0
    28a0:      	ldr	x8, [x8]
    28a4:      	str	x8, [sp, #0x88]
    28a8:      	mov	w8, #0x1                // =1
    28ac:      	ldr	x0, [x0]
    28b0:      	blr	x8
    28b4:      	cbz	x0, 0x3b10 <generic_fentry_process_event+0x3780>
    28b8:      	ldr	w8, [x0]
    28bc:      	mov	w25, #0x40              // =64
    28c0:      	str	w8, [x21, #0x10]
    28c4:      	ldr	x8, [x0, #0x8]
    28c8:      	str	x8, [x21, #0x18]
    28cc:      	ldr	w8, [x0, #0x4]
    28d0:      	str	w8, [x21, #0x7c]
    28d4:      	b	0x3b14 <generic_fentry_process_event+0x3784>
    28d8:      	mov	x25, xzr
    28dc:      	b	0x3b14 <generic_fentry_process_event+0x3784>
    28e0:      	mov	w8, #0xe                // =14
    28e4:      	blr	x8
    28e8:      	cmn	x0, #0x16
    28ec:      	b.ne	0x2910 <generic_fentry_process_event+0x2580>
    28f0:      	add	x2, x19, #0xe8
    28f4:      	mov	w8, #0x8                // =8
    28f8:      	mov	w9, #0x4                // =4
    28fc:      	add	x10, sp, #0x88
    2900:      	add	x0, sp, #0x88
    2904:      	mov	w1, #0x8                // =8
    2908:      	blr	x9
    290c:      	ldr	x0, [sp, #0x88]
    2910:      	ldr	x8, [sp, #0x10]
    2914:      	mov	x3, xzr
    2918:      	add	x1, sp, #0xe0
    291c:      	add	x2, sp, #0x88
    2920:      	ldr	x9, [x8, #0x60]
    2924:      	ldr	x10, [x8, #0x8]
    2928:      	ldr	x8, [sp, #0x38]
    292c:      	str	xzr, [sp, #0x98]
    2930:      	stp	x10, x8, [sp, #0x88]
    2934:      	add	x8, sp, #0xd0
    2938:      	add	x10, sp, #0x88
    293c:      	stp	x9, x0, [x8, #0x10]
    2940:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    2944:      	mov	w8, #0x2                // =2
    2948:      	add	x9, sp, #0xe0
    294c:      	ldr	x0, [x0]
    2950:      	blr	x8
    2954:      	cbz	x0, 0x2d00 <generic_fentry_process_event+0x2970>
    2958:      	neg	w8, w0
    295c:      	adrp	x23, 0x2000 <generic_fentry_process_event+0x1c70>
    2960:      	mov	w9, #0x1                // =1
    2964:      	strh	w8, [sp, #0x60]
    2968:      	mov	w8, #0x5                // =5
    296c:      	add	x1, sp, #0x60
    2970:      	mov	w21, #0x1               // =1
    2974:      	strh	w8, [sp, #0x62]
    2978:      	mov	x8, #0x46               // =70
    297c:      	movk	x8, #0x2, lsl #32
    2980:      	stur	x8, [sp, #0x64]
    2984:      	add	x8, sp, #0x60
    2988:      	ldr	x23, [x23]
    298c:      	mov	x0, x23
    2990:      	blr	x9
    2994:      	cbz	x0, 0x2cdc <generic_fentry_process_event+0x294c>
    2998:      	ldr	w8, [x0]
    299c:      	add	w8, w8, #0x1
    29a0:      	str	w8, [x0]
    29a4:      	b	0x2d00 <generic_fentry_process_event+0x2970>
    29a8:      	cmp	w8, #0x1
    29ac:      	b.eq	0x2b80 <generic_fentry_process_event+0x27f0>
    29b0:      	cmp	w8, #0x2
    29b4:      	b.ne	0x2bd0 <generic_fentry_process_event+0x2840>
    29b8:      	mov	w9, #0x5e58             // =24152
    29bc:      	b	0x2b84 <generic_fentry_process_event+0x27f4>
    29c0:      	ldr	x24, [sp, #0x18]
    29c4:      	add	x2, x23, #0x8
    29c8:      	mov	w8, #0x10               // =16
    29cc:      	mov	w9, #0x4                // =4
    29d0:      	mov	w1, #0x10               // =16
    29d4:      	mov	w22, #0x4               // =4
    29d8:      	add	x0, x24, #0x8
    29dc:      	blr	x9
    29e0:      	add	x0, x24, #0x2
    29e4:      	add	x2, x23, #0x2
    29e8:      	mov	w8, #0x2                // =2
    29ec:      	mov	w1, #0x2                // =2
    29f0:      	blr	x22
    29f4:      	ldr	x9, [sp, #0x18]
    29f8:      	ldrh	w8, [x9, #0x2]
    29fc:      	rev	w8, w8
    2a00:      	lsr	w8, w8, #16
    2a04:      	strh	w8, [x9, #0x2]
    2a08:      	mov	w25, #0x18              // =24
    2a0c:      	mov	x29, x21
    2a10:      	b	0x3b1c <generic_fentry_process_event+0x378c>
    2a14:      	add	x2, x23, #0x3
    2a18:      	mov	w22, #0x6b              // =107
    2a1c:      	mov	w8, #0x71               // =113
    2a20:      	mov	w1, #0x6b               // =107
    2a24:      	blr	x8
    2a28:      	tbnz	w0, #0x1f, 0x2a34 <generic_fentry_process_event+0x26a4>
    2a2c:      	ldr	x8, [sp, #0x18]
    2a30:      	strb	w22, [x8, #0x3]
    2a34:      	mov	w25, #0x70              // =112
    2a38:      	mov	x29, x21
    2a3c:      	b	0x3b1c <generic_fentry_process_event+0x378c>
    2a40:      	ldr	x9, [sp, #0x38]
    2a44:      	mov	w24, #0xc               // =12
    2a48:      	str	wzr, [x9]
    2a4c:      	ldr	x9, [sp, #0xf8]
    2a50:      	add	x8, x8, x9
    2a54:      	add	x8, x8, #0x8
    2a58:      	str	x8, [sp, #0x38]
    2a5c:      	cmp	x22, #0xfff
    2a60:      	mov	w8, #0xfff              // =4095
    2a64:      	csel	x23, x22, x8, lo
    2a68:      	ldp	x2, x8, [sp, #0x30]
    2a6c:      	mov	w1, w23
    2a70:      	add	x0, x8, #0x8
    2a74:      	mov	w8, #0x4                // =4
    2a78:      	blr	x8
    2a7c:      	tbnz	w0, #0x1f, 0x2a90 <generic_fentry_process_event+0x2700>
    2a80:      	ldr	x8, [sp, #0x38]
    2a84:      	add	x25, x24, x23
    2a88:      	stp	w22, w23, [x8]
    2a8c:      	b	0x3b1c <generic_fentry_process_event+0x378c>
    2a90:      	ldr	x9, [sp, #0x38]
    2a94:      	mov	w8, #-0x2               // =-2
    2a98:      	mov	w25, #0x4               // =4
    2a9c:      	str	w8, [x9]
    2aa0:      	b	0x3b1c <generic_fentry_process_event+0x378c>
    2aa4:      	cmp	w9, #0x1
    2aa8:      	b.eq	0x2d58 <generic_fentry_process_event+0x29c8>
    2aac:      	cmp	w9, #0x2
    2ab0:      	b.ne	0x2d68 <generic_fentry_process_event+0x29d8>
    2ab4:      	mov	w9, #0x5e58             // =24152
    2ab8:      	b	0x2d5c <generic_fentry_process_event+0x29cc>
    2abc:      	ldr	x0, [sp, #0x18]
    2ac0:      	add	x2, x23, #0x48
    2ac4:      	mov	w25, #0x10              // =16
    2ac8:      	mov	w8, #0x4                // =4
    2acc:      	mov	w1, #0x10               // =16
    2ad0:      	mov	w29, #0x4               // =4
    2ad4:      	blr	x8
    2ad8:      	add	x2, x23, #0x38
    2adc:      	mov	x0, x24
    2ae0:      	mov	w1, #0x10               // =16
    2ae4:      	blr	x29
    2ae8:      	ldr	x22, [sp, #0x18]
    2aec:      	add	x24, x23, #0xc
    2af0:      	add	x2, x23, #0xe
    2af4:      	mov	w23, #0x2               // =2
    2af8:      	mov	w8, #0x4                // =4
    2afc:      	mov	w1, #0x2                // =2
    2b00:      	mov	w25, #0x4               // =4
    2b04:      	add	x0, x22, #0x20
    2b08:      	blr	x8
    2b0c:      	add	x0, x22, #0x22
    2b10:      	mov	w1, #0x2                // =2
    2b14:      	mov	x2, x24
    2b18:      	blr	x25
    2b1c:      	ldrh	w8, [x22, #0x22]
    2b20:      	rev	w8, w8
    2b24:      	lsr	w8, w8, #16
    2b28:      	strh	w8, [x22, #0x22]
    2b2c:      	ldr	x8, [sp, #0x18]
    2b30:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    2b34:      	add	x9, sp, #0x88
    2b38:      	add	x1, sp, #0x88
    2b3c:      	ldr	x8, [x8, #0x28]
    2b40:      	str	x8, [sp, #0x88]
    2b44:      	mov	w8, #0x1                // =1
    2b48:      	ldr	x0, [x0]
    2b4c:      	blr	x8
    2b50:      	cbz	x0, 0x3b10 <generic_fentry_process_event+0x3780>
    2b54:      	ldr	w8, [x0]
    2b58:      	str	w8, [x21, #0x10]
    2b5c:      	ldr	x8, [x0, #0x8]
    2b60:      	str	x8, [x21, #0x18]
    2b64:      	ldr	w8, [x0, #0x4]
    2b68:      	str	w8, [x21, #0x7c]
    2b6c:      	b	0x3b10 <generic_fentry_process_event+0x3780>
    2b70:      	mov	w9, #0x5e60             // =24160
    2b74:      	b	0x2b84 <generic_fentry_process_event+0x27f4>
    2b78:      	mov	w9, #0x5e68             // =24168
    2b7c:      	b	0x2b84 <generic_fentry_process_event+0x27f4>
    2b80:      	mov	w9, #0x5e50             // =24144
    2b84:      	ldr	x8, [sp, #0x10]
    2b88:      	add	x8, x8, x9
    2b8c:      	ldr	x21, [x8]
    2b90:      	ldr	x8, [sp, #0x30]
    2b94:      	tbnz	w8, #0x4, 0x2be0 <generic_fentry_process_event+0x2850>
    2b98:      	cbz	x21, 0x2cac <generic_fentry_process_event+0x291c>
    2b9c:      	ldr	x2, [sp, #0x38]
    2ba0:      	mov	w8, #0x10               // =16
    2ba4:      	mov	w9, #0x4                // =4
    2ba8:      	add	x10, sp, #0x88
    2bac:      	add	x0, sp, #0x88
    2bb0:      	mov	w1, #0x10               // =16
    2bb4:      	blr	x9
    2bb8:      	tbnz	w0, #0x1f, 0x31fc <generic_fentry_process_event+0x2e6c>
    2bbc:      	ldr	x23, [sp, #0x90]
    2bc0:      	cmp	x23, #0xffe
    2bc4:      	b.ls	0x2f70 <generic_fentry_process_event+0x2be0>
    2bc8:      	mov	w8, #-0x3               // =-3
    2bcc:      	b	0x3200 <generic_fentry_process_event+0x2e70>
    2bd0:      	ldr	x8, [sp, #0x30]
    2bd4:      	mov	x21, xzr
    2bd8:      	mov	x23, xzr
    2bdc:      	tbz	w8, #0x4, 0x2cb0 <generic_fentry_process_event+0x2920>
    2be0:      	mov	w8, #0xe                // =14
    2be4:      	blr	x8
    2be8:      	cmn	x0, #0x16
    2bec:      	b.ne	0x2c10 <generic_fentry_process_event+0x2880>
    2bf0:      	add	x2, x19, #0xe8
    2bf4:      	mov	w8, #0x8                // =8
    2bf8:      	mov	w9, #0x4                // =4
    2bfc:      	add	x10, sp, #0x88
    2c00:      	add	x0, sp, #0x88
    2c04:      	mov	w1, #0x8                // =8
    2c08:      	blr	x9
    2c0c:      	ldr	x0, [sp, #0x88]
    2c10:      	ldr	x8, [sp, #0x10]
    2c14:      	mov	x3, xzr
    2c18:      	add	x1, sp, #0xe0
    2c1c:      	add	x2, sp, #0x88
    2c20:      	ldr	x9, [x8, #0x60]
    2c24:      	ldr	x10, [x8, #0x8]
    2c28:      	ldr	x8, [sp, #0x38]
    2c2c:      	str	x21, [sp, #0x98]
    2c30:      	stp	x10, x8, [sp, #0x88]
    2c34:      	add	x8, sp, #0xd0
    2c38:      	add	x10, sp, #0x88
    2c3c:      	stp	x9, x0, [x8, #0x10]
    2c40:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    2c44:      	mov	w8, #0x2                // =2
    2c48:      	add	x9, sp, #0xe0
    2c4c:      	ldr	x0, [x0]
    2c50:      	blr	x8
    2c54:      	cbz	x0, 0x2d2c <generic_fentry_process_event+0x299c>
    2c58:      	neg	w8, w0
    2c5c:      	adrp	x23, 0x2000 <generic_fentry_process_event+0x1c70>
    2c60:      	mov	w9, #0x1                // =1
    2c64:      	strh	w8, [sp, #0x60]
    2c68:      	mov	w8, #0x5                // =5
    2c6c:      	add	x1, sp, #0x60
    2c70:      	mov	w21, #0x1               // =1
    2c74:      	strh	w8, [sp, #0x62]
    2c78:      	mov	x8, #0x57               // =87
    2c7c:      	movk	x8, #0x2, lsl #32
    2c80:      	stur	x8, [sp, #0x64]
    2c84:      	add	x8, sp, #0x60
    2c88:      	ldr	x23, [x23]
    2c8c:      	mov	x0, x23
    2c90:      	blr	x9
    2c94:      	cbz	x0, 0x2d08 <generic_fentry_process_event+0x2978>
    2c98:      	ldr	w8, [x0]
    2c9c:      	add	w8, w8, #0x1
    2ca0:      	str	w8, [x0]
    2ca4:      	mov	w8, #-0x4               // =-4
    2ca8:      	b	0x3200 <generic_fentry_process_event+0x2e70>
    2cac:      	mov	x23, xzr
    2cb0:      	stp	w23, w23, [x22]
    2cb4:      	add	x25, x23, #0x8
    2cb8:      	b	0x3b14 <generic_fentry_process_event+0x3784>
    2cbc:      	cmp	w8, #0x33
    2cc0:      	b.eq	0x3268 <generic_fentry_process_event+0x2ed8>
    2cc4:      	cmp	w8, #0x3c
    2cc8:      	b.eq	0x2d34 <generic_fentry_process_event+0x29a4>
    2ccc:      	cmp	w8, #0xff
    2cd0:      	b.ne	0x3328 <generic_fentry_process_event+0x2f98>
    2cd4:      	mov	w8, #0x28               // =40
    2cd8:      	b	0x3274 <generic_fentry_process_event+0x2ee4>
    2cdc:      	str	w21, [sp, #0xc8]
    2ce0:      	mov	x3, xzr
    2ce4:      	mov	w8, #0x2                // =2
    2ce8:      	add	x9, sp, #0x60
    2cec:      	add	x10, sp, #0xc8
    2cf0:      	add	x1, sp, #0x60
    2cf4:      	add	x2, sp, #0xc8
    2cf8:      	mov	x0, x23
    2cfc:      	blr	x8
    2d00:      	mov	w8, #-0x4               // =-4
    2d04:      	b	0x2f60 <generic_fentry_process_event+0x2bd0>
    2d08:      	str	w21, [sp, #0xd8]
    2d0c:      	mov	x3, xzr
    2d10:      	mov	w8, #0x2                // =2
    2d14:      	add	x9, sp, #0x60
    2d18:      	add	x10, sp, #0xd8
    2d1c:      	add	x1, sp, #0x60
    2d20:      	add	x2, sp, #0xd8
    2d24:      	mov	x0, x23
    2d28:      	blr	x8
    2d2c:      	mov	w8, #-0x4               // =-4
    2d30:      	b	0x3200 <generic_fentry_process_event+0x2e70>
    2d34:      	ldrb	w8, [x24, #0x7]
    2d38:      	lsl	w8, w8, #3
    2d3c:      	b	0x3270 <generic_fentry_process_event+0x2ee0>
    2d40:      	mov	w25, #0x4               // =4
    2d44:      	b	0x3b1c <generic_fentry_process_event+0x378c>
    2d48:      	mov	w9, #0x5e60             // =24160
    2d4c:      	b	0x2d5c <generic_fentry_process_event+0x29cc>
    2d50:      	mov	w9, #0x5e68             // =24168
    2d54:      	b	0x2d5c <generic_fentry_process_event+0x29cc>
    2d58:      	mov	w9, #0x5e50             // =24144
    2d5c:      	ldr	x8, [sp, #0x10]
    2d60:      	add	x8, x8, x9
    2d64:      	ldr	x8, [x8]
    2d68:      	add	x21, sp, #0xd0
    2d6c:      	mov	w25, #0x8               // =8
    2d70:      	add	x9, sp, #0xd0
    2d74:      	str	x8, [x21, #0x8]
    2d78:      	mov	w8, #0x4                // =4
    2d7c:      	add	x10, sp, #0xd8
    2d80:      	add	x0, sp, #0xd0
    2d84:      	add	x2, sp, #0xd8
    2d88:      	mov	w1, #0x8                // =8
    2d8c:      	blr	x8
    2d90:      	ldr	x21, [x21]
    2d94:      	tbz	w23, #0x5, 0x2f24 <generic_fentry_process_event+0x2b94>
    2d98:      	cmp	x21, #0x1, lsl #12      // =0x1000
    2d9c:      	b.lo	0x2f08 <generic_fentry_process_event+0x2b78>
    2da0:      	ldr	x9, [sp, #0x18]
    2da4:      	mov	w8, #0x1                // =1
    2da8:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    2dac:      	add	x1, sp, #0xe0
    2db0:      	str	w8, [x9]
    2db4:      	str	wzr, [sp, #0xe0]
    2db8:      	add	x9, sp, #0xe0
    2dbc:      	ldr	x0, [x0]
    2dc0:      	blr	x8
    2dc4:      	cbz	x0, 0x3204 <generic_fentry_process_event+0x2e74>
    2dc8:      	mov	w8, #0x18               // =24
    2dcc:      	mov	x29, x0
    2dd0:      	str	w8, [x0]
    2dd4:      	mov	w8, #0xe                // =14
    2dd8:      	blr	x8
    2ddc:      	mov	x23, x29
    2de0:      	cmn	x0, #0x16
    2de4:      	str	x0, [x23, #0x10]!
    2de8:      	b.ne	0x2e10 <generic_fentry_process_event+0x2a80>
    2dec:      	add	x2, x19, #0xe8
    2df0:      	mov	w8, #0x8                // =8
    2df4:      	mov	w9, #0x4                // =4
    2df8:      	add	x10, sp, #0x88
    2dfc:      	add	x0, sp, #0x88
    2e00:      	mov	w1, #0x8                // =8
    2e04:      	blr	x9
    2e08:      	ldr	x8, [sp, #0x88]
    2e0c:      	str	x8, [x23]
    2e10:      	mov	w8, #0x7d               // =125
    2e14:      	blr	x8
    2e18:      	str	x0, [x29, #0x18]
    2e1c:      	add	x8, x29, #0x20
    2e20:      	ldr	x10, [sp, #0x18]
    2e24:      	mov	x25, xzr
    2e28:      	mov	w24, #0xa               // =10
    2e2c:      	str	x8, [sp, #0x30]
    2e30:      	ldp	x8, x9, [x23]
    2e34:      	stur	x8, [x10, #0x14]
    2e38:      	stur	x9, [x10, #0x1c]
    2e3c:      	subs	x8, x21, x25
    2e40:      	b.mi	0x336c <generic_fentry_process_event+0x2fdc>
    2e44:      	ldp	x0, x9, [sp, #0x30]
    2e48:      	add	x2, x25, x9
    2e4c:      	mov	w9, #0x7fe0             // =32736
    2e50:      	cmp	x8, x9
    2e54:      	csel	x23, x8, x9, lo
    2e58:      	mov	w8, #0x4                // =4
    2e5c:      	mov	w1, w23
    2e60:      	blr	x8
    2e64:      	tbnz	w0, #0x1f, 0x2ee4 <generic_fentry_process_event+0x2b54>
    2e68:      	add	w8, w23, #0x20
    2e6c:      	str	wzr, [sp, #0x88]
    2e70:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    2e74:      	add	x9, sp, #0x88
    2e78:      	str	w8, [x29, #0x4]
    2e7c:      	mov	x22, x8
    2e80:      	mov	w8, #0x1                // =1
    2e84:      	add	x1, sp, #0x88
    2e88:      	ldr	x0, [x0]
    2e8c:      	blr	x8
    2e90:      	cbz	x0, 0x2ec4 <generic_fentry_process_event+0x2b34>
    2e94:      	ldrb	w8, [x0, #0x28]
    2e98:      	cbz	w8, 0x2ec4 <generic_fentry_process_event+0x2b34>
    2e9c:      	adrp	x1, 0x2000 <generic_fentry_process_event+0x1c70>
    2ea0:      	mov	w8, #0x19               // =25
    2ea4:      	mov	w9, #-0x1               // =-1
    2ea8:      	ldr	x1, [x1]
    2eac:      	mov	x0, x19
    2eb0:      	mov	w2, #-0x1               // =-1
    2eb4:      	mov	x3, x29
    2eb8:      	mov	x4, x22
    2ebc:      	blr	x8
    2ec0:      	b	0x2ee0 <generic_fentry_process_event+0x2b50>
    2ec4:      	adrp	x0, 0x2000 <generic_fentry_process_event+0x1c70>
    2ec8:      	mov	x3, xzr
    2ecc:      	mov	w8, #0x82               // =130
    2ed0:      	ldr	x0, [x0]
    2ed4:      	mov	x1, x29
    2ed8:      	mov	x2, x22
    2edc:      	blr	x8
    2ee0:      	tbz	w0, #0x1f, 0x2ee8 <generic_fentry_process_event+0x2b58>
    2ee4:      	sxtw	x23, w0
    2ee8:      	tbnz	w23, #0x1f, 0x3374 <generic_fentry_process_event+0x2fe4>
    2eec:      	and	x8, x23, #0x7fffffff
    2ef0:      	add	x25, x8, x25
    2ef4:      	cmp	x25, x21
    2ef8:      	b.eq	0x33c0 <generic_fentry_process_event+0x3030>
    2efc:      	subs	w24, w24, #0x1
    2f00:      	b.ne	0x2e3c <generic_fentry_process_event+0x2aac>
    2f04:      	b	0x372c <generic_fentry_process_event+0x339c>
    2f08:      	ldr	x8, [sp, #0x18]
    2f0c:      	mov	w25, #0xc               // =12
    2f10:      	str	wzr, [x8]
    2f14:      	ldr	x8, [sp, #0xf8]
    2f18:      	add	x8, x24, x8
    2f1c:      	add	x8, x8, #0x8
    2f20:      	str	x8, [sp, #0x18]
    2f24:      	cmp	x21, #0xfff
    2f28:      	mov	w8, #0xfff              // =4095
    2f2c:      	ldr	x2, [sp, #0x38]
    2f30:      	csel	x23, x21, x8, lo
    2f34:      	ldr	x8, [sp, #0x18]
    2f38:      	mov	w1, w23
    2f3c:      	add	x0, x8, #0x8
    2f40:      	mov	w8, #0x4                // =4
    2f44:      	blr	x8
    2f48:      	tbnz	w0, #0x1f, 0x2f5c <generic_fentry_process_event+0x2bcc>
    2f4c:      	ldr	x8, [sp, #0x18]
    2f50:      	add	x25, x25, x23
    2f54:      	stp	w21, w23, [x8]
    2f58:      	b	0x3b14 <generic_fentry_process_event+0x3784>
    2f5c:      	mov	w8, #-0x2               // =-2
    2f60:      	ldr	x9, [sp, #0x18]
    2f64:      	mov	w25, #0x4               // =4
    2f68:      	str	w8, [x9]
    2f6c:      	b	0x3b14 <generic_fentry_process_event+0x3784>
    2f70:      	ldr	x8, [sp, #0xf8]
    2f74:      	mov	w9, #0x4                // =4
    2f78:      	mov	w1, w23
    2f7c:      	add	x25, x8, #0xc
    2f80:      	ldr	x8, [sp, #0x88]
    2f84:      	add	x0, x24, x25
    2f88:      	ldr	x2, [sp, #0x88]
    2f8c:      	blr	x9
    2f90:      	tbnz	w0, #0x1f, 0x31fc <generic_fentry_process_event+0x2e6c>
    2f94:      	cmp	x21, #0x1
    2f98:      	b.eq	0x2cb0 <generic_fentry_process_event+0x2920>
    2f9c:      	ldr	x8, [sp, #0x38]
    2fa0:      	mov	w9, #0x4                // =4
    2fa4:      	add	x10, sp, #0x88
    2fa8:      	add	x0, sp, #0x88
    2fac:      	mov	w1, #0x10               // =16
    2fb0:      	add	x2, x8, #0x10
    2fb4:      	mov	w8, #0x10               // =16
    2fb8:      	blr	x9
    2fbc:      	tbnz	w0, #0x1f, 0x31fc <generic_fentry_process_event+0x2e6c>
    2fc0:      	ldr	x8, [sp, #0x90]
    2fc4:      	cmp	x8, #0xffe
    2fc8:      	b.hi	0x2bc8 <generic_fentry_process_event+0x2838>
    2fcc:      	add	x25, x23, x25
    2fd0:      	mov	x29, x8
    2fd4:      	ldr	x8, [sp, #0x88]
    2fd8:      	mov	w9, #0x4                // =4
    2fdc:      	add	x0, x24, x25
    2fe0:      	mov	x1, x29
    2fe4:      	ldr	x2, [sp, #0x88]
    2fe8:      	blr	x9
    2fec:      	tbnz	w0, #0x1f, 0x31fc <generic_fentry_process_event+0x2e6c>
    2ff0:      	add	x23, x29, x23
    2ff4:      	cmp	x21, #0x3
    2ff8:      	b.lo	0x2cb0 <generic_fentry_process_event+0x2920>
    2ffc:      	ldr	x8, [sp, #0x38]
    3000:      	mov	w9, #0x4                // =4
    3004:      	add	x10, sp, #0x88
    3008:      	add	x0, sp, #0x88
    300c:      	mov	w1, #0x10               // =16
    3010:      	add	x2, x8, #0x20
    3014:      	mov	w8, #0x10               // =16
    3018:      	blr	x9
    301c:      	tbnz	w0, #0x1f, 0x31fc <generic_fentry_process_event+0x2e6c>
    3020:      	ldr	x8, [sp, #0x90]
    3024:      	cmp	x8, #0xffe
    3028:      	str	x8, [sp, #0x30]
    302c:      	b.hi	0x2bc8 <generic_fentry_process_event+0x2838>
    3030:      	add	x25, x29, x25
    3034:      	mov	w9, #0x4                // =4
    3038:      	ldr	x1, [sp, #0x30]
    303c:      	and	x8, x25, #0x3fff
    3040:      	add	x0, x24, x8
    3044:      	ldr	x8, [sp, #0x88]
    3048:      	ldr	x2, [sp, #0x88]
    304c:      	blr	x9
    3050:      	tbnz	w0, #0x1f, 0x31fc <generic_fentry_process_event+0x2e6c>
    3054:      	ldr	x8, [sp, #0x30]
    3058:      	cmp	x21, #0x3
    305c:      	add	x23, x8, x23
    3060:      	b.eq	0x2cb0 <generic_fentry_process_event+0x2920>
    3064:      	ldr	x8, [sp, #0x38]
    3068:      	mov	w9, #0x4                // =4
    306c:      	add	x10, sp, #0x88
    3070:      	add	x0, sp, #0x88
    3074:      	mov	w1, #0x10               // =16
    3078:      	add	x2, x8, #0x30
    307c:      	mov	w8, #0x10               // =16
    3080:      	blr	x9
    3084:      	tbnz	w0, #0x1f, 0x31fc <generic_fentry_process_event+0x2e6c>
    3088:      	ldr	x8, [sp, #0x90]
    308c:      	cmp	x8, #0xffe
    3090:      	str	x8, [sp, #0x18]
    3094:      	b.hi	0x2bc8 <generic_fentry_process_event+0x2838>
    3098:      	ldr	x8, [sp, #0x30]
    309c:      	mov	w9, #0x4                // =4
    30a0:      	ldr	x1, [sp, #0x18]
    30a4:      	add	x25, x8, x25
    30a8:      	and	x8, x25, #0x3fff
    30ac:      	add	x0, x24, x8
    30b0:      	ldr	x8, [sp, #0x88]
    30b4:      	ldr	x2, [sp, #0x88]
    30b8:      	blr	x9
    30bc:      	tbnz	w0, #0x1f, 0x31fc <generic_fentry_process_event+0x2e6c>
    30c0:      	ldr	x8, [sp, #0x18]
    30c4:      	cmp	x21, #0x5
    30c8:      	add	x23, x8, x23
    30cc:      	b.lo	0x2cb0 <generic_fentry_process_event+0x2920>
    30d0:      	ldr	x8, [sp, #0x38]
    30d4:      	mov	w9, #0x4                // =4
    30d8:      	add	x10, sp, #0x88
    30dc:      	add	x0, sp, #0x88
    30e0:      	mov	w1, #0x10               // =16
    30e4:      	add	x2, x8, #0x40
    30e8:      	mov	w8, #0x10               // =16
    30ec:      	blr	x9
    30f0:      	tbnz	w0, #0x1f, 0x31fc <generic_fentry_process_event+0x2e6c>
    30f4:      	ldr	x29, [sp, #0x90]
    30f8:      	cmp	x29, #0xffe
    30fc:      	b.hi	0x2bc8 <generic_fentry_process_event+0x2838>
    3100:      	ldr	x8, [sp, #0x18]
    3104:      	mov	w9, #0x4                // =4
    3108:      	mov	w1, w29
    310c:      	add	x25, x8, x25
    3110:      	and	x8, x25, #0x3fff
    3114:      	add	x0, x24, x8
    3118:      	ldr	x8, [sp, #0x88]
    311c:      	ldr	x2, [sp, #0x88]
    3120:      	blr	x9
    3124:      	tbnz	w0, #0x1f, 0x31fc <generic_fentry_process_event+0x2e6c>
    3128:      	add	x23, x29, x23
    312c:      	cmp	x21, #0x5
    3130:      	b.eq	0x2cb0 <generic_fentry_process_event+0x2920>
    3134:      	ldr	x8, [sp, #0x38]
    3138:      	mov	w9, #0x4                // =4
    313c:      	add	x10, sp, #0x88
    3140:      	add	x0, sp, #0x88
    3144:      	mov	w1, #0x10               // =16
    3148:      	add	x2, x8, #0x50
    314c:      	mov	w8, #0x10               // =16
    3150:      	blr	x9
    3154:      	tbnz	w0, #0x1f, 0x31fc <generic_fentry_process_event+0x2e6c>
    3158:      	ldr	x8, [sp, #0x90]
    315c:      	cmp	x8, #0xffe
    3160:      	str	x8, [sp, #0x30]
    3164:      	b.hi	0x2bc8 <generic_fentry_process_event+0x2838>
    3168:      	add	x25, x29, x25
    316c:      	mov	w9, #0x4                // =4
    3170:      	ldr	x1, [sp, #0x30]
    3174:      	and	x8, x25, #0x3fff
    3178:      	add	x0, x24, x8
    317c:      	ldr	x8, [sp, #0x88]
    3180:      	ldr	x2, [sp, #0x88]
    3184:      	blr	x9
    3188:      	tbnz	w0, #0x1f, 0x31fc <generic_fentry_process_event+0x2e6c>
    318c:      	ldr	x8, [sp, #0x30]
    3190:      	cmp	x21, #0x7
    3194:      	add	x23, x8, x23
    3198:      	b.lo	0x2cb0 <generic_fentry_process_event+0x2920>
    319c:      	ldr	x8, [sp, #0x38]
    31a0:      	mov	w9, #0x4                // =4
    31a4:      	add	x10, sp, #0x88
    31a8:      	add	x0, sp, #0x88
    31ac:      	mov	w1, #0x10               // =16
    31b0:      	add	x2, x8, #0x60
    31b4:      	mov	w8, #0x10               // =16
    31b8:      	blr	x9
    31bc:      	tbnz	w0, #0x1f, 0x31fc <generic_fentry_process_event+0x2e6c>
    31c0:      	ldr	x21, [sp, #0x90]
    31c4:      	cmp	x21, #0xffe
    31c8:      	b.hi	0x2bc8 <generic_fentry_process_event+0x2838>
    31cc:      	ldr	x8, [sp, #0x30]
    31d0:      	mov	w9, #0x4                // =4
    31d4:      	mov	w1, w21
    31d8:      	add	x8, x8, x25
    31dc:      	and	x8, x8, #0x3fff
    31e0:      	add	x0, x24, x8
    31e4:      	ldr	x8, [sp, #0x88]
    31e8:      	ldr	x2, [sp, #0x88]
    31ec:      	blr	x9
    31f0:      	tbnz	w0, #0x1f, 0x31fc <generic_fentry_process_event+0x2e6c>
    31f4:      	add	x23, x21, x23
    31f8:      	b	0x2cb0 <generic_fentry_process_event+0x2920>
    31fc:      	mov	w8, #-0x2               // =-2
    3200:      	str	w8, [x22]
    3204:      	mov	w25, #0x4               // =4
    3208:      	b	0x3b14 <generic_fentry_process_event+0x3784>
    320c:      	mov	x21, #-0x1              // =-1
    3210:      	b	0x3218 <generic_fentry_process_event+0x2e88>
    3214:      	mov	x21, x24
    3218:      	str	wzr, [sp, #0x88]
    321c:      	adrp	x0, 0x3000 <generic_fentry_process_event+0x2c70>
    3220:      	mov	w8, #0x1                // =1
    3224:      	add	x9, sp, #0x88
    3228:      	ldr	x0, [x0]
    322c:      	add	x1, sp, #0x88
    3230:      	blr	x8
    3234:      	cbz	x0, 0x35dc <generic_fentry_process_event+0x324c>
    3238:      	cmn	x21, #0xc
    323c:      	b.gt	0x334c <generic_fentry_process_event+0x2fbc>
    3240:      	cmn	x21, #0x1c
    3244:      	b.eq	0x35a8 <generic_fentry_process_event+0x3218>
    3248:      	cmn	x21, #0x16
    324c:      	b.eq	0x35c0 <generic_fentry_process_event+0x3230>
    3250:      	cmn	x21, #0x10
    3254:      	b.ne	0x35b8 <generic_fentry_process_event+0x3228>
    3258:      	add	x8, x0, #0x558
    325c:      	b	0x35cc <generic_fentry_process_event+0x323c>
    3260:      	mov	x21, x22
    3264:      	b	0x35dc <generic_fentry_process_event+0x324c>
    3268:      	ldrb	w8, [x24, #0x7]
    326c:      	lsl	w8, w8, #2
    3270:      	add	w8, w8, #0x8
    3274:      	strh	w8, [x24, #0x2]
    3278:      	ldrh	w9, [x24]
    327c:      	ldrb	w25, [x24, #0x6]
    3280:      	add	w8, w9, w8
    3284:      	cmp	w25, #0x3c
    3288:      	strh	w8, [x24]
    328c:      	b.hi	0x3344 <generic_fentry_process_event+0x2fb4>
    3290:      	mov	x10, #0x1               // =1
    3294:      	mov	w9, #0x1                // =1
    3298:      	movk	x10, #0x1800, lsl #32
    329c:      	lsl	x9, x9, x25
    32a0:      	movk	x10, #0x1008, lsl #48
    32a4:      	tst	x9, x10
    32a8:      	b.eq	0x3344 <generic_fentry_process_event+0x2fb4>
    32ac:      	strb	w25, [x24, #0x5]
    32b0:      	add	x8, x22, w8, uxth
    32b4:      	mov	w9, #0x2                // =2
    32b8:      	mov	w10, #0x4               // =4
    32bc:      	mov	x0, x23
    32c0:      	mov	w1, #0x2                // =2
    32c4:      	ldrh	w8, [x24]
    32c8:      	add	x2, x22, x8
    32cc:      	blr	x10
    32d0:      	tbnz	x0, #0x3f, 0x3990 <generic_fentry_process_event+0x3600>
    32d4:      	ldrb	w8, [x24, #0x5]
    32d8:      	cmp	w8, #0x32
    32dc:      	b.gt	0x32fc <generic_fentry_process_event+0x2f6c>
    32e0:      	cbz	w8, 0x331c <generic_fentry_process_event+0x2f8c>
    32e4:      	cmp	w8, #0x2b
    32e8:      	b.eq	0x331c <generic_fentry_process_event+0x2f8c>
    32ec:      	cmp	w8, #0x2c
    32f0:      	b.ne	0x3488 <generic_fentry_process_event+0x30f8>
    32f4:      	mov	w8, #0x8                // =8
    32f8:      	b	0x33d4 <generic_fentry_process_event+0x3044>
    32fc:      	cmp	w8, #0x33
    3300:      	b.eq	0x33c8 <generic_fentry_process_event+0x3038>
    3304:      	cmp	w8, #0x3c
    3308:      	b.eq	0x331c <generic_fentry_process_event+0x2f8c>
    330c:      	cmp	w8, #0xff
    3310:      	b.ne	0x3488 <generic_fentry_process_event+0x30f8>
    3314:      	mov	w8, #0x28               // =40
    3318:      	b	0x33d4 <generic_fentry_process_event+0x3044>
    331c:      	ldrb	w8, [x24, #0x7]
    3320:      	lsl	w8, w8, #3
    3324:      	b	0x33d0 <generic_fentry_process_event+0x3040>
    3328:      	ldrh	w8, [x24, #0x2]
    332c:      	ldrh	w9, [x24]
    3330:      	ldrb	w25, [x24, #0x6]
    3334:      	add	w8, w9, w8
    3338:      	cmp	w25, #0x3c
    333c:      	strh	w8, [x24]
    3340:      	b.ls	0x3290 <generic_fentry_process_event+0x2f00>
    3344:      	strh	w8, [sp, #0xc8]
    3348:      	b	0x3994 <generic_fentry_process_event+0x3604>
    334c:      	cmn	x21, #0xb
    3350:      	b.eq	0x35b0 <generic_fentry_process_event+0x3220>
    3354:      	cmn	x21, #0x7
    3358:      	b.eq	0x35c8 <generic_fentry_process_event+0x3238>
    335c:      	cmn	x21, #0x2
    3360:      	b.ne	0x35b8 <generic_fentry_process_event+0x3228>
    3364:      	add	x8, x0, #0x548
    3368:      	b	0x35cc <generic_fentry_process_event+0x323c>
    336c:      	mov	x25, #-0x1              // =-1
    3370:      	b	0x3378 <generic_fentry_process_event+0x2fe8>
    3374:      	mov	x25, x23
    3378:      	str	wzr, [sp, #0x88]
    337c:      	adrp	x0, 0x3000 <generic_fentry_process_event+0x2c70>
    3380:      	mov	w8, #0x1                // =1
    3384:      	add	x9, sp, #0x88
    3388:      	ldr	x0, [x0]
    338c:      	add	x1, sp, #0x88
    3390:      	blr	x8
    3394:      	cbz	x0, 0x372c <generic_fentry_process_event+0x339c>
    3398:      	cmn	x25, #0xc
    339c:      	b.gt	0x34a8 <generic_fentry_process_event+0x3118>
    33a0:      	cmn	x25, #0x1c
    33a4:      	b.eq	0x36f8 <generic_fentry_process_event+0x3368>
    33a8:      	cmn	x25, #0x16
    33ac:      	b.eq	0x3710 <generic_fentry_process_event+0x3380>
    33b0:      	cmn	x25, #0x10
    33b4:      	b.ne	0x3708 <generic_fentry_process_event+0x3378>
    33b8:      	add	x8, x0, #0x558
    33bc:      	b	0x371c <generic_fentry_process_event+0x338c>
    33c0:      	mov	x25, x21
    33c4:      	b	0x372c <generic_fentry_process_event+0x339c>
    33c8:      	ldrb	w8, [x24, #0x7]
    33cc:      	lsl	w8, w8, #2
    33d0:      	add	w8, w8, #0x8
    33d4:      	strh	w8, [x24, #0x2]
    33d8:      	ldrh	w9, [x24]
    33dc:      	ldrb	w25, [x24, #0x6]
    33e0:      	add	w8, w9, w8
    33e4:      	cmp	w25, #0x3c
    33e8:      	strh	w8, [x24]
    33ec:      	b.hi	0x3c30 <generic_fentry_process_event+0x38a0>
    33f0:      	mov	x10, #0x1               // =1
    33f4:      	mov	w9, #0x1                // =1
    33f8:      	movk	x10, #0x1800, lsl #32
    33fc:      	lsl	x9, x9, x25
    3400:      	movk	x10, #0x1008, lsl #48
    3404:      	tst	x9, x10
    3408:      	b.eq	0x3c30 <generic_fentry_process_event+0x38a0>
    340c:      	strb	w25, [x24, #0x5]
    3410:      	add	x8, x22, w8, uxth
    3414:      	mov	w9, #0x2                // =2
    3418:      	mov	w10, #0x4               // =4
    341c:      	mov	x0, x23
    3420:      	mov	w1, #0x2                // =2
    3424:      	ldrh	w8, [x24]
    3428:      	add	x2, x22, x8
    342c:      	blr	x10
    3430:      	tbnz	x0, #0x3f, 0x3990 <generic_fentry_process_event+0x3600>
    3434:      	ldrb	w8, [x24, #0x5]
    3438:      	cmp	w8, #0x32
    343c:      	b.gt	0x345c <generic_fentry_process_event+0x30cc>
    3440:      	cbz	w8, 0x347c <generic_fentry_process_event+0x30ec>
    3444:      	cmp	w8, #0x2b
    3448:      	b.eq	0x347c <generic_fentry_process_event+0x30ec>
    344c:      	cmp	w8, #0x2c
    3450:      	b.ne	0x3588 <generic_fentry_process_event+0x31f8>
    3454:      	mov	w8, #0x8                // =8
    3458:      	b	0x34d4 <generic_fentry_process_event+0x3144>
    345c:      	cmp	w8, #0x33
    3460:      	b.eq	0x34c8 <generic_fentry_process_event+0x3138>
    3464:      	cmp	w8, #0x3c
    3468:      	b.eq	0x347c <generic_fentry_process_event+0x30ec>
    346c:      	cmp	w8, #0xff
    3470:      	b.ne	0x3588 <generic_fentry_process_event+0x31f8>
    3474:      	mov	w8, #0x28               // =40
    3478:      	b	0x34d4 <generic_fentry_process_event+0x3144>
    347c:      	ldrb	w8, [x24, #0x7]
    3480:      	lsl	w8, w8, #3
    3484:      	b	0x34d0 <generic_fentry_process_event+0x3140>
    3488:      	ldrh	w8, [x24, #0x2]
    348c:      	ldrh	w9, [x24]
    3490:      	ldrb	w25, [x24, #0x6]
    3494:      	add	w8, w9, w8
    3498:      	cmp	w25, #0x3c
    349c:      	strh	w8, [x24]
    34a0:      	b.ls	0x33f0 <generic_fentry_process_event+0x3060>
    34a4:      	b	0x3c30 <generic_fentry_process_event+0x38a0>
    34a8:      	cmn	x25, #0xb
    34ac:      	b.eq	0x3700 <generic_fentry_process_event+0x3370>
    34b0:      	cmn	x25, #0x7
    34b4:      	b.eq	0x3718 <generic_fentry_process_event+0x3388>
    34b8:      	cmn	x25, #0x2
    34bc:      	b.ne	0x3708 <generic_fentry_process_event+0x3378>
    34c0:      	add	x8, x0, #0x548
    34c4:      	b	0x371c <generic_fentry_process_event+0x338c>
    34c8:      	ldrb	w8, [x24, #0x7]
    34cc:      	lsl	w8, w8, #2
    34d0:      	add	w8, w8, #0x8
    34d4:      	strh	w8, [x24, #0x2]
    34d8:      	ldrh	w9, [x24]
    34dc:      	ldrb	w25, [x24, #0x6]
    34e0:      	add	w8, w9, w8
    34e4:      	cmp	w25, #0x3c
    34e8:      	strh	w8, [x24]
    34ec:      	b.hi	0x3c30 <generic_fentry_process_event+0x38a0>
    34f0:      	mov	x10, #0x1               // =1
    34f4:      	mov	w9, #0x1                // =1
    34f8:      	movk	x10, #0x1800, lsl #32
    34fc:      	lsl	x9, x9, x25
    3500:      	movk	x10, #0x1008, lsl #48
    3504:      	tst	x9, x10
    3508:      	b.eq	0x3c30 <generic_fentry_process_event+0x38a0>
    350c:      	strb	w25, [x24, #0x5]
    3510:      	add	x8, x22, w8, uxth
    3514:      	mov	w9, #0x2                // =2
    3518:      	mov	w10, #0x4               // =4
    351c:      	mov	x0, x23
    3520:      	mov	w1, #0x2                // =2
    3524:      	ldrh	w8, [x24]
    3528:      	add	x2, x22, x8
    352c:      	blr	x10
    3530:      	tbnz	x0, #0x3f, 0x3990 <generic_fentry_process_event+0x3600>
    3534:      	ldrb	w8, [x24, #0x5]
    3538:      	cmp	w8, #0x32
    353c:      	b.gt	0x355c <generic_fentry_process_event+0x31cc>
    3540:      	cbz	w8, 0x357c <generic_fentry_process_event+0x31ec>
    3544:      	cmp	w8, #0x2b
    3548:      	b.eq	0x357c <generic_fentry_process_event+0x31ec>
    354c:      	cmp	w8, #0x2c
    3550:      	b.ne	0x36d8 <generic_fentry_process_event+0x3348>
    3554:      	mov	w8, #0x8                // =8
    3558:      	b	0x3624 <generic_fentry_process_event+0x3294>
    355c:      	cmp	w8, #0x33
    3560:      	b.eq	0x3618 <generic_fentry_process_event+0x3288>
    3564:      	cmp	w8, #0x3c
    3568:      	b.eq	0x357c <generic_fentry_process_event+0x31ec>
    356c:      	cmp	w8, #0xff
    3570:      	b.ne	0x36d8 <generic_fentry_process_event+0x3348>
    3574:      	mov	w8, #0x28               // =40
    3578:      	b	0x3624 <generic_fentry_process_event+0x3294>
    357c:      	ldrb	w8, [x24, #0x7]
    3580:      	lsl	w8, w8, #3
    3584:      	b	0x3620 <generic_fentry_process_event+0x3290>
    3588:      	ldrh	w8, [x24, #0x2]
    358c:      	ldrh	w9, [x24]
    3590:      	ldrb	w25, [x24, #0x6]
    3594:      	add	w8, w9, w8
    3598:      	cmp	w25, #0x3c
    359c:      	strh	w8, [x24]
    35a0:      	b.ls	0x34f0 <generic_fentry_process_event+0x3160>
    35a4:      	b	0x3c30 <generic_fentry_process_event+0x38a0>
    35a8:      	add	x8, x0, #0x568
    35ac:      	b	0x35cc <generic_fentry_process_event+0x323c>
    35b0:      	add	x8, x0, #0x570
    35b4:      	b	0x35cc <generic_fentry_process_event+0x323c>
    35b8:      	add	x8, x0, #0x540
    35bc:      	b	0x35cc <generic_fentry_process_event+0x323c>
    35c0:      	add	x8, x0, #0x560
    35c4:      	b	0x35cc <generic_fentry_process_event+0x323c>
    35c8:      	add	x8, x0, #0x550
    35cc:      	ldaxr	x9, [x8]
    35d0:      	add	x9, x9, #0x1
    35d4:      	stlxr	w10, x9, [x8]
    35d8:      	cbnz	w10, 0x35cc <generic_fentry_process_event+0x323c>
    35dc:      	tbnz	w21, #0x1f, 0x35f8 <generic_fentry_process_event+0x3268>
    35e0:      	ldr	x8, [sp, #0x38]
    35e4:      	cmn	x22, #0x1
    35e8:      	stur	xzr, [x8, #0x4]
    35ec:      	sub	w8, w22, w21
    35f0:      	csel	w8, wzr, w8, eq
    35f4:      	b	0x3608 <generic_fentry_process_event+0x3278>
    35f8:      	ldr	x9, [sp, #0x38]
    35fc:      	mov	w8, wzr
    3600:      	stp	w21, wzr, [x9, #0x4]
    3604:      	mov	w21, wzr
    3608:      	ldr	x9, [sp, #0x38]
    360c:      	mov	w25, #0x24              // =36
    3610:      	stp	w8, w21, [x9, #0xc]
    3614:      	b	0x3b1c <generic_fentry_process_event+0x378c>
    3618:      	ldrb	w8, [x24, #0x7]
    361c:      	lsl	w8, w8, #2
    3620:      	add	w8, w8, #0x8
    3624:      	strh	w8, [x24, #0x2]
    3628:      	ldrh	w9, [x24]
    362c:      	ldrb	w25, [x24, #0x6]
    3630:      	add	w8, w9, w8
    3634:      	cmp	w25, #0x3c
    3638:      	strh	w8, [x24]
    363c:      	b.hi	0x3c30 <generic_fentry_process_event+0x38a0>
    3640:      	mov	x10, #0x1               // =1
    3644:      	mov	w9, #0x1                // =1
    3648:      	movk	x10, #0x1800, lsl #32
    364c:      	lsl	x9, x9, x25
    3650:      	movk	x10, #0x1008, lsl #48
    3654:      	tst	x9, x10
    3658:      	b.eq	0x3c30 <generic_fentry_process_event+0x38a0>
    365c:      	strb	w25, [x24, #0x5]
    3660:      	add	x8, x22, w8, uxth
    3664:      	mov	w9, #0x2                // =2
    3668:      	mov	w10, #0x4               // =4
    366c:      	mov	x0, x23
    3670:      	mov	w1, #0x2                // =2
    3674:      	ldrh	w8, [x24]
    3678:      	add	x2, x22, x8
    367c:      	blr	x10
    3680:      	tbnz	x0, #0x3f, 0x3990 <generic_fentry_process_event+0x3600>
    3684:      	ldrb	w8, [x24, #0x5]
    3688:      	cmp	w8, #0x32
    368c:      	b.gt	0x36ac <generic_fentry_process_event+0x331c>
    3690:      	cbz	w8, 0x36cc <generic_fentry_process_event+0x333c>
    3694:      	cmp	w8, #0x2b
    3698:      	b.eq	0x36cc <generic_fentry_process_event+0x333c>
    369c:      	cmp	w8, #0x2c
    36a0:      	b.ne	0x3828 <generic_fentry_process_event+0x3498>
    36a4:      	mov	w8, #0x8                // =8
    36a8:      	b	0x3774 <generic_fentry_process_event+0x33e4>
    36ac:      	cmp	w8, #0x33
    36b0:      	b.eq	0x3768 <generic_fentry_process_event+0x33d8>
    36b4:      	cmp	w8, #0x3c
    36b8:      	b.eq	0x36cc <generic_fentry_process_event+0x333c>
    36bc:      	cmp	w8, #0xff
    36c0:      	b.ne	0x3828 <generic_fentry_process_event+0x3498>
    36c4:      	mov	w8, #0x28               // =40
    36c8:      	b	0x3774 <generic_fentry_process_event+0x33e4>
    36cc:      	ldrb	w8, [x24, #0x7]
    36d0:      	lsl	w8, w8, #3
    36d4:      	b	0x3770 <generic_fentry_process_event+0x33e0>
    36d8:      	ldrh	w8, [x24, #0x2]
    36dc:      	ldrh	w9, [x24]
    36e0:      	ldrb	w25, [x24, #0x6]
    36e4:      	add	w8, w9, w8
    36e8:      	cmp	w25, #0x3c
    36ec:      	strh	w8, [x24]
    36f0:      	b.ls	0x3640 <generic_fentry_process_event+0x32b0>
    36f4:      	b	0x3c30 <generic_fentry_process_event+0x38a0>
    36f8:      	add	x8, x0, #0x568
    36fc:      	b	0x371c <generic_fentry_process_event+0x338c>
    3700:      	add	x8, x0, #0x570
    3704:      	b	0x371c <generic_fentry_process_event+0x338c>
    3708:      	add	x8, x0, #0x540
    370c:      	b	0x371c <generic_fentry_process_event+0x338c>
    3710:      	add	x8, x0, #0x560
    3714:      	b	0x371c <generic_fentry_process_event+0x338c>
    3718:      	add	x8, x0, #0x550
    371c:      	ldaxr	x9, [x8]
    3720:      	add	x9, x9, #0x1
    3724:      	stlxr	w10, x9, [x8]
    3728:      	cbnz	w10, 0x371c <generic_fentry_process_event+0x338c>
    372c:      	tbnz	w25, #0x1f, 0x3748 <generic_fentry_process_event+0x33b8>
    3730:      	ldr	x8, [sp, #0x18]
    3734:      	cmn	x21, #0x1
    3738:      	stur	xzr, [x8, #0x4]
    373c:      	sub	w8, w21, w25
    3740:      	csel	w8, wzr, w8, eq
    3744:      	b	0x3758 <generic_fentry_process_event+0x33c8>
    3748:      	ldr	x9, [sp, #0x18]
    374c:      	mov	w8, wzr
    3750:      	stp	w25, wzr, [x9, #0x4]
    3754:      	mov	w25, wzr
    3758:      	ldr	x9, [sp, #0x18]
    375c:      	stp	w8, w25, [x9, #0xc]
    3760:      	mov	w25, #0x24              // =36
    3764:      	b	0x3b14 <generic_fentry_process_event+0x3784>
    3768:      	ldrb	w8, [x24, #0x7]
    376c:      	lsl	w8, w8, #2
    3770:      	add	w8, w8, #0x8
    3774:      	strh	w8, [x24, #0x2]
    3778:      	ldrh	w9, [x24]
    377c:      	ldrb	w25, [x24, #0x6]
    3780:      	add	w8, w9, w8
    3784:      	cmp	w25, #0x3c
    3788:      	strh	w8, [x24]
    378c:      	b.hi	0x3c30 <generic_fentry_process_event+0x38a0>
    3790:      	mov	x10, #0x1               // =1
    3794:      	mov	w9, #0x1                // =1
    3798:      	movk	x10, #0x1800, lsl #32
    379c:      	lsl	x9, x9, x25
    37a0:      	movk	x10, #0x1008, lsl #48
    37a4:      	tst	x9, x10
    37a8:      	b.eq	0x3c30 <generic_fentry_process_event+0x38a0>
    37ac:      	strb	w25, [x24, #0x5]
    37b0:      	add	x8, x22, w8, uxth
    37b4:      	mov	w9, #0x2                // =2
    37b8:      	mov	w10, #0x4               // =4
    37bc:      	mov	x0, x23
    37c0:      	mov	w1, #0x2                // =2
    37c4:      	ldrh	w8, [x24]
    37c8:      	add	x2, x22, x8
    37cc:      	blr	x10
    37d0:      	tbnz	x0, #0x3f, 0x3990 <generic_fentry_process_event+0x3600>
    37d4:      	ldrb	w8, [x24, #0x5]
    37d8:      	cmp	w8, #0x32
    37dc:      	b.gt	0x37fc <generic_fentry_process_event+0x346c>
    37e0:      	cbz	w8, 0x381c <generic_fentry_process_event+0x348c>
    37e4:      	cmp	w8, #0x2b
    37e8:      	b.eq	0x381c <generic_fentry_process_event+0x348c>
    37ec:      	cmp	w8, #0x2c
    37f0:      	b.ne	0x3908 <generic_fentry_process_event+0x3578>
    37f4:      	mov	w8, #0x8                // =8
    37f8:      	b	0x3854 <generic_fentry_process_event+0x34c4>
    37fc:      	cmp	w8, #0x33
    3800:      	b.eq	0x3848 <generic_fentry_process_event+0x34b8>
    3804:      	cmp	w8, #0x3c
    3808:      	b.eq	0x381c <generic_fentry_process_event+0x348c>
    380c:      	cmp	w8, #0xff
    3810:      	b.ne	0x3908 <generic_fentry_process_event+0x3578>
    3814:      	mov	w8, #0x28               // =40
    3818:      	b	0x3854 <generic_fentry_process_event+0x34c4>
    381c:      	ldrb	w8, [x24, #0x7]
    3820:      	lsl	w8, w8, #3
    3824:      	b	0x3850 <generic_fentry_process_event+0x34c0>
    3828:      	ldrh	w8, [x24, #0x2]
    382c:      	ldrh	w9, [x24]
    3830:      	ldrb	w25, [x24, #0x6]
    3834:      	add	w8, w9, w8
    3838:      	cmp	w25, #0x3c
    383c:      	strh	w8, [x24]
    3840:      	b.ls	0x3790 <generic_fentry_process_event+0x3400>
    3844:      	b	0x3c30 <generic_fentry_process_event+0x38a0>
    3848:      	ldrb	w8, [x24, #0x7]
    384c:      	lsl	w8, w8, #2
    3850:      	add	w8, w8, #0x8
    3854:      	strh	w8, [x24, #0x2]
    3858:      	ldrh	w9, [x24]
    385c:      	ldrb	w25, [x24, #0x6]
    3860:      	add	w8, w9, w8
    3864:      	cmp	w25, #0x3c
    3868:      	strh	w8, [x24]
    386c:      	b.hi	0x3c30 <generic_fentry_process_event+0x38a0>
    3870:      	mov	x10, #0x1               // =1
    3874:      	mov	w9, #0x1                // =1
    3878:      	movk	x10, #0x1800, lsl #32
    387c:      	lsl	x9, x9, x25
    3880:      	movk	x10, #0x1008, lsl #48
    3884:      	tst	x9, x10
    3888:      	b.eq	0x3c30 <generic_fentry_process_event+0x38a0>
    388c:      	strb	w25, [x24, #0x5]
    3890:      	add	x8, x22, w8, uxth
    3894:      	mov	w9, #0x2                // =2
    3898:      	mov	w10, #0x4               // =4
    389c:      	mov	x0, x23
    38a0:      	mov	w1, #0x2                // =2
    38a4:      	ldrh	w8, [x24]
    38a8:      	add	x2, x22, x8
    38ac:      	blr	x10
    38b0:      	tbnz	x0, #0x3f, 0x3990 <generic_fentry_process_event+0x3600>
    38b4:      	ldrb	w8, [x24, #0x5]
    38b8:      	cmp	w8, #0x32
    38bc:      	b.gt	0x38dc <generic_fentry_process_event+0x354c>
    38c0:      	cbz	w8, 0x38fc <generic_fentry_process_event+0x356c>
    38c4:      	cmp	w8, #0x2b
    38c8:      	b.eq	0x38fc <generic_fentry_process_event+0x356c>
    38cc:      	cmp	w8, #0x2c
    38d0:      	b.ne	0x3c14 <generic_fentry_process_event+0x3884>
    38d4:      	mov	w8, #0x8                // =8
    38d8:      	b	0x3934 <generic_fentry_process_event+0x35a4>
    38dc:      	cmp	w8, #0x33
    38e0:      	b.eq	0x3928 <generic_fentry_process_event+0x3598>
    38e4:      	cmp	w8, #0x3c
    38e8:      	b.eq	0x38fc <generic_fentry_process_event+0x356c>
    38ec:      	cmp	w8, #0xff
    38f0:      	b.ne	0x3c14 <generic_fentry_process_event+0x3884>
    38f4:      	mov	w8, #0x28               // =40
    38f8:      	b	0x3934 <generic_fentry_process_event+0x35a4>
    38fc:      	ldrb	w8, [x24, #0x7]
    3900:      	lsl	w8, w8, #3
    3904:      	b	0x3930 <generic_fentry_process_event+0x35a0>
    3908:      	ldrh	w8, [x24, #0x2]
    390c:      	ldrh	w9, [x24]
    3910:      	ldrb	w25, [x24, #0x6]
    3914:      	add	w8, w9, w8
    3918:      	cmp	w25, #0x3c
    391c:      	strh	w8, [x24]
    3920:      	b.ls	0x3870 <generic_fentry_process_event+0x34e0>
    3924:      	b	0x3c30 <generic_fentry_process_event+0x38a0>
    3928:      	ldrb	w8, [x24, #0x7]
    392c:      	lsl	w8, w8, #2
    3930:      	add	w8, w8, #0x8
    3934:      	strh	w8, [x24, #0x2]
    3938:      	ldrh	w9, [x24]
    393c:      	ldrb	w25, [x24, #0x6]
    3940:      	add	w8, w9, w8
    3944:      	cmp	w25, #0x3c
    3948:      	strh	w8, [x24]
    394c:      	b.hi	0x3c30 <generic_fentry_process_event+0x38a0>
    3950:      	mov	x10, #0x1               // =1
    3954:      	mov	w9, #0x1                // =1
    3958:      	movk	x10, #0x1800, lsl #32
    395c:      	lsl	x9, x9, x25
    3960:      	movk	x10, #0x1008, lsl #48
    3964:      	tst	x9, x10
    3968:      	b.eq	0x3c30 <generic_fentry_process_event+0x38a0>
    396c:      	strb	w25, [x24, #0x5]
    3970:      	add	x8, x22, w8, uxth
    3974:      	mov	w9, #0x2                // =2
    3978:      	mov	w10, #0x4               // =4
    397c:      	mov	x0, x23
    3980:      	mov	w1, #0x2                // =2
    3984:      	ldrh	w8, [x24]
    3988:      	add	x2, x22, x8
    398c:      	blr	x10
    3990:      	mov	w25, wzr
    3994:      	ldr	x22, [sp, #0x18]
    3998:      	mov	w8, #0xa                // =10
    399c:      	strb	w25, [sp, #0x78]
    39a0:      	add	x2, x29, #0x8
    39a4:      	mov	w23, #0x10              // =16
    39a8:      	mov	w1, #0x10               // =16
    39ac:      	mov	w24, #0x4               // =4
    39b0:      	strh	w25, [x22, #0x24]
    39b4:      	strh	w8, [x22, #0x26]
    39b8:      	mov	w8, #0x4                // =4
    39bc:      	mov	x0, x22
    39c0:      	blr	x8
    39c4:      	add	x0, x22, #0x10
    39c8:      	add	x2, x29, #0x18
    39cc:      	mov	w1, #0x10               // =16
    39d0:      	blr	x24
    39d4:      	cmp	w25, #0x11
    39d8:      	b.eq	0x3a1c <generic_fentry_process_event+0x368c>
    39dc:      	cmp	w25, #0x6
    39e0:      	b.ne	0x3a5c <generic_fentry_process_event+0x36cc>
    39e4:      	ldr	x8, [sp, #0x88]
    39e8:      	ldrh	w9, [sp, #0xc8]
    39ec:      	mov	w24, #0x2               // =2
    39f0:      	mov	w1, #0x2                // =2
    39f4:      	mov	w25, #0x4               // =4
    39f8:      	add	x23, x8, x9
    39fc:      	ldr	x22, [sp, #0x18]
    3a00:      	add	x0, x22, #0x20
    3a04:      	mov	w8, #0x4                // =4
    3a08:      	mov	x2, x23
    3a0c:      	blr	x8
    3a10:      	add	x0, x22, #0x22
    3a14:      	add	x2, x23, #0x2
    3a18:      	b	0x3a50 <generic_fentry_process_event+0x36c0>
    3a1c:      	ldr	x8, [sp, #0x88]
    3a20:      	ldrh	w9, [sp, #0xc8]
    3a24:      	mov	w24, #0x2               // =2
    3a28:      	mov	w1, #0x2                // =2
    3a2c:      	mov	w25, #0x4               // =4
    3a30:      	add	x23, x8, x9
    3a34:      	ldr	x22, [sp, #0x18]
    3a38:      	add	x0, x22, #0x20
    3a3c:      	mov	w8, #0x4                // =4
    3a40:      	mov	x2, x23
    3a44:      	blr	x8
    3a48:      	add	x0, x22, #0x22
    3a4c:      	add	x2, x23, #0x2
    3a50:      	mov	w1, #0x2                // =2
    3a54:      	blr	x25
    3a58:      	b	0x3a64 <generic_fentry_process_event+0x36d4>
    3a5c:      	ldr	x8, [sp, #0x18]
    3a60:      	str	wzr, [x8, #0x20]
    3a64:      	ldr	x9, [sp, #0x18]
    3a68:      	add	x2, x21, #0xe0
    3a6c:      	add	x10, sp, #0xe0
    3a70:      	add	x0, sp, #0xe0
    3a74:      	ldrh	w8, [x9, #0x20]
    3a78:      	mov	w1, #0x8                // =8
    3a7c:      	rev	w8, w8
    3a80:      	lsr	w8, w8, #16
    3a84:      	strh	w8, [x9, #0x20]
    3a88:      	ldrh	w8, [x9, #0x22]
    3a8c:      	rev	w8, w8
    3a90:      	lsr	w8, w8, #16
    3a94:      	strh	w8, [x9, #0x22]
    3a98:      	mov	w8, #0x8                // =8
    3a9c:      	mov	w9, #0x4                // =4
    3aa0:      	blr	x9
    3aa4:      	add	x8, sp, #0xd0
    3aa8:      	ldr	x8, [x8, #0x10]
    3aac:      	cbz	x8, 0x3b10 <generic_fentry_process_event+0x3780>
    3ab0:      	add	x8, x8, #0x5
    3ab4:      	mov	w9, #0x8                // =8
    3ab8:      	add	x10, sp, #0x60
    3abc:      	mov	w11, #0x4               // =4
    3ac0:      	add	x22, sp, #0xd0
    3ac4:      	ldr	x8, [x22, #0x10]
    3ac8:      	add	x0, sp, #0x60
    3acc:      	mov	w1, #0x8                // =8
    3ad0:      	mov	w21, #0x4               // =4
    3ad4:      	add	x2, x8, #0x5
    3ad8:      	blr	x11
    3adc:      	ldr	x8, [x22, #0x10]
    3ae0:      	ldr	x9, [sp, #0x60]
    3ae4:      	mov	w1, #0x4                // =4
    3ae8:      	add	x23, x8, x9, lsl #3
    3aec:      	ldr	x22, [sp, #0x18]
    3af0:      	add	x0, x22, #0x38
    3af4:      	mov	w8, #0x4                // =4
    3af8:      	add	x2, x23, #0x44
    3afc:      	blr	x8
    3b00:      	add	x0, x22, #0x3c
    3b04:      	add	x2, x23, #0x45
    3b08:      	mov	w1, #0x4                // =4
    3b0c:      	blr	x21
    3b10:      	mov	w25, #0x40              // =64
    3b14:      	adrp	x29, 0x3000 <generic_fentry_process_event+0x2c70>
    3b18:      	ldr	x29, [x29]
    3b1c:      	ldr	x12, [sp, #0x28]
    3b20:      	ldr	x10, [sp, #0x20]
    3b24:      	mov	w9, #0x5ea0             // =24224
    3b28:      	tbnz	w25, #0x1f, 0x3c00 <generic_fentry_process_event+0x3870>
    3b2c:      	and	x8, x25, #0x7fffffff
    3b30:      	add	x8, x8, #0x4
    3b34:      	ldr	x25, [sp, #0x40]
    3b38:      	mov	w22, #0x5efc            // =24316
    3b3c:      	adrp	x21, 0x3000 <generic_fentry_process_event+0x2c70>
    3b40:      	ldr	x21, [x21]
    3b44:      	ldr	x24, [sp, #0xf8]
    3b48:      	add	w24, w24, w8
    3b4c:      	cmp	w25, #0x3
    3b50:      	str	w24, [x20, #0x4]
    3b54:      	b.gt	0x3bc4 <generic_fentry_process_event+0x3834>
    3b58:      	str	wzr, [sp, #0x88]
    3b5c:      	mov	w8, #0x1                // =1
    3b60:      	add	x9, sp, #0x88
    3b64:      	add	x1, sp, #0x88
    3b68:      	mov	x0, x21
    3b6c:      	blr	x8
    3b70:      	cbz	x0, 0x3bc4 <generic_fentry_process_event+0x3834>
    3b74:      	mov	w8, #0x5ef8             // =24312
    3b78:      	add	x1, x0, x8
    3b7c:      	adrp	x0, 0x3000 <generic_fentry_process_event+0x2c70>
    3b80:      	mov	w8, #0x1                // =1
    3b84:      	ldr	x0, [x0]
    3b88:      	blr	x8
    3b8c:      	cbz	x0, 0x3bc4 <generic_fentry_process_event+0x3834>
    3b90:      	add	w8, w25, #0x1
    3b94:      	and	w9, w8, #0x7
    3b98:      	add	x9, x0, w9, uxtw #2
    3b9c:      	ldr	w9, [x9, #0x40]
    3ba0:      	cmn	w9, #0x1
    3ba4:      	b.eq	0x3bc4 <generic_fentry_process_event+0x3834>
    3ba8:      	str	w8, [x20, x22]
    3bac:      	mov	w8, #0x1                // =1
    3bb0:      	mov	w9, #0xc                // =12
    3bb4:      	mov	x0, x19
    3bb8:      	mov	x1, x29
    3bbc:      	mov	w2, #0x1                // =1
    3bc0:      	blr	x9
    3bc4:      	str	wzr, [x20, x22]
    3bc8:      	mov	w8, #0x3                // =3
    3bcc:      	mov	w9, #0xc                // =12
    3bd0:      	mov	x0, x19
    3bd4:      	mov	x1, x29
    3bd8:      	mov	w2, #0x3                // =3
    3bdc:      	blr	x9
    3be0:      	ldp	x20, x19, [sp, #0x130]
    3be4:      	mov	w0, wzr
    3be8:      	ldr	x29, [sp, #0xf0]
    3bec:      	ldp	x22, x21, [sp, #0x120]
    3bf0:      	ldp	x24, x23, [sp, #0x110]
    3bf4:      	ldp	x30, x25, [sp, #0x100]
    3bf8:      	add	sp, sp, #0x140
    3bfc:      	ret
    3c00:      	mov	w8, #-0x1               // =-1
    3c04:      	str	w8, [x12, x9]
    3c08:      	ldr	x9, [sp, #0xf8]
    3c0c:      	str	w8, [x10, x9]
    3c10:      	b	0xf90 <generic_fentry_process_event+0xc00>
    3c14:      	ldrh	w8, [x24, #0x2]
    3c18:      	ldrh	w9, [x24]
    3c1c:      	ldrb	w25, [x24, #0x6]
    3c20:      	add	w8, w9, w8
    3c24:      	cmp	w25, #0x3c
    3c28:      	strh	w8, [x24]
    3c2c:      	b.ls	0x3950 <generic_fentry_process_event+0x35c0>
    3c30:      	strh	w8, [sp, #0xc8]
    3c34:      	b	0x3994 <generic_fentry_process_event+0x3604>
    3c38:      	nop
    3c3c:      	nop

0000000000003c40 <generic_fentry_process_filter>:
    3c40:      	sub	sp, sp, #0x130
    3c44:      	str	x29, [sp, #0xe0]
    3c48:      	stp	x30, x25, [sp, #0xf0]
    3c4c:      	stp	x24, x23, [sp, #0x100]
    3c50:      	stp	x22, x21, [sp, #0x110]
    3c54:      	stp	x20, x19, [sp, #0x120]
    3c58:      	mov	x20, x0
    3c5c:      	str	wzr, [sp, #0x54]
    3c60:      	adrp	x0, 0x3000 <generic_fentry_process_event+0x2c70>
    3c64:      	mov	w8, #0x1                // =1
    3c68:      	ldr	x0, [x0]
    3c6c:      	add	x9, sp, #0x54
    3c70:      	add	x1, sp, #0x54
    3c74:      	blr	x8
    3c78:      	cbz	x0, 0x5f6c <generic_fentry_process_filter+0x232c>
    3c7c:      	mov	w8, #0x5ec0             // =24256
    3c80:      	mov	x22, x0
    3c84:      	add	x29, x0, x8
    3c88:      	mov	w8, #0x23               // =35
    3c8c:      	blr	x8
    3c90:      	str	x0, [sp, #0x58]
    3c94:      	add	x8, x0, #0x8d4
    3c98:      	mov	w9, #0x4                // =4
    3c9c:      	mov	w10, #0x71              // =113
    3ca0:      	add	x11, sp, #0xd8
    3ca4:      	add	x0, sp, #0xd8
    3ca8:      	mov	w1, #0x4                // =4
    3cac:      	ldr	x8, [sp, #0x58]
    3cb0:      	add	x2, x8, #0x8d4
    3cb4:      	blr	x10
    3cb8:      	ldr	w8, [sp, #0xd8]
    3cbc:      	adrp	x19, 0x3000 <generic_fentry_process_event+0x2c70>
    3cc0:      	add	x9, sp, #0xc8
    3cc4:      	add	x1, sp, #0xc8
    3cc8:      	str	w8, [sp, #0xc8]
    3ccc:      	mov	w8, #0x1                // =1
    3cd0:      	ldr	x19, [x19]
    3cd4:      	mov	x0, x19
    3cd8:      	blr	x8
    3cdc:      	cbz	x0, 0x3cec <generic_fentry_process_filter+0xac>
    3ce0:      	ldr	x8, [x0, #0x8]
    3ce4:      	mov	x24, x0
    3ce8:      	cbnz	x8, 0x4acc <generic_fentry_process_filter+0xe8c>
    3cec:      	ldr	x8, [sp, #0x58]
    3cf0:      	mov	w9, #0x8                // =8
    3cf4:      	mov	w10, #0x71              // =113
    3cf8:      	add	x11, sp, #0x58
    3cfc:      	add	x0, sp, #0x58
    3d00:      	mov	w1, #0x8                // =8
    3d04:      	add	x8, x8, #0x8e0
    3d08:      	ldr	x8, [sp, #0x58]
    3d0c:      	add	x2, x8, #0x8e0
    3d10:      	blr	x10
    3d14:      	ldr	x8, [sp, #0x58]
    3d18:      	cbz	x8, 0x3e94 <generic_fentry_process_filter+0x254>
    3d1c:      	add	x8, x8, #0x8d4
    3d20:      	mov	w9, #0x4                // =4
    3d24:      	mov	w10, #0x71              // =113
    3d28:      	add	x11, sp, #0xd8
    3d2c:      	ldr	x8, [sp, #0x58]
    3d30:      	add	x0, sp, #0xd8
    3d34:      	mov	w1, #0x4                // =4
    3d38:      	add	x2, x8, #0x8d4
    3d3c:      	blr	x10
    3d40:      	ldr	w8, [sp, #0xd8]
    3d44:      	add	x9, sp, #0xc8
    3d48:      	add	x1, sp, #0xc8
    3d4c:      	mov	x0, x19
    3d50:      	str	w8, [sp, #0xc8]
    3d54:      	mov	w8, #0x1                // =1
    3d58:      	blr	x8
    3d5c:      	cbz	x0, 0x3d6c <generic_fentry_process_filter+0x12c>
    3d60:      	ldr	x8, [x0, #0x8]
    3d64:      	mov	x24, x0
    3d68:      	cbnz	x8, 0x4acc <generic_fentry_process_filter+0xe8c>
    3d6c:      	ldr	x8, [sp, #0x58]
    3d70:      	mov	w9, #0x8                // =8
    3d74:      	mov	w10, #0x71              // =113
    3d78:      	add	x11, sp, #0x58
    3d7c:      	add	x0, sp, #0x58
    3d80:      	mov	w1, #0x8                // =8
    3d84:      	add	x8, x8, #0x8e0
    3d88:      	ldr	x8, [sp, #0x58]
    3d8c:      	add	x2, x8, #0x8e0
    3d90:      	blr	x10
    3d94:      	ldr	x8, [sp, #0x58]
    3d98:      	cbz	x8, 0x3e94 <generic_fentry_process_filter+0x254>
    3d9c:      	add	x8, x8, #0x8d4
    3da0:      	mov	w9, #0x4                // =4
    3da4:      	mov	w10, #0x71              // =113
    3da8:      	add	x11, sp, #0xd8
    3dac:      	ldr	x8, [sp, #0x58]
    3db0:      	add	x0, sp, #0xd8
    3db4:      	mov	w1, #0x4                // =4
    3db8:      	add	x2, x8, #0x8d4
    3dbc:      	blr	x10
    3dc0:      	ldr	w8, [sp, #0xd8]
    3dc4:      	add	x9, sp, #0xc8
    3dc8:      	add	x1, sp, #0xc8
    3dcc:      	mov	x0, x19
    3dd0:      	str	w8, [sp, #0xc8]
    3dd4:      	mov	w8, #0x1                // =1
    3dd8:      	blr	x8
    3ddc:      	cbz	x0, 0x3dec <generic_fentry_process_filter+0x1ac>
    3de0:      	ldr	x8, [x0, #0x8]
    3de4:      	mov	x24, x0
    3de8:      	cbnz	x8, 0x4acc <generic_fentry_process_filter+0xe8c>
    3dec:      	ldr	x8, [sp, #0x58]
    3df0:      	mov	w9, #0x8                // =8
    3df4:      	mov	w10, #0x71              // =113
    3df8:      	add	x11, sp, #0x58
    3dfc:      	add	x0, sp, #0x58
    3e00:      	mov	w1, #0x8                // =8
    3e04:      	add	x8, x8, #0x8e0
    3e08:      	ldr	x8, [sp, #0x58]
    3e0c:      	add	x2, x8, #0x8e0
    3e10:      	blr	x10
    3e14:      	ldr	x8, [sp, #0x58]
    3e18:      	cbz	x8, 0x3e94 <generic_fentry_process_filter+0x254>
    3e1c:      	add	x8, x8, #0x8d4
    3e20:      	mov	w9, #0x4                // =4
    3e24:      	mov	w10, #0x71              // =113
    3e28:      	add	x11, sp, #0xd8
    3e2c:      	ldr	x8, [sp, #0x58]
    3e30:      	add	x0, sp, #0xd8
    3e34:      	mov	w1, #0x4                // =4
    3e38:      	add	x2, x8, #0x8d4
    3e3c:      	blr	x10
    3e40:      	ldr	w8, [sp, #0xd8]
    3e44:      	add	x9, sp, #0xc8
    3e48:      	add	x1, sp, #0xc8
    3e4c:      	mov	x0, x19
    3e50:      	str	w8, [sp, #0xc8]
    3e54:      	mov	w8, #0x1                // =1
    3e58:      	blr	x8
    3e5c:      	cbz	x0, 0x3e6c <generic_fentry_process_filter+0x22c>
    3e60:      	ldr	x8, [x0, #0x8]
    3e64:      	mov	x24, x0
    3e68:      	cbnz	x8, 0x4acc <generic_fentry_process_filter+0xe8c>
    3e6c:      	ldr	x8, [sp, #0x58]
    3e70:      	mov	w9, #0x8                // =8
    3e74:      	mov	w10, #0x71              // =113
    3e78:      	add	x11, sp, #0x58
    3e7c:      	add	x0, sp, #0x58
    3e80:      	mov	w1, #0x8                // =8
    3e84:      	add	x8, x8, #0x8e0
    3e88:      	ldr	x8, [sp, #0x58]
    3e8c:      	add	x2, x8, #0x8e0
    3e90:      	blr	x10
    3e94:      	str	x20, [sp, #0x38]
    3e98:      	mov	w8, #0x23               // =35
    3e9c:      	blr	x8
    3ea0:      	add	x2, x0, #0x8d4
    3ea4:      	mov	w8, #0x4                // =4
    3ea8:      	add	x9, sp, #0x58
    3eac:      	mov	x24, x0
    3eb0:      	add	x0, sp, #0x58
    3eb4:      	mov	w1, #0x4                // =4
    3eb8:      	blr	x8
    3ebc:      	ldr	w8, [sp, #0x58]
    3ec0:      	mov	x19, x29
    3ec4:      	str	w8, [x19, #0x50]!
    3ec8:      	mov	w8, #0x7d               // =125
    3ecc:      	blr	x8
    3ed0:      	str	x0, [x22, #0x5f18]
    3ed4:      	str	wzr, [x19, #0x10]
    3ed8:      	add	x2, x24, #0x60
    3edc:      	mov	w8, #0x8                // =8
    3ee0:      	mov	w9, #0x71               // =113
    3ee4:      	add	x10, sp, #0xc8
    3ee8:      	str	xzr, [x22, #0x5f28]
    3eec:      	str	x19, [sp, #0x48]
    3ef0:      	add	x0, sp, #0xc8
    3ef4:      	mov	w1, #0x8                // =8
    3ef8:      	str	wzr, [x19, #0x20]
    3efc:      	blr	x9
    3f00:      	ldr	x8, [sp, #0xc8]
    3f04:      	cbz	x8, 0x3f74 <generic_fentry_process_filter+0x334>
    3f08:      	add	x8, x8, #0x4
    3f0c:      	mov	w9, #0x4                // =4
    3f10:      	mov	w10, #0x71              // =113
    3f14:      	add	x11, sp, #0xd8
    3f18:      	ldr	x8, [sp, #0xc8]
    3f1c:      	add	x0, sp, #0xd8
    3f20:      	mov	w1, #0x4                // =4
    3f24:      	add	x2, x8, #0x4
    3f28:      	blr	x10
    3f2c:      	ldr	w8, [sp, #0xd8]
    3f30:      	cbz	w8, 0x3f74 <generic_fentry_process_filter+0x334>
    3f34:      	ldr	x9, [sp, #0xc8]
    3f38:      	lsl	w8, w8, #4
    3f3c:      	mov	w10, #0x71              // =113
    3f40:      	add	x11, sp, #0x58
    3f44:      	add	x0, sp, #0x58
    3f48:      	mov	w1, #0x10               // =16
    3f4c:      	add	x8, x9, x8
    3f50:      	mov	w9, #0x10               // =16
    3f54:      	add	x8, x8, #0x80
    3f58:      	ldr	w9, [sp, #0xd8]
    3f5c:      	ldr	x8, [sp, #0xc8]
    3f60:      	lsl	w9, w9, #4
    3f64:      	add	x8, x8, x9
    3f68:      	add	x2, x8, #0x80
    3f6c:      	blr	x10
    3f70:      	ldr	w8, [sp, #0x58]
    3f74:      	str	w8, [x29, #0x74]
    3f78:      	mov	w8, #0x5f60             // =24416
    3f7c:      	str	x22, [sp, #0xe8]
    3f80:      	add	x23, x24, #0xae0
    3f84:      	mov	w19, #0x8               // =8
    3f88:      	add	x25, x22, x8
    3f8c:      	add	x8, sp, #0x58
    3f90:      	mov	w9, #0x4                // =4
    3f94:      	add	x0, sp, #0x58
    3f98:      	mov	w1, #0x8                // =8
    3f9c:      	mov	x2, x23
    3fa0:      	mov	w21, #0x4               // =4
    3fa4:      	blr	x9
    3fa8:      	ldr	x20, [sp, #0x58]
    3fac:      	ldr	x9, [sp, #0xe8]
    3fb0:      	mov	w8, #0x5f68             // =24424
    3fb4:      	mov	w1, #0x8                // =8
    3fb8:      	add	x0, x9, x8
    3fbc:      	add	x2, x20, #0x40
    3fc0:      	mov	w8, #0x4                // =4
    3fc4:      	blr	x8
    3fc8:      	ldr	x9, [sp, #0xe8]
    3fcc:      	mov	w8, #0x5f70             // =24432
    3fd0:      	add	x2, x20, #0x30
    3fd4:      	mov	w1, #0x8                // =8
    3fd8:      	add	x0, x9, x8
    3fdc:      	mov	w8, #0x4                // =4
    3fe0:      	blr	x8
    3fe4:      	add	x2, x20, #0x38
    3fe8:      	mov	w8, #0x4                // =4
    3fec:      	mov	x0, x25
    3ff0:      	mov	w1, #0x8                // =8
    3ff4:      	blr	x8
    3ff8:      	ldr	x9, [sp, #0xe8]
    3ffc:      	mov	w8, #0x5f38             // =24376
    4000:      	add	x2, x24, #0xb50
    4004:      	add	x0, sp, #0xd8
    4008:      	mov	w1, #0x8                // =8
    400c:      	add	x25, x9, x8
    4010:      	add	x8, sp, #0xd8
    4014:      	mov	w9, #0x4                // =4
    4018:      	blr	x9
    401c:      	add	x12, sp, #0xd8
    4020:      	mov	w9, #0x48               // =72
    4024:      	add	x10, sp, #0x58
    4028:      	ldr	x8, [x12]
    402c:      	mov	w11, #0x4               // =4
    4030:      	add	x0, sp, #0x58
    4034:      	mov	w1, #0x48               // =72
    4038:      	ldr	x2, [x12]
    403c:      	blr	x11
    4040:      	ldr	x8, [sp, #0x60]
    4044:      	mov	w9, #0x4                // =4
    4048:      	mov	x0, x25
    404c:      	mov	w1, #0x4                // =4
    4050:      	add	x8, x8, #0x218
    4054:      	ldr	x8, [sp, #0x60]
    4058:      	ldr	x22, [sp, #0xe8]
    405c:      	add	x2, x8, #0x218
    4060:      	blr	x9
    4064:      	mov	w8, #0x5f3c             // =24380
    4068:      	mov	w9, #0x4                // =4
    406c:      	mov	w1, #0x4                // =4
    4070:      	add	x0, x22, x8
    4074:      	ldr	x8, [sp, #0x68]
    4078:      	add	x8, x8, #0x4d8
    407c:      	ldr	x8, [sp, #0x68]
    4080:      	add	x2, x8, #0x4d8
    4084:      	blr	x9
    4088:      	mov	w8, #0x5f40             // =24384
    408c:      	mov	w9, #0x4                // =4
    4090:      	mov	w1, #0x4                // =4
    4094:      	add	x0, x22, x8
    4098:      	ldr	x8, [sp, #0x70]
    409c:      	add	x8, x8, #0x58
    40a0:      	ldr	x8, [sp, #0x70]
    40a4:      	add	x2, x8, #0x58
    40a8:      	blr	x9
    40ac:      	str	xzr, [sp, #0xc0]
    40b0:      	add	x2, x24, #0x938
    40b4:      	add	x8, sp, #0xc0
    40b8:      	add	x0, sp, #0xc0
    40bc:      	mov	w1, #0x8                // =8
    40c0:      	blr	x21
    40c4:      	ldr	x8, [sp, #0xc0]
    40c8:      	cbz	x8, 0x4150 <generic_fentry_process_filter+0x510>
    40cc:      	str	wzr, [sp, #0xb8]
    40d0:      	add	x8, x8, #0x4
    40d4:      	add	x9, sp, #0xb8
    40d8:      	mov	w10, #0x4               // =4
    40dc:      	add	x0, sp, #0xb8
    40e0:      	mov	w1, #0x4                // =4
    40e4:      	mov	w19, #0x4               // =4
    40e8:      	ldr	x8, [sp, #0xc0]
    40ec:      	add	x2, x8, #0x4
    40f0:      	blr	x10
    40f4:      	ldr	x8, [sp, #0xc0]
    40f8:      	ldrsw	x9, [sp, #0xb8]
    40fc:      	add	x10, sp, #0xc8
    4100:      	mov	w11, #0x4               // =4
    4104:      	add	x0, sp, #0xc8
    4108:      	mov	w1, #0x10               // =16
    410c:      	add	x8, x8, x9, lsl #4
    4110:      	mov	w9, #0x10               // =16
    4114:      	add	x8, x8, #0x80
    4118:      	ldr	x8, [sp, #0xc0]
    411c:      	ldrsw	x9, [sp, #0xb8]
    4120:      	add	x8, x8, x9, lsl #4
    4124:      	add	x2, x8, #0x80
    4128:      	blr	x11
    412c:      	mov	w8, #0x5f44             // =24388
    4130:      	mov	w1, #0x4                // =4
    4134:      	add	x0, x22, x8
    4138:      	ldr	x8, [sp, #0xd0]
    413c:      	add	x8, x8, #0x158
    4140:      	ldr	x8, [sp, #0xd0]
    4144:      	add	x2, x8, #0x158
    4148:      	blr	x19
    414c:      	b	0x4154 <generic_fentry_process_filter+0x514>
    4150:      	str	wzr, [x29, #0x84]
    4154:      	mov	w8, #0x5f48             // =24392
    4158:      	mov	w9, #0x4                // =4
    415c:      	mov	w1, #0x4                // =4
    4160:      	mov	w19, #0x4               // =4
    4164:      	add	x0, x22, x8
    4168:      	ldr	x8, [sp, #0x78]
    416c:      	add	x8, x8, #0x158
    4170:      	ldr	x8, [sp, #0x78]
    4174:      	add	x2, x8, #0x158
    4178:      	blr	x9
    417c:      	mov	w8, #0x5f4c             // =24396
    4180:      	mov	w9, #0x4                // =4
    4184:      	mov	w1, #0x4                // =4
    4188:      	add	x0, x22, x8
    418c:      	ldr	x8, [sp, #0x80]
    4190:      	add	x8, x8, #0x118
    4194:      	ldr	x8, [sp, #0x80]
    4198:      	add	x2, x8, #0x118
    419c:      	blr	x9
    41a0:      	mov	w8, #0x5f50             // =24400
    41a4:      	mov	w9, #0x4                // =4
    41a8:      	mov	w1, #0x4                // =4
    41ac:      	add	x0, x22, x8
    41b0:      	ldr	x8, [sp, #0x88]
    41b4:      	add	x8, x8, #0x98
    41b8:      	ldr	x8, [sp, #0x88]
    41bc:      	add	x2, x8, #0x98
    41c0:      	blr	x9
    41c4:      	mov	w8, #0x5f54             // =24404
    41c8:      	mov	w9, #0x4                // =4
    41cc:      	mov	w1, #0x4                // =4
    41d0:      	add	x0, x22, x8
    41d4:      	ldr	x8, [sp, #0x90]
    41d8:      	add	x8, x8, #0x98
    41dc:      	ldr	x8, [sp, #0x90]
    41e0:      	add	x2, x8, #0x98
    41e4:      	blr	x9
    41e8:      	mov	w8, #0x5f58             // =24408
    41ec:      	mov	w9, #0x4                // =4
    41f0:      	mov	w1, #0x4                // =4
    41f4:      	add	x0, x22, x8
    41f8:      	ldr	x8, [sp, #0x98]
    41fc:      	add	x8, x8, #0x58
    4200:      	ldr	x8, [sp, #0x98]
    4204:      	add	x2, x8, #0x58
    4208:      	blr	x9
    420c:      	stp	xzr, xzr, [sp, #0xc0]
    4210:      	mov	w20, #0x8               // =8
    4214:      	add	x8, sp, #0xc8
    4218:      	mov	w9, #0x4                // =4
    421c:      	add	x0, sp, #0xc8
    4220:      	mov	w1, #0x8                // =8
    4224:      	mov	x2, x23
    4228:      	blr	x9
    422c:      	ldr	x8, [sp, #0xc8]
    4230:      	add	x9, sp, #0xc0
    4234:      	mov	w10, #0x4               // =4
    4238:      	add	x0, sp, #0xc0
    423c:      	mov	w1, #0x8                // =8
    4240:      	add	x8, x8, #0x90
    4244:      	ldr	x8, [sp, #0xc8]
    4248:      	add	x2, x8, #0x90
    424c:      	blr	x10
    4250:      	mov	w8, #0x5f5c             // =24412
    4254:      	mov	w1, #0x4                // =4
    4258:      	add	x0, x22, x8
    425c:      	ldr	x8, [sp, #0xc0]
    4260:      	add	x8, x8, #0x158
    4264:      	ldr	x8, [sp, #0xc0]
    4268:      	add	x2, x8, #0x158
    426c:      	blr	x19
    4270:      	ldr	w8, [x29, #0x74]
    4274:      	cmp	w8, #0x1
    4278:      	b.ne	0x4288 <generic_fentry_process_filter+0x648>
    427c:      	ldr	w8, [x29, #0x70]
    4280:      	orr	w8, w8, #0x2000000
    4284:      	str	w8, [x29, #0x70]
    4288:      	add	x0, x29, #0xb8
    428c:      	mov	w1, wzr
    4290:      	mov	w2, #0x308              // =776
    4294:      	bl	0x4294 <generic_fentry_process_filter+0x654>
    4298:      	mov	w8, #0x6290             // =25232
    429c:      	add	x2, x24, #0x858
    42a0:      	mov	w19, #0x8               // =8
    42a4:      	mov	w9, #0x4                // =4
    42a8:      	add	x0, sp, #0xc8
    42ac:      	mov	w1, #0x8                // =8
    42b0:      	mov	w20, #0x4               // =4
    42b4:      	add	x21, x22, x8
    42b8:      	add	x8, sp, #0xc8
    42bc:      	blr	x9
    42c0:      	ldr	x8, [sp, #0xc8]
    42c4:      	add	x9, sp, #0x58
    42c8:      	add	x0, sp, #0x58
    42cc:      	mov	w1, #0x8                // =8
    42d0:      	add	x8, x8, #0x528
    42d4:      	ldr	x8, [sp, #0xc8]
    42d8:      	add	x2, x8, #0x528
    42dc:      	blr	x20
    42e0:      	str	wzr, [sp, #0xa4]
    42e4:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x3c0>
    42e8:      	ldr	x19, [sp, #0x58]
    42ec:      	mov	w8, #0x1                // =1
    42f0:      	add	x9, sp, #0xa4
    42f4:      	add	x1, sp, #0xa4
    42f8:      	ldr	x0, [x0]
    42fc:      	blr	x8
    4300:      	cbz	x0, 0x4914 <generic_fentry_process_filter+0xcd4>
    4304:      	mov	w8, #0x1000             // =4096
    4308:      	str	x21, [sp, #0x30]
    430c:      	str	x29, [sp, #0x40]
    4310:      	mov	x24, x0
    4314:      	add	x20, x0, #0x1, lsl #12  // =0x1000
    4318:      	str	w8, [x29, #0x550]
    431c:      	mov	w8, #0x23               // =35
    4320:      	blr	x8
    4324:      	add	x2, x0, #0xb30
    4328:      	mov	w23, #0x8               // =8
    432c:      	add	x8, sp, #0xa8
    4330:      	mov	w9, #0x4                // =4
    4334:      	add	x0, sp, #0xa8
    4338:      	mov	w1, #0x8                // =8
    433c:      	mov	w29, #0x4               // =4
    4340:      	blr	x9
    4344:      	ldr	x22, [sp, #0xa8]
    4348:      	add	x25, x19, #0x48
    434c:      	add	x8, sp, #0xb0
    4350:      	mov	w9, #0x4                // =4
    4354:      	add	x0, sp, #0xb0
    4358:      	mov	w1, #0x8                // =8
    435c:      	mov	x2, x25
    4360:      	blr	x9
    4364:      	ldr	x21, [sp, #0xb0]
    4368:      	add	x8, sp, #0x58
    436c:      	add	x0, sp, #0x58
    4370:      	mov	w1, #0x8                // =8
    4374:      	add	x2, x21, #0x10
    4378:      	blr	x29
    437c:      	ldr	x8, [sp, #0x58]
    4380:      	cbz	x8, 0x45b4 <generic_fentry_process_filter+0x974>
    4384:      	ldr	x8, [sp, #0x40]
    4388:      	stp	xzr, xzr, [sp, #0x58]
    438c:      	add	x21, x22, #0x18
    4390:      	add	x9, sp, #0x58
    4394:      	add	x2, x22, #0x20
    4398:      	mov	w22, #0x8               // =8
    439c:      	stp	x24, xzr, [sp, #0x68]
    43a0:      	add	x0, sp, #0x58
    43a4:      	mov	w1, #0x8                // =8
    43a8:      	add	x29, x19, #0x40
    43ac:      	add	x19, x9, #0x8
    43b0:      	add	x24, x9, #0x18
    43b4:      	stp	xzr, xzr, [sp, #0x78]
    43b8:      	add	x23, x9, #0x20
    43bc:      	str	x20, [sp, #0x88]
    43c0:      	str	x20, [sp, #0x28]
    43c4:      	mov	w20, #0x4               // =4
    43c8:      	ldr	w8, [x8, #0x550]
    43cc:      	strb	wzr, [sp, #0x94]
    43d0:      	str	w8, [sp, #0x90]
    43d4:      	mov	w8, #0x4                // =4
    43d8:      	blr	x8
    43dc:      	mov	w8, #0x4                // =4
    43e0:      	mov	x0, x19
    43e4:      	mov	w1, #0x8                // =8
    43e8:      	mov	x2, x21
    43ec:      	blr	x8
    43f0:      	mov	w8, #0x4                // =4
    43f4:      	mov	x0, x24
    43f8:      	mov	w1, #0x8                // =8
    43fc:      	mov	x2, x25
    4400:      	blr	x8
    4404:      	mov	x0, x23
    4408:      	mov	w1, #0x8                // =8
    440c:      	mov	x2, x29
    4410:      	blr	x20
    4414:      	ldr	x8, [sp, #0x78]
    4418:      	sub	x8, x8, #0x20
    441c:      	str	x8, [sp, #0x80]
    4420:      	adrp	x8, 0x4000 <generic_fentry_process_filter+0x3c0>
    4424:      	ldr	x8, [x8]
    4428:      	ldrb	w8, [x8]
    442c:      	cbz	w8, 0x4608 <generic_fentry_process_filter+0x9c8>
    4430:      	mov	w19, #0x80              // =128
    4434:      	mov	w21, #0x8               // =8
    4438:      	add	x23, sp, #0xb8
    443c:      	add	x29, sp, #0xd8
    4440:      	b	0x4494 <generic_fentry_process_filter+0x854>
    4444:      	add	x2, x22, #0x10
    4448:      	mov	w8, #0x4                // =4
    444c:      	add	x0, sp, #0xd8
    4450:      	mov	w1, #0x8                // =8
    4454:      	blr	x8
    4458:      	add	x20, sp, #0xd8
    445c:      	ldr	x8, [sp, #0x80]
    4460:      	ldr	x9, [x20]
    4464:      	cmp	x8, x9
    4468:      	b.eq	0x4790 <generic_fentry_process_filter+0xb50>
    446c:      	add	x2, x22, #0x18
    4470:      	mov	w8, #0x4                // =4
    4474:      	mov	x0, x24
    4478:      	mov	w1, #0x8                // =8
    447c:      	blr	x8
    4480:      	ldr	x8, [x20]
    4484:      	add	x9, x8, #0x20
    4488:      	stp	x9, x8, [sp, #0x78]
    448c:      	subs	w19, w19, #0x1
    4490:      	b.eq	0x4798 <generic_fentry_process_filter+0xb58>
    4494:      	ldp	x20, x2, [sp, #0x70]
    4498:      	ldp	x8, x9, [sp, #0x58]
    449c:      	cmp	x20, x8
    44a0:      	ccmp	x2, x9, #0x0, eq
    44a4:      	b.eq	0x4790 <generic_fentry_process_filter+0xb50>
    44a8:      	ldr	x22, [sp, #0x80]
    44ac:      	mov	w8, #0x4                // =4
    44b0:      	add	x0, sp, #0xb8
    44b4:      	mov	w1, #0x8                // =8
    44b8:      	blr	x8
    44bc:      	ldr	x8, [sp, #0xb8]
    44c0:      	cmp	x20, x8
    44c4:      	b.eq	0x4444 <generic_fentry_process_filter+0x804>
    44c8:      	add	x25, x20, #0x18
    44cc:      	mov	w8, #0x4                // =4
    44d0:      	add	x0, sp, #0xd8
    44d4:      	mov	w1, #0x8                // =8
    44d8:      	mov	x2, x25
    44dc:      	blr	x8
    44e0:      	add	x8, sp, #0xd8
    44e4:      	ldr	x8, [x8]
    44e8:      	cmp	x8, x20
    44ec:      	b.eq	0x4444 <generic_fentry_process_filter+0x804>
    44f0:      	mov	w8, #0x4                // =4
    44f4:      	add	x9, sp, #0xc0
    44f8:      	add	x0, sp, #0xc0
    44fc:      	mov	w1, #0x8                // =8
    4500:      	mov	x2, x25
    4504:      	blr	x8
    4508:      	add	x2, x20, #0x20
    450c:      	mov	w8, #0x4                // =4
    4510:      	mov	w9, #0x10               // =16
    4514:      	add	x10, sp, #0xc8
    4518:      	add	x0, sp, #0xc8
    451c:      	mov	w1, #0x10               // =16
    4520:      	blr	x8
    4524:      	ldr	w20, [sp, #0xcc]
    4528:      	ldr	x8, [sp, #0x68]
    452c:      	ldr	x10, [sp, #0x88]
    4530:      	sub	x12, x10, x8
    4534:      	ldr	w22, [sp, #0x90]
    4538:      	subs	w10, w20, w22
    453c:      	ldr	x9, [sp, #0xd0]
    4540:      	csel	w10, wzr, w10, lo
    4544:      	cmp	w22, w20
    4548:      	csel	w11, w22, w20, lo
    454c:      	cinc	w13, w11, hi
    4550:      	sub	w14, w22, w13
    4554:      	subs	x12, x12, x13
    4558:      	str	w14, [sp, #0x90]
    455c:      	b.lo	0x4798 <generic_fentry_process_filter+0xb58>
    4560:      	cmp	x12, #0xfff
    4564:      	b.hi	0x4798 <generic_fentry_process_filter+0xb58>
    4568:      	cmp	w22, w20
    456c:      	b.ls	0x4578 <generic_fentry_process_filter+0x938>
    4570:      	mov	w13, #0x2f              // =47
    4574:      	strb	w13, [x8, x12]
    4578:      	add	x25, x8, x12
    457c:      	cmp	w22, w20
    4580:      	add	x2, x9, x10
    4584:      	and	w1, w11, #0xff
    4588:      	mov	w8, #0x4                // =4
    458c:      	cinc	x0, x25, hi
    4590:      	blr	x8
    4594:      	cmp	w22, w20
    4598:      	str	x25, [sp, #0x88]
    459c:      	b.ls	0x4798 <generic_fentry_process_filter+0xb58>
    45a0:      	ldr	x8, [sp, #0xc0]
    45a4:      	str	x8, [sp, #0x70]
    45a8:      	subs	w19, w19, #0x1
    45ac:      	b.ne	0x4494 <generic_fentry_process_filter+0x854>
    45b0:      	b	0x4798 <generic_fentry_process_filter+0xb58>
    45b4:      	add	x2, x21, #0x18
    45b8:      	mov	w8, #0x8                // =8
    45bc:      	mov	w9, #0x4                // =4
    45c0:      	add	x10, sp, #0x58
    45c4:      	add	x0, sp, #0x58
    45c8:      	mov	w1, #0x8                // =8
    45cc:      	blr	x9
    45d0:      	ldr	x8, [sp, #0x58]
    45d4:      	cmp	x8, x21
    45d8:      	b.eq	0x4384 <generic_fentry_process_filter+0x744>
    45dc:      	ldr	x29, [sp, #0x40]
    45e0:      	ldr	w9, [x29, #0x550]
    45e4:      	sub	w8, w9, #0xa
    45e8:      	cmp	w9, #0x9
    45ec:      	str	w8, [x29, #0x550]
    45f0:      	b.gt	0x4cc0 <generic_fentry_process_filter+0x1080>
    45f4:      	ldr	x21, [sp, #0x30]
    45f8:      	mov	w9, #-0x24              // =-36
    45fc:      	mov	x24, x20
    4600:      	str	w9, [x29, #0x554]
    4604:      	b	0x47fc <generic_fentry_process_filter+0xbbc>
    4608:      	mov	w19, #0x80              // =128
    460c:      	mov	w21, #0x8               // =8
    4610:      	add	x23, sp, #0xb8
    4614:      	add	x29, sp, #0xd8
    4618:      	b	0x4670 <generic_fentry_process_filter+0xa30>
    461c:      	nop
    4620:      	add	x2, x22, #0x10
    4624:      	mov	w8, #0x4                // =4
    4628:      	add	x0, sp, #0xd8
    462c:      	mov	w1, #0x8                // =8
    4630:      	blr	x8
    4634:      	add	x20, sp, #0xd8
    4638:      	ldr	x8, [sp, #0x80]
    463c:      	ldr	x9, [x20]
    4640:      	cmp	x8, x9
    4644:      	b.eq	0x4790 <generic_fentry_process_filter+0xb50>
    4648:      	add	x2, x22, #0x18
    464c:      	mov	w8, #0x4                // =4
    4650:      	mov	x0, x24
    4654:      	mov	w1, #0x8                // =8
    4658:      	blr	x8
    465c:      	ldr	x8, [x20]
    4660:      	add	x9, x8, #0x20
    4664:      	stp	x9, x8, [sp, #0x78]
    4668:      	subs	w19, w19, #0x1
    466c:      	b.eq	0x4798 <generic_fentry_process_filter+0xb58>
    4670:      	ldp	x20, x2, [sp, #0x70]
    4674:      	ldp	x8, x9, [sp, #0x58]
    4678:      	cmp	x20, x8
    467c:      	ccmp	x2, x9, #0x0, eq
    4680:      	b.eq	0x4790 <generic_fentry_process_filter+0xb50>
    4684:      	ldr	x22, [sp, #0x80]
    4688:      	mov	w8, #0x4                // =4
    468c:      	add	x0, sp, #0xb8
    4690:      	mov	w1, #0x8                // =8
    4694:      	blr	x8
    4698:      	ldr	x8, [sp, #0xb8]
    469c:      	cmp	x20, x8
    46a0:      	b.eq	0x4620 <generic_fentry_process_filter+0x9e0>
    46a4:      	add	x25, x20, #0x18
    46a8:      	mov	w8, #0x4                // =4
    46ac:      	add	x0, sp, #0xd8
    46b0:      	mov	w1, #0x8                // =8
    46b4:      	mov	x2, x25
    46b8:      	blr	x8
    46bc:      	add	x8, sp, #0xd8
    46c0:      	ldr	x8, [x8]
    46c4:      	cmp	x8, x20
    46c8:      	b.eq	0x4620 <generic_fentry_process_filter+0x9e0>
    46cc:      	mov	w8, #0x4                // =4
    46d0:      	add	x9, sp, #0xc0
    46d4:      	add	x0, sp, #0xc0
    46d8:      	mov	w1, #0x8                // =8
    46dc:      	mov	x2, x25
    46e0:      	blr	x8
    46e4:      	add	x2, x20, #0x20
    46e8:      	mov	w8, #0x4                // =4
    46ec:      	mov	w9, #0x10               // =16
    46f0:      	add	x10, sp, #0xc8
    46f4:      	add	x0, sp, #0xc8
    46f8:      	mov	w1, #0x10               // =16
    46fc:      	blr	x8
    4700:      	ldr	w20, [sp, #0xcc]
    4704:      	ldr	x8, [sp, #0x68]
    4708:      	ldr	x10, [sp, #0x88]
    470c:      	sub	x12, x10, x8
    4710:      	ldr	w22, [sp, #0x90]
    4714:      	subs	w10, w20, w22
    4718:      	ldr	x9, [sp, #0xd0]
    471c:      	csel	w10, wzr, w10, lo
    4720:      	cmp	w22, w20
    4724:      	csel	w11, w22, w20, lo
    4728:      	cinc	w13, w11, hi
    472c:      	sub	w14, w22, w13
    4730:      	subs	x12, x12, x13
    4734:      	str	w14, [sp, #0x90]
    4738:      	b.lo	0x4798 <generic_fentry_process_filter+0xb58>
    473c:      	cmp	x12, #0xfff
    4740:      	b.hi	0x4798 <generic_fentry_process_filter+0xb58>
    4744:      	cmp	w22, w20
    4748:      	b.ls	0x4754 <generic_fentry_process_filter+0xb14>
    474c:      	mov	w13, #0x2f              // =47
    4750:      	strb	w13, [x8, x12]
    4754:      	add	x25, x8, x12
    4758:      	cmp	w22, w20
    475c:      	add	x2, x9, x10
    4760:      	and	w1, w11, #0xff
    4764:      	mov	w8, #0x4                // =4
    4768:      	cinc	x0, x25, hi
    476c:      	blr	x8
    4770:      	cmp	w22, w20
    4774:      	str	x25, [sp, #0x88]
    4778:      	b.ls	0x4798 <generic_fentry_process_filter+0xb58>
    477c:      	ldr	x8, [sp, #0xc0]
    4780:      	str	x8, [sp, #0x70]
    4784:      	subs	w19, w19, #0x1
    4788:      	b.ne	0x4670 <generic_fentry_process_filter+0xa30>
    478c:      	b	0x4798 <generic_fentry_process_filter+0xb58>
    4790:      	mov	w8, #0x1                // =1
    4794:      	strb	w8, [sp, #0x94]
    4798:      	ldr	x24, [sp, #0x88]
    479c:      	ldr	x9, [sp, #0x28]
    47a0:      	cmp	x24, x9
    47a4:      	b.eq	0x47e8 <generic_fentry_process_filter+0xba8>
    47a8:      	ldrb	w8, [sp, #0x94]
    47ac:      	ldr	x29, [sp, #0x40]
    47b0:      	cmp	w8, #0x0
    47b4:      	ldr	x21, [sp, #0x30]
    47b8:      	cset	w8, eq
    47bc:      	lsl	w9, w8, #1
    47c0:      	ldr	w8, [sp, #0x90]
    47c4:      	cmp	w8, #0x1
    47c8:      	str	w8, [x29, #0x550]
    47cc:      	str	w9, [x29, #0x554]
    47d0:      	b.lt	0x47e0 <generic_fentry_process_filter+0xba0>
    47d4:      	mov	w9, #0x1000             // =4096
    47d8:      	sub	w8, w9, w8
    47dc:      	str	w8, [x29, #0x550]
    47e0:      	cbnz	x24, 0x47fc <generic_fentry_process_filter+0xbbc>
    47e4:      	b	0x4914 <generic_fentry_process_filter+0xcd4>
    47e8:      	ldr	x29, [sp, #0x40]
    47ec:      	ldr	x21, [sp, #0x30]
    47f0:      	mov	w8, wzr
    47f4:      	mov	x24, x9
    47f8:      	str	xzr, [x29, #0x550]
    47fc:      	subs	w9, w8, #0x7f
    4800:      	mov	w10, #0x7f              // =127
    4804:      	mov	x11, x29
    4808:      	mov	x0, x21
    480c:      	mov	x2, x24
    4810:      	csel	w29, w8, w10, lo
    4814:      	csel	w19, wzr, w9, lo
    4818:      	cmp	w8, #0xff
    481c:      	mov	w9, #0xff               // =255
    4820:      	csel	w8, w8, w9, lo
    4824:      	and	w1, w8, #0xff
    4828:      	str	w1, [x11, #0x550]
    482c:      	mov	w8, #0x4                // =4
    4830:      	blr	x8
    4834:      	adrp	x25, 0x4000 <generic_fentry_process_filter+0x3c0>
    4838:      	ldr	x25, [x25]
    483c:      	cbz	x0, 0x48ac <generic_fentry_process_filter+0xc6c>
    4840:      	neg	w8, w0
    4844:      	mov	w9, #0x1                // =1
    4848:      	add	x1, sp, #0x58
    484c:      	strh	w8, [sp, #0x58]
    4850:      	mov	w8, #0x8                // =8
    4854:      	mov	x0, x25
    4858:      	mov	w20, #0x1               // =1
    485c:      	strh	w8, [sp, #0x5a]
    4860:      	mov	x8, #0x2de              // =734
    4864:      	movk	x8, #0x4, lsl #32
    4868:      	stur	x8, [sp, #0x5c]
    486c:      	add	x8, sp, #0x58
    4870:      	blr	x9
    4874:      	cbz	x0, 0x4888 <generic_fentry_process_filter+0xc48>
    4878:      	ldr	w8, [x0]
    487c:      	add	w8, w8, #0x1
    4880:      	str	w8, [x0]
    4884:      	b	0x48ac <generic_fentry_process_filter+0xc6c>
    4888:      	str	w20, [sp, #0xc8]
    488c:      	mov	x3, xzr
    4890:      	mov	w8, #0x2                // =2
    4894:      	add	x9, sp, #0x58
    4898:      	add	x10, sp, #0xc8
    489c:      	add	x1, sp, #0x58
    48a0:      	add	x2, sp, #0xc8
    48a4:      	mov	x0, x25
    48a8:      	blr	x8
    48ac:      	ldr	x9, [sp, #0xe8]
    48b0:      	mov	w8, #0x6390             // =25488
    48b4:      	add	x2, x24, x19
    48b8:      	mov	w1, w29
    48bc:      	add	x0, x9, x8
    48c0:      	mov	w8, #0x4                // =4
    48c4:      	blr	x8
    48c8:      	ldr	x29, [sp, #0x40]
    48cc:      	cbz	x0, 0x4914 <generic_fentry_process_filter+0xcd4>
    48d0:      	neg	w8, w0
    48d4:      	mov	w9, #0x1                // =1
    48d8:      	add	x1, sp, #0x58
    48dc:      	strh	w8, [sp, #0x58]
    48e0:      	mov	w8, #0x8                // =8
    48e4:      	mov	x0, x25
    48e8:      	mov	w19, #0x1               // =1
    48ec:      	strh	w8, [sp, #0x5a]
    48f0:      	mov	x8, #0x2e0              // =736
    48f4:      	movk	x8, #0x4, lsl #32
    48f8:      	stur	x8, [sp, #0x5c]
    48fc:      	add	x8, sp, #0x58
    4900:      	blr	x9
    4904:      	cbz	x0, 0x493c <generic_fentry_process_filter+0xcfc>
    4908:      	ldr	w8, [x0]
    490c:      	add	w8, w8, #0x1
    4910:      	str	w8, [x0]
    4914:      	ldr	w8, [x29, #0x550]
    4918:      	sub	w9, w8, #0x101
    491c:      	cmn	w9, #0x101
    4920:      	b.hi	0x4970 <generic_fentry_process_filter+0xd30>
    4924:      	ldr	x20, [sp, #0x38]
    4928:      	ldr	x22, [sp, #0xe8]
    492c:      	mov	w8, #-0x1               // =-1
    4930:      	ldr	x24, [sp, #0x48]
    4934:      	stur	w8, [x29, #0xb8]
    4938:      	b	0x4ac0 <generic_fentry_process_filter+0xe80>
    493c:      	str	w19, [sp, #0xc8]
    4940:      	mov	x3, xzr
    4944:      	mov	w8, #0x2                // =2
    4948:      	add	x9, sp, #0x58
    494c:      	add	x10, sp, #0xc8
    4950:      	add	x1, sp, #0x58
    4954:      	add	x2, sp, #0xc8
    4958:      	mov	x0, x25
    495c:      	blr	x8
    4960:      	ldr	w8, [x29, #0x550]
    4964:      	sub	w9, w8, #0x101
    4968:      	cmn	w9, #0x101
    496c:      	b.ls	0x4924 <generic_fentry_process_filter+0xce4>
    4970:      	ldr	x22, [sp, #0xe8]
    4974:      	and	x24, x8, #0xff
    4978:      	mov	w8, #0x5f80             // =24448
    497c:      	mov	x2, x21
    4980:      	mov	w1, w24
    4984:      	add	x0, x22, x8
    4988:      	mov	w8, #0x4                // =4
    498c:      	blr	x8
    4990:      	mov	x23, x0
    4994:      	cbz	x0, 0x4a10 <generic_fentry_process_filter+0xdd0>
    4998:      	neg	w8, w23
    499c:      	adrp	x25, 0x4000 <generic_fentry_process_filter+0x3c0>
    49a0:      	mov	w9, #0x1                // =1
    49a4:      	strh	w8, [sp, #0x58]
    49a8:      	mov	w8, #0xf                // =15
    49ac:      	add	x1, sp, #0x58
    49b0:      	mov	w19, #0x1               // =1
    49b4:      	strh	w8, [sp, #0x5a]
    49b8:      	mov	x8, #0x164              // =356
    49bc:      	movk	x8, #0x4, lsl #32
    49c0:      	stur	x8, [sp, #0x5c]
    49c4:      	add	x8, sp, #0x58
    49c8:      	ldr	x25, [x25]
    49cc:      	mov	x0, x25
    49d0:      	blr	x9
    49d4:      	cbz	x0, 0x49e8 <generic_fentry_process_filter+0xda8>
    49d8:      	ldr	w8, [x0]
    49dc:      	add	w8, w8, #0x1
    49e0:      	str	w8, [x0]
    49e4:      	b	0x4a0c <generic_fentry_process_filter+0xdcc>
    49e8:      	str	w19, [sp, #0xc8]
    49ec:      	mov	x3, xzr
    49f0:      	mov	w8, #0x2                // =2
    49f4:      	add	x9, sp, #0x58
    49f8:      	add	x10, sp, #0xc8
    49fc:      	add	x1, sp, #0x58
    4a00:      	add	x2, sp, #0xc8
    4a04:      	mov	x0, x25
    4a08:      	blr	x8
    4a0c:      	ldr	x22, [sp, #0xe8]
    4a10:      	cmp	w23, #0x0
    4a14:      	csel	w8, w24, w23, eq
    4a18:      	cmp	w24, #0x7f
    4a1c:      	stur	w8, [x29, #0xb8]
    4a20:      	mov	w8, #0x7f               // =127
    4a24:      	csel	w1, w24, w8, lo
    4a28:      	mov	w8, #0x6080             // =24704
    4a2c:      	add	x0, x22, x8
    4a30:      	mov	w8, #0x6390             // =25488
    4a34:      	add	x2, x22, x8
    4a38:      	mov	w8, #0x4                // =4
    4a3c:      	blr	x8
    4a40:      	ldr	x20, [sp, #0x38]
    4a44:      	ldr	x24, [sp, #0x48]
    4a48:      	cbz	x0, 0x4ac0 <generic_fentry_process_filter+0xe80>
    4a4c:      	neg	w8, w0
    4a50:      	adrp	x23, 0x4000 <generic_fentry_process_filter+0x3c0>
    4a54:      	mov	w9, #0x1                // =1
    4a58:      	strh	w8, [sp, #0x58]
    4a5c:      	mov	w8, #0xf                // =15
    4a60:      	add	x1, sp, #0x58
    4a64:      	mov	w19, #0x1               // =1
    4a68:      	strh	w8, [sp, #0x5a]
    4a6c:      	mov	x8, #0x16a              // =362
    4a70:      	movk	x8, #0x4, lsl #32
    4a74:      	stur	x8, [sp, #0x5c]
    4a78:      	add	x8, sp, #0x58
    4a7c:      	ldr	x23, [x23]
    4a80:      	mov	x0, x23
    4a84:      	blr	x9
    4a88:      	cbz	x0, 0x4a9c <generic_fentry_process_filter+0xe5c>
    4a8c:      	ldr	w8, [x0]
    4a90:      	add	w8, w8, #0x1
    4a94:      	str	w8, [x0]
    4a98:      	b	0x4ac0 <generic_fentry_process_filter+0xe80>
    4a9c:      	str	w19, [sp, #0xc8]
    4aa0:      	mov	x3, xzr
    4aa4:      	mov	w8, #0x2                // =2
    4aa8:      	add	x9, sp, #0x58
    4aac:      	add	x10, sp, #0xc8
    4ab0:      	add	x1, sp, #0x58
    4ab4:      	add	x2, sp, #0xc8
    4ab8:      	mov	x0, x23
    4abc:      	blr	x8
    4ac0:      	ldrb	w8, [x22, #0x1]
    4ac4:      	orr	w8, w8, #0x10
    4ac8:      	strb	w8, [x22, #0x1]
    4acc:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x3c0>
    4ad0:      	mov	w8, #0x5ef8             // =24312
    4ad4:      	ldr	x0, [x0]
    4ad8:      	add	x1, x22, x8
    4adc:      	mov	w8, #0x1                // =1
    4ae0:      	blr	x8
    4ae4:      	cbz	x0, 0x5f6c <generic_fentry_process_filter+0x232c>
    4ae8:      	ldr	x21, [x22, #0x5eb8]
    4aec:      	cmp	x21, #0x6
    4af0:      	b.hs	0x4c88 <generic_fentry_process_filter+0x1048>
    4af4:      	ldrsw	x8, [x0]
    4af8:      	mov	x23, x0
    4afc:      	cbz	w8, 0x4ca4 <generic_fentry_process_filter+0x1064>
    4b00:      	cmp	x21, x8
    4b04:      	b.hs	0x4c88 <generic_fentry_process_filter+0x1048>
    4b08:      	str	x8, [sp, #0x28]
    4b0c:      	stp	x29, x24, [sp, #0x40]
    4b10:      	adrp	x24, 0x4000 <generic_fentry_process_filter+0x3c0>
    4b14:      	mov	w8, #0x1                // =1
    4b18:      	add	x9, sp, #0xd8
    4b1c:      	str	x22, [sp, #0xe8]
    4b20:      	add	x1, sp, #0xd8
    4b24:      	str	x20, [sp, #0x38]
    4b28:      	str	w21, [sp, #0xd8]
    4b2c:      	str	wzr, [sp, #0xc0]
    4b30:      	ldr	x24, [x24]
    4b34:      	mov	x0, x24
    4b38:      	blr	x8
    4b3c:      	cbz	x0, 0x4f54 <generic_fentry_process_filter+0x1314>
    4b40:      	ldr	w8, [x0]
    4b44:      	mov	x25, x0
    4b48:      	cbz	w8, 0x4f54 <generic_fentry_process_filter+0x1314>
    4b4c:      	ldr	x9, [sp, #0x48]
    4b50:      	ldr	w9, [x9, #0x68]
    4b54:      	tbnz	w9, #0x1f, 0x5f14 <generic_fentry_process_filter+0x22d4>
    4b58:      	cmp	w8, #0x1b
    4b5c:      	b.hi	0x5f14 <generic_fentry_process_filter+0x22d4>
    4b60:      	mov	w9, #0x1                // =1
    4b64:      	lsl	w9, w9, w8
    4b68:      	tst	w9, #0x60
    4b6c:      	b.ne	0x4d64 <generic_fentry_process_filter+0x1124>
    4b70:      	mov	w10, #0x100             // =256
    4b74:      	movk	w10, #0x400, lsl #16
    4b78:      	tst	w9, w10
    4b7c:      	b.ne	0x4ce0 <generic_fentry_process_filter+0x10a0>
    4b80:      	mov	w9, #0x1                // =1
    4b84:      	lsl	w8, w9, w8
    4b88:      	mov	w9, #0x200              // =512
    4b8c:      	movk	w9, #0x800, lsl #16
    4b90:      	tst	w8, w9
    4b94:      	b.eq	0x5f14 <generic_fentry_process_filter+0x22d4>
    4b98:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x3c0>
    4b9c:      	add	x1, x25, #0x4
    4ba0:      	mov	w8, #0x1                // =1
    4ba4:      	ldr	x0, [x0]
    4ba8:      	blr	x8
    4bac:      	cbz	x0, 0x5f14 <generic_fentry_process_filter+0x22d4>
    4bb0:      	ldr	x8, [sp, #0x48]
    4bb4:      	mov	x20, x0
    4bb8:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x3c0>
    4bbc:      	mov	w9, #0x7f               // =127
    4bc0:      	ldr	w8, [x8, #0x68]
    4bc4:      	ldr	x0, [x0]
    4bc8:      	add	x1, sp, #0xc0
    4bcc:      	cmp	w8, #0x7f
    4bd0:      	csel	w19, w8, w9, lt
    4bd4:      	mov	w8, #0x1                // =1
    4bd8:      	add	x9, sp, #0xc0
    4bdc:      	blr	x8
    4be0:      	cbz	x0, 0x5f14 <generic_fentry_process_filter+0x22d4>
    4be4:      	sxtw	x1, w19
    4be8:      	mov	x29, x0
    4bec:      	lsl	w8, w1, #3
    4bf0:      	str	w8, [x0]
    4bf4:      	ldr	x8, [sp, #0x48]
    4bf8:      	ldr	w8, [x8, #0x6c]
    4bfc:      	cbnz	w8, 0x4c5c <generic_fentry_process_filter+0x101c>
    4c00:      	ldr	x11, [sp, #0x48]
    4c04:      	and	w13, w1, #0x7f
    4c08:      	mov	x8, xzr
    4c0c:      	ldr	w12, [x11, #0x68]
    4c10:      	add	x9, x11, #0x1f0
    4c14:      	add	x10, x11, #0x170
    4c18:      	sub	w11, w12, w1
    4c1c:      	add	w12, w12, w13
    4c20:      	add	w11, w11, w13
    4c24:      	mvn	w13, w1
    4c28:      	add	w12, w13, w12
    4c2c:      	cmp	x8, #0x7f
    4c30:      	b.eq	0x4c50 <generic_fentry_process_filter+0x1010>
    4c34:      	and	x13, x12, #0x7f
    4c38:      	sub	w12, w12, #0x1
    4c3c:      	ldrb	w13, [x10, x13]
    4c40:      	strb	w13, [x9, x8]
    4c44:      	add	x8, x8, #0x1
    4c48:      	cmp	x11, x8
    4c4c:      	b.ne	0x4c2c <generic_fentry_process_filter+0xfec>
    4c50:      	ldr	x9, [sp, #0x48]
    4c54:      	mov	w8, #0x1                // =1
    4c58:      	str	w8, [x9, #0x6c]
    4c5c:      	cmp	w1, #0x7f
    4c60:      	b.hi	0x4c7c <generic_fentry_process_filter+0x103c>
    4c64:      	ldr	x8, [sp, #0x48]
    4c68:      	add	x0, x29, #0x4
    4c6c:      	add	x2, x8, #0x1f0
    4c70:      	mov	w8, #0x4                // =4
    4c74:      	blr	x8
    4c78:      	tbnz	x0, #0x3f, 0x5f14 <generic_fentry_process_filter+0x22d4>
    4c7c:      	mov	w8, #0x1                // =1
    4c80:      	mov	x0, x20
    4c84:      	b	0x4d5c <generic_fentry_process_filter+0x111c>
    4c88:      	ldr	w8, [x24]
    4c8c:      	str	w8, [x22, #0x10]
    4c90:      	ldr	x8, [x24, #0x8]
    4c94:      	str	x8, [x22, #0x18]
    4c98:      	ldrb	w8, [x29]
    4c9c:      	cbnz	w8, 0x5f50 <generic_fentry_process_filter+0x2310>
    4ca0:      	b	0x5f6c <generic_fentry_process_filter+0x232c>
    4ca4:      	mov	w8, #0x1                // =1
    4ca8:      	strb	w8, [x29]
    4cac:      	ldr	w8, [x24]
    4cb0:      	str	w8, [x22, #0x10]
    4cb4:      	ldr	x8, [x24, #0x8]
    4cb8:      	str	x8, [x22, #0x18]
    4cbc:      	b	0x5f50 <generic_fentry_process_filter+0x2310>
    4cc0:      	mov	w8, #0x2964             // =10596
    4cc4:      	add	x20, x24, #0xff6
    4cc8:      	strh	w8, [x24, #0xffe]
    4ccc:      	adrp	x8, 0x4000 <generic_fentry_process_filter+0x3c0>
    4cd0:      	add	x8, x8, #0x0
    4cd4:      	ldr	x8, [x8]
    4cd8:      	str	x8, [x20]
    4cdc:      	b	0x4384 <generic_fentry_process_filter+0x744>
    4ce0:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x3c0>
    4ce4:      	add	x1, x25, #0x4
    4ce8:      	mov	w8, #0x1                // =1
    4cec:      	ldr	x0, [x0]
    4cf0:      	blr	x8
    4cf4:      	cbz	x0, 0x5f14 <generic_fentry_process_filter+0x22d4>
    4cf8:      	mov	x19, x0
    4cfc:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x3c0>
    4d00:      	mov	w8, #0x1                // =1
    4d04:      	ldr	x0, [x0]
    4d08:      	add	x9, sp, #0xc0
    4d0c:      	add	x1, sp, #0xc0
    4d10:      	blr	x8
    4d14:      	cbz	x0, 0x5f14 <generic_fentry_process_filter+0x22d4>
    4d18:      	mov	w1, wzr
    4d1c:      	mov	w2, #0x104              // =260
    4d20:      	mov	x29, x0
    4d24:      	bl	0x4d24 <generic_fentry_process_filter+0x10e4>
    4d28:      	ldr	x10, [sp, #0x48]
    4d2c:      	mov	x0, x29
    4d30:      	ldr	w8, [x10, #0x68]
    4d34:      	add	x2, x10, #0x70
    4d38:      	lsl	w9, w8, #3
    4d3c:      	and	x8, x8, #0xff
    4d40:      	str	w9, [x0], #0x4
    4d44:      	mov	w9, #0x4                // =4
    4d48:      	ldrb	w1, [x10, #0x68]
    4d4c:      	blr	x9
    4d50:      	tbnz	x0, #0x3f, 0x5f14 <generic_fentry_process_filter+0x22d4>
    4d54:      	mov	w8, #0x1                // =1
    4d58:      	mov	x0, x19
    4d5c:      	mov	x1, x29
    4d60:      	b	0x4f1c <generic_fentry_process_filter+0x12dc>
    4d64:      	str	wzr, [sp, #0xc8]
    4d68:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x3c0>
    4d6c:      	mov	w8, #0x1                // =1
    4d70:      	add	x9, sp, #0xc8
    4d74:      	ldr	x0, [x0]
    4d78:      	add	x1, sp, #0xc8
    4d7c:      	blr	x8
    4d80:      	cbz	x0, 0x4ec8 <generic_fentry_process_filter+0x1288>
    4d84:      	ldr	x9, [sp, #0x48]
    4d88:      	ldr	x8, [x0]
    4d8c:      	ldr	x9, [x9, #0x378]
    4d90:      	cmp	x8, x9
    4d94:      	b.eq	0x4ec8 <generic_fentry_process_filter+0x1288>
    4d98:      	str	x0, [sp, #0x30]
    4d9c:      	adrp	x8, 0x4000 <generic_fentry_process_filter+0x3c0>
    4da0:      	ldr	x8, [x8]
    4da4:      	ldrb	w8, [x8]
    4da8:      	cbz	w8, 0x4e34 <generic_fentry_process_filter+0x11f4>
    4dac:      	adrp	x19, 0x4000 <generic_fentry_process_filter+0x3c0>
    4db0:      	mov	w20, #0x869f            // =34463
    4db4:      	mov	x22, xzr
    4db8:      	ldr	x19, [x19]
    4dbc:      	movk	w20, #0x1, lsl #16
    4dc0:      	b	0x4dd8 <generic_fentry_process_filter+0x1198>
    4dc4:      	cmp	x29, x22
    4dc8:      	mov	x22, x29
    4dcc:      	ccmp	w20, #0x0, #0x4, ne
    4dd0:      	sub	w20, w20, #0x1
    4dd4:      	b.eq	0x4eb8 <generic_fentry_process_filter+0x1278>
    4dd8:      	ldr	x8, [sp, #0x48]
    4ddc:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x3c0>
    4de0:      	add	x9, sp, #0x58
    4de4:      	add	x1, sp, #0x58
    4de8:      	ldr	w8, [x8, #0x10]
    4dec:      	str	w8, [sp, #0x58]
    4df0:      	mov	w8, #0x1                // =1
    4df4:      	ldr	x0, [x0]
    4df8:      	blr	x8
    4dfc:      	cbz	x0, 0x4eb8 <generic_fentry_process_filter+0x1278>
    4e00:      	add	x1, x0, #0x70
    4e04:      	mov	w8, #0x1                // =1
    4e08:      	mov	x29, x0
    4e0c:      	mov	x0, x19
    4e10:      	blr	x8
    4e14:      	cbz	x0, 0x4dc4 <generic_fentry_process_filter+0x1184>
    4e18:      	ldr	x8, [x0]
    4e1c:      	cbz	x8, 0x4dc4 <generic_fentry_process_filter+0x1184>
    4e20:      	ldr	x10, [sp, #0x48]
    4e24:      	ldr	x9, [x10, #0x370]
    4e28:      	orr	x8, x9, x8
    4e2c:      	str	x8, [x10, #0x370]
    4e30:      	b	0x4dc4 <generic_fentry_process_filter+0x1184>
    4e34:      	adrp	x19, 0x4000 <generic_fentry_process_filter+0x3c0>
    4e38:      	mov	x22, xzr
    4e3c:      	mov	w20, #0x3ff             // =1023
    4e40:      	ldr	x19, [x19]
    4e44:      	b	0x4e5c <generic_fentry_process_filter+0x121c>
    4e48:      	cmp	x29, x22
    4e4c:      	mov	x22, x29
    4e50:      	ccmp	w20, #0x0, #0x4, ne
    4e54:      	sub	w20, w20, #0x1
    4e58:      	b.eq	0x4eb8 <generic_fentry_process_filter+0x1278>
    4e5c:      	ldr	x8, [sp, #0x48]
    4e60:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x3c0>
    4e64:      	add	x9, sp, #0x58
    4e68:      	add	x1, sp, #0x58
    4e6c:      	ldr	w8, [x8, #0x10]
    4e70:      	str	w8, [sp, #0x58]
    4e74:      	mov	w8, #0x1                // =1
    4e78:      	ldr	x0, [x0]
    4e7c:      	blr	x8
    4e80:      	cbz	x0, 0x4eb8 <generic_fentry_process_filter+0x1278>
    4e84:      	add	x1, x0, #0x70
    4e88:      	mov	w8, #0x1                // =1
    4e8c:      	mov	x29, x0
    4e90:      	mov	x0, x19
    4e94:      	blr	x8
    4e98:      	cbz	x0, 0x4e48 <generic_fentry_process_filter+0x1208>
    4e9c:      	ldr	x8, [x0]
    4ea0:      	cbz	x8, 0x4e48 <generic_fentry_process_filter+0x1208>
    4ea4:      	ldr	x10, [sp, #0x48]
    4ea8:      	ldr	x9, [x10, #0x370]
    4eac:      	orr	x8, x9, x8
    4eb0:      	str	x8, [x10, #0x370]
    4eb4:      	b	0x4e48 <generic_fentry_process_filter+0x1208>
    4eb8:      	ldr	x8, [sp, #0x30]
    4ebc:      	ldr	x9, [sp, #0x48]
    4ec0:      	ldr	x8, [x8]
    4ec4:      	str	x8, [x9, #0x378]
    4ec8:      	ldr	w8, [x25, #0x8]
    4ecc:      	cmn	w8, #0x1
    4ed0:      	b.eq	0x4ef4 <generic_fentry_process_filter+0x12b4>
    4ed4:      	ldr	x9, [sp, #0x48]
    4ed8:      	ldr	x9, [x9, #0x370]
    4edc:      	lsr	x8, x9, x8
    4ee0:      	tbz	w8, #0x0, 0x4ef4 <generic_fentry_process_filter+0x12b4>
    4ee4:      	mov	x0, #0xffee             // =65518
    4ee8:      	movk	x0, #0xadc0, lsl #16
    4eec:      	movk	x0, #0xb, lsl #32
    4ef0:      	b	0x4f20 <generic_fentry_process_filter+0x12e0>
    4ef4:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x3c0>
    4ef8:      	mov	w8, #0x1                // =1
    4efc:      	add	x9, sp, #0xd8
    4f00:      	ldr	x0, [x0]
    4f04:      	add	x1, sp, #0xd8
    4f08:      	blr	x8
    4f0c:      	cbz	x0, 0x5f14 <generic_fentry_process_filter+0x22d4>
    4f10:      	ldr	x8, [sp, #0x48]
    4f14:      	add	x1, x8, #0x70
    4f18:      	mov	w8, #0x1                // =1
    4f1c:      	blr	x8
    4f20:      	ldr	w8, [x25]
    4f24:      	cmp	w8, #0x25
    4f28:      	b.hi	0x4f50 <generic_fentry_process_filter+0x1310>
    4f2c:      	mov	w9, #0x1                // =1
    4f30:      	lsl	x8, x9, x8
    4f34:      	mov	x9, #0x50               // =80
    4f38:      	movk	x9, #0xc00, lsl #16
    4f3c:      	movk	x9, #0x20, lsl #32
    4f40:      	tst	x8, x9
    4f44:      	b.eq	0x4f50 <generic_fentry_process_filter+0x1310>
    4f48:      	cbnz	x0, 0x5f14 <generic_fentry_process_filter+0x22d4>
    4f4c:      	b	0x4f54 <generic_fentry_process_filter+0x1314>
    4f50:      	cbz	x0, 0x5f14 <generic_fentry_process_filter+0x22d4>
    4f54:      	adrp	x8, 0x4000 <generic_fentry_process_filter+0x3c0>
    4f58:      	ldr	x8, [x8]
    4f5c:      	ldrb	w8, [x8]
    4f60:      	cbz	w8, 0x532c <generic_fentry_process_filter+0x16ec>
    4f64:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x3c0>
    4f68:      	mov	w8, #0x1                // =1
    4f6c:      	ldr	x0, [x0]
    4f70:      	ldr	x1, [sp, #0x48]
    4f74:      	blr	x8
    4f78:      	cbz	x0, 0x532c <generic_fentry_process_filter+0x16ec>
    4f7c:      	add	w8, w21, #0x5
    4f80:      	str	wzr, [sp, #0xc0]
    4f84:      	add	x9, sp, #0xd8
    4f88:      	mov	x25, x0
    4f8c:      	str	w8, [sp, #0xd8]
    4f90:      	mov	w8, #0x1                // =1
    4f94:      	add	x1, sp, #0xd8
    4f98:      	mov	x0, x24
    4f9c:      	blr	x8
    4fa0:      	cbz	x0, 0x532c <generic_fentry_process_filter+0x16ec>
    4fa4:      	ldr	w8, [x0]
    4fa8:      	mov	x24, x0
    4fac:      	cbz	w8, 0x532c <generic_fentry_process_filter+0x16ec>
    4fb0:      	ldr	w9, [x25]
    4fb4:      	tbnz	w9, #0x1f, 0x5f14 <generic_fentry_process_filter+0x22d4>
    4fb8:      	cmp	w8, #0x1b
    4fbc:      	b.hi	0x5f14 <generic_fentry_process_filter+0x22d4>
    4fc0:      	mov	w9, #0x1                // =1
    4fc4:      	lsl	w9, w9, w8
    4fc8:      	tst	w9, #0x60
    4fcc:      	b.ne	0x5154 <generic_fentry_process_filter+0x1514>
    4fd0:      	mov	w10, #0x100             // =256
    4fd4:      	movk	w10, #0x400, lsl #16
    4fd8:      	tst	w9, w10
    4fdc:      	b.ne	0x50d4 <generic_fentry_process_filter+0x1494>
    4fe0:      	mov	w9, #0x1                // =1
    4fe4:      	lsl	w8, w9, w8
    4fe8:      	mov	w9, #0x200              // =512
    4fec:      	movk	w9, #0x800, lsl #16
    4ff0:      	tst	w8, w9
    4ff4:      	b.eq	0x5f14 <generic_fentry_process_filter+0x22d4>
    4ff8:      	adrp	x0, 0x4000 <generic_fentry_process_filter+0x3c0>
    4ffc:      	add	x1, x24, #0x4
    5000:      	mov	w8, #0x1                // =1
    5004:      	ldr	x0, [x0]
    5008:      	blr	x8
    500c:      	cbz	x0, 0x5f14 <generic_fentry_process_filter+0x22d4>
    5010:      	ldr	w8, [x25]
    5014:      	mov	x20, x0
    5018:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    501c:      	mov	w9, #0x7f               // =127
    5020:      	ldr	x0, [x0]
    5024:      	add	x1, sp, #0xc0
    5028:      	cmp	w8, #0x7f
    502c:      	csel	w19, w8, w9, lt
    5030:      	mov	w8, #0x1                // =1
    5034:      	add	x9, sp, #0xc0
    5038:      	blr	x8
    503c:      	cbz	x0, 0x5f14 <generic_fentry_process_filter+0x22d4>
    5040:      	sxtw	x1, w19
    5044:      	mov	x29, x0
    5048:      	lsl	w8, w1, #3
    504c:      	str	w8, [x0]
    5050:      	ldr	w8, [x25, #0x4]
    5054:      	cbnz	w8, 0x50ac <generic_fentry_process_filter+0x146c>
    5058:      	ldr	w12, [x25]
    505c:      	and	w13, w1, #0x7f
    5060:      	mov	x8, xzr
    5064:      	add	x9, x25, #0x188
    5068:      	add	x10, x25, #0x108
    506c:      	sub	w11, w12, w1
    5070:      	add	w12, w12, w13
    5074:      	add	w11, w11, w13
    5078:      	mvn	w13, w1
    507c:      	add	w12, w13, w12
    5080:      	cmp	x8, #0x7f
    5084:      	b.eq	0x50a4 <generic_fentry_process_filter+0x1464>
    5088:      	and	x13, x12, #0x7f
    508c:      	sub	w12, w12, #0x1
    5090:      	ldrb	w13, [x10, x13]
    5094:      	strb	w13, [x9, x8]
    5098:      	add	x8, x8, #0x1
    509c:      	cmp	x11, x8
    50a0:      	b.ne	0x5080 <generic_fentry_process_filter+0x1440>
    50a4:      	mov	w8, #0x1                // =1
    50a8:      	str	w8, [x25, #0x4]
    50ac:      	cmp	w1, #0x7f
    50b0:      	b.hi	0x50c8 <generic_fentry_process_filter+0x1488>
    50b4:      	add	x0, x29, #0x4
    50b8:      	add	x2, x25, #0x188
    50bc:      	mov	w8, #0x4                // =4
    50c0:      	blr	x8
    50c4:      	tbnz	x0, #0x3f, 0x5f14 <generic_fentry_process_filter+0x22d4>
    50c8:      	mov	w8, #0x1                // =1
    50cc:      	mov	x0, x20
    50d0:      	b	0x514c <generic_fentry_process_filter+0x150c>
    50d4:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    50d8:      	add	x1, x24, #0x4
    50dc:      	mov	w8, #0x1                // =1
    50e0:      	ldr	x0, [x0]
    50e4:      	blr	x8
    50e8:      	cbz	x0, 0x5f14 <generic_fentry_process_filter+0x22d4>
    50ec:      	mov	x19, x0
    50f0:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    50f4:      	mov	w8, #0x1                // =1
    50f8:      	ldr	x0, [x0]
    50fc:      	add	x9, sp, #0xc0
    5100:      	add	x1, sp, #0xc0
    5104:      	blr	x8
    5108:      	cbz	x0, 0x5f14 <generic_fentry_process_filter+0x22d4>
    510c:      	mov	w1, wzr
    5110:      	mov	w2, #0x104              // =260
    5114:      	mov	x29, x0
    5118:      	bl	0x5118 <generic_fentry_process_filter+0x14d8>
    511c:      	ldr	w8, [x25]
    5120:      	mov	x0, x29
    5124:      	add	x2, x25, #0x8
    5128:      	lsl	w9, w8, #3
    512c:      	and	x8, x8, #0xff
    5130:      	str	w9, [x0], #0x4
    5134:      	mov	w9, #0x4                // =4
    5138:      	ldrb	w1, [x25]
    513c:      	blr	x9
    5140:      	tbnz	x0, #0x3f, 0x5f14 <generic_fentry_process_filter+0x22d4>
    5144:      	mov	w8, #0x1                // =1
    5148:      	mov	x0, x19
    514c:      	mov	x1, x29
    5150:      	b	0x52f4 <generic_fentry_process_filter+0x16b4>
    5154:      	str	wzr, [sp, #0xc8]
    5158:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    515c:      	mov	w8, #0x1                // =1
    5160:      	add	x9, sp, #0xc8
    5164:      	ldr	x0, [x0]
    5168:      	add	x1, sp, #0xc8
    516c:      	blr	x8
    5170:      	cbz	x0, 0x52a8 <generic_fentry_process_filter+0x1668>
    5174:      	ldr	x8, [x0]
    5178:      	ldr	x9, [x25, #0x310]
    517c:      	cmp	x8, x9
    5180:      	b.eq	0x52a8 <generic_fentry_process_filter+0x1668>
    5184:      	str	x0, [sp, #0x30]
    5188:      	adrp	x8, 0x5000 <generic_fentry_process_filter+0x13c0>
    518c:      	ldr	x8, [x8]
    5190:      	ldrb	w8, [x8]
    5194:      	cbz	w8, 0x521c <generic_fentry_process_filter+0x15dc>
    5198:      	adrp	x19, 0x5000 <generic_fentry_process_filter+0x13c0>
    519c:      	mov	w20, #0x869f            // =34463
    51a0:      	mov	x22, xzr
    51a4:      	ldr	x19, [x19]
    51a8:      	movk	w20, #0x1, lsl #16
    51ac:      	b	0x51c4 <generic_fentry_process_filter+0x1584>
    51b0:      	cmp	x29, x22
    51b4:      	mov	x22, x29
    51b8:      	ccmp	w20, #0x0, #0x4, ne
    51bc:      	sub	w20, w20, #0x1
    51c0:      	b.eq	0x529c <generic_fentry_process_filter+0x165c>
    51c4:      	ldr	x8, [sp, #0x48]
    51c8:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    51cc:      	add	x9, sp, #0x58
    51d0:      	add	x1, sp, #0x58
    51d4:      	ldr	w8, [x8, #0x10]
    51d8:      	str	w8, [sp, #0x58]
    51dc:      	mov	w8, #0x1                // =1
    51e0:      	ldr	x0, [x0]
    51e4:      	blr	x8
    51e8:      	cbz	x0, 0x529c <generic_fentry_process_filter+0x165c>
    51ec:      	add	x1, x0, #0x70
    51f0:      	mov	w8, #0x1                // =1
    51f4:      	mov	x29, x0
    51f8:      	mov	x0, x19
    51fc:      	blr	x8
    5200:      	cbz	x0, 0x51b0 <generic_fentry_process_filter+0x1570>
    5204:      	ldr	x8, [x0]
    5208:      	cbz	x8, 0x51b0 <generic_fentry_process_filter+0x1570>
    520c:      	ldr	x9, [x25, #0x308]
    5210:      	orr	x8, x9, x8
    5214:      	str	x8, [x25, #0x308]
    5218:      	b	0x51b0 <generic_fentry_process_filter+0x1570>
    521c:      	adrp	x19, 0x5000 <generic_fentry_process_filter+0x13c0>
    5220:      	mov	x22, xzr
    5224:      	mov	w20, #0x3ff             // =1023
    5228:      	ldr	x19, [x19]
    522c:      	b	0x5244 <generic_fentry_process_filter+0x1604>
    5230:      	cmp	x29, x22
    5234:      	mov	x22, x29
    5238:      	ccmp	w20, #0x0, #0x4, ne
    523c:      	sub	w20, w20, #0x1
    5240:      	b.eq	0x529c <generic_fentry_process_filter+0x165c>
    5244:      	ldr	x8, [sp, #0x48]
    5248:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    524c:      	add	x9, sp, #0x58
    5250:      	add	x1, sp, #0x58
    5254:      	ldr	w8, [x8, #0x10]
    5258:      	str	w8, [sp, #0x58]
    525c:      	mov	w8, #0x1                // =1
    5260:      	ldr	x0, [x0]
    5264:      	blr	x8
    5268:      	cbz	x0, 0x529c <generic_fentry_process_filter+0x165c>
    526c:      	add	x1, x0, #0x70
    5270:      	mov	w8, #0x1                // =1
    5274:      	mov	x29, x0
    5278:      	mov	x0, x19
    527c:      	blr	x8
    5280:      	cbz	x0, 0x5230 <generic_fentry_process_filter+0x15f0>
    5284:      	ldr	x8, [x0]
    5288:      	cbz	x8, 0x5230 <generic_fentry_process_filter+0x15f0>
    528c:      	ldr	x9, [x25, #0x308]
    5290:      	orr	x8, x9, x8
    5294:      	str	x8, [x25, #0x308]
    5298:      	b	0x5230 <generic_fentry_process_filter+0x15f0>
    529c:      	ldr	x8, [sp, #0x30]
    52a0:      	ldr	x8, [x8]
    52a4:      	str	x8, [x25, #0x310]
    52a8:      	ldr	w8, [x24, #0x8]
    52ac:      	cmn	w8, #0x1
    52b0:      	b.eq	0x52d0 <generic_fentry_process_filter+0x1690>
    52b4:      	ldr	x9, [x25, #0x308]
    52b8:      	lsr	x8, x9, x8
    52bc:      	tbz	w8, #0x0, 0x52d0 <generic_fentry_process_filter+0x1690>
    52c0:      	mov	x0, #0xffee             // =65518
    52c4:      	movk	x0, #0xadc0, lsl #16
    52c8:      	movk	x0, #0xb, lsl #32
    52cc:      	b	0x52f8 <generic_fentry_process_filter+0x16b8>
    52d0:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    52d4:      	mov	w8, #0x1                // =1
    52d8:      	add	x9, sp, #0xd8
    52dc:      	ldr	x0, [x0]
    52e0:      	add	x1, sp, #0xd8
    52e4:      	blr	x8
    52e8:      	cbz	x0, 0x5f14 <generic_fentry_process_filter+0x22d4>
    52ec:      	add	x1, x25, #0x8
    52f0:      	mov	w8, #0x1                // =1
    52f4:      	blr	x8
    52f8:      	ldr	w8, [x24]
    52fc:      	cmp	w8, #0x25
    5300:      	b.hi	0x5328 <generic_fentry_process_filter+0x16e8>
    5304:      	mov	w9, #0x1                // =1
    5308:      	lsl	x8, x9, x8
    530c:      	mov	x9, #0x50               // =80
    5310:      	movk	x9, #0xc00, lsl #16
    5314:      	movk	x9, #0x20, lsl #32
    5318:      	tst	x8, x9
    531c:      	b.eq	0x5328 <generic_fentry_process_filter+0x16e8>
    5320:      	cbnz	x0, 0x5f14 <generic_fentry_process_filter+0x22d4>
    5324:      	b	0x532c <generic_fentry_process_filter+0x16ec>
    5328:      	cbz	x0, 0x5f14 <generic_fentry_process_filter+0x22d4>
    532c:      	lsl	w8, w21, #2
    5330:      	add	x9, x8, #0x4
    5334:      	ldr	w8, [x9, x23]
    5338:      	add	w9, w8, w9
    533c:      	and	w11, w9, #0x3ff
    5340:      	add	w9, w9, #0x4
    5344:      	and	x9, x9, #0x3ff
    5348:      	add	x10, x11, #0x8
    534c:      	ldr	w9, [x9, x23]
    5350:      	cmp	w9, #0x5
    5354:      	b.lo	0x53e4 <generic_fentry_process_filter+0x17a4>
    5358:      	add	x9, x10, x23
    535c:      	ldr	w10, [x9, #0x8]
    5360:      	ldp	w12, w22, [x9]
    5364:      	stp	x9, x11, [sp, #0x8]
    5368:      	mov	w9, #0x4                // =4
    536c:      	cmp	w10, #0x4
    5370:      	stp	xzr, xzr, [sp, #0x58]
    5374:      	csel	w9, w10, w9, lo
    5378:      	cmp	w12, #0x6
    537c:      	b.ne	0x5388 <generic_fentry_process_filter+0x1748>
    5380:      	mov	x11, #0x100000001       // =4294967297
    5384:      	stp	x11, x11, [sp, #0x58]
    5388:      	cbz	w10, 0x57ec <generic_fentry_process_filter+0x1bac>
    538c:      	ldr	x10, [sp, #0x48]
    5390:      	add	w8, w8, w21, lsl #2
    5394:      	tst	x22, #0x1
    5398:      	add	x25, sp, #0x58
    539c:      	str	w12, [sp, #0x30]
    53a0:      	add	w8, w8, #0x4
    53a4:      	and	x8, x8, #0x3ff
    53a8:      	add	x21, x8, #0x14
    53ac:      	sub	x8, x9, #0x1
    53b0:      	mov	w9, #0x3                // =3
    53b4:      	add	x11, x10, #0x24
    53b8:      	str	x11, [sp, #0x20]
    53bc:      	csel	x11, x10, x11, eq
    53c0:      	cmp	x8, #0x3
    53c4:      	add	x10, x10, #0x10
    53c8:      	csel	x8, x8, x9, lo
    53cc:      	and	x9, x21, #0x7fc
    53d0:      	mov	x20, x11
    53d4:      	str	x10, [sp, #0x18]
    53d8:      	add	x19, x23, x9
    53dc:      	add	x24, x8, #0x1
    53e0:      	b	0x541c <generic_fentry_process_filter+0x17dc>
    53e4:      	mov	w9, #0x1                // =1
    53e8:      	mov	w8, w10
    53ec:      	b	0x5834 <generic_fentry_process_filter+0x1bf4>
    53f0:      	mov	w8, #0x1                // =1
    53f4:      	ldr	w12, [sp, #0x30]
    53f8:      	mov	x11, x20
    53fc:      	cmp	w12, #0x6
    5400:      	eor	w8, w8, #0x1
    5404:      	csinc	w9, w8, wzr, eq
    5408:      	str	w9, [x25], #0x4
    540c:      	add	x21, x21, #0x4
    5410:      	add	x19, x19, #0x4
    5414:      	subs	x24, x24, #0x1
    5418:      	b.eq	0x57ec <generic_fentry_process_filter+0x1bac>
    541c:      	cmp	x21, #0x3e8
    5420:      	b.ls	0x5644 <generic_fentry_process_filter+0x1a04>
    5424:      	mov	x29, xzr
    5428:      	tbz	w22, #0x1, 0x564c <generic_fentry_process_filter+0x1a0c>
    542c:      	tbnz	w22, #0x0, 0x5678 <generic_fentry_process_filter+0x1a38>
    5430:      	ldr	x10, [sp, #0x48]
    5434:      	mov	w8, #0x1                // =1
    5438:      	ldr	w9, [x10]
    543c:      	cmp	x29, x9
    5440:      	b.eq	0x53fc <generic_fentry_process_filter+0x17bc>
    5444:      	ldr	w9, [x10, #0x10]
    5448:      	cmp	x29, x9
    544c:      	b.eq	0x53fc <generic_fentry_process_filter+0x17bc>
    5450:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    5454:      	mov	w8, #0x1                // =1
    5458:      	ldr	x0, [x0]
    545c:      	ldr	x1, [sp, #0x18]
    5460:      	blr	x8
    5464:      	cbz	x0, 0x57d0 <generic_fentry_process_filter+0x1b90>
    5468:      	ldr	w9, [x0]
    546c:      	mov	x1, x0
    5470:      	mov	w8, #0x1                // =1
    5474:      	cmp	x29, x9
    5478:      	b.eq	0x53f4 <generic_fentry_process_filter+0x17b4>
    547c:      	ldr	w9, [x1, #0x10]!
    5480:      	ldr	w12, [sp, #0x30]
    5484:      	mov	x11, x20
    5488:      	cmp	x29, x9
    548c:      	b.eq	0x53fc <generic_fentry_process_filter+0x17bc>
    5490:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    5494:      	mov	w8, #0x1                // =1
    5498:      	ldr	x0, [x0]
    549c:      	blr	x8
    54a0:      	cbz	x0, 0x57d0 <generic_fentry_process_filter+0x1b90>
    54a4:      	ldr	w9, [x0]
    54a8:      	mov	x1, x0
    54ac:      	mov	w8, #0x1                // =1
    54b0:      	cmp	x29, x9
    54b4:      	b.eq	0x53f4 <generic_fentry_process_filter+0x17b4>
    54b8:      	ldr	w9, [x1, #0x10]!
    54bc:      	ldr	w12, [sp, #0x30]
    54c0:      	mov	x11, x20
    54c4:      	cmp	x29, x9
    54c8:      	b.eq	0x53fc <generic_fentry_process_filter+0x17bc>
    54cc:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    54d0:      	mov	w8, #0x1                // =1
    54d4:      	ldr	x0, [x0]
    54d8:      	blr	x8
    54dc:      	cbz	x0, 0x57d0 <generic_fentry_process_filter+0x1b90>
    54e0:      	ldr	w9, [x0]
    54e4:      	mov	x1, x0
    54e8:      	mov	w8, #0x1                // =1
    54ec:      	cmp	x29, x9
    54f0:      	b.eq	0x53f4 <generic_fentry_process_filter+0x17b4>
    54f4:      	ldr	w9, [x1, #0x10]!
    54f8:      	ldr	w12, [sp, #0x30]
    54fc:      	mov	x11, x20
    5500:      	cmp	x29, x9
    5504:      	b.eq	0x53fc <generic_fentry_process_filter+0x17bc>
    5508:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    550c:      	mov	w8, #0x1                // =1
    5510:      	ldr	x0, [x0]
    5514:      	blr	x8
    5518:      	cbz	x0, 0x57d0 <generic_fentry_process_filter+0x1b90>
    551c:      	ldr	w9, [x0]
    5520:      	mov	x1, x0
    5524:      	mov	w8, #0x1                // =1
    5528:      	cmp	x29, x9
    552c:      	b.eq	0x53f4 <generic_fentry_process_filter+0x17b4>
    5530:      	ldr	w9, [x1, #0x10]!
    5534:      	ldr	w12, [sp, #0x30]
    5538:      	mov	x11, x20
    553c:      	cmp	x29, x9
    5540:      	b.eq	0x53fc <generic_fentry_process_filter+0x17bc>
    5544:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    5548:      	mov	w8, #0x1                // =1
    554c:      	ldr	x0, [x0]
    5550:      	blr	x8
    5554:      	cbz	x0, 0x57d0 <generic_fentry_process_filter+0x1b90>
    5558:      	ldr	w9, [x0]
    555c:      	mov	x1, x0
    5560:      	mov	w8, #0x1                // =1
    5564:      	cmp	x29, x9
    5568:      	b.eq	0x53f4 <generic_fentry_process_filter+0x17b4>
    556c:      	ldr	w9, [x1, #0x10]!
    5570:      	ldr	w12, [sp, #0x30]
    5574:      	mov	x11, x20
    5578:      	cmp	x29, x9
    557c:      	b.eq	0x53fc <generic_fentry_process_filter+0x17bc>
    5580:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    5584:      	mov	w8, #0x1                // =1
    5588:      	ldr	x0, [x0]
    558c:      	blr	x8
    5590:      	cbz	x0, 0x57d0 <generic_fentry_process_filter+0x1b90>
    5594:      	ldr	w9, [x0]
    5598:      	mov	x1, x0
    559c:      	mov	w8, #0x1                // =1
    55a0:      	cmp	x29, x9
    55a4:      	b.eq	0x53f4 <generic_fentry_process_filter+0x17b4>
    55a8:      	ldr	w9, [x1, #0x10]!
    55ac:      	ldr	w12, [sp, #0x30]
    55b0:      	mov	x11, x20
    55b4:      	cmp	x29, x9
    55b8:      	b.eq	0x53fc <generic_fentry_process_filter+0x17bc>
    55bc:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    55c0:      	mov	w8, #0x1                // =1
    55c4:      	ldr	x0, [x0]
    55c8:      	blr	x8
    55cc:      	cbz	x0, 0x57d0 <generic_fentry_process_filter+0x1b90>
    55d0:      	ldr	w9, [x0]
    55d4:      	mov	x1, x0
    55d8:      	mov	w8, #0x1                // =1
    55dc:      	cmp	x29, x9
    55e0:      	b.eq	0x53f4 <generic_fentry_process_filter+0x17b4>
    55e4:      	ldr	w9, [x1, #0x10]!
    55e8:      	ldr	w12, [sp, #0x30]
    55ec:      	mov	x11, x20
    55f0:      	cmp	x29, x9
    55f4:      	b.eq	0x53fc <generic_fentry_process_filter+0x17bc>
    55f8:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    55fc:      	mov	w8, #0x1                // =1
    5600:      	ldr	x0, [x0]
    5604:      	blr	x8
    5608:      	cbz	x0, 0x57d0 <generic_fentry_process_filter+0x1b90>
    560c:      	ldr	w9, [x0]
    5610:      	mov	x1, x0
    5614:      	mov	w8, #0x1                // =1
    5618:      	cmp	x29, x9
    561c:      	b.eq	0x53f4 <generic_fentry_process_filter+0x17b4>
    5620:      	ldr	w9, [x1, #0x10]!
    5624:      	ldr	w12, [sp, #0x30]
    5628:      	mov	x11, x20
    562c:      	cmp	x29, x9
    5630:      	b.eq	0x53fc <generic_fentry_process_filter+0x17bc>
    5634:      	adrp	x9, 0x5000 <generic_fentry_process_filter+0x13c0>
    5638:      	mov	w8, #0x1                // =1
    563c:      	ldr	x9, [x9]
    5640:      	b	0x57c4 <generic_fentry_process_filter+0x1b84>
    5644:      	ldr	w29, [x19]
    5648:      	tbnz	w22, #0x1, 0x542c <generic_fentry_process_filter+0x17ec>
    564c:      	ldr	w8, [x11]
    5650:      	cmp	w12, #0x5
    5654:      	b.ne	0x5668 <generic_fentry_process_filter+0x1a28>
    5658:      	cmp	x29, x8
    565c:      	b.eq	0x5668 <generic_fentry_process_filter+0x1a28>
    5660:      	mov	w9, wzr
    5664:      	b	0x5408 <generic_fentry_process_filter+0x17c8>
    5668:      	cmp	w12, #0x6
    566c:      	ccmp	x29, x8, #0x0, eq
    5670:      	cset	w9, ne
    5674:      	b	0x5408 <generic_fentry_process_filter+0x17c8>
    5678:      	ldr	x8, [sp, #0x20]
    567c:      	ldr	w9, [x8]
    5680:      	cbz	w9, 0x5408 <generic_fentry_process_filter+0x17c8>
    5684:      	mov	w8, #0x1                // =1
    5688:      	cbz	x29, 0x53fc <generic_fentry_process_filter+0x17bc>
    568c:      	cmp	x29, x9
    5690:      	b.eq	0x53fc <generic_fentry_process_filter+0x17bc>
    5694:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    5698:      	mov	w8, #0x1                // =1
    569c:      	ldr	x0, [x0]
    56a0:      	ldr	x1, [sp, #0x18]
    56a4:      	blr	x8
    56a8:      	cbz	x0, 0x57d0 <generic_fentry_process_filter+0x1b90>
    56ac:      	ldr	w8, [x0, #0x24]
    56b0:      	cmp	x29, x8
    56b4:      	b.eq	0x53f0 <generic_fentry_process_filter+0x17b0>
    56b8:      	add	x1, x0, #0x10
    56bc:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    56c0:      	mov	w8, #0x1                // =1
    56c4:      	ldr	x0, [x0]
    56c8:      	blr	x8
    56cc:      	cbz	x0, 0x57d0 <generic_fentry_process_filter+0x1b90>
    56d0:      	ldr	w8, [x0, #0x24]
    56d4:      	cmp	x29, x8
    56d8:      	b.eq	0x53f0 <generic_fentry_process_filter+0x17b0>
    56dc:      	add	x1, x0, #0x10
    56e0:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    56e4:      	mov	w8, #0x1                // =1
    56e8:      	ldr	x0, [x0]
    56ec:      	blr	x8
    56f0:      	cbz	x0, 0x57d0 <generic_fentry_process_filter+0x1b90>
    56f4:      	ldr	w8, [x0, #0x24]
    56f8:      	cmp	x29, x8
    56fc:      	b.eq	0x53f0 <generic_fentry_process_filter+0x17b0>
    5700:      	add	x1, x0, #0x10
    5704:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    5708:      	mov	w8, #0x1                // =1
    570c:      	ldr	x0, [x0]
    5710:      	blr	x8
    5714:      	cbz	x0, 0x57d0 <generic_fentry_process_filter+0x1b90>
    5718:      	ldr	w8, [x0, #0x24]
    571c:      	cmp	x29, x8
    5720:      	b.eq	0x53f0 <generic_fentry_process_filter+0x17b0>
    5724:      	add	x1, x0, #0x10
    5728:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    572c:      	mov	w8, #0x1                // =1
    5730:      	ldr	x0, [x0]
    5734:      	blr	x8
    5738:      	cbz	x0, 0x57d0 <generic_fentry_process_filter+0x1b90>
    573c:      	ldr	w8, [x0, #0x24]
    5740:      	cmp	x29, x8
    5744:      	b.eq	0x53f0 <generic_fentry_process_filter+0x17b0>
    5748:      	add	x1, x0, #0x10
    574c:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    5750:      	mov	w8, #0x1                // =1
    5754:      	ldr	x0, [x0]
    5758:      	blr	x8
    575c:      	cbz	x0, 0x57d0 <generic_fentry_process_filter+0x1b90>
    5760:      	ldr	w8, [x0, #0x24]
    5764:      	cmp	x29, x8
    5768:      	b.eq	0x53f0 <generic_fentry_process_filter+0x17b0>
    576c:      	add	x1, x0, #0x10
    5770:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    5774:      	mov	w8, #0x1                // =1
    5778:      	ldr	x0, [x0]
    577c:      	blr	x8
    5780:      	cbz	x0, 0x57d0 <generic_fentry_process_filter+0x1b90>
    5784:      	ldr	w8, [x0, #0x24]
    5788:      	cmp	x29, x8
    578c:      	b.eq	0x53f0 <generic_fentry_process_filter+0x17b0>
    5790:      	add	x1, x0, #0x10
    5794:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    5798:      	mov	w8, #0x1                // =1
    579c:      	ldr	x0, [x0]
    57a0:      	blr	x8
    57a4:      	cbz	x0, 0x57d0 <generic_fentry_process_filter+0x1b90>
    57a8:      	ldr	w8, [x0, #0x24]
    57ac:      	cmp	x29, x8
    57b0:      	b.eq	0x53f0 <generic_fentry_process_filter+0x17b0>
    57b4:      	adrp	x9, 0x5000 <generic_fentry_process_filter+0x13c0>
    57b8:      	add	x1, x0, #0x10
    57bc:      	mov	w8, #0x1                // =1
    57c0:      	ldr	x9, [x9]
    57c4:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    57c8:      	ldr	x0, [x0]
    57cc:      	blr	x8
    57d0:      	ldr	w12, [sp, #0x30]
    57d4:      	mov	w8, wzr
    57d8:      	mov	w9, wzr
    57dc:      	mov	x11, x20
    57e0:      	cmp	w12, #0x5
    57e4:      	b.ne	0x53fc <generic_fentry_process_filter+0x17bc>
    57e8:      	b	0x5408 <generic_fentry_process_filter+0x17c8>
    57ec:      	ldp	w8, w9, [sp, #0x58]
    57f0:      	ldp	w10, w11, [sp, #0x60]
    57f4:      	cmp	w12, #0x6
    57f8:      	b.ne	0x580c <generic_fentry_process_filter+0x1bcc>
    57fc:      	and	w8, w9, w8
    5800:      	and	w9, w10, w11
    5804:      	and	w9, w8, w9
    5808:      	b	0x5818 <generic_fentry_process_filter+0x1bd8>
    580c:      	orr	w8, w9, w8
    5810:      	orr	w9, w10, w11
    5814:      	orr	w9, w8, w9
    5818:      	ldr	x8, [sp, #0x10]
    581c:      	cbz	w9, 0x5f14 <generic_fentry_process_filter+0x22d4>
    5820:      	ldr	x10, [sp, #0x8]
    5824:      	add	w8, w8, #0x14
    5828:      	ldr	w10, [x10, #0x8]
    582c:      	ubfiz	w10, w10, #2, #3
    5830:      	add	w8, w10, w8
    5834:      	and	x10, x8, #0x3ff
    5838:      	add	w8, w8, #0x4
    583c:      	mov	w19, #0xa               // =10
    5840:      	ldr	w10, [x10, x23]
    5844:      	mov	w20, #0x4               // =4
    5848:      	mov	x25, #0x100000001       // =4294967297
    584c:      	sub	w22, w10, #0x4
    5850:      	ldr	x10, [sp, #0xe8]
    5854:      	add	x10, x10, #0x20
    5858:      	str	x10, [sp, #0x30]
    585c:      	b	0x5868 <generic_fentry_process_filter+0x1c28>
    5860:      	subs	x19, x19, #0x1
    5864:      	b.eq	0x5a34 <generic_fentry_process_filter+0x1df4>
    5868:      	cbz	w22, 0x5860 <generic_fentry_process_filter+0x1c20>
    586c:      	and	x9, x8, #0x3ff
    5870:      	add	x10, x9, x23
    5874:      	ldr	w29, [x10, #0x8]
    5878:      	ldp	w9, w24, [x10]
    587c:      	stp	xzr, xzr, [sp, #0x58]
    5880:      	cmp	w29, #0x4
    5884:      	csel	w10, w29, w20, lo
    5888:      	cmp	w24, #0x6
    588c:      	b.ne	0x5894 <generic_fentry_process_filter+0x1c54>
    5890:      	stp	x25, x25, [sp, #0x58]
    5894:      	add	w21, w8, #0xc
    5898:      	cbz	w29, 0x59ec <generic_fentry_process_filter+0x1dac>
    589c:      	and	x9, x9, #0xf
    58a0:      	cmp	w9, #0xa
    58a4:      	b.lo	0x58d0 <generic_fentry_process_filter+0x1c90>
    58a8:      	sub	x8, x10, #0x1
    58ac:      	mov	w9, #0x3                // =3
    58b0:      	add	x0, sp, #0x58
    58b4:      	mov	w1, wzr
    58b8:      	cmp	x8, #0x3
    58bc:      	csel	x8, x8, x9, lo
    58c0:      	lsl	x8, x8, #2
    58c4:      	add	x2, x8, #0x4
    58c8:      	bl	0x58c8 <generic_fentry_process_filter+0x1c88>
    58cc:      	b	0x59ec <generic_fentry_process_filter+0x1dac>
    58d0:      	cmp	w21, #0x3e8
    58d4:      	b.ls	0x58e0 <generic_fentry_process_filter+0x1ca0>
    58d8:      	mov	w11, wzr
    58dc:      	b	0x58e8 <generic_fentry_process_filter+0x1ca8>
    58e0:      	and	w11, w21, #0xfffffffc
    58e4:      	ldr	w11, [x23, w11, uxtw]
    58e8:      	ldr	x12, [sp, #0x30]
    58ec:      	cmp	w24, #0x5
    58f0:      	sub	x10, x10, #0x1
    58f4:      	ldr	w9, [x12, x9, lsl #2]
    58f8:      	cset	w12, ne
    58fc:      	cmp	w24, #0x6
    5900:      	cset	w13, ne
    5904:      	cmp	w11, w9
    5908:      	csinc	w11, w12, wzr, ne
    590c:      	csinc	w12, w13, wzr, eq
    5910:      	and	w11, w11, w12
    5914:      	str	w11, [sp, #0x58]
    5918:      	cbz	x10, 0x59ec <generic_fentry_process_filter+0x1dac>
    591c:      	add	w11, w8, #0x10
    5920:      	cmp	w11, #0x3e8
    5924:      	b.ls	0x5930 <generic_fentry_process_filter+0x1cf0>
    5928:      	mov	w11, wzr
    592c:      	b	0x5938 <generic_fentry_process_filter+0x1cf8>
    5930:      	and	w11, w11, #0xfffffffc
    5934:      	ldr	w11, [x23, w11, uxtw]
    5938:      	cmp	w24, #0x5
    593c:      	cset	w12, ne
    5940:      	cmp	w24, #0x6
    5944:      	cset	w13, ne
    5948:      	cmp	w11, w9
    594c:      	csinc	w11, w12, wzr, ne
    5950:      	csinc	w12, w13, wzr, eq
    5954:      	cmp	x10, #0x1
    5958:      	and	w11, w11, w12
    595c:      	str	w11, [sp, #0x5c]
    5960:      	b.eq	0x59ec <generic_fentry_process_filter+0x1dac>
    5964:      	add	w11, w8, #0x14
    5968:      	cmp	w11, #0x3e8
    596c:      	b.ls	0x5978 <generic_fentry_process_filter+0x1d38>
    5970:      	mov	w11, wzr
    5974:      	b	0x5980 <generic_fentry_process_filter+0x1d40>
    5978:      	and	w11, w11, #0xfffffffc
    597c:      	ldr	w11, [x23, w11, uxtw]
    5980:      	cmp	w24, #0x5
    5984:      	cset	w12, ne
    5988:      	cmp	w24, #0x6
    598c:      	cset	w13, ne
    5990:      	cmp	w11, w9
    5994:      	csinc	w11, w12, wzr, ne
    5998:      	csinc	w12, w13, wzr, eq
    599c:      	cmp	x10, #0x2
    59a0:      	and	w11, w11, w12
    59a4:      	str	w11, [sp, #0x60]
    59a8:      	b.eq	0x59ec <generic_fentry_process_filter+0x1dac>
    59ac:      	add	w8, w8, #0x18
    59b0:      	cmp	w8, #0x3e8
    59b4:      	b.ls	0x59c0 <generic_fentry_process_filter+0x1d80>
    59b8:      	mov	w8, wzr
    59bc:      	b	0x59c8 <generic_fentry_process_filter+0x1d88>
    59c0:      	and	w8, w8, #0xfffffffc
    59c4:      	ldr	w8, [x23, w8, uxtw]
    59c8:      	cmp	w24, #0x5
    59cc:      	cset	w10, ne
    59d0:      	cmp	w24, #0x6
    59d4:      	cset	w11, ne
    59d8:      	cmp	w8, w9
    59dc:      	csinc	w8, w10, wzr, ne
    59e0:      	csinc	w9, w11, wzr, eq
    59e4:      	and	w8, w8, w9
    59e8:      	str	w8, [sp, #0x64]
    59ec:      	ldp	w8, w9, [sp, #0x58]
    59f0:      	ldp	w10, w11, [sp, #0x60]
    59f4:      	cmp	w24, #0x6
    59f8:      	b.ne	0x5a0c <generic_fentry_process_filter+0x1dcc>
    59fc:      	and	w8, w9, w8
    5a00:      	and	w9, w10, w11
    5a04:      	and	w9, w8, w9
    5a08:      	b	0x5a18 <generic_fentry_process_filter+0x1dd8>
    5a0c:      	orr	w8, w9, w8
    5a10:      	orr	w9, w10, w11
    5a14:      	orr	w9, w8, w9
    5a18:      	cbz	w9, 0x5f14 <generic_fentry_process_filter+0x22d4>
    5a1c:      	lsl	w8, w29, #2
    5a20:      	sub	w10, w22, w29, lsl #2
    5a24:      	and	w8, w8, #0x1c
    5a28:      	sub	w22, w10, #0xc
    5a2c:      	add	w8, w8, w21
    5a30:      	b	0x5860 <generic_fentry_process_filter+0x1c20>
    5a34:      	mov	w10, w8
    5a38:      	add	w19, w8, #0x4
    5a3c:      	and	x10, x10, #0x3ff
    5a40:      	ldr	w10, [x10, x23]
    5a44:      	cmp	w10, #0x4
    5a48:      	b.ne	0x5ae0 <generic_fentry_process_filter+0x1ea0>
    5a4c:      	cbz	w9, 0x5f14 <generic_fentry_process_filter+0x22d4>
    5a50:      	mov	w8, w19
    5a54:      	and	x8, x8, #0x3ff
    5a58:      	ldr	w9, [x8, x23]
    5a5c:      	add	w8, w19, #0x4
    5a60:      	cmp	w9, #0x4
    5a64:      	mov	w9, w8
    5a68:      	b.eq	0x5e10 <generic_fentry_process_filter+0x21d0>
    5a6c:      	and	x8, x8, #0x3ff
    5a70:      	add	x8, x8, x23
    5a74:      	ldp	w20, w22, [x8]
    5a78:      	mov	w8, #0xe                // =14
    5a7c:      	blr	x8
    5a80:      	lsr	x8, x0, #32
    5a84:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    5a88:      	add	x9, sp, #0x58
    5a8c:      	str	w8, [sp, #0x58]
    5a90:      	mov	w8, #0x1                // =1
    5a94:      	add	x1, sp, #0x58
    5a98:      	ldr	x0, [x0]
    5a9c:      	blr	x8
    5aa0:      	cbz	x0, 0x5f14 <generic_fentry_process_filter+0x22d4>
    5aa4:      	cmp	w20, #0x5
    5aa8:      	b.eq	0x5b5c <generic_fentry_process_filter+0x1f1c>
    5aac:      	cmp	w20, #0x6
    5ab0:      	b.ne	0x5f14 <generic_fentry_process_filter+0x22d4>
    5ab4:      	ldr	x11, [sp, #0xe8]
    5ab8:      	mov	w8, #0x5ee8             // =24296
    5abc:      	add	x8, x11, x8
    5ac0:      	tbnz	w22, #0x0, 0x5b90 <generic_fentry_process_filter+0x1f50>
    5ac4:      	ldr	w9, [x0, #0x28]
    5ac8:      	cbz	w9, 0x5b88 <generic_fentry_process_filter+0x1f48>
    5acc:      	ldr	x10, [sp, #0x30]
    5ad0:      	ldr	w10, [x10]
    5ad4:      	cmp	w9, w10
    5ad8:      	b.eq	0x5b90 <generic_fentry_process_filter+0x1f50>
    5adc:      	b	0x5e04 <generic_fentry_process_filter+0x21c4>
    5ae0:      	and	x9, x19, #0x3ff
    5ae4:      	add	w19, w8, #0x18
    5ae8:      	add	x9, x9, x23
    5aec:      	ldp	w8, w10, [x9]
    5af0:      	ldr	w12, [x9, #0x8]
    5af4:      	ldur	x11, [x9, #0xc]
    5af8:      	cbz	w12, 0x5b1c <generic_fentry_process_filter+0x1edc>
    5afc:      	ldr	x14, [sp, #0xe8]
    5b00:      	mov	w9, wzr
    5b04:      	cmp	w8, #0x2
    5b08:      	b.hi	0x5a4c <generic_fentry_process_filter+0x1e0c>
    5b0c:      	ldr	w13, [x14, #0x44]
    5b10:      	cmp	w13, w12
    5b14:      	b.ne	0x5b30 <generic_fentry_process_filter+0x1ef0>
    5b18:      	b	0x5a4c <generic_fentry_process_filter+0x1e0c>
    5b1c:      	ldr	x14, [sp, #0xe8]
    5b20:      	cmp	w8, #0x2
    5b24:      	b.ls	0x5b30 <generic_fentry_process_filter+0x1ef0>
    5b28:      	mov	w9, wzr
    5b2c:      	b	0x5a4c <generic_fentry_process_filter+0x1e0c>
    5b30:      	add	x9, x14, #0x48
    5b34:      	cmp	w10, #0x5
    5b38:      	ldr	x8, [x9, x8, lsl #3]
    5b3c:      	and	x8, x8, x11
    5b40:      	b.ne	0x5b50 <generic_fentry_process_filter+0x1f10>
    5b44:      	cmp	x8, #0x0
    5b48:      	cset	w9, ne
    5b4c:      	b	0x5a4c <generic_fentry_process_filter+0x1e0c>
    5b50:      	cmp	x8, #0x0
    5b54:      	cset	w9, eq
    5b58:      	b	0x5a4c <generic_fentry_process_filter+0x1e0c>
    5b5c:      	ldr	x11, [sp, #0xe8]
    5b60:      	mov	w8, #0x5ee8             // =24296
    5b64:      	add	x8, x11, x8
    5b68:      	tbz	w22, #0x0, 0x5bb4 <generic_fentry_process_filter+0x1f74>
    5b6c:      	ldr	w9, [x0, #0x28]
    5b70:      	cbz	w9, 0x5bac <generic_fentry_process_filter+0x1f6c>
    5b74:      	ldr	x10, [sp, #0x30]
    5b78:      	ldr	w10, [x10]
    5b7c:      	cmp	w9, w10
    5b80:      	b.eq	0x5bb4 <generic_fentry_process_filter+0x1f74>
    5b84:      	b	0x5e04 <generic_fentry_process_filter+0x21c4>
    5b88:      	mov	w9, #0x1                // =1
    5b8c:      	str	x9, [x8]
    5b90:      	tbnz	w22, #0x1, 0x5bd8 <generic_fentry_process_filter+0x1f98>
    5b94:      	ldr	w9, [x0, #0x2c]
    5b98:      	cbz	w9, 0x5bd0 <generic_fentry_process_filter+0x1f90>
    5b9c:      	ldr	w10, [x11, #0x24]
    5ba0:      	cmp	w9, w10
    5ba4:      	b.eq	0x5bd8 <generic_fentry_process_filter+0x1f98>
    5ba8:      	b	0x5e04 <generic_fentry_process_filter+0x21c4>
    5bac:      	mov	w9, #0x1                // =1
    5bb0:      	str	x9, [x8]
    5bb4:      	tbz	w22, #0x1, 0x5bfc <generic_fentry_process_filter+0x1fbc>
    5bb8:      	ldr	w9, [x0, #0x2c]
    5bbc:      	cbz	w9, 0x5bf4 <generic_fentry_process_filter+0x1fb4>
    5bc0:      	ldr	w10, [x11, #0x24]
    5bc4:      	cmp	w9, w10
    5bc8:      	b.eq	0x5bfc <generic_fentry_process_filter+0x1fbc>
    5bcc:      	b	0x5e04 <generic_fentry_process_filter+0x21c4>
    5bd0:      	mov	w9, #0x1                // =1
    5bd4:      	str	x9, [x8]
    5bd8:      	tbnz	w22, #0x2, 0x5c20 <generic_fentry_process_filter+0x1fe0>
    5bdc:      	ldr	w9, [x0, #0x30]
    5be0:      	cbz	w9, 0x5c18 <generic_fentry_process_filter+0x1fd8>
    5be4:      	ldr	w10, [x11, #0x28]
    5be8:      	cmp	w9, w10
    5bec:      	b.eq	0x5c20 <generic_fentry_process_filter+0x1fe0>
    5bf0:      	b	0x5e04 <generic_fentry_process_filter+0x21c4>
    5bf4:      	mov	w9, #0x1                // =1
    5bf8:      	str	x9, [x8]
    5bfc:      	tbz	w22, #0x2, 0x5c44 <generic_fentry_process_filter+0x2004>
    5c00:      	ldr	w9, [x0, #0x30]
    5c04:      	cbz	w9, 0x5c3c <generic_fentry_process_filter+0x1ffc>
    5c08:      	ldr	w10, [x11, #0x28]
    5c0c:      	cmp	w9, w10
    5c10:      	b.eq	0x5c44 <generic_fentry_process_filter+0x2004>
    5c14:      	b	0x5e04 <generic_fentry_process_filter+0x21c4>
    5c18:      	mov	w9, #0x1                // =1
    5c1c:      	str	x9, [x8]
    5c20:      	tbnz	w22, #0x3, 0x5c68 <generic_fentry_process_filter+0x2028>
    5c24:      	ldr	w9, [x0, #0x34]
    5c28:      	cbz	w9, 0x5c60 <generic_fentry_process_filter+0x2020>
    5c2c:      	ldr	w10, [x11, #0x2c]
    5c30:      	cmp	w9, w10
    5c34:      	b.eq	0x5c68 <generic_fentry_process_filter+0x2028>
    5c38:      	b	0x5e04 <generic_fentry_process_filter+0x21c4>
    5c3c:      	mov	w9, #0x1                // =1
    5c40:      	str	x9, [x8]
    5c44:      	tbz	w22, #0x3, 0x5c8c <generic_fentry_process_filter+0x204c>
    5c48:      	ldr	w9, [x0, #0x34]
    5c4c:      	cbz	w9, 0x5c84 <generic_fentry_process_filter+0x2044>
    5c50:      	ldr	w10, [x11, #0x2c]
    5c54:      	cmp	w9, w10
    5c58:      	b.eq	0x5c8c <generic_fentry_process_filter+0x204c>
    5c5c:      	b	0x5e04 <generic_fentry_process_filter+0x21c4>
    5c60:      	mov	w9, #0x1                // =1
    5c64:      	str	x9, [x8]
    5c68:      	tbnz	w22, #0x4, 0x5cb0 <generic_fentry_process_filter+0x2070>
    5c6c:      	ldr	w9, [x0, #0x38]
    5c70:      	cbz	w9, 0x5ca8 <generic_fentry_process_filter+0x2068>
    5c74:      	ldr	w10, [x11, #0x30]
    5c78:      	cmp	w9, w10
    5c7c:      	b.eq	0x5cb0 <generic_fentry_process_filter+0x2070>
    5c80:      	b	0x5e04 <generic_fentry_process_filter+0x21c4>
    5c84:      	mov	w9, #0x1                // =1
    5c88:      	str	x9, [x8]
    5c8c:      	tbz	w22, #0x4, 0x5cd4 <generic_fentry_process_filter+0x2094>
    5c90:      	ldr	w9, [x0, #0x38]
    5c94:      	cbz	w9, 0x5ccc <generic_fentry_process_filter+0x208c>
    5c98:      	ldr	w10, [x11, #0x30]
    5c9c:      	cmp	w9, w10
    5ca0:      	b.eq	0x5cd4 <generic_fentry_process_filter+0x2094>
    5ca4:      	b	0x5e04 <generic_fentry_process_filter+0x21c4>
    5ca8:      	mov	w9, #0x1                // =1
    5cac:      	str	x9, [x8]
    5cb0:      	tbnz	w22, #0x5, 0x5cf8 <generic_fentry_process_filter+0x20b8>
    5cb4:      	ldr	w9, [x0, #0x3c]
    5cb8:      	cbz	w9, 0x5cf0 <generic_fentry_process_filter+0x20b0>
    5cbc:      	ldr	w10, [x11, #0x34]
    5cc0:      	cmp	w9, w10
    5cc4:      	b.eq	0x5cf8 <generic_fentry_process_filter+0x20b8>
    5cc8:      	b	0x5e04 <generic_fentry_process_filter+0x21c4>
    5ccc:      	mov	w9, #0x1                // =1
    5cd0:      	str	x9, [x8]
    5cd4:      	tbz	w22, #0x5, 0x5d1c <generic_fentry_process_filter+0x20dc>
    5cd8:      	ldr	w9, [x0, #0x3c]
    5cdc:      	cbz	w9, 0x5d14 <generic_fentry_process_filter+0x20d4>
    5ce0:      	ldr	w10, [x11, #0x34]
    5ce4:      	cmp	w9, w10
    5ce8:      	b.eq	0x5d1c <generic_fentry_process_filter+0x20dc>
    5cec:      	b	0x5e04 <generic_fentry_process_filter+0x21c4>
    5cf0:      	mov	w9, #0x1                // =1
    5cf4:      	str	x9, [x8]
    5cf8:      	tbnz	w22, #0x6, 0x5d40 <generic_fentry_process_filter+0x2100>
    5cfc:      	ldr	w9, [x0, #0x40]
    5d00:      	cbz	w9, 0x5d38 <generic_fentry_process_filter+0x20f8>
    5d04:      	ldr	w10, [x11, #0x38]
    5d08:      	cmp	w9, w10
    5d0c:      	b.eq	0x5d40 <generic_fentry_process_filter+0x2100>
    5d10:      	b	0x5e04 <generic_fentry_process_filter+0x21c4>
    5d14:      	mov	w9, #0x1                // =1
    5d18:      	str	x9, [x8]
    5d1c:      	tbz	w22, #0x6, 0x5d64 <generic_fentry_process_filter+0x2124>
    5d20:      	ldr	w9, [x0, #0x40]
    5d24:      	cbz	w9, 0x5d5c <generic_fentry_process_filter+0x211c>
    5d28:      	ldr	w10, [x11, #0x38]
    5d2c:      	cmp	w9, w10
    5d30:      	b.eq	0x5d64 <generic_fentry_process_filter+0x2124>
    5d34:      	b	0x5e04 <generic_fentry_process_filter+0x21c4>
    5d38:      	mov	w9, #0x1                // =1
    5d3c:      	str	x9, [x8]
    5d40:      	tbnz	w22, #0x7, 0x5d88 <generic_fentry_process_filter+0x2148>
    5d44:      	ldr	w9, [x0, #0x44]
    5d48:      	cbz	w9, 0x5d80 <generic_fentry_process_filter+0x2140>
    5d4c:      	ldr	w10, [x11, #0x3c]
    5d50:      	cmp	w9, w10
    5d54:      	b.eq	0x5d88 <generic_fentry_process_filter+0x2148>
    5d58:      	b	0x5e04 <generic_fentry_process_filter+0x21c4>
    5d5c:      	mov	w9, #0x1                // =1
    5d60:      	str	x9, [x8]
    5d64:      	tbz	w22, #0x7, 0x5db0 <generic_fentry_process_filter+0x2170>
    5d68:      	ldr	w9, [x0, #0x44]
    5d6c:      	cbz	w9, 0x5da8 <generic_fentry_process_filter+0x2168>
    5d70:      	ldr	w10, [x11, #0x3c]
    5d74:      	cmp	w9, w10
    5d78:      	b.eq	0x5db0 <generic_fentry_process_filter+0x2170>
    5d7c:      	b	0x5e04 <generic_fentry_process_filter+0x21c4>
    5d80:      	mov	w9, #0x1                // =1
    5d84:      	str	x9, [x8]
    5d88:      	tbnz	w22, #0x8, 0x5dd8 <generic_fentry_process_filter+0x2198>
    5d8c:      	ldr	w9, [x0, #0x48]
    5d90:      	cbz	w9, 0x5dd0 <generic_fentry_process_filter+0x2190>
    5d94:      	ldr	x10, [sp, #0xe8]
    5d98:      	ldr	w10, [x10, #0x40]
    5d9c:      	cmp	w9, w10
    5da0:      	b.eq	0x5dd8 <generic_fentry_process_filter+0x2198>
    5da4:      	b	0x5e04 <generic_fentry_process_filter+0x21c4>
    5da8:      	mov	w9, #0x1                // =1
    5dac:      	str	x9, [x8]
    5db0:      	tbz	w22, #0x8, 0x5de8 <generic_fentry_process_filter+0x21a8>
    5db4:      	ldr	w9, [x0, #0x48]
    5db8:      	cbz	w9, 0x5de0 <generic_fentry_process_filter+0x21a0>
    5dbc:      	ldr	x10, [sp, #0xe8]
    5dc0:      	ldr	w10, [x10, #0x40]
    5dc4:      	cmp	w9, w10
    5dc8:      	b.eq	0x5de8 <generic_fentry_process_filter+0x21a8>
    5dcc:      	b	0x5e04 <generic_fentry_process_filter+0x21c4>
    5dd0:      	mov	w9, #0x1                // =1
    5dd4:      	str	x9, [x8]
    5dd8:      	tbz	w22, #0x9, 0x5dec <generic_fentry_process_filter+0x21ac>
    5ddc:      	b	0x5f14 <generic_fentry_process_filter+0x22d4>
    5de0:      	mov	w9, #0x1                // =1
    5de4:      	str	x9, [x8]
    5de8:      	tbz	w22, #0x9, 0x5f14 <generic_fentry_process_filter+0x22d4>
    5dec:      	ldr	w9, [x0, #0x4c]
    5df0:      	cbz	w9, 0x5f0c <generic_fentry_process_filter+0x22cc>
    5df4:      	ldr	x10, [sp, #0xe8]
    5df8:      	ldr	w10, [x10, #0x44]
    5dfc:      	cmp	w9, w10
    5e00:      	b.eq	0x5f14 <generic_fentry_process_filter+0x22d4>
    5e04:      	add	w9, w19, #0xc
    5e08:      	mov	w10, #0x1               // =1
    5e0c:      	str	x10, [x8]
    5e10:      	and	x8, x9, #0x3ff
    5e14:      	adrp	x24, 0x5000 <generic_fentry_process_filter+0x13c0>
    5e18:      	ldr	w8, [x8, x23]
    5e1c:      	ldr	x24, [x24]
    5e20:      	cmp	w8, #0x4
    5e24:      	b.ne	0x5e58 <generic_fentry_process_filter+0x2218>
    5e28:      	ldr	x9, [sp, #0xe8]
    5e2c:      	mov	w8, #0x5eb8             // =24248
    5e30:      	add	x8, x9, x8
    5e34:      	ldr	x9, [x9, #0x5eb8]
    5e38:      	and	x9, x9, #0x1f
    5e3c:      	add	x8, x8, x9
    5e40:      	mov	w9, #0x1                // =1
    5e44:      	strb	w9, [x8, #0x9]
    5e48:      	ldr	x8, [sp, #0x40]
    5e4c:      	strb	w9, [x8, #0x20]
    5e50:      	strb	w9, [x8]
    5e54:      	b	0x5f14 <generic_fentry_process_filter+0x22d4>
    5e58:      	add	w8, w9, #0x4
    5e5c:      	and	x8, x8, #0x3ff
    5e60:      	add	x8, x8, x23
    5e64:      	ldp	w21, w19, [x8]
    5e68:      	ldr	w22, [x8, #0x8]
    5e6c:      	ldur	x20, [x8, #0xc]
    5e70:      	mov	w8, #0xe                // =14
    5e74:      	blr	x8
    5e78:      	lsr	x8, x0, #32
    5e7c:      	add	x9, sp, #0x58
    5e80:      	add	x1, sp, #0x58
    5e84:      	str	w8, [sp, #0x58]
    5e88:      	mov	w8, #0x1                // =1
    5e8c:      	mov	x0, x24
    5e90:      	blr	x8
    5e94:      	cbz	x0, 0x5f14 <generic_fentry_process_filter+0x22d4>
    5e98:      	cmp	w21, #0x2
    5e9c:      	cbz	w22, 0x5eb8 <generic_fentry_process_filter+0x2278>
    5ea0:      	b.hi	0x5f14 <generic_fentry_process_filter+0x22d4>
    5ea4:      	ldr	x8, [sp, #0xe8]
    5ea8:      	ldr	w8, [x8, #0x44]
    5eac:      	cmp	w8, w22
    5eb0:      	b.ne	0x5ebc <generic_fentry_process_filter+0x227c>
    5eb4:      	b	0x5f14 <generic_fentry_process_filter+0x22d4>
    5eb8:      	b.hi	0x5f14 <generic_fentry_process_filter+0x22d4>
    5ebc:      	ldr	x8, [sp, #0xe8]
    5ec0:      	lsl	x10, x21, #3
    5ec4:      	add	x9, x8, #0x48
    5ec8:      	add	x8, x0, x21, lsl #3
    5ecc:      	ldr	x8, [x8, #0x50]
    5ed0:      	ldr	x9, [x9, x10]
    5ed4:      	eor	x10, x9, x8
    5ed8:      	tst	x10, x20
    5edc:      	b.eq	0x5eec <generic_fentry_process_filter+0x22ac>
    5ee0:      	cmp	w19, #0x5
    5ee4:      	b.eq	0x5efc <generic_fentry_process_filter+0x22bc>
    5ee8:      	b	0x5f14 <generic_fentry_process_filter+0x22d4>
    5eec:      	cmp	x8, x9
    5ef0:      	b.eq	0x5f14 <generic_fentry_process_filter+0x22d4>
    5ef4:      	cmp	w19, #0x6
    5ef8:      	b.ne	0x5f14 <generic_fentry_process_filter+0x22d4>
    5efc:      	ldr	x9, [sp, #0xe8]
    5f00:      	mov	w8, #0x1                // =1
    5f04:      	str	x8, [x9, #0x5ef0]
    5f08:      	b	0x5e28 <generic_fentry_process_filter+0x21e8>
    5f0c:      	mov	w9, #0x1                // =1
    5f10:      	str	x9, [x8]
    5f14:      	ldr	x9, [sp, #0xe8]
    5f18:      	ldr	x10, [sp, #0x28]
    5f1c:      	ldr	x8, [x9, #0x5eb8]
    5f20:      	add	x8, x8, #0x1
    5f24:      	cmp	x8, x10
    5f28:      	str	x8, [x9, #0x5eb8]
    5f2c:      	b.ls	0x5f8c <generic_fentry_process_filter+0x234c>
    5f30:      	ldr	x10, [sp, #0x48]
    5f34:      	ldr	w8, [x10]
    5f38:      	str	w8, [x9, #0x10]
    5f3c:      	ldr	x8, [x10, #0x8]
    5f40:      	str	x8, [x9, #0x18]
    5f44:      	ldp	x20, x8, [sp, #0x38]
    5f48:      	ldrb	w8, [x8]
    5f4c:      	cbz	w8, 0x5f6c <generic_fentry_process_filter+0x232c>
    5f50:      	adrp	x1, 0x5000 <generic_fentry_process_filter+0x13c0>
    5f54:      	mov	x8, xzr
    5f58:      	mov	w9, #0xc                // =12
    5f5c:      	ldr	x1, [x1]
    5f60:      	mov	x0, x20
    5f64:      	mov	w2, wzr
    5f68:      	blr	x9
    5f6c:      	ldp	x20, x19, [sp, #0x120]
    5f70:      	mov	w0, wzr
    5f74:      	ldr	x29, [sp, #0xe0]
    5f78:      	ldp	x22, x21, [sp, #0x110]
    5f7c:      	ldp	x24, x23, [sp, #0x100]
    5f80:      	ldp	x30, x25, [sp, #0xf0]
    5f84:      	add	sp, sp, #0x130
    5f88:      	ret
    5f8c:      	adrp	x1, 0x5000 <generic_fentry_process_filter+0x13c0>
    5f90:      	mov	w8, #0x2                // =2
    5f94:      	mov	w9, #0xc                // =12
    5f98:      	ldr	x1, [x1]
    5f9c:      	ldr	x0, [sp, #0x38]
    5fa0:      	mov	w2, #0x2                // =2
    5fa4:      	b	0x5f68 <generic_fentry_process_filter+0x2328>
    5fa8:      	nop
    5fac:      	nop

0000000000005fb0 <generic_fentry_filter_arg>:
    5fb0:      	sub	sp, sp, #0xf0
    5fb4:      	str	x29, [sp, #0xa0]
    5fb8:      	stp	x30, x25, [sp, #0xb0]
    5fbc:      	stp	x24, x23, [sp, #0xc0]
    5fc0:      	stp	x22, x21, [sp, #0xd0]
    5fc4:      	stp	x20, x19, [sp, #0xe0]
    5fc8:      	mov	x19, x0
    5fcc:      	str	wzr, [sp, #0xa8]
    5fd0:      	adrp	x0, 0x5000 <generic_fentry_process_filter+0x13c0>
    5fd4:      	mov	w8, #0x1                // =1
    5fd8:      	ldr	x0, [x0]
    5fdc:      	add	x9, sp, #0xa8
    5fe0:      	add	x1, sp, #0xa8
    5fe4:      	blr	x8
    5fe8:      	cbz	x0, 0x6158 <generic_fentry_filter_arg+0x1a8>
    5fec:      	mov	w8, #0x5ec1             // =24257
    5ff0:      	mov	x20, x0
    5ff4:      	add	x22, x0, x8
    5ff8:      	mov	w8, #0x5ef8             // =24312
    5ffc:      	add	x1, x0, x8
    6000:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0x50>
    6004:      	ldur	w23, [x22, #0x3f]
    6008:      	mov	w8, #0x1                // =1
    600c:      	ldr	x0, [x0]
    6010:      	blr	x8
    6014:      	cbz	x0, 0x613c <generic_fentry_filter_arg+0x18c>
    6018:      	ldrb	w8, [x22, #0x1f]
    601c:      	cbz	w8, 0x613c <generic_fentry_filter_arg+0x18c>
    6020:      	and	x8, x23, #0x7
    6024:      	mov	w10, #0x5ec1            // =24257
    6028:      	stp	x23, x22, [sp, #0x50]
    602c:      	add	x9, x20, x8
    6030:      	ldrb	w9, [x9, x10]
    6034:      	cbz	w9, 0x60ac <generic_fentry_filter_arg+0xfc>
    6038:      	lsl	w8, w8, #2
    603c:      	mov	x21, x0
    6040:      	add	x8, x8, #0x4
    6044:      	ldr	w9, [x8, x0]
    6048:      	add	x8, x8, x9
    604c:      	add	x8, x8, #0x4
    6050:      	and	x9, x8, #0x3ff
    6054:      	ldr	w9, [x9, x0]
    6058:      	add	x8, x8, x9
    605c:      	and	x9, x8, #0x3ff
    6060:      	ldr	w9, [x9, x0]
    6064:      	add	x8, x8, x9
    6068:      	and	x9, x8, #0x3ff
    606c:      	ldr	w9, [x9, x0]
    6070:      	add	x8, x8, x9
    6074:      	and	x9, x8, #0x3ff
    6078:      	ldr	w9, [x9, x0]
    607c:      	add	x8, x8, x9
    6080:      	and	x9, x8, #0x3ff
    6084:      	ldr	w9, [x9, x0]
    6088:      	add	x16, x8, x9
    608c:      	and	x15, x16, #0x3ff
    6090:      	add	x17, x0, x15
    6094:      	ldr	w8, [x17]
    6098:      	cmp	w8, #0x19
    609c:      	b.hs	0x6100 <generic_fentry_filter_arg+0x150>
    60a0:      	cmp	w15, #0x1
    60a4:      	b.eq	0x613c <generic_fentry_filter_arg+0x18c>
    60a8:      	cbnz	w15, 0x6118 <generic_fentry_filter_arg+0x168>
    60ac:      	ldr	x8, [sp, #0x50]
    60b0:      	cmp	w8, #0x1
    60b4:      	b.gt	0x60d4 <generic_fentry_filter_arg+0x124>
    60b8:      	ldr	x9, [sp, #0x58]
    60bc:      	cmn	w8, #0x1
    60c0:      	b.eq	0x6178 <generic_fentry_filter_arg+0x1c8>
    60c4:      	cbz	w8, 0x6188 <generic_fentry_filter_arg+0x1d8>
    60c8:      	cmp	w8, #0x1
    60cc:      	b.eq	0x6198 <generic_fentry_filter_arg+0x1e8>
    60d0:      	b	0x60f0 <generic_fentry_filter_arg+0x140>
    60d4:      	ldr	x9, [sp, #0x58]
    60d8:      	cmp	w8, #0x2
    60dc:      	b.eq	0x61a8 <generic_fentry_filter_arg+0x1f8>
    60e0:      	cmp	w8, #0x3
    60e4:      	b.eq	0x61b8 <generic_fentry_filter_arg+0x208>
    60e8:      	cmp	w8, #0x4
    60ec:      	b.eq	0x61c8 <generic_fentry_filter_arg+0x218>
    60f0:      	cmp	w8, #0x4
    60f4:      	b.gt	0x61f4 <generic_fentry_filter_arg+0x244>
    60f8:      	add	w8, w8, #0x1
    60fc:      	b	0x61d4 <generic_fentry_filter_arg+0x224>
    6100:      	mov	x24, xzr
    6104:      	mov	w2, #0x5ea0             // =24224
    6108:      	mov	w12, #0x1               // =1
    610c:      	stp	x19, x17, [sp, #0x30]
    6110:      	stp	x16, x15, [sp, #0x40]
    6114:      	b	0x6254 <generic_fentry_filter_arg+0x2a4>
    6118:      	ldr	x8, [sp, #0x58]
    611c:      	adrp	x1, 0x6000 <generic_fentry_filter_arg+0x50>
    6120:      	mov	w9, #0xc                // =12
    6124:      	mov	x0, x19
    6128:      	stur	w15, [x8, #0x43]
    612c:      	mov	w8, #0x4                // =4
    6130:      	mov	w2, #0x4                // =4
    6134:      	ldr	x1, [x1]
    6138:      	blr	x9
    613c:      	adrp	x1, 0x6000 <generic_fentry_filter_arg+0x50>
    6140:      	mov	w8, #0x5                // =5
    6144:      	mov	w9, #0xc                // =12
    6148:      	ldr	x1, [x1]
    614c:      	mov	x0, x19
    6150:      	mov	w2, #0x5                // =5
    6154:      	blr	x9
    6158:      	ldp	x20, x19, [sp, #0xe0]
    615c:      	mov	w0, wzr
    6160:      	ldr	x29, [sp, #0xa0]
    6164:      	ldp	x22, x21, [sp, #0xd0]
    6168:      	ldp	x24, x23, [sp, #0xc0]
    616c:      	ldp	x30, x25, [sp, #0xb0]
    6170:      	add	sp, sp, #0xf0
    6174:      	ret
    6178:      	ldrb	w8, [x9]
    617c:      	cbz	w8, 0x6188 <generic_fentry_filter_arg+0x1d8>
    6180:      	mov	w8, wzr
    6184:      	b	0x61d4 <generic_fentry_filter_arg+0x224>
    6188:      	ldrb	w8, [x9, #0x1]
    618c:      	cbz	w8, 0x6198 <generic_fentry_filter_arg+0x1e8>
    6190:      	mov	w8, #0x1                // =1
    6194:      	b	0x61d4 <generic_fentry_filter_arg+0x224>
    6198:      	ldrb	w8, [x9, #0x2]
    619c:      	cbz	w8, 0x61a8 <generic_fentry_filter_arg+0x1f8>
    61a0:      	mov	w8, #0x2                // =2
    61a4:      	b	0x61d4 <generic_fentry_filter_arg+0x224>
    61a8:      	ldrb	w8, [x9, #0x3]
    61ac:      	cbz	w8, 0x61b8 <generic_fentry_filter_arg+0x208>
    61b0:      	mov	w8, #0x3                // =3
    61b4:      	b	0x61d4 <generic_fentry_filter_arg+0x224>
    61b8:      	ldrb	w8, [x9, #0x4]
    61bc:      	cbz	w8, 0x61c8 <generic_fentry_filter_arg+0x218>
    61c0:      	mov	w8, #0x4                // =4
    61c4:      	b	0x61d4 <generic_fentry_filter_arg+0x224>
    61c8:      	ldrb	w8, [x9, #0x5]
    61cc:      	cbz	w8, 0x61f4 <generic_fentry_filter_arg+0x244>
    61d0:      	mov	w8, #0x5                // =5
    61d4:      	stur	w8, [x9, #0x3f]
    61d8:      	adrp	x1, 0x6000 <generic_fentry_filter_arg+0x50>
    61dc:      	mov	w8, #0x3                // =3
    61e0:      	mov	w9, #0xc                // =12
    61e4:      	ldr	x1, [x1]
    61e8:      	mov	x0, x19
    61ec:      	mov	w2, #0x3                // =3
    61f0:      	blr	x9
    61f4:      	ldr	x19, [x20, #0x60]
    61f8:      	mov	w8, #0xe                // =14
    61fc:      	blr	x8
    6200:      	stp	x19, x0, [sp, #0x60]
    6204:      	adrp	x19, 0x6000 <generic_fentry_filter_arg+0x50>
    6208:      	mov	w8, #0x1                // =1
    620c:      	add	x9, sp, #0x60
    6210:      	add	x1, sp, #0x60
    6214:      	ldr	x19, [x19]
    6218:      	mov	x0, x19
    621c:      	blr	x8
    6220:      	cbz	x0, 0x6158 <generic_fentry_filter_arg+0x1a8>
    6224:      	mov	w8, #0x3                // =3
    6228:      	add	x9, sp, #0x60
    622c:      	add	x1, sp, #0x60
    6230:      	mov	x0, x19
    6234:      	blr	x8
    6238:      	b	0x6158 <generic_fentry_filter_arg+0x1a8>
    623c:      	cmp	w8, #0x3
    6240:      	cset	w22, eq
    6244:      	cbz	x22, 0x60ac <generic_fentry_filter_arg+0xfc>
    6248:      	add	x24, x24, #0x1
    624c:      	cmp	x24, #0x5
    6250:      	b.eq	0x60a0 <generic_fentry_filter_arg+0xf0>
    6254:      	add	x8, x17, x24, lsl #2
    6258:      	ldr	w8, [x8, #0x4]
    625c:      	tst	w8, #0x3ff
    6260:      	b.eq	0x60a0 <generic_fentry_filter_arg+0xf0>
    6264:      	add	w8, w16, w8
    6268:      	and	x8, x8, #0x3ff
    626c:      	add	x23, x21, x8
    6270:      	ldr	w8, [x23, #0x4]
    6274:      	cmp	w8, #0x23
    6278:      	b.eq	0x60ac <generic_fentry_filter_arg+0xfc>
    627c:      	ldr	w9, [x23]
    6280:      	cmp	w9, #0x4
    6284:      	b.hi	0x60ac <generic_fentry_filter_arg+0xfc>
    6288:      	add	x10, x20, x9, lsl #2
    628c:      	ldr	w10, [x10, x2]
    6290:      	cbnz	w10, 0x60ac <generic_fentry_filter_arg+0xfc>
    6294:      	add	x9, x20, x9, lsl #3
    6298:      	ldr	x9, [x9, #0x5e78]
    629c:      	and	x9, x9, #0x7ff
    62a0:      	add	x9, x20, x9
    62a4:      	add	x25, x9, #0x90
    62a8:      	ldr	w9, [x23, #0xc]
    62ac:      	cmp	w9, #0x1b
    62b0:      	b.le	0x62d4 <generic_fentry_filter_arg+0x324>
    62b4:      	cmp	w9, #0x25
    62b8:      	b.gt	0x6304 <generic_fentry_filter_arg+0x354>
    62bc:      	sub	w10, w9, #0x1c
    62c0:      	cmp	w10, #0x9
    62c4:      	b.lo	0x6348 <generic_fentry_filter_arg+0x398>
    62c8:      	cmp	w9, #0x25
    62cc:      	b.eq	0x64fc <generic_fentry_filter_arg+0x54c>
    62d0:      	b	0x6248 <generic_fentry_filter_arg+0x298>
    62d4:      	cmp	w9, #0x9
    62d8:      	b.le	0x6328 <generic_fentry_filter_arg+0x378>
    62dc:      	sub	w10, w9, #0xa
    62e0:      	cmp	w10, #0x4
    62e4:      	b.lo	0x6348 <generic_fentry_filter_arg+0x398>
    62e8:      	sub	w10, w9, #0xf
    62ec:      	cmp	w10, #0x2
    62f0:      	b.lo	0x64fc <generic_fentry_filter_arg+0x54c>
    62f4:      	cmp	w9, #0x11
    62f8:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    62fc:      	add	x25, x25, #0x4
    6300:      	b	0x64fc <generic_fentry_filter_arg+0x54c>
    6304:      	cmp	w9, #0x29
    6308:      	b.gt	0x6474 <generic_fentry_filter_arg+0x4c4>
    630c:      	sub	w10, w9, #0x26
    6310:      	cmp	w10, #0x2
    6314:      	b.lo	0x641c <generic_fentry_filter_arg+0x46c>
    6318:      	sub	w10, w9, #0x28
    631c:      	cmp	w10, #0x2
    6320:      	b.lo	0x63f4 <generic_fentry_filter_arg+0x444>
    6324:      	b	0x6248 <generic_fentry_filter_arg+0x298>
    6328:      	cmp	w9, #0x4
    632c:      	b.gt	0x63dc <generic_fentry_filter_arg+0x42c>
    6330:      	cmp	w9, #0x1
    6334:      	b.eq	0x6348 <generic_fentry_filter_arg+0x398>
    6338:      	cmp	w9, #0x2
    633c:      	b.eq	0x692c <generic_fentry_filter_arg+0x97c>
    6340:      	cmp	w9, #0x4
    6344:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    6348:      	cmp	w9, #0xb
    634c:      	b.le	0x63bc <generic_fentry_filter_arg+0x40c>
    6350:      	cmp	w9, #0x24
    6354:      	b.hi	0x65b8 <generic_fentry_filter_arg+0x608>
    6358:      	lsl	x10, x12, x9
    635c:      	tst	x10, #0x1e00000000
    6360:      	b.ne	0x644c <generic_fentry_filter_arg+0x49c>
    6364:      	lsl	x10, x12, x9
    6368:      	tst	x10, #0x60000000
    636c:      	b.ne	0x6774 <generic_fentry_filter_arg+0x7c4>
    6370:      	lsl	x10, x12, x9
    6374:      	tst	x10, #0x180000000
    6378:      	b.eq	0x65b8 <generic_fentry_filter_arg+0x608>
    637c:      	cmp	w8, #0x20
    6380:      	b.hi	0x60ac <generic_fentry_filter_arg+0xfc>
    6384:      	lsl	x9, x12, x8
    6388:      	mov	w10, #0x101e            // =4126
    638c:      	tst	x9, x10
    6390:      	b.eq	0x6db4 <generic_fentry_filter_arg+0xe04>
    6394:      	ldr	w9, [x23, #0x10]
    6398:      	cmp	w8, #0x2
    639c:      	b.le	0x7350 <generic_fentry_filter_arg+0x13a0>
    63a0:      	sub	w10, w8, #0x3
    63a4:      	cmp	w10, #0x2
    63a8:      	b.hs	0x7904 <generic_fentry_filter_arg+0x1954>
    63ac:      	ldrb	w10, [x25]
    63b0:      	cmp	w9, w10
    63b4:      	b.eq	0x623c <generic_fentry_filter_arg+0x28c>
    63b8:      	b	0x7a8c <generic_fentry_filter_arg+0x1adc>
    63bc:      	sub	w10, w9, #0xa
    63c0:      	cmp	w10, #0x2
    63c4:      	b.lo	0x69a0 <generic_fentry_filter_arg+0x9f0>
    63c8:      	cmp	w9, #0x1
    63cc:      	b.eq	0x65c4 <generic_fentry_filter_arg+0x614>
    63d0:      	cmp	w9, #0x4
    63d4:      	b.eq	0x65c4 <generic_fentry_filter_arg+0x614>
    63d8:      	b	0x6248 <generic_fentry_filter_arg+0x298>
    63dc:      	cmp	w9, #0x5
    63e0:      	b.eq	0x63f4 <generic_fentry_filter_arg+0x444>
    63e4:      	cmp	w9, #0x6
    63e8:      	b.eq	0x641c <generic_fentry_filter_arg+0x46c>
    63ec:      	cmp	w9, #0x7
    63f0:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    63f4:      	mov	x22, xzr
    63f8:      	cmp	w9, #0x27
    63fc:      	stp	xzr, xzr, [sp, #0x78]
    6400:      	str	xzr, [sp, #0x60]
    6404:      	stp	xzr, xzr, [sp, #0x68]
    6408:      	b.gt	0x6604 <generic_fentry_filter_arg+0x654>
    640c:      	cmp	w9, #0x5
    6410:      	b.eq	0x6ac0 <generic_fentry_filter_arg+0xb10>
    6414:      	cmp	w9, #0x7
    6418:      	b	0x6610 <generic_fentry_filter_arg+0x660>
    641c:      	ldr	w29, [x25], #0x4
    6420:      	mov	x22, xzr
    6424:      	cmp	w8, #0x19
    6428:      	b.gt	0x6670 <generic_fentry_filter_arg+0x6c0>
    642c:      	sub	w9, w8, #0x3
    6430:      	cmp	w9, #0x2
    6434:      	b.lo	0x6d44 <generic_fentry_filter_arg+0xd94>
    6438:      	cmp	w8, #0x8
    643c:      	b.eq	0x6cac <generic_fentry_filter_arg+0xcfc>
    6440:      	cmp	w8, #0x9
    6444:      	b.eq	0x6688 <generic_fentry_filter_arg+0x6d8>
    6448:      	b	0x7270 <generic_fentry_filter_arg+0x12c0>
    644c:      	cmp	w8, #0x9
    6450:      	b.le	0x691c <generic_fentry_filter_arg+0x96c>
    6454:      	cmp	w8, #0x1d
    6458:      	b.gt	0x6c6c <generic_fentry_filter_arg+0xcbc>
    645c:      	sub	w10, w8, #0xa
    6460:      	cmp	w10, #0x2
    6464:      	b.lo	0x6a2c <generic_fentry_filter_arg+0xa7c>
    6468:      	cmp	w8, #0xc
    646c:      	b.eq	0x69b8 <generic_fentry_filter_arg+0xa08>
    6470:      	b	0x60ac <generic_fentry_filter_arg+0xfc>
    6474:      	cmp	w9, #0x2a
    6478:      	b.eq	0x64fc <generic_fentry_filter_arg+0x54c>
    647c:      	cmp	w9, #0x2c
    6480:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    6484:      	ldrb	w29, [x25, #0x3]
    6488:      	add	x10, x25, #0x4
    648c:      	cmp	w8, #0x19
    6490:      	b.gt	0x7040 <generic_fentry_filter_arg+0x1090>
    6494:      	sub	w9, w8, #0x3
    6498:      	cmp	w9, #0x2
    649c:      	b.hs	0x75a4 <generic_fentry_filter_arg+0x15f4>
    64a0:      	cmp	w29, #0x90
    64a4:      	str	wzr, [sp, #0x88]
    64a8:      	b.hi	0x7640 <generic_fentry_filter_arg+0x1690>
    64ac:      	mov	w8, #0xaaab             // =43691
    64b0:      	mov	w9, #0x18               // =24
    64b4:      	movk	w8, #0xaaa, lsl #16
    64b8:      	umull	x8, w29, w8
    64bc:      	lsr	x8, x8, #32
    64c0:      	msub	w8, w8, w9, w29
    64c4:      	cbz	w29, 0x64d0 <generic_fentry_filter_arg+0x520>
    64c8:      	mov	w13, w29
    64cc:      	cbz	w8, 0x64e4 <generic_fentry_filter_arg+0x534>
    64d0:      	sub	w8, w29, w8, uxtb
    64d4:      	add	w9, w8, #0x18
    64d8:      	cmp	w8, #0x78
    64dc:      	and	w13, w9, #0xffff
    64e0:      	b.hi	0x7644 <generic_fentry_filter_arg+0x1694>
    64e4:      	and	w8, w13, #0xff
    64e8:      	mov	w9, #0xab               // =171
    64ec:      	mul	w8, w8, w9
    64f0:      	lsr	w8, w8, #12
    64f4:      	sub	w11, w8, #0x1
    64f8:      	b	0x8038 <generic_fentry_filter_arg+0x2088>
    64fc:      	ldr	w29, [x25]
    6500:      	and	w9, w8, #0xfffffffe
    6504:      	cmp	w9, #0x24
    6508:      	b.eq	0x6510 <generic_fentry_filter_arg+0x560>
    650c:      	cbz	w29, 0x60ac <generic_fentry_filter_arg+0xfc>
    6510:      	cmp	w8, #0x25
    6514:      	b.hi	0x6754 <generic_fentry_filter_arg+0x7a4>
    6518:      	mov	w10, #0x100             // =256
    651c:      	lsl	x9, x12, x8
    6520:      	movk	w10, #0x400, lsl #16
    6524:      	tst	x9, x10
    6528:      	b.ne	0x6884 <generic_fentry_filter_arg+0x8d4>
    652c:      	mov	w10, #0x200             // =512
    6530:      	lsl	x9, x12, x8
    6534:      	movk	w10, #0x800, lsl #16
    6538:      	tst	x9, x10
    653c:      	b.ne	0x67b4 <generic_fentry_filter_arg+0x804>
    6540:      	lsl	x9, x12, x8
    6544:      	tst	x9, #0x3000000000
    6548:      	b.eq	0x6754 <generic_fentry_filter_arg+0x7a4>
    654c:      	cmp	w29, #0x1, lsl #12      // =0x1000
    6550:      	strh	wzr, [sp, #0x60]
    6554:      	b.hi	0x676c <generic_fentry_filter_arg+0x7bc>
    6558:      	add	x8, x25, #0x4
    655c:      	mov	w10, #0x4               // =4
    6560:      	add	x11, sp, #0x60
    6564:      	mov	w12, #0x2               // =2
    6568:      	add	x0, sp, #0x60
    656c:      	mov	w1, #0x2                // =2
    6570:      	add	x9, x8, x29
    6574:      	add	x9, x9, #0x4
    6578:      	ldr	w9, [x25]
    657c:      	add	x8, x8, x9
    6580:      	add	x2, x8, #0x4
    6584:      	blr	x10
    6588:      	ldr	w9, [x23, #0x10]
    658c:      	cbz	w9, 0x8d90 <generic_fentry_filter_arg+0x2de0>
    6590:      	ldrh	w8, [sp, #0x60]
    6594:      	ldp	x16, x15, [sp, #0x40]
    6598:      	mov	w2, #0x5ea0             // =24224
    659c:      	mov	w12, #0x1               // =1
    65a0:      	and	w8, w8, #0xf000
    65a4:      	ldr	x17, [sp, #0x38]
    65a8:      	cmp	w9, w8
    65ac:      	b.ne	0x7934 <generic_fentry_filter_arg+0x1984>
    65b0:      	mov	w22, #0x1               // =1
    65b4:      	b	0x8da4 <generic_fentry_filter_arg+0x2df4>
    65b8:      	sub	w10, w9, #0xc
    65bc:      	cmp	w10, #0x2
    65c0:      	b.hs	0x6998 <generic_fentry_filter_arg+0x9e8>
    65c4:      	cmp	w8, #0x20
    65c8:      	b.hi	0x60ac <generic_fentry_filter_arg+0xfc>
    65cc:      	lsl	x10, x12, x8
    65d0:      	mov	w11, #0x101e            // =4126
    65d4:      	tst	x10, x11
    65d8:      	b.eq	0x661c <generic_fentry_filter_arg+0x66c>
    65dc:      	ldr	w10, [x23, #0x10]
    65e0:      	cmp	w8, #0x2
    65e4:      	b.le	0x6960 <generic_fentry_filter_arg+0x9b0>
    65e8:      	sub	w11, w8, #0x3
    65ec:      	cmp	w11, #0x2
    65f0:      	b.hs	0x6d9c <generic_fentry_filter_arg+0xdec>
    65f4:      	ldr	w11, [x25]
    65f8:      	cmp	w11, w10
    65fc:      	b.eq	0x623c <generic_fentry_filter_arg+0x28c>
    6600:      	b	0x7e60 <generic_fentry_filter_arg+0x1eb0>
    6604:      	cmp	w9, #0x28
    6608:      	b.eq	0x6ac8 <generic_fentry_filter_arg+0xb18>
    660c:      	cmp	w9, #0x29
    6610:      	mov	x10, x25
    6614:      	b.eq	0x6af0 <generic_fentry_filter_arg+0xb40>
    6618:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    661c:      	lsl	x10, x12, x8
    6620:      	tst	x10, #0xc00
    6624:      	b.ne	0x6a88 <generic_fentry_filter_arg+0xad8>
    6628:      	lsl	x10, x12, x8
    662c:      	tst	x10, #0x180000000
    6630:      	b.eq	0x60ac <generic_fentry_filter_arg+0xfc>
    6634:      	cmp	w8, #0x1f
    6638:      	b.ne	0x7010 <generic_fentry_filter_arg+0x1060>
    663c:      	ldp	w11, w10, [x23, #0x10]
    6640:      	cmp	w9, #0xc
    6644:      	b.hi	0x7b00 <generic_fentry_filter_arg+0x1b50>
    6648:      	lsl	w8, w12, w9
    664c:      	mov	w13, #0x1402            // =5122
    6650:      	tst	w8, w13
    6654:      	b.eq	0x7b00 <generic_fentry_filter_arg+0x1b50>
    6658:      	ldr	w8, [x25]
    665c:      	cmp	w11, w8
    6660:      	b.gt	0x7b14 <generic_fentry_filter_arg+0x1b64>
    6664:      	cmp	w8, w10
    6668:      	b.le	0x6248 <generic_fentry_filter_arg+0x298>
    666c:      	b	0x7b14 <generic_fentry_filter_arg+0x1b64>
    6670:      	cmp	w8, #0x20
    6674:      	b.gt	0x6b64 <generic_fentry_filter_arg+0xbb4>
    6678:      	cmp	w8, #0x1a
    667c:      	b.eq	0x6cac <generic_fentry_filter_arg+0xcfc>
    6680:      	cmp	w8, #0x1b
    6684:      	b.ne	0x7270 <generic_fentry_filter_arg+0x12c0>
    6688:      	ldr	w8, [x23, #0x10]
    668c:      	str	wzr, [sp, #0x88]
    6690:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0x50>
    6694:      	add	x9, sp, #0x60
    6698:      	add	x1, sp, #0x60
    669c:      	str	w8, [sp, #0x60]
    66a0:      	mov	w8, #0x1                // =1
    66a4:      	ldr	x0, [x0]
    66a8:      	blr	x8
    66ac:      	mov	x22, xzr
    66b0:      	cbz	w29, 0x7260 <generic_fentry_filter_arg+0x12b0>
    66b4:      	cbz	x0, 0x7260 <generic_fentry_filter_arg+0x12b0>
    66b8:      	mov	x19, x0
    66bc:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0x50>
    66c0:      	mov	w8, #0x1                // =1
    66c4:      	ldr	x0, [x0]
    66c8:      	add	x9, sp, #0x88
    66cc:      	add	x1, sp, #0x88
    66d0:      	blr	x8
    66d4:      	cbz	x0, 0x7258 <generic_fentry_filter_arg+0x12a8>
    66d8:      	cmp	w29, #0x7f
    66dc:      	mov	w9, #0x7f               // =127
    66e0:      	mov	w11, #0x1               // =1
    66e4:      	mov	x1, x0
    66e8:      	mov	x8, xzr
    66ec:      	sub	w12, w29, #0x2
    66f0:      	sub	w13, w29, #0x1
    66f4:      	csel	w9, w29, w9, lo
    66f8:      	sub	x11, x11, x29
    66fc:      	lsl	w10, w9, #3
    6700:      	mov	x9, x0
    6704:      	str	w10, [x9], #0x5
    6708:      	neg	x10, x29
    670c:      	add	w14, w13, w8
    6710:      	cmp	x11, x8
    6714:      	and	x14, x14, #0xfff
    6718:      	ldrb	w14, [x25, x14]
    671c:      	sturb	w14, [x9, #-0x1]
    6720:      	b.eq	0x6748 <generic_fentry_filter_arg+0x798>
    6724:      	cmn	x8, #0x7e
    6728:      	b.eq	0x6748 <generic_fentry_filter_arg+0x798>
    672c:      	add	w14, w12, w8
    6730:      	sub	x8, x8, #0x2
    6734:      	and	x14, x14, #0xfff
    6738:      	cmp	x10, x8
    673c:      	ldrb	w14, [x25, x14]
    6740:      	strb	w14, [x9], #0x2
    6744:      	b.ne	0x670c <generic_fentry_filter_arg+0x75c>
    6748:      	mov	w8, #0x1                // =1
    674c:      	mov	x0, x19
    6750:      	b	0x6d34 <generic_fentry_filter_arg+0xd84>
    6754:      	sub	w8, w8, #0x3
    6758:      	cmp	w8, #0x2
    675c:      	b.hs	0x676c <generic_fentry_filter_arg+0x7bc>
    6760:      	cmp	w29, #0x1, lsl #12      // =0x1000
    6764:      	str	wzr, [sp, #0x88]
    6768:      	b.ls	0x6ea4 <generic_fentry_filter_arg+0xef4>
    676c:      	mov	x22, xzr
    6770:      	b	0x8da4 <generic_fentry_filter_arg+0x2df4>
    6774:      	cmp	w8, #0x20
    6778:      	b.hi	0x60ac <generic_fentry_filter_arg+0xfc>
    677c:      	lsl	x9, x12, x8
    6780:      	mov	w10, #0x101e            // =4126
    6784:      	tst	x9, x10
    6788:      	b.eq	0x6de0 <generic_fentry_filter_arg+0xe30>
    678c:      	ldr	w9, [x23, #0x10]
    6790:      	cmp	w8, #0x2
    6794:      	b.le	0x7370 <generic_fentry_filter_arg+0x13c0>
    6798:      	sub	w10, w8, #0x3
    679c:      	cmp	w10, #0x2
    67a0:      	b.hs	0x791c <generic_fentry_filter_arg+0x196c>
    67a4:      	ldrh	w10, [x25]
    67a8:      	cmp	w9, w10
    67ac:      	b.eq	0x623c <generic_fentry_filter_arg+0x28c>
    67b0:      	b	0x7acc <generic_fentry_filter_arg+0x1b1c>
    67b4:      	ldr	w8, [x23, #0x10]
    67b8:      	str	wzr, [sp, #0x88]
    67bc:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0x50>
    67c0:      	add	x9, sp, #0x60
    67c4:      	add	x1, sp, #0x60
    67c8:      	str	w8, [sp, #0x60]
    67cc:      	mov	w8, #0x1                // =1
    67d0:      	ldr	x0, [x0]
    67d4:      	blr	x8
    67d8:      	mov	x22, xzr
    67dc:      	cbz	w29, 0x8d94 <generic_fentry_filter_arg+0x2de4>
    67e0:      	cbz	x0, 0x8d94 <generic_fentry_filter_arg+0x2de4>
    67e4:      	mov	x19, x0
    67e8:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0x50>
    67ec:      	mov	w8, #0x1                // =1
    67f0:      	ldr	x0, [x0]
    67f4:      	add	x9, sp, #0x88
    67f8:      	add	x1, sp, #0x88
    67fc:      	blr	x8
    6800:      	cbz	x0, 0x7984 <generic_fentry_filter_arg+0x19d4>
    6804:      	cmp	w29, #0x7f
    6808:      	mov	w10, #0x7f              // =127
    680c:      	mov	w12, #0x1               // =1
    6810:      	mov	x1, x0
    6814:      	mov	x8, xzr
    6818:      	add	x9, x25, #0x4
    681c:      	sub	w13, w29, #0x2
    6820:      	sub	w14, w29, #0x1
    6824:      	csel	w10, w29, w10, lo
    6828:      	sub	x12, x12, x29
    682c:      	lsl	w11, w10, #3
    6830:      	mov	x10, x0
    6834:      	str	w11, [x10], #0x5
    6838:      	neg	x11, x29
    683c:      	add	w15, w14, w8
    6840:      	cmp	x12, x8
    6844:      	and	x15, x15, #0xfff
    6848:      	ldrb	w15, [x9, x15]
    684c:      	sturb	w15, [x10, #-0x1]
    6850:      	b.eq	0x6878 <generic_fentry_filter_arg+0x8c8>
    6854:      	cmn	x8, #0x7e
    6858:      	b.eq	0x6878 <generic_fentry_filter_arg+0x8c8>
    685c:      	add	w15, w13, w8
    6860:      	sub	x8, x8, #0x2
    6864:      	and	x15, x15, #0xfff
    6868:      	cmp	x11, x8
    686c:      	ldrb	w15, [x9, x15]
    6870:      	strb	w15, [x10], #0x2
    6874:      	b.ne	0x683c <generic_fentry_filter_arg+0x88c>
    6878:      	mov	w8, #0x1                // =1
    687c:      	mov	x0, x19
    6880:      	b	0x690c <generic_fentry_filter_arg+0x95c>
    6884:      	ldr	w8, [x23, #0x10]
    6888:      	str	wzr, [sp, #0x88]
    688c:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0x50>
    6890:      	add	x9, sp, #0x60
    6894:      	add	x1, sp, #0x60
    6898:      	str	w8, [sp, #0x60]
    689c:      	mov	w8, #0x1                // =1
    68a0:      	ldr	x0, [x0]
    68a4:      	blr	x8
    68a8:      	mov	x22, xzr
    68ac:      	cbz	w29, 0x8d94 <generic_fentry_filter_arg+0x2de4>
    68b0:      	cbz	x0, 0x8d94 <generic_fentry_filter_arg+0x2de4>
    68b4:      	mov	x19, x0
    68b8:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0x50>
    68bc:      	mov	w8, #0x1                // =1
    68c0:      	ldr	x0, [x0]
    68c4:      	add	x9, sp, #0x88
    68c8:      	add	x1, sp, #0x88
    68cc:      	blr	x8
    68d0:      	cbz	x0, 0x7984 <generic_fentry_filter_arg+0x19d4>
    68d4:      	cmp	w29, #0xff
    68d8:      	mov	w8, #0xff               // =255
    68dc:      	add	x2, x25, #0x4
    68e0:      	mov	x22, x0
    68e4:      	csel	w1, w29, w8, lo
    68e8:      	mov	x8, x0
    68ec:      	lsl	w9, w1, #3
    68f0:      	str	w9, [x8], #0x4
    68f4:      	mov	w9, #0x4                // =4
    68f8:      	mov	x0, x8
    68fc:      	blr	x9
    6900:      	mov	w8, #0x1                // =1
    6904:      	mov	x0, x19
    6908:      	mov	x1, x22
    690c:      	blr	x8
    6910:      	cmp	x0, #0x0
    6914:      	cset	w22, ne
    6918:      	b	0x7988 <generic_fentry_filter_arg+0x19d8>
    691c:      	sub	w10, w8, #0x1
    6920:      	cmp	w10, #0x4
    6924:      	b.lo	0x69b8 <generic_fentry_filter_arg+0xa08>
    6928:      	b	0x60ac <generic_fentry_filter_arg+0xfc>
    692c:      	add	x29, x25, #0x8
    6930:      	ldr	w25, [x25, #0x4]
    6934:      	mov	x22, xzr
    6938:      	cmp	w8, #0x19
    693c:      	b.gt	0x6f14 <generic_fentry_filter_arg+0xf64>
    6940:      	sub	w9, w8, #0x3
    6944:      	cmp	w9, #0x2
    6948:      	b.lo	0x7730 <generic_fentry_filter_arg+0x1780>
    694c:      	cmp	w8, #0x8
    6950:      	b.eq	0x76a4 <generic_fentry_filter_arg+0x16f4>
    6954:      	cmp	w8, #0x9
    6958:      	b.eq	0x6f2c <generic_fentry_filter_arg+0xf7c>
    695c:      	b	0x9334 <generic_fentry_filter_arg+0x3384>
    6960:      	cmp	w8, #0x1
    6964:      	b.eq	0x717c <generic_fentry_filter_arg+0x11cc>
    6968:      	cmp	w8, #0x2
    696c:      	b.ne	0x7e60 <generic_fentry_filter_arg+0x1eb0>
    6970:      	cmp	w9, #0xc
    6974:      	b.hi	0x7e54 <generic_fentry_filter_arg+0x1ea4>
    6978:      	lsl	w11, w12, w9
    697c:      	mov	w13, #0x1402            // =5122
    6980:      	tst	w11, w13
    6984:      	b.eq	0x7e54 <generic_fentry_filter_arg+0x1ea4>
    6988:      	ldr	w11, [x25]
    698c:      	cmp	w11, w10
    6990:      	b.lt	0x6248 <generic_fentry_filter_arg+0x298>
    6994:      	b	0x7e60 <generic_fentry_filter_arg+0x1eb0>
    6998:      	cmp	w9, #0x1c
    699c:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    69a0:      	cmp	w8, #0x20
    69a4:      	b.hi	0x60ac <generic_fentry_filter_arg+0xfc>
    69a8:      	lsl	x10, x12, x8
    69ac:      	mov	w11, #0x101e            // =4126
    69b0:      	tst	x10, x11
    69b4:      	b.eq	0x69e0 <generic_fentry_filter_arg+0xa30>
    69b8:      	ldr	x10, [x23, #0x10]
    69bc:      	cmp	w8, #0x2
    69c0:      	b.le	0x69fc <generic_fentry_filter_arg+0xa4c>
    69c4:      	sub	w11, w8, #0x3
    69c8:      	cmp	w11, #0x2
    69cc:      	b.hs	0x6c54 <generic_fentry_filter_arg+0xca4>
    69d0:      	ldr	x11, [x25]
    69d4:      	cmp	x11, x10
    69d8:      	b.eq	0x623c <generic_fentry_filter_arg+0x28c>
    69dc:      	b	0x7878 <generic_fentry_filter_arg+0x18c8>
    69e0:      	lsl	x10, x12, x8
    69e4:      	tst	x10, #0xc00
    69e8:      	b.ne	0x6a2c <generic_fentry_filter_arg+0xa7c>
    69ec:      	lsl	x10, x12, x8
    69f0:      	tst	x10, #0x180000000
    69f4:      	b.ne	0x6c78 <generic_fentry_filter_arg+0xcc8>
    69f8:      	b	0x60ac <generic_fentry_filter_arg+0xfc>
    69fc:      	cmp	w8, #0x1
    6a00:      	b.eq	0x6e84 <generic_fentry_filter_arg+0xed4>
    6a04:      	cmp	w8, #0x2
    6a08:      	b.ne	0x7878 <generic_fentry_filter_arg+0x18c8>
    6a0c:      	cmp	w9, #0xc
    6a10:      	b.eq	0x6a1c <generic_fentry_filter_arg+0xa6c>
    6a14:      	cmp	w9, #0xa
    6a18:      	b.ne	0x786c <generic_fentry_filter_arg+0x18bc>
    6a1c:      	ldr	x11, [x25]
    6a20:      	cmp	x11, x10
    6a24:      	b.lt	0x6248 <generic_fentry_filter_arg+0x298>
    6a28:      	b	0x7878 <generic_fentry_filter_arg+0x18c8>
    6a2c:      	ldrb	w8, [x23, #0x10]
    6a30:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0x50>
    6a34:      	add	x9, sp, #0x88
    6a38:      	add	x1, sp, #0x88
    6a3c:      	str	w8, [sp, #0x88]
    6a40:      	mov	w8, #0x1                // =1
    6a44:      	ldr	x0, [x0]
    6a48:      	blr	x8
    6a4c:      	cbz	x0, 0x6ff8 <generic_fentry_filter_arg+0x1048>
    6a50:      	ldr	x8, [x25]
    6a54:      	add	x9, sp, #0x60
    6a58:      	add	x1, sp, #0x60
    6a5c:      	str	x8, [sp, #0x60]
    6a60:      	mov	w8, #0x1                // =1
    6a64:      	blr	x8
    6a68:      	ldr	w8, [x23, #0x4]
    6a6c:      	cmp	w8, #0xb
    6a70:      	b.eq	0x7424 <generic_fentry_filter_arg+0x1474>
    6a74:      	cmp	w8, #0xa
    6a78:      	mov	w12, #0x1               // =1
    6a7c:      	b.eq	0x74c4 <generic_fentry_filter_arg+0x1514>
    6a80:      	mov	w8, wzr
    6a84:      	b	0x74cc <generic_fentry_filter_arg+0x151c>
    6a88:      	ldrb	w8, [x23, #0x10]
    6a8c:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0x50>
    6a90:      	add	x9, sp, #0x88
    6a94:      	add	x1, sp, #0x88
    6a98:      	str	w8, [sp, #0x88]
    6a9c:      	mov	w8, #0x1                // =1
    6aa0:      	ldr	x0, [x0]
    6aa4:      	blr	x8
    6aa8:      	cbz	x0, 0x7840 <generic_fentry_filter_arg+0x1890>
    6aac:      	ldr	w8, [x25]
    6ab0:      	add	x9, sp, #0x60
    6ab4:      	str	x8, [sp, #0x60]
    6ab8:      	mov	w8, #0x1                // =1
    6abc:      	b	0x73fc <generic_fentry_filter_arg+0x144c>
    6ac0:      	mov	x10, xzr
    6ac4:      	b	0x6af0 <generic_fentry_filter_arg+0xb40>
    6ac8:      	ldrh	w11, [x25]
    6acc:      	mov	x10, xzr
    6ad0:      	strh	w11, [sp, #0x86]
    6ad4:      	ldrh	w11, [x25, #0x2]
    6ad8:      	strh	w11, [sp, #0x80]
    6adc:      	ldr	x11, [x25, #0x8]
    6ae0:      	str	x11, [sp, #0x60]
    6ae4:      	ldr	x11, [x25, #0x10]
    6ae8:      	add	x25, sp, #0x60
    6aec:      	str	x11, [sp, #0x68]
    6af0:      	mov	x22, xzr
    6af4:      	cmp	w8, #0x13
    6af8:      	b.le	0x6b20 <generic_fentry_filter_arg+0xb70>
    6afc:      	cmp	w8, #0x17
    6b00:      	b.gt	0x6b48 <generic_fentry_filter_arg+0xb98>
    6b04:      	sub	w9, w8, #0x14
    6b08:      	cmp	w9, #0x2
    6b0c:      	b.lo	0x707c <generic_fentry_filter_arg+0x10cc>
    6b10:      	sub	w9, w8, #0x16
    6b14:      	cmp	w9, #0x2
    6b18:      	b.lo	0x7068 <generic_fentry_filter_arg+0x10b8>
    6b1c:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    6b20:      	cmp	w8, #0xf
    6b24:      	b.le	0x6d58 <generic_fentry_filter_arg+0xda8>
    6b28:      	cmp	w8, #0x11
    6b2c:      	b.gt	0x7058 <generic_fentry_filter_arg+0x10a8>
    6b30:      	cmp	w8, #0x10
    6b34:      	b.eq	0x7068 <generic_fentry_filter_arg+0x10b8>
    6b38:      	cmp	w8, #0x11
    6b3c:      	b.ne	0x6244 <generic_fentry_filter_arg+0x294>
    6b40:      	ldrh	w22, [x25, #0x24]
    6b44:      	b	0x77d4 <generic_fentry_filter_arg+0x1824>
    6b48:      	cmp	w8, #0x1b
    6b4c:      	b.gt	0x7090 <generic_fentry_filter_arg+0x10e0>
    6b50:      	cmp	w8, #0x18
    6b54:      	b.eq	0x70c0 <generic_fentry_filter_arg+0x1110>
    6b58:      	cmp	w8, #0x19
    6b5c:      	b.eq	0x70b4 <generic_fentry_filter_arg+0x1104>
    6b60:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    6b64:      	cmp	w8, #0x21
    6b68:      	b.eq	0x71a4 <generic_fentry_filter_arg+0x11f4>
    6b6c:      	cmp	w8, #0x22
    6b70:      	b.ne	0x7270 <generic_fentry_filter_arg+0x12c0>
    6b74:      	mov	x22, xzr
    6b78:      	mov	w19, wzr
    6b7c:      	add	x8, x23, #0x10
    6b80:      	str	x8, [sp, #0x28]
    6b84:      	ldr	x8, [sp, #0x28]
    6b88:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0x50>
    6b8c:      	add	x9, sp, #0x60
    6b90:      	add	x1, sp, #0x60
    6b94:      	ldr	w8, [x8, x22, lsl #2]
    6b98:      	str	w8, [sp, #0x60]
    6b9c:      	mov	w8, #0x1                // =1
    6ba0:      	ldr	x0, [x0]
    6ba4:      	blr	x8
    6ba8:      	cbz	x0, 0x7258 <generic_fentry_filter_arg+0x12a8>
    6bac:      	cbz	w29, 0x6c30 <generic_fentry_filter_arg+0xc80>
    6bb0:      	mov	x8, xzr
    6bb4:      	mov	x9, x25
    6bb8:      	mov	x10, x29
    6bbc:      	b	0x6bd4 <generic_fentry_filter_arg+0xc24>
    6bc0:      	add	x8, x8, #0x1
    6bc4:      	sub	x10, x10, #0x1
    6bc8:      	add	x9, x9, #0x1
    6bcc:      	cmp	x8, x29
    6bd0:      	b.eq	0x6c30 <generic_fentry_filter_arg+0xc80>
    6bd4:      	mov	x11, xzr
    6bd8:      	nop
    6bdc:      	nop
    6be0:      	cmp	x10, x11
    6be4:      	b.eq	0x6bc0 <generic_fentry_filter_arg+0xc10>
    6be8:      	ldrb	w12, [x0, x11]
    6bec:      	cbz	w12, 0x6c2c <generic_fentry_filter_arg+0xc7c>
    6bf0:      	ldrb	w13, [x9, x11]
    6bf4:      	sub	w14, w13, #0x41
    6bf8:      	orr	w15, w13, #0x20
    6bfc:      	cmp	w14, #0x1a
    6c00:      	sub	w14, w12, #0x41
    6c04:      	csel	w13, w15, w13, lo
    6c08:      	orr	w15, w12, #0x20
    6c0c:      	cmp	w14, #0x1a
    6c10:      	csel	w12, w15, w12, lo
    6c14:      	cmp	x11, #0x62
    6c18:      	b.hi	0x6bc0 <generic_fentry_filter_arg+0xc10>
    6c1c:      	add	x11, x11, #0x1
    6c20:      	cmp	w13, w12
    6c24:      	b.eq	0x6be0 <generic_fentry_filter_arg+0xc30>
    6c28:      	b	0x6bc0 <generic_fentry_filter_arg+0xc10>
    6c2c:      	tbz	w8, #0x1f, 0x7a78 <generic_fentry_filter_arg+0x1ac8>
    6c30:      	ldr	w9, [x23, #0x8]
    6c34:      	add	w8, w19, #0xc
    6c38:      	cmp	w8, w9
    6c3c:      	b.hs	0x7258 <generic_fentry_filter_arg+0x12a8>
    6c40:      	add	x22, x22, #0x1
    6c44:      	add	w19, w19, #0x4
    6c48:      	cmp	x22, #0x64
    6c4c:      	b.ne	0x6b84 <generic_fentry_filter_arg+0xbd4>
    6c50:      	b	0x7258 <generic_fentry_filter_arg+0x12a8>
    6c54:      	cmp	w8, #0xc
    6c58:      	b.ne	0x7878 <generic_fentry_filter_arg+0x18c8>
    6c5c:      	ldr	x11, [x25]
    6c60:      	tst	x11, x10
    6c64:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    6c68:      	b	0x7878 <generic_fentry_filter_arg+0x18c8>
    6c6c:      	sub	w10, w8, #0x1f
    6c70:      	cmp	w10, #0x2
    6c74:      	b.hs	0x74f0 <generic_fentry_filter_arg+0x1540>
    6c78:      	cmp	w8, #0x1f
    6c7c:      	b.ne	0x6d74 <generic_fentry_filter_arg+0xdc4>
    6c80:      	ldp	x11, x10, [x23, #0x10]
    6c84:      	cmp	w9, #0xa
    6c88:      	b.eq	0x6c94 <generic_fentry_filter_arg+0xce4>
    6c8c:      	cmp	w9, #0xc
    6c90:      	b.ne	0x7744 <generic_fentry_filter_arg+0x1794>
    6c94:      	ldr	x8, [x25]
    6c98:      	cmp	x11, x8
    6c9c:      	b.gt	0x7758 <generic_fentry_filter_arg+0x17a8>
    6ca0:      	cmp	x8, x10
    6ca4:      	b.le	0x6248 <generic_fentry_filter_arg+0x298>
    6ca8:      	b	0x7758 <generic_fentry_filter_arg+0x17a8>
    6cac:      	ldr	w8, [x23, #0x10]
    6cb0:      	str	wzr, [sp, #0x88]
    6cb4:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0x50>
    6cb8:      	add	x9, sp, #0x60
    6cbc:      	add	x1, sp, #0x60
    6cc0:      	str	w8, [sp, #0x60]
    6cc4:      	mov	w8, #0x1                // =1
    6cc8:      	ldr	x0, [x0]
    6ccc:      	blr	x8
    6cd0:      	mov	x22, xzr
    6cd4:      	cbz	w29, 0x7260 <generic_fentry_filter_arg+0x12b0>
    6cd8:      	cbz	x0, 0x7260 <generic_fentry_filter_arg+0x12b0>
    6cdc:      	mov	x19, x0
    6ce0:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0x50>
    6ce4:      	mov	w8, #0x1                // =1
    6ce8:      	ldr	x0, [x0]
    6cec:      	add	x9, sp, #0x88
    6cf0:      	add	x1, sp, #0x88
    6cf4:      	blr	x8
    6cf8:      	cbz	x0, 0x7258 <generic_fentry_filter_arg+0x12a8>
    6cfc:      	cmp	w29, #0xff
    6d00:      	mov	w8, #0xff               // =255
    6d04:      	mov	x22, x0
    6d08:      	mov	x2, x25
    6d0c:      	csel	w1, w29, w8, lo
    6d10:      	mov	x8, x0
    6d14:      	lsl	w9, w1, #3
    6d18:      	str	w9, [x8], #0x4
    6d1c:      	mov	w9, #0x4                // =4
    6d20:      	mov	x0, x8
    6d24:      	blr	x9
    6d28:      	mov	w8, #0x1                // =1
    6d2c:      	mov	x0, x19
    6d30:      	mov	x1, x22
    6d34:      	blr	x8
    6d38:      	cmp	x0, #0x0
    6d3c:      	cset	w22, ne
    6d40:      	b	0x725c <generic_fentry_filter_arg+0x12ac>
    6d44:      	cmp	w29, #0x1, lsl #12      // =0x1000
    6d48:      	str	wzr, [sp, #0x88]
    6d4c:      	b.ls	0x7298 <generic_fentry_filter_arg+0x12e8>
    6d50:      	mov	x22, xzr
    6d54:      	b	0x7270 <generic_fentry_filter_arg+0x12c0>
    6d58:      	cmp	w8, #0xd
    6d5c:      	b.eq	0x70c0 <generic_fentry_filter_arg+0x1110>
    6d60:      	cmp	w8, #0xe
    6d64:      	b.eq	0x70b4 <generic_fentry_filter_arg+0x1104>
    6d68:      	cmp	w8, #0xf
    6d6c:      	b.eq	0x707c <generic_fentry_filter_arg+0x10cc>
    6d70:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    6d74:      	ldp	x11, x8, [x23, #0x10]
    6d78:      	cmp	w9, #0xc
    6d7c:      	b.eq	0x6d88 <generic_fentry_filter_arg+0xdd8>
    6d80:      	cmp	w9, #0xa
    6d84:      	b.ne	0x7790 <generic_fentry_filter_arg+0x17e0>
    6d88:      	ldr	x10, [x25]
    6d8c:      	cmp	x11, x10
    6d90:      	ccmp	x10, x8, #0x0, le
    6d94:      	cset	w8, le
    6d98:      	b	0x77a0 <generic_fentry_filter_arg+0x17f0>
    6d9c:      	cmp	w8, #0xc
    6da0:      	b.ne	0x7e60 <generic_fentry_filter_arg+0x1eb0>
    6da4:      	ldr	w11, [x25]
    6da8:      	tst	w11, w10
    6dac:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    6db0:      	b	0x7e60 <generic_fentry_filter_arg+0x1eb0>
    6db4:      	lsl	x9, x12, x8
    6db8:      	tst	x9, #0xc00
    6dbc:      	b.ne	0x7390 <generic_fentry_filter_arg+0x13e0>
    6dc0:      	lsl	x9, x12, x8
    6dc4:      	tst	x9, #0x180000000
    6dc8:      	b.eq	0x60ac <generic_fentry_filter_arg+0xfc>
    6dcc:      	cmp	w8, #0x1f
    6dd0:      	b.ne	0x79b4 <generic_fentry_filter_arg+0x1a04>
    6dd4:      	ldr	w9, [x23, #0x10]
    6dd8:      	ldrb	w8, [x25]
    6ddc:      	b	0x6e08 <generic_fentry_filter_arg+0xe58>
    6de0:      	lsl	x9, x12, x8
    6de4:      	tst	x9, #0xc00
    6de8:      	b.ne	0x73c8 <generic_fentry_filter_arg+0x1418>
    6dec:      	lsl	x9, x12, x8
    6df0:      	tst	x9, #0x180000000
    6df4:      	b.eq	0x60ac <generic_fentry_filter_arg+0xfc>
    6df8:      	cmp	w8, #0x1f
    6dfc:      	b.ne	0x79d8 <generic_fentry_filter_arg+0x1a28>
    6e00:      	ldr	w9, [x23, #0x10]
    6e04:      	ldrh	w8, [x25]
    6e08:      	cmp	w9, w8
    6e0c:      	b.hi	0x6e1c <generic_fentry_filter_arg+0xe6c>
    6e10:      	ldr	w9, [x23, #0x14]
    6e14:      	cmp	w9, w8
    6e18:      	b.hs	0x6248 <generic_fentry_filter_arg+0x298>
    6e1c:      	ldr	w9, [x23, #0x8]
    6e20:      	cmp	w9, #0x11
    6e24:      	b.lo	0x60ac <generic_fentry_filter_arg+0xfc>
    6e28:      	ldr	w10, [x23, #0x18]
    6e2c:      	cmp	w10, w8
    6e30:      	b.hi	0x6e40 <generic_fentry_filter_arg+0xe90>
    6e34:      	ldr	w10, [x23, #0x1c]
    6e38:      	cmp	w10, w8
    6e3c:      	b.hs	0x6248 <generic_fentry_filter_arg+0x298>
    6e40:      	cmp	w9, #0x19
    6e44:      	b.lo	0x60ac <generic_fentry_filter_arg+0xfc>
    6e48:      	ldr	w10, [x23, #0x20]
    6e4c:      	cmp	w10, w8
    6e50:      	b.hi	0x6e60 <generic_fentry_filter_arg+0xeb0>
    6e54:      	ldr	w10, [x23, #0x24]
    6e58:      	cmp	w10, w8
    6e5c:      	b.hs	0x6248 <generic_fentry_filter_arg+0x298>
    6e60:      	cmp	w9, #0x21
    6e64:      	b.lo	0x60ac <generic_fentry_filter_arg+0xfc>
    6e68:      	ldr	w9, [x23, #0x28]
    6e6c:      	cmp	w9, w8
    6e70:      	b.hi	0x60ac <generic_fentry_filter_arg+0xfc>
    6e74:      	ldr	w9, [x23, #0x2c]
    6e78:      	cmp	w9, w8
    6e7c:      	b.hs	0x6248 <generic_fentry_filter_arg+0x298>
    6e80:      	b	0x60ac <generic_fentry_filter_arg+0xfc>
    6e84:      	cmp	w9, #0xc
    6e88:      	b.eq	0x6e94 <generic_fentry_filter_arg+0xee4>
    6e8c:      	cmp	w9, #0xa
    6e90:      	b.ne	0x785c <generic_fentry_filter_arg+0x18ac>
    6e94:      	ldr	x11, [x25]
    6e98:      	cmp	x11, x10
    6e9c:      	b.gt	0x6248 <generic_fentry_filter_arg+0x298>
    6ea0:      	b	0x7878 <generic_fentry_filter_arg+0x18c8>
    6ea4:      	and	w8, w29, #0xffff
    6ea8:      	cmp	w8, #0x90
    6eac:      	b.hi	0x7444 <generic_fentry_filter_arg+0x1494>
    6eb0:      	and	w8, w29, #0xff
    6eb4:      	mov	w9, #0xab               // =171
    6eb8:      	tst	w29, #0xffff
    6ebc:      	mul	w8, w8, w9
    6ec0:      	mov	w9, #0x18               // =24
    6ec4:      	lsr	w8, w8, #12
    6ec8:      	msub	w8, w8, w9, w29
    6ecc:      	b.eq	0x6ee0 <generic_fentry_filter_arg+0xf30>
    6ed0:      	tst	w8, #0xff
    6ed4:      	mov	w9, w29
    6ed8:      	mov	w11, w29
    6edc:      	b.eq	0x6efc <generic_fentry_filter_arg+0xf4c>
    6ee0:      	sub	w8, w29, w8, uxtb
    6ee4:      	and	w9, w8, #0xffff
    6ee8:      	add	w8, w8, #0x18
    6eec:      	and	w11, w8, #0xffff
    6ef0:      	cmp	w9, #0x78
    6ef4:      	b.hi	0x8400 <generic_fentry_filter_arg+0x2450>
    6ef8:      	mov	w9, w11
    6efc:      	and	w8, w9, #0xff
    6f00:      	mov	w9, #0xab               // =171
    6f04:      	mul	w8, w8, w9
    6f08:      	lsr	w8, w8, #12
    6f0c:      	sub	w10, w8, #0x1
    6f10:      	b	0x8450 <generic_fentry_filter_arg+0x24a0>
    6f14:      	cmp	w8, #0x20
    6f18:      	b.gt	0x7530 <generic_fentry_filter_arg+0x1580>
    6f1c:      	cmp	w8, #0x1a
    6f20:      	b.eq	0x76a4 <generic_fentry_filter_arg+0x16f4>
    6f24:      	cmp	w8, #0x1b
    6f28:      	b.ne	0x9334 <generic_fentry_filter_arg+0x3384>
    6f2c:      	ldr	w8, [x23, #0x10]
    6f30:      	str	wzr, [sp, #0x88]
    6f34:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0x50>
    6f38:      	add	x9, sp, #0x60
    6f3c:      	add	x1, sp, #0x60
    6f40:      	mov	w19, #0x1               // =1
    6f44:      	str	w8, [sp, #0x60]
    6f48:      	mov	w8, #0x1                // =1
    6f4c:      	ldr	x0, [x0]
    6f50:      	blr	x8
    6f54:      	mov	x22, xzr
    6f58:      	cbz	w25, 0x9330 <generic_fentry_filter_arg+0x3380>
    6f5c:      	cbz	x0, 0x9330 <generic_fentry_filter_arg+0x3380>
    6f60:      	mov	x22, x0
    6f64:      	adrp	x0, 0x6000 <generic_fentry_filter_arg+0x50>
    6f68:      	mov	w8, #0x1                // =1
    6f6c:      	ldr	x0, [x0]
    6f70:      	add	x9, sp, #0x88
    6f74:      	add	x1, sp, #0x88
    6f78:      	blr	x8
    6f7c:      	cbz	x0, 0x932c <generic_fentry_filter_arg+0x337c>
    6f80:      	cmp	w25, #0x7f
    6f84:      	mov	w9, #0x7f               // =127
    6f88:      	mov	x1, x0
    6f8c:      	mov	x8, xzr
    6f90:      	sub	x11, x19, x25
    6f94:      	sub	w12, w25, #0x2
    6f98:      	sub	w13, w25, #0x1
    6f9c:      	csel	w9, w25, w9, lo
    6fa0:      	lsl	w10, w9, #3
    6fa4:      	mov	x9, x0
    6fa8:      	str	w10, [x9], #0x5
    6fac:      	neg	x10, x25
    6fb0:      	add	w14, w13, w8
    6fb4:      	cmp	x11, x8
    6fb8:      	and	x14, x14, #0xfff
    6fbc:      	ldrb	w14, [x29, x14]
    6fc0:      	sturb	w14, [x9, #-0x1]
    6fc4:      	b.eq	0x6fec <generic_fentry_filter_arg+0x103c>
    6fc8:      	cmn	x8, #0x7e
    6fcc:      	b.eq	0x6fec <generic_fentry_filter_arg+0x103c>
    6fd0:      	add	w14, w12, w8
    6fd4:      	sub	x8, x8, #0x2
    6fd8:      	and	x14, x14, #0xfff
    6fdc:      	cmp	x10, x8
    6fe0:      	ldrb	w14, [x29, x14]
    6fe4:      	strb	w14, [x9], #0x2
    6fe8:      	b.ne	0x6fb0 <generic_fentry_filter_arg+0x1000>
    6fec:      	mov	w8, #0x1                // =1
    6ff0:      	mov	x0, x22
    6ff4:      	b	0x931c <generic_fentry_filter_arg+0x336c>
    6ff8:      	mov	x22, xzr
    6ffc:      	ldp	x16, x15, [sp, #0x40]
    7000:      	mov	w2, #0x5ea0             // =24224
    7004:      	mov	w12, #0x1               // =1
    7008:      	ldr	x17, [sp, #0x38]
    700c:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    7010:      	ldp	w11, w8, [x23, #0x10]
    7014:      	cmp	w9, #0xc
    7018:      	b.hi	0x7b58 <generic_fentry_filter_arg+0x1ba8>
    701c:      	lsl	w10, w12, w9
    7020:      	mov	w13, #0x1402            // =5122
    7024:      	tst	w10, w13
    7028:      	b.eq	0x7b58 <generic_fentry_filter_arg+0x1ba8>
    702c:      	ldr	w10, [x25]
    7030:      	cmp	w11, w10
    7034:      	ccmp	w10, w8, #0x0, le
    7038:      	cset	w8, le
    703c:      	b	0x7b68 <generic_fentry_filter_arg+0x1bb8>
    7040:      	cmp	w8, #0x1c
    7044:      	b.eq	0x7668 <generic_fentry_filter_arg+0x16b8>
    7048:      	mov	x25, x10
    704c:      	cmp	w8, #0x1a
    7050:      	b.eq	0x75b0 <generic_fentry_filter_arg+0x1600>
    7054:      	b	0x60ac <generic_fentry_filter_arg+0xfc>
    7058:      	cmp	w8, #0x12
    705c:      	b.eq	0x707c <generic_fentry_filter_arg+0x10cc>
    7060:      	cmp	w8, #0x13
    7064:      	b.ne	0x6244 <generic_fentry_filter_arg+0x294>
    7068:      	ldrh	w29, [x25, #0x22]
    706c:      	mov	w11, wzr
    7070:      	mov	w13, wzr
    7074:      	mov	x19, xzr
    7078:      	b	0x70cc <generic_fentry_filter_arg+0x111c>
    707c:      	ldrh	w29, [x25, #0x20]
    7080:      	mov	w11, wzr
    7084:      	mov	w13, wzr
    7088:      	mov	x19, xzr
    708c:      	b	0x70cc <generic_fentry_filter_arg+0x111c>
    7090:      	cmp	w8, #0x1c
    7094:      	b.eq	0x77d0 <generic_fentry_filter_arg+0x1820>
    7098:      	cmp	w8, #0x1d
    709c:      	b.ne	0x6244 <generic_fentry_filter_arg+0x294>
    70a0:      	cmp	w9, #0x7
    70a4:      	b.ne	0x7d04 <generic_fentry_filter_arg+0x1d54>
    70a8:      	cbnz	x10, 0x7d14 <generic_fentry_filter_arg+0x1d64>
    70ac:      	mov	x19, xzr
    70b0:      	b	0x7d28 <generic_fentry_filter_arg+0x1d78>
    70b4:      	ldp	w11, w13, [x25, #0x10]
    70b8:      	ldr	x19, [x25, #0x18]
    70bc:      	b	0x70c8 <generic_fentry_filter_arg+0x1118>
    70c0:      	ldp	w11, w13, [x25]
    70c4:      	ldr	x19, [x25, #0x8]
    70c8:      	mov	x29, xzr
    70cc:      	mov	x22, xzr
    70d0:      	cmp	w8, #0x11
    70d4:      	b.gt	0x7100 <generic_fentry_filter_arg+0x1150>
    70d8:      	sub	w9, w8, #0xd
    70dc:      	cmp	w9, #0x2
    70e0:      	b.lo	0x712c <generic_fentry_filter_arg+0x117c>
    70e4:      	ldr	x19, [sp, #0x30]
    70e8:      	sub	w9, w8, #0xf
    70ec:      	cmp	w9, #0x2
    70f0:      	b.lo	0x7318 <generic_fentry_filter_arg+0x1368>
    70f4:      	cmp	w8, #0x11
    70f8:      	b.eq	0x77d4 <generic_fentry_filter_arg+0x1824>
    70fc:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    7100:      	cmp	w8, #0x19
    7104:      	b.hi	0x7308 <generic_fentry_filter_arg+0x1358>
    7108:      	lsl	w9, w12, w8
    710c:      	mov	w10, #0x500000          // =5242880
    7110:      	tst	w9, w10
    7114:      	b.ne	0x7404 <generic_fentry_filter_arg+0x1454>
    7118:      	mov	w10, #0xa00000          // =10485760
    711c:      	tst	w9, w10
    7120:      	b.ne	0x7414 <generic_fentry_filter_arg+0x1464>
    7124:      	tst	w9, #0x3000000
    7128:      	b.eq	0x7308 <generic_fentry_filter_arg+0x1358>
    712c:      	ldrh	w8, [x25, #0x26]
    7130:      	cmp	w8, #0xa
    7134:      	b.eq	0x7454 <generic_fentry_filter_arg+0x14a4>
    7138:      	cmp	w8, #0x2
    713c:      	b.ne	0x74e0 <generic_fentry_filter_arg+0x1530>
    7140:      	ldr	w8, [x23, #0x10]
    7144:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1050>
    7148:      	add	x9, sp, #0xac
    714c:      	add	x1, sp, #0xac
    7150:      	str	w8, [sp, #0xac]
    7154:      	mov	w8, #0x1                // =1
    7158:      	mov	w22, w11
    715c:      	ldr	x0, [x0]
    7160:      	blr	x8
    7164:      	ldr	x19, [sp, #0x30]
    7168:      	cbz	x0, 0x7e10 <generic_fentry_filter_arg+0x1e60>
    716c:      	mov	w8, #0x20               // =32
    7170:      	add	x1, sp, #0x88
    7174:      	stp	w8, w22, [sp, #0x88]
    7178:      	b	0x749c <generic_fentry_filter_arg+0x14ec>
    717c:      	cmp	w9, #0xc
    7180:      	b.hi	0x7e44 <generic_fentry_filter_arg+0x1e94>
    7184:      	lsl	w11, w12, w9
    7188:      	mov	w13, #0x1402            // =5122
    718c:      	tst	w11, w13
    7190:      	b.eq	0x7e44 <generic_fentry_filter_arg+0x1e94>
    7194:      	ldr	w11, [x25]
    7198:      	cmp	w11, w10
    719c:      	b.gt	0x6248 <generic_fentry_filter_arg+0x298>
    71a0:      	b	0x7e60 <generic_fentry_filter_arg+0x1eb0>
    71a4:      	mov	x19, xzr
    71a8:      	mov	w22, wzr
    71ac:      	add	x8, x23, #0x10
    71b0:      	str	x8, [sp, #0x28]
    71b4:      	ldr	x8, [sp, #0x28]
    71b8:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1050>
    71bc:      	add	x9, sp, #0x60
    71c0:      	add	x1, sp, #0x60
    71c4:      	ldr	w8, [x8, x19, lsl #2]
    71c8:      	str	w8, [sp, #0x60]
    71cc:      	mov	w8, #0x1                // =1
    71d0:      	ldr	x0, [x0]
    71d4:      	blr	x8
    71d8:      	cbz	x0, 0x7258 <generic_fentry_filter_arg+0x12a8>
    71dc:      	cbz	w29, 0x7238 <generic_fentry_filter_arg+0x1288>
    71e0:      	mov	x8, xzr
    71e4:      	mov	x9, x25
    71e8:      	mov	x10, x29
    71ec:      	b	0x7204 <generic_fentry_filter_arg+0x1254>
    71f0:      	add	x8, x8, #0x1
    71f4:      	sub	x10, x10, #0x1
    71f8:      	add	x9, x9, #0x1
    71fc:      	cmp	x8, x29
    7200:      	b.eq	0x7238 <generic_fentry_filter_arg+0x1288>
    7204:      	mov	x11, xzr
    7208:      	cmp	x10, x11
    720c:      	b.eq	0x71f0 <generic_fentry_filter_arg+0x1240>
    7210:      	ldrb	w12, [x0, x11]
    7214:      	cbz	w12, 0x7234 <generic_fentry_filter_arg+0x1284>
    7218:      	cmp	x11, #0x62
    721c:      	b.hi	0x71f0 <generic_fentry_filter_arg+0x1240>
    7220:      	ldrb	w13, [x9, x11]
    7224:      	add	x11, x11, #0x1
    7228:      	cmp	w13, w12
    722c:      	b.eq	0x7208 <generic_fentry_filter_arg+0x1258>
    7230:      	b	0x71f0 <generic_fentry_filter_arg+0x1240>
    7234:      	tbz	w8, #0x1f, 0x7a78 <generic_fentry_filter_arg+0x1ac8>
    7238:      	ldr	w9, [x23, #0x8]
    723c:      	add	w8, w22, #0xc
    7240:      	cmp	w8, w9
    7244:      	b.hs	0x7258 <generic_fentry_filter_arg+0x12a8>
    7248:      	add	x19, x19, #0x1
    724c:      	add	w22, w22, #0x4
    7250:      	cmp	x19, #0x64
    7254:      	b.ne	0x71b4 <generic_fentry_filter_arg+0x1204>
    7258:      	mov	x22, xzr
    725c:      	ldr	x19, [sp, #0x30]
    7260:      	ldp	x16, x15, [sp, #0x40]
    7264:      	mov	w2, #0x5ea0             // =24224
    7268:      	ldr	x17, [sp, #0x38]
    726c:      	mov	w12, #0x1               // =1
    7270:      	ldr	w8, [x23, #0x4]
    7274:      	cmp	w8, #0x25
    7278:      	b.hi	0x6244 <generic_fentry_filter_arg+0x294>
    727c:      	mov	x9, #0x50               // =80
    7280:      	lsl	x8, x12, x8
    7284:      	movk	x9, #0xc00, lsl #16
    7288:      	movk	x9, #0x20, lsl #32
    728c:      	tst	x8, x9
    7290:      	b.ne	0x9368 <generic_fentry_filter_arg+0x33b8>
    7294:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    7298:      	and	w8, w29, #0xffff
    729c:      	cmp	w8, #0x90
    72a0:      	b.hi	0x784c <generic_fentry_filter_arg+0x189c>
    72a4:      	and	w8, w29, #0xff
    72a8:      	mov	w9, #0xab               // =171
    72ac:      	tst	w29, #0xffff
    72b0:      	mul	w8, w8, w9
    72b4:      	mov	w9, #0x18               // =24
    72b8:      	lsr	w8, w8, #12
    72bc:      	msub	w8, w8, w9, w29
    72c0:      	b.eq	0x72d4 <generic_fentry_filter_arg+0x1324>
    72c4:      	tst	w8, #0xff
    72c8:      	mov	w9, w29
    72cc:      	mov	w11, w29
    72d0:      	b.eq	0x72f0 <generic_fentry_filter_arg+0x1340>
    72d4:      	sub	w8, w29, w8, uxtb
    72d8:      	and	w9, w8, #0xffff
    72dc:      	add	w8, w8, #0x18
    72e0:      	and	w11, w8, #0xffff
    72e4:      	cmp	w9, #0x78
    72e8:      	b.hi	0x88cc <generic_fentry_filter_arg+0x291c>
    72ec:      	mov	w9, w11
    72f0:      	and	w8, w9, #0xff
    72f4:      	mov	w9, #0xab               // =171
    72f8:      	mul	w8, w8, w9
    72fc:      	lsr	w8, w8, #12
    7300:      	sub	w10, w8, #0x1
    7304:      	b	0x891c <generic_fentry_filter_arg+0x296c>
    7308:      	ldr	x19, [sp, #0x30]
    730c:      	sub	w8, w8, #0x12
    7310:      	cmp	w8, #0x2
    7314:      	b.hs	0x6244 <generic_fentry_filter_arg+0x294>
    7318:      	ldrb	w8, [x23, #0x10]
    731c:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1050>
    7320:      	add	x9, sp, #0xac
    7324:      	add	x1, sp, #0xac
    7328:      	str	w8, [sp, #0xac]
    732c:      	mov	w8, #0x1                // =1
    7330:      	ldr	x0, [x0]
    7334:      	blr	x8
    7338:      	cbz	x0, 0x7840 <generic_fentry_filter_arg+0x1890>
    733c:      	str	x29, [sp, #0x88]
    7340:      	mov	w8, #0x1                // =1
    7344:      	add	x9, sp, #0x88
    7348:      	add	x1, sp, #0x88
    734c:      	b	0x7808 <generic_fentry_filter_arg+0x1858>
    7350:      	cmp	w8, #0x1
    7354:      	b.eq	0x7a80 <generic_fentry_filter_arg+0x1ad0>
    7358:      	cmp	w8, #0x2
    735c:      	b.ne	0x7a8c <generic_fentry_filter_arg+0x1adc>
    7360:      	ldrb	w10, [x25]
    7364:      	cmp	w9, w10
    7368:      	b.hi	0x6248 <generic_fentry_filter_arg+0x298>
    736c:      	b	0x7a8c <generic_fentry_filter_arg+0x1adc>
    7370:      	cmp	w8, #0x1
    7374:      	b.eq	0x7ac0 <generic_fentry_filter_arg+0x1b10>
    7378:      	cmp	w8, #0x2
    737c:      	b.ne	0x7acc <generic_fentry_filter_arg+0x1b1c>
    7380:      	ldrh	w10, [x25]
    7384:      	cmp	w9, w10
    7388:      	b.hi	0x6248 <generic_fentry_filter_arg+0x298>
    738c:      	b	0x7acc <generic_fentry_filter_arg+0x1b1c>
    7390:      	ldrb	w8, [x23, #0x10]
    7394:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1050>
    7398:      	add	x9, sp, #0x88
    739c:      	add	x1, sp, #0x88
    73a0:      	str	w8, [sp, #0x88]
    73a4:      	mov	w8, #0x1                // =1
    73a8:      	ldr	x0, [x0]
    73ac:      	blr	x8
    73b0:      	cbz	x0, 0x7840 <generic_fentry_filter_arg+0x1890>
    73b4:      	ldrb	w8, [x25]
    73b8:      	add	x9, sp, #0x60
    73bc:      	str	x8, [sp, #0x60]
    73c0:      	mov	w8, #0x1                // =1
    73c4:      	b	0x73fc <generic_fentry_filter_arg+0x144c>
    73c8:      	ldrb	w8, [x23, #0x10]
    73cc:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1050>
    73d0:      	add	x9, sp, #0x88
    73d4:      	add	x1, sp, #0x88
    73d8:      	str	w8, [sp, #0x88]
    73dc:      	mov	w8, #0x1                // =1
    73e0:      	ldr	x0, [x0]
    73e4:      	blr	x8
    73e8:      	cbz	x0, 0x7840 <generic_fentry_filter_arg+0x1890>
    73ec:      	ldrh	w8, [x25]
    73f0:      	add	x9, sp, #0x60
    73f4:      	str	x8, [sp, #0x60]
    73f8:      	mov	w8, #0x1                // =1
    73fc:      	add	x1, sp, #0x60
    7400:      	b	0x7808 <generic_fentry_filter_arg+0x1858>
    7404:      	ldr	x19, [sp, #0x30]
    7408:      	cmp	x29, #0x400
    740c:      	cset	w22, lo
    7410:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    7414:      	ldr	x19, [sp, #0x30]
    7418:      	cmp	x29, #0x3ff
    741c:      	cset	w22, hi
    7420:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    7424:      	ldp	x16, x15, [sp, #0x40]
    7428:      	cmp	x0, #0x0
    742c:      	mov	w2, #0x5ea0             // =24224
    7430:      	mov	w12, #0x1               // =1
    7434:      	cset	w8, eq
    7438:      	ldr	x17, [sp, #0x38]
    743c:      	mov	w22, w8
    7440:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    7444:      	cmp	w8, #0x101
    7448:      	b.hs	0x7a5c <generic_fentry_filter_arg+0x1aac>
    744c:      	mov	w11, #0x100             // =256
    7450:      	b	0x8400 <generic_fentry_filter_arg+0x2450>
    7454:      	ldr	w8, [x23, #0x14]
    7458:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1050>
    745c:      	add	x9, sp, #0xac
    7460:      	add	x1, sp, #0xac
    7464:      	str	w8, [sp, #0xac]
    7468:      	mov	w8, #0x1                // =1
    746c:      	mov	w25, w13
    7470:      	mov	w22, w11
    7474:      	ldr	x0, [x0]
    7478:      	blr	x8
    747c:      	cbz	x0, 0x7e18 <generic_fentry_filter_arg+0x1e68>
    7480:      	mov	w8, #0x80               // =128
    7484:      	stp	w25, w19, [sp, #0x90]
    7488:      	add	x1, sp, #0x88
    748c:      	stp	w8, w22, [sp, #0x88]
    7490:      	lsr	x8, x19, #32
    7494:      	ldr	x19, [sp, #0x30]
    7498:      	str	w8, [sp, #0x98]
    749c:      	mov	w8, #0x1                // =1
    74a0:      	blr	x8
    74a4:      	ldr	w8, [x23, #0x4]
    74a8:      	sub	w9, w8, #0x18
    74ac:      	cmp	w9, #0x2
    74b0:      	b.lo	0x7a70 <generic_fentry_filter_arg+0x1ac0>
    74b4:      	sub	w8, w8, #0xd
    74b8:      	mov	w12, #0x1               // =1
    74bc:      	cmp	w8, #0x1
    74c0:      	b.hi	0x6a80 <generic_fentry_filter_arg+0xad0>
    74c4:      	cmp	x0, #0x0
    74c8:      	cset	w8, ne
    74cc:      	ldp	x16, x15, [sp, #0x40]
    74d0:      	mov	w2, #0x5ea0             // =24224
    74d4:      	mov	w22, w8
    74d8:      	ldr	x17, [sp, #0x38]
    74dc:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    74e0:      	ldr	x19, [sp, #0x30]
    74e4:      	mov	w8, wzr
    74e8:      	mov	w22, wzr
    74ec:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    74f0:      	cmp	w8, #0x1e
    74f4:      	b.ne	0x60ac <generic_fentry_filter_arg+0xfc>
    74f8:      	ldr	w8, [x23, #0x10]
    74fc:      	and	x8, x8, #0x7
    7500:      	add	x9, x20, x8, lsl #2
    7504:      	ldr	w9, [x9, x2]
    7508:      	cbnz	w9, 0x60ac <generic_fentry_filter_arg+0xfc>
    750c:      	add	x8, x20, x8, lsl #3
    7510:      	ldr	x9, [x25]
    7514:      	ldr	x8, [x8, #0x5e78]
    7518:      	and	x8, x8, #0x7ff
    751c:      	add	x8, x20, x8
    7520:      	ldr	x8, [x8, #0x90]
    7524:      	bics	xzr, x8, x9
    7528:      	cset	w22, ne
    752c:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    7530:      	cmp	w8, #0x21
    7534:      	b.eq	0x7ba4 <generic_fentry_filter_arg+0x1bf4>
    7538:      	cmp	w8, #0x22
    753c:      	b.ne	0x9334 <generic_fentry_filter_arg+0x3384>
    7540:      	mov	w19, #0x10              // =16
    7544:      	ldr	w8, [x23, x19]
    7548:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1050>
    754c:      	add	x9, sp, #0x60
    7550:      	add	x1, sp, #0x60
    7554:      	str	w8, [sp, #0x60]
    7558:      	mov	w8, #0x1                // =1
    755c:      	ldr	x0, [x0]
    7560:      	blr	x8
    7564:      	cbz	x0, 0x932c <generic_fentry_filter_arg+0x337c>
    7568:      	mov	x1, x0
    756c:      	mov	x0, x29
    7570:      	mov	x2, x25
    7574:      	bl	0x7574 <generic_fentry_filter_arg+0x15c4>
    7578:      	tbz	w0, #0x1f, 0x8384 <generic_fentry_filter_arg+0x23d4>
    757c:      	ldr	w8, [x23, #0x8]
    7580:      	add	x19, x19, #0x4
    7584:      	mov	w12, #0x1               // =1
    7588:      	mov	x22, xzr
    758c:      	sub	w9, w19, #0x8
    7590:      	cmp	w9, w8
    7594:      	b.hs	0x9334 <generic_fentry_filter_arg+0x3384>
    7598:      	cmp	x19, #0x1a0
    759c:      	b.ne	0x7544 <generic_fentry_filter_arg+0x1594>
    75a0:      	b	0x9334 <generic_fentry_filter_arg+0x3384>
    75a4:      	mov	x25, x10
    75a8:      	cmp	w8, #0x8
    75ac:      	b.ne	0x60ac <generic_fentry_filter_arg+0xfc>
    75b0:      	ldr	w8, [x23, #0x10]
    75b4:      	str	wzr, [sp, #0x88]
    75b8:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1050>
    75bc:      	add	x9, sp, #0x60
    75c0:      	add	x1, sp, #0x60
    75c4:      	str	w8, [sp, #0x60]
    75c8:      	mov	w8, #0x1                // =1
    75cc:      	ldr	x0, [x0]
    75d0:      	blr	x8
    75d4:      	mov	x22, xzr
    75d8:      	cbz	w29, 0x7f44 <generic_fentry_filter_arg+0x1f94>
    75dc:      	cbz	x0, 0x7f44 <generic_fentry_filter_arg+0x1f94>
    75e0:      	mov	x19, x0
    75e4:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1050>
    75e8:      	mov	w8, #0x1                // =1
    75ec:      	ldr	x0, [x0]
    75f0:      	add	x9, sp, #0x88
    75f4:      	add	x1, sp, #0x88
    75f8:      	blr	x8
    75fc:      	cbz	x0, 0x7f3c <generic_fentry_filter_arg+0x1f8c>
    7600:      	lsl	w9, w29, #3
    7604:      	mov	x8, x0
    7608:      	mov	x2, x25
    760c:      	mov	w1, w29
    7610:      	str	w9, [x8], #0x4
    7614:      	mov	w9, #0x4                // =4
    7618:      	mov	x25, x0
    761c:      	mov	x0, x8
    7620:      	blr	x9
    7624:      	mov	w8, #0x1                // =1
    7628:      	mov	x0, x19
    762c:      	mov	x1, x25
    7630:      	blr	x8
    7634:      	cmp	x0, #0x0
    7638:      	cset	w22, ne
    763c:      	b	0x7f40 <generic_fentry_filter_arg+0x1f90>
    7640:      	mov	w13, #0x100             // =256
    7644:      	sub	w8, w13, #0x100
    7648:      	ror	w8, w8, #0x8
    764c:      	cmp	w8, #0x2
    7650:      	b.gt	0x7a44 <generic_fentry_filter_arg+0x1a94>
    7654:      	cbz	w8, 0x802c <generic_fentry_filter_arg+0x207c>
    7658:      	cmp	w8, #0x1
    765c:      	b.ne	0x8024 <generic_fentry_filter_arg+0x2074>
    7660:      	mov	w11, #0x7               // =7
    7664:      	b	0x8038 <generic_fentry_filter_arg+0x2088>
    7668:      	ldrb	w8, [x23, #0x10]
    766c:      	ldrh	w19, [x25]
    7670:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1050>
    7674:      	add	x9, sp, #0x88
    7678:      	add	x1, sp, #0x88
    767c:      	str	w8, [sp, #0x88]
    7680:      	mov	w8, #0x1                // =1
    7684:      	ldr	x0, [x0]
    7688:      	blr	x8
    768c:      	cbz	x0, 0x7db8 <generic_fentry_filter_arg+0x1e08>
    7690:      	str	x19, [sp, #0x60]
    7694:      	mov	w8, #0x1                // =1
    7698:      	add	x9, sp, #0x60
    769c:      	add	x1, sp, #0x60
    76a0:      	b	0x7d5c <generic_fentry_filter_arg+0x1dac>
    76a4:      	ldr	w8, [x23, #0x10]
    76a8:      	str	wzr, [sp, #0x88]
    76ac:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1050>
    76b0:      	add	x9, sp, #0x60
    76b4:      	add	x1, sp, #0x60
    76b8:      	str	w8, [sp, #0x60]
    76bc:      	mov	w8, #0x1                // =1
    76c0:      	ldr	x0, [x0]
    76c4:      	blr	x8
    76c8:      	mov	x22, xzr
    76cc:      	cbz	w25, 0x9330 <generic_fentry_filter_arg+0x3380>
    76d0:      	cbz	x0, 0x9330 <generic_fentry_filter_arg+0x3380>
    76d4:      	mov	x19, x0
    76d8:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1050>
    76dc:      	mov	w8, #0x1                // =1
    76e0:      	ldr	x0, [x0]
    76e4:      	add	x9, sp, #0x88
    76e8:      	add	x1, sp, #0x88
    76ec:      	blr	x8
    76f0:      	cbz	x0, 0x932c <generic_fentry_filter_arg+0x337c>
    76f4:      	cmp	w25, #0xff
    76f8:      	mov	w8, #0xff               // =255
    76fc:      	mov	x22, x0
    7700:      	mov	x2, x29
    7704:      	csel	w1, w25, w8, lo
    7708:      	mov	x8, x0
    770c:      	lsl	w9, w1, #3
    7710:      	str	w9, [x8], #0x4
    7714:      	mov	w9, #0x4                // =4
    7718:      	mov	x0, x8
    771c:      	blr	x9
    7720:      	mov	w8, #0x1                // =1
    7724:      	mov	x0, x19
    7728:      	mov	x1, x22
    772c:      	b	0x931c <generic_fentry_filter_arg+0x336c>
    7730:      	cmp	w25, #0x1, lsl #12      // =0x1000
    7734:      	str	wzr, [sp, #0x88]
    7738:      	b.ls	0x7c58 <generic_fentry_filter_arg+0x1ca8>
    773c:      	mov	x22, xzr
    7740:      	b	0x9334 <generic_fentry_filter_arg+0x3384>
    7744:      	ldr	x8, [x25]
    7748:      	cmp	x11, x8
    774c:      	b.hi	0x7758 <generic_fentry_filter_arg+0x17a8>
    7750:      	cmp	x8, x10
    7754:      	b.ls	0x6248 <generic_fentry_filter_arg+0x298>
    7758:      	ldr	w10, [x23, #0x8]
    775c:      	cmp	w10, #0x19
    7760:      	b.lo	0x60ac <generic_fentry_filter_arg+0xfc>
    7764:      	ldp	x12, x11, [x23, #0x20]
    7768:      	cmp	w9, #0xc
    776c:      	b.eq	0x7778 <generic_fentry_filter_arg+0x17c8>
    7770:      	cmp	w9, #0xa
    7774:      	b.ne	0x7dc8 <generic_fentry_filter_arg+0x1e18>
    7778:      	cmp	x12, x8
    777c:      	mov	w12, #0x1               // =1
    7780:      	b.gt	0x7ddc <generic_fentry_filter_arg+0x1e2c>
    7784:      	cmp	x8, x11
    7788:      	b.le	0x6248 <generic_fentry_filter_arg+0x298>
    778c:      	b	0x7ddc <generic_fentry_filter_arg+0x1e2c>
    7790:      	ldr	x10, [x25]
    7794:      	cmp	x11, x10
    7798:      	ccmp	x10, x8, #0x2, ls
    779c:      	cset	w8, ls
    77a0:      	ldr	w11, [x23, #0x8]
    77a4:      	cmp	w11, #0x19
    77a8:      	b.lo	0x8838 <generic_fentry_filter_arg+0x2888>
    77ac:      	ldp	x13, x12, [x23, #0x20]
    77b0:      	cmp	w9, #0xc
    77b4:      	b.eq	0x77c0 <generic_fentry_filter_arg+0x1810>
    77b8:      	cmp	w9, #0xa
    77bc:      	b.ne	0x7cc8 <generic_fentry_filter_arg+0x1d18>
    77c0:      	cmp	x13, x10
    77c4:      	ccmp	x10, x12, #0x0, le
    77c8:      	cset	w12, le
    77cc:      	b	0x7cd4 <generic_fentry_filter_arg+0x1d24>
    77d0:      	ldrh	w22, [x25, #0x26]
    77d4:      	ldrb	w8, [x23, #0x10]
    77d8:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1050>
    77dc:      	add	x9, sp, #0xac
    77e0:      	add	x1, sp, #0xac
    77e4:      	str	w8, [sp, #0xac]
    77e8:      	mov	w8, #0x1                // =1
    77ec:      	ldr	x0, [x0]
    77f0:      	blr	x8
    77f4:      	cbz	x0, 0x7840 <generic_fentry_filter_arg+0x1890>
    77f8:      	str	x22, [sp, #0x88]
    77fc:      	mov	w8, #0x1                // =1
    7800:      	add	x9, sp, #0x88
    7804:      	add	x1, sp, #0x88
    7808:      	blr	x8
    780c:      	ldr	w9, [x23, #0x4]
    7810:      	mov	w8, wzr
    7814:      	mov	w12, #0x1               // =1
    7818:      	cmp	w9, #0x1d
    781c:      	b.hi	0x7da4 <generic_fentry_filter_arg+0x1df4>
    7820:      	mov	w10, #0x8400            // =33792
    7824:      	lsl	w9, w12, w9
    7828:      	movk	w10, #0x3003, lsl #16
    782c:      	tst	w9, w10
    7830:      	b.eq	0x7d8c <generic_fentry_filter_arg+0x1ddc>
    7834:      	cmp	x0, #0x0
    7838:      	cset	w8, ne
    783c:      	b	0x7da4 <generic_fentry_filter_arg+0x1df4>
    7840:      	mov	x22, xzr
    7844:      	mov	w12, #0x1               // =1
    7848:      	b	0x7da8 <generic_fentry_filter_arg+0x1df8>
    784c:      	cmp	w8, #0x101
    7850:      	b.hs	0x7f28 <generic_fentry_filter_arg+0x1f78>
    7854:      	mov	w11, #0x100             // =256
    7858:      	b	0x88cc <generic_fentry_filter_arg+0x291c>
    785c:      	ldr	x11, [x25]
    7860:      	cmp	x11, x10
    7864:      	b.hi	0x6248 <generic_fentry_filter_arg+0x298>
    7868:      	b	0x7878 <generic_fentry_filter_arg+0x18c8>
    786c:      	ldr	x11, [x25]
    7870:      	cmp	x11, x10
    7874:      	b.lo	0x6248 <generic_fentry_filter_arg+0x298>
    7878:      	ldr	w10, [x23, #0x8]
    787c:      	cmp	w10, #0x11
    7880:      	b.lo	0x93a4 <generic_fentry_filter_arg+0x33f4>
    7884:      	ldr	x11, [x23, #0x18]
    7888:      	cmp	w8, #0x2
    788c:      	b.le	0x78b0 <generic_fentry_filter_arg+0x1900>
    7890:      	sub	w12, w8, #0x3
    7894:      	cmp	w12, #0x2
    7898:      	b.hs	0x78e4 <generic_fentry_filter_arg+0x1934>
    789c:      	ldr	x12, [x25]
    78a0:      	cmp	x12, x11
    78a4:      	mov	w12, #0x1               // =1
    78a8:      	b.eq	0x623c <generic_fentry_filter_arg+0x28c>
    78ac:      	b	0x82cc <generic_fentry_filter_arg+0x231c>
    78b0:      	cmp	w8, #0x1
    78b4:      	b.eq	0x7990 <generic_fentry_filter_arg+0x19e0>
    78b8:      	cmp	w8, #0x2
    78bc:      	b.ne	0x82cc <generic_fentry_filter_arg+0x231c>
    78c0:      	cmp	w9, #0xc
    78c4:      	b.eq	0x78d0 <generic_fentry_filter_arg+0x1920>
    78c8:      	cmp	w9, #0xa
    78cc:      	b.ne	0x82bc <generic_fentry_filter_arg+0x230c>
    78d0:      	ldr	x12, [x25]
    78d4:      	cmp	x12, x11
    78d8:      	mov	w12, #0x1               // =1
    78dc:      	b.lt	0x6248 <generic_fentry_filter_arg+0x298>
    78e0:      	b	0x82cc <generic_fentry_filter_arg+0x231c>
    78e4:      	cmp	w8, #0xc
    78e8:      	mov	w12, #0x1               // =1
    78ec:      	b.ne	0x82cc <generic_fentry_filter_arg+0x231c>
    78f0:      	ldr	x12, [x25]
    78f4:      	tst	x12, x11
    78f8:      	mov	w12, #0x1               // =1
    78fc:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    7900:      	b	0x82cc <generic_fentry_filter_arg+0x231c>
    7904:      	cmp	w8, #0xc
    7908:      	b.ne	0x7a8c <generic_fentry_filter_arg+0x1adc>
    790c:      	ldrb	w10, [x25]
    7910:      	tst	w9, w10
    7914:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    7918:      	b	0x7a8c <generic_fentry_filter_arg+0x1adc>
    791c:      	cmp	w8, #0xc
    7920:      	b.ne	0x7acc <generic_fentry_filter_arg+0x1b1c>
    7924:      	ldrh	w10, [x25]
    7928:      	tst	w9, w10
    792c:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    7930:      	b	0x7acc <generic_fentry_filter_arg+0x1b1c>
    7934:      	ldr	w9, [x23, #0x8]
    7938:      	cmp	w9, #0xd
    793c:      	b.lo	0x676c <generic_fentry_filter_arg+0x7bc>
    7940:      	ldr	w10, [x23, #0x14]
    7944:      	cbz	w10, 0x676c <generic_fentry_filter_arg+0x7bc>
    7948:      	cmp	w10, w8
    794c:      	b.eq	0x65b0 <generic_fentry_filter_arg+0x600>
    7950:      	cmp	w9, #0x11
    7954:      	b.lo	0x676c <generic_fentry_filter_arg+0x7bc>
    7958:      	ldr	w10, [x23, #0x18]
    795c:      	cbz	w10, 0x676c <generic_fentry_filter_arg+0x7bc>
    7960:      	cmp	w10, w8
    7964:      	b.eq	0x65b0 <generic_fentry_filter_arg+0x600>
    7968:      	cmp	w9, #0x15
    796c:      	b.lo	0x7984 <generic_fentry_filter_arg+0x19d4>
    7970:      	ldr	w9, [x23, #0x1c]
    7974:      	cbz	w9, 0x7984 <generic_fentry_filter_arg+0x19d4>
    7978:      	cmp	w9, w8
    797c:      	cset	w22, eq
    7980:      	b	0x7988 <generic_fentry_filter_arg+0x19d8>
    7984:      	mov	x22, xzr
    7988:      	ldr	x19, [sp, #0x30]
    798c:      	b	0x8d94 <generic_fentry_filter_arg+0x2de4>
    7990:      	cmp	w9, #0xc
    7994:      	b.eq	0x79a0 <generic_fentry_filter_arg+0x19f0>
    7998:      	cmp	w9, #0xa
    799c:      	b.ne	0x82a8 <generic_fentry_filter_arg+0x22f8>
    79a0:      	ldr	x12, [x25]
    79a4:      	cmp	x12, x11
    79a8:      	mov	w12, #0x1               // =1
    79ac:      	b.gt	0x6248 <generic_fentry_filter_arg+0x298>
    79b0:      	b	0x82cc <generic_fentry_filter_arg+0x231c>
    79b4:      	ldp	w8, w11, [x23, #0x10]
    79b8:      	ldrb	w9, [x25]
    79bc:      	cmp	w8, w9
    79c0:      	ldr	w10, [x23, #0x8]
    79c4:      	ccmp	w11, w9, #0x0, ls
    79c8:      	cset	w8, hs
    79cc:      	cmp	w10, #0x11
    79d0:      	b.lo	0x8b0c <generic_fentry_filter_arg+0x2b5c>
    79d4:      	b	0x79f8 <generic_fentry_filter_arg+0x1a48>
    79d8:      	ldp	w8, w11, [x23, #0x10]
    79dc:      	ldrh	w9, [x25]
    79e0:      	cmp	w8, w9
    79e4:      	ldr	w10, [x23, #0x8]
    79e8:      	ccmp	w11, w9, #0x0, ls
    79ec:      	cset	w8, hs
    79f0:      	cmp	w10, #0x11
    79f4:      	b.lo	0x8b0c <generic_fentry_filter_arg+0x2b5c>
    79f8:      	ldp	w11, w12, [x23, #0x18]
    79fc:      	cmp	w11, w9
    7a00:      	ccmp	w12, w9, #0x0, ls
    7a04:      	mov	w12, #0x1               // =1
    7a08:      	csinc	w8, w8, wzr, lo
    7a0c:      	cmp	w10, #0x19
    7a10:      	b.lo	0x8b0c <generic_fentry_filter_arg+0x2b5c>
    7a14:      	ldp	w11, w12, [x23, #0x20]
    7a18:      	cmp	w11, w9
    7a1c:      	ccmp	w12, w9, #0x0, ls
    7a20:      	mov	w12, #0x1               // =1
    7a24:      	csinc	w8, w8, wzr, lo
    7a28:      	cmp	w10, #0x21
    7a2c:      	b.lo	0x8b0c <generic_fentry_filter_arg+0x2b5c>
    7a30:      	ldp	w10, w11, [x23, #0x28]
    7a34:      	cmp	w10, w9
    7a38:      	ccmp	w11, w9, #0x0, ls
    7a3c:      	csinc	w8, w8, wzr, lo
    7a40:      	b	0x8b0c <generic_fentry_filter_arg+0x2b5c>
    7a44:      	cmp	w8, #0x3
    7a48:      	b.eq	0x8034 <generic_fentry_filter_arg+0x2084>
    7a4c:      	cmp	w8, #0x7
    7a50:      	b.ne	0x8024 <generic_fentry_filter_arg+0x2074>
    7a54:      	mov	w11, #0x9               // =9
    7a58:      	b	0x8038 <generic_fentry_filter_arg+0x2088>
    7a5c:      	and	w8, w29, #0xffff
    7a60:      	cmp	w8, #0x201
    7a64:      	b.hs	0x7fbc <generic_fentry_filter_arg+0x200c>
    7a68:      	mov	w11, #0x200             // =512
    7a6c:      	b	0x8400 <generic_fentry_filter_arg+0x2450>
    7a70:      	cmp	x0, #0x0
    7a74:      	b	0x7e28 <generic_fentry_filter_arg+0x1e78>
    7a78:      	mov	w22, #0x1               // =1
    7a7c:      	b	0x725c <generic_fentry_filter_arg+0x12ac>
    7a80:      	ldrb	w10, [x25]
    7a84:      	cmp	w9, w10
    7a88:      	b.lo	0x6248 <generic_fentry_filter_arg+0x298>
    7a8c:      	ldr	w9, [x23, #0x8]
    7a90:      	cmp	w9, #0xd
    7a94:      	b.lo	0x93a4 <generic_fentry_filter_arg+0x33f4>
    7a98:      	ldr	w10, [x23, #0x14]
    7a9c:      	cmp	w8, #0x2
    7aa0:      	b.le	0x7f7c <generic_fentry_filter_arg+0x1fcc>
    7aa4:      	sub	w11, w8, #0x3
    7aa8:      	cmp	w11, #0x2
    7aac:      	b.hs	0x8354 <generic_fentry_filter_arg+0x23a4>
    7ab0:      	ldrb	w11, [x25]
    7ab4:      	cmp	w10, w11
    7ab8:      	b.eq	0x623c <generic_fentry_filter_arg+0x28c>
    7abc:      	b	0x8608 <generic_fentry_filter_arg+0x2658>
    7ac0:      	ldrh	w10, [x25]
    7ac4:      	cmp	w9, w10
    7ac8:      	b.lo	0x6248 <generic_fentry_filter_arg+0x298>
    7acc:      	ldr	w9, [x23, #0x8]
    7ad0:      	cmp	w9, #0xd
    7ad4:      	b.lo	0x93a4 <generic_fentry_filter_arg+0x33f4>
    7ad8:      	ldr	w10, [x23, #0x14]
    7adc:      	cmp	w8, #0x2
    7ae0:      	b.le	0x7f9c <generic_fentry_filter_arg+0x1fec>
    7ae4:      	sub	w11, w8, #0x3
    7ae8:      	cmp	w11, #0x2
    7aec:      	b.hs	0x836c <generic_fentry_filter_arg+0x23bc>
    7af0:      	ldrh	w11, [x25]
    7af4:      	cmp	w10, w11
    7af8:      	b.eq	0x623c <generic_fentry_filter_arg+0x28c>
    7afc:      	b	0x8644 <generic_fentry_filter_arg+0x2694>
    7b00:      	ldr	w8, [x25]
    7b04:      	cmp	w11, w8
    7b08:      	b.hi	0x7b14 <generic_fentry_filter_arg+0x1b64>
    7b0c:      	cmp	w8, w10
    7b10:      	b.ls	0x6248 <generic_fentry_filter_arg+0x298>
    7b14:      	ldr	w10, [x23, #0x8]
    7b18:      	cmp	w10, #0x11
    7b1c:      	b.lo	0x60ac <generic_fentry_filter_arg+0xfc>
    7b20:      	ldp	w12, w11, [x23, #0x18]
    7b24:      	mov	w13, #0x1               // =1
    7b28:      	cmp	w9, #0xc
    7b2c:      	b.hi	0x81c4 <generic_fentry_filter_arg+0x2214>
    7b30:      	lsl	w13, w13, w9
    7b34:      	mov	w14, #0x1402            // =5122
    7b38:      	tst	w13, w14
    7b3c:      	b.eq	0x81c4 <generic_fentry_filter_arg+0x2214>
    7b40:      	cmp	w12, w8
    7b44:      	mov	w12, #0x1               // =1
    7b48:      	b.gt	0x81d8 <generic_fentry_filter_arg+0x2228>
    7b4c:      	cmp	w8, w11
    7b50:      	b.le	0x6248 <generic_fentry_filter_arg+0x298>
    7b54:      	b	0x81d8 <generic_fentry_filter_arg+0x2228>
    7b58:      	ldr	w10, [x25]
    7b5c:      	cmp	w11, w10
    7b60:      	ccmp	w10, w8, #0x2, ls
    7b64:      	cset	w8, ls
    7b68:      	ldr	w11, [x23, #0x8]
    7b6c:      	cmp	w11, #0x11
    7b70:      	b.lo	0x8b0c <generic_fentry_filter_arg+0x2b5c>
    7b74:      	ldp	w13, w12, [x23, #0x18]
    7b78:      	mov	w14, #0x1               // =1
    7b7c:      	cmp	w9, #0xc
    7b80:      	b.hi	0x7fcc <generic_fentry_filter_arg+0x201c>
    7b84:      	lsl	w14, w14, w9
    7b88:      	mov	w1, #0x1402             // =5122
    7b8c:      	tst	w14, w1
    7b90:      	b.eq	0x7fcc <generic_fentry_filter_arg+0x201c>
    7b94:      	cmp	w13, w10
    7b98:      	ccmp	w10, w12, #0x0, le
    7b9c:      	cset	w12, le
    7ba0:      	b	0x7fd8 <generic_fentry_filter_arg+0x2028>
    7ba4:      	str	x29, [sp, #0x28]
    7ba8:      	mov	x19, xzr
    7bac:      	mov	w22, wzr
    7bb0:      	add	x29, x23, #0x10
    7bb4:      	ldr	w8, [x29, x19, lsl #2]
    7bb8:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1050>
    7bbc:      	add	x9, sp, #0x60
    7bc0:      	add	x1, sp, #0x60
    7bc4:      	str	w8, [sp, #0x60]
    7bc8:      	mov	w8, #0x1                // =1
    7bcc:      	ldr	x0, [x0]
    7bd0:      	blr	x8
    7bd4:      	cbz	x0, 0x932c <generic_fentry_filter_arg+0x337c>
    7bd8:      	cbz	w25, 0x7c34 <generic_fentry_filter_arg+0x1c84>
    7bdc:      	ldr	x9, [sp, #0x28]
    7be0:      	mov	x8, xzr
    7be4:      	mov	x10, x25
    7be8:      	b	0x7c00 <generic_fentry_filter_arg+0x1c50>
    7bec:      	add	x8, x8, #0x1
    7bf0:      	sub	x10, x10, #0x1
    7bf4:      	add	x9, x9, #0x1
    7bf8:      	cmp	x8, x25
    7bfc:      	b.eq	0x7c34 <generic_fentry_filter_arg+0x1c84>
    7c00:      	mov	x11, xzr
    7c04:      	cmp	x10, x11
    7c08:      	b.eq	0x7bec <generic_fentry_filter_arg+0x1c3c>
    7c0c:      	ldrb	w12, [x0, x11]
    7c10:      	cbz	w12, 0x7c30 <generic_fentry_filter_arg+0x1c80>
    7c14:      	cmp	x11, #0x62
    7c18:      	b.hi	0x7bec <generic_fentry_filter_arg+0x1c3c>
    7c1c:      	ldrb	w13, [x9, x11]
    7c20:      	add	x11, x11, #0x1
    7c24:      	cmp	w13, w12
    7c28:      	b.eq	0x7c04 <generic_fentry_filter_arg+0x1c54>
    7c2c:      	b	0x7bec <generic_fentry_filter_arg+0x1c3c>
    7c30:      	tbz	w8, #0x1f, 0x8384 <generic_fentry_filter_arg+0x23d4>
    7c34:      	ldr	w9, [x23, #0x8]
    7c38:      	add	w8, w22, #0xc
    7c3c:      	cmp	w8, w9
    7c40:      	b.hs	0x932c <generic_fentry_filter_arg+0x337c>
    7c44:      	add	x19, x19, #0x1
    7c48:      	add	w22, w22, #0x4
    7c4c:      	cmp	x19, #0x64
    7c50:      	b.ne	0x7bb4 <generic_fentry_filter_arg+0x1c04>
    7c54:      	b	0x932c <generic_fentry_filter_arg+0x337c>
    7c58:      	and	w8, w25, #0xffff
    7c5c:      	cmp	w8, #0x90
    7c60:      	b.hi	0x8218 <generic_fentry_filter_arg+0x2268>
    7c64:      	and	w8, w25, #0xff
    7c68:      	mov	w9, #0xab               // =171
    7c6c:      	tst	w25, #0xffff
    7c70:      	mul	w8, w8, w9
    7c74:      	mov	w9, #0x18               // =24
    7c78:      	lsr	w8, w8, #12
    7c7c:      	msub	w8, w8, w9, w25
    7c80:      	b.eq	0x7c94 <generic_fentry_filter_arg+0x1ce4>
    7c84:      	tst	w8, #0xff
    7c88:      	mov	w9, w25
    7c8c:      	mov	w11, w25
    7c90:      	b.eq	0x7cb0 <generic_fentry_filter_arg+0x1d00>
    7c94:      	sub	w8, w25, w8, uxtb
    7c98:      	and	w9, w8, #0xffff
    7c9c:      	add	w8, w8, #0x18
    7ca0:      	and	w11, w8, #0xffff
    7ca4:      	cmp	w9, #0x78
    7ca8:      	b.hi	0x9020 <generic_fentry_filter_arg+0x3070>
    7cac:      	mov	w9, w11
    7cb0:      	and	w8, w9, #0xff
    7cb4:      	mov	w9, #0xab               // =171
    7cb8:      	mul	w8, w8, w9
    7cbc:      	lsr	w8, w8, #12
    7cc0:      	sub	w10, w8, #0x1
    7cc4:      	b	0x9070 <generic_fentry_filter_arg+0x30c0>
    7cc8:      	cmp	x13, x10
    7ccc:      	ccmp	x10, x12, #0x2, ls
    7cd0:      	cset	w12, ls
    7cd4:      	orr	w8, w8, w12
    7cd8:      	cmp	w11, #0x29
    7cdc:      	b.lo	0x8838 <generic_fentry_filter_arg+0x2888>
    7ce0:      	ldp	x13, x12, [x23, #0x30]
    7ce4:      	cmp	w9, #0xc
    7ce8:      	b.eq	0x7cf4 <generic_fentry_filter_arg+0x1d44>
    7cec:      	cmp	w9, #0xa
    7cf0:      	b.ne	0x8228 <generic_fentry_filter_arg+0x2278>
    7cf4:      	cmp	x13, x10
    7cf8:      	ccmp	x10, x12, #0x0, le
    7cfc:      	cset	w12, le
    7d00:      	b	0x8234 <generic_fentry_filter_arg+0x2284>
    7d04:      	mov	x19, xzr
    7d08:      	cmp	w9, #0x29
    7d0c:      	b.ne	0x7d18 <generic_fentry_filter_arg+0x1d68>
    7d10:      	cbz	x10, 0x7d18 <generic_fentry_filter_arg+0x1d68>
    7d14:      	ldrb	w19, [x10, #0x3a]
    7d18:      	cmp	w9, #0x29
    7d1c:      	b.eq	0x7d28 <generic_fentry_filter_arg+0x1d78>
    7d20:      	cmp	w9, #0x7
    7d24:      	b.ne	0x8018 <generic_fentry_filter_arg+0x2068>
    7d28:      	ldrb	w8, [x23, #0x10]
    7d2c:      	adrp	x0, 0x7000 <generic_fentry_filter_arg+0x1050>
    7d30:      	add	x9, sp, #0xac
    7d34:      	add	x1, sp, #0xac
    7d38:      	str	w8, [sp, #0xac]
    7d3c:      	mov	w8, #0x1                // =1
    7d40:      	ldr	x0, [x0]
    7d44:      	blr	x8
    7d48:      	cbz	x0, 0x7db8 <generic_fentry_filter_arg+0x1e08>
    7d4c:      	str	x19, [sp, #0x88]
    7d50:      	mov	w8, #0x1                // =1
    7d54:      	add	x9, sp, #0x88
    7d58:      	add	x1, sp, #0x88
    7d5c:      	blr	x8
    7d60:      	ldr	w9, [x23, #0x4]
    7d64:      	mov	w8, wzr
    7d68:      	cmp	w9, #0x1d
    7d6c:      	b.hi	0x8cd8 <generic_fentry_filter_arg+0x2d28>
    7d70:      	ldr	x19, [sp, #0x30]
    7d74:      	mov	w12, #0x1               // =1
    7d78:      	mov	w10, #0x8400            // =33792
    7d7c:      	lsl	w9, w12, w9
    7d80:      	movk	w10, #0x3003, lsl #16
    7d84:      	tst	w9, w10
    7d88:      	b.ne	0x7834 <generic_fentry_filter_arg+0x1884>
    7d8c:      	mov	w10, #0x800             // =2048
    7d90:      	movk	w10, #0xc, lsl #16
    7d94:      	tst	w9, w10
    7d98:      	b.eq	0x7da4 <generic_fentry_filter_arg+0x1df4>
    7d9c:      	cmp	x0, #0x0
    7da0:      	cset	w8, eq
    7da4:      	mov	w22, w8
    7da8:      	ldp	x16, x15, [sp, #0x40]
    7dac:      	mov	w2, #0x5ea0             // =24224
    7db0:      	ldr	x17, [sp, #0x38]
    7db4:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    7db8:      	ldr	x19, [sp, #0x30]
    7dbc:      	mov	x22, xzr
    7dc0:      	mov	w12, #0x1               // =1
    7dc4:      	b	0x7da8 <generic_fentry_filter_arg+0x1df8>
    7dc8:      	cmp	x12, x8
    7dcc:      	mov	w12, #0x1               // =1
    7dd0:      	b.hi	0x7ddc <generic_fentry_filter_arg+0x1e2c>
    7dd4:      	cmp	x8, x11
    7dd8:      	b.ls	0x6248 <generic_fentry_filter_arg+0x298>
    7ddc:      	cmp	w10, #0x29
    7de0:      	b.lo	0x60ac <generic_fentry_filter_arg+0xfc>
    7de4:      	ldp	x12, x11, [x23, #0x30]
    7de8:      	cmp	w9, #0xc
    7dec:      	b.eq	0x7df8 <generic_fentry_filter_arg+0x1e48>
    7df0:      	cmp	w9, #0xa
    7df4:      	b.ne	0x8264 <generic_fentry_filter_arg+0x22b4>
    7df8:      	cmp	x12, x8
    7dfc:      	mov	w12, #0x1               // =1
    7e00:      	b.gt	0x8278 <generic_fentry_filter_arg+0x22c8>
    7e04:      	cmp	x8, x11
    7e08:      	b.le	0x6248 <generic_fentry_filter_arg+0x298>
    7e0c:      	b	0x8278 <generic_fentry_filter_arg+0x22c8>
    7e10:      	ldr	w8, [x23, #0x4]
    7e14:      	b	0x7e20 <generic_fentry_filter_arg+0x1e70>
    7e18:      	ldr	w8, [x23, #0x4]
    7e1c:      	ldr	x19, [sp, #0x30]
    7e20:      	and	w8, w8, #0xfffffffe
    7e24:      	cmp	w8, #0x18
    7e28:      	cset	w8, eq
    7e2c:      	ldp	x16, x15, [sp, #0x40]
    7e30:      	mov	w2, #0x5ea0             // =24224
    7e34:      	mov	w12, #0x1               // =1
    7e38:      	mov	w22, w8
    7e3c:      	ldr	x17, [sp, #0x38]
    7e40:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    7e44:      	ldr	w11, [x25]
    7e48:      	cmp	w11, w10
    7e4c:      	b.hi	0x6248 <generic_fentry_filter_arg+0x298>
    7e50:      	b	0x7e60 <generic_fentry_filter_arg+0x1eb0>
    7e54:      	ldr	w11, [x25]
    7e58:      	cmp	w11, w10
    7e5c:      	b.lo	0x6248 <generic_fentry_filter_arg+0x298>
    7e60:      	ldr	w10, [x23, #0x8]
    7e64:      	cmp	w10, #0xd
    7e68:      	b.lo	0x93a4 <generic_fentry_filter_arg+0x33f4>
    7e6c:      	ldr	w11, [x23, #0x14]
    7e70:      	cmp	w8, #0x2
    7e74:      	b.le	0x7e98 <generic_fentry_filter_arg+0x1ee8>
    7e78:      	sub	w12, w8, #0x3
    7e7c:      	cmp	w12, #0x2
    7e80:      	b.hs	0x7ed8 <generic_fentry_filter_arg+0x1f28>
    7e84:      	ldr	w12, [x25]
    7e88:      	cmp	w12, w11
    7e8c:      	mov	w12, #0x1               // =1
    7e90:      	b.eq	0x623c <generic_fentry_filter_arg+0x28c>
    7e94:      	b	0x8764 <generic_fentry_filter_arg+0x27b4>
    7e98:      	cmp	w8, #0x1
    7e9c:      	b.eq	0x7ef8 <generic_fentry_filter_arg+0x1f48>
    7ea0:      	cmp	w8, #0x2
    7ea4:      	b.ne	0x8764 <generic_fentry_filter_arg+0x27b4>
    7ea8:      	mov	w12, #0x1               // =1
    7eac:      	cmp	w9, #0xc
    7eb0:      	b.hi	0x8754 <generic_fentry_filter_arg+0x27a4>
    7eb4:      	lsl	w12, w12, w9
    7eb8:      	mov	w13, #0x1402            // =5122
    7ebc:      	tst	w12, w13
    7ec0:      	b.eq	0x8754 <generic_fentry_filter_arg+0x27a4>
    7ec4:      	ldr	w12, [x25]
    7ec8:      	cmp	w12, w11
    7ecc:      	mov	w12, #0x1               // =1
    7ed0:      	b.lt	0x6248 <generic_fentry_filter_arg+0x298>
    7ed4:      	b	0x8764 <generic_fentry_filter_arg+0x27b4>
    7ed8:      	cmp	w8, #0xc
    7edc:      	mov	w12, #0x1               // =1
    7ee0:      	b.ne	0x8764 <generic_fentry_filter_arg+0x27b4>
    7ee4:      	ldr	w12, [x25]
    7ee8:      	tst	w12, w11
    7eec:      	mov	w12, #0x1               // =1
    7ef0:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    7ef4:      	b	0x8764 <generic_fentry_filter_arg+0x27b4>
    7ef8:      	mov	w12, #0x1               // =1
    7efc:      	cmp	w9, #0xc
    7f00:      	b.hi	0x8740 <generic_fentry_filter_arg+0x2790>
    7f04:      	lsl	w12, w12, w9
    7f08:      	mov	w13, #0x1402            // =5122
    7f0c:      	tst	w12, w13
    7f10:      	b.eq	0x8740 <generic_fentry_filter_arg+0x2790>
    7f14:      	ldr	w12, [x25]
    7f18:      	cmp	w12, w11
    7f1c:      	mov	w12, #0x1               // =1
    7f20:      	b.gt	0x6248 <generic_fentry_filter_arg+0x298>
    7f24:      	b	0x8764 <generic_fentry_filter_arg+0x27b4>
    7f28:      	and	w8, w29, #0xffff
    7f2c:      	cmp	w8, #0x201
    7f30:      	b.hs	0x838c <generic_fentry_filter_arg+0x23dc>
    7f34:      	mov	w11, #0x200             // =512
    7f38:      	b	0x88cc <generic_fentry_filter_arg+0x291c>
    7f3c:      	mov	x22, xzr
    7f40:      	ldr	x19, [sp, #0x30]
    7f44:      	ldr	w8, [x23, #0x4]
    7f48:      	cmp	w8, #0x25
    7f4c:      	b.hi	0x6ffc <generic_fentry_filter_arg+0x104c>
    7f50:      	mov	x9, #0x50               // =80
    7f54:      	ldp	x16, x15, [sp, #0x40]
    7f58:      	mov	w12, #0x1               // =1
    7f5c:      	mov	w2, #0x5ea0             // =24224
    7f60:      	movk	x9, #0xc00, lsl #16
    7f64:      	ldr	x17, [sp, #0x38]
    7f68:      	lsl	x8, x12, x8
    7f6c:      	movk	x9, #0x20, lsl #32
    7f70:      	tst	x8, x9
    7f74:      	b.ne	0x8dc8 <generic_fentry_filter_arg+0x2e18>
    7f78:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    7f7c:      	cmp	w8, #0x1
    7f80:      	b.eq	0x85fc <generic_fentry_filter_arg+0x264c>
    7f84:      	cmp	w8, #0x2
    7f88:      	b.ne	0x8608 <generic_fentry_filter_arg+0x2658>
    7f8c:      	ldrb	w11, [x25]
    7f90:      	cmp	w10, w11
    7f94:      	b.hi	0x6248 <generic_fentry_filter_arg+0x298>
    7f98:      	b	0x8608 <generic_fentry_filter_arg+0x2658>
    7f9c:      	cmp	w8, #0x1
    7fa0:      	b.eq	0x8638 <generic_fentry_filter_arg+0x2688>
    7fa4:      	cmp	w8, #0x2
    7fa8:      	b.ne	0x8644 <generic_fentry_filter_arg+0x2694>
    7fac:      	ldrh	w11, [x25]
    7fb0:      	cmp	w10, w11
    7fb4:      	b.hi	0x6248 <generic_fentry_filter_arg+0x298>
    7fb8:      	b	0x8644 <generic_fentry_filter_arg+0x2694>
    7fbc:      	cmp	w8, #0x401
    7fc0:      	b.hs	0x83ec <generic_fentry_filter_arg+0x243c>
    7fc4:      	mov	w11, #0x400             // =1024
    7fc8:      	b	0x8400 <generic_fentry_filter_arg+0x2450>
    7fcc:      	cmp	w13, w10
    7fd0:      	ccmp	w10, w12, #0x2, ls
    7fd4:      	cset	w12, ls
    7fd8:      	orr	w8, w8, w12
    7fdc:      	cmp	w11, #0x19
    7fe0:      	mov	w12, #0x1               // =1
    7fe4:      	b.lo	0x8b0c <generic_fentry_filter_arg+0x2b5c>
    7fe8:      	ldp	w13, w12, [x23, #0x20]
    7fec:      	mov	w14, #0x1               // =1
    7ff0:      	cmp	w9, #0xc
    7ff4:      	b.hi	0x8694 <generic_fentry_filter_arg+0x26e4>
    7ff8:      	lsl	w14, w14, w9
    7ffc:      	mov	w1, #0x1402             // =5122
    8000:      	tst	w14, w1
    8004:      	b.eq	0x8694 <generic_fentry_filter_arg+0x26e4>
    8008:      	cmp	w13, w10
    800c:      	ccmp	w10, w12, #0x0, le
    8010:      	cset	w12, le
    8014:      	b	0x86a0 <generic_fentry_filter_arg+0x26f0>
    8018:      	ldr	x19, [sp, #0x30]
    801c:      	mov	x22, xzr
    8020:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    8024:      	mov	w11, #0xa               // =10
    8028:      	b	0x8038 <generic_fentry_filter_arg+0x2088>
    802c:      	mov	w11, #0x6               // =6
    8030:      	b	0x8038 <generic_fentry_filter_arg+0x2088>
    8034:      	mov	w11, #0x8               // =8
    8038:      	add	x8, x23, #0x10
    803c:      	and	w9, w11, #0xf
    8040:      	ldr	w8, [x8, w9, uxtw #2]
    8044:      	cmn	w8, #0x1
    8048:      	b.eq	0x80f8 <generic_fentry_filter_arg+0x2148>
    804c:      	str	w8, [sp, #0x10]
    8050:      	stp	w13, w11, [sp, #0x1c]
    8054:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8058:      	mov	w8, #0x1                // =1
    805c:      	add	x22, sp, #0x88
    8060:      	add	x1, sp, #0x88
    8064:      	str	x10, [sp, #0x28]
    8068:      	ldr	x0, [x0]
    806c:      	blr	x8
    8070:      	mov	x25, x0
    8074:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8078:      	mov	w8, #0x1                // =1
    807c:      	ldr	x0, [x0]
    8080:      	add	x1, sp, #0x88
    8084:      	blr	x8
    8088:      	mov	x22, xzr
    808c:      	cbz	x25, 0x8d94 <generic_fentry_filter_arg+0x2de4>
    8090:      	ldp	x16, x15, [sp, #0x40]
    8094:      	mov	w2, #0x5ea0             // =24224
    8098:      	mov	w12, #0x1               // =1
    809c:      	ldr	x17, [sp, #0x38]
    80a0:      	cbz	x0, 0x8da4 <generic_fentry_filter_arg+0x2df4>
    80a4:      	mov	x8, x25
    80a8:      	ldr	w25, [sp, #0x20]
    80ac:      	mov	x22, x0
    80b0:      	mov	x0, x8
    80b4:      	str	x8, [sp, #0x8]
    80b8:      	cmp	w25, #0x5
    80bc:      	b.gt	0x810c <generic_fentry_filter_arg+0x215c>
    80c0:      	strb	w29, [x0], #0x1
    80c4:      	ldr	x2, [sp, #0x28]
    80c8:      	mov	w8, #0x4                // =4
    80cc:      	mov	w1, w29
    80d0:      	blr	x8
    80d4:      	ldr	w8, [sp, #0x1c]
    80d8:      	subs	w8, w8, w29
    80dc:      	b.ls	0x8148 <generic_fentry_filter_arg+0x2198>
    80e0:      	ldr	x9, [sp, #0x8]
    80e4:      	and	w1, w8, #0xfff
    80e8:      	mov	w8, #0x4                // =4
    80ec:      	add	x9, x9, x29
    80f0:      	add	x0, x9, #0x1
    80f4:      	b	0x8140 <generic_fentry_filter_arg+0x2190>
    80f8:      	mov	x22, xzr
    80fc:      	ldr	w8, [x23, #0x4]
    8100:      	cmp	w8, #0x25
    8104:      	b.ls	0x8db0 <generic_fentry_filter_arg+0x2e00>
    8108:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    810c:      	strh	w29, [x0], #0x2
    8110:      	ldr	x2, [sp, #0x28]
    8114:      	mov	w8, #0x4                // =4
    8118:      	mov	w1, w29
    811c:      	blr	x8
    8120:      	ldr	w8, [sp, #0x1c]
    8124:      	subs	w8, w8, w29
    8128:      	b.ls	0x8148 <generic_fentry_filter_arg+0x2198>
    812c:      	ldr	x9, [sp, #0x8]
    8130:      	and	w1, w8, #0xfff
    8134:      	mov	w8, #0x4                // =4
    8138:      	add	x9, x9, x29
    813c:      	add	x0, x9, #0x2
    8140:      	mov	x2, x22
    8144:      	blr	x8
    8148:      	ldr	w8, [sp, #0x10]
    814c:      	cmp	w25, #0x4
    8150:      	mov	w12, #0x1               // =1
    8154:      	str	w8, [sp, #0x60]
    8158:      	b.le	0x8190 <generic_fentry_filter_arg+0x21e0>
    815c:      	cmp	w25, #0x7
    8160:      	b.gt	0x83c0 <generic_fentry_filter_arg+0x2410>
    8164:      	cmp	w25, #0x5
    8168:      	b.eq	0x8d48 <generic_fentry_filter_arg+0x2d98>
    816c:      	cmp	w25, #0x6
    8170:      	b.eq	0x8d0c <generic_fentry_filter_arg+0x2d5c>
    8174:      	cmp	w25, #0x7
    8178:      	b.ne	0x8dd0 <generic_fentry_filter_arg+0x2e20>
    817c:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8180:      	mov	w8, #0x1                // =1
    8184:      	add	x9, sp, #0x60
    8188:      	ldr	x0, [x0]
    818c:      	b	0x8d6c <generic_fentry_filter_arg+0x2dbc>
    8190:      	cmp	w25, #0x1
    8194:      	b.le	0x8844 <generic_fentry_filter_arg+0x2894>
    8198:      	cmp	w25, #0x2
    819c:      	b.eq	0x8d34 <generic_fentry_filter_arg+0x2d84>
    81a0:      	cmp	w25, #0x3
    81a4:      	b.eq	0x8cf8 <generic_fentry_filter_arg+0x2d48>
    81a8:      	cmp	w25, #0x4
    81ac:      	b.ne	0x8dd0 <generic_fentry_filter_arg+0x2e20>
    81b0:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    81b4:      	mov	w8, #0x1                // =1
    81b8:      	add	x9, sp, #0x60
    81bc:      	ldr	x0, [x0]
    81c0:      	b	0x8d6c <generic_fentry_filter_arg+0x2dbc>
    81c4:      	cmp	w12, w8
    81c8:      	mov	w12, #0x1               // =1
    81cc:      	b.hi	0x81d8 <generic_fentry_filter_arg+0x2228>
    81d0:      	cmp	w8, w11
    81d4:      	b.ls	0x6248 <generic_fentry_filter_arg+0x298>
    81d8:      	cmp	w10, #0x19
    81dc:      	b.lo	0x60ac <generic_fentry_filter_arg+0xfc>
    81e0:      	ldp	w12, w11, [x23, #0x20]
    81e4:      	mov	w13, #0x1               // =1
    81e8:      	cmp	w9, #0xc
    81ec:      	b.hi	0x86f4 <generic_fentry_filter_arg+0x2744>
    81f0:      	lsl	w13, w13, w9
    81f4:      	mov	w14, #0x1402            // =5122
    81f8:      	tst	w13, w14
    81fc:      	b.eq	0x86f4 <generic_fentry_filter_arg+0x2744>
    8200:      	cmp	w12, w8
    8204:      	mov	w12, #0x1               // =1
    8208:      	b.gt	0x8708 <generic_fentry_filter_arg+0x2758>
    820c:      	cmp	w8, w11
    8210:      	b.le	0x6248 <generic_fentry_filter_arg+0x298>
    8214:      	b	0x8708 <generic_fentry_filter_arg+0x2758>
    8218:      	cmp	w8, #0x101
    821c:      	b.hs	0x86e0 <generic_fentry_filter_arg+0x2730>
    8220:      	mov	w11, #0x100             // =256
    8224:      	b	0x9020 <generic_fentry_filter_arg+0x3070>
    8228:      	cmp	x13, x10
    822c:      	ccmp	x10, x12, #0x2, ls
    8230:      	cset	w12, ls
    8234:      	orr	w8, w8, w12
    8238:      	cmp	w11, #0x39
    823c:      	b.lo	0x8838 <generic_fentry_filter_arg+0x2888>
    8240:      	ldp	x12, x11, [x23, #0x40]
    8244:      	cmp	w9, #0xc
    8248:      	b.eq	0x8254 <generic_fentry_filter_arg+0x22a4>
    824c:      	cmp	w9, #0xa
    8250:      	b.ne	0x8828 <generic_fentry_filter_arg+0x2878>
    8254:      	cmp	x12, x10
    8258:      	ccmp	x10, x11, #0x0, le
    825c:      	cset	w9, le
    8260:      	b	0x8834 <generic_fentry_filter_arg+0x2884>
    8264:      	cmp	x12, x8
    8268:      	mov	w12, #0x1               // =1
    826c:      	b.hi	0x8278 <generic_fentry_filter_arg+0x22c8>
    8270:      	cmp	x8, x11
    8274:      	b.ls	0x6248 <generic_fentry_filter_arg+0x298>
    8278:      	cmp	w10, #0x39
    827c:      	b.lo	0x60ac <generic_fentry_filter_arg+0xfc>
    8280:      	ldp	x11, x10, [x23, #0x40]
    8284:      	cmp	w9, #0xc
    8288:      	b.eq	0x8294 <generic_fentry_filter_arg+0x22e4>
    828c:      	cmp	w9, #0xa
    8290:      	b.ne	0x8864 <generic_fentry_filter_arg+0x28b4>
    8294:      	cmp	x11, x8
    8298:      	b.gt	0x60ac <generic_fentry_filter_arg+0xfc>
    829c:      	cmp	x8, x10
    82a0:      	b.le	0x6248 <generic_fentry_filter_arg+0x298>
    82a4:      	b	0x60ac <generic_fentry_filter_arg+0xfc>
    82a8:      	ldr	x12, [x25]
    82ac:      	cmp	x12, x11
    82b0:      	mov	w12, #0x1               // =1
    82b4:      	b.hi	0x6248 <generic_fentry_filter_arg+0x298>
    82b8:      	b	0x82cc <generic_fentry_filter_arg+0x231c>
    82bc:      	ldr	x12, [x25]
    82c0:      	cmp	x12, x11
    82c4:      	mov	w12, #0x1               // =1
    82c8:      	b.lo	0x6248 <generic_fentry_filter_arg+0x298>
    82cc:      	cmp	w10, #0x19
    82d0:      	b.lo	0x93a4 <generic_fentry_filter_arg+0x33f4>
    82d4:      	ldr	x11, [x23, #0x20]
    82d8:      	cmp	w8, #0x2
    82dc:      	b.le	0x8300 <generic_fentry_filter_arg+0x2350>
    82e0:      	sub	w12, w8, #0x3
    82e4:      	cmp	w12, #0x2
    82e8:      	b.hs	0x8334 <generic_fentry_filter_arg+0x2384>
    82ec:      	ldr	x12, [x25]
    82f0:      	cmp	x12, x11
    82f4:      	mov	w12, #0x1               // =1
    82f8:      	b.eq	0x623c <generic_fentry_filter_arg+0x28c>
    82fc:      	b	0x8b38 <generic_fentry_filter_arg+0x2b88>
    8300:      	cmp	w8, #0x1
    8304:      	b.eq	0x839c <generic_fentry_filter_arg+0x23ec>
    8308:      	cmp	w8, #0x2
    830c:      	b.ne	0x8b38 <generic_fentry_filter_arg+0x2b88>
    8310:      	cmp	w9, #0xc
    8314:      	b.eq	0x8320 <generic_fentry_filter_arg+0x2370>
    8318:      	cmp	w9, #0xa
    831c:      	b.ne	0x8b28 <generic_fentry_filter_arg+0x2b78>
    8320:      	ldr	x12, [x25]
    8324:      	cmp	x12, x11
    8328:      	mov	w12, #0x1               // =1
    832c:      	b.lt	0x6248 <generic_fentry_filter_arg+0x298>
    8330:      	b	0x8b38 <generic_fentry_filter_arg+0x2b88>
    8334:      	cmp	w8, #0xc
    8338:      	mov	w12, #0x1               // =1
    833c:      	b.ne	0x8b38 <generic_fentry_filter_arg+0x2b88>
    8340:      	ldr	x12, [x25]
    8344:      	tst	x12, x11
    8348:      	mov	w12, #0x1               // =1
    834c:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    8350:      	b	0x8b38 <generic_fentry_filter_arg+0x2b88>
    8354:      	cmp	w8, #0xc
    8358:      	b.ne	0x8608 <generic_fentry_filter_arg+0x2658>
    835c:      	ldrb	w11, [x25]
    8360:      	tst	w10, w11
    8364:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    8368:      	b	0x8608 <generic_fentry_filter_arg+0x2658>
    836c:      	cmp	w8, #0xc
    8370:      	b.ne	0x8644 <generic_fentry_filter_arg+0x2694>
    8374:      	ldrh	w11, [x25]
    8378:      	tst	w10, w11
    837c:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    8380:      	b	0x8644 <generic_fentry_filter_arg+0x2694>
    8384:      	mov	w22, #0x1               // =1
    8388:      	b	0x9330 <generic_fentry_filter_arg+0x3380>
    838c:      	cmp	w8, #0x401
    8390:      	b.hs	0x88b8 <generic_fentry_filter_arg+0x2908>
    8394:      	mov	w11, #0x400             // =1024
    8398:      	b	0x88cc <generic_fentry_filter_arg+0x291c>
    839c:      	cmp	w9, #0xc
    83a0:      	b.eq	0x83ac <generic_fentry_filter_arg+0x23fc>
    83a4:      	cmp	w9, #0xa
    83a8:      	b.ne	0x8b14 <generic_fentry_filter_arg+0x2b64>
    83ac:      	ldr	x12, [x25]
    83b0:      	cmp	x12, x11
    83b4:      	mov	w12, #0x1               // =1
    83b8:      	b.gt	0x6248 <generic_fentry_filter_arg+0x298>
    83bc:      	b	0x8b38 <generic_fentry_filter_arg+0x2b88>
    83c0:      	cmp	w25, #0x8
    83c4:      	b.eq	0x8d5c <generic_fentry_filter_arg+0x2dac>
    83c8:      	cmp	w25, #0x9
    83cc:      	b.eq	0x8d20 <generic_fentry_filter_arg+0x2d70>
    83d0:      	cmp	w25, #0xa
    83d4:      	b.ne	0x8dd0 <generic_fentry_filter_arg+0x2e20>
    83d8:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    83dc:      	mov	w8, #0x1                // =1
    83e0:      	add	x9, sp, #0x60
    83e4:      	ldr	x0, [x0]
    83e8:      	b	0x8d6c <generic_fentry_filter_arg+0x2dbc>
    83ec:      	and	w8, w29, #0xffff
    83f0:      	mov	w9, #0x1000             // =4096
    83f4:      	cmp	w8, #0x800
    83f8:      	mov	w8, #0x800              // =2048
    83fc:      	csel	w11, w9, w8, hi
    8400:      	sub	w8, w11, #0x100
    8404:      	ror	w8, w8, #0x8
    8408:      	cmp	w8, #0x2
    840c:      	b.gt	0x8424 <generic_fentry_filter_arg+0x2474>
    8410:      	cbz	w8, 0x8444 <generic_fentry_filter_arg+0x2494>
    8414:      	cmp	w8, #0x1
    8418:      	b.ne	0x843c <generic_fentry_filter_arg+0x248c>
    841c:      	mov	w10, #0x7               // =7
    8420:      	b	0x8450 <generic_fentry_filter_arg+0x24a0>
    8424:      	cmp	w8, #0x3
    8428:      	b.eq	0x844c <generic_fentry_filter_arg+0x249c>
    842c:      	cmp	w8, #0x7
    8430:      	b.ne	0x843c <generic_fentry_filter_arg+0x248c>
    8434:      	mov	w10, #0x9               // =9
    8438:      	b	0x8450 <generic_fentry_filter_arg+0x24a0>
    843c:      	mov	w10, #0xa               // =10
    8440:      	b	0x8450 <generic_fentry_filter_arg+0x24a0>
    8444:      	mov	w10, #0x6               // =6
    8448:      	b	0x8450 <generic_fentry_filter_arg+0x24a0>
    844c:      	mov	w10, #0x8               // =8
    8450:      	add	x8, x23, #0x10
    8454:      	and	w9, w10, #0xf
    8458:      	ldr	w8, [x8, w9, uxtw #2]
    845c:      	cmn	w8, #0x1
    8460:      	b.eq	0x8d90 <generic_fentry_filter_arg+0x2de0>
    8464:      	str	w8, [sp, #0x10]
    8468:      	str	w11, [sp, #0x1c]
    846c:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8470:      	mov	w8, #0x1                // =1
    8474:      	add	x22, sp, #0x88
    8478:      	add	x1, sp, #0x88
    847c:      	str	w10, [sp, #0x28]
    8480:      	ldr	x0, [x0]
    8484:      	blr	x8
    8488:      	str	x0, [sp, #0x20]
    848c:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8490:      	mov	w8, #0x1                // =1
    8494:      	add	x1, sp, #0x88
    8498:      	ldr	x0, [x0]
    849c:      	blr	x8
    84a0:      	ldr	x9, [sp, #0x20]
    84a4:      	mov	x22, xzr
    84a8:      	cbz	x9, 0x8d94 <generic_fentry_filter_arg+0x2de4>
    84ac:      	ldp	x16, x15, [sp, #0x40]
    84b0:      	mov	w2, #0x5ea0             // =24224
    84b4:      	mov	w12, #0x1               // =1
    84b8:      	ldr	x17, [sp, #0x38]
    84bc:      	cbz	x0, 0x8da4 <generic_fentry_filter_arg+0x2df4>
    84c0:      	mov	x8, x9
    84c4:      	ldr	w9, [sp, #0x28]
    84c8:      	mov	x22, x0
    84cc:      	add	x2, x25, #0x4
    84d0:      	mov	x25, x8
    84d4:      	mov	x0, x8
    84d8:      	cmp	w9, #0x5
    84dc:      	b.gt	0x8510 <generic_fentry_filter_arg+0x2560>
    84e0:      	strb	w29, [x0], #0x1
    84e4:      	mov	w8, #0x4                // =4
    84e8:      	mov	w1, w29
    84ec:      	blr	x8
    84f0:      	ldr	w8, [sp, #0x1c]
    84f4:      	subs	w8, w8, w29
    84f8:      	b.ls	0x8544 <generic_fentry_filter_arg+0x2594>
    84fc:      	add	x9, x25, x29
    8500:      	and	w1, w8, #0xfff
    8504:      	mov	w8, #0x4                // =4
    8508:      	add	x0, x9, #0x1
    850c:      	b	0x853c <generic_fentry_filter_arg+0x258c>
    8510:      	strh	w29, [x0], #0x2
    8514:      	mov	w8, #0x4                // =4
    8518:      	mov	w1, w29
    851c:      	blr	x8
    8520:      	ldr	w8, [sp, #0x1c]
    8524:      	subs	w8, w8, w29
    8528:      	b.ls	0x8544 <generic_fentry_filter_arg+0x2594>
    852c:      	add	x9, x25, x29
    8530:      	and	w1, w8, #0xfff
    8534:      	mov	w8, #0x4                // =4
    8538:      	add	x0, x9, #0x2
    853c:      	mov	x2, x22
    8540:      	blr	x8
    8544:      	ldr	w8, [sp, #0x10]
    8548:      	ldp	x16, x15, [sp, #0x40]
    854c:      	mov	w2, #0x5ea0             // =24224
    8550:      	mov	w12, #0x1               // =1
    8554:      	ldr	x17, [sp, #0x38]
    8558:      	str	w8, [sp, #0x60]
    855c:      	ldr	w8, [sp, #0x28]
    8560:      	cmp	w8, #0x4
    8564:      	b.le	0x859c <generic_fentry_filter_arg+0x25ec>
    8568:      	cmp	w8, #0x7
    856c:      	b.gt	0x85d0 <generic_fentry_filter_arg+0x2620>
    8570:      	cmp	w8, #0x5
    8574:      	b.eq	0x8c4c <generic_fentry_filter_arg+0x2c9c>
    8578:      	cmp	w8, #0x6
    857c:      	b.eq	0x8c10 <generic_fentry_filter_arg+0x2c60>
    8580:      	cmp	w8, #0x7
    8584:      	b.ne	0x676c <generic_fentry_filter_arg+0x7bc>
    8588:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    858c:      	mov	w8, #0x1                // =1
    8590:      	add	x9, sp, #0x60
    8594:      	ldr	x0, [x0]
    8598:      	b	0x8c70 <generic_fentry_filter_arg+0x2cc0>
    859c:      	cmp	w8, #0x1
    85a0:      	b.le	0x8674 <generic_fentry_filter_arg+0x26c4>
    85a4:      	cmp	w8, #0x2
    85a8:      	b.eq	0x8c38 <generic_fentry_filter_arg+0x2c88>
    85ac:      	cmp	w8, #0x3
    85b0:      	b.eq	0x8bfc <generic_fentry_filter_arg+0x2c4c>
    85b4:      	cmp	w8, #0x4
    85b8:      	b.ne	0x676c <generic_fentry_filter_arg+0x7bc>
    85bc:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    85c0:      	mov	w8, #0x1                // =1
    85c4:      	add	x9, sp, #0x60
    85c8:      	ldr	x0, [x0]
    85cc:      	b	0x8c70 <generic_fentry_filter_arg+0x2cc0>
    85d0:      	cmp	w8, #0x8
    85d4:      	b.eq	0x8c60 <generic_fentry_filter_arg+0x2cb0>
    85d8:      	cmp	w8, #0x9
    85dc:      	b.eq	0x8c24 <generic_fentry_filter_arg+0x2c74>
    85e0:      	cmp	w8, #0xa
    85e4:      	b.ne	0x676c <generic_fentry_filter_arg+0x7bc>
    85e8:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    85ec:      	mov	w8, #0x1                // =1
    85f0:      	add	x9, sp, #0x60
    85f4:      	ldr	x0, [x0]
    85f8:      	b	0x8c70 <generic_fentry_filter_arg+0x2cc0>
    85fc:      	ldrb	w11, [x25]
    8600:      	cmp	w10, w11
    8604:      	b.lo	0x6248 <generic_fentry_filter_arg+0x298>
    8608:      	cmp	w9, #0x11
    860c:      	b.lo	0x93a4 <generic_fentry_filter_arg+0x33f4>
    8610:      	ldr	w10, [x23, #0x18]
    8614:      	cmp	w8, #0x2
    8618:      	b.le	0x8878 <generic_fentry_filter_arg+0x28c8>
    861c:      	sub	w11, w8, #0x3
    8620:      	cmp	w11, #0x2
    8624:      	b.hs	0x8bb8 <generic_fentry_filter_arg+0x2c08>
    8628:      	ldrb	w11, [x25]
    862c:      	cmp	w10, w11
    8630:      	b.eq	0x623c <generic_fentry_filter_arg+0x28c>
    8634:      	b	0x8ec4 <generic_fentry_filter_arg+0x2f14>
    8638:      	ldrh	w11, [x25]
    863c:      	cmp	w10, w11
    8640:      	b.lo	0x6248 <generic_fentry_filter_arg+0x298>
    8644:      	cmp	w9, #0x11
    8648:      	b.lo	0x93a4 <generic_fentry_filter_arg+0x33f4>
    864c:      	ldr	w10, [x23, #0x18]
    8650:      	cmp	w8, #0x2
    8654:      	b.le	0x8898 <generic_fentry_filter_arg+0x28e8>
    8658:      	sub	w11, w8, #0x3
    865c:      	cmp	w11, #0x2
    8660:      	b.hs	0x8bd0 <generic_fentry_filter_arg+0x2c20>
    8664:      	ldrh	w11, [x25]
    8668:      	cmp	w10, w11
    866c:      	b.eq	0x623c <generic_fentry_filter_arg+0x28c>
    8670:      	b	0x8f08 <generic_fentry_filter_arg+0x2f58>
    8674:      	cbz	w8, 0x8be8 <generic_fentry_filter_arg+0x2c38>
    8678:      	cmp	w8, #0x1
    867c:      	b.ne	0x676c <generic_fentry_filter_arg+0x7bc>
    8680:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8684:      	mov	w8, #0x1                // =1
    8688:      	add	x9, sp, #0x60
    868c:      	ldr	x0, [x0]
    8690:      	b	0x8c70 <generic_fentry_filter_arg+0x2cc0>
    8694:      	cmp	w13, w10
    8698:      	ccmp	w10, w12, #0x2, ls
    869c:      	cset	w12, ls
    86a0:      	orr	w8, w8, w12
    86a4:      	cmp	w11, #0x21
    86a8:      	mov	w12, #0x1               // =1
    86ac:      	b.lo	0x8b0c <generic_fentry_filter_arg+0x2b5c>
    86b0:      	ldp	w12, w11, [x23, #0x28]
    86b4:      	mov	w13, #0x1               // =1
    86b8:      	cmp	w9, #0xc
    86bc:      	b.hi	0x8af8 <generic_fentry_filter_arg+0x2b48>
    86c0:      	lsl	w9, w13, w9
    86c4:      	mov	w13, #0x1402            // =5122
    86c8:      	tst	w9, w13
    86cc:      	b.eq	0x8af8 <generic_fentry_filter_arg+0x2b48>
    86d0:      	cmp	w12, w10
    86d4:      	ccmp	w10, w11, #0x0, le
    86d8:      	cset	w9, le
    86dc:      	b	0x8b04 <generic_fentry_filter_arg+0x2b54>
    86e0:      	and	w8, w25, #0xffff
    86e4:      	cmp	w8, #0x201
    86e8:      	b.hs	0x8c94 <generic_fentry_filter_arg+0x2ce4>
    86ec:      	mov	w11, #0x200             // =512
    86f0:      	b	0x9020 <generic_fentry_filter_arg+0x3070>
    86f4:      	cmp	w12, w8
    86f8:      	mov	w12, #0x1               // =1
    86fc:      	b.hi	0x8708 <generic_fentry_filter_arg+0x2758>
    8700:      	cmp	w8, w11
    8704:      	b.ls	0x6248 <generic_fentry_filter_arg+0x298>
    8708:      	cmp	w10, #0x21
    870c:      	b.lo	0x60ac <generic_fentry_filter_arg+0xfc>
    8710:      	ldp	w11, w10, [x23, #0x28]
    8714:      	cmp	w9, #0xc
    8718:      	b.hi	0x8ca4 <generic_fentry_filter_arg+0x2cf4>
    871c:      	lsl	w9, w12, w9
    8720:      	mov	w13, #0x1402            // =5122
    8724:      	tst	w9, w13
    8728:      	b.eq	0x8ca4 <generic_fentry_filter_arg+0x2cf4>
    872c:      	cmp	w11, w8
    8730:      	b.gt	0x60ac <generic_fentry_filter_arg+0xfc>
    8734:      	cmp	w8, w10
    8738:      	b.le	0x6248 <generic_fentry_filter_arg+0x298>
    873c:      	b	0x60ac <generic_fentry_filter_arg+0xfc>
    8740:      	ldr	w12, [x25]
    8744:      	cmp	w12, w11
    8748:      	mov	w12, #0x1               // =1
    874c:      	b.hi	0x6248 <generic_fentry_filter_arg+0x298>
    8750:      	b	0x8764 <generic_fentry_filter_arg+0x27b4>
    8754:      	ldr	w12, [x25]
    8758:      	cmp	w12, w11
    875c:      	mov	w12, #0x1               // =1
    8760:      	b.lo	0x6248 <generic_fentry_filter_arg+0x298>
    8764:      	cmp	w10, #0x11
    8768:      	b.lo	0x93a4 <generic_fentry_filter_arg+0x33f4>
    876c:      	ldr	w11, [x23, #0x18]
    8770:      	cmp	w8, #0x2
    8774:      	b.le	0x8798 <generic_fentry_filter_arg+0x27e8>
    8778:      	sub	w12, w8, #0x3
    877c:      	cmp	w12, #0x2
    8780:      	b.hs	0x87d8 <generic_fentry_filter_arg+0x2828>
    8784:      	ldr	w12, [x25]
    8788:      	cmp	w12, w11
    878c:      	mov	w12, #0x1               // =1
    8790:      	b.eq	0x623c <generic_fentry_filter_arg+0x28c>
    8794:      	b	0x8f64 <generic_fentry_filter_arg+0x2fb4>
    8798:      	cmp	w8, #0x1
    879c:      	b.eq	0x87f8 <generic_fentry_filter_arg+0x2848>
    87a0:      	cmp	w8, #0x2
    87a4:      	b.ne	0x8f64 <generic_fentry_filter_arg+0x2fb4>
    87a8:      	mov	w12, #0x1               // =1
    87ac:      	cmp	w9, #0xc
    87b0:      	b.hi	0x8f54 <generic_fentry_filter_arg+0x2fa4>
    87b4:      	lsl	w12, w12, w9
    87b8:      	mov	w13, #0x1402            // =5122
    87bc:      	tst	w12, w13
    87c0:      	b.eq	0x8f54 <generic_fentry_filter_arg+0x2fa4>
    87c4:      	ldr	w12, [x25]
    87c8:      	cmp	w12, w11
    87cc:      	mov	w12, #0x1               // =1
    87d0:      	b.lt	0x6248 <generic_fentry_filter_arg+0x298>
    87d4:      	b	0x8f64 <generic_fentry_filter_arg+0x2fb4>
    87d8:      	cmp	w8, #0xc
    87dc:      	mov	w12, #0x1               // =1
    87e0:      	b.ne	0x8f64 <generic_fentry_filter_arg+0x2fb4>
    87e4:      	ldr	w12, [x25]
    87e8:      	tst	w12, w11
    87ec:      	mov	w12, #0x1               // =1
    87f0:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    87f4:      	b	0x8f64 <generic_fentry_filter_arg+0x2fb4>
    87f8:      	mov	w12, #0x1               // =1
    87fc:      	cmp	w9, #0xc
    8800:      	b.hi	0x8f40 <generic_fentry_filter_arg+0x2f90>
    8804:      	lsl	w12, w12, w9
    8808:      	mov	w13, #0x1402            // =5122
    880c:      	tst	w12, w13
    8810:      	b.eq	0x8f40 <generic_fentry_filter_arg+0x2f90>
    8814:      	ldr	w12, [x25]
    8818:      	cmp	w12, w11
    881c:      	mov	w12, #0x1               // =1
    8820:      	b.gt	0x6248 <generic_fentry_filter_arg+0x298>
    8824:      	b	0x8f64 <generic_fentry_filter_arg+0x2fb4>
    8828:      	cmp	x12, x10
    882c:      	ccmp	x10, x11, #0x2, ls
    8830:      	cset	w9, ls
    8834:      	orr	w8, w8, w9
    8838:      	mov	w12, #0x1               // =1
    883c:      	tbz	w8, #0x0, 0x6248 <generic_fentry_filter_arg+0x298>
    8840:      	b	0x60ac <generic_fentry_filter_arg+0xfc>
    8844:      	cbz	w25, 0x8ce4 <generic_fentry_filter_arg+0x2d34>
    8848:      	cmp	w25, #0x1
    884c:      	b.ne	0x8dd0 <generic_fentry_filter_arg+0x2e20>
    8850:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8854:      	mov	w8, #0x1                // =1
    8858:      	add	x9, sp, #0x60
    885c:      	ldr	x0, [x0]
    8860:      	b	0x8d6c <generic_fentry_filter_arg+0x2dbc>
    8864:      	cmp	x11, x8
    8868:      	b.hi	0x60ac <generic_fentry_filter_arg+0xfc>
    886c:      	cmp	x8, x10
    8870:      	b.ls	0x6248 <generic_fentry_filter_arg+0x298>
    8874:      	b	0x60ac <generic_fentry_filter_arg+0xfc>
    8878:      	cmp	w8, #0x1
    887c:      	b.eq	0x8eb8 <generic_fentry_filter_arg+0x2f08>
    8880:      	cmp	w8, #0x2
    8884:      	b.ne	0x8ec4 <generic_fentry_filter_arg+0x2f14>
    8888:      	ldrb	w11, [x25]
    888c:      	cmp	w10, w11
    8890:      	b.hi	0x6248 <generic_fentry_filter_arg+0x298>
    8894:      	b	0x8ec4 <generic_fentry_filter_arg+0x2f14>
    8898:      	cmp	w8, #0x1
    889c:      	b.eq	0x8efc <generic_fentry_filter_arg+0x2f4c>
    88a0:      	cmp	w8, #0x2
    88a4:      	b.ne	0x8f08 <generic_fentry_filter_arg+0x2f58>
    88a8:      	ldrh	w11, [x25]
    88ac:      	cmp	w10, w11
    88b0:      	b.hi	0x6248 <generic_fentry_filter_arg+0x298>
    88b4:      	b	0x8f08 <generic_fentry_filter_arg+0x2f58>
    88b8:      	and	w8, w29, #0xffff
    88bc:      	mov	w9, #0x1000             // =4096
    88c0:      	cmp	w8, #0x800
    88c4:      	mov	w8, #0x800              // =2048
    88c8:      	csel	w11, w9, w8, hi
    88cc:      	sub	w8, w11, #0x100
    88d0:      	ror	w8, w8, #0x8
    88d4:      	cmp	w8, #0x2
    88d8:      	b.gt	0x88f0 <generic_fentry_filter_arg+0x2940>
    88dc:      	cbz	w8, 0x8910 <generic_fentry_filter_arg+0x2960>
    88e0:      	cmp	w8, #0x1
    88e4:      	b.ne	0x8908 <generic_fentry_filter_arg+0x2958>
    88e8:      	mov	w10, #0x7               // =7
    88ec:      	b	0x891c <generic_fentry_filter_arg+0x296c>
    88f0:      	cmp	w8, #0x3
    88f4:      	b.eq	0x8918 <generic_fentry_filter_arg+0x2968>
    88f8:      	cmp	w8, #0x7
    88fc:      	b.ne	0x8908 <generic_fentry_filter_arg+0x2958>
    8900:      	mov	w10, #0x9               // =9
    8904:      	b	0x891c <generic_fentry_filter_arg+0x296c>
    8908:      	mov	w10, #0xa               // =10
    890c:      	b	0x891c <generic_fentry_filter_arg+0x296c>
    8910:      	mov	w10, #0x6               // =6
    8914:      	b	0x891c <generic_fentry_filter_arg+0x296c>
    8918:      	mov	w10, #0x8               // =8
    891c:      	add	x8, x23, #0x10
    8920:      	and	w9, w10, #0xf
    8924:      	ldr	w8, [x8, w9, uxtw #2]
    8928:      	cmn	w8, #0x1
    892c:      	b.eq	0x89e0 <generic_fentry_filter_arg+0x2a30>
    8930:      	str	w8, [sp, #0x1c]
    8934:      	str	w11, [sp, #0x10]
    8938:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    893c:      	mov	w8, #0x1                // =1
    8940:      	add	x22, sp, #0x88
    8944:      	add	x1, sp, #0x88
    8948:      	str	w10, [sp, #0x28]
    894c:      	ldr	x0, [x0]
    8950:      	blr	x8
    8954:      	str	x0, [sp, #0x20]
    8958:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    895c:      	mov	w8, #0x1                // =1
    8960:      	add	x1, sp, #0x88
    8964:      	ldr	x0, [x0]
    8968:      	blr	x8
    896c:      	ldr	x9, [sp, #0x20]
    8970:      	mov	x22, xzr
    8974:      	cbz	x9, 0x7260 <generic_fentry_filter_arg+0x12b0>
    8978:      	ldp	x16, x15, [sp, #0x40]
    897c:      	mov	w2, #0x5ea0             // =24224
    8980:      	mov	w12, #0x1               // =1
    8984:      	ldr	x17, [sp, #0x38]
    8988:      	cbz	x0, 0x7270 <generic_fentry_filter_arg+0x12c0>
    898c:      	mov	x8, x9
    8990:      	ldr	w9, [sp, #0x28]
    8994:      	mov	x22, x0
    8998:      	cmp	w9, #0x5
    899c:      	b.gt	0x89e8 <generic_fentry_filter_arg+0x2a38>
    89a0:      	mov	x0, x8
    89a4:      	mov	x9, x8
    89a8:      	mov	w8, #0x4                // =4
    89ac:      	mov	w1, w29
    89b0:      	mov	x2, x25
    89b4:      	strb	w29, [x0], #0x1
    89b8:      	mov	x25, x9
    89bc:      	blr	x8
    89c0:      	ldr	w8, [sp, #0x10]
    89c4:      	subs	w8, w8, w29
    89c8:      	b.ls	0x8a2c <generic_fentry_filter_arg+0x2a7c>
    89cc:      	add	x9, x25, x29
    89d0:      	and	w1, w8, #0xfff
    89d4:      	mov	w8, #0x4                // =4
    89d8:      	add	x0, x9, #0x1
    89dc:      	b	0x8a24 <generic_fentry_filter_arg+0x2a74>
    89e0:      	mov	x22, xzr
    89e4:      	b	0x726c <generic_fentry_filter_arg+0x12bc>
    89e8:      	mov	x0, x8
    89ec:      	mov	x9, x8
    89f0:      	mov	w8, #0x4                // =4
    89f4:      	mov	w1, w29
    89f8:      	mov	x2, x25
    89fc:      	strh	w29, [x0], #0x2
    8a00:      	mov	x25, x9
    8a04:      	blr	x8
    8a08:      	ldr	w8, [sp, #0x10]
    8a0c:      	subs	w8, w8, w29
    8a10:      	b.ls	0x8a2c <generic_fentry_filter_arg+0x2a7c>
    8a14:      	add	x9, x25, x29
    8a18:      	and	w1, w8, #0xfff
    8a1c:      	mov	w8, #0x4                // =4
    8a20:      	add	x0, x9, #0x2
    8a24:      	mov	x2, x22
    8a28:      	blr	x8
    8a2c:      	ldr	w8, [sp, #0x1c]
    8a30:      	mov	w12, #0x1               // =1
    8a34:      	str	w8, [sp, #0x60]
    8a38:      	ldr	w8, [sp, #0x28]
    8a3c:      	cmp	w8, #0x4
    8a40:      	b.le	0x8a78 <generic_fentry_filter_arg+0x2ac8>
    8a44:      	cmp	w8, #0x7
    8a48:      	b.gt	0x8aac <generic_fentry_filter_arg+0x2afc>
    8a4c:      	cmp	w8, #0x5
    8a50:      	b.eq	0x8e54 <generic_fentry_filter_arg+0x2ea4>
    8a54:      	cmp	w8, #0x6
    8a58:      	b.eq	0x8e18 <generic_fentry_filter_arg+0x2e68>
    8a5c:      	cmp	w8, #0x7
    8a60:      	b.ne	0x8ea4 <generic_fentry_filter_arg+0x2ef4>
    8a64:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8a68:      	mov	w8, #0x1                // =1
    8a6c:      	add	x9, sp, #0x60
    8a70:      	ldr	x0, [x0]
    8a74:      	b	0x8e78 <generic_fentry_filter_arg+0x2ec8>
    8a78:      	cmp	w8, #0x1
    8a7c:      	b.le	0x8ad8 <generic_fentry_filter_arg+0x2b28>
    8a80:      	cmp	w8, #0x2
    8a84:      	b.eq	0x8e40 <generic_fentry_filter_arg+0x2e90>
    8a88:      	cmp	w8, #0x3
    8a8c:      	b.eq	0x8e04 <generic_fentry_filter_arg+0x2e54>
    8a90:      	cmp	w8, #0x4
    8a94:      	b.ne	0x8ea4 <generic_fentry_filter_arg+0x2ef4>
    8a98:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8a9c:      	mov	w8, #0x1                // =1
    8aa0:      	add	x9, sp, #0x60
    8aa4:      	ldr	x0, [x0]
    8aa8:      	b	0x8e78 <generic_fentry_filter_arg+0x2ec8>
    8aac:      	cmp	w8, #0x8
    8ab0:      	b.eq	0x8e68 <generic_fentry_filter_arg+0x2eb8>
    8ab4:      	cmp	w8, #0x9
    8ab8:      	b.eq	0x8e2c <generic_fentry_filter_arg+0x2e7c>
    8abc:      	cmp	w8, #0xa
    8ac0:      	b.ne	0x8ea4 <generic_fentry_filter_arg+0x2ef4>
    8ac4:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8ac8:      	mov	w8, #0x1                // =1
    8acc:      	add	x9, sp, #0x60
    8ad0:      	ldr	x0, [x0]
    8ad4:      	b	0x8e78 <generic_fentry_filter_arg+0x2ec8>
    8ad8:      	cbz	w8, 0x8df0 <generic_fentry_filter_arg+0x2e40>
    8adc:      	cmp	w8, #0x1
    8ae0:      	b.ne	0x8ea4 <generic_fentry_filter_arg+0x2ef4>
    8ae4:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8ae8:      	mov	w8, #0x1                // =1
    8aec:      	add	x9, sp, #0x60
    8af0:      	ldr	x0, [x0]
    8af4:      	b	0x8e78 <generic_fentry_filter_arg+0x2ec8>
    8af8:      	cmp	w12, w10
    8afc:      	ccmp	w10, w11, #0x2, ls
    8b00:      	cset	w9, ls
    8b04:      	orr	w8, w8, w9
    8b08:      	mov	w12, #0x1               // =1
    8b0c:      	tbz	w8, #0x0, 0x6248 <generic_fentry_filter_arg+0x298>
    8b10:      	b	0x60ac <generic_fentry_filter_arg+0xfc>
    8b14:      	ldr	x12, [x25]
    8b18:      	cmp	x12, x11
    8b1c:      	mov	w12, #0x1               // =1
    8b20:      	b.hi	0x6248 <generic_fentry_filter_arg+0x298>
    8b24:      	b	0x8b38 <generic_fentry_filter_arg+0x2b88>
    8b28:      	ldr	x12, [x25]
    8b2c:      	cmp	x12, x11
    8b30:      	mov	w12, #0x1               // =1
    8b34:      	b.lo	0x6248 <generic_fentry_filter_arg+0x298>
    8b38:      	cmp	w10, #0x21
    8b3c:      	b.lo	0x93a4 <generic_fentry_filter_arg+0x33f4>
    8b40:      	ldr	x10, [x23, #0x28]
    8b44:      	cmp	w8, #0x2
    8b48:      	b.le	0x8b78 <generic_fentry_filter_arg+0x2bc8>
    8b4c:      	sub	w9, w8, #0x3
    8b50:      	cmp	w9, #0x2
    8b54:      	b.lo	0x8ba8 <generic_fentry_filter_arg+0x2bf8>
    8b58:      	cmp	w8, #0x6
    8b5c:      	b.eq	0x6248 <generic_fentry_filter_arg+0x298>
    8b60:      	cmp	w8, #0xc
    8b64:      	b.ne	0x60ac <generic_fentry_filter_arg+0xfc>
    8b68:      	ldr	x9, [x25]
    8b6c:      	tst	x9, x10
    8b70:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    8b74:      	b	0x93a4 <generic_fentry_filter_arg+0x33f4>
    8b78:      	cmp	w8, #0x1
    8b7c:      	b.eq	0x8cb8 <generic_fentry_filter_arg+0x2d08>
    8b80:      	cmp	w8, #0x2
    8b84:      	b.ne	0x60ac <generic_fentry_filter_arg+0xfc>
    8b88:      	cmp	w9, #0xc
    8b8c:      	b.eq	0x8b98 <generic_fentry_filter_arg+0x2be8>
    8b90:      	cmp	w9, #0xa
    8b94:      	b.ne	0x9260 <generic_fentry_filter_arg+0x32b0>
    8b98:      	ldr	x9, [x25]
    8b9c:      	cmp	x9, x10
    8ba0:      	b.lt	0x6248 <generic_fentry_filter_arg+0x298>
    8ba4:      	b	0x93a4 <generic_fentry_filter_arg+0x33f4>
    8ba8:      	ldr	x9, [x25]
    8bac:      	cmp	x9, x10
    8bb0:      	b.ne	0x93a4 <generic_fentry_filter_arg+0x33f4>
    8bb4:      	b	0x623c <generic_fentry_filter_arg+0x28c>
    8bb8:      	cmp	w8, #0xc
    8bbc:      	b.ne	0x8ec4 <generic_fentry_filter_arg+0x2f14>
    8bc0:      	ldrb	w11, [x25]
    8bc4:      	tst	w10, w11
    8bc8:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    8bcc:      	b	0x8ec4 <generic_fentry_filter_arg+0x2f14>
    8bd0:      	cmp	w8, #0xc
    8bd4:      	b.ne	0x8f08 <generic_fentry_filter_arg+0x2f58>
    8bd8:      	ldrh	w11, [x25]
    8bdc:      	tst	w10, w11
    8be0:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    8be4:      	b	0x8f08 <generic_fentry_filter_arg+0x2f58>
    8be8:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8bec:      	mov	w8, #0x1                // =1
    8bf0:      	add	x9, sp, #0x60
    8bf4:      	ldr	x0, [x0]
    8bf8:      	b	0x8c70 <generic_fentry_filter_arg+0x2cc0>
    8bfc:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8c00:      	mov	w8, #0x1                // =1
    8c04:      	add	x9, sp, #0x60
    8c08:      	ldr	x0, [x0]
    8c0c:      	b	0x8c70 <generic_fentry_filter_arg+0x2cc0>
    8c10:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8c14:      	mov	w8, #0x1                // =1
    8c18:      	add	x9, sp, #0x60
    8c1c:      	ldr	x0, [x0]
    8c20:      	b	0x8c70 <generic_fentry_filter_arg+0x2cc0>
    8c24:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8c28:      	mov	w8, #0x1                // =1
    8c2c:      	add	x9, sp, #0x60
    8c30:      	ldr	x0, [x0]
    8c34:      	b	0x8c70 <generic_fentry_filter_arg+0x2cc0>
    8c38:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8c3c:      	mov	w8, #0x1                // =1
    8c40:      	add	x9, sp, #0x60
    8c44:      	ldr	x0, [x0]
    8c48:      	b	0x8c70 <generic_fentry_filter_arg+0x2cc0>
    8c4c:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8c50:      	mov	w8, #0x1                // =1
    8c54:      	add	x9, sp, #0x60
    8c58:      	ldr	x0, [x0]
    8c5c:      	b	0x8c70 <generic_fentry_filter_arg+0x2cc0>
    8c60:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8c64:      	mov	w8, #0x1                // =1
    8c68:      	add	x9, sp, #0x60
    8c6c:      	ldr	x0, [x0]
    8c70:      	add	x1, sp, #0x60
    8c74:      	blr	x8
    8c78:      	cbz	x0, 0x8d90 <generic_fentry_filter_arg+0x2de0>
    8c7c:      	mov	w8, #0x1                // =1
    8c80:      	mov	x1, x25
    8c84:      	blr	x8
    8c88:      	cmp	x0, #0x0
    8c8c:      	cset	w22, ne
    8c90:      	b	0x8d94 <generic_fentry_filter_arg+0x2de4>
    8c94:      	cmp	w8, #0x401
    8c98:      	b.hs	0x900c <generic_fentry_filter_arg+0x305c>
    8c9c:      	mov	w11, #0x400             // =1024
    8ca0:      	b	0x9020 <generic_fentry_filter_arg+0x3070>
    8ca4:      	cmp	w11, w8
    8ca8:      	b.hi	0x60ac <generic_fentry_filter_arg+0xfc>
    8cac:      	cmp	w8, w10
    8cb0:      	b.ls	0x6248 <generic_fentry_filter_arg+0x298>
    8cb4:      	b	0x60ac <generic_fentry_filter_arg+0xfc>
    8cb8:      	cmp	w9, #0xc
    8cbc:      	b.eq	0x8cc8 <generic_fentry_filter_arg+0x2d18>
    8cc0:      	cmp	w9, #0xa
    8cc4:      	b.ne	0x9270 <generic_fentry_filter_arg+0x32c0>
    8cc8:      	ldr	x9, [x25]
    8ccc:      	cmp	x9, x10
    8cd0:      	b.gt	0x6248 <generic_fentry_filter_arg+0x298>
    8cd4:      	b	0x93a4 <generic_fentry_filter_arg+0x33f4>
    8cd8:      	ldr	x19, [sp, #0x30]
    8cdc:      	mov	w12, #0x1               // =1
    8ce0:      	b	0x7da4 <generic_fentry_filter_arg+0x1df4>
    8ce4:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8ce8:      	mov	w8, #0x1                // =1
    8cec:      	add	x9, sp, #0x60
    8cf0:      	ldr	x0, [x0]
    8cf4:      	b	0x8d6c <generic_fentry_filter_arg+0x2dbc>
    8cf8:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8cfc:      	mov	w8, #0x1                // =1
    8d00:      	add	x9, sp, #0x60
    8d04:      	ldr	x0, [x0]
    8d08:      	b	0x8d6c <generic_fentry_filter_arg+0x2dbc>
    8d0c:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8d10:      	mov	w8, #0x1                // =1
    8d14:      	add	x9, sp, #0x60
    8d18:      	ldr	x0, [x0]
    8d1c:      	b	0x8d6c <generic_fentry_filter_arg+0x2dbc>
    8d20:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8d24:      	mov	w8, #0x1                // =1
    8d28:      	add	x9, sp, #0x60
    8d2c:      	ldr	x0, [x0]
    8d30:      	b	0x8d6c <generic_fentry_filter_arg+0x2dbc>
    8d34:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8d38:      	mov	w8, #0x1                // =1
    8d3c:      	add	x9, sp, #0x60
    8d40:      	ldr	x0, [x0]
    8d44:      	b	0x8d6c <generic_fentry_filter_arg+0x2dbc>
    8d48:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8d4c:      	mov	w8, #0x1                // =1
    8d50:      	add	x9, sp, #0x60
    8d54:      	ldr	x0, [x0]
    8d58:      	b	0x8d6c <generic_fentry_filter_arg+0x2dbc>
    8d5c:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8d60:      	mov	w8, #0x1                // =1
    8d64:      	add	x9, sp, #0x60
    8d68:      	ldr	x0, [x0]
    8d6c:      	add	x1, sp, #0x60
    8d70:      	blr	x8
    8d74:      	cbz	x0, 0x8d90 <generic_fentry_filter_arg+0x2de0>
    8d78:      	ldr	x1, [sp, #0x8]
    8d7c:      	mov	w8, #0x1                // =1
    8d80:      	blr	x8
    8d84:      	cmp	x0, #0x0
    8d88:      	cset	w22, ne
    8d8c:      	b	0x8d94 <generic_fentry_filter_arg+0x2de4>
    8d90:      	mov	x22, xzr
    8d94:      	ldp	x16, x15, [sp, #0x40]
    8d98:      	mov	w2, #0x5ea0             // =24224
    8d9c:      	mov	w12, #0x1               // =1
    8da0:      	ldr	x17, [sp, #0x38]
    8da4:      	ldr	w8, [x23, #0x4]
    8da8:      	cmp	w8, #0x25
    8dac:      	b.hi	0x6244 <generic_fentry_filter_arg+0x294>
    8db0:      	mov	x9, #0x50               // =80
    8db4:      	lsl	x8, x12, x8
    8db8:      	movk	x9, #0xc00, lsl #16
    8dbc:      	movk	x9, #0x20, lsl #32
    8dc0:      	tst	x8, x9
    8dc4:      	b.eq	0x6244 <generic_fentry_filter_arg+0x294>
    8dc8:      	eor	x22, x22, #0x1
    8dcc:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    8dd0:      	ldp	x16, x15, [sp, #0x40]
    8dd4:      	mov	x22, xzr
    8dd8:      	mov	w2, #0x5ea0             // =24224
    8ddc:      	ldr	x17, [sp, #0x38]
    8de0:      	ldr	w8, [x23, #0x4]
    8de4:      	cmp	w8, #0x25
    8de8:      	b.ls	0x8db0 <generic_fentry_filter_arg+0x2e00>
    8dec:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    8df0:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8df4:      	mov	w8, #0x1                // =1
    8df8:      	add	x9, sp, #0x60
    8dfc:      	ldr	x0, [x0]
    8e00:      	b	0x8e78 <generic_fentry_filter_arg+0x2ec8>
    8e04:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8e08:      	mov	w8, #0x1                // =1
    8e0c:      	add	x9, sp, #0x60
    8e10:      	ldr	x0, [x0]
    8e14:      	b	0x8e78 <generic_fentry_filter_arg+0x2ec8>
    8e18:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8e1c:      	mov	w8, #0x1                // =1
    8e20:      	add	x9, sp, #0x60
    8e24:      	ldr	x0, [x0]
    8e28:      	b	0x8e78 <generic_fentry_filter_arg+0x2ec8>
    8e2c:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8e30:      	mov	w8, #0x1                // =1
    8e34:      	add	x9, sp, #0x60
    8e38:      	ldr	x0, [x0]
    8e3c:      	b	0x8e78 <generic_fentry_filter_arg+0x2ec8>
    8e40:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8e44:      	mov	w8, #0x1                // =1
    8e48:      	add	x9, sp, #0x60
    8e4c:      	ldr	x0, [x0]
    8e50:      	b	0x8e78 <generic_fentry_filter_arg+0x2ec8>
    8e54:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8e58:      	mov	w8, #0x1                // =1
    8e5c:      	add	x9, sp, #0x60
    8e60:      	ldr	x0, [x0]
    8e64:      	b	0x8e78 <generic_fentry_filter_arg+0x2ec8>
    8e68:      	adrp	x0, 0x8000 <generic_fentry_filter_arg+0x2050>
    8e6c:      	mov	w8, #0x1                // =1
    8e70:      	add	x9, sp, #0x60
    8e74:      	ldr	x0, [x0]
    8e78:      	add	x1, sp, #0x60
    8e7c:      	blr	x8
    8e80:      	cbz	x0, 0x8e9c <generic_fentry_filter_arg+0x2eec>
    8e84:      	mov	w8, #0x1                // =1
    8e88:      	mov	x1, x25
    8e8c:      	blr	x8
    8e90:      	cmp	x0, #0x0
    8e94:      	cset	w22, ne
    8e98:      	b	0x7260 <generic_fentry_filter_arg+0x12b0>
    8e9c:      	mov	x22, xzr
    8ea0:      	b	0x7260 <generic_fentry_filter_arg+0x12b0>
    8ea4:      	ldp	x16, x15, [sp, #0x40]
    8ea8:      	mov	x22, xzr
    8eac:      	mov	w2, #0x5ea0             // =24224
    8eb0:      	ldr	x17, [sp, #0x38]
    8eb4:      	b	0x7270 <generic_fentry_filter_arg+0x12c0>
    8eb8:      	ldrb	w11, [x25]
    8ebc:      	cmp	w10, w11
    8ec0:      	b.lo	0x6248 <generic_fentry_filter_arg+0x298>
    8ec4:      	cmp	w9, #0x15
    8ec8:      	b.lo	0x93a4 <generic_fentry_filter_arg+0x33f4>
    8ecc:      	ldr	w9, [x23, #0x1c]
    8ed0:      	cmp	w8, #0x2
    8ed4:      	b.le	0x9218 <generic_fentry_filter_arg+0x3268>
    8ed8:      	sub	w10, w8, #0x3
    8edc:      	cmp	w10, #0x2
    8ee0:      	b.lo	0x9248 <generic_fentry_filter_arg+0x3298>
    8ee4:      	cmp	w8, #0x6
    8ee8:      	b.eq	0x6248 <generic_fentry_filter_arg+0x298>
    8eec:      	cmp	w8, #0xc
    8ef0:      	b.ne	0x60ac <generic_fentry_filter_arg+0xfc>
    8ef4:      	ldrb	w10, [x25]
    8ef8:      	b	0x8f98 <generic_fentry_filter_arg+0x2fe8>
    8efc:      	ldrh	w11, [x25]
    8f00:      	cmp	w10, w11
    8f04:      	b.lo	0x6248 <generic_fentry_filter_arg+0x298>
    8f08:      	cmp	w9, #0x15
    8f0c:      	b.lo	0x93a4 <generic_fentry_filter_arg+0x33f4>
    8f10:      	ldr	w9, [x23, #0x1c]
    8f14:      	cmp	w8, #0x2
    8f18:      	b.le	0x9230 <generic_fentry_filter_arg+0x3280>
    8f1c:      	sub	w10, w8, #0x3
    8f20:      	cmp	w10, #0x2
    8f24:      	b.lo	0x9250 <generic_fentry_filter_arg+0x32a0>
    8f28:      	cmp	w8, #0x6
    8f2c:      	b.eq	0x6248 <generic_fentry_filter_arg+0x298>
    8f30:      	cmp	w8, #0xc
    8f34:      	b.ne	0x60ac <generic_fentry_filter_arg+0xfc>
    8f38:      	ldrh	w10, [x25]
    8f3c:      	b	0x8f98 <generic_fentry_filter_arg+0x2fe8>
    8f40:      	ldr	w12, [x25]
    8f44:      	cmp	w12, w11
    8f48:      	mov	w12, #0x1               // =1
    8f4c:      	b.hi	0x6248 <generic_fentry_filter_arg+0x298>
    8f50:      	b	0x8f64 <generic_fentry_filter_arg+0x2fb4>
    8f54:      	ldr	w12, [x25]
    8f58:      	cmp	w12, w11
    8f5c:      	mov	w12, #0x1               // =1
    8f60:      	b.lo	0x6248 <generic_fentry_filter_arg+0x298>
    8f64:      	cmp	w10, #0x15
    8f68:      	b.lo	0x93a4 <generic_fentry_filter_arg+0x33f4>
    8f6c:      	ldr	w10, [x23, #0x1c]
    8f70:      	cmp	w8, #0x2
    8f74:      	b.le	0x8fa4 <generic_fentry_filter_arg+0x2ff4>
    8f78:      	sub	w9, w8, #0x3
    8f7c:      	cmp	w9, #0x2
    8f80:      	b.lo	0x8fdc <generic_fentry_filter_arg+0x302c>
    8f84:      	cmp	w8, #0x6
    8f88:      	b.eq	0x6248 <generic_fentry_filter_arg+0x298>
    8f8c:      	cmp	w8, #0xc
    8f90:      	b.ne	0x60ac <generic_fentry_filter_arg+0xfc>
    8f94:      	ldr	w9, [x25]
    8f98:      	tst	w9, w10
    8f9c:      	b.ne	0x6248 <generic_fentry_filter_arg+0x298>
    8fa0:      	b	0x93a4 <generic_fentry_filter_arg+0x33f4>
    8fa4:      	cmp	w8, #0x1
    8fa8:      	b.eq	0x8fe4 <generic_fentry_filter_arg+0x3034>
    8fac:      	cmp	w8, #0x2
    8fb0:      	b.ne	0x60ac <generic_fentry_filter_arg+0xfc>
    8fb4:      	cmp	w9, #0xc
    8fb8:      	b.hi	0x9388 <generic_fentry_filter_arg+0x33d8>
    8fbc:      	lsl	w9, w12, w9
    8fc0:      	mov	w11, #0x1402            // =5122
    8fc4:      	tst	w9, w11
    8fc8:      	b.eq	0x9388 <generic_fentry_filter_arg+0x33d8>
    8fcc:      	ldr	w9, [x25]
    8fd0:      	cmp	w9, w10
    8fd4:      	b.lt	0x6248 <generic_fentry_filter_arg+0x298>
    8fd8:      	b	0x93a4 <generic_fentry_filter_arg+0x33f4>
    8fdc:      	ldr	w9, [x25]
    8fe0:      	b	0x9254 <generic_fentry_filter_arg+0x32a4>
    8fe4:      	cmp	w9, #0xc
    8fe8:      	b.hi	0x9398 <generic_fentry_filter_arg+0x33e8>
    8fec:      	lsl	w9, w12, w9
    8ff0:      	mov	w11, #0x1402            // =5122
    8ff4:      	tst	w9, w11
    8ff8:      	b.eq	0x9398 <generic_fentry_filter_arg+0x33e8>
    8ffc:      	ldr	w9, [x25]
    9000:      	cmp	w9, w10
    9004:      	b.gt	0x6248 <generic_fentry_filter_arg+0x298>
    9008:      	b	0x93a4 <generic_fentry_filter_arg+0x33f4>
    900c:      	and	w8, w25, #0xffff
    9010:      	mov	w9, #0x1000             // =4096
    9014:      	cmp	w8, #0x800
    9018:      	mov	w8, #0x800              // =2048
    901c:      	csel	w11, w9, w8, hi
    9020:      	sub	w8, w11, #0x100
    9024:      	ror	w8, w8, #0x8
    9028:      	cmp	w8, #0x2
    902c:      	b.gt	0x9044 <generic_fentry_filter_arg+0x3094>
    9030:      	cbz	w8, 0x9064 <generic_fentry_filter_arg+0x30b4>
    9034:      	cmp	w8, #0x1
    9038:      	b.ne	0x905c <generic_fentry_filter_arg+0x30ac>
    903c:      	mov	w10, #0x7               // =7
    9040:      	b	0x9070 <generic_fentry_filter_arg+0x30c0>
    9044:      	cmp	w8, #0x3
    9048:      	b.eq	0x906c <generic_fentry_filter_arg+0x30bc>
    904c:      	cmp	w8, #0x7
    9050:      	b.ne	0x905c <generic_fentry_filter_arg+0x30ac>
    9054:      	mov	w10, #0x9               // =9
    9058:      	b	0x9070 <generic_fentry_filter_arg+0x30c0>
    905c:      	mov	w10, #0xa               // =10
    9060:      	b	0x9070 <generic_fentry_filter_arg+0x30c0>
    9064:      	mov	w10, #0x6               // =6
    9068:      	b	0x9070 <generic_fentry_filter_arg+0x30c0>
    906c:      	mov	w10, #0x8               // =8
    9070:      	add	x8, x23, #0x10
    9074:      	and	w9, w10, #0xf
    9078:      	ldr	w8, [x8, w9, uxtw #2]
    907c:      	cmn	w8, #0x1
    9080:      	b.eq	0x932c <generic_fentry_filter_arg+0x337c>
    9084:      	stp	w8, w11, [sp, #0x1c]
    9088:      	str	w10, [sp, #0x28]
    908c:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9090:      	mov	w8, #0x1                // =1
    9094:      	add	x19, sp, #0x88
    9098:      	add	x1, sp, #0x88
    909c:      	ldr	x0, [x0]
    90a0:      	blr	x8
    90a4:      	mov	x9, x0
    90a8:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    90ac:      	mov	w8, #0x1                // =1
    90b0:      	ldr	x0, [x0]
    90b4:      	add	x1, sp, #0x88
    90b8:      	mov	x19, x9
    90bc:      	blr	x8
    90c0:      	mov	x22, xzr
    90c4:      	cbz	x19, 0x9330 <generic_fentry_filter_arg+0x3380>
    90c8:      	mov	w12, #0x1               // =1
    90cc:      	cbz	x0, 0x9334 <generic_fentry_filter_arg+0x3384>
    90d0:      	ldr	w22, [sp, #0x28]
    90d4:      	str	x0, [sp, #0x10]
    90d8:      	mov	x0, x19
    90dc:      	cmp	w22, #0x5
    90e0:      	b.gt	0x911c <generic_fentry_filter_arg+0x316c>
    90e4:      	strb	w25, [x0], #0x1
    90e8:      	mov	w8, #0x4                // =4
    90ec:      	mov	w1, w25
    90f0:      	mov	x2, x29
    90f4:      	blr	x8
    90f8:      	ldr	w8, [sp, #0x20]
    90fc:      	subs	w8, w8, w25
    9100:      	b.ls	0x9154 <generic_fentry_filter_arg+0x31a4>
    9104:      	add	x9, x19, x25
    9108:      	and	w1, w8, #0xfff
    910c:      	mov	w8, #0x4                // =4
    9110:      	ldr	x2, [sp, #0x10]
    9114:      	add	x0, x9, #0x1
    9118:      	b	0x9150 <generic_fentry_filter_arg+0x31a0>
    911c:      	strh	w25, [x0], #0x2
    9120:      	mov	w8, #0x4                // =4
    9124:      	mov	w1, w25
    9128:      	mov	x2, x29
    912c:      	blr	x8
    9130:      	ldr	w8, [sp, #0x20]
    9134:      	subs	w8, w8, w25
    9138:      	b.ls	0x9154 <generic_fentry_filter_arg+0x31a4>
    913c:      	add	x9, x19, x25
    9140:      	ldr	x2, [sp, #0x10]
    9144:      	and	w1, w8, #0xfff
    9148:      	mov	w8, #0x4                // =4
    914c:      	add	x0, x9, #0x2
    9150:      	blr	x8
    9154:      	ldr	w8, [sp, #0x1c]
    9158:      	cmp	w22, #0x4
    915c:      	str	w8, [sp, #0x60]
    9160:      	b.le	0x9198 <generic_fentry_filter_arg+0x31e8>
    9164:      	cmp	w22, #0x7
    9168:      	b.gt	0x91cc <generic_fentry_filter_arg+0x321c>
    916c:      	cmp	w22, #0x5
    9170:      	b.eq	0x92e4 <generic_fentry_filter_arg+0x3334>
    9174:      	cmp	w22, #0x6
    9178:      	b.eq	0x92a8 <generic_fentry_filter_arg+0x32f8>
    917c:      	cmp	w22, #0x7
    9180:      	b.ne	0x932c <generic_fentry_filter_arg+0x337c>
    9184:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9188:      	mov	w8, #0x1                // =1
    918c:      	add	x9, sp, #0x60
    9190:      	ldr	x0, [x0]
    9194:      	b	0x9308 <generic_fentry_filter_arg+0x3358>
    9198:      	cmp	w22, #0x1
    919c:      	b.le	0x91f8 <generic_fentry_filter_arg+0x3248>
    91a0:      	cmp	w22, #0x2
    91a4:      	b.eq	0x92d0 <generic_fentry_filter_arg+0x3320>
    91a8:      	cmp	w22, #0x3
    91ac:      	b.eq	0x9294 <generic_fentry_filter_arg+0x32e4>
    91b0:      	cmp	w22, #0x4
    91b4:      	b.ne	0x932c <generic_fentry_filter_arg+0x337c>
    91b8:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    91bc:      	mov	w8, #0x1                // =1
    91c0:      	add	x9, sp, #0x60
    91c4:      	ldr	x0, [x0]
    91c8:      	b	0x9308 <generic_fentry_filter_arg+0x3358>
    91cc:      	cmp	w22, #0x8
    91d0:      	b.eq	0x92f8 <generic_fentry_filter_arg+0x3348>
    91d4:      	cmp	w22, #0x9
    91d8:      	b.eq	0x92bc <generic_fentry_filter_arg+0x330c>
    91dc:      	cmp	w22, #0xa
    91e0:      	b.ne	0x932c <generic_fentry_filter_arg+0x337c>
    91e4:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    91e8:      	mov	w8, #0x1                // =1
    91ec:      	add	x9, sp, #0x60
    91f0:      	ldr	x0, [x0]
    91f4:      	b	0x9308 <generic_fentry_filter_arg+0x3358>
    91f8:      	cbz	w22, 0x9280 <generic_fentry_filter_arg+0x32d0>
    91fc:      	cmp	w22, #0x1
    9200:      	b.ne	0x932c <generic_fentry_filter_arg+0x337c>
    9204:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9208:      	mov	w8, #0x1                // =1
    920c:      	add	x9, sp, #0x60
    9210:      	ldr	x0, [x0]
    9214:      	b	0x9308 <generic_fentry_filter_arg+0x3358>
    9218:      	cmp	w8, #0x1
    921c:      	b.eq	0x9378 <generic_fentry_filter_arg+0x33c8>
    9220:      	cmp	w8, #0x2
    9224:      	b.ne	0x60ac <generic_fentry_filter_arg+0xfc>
    9228:      	ldrb	w10, [x25]
    922c:      	b	0x939c <generic_fentry_filter_arg+0x33ec>
    9230:      	cmp	w8, #0x1
    9234:      	b.eq	0x9380 <generic_fentry_filter_arg+0x33d0>
    9238:      	cmp	w8, #0x2
    923c:      	b.ne	0x60ac <generic_fentry_filter_arg+0xfc>
    9240:      	ldrh	w10, [x25]
    9244:      	b	0x939c <generic_fentry_filter_arg+0x33ec>
    9248:      	ldrb	w10, [x25]
    924c:      	b	0x9254 <generic_fentry_filter_arg+0x32a4>
    9250:      	ldrh	w10, [x25]
    9254:      	cmp	w9, w10
    9258:      	b.eq	0x623c <generic_fentry_filter_arg+0x28c>
    925c:      	b	0x93a4 <generic_fentry_filter_arg+0x33f4>
    9260:      	ldr	x9, [x25]
    9264:      	cmp	x9, x10
    9268:      	b.lo	0x6248 <generic_fentry_filter_arg+0x298>
    926c:      	b	0x93a4 <generic_fentry_filter_arg+0x33f4>
    9270:      	ldr	x9, [x25]
    9274:      	cmp	x9, x10
    9278:      	b.hi	0x6248 <generic_fentry_filter_arg+0x298>
    927c:      	b	0x93a4 <generic_fentry_filter_arg+0x33f4>
    9280:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9284:      	mov	w8, #0x1                // =1
    9288:      	add	x9, sp, #0x60
    928c:      	ldr	x0, [x0]
    9290:      	b	0x9308 <generic_fentry_filter_arg+0x3358>
    9294:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9298:      	mov	w8, #0x1                // =1
    929c:      	add	x9, sp, #0x60
    92a0:      	ldr	x0, [x0]
    92a4:      	b	0x9308 <generic_fentry_filter_arg+0x3358>
    92a8:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    92ac:      	mov	w8, #0x1                // =1
    92b0:      	add	x9, sp, #0x60
    92b4:      	ldr	x0, [x0]
    92b8:      	b	0x9308 <generic_fentry_filter_arg+0x3358>
    92bc:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    92c0:      	mov	w8, #0x1                // =1
    92c4:      	add	x9, sp, #0x60
    92c8:      	ldr	x0, [x0]
    92cc:      	b	0x9308 <generic_fentry_filter_arg+0x3358>
    92d0:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    92d4:      	mov	w8, #0x1                // =1
    92d8:      	add	x9, sp, #0x60
    92dc:      	ldr	x0, [x0]
    92e0:      	b	0x9308 <generic_fentry_filter_arg+0x3358>
    92e4:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    92e8:      	mov	w8, #0x1                // =1
    92ec:      	add	x9, sp, #0x60
    92f0:      	ldr	x0, [x0]
    92f4:      	b	0x9308 <generic_fentry_filter_arg+0x3358>
    92f8:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    92fc:      	mov	w8, #0x1                // =1
    9300:      	add	x9, sp, #0x60
    9304:      	ldr	x0, [x0]
    9308:      	add	x1, sp, #0x60
    930c:      	blr	x8
    9310:      	cbz	x0, 0x932c <generic_fentry_filter_arg+0x337c>
    9314:      	mov	w8, #0x1                // =1
    9318:      	mov	x1, x19
    931c:      	blr	x8
    9320:      	cmp	x0, #0x0
    9324:      	cset	w22, ne
    9328:      	b	0x9330 <generic_fentry_filter_arg+0x3380>
    932c:      	mov	x22, xzr
    9330:      	mov	w12, #0x1               // =1
    9334:      	ldr	w8, [x23, #0x4]
    9338:      	ldp	x16, x15, [sp, #0x40]
    933c:      	mov	w2, #0x5ea0             // =24224
    9340:      	cmp	w8, #0x25
    9344:      	ldr	x17, [sp, #0x38]
    9348:      	b.hi	0x9370 <generic_fentry_filter_arg+0x33c0>
    934c:      	mov	x9, #0x50               // =80
    9350:      	ldr	x19, [sp, #0x30]
    9354:      	lsl	x8, x12, x8
    9358:      	movk	x9, #0xc00, lsl #16
    935c:      	movk	x9, #0x20, lsl #32
    9360:      	tst	x8, x9
    9364:      	b.eq	0x6244 <generic_fentry_filter_arg+0x294>
    9368:      	cmp	x22, #0x0
    936c:      	b	0x6240 <generic_fentry_filter_arg+0x290>
    9370:      	ldr	x19, [sp, #0x30]
    9374:      	b	0x6244 <generic_fentry_filter_arg+0x294>
    9378:      	ldrb	w10, [x25]
    937c:      	b	0x938c <generic_fentry_filter_arg+0x33dc>
    9380:      	ldrh	w10, [x25]
    9384:      	b	0x938c <generic_fentry_filter_arg+0x33dc>
    9388:      	ldr	w9, [x25]
    938c:      	cmp	w9, w10
    9390:      	b.lo	0x6248 <generic_fentry_filter_arg+0x298>
    9394:      	b	0x93a4 <generic_fentry_filter_arg+0x33f4>
    9398:      	ldr	w9, [x25]
    939c:      	cmp	w9, w10
    93a0:      	b.hi	0x6248 <generic_fentry_filter_arg+0x298>
    93a4:      	orr	w8, w8, #0x2
    93a8:      	cmp	w8, #0x6
    93ac:      	b.eq	0x6248 <generic_fentry_filter_arg+0x298>
    93b0:      	b	0x60ac <generic_fentry_filter_arg+0xfc>
    93b4:      	nop
    93b8:      	nop
    93bc:      	nop

00000000000093c0 <generic_fentry_actions>:
    93c0:      	sub	sp, sp, #0xe0
    93c4:      	str	x29, [sp, #0x90]
    93c8:      	stp	x30, x25, [sp, #0xa0]
    93cc:      	stp	x24, x23, [sp, #0xb0]
    93d0:      	stp	x22, x21, [sp, #0xc0]
    93d4:      	stp	x20, x19, [sp, #0xd0]
    93d8:      	str	x0, [sp, #0x50]
    93dc:      	str	wzr, [sp, #0x5c]
    93e0:      	adrp	x29, 0x9000 <generic_fentry_filter_arg+0x3050>
    93e4:      	mov	w8, #0x1                // =1
    93e8:      	add	x9, sp, #0x5c
    93ec:      	add	x1, sp, #0x5c
    93f0:      	ldr	x29, [x29]
    93f4:      	mov	x0, x29
    93f8:      	blr	x8
    93fc:      	cbz	x0, 0x9e84 <generic_fentry_actions+0xac4>
    9400:      	mov	w8, #0x5f04             // =24324
    9404:      	ldr	w19, [x0, x8]
    9408:      	cmp	w19, #0x2
    940c:      	b.lt	0x9e84 <generic_fentry_actions+0xac4>
    9410:      	mov	w8, #0x5ef8             // =24312
    9414:      	add	x1, x0, x8
    9418:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    941c:      	mov	w8, #0x1                // =1
    9420:      	ldr	x0, [x0]
    9424:      	blr	x8
    9428:      	cbz	x0, 0x9e84 <generic_fentry_actions+0xac4>
    942c:      	and	x8, x19, #0x7ff
    9430:      	add	x9, sp, #0x60
    9434:      	add	x1, sp, #0x60
    9438:      	ldr	w8, [x0, x8]
    943c:      	str	wzr, [sp, #0x60]
    9440:      	add	w8, w8, w19
    9444:      	and	w8, w8, #0x7ff
    9448:      	add	x21, x0, x8
    944c:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9450:      	mov	w8, #0x1                // =1
    9454:      	ldr	x0, [x0]
    9458:      	blr	x8
    945c:      	cbz	x0, 0x94a4 <generic_fentry_actions+0xe4>
    9460:      	ldrb	w8, [x0]
    9464:      	mov	w11, #0x6               // =6
    9468:      	mov	w14, #0x7               // =7
    946c:      	mov	w10, #0x8               // =8
    9470:      	mov	w12, #0x5               // =5
    9474:      	mov	w13, #0x9               // =9
    9478:      	ands	w8, w8, #0xff
    947c:      	cset	w9, eq
    9480:      	cmp	w8, #0x0
    9484:      	str	w9, [sp, #0x48]
    9488:      	mov	w9, #0x4                // =4
    948c:      	csel	x8, x11, x14, eq
    9490:      	csel	x11, x10, x13, eq
    9494:      	str	x8, [sp, #0x30]
    9498:      	csel	x8, x9, x12, eq
    949c:      	stp	x11, x8, [sp, #0x38]
    94a0:      	b	0x94c4 <generic_fentry_actions+0x104>
    94a4:      	mov	w8, #0x1                // =1
    94a8:      	str	w8, [sp, #0x48]
    94ac:      	mov	w8, #0x4                // =4
    94b0:      	str	x8, [sp, #0x40]
    94b4:      	mov	w8, #0x8                // =8
    94b8:      	str	x8, [sp, #0x38]
    94bc:      	mov	w8, #0x6                // =6
    94c0:      	str	x8, [sp, #0x30]
    94c4:      	adrp	x25, 0x9000 <generic_fentry_filter_arg+0x3050>
    94c8:      	mov	w23, wzr
    94cc:      	mov	w19, wzr
    94d0:      	ldr	x25, [x25]
    94d4:      	add	x20, sp, #0x64
    94d8:      	mov	w8, #0x1                // =1
    94dc:      	str	w8, [sp, #0x4c]
    94e0:      	b	0x94f4 <generic_fentry_actions+0x134>
    94e4:      	mov	w19, wzr
    94e8:      	add	w23, w23, #0x1
    94ec:      	cmp	w23, #0x3
    94f0:      	b.eq	0x9e60 <generic_fentry_actions+0xaa0>
    94f4:      	ldr	w9, [x21]
    94f8:      	lsl	w8, w19, #2
    94fc:      	add	w8, w8, #0x4
    9500:      	cmp	w8, w9
    9504:      	b.hs	0x9e60 <generic_fentry_actions+0xaa0>
    9508:      	add	x8, x21, w19, uxtw #2
    950c:      	add	x1, sp, #0x64
    9510:      	mov	x0, x29
    9514:      	ldrsw	x24, [x8, #0x4]
    9518:      	str	wzr, [sp, #0x64]
    951c:      	mov	w8, #0x1                // =1
    9520:      	blr	x8
    9524:      	cbz	x0, 0x94e4 <generic_fentry_actions+0x124>
    9528:      	mov	x22, x0
    952c:      	cmp	w24, #0x7
    9530:      	b.gt	0x9560 <generic_fentry_actions+0x1a0>
    9534:      	cmp	w24, #0x3
    9538:      	b.gt	0x95b0 <generic_fentry_actions+0x1f0>
    953c:      	cmp	w24, #0x1
    9540:      	b.gt	0x9630 <generic_fentry_actions+0x270>
    9544:      	cbz	w24, 0x9794 <generic_fentry_actions+0x3d4>
    9548:      	cmp	w24, #0x1
    954c:      	b.eq	0x9640 <generic_fentry_actions+0x280>
    9550:      	adrp	x25, 0x9000 <generic_fentry_filter_arg+0x3050>
    9554:      	b	0x9898 <generic_fentry_actions+0x4d8>
    9558:      	nop
    955c:      	nop
    9560:      	cmp	w24, #0xb
    9564:      	b.gt	0x9608 <generic_fentry_actions+0x248>
    9568:      	sub	w8, w24, #0xa
    956c:      	cmp	w8, #0x2
    9570:      	b.lo	0x96a4 <generic_fentry_actions+0x2e4>
    9574:      	cmp	w24, #0x8
    9578:      	b.eq	0x96ec <generic_fentry_actions+0x32c>
    957c:      	cmp	w24, #0x9
    9580:      	b.ne	0x989c <generic_fentry_actions+0x4dc>
    9584:      	add	w19, w19, #0x1
    9588:      	add	x8, x21, w19, uxtw #2
    958c:      	ldr	w0, [x8, #0x4]
    9590:      	ldr	w8, [sp, #0x48]
    9594:      	add	x25, sp, #0x68
    9598:      	cbz	w8, 0x983c <generic_fentry_actions+0x47c>
    959c:      	sxtw	x8, w0
    95a0:      	mov	w9, #0x6d               // =109
    95a4:      	blr	x9
    95a8:      	mov	w20, #0x2               // =2
    95ac:      	b	0x9850 <generic_fentry_actions+0x490>
    95b0:      	sub	w8, w24, #0x6
    95b4:      	cmp	w8, #0x2
    95b8:      	b.lo	0x96d8 <generic_fentry_actions+0x318>
    95bc:      	cmp	w24, #0x4
    95c0:      	b.eq	0x96f4 <generic_fentry_actions+0x334>
    95c4:      	cmp	w24, #0x5
    95c8:      	b.ne	0x989c <generic_fentry_actions+0x4dc>
    95cc:      	add	w8, w19, #0x1
    95d0:      	add	x9, x21, #0x4
    95d4:      	add	w19, w19, #0x2
    95d8:      	ldr	w8, [x9, w8, uxtw #2]
    95dc:      	ldr	w20, [x9, w19, uxtw #2]
    95e0:      	stp	xzr, xzr, [sp, #0x68]
    95e4:      	and	x8, x8, #0x7
    95e8:      	cmp	w8, #0x4
    95ec:      	b.hi	0x9600 <generic_fentry_actions+0x240>
    95f0:      	add	x9, x22, x8, lsl #2
    95f4:      	mov	w10, #0x5ea0            // =24224
    95f8:      	ldr	w9, [x9, x10]
    95fc:      	cbz	w9, 0x9a78 <generic_fentry_actions+0x6b8>
    9600:      	add	x20, sp, #0x64
    9604:      	b	0x989c <generic_fentry_actions+0x4dc>
    9608:      	cmp	w24, #0xc
    960c:      	b.eq	0x9844 <generic_fentry_actions+0x484>
    9610:      	cmp	w24, #0xd
    9614:      	b.eq	0x9704 <generic_fentry_actions+0x344>
    9618:      	cmp	w24, #0xe
    961c:      	b.ne	0x989c <generic_fentry_actions+0x4dc>
    9620:      	ldr	x20, [sp, #0x38]
    9624:      	add	x25, sp, #0x68
    9628:      	add	w19, w19, #0x2
    962c:      	b	0x9850 <generic_fentry_actions+0x490>
    9630:      	cmp	w24, #0x2
    9634:      	b.eq	0x982c <generic_fentry_actions+0x46c>
    9638:      	cmp	w24, #0x3
    963c:      	b.ne	0x9550 <generic_fentry_actions+0x190>
    9640:      	add	w8, w19, #0x1
    9644:      	add	x9, x21, #0x4
    9648:      	add	w19, w19, #0x2
    964c:      	ldr	w20, [x9, w19, uxtw #2]
    9650:      	mov	x25, x21
    9654:      	ldr	w21, [x9, w8, uxtw #2]
    9658:      	str	wzr, [sp, #0x78]
    965c:      	stp	xzr, xzr, [sp, #0x68]
    9660:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9664:      	mov	w8, #0x1                // =1
    9668:      	add	x9, sp, #0x78
    966c:      	add	x1, sp, #0x78
    9670:      	ldr	x0, [x0]
    9674:      	blr	x8
    9678:      	cbz	x0, 0x968c <generic_fentry_actions+0x2cc>
    967c:      	and	x8, x21, #0x7
    9680:      	cmp	w8, #0x4
    9684:      	b.ls	0x98b4 <generic_fentry_actions+0x4f4>
    9688:      	mov	w0, wzr
    968c:      	mov	x21, x25
    9690:      	adrp	x25, 0x9000 <generic_fentry_filter_arg+0x3050>
    9694:      	add	x20, sp, #0x64
    9698:      	ldr	x25, [x25]
    969c:      	cbnz	w0, 0x94e4 <generic_fentry_actions+0x124>
    96a0:      	b	0x989c <generic_fentry_actions+0x4dc>
    96a4:      	add	w19, w19, #0x1
    96a8:      	add	x8, x21, w19, uxtw #2
    96ac:      	ldr	w8, [x8, #0x4]
    96b0:      	and	x8, x8, #0x7
    96b4:      	cmp	w8, #0x4
    96b8:      	b.hi	0x96cc <generic_fentry_actions+0x30c>
    96bc:      	add	x9, x22, x8, lsl #2
    96c0:      	mov	w10, #0x5ea0            // =24224
    96c4:      	ldr	w9, [x9, x10]
    96c8:      	cbz	w9, 0x98d0 <generic_fentry_actions+0x510>
    96cc:      	mov	w0, wzr
    96d0:      	cbnz	w0, 0x94e4 <generic_fentry_actions+0x124>
    96d4:      	b	0x989c <generic_fentry_actions+0x4dc>
    96d8:      	add	w19, w19, #0x1
    96dc:      	add	x8, x21, w19, uxtw #2
    96e0:      	ldr	w8, [x8, #0x4]
    96e4:      	str	w8, [x22, #0x78]
    96e8:      	b	0x989c <generic_fentry_actions+0x4dc>
    96ec:      	str	wzr, [sp, #0x4c]
    96f0:      	b	0x989c <generic_fentry_actions+0x4dc>
    96f4:      	ldr	x20, [sp, #0x40]
    96f8:      	add	x25, sp, #0x68
    96fc:      	add	w19, w19, #0x1
    9700:      	b	0x9850 <generic_fentry_actions+0x490>
    9704:      	mov	w8, #0xe                // =14
    9708:      	blr	x8
    970c:      	str	x0, [sp, #0x88]
    9710:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9714:      	mov	w8, #0x1                // =1
    9718:      	add	x9, sp, #0x88
    971c:      	ldr	x0, [x0]
    9720:      	add	x1, sp, #0x88
    9724:      	blr	x8
    9728:      	cbz	x0, 0x989c <generic_fentry_actions+0x4dc>
    972c:      	ldur	x8, [x0, #0x4]
    9730:      	mov	x20, x21
    9734:      	add	x21, sp, #0x78
    9738:      	add	x1, sp, #0x78
    973c:      	str	x8, [sp, #0x78]
    9740:      	mov	w8, #0x2                // =2
    9744:      	mov	x0, x25
    9748:      	str	w8, [sp, #0x80]
    974c:      	mov	w8, #0x1                // =1
    9750:      	blr	x8
    9754:      	mov	w9, #0x1                // =1
    9758:      	str	w9, [sp, #0x98]
    975c:      	cbz	x0, 0x9a08 <generic_fentry_actions+0x648>
    9760:      	ldaxr	w8, [x0]
    9764:      	add	w8, w8, #0x1
    9768:      	stlxr	w9, w8, [x0]
    976c:      	cbnz	w9, 0x9760 <generic_fentry_actions+0x3a0>
    9770:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9774:      	mov	w8, #0x3                // =3
    9778:      	add	x9, sp, #0x88
    977c:      	ldr	x0, [x0]
    9780:      	add	x1, sp, #0x88
    9784:      	blr	x8
    9788:      	mov	x21, x20
    978c:      	add	x20, sp, #0x64
    9790:      	b	0x989c <generic_fentry_actions+0x4dc>
    9794:      	add	w8, w19, #0x1
    9798:      	add	x9, x21, #0x4
    979c:      	ldr	w25, [x9, w8, uxtw #2]
    97a0:      	add	w8, w19, #0x2
    97a4:      	ldr	w20, [x9, w8, uxtw #2]
    97a8:      	mov	w8, #0x7d               // =125
    97ac:      	blr	x8
    97b0:      	str	x0, [sp, #0x68]
    97b4:      	str	wzr, [sp, #0x88]
    97b8:      	str	x25, [sp, #0x18]
    97bc:      	cbz	w25, 0x9d5c <generic_fentry_actions+0x99c>
    97c0:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    97c4:      	mov	w8, #0x1                // =1
    97c8:      	add	x9, sp, #0x88
    97cc:      	ldr	x0, [x0]
    97d0:      	add	x1, sp, #0x88
    97d4:      	blr	x8
    97d8:      	cbz	x0, 0x9d5c <generic_fentry_actions+0x99c>
    97dc:      	mov	x25, x0
    97e0:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    97e4:      	mov	w8, #0x1                // =1
    97e8:      	ldr	x0, [x0]
    97ec:      	add	x9, sp, #0x88
    97f0:      	add	x1, sp, #0x88
    97f4:      	blr	x8
    97f8:      	ldr	x8, [x22, #0x60]
    97fc:      	mov	x2, x0
    9800:      	cmp	w20, #0x2
    9804:      	str	x8, [x25]
    9808:      	ldr	x8, [x22, #0x70]
    980c:      	str	x8, [x25, #0x8]
    9810:      	b.eq	0x9b7c <generic_fentry_actions+0x7bc>
    9814:      	cmp	w20, #0x1
    9818:      	b.eq	0x9b70 <generic_fentry_actions+0x7b0>
    981c:      	cbnz	w20, 0x9d5c <generic_fentry_actions+0x99c>
    9820:      	ldr	w8, [x22, #0x7c]
    9824:      	str	x21, [sp, #0x8]
    9828:      	b	0x9b84 <generic_fentry_actions+0x7c4>
    982c:      	mov	w0, #0x9                // =9
    9830:      	ldr	w8, [sp, #0x48]
    9834:      	add	x25, sp, #0x68
    9838:      	cbnz	w8, 0x959c <generic_fentry_actions+0x1dc>
    983c:      	mov	w20, #0x3               // =3
    9840:      	b	0x9850 <generic_fentry_actions+0x490>
    9844:      	ldr	x20, [sp, #0x30]
    9848:      	add	x25, sp, #0x68
    984c:      	add	w19, w19, #0x3
    9850:      	str	wzr, [sp, #0x68]
    9854:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9858:      	mov	w8, #0x1                // =1
    985c:      	add	x1, sp, #0x68
    9860:      	ldr	x0, [x0]
    9864:      	blr	x8
    9868:      	cbz	x0, 0x9890 <generic_fentry_actions+0x4d0>
    986c:      	add	x8, x0, x20, lsl #3
    9870:      	nop
    9874:      	nop
    9878:      	nop
    987c:      	nop
    9880:      	ldaxr	x9, [x8]
    9884:      	add	x9, x9, #0x1
    9888:      	stlxr	w10, x9, [x8]
    988c:      	cbnz	w10, 0x9880 <generic_fentry_actions+0x4c0>
    9890:      	adrp	x25, 0x9000 <generic_fentry_filter_arg+0x3050>
    9894:      	add	x20, sp, #0x64
    9898:      	ldr	x25, [x25]
    989c:      	add	w19, w19, #0x1
    98a0:      	str	x24, [x22, #0x70]
    98a4:      	add	w23, w23, #0x1
    98a8:      	cmp	w23, #0x3
    98ac:      	b.ne	0x94f4 <generic_fentry_actions+0x134>
    98b0:      	b	0x9e60 <generic_fentry_actions+0xaa0>
    98b4:      	add	x9, x22, x8, lsl #2
    98b8:      	mov	w10, #0x5ea0            // =24224
    98bc:      	ldr	w9, [x9, x10]
    98c0:      	cbz	w9, 0x9968 <generic_fentry_actions+0x5a8>
    98c4:      	mov	x21, x25
    98c8:      	mov	w0, wzr
    98cc:      	b	0x9690 <generic_fentry_actions+0x2d0>
    98d0:      	add	x8, x22, x8, lsl #3
    98d4:      	ldr	x8, [x8, #0x5e78]
    98d8:      	and	x8, x8, #0x7ff
    98dc:      	add	x8, x22, x8
    98e0:      	ldr	x8, [x8, #0xb8]
    98e4:      	str	x8, [sp, #0x78]
    98e8:      	cbz	x8, 0x96cc <generic_fentry_actions+0x30c>
    98ec:      	cmp	w24, #0xa
    98f0:      	b.ne	0x9b50 <generic_fentry_actions+0x790>
    98f4:      	mov	w8, #0xe                // =14
    98f8:      	add	x25, sp, #0x68
    98fc:      	mov	x20, x21
    9900:      	blr	x8
    9904:      	lsr	x8, x0, #32
    9908:      	mov	x21, x0
    990c:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9910:      	str	w8, [sp, #0x68]
    9914:      	mov	w8, #0x1                // =1
    9918:      	add	x1, sp, #0x68
    991c:      	ldr	x0, [x0]
    9920:      	blr	x8
    9924:      	cbz	x0, 0x995c <generic_fentry_actions+0x59c>
    9928:      	ldr	w8, [x0]
    992c:      	mov	x3, xzr
    9930:      	add	x9, sp, #0x78
    9934:      	add	x1, sp, #0x78
    9938:      	stp	w8, w21, [sp, #0x68]
    993c:      	ldr	x8, [x0, #0x8]
    9940:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9944:      	add	x2, sp, #0x68
    9948:      	str	x8, [sp, #0x70]
    994c:      	mov	w8, #0x2                // =2
    9950:      	ldr	x0, [x0]
    9954:      	blr	x8
    9958:      	mov	w0, wzr
    995c:      	adrp	x25, 0x9000 <generic_fentry_filter_arg+0x3050>
    9960:      	mov	x21, x20
    9964:      	b	0x9694 <generic_fentry_actions+0x2d4>
    9968:      	add	x8, x22, x8, lsl #3
    996c:      	mov	x21, x0
    9970:      	ldr	x8, [x8, #0x5e78]
    9974:      	str	wzr, [sp, #0x74]
    9978:      	and	x8, x8, #0x7ff
    997c:      	add	x8, x22, x8
    9980:      	ldr	w8, [x8, #0x90]
    9984:      	str	w8, [sp, #0x70]
    9988:      	mov	w8, #0xe                // =14
    998c:      	blr	x8
    9990:      	lsr	x8, x0, #32
    9994:      	cmp	w24, #0x1
    9998:      	str	x8, [sp, #0x68]
    999c:      	b.ne	0x9b34 <generic_fentry_actions+0x774>
    99a0:      	and	x8, x20, #0x7
    99a4:      	cmp	w8, #0x4
    99a8:      	b.hi	0x9688 <generic_fentry_actions+0x2c8>
    99ac:      	add	x9, x22, x8, lsl #2
    99b0:      	mov	w10, #0x5ea0            // =24224
    99b4:      	add	x20, sp, #0x68
    99b8:      	ldr	w9, [x9, x10]
    99bc:      	cbnz	w9, 0x9688 <generic_fentry_actions+0x2c8>
    99c0:      	add	x8, x22, x8, lsl #3
    99c4:      	mov	x0, x21
    99c8:      	ldr	x8, [x8, #0x5e78]
    99cc:      	and	x8, x8, #0x7ff
    99d0:      	add	x2, x22, x8
    99d4:      	ldr	w8, [x2, #0x90]!
    99d8:      	and	x8, x8, #0xfff
    99dc:      	add	x1, x8, #0x8
    99e0:      	mov	w8, #0x4                // =4
    99e4:      	blr	x8
    99e8:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    99ec:      	mov	x3, xzr
    99f0:      	mov	w8, #0x2                // =2
    99f4:      	ldr	x0, [x0]
    99f8:      	add	x1, sp, #0x68
    99fc:      	mov	x2, x21
    9a00:      	blr	x8
    9a04:      	b	0x9688 <generic_fentry_actions+0x2c8>
    9a08:      	mov	w8, #0x2                // =2
    9a0c:      	add	x10, sp, #0x98
    9a10:      	add	x1, sp, #0x78
    9a14:      	add	x2, sp, #0x98
    9a18:      	mov	x0, x25
    9a1c:      	mov	w3, #0x1                // =1
    9a20:      	blr	x8
    9a24:      	cbz	x0, 0x9770 <generic_fentry_actions+0x3b0>
    9a28:      	mov	x21, x0
    9a2c:      	adrp	x25, 0x9000 <generic_fentry_filter_arg+0x3050>
    9a30:      	add	x9, sp, #0x68
    9a34:      	add	x1, sp, #0x68
    9a38:      	neg	w8, w21
    9a3c:      	strh	w8, [sp, #0x68]
    9a40:      	mov	w8, #0x3                // =3
    9a44:      	strh	w8, [sp, #0x6a]
    9a48:      	mov	x8, #0x3b               // =59
    9a4c:      	movk	x8, #0x2, lsl #32
    9a50:      	stur	x8, [sp, #0x6c]
    9a54:      	mov	w8, #0x1                // =1
    9a58:      	ldr	x25, [x25]
    9a5c:      	mov	x0, x25
    9a60:      	blr	x8
    9a64:      	cbz	x0, 0x9dfc <generic_fentry_actions+0xa3c>
    9a68:      	ldr	w8, [x0]
    9a6c:      	add	w8, w8, #0x1
    9a70:      	str	w8, [x0]
    9a74:      	b	0x9e24 <generic_fentry_actions+0xa64>
    9a78:      	add	x8, x22, x8, lsl #3
    9a7c:      	ldr	x8, [x8, #0x5e78]
    9a80:      	and	x8, x8, #0x7ff
    9a84:      	add	x8, x22, x8
    9a88:      	ldr	w8, [x8, #0x90]
    9a8c:      	str	w8, [sp, #0x70]
    9a90:      	mov	w8, #0xe                // =14
    9a94:      	blr	x8
    9a98:      	lsr	x8, x0, #32
    9a9c:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9aa0:      	add	x9, sp, #0x68
    9aa4:      	str	x8, [sp, #0x68]
    9aa8:      	mov	w8, #0x1                // =1
    9aac:      	add	x1, sp, #0x68
    9ab0:      	ldr	x0, [x0]
    9ab4:      	blr	x8
    9ab8:      	cbz	x0, 0x9600 <generic_fentry_actions+0x240>
    9abc:      	and	x8, x20, #0x7
    9ac0:      	cmp	w8, #0x4
    9ac4:      	b.hi	0x9600 <generic_fentry_actions+0x240>
    9ac8:      	add	x9, x22, x8, lsl #2
    9acc:      	mov	w10, #0x5ea0            // =24224
    9ad0:      	ldr	w9, [x9, x10]
    9ad4:      	cbnz	w9, 0x9600 <generic_fentry_actions+0x240>
    9ad8:      	add	x8, x22, x8, lsl #3
    9adc:      	mov	x20, x21
    9ae0:      	mov	x21, x0
    9ae4:      	ldr	x8, [x8, #0x5e78]
    9ae8:      	str	wzr, [sp, #0x74]
    9aec:      	and	x8, x8, #0x7ff
    9af0:      	add	x8, x22, x8
    9af4:      	ldr	w8, [x8, #0x90]
    9af8:      	str	w8, [sp, #0x70]
    9afc:      	mov	w8, #0xe                // =14
    9b00:      	blr	x8
    9b04:      	lsr	x8, x0, #32
    9b08:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9b0c:      	mov	x3, xzr
    9b10:      	str	x8, [sp, #0x68]
    9b14:      	mov	w8, #0x2                // =2
    9b18:      	add	x9, sp, #0x68
    9b1c:      	add	x1, sp, #0x68
    9b20:      	ldr	x0, [x0]
    9b24:      	mov	x2, x21
    9b28:      	mov	x21, x20
    9b2c:      	blr	x8
    9b30:      	b	0x9600 <generic_fentry_actions+0x240>
    9b34:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9b38:      	mov	w8, #0x3                // =3
    9b3c:      	add	x9, sp, #0x68
    9b40:      	ldr	x0, [x0]
    9b44:      	add	x1, sp, #0x68
    9b48:      	blr	x8
    9b4c:      	b	0x968c <generic_fentry_actions+0x2cc>
    9b50:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9b54:      	mov	w8, #0x3                // =3
    9b58:      	add	x9, sp, #0x78
    9b5c:      	ldr	x0, [x0]
    9b60:      	add	x1, sp, #0x78
    9b64:      	blr	x8
    9b68:      	cbnz	w0, 0x94e4 <generic_fentry_actions+0x124>
    9b6c:      	b	0x989c <generic_fentry_actions+0x4dc>
    9b70:      	ldr	w8, [x22, #0x10]
    9b74:      	str	x21, [sp, #0x8]
    9b78:      	b	0x9b84 <generic_fentry_actions+0x7c4>
    9b7c:      	str	x21, [sp, #0x8]
    9b80:      	mov	x8, xzr
    9b84:      	str	x8, [x25, #0x10]
    9b88:      	str	x25, [sp, #0x10]
    9b8c:      	add	x0, x25, #0x18
    9b90:      	mov	w8, #0x4                // =4
    9b94:      	mov	w9, #0xc8               // =200
    9b98:      	mov	w1, #0xc8               // =200
    9b9c:      	str	x0, [sp, #0x20]
    9ba0:      	blr	x8
    9ba4:      	str	wzr, [sp, #0x2c]
    9ba8:      	adrp	x25, 0x9000 <generic_fentry_filter_arg+0x3050>
    9bac:      	mov	w8, #0x5e78             // =24184
    9bb0:      	mov	x21, xzr
    9bb4:      	ldr	x25, [x25]
    9bb8:      	add	x20, x22, x8
    9bbc:      	b	0x9bd0 <generic_fentry_actions+0x810>
    9bc0:      	add	x21, x21, #0x4
    9bc4:      	add	x20, x20, #0x8
    9bc8:      	cmp	x21, #0x14
    9bcc:      	b.eq	0x9cf8 <generic_fentry_actions+0x938>
    9bd0:      	str	wzr, [sp, #0x78]
    9bd4:      	mov	w8, #0x1                // =1
    9bd8:      	add	x9, sp, #0x78
    9bdc:      	add	x1, sp, #0x78
    9be0:      	mov	x0, x29
    9be4:      	blr	x8
    9be8:      	cbz	x0, 0x9cf8 <generic_fentry_actions+0x938>
    9bec:      	mov	w8, #0x5ef8             // =24312
    9bf0:      	add	x1, x0, x8
    9bf4:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9bf8:      	mov	w8, #0x1                // =1
    9bfc:      	ldr	x0, [x0]
    9c00:      	blr	x8
    9c04:      	cbz	x0, 0x9cf8 <generic_fentry_actions+0x938>
    9c08:      	add	x8, x0, x21
    9c0c:      	ldr	w8, [x8, #0x40]
    9c10:      	cmn	w8, #0x1
    9c14:      	b.eq	0x9cf8 <generic_fentry_actions+0x938>
    9c18:      	ldr	x8, [x20]
    9c1c:      	ldr	w9, [x22, #0x4]
    9c20:      	cmp	x8, x9
    9c24:      	b.ge	0x9cf8 <generic_fentry_actions+0x938>
    9c28:      	cmp	x21, #0x10
    9c2c:      	b.eq	0x9c8c <generic_fentry_actions+0x8cc>
    9c30:      	str	wzr, [sp, #0x78]
    9c34:      	mov	w8, #0x1                // =1
    9c38:      	add	x9, sp, #0x78
    9c3c:      	add	x1, sp, #0x78
    9c40:      	mov	x0, x29
    9c44:      	blr	x8
    9c48:      	cbz	x0, 0x9c88 <generic_fentry_actions+0x8c8>
    9c4c:      	mov	w8, #0x5ef8             // =24312
    9c50:      	add	x1, x0, x8
    9c54:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9c58:      	mov	w8, #0x1                // =1
    9c5c:      	ldr	x0, [x0]
    9c60:      	blr	x8
    9c64:      	cbz	x0, 0x9c88 <generic_fentry_actions+0x8c8>
    9c68:      	add	x8, x0, x21
    9c6c:      	ldr	w9, [x8, #0x44]
    9c70:      	ldr	x8, [x20]
    9c74:      	cmn	w9, #0x1
    9c78:      	b.eq	0x9c8c <generic_fentry_actions+0x8cc>
    9c7c:      	ldr	w9, [x20, #0x8]
    9c80:      	sub	w9, w9, w8
    9c84:      	b	0x9c98 <generic_fentry_actions+0x8d8>
    9c88:      	ldr	x8, [x20]
    9c8c:      	ldr	w9, [x22, #0x4]
    9c90:      	sub	w9, w9, w8
    9c94:      	add	w9, w9, #0x4
    9c98:      	cmp	w9, #0x1
    9c9c:      	b.lt	0x9bc0 <generic_fentry_actions+0x800>
    9ca0:      	mov	w10, #0x3ffc            // =16380
    9ca4:      	cmp	w9, #0x28
    9ca8:      	add	w8, w8, w10
    9cac:      	mov	w10, #0x28              // =40
    9cb0:      	csel	w29, w9, w10, lt
    9cb4:      	ldr	w9, [sp, #0x2c]
    9cb8:      	and	x8, x8, #0x3fff
    9cbc:      	add	x8, x22, x8
    9cc0:      	mov	w1, w29
    9cc4:      	add	x2, x8, #0x90
    9cc8:      	mov	w8, #0x4                // =4
    9ccc:      	and	w25, w9, #0xff
    9cd0:      	ldr	x9, [sp, #0x20]
    9cd4:      	add	x0, x9, x25
    9cd8:      	blr	x8
    9cdc:      	add	w8, w29, w25
    9ce0:      	adrp	x25, 0x9000 <generic_fentry_filter_arg+0x3050>
    9ce4:      	adrp	x29, 0x9000 <generic_fentry_filter_arg+0x3050>
    9ce8:      	str	w8, [sp, #0x2c]
    9cec:      	ldr	x25, [x25]
    9cf0:      	ldr	x29, [x29]
    9cf4:      	b	0x9bc0 <generic_fentry_actions+0x800>
    9cf8:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9cfc:      	mov	w8, #0x1                // =1
    9d00:      	ldr	x0, [x0]
    9d04:      	ldr	x1, [sp, #0x10]
    9d08:      	blr	x8
    9d0c:      	ldr	x21, [sp, #0x8]
    9d10:      	cbz	x0, 0x9d3c <generic_fentry_actions+0x97c>
    9d14:      	ldr	x9, [sp, #0x68]
    9d18:      	ldr	x11, [sp, #0x18]
    9d1c:      	mov	x10, #-0x4240           // =-16960
    9d20:      	movk	x10, #0xfff0, lsl #16
    9d24:      	ldr	x8, [x0]
    9d28:      	madd	x9, x11, x10, x9
    9d2c:      	cmp	x8, x9
    9d30:      	b.ls	0x9d3c <generic_fentry_actions+0x97c>
    9d34:      	str	wzr, [sp, #0x4c]
    9d38:      	b	0x9d64 <generic_fentry_actions+0x9a4>
    9d3c:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9d40:      	mov	x3, xzr
    9d44:      	mov	w8, #0x2                // =2
    9d48:      	ldr	x0, [x0]
    9d4c:      	ldr	x1, [sp, #0x10]
    9d50:      	add	x9, sp, #0x68
    9d54:      	add	x2, sp, #0x68
    9d58:      	blr	x8
    9d5c:      	adrp	x25, 0x9000 <generic_fentry_filter_arg+0x3050>
    9d60:      	ldr	x25, [x25]
    9d64:      	add	w8, w19, #0x3
    9d68:      	add	x20, sp, #0x64
    9d6c:      	add	x8, x21, w8, uxtw #2
    9d70:      	ldr	w8, [x8, #0x4]
    9d74:      	cbz	w8, 0x9da0 <generic_fentry_actions+0x9e0>
    9d78:      	ldrb	w8, [x22, #0x1]
    9d7c:      	adrp	x1, 0x9000 <generic_fentry_filter_arg+0x3050>
    9d80:      	ldr	x0, [sp, #0x50]
    9d84:      	mov	x2, xzr
    9d88:      	orr	w8, w8, #0x2
    9d8c:      	strb	w8, [x22, #0x1]
    9d90:      	mov	w8, #0x1b               // =27
    9d94:      	ldr	x1, [x1]
    9d98:      	blr	x8
    9d9c:      	str	x0, [x22, #0x80]
    9da0:      	add	w8, w19, #0x4
    9da4:      	add	x8, x21, w8, uxtw #2
    9da8:      	ldr	w8, [x8, #0x4]
    9dac:      	cbz	w8, 0x9ddc <generic_fentry_actions+0xa1c>
    9db0:      	ldrb	w8, [x22, #0x1]
    9db4:      	adrp	x1, 0x9000 <generic_fentry_filter_arg+0x3050>
    9db8:      	ldr	x0, [sp, #0x50]
    9dbc:      	mov	w9, #0x100              // =256
    9dc0:      	mov	w2, #0x100              // =256
    9dc4:      	orr	w8, w8, #0x4
    9dc8:      	strb	w8, [x22, #0x1]
    9dcc:      	mov	w8, #0x1b               // =27
    9dd0:      	ldr	x1, [x1]
    9dd4:      	blr	x8
    9dd8:      	str	x0, [x22, #0x88]
    9ddc:      	add	w19, w19, #0x5
    9de0:      	add	x8, x21, w19, uxtw #2
    9de4:      	ldr	w8, [x8, #0x4]
    9de8:      	cbz	w8, 0x989c <generic_fentry_actions+0x4dc>
    9dec:      	ldrb	w8, [x22, #0x1]
    9df0:      	orr	w8, w8, #0x8
    9df4:      	strb	w8, [x22, #0x1]
    9df8:      	b	0x989c <generic_fentry_actions+0x4dc>
    9dfc:      	mov	w8, #0x1                // =1
    9e00:      	mov	x3, xzr
    9e04:      	add	x9, sp, #0x9c
    9e08:      	str	w8, [sp, #0x9c]
    9e0c:      	mov	w8, #0x2                // =2
    9e10:      	add	x10, sp, #0x68
    9e14:      	add	x1, sp, #0x68
    9e18:      	add	x2, sp, #0x9c
    9e1c:      	mov	x0, x25
    9e20:      	blr	x8
    9e24:      	adrp	x25, 0x9000 <generic_fentry_filter_arg+0x3050>
    9e28:      	ldr	x25, [x25]
    9e2c:      	cbz	w21, 0x9770 <generic_fentry_actions+0x3b0>
    9e30:      	mov	w8, #0x1                // =1
    9e34:      	add	x9, sp, #0x78
    9e38:      	add	x1, sp, #0x78
    9e3c:      	mov	x0, x25
    9e40:      	blr	x8
    9e44:      	cbz	x0, 0x9770 <generic_fentry_actions+0x3b0>
    9e48:      	ldr	w8, [sp, #0x98]
    9e4c:      	ldaxr	w9, [x0]
    9e50:      	add	w9, w9, w8
    9e54:      	stlxr	w10, w9, [x0]
    9e58:      	cbnz	w10, 0x9e4c <generic_fentry_actions+0xa8c>
    9e5c:      	b	0x9770 <generic_fentry_actions+0x3b0>
    9e60:      	ldr	w8, [sp, #0x4c]
    9e64:      	cbz	w8, 0x9e84 <generic_fentry_actions+0xac4>
    9e68:      	adrp	x1, 0x9000 <generic_fentry_filter_arg+0x3050>
    9e6c:      	mov	w8, #0x5                // =5
    9e70:      	mov	w9, #0xc                // =12
    9e74:      	ldr	x1, [x1]
    9e78:      	ldr	x0, [sp, #0x50]
    9e7c:      	mov	w2, #0x5                // =5
    9e80:      	blr	x9
    9e84:      	ldp	x20, x19, [sp, #0xd0]
    9e88:      	mov	w0, wzr
    9e8c:      	ldr	x29, [sp, #0x90]
    9e90:      	ldp	x22, x21, [sp, #0xc0]
    9e94:      	ldp	x24, x23, [sp, #0xb0]
    9e98:      	ldp	x30, x25, [sp, #0xa0]
    9e9c:      	add	sp, sp, #0xe0
    9ea0:      	ret
    9ea4:      	nop
    9ea8:      	nop
    9eac:      	nop

0000000000009eb0 <generic_fentry_output>:
    9eb0:      	sub	sp, sp, #0xc0
    9eb4:      	str	x29, [sp, #0x70]
    9eb8:      	stp	x30, x25, [sp, #0x80]
    9ebc:      	stp	x24, x23, [sp, #0x90]
    9ec0:      	stp	x22, x21, [sp, #0xa0]
    9ec4:      	stp	x20, x19, [sp, #0xb0]
    9ec8:      	mov	x20, x0
    9ecc:      	str	wzr, [sp, #0x4]
    9ed0:      	adrp	x0, 0x9000 <generic_fentry_filter_arg+0x3050>
    9ed4:      	mov	w8, #0x1                // =1
    9ed8:      	ldr	x0, [x0]
    9edc:      	add	x9, sp, #0x4
    9ee0:      	add	x1, sp, #0x4
    9ee4:      	blr	x8
    9ee8:      	cbz	x0, 0xa490 <generic_fentry_output+0x5e0>
    9eec:      	adrp	x21, 0x9000 <generic_fentry_filter_arg+0x3050>
    9ef0:      	ldr	x8, [x0, #0x5ee8]
    9ef4:      	mov	x19, x0
    9ef8:      	ldr	x21, [x21]
    9efc:      	cbz	x8, 0xa188 <generic_fentry_output+0x2d8>
    9f00:      	mov	w8, #0xe                // =14
    9f04:      	blr	x8
    9f08:      	mov	w8, #0x23               // =35
    9f0c:      	lsr	x22, x0, #32
    9f10:      	blr	x8
    9f14:      	str	w22, [sp, #0x28]
    9f18:      	mov	w8, #0x1                // =1
    9f1c:      	add	x9, sp, #0x28
    9f20:      	mov	x23, x0
    9f24:      	add	x1, sp, #0x28
    9f28:      	mov	x0, x21
    9f2c:      	blr	x8
    9f30:      	cbz	x0, 0xa188 <generic_fentry_output+0x2d8>
    9f34:      	add	x2, x23, #0xb50
    9f38:      	mov	w29, #0x8               // =8
    9f3c:      	add	x8, sp, #0x78
    9f40:      	mov	w9, #0x4                // =4
    9f44:      	mov	x22, x0
    9f48:      	add	x24, x0, #0x28
    9f4c:      	add	x0, sp, #0x78
    9f50:      	mov	w1, #0x8                // =8
    9f54:      	mov	w25, #0x4               // =4
    9f58:      	blr	x9
    9f5c:      	ldr	x8, [sp, #0x78]
    9f60:      	mov	w9, #0x48               // =72
    9f64:      	add	x10, sp, #0x28
    9f68:      	mov	w11, #0x4               // =4
    9f6c:      	ldr	x2, [sp, #0x78]
    9f70:      	add	x0, sp, #0x28
    9f74:      	mov	w1, #0x48               // =72
    9f78:      	blr	x11
    9f7c:      	ldr	x8, [sp, #0x30]
    9f80:      	mov	w9, #0x4                // =4
    9f84:      	mov	x0, x24
    9f88:      	mov	w1, #0x4                // =4
    9f8c:      	add	x8, x8, #0x218
    9f90:      	ldr	x8, [sp, #0x30]
    9f94:      	add	x2, x8, #0x218
    9f98:      	blr	x9
    9f9c:      	ldr	x8, [sp, #0x38]
    9fa0:      	add	x0, x22, #0x2c
    9fa4:      	mov	w9, #0x4                // =4
    9fa8:      	mov	w1, #0x4                // =4
    9fac:      	add	x8, x8, #0x4d8
    9fb0:      	ldr	x8, [sp, #0x38]
    9fb4:      	add	x2, x8, #0x4d8
    9fb8:      	blr	x9
    9fbc:      	ldr	x8, [sp, #0x40]
    9fc0:      	add	x0, x22, #0x30
    9fc4:      	mov	w9, #0x4                // =4
    9fc8:      	mov	w1, #0x4                // =4
    9fcc:      	add	x8, x8, #0x58
    9fd0:      	ldr	x8, [sp, #0x40]
    9fd4:      	add	x2, x8, #0x58
    9fd8:      	blr	x9
    9fdc:      	str	xzr, [sp, #0x20]
    9fe0:      	add	x2, x23, #0x938
    9fe4:      	add	x8, sp, #0x20
    9fe8:      	add	x0, sp, #0x20
    9fec:      	mov	w1, #0x8                // =8
    9ff0:      	blr	x25
    9ff4:      	ldr	x8, [sp, #0x20]
    9ff8:      	cbz	x8, 0xa07c <generic_fentry_output+0x1cc>
    9ffc:      	str	wzr, [sp, #0x1c]
    a000:      	add	x8, x8, #0x4
    a004:      	add	x9, sp, #0x1c
    a008:      	mov	w10, #0x4               // =4
    a00c:      	add	x0, sp, #0x1c
    a010:      	mov	w1, #0x4                // =4
    a014:      	mov	w24, #0x4               // =4
    a018:      	ldr	x8, [sp, #0x20]
    a01c:      	add	x2, x8, #0x4
    a020:      	blr	x10
    a024:      	ldr	x8, [sp, #0x20]
    a028:      	ldrsw	x9, [sp, #0x1c]
    a02c:      	add	x10, sp, #0x8
    a030:      	mov	w11, #0x4               // =4
    a034:      	add	x0, sp, #0x8
    a038:      	mov	w1, #0x10               // =16
    a03c:      	add	x8, x8, x9, lsl #4
    a040:      	mov	w9, #0x10               // =16
    a044:      	add	x8, x8, #0x80
    a048:      	ldr	x8, [sp, #0x20]
    a04c:      	ldrsw	x9, [sp, #0x1c]
    a050:      	add	x8, x8, x9, lsl #4
    a054:      	add	x2, x8, #0x80
    a058:      	blr	x11
    a05c:      	ldr	x8, [sp, #0x10]
    a060:      	add	x0, x22, #0x34
    a064:      	mov	w1, #0x4                // =4
    a068:      	add	x8, x8, #0x158
    a06c:      	ldr	x8, [sp, #0x10]
    a070:      	add	x2, x8, #0x158
    a074:      	blr	x24
    a078:      	b	0xa080 <generic_fentry_output+0x1d0>
    a07c:      	str	wzr, [x22, #0x34]
    a080:      	ldr	x8, [sp, #0x48]
    a084:      	add	x0, x22, #0x38
    a088:      	mov	w9, #0x4                // =4
    a08c:      	mov	w1, #0x4                // =4
    a090:      	mov	w24, #0x4               // =4
    a094:      	add	x8, x8, #0x158
    a098:      	ldr	x8, [sp, #0x48]
    a09c:      	add	x2, x8, #0x158
    a0a0:      	blr	x9
    a0a4:      	ldr	x8, [sp, #0x50]
    a0a8:      	add	x0, x22, #0x3c
    a0ac:      	mov	w9, #0x4                // =4
    a0b0:      	mov	w1, #0x4                // =4
    a0b4:      	add	x8, x8, #0x118
    a0b8:      	ldr	x8, [sp, #0x50]
    a0bc:      	add	x2, x8, #0x118
    a0c0:      	blr	x9
    a0c4:      	ldr	x8, [sp, #0x58]
    a0c8:      	add	x0, x22, #0x40
    a0cc:      	mov	w9, #0x4                // =4
    a0d0:      	mov	w1, #0x4                // =4
    a0d4:      	add	x8, x8, #0x98
    a0d8:      	ldr	x8, [sp, #0x58]
    a0dc:      	add	x2, x8, #0x98
    a0e0:      	blr	x9
    a0e4:      	ldr	x8, [sp, #0x60]
    a0e8:      	add	x0, x22, #0x44
    a0ec:      	mov	w9, #0x4                // =4
    a0f0:      	mov	w1, #0x4                // =4
    a0f4:      	add	x8, x8, #0x98
    a0f8:      	ldr	x8, [sp, #0x60]
    a0fc:      	add	x2, x8, #0x98
    a100:      	blr	x9
    a104:      	ldr	x8, [sp, #0x68]
    a108:      	add	x0, x22, #0x48
    a10c:      	mov	w9, #0x4                // =4
    a110:      	mov	w1, #0x4                // =4
    a114:      	add	x8, x8, #0x58
    a118:      	ldr	x8, [sp, #0x68]
    a11c:      	add	x2, x8, #0x58
    a120:      	blr	x9
    a124:      	str	xzr, [sp, #0x8]
    a128:      	str	xzr, [sp, #0x20]
    a12c:      	add	x2, x23, #0xae0
    a130:      	mov	w23, #0x8               // =8
    a134:      	add	x8, sp, #0x8
    a138:      	mov	w9, #0x4                // =4
    a13c:      	add	x0, sp, #0x8
    a140:      	mov	w1, #0x8                // =8
    a144:      	blr	x9
    a148:      	ldr	x8, [sp, #0x8]
    a14c:      	add	x9, sp, #0x20
    a150:      	mov	w10, #0x4               // =4
    a154:      	add	x0, sp, #0x20
    a158:      	mov	w1, #0x8                // =8
    a15c:      	add	x8, x8, #0x90
    a160:      	ldr	x8, [sp, #0x8]
    a164:      	add	x2, x8, #0x90
    a168:      	blr	x10
    a16c:      	ldr	x8, [sp, #0x20]
    a170:      	add	x0, x22, #0x4c
    a174:      	mov	w1, #0x4                // =4
    a178:      	add	x8, x8, #0x158
    a17c:      	ldr	x8, [sp, #0x20]
    a180:      	add	x2, x8, #0x158
    a184:      	blr	x24
    a188:      	ldr	x8, [x19, #0x5ef0]
    a18c:      	cbz	x8, 0xa228 <generic_fentry_output+0x378>
    a190:      	mov	w8, #0xe                // =14
    a194:      	blr	x8
    a198:      	mov	w8, #0x23               // =35
    a19c:      	lsr	x23, x0, #32
    a1a0:      	blr	x8
    a1a4:      	str	w23, [sp, #0x28]
    a1a8:      	mov	w8, #0x1                // =1
    a1ac:      	add	x9, sp, #0x28
    a1b0:      	mov	x22, x0
    a1b4:      	add	x1, sp, #0x28
    a1b8:      	mov	x0, x21
    a1bc:      	blr	x8
    a1c0:      	cbz	x0, 0xa228 <generic_fentry_output+0x378>
    a1c4:      	add	x2, x22, #0xae0
    a1c8:      	mov	w22, #0x8               // =8
    a1cc:      	add	x8, sp, #0x28
    a1d0:      	mov	w9, #0x4                // =4
    a1d4:      	add	x21, x0, #0x50
    a1d8:      	mov	x24, x0
    a1dc:      	add	x0, sp, #0x28
    a1e0:      	mov	w1, #0x8                // =8
    a1e4:      	mov	w23, #0x4               // =4
    a1e8:      	blr	x9
    a1ec:      	ldr	x25, [sp, #0x28]
    a1f0:      	add	x0, x24, #0x58
    a1f4:      	mov	w8, #0x4                // =4
    a1f8:      	mov	w1, #0x8                // =8
    a1fc:      	add	x2, x25, #0x40
    a200:      	blr	x8
    a204:      	add	x0, x24, #0x60
    a208:      	add	x2, x25, #0x30
    a20c:      	mov	w8, #0x4                // =4
    a210:      	mov	w1, #0x8                // =8
    a214:      	blr	x8
    a218:      	add	x2, x25, #0x38
    a21c:      	mov	x0, x21
    a220:      	mov	w1, #0x8                // =8
    a224:      	blr	x23
    a228:      	ldr	w8, [x19, #0x4]
    a22c:      	mov	w9, #0x2328             // =9000
    a230:      	str	wzr, [sp, #0x8]
    a234:      	adrp	x0, 0xa000 <generic_fentry_output+0x150>
    a238:      	add	x1, sp, #0x8
    a23c:      	add	w8, w8, #0x90
    a240:      	ldr	x0, [x0]
    a244:      	and	w8, w8, #0x7fff
    a248:      	cmp	w8, w9
    a24c:      	csel	w21, w8, w9, lo
    a250:      	mov	w8, #0x1                // =1
    a254:      	add	x9, sp, #0x8
    a258:      	blr	x8
    a25c:      	cbz	x0, 0xa2d4 <generic_fentry_output+0x424>
    a260:      	ldrb	w8, [x0, #0x28]
    a264:      	cbz	w8, 0xa2d4 <generic_fentry_output+0x424>
    a268:      	adrp	x1, 0xa000 <generic_fentry_output+0x150>
    a26c:      	mov	w8, #-0x1               // =-1
    a270:      	mov	w9, #0x19               // =25
    a274:      	ldr	x1, [x1]
    a278:      	mov	x0, x20
    a27c:      	mov	w2, #-0x1               // =-1
    a280:      	mov	x3, x19
    a284:      	mov	x4, x21
    a288:      	blr	x9
    a28c:      	tbnz	x0, #0x3f, 0xa384 <generic_fentry_output+0x4d4>
    a290:      	str	wzr, [sp, #0x28]
    a294:      	adrp	x0, 0xa000 <generic_fentry_output+0x150>
    a298:      	mov	w8, #0x1                // =1
    a29c:      	add	x9, sp, #0x28
    a2a0:      	ldr	x0, [x0]
    a2a4:      	add	x1, sp, #0x28
    a2a8:      	blr	x8
    a2ac:      	cbz	x0, 0xa490 <generic_fentry_output+0x5e0>
    a2b0:      	add	x8, x0, #0x8
    a2b4:      	nop
    a2b8:      	nop
    a2bc:      	nop
    a2c0:      	ldaxr	x9, [x8]
    a2c4:      	add	x9, x9, #0x1
    a2c8:      	stlxr	w10, x9, [x8]
    a2cc:      	cbnz	w10, 0xa2c0 <generic_fentry_output+0x410>
    a2d0:      	b	0xa490 <generic_fentry_output+0x5e0>
    a2d4:      	adrp	x0, 0xa000 <generic_fentry_output+0x150>
    a2d8:      	mov	x3, xzr
    a2dc:      	mov	w8, #0x82               // =130
    a2e0:      	ldr	x0, [x0]
    a2e4:      	mov	x1, x19
    a2e8:      	mov	x2, x21
    a2ec:      	blr	x8
    a2f0:      	tbnz	x0, #0x3f, 0xa334 <generic_fentry_output+0x484>
    a2f4:      	str	wzr, [sp, #0x28]
    a2f8:      	adrp	x0, 0xa000 <generic_fentry_output+0x150>
    a2fc:      	mov	w8, #0x1                // =1
    a300:      	add	x9, sp, #0x28
    a304:      	ldr	x0, [x0]
    a308:      	add	x1, sp, #0x28
    a30c:      	blr	x8
    a310:      	cbz	x0, 0xa490 <generic_fentry_output+0x5e0>
    a314:      	add	x8, x0, #0x8
    a318:      	nop
    a31c:      	nop
    a320:      	ldaxr	x9, [x8]
    a324:      	add	x9, x9, #0x1
    a328:      	stlxr	w10, x9, [x8]
    a32c:      	cbnz	w10, 0xa320 <generic_fentry_output+0x470>
    a330:      	b	0xa490 <generic_fentry_output+0x5e0>
    a334:      	mov	x19, x0
    a338:      	str	wzr, [sp, #0x28]
    a33c:      	adrp	x0, 0xa000 <generic_fentry_output+0x150>
    a340:      	mov	w8, #0x1                // =1
    a344:      	ldr	x0, [x0]
    a348:      	add	x9, sp, #0x28
    a34c:      	add	x1, sp, #0x28
    a350:      	blr	x8
    a354:      	cbz	x0, 0xa490 <generic_fentry_output+0x5e0>
    a358:      	mov	x8, x19
    a35c:      	cmn	x19, #0xc
    a360:      	b.gt	0xa3d4 <generic_fentry_output+0x524>
    a364:      	cmn	x8, #0x1c
    a368:      	b.eq	0xa414 <generic_fentry_output+0x564>
    a36c:      	cmn	x8, #0x16
    a370:      	b.eq	0xa42c <generic_fentry_output+0x57c>
    a374:      	cmn	x8, #0x10
    a378:      	b.ne	0xa424 <generic_fentry_output+0x574>
    a37c:      	add	x8, x0, #0x2f0
    a380:      	b	0xa440 <generic_fentry_output+0x590>
    a384:      	mov	x19, x0
    a388:      	str	wzr, [sp, #0x28]
    a38c:      	adrp	x0, 0xa000 <generic_fentry_output+0x150>
    a390:      	mov	w8, #0x1                // =1
    a394:      	ldr	x0, [x0]
    a398:      	add	x9, sp, #0x28
    a39c:      	add	x1, sp, #0x28
    a3a0:      	blr	x8
    a3a4:      	cbz	x0, 0xa490 <generic_fentry_output+0x5e0>
    a3a8:      	mov	x8, x19
    a3ac:      	cmn	x19, #0xc
    a3b0:      	b.gt	0xa3f4 <generic_fentry_output+0x544>
    a3b4:      	cmn	x8, #0x1c
    a3b8:      	b.eq	0xa454 <generic_fentry_output+0x5a4>
    a3bc:      	cmn	x8, #0x16
    a3c0:      	b.eq	0xa46c <generic_fentry_output+0x5bc>
    a3c4:      	cmn	x8, #0x10
    a3c8:      	b.ne	0xa464 <generic_fentry_output+0x5b4>
    a3cc:      	add	x8, x0, #0x2f0
    a3d0:      	b	0xa480 <generic_fentry_output+0x5d0>
    a3d4:      	cmn	x8, #0xb
    a3d8:      	b.eq	0xa41c <generic_fentry_output+0x56c>
    a3dc:      	cmn	x8, #0x7
    a3e0:      	b.eq	0xa434 <generic_fentry_output+0x584>
    a3e4:      	cmn	x8, #0x2
    a3e8:      	b.ne	0xa424 <generic_fentry_output+0x574>
    a3ec:      	add	x8, x0, #0x2e0
    a3f0:      	b	0xa440 <generic_fentry_output+0x590>
    a3f4:      	cmn	x8, #0xb
    a3f8:      	b.eq	0xa45c <generic_fentry_output+0x5ac>
    a3fc:      	cmn	x8, #0x7
    a400:      	b.eq	0xa474 <generic_fentry_output+0x5c4>
    a404:      	cmn	x8, #0x2
    a408:      	b.ne	0xa464 <generic_fentry_output+0x5b4>
    a40c:      	add	x8, x0, #0x2e0
    a410:      	b	0xa480 <generic_fentry_output+0x5d0>
    a414:      	add	x8, x0, #0x300
    a418:      	b	0xa440 <generic_fentry_output+0x590>
    a41c:      	add	x8, x0, #0x308
    a420:      	b	0xa440 <generic_fentry_output+0x590>
    a424:      	add	x8, x0, #0x2d8
    a428:      	b	0xa440 <generic_fentry_output+0x590>
    a42c:      	add	x8, x0, #0x2f8
    a430:      	b	0xa440 <generic_fentry_output+0x590>
    a434:      	add	x8, x0, #0x2e8
    a438:      	nop
    a43c:      	nop
    a440:      	ldaxr	x9, [x8]
    a444:      	add	x9, x9, #0x1
    a448:      	stlxr	w10, x9, [x8]
    a44c:      	cbnz	w10, 0xa440 <generic_fentry_output+0x590>
    a450:      	b	0xa490 <generic_fentry_output+0x5e0>
    a454:      	add	x8, x0, #0x300
    a458:      	b	0xa480 <generic_fentry_output+0x5d0>
    a45c:      	add	x8, x0, #0x308
    a460:      	b	0xa480 <generic_fentry_output+0x5d0>
    a464:      	add	x8, x0, #0x2d8
    a468:      	b	0xa480 <generic_fentry_output+0x5d0>
    a46c:      	add	x8, x0, #0x2f8
    a470:      	b	0xa480 <generic_fentry_output+0x5d0>
    a474:      	add	x8, x0, #0x2e8
    a478:      	nop
    a47c:      	nop
    a480:      	ldaxr	x9, [x8]
    a484:      	add	x9, x9, #0x1
    a488:      	stlxr	w10, x9, [x8]
    a48c:      	cbnz	w10, 0xa480 <generic_fentry_output+0x5d0>
    a490:      	ldp	x20, x19, [sp, #0xb0]
    a494:      	mov	w0, wzr
    a498:      	ldr	x29, [sp, #0x70]
    a49c:      	ldp	x22, x21, [sp, #0xa0]
    a4a0:      	ldp	x24, x23, [sp, #0x90]
    a4a4:      	ldp	x30, x25, [sp, #0x80]
    a4a8:      	add	sp, sp, #0xc0
    a4ac:      	ret

000000000000a4b0 <generic_fentry_path>:
    a4b0:      	sub	sp, sp, #0xe0
    a4b4:      	str	x29, [sp, #0x90]
    a4b8:      	stp	x30, x25, [sp, #0xa0]
    a4bc:      	stp	x24, x23, [sp, #0xb0]
    a4c0:      	stp	x22, x21, [sp, #0xc0]
    a4c4:      	stp	x20, x19, [sp, #0xd0]
    a4c8:      	mov	x19, x0
    a4cc:      	str	wzr, [sp, #0x28]
    a4d0:      	adrp	x0, 0xa000 <generic_fentry_output+0x150>
    a4d4:      	mov	w8, #0x1                // =1
    a4d8:      	ldr	x0, [x0]
    a4dc:      	add	x9, sp, #0x28
    a4e0:      	add	x1, sp, #0x28
    a4e4:      	blr	x8
    a4e8:      	cbz	x0, 0x1634c <generic_fentry_path+0xbe9c>
    a4ec:      	mov	w8, #0x6420             // =25632
    a4f0:      	add	x25, x0, x8
    a4f4:      	ldr	w8, [x25]
    a4f8:      	cmp	w8, #0x1
    a4fc:      	b.eq	0xa5a8 <generic_fentry_path+0xf8>
    a500:      	cbnz	w8, 0x1634c <generic_fentry_path+0xbe9c>
    a504:      	mov	x20, x0
    a508:      	ldr	x22, [x0, #0x6440]
    a50c:      	str	wzr, [sp, #0x70]
    a510:      	adrp	x0, 0xa000 <generic_fentry_output+0x150>
    a514:      	mov	w8, #0x1                // =1
    a518:      	add	x9, sp, #0x70
    a51c:      	ldr	x0, [x0]
    a520:      	add	x1, sp, #0x70
    a524:      	blr	x8
    a528:      	cbz	x0, 0x1634c <generic_fentry_path+0xbe9c>
    a52c:      	str	x19, [sp, #0x20]
    a530:      	add	x2, x22, #0x8
    a534:      	mov	w8, #0x8                // =8
    a538:      	mov	w9, #0x4                // =4
    a53c:      	add	x10, sp, #0x80
    a540:      	mov	x21, x0
    a544:      	add	x29, x0, #0xfff
    a548:      	add	x0, sp, #0x80
    a54c:      	mov	w1, #0x8                // =8
    a550:      	blr	x9
    a554:      	adrp	x22, 0xa000 <generic_fentry_output+0x150>
    a558:      	ldr	x22, [x22]
    a55c:      	cbz	x0, 0x15fd8 <generic_fentry_path+0xbb28>
    a560:      	neg	w8, w0
    a564:      	mov	w9, #0x1                // =1
    a568:      	add	x1, sp, #0x30
    a56c:      	strh	w8, [sp, #0x30]
    a570:      	mov	w8, #0x6                // =6
    a574:      	mov	x0, x22
    a578:      	mov	w23, #0x1               // =1
    a57c:      	strh	w8, [sp, #0x32]
    a580:      	mov	x8, #0x2c               // =44
    a584:      	movk	x8, #0x4, lsl #32
    a588:      	stur	x8, [sp, #0x34]
    a58c:      	add	x8, sp, #0x30
    a590:      	blr	x9
    a594:      	cbz	x0, 0x15fb4 <generic_fentry_path+0xbb04>
    a598:      	ldr	w8, [x0]
    a59c:      	add	w8, w8, #0x1
    a5a0:      	str	w8, [x0]
    a5a4:      	b	0x15fd8 <generic_fentry_path+0xbb28>
    a5a8:      	ldr	x8, [x0, #0x6448]
    a5ac:      	ldr	x9, [x0, #0x6450]
    a5b0:      	mov	x20, x0
    a5b4:      	add	x1, sp, #0x2c
    a5b8:      	str	xzr, [sp, #0x60]
    a5bc:      	str	wzr, [sp, #0x68]
    a5c0:      	strb	wzr, [sp, #0x6c]
    a5c4:      	str	wzr, [sp, #0x2c]
    a5c8:      	stp	x8, x9, [sp, #0x30]
    a5cc:      	ldr	x8, [x0, #0x6458]
    a5d0:      	ldr	x9, [x0, #0x6468]
    a5d4:      	stp	xzr, x8, [sp, #0x40]
    a5d8:      	ldr	x8, [x0, #0x6460]
    a5dc:      	adrp	x0, 0xa000 <generic_fentry_output+0x150>
    a5e0:      	stp	x8, x9, [sp, #0x50]
    a5e4:      	mov	w8, #0x1                // =1
    a5e8:      	add	x9, sp, #0x2c
    a5ec:      	ldr	x0, [x0]
    a5f0:      	blr	x8
    a5f4:      	cbz	x0, 0x1634c <generic_fentry_path+0xbe9c>
    a5f8:      	str	x0, [sp, #0x40]
    a5fc:      	add	x10, sp, #0x30
    a600:      	stp	x20, x19, [sp, #0x18]
    a604:      	mov	w20, #0x200             // =512
    a608:      	mov	w29, #0x8               // =8
    a60c:      	ldr	w8, [x25, #0x4]
    a610:      	add	x22, x10, #0x18
    a614:      	add	x19, sp, #0x70
    a618:      	and	x9, x8, #0xfff
    a61c:      	str	x0, [sp, #0x10]
    a620:      	str	w8, [sp, #0x68]
    a624:      	add	x9, x0, x9
    a628:      	str	x9, [sp, #0x60]
    a62c:      	ldp	x21, x2, [sp, #0x48]
    a630:      	ldp	x8, x9, [sp, #0x30]
    a634:      	cmp	x21, x8
    a638:      	ccmp	x2, x9, #0x0, eq
    a63c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    a640:      	ldr	x24, [sp, #0x58]
    a644:      	mov	w8, #0x4                // =4
    a648:      	add	x0, sp, #0x70
    a64c:      	mov	w1, #0x8                // =8
    a650:      	blr	x8
    a654:      	ldr	x8, [sp, #0x70]
    a658:      	cmp	x21, x8
    a65c:      	b.eq	0xa758 <generic_fentry_path+0x2a8>
    a660:      	add	x23, x21, #0x18
    a664:      	mov	w8, #0x4                // =4
    a668:      	add	x9, sp, #0x98
    a66c:      	add	x0, sp, #0x98
    a670:      	mov	w1, #0x8                // =8
    a674:      	mov	x2, x23
    a678:      	blr	x8
    a67c:      	ldr	x8, [sp, #0x98]
    a680:      	cmp	x8, x21
    a684:      	b.eq	0xa758 <generic_fentry_path+0x2a8>
    a688:      	mov	w8, #0x4                // =4
    a68c:      	add	x9, sp, #0x78
    a690:      	add	x0, sp, #0x78
    a694:      	mov	w1, #0x8                // =8
    a698:      	mov	x2, x23
    a69c:      	blr	x8
    a6a0:      	add	x2, x21, #0x20
    a6a4:      	mov	w8, #0x4                // =4
    a6a8:      	mov	w9, #0x10               // =16
    a6ac:      	add	x10, sp, #0x80
    a6b0:      	add	x0, sp, #0x80
    a6b4:      	mov	w1, #0x10               // =16
    a6b8:      	blr	x8
    a6bc:      	ldr	w21, [sp, #0x84]
    a6c0:      	ldr	x8, [sp, #0x40]
    a6c4:      	ldr	x10, [sp, #0x60]
    a6c8:      	sub	x12, x10, x8
    a6cc:      	ldr	w23, [sp, #0x68]
    a6d0:      	subs	w10, w21, w23
    a6d4:      	ldr	x9, [sp, #0x88]
    a6d8:      	csel	w10, wzr, w10, lo
    a6dc:      	cmp	w23, w21
    a6e0:      	csel	w11, w23, w21, lo
    a6e4:      	cinc	w13, w11, hi
    a6e8:      	sub	w14, w23, w13
    a6ec:      	subs	x12, x12, x13
    a6f0:      	str	w14, [sp, #0x68]
    a6f4:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    a6f8:      	cmp	x12, #0xfff
    a6fc:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    a700:      	cmp	w23, w21
    a704:      	b.ls	0xa710 <generic_fentry_path+0x260>
    a708:      	mov	w13, #0x2f              // =47
    a70c:      	strb	w13, [x8, x12]
    a710:      	add	x19, x8, x12
    a714:      	cmp	w23, w21
    a718:      	add	x2, x9, x10
    a71c:      	and	w1, w11, #0xff
    a720:      	mov	w8, #0x4                // =4
    a724:      	cinc	x0, x19, hi
    a728:      	blr	x8
    a72c:      	cmp	w23, w21
    a730:      	str	x19, [sp, #0x60]
    a734:      	add	x19, sp, #0x70
    a738:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    a73c:      	ldr	x21, [sp, #0x78]
    a740:      	ldp	x2, x24, [sp, #0x50]
    a744:      	str	x21, [sp, #0x48]
    a748:      	ldr	x8, [sp, #0x30]
    a74c:      	cmp	x21, x8
    a750:      	b.eq	0xa7b0 <generic_fentry_path+0x300>
    a754:      	b	0xa7bc <generic_fentry_path+0x30c>
    a758:      	add	x2, x24, #0x10
    a75c:      	mov	w8, #0x4                // =4
    a760:      	add	x9, sp, #0x98
    a764:      	add	x0, sp, #0x98
    a768:      	mov	w1, #0x8                // =8
    a76c:      	blr	x8
    a770:      	ldr	x8, [sp, #0x58]
    a774:      	ldr	x9, [sp, #0x98]
    a778:      	cmp	x8, x9
    a77c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    a780:      	add	x2, x24, #0x18
    a784:      	mov	w8, #0x4                // =4
    a788:      	mov	x0, x22
    a78c:      	mov	w1, #0x8                // =8
    a790:      	blr	x8
    a794:      	ldr	x24, [sp, #0x98]
    a798:      	ldr	x21, [sp, #0x48]
    a79c:      	add	x2, x24, #0x20
    a7a0:      	stp	x2, x24, [sp, #0x50]
    a7a4:      	ldr	x8, [sp, #0x30]
    a7a8:      	cmp	x21, x8
    a7ac:      	b.ne	0xa7bc <generic_fentry_path+0x30c>
    a7b0:      	ldr	x8, [sp, #0x38]
    a7b4:      	cmp	x2, x8
    a7b8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    a7bc:      	mov	w8, #0x4                // =4
    a7c0:      	add	x0, sp, #0x70
    a7c4:      	mov	w1, #0x8                // =8
    a7c8:      	blr	x8
    a7cc:      	ldr	x8, [sp, #0x70]
    a7d0:      	cmp	x21, x8
    a7d4:      	b.eq	0xa8d0 <generic_fentry_path+0x420>
    a7d8:      	add	x23, x21, #0x18
    a7dc:      	mov	w8, #0x4                // =4
    a7e0:      	add	x9, sp, #0x98
    a7e4:      	add	x0, sp, #0x98
    a7e8:      	mov	w1, #0x8                // =8
    a7ec:      	mov	x2, x23
    a7f0:      	blr	x8
    a7f4:      	ldr	x8, [sp, #0x98]
    a7f8:      	cmp	x8, x21
    a7fc:      	b.eq	0xa8d0 <generic_fentry_path+0x420>
    a800:      	mov	w8, #0x4                // =4
    a804:      	add	x9, sp, #0x78
    a808:      	add	x0, sp, #0x78
    a80c:      	mov	w1, #0x8                // =8
    a810:      	mov	x2, x23
    a814:      	blr	x8
    a818:      	add	x2, x21, #0x20
    a81c:      	mov	w8, #0x4                // =4
    a820:      	mov	w9, #0x10               // =16
    a824:      	add	x10, sp, #0x80
    a828:      	add	x0, sp, #0x80
    a82c:      	mov	w1, #0x10               // =16
    a830:      	blr	x8
    a834:      	ldr	w21, [sp, #0x84]
    a838:      	ldr	x8, [sp, #0x40]
    a83c:      	ldr	x10, [sp, #0x60]
    a840:      	sub	x12, x10, x8
    a844:      	ldr	w23, [sp, #0x68]
    a848:      	subs	w10, w21, w23
    a84c:      	ldr	x9, [sp, #0x88]
    a850:      	csel	w10, wzr, w10, lo
    a854:      	cmp	w23, w21
    a858:      	csel	w11, w23, w21, lo
    a85c:      	cinc	w13, w11, hi
    a860:      	sub	w14, w23, w13
    a864:      	subs	x12, x12, x13
    a868:      	str	w14, [sp, #0x68]
    a86c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    a870:      	cmp	x12, #0xfff
    a874:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    a878:      	cmp	w23, w21
    a87c:      	b.ls	0xa888 <generic_fentry_path+0x3d8>
    a880:      	mov	w13, #0x2f              // =47
    a884:      	strb	w13, [x8, x12]
    a888:      	add	x19, x8, x12
    a88c:      	cmp	w23, w21
    a890:      	add	x2, x9, x10
    a894:      	and	w1, w11, #0xff
    a898:      	mov	w8, #0x4                // =4
    a89c:      	cinc	x0, x19, hi
    a8a0:      	blr	x8
    a8a4:      	cmp	w23, w21
    a8a8:      	str	x19, [sp, #0x60]
    a8ac:      	add	x19, sp, #0x70
    a8b0:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    a8b4:      	ldr	x21, [sp, #0x78]
    a8b8:      	ldp	x2, x24, [sp, #0x50]
    a8bc:      	str	x21, [sp, #0x48]
    a8c0:      	ldr	x8, [sp, #0x30]
    a8c4:      	cmp	x21, x8
    a8c8:      	b.eq	0xa928 <generic_fentry_path+0x478>
    a8cc:      	b	0xa934 <generic_fentry_path+0x484>
    a8d0:      	add	x2, x24, #0x10
    a8d4:      	mov	w8, #0x4                // =4
    a8d8:      	add	x9, sp, #0x98
    a8dc:      	add	x0, sp, #0x98
    a8e0:      	mov	w1, #0x8                // =8
    a8e4:      	blr	x8
    a8e8:      	ldr	x8, [sp, #0x58]
    a8ec:      	ldr	x9, [sp, #0x98]
    a8f0:      	cmp	x8, x9
    a8f4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    a8f8:      	add	x2, x24, #0x18
    a8fc:      	mov	w8, #0x4                // =4
    a900:      	mov	x0, x22
    a904:      	mov	w1, #0x8                // =8
    a908:      	blr	x8
    a90c:      	ldr	x24, [sp, #0x98]
    a910:      	ldr	x21, [sp, #0x48]
    a914:      	add	x2, x24, #0x20
    a918:      	stp	x2, x24, [sp, #0x50]
    a91c:      	ldr	x8, [sp, #0x30]
    a920:      	cmp	x21, x8
    a924:      	b.ne	0xa934 <generic_fentry_path+0x484>
    a928:      	ldr	x8, [sp, #0x38]
    a92c:      	cmp	x2, x8
    a930:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    a934:      	mov	w8, #0x4                // =4
    a938:      	add	x0, sp, #0x70
    a93c:      	mov	w1, #0x8                // =8
    a940:      	blr	x8
    a944:      	ldr	x8, [sp, #0x70]
    a948:      	cmp	x21, x8
    a94c:      	b.eq	0xaa48 <generic_fentry_path+0x598>
    a950:      	add	x23, x21, #0x18
    a954:      	mov	w8, #0x4                // =4
    a958:      	add	x9, sp, #0x98
    a95c:      	add	x0, sp, #0x98
    a960:      	mov	w1, #0x8                // =8
    a964:      	mov	x2, x23
    a968:      	blr	x8
    a96c:      	ldr	x8, [sp, #0x98]
    a970:      	cmp	x8, x21
    a974:      	b.eq	0xaa48 <generic_fentry_path+0x598>
    a978:      	mov	w8, #0x4                // =4
    a97c:      	add	x9, sp, #0x78
    a980:      	add	x0, sp, #0x78
    a984:      	mov	w1, #0x8                // =8
    a988:      	mov	x2, x23
    a98c:      	blr	x8
    a990:      	add	x2, x21, #0x20
    a994:      	mov	w8, #0x4                // =4
    a998:      	mov	w9, #0x10               // =16
    a99c:      	add	x10, sp, #0x80
    a9a0:      	add	x0, sp, #0x80
    a9a4:      	mov	w1, #0x10               // =16
    a9a8:      	blr	x8
    a9ac:      	ldr	w21, [sp, #0x84]
    a9b0:      	ldr	x8, [sp, #0x40]
    a9b4:      	ldr	x10, [sp, #0x60]
    a9b8:      	sub	x12, x10, x8
    a9bc:      	ldr	w23, [sp, #0x68]
    a9c0:      	subs	w10, w21, w23
    a9c4:      	ldr	x9, [sp, #0x88]
    a9c8:      	csel	w10, wzr, w10, lo
    a9cc:      	cmp	w23, w21
    a9d0:      	csel	w11, w23, w21, lo
    a9d4:      	cinc	w13, w11, hi
    a9d8:      	sub	w14, w23, w13
    a9dc:      	subs	x12, x12, x13
    a9e0:      	str	w14, [sp, #0x68]
    a9e4:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    a9e8:      	cmp	x12, #0xfff
    a9ec:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    a9f0:      	cmp	w23, w21
    a9f4:      	b.ls	0xaa00 <generic_fentry_path+0x550>
    a9f8:      	mov	w13, #0x2f              // =47
    a9fc:      	strb	w13, [x8, x12]
    aa00:      	add	x19, x8, x12
    aa04:      	cmp	w23, w21
    aa08:      	add	x2, x9, x10
    aa0c:      	and	w1, w11, #0xff
    aa10:      	mov	w8, #0x4                // =4
    aa14:      	cinc	x0, x19, hi
    aa18:      	blr	x8
    aa1c:      	cmp	w23, w21
    aa20:      	str	x19, [sp, #0x60]
    aa24:      	add	x19, sp, #0x70
    aa28:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    aa2c:      	ldr	x21, [sp, #0x78]
    aa30:      	ldp	x2, x24, [sp, #0x50]
    aa34:      	str	x21, [sp, #0x48]
    aa38:      	ldr	x8, [sp, #0x30]
    aa3c:      	cmp	x21, x8
    aa40:      	b.eq	0xaaa0 <generic_fentry_path+0x5f0>
    aa44:      	b	0xaaac <generic_fentry_path+0x5fc>
    aa48:      	add	x2, x24, #0x10
    aa4c:      	mov	w8, #0x4                // =4
    aa50:      	add	x9, sp, #0x98
    aa54:      	add	x0, sp, #0x98
    aa58:      	mov	w1, #0x8                // =8
    aa5c:      	blr	x8
    aa60:      	ldr	x8, [sp, #0x58]
    aa64:      	ldr	x9, [sp, #0x98]
    aa68:      	cmp	x8, x9
    aa6c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    aa70:      	add	x2, x24, #0x18
    aa74:      	mov	w8, #0x4                // =4
    aa78:      	mov	x0, x22
    aa7c:      	mov	w1, #0x8                // =8
    aa80:      	blr	x8
    aa84:      	ldr	x24, [sp, #0x98]
    aa88:      	ldr	x21, [sp, #0x48]
    aa8c:      	add	x2, x24, #0x20
    aa90:      	stp	x2, x24, [sp, #0x50]
    aa94:      	ldr	x8, [sp, #0x30]
    aa98:      	cmp	x21, x8
    aa9c:      	b.ne	0xaaac <generic_fentry_path+0x5fc>
    aaa0:      	ldr	x8, [sp, #0x38]
    aaa4:      	cmp	x2, x8
    aaa8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    aaac:      	mov	w8, #0x4                // =4
    aab0:      	add	x0, sp, #0x70
    aab4:      	mov	w1, #0x8                // =8
    aab8:      	blr	x8
    aabc:      	ldr	x8, [sp, #0x70]
    aac0:      	cmp	x21, x8
    aac4:      	b.eq	0xabc0 <generic_fentry_path+0x710>
    aac8:      	add	x23, x21, #0x18
    aacc:      	mov	w8, #0x4                // =4
    aad0:      	add	x9, sp, #0x98
    aad4:      	add	x0, sp, #0x98
    aad8:      	mov	w1, #0x8                // =8
    aadc:      	mov	x2, x23
    aae0:      	blr	x8
    aae4:      	ldr	x8, [sp, #0x98]
    aae8:      	cmp	x8, x21
    aaec:      	b.eq	0xabc0 <generic_fentry_path+0x710>
    aaf0:      	mov	w8, #0x4                // =4
    aaf4:      	add	x9, sp, #0x78
    aaf8:      	add	x0, sp, #0x78
    aafc:      	mov	w1, #0x8                // =8
    ab00:      	mov	x2, x23
    ab04:      	blr	x8
    ab08:      	add	x2, x21, #0x20
    ab0c:      	mov	w8, #0x4                // =4
    ab10:      	mov	w9, #0x10               // =16
    ab14:      	add	x10, sp, #0x80
    ab18:      	add	x0, sp, #0x80
    ab1c:      	mov	w1, #0x10               // =16
    ab20:      	blr	x8
    ab24:      	ldr	w21, [sp, #0x84]
    ab28:      	ldr	x8, [sp, #0x40]
    ab2c:      	ldr	x10, [sp, #0x60]
    ab30:      	sub	x12, x10, x8
    ab34:      	ldr	w23, [sp, #0x68]
    ab38:      	subs	w10, w21, w23
    ab3c:      	ldr	x9, [sp, #0x88]
    ab40:      	csel	w10, wzr, w10, lo
    ab44:      	cmp	w23, w21
    ab48:      	csel	w11, w23, w21, lo
    ab4c:      	cinc	w13, w11, hi
    ab50:      	sub	w14, w23, w13
    ab54:      	subs	x12, x12, x13
    ab58:      	str	w14, [sp, #0x68]
    ab5c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    ab60:      	cmp	x12, #0xfff
    ab64:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    ab68:      	cmp	w23, w21
    ab6c:      	b.ls	0xab78 <generic_fentry_path+0x6c8>
    ab70:      	mov	w13, #0x2f              // =47
    ab74:      	strb	w13, [x8, x12]
    ab78:      	add	x19, x8, x12
    ab7c:      	cmp	w23, w21
    ab80:      	add	x2, x9, x10
    ab84:      	and	w1, w11, #0xff
    ab88:      	mov	w8, #0x4                // =4
    ab8c:      	cinc	x0, x19, hi
    ab90:      	blr	x8
    ab94:      	cmp	w23, w21
    ab98:      	str	x19, [sp, #0x60]
    ab9c:      	add	x19, sp, #0x70
    aba0:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    aba4:      	ldr	x21, [sp, #0x78]
    aba8:      	ldp	x2, x24, [sp, #0x50]
    abac:      	str	x21, [sp, #0x48]
    abb0:      	ldr	x8, [sp, #0x30]
    abb4:      	cmp	x21, x8
    abb8:      	b.eq	0xac18 <generic_fentry_path+0x768>
    abbc:      	b	0xac24 <generic_fentry_path+0x774>
    abc0:      	add	x2, x24, #0x10
    abc4:      	mov	w8, #0x4                // =4
    abc8:      	add	x9, sp, #0x98
    abcc:      	add	x0, sp, #0x98
    abd0:      	mov	w1, #0x8                // =8
    abd4:      	blr	x8
    abd8:      	ldr	x8, [sp, #0x58]
    abdc:      	ldr	x9, [sp, #0x98]
    abe0:      	cmp	x8, x9
    abe4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    abe8:      	add	x2, x24, #0x18
    abec:      	mov	w8, #0x4                // =4
    abf0:      	mov	x0, x22
    abf4:      	mov	w1, #0x8                // =8
    abf8:      	blr	x8
    abfc:      	ldr	x24, [sp, #0x98]
    ac00:      	ldr	x21, [sp, #0x48]
    ac04:      	add	x2, x24, #0x20
    ac08:      	stp	x2, x24, [sp, #0x50]
    ac0c:      	ldr	x8, [sp, #0x30]
    ac10:      	cmp	x21, x8
    ac14:      	b.ne	0xac24 <generic_fentry_path+0x774>
    ac18:      	ldr	x8, [sp, #0x38]
    ac1c:      	cmp	x2, x8
    ac20:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    ac24:      	mov	w8, #0x4                // =4
    ac28:      	add	x0, sp, #0x70
    ac2c:      	mov	w1, #0x8                // =8
    ac30:      	blr	x8
    ac34:      	ldr	x8, [sp, #0x70]
    ac38:      	cmp	x21, x8
    ac3c:      	b.eq	0xad38 <generic_fentry_path+0x888>
    ac40:      	add	x23, x21, #0x18
    ac44:      	mov	w8, #0x4                // =4
    ac48:      	add	x9, sp, #0x98
    ac4c:      	add	x0, sp, #0x98
    ac50:      	mov	w1, #0x8                // =8
    ac54:      	mov	x2, x23
    ac58:      	blr	x8
    ac5c:      	ldr	x8, [sp, #0x98]
    ac60:      	cmp	x8, x21
    ac64:      	b.eq	0xad38 <generic_fentry_path+0x888>
    ac68:      	mov	w8, #0x4                // =4
    ac6c:      	add	x9, sp, #0x78
    ac70:      	add	x0, sp, #0x78
    ac74:      	mov	w1, #0x8                // =8
    ac78:      	mov	x2, x23
    ac7c:      	blr	x8
    ac80:      	add	x2, x21, #0x20
    ac84:      	mov	w8, #0x4                // =4
    ac88:      	mov	w9, #0x10               // =16
    ac8c:      	add	x10, sp, #0x80
    ac90:      	add	x0, sp, #0x80
    ac94:      	mov	w1, #0x10               // =16
    ac98:      	blr	x8
    ac9c:      	ldr	w21, [sp, #0x84]
    aca0:      	ldr	x8, [sp, #0x40]
    aca4:      	ldr	x10, [sp, #0x60]
    aca8:      	sub	x12, x10, x8
    acac:      	ldr	w23, [sp, #0x68]
    acb0:      	subs	w10, w21, w23
    acb4:      	ldr	x9, [sp, #0x88]
    acb8:      	csel	w10, wzr, w10, lo
    acbc:      	cmp	w23, w21
    acc0:      	csel	w11, w23, w21, lo
    acc4:      	cinc	w13, w11, hi
    acc8:      	sub	w14, w23, w13
    accc:      	subs	x12, x12, x13
    acd0:      	str	w14, [sp, #0x68]
    acd4:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    acd8:      	cmp	x12, #0xfff
    acdc:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    ace0:      	cmp	w23, w21
    ace4:      	b.ls	0xacf0 <generic_fentry_path+0x840>
    ace8:      	mov	w13, #0x2f              // =47
    acec:      	strb	w13, [x8, x12]
    acf0:      	add	x19, x8, x12
    acf4:      	cmp	w23, w21
    acf8:      	add	x2, x9, x10
    acfc:      	and	w1, w11, #0xff
    ad00:      	mov	w8, #0x4                // =4
    ad04:      	cinc	x0, x19, hi
    ad08:      	blr	x8
    ad0c:      	cmp	w23, w21
    ad10:      	str	x19, [sp, #0x60]
    ad14:      	add	x19, sp, #0x70
    ad18:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    ad1c:      	ldr	x21, [sp, #0x78]
    ad20:      	ldp	x2, x24, [sp, #0x50]
    ad24:      	str	x21, [sp, #0x48]
    ad28:      	ldr	x8, [sp, #0x30]
    ad2c:      	cmp	x21, x8
    ad30:      	b.eq	0xad90 <generic_fentry_path+0x8e0>
    ad34:      	b	0xad9c <generic_fentry_path+0x8ec>
    ad38:      	add	x2, x24, #0x10
    ad3c:      	mov	w8, #0x4                // =4
    ad40:      	add	x9, sp, #0x98
    ad44:      	add	x0, sp, #0x98
    ad48:      	mov	w1, #0x8                // =8
    ad4c:      	blr	x8
    ad50:      	ldr	x8, [sp, #0x58]
    ad54:      	ldr	x9, [sp, #0x98]
    ad58:      	cmp	x8, x9
    ad5c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    ad60:      	add	x2, x24, #0x18
    ad64:      	mov	w8, #0x4                // =4
    ad68:      	mov	x0, x22
    ad6c:      	mov	w1, #0x8                // =8
    ad70:      	blr	x8
    ad74:      	ldr	x24, [sp, #0x98]
    ad78:      	ldr	x21, [sp, #0x48]
    ad7c:      	add	x2, x24, #0x20
    ad80:      	stp	x2, x24, [sp, #0x50]
    ad84:      	ldr	x8, [sp, #0x30]
    ad88:      	cmp	x21, x8
    ad8c:      	b.ne	0xad9c <generic_fentry_path+0x8ec>
    ad90:      	ldr	x8, [sp, #0x38]
    ad94:      	cmp	x2, x8
    ad98:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    ad9c:      	mov	w8, #0x4                // =4
    ada0:      	add	x0, sp, #0x70
    ada4:      	mov	w1, #0x8                // =8
    ada8:      	blr	x8
    adac:      	ldr	x8, [sp, #0x70]
    adb0:      	cmp	x21, x8
    adb4:      	b.eq	0xaeb0 <generic_fentry_path+0xa00>
    adb8:      	add	x23, x21, #0x18
    adbc:      	mov	w8, #0x4                // =4
    adc0:      	add	x9, sp, #0x98
    adc4:      	add	x0, sp, #0x98
    adc8:      	mov	w1, #0x8                // =8
    adcc:      	mov	x2, x23
    add0:      	blr	x8
    add4:      	ldr	x8, [sp, #0x98]
    add8:      	cmp	x8, x21
    addc:      	b.eq	0xaeb0 <generic_fentry_path+0xa00>
    ade0:      	mov	w8, #0x4                // =4
    ade4:      	add	x9, sp, #0x78
    ade8:      	add	x0, sp, #0x78
    adec:      	mov	w1, #0x8                // =8
    adf0:      	mov	x2, x23
    adf4:      	blr	x8
    adf8:      	add	x2, x21, #0x20
    adfc:      	mov	w8, #0x4                // =4
    ae00:      	mov	w9, #0x10               // =16
    ae04:      	add	x10, sp, #0x80
    ae08:      	add	x0, sp, #0x80
    ae0c:      	mov	w1, #0x10               // =16
    ae10:      	blr	x8
    ae14:      	ldr	w21, [sp, #0x84]
    ae18:      	ldr	x8, [sp, #0x40]
    ae1c:      	ldr	x10, [sp, #0x60]
    ae20:      	sub	x12, x10, x8
    ae24:      	ldr	w23, [sp, #0x68]
    ae28:      	subs	w10, w21, w23
    ae2c:      	ldr	x9, [sp, #0x88]
    ae30:      	csel	w10, wzr, w10, lo
    ae34:      	cmp	w23, w21
    ae38:      	csel	w11, w23, w21, lo
    ae3c:      	cinc	w13, w11, hi
    ae40:      	sub	w14, w23, w13
    ae44:      	subs	x12, x12, x13
    ae48:      	str	w14, [sp, #0x68]
    ae4c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    ae50:      	cmp	x12, #0xfff
    ae54:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    ae58:      	cmp	w23, w21
    ae5c:      	b.ls	0xae68 <generic_fentry_path+0x9b8>
    ae60:      	mov	w13, #0x2f              // =47
    ae64:      	strb	w13, [x8, x12]
    ae68:      	add	x19, x8, x12
    ae6c:      	cmp	w23, w21
    ae70:      	add	x2, x9, x10
    ae74:      	and	w1, w11, #0xff
    ae78:      	mov	w8, #0x4                // =4
    ae7c:      	cinc	x0, x19, hi
    ae80:      	blr	x8
    ae84:      	cmp	w23, w21
    ae88:      	str	x19, [sp, #0x60]
    ae8c:      	add	x19, sp, #0x70
    ae90:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    ae94:      	ldr	x21, [sp, #0x78]
    ae98:      	ldp	x2, x24, [sp, #0x50]
    ae9c:      	str	x21, [sp, #0x48]
    aea0:      	ldr	x8, [sp, #0x30]
    aea4:      	cmp	x21, x8
    aea8:      	b.eq	0xaf08 <generic_fentry_path+0xa58>
    aeac:      	b	0xaf14 <generic_fentry_path+0xa64>
    aeb0:      	add	x2, x24, #0x10
    aeb4:      	mov	w8, #0x4                // =4
    aeb8:      	add	x9, sp, #0x98
    aebc:      	add	x0, sp, #0x98
    aec0:      	mov	w1, #0x8                // =8
    aec4:      	blr	x8
    aec8:      	ldr	x8, [sp, #0x58]
    aecc:      	ldr	x9, [sp, #0x98]
    aed0:      	cmp	x8, x9
    aed4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    aed8:      	add	x2, x24, #0x18
    aedc:      	mov	w8, #0x4                // =4
    aee0:      	mov	x0, x22
    aee4:      	mov	w1, #0x8                // =8
    aee8:      	blr	x8
    aeec:      	ldr	x24, [sp, #0x98]
    aef0:      	ldr	x21, [sp, #0x48]
    aef4:      	add	x2, x24, #0x20
    aef8:      	stp	x2, x24, [sp, #0x50]
    aefc:      	ldr	x8, [sp, #0x30]
    af00:      	cmp	x21, x8
    af04:      	b.ne	0xaf14 <generic_fentry_path+0xa64>
    af08:      	ldr	x8, [sp, #0x38]
    af0c:      	cmp	x2, x8
    af10:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    af14:      	mov	w8, #0x4                // =4
    af18:      	add	x0, sp, #0x70
    af1c:      	mov	w1, #0x8                // =8
    af20:      	blr	x8
    af24:      	ldr	x8, [sp, #0x70]
    af28:      	cmp	x21, x8
    af2c:      	b.eq	0xb028 <generic_fentry_path+0xb78>
    af30:      	add	x23, x21, #0x18
    af34:      	mov	w8, #0x4                // =4
    af38:      	add	x9, sp, #0x98
    af3c:      	add	x0, sp, #0x98
    af40:      	mov	w1, #0x8                // =8
    af44:      	mov	x2, x23
    af48:      	blr	x8
    af4c:      	ldr	x8, [sp, #0x98]
    af50:      	cmp	x8, x21
    af54:      	b.eq	0xb028 <generic_fentry_path+0xb78>
    af58:      	mov	w8, #0x4                // =4
    af5c:      	add	x9, sp, #0x78
    af60:      	add	x0, sp, #0x78
    af64:      	mov	w1, #0x8                // =8
    af68:      	mov	x2, x23
    af6c:      	blr	x8
    af70:      	add	x2, x21, #0x20
    af74:      	mov	w8, #0x4                // =4
    af78:      	mov	w9, #0x10               // =16
    af7c:      	add	x10, sp, #0x80
    af80:      	add	x0, sp, #0x80
    af84:      	mov	w1, #0x10               // =16
    af88:      	blr	x8
    af8c:      	ldr	w21, [sp, #0x84]
    af90:      	ldr	x8, [sp, #0x40]
    af94:      	ldr	x10, [sp, #0x60]
    af98:      	sub	x12, x10, x8
    af9c:      	ldr	w23, [sp, #0x68]
    afa0:      	subs	w10, w21, w23
    afa4:      	ldr	x9, [sp, #0x88]
    afa8:      	csel	w10, wzr, w10, lo
    afac:      	cmp	w23, w21
    afb0:      	csel	w11, w23, w21, lo
    afb4:      	cinc	w13, w11, hi
    afb8:      	sub	w14, w23, w13
    afbc:      	subs	x12, x12, x13
    afc0:      	str	w14, [sp, #0x68]
    afc4:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    afc8:      	cmp	x12, #0xfff
    afcc:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    afd0:      	cmp	w23, w21
    afd4:      	b.ls	0xafe0 <generic_fentry_path+0xb30>
    afd8:      	mov	w13, #0x2f              // =47
    afdc:      	strb	w13, [x8, x12]
    afe0:      	add	x19, x8, x12
    afe4:      	cmp	w23, w21
    afe8:      	add	x2, x9, x10
    afec:      	and	w1, w11, #0xff
    aff0:      	mov	w8, #0x4                // =4
    aff4:      	cinc	x0, x19, hi
    aff8:      	blr	x8
    affc:      	cmp	w23, w21
    b000:      	str	x19, [sp, #0x60]
    b004:      	add	x19, sp, #0x70
    b008:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    b00c:      	ldr	x21, [sp, #0x78]
    b010:      	ldp	x2, x24, [sp, #0x50]
    b014:      	str	x21, [sp, #0x48]
    b018:      	ldr	x8, [sp, #0x30]
    b01c:      	cmp	x21, x8
    b020:      	b.eq	0xb080 <generic_fentry_path+0xbd0>
    b024:      	b	0xb08c <generic_fentry_path+0xbdc>
    b028:      	add	x2, x24, #0x10
    b02c:      	mov	w8, #0x4                // =4
    b030:      	add	x9, sp, #0x98
    b034:      	add	x0, sp, #0x98
    b038:      	mov	w1, #0x8                // =8
    b03c:      	blr	x8
    b040:      	ldr	x8, [sp, #0x58]
    b044:      	ldr	x9, [sp, #0x98]
    b048:      	cmp	x8, x9
    b04c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    b050:      	add	x2, x24, #0x18
    b054:      	mov	w8, #0x4                // =4
    b058:      	mov	x0, x22
    b05c:      	mov	w1, #0x8                // =8
    b060:      	blr	x8
    b064:      	ldr	x24, [sp, #0x98]
    b068:      	ldr	x21, [sp, #0x48]
    b06c:      	add	x2, x24, #0x20
    b070:      	stp	x2, x24, [sp, #0x50]
    b074:      	ldr	x8, [sp, #0x30]
    b078:      	cmp	x21, x8
    b07c:      	b.ne	0xb08c <generic_fentry_path+0xbdc>
    b080:      	ldr	x8, [sp, #0x38]
    b084:      	cmp	x2, x8
    b088:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    b08c:      	mov	w8, #0x4                // =4
    b090:      	add	x0, sp, #0x70
    b094:      	mov	w1, #0x8                // =8
    b098:      	blr	x8
    b09c:      	ldr	x8, [sp, #0x70]
    b0a0:      	cmp	x21, x8
    b0a4:      	b.eq	0xb1a0 <generic_fentry_path+0xcf0>
    b0a8:      	add	x23, x21, #0x18
    b0ac:      	mov	w8, #0x4                // =4
    b0b0:      	add	x9, sp, #0x98
    b0b4:      	add	x0, sp, #0x98
    b0b8:      	mov	w1, #0x8                // =8
    b0bc:      	mov	x2, x23
    b0c0:      	blr	x8
    b0c4:      	ldr	x8, [sp, #0x98]
    b0c8:      	cmp	x8, x21
    b0cc:      	b.eq	0xb1a0 <generic_fentry_path+0xcf0>
    b0d0:      	mov	w8, #0x4                // =4
    b0d4:      	add	x9, sp, #0x78
    b0d8:      	add	x0, sp, #0x78
    b0dc:      	mov	w1, #0x8                // =8
    b0e0:      	mov	x2, x23
    b0e4:      	blr	x8
    b0e8:      	add	x2, x21, #0x20
    b0ec:      	mov	w8, #0x4                // =4
    b0f0:      	mov	w9, #0x10               // =16
    b0f4:      	add	x10, sp, #0x80
    b0f8:      	add	x0, sp, #0x80
    b0fc:      	mov	w1, #0x10               // =16
    b100:      	blr	x8
    b104:      	ldr	w21, [sp, #0x84]
    b108:      	ldr	x8, [sp, #0x40]
    b10c:      	ldr	x10, [sp, #0x60]
    b110:      	sub	x12, x10, x8
    b114:      	ldr	w23, [sp, #0x68]
    b118:      	subs	w10, w21, w23
    b11c:      	ldr	x9, [sp, #0x88]
    b120:      	csel	w10, wzr, w10, lo
    b124:      	cmp	w23, w21
    b128:      	csel	w11, w23, w21, lo
    b12c:      	cinc	w13, w11, hi
    b130:      	sub	w14, w23, w13
    b134:      	subs	x12, x12, x13
    b138:      	str	w14, [sp, #0x68]
    b13c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    b140:      	cmp	x12, #0xfff
    b144:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    b148:      	cmp	w23, w21
    b14c:      	b.ls	0xb158 <generic_fentry_path+0xca8>
    b150:      	mov	w13, #0x2f              // =47
    b154:      	strb	w13, [x8, x12]
    b158:      	add	x19, x8, x12
    b15c:      	cmp	w23, w21
    b160:      	add	x2, x9, x10
    b164:      	and	w1, w11, #0xff
    b168:      	mov	w8, #0x4                // =4
    b16c:      	cinc	x0, x19, hi
    b170:      	blr	x8
    b174:      	cmp	w23, w21
    b178:      	str	x19, [sp, #0x60]
    b17c:      	add	x19, sp, #0x70
    b180:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    b184:      	ldr	x21, [sp, #0x78]
    b188:      	ldp	x2, x24, [sp, #0x50]
    b18c:      	str	x21, [sp, #0x48]
    b190:      	ldr	x8, [sp, #0x30]
    b194:      	cmp	x21, x8
    b198:      	b.eq	0xb1f8 <generic_fentry_path+0xd48>
    b19c:      	b	0xb204 <generic_fentry_path+0xd54>
    b1a0:      	add	x2, x24, #0x10
    b1a4:      	mov	w8, #0x4                // =4
    b1a8:      	add	x9, sp, #0x98
    b1ac:      	add	x0, sp, #0x98
    b1b0:      	mov	w1, #0x8                // =8
    b1b4:      	blr	x8
    b1b8:      	ldr	x8, [sp, #0x58]
    b1bc:      	ldr	x9, [sp, #0x98]
    b1c0:      	cmp	x8, x9
    b1c4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    b1c8:      	add	x2, x24, #0x18
    b1cc:      	mov	w8, #0x4                // =4
    b1d0:      	mov	x0, x22
    b1d4:      	mov	w1, #0x8                // =8
    b1d8:      	blr	x8
    b1dc:      	ldr	x24, [sp, #0x98]
    b1e0:      	ldr	x21, [sp, #0x48]
    b1e4:      	add	x2, x24, #0x20
    b1e8:      	stp	x2, x24, [sp, #0x50]
    b1ec:      	ldr	x8, [sp, #0x30]
    b1f0:      	cmp	x21, x8
    b1f4:      	b.ne	0xb204 <generic_fentry_path+0xd54>
    b1f8:      	ldr	x8, [sp, #0x38]
    b1fc:      	cmp	x2, x8
    b200:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    b204:      	mov	w8, #0x4                // =4
    b208:      	add	x0, sp, #0x70
    b20c:      	mov	w1, #0x8                // =8
    b210:      	blr	x8
    b214:      	ldr	x8, [sp, #0x70]
    b218:      	cmp	x21, x8
    b21c:      	b.eq	0xb318 <generic_fentry_path+0xe68>
    b220:      	add	x23, x21, #0x18
    b224:      	mov	w8, #0x4                // =4
    b228:      	add	x9, sp, #0x98
    b22c:      	add	x0, sp, #0x98
    b230:      	mov	w1, #0x8                // =8
    b234:      	mov	x2, x23
    b238:      	blr	x8
    b23c:      	ldr	x8, [sp, #0x98]
    b240:      	cmp	x8, x21
    b244:      	b.eq	0xb318 <generic_fentry_path+0xe68>
    b248:      	mov	w8, #0x4                // =4
    b24c:      	add	x9, sp, #0x78
    b250:      	add	x0, sp, #0x78
    b254:      	mov	w1, #0x8                // =8
    b258:      	mov	x2, x23
    b25c:      	blr	x8
    b260:      	add	x2, x21, #0x20
    b264:      	mov	w8, #0x4                // =4
    b268:      	mov	w9, #0x10               // =16
    b26c:      	add	x10, sp, #0x80
    b270:      	add	x0, sp, #0x80
    b274:      	mov	w1, #0x10               // =16
    b278:      	blr	x8
    b27c:      	ldr	w21, [sp, #0x84]
    b280:      	ldr	x8, [sp, #0x40]
    b284:      	ldr	x10, [sp, #0x60]
    b288:      	sub	x12, x10, x8
    b28c:      	ldr	w23, [sp, #0x68]
    b290:      	subs	w10, w21, w23
    b294:      	ldr	x9, [sp, #0x88]
    b298:      	csel	w10, wzr, w10, lo
    b29c:      	cmp	w23, w21
    b2a0:      	csel	w11, w23, w21, lo
    b2a4:      	cinc	w13, w11, hi
    b2a8:      	sub	w14, w23, w13
    b2ac:      	subs	x12, x12, x13
    b2b0:      	str	w14, [sp, #0x68]
    b2b4:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    b2b8:      	cmp	x12, #0xfff
    b2bc:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    b2c0:      	cmp	w23, w21
    b2c4:      	b.ls	0xb2d0 <generic_fentry_path+0xe20>
    b2c8:      	mov	w13, #0x2f              // =47
    b2cc:      	strb	w13, [x8, x12]
    b2d0:      	add	x19, x8, x12
    b2d4:      	cmp	w23, w21
    b2d8:      	add	x2, x9, x10
    b2dc:      	and	w1, w11, #0xff
    b2e0:      	mov	w8, #0x4                // =4
    b2e4:      	cinc	x0, x19, hi
    b2e8:      	blr	x8
    b2ec:      	cmp	w23, w21
    b2f0:      	str	x19, [sp, #0x60]
    b2f4:      	add	x19, sp, #0x70
    b2f8:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    b2fc:      	ldr	x21, [sp, #0x78]
    b300:      	ldp	x2, x24, [sp, #0x50]
    b304:      	str	x21, [sp, #0x48]
    b308:      	ldr	x8, [sp, #0x30]
    b30c:      	cmp	x21, x8
    b310:      	b.eq	0xb370 <generic_fentry_path+0xec0>
    b314:      	b	0xb37c <generic_fentry_path+0xecc>
    b318:      	add	x2, x24, #0x10
    b31c:      	mov	w8, #0x4                // =4
    b320:      	add	x9, sp, #0x98
    b324:      	add	x0, sp, #0x98
    b328:      	mov	w1, #0x8                // =8
    b32c:      	blr	x8
    b330:      	ldr	x8, [sp, #0x58]
    b334:      	ldr	x9, [sp, #0x98]
    b338:      	cmp	x8, x9
    b33c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    b340:      	add	x2, x24, #0x18
    b344:      	mov	w8, #0x4                // =4
    b348:      	mov	x0, x22
    b34c:      	mov	w1, #0x8                // =8
    b350:      	blr	x8
    b354:      	ldr	x24, [sp, #0x98]
    b358:      	ldr	x21, [sp, #0x48]
    b35c:      	add	x2, x24, #0x20
    b360:      	stp	x2, x24, [sp, #0x50]
    b364:      	ldr	x8, [sp, #0x30]
    b368:      	cmp	x21, x8
    b36c:      	b.ne	0xb37c <generic_fentry_path+0xecc>
    b370:      	ldr	x8, [sp, #0x38]
    b374:      	cmp	x2, x8
    b378:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    b37c:      	mov	w8, #0x4                // =4
    b380:      	add	x0, sp, #0x70
    b384:      	mov	w1, #0x8                // =8
    b388:      	blr	x8
    b38c:      	ldr	x8, [sp, #0x70]
    b390:      	cmp	x21, x8
    b394:      	b.eq	0xb484 <generic_fentry_path+0xfd4>
    b398:      	add	x23, x21, #0x18
    b39c:      	mov	w8, #0x4                // =4
    b3a0:      	add	x9, sp, #0x98
    b3a4:      	add	x0, sp, #0x98
    b3a8:      	mov	w1, #0x8                // =8
    b3ac:      	mov	x2, x23
    b3b0:      	blr	x8
    b3b4:      	ldr	x8, [sp, #0x98]
    b3b8:      	cmp	x8, x21
    b3bc:      	b.eq	0xb484 <generic_fentry_path+0xfd4>
    b3c0:      	mov	w8, #0x4                // =4
    b3c4:      	add	x9, sp, #0x78
    b3c8:      	add	x0, sp, #0x78
    b3cc:      	mov	w1, #0x8                // =8
    b3d0:      	mov	x2, x23
    b3d4:      	blr	x8
    b3d8:      	add	x2, x21, #0x20
    b3dc:      	mov	w8, #0x4                // =4
    b3e0:      	mov	w9, #0x10               // =16
    b3e4:      	add	x10, sp, #0x80
    b3e8:      	add	x0, sp, #0x80
    b3ec:      	mov	w1, #0x10               // =16
    b3f0:      	blr	x8
    b3f4:      	ldr	w21, [sp, #0x84]
    b3f8:      	ldr	x8, [sp, #0x40]
    b3fc:      	ldr	x10, [sp, #0x60]
    b400:      	sub	x12, x10, x8
    b404:      	ldr	w23, [sp, #0x68]
    b408:      	subs	w10, w21, w23
    b40c:      	ldr	x9, [sp, #0x88]
    b410:      	csel	w10, wzr, w10, lo
    b414:      	cmp	w23, w21
    b418:      	csel	w11, w23, w21, lo
    b41c:      	cinc	w13, w11, hi
    b420:      	sub	w14, w23, w13
    b424:      	subs	x12, x12, x13
    b428:      	str	w14, [sp, #0x68]
    b42c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    b430:      	cmp	x12, #0xfff
    b434:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    b438:      	cmp	w23, w21
    b43c:      	b.ls	0xb448 <generic_fentry_path+0xf98>
    b440:      	mov	w13, #0x2f              // =47
    b444:      	strb	w13, [x8, x12]
    b448:      	add	x19, x8, x12
    b44c:      	cmp	w23, w21
    b450:      	add	x2, x9, x10
    b454:      	and	w1, w11, #0xff
    b458:      	mov	w8, #0x4                // =4
    b45c:      	cinc	x0, x19, hi
    b460:      	blr	x8
    b464:      	cmp	w23, w21
    b468:      	str	x19, [sp, #0x60]
    b46c:      	add	x19, sp, #0x70
    b470:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    b474:      	ldr	x21, [sp, #0x78]
    b478:      	ldp	x2, x24, [sp, #0x50]
    b47c:      	str	x21, [sp, #0x48]
    b480:      	b	0xb4d0 <generic_fentry_path+0x1020>
    b484:      	add	x2, x24, #0x10
    b488:      	mov	w8, #0x4                // =4
    b48c:      	add	x9, sp, #0x98
    b490:      	add	x0, sp, #0x98
    b494:      	mov	w1, #0x8                // =8
    b498:      	blr	x8
    b49c:      	ldr	x8, [sp, #0x58]
    b4a0:      	ldr	x9, [sp, #0x98]
    b4a4:      	cmp	x8, x9
    b4a8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    b4ac:      	add	x2, x24, #0x18
    b4b0:      	mov	w8, #0x4                // =4
    b4b4:      	mov	x0, x22
    b4b8:      	mov	w1, #0x8                // =8
    b4bc:      	blr	x8
    b4c0:      	ldr	x24, [sp, #0x98]
    b4c4:      	ldr	x21, [sp, #0x48]
    b4c8:      	add	x2, x24, #0x20
    b4cc:      	stp	x2, x24, [sp, #0x50]
    b4d0:      	ldr	x8, [sp, #0x30]
    b4d4:      	cmp	x21, x8
    b4d8:      	b.ne	0xb4e8 <generic_fentry_path+0x1038>
    b4dc:      	ldr	x8, [sp, #0x38]
    b4e0:      	cmp	x2, x8
    b4e4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    b4e8:      	mov	w8, #0x4                // =4
    b4ec:      	add	x0, sp, #0x70
    b4f0:      	mov	w1, #0x8                // =8
    b4f4:      	blr	x8
    b4f8:      	ldr	x8, [sp, #0x70]
    b4fc:      	cmp	x21, x8
    b500:      	b.eq	0xb5f0 <generic_fentry_path+0x1140>
    b504:      	add	x23, x21, #0x18
    b508:      	mov	w8, #0x4                // =4
    b50c:      	add	x9, sp, #0x98
    b510:      	add	x0, sp, #0x98
    b514:      	mov	w1, #0x8                // =8
    b518:      	mov	x2, x23
    b51c:      	blr	x8
    b520:      	ldr	x8, [sp, #0x98]
    b524:      	cmp	x8, x21
    b528:      	b.eq	0xb5f0 <generic_fentry_path+0x1140>
    b52c:      	mov	w8, #0x4                // =4
    b530:      	add	x9, sp, #0x78
    b534:      	add	x0, sp, #0x78
    b538:      	mov	w1, #0x8                // =8
    b53c:      	mov	x2, x23
    b540:      	blr	x8
    b544:      	add	x2, x21, #0x20
    b548:      	mov	w8, #0x4                // =4
    b54c:      	mov	w9, #0x10               // =16
    b550:      	add	x10, sp, #0x80
    b554:      	add	x0, sp, #0x80
    b558:      	mov	w1, #0x10               // =16
    b55c:      	blr	x8
    b560:      	ldr	w21, [sp, #0x84]
    b564:      	ldr	x8, [sp, #0x40]
    b568:      	ldr	x10, [sp, #0x60]
    b56c:      	sub	x12, x10, x8
    b570:      	ldr	w23, [sp, #0x68]
    b574:      	subs	w10, w21, w23
    b578:      	ldr	x9, [sp, #0x88]
    b57c:      	csel	w10, wzr, w10, lo
    b580:      	cmp	w23, w21
    b584:      	csel	w11, w23, w21, lo
    b588:      	cinc	w13, w11, hi
    b58c:      	sub	w14, w23, w13
    b590:      	subs	x12, x12, x13
    b594:      	str	w14, [sp, #0x68]
    b598:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    b59c:      	cmp	x12, #0xfff
    b5a0:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    b5a4:      	cmp	w23, w21
    b5a8:      	b.ls	0xb5b4 <generic_fentry_path+0x1104>
    b5ac:      	mov	w13, #0x2f              // =47
    b5b0:      	strb	w13, [x8, x12]
    b5b4:      	add	x19, x8, x12
    b5b8:      	cmp	w23, w21
    b5bc:      	add	x2, x9, x10
    b5c0:      	and	w1, w11, #0xff
    b5c4:      	mov	w8, #0x4                // =4
    b5c8:      	cinc	x0, x19, hi
    b5cc:      	blr	x8
    b5d0:      	cmp	w23, w21
    b5d4:      	str	x19, [sp, #0x60]
    b5d8:      	add	x19, sp, #0x70
    b5dc:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    b5e0:      	ldr	x21, [sp, #0x78]
    b5e4:      	ldp	x2, x24, [sp, #0x50]
    b5e8:      	str	x21, [sp, #0x48]
    b5ec:      	b	0xb63c <generic_fentry_path+0x118c>
    b5f0:      	add	x2, x24, #0x10
    b5f4:      	mov	w8, #0x4                // =4
    b5f8:      	add	x9, sp, #0x98
    b5fc:      	add	x0, sp, #0x98
    b600:      	mov	w1, #0x8                // =8
    b604:      	blr	x8
    b608:      	ldr	x8, [sp, #0x58]
    b60c:      	ldr	x9, [sp, #0x98]
    b610:      	cmp	x8, x9
    b614:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    b618:      	add	x2, x24, #0x18
    b61c:      	mov	w8, #0x4                // =4
    b620:      	mov	x0, x22
    b624:      	mov	w1, #0x8                // =8
    b628:      	blr	x8
    b62c:      	ldr	x24, [sp, #0x98]
    b630:      	ldr	x21, [sp, #0x48]
    b634:      	add	x2, x24, #0x20
    b638:      	stp	x2, x24, [sp, #0x50]
    b63c:      	ldr	x8, [sp, #0x30]
    b640:      	cmp	x21, x8
    b644:      	b.ne	0xb654 <generic_fentry_path+0x11a4>
    b648:      	ldr	x8, [sp, #0x38]
    b64c:      	cmp	x2, x8
    b650:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    b654:      	mov	w8, #0x4                // =4
    b658:      	add	x0, sp, #0x70
    b65c:      	mov	w1, #0x8                // =8
    b660:      	blr	x8
    b664:      	ldr	x8, [sp, #0x70]
    b668:      	cmp	x21, x8
    b66c:      	b.eq	0xb75c <generic_fentry_path+0x12ac>
    b670:      	add	x23, x21, #0x18
    b674:      	mov	w8, #0x4                // =4
    b678:      	add	x9, sp, #0x98
    b67c:      	add	x0, sp, #0x98
    b680:      	mov	w1, #0x8                // =8
    b684:      	mov	x2, x23
    b688:      	blr	x8
    b68c:      	ldr	x8, [sp, #0x98]
    b690:      	cmp	x8, x21
    b694:      	b.eq	0xb75c <generic_fentry_path+0x12ac>
    b698:      	mov	w8, #0x4                // =4
    b69c:      	add	x9, sp, #0x78
    b6a0:      	add	x0, sp, #0x78
    b6a4:      	mov	w1, #0x8                // =8
    b6a8:      	mov	x2, x23
    b6ac:      	blr	x8
    b6b0:      	add	x2, x21, #0x20
    b6b4:      	mov	w8, #0x4                // =4
    b6b8:      	mov	w9, #0x10               // =16
    b6bc:      	add	x10, sp, #0x80
    b6c0:      	add	x0, sp, #0x80
    b6c4:      	mov	w1, #0x10               // =16
    b6c8:      	blr	x8
    b6cc:      	ldr	w21, [sp, #0x84]
    b6d0:      	ldr	x8, [sp, #0x40]
    b6d4:      	ldr	x10, [sp, #0x60]
    b6d8:      	sub	x12, x10, x8
    b6dc:      	ldr	w23, [sp, #0x68]
    b6e0:      	subs	w10, w21, w23
    b6e4:      	ldr	x9, [sp, #0x88]
    b6e8:      	csel	w10, wzr, w10, lo
    b6ec:      	cmp	w23, w21
    b6f0:      	csel	w11, w23, w21, lo
    b6f4:      	cinc	w13, w11, hi
    b6f8:      	sub	w14, w23, w13
    b6fc:      	subs	x12, x12, x13
    b700:      	str	w14, [sp, #0x68]
    b704:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    b708:      	cmp	x12, #0xfff
    b70c:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    b710:      	cmp	w23, w21
    b714:      	b.ls	0xb720 <generic_fentry_path+0x1270>
    b718:      	mov	w13, #0x2f              // =47
    b71c:      	strb	w13, [x8, x12]
    b720:      	add	x19, x8, x12
    b724:      	cmp	w23, w21
    b728:      	add	x2, x9, x10
    b72c:      	and	w1, w11, #0xff
    b730:      	mov	w8, #0x4                // =4
    b734:      	cinc	x0, x19, hi
    b738:      	blr	x8
    b73c:      	cmp	w23, w21
    b740:      	str	x19, [sp, #0x60]
    b744:      	add	x19, sp, #0x70
    b748:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    b74c:      	ldr	x21, [sp, #0x78]
    b750:      	ldp	x2, x24, [sp, #0x50]
    b754:      	str	x21, [sp, #0x48]
    b758:      	b	0xb7a8 <generic_fentry_path+0x12f8>
    b75c:      	add	x2, x24, #0x10
    b760:      	mov	w8, #0x4                // =4
    b764:      	add	x9, sp, #0x98
    b768:      	add	x0, sp, #0x98
    b76c:      	mov	w1, #0x8                // =8
    b770:      	blr	x8
    b774:      	ldr	x8, [sp, #0x58]
    b778:      	ldr	x9, [sp, #0x98]
    b77c:      	cmp	x8, x9
    b780:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    b784:      	add	x2, x24, #0x18
    b788:      	mov	w8, #0x4                // =4
    b78c:      	mov	x0, x22
    b790:      	mov	w1, #0x8                // =8
    b794:      	blr	x8
    b798:      	ldr	x24, [sp, #0x98]
    b79c:      	ldr	x21, [sp, #0x48]
    b7a0:      	add	x2, x24, #0x20
    b7a4:      	stp	x2, x24, [sp, #0x50]
    b7a8:      	ldr	x8, [sp, #0x30]
    b7ac:      	cmp	x21, x8
    b7b0:      	b.ne	0xb7c0 <generic_fentry_path+0x1310>
    b7b4:      	ldr	x8, [sp, #0x38]
    b7b8:      	cmp	x2, x8
    b7bc:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    b7c0:      	mov	w8, #0x4                // =4
    b7c4:      	add	x0, sp, #0x70
    b7c8:      	mov	w1, #0x8                // =8
    b7cc:      	blr	x8
    b7d0:      	ldr	x8, [sp, #0x70]
    b7d4:      	cmp	x21, x8
    b7d8:      	b.eq	0xb8c8 <generic_fentry_path+0x1418>
    b7dc:      	add	x23, x21, #0x18
    b7e0:      	mov	w8, #0x4                // =4
    b7e4:      	add	x9, sp, #0x98
    b7e8:      	add	x0, sp, #0x98
    b7ec:      	mov	w1, #0x8                // =8
    b7f0:      	mov	x2, x23
    b7f4:      	blr	x8
    b7f8:      	ldr	x8, [sp, #0x98]
    b7fc:      	cmp	x8, x21
    b800:      	b.eq	0xb8c8 <generic_fentry_path+0x1418>
    b804:      	mov	w8, #0x4                // =4
    b808:      	add	x9, sp, #0x78
    b80c:      	add	x0, sp, #0x78
    b810:      	mov	w1, #0x8                // =8
    b814:      	mov	x2, x23
    b818:      	blr	x8
    b81c:      	add	x2, x21, #0x20
    b820:      	mov	w8, #0x4                // =4
    b824:      	mov	w9, #0x10               // =16
    b828:      	add	x10, sp, #0x80
    b82c:      	add	x0, sp, #0x80
    b830:      	mov	w1, #0x10               // =16
    b834:      	blr	x8
    b838:      	ldr	w21, [sp, #0x84]
    b83c:      	ldr	x8, [sp, #0x40]
    b840:      	ldr	x10, [sp, #0x60]
    b844:      	sub	x12, x10, x8
    b848:      	ldr	w23, [sp, #0x68]
    b84c:      	subs	w10, w21, w23
    b850:      	ldr	x9, [sp, #0x88]
    b854:      	csel	w10, wzr, w10, lo
    b858:      	cmp	w23, w21
    b85c:      	csel	w11, w23, w21, lo
    b860:      	cinc	w13, w11, hi
    b864:      	sub	w14, w23, w13
    b868:      	subs	x12, x12, x13
    b86c:      	str	w14, [sp, #0x68]
    b870:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    b874:      	cmp	x12, #0xfff
    b878:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    b87c:      	cmp	w23, w21
    b880:      	b.ls	0xb88c <generic_fentry_path+0x13dc>
    b884:      	mov	w13, #0x2f              // =47
    b888:      	strb	w13, [x8, x12]
    b88c:      	add	x19, x8, x12
    b890:      	cmp	w23, w21
    b894:      	add	x2, x9, x10
    b898:      	and	w1, w11, #0xff
    b89c:      	mov	w8, #0x4                // =4
    b8a0:      	cinc	x0, x19, hi
    b8a4:      	blr	x8
    b8a8:      	cmp	w23, w21
    b8ac:      	str	x19, [sp, #0x60]
    b8b0:      	add	x19, sp, #0x70
    b8b4:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    b8b8:      	ldr	x21, [sp, #0x78]
    b8bc:      	ldp	x2, x24, [sp, #0x50]
    b8c0:      	str	x21, [sp, #0x48]
    b8c4:      	b	0xb914 <generic_fentry_path+0x1464>
    b8c8:      	add	x2, x24, #0x10
    b8cc:      	mov	w8, #0x4                // =4
    b8d0:      	add	x9, sp, #0x98
    b8d4:      	add	x0, sp, #0x98
    b8d8:      	mov	w1, #0x8                // =8
    b8dc:      	blr	x8
    b8e0:      	ldr	x8, [sp, #0x58]
    b8e4:      	ldr	x9, [sp, #0x98]
    b8e8:      	cmp	x8, x9
    b8ec:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    b8f0:      	add	x2, x24, #0x18
    b8f4:      	mov	w8, #0x4                // =4
    b8f8:      	mov	x0, x22
    b8fc:      	mov	w1, #0x8                // =8
    b900:      	blr	x8
    b904:      	ldr	x24, [sp, #0x98]
    b908:      	ldr	x21, [sp, #0x48]
    b90c:      	add	x2, x24, #0x20
    b910:      	stp	x2, x24, [sp, #0x50]
    b914:      	ldr	x8, [sp, #0x30]
    b918:      	cmp	x21, x8
    b91c:      	b.ne	0xb92c <generic_fentry_path+0x147c>
    b920:      	ldr	x8, [sp, #0x38]
    b924:      	cmp	x2, x8
    b928:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    b92c:      	mov	w8, #0x4                // =4
    b930:      	add	x0, sp, #0x70
    b934:      	mov	w1, #0x8                // =8
    b938:      	blr	x8
    b93c:      	ldr	x8, [sp, #0x70]
    b940:      	cmp	x21, x8
    b944:      	b.eq	0xba34 <generic_fentry_path+0x1584>
    b948:      	add	x23, x21, #0x18
    b94c:      	mov	w8, #0x4                // =4
    b950:      	add	x9, sp, #0x98
    b954:      	add	x0, sp, #0x98
    b958:      	mov	w1, #0x8                // =8
    b95c:      	mov	x2, x23
    b960:      	blr	x8
    b964:      	ldr	x8, [sp, #0x98]
    b968:      	cmp	x8, x21
    b96c:      	b.eq	0xba34 <generic_fentry_path+0x1584>
    b970:      	mov	w8, #0x4                // =4
    b974:      	add	x9, sp, #0x78
    b978:      	add	x0, sp, #0x78
    b97c:      	mov	w1, #0x8                // =8
    b980:      	mov	x2, x23
    b984:      	blr	x8
    b988:      	add	x2, x21, #0x20
    b98c:      	mov	w8, #0x4                // =4
    b990:      	mov	w9, #0x10               // =16
    b994:      	add	x10, sp, #0x80
    b998:      	add	x0, sp, #0x80
    b99c:      	mov	w1, #0x10               // =16
    b9a0:      	blr	x8
    b9a4:      	ldr	w21, [sp, #0x84]
    b9a8:      	ldr	x8, [sp, #0x40]
    b9ac:      	ldr	x10, [sp, #0x60]
    b9b0:      	sub	x12, x10, x8
    b9b4:      	ldr	w23, [sp, #0x68]
    b9b8:      	subs	w10, w21, w23
    b9bc:      	ldr	x9, [sp, #0x88]
    b9c0:      	csel	w10, wzr, w10, lo
    b9c4:      	cmp	w23, w21
    b9c8:      	csel	w11, w23, w21, lo
    b9cc:      	cinc	w13, w11, hi
    b9d0:      	sub	w14, w23, w13
    b9d4:      	subs	x12, x12, x13
    b9d8:      	str	w14, [sp, #0x68]
    b9dc:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    b9e0:      	cmp	x12, #0xfff
    b9e4:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    b9e8:      	cmp	w23, w21
    b9ec:      	b.ls	0xb9f8 <generic_fentry_path+0x1548>
    b9f0:      	mov	w13, #0x2f              // =47
    b9f4:      	strb	w13, [x8, x12]
    b9f8:      	add	x19, x8, x12
    b9fc:      	cmp	w23, w21
    ba00:      	add	x2, x9, x10
    ba04:      	and	w1, w11, #0xff
    ba08:      	mov	w8, #0x4                // =4
    ba0c:      	cinc	x0, x19, hi
    ba10:      	blr	x8
    ba14:      	cmp	w23, w21
    ba18:      	str	x19, [sp, #0x60]
    ba1c:      	add	x19, sp, #0x70
    ba20:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    ba24:      	ldr	x21, [sp, #0x78]
    ba28:      	ldp	x2, x24, [sp, #0x50]
    ba2c:      	str	x21, [sp, #0x48]
    ba30:      	b	0xba80 <generic_fentry_path+0x15d0>
    ba34:      	add	x2, x24, #0x10
    ba38:      	mov	w8, #0x4                // =4
    ba3c:      	add	x9, sp, #0x98
    ba40:      	add	x0, sp, #0x98
    ba44:      	mov	w1, #0x8                // =8
    ba48:      	blr	x8
    ba4c:      	ldr	x8, [sp, #0x58]
    ba50:      	ldr	x9, [sp, #0x98]
    ba54:      	cmp	x8, x9
    ba58:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    ba5c:      	add	x2, x24, #0x18
    ba60:      	mov	w8, #0x4                // =4
    ba64:      	mov	x0, x22
    ba68:      	mov	w1, #0x8                // =8
    ba6c:      	blr	x8
    ba70:      	ldr	x24, [sp, #0x98]
    ba74:      	ldr	x21, [sp, #0x48]
    ba78:      	add	x2, x24, #0x20
    ba7c:      	stp	x2, x24, [sp, #0x50]
    ba80:      	ldr	x8, [sp, #0x30]
    ba84:      	cmp	x21, x8
    ba88:      	b.ne	0xba98 <generic_fentry_path+0x15e8>
    ba8c:      	ldr	x8, [sp, #0x38]
    ba90:      	cmp	x2, x8
    ba94:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    ba98:      	mov	w8, #0x4                // =4
    ba9c:      	add	x0, sp, #0x70
    baa0:      	mov	w1, #0x8                // =8
    baa4:      	blr	x8
    baa8:      	ldr	x8, [sp, #0x70]
    baac:      	cmp	x21, x8
    bab0:      	b.eq	0xbba0 <generic_fentry_path+0x16f0>
    bab4:      	add	x23, x21, #0x18
    bab8:      	mov	w8, #0x4                // =4
    babc:      	add	x9, sp, #0x98
    bac0:      	add	x0, sp, #0x98
    bac4:      	mov	w1, #0x8                // =8
    bac8:      	mov	x2, x23
    bacc:      	blr	x8
    bad0:      	ldr	x8, [sp, #0x98]
    bad4:      	cmp	x8, x21
    bad8:      	b.eq	0xbba0 <generic_fentry_path+0x16f0>
    badc:      	mov	w8, #0x4                // =4
    bae0:      	add	x9, sp, #0x78
    bae4:      	add	x0, sp, #0x78
    bae8:      	mov	w1, #0x8                // =8
    baec:      	mov	x2, x23
    baf0:      	blr	x8
    baf4:      	add	x2, x21, #0x20
    baf8:      	mov	w8, #0x4                // =4
    bafc:      	mov	w9, #0x10               // =16
    bb00:      	add	x10, sp, #0x80
    bb04:      	add	x0, sp, #0x80
    bb08:      	mov	w1, #0x10               // =16
    bb0c:      	blr	x8
    bb10:      	ldr	w21, [sp, #0x84]
    bb14:      	ldr	x8, [sp, #0x40]
    bb18:      	ldr	x10, [sp, #0x60]
    bb1c:      	sub	x12, x10, x8
    bb20:      	ldr	w23, [sp, #0x68]
    bb24:      	subs	w10, w21, w23
    bb28:      	ldr	x9, [sp, #0x88]
    bb2c:      	csel	w10, wzr, w10, lo
    bb30:      	cmp	w23, w21
    bb34:      	csel	w11, w23, w21, lo
    bb38:      	cinc	w13, w11, hi
    bb3c:      	sub	w14, w23, w13
    bb40:      	subs	x12, x12, x13
    bb44:      	str	w14, [sp, #0x68]
    bb48:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    bb4c:      	cmp	x12, #0xfff
    bb50:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    bb54:      	cmp	w23, w21
    bb58:      	b.ls	0xbb64 <generic_fentry_path+0x16b4>
    bb5c:      	mov	w13, #0x2f              // =47
    bb60:      	strb	w13, [x8, x12]
    bb64:      	add	x19, x8, x12
    bb68:      	cmp	w23, w21
    bb6c:      	add	x2, x9, x10
    bb70:      	and	w1, w11, #0xff
    bb74:      	mov	w8, #0x4                // =4
    bb78:      	cinc	x0, x19, hi
    bb7c:      	blr	x8
    bb80:      	cmp	w23, w21
    bb84:      	str	x19, [sp, #0x60]
    bb88:      	add	x19, sp, #0x70
    bb8c:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    bb90:      	ldr	x21, [sp, #0x78]
    bb94:      	ldp	x2, x24, [sp, #0x50]
    bb98:      	str	x21, [sp, #0x48]
    bb9c:      	b	0xbbec <generic_fentry_path+0x173c>
    bba0:      	add	x2, x24, #0x10
    bba4:      	mov	w8, #0x4                // =4
    bba8:      	add	x9, sp, #0x98
    bbac:      	add	x0, sp, #0x98
    bbb0:      	mov	w1, #0x8                // =8
    bbb4:      	blr	x8
    bbb8:      	ldr	x8, [sp, #0x58]
    bbbc:      	ldr	x9, [sp, #0x98]
    bbc0:      	cmp	x8, x9
    bbc4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    bbc8:      	add	x2, x24, #0x18
    bbcc:      	mov	w8, #0x4                // =4
    bbd0:      	mov	x0, x22
    bbd4:      	mov	w1, #0x8                // =8
    bbd8:      	blr	x8
    bbdc:      	ldr	x24, [sp, #0x98]
    bbe0:      	ldr	x21, [sp, #0x48]
    bbe4:      	add	x2, x24, #0x20
    bbe8:      	stp	x2, x24, [sp, #0x50]
    bbec:      	ldr	x8, [sp, #0x30]
    bbf0:      	cmp	x21, x8
    bbf4:      	b.ne	0xbc04 <generic_fentry_path+0x1754>
    bbf8:      	ldr	x8, [sp, #0x38]
    bbfc:      	cmp	x2, x8
    bc00:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    bc04:      	mov	w8, #0x4                // =4
    bc08:      	add	x0, sp, #0x70
    bc0c:      	mov	w1, #0x8                // =8
    bc10:      	blr	x8
    bc14:      	ldr	x8, [sp, #0x70]
    bc18:      	cmp	x21, x8
    bc1c:      	b.eq	0xbd0c <generic_fentry_path+0x185c>
    bc20:      	add	x23, x21, #0x18
    bc24:      	mov	w8, #0x4                // =4
    bc28:      	add	x9, sp, #0x98
    bc2c:      	add	x0, sp, #0x98
    bc30:      	mov	w1, #0x8                // =8
    bc34:      	mov	x2, x23
    bc38:      	blr	x8
    bc3c:      	ldr	x8, [sp, #0x98]
    bc40:      	cmp	x8, x21
    bc44:      	b.eq	0xbd0c <generic_fentry_path+0x185c>
    bc48:      	mov	w8, #0x4                // =4
    bc4c:      	add	x9, sp, #0x78
    bc50:      	add	x0, sp, #0x78
    bc54:      	mov	w1, #0x8                // =8
    bc58:      	mov	x2, x23
    bc5c:      	blr	x8
    bc60:      	add	x2, x21, #0x20
    bc64:      	mov	w8, #0x4                // =4
    bc68:      	mov	w9, #0x10               // =16
    bc6c:      	add	x10, sp, #0x80
    bc70:      	add	x0, sp, #0x80
    bc74:      	mov	w1, #0x10               // =16
    bc78:      	blr	x8
    bc7c:      	ldr	w21, [sp, #0x84]
    bc80:      	ldr	x8, [sp, #0x40]
    bc84:      	ldr	x10, [sp, #0x60]
    bc88:      	sub	x12, x10, x8
    bc8c:      	ldr	w23, [sp, #0x68]
    bc90:      	subs	w10, w21, w23
    bc94:      	ldr	x9, [sp, #0x88]
    bc98:      	csel	w10, wzr, w10, lo
    bc9c:      	cmp	w23, w21
    bca0:      	csel	w11, w23, w21, lo
    bca4:      	cinc	w13, w11, hi
    bca8:      	sub	w14, w23, w13
    bcac:      	subs	x12, x12, x13
    bcb0:      	str	w14, [sp, #0x68]
    bcb4:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    bcb8:      	cmp	x12, #0xfff
    bcbc:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    bcc0:      	cmp	w23, w21
    bcc4:      	b.ls	0xbcd0 <generic_fentry_path+0x1820>
    bcc8:      	mov	w13, #0x2f              // =47
    bccc:      	strb	w13, [x8, x12]
    bcd0:      	add	x19, x8, x12
    bcd4:      	cmp	w23, w21
    bcd8:      	add	x2, x9, x10
    bcdc:      	and	w1, w11, #0xff
    bce0:      	mov	w8, #0x4                // =4
    bce4:      	cinc	x0, x19, hi
    bce8:      	blr	x8
    bcec:      	cmp	w23, w21
    bcf0:      	str	x19, [sp, #0x60]
    bcf4:      	add	x19, sp, #0x70
    bcf8:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    bcfc:      	ldr	x21, [sp, #0x78]
    bd00:      	ldp	x2, x24, [sp, #0x50]
    bd04:      	str	x21, [sp, #0x48]
    bd08:      	b	0xbd58 <generic_fentry_path+0x18a8>
    bd0c:      	add	x2, x24, #0x10
    bd10:      	mov	w8, #0x4                // =4
    bd14:      	add	x9, sp, #0x98
    bd18:      	add	x0, sp, #0x98
    bd1c:      	mov	w1, #0x8                // =8
    bd20:      	blr	x8
    bd24:      	ldr	x8, [sp, #0x58]
    bd28:      	ldr	x9, [sp, #0x98]
    bd2c:      	cmp	x8, x9
    bd30:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    bd34:      	add	x2, x24, #0x18
    bd38:      	mov	w8, #0x4                // =4
    bd3c:      	mov	x0, x22
    bd40:      	mov	w1, #0x8                // =8
    bd44:      	blr	x8
    bd48:      	ldr	x24, [sp, #0x98]
    bd4c:      	ldr	x21, [sp, #0x48]
    bd50:      	add	x2, x24, #0x20
    bd54:      	stp	x2, x24, [sp, #0x50]
    bd58:      	ldr	x8, [sp, #0x30]
    bd5c:      	cmp	x21, x8
    bd60:      	b.ne	0xbd70 <generic_fentry_path+0x18c0>
    bd64:      	ldr	x8, [sp, #0x38]
    bd68:      	cmp	x2, x8
    bd6c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    bd70:      	mov	w8, #0x4                // =4
    bd74:      	add	x0, sp, #0x70
    bd78:      	mov	w1, #0x8                // =8
    bd7c:      	blr	x8
    bd80:      	ldr	x8, [sp, #0x70]
    bd84:      	cmp	x21, x8
    bd88:      	b.eq	0xbe78 <generic_fentry_path+0x19c8>
    bd8c:      	add	x23, x21, #0x18
    bd90:      	mov	w8, #0x4                // =4
    bd94:      	add	x9, sp, #0x98
    bd98:      	add	x0, sp, #0x98
    bd9c:      	mov	w1, #0x8                // =8
    bda0:      	mov	x2, x23
    bda4:      	blr	x8
    bda8:      	ldr	x8, [sp, #0x98]
    bdac:      	cmp	x8, x21
    bdb0:      	b.eq	0xbe78 <generic_fentry_path+0x19c8>
    bdb4:      	mov	w8, #0x4                // =4
    bdb8:      	add	x9, sp, #0x78
    bdbc:      	add	x0, sp, #0x78
    bdc0:      	mov	w1, #0x8                // =8
    bdc4:      	mov	x2, x23
    bdc8:      	blr	x8
    bdcc:      	add	x2, x21, #0x20
    bdd0:      	mov	w8, #0x4                // =4
    bdd4:      	mov	w9, #0x10               // =16
    bdd8:      	add	x10, sp, #0x80
    bddc:      	add	x0, sp, #0x80
    bde0:      	mov	w1, #0x10               // =16
    bde4:      	blr	x8
    bde8:      	ldr	w21, [sp, #0x84]
    bdec:      	ldr	x8, [sp, #0x40]
    bdf0:      	ldr	x10, [sp, #0x60]
    bdf4:      	sub	x12, x10, x8
    bdf8:      	ldr	w23, [sp, #0x68]
    bdfc:      	subs	w10, w21, w23
    be00:      	ldr	x9, [sp, #0x88]
    be04:      	csel	w10, wzr, w10, lo
    be08:      	cmp	w23, w21
    be0c:      	csel	w11, w23, w21, lo
    be10:      	cinc	w13, w11, hi
    be14:      	sub	w14, w23, w13
    be18:      	subs	x12, x12, x13
    be1c:      	str	w14, [sp, #0x68]
    be20:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    be24:      	cmp	x12, #0xfff
    be28:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    be2c:      	cmp	w23, w21
    be30:      	b.ls	0xbe3c <generic_fentry_path+0x198c>
    be34:      	mov	w13, #0x2f              // =47
    be38:      	strb	w13, [x8, x12]
    be3c:      	add	x19, x8, x12
    be40:      	cmp	w23, w21
    be44:      	add	x2, x9, x10
    be48:      	and	w1, w11, #0xff
    be4c:      	mov	w8, #0x4                // =4
    be50:      	cinc	x0, x19, hi
    be54:      	blr	x8
    be58:      	cmp	w23, w21
    be5c:      	str	x19, [sp, #0x60]
    be60:      	add	x19, sp, #0x70
    be64:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    be68:      	ldr	x21, [sp, #0x78]
    be6c:      	ldp	x2, x24, [sp, #0x50]
    be70:      	str	x21, [sp, #0x48]
    be74:      	b	0xbec4 <generic_fentry_path+0x1a14>
    be78:      	add	x2, x24, #0x10
    be7c:      	mov	w8, #0x4                // =4
    be80:      	add	x9, sp, #0x98
    be84:      	add	x0, sp, #0x98
    be88:      	mov	w1, #0x8                // =8
    be8c:      	blr	x8
    be90:      	ldr	x8, [sp, #0x58]
    be94:      	ldr	x9, [sp, #0x98]
    be98:      	cmp	x8, x9
    be9c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    bea0:      	add	x2, x24, #0x18
    bea4:      	mov	w8, #0x4                // =4
    bea8:      	mov	x0, x22
    beac:      	mov	w1, #0x8                // =8
    beb0:      	blr	x8
    beb4:      	ldr	x24, [sp, #0x98]
    beb8:      	ldr	x21, [sp, #0x48]
    bebc:      	add	x2, x24, #0x20
    bec0:      	stp	x2, x24, [sp, #0x50]
    bec4:      	ldr	x8, [sp, #0x30]
    bec8:      	cmp	x21, x8
    becc:      	b.ne	0xbedc <generic_fentry_path+0x1a2c>
    bed0:      	ldr	x8, [sp, #0x38]
    bed4:      	cmp	x2, x8
    bed8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    bedc:      	mov	w8, #0x4                // =4
    bee0:      	add	x0, sp, #0x70
    bee4:      	mov	w1, #0x8                // =8
    bee8:      	blr	x8
    beec:      	ldr	x8, [sp, #0x70]
    bef0:      	cmp	x21, x8
    bef4:      	b.eq	0xbfe4 <generic_fentry_path+0x1b34>
    bef8:      	add	x23, x21, #0x18
    befc:      	mov	w8, #0x4                // =4
    bf00:      	add	x9, sp, #0x98
    bf04:      	add	x0, sp, #0x98
    bf08:      	mov	w1, #0x8                // =8
    bf0c:      	mov	x2, x23
    bf10:      	blr	x8
    bf14:      	ldr	x8, [sp, #0x98]
    bf18:      	cmp	x8, x21
    bf1c:      	b.eq	0xbfe4 <generic_fentry_path+0x1b34>
    bf20:      	mov	w8, #0x4                // =4
    bf24:      	add	x9, sp, #0x78
    bf28:      	add	x0, sp, #0x78
    bf2c:      	mov	w1, #0x8                // =8
    bf30:      	mov	x2, x23
    bf34:      	blr	x8
    bf38:      	add	x2, x21, #0x20
    bf3c:      	mov	w8, #0x4                // =4
    bf40:      	mov	w9, #0x10               // =16
    bf44:      	add	x10, sp, #0x80
    bf48:      	add	x0, sp, #0x80
    bf4c:      	mov	w1, #0x10               // =16
    bf50:      	blr	x8
    bf54:      	ldr	w21, [sp, #0x84]
    bf58:      	ldr	x8, [sp, #0x40]
    bf5c:      	ldr	x10, [sp, #0x60]
    bf60:      	sub	x12, x10, x8
    bf64:      	ldr	w23, [sp, #0x68]
    bf68:      	subs	w10, w21, w23
    bf6c:      	ldr	x9, [sp, #0x88]
    bf70:      	csel	w10, wzr, w10, lo
    bf74:      	cmp	w23, w21
    bf78:      	csel	w11, w23, w21, lo
    bf7c:      	cinc	w13, w11, hi
    bf80:      	sub	w14, w23, w13
    bf84:      	subs	x12, x12, x13
    bf88:      	str	w14, [sp, #0x68]
    bf8c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    bf90:      	cmp	x12, #0xfff
    bf94:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    bf98:      	cmp	w23, w21
    bf9c:      	b.ls	0xbfa8 <generic_fentry_path+0x1af8>
    bfa0:      	mov	w13, #0x2f              // =47
    bfa4:      	strb	w13, [x8, x12]
    bfa8:      	add	x19, x8, x12
    bfac:      	cmp	w23, w21
    bfb0:      	add	x2, x9, x10
    bfb4:      	and	w1, w11, #0xff
    bfb8:      	mov	w8, #0x4                // =4
    bfbc:      	cinc	x0, x19, hi
    bfc0:      	blr	x8
    bfc4:      	cmp	w23, w21
    bfc8:      	str	x19, [sp, #0x60]
    bfcc:      	add	x19, sp, #0x70
    bfd0:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    bfd4:      	ldr	x21, [sp, #0x78]
    bfd8:      	ldp	x2, x24, [sp, #0x50]
    bfdc:      	str	x21, [sp, #0x48]
    bfe0:      	b	0xc030 <generic_fentry_path+0x1b80>
    bfe4:      	add	x2, x24, #0x10
    bfe8:      	mov	w8, #0x4                // =4
    bfec:      	add	x9, sp, #0x98
    bff0:      	add	x0, sp, #0x98
    bff4:      	mov	w1, #0x8                // =8
    bff8:      	blr	x8
    bffc:      	ldr	x8, [sp, #0x58]
    c000:      	ldr	x9, [sp, #0x98]
    c004:      	cmp	x8, x9
    c008:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    c00c:      	add	x2, x24, #0x18
    c010:      	mov	w8, #0x4                // =4
    c014:      	mov	x0, x22
    c018:      	mov	w1, #0x8                // =8
    c01c:      	blr	x8
    c020:      	ldr	x24, [sp, #0x98]
    c024:      	ldr	x21, [sp, #0x48]
    c028:      	add	x2, x24, #0x20
    c02c:      	stp	x2, x24, [sp, #0x50]
    c030:      	ldr	x8, [sp, #0x30]
    c034:      	cmp	x21, x8
    c038:      	b.ne	0xc048 <generic_fentry_path+0x1b98>
    c03c:      	ldr	x8, [sp, #0x38]
    c040:      	cmp	x2, x8
    c044:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    c048:      	mov	w8, #0x4                // =4
    c04c:      	add	x0, sp, #0x70
    c050:      	mov	w1, #0x8                // =8
    c054:      	blr	x8
    c058:      	ldr	x8, [sp, #0x70]
    c05c:      	cmp	x21, x8
    c060:      	b.eq	0xc150 <generic_fentry_path+0x1ca0>
    c064:      	add	x23, x21, #0x18
    c068:      	mov	w8, #0x4                // =4
    c06c:      	add	x9, sp, #0x98
    c070:      	add	x0, sp, #0x98
    c074:      	mov	w1, #0x8                // =8
    c078:      	mov	x2, x23
    c07c:      	blr	x8
    c080:      	ldr	x8, [sp, #0x98]
    c084:      	cmp	x8, x21
    c088:      	b.eq	0xc150 <generic_fentry_path+0x1ca0>
    c08c:      	mov	w8, #0x4                // =4
    c090:      	add	x9, sp, #0x78
    c094:      	add	x0, sp, #0x78
    c098:      	mov	w1, #0x8                // =8
    c09c:      	mov	x2, x23
    c0a0:      	blr	x8
    c0a4:      	add	x2, x21, #0x20
    c0a8:      	mov	w8, #0x4                // =4
    c0ac:      	mov	w9, #0x10               // =16
    c0b0:      	add	x10, sp, #0x80
    c0b4:      	add	x0, sp, #0x80
    c0b8:      	mov	w1, #0x10               // =16
    c0bc:      	blr	x8
    c0c0:      	ldr	w21, [sp, #0x84]
    c0c4:      	ldr	x8, [sp, #0x40]
    c0c8:      	ldr	x10, [sp, #0x60]
    c0cc:      	sub	x12, x10, x8
    c0d0:      	ldr	w23, [sp, #0x68]
    c0d4:      	subs	w10, w21, w23
    c0d8:      	ldr	x9, [sp, #0x88]
    c0dc:      	csel	w10, wzr, w10, lo
    c0e0:      	cmp	w23, w21
    c0e4:      	csel	w11, w23, w21, lo
    c0e8:      	cinc	w13, w11, hi
    c0ec:      	sub	w14, w23, w13
    c0f0:      	subs	x12, x12, x13
    c0f4:      	str	w14, [sp, #0x68]
    c0f8:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    c0fc:      	cmp	x12, #0xfff
    c100:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    c104:      	cmp	w23, w21
    c108:      	b.ls	0xc114 <generic_fentry_path+0x1c64>
    c10c:      	mov	w13, #0x2f              // =47
    c110:      	strb	w13, [x8, x12]
    c114:      	add	x19, x8, x12
    c118:      	cmp	w23, w21
    c11c:      	add	x2, x9, x10
    c120:      	and	w1, w11, #0xff
    c124:      	mov	w8, #0x4                // =4
    c128:      	cinc	x0, x19, hi
    c12c:      	blr	x8
    c130:      	cmp	w23, w21
    c134:      	str	x19, [sp, #0x60]
    c138:      	add	x19, sp, #0x70
    c13c:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    c140:      	ldr	x21, [sp, #0x78]
    c144:      	ldp	x2, x24, [sp, #0x50]
    c148:      	str	x21, [sp, #0x48]
    c14c:      	b	0xc19c <generic_fentry_path+0x1cec>
    c150:      	add	x2, x24, #0x10
    c154:      	mov	w8, #0x4                // =4
    c158:      	add	x9, sp, #0x98
    c15c:      	add	x0, sp, #0x98
    c160:      	mov	w1, #0x8                // =8
    c164:      	blr	x8
    c168:      	ldr	x8, [sp, #0x58]
    c16c:      	ldr	x9, [sp, #0x98]
    c170:      	cmp	x8, x9
    c174:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    c178:      	add	x2, x24, #0x18
    c17c:      	mov	w8, #0x4                // =4
    c180:      	mov	x0, x22
    c184:      	mov	w1, #0x8                // =8
    c188:      	blr	x8
    c18c:      	ldr	x24, [sp, #0x98]
    c190:      	ldr	x21, [sp, #0x48]
    c194:      	add	x2, x24, #0x20
    c198:      	stp	x2, x24, [sp, #0x50]
    c19c:      	ldr	x8, [sp, #0x30]
    c1a0:      	cmp	x21, x8
    c1a4:      	b.ne	0xc1b4 <generic_fentry_path+0x1d04>
    c1a8:      	ldr	x8, [sp, #0x38]
    c1ac:      	cmp	x2, x8
    c1b0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    c1b4:      	mov	w8, #0x4                // =4
    c1b8:      	add	x0, sp, #0x70
    c1bc:      	mov	w1, #0x8                // =8
    c1c0:      	blr	x8
    c1c4:      	ldr	x8, [sp, #0x70]
    c1c8:      	cmp	x21, x8
    c1cc:      	b.eq	0xc2bc <generic_fentry_path+0x1e0c>
    c1d0:      	add	x23, x21, #0x18
    c1d4:      	mov	w8, #0x4                // =4
    c1d8:      	add	x9, sp, #0x98
    c1dc:      	add	x0, sp, #0x98
    c1e0:      	mov	w1, #0x8                // =8
    c1e4:      	mov	x2, x23
    c1e8:      	blr	x8
    c1ec:      	ldr	x8, [sp, #0x98]
    c1f0:      	cmp	x8, x21
    c1f4:      	b.eq	0xc2bc <generic_fentry_path+0x1e0c>
    c1f8:      	mov	w8, #0x4                // =4
    c1fc:      	add	x9, sp, #0x78
    c200:      	add	x0, sp, #0x78
    c204:      	mov	w1, #0x8                // =8
    c208:      	mov	x2, x23
    c20c:      	blr	x8
    c210:      	add	x2, x21, #0x20
    c214:      	mov	w8, #0x4                // =4
    c218:      	mov	w9, #0x10               // =16
    c21c:      	add	x10, sp, #0x80
    c220:      	add	x0, sp, #0x80
    c224:      	mov	w1, #0x10               // =16
    c228:      	blr	x8
    c22c:      	ldr	w21, [sp, #0x84]
    c230:      	ldr	x8, [sp, #0x40]
    c234:      	ldr	x10, [sp, #0x60]
    c238:      	sub	x12, x10, x8
    c23c:      	ldr	w23, [sp, #0x68]
    c240:      	subs	w10, w21, w23
    c244:      	ldr	x9, [sp, #0x88]
    c248:      	csel	w10, wzr, w10, lo
    c24c:      	cmp	w23, w21
    c250:      	csel	w11, w23, w21, lo
    c254:      	cinc	w13, w11, hi
    c258:      	sub	w14, w23, w13
    c25c:      	subs	x12, x12, x13
    c260:      	str	w14, [sp, #0x68]
    c264:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    c268:      	cmp	x12, #0xfff
    c26c:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    c270:      	cmp	w23, w21
    c274:      	b.ls	0xc280 <generic_fentry_path+0x1dd0>
    c278:      	mov	w13, #0x2f              // =47
    c27c:      	strb	w13, [x8, x12]
    c280:      	add	x19, x8, x12
    c284:      	cmp	w23, w21
    c288:      	add	x2, x9, x10
    c28c:      	and	w1, w11, #0xff
    c290:      	mov	w8, #0x4                // =4
    c294:      	cinc	x0, x19, hi
    c298:      	blr	x8
    c29c:      	cmp	w23, w21
    c2a0:      	str	x19, [sp, #0x60]
    c2a4:      	add	x19, sp, #0x70
    c2a8:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    c2ac:      	ldr	x21, [sp, #0x78]
    c2b0:      	ldp	x2, x24, [sp, #0x50]
    c2b4:      	str	x21, [sp, #0x48]
    c2b8:      	b	0xc308 <generic_fentry_path+0x1e58>
    c2bc:      	add	x2, x24, #0x10
    c2c0:      	mov	w8, #0x4                // =4
    c2c4:      	add	x9, sp, #0x98
    c2c8:      	add	x0, sp, #0x98
    c2cc:      	mov	w1, #0x8                // =8
    c2d0:      	blr	x8
    c2d4:      	ldr	x8, [sp, #0x58]
    c2d8:      	ldr	x9, [sp, #0x98]
    c2dc:      	cmp	x8, x9
    c2e0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    c2e4:      	add	x2, x24, #0x18
    c2e8:      	mov	w8, #0x4                // =4
    c2ec:      	mov	x0, x22
    c2f0:      	mov	w1, #0x8                // =8
    c2f4:      	blr	x8
    c2f8:      	ldr	x24, [sp, #0x98]
    c2fc:      	ldr	x21, [sp, #0x48]
    c300:      	add	x2, x24, #0x20
    c304:      	stp	x2, x24, [sp, #0x50]
    c308:      	ldr	x8, [sp, #0x30]
    c30c:      	cmp	x21, x8
    c310:      	b.ne	0xc320 <generic_fentry_path+0x1e70>
    c314:      	ldr	x8, [sp, #0x38]
    c318:      	cmp	x2, x8
    c31c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    c320:      	mov	w8, #0x4                // =4
    c324:      	add	x0, sp, #0x70
    c328:      	mov	w1, #0x8                // =8
    c32c:      	blr	x8
    c330:      	ldr	x8, [sp, #0x70]
    c334:      	cmp	x21, x8
    c338:      	b.eq	0xc428 <generic_fentry_path+0x1f78>
    c33c:      	add	x23, x21, #0x18
    c340:      	mov	w8, #0x4                // =4
    c344:      	add	x9, sp, #0x98
    c348:      	add	x0, sp, #0x98
    c34c:      	mov	w1, #0x8                // =8
    c350:      	mov	x2, x23
    c354:      	blr	x8
    c358:      	ldr	x8, [sp, #0x98]
    c35c:      	cmp	x8, x21
    c360:      	b.eq	0xc428 <generic_fentry_path+0x1f78>
    c364:      	mov	w8, #0x4                // =4
    c368:      	add	x9, sp, #0x78
    c36c:      	add	x0, sp, #0x78
    c370:      	mov	w1, #0x8                // =8
    c374:      	mov	x2, x23
    c378:      	blr	x8
    c37c:      	add	x2, x21, #0x20
    c380:      	mov	w8, #0x4                // =4
    c384:      	mov	w9, #0x10               // =16
    c388:      	add	x10, sp, #0x80
    c38c:      	add	x0, sp, #0x80
    c390:      	mov	w1, #0x10               // =16
    c394:      	blr	x8
    c398:      	ldr	w21, [sp, #0x84]
    c39c:      	ldr	x8, [sp, #0x40]
    c3a0:      	ldr	x10, [sp, #0x60]
    c3a4:      	sub	x12, x10, x8
    c3a8:      	ldr	w23, [sp, #0x68]
    c3ac:      	subs	w10, w21, w23
    c3b0:      	ldr	x9, [sp, #0x88]
    c3b4:      	csel	w10, wzr, w10, lo
    c3b8:      	cmp	w23, w21
    c3bc:      	csel	w11, w23, w21, lo
    c3c0:      	cinc	w13, w11, hi
    c3c4:      	sub	w14, w23, w13
    c3c8:      	subs	x12, x12, x13
    c3cc:      	str	w14, [sp, #0x68]
    c3d0:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    c3d4:      	cmp	x12, #0xfff
    c3d8:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    c3dc:      	cmp	w23, w21
    c3e0:      	b.ls	0xc3ec <generic_fentry_path+0x1f3c>
    c3e4:      	mov	w13, #0x2f              // =47
    c3e8:      	strb	w13, [x8, x12]
    c3ec:      	add	x19, x8, x12
    c3f0:      	cmp	w23, w21
    c3f4:      	add	x2, x9, x10
    c3f8:      	and	w1, w11, #0xff
    c3fc:      	mov	w8, #0x4                // =4
    c400:      	cinc	x0, x19, hi
    c404:      	blr	x8
    c408:      	cmp	w23, w21
    c40c:      	str	x19, [sp, #0x60]
    c410:      	add	x19, sp, #0x70
    c414:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    c418:      	ldr	x21, [sp, #0x78]
    c41c:      	ldp	x2, x24, [sp, #0x50]
    c420:      	str	x21, [sp, #0x48]
    c424:      	b	0xc474 <generic_fentry_path+0x1fc4>
    c428:      	add	x2, x24, #0x10
    c42c:      	mov	w8, #0x4                // =4
    c430:      	add	x9, sp, #0x98
    c434:      	add	x0, sp, #0x98
    c438:      	mov	w1, #0x8                // =8
    c43c:      	blr	x8
    c440:      	ldr	x8, [sp, #0x58]
    c444:      	ldr	x9, [sp, #0x98]
    c448:      	cmp	x8, x9
    c44c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    c450:      	add	x2, x24, #0x18
    c454:      	mov	w8, #0x4                // =4
    c458:      	mov	x0, x22
    c45c:      	mov	w1, #0x8                // =8
    c460:      	blr	x8
    c464:      	ldr	x24, [sp, #0x98]
    c468:      	ldr	x21, [sp, #0x48]
    c46c:      	add	x2, x24, #0x20
    c470:      	stp	x2, x24, [sp, #0x50]
    c474:      	ldr	x8, [sp, #0x30]
    c478:      	cmp	x21, x8
    c47c:      	b.ne	0xc48c <generic_fentry_path+0x1fdc>
    c480:      	ldr	x8, [sp, #0x38]
    c484:      	cmp	x2, x8
    c488:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    c48c:      	mov	w8, #0x4                // =4
    c490:      	add	x0, sp, #0x70
    c494:      	mov	w1, #0x8                // =8
    c498:      	blr	x8
    c49c:      	ldr	x8, [sp, #0x70]
    c4a0:      	cmp	x21, x8
    c4a4:      	b.eq	0xc594 <generic_fentry_path+0x20e4>
    c4a8:      	add	x23, x21, #0x18
    c4ac:      	mov	w8, #0x4                // =4
    c4b0:      	add	x9, sp, #0x98
    c4b4:      	add	x0, sp, #0x98
    c4b8:      	mov	w1, #0x8                // =8
    c4bc:      	mov	x2, x23
    c4c0:      	blr	x8
    c4c4:      	ldr	x8, [sp, #0x98]
    c4c8:      	cmp	x8, x21
    c4cc:      	b.eq	0xc594 <generic_fentry_path+0x20e4>
    c4d0:      	mov	w8, #0x4                // =4
    c4d4:      	add	x9, sp, #0x78
    c4d8:      	add	x0, sp, #0x78
    c4dc:      	mov	w1, #0x8                // =8
    c4e0:      	mov	x2, x23
    c4e4:      	blr	x8
    c4e8:      	add	x2, x21, #0x20
    c4ec:      	mov	w8, #0x4                // =4
    c4f0:      	mov	w9, #0x10               // =16
    c4f4:      	add	x10, sp, #0x80
    c4f8:      	add	x0, sp, #0x80
    c4fc:      	mov	w1, #0x10               // =16
    c500:      	blr	x8
    c504:      	ldr	w21, [sp, #0x84]
    c508:      	ldr	x8, [sp, #0x40]
    c50c:      	ldr	x10, [sp, #0x60]
    c510:      	sub	x12, x10, x8
    c514:      	ldr	w23, [sp, #0x68]
    c518:      	subs	w10, w21, w23
    c51c:      	ldr	x9, [sp, #0x88]
    c520:      	csel	w10, wzr, w10, lo
    c524:      	cmp	w23, w21
    c528:      	csel	w11, w23, w21, lo
    c52c:      	cinc	w13, w11, hi
    c530:      	sub	w14, w23, w13
    c534:      	subs	x12, x12, x13
    c538:      	str	w14, [sp, #0x68]
    c53c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    c540:      	cmp	x12, #0xfff
    c544:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    c548:      	cmp	w23, w21
    c54c:      	b.ls	0xc558 <generic_fentry_path+0x20a8>
    c550:      	mov	w13, #0x2f              // =47
    c554:      	strb	w13, [x8, x12]
    c558:      	add	x19, x8, x12
    c55c:      	cmp	w23, w21
    c560:      	add	x2, x9, x10
    c564:      	and	w1, w11, #0xff
    c568:      	mov	w8, #0x4                // =4
    c56c:      	cinc	x0, x19, hi
    c570:      	blr	x8
    c574:      	cmp	w23, w21
    c578:      	str	x19, [sp, #0x60]
    c57c:      	add	x19, sp, #0x70
    c580:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    c584:      	ldr	x21, [sp, #0x78]
    c588:      	ldp	x2, x24, [sp, #0x50]
    c58c:      	str	x21, [sp, #0x48]
    c590:      	b	0xc5e0 <generic_fentry_path+0x2130>
    c594:      	add	x2, x24, #0x10
    c598:      	mov	w8, #0x4                // =4
    c59c:      	add	x9, sp, #0x98
    c5a0:      	add	x0, sp, #0x98
    c5a4:      	mov	w1, #0x8                // =8
    c5a8:      	blr	x8
    c5ac:      	ldr	x8, [sp, #0x58]
    c5b0:      	ldr	x9, [sp, #0x98]
    c5b4:      	cmp	x8, x9
    c5b8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    c5bc:      	add	x2, x24, #0x18
    c5c0:      	mov	w8, #0x4                // =4
    c5c4:      	mov	x0, x22
    c5c8:      	mov	w1, #0x8                // =8
    c5cc:      	blr	x8
    c5d0:      	ldr	x24, [sp, #0x98]
    c5d4:      	ldr	x21, [sp, #0x48]
    c5d8:      	add	x2, x24, #0x20
    c5dc:      	stp	x2, x24, [sp, #0x50]
    c5e0:      	ldr	x8, [sp, #0x30]
    c5e4:      	cmp	x21, x8
    c5e8:      	b.ne	0xc5f8 <generic_fentry_path+0x2148>
    c5ec:      	ldr	x8, [sp, #0x38]
    c5f0:      	cmp	x2, x8
    c5f4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    c5f8:      	mov	w8, #0x4                // =4
    c5fc:      	add	x0, sp, #0x70
    c600:      	mov	w1, #0x8                // =8
    c604:      	blr	x8
    c608:      	ldr	x8, [sp, #0x70]
    c60c:      	cmp	x21, x8
    c610:      	b.eq	0xc700 <generic_fentry_path+0x2250>
    c614:      	add	x23, x21, #0x18
    c618:      	mov	w8, #0x4                // =4
    c61c:      	add	x9, sp, #0x98
    c620:      	add	x0, sp, #0x98
    c624:      	mov	w1, #0x8                // =8
    c628:      	mov	x2, x23
    c62c:      	blr	x8
    c630:      	ldr	x8, [sp, #0x98]
    c634:      	cmp	x8, x21
    c638:      	b.eq	0xc700 <generic_fentry_path+0x2250>
    c63c:      	mov	w8, #0x4                // =4
    c640:      	add	x9, sp, #0x78
    c644:      	add	x0, sp, #0x78
    c648:      	mov	w1, #0x8                // =8
    c64c:      	mov	x2, x23
    c650:      	blr	x8
    c654:      	add	x2, x21, #0x20
    c658:      	mov	w8, #0x4                // =4
    c65c:      	mov	w9, #0x10               // =16
    c660:      	add	x10, sp, #0x80
    c664:      	add	x0, sp, #0x80
    c668:      	mov	w1, #0x10               // =16
    c66c:      	blr	x8
    c670:      	ldr	w21, [sp, #0x84]
    c674:      	ldr	x8, [sp, #0x40]
    c678:      	ldr	x10, [sp, #0x60]
    c67c:      	sub	x12, x10, x8
    c680:      	ldr	w23, [sp, #0x68]
    c684:      	subs	w10, w21, w23
    c688:      	ldr	x9, [sp, #0x88]
    c68c:      	csel	w10, wzr, w10, lo
    c690:      	cmp	w23, w21
    c694:      	csel	w11, w23, w21, lo
    c698:      	cinc	w13, w11, hi
    c69c:      	sub	w14, w23, w13
    c6a0:      	subs	x12, x12, x13
    c6a4:      	str	w14, [sp, #0x68]
    c6a8:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    c6ac:      	cmp	x12, #0xfff
    c6b0:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    c6b4:      	cmp	w23, w21
    c6b8:      	b.ls	0xc6c4 <generic_fentry_path+0x2214>
    c6bc:      	mov	w13, #0x2f              // =47
    c6c0:      	strb	w13, [x8, x12]
    c6c4:      	add	x19, x8, x12
    c6c8:      	cmp	w23, w21
    c6cc:      	add	x2, x9, x10
    c6d0:      	and	w1, w11, #0xff
    c6d4:      	mov	w8, #0x4                // =4
    c6d8:      	cinc	x0, x19, hi
    c6dc:      	blr	x8
    c6e0:      	cmp	w23, w21
    c6e4:      	str	x19, [sp, #0x60]
    c6e8:      	add	x19, sp, #0x70
    c6ec:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    c6f0:      	ldr	x21, [sp, #0x78]
    c6f4:      	ldp	x2, x24, [sp, #0x50]
    c6f8:      	str	x21, [sp, #0x48]
    c6fc:      	b	0xc74c <generic_fentry_path+0x229c>
    c700:      	add	x2, x24, #0x10
    c704:      	mov	w8, #0x4                // =4
    c708:      	add	x9, sp, #0x98
    c70c:      	add	x0, sp, #0x98
    c710:      	mov	w1, #0x8                // =8
    c714:      	blr	x8
    c718:      	ldr	x8, [sp, #0x58]
    c71c:      	ldr	x9, [sp, #0x98]
    c720:      	cmp	x8, x9
    c724:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    c728:      	add	x2, x24, #0x18
    c72c:      	mov	w8, #0x4                // =4
    c730:      	mov	x0, x22
    c734:      	mov	w1, #0x8                // =8
    c738:      	blr	x8
    c73c:      	ldr	x24, [sp, #0x98]
    c740:      	ldr	x21, [sp, #0x48]
    c744:      	add	x2, x24, #0x20
    c748:      	stp	x2, x24, [sp, #0x50]
    c74c:      	ldr	x8, [sp, #0x30]
    c750:      	cmp	x21, x8
    c754:      	b.ne	0xc764 <generic_fentry_path+0x22b4>
    c758:      	ldr	x8, [sp, #0x38]
    c75c:      	cmp	x2, x8
    c760:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    c764:      	mov	w8, #0x4                // =4
    c768:      	add	x0, sp, #0x70
    c76c:      	mov	w1, #0x8                // =8
    c770:      	blr	x8
    c774:      	ldr	x8, [sp, #0x70]
    c778:      	cmp	x21, x8
    c77c:      	b.eq	0xc86c <generic_fentry_path+0x23bc>
    c780:      	add	x23, x21, #0x18
    c784:      	mov	w8, #0x4                // =4
    c788:      	add	x9, sp, #0x98
    c78c:      	add	x0, sp, #0x98
    c790:      	mov	w1, #0x8                // =8
    c794:      	mov	x2, x23
    c798:      	blr	x8
    c79c:      	ldr	x8, [sp, #0x98]
    c7a0:      	cmp	x8, x21
    c7a4:      	b.eq	0xc86c <generic_fentry_path+0x23bc>
    c7a8:      	mov	w8, #0x4                // =4
    c7ac:      	add	x9, sp, #0x78
    c7b0:      	add	x0, sp, #0x78
    c7b4:      	mov	w1, #0x8                // =8
    c7b8:      	mov	x2, x23
    c7bc:      	blr	x8
    c7c0:      	add	x2, x21, #0x20
    c7c4:      	mov	w8, #0x4                // =4
    c7c8:      	mov	w9, #0x10               // =16
    c7cc:      	add	x10, sp, #0x80
    c7d0:      	add	x0, sp, #0x80
    c7d4:      	mov	w1, #0x10               // =16
    c7d8:      	blr	x8
    c7dc:      	ldr	w21, [sp, #0x84]
    c7e0:      	ldr	x8, [sp, #0x40]
    c7e4:      	ldr	x10, [sp, #0x60]
    c7e8:      	sub	x12, x10, x8
    c7ec:      	ldr	w23, [sp, #0x68]
    c7f0:      	subs	w10, w21, w23
    c7f4:      	ldr	x9, [sp, #0x88]
    c7f8:      	csel	w10, wzr, w10, lo
    c7fc:      	cmp	w23, w21
    c800:      	csel	w11, w23, w21, lo
    c804:      	cinc	w13, w11, hi
    c808:      	sub	w14, w23, w13
    c80c:      	subs	x12, x12, x13
    c810:      	str	w14, [sp, #0x68]
    c814:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    c818:      	cmp	x12, #0xfff
    c81c:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    c820:      	cmp	w23, w21
    c824:      	b.ls	0xc830 <generic_fentry_path+0x2380>
    c828:      	mov	w13, #0x2f              // =47
    c82c:      	strb	w13, [x8, x12]
    c830:      	add	x19, x8, x12
    c834:      	cmp	w23, w21
    c838:      	add	x2, x9, x10
    c83c:      	and	w1, w11, #0xff
    c840:      	mov	w8, #0x4                // =4
    c844:      	cinc	x0, x19, hi
    c848:      	blr	x8
    c84c:      	cmp	w23, w21
    c850:      	str	x19, [sp, #0x60]
    c854:      	add	x19, sp, #0x70
    c858:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    c85c:      	ldr	x21, [sp, #0x78]
    c860:      	ldp	x2, x24, [sp, #0x50]
    c864:      	str	x21, [sp, #0x48]
    c868:      	b	0xc8b8 <generic_fentry_path+0x2408>
    c86c:      	add	x2, x24, #0x10
    c870:      	mov	w8, #0x4                // =4
    c874:      	add	x9, sp, #0x98
    c878:      	add	x0, sp, #0x98
    c87c:      	mov	w1, #0x8                // =8
    c880:      	blr	x8
    c884:      	ldr	x8, [sp, #0x58]
    c888:      	ldr	x9, [sp, #0x98]
    c88c:      	cmp	x8, x9
    c890:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    c894:      	add	x2, x24, #0x18
    c898:      	mov	w8, #0x4                // =4
    c89c:      	mov	x0, x22
    c8a0:      	mov	w1, #0x8                // =8
    c8a4:      	blr	x8
    c8a8:      	ldr	x24, [sp, #0x98]
    c8ac:      	ldr	x21, [sp, #0x48]
    c8b0:      	add	x2, x24, #0x20
    c8b4:      	stp	x2, x24, [sp, #0x50]
    c8b8:      	ldr	x8, [sp, #0x30]
    c8bc:      	cmp	x21, x8
    c8c0:      	b.ne	0xc8d0 <generic_fentry_path+0x2420>
    c8c4:      	ldr	x8, [sp, #0x38]
    c8c8:      	cmp	x2, x8
    c8cc:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    c8d0:      	mov	w8, #0x4                // =4
    c8d4:      	add	x0, sp, #0x70
    c8d8:      	mov	w1, #0x8                // =8
    c8dc:      	blr	x8
    c8e0:      	ldr	x8, [sp, #0x70]
    c8e4:      	cmp	x21, x8
    c8e8:      	b.eq	0xc9d8 <generic_fentry_path+0x2528>
    c8ec:      	add	x23, x21, #0x18
    c8f0:      	mov	w8, #0x4                // =4
    c8f4:      	add	x9, sp, #0x98
    c8f8:      	add	x0, sp, #0x98
    c8fc:      	mov	w1, #0x8                // =8
    c900:      	mov	x2, x23
    c904:      	blr	x8
    c908:      	ldr	x8, [sp, #0x98]
    c90c:      	cmp	x8, x21
    c910:      	b.eq	0xc9d8 <generic_fentry_path+0x2528>
    c914:      	mov	w8, #0x4                // =4
    c918:      	add	x9, sp, #0x78
    c91c:      	add	x0, sp, #0x78
    c920:      	mov	w1, #0x8                // =8
    c924:      	mov	x2, x23
    c928:      	blr	x8
    c92c:      	add	x2, x21, #0x20
    c930:      	mov	w8, #0x4                // =4
    c934:      	mov	w9, #0x10               // =16
    c938:      	add	x10, sp, #0x80
    c93c:      	add	x0, sp, #0x80
    c940:      	mov	w1, #0x10               // =16
    c944:      	blr	x8
    c948:      	ldr	w21, [sp, #0x84]
    c94c:      	ldr	x8, [sp, #0x40]
    c950:      	ldr	x10, [sp, #0x60]
    c954:      	sub	x12, x10, x8
    c958:      	ldr	w23, [sp, #0x68]
    c95c:      	subs	w10, w21, w23
    c960:      	ldr	x9, [sp, #0x88]
    c964:      	csel	w10, wzr, w10, lo
    c968:      	cmp	w23, w21
    c96c:      	csel	w11, w23, w21, lo
    c970:      	cinc	w13, w11, hi
    c974:      	sub	w14, w23, w13
    c978:      	subs	x12, x12, x13
    c97c:      	str	w14, [sp, #0x68]
    c980:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    c984:      	cmp	x12, #0xfff
    c988:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    c98c:      	cmp	w23, w21
    c990:      	b.ls	0xc99c <generic_fentry_path+0x24ec>
    c994:      	mov	w13, #0x2f              // =47
    c998:      	strb	w13, [x8, x12]
    c99c:      	add	x19, x8, x12
    c9a0:      	cmp	w23, w21
    c9a4:      	add	x2, x9, x10
    c9a8:      	and	w1, w11, #0xff
    c9ac:      	mov	w8, #0x4                // =4
    c9b0:      	cinc	x0, x19, hi
    c9b4:      	blr	x8
    c9b8:      	cmp	w23, w21
    c9bc:      	str	x19, [sp, #0x60]
    c9c0:      	add	x19, sp, #0x70
    c9c4:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    c9c8:      	ldr	x21, [sp, #0x78]
    c9cc:      	ldp	x2, x24, [sp, #0x50]
    c9d0:      	str	x21, [sp, #0x48]
    c9d4:      	b	0xca24 <generic_fentry_path+0x2574>
    c9d8:      	add	x2, x24, #0x10
    c9dc:      	mov	w8, #0x4                // =4
    c9e0:      	add	x9, sp, #0x98
    c9e4:      	add	x0, sp, #0x98
    c9e8:      	mov	w1, #0x8                // =8
    c9ec:      	blr	x8
    c9f0:      	ldr	x8, [sp, #0x58]
    c9f4:      	ldr	x9, [sp, #0x98]
    c9f8:      	cmp	x8, x9
    c9fc:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    ca00:      	add	x2, x24, #0x18
    ca04:      	mov	w8, #0x4                // =4
    ca08:      	mov	x0, x22
    ca0c:      	mov	w1, #0x8                // =8
    ca10:      	blr	x8
    ca14:      	ldr	x24, [sp, #0x98]
    ca18:      	ldr	x21, [sp, #0x48]
    ca1c:      	add	x2, x24, #0x20
    ca20:      	stp	x2, x24, [sp, #0x50]
    ca24:      	ldr	x8, [sp, #0x30]
    ca28:      	cmp	x21, x8
    ca2c:      	b.ne	0xca3c <generic_fentry_path+0x258c>
    ca30:      	ldr	x8, [sp, #0x38]
    ca34:      	cmp	x2, x8
    ca38:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    ca3c:      	mov	w8, #0x4                // =4
    ca40:      	add	x0, sp, #0x70
    ca44:      	mov	w1, #0x8                // =8
    ca48:      	blr	x8
    ca4c:      	ldr	x8, [sp, #0x70]
    ca50:      	cmp	x21, x8
    ca54:      	b.eq	0xcb44 <generic_fentry_path+0x2694>
    ca58:      	add	x23, x21, #0x18
    ca5c:      	mov	w8, #0x4                // =4
    ca60:      	add	x9, sp, #0x98
    ca64:      	add	x0, sp, #0x98
    ca68:      	mov	w1, #0x8                // =8
    ca6c:      	mov	x2, x23
    ca70:      	blr	x8
    ca74:      	ldr	x8, [sp, #0x98]
    ca78:      	cmp	x8, x21
    ca7c:      	b.eq	0xcb44 <generic_fentry_path+0x2694>
    ca80:      	mov	w8, #0x4                // =4
    ca84:      	add	x9, sp, #0x78
    ca88:      	add	x0, sp, #0x78
    ca8c:      	mov	w1, #0x8                // =8
    ca90:      	mov	x2, x23
    ca94:      	blr	x8
    ca98:      	add	x2, x21, #0x20
    ca9c:      	mov	w8, #0x4                // =4
    caa0:      	mov	w9, #0x10               // =16
    caa4:      	add	x10, sp, #0x80
    caa8:      	add	x0, sp, #0x80
    caac:      	mov	w1, #0x10               // =16
    cab0:      	blr	x8
    cab4:      	ldr	w21, [sp, #0x84]
    cab8:      	ldr	x8, [sp, #0x40]
    cabc:      	ldr	x10, [sp, #0x60]
    cac0:      	sub	x12, x10, x8
    cac4:      	ldr	w23, [sp, #0x68]
    cac8:      	subs	w10, w21, w23
    cacc:      	ldr	x9, [sp, #0x88]
    cad0:      	csel	w10, wzr, w10, lo
    cad4:      	cmp	w23, w21
    cad8:      	csel	w11, w23, w21, lo
    cadc:      	cinc	w13, w11, hi
    cae0:      	sub	w14, w23, w13
    cae4:      	subs	x12, x12, x13
    cae8:      	str	w14, [sp, #0x68]
    caec:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    caf0:      	cmp	x12, #0xfff
    caf4:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    caf8:      	cmp	w23, w21
    cafc:      	b.ls	0xcb08 <generic_fentry_path+0x2658>
    cb00:      	mov	w13, #0x2f              // =47
    cb04:      	strb	w13, [x8, x12]
    cb08:      	add	x19, x8, x12
    cb0c:      	cmp	w23, w21
    cb10:      	add	x2, x9, x10
    cb14:      	and	w1, w11, #0xff
    cb18:      	mov	w8, #0x4                // =4
    cb1c:      	cinc	x0, x19, hi
    cb20:      	blr	x8
    cb24:      	cmp	w23, w21
    cb28:      	str	x19, [sp, #0x60]
    cb2c:      	add	x19, sp, #0x70
    cb30:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    cb34:      	ldr	x21, [sp, #0x78]
    cb38:      	ldp	x2, x24, [sp, #0x50]
    cb3c:      	str	x21, [sp, #0x48]
    cb40:      	b	0xcb90 <generic_fentry_path+0x26e0>
    cb44:      	add	x2, x24, #0x10
    cb48:      	mov	w8, #0x4                // =4
    cb4c:      	add	x9, sp, #0x98
    cb50:      	add	x0, sp, #0x98
    cb54:      	mov	w1, #0x8                // =8
    cb58:      	blr	x8
    cb5c:      	ldr	x8, [sp, #0x58]
    cb60:      	ldr	x9, [sp, #0x98]
    cb64:      	cmp	x8, x9
    cb68:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    cb6c:      	add	x2, x24, #0x18
    cb70:      	mov	w8, #0x4                // =4
    cb74:      	mov	x0, x22
    cb78:      	mov	w1, #0x8                // =8
    cb7c:      	blr	x8
    cb80:      	ldr	x24, [sp, #0x98]
    cb84:      	ldr	x21, [sp, #0x48]
    cb88:      	add	x2, x24, #0x20
    cb8c:      	stp	x2, x24, [sp, #0x50]
    cb90:      	ldr	x8, [sp, #0x30]
    cb94:      	cmp	x21, x8
    cb98:      	b.ne	0xcba8 <generic_fentry_path+0x26f8>
    cb9c:      	ldr	x8, [sp, #0x38]
    cba0:      	cmp	x2, x8
    cba4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    cba8:      	mov	w8, #0x4                // =4
    cbac:      	add	x0, sp, #0x70
    cbb0:      	mov	w1, #0x8                // =8
    cbb4:      	blr	x8
    cbb8:      	ldr	x8, [sp, #0x70]
    cbbc:      	cmp	x21, x8
    cbc0:      	b.eq	0xccb0 <generic_fentry_path+0x2800>
    cbc4:      	add	x23, x21, #0x18
    cbc8:      	mov	w8, #0x4                // =4
    cbcc:      	add	x9, sp, #0x98
    cbd0:      	add	x0, sp, #0x98
    cbd4:      	mov	w1, #0x8                // =8
    cbd8:      	mov	x2, x23
    cbdc:      	blr	x8
    cbe0:      	ldr	x8, [sp, #0x98]
    cbe4:      	cmp	x8, x21
    cbe8:      	b.eq	0xccb0 <generic_fentry_path+0x2800>
    cbec:      	mov	w8, #0x4                // =4
    cbf0:      	add	x9, sp, #0x78
    cbf4:      	add	x0, sp, #0x78
    cbf8:      	mov	w1, #0x8                // =8
    cbfc:      	mov	x2, x23
    cc00:      	blr	x8
    cc04:      	add	x2, x21, #0x20
    cc08:      	mov	w8, #0x4                // =4
    cc0c:      	mov	w9, #0x10               // =16
    cc10:      	add	x10, sp, #0x80
    cc14:      	add	x0, sp, #0x80
    cc18:      	mov	w1, #0x10               // =16
    cc1c:      	blr	x8
    cc20:      	ldr	w21, [sp, #0x84]
    cc24:      	ldr	x8, [sp, #0x40]
    cc28:      	ldr	x10, [sp, #0x60]
    cc2c:      	sub	x12, x10, x8
    cc30:      	ldr	w23, [sp, #0x68]
    cc34:      	subs	w10, w21, w23
    cc38:      	ldr	x9, [sp, #0x88]
    cc3c:      	csel	w10, wzr, w10, lo
    cc40:      	cmp	w23, w21
    cc44:      	csel	w11, w23, w21, lo
    cc48:      	cinc	w13, w11, hi
    cc4c:      	sub	w14, w23, w13
    cc50:      	subs	x12, x12, x13
    cc54:      	str	w14, [sp, #0x68]
    cc58:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    cc5c:      	cmp	x12, #0xfff
    cc60:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    cc64:      	cmp	w23, w21
    cc68:      	b.ls	0xcc74 <generic_fentry_path+0x27c4>
    cc6c:      	mov	w13, #0x2f              // =47
    cc70:      	strb	w13, [x8, x12]
    cc74:      	add	x19, x8, x12
    cc78:      	cmp	w23, w21
    cc7c:      	add	x2, x9, x10
    cc80:      	and	w1, w11, #0xff
    cc84:      	mov	w8, #0x4                // =4
    cc88:      	cinc	x0, x19, hi
    cc8c:      	blr	x8
    cc90:      	cmp	w23, w21
    cc94:      	str	x19, [sp, #0x60]
    cc98:      	add	x19, sp, #0x70
    cc9c:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    cca0:      	ldr	x21, [sp, #0x78]
    cca4:      	ldp	x2, x24, [sp, #0x50]
    cca8:      	str	x21, [sp, #0x48]
    ccac:      	b	0xccfc <generic_fentry_path+0x284c>
    ccb0:      	add	x2, x24, #0x10
    ccb4:      	mov	w8, #0x4                // =4
    ccb8:      	add	x9, sp, #0x98
    ccbc:      	add	x0, sp, #0x98
    ccc0:      	mov	w1, #0x8                // =8
    ccc4:      	blr	x8
    ccc8:      	ldr	x8, [sp, #0x58]
    cccc:      	ldr	x9, [sp, #0x98]
    ccd0:      	cmp	x8, x9
    ccd4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    ccd8:      	add	x2, x24, #0x18
    ccdc:      	mov	w8, #0x4                // =4
    cce0:      	mov	x0, x22
    cce4:      	mov	w1, #0x8                // =8
    cce8:      	blr	x8
    ccec:      	ldr	x24, [sp, #0x98]
    ccf0:      	ldr	x21, [sp, #0x48]
    ccf4:      	add	x2, x24, #0x20
    ccf8:      	stp	x2, x24, [sp, #0x50]
    ccfc:      	ldr	x8, [sp, #0x30]
    cd00:      	cmp	x21, x8
    cd04:      	b.ne	0xcd14 <generic_fentry_path+0x2864>
    cd08:      	ldr	x8, [sp, #0x38]
    cd0c:      	cmp	x2, x8
    cd10:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    cd14:      	mov	w8, #0x4                // =4
    cd18:      	add	x0, sp, #0x70
    cd1c:      	mov	w1, #0x8                // =8
    cd20:      	blr	x8
    cd24:      	ldr	x8, [sp, #0x70]
    cd28:      	cmp	x21, x8
    cd2c:      	b.eq	0xce1c <generic_fentry_path+0x296c>
    cd30:      	add	x23, x21, #0x18
    cd34:      	mov	w8, #0x4                // =4
    cd38:      	add	x9, sp, #0x98
    cd3c:      	add	x0, sp, #0x98
    cd40:      	mov	w1, #0x8                // =8
    cd44:      	mov	x2, x23
    cd48:      	blr	x8
    cd4c:      	ldr	x8, [sp, #0x98]
    cd50:      	cmp	x8, x21
    cd54:      	b.eq	0xce1c <generic_fentry_path+0x296c>
    cd58:      	mov	w8, #0x4                // =4
    cd5c:      	add	x9, sp, #0x78
    cd60:      	add	x0, sp, #0x78
    cd64:      	mov	w1, #0x8                // =8
    cd68:      	mov	x2, x23
    cd6c:      	blr	x8
    cd70:      	add	x2, x21, #0x20
    cd74:      	mov	w8, #0x4                // =4
    cd78:      	mov	w9, #0x10               // =16
    cd7c:      	add	x10, sp, #0x80
    cd80:      	add	x0, sp, #0x80
    cd84:      	mov	w1, #0x10               // =16
    cd88:      	blr	x8
    cd8c:      	ldr	w21, [sp, #0x84]
    cd90:      	ldr	x8, [sp, #0x40]
    cd94:      	ldr	x10, [sp, #0x60]
    cd98:      	sub	x12, x10, x8
    cd9c:      	ldr	w23, [sp, #0x68]
    cda0:      	subs	w10, w21, w23
    cda4:      	ldr	x9, [sp, #0x88]
    cda8:      	csel	w10, wzr, w10, lo
    cdac:      	cmp	w23, w21
    cdb0:      	csel	w11, w23, w21, lo
    cdb4:      	cinc	w13, w11, hi
    cdb8:      	sub	w14, w23, w13
    cdbc:      	subs	x12, x12, x13
    cdc0:      	str	w14, [sp, #0x68]
    cdc4:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    cdc8:      	cmp	x12, #0xfff
    cdcc:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    cdd0:      	cmp	w23, w21
    cdd4:      	b.ls	0xcde0 <generic_fentry_path+0x2930>
    cdd8:      	mov	w13, #0x2f              // =47
    cddc:      	strb	w13, [x8, x12]
    cde0:      	add	x19, x8, x12
    cde4:      	cmp	w23, w21
    cde8:      	add	x2, x9, x10
    cdec:      	and	w1, w11, #0xff
    cdf0:      	mov	w8, #0x4                // =4
    cdf4:      	cinc	x0, x19, hi
    cdf8:      	blr	x8
    cdfc:      	cmp	w23, w21
    ce00:      	str	x19, [sp, #0x60]
    ce04:      	add	x19, sp, #0x70
    ce08:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    ce0c:      	ldr	x21, [sp, #0x78]
    ce10:      	ldp	x2, x24, [sp, #0x50]
    ce14:      	str	x21, [sp, #0x48]
    ce18:      	b	0xce68 <generic_fentry_path+0x29b8>
    ce1c:      	add	x2, x24, #0x10
    ce20:      	mov	w8, #0x4                // =4
    ce24:      	add	x9, sp, #0x98
    ce28:      	add	x0, sp, #0x98
    ce2c:      	mov	w1, #0x8                // =8
    ce30:      	blr	x8
    ce34:      	ldr	x8, [sp, #0x58]
    ce38:      	ldr	x9, [sp, #0x98]
    ce3c:      	cmp	x8, x9
    ce40:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    ce44:      	add	x2, x24, #0x18
    ce48:      	mov	w8, #0x4                // =4
    ce4c:      	mov	x0, x22
    ce50:      	mov	w1, #0x8                // =8
    ce54:      	blr	x8
    ce58:      	ldr	x24, [sp, #0x98]
    ce5c:      	ldr	x21, [sp, #0x48]
    ce60:      	add	x2, x24, #0x20
    ce64:      	stp	x2, x24, [sp, #0x50]
    ce68:      	ldr	x8, [sp, #0x30]
    ce6c:      	cmp	x21, x8
    ce70:      	b.ne	0xce80 <generic_fentry_path+0x29d0>
    ce74:      	ldr	x8, [sp, #0x38]
    ce78:      	cmp	x2, x8
    ce7c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    ce80:      	mov	w8, #0x4                // =4
    ce84:      	add	x0, sp, #0x70
    ce88:      	mov	w1, #0x8                // =8
    ce8c:      	blr	x8
    ce90:      	ldr	x8, [sp, #0x70]
    ce94:      	cmp	x21, x8
    ce98:      	b.eq	0xcf88 <generic_fentry_path+0x2ad8>
    ce9c:      	add	x23, x21, #0x18
    cea0:      	mov	w8, #0x4                // =4
    cea4:      	add	x9, sp, #0x98
    cea8:      	add	x0, sp, #0x98
    ceac:      	mov	w1, #0x8                // =8
    ceb0:      	mov	x2, x23
    ceb4:      	blr	x8
    ceb8:      	ldr	x8, [sp, #0x98]
    cebc:      	cmp	x8, x21
    cec0:      	b.eq	0xcf88 <generic_fentry_path+0x2ad8>
    cec4:      	mov	w8, #0x4                // =4
    cec8:      	add	x9, sp, #0x78
    cecc:      	add	x0, sp, #0x78
    ced0:      	mov	w1, #0x8                // =8
    ced4:      	mov	x2, x23
    ced8:      	blr	x8
    cedc:      	add	x2, x21, #0x20
    cee0:      	mov	w8, #0x4                // =4
    cee4:      	mov	w9, #0x10               // =16
    cee8:      	add	x10, sp, #0x80
    ceec:      	add	x0, sp, #0x80
    cef0:      	mov	w1, #0x10               // =16
    cef4:      	blr	x8
    cef8:      	ldr	w21, [sp, #0x84]
    cefc:      	ldr	x8, [sp, #0x40]
    cf00:      	ldr	x10, [sp, #0x60]
    cf04:      	sub	x12, x10, x8
    cf08:      	ldr	w23, [sp, #0x68]
    cf0c:      	subs	w10, w21, w23
    cf10:      	ldr	x9, [sp, #0x88]
    cf14:      	csel	w10, wzr, w10, lo
    cf18:      	cmp	w23, w21
    cf1c:      	csel	w11, w23, w21, lo
    cf20:      	cinc	w13, w11, hi
    cf24:      	sub	w14, w23, w13
    cf28:      	subs	x12, x12, x13
    cf2c:      	str	w14, [sp, #0x68]
    cf30:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    cf34:      	cmp	x12, #0xfff
    cf38:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    cf3c:      	cmp	w23, w21
    cf40:      	b.ls	0xcf4c <generic_fentry_path+0x2a9c>
    cf44:      	mov	w13, #0x2f              // =47
    cf48:      	strb	w13, [x8, x12]
    cf4c:      	add	x19, x8, x12
    cf50:      	cmp	w23, w21
    cf54:      	add	x2, x9, x10
    cf58:      	and	w1, w11, #0xff
    cf5c:      	mov	w8, #0x4                // =4
    cf60:      	cinc	x0, x19, hi
    cf64:      	blr	x8
    cf68:      	cmp	w23, w21
    cf6c:      	str	x19, [sp, #0x60]
    cf70:      	add	x19, sp, #0x70
    cf74:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    cf78:      	ldr	x21, [sp, #0x78]
    cf7c:      	ldp	x2, x24, [sp, #0x50]
    cf80:      	str	x21, [sp, #0x48]
    cf84:      	b	0xcfd4 <generic_fentry_path+0x2b24>
    cf88:      	add	x2, x24, #0x10
    cf8c:      	mov	w8, #0x4                // =4
    cf90:      	add	x9, sp, #0x98
    cf94:      	add	x0, sp, #0x98
    cf98:      	mov	w1, #0x8                // =8
    cf9c:      	blr	x8
    cfa0:      	ldr	x8, [sp, #0x58]
    cfa4:      	ldr	x9, [sp, #0x98]
    cfa8:      	cmp	x8, x9
    cfac:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    cfb0:      	add	x2, x24, #0x18
    cfb4:      	mov	w8, #0x4                // =4
    cfb8:      	mov	x0, x22
    cfbc:      	mov	w1, #0x8                // =8
    cfc0:      	blr	x8
    cfc4:      	ldr	x24, [sp, #0x98]
    cfc8:      	ldr	x21, [sp, #0x48]
    cfcc:      	add	x2, x24, #0x20
    cfd0:      	stp	x2, x24, [sp, #0x50]
    cfd4:      	ldr	x8, [sp, #0x30]
    cfd8:      	cmp	x21, x8
    cfdc:      	b.ne	0xcfec <generic_fentry_path+0x2b3c>
    cfe0:      	ldr	x8, [sp, #0x38]
    cfe4:      	cmp	x2, x8
    cfe8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    cfec:      	mov	w8, #0x4                // =4
    cff0:      	add	x0, sp, #0x70
    cff4:      	mov	w1, #0x8                // =8
    cff8:      	blr	x8
    cffc:      	ldr	x8, [sp, #0x70]
    d000:      	cmp	x21, x8
    d004:      	b.eq	0xd0f4 <generic_fentry_path+0x2c44>
    d008:      	add	x23, x21, #0x18
    d00c:      	mov	w8, #0x4                // =4
    d010:      	add	x9, sp, #0x98
    d014:      	add	x0, sp, #0x98
    d018:      	mov	w1, #0x8                // =8
    d01c:      	mov	x2, x23
    d020:      	blr	x8
    d024:      	ldr	x8, [sp, #0x98]
    d028:      	cmp	x8, x21
    d02c:      	b.eq	0xd0f4 <generic_fentry_path+0x2c44>
    d030:      	mov	w8, #0x4                // =4
    d034:      	add	x9, sp, #0x78
    d038:      	add	x0, sp, #0x78
    d03c:      	mov	w1, #0x8                // =8
    d040:      	mov	x2, x23
    d044:      	blr	x8
    d048:      	add	x2, x21, #0x20
    d04c:      	mov	w8, #0x4                // =4
    d050:      	mov	w9, #0x10               // =16
    d054:      	add	x10, sp, #0x80
    d058:      	add	x0, sp, #0x80
    d05c:      	mov	w1, #0x10               // =16
    d060:      	blr	x8
    d064:      	ldr	w21, [sp, #0x84]
    d068:      	ldr	x8, [sp, #0x40]
    d06c:      	ldr	x10, [sp, #0x60]
    d070:      	sub	x12, x10, x8
    d074:      	ldr	w23, [sp, #0x68]
    d078:      	subs	w10, w21, w23
    d07c:      	ldr	x9, [sp, #0x88]
    d080:      	csel	w10, wzr, w10, lo
    d084:      	cmp	w23, w21
    d088:      	csel	w11, w23, w21, lo
    d08c:      	cinc	w13, w11, hi
    d090:      	sub	w14, w23, w13
    d094:      	subs	x12, x12, x13
    d098:      	str	w14, [sp, #0x68]
    d09c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    d0a0:      	cmp	x12, #0xfff
    d0a4:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    d0a8:      	cmp	w23, w21
    d0ac:      	b.ls	0xd0b8 <generic_fentry_path+0x2c08>
    d0b0:      	mov	w13, #0x2f              // =47
    d0b4:      	strb	w13, [x8, x12]
    d0b8:      	add	x19, x8, x12
    d0bc:      	cmp	w23, w21
    d0c0:      	add	x2, x9, x10
    d0c4:      	and	w1, w11, #0xff
    d0c8:      	mov	w8, #0x4                // =4
    d0cc:      	cinc	x0, x19, hi
    d0d0:      	blr	x8
    d0d4:      	cmp	w23, w21
    d0d8:      	str	x19, [sp, #0x60]
    d0dc:      	add	x19, sp, #0x70
    d0e0:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    d0e4:      	ldr	x21, [sp, #0x78]
    d0e8:      	ldp	x2, x24, [sp, #0x50]
    d0ec:      	str	x21, [sp, #0x48]
    d0f0:      	b	0xd140 <generic_fentry_path+0x2c90>
    d0f4:      	add	x2, x24, #0x10
    d0f8:      	mov	w8, #0x4                // =4
    d0fc:      	add	x9, sp, #0x98
    d100:      	add	x0, sp, #0x98
    d104:      	mov	w1, #0x8                // =8
    d108:      	blr	x8
    d10c:      	ldr	x8, [sp, #0x58]
    d110:      	ldr	x9, [sp, #0x98]
    d114:      	cmp	x8, x9
    d118:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    d11c:      	add	x2, x24, #0x18
    d120:      	mov	w8, #0x4                // =4
    d124:      	mov	x0, x22
    d128:      	mov	w1, #0x8                // =8
    d12c:      	blr	x8
    d130:      	ldr	x24, [sp, #0x98]
    d134:      	ldr	x21, [sp, #0x48]
    d138:      	add	x2, x24, #0x20
    d13c:      	stp	x2, x24, [sp, #0x50]
    d140:      	ldr	x8, [sp, #0x30]
    d144:      	cmp	x21, x8
    d148:      	b.ne	0xd158 <generic_fentry_path+0x2ca8>
    d14c:      	ldr	x8, [sp, #0x38]
    d150:      	cmp	x2, x8
    d154:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    d158:      	mov	w8, #0x4                // =4
    d15c:      	add	x0, sp, #0x70
    d160:      	mov	w1, #0x8                // =8
    d164:      	blr	x8
    d168:      	ldr	x8, [sp, #0x70]
    d16c:      	cmp	x21, x8
    d170:      	b.eq	0xd260 <generic_fentry_path+0x2db0>
    d174:      	add	x23, x21, #0x18
    d178:      	mov	w8, #0x4                // =4
    d17c:      	add	x9, sp, #0x98
    d180:      	add	x0, sp, #0x98
    d184:      	mov	w1, #0x8                // =8
    d188:      	mov	x2, x23
    d18c:      	blr	x8
    d190:      	ldr	x8, [sp, #0x98]
    d194:      	cmp	x8, x21
    d198:      	b.eq	0xd260 <generic_fentry_path+0x2db0>
    d19c:      	mov	w8, #0x4                // =4
    d1a0:      	add	x9, sp, #0x78
    d1a4:      	add	x0, sp, #0x78
    d1a8:      	mov	w1, #0x8                // =8
    d1ac:      	mov	x2, x23
    d1b0:      	blr	x8
    d1b4:      	add	x2, x21, #0x20
    d1b8:      	mov	w8, #0x4                // =4
    d1bc:      	mov	w9, #0x10               // =16
    d1c0:      	add	x10, sp, #0x80
    d1c4:      	add	x0, sp, #0x80
    d1c8:      	mov	w1, #0x10               // =16
    d1cc:      	blr	x8
    d1d0:      	ldr	w21, [sp, #0x84]
    d1d4:      	ldr	x8, [sp, #0x40]
    d1d8:      	ldr	x10, [sp, #0x60]
    d1dc:      	sub	x12, x10, x8
    d1e0:      	ldr	w23, [sp, #0x68]
    d1e4:      	subs	w10, w21, w23
    d1e8:      	ldr	x9, [sp, #0x88]
    d1ec:      	csel	w10, wzr, w10, lo
    d1f0:      	cmp	w23, w21
    d1f4:      	csel	w11, w23, w21, lo
    d1f8:      	cinc	w13, w11, hi
    d1fc:      	sub	w14, w23, w13
    d200:      	subs	x12, x12, x13
    d204:      	str	w14, [sp, #0x68]
    d208:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    d20c:      	cmp	x12, #0xfff
    d210:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    d214:      	cmp	w23, w21
    d218:      	b.ls	0xd224 <generic_fentry_path+0x2d74>
    d21c:      	mov	w13, #0x2f              // =47
    d220:      	strb	w13, [x8, x12]
    d224:      	add	x19, x8, x12
    d228:      	cmp	w23, w21
    d22c:      	add	x2, x9, x10
    d230:      	and	w1, w11, #0xff
    d234:      	mov	w8, #0x4                // =4
    d238:      	cinc	x0, x19, hi
    d23c:      	blr	x8
    d240:      	cmp	w23, w21
    d244:      	str	x19, [sp, #0x60]
    d248:      	add	x19, sp, #0x70
    d24c:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    d250:      	ldr	x21, [sp, #0x78]
    d254:      	ldp	x2, x24, [sp, #0x50]
    d258:      	str	x21, [sp, #0x48]
    d25c:      	b	0xd2ac <generic_fentry_path+0x2dfc>
    d260:      	add	x2, x24, #0x10
    d264:      	mov	w8, #0x4                // =4
    d268:      	add	x9, sp, #0x98
    d26c:      	add	x0, sp, #0x98
    d270:      	mov	w1, #0x8                // =8
    d274:      	blr	x8
    d278:      	ldr	x8, [sp, #0x58]
    d27c:      	ldr	x9, [sp, #0x98]
    d280:      	cmp	x8, x9
    d284:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    d288:      	add	x2, x24, #0x18
    d28c:      	mov	w8, #0x4                // =4
    d290:      	mov	x0, x22
    d294:      	mov	w1, #0x8                // =8
    d298:      	blr	x8
    d29c:      	ldr	x24, [sp, #0x98]
    d2a0:      	ldr	x21, [sp, #0x48]
    d2a4:      	add	x2, x24, #0x20
    d2a8:      	stp	x2, x24, [sp, #0x50]
    d2ac:      	ldr	x8, [sp, #0x30]
    d2b0:      	cmp	x21, x8
    d2b4:      	b.ne	0xd2c4 <generic_fentry_path+0x2e14>
    d2b8:      	ldr	x8, [sp, #0x38]
    d2bc:      	cmp	x2, x8
    d2c0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    d2c4:      	mov	w8, #0x4                // =4
    d2c8:      	add	x0, sp, #0x70
    d2cc:      	mov	w1, #0x8                // =8
    d2d0:      	blr	x8
    d2d4:      	ldr	x8, [sp, #0x70]
    d2d8:      	cmp	x21, x8
    d2dc:      	b.eq	0xd3cc <generic_fentry_path+0x2f1c>
    d2e0:      	add	x23, x21, #0x18
    d2e4:      	mov	w8, #0x4                // =4
    d2e8:      	add	x9, sp, #0x98
    d2ec:      	add	x0, sp, #0x98
    d2f0:      	mov	w1, #0x8                // =8
    d2f4:      	mov	x2, x23
    d2f8:      	blr	x8
    d2fc:      	ldr	x8, [sp, #0x98]
    d300:      	cmp	x8, x21
    d304:      	b.eq	0xd3cc <generic_fentry_path+0x2f1c>
    d308:      	mov	w8, #0x4                // =4
    d30c:      	add	x9, sp, #0x78
    d310:      	add	x0, sp, #0x78
    d314:      	mov	w1, #0x8                // =8
    d318:      	mov	x2, x23
    d31c:      	blr	x8
    d320:      	add	x2, x21, #0x20
    d324:      	mov	w8, #0x4                // =4
    d328:      	mov	w9, #0x10               // =16
    d32c:      	add	x10, sp, #0x80
    d330:      	add	x0, sp, #0x80
    d334:      	mov	w1, #0x10               // =16
    d338:      	blr	x8
    d33c:      	ldr	w21, [sp, #0x84]
    d340:      	ldr	x8, [sp, #0x40]
    d344:      	ldr	x10, [sp, #0x60]
    d348:      	sub	x12, x10, x8
    d34c:      	ldr	w23, [sp, #0x68]
    d350:      	subs	w10, w21, w23
    d354:      	ldr	x9, [sp, #0x88]
    d358:      	csel	w10, wzr, w10, lo
    d35c:      	cmp	w23, w21
    d360:      	csel	w11, w23, w21, lo
    d364:      	cinc	w13, w11, hi
    d368:      	sub	w14, w23, w13
    d36c:      	subs	x12, x12, x13
    d370:      	str	w14, [sp, #0x68]
    d374:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    d378:      	cmp	x12, #0xfff
    d37c:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    d380:      	cmp	w23, w21
    d384:      	b.ls	0xd390 <generic_fentry_path+0x2ee0>
    d388:      	mov	w13, #0x2f              // =47
    d38c:      	strb	w13, [x8, x12]
    d390:      	add	x19, x8, x12
    d394:      	cmp	w23, w21
    d398:      	add	x2, x9, x10
    d39c:      	and	w1, w11, #0xff
    d3a0:      	mov	w8, #0x4                // =4
    d3a4:      	cinc	x0, x19, hi
    d3a8:      	blr	x8
    d3ac:      	cmp	w23, w21
    d3b0:      	str	x19, [sp, #0x60]
    d3b4:      	add	x19, sp, #0x70
    d3b8:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    d3bc:      	ldr	x21, [sp, #0x78]
    d3c0:      	ldp	x2, x24, [sp, #0x50]
    d3c4:      	str	x21, [sp, #0x48]
    d3c8:      	b	0xd418 <generic_fentry_path+0x2f68>
    d3cc:      	add	x2, x24, #0x10
    d3d0:      	mov	w8, #0x4                // =4
    d3d4:      	add	x9, sp, #0x98
    d3d8:      	add	x0, sp, #0x98
    d3dc:      	mov	w1, #0x8                // =8
    d3e0:      	blr	x8
    d3e4:      	ldr	x8, [sp, #0x58]
    d3e8:      	ldr	x9, [sp, #0x98]
    d3ec:      	cmp	x8, x9
    d3f0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    d3f4:      	add	x2, x24, #0x18
    d3f8:      	mov	w8, #0x4                // =4
    d3fc:      	mov	x0, x22
    d400:      	mov	w1, #0x8                // =8
    d404:      	blr	x8
    d408:      	ldr	x24, [sp, #0x98]
    d40c:      	ldr	x21, [sp, #0x48]
    d410:      	add	x2, x24, #0x20
    d414:      	stp	x2, x24, [sp, #0x50]
    d418:      	ldr	x8, [sp, #0x30]
    d41c:      	cmp	x21, x8
    d420:      	b.ne	0xd430 <generic_fentry_path+0x2f80>
    d424:      	ldr	x8, [sp, #0x38]
    d428:      	cmp	x2, x8
    d42c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    d430:      	mov	w8, #0x4                // =4
    d434:      	add	x0, sp, #0x70
    d438:      	mov	w1, #0x8                // =8
    d43c:      	blr	x8
    d440:      	ldr	x8, [sp, #0x70]
    d444:      	cmp	x21, x8
    d448:      	b.eq	0xd538 <generic_fentry_path+0x3088>
    d44c:      	add	x23, x21, #0x18
    d450:      	mov	w8, #0x4                // =4
    d454:      	add	x9, sp, #0x98
    d458:      	add	x0, sp, #0x98
    d45c:      	mov	w1, #0x8                // =8
    d460:      	mov	x2, x23
    d464:      	blr	x8
    d468:      	ldr	x8, [sp, #0x98]
    d46c:      	cmp	x8, x21
    d470:      	b.eq	0xd538 <generic_fentry_path+0x3088>
    d474:      	mov	w8, #0x4                // =4
    d478:      	add	x9, sp, #0x78
    d47c:      	add	x0, sp, #0x78
    d480:      	mov	w1, #0x8                // =8
    d484:      	mov	x2, x23
    d488:      	blr	x8
    d48c:      	add	x2, x21, #0x20
    d490:      	mov	w8, #0x4                // =4
    d494:      	mov	w9, #0x10               // =16
    d498:      	add	x10, sp, #0x80
    d49c:      	add	x0, sp, #0x80
    d4a0:      	mov	w1, #0x10               // =16
    d4a4:      	blr	x8
    d4a8:      	ldr	w21, [sp, #0x84]
    d4ac:      	ldr	x8, [sp, #0x40]
    d4b0:      	ldr	x10, [sp, #0x60]
    d4b4:      	sub	x12, x10, x8
    d4b8:      	ldr	w23, [sp, #0x68]
    d4bc:      	subs	w10, w21, w23
    d4c0:      	ldr	x9, [sp, #0x88]
    d4c4:      	csel	w10, wzr, w10, lo
    d4c8:      	cmp	w23, w21
    d4cc:      	csel	w11, w23, w21, lo
    d4d0:      	cinc	w13, w11, hi
    d4d4:      	sub	w14, w23, w13
    d4d8:      	subs	x12, x12, x13
    d4dc:      	str	w14, [sp, #0x68]
    d4e0:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    d4e4:      	cmp	x12, #0xfff
    d4e8:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    d4ec:      	cmp	w23, w21
    d4f0:      	b.ls	0xd4fc <generic_fentry_path+0x304c>
    d4f4:      	mov	w13, #0x2f              // =47
    d4f8:      	strb	w13, [x8, x12]
    d4fc:      	add	x19, x8, x12
    d500:      	cmp	w23, w21
    d504:      	add	x2, x9, x10
    d508:      	and	w1, w11, #0xff
    d50c:      	mov	w8, #0x4                // =4
    d510:      	cinc	x0, x19, hi
    d514:      	blr	x8
    d518:      	cmp	w23, w21
    d51c:      	str	x19, [sp, #0x60]
    d520:      	add	x19, sp, #0x70
    d524:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    d528:      	ldr	x21, [sp, #0x78]
    d52c:      	ldp	x2, x24, [sp, #0x50]
    d530:      	str	x21, [sp, #0x48]
    d534:      	b	0xd584 <generic_fentry_path+0x30d4>
    d538:      	add	x2, x24, #0x10
    d53c:      	mov	w8, #0x4                // =4
    d540:      	add	x9, sp, #0x98
    d544:      	add	x0, sp, #0x98
    d548:      	mov	w1, #0x8                // =8
    d54c:      	blr	x8
    d550:      	ldr	x8, [sp, #0x58]
    d554:      	ldr	x9, [sp, #0x98]
    d558:      	cmp	x8, x9
    d55c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    d560:      	add	x2, x24, #0x18
    d564:      	mov	w8, #0x4                // =4
    d568:      	mov	x0, x22
    d56c:      	mov	w1, #0x8                // =8
    d570:      	blr	x8
    d574:      	ldr	x24, [sp, #0x98]
    d578:      	ldr	x21, [sp, #0x48]
    d57c:      	add	x2, x24, #0x20
    d580:      	stp	x2, x24, [sp, #0x50]
    d584:      	ldr	x8, [sp, #0x30]
    d588:      	cmp	x21, x8
    d58c:      	b.ne	0xd59c <generic_fentry_path+0x30ec>
    d590:      	ldr	x8, [sp, #0x38]
    d594:      	cmp	x2, x8
    d598:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    d59c:      	mov	w8, #0x4                // =4
    d5a0:      	add	x0, sp, #0x70
    d5a4:      	mov	w1, #0x8                // =8
    d5a8:      	blr	x8
    d5ac:      	ldr	x8, [sp, #0x70]
    d5b0:      	cmp	x21, x8
    d5b4:      	b.eq	0xd6a4 <generic_fentry_path+0x31f4>
    d5b8:      	add	x23, x21, #0x18
    d5bc:      	mov	w8, #0x4                // =4
    d5c0:      	add	x9, sp, #0x98
    d5c4:      	add	x0, sp, #0x98
    d5c8:      	mov	w1, #0x8                // =8
    d5cc:      	mov	x2, x23
    d5d0:      	blr	x8
    d5d4:      	ldr	x8, [sp, #0x98]
    d5d8:      	cmp	x8, x21
    d5dc:      	b.eq	0xd6a4 <generic_fentry_path+0x31f4>
    d5e0:      	mov	w8, #0x4                // =4
    d5e4:      	add	x9, sp, #0x78
    d5e8:      	add	x0, sp, #0x78
    d5ec:      	mov	w1, #0x8                // =8
    d5f0:      	mov	x2, x23
    d5f4:      	blr	x8
    d5f8:      	add	x2, x21, #0x20
    d5fc:      	mov	w8, #0x4                // =4
    d600:      	mov	w9, #0x10               // =16
    d604:      	add	x10, sp, #0x80
    d608:      	add	x0, sp, #0x80
    d60c:      	mov	w1, #0x10               // =16
    d610:      	blr	x8
    d614:      	ldr	w21, [sp, #0x84]
    d618:      	ldr	x8, [sp, #0x40]
    d61c:      	ldr	x10, [sp, #0x60]
    d620:      	sub	x12, x10, x8
    d624:      	ldr	w23, [sp, #0x68]
    d628:      	subs	w10, w21, w23
    d62c:      	ldr	x9, [sp, #0x88]
    d630:      	csel	w10, wzr, w10, lo
    d634:      	cmp	w23, w21
    d638:      	csel	w11, w23, w21, lo
    d63c:      	cinc	w13, w11, hi
    d640:      	sub	w14, w23, w13
    d644:      	subs	x12, x12, x13
    d648:      	str	w14, [sp, #0x68]
    d64c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    d650:      	cmp	x12, #0xfff
    d654:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    d658:      	cmp	w23, w21
    d65c:      	b.ls	0xd668 <generic_fentry_path+0x31b8>
    d660:      	mov	w13, #0x2f              // =47
    d664:      	strb	w13, [x8, x12]
    d668:      	add	x19, x8, x12
    d66c:      	cmp	w23, w21
    d670:      	add	x2, x9, x10
    d674:      	and	w1, w11, #0xff
    d678:      	mov	w8, #0x4                // =4
    d67c:      	cinc	x0, x19, hi
    d680:      	blr	x8
    d684:      	cmp	w23, w21
    d688:      	str	x19, [sp, #0x60]
    d68c:      	add	x19, sp, #0x70
    d690:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    d694:      	ldr	x21, [sp, #0x78]
    d698:      	ldp	x2, x24, [sp, #0x50]
    d69c:      	str	x21, [sp, #0x48]
    d6a0:      	b	0xd6f0 <generic_fentry_path+0x3240>
    d6a4:      	add	x2, x24, #0x10
    d6a8:      	mov	w8, #0x4                // =4
    d6ac:      	add	x9, sp, #0x98
    d6b0:      	add	x0, sp, #0x98
    d6b4:      	mov	w1, #0x8                // =8
    d6b8:      	blr	x8
    d6bc:      	ldr	x8, [sp, #0x58]
    d6c0:      	ldr	x9, [sp, #0x98]
    d6c4:      	cmp	x8, x9
    d6c8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    d6cc:      	add	x2, x24, #0x18
    d6d0:      	mov	w8, #0x4                // =4
    d6d4:      	mov	x0, x22
    d6d8:      	mov	w1, #0x8                // =8
    d6dc:      	blr	x8
    d6e0:      	ldr	x24, [sp, #0x98]
    d6e4:      	ldr	x21, [sp, #0x48]
    d6e8:      	add	x2, x24, #0x20
    d6ec:      	stp	x2, x24, [sp, #0x50]
    d6f0:      	ldr	x8, [sp, #0x30]
    d6f4:      	cmp	x21, x8
    d6f8:      	b.ne	0xd708 <generic_fentry_path+0x3258>
    d6fc:      	ldr	x8, [sp, #0x38]
    d700:      	cmp	x2, x8
    d704:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    d708:      	mov	w8, #0x4                // =4
    d70c:      	add	x0, sp, #0x70
    d710:      	mov	w1, #0x8                // =8
    d714:      	blr	x8
    d718:      	ldr	x8, [sp, #0x70]
    d71c:      	cmp	x21, x8
    d720:      	b.eq	0xd810 <generic_fentry_path+0x3360>
    d724:      	add	x23, x21, #0x18
    d728:      	mov	w8, #0x4                // =4
    d72c:      	add	x9, sp, #0x98
    d730:      	add	x0, sp, #0x98
    d734:      	mov	w1, #0x8                // =8
    d738:      	mov	x2, x23
    d73c:      	blr	x8
    d740:      	ldr	x8, [sp, #0x98]
    d744:      	cmp	x8, x21
    d748:      	b.eq	0xd810 <generic_fentry_path+0x3360>
    d74c:      	mov	w8, #0x4                // =4
    d750:      	add	x9, sp, #0x78
    d754:      	add	x0, sp, #0x78
    d758:      	mov	w1, #0x8                // =8
    d75c:      	mov	x2, x23
    d760:      	blr	x8
    d764:      	add	x2, x21, #0x20
    d768:      	mov	w8, #0x4                // =4
    d76c:      	mov	w9, #0x10               // =16
    d770:      	add	x10, sp, #0x80
    d774:      	add	x0, sp, #0x80
    d778:      	mov	w1, #0x10               // =16
    d77c:      	blr	x8
    d780:      	ldr	w21, [sp, #0x84]
    d784:      	ldr	x8, [sp, #0x40]
    d788:      	ldr	x10, [sp, #0x60]
    d78c:      	sub	x12, x10, x8
    d790:      	ldr	w23, [sp, #0x68]
    d794:      	subs	w10, w21, w23
    d798:      	ldr	x9, [sp, #0x88]
    d79c:      	csel	w10, wzr, w10, lo
    d7a0:      	cmp	w23, w21
    d7a4:      	csel	w11, w23, w21, lo
    d7a8:      	cinc	w13, w11, hi
    d7ac:      	sub	w14, w23, w13
    d7b0:      	subs	x12, x12, x13
    d7b4:      	str	w14, [sp, #0x68]
    d7b8:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    d7bc:      	cmp	x12, #0xfff
    d7c0:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    d7c4:      	cmp	w23, w21
    d7c8:      	b.ls	0xd7d4 <generic_fentry_path+0x3324>
    d7cc:      	mov	w13, #0x2f              // =47
    d7d0:      	strb	w13, [x8, x12]
    d7d4:      	add	x19, x8, x12
    d7d8:      	cmp	w23, w21
    d7dc:      	add	x2, x9, x10
    d7e0:      	and	w1, w11, #0xff
    d7e4:      	mov	w8, #0x4                // =4
    d7e8:      	cinc	x0, x19, hi
    d7ec:      	blr	x8
    d7f0:      	cmp	w23, w21
    d7f4:      	str	x19, [sp, #0x60]
    d7f8:      	add	x19, sp, #0x70
    d7fc:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    d800:      	ldr	x21, [sp, #0x78]
    d804:      	ldp	x2, x24, [sp, #0x50]
    d808:      	str	x21, [sp, #0x48]
    d80c:      	b	0xd85c <generic_fentry_path+0x33ac>
    d810:      	add	x2, x24, #0x10
    d814:      	mov	w8, #0x4                // =4
    d818:      	add	x9, sp, #0x98
    d81c:      	add	x0, sp, #0x98
    d820:      	mov	w1, #0x8                // =8
    d824:      	blr	x8
    d828:      	ldr	x8, [sp, #0x58]
    d82c:      	ldr	x9, [sp, #0x98]
    d830:      	cmp	x8, x9
    d834:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    d838:      	add	x2, x24, #0x18
    d83c:      	mov	w8, #0x4                // =4
    d840:      	mov	x0, x22
    d844:      	mov	w1, #0x8                // =8
    d848:      	blr	x8
    d84c:      	ldr	x24, [sp, #0x98]
    d850:      	ldr	x21, [sp, #0x48]
    d854:      	add	x2, x24, #0x20
    d858:      	stp	x2, x24, [sp, #0x50]
    d85c:      	ldr	x8, [sp, #0x30]
    d860:      	cmp	x21, x8
    d864:      	b.ne	0xd874 <generic_fentry_path+0x33c4>
    d868:      	ldr	x8, [sp, #0x38]
    d86c:      	cmp	x2, x8
    d870:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    d874:      	mov	w8, #0x4                // =4
    d878:      	add	x0, sp, #0x70
    d87c:      	mov	w1, #0x8                // =8
    d880:      	blr	x8
    d884:      	ldr	x8, [sp, #0x70]
    d888:      	cmp	x21, x8
    d88c:      	b.eq	0xd97c <generic_fentry_path+0x34cc>
    d890:      	add	x23, x21, #0x18
    d894:      	mov	w8, #0x4                // =4
    d898:      	add	x9, sp, #0x98
    d89c:      	add	x0, sp, #0x98
    d8a0:      	mov	w1, #0x8                // =8
    d8a4:      	mov	x2, x23
    d8a8:      	blr	x8
    d8ac:      	ldr	x8, [sp, #0x98]
    d8b0:      	cmp	x8, x21
    d8b4:      	b.eq	0xd97c <generic_fentry_path+0x34cc>
    d8b8:      	mov	w8, #0x4                // =4
    d8bc:      	add	x9, sp, #0x78
    d8c0:      	add	x0, sp, #0x78
    d8c4:      	mov	w1, #0x8                // =8
    d8c8:      	mov	x2, x23
    d8cc:      	blr	x8
    d8d0:      	add	x2, x21, #0x20
    d8d4:      	mov	w8, #0x4                // =4
    d8d8:      	mov	w9, #0x10               // =16
    d8dc:      	add	x10, sp, #0x80
    d8e0:      	add	x0, sp, #0x80
    d8e4:      	mov	w1, #0x10               // =16
    d8e8:      	blr	x8
    d8ec:      	ldr	w21, [sp, #0x84]
    d8f0:      	ldr	x8, [sp, #0x40]
    d8f4:      	ldr	x10, [sp, #0x60]
    d8f8:      	sub	x12, x10, x8
    d8fc:      	ldr	w23, [sp, #0x68]
    d900:      	subs	w10, w21, w23
    d904:      	ldr	x9, [sp, #0x88]
    d908:      	csel	w10, wzr, w10, lo
    d90c:      	cmp	w23, w21
    d910:      	csel	w11, w23, w21, lo
    d914:      	cinc	w13, w11, hi
    d918:      	sub	w14, w23, w13
    d91c:      	subs	x12, x12, x13
    d920:      	str	w14, [sp, #0x68]
    d924:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    d928:      	cmp	x12, #0xfff
    d92c:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    d930:      	cmp	w23, w21
    d934:      	b.ls	0xd940 <generic_fentry_path+0x3490>
    d938:      	mov	w13, #0x2f              // =47
    d93c:      	strb	w13, [x8, x12]
    d940:      	add	x19, x8, x12
    d944:      	cmp	w23, w21
    d948:      	add	x2, x9, x10
    d94c:      	and	w1, w11, #0xff
    d950:      	mov	w8, #0x4                // =4
    d954:      	cinc	x0, x19, hi
    d958:      	blr	x8
    d95c:      	cmp	w23, w21
    d960:      	str	x19, [sp, #0x60]
    d964:      	add	x19, sp, #0x70
    d968:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    d96c:      	ldr	x21, [sp, #0x78]
    d970:      	ldp	x2, x24, [sp, #0x50]
    d974:      	str	x21, [sp, #0x48]
    d978:      	b	0xd9c8 <generic_fentry_path+0x3518>
    d97c:      	add	x2, x24, #0x10
    d980:      	mov	w8, #0x4                // =4
    d984:      	add	x9, sp, #0x98
    d988:      	add	x0, sp, #0x98
    d98c:      	mov	w1, #0x8                // =8
    d990:      	blr	x8
    d994:      	ldr	x8, [sp, #0x58]
    d998:      	ldr	x9, [sp, #0x98]
    d99c:      	cmp	x8, x9
    d9a0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    d9a4:      	add	x2, x24, #0x18
    d9a8:      	mov	w8, #0x4                // =4
    d9ac:      	mov	x0, x22
    d9b0:      	mov	w1, #0x8                // =8
    d9b4:      	blr	x8
    d9b8:      	ldr	x24, [sp, #0x98]
    d9bc:      	ldr	x21, [sp, #0x48]
    d9c0:      	add	x2, x24, #0x20
    d9c4:      	stp	x2, x24, [sp, #0x50]
    d9c8:      	ldr	x8, [sp, #0x30]
    d9cc:      	cmp	x21, x8
    d9d0:      	b.ne	0xd9e0 <generic_fentry_path+0x3530>
    d9d4:      	ldr	x8, [sp, #0x38]
    d9d8:      	cmp	x2, x8
    d9dc:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    d9e0:      	mov	w8, #0x4                // =4
    d9e4:      	add	x0, sp, #0x70
    d9e8:      	mov	w1, #0x8                // =8
    d9ec:      	blr	x8
    d9f0:      	ldr	x8, [sp, #0x70]
    d9f4:      	cmp	x21, x8
    d9f8:      	b.eq	0xdae8 <generic_fentry_path+0x3638>
    d9fc:      	add	x23, x21, #0x18
    da00:      	mov	w8, #0x4                // =4
    da04:      	add	x9, sp, #0x98
    da08:      	add	x0, sp, #0x98
    da0c:      	mov	w1, #0x8                // =8
    da10:      	mov	x2, x23
    da14:      	blr	x8
    da18:      	ldr	x8, [sp, #0x98]
    da1c:      	cmp	x8, x21
    da20:      	b.eq	0xdae8 <generic_fentry_path+0x3638>
    da24:      	mov	w8, #0x4                // =4
    da28:      	add	x9, sp, #0x78
    da2c:      	add	x0, sp, #0x78
    da30:      	mov	w1, #0x8                // =8
    da34:      	mov	x2, x23
    da38:      	blr	x8
    da3c:      	add	x2, x21, #0x20
    da40:      	mov	w8, #0x4                // =4
    da44:      	mov	w9, #0x10               // =16
    da48:      	add	x10, sp, #0x80
    da4c:      	add	x0, sp, #0x80
    da50:      	mov	w1, #0x10               // =16
    da54:      	blr	x8
    da58:      	ldr	w21, [sp, #0x84]
    da5c:      	ldr	x8, [sp, #0x40]
    da60:      	ldr	x10, [sp, #0x60]
    da64:      	sub	x12, x10, x8
    da68:      	ldr	w23, [sp, #0x68]
    da6c:      	subs	w10, w21, w23
    da70:      	ldr	x9, [sp, #0x88]
    da74:      	csel	w10, wzr, w10, lo
    da78:      	cmp	w23, w21
    da7c:      	csel	w11, w23, w21, lo
    da80:      	cinc	w13, w11, hi
    da84:      	sub	w14, w23, w13
    da88:      	subs	x12, x12, x13
    da8c:      	str	w14, [sp, #0x68]
    da90:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    da94:      	cmp	x12, #0xfff
    da98:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    da9c:      	cmp	w23, w21
    daa0:      	b.ls	0xdaac <generic_fentry_path+0x35fc>
    daa4:      	mov	w13, #0x2f              // =47
    daa8:      	strb	w13, [x8, x12]
    daac:      	add	x19, x8, x12
    dab0:      	cmp	w23, w21
    dab4:      	add	x2, x9, x10
    dab8:      	and	w1, w11, #0xff
    dabc:      	mov	w8, #0x4                // =4
    dac0:      	cinc	x0, x19, hi
    dac4:      	blr	x8
    dac8:      	cmp	w23, w21
    dacc:      	str	x19, [sp, #0x60]
    dad0:      	add	x19, sp, #0x70
    dad4:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    dad8:      	ldr	x21, [sp, #0x78]
    dadc:      	ldp	x2, x24, [sp, #0x50]
    dae0:      	str	x21, [sp, #0x48]
    dae4:      	b	0xdb34 <generic_fentry_path+0x3684>
    dae8:      	add	x2, x24, #0x10
    daec:      	mov	w8, #0x4                // =4
    daf0:      	add	x9, sp, #0x98
    daf4:      	add	x0, sp, #0x98
    daf8:      	mov	w1, #0x8                // =8
    dafc:      	blr	x8
    db00:      	ldr	x8, [sp, #0x58]
    db04:      	ldr	x9, [sp, #0x98]
    db08:      	cmp	x8, x9
    db0c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    db10:      	add	x2, x24, #0x18
    db14:      	mov	w8, #0x4                // =4
    db18:      	mov	x0, x22
    db1c:      	mov	w1, #0x8                // =8
    db20:      	blr	x8
    db24:      	ldr	x24, [sp, #0x98]
    db28:      	ldr	x21, [sp, #0x48]
    db2c:      	add	x2, x24, #0x20
    db30:      	stp	x2, x24, [sp, #0x50]
    db34:      	ldr	x8, [sp, #0x30]
    db38:      	cmp	x21, x8
    db3c:      	b.ne	0xdb4c <generic_fentry_path+0x369c>
    db40:      	ldr	x8, [sp, #0x38]
    db44:      	cmp	x2, x8
    db48:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    db4c:      	mov	w8, #0x4                // =4
    db50:      	add	x0, sp, #0x70
    db54:      	mov	w1, #0x8                // =8
    db58:      	blr	x8
    db5c:      	ldr	x8, [sp, #0x70]
    db60:      	cmp	x21, x8
    db64:      	b.eq	0xdc54 <generic_fentry_path+0x37a4>
    db68:      	add	x23, x21, #0x18
    db6c:      	mov	w8, #0x4                // =4
    db70:      	add	x9, sp, #0x98
    db74:      	add	x0, sp, #0x98
    db78:      	mov	w1, #0x8                // =8
    db7c:      	mov	x2, x23
    db80:      	blr	x8
    db84:      	ldr	x8, [sp, #0x98]
    db88:      	cmp	x8, x21
    db8c:      	b.eq	0xdc54 <generic_fentry_path+0x37a4>
    db90:      	mov	w8, #0x4                // =4
    db94:      	add	x9, sp, #0x78
    db98:      	add	x0, sp, #0x78
    db9c:      	mov	w1, #0x8                // =8
    dba0:      	mov	x2, x23
    dba4:      	blr	x8
    dba8:      	add	x2, x21, #0x20
    dbac:      	mov	w8, #0x4                // =4
    dbb0:      	mov	w9, #0x10               // =16
    dbb4:      	add	x10, sp, #0x80
    dbb8:      	add	x0, sp, #0x80
    dbbc:      	mov	w1, #0x10               // =16
    dbc0:      	blr	x8
    dbc4:      	ldr	w21, [sp, #0x84]
    dbc8:      	ldr	x8, [sp, #0x40]
    dbcc:      	ldr	x10, [sp, #0x60]
    dbd0:      	sub	x12, x10, x8
    dbd4:      	ldr	w23, [sp, #0x68]
    dbd8:      	subs	w10, w21, w23
    dbdc:      	ldr	x9, [sp, #0x88]
    dbe0:      	csel	w10, wzr, w10, lo
    dbe4:      	cmp	w23, w21
    dbe8:      	csel	w11, w23, w21, lo
    dbec:      	cinc	w13, w11, hi
    dbf0:      	sub	w14, w23, w13
    dbf4:      	subs	x12, x12, x13
    dbf8:      	str	w14, [sp, #0x68]
    dbfc:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    dc00:      	cmp	x12, #0xfff
    dc04:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    dc08:      	cmp	w23, w21
    dc0c:      	b.ls	0xdc18 <generic_fentry_path+0x3768>
    dc10:      	mov	w13, #0x2f              // =47
    dc14:      	strb	w13, [x8, x12]
    dc18:      	add	x19, x8, x12
    dc1c:      	cmp	w23, w21
    dc20:      	add	x2, x9, x10
    dc24:      	and	w1, w11, #0xff
    dc28:      	mov	w8, #0x4                // =4
    dc2c:      	cinc	x0, x19, hi
    dc30:      	blr	x8
    dc34:      	cmp	w23, w21
    dc38:      	str	x19, [sp, #0x60]
    dc3c:      	add	x19, sp, #0x70
    dc40:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    dc44:      	ldr	x21, [sp, #0x78]
    dc48:      	ldp	x2, x24, [sp, #0x50]
    dc4c:      	str	x21, [sp, #0x48]
    dc50:      	b	0xdca0 <generic_fentry_path+0x37f0>
    dc54:      	add	x2, x24, #0x10
    dc58:      	mov	w8, #0x4                // =4
    dc5c:      	add	x9, sp, #0x98
    dc60:      	add	x0, sp, #0x98
    dc64:      	mov	w1, #0x8                // =8
    dc68:      	blr	x8
    dc6c:      	ldr	x8, [sp, #0x58]
    dc70:      	ldr	x9, [sp, #0x98]
    dc74:      	cmp	x8, x9
    dc78:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    dc7c:      	add	x2, x24, #0x18
    dc80:      	mov	w8, #0x4                // =4
    dc84:      	mov	x0, x22
    dc88:      	mov	w1, #0x8                // =8
    dc8c:      	blr	x8
    dc90:      	ldr	x24, [sp, #0x98]
    dc94:      	ldr	x21, [sp, #0x48]
    dc98:      	add	x2, x24, #0x20
    dc9c:      	stp	x2, x24, [sp, #0x50]
    dca0:      	ldr	x8, [sp, #0x30]
    dca4:      	cmp	x21, x8
    dca8:      	b.ne	0xdcb8 <generic_fentry_path+0x3808>
    dcac:      	ldr	x8, [sp, #0x38]
    dcb0:      	cmp	x2, x8
    dcb4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    dcb8:      	mov	w8, #0x4                // =4
    dcbc:      	add	x0, sp, #0x70
    dcc0:      	mov	w1, #0x8                // =8
    dcc4:      	blr	x8
    dcc8:      	ldr	x8, [sp, #0x70]
    dccc:      	cmp	x21, x8
    dcd0:      	b.eq	0xddc0 <generic_fentry_path+0x3910>
    dcd4:      	add	x23, x21, #0x18
    dcd8:      	mov	w8, #0x4                // =4
    dcdc:      	add	x9, sp, #0x98
    dce0:      	add	x0, sp, #0x98
    dce4:      	mov	w1, #0x8                // =8
    dce8:      	mov	x2, x23
    dcec:      	blr	x8
    dcf0:      	ldr	x8, [sp, #0x98]
    dcf4:      	cmp	x8, x21
    dcf8:      	b.eq	0xddc0 <generic_fentry_path+0x3910>
    dcfc:      	mov	w8, #0x4                // =4
    dd00:      	add	x9, sp, #0x78
    dd04:      	add	x0, sp, #0x78
    dd08:      	mov	w1, #0x8                // =8
    dd0c:      	mov	x2, x23
    dd10:      	blr	x8
    dd14:      	add	x2, x21, #0x20
    dd18:      	mov	w8, #0x4                // =4
    dd1c:      	mov	w9, #0x10               // =16
    dd20:      	add	x10, sp, #0x80
    dd24:      	add	x0, sp, #0x80
    dd28:      	mov	w1, #0x10               // =16
    dd2c:      	blr	x8
    dd30:      	ldr	w21, [sp, #0x84]
    dd34:      	ldr	x8, [sp, #0x40]
    dd38:      	ldr	x10, [sp, #0x60]
    dd3c:      	sub	x12, x10, x8
    dd40:      	ldr	w23, [sp, #0x68]
    dd44:      	subs	w10, w21, w23
    dd48:      	ldr	x9, [sp, #0x88]
    dd4c:      	csel	w10, wzr, w10, lo
    dd50:      	cmp	w23, w21
    dd54:      	csel	w11, w23, w21, lo
    dd58:      	cinc	w13, w11, hi
    dd5c:      	sub	w14, w23, w13
    dd60:      	subs	x12, x12, x13
    dd64:      	str	w14, [sp, #0x68]
    dd68:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    dd6c:      	cmp	x12, #0xfff
    dd70:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    dd74:      	cmp	w23, w21
    dd78:      	b.ls	0xdd84 <generic_fentry_path+0x38d4>
    dd7c:      	mov	w13, #0x2f              // =47
    dd80:      	strb	w13, [x8, x12]
    dd84:      	add	x19, x8, x12
    dd88:      	cmp	w23, w21
    dd8c:      	add	x2, x9, x10
    dd90:      	and	w1, w11, #0xff
    dd94:      	mov	w8, #0x4                // =4
    dd98:      	cinc	x0, x19, hi
    dd9c:      	blr	x8
    dda0:      	cmp	w23, w21
    dda4:      	str	x19, [sp, #0x60]
    dda8:      	add	x19, sp, #0x70
    ddac:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    ddb0:      	ldr	x21, [sp, #0x78]
    ddb4:      	ldp	x2, x24, [sp, #0x50]
    ddb8:      	str	x21, [sp, #0x48]
    ddbc:      	b	0xde0c <generic_fentry_path+0x395c>
    ddc0:      	add	x2, x24, #0x10
    ddc4:      	mov	w8, #0x4                // =4
    ddc8:      	add	x9, sp, #0x98
    ddcc:      	add	x0, sp, #0x98
    ddd0:      	mov	w1, #0x8                // =8
    ddd4:      	blr	x8
    ddd8:      	ldr	x8, [sp, #0x58]
    dddc:      	ldr	x9, [sp, #0x98]
    dde0:      	cmp	x8, x9
    dde4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    dde8:      	add	x2, x24, #0x18
    ddec:      	mov	w8, #0x4                // =4
    ddf0:      	mov	x0, x22
    ddf4:      	mov	w1, #0x8                // =8
    ddf8:      	blr	x8
    ddfc:      	ldr	x24, [sp, #0x98]
    de00:      	ldr	x21, [sp, #0x48]
    de04:      	add	x2, x24, #0x20
    de08:      	stp	x2, x24, [sp, #0x50]
    de0c:      	ldr	x8, [sp, #0x30]
    de10:      	cmp	x21, x8
    de14:      	b.ne	0xde24 <generic_fentry_path+0x3974>
    de18:      	ldr	x8, [sp, #0x38]
    de1c:      	cmp	x2, x8
    de20:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    de24:      	mov	w8, #0x4                // =4
    de28:      	add	x0, sp, #0x70
    de2c:      	mov	w1, #0x8                // =8
    de30:      	blr	x8
    de34:      	ldr	x8, [sp, #0x70]
    de38:      	cmp	x21, x8
    de3c:      	b.eq	0xdf2c <generic_fentry_path+0x3a7c>
    de40:      	add	x23, x21, #0x18
    de44:      	mov	w8, #0x4                // =4
    de48:      	add	x9, sp, #0x98
    de4c:      	add	x0, sp, #0x98
    de50:      	mov	w1, #0x8                // =8
    de54:      	mov	x2, x23
    de58:      	blr	x8
    de5c:      	ldr	x8, [sp, #0x98]
    de60:      	cmp	x8, x21
    de64:      	b.eq	0xdf2c <generic_fentry_path+0x3a7c>
    de68:      	mov	w8, #0x4                // =4
    de6c:      	add	x9, sp, #0x78
    de70:      	add	x0, sp, #0x78
    de74:      	mov	w1, #0x8                // =8
    de78:      	mov	x2, x23
    de7c:      	blr	x8
    de80:      	add	x2, x21, #0x20
    de84:      	mov	w8, #0x4                // =4
    de88:      	mov	w9, #0x10               // =16
    de8c:      	add	x10, sp, #0x80
    de90:      	add	x0, sp, #0x80
    de94:      	mov	w1, #0x10               // =16
    de98:      	blr	x8
    de9c:      	ldr	w21, [sp, #0x84]
    dea0:      	ldr	x8, [sp, #0x40]
    dea4:      	ldr	x10, [sp, #0x60]
    dea8:      	sub	x12, x10, x8
    deac:      	ldr	w23, [sp, #0x68]
    deb0:      	subs	w10, w21, w23
    deb4:      	ldr	x9, [sp, #0x88]
    deb8:      	csel	w10, wzr, w10, lo
    debc:      	cmp	w23, w21
    dec0:      	csel	w11, w23, w21, lo
    dec4:      	cinc	w13, w11, hi
    dec8:      	sub	w14, w23, w13
    decc:      	subs	x12, x12, x13
    ded0:      	str	w14, [sp, #0x68]
    ded4:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    ded8:      	cmp	x12, #0xfff
    dedc:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    dee0:      	cmp	w23, w21
    dee4:      	b.ls	0xdef0 <generic_fentry_path+0x3a40>
    dee8:      	mov	w13, #0x2f              // =47
    deec:      	strb	w13, [x8, x12]
    def0:      	add	x19, x8, x12
    def4:      	cmp	w23, w21
    def8:      	add	x2, x9, x10
    defc:      	and	w1, w11, #0xff
    df00:      	mov	w8, #0x4                // =4
    df04:      	cinc	x0, x19, hi
    df08:      	blr	x8
    df0c:      	cmp	w23, w21
    df10:      	str	x19, [sp, #0x60]
    df14:      	add	x19, sp, #0x70
    df18:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    df1c:      	ldr	x21, [sp, #0x78]
    df20:      	ldp	x2, x24, [sp, #0x50]
    df24:      	str	x21, [sp, #0x48]
    df28:      	b	0xdf78 <generic_fentry_path+0x3ac8>
    df2c:      	add	x2, x24, #0x10
    df30:      	mov	w8, #0x4                // =4
    df34:      	add	x9, sp, #0x98
    df38:      	add	x0, sp, #0x98
    df3c:      	mov	w1, #0x8                // =8
    df40:      	blr	x8
    df44:      	ldr	x8, [sp, #0x58]
    df48:      	ldr	x9, [sp, #0x98]
    df4c:      	cmp	x8, x9
    df50:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    df54:      	add	x2, x24, #0x18
    df58:      	mov	w8, #0x4                // =4
    df5c:      	mov	x0, x22
    df60:      	mov	w1, #0x8                // =8
    df64:      	blr	x8
    df68:      	ldr	x24, [sp, #0x98]
    df6c:      	ldr	x21, [sp, #0x48]
    df70:      	add	x2, x24, #0x20
    df74:      	stp	x2, x24, [sp, #0x50]
    df78:      	ldr	x8, [sp, #0x30]
    df7c:      	cmp	x21, x8
    df80:      	b.ne	0xdf90 <generic_fentry_path+0x3ae0>
    df84:      	ldr	x8, [sp, #0x38]
    df88:      	cmp	x2, x8
    df8c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    df90:      	mov	w8, #0x4                // =4
    df94:      	add	x0, sp, #0x70
    df98:      	mov	w1, #0x8                // =8
    df9c:      	blr	x8
    dfa0:      	ldr	x8, [sp, #0x70]
    dfa4:      	cmp	x21, x8
    dfa8:      	b.eq	0xe098 <generic_fentry_path+0x3be8>
    dfac:      	add	x23, x21, #0x18
    dfb0:      	mov	w8, #0x4                // =4
    dfb4:      	add	x9, sp, #0x98
    dfb8:      	add	x0, sp, #0x98
    dfbc:      	mov	w1, #0x8                // =8
    dfc0:      	mov	x2, x23
    dfc4:      	blr	x8
    dfc8:      	ldr	x8, [sp, #0x98]
    dfcc:      	cmp	x8, x21
    dfd0:      	b.eq	0xe098 <generic_fentry_path+0x3be8>
    dfd4:      	mov	w8, #0x4                // =4
    dfd8:      	add	x9, sp, #0x78
    dfdc:      	add	x0, sp, #0x78
    dfe0:      	mov	w1, #0x8                // =8
    dfe4:      	mov	x2, x23
    dfe8:      	blr	x8
    dfec:      	add	x2, x21, #0x20
    dff0:      	mov	w8, #0x4                // =4
    dff4:      	mov	w9, #0x10               // =16
    dff8:      	add	x10, sp, #0x80
    dffc:      	add	x0, sp, #0x80
    e000:      	mov	w1, #0x10               // =16
    e004:      	blr	x8
    e008:      	ldr	w21, [sp, #0x84]
    e00c:      	ldr	x8, [sp, #0x40]
    e010:      	ldr	x10, [sp, #0x60]
    e014:      	sub	x12, x10, x8
    e018:      	ldr	w23, [sp, #0x68]
    e01c:      	subs	w10, w21, w23
    e020:      	ldr	x9, [sp, #0x88]
    e024:      	csel	w10, wzr, w10, lo
    e028:      	cmp	w23, w21
    e02c:      	csel	w11, w23, w21, lo
    e030:      	cinc	w13, w11, hi
    e034:      	sub	w14, w23, w13
    e038:      	subs	x12, x12, x13
    e03c:      	str	w14, [sp, #0x68]
    e040:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    e044:      	cmp	x12, #0xfff
    e048:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    e04c:      	cmp	w23, w21
    e050:      	b.ls	0xe05c <generic_fentry_path+0x3bac>
    e054:      	mov	w13, #0x2f              // =47
    e058:      	strb	w13, [x8, x12]
    e05c:      	add	x19, x8, x12
    e060:      	cmp	w23, w21
    e064:      	add	x2, x9, x10
    e068:      	and	w1, w11, #0xff
    e06c:      	mov	w8, #0x4                // =4
    e070:      	cinc	x0, x19, hi
    e074:      	blr	x8
    e078:      	cmp	w23, w21
    e07c:      	str	x19, [sp, #0x60]
    e080:      	add	x19, sp, #0x70
    e084:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    e088:      	ldr	x21, [sp, #0x78]
    e08c:      	ldp	x2, x24, [sp, #0x50]
    e090:      	str	x21, [sp, #0x48]
    e094:      	b	0xe0e4 <generic_fentry_path+0x3c34>
    e098:      	add	x2, x24, #0x10
    e09c:      	mov	w8, #0x4                // =4
    e0a0:      	add	x9, sp, #0x98
    e0a4:      	add	x0, sp, #0x98
    e0a8:      	mov	w1, #0x8                // =8
    e0ac:      	blr	x8
    e0b0:      	ldr	x8, [sp, #0x58]
    e0b4:      	ldr	x9, [sp, #0x98]
    e0b8:      	cmp	x8, x9
    e0bc:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    e0c0:      	add	x2, x24, #0x18
    e0c4:      	mov	w8, #0x4                // =4
    e0c8:      	mov	x0, x22
    e0cc:      	mov	w1, #0x8                // =8
    e0d0:      	blr	x8
    e0d4:      	ldr	x24, [sp, #0x98]
    e0d8:      	ldr	x21, [sp, #0x48]
    e0dc:      	add	x2, x24, #0x20
    e0e0:      	stp	x2, x24, [sp, #0x50]
    e0e4:      	ldr	x8, [sp, #0x30]
    e0e8:      	cmp	x21, x8
    e0ec:      	b.ne	0xe0fc <generic_fentry_path+0x3c4c>
    e0f0:      	ldr	x8, [sp, #0x38]
    e0f4:      	cmp	x2, x8
    e0f8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    e0fc:      	mov	w8, #0x4                // =4
    e100:      	add	x0, sp, #0x70
    e104:      	mov	w1, #0x8                // =8
    e108:      	blr	x8
    e10c:      	ldr	x8, [sp, #0x70]
    e110:      	cmp	x21, x8
    e114:      	b.eq	0xe204 <generic_fentry_path+0x3d54>
    e118:      	add	x23, x21, #0x18
    e11c:      	mov	w8, #0x4                // =4
    e120:      	add	x9, sp, #0x98
    e124:      	add	x0, sp, #0x98
    e128:      	mov	w1, #0x8                // =8
    e12c:      	mov	x2, x23
    e130:      	blr	x8
    e134:      	ldr	x8, [sp, #0x98]
    e138:      	cmp	x8, x21
    e13c:      	b.eq	0xe204 <generic_fentry_path+0x3d54>
    e140:      	mov	w8, #0x4                // =4
    e144:      	add	x9, sp, #0x78
    e148:      	add	x0, sp, #0x78
    e14c:      	mov	w1, #0x8                // =8
    e150:      	mov	x2, x23
    e154:      	blr	x8
    e158:      	add	x2, x21, #0x20
    e15c:      	mov	w8, #0x4                // =4
    e160:      	mov	w9, #0x10               // =16
    e164:      	add	x10, sp, #0x80
    e168:      	add	x0, sp, #0x80
    e16c:      	mov	w1, #0x10               // =16
    e170:      	blr	x8
    e174:      	ldr	w21, [sp, #0x84]
    e178:      	ldr	x8, [sp, #0x40]
    e17c:      	ldr	x10, [sp, #0x60]
    e180:      	sub	x12, x10, x8
    e184:      	ldr	w23, [sp, #0x68]
    e188:      	subs	w10, w21, w23
    e18c:      	ldr	x9, [sp, #0x88]
    e190:      	csel	w10, wzr, w10, lo
    e194:      	cmp	w23, w21
    e198:      	csel	w11, w23, w21, lo
    e19c:      	cinc	w13, w11, hi
    e1a0:      	sub	w14, w23, w13
    e1a4:      	subs	x12, x12, x13
    e1a8:      	str	w14, [sp, #0x68]
    e1ac:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    e1b0:      	cmp	x12, #0xfff
    e1b4:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    e1b8:      	cmp	w23, w21
    e1bc:      	b.ls	0xe1c8 <generic_fentry_path+0x3d18>
    e1c0:      	mov	w13, #0x2f              // =47
    e1c4:      	strb	w13, [x8, x12]
    e1c8:      	add	x19, x8, x12
    e1cc:      	cmp	w23, w21
    e1d0:      	add	x2, x9, x10
    e1d4:      	and	w1, w11, #0xff
    e1d8:      	mov	w8, #0x4                // =4
    e1dc:      	cinc	x0, x19, hi
    e1e0:      	blr	x8
    e1e4:      	cmp	w23, w21
    e1e8:      	str	x19, [sp, #0x60]
    e1ec:      	add	x19, sp, #0x70
    e1f0:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    e1f4:      	ldr	x21, [sp, #0x78]
    e1f8:      	ldp	x2, x24, [sp, #0x50]
    e1fc:      	str	x21, [sp, #0x48]
    e200:      	b	0xe250 <generic_fentry_path+0x3da0>
    e204:      	add	x2, x24, #0x10
    e208:      	mov	w8, #0x4                // =4
    e20c:      	add	x9, sp, #0x98
    e210:      	add	x0, sp, #0x98
    e214:      	mov	w1, #0x8                // =8
    e218:      	blr	x8
    e21c:      	ldr	x8, [sp, #0x58]
    e220:      	ldr	x9, [sp, #0x98]
    e224:      	cmp	x8, x9
    e228:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    e22c:      	add	x2, x24, #0x18
    e230:      	mov	w8, #0x4                // =4
    e234:      	mov	x0, x22
    e238:      	mov	w1, #0x8                // =8
    e23c:      	blr	x8
    e240:      	ldr	x24, [sp, #0x98]
    e244:      	ldr	x21, [sp, #0x48]
    e248:      	add	x2, x24, #0x20
    e24c:      	stp	x2, x24, [sp, #0x50]
    e250:      	ldr	x8, [sp, #0x30]
    e254:      	cmp	x21, x8
    e258:      	b.ne	0xe268 <generic_fentry_path+0x3db8>
    e25c:      	ldr	x8, [sp, #0x38]
    e260:      	cmp	x2, x8
    e264:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    e268:      	mov	w8, #0x4                // =4
    e26c:      	add	x0, sp, #0x70
    e270:      	mov	w1, #0x8                // =8
    e274:      	blr	x8
    e278:      	ldr	x8, [sp, #0x70]
    e27c:      	cmp	x21, x8
    e280:      	b.eq	0xe370 <generic_fentry_path+0x3ec0>
    e284:      	add	x23, x21, #0x18
    e288:      	mov	w8, #0x4                // =4
    e28c:      	add	x9, sp, #0x98
    e290:      	add	x0, sp, #0x98
    e294:      	mov	w1, #0x8                // =8
    e298:      	mov	x2, x23
    e29c:      	blr	x8
    e2a0:      	ldr	x8, [sp, #0x98]
    e2a4:      	cmp	x8, x21
    e2a8:      	b.eq	0xe370 <generic_fentry_path+0x3ec0>
    e2ac:      	mov	w8, #0x4                // =4
    e2b0:      	add	x9, sp, #0x78
    e2b4:      	add	x0, sp, #0x78
    e2b8:      	mov	w1, #0x8                // =8
    e2bc:      	mov	x2, x23
    e2c0:      	blr	x8
    e2c4:      	add	x2, x21, #0x20
    e2c8:      	mov	w8, #0x4                // =4
    e2cc:      	mov	w9, #0x10               // =16
    e2d0:      	add	x10, sp, #0x80
    e2d4:      	add	x0, sp, #0x80
    e2d8:      	mov	w1, #0x10               // =16
    e2dc:      	blr	x8
    e2e0:      	ldr	w21, [sp, #0x84]
    e2e4:      	ldr	x8, [sp, #0x40]
    e2e8:      	ldr	x10, [sp, #0x60]
    e2ec:      	sub	x12, x10, x8
    e2f0:      	ldr	w23, [sp, #0x68]
    e2f4:      	subs	w10, w21, w23
    e2f8:      	ldr	x9, [sp, #0x88]
    e2fc:      	csel	w10, wzr, w10, lo
    e300:      	cmp	w23, w21
    e304:      	csel	w11, w23, w21, lo
    e308:      	cinc	w13, w11, hi
    e30c:      	sub	w14, w23, w13
    e310:      	subs	x12, x12, x13
    e314:      	str	w14, [sp, #0x68]
    e318:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    e31c:      	cmp	x12, #0xfff
    e320:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    e324:      	cmp	w23, w21
    e328:      	b.ls	0xe334 <generic_fentry_path+0x3e84>
    e32c:      	mov	w13, #0x2f              // =47
    e330:      	strb	w13, [x8, x12]
    e334:      	add	x19, x8, x12
    e338:      	cmp	w23, w21
    e33c:      	add	x2, x9, x10
    e340:      	and	w1, w11, #0xff
    e344:      	mov	w8, #0x4                // =4
    e348:      	cinc	x0, x19, hi
    e34c:      	blr	x8
    e350:      	cmp	w23, w21
    e354:      	str	x19, [sp, #0x60]
    e358:      	add	x19, sp, #0x70
    e35c:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    e360:      	ldr	x21, [sp, #0x78]
    e364:      	ldp	x2, x24, [sp, #0x50]
    e368:      	str	x21, [sp, #0x48]
    e36c:      	b	0xe3bc <generic_fentry_path+0x3f0c>
    e370:      	add	x2, x24, #0x10
    e374:      	mov	w8, #0x4                // =4
    e378:      	add	x9, sp, #0x98
    e37c:      	add	x0, sp, #0x98
    e380:      	mov	w1, #0x8                // =8
    e384:      	blr	x8
    e388:      	ldr	x8, [sp, #0x58]
    e38c:      	ldr	x9, [sp, #0x98]
    e390:      	cmp	x8, x9
    e394:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    e398:      	add	x2, x24, #0x18
    e39c:      	mov	w8, #0x4                // =4
    e3a0:      	mov	x0, x22
    e3a4:      	mov	w1, #0x8                // =8
    e3a8:      	blr	x8
    e3ac:      	ldr	x24, [sp, #0x98]
    e3b0:      	ldr	x21, [sp, #0x48]
    e3b4:      	add	x2, x24, #0x20
    e3b8:      	stp	x2, x24, [sp, #0x50]
    e3bc:      	ldr	x8, [sp, #0x30]
    e3c0:      	cmp	x21, x8
    e3c4:      	b.ne	0xe3d4 <generic_fentry_path+0x3f24>
    e3c8:      	ldr	x8, [sp, #0x38]
    e3cc:      	cmp	x2, x8
    e3d0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    e3d4:      	mov	w8, #0x4                // =4
    e3d8:      	add	x0, sp, #0x70
    e3dc:      	mov	w1, #0x8                // =8
    e3e0:      	blr	x8
    e3e4:      	ldr	x8, [sp, #0x70]
    e3e8:      	cmp	x21, x8
    e3ec:      	b.eq	0xe4dc <generic_fentry_path+0x402c>
    e3f0:      	add	x23, x21, #0x18
    e3f4:      	mov	w8, #0x4                // =4
    e3f8:      	add	x9, sp, #0x98
    e3fc:      	add	x0, sp, #0x98
    e400:      	mov	w1, #0x8                // =8
    e404:      	mov	x2, x23
    e408:      	blr	x8
    e40c:      	ldr	x8, [sp, #0x98]
    e410:      	cmp	x8, x21
    e414:      	b.eq	0xe4dc <generic_fentry_path+0x402c>
    e418:      	mov	w8, #0x4                // =4
    e41c:      	add	x9, sp, #0x78
    e420:      	add	x0, sp, #0x78
    e424:      	mov	w1, #0x8                // =8
    e428:      	mov	x2, x23
    e42c:      	blr	x8
    e430:      	add	x2, x21, #0x20
    e434:      	mov	w8, #0x4                // =4
    e438:      	mov	w9, #0x10               // =16
    e43c:      	add	x10, sp, #0x80
    e440:      	add	x0, sp, #0x80
    e444:      	mov	w1, #0x10               // =16
    e448:      	blr	x8
    e44c:      	ldr	w21, [sp, #0x84]
    e450:      	ldr	x8, [sp, #0x40]
    e454:      	ldr	x10, [sp, #0x60]
    e458:      	sub	x12, x10, x8
    e45c:      	ldr	w23, [sp, #0x68]
    e460:      	subs	w10, w21, w23
    e464:      	ldr	x9, [sp, #0x88]
    e468:      	csel	w10, wzr, w10, lo
    e46c:      	cmp	w23, w21
    e470:      	csel	w11, w23, w21, lo
    e474:      	cinc	w13, w11, hi
    e478:      	sub	w14, w23, w13
    e47c:      	subs	x12, x12, x13
    e480:      	str	w14, [sp, #0x68]
    e484:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    e488:      	cmp	x12, #0xfff
    e48c:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    e490:      	cmp	w23, w21
    e494:      	b.ls	0xe4a0 <generic_fentry_path+0x3ff0>
    e498:      	mov	w13, #0x2f              // =47
    e49c:      	strb	w13, [x8, x12]
    e4a0:      	add	x19, x8, x12
    e4a4:      	cmp	w23, w21
    e4a8:      	add	x2, x9, x10
    e4ac:      	and	w1, w11, #0xff
    e4b0:      	mov	w8, #0x4                // =4
    e4b4:      	cinc	x0, x19, hi
    e4b8:      	blr	x8
    e4bc:      	cmp	w23, w21
    e4c0:      	str	x19, [sp, #0x60]
    e4c4:      	add	x19, sp, #0x70
    e4c8:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    e4cc:      	ldr	x21, [sp, #0x78]
    e4d0:      	ldp	x2, x24, [sp, #0x50]
    e4d4:      	str	x21, [sp, #0x48]
    e4d8:      	b	0xe528 <generic_fentry_path+0x4078>
    e4dc:      	add	x2, x24, #0x10
    e4e0:      	mov	w8, #0x4                // =4
    e4e4:      	add	x9, sp, #0x98
    e4e8:      	add	x0, sp, #0x98
    e4ec:      	mov	w1, #0x8                // =8
    e4f0:      	blr	x8
    e4f4:      	ldr	x8, [sp, #0x58]
    e4f8:      	ldr	x9, [sp, #0x98]
    e4fc:      	cmp	x8, x9
    e500:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    e504:      	add	x2, x24, #0x18
    e508:      	mov	w8, #0x4                // =4
    e50c:      	mov	x0, x22
    e510:      	mov	w1, #0x8                // =8
    e514:      	blr	x8
    e518:      	ldr	x24, [sp, #0x98]
    e51c:      	ldr	x21, [sp, #0x48]
    e520:      	add	x2, x24, #0x20
    e524:      	stp	x2, x24, [sp, #0x50]
    e528:      	ldr	x8, [sp, #0x30]
    e52c:      	cmp	x21, x8
    e530:      	b.ne	0xe540 <generic_fentry_path+0x4090>
    e534:      	ldr	x8, [sp, #0x38]
    e538:      	cmp	x2, x8
    e53c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    e540:      	mov	w8, #0x4                // =4
    e544:      	add	x0, sp, #0x70
    e548:      	mov	w1, #0x8                // =8
    e54c:      	blr	x8
    e550:      	ldr	x8, [sp, #0x70]
    e554:      	cmp	x21, x8
    e558:      	b.eq	0xe648 <generic_fentry_path+0x4198>
    e55c:      	add	x23, x21, #0x18
    e560:      	mov	w8, #0x4                // =4
    e564:      	add	x9, sp, #0x98
    e568:      	add	x0, sp, #0x98
    e56c:      	mov	w1, #0x8                // =8
    e570:      	mov	x2, x23
    e574:      	blr	x8
    e578:      	ldr	x8, [sp, #0x98]
    e57c:      	cmp	x8, x21
    e580:      	b.eq	0xe648 <generic_fentry_path+0x4198>
    e584:      	mov	w8, #0x4                // =4
    e588:      	add	x9, sp, #0x78
    e58c:      	add	x0, sp, #0x78
    e590:      	mov	w1, #0x8                // =8
    e594:      	mov	x2, x23
    e598:      	blr	x8
    e59c:      	add	x2, x21, #0x20
    e5a0:      	mov	w8, #0x4                // =4
    e5a4:      	mov	w9, #0x10               // =16
    e5a8:      	add	x10, sp, #0x80
    e5ac:      	add	x0, sp, #0x80
    e5b0:      	mov	w1, #0x10               // =16
    e5b4:      	blr	x8
    e5b8:      	ldr	w21, [sp, #0x84]
    e5bc:      	ldr	x8, [sp, #0x40]
    e5c0:      	ldr	x10, [sp, #0x60]
    e5c4:      	sub	x12, x10, x8
    e5c8:      	ldr	w23, [sp, #0x68]
    e5cc:      	subs	w10, w21, w23
    e5d0:      	ldr	x9, [sp, #0x88]
    e5d4:      	csel	w10, wzr, w10, lo
    e5d8:      	cmp	w23, w21
    e5dc:      	csel	w11, w23, w21, lo
    e5e0:      	cinc	w13, w11, hi
    e5e4:      	sub	w14, w23, w13
    e5e8:      	subs	x12, x12, x13
    e5ec:      	str	w14, [sp, #0x68]
    e5f0:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    e5f4:      	cmp	x12, #0xfff
    e5f8:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    e5fc:      	cmp	w23, w21
    e600:      	b.ls	0xe60c <generic_fentry_path+0x415c>
    e604:      	mov	w13, #0x2f              // =47
    e608:      	strb	w13, [x8, x12]
    e60c:      	add	x19, x8, x12
    e610:      	cmp	w23, w21
    e614:      	add	x2, x9, x10
    e618:      	and	w1, w11, #0xff
    e61c:      	mov	w8, #0x4                // =4
    e620:      	cinc	x0, x19, hi
    e624:      	blr	x8
    e628:      	cmp	w23, w21
    e62c:      	str	x19, [sp, #0x60]
    e630:      	add	x19, sp, #0x70
    e634:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    e638:      	ldr	x21, [sp, #0x78]
    e63c:      	ldp	x2, x24, [sp, #0x50]
    e640:      	str	x21, [sp, #0x48]
    e644:      	b	0xe694 <generic_fentry_path+0x41e4>
    e648:      	add	x2, x24, #0x10
    e64c:      	mov	w8, #0x4                // =4
    e650:      	add	x9, sp, #0x98
    e654:      	add	x0, sp, #0x98
    e658:      	mov	w1, #0x8                // =8
    e65c:      	blr	x8
    e660:      	ldr	x8, [sp, #0x58]
    e664:      	ldr	x9, [sp, #0x98]
    e668:      	cmp	x8, x9
    e66c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    e670:      	add	x2, x24, #0x18
    e674:      	mov	w8, #0x4                // =4
    e678:      	mov	x0, x22
    e67c:      	mov	w1, #0x8                // =8
    e680:      	blr	x8
    e684:      	ldr	x24, [sp, #0x98]
    e688:      	ldr	x21, [sp, #0x48]
    e68c:      	add	x2, x24, #0x20
    e690:      	stp	x2, x24, [sp, #0x50]
    e694:      	ldr	x8, [sp, #0x30]
    e698:      	cmp	x21, x8
    e69c:      	b.ne	0xe6ac <generic_fentry_path+0x41fc>
    e6a0:      	ldr	x8, [sp, #0x38]
    e6a4:      	cmp	x2, x8
    e6a8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    e6ac:      	mov	w8, #0x4                // =4
    e6b0:      	add	x0, sp, #0x70
    e6b4:      	mov	w1, #0x8                // =8
    e6b8:      	blr	x8
    e6bc:      	ldr	x8, [sp, #0x70]
    e6c0:      	cmp	x21, x8
    e6c4:      	b.eq	0xe7b4 <generic_fentry_path+0x4304>
    e6c8:      	add	x23, x21, #0x18
    e6cc:      	mov	w8, #0x4                // =4
    e6d0:      	add	x9, sp, #0x98
    e6d4:      	add	x0, sp, #0x98
    e6d8:      	mov	w1, #0x8                // =8
    e6dc:      	mov	x2, x23
    e6e0:      	blr	x8
    e6e4:      	ldr	x8, [sp, #0x98]
    e6e8:      	cmp	x8, x21
    e6ec:      	b.eq	0xe7b4 <generic_fentry_path+0x4304>
    e6f0:      	mov	w8, #0x4                // =4
    e6f4:      	add	x9, sp, #0x78
    e6f8:      	add	x0, sp, #0x78
    e6fc:      	mov	w1, #0x8                // =8
    e700:      	mov	x2, x23
    e704:      	blr	x8
    e708:      	add	x2, x21, #0x20
    e70c:      	mov	w8, #0x4                // =4
    e710:      	mov	w9, #0x10               // =16
    e714:      	add	x10, sp, #0x80
    e718:      	add	x0, sp, #0x80
    e71c:      	mov	w1, #0x10               // =16
    e720:      	blr	x8
    e724:      	ldr	w21, [sp, #0x84]
    e728:      	ldr	x8, [sp, #0x40]
    e72c:      	ldr	x10, [sp, #0x60]
    e730:      	sub	x12, x10, x8
    e734:      	ldr	w23, [sp, #0x68]
    e738:      	subs	w10, w21, w23
    e73c:      	ldr	x9, [sp, #0x88]
    e740:      	csel	w10, wzr, w10, lo
    e744:      	cmp	w23, w21
    e748:      	csel	w11, w23, w21, lo
    e74c:      	cinc	w13, w11, hi
    e750:      	sub	w14, w23, w13
    e754:      	subs	x12, x12, x13
    e758:      	str	w14, [sp, #0x68]
    e75c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    e760:      	cmp	x12, #0xfff
    e764:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    e768:      	cmp	w23, w21
    e76c:      	b.ls	0xe778 <generic_fentry_path+0x42c8>
    e770:      	mov	w13, #0x2f              // =47
    e774:      	strb	w13, [x8, x12]
    e778:      	add	x19, x8, x12
    e77c:      	cmp	w23, w21
    e780:      	add	x2, x9, x10
    e784:      	and	w1, w11, #0xff
    e788:      	mov	w8, #0x4                // =4
    e78c:      	cinc	x0, x19, hi
    e790:      	blr	x8
    e794:      	cmp	w23, w21
    e798:      	str	x19, [sp, #0x60]
    e79c:      	add	x19, sp, #0x70
    e7a0:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    e7a4:      	ldr	x21, [sp, #0x78]
    e7a8:      	ldp	x2, x24, [sp, #0x50]
    e7ac:      	str	x21, [sp, #0x48]
    e7b0:      	b	0xe800 <generic_fentry_path+0x4350>
    e7b4:      	add	x2, x24, #0x10
    e7b8:      	mov	w8, #0x4                // =4
    e7bc:      	add	x9, sp, #0x98
    e7c0:      	add	x0, sp, #0x98
    e7c4:      	mov	w1, #0x8                // =8
    e7c8:      	blr	x8
    e7cc:      	ldr	x8, [sp, #0x58]
    e7d0:      	ldr	x9, [sp, #0x98]
    e7d4:      	cmp	x8, x9
    e7d8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    e7dc:      	add	x2, x24, #0x18
    e7e0:      	mov	w8, #0x4                // =4
    e7e4:      	mov	x0, x22
    e7e8:      	mov	w1, #0x8                // =8
    e7ec:      	blr	x8
    e7f0:      	ldr	x24, [sp, #0x98]
    e7f4:      	ldr	x21, [sp, #0x48]
    e7f8:      	add	x2, x24, #0x20
    e7fc:      	stp	x2, x24, [sp, #0x50]
    e800:      	ldr	x8, [sp, #0x30]
    e804:      	cmp	x21, x8
    e808:      	b.ne	0xe818 <generic_fentry_path+0x4368>
    e80c:      	ldr	x8, [sp, #0x38]
    e810:      	cmp	x2, x8
    e814:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    e818:      	mov	w8, #0x4                // =4
    e81c:      	add	x0, sp, #0x70
    e820:      	mov	w1, #0x8                // =8
    e824:      	blr	x8
    e828:      	ldr	x8, [sp, #0x70]
    e82c:      	cmp	x21, x8
    e830:      	b.eq	0xe920 <generic_fentry_path+0x4470>
    e834:      	add	x23, x21, #0x18
    e838:      	mov	w8, #0x4                // =4
    e83c:      	add	x9, sp, #0x98
    e840:      	add	x0, sp, #0x98
    e844:      	mov	w1, #0x8                // =8
    e848:      	mov	x2, x23
    e84c:      	blr	x8
    e850:      	ldr	x8, [sp, #0x98]
    e854:      	cmp	x8, x21
    e858:      	b.eq	0xe920 <generic_fentry_path+0x4470>
    e85c:      	mov	w8, #0x4                // =4
    e860:      	add	x9, sp, #0x78
    e864:      	add	x0, sp, #0x78
    e868:      	mov	w1, #0x8                // =8
    e86c:      	mov	x2, x23
    e870:      	blr	x8
    e874:      	add	x2, x21, #0x20
    e878:      	mov	w8, #0x4                // =4
    e87c:      	mov	w9, #0x10               // =16
    e880:      	add	x10, sp, #0x80
    e884:      	add	x0, sp, #0x80
    e888:      	mov	w1, #0x10               // =16
    e88c:      	blr	x8
    e890:      	ldr	w21, [sp, #0x84]
    e894:      	ldr	x8, [sp, #0x40]
    e898:      	ldr	x10, [sp, #0x60]
    e89c:      	sub	x12, x10, x8
    e8a0:      	ldr	w23, [sp, #0x68]
    e8a4:      	subs	w10, w21, w23
    e8a8:      	ldr	x9, [sp, #0x88]
    e8ac:      	csel	w10, wzr, w10, lo
    e8b0:      	cmp	w23, w21
    e8b4:      	csel	w11, w23, w21, lo
    e8b8:      	cinc	w13, w11, hi
    e8bc:      	sub	w14, w23, w13
    e8c0:      	subs	x12, x12, x13
    e8c4:      	str	w14, [sp, #0x68]
    e8c8:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    e8cc:      	cmp	x12, #0xfff
    e8d0:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    e8d4:      	cmp	w23, w21
    e8d8:      	b.ls	0xe8e4 <generic_fentry_path+0x4434>
    e8dc:      	mov	w13, #0x2f              // =47
    e8e0:      	strb	w13, [x8, x12]
    e8e4:      	add	x19, x8, x12
    e8e8:      	cmp	w23, w21
    e8ec:      	add	x2, x9, x10
    e8f0:      	and	w1, w11, #0xff
    e8f4:      	mov	w8, #0x4                // =4
    e8f8:      	cinc	x0, x19, hi
    e8fc:      	blr	x8
    e900:      	cmp	w23, w21
    e904:      	str	x19, [sp, #0x60]
    e908:      	add	x19, sp, #0x70
    e90c:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    e910:      	ldr	x21, [sp, #0x78]
    e914:      	ldp	x2, x24, [sp, #0x50]
    e918:      	str	x21, [sp, #0x48]
    e91c:      	b	0xe96c <generic_fentry_path+0x44bc>
    e920:      	add	x2, x24, #0x10
    e924:      	mov	w8, #0x4                // =4
    e928:      	add	x9, sp, #0x98
    e92c:      	add	x0, sp, #0x98
    e930:      	mov	w1, #0x8                // =8
    e934:      	blr	x8
    e938:      	ldr	x8, [sp, #0x58]
    e93c:      	ldr	x9, [sp, #0x98]
    e940:      	cmp	x8, x9
    e944:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    e948:      	add	x2, x24, #0x18
    e94c:      	mov	w8, #0x4                // =4
    e950:      	mov	x0, x22
    e954:      	mov	w1, #0x8                // =8
    e958:      	blr	x8
    e95c:      	ldr	x24, [sp, #0x98]
    e960:      	ldr	x21, [sp, #0x48]
    e964:      	add	x2, x24, #0x20
    e968:      	stp	x2, x24, [sp, #0x50]
    e96c:      	ldr	x8, [sp, #0x30]
    e970:      	cmp	x21, x8
    e974:      	b.ne	0xe984 <generic_fentry_path+0x44d4>
    e978:      	ldr	x8, [sp, #0x38]
    e97c:      	cmp	x2, x8
    e980:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    e984:      	mov	w8, #0x4                // =4
    e988:      	add	x0, sp, #0x70
    e98c:      	mov	w1, #0x8                // =8
    e990:      	blr	x8
    e994:      	ldr	x8, [sp, #0x70]
    e998:      	cmp	x21, x8
    e99c:      	b.eq	0xea8c <generic_fentry_path+0x45dc>
    e9a0:      	add	x23, x21, #0x18
    e9a4:      	mov	w8, #0x4                // =4
    e9a8:      	add	x9, sp, #0x98
    e9ac:      	add	x0, sp, #0x98
    e9b0:      	mov	w1, #0x8                // =8
    e9b4:      	mov	x2, x23
    e9b8:      	blr	x8
    e9bc:      	ldr	x8, [sp, #0x98]
    e9c0:      	cmp	x8, x21
    e9c4:      	b.eq	0xea8c <generic_fentry_path+0x45dc>
    e9c8:      	mov	w8, #0x4                // =4
    e9cc:      	add	x9, sp, #0x78
    e9d0:      	add	x0, sp, #0x78
    e9d4:      	mov	w1, #0x8                // =8
    e9d8:      	mov	x2, x23
    e9dc:      	blr	x8
    e9e0:      	add	x2, x21, #0x20
    e9e4:      	mov	w8, #0x4                // =4
    e9e8:      	mov	w9, #0x10               // =16
    e9ec:      	add	x10, sp, #0x80
    e9f0:      	add	x0, sp, #0x80
    e9f4:      	mov	w1, #0x10               // =16
    e9f8:      	blr	x8
    e9fc:      	ldr	w21, [sp, #0x84]
    ea00:      	ldr	x8, [sp, #0x40]
    ea04:      	ldr	x10, [sp, #0x60]
    ea08:      	sub	x12, x10, x8
    ea0c:      	ldr	w23, [sp, #0x68]
    ea10:      	subs	w10, w21, w23
    ea14:      	ldr	x9, [sp, #0x88]
    ea18:      	csel	w10, wzr, w10, lo
    ea1c:      	cmp	w23, w21
    ea20:      	csel	w11, w23, w21, lo
    ea24:      	cinc	w13, w11, hi
    ea28:      	sub	w14, w23, w13
    ea2c:      	subs	x12, x12, x13
    ea30:      	str	w14, [sp, #0x68]
    ea34:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    ea38:      	cmp	x12, #0xfff
    ea3c:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    ea40:      	cmp	w23, w21
    ea44:      	b.ls	0xea50 <generic_fentry_path+0x45a0>
    ea48:      	mov	w13, #0x2f              // =47
    ea4c:      	strb	w13, [x8, x12]
    ea50:      	add	x19, x8, x12
    ea54:      	cmp	w23, w21
    ea58:      	add	x2, x9, x10
    ea5c:      	and	w1, w11, #0xff
    ea60:      	mov	w8, #0x4                // =4
    ea64:      	cinc	x0, x19, hi
    ea68:      	blr	x8
    ea6c:      	cmp	w23, w21
    ea70:      	str	x19, [sp, #0x60]
    ea74:      	add	x19, sp, #0x70
    ea78:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    ea7c:      	ldr	x21, [sp, #0x78]
    ea80:      	ldp	x2, x24, [sp, #0x50]
    ea84:      	str	x21, [sp, #0x48]
    ea88:      	b	0xead8 <generic_fentry_path+0x4628>
    ea8c:      	add	x2, x24, #0x10
    ea90:      	mov	w8, #0x4                // =4
    ea94:      	add	x9, sp, #0x98
    ea98:      	add	x0, sp, #0x98
    ea9c:      	mov	w1, #0x8                // =8
    eaa0:      	blr	x8
    eaa4:      	ldr	x8, [sp, #0x58]
    eaa8:      	ldr	x9, [sp, #0x98]
    eaac:      	cmp	x8, x9
    eab0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    eab4:      	add	x2, x24, #0x18
    eab8:      	mov	w8, #0x4                // =4
    eabc:      	mov	x0, x22
    eac0:      	mov	w1, #0x8                // =8
    eac4:      	blr	x8
    eac8:      	ldr	x24, [sp, #0x98]
    eacc:      	ldr	x21, [sp, #0x48]
    ead0:      	add	x2, x24, #0x20
    ead4:      	stp	x2, x24, [sp, #0x50]
    ead8:      	ldr	x8, [sp, #0x30]
    eadc:      	cmp	x21, x8
    eae0:      	b.ne	0xeaf0 <generic_fentry_path+0x4640>
    eae4:      	ldr	x8, [sp, #0x38]
    eae8:      	cmp	x2, x8
    eaec:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    eaf0:      	mov	w8, #0x4                // =4
    eaf4:      	add	x0, sp, #0x70
    eaf8:      	mov	w1, #0x8                // =8
    eafc:      	blr	x8
    eb00:      	ldr	x8, [sp, #0x70]
    eb04:      	cmp	x21, x8
    eb08:      	b.eq	0xebf8 <generic_fentry_path+0x4748>
    eb0c:      	add	x23, x21, #0x18
    eb10:      	mov	w8, #0x4                // =4
    eb14:      	add	x9, sp, #0x98
    eb18:      	add	x0, sp, #0x98
    eb1c:      	mov	w1, #0x8                // =8
    eb20:      	mov	x2, x23
    eb24:      	blr	x8
    eb28:      	ldr	x8, [sp, #0x98]
    eb2c:      	cmp	x8, x21
    eb30:      	b.eq	0xebf8 <generic_fentry_path+0x4748>
    eb34:      	mov	w8, #0x4                // =4
    eb38:      	add	x9, sp, #0x78
    eb3c:      	add	x0, sp, #0x78
    eb40:      	mov	w1, #0x8                // =8
    eb44:      	mov	x2, x23
    eb48:      	blr	x8
    eb4c:      	add	x2, x21, #0x20
    eb50:      	mov	w8, #0x4                // =4
    eb54:      	mov	w9, #0x10               // =16
    eb58:      	add	x10, sp, #0x80
    eb5c:      	add	x0, sp, #0x80
    eb60:      	mov	w1, #0x10               // =16
    eb64:      	blr	x8
    eb68:      	ldr	w21, [sp, #0x84]
    eb6c:      	ldr	x8, [sp, #0x40]
    eb70:      	ldr	x10, [sp, #0x60]
    eb74:      	sub	x12, x10, x8
    eb78:      	ldr	w23, [sp, #0x68]
    eb7c:      	subs	w10, w21, w23
    eb80:      	ldr	x9, [sp, #0x88]
    eb84:      	csel	w10, wzr, w10, lo
    eb88:      	cmp	w23, w21
    eb8c:      	csel	w11, w23, w21, lo
    eb90:      	cinc	w13, w11, hi
    eb94:      	sub	w14, w23, w13
    eb98:      	subs	x12, x12, x13
    eb9c:      	str	w14, [sp, #0x68]
    eba0:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    eba4:      	cmp	x12, #0xfff
    eba8:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    ebac:      	cmp	w23, w21
    ebb0:      	b.ls	0xebbc <generic_fentry_path+0x470c>
    ebb4:      	mov	w13, #0x2f              // =47
    ebb8:      	strb	w13, [x8, x12]
    ebbc:      	add	x19, x8, x12
    ebc0:      	cmp	w23, w21
    ebc4:      	add	x2, x9, x10
    ebc8:      	and	w1, w11, #0xff
    ebcc:      	mov	w8, #0x4                // =4
    ebd0:      	cinc	x0, x19, hi
    ebd4:      	blr	x8
    ebd8:      	cmp	w23, w21
    ebdc:      	str	x19, [sp, #0x60]
    ebe0:      	add	x19, sp, #0x70
    ebe4:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    ebe8:      	ldr	x21, [sp, #0x78]
    ebec:      	ldp	x2, x24, [sp, #0x50]
    ebf0:      	str	x21, [sp, #0x48]
    ebf4:      	b	0xec44 <generic_fentry_path+0x4794>
    ebf8:      	add	x2, x24, #0x10
    ebfc:      	mov	w8, #0x4                // =4
    ec00:      	add	x9, sp, #0x98
    ec04:      	add	x0, sp, #0x98
    ec08:      	mov	w1, #0x8                // =8
    ec0c:      	blr	x8
    ec10:      	ldr	x8, [sp, #0x58]
    ec14:      	ldr	x9, [sp, #0x98]
    ec18:      	cmp	x8, x9
    ec1c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    ec20:      	add	x2, x24, #0x18
    ec24:      	mov	w8, #0x4                // =4
    ec28:      	mov	x0, x22
    ec2c:      	mov	w1, #0x8                // =8
    ec30:      	blr	x8
    ec34:      	ldr	x24, [sp, #0x98]
    ec38:      	ldr	x21, [sp, #0x48]
    ec3c:      	add	x2, x24, #0x20
    ec40:      	stp	x2, x24, [sp, #0x50]
    ec44:      	ldr	x8, [sp, #0x30]
    ec48:      	cmp	x21, x8
    ec4c:      	b.ne	0xec5c <generic_fentry_path+0x47ac>
    ec50:      	ldr	x8, [sp, #0x38]
    ec54:      	cmp	x2, x8
    ec58:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    ec5c:      	mov	w8, #0x4                // =4
    ec60:      	add	x0, sp, #0x70
    ec64:      	mov	w1, #0x8                // =8
    ec68:      	blr	x8
    ec6c:      	ldr	x8, [sp, #0x70]
    ec70:      	cmp	x21, x8
    ec74:      	b.eq	0xed64 <generic_fentry_path+0x48b4>
    ec78:      	add	x23, x21, #0x18
    ec7c:      	mov	w8, #0x4                // =4
    ec80:      	add	x9, sp, #0x98
    ec84:      	add	x0, sp, #0x98
    ec88:      	mov	w1, #0x8                // =8
    ec8c:      	mov	x2, x23
    ec90:      	blr	x8
    ec94:      	ldr	x8, [sp, #0x98]
    ec98:      	cmp	x8, x21
    ec9c:      	b.eq	0xed64 <generic_fentry_path+0x48b4>
    eca0:      	mov	w8, #0x4                // =4
    eca4:      	add	x9, sp, #0x78
    eca8:      	add	x0, sp, #0x78
    ecac:      	mov	w1, #0x8                // =8
    ecb0:      	mov	x2, x23
    ecb4:      	blr	x8
    ecb8:      	add	x2, x21, #0x20
    ecbc:      	mov	w8, #0x4                // =4
    ecc0:      	mov	w9, #0x10               // =16
    ecc4:      	add	x10, sp, #0x80
    ecc8:      	add	x0, sp, #0x80
    eccc:      	mov	w1, #0x10               // =16
    ecd0:      	blr	x8
    ecd4:      	ldr	w21, [sp, #0x84]
    ecd8:      	ldr	x8, [sp, #0x40]
    ecdc:      	ldr	x10, [sp, #0x60]
    ece0:      	sub	x12, x10, x8
    ece4:      	ldr	w23, [sp, #0x68]
    ece8:      	subs	w10, w21, w23
    ecec:      	ldr	x9, [sp, #0x88]
    ecf0:      	csel	w10, wzr, w10, lo
    ecf4:      	cmp	w23, w21
    ecf8:      	csel	w11, w23, w21, lo
    ecfc:      	cinc	w13, w11, hi
    ed00:      	sub	w14, w23, w13
    ed04:      	subs	x12, x12, x13
    ed08:      	str	w14, [sp, #0x68]
    ed0c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    ed10:      	cmp	x12, #0xfff
    ed14:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    ed18:      	cmp	w23, w21
    ed1c:      	b.ls	0xed28 <generic_fentry_path+0x4878>
    ed20:      	mov	w13, #0x2f              // =47
    ed24:      	strb	w13, [x8, x12]
    ed28:      	add	x19, x8, x12
    ed2c:      	cmp	w23, w21
    ed30:      	add	x2, x9, x10
    ed34:      	and	w1, w11, #0xff
    ed38:      	mov	w8, #0x4                // =4
    ed3c:      	cinc	x0, x19, hi
    ed40:      	blr	x8
    ed44:      	cmp	w23, w21
    ed48:      	str	x19, [sp, #0x60]
    ed4c:      	add	x19, sp, #0x70
    ed50:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    ed54:      	ldr	x21, [sp, #0x78]
    ed58:      	ldp	x2, x24, [sp, #0x50]
    ed5c:      	str	x21, [sp, #0x48]
    ed60:      	b	0xedb0 <generic_fentry_path+0x4900>
    ed64:      	add	x2, x24, #0x10
    ed68:      	mov	w8, #0x4                // =4
    ed6c:      	add	x9, sp, #0x98
    ed70:      	add	x0, sp, #0x98
    ed74:      	mov	w1, #0x8                // =8
    ed78:      	blr	x8
    ed7c:      	ldr	x8, [sp, #0x58]
    ed80:      	ldr	x9, [sp, #0x98]
    ed84:      	cmp	x8, x9
    ed88:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    ed8c:      	add	x2, x24, #0x18
    ed90:      	mov	w8, #0x4                // =4
    ed94:      	mov	x0, x22
    ed98:      	mov	w1, #0x8                // =8
    ed9c:      	blr	x8
    eda0:      	ldr	x24, [sp, #0x98]
    eda4:      	ldr	x21, [sp, #0x48]
    eda8:      	add	x2, x24, #0x20
    edac:      	stp	x2, x24, [sp, #0x50]
    edb0:      	ldr	x8, [sp, #0x30]
    edb4:      	cmp	x21, x8
    edb8:      	b.ne	0xedc8 <generic_fentry_path+0x4918>
    edbc:      	ldr	x8, [sp, #0x38]
    edc0:      	cmp	x2, x8
    edc4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    edc8:      	mov	w8, #0x4                // =4
    edcc:      	add	x0, sp, #0x70
    edd0:      	mov	w1, #0x8                // =8
    edd4:      	blr	x8
    edd8:      	ldr	x8, [sp, #0x70]
    eddc:      	cmp	x21, x8
    ede0:      	b.eq	0xeed0 <generic_fentry_path+0x4a20>
    ede4:      	add	x23, x21, #0x18
    ede8:      	mov	w8, #0x4                // =4
    edec:      	add	x9, sp, #0x98
    edf0:      	add	x0, sp, #0x98
    edf4:      	mov	w1, #0x8                // =8
    edf8:      	mov	x2, x23
    edfc:      	blr	x8
    ee00:      	ldr	x8, [sp, #0x98]
    ee04:      	cmp	x8, x21
    ee08:      	b.eq	0xeed0 <generic_fentry_path+0x4a20>
    ee0c:      	mov	w8, #0x4                // =4
    ee10:      	add	x9, sp, #0x78
    ee14:      	add	x0, sp, #0x78
    ee18:      	mov	w1, #0x8                // =8
    ee1c:      	mov	x2, x23
    ee20:      	blr	x8
    ee24:      	add	x2, x21, #0x20
    ee28:      	mov	w8, #0x4                // =4
    ee2c:      	mov	w9, #0x10               // =16
    ee30:      	add	x10, sp, #0x80
    ee34:      	add	x0, sp, #0x80
    ee38:      	mov	w1, #0x10               // =16
    ee3c:      	blr	x8
    ee40:      	ldr	w21, [sp, #0x84]
    ee44:      	ldr	x8, [sp, #0x40]
    ee48:      	ldr	x10, [sp, #0x60]
    ee4c:      	sub	x12, x10, x8
    ee50:      	ldr	w23, [sp, #0x68]
    ee54:      	subs	w10, w21, w23
    ee58:      	ldr	x9, [sp, #0x88]
    ee5c:      	csel	w10, wzr, w10, lo
    ee60:      	cmp	w23, w21
    ee64:      	csel	w11, w23, w21, lo
    ee68:      	cinc	w13, w11, hi
    ee6c:      	sub	w14, w23, w13
    ee70:      	subs	x12, x12, x13
    ee74:      	str	w14, [sp, #0x68]
    ee78:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    ee7c:      	cmp	x12, #0xfff
    ee80:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    ee84:      	cmp	w23, w21
    ee88:      	b.ls	0xee94 <generic_fentry_path+0x49e4>
    ee8c:      	mov	w13, #0x2f              // =47
    ee90:      	strb	w13, [x8, x12]
    ee94:      	add	x19, x8, x12
    ee98:      	cmp	w23, w21
    ee9c:      	add	x2, x9, x10
    eea0:      	and	w1, w11, #0xff
    eea4:      	mov	w8, #0x4                // =4
    eea8:      	cinc	x0, x19, hi
    eeac:      	blr	x8
    eeb0:      	cmp	w23, w21
    eeb4:      	str	x19, [sp, #0x60]
    eeb8:      	add	x19, sp, #0x70
    eebc:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    eec0:      	ldr	x21, [sp, #0x78]
    eec4:      	ldp	x2, x24, [sp, #0x50]
    eec8:      	str	x21, [sp, #0x48]
    eecc:      	b	0xef1c <generic_fentry_path+0x4a6c>
    eed0:      	add	x2, x24, #0x10
    eed4:      	mov	w8, #0x4                // =4
    eed8:      	add	x9, sp, #0x98
    eedc:      	add	x0, sp, #0x98
    eee0:      	mov	w1, #0x8                // =8
    eee4:      	blr	x8
    eee8:      	ldr	x8, [sp, #0x58]
    eeec:      	ldr	x9, [sp, #0x98]
    eef0:      	cmp	x8, x9
    eef4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    eef8:      	add	x2, x24, #0x18
    eefc:      	mov	w8, #0x4                // =4
    ef00:      	mov	x0, x22
    ef04:      	mov	w1, #0x8                // =8
    ef08:      	blr	x8
    ef0c:      	ldr	x24, [sp, #0x98]
    ef10:      	ldr	x21, [sp, #0x48]
    ef14:      	add	x2, x24, #0x20
    ef18:      	stp	x2, x24, [sp, #0x50]
    ef1c:      	ldr	x8, [sp, #0x30]
    ef20:      	cmp	x21, x8
    ef24:      	b.ne	0xef34 <generic_fentry_path+0x4a84>
    ef28:      	ldr	x8, [sp, #0x38]
    ef2c:      	cmp	x2, x8
    ef30:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    ef34:      	mov	w8, #0x4                // =4
    ef38:      	add	x0, sp, #0x70
    ef3c:      	mov	w1, #0x8                // =8
    ef40:      	blr	x8
    ef44:      	ldr	x8, [sp, #0x70]
    ef48:      	cmp	x21, x8
    ef4c:      	b.eq	0xf03c <generic_fentry_path+0x4b8c>
    ef50:      	add	x23, x21, #0x18
    ef54:      	mov	w8, #0x4                // =4
    ef58:      	add	x9, sp, #0x98
    ef5c:      	add	x0, sp, #0x98
    ef60:      	mov	w1, #0x8                // =8
    ef64:      	mov	x2, x23
    ef68:      	blr	x8
    ef6c:      	ldr	x8, [sp, #0x98]
    ef70:      	cmp	x8, x21
    ef74:      	b.eq	0xf03c <generic_fentry_path+0x4b8c>
    ef78:      	mov	w8, #0x4                // =4
    ef7c:      	add	x9, sp, #0x78
    ef80:      	add	x0, sp, #0x78
    ef84:      	mov	w1, #0x8                // =8
    ef88:      	mov	x2, x23
    ef8c:      	blr	x8
    ef90:      	add	x2, x21, #0x20
    ef94:      	mov	w8, #0x4                // =4
    ef98:      	mov	w9, #0x10               // =16
    ef9c:      	add	x10, sp, #0x80
    efa0:      	add	x0, sp, #0x80
    efa4:      	mov	w1, #0x10               // =16
    efa8:      	blr	x8
    efac:      	ldr	w21, [sp, #0x84]
    efb0:      	ldr	x8, [sp, #0x40]
    efb4:      	ldr	x10, [sp, #0x60]
    efb8:      	sub	x12, x10, x8
    efbc:      	ldr	w23, [sp, #0x68]
    efc0:      	subs	w10, w21, w23
    efc4:      	ldr	x9, [sp, #0x88]
    efc8:      	csel	w10, wzr, w10, lo
    efcc:      	cmp	w23, w21
    efd0:      	csel	w11, w23, w21, lo
    efd4:      	cinc	w13, w11, hi
    efd8:      	sub	w14, w23, w13
    efdc:      	subs	x12, x12, x13
    efe0:      	str	w14, [sp, #0x68]
    efe4:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    efe8:      	cmp	x12, #0xfff
    efec:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    eff0:      	cmp	w23, w21
    eff4:      	b.ls	0xf000 <generic_fentry_path+0x4b50>
    eff8:      	mov	w13, #0x2f              // =47
    effc:      	strb	w13, [x8, x12]
    f000:      	add	x19, x8, x12
    f004:      	cmp	w23, w21
    f008:      	add	x2, x9, x10
    f00c:      	and	w1, w11, #0xff
    f010:      	mov	w8, #0x4                // =4
    f014:      	cinc	x0, x19, hi
    f018:      	blr	x8
    f01c:      	cmp	w23, w21
    f020:      	str	x19, [sp, #0x60]
    f024:      	add	x19, sp, #0x70
    f028:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    f02c:      	ldr	x21, [sp, #0x78]
    f030:      	ldp	x2, x24, [sp, #0x50]
    f034:      	str	x21, [sp, #0x48]
    f038:      	b	0xf088 <generic_fentry_path+0x4bd8>
    f03c:      	add	x2, x24, #0x10
    f040:      	mov	w8, #0x4                // =4
    f044:      	add	x9, sp, #0x98
    f048:      	add	x0, sp, #0x98
    f04c:      	mov	w1, #0x8                // =8
    f050:      	blr	x8
    f054:      	ldr	x8, [sp, #0x58]
    f058:      	ldr	x9, [sp, #0x98]
    f05c:      	cmp	x8, x9
    f060:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    f064:      	add	x2, x24, #0x18
    f068:      	mov	w8, #0x4                // =4
    f06c:      	mov	x0, x22
    f070:      	mov	w1, #0x8                // =8
    f074:      	blr	x8
    f078:      	ldr	x24, [sp, #0x98]
    f07c:      	ldr	x21, [sp, #0x48]
    f080:      	add	x2, x24, #0x20
    f084:      	stp	x2, x24, [sp, #0x50]
    f088:      	ldr	x8, [sp, #0x30]
    f08c:      	cmp	x21, x8
    f090:      	b.ne	0xf0a0 <generic_fentry_path+0x4bf0>
    f094:      	ldr	x8, [sp, #0x38]
    f098:      	cmp	x2, x8
    f09c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    f0a0:      	mov	w8, #0x4                // =4
    f0a4:      	add	x0, sp, #0x70
    f0a8:      	mov	w1, #0x8                // =8
    f0ac:      	blr	x8
    f0b0:      	ldr	x8, [sp, #0x70]
    f0b4:      	cmp	x21, x8
    f0b8:      	b.eq	0xf1a8 <generic_fentry_path+0x4cf8>
    f0bc:      	add	x23, x21, #0x18
    f0c0:      	mov	w8, #0x4                // =4
    f0c4:      	add	x9, sp, #0x98
    f0c8:      	add	x0, sp, #0x98
    f0cc:      	mov	w1, #0x8                // =8
    f0d0:      	mov	x2, x23
    f0d4:      	blr	x8
    f0d8:      	ldr	x8, [sp, #0x98]
    f0dc:      	cmp	x8, x21
    f0e0:      	b.eq	0xf1a8 <generic_fentry_path+0x4cf8>
    f0e4:      	mov	w8, #0x4                // =4
    f0e8:      	add	x9, sp, #0x78
    f0ec:      	add	x0, sp, #0x78
    f0f0:      	mov	w1, #0x8                // =8
    f0f4:      	mov	x2, x23
    f0f8:      	blr	x8
    f0fc:      	add	x2, x21, #0x20
    f100:      	mov	w8, #0x4                // =4
    f104:      	mov	w9, #0x10               // =16
    f108:      	add	x10, sp, #0x80
    f10c:      	add	x0, sp, #0x80
    f110:      	mov	w1, #0x10               // =16
    f114:      	blr	x8
    f118:      	ldr	w21, [sp, #0x84]
    f11c:      	ldr	x8, [sp, #0x40]
    f120:      	ldr	x10, [sp, #0x60]
    f124:      	sub	x12, x10, x8
    f128:      	ldr	w23, [sp, #0x68]
    f12c:      	subs	w10, w21, w23
    f130:      	ldr	x9, [sp, #0x88]
    f134:      	csel	w10, wzr, w10, lo
    f138:      	cmp	w23, w21
    f13c:      	csel	w11, w23, w21, lo
    f140:      	cinc	w13, w11, hi
    f144:      	sub	w14, w23, w13
    f148:      	subs	x12, x12, x13
    f14c:      	str	w14, [sp, #0x68]
    f150:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    f154:      	cmp	x12, #0xfff
    f158:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    f15c:      	cmp	w23, w21
    f160:      	b.ls	0xf16c <generic_fentry_path+0x4cbc>
    f164:      	mov	w13, #0x2f              // =47
    f168:      	strb	w13, [x8, x12]
    f16c:      	add	x19, x8, x12
    f170:      	cmp	w23, w21
    f174:      	add	x2, x9, x10
    f178:      	and	w1, w11, #0xff
    f17c:      	mov	w8, #0x4                // =4
    f180:      	cinc	x0, x19, hi
    f184:      	blr	x8
    f188:      	cmp	w23, w21
    f18c:      	str	x19, [sp, #0x60]
    f190:      	add	x19, sp, #0x70
    f194:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    f198:      	ldr	x21, [sp, #0x78]
    f19c:      	ldp	x2, x24, [sp, #0x50]
    f1a0:      	str	x21, [sp, #0x48]
    f1a4:      	b	0xf1f4 <generic_fentry_path+0x4d44>
    f1a8:      	add	x2, x24, #0x10
    f1ac:      	mov	w8, #0x4                // =4
    f1b0:      	add	x9, sp, #0x98
    f1b4:      	add	x0, sp, #0x98
    f1b8:      	mov	w1, #0x8                // =8
    f1bc:      	blr	x8
    f1c0:      	ldr	x8, [sp, #0x58]
    f1c4:      	ldr	x9, [sp, #0x98]
    f1c8:      	cmp	x8, x9
    f1cc:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    f1d0:      	add	x2, x24, #0x18
    f1d4:      	mov	w8, #0x4                // =4
    f1d8:      	mov	x0, x22
    f1dc:      	mov	w1, #0x8                // =8
    f1e0:      	blr	x8
    f1e4:      	ldr	x24, [sp, #0x98]
    f1e8:      	ldr	x21, [sp, #0x48]
    f1ec:      	add	x2, x24, #0x20
    f1f0:      	stp	x2, x24, [sp, #0x50]
    f1f4:      	ldr	x8, [sp, #0x30]
    f1f8:      	cmp	x21, x8
    f1fc:      	b.ne	0xf20c <generic_fentry_path+0x4d5c>
    f200:      	ldr	x8, [sp, #0x38]
    f204:      	cmp	x2, x8
    f208:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    f20c:      	mov	w8, #0x4                // =4
    f210:      	add	x0, sp, #0x70
    f214:      	mov	w1, #0x8                // =8
    f218:      	blr	x8
    f21c:      	ldr	x8, [sp, #0x70]
    f220:      	cmp	x21, x8
    f224:      	b.eq	0xf314 <generic_fentry_path+0x4e64>
    f228:      	add	x23, x21, #0x18
    f22c:      	mov	w8, #0x4                // =4
    f230:      	add	x9, sp, #0x98
    f234:      	add	x0, sp, #0x98
    f238:      	mov	w1, #0x8                // =8
    f23c:      	mov	x2, x23
    f240:      	blr	x8
    f244:      	ldr	x8, [sp, #0x98]
    f248:      	cmp	x8, x21
    f24c:      	b.eq	0xf314 <generic_fentry_path+0x4e64>
    f250:      	mov	w8, #0x4                // =4
    f254:      	add	x9, sp, #0x78
    f258:      	add	x0, sp, #0x78
    f25c:      	mov	w1, #0x8                // =8
    f260:      	mov	x2, x23
    f264:      	blr	x8
    f268:      	add	x2, x21, #0x20
    f26c:      	mov	w8, #0x4                // =4
    f270:      	mov	w9, #0x10               // =16
    f274:      	add	x10, sp, #0x80
    f278:      	add	x0, sp, #0x80
    f27c:      	mov	w1, #0x10               // =16
    f280:      	blr	x8
    f284:      	ldr	w21, [sp, #0x84]
    f288:      	ldr	x8, [sp, #0x40]
    f28c:      	ldr	x10, [sp, #0x60]
    f290:      	sub	x12, x10, x8
    f294:      	ldr	w23, [sp, #0x68]
    f298:      	subs	w10, w21, w23
    f29c:      	ldr	x9, [sp, #0x88]
    f2a0:      	csel	w10, wzr, w10, lo
    f2a4:      	cmp	w23, w21
    f2a8:      	csel	w11, w23, w21, lo
    f2ac:      	cinc	w13, w11, hi
    f2b0:      	sub	w14, w23, w13
    f2b4:      	subs	x12, x12, x13
    f2b8:      	str	w14, [sp, #0x68]
    f2bc:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    f2c0:      	cmp	x12, #0xfff
    f2c4:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    f2c8:      	cmp	w23, w21
    f2cc:      	b.ls	0xf2d8 <generic_fentry_path+0x4e28>
    f2d0:      	mov	w13, #0x2f              // =47
    f2d4:      	strb	w13, [x8, x12]
    f2d8:      	add	x19, x8, x12
    f2dc:      	cmp	w23, w21
    f2e0:      	add	x2, x9, x10
    f2e4:      	and	w1, w11, #0xff
    f2e8:      	mov	w8, #0x4                // =4
    f2ec:      	cinc	x0, x19, hi
    f2f0:      	blr	x8
    f2f4:      	cmp	w23, w21
    f2f8:      	str	x19, [sp, #0x60]
    f2fc:      	add	x19, sp, #0x70
    f300:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    f304:      	ldr	x21, [sp, #0x78]
    f308:      	ldp	x2, x24, [sp, #0x50]
    f30c:      	str	x21, [sp, #0x48]
    f310:      	b	0xf360 <generic_fentry_path+0x4eb0>
    f314:      	add	x2, x24, #0x10
    f318:      	mov	w8, #0x4                // =4
    f31c:      	add	x9, sp, #0x98
    f320:      	add	x0, sp, #0x98
    f324:      	mov	w1, #0x8                // =8
    f328:      	blr	x8
    f32c:      	ldr	x8, [sp, #0x58]
    f330:      	ldr	x9, [sp, #0x98]
    f334:      	cmp	x8, x9
    f338:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    f33c:      	add	x2, x24, #0x18
    f340:      	mov	w8, #0x4                // =4
    f344:      	mov	x0, x22
    f348:      	mov	w1, #0x8                // =8
    f34c:      	blr	x8
    f350:      	ldr	x24, [sp, #0x98]
    f354:      	ldr	x21, [sp, #0x48]
    f358:      	add	x2, x24, #0x20
    f35c:      	stp	x2, x24, [sp, #0x50]
    f360:      	ldr	x8, [sp, #0x30]
    f364:      	cmp	x21, x8
    f368:      	b.ne	0xf378 <generic_fentry_path+0x4ec8>
    f36c:      	ldr	x8, [sp, #0x38]
    f370:      	cmp	x2, x8
    f374:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    f378:      	mov	w8, #0x4                // =4
    f37c:      	add	x0, sp, #0x70
    f380:      	mov	w1, #0x8                // =8
    f384:      	blr	x8
    f388:      	ldr	x8, [sp, #0x70]
    f38c:      	cmp	x21, x8
    f390:      	b.eq	0xf480 <generic_fentry_path+0x4fd0>
    f394:      	add	x23, x21, #0x18
    f398:      	mov	w8, #0x4                // =4
    f39c:      	add	x9, sp, #0x98
    f3a0:      	add	x0, sp, #0x98
    f3a4:      	mov	w1, #0x8                // =8
    f3a8:      	mov	x2, x23
    f3ac:      	blr	x8
    f3b0:      	ldr	x8, [sp, #0x98]
    f3b4:      	cmp	x8, x21
    f3b8:      	b.eq	0xf480 <generic_fentry_path+0x4fd0>
    f3bc:      	mov	w8, #0x4                // =4
    f3c0:      	add	x9, sp, #0x78
    f3c4:      	add	x0, sp, #0x78
    f3c8:      	mov	w1, #0x8                // =8
    f3cc:      	mov	x2, x23
    f3d0:      	blr	x8
    f3d4:      	add	x2, x21, #0x20
    f3d8:      	mov	w8, #0x4                // =4
    f3dc:      	mov	w9, #0x10               // =16
    f3e0:      	add	x10, sp, #0x80
    f3e4:      	add	x0, sp, #0x80
    f3e8:      	mov	w1, #0x10               // =16
    f3ec:      	blr	x8
    f3f0:      	ldr	w21, [sp, #0x84]
    f3f4:      	ldr	x8, [sp, #0x40]
    f3f8:      	ldr	x10, [sp, #0x60]
    f3fc:      	sub	x12, x10, x8
    f400:      	ldr	w23, [sp, #0x68]
    f404:      	subs	w10, w21, w23
    f408:      	ldr	x9, [sp, #0x88]
    f40c:      	csel	w10, wzr, w10, lo
    f410:      	cmp	w23, w21
    f414:      	csel	w11, w23, w21, lo
    f418:      	cinc	w13, w11, hi
    f41c:      	sub	w14, w23, w13
    f420:      	subs	x12, x12, x13
    f424:      	str	w14, [sp, #0x68]
    f428:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    f42c:      	cmp	x12, #0xfff
    f430:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    f434:      	cmp	w23, w21
    f438:      	b.ls	0xf444 <generic_fentry_path+0x4f94>
    f43c:      	mov	w13, #0x2f              // =47
    f440:      	strb	w13, [x8, x12]
    f444:      	add	x19, x8, x12
    f448:      	cmp	w23, w21
    f44c:      	add	x2, x9, x10
    f450:      	and	w1, w11, #0xff
    f454:      	mov	w8, #0x4                // =4
    f458:      	cinc	x0, x19, hi
    f45c:      	blr	x8
    f460:      	cmp	w23, w21
    f464:      	str	x19, [sp, #0x60]
    f468:      	add	x19, sp, #0x70
    f46c:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    f470:      	ldr	x21, [sp, #0x78]
    f474:      	ldp	x2, x24, [sp, #0x50]
    f478:      	str	x21, [sp, #0x48]
    f47c:      	b	0xf4cc <generic_fentry_path+0x501c>
    f480:      	add	x2, x24, #0x10
    f484:      	mov	w8, #0x4                // =4
    f488:      	add	x9, sp, #0x98
    f48c:      	add	x0, sp, #0x98
    f490:      	mov	w1, #0x8                // =8
    f494:      	blr	x8
    f498:      	ldr	x8, [sp, #0x58]
    f49c:      	ldr	x9, [sp, #0x98]
    f4a0:      	cmp	x8, x9
    f4a4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    f4a8:      	add	x2, x24, #0x18
    f4ac:      	mov	w8, #0x4                // =4
    f4b0:      	mov	x0, x22
    f4b4:      	mov	w1, #0x8                // =8
    f4b8:      	blr	x8
    f4bc:      	ldr	x24, [sp, #0x98]
    f4c0:      	ldr	x21, [sp, #0x48]
    f4c4:      	add	x2, x24, #0x20
    f4c8:      	stp	x2, x24, [sp, #0x50]
    f4cc:      	ldr	x8, [sp, #0x30]
    f4d0:      	cmp	x21, x8
    f4d4:      	b.ne	0xf4e4 <generic_fentry_path+0x5034>
    f4d8:      	ldr	x8, [sp, #0x38]
    f4dc:      	cmp	x2, x8
    f4e0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    f4e4:      	mov	w8, #0x4                // =4
    f4e8:      	add	x0, sp, #0x70
    f4ec:      	mov	w1, #0x8                // =8
    f4f0:      	blr	x8
    f4f4:      	ldr	x8, [sp, #0x70]
    f4f8:      	cmp	x21, x8
    f4fc:      	b.eq	0xf5ec <generic_fentry_path+0x513c>
    f500:      	add	x23, x21, #0x18
    f504:      	mov	w8, #0x4                // =4
    f508:      	add	x9, sp, #0x98
    f50c:      	add	x0, sp, #0x98
    f510:      	mov	w1, #0x8                // =8
    f514:      	mov	x2, x23
    f518:      	blr	x8
    f51c:      	ldr	x8, [sp, #0x98]
    f520:      	cmp	x8, x21
    f524:      	b.eq	0xf5ec <generic_fentry_path+0x513c>
    f528:      	mov	w8, #0x4                // =4
    f52c:      	add	x9, sp, #0x78
    f530:      	add	x0, sp, #0x78
    f534:      	mov	w1, #0x8                // =8
    f538:      	mov	x2, x23
    f53c:      	blr	x8
    f540:      	add	x2, x21, #0x20
    f544:      	mov	w8, #0x4                // =4
    f548:      	mov	w9, #0x10               // =16
    f54c:      	add	x10, sp, #0x80
    f550:      	add	x0, sp, #0x80
    f554:      	mov	w1, #0x10               // =16
    f558:      	blr	x8
    f55c:      	ldr	w21, [sp, #0x84]
    f560:      	ldr	x8, [sp, #0x40]
    f564:      	ldr	x10, [sp, #0x60]
    f568:      	sub	x12, x10, x8
    f56c:      	ldr	w23, [sp, #0x68]
    f570:      	subs	w10, w21, w23
    f574:      	ldr	x9, [sp, #0x88]
    f578:      	csel	w10, wzr, w10, lo
    f57c:      	cmp	w23, w21
    f580:      	csel	w11, w23, w21, lo
    f584:      	cinc	w13, w11, hi
    f588:      	sub	w14, w23, w13
    f58c:      	subs	x12, x12, x13
    f590:      	str	w14, [sp, #0x68]
    f594:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    f598:      	cmp	x12, #0xfff
    f59c:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    f5a0:      	cmp	w23, w21
    f5a4:      	b.ls	0xf5b0 <generic_fentry_path+0x5100>
    f5a8:      	mov	w13, #0x2f              // =47
    f5ac:      	strb	w13, [x8, x12]
    f5b0:      	add	x19, x8, x12
    f5b4:      	cmp	w23, w21
    f5b8:      	add	x2, x9, x10
    f5bc:      	and	w1, w11, #0xff
    f5c0:      	mov	w8, #0x4                // =4
    f5c4:      	cinc	x0, x19, hi
    f5c8:      	blr	x8
    f5cc:      	cmp	w23, w21
    f5d0:      	str	x19, [sp, #0x60]
    f5d4:      	add	x19, sp, #0x70
    f5d8:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    f5dc:      	ldr	x21, [sp, #0x78]
    f5e0:      	ldp	x2, x24, [sp, #0x50]
    f5e4:      	str	x21, [sp, #0x48]
    f5e8:      	b	0xf638 <generic_fentry_path+0x5188>
    f5ec:      	add	x2, x24, #0x10
    f5f0:      	mov	w8, #0x4                // =4
    f5f4:      	add	x9, sp, #0x98
    f5f8:      	add	x0, sp, #0x98
    f5fc:      	mov	w1, #0x8                // =8
    f600:      	blr	x8
    f604:      	ldr	x8, [sp, #0x58]
    f608:      	ldr	x9, [sp, #0x98]
    f60c:      	cmp	x8, x9
    f610:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    f614:      	add	x2, x24, #0x18
    f618:      	mov	w8, #0x4                // =4
    f61c:      	mov	x0, x22
    f620:      	mov	w1, #0x8                // =8
    f624:      	blr	x8
    f628:      	ldr	x24, [sp, #0x98]
    f62c:      	ldr	x21, [sp, #0x48]
    f630:      	add	x2, x24, #0x20
    f634:      	stp	x2, x24, [sp, #0x50]
    f638:      	ldr	x8, [sp, #0x30]
    f63c:      	cmp	x21, x8
    f640:      	b.ne	0xf650 <generic_fentry_path+0x51a0>
    f644:      	ldr	x8, [sp, #0x38]
    f648:      	cmp	x2, x8
    f64c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    f650:      	mov	w8, #0x4                // =4
    f654:      	add	x0, sp, #0x70
    f658:      	mov	w1, #0x8                // =8
    f65c:      	blr	x8
    f660:      	ldr	x8, [sp, #0x70]
    f664:      	cmp	x21, x8
    f668:      	b.eq	0xf758 <generic_fentry_path+0x52a8>
    f66c:      	add	x23, x21, #0x18
    f670:      	mov	w8, #0x4                // =4
    f674:      	add	x9, sp, #0x98
    f678:      	add	x0, sp, #0x98
    f67c:      	mov	w1, #0x8                // =8
    f680:      	mov	x2, x23
    f684:      	blr	x8
    f688:      	ldr	x8, [sp, #0x98]
    f68c:      	cmp	x8, x21
    f690:      	b.eq	0xf758 <generic_fentry_path+0x52a8>
    f694:      	mov	w8, #0x4                // =4
    f698:      	add	x9, sp, #0x78
    f69c:      	add	x0, sp, #0x78
    f6a0:      	mov	w1, #0x8                // =8
    f6a4:      	mov	x2, x23
    f6a8:      	blr	x8
    f6ac:      	add	x2, x21, #0x20
    f6b0:      	mov	w8, #0x4                // =4
    f6b4:      	mov	w9, #0x10               // =16
    f6b8:      	add	x10, sp, #0x80
    f6bc:      	add	x0, sp, #0x80
    f6c0:      	mov	w1, #0x10               // =16
    f6c4:      	blr	x8
    f6c8:      	ldr	w21, [sp, #0x84]
    f6cc:      	ldr	x8, [sp, #0x40]
    f6d0:      	ldr	x10, [sp, #0x60]
    f6d4:      	sub	x12, x10, x8
    f6d8:      	ldr	w23, [sp, #0x68]
    f6dc:      	subs	w10, w21, w23
    f6e0:      	ldr	x9, [sp, #0x88]
    f6e4:      	csel	w10, wzr, w10, lo
    f6e8:      	cmp	w23, w21
    f6ec:      	csel	w11, w23, w21, lo
    f6f0:      	cinc	w13, w11, hi
    f6f4:      	sub	w14, w23, w13
    f6f8:      	subs	x12, x12, x13
    f6fc:      	str	w14, [sp, #0x68]
    f700:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    f704:      	cmp	x12, #0xfff
    f708:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    f70c:      	cmp	w23, w21
    f710:      	b.ls	0xf71c <generic_fentry_path+0x526c>
    f714:      	mov	w13, #0x2f              // =47
    f718:      	strb	w13, [x8, x12]
    f71c:      	add	x19, x8, x12
    f720:      	cmp	w23, w21
    f724:      	add	x2, x9, x10
    f728:      	and	w1, w11, #0xff
    f72c:      	mov	w8, #0x4                // =4
    f730:      	cinc	x0, x19, hi
    f734:      	blr	x8
    f738:      	cmp	w23, w21
    f73c:      	str	x19, [sp, #0x60]
    f740:      	add	x19, sp, #0x70
    f744:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    f748:      	ldr	x21, [sp, #0x78]
    f74c:      	ldp	x2, x24, [sp, #0x50]
    f750:      	str	x21, [sp, #0x48]
    f754:      	b	0xf7a4 <generic_fentry_path+0x52f4>
    f758:      	add	x2, x24, #0x10
    f75c:      	mov	w8, #0x4                // =4
    f760:      	add	x9, sp, #0x98
    f764:      	add	x0, sp, #0x98
    f768:      	mov	w1, #0x8                // =8
    f76c:      	blr	x8
    f770:      	ldr	x8, [sp, #0x58]
    f774:      	ldr	x9, [sp, #0x98]
    f778:      	cmp	x8, x9
    f77c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    f780:      	add	x2, x24, #0x18
    f784:      	mov	w8, #0x4                // =4
    f788:      	mov	x0, x22
    f78c:      	mov	w1, #0x8                // =8
    f790:      	blr	x8
    f794:      	ldr	x24, [sp, #0x98]
    f798:      	ldr	x21, [sp, #0x48]
    f79c:      	add	x2, x24, #0x20
    f7a0:      	stp	x2, x24, [sp, #0x50]
    f7a4:      	ldr	x8, [sp, #0x30]
    f7a8:      	cmp	x21, x8
    f7ac:      	b.ne	0xf7bc <generic_fentry_path+0x530c>
    f7b0:      	ldr	x8, [sp, #0x38]
    f7b4:      	cmp	x2, x8
    f7b8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    f7bc:      	mov	w8, #0x4                // =4
    f7c0:      	add	x0, sp, #0x70
    f7c4:      	mov	w1, #0x8                // =8
    f7c8:      	blr	x8
    f7cc:      	ldr	x8, [sp, #0x70]
    f7d0:      	cmp	x21, x8
    f7d4:      	b.eq	0xf8c4 <generic_fentry_path+0x5414>
    f7d8:      	add	x23, x21, #0x18
    f7dc:      	mov	w8, #0x4                // =4
    f7e0:      	add	x9, sp, #0x98
    f7e4:      	add	x0, sp, #0x98
    f7e8:      	mov	w1, #0x8                // =8
    f7ec:      	mov	x2, x23
    f7f0:      	blr	x8
    f7f4:      	ldr	x8, [sp, #0x98]
    f7f8:      	cmp	x8, x21
    f7fc:      	b.eq	0xf8c4 <generic_fentry_path+0x5414>
    f800:      	mov	w8, #0x4                // =4
    f804:      	add	x9, sp, #0x78
    f808:      	add	x0, sp, #0x78
    f80c:      	mov	w1, #0x8                // =8
    f810:      	mov	x2, x23
    f814:      	blr	x8
    f818:      	add	x2, x21, #0x20
    f81c:      	mov	w8, #0x4                // =4
    f820:      	mov	w9, #0x10               // =16
    f824:      	add	x10, sp, #0x80
    f828:      	add	x0, sp, #0x80
    f82c:      	mov	w1, #0x10               // =16
    f830:      	blr	x8
    f834:      	ldr	w21, [sp, #0x84]
    f838:      	ldr	x8, [sp, #0x40]
    f83c:      	ldr	x10, [sp, #0x60]
    f840:      	sub	x12, x10, x8
    f844:      	ldr	w23, [sp, #0x68]
    f848:      	subs	w10, w21, w23
    f84c:      	ldr	x9, [sp, #0x88]
    f850:      	csel	w10, wzr, w10, lo
    f854:      	cmp	w23, w21
    f858:      	csel	w11, w23, w21, lo
    f85c:      	cinc	w13, w11, hi
    f860:      	sub	w14, w23, w13
    f864:      	subs	x12, x12, x13
    f868:      	str	w14, [sp, #0x68]
    f86c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    f870:      	cmp	x12, #0xfff
    f874:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    f878:      	cmp	w23, w21
    f87c:      	b.ls	0xf888 <generic_fentry_path+0x53d8>
    f880:      	mov	w13, #0x2f              // =47
    f884:      	strb	w13, [x8, x12]
    f888:      	add	x19, x8, x12
    f88c:      	cmp	w23, w21
    f890:      	add	x2, x9, x10
    f894:      	and	w1, w11, #0xff
    f898:      	mov	w8, #0x4                // =4
    f89c:      	cinc	x0, x19, hi
    f8a0:      	blr	x8
    f8a4:      	cmp	w23, w21
    f8a8:      	str	x19, [sp, #0x60]
    f8ac:      	add	x19, sp, #0x70
    f8b0:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    f8b4:      	ldr	x21, [sp, #0x78]
    f8b8:      	ldp	x2, x24, [sp, #0x50]
    f8bc:      	str	x21, [sp, #0x48]
    f8c0:      	b	0xf910 <generic_fentry_path+0x5460>
    f8c4:      	add	x2, x24, #0x10
    f8c8:      	mov	w8, #0x4                // =4
    f8cc:      	add	x9, sp, #0x98
    f8d0:      	add	x0, sp, #0x98
    f8d4:      	mov	w1, #0x8                // =8
    f8d8:      	blr	x8
    f8dc:      	ldr	x8, [sp, #0x58]
    f8e0:      	ldr	x9, [sp, #0x98]
    f8e4:      	cmp	x8, x9
    f8e8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    f8ec:      	add	x2, x24, #0x18
    f8f0:      	mov	w8, #0x4                // =4
    f8f4:      	mov	x0, x22
    f8f8:      	mov	w1, #0x8                // =8
    f8fc:      	blr	x8
    f900:      	ldr	x24, [sp, #0x98]
    f904:      	ldr	x21, [sp, #0x48]
    f908:      	add	x2, x24, #0x20
    f90c:      	stp	x2, x24, [sp, #0x50]
    f910:      	ldr	x8, [sp, #0x30]
    f914:      	cmp	x21, x8
    f918:      	b.ne	0xf928 <generic_fentry_path+0x5478>
    f91c:      	ldr	x8, [sp, #0x38]
    f920:      	cmp	x2, x8
    f924:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    f928:      	mov	w8, #0x4                // =4
    f92c:      	add	x0, sp, #0x70
    f930:      	mov	w1, #0x8                // =8
    f934:      	blr	x8
    f938:      	ldr	x8, [sp, #0x70]
    f93c:      	cmp	x21, x8
    f940:      	b.eq	0xfa30 <generic_fentry_path+0x5580>
    f944:      	add	x23, x21, #0x18
    f948:      	mov	w8, #0x4                // =4
    f94c:      	add	x9, sp, #0x98
    f950:      	add	x0, sp, #0x98
    f954:      	mov	w1, #0x8                // =8
    f958:      	mov	x2, x23
    f95c:      	blr	x8
    f960:      	ldr	x8, [sp, #0x98]
    f964:      	cmp	x8, x21
    f968:      	b.eq	0xfa30 <generic_fentry_path+0x5580>
    f96c:      	mov	w8, #0x4                // =4
    f970:      	add	x9, sp, #0x78
    f974:      	add	x0, sp, #0x78
    f978:      	mov	w1, #0x8                // =8
    f97c:      	mov	x2, x23
    f980:      	blr	x8
    f984:      	add	x2, x21, #0x20
    f988:      	mov	w8, #0x4                // =4
    f98c:      	mov	w9, #0x10               // =16
    f990:      	add	x10, sp, #0x80
    f994:      	add	x0, sp, #0x80
    f998:      	mov	w1, #0x10               // =16
    f99c:      	blr	x8
    f9a0:      	ldr	w21, [sp, #0x84]
    f9a4:      	ldr	x8, [sp, #0x40]
    f9a8:      	ldr	x10, [sp, #0x60]
    f9ac:      	sub	x12, x10, x8
    f9b0:      	ldr	w23, [sp, #0x68]
    f9b4:      	subs	w10, w21, w23
    f9b8:      	ldr	x9, [sp, #0x88]
    f9bc:      	csel	w10, wzr, w10, lo
    f9c0:      	cmp	w23, w21
    f9c4:      	csel	w11, w23, w21, lo
    f9c8:      	cinc	w13, w11, hi
    f9cc:      	sub	w14, w23, w13
    f9d0:      	subs	x12, x12, x13
    f9d4:      	str	w14, [sp, #0x68]
    f9d8:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    f9dc:      	cmp	x12, #0xfff
    f9e0:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    f9e4:      	cmp	w23, w21
    f9e8:      	b.ls	0xf9f4 <generic_fentry_path+0x5544>
    f9ec:      	mov	w13, #0x2f              // =47
    f9f0:      	strb	w13, [x8, x12]
    f9f4:      	add	x19, x8, x12
    f9f8:      	cmp	w23, w21
    f9fc:      	add	x2, x9, x10
    fa00:      	and	w1, w11, #0xff
    fa04:      	mov	w8, #0x4                // =4
    fa08:      	cinc	x0, x19, hi
    fa0c:      	blr	x8
    fa10:      	cmp	w23, w21
    fa14:      	str	x19, [sp, #0x60]
    fa18:      	add	x19, sp, #0x70
    fa1c:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    fa20:      	ldr	x21, [sp, #0x78]
    fa24:      	ldp	x2, x24, [sp, #0x50]
    fa28:      	str	x21, [sp, #0x48]
    fa2c:      	b	0xfa7c <generic_fentry_path+0x55cc>
    fa30:      	add	x2, x24, #0x10
    fa34:      	mov	w8, #0x4                // =4
    fa38:      	add	x9, sp, #0x98
    fa3c:      	add	x0, sp, #0x98
    fa40:      	mov	w1, #0x8                // =8
    fa44:      	blr	x8
    fa48:      	ldr	x8, [sp, #0x58]
    fa4c:      	ldr	x9, [sp, #0x98]
    fa50:      	cmp	x8, x9
    fa54:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    fa58:      	add	x2, x24, #0x18
    fa5c:      	mov	w8, #0x4                // =4
    fa60:      	mov	x0, x22
    fa64:      	mov	w1, #0x8                // =8
    fa68:      	blr	x8
    fa6c:      	ldr	x24, [sp, #0x98]
    fa70:      	ldr	x21, [sp, #0x48]
    fa74:      	add	x2, x24, #0x20
    fa78:      	stp	x2, x24, [sp, #0x50]
    fa7c:      	ldr	x8, [sp, #0x30]
    fa80:      	cmp	x21, x8
    fa84:      	b.ne	0xfa94 <generic_fentry_path+0x55e4>
    fa88:      	ldr	x8, [sp, #0x38]
    fa8c:      	cmp	x2, x8
    fa90:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    fa94:      	mov	w8, #0x4                // =4
    fa98:      	add	x0, sp, #0x70
    fa9c:      	mov	w1, #0x8                // =8
    faa0:      	blr	x8
    faa4:      	ldr	x8, [sp, #0x70]
    faa8:      	cmp	x21, x8
    faac:      	b.eq	0xfb9c <generic_fentry_path+0x56ec>
    fab0:      	add	x23, x21, #0x18
    fab4:      	mov	w8, #0x4                // =4
    fab8:      	add	x9, sp, #0x98
    fabc:      	add	x0, sp, #0x98
    fac0:      	mov	w1, #0x8                // =8
    fac4:      	mov	x2, x23
    fac8:      	blr	x8
    facc:      	ldr	x8, [sp, #0x98]
    fad0:      	cmp	x8, x21
    fad4:      	b.eq	0xfb9c <generic_fentry_path+0x56ec>
    fad8:      	mov	w8, #0x4                // =4
    fadc:      	add	x9, sp, #0x78
    fae0:      	add	x0, sp, #0x78
    fae4:      	mov	w1, #0x8                // =8
    fae8:      	mov	x2, x23
    faec:      	blr	x8
    faf0:      	add	x2, x21, #0x20
    faf4:      	mov	w8, #0x4                // =4
    faf8:      	mov	w9, #0x10               // =16
    fafc:      	add	x10, sp, #0x80
    fb00:      	add	x0, sp, #0x80
    fb04:      	mov	w1, #0x10               // =16
    fb08:      	blr	x8
    fb0c:      	ldr	w21, [sp, #0x84]
    fb10:      	ldr	x8, [sp, #0x40]
    fb14:      	ldr	x10, [sp, #0x60]
    fb18:      	sub	x12, x10, x8
    fb1c:      	ldr	w23, [sp, #0x68]
    fb20:      	subs	w10, w21, w23
    fb24:      	ldr	x9, [sp, #0x88]
    fb28:      	csel	w10, wzr, w10, lo
    fb2c:      	cmp	w23, w21
    fb30:      	csel	w11, w23, w21, lo
    fb34:      	cinc	w13, w11, hi
    fb38:      	sub	w14, w23, w13
    fb3c:      	subs	x12, x12, x13
    fb40:      	str	w14, [sp, #0x68]
    fb44:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    fb48:      	cmp	x12, #0xfff
    fb4c:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    fb50:      	cmp	w23, w21
    fb54:      	b.ls	0xfb60 <generic_fentry_path+0x56b0>
    fb58:      	mov	w13, #0x2f              // =47
    fb5c:      	strb	w13, [x8, x12]
    fb60:      	add	x19, x8, x12
    fb64:      	cmp	w23, w21
    fb68:      	add	x2, x9, x10
    fb6c:      	and	w1, w11, #0xff
    fb70:      	mov	w8, #0x4                // =4
    fb74:      	cinc	x0, x19, hi
    fb78:      	blr	x8
    fb7c:      	cmp	w23, w21
    fb80:      	str	x19, [sp, #0x60]
    fb84:      	add	x19, sp, #0x70
    fb88:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    fb8c:      	ldr	x21, [sp, #0x78]
    fb90:      	ldp	x2, x24, [sp, #0x50]
    fb94:      	str	x21, [sp, #0x48]
    fb98:      	b	0xfbe8 <generic_fentry_path+0x5738>
    fb9c:      	add	x2, x24, #0x10
    fba0:      	mov	w8, #0x4                // =4
    fba4:      	add	x9, sp, #0x98
    fba8:      	add	x0, sp, #0x98
    fbac:      	mov	w1, #0x8                // =8
    fbb0:      	blr	x8
    fbb4:      	ldr	x8, [sp, #0x58]
    fbb8:      	ldr	x9, [sp, #0x98]
    fbbc:      	cmp	x8, x9
    fbc0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    fbc4:      	add	x2, x24, #0x18
    fbc8:      	mov	w8, #0x4                // =4
    fbcc:      	mov	x0, x22
    fbd0:      	mov	w1, #0x8                // =8
    fbd4:      	blr	x8
    fbd8:      	ldr	x24, [sp, #0x98]
    fbdc:      	ldr	x21, [sp, #0x48]
    fbe0:      	add	x2, x24, #0x20
    fbe4:      	stp	x2, x24, [sp, #0x50]
    fbe8:      	ldr	x8, [sp, #0x30]
    fbec:      	cmp	x21, x8
    fbf0:      	b.ne	0xfc00 <generic_fentry_path+0x5750>
    fbf4:      	ldr	x8, [sp, #0x38]
    fbf8:      	cmp	x2, x8
    fbfc:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    fc00:      	mov	w8, #0x4                // =4
    fc04:      	add	x0, sp, #0x70
    fc08:      	mov	w1, #0x8                // =8
    fc0c:      	blr	x8
    fc10:      	ldr	x8, [sp, #0x70]
    fc14:      	cmp	x21, x8
    fc18:      	b.eq	0xfd08 <generic_fentry_path+0x5858>
    fc1c:      	add	x23, x21, #0x18
    fc20:      	mov	w8, #0x4                // =4
    fc24:      	add	x9, sp, #0x98
    fc28:      	add	x0, sp, #0x98
    fc2c:      	mov	w1, #0x8                // =8
    fc30:      	mov	x2, x23
    fc34:      	blr	x8
    fc38:      	ldr	x8, [sp, #0x98]
    fc3c:      	cmp	x8, x21
    fc40:      	b.eq	0xfd08 <generic_fentry_path+0x5858>
    fc44:      	mov	w8, #0x4                // =4
    fc48:      	add	x9, sp, #0x78
    fc4c:      	add	x0, sp, #0x78
    fc50:      	mov	w1, #0x8                // =8
    fc54:      	mov	x2, x23
    fc58:      	blr	x8
    fc5c:      	add	x2, x21, #0x20
    fc60:      	mov	w8, #0x4                // =4
    fc64:      	mov	w9, #0x10               // =16
    fc68:      	add	x10, sp, #0x80
    fc6c:      	add	x0, sp, #0x80
    fc70:      	mov	w1, #0x10               // =16
    fc74:      	blr	x8
    fc78:      	ldr	w21, [sp, #0x84]
    fc7c:      	ldr	x8, [sp, #0x40]
    fc80:      	ldr	x10, [sp, #0x60]
    fc84:      	sub	x12, x10, x8
    fc88:      	ldr	w23, [sp, #0x68]
    fc8c:      	subs	w10, w21, w23
    fc90:      	ldr	x9, [sp, #0x88]
    fc94:      	csel	w10, wzr, w10, lo
    fc98:      	cmp	w23, w21
    fc9c:      	csel	w11, w23, w21, lo
    fca0:      	cinc	w13, w11, hi
    fca4:      	sub	w14, w23, w13
    fca8:      	subs	x12, x12, x13
    fcac:      	str	w14, [sp, #0x68]
    fcb0:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    fcb4:      	cmp	x12, #0xfff
    fcb8:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    fcbc:      	cmp	w23, w21
    fcc0:      	b.ls	0xfccc <generic_fentry_path+0x581c>
    fcc4:      	mov	w13, #0x2f              // =47
    fcc8:      	strb	w13, [x8, x12]
    fccc:      	add	x19, x8, x12
    fcd0:      	cmp	w23, w21
    fcd4:      	add	x2, x9, x10
    fcd8:      	and	w1, w11, #0xff
    fcdc:      	mov	w8, #0x4                // =4
    fce0:      	cinc	x0, x19, hi
    fce4:      	blr	x8
    fce8:      	cmp	w23, w21
    fcec:      	str	x19, [sp, #0x60]
    fcf0:      	add	x19, sp, #0x70
    fcf4:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    fcf8:      	ldr	x21, [sp, #0x78]
    fcfc:      	ldp	x2, x24, [sp, #0x50]
    fd00:      	str	x21, [sp, #0x48]
    fd04:      	b	0xfd54 <generic_fentry_path+0x58a4>
    fd08:      	add	x2, x24, #0x10
    fd0c:      	mov	w8, #0x4                // =4
    fd10:      	add	x9, sp, #0x98
    fd14:      	add	x0, sp, #0x98
    fd18:      	mov	w1, #0x8                // =8
    fd1c:      	blr	x8
    fd20:      	ldr	x8, [sp, #0x58]
    fd24:      	ldr	x9, [sp, #0x98]
    fd28:      	cmp	x8, x9
    fd2c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    fd30:      	add	x2, x24, #0x18
    fd34:      	mov	w8, #0x4                // =4
    fd38:      	mov	x0, x22
    fd3c:      	mov	w1, #0x8                // =8
    fd40:      	blr	x8
    fd44:      	ldr	x24, [sp, #0x98]
    fd48:      	ldr	x21, [sp, #0x48]
    fd4c:      	add	x2, x24, #0x20
    fd50:      	stp	x2, x24, [sp, #0x50]
    fd54:      	ldr	x8, [sp, #0x30]
    fd58:      	cmp	x21, x8
    fd5c:      	b.ne	0xfd6c <generic_fentry_path+0x58bc>
    fd60:      	ldr	x8, [sp, #0x38]
    fd64:      	cmp	x2, x8
    fd68:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    fd6c:      	mov	w8, #0x4                // =4
    fd70:      	add	x0, sp, #0x70
    fd74:      	mov	w1, #0x8                // =8
    fd78:      	blr	x8
    fd7c:      	ldr	x8, [sp, #0x70]
    fd80:      	cmp	x21, x8
    fd84:      	b.eq	0xfe74 <generic_fentry_path+0x59c4>
    fd88:      	add	x23, x21, #0x18
    fd8c:      	mov	w8, #0x4                // =4
    fd90:      	add	x9, sp, #0x98
    fd94:      	add	x0, sp, #0x98
    fd98:      	mov	w1, #0x8                // =8
    fd9c:      	mov	x2, x23
    fda0:      	blr	x8
    fda4:      	ldr	x8, [sp, #0x98]
    fda8:      	cmp	x8, x21
    fdac:      	b.eq	0xfe74 <generic_fentry_path+0x59c4>
    fdb0:      	mov	w8, #0x4                // =4
    fdb4:      	add	x9, sp, #0x78
    fdb8:      	add	x0, sp, #0x78
    fdbc:      	mov	w1, #0x8                // =8
    fdc0:      	mov	x2, x23
    fdc4:      	blr	x8
    fdc8:      	add	x2, x21, #0x20
    fdcc:      	mov	w8, #0x4                // =4
    fdd0:      	mov	w9, #0x10               // =16
    fdd4:      	add	x10, sp, #0x80
    fdd8:      	add	x0, sp, #0x80
    fddc:      	mov	w1, #0x10               // =16
    fde0:      	blr	x8
    fde4:      	ldr	w21, [sp, #0x84]
    fde8:      	ldr	x8, [sp, #0x40]
    fdec:      	ldr	x10, [sp, #0x60]
    fdf0:      	sub	x12, x10, x8
    fdf4:      	ldr	w23, [sp, #0x68]
    fdf8:      	subs	w10, w21, w23
    fdfc:      	ldr	x9, [sp, #0x88]
    fe00:      	csel	w10, wzr, w10, lo
    fe04:      	cmp	w23, w21
    fe08:      	csel	w11, w23, w21, lo
    fe0c:      	cinc	w13, w11, hi
    fe10:      	sub	w14, w23, w13
    fe14:      	subs	x12, x12, x13
    fe18:      	str	w14, [sp, #0x68]
    fe1c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    fe20:      	cmp	x12, #0xfff
    fe24:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    fe28:      	cmp	w23, w21
    fe2c:      	b.ls	0xfe38 <generic_fentry_path+0x5988>
    fe30:      	mov	w13, #0x2f              // =47
    fe34:      	strb	w13, [x8, x12]
    fe38:      	add	x19, x8, x12
    fe3c:      	cmp	w23, w21
    fe40:      	add	x2, x9, x10
    fe44:      	and	w1, w11, #0xff
    fe48:      	mov	w8, #0x4                // =4
    fe4c:      	cinc	x0, x19, hi
    fe50:      	blr	x8
    fe54:      	cmp	w23, w21
    fe58:      	str	x19, [sp, #0x60]
    fe5c:      	add	x19, sp, #0x70
    fe60:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    fe64:      	ldr	x21, [sp, #0x78]
    fe68:      	ldp	x2, x24, [sp, #0x50]
    fe6c:      	str	x21, [sp, #0x48]
    fe70:      	b	0xfec0 <generic_fentry_path+0x5a10>
    fe74:      	add	x2, x24, #0x10
    fe78:      	mov	w8, #0x4                // =4
    fe7c:      	add	x9, sp, #0x98
    fe80:      	add	x0, sp, #0x98
    fe84:      	mov	w1, #0x8                // =8
    fe88:      	blr	x8
    fe8c:      	ldr	x8, [sp, #0x58]
    fe90:      	ldr	x9, [sp, #0x98]
    fe94:      	cmp	x8, x9
    fe98:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    fe9c:      	add	x2, x24, #0x18
    fea0:      	mov	w8, #0x4                // =4
    fea4:      	mov	x0, x22
    fea8:      	mov	w1, #0x8                // =8
    feac:      	blr	x8
    feb0:      	ldr	x24, [sp, #0x98]
    feb4:      	ldr	x21, [sp, #0x48]
    feb8:      	add	x2, x24, #0x20
    febc:      	stp	x2, x24, [sp, #0x50]
    fec0:      	ldr	x8, [sp, #0x30]
    fec4:      	cmp	x21, x8
    fec8:      	b.ne	0xfed8 <generic_fentry_path+0x5a28>
    fecc:      	ldr	x8, [sp, #0x38]
    fed0:      	cmp	x2, x8
    fed4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
    fed8:      	mov	w8, #0x4                // =4
    fedc:      	add	x0, sp, #0x70
    fee0:      	mov	w1, #0x8                // =8
    fee4:      	blr	x8
    fee8:      	ldr	x8, [sp, #0x70]
    feec:      	cmp	x21, x8
    fef0:      	b.eq	0xffe0 <generic_fentry_path+0x5b30>
    fef4:      	add	x23, x21, #0x18
    fef8:      	mov	w8, #0x4                // =4
    fefc:      	add	x9, sp, #0x98
    ff00:      	add	x0, sp, #0x98
    ff04:      	mov	w1, #0x8                // =8
    ff08:      	mov	x2, x23
    ff0c:      	blr	x8
    ff10:      	ldr	x8, [sp, #0x98]
    ff14:      	cmp	x8, x21
    ff18:      	b.eq	0xffe0 <generic_fentry_path+0x5b30>
    ff1c:      	mov	w8, #0x4                // =4
    ff20:      	add	x9, sp, #0x78
    ff24:      	add	x0, sp, #0x78
    ff28:      	mov	w1, #0x8                // =8
    ff2c:      	mov	x2, x23
    ff30:      	blr	x8
    ff34:      	add	x2, x21, #0x20
    ff38:      	mov	w8, #0x4                // =4
    ff3c:      	mov	w9, #0x10               // =16
    ff40:      	add	x10, sp, #0x80
    ff44:      	add	x0, sp, #0x80
    ff48:      	mov	w1, #0x10               // =16
    ff4c:      	blr	x8
    ff50:      	ldr	w21, [sp, #0x84]
    ff54:      	ldr	x8, [sp, #0x40]
    ff58:      	ldr	x10, [sp, #0x60]
    ff5c:      	sub	x12, x10, x8
    ff60:      	ldr	w23, [sp, #0x68]
    ff64:      	subs	w10, w21, w23
    ff68:      	ldr	x9, [sp, #0x88]
    ff6c:      	csel	w10, wzr, w10, lo
    ff70:      	cmp	w23, w21
    ff74:      	csel	w11, w23, w21, lo
    ff78:      	cinc	w13, w11, hi
    ff7c:      	sub	w14, w23, w13
    ff80:      	subs	x12, x12, x13
    ff84:      	str	w14, [sp, #0x68]
    ff88:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
    ff8c:      	cmp	x12, #0xfff
    ff90:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
    ff94:      	cmp	w23, w21
    ff98:      	b.ls	0xffa4 <generic_fentry_path+0x5af4>
    ff9c:      	mov	w13, #0x2f              // =47
    ffa0:      	strb	w13, [x8, x12]
    ffa4:      	add	x19, x8, x12
    ffa8:      	cmp	w23, w21
    ffac:      	add	x2, x9, x10
    ffb0:      	and	w1, w11, #0xff
    ffb4:      	mov	w8, #0x4                // =4
    ffb8:      	cinc	x0, x19, hi
    ffbc:      	blr	x8
    ffc0:      	cmp	w23, w21
    ffc4:      	str	x19, [sp, #0x60]
    ffc8:      	add	x19, sp, #0x70
    ffcc:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
    ffd0:      	ldr	x21, [sp, #0x78]
    ffd4:      	ldp	x2, x24, [sp, #0x50]
    ffd8:      	str	x21, [sp, #0x48]
    ffdc:      	b	0x1002c <generic_fentry_path+0x5b7c>
    ffe0:      	add	x2, x24, #0x10
    ffe4:      	mov	w8, #0x4                // =4
    ffe8:      	add	x9, sp, #0x98
    ffec:      	add	x0, sp, #0x98
    fff0:      	mov	w1, #0x8                // =8
    fff4:      	blr	x8
    fff8:      	ldr	x8, [sp, #0x58]
    fffc:      	ldr	x9, [sp, #0x98]
   10000:      	cmp	x8, x9
   10004:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   10008:      	add	x2, x24, #0x18
   1000c:      	mov	w8, #0x4                // =4
   10010:      	mov	x0, x22
   10014:      	mov	w1, #0x8                // =8
   10018:      	blr	x8
   1001c:      	ldr	x24, [sp, #0x98]
   10020:      	ldr	x21, [sp, #0x48]
   10024:      	add	x2, x24, #0x20
   10028:      	stp	x2, x24, [sp, #0x50]
   1002c:      	ldr	x8, [sp, #0x30]
   10030:      	cmp	x21, x8
   10034:      	b.ne	0x10044 <generic_fentry_path+0x5b94>
   10038:      	ldr	x8, [sp, #0x38]
   1003c:      	cmp	x2, x8
   10040:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   10044:      	mov	w8, #0x4                // =4
   10048:      	add	x0, sp, #0x70
   1004c:      	mov	w1, #0x8                // =8
   10050:      	blr	x8
   10054:      	ldr	x8, [sp, #0x70]
   10058:      	cmp	x21, x8
   1005c:      	b.eq	0x1014c <generic_fentry_path+0x5c9c>
   10060:      	add	x23, x21, #0x18
   10064:      	mov	w8, #0x4                // =4
   10068:      	add	x9, sp, #0x98
   1006c:      	add	x0, sp, #0x98
   10070:      	mov	w1, #0x8                // =8
   10074:      	mov	x2, x23
   10078:      	blr	x8
   1007c:      	ldr	x8, [sp, #0x98]
   10080:      	cmp	x8, x21
   10084:      	b.eq	0x1014c <generic_fentry_path+0x5c9c>
   10088:      	mov	w8, #0x4                // =4
   1008c:      	add	x9, sp, #0x78
   10090:      	add	x0, sp, #0x78
   10094:      	mov	w1, #0x8                // =8
   10098:      	mov	x2, x23
   1009c:      	blr	x8
   100a0:      	add	x2, x21, #0x20
   100a4:      	mov	w8, #0x4                // =4
   100a8:      	mov	w9, #0x10               // =16
   100ac:      	add	x10, sp, #0x80
   100b0:      	add	x0, sp, #0x80
   100b4:      	mov	w1, #0x10               // =16
   100b8:      	blr	x8
   100bc:      	ldr	w21, [sp, #0x84]
   100c0:      	ldr	x8, [sp, #0x40]
   100c4:      	ldr	x10, [sp, #0x60]
   100c8:      	sub	x12, x10, x8
   100cc:      	ldr	w23, [sp, #0x68]
   100d0:      	subs	w10, w21, w23
   100d4:      	ldr	x9, [sp, #0x88]
   100d8:      	csel	w10, wzr, w10, lo
   100dc:      	cmp	w23, w21
   100e0:      	csel	w11, w23, w21, lo
   100e4:      	cinc	w13, w11, hi
   100e8:      	sub	w14, w23, w13
   100ec:      	subs	x12, x12, x13
   100f0:      	str	w14, [sp, #0x68]
   100f4:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   100f8:      	cmp	x12, #0xfff
   100fc:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   10100:      	cmp	w23, w21
   10104:      	b.ls	0x10110 <generic_fentry_path+0x5c60>
   10108:      	mov	w13, #0x2f              // =47
   1010c:      	strb	w13, [x8, x12]
   10110:      	add	x19, x8, x12
   10114:      	cmp	w23, w21
   10118:      	add	x2, x9, x10
   1011c:      	and	w1, w11, #0xff
   10120:      	mov	w8, #0x4                // =4
   10124:      	cinc	x0, x19, hi
   10128:      	blr	x8
   1012c:      	cmp	w23, w21
   10130:      	str	x19, [sp, #0x60]
   10134:      	add	x19, sp, #0x70
   10138:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   1013c:      	ldr	x21, [sp, #0x78]
   10140:      	ldp	x2, x24, [sp, #0x50]
   10144:      	str	x21, [sp, #0x48]
   10148:      	b	0x10198 <generic_fentry_path+0x5ce8>
   1014c:      	add	x2, x24, #0x10
   10150:      	mov	w8, #0x4                // =4
   10154:      	add	x9, sp, #0x98
   10158:      	add	x0, sp, #0x98
   1015c:      	mov	w1, #0x8                // =8
   10160:      	blr	x8
   10164:      	ldr	x8, [sp, #0x58]
   10168:      	ldr	x9, [sp, #0x98]
   1016c:      	cmp	x8, x9
   10170:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   10174:      	add	x2, x24, #0x18
   10178:      	mov	w8, #0x4                // =4
   1017c:      	mov	x0, x22
   10180:      	mov	w1, #0x8                // =8
   10184:      	blr	x8
   10188:      	ldr	x24, [sp, #0x98]
   1018c:      	ldr	x21, [sp, #0x48]
   10190:      	add	x2, x24, #0x20
   10194:      	stp	x2, x24, [sp, #0x50]
   10198:      	ldr	x8, [sp, #0x30]
   1019c:      	cmp	x21, x8
   101a0:      	b.ne	0x101b0 <generic_fentry_path+0x5d00>
   101a4:      	ldr	x8, [sp, #0x38]
   101a8:      	cmp	x2, x8
   101ac:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   101b0:      	mov	w8, #0x4                // =4
   101b4:      	add	x0, sp, #0x70
   101b8:      	mov	w1, #0x8                // =8
   101bc:      	blr	x8
   101c0:      	ldr	x8, [sp, #0x70]
   101c4:      	cmp	x21, x8
   101c8:      	b.eq	0x102b8 <generic_fentry_path+0x5e08>
   101cc:      	add	x23, x21, #0x18
   101d0:      	mov	w8, #0x4                // =4
   101d4:      	add	x9, sp, #0x98
   101d8:      	add	x0, sp, #0x98
   101dc:      	mov	w1, #0x8                // =8
   101e0:      	mov	x2, x23
   101e4:      	blr	x8
   101e8:      	ldr	x8, [sp, #0x98]
   101ec:      	cmp	x8, x21
   101f0:      	b.eq	0x102b8 <generic_fentry_path+0x5e08>
   101f4:      	mov	w8, #0x4                // =4
   101f8:      	add	x9, sp, #0x78
   101fc:      	add	x0, sp, #0x78
   10200:      	mov	w1, #0x8                // =8
   10204:      	mov	x2, x23
   10208:      	blr	x8
   1020c:      	add	x2, x21, #0x20
   10210:      	mov	w8, #0x4                // =4
   10214:      	mov	w9, #0x10               // =16
   10218:      	add	x10, sp, #0x80
   1021c:      	add	x0, sp, #0x80
   10220:      	mov	w1, #0x10               // =16
   10224:      	blr	x8
   10228:      	ldr	w21, [sp, #0x84]
   1022c:      	ldr	x8, [sp, #0x40]
   10230:      	ldr	x10, [sp, #0x60]
   10234:      	sub	x12, x10, x8
   10238:      	ldr	w23, [sp, #0x68]
   1023c:      	subs	w10, w21, w23
   10240:      	ldr	x9, [sp, #0x88]
   10244:      	csel	w10, wzr, w10, lo
   10248:      	cmp	w23, w21
   1024c:      	csel	w11, w23, w21, lo
   10250:      	cinc	w13, w11, hi
   10254:      	sub	w14, w23, w13
   10258:      	subs	x12, x12, x13
   1025c:      	str	w14, [sp, #0x68]
   10260:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   10264:      	cmp	x12, #0xfff
   10268:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   1026c:      	cmp	w23, w21
   10270:      	b.ls	0x1027c <generic_fentry_path+0x5dcc>
   10274:      	mov	w13, #0x2f              // =47
   10278:      	strb	w13, [x8, x12]
   1027c:      	add	x19, x8, x12
   10280:      	cmp	w23, w21
   10284:      	add	x2, x9, x10
   10288:      	and	w1, w11, #0xff
   1028c:      	mov	w8, #0x4                // =4
   10290:      	cinc	x0, x19, hi
   10294:      	blr	x8
   10298:      	cmp	w23, w21
   1029c:      	str	x19, [sp, #0x60]
   102a0:      	add	x19, sp, #0x70
   102a4:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   102a8:      	ldr	x21, [sp, #0x78]
   102ac:      	ldp	x2, x24, [sp, #0x50]
   102b0:      	str	x21, [sp, #0x48]
   102b4:      	b	0x10304 <generic_fentry_path+0x5e54>
   102b8:      	add	x2, x24, #0x10
   102bc:      	mov	w8, #0x4                // =4
   102c0:      	add	x9, sp, #0x98
   102c4:      	add	x0, sp, #0x98
   102c8:      	mov	w1, #0x8                // =8
   102cc:      	blr	x8
   102d0:      	ldr	x8, [sp, #0x58]
   102d4:      	ldr	x9, [sp, #0x98]
   102d8:      	cmp	x8, x9
   102dc:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   102e0:      	add	x2, x24, #0x18
   102e4:      	mov	w8, #0x4                // =4
   102e8:      	mov	x0, x22
   102ec:      	mov	w1, #0x8                // =8
   102f0:      	blr	x8
   102f4:      	ldr	x24, [sp, #0x98]
   102f8:      	ldr	x21, [sp, #0x48]
   102fc:      	add	x2, x24, #0x20
   10300:      	stp	x2, x24, [sp, #0x50]
   10304:      	ldr	x8, [sp, #0x30]
   10308:      	cmp	x21, x8
   1030c:      	b.ne	0x1031c <generic_fentry_path+0x5e6c>
   10310:      	ldr	x8, [sp, #0x38]
   10314:      	cmp	x2, x8
   10318:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   1031c:      	mov	w8, #0x4                // =4
   10320:      	add	x0, sp, #0x70
   10324:      	mov	w1, #0x8                // =8
   10328:      	blr	x8
   1032c:      	ldr	x8, [sp, #0x70]
   10330:      	cmp	x21, x8
   10334:      	b.eq	0x10424 <generic_fentry_path+0x5f74>
   10338:      	add	x23, x21, #0x18
   1033c:      	mov	w8, #0x4                // =4
   10340:      	add	x9, sp, #0x98
   10344:      	add	x0, sp, #0x98
   10348:      	mov	w1, #0x8                // =8
   1034c:      	mov	x2, x23
   10350:      	blr	x8
   10354:      	ldr	x8, [sp, #0x98]
   10358:      	cmp	x8, x21
   1035c:      	b.eq	0x10424 <generic_fentry_path+0x5f74>
   10360:      	mov	w8, #0x4                // =4
   10364:      	add	x9, sp, #0x78
   10368:      	add	x0, sp, #0x78
   1036c:      	mov	w1, #0x8                // =8
   10370:      	mov	x2, x23
   10374:      	blr	x8
   10378:      	add	x2, x21, #0x20
   1037c:      	mov	w8, #0x4                // =4
   10380:      	mov	w9, #0x10               // =16
   10384:      	add	x10, sp, #0x80
   10388:      	add	x0, sp, #0x80
   1038c:      	mov	w1, #0x10               // =16
   10390:      	blr	x8
   10394:      	ldr	w21, [sp, #0x84]
   10398:      	ldr	x8, [sp, #0x40]
   1039c:      	ldr	x10, [sp, #0x60]
   103a0:      	sub	x12, x10, x8
   103a4:      	ldr	w23, [sp, #0x68]
   103a8:      	subs	w10, w21, w23
   103ac:      	ldr	x9, [sp, #0x88]
   103b0:      	csel	w10, wzr, w10, lo
   103b4:      	cmp	w23, w21
   103b8:      	csel	w11, w23, w21, lo
   103bc:      	cinc	w13, w11, hi
   103c0:      	sub	w14, w23, w13
   103c4:      	subs	x12, x12, x13
   103c8:      	str	w14, [sp, #0x68]
   103cc:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   103d0:      	cmp	x12, #0xfff
   103d4:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   103d8:      	cmp	w23, w21
   103dc:      	b.ls	0x103e8 <generic_fentry_path+0x5f38>
   103e0:      	mov	w13, #0x2f              // =47
   103e4:      	strb	w13, [x8, x12]
   103e8:      	add	x19, x8, x12
   103ec:      	cmp	w23, w21
   103f0:      	add	x2, x9, x10
   103f4:      	and	w1, w11, #0xff
   103f8:      	mov	w8, #0x4                // =4
   103fc:      	cinc	x0, x19, hi
   10400:      	blr	x8
   10404:      	cmp	w23, w21
   10408:      	str	x19, [sp, #0x60]
   1040c:      	add	x19, sp, #0x70
   10410:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   10414:      	ldr	x21, [sp, #0x78]
   10418:      	ldp	x2, x24, [sp, #0x50]
   1041c:      	str	x21, [sp, #0x48]
   10420:      	b	0x10470 <generic_fentry_path+0x5fc0>
   10424:      	add	x2, x24, #0x10
   10428:      	mov	w8, #0x4                // =4
   1042c:      	add	x9, sp, #0x98
   10430:      	add	x0, sp, #0x98
   10434:      	mov	w1, #0x8                // =8
   10438:      	blr	x8
   1043c:      	ldr	x8, [sp, #0x58]
   10440:      	ldr	x9, [sp, #0x98]
   10444:      	cmp	x8, x9
   10448:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   1044c:      	add	x2, x24, #0x18
   10450:      	mov	w8, #0x4                // =4
   10454:      	mov	x0, x22
   10458:      	mov	w1, #0x8                // =8
   1045c:      	blr	x8
   10460:      	ldr	x24, [sp, #0x98]
   10464:      	ldr	x21, [sp, #0x48]
   10468:      	add	x2, x24, #0x20
   1046c:      	stp	x2, x24, [sp, #0x50]
   10470:      	ldr	x8, [sp, #0x30]
   10474:      	cmp	x21, x8
   10478:      	b.ne	0x10488 <generic_fentry_path+0x5fd8>
   1047c:      	ldr	x8, [sp, #0x38]
   10480:      	cmp	x2, x8
   10484:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   10488:      	mov	w8, #0x4                // =4
   1048c:      	add	x0, sp, #0x70
   10490:      	mov	w1, #0x8                // =8
   10494:      	blr	x8
   10498:      	ldr	x8, [sp, #0x70]
   1049c:      	cmp	x21, x8
   104a0:      	b.eq	0x10590 <generic_fentry_path+0x60e0>
   104a4:      	add	x23, x21, #0x18
   104a8:      	mov	w8, #0x4                // =4
   104ac:      	add	x9, sp, #0x98
   104b0:      	add	x0, sp, #0x98
   104b4:      	mov	w1, #0x8                // =8
   104b8:      	mov	x2, x23
   104bc:      	blr	x8
   104c0:      	ldr	x8, [sp, #0x98]
   104c4:      	cmp	x8, x21
   104c8:      	b.eq	0x10590 <generic_fentry_path+0x60e0>
   104cc:      	mov	w8, #0x4                // =4
   104d0:      	add	x9, sp, #0x78
   104d4:      	add	x0, sp, #0x78
   104d8:      	mov	w1, #0x8                // =8
   104dc:      	mov	x2, x23
   104e0:      	blr	x8
   104e4:      	add	x2, x21, #0x20
   104e8:      	mov	w8, #0x4                // =4
   104ec:      	mov	w9, #0x10               // =16
   104f0:      	add	x10, sp, #0x80
   104f4:      	add	x0, sp, #0x80
   104f8:      	mov	w1, #0x10               // =16
   104fc:      	blr	x8
   10500:      	ldr	w21, [sp, #0x84]
   10504:      	ldr	x8, [sp, #0x40]
   10508:      	ldr	x10, [sp, #0x60]
   1050c:      	sub	x12, x10, x8
   10510:      	ldr	w23, [sp, #0x68]
   10514:      	subs	w10, w21, w23
   10518:      	ldr	x9, [sp, #0x88]
   1051c:      	csel	w10, wzr, w10, lo
   10520:      	cmp	w23, w21
   10524:      	csel	w11, w23, w21, lo
   10528:      	cinc	w13, w11, hi
   1052c:      	sub	w14, w23, w13
   10530:      	subs	x12, x12, x13
   10534:      	str	w14, [sp, #0x68]
   10538:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   1053c:      	cmp	x12, #0xfff
   10540:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   10544:      	cmp	w23, w21
   10548:      	b.ls	0x10554 <generic_fentry_path+0x60a4>
   1054c:      	mov	w13, #0x2f              // =47
   10550:      	strb	w13, [x8, x12]
   10554:      	add	x19, x8, x12
   10558:      	cmp	w23, w21
   1055c:      	add	x2, x9, x10
   10560:      	and	w1, w11, #0xff
   10564:      	mov	w8, #0x4                // =4
   10568:      	cinc	x0, x19, hi
   1056c:      	blr	x8
   10570:      	cmp	w23, w21
   10574:      	str	x19, [sp, #0x60]
   10578:      	add	x19, sp, #0x70
   1057c:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   10580:      	ldr	x21, [sp, #0x78]
   10584:      	ldp	x2, x24, [sp, #0x50]
   10588:      	str	x21, [sp, #0x48]
   1058c:      	b	0x105dc <generic_fentry_path+0x612c>
   10590:      	add	x2, x24, #0x10
   10594:      	mov	w8, #0x4                // =4
   10598:      	add	x9, sp, #0x98
   1059c:      	add	x0, sp, #0x98
   105a0:      	mov	w1, #0x8                // =8
   105a4:      	blr	x8
   105a8:      	ldr	x8, [sp, #0x58]
   105ac:      	ldr	x9, [sp, #0x98]
   105b0:      	cmp	x8, x9
   105b4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   105b8:      	add	x2, x24, #0x18
   105bc:      	mov	w8, #0x4                // =4
   105c0:      	mov	x0, x22
   105c4:      	mov	w1, #0x8                // =8
   105c8:      	blr	x8
   105cc:      	ldr	x24, [sp, #0x98]
   105d0:      	ldr	x21, [sp, #0x48]
   105d4:      	add	x2, x24, #0x20
   105d8:      	stp	x2, x24, [sp, #0x50]
   105dc:      	ldr	x8, [sp, #0x30]
   105e0:      	cmp	x21, x8
   105e4:      	b.ne	0x105f4 <generic_fentry_path+0x6144>
   105e8:      	ldr	x8, [sp, #0x38]
   105ec:      	cmp	x2, x8
   105f0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   105f4:      	mov	w8, #0x4                // =4
   105f8:      	add	x0, sp, #0x70
   105fc:      	mov	w1, #0x8                // =8
   10600:      	blr	x8
   10604:      	ldr	x8, [sp, #0x70]
   10608:      	cmp	x21, x8
   1060c:      	b.eq	0x106fc <generic_fentry_path+0x624c>
   10610:      	add	x23, x21, #0x18
   10614:      	mov	w8, #0x4                // =4
   10618:      	add	x9, sp, #0x98
   1061c:      	add	x0, sp, #0x98
   10620:      	mov	w1, #0x8                // =8
   10624:      	mov	x2, x23
   10628:      	blr	x8
   1062c:      	ldr	x8, [sp, #0x98]
   10630:      	cmp	x8, x21
   10634:      	b.eq	0x106fc <generic_fentry_path+0x624c>
   10638:      	mov	w8, #0x4                // =4
   1063c:      	add	x9, sp, #0x78
   10640:      	add	x0, sp, #0x78
   10644:      	mov	w1, #0x8                // =8
   10648:      	mov	x2, x23
   1064c:      	blr	x8
   10650:      	add	x2, x21, #0x20
   10654:      	mov	w8, #0x4                // =4
   10658:      	mov	w9, #0x10               // =16
   1065c:      	add	x10, sp, #0x80
   10660:      	add	x0, sp, #0x80
   10664:      	mov	w1, #0x10               // =16
   10668:      	blr	x8
   1066c:      	ldr	w21, [sp, #0x84]
   10670:      	ldr	x8, [sp, #0x40]
   10674:      	ldr	x10, [sp, #0x60]
   10678:      	sub	x12, x10, x8
   1067c:      	ldr	w23, [sp, #0x68]
   10680:      	subs	w10, w21, w23
   10684:      	ldr	x9, [sp, #0x88]
   10688:      	csel	w10, wzr, w10, lo
   1068c:      	cmp	w23, w21
   10690:      	csel	w11, w23, w21, lo
   10694:      	cinc	w13, w11, hi
   10698:      	sub	w14, w23, w13
   1069c:      	subs	x12, x12, x13
   106a0:      	str	w14, [sp, #0x68]
   106a4:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   106a8:      	cmp	x12, #0xfff
   106ac:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   106b0:      	cmp	w23, w21
   106b4:      	b.ls	0x106c0 <generic_fentry_path+0x6210>
   106b8:      	mov	w13, #0x2f              // =47
   106bc:      	strb	w13, [x8, x12]
   106c0:      	add	x19, x8, x12
   106c4:      	cmp	w23, w21
   106c8:      	add	x2, x9, x10
   106cc:      	and	w1, w11, #0xff
   106d0:      	mov	w8, #0x4                // =4
   106d4:      	cinc	x0, x19, hi
   106d8:      	blr	x8
   106dc:      	cmp	w23, w21
   106e0:      	str	x19, [sp, #0x60]
   106e4:      	add	x19, sp, #0x70
   106e8:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   106ec:      	ldr	x21, [sp, #0x78]
   106f0:      	ldp	x2, x24, [sp, #0x50]
   106f4:      	str	x21, [sp, #0x48]
   106f8:      	b	0x10748 <generic_fentry_path+0x6298>
   106fc:      	add	x2, x24, #0x10
   10700:      	mov	w8, #0x4                // =4
   10704:      	add	x9, sp, #0x98
   10708:      	add	x0, sp, #0x98
   1070c:      	mov	w1, #0x8                // =8
   10710:      	blr	x8
   10714:      	ldr	x8, [sp, #0x58]
   10718:      	ldr	x9, [sp, #0x98]
   1071c:      	cmp	x8, x9
   10720:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   10724:      	add	x2, x24, #0x18
   10728:      	mov	w8, #0x4                // =4
   1072c:      	mov	x0, x22
   10730:      	mov	w1, #0x8                // =8
   10734:      	blr	x8
   10738:      	ldr	x24, [sp, #0x98]
   1073c:      	ldr	x21, [sp, #0x48]
   10740:      	add	x2, x24, #0x20
   10744:      	stp	x2, x24, [sp, #0x50]
   10748:      	ldr	x8, [sp, #0x30]
   1074c:      	cmp	x21, x8
   10750:      	b.ne	0x10760 <generic_fentry_path+0x62b0>
   10754:      	ldr	x8, [sp, #0x38]
   10758:      	cmp	x2, x8
   1075c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   10760:      	mov	w8, #0x4                // =4
   10764:      	add	x0, sp, #0x70
   10768:      	mov	w1, #0x8                // =8
   1076c:      	blr	x8
   10770:      	ldr	x8, [sp, #0x70]
   10774:      	cmp	x21, x8
   10778:      	b.eq	0x10868 <generic_fentry_path+0x63b8>
   1077c:      	add	x23, x21, #0x18
   10780:      	mov	w8, #0x4                // =4
   10784:      	add	x9, sp, #0x98
   10788:      	add	x0, sp, #0x98
   1078c:      	mov	w1, #0x8                // =8
   10790:      	mov	x2, x23
   10794:      	blr	x8
   10798:      	ldr	x8, [sp, #0x98]
   1079c:      	cmp	x8, x21
   107a0:      	b.eq	0x10868 <generic_fentry_path+0x63b8>
   107a4:      	mov	w8, #0x4                // =4
   107a8:      	add	x9, sp, #0x78
   107ac:      	add	x0, sp, #0x78
   107b0:      	mov	w1, #0x8                // =8
   107b4:      	mov	x2, x23
   107b8:      	blr	x8
   107bc:      	add	x2, x21, #0x20
   107c0:      	mov	w8, #0x4                // =4
   107c4:      	mov	w9, #0x10               // =16
   107c8:      	add	x10, sp, #0x80
   107cc:      	add	x0, sp, #0x80
   107d0:      	mov	w1, #0x10               // =16
   107d4:      	blr	x8
   107d8:      	ldr	w21, [sp, #0x84]
   107dc:      	ldr	x8, [sp, #0x40]
   107e0:      	ldr	x10, [sp, #0x60]
   107e4:      	sub	x12, x10, x8
   107e8:      	ldr	w23, [sp, #0x68]
   107ec:      	subs	w10, w21, w23
   107f0:      	ldr	x9, [sp, #0x88]
   107f4:      	csel	w10, wzr, w10, lo
   107f8:      	cmp	w23, w21
   107fc:      	csel	w11, w23, w21, lo
   10800:      	cinc	w13, w11, hi
   10804:      	sub	w14, w23, w13
   10808:      	subs	x12, x12, x13
   1080c:      	str	w14, [sp, #0x68]
   10810:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   10814:      	cmp	x12, #0xfff
   10818:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   1081c:      	cmp	w23, w21
   10820:      	b.ls	0x1082c <generic_fentry_path+0x637c>
   10824:      	mov	w13, #0x2f              // =47
   10828:      	strb	w13, [x8, x12]
   1082c:      	add	x19, x8, x12
   10830:      	cmp	w23, w21
   10834:      	add	x2, x9, x10
   10838:      	and	w1, w11, #0xff
   1083c:      	mov	w8, #0x4                // =4
   10840:      	cinc	x0, x19, hi
   10844:      	blr	x8
   10848:      	cmp	w23, w21
   1084c:      	str	x19, [sp, #0x60]
   10850:      	add	x19, sp, #0x70
   10854:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   10858:      	ldr	x21, [sp, #0x78]
   1085c:      	ldp	x2, x24, [sp, #0x50]
   10860:      	str	x21, [sp, #0x48]
   10864:      	b	0x108b4 <generic_fentry_path+0x6404>
   10868:      	add	x2, x24, #0x10
   1086c:      	mov	w8, #0x4                // =4
   10870:      	add	x9, sp, #0x98
   10874:      	add	x0, sp, #0x98
   10878:      	mov	w1, #0x8                // =8
   1087c:      	blr	x8
   10880:      	ldr	x8, [sp, #0x58]
   10884:      	ldr	x9, [sp, #0x98]
   10888:      	cmp	x8, x9
   1088c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   10890:      	add	x2, x24, #0x18
   10894:      	mov	w8, #0x4                // =4
   10898:      	mov	x0, x22
   1089c:      	mov	w1, #0x8                // =8
   108a0:      	blr	x8
   108a4:      	ldr	x24, [sp, #0x98]
   108a8:      	ldr	x21, [sp, #0x48]
   108ac:      	add	x2, x24, #0x20
   108b0:      	stp	x2, x24, [sp, #0x50]
   108b4:      	ldr	x8, [sp, #0x30]
   108b8:      	cmp	x21, x8
   108bc:      	b.ne	0x108cc <generic_fentry_path+0x641c>
   108c0:      	ldr	x8, [sp, #0x38]
   108c4:      	cmp	x2, x8
   108c8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   108cc:      	mov	w8, #0x4                // =4
   108d0:      	add	x0, sp, #0x70
   108d4:      	mov	w1, #0x8                // =8
   108d8:      	blr	x8
   108dc:      	ldr	x8, [sp, #0x70]
   108e0:      	cmp	x21, x8
   108e4:      	b.eq	0x109d4 <generic_fentry_path+0x6524>
   108e8:      	add	x23, x21, #0x18
   108ec:      	mov	w8, #0x4                // =4
   108f0:      	add	x9, sp, #0x98
   108f4:      	add	x0, sp, #0x98
   108f8:      	mov	w1, #0x8                // =8
   108fc:      	mov	x2, x23
   10900:      	blr	x8
   10904:      	ldr	x8, [sp, #0x98]
   10908:      	cmp	x8, x21
   1090c:      	b.eq	0x109d4 <generic_fentry_path+0x6524>
   10910:      	mov	w8, #0x4                // =4
   10914:      	add	x9, sp, #0x78
   10918:      	add	x0, sp, #0x78
   1091c:      	mov	w1, #0x8                // =8
   10920:      	mov	x2, x23
   10924:      	blr	x8
   10928:      	add	x2, x21, #0x20
   1092c:      	mov	w8, #0x4                // =4
   10930:      	mov	w9, #0x10               // =16
   10934:      	add	x10, sp, #0x80
   10938:      	add	x0, sp, #0x80
   1093c:      	mov	w1, #0x10               // =16
   10940:      	blr	x8
   10944:      	ldr	w21, [sp, #0x84]
   10948:      	ldr	x8, [sp, #0x40]
   1094c:      	ldr	x10, [sp, #0x60]
   10950:      	sub	x12, x10, x8
   10954:      	ldr	w23, [sp, #0x68]
   10958:      	subs	w10, w21, w23
   1095c:      	ldr	x9, [sp, #0x88]
   10960:      	csel	w10, wzr, w10, lo
   10964:      	cmp	w23, w21
   10968:      	csel	w11, w23, w21, lo
   1096c:      	cinc	w13, w11, hi
   10970:      	sub	w14, w23, w13
   10974:      	subs	x12, x12, x13
   10978:      	str	w14, [sp, #0x68]
   1097c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   10980:      	cmp	x12, #0xfff
   10984:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   10988:      	cmp	w23, w21
   1098c:      	b.ls	0x10998 <generic_fentry_path+0x64e8>
   10990:      	mov	w13, #0x2f              // =47
   10994:      	strb	w13, [x8, x12]
   10998:      	add	x19, x8, x12
   1099c:      	cmp	w23, w21
   109a0:      	add	x2, x9, x10
   109a4:      	and	w1, w11, #0xff
   109a8:      	mov	w8, #0x4                // =4
   109ac:      	cinc	x0, x19, hi
   109b0:      	blr	x8
   109b4:      	cmp	w23, w21
   109b8:      	str	x19, [sp, #0x60]
   109bc:      	add	x19, sp, #0x70
   109c0:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   109c4:      	ldr	x21, [sp, #0x78]
   109c8:      	ldp	x2, x24, [sp, #0x50]
   109cc:      	str	x21, [sp, #0x48]
   109d0:      	b	0x10a20 <generic_fentry_path+0x6570>
   109d4:      	add	x2, x24, #0x10
   109d8:      	mov	w8, #0x4                // =4
   109dc:      	add	x9, sp, #0x98
   109e0:      	add	x0, sp, #0x98
   109e4:      	mov	w1, #0x8                // =8
   109e8:      	blr	x8
   109ec:      	ldr	x8, [sp, #0x58]
   109f0:      	ldr	x9, [sp, #0x98]
   109f4:      	cmp	x8, x9
   109f8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   109fc:      	add	x2, x24, #0x18
   10a00:      	mov	w8, #0x4                // =4
   10a04:      	mov	x0, x22
   10a08:      	mov	w1, #0x8                // =8
   10a0c:      	blr	x8
   10a10:      	ldr	x24, [sp, #0x98]
   10a14:      	ldr	x21, [sp, #0x48]
   10a18:      	add	x2, x24, #0x20
   10a1c:      	stp	x2, x24, [sp, #0x50]
   10a20:      	ldr	x8, [sp, #0x30]
   10a24:      	cmp	x21, x8
   10a28:      	b.ne	0x10a38 <generic_fentry_path+0x6588>
   10a2c:      	ldr	x8, [sp, #0x38]
   10a30:      	cmp	x2, x8
   10a34:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   10a38:      	mov	w8, #0x4                // =4
   10a3c:      	add	x0, sp, #0x70
   10a40:      	mov	w1, #0x8                // =8
   10a44:      	blr	x8
   10a48:      	ldr	x8, [sp, #0x70]
   10a4c:      	cmp	x21, x8
   10a50:      	b.eq	0x10b40 <generic_fentry_path+0x6690>
   10a54:      	add	x23, x21, #0x18
   10a58:      	mov	w8, #0x4                // =4
   10a5c:      	add	x9, sp, #0x98
   10a60:      	add	x0, sp, #0x98
   10a64:      	mov	w1, #0x8                // =8
   10a68:      	mov	x2, x23
   10a6c:      	blr	x8
   10a70:      	ldr	x8, [sp, #0x98]
   10a74:      	cmp	x8, x21
   10a78:      	b.eq	0x10b40 <generic_fentry_path+0x6690>
   10a7c:      	mov	w8, #0x4                // =4
   10a80:      	add	x9, sp, #0x78
   10a84:      	add	x0, sp, #0x78
   10a88:      	mov	w1, #0x8                // =8
   10a8c:      	mov	x2, x23
   10a90:      	blr	x8
   10a94:      	add	x2, x21, #0x20
   10a98:      	mov	w8, #0x4                // =4
   10a9c:      	mov	w9, #0x10               // =16
   10aa0:      	add	x10, sp, #0x80
   10aa4:      	add	x0, sp, #0x80
   10aa8:      	mov	w1, #0x10               // =16
   10aac:      	blr	x8
   10ab0:      	ldr	w21, [sp, #0x84]
   10ab4:      	ldr	x8, [sp, #0x40]
   10ab8:      	ldr	x10, [sp, #0x60]
   10abc:      	sub	x12, x10, x8
   10ac0:      	ldr	w23, [sp, #0x68]
   10ac4:      	subs	w10, w21, w23
   10ac8:      	ldr	x9, [sp, #0x88]
   10acc:      	csel	w10, wzr, w10, lo
   10ad0:      	cmp	w23, w21
   10ad4:      	csel	w11, w23, w21, lo
   10ad8:      	cinc	w13, w11, hi
   10adc:      	sub	w14, w23, w13
   10ae0:      	subs	x12, x12, x13
   10ae4:      	str	w14, [sp, #0x68]
   10ae8:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   10aec:      	cmp	x12, #0xfff
   10af0:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   10af4:      	cmp	w23, w21
   10af8:      	b.ls	0x10b04 <generic_fentry_path+0x6654>
   10afc:      	mov	w13, #0x2f              // =47
   10b00:      	strb	w13, [x8, x12]
   10b04:      	add	x19, x8, x12
   10b08:      	cmp	w23, w21
   10b0c:      	add	x2, x9, x10
   10b10:      	and	w1, w11, #0xff
   10b14:      	mov	w8, #0x4                // =4
   10b18:      	cinc	x0, x19, hi
   10b1c:      	blr	x8
   10b20:      	cmp	w23, w21
   10b24:      	str	x19, [sp, #0x60]
   10b28:      	add	x19, sp, #0x70
   10b2c:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   10b30:      	ldr	x21, [sp, #0x78]
   10b34:      	ldp	x2, x24, [sp, #0x50]
   10b38:      	str	x21, [sp, #0x48]
   10b3c:      	b	0x10b8c <generic_fentry_path+0x66dc>
   10b40:      	add	x2, x24, #0x10
   10b44:      	mov	w8, #0x4                // =4
   10b48:      	add	x9, sp, #0x98
   10b4c:      	add	x0, sp, #0x98
   10b50:      	mov	w1, #0x8                // =8
   10b54:      	blr	x8
   10b58:      	ldr	x8, [sp, #0x58]
   10b5c:      	ldr	x9, [sp, #0x98]
   10b60:      	cmp	x8, x9
   10b64:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   10b68:      	add	x2, x24, #0x18
   10b6c:      	mov	w8, #0x4                // =4
   10b70:      	mov	x0, x22
   10b74:      	mov	w1, #0x8                // =8
   10b78:      	blr	x8
   10b7c:      	ldr	x24, [sp, #0x98]
   10b80:      	ldr	x21, [sp, #0x48]
   10b84:      	add	x2, x24, #0x20
   10b88:      	stp	x2, x24, [sp, #0x50]
   10b8c:      	ldr	x8, [sp, #0x30]
   10b90:      	cmp	x21, x8
   10b94:      	b.ne	0x10ba4 <generic_fentry_path+0x66f4>
   10b98:      	ldr	x8, [sp, #0x38]
   10b9c:      	cmp	x2, x8
   10ba0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   10ba4:      	mov	w8, #0x4                // =4
   10ba8:      	add	x0, sp, #0x70
   10bac:      	mov	w1, #0x8                // =8
   10bb0:      	blr	x8
   10bb4:      	ldr	x8, [sp, #0x70]
   10bb8:      	cmp	x21, x8
   10bbc:      	b.eq	0x10cac <generic_fentry_path+0x67fc>
   10bc0:      	add	x23, x21, #0x18
   10bc4:      	mov	w8, #0x4                // =4
   10bc8:      	add	x9, sp, #0x98
   10bcc:      	add	x0, sp, #0x98
   10bd0:      	mov	w1, #0x8                // =8
   10bd4:      	mov	x2, x23
   10bd8:      	blr	x8
   10bdc:      	ldr	x8, [sp, #0x98]
   10be0:      	cmp	x8, x21
   10be4:      	b.eq	0x10cac <generic_fentry_path+0x67fc>
   10be8:      	mov	w8, #0x4                // =4
   10bec:      	add	x9, sp, #0x78
   10bf0:      	add	x0, sp, #0x78
   10bf4:      	mov	w1, #0x8                // =8
   10bf8:      	mov	x2, x23
   10bfc:      	blr	x8
   10c00:      	add	x2, x21, #0x20
   10c04:      	mov	w8, #0x4                // =4
   10c08:      	mov	w9, #0x10               // =16
   10c0c:      	add	x10, sp, #0x80
   10c10:      	add	x0, sp, #0x80
   10c14:      	mov	w1, #0x10               // =16
   10c18:      	blr	x8
   10c1c:      	ldr	w21, [sp, #0x84]
   10c20:      	ldr	x8, [sp, #0x40]
   10c24:      	ldr	x10, [sp, #0x60]
   10c28:      	sub	x12, x10, x8
   10c2c:      	ldr	w23, [sp, #0x68]
   10c30:      	subs	w10, w21, w23
   10c34:      	ldr	x9, [sp, #0x88]
   10c38:      	csel	w10, wzr, w10, lo
   10c3c:      	cmp	w23, w21
   10c40:      	csel	w11, w23, w21, lo
   10c44:      	cinc	w13, w11, hi
   10c48:      	sub	w14, w23, w13
   10c4c:      	subs	x12, x12, x13
   10c50:      	str	w14, [sp, #0x68]
   10c54:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   10c58:      	cmp	x12, #0xfff
   10c5c:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   10c60:      	cmp	w23, w21
   10c64:      	b.ls	0x10c70 <generic_fentry_path+0x67c0>
   10c68:      	mov	w13, #0x2f              // =47
   10c6c:      	strb	w13, [x8, x12]
   10c70:      	add	x19, x8, x12
   10c74:      	cmp	w23, w21
   10c78:      	add	x2, x9, x10
   10c7c:      	and	w1, w11, #0xff
   10c80:      	mov	w8, #0x4                // =4
   10c84:      	cinc	x0, x19, hi
   10c88:      	blr	x8
   10c8c:      	cmp	w23, w21
   10c90:      	str	x19, [sp, #0x60]
   10c94:      	add	x19, sp, #0x70
   10c98:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   10c9c:      	ldr	x21, [sp, #0x78]
   10ca0:      	ldp	x2, x24, [sp, #0x50]
   10ca4:      	str	x21, [sp, #0x48]
   10ca8:      	b	0x10cf8 <generic_fentry_path+0x6848>
   10cac:      	add	x2, x24, #0x10
   10cb0:      	mov	w8, #0x4                // =4
   10cb4:      	add	x9, sp, #0x98
   10cb8:      	add	x0, sp, #0x98
   10cbc:      	mov	w1, #0x8                // =8
   10cc0:      	blr	x8
   10cc4:      	ldr	x8, [sp, #0x58]
   10cc8:      	ldr	x9, [sp, #0x98]
   10ccc:      	cmp	x8, x9
   10cd0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   10cd4:      	add	x2, x24, #0x18
   10cd8:      	mov	w8, #0x4                // =4
   10cdc:      	mov	x0, x22
   10ce0:      	mov	w1, #0x8                // =8
   10ce4:      	blr	x8
   10ce8:      	ldr	x24, [sp, #0x98]
   10cec:      	ldr	x21, [sp, #0x48]
   10cf0:      	add	x2, x24, #0x20
   10cf4:      	stp	x2, x24, [sp, #0x50]
   10cf8:      	ldr	x8, [sp, #0x30]
   10cfc:      	cmp	x21, x8
   10d00:      	b.ne	0x10d10 <generic_fentry_path+0x6860>
   10d04:      	ldr	x8, [sp, #0x38]
   10d08:      	cmp	x2, x8
   10d0c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   10d10:      	mov	w8, #0x4                // =4
   10d14:      	add	x0, sp, #0x70
   10d18:      	mov	w1, #0x8                // =8
   10d1c:      	blr	x8
   10d20:      	ldr	x8, [sp, #0x70]
   10d24:      	cmp	x21, x8
   10d28:      	b.eq	0x10e18 <generic_fentry_path+0x6968>
   10d2c:      	add	x23, x21, #0x18
   10d30:      	mov	w8, #0x4                // =4
   10d34:      	add	x9, sp, #0x98
   10d38:      	add	x0, sp, #0x98
   10d3c:      	mov	w1, #0x8                // =8
   10d40:      	mov	x2, x23
   10d44:      	blr	x8
   10d48:      	ldr	x8, [sp, #0x98]
   10d4c:      	cmp	x8, x21
   10d50:      	b.eq	0x10e18 <generic_fentry_path+0x6968>
   10d54:      	mov	w8, #0x4                // =4
   10d58:      	add	x9, sp, #0x78
   10d5c:      	add	x0, sp, #0x78
   10d60:      	mov	w1, #0x8                // =8
   10d64:      	mov	x2, x23
   10d68:      	blr	x8
   10d6c:      	add	x2, x21, #0x20
   10d70:      	mov	w8, #0x4                // =4
   10d74:      	mov	w9, #0x10               // =16
   10d78:      	add	x10, sp, #0x80
   10d7c:      	add	x0, sp, #0x80
   10d80:      	mov	w1, #0x10               // =16
   10d84:      	blr	x8
   10d88:      	ldr	w21, [sp, #0x84]
   10d8c:      	ldr	x8, [sp, #0x40]
   10d90:      	ldr	x10, [sp, #0x60]
   10d94:      	sub	x12, x10, x8
   10d98:      	ldr	w23, [sp, #0x68]
   10d9c:      	subs	w10, w21, w23
   10da0:      	ldr	x9, [sp, #0x88]
   10da4:      	csel	w10, wzr, w10, lo
   10da8:      	cmp	w23, w21
   10dac:      	csel	w11, w23, w21, lo
   10db0:      	cinc	w13, w11, hi
   10db4:      	sub	w14, w23, w13
   10db8:      	subs	x12, x12, x13
   10dbc:      	str	w14, [sp, #0x68]
   10dc0:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   10dc4:      	cmp	x12, #0xfff
   10dc8:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   10dcc:      	cmp	w23, w21
   10dd0:      	b.ls	0x10ddc <generic_fentry_path+0x692c>
   10dd4:      	mov	w13, #0x2f              // =47
   10dd8:      	strb	w13, [x8, x12]
   10ddc:      	add	x19, x8, x12
   10de0:      	cmp	w23, w21
   10de4:      	add	x2, x9, x10
   10de8:      	and	w1, w11, #0xff
   10dec:      	mov	w8, #0x4                // =4
   10df0:      	cinc	x0, x19, hi
   10df4:      	blr	x8
   10df8:      	cmp	w23, w21
   10dfc:      	str	x19, [sp, #0x60]
   10e00:      	add	x19, sp, #0x70
   10e04:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   10e08:      	ldr	x21, [sp, #0x78]
   10e0c:      	ldp	x2, x24, [sp, #0x50]
   10e10:      	str	x21, [sp, #0x48]
   10e14:      	b	0x10e64 <generic_fentry_path+0x69b4>
   10e18:      	add	x2, x24, #0x10
   10e1c:      	mov	w8, #0x4                // =4
   10e20:      	add	x9, sp, #0x98
   10e24:      	add	x0, sp, #0x98
   10e28:      	mov	w1, #0x8                // =8
   10e2c:      	blr	x8
   10e30:      	ldr	x8, [sp, #0x58]
   10e34:      	ldr	x9, [sp, #0x98]
   10e38:      	cmp	x8, x9
   10e3c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   10e40:      	add	x2, x24, #0x18
   10e44:      	mov	w8, #0x4                // =4
   10e48:      	mov	x0, x22
   10e4c:      	mov	w1, #0x8                // =8
   10e50:      	blr	x8
   10e54:      	ldr	x24, [sp, #0x98]
   10e58:      	ldr	x21, [sp, #0x48]
   10e5c:      	add	x2, x24, #0x20
   10e60:      	stp	x2, x24, [sp, #0x50]
   10e64:      	ldr	x8, [sp, #0x30]
   10e68:      	cmp	x21, x8
   10e6c:      	b.ne	0x10e7c <generic_fentry_path+0x69cc>
   10e70:      	ldr	x8, [sp, #0x38]
   10e74:      	cmp	x2, x8
   10e78:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   10e7c:      	mov	w8, #0x4                // =4
   10e80:      	add	x0, sp, #0x70
   10e84:      	mov	w1, #0x8                // =8
   10e88:      	blr	x8
   10e8c:      	ldr	x8, [sp, #0x70]
   10e90:      	cmp	x21, x8
   10e94:      	b.eq	0x10f84 <generic_fentry_path+0x6ad4>
   10e98:      	add	x23, x21, #0x18
   10e9c:      	mov	w8, #0x4                // =4
   10ea0:      	add	x9, sp, #0x98
   10ea4:      	add	x0, sp, #0x98
   10ea8:      	mov	w1, #0x8                // =8
   10eac:      	mov	x2, x23
   10eb0:      	blr	x8
   10eb4:      	ldr	x8, [sp, #0x98]
   10eb8:      	cmp	x8, x21
   10ebc:      	b.eq	0x10f84 <generic_fentry_path+0x6ad4>
   10ec0:      	mov	w8, #0x4                // =4
   10ec4:      	add	x9, sp, #0x78
   10ec8:      	add	x0, sp, #0x78
   10ecc:      	mov	w1, #0x8                // =8
   10ed0:      	mov	x2, x23
   10ed4:      	blr	x8
   10ed8:      	add	x2, x21, #0x20
   10edc:      	mov	w8, #0x4                // =4
   10ee0:      	mov	w9, #0x10               // =16
   10ee4:      	add	x10, sp, #0x80
   10ee8:      	add	x0, sp, #0x80
   10eec:      	mov	w1, #0x10               // =16
   10ef0:      	blr	x8
   10ef4:      	ldr	w21, [sp, #0x84]
   10ef8:      	ldr	x8, [sp, #0x40]
   10efc:      	ldr	x10, [sp, #0x60]
   10f00:      	sub	x12, x10, x8
   10f04:      	ldr	w23, [sp, #0x68]
   10f08:      	subs	w10, w21, w23
   10f0c:      	ldr	x9, [sp, #0x88]
   10f10:      	csel	w10, wzr, w10, lo
   10f14:      	cmp	w23, w21
   10f18:      	csel	w11, w23, w21, lo
   10f1c:      	cinc	w13, w11, hi
   10f20:      	sub	w14, w23, w13
   10f24:      	subs	x12, x12, x13
   10f28:      	str	w14, [sp, #0x68]
   10f2c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   10f30:      	cmp	x12, #0xfff
   10f34:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   10f38:      	cmp	w23, w21
   10f3c:      	b.ls	0x10f48 <generic_fentry_path+0x6a98>
   10f40:      	mov	w13, #0x2f              // =47
   10f44:      	strb	w13, [x8, x12]
   10f48:      	add	x19, x8, x12
   10f4c:      	cmp	w23, w21
   10f50:      	add	x2, x9, x10
   10f54:      	and	w1, w11, #0xff
   10f58:      	mov	w8, #0x4                // =4
   10f5c:      	cinc	x0, x19, hi
   10f60:      	blr	x8
   10f64:      	cmp	w23, w21
   10f68:      	str	x19, [sp, #0x60]
   10f6c:      	add	x19, sp, #0x70
   10f70:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   10f74:      	ldr	x21, [sp, #0x78]
   10f78:      	ldp	x2, x24, [sp, #0x50]
   10f7c:      	str	x21, [sp, #0x48]
   10f80:      	b	0x10fd0 <generic_fentry_path+0x6b20>
   10f84:      	add	x2, x24, #0x10
   10f88:      	mov	w8, #0x4                // =4
   10f8c:      	add	x9, sp, #0x98
   10f90:      	add	x0, sp, #0x98
   10f94:      	mov	w1, #0x8                // =8
   10f98:      	blr	x8
   10f9c:      	ldr	x8, [sp, #0x58]
   10fa0:      	ldr	x9, [sp, #0x98]
   10fa4:      	cmp	x8, x9
   10fa8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   10fac:      	add	x2, x24, #0x18
   10fb0:      	mov	w8, #0x4                // =4
   10fb4:      	mov	x0, x22
   10fb8:      	mov	w1, #0x8                // =8
   10fbc:      	blr	x8
   10fc0:      	ldr	x24, [sp, #0x98]
   10fc4:      	ldr	x21, [sp, #0x48]
   10fc8:      	add	x2, x24, #0x20
   10fcc:      	stp	x2, x24, [sp, #0x50]
   10fd0:      	ldr	x8, [sp, #0x30]
   10fd4:      	cmp	x21, x8
   10fd8:      	b.ne	0x10fe8 <generic_fentry_path+0x6b38>
   10fdc:      	ldr	x8, [sp, #0x38]
   10fe0:      	cmp	x2, x8
   10fe4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   10fe8:      	mov	w8, #0x4                // =4
   10fec:      	add	x0, sp, #0x70
   10ff0:      	mov	w1, #0x8                // =8
   10ff4:      	blr	x8
   10ff8:      	ldr	x8, [sp, #0x70]
   10ffc:      	cmp	x21, x8
   11000:      	b.eq	0x110f0 <generic_fentry_path+0x6c40>
   11004:      	add	x23, x21, #0x18
   11008:      	mov	w8, #0x4                // =4
   1100c:      	add	x9, sp, #0x98
   11010:      	add	x0, sp, #0x98
   11014:      	mov	w1, #0x8                // =8
   11018:      	mov	x2, x23
   1101c:      	blr	x8
   11020:      	ldr	x8, [sp, #0x98]
   11024:      	cmp	x8, x21
   11028:      	b.eq	0x110f0 <generic_fentry_path+0x6c40>
   1102c:      	mov	w8, #0x4                // =4
   11030:      	add	x9, sp, #0x78
   11034:      	add	x0, sp, #0x78
   11038:      	mov	w1, #0x8                // =8
   1103c:      	mov	x2, x23
   11040:      	blr	x8
   11044:      	add	x2, x21, #0x20
   11048:      	mov	w8, #0x4                // =4
   1104c:      	mov	w9, #0x10               // =16
   11050:      	add	x10, sp, #0x80
   11054:      	add	x0, sp, #0x80
   11058:      	mov	w1, #0x10               // =16
   1105c:      	blr	x8
   11060:      	ldr	w21, [sp, #0x84]
   11064:      	ldr	x8, [sp, #0x40]
   11068:      	ldr	x10, [sp, #0x60]
   1106c:      	sub	x12, x10, x8
   11070:      	ldr	w23, [sp, #0x68]
   11074:      	subs	w10, w21, w23
   11078:      	ldr	x9, [sp, #0x88]
   1107c:      	csel	w10, wzr, w10, lo
   11080:      	cmp	w23, w21
   11084:      	csel	w11, w23, w21, lo
   11088:      	cinc	w13, w11, hi
   1108c:      	sub	w14, w23, w13
   11090:      	subs	x12, x12, x13
   11094:      	str	w14, [sp, #0x68]
   11098:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   1109c:      	cmp	x12, #0xfff
   110a0:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   110a4:      	cmp	w23, w21
   110a8:      	b.ls	0x110b4 <generic_fentry_path+0x6c04>
   110ac:      	mov	w13, #0x2f              // =47
   110b0:      	strb	w13, [x8, x12]
   110b4:      	add	x19, x8, x12
   110b8:      	cmp	w23, w21
   110bc:      	add	x2, x9, x10
   110c0:      	and	w1, w11, #0xff
   110c4:      	mov	w8, #0x4                // =4
   110c8:      	cinc	x0, x19, hi
   110cc:      	blr	x8
   110d0:      	cmp	w23, w21
   110d4:      	str	x19, [sp, #0x60]
   110d8:      	add	x19, sp, #0x70
   110dc:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   110e0:      	ldr	x21, [sp, #0x78]
   110e4:      	ldp	x2, x24, [sp, #0x50]
   110e8:      	str	x21, [sp, #0x48]
   110ec:      	b	0x1113c <generic_fentry_path+0x6c8c>
   110f0:      	add	x2, x24, #0x10
   110f4:      	mov	w8, #0x4                // =4
   110f8:      	add	x9, sp, #0x98
   110fc:      	add	x0, sp, #0x98
   11100:      	mov	w1, #0x8                // =8
   11104:      	blr	x8
   11108:      	ldr	x8, [sp, #0x58]
   1110c:      	ldr	x9, [sp, #0x98]
   11110:      	cmp	x8, x9
   11114:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   11118:      	add	x2, x24, #0x18
   1111c:      	mov	w8, #0x4                // =4
   11120:      	mov	x0, x22
   11124:      	mov	w1, #0x8                // =8
   11128:      	blr	x8
   1112c:      	ldr	x24, [sp, #0x98]
   11130:      	ldr	x21, [sp, #0x48]
   11134:      	add	x2, x24, #0x20
   11138:      	stp	x2, x24, [sp, #0x50]
   1113c:      	ldr	x8, [sp, #0x30]
   11140:      	cmp	x21, x8
   11144:      	b.ne	0x11154 <generic_fentry_path+0x6ca4>
   11148:      	ldr	x8, [sp, #0x38]
   1114c:      	cmp	x2, x8
   11150:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   11154:      	mov	w8, #0x4                // =4
   11158:      	add	x0, sp, #0x70
   1115c:      	mov	w1, #0x8                // =8
   11160:      	blr	x8
   11164:      	ldr	x8, [sp, #0x70]
   11168:      	cmp	x21, x8
   1116c:      	b.eq	0x1125c <generic_fentry_path+0x6dac>
   11170:      	add	x23, x21, #0x18
   11174:      	mov	w8, #0x4                // =4
   11178:      	add	x9, sp, #0x98
   1117c:      	add	x0, sp, #0x98
   11180:      	mov	w1, #0x8                // =8
   11184:      	mov	x2, x23
   11188:      	blr	x8
   1118c:      	ldr	x8, [sp, #0x98]
   11190:      	cmp	x8, x21
   11194:      	b.eq	0x1125c <generic_fentry_path+0x6dac>
   11198:      	mov	w8, #0x4                // =4
   1119c:      	add	x9, sp, #0x78
   111a0:      	add	x0, sp, #0x78
   111a4:      	mov	w1, #0x8                // =8
   111a8:      	mov	x2, x23
   111ac:      	blr	x8
   111b0:      	add	x2, x21, #0x20
   111b4:      	mov	w8, #0x4                // =4
   111b8:      	mov	w9, #0x10               // =16
   111bc:      	add	x10, sp, #0x80
   111c0:      	add	x0, sp, #0x80
   111c4:      	mov	w1, #0x10               // =16
   111c8:      	blr	x8
   111cc:      	ldr	w21, [sp, #0x84]
   111d0:      	ldr	x8, [sp, #0x40]
   111d4:      	ldr	x10, [sp, #0x60]
   111d8:      	sub	x12, x10, x8
   111dc:      	ldr	w23, [sp, #0x68]
   111e0:      	subs	w10, w21, w23
   111e4:      	ldr	x9, [sp, #0x88]
   111e8:      	csel	w10, wzr, w10, lo
   111ec:      	cmp	w23, w21
   111f0:      	csel	w11, w23, w21, lo
   111f4:      	cinc	w13, w11, hi
   111f8:      	sub	w14, w23, w13
   111fc:      	subs	x12, x12, x13
   11200:      	str	w14, [sp, #0x68]
   11204:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   11208:      	cmp	x12, #0xfff
   1120c:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   11210:      	cmp	w23, w21
   11214:      	b.ls	0x11220 <generic_fentry_path+0x6d70>
   11218:      	mov	w13, #0x2f              // =47
   1121c:      	strb	w13, [x8, x12]
   11220:      	add	x19, x8, x12
   11224:      	cmp	w23, w21
   11228:      	add	x2, x9, x10
   1122c:      	and	w1, w11, #0xff
   11230:      	mov	w8, #0x4                // =4
   11234:      	cinc	x0, x19, hi
   11238:      	blr	x8
   1123c:      	cmp	w23, w21
   11240:      	str	x19, [sp, #0x60]
   11244:      	add	x19, sp, #0x70
   11248:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   1124c:      	ldr	x21, [sp, #0x78]
   11250:      	ldp	x2, x24, [sp, #0x50]
   11254:      	str	x21, [sp, #0x48]
   11258:      	b	0x112a8 <generic_fentry_path+0x6df8>
   1125c:      	add	x2, x24, #0x10
   11260:      	mov	w8, #0x4                // =4
   11264:      	add	x9, sp, #0x98
   11268:      	add	x0, sp, #0x98
   1126c:      	mov	w1, #0x8                // =8
   11270:      	blr	x8
   11274:      	ldr	x8, [sp, #0x58]
   11278:      	ldr	x9, [sp, #0x98]
   1127c:      	cmp	x8, x9
   11280:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   11284:      	add	x2, x24, #0x18
   11288:      	mov	w8, #0x4                // =4
   1128c:      	mov	x0, x22
   11290:      	mov	w1, #0x8                // =8
   11294:      	blr	x8
   11298:      	ldr	x24, [sp, #0x98]
   1129c:      	ldr	x21, [sp, #0x48]
   112a0:      	add	x2, x24, #0x20
   112a4:      	stp	x2, x24, [sp, #0x50]
   112a8:      	ldr	x8, [sp, #0x30]
   112ac:      	cmp	x21, x8
   112b0:      	b.ne	0x112c0 <generic_fentry_path+0x6e10>
   112b4:      	ldr	x8, [sp, #0x38]
   112b8:      	cmp	x2, x8
   112bc:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   112c0:      	mov	w8, #0x4                // =4
   112c4:      	add	x0, sp, #0x70
   112c8:      	mov	w1, #0x8                // =8
   112cc:      	blr	x8
   112d0:      	ldr	x8, [sp, #0x70]
   112d4:      	cmp	x21, x8
   112d8:      	b.eq	0x113c8 <generic_fentry_path+0x6f18>
   112dc:      	add	x23, x21, #0x18
   112e0:      	mov	w8, #0x4                // =4
   112e4:      	add	x9, sp, #0x98
   112e8:      	add	x0, sp, #0x98
   112ec:      	mov	w1, #0x8                // =8
   112f0:      	mov	x2, x23
   112f4:      	blr	x8
   112f8:      	ldr	x8, [sp, #0x98]
   112fc:      	cmp	x8, x21
   11300:      	b.eq	0x113c8 <generic_fentry_path+0x6f18>
   11304:      	mov	w8, #0x4                // =4
   11308:      	add	x9, sp, #0x78
   1130c:      	add	x0, sp, #0x78
   11310:      	mov	w1, #0x8                // =8
   11314:      	mov	x2, x23
   11318:      	blr	x8
   1131c:      	add	x2, x21, #0x20
   11320:      	mov	w8, #0x4                // =4
   11324:      	mov	w9, #0x10               // =16
   11328:      	add	x10, sp, #0x80
   1132c:      	add	x0, sp, #0x80
   11330:      	mov	w1, #0x10               // =16
   11334:      	blr	x8
   11338:      	ldr	w21, [sp, #0x84]
   1133c:      	ldr	x8, [sp, #0x40]
   11340:      	ldr	x10, [sp, #0x60]
   11344:      	sub	x12, x10, x8
   11348:      	ldr	w23, [sp, #0x68]
   1134c:      	subs	w10, w21, w23
   11350:      	ldr	x9, [sp, #0x88]
   11354:      	csel	w10, wzr, w10, lo
   11358:      	cmp	w23, w21
   1135c:      	csel	w11, w23, w21, lo
   11360:      	cinc	w13, w11, hi
   11364:      	sub	w14, w23, w13
   11368:      	subs	x12, x12, x13
   1136c:      	str	w14, [sp, #0x68]
   11370:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   11374:      	cmp	x12, #0xfff
   11378:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   1137c:      	cmp	w23, w21
   11380:      	b.ls	0x1138c <generic_fentry_path+0x6edc>
   11384:      	mov	w13, #0x2f              // =47
   11388:      	strb	w13, [x8, x12]
   1138c:      	add	x19, x8, x12
   11390:      	cmp	w23, w21
   11394:      	add	x2, x9, x10
   11398:      	and	w1, w11, #0xff
   1139c:      	mov	w8, #0x4                // =4
   113a0:      	cinc	x0, x19, hi
   113a4:      	blr	x8
   113a8:      	cmp	w23, w21
   113ac:      	str	x19, [sp, #0x60]
   113b0:      	add	x19, sp, #0x70
   113b4:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   113b8:      	ldr	x21, [sp, #0x78]
   113bc:      	ldp	x2, x24, [sp, #0x50]
   113c0:      	str	x21, [sp, #0x48]
   113c4:      	b	0x11414 <generic_fentry_path+0x6f64>
   113c8:      	add	x2, x24, #0x10
   113cc:      	mov	w8, #0x4                // =4
   113d0:      	add	x9, sp, #0x98
   113d4:      	add	x0, sp, #0x98
   113d8:      	mov	w1, #0x8                // =8
   113dc:      	blr	x8
   113e0:      	ldr	x8, [sp, #0x58]
   113e4:      	ldr	x9, [sp, #0x98]
   113e8:      	cmp	x8, x9
   113ec:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   113f0:      	add	x2, x24, #0x18
   113f4:      	mov	w8, #0x4                // =4
   113f8:      	mov	x0, x22
   113fc:      	mov	w1, #0x8                // =8
   11400:      	blr	x8
   11404:      	ldr	x24, [sp, #0x98]
   11408:      	ldr	x21, [sp, #0x48]
   1140c:      	add	x2, x24, #0x20
   11410:      	stp	x2, x24, [sp, #0x50]
   11414:      	ldr	x8, [sp, #0x30]
   11418:      	cmp	x21, x8
   1141c:      	b.ne	0x1142c <generic_fentry_path+0x6f7c>
   11420:      	ldr	x8, [sp, #0x38]
   11424:      	cmp	x2, x8
   11428:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   1142c:      	mov	w8, #0x4                // =4
   11430:      	add	x0, sp, #0x70
   11434:      	mov	w1, #0x8                // =8
   11438:      	blr	x8
   1143c:      	ldr	x8, [sp, #0x70]
   11440:      	cmp	x21, x8
   11444:      	b.eq	0x11534 <generic_fentry_path+0x7084>
   11448:      	add	x23, x21, #0x18
   1144c:      	mov	w8, #0x4                // =4
   11450:      	add	x9, sp, #0x98
   11454:      	add	x0, sp, #0x98
   11458:      	mov	w1, #0x8                // =8
   1145c:      	mov	x2, x23
   11460:      	blr	x8
   11464:      	ldr	x8, [sp, #0x98]
   11468:      	cmp	x8, x21
   1146c:      	b.eq	0x11534 <generic_fentry_path+0x7084>
   11470:      	mov	w8, #0x4                // =4
   11474:      	add	x9, sp, #0x78
   11478:      	add	x0, sp, #0x78
   1147c:      	mov	w1, #0x8                // =8
   11480:      	mov	x2, x23
   11484:      	blr	x8
   11488:      	add	x2, x21, #0x20
   1148c:      	mov	w8, #0x4                // =4
   11490:      	mov	w9, #0x10               // =16
   11494:      	add	x10, sp, #0x80
   11498:      	add	x0, sp, #0x80
   1149c:      	mov	w1, #0x10               // =16
   114a0:      	blr	x8
   114a4:      	ldr	w21, [sp, #0x84]
   114a8:      	ldr	x8, [sp, #0x40]
   114ac:      	ldr	x10, [sp, #0x60]
   114b0:      	sub	x12, x10, x8
   114b4:      	ldr	w23, [sp, #0x68]
   114b8:      	subs	w10, w21, w23
   114bc:      	ldr	x9, [sp, #0x88]
   114c0:      	csel	w10, wzr, w10, lo
   114c4:      	cmp	w23, w21
   114c8:      	csel	w11, w23, w21, lo
   114cc:      	cinc	w13, w11, hi
   114d0:      	sub	w14, w23, w13
   114d4:      	subs	x12, x12, x13
   114d8:      	str	w14, [sp, #0x68]
   114dc:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   114e0:      	cmp	x12, #0xfff
   114e4:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   114e8:      	cmp	w23, w21
   114ec:      	b.ls	0x114f8 <generic_fentry_path+0x7048>
   114f0:      	mov	w13, #0x2f              // =47
   114f4:      	strb	w13, [x8, x12]
   114f8:      	add	x19, x8, x12
   114fc:      	cmp	w23, w21
   11500:      	add	x2, x9, x10
   11504:      	and	w1, w11, #0xff
   11508:      	mov	w8, #0x4                // =4
   1150c:      	cinc	x0, x19, hi
   11510:      	blr	x8
   11514:      	cmp	w23, w21
   11518:      	str	x19, [sp, #0x60]
   1151c:      	add	x19, sp, #0x70
   11520:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   11524:      	ldr	x21, [sp, #0x78]
   11528:      	ldp	x2, x24, [sp, #0x50]
   1152c:      	str	x21, [sp, #0x48]
   11530:      	b	0x11580 <generic_fentry_path+0x70d0>
   11534:      	add	x2, x24, #0x10
   11538:      	mov	w8, #0x4                // =4
   1153c:      	add	x9, sp, #0x98
   11540:      	add	x0, sp, #0x98
   11544:      	mov	w1, #0x8                // =8
   11548:      	blr	x8
   1154c:      	ldr	x8, [sp, #0x58]
   11550:      	ldr	x9, [sp, #0x98]
   11554:      	cmp	x8, x9
   11558:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   1155c:      	add	x2, x24, #0x18
   11560:      	mov	w8, #0x4                // =4
   11564:      	mov	x0, x22
   11568:      	mov	w1, #0x8                // =8
   1156c:      	blr	x8
   11570:      	ldr	x24, [sp, #0x98]
   11574:      	ldr	x21, [sp, #0x48]
   11578:      	add	x2, x24, #0x20
   1157c:      	stp	x2, x24, [sp, #0x50]
   11580:      	ldr	x8, [sp, #0x30]
   11584:      	cmp	x21, x8
   11588:      	b.ne	0x11598 <generic_fentry_path+0x70e8>
   1158c:      	ldr	x8, [sp, #0x38]
   11590:      	cmp	x2, x8
   11594:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   11598:      	mov	w8, #0x4                // =4
   1159c:      	add	x0, sp, #0x70
   115a0:      	mov	w1, #0x8                // =8
   115a4:      	blr	x8
   115a8:      	ldr	x8, [sp, #0x70]
   115ac:      	cmp	x21, x8
   115b0:      	b.eq	0x116a0 <generic_fentry_path+0x71f0>
   115b4:      	add	x23, x21, #0x18
   115b8:      	mov	w8, #0x4                // =4
   115bc:      	add	x9, sp, #0x98
   115c0:      	add	x0, sp, #0x98
   115c4:      	mov	w1, #0x8                // =8
   115c8:      	mov	x2, x23
   115cc:      	blr	x8
   115d0:      	ldr	x8, [sp, #0x98]
   115d4:      	cmp	x8, x21
   115d8:      	b.eq	0x116a0 <generic_fentry_path+0x71f0>
   115dc:      	mov	w8, #0x4                // =4
   115e0:      	add	x9, sp, #0x78
   115e4:      	add	x0, sp, #0x78
   115e8:      	mov	w1, #0x8                // =8
   115ec:      	mov	x2, x23
   115f0:      	blr	x8
   115f4:      	add	x2, x21, #0x20
   115f8:      	mov	w8, #0x4                // =4
   115fc:      	mov	w9, #0x10               // =16
   11600:      	add	x10, sp, #0x80
   11604:      	add	x0, sp, #0x80
   11608:      	mov	w1, #0x10               // =16
   1160c:      	blr	x8
   11610:      	ldr	w21, [sp, #0x84]
   11614:      	ldr	x8, [sp, #0x40]
   11618:      	ldr	x10, [sp, #0x60]
   1161c:      	sub	x12, x10, x8
   11620:      	ldr	w23, [sp, #0x68]
   11624:      	subs	w10, w21, w23
   11628:      	ldr	x9, [sp, #0x88]
   1162c:      	csel	w10, wzr, w10, lo
   11630:      	cmp	w23, w21
   11634:      	csel	w11, w23, w21, lo
   11638:      	cinc	w13, w11, hi
   1163c:      	sub	w14, w23, w13
   11640:      	subs	x12, x12, x13
   11644:      	str	w14, [sp, #0x68]
   11648:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   1164c:      	cmp	x12, #0xfff
   11650:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   11654:      	cmp	w23, w21
   11658:      	b.ls	0x11664 <generic_fentry_path+0x71b4>
   1165c:      	mov	w13, #0x2f              // =47
   11660:      	strb	w13, [x8, x12]
   11664:      	add	x19, x8, x12
   11668:      	cmp	w23, w21
   1166c:      	add	x2, x9, x10
   11670:      	and	w1, w11, #0xff
   11674:      	mov	w8, #0x4                // =4
   11678:      	cinc	x0, x19, hi
   1167c:      	blr	x8
   11680:      	cmp	w23, w21
   11684:      	str	x19, [sp, #0x60]
   11688:      	add	x19, sp, #0x70
   1168c:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   11690:      	ldr	x21, [sp, #0x78]
   11694:      	ldp	x2, x24, [sp, #0x50]
   11698:      	str	x21, [sp, #0x48]
   1169c:      	b	0x116ec <generic_fentry_path+0x723c>
   116a0:      	add	x2, x24, #0x10
   116a4:      	mov	w8, #0x4                // =4
   116a8:      	add	x9, sp, #0x98
   116ac:      	add	x0, sp, #0x98
   116b0:      	mov	w1, #0x8                // =8
   116b4:      	blr	x8
   116b8:      	ldr	x8, [sp, #0x58]
   116bc:      	ldr	x9, [sp, #0x98]
   116c0:      	cmp	x8, x9
   116c4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   116c8:      	add	x2, x24, #0x18
   116cc:      	mov	w8, #0x4                // =4
   116d0:      	mov	x0, x22
   116d4:      	mov	w1, #0x8                // =8
   116d8:      	blr	x8
   116dc:      	ldr	x24, [sp, #0x98]
   116e0:      	ldr	x21, [sp, #0x48]
   116e4:      	add	x2, x24, #0x20
   116e8:      	stp	x2, x24, [sp, #0x50]
   116ec:      	ldr	x8, [sp, #0x30]
   116f0:      	cmp	x21, x8
   116f4:      	b.ne	0x11704 <generic_fentry_path+0x7254>
   116f8:      	ldr	x8, [sp, #0x38]
   116fc:      	cmp	x2, x8
   11700:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   11704:      	mov	w8, #0x4                // =4
   11708:      	add	x0, sp, #0x70
   1170c:      	mov	w1, #0x8                // =8
   11710:      	blr	x8
   11714:      	ldr	x8, [sp, #0x70]
   11718:      	cmp	x21, x8
   1171c:      	b.eq	0x1180c <generic_fentry_path+0x735c>
   11720:      	add	x23, x21, #0x18
   11724:      	mov	w8, #0x4                // =4
   11728:      	add	x9, sp, #0x98
   1172c:      	add	x0, sp, #0x98
   11730:      	mov	w1, #0x8                // =8
   11734:      	mov	x2, x23
   11738:      	blr	x8
   1173c:      	ldr	x8, [sp, #0x98]
   11740:      	cmp	x8, x21
   11744:      	b.eq	0x1180c <generic_fentry_path+0x735c>
   11748:      	mov	w8, #0x4                // =4
   1174c:      	add	x9, sp, #0x78
   11750:      	add	x0, sp, #0x78
   11754:      	mov	w1, #0x8                // =8
   11758:      	mov	x2, x23
   1175c:      	blr	x8
   11760:      	add	x2, x21, #0x20
   11764:      	mov	w8, #0x4                // =4
   11768:      	mov	w9, #0x10               // =16
   1176c:      	add	x10, sp, #0x80
   11770:      	add	x0, sp, #0x80
   11774:      	mov	w1, #0x10               // =16
   11778:      	blr	x8
   1177c:      	ldr	w21, [sp, #0x84]
   11780:      	ldr	x8, [sp, #0x40]
   11784:      	ldr	x10, [sp, #0x60]
   11788:      	sub	x12, x10, x8
   1178c:      	ldr	w23, [sp, #0x68]
   11790:      	subs	w10, w21, w23
   11794:      	ldr	x9, [sp, #0x88]
   11798:      	csel	w10, wzr, w10, lo
   1179c:      	cmp	w23, w21
   117a0:      	csel	w11, w23, w21, lo
   117a4:      	cinc	w13, w11, hi
   117a8:      	sub	w14, w23, w13
   117ac:      	subs	x12, x12, x13
   117b0:      	str	w14, [sp, #0x68]
   117b4:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   117b8:      	cmp	x12, #0xfff
   117bc:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   117c0:      	cmp	w23, w21
   117c4:      	b.ls	0x117d0 <generic_fentry_path+0x7320>
   117c8:      	mov	w13, #0x2f              // =47
   117cc:      	strb	w13, [x8, x12]
   117d0:      	add	x19, x8, x12
   117d4:      	cmp	w23, w21
   117d8:      	add	x2, x9, x10
   117dc:      	and	w1, w11, #0xff
   117e0:      	mov	w8, #0x4                // =4
   117e4:      	cinc	x0, x19, hi
   117e8:      	blr	x8
   117ec:      	cmp	w23, w21
   117f0:      	str	x19, [sp, #0x60]
   117f4:      	add	x19, sp, #0x70
   117f8:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   117fc:      	ldr	x21, [sp, #0x78]
   11800:      	ldp	x2, x24, [sp, #0x50]
   11804:      	str	x21, [sp, #0x48]
   11808:      	b	0x11858 <generic_fentry_path+0x73a8>
   1180c:      	add	x2, x24, #0x10
   11810:      	mov	w8, #0x4                // =4
   11814:      	add	x9, sp, #0x98
   11818:      	add	x0, sp, #0x98
   1181c:      	mov	w1, #0x8                // =8
   11820:      	blr	x8
   11824:      	ldr	x8, [sp, #0x58]
   11828:      	ldr	x9, [sp, #0x98]
   1182c:      	cmp	x8, x9
   11830:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   11834:      	add	x2, x24, #0x18
   11838:      	mov	w8, #0x4                // =4
   1183c:      	mov	x0, x22
   11840:      	mov	w1, #0x8                // =8
   11844:      	blr	x8
   11848:      	ldr	x24, [sp, #0x98]
   1184c:      	ldr	x21, [sp, #0x48]
   11850:      	add	x2, x24, #0x20
   11854:      	stp	x2, x24, [sp, #0x50]
   11858:      	ldr	x8, [sp, #0x30]
   1185c:      	cmp	x21, x8
   11860:      	b.ne	0x11870 <generic_fentry_path+0x73c0>
   11864:      	ldr	x8, [sp, #0x38]
   11868:      	cmp	x2, x8
   1186c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   11870:      	mov	w8, #0x4                // =4
   11874:      	add	x0, sp, #0x70
   11878:      	mov	w1, #0x8                // =8
   1187c:      	blr	x8
   11880:      	ldr	x8, [sp, #0x70]
   11884:      	cmp	x21, x8
   11888:      	b.eq	0x11978 <generic_fentry_path+0x74c8>
   1188c:      	add	x23, x21, #0x18
   11890:      	mov	w8, #0x4                // =4
   11894:      	add	x9, sp, #0x98
   11898:      	add	x0, sp, #0x98
   1189c:      	mov	w1, #0x8                // =8
   118a0:      	mov	x2, x23
   118a4:      	blr	x8
   118a8:      	ldr	x8, [sp, #0x98]
   118ac:      	cmp	x8, x21
   118b0:      	b.eq	0x11978 <generic_fentry_path+0x74c8>
   118b4:      	mov	w8, #0x4                // =4
   118b8:      	add	x9, sp, #0x78
   118bc:      	add	x0, sp, #0x78
   118c0:      	mov	w1, #0x8                // =8
   118c4:      	mov	x2, x23
   118c8:      	blr	x8
   118cc:      	add	x2, x21, #0x20
   118d0:      	mov	w8, #0x4                // =4
   118d4:      	mov	w9, #0x10               // =16
   118d8:      	add	x10, sp, #0x80
   118dc:      	add	x0, sp, #0x80
   118e0:      	mov	w1, #0x10               // =16
   118e4:      	blr	x8
   118e8:      	ldr	w21, [sp, #0x84]
   118ec:      	ldr	x8, [sp, #0x40]
   118f0:      	ldr	x10, [sp, #0x60]
   118f4:      	sub	x12, x10, x8
   118f8:      	ldr	w23, [sp, #0x68]
   118fc:      	subs	w10, w21, w23
   11900:      	ldr	x9, [sp, #0x88]
   11904:      	csel	w10, wzr, w10, lo
   11908:      	cmp	w23, w21
   1190c:      	csel	w11, w23, w21, lo
   11910:      	cinc	w13, w11, hi
   11914:      	sub	w14, w23, w13
   11918:      	subs	x12, x12, x13
   1191c:      	str	w14, [sp, #0x68]
   11920:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   11924:      	cmp	x12, #0xfff
   11928:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   1192c:      	cmp	w23, w21
   11930:      	b.ls	0x1193c <generic_fentry_path+0x748c>
   11934:      	mov	w13, #0x2f              // =47
   11938:      	strb	w13, [x8, x12]
   1193c:      	add	x19, x8, x12
   11940:      	cmp	w23, w21
   11944:      	add	x2, x9, x10
   11948:      	and	w1, w11, #0xff
   1194c:      	mov	w8, #0x4                // =4
   11950:      	cinc	x0, x19, hi
   11954:      	blr	x8
   11958:      	cmp	w23, w21
   1195c:      	str	x19, [sp, #0x60]
   11960:      	add	x19, sp, #0x70
   11964:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   11968:      	ldr	x21, [sp, #0x78]
   1196c:      	ldp	x2, x24, [sp, #0x50]
   11970:      	str	x21, [sp, #0x48]
   11974:      	b	0x119c4 <generic_fentry_path+0x7514>
   11978:      	add	x2, x24, #0x10
   1197c:      	mov	w8, #0x4                // =4
   11980:      	add	x9, sp, #0x98
   11984:      	add	x0, sp, #0x98
   11988:      	mov	w1, #0x8                // =8
   1198c:      	blr	x8
   11990:      	ldr	x8, [sp, #0x58]
   11994:      	ldr	x9, [sp, #0x98]
   11998:      	cmp	x8, x9
   1199c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   119a0:      	add	x2, x24, #0x18
   119a4:      	mov	w8, #0x4                // =4
   119a8:      	mov	x0, x22
   119ac:      	mov	w1, #0x8                // =8
   119b0:      	blr	x8
   119b4:      	ldr	x24, [sp, #0x98]
   119b8:      	ldr	x21, [sp, #0x48]
   119bc:      	add	x2, x24, #0x20
   119c0:      	stp	x2, x24, [sp, #0x50]
   119c4:      	ldr	x8, [sp, #0x30]
   119c8:      	cmp	x21, x8
   119cc:      	b.ne	0x119dc <generic_fentry_path+0x752c>
   119d0:      	ldr	x8, [sp, #0x38]
   119d4:      	cmp	x2, x8
   119d8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   119dc:      	mov	w8, #0x4                // =4
   119e0:      	add	x0, sp, #0x70
   119e4:      	mov	w1, #0x8                // =8
   119e8:      	blr	x8
   119ec:      	ldr	x8, [sp, #0x70]
   119f0:      	cmp	x21, x8
   119f4:      	b.eq	0x11ae4 <generic_fentry_path+0x7634>
   119f8:      	add	x23, x21, #0x18
   119fc:      	mov	w8, #0x4                // =4
   11a00:      	add	x9, sp, #0x98
   11a04:      	add	x0, sp, #0x98
   11a08:      	mov	w1, #0x8                // =8
   11a0c:      	mov	x2, x23
   11a10:      	blr	x8
   11a14:      	ldr	x8, [sp, #0x98]
   11a18:      	cmp	x8, x21
   11a1c:      	b.eq	0x11ae4 <generic_fentry_path+0x7634>
   11a20:      	mov	w8, #0x4                // =4
   11a24:      	add	x9, sp, #0x78
   11a28:      	add	x0, sp, #0x78
   11a2c:      	mov	w1, #0x8                // =8
   11a30:      	mov	x2, x23
   11a34:      	blr	x8
   11a38:      	add	x2, x21, #0x20
   11a3c:      	mov	w8, #0x4                // =4
   11a40:      	mov	w9, #0x10               // =16
   11a44:      	add	x10, sp, #0x80
   11a48:      	add	x0, sp, #0x80
   11a4c:      	mov	w1, #0x10               // =16
   11a50:      	blr	x8
   11a54:      	ldr	w21, [sp, #0x84]
   11a58:      	ldr	x8, [sp, #0x40]
   11a5c:      	ldr	x10, [sp, #0x60]
   11a60:      	sub	x12, x10, x8
   11a64:      	ldr	w23, [sp, #0x68]
   11a68:      	subs	w10, w21, w23
   11a6c:      	ldr	x9, [sp, #0x88]
   11a70:      	csel	w10, wzr, w10, lo
   11a74:      	cmp	w23, w21
   11a78:      	csel	w11, w23, w21, lo
   11a7c:      	cinc	w13, w11, hi
   11a80:      	sub	w14, w23, w13
   11a84:      	subs	x12, x12, x13
   11a88:      	str	w14, [sp, #0x68]
   11a8c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   11a90:      	cmp	x12, #0xfff
   11a94:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   11a98:      	cmp	w23, w21
   11a9c:      	b.ls	0x11aa8 <generic_fentry_path+0x75f8>
   11aa0:      	mov	w13, #0x2f              // =47
   11aa4:      	strb	w13, [x8, x12]
   11aa8:      	add	x19, x8, x12
   11aac:      	cmp	w23, w21
   11ab0:      	add	x2, x9, x10
   11ab4:      	and	w1, w11, #0xff
   11ab8:      	mov	w8, #0x4                // =4
   11abc:      	cinc	x0, x19, hi
   11ac0:      	blr	x8
   11ac4:      	cmp	w23, w21
   11ac8:      	str	x19, [sp, #0x60]
   11acc:      	add	x19, sp, #0x70
   11ad0:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   11ad4:      	ldr	x21, [sp, #0x78]
   11ad8:      	ldp	x2, x24, [sp, #0x50]
   11adc:      	str	x21, [sp, #0x48]
   11ae0:      	b	0x11b30 <generic_fentry_path+0x7680>
   11ae4:      	add	x2, x24, #0x10
   11ae8:      	mov	w8, #0x4                // =4
   11aec:      	add	x9, sp, #0x98
   11af0:      	add	x0, sp, #0x98
   11af4:      	mov	w1, #0x8                // =8
   11af8:      	blr	x8
   11afc:      	ldr	x8, [sp, #0x58]
   11b00:      	ldr	x9, [sp, #0x98]
   11b04:      	cmp	x8, x9
   11b08:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   11b0c:      	add	x2, x24, #0x18
   11b10:      	mov	w8, #0x4                // =4
   11b14:      	mov	x0, x22
   11b18:      	mov	w1, #0x8                // =8
   11b1c:      	blr	x8
   11b20:      	ldr	x24, [sp, #0x98]
   11b24:      	ldr	x21, [sp, #0x48]
   11b28:      	add	x2, x24, #0x20
   11b2c:      	stp	x2, x24, [sp, #0x50]
   11b30:      	ldr	x8, [sp, #0x30]
   11b34:      	cmp	x21, x8
   11b38:      	b.ne	0x11b48 <generic_fentry_path+0x7698>
   11b3c:      	ldr	x8, [sp, #0x38]
   11b40:      	cmp	x2, x8
   11b44:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   11b48:      	mov	w8, #0x4                // =4
   11b4c:      	add	x0, sp, #0x70
   11b50:      	mov	w1, #0x8                // =8
   11b54:      	blr	x8
   11b58:      	ldr	x8, [sp, #0x70]
   11b5c:      	cmp	x21, x8
   11b60:      	b.eq	0x11c50 <generic_fentry_path+0x77a0>
   11b64:      	add	x23, x21, #0x18
   11b68:      	mov	w8, #0x4                // =4
   11b6c:      	add	x9, sp, #0x98
   11b70:      	add	x0, sp, #0x98
   11b74:      	mov	w1, #0x8                // =8
   11b78:      	mov	x2, x23
   11b7c:      	blr	x8
   11b80:      	ldr	x8, [sp, #0x98]
   11b84:      	cmp	x8, x21
   11b88:      	b.eq	0x11c50 <generic_fentry_path+0x77a0>
   11b8c:      	mov	w8, #0x4                // =4
   11b90:      	add	x9, sp, #0x78
   11b94:      	add	x0, sp, #0x78
   11b98:      	mov	w1, #0x8                // =8
   11b9c:      	mov	x2, x23
   11ba0:      	blr	x8
   11ba4:      	add	x2, x21, #0x20
   11ba8:      	mov	w8, #0x4                // =4
   11bac:      	mov	w9, #0x10               // =16
   11bb0:      	add	x10, sp, #0x80
   11bb4:      	add	x0, sp, #0x80
   11bb8:      	mov	w1, #0x10               // =16
   11bbc:      	blr	x8
   11bc0:      	ldr	w21, [sp, #0x84]
   11bc4:      	ldr	x8, [sp, #0x40]
   11bc8:      	ldr	x10, [sp, #0x60]
   11bcc:      	sub	x12, x10, x8
   11bd0:      	ldr	w23, [sp, #0x68]
   11bd4:      	subs	w10, w21, w23
   11bd8:      	ldr	x9, [sp, #0x88]
   11bdc:      	csel	w10, wzr, w10, lo
   11be0:      	cmp	w23, w21
   11be4:      	csel	w11, w23, w21, lo
   11be8:      	cinc	w13, w11, hi
   11bec:      	sub	w14, w23, w13
   11bf0:      	subs	x12, x12, x13
   11bf4:      	str	w14, [sp, #0x68]
   11bf8:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   11bfc:      	cmp	x12, #0xfff
   11c00:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   11c04:      	cmp	w23, w21
   11c08:      	b.ls	0x11c14 <generic_fentry_path+0x7764>
   11c0c:      	mov	w13, #0x2f              // =47
   11c10:      	strb	w13, [x8, x12]
   11c14:      	add	x19, x8, x12
   11c18:      	cmp	w23, w21
   11c1c:      	add	x2, x9, x10
   11c20:      	and	w1, w11, #0xff
   11c24:      	mov	w8, #0x4                // =4
   11c28:      	cinc	x0, x19, hi
   11c2c:      	blr	x8
   11c30:      	cmp	w23, w21
   11c34:      	str	x19, [sp, #0x60]
   11c38:      	add	x19, sp, #0x70
   11c3c:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   11c40:      	ldr	x21, [sp, #0x78]
   11c44:      	ldp	x2, x24, [sp, #0x50]
   11c48:      	str	x21, [sp, #0x48]
   11c4c:      	b	0x11c9c <generic_fentry_path+0x77ec>
   11c50:      	add	x2, x24, #0x10
   11c54:      	mov	w8, #0x4                // =4
   11c58:      	add	x9, sp, #0x98
   11c5c:      	add	x0, sp, #0x98
   11c60:      	mov	w1, #0x8                // =8
   11c64:      	blr	x8
   11c68:      	ldr	x8, [sp, #0x58]
   11c6c:      	ldr	x9, [sp, #0x98]
   11c70:      	cmp	x8, x9
   11c74:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   11c78:      	add	x2, x24, #0x18
   11c7c:      	mov	w8, #0x4                // =4
   11c80:      	mov	x0, x22
   11c84:      	mov	w1, #0x8                // =8
   11c88:      	blr	x8
   11c8c:      	ldr	x24, [sp, #0x98]
   11c90:      	ldr	x21, [sp, #0x48]
   11c94:      	add	x2, x24, #0x20
   11c98:      	stp	x2, x24, [sp, #0x50]
   11c9c:      	ldr	x8, [sp, #0x30]
   11ca0:      	cmp	x21, x8
   11ca4:      	b.ne	0x11cb4 <generic_fentry_path+0x7804>
   11ca8:      	ldr	x8, [sp, #0x38]
   11cac:      	cmp	x2, x8
   11cb0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   11cb4:      	mov	w8, #0x4                // =4
   11cb8:      	add	x0, sp, #0x70
   11cbc:      	mov	w1, #0x8                // =8
   11cc0:      	blr	x8
   11cc4:      	ldr	x8, [sp, #0x70]
   11cc8:      	cmp	x21, x8
   11ccc:      	b.eq	0x11dbc <generic_fentry_path+0x790c>
   11cd0:      	add	x23, x21, #0x18
   11cd4:      	mov	w8, #0x4                // =4
   11cd8:      	add	x9, sp, #0x98
   11cdc:      	add	x0, sp, #0x98
   11ce0:      	mov	w1, #0x8                // =8
   11ce4:      	mov	x2, x23
   11ce8:      	blr	x8
   11cec:      	ldr	x8, [sp, #0x98]
   11cf0:      	cmp	x8, x21
   11cf4:      	b.eq	0x11dbc <generic_fentry_path+0x790c>
   11cf8:      	mov	w8, #0x4                // =4
   11cfc:      	add	x9, sp, #0x78
   11d00:      	add	x0, sp, #0x78
   11d04:      	mov	w1, #0x8                // =8
   11d08:      	mov	x2, x23
   11d0c:      	blr	x8
   11d10:      	add	x2, x21, #0x20
   11d14:      	mov	w8, #0x4                // =4
   11d18:      	mov	w9, #0x10               // =16
   11d1c:      	add	x10, sp, #0x80
   11d20:      	add	x0, sp, #0x80
   11d24:      	mov	w1, #0x10               // =16
   11d28:      	blr	x8
   11d2c:      	ldr	w21, [sp, #0x84]
   11d30:      	ldr	x8, [sp, #0x40]
   11d34:      	ldr	x10, [sp, #0x60]
   11d38:      	sub	x12, x10, x8
   11d3c:      	ldr	w23, [sp, #0x68]
   11d40:      	subs	w10, w21, w23
   11d44:      	ldr	x9, [sp, #0x88]
   11d48:      	csel	w10, wzr, w10, lo
   11d4c:      	cmp	w23, w21
   11d50:      	csel	w11, w23, w21, lo
   11d54:      	cinc	w13, w11, hi
   11d58:      	sub	w14, w23, w13
   11d5c:      	subs	x12, x12, x13
   11d60:      	str	w14, [sp, #0x68]
   11d64:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   11d68:      	cmp	x12, #0xfff
   11d6c:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   11d70:      	cmp	w23, w21
   11d74:      	b.ls	0x11d80 <generic_fentry_path+0x78d0>
   11d78:      	mov	w13, #0x2f              // =47
   11d7c:      	strb	w13, [x8, x12]
   11d80:      	add	x19, x8, x12
   11d84:      	cmp	w23, w21
   11d88:      	add	x2, x9, x10
   11d8c:      	and	w1, w11, #0xff
   11d90:      	mov	w8, #0x4                // =4
   11d94:      	cinc	x0, x19, hi
   11d98:      	blr	x8
   11d9c:      	cmp	w23, w21
   11da0:      	str	x19, [sp, #0x60]
   11da4:      	add	x19, sp, #0x70
   11da8:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   11dac:      	ldr	x21, [sp, #0x78]
   11db0:      	ldp	x2, x24, [sp, #0x50]
   11db4:      	str	x21, [sp, #0x48]
   11db8:      	b	0x11e08 <generic_fentry_path+0x7958>
   11dbc:      	add	x2, x24, #0x10
   11dc0:      	mov	w8, #0x4                // =4
   11dc4:      	add	x9, sp, #0x98
   11dc8:      	add	x0, sp, #0x98
   11dcc:      	mov	w1, #0x8                // =8
   11dd0:      	blr	x8
   11dd4:      	ldr	x8, [sp, #0x58]
   11dd8:      	ldr	x9, [sp, #0x98]
   11ddc:      	cmp	x8, x9
   11de0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   11de4:      	add	x2, x24, #0x18
   11de8:      	mov	w8, #0x4                // =4
   11dec:      	mov	x0, x22
   11df0:      	mov	w1, #0x8                // =8
   11df4:      	blr	x8
   11df8:      	ldr	x24, [sp, #0x98]
   11dfc:      	ldr	x21, [sp, #0x48]
   11e00:      	add	x2, x24, #0x20
   11e04:      	stp	x2, x24, [sp, #0x50]
   11e08:      	ldr	x8, [sp, #0x30]
   11e0c:      	cmp	x21, x8
   11e10:      	b.ne	0x11e20 <generic_fentry_path+0x7970>
   11e14:      	ldr	x8, [sp, #0x38]
   11e18:      	cmp	x2, x8
   11e1c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   11e20:      	mov	w8, #0x4                // =4
   11e24:      	add	x0, sp, #0x70
   11e28:      	mov	w1, #0x8                // =8
   11e2c:      	blr	x8
   11e30:      	ldr	x8, [sp, #0x70]
   11e34:      	cmp	x21, x8
   11e38:      	b.eq	0x11f28 <generic_fentry_path+0x7a78>
   11e3c:      	add	x23, x21, #0x18
   11e40:      	mov	w8, #0x4                // =4
   11e44:      	add	x9, sp, #0x98
   11e48:      	add	x0, sp, #0x98
   11e4c:      	mov	w1, #0x8                // =8
   11e50:      	mov	x2, x23
   11e54:      	blr	x8
   11e58:      	ldr	x8, [sp, #0x98]
   11e5c:      	cmp	x8, x21
   11e60:      	b.eq	0x11f28 <generic_fentry_path+0x7a78>
   11e64:      	mov	w8, #0x4                // =4
   11e68:      	add	x9, sp, #0x78
   11e6c:      	add	x0, sp, #0x78
   11e70:      	mov	w1, #0x8                // =8
   11e74:      	mov	x2, x23
   11e78:      	blr	x8
   11e7c:      	add	x2, x21, #0x20
   11e80:      	mov	w8, #0x4                // =4
   11e84:      	mov	w9, #0x10               // =16
   11e88:      	add	x10, sp, #0x80
   11e8c:      	add	x0, sp, #0x80
   11e90:      	mov	w1, #0x10               // =16
   11e94:      	blr	x8
   11e98:      	ldr	w21, [sp, #0x84]
   11e9c:      	ldr	x8, [sp, #0x40]
   11ea0:      	ldr	x10, [sp, #0x60]
   11ea4:      	sub	x12, x10, x8
   11ea8:      	ldr	w23, [sp, #0x68]
   11eac:      	subs	w10, w21, w23
   11eb0:      	ldr	x9, [sp, #0x88]
   11eb4:      	csel	w10, wzr, w10, lo
   11eb8:      	cmp	w23, w21
   11ebc:      	csel	w11, w23, w21, lo
   11ec0:      	cinc	w13, w11, hi
   11ec4:      	sub	w14, w23, w13
   11ec8:      	subs	x12, x12, x13
   11ecc:      	str	w14, [sp, #0x68]
   11ed0:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   11ed4:      	cmp	x12, #0xfff
   11ed8:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   11edc:      	cmp	w23, w21
   11ee0:      	b.ls	0x11eec <generic_fentry_path+0x7a3c>
   11ee4:      	mov	w13, #0x2f              // =47
   11ee8:      	strb	w13, [x8, x12]
   11eec:      	add	x19, x8, x12
   11ef0:      	cmp	w23, w21
   11ef4:      	add	x2, x9, x10
   11ef8:      	and	w1, w11, #0xff
   11efc:      	mov	w8, #0x4                // =4
   11f00:      	cinc	x0, x19, hi
   11f04:      	blr	x8
   11f08:      	cmp	w23, w21
   11f0c:      	str	x19, [sp, #0x60]
   11f10:      	add	x19, sp, #0x70
   11f14:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   11f18:      	ldr	x21, [sp, #0x78]
   11f1c:      	ldp	x2, x24, [sp, #0x50]
   11f20:      	str	x21, [sp, #0x48]
   11f24:      	b	0x11f74 <generic_fentry_path+0x7ac4>
   11f28:      	add	x2, x24, #0x10
   11f2c:      	mov	w8, #0x4                // =4
   11f30:      	add	x9, sp, #0x98
   11f34:      	add	x0, sp, #0x98
   11f38:      	mov	w1, #0x8                // =8
   11f3c:      	blr	x8
   11f40:      	ldr	x8, [sp, #0x58]
   11f44:      	ldr	x9, [sp, #0x98]
   11f48:      	cmp	x8, x9
   11f4c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   11f50:      	add	x2, x24, #0x18
   11f54:      	mov	w8, #0x4                // =4
   11f58:      	mov	x0, x22
   11f5c:      	mov	w1, #0x8                // =8
   11f60:      	blr	x8
   11f64:      	ldr	x24, [sp, #0x98]
   11f68:      	ldr	x21, [sp, #0x48]
   11f6c:      	add	x2, x24, #0x20
   11f70:      	stp	x2, x24, [sp, #0x50]
   11f74:      	ldr	x8, [sp, #0x30]
   11f78:      	cmp	x21, x8
   11f7c:      	b.ne	0x11f8c <generic_fentry_path+0x7adc>
   11f80:      	ldr	x8, [sp, #0x38]
   11f84:      	cmp	x2, x8
   11f88:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   11f8c:      	mov	w8, #0x4                // =4
   11f90:      	add	x0, sp, #0x70
   11f94:      	mov	w1, #0x8                // =8
   11f98:      	blr	x8
   11f9c:      	ldr	x8, [sp, #0x70]
   11fa0:      	cmp	x21, x8
   11fa4:      	b.eq	0x12094 <generic_fentry_path+0x7be4>
   11fa8:      	add	x23, x21, #0x18
   11fac:      	mov	w8, #0x4                // =4
   11fb0:      	add	x9, sp, #0x98
   11fb4:      	add	x0, sp, #0x98
   11fb8:      	mov	w1, #0x8                // =8
   11fbc:      	mov	x2, x23
   11fc0:      	blr	x8
   11fc4:      	ldr	x8, [sp, #0x98]
   11fc8:      	cmp	x8, x21
   11fcc:      	b.eq	0x12094 <generic_fentry_path+0x7be4>
   11fd0:      	mov	w8, #0x4                // =4
   11fd4:      	add	x9, sp, #0x78
   11fd8:      	add	x0, sp, #0x78
   11fdc:      	mov	w1, #0x8                // =8
   11fe0:      	mov	x2, x23
   11fe4:      	blr	x8
   11fe8:      	add	x2, x21, #0x20
   11fec:      	mov	w8, #0x4                // =4
   11ff0:      	mov	w9, #0x10               // =16
   11ff4:      	add	x10, sp, #0x80
   11ff8:      	add	x0, sp, #0x80
   11ffc:      	mov	w1, #0x10               // =16
   12000:      	blr	x8
   12004:      	ldr	w21, [sp, #0x84]
   12008:      	ldr	x8, [sp, #0x40]
   1200c:      	ldr	x10, [sp, #0x60]
   12010:      	sub	x12, x10, x8
   12014:      	ldr	w23, [sp, #0x68]
   12018:      	subs	w10, w21, w23
   1201c:      	ldr	x9, [sp, #0x88]
   12020:      	csel	w10, wzr, w10, lo
   12024:      	cmp	w23, w21
   12028:      	csel	w11, w23, w21, lo
   1202c:      	cinc	w13, w11, hi
   12030:      	sub	w14, w23, w13
   12034:      	subs	x12, x12, x13
   12038:      	str	w14, [sp, #0x68]
   1203c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   12040:      	cmp	x12, #0xfff
   12044:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   12048:      	cmp	w23, w21
   1204c:      	b.ls	0x12058 <generic_fentry_path+0x7ba8>
   12050:      	mov	w13, #0x2f              // =47
   12054:      	strb	w13, [x8, x12]
   12058:      	add	x19, x8, x12
   1205c:      	cmp	w23, w21
   12060:      	add	x2, x9, x10
   12064:      	and	w1, w11, #0xff
   12068:      	mov	w8, #0x4                // =4
   1206c:      	cinc	x0, x19, hi
   12070:      	blr	x8
   12074:      	cmp	w23, w21
   12078:      	str	x19, [sp, #0x60]
   1207c:      	add	x19, sp, #0x70
   12080:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   12084:      	ldr	x21, [sp, #0x78]
   12088:      	ldp	x2, x24, [sp, #0x50]
   1208c:      	str	x21, [sp, #0x48]
   12090:      	b	0x120e0 <generic_fentry_path+0x7c30>
   12094:      	add	x2, x24, #0x10
   12098:      	mov	w8, #0x4                // =4
   1209c:      	add	x9, sp, #0x98
   120a0:      	add	x0, sp, #0x98
   120a4:      	mov	w1, #0x8                // =8
   120a8:      	blr	x8
   120ac:      	ldr	x8, [sp, #0x58]
   120b0:      	ldr	x9, [sp, #0x98]
   120b4:      	cmp	x8, x9
   120b8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   120bc:      	add	x2, x24, #0x18
   120c0:      	mov	w8, #0x4                // =4
   120c4:      	mov	x0, x22
   120c8:      	mov	w1, #0x8                // =8
   120cc:      	blr	x8
   120d0:      	ldr	x24, [sp, #0x98]
   120d4:      	ldr	x21, [sp, #0x48]
   120d8:      	add	x2, x24, #0x20
   120dc:      	stp	x2, x24, [sp, #0x50]
   120e0:      	ldr	x8, [sp, #0x30]
   120e4:      	cmp	x21, x8
   120e8:      	b.ne	0x120f8 <generic_fentry_path+0x7c48>
   120ec:      	ldr	x8, [sp, #0x38]
   120f0:      	cmp	x2, x8
   120f4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   120f8:      	mov	w8, #0x4                // =4
   120fc:      	add	x0, sp, #0x70
   12100:      	mov	w1, #0x8                // =8
   12104:      	blr	x8
   12108:      	ldr	x8, [sp, #0x70]
   1210c:      	cmp	x21, x8
   12110:      	b.eq	0x12200 <generic_fentry_path+0x7d50>
   12114:      	add	x23, x21, #0x18
   12118:      	mov	w8, #0x4                // =4
   1211c:      	add	x9, sp, #0x98
   12120:      	add	x0, sp, #0x98
   12124:      	mov	w1, #0x8                // =8
   12128:      	mov	x2, x23
   1212c:      	blr	x8
   12130:      	ldr	x8, [sp, #0x98]
   12134:      	cmp	x8, x21
   12138:      	b.eq	0x12200 <generic_fentry_path+0x7d50>
   1213c:      	mov	w8, #0x4                // =4
   12140:      	add	x9, sp, #0x78
   12144:      	add	x0, sp, #0x78
   12148:      	mov	w1, #0x8                // =8
   1214c:      	mov	x2, x23
   12150:      	blr	x8
   12154:      	add	x2, x21, #0x20
   12158:      	mov	w8, #0x4                // =4
   1215c:      	mov	w9, #0x10               // =16
   12160:      	add	x10, sp, #0x80
   12164:      	add	x0, sp, #0x80
   12168:      	mov	w1, #0x10               // =16
   1216c:      	blr	x8
   12170:      	ldr	w21, [sp, #0x84]
   12174:      	ldr	x8, [sp, #0x40]
   12178:      	ldr	x10, [sp, #0x60]
   1217c:      	sub	x12, x10, x8
   12180:      	ldr	w23, [sp, #0x68]
   12184:      	subs	w10, w21, w23
   12188:      	ldr	x9, [sp, #0x88]
   1218c:      	csel	w10, wzr, w10, lo
   12190:      	cmp	w23, w21
   12194:      	csel	w11, w23, w21, lo
   12198:      	cinc	w13, w11, hi
   1219c:      	sub	w14, w23, w13
   121a0:      	subs	x12, x12, x13
   121a4:      	str	w14, [sp, #0x68]
   121a8:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   121ac:      	cmp	x12, #0xfff
   121b0:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   121b4:      	cmp	w23, w21
   121b8:      	b.ls	0x121c4 <generic_fentry_path+0x7d14>
   121bc:      	mov	w13, #0x2f              // =47
   121c0:      	strb	w13, [x8, x12]
   121c4:      	add	x19, x8, x12
   121c8:      	cmp	w23, w21
   121cc:      	add	x2, x9, x10
   121d0:      	and	w1, w11, #0xff
   121d4:      	mov	w8, #0x4                // =4
   121d8:      	cinc	x0, x19, hi
   121dc:      	blr	x8
   121e0:      	cmp	w23, w21
   121e4:      	str	x19, [sp, #0x60]
   121e8:      	add	x19, sp, #0x70
   121ec:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   121f0:      	ldr	x21, [sp, #0x78]
   121f4:      	ldp	x2, x24, [sp, #0x50]
   121f8:      	str	x21, [sp, #0x48]
   121fc:      	b	0x1224c <generic_fentry_path+0x7d9c>
   12200:      	add	x2, x24, #0x10
   12204:      	mov	w8, #0x4                // =4
   12208:      	add	x9, sp, #0x98
   1220c:      	add	x0, sp, #0x98
   12210:      	mov	w1, #0x8                // =8
   12214:      	blr	x8
   12218:      	ldr	x8, [sp, #0x58]
   1221c:      	ldr	x9, [sp, #0x98]
   12220:      	cmp	x8, x9
   12224:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   12228:      	add	x2, x24, #0x18
   1222c:      	mov	w8, #0x4                // =4
   12230:      	mov	x0, x22
   12234:      	mov	w1, #0x8                // =8
   12238:      	blr	x8
   1223c:      	ldr	x24, [sp, #0x98]
   12240:      	ldr	x21, [sp, #0x48]
   12244:      	add	x2, x24, #0x20
   12248:      	stp	x2, x24, [sp, #0x50]
   1224c:      	ldr	x8, [sp, #0x30]
   12250:      	cmp	x21, x8
   12254:      	b.ne	0x12264 <generic_fentry_path+0x7db4>
   12258:      	ldr	x8, [sp, #0x38]
   1225c:      	cmp	x2, x8
   12260:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   12264:      	str	x25, [sp, #0x8]
   12268:      	mov	w8, #0x4                // =4
   1226c:      	add	x0, sp, #0x70
   12270:      	mov	w1, #0x8                // =8
   12274:      	blr	x8
   12278:      	ldr	x8, [sp, #0x70]
   1227c:      	cmp	x21, x8
   12280:      	b.eq	0x12374 <generic_fentry_path+0x7ec4>
   12284:      	add	x23, x21, #0x18
   12288:      	mov	w8, #0x4                // =4
   1228c:      	add	x9, sp, #0x98
   12290:      	add	x0, sp, #0x98
   12294:      	mov	w1, #0x8                // =8
   12298:      	mov	x2, x23
   1229c:      	blr	x8
   122a0:      	ldr	x8, [sp, #0x98]
   122a4:      	cmp	x8, x21
   122a8:      	b.eq	0x12374 <generic_fentry_path+0x7ec4>
   122ac:      	mov	w8, #0x4                // =4
   122b0:      	add	x9, sp, #0x78
   122b4:      	add	x0, sp, #0x78
   122b8:      	mov	w1, #0x8                // =8
   122bc:      	mov	x2, x23
   122c0:      	blr	x8
   122c4:      	add	x2, x21, #0x20
   122c8:      	mov	w8, #0x4                // =4
   122cc:      	mov	w9, #0x10               // =16
   122d0:      	add	x10, sp, #0x80
   122d4:      	add	x0, sp, #0x80
   122d8:      	mov	w1, #0x10               // =16
   122dc:      	blr	x8
   122e0:      	ldr	w21, [sp, #0x84]
   122e4:      	ldr	x8, [sp, #0x40]
   122e8:      	ldr	x10, [sp, #0x60]
   122ec:      	sub	x12, x10, x8
   122f0:      	ldr	w23, [sp, #0x68]
   122f4:      	subs	w10, w21, w23
   122f8:      	ldr	x9, [sp, #0x88]
   122fc:      	ldr	x25, [sp, #0x8]
   12300:      	csel	w10, wzr, w10, lo
   12304:      	cmp	w23, w21
   12308:      	csel	w11, w23, w21, lo
   1230c:      	cinc	w13, w11, hi
   12310:      	sub	w14, w23, w13
   12314:      	subs	x12, x12, x13
   12318:      	str	w14, [sp, #0x68]
   1231c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   12320:      	cmp	x12, #0xfff
   12324:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   12328:      	cmp	w23, w21
   1232c:      	b.ls	0x12338 <generic_fentry_path+0x7e88>
   12330:      	mov	w13, #0x2f              // =47
   12334:      	strb	w13, [x8, x12]
   12338:      	add	x19, x8, x12
   1233c:      	cmp	w23, w21
   12340:      	add	x2, x9, x10
   12344:      	and	w1, w11, #0xff
   12348:      	mov	w8, #0x4                // =4
   1234c:      	cinc	x0, x19, hi
   12350:      	blr	x8
   12354:      	ldr	x25, [sp, #0x8]
   12358:      	cmp	w23, w21
   1235c:      	str	x19, [sp, #0x60]
   12360:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   12364:      	ldr	x21, [sp, #0x78]
   12368:      	ldp	x2, x24, [sp, #0x50]
   1236c:      	str	x21, [sp, #0x48]
   12370:      	b	0x123c4 <generic_fentry_path+0x7f14>
   12374:      	add	x2, x24, #0x10
   12378:      	mov	w8, #0x4                // =4
   1237c:      	add	x9, sp, #0x98
   12380:      	add	x0, sp, #0x98
   12384:      	mov	w1, #0x8                // =8
   12388:      	blr	x8
   1238c:      	ldr	x8, [sp, #0x58]
   12390:      	ldr	x9, [sp, #0x98]
   12394:      	cmp	x8, x9
   12398:      	ldr	x25, [sp, #0x8]
   1239c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   123a0:      	add	x2, x24, #0x18
   123a4:      	mov	w8, #0x4                // =4
   123a8:      	mov	x0, x22
   123ac:      	mov	w1, #0x8                // =8
   123b0:      	blr	x8
   123b4:      	ldr	x24, [sp, #0x98]
   123b8:      	ldr	x21, [sp, #0x48]
   123bc:      	add	x2, x24, #0x20
   123c0:      	stp	x2, x24, [sp, #0x50]
   123c4:      	ldr	x8, [sp, #0x30]
   123c8:      	ldr	x25, [sp, #0x8]
   123cc:      	add	x9, sp, #0x70
   123d0:      	cmp	x21, x8
   123d4:      	b.ne	0x123e4 <generic_fentry_path+0x7f34>
   123d8:      	ldr	x8, [sp, #0x38]
   123dc:      	cmp	x2, x8
   123e0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   123e4:      	mov	w8, #0x4                // =4
   123e8:      	add	x0, sp, #0x70
   123ec:      	mov	w1, #0x8                // =8
   123f0:      	blr	x8
   123f4:      	ldr	x8, [sp, #0x70]
   123f8:      	cmp	x21, x8
   123fc:      	b.eq	0x124f0 <generic_fentry_path+0x8040>
   12400:      	add	x23, x21, #0x18
   12404:      	mov	w8, #0x4                // =4
   12408:      	add	x9, sp, #0x98
   1240c:      	add	x0, sp, #0x98
   12410:      	mov	w1, #0x8                // =8
   12414:      	mov	x2, x23
   12418:      	blr	x8
   1241c:      	ldr	x8, [sp, #0x98]
   12420:      	cmp	x8, x21
   12424:      	b.eq	0x124f0 <generic_fentry_path+0x8040>
   12428:      	mov	w8, #0x4                // =4
   1242c:      	add	x9, sp, #0x78
   12430:      	add	x0, sp, #0x78
   12434:      	mov	w1, #0x8                // =8
   12438:      	mov	x2, x23
   1243c:      	blr	x8
   12440:      	add	x2, x21, #0x20
   12444:      	mov	w8, #0x4                // =4
   12448:      	mov	w9, #0x10               // =16
   1244c:      	add	x10, sp, #0x80
   12450:      	add	x0, sp, #0x80
   12454:      	mov	w1, #0x10               // =16
   12458:      	blr	x8
   1245c:      	ldr	w21, [sp, #0x84]
   12460:      	ldr	x8, [sp, #0x40]
   12464:      	ldr	x10, [sp, #0x60]
   12468:      	sub	x12, x10, x8
   1246c:      	ldr	w23, [sp, #0x68]
   12470:      	subs	w10, w21, w23
   12474:      	ldr	x9, [sp, #0x88]
   12478:      	ldr	x25, [sp, #0x8]
   1247c:      	csel	w10, wzr, w10, lo
   12480:      	cmp	w23, w21
   12484:      	csel	w11, w23, w21, lo
   12488:      	cinc	w13, w11, hi
   1248c:      	sub	w14, w23, w13
   12490:      	subs	x12, x12, x13
   12494:      	str	w14, [sp, #0x68]
   12498:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   1249c:      	cmp	x12, #0xfff
   124a0:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   124a4:      	cmp	w23, w21
   124a8:      	b.ls	0x124b4 <generic_fentry_path+0x8004>
   124ac:      	mov	w13, #0x2f              // =47
   124b0:      	strb	w13, [x8, x12]
   124b4:      	add	x19, x8, x12
   124b8:      	cmp	w23, w21
   124bc:      	add	x2, x9, x10
   124c0:      	and	w1, w11, #0xff
   124c4:      	mov	w8, #0x4                // =4
   124c8:      	cinc	x0, x19, hi
   124cc:      	blr	x8
   124d0:      	ldr	x25, [sp, #0x8]
   124d4:      	cmp	w23, w21
   124d8:      	str	x19, [sp, #0x60]
   124dc:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   124e0:      	ldr	x21, [sp, #0x78]
   124e4:      	ldp	x2, x24, [sp, #0x50]
   124e8:      	str	x21, [sp, #0x48]
   124ec:      	b	0x12540 <generic_fentry_path+0x8090>
   124f0:      	add	x2, x24, #0x10
   124f4:      	mov	w8, #0x4                // =4
   124f8:      	add	x9, sp, #0x98
   124fc:      	add	x0, sp, #0x98
   12500:      	mov	w1, #0x8                // =8
   12504:      	blr	x8
   12508:      	ldr	x8, [sp, #0x58]
   1250c:      	ldr	x9, [sp, #0x98]
   12510:      	cmp	x8, x9
   12514:      	ldr	x25, [sp, #0x8]
   12518:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   1251c:      	add	x2, x24, #0x18
   12520:      	mov	w8, #0x4                // =4
   12524:      	mov	x0, x22
   12528:      	mov	w1, #0x8                // =8
   1252c:      	blr	x8
   12530:      	ldr	x24, [sp, #0x98]
   12534:      	ldr	x21, [sp, #0x48]
   12538:      	add	x2, x24, #0x20
   1253c:      	stp	x2, x24, [sp, #0x50]
   12540:      	ldr	x8, [sp, #0x30]
   12544:      	ldr	x25, [sp, #0x8]
   12548:      	add	x9, sp, #0x70
   1254c:      	cmp	x21, x8
   12550:      	b.ne	0x12560 <generic_fentry_path+0x80b0>
   12554:      	ldr	x8, [sp, #0x38]
   12558:      	cmp	x2, x8
   1255c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   12560:      	mov	w8, #0x4                // =4
   12564:      	add	x0, sp, #0x70
   12568:      	mov	w1, #0x8                // =8
   1256c:      	blr	x8
   12570:      	ldr	x8, [sp, #0x70]
   12574:      	cmp	x21, x8
   12578:      	b.eq	0x1266c <generic_fentry_path+0x81bc>
   1257c:      	add	x23, x21, #0x18
   12580:      	mov	w8, #0x4                // =4
   12584:      	add	x9, sp, #0x98
   12588:      	add	x0, sp, #0x98
   1258c:      	mov	w1, #0x8                // =8
   12590:      	mov	x2, x23
   12594:      	blr	x8
   12598:      	ldr	x8, [sp, #0x98]
   1259c:      	cmp	x8, x21
   125a0:      	b.eq	0x1266c <generic_fentry_path+0x81bc>
   125a4:      	mov	w8, #0x4                // =4
   125a8:      	add	x9, sp, #0x78
   125ac:      	add	x0, sp, #0x78
   125b0:      	mov	w1, #0x8                // =8
   125b4:      	mov	x2, x23
   125b8:      	blr	x8
   125bc:      	add	x2, x21, #0x20
   125c0:      	mov	w8, #0x4                // =4
   125c4:      	mov	w9, #0x10               // =16
   125c8:      	add	x10, sp, #0x80
   125cc:      	add	x0, sp, #0x80
   125d0:      	mov	w1, #0x10               // =16
   125d4:      	blr	x8
   125d8:      	ldr	w21, [sp, #0x84]
   125dc:      	ldr	x8, [sp, #0x40]
   125e0:      	ldr	x10, [sp, #0x60]
   125e4:      	sub	x12, x10, x8
   125e8:      	ldr	w23, [sp, #0x68]
   125ec:      	subs	w10, w21, w23
   125f0:      	ldr	x9, [sp, #0x88]
   125f4:      	ldr	x25, [sp, #0x8]
   125f8:      	csel	w10, wzr, w10, lo
   125fc:      	cmp	w23, w21
   12600:      	csel	w11, w23, w21, lo
   12604:      	cinc	w13, w11, hi
   12608:      	sub	w14, w23, w13
   1260c:      	subs	x12, x12, x13
   12610:      	str	w14, [sp, #0x68]
   12614:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   12618:      	cmp	x12, #0xfff
   1261c:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   12620:      	cmp	w23, w21
   12624:      	b.ls	0x12630 <generic_fentry_path+0x8180>
   12628:      	mov	w13, #0x2f              // =47
   1262c:      	strb	w13, [x8, x12]
   12630:      	add	x19, x8, x12
   12634:      	cmp	w23, w21
   12638:      	add	x2, x9, x10
   1263c:      	and	w1, w11, #0xff
   12640:      	mov	w8, #0x4                // =4
   12644:      	cinc	x0, x19, hi
   12648:      	blr	x8
   1264c:      	ldr	x25, [sp, #0x8]
   12650:      	cmp	w23, w21
   12654:      	str	x19, [sp, #0x60]
   12658:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   1265c:      	ldr	x21, [sp, #0x78]
   12660:      	ldp	x2, x24, [sp, #0x50]
   12664:      	str	x21, [sp, #0x48]
   12668:      	b	0x126bc <generic_fentry_path+0x820c>
   1266c:      	add	x2, x24, #0x10
   12670:      	mov	w8, #0x4                // =4
   12674:      	add	x9, sp, #0x98
   12678:      	add	x0, sp, #0x98
   1267c:      	mov	w1, #0x8                // =8
   12680:      	blr	x8
   12684:      	ldr	x8, [sp, #0x58]
   12688:      	ldr	x9, [sp, #0x98]
   1268c:      	cmp	x8, x9
   12690:      	ldr	x25, [sp, #0x8]
   12694:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   12698:      	add	x2, x24, #0x18
   1269c:      	mov	w8, #0x4                // =4
   126a0:      	mov	x0, x22
   126a4:      	mov	w1, #0x8                // =8
   126a8:      	blr	x8
   126ac:      	ldr	x24, [sp, #0x98]
   126b0:      	ldr	x21, [sp, #0x48]
   126b4:      	add	x2, x24, #0x20
   126b8:      	stp	x2, x24, [sp, #0x50]
   126bc:      	ldr	x8, [sp, #0x30]
   126c0:      	ldr	x25, [sp, #0x8]
   126c4:      	add	x9, sp, #0x70
   126c8:      	cmp	x21, x8
   126cc:      	b.ne	0x126dc <generic_fentry_path+0x822c>
   126d0:      	ldr	x8, [sp, #0x38]
   126d4:      	cmp	x2, x8
   126d8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   126dc:      	mov	w8, #0x4                // =4
   126e0:      	add	x0, sp, #0x70
   126e4:      	mov	w1, #0x8                // =8
   126e8:      	blr	x8
   126ec:      	ldr	x8, [sp, #0x70]
   126f0:      	cmp	x21, x8
   126f4:      	b.eq	0x127e8 <generic_fentry_path+0x8338>
   126f8:      	add	x23, x21, #0x18
   126fc:      	mov	w8, #0x4                // =4
   12700:      	add	x9, sp, #0x98
   12704:      	add	x0, sp, #0x98
   12708:      	mov	w1, #0x8                // =8
   1270c:      	mov	x2, x23
   12710:      	blr	x8
   12714:      	ldr	x8, [sp, #0x98]
   12718:      	cmp	x8, x21
   1271c:      	b.eq	0x127e8 <generic_fentry_path+0x8338>
   12720:      	mov	w8, #0x4                // =4
   12724:      	add	x9, sp, #0x78
   12728:      	add	x0, sp, #0x78
   1272c:      	mov	w1, #0x8                // =8
   12730:      	mov	x2, x23
   12734:      	blr	x8
   12738:      	add	x2, x21, #0x20
   1273c:      	mov	w8, #0x4                // =4
   12740:      	mov	w9, #0x10               // =16
   12744:      	add	x10, sp, #0x80
   12748:      	add	x0, sp, #0x80
   1274c:      	mov	w1, #0x10               // =16
   12750:      	blr	x8
   12754:      	ldr	w21, [sp, #0x84]
   12758:      	ldr	x8, [sp, #0x40]
   1275c:      	ldr	x10, [sp, #0x60]
   12760:      	sub	x12, x10, x8
   12764:      	ldr	w23, [sp, #0x68]
   12768:      	subs	w10, w21, w23
   1276c:      	ldr	x9, [sp, #0x88]
   12770:      	ldr	x25, [sp, #0x8]
   12774:      	csel	w10, wzr, w10, lo
   12778:      	cmp	w23, w21
   1277c:      	csel	w11, w23, w21, lo
   12780:      	cinc	w13, w11, hi
   12784:      	sub	w14, w23, w13
   12788:      	subs	x12, x12, x13
   1278c:      	str	w14, [sp, #0x68]
   12790:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   12794:      	cmp	x12, #0xfff
   12798:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   1279c:      	cmp	w23, w21
   127a0:      	b.ls	0x127ac <generic_fentry_path+0x82fc>
   127a4:      	mov	w13, #0x2f              // =47
   127a8:      	strb	w13, [x8, x12]
   127ac:      	add	x19, x8, x12
   127b0:      	cmp	w23, w21
   127b4:      	add	x2, x9, x10
   127b8:      	and	w1, w11, #0xff
   127bc:      	mov	w8, #0x4                // =4
   127c0:      	cinc	x0, x19, hi
   127c4:      	blr	x8
   127c8:      	ldr	x25, [sp, #0x8]
   127cc:      	cmp	w23, w21
   127d0:      	str	x19, [sp, #0x60]
   127d4:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   127d8:      	ldr	x21, [sp, #0x78]
   127dc:      	ldp	x2, x24, [sp, #0x50]
   127e0:      	str	x21, [sp, #0x48]
   127e4:      	b	0x12838 <generic_fentry_path+0x8388>
   127e8:      	add	x2, x24, #0x10
   127ec:      	mov	w8, #0x4                // =4
   127f0:      	add	x9, sp, #0x98
   127f4:      	add	x0, sp, #0x98
   127f8:      	mov	w1, #0x8                // =8
   127fc:      	blr	x8
   12800:      	ldr	x8, [sp, #0x58]
   12804:      	ldr	x9, [sp, #0x98]
   12808:      	cmp	x8, x9
   1280c:      	ldr	x25, [sp, #0x8]
   12810:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   12814:      	add	x2, x24, #0x18
   12818:      	mov	w8, #0x4                // =4
   1281c:      	mov	x0, x22
   12820:      	mov	w1, #0x8                // =8
   12824:      	blr	x8
   12828:      	ldr	x24, [sp, #0x98]
   1282c:      	ldr	x21, [sp, #0x48]
   12830:      	add	x2, x24, #0x20
   12834:      	stp	x2, x24, [sp, #0x50]
   12838:      	ldr	x8, [sp, #0x30]
   1283c:      	ldr	x25, [sp, #0x8]
   12840:      	add	x9, sp, #0x70
   12844:      	cmp	x21, x8
   12848:      	b.ne	0x12858 <generic_fentry_path+0x83a8>
   1284c:      	ldr	x8, [sp, #0x38]
   12850:      	cmp	x2, x8
   12854:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   12858:      	mov	w8, #0x4                // =4
   1285c:      	add	x0, sp, #0x70
   12860:      	mov	w1, #0x8                // =8
   12864:      	blr	x8
   12868:      	ldr	x8, [sp, #0x70]
   1286c:      	cmp	x21, x8
   12870:      	b.eq	0x12964 <generic_fentry_path+0x84b4>
   12874:      	add	x23, x21, #0x18
   12878:      	mov	w8, #0x4                // =4
   1287c:      	add	x9, sp, #0x98
   12880:      	add	x0, sp, #0x98
   12884:      	mov	w1, #0x8                // =8
   12888:      	mov	x2, x23
   1288c:      	blr	x8
   12890:      	ldr	x8, [sp, #0x98]
   12894:      	cmp	x8, x21
   12898:      	b.eq	0x12964 <generic_fentry_path+0x84b4>
   1289c:      	mov	w8, #0x4                // =4
   128a0:      	add	x9, sp, #0x78
   128a4:      	add	x0, sp, #0x78
   128a8:      	mov	w1, #0x8                // =8
   128ac:      	mov	x2, x23
   128b0:      	blr	x8
   128b4:      	add	x2, x21, #0x20
   128b8:      	mov	w8, #0x4                // =4
   128bc:      	mov	w9, #0x10               // =16
   128c0:      	add	x10, sp, #0x80
   128c4:      	add	x0, sp, #0x80
   128c8:      	mov	w1, #0x10               // =16
   128cc:      	blr	x8
   128d0:      	ldr	w21, [sp, #0x84]
   128d4:      	ldr	x8, [sp, #0x40]
   128d8:      	ldr	x10, [sp, #0x60]
   128dc:      	sub	x12, x10, x8
   128e0:      	ldr	w23, [sp, #0x68]
   128e4:      	subs	w10, w21, w23
   128e8:      	ldr	x9, [sp, #0x88]
   128ec:      	ldr	x25, [sp, #0x8]
   128f0:      	csel	w10, wzr, w10, lo
   128f4:      	cmp	w23, w21
   128f8:      	csel	w11, w23, w21, lo
   128fc:      	cinc	w13, w11, hi
   12900:      	sub	w14, w23, w13
   12904:      	subs	x12, x12, x13
   12908:      	str	w14, [sp, #0x68]
   1290c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   12910:      	cmp	x12, #0xfff
   12914:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   12918:      	cmp	w23, w21
   1291c:      	b.ls	0x12928 <generic_fentry_path+0x8478>
   12920:      	mov	w13, #0x2f              // =47
   12924:      	strb	w13, [x8, x12]
   12928:      	add	x19, x8, x12
   1292c:      	cmp	w23, w21
   12930:      	add	x2, x9, x10
   12934:      	and	w1, w11, #0xff
   12938:      	mov	w8, #0x4                // =4
   1293c:      	cinc	x0, x19, hi
   12940:      	blr	x8
   12944:      	ldr	x25, [sp, #0x8]
   12948:      	cmp	w23, w21
   1294c:      	str	x19, [sp, #0x60]
   12950:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   12954:      	ldr	x21, [sp, #0x78]
   12958:      	ldp	x2, x24, [sp, #0x50]
   1295c:      	str	x21, [sp, #0x48]
   12960:      	b	0x129b4 <generic_fentry_path+0x8504>
   12964:      	add	x2, x24, #0x10
   12968:      	mov	w8, #0x4                // =4
   1296c:      	add	x9, sp, #0x98
   12970:      	add	x0, sp, #0x98
   12974:      	mov	w1, #0x8                // =8
   12978:      	blr	x8
   1297c:      	ldr	x8, [sp, #0x58]
   12980:      	ldr	x9, [sp, #0x98]
   12984:      	cmp	x8, x9
   12988:      	ldr	x25, [sp, #0x8]
   1298c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   12990:      	add	x2, x24, #0x18
   12994:      	mov	w8, #0x4                // =4
   12998:      	mov	x0, x22
   1299c:      	mov	w1, #0x8                // =8
   129a0:      	blr	x8
   129a4:      	ldr	x24, [sp, #0x98]
   129a8:      	ldr	x21, [sp, #0x48]
   129ac:      	add	x2, x24, #0x20
   129b0:      	stp	x2, x24, [sp, #0x50]
   129b4:      	ldr	x8, [sp, #0x30]
   129b8:      	ldr	x25, [sp, #0x8]
   129bc:      	add	x9, sp, #0x70
   129c0:      	cmp	x21, x8
   129c4:      	b.ne	0x129d4 <generic_fentry_path+0x8524>
   129c8:      	ldr	x8, [sp, #0x38]
   129cc:      	cmp	x2, x8
   129d0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   129d4:      	mov	w8, #0x4                // =4
   129d8:      	add	x0, sp, #0x70
   129dc:      	mov	w1, #0x8                // =8
   129e0:      	blr	x8
   129e4:      	ldr	x8, [sp, #0x70]
   129e8:      	cmp	x21, x8
   129ec:      	b.eq	0x12ae0 <generic_fentry_path+0x8630>
   129f0:      	add	x23, x21, #0x18
   129f4:      	mov	w8, #0x4                // =4
   129f8:      	add	x9, sp, #0x98
   129fc:      	add	x0, sp, #0x98
   12a00:      	mov	w1, #0x8                // =8
   12a04:      	mov	x2, x23
   12a08:      	blr	x8
   12a0c:      	ldr	x8, [sp, #0x98]
   12a10:      	cmp	x8, x21
   12a14:      	b.eq	0x12ae0 <generic_fentry_path+0x8630>
   12a18:      	mov	w8, #0x4                // =4
   12a1c:      	add	x9, sp, #0x78
   12a20:      	add	x0, sp, #0x78
   12a24:      	mov	w1, #0x8                // =8
   12a28:      	mov	x2, x23
   12a2c:      	blr	x8
   12a30:      	add	x2, x21, #0x20
   12a34:      	mov	w8, #0x4                // =4
   12a38:      	mov	w9, #0x10               // =16
   12a3c:      	add	x10, sp, #0x80
   12a40:      	add	x0, sp, #0x80
   12a44:      	mov	w1, #0x10               // =16
   12a48:      	blr	x8
   12a4c:      	ldr	w21, [sp, #0x84]
   12a50:      	ldr	x8, [sp, #0x40]
   12a54:      	ldr	x10, [sp, #0x60]
   12a58:      	sub	x12, x10, x8
   12a5c:      	ldr	w23, [sp, #0x68]
   12a60:      	subs	w10, w21, w23
   12a64:      	ldr	x9, [sp, #0x88]
   12a68:      	ldr	x25, [sp, #0x8]
   12a6c:      	csel	w10, wzr, w10, lo
   12a70:      	cmp	w23, w21
   12a74:      	csel	w11, w23, w21, lo
   12a78:      	cinc	w13, w11, hi
   12a7c:      	sub	w14, w23, w13
   12a80:      	subs	x12, x12, x13
   12a84:      	str	w14, [sp, #0x68]
   12a88:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   12a8c:      	cmp	x12, #0xfff
   12a90:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   12a94:      	cmp	w23, w21
   12a98:      	b.ls	0x12aa4 <generic_fentry_path+0x85f4>
   12a9c:      	mov	w13, #0x2f              // =47
   12aa0:      	strb	w13, [x8, x12]
   12aa4:      	add	x19, x8, x12
   12aa8:      	cmp	w23, w21
   12aac:      	add	x2, x9, x10
   12ab0:      	and	w1, w11, #0xff
   12ab4:      	mov	w8, #0x4                // =4
   12ab8:      	cinc	x0, x19, hi
   12abc:      	blr	x8
   12ac0:      	ldr	x25, [sp, #0x8]
   12ac4:      	cmp	w23, w21
   12ac8:      	str	x19, [sp, #0x60]
   12acc:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   12ad0:      	ldr	x21, [sp, #0x78]
   12ad4:      	ldp	x2, x24, [sp, #0x50]
   12ad8:      	str	x21, [sp, #0x48]
   12adc:      	b	0x12b30 <generic_fentry_path+0x8680>
   12ae0:      	add	x2, x24, #0x10
   12ae4:      	mov	w8, #0x4                // =4
   12ae8:      	add	x9, sp, #0x98
   12aec:      	add	x0, sp, #0x98
   12af0:      	mov	w1, #0x8                // =8
   12af4:      	blr	x8
   12af8:      	ldr	x8, [sp, #0x58]
   12afc:      	ldr	x9, [sp, #0x98]
   12b00:      	cmp	x8, x9
   12b04:      	ldr	x25, [sp, #0x8]
   12b08:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   12b0c:      	add	x2, x24, #0x18
   12b10:      	mov	w8, #0x4                // =4
   12b14:      	mov	x0, x22
   12b18:      	mov	w1, #0x8                // =8
   12b1c:      	blr	x8
   12b20:      	ldr	x24, [sp, #0x98]
   12b24:      	ldr	x21, [sp, #0x48]
   12b28:      	add	x2, x24, #0x20
   12b2c:      	stp	x2, x24, [sp, #0x50]
   12b30:      	ldr	x8, [sp, #0x30]
   12b34:      	ldr	x25, [sp, #0x8]
   12b38:      	add	x9, sp, #0x70
   12b3c:      	cmp	x21, x8
   12b40:      	b.ne	0x12b50 <generic_fentry_path+0x86a0>
   12b44:      	ldr	x8, [sp, #0x38]
   12b48:      	cmp	x2, x8
   12b4c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   12b50:      	mov	w8, #0x4                // =4
   12b54:      	add	x0, sp, #0x70
   12b58:      	mov	w1, #0x8                // =8
   12b5c:      	blr	x8
   12b60:      	ldr	x8, [sp, #0x70]
   12b64:      	cmp	x21, x8
   12b68:      	b.eq	0x12c5c <generic_fentry_path+0x87ac>
   12b6c:      	add	x23, x21, #0x18
   12b70:      	mov	w8, #0x4                // =4
   12b74:      	add	x9, sp, #0x98
   12b78:      	add	x0, sp, #0x98
   12b7c:      	mov	w1, #0x8                // =8
   12b80:      	mov	x2, x23
   12b84:      	blr	x8
   12b88:      	ldr	x8, [sp, #0x98]
   12b8c:      	cmp	x8, x21
   12b90:      	b.eq	0x12c5c <generic_fentry_path+0x87ac>
   12b94:      	mov	w8, #0x4                // =4
   12b98:      	add	x9, sp, #0x78
   12b9c:      	add	x0, sp, #0x78
   12ba0:      	mov	w1, #0x8                // =8
   12ba4:      	mov	x2, x23
   12ba8:      	blr	x8
   12bac:      	add	x2, x21, #0x20
   12bb0:      	mov	w8, #0x4                // =4
   12bb4:      	mov	w9, #0x10               // =16
   12bb8:      	add	x10, sp, #0x80
   12bbc:      	add	x0, sp, #0x80
   12bc0:      	mov	w1, #0x10               // =16
   12bc4:      	blr	x8
   12bc8:      	ldr	w21, [sp, #0x84]
   12bcc:      	ldr	x8, [sp, #0x40]
   12bd0:      	ldr	x10, [sp, #0x60]
   12bd4:      	sub	x12, x10, x8
   12bd8:      	ldr	w23, [sp, #0x68]
   12bdc:      	subs	w10, w21, w23
   12be0:      	ldr	x9, [sp, #0x88]
   12be4:      	ldr	x25, [sp, #0x8]
   12be8:      	csel	w10, wzr, w10, lo
   12bec:      	cmp	w23, w21
   12bf0:      	csel	w11, w23, w21, lo
   12bf4:      	cinc	w13, w11, hi
   12bf8:      	sub	w14, w23, w13
   12bfc:      	subs	x12, x12, x13
   12c00:      	str	w14, [sp, #0x68]
   12c04:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   12c08:      	cmp	x12, #0xfff
   12c0c:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   12c10:      	cmp	w23, w21
   12c14:      	b.ls	0x12c20 <generic_fentry_path+0x8770>
   12c18:      	mov	w13, #0x2f              // =47
   12c1c:      	strb	w13, [x8, x12]
   12c20:      	add	x19, x8, x12
   12c24:      	cmp	w23, w21
   12c28:      	add	x2, x9, x10
   12c2c:      	and	w1, w11, #0xff
   12c30:      	mov	w8, #0x4                // =4
   12c34:      	cinc	x0, x19, hi
   12c38:      	blr	x8
   12c3c:      	ldr	x25, [sp, #0x8]
   12c40:      	cmp	w23, w21
   12c44:      	str	x19, [sp, #0x60]
   12c48:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   12c4c:      	ldr	x21, [sp, #0x78]
   12c50:      	ldp	x2, x24, [sp, #0x50]
   12c54:      	str	x21, [sp, #0x48]
   12c58:      	b	0x12cac <generic_fentry_path+0x87fc>
   12c5c:      	add	x2, x24, #0x10
   12c60:      	mov	w8, #0x4                // =4
   12c64:      	add	x9, sp, #0x98
   12c68:      	add	x0, sp, #0x98
   12c6c:      	mov	w1, #0x8                // =8
   12c70:      	blr	x8
   12c74:      	ldr	x8, [sp, #0x58]
   12c78:      	ldr	x9, [sp, #0x98]
   12c7c:      	cmp	x8, x9
   12c80:      	ldr	x25, [sp, #0x8]
   12c84:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   12c88:      	add	x2, x24, #0x18
   12c8c:      	mov	w8, #0x4                // =4
   12c90:      	mov	x0, x22
   12c94:      	mov	w1, #0x8                // =8
   12c98:      	blr	x8
   12c9c:      	ldr	x24, [sp, #0x98]
   12ca0:      	ldr	x21, [sp, #0x48]
   12ca4:      	add	x2, x24, #0x20
   12ca8:      	stp	x2, x24, [sp, #0x50]
   12cac:      	ldr	x8, [sp, #0x30]
   12cb0:      	ldr	x25, [sp, #0x8]
   12cb4:      	add	x9, sp, #0x70
   12cb8:      	cmp	x21, x8
   12cbc:      	b.ne	0x12ccc <generic_fentry_path+0x881c>
   12cc0:      	ldr	x8, [sp, #0x38]
   12cc4:      	cmp	x2, x8
   12cc8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   12ccc:      	mov	w8, #0x4                // =4
   12cd0:      	add	x0, sp, #0x70
   12cd4:      	mov	w1, #0x8                // =8
   12cd8:      	blr	x8
   12cdc:      	ldr	x8, [sp, #0x70]
   12ce0:      	cmp	x21, x8
   12ce4:      	b.eq	0x12dd8 <generic_fentry_path+0x8928>
   12ce8:      	add	x23, x21, #0x18
   12cec:      	mov	w8, #0x4                // =4
   12cf0:      	add	x9, sp, #0x98
   12cf4:      	add	x0, sp, #0x98
   12cf8:      	mov	w1, #0x8                // =8
   12cfc:      	mov	x2, x23
   12d00:      	blr	x8
   12d04:      	ldr	x8, [sp, #0x98]
   12d08:      	cmp	x8, x21
   12d0c:      	b.eq	0x12dd8 <generic_fentry_path+0x8928>
   12d10:      	mov	w8, #0x4                // =4
   12d14:      	add	x9, sp, #0x78
   12d18:      	add	x0, sp, #0x78
   12d1c:      	mov	w1, #0x8                // =8
   12d20:      	mov	x2, x23
   12d24:      	blr	x8
   12d28:      	add	x2, x21, #0x20
   12d2c:      	mov	w8, #0x4                // =4
   12d30:      	mov	w9, #0x10               // =16
   12d34:      	add	x10, sp, #0x80
   12d38:      	add	x0, sp, #0x80
   12d3c:      	mov	w1, #0x10               // =16
   12d40:      	blr	x8
   12d44:      	ldr	w21, [sp, #0x84]
   12d48:      	ldr	x8, [sp, #0x40]
   12d4c:      	ldr	x10, [sp, #0x60]
   12d50:      	sub	x12, x10, x8
   12d54:      	ldr	w23, [sp, #0x68]
   12d58:      	subs	w10, w21, w23
   12d5c:      	ldr	x9, [sp, #0x88]
   12d60:      	ldr	x25, [sp, #0x8]
   12d64:      	csel	w10, wzr, w10, lo
   12d68:      	cmp	w23, w21
   12d6c:      	csel	w11, w23, w21, lo
   12d70:      	cinc	w13, w11, hi
   12d74:      	sub	w14, w23, w13
   12d78:      	subs	x12, x12, x13
   12d7c:      	str	w14, [sp, #0x68]
   12d80:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   12d84:      	cmp	x12, #0xfff
   12d88:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   12d8c:      	cmp	w23, w21
   12d90:      	b.ls	0x12d9c <generic_fentry_path+0x88ec>
   12d94:      	mov	w13, #0x2f              // =47
   12d98:      	strb	w13, [x8, x12]
   12d9c:      	add	x19, x8, x12
   12da0:      	cmp	w23, w21
   12da4:      	add	x2, x9, x10
   12da8:      	and	w1, w11, #0xff
   12dac:      	mov	w8, #0x4                // =4
   12db0:      	cinc	x0, x19, hi
   12db4:      	blr	x8
   12db8:      	ldr	x25, [sp, #0x8]
   12dbc:      	cmp	w23, w21
   12dc0:      	str	x19, [sp, #0x60]
   12dc4:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   12dc8:      	ldr	x21, [sp, #0x78]
   12dcc:      	ldp	x2, x24, [sp, #0x50]
   12dd0:      	str	x21, [sp, #0x48]
   12dd4:      	b	0x12e28 <generic_fentry_path+0x8978>
   12dd8:      	add	x2, x24, #0x10
   12ddc:      	mov	w8, #0x4                // =4
   12de0:      	add	x9, sp, #0x98
   12de4:      	add	x0, sp, #0x98
   12de8:      	mov	w1, #0x8                // =8
   12dec:      	blr	x8
   12df0:      	ldr	x8, [sp, #0x58]
   12df4:      	ldr	x9, [sp, #0x98]
   12df8:      	cmp	x8, x9
   12dfc:      	ldr	x25, [sp, #0x8]
   12e00:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   12e04:      	add	x2, x24, #0x18
   12e08:      	mov	w8, #0x4                // =4
   12e0c:      	mov	x0, x22
   12e10:      	mov	w1, #0x8                // =8
   12e14:      	blr	x8
   12e18:      	ldr	x24, [sp, #0x98]
   12e1c:      	ldr	x21, [sp, #0x48]
   12e20:      	add	x2, x24, #0x20
   12e24:      	stp	x2, x24, [sp, #0x50]
   12e28:      	ldr	x8, [sp, #0x30]
   12e2c:      	ldr	x25, [sp, #0x8]
   12e30:      	add	x9, sp, #0x70
   12e34:      	cmp	x21, x8
   12e38:      	b.ne	0x12e48 <generic_fentry_path+0x8998>
   12e3c:      	ldr	x8, [sp, #0x38]
   12e40:      	cmp	x2, x8
   12e44:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   12e48:      	mov	w8, #0x4                // =4
   12e4c:      	add	x0, sp, #0x70
   12e50:      	mov	w1, #0x8                // =8
   12e54:      	blr	x8
   12e58:      	ldr	x8, [sp, #0x70]
   12e5c:      	cmp	x21, x8
   12e60:      	b.eq	0x12f54 <generic_fentry_path+0x8aa4>
   12e64:      	add	x23, x21, #0x18
   12e68:      	mov	w8, #0x4                // =4
   12e6c:      	add	x9, sp, #0x98
   12e70:      	add	x0, sp, #0x98
   12e74:      	mov	w1, #0x8                // =8
   12e78:      	mov	x2, x23
   12e7c:      	blr	x8
   12e80:      	ldr	x8, [sp, #0x98]
   12e84:      	cmp	x8, x21
   12e88:      	b.eq	0x12f54 <generic_fentry_path+0x8aa4>
   12e8c:      	mov	w8, #0x4                // =4
   12e90:      	add	x9, sp, #0x78
   12e94:      	add	x0, sp, #0x78
   12e98:      	mov	w1, #0x8                // =8
   12e9c:      	mov	x2, x23
   12ea0:      	blr	x8
   12ea4:      	add	x2, x21, #0x20
   12ea8:      	mov	w8, #0x4                // =4
   12eac:      	mov	w9, #0x10               // =16
   12eb0:      	add	x10, sp, #0x80
   12eb4:      	add	x0, sp, #0x80
   12eb8:      	mov	w1, #0x10               // =16
   12ebc:      	blr	x8
   12ec0:      	ldr	w21, [sp, #0x84]
   12ec4:      	ldr	x8, [sp, #0x40]
   12ec8:      	ldr	x10, [sp, #0x60]
   12ecc:      	sub	x12, x10, x8
   12ed0:      	ldr	w23, [sp, #0x68]
   12ed4:      	subs	w10, w21, w23
   12ed8:      	ldr	x9, [sp, #0x88]
   12edc:      	ldr	x25, [sp, #0x8]
   12ee0:      	csel	w10, wzr, w10, lo
   12ee4:      	cmp	w23, w21
   12ee8:      	csel	w11, w23, w21, lo
   12eec:      	cinc	w13, w11, hi
   12ef0:      	sub	w14, w23, w13
   12ef4:      	subs	x12, x12, x13
   12ef8:      	str	w14, [sp, #0x68]
   12efc:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   12f00:      	cmp	x12, #0xfff
   12f04:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   12f08:      	cmp	w23, w21
   12f0c:      	b.ls	0x12f18 <generic_fentry_path+0x8a68>
   12f10:      	mov	w13, #0x2f              // =47
   12f14:      	strb	w13, [x8, x12]
   12f18:      	add	x19, x8, x12
   12f1c:      	cmp	w23, w21
   12f20:      	add	x2, x9, x10
   12f24:      	and	w1, w11, #0xff
   12f28:      	mov	w8, #0x4                // =4
   12f2c:      	cinc	x0, x19, hi
   12f30:      	blr	x8
   12f34:      	ldr	x25, [sp, #0x8]
   12f38:      	cmp	w23, w21
   12f3c:      	str	x19, [sp, #0x60]
   12f40:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   12f44:      	ldr	x21, [sp, #0x78]
   12f48:      	ldp	x2, x24, [sp, #0x50]
   12f4c:      	str	x21, [sp, #0x48]
   12f50:      	b	0x12fa4 <generic_fentry_path+0x8af4>
   12f54:      	add	x2, x24, #0x10
   12f58:      	mov	w8, #0x4                // =4
   12f5c:      	add	x9, sp, #0x98
   12f60:      	add	x0, sp, #0x98
   12f64:      	mov	w1, #0x8                // =8
   12f68:      	blr	x8
   12f6c:      	ldr	x8, [sp, #0x58]
   12f70:      	ldr	x9, [sp, #0x98]
   12f74:      	cmp	x8, x9
   12f78:      	ldr	x25, [sp, #0x8]
   12f7c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   12f80:      	add	x2, x24, #0x18
   12f84:      	mov	w8, #0x4                // =4
   12f88:      	mov	x0, x22
   12f8c:      	mov	w1, #0x8                // =8
   12f90:      	blr	x8
   12f94:      	ldr	x24, [sp, #0x98]
   12f98:      	ldr	x21, [sp, #0x48]
   12f9c:      	add	x2, x24, #0x20
   12fa0:      	stp	x2, x24, [sp, #0x50]
   12fa4:      	ldr	x8, [sp, #0x30]
   12fa8:      	ldr	x25, [sp, #0x8]
   12fac:      	add	x9, sp, #0x70
   12fb0:      	cmp	x21, x8
   12fb4:      	b.ne	0x12fc4 <generic_fentry_path+0x8b14>
   12fb8:      	ldr	x8, [sp, #0x38]
   12fbc:      	cmp	x2, x8
   12fc0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   12fc4:      	mov	w8, #0x4                // =4
   12fc8:      	add	x0, sp, #0x70
   12fcc:      	mov	w1, #0x8                // =8
   12fd0:      	blr	x8
   12fd4:      	ldr	x8, [sp, #0x70]
   12fd8:      	cmp	x21, x8
   12fdc:      	b.eq	0x130d0 <generic_fentry_path+0x8c20>
   12fe0:      	add	x23, x21, #0x18
   12fe4:      	mov	w8, #0x4                // =4
   12fe8:      	add	x9, sp, #0x98
   12fec:      	add	x0, sp, #0x98
   12ff0:      	mov	w1, #0x8                // =8
   12ff4:      	mov	x2, x23
   12ff8:      	blr	x8
   12ffc:      	ldr	x8, [sp, #0x98]
   13000:      	cmp	x8, x21
   13004:      	b.eq	0x130d0 <generic_fentry_path+0x8c20>
   13008:      	mov	w8, #0x4                // =4
   1300c:      	add	x9, sp, #0x78
   13010:      	add	x0, sp, #0x78
   13014:      	mov	w1, #0x8                // =8
   13018:      	mov	x2, x23
   1301c:      	blr	x8
   13020:      	add	x2, x21, #0x20
   13024:      	mov	w8, #0x4                // =4
   13028:      	mov	w9, #0x10               // =16
   1302c:      	add	x10, sp, #0x80
   13030:      	add	x0, sp, #0x80
   13034:      	mov	w1, #0x10               // =16
   13038:      	blr	x8
   1303c:      	ldr	w21, [sp, #0x84]
   13040:      	ldr	x8, [sp, #0x40]
   13044:      	ldr	x10, [sp, #0x60]
   13048:      	sub	x12, x10, x8
   1304c:      	ldr	w23, [sp, #0x68]
   13050:      	subs	w10, w21, w23
   13054:      	ldr	x9, [sp, #0x88]
   13058:      	ldr	x25, [sp, #0x8]
   1305c:      	csel	w10, wzr, w10, lo
   13060:      	cmp	w23, w21
   13064:      	csel	w11, w23, w21, lo
   13068:      	cinc	w13, w11, hi
   1306c:      	sub	w14, w23, w13
   13070:      	subs	x12, x12, x13
   13074:      	str	w14, [sp, #0x68]
   13078:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   1307c:      	cmp	x12, #0xfff
   13080:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   13084:      	cmp	w23, w21
   13088:      	b.ls	0x13094 <generic_fentry_path+0x8be4>
   1308c:      	mov	w13, #0x2f              // =47
   13090:      	strb	w13, [x8, x12]
   13094:      	add	x19, x8, x12
   13098:      	cmp	w23, w21
   1309c:      	add	x2, x9, x10
   130a0:      	and	w1, w11, #0xff
   130a4:      	mov	w8, #0x4                // =4
   130a8:      	cinc	x0, x19, hi
   130ac:      	blr	x8
   130b0:      	ldr	x25, [sp, #0x8]
   130b4:      	cmp	w23, w21
   130b8:      	str	x19, [sp, #0x60]
   130bc:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   130c0:      	ldr	x21, [sp, #0x78]
   130c4:      	ldp	x2, x24, [sp, #0x50]
   130c8:      	str	x21, [sp, #0x48]
   130cc:      	b	0x13120 <generic_fentry_path+0x8c70>
   130d0:      	add	x2, x24, #0x10
   130d4:      	mov	w8, #0x4                // =4
   130d8:      	add	x9, sp, #0x98
   130dc:      	add	x0, sp, #0x98
   130e0:      	mov	w1, #0x8                // =8
   130e4:      	blr	x8
   130e8:      	ldr	x8, [sp, #0x58]
   130ec:      	ldr	x9, [sp, #0x98]
   130f0:      	cmp	x8, x9
   130f4:      	ldr	x25, [sp, #0x8]
   130f8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   130fc:      	add	x2, x24, #0x18
   13100:      	mov	w8, #0x4                // =4
   13104:      	mov	x0, x22
   13108:      	mov	w1, #0x8                // =8
   1310c:      	blr	x8
   13110:      	ldr	x24, [sp, #0x98]
   13114:      	ldr	x21, [sp, #0x48]
   13118:      	add	x2, x24, #0x20
   1311c:      	stp	x2, x24, [sp, #0x50]
   13120:      	ldr	x8, [sp, #0x30]
   13124:      	ldr	x25, [sp, #0x8]
   13128:      	add	x9, sp, #0x70
   1312c:      	cmp	x21, x8
   13130:      	b.ne	0x13140 <generic_fentry_path+0x8c90>
   13134:      	ldr	x8, [sp, #0x38]
   13138:      	cmp	x2, x8
   1313c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   13140:      	mov	w8, #0x4                // =4
   13144:      	add	x0, sp, #0x70
   13148:      	mov	w1, #0x8                // =8
   1314c:      	blr	x8
   13150:      	ldr	x8, [sp, #0x70]
   13154:      	cmp	x21, x8
   13158:      	b.eq	0x1324c <generic_fentry_path+0x8d9c>
   1315c:      	add	x23, x21, #0x18
   13160:      	mov	w8, #0x4                // =4
   13164:      	add	x9, sp, #0x98
   13168:      	add	x0, sp, #0x98
   1316c:      	mov	w1, #0x8                // =8
   13170:      	mov	x2, x23
   13174:      	blr	x8
   13178:      	ldr	x8, [sp, #0x98]
   1317c:      	cmp	x8, x21
   13180:      	b.eq	0x1324c <generic_fentry_path+0x8d9c>
   13184:      	mov	w8, #0x4                // =4
   13188:      	add	x9, sp, #0x78
   1318c:      	add	x0, sp, #0x78
   13190:      	mov	w1, #0x8                // =8
   13194:      	mov	x2, x23
   13198:      	blr	x8
   1319c:      	add	x2, x21, #0x20
   131a0:      	mov	w8, #0x4                // =4
   131a4:      	mov	w9, #0x10               // =16
   131a8:      	add	x10, sp, #0x80
   131ac:      	add	x0, sp, #0x80
   131b0:      	mov	w1, #0x10               // =16
   131b4:      	blr	x8
   131b8:      	ldr	w21, [sp, #0x84]
   131bc:      	ldr	x8, [sp, #0x40]
   131c0:      	ldr	x10, [sp, #0x60]
   131c4:      	sub	x12, x10, x8
   131c8:      	ldr	w23, [sp, #0x68]
   131cc:      	subs	w10, w21, w23
   131d0:      	ldr	x9, [sp, #0x88]
   131d4:      	ldr	x25, [sp, #0x8]
   131d8:      	csel	w10, wzr, w10, lo
   131dc:      	cmp	w23, w21
   131e0:      	csel	w11, w23, w21, lo
   131e4:      	cinc	w13, w11, hi
   131e8:      	sub	w14, w23, w13
   131ec:      	subs	x12, x12, x13
   131f0:      	str	w14, [sp, #0x68]
   131f4:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   131f8:      	cmp	x12, #0xfff
   131fc:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   13200:      	cmp	w23, w21
   13204:      	b.ls	0x13210 <generic_fentry_path+0x8d60>
   13208:      	mov	w13, #0x2f              // =47
   1320c:      	strb	w13, [x8, x12]
   13210:      	add	x19, x8, x12
   13214:      	cmp	w23, w21
   13218:      	add	x2, x9, x10
   1321c:      	and	w1, w11, #0xff
   13220:      	mov	w8, #0x4                // =4
   13224:      	cinc	x0, x19, hi
   13228:      	blr	x8
   1322c:      	ldr	x25, [sp, #0x8]
   13230:      	cmp	w23, w21
   13234:      	str	x19, [sp, #0x60]
   13238:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   1323c:      	ldr	x21, [sp, #0x78]
   13240:      	ldp	x2, x24, [sp, #0x50]
   13244:      	str	x21, [sp, #0x48]
   13248:      	b	0x1329c <generic_fentry_path+0x8dec>
   1324c:      	add	x2, x24, #0x10
   13250:      	mov	w8, #0x4                // =4
   13254:      	add	x9, sp, #0x98
   13258:      	add	x0, sp, #0x98
   1325c:      	mov	w1, #0x8                // =8
   13260:      	blr	x8
   13264:      	ldr	x8, [sp, #0x58]
   13268:      	ldr	x9, [sp, #0x98]
   1326c:      	cmp	x8, x9
   13270:      	ldr	x25, [sp, #0x8]
   13274:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   13278:      	add	x2, x24, #0x18
   1327c:      	mov	w8, #0x4                // =4
   13280:      	mov	x0, x22
   13284:      	mov	w1, #0x8                // =8
   13288:      	blr	x8
   1328c:      	ldr	x24, [sp, #0x98]
   13290:      	ldr	x21, [sp, #0x48]
   13294:      	add	x2, x24, #0x20
   13298:      	stp	x2, x24, [sp, #0x50]
   1329c:      	ldr	x8, [sp, #0x30]
   132a0:      	ldr	x25, [sp, #0x8]
   132a4:      	add	x9, sp, #0x70
   132a8:      	cmp	x21, x8
   132ac:      	b.ne	0x132bc <generic_fentry_path+0x8e0c>
   132b0:      	ldr	x8, [sp, #0x38]
   132b4:      	cmp	x2, x8
   132b8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   132bc:      	mov	w8, #0x4                // =4
   132c0:      	add	x0, sp, #0x70
   132c4:      	mov	w1, #0x8                // =8
   132c8:      	blr	x8
   132cc:      	ldr	x8, [sp, #0x70]
   132d0:      	cmp	x21, x8
   132d4:      	b.eq	0x133c8 <generic_fentry_path+0x8f18>
   132d8:      	add	x23, x21, #0x18
   132dc:      	mov	w8, #0x4                // =4
   132e0:      	add	x9, sp, #0x98
   132e4:      	add	x0, sp, #0x98
   132e8:      	mov	w1, #0x8                // =8
   132ec:      	mov	x2, x23
   132f0:      	blr	x8
   132f4:      	ldr	x8, [sp, #0x98]
   132f8:      	cmp	x8, x21
   132fc:      	b.eq	0x133c8 <generic_fentry_path+0x8f18>
   13300:      	mov	w8, #0x4                // =4
   13304:      	add	x9, sp, #0x78
   13308:      	add	x0, sp, #0x78
   1330c:      	mov	w1, #0x8                // =8
   13310:      	mov	x2, x23
   13314:      	blr	x8
   13318:      	add	x2, x21, #0x20
   1331c:      	mov	w8, #0x4                // =4
   13320:      	mov	w9, #0x10               // =16
   13324:      	add	x10, sp, #0x80
   13328:      	add	x0, sp, #0x80
   1332c:      	mov	w1, #0x10               // =16
   13330:      	blr	x8
   13334:      	ldr	w21, [sp, #0x84]
   13338:      	ldr	x8, [sp, #0x40]
   1333c:      	ldr	x10, [sp, #0x60]
   13340:      	sub	x12, x10, x8
   13344:      	ldr	w23, [sp, #0x68]
   13348:      	subs	w10, w21, w23
   1334c:      	ldr	x9, [sp, #0x88]
   13350:      	ldr	x25, [sp, #0x8]
   13354:      	csel	w10, wzr, w10, lo
   13358:      	cmp	w23, w21
   1335c:      	csel	w11, w23, w21, lo
   13360:      	cinc	w13, w11, hi
   13364:      	sub	w14, w23, w13
   13368:      	subs	x12, x12, x13
   1336c:      	str	w14, [sp, #0x68]
   13370:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   13374:      	cmp	x12, #0xfff
   13378:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   1337c:      	cmp	w23, w21
   13380:      	b.ls	0x1338c <generic_fentry_path+0x8edc>
   13384:      	mov	w13, #0x2f              // =47
   13388:      	strb	w13, [x8, x12]
   1338c:      	add	x19, x8, x12
   13390:      	cmp	w23, w21
   13394:      	add	x2, x9, x10
   13398:      	and	w1, w11, #0xff
   1339c:      	mov	w8, #0x4                // =4
   133a0:      	cinc	x0, x19, hi
   133a4:      	blr	x8
   133a8:      	ldr	x25, [sp, #0x8]
   133ac:      	cmp	w23, w21
   133b0:      	str	x19, [sp, #0x60]
   133b4:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   133b8:      	ldr	x21, [sp, #0x78]
   133bc:      	ldp	x2, x24, [sp, #0x50]
   133c0:      	str	x21, [sp, #0x48]
   133c4:      	b	0x13418 <generic_fentry_path+0x8f68>
   133c8:      	add	x2, x24, #0x10
   133cc:      	mov	w8, #0x4                // =4
   133d0:      	add	x9, sp, #0x98
   133d4:      	add	x0, sp, #0x98
   133d8:      	mov	w1, #0x8                // =8
   133dc:      	blr	x8
   133e0:      	ldr	x8, [sp, #0x58]
   133e4:      	ldr	x9, [sp, #0x98]
   133e8:      	cmp	x8, x9
   133ec:      	ldr	x25, [sp, #0x8]
   133f0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   133f4:      	add	x2, x24, #0x18
   133f8:      	mov	w8, #0x4                // =4
   133fc:      	mov	x0, x22
   13400:      	mov	w1, #0x8                // =8
   13404:      	blr	x8
   13408:      	ldr	x24, [sp, #0x98]
   1340c:      	ldr	x21, [sp, #0x48]
   13410:      	add	x2, x24, #0x20
   13414:      	stp	x2, x24, [sp, #0x50]
   13418:      	ldr	x8, [sp, #0x30]
   1341c:      	ldr	x25, [sp, #0x8]
   13420:      	add	x9, sp, #0x70
   13424:      	cmp	x21, x8
   13428:      	b.ne	0x13438 <generic_fentry_path+0x8f88>
   1342c:      	ldr	x8, [sp, #0x38]
   13430:      	cmp	x2, x8
   13434:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   13438:      	mov	w8, #0x4                // =4
   1343c:      	add	x0, sp, #0x70
   13440:      	mov	w1, #0x8                // =8
   13444:      	blr	x8
   13448:      	ldr	x8, [sp, #0x70]
   1344c:      	cmp	x21, x8
   13450:      	b.eq	0x13544 <generic_fentry_path+0x9094>
   13454:      	add	x23, x21, #0x18
   13458:      	mov	w8, #0x4                // =4
   1345c:      	add	x9, sp, #0x98
   13460:      	add	x0, sp, #0x98
   13464:      	mov	w1, #0x8                // =8
   13468:      	mov	x2, x23
   1346c:      	blr	x8
   13470:      	ldr	x8, [sp, #0x98]
   13474:      	cmp	x8, x21
   13478:      	b.eq	0x13544 <generic_fentry_path+0x9094>
   1347c:      	mov	w8, #0x4                // =4
   13480:      	add	x9, sp, #0x78
   13484:      	add	x0, sp, #0x78
   13488:      	mov	w1, #0x8                // =8
   1348c:      	mov	x2, x23
   13490:      	blr	x8
   13494:      	add	x2, x21, #0x20
   13498:      	mov	w8, #0x4                // =4
   1349c:      	mov	w9, #0x10               // =16
   134a0:      	add	x10, sp, #0x80
   134a4:      	add	x0, sp, #0x80
   134a8:      	mov	w1, #0x10               // =16
   134ac:      	blr	x8
   134b0:      	ldr	w21, [sp, #0x84]
   134b4:      	ldr	x8, [sp, #0x40]
   134b8:      	ldr	x10, [sp, #0x60]
   134bc:      	sub	x12, x10, x8
   134c0:      	ldr	w23, [sp, #0x68]
   134c4:      	subs	w10, w21, w23
   134c8:      	ldr	x9, [sp, #0x88]
   134cc:      	ldr	x25, [sp, #0x8]
   134d0:      	csel	w10, wzr, w10, lo
   134d4:      	cmp	w23, w21
   134d8:      	csel	w11, w23, w21, lo
   134dc:      	cinc	w13, w11, hi
   134e0:      	sub	w14, w23, w13
   134e4:      	subs	x12, x12, x13
   134e8:      	str	w14, [sp, #0x68]
   134ec:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   134f0:      	cmp	x12, #0xfff
   134f4:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   134f8:      	cmp	w23, w21
   134fc:      	b.ls	0x13508 <generic_fentry_path+0x9058>
   13500:      	mov	w13, #0x2f              // =47
   13504:      	strb	w13, [x8, x12]
   13508:      	add	x19, x8, x12
   1350c:      	cmp	w23, w21
   13510:      	add	x2, x9, x10
   13514:      	and	w1, w11, #0xff
   13518:      	mov	w8, #0x4                // =4
   1351c:      	cinc	x0, x19, hi
   13520:      	blr	x8
   13524:      	ldr	x25, [sp, #0x8]
   13528:      	cmp	w23, w21
   1352c:      	str	x19, [sp, #0x60]
   13530:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   13534:      	ldr	x21, [sp, #0x78]
   13538:      	ldp	x2, x24, [sp, #0x50]
   1353c:      	str	x21, [sp, #0x48]
   13540:      	b	0x13594 <generic_fentry_path+0x90e4>
   13544:      	add	x2, x24, #0x10
   13548:      	mov	w8, #0x4                // =4
   1354c:      	add	x9, sp, #0x98
   13550:      	add	x0, sp, #0x98
   13554:      	mov	w1, #0x8                // =8
   13558:      	blr	x8
   1355c:      	ldr	x8, [sp, #0x58]
   13560:      	ldr	x9, [sp, #0x98]
   13564:      	cmp	x8, x9
   13568:      	ldr	x25, [sp, #0x8]
   1356c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   13570:      	add	x2, x24, #0x18
   13574:      	mov	w8, #0x4                // =4
   13578:      	mov	x0, x22
   1357c:      	mov	w1, #0x8                // =8
   13580:      	blr	x8
   13584:      	ldr	x24, [sp, #0x98]
   13588:      	ldr	x21, [sp, #0x48]
   1358c:      	add	x2, x24, #0x20
   13590:      	stp	x2, x24, [sp, #0x50]
   13594:      	ldr	x8, [sp, #0x30]
   13598:      	ldr	x25, [sp, #0x8]
   1359c:      	add	x9, sp, #0x70
   135a0:      	cmp	x21, x8
   135a4:      	b.ne	0x135b4 <generic_fentry_path+0x9104>
   135a8:      	ldr	x8, [sp, #0x38]
   135ac:      	cmp	x2, x8
   135b0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   135b4:      	mov	w8, #0x4                // =4
   135b8:      	add	x0, sp, #0x70
   135bc:      	mov	w1, #0x8                // =8
   135c0:      	blr	x8
   135c4:      	ldr	x8, [sp, #0x70]
   135c8:      	cmp	x21, x8
   135cc:      	b.eq	0x136c0 <generic_fentry_path+0x9210>
   135d0:      	add	x23, x21, #0x18
   135d4:      	mov	w8, #0x4                // =4
   135d8:      	add	x9, sp, #0x98
   135dc:      	add	x0, sp, #0x98
   135e0:      	mov	w1, #0x8                // =8
   135e4:      	mov	x2, x23
   135e8:      	blr	x8
   135ec:      	ldr	x8, [sp, #0x98]
   135f0:      	cmp	x8, x21
   135f4:      	b.eq	0x136c0 <generic_fentry_path+0x9210>
   135f8:      	mov	w8, #0x4                // =4
   135fc:      	add	x9, sp, #0x78
   13600:      	add	x0, sp, #0x78
   13604:      	mov	w1, #0x8                // =8
   13608:      	mov	x2, x23
   1360c:      	blr	x8
   13610:      	add	x2, x21, #0x20
   13614:      	mov	w8, #0x4                // =4
   13618:      	mov	w9, #0x10               // =16
   1361c:      	add	x10, sp, #0x80
   13620:      	add	x0, sp, #0x80
   13624:      	mov	w1, #0x10               // =16
   13628:      	blr	x8
   1362c:      	ldr	w21, [sp, #0x84]
   13630:      	ldr	x8, [sp, #0x40]
   13634:      	ldr	x10, [sp, #0x60]
   13638:      	sub	x12, x10, x8
   1363c:      	ldr	w23, [sp, #0x68]
   13640:      	subs	w10, w21, w23
   13644:      	ldr	x9, [sp, #0x88]
   13648:      	ldr	x25, [sp, #0x8]
   1364c:      	csel	w10, wzr, w10, lo
   13650:      	cmp	w23, w21
   13654:      	csel	w11, w23, w21, lo
   13658:      	cinc	w13, w11, hi
   1365c:      	sub	w14, w23, w13
   13660:      	subs	x12, x12, x13
   13664:      	str	w14, [sp, #0x68]
   13668:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   1366c:      	cmp	x12, #0xfff
   13670:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   13674:      	cmp	w23, w21
   13678:      	b.ls	0x13684 <generic_fentry_path+0x91d4>
   1367c:      	mov	w13, #0x2f              // =47
   13680:      	strb	w13, [x8, x12]
   13684:      	add	x19, x8, x12
   13688:      	cmp	w23, w21
   1368c:      	add	x2, x9, x10
   13690:      	and	w1, w11, #0xff
   13694:      	mov	w8, #0x4                // =4
   13698:      	cinc	x0, x19, hi
   1369c:      	blr	x8
   136a0:      	ldr	x25, [sp, #0x8]
   136a4:      	cmp	w23, w21
   136a8:      	str	x19, [sp, #0x60]
   136ac:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   136b0:      	ldr	x21, [sp, #0x78]
   136b4:      	ldp	x2, x24, [sp, #0x50]
   136b8:      	str	x21, [sp, #0x48]
   136bc:      	b	0x13710 <generic_fentry_path+0x9260>
   136c0:      	add	x2, x24, #0x10
   136c4:      	mov	w8, #0x4                // =4
   136c8:      	add	x9, sp, #0x98
   136cc:      	add	x0, sp, #0x98
   136d0:      	mov	w1, #0x8                // =8
   136d4:      	blr	x8
   136d8:      	ldr	x8, [sp, #0x58]
   136dc:      	ldr	x9, [sp, #0x98]
   136e0:      	cmp	x8, x9
   136e4:      	ldr	x25, [sp, #0x8]
   136e8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   136ec:      	add	x2, x24, #0x18
   136f0:      	mov	w8, #0x4                // =4
   136f4:      	mov	x0, x22
   136f8:      	mov	w1, #0x8                // =8
   136fc:      	blr	x8
   13700:      	ldr	x24, [sp, #0x98]
   13704:      	ldr	x21, [sp, #0x48]
   13708:      	add	x2, x24, #0x20
   1370c:      	stp	x2, x24, [sp, #0x50]
   13710:      	ldr	x8, [sp, #0x30]
   13714:      	ldr	x25, [sp, #0x8]
   13718:      	add	x9, sp, #0x70
   1371c:      	cmp	x21, x8
   13720:      	b.ne	0x13730 <generic_fentry_path+0x9280>
   13724:      	ldr	x8, [sp, #0x38]
   13728:      	cmp	x2, x8
   1372c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   13730:      	mov	w8, #0x4                // =4
   13734:      	add	x0, sp, #0x70
   13738:      	mov	w1, #0x8                // =8
   1373c:      	blr	x8
   13740:      	ldr	x8, [sp, #0x70]
   13744:      	cmp	x21, x8
   13748:      	b.eq	0x1383c <generic_fentry_path+0x938c>
   1374c:      	add	x23, x21, #0x18
   13750:      	mov	w8, #0x4                // =4
   13754:      	add	x9, sp, #0x98
   13758:      	add	x0, sp, #0x98
   1375c:      	mov	w1, #0x8                // =8
   13760:      	mov	x2, x23
   13764:      	blr	x8
   13768:      	ldr	x8, [sp, #0x98]
   1376c:      	cmp	x8, x21
   13770:      	b.eq	0x1383c <generic_fentry_path+0x938c>
   13774:      	mov	w8, #0x4                // =4
   13778:      	add	x9, sp, #0x78
   1377c:      	add	x0, sp, #0x78
   13780:      	mov	w1, #0x8                // =8
   13784:      	mov	x2, x23
   13788:      	blr	x8
   1378c:      	add	x2, x21, #0x20
   13790:      	mov	w8, #0x4                // =4
   13794:      	mov	w9, #0x10               // =16
   13798:      	add	x10, sp, #0x80
   1379c:      	add	x0, sp, #0x80
   137a0:      	mov	w1, #0x10               // =16
   137a4:      	blr	x8
   137a8:      	ldr	w21, [sp, #0x84]
   137ac:      	ldr	x8, [sp, #0x40]
   137b0:      	ldr	x10, [sp, #0x60]
   137b4:      	sub	x12, x10, x8
   137b8:      	ldr	w23, [sp, #0x68]
   137bc:      	subs	w10, w21, w23
   137c0:      	ldr	x9, [sp, #0x88]
   137c4:      	ldr	x25, [sp, #0x8]
   137c8:      	csel	w10, wzr, w10, lo
   137cc:      	cmp	w23, w21
   137d0:      	csel	w11, w23, w21, lo
   137d4:      	cinc	w13, w11, hi
   137d8:      	sub	w14, w23, w13
   137dc:      	subs	x12, x12, x13
   137e0:      	str	w14, [sp, #0x68]
   137e4:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   137e8:      	cmp	x12, #0xfff
   137ec:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   137f0:      	cmp	w23, w21
   137f4:      	b.ls	0x13800 <generic_fentry_path+0x9350>
   137f8:      	mov	w13, #0x2f              // =47
   137fc:      	strb	w13, [x8, x12]
   13800:      	add	x19, x8, x12
   13804:      	cmp	w23, w21
   13808:      	add	x2, x9, x10
   1380c:      	and	w1, w11, #0xff
   13810:      	mov	w8, #0x4                // =4
   13814:      	cinc	x0, x19, hi
   13818:      	blr	x8
   1381c:      	ldr	x25, [sp, #0x8]
   13820:      	cmp	w23, w21
   13824:      	str	x19, [sp, #0x60]
   13828:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   1382c:      	ldr	x21, [sp, #0x78]
   13830:      	ldp	x2, x24, [sp, #0x50]
   13834:      	str	x21, [sp, #0x48]
   13838:      	b	0x1388c <generic_fentry_path+0x93dc>
   1383c:      	add	x2, x24, #0x10
   13840:      	mov	w8, #0x4                // =4
   13844:      	add	x9, sp, #0x98
   13848:      	add	x0, sp, #0x98
   1384c:      	mov	w1, #0x8                // =8
   13850:      	blr	x8
   13854:      	ldr	x8, [sp, #0x58]
   13858:      	ldr	x9, [sp, #0x98]
   1385c:      	cmp	x8, x9
   13860:      	ldr	x25, [sp, #0x8]
   13864:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   13868:      	add	x2, x24, #0x18
   1386c:      	mov	w8, #0x4                // =4
   13870:      	mov	x0, x22
   13874:      	mov	w1, #0x8                // =8
   13878:      	blr	x8
   1387c:      	ldr	x24, [sp, #0x98]
   13880:      	ldr	x21, [sp, #0x48]
   13884:      	add	x2, x24, #0x20
   13888:      	stp	x2, x24, [sp, #0x50]
   1388c:      	ldr	x8, [sp, #0x30]
   13890:      	ldr	x25, [sp, #0x8]
   13894:      	add	x9, sp, #0x70
   13898:      	cmp	x21, x8
   1389c:      	b.ne	0x138ac <generic_fentry_path+0x93fc>
   138a0:      	ldr	x8, [sp, #0x38]
   138a4:      	cmp	x2, x8
   138a8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   138ac:      	mov	w8, #0x4                // =4
   138b0:      	add	x0, sp, #0x70
   138b4:      	mov	w1, #0x8                // =8
   138b8:      	blr	x8
   138bc:      	ldr	x8, [sp, #0x70]
   138c0:      	cmp	x21, x8
   138c4:      	b.eq	0x139b8 <generic_fentry_path+0x9508>
   138c8:      	add	x23, x21, #0x18
   138cc:      	mov	w8, #0x4                // =4
   138d0:      	add	x9, sp, #0x98
   138d4:      	add	x0, sp, #0x98
   138d8:      	mov	w1, #0x8                // =8
   138dc:      	mov	x2, x23
   138e0:      	blr	x8
   138e4:      	ldr	x8, [sp, #0x98]
   138e8:      	cmp	x8, x21
   138ec:      	b.eq	0x139b8 <generic_fentry_path+0x9508>
   138f0:      	mov	w8, #0x4                // =4
   138f4:      	add	x9, sp, #0x78
   138f8:      	add	x0, sp, #0x78
   138fc:      	mov	w1, #0x8                // =8
   13900:      	mov	x2, x23
   13904:      	blr	x8
   13908:      	add	x2, x21, #0x20
   1390c:      	mov	w8, #0x4                // =4
   13910:      	mov	w9, #0x10               // =16
   13914:      	add	x10, sp, #0x80
   13918:      	add	x0, sp, #0x80
   1391c:      	mov	w1, #0x10               // =16
   13920:      	blr	x8
   13924:      	ldr	w21, [sp, #0x84]
   13928:      	ldr	x8, [sp, #0x40]
   1392c:      	ldr	x10, [sp, #0x60]
   13930:      	sub	x12, x10, x8
   13934:      	ldr	w23, [sp, #0x68]
   13938:      	subs	w10, w21, w23
   1393c:      	ldr	x9, [sp, #0x88]
   13940:      	ldr	x25, [sp, #0x8]
   13944:      	csel	w10, wzr, w10, lo
   13948:      	cmp	w23, w21
   1394c:      	csel	w11, w23, w21, lo
   13950:      	cinc	w13, w11, hi
   13954:      	sub	w14, w23, w13
   13958:      	subs	x12, x12, x13
   1395c:      	str	w14, [sp, #0x68]
   13960:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   13964:      	cmp	x12, #0xfff
   13968:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   1396c:      	cmp	w23, w21
   13970:      	b.ls	0x1397c <generic_fentry_path+0x94cc>
   13974:      	mov	w13, #0x2f              // =47
   13978:      	strb	w13, [x8, x12]
   1397c:      	add	x19, x8, x12
   13980:      	cmp	w23, w21
   13984:      	add	x2, x9, x10
   13988:      	and	w1, w11, #0xff
   1398c:      	mov	w8, #0x4                // =4
   13990:      	cinc	x0, x19, hi
   13994:      	blr	x8
   13998:      	ldr	x25, [sp, #0x8]
   1399c:      	cmp	w23, w21
   139a0:      	str	x19, [sp, #0x60]
   139a4:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   139a8:      	ldr	x21, [sp, #0x78]
   139ac:      	ldp	x2, x24, [sp, #0x50]
   139b0:      	str	x21, [sp, #0x48]
   139b4:      	b	0x13a08 <generic_fentry_path+0x9558>
   139b8:      	add	x2, x24, #0x10
   139bc:      	mov	w8, #0x4                // =4
   139c0:      	add	x9, sp, #0x98
   139c4:      	add	x0, sp, #0x98
   139c8:      	mov	w1, #0x8                // =8
   139cc:      	blr	x8
   139d0:      	ldr	x8, [sp, #0x58]
   139d4:      	ldr	x9, [sp, #0x98]
   139d8:      	cmp	x8, x9
   139dc:      	ldr	x25, [sp, #0x8]
   139e0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   139e4:      	add	x2, x24, #0x18
   139e8:      	mov	w8, #0x4                // =4
   139ec:      	mov	x0, x22
   139f0:      	mov	w1, #0x8                // =8
   139f4:      	blr	x8
   139f8:      	ldr	x24, [sp, #0x98]
   139fc:      	ldr	x21, [sp, #0x48]
   13a00:      	add	x2, x24, #0x20
   13a04:      	stp	x2, x24, [sp, #0x50]
   13a08:      	ldr	x8, [sp, #0x30]
   13a0c:      	ldr	x25, [sp, #0x8]
   13a10:      	add	x9, sp, #0x70
   13a14:      	cmp	x21, x8
   13a18:      	b.ne	0x13a28 <generic_fentry_path+0x9578>
   13a1c:      	ldr	x8, [sp, #0x38]
   13a20:      	cmp	x2, x8
   13a24:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   13a28:      	mov	w8, #0x4                // =4
   13a2c:      	add	x0, sp, #0x70
   13a30:      	mov	w1, #0x8                // =8
   13a34:      	blr	x8
   13a38:      	ldr	x8, [sp, #0x70]
   13a3c:      	cmp	x21, x8
   13a40:      	b.eq	0x13b34 <generic_fentry_path+0x9684>
   13a44:      	add	x23, x21, #0x18
   13a48:      	mov	w8, #0x4                // =4
   13a4c:      	add	x9, sp, #0x98
   13a50:      	add	x0, sp, #0x98
   13a54:      	mov	w1, #0x8                // =8
   13a58:      	mov	x2, x23
   13a5c:      	blr	x8
   13a60:      	ldr	x8, [sp, #0x98]
   13a64:      	cmp	x8, x21
   13a68:      	b.eq	0x13b34 <generic_fentry_path+0x9684>
   13a6c:      	mov	w8, #0x4                // =4
   13a70:      	add	x9, sp, #0x78
   13a74:      	add	x0, sp, #0x78
   13a78:      	mov	w1, #0x8                // =8
   13a7c:      	mov	x2, x23
   13a80:      	blr	x8
   13a84:      	add	x2, x21, #0x20
   13a88:      	mov	w8, #0x4                // =4
   13a8c:      	mov	w9, #0x10               // =16
   13a90:      	add	x10, sp, #0x80
   13a94:      	add	x0, sp, #0x80
   13a98:      	mov	w1, #0x10               // =16
   13a9c:      	blr	x8
   13aa0:      	ldr	w21, [sp, #0x84]
   13aa4:      	ldr	x8, [sp, #0x40]
   13aa8:      	ldr	x10, [sp, #0x60]
   13aac:      	sub	x12, x10, x8
   13ab0:      	ldr	w23, [sp, #0x68]
   13ab4:      	subs	w10, w21, w23
   13ab8:      	ldr	x9, [sp, #0x88]
   13abc:      	ldr	x25, [sp, #0x8]
   13ac0:      	csel	w10, wzr, w10, lo
   13ac4:      	cmp	w23, w21
   13ac8:      	csel	w11, w23, w21, lo
   13acc:      	cinc	w13, w11, hi
   13ad0:      	sub	w14, w23, w13
   13ad4:      	subs	x12, x12, x13
   13ad8:      	str	w14, [sp, #0x68]
   13adc:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   13ae0:      	cmp	x12, #0xfff
   13ae4:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   13ae8:      	cmp	w23, w21
   13aec:      	b.ls	0x13af8 <generic_fentry_path+0x9648>
   13af0:      	mov	w13, #0x2f              // =47
   13af4:      	strb	w13, [x8, x12]
   13af8:      	add	x19, x8, x12
   13afc:      	cmp	w23, w21
   13b00:      	add	x2, x9, x10
   13b04:      	and	w1, w11, #0xff
   13b08:      	mov	w8, #0x4                // =4
   13b0c:      	cinc	x0, x19, hi
   13b10:      	blr	x8
   13b14:      	ldr	x25, [sp, #0x8]
   13b18:      	cmp	w23, w21
   13b1c:      	str	x19, [sp, #0x60]
   13b20:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   13b24:      	ldr	x21, [sp, #0x78]
   13b28:      	ldp	x2, x24, [sp, #0x50]
   13b2c:      	str	x21, [sp, #0x48]
   13b30:      	b	0x13b84 <generic_fentry_path+0x96d4>
   13b34:      	add	x2, x24, #0x10
   13b38:      	mov	w8, #0x4                // =4
   13b3c:      	add	x9, sp, #0x98
   13b40:      	add	x0, sp, #0x98
   13b44:      	mov	w1, #0x8                // =8
   13b48:      	blr	x8
   13b4c:      	ldr	x8, [sp, #0x58]
   13b50:      	ldr	x9, [sp, #0x98]
   13b54:      	cmp	x8, x9
   13b58:      	ldr	x25, [sp, #0x8]
   13b5c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   13b60:      	add	x2, x24, #0x18
   13b64:      	mov	w8, #0x4                // =4
   13b68:      	mov	x0, x22
   13b6c:      	mov	w1, #0x8                // =8
   13b70:      	blr	x8
   13b74:      	ldr	x24, [sp, #0x98]
   13b78:      	ldr	x21, [sp, #0x48]
   13b7c:      	add	x2, x24, #0x20
   13b80:      	stp	x2, x24, [sp, #0x50]
   13b84:      	ldr	x8, [sp, #0x30]
   13b88:      	ldr	x25, [sp, #0x8]
   13b8c:      	add	x9, sp, #0x70
   13b90:      	cmp	x21, x8
   13b94:      	b.ne	0x13ba4 <generic_fentry_path+0x96f4>
   13b98:      	ldr	x8, [sp, #0x38]
   13b9c:      	cmp	x2, x8
   13ba0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   13ba4:      	mov	w8, #0x4                // =4
   13ba8:      	add	x0, sp, #0x70
   13bac:      	mov	w1, #0x8                // =8
   13bb0:      	blr	x8
   13bb4:      	ldr	x8, [sp, #0x70]
   13bb8:      	cmp	x21, x8
   13bbc:      	b.eq	0x13cb0 <generic_fentry_path+0x9800>
   13bc0:      	add	x23, x21, #0x18
   13bc4:      	mov	w8, #0x4                // =4
   13bc8:      	add	x9, sp, #0x98
   13bcc:      	add	x0, sp, #0x98
   13bd0:      	mov	w1, #0x8                // =8
   13bd4:      	mov	x2, x23
   13bd8:      	blr	x8
   13bdc:      	ldr	x8, [sp, #0x98]
   13be0:      	cmp	x8, x21
   13be4:      	b.eq	0x13cb0 <generic_fentry_path+0x9800>
   13be8:      	mov	w8, #0x4                // =4
   13bec:      	add	x9, sp, #0x78
   13bf0:      	add	x0, sp, #0x78
   13bf4:      	mov	w1, #0x8                // =8
   13bf8:      	mov	x2, x23
   13bfc:      	blr	x8
   13c00:      	add	x2, x21, #0x20
   13c04:      	mov	w8, #0x4                // =4
   13c08:      	mov	w9, #0x10               // =16
   13c0c:      	add	x10, sp, #0x80
   13c10:      	add	x0, sp, #0x80
   13c14:      	mov	w1, #0x10               // =16
   13c18:      	blr	x8
   13c1c:      	ldr	w21, [sp, #0x84]
   13c20:      	ldr	x8, [sp, #0x40]
   13c24:      	ldr	x10, [sp, #0x60]
   13c28:      	sub	x12, x10, x8
   13c2c:      	ldr	w23, [sp, #0x68]
   13c30:      	subs	w10, w21, w23
   13c34:      	ldr	x9, [sp, #0x88]
   13c38:      	ldr	x25, [sp, #0x8]
   13c3c:      	csel	w10, wzr, w10, lo
   13c40:      	cmp	w23, w21
   13c44:      	csel	w11, w23, w21, lo
   13c48:      	cinc	w13, w11, hi
   13c4c:      	sub	w14, w23, w13
   13c50:      	subs	x12, x12, x13
   13c54:      	str	w14, [sp, #0x68]
   13c58:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   13c5c:      	cmp	x12, #0xfff
   13c60:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   13c64:      	cmp	w23, w21
   13c68:      	b.ls	0x13c74 <generic_fentry_path+0x97c4>
   13c6c:      	mov	w13, #0x2f              // =47
   13c70:      	strb	w13, [x8, x12]
   13c74:      	add	x19, x8, x12
   13c78:      	cmp	w23, w21
   13c7c:      	add	x2, x9, x10
   13c80:      	and	w1, w11, #0xff
   13c84:      	mov	w8, #0x4                // =4
   13c88:      	cinc	x0, x19, hi
   13c8c:      	blr	x8
   13c90:      	ldr	x25, [sp, #0x8]
   13c94:      	cmp	w23, w21
   13c98:      	str	x19, [sp, #0x60]
   13c9c:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   13ca0:      	ldr	x21, [sp, #0x78]
   13ca4:      	ldp	x2, x24, [sp, #0x50]
   13ca8:      	str	x21, [sp, #0x48]
   13cac:      	b	0x13d00 <generic_fentry_path+0x9850>
   13cb0:      	add	x2, x24, #0x10
   13cb4:      	mov	w8, #0x4                // =4
   13cb8:      	add	x9, sp, #0x98
   13cbc:      	add	x0, sp, #0x98
   13cc0:      	mov	w1, #0x8                // =8
   13cc4:      	blr	x8
   13cc8:      	ldr	x8, [sp, #0x58]
   13ccc:      	ldr	x9, [sp, #0x98]
   13cd0:      	cmp	x8, x9
   13cd4:      	ldr	x25, [sp, #0x8]
   13cd8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   13cdc:      	add	x2, x24, #0x18
   13ce0:      	mov	w8, #0x4                // =4
   13ce4:      	mov	x0, x22
   13ce8:      	mov	w1, #0x8                // =8
   13cec:      	blr	x8
   13cf0:      	ldr	x24, [sp, #0x98]
   13cf4:      	ldr	x21, [sp, #0x48]
   13cf8:      	add	x2, x24, #0x20
   13cfc:      	stp	x2, x24, [sp, #0x50]
   13d00:      	ldr	x8, [sp, #0x30]
   13d04:      	ldr	x25, [sp, #0x8]
   13d08:      	add	x9, sp, #0x70
   13d0c:      	cmp	x21, x8
   13d10:      	b.ne	0x13d20 <generic_fentry_path+0x9870>
   13d14:      	ldr	x8, [sp, #0x38]
   13d18:      	cmp	x2, x8
   13d1c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   13d20:      	mov	w8, #0x4                // =4
   13d24:      	add	x0, sp, #0x70
   13d28:      	mov	w1, #0x8                // =8
   13d2c:      	blr	x8
   13d30:      	ldr	x8, [sp, #0x70]
   13d34:      	cmp	x21, x8
   13d38:      	b.eq	0x13e2c <generic_fentry_path+0x997c>
   13d3c:      	add	x23, x21, #0x18
   13d40:      	mov	w8, #0x4                // =4
   13d44:      	add	x9, sp, #0x98
   13d48:      	add	x0, sp, #0x98
   13d4c:      	mov	w1, #0x8                // =8
   13d50:      	mov	x2, x23
   13d54:      	blr	x8
   13d58:      	ldr	x8, [sp, #0x98]
   13d5c:      	cmp	x8, x21
   13d60:      	b.eq	0x13e2c <generic_fentry_path+0x997c>
   13d64:      	mov	w8, #0x4                // =4
   13d68:      	add	x9, sp, #0x78
   13d6c:      	add	x0, sp, #0x78
   13d70:      	mov	w1, #0x8                // =8
   13d74:      	mov	x2, x23
   13d78:      	blr	x8
   13d7c:      	add	x2, x21, #0x20
   13d80:      	mov	w8, #0x4                // =4
   13d84:      	mov	w9, #0x10               // =16
   13d88:      	add	x10, sp, #0x80
   13d8c:      	add	x0, sp, #0x80
   13d90:      	mov	w1, #0x10               // =16
   13d94:      	blr	x8
   13d98:      	ldr	w21, [sp, #0x84]
   13d9c:      	ldr	x8, [sp, #0x40]
   13da0:      	ldr	x10, [sp, #0x60]
   13da4:      	sub	x12, x10, x8
   13da8:      	ldr	w23, [sp, #0x68]
   13dac:      	subs	w10, w21, w23
   13db0:      	ldr	x9, [sp, #0x88]
   13db4:      	ldr	x25, [sp, #0x8]
   13db8:      	csel	w10, wzr, w10, lo
   13dbc:      	cmp	w23, w21
   13dc0:      	csel	w11, w23, w21, lo
   13dc4:      	cinc	w13, w11, hi
   13dc8:      	sub	w14, w23, w13
   13dcc:      	subs	x12, x12, x13
   13dd0:      	str	w14, [sp, #0x68]
   13dd4:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   13dd8:      	cmp	x12, #0xfff
   13ddc:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   13de0:      	cmp	w23, w21
   13de4:      	b.ls	0x13df0 <generic_fentry_path+0x9940>
   13de8:      	mov	w13, #0x2f              // =47
   13dec:      	strb	w13, [x8, x12]
   13df0:      	add	x19, x8, x12
   13df4:      	cmp	w23, w21
   13df8:      	add	x2, x9, x10
   13dfc:      	and	w1, w11, #0xff
   13e00:      	mov	w8, #0x4                // =4
   13e04:      	cinc	x0, x19, hi
   13e08:      	blr	x8
   13e0c:      	ldr	x25, [sp, #0x8]
   13e10:      	cmp	w23, w21
   13e14:      	str	x19, [sp, #0x60]
   13e18:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   13e1c:      	ldr	x21, [sp, #0x78]
   13e20:      	ldp	x2, x24, [sp, #0x50]
   13e24:      	str	x21, [sp, #0x48]
   13e28:      	b	0x13e7c <generic_fentry_path+0x99cc>
   13e2c:      	add	x2, x24, #0x10
   13e30:      	mov	w8, #0x4                // =4
   13e34:      	add	x9, sp, #0x98
   13e38:      	add	x0, sp, #0x98
   13e3c:      	mov	w1, #0x8                // =8
   13e40:      	blr	x8
   13e44:      	ldr	x8, [sp, #0x58]
   13e48:      	ldr	x9, [sp, #0x98]
   13e4c:      	cmp	x8, x9
   13e50:      	ldr	x25, [sp, #0x8]
   13e54:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   13e58:      	add	x2, x24, #0x18
   13e5c:      	mov	w8, #0x4                // =4
   13e60:      	mov	x0, x22
   13e64:      	mov	w1, #0x8                // =8
   13e68:      	blr	x8
   13e6c:      	ldr	x24, [sp, #0x98]
   13e70:      	ldr	x21, [sp, #0x48]
   13e74:      	add	x2, x24, #0x20
   13e78:      	stp	x2, x24, [sp, #0x50]
   13e7c:      	ldr	x8, [sp, #0x30]
   13e80:      	ldr	x25, [sp, #0x8]
   13e84:      	add	x9, sp, #0x70
   13e88:      	cmp	x21, x8
   13e8c:      	b.ne	0x13e9c <generic_fentry_path+0x99ec>
   13e90:      	ldr	x8, [sp, #0x38]
   13e94:      	cmp	x2, x8
   13e98:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   13e9c:      	mov	w8, #0x4                // =4
   13ea0:      	add	x0, sp, #0x70
   13ea4:      	mov	w1, #0x8                // =8
   13ea8:      	blr	x8
   13eac:      	ldr	x8, [sp, #0x70]
   13eb0:      	cmp	x21, x8
   13eb4:      	b.eq	0x13fa8 <generic_fentry_path+0x9af8>
   13eb8:      	add	x23, x21, #0x18
   13ebc:      	mov	w8, #0x4                // =4
   13ec0:      	add	x9, sp, #0x98
   13ec4:      	add	x0, sp, #0x98
   13ec8:      	mov	w1, #0x8                // =8
   13ecc:      	mov	x2, x23
   13ed0:      	blr	x8
   13ed4:      	ldr	x8, [sp, #0x98]
   13ed8:      	cmp	x8, x21
   13edc:      	b.eq	0x13fa8 <generic_fentry_path+0x9af8>
   13ee0:      	mov	w8, #0x4                // =4
   13ee4:      	add	x9, sp, #0x78
   13ee8:      	add	x0, sp, #0x78
   13eec:      	mov	w1, #0x8                // =8
   13ef0:      	mov	x2, x23
   13ef4:      	blr	x8
   13ef8:      	add	x2, x21, #0x20
   13efc:      	mov	w8, #0x4                // =4
   13f00:      	mov	w9, #0x10               // =16
   13f04:      	add	x10, sp, #0x80
   13f08:      	add	x0, sp, #0x80
   13f0c:      	mov	w1, #0x10               // =16
   13f10:      	blr	x8
   13f14:      	ldr	w21, [sp, #0x84]
   13f18:      	ldr	x8, [sp, #0x40]
   13f1c:      	ldr	x10, [sp, #0x60]
   13f20:      	sub	x12, x10, x8
   13f24:      	ldr	w23, [sp, #0x68]
   13f28:      	subs	w10, w21, w23
   13f2c:      	ldr	x9, [sp, #0x88]
   13f30:      	ldr	x25, [sp, #0x8]
   13f34:      	csel	w10, wzr, w10, lo
   13f38:      	cmp	w23, w21
   13f3c:      	csel	w11, w23, w21, lo
   13f40:      	cinc	w13, w11, hi
   13f44:      	sub	w14, w23, w13
   13f48:      	subs	x12, x12, x13
   13f4c:      	str	w14, [sp, #0x68]
   13f50:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   13f54:      	cmp	x12, #0xfff
   13f58:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   13f5c:      	cmp	w23, w21
   13f60:      	b.ls	0x13f6c <generic_fentry_path+0x9abc>
   13f64:      	mov	w13, #0x2f              // =47
   13f68:      	strb	w13, [x8, x12]
   13f6c:      	add	x19, x8, x12
   13f70:      	cmp	w23, w21
   13f74:      	add	x2, x9, x10
   13f78:      	and	w1, w11, #0xff
   13f7c:      	mov	w8, #0x4                // =4
   13f80:      	cinc	x0, x19, hi
   13f84:      	blr	x8
   13f88:      	ldr	x25, [sp, #0x8]
   13f8c:      	cmp	w23, w21
   13f90:      	str	x19, [sp, #0x60]
   13f94:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   13f98:      	ldr	x21, [sp, #0x78]
   13f9c:      	ldp	x2, x24, [sp, #0x50]
   13fa0:      	str	x21, [sp, #0x48]
   13fa4:      	b	0x13ff8 <generic_fentry_path+0x9b48>
   13fa8:      	add	x2, x24, #0x10
   13fac:      	mov	w8, #0x4                // =4
   13fb0:      	add	x9, sp, #0x98
   13fb4:      	add	x0, sp, #0x98
   13fb8:      	mov	w1, #0x8                // =8
   13fbc:      	blr	x8
   13fc0:      	ldr	x8, [sp, #0x58]
   13fc4:      	ldr	x9, [sp, #0x98]
   13fc8:      	cmp	x8, x9
   13fcc:      	ldr	x25, [sp, #0x8]
   13fd0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   13fd4:      	add	x2, x24, #0x18
   13fd8:      	mov	w8, #0x4                // =4
   13fdc:      	mov	x0, x22
   13fe0:      	mov	w1, #0x8                // =8
   13fe4:      	blr	x8
   13fe8:      	ldr	x24, [sp, #0x98]
   13fec:      	ldr	x21, [sp, #0x48]
   13ff0:      	add	x2, x24, #0x20
   13ff4:      	stp	x2, x24, [sp, #0x50]
   13ff8:      	ldr	x8, [sp, #0x30]
   13ffc:      	ldr	x25, [sp, #0x8]
   14000:      	add	x9, sp, #0x70
   14004:      	cmp	x21, x8
   14008:      	b.ne	0x14018 <generic_fentry_path+0x9b68>
   1400c:      	ldr	x8, [sp, #0x38]
   14010:      	cmp	x2, x8
   14014:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   14018:      	mov	w8, #0x4                // =4
   1401c:      	add	x0, sp, #0x70
   14020:      	mov	w1, #0x8                // =8
   14024:      	blr	x8
   14028:      	ldr	x8, [sp, #0x70]
   1402c:      	cmp	x21, x8
   14030:      	b.eq	0x14124 <generic_fentry_path+0x9c74>
   14034:      	add	x23, x21, #0x18
   14038:      	mov	w8, #0x4                // =4
   1403c:      	add	x9, sp, #0x98
   14040:      	add	x0, sp, #0x98
   14044:      	mov	w1, #0x8                // =8
   14048:      	mov	x2, x23
   1404c:      	blr	x8
   14050:      	ldr	x8, [sp, #0x98]
   14054:      	cmp	x8, x21
   14058:      	b.eq	0x14124 <generic_fentry_path+0x9c74>
   1405c:      	mov	w8, #0x4                // =4
   14060:      	add	x9, sp, #0x78
   14064:      	add	x0, sp, #0x78
   14068:      	mov	w1, #0x8                // =8
   1406c:      	mov	x2, x23
   14070:      	blr	x8
   14074:      	add	x2, x21, #0x20
   14078:      	mov	w8, #0x4                // =4
   1407c:      	mov	w9, #0x10               // =16
   14080:      	add	x10, sp, #0x80
   14084:      	add	x0, sp, #0x80
   14088:      	mov	w1, #0x10               // =16
   1408c:      	blr	x8
   14090:      	ldr	w21, [sp, #0x84]
   14094:      	ldr	x8, [sp, #0x40]
   14098:      	ldr	x10, [sp, #0x60]
   1409c:      	sub	x12, x10, x8
   140a0:      	ldr	w23, [sp, #0x68]
   140a4:      	subs	w10, w21, w23
   140a8:      	ldr	x9, [sp, #0x88]
   140ac:      	ldr	x25, [sp, #0x8]
   140b0:      	csel	w10, wzr, w10, lo
   140b4:      	cmp	w23, w21
   140b8:      	csel	w11, w23, w21, lo
   140bc:      	cinc	w13, w11, hi
   140c0:      	sub	w14, w23, w13
   140c4:      	subs	x12, x12, x13
   140c8:      	str	w14, [sp, #0x68]
   140cc:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   140d0:      	cmp	x12, #0xfff
   140d4:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   140d8:      	cmp	w23, w21
   140dc:      	b.ls	0x140e8 <generic_fentry_path+0x9c38>
   140e0:      	mov	w13, #0x2f              // =47
   140e4:      	strb	w13, [x8, x12]
   140e8:      	add	x19, x8, x12
   140ec:      	cmp	w23, w21
   140f0:      	add	x2, x9, x10
   140f4:      	and	w1, w11, #0xff
   140f8:      	mov	w8, #0x4                // =4
   140fc:      	cinc	x0, x19, hi
   14100:      	blr	x8
   14104:      	ldr	x25, [sp, #0x8]
   14108:      	cmp	w23, w21
   1410c:      	str	x19, [sp, #0x60]
   14110:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   14114:      	ldr	x21, [sp, #0x78]
   14118:      	ldp	x2, x24, [sp, #0x50]
   1411c:      	str	x21, [sp, #0x48]
   14120:      	b	0x14174 <generic_fentry_path+0x9cc4>
   14124:      	add	x2, x24, #0x10
   14128:      	mov	w8, #0x4                // =4
   1412c:      	add	x9, sp, #0x98
   14130:      	add	x0, sp, #0x98
   14134:      	mov	w1, #0x8                // =8
   14138:      	blr	x8
   1413c:      	ldr	x8, [sp, #0x58]
   14140:      	ldr	x9, [sp, #0x98]
   14144:      	cmp	x8, x9
   14148:      	ldr	x25, [sp, #0x8]
   1414c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   14150:      	add	x2, x24, #0x18
   14154:      	mov	w8, #0x4                // =4
   14158:      	mov	x0, x22
   1415c:      	mov	w1, #0x8                // =8
   14160:      	blr	x8
   14164:      	ldr	x24, [sp, #0x98]
   14168:      	ldr	x21, [sp, #0x48]
   1416c:      	add	x2, x24, #0x20
   14170:      	stp	x2, x24, [sp, #0x50]
   14174:      	ldr	x8, [sp, #0x30]
   14178:      	ldr	x25, [sp, #0x8]
   1417c:      	add	x9, sp, #0x70
   14180:      	cmp	x21, x8
   14184:      	b.ne	0x14194 <generic_fentry_path+0x9ce4>
   14188:      	ldr	x8, [sp, #0x38]
   1418c:      	cmp	x2, x8
   14190:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   14194:      	mov	w8, #0x4                // =4
   14198:      	add	x0, sp, #0x70
   1419c:      	mov	w1, #0x8                // =8
   141a0:      	blr	x8
   141a4:      	ldr	x8, [sp, #0x70]
   141a8:      	cmp	x21, x8
   141ac:      	b.eq	0x142a0 <generic_fentry_path+0x9df0>
   141b0:      	add	x23, x21, #0x18
   141b4:      	mov	w8, #0x4                // =4
   141b8:      	add	x9, sp, #0x98
   141bc:      	add	x0, sp, #0x98
   141c0:      	mov	w1, #0x8                // =8
   141c4:      	mov	x2, x23
   141c8:      	blr	x8
   141cc:      	ldr	x8, [sp, #0x98]
   141d0:      	cmp	x8, x21
   141d4:      	b.eq	0x142a0 <generic_fentry_path+0x9df0>
   141d8:      	mov	w8, #0x4                // =4
   141dc:      	add	x9, sp, #0x78
   141e0:      	add	x0, sp, #0x78
   141e4:      	mov	w1, #0x8                // =8
   141e8:      	mov	x2, x23
   141ec:      	blr	x8
   141f0:      	add	x2, x21, #0x20
   141f4:      	mov	w8, #0x4                // =4
   141f8:      	mov	w9, #0x10               // =16
   141fc:      	add	x10, sp, #0x80
   14200:      	add	x0, sp, #0x80
   14204:      	mov	w1, #0x10               // =16
   14208:      	blr	x8
   1420c:      	ldr	w21, [sp, #0x84]
   14210:      	ldr	x8, [sp, #0x40]
   14214:      	ldr	x10, [sp, #0x60]
   14218:      	sub	x12, x10, x8
   1421c:      	ldr	w23, [sp, #0x68]
   14220:      	subs	w10, w21, w23
   14224:      	ldr	x9, [sp, #0x88]
   14228:      	ldr	x25, [sp, #0x8]
   1422c:      	csel	w10, wzr, w10, lo
   14230:      	cmp	w23, w21
   14234:      	csel	w11, w23, w21, lo
   14238:      	cinc	w13, w11, hi
   1423c:      	sub	w14, w23, w13
   14240:      	subs	x12, x12, x13
   14244:      	str	w14, [sp, #0x68]
   14248:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   1424c:      	cmp	x12, #0xfff
   14250:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   14254:      	cmp	w23, w21
   14258:      	b.ls	0x14264 <generic_fentry_path+0x9db4>
   1425c:      	mov	w13, #0x2f              // =47
   14260:      	strb	w13, [x8, x12]
   14264:      	add	x19, x8, x12
   14268:      	cmp	w23, w21
   1426c:      	add	x2, x9, x10
   14270:      	and	w1, w11, #0xff
   14274:      	mov	w8, #0x4                // =4
   14278:      	cinc	x0, x19, hi
   1427c:      	blr	x8
   14280:      	ldr	x25, [sp, #0x8]
   14284:      	cmp	w23, w21
   14288:      	str	x19, [sp, #0x60]
   1428c:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   14290:      	ldr	x21, [sp, #0x78]
   14294:      	ldp	x2, x24, [sp, #0x50]
   14298:      	str	x21, [sp, #0x48]
   1429c:      	b	0x142f0 <generic_fentry_path+0x9e40>
   142a0:      	add	x2, x24, #0x10
   142a4:      	mov	w8, #0x4                // =4
   142a8:      	add	x9, sp, #0x98
   142ac:      	add	x0, sp, #0x98
   142b0:      	mov	w1, #0x8                // =8
   142b4:      	blr	x8
   142b8:      	ldr	x8, [sp, #0x58]
   142bc:      	ldr	x9, [sp, #0x98]
   142c0:      	cmp	x8, x9
   142c4:      	ldr	x25, [sp, #0x8]
   142c8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   142cc:      	add	x2, x24, #0x18
   142d0:      	mov	w8, #0x4                // =4
   142d4:      	mov	x0, x22
   142d8:      	mov	w1, #0x8                // =8
   142dc:      	blr	x8
   142e0:      	ldr	x24, [sp, #0x98]
   142e4:      	ldr	x21, [sp, #0x48]
   142e8:      	add	x2, x24, #0x20
   142ec:      	stp	x2, x24, [sp, #0x50]
   142f0:      	ldr	x8, [sp, #0x30]
   142f4:      	ldr	x25, [sp, #0x8]
   142f8:      	add	x9, sp, #0x70
   142fc:      	cmp	x21, x8
   14300:      	b.ne	0x14310 <generic_fentry_path+0x9e60>
   14304:      	ldr	x8, [sp, #0x38]
   14308:      	cmp	x2, x8
   1430c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   14310:      	mov	w8, #0x4                // =4
   14314:      	add	x0, sp, #0x70
   14318:      	mov	w1, #0x8                // =8
   1431c:      	blr	x8
   14320:      	ldr	x8, [sp, #0x70]
   14324:      	cmp	x21, x8
   14328:      	b.eq	0x1441c <generic_fentry_path+0x9f6c>
   1432c:      	add	x23, x21, #0x18
   14330:      	mov	w8, #0x4                // =4
   14334:      	add	x9, sp, #0x98
   14338:      	add	x0, sp, #0x98
   1433c:      	mov	w1, #0x8                // =8
   14340:      	mov	x2, x23
   14344:      	blr	x8
   14348:      	ldr	x8, [sp, #0x98]
   1434c:      	cmp	x8, x21
   14350:      	b.eq	0x1441c <generic_fentry_path+0x9f6c>
   14354:      	mov	w8, #0x4                // =4
   14358:      	add	x9, sp, #0x78
   1435c:      	add	x0, sp, #0x78
   14360:      	mov	w1, #0x8                // =8
   14364:      	mov	x2, x23
   14368:      	blr	x8
   1436c:      	add	x2, x21, #0x20
   14370:      	mov	w8, #0x4                // =4
   14374:      	mov	w9, #0x10               // =16
   14378:      	add	x10, sp, #0x80
   1437c:      	add	x0, sp, #0x80
   14380:      	mov	w1, #0x10               // =16
   14384:      	blr	x8
   14388:      	ldr	w21, [sp, #0x84]
   1438c:      	ldr	x8, [sp, #0x40]
   14390:      	ldr	x10, [sp, #0x60]
   14394:      	sub	x12, x10, x8
   14398:      	ldr	w23, [sp, #0x68]
   1439c:      	subs	w10, w21, w23
   143a0:      	ldr	x9, [sp, #0x88]
   143a4:      	ldr	x25, [sp, #0x8]
   143a8:      	csel	w10, wzr, w10, lo
   143ac:      	cmp	w23, w21
   143b0:      	csel	w11, w23, w21, lo
   143b4:      	cinc	w13, w11, hi
   143b8:      	sub	w14, w23, w13
   143bc:      	subs	x12, x12, x13
   143c0:      	str	w14, [sp, #0x68]
   143c4:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   143c8:      	cmp	x12, #0xfff
   143cc:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   143d0:      	cmp	w23, w21
   143d4:      	b.ls	0x143e0 <generic_fentry_path+0x9f30>
   143d8:      	mov	w13, #0x2f              // =47
   143dc:      	strb	w13, [x8, x12]
   143e0:      	add	x19, x8, x12
   143e4:      	cmp	w23, w21
   143e8:      	add	x2, x9, x10
   143ec:      	and	w1, w11, #0xff
   143f0:      	mov	w8, #0x4                // =4
   143f4:      	cinc	x0, x19, hi
   143f8:      	blr	x8
   143fc:      	ldr	x25, [sp, #0x8]
   14400:      	cmp	w23, w21
   14404:      	str	x19, [sp, #0x60]
   14408:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   1440c:      	ldr	x21, [sp, #0x78]
   14410:      	ldp	x2, x24, [sp, #0x50]
   14414:      	str	x21, [sp, #0x48]
   14418:      	b	0x1446c <generic_fentry_path+0x9fbc>
   1441c:      	add	x2, x24, #0x10
   14420:      	mov	w8, #0x4                // =4
   14424:      	add	x9, sp, #0x98
   14428:      	add	x0, sp, #0x98
   1442c:      	mov	w1, #0x8                // =8
   14430:      	blr	x8
   14434:      	ldr	x8, [sp, #0x58]
   14438:      	ldr	x9, [sp, #0x98]
   1443c:      	cmp	x8, x9
   14440:      	ldr	x25, [sp, #0x8]
   14444:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   14448:      	add	x2, x24, #0x18
   1444c:      	mov	w8, #0x4                // =4
   14450:      	mov	x0, x22
   14454:      	mov	w1, #0x8                // =8
   14458:      	blr	x8
   1445c:      	ldr	x24, [sp, #0x98]
   14460:      	ldr	x21, [sp, #0x48]
   14464:      	add	x2, x24, #0x20
   14468:      	stp	x2, x24, [sp, #0x50]
   1446c:      	ldr	x8, [sp, #0x30]
   14470:      	ldr	x25, [sp, #0x8]
   14474:      	add	x9, sp, #0x70
   14478:      	cmp	x21, x8
   1447c:      	b.ne	0x1448c <generic_fentry_path+0x9fdc>
   14480:      	ldr	x8, [sp, #0x38]
   14484:      	cmp	x2, x8
   14488:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   1448c:      	mov	w8, #0x4                // =4
   14490:      	add	x0, sp, #0x70
   14494:      	mov	w1, #0x8                // =8
   14498:      	blr	x8
   1449c:      	ldr	x8, [sp, #0x70]
   144a0:      	cmp	x21, x8
   144a4:      	b.eq	0x14598 <generic_fentry_path+0xa0e8>
   144a8:      	add	x23, x21, #0x18
   144ac:      	mov	w8, #0x4                // =4
   144b0:      	add	x9, sp, #0x98
   144b4:      	add	x0, sp, #0x98
   144b8:      	mov	w1, #0x8                // =8
   144bc:      	mov	x2, x23
   144c0:      	blr	x8
   144c4:      	ldr	x8, [sp, #0x98]
   144c8:      	cmp	x8, x21
   144cc:      	b.eq	0x14598 <generic_fentry_path+0xa0e8>
   144d0:      	mov	w8, #0x4                // =4
   144d4:      	add	x9, sp, #0x78
   144d8:      	add	x0, sp, #0x78
   144dc:      	mov	w1, #0x8                // =8
   144e0:      	mov	x2, x23
   144e4:      	blr	x8
   144e8:      	add	x2, x21, #0x20
   144ec:      	mov	w8, #0x4                // =4
   144f0:      	mov	w9, #0x10               // =16
   144f4:      	add	x10, sp, #0x80
   144f8:      	add	x0, sp, #0x80
   144fc:      	mov	w1, #0x10               // =16
   14500:      	blr	x8
   14504:      	ldr	w21, [sp, #0x84]
   14508:      	ldr	x8, [sp, #0x40]
   1450c:      	ldr	x10, [sp, #0x60]
   14510:      	sub	x12, x10, x8
   14514:      	ldr	w23, [sp, #0x68]
   14518:      	subs	w10, w21, w23
   1451c:      	ldr	x9, [sp, #0x88]
   14520:      	ldr	x25, [sp, #0x8]
   14524:      	csel	w10, wzr, w10, lo
   14528:      	cmp	w23, w21
   1452c:      	csel	w11, w23, w21, lo
   14530:      	cinc	w13, w11, hi
   14534:      	sub	w14, w23, w13
   14538:      	subs	x12, x12, x13
   1453c:      	str	w14, [sp, #0x68]
   14540:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   14544:      	cmp	x12, #0xfff
   14548:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   1454c:      	cmp	w23, w21
   14550:      	b.ls	0x1455c <generic_fentry_path+0xa0ac>
   14554:      	mov	w13, #0x2f              // =47
   14558:      	strb	w13, [x8, x12]
   1455c:      	add	x19, x8, x12
   14560:      	cmp	w23, w21
   14564:      	add	x2, x9, x10
   14568:      	and	w1, w11, #0xff
   1456c:      	mov	w8, #0x4                // =4
   14570:      	cinc	x0, x19, hi
   14574:      	blr	x8
   14578:      	ldr	x25, [sp, #0x8]
   1457c:      	cmp	w23, w21
   14580:      	str	x19, [sp, #0x60]
   14584:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   14588:      	ldr	x21, [sp, #0x78]
   1458c:      	ldp	x2, x24, [sp, #0x50]
   14590:      	str	x21, [sp, #0x48]
   14594:      	b	0x145e8 <generic_fentry_path+0xa138>
   14598:      	add	x2, x24, #0x10
   1459c:      	mov	w8, #0x4                // =4
   145a0:      	add	x9, sp, #0x98
   145a4:      	add	x0, sp, #0x98
   145a8:      	mov	w1, #0x8                // =8
   145ac:      	blr	x8
   145b0:      	ldr	x8, [sp, #0x58]
   145b4:      	ldr	x9, [sp, #0x98]
   145b8:      	cmp	x8, x9
   145bc:      	ldr	x25, [sp, #0x8]
   145c0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   145c4:      	add	x2, x24, #0x18
   145c8:      	mov	w8, #0x4                // =4
   145cc:      	mov	x0, x22
   145d0:      	mov	w1, #0x8                // =8
   145d4:      	blr	x8
   145d8:      	ldr	x24, [sp, #0x98]
   145dc:      	ldr	x21, [sp, #0x48]
   145e0:      	add	x2, x24, #0x20
   145e4:      	stp	x2, x24, [sp, #0x50]
   145e8:      	ldr	x8, [sp, #0x30]
   145ec:      	ldr	x25, [sp, #0x8]
   145f0:      	add	x9, sp, #0x70
   145f4:      	cmp	x21, x8
   145f8:      	b.ne	0x14608 <generic_fentry_path+0xa158>
   145fc:      	ldr	x8, [sp, #0x38]
   14600:      	cmp	x2, x8
   14604:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   14608:      	mov	w8, #0x4                // =4
   1460c:      	add	x0, sp, #0x70
   14610:      	mov	w1, #0x8                // =8
   14614:      	blr	x8
   14618:      	ldr	x8, [sp, #0x70]
   1461c:      	cmp	x21, x8
   14620:      	b.eq	0x14714 <generic_fentry_path+0xa264>
   14624:      	add	x23, x21, #0x18
   14628:      	mov	w8, #0x4                // =4
   1462c:      	add	x9, sp, #0x98
   14630:      	add	x0, sp, #0x98
   14634:      	mov	w1, #0x8                // =8
   14638:      	mov	x2, x23
   1463c:      	blr	x8
   14640:      	ldr	x8, [sp, #0x98]
   14644:      	cmp	x8, x21
   14648:      	b.eq	0x14714 <generic_fentry_path+0xa264>
   1464c:      	mov	w8, #0x4                // =4
   14650:      	add	x9, sp, #0x78
   14654:      	add	x0, sp, #0x78
   14658:      	mov	w1, #0x8                // =8
   1465c:      	mov	x2, x23
   14660:      	blr	x8
   14664:      	add	x2, x21, #0x20
   14668:      	mov	w8, #0x4                // =4
   1466c:      	mov	w9, #0x10               // =16
   14670:      	add	x10, sp, #0x80
   14674:      	add	x0, sp, #0x80
   14678:      	mov	w1, #0x10               // =16
   1467c:      	blr	x8
   14680:      	ldr	w21, [sp, #0x84]
   14684:      	ldr	x8, [sp, #0x40]
   14688:      	ldr	x10, [sp, #0x60]
   1468c:      	sub	x12, x10, x8
   14690:      	ldr	w23, [sp, #0x68]
   14694:      	subs	w10, w21, w23
   14698:      	ldr	x9, [sp, #0x88]
   1469c:      	ldr	x25, [sp, #0x8]
   146a0:      	csel	w10, wzr, w10, lo
   146a4:      	cmp	w23, w21
   146a8:      	csel	w11, w23, w21, lo
   146ac:      	cinc	w13, w11, hi
   146b0:      	sub	w14, w23, w13
   146b4:      	subs	x12, x12, x13
   146b8:      	str	w14, [sp, #0x68]
   146bc:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   146c0:      	cmp	x12, #0xfff
   146c4:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   146c8:      	cmp	w23, w21
   146cc:      	b.ls	0x146d8 <generic_fentry_path+0xa228>
   146d0:      	mov	w13, #0x2f              // =47
   146d4:      	strb	w13, [x8, x12]
   146d8:      	add	x19, x8, x12
   146dc:      	cmp	w23, w21
   146e0:      	add	x2, x9, x10
   146e4:      	and	w1, w11, #0xff
   146e8:      	mov	w8, #0x4                // =4
   146ec:      	cinc	x0, x19, hi
   146f0:      	blr	x8
   146f4:      	ldr	x25, [sp, #0x8]
   146f8:      	cmp	w23, w21
   146fc:      	str	x19, [sp, #0x60]
   14700:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   14704:      	ldr	x21, [sp, #0x78]
   14708:      	ldp	x2, x24, [sp, #0x50]
   1470c:      	str	x21, [sp, #0x48]
   14710:      	b	0x14764 <generic_fentry_path+0xa2b4>
   14714:      	add	x2, x24, #0x10
   14718:      	mov	w8, #0x4                // =4
   1471c:      	add	x9, sp, #0x98
   14720:      	add	x0, sp, #0x98
   14724:      	mov	w1, #0x8                // =8
   14728:      	blr	x8
   1472c:      	ldr	x8, [sp, #0x58]
   14730:      	ldr	x9, [sp, #0x98]
   14734:      	cmp	x8, x9
   14738:      	ldr	x25, [sp, #0x8]
   1473c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   14740:      	add	x2, x24, #0x18
   14744:      	mov	w8, #0x4                // =4
   14748:      	mov	x0, x22
   1474c:      	mov	w1, #0x8                // =8
   14750:      	blr	x8
   14754:      	ldr	x24, [sp, #0x98]
   14758:      	ldr	x21, [sp, #0x48]
   1475c:      	add	x2, x24, #0x20
   14760:      	stp	x2, x24, [sp, #0x50]
   14764:      	ldr	x8, [sp, #0x30]
   14768:      	ldr	x25, [sp, #0x8]
   1476c:      	add	x9, sp, #0x70
   14770:      	cmp	x21, x8
   14774:      	b.ne	0x14784 <generic_fentry_path+0xa2d4>
   14778:      	ldr	x8, [sp, #0x38]
   1477c:      	cmp	x2, x8
   14780:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   14784:      	mov	w8, #0x4                // =4
   14788:      	add	x0, sp, #0x70
   1478c:      	mov	w1, #0x8                // =8
   14790:      	blr	x8
   14794:      	ldr	x8, [sp, #0x70]
   14798:      	cmp	x21, x8
   1479c:      	b.eq	0x14890 <generic_fentry_path+0xa3e0>
   147a0:      	add	x23, x21, #0x18
   147a4:      	mov	w8, #0x4                // =4
   147a8:      	add	x9, sp, #0x98
   147ac:      	add	x0, sp, #0x98
   147b0:      	mov	w1, #0x8                // =8
   147b4:      	mov	x2, x23
   147b8:      	blr	x8
   147bc:      	ldr	x8, [sp, #0x98]
   147c0:      	cmp	x8, x21
   147c4:      	b.eq	0x14890 <generic_fentry_path+0xa3e0>
   147c8:      	mov	w8, #0x4                // =4
   147cc:      	add	x9, sp, #0x78
   147d0:      	add	x0, sp, #0x78
   147d4:      	mov	w1, #0x8                // =8
   147d8:      	mov	x2, x23
   147dc:      	blr	x8
   147e0:      	add	x2, x21, #0x20
   147e4:      	mov	w8, #0x4                // =4
   147e8:      	mov	w9, #0x10               // =16
   147ec:      	add	x10, sp, #0x80
   147f0:      	add	x0, sp, #0x80
   147f4:      	mov	w1, #0x10               // =16
   147f8:      	blr	x8
   147fc:      	ldr	w21, [sp, #0x84]
   14800:      	ldr	x8, [sp, #0x40]
   14804:      	ldr	x10, [sp, #0x60]
   14808:      	sub	x12, x10, x8
   1480c:      	ldr	w23, [sp, #0x68]
   14810:      	subs	w10, w21, w23
   14814:      	ldr	x9, [sp, #0x88]
   14818:      	ldr	x25, [sp, #0x8]
   1481c:      	csel	w10, wzr, w10, lo
   14820:      	cmp	w23, w21
   14824:      	csel	w11, w23, w21, lo
   14828:      	cinc	w13, w11, hi
   1482c:      	sub	w14, w23, w13
   14830:      	subs	x12, x12, x13
   14834:      	str	w14, [sp, #0x68]
   14838:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   1483c:      	cmp	x12, #0xfff
   14840:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   14844:      	cmp	w23, w21
   14848:      	b.ls	0x14854 <generic_fentry_path+0xa3a4>
   1484c:      	mov	w13, #0x2f              // =47
   14850:      	strb	w13, [x8, x12]
   14854:      	add	x19, x8, x12
   14858:      	cmp	w23, w21
   1485c:      	add	x2, x9, x10
   14860:      	and	w1, w11, #0xff
   14864:      	mov	w8, #0x4                // =4
   14868:      	cinc	x0, x19, hi
   1486c:      	blr	x8
   14870:      	ldr	x25, [sp, #0x8]
   14874:      	cmp	w23, w21
   14878:      	str	x19, [sp, #0x60]
   1487c:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   14880:      	ldr	x21, [sp, #0x78]
   14884:      	ldp	x2, x24, [sp, #0x50]
   14888:      	str	x21, [sp, #0x48]
   1488c:      	b	0x148e0 <generic_fentry_path+0xa430>
   14890:      	add	x2, x24, #0x10
   14894:      	mov	w8, #0x4                // =4
   14898:      	add	x9, sp, #0x98
   1489c:      	add	x0, sp, #0x98
   148a0:      	mov	w1, #0x8                // =8
   148a4:      	blr	x8
   148a8:      	ldr	x8, [sp, #0x58]
   148ac:      	ldr	x9, [sp, #0x98]
   148b0:      	cmp	x8, x9
   148b4:      	ldr	x25, [sp, #0x8]
   148b8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   148bc:      	add	x2, x24, #0x18
   148c0:      	mov	w8, #0x4                // =4
   148c4:      	mov	x0, x22
   148c8:      	mov	w1, #0x8                // =8
   148cc:      	blr	x8
   148d0:      	ldr	x24, [sp, #0x98]
   148d4:      	ldr	x21, [sp, #0x48]
   148d8:      	add	x2, x24, #0x20
   148dc:      	stp	x2, x24, [sp, #0x50]
   148e0:      	ldr	x8, [sp, #0x30]
   148e4:      	ldr	x25, [sp, #0x8]
   148e8:      	add	x9, sp, #0x70
   148ec:      	cmp	x21, x8
   148f0:      	b.ne	0x14900 <generic_fentry_path+0xa450>
   148f4:      	ldr	x8, [sp, #0x38]
   148f8:      	cmp	x2, x8
   148fc:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   14900:      	mov	w8, #0x4                // =4
   14904:      	add	x0, sp, #0x70
   14908:      	mov	w1, #0x8                // =8
   1490c:      	blr	x8
   14910:      	ldr	x8, [sp, #0x70]
   14914:      	cmp	x21, x8
   14918:      	b.eq	0x14a0c <generic_fentry_path+0xa55c>
   1491c:      	add	x23, x21, #0x18
   14920:      	mov	w8, #0x4                // =4
   14924:      	add	x9, sp, #0x98
   14928:      	add	x0, sp, #0x98
   1492c:      	mov	w1, #0x8                // =8
   14930:      	mov	x2, x23
   14934:      	blr	x8
   14938:      	ldr	x8, [sp, #0x98]
   1493c:      	cmp	x8, x21
   14940:      	b.eq	0x14a0c <generic_fentry_path+0xa55c>
   14944:      	mov	w8, #0x4                // =4
   14948:      	add	x9, sp, #0x78
   1494c:      	add	x0, sp, #0x78
   14950:      	mov	w1, #0x8                // =8
   14954:      	mov	x2, x23
   14958:      	blr	x8
   1495c:      	add	x2, x21, #0x20
   14960:      	mov	w8, #0x4                // =4
   14964:      	mov	w9, #0x10               // =16
   14968:      	add	x10, sp, #0x80
   1496c:      	add	x0, sp, #0x80
   14970:      	mov	w1, #0x10               // =16
   14974:      	blr	x8
   14978:      	ldr	w21, [sp, #0x84]
   1497c:      	ldr	x8, [sp, #0x40]
   14980:      	ldr	x10, [sp, #0x60]
   14984:      	sub	x12, x10, x8
   14988:      	ldr	w23, [sp, #0x68]
   1498c:      	subs	w10, w21, w23
   14990:      	ldr	x9, [sp, #0x88]
   14994:      	ldr	x25, [sp, #0x8]
   14998:      	csel	w10, wzr, w10, lo
   1499c:      	cmp	w23, w21
   149a0:      	csel	w11, w23, w21, lo
   149a4:      	cinc	w13, w11, hi
   149a8:      	sub	w14, w23, w13
   149ac:      	subs	x12, x12, x13
   149b0:      	str	w14, [sp, #0x68]
   149b4:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   149b8:      	cmp	x12, #0xfff
   149bc:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   149c0:      	cmp	w23, w21
   149c4:      	b.ls	0x149d0 <generic_fentry_path+0xa520>
   149c8:      	mov	w13, #0x2f              // =47
   149cc:      	strb	w13, [x8, x12]
   149d0:      	add	x19, x8, x12
   149d4:      	cmp	w23, w21
   149d8:      	add	x2, x9, x10
   149dc:      	and	w1, w11, #0xff
   149e0:      	mov	w8, #0x4                // =4
   149e4:      	cinc	x0, x19, hi
   149e8:      	blr	x8
   149ec:      	ldr	x25, [sp, #0x8]
   149f0:      	cmp	w23, w21
   149f4:      	str	x19, [sp, #0x60]
   149f8:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   149fc:      	ldr	x21, [sp, #0x78]
   14a00:      	ldp	x2, x24, [sp, #0x50]
   14a04:      	str	x21, [sp, #0x48]
   14a08:      	b	0x14a5c <generic_fentry_path+0xa5ac>
   14a0c:      	add	x2, x24, #0x10
   14a10:      	mov	w8, #0x4                // =4
   14a14:      	add	x9, sp, #0x98
   14a18:      	add	x0, sp, #0x98
   14a1c:      	mov	w1, #0x8                // =8
   14a20:      	blr	x8
   14a24:      	ldr	x8, [sp, #0x58]
   14a28:      	ldr	x9, [sp, #0x98]
   14a2c:      	cmp	x8, x9
   14a30:      	ldr	x25, [sp, #0x8]
   14a34:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   14a38:      	add	x2, x24, #0x18
   14a3c:      	mov	w8, #0x4                // =4
   14a40:      	mov	x0, x22
   14a44:      	mov	w1, #0x8                // =8
   14a48:      	blr	x8
   14a4c:      	ldr	x24, [sp, #0x98]
   14a50:      	ldr	x21, [sp, #0x48]
   14a54:      	add	x2, x24, #0x20
   14a58:      	stp	x2, x24, [sp, #0x50]
   14a5c:      	ldr	x8, [sp, #0x30]
   14a60:      	ldr	x25, [sp, #0x8]
   14a64:      	add	x9, sp, #0x70
   14a68:      	cmp	x21, x8
   14a6c:      	b.ne	0x14a7c <generic_fentry_path+0xa5cc>
   14a70:      	ldr	x8, [sp, #0x38]
   14a74:      	cmp	x2, x8
   14a78:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   14a7c:      	mov	w8, #0x4                // =4
   14a80:      	add	x0, sp, #0x70
   14a84:      	mov	w1, #0x8                // =8
   14a88:      	blr	x8
   14a8c:      	ldr	x8, [sp, #0x70]
   14a90:      	cmp	x21, x8
   14a94:      	b.eq	0x14b88 <generic_fentry_path+0xa6d8>
   14a98:      	add	x23, x21, #0x18
   14a9c:      	mov	w8, #0x4                // =4
   14aa0:      	add	x9, sp, #0x98
   14aa4:      	add	x0, sp, #0x98
   14aa8:      	mov	w1, #0x8                // =8
   14aac:      	mov	x2, x23
   14ab0:      	blr	x8
   14ab4:      	ldr	x8, [sp, #0x98]
   14ab8:      	cmp	x8, x21
   14abc:      	b.eq	0x14b88 <generic_fentry_path+0xa6d8>
   14ac0:      	mov	w8, #0x4                // =4
   14ac4:      	add	x9, sp, #0x78
   14ac8:      	add	x0, sp, #0x78
   14acc:      	mov	w1, #0x8                // =8
   14ad0:      	mov	x2, x23
   14ad4:      	blr	x8
   14ad8:      	add	x2, x21, #0x20
   14adc:      	mov	w8, #0x4                // =4
   14ae0:      	mov	w9, #0x10               // =16
   14ae4:      	add	x10, sp, #0x80
   14ae8:      	add	x0, sp, #0x80
   14aec:      	mov	w1, #0x10               // =16
   14af0:      	blr	x8
   14af4:      	ldr	w21, [sp, #0x84]
   14af8:      	ldr	x8, [sp, #0x40]
   14afc:      	ldr	x10, [sp, #0x60]
   14b00:      	sub	x12, x10, x8
   14b04:      	ldr	w23, [sp, #0x68]
   14b08:      	subs	w10, w21, w23
   14b0c:      	ldr	x9, [sp, #0x88]
   14b10:      	ldr	x25, [sp, #0x8]
   14b14:      	csel	w10, wzr, w10, lo
   14b18:      	cmp	w23, w21
   14b1c:      	csel	w11, w23, w21, lo
   14b20:      	cinc	w13, w11, hi
   14b24:      	sub	w14, w23, w13
   14b28:      	subs	x12, x12, x13
   14b2c:      	str	w14, [sp, #0x68]
   14b30:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   14b34:      	cmp	x12, #0xfff
   14b38:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   14b3c:      	cmp	w23, w21
   14b40:      	b.ls	0x14b4c <generic_fentry_path+0xa69c>
   14b44:      	mov	w13, #0x2f              // =47
   14b48:      	strb	w13, [x8, x12]
   14b4c:      	add	x19, x8, x12
   14b50:      	cmp	w23, w21
   14b54:      	add	x2, x9, x10
   14b58:      	and	w1, w11, #0xff
   14b5c:      	mov	w8, #0x4                // =4
   14b60:      	cinc	x0, x19, hi
   14b64:      	blr	x8
   14b68:      	ldr	x25, [sp, #0x8]
   14b6c:      	cmp	w23, w21
   14b70:      	str	x19, [sp, #0x60]
   14b74:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   14b78:      	ldr	x21, [sp, #0x78]
   14b7c:      	ldp	x2, x24, [sp, #0x50]
   14b80:      	str	x21, [sp, #0x48]
   14b84:      	b	0x14bd8 <generic_fentry_path+0xa728>
   14b88:      	add	x2, x24, #0x10
   14b8c:      	mov	w8, #0x4                // =4
   14b90:      	add	x9, sp, #0x98
   14b94:      	add	x0, sp, #0x98
   14b98:      	mov	w1, #0x8                // =8
   14b9c:      	blr	x8
   14ba0:      	ldr	x8, [sp, #0x58]
   14ba4:      	ldr	x9, [sp, #0x98]
   14ba8:      	cmp	x8, x9
   14bac:      	ldr	x25, [sp, #0x8]
   14bb0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   14bb4:      	add	x2, x24, #0x18
   14bb8:      	mov	w8, #0x4                // =4
   14bbc:      	mov	x0, x22
   14bc0:      	mov	w1, #0x8                // =8
   14bc4:      	blr	x8
   14bc8:      	ldr	x24, [sp, #0x98]
   14bcc:      	ldr	x21, [sp, #0x48]
   14bd0:      	add	x2, x24, #0x20
   14bd4:      	stp	x2, x24, [sp, #0x50]
   14bd8:      	ldr	x8, [sp, #0x30]
   14bdc:      	ldr	x25, [sp, #0x8]
   14be0:      	add	x9, sp, #0x70
   14be4:      	cmp	x21, x8
   14be8:      	b.ne	0x14bf8 <generic_fentry_path+0xa748>
   14bec:      	ldr	x8, [sp, #0x38]
   14bf0:      	cmp	x2, x8
   14bf4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   14bf8:      	mov	w8, #0x4                // =4
   14bfc:      	add	x0, sp, #0x70
   14c00:      	mov	w1, #0x8                // =8
   14c04:      	blr	x8
   14c08:      	ldr	x8, [sp, #0x70]
   14c0c:      	cmp	x21, x8
   14c10:      	b.eq	0x14d04 <generic_fentry_path+0xa854>
   14c14:      	add	x23, x21, #0x18
   14c18:      	mov	w8, #0x4                // =4
   14c1c:      	add	x9, sp, #0x98
   14c20:      	add	x0, sp, #0x98
   14c24:      	mov	w1, #0x8                // =8
   14c28:      	mov	x2, x23
   14c2c:      	blr	x8
   14c30:      	ldr	x8, [sp, #0x98]
   14c34:      	cmp	x8, x21
   14c38:      	b.eq	0x14d04 <generic_fentry_path+0xa854>
   14c3c:      	mov	w8, #0x4                // =4
   14c40:      	add	x9, sp, #0x78
   14c44:      	add	x0, sp, #0x78
   14c48:      	mov	w1, #0x8                // =8
   14c4c:      	mov	x2, x23
   14c50:      	blr	x8
   14c54:      	add	x2, x21, #0x20
   14c58:      	mov	w8, #0x4                // =4
   14c5c:      	mov	w9, #0x10               // =16
   14c60:      	add	x10, sp, #0x80
   14c64:      	add	x0, sp, #0x80
   14c68:      	mov	w1, #0x10               // =16
   14c6c:      	blr	x8
   14c70:      	ldr	w21, [sp, #0x84]
   14c74:      	ldr	x8, [sp, #0x40]
   14c78:      	ldr	x10, [sp, #0x60]
   14c7c:      	sub	x12, x10, x8
   14c80:      	ldr	w23, [sp, #0x68]
   14c84:      	subs	w10, w21, w23
   14c88:      	ldr	x9, [sp, #0x88]
   14c8c:      	ldr	x25, [sp, #0x8]
   14c90:      	csel	w10, wzr, w10, lo
   14c94:      	cmp	w23, w21
   14c98:      	csel	w11, w23, w21, lo
   14c9c:      	cinc	w13, w11, hi
   14ca0:      	sub	w14, w23, w13
   14ca4:      	subs	x12, x12, x13
   14ca8:      	str	w14, [sp, #0x68]
   14cac:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   14cb0:      	cmp	x12, #0xfff
   14cb4:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   14cb8:      	cmp	w23, w21
   14cbc:      	b.ls	0x14cc8 <generic_fentry_path+0xa818>
   14cc0:      	mov	w13, #0x2f              // =47
   14cc4:      	strb	w13, [x8, x12]
   14cc8:      	add	x19, x8, x12
   14ccc:      	cmp	w23, w21
   14cd0:      	add	x2, x9, x10
   14cd4:      	and	w1, w11, #0xff
   14cd8:      	mov	w8, #0x4                // =4
   14cdc:      	cinc	x0, x19, hi
   14ce0:      	blr	x8
   14ce4:      	ldr	x25, [sp, #0x8]
   14ce8:      	cmp	w23, w21
   14cec:      	str	x19, [sp, #0x60]
   14cf0:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   14cf4:      	ldr	x21, [sp, #0x78]
   14cf8:      	ldp	x2, x24, [sp, #0x50]
   14cfc:      	str	x21, [sp, #0x48]
   14d00:      	b	0x14d54 <generic_fentry_path+0xa8a4>
   14d04:      	add	x2, x24, #0x10
   14d08:      	mov	w8, #0x4                // =4
   14d0c:      	add	x9, sp, #0x98
   14d10:      	add	x0, sp, #0x98
   14d14:      	mov	w1, #0x8                // =8
   14d18:      	blr	x8
   14d1c:      	ldr	x8, [sp, #0x58]
   14d20:      	ldr	x9, [sp, #0x98]
   14d24:      	cmp	x8, x9
   14d28:      	ldr	x25, [sp, #0x8]
   14d2c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   14d30:      	add	x2, x24, #0x18
   14d34:      	mov	w8, #0x4                // =4
   14d38:      	mov	x0, x22
   14d3c:      	mov	w1, #0x8                // =8
   14d40:      	blr	x8
   14d44:      	ldr	x24, [sp, #0x98]
   14d48:      	ldr	x21, [sp, #0x48]
   14d4c:      	add	x2, x24, #0x20
   14d50:      	stp	x2, x24, [sp, #0x50]
   14d54:      	ldr	x8, [sp, #0x30]
   14d58:      	ldr	x25, [sp, #0x8]
   14d5c:      	add	x9, sp, #0x70
   14d60:      	cmp	x21, x8
   14d64:      	b.ne	0x14d74 <generic_fentry_path+0xa8c4>
   14d68:      	ldr	x8, [sp, #0x38]
   14d6c:      	cmp	x2, x8
   14d70:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   14d74:      	mov	w8, #0x4                // =4
   14d78:      	add	x0, sp, #0x70
   14d7c:      	mov	w1, #0x8                // =8
   14d80:      	blr	x8
   14d84:      	ldr	x8, [sp, #0x70]
   14d88:      	cmp	x21, x8
   14d8c:      	b.eq	0x14e80 <generic_fentry_path+0xa9d0>
   14d90:      	add	x23, x21, #0x18
   14d94:      	mov	w8, #0x4                // =4
   14d98:      	add	x9, sp, #0x98
   14d9c:      	add	x0, sp, #0x98
   14da0:      	mov	w1, #0x8                // =8
   14da4:      	mov	x2, x23
   14da8:      	blr	x8
   14dac:      	ldr	x8, [sp, #0x98]
   14db0:      	cmp	x8, x21
   14db4:      	b.eq	0x14e80 <generic_fentry_path+0xa9d0>
   14db8:      	mov	w8, #0x4                // =4
   14dbc:      	add	x9, sp, #0x78
   14dc0:      	add	x0, sp, #0x78
   14dc4:      	mov	w1, #0x8                // =8
   14dc8:      	mov	x2, x23
   14dcc:      	blr	x8
   14dd0:      	add	x2, x21, #0x20
   14dd4:      	mov	w8, #0x4                // =4
   14dd8:      	mov	w9, #0x10               // =16
   14ddc:      	add	x10, sp, #0x80
   14de0:      	add	x0, sp, #0x80
   14de4:      	mov	w1, #0x10               // =16
   14de8:      	blr	x8
   14dec:      	ldr	w21, [sp, #0x84]
   14df0:      	ldr	x8, [sp, #0x40]
   14df4:      	ldr	x10, [sp, #0x60]
   14df8:      	sub	x12, x10, x8
   14dfc:      	ldr	w23, [sp, #0x68]
   14e00:      	subs	w10, w21, w23
   14e04:      	ldr	x9, [sp, #0x88]
   14e08:      	ldr	x25, [sp, #0x8]
   14e0c:      	csel	w10, wzr, w10, lo
   14e10:      	cmp	w23, w21
   14e14:      	csel	w11, w23, w21, lo
   14e18:      	cinc	w13, w11, hi
   14e1c:      	sub	w14, w23, w13
   14e20:      	subs	x12, x12, x13
   14e24:      	str	w14, [sp, #0x68]
   14e28:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   14e2c:      	cmp	x12, #0xfff
   14e30:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   14e34:      	cmp	w23, w21
   14e38:      	b.ls	0x14e44 <generic_fentry_path+0xa994>
   14e3c:      	mov	w13, #0x2f              // =47
   14e40:      	strb	w13, [x8, x12]
   14e44:      	add	x19, x8, x12
   14e48:      	cmp	w23, w21
   14e4c:      	add	x2, x9, x10
   14e50:      	and	w1, w11, #0xff
   14e54:      	mov	w8, #0x4                // =4
   14e58:      	cinc	x0, x19, hi
   14e5c:      	blr	x8
   14e60:      	ldr	x25, [sp, #0x8]
   14e64:      	cmp	w23, w21
   14e68:      	str	x19, [sp, #0x60]
   14e6c:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   14e70:      	ldr	x21, [sp, #0x78]
   14e74:      	ldp	x2, x24, [sp, #0x50]
   14e78:      	str	x21, [sp, #0x48]
   14e7c:      	b	0x14ed0 <generic_fentry_path+0xaa20>
   14e80:      	add	x2, x24, #0x10
   14e84:      	mov	w8, #0x4                // =4
   14e88:      	add	x9, sp, #0x98
   14e8c:      	add	x0, sp, #0x98
   14e90:      	mov	w1, #0x8                // =8
   14e94:      	blr	x8
   14e98:      	ldr	x8, [sp, #0x58]
   14e9c:      	ldr	x9, [sp, #0x98]
   14ea0:      	cmp	x8, x9
   14ea4:      	ldr	x25, [sp, #0x8]
   14ea8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   14eac:      	add	x2, x24, #0x18
   14eb0:      	mov	w8, #0x4                // =4
   14eb4:      	mov	x0, x22
   14eb8:      	mov	w1, #0x8                // =8
   14ebc:      	blr	x8
   14ec0:      	ldr	x24, [sp, #0x98]
   14ec4:      	ldr	x21, [sp, #0x48]
   14ec8:      	add	x2, x24, #0x20
   14ecc:      	stp	x2, x24, [sp, #0x50]
   14ed0:      	ldr	x8, [sp, #0x30]
   14ed4:      	ldr	x25, [sp, #0x8]
   14ed8:      	add	x9, sp, #0x70
   14edc:      	cmp	x21, x8
   14ee0:      	b.ne	0x14ef0 <generic_fentry_path+0xaa40>
   14ee4:      	ldr	x8, [sp, #0x38]
   14ee8:      	cmp	x2, x8
   14eec:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   14ef0:      	mov	w8, #0x4                // =4
   14ef4:      	add	x0, sp, #0x70
   14ef8:      	mov	w1, #0x8                // =8
   14efc:      	blr	x8
   14f00:      	ldr	x8, [sp, #0x70]
   14f04:      	cmp	x21, x8
   14f08:      	b.eq	0x14ffc <generic_fentry_path+0xab4c>
   14f0c:      	add	x23, x21, #0x18
   14f10:      	mov	w8, #0x4                // =4
   14f14:      	add	x9, sp, #0x98
   14f18:      	add	x0, sp, #0x98
   14f1c:      	mov	w1, #0x8                // =8
   14f20:      	mov	x2, x23
   14f24:      	blr	x8
   14f28:      	ldr	x8, [sp, #0x98]
   14f2c:      	cmp	x8, x21
   14f30:      	b.eq	0x14ffc <generic_fentry_path+0xab4c>
   14f34:      	mov	w8, #0x4                // =4
   14f38:      	add	x9, sp, #0x78
   14f3c:      	add	x0, sp, #0x78
   14f40:      	mov	w1, #0x8                // =8
   14f44:      	mov	x2, x23
   14f48:      	blr	x8
   14f4c:      	add	x2, x21, #0x20
   14f50:      	mov	w8, #0x4                // =4
   14f54:      	mov	w9, #0x10               // =16
   14f58:      	add	x10, sp, #0x80
   14f5c:      	add	x0, sp, #0x80
   14f60:      	mov	w1, #0x10               // =16
   14f64:      	blr	x8
   14f68:      	ldr	w21, [sp, #0x84]
   14f6c:      	ldr	x8, [sp, #0x40]
   14f70:      	ldr	x10, [sp, #0x60]
   14f74:      	sub	x12, x10, x8
   14f78:      	ldr	w23, [sp, #0x68]
   14f7c:      	subs	w10, w21, w23
   14f80:      	ldr	x9, [sp, #0x88]
   14f84:      	ldr	x25, [sp, #0x8]
   14f88:      	csel	w10, wzr, w10, lo
   14f8c:      	cmp	w23, w21
   14f90:      	csel	w11, w23, w21, lo
   14f94:      	cinc	w13, w11, hi
   14f98:      	sub	w14, w23, w13
   14f9c:      	subs	x12, x12, x13
   14fa0:      	str	w14, [sp, #0x68]
   14fa4:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   14fa8:      	cmp	x12, #0xfff
   14fac:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   14fb0:      	cmp	w23, w21
   14fb4:      	b.ls	0x14fc0 <generic_fentry_path+0xab10>
   14fb8:      	mov	w13, #0x2f              // =47
   14fbc:      	strb	w13, [x8, x12]
   14fc0:      	add	x19, x8, x12
   14fc4:      	cmp	w23, w21
   14fc8:      	add	x2, x9, x10
   14fcc:      	and	w1, w11, #0xff
   14fd0:      	mov	w8, #0x4                // =4
   14fd4:      	cinc	x0, x19, hi
   14fd8:      	blr	x8
   14fdc:      	ldr	x25, [sp, #0x8]
   14fe0:      	cmp	w23, w21
   14fe4:      	str	x19, [sp, #0x60]
   14fe8:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   14fec:      	ldr	x21, [sp, #0x78]
   14ff0:      	ldp	x2, x24, [sp, #0x50]
   14ff4:      	str	x21, [sp, #0x48]
   14ff8:      	b	0x1504c <generic_fentry_path+0xab9c>
   14ffc:      	add	x2, x24, #0x10
   15000:      	mov	w8, #0x4                // =4
   15004:      	add	x9, sp, #0x98
   15008:      	add	x0, sp, #0x98
   1500c:      	mov	w1, #0x8                // =8
   15010:      	blr	x8
   15014:      	ldr	x8, [sp, #0x58]
   15018:      	ldr	x9, [sp, #0x98]
   1501c:      	cmp	x8, x9
   15020:      	ldr	x25, [sp, #0x8]
   15024:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   15028:      	add	x2, x24, #0x18
   1502c:      	mov	w8, #0x4                // =4
   15030:      	mov	x0, x22
   15034:      	mov	w1, #0x8                // =8
   15038:      	blr	x8
   1503c:      	ldr	x24, [sp, #0x98]
   15040:      	ldr	x21, [sp, #0x48]
   15044:      	add	x2, x24, #0x20
   15048:      	stp	x2, x24, [sp, #0x50]
   1504c:      	ldr	x8, [sp, #0x30]
   15050:      	ldr	x25, [sp, #0x8]
   15054:      	add	x9, sp, #0x70
   15058:      	cmp	x21, x8
   1505c:      	b.ne	0x1506c <generic_fentry_path+0xabbc>
   15060:      	ldr	x8, [sp, #0x38]
   15064:      	cmp	x2, x8
   15068:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   1506c:      	mov	w8, #0x4                // =4
   15070:      	add	x0, sp, #0x70
   15074:      	mov	w1, #0x8                // =8
   15078:      	blr	x8
   1507c:      	ldr	x8, [sp, #0x70]
   15080:      	cmp	x21, x8
   15084:      	b.eq	0x15178 <generic_fentry_path+0xacc8>
   15088:      	add	x23, x21, #0x18
   1508c:      	mov	w8, #0x4                // =4
   15090:      	add	x9, sp, #0x98
   15094:      	add	x0, sp, #0x98
   15098:      	mov	w1, #0x8                // =8
   1509c:      	mov	x2, x23
   150a0:      	blr	x8
   150a4:      	ldr	x8, [sp, #0x98]
   150a8:      	cmp	x8, x21
   150ac:      	b.eq	0x15178 <generic_fentry_path+0xacc8>
   150b0:      	mov	w8, #0x4                // =4
   150b4:      	add	x9, sp, #0x78
   150b8:      	add	x0, sp, #0x78
   150bc:      	mov	w1, #0x8                // =8
   150c0:      	mov	x2, x23
   150c4:      	blr	x8
   150c8:      	add	x2, x21, #0x20
   150cc:      	mov	w8, #0x4                // =4
   150d0:      	mov	w9, #0x10               // =16
   150d4:      	add	x10, sp, #0x80
   150d8:      	add	x0, sp, #0x80
   150dc:      	mov	w1, #0x10               // =16
   150e0:      	blr	x8
   150e4:      	ldr	w21, [sp, #0x84]
   150e8:      	ldr	x8, [sp, #0x40]
   150ec:      	ldr	x10, [sp, #0x60]
   150f0:      	sub	x12, x10, x8
   150f4:      	ldr	w23, [sp, #0x68]
   150f8:      	subs	w10, w21, w23
   150fc:      	ldr	x9, [sp, #0x88]
   15100:      	ldr	x25, [sp, #0x8]
   15104:      	csel	w10, wzr, w10, lo
   15108:      	cmp	w23, w21
   1510c:      	csel	w11, w23, w21, lo
   15110:      	cinc	w13, w11, hi
   15114:      	sub	w14, w23, w13
   15118:      	subs	x12, x12, x13
   1511c:      	str	w14, [sp, #0x68]
   15120:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   15124:      	cmp	x12, #0xfff
   15128:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   1512c:      	cmp	w23, w21
   15130:      	b.ls	0x1513c <generic_fentry_path+0xac8c>
   15134:      	mov	w13, #0x2f              // =47
   15138:      	strb	w13, [x8, x12]
   1513c:      	add	x19, x8, x12
   15140:      	cmp	w23, w21
   15144:      	add	x2, x9, x10
   15148:      	and	w1, w11, #0xff
   1514c:      	mov	w8, #0x4                // =4
   15150:      	cinc	x0, x19, hi
   15154:      	blr	x8
   15158:      	ldr	x25, [sp, #0x8]
   1515c:      	cmp	w23, w21
   15160:      	str	x19, [sp, #0x60]
   15164:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   15168:      	ldr	x21, [sp, #0x78]
   1516c:      	ldp	x2, x24, [sp, #0x50]
   15170:      	str	x21, [sp, #0x48]
   15174:      	b	0x151c8 <generic_fentry_path+0xad18>
   15178:      	add	x2, x24, #0x10
   1517c:      	mov	w8, #0x4                // =4
   15180:      	add	x9, sp, #0x98
   15184:      	add	x0, sp, #0x98
   15188:      	mov	w1, #0x8                // =8
   1518c:      	blr	x8
   15190:      	ldr	x8, [sp, #0x58]
   15194:      	ldr	x9, [sp, #0x98]
   15198:      	cmp	x8, x9
   1519c:      	ldr	x25, [sp, #0x8]
   151a0:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   151a4:      	add	x2, x24, #0x18
   151a8:      	mov	w8, #0x4                // =4
   151ac:      	mov	x0, x22
   151b0:      	mov	w1, #0x8                // =8
   151b4:      	blr	x8
   151b8:      	ldr	x24, [sp, #0x98]
   151bc:      	ldr	x21, [sp, #0x48]
   151c0:      	add	x2, x24, #0x20
   151c4:      	stp	x2, x24, [sp, #0x50]
   151c8:      	ldr	x8, [sp, #0x30]
   151cc:      	ldr	x25, [sp, #0x8]
   151d0:      	add	x9, sp, #0x70
   151d4:      	cmp	x21, x8
   151d8:      	b.ne	0x151e8 <generic_fentry_path+0xad38>
   151dc:      	ldr	x8, [sp, #0x38]
   151e0:      	cmp	x2, x8
   151e4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   151e8:      	mov	w8, #0x4                // =4
   151ec:      	add	x0, sp, #0x70
   151f0:      	mov	w1, #0x8                // =8
   151f4:      	blr	x8
   151f8:      	ldr	x8, [sp, #0x70]
   151fc:      	cmp	x21, x8
   15200:      	b.eq	0x152f4 <generic_fentry_path+0xae44>
   15204:      	add	x23, x21, #0x18
   15208:      	mov	w8, #0x4                // =4
   1520c:      	add	x9, sp, #0x98
   15210:      	add	x0, sp, #0x98
   15214:      	mov	w1, #0x8                // =8
   15218:      	mov	x2, x23
   1521c:      	blr	x8
   15220:      	ldr	x8, [sp, #0x98]
   15224:      	cmp	x8, x21
   15228:      	b.eq	0x152f4 <generic_fentry_path+0xae44>
   1522c:      	mov	w8, #0x4                // =4
   15230:      	add	x9, sp, #0x78
   15234:      	add	x0, sp, #0x78
   15238:      	mov	w1, #0x8                // =8
   1523c:      	mov	x2, x23
   15240:      	blr	x8
   15244:      	add	x2, x21, #0x20
   15248:      	mov	w8, #0x4                // =4
   1524c:      	mov	w9, #0x10               // =16
   15250:      	add	x10, sp, #0x80
   15254:      	add	x0, sp, #0x80
   15258:      	mov	w1, #0x10               // =16
   1525c:      	blr	x8
   15260:      	ldr	w21, [sp, #0x84]
   15264:      	ldr	x8, [sp, #0x40]
   15268:      	ldr	x10, [sp, #0x60]
   1526c:      	sub	x12, x10, x8
   15270:      	ldr	w23, [sp, #0x68]
   15274:      	subs	w10, w21, w23
   15278:      	ldr	x9, [sp, #0x88]
   1527c:      	ldr	x25, [sp, #0x8]
   15280:      	csel	w10, wzr, w10, lo
   15284:      	cmp	w23, w21
   15288:      	csel	w11, w23, w21, lo
   1528c:      	cinc	w13, w11, hi
   15290:      	sub	w14, w23, w13
   15294:      	subs	x12, x12, x13
   15298:      	str	w14, [sp, #0x68]
   1529c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   152a0:      	cmp	x12, #0xfff
   152a4:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   152a8:      	cmp	w23, w21
   152ac:      	b.ls	0x152b8 <generic_fentry_path+0xae08>
   152b0:      	mov	w13, #0x2f              // =47
   152b4:      	strb	w13, [x8, x12]
   152b8:      	add	x19, x8, x12
   152bc:      	cmp	w23, w21
   152c0:      	add	x2, x9, x10
   152c4:      	and	w1, w11, #0xff
   152c8:      	mov	w8, #0x4                // =4
   152cc:      	cinc	x0, x19, hi
   152d0:      	blr	x8
   152d4:      	ldr	x25, [sp, #0x8]
   152d8:      	cmp	w23, w21
   152dc:      	str	x19, [sp, #0x60]
   152e0:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   152e4:      	ldr	x21, [sp, #0x78]
   152e8:      	ldp	x2, x24, [sp, #0x50]
   152ec:      	str	x21, [sp, #0x48]
   152f0:      	b	0x15344 <generic_fentry_path+0xae94>
   152f4:      	add	x2, x24, #0x10
   152f8:      	mov	w8, #0x4                // =4
   152fc:      	add	x9, sp, #0x98
   15300:      	add	x0, sp, #0x98
   15304:      	mov	w1, #0x8                // =8
   15308:      	blr	x8
   1530c:      	ldr	x8, [sp, #0x58]
   15310:      	ldr	x9, [sp, #0x98]
   15314:      	cmp	x8, x9
   15318:      	ldr	x25, [sp, #0x8]
   1531c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   15320:      	add	x2, x24, #0x18
   15324:      	mov	w8, #0x4                // =4
   15328:      	mov	x0, x22
   1532c:      	mov	w1, #0x8                // =8
   15330:      	blr	x8
   15334:      	ldr	x24, [sp, #0x98]
   15338:      	ldr	x21, [sp, #0x48]
   1533c:      	add	x2, x24, #0x20
   15340:      	stp	x2, x24, [sp, #0x50]
   15344:      	ldr	x8, [sp, #0x30]
   15348:      	ldr	x25, [sp, #0x8]
   1534c:      	add	x9, sp, #0x70
   15350:      	cmp	x21, x8
   15354:      	b.ne	0x15364 <generic_fentry_path+0xaeb4>
   15358:      	ldr	x8, [sp, #0x38]
   1535c:      	cmp	x2, x8
   15360:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   15364:      	mov	w8, #0x4                // =4
   15368:      	add	x0, sp, #0x70
   1536c:      	mov	w1, #0x8                // =8
   15370:      	blr	x8
   15374:      	ldr	x8, [sp, #0x70]
   15378:      	cmp	x21, x8
   1537c:      	b.eq	0x15470 <generic_fentry_path+0xafc0>
   15380:      	add	x23, x21, #0x18
   15384:      	mov	w8, #0x4                // =4
   15388:      	add	x9, sp, #0x98
   1538c:      	add	x0, sp, #0x98
   15390:      	mov	w1, #0x8                // =8
   15394:      	mov	x2, x23
   15398:      	blr	x8
   1539c:      	ldr	x8, [sp, #0x98]
   153a0:      	cmp	x8, x21
   153a4:      	b.eq	0x15470 <generic_fentry_path+0xafc0>
   153a8:      	mov	w8, #0x4                // =4
   153ac:      	add	x9, sp, #0x78
   153b0:      	add	x0, sp, #0x78
   153b4:      	mov	w1, #0x8                // =8
   153b8:      	mov	x2, x23
   153bc:      	blr	x8
   153c0:      	add	x2, x21, #0x20
   153c4:      	mov	w8, #0x4                // =4
   153c8:      	mov	w9, #0x10               // =16
   153cc:      	add	x10, sp, #0x80
   153d0:      	add	x0, sp, #0x80
   153d4:      	mov	w1, #0x10               // =16
   153d8:      	blr	x8
   153dc:      	ldr	w21, [sp, #0x84]
   153e0:      	ldr	x8, [sp, #0x40]
   153e4:      	ldr	x10, [sp, #0x60]
   153e8:      	sub	x12, x10, x8
   153ec:      	ldr	w23, [sp, #0x68]
   153f0:      	subs	w10, w21, w23
   153f4:      	ldr	x9, [sp, #0x88]
   153f8:      	ldr	x25, [sp, #0x8]
   153fc:      	csel	w10, wzr, w10, lo
   15400:      	cmp	w23, w21
   15404:      	csel	w11, w23, w21, lo
   15408:      	cinc	w13, w11, hi
   1540c:      	sub	w14, w23, w13
   15410:      	subs	x12, x12, x13
   15414:      	str	w14, [sp, #0x68]
   15418:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   1541c:      	cmp	x12, #0xfff
   15420:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   15424:      	cmp	w23, w21
   15428:      	b.ls	0x15434 <generic_fentry_path+0xaf84>
   1542c:      	mov	w13, #0x2f              // =47
   15430:      	strb	w13, [x8, x12]
   15434:      	add	x19, x8, x12
   15438:      	cmp	w23, w21
   1543c:      	add	x2, x9, x10
   15440:      	and	w1, w11, #0xff
   15444:      	mov	w8, #0x4                // =4
   15448:      	cinc	x0, x19, hi
   1544c:      	blr	x8
   15450:      	ldr	x25, [sp, #0x8]
   15454:      	cmp	w23, w21
   15458:      	str	x19, [sp, #0x60]
   1545c:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   15460:      	ldr	x21, [sp, #0x78]
   15464:      	ldp	x2, x24, [sp, #0x50]
   15468:      	str	x21, [sp, #0x48]
   1546c:      	b	0x154c0 <generic_fentry_path+0xb010>
   15470:      	add	x2, x24, #0x10
   15474:      	mov	w8, #0x4                // =4
   15478:      	add	x9, sp, #0x98
   1547c:      	add	x0, sp, #0x98
   15480:      	mov	w1, #0x8                // =8
   15484:      	blr	x8
   15488:      	ldr	x8, [sp, #0x58]
   1548c:      	ldr	x9, [sp, #0x98]
   15490:      	cmp	x8, x9
   15494:      	ldr	x25, [sp, #0x8]
   15498:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   1549c:      	add	x2, x24, #0x18
   154a0:      	mov	w8, #0x4                // =4
   154a4:      	mov	x0, x22
   154a8:      	mov	w1, #0x8                // =8
   154ac:      	blr	x8
   154b0:      	ldr	x24, [sp, #0x98]
   154b4:      	ldr	x21, [sp, #0x48]
   154b8:      	add	x2, x24, #0x20
   154bc:      	stp	x2, x24, [sp, #0x50]
   154c0:      	ldr	x8, [sp, #0x30]
   154c4:      	ldr	x25, [sp, #0x8]
   154c8:      	add	x9, sp, #0x70
   154cc:      	cmp	x21, x8
   154d0:      	b.ne	0x154e0 <generic_fentry_path+0xb030>
   154d4:      	ldr	x8, [sp, #0x38]
   154d8:      	cmp	x2, x8
   154dc:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   154e0:      	mov	w8, #0x4                // =4
   154e4:      	add	x0, sp, #0x70
   154e8:      	mov	w1, #0x8                // =8
   154ec:      	blr	x8
   154f0:      	ldr	x8, [sp, #0x70]
   154f4:      	cmp	x21, x8
   154f8:      	b.eq	0x155ec <generic_fentry_path+0xb13c>
   154fc:      	add	x23, x21, #0x18
   15500:      	mov	w8, #0x4                // =4
   15504:      	add	x9, sp, #0x98
   15508:      	add	x0, sp, #0x98
   1550c:      	mov	w1, #0x8                // =8
   15510:      	mov	x2, x23
   15514:      	blr	x8
   15518:      	ldr	x8, [sp, #0x98]
   1551c:      	cmp	x8, x21
   15520:      	b.eq	0x155ec <generic_fentry_path+0xb13c>
   15524:      	mov	w8, #0x4                // =4
   15528:      	add	x9, sp, #0x78
   1552c:      	add	x0, sp, #0x78
   15530:      	mov	w1, #0x8                // =8
   15534:      	mov	x2, x23
   15538:      	blr	x8
   1553c:      	add	x2, x21, #0x20
   15540:      	mov	w8, #0x4                // =4
   15544:      	mov	w9, #0x10               // =16
   15548:      	add	x10, sp, #0x80
   1554c:      	add	x0, sp, #0x80
   15550:      	mov	w1, #0x10               // =16
   15554:      	blr	x8
   15558:      	ldr	w21, [sp, #0x84]
   1555c:      	ldr	x8, [sp, #0x40]
   15560:      	ldr	x10, [sp, #0x60]
   15564:      	sub	x12, x10, x8
   15568:      	ldr	w23, [sp, #0x68]
   1556c:      	subs	w10, w21, w23
   15570:      	ldr	x9, [sp, #0x88]
   15574:      	ldr	x25, [sp, #0x8]
   15578:      	csel	w10, wzr, w10, lo
   1557c:      	cmp	w23, w21
   15580:      	csel	w11, w23, w21, lo
   15584:      	cinc	w13, w11, hi
   15588:      	sub	w14, w23, w13
   1558c:      	subs	x12, x12, x13
   15590:      	str	w14, [sp, #0x68]
   15594:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   15598:      	cmp	x12, #0xfff
   1559c:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   155a0:      	cmp	w23, w21
   155a4:      	b.ls	0x155b0 <generic_fentry_path+0xb100>
   155a8:      	mov	w13, #0x2f              // =47
   155ac:      	strb	w13, [x8, x12]
   155b0:      	add	x19, x8, x12
   155b4:      	cmp	w23, w21
   155b8:      	add	x2, x9, x10
   155bc:      	and	w1, w11, #0xff
   155c0:      	mov	w8, #0x4                // =4
   155c4:      	cinc	x0, x19, hi
   155c8:      	blr	x8
   155cc:      	ldr	x25, [sp, #0x8]
   155d0:      	cmp	w23, w21
   155d4:      	str	x19, [sp, #0x60]
   155d8:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   155dc:      	ldr	x21, [sp, #0x78]
   155e0:      	ldp	x2, x24, [sp, #0x50]
   155e4:      	str	x21, [sp, #0x48]
   155e8:      	b	0x1563c <generic_fentry_path+0xb18c>
   155ec:      	add	x2, x24, #0x10
   155f0:      	mov	w8, #0x4                // =4
   155f4:      	add	x9, sp, #0x98
   155f8:      	add	x0, sp, #0x98
   155fc:      	mov	w1, #0x8                // =8
   15600:      	blr	x8
   15604:      	ldr	x8, [sp, #0x58]
   15608:      	ldr	x9, [sp, #0x98]
   1560c:      	cmp	x8, x9
   15610:      	ldr	x25, [sp, #0x8]
   15614:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   15618:      	add	x2, x24, #0x18
   1561c:      	mov	w8, #0x4                // =4
   15620:      	mov	x0, x22
   15624:      	mov	w1, #0x8                // =8
   15628:      	blr	x8
   1562c:      	ldr	x24, [sp, #0x98]
   15630:      	ldr	x21, [sp, #0x48]
   15634:      	add	x2, x24, #0x20
   15638:      	stp	x2, x24, [sp, #0x50]
   1563c:      	ldr	x8, [sp, #0x30]
   15640:      	ldr	x25, [sp, #0x8]
   15644:      	add	x9, sp, #0x70
   15648:      	cmp	x21, x8
   1564c:      	b.ne	0x1565c <generic_fentry_path+0xb1ac>
   15650:      	ldr	x8, [sp, #0x38]
   15654:      	cmp	x2, x8
   15658:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   1565c:      	mov	w8, #0x4                // =4
   15660:      	add	x0, sp, #0x70
   15664:      	mov	w1, #0x8                // =8
   15668:      	blr	x8
   1566c:      	ldr	x8, [sp, #0x70]
   15670:      	cmp	x21, x8
   15674:      	b.eq	0x15768 <generic_fentry_path+0xb2b8>
   15678:      	add	x23, x21, #0x18
   1567c:      	mov	w8, #0x4                // =4
   15680:      	add	x9, sp, #0x98
   15684:      	add	x0, sp, #0x98
   15688:      	mov	w1, #0x8                // =8
   1568c:      	mov	x2, x23
   15690:      	blr	x8
   15694:      	ldr	x8, [sp, #0x98]
   15698:      	cmp	x8, x21
   1569c:      	b.eq	0x15768 <generic_fentry_path+0xb2b8>
   156a0:      	mov	w8, #0x4                // =4
   156a4:      	add	x9, sp, #0x78
   156a8:      	add	x0, sp, #0x78
   156ac:      	mov	w1, #0x8                // =8
   156b0:      	mov	x2, x23
   156b4:      	blr	x8
   156b8:      	add	x2, x21, #0x20
   156bc:      	mov	w8, #0x4                // =4
   156c0:      	mov	w9, #0x10               // =16
   156c4:      	add	x10, sp, #0x80
   156c8:      	add	x0, sp, #0x80
   156cc:      	mov	w1, #0x10               // =16
   156d0:      	blr	x8
   156d4:      	ldr	w21, [sp, #0x84]
   156d8:      	ldr	x8, [sp, #0x40]
   156dc:      	ldr	x10, [sp, #0x60]
   156e0:      	sub	x12, x10, x8
   156e4:      	ldr	w23, [sp, #0x68]
   156e8:      	subs	w10, w21, w23
   156ec:      	ldr	x9, [sp, #0x88]
   156f0:      	ldr	x25, [sp, #0x8]
   156f4:      	csel	w10, wzr, w10, lo
   156f8:      	cmp	w23, w21
   156fc:      	csel	w11, w23, w21, lo
   15700:      	cinc	w13, w11, hi
   15704:      	sub	w14, w23, w13
   15708:      	subs	x12, x12, x13
   1570c:      	str	w14, [sp, #0x68]
   15710:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   15714:      	cmp	x12, #0xfff
   15718:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   1571c:      	cmp	w23, w21
   15720:      	b.ls	0x1572c <generic_fentry_path+0xb27c>
   15724:      	mov	w13, #0x2f              // =47
   15728:      	strb	w13, [x8, x12]
   1572c:      	add	x19, x8, x12
   15730:      	cmp	w23, w21
   15734:      	add	x2, x9, x10
   15738:      	and	w1, w11, #0xff
   1573c:      	mov	w8, #0x4                // =4
   15740:      	cinc	x0, x19, hi
   15744:      	blr	x8
   15748:      	ldr	x25, [sp, #0x8]
   1574c:      	cmp	w23, w21
   15750:      	str	x19, [sp, #0x60]
   15754:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   15758:      	ldr	x21, [sp, #0x78]
   1575c:      	ldp	x2, x24, [sp, #0x50]
   15760:      	str	x21, [sp, #0x48]
   15764:      	b	0x157b8 <generic_fentry_path+0xb308>
   15768:      	add	x2, x24, #0x10
   1576c:      	mov	w8, #0x4                // =4
   15770:      	add	x9, sp, #0x98
   15774:      	add	x0, sp, #0x98
   15778:      	mov	w1, #0x8                // =8
   1577c:      	blr	x8
   15780:      	ldr	x8, [sp, #0x58]
   15784:      	ldr	x9, [sp, #0x98]
   15788:      	cmp	x8, x9
   1578c:      	ldr	x25, [sp, #0x8]
   15790:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   15794:      	add	x2, x24, #0x18
   15798:      	mov	w8, #0x4                // =4
   1579c:      	mov	x0, x22
   157a0:      	mov	w1, #0x8                // =8
   157a4:      	blr	x8
   157a8:      	ldr	x24, [sp, #0x98]
   157ac:      	ldr	x21, [sp, #0x48]
   157b0:      	add	x2, x24, #0x20
   157b4:      	stp	x2, x24, [sp, #0x50]
   157b8:      	ldr	x8, [sp, #0x30]
   157bc:      	ldr	x25, [sp, #0x8]
   157c0:      	add	x9, sp, #0x70
   157c4:      	cmp	x21, x8
   157c8:      	b.ne	0x157d8 <generic_fentry_path+0xb328>
   157cc:      	ldr	x8, [sp, #0x38]
   157d0:      	cmp	x2, x8
   157d4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   157d8:      	mov	w8, #0x4                // =4
   157dc:      	add	x0, sp, #0x70
   157e0:      	mov	w1, #0x8                // =8
   157e4:      	blr	x8
   157e8:      	ldr	x8, [sp, #0x70]
   157ec:      	cmp	x21, x8
   157f0:      	b.eq	0x158e4 <generic_fentry_path+0xb434>
   157f4:      	add	x23, x21, #0x18
   157f8:      	mov	w8, #0x4                // =4
   157fc:      	add	x9, sp, #0x98
   15800:      	add	x0, sp, #0x98
   15804:      	mov	w1, #0x8                // =8
   15808:      	mov	x2, x23
   1580c:      	blr	x8
   15810:      	ldr	x8, [sp, #0x98]
   15814:      	cmp	x8, x21
   15818:      	b.eq	0x158e4 <generic_fentry_path+0xb434>
   1581c:      	mov	w8, #0x4                // =4
   15820:      	add	x9, sp, #0x78
   15824:      	add	x0, sp, #0x78
   15828:      	mov	w1, #0x8                // =8
   1582c:      	mov	x2, x23
   15830:      	blr	x8
   15834:      	add	x2, x21, #0x20
   15838:      	mov	w8, #0x4                // =4
   1583c:      	mov	w9, #0x10               // =16
   15840:      	add	x10, sp, #0x80
   15844:      	add	x0, sp, #0x80
   15848:      	mov	w1, #0x10               // =16
   1584c:      	blr	x8
   15850:      	ldr	w21, [sp, #0x84]
   15854:      	ldr	x8, [sp, #0x40]
   15858:      	ldr	x10, [sp, #0x60]
   1585c:      	sub	x12, x10, x8
   15860:      	ldr	w23, [sp, #0x68]
   15864:      	subs	w10, w21, w23
   15868:      	ldr	x9, [sp, #0x88]
   1586c:      	ldr	x25, [sp, #0x8]
   15870:      	csel	w10, wzr, w10, lo
   15874:      	cmp	w23, w21
   15878:      	csel	w11, w23, w21, lo
   1587c:      	cinc	w13, w11, hi
   15880:      	sub	w14, w23, w13
   15884:      	subs	x12, x12, x13
   15888:      	str	w14, [sp, #0x68]
   1588c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   15890:      	cmp	x12, #0xfff
   15894:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   15898:      	cmp	w23, w21
   1589c:      	b.ls	0x158a8 <generic_fentry_path+0xb3f8>
   158a0:      	mov	w13, #0x2f              // =47
   158a4:      	strb	w13, [x8, x12]
   158a8:      	add	x19, x8, x12
   158ac:      	cmp	w23, w21
   158b0:      	add	x2, x9, x10
   158b4:      	and	w1, w11, #0xff
   158b8:      	mov	w8, #0x4                // =4
   158bc:      	cinc	x0, x19, hi
   158c0:      	blr	x8
   158c4:      	ldr	x25, [sp, #0x8]
   158c8:      	cmp	w23, w21
   158cc:      	str	x19, [sp, #0x60]
   158d0:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   158d4:      	ldr	x21, [sp, #0x78]
   158d8:      	ldp	x2, x24, [sp, #0x50]
   158dc:      	str	x21, [sp, #0x48]
   158e0:      	b	0x15934 <generic_fentry_path+0xb484>
   158e4:      	add	x2, x24, #0x10
   158e8:      	mov	w8, #0x4                // =4
   158ec:      	add	x9, sp, #0x98
   158f0:      	add	x0, sp, #0x98
   158f4:      	mov	w1, #0x8                // =8
   158f8:      	blr	x8
   158fc:      	ldr	x8, [sp, #0x58]
   15900:      	ldr	x9, [sp, #0x98]
   15904:      	cmp	x8, x9
   15908:      	ldr	x25, [sp, #0x8]
   1590c:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   15910:      	add	x2, x24, #0x18
   15914:      	mov	w8, #0x4                // =4
   15918:      	mov	x0, x22
   1591c:      	mov	w1, #0x8                // =8
   15920:      	blr	x8
   15924:      	ldr	x24, [sp, #0x98]
   15928:      	ldr	x21, [sp, #0x48]
   1592c:      	add	x2, x24, #0x20
   15930:      	stp	x2, x24, [sp, #0x50]
   15934:      	ldr	x8, [sp, #0x30]
   15938:      	ldr	x25, [sp, #0x8]
   1593c:      	add	x9, sp, #0x70
   15940:      	cmp	x21, x8
   15944:      	b.ne	0x15954 <generic_fentry_path+0xb4a4>
   15948:      	ldr	x8, [sp, #0x38]
   1594c:      	cmp	x2, x8
   15950:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   15954:      	mov	w8, #0x4                // =4
   15958:      	add	x0, sp, #0x70
   1595c:      	mov	w1, #0x8                // =8
   15960:      	blr	x8
   15964:      	ldr	x8, [sp, #0x70]
   15968:      	cmp	x21, x8
   1596c:      	b.eq	0x15a60 <generic_fentry_path+0xb5b0>
   15970:      	add	x23, x21, #0x18
   15974:      	mov	w8, #0x4                // =4
   15978:      	add	x9, sp, #0x98
   1597c:      	add	x0, sp, #0x98
   15980:      	mov	w1, #0x8                // =8
   15984:      	mov	x2, x23
   15988:      	blr	x8
   1598c:      	ldr	x8, [sp, #0x98]
   15990:      	cmp	x8, x21
   15994:      	b.eq	0x15a60 <generic_fentry_path+0xb5b0>
   15998:      	mov	w8, #0x4                // =4
   1599c:      	add	x9, sp, #0x78
   159a0:      	add	x0, sp, #0x78
   159a4:      	mov	w1, #0x8                // =8
   159a8:      	mov	x2, x23
   159ac:      	blr	x8
   159b0:      	add	x2, x21, #0x20
   159b4:      	mov	w8, #0x4                // =4
   159b8:      	mov	w9, #0x10               // =16
   159bc:      	add	x10, sp, #0x80
   159c0:      	add	x0, sp, #0x80
   159c4:      	mov	w1, #0x10               // =16
   159c8:      	blr	x8
   159cc:      	ldr	w21, [sp, #0x84]
   159d0:      	ldr	x8, [sp, #0x40]
   159d4:      	ldr	x10, [sp, #0x60]
   159d8:      	sub	x12, x10, x8
   159dc:      	ldr	w23, [sp, #0x68]
   159e0:      	subs	w10, w21, w23
   159e4:      	ldr	x9, [sp, #0x88]
   159e8:      	ldr	x25, [sp, #0x8]
   159ec:      	csel	w10, wzr, w10, lo
   159f0:      	cmp	w23, w21
   159f4:      	csel	w11, w23, w21, lo
   159f8:      	cinc	w13, w11, hi
   159fc:      	sub	w14, w23, w13
   15a00:      	subs	x12, x12, x13
   15a04:      	str	w14, [sp, #0x68]
   15a08:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   15a0c:      	cmp	x12, #0xfff
   15a10:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   15a14:      	cmp	w23, w21
   15a18:      	b.ls	0x15a24 <generic_fentry_path+0xb574>
   15a1c:      	mov	w13, #0x2f              // =47
   15a20:      	strb	w13, [x8, x12]
   15a24:      	add	x19, x8, x12
   15a28:      	cmp	w23, w21
   15a2c:      	add	x2, x9, x10
   15a30:      	and	w1, w11, #0xff
   15a34:      	mov	w8, #0x4                // =4
   15a38:      	cinc	x0, x19, hi
   15a3c:      	blr	x8
   15a40:      	ldr	x25, [sp, #0x8]
   15a44:      	cmp	w23, w21
   15a48:      	str	x19, [sp, #0x60]
   15a4c:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   15a50:      	ldr	x21, [sp, #0x78]
   15a54:      	ldp	x2, x24, [sp, #0x50]
   15a58:      	str	x21, [sp, #0x48]
   15a5c:      	b	0x15ab0 <generic_fentry_path+0xb600>
   15a60:      	add	x2, x24, #0x10
   15a64:      	mov	w8, #0x4                // =4
   15a68:      	add	x9, sp, #0x98
   15a6c:      	add	x0, sp, #0x98
   15a70:      	mov	w1, #0x8                // =8
   15a74:      	blr	x8
   15a78:      	ldr	x8, [sp, #0x58]
   15a7c:      	ldr	x9, [sp, #0x98]
   15a80:      	cmp	x8, x9
   15a84:      	ldr	x25, [sp, #0x8]
   15a88:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   15a8c:      	add	x2, x24, #0x18
   15a90:      	mov	w8, #0x4                // =4
   15a94:      	mov	x0, x22
   15a98:      	mov	w1, #0x8                // =8
   15a9c:      	blr	x8
   15aa0:      	ldr	x24, [sp, #0x98]
   15aa4:      	ldr	x21, [sp, #0x48]
   15aa8:      	add	x2, x24, #0x20
   15aac:      	stp	x2, x24, [sp, #0x50]
   15ab0:      	ldr	x8, [sp, #0x30]
   15ab4:      	ldr	x25, [sp, #0x8]
   15ab8:      	add	x9, sp, #0x70
   15abc:      	cmp	x21, x8
   15ac0:      	b.ne	0x15ad0 <generic_fentry_path+0xb620>
   15ac4:      	ldr	x8, [sp, #0x38]
   15ac8:      	cmp	x2, x8
   15acc:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   15ad0:      	mov	w8, #0x4                // =4
   15ad4:      	add	x0, sp, #0x70
   15ad8:      	mov	w1, #0x8                // =8
   15adc:      	blr	x8
   15ae0:      	ldr	x8, [sp, #0x70]
   15ae4:      	cmp	x21, x8
   15ae8:      	b.eq	0x15bdc <generic_fentry_path+0xb72c>
   15aec:      	add	x23, x21, #0x18
   15af0:      	mov	w8, #0x4                // =4
   15af4:      	add	x9, sp, #0x98
   15af8:      	add	x0, sp, #0x98
   15afc:      	mov	w1, #0x8                // =8
   15b00:      	mov	x2, x23
   15b04:      	blr	x8
   15b08:      	ldr	x8, [sp, #0x98]
   15b0c:      	cmp	x8, x21
   15b10:      	b.eq	0x15bdc <generic_fentry_path+0xb72c>
   15b14:      	mov	w8, #0x4                // =4
   15b18:      	add	x9, sp, #0x78
   15b1c:      	add	x0, sp, #0x78
   15b20:      	mov	w1, #0x8                // =8
   15b24:      	mov	x2, x23
   15b28:      	blr	x8
   15b2c:      	add	x2, x21, #0x20
   15b30:      	mov	w8, #0x4                // =4
   15b34:      	mov	w9, #0x10               // =16
   15b38:      	add	x10, sp, #0x80
   15b3c:      	add	x0, sp, #0x80
   15b40:      	mov	w1, #0x10               // =16
   15b44:      	blr	x8
   15b48:      	ldr	w21, [sp, #0x84]
   15b4c:      	ldr	x8, [sp, #0x40]
   15b50:      	ldr	x10, [sp, #0x60]
   15b54:      	sub	x12, x10, x8
   15b58:      	ldr	w23, [sp, #0x68]
   15b5c:      	subs	w10, w21, w23
   15b60:      	ldr	x9, [sp, #0x88]
   15b64:      	ldr	x25, [sp, #0x8]
   15b68:      	csel	w10, wzr, w10, lo
   15b6c:      	cmp	w23, w21
   15b70:      	csel	w11, w23, w21, lo
   15b74:      	cinc	w13, w11, hi
   15b78:      	sub	w14, w23, w13
   15b7c:      	subs	x12, x12, x13
   15b80:      	str	w14, [sp, #0x68]
   15b84:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   15b88:      	cmp	x12, #0xfff
   15b8c:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   15b90:      	cmp	w23, w21
   15b94:      	b.ls	0x15ba0 <generic_fentry_path+0xb6f0>
   15b98:      	mov	w13, #0x2f              // =47
   15b9c:      	strb	w13, [x8, x12]
   15ba0:      	add	x19, x8, x12
   15ba4:      	cmp	w23, w21
   15ba8:      	add	x2, x9, x10
   15bac:      	and	w1, w11, #0xff
   15bb0:      	mov	w8, #0x4                // =4
   15bb4:      	cinc	x0, x19, hi
   15bb8:      	blr	x8
   15bbc:      	ldr	x25, [sp, #0x8]
   15bc0:      	cmp	w23, w21
   15bc4:      	str	x19, [sp, #0x60]
   15bc8:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   15bcc:      	ldr	x21, [sp, #0x78]
   15bd0:      	ldp	x2, x24, [sp, #0x50]
   15bd4:      	str	x21, [sp, #0x48]
   15bd8:      	b	0x15c2c <generic_fentry_path+0xb77c>
   15bdc:      	add	x2, x24, #0x10
   15be0:      	mov	w8, #0x4                // =4
   15be4:      	add	x9, sp, #0x98
   15be8:      	add	x0, sp, #0x98
   15bec:      	mov	w1, #0x8                // =8
   15bf0:      	blr	x8
   15bf4:      	ldr	x8, [sp, #0x58]
   15bf8:      	ldr	x9, [sp, #0x98]
   15bfc:      	cmp	x8, x9
   15c00:      	ldr	x25, [sp, #0x8]
   15c04:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   15c08:      	add	x2, x24, #0x18
   15c0c:      	mov	w8, #0x4                // =4
   15c10:      	mov	x0, x22
   15c14:      	mov	w1, #0x8                // =8
   15c18:      	blr	x8
   15c1c:      	ldr	x24, [sp, #0x98]
   15c20:      	ldr	x21, [sp, #0x48]
   15c24:      	add	x2, x24, #0x20
   15c28:      	stp	x2, x24, [sp, #0x50]
   15c2c:      	ldr	x8, [sp, #0x30]
   15c30:      	ldr	x25, [sp, #0x8]
   15c34:      	add	x9, sp, #0x70
   15c38:      	cmp	x21, x8
   15c3c:      	b.ne	0x15c4c <generic_fentry_path+0xb79c>
   15c40:      	ldr	x8, [sp, #0x38]
   15c44:      	cmp	x2, x8
   15c48:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   15c4c:      	mov	w8, #0x4                // =4
   15c50:      	add	x0, sp, #0x70
   15c54:      	mov	w1, #0x8                // =8
   15c58:      	blr	x8
   15c5c:      	ldr	x8, [sp, #0x70]
   15c60:      	cmp	x21, x8
   15c64:      	b.eq	0x15d58 <generic_fentry_path+0xb8a8>
   15c68:      	add	x23, x21, #0x18
   15c6c:      	mov	w8, #0x4                // =4
   15c70:      	add	x9, sp, #0x98
   15c74:      	add	x0, sp, #0x98
   15c78:      	mov	w1, #0x8                // =8
   15c7c:      	mov	x2, x23
   15c80:      	blr	x8
   15c84:      	ldr	x8, [sp, #0x98]
   15c88:      	cmp	x8, x21
   15c8c:      	b.eq	0x15d58 <generic_fentry_path+0xb8a8>
   15c90:      	mov	w8, #0x4                // =4
   15c94:      	add	x9, sp, #0x78
   15c98:      	add	x0, sp, #0x78
   15c9c:      	mov	w1, #0x8                // =8
   15ca0:      	mov	x2, x23
   15ca4:      	blr	x8
   15ca8:      	add	x2, x21, #0x20
   15cac:      	mov	w8, #0x4                // =4
   15cb0:      	mov	w9, #0x10               // =16
   15cb4:      	add	x10, sp, #0x80
   15cb8:      	add	x0, sp, #0x80
   15cbc:      	mov	w1, #0x10               // =16
   15cc0:      	blr	x8
   15cc4:      	ldr	w21, [sp, #0x84]
   15cc8:      	ldr	x8, [sp, #0x40]
   15ccc:      	ldr	x10, [sp, #0x60]
   15cd0:      	sub	x12, x10, x8
   15cd4:      	ldr	w23, [sp, #0x68]
   15cd8:      	subs	w10, w21, w23
   15cdc:      	ldr	x9, [sp, #0x88]
   15ce0:      	ldr	x25, [sp, #0x8]
   15ce4:      	csel	w10, wzr, w10, lo
   15ce8:      	cmp	w23, w21
   15cec:      	csel	w11, w23, w21, lo
   15cf0:      	cinc	w13, w11, hi
   15cf4:      	sub	w14, w23, w13
   15cf8:      	subs	x12, x12, x13
   15cfc:      	str	w14, [sp, #0x68]
   15d00:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   15d04:      	cmp	x12, #0xfff
   15d08:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   15d0c:      	cmp	w23, w21
   15d10:      	b.ls	0x15d1c <generic_fentry_path+0xb86c>
   15d14:      	mov	w13, #0x2f              // =47
   15d18:      	strb	w13, [x8, x12]
   15d1c:      	add	x19, x8, x12
   15d20:      	cmp	w23, w21
   15d24:      	add	x2, x9, x10
   15d28:      	and	w1, w11, #0xff
   15d2c:      	mov	w8, #0x4                // =4
   15d30:      	cinc	x0, x19, hi
   15d34:      	blr	x8
   15d38:      	ldr	x25, [sp, #0x8]
   15d3c:      	cmp	w23, w21
   15d40:      	str	x19, [sp, #0x60]
   15d44:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   15d48:      	ldr	x21, [sp, #0x78]
   15d4c:      	ldp	x2, x24, [sp, #0x50]
   15d50:      	str	x21, [sp, #0x48]
   15d54:      	b	0x15da8 <generic_fentry_path+0xb8f8>
   15d58:      	add	x2, x24, #0x10
   15d5c:      	mov	w8, #0x4                // =4
   15d60:      	add	x9, sp, #0x98
   15d64:      	add	x0, sp, #0x98
   15d68:      	mov	w1, #0x8                // =8
   15d6c:      	blr	x8
   15d70:      	ldr	x8, [sp, #0x58]
   15d74:      	ldr	x9, [sp, #0x98]
   15d78:      	cmp	x8, x9
   15d7c:      	ldr	x25, [sp, #0x8]
   15d80:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   15d84:      	add	x2, x24, #0x18
   15d88:      	mov	w8, #0x4                // =4
   15d8c:      	mov	x0, x22
   15d90:      	mov	w1, #0x8                // =8
   15d94:      	blr	x8
   15d98:      	ldr	x24, [sp, #0x98]
   15d9c:      	ldr	x21, [sp, #0x48]
   15da0:      	add	x2, x24, #0x20
   15da4:      	stp	x2, x24, [sp, #0x50]
   15da8:      	ldr	x8, [sp, #0x30]
   15dac:      	ldr	x25, [sp, #0x8]
   15db0:      	add	x9, sp, #0x70
   15db4:      	cmp	x21, x8
   15db8:      	b.ne	0x15dc8 <generic_fentry_path+0xb918>
   15dbc:      	ldr	x8, [sp, #0x38]
   15dc0:      	cmp	x2, x8
   15dc4:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   15dc8:      	mov	w8, #0x4                // =4
   15dcc:      	add	x0, sp, #0x70
   15dd0:      	mov	w1, #0x8                // =8
   15dd4:      	blr	x8
   15dd8:      	ldr	x8, [sp, #0x70]
   15ddc:      	cmp	x21, x8
   15de0:      	b.eq	0x15ed0 <generic_fentry_path+0xba20>
   15de4:      	add	x23, x21, #0x18
   15de8:      	mov	w8, #0x4                // =4
   15dec:      	add	x9, sp, #0x98
   15df0:      	add	x0, sp, #0x98
   15df4:      	mov	w1, #0x8                // =8
   15df8:      	mov	x2, x23
   15dfc:      	blr	x8
   15e00:      	ldr	x8, [sp, #0x98]
   15e04:      	cmp	x8, x21
   15e08:      	b.eq	0x15ed0 <generic_fentry_path+0xba20>
   15e0c:      	mov	w8, #0x4                // =4
   15e10:      	add	x9, sp, #0x78
   15e14:      	add	x0, sp, #0x78
   15e18:      	mov	w1, #0x8                // =8
   15e1c:      	mov	x2, x23
   15e20:      	blr	x8
   15e24:      	add	x2, x21, #0x20
   15e28:      	mov	w8, #0x4                // =4
   15e2c:      	mov	w9, #0x10               // =16
   15e30:      	add	x10, sp, #0x80
   15e34:      	add	x0, sp, #0x80
   15e38:      	mov	w1, #0x10               // =16
   15e3c:      	blr	x8
   15e40:      	ldr	w21, [sp, #0x84]
   15e44:      	ldr	x8, [sp, #0x40]
   15e48:      	ldr	x10, [sp, #0x60]
   15e4c:      	sub	x12, x10, x8
   15e50:      	ldr	w23, [sp, #0x68]
   15e54:      	subs	w10, w21, w23
   15e58:      	ldr	x9, [sp, #0x88]
   15e5c:      	ldr	x25, [sp, #0x8]
   15e60:      	csel	w10, wzr, w10, lo
   15e64:      	cmp	w23, w21
   15e68:      	csel	w11, w23, w21, lo
   15e6c:      	cinc	w13, w11, hi
   15e70:      	sub	w14, w23, w13
   15e74:      	subs	x12, x12, x13
   15e78:      	str	w14, [sp, #0x68]
   15e7c:      	b.lo	0x15f38 <generic_fentry_path+0xba88>
   15e80:      	cmp	x12, #0xfff
   15e84:      	b.hi	0x15f38 <generic_fentry_path+0xba88>
   15e88:      	cmp	w23, w21
   15e8c:      	b.ls	0x15e98 <generic_fentry_path+0xb9e8>
   15e90:      	mov	w13, #0x2f              // =47
   15e94:      	strb	w13, [x8, x12]
   15e98:      	add	x19, x8, x12
   15e9c:      	cmp	w23, w21
   15ea0:      	add	x2, x9, x10
   15ea4:      	and	w1, w11, #0xff
   15ea8:      	mov	w8, #0x4                // =4
   15eac:      	cinc	x0, x19, hi
   15eb0:      	blr	x8
   15eb4:      	ldr	x25, [sp, #0x8]
   15eb8:      	cmp	w23, w21
   15ebc:      	str	x19, [sp, #0x60]
   15ec0:      	b.ls	0x15f38 <generic_fentry_path+0xba88>
   15ec4:      	ldr	x8, [sp, #0x78]
   15ec8:      	str	x8, [sp, #0x48]
   15ecc:      	b	0x15f1c <generic_fentry_path+0xba6c>
   15ed0:      	add	x2, x24, #0x10
   15ed4:      	mov	w8, #0x4                // =4
   15ed8:      	add	x9, sp, #0x98
   15edc:      	add	x0, sp, #0x98
   15ee0:      	mov	w1, #0x8                // =8
   15ee4:      	blr	x8
   15ee8:      	ldr	x8, [sp, #0x58]
   15eec:      	ldr	x9, [sp, #0x98]
   15ef0:      	cmp	x8, x9
   15ef4:      	ldr	x25, [sp, #0x8]
   15ef8:      	b.eq	0x15f30 <generic_fentry_path+0xba80>
   15efc:      	add	x2, x24, #0x18
   15f00:      	mov	w8, #0x4                // =4
   15f04:      	mov	x0, x22
   15f08:      	mov	w1, #0x8                // =8
   15f0c:      	blr	x8
   15f10:      	ldr	x8, [sp, #0x98]
   15f14:      	add	x9, x8, #0x20
   15f18:      	stp	x9, x8, [sp, #0x50]
   15f1c:      	ldr	x25, [sp, #0x8]
   15f20:      	subs	w20, w20, #0x80
   15f24:      	add	x19, sp, #0x70
   15f28:      	b.ne	0xa62c <generic_fentry_path+0x17c>
   15f2c:      	b	0x15f38 <generic_fentry_path+0xba88>
   15f30:      	mov	w8, #0x1                // =1
   15f34:      	strb	w8, [sp, #0x6c]
   15f38:      	ldr	w8, [x25, #0x8]
   15f3c:      	ldp	x10, x20, [sp, #0x10]
   15f40:      	add	w8, w8, #0x1
   15f44:      	str	w8, [x25, #0x8]
   15f48:      	ldr	w9, [sp, #0x60]
   15f4c:      	sub	w9, w9, w10
   15f50:      	str	w9, [x25, #0x4]
   15f54:      	ldrb	w9, [sp, #0x6c]
   15f58:      	cbnz	w9, 0x15f90 <generic_fentry_path+0xbae0>
   15f5c:      	cmp	w8, #0x8
   15f60:      	b.eq	0x15f90 <generic_fentry_path+0xbae0>
   15f64:      	ldp	x8, x9, [sp, #0x48]
   15f68:      	mov	w2, #0x6                // =6
   15f6c:      	str	x8, [x20, #0x6458]
   15f70:      	ldr	x8, [sp, #0x58]
   15f74:      	str	x9, [x20, #0x6460]
   15f78:      	adrp	x9, 0x15000 <generic_fentry_path+0xab50>
   15f7c:      	str	x8, [x20, #0x6468]
   15f80:      	mov	w8, #0xc                // =12
   15f84:      	ldr	x9, [x9]
   15f88:      	ldr	x0, [sp, #0x20]
   15f8c:      	b	0x15fa4 <generic_fentry_path+0xbaf4>
   15f90:      	adrp	x9, 0x15000 <generic_fentry_path+0xab50>
   15f94:      	mov	w2, #0x1                // =1
   15f98:      	mov	w8, #0xc                // =12
   15f9c:      	ldr	x9, [x9]
   15fa0:      	ldr	x0, [sp, #0x20]
   15fa4:      	adrp	x1, 0x15000 <generic_fentry_path+0xab50>
   15fa8:      	ldr	x1, [x1]
   15fac:      	blr	x8
   15fb0:      	b	0x1634c <generic_fentry_path+0xbe9c>
   15fb4:      	str	w23, [sp, #0x98]
   15fb8:      	mov	x3, xzr
   15fbc:      	mov	w8, #0x2                // =2
   15fc0:      	add	x9, sp, #0x30
   15fc4:      	add	x10, sp, #0x98
   15fc8:      	add	x1, sp, #0x30
   15fcc:      	add	x2, sp, #0x98
   15fd0:      	mov	x0, x22
   15fd4:      	blr	x8
   15fd8:      	ldr	x23, [sp, #0x80]
   15fdc:      	mov	w8, #0x8                // =8
   15fe0:      	mov	w9, #0x4                // =4
   15fe4:      	add	x10, sp, #0x30
   15fe8:      	add	x0, sp, #0x30
   15fec:      	mov	w1, #0x8                // =8
   15ff0:      	add	x2, x23, #0x10
   15ff4:      	blr	x9
   15ff8:      	ldr	x8, [sp, #0x30]
   15ffc:      	cbnz	x8, 0x16044 <generic_fentry_path+0xbb94>
   16000:      	add	x2, x23, #0x18
   16004:      	mov	w8, #0x8                // =8
   16008:      	mov	w9, #0x4                // =4
   1600c:      	add	x10, sp, #0x30
   16010:      	add	x0, sp, #0x30
   16014:      	mov	w1, #0x8                // =8
   16018:      	blr	x9
   1601c:      	ldr	x8, [sp, #0x30]
   16020:      	cmp	x8, x23
   16024:      	b.eq	0x16044 <generic_fentry_path+0xbb94>
   16028:      	adrp	x8, 0x16000 <generic_fentry_path+0xbb50>
   1602c:      	add	x8, x8, #0x0
   16030:      	add	x29, x21, #0xff5
   16034:      	ldr	x8, [x8]
   16038:      	str	x8, [x29]
   1603c:      	mov	w8, #0x2964             // =10596
   16040:      	strh	w8, [x29, #0x8]
   16044:      	mov	w8, #0x23               // =35
   16048:      	blr	x8
   1604c:      	add	x2, x0, #0xb30
   16050:      	mov	w8, #0x8                // =8
   16054:      	mov	w9, #0x4                // =4
   16058:      	add	x10, sp, #0x98
   1605c:      	add	x0, sp, #0x98
   16060:      	mov	w1, #0x8                // =8
   16064:      	blr	x9
   16068:      	cbz	x0, 0x160d8 <generic_fentry_path+0xbc28>
   1606c:      	neg	w8, w0
   16070:      	mov	w9, #0x1                // =1
   16074:      	add	x1, sp, #0x30
   16078:      	strh	w8, [sp, #0x30]
   1607c:      	mov	w8, #0x6                // =6
   16080:      	mov	x0, x22
   16084:      	mov	w23, #0x1               // =1
   16088:      	strh	w8, [sp, #0x32]
   1608c:      	mov	x8, #0x33               // =51
   16090:      	movk	x8, #0x4, lsl #32
   16094:      	stur	x8, [sp, #0x34]
   16098:      	add	x8, sp, #0x30
   1609c:      	blr	x9
   160a0:      	cbz	x0, 0x160b4 <generic_fentry_path+0xbc04>
   160a4:      	ldr	w8, [x0]
   160a8:      	add	w8, w8, #0x1
   160ac:      	str	w8, [x0]
   160b0:      	b	0x160d8 <generic_fentry_path+0xbc28>
   160b4:      	str	w23, [sp, #0x78]
   160b8:      	mov	x3, xzr
   160bc:      	mov	w8, #0x2                // =2
   160c0:      	add	x9, sp, #0x30
   160c4:      	add	x10, sp, #0x78
   160c8:      	add	x1, sp, #0x30
   160cc:      	add	x2, sp, #0x78
   160d0:      	mov	x0, x22
   160d4:      	blr	x8
   160d8:      	ldr	x8, [sp, #0x98]
   160dc:      	mov	w9, #0x6448             // =25672
   160e0:      	ldr	x23, [x20, #0x6440]
   160e4:      	mov	w1, #0x8                // =8
   160e8:      	add	x0, x20, x9
   160ec:      	mov	w9, #0x4                // =4
   160f0:      	add	x24, x8, #0x18
   160f4:      	add	x2, x8, #0x20
   160f8:      	mov	w8, #0x8                // =8
   160fc:      	blr	x9
   16100:      	cbz	x0, 0x16170 <generic_fentry_path+0xbcc0>
   16104:      	neg	w8, w0
   16108:      	mov	w9, #0x1                // =1
   1610c:      	add	x1, sp, #0x30
   16110:      	strh	w8, [sp, #0x30]
   16114:      	mov	w8, #0x6                // =6
   16118:      	mov	x0, x22
   1611c:      	mov	w19, #0x1               // =1
   16120:      	strh	w8, [sp, #0x32]
   16124:      	mov	x8, #0x38               // =56
   16128:      	movk	x8, #0x4, lsl #32
   1612c:      	stur	x8, [sp, #0x34]
   16130:      	add	x8, sp, #0x30
   16134:      	blr	x9
   16138:      	cbz	x0, 0x1614c <generic_fentry_path+0xbc9c>
   1613c:      	ldr	w8, [x0]
   16140:      	add	w8, w8, #0x1
   16144:      	str	w8, [x0]
   16148:      	b	0x16170 <generic_fentry_path+0xbcc0>
   1614c:      	str	w19, [sp, #0x78]
   16150:      	mov	x3, xzr
   16154:      	mov	w8, #0x2                // =2
   16158:      	add	x9, sp, #0x30
   1615c:      	add	x10, sp, #0x78
   16160:      	add	x1, sp, #0x30
   16164:      	add	x2, sp, #0x78
   16168:      	mov	x0, x22
   1616c:      	blr	x8
   16170:      	mov	w8, #0x6450             // =25680
   16174:      	mov	w9, #0x4                // =4
   16178:      	mov	w1, #0x8                // =8
   1617c:      	mov	x2, x24
   16180:      	add	x0, x20, x8
   16184:      	mov	w8, #0x8                // =8
   16188:      	blr	x9
   1618c:      	cbz	x0, 0x161fc <generic_fentry_path+0xbd4c>
   16190:      	neg	w8, w0
   16194:      	mov	w9, #0x1                // =1
   16198:      	add	x1, sp, #0x30
   1619c:      	strh	w8, [sp, #0x30]
   161a0:      	mov	w8, #0x6                // =6
   161a4:      	mov	x0, x22
   161a8:      	mov	w19, #0x1               // =1
   161ac:      	strh	w8, [sp, #0x32]
   161b0:      	mov	x8, #0x39               // =57
   161b4:      	movk	x8, #0x4, lsl #32
   161b8:      	stur	x8, [sp, #0x34]
   161bc:      	add	x8, sp, #0x30
   161c0:      	blr	x9
   161c4:      	cbz	x0, 0x161d8 <generic_fentry_path+0xbd28>
   161c8:      	ldr	w8, [x0]
   161cc:      	add	w8, w8, #0x1
   161d0:      	str	w8, [x0]
   161d4:      	b	0x161fc <generic_fentry_path+0xbd4c>
   161d8:      	str	w19, [sp, #0x78]
   161dc:      	mov	x3, xzr
   161e0:      	mov	w8, #0x2                // =2
   161e4:      	add	x9, sp, #0x30
   161e8:      	add	x10, sp, #0x78
   161ec:      	add	x1, sp, #0x30
   161f0:      	add	x2, sp, #0x78
   161f4:      	mov	x0, x22
   161f8:      	blr	x8
   161fc:      	mov	w8, #0x6458             // =25688
   16200:      	add	x2, x23, #0x8
   16204:      	mov	w9, #0x4                // =4
   16208:      	mov	w1, #0x8                // =8
   1620c:      	add	x0, x20, x8
   16210:      	mov	w8, #0x8                // =8
   16214:      	blr	x9
   16218:      	cbz	x0, 0x16288 <generic_fentry_path+0xbdd8>
   1621c:      	neg	w8, w0
   16220:      	mov	w9, #0x1                // =1
   16224:      	add	x1, sp, #0x30
   16228:      	strh	w8, [sp, #0x30]
   1622c:      	mov	w8, #0x6                // =6
   16230:      	mov	x0, x22
   16234:      	mov	w19, #0x1               // =1
   16238:      	strh	w8, [sp, #0x32]
   1623c:      	mov	x8, #0x3a               // =58
   16240:      	movk	x8, #0x4, lsl #32
   16244:      	stur	x8, [sp, #0x34]
   16248:      	add	x8, sp, #0x30
   1624c:      	blr	x9
   16250:      	cbz	x0, 0x16264 <generic_fentry_path+0xbdb4>
   16254:      	ldr	w8, [x0]
   16258:      	add	w8, w8, #0x1
   1625c:      	str	w8, [x0]
   16260:      	b	0x16288 <generic_fentry_path+0xbdd8>
   16264:      	str	w19, [sp, #0x78]
   16268:      	mov	x3, xzr
   1626c:      	mov	w8, #0x2                // =2
   16270:      	add	x9, sp, #0x30
   16274:      	add	x10, sp, #0x78
   16278:      	add	x1, sp, #0x30
   1627c:      	add	x2, sp, #0x78
   16280:      	mov	x0, x22
   16284:      	blr	x8
   16288:      	mov	w8, #0x6460             // =25696
   1628c:      	mov	w9, #0x4                // =4
   16290:      	mov	w1, #0x8                // =8
   16294:      	mov	x2, x23
   16298:      	add	x0, x20, x8
   1629c:      	mov	w8, #0x8                // =8
   162a0:      	blr	x9
   162a4:      	cbz	x0, 0x16314 <generic_fentry_path+0xbe64>
   162a8:      	neg	w8, w0
   162ac:      	mov	w9, #0x1                // =1
   162b0:      	add	x1, sp, #0x30
   162b4:      	strh	w8, [sp, #0x30]
   162b8:      	mov	w8, #0x6                // =6
   162bc:      	mov	x0, x22
   162c0:      	mov	w19, #0x1               // =1
   162c4:      	strh	w8, [sp, #0x32]
   162c8:      	mov	x8, #0x3b               // =59
   162cc:      	movk	x8, #0x4, lsl #32
   162d0:      	stur	x8, [sp, #0x34]
   162d4:      	add	x8, sp, #0x30
   162d8:      	blr	x9
   162dc:      	cbz	x0, 0x162f0 <generic_fentry_path+0xbe40>
   162e0:      	ldr	w8, [x0]
   162e4:      	add	w8, w8, #0x1
   162e8:      	str	w8, [x0]
   162ec:      	b	0x16314 <generic_fentry_path+0xbe64>
   162f0:      	str	w19, [sp, #0x78]
   162f4:      	mov	x3, xzr
   162f8:      	mov	w8, #0x2                // =2
   162fc:      	add	x9, sp, #0x30
   16300:      	add	x10, sp, #0x78
   16304:      	add	x1, sp, #0x30
   16308:      	add	x2, sp, #0x78
   1630c:      	mov	x0, x22
   16310:      	blr	x8
   16314:      	ldr	x8, [x20, #0x6460]
   16318:      	mov	w9, #0x1                // =1
   1631c:      	adrp	x1, 0x16000 <generic_fentry_path+0xbb50>
   16320:      	mov	w2, #0x6                // =6
   16324:      	str	w9, [x25]
   16328:      	mov	w9, #0xc                // =12
   1632c:      	sub	x8, x8, #0x20
   16330:      	str	x8, [x20, #0x6468]
   16334:      	sub	w8, w29, w21
   16338:      	stp	w8, wzr, [x25, #0x4]
   1633c:      	mov	w8, #0x6                // =6
   16340:      	ldr	x1, [x1]
   16344:      	ldr	x0, [sp, #0x20]
   16348:      	blr	x9
   1634c:      	ldp	x20, x19, [sp, #0xd0]
   16350:      	mov	w0, wzr
   16354:      	ldr	x29, [sp, #0x90]
   16358:      	ldp	x22, x21, [sp, #0xc0]
   1635c:      	ldp	x24, x23, [sp, #0xb0]
   16360:      	ldp	x30, x25, [sp, #0xa0]
   16364:      	add	sp, sp, #0xe0
   16368:      	ret

Disassembly of section fentry/generic_fentry:

0000000000000000 <generic_fentry_event>:
       0:      	sub	sp, sp, #0xd0
       4:      	stp	x30, x25, [sp, #0x90]
       8:      	stp	x24, x23, [sp, #0xa0]
       c:      	stp	x22, x21, [sp, #0xb0]
      10:      	stp	x20, x19, [sp, #0xc0]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0xc]
      1c:      	adrp	x0, 0x0 <generic_fentry_event>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0xc
      2c:      	add	x1, sp, #0xc
      30:      	blr	x8
      34:      	cbz	x0, 0x540 <generic_fentry_event+0x540>
      38:      	mov	w8, #0x5ef8             // =24312
      3c:      	mov	x20, x0
      40:      	add	x21, x0, x8
      44:      	adrp	x0, 0x0 <generic_fentry_event>
      48:      	mov	w8, #0x1                // =1
      4c:      	str	wzr, [x21]
      50:      	mov	x1, x21
      54:      	ldr	x0, [x0]
      58:      	blr	x8
      5c:      	cbz	x0, 0x540 <generic_fentry_event+0x540>
      60:      	ldr	w8, [x0, #0x64]
      64:      	str	w8, [sp, #0x1c]
      68:      	cbz	w8, 0x224 <generic_fentry_event+0x224>
      6c:      	adrp	x22, 0x0 <generic_fentry_event>
      70:      	mov	w8, #0x1                // =1
      74:      	add	x9, sp, #0x1c
      78:      	ldr	x22, [x22]
      7c:      	mov	x24, x0
      80:      	add	x1, sp, #0x1c
      84:      	mov	x0, x22
      88:      	blr	x8
      8c:      	cbz	x0, 0x540 <generic_fentry_event+0x540>
      90:      	mov	x23, x0
      94:      	str	wzr, [sp, #0x84]
      98:      	adrp	x0, 0x0 <generic_fentry_event>
      9c:      	mov	w8, #0x1                // =1
      a0:      	ldr	x0, [x0]
      a4:      	add	x9, sp, #0x84
      a8:      	add	x1, sp, #0x84
      ac:      	blr	x8
      b0:      	cbz	x0, 0xdc <generic_fentry_event+0xdc>
      b4:      	ldr	x8, [x0, #0x20]
      b8:      	mov	w9, #0x7270             // =29296
      bc:      	movk	w9, #0x6367, lsl #16
      c0:      	cmp	x8, x9
      c4:      	b.ne	0xe4 <generic_fentry_event+0xe4>
      c8:      	mov	w8, #0x50               // =80
      cc:      	blr	x8
      d0:      	str	x0, [sp, #0x30]
      d4:      	cbnz	x0, 0x1d8 <generic_fentry_event+0x1d8>
      d8:      	b	0x540 <generic_fentry_event+0x540>
      dc:      	mov	w25, wzr
      e0:      	b	0xe8 <generic_fentry_event+0xe8>
      e4:      	ldr	w25, [x0, #0x10]
      e8:      	mov	w8, #0x23               // =35
      ec:      	blr	x8
      f0:      	str	xzr, [sp, #0x88]
      f4:      	add	x2, x0, #0xcd0
      f8:      	mov	w8, #0x8                // =8
      fc:      	mov	w9, #0x71               // =113
     100:      	add	x10, sp, #0x20
     104:      	add	x0, sp, #0x20
     108:      	mov	w1, #0x8                // =8
     10c:      	blr	x9
     110:      	ldr	x8, [sp, #0x20]
     114:      	cbz	x8, 0x540 <generic_fentry_event+0x540>
     118:      	cmp	w25, #0xb
     11c:      	b.hi	0x540 <generic_fentry_event+0x540>
     120:      	ubfiz	x9, x25, #3, #32
     124:      	mov	w10, #0x8               // =8
     128:      	mov	w11, #0x71              // =113
     12c:      	add	x12, sp, #0x38
     130:      	add	x0, sp, #0x38
     134:      	mov	w1, #0x8                // =8
     138:      	add	x8, x8, x9
     13c:      	ldr	x8, [sp, #0x20]
     140:      	add	x2, x8, x9
     144:      	blr	x11
     148:      	ldr	x8, [sp, #0x38]
     14c:      	cbz	x8, 0x540 <generic_fentry_event+0x540>
     150:      	mov	w9, #0x8                // =8
     154:      	mov	w10, #0x71              // =113
     158:      	add	x11, sp, #0x88
     15c:      	ldr	x2, [sp, #0x38]
     160:      	add	x0, sp, #0x88
     164:      	mov	w1, #0x8                // =8
     168:      	blr	x10
     16c:      	ldr	x8, [sp, #0x88]
     170:      	cbz	x8, 0x540 <generic_fentry_event+0x540>
     174:      	str	xzr, [sp, #0x38]
     178:      	add	x2, x8, #0x100
     17c:      	mov	w8, #0x8                // =8
     180:      	mov	w9, #0x71               // =113
     184:      	add	x10, sp, #0x38
     188:      	add	x0, sp, #0x38
     18c:      	mov	w1, #0x8                // =8
     190:      	blr	x9
     194:      	ldr	x8, [sp, #0x38]
     198:      	str	xzr, [sp, #0x38]
     19c:      	cbz	x8, 0x1cc <generic_fentry_event+0x1cc>
     1a0:      	add	x2, x8, #0x60
     1a4:      	mov	w8, #0x8                // =8
     1a8:      	mov	w9, #0x71               // =113
     1ac:      	add	x10, sp, #0x38
     1b0:      	add	x0, sp, #0x38
     1b4:      	mov	w1, #0x8                // =8
     1b8:      	blr	x9
     1bc:      	ldr	x0, [sp, #0x38]
     1c0:      	str	x0, [sp, #0x30]
     1c4:      	cbnz	x0, 0x1d8 <generic_fentry_event+0x1d8>
     1c8:      	b	0x540 <generic_fentry_event+0x540>
     1cc:      	mov	x0, xzr
     1d0:      	str	xzr, [sp, #0x30]
     1d4:      	cbz	xzr, 0x540 <generic_fentry_event+0x540>
     1d8:      	str	x0, [sp, #0x38]
     1dc:      	adrp	x0, 0x0 <generic_fentry_event>
     1e0:      	mov	w8, #0x1                // =1
     1e4:      	add	x9, sp, #0x38
     1e8:      	ldr	x0, [x0]
     1ec:      	add	x1, sp, #0x38
     1f0:      	blr	x8
     1f4:      	cbz	x0, 0x204 <generic_fentry_event+0x204>
     1f8:      	ldr	x8, [x0]
     1fc:      	cbz	x8, 0x204 <generic_fentry_event+0x204>
     200:      	str	x8, [sp, #0x30]
     204:      	mov	w8, #0x1                // =1
     208:      	add	x9, sp, #0x30
     20c:      	add	x1, sp, #0x30
     210:      	mov	x0, x23
     214:      	blr	x8
     218:      	mov	x8, x0
     21c:      	mov	x0, x24
     220:      	cbz	x8, 0x55c <generic_fentry_event+0x55c>
     224:      	ldr	w9, [x0]
     228:      	mov	w8, #0x6420             // =25632
     22c:      	stur	xzr, [x21, #0x4]
     230:      	str	xzr, [x20, #0x5eb8]
     234:      	str	xzr, [x20, #0x5ec0]
     238:      	str	wzr, [x20, x8]
     23c:      	mov	w8, #0x23               // =35
     240:      	str	xzr, [x20, #0x5ec8]
     244:      	str	xzr, [x20, #0x5ed0]
     248:      	str	xzr, [x20, #0x5ed8]
     24c:      	stp	x9, xzr, [x20, #0x60]
     250:      	mov	w9, #0x5eb8             // =24248
     254:      	add	x9, x20, x9
     258:      	strb	wzr, [x9, #0x28]
     25c:      	blr	x8
     260:      	add	x2, x0, #0xb50
     264:      	mov	w25, #0x8               // =8
     268:      	add	x8, sp, #0x88
     26c:      	mov	w9, #0x4                // =4
     270:      	mov	x22, x0
     274:      	add	x0, sp, #0x88
     278:      	mov	w1, #0x8                // =8
     27c:      	add	x23, x20, #0x20
     280:      	mov	w24, #0x4               // =4
     284:      	blr	x9
     288:      	ldr	x8, [sp, #0x88]
     28c:      	mov	w9, #0x48               // =72
     290:      	add	x10, sp, #0x38
     294:      	mov	w11, #0x4               // =4
     298:      	ldr	x2, [sp, #0x88]
     29c:      	add	x0, sp, #0x38
     2a0:      	mov	w1, #0x48               // =72
     2a4:      	blr	x11
     2a8:      	ldr	x8, [sp, #0x40]
     2ac:      	mov	w9, #0x4                // =4
     2b0:      	mov	x0, x23
     2b4:      	mov	w1, #0x4                // =4
     2b8:      	add	x8, x8, #0x218
     2bc:      	ldr	x8, [sp, #0x40]
     2c0:      	add	x2, x8, #0x218
     2c4:      	blr	x9
     2c8:      	ldr	x8, [sp, #0x48]
     2cc:      	add	x0, x20, #0x24
     2d0:      	mov	w9, #0x4                // =4
     2d4:      	mov	w1, #0x4                // =4
     2d8:      	add	x8, x8, #0x4d8
     2dc:      	ldr	x8, [sp, #0x48]
     2e0:      	add	x2, x8, #0x4d8
     2e4:      	blr	x9
     2e8:      	ldr	x8, [sp, #0x50]
     2ec:      	add	x0, x20, #0x28
     2f0:      	mov	w9, #0x4                // =4
     2f4:      	mov	w1, #0x4                // =4
     2f8:      	add	x8, x8, #0x58
     2fc:      	ldr	x8, [sp, #0x50]
     300:      	add	x2, x8, #0x58
     304:      	blr	x9
     308:      	str	xzr, [sp, #0x30]
     30c:      	add	x2, x22, #0x938
     310:      	add	x8, sp, #0x30
     314:      	add	x0, sp, #0x30
     318:      	mov	w1, #0x8                // =8
     31c:      	blr	x24
     320:      	ldr	x8, [sp, #0x30]
     324:      	cbz	x8, 0x3a8 <generic_fentry_event+0x3a8>
     328:      	str	wzr, [sp, #0x10]
     32c:      	add	x8, x8, #0x4
     330:      	add	x9, sp, #0x10
     334:      	mov	w10, #0x4               // =4
     338:      	add	x0, sp, #0x10
     33c:      	mov	w1, #0x4                // =4
     340:      	mov	w23, #0x4               // =4
     344:      	ldr	x8, [sp, #0x30]
     348:      	add	x2, x8, #0x4
     34c:      	blr	x10
     350:      	ldr	x8, [sp, #0x30]
     354:      	ldrsw	x9, [sp, #0x10]
     358:      	add	x10, sp, #0x20
     35c:      	mov	w11, #0x4               // =4
     360:      	add	x0, sp, #0x20
     364:      	mov	w1, #0x10               // =16
     368:      	add	x8, x8, x9, lsl #4
     36c:      	mov	w9, #0x10               // =16
     370:      	add	x8, x8, #0x80
     374:      	ldr	x8, [sp, #0x30]
     378:      	ldrsw	x9, [sp, #0x10]
     37c:      	add	x8, x8, x9, lsl #4
     380:      	add	x2, x8, #0x80
     384:      	blr	x11
     388:      	ldr	x8, [sp, #0x28]
     38c:      	add	x0, x20, #0x2c
     390:      	mov	w1, #0x4                // =4
     394:      	add	x8, x8, #0x158
     398:      	ldr	x8, [sp, #0x28]
     39c:      	add	x2, x8, #0x158
     3a0:      	blr	x23
     3a4:      	b	0x3ac <generic_fentry_event+0x3ac>
     3a8:      	str	wzr, [x20, #0x2c]
     3ac:      	ldr	x8, [sp, #0x58]
     3b0:      	add	x0, x20, #0x30
     3b4:      	mov	w9, #0x4                // =4
     3b8:      	mov	w1, #0x4                // =4
     3bc:      	mov	w24, #0x4               // =4
     3c0:      	add	x8, x8, #0x158
     3c4:      	ldr	x8, [sp, #0x58]
     3c8:      	add	x2, x8, #0x158
     3cc:      	blr	x9
     3d0:      	ldr	x8, [sp, #0x60]
     3d4:      	add	x0, x20, #0x34
     3d8:      	mov	w9, #0x4                // =4
     3dc:      	mov	w1, #0x4                // =4
     3e0:      	add	x8, x8, #0x118
     3e4:      	ldr	x8, [sp, #0x60]
     3e8:      	add	x2, x8, #0x118
     3ec:      	blr	x9
     3f0:      	ldr	x8, [sp, #0x68]
     3f4:      	add	x0, x20, #0x38
     3f8:      	mov	w9, #0x4                // =4
     3fc:      	mov	w1, #0x4                // =4
     400:      	add	x8, x8, #0x98
     404:      	ldr	x8, [sp, #0x68]
     408:      	add	x2, x8, #0x98
     40c:      	blr	x9
     410:      	ldr	x8, [sp, #0x70]
     414:      	add	x0, x20, #0x3c
     418:      	mov	w9, #0x4                // =4
     41c:      	mov	w1, #0x4                // =4
     420:      	add	x8, x8, #0x98
     424:      	ldr	x8, [sp, #0x70]
     428:      	add	x2, x8, #0x98
     42c:      	blr	x9
     430:      	ldr	x8, [sp, #0x78]
     434:      	add	x0, x20, #0x40
     438:      	mov	w9, #0x4                // =4
     43c:      	mov	w1, #0x4                // =4
     440:      	add	x8, x8, #0x58
     444:      	ldr	x8, [sp, #0x78]
     448:      	add	x2, x8, #0x58
     44c:      	blr	x9
     450:      	str	xzr, [sp, #0x20]
     454:      	str	xzr, [sp, #0x30]
     458:      	add	x22, x22, #0xae0
     45c:      	mov	w25, #0x8               // =8
     460:      	add	x8, sp, #0x20
     464:      	mov	w9, #0x4                // =4
     468:      	add	x0, sp, #0x20
     46c:      	mov	w1, #0x8                // =8
     470:      	mov	x2, x22
     474:      	blr	x9
     478:      	ldr	x8, [sp, #0x20]
     47c:      	add	x9, sp, #0x30
     480:      	mov	w10, #0x4               // =4
     484:      	add	x0, sp, #0x30
     488:      	mov	w1, #0x8                // =8
     48c:      	add	x8, x8, #0x90
     490:      	ldr	x8, [sp, #0x20]
     494:      	add	x2, x8, #0x90
     498:      	blr	x10
     49c:      	ldr	x8, [sp, #0x30]
     4a0:      	add	x0, x20, #0x44
     4a4:      	mov	w9, #0x4                // =4
     4a8:      	mov	w1, #0x4                // =4
     4ac:      	add	x8, x8, #0x158
     4b0:      	ldr	x8, [sp, #0x30]
     4b4:      	add	x2, x8, #0x158
     4b8:      	blr	x9
     4bc:      	add	x8, sp, #0x38
     4c0:      	mov	w9, #0x4                // =4
     4c4:      	add	x0, sp, #0x38
     4c8:      	mov	w1, #0x8                // =8
     4cc:      	mov	x2, x22
     4d0:      	add	x23, x20, #0x48
     4d4:      	blr	x9
     4d8:      	ldr	x22, [sp, #0x38]
     4dc:      	add	x0, x20, #0x50
     4e0:      	mov	w8, #0x4                // =4
     4e4:      	mov	w1, #0x8                // =8
     4e8:      	add	x2, x22, #0x40
     4ec:      	blr	x8
     4f0:      	add	x0, x20, #0x58
     4f4:      	add	x2, x22, #0x30
     4f8:      	mov	w8, #0x4                // =4
     4fc:      	mov	w1, #0x8                // =8
     500:      	blr	x8
     504:      	add	x2, x22, #0x38
     508:      	mov	x0, x23
     50c:      	mov	w1, #0x8                // =8
     510:      	blr	x24
     514:      	strb	wzr, [x21, #0x10]
     518:      	strb	wzr, [x20, #0x1]
     51c:      	adrp	x1, 0x0 <generic_fentry_event>
     520:      	mov	w8, #0x2                // =2
     524:      	mov	w9, #0xc                // =12
     528:      	mov	x0, x19
     52c:      	str	xzr, [x20, #0x5ee8]
     530:      	str	xzr, [x20, #0x5ef0]
     534:      	ldr	x1, [x1]
     538:      	mov	w2, #0x2                // =2
     53c:      	blr	x9
     540:      	ldp	x20, x19, [sp, #0xc0]
     544:      	mov	w0, wzr
     548:      	ldp	x22, x21, [sp, #0xb0]
     54c:      	ldp	x24, x23, [sp, #0xa0]
     550:      	ldp	x30, x25, [sp, #0x90]
     554:      	add	sp, sp, #0xd0
     558:      	ret
     55c:      	mov	x8, #-0x1               // =-1
     560:      	mov	w9, #0x1                // =1
     564:      	add	x1, sp, #0x10
     568:      	str	x8, [sp, #0x10]
     56c:      	add	x8, sp, #0x10
     570:      	mov	x0, x23
     574:      	mov	w25, #0x1               // =1
     578:      	blr	x9
     57c:      	cbz	x0, 0x540 <generic_fentry_event+0x540>
     580:      	str	w25, [sp, #0x1c]
     584:      	add	x8, sp, #0x1c
     588:      	add	x1, sp, #0x1c
     58c:      	mov	x0, x22
     590:      	blr	x25
     594:      	cbz	x0, 0x540 <generic_fentry_event+0x540>
     598:      	mov	w8, #0x1                // =1
     59c:      	add	x9, sp, #0x30
     5a0:      	add	x1, sp, #0x30
     5a4:      	blr	x8
     5a8:      	mov	x8, x0
     5ac:      	mov	x0, x24
     5b0:      	cbnz	x8, 0x540 <generic_fentry_event+0x540>
     5b4:      	b	0x224 <generic_fentry_event+0x224>
