
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_execve_map_update_v511.native.o:	file format elf64-littleaarch64

Disassembly of section socket:

0000000000000000 <execve_map_update>:
       0:      	sub	sp, sp, #0x40
       4:      	stp	x30, x23, [sp, #0x10]
       8:      	stp	x22, x21, [sp, #0x20]
       c:      	stp	x20, x19, [sp, #0x30]
      10:      	str	wzr, [sp, #0x4]
      14:      	adrp	x0, 0x0 <execve_map_update>
      18:      	mov	w8, #0x1                // =1
      1c:      	add	x9, sp, #0x4
      20:      	ldr	x0, [x0]
      24:      	add	x1, sp, #0x4
      28:      	blr	x8
      2c:      	cbz	x0, 0xb8 <execve_map_update+0xb8>
      30:      	adrp	x8, 0x0 <execve_map_update>
      34:      	mov	x19, x0
      38:      	ldr	x8, [x8]
      3c:      	ldrb	w8, [x8]
      40:      	cbz	w8, 0xd0 <execve_map_update+0xd0>
      44:      	adrp	x20, 0x0 <execve_map_update>
      48:      	mov	x21, xzr
      4c:      	mov	w22, #0x1               // =1
      50:      	ldr	x20, [x20]
      54:      	add	x23, sp, #0x8
      58:      	b	0x6c <execve_map_update+0x6c>
      5c:      	nop
      60:      	add	x21, x21, #0x1
      64:      	cmp	x21, #0x8, lsl #12      // =0x8000
      68:      	b.eq	0x140 <execve_map_update+0x140>
      6c:      	ldr	w8, [x19, #0x4]
      70:      	cmp	x21, x8
      74:      	b.eq	0x140 <execve_map_update+0x140>
      78:      	add	x8, x19, x21, lsl #2
      7c:      	add	x1, sp, #0x8
      80:      	mov	x0, x20
      84:      	ldr	w8, [x8, #0x8]
      88:      	str	w8, [sp, #0x8]
      8c:      	mov	w8, #0x1                // =1
      90:      	blr	x8
      94:      	cbz	x0, 0x60 <execve_map_update+0x60>
      98:      	ldr	w8, [x19]
      9c:      	ldr	x9, [x0, #0x370]
      a0:      	lsl	w8, w22, w8
      a4:      	mvn	w8, w8
      a8:      	sxtw	x8, w8
      ac:      	and	x8, x9, x8
      b0:      	str	x8, [x0, #0x370]
      b4:      	b	0x60 <execve_map_update+0x60>
      b8:      	mov	w0, #-0x1               // =-1
      bc:      	ldp	x20, x19, [sp, #0x30]
      c0:      	ldp	x22, x21, [sp, #0x20]
      c4:      	ldp	x30, x23, [sp, #0x10]
      c8:      	add	sp, sp, #0x40
      cc:      	ret
      d0:      	adrp	x20, 0x0 <execve_map_update>
      d4:      	mov	x21, xzr
      d8:      	mov	w22, #0x1               // =1
      dc:      	ldr	x20, [x20]
      e0:      	add	x23, sp, #0xc
      e4:      	b	0xf4 <execve_map_update+0xf4>
      e8:      	add	x21, x21, #0x1
      ec:      	cmp	x21, #0x400
      f0:      	b.eq	0x140 <execve_map_update+0x140>
      f4:      	ldr	w8, [x19, #0x4]
      f8:      	cmp	x21, x8
      fc:      	b.eq	0x140 <execve_map_update+0x140>
     100:      	add	x8, x19, x21, lsl #2
     104:      	add	x1, sp, #0xc
     108:      	mov	x0, x20
     10c:      	ldr	w8, [x8, #0x8]
     110:      	str	w8, [sp, #0xc]
     114:      	mov	w8, #0x1                // =1
     118:      	blr	x8
     11c:      	cbz	x0, 0xe8 <execve_map_update+0xe8>
     120:      	ldr	w8, [x19]
     124:      	ldr	x9, [x0, #0x370]
     128:      	lsl	w8, w22, w8
     12c:      	mvn	w8, w8
     130:      	sxtw	x8, w8
     134:      	and	x8, x9, x8
     138:      	str	x8, [x0, #0x370]
     13c:      	b	0xe8 <execve_map_update+0xe8>
     140:      	mov	w0, wzr
     144:      	ldp	x20, x19, [sp, #0x30]
     148:      	ldp	x22, x21, [sp, #0x20]
     14c:      	ldp	x30, x23, [sp, #0x10]
     150:      	add	sp, sp, #0x40
     154:      	ret
