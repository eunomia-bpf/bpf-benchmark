
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_usdt_v61.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <extract_arg_depth>:
       0:      	cmp	w0, #0x9
       4:      	b.ls	0x10 <extract_arg_depth+0x10>
       8:      	mov	w0, #0x1                // =1
       c:      	ret
      10:      	str	x30, [sp, #-0x20]!
      14:      	stp	x20, x19, [sp, #0x10]
      18:      	ldr	x8, [x1]
      1c:      	add	x9, x8, w0, uxtw #3
      20:      	ldrh	w9, [x9, #0x6]
      24:      	cbz	w9, 0xb4 <extract_arg_depth+0xb4>
      28:      	mov	w9, w0
      2c:      	add	x10, x8, x9, lsl #3
      30:      	ldr	x8, [x1, #0x8]
      34:      	ldr	w11, [x10]
      38:      	ldrh	w10, [x10, #0x4]
      3c:      	ldr	x9, [x8]
      40:      	add	x9, x9, x11
      44:      	str	x9, [x8]
      48:      	cbz	w10, 0x78 <extract_arg_depth+0x78>
      4c:      	ldrb	w10, [x1, #0x10]
      50:      	mov	w19, w0
      54:      	cbz	w10, 0x88 <extract_arg_depth+0x88>
      58:      	mov	w10, #0x8               // =8
      5c:      	mov	w11, #0x94              // =148
      60:      	ldr	x0, [x1, #0x8]
      64:      	mov	x20, x1
      68:      	mov	w1, #0x8                // =8
      6c:      	ldr	x2, [x0]
      70:      	blr	x11
      74:      	tbnz	w0, #0x1f, 0xa8 <extract_arg_depth+0xa8>
      78:      	mov	w0, wzr
      7c:      	ldp	x20, x19, [sp, #0x10]
      80:      	ldr	x30, [sp], #0x20
      84:      	ret
      88:      	mov	w10, #0x8               // =8
      8c:      	mov	w11, #0x4               // =4
      90:      	ldr	x0, [x1, #0x8]
      94:      	mov	x20, x1
      98:      	mov	w1, #0x8                // =8
      9c:      	ldr	x2, [x0]
      a0:      	blr	x11
      a4:      	tbz	w0, #0x1f, 0x78 <extract_arg_depth+0x78>
      a8:      	ldr	x9, [x20, #0x18]
      ac:      	add	w8, w19, #0x1
      b0:      	str	w8, [x9]
      b4:      	mov	w0, #0x1                // =1
      b8:      	ldp	x20, x19, [sp, #0x10]
      bc:      	ldr	x30, [sp], #0x20
      c0:      	ret
      c4:      	nop
      c8:      	nop
      cc:      	nop

00000000000000d0 <do_bytes>:
      d0:      	sub	sp, sp, #0x40
      d4:      	stp	x30, x23, [sp, #0x10]
      d8:      	stp	x22, x21, [sp, #0x20]
      dc:      	stp	x20, x19, [sp, #0x30]
      e0:      	mov	x19, x3
      e4:      	mov	x21, x2
      e8:      	mov	x20, x1
      ec:      	mov	x22, x0
      f0:      	bl	0x310 <__do_bytes>
      f4:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
      f8:      	and	x23, x0, #0x7fffffff
      fc:      	subs	x3, x19, x23
     100:      	b.eq	0x2f8 <do_bytes+0x228>
     104:      	add	x2, x23, x21
     108:      	mov	x0, x22
     10c:      	mov	x1, x20
     110:      	bl	0x310 <__do_bytes>
     114:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     118:      	and	x8, x0, #0x7fffffff
     11c:      	add	x23, x8, x23
     120:      	subs	x3, x19, x23
     124:      	b.eq	0x2f8 <do_bytes+0x228>
     128:      	add	x2, x23, x21
     12c:      	mov	x0, x22
     130:      	mov	x1, x20
     134:      	bl	0x310 <__do_bytes>
     138:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     13c:      	and	x8, x0, #0x7fffffff
     140:      	add	x23, x8, x23
     144:      	subs	x3, x19, x23
     148:      	b.eq	0x2f8 <do_bytes+0x228>
     14c:      	add	x2, x23, x21
     150:      	mov	x0, x22
     154:      	mov	x1, x20
     158:      	bl	0x310 <__do_bytes>
     15c:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     160:      	and	x8, x0, #0x7fffffff
     164:      	add	x23, x8, x23
     168:      	subs	x3, x19, x23
     16c:      	b.eq	0x2f8 <do_bytes+0x228>
     170:      	add	x2, x23, x21
     174:      	mov	x0, x22
     178:      	mov	x1, x20
     17c:      	bl	0x310 <__do_bytes>
     180:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     184:      	and	x8, x0, #0x7fffffff
     188:      	add	x23, x8, x23
     18c:      	subs	x3, x19, x23
     190:      	b.eq	0x2f8 <do_bytes+0x228>
     194:      	add	x2, x23, x21
     198:      	mov	x0, x22
     19c:      	mov	x1, x20
     1a0:      	bl	0x310 <__do_bytes>
     1a4:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     1a8:      	and	x8, x0, #0x7fffffff
     1ac:      	add	x23, x8, x23
     1b0:      	subs	x3, x19, x23
     1b4:      	b.eq	0x2f8 <do_bytes+0x228>
     1b8:      	add	x2, x23, x21
     1bc:      	mov	x0, x22
     1c0:      	mov	x1, x20
     1c4:      	bl	0x310 <__do_bytes>
     1c8:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     1cc:      	and	x8, x0, #0x7fffffff
     1d0:      	add	x23, x8, x23
     1d4:      	subs	x3, x19, x23
     1d8:      	b.eq	0x2f8 <do_bytes+0x228>
     1dc:      	add	x2, x23, x21
     1e0:      	mov	x0, x22
     1e4:      	mov	x1, x20
     1e8:      	bl	0x310 <__do_bytes>
     1ec:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     1f0:      	and	x8, x0, #0x7fffffff
     1f4:      	add	x23, x8, x23
     1f8:      	subs	x3, x19, x23
     1fc:      	b.eq	0x2f8 <do_bytes+0x228>
     200:      	add	x2, x23, x21
     204:      	mov	x0, x22
     208:      	mov	x1, x20
     20c:      	bl	0x310 <__do_bytes>
     210:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     214:      	and	x8, x0, #0x7fffffff
     218:      	add	x23, x8, x23
     21c:      	subs	x3, x19, x23
     220:      	b.eq	0x2f8 <do_bytes+0x228>
     224:      	add	x2, x23, x21
     228:      	mov	x0, x22
     22c:      	mov	x1, x20
     230:      	bl	0x310 <__do_bytes>
     234:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     238:      	and	x8, x0, #0x7fffffff
     23c:      	add	x19, x8, x23
     240:      	mov	x0, x19
     244:      	ldp	x20, x19, [sp, #0x30]
     248:      	ldp	x22, x21, [sp, #0x20]
     24c:      	ldp	x30, x23, [sp, #0x10]
     250:      	add	sp, sp, #0x40
     254:      	ret
     258:      	sxtw	x19, w0
     25c:      	str	wzr, [sp, #0xc]
     260:      	adrp	x0, 0x0 <extract_arg_depth>
     264:      	mov	w8, #0x1                // =1
     268:      	ldr	x0, [x0]
     26c:      	add	x9, sp, #0xc
     270:      	add	x1, sp, #0xc
     274:      	blr	x8
     278:      	cbz	x0, 0x2f8 <do_bytes+0x228>
     27c:      	cmn	x19, #0xc
     280:      	b.gt	0x2a4 <do_bytes+0x1d4>
     284:      	cmn	x19, #0x1c
     288:      	b.eq	0x2c4 <do_bytes+0x1f4>
     28c:      	cmn	x19, #0x16
     290:      	b.eq	0x2dc <do_bytes+0x20c>
     294:      	cmn	x19, #0x10
     298:      	b.ne	0x2d4 <do_bytes+0x204>
     29c:      	add	x8, x0, #0x558
     2a0:      	b	0x2e8 <do_bytes+0x218>
     2a4:      	cmn	x19, #0xb
     2a8:      	b.eq	0x2cc <do_bytes+0x1fc>
     2ac:      	cmn	x19, #0x7
     2b0:      	b.eq	0x2e4 <do_bytes+0x214>
     2b4:      	cmn	x19, #0x2
     2b8:      	b.ne	0x2d4 <do_bytes+0x204>
     2bc:      	add	x8, x0, #0x548
     2c0:      	b	0x2e8 <do_bytes+0x218>
     2c4:      	add	x8, x0, #0x568
     2c8:      	b	0x2e8 <do_bytes+0x218>
     2cc:      	add	x8, x0, #0x570
     2d0:      	b	0x2e8 <do_bytes+0x218>
     2d4:      	add	x8, x0, #0x540
     2d8:      	b	0x2e8 <do_bytes+0x218>
     2dc:      	add	x8, x0, #0x560
     2e0:      	b	0x2e8 <do_bytes+0x218>
     2e4:      	add	x8, x0, #0x550
     2e8:      	ldaxr	x9, [x8]
     2ec:      	add	x9, x9, #0x1
     2f0:      	stlxr	w10, x9, [x8]
     2f4:      	cbnz	w10, 0x2e8 <do_bytes+0x218>
     2f8:      	mov	x0, x19
     2fc:      	ldp	x20, x19, [sp, #0x30]
     300:      	ldp	x22, x21, [sp, #0x20]
     304:      	ldp	x30, x23, [sp, #0x10]
     308:      	add	sp, sp, #0x40
     30c:      	ret

0000000000000310 <__do_bytes>:
     310:      	str	x30, [sp, #-0x30]!
     314:      	stp	x22, x21, [sp, #0x10]
     318:      	stp	x20, x19, [sp, #0x20]
     31c:      	tbnz	x3, #0x3f, 0x3b4 <__do_bytes+0xa4>
     320:      	mov	w8, #0x7fe0             // =32736
     324:      	mov	x22, x0
     328:      	add	x0, x1, #0x20
     32c:      	mov	x20, x1
     330:      	cmp	x3, x8
     334:      	csel	x19, x3, x8, lo
     338:      	mov	w8, #0x4                // =4
     33c:      	mov	w1, w19
     340:      	blr	x8
     344:      	tbnz	w0, #0x1f, 0x3ec <__do_bytes+0xdc>
     348:      	add	w21, w19, #0x20
     34c:      	str	wzr, [sp, #0xc]
     350:      	adrp	x0, 0x0 <extract_arg_depth>
     354:      	mov	w8, #0x1                // =1
     358:      	str	w21, [x20, #0x4]
     35c:      	add	x9, sp, #0xc
     360:      	add	x1, sp, #0xc
     364:      	ldr	x0, [x0]
     368:      	blr	x8
     36c:      	cbz	x0, 0x3cc <__do_bytes+0xbc>
     370:      	ldrb	w8, [x0, #0x28]
     374:      	cbz	w8, 0x3cc <__do_bytes+0xbc>
     378:      	adrp	x1, 0x0 <extract_arg_depth>
     37c:      	mov	w8, #-0x1               // =-1
     380:      	mov	w9, #0x19               // =25
     384:      	ldr	x1, [x1]
     388:      	mov	x0, x22
     38c:      	mov	w2, #-0x1               // =-1
     390:      	mov	x3, x20
     394:      	mov	x4, x21
     398:      	blr	x9
     39c:      	tbnz	w0, #0x1f, 0x3ec <__do_bytes+0xdc>
     3a0:      	mov	x0, x19
     3a4:      	ldp	x20, x19, [sp, #0x20]
     3a8:      	ldp	x22, x21, [sp, #0x10]
     3ac:      	ldr	x30, [sp], #0x30
     3b0:      	ret
     3b4:      	mov	x19, #-0x1              // =-1
     3b8:      	mov	x0, x19
     3bc:      	ldp	x20, x19, [sp, #0x20]
     3c0:      	ldp	x22, x21, [sp, #0x10]
     3c4:      	ldr	x30, [sp], #0x30
     3c8:      	ret
     3cc:      	adrp	x0, 0x0 <extract_arg_depth>
     3d0:      	mov	x3, xzr
     3d4:      	mov	w8, #0x82               // =130
     3d8:      	ldr	x0, [x0]
     3dc:      	mov	x1, x20
     3e0:      	mov	x2, x21
     3e4:      	blr	x8
     3e8:      	tbz	w0, #0x1f, 0x3a0 <__do_bytes+0x90>
     3ec:      	sxtw	x19, w0
     3f0:      	mov	x0, x19
     3f4:      	ldp	x20, x19, [sp, #0x20]
     3f8:      	ldp	x22, x21, [sp, #0x10]
     3fc:      	ldr	x30, [sp], #0x30
     400:      	ret
     404:      	nop
     408:      	nop
     40c:      	nop

0000000000000410 <filter_64ty>:
     410:      	str	x30, [sp, #-0x10]!
     414:      	mov	x8, x0
     418:      	mov	x0, xzr
     41c:      	ldr	w9, [x8, #0x4]
     420:      	cmp	w9, #0x20
     424:      	b.hi	0x484 <filter_64ty+0x74>
     428:      	mov	w10, #0x1               // =1
     42c:      	mov	w11, #0x101e            // =4126
     430:      	lsl	x10, x10, x9
     434:      	tst	x10, x11
     438:      	b.eq	0x44c <filter_64ty+0x3c>
     43c:      	mov	x0, x8
     440:      	bl	0x610 <filter_64ty_selector_val>
     444:      	ldr	x30, [sp], #0x10
     448:      	ret
     44c:      	mov	w10, #0x1               // =1
     450:      	lsl	x10, x10, x9
     454:      	tst	x10, #0xc00
     458:      	b.ne	0x47c <filter_64ty+0x6c>
     45c:      	mov	w10, #0x1               // =1
     460:      	lsl	x9, x10, x9
     464:      	tst	x9, #0x180000000
     468:      	b.eq	0x484 <filter_64ty+0x74>
     46c:      	mov	x0, x8
     470:      	bl	0xa10 <filter_64ty_range>
     474:      	ldr	x30, [sp], #0x10
     478:      	ret
     47c:      	mov	x0, x8
     480:      	bl	0x970 <filter_64ty_map>
     484:      	ldr	x30, [sp], #0x10
     488:      	ret
     48c:      	nop

0000000000000490 <filter_32ty>:
     490:      	str	x30, [sp, #-0x10]!
     494:      	mov	x8, x0
     498:      	mov	x0, xzr
     49c:      	ldr	w9, [x8, #0x4]
     4a0:      	cmp	w9, #0x20
     4a4:      	b.hi	0x504 <filter_32ty+0x74>
     4a8:      	mov	w10, #0x1               // =1
     4ac:      	mov	w11, #0x101e            // =4126
     4b0:      	lsl	x10, x10, x9
     4b4:      	tst	x10, x11
     4b8:      	b.eq	0x4cc <filter_32ty+0x3c>
     4bc:      	mov	x0, x8
     4c0:      	bl	0xc60 <filter_32ty_selector_val>
     4c4:      	ldr	x30, [sp], #0x10
     4c8:      	ret
     4cc:      	mov	w10, #0x1               // =1
     4d0:      	lsl	x10, x10, x9
     4d4:      	tst	x10, #0xc00
     4d8:      	b.ne	0x4fc <filter_32ty+0x6c>
     4dc:      	mov	w10, #0x1               // =1
     4e0:      	lsl	x9, x10, x9
     4e4:      	tst	x9, #0x180000000
     4e8:      	b.eq	0x504 <filter_32ty+0x74>
     4ec:      	mov	x0, x8
     4f0:      	bl	0x1080 <filter_32ty_range>
     4f4:      	ldr	x30, [sp], #0x10
     4f8:      	ret
     4fc:      	mov	x0, x8
     500:      	bl	0xfc0 <filter_32ty_map>
     504:      	ldr	x30, [sp], #0x10
     508:      	ret
     50c:      	nop

0000000000000510 <filter_16ty>:
     510:      	str	x30, [sp, #-0x10]!
     514:      	mov	x8, x0
     518:      	mov	x0, xzr
     51c:      	ldr	w9, [x8, #0x4]
     520:      	cmp	w9, #0x20
     524:      	b.hi	0x584 <filter_16ty+0x74>
     528:      	mov	w10, #0x1               // =1
     52c:      	mov	w11, #0x101e            // =4126
     530:      	lsl	x10, x10, x9
     534:      	tst	x10, x11
     538:      	b.eq	0x54c <filter_16ty+0x3c>
     53c:      	mov	x0, x8
     540:      	bl	0x12d0 <filter_16ty_selector_val>
     544:      	ldr	x30, [sp], #0x10
     548:      	ret
     54c:      	mov	w10, #0x1               // =1
     550:      	lsl	x10, x10, x9
     554:      	tst	x10, #0xc00
     558:      	b.ne	0x57c <filter_16ty+0x6c>
     55c:      	mov	w10, #0x1               // =1
     560:      	lsl	x9, x10, x9
     564:      	tst	x9, #0x180000000
     568:      	b.eq	0x584 <filter_16ty+0x74>
     56c:      	mov	x0, x8
     570:      	bl	0x16f0 <filter_16ty_range>
     574:      	ldr	x30, [sp], #0x10
     578:      	ret
     57c:      	mov	x0, x8
     580:      	bl	0x1630 <filter_16ty_map>
     584:      	ldr	x30, [sp], #0x10
     588:      	ret
     58c:      	nop

0000000000000590 <filter_8ty>:
     590:      	str	x30, [sp, #-0x10]!
     594:      	mov	x8, x0
     598:      	mov	x0, xzr
     59c:      	ldr	w9, [x8, #0x4]
     5a0:      	cmp	w9, #0x20
     5a4:      	b.hi	0x604 <filter_8ty+0x74>
     5a8:      	mov	w10, #0x1               // =1
     5ac:      	mov	w11, #0x101e            // =4126
     5b0:      	lsl	x10, x10, x9
     5b4:      	tst	x10, x11
     5b8:      	b.eq	0x5cc <filter_8ty+0x3c>
     5bc:      	mov	x0, x8
     5c0:      	bl	0x1940 <filter_8ty_selector_val>
     5c4:      	ldr	x30, [sp], #0x10
     5c8:      	ret
     5cc:      	mov	w10, #0x1               // =1
     5d0:      	lsl	x10, x10, x9
     5d4:      	tst	x10, #0xc00
     5d8:      	b.ne	0x5fc <filter_8ty+0x6c>
     5dc:      	mov	w10, #0x1               // =1
     5e0:      	lsl	x9, x10, x9
     5e4:      	tst	x9, #0x180000000
     5e8:      	b.eq	0x604 <filter_8ty+0x74>
     5ec:      	mov	x0, x8
     5f0:      	bl	0x1d60 <filter_8ty_range>
     5f4:      	ldr	x30, [sp], #0x10
     5f8:      	ret
     5fc:      	mov	x0, x8
     600:      	bl	0x1ca0 <filter_8ty_map>
     604:      	ldr	x30, [sp], #0x10
     608:      	ret
     60c:      	nop

0000000000000610 <filter_64ty_selector_val>:
     610:      	ldr	w8, [x0, #0x4]
     614:      	cmp	w8, #0x25
     618:      	b.hi	0x68c <filter_64ty_selector_val+0x7c>
     61c:      	mov	x10, #0x40              // =64
     620:      	mov	w9, #0x1                // =1
     624:      	movk	x10, #0xc00, lsl #16
     628:      	lsl	x9, x9, x8
     62c:      	movk	x10, #0x20, lsl #32
     630:      	tst	x9, x10
     634:      	b.eq	0x640 <filter_64ty_selector_val+0x30>
     638:      	mov	w0, #0x1                // =1
     63c:      	ret
     640:      	mov	w9, #0x1                // =1
     644:      	lsl	x9, x9, x8
     648:      	tst	x9, #0x18
     64c:      	b.eq	0x66c <filter_64ty_selector_val+0x5c>
     650:      	ldr	x9, [x1]
     654:      	ldr	x10, [x0, #0x10]
     658:      	cmp	x9, x10
     65c:      	b.ne	0x70c <filter_64ty_selector_val+0xfc>
     660:      	cmp	w8, #0x3
     664:      	cset	w0, eq
     668:      	ret
     66c:      	cmp	x8, #0xc
     670:      	b.ne	0x68c <filter_64ty_selector_val+0x7c>
     674:      	ldr	x8, [x1]
     678:      	ldr	x9, [x0, #0x10]
     67c:      	tst	x8, x9
     680:      	b.eq	0x7b8 <filter_64ty_selector_val+0x1a8>
     684:      	mov	w0, #0x1                // =1
     688:      	ret
     68c:      	cmp	w8, #0x1
     690:      	b.eq	0x6d4 <filter_64ty_selector_val+0xc4>
     694:      	cmp	w8, #0x2
     698:      	b.ne	0x960 <filter_64ty_selector_val+0x350>
     69c:      	ldr	w8, [x0, #0xc]
     6a0:      	cmp	w8, #0xc
     6a4:      	b.hi	0x7f0 <filter_64ty_selector_val+0x1e0>
     6a8:      	mov	w9, #0x1                // =1
     6ac:      	lsl	w8, w9, w8
     6b0:      	mov	w9, #0x1402             // =5122
     6b4:      	tst	w8, w9
     6b8:      	b.eq	0x7f0 <filter_64ty_selector_val+0x1e0>
     6bc:      	ldr	x8, [x1]
     6c0:      	ldr	x9, [x0, #0x10]
     6c4:      	cmp	x8, x9
     6c8:      	b.ge	0x798 <filter_64ty_selector_val+0x188>
     6cc:      	mov	w0, #0x1                // =1
     6d0:      	ret
     6d4:      	ldr	w8, [x0, #0xc]
     6d8:      	cmp	w8, #0xc
     6dc:      	b.hi	0x7d8 <filter_64ty_selector_val+0x1c8>
     6e0:      	mov	w9, #0x1                // =1
     6e4:      	lsl	w8, w9, w8
     6e8:      	mov	w9, #0x1402             // =5122
     6ec:      	tst	w8, w9
     6f0:      	b.eq	0x7d8 <filter_64ty_selector_val+0x1c8>
     6f4:      	ldr	x8, [x1]
     6f8:      	ldr	x9, [x0, #0x10]
     6fc:      	cmp	x8, x9
     700:      	b.le	0x778 <filter_64ty_selector_val+0x168>
     704:      	mov	w0, #0x1                // =1
     708:      	ret
     70c:      	ldr	w10, [x0, #0x8]
     710:      	cmp	w10, #0x11
     714:      	b.lo	0x74c <filter_64ty_selector_val+0x13c>
     718:      	ldr	x11, [x0, #0x18]
     71c:      	cmp	x9, x11
     720:      	b.eq	0x660 <filter_64ty_selector_val+0x50>
     724:      	cmp	w10, #0x19
     728:      	b.lo	0x74c <filter_64ty_selector_val+0x13c>
     72c:      	ldr	x11, [x0, #0x20]
     730:      	cmp	x9, x11
     734:      	b.eq	0x660 <filter_64ty_selector_val+0x50>
     738:      	cmp	w10, #0x21
     73c:      	b.lo	0x74c <filter_64ty_selector_val+0x13c>
     740:      	ldr	x10, [x0, #0x28]
     744:      	cmp	x9, x10
     748:      	b.eq	0x660 <filter_64ty_selector_val+0x50>
     74c:      	cmp	w8, #0x25
     750:      	b.hi	0x960 <filter_64ty_selector_val+0x350>
     754:      	mov	w9, #0x1                // =1
     758:      	lsl	x8, x9, x8
     75c:      	mov	x9, #0x50               // =80
     760:      	movk	x9, #0xc00, lsl #16
     764:      	movk	x9, #0x20, lsl #32
     768:      	tst	x8, x9
     76c:      	b.eq	0x960 <filter_64ty_selector_val+0x350>
     770:      	mov	w0, #0x1                // =1
     774:      	ret
     778:      	ldr	w9, [x0, #0x8]
     77c:      	cmp	w9, #0x11
     780:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     784:      	ldr	x10, [x0, #0x18]
     788:      	cmp	x8, x10
     78c:      	b.le	0x848 <filter_64ty_selector_val+0x238>
     790:      	mov	w0, #0x1                // =1
     794:      	ret
     798:      	ldr	w9, [x0, #0x8]
     79c:      	cmp	w9, #0x11
     7a0:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     7a4:      	ldr	x10, [x0, #0x18]
     7a8:      	cmp	x8, x10
     7ac:      	b.ge	0x864 <filter_64ty_selector_val+0x254>
     7b0:      	mov	w0, #0x1                // =1
     7b4:      	ret
     7b8:      	ldr	w9, [x0, #0x8]
     7bc:      	cmp	w9, #0x11
     7c0:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     7c4:      	ldr	x10, [x0, #0x18]
     7c8:      	tst	x8, x10
     7cc:      	b.eq	0x880 <filter_64ty_selector_val+0x270>
     7d0:      	mov	w0, #0x1                // =1
     7d4:      	ret
     7d8:      	ldr	x8, [x1]
     7dc:      	ldr	x9, [x0, #0x10]
     7e0:      	cmp	x8, x9
     7e4:      	b.ls	0x808 <filter_64ty_selector_val+0x1f8>
     7e8:      	mov	w0, #0x1                // =1
     7ec:      	ret
     7f0:      	ldr	x8, [x1]
     7f4:      	ldr	x9, [x0, #0x10]
     7f8:      	cmp	x8, x9
     7fc:      	b.hs	0x828 <filter_64ty_selector_val+0x218>
     800:      	mov	w0, #0x1                // =1
     804:      	ret
     808:      	ldr	w9, [x0, #0x8]
     80c:      	cmp	w9, #0x11
     810:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     814:      	ldr	x10, [x0, #0x18]
     818:      	cmp	x8, x10
     81c:      	b.ls	0x89c <filter_64ty_selector_val+0x28c>
     820:      	mov	w0, #0x1                // =1
     824:      	ret
     828:      	ldr	w9, [x0, #0x8]
     82c:      	cmp	w9, #0x11
     830:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     834:      	ldr	x10, [x0, #0x18]
     838:      	cmp	x8, x10
     83c:      	b.hs	0x8b8 <filter_64ty_selector_val+0x2a8>
     840:      	mov	w0, #0x1                // =1
     844:      	ret
     848:      	cmp	w9, #0x19
     84c:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     850:      	ldr	x10, [x0, #0x20]
     854:      	cmp	x8, x10
     858:      	b.le	0x8d4 <filter_64ty_selector_val+0x2c4>
     85c:      	mov	w0, #0x1                // =1
     860:      	ret
     864:      	cmp	w9, #0x19
     868:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     86c:      	ldr	x10, [x0, #0x20]
     870:      	cmp	x8, x10
     874:      	b.ge	0x8f0 <filter_64ty_selector_val+0x2e0>
     878:      	mov	w0, #0x1                // =1
     87c:      	ret
     880:      	cmp	w9, #0x19
     884:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     888:      	ldr	x10, [x0, #0x20]
     88c:      	tst	x8, x10
     890:      	b.eq	0x90c <filter_64ty_selector_val+0x2fc>
     894:      	mov	w0, #0x1                // =1
     898:      	ret
     89c:      	cmp	w9, #0x19
     8a0:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     8a4:      	ldr	x10, [x0, #0x20]
     8a8:      	cmp	x8, x10
     8ac:      	b.ls	0x928 <filter_64ty_selector_val+0x318>
     8b0:      	mov	w0, #0x1                // =1
     8b4:      	ret
     8b8:      	cmp	w9, #0x19
     8bc:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     8c0:      	ldr	x10, [x0, #0x20]
     8c4:      	cmp	x8, x10
     8c8:      	b.hs	0x944 <filter_64ty_selector_val+0x334>
     8cc:      	mov	w0, #0x1                // =1
     8d0:      	ret
     8d4:      	cmp	w9, #0x21
     8d8:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     8dc:      	ldr	x9, [x0, #0x28]
     8e0:      	cmp	x8, x9
     8e4:      	b.le	0x960 <filter_64ty_selector_val+0x350>
     8e8:      	mov	w0, #0x1                // =1
     8ec:      	ret
     8f0:      	cmp	w9, #0x21
     8f4:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     8f8:      	ldr	x9, [x0, #0x28]
     8fc:      	cmp	x8, x9
     900:      	b.ge	0x960 <filter_64ty_selector_val+0x350>
     904:      	mov	w0, #0x1                // =1
     908:      	ret
     90c:      	cmp	w9, #0x21
     910:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     914:      	ldr	x9, [x0, #0x28]
     918:      	tst	x8, x9
     91c:      	b.eq	0x960 <filter_64ty_selector_val+0x350>
     920:      	mov	w0, #0x1                // =1
     924:      	ret
     928:      	cmp	w9, #0x21
     92c:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     930:      	ldr	x9, [x0, #0x28]
     934:      	cmp	x8, x9
     938:      	b.ls	0x960 <filter_64ty_selector_val+0x350>
     93c:      	mov	w0, #0x1                // =1
     940:      	ret
     944:      	cmp	w9, #0x21
     948:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     94c:      	ldr	x9, [x0, #0x28]
     950:      	cmp	x8, x9
     954:      	b.hs	0x960 <filter_64ty_selector_val+0x350>
     958:      	mov	w0, #0x1                // =1
     95c:      	ret
     960:      	mov	x0, xzr
     964:      	ret
     968:      	nop
     96c:      	nop

0000000000000970 <filter_64ty_map>:
     970:      	sub	sp, sp, #0x30
     974:      	str	x30, [sp, #0x10]
     978:      	stp	x20, x19, [sp, #0x20]
     97c:      	ldrb	w8, [x0, #0x10]
     980:      	mov	x19, x0
     984:      	adrp	x0, 0x0 <extract_arg_depth>
     988:      	add	x9, sp, #0x1c
     98c:      	str	w8, [sp, #0x1c]
     990:      	mov	w8, #0x1                // =1
     994:      	mov	x20, x1
     998:      	add	x1, sp, #0x1c
     99c:      	ldr	x0, [x0]
     9a0:      	blr	x8
     9a4:      	cbz	x0, 0x9f4 <filter_64ty_map+0x84>
     9a8:      	ldr	x8, [x20]
     9ac:      	add	x9, sp, #0x8
     9b0:      	add	x1, sp, #0x8
     9b4:      	str	x8, [sp, #0x8]
     9b8:      	mov	w8, #0x1                // =1
     9bc:      	blr	x8
     9c0:      	ldr	w8, [x19, #0x4]
     9c4:      	cmp	w8, #0xb
     9c8:      	b.eq	0x9e0 <filter_64ty_map+0x70>
     9cc:      	cmp	w8, #0xa
     9d0:      	b.ne	0x9ec <filter_64ty_map+0x7c>
     9d4:      	cmp	x0, #0x0
     9d8:      	cset	w8, ne
     9dc:      	b	0x9f0 <filter_64ty_map+0x80>
     9e0:      	cmp	x0, #0x0
     9e4:      	cset	w8, eq
     9e8:      	b	0x9f0 <filter_64ty_map+0x80>
     9ec:      	mov	w8, wzr
     9f0:      	mov	w0, w8
     9f4:      	ldp	x20, x19, [sp, #0x20]
     9f8:      	ldr	x30, [sp, #0x10]
     9fc:      	add	sp, sp, #0x30
     a00:      	ret
     a04:      	nop
     a08:      	nop
     a0c:      	nop

0000000000000a10 <filter_64ty_range>:
     a10:      	ldr	w9, [x0, #0xc]
     a14:      	ldr	w8, [x0, #0x4]
     a18:      	mov	w10, #0x1               // =1
     a1c:      	cmp	w9, #0xc
     a20:      	lsl	w9, w10, w9
     a24:      	mov	w10, #0x1402            // =5122
     a28:      	and	w9, w9, w10
     a2c:      	ccmp	w9, #0x0, #0x4, ls
     a30:      	b.eq	0xb30 <filter_64ty_range+0x120>
     a34:      	ldr	x10, [x1]
     a38:      	cmp	w8, #0x1f
     a3c:      	b.ne	0xac4 <filter_64ty_range+0xb4>
     a40:      	ldr	x9, [x0, #0x10]
     a44:      	cmp	x9, x10
     a48:      	b.gt	0xa58 <filter_64ty_range+0x48>
     a4c:      	ldr	x9, [x0, #0x18]
     a50:      	cmp	x10, x9
     a54:      	b.le	0xb54 <filter_64ty_range+0x144>
     a58:      	ldr	w9, [x0, #0x8]
     a5c:      	cmp	w9, #0x19
     a60:      	b.lo	0xc40 <filter_64ty_range+0x230>
     a64:      	ldr	x11, [x0, #0x20]
     a68:      	cmp	x11, x10
     a6c:      	b.gt	0xa7c <filter_64ty_range+0x6c>
     a70:      	ldr	x11, [x0, #0x28]
     a74:      	cmp	x10, x11
     a78:      	b.le	0xb54 <filter_64ty_range+0x144>
     a7c:      	cmp	w9, #0x29
     a80:      	b.lo	0xc40 <filter_64ty_range+0x230>
     a84:      	ldr	x11, [x0, #0x30]
     a88:      	cmp	x11, x10
     a8c:      	b.gt	0xa9c <filter_64ty_range+0x8c>
     a90:      	ldr	x11, [x0, #0x38]
     a94:      	cmp	x10, x11
     a98:      	b.le	0xb54 <filter_64ty_range+0x144>
     a9c:      	cmp	w9, #0x39
     aa0:      	b.lo	0xc40 <filter_64ty_range+0x230>
     aa4:      	ldr	x11, [x0, #0x40]
     aa8:      	mov	w9, wzr
     aac:      	cmp	x11, x10
     ab0:      	b.gt	0xc30 <filter_64ty_range+0x220>
     ab4:      	ldr	x11, [x0, #0x48]
     ab8:      	cmp	x10, x11
     abc:      	b.le	0xb54 <filter_64ty_range+0x144>
     ac0:      	b	0xc30 <filter_64ty_range+0x220>
     ac4:      	ldp	x9, x12, [x0, #0x10]
     ac8:      	cmp	x9, x10
     acc:      	ldr	w11, [x0, #0x8]
     ad0:      	ccmp	x10, x12, #0x0, le
     ad4:      	cset	w9, le
     ad8:      	cmp	w11, #0x19
     adc:      	b.lo	0xc30 <filter_64ty_range+0x220>
     ae0:      	ldp	x12, x13, [x0, #0x20]
     ae4:      	cmp	x12, x10
     ae8:      	ccmp	x10, x13, #0x0, le
     aec:      	csinc	w9, w9, wzr, gt
     af0:      	cmp	w11, #0x29
     af4:      	b.lo	0xc30 <filter_64ty_range+0x220>
     af8:      	ldp	x12, x13, [x0, #0x30]
     afc:      	cmp	x12, x10
     b00:      	ccmp	x10, x13, #0x0, le
     b04:      	csinc	w9, w9, wzr, gt
     b08:      	cmp	w11, #0x39
     b0c:      	b.lo	0xc30 <filter_64ty_range+0x220>
     b10:      	ldp	x11, x12, [x0, #0x40]
     b14:      	cmp	x11, x10
     b18:      	ccmp	x10, x12, #0x0, le
     b1c:      	csinc	w9, w9, wzr, gt
     b20:      	cmp	w8, #0x20
     b24:      	eor	w8, w9, #0x1
     b28:      	csel	w0, wzr, w8, ne
     b2c:      	ret
     b30:      	ldr	x10, [x1]
     b34:      	cmp	w8, #0x1f
     b38:      	b.ne	0xb5c <filter_64ty_range+0x14c>
     b3c:      	ldr	x9, [x0, #0x10]
     b40:      	cmp	x9, x10
     b44:      	b.hi	0xbc8 <filter_64ty_range+0x1b8>
     b48:      	ldr	x9, [x0, #0x18]
     b4c:      	cmp	x10, x9
     b50:      	b.hi	0xbc8 <filter_64ty_range+0x1b8>
     b54:      	mov	w0, #0x1                // =1
     b58:      	ret
     b5c:      	ldp	x9, x12, [x0, #0x10]
     b60:      	cmp	x9, x10
     b64:      	ldr	w11, [x0, #0x8]
     b68:      	ccmp	x10, x12, #0x2, ls
     b6c:      	cset	w9, ls
     b70:      	cmp	w11, #0x19
     b74:      	b.lo	0xc30 <filter_64ty_range+0x220>
     b78:      	ldp	x12, x13, [x0, #0x20]
     b7c:      	cmp	x12, x10
     b80:      	ccmp	x10, x13, #0x2, ls
     b84:      	csinc	w9, w9, wzr, hi
     b88:      	cmp	w11, #0x29
     b8c:      	b.lo	0xc30 <filter_64ty_range+0x220>
     b90:      	ldp	x12, x13, [x0, #0x30]
     b94:      	cmp	x12, x10
     b98:      	ccmp	x10, x13, #0x2, ls
     b9c:      	csinc	w9, w9, wzr, hi
     ba0:      	cmp	w11, #0x39
     ba4:      	b.lo	0xc30 <filter_64ty_range+0x220>
     ba8:      	ldp	x11, x12, [x0, #0x40]
     bac:      	cmp	x11, x10
     bb0:      	ccmp	x10, x12, #0x2, ls
     bb4:      	csinc	w9, w9, wzr, hi
     bb8:      	cmp	w8, #0x20
     bbc:      	eor	w8, w9, #0x1
     bc0:      	csel	w0, wzr, w8, ne
     bc4:      	ret
     bc8:      	ldr	w9, [x0, #0x8]
     bcc:      	cmp	w9, #0x19
     bd0:      	b.lo	0xc40 <filter_64ty_range+0x230>
     bd4:      	ldr	x11, [x0, #0x20]
     bd8:      	cmp	x11, x10
     bdc:      	b.hi	0xbec <filter_64ty_range+0x1dc>
     be0:      	ldr	x11, [x0, #0x28]
     be4:      	cmp	x10, x11
     be8:      	b.ls	0xb54 <filter_64ty_range+0x144>
     bec:      	cmp	w9, #0x29
     bf0:      	b.lo	0xc40 <filter_64ty_range+0x230>
     bf4:      	ldr	x11, [x0, #0x30]
     bf8:      	cmp	x11, x10
     bfc:      	b.hi	0xc0c <filter_64ty_range+0x1fc>
     c00:      	ldr	x11, [x0, #0x38]
     c04:      	cmp	x10, x11
     c08:      	b.ls	0xb54 <filter_64ty_range+0x144>
     c0c:      	cmp	w9, #0x39
     c10:      	b.lo	0xc40 <filter_64ty_range+0x230>
     c14:      	ldr	x11, [x0, #0x40]
     c18:      	mov	w9, wzr
     c1c:      	cmp	x11, x10
     c20:      	b.hi	0xc30 <filter_64ty_range+0x220>
     c24:      	ldr	x11, [x0, #0x48]
     c28:      	cmp	x10, x11
     c2c:      	b.ls	0xb54 <filter_64ty_range+0x144>
     c30:      	cmp	w8, #0x20
     c34:      	eor	w8, w9, #0x1
     c38:      	csel	w0, wzr, w8, ne
     c3c:      	ret
     c40:      	mov	w9, wzr
     c44:      	cmp	w8, #0x20
     c48:      	eor	w8, w9, #0x1
     c4c:      	csel	w0, wzr, w8, ne
     c50:      	ret
     c54:      	nop
     c58:      	nop
     c5c:      	nop

0000000000000c60 <filter_32ty_selector_val>:
     c60:      	ldr	w8, [x0, #0x4]
     c64:      	cmp	w8, #0x25
     c68:      	b.hi	0xcdc <filter_32ty_selector_val+0x7c>
     c6c:      	mov	x10, #0x40              // =64
     c70:      	mov	w9, #0x1                // =1
     c74:      	movk	x10, #0xc00, lsl #16
     c78:      	lsl	x9, x9, x8
     c7c:      	movk	x10, #0x20, lsl #32
     c80:      	tst	x9, x10
     c84:      	b.eq	0xc90 <filter_32ty_selector_val+0x30>
     c88:      	mov	w0, #0x1                // =1
     c8c:      	ret
     c90:      	mov	w9, #0x1                // =1
     c94:      	lsl	x9, x9, x8
     c98:      	tst	x9, #0x18
     c9c:      	b.eq	0xcbc <filter_32ty_selector_val+0x5c>
     ca0:      	ldr	w9, [x1]
     ca4:      	ldr	w10, [x0, #0x10]
     ca8:      	cmp	w9, w10
     cac:      	b.ne	0xd5c <filter_32ty_selector_val+0xfc>
     cb0:      	cmp	w8, #0x3
     cb4:      	cset	w0, eq
     cb8:      	ret
     cbc:      	cmp	x8, #0xc
     cc0:      	b.ne	0xcdc <filter_32ty_selector_val+0x7c>
     cc4:      	ldr	w8, [x1]
     cc8:      	ldr	w9, [x0, #0x10]
     ccc:      	tst	w8, w9
     cd0:      	b.eq	0xe08 <filter_32ty_selector_val+0x1a8>
     cd4:      	mov	w0, #0x1                // =1
     cd8:      	ret
     cdc:      	cmp	w8, #0x1
     ce0:      	b.eq	0xd24 <filter_32ty_selector_val+0xc4>
     ce4:      	cmp	w8, #0x2
     ce8:      	b.ne	0xfb0 <filter_32ty_selector_val+0x350>
     cec:      	ldr	w8, [x0, #0xc]
     cf0:      	cmp	w8, #0xc
     cf4:      	b.hi	0xe40 <filter_32ty_selector_val+0x1e0>
     cf8:      	mov	w9, #0x1                // =1
     cfc:      	lsl	w8, w9, w8
     d00:      	mov	w9, #0x1402             // =5122
     d04:      	tst	w8, w9
     d08:      	b.eq	0xe40 <filter_32ty_selector_val+0x1e0>
     d0c:      	ldr	w8, [x1]
     d10:      	ldr	w9, [x0, #0x10]
     d14:      	cmp	w8, w9
     d18:      	b.ge	0xde8 <filter_32ty_selector_val+0x188>
     d1c:      	mov	w0, #0x1                // =1
     d20:      	ret
     d24:      	ldr	w8, [x0, #0xc]
     d28:      	cmp	w8, #0xc
     d2c:      	b.hi	0xe28 <filter_32ty_selector_val+0x1c8>
     d30:      	mov	w9, #0x1                // =1
     d34:      	lsl	w8, w9, w8
     d38:      	mov	w9, #0x1402             // =5122
     d3c:      	tst	w8, w9
     d40:      	b.eq	0xe28 <filter_32ty_selector_val+0x1c8>
     d44:      	ldr	w8, [x1]
     d48:      	ldr	w9, [x0, #0x10]
     d4c:      	cmp	w8, w9
     d50:      	b.le	0xdc8 <filter_32ty_selector_val+0x168>
     d54:      	mov	w0, #0x1                // =1
     d58:      	ret
     d5c:      	ldr	w10, [x0, #0x8]
     d60:      	cmp	w10, #0xd
     d64:      	b.lo	0xd9c <filter_32ty_selector_val+0x13c>
     d68:      	ldr	w11, [x0, #0x14]
     d6c:      	cmp	w9, w11
     d70:      	b.eq	0xcb0 <filter_32ty_selector_val+0x50>
     d74:      	cmp	w10, #0x11
     d78:      	b.lo	0xd9c <filter_32ty_selector_val+0x13c>
     d7c:      	ldr	w11, [x0, #0x18]
     d80:      	cmp	w9, w11
     d84:      	b.eq	0xcb0 <filter_32ty_selector_val+0x50>
     d88:      	cmp	w10, #0x15
     d8c:      	b.lo	0xd9c <filter_32ty_selector_val+0x13c>
     d90:      	ldr	w10, [x0, #0x1c]
     d94:      	cmp	w9, w10
     d98:      	b.eq	0xcb0 <filter_32ty_selector_val+0x50>
     d9c:      	cmp	w8, #0x25
     da0:      	b.hi	0xfb0 <filter_32ty_selector_val+0x350>
     da4:      	mov	w9, #0x1                // =1
     da8:      	lsl	x8, x9, x8
     dac:      	mov	x9, #0x50               // =80
     db0:      	movk	x9, #0xc00, lsl #16
     db4:      	movk	x9, #0x20, lsl #32
     db8:      	tst	x8, x9
     dbc:      	b.eq	0xfb0 <filter_32ty_selector_val+0x350>
     dc0:      	mov	w0, #0x1                // =1
     dc4:      	ret
     dc8:      	ldr	w9, [x0, #0x8]
     dcc:      	cmp	w9, #0xd
     dd0:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     dd4:      	ldr	w10, [x0, #0x14]
     dd8:      	cmp	w8, w10
     ddc:      	b.le	0xe98 <filter_32ty_selector_val+0x238>
     de0:      	mov	w0, #0x1                // =1
     de4:      	ret
     de8:      	ldr	w9, [x0, #0x8]
     dec:      	cmp	w9, #0xd
     df0:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     df4:      	ldr	w10, [x0, #0x14]
     df8:      	cmp	w8, w10
     dfc:      	b.ge	0xeb4 <filter_32ty_selector_val+0x254>
     e00:      	mov	w0, #0x1                // =1
     e04:      	ret
     e08:      	ldr	w9, [x0, #0x8]
     e0c:      	cmp	w9, #0xd
     e10:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     e14:      	ldr	w10, [x0, #0x14]
     e18:      	tst	w8, w10
     e1c:      	b.eq	0xed0 <filter_32ty_selector_val+0x270>
     e20:      	mov	w0, #0x1                // =1
     e24:      	ret
     e28:      	ldr	w8, [x1]
     e2c:      	ldr	w9, [x0, #0x10]
     e30:      	cmp	w8, w9
     e34:      	b.ls	0xe58 <filter_32ty_selector_val+0x1f8>
     e38:      	mov	w0, #0x1                // =1
     e3c:      	ret
     e40:      	ldr	w8, [x1]
     e44:      	ldr	w9, [x0, #0x10]
     e48:      	cmp	w8, w9
     e4c:      	b.hs	0xe78 <filter_32ty_selector_val+0x218>
     e50:      	mov	w0, #0x1                // =1
     e54:      	ret
     e58:      	ldr	w9, [x0, #0x8]
     e5c:      	cmp	w9, #0xd
     e60:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     e64:      	ldr	w10, [x0, #0x14]
     e68:      	cmp	w8, w10
     e6c:      	b.ls	0xeec <filter_32ty_selector_val+0x28c>
     e70:      	mov	w0, #0x1                // =1
     e74:      	ret
     e78:      	ldr	w9, [x0, #0x8]
     e7c:      	cmp	w9, #0xd
     e80:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     e84:      	ldr	w10, [x0, #0x14]
     e88:      	cmp	w8, w10
     e8c:      	b.hs	0xf08 <filter_32ty_selector_val+0x2a8>
     e90:      	mov	w0, #0x1                // =1
     e94:      	ret
     e98:      	cmp	w9, #0x11
     e9c:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     ea0:      	ldr	w10, [x0, #0x18]
     ea4:      	cmp	w8, w10
     ea8:      	b.le	0xf24 <filter_32ty_selector_val+0x2c4>
     eac:      	mov	w0, #0x1                // =1
     eb0:      	ret
     eb4:      	cmp	w9, #0x11
     eb8:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     ebc:      	ldr	w10, [x0, #0x18]
     ec0:      	cmp	w8, w10
     ec4:      	b.ge	0xf40 <filter_32ty_selector_val+0x2e0>
     ec8:      	mov	w0, #0x1                // =1
     ecc:      	ret
     ed0:      	cmp	w9, #0x11
     ed4:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     ed8:      	ldr	w10, [x0, #0x18]
     edc:      	tst	w8, w10
     ee0:      	b.eq	0xf5c <filter_32ty_selector_val+0x2fc>
     ee4:      	mov	w0, #0x1                // =1
     ee8:      	ret
     eec:      	cmp	w9, #0x11
     ef0:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     ef4:      	ldr	w10, [x0, #0x18]
     ef8:      	cmp	w8, w10
     efc:      	b.ls	0xf78 <filter_32ty_selector_val+0x318>
     f00:      	mov	w0, #0x1                // =1
     f04:      	ret
     f08:      	cmp	w9, #0x11
     f0c:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     f10:      	ldr	w10, [x0, #0x18]
     f14:      	cmp	w8, w10
     f18:      	b.hs	0xf94 <filter_32ty_selector_val+0x334>
     f1c:      	mov	w0, #0x1                // =1
     f20:      	ret
     f24:      	cmp	w9, #0x15
     f28:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     f2c:      	ldr	w9, [x0, #0x1c]
     f30:      	cmp	w8, w9
     f34:      	b.le	0xfb0 <filter_32ty_selector_val+0x350>
     f38:      	mov	w0, #0x1                // =1
     f3c:      	ret
     f40:      	cmp	w9, #0x15
     f44:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     f48:      	ldr	w9, [x0, #0x1c]
     f4c:      	cmp	w8, w9
     f50:      	b.ge	0xfb0 <filter_32ty_selector_val+0x350>
     f54:      	mov	w0, #0x1                // =1
     f58:      	ret
     f5c:      	cmp	w9, #0x15
     f60:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     f64:      	ldr	w9, [x0, #0x1c]
     f68:      	tst	w8, w9
     f6c:      	b.eq	0xfb0 <filter_32ty_selector_val+0x350>
     f70:      	mov	w0, #0x1                // =1
     f74:      	ret
     f78:      	cmp	w9, #0x15
     f7c:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     f80:      	ldr	w9, [x0, #0x1c]
     f84:      	cmp	w8, w9
     f88:      	b.ls	0xfb0 <filter_32ty_selector_val+0x350>
     f8c:      	mov	w0, #0x1                // =1
     f90:      	ret
     f94:      	cmp	w9, #0x15
     f98:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     f9c:      	ldr	w9, [x0, #0x1c]
     fa0:      	cmp	w8, w9
     fa4:      	b.hs	0xfb0 <filter_32ty_selector_val+0x350>
     fa8:      	mov	w0, #0x1                // =1
     fac:      	ret
     fb0:      	mov	x0, xzr
     fb4:      	ret
     fb8:      	nop
     fbc:      	nop

0000000000000fc0 <filter_32ty_map>:
     fc0:      	sub	sp, sp, #0x30
     fc4:      	str	x30, [sp, #0x10]
     fc8:      	stp	x20, x19, [sp, #0x20]
     fcc:      	ldrb	w8, [x0, #0x10]
     fd0:      	mov	x19, x0
     fd4:      	adrp	x0, 0x0 <extract_arg_depth>
     fd8:      	add	x9, sp, #0x1c
     fdc:      	str	w8, [sp, #0x1c]
     fe0:      	mov	w8, #0x1                // =1
     fe4:      	mov	x20, x1
     fe8:      	add	x1, sp, #0x1c
     fec:      	ldr	x0, [x0]
     ff0:      	blr	x8
     ff4:      	cbz	x0, 0x1068 <filter_32ty_map+0xa8>
     ff8:      	ldr	w8, [x20]
     ffc:      	mov	w9, #0x1                // =1
    1000:      	add	x1, sp, #0x8
    1004:      	mov	w20, #0x1               // =1
    1008:      	str	x8, [sp, #0x8]
    100c:      	add	x8, sp, #0x8
    1010:      	blr	x9
    1014:      	ldr	w9, [x19, #0x4]
    1018:      	mov	w8, wzr
    101c:      	cmp	w9, #0x1d
    1020:      	b.hi	0x1064 <filter_32ty_map+0xa4>
    1024:      	mov	w11, #0x8400            // =33792
    1028:      	lsl	w10, w20, w9
    102c:      	movk	w11, #0x3003, lsl #16
    1030:      	tst	w10, w11
    1034:      	b.eq	0x1044 <filter_32ty_map+0x84>
    1038:      	cmp	x0, #0x0
    103c:      	cset	w8, ne
    1040:      	b	0x1064 <filter_32ty_map+0xa4>
    1044:      	mov	w10, #0x1               // =1
    1048:      	lsl	w9, w10, w9
    104c:      	mov	w10, #0x800             // =2048
    1050:      	movk	w10, #0xc, lsl #16
    1054:      	tst	w9, w10
    1058:      	b.eq	0x1064 <filter_32ty_map+0xa4>
    105c:      	cmp	x0, #0x0
    1060:      	cset	w8, eq
    1064:      	mov	w0, w8
    1068:      	ldp	x20, x19, [sp, #0x20]
    106c:      	ldr	x30, [sp, #0x10]
    1070:      	add	sp, sp, #0x30
    1074:      	ret
    1078:      	nop
    107c:      	nop

0000000000001080 <filter_32ty_range>:
    1080:      	ldr	w9, [x0, #0xc]
    1084:      	ldr	w8, [x0, #0x4]
    1088:      	mov	w10, #0x1               // =1
    108c:      	cmp	w9, #0xc
    1090:      	lsl	w9, w10, w9
    1094:      	mov	w10, #0x1402            // =5122
    1098:      	and	w9, w9, w10
    109c:      	ccmp	w9, #0x0, #0x4, ls
    10a0:      	b.eq	0x11a0 <filter_32ty_range+0x120>
    10a4:      	ldr	w10, [x1]
    10a8:      	cmp	w8, #0x1f
    10ac:      	b.ne	0x1134 <filter_32ty_range+0xb4>
    10b0:      	ldr	w9, [x0, #0x10]
    10b4:      	cmp	w9, w10
    10b8:      	b.gt	0x10c8 <filter_32ty_range+0x48>
    10bc:      	ldr	w9, [x0, #0x14]
    10c0:      	cmp	w10, w9
    10c4:      	b.le	0x11c4 <filter_32ty_range+0x144>
    10c8:      	ldr	w9, [x0, #0x8]
    10cc:      	cmp	w9, #0x11
    10d0:      	b.lo	0x12b0 <filter_32ty_range+0x230>
    10d4:      	ldr	w11, [x0, #0x18]
    10d8:      	cmp	w11, w10
    10dc:      	b.gt	0x10ec <filter_32ty_range+0x6c>
    10e0:      	ldr	w11, [x0, #0x1c]
    10e4:      	cmp	w10, w11
    10e8:      	b.le	0x11c4 <filter_32ty_range+0x144>
    10ec:      	cmp	w9, #0x19
    10f0:      	b.lo	0x12b0 <filter_32ty_range+0x230>
    10f4:      	ldr	w11, [x0, #0x20]
    10f8:      	cmp	w11, w10
    10fc:      	b.gt	0x110c <filter_32ty_range+0x8c>
    1100:      	ldr	w11, [x0, #0x24]
    1104:      	cmp	w10, w11
    1108:      	b.le	0x11c4 <filter_32ty_range+0x144>
    110c:      	cmp	w9, #0x21
    1110:      	b.lo	0x12b0 <filter_32ty_range+0x230>
    1114:      	ldr	w11, [x0, #0x28]
    1118:      	mov	w9, wzr
    111c:      	cmp	w11, w10
    1120:      	b.gt	0x12a0 <filter_32ty_range+0x220>
    1124:      	ldr	w11, [x0, #0x2c]
    1128:      	cmp	w10, w11
    112c:      	b.le	0x11c4 <filter_32ty_range+0x144>
    1130:      	b	0x12a0 <filter_32ty_range+0x220>
    1134:      	ldp	w9, w12, [x0, #0x10]
    1138:      	ldr	w11, [x0, #0x8]
    113c:      	cmp	w9, w10
    1140:      	ccmp	w10, w12, #0x0, le
    1144:      	cset	w9, le
    1148:      	cmp	w11, #0x11
    114c:      	b.lo	0x12a0 <filter_32ty_range+0x220>
    1150:      	ldp	w12, w13, [x0, #0x18]
    1154:      	cmp	w12, w10
    1158:      	ccmp	w10, w13, #0x0, le
    115c:      	csinc	w9, w9, wzr, gt
    1160:      	cmp	w11, #0x19
    1164:      	b.lo	0x12a0 <filter_32ty_range+0x220>
    1168:      	ldp	w12, w13, [x0, #0x20]
    116c:      	cmp	w12, w10
    1170:      	ccmp	w10, w13, #0x0, le
    1174:      	csinc	w9, w9, wzr, gt
    1178:      	cmp	w11, #0x21
    117c:      	b.lo	0x12a0 <filter_32ty_range+0x220>
    1180:      	ldp	w11, w12, [x0, #0x28]
    1184:      	cmp	w11, w10
    1188:      	ccmp	w10, w12, #0x0, le
    118c:      	csinc	w9, w9, wzr, gt
    1190:      	cmp	w8, #0x20
    1194:      	eor	w8, w9, #0x1
    1198:      	csel	w0, wzr, w8, ne
    119c:      	ret
    11a0:      	ldr	w10, [x1]
    11a4:      	cmp	w8, #0x1f
    11a8:      	b.ne	0x11cc <filter_32ty_range+0x14c>
    11ac:      	ldr	w9, [x0, #0x10]
    11b0:      	cmp	w9, w10
    11b4:      	b.hi	0x1238 <filter_32ty_range+0x1b8>
    11b8:      	ldr	w9, [x0, #0x14]
    11bc:      	cmp	w10, w9
    11c0:      	b.hi	0x1238 <filter_32ty_range+0x1b8>
    11c4:      	mov	w0, #0x1                // =1
    11c8:      	ret
    11cc:      	ldp	w9, w12, [x0, #0x10]
    11d0:      	ldr	w11, [x0, #0x8]
    11d4:      	cmp	w9, w10
    11d8:      	ccmp	w10, w12, #0x2, ls
    11dc:      	cset	w9, ls
    11e0:      	cmp	w11, #0x11
    11e4:      	b.lo	0x12a0 <filter_32ty_range+0x220>
    11e8:      	ldp	w12, w13, [x0, #0x18]
    11ec:      	cmp	w12, w10
    11f0:      	ccmp	w10, w13, #0x2, ls
    11f4:      	csinc	w9, w9, wzr, hi
    11f8:      	cmp	w11, #0x19
    11fc:      	b.lo	0x12a0 <filter_32ty_range+0x220>
    1200:      	ldp	w12, w13, [x0, #0x20]
    1204:      	cmp	w12, w10
    1208:      	ccmp	w10, w13, #0x2, ls
    120c:      	csinc	w9, w9, wzr, hi
    1210:      	cmp	w11, #0x21
    1214:      	b.lo	0x12a0 <filter_32ty_range+0x220>
    1218:      	ldp	w11, w12, [x0, #0x28]
    121c:      	cmp	w11, w10
    1220:      	ccmp	w10, w12, #0x2, ls
    1224:      	csinc	w9, w9, wzr, hi
    1228:      	cmp	w8, #0x20
    122c:      	eor	w8, w9, #0x1
    1230:      	csel	w0, wzr, w8, ne
    1234:      	ret
    1238:      	ldr	w9, [x0, #0x8]
    123c:      	cmp	w9, #0x11
    1240:      	b.lo	0x12b0 <filter_32ty_range+0x230>
    1244:      	ldr	w11, [x0, #0x18]
    1248:      	cmp	w11, w10
    124c:      	b.hi	0x125c <filter_32ty_range+0x1dc>
    1250:      	ldr	w11, [x0, #0x1c]
    1254:      	cmp	w10, w11
    1258:      	b.ls	0x11c4 <filter_32ty_range+0x144>
    125c:      	cmp	w9, #0x19
    1260:      	b.lo	0x12b0 <filter_32ty_range+0x230>
    1264:      	ldr	w11, [x0, #0x20]
    1268:      	cmp	w11, w10
    126c:      	b.hi	0x127c <filter_32ty_range+0x1fc>
    1270:      	ldr	w11, [x0, #0x24]
    1274:      	cmp	w10, w11
    1278:      	b.ls	0x11c4 <filter_32ty_range+0x144>
    127c:      	cmp	w9, #0x21
    1280:      	b.lo	0x12b0 <filter_32ty_range+0x230>
    1284:      	ldr	w11, [x0, #0x28]
    1288:      	mov	w9, wzr
    128c:      	cmp	w11, w10
    1290:      	b.hi	0x12a0 <filter_32ty_range+0x220>
    1294:      	ldr	w11, [x0, #0x2c]
    1298:      	cmp	w10, w11
    129c:      	b.ls	0x11c4 <filter_32ty_range+0x144>
    12a0:      	cmp	w8, #0x20
    12a4:      	eor	w8, w9, #0x1
    12a8:      	csel	w0, wzr, w8, ne
    12ac:      	ret
    12b0:      	mov	w9, wzr
    12b4:      	cmp	w8, #0x20
    12b8:      	eor	w8, w9, #0x1
    12bc:      	csel	w0, wzr, w8, ne
    12c0:      	ret
    12c4:      	nop
    12c8:      	nop
    12cc:      	nop

00000000000012d0 <filter_16ty_selector_val>:
    12d0:      	ldr	w8, [x0, #0x4]
    12d4:      	cmp	w8, #0x25
    12d8:      	b.hi	0x134c <filter_16ty_selector_val+0x7c>
    12dc:      	mov	x10, #0x40              // =64
    12e0:      	mov	w9, #0x1                // =1
    12e4:      	movk	x10, #0xc00, lsl #16
    12e8:      	lsl	x9, x9, x8
    12ec:      	movk	x10, #0x20, lsl #32
    12f0:      	tst	x9, x10
    12f4:      	b.eq	0x1300 <filter_16ty_selector_val+0x30>
    12f8:      	mov	w0, #0x1                // =1
    12fc:      	ret
    1300:      	mov	w9, #0x1                // =1
    1304:      	lsl	x9, x9, x8
    1308:      	tst	x9, #0x18
    130c:      	b.eq	0x132c <filter_16ty_selector_val+0x5c>
    1310:      	ldrh	w9, [x1]
    1314:      	ldr	w10, [x0, #0x10]
    1318:      	cmp	w10, w9
    131c:      	b.ne	0x13cc <filter_16ty_selector_val+0xfc>
    1320:      	cmp	w8, #0x3
    1324:      	cset	w0, eq
    1328:      	ret
    132c:      	cmp	x8, #0xc
    1330:      	b.ne	0x134c <filter_16ty_selector_val+0x7c>
    1334:      	ldrh	w8, [x1]
    1338:      	ldr	w9, [x0, #0x10]
    133c:      	tst	w9, w8
    1340:      	b.eq	0x1478 <filter_16ty_selector_val+0x1a8>
    1344:      	mov	w0, #0x1                // =1
    1348:      	ret
    134c:      	cmp	w8, #0x1
    1350:      	b.eq	0x1394 <filter_16ty_selector_val+0xc4>
    1354:      	cmp	w8, #0x2
    1358:      	b.ne	0x1620 <filter_16ty_selector_val+0x350>
    135c:      	ldr	w8, [x0, #0xc]
    1360:      	cmp	w8, #0xc
    1364:      	b.hi	0x14b0 <filter_16ty_selector_val+0x1e0>
    1368:      	mov	w9, #0x1                // =1
    136c:      	lsl	w8, w9, w8
    1370:      	mov	w9, #0x1402             // =5122
    1374:      	tst	w8, w9
    1378:      	b.eq	0x14b0 <filter_16ty_selector_val+0x1e0>
    137c:      	ldrsh	w8, [x1]
    1380:      	ldr	w9, [x0, #0x10]
    1384:      	cmp	w9, w8
    1388:      	b.le	0x1458 <filter_16ty_selector_val+0x188>
    138c:      	mov	w0, #0x1                // =1
    1390:      	ret
    1394:      	ldr	w8, [x0, #0xc]
    1398:      	cmp	w8, #0xc
    139c:      	b.hi	0x1498 <filter_16ty_selector_val+0x1c8>
    13a0:      	mov	w9, #0x1                // =1
    13a4:      	lsl	w8, w9, w8
    13a8:      	mov	w9, #0x1402             // =5122
    13ac:      	tst	w8, w9
    13b0:      	b.eq	0x1498 <filter_16ty_selector_val+0x1c8>
    13b4:      	ldrsh	w8, [x1]
    13b8:      	ldr	w9, [x0, #0x10]
    13bc:      	cmp	w9, w8
    13c0:      	b.ge	0x1438 <filter_16ty_selector_val+0x168>
    13c4:      	mov	w0, #0x1                // =1
    13c8:      	ret
    13cc:      	ldr	w10, [x0, #0x8]
    13d0:      	cmp	w10, #0xd
    13d4:      	b.lo	0x140c <filter_16ty_selector_val+0x13c>
    13d8:      	ldr	w11, [x0, #0x14]
    13dc:      	cmp	w11, w9
    13e0:      	b.eq	0x1320 <filter_16ty_selector_val+0x50>
    13e4:      	cmp	w10, #0x11
    13e8:      	b.lo	0x140c <filter_16ty_selector_val+0x13c>
    13ec:      	ldr	w11, [x0, #0x18]
    13f0:      	cmp	w11, w9
    13f4:      	b.eq	0x1320 <filter_16ty_selector_val+0x50>
    13f8:      	cmp	w10, #0x15
    13fc:      	b.lo	0x140c <filter_16ty_selector_val+0x13c>
    1400:      	ldr	w10, [x0, #0x1c]
    1404:      	cmp	w10, w9
    1408:      	b.eq	0x1320 <filter_16ty_selector_val+0x50>
    140c:      	cmp	w8, #0x25
    1410:      	b.hi	0x1620 <filter_16ty_selector_val+0x350>
    1414:      	mov	w9, #0x1                // =1
    1418:      	lsl	x8, x9, x8
    141c:      	mov	x9, #0x50               // =80
    1420:      	movk	x9, #0xc00, lsl #16
    1424:      	movk	x9, #0x20, lsl #32
    1428:      	tst	x8, x9
    142c:      	b.eq	0x1620 <filter_16ty_selector_val+0x350>
    1430:      	mov	w0, #0x1                // =1
    1434:      	ret
    1438:      	ldr	w9, [x0, #0x8]
    143c:      	cmp	w9, #0xd
    1440:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1444:      	ldr	w10, [x0, #0x14]
    1448:      	cmp	w10, w8
    144c:      	b.ge	0x1508 <filter_16ty_selector_val+0x238>
    1450:      	mov	w0, #0x1                // =1
    1454:      	ret
    1458:      	ldr	w9, [x0, #0x8]
    145c:      	cmp	w9, #0xd
    1460:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1464:      	ldr	w10, [x0, #0x14]
    1468:      	cmp	w10, w8
    146c:      	b.le	0x1524 <filter_16ty_selector_val+0x254>
    1470:      	mov	w0, #0x1                // =1
    1474:      	ret
    1478:      	ldr	w9, [x0, #0x8]
    147c:      	cmp	w9, #0xd
    1480:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1484:      	ldr	w10, [x0, #0x14]
    1488:      	tst	w10, w8
    148c:      	b.eq	0x1540 <filter_16ty_selector_val+0x270>
    1490:      	mov	w0, #0x1                // =1
    1494:      	ret
    1498:      	ldrh	w8, [x1]
    149c:      	ldr	w9, [x0, #0x10]
    14a0:      	cmp	w9, w8
    14a4:      	b.hs	0x14c8 <filter_16ty_selector_val+0x1f8>
    14a8:      	mov	w0, #0x1                // =1
    14ac:      	ret
    14b0:      	ldrh	w8, [x1]
    14b4:      	ldr	w9, [x0, #0x10]
    14b8:      	cmp	w9, w8
    14bc:      	b.ls	0x14e8 <filter_16ty_selector_val+0x218>
    14c0:      	mov	w0, #0x1                // =1
    14c4:      	ret
    14c8:      	ldr	w9, [x0, #0x8]
    14cc:      	cmp	w9, #0xd
    14d0:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    14d4:      	ldr	w10, [x0, #0x14]
    14d8:      	cmp	w10, w8
    14dc:      	b.hs	0x155c <filter_16ty_selector_val+0x28c>
    14e0:      	mov	w0, #0x1                // =1
    14e4:      	ret
    14e8:      	ldr	w9, [x0, #0x8]
    14ec:      	cmp	w9, #0xd
    14f0:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    14f4:      	ldr	w10, [x0, #0x14]
    14f8:      	cmp	w10, w8
    14fc:      	b.ls	0x1578 <filter_16ty_selector_val+0x2a8>
    1500:      	mov	w0, #0x1                // =1
    1504:      	ret
    1508:      	cmp	w9, #0x11
    150c:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1510:      	ldr	w10, [x0, #0x18]
    1514:      	cmp	w10, w8
    1518:      	b.ge	0x1594 <filter_16ty_selector_val+0x2c4>
    151c:      	mov	w0, #0x1                // =1
    1520:      	ret
    1524:      	cmp	w9, #0x11
    1528:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    152c:      	ldr	w10, [x0, #0x18]
    1530:      	cmp	w10, w8
    1534:      	b.le	0x15b0 <filter_16ty_selector_val+0x2e0>
    1538:      	mov	w0, #0x1                // =1
    153c:      	ret
    1540:      	cmp	w9, #0x11
    1544:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1548:      	ldr	w10, [x0, #0x18]
    154c:      	tst	w10, w8
    1550:      	b.eq	0x15cc <filter_16ty_selector_val+0x2fc>
    1554:      	mov	w0, #0x1                // =1
    1558:      	ret
    155c:      	cmp	w9, #0x11
    1560:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1564:      	ldr	w10, [x0, #0x18]
    1568:      	cmp	w10, w8
    156c:      	b.hs	0x15e8 <filter_16ty_selector_val+0x318>
    1570:      	mov	w0, #0x1                // =1
    1574:      	ret
    1578:      	cmp	w9, #0x11
    157c:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1580:      	ldr	w10, [x0, #0x18]
    1584:      	cmp	w10, w8
    1588:      	b.ls	0x1604 <filter_16ty_selector_val+0x334>
    158c:      	mov	w0, #0x1                // =1
    1590:      	ret
    1594:      	cmp	w9, #0x15
    1598:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    159c:      	ldr	w9, [x0, #0x1c]
    15a0:      	cmp	w9, w8
    15a4:      	b.ge	0x1620 <filter_16ty_selector_val+0x350>
    15a8:      	mov	w0, #0x1                // =1
    15ac:      	ret
    15b0:      	cmp	w9, #0x15
    15b4:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    15b8:      	ldr	w9, [x0, #0x1c]
    15bc:      	cmp	w9, w8
    15c0:      	b.le	0x1620 <filter_16ty_selector_val+0x350>
    15c4:      	mov	w0, #0x1                // =1
    15c8:      	ret
    15cc:      	cmp	w9, #0x15
    15d0:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    15d4:      	ldr	w9, [x0, #0x1c]
    15d8:      	tst	w9, w8
    15dc:      	b.eq	0x1620 <filter_16ty_selector_val+0x350>
    15e0:      	mov	w0, #0x1                // =1
    15e4:      	ret
    15e8:      	cmp	w9, #0x15
    15ec:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    15f0:      	ldr	w9, [x0, #0x1c]
    15f4:      	cmp	w9, w8
    15f8:      	b.hs	0x1620 <filter_16ty_selector_val+0x350>
    15fc:      	mov	w0, #0x1                // =1
    1600:      	ret
    1604:      	cmp	w9, #0x15
    1608:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    160c:      	ldr	w9, [x0, #0x1c]
    1610:      	cmp	w9, w8
    1614:      	b.ls	0x1620 <filter_16ty_selector_val+0x350>
    1618:      	mov	w0, #0x1                // =1
    161c:      	ret
    1620:      	mov	x0, xzr
    1624:      	ret
    1628:      	nop
    162c:      	nop

0000000000001630 <filter_16ty_map>:
    1630:      	sub	sp, sp, #0x30
    1634:      	str	x30, [sp, #0x10]
    1638:      	stp	x20, x19, [sp, #0x20]
    163c:      	ldrb	w8, [x0, #0x10]
    1640:      	mov	x19, x0
    1644:      	adrp	x0, 0x1000 <filter_32ty_map+0x40>
    1648:      	add	x9, sp, #0x1c
    164c:      	str	w8, [sp, #0x1c]
    1650:      	mov	w8, #0x1                // =1
    1654:      	mov	x20, x1
    1658:      	add	x1, sp, #0x1c
    165c:      	ldr	x0, [x0]
    1660:      	blr	x8
    1664:      	cbz	x0, 0x16d8 <filter_16ty_map+0xa8>
    1668:      	ldrh	w8, [x20]
    166c:      	mov	w9, #0x1                // =1
    1670:      	add	x1, sp, #0x8
    1674:      	mov	w20, #0x1               // =1
    1678:      	str	x8, [sp, #0x8]
    167c:      	add	x8, sp, #0x8
    1680:      	blr	x9
    1684:      	ldr	w9, [x19, #0x4]
    1688:      	mov	w8, wzr
    168c:      	cmp	w9, #0x1d
    1690:      	b.hi	0x16d4 <filter_16ty_map+0xa4>
    1694:      	mov	w11, #0x8400            // =33792
    1698:      	lsl	w10, w20, w9
    169c:      	movk	w11, #0x3003, lsl #16
    16a0:      	tst	w10, w11
    16a4:      	b.eq	0x16b4 <filter_16ty_map+0x84>
    16a8:      	cmp	x0, #0x0
    16ac:      	cset	w8, ne
    16b0:      	b	0x16d4 <filter_16ty_map+0xa4>
    16b4:      	mov	w10, #0x1               // =1
    16b8:      	lsl	w9, w10, w9
    16bc:      	mov	w10, #0x800             // =2048
    16c0:      	movk	w10, #0xc, lsl #16
    16c4:      	tst	w9, w10
    16c8:      	b.eq	0x16d4 <filter_16ty_map+0xa4>
    16cc:      	cmp	x0, #0x0
    16d0:      	cset	w8, eq
    16d4:      	mov	w0, w8
    16d8:      	ldp	x20, x19, [sp, #0x20]
    16dc:      	ldr	x30, [sp, #0x10]
    16e0:      	add	sp, sp, #0x30
    16e4:      	ret
    16e8:      	nop
    16ec:      	nop

00000000000016f0 <filter_16ty_range>:
    16f0:      	ldr	w9, [x0, #0xc]
    16f4:      	ldr	w8, [x0, #0x4]
    16f8:      	mov	w10, #0x1               // =1
    16fc:      	cmp	w9, #0xc
    1700:      	lsl	w9, w10, w9
    1704:      	mov	w10, #0x1402            // =5122
    1708:      	and	w9, w9, w10
    170c:      	ccmp	w9, #0x0, #0x4, ls
    1710:      	b.eq	0x1810 <filter_16ty_range+0x120>
    1714:      	ldrsh	w10, [x1]
    1718:      	cmp	w8, #0x1f
    171c:      	b.ne	0x17a4 <filter_16ty_range+0xb4>
    1720:      	ldr	w9, [x0, #0x10]
    1724:      	cmp	w9, w10
    1728:      	b.gt	0x1738 <filter_16ty_range+0x48>
    172c:      	ldr	w9, [x0, #0x14]
    1730:      	cmp	w9, w10
    1734:      	b.ge	0x1834 <filter_16ty_range+0x144>
    1738:      	ldr	w9, [x0, #0x8]
    173c:      	cmp	w9, #0x11
    1740:      	b.lo	0x1920 <filter_16ty_range+0x230>
    1744:      	ldr	w11, [x0, #0x18]
    1748:      	cmp	w11, w10
    174c:      	b.gt	0x175c <filter_16ty_range+0x6c>
    1750:      	ldr	w11, [x0, #0x1c]
    1754:      	cmp	w11, w10
    1758:      	b.ge	0x1834 <filter_16ty_range+0x144>
    175c:      	cmp	w9, #0x19
    1760:      	b.lo	0x1920 <filter_16ty_range+0x230>
    1764:      	ldr	w11, [x0, #0x20]
    1768:      	cmp	w11, w10
    176c:      	b.gt	0x177c <filter_16ty_range+0x8c>
    1770:      	ldr	w11, [x0, #0x24]
    1774:      	cmp	w11, w10
    1778:      	b.ge	0x1834 <filter_16ty_range+0x144>
    177c:      	cmp	w9, #0x21
    1780:      	b.lo	0x1920 <filter_16ty_range+0x230>
    1784:      	ldr	w11, [x0, #0x28]
    1788:      	mov	w9, wzr
    178c:      	cmp	w11, w10
    1790:      	b.gt	0x1910 <filter_16ty_range+0x220>
    1794:      	ldr	w11, [x0, #0x2c]
    1798:      	cmp	w11, w10
    179c:      	b.ge	0x1834 <filter_16ty_range+0x144>
    17a0:      	b	0x1910 <filter_16ty_range+0x220>
    17a4:      	ldp	w9, w12, [x0, #0x10]
    17a8:      	ldr	w11, [x0, #0x8]
    17ac:      	cmp	w9, w10
    17b0:      	ccmp	w12, w10, #0x8, le
    17b4:      	cset	w9, ge
    17b8:      	cmp	w11, #0x11
    17bc:      	b.lo	0x1910 <filter_16ty_range+0x220>
    17c0:      	ldp	w12, w13, [x0, #0x18]
    17c4:      	cmp	w12, w10
    17c8:      	ccmp	w13, w10, #0x8, le
    17cc:      	csinc	w9, w9, wzr, lt
    17d0:      	cmp	w11, #0x19
    17d4:      	b.lo	0x1910 <filter_16ty_range+0x220>
    17d8:      	ldp	w12, w13, [x0, #0x20]
    17dc:      	cmp	w12, w10
    17e0:      	ccmp	w13, w10, #0x8, le
    17e4:      	csinc	w9, w9, wzr, lt
    17e8:      	cmp	w11, #0x21
    17ec:      	b.lo	0x1910 <filter_16ty_range+0x220>
    17f0:      	ldp	w11, w12, [x0, #0x28]
    17f4:      	cmp	w11, w10
    17f8:      	ccmp	w12, w10, #0x8, le
    17fc:      	csinc	w9, w9, wzr, lt
    1800:      	cmp	w8, #0x20
    1804:      	eor	w8, w9, #0x1
    1808:      	csel	w0, wzr, w8, ne
    180c:      	ret
    1810:      	ldrh	w10, [x1]
    1814:      	cmp	w8, #0x1f
    1818:      	b.ne	0x183c <filter_16ty_range+0x14c>
    181c:      	ldr	w9, [x0, #0x10]
    1820:      	cmp	w9, w10
    1824:      	b.hi	0x18a8 <filter_16ty_range+0x1b8>
    1828:      	ldr	w9, [x0, #0x14]
    182c:      	cmp	w9, w10
    1830:      	b.lo	0x18a8 <filter_16ty_range+0x1b8>
    1834:      	mov	w0, #0x1                // =1
    1838:      	ret
    183c:      	ldp	w9, w12, [x0, #0x10]
    1840:      	ldr	w11, [x0, #0x8]
    1844:      	cmp	w9, w10
    1848:      	ccmp	w12, w10, #0x0, ls
    184c:      	cset	w9, hs
    1850:      	cmp	w11, #0x11
    1854:      	b.lo	0x1910 <filter_16ty_range+0x220>
    1858:      	ldp	w12, w13, [x0, #0x18]
    185c:      	cmp	w12, w10
    1860:      	ccmp	w13, w10, #0x0, ls
    1864:      	csinc	w9, w9, wzr, lo
    1868:      	cmp	w11, #0x19
    186c:      	b.lo	0x1910 <filter_16ty_range+0x220>
    1870:      	ldp	w12, w13, [x0, #0x20]
    1874:      	cmp	w12, w10
    1878:      	ccmp	w13, w10, #0x0, ls
    187c:      	csinc	w9, w9, wzr, lo
    1880:      	cmp	w11, #0x21
    1884:      	b.lo	0x1910 <filter_16ty_range+0x220>
    1888:      	ldp	w11, w12, [x0, #0x28]
    188c:      	cmp	w11, w10
    1890:      	ccmp	w12, w10, #0x0, ls
    1894:      	csinc	w9, w9, wzr, lo
    1898:      	cmp	w8, #0x20
    189c:      	eor	w8, w9, #0x1
    18a0:      	csel	w0, wzr, w8, ne
    18a4:      	ret
    18a8:      	ldr	w9, [x0, #0x8]
    18ac:      	cmp	w9, #0x11
    18b0:      	b.lo	0x1920 <filter_16ty_range+0x230>
    18b4:      	ldr	w11, [x0, #0x18]
    18b8:      	cmp	w11, w10
    18bc:      	b.hi	0x18cc <filter_16ty_range+0x1dc>
    18c0:      	ldr	w11, [x0, #0x1c]
    18c4:      	cmp	w11, w10
    18c8:      	b.hs	0x1834 <filter_16ty_range+0x144>
    18cc:      	cmp	w9, #0x19
    18d0:      	b.lo	0x1920 <filter_16ty_range+0x230>
    18d4:      	ldr	w11, [x0, #0x20]
    18d8:      	cmp	w11, w10
    18dc:      	b.hi	0x18ec <filter_16ty_range+0x1fc>
    18e0:      	ldr	w11, [x0, #0x24]
    18e4:      	cmp	w11, w10
    18e8:      	b.hs	0x1834 <filter_16ty_range+0x144>
    18ec:      	cmp	w9, #0x21
    18f0:      	b.lo	0x1920 <filter_16ty_range+0x230>
    18f4:      	ldr	w11, [x0, #0x28]
    18f8:      	mov	w9, wzr
    18fc:      	cmp	w11, w10
    1900:      	b.hi	0x1910 <filter_16ty_range+0x220>
    1904:      	ldr	w11, [x0, #0x2c]
    1908:      	cmp	w11, w10
    190c:      	b.hs	0x1834 <filter_16ty_range+0x144>
    1910:      	cmp	w8, #0x20
    1914:      	eor	w8, w9, #0x1
    1918:      	csel	w0, wzr, w8, ne
    191c:      	ret
    1920:      	mov	w9, wzr
    1924:      	cmp	w8, #0x20
    1928:      	eor	w8, w9, #0x1
    192c:      	csel	w0, wzr, w8, ne
    1930:      	ret
    1934:      	nop
    1938:      	nop
    193c:      	nop

0000000000001940 <filter_8ty_selector_val>:
    1940:      	ldr	w8, [x0, #0x4]
    1944:      	cmp	w8, #0x25
    1948:      	b.hi	0x19bc <filter_8ty_selector_val+0x7c>
    194c:      	mov	x10, #0x40              // =64
    1950:      	mov	w9, #0x1                // =1
    1954:      	movk	x10, #0xc00, lsl #16
    1958:      	lsl	x9, x9, x8
    195c:      	movk	x10, #0x20, lsl #32
    1960:      	tst	x9, x10
    1964:      	b.eq	0x1970 <filter_8ty_selector_val+0x30>
    1968:      	mov	w0, #0x1                // =1
    196c:      	ret
    1970:      	mov	w9, #0x1                // =1
    1974:      	lsl	x9, x9, x8
    1978:      	tst	x9, #0x18
    197c:      	b.eq	0x199c <filter_8ty_selector_val+0x5c>
    1980:      	ldrb	w9, [x1]
    1984:      	ldr	w10, [x0, #0x10]
    1988:      	cmp	w10, w9
    198c:      	b.ne	0x1a3c <filter_8ty_selector_val+0xfc>
    1990:      	cmp	w8, #0x3
    1994:      	cset	w0, eq
    1998:      	ret
    199c:      	cmp	x8, #0xc
    19a0:      	b.ne	0x19bc <filter_8ty_selector_val+0x7c>
    19a4:      	ldrb	w8, [x1]
    19a8:      	ldr	w9, [x0, #0x10]
    19ac:      	tst	w9, w8
    19b0:      	b.eq	0x1ae8 <filter_8ty_selector_val+0x1a8>
    19b4:      	mov	w0, #0x1                // =1
    19b8:      	ret
    19bc:      	cmp	w8, #0x1
    19c0:      	b.eq	0x1a04 <filter_8ty_selector_val+0xc4>
    19c4:      	cmp	w8, #0x2
    19c8:      	b.ne	0x1c90 <filter_8ty_selector_val+0x350>
    19cc:      	ldr	w8, [x0, #0xc]
    19d0:      	cmp	w8, #0xc
    19d4:      	b.hi	0x1b20 <filter_8ty_selector_val+0x1e0>
    19d8:      	mov	w9, #0x1                // =1
    19dc:      	lsl	w8, w9, w8
    19e0:      	mov	w9, #0x1402             // =5122
    19e4:      	tst	w8, w9
    19e8:      	b.eq	0x1b20 <filter_8ty_selector_val+0x1e0>
    19ec:      	ldrsb	w8, [x1]
    19f0:      	ldr	w9, [x0, #0x10]
    19f4:      	cmp	w9, w8
    19f8:      	b.le	0x1ac8 <filter_8ty_selector_val+0x188>
    19fc:      	mov	w0, #0x1                // =1
    1a00:      	ret
    1a04:      	ldr	w8, [x0, #0xc]
    1a08:      	cmp	w8, #0xc
    1a0c:      	b.hi	0x1b08 <filter_8ty_selector_val+0x1c8>
    1a10:      	mov	w9, #0x1                // =1
    1a14:      	lsl	w8, w9, w8
    1a18:      	mov	w9, #0x1402             // =5122
    1a1c:      	tst	w8, w9
    1a20:      	b.eq	0x1b08 <filter_8ty_selector_val+0x1c8>
    1a24:      	ldrsb	w8, [x1]
    1a28:      	ldr	w9, [x0, #0x10]
    1a2c:      	cmp	w9, w8
    1a30:      	b.ge	0x1aa8 <filter_8ty_selector_val+0x168>
    1a34:      	mov	w0, #0x1                // =1
    1a38:      	ret
    1a3c:      	ldr	w10, [x0, #0x8]
    1a40:      	cmp	w10, #0xd
    1a44:      	b.lo	0x1a7c <filter_8ty_selector_val+0x13c>
    1a48:      	ldr	w11, [x0, #0x14]
    1a4c:      	cmp	w11, w9
    1a50:      	b.eq	0x1990 <filter_8ty_selector_val+0x50>
    1a54:      	cmp	w10, #0x11
    1a58:      	b.lo	0x1a7c <filter_8ty_selector_val+0x13c>
    1a5c:      	ldr	w11, [x0, #0x18]
    1a60:      	cmp	w11, w9
    1a64:      	b.eq	0x1990 <filter_8ty_selector_val+0x50>
    1a68:      	cmp	w10, #0x15
    1a6c:      	b.lo	0x1a7c <filter_8ty_selector_val+0x13c>
    1a70:      	ldr	w10, [x0, #0x1c]
    1a74:      	cmp	w10, w9
    1a78:      	b.eq	0x1990 <filter_8ty_selector_val+0x50>
    1a7c:      	cmp	w8, #0x25
    1a80:      	b.hi	0x1c90 <filter_8ty_selector_val+0x350>
    1a84:      	mov	w9, #0x1                // =1
    1a88:      	lsl	x8, x9, x8
    1a8c:      	mov	x9, #0x50               // =80
    1a90:      	movk	x9, #0xc00, lsl #16
    1a94:      	movk	x9, #0x20, lsl #32
    1a98:      	tst	x8, x9
    1a9c:      	b.eq	0x1c90 <filter_8ty_selector_val+0x350>
    1aa0:      	mov	w0, #0x1                // =1
    1aa4:      	ret
    1aa8:      	ldr	w9, [x0, #0x8]
    1aac:      	cmp	w9, #0xd
    1ab0:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1ab4:      	ldr	w10, [x0, #0x14]
    1ab8:      	cmp	w10, w8
    1abc:      	b.ge	0x1b78 <filter_8ty_selector_val+0x238>
    1ac0:      	mov	w0, #0x1                // =1
    1ac4:      	ret
    1ac8:      	ldr	w9, [x0, #0x8]
    1acc:      	cmp	w9, #0xd
    1ad0:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1ad4:      	ldr	w10, [x0, #0x14]
    1ad8:      	cmp	w10, w8
    1adc:      	b.le	0x1b94 <filter_8ty_selector_val+0x254>
    1ae0:      	mov	w0, #0x1                // =1
    1ae4:      	ret
    1ae8:      	ldr	w9, [x0, #0x8]
    1aec:      	cmp	w9, #0xd
    1af0:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1af4:      	ldr	w10, [x0, #0x14]
    1af8:      	tst	w10, w8
    1afc:      	b.eq	0x1bb0 <filter_8ty_selector_val+0x270>
    1b00:      	mov	w0, #0x1                // =1
    1b04:      	ret
    1b08:      	ldrb	w8, [x1]
    1b0c:      	ldr	w9, [x0, #0x10]
    1b10:      	cmp	w9, w8
    1b14:      	b.hs	0x1b38 <filter_8ty_selector_val+0x1f8>
    1b18:      	mov	w0, #0x1                // =1
    1b1c:      	ret
    1b20:      	ldrb	w8, [x1]
    1b24:      	ldr	w9, [x0, #0x10]
    1b28:      	cmp	w9, w8
    1b2c:      	b.ls	0x1b58 <filter_8ty_selector_val+0x218>
    1b30:      	mov	w0, #0x1                // =1
    1b34:      	ret
    1b38:      	ldr	w9, [x0, #0x8]
    1b3c:      	cmp	w9, #0xd
    1b40:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1b44:      	ldr	w10, [x0, #0x14]
    1b48:      	cmp	w10, w8
    1b4c:      	b.hs	0x1bcc <filter_8ty_selector_val+0x28c>
    1b50:      	mov	w0, #0x1                // =1
    1b54:      	ret
    1b58:      	ldr	w9, [x0, #0x8]
    1b5c:      	cmp	w9, #0xd
    1b60:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1b64:      	ldr	w10, [x0, #0x14]
    1b68:      	cmp	w10, w8
    1b6c:      	b.ls	0x1be8 <filter_8ty_selector_val+0x2a8>
    1b70:      	mov	w0, #0x1                // =1
    1b74:      	ret
    1b78:      	cmp	w9, #0x11
    1b7c:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1b80:      	ldr	w10, [x0, #0x18]
    1b84:      	cmp	w10, w8
    1b88:      	b.ge	0x1c04 <filter_8ty_selector_val+0x2c4>
    1b8c:      	mov	w0, #0x1                // =1
    1b90:      	ret
    1b94:      	cmp	w9, #0x11
    1b98:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1b9c:      	ldr	w10, [x0, #0x18]
    1ba0:      	cmp	w10, w8
    1ba4:      	b.le	0x1c20 <filter_8ty_selector_val+0x2e0>
    1ba8:      	mov	w0, #0x1                // =1
    1bac:      	ret
    1bb0:      	cmp	w9, #0x11
    1bb4:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1bb8:      	ldr	w10, [x0, #0x18]
    1bbc:      	tst	w10, w8
    1bc0:      	b.eq	0x1c3c <filter_8ty_selector_val+0x2fc>
    1bc4:      	mov	w0, #0x1                // =1
    1bc8:      	ret
    1bcc:      	cmp	w9, #0x11
    1bd0:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1bd4:      	ldr	w10, [x0, #0x18]
    1bd8:      	cmp	w10, w8
    1bdc:      	b.hs	0x1c58 <filter_8ty_selector_val+0x318>
    1be0:      	mov	w0, #0x1                // =1
    1be4:      	ret
    1be8:      	cmp	w9, #0x11
    1bec:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1bf0:      	ldr	w10, [x0, #0x18]
    1bf4:      	cmp	w10, w8
    1bf8:      	b.ls	0x1c74 <filter_8ty_selector_val+0x334>
    1bfc:      	mov	w0, #0x1                // =1
    1c00:      	ret
    1c04:      	cmp	w9, #0x15
    1c08:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1c0c:      	ldr	w9, [x0, #0x1c]
    1c10:      	cmp	w9, w8
    1c14:      	b.ge	0x1c90 <filter_8ty_selector_val+0x350>
    1c18:      	mov	w0, #0x1                // =1
    1c1c:      	ret
    1c20:      	cmp	w9, #0x15
    1c24:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1c28:      	ldr	w9, [x0, #0x1c]
    1c2c:      	cmp	w9, w8
    1c30:      	b.le	0x1c90 <filter_8ty_selector_val+0x350>
    1c34:      	mov	w0, #0x1                // =1
    1c38:      	ret
    1c3c:      	cmp	w9, #0x15
    1c40:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1c44:      	ldr	w9, [x0, #0x1c]
    1c48:      	tst	w9, w8
    1c4c:      	b.eq	0x1c90 <filter_8ty_selector_val+0x350>
    1c50:      	mov	w0, #0x1                // =1
    1c54:      	ret
    1c58:      	cmp	w9, #0x15
    1c5c:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1c60:      	ldr	w9, [x0, #0x1c]
    1c64:      	cmp	w9, w8
    1c68:      	b.hs	0x1c90 <filter_8ty_selector_val+0x350>
    1c6c:      	mov	w0, #0x1                // =1
    1c70:      	ret
    1c74:      	cmp	w9, #0x15
    1c78:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1c7c:      	ldr	w9, [x0, #0x1c]
    1c80:      	cmp	w9, w8
    1c84:      	b.ls	0x1c90 <filter_8ty_selector_val+0x350>
    1c88:      	mov	w0, #0x1                // =1
    1c8c:      	ret
    1c90:      	mov	x0, xzr
    1c94:      	ret
    1c98:      	nop
    1c9c:      	nop

0000000000001ca0 <filter_8ty_map>:
    1ca0:      	sub	sp, sp, #0x30
    1ca4:      	str	x30, [sp, #0x10]
    1ca8:      	stp	x20, x19, [sp, #0x20]
    1cac:      	ldrb	w8, [x0, #0x10]
    1cb0:      	mov	x19, x0
    1cb4:      	adrp	x0, 0x1000 <filter_32ty_map+0x40>
    1cb8:      	add	x9, sp, #0x1c
    1cbc:      	str	w8, [sp, #0x1c]
    1cc0:      	mov	w8, #0x1                // =1
    1cc4:      	mov	x20, x1
    1cc8:      	add	x1, sp, #0x1c
    1ccc:      	ldr	x0, [x0]
    1cd0:      	blr	x8
    1cd4:      	cbz	x0, 0x1d48 <filter_8ty_map+0xa8>
    1cd8:      	ldrb	w8, [x20]
    1cdc:      	mov	w9, #0x1                // =1
    1ce0:      	add	x1, sp, #0x8
    1ce4:      	mov	w20, #0x1               // =1
    1ce8:      	str	x8, [sp, #0x8]
    1cec:      	add	x8, sp, #0x8
    1cf0:      	blr	x9
    1cf4:      	ldr	w9, [x19, #0x4]
    1cf8:      	mov	w8, wzr
    1cfc:      	cmp	w9, #0x1d
    1d00:      	b.hi	0x1d44 <filter_8ty_map+0xa4>
    1d04:      	mov	w11, #0x8400            // =33792
    1d08:      	lsl	w10, w20, w9
    1d0c:      	movk	w11, #0x3003, lsl #16
    1d10:      	tst	w10, w11
    1d14:      	b.eq	0x1d24 <filter_8ty_map+0x84>
    1d18:      	cmp	x0, #0x0
    1d1c:      	cset	w8, ne
    1d20:      	b	0x1d44 <filter_8ty_map+0xa4>
    1d24:      	mov	w10, #0x1               // =1
    1d28:      	lsl	w9, w10, w9
    1d2c:      	mov	w10, #0x800             // =2048
    1d30:      	movk	w10, #0xc, lsl #16
    1d34:      	tst	w9, w10
    1d38:      	b.eq	0x1d44 <filter_8ty_map+0xa4>
    1d3c:      	cmp	x0, #0x0
    1d40:      	cset	w8, eq
    1d44:      	mov	w0, w8
    1d48:      	ldp	x20, x19, [sp, #0x20]
    1d4c:      	ldr	x30, [sp, #0x10]
    1d50:      	add	sp, sp, #0x30
    1d54:      	ret
    1d58:      	nop
    1d5c:      	nop

0000000000001d60 <filter_8ty_range>:
    1d60:      	ldr	w9, [x0, #0xc]
    1d64:      	ldr	w8, [x0, #0x4]
    1d68:      	mov	w10, #0x1               // =1
    1d6c:      	cmp	w9, #0xc
    1d70:      	lsl	w9, w10, w9
    1d74:      	mov	w10, #0x1402            // =5122
    1d78:      	and	w9, w9, w10
    1d7c:      	ccmp	w9, #0x0, #0x4, ls
    1d80:      	b.eq	0x1e80 <filter_8ty_range+0x120>
    1d84:      	ldrsb	w10, [x1]
    1d88:      	cmp	w8, #0x1f
    1d8c:      	b.ne	0x1e14 <filter_8ty_range+0xb4>
    1d90:      	ldr	w9, [x0, #0x10]
    1d94:      	cmp	w9, w10
    1d98:      	b.gt	0x1da8 <filter_8ty_range+0x48>
    1d9c:      	ldr	w9, [x0, #0x14]
    1da0:      	cmp	w9, w10
    1da4:      	b.ge	0x1ea4 <filter_8ty_range+0x144>
    1da8:      	ldr	w9, [x0, #0x8]
    1dac:      	cmp	w9, #0x11
    1db0:      	b.lo	0x1f90 <filter_8ty_range+0x230>
    1db4:      	ldr	w11, [x0, #0x18]
    1db8:      	cmp	w11, w10
    1dbc:      	b.gt	0x1dcc <filter_8ty_range+0x6c>
    1dc0:      	ldr	w11, [x0, #0x1c]
    1dc4:      	cmp	w11, w10
    1dc8:      	b.ge	0x1ea4 <filter_8ty_range+0x144>
    1dcc:      	cmp	w9, #0x19
    1dd0:      	b.lo	0x1f90 <filter_8ty_range+0x230>
    1dd4:      	ldr	w11, [x0, #0x20]
    1dd8:      	cmp	w11, w10
    1ddc:      	b.gt	0x1dec <filter_8ty_range+0x8c>
    1de0:      	ldr	w11, [x0, #0x24]
    1de4:      	cmp	w11, w10
    1de8:      	b.ge	0x1ea4 <filter_8ty_range+0x144>
    1dec:      	cmp	w9, #0x21
    1df0:      	b.lo	0x1f90 <filter_8ty_range+0x230>
    1df4:      	ldr	w11, [x0, #0x28]
    1df8:      	mov	w9, wzr
    1dfc:      	cmp	w11, w10
    1e00:      	b.gt	0x1f80 <filter_8ty_range+0x220>
    1e04:      	ldr	w11, [x0, #0x2c]
    1e08:      	cmp	w11, w10
    1e0c:      	b.ge	0x1ea4 <filter_8ty_range+0x144>
    1e10:      	b	0x1f80 <filter_8ty_range+0x220>
    1e14:      	ldp	w9, w12, [x0, #0x10]
    1e18:      	ldr	w11, [x0, #0x8]
    1e1c:      	cmp	w9, w10
    1e20:      	ccmp	w12, w10, #0x8, le
    1e24:      	cset	w9, ge
    1e28:      	cmp	w11, #0x11
    1e2c:      	b.lo	0x1f80 <filter_8ty_range+0x220>
    1e30:      	ldp	w12, w13, [x0, #0x18]
    1e34:      	cmp	w12, w10
    1e38:      	ccmp	w13, w10, #0x8, le
    1e3c:      	csinc	w9, w9, wzr, lt
    1e40:      	cmp	w11, #0x19
    1e44:      	b.lo	0x1f80 <filter_8ty_range+0x220>
    1e48:      	ldp	w12, w13, [x0, #0x20]
    1e4c:      	cmp	w12, w10
    1e50:      	ccmp	w13, w10, #0x8, le
    1e54:      	csinc	w9, w9, wzr, lt
    1e58:      	cmp	w11, #0x21
    1e5c:      	b.lo	0x1f80 <filter_8ty_range+0x220>
    1e60:      	ldp	w11, w12, [x0, #0x28]
    1e64:      	cmp	w11, w10
    1e68:      	ccmp	w12, w10, #0x8, le
    1e6c:      	csinc	w9, w9, wzr, lt
    1e70:      	cmp	w8, #0x20
    1e74:      	eor	w8, w9, #0x1
    1e78:      	csel	w0, wzr, w8, ne
    1e7c:      	ret
    1e80:      	ldrb	w10, [x1]
    1e84:      	cmp	w8, #0x1f
    1e88:      	b.ne	0x1eac <filter_8ty_range+0x14c>
    1e8c:      	ldr	w9, [x0, #0x10]
    1e90:      	cmp	w9, w10
    1e94:      	b.hi	0x1f18 <filter_8ty_range+0x1b8>
    1e98:      	ldr	w9, [x0, #0x14]
    1e9c:      	cmp	w9, w10
    1ea0:      	b.lo	0x1f18 <filter_8ty_range+0x1b8>
    1ea4:      	mov	w0, #0x1                // =1
    1ea8:      	ret
    1eac:      	ldp	w9, w12, [x0, #0x10]
    1eb0:      	ldr	w11, [x0, #0x8]
    1eb4:      	cmp	w9, w10
    1eb8:      	ccmp	w12, w10, #0x0, ls
    1ebc:      	cset	w9, hs
    1ec0:      	cmp	w11, #0x11
    1ec4:      	b.lo	0x1f80 <filter_8ty_range+0x220>
    1ec8:      	ldp	w12, w13, [x0, #0x18]
    1ecc:      	cmp	w12, w10
    1ed0:      	ccmp	w13, w10, #0x0, ls
    1ed4:      	csinc	w9, w9, wzr, lo
    1ed8:      	cmp	w11, #0x19
    1edc:      	b.lo	0x1f80 <filter_8ty_range+0x220>
    1ee0:      	ldp	w12, w13, [x0, #0x20]
    1ee4:      	cmp	w12, w10
    1ee8:      	ccmp	w13, w10, #0x0, ls
    1eec:      	csinc	w9, w9, wzr, lo
    1ef0:      	cmp	w11, #0x21
    1ef4:      	b.lo	0x1f80 <filter_8ty_range+0x220>
    1ef8:      	ldp	w11, w12, [x0, #0x28]
    1efc:      	cmp	w11, w10
    1f00:      	ccmp	w12, w10, #0x0, ls
    1f04:      	csinc	w9, w9, wzr, lo
    1f08:      	cmp	w8, #0x20
    1f0c:      	eor	w8, w9, #0x1
    1f10:      	csel	w0, wzr, w8, ne
    1f14:      	ret
    1f18:      	ldr	w9, [x0, #0x8]
    1f1c:      	cmp	w9, #0x11
    1f20:      	b.lo	0x1f90 <filter_8ty_range+0x230>
    1f24:      	ldr	w11, [x0, #0x18]
    1f28:      	cmp	w11, w10
    1f2c:      	b.hi	0x1f3c <filter_8ty_range+0x1dc>
    1f30:      	ldr	w11, [x0, #0x1c]
    1f34:      	cmp	w11, w10
    1f38:      	b.hs	0x1ea4 <filter_8ty_range+0x144>
    1f3c:      	cmp	w9, #0x19
    1f40:      	b.lo	0x1f90 <filter_8ty_range+0x230>
    1f44:      	ldr	w11, [x0, #0x20]
    1f48:      	cmp	w11, w10
    1f4c:      	b.hi	0x1f5c <filter_8ty_range+0x1fc>
    1f50:      	ldr	w11, [x0, #0x24]
    1f54:      	cmp	w11, w10
    1f58:      	b.hs	0x1ea4 <filter_8ty_range+0x144>
    1f5c:      	cmp	w9, #0x21
    1f60:      	b.lo	0x1f90 <filter_8ty_range+0x230>
    1f64:      	ldr	w11, [x0, #0x28]
    1f68:      	mov	w9, wzr
    1f6c:      	cmp	w11, w10
    1f70:      	b.hi	0x1f80 <filter_8ty_range+0x220>
    1f74:      	ldr	w11, [x0, #0x2c]
    1f78:      	cmp	w11, w10
    1f7c:      	b.hs	0x1ea4 <filter_8ty_range+0x144>
    1f80:      	cmp	w8, #0x20
    1f84:      	eor	w8, w9, #0x1
    1f88:      	csel	w0, wzr, w8, ne
    1f8c:      	ret
    1f90:      	mov	w9, wzr
    1f94:      	cmp	w8, #0x20
    1f98:      	eor	w8, w9, #0x1
    1f9c:      	csel	w0, wzr, w8, ne
    1fa0:      	ret
    1fa4:      	nop
    1fa8:      	nop
    1fac:      	nop

0000000000001fb0 <filter_file_buf>:
    1fb0:      	stp	x30, x19, [sp, #-0x10]!
    1fb4:      	ldr	w2, [x1]
    1fb8:      	ldr	w8, [x0, #0x4]
    1fbc:      	mov	x19, x0
    1fc0:      	cbnz	w2, 0x1fdc <filter_file_buf+0x2c>
    1fc4:      	and	w9, w8, #0xfffffffe
    1fc8:      	cmp	w9, #0x24
    1fcc:      	b.eq	0x1fdc <filter_file_buf+0x2c>
    1fd0:      	mov	x0, xzr
    1fd4:      	ldp	x30, x19, [sp], #0x10
    1fd8:      	ret
    1fdc:      	cmp	w8, #0x25
    1fe0:      	b.hi	0x203c <filter_file_buf+0x8c>
    1fe4:      	mov	w9, #0x1                // =1
    1fe8:      	mov	w10, #0x100             // =256
    1fec:      	lsl	x9, x9, x8
    1ff0:      	movk	w10, #0x400, lsl #16
    1ff4:      	tst	x9, x10
    1ff8:      	b.ne	0x2080 <filter_file_buf+0xd0>
    1ffc:      	mov	w9, #0x1                // =1
    2000:      	mov	w10, #0x200             // =512
    2004:      	lsl	x9, x9, x8
    2008:      	movk	w10, #0x800, lsl #16
    200c:      	tst	x9, x10
    2010:      	b.ne	0x2064 <filter_file_buf+0xb4>
    2014:      	mov	w9, #0x1                // =1
    2018:      	lsl	x9, x9, x8
    201c:      	tst	x9, #0x3000000000
    2020:      	b.eq	0x203c <filter_file_buf+0x8c>
    2024:      	mov	x0, x19
    2028:      	bl	0x2c90 <filter_file_type>
    202c:      	ldr	w8, [x19, #0x4]
    2030:      	cmp	w8, #0x25
    2034:      	b.ls	0x20a8 <filter_file_buf+0xf8>
    2038:      	b	0x20cc <filter_file_buf+0x11c>
    203c:      	sub	w9, w8, #0x3
    2040:      	cmp	w9, #0x2
    2044:      	b.hs	0x209c <filter_file_buf+0xec>
    2048:      	add	x1, x1, #0x4
    204c:      	mov	x0, x19
    2050:      	bl	0x26c0 <filter_char_buf_equal>
    2054:      	ldr	w8, [x19, #0x4]
    2058:      	cmp	w8, #0x25
    205c:      	b.ls	0x20a8 <filter_file_buf+0xf8>
    2060:      	b	0x20cc <filter_file_buf+0x11c>
    2064:      	ldr	w0, [x19, #0x10]
    2068:      	add	x1, x1, #0x4
    206c:      	bl	0x2bb0 <filter_char_buf_postfix>
    2070:      	ldr	w8, [x19, #0x4]
    2074:      	cmp	w8, #0x25
    2078:      	b.ls	0x20a8 <filter_file_buf+0xf8>
    207c:      	b	0x20cc <filter_file_buf+0x11c>
    2080:      	ldr	w0, [x19, #0x10]
    2084:      	add	x1, x1, #0x4
    2088:      	bl	0x2af0 <filter_char_buf_prefix>
    208c:      	ldr	w8, [x19, #0x4]
    2090:      	cmp	w8, #0x25
    2094:      	b.ls	0x20a8 <filter_file_buf+0xf8>
    2098:      	b	0x20cc <filter_file_buf+0x11c>
    209c:      	mov	x0, xzr
    20a0:      	cmp	w8, #0x25
    20a4:      	b.hi	0x20cc <filter_file_buf+0x11c>
    20a8:      	mov	w8, w8
    20ac:      	mov	w9, #0x1                // =1
    20b0:      	lsl	x8, x9, x8
    20b4:      	mov	x9, #0x50               // =80
    20b8:      	movk	x9, #0xc00, lsl #16
    20bc:      	movk	x9, #0x20, lsl #32
    20c0:      	tst	x8, x9
    20c4:      	b.eq	0x20cc <filter_file_buf+0x11c>
    20c8:      	eor	x0, x0, #0x1
    20cc:      	ldp	x30, x19, [sp], #0x10
    20d0:      	ret
    20d4:      	nop
    20d8:      	nop
    20dc:      	nop

00000000000020e0 <filter_char_buf>:
    20e0:      	stp	x30, x19, [sp, #-0x10]!
    20e4:      	mov	w8, w2
    20e8:      	mov	x19, x0
    20ec:      	add	x9, x1, w2, sxtw
    20f0:      	ldur	w2, [x9, #-0x4]
    20f4:      	add	x1, x1, w8, uxtw
    20f8:      	ldr	w8, [x0, #0x4]
    20fc:      	mov	x0, xzr
    2100:      	cmp	w8, #0x19
    2104:      	b.gt	0x2128 <filter_char_buf+0x48>
    2108:      	sub	w9, w8, #0x3
    210c:      	cmp	w9, #0x2
    2110:      	b.lo	0x2174 <filter_char_buf+0x94>
    2114:      	cmp	w8, #0x8
    2118:      	b.eq	0x2168 <filter_char_buf+0x88>
    211c:      	cmp	w8, #0x9
    2120:      	b.eq	0x2140 <filter_char_buf+0x60>
    2124:      	b	0x2190 <filter_char_buf+0xb0>
    2128:      	cmp	w8, #0x20
    212c:      	b.gt	0x214c <filter_char_buf+0x6c>
    2130:      	cmp	w8, #0x1a
    2134:      	b.eq	0x2168 <filter_char_buf+0x88>
    2138:      	cmp	w8, #0x1b
    213c:      	b.ne	0x2190 <filter_char_buf+0xb0>
    2140:      	ldr	w0, [x19, #0x10]
    2144:      	bl	0x2bb0 <filter_char_buf_postfix>
    2148:      	b	0x218c <filter_char_buf+0xac>
    214c:      	cmp	w8, #0x21
    2150:      	b.eq	0x2180 <filter_char_buf+0xa0>
    2154:      	cmp	w8, #0x22
    2158:      	b.ne	0x2190 <filter_char_buf+0xb0>
    215c:      	mov	x0, x19
    2160:      	mov	w3, #0x1                // =1
    2164:      	b	0x2188 <filter_char_buf+0xa8>
    2168:      	ldr	w0, [x19, #0x10]
    216c:      	bl	0x2af0 <filter_char_buf_prefix>
    2170:      	b	0x218c <filter_char_buf+0xac>
    2174:      	mov	x0, x19
    2178:      	bl	0x26c0 <filter_char_buf_equal>
    217c:      	b	0x218c <filter_char_buf+0xac>
    2180:      	mov	x0, x19
    2184:      	mov	w3, wzr
    2188:      	bl	0x2d90 <filter_char_substring>
    218c:      	ldr	w8, [x19, #0x4]
    2190:      	cmp	w8, #0x25
    2194:      	b.hi	0x21c0 <filter_char_buf+0xe0>
    2198:      	mov	w8, w8
    219c:      	mov	w9, #0x1                // =1
    21a0:      	lsl	x8, x9, x8
    21a4:      	mov	x9, #0x50               // =80
    21a8:      	movk	x9, #0xc00, lsl #16
    21ac:      	movk	x9, #0x20, lsl #32
    21b0:      	tst	x8, x9
    21b4:      	b.eq	0x21c0 <filter_char_buf+0xe0>
    21b8:      	cmp	x0, #0x0
    21bc:      	cset	w0, eq
    21c0:      	ldp	x30, x19, [sp], #0x10
    21c4:      	ret
    21c8:      	nop
    21cc:      	nop

00000000000021d0 <filter_inet>:
    21d0:      	sub	sp, sp, #0x80
    21d4:      	str	x30, [sp, #0x50]
    21d8:      	stp	x22, x21, [sp, #0x60]
    21dc:      	stp	x20, x19, [sp, #0x70]
    21e0:      	ldr	w10, [x0, #0xc]
    21e4:      	mov	x8, xzr
    21e8:      	stp	xzr, xzr, [sp, #0x28]
    21ec:      	cmp	w10, #0x27
    21f0:      	str	xzr, [sp, #0x10]
    21f4:      	stp	xzr, xzr, [sp, #0x18]
    21f8:      	str	wzr, [sp, #0x58]
    21fc:      	str	wzr, [sp, #0xc]
    2200:      	b.gt	0x224c <filter_inet+0x7c>
    2204:      	cmp	w10, #0x5
    2208:      	b.eq	0x2280 <filter_inet+0xb0>
    220c:      	cmp	w10, #0x7
    2210:      	mov	x11, x1
    2214:      	b.ne	0x2454 <filter_inet+0x284>
    2218:      	ldr	w9, [x0, #0x4]
    221c:      	mov	x8, xzr
    2220:      	cmp	w9, #0x13
    2224:      	b.le	0x22c8 <filter_inet+0xf8>
    2228:      	cmp	w9, #0x17
    222c:      	b.gt	0x2264 <filter_inet+0x94>
    2230:      	sub	w10, w9, #0x14
    2234:      	cmp	w10, #0x2
    2238:      	b.lo	0x2324 <filter_inet+0x154>
    223c:      	sub	w10, w9, #0x16
    2240:      	cmp	w10, #0x2
    2244:      	b.lo	0x231c <filter_inet+0x14c>
    2248:      	b	0x2454 <filter_inet+0x284>
    224c:      	cmp	w10, #0x28
    2250:      	b.eq	0x2298 <filter_inet+0xc8>
    2254:      	cmp	w10, #0x29
    2258:      	mov	x11, x1
    225c:      	b.eq	0x2218 <filter_inet+0x48>
    2260:      	b	0x2454 <filter_inet+0x284>
    2264:      	cmp	w9, #0x1b
    2268:      	b.gt	0x2368 <filter_inet+0x198>
    226c:      	cmp	w9, #0x18
    2270:      	b.eq	0x2424 <filter_inet+0x254>
    2274:      	cmp	w9, #0x19
    2278:      	b.eq	0x2388 <filter_inet+0x1b8>
    227c:      	b	0x2454 <filter_inet+0x284>
    2280:      	mov	x11, xzr
    2284:      	ldr	w9, [x0, #0x4]
    2288:      	mov	x8, xzr
    228c:      	cmp	w9, #0x13
    2290:      	b.gt	0x2228 <filter_inet+0x58>
    2294:      	b	0x22c8 <filter_inet+0xf8>
    2298:      	ldrh	w8, [x1]
    229c:      	ldrh	w9, [x1, #0x2]
    22a0:      	mov	x11, xzr
    22a4:      	strh	w8, [sp, #0x36]
    22a8:      	strh	w9, [sp, #0x30]
    22ac:      	ldp	x8, x9, [x1, #0x8]
    22b0:      	add	x1, sp, #0x10
    22b4:      	stp	x8, x9, [sp, #0x10]
    22b8:      	ldr	w9, [x0, #0x4]
    22bc:      	mov	x8, xzr
    22c0:      	cmp	w9, #0x13
    22c4:      	b.gt	0x2228 <filter_inet+0x58>
    22c8:      	cmp	w9, #0xf
    22cc:      	b.le	0x22f0 <filter_inet+0x120>
    22d0:      	cmp	w9, #0x11
    22d4:      	b.gt	0x230c <filter_inet+0x13c>
    22d8:      	cmp	w9, #0x10
    22dc:      	b.eq	0x231c <filter_inet+0x14c>
    22e0:      	cmp	w9, #0x11
    22e4:      	b.ne	0x2454 <filter_inet+0x284>
    22e8:      	ldrh	w8, [x1, #0x24]
    22ec:      	b	0x253c <filter_inet+0x36c>
    22f0:      	cmp	w9, #0xd
    22f4:      	b.eq	0x2424 <filter_inet+0x254>
    22f8:      	cmp	w9, #0xe
    22fc:      	b.eq	0x2388 <filter_inet+0x1b8>
    2300:      	cmp	w9, #0xf
    2304:      	b.eq	0x2324 <filter_inet+0x154>
    2308:      	b	0x2454 <filter_inet+0x284>
    230c:      	cmp	w9, #0x12
    2310:      	b.eq	0x2324 <filter_inet+0x154>
    2314:      	cmp	w9, #0x13
    2318:      	b.ne	0x2454 <filter_inet+0x284>
    231c:      	ldrh	w10, [x1, #0x22]
    2320:      	b	0x2328 <filter_inet+0x158>
    2324:      	ldrh	w10, [x1, #0x20]
    2328:      	mov	w19, wzr
    232c:      	mov	w20, wzr
    2330:      	mov	x21, xzr
    2334:      	str	w10, [sp, #0xc]
    2338:      	mov	x8, xzr
    233c:      	cmp	w9, #0x11
    2340:      	b.gt	0x23a0 <filter_inet+0x1d0>
    2344:      	sub	w10, w9, #0xd
    2348:      	cmp	w10, #0x2
    234c:      	b.lo	0x23d8 <filter_inet+0x208>
    2350:      	sub	w10, w9, #0xf
    2354:      	cmp	w10, #0x2
    2358:      	b.lo	0x244c <filter_inet+0x27c>
    235c:      	cmp	w9, #0x11
    2360:      	b.eq	0x2540 <filter_inet+0x370>
    2364:      	b	0x2454 <filter_inet+0x284>
    2368:      	cmp	w9, #0x1c
    236c:      	b.eq	0x2538 <filter_inet+0x368>
    2370:      	cmp	w9, #0x1d
    2374:      	b.ne	0x2454 <filter_inet+0x284>
    2378:      	cmp	w10, #0x7
    237c:      	b.ne	0x2590 <filter_inet+0x3c0>
    2380:      	cbnz	x11, 0x259c <filter_inet+0x3cc>
    2384:      	b	0x2540 <filter_inet+0x370>
    2388:      	ldp	w19, w20, [x1, #0x10]
    238c:      	ldr	x21, [x1, #0x18]
    2390:      	mov	w10, wzr
    2394:      	mov	x8, xzr
    2398:      	cmp	w9, #0x11
    239c:      	b.le	0x2344 <filter_inet+0x174>
    23a0:      	cmp	w9, #0x19
    23a4:      	b.hi	0x2440 <filter_inet+0x270>
    23a8:      	mov	w11, #0x1               // =1
    23ac:      	mov	w12, #0x500000          // =5242880
    23b0:      	lsl	w11, w11, w9
    23b4:      	tst	w11, w12
    23b8:      	b.ne	0x246c <filter_inet+0x29c>
    23bc:      	mov	w12, #0xa00000          // =10485760
    23c0:      	tst	w11, w12
    23c4:      	b.ne	0x248c <filter_inet+0x2bc>
    23c8:      	mov	w10, #0x1               // =1
    23cc:      	lsl	w10, w10, w9
    23d0:      	tst	w10, #0x3000000
    23d4:      	b.eq	0x2440 <filter_inet+0x270>
    23d8:      	ldrh	w8, [x1, #0x26]
    23dc:      	cmp	w8, #0xa
    23e0:      	b.eq	0x24ac <filter_inet+0x2dc>
    23e4:      	cmp	w8, #0x2
    23e8:      	b.ne	0x251c <filter_inet+0x34c>
    23ec:      	ldr	w8, [x0, #0x10]
    23f0:      	mov	x22, x0
    23f4:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    23f8:      	add	x9, sp, #0x5c
    23fc:      	str	w8, [sp, #0x5c]
    2400:      	mov	w8, #0x1                // =1
    2404:      	add	x1, sp, #0x5c
    2408:      	ldr	x0, [x0]
    240c:      	blr	x8
    2410:      	cbz	x0, 0x255c <filter_inet+0x38c>
    2414:      	mov	w8, #0x20               // =32
    2418:      	add	x1, sp, #0x3c
    241c:      	stp	w8, w19, [sp, #0x3c]
    2420:      	b	0x24ec <filter_inet+0x31c>
    2424:      	ldp	w19, w20, [x1]
    2428:      	ldr	x21, [x1, #0x8]
    242c:      	mov	w10, wzr
    2430:      	mov	x8, xzr
    2434:      	cmp	w9, #0x11
    2438:      	b.le	0x2344 <filter_inet+0x174>
    243c:      	b	0x23a0 <filter_inet+0x1d0>
    2440:      	sub	w9, w9, #0x12
    2444:      	cmp	w9, #0x2
    2448:      	b.hs	0x2454 <filter_inet+0x284>
    244c:      	add	x1, sp, #0xc
    2450:      	b	0x2544 <filter_inet+0x374>
    2454:      	ldp	x20, x19, [sp, #0x70]
    2458:      	mov	x0, x8
    245c:      	ldr	x30, [sp, #0x50]
    2460:      	ldp	x22, x21, [sp, #0x60]
    2464:      	add	sp, sp, #0x80
    2468:      	ret
    246c:      	cmp	w10, #0x400
    2470:      	cset	w8, lo
    2474:      	ldp	x20, x19, [sp, #0x70]
    2478:      	mov	x0, x8
    247c:      	ldr	x30, [sp, #0x50]
    2480:      	ldp	x22, x21, [sp, #0x60]
    2484:      	add	sp, sp, #0x80
    2488:      	ret
    248c:      	cmp	w10, #0x3ff
    2490:      	cset	w8, hi
    2494:      	ldp	x20, x19, [sp, #0x70]
    2498:      	mov	x0, x8
    249c:      	ldr	x30, [sp, #0x50]
    24a0:      	ldp	x22, x21, [sp, #0x60]
    24a4:      	add	sp, sp, #0x80
    24a8:      	ret
    24ac:      	ldr	w8, [x0, #0x14]
    24b0:      	mov	x22, x0
    24b4:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    24b8:      	add	x9, sp, #0x5c
    24bc:      	str	w8, [sp, #0x5c]
    24c0:      	mov	w8, #0x1                // =1
    24c4:      	add	x1, sp, #0x5c
    24c8:      	ldr	x0, [x0]
    24cc:      	blr	x8
    24d0:      	cbz	x0, 0x255c <filter_inet+0x38c>
    24d4:      	mov	w8, #0x80               // =128
    24d8:      	add	x1, sp, #0x3c
    24dc:      	stp	w20, w21, [sp, #0x44]
    24e0:      	stp	w8, w19, [sp, #0x3c]
    24e4:      	lsr	x8, x21, #32
    24e8:      	str	w8, [sp, #0x4c]
    24ec:      	mov	w8, #0x1                // =1
    24f0:      	blr	x8
    24f4:      	ldr	w8, [x22, #0x4]
    24f8:      	sub	w9, w8, #0x18
    24fc:      	cmp	w9, #0x2
    2500:      	b.lo	0x256c <filter_inet+0x39c>
    2504:      	sub	w8, w8, #0xd
    2508:      	cmp	w8, #0x1
    250c:      	b.hi	0x251c <filter_inet+0x34c>
    2510:      	cmp	x0, #0x0
    2514:      	cset	w8, ne
    2518:      	b	0x2574 <filter_inet+0x3a4>
    251c:      	mov	w8, wzr
    2520:      	ldp	x20, x19, [sp, #0x70]
    2524:      	mov	x0, x8
    2528:      	ldr	x30, [sp, #0x50]
    252c:      	ldp	x22, x21, [sp, #0x60]
    2530:      	add	sp, sp, #0x80
    2534:      	ret
    2538:      	ldrh	w8, [x1, #0x26]
    253c:      	str	w8, [sp, #0x58]
    2540:      	add	x1, sp, #0x58
    2544:      	bl	0xfc0 <filter_32ty_map>
    2548:      	ldp	x20, x19, [sp, #0x70]
    254c:      	ldr	x30, [sp, #0x50]
    2550:      	ldp	x22, x21, [sp, #0x60]
    2554:      	add	sp, sp, #0x80
    2558:      	ret
    255c:      	ldr	w8, [x22, #0x4]
    2560:      	and	w8, w8, #0xfffffffe
    2564:      	cmp	w8, #0x18
    2568:      	b	0x2570 <filter_inet+0x3a0>
    256c:      	cmp	x0, #0x0
    2570:      	cset	w8, eq
    2574:      	mov	w8, w8
    2578:      	ldp	x20, x19, [sp, #0x70]
    257c:      	mov	x0, x8
    2580:      	ldr	x30, [sp, #0x50]
    2584:      	ldp	x22, x21, [sp, #0x60]
    2588:      	add	sp, sp, #0x80
    258c:      	ret
    2590:      	cmp	w10, #0x29
    2594:      	b.ne	0x25a4 <filter_inet+0x3d4>
    2598:      	cbz	x11, 0x25a4 <filter_inet+0x3d4>
    259c:      	ldrb	w8, [x11, #0x3a]
    25a0:      	str	w8, [sp, #0x58]
    25a4:      	cmp	w10, #0x29
    25a8:      	b.eq	0x2540 <filter_inet+0x370>
    25ac:      	cmp	w10, #0x7
    25b0:      	b.eq	0x2540 <filter_inet+0x370>
    25b4:      	mov	x8, xzr
    25b8:      	ldp	x20, x19, [sp, #0x70]
    25bc:      	mov	x0, x8
    25c0:      	ldr	x30, [sp, #0x50]
    25c4:      	ldp	x22, x21, [sp, #0x60]
    25c8:      	add	sp, sp, #0x80
    25cc:      	ret

00000000000025d0 <filter_sockaddr_un>:
    25d0:      	sub	sp, sp, #0x20
    25d4:      	stp	x30, x19, [sp, #0x10]
    25d8:      	mov	x19, x0
    25dc:      	ldrb	w2, [x1, #0x3]
    25e0:      	mov	x0, xzr
    25e4:      	ldr	w8, [x19, #0x4]
    25e8:      	cmp	w8, #0x19
    25ec:      	b.gt	0x2640 <filter_sockaddr_un+0x70>
    25f0:      	sub	w9, w8, #0x3
    25f4:      	cmp	w9, #0x2
    25f8:      	b.hs	0x2654 <filter_sockaddr_un+0x84>
    25fc:      	add	x1, x1, #0x4
    2600:      	mov	x0, x19
    2604:      	bl	0x26c0 <filter_char_buf_equal>
    2608:      	ldr	w8, [x19, #0x4]
    260c:      	cmp	w8, #0x25
    2610:      	b.hi	0x2634 <filter_sockaddr_un+0x64>
    2614:      	mov	w9, #0x1                // =1
    2618:      	lsl	x8, x9, x8
    261c:      	mov	x9, #0x50               // =80
    2620:      	movk	x9, #0xc00, lsl #16
    2624:      	movk	x9, #0x20, lsl #32
    2628:      	tst	x8, x9
    262c:      	b.eq	0x2634 <filter_sockaddr_un+0x64>
    2630:      	eor	x0, x0, #0x1
    2634:      	ldp	x30, x19, [sp, #0x10]
    2638:      	add	sp, sp, #0x20
    263c:      	ret
    2640:      	cmp	w8, #0x1c
    2644:      	b.eq	0x26a0 <filter_sockaddr_un+0xd0>
    2648:      	cmp	w8, #0x1a
    264c:      	b.eq	0x265c <filter_sockaddr_un+0x8c>
    2650:      	b	0x2634 <filter_sockaddr_un+0x64>
    2654:      	cmp	w8, #0x8
    2658:      	b.ne	0x2634 <filter_sockaddr_un+0x64>
    265c:      	ldr	w0, [x19, #0x10]
    2660:      	add	x1, x1, #0x4
    2664:      	bl	0x2af0 <filter_char_buf_prefix>
    2668:      	ldr	w8, [x19, #0x4]
    266c:      	cmp	w8, #0x25
    2670:      	b.hi	0x2634 <filter_sockaddr_un+0x64>
    2674:      	mov	w9, #0x1                // =1
    2678:      	lsl	x8, x9, x8
    267c:      	mov	x9, #0x50               // =80
    2680:      	movk	x9, #0xc00, lsl #16
    2684:      	movk	x9, #0x20, lsl #32
    2688:      	tst	x8, x9
    268c:      	b.eq	0x2634 <filter_sockaddr_un+0x64>
    2690:      	eor	x0, x0, #0x1
    2694:      	ldp	x30, x19, [sp, #0x10]
    2698:      	add	sp, sp, #0x20
    269c:      	ret
    26a0:      	ldrh	w8, [x1]
    26a4:      	add	x1, sp, #0xc
    26a8:      	mov	x0, x19
    26ac:      	str	w8, [sp, #0xc]
    26b0:      	bl	0xfc0 <filter_32ty_map>
    26b4:      	ldp	x30, x19, [sp, #0x10]
    26b8:      	add	sp, sp, #0x20
    26bc:      	ret

00000000000026c0 <filter_char_buf_equal>:
    26c0:      	str	x29, [sp, #-0x50]!
    26c4:      	stp	x30, x25, [sp, #0x10]
    26c8:      	stp	x24, x23, [sp, #0x20]
    26cc:      	stp	x22, x21, [sp, #0x30]
    26d0:      	stp	x20, x19, [sp, #0x40]
    26d4:      	cmp	w2, #0x1, lsl #12       // =0x1000
    26d8:      	str	wzr, [sp, #0x8]
    26dc:      	b.ls	0x26fc <filter_char_buf_equal+0x3c>
    26e0:      	mov	x0, xzr
    26e4:      	ldp	x20, x19, [sp, #0x40]
    26e8:      	ldp	x22, x21, [sp, #0x30]
    26ec:      	ldp	x24, x23, [sp, #0x20]
    26f0:      	ldp	x30, x25, [sp, #0x10]
    26f4:      	ldr	x29, [sp], #0x50
    26f8:      	ret
    26fc:      	and	w9, w2, #0xffff
    2700:      	add	x8, x0, #0x10
    2704:      	cmp	w9, #0x90
    2708:      	b.hi	0x2778 <filter_char_buf_equal+0xb8>
    270c:      	and	w9, w2, #0xff
    2710:      	mov	w10, #0xab              // =171
    2714:      	tst	w2, #0xffff
    2718:      	mul	w9, w9, w10
    271c:      	mov	w10, #0x18              // =24
    2720:      	lsr	w9, w9, #12
    2724:      	msub	w9, w9, w10, w2
    2728:      	b.eq	0x2738 <filter_char_buf_equal+0x78>
    272c:      	tst	w9, #0xff
    2730:      	mov	w23, w2
    2734:      	b.eq	0x2750 <filter_char_buf_equal+0x90>
    2738:      	sub	w9, w2, w9, uxtb
    273c:      	and	w10, w9, #0xffff
    2740:      	add	w9, w9, #0x18
    2744:      	and	w23, w9, #0xffff
    2748:      	cmp	w10, #0x78
    274c:      	b.hi	0x27ec <filter_char_buf_equal+0x12c>
    2750:      	and	w9, w23, #0xff
    2754:      	mov	w10, #0xab              // =171
    2758:      	mul	w9, w9, w10
    275c:      	lsr	w9, w9, #12
    2760:      	sub	w22, w9, #0x1
    2764:      	and	w9, w22, #0xf
    2768:      	ldr	w24, [x8, w9, uxtw #2]
    276c:      	cmn	w24, #0x1
    2770:      	b.ne	0x2864 <filter_char_buf_equal+0x1a4>
    2774:      	b	0x2a0c <filter_char_buf_equal+0x34c>
    2778:      	cmp	w9, #0x101
    277c:      	b.hs	0x27bc <filter_char_buf_equal+0xfc>
    2780:      	mov	w23, #0x100             // =256
    2784:      	sub	w9, w23, #0x100
    2788:      	ror	w9, w9, #0x8
    278c:      	cmp	w9, #0x2
    2790:      	b.le	0x27fc <filter_char_buf_equal+0x13c>
    2794:      	cmp	w9, #0x3
    2798:      	b.eq	0x2838 <filter_char_buf_equal+0x178>
    279c:      	cmp	w9, #0x7
    27a0:      	b.ne	0x2820 <filter_char_buf_equal+0x160>
    27a4:      	mov	w22, #0x9               // =9
    27a8:      	and	w9, w22, #0xf
    27ac:      	ldr	w24, [x8, w9, uxtw #2]
    27b0:      	cmn	w24, #0x1
    27b4:      	b.ne	0x2864 <filter_char_buf_equal+0x1a4>
    27b8:      	b	0x2a0c <filter_char_buf_equal+0x34c>
    27bc:      	and	w9, w2, #0xffff
    27c0:      	cmp	w9, #0x201
    27c4:      	b.hs	0x27e0 <filter_char_buf_equal+0x120>
    27c8:      	mov	w23, #0x200             // =512
    27cc:      	sub	w9, w23, #0x100
    27d0:      	ror	w9, w9, #0x8
    27d4:      	cmp	w9, #0x2
    27d8:      	b.le	0x27fc <filter_char_buf_equal+0x13c>
    27dc:      	b	0x2794 <filter_char_buf_equal+0xd4>
    27e0:      	cmp	w9, #0x401
    27e4:      	b.hs	0x29c4 <filter_char_buf_equal+0x304>
    27e8:      	mov	w23, #0x400             // =1024
    27ec:      	sub	w9, w23, #0x100
    27f0:      	ror	w9, w9, #0x8
    27f4:      	cmp	w9, #0x2
    27f8:      	b.gt	0x2794 <filter_char_buf_equal+0xd4>
    27fc:      	cbz	w9, 0x2850 <filter_char_buf_equal+0x190>
    2800:      	cmp	w9, #0x1
    2804:      	b.ne	0x2820 <filter_char_buf_equal+0x160>
    2808:      	mov	w22, #0x7               // =7
    280c:      	and	w9, w22, #0xf
    2810:      	ldr	w24, [x8, w9, uxtw #2]
    2814:      	cmn	w24, #0x1
    2818:      	b.ne	0x2864 <filter_char_buf_equal+0x1a4>
    281c:      	b	0x2a0c <filter_char_buf_equal+0x34c>
    2820:      	mov	w22, #0xa               // =10
    2824:      	and	w9, w22, #0xf
    2828:      	ldr	w24, [x8, w9, uxtw #2]
    282c:      	cmn	w24, #0x1
    2830:      	b.ne	0x2864 <filter_char_buf_equal+0x1a4>
    2834:      	b	0x2a0c <filter_char_buf_equal+0x34c>
    2838:      	mov	w22, #0x8               // =8
    283c:      	and	w9, w22, #0xf
    2840:      	ldr	w24, [x8, w9, uxtw #2]
    2844:      	cmn	w24, #0x1
    2848:      	b.ne	0x2864 <filter_char_buf_equal+0x1a4>
    284c:      	b	0x2a0c <filter_char_buf_equal+0x34c>
    2850:      	mov	w22, #0x6               // =6
    2854:      	and	w9, w22, #0xf
    2858:      	ldr	w24, [x8, w9, uxtw #2]
    285c:      	cmn	w24, #0x1
    2860:      	b.eq	0x2a0c <filter_char_buf_equal+0x34c>
    2864:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2868:      	add	x29, sp, #0x8
    286c:      	mov	w8, #0x1                // =1
    2870:      	ldr	x0, [x0]
    2874:      	mov	x25, x1
    2878:      	add	x1, sp, #0x8
    287c:      	mov	w21, w2
    2880:      	mov	w20, #0x1               // =1
    2884:      	blr	x8
    2888:      	mov	x19, x0
    288c:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2890:      	add	x1, sp, #0x8
    2894:      	ldr	x0, [x0]
    2898:      	blr	x20
    289c:      	mov	x20, x0
    28a0:      	mov	x0, xzr
    28a4:      	cbz	x19, 0x26e4 <filter_char_buf_equal+0x24>
    28a8:      	cbz	x20, 0x26e4 <filter_char_buf_equal+0x24>
    28ac:      	mov	x0, x19
    28b0:      	cmp	w22, #0x5
    28b4:      	b.gt	0x28ec <filter_char_buf_equal+0x22c>
    28b8:      	strb	w21, [x0], #0x1
    28bc:      	mov	w29, w21
    28c0:      	mov	w8, #0x4                // =4
    28c4:      	mov	x2, x25
    28c8:      	mov	w1, w21
    28cc:      	blr	x8
    28d0:      	subs	w8, w23, w21
    28d4:      	b.ls	0x2924 <filter_char_buf_equal+0x264>
    28d8:      	add	x9, x19, x29
    28dc:      	and	w1, w8, #0xfff
    28e0:      	mov	w8, #0x4                // =4
    28e4:      	add	x0, x9, #0x1
    28e8:      	b	0x291c <filter_char_buf_equal+0x25c>
    28ec:      	strh	w21, [x0], #0x2
    28f0:      	mov	w29, w21
    28f4:      	mov	w8, #0x4                // =4
    28f8:      	mov	x2, x25
    28fc:      	mov	w1, w21
    2900:      	blr	x8
    2904:      	subs	w8, w23, w21
    2908:      	b.ls	0x2924 <filter_char_buf_equal+0x264>
    290c:      	add	x9, x19, x29
    2910:      	and	w1, w8, #0xfff
    2914:      	mov	w8, #0x4                // =4
    2918:      	add	x0, x9, #0x2
    291c:      	mov	x2, x20
    2920:      	blr	x8
    2924:      	cmp	w22, #0x4
    2928:      	str	w24, [sp, #0xc]
    292c:      	b.le	0x2964 <filter_char_buf_equal+0x2a4>
    2930:      	cmp	w22, #0x7
    2934:      	b.gt	0x2998 <filter_char_buf_equal+0x2d8>
    2938:      	cmp	w22, #0x5
    293c:      	b.eq	0x2a8c <filter_char_buf_equal+0x3cc>
    2940:      	cmp	w22, #0x6
    2944:      	b.eq	0x2a50 <filter_char_buf_equal+0x390>
    2948:      	cmp	w22, #0x7
    294c:      	b.ne	0x2a0c <filter_char_buf_equal+0x34c>
    2950:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2954:      	mov	w8, #0x1                // =1
    2958:      	add	x9, sp, #0xc
    295c:      	ldr	x0, [x0]
    2960:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2964:      	cmp	w22, #0x1
    2968:      	b.le	0x29ec <filter_char_buf_equal+0x32c>
    296c:      	cmp	w22, #0x2
    2970:      	b.eq	0x2a78 <filter_char_buf_equal+0x3b8>
    2974:      	cmp	w22, #0x3
    2978:      	b.eq	0x2a3c <filter_char_buf_equal+0x37c>
    297c:      	cmp	w22, #0x4
    2980:      	b.ne	0x2a0c <filter_char_buf_equal+0x34c>
    2984:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2988:      	mov	w8, #0x1                // =1
    298c:      	add	x9, sp, #0xc
    2990:      	ldr	x0, [x0]
    2994:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2998:      	cmp	w22, #0x8
    299c:      	b.eq	0x2aa0 <filter_char_buf_equal+0x3e0>
    29a0:      	cmp	w22, #0x9
    29a4:      	b.eq	0x2a64 <filter_char_buf_equal+0x3a4>
    29a8:      	cmp	w22, #0xa
    29ac:      	b.ne	0x2a0c <filter_char_buf_equal+0x34c>
    29b0:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    29b4:      	mov	w8, #0x1                // =1
    29b8:      	add	x9, sp, #0xc
    29bc:      	ldr	x0, [x0]
    29c0:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    29c4:      	and	w9, w2, #0xffff
    29c8:      	mov	w10, #0x1000            // =4096
    29cc:      	cmp	w9, #0x800
    29d0:      	mov	w9, #0x800              // =2048
    29d4:      	csel	w23, w10, w9, hi
    29d8:      	sub	w9, w23, #0x100
    29dc:      	ror	w9, w9, #0x8
    29e0:      	cmp	w9, #0x2
    29e4:      	b.le	0x27fc <filter_char_buf_equal+0x13c>
    29e8:      	b	0x2794 <filter_char_buf_equal+0xd4>
    29ec:      	cbz	w22, 0x2a28 <filter_char_buf_equal+0x368>
    29f0:      	cmp	w22, #0x1
    29f4:      	b.ne	0x2a0c <filter_char_buf_equal+0x34c>
    29f8:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    29fc:      	mov	w8, #0x1                // =1
    2a00:      	add	x9, sp, #0xc
    2a04:      	ldr	x0, [x0]
    2a08:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2a0c:      	mov	x0, xzr
    2a10:      	ldp	x20, x19, [sp, #0x40]
    2a14:      	ldp	x22, x21, [sp, #0x30]
    2a18:      	ldp	x24, x23, [sp, #0x20]
    2a1c:      	ldp	x30, x25, [sp, #0x10]
    2a20:      	ldr	x29, [sp], #0x50
    2a24:      	ret
    2a28:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2a2c:      	mov	w8, #0x1                // =1
    2a30:      	add	x9, sp, #0xc
    2a34:      	ldr	x0, [x0]
    2a38:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2a3c:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2a40:      	mov	w8, #0x1                // =1
    2a44:      	add	x9, sp, #0xc
    2a48:      	ldr	x0, [x0]
    2a4c:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2a50:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2a54:      	mov	w8, #0x1                // =1
    2a58:      	add	x9, sp, #0xc
    2a5c:      	ldr	x0, [x0]
    2a60:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2a64:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2a68:      	mov	w8, #0x1                // =1
    2a6c:      	add	x9, sp, #0xc
    2a70:      	ldr	x0, [x0]
    2a74:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2a78:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2a7c:      	mov	w8, #0x1                // =1
    2a80:      	add	x9, sp, #0xc
    2a84:      	ldr	x0, [x0]
    2a88:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2a8c:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2a90:      	mov	w8, #0x1                // =1
    2a94:      	add	x9, sp, #0xc
    2a98:      	ldr	x0, [x0]
    2a9c:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2aa0:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2aa4:      	mov	w8, #0x1                // =1
    2aa8:      	add	x9, sp, #0xc
    2aac:      	ldr	x0, [x0]
    2ab0:      	add	x1, sp, #0xc
    2ab4:      	blr	x8
    2ab8:      	cbz	x0, 0x26e4 <filter_char_buf_equal+0x24>
    2abc:      	mov	w8, #0x1                // =1
    2ac0:      	mov	x1, x19
    2ac4:      	blr	x8
    2ac8:      	cmp	x0, #0x0
    2acc:      	cset	w0, ne
    2ad0:      	ldp	x20, x19, [sp, #0x40]
    2ad4:      	ldp	x22, x21, [sp, #0x30]
    2ad8:      	ldp	x24, x23, [sp, #0x20]
    2adc:      	ldp	x30, x25, [sp, #0x10]
    2ae0:      	ldr	x29, [sp], #0x50
    2ae4:      	ret
    2ae8:      	nop
    2aec:      	nop

0000000000002af0 <filter_char_buf_prefix>:
    2af0:      	sub	sp, sp, #0x30
    2af4:      	stp	x30, x21, [sp, #0x10]
    2af8:      	stp	x20, x19, [sp, #0x20]
    2afc:      	stp	wzr, w0, [sp, #0x8]
    2b00:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2b04:      	mov	w8, #0x1                // =1
    2b08:      	add	x9, sp, #0xc
    2b0c:      	ldr	x0, [x0]
    2b10:      	mov	x19, x1
    2b14:      	add	x1, sp, #0xc
    2b18:      	mov	w20, w2
    2b1c:      	blr	x8
    2b20:      	mov	x8, x0
    2b24:      	mov	x0, xzr
    2b28:      	cbz	w20, 0x2b94 <filter_char_buf_prefix+0xa4>
    2b2c:      	cbz	x8, 0x2b94 <filter_char_buf_prefix+0xa4>
    2b30:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2b34:      	mov	x21, x8
    2b38:      	mov	w8, #0x1                // =1
    2b3c:      	ldr	x0, [x0]
    2b40:      	add	x9, sp, #0x8
    2b44:      	add	x1, sp, #0x8
    2b48:      	blr	x8
    2b4c:      	cbz	x0, 0x2b94 <filter_char_buf_prefix+0xa4>
    2b50:      	cmp	w20, #0xff
    2b54:      	mov	w8, #0xff               // =255
    2b58:      	mov	x2, x19
    2b5c:      	csel	w1, w20, w8, lo
    2b60:      	mov	x8, x0
    2b64:      	mov	x20, x0
    2b68:      	lsl	w9, w1, #3
    2b6c:      	str	w9, [x8], #0x4
    2b70:      	mov	w9, #0x4                // =4
    2b74:      	mov	x0, x8
    2b78:      	blr	x9
    2b7c:      	mov	w8, #0x1                // =1
    2b80:      	mov	x0, x21
    2b84:      	mov	x1, x20
    2b88:      	blr	x8
    2b8c:      	cmp	x0, #0x0
    2b90:      	cset	w0, ne
    2b94:      	ldp	x20, x19, [sp, #0x20]
    2b98:      	ldp	x30, x21, [sp, #0x10]
    2b9c:      	add	sp, sp, #0x30
    2ba0:      	ret
    2ba4:      	nop
    2ba8:      	nop
    2bac:      	nop

0000000000002bb0 <filter_char_buf_postfix>:
    2bb0:      	sub	sp, sp, #0x30
    2bb4:      	stp	x30, x21, [sp, #0x10]
    2bb8:      	stp	x20, x19, [sp, #0x20]
    2bbc:      	stp	wzr, w0, [sp, #0x8]
    2bc0:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2bc4:      	mov	w8, #0x1                // =1
    2bc8:      	add	x9, sp, #0xc
    2bcc:      	ldr	x0, [x0]
    2bd0:      	mov	x19, x1
    2bd4:      	add	x1, sp, #0xc
    2bd8:      	mov	w20, w2
    2bdc:      	blr	x8
    2be0:      	mov	x8, x0
    2be4:      	mov	x0, xzr
    2be8:      	cbz	w20, 0x2c7c <filter_char_buf_postfix+0xcc>
    2bec:      	cbz	x8, 0x2c7c <filter_char_buf_postfix+0xcc>
    2bf0:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2bf4:      	mov	x21, x8
    2bf8:      	mov	w8, #0x1                // =1
    2bfc:      	ldr	x0, [x0]
    2c00:      	add	x9, sp, #0x8
    2c04:      	add	x1, sp, #0x8
    2c08:      	blr	x8
    2c0c:      	cbz	x0, 0x2c7c <filter_char_buf_postfix+0xcc>
    2c10:      	cmp	w20, #0x7f
    2c14:      	mov	w9, #0x7f               // =127
    2c18:      	mov	x1, x0
    2c1c:      	mov	x8, xzr
    2c20:      	sub	w10, w20, #0x1
    2c24:      	csel	w9, w20, w9, lo
    2c28:      	lsl	w9, w9, #3
    2c2c:      	str	w9, [x0]
    2c30:      	mov	w9, w20
    2c34:      	nop
    2c38:      	nop
    2c3c:      	nop
    2c40:      	cmp	x8, #0x7f
    2c44:      	b.eq	0x2c68 <filter_char_buf_postfix+0xb8>
    2c48:      	and	x11, x10, #0xfff
    2c4c:      	add	x12, x1, x8
    2c50:      	add	x8, x8, #0x1
    2c54:      	ldrb	w11, [x19, x11]
    2c58:      	sub	w10, w10, #0x1
    2c5c:      	cmp	x9, x8
    2c60:      	strb	w11, [x12, #0x4]
    2c64:      	b.ne	0x2c40 <filter_char_buf_postfix+0x90>
    2c68:      	mov	w8, #0x1                // =1
    2c6c:      	mov	x0, x21
    2c70:      	blr	x8
    2c74:      	cmp	x0, #0x0
    2c78:      	cset	w0, ne
    2c7c:      	ldp	x20, x19, [sp, #0x20]
    2c80:      	ldp	x30, x21, [sp, #0x10]
    2c84:      	add	sp, sp, #0x30
    2c88:      	ret
    2c8c:      	nop

0000000000002c90 <filter_file_type>:
    2c90:      	sub	sp, sp, #0x20
    2c94:      	stp	x30, x19, [sp, #0x10]
    2c98:      	ldr	w8, [x1]
    2c9c:      	strh	wzr, [sp, #0xc]
    2ca0:      	cmp	w8, #0x1, lsl #12       // =0x1000
    2ca4:      	b.hi	0x2d7c <filter_file_type+0xec>
    2ca8:      	add	x9, x1, #0x4
    2cac:      	mov	w10, #0x2               // =2
    2cb0:      	mov	w11, #0x4               // =4
    2cb4:      	add	x12, sp, #0xc
    2cb8:      	mov	x19, x0
    2cbc:      	add	x0, sp, #0xc
    2cc0:      	add	x8, x9, x8
    2cc4:      	add	x8, x8, #0x4
    2cc8:      	ldr	w8, [x1]
    2ccc:      	mov	w1, #0x2                // =2
    2cd0:      	add	x8, x9, x8
    2cd4:      	add	x2, x8, #0x4
    2cd8:      	blr	x11
    2cdc:      	ldr	w9, [x19, #0x10]
    2ce0:      	cbz	w9, 0x2d7c <filter_file_type+0xec>
    2ce4:      	ldrh	w8, [sp, #0xc]
    2ce8:      	and	w8, w8, #0xf000
    2cec:      	cmp	w9, w8
    2cf0:      	b.ne	0x2d04 <filter_file_type+0x74>
    2cf4:      	mov	w0, #0x1                // =1
    2cf8:      	ldp	x30, x19, [sp, #0x10]
    2cfc:      	add	sp, sp, #0x20
    2d00:      	ret
    2d04:      	ldr	w9, [x19, #0x8]
    2d08:      	cmp	w9, #0xc
    2d0c:      	b.ls	0x2d7c <filter_file_type+0xec>
    2d10:      	ldr	w10, [x19, #0x14]
    2d14:      	cbz	w10, 0x2d7c <filter_file_type+0xec>
    2d18:      	cmp	w10, w8
    2d1c:      	b.ne	0x2d30 <filter_file_type+0xa0>
    2d20:      	mov	w0, #0x1                // =1
    2d24:      	ldp	x30, x19, [sp, #0x10]
    2d28:      	add	sp, sp, #0x20
    2d2c:      	ret
    2d30:      	cmp	w9, #0x11
    2d34:      	b.lo	0x2d7c <filter_file_type+0xec>
    2d38:      	ldr	w10, [x19, #0x18]
    2d3c:      	cbz	w10, 0x2d7c <filter_file_type+0xec>
    2d40:      	cmp	w10, w8
    2d44:      	b.ne	0x2d58 <filter_file_type+0xc8>
    2d48:      	mov	w0, #0x1                // =1
    2d4c:      	ldp	x30, x19, [sp, #0x10]
    2d50:      	add	sp, sp, #0x20
    2d54:      	ret
    2d58:      	cmp	w9, #0x15
    2d5c:      	b.lo	0x2d7c <filter_file_type+0xec>
    2d60:      	ldr	w9, [x19, #0x1c]
    2d64:      	cbz	w9, 0x2d7c <filter_file_type+0xec>
    2d68:      	cmp	w9, w8
    2d6c:      	cset	w0, eq
    2d70:      	ldp	x30, x19, [sp, #0x10]
    2d74:      	add	sp, sp, #0x20
    2d78:      	ret
    2d7c:      	mov	x0, xzr
    2d80:      	ldp	x30, x19, [sp, #0x10]
    2d84:      	add	sp, sp, #0x20
    2d88:      	ret
    2d8c:      	nop

0000000000002d90 <filter_char_substring>:
    2d90:      	str	x29, [sp, #-0x50]!
    2d94:      	stp	x30, x25, [sp, #0x10]
    2d98:      	stp	x24, x23, [sp, #0x20]
    2d9c:      	stp	x22, x21, [sp, #0x30]
    2da0:      	stp	x20, x19, [sp, #0x40]
    2da4:      	mov	x21, x1
    2da8:      	mov	x19, x0
    2dac:      	add	x23, x0, #0x10
    2db0:      	mov	w24, w2
    2db4:      	tbz	w3, #0x0, 0x2ea8 <filter_char_substring+0x118>
    2db8:      	cbz	w2, 0x2f68 <filter_char_substring+0x1d8>
    2dbc:      	adrp	x22, 0x2000 <filter_file_buf+0x50>
    2dc0:      	mov	x25, xzr
    2dc4:      	mov	w29, wzr
    2dc8:      	ldr	x22, [x22]
    2dcc:      	add	x20, sp, #0xc
    2dd0:      	nop
    2dd4:      	nop
    2dd8:      	nop
    2ddc:      	nop
    2de0:      	ldr	w8, [x23, x25, lsl #2]
    2de4:      	add	x1, sp, #0xc
    2de8:      	mov	x0, x22
    2dec:      	str	w8, [sp, #0xc]
    2df0:      	mov	w8, #0x1                // =1
    2df4:      	blr	x8
    2df8:      	cbz	x0, 0x3008 <filter_char_substring+0x278>
    2dfc:      	mov	x8, xzr
    2e00:      	mov	x9, x21
    2e04:      	mov	x10, x24
    2e08:      	b	0x2e20 <filter_char_substring+0x90>
    2e0c:      	add	x8, x8, #0x1
    2e10:      	sub	x10, x10, #0x1
    2e14:      	add	x9, x9, #0x1
    2e18:      	cmp	x8, x24
    2e1c:      	b.eq	0x2e84 <filter_char_substring+0xf4>
    2e20:      	mov	x11, xzr
    2e24:      	cmp	x10, x11
    2e28:      	b.eq	0x2e0c <filter_char_substring+0x7c>
    2e2c:      	ldrb	w12, [x0, x11]
    2e30:      	cbz	w12, 0x2e80 <filter_char_substring+0xf0>
    2e34:      	ldrb	w13, [x9, x11]
    2e38:      	sub	w14, w13, #0x41
    2e3c:      	orr	w15, w13, #0x20
    2e40:      	cmp	w14, #0x1a
    2e44:      	sub	w14, w12, #0x41
    2e48:      	csel	w13, w15, w13, lo
    2e4c:      	orr	w15, w12, #0x20
    2e50:      	cmp	w14, #0x1a
    2e54:      	csel	w12, w15, w12, lo
    2e58:      	cmp	x11, #0x62
    2e5c:      	b.hi	0x2e0c <filter_char_substring+0x7c>
    2e60:      	add	x11, x11, #0x1
    2e64:      	cmp	w13, w12
    2e68:      	b.eq	0x2e24 <filter_char_substring+0x94>
    2e6c:      	b	0x2e0c <filter_char_substring+0x7c>
    2e70:      	nop
    2e74:      	nop
    2e78:      	nop
    2e7c:      	nop
    2e80:      	tbz	w8, #0x1f, 0x3020 <filter_char_substring+0x290>
    2e84:      	ldr	w9, [x19, #0x8]
    2e88:      	add	w8, w29, #0xc
    2e8c:      	cmp	w8, w9
    2e90:      	b.hs	0x3004 <filter_char_substring+0x274>
    2e94:      	add	x25, x25, #0x1
    2e98:      	add	w29, w29, #0x4
    2e9c:      	cmp	x25, #0x64
    2ea0:      	b.ne	0x2de0 <filter_char_substring+0x50>
    2ea4:      	b	0x3004 <filter_char_substring+0x274>
    2ea8:      	cbz	w2, 0x2fbc <filter_char_substring+0x22c>
    2eac:      	adrp	x22, 0x2000 <filter_file_buf+0x50>
    2eb0:      	mov	x25, xzr
    2eb4:      	mov	w29, wzr
    2eb8:      	ldr	x22, [x22]
    2ebc:      	add	x20, sp, #0xc
    2ec0:      	ldr	w8, [x23, x25, lsl #2]
    2ec4:      	add	x1, sp, #0xc
    2ec8:      	mov	x0, x22
    2ecc:      	str	w8, [sp, #0xc]
    2ed0:      	mov	w8, #0x1                // =1
    2ed4:      	blr	x8
    2ed8:      	cbz	x0, 0x3008 <filter_char_substring+0x278>
    2edc:      	mov	x8, xzr
    2ee0:      	mov	x9, x21
    2ee4:      	mov	x10, x24
    2ee8:      	b	0x2f00 <filter_char_substring+0x170>
    2eec:      	add	x8, x8, #0x1
    2ef0:      	sub	x10, x10, #0x1
    2ef4:      	add	x9, x9, #0x1
    2ef8:      	cmp	x8, x24
    2efc:      	b.eq	0x2f44 <filter_char_substring+0x1b4>
    2f00:      	mov	x11, xzr
    2f04:      	cmp	x10, x11
    2f08:      	b.eq	0x2eec <filter_char_substring+0x15c>
    2f0c:      	ldrb	w12, [x0, x11]
    2f10:      	cbz	w12, 0x2f40 <filter_char_substring+0x1b0>
    2f14:      	cmp	x11, #0x62
    2f18:      	b.hi	0x2eec <filter_char_substring+0x15c>
    2f1c:      	ldrb	w13, [x9, x11]
    2f20:      	add	x11, x11, #0x1
    2f24:      	cmp	w13, w12
    2f28:      	b.eq	0x2f04 <filter_char_substring+0x174>
    2f2c:      	b	0x2eec <filter_char_substring+0x15c>
    2f30:      	nop
    2f34:      	nop
    2f38:      	nop
    2f3c:      	nop
    2f40:      	tbz	w8, #0x1f, 0x3020 <filter_char_substring+0x290>
    2f44:      	ldr	w9, [x19, #0x8]
    2f48:      	add	w8, w29, #0xc
    2f4c:      	cmp	w8, w9
    2f50:      	b.hs	0x3004 <filter_char_substring+0x274>
    2f54:      	add	x25, x25, #0x1
    2f58:      	add	w29, w29, #0x4
    2f5c:      	cmp	x25, #0x64
    2f60:      	b.ne	0x2ec0 <filter_char_substring+0x130>
    2f64:      	b	0x3004 <filter_char_substring+0x274>
    2f68:      	adrp	x20, 0x2000 <filter_file_buf+0x50>
    2f6c:      	mov	w21, #0x10              // =16
    2f70:      	add	x22, sp, #0xc
    2f74:      	ldr	x20, [x20]
    2f78:      	nop
    2f7c:      	nop
    2f80:      	ldr	w8, [x19, x21]
    2f84:      	add	x1, sp, #0xc
    2f88:      	mov	x0, x20
    2f8c:      	str	w8, [sp, #0xc]
    2f90:      	mov	w8, #0x1                // =1
    2f94:      	blr	x8
    2f98:      	cbz	x0, 0x3008 <filter_char_substring+0x278>
    2f9c:      	ldr	w8, [x19, #0x8]
    2fa0:      	add	x21, x21, #0x4
    2fa4:      	sub	w9, w21, #0x8
    2fa8:      	cmp	w9, w8
    2fac:      	b.hs	0x3004 <filter_char_substring+0x274>
    2fb0:      	cmp	x21, #0x1a0
    2fb4:      	b.ne	0x2f80 <filter_char_substring+0x1f0>
    2fb8:      	b	0x3004 <filter_char_substring+0x274>
    2fbc:      	adrp	x20, 0x2000 <filter_file_buf+0x50>
    2fc0:      	mov	w21, #0x10              // =16
    2fc4:      	add	x22, sp, #0xc
    2fc8:      	ldr	x20, [x20]
    2fcc:      	ldr	w8, [x19, x21]
    2fd0:      	add	x1, sp, #0xc
    2fd4:      	mov	x0, x20
    2fd8:      	str	w8, [sp, #0xc]
    2fdc:      	mov	w8, #0x1                // =1
    2fe0:      	blr	x8
    2fe4:      	cbz	x0, 0x3008 <filter_char_substring+0x278>
    2fe8:      	ldr	w8, [x19, #0x8]
    2fec:      	add	x21, x21, #0x4
    2ff0:      	sub	w9, w21, #0x8
    2ff4:      	cmp	w9, w8
    2ff8:      	b.hs	0x3004 <filter_char_substring+0x274>
    2ffc:      	cmp	x21, #0x1a0
    3000:      	b.ne	0x2fcc <filter_char_substring+0x23c>
    3004:      	mov	x0, xzr
    3008:      	ldp	x20, x19, [sp, #0x40]
    300c:      	ldp	x22, x21, [sp, #0x30]
    3010:      	ldp	x24, x23, [sp, #0x20]
    3014:      	ldp	x30, x25, [sp, #0x10]
    3018:      	ldr	x29, [sp], #0x50
    301c:      	ret
    3020:      	mov	w0, #0x1                // =1
    3024:      	ldp	x20, x19, [sp, #0x40]
    3028:      	ldp	x22, x21, [sp, #0x30]
    302c:      	ldp	x24, x23, [sp, #0x20]
    3030:      	ldp	x30, x25, [sp, #0x10]
    3034:      	ldr	x29, [sp], #0x50
    3038:      	ret
    303c:      	nop

0000000000003040 <do_action>:
    3040:      	sub	sp, sp, #0xc0
    3044:      	str	x29, [sp, #0x70]
    3048:      	stp	x30, x25, [sp, #0x80]
    304c:      	stp	x24, x23, [sp, #0x90]
    3050:      	stp	x22, x21, [sp, #0xa0]
    3054:      	stp	x20, x19, [sp, #0xb0]
    3058:      	add	x8, x2, w1, uxtw #2
    305c:      	str	wzr, [sp, #0x44]
    3060:      	adrp	x24, 0x3000 <filter_char_substring+0x270>
    3064:      	add	x9, sp, #0x44
    3068:      	mov	w20, w1
    306c:      	ldrsw	x22, [x8, #0x4]
    3070:      	ldr	x24, [x24]
    3074:      	mov	w8, #0x1                // =1
    3078:      	mov	x19, x0
    307c:      	add	x1, sp, #0x44
    3080:      	mov	w25, w4
    3084:      	mov	x23, x3
    3088:      	mov	x21, x2
    308c:      	mov	x0, x24
    3090:      	blr	x8
    3094:      	cbz	x0, 0x3abc <do_action+0xa7c>
    3098:      	mov	x29, x0
    309c:      	cmp	w22, #0x7
    30a0:      	b.gt	0x30c4 <do_action+0x84>
    30a4:      	cmp	w22, #0x3
    30a8:      	b.gt	0x3110 <do_action+0xd0>
    30ac:      	cmp	w22, #0x1
    30b0:      	b.gt	0x331c <do_action+0x2dc>
    30b4:      	cbz	w22, 0x3510 <do_action+0x4d0>
    30b8:      	cmp	w22, #0x1
    30bc:      	b.eq	0x332c <do_action+0x2ec>
    30c0:      	b	0x3ab4 <do_action+0xa74>
    30c4:      	cmp	w22, #0xb
    30c8:      	b.gt	0x3214 <do_action+0x1d4>
    30cc:      	sub	w8, w22, #0xa
    30d0:      	cmp	w8, #0x2
    30d4:      	b.lo	0x341c <do_action+0x3dc>
    30d8:      	cmp	w22, #0x8
    30dc:      	b.eq	0x3468 <do_action+0x428>
    30e0:      	cmp	w22, #0x9
    30e4:      	b.ne	0x3ab4 <do_action+0xa74>
    30e8:      	add	w20, w20, #0x1
    30ec:      	add	x8, x21, w20, uxtw #2
    30f0:      	ldr	w0, [x8, #0x4]
    30f4:      	tbz	w25, #0x0, 0x35bc <do_action+0x57c>
    30f8:      	sxtw	x8, w0
    30fc:      	mov	w9, #0x6d               // =109
    3100:      	blr	x9
    3104:      	mov	w19, #0x2               // =2
    3108:      	mov	w23, w20
    310c:      	b	0x3a6c <do_action+0xa2c>
    3110:      	sub	w8, w22, #0x6
    3114:      	cmp	w8, #0x2
    3118:      	b.lo	0x3454 <do_action+0x414>
    311c:      	cmp	w22, #0x4
    3120:      	b.eq	0x3470 <do_action+0x430>
    3124:      	cmp	w22, #0x5
    3128:      	b.ne	0x3ab4 <do_action+0xa74>
    312c:      	add	w9, w20, #0x1
    3130:      	add	x8, x21, #0x4
    3134:      	add	w20, w20, #0x2
    3138:      	ldr	w9, [x8, w9, uxtw #2]
    313c:      	and	x9, x9, #0x7
    3140:      	cmp	w9, #0x4
    3144:      	b.hi	0x3ab4 <do_action+0xa74>
    3148:      	add	x10, x29, x9, lsl #2
    314c:      	mov	w11, #0x5ea0            // =24224
    3150:      	ldr	w10, [x10, x11]
    3154:      	cbnz	w10, 0x3ab4 <do_action+0xa74>
    3158:      	ldr	w19, [x8, w20, uxtw #2]
    315c:      	add	x8, x29, x9, lsl #3
    3160:      	ldr	x8, [x8, #0x5e78]
    3164:      	str	wzr, [sp, #0x5c]
    3168:      	and	x8, x8, #0x7ff
    316c:      	add	x8, x29, x8
    3170:      	ldr	w8, [x8, #0x90]
    3174:      	str	w8, [sp, #0x58]
    3178:      	mov	w8, #0xe                // =14
    317c:      	blr	x8
    3180:      	lsr	x8, x0, #32
    3184:      	adrp	x21, 0x3000 <filter_char_substring+0x270>
    3188:      	add	x9, sp, #0x50
    318c:      	str	x8, [sp, #0x50]
    3190:      	mov	w8, #0x1                // =1
    3194:      	add	x1, sp, #0x50
    3198:      	ldr	x21, [x21]
    319c:      	mov	x0, x21
    31a0:      	blr	x8
    31a4:      	cbz	x0, 0x3ab4 <do_action+0xa74>
    31a8:      	and	x8, x19, #0x7
    31ac:      	cmp	w8, #0x4
    31b0:      	b.hi	0x3ab4 <do_action+0xa74>
    31b4:      	add	x9, x29, x8, lsl #2
    31b8:      	mov	w10, #0x5ea0            // =24224
    31bc:      	ldr	w9, [x9, x10]
    31c0:      	cbnz	w9, 0x3ab4 <do_action+0xa74>
    31c4:      	add	x8, x29, x8, lsl #3
    31c8:      	mov	x23, x0
    31cc:      	ldr	x8, [x8, #0x5e78]
    31d0:      	str	wzr, [sp, #0x5c]
    31d4:      	and	x8, x8, #0x7ff
    31d8:      	add	x8, x29, x8
    31dc:      	ldr	w8, [x8, #0x90]
    31e0:      	str	w8, [sp, #0x58]
    31e4:      	mov	w8, #0xe                // =14
    31e8:      	blr	x8
    31ec:      	lsr	x8, x0, #32
    31f0:      	mov	x3, xzr
    31f4:      	add	x9, sp, #0x50
    31f8:      	str	x8, [sp, #0x50]
    31fc:      	mov	w8, #0x2                // =2
    3200:      	add	x1, sp, #0x50
    3204:      	mov	x0, x21
    3208:      	mov	x2, x23
    320c:      	blr	x8
    3210:      	b	0x3ab4 <do_action+0xa74>
    3214:      	cmp	w22, #0xc
    3218:      	b.eq	0x35c8 <do_action+0x588>
    321c:      	cmp	w22, #0xd
    3220:      	b.eq	0x3484 <do_action+0x444>
    3224:      	cmp	w22, #0xe
    3228:      	b.ne	0x3ab4 <do_action+0xa74>
    322c:      	add	w23, w20, #0x2
    3230:      	tbz	w25, #0x0, 0x35dc <do_action+0x59c>
    3234:      	add	x8, x21, #0x4
    3238:      	add	w9, w20, #0x1
    323c:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    3240:      	ldr	w20, [x8, w9, uxtw #2]
    3244:      	mov	x24, x19
    3248:      	ldr	w19, [x8, w23, uxtw #2]
    324c:      	mov	w8, #0x5ef8             // =24312
    3250:      	ldr	x0, [x0]
    3254:      	add	x1, x29, x8
    3258:      	mov	w8, #0x1                // =1
    325c:      	blr	x8
    3260:      	cbz	x0, 0x3a68 <do_action+0xa28>
    3264:      	and	x8, x20, #0x7
    3268:      	mov	w9, #0x18               // =24
    326c:      	umaddl	x9, w8, w9, x0
    3270:      	ldrb	w9, [x9, #0x211]
    3274:      	cmp	w9, #0x3
    3278:      	b.ne	0x36ec <do_action+0x6ac>
    327c:      	mov	w9, #0x18               // =24
    3280:      	mov	w2, wzr
    3284:      	umaddl	x20, w8, w9, x0
    3288:      	mov	x0, x24
    328c:      	ldr	w1, [x20, #0x208]
    3290:      	bl	0x3ae0 <read_reg>
    3294:      	ldr	x8, [x20, #0x200]
    3298:      	str	w19, [sp, #0x58]
    329c:      	add	x8, x0, x8
    32a0:      	str	x8, [sp, #0x50]
    32a4:      	mov	w8, #0xe                // =14
    32a8:      	blr	x8
    32ac:      	str	x0, [sp, #0x48]
    32b0:      	adrp	x21, 0x3000 <filter_char_substring+0x270>
    32b4:      	mov	w8, #0x1                // =1
    32b8:      	add	x9, sp, #0x48
    32bc:      	ldr	x21, [x21]
    32c0:      	add	x1, sp, #0x48
    32c4:      	mov	x0, x21
    32c8:      	blr	x8
    32cc:      	cbz	x0, 0x39c0 <do_action+0x980>
    32d0:      	mov	w8, #0x11               // =17
    32d4:      	adrp	x21, 0x3000 <filter_char_substring+0x270>
    32d8:      	mov	w9, #0x1                // =1
    32dc:      	mov	x20, x0
    32e0:      	add	x1, sp, #0x60
    32e4:      	mov	w19, #0x1               // =1
    32e8:      	movk	w8, #0xe, lsl #16
    32ec:      	str	w8, [sp, #0x60]
    32f0:      	mov	w8, #0x377              // =887
    32f4:      	stur	x8, [sp, #0x64]
    32f8:      	add	x8, sp, #0x60
    32fc:      	ldr	x21, [x21]
    3300:      	mov	x0, x21
    3304:      	blr	x9
    3308:      	cbz	x0, 0x3a3c <do_action+0x9fc>
    330c:      	ldr	w8, [x0]
    3310:      	add	w8, w8, #0x1
    3314:      	str	w8, [x0]
    3318:      	b	0x3a60 <do_action+0xa20>
    331c:      	cmp	w22, #0x2
    3320:      	b.eq	0x35b4 <do_action+0x574>
    3324:      	cmp	w22, #0x3
    3328:      	b.ne	0x3ab4 <do_action+0xa74>
    332c:      	add	w8, w20, #0x1
    3330:      	add	x9, x21, #0x4
    3334:      	add	w20, w20, #0x2
    3338:      	str	wzr, [sp, #0x60]
    333c:      	ldr	w21, [x9, w8, uxtw #2]
    3340:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    3344:      	ldr	w19, [x9, w20, uxtw #2]
    3348:      	ldr	x0, [x0]
    334c:      	mov	w8, #0x1                // =1
    3350:      	add	x9, sp, #0x60
    3354:      	add	x1, sp, #0x60
    3358:      	blr	x8
    335c:      	cbz	x0, 0x3448 <do_action+0x408>
    3360:      	and	x8, x21, #0x7
    3364:      	cmp	w8, #0x4
    3368:      	b.hi	0x3444 <do_action+0x404>
    336c:      	add	x9, x29, x8, lsl #2
    3370:      	mov	w10, #0x5ea0            // =24224
    3374:      	ldr	w9, [x9, x10]
    3378:      	cbnz	w9, 0x3444 <do_action+0x404>
    337c:      	add	x8, x29, x8, lsl #3
    3380:      	mov	x21, x0
    3384:      	ldr	x8, [x8, #0x5e78]
    3388:      	str	wzr, [sp, #0x5c]
    338c:      	and	x8, x8, #0x7ff
    3390:      	add	x8, x29, x8
    3394:      	ldr	w8, [x8, #0x90]
    3398:      	str	w8, [sp, #0x58]
    339c:      	mov	w8, #0xe                // =14
    33a0:      	blr	x8
    33a4:      	lsr	x8, x0, #32
    33a8:      	cmp	w22, #0x1
    33ac:      	str	x8, [sp, #0x50]
    33b0:      	b.ne	0x36fc <do_action+0x6bc>
    33b4:      	and	x8, x19, #0x7
    33b8:      	cmp	w8, #0x4
    33bc:      	b.hi	0x3444 <do_action+0x404>
    33c0:      	add	x9, x29, x8, lsl #2
    33c4:      	mov	w10, #0x5ea0            // =24224
    33c8:      	ldr	w9, [x9, x10]
    33cc:      	cbnz	w9, 0x3444 <do_action+0x404>
    33d0:      	add	x8, x29, x8, lsl #3
    33d4:      	mov	x0, x21
    33d8:      	ldr	x8, [x8, #0x5e78]
    33dc:      	and	x8, x8, #0x7ff
    33e0:      	add	x2, x29, x8
    33e4:      	ldr	w8, [x2, #0x90]!
    33e8:      	and	x8, x8, #0xfff
    33ec:      	add	x1, x8, #0x8
    33f0:      	mov	w8, #0x4                // =4
    33f4:      	blr	x8
    33f8:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    33fc:      	mov	x3, xzr
    3400:      	mov	w8, #0x2                // =2
    3404:      	ldr	x0, [x0]
    3408:      	add	x9, sp, #0x50
    340c:      	add	x1, sp, #0x50
    3410:      	mov	x2, x21
    3414:      	blr	x8
    3418:      	b	0x3444 <do_action+0x404>
    341c:      	add	w20, w20, #0x1
    3420:      	add	x8, x21, w20, uxtw #2
    3424:      	ldr	w8, [x8, #0x4]
    3428:      	and	x8, x8, #0x7
    342c:      	cmp	w8, #0x4
    3430:      	b.hi	0x3444 <do_action+0x404>
    3434:      	add	x9, x29, x8, lsl #2
    3438:      	mov	w10, #0x5ea0            // =24224
    343c:      	ldr	w9, [x9, x10]
    3440:      	cbz	w9, 0x35e4 <do_action+0x5a4>
    3444:      	mov	w0, wzr
    3448:      	cbz	w0, 0x3ab4 <do_action+0xa74>
    344c:      	mov	w0, wzr
    3450:      	b	0x3abc <do_action+0xa7c>
    3454:      	add	w20, w20, #0x1
    3458:      	add	x8, x21, w20, uxtw #2
    345c:      	ldr	w8, [x8, #0x4]
    3460:      	str	w8, [x29, #0x78]
    3464:      	b	0x3ab4 <do_action+0xa74>
    3468:      	strb	wzr, [x23]
    346c:      	b	0x3ab4 <do_action+0xa74>
    3470:      	tst	w25, #0x1
    3474:      	mov	w8, #0x4                // =4
    3478:      	add	w23, w20, #0x1
    347c:      	cinc	x19, x8, eq
    3480:      	b	0x3a6c <do_action+0xa2c>
    3484:      	mov	w8, #0xe                // =14
    3488:      	blr	x8
    348c:      	str	x0, [sp, #0x48]
    3490:      	adrp	x21, 0x3000 <filter_char_substring+0x270>
    3494:      	add	x8, sp, #0x48
    3498:      	mov	w9, #0x1                // =1
    349c:      	ldr	x21, [x21]
    34a0:      	add	x1, sp, #0x48
    34a4:      	mov	w19, #0x1               // =1
    34a8:      	mov	x0, x21
    34ac:      	blr	x9
    34b0:      	cbz	x0, 0x3ab4 <do_action+0xa74>
    34b4:      	ldur	x8, [x0, #0x4]
    34b8:      	adrp	x25, 0x3000 <filter_char_substring+0x270>
    34bc:      	mov	w9, #0x1                // =1
    34c0:      	add	x1, sp, #0x60
    34c4:      	str	x8, [sp, #0x60]
    34c8:      	mov	w8, #0x2                // =2
    34cc:      	str	w8, [sp, #0x68]
    34d0:      	add	x8, sp, #0x60
    34d4:      	ldr	x25, [x25]
    34d8:      	mov	x0, x25
    34dc:      	blr	x9
    34e0:      	str	w19, [sp, #0x78]
    34e4:      	cbz	x0, 0x3670 <do_action+0x630>
    34e8:      	ldaxr	w8, [x0]
    34ec:      	add	w8, w8, #0x1
    34f0:      	stlxr	w9, w8, [x0]
    34f4:      	cbnz	w9, 0x34e8 <do_action+0x4a8>
    34f8:      	mov	w8, #0x3                // =3
    34fc:      	add	x9, sp, #0x48
    3500:      	add	x1, sp, #0x48
    3504:      	mov	x0, x21
    3508:      	blr	x8
    350c:      	b	0x3ab4 <do_action+0xa74>
    3510:      	add	w8, w20, #0x1
    3514:      	add	x9, x21, #0x4
    3518:      	str	x19, [sp, #0x30]
    351c:      	ldr	w25, [x9, w8, uxtw #2]
    3520:      	add	w8, w20, #0x2
    3524:      	ldr	w19, [x9, w8, uxtw #2]
    3528:      	mov	w8, #0x7d               // =125
    352c:      	blr	x8
    3530:      	str	x0, [sp, #0x8]
    3534:      	str	x0, [sp, #0x50]
    3538:      	str	wzr, [sp, #0x48]
    353c:      	cbz	w25, 0x3928 <do_action+0x8e8>
    3540:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    3544:      	mov	w8, #0x1                // =1
    3548:      	add	x9, sp, #0x48
    354c:      	ldr	x0, [x0]
    3550:      	add	x1, sp, #0x48
    3554:      	blr	x8
    3558:      	cbz	x0, 0x3928 <do_action+0x8e8>
    355c:      	mov	x10, x0
    3560:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    3564:      	mov	w8, #0x1                // =1
    3568:      	ldr	x0, [x0]
    356c:      	add	x9, sp, #0x48
    3570:      	add	x1, sp, #0x48
    3574:      	str	x10, [sp, #0x10]
    3578:      	blr	x8
    357c:      	ldr	x9, [sp, #0x10]
    3580:      	ldr	x8, [x29, #0x60]
    3584:      	mov	x2, x0
    3588:      	cmp	w19, #0x2
    358c:      	str	x8, [x9]
    3590:      	ldr	x8, [x29, #0x70]
    3594:      	str	x8, [x9, #0x8]
    3598:      	b.eq	0x3740 <do_action+0x700>
    359c:      	cmp	w19, #0x1
    35a0:      	b.eq	0x3734 <do_action+0x6f4>
    35a4:      	cbnz	w19, 0x3928 <do_action+0x8e8>
    35a8:      	ldr	w8, [x29, #0x7c]
    35ac:      	str	x25, [sp]
    35b0:      	b	0x3748 <do_action+0x708>
    35b4:      	mov	w0, #0x9                // =9
    35b8:      	tbnz	w25, #0x0, 0x30f8 <do_action+0xb8>
    35bc:      	mov	w19, #0x3               // =3
    35c0:      	mov	w23, w20
    35c4:      	b	0x3a6c <do_action+0xa2c>
    35c8:      	tst	w25, #0x1
    35cc:      	mov	w8, #0x6                // =6
    35d0:      	add	w23, w20, #0x3
    35d4:      	cinc	x19, x8, eq
    35d8:      	b	0x3a6c <do_action+0xa2c>
    35dc:      	mov	w19, #0x9               // =9
    35e0:      	b	0x3a6c <do_action+0xa2c>
    35e4:      	add	x8, x29, x8, lsl #3
    35e8:      	ldr	x8, [x8, #0x5e78]
    35ec:      	and	x8, x8, #0x7ff
    35f0:      	add	x8, x29, x8
    35f4:      	ldr	x8, [x8, #0xb8]
    35f8:      	str	x8, [sp, #0x60]
    35fc:      	cbz	x8, 0x3444 <do_action+0x404>
    3600:      	cmp	w22, #0xa
    3604:      	b.ne	0x3718 <do_action+0x6d8>
    3608:      	mov	w8, #0xe                // =14
    360c:      	blr	x8
    3610:      	lsr	x8, x0, #32
    3614:      	mov	x21, x0
    3618:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    361c:      	str	w8, [sp, #0x50]
    3620:      	mov	w8, #0x1                // =1
    3624:      	add	x9, sp, #0x50
    3628:      	add	x1, sp, #0x50
    362c:      	ldr	x0, [x0]
    3630:      	blr	x8
    3634:      	cbz	x0, 0x3448 <do_action+0x408>
    3638:      	ldr	w8, [x0]
    363c:      	mov	x3, xzr
    3640:      	add	x9, sp, #0x60
    3644:      	add	x10, sp, #0x50
    3648:      	stp	w8, w21, [sp, #0x50]
    364c:      	ldr	x8, [x0, #0x8]
    3650:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    3654:      	add	x1, sp, #0x60
    3658:      	add	x2, sp, #0x50
    365c:      	str	x8, [sp, #0x58]
    3660:      	mov	w8, #0x2                // =2
    3664:      	ldr	x0, [x0]
    3668:      	blr	x8
    366c:      	b	0x3444 <do_action+0x404>
    3670:      	mov	w8, #0x1                // =1
    3674:      	mov	w9, #0x2                // =2
    3678:      	add	x10, sp, #0x60
    367c:      	add	x11, sp, #0x78
    3680:      	add	x1, sp, #0x60
    3684:      	add	x2, sp, #0x78
    3688:      	mov	x0, x25
    368c:      	mov	w3, #0x1                // =1
    3690:      	blr	x9
    3694:      	cbz	x0, 0x34f8 <do_action+0x4b8>
    3698:      	mov	x23, x0
    369c:      	adrp	x24, 0x3000 <filter_char_substring+0x270>
    36a0:      	mov	w9, #0x1                // =1
    36a4:      	add	x1, sp, #0x50
    36a8:      	mov	w19, #0x1               // =1
    36ac:      	neg	w8, w23
    36b0:      	strh	w8, [sp, #0x50]
    36b4:      	mov	w8, #0x3                // =3
    36b8:      	strh	w8, [sp, #0x52]
    36bc:      	mov	x8, #0x3b               // =59
    36c0:      	movk	x8, #0x2, lsl #32
    36c4:      	stur	x8, [sp, #0x54]
    36c8:      	add	x8, sp, #0x50
    36cc:      	ldr	x24, [x24]
    36d0:      	mov	x0, x24
    36d4:      	blr	x9
    36d8:      	cbz	x0, 0x39e4 <do_action+0x9a4>
    36dc:      	ldr	w8, [x0]
    36e0:      	add	w8, w8, #0x1
    36e4:      	str	w8, [x0]
    36e8:      	b	0x3a08 <do_action+0x9c8>
    36ec:      	ldrb	w8, [x29, #0x1]
    36f0:      	orr	w8, w8, #0x20
    36f4:      	strb	w8, [x29, #0x1]
    36f8:      	b	0x3a68 <do_action+0xa28>
    36fc:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    3700:      	mov	w8, #0x3                // =3
    3704:      	add	x9, sp, #0x50
    3708:      	ldr	x0, [x0]
    370c:      	add	x1, sp, #0x50
    3710:      	blr	x8
    3714:      	b	0x3448 <do_action+0x408>
    3718:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    371c:      	mov	w8, #0x3                // =3
    3720:      	add	x9, sp, #0x60
    3724:      	ldr	x0, [x0]
    3728:      	add	x1, sp, #0x60
    372c:      	blr	x8
    3730:      	b	0x3448 <do_action+0x408>
    3734:      	ldr	w8, [x29, #0x10]
    3738:      	str	x25, [sp]
    373c:      	b	0x3748 <do_action+0x708>
    3740:      	str	x25, [sp]
    3744:      	mov	w8, wzr
    3748:      	mov	w8, w8
    374c:      	add	x0, x9, #0x18
    3750:      	mov	w1, #0xc8               // =200
    3754:      	str	x8, [x9, #0x10]
    3758:      	mov	w8, #0xc8               // =200
    375c:      	mov	w9, #0x4                // =4
    3760:      	str	x0, [sp, #0x18]
    3764:      	blr	x9
    3768:      	ldr	x19, [sp, #0x30]
    376c:      	mov	w8, #0x5e78             // =24184
    3770:      	mov	x25, xzr
    3774:      	str	wzr, [sp, #0x2c]
    3778:      	add	x10, x29, x8
    377c:      	str	x23, [sp, #0x20]
    3780:      	b	0x3794 <do_action+0x754>
    3784:      	add	x25, x25, #0x4
    3788:      	add	x10, x10, #0x8
    378c:      	cmp	x25, #0x14
    3790:      	b.eq	0x38cc <do_action+0x88c>
    3794:      	str	x10, [sp, #0x38]
    3798:      	str	wzr, [sp, #0x60]
    379c:      	mov	w8, #0x1                // =1
    37a0:      	add	x9, sp, #0x60
    37a4:      	add	x1, sp, #0x60
    37a8:      	mov	x0, x24
    37ac:      	blr	x8
    37b0:      	cbz	x0, 0x38cc <do_action+0x88c>
    37b4:      	mov	w8, #0x5ef8             // =24312
    37b8:      	add	x1, x0, x8
    37bc:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    37c0:      	mov	w8, #0x1                // =1
    37c4:      	ldr	x0, [x0]
    37c8:      	blr	x8
    37cc:      	cbz	x0, 0x38cc <do_action+0x88c>
    37d0:      	add	x8, x0, x25
    37d4:      	ldr	x10, [sp, #0x38]
    37d8:      	ldr	w8, [x8, #0x40]
    37dc:      	cmn	w8, #0x1
    37e0:      	b.eq	0x38cc <do_action+0x88c>
    37e4:      	ldr	x8, [x10]
    37e8:      	ldr	w9, [x29, #0x4]
    37ec:      	cmp	x8, x9
    37f0:      	b.ge	0x38cc <do_action+0x88c>
    37f4:      	cmp	x25, #0x10
    37f8:      	b.eq	0x3860 <do_action+0x820>
    37fc:      	str	wzr, [sp, #0x60]
    3800:      	mov	w8, #0x1                // =1
    3804:      	add	x9, sp, #0x60
    3808:      	add	x1, sp, #0x60
    380c:      	mov	x0, x24
    3810:      	blr	x8
    3814:      	cbz	x0, 0x3858 <do_action+0x818>
    3818:      	mov	w8, #0x5ef8             // =24312
    381c:      	add	x1, x0, x8
    3820:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    3824:      	mov	w8, #0x1                // =1
    3828:      	ldr	x0, [x0]
    382c:      	blr	x8
    3830:      	cbz	x0, 0x3858 <do_action+0x818>
    3834:      	ldr	x10, [sp, #0x38]
    3838:      	add	x8, x0, x25
    383c:      	ldr	w9, [x8, #0x44]
    3840:      	ldr	x8, [x10]
    3844:      	cmn	w9, #0x1
    3848:      	b.eq	0x3860 <do_action+0x820>
    384c:      	ldr	w9, [x10, #0x8]
    3850:      	sub	w9, w9, w8
    3854:      	b	0x386c <do_action+0x82c>
    3858:      	ldr	x10, [sp, #0x38]
    385c:      	ldr	x8, [x10]
    3860:      	ldr	w9, [x29, #0x4]
    3864:      	sub	w9, w9, w8
    3868:      	add	w9, w9, #0x4
    386c:      	cmp	w9, #0x1
    3870:      	b.lt	0x3784 <do_action+0x744>
    3874:      	mov	w10, #0x3ffc            // =16380
    3878:      	cmp	w9, #0x28
    387c:      	mov	x23, x29
    3880:      	add	w8, w8, w10
    3884:      	mov	w10, #0x28              // =40
    3888:      	csel	w29, w9, w10, lt
    388c:      	ldr	w9, [sp, #0x2c]
    3890:      	and	x8, x8, #0x3fff
    3894:      	add	x8, x23, x8
    3898:      	mov	w1, w29
    389c:      	add	x2, x8, #0x90
    38a0:      	mov	w8, #0x4                // =4
    38a4:      	and	w19, w9, #0xff
    38a8:      	ldr	x9, [sp, #0x18]
    38ac:      	add	x0, x9, x19
    38b0:      	blr	x8
    38b4:      	add	w8, w29, w19
    38b8:      	ldp	x19, x10, [sp, #0x30]
    38bc:      	mov	x29, x23
    38c0:      	ldr	x23, [sp, #0x20]
    38c4:      	str	w8, [sp, #0x2c]
    38c8:      	b	0x3784 <do_action+0x744>
    38cc:      	adrp	x24, 0x3000 <filter_char_substring+0x270>
    38d0:      	mov	w8, #0x1                // =1
    38d4:      	ldr	x24, [x24]
    38d8:      	ldr	x1, [sp, #0x10]
    38dc:      	mov	x0, x24
    38e0:      	blr	x8
    38e4:      	cbz	x0, 0x390c <do_action+0x8cc>
    38e8:      	ldp	x10, x11, [sp]
    38ec:      	mov	x9, #-0x4240            // =-16960
    38f0:      	movk	x9, #0xfff0, lsl #16
    38f4:      	ldr	x8, [x0]
    38f8:      	madd	x9, x10, x9, x11
    38fc:      	cmp	x8, x9
    3900:      	b.ls	0x390c <do_action+0x8cc>
    3904:      	strb	wzr, [x23]
    3908:      	b	0x392c <do_action+0x8ec>
    390c:      	ldr	x1, [sp, #0x10]
    3910:      	mov	x3, xzr
    3914:      	mov	w8, #0x2                // =2
    3918:      	add	x9, sp, #0x50
    391c:      	add	x2, sp, #0x50
    3920:      	mov	x0, x24
    3924:      	blr	x8
    3928:      	ldr	x19, [sp, #0x30]
    392c:      	add	w8, w20, #0x3
    3930:      	adrp	x23, 0x3000 <filter_char_substring+0x270>
    3934:      	add	x8, x21, w8, uxtw #2
    3938:      	ldr	w8, [x8, #0x4]
    393c:      	ldr	x23, [x23]
    3940:      	cbz	w8, 0x3968 <do_action+0x928>
    3944:      	ldrb	w8, [x29, #0x1]
    3948:      	mov	x2, xzr
    394c:      	mov	x0, x19
    3950:      	mov	x1, x23
    3954:      	orr	w8, w8, #0x2
    3958:      	strb	w8, [x29, #0x1]
    395c:      	mov	w8, #0x1b               // =27
    3960:      	blr	x8
    3964:      	str	x0, [x29, #0x80]
    3968:      	add	w8, w20, #0x4
    396c:      	add	x8, x21, w8, uxtw #2
    3970:      	ldr	w8, [x8, #0x4]
    3974:      	cbz	w8, 0x39a0 <do_action+0x960>
    3978:      	ldrb	w8, [x29, #0x1]
    397c:      	mov	w9, #0x1b               // =27
    3980:      	mov	x0, x19
    3984:      	mov	x1, x23
    3988:      	mov	w2, #0x100              // =256
    398c:      	orr	w8, w8, #0x4
    3990:      	strb	w8, [x29, #0x1]
    3994:      	mov	w8, #0x100              // =256
    3998:      	blr	x9
    399c:      	str	x0, [x29, #0x88]
    39a0:      	add	w20, w20, #0x5
    39a4:      	add	x8, x21, w20, uxtw #2
    39a8:      	ldr	w8, [x8, #0x4]
    39ac:      	cbz	w8, 0x3ab4 <do_action+0xa74>
    39b0:      	ldrb	w8, [x29, #0x1]
    39b4:      	orr	w8, w8, #0x8
    39b8:      	strb	w8, [x29, #0x1]
    39bc:      	b	0x3ab4 <do_action+0xa74>
    39c0:      	mov	x3, xzr
    39c4:      	mov	w8, #0x2                // =2
    39c8:      	add	x9, sp, #0x48
    39cc:      	add	x10, sp, #0x50
    39d0:      	add	x1, sp, #0x48
    39d4:      	add	x2, sp, #0x50
    39d8:      	mov	x0, x21
    39dc:      	blr	x8
    39e0:      	b	0x3a68 <do_action+0xa28>
    39e4:      	str	w19, [sp, #0x7c]
    39e8:      	mov	x3, xzr
    39ec:      	mov	w8, #0x2                // =2
    39f0:      	add	x9, sp, #0x50
    39f4:      	add	x10, sp, #0x7c
    39f8:      	add	x1, sp, #0x50
    39fc:      	add	x2, sp, #0x7c
    3a00:      	mov	x0, x24
    3a04:      	blr	x8
    3a08:      	cbz	w23, 0x34f8 <do_action+0x4b8>
    3a0c:      	mov	w8, #0x1                // =1
    3a10:      	add	x9, sp, #0x60
    3a14:      	add	x1, sp, #0x60
    3a18:      	mov	x0, x25
    3a1c:      	blr	x8
    3a20:      	cbz	x0, 0x34f8 <do_action+0x4b8>
    3a24:      	ldr	w8, [sp, #0x78]
    3a28:      	ldaxr	w9, [x0]
    3a2c:      	add	w9, w9, w8
    3a30:      	stlxr	w10, w9, [x0]
    3a34:      	cbnz	w10, 0x3a28 <do_action+0x9e8>
    3a38:      	b	0x34f8 <do_action+0x4b8>
    3a3c:      	str	w19, [sp, #0x7c]
    3a40:      	mov	x3, xzr
    3a44:      	mov	w8, #0x2                // =2
    3a48:      	add	x9, sp, #0x60
    3a4c:      	add	x10, sp, #0x7c
    3a50:      	add	x1, sp, #0x60
    3a54:      	add	x2, sp, #0x7c
    3a58:      	mov	x0, x21
    3a5c:      	blr	x8
    3a60:      	ldp	x8, x9, [sp, #0x50]
    3a64:      	stp	x8, x9, [x20]
    3a68:      	mov	w19, #0x8               // =8
    3a6c:      	str	wzr, [sp, #0x50]
    3a70:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    3a74:      	mov	w8, #0x1                // =1
    3a78:      	add	x9, sp, #0x50
    3a7c:      	ldr	x0, [x0]
    3a80:      	add	x1, sp, #0x50
    3a84:      	blr	x8
    3a88:      	cbz	x0, 0x3ab0 <do_action+0xa70>
    3a8c:      	add	x8, x0, x19, lsl #3
    3a90:      	nop
    3a94:      	nop
    3a98:      	nop
    3a9c:      	nop
    3aa0:      	ldaxr	x9, [x8]
    3aa4:      	add	x9, x9, #0x1
    3aa8:      	stlxr	w10, x9, [x8]
    3aac:      	cbnz	w10, 0x3aa0 <do_action+0xa60>
    3ab0:      	mov	w20, w23
    3ab4:      	add	w0, w20, #0x1
    3ab8:      	str	x22, [x29, #0x70]
    3abc:      	ldp	x20, x19, [sp, #0xb0]
    3ac0:      	ldr	x29, [sp, #0x70]
    3ac4:      	ldp	x22, x21, [sp, #0xa0]
    3ac8:      	ldp	x24, x23, [sp, #0x90]
    3acc:      	ldp	x30, x25, [sp, #0x80]
    3ad0:      	add	sp, sp, #0xc0
    3ad4:      	ret
    3ad8:      	nop
    3adc:      	nop

0000000000003ae0 <read_reg>:
    3ae0:      	ror	w9, w1, #0x3
    3ae4:      	mov	x8, xzr
    3ae8:      	cmp	w9, #0xf
    3aec:      	b.le	0x3b28 <read_reg+0x48>
    3af0:      	cmp	w9, #0x17
    3af4:      	b.le	0x3b7c <read_reg+0x9c>
    3af8:      	cmp	w9, #0x1b
    3afc:      	b.le	0x3ba4 <read_reg+0xc4>
    3b00:      	cmp	w9, #0x1d
    3b04:      	b.le	0x3c3c <read_reg+0x15c>
    3b08:      	cmp	w9, #0x1e
    3b0c:      	b.eq	0x3d5c <read_reg+0x27c>
    3b10:      	cmp	w9, #0x20
    3b14:      	b.eq	0x3cfc <read_reg+0x21c>
    3b18:      	cmp	w9, #0x1f
    3b1c:      	b.ne	0x3d70 <read_reg+0x290>
    3b20:      	add	x0, x0, #0xf8
    3b24:      	b	0x3d60 <read_reg+0x280>
    3b28:      	cmp	w9, #0x7
    3b2c:      	b.gt	0x3b54 <read_reg+0x74>
    3b30:      	cmp	w9, #0x3
    3b34:      	b.gt	0x3bc4 <read_reg+0xe4>
    3b38:      	cmp	w9, #0x1
    3b3c:      	b.gt	0x3c54 <read_reg+0x174>
    3b40:      	cbz	w9, 0x3d60 <read_reg+0x280>
    3b44:      	cmp	w9, #0x1
    3b48:      	b.ne	0x3d70 <read_reg+0x290>
    3b4c:      	add	x0, x0, #0x8
    3b50:      	b	0x3d60 <read_reg+0x280>
    3b54:      	cmp	w9, #0xb
    3b58:      	b.gt	0x3be4 <read_reg+0x104>
    3b5c:      	cmp	w9, #0x9
    3b60:      	b.gt	0x3c6c <read_reg+0x18c>
    3b64:      	cmp	w9, #0x8
    3b68:      	b.eq	0x3d04 <read_reg+0x224>
    3b6c:      	cmp	w9, #0x9
    3b70:      	b.ne	0x3d70 <read_reg+0x290>
    3b74:      	add	x0, x0, #0x48
    3b78:      	b	0x3d60 <read_reg+0x280>
    3b7c:      	cmp	w9, #0x13
    3b80:      	b.gt	0x3c04 <read_reg+0x124>
    3b84:      	cmp	w9, #0x11
    3b88:      	b.gt	0x3cb4 <read_reg+0x1d4>
    3b8c:      	cmp	w9, #0x10
    3b90:      	b.eq	0x3d3c <read_reg+0x25c>
    3b94:      	cmp	w9, #0x11
    3b98:      	b.ne	0x3d70 <read_reg+0x290>
    3b9c:      	add	x0, x0, #0x88
    3ba0:      	b	0x3d60 <read_reg+0x280>
    3ba4:      	cmp	w9, #0x19
    3ba8:      	b.gt	0x3c24 <read_reg+0x144>
    3bac:      	cmp	w9, #0x18
    3bb0:      	b.eq	0x3ce4 <read_reg+0x204>
    3bb4:      	cmp	w9, #0x19
    3bb8:      	b.ne	0x3d70 <read_reg+0x290>
    3bbc:      	add	x0, x0, #0xc8
    3bc0:      	b	0x3d60 <read_reg+0x280>
    3bc4:      	cmp	w9, #0x5
    3bc8:      	b.gt	0x3c84 <read_reg+0x1a4>
    3bcc:      	cmp	w9, #0x4
    3bd0:      	b.eq	0x3d0c <read_reg+0x22c>
    3bd4:      	cmp	w9, #0x5
    3bd8:      	b.ne	0x3d70 <read_reg+0x290>
    3bdc:      	add	x0, x0, #0x28
    3be0:      	b	0x3d60 <read_reg+0x280>
    3be4:      	cmp	w9, #0xd
    3be8:      	b.gt	0x3c9c <read_reg+0x1bc>
    3bec:      	cmp	w9, #0xc
    3bf0:      	b.eq	0x3d14 <read_reg+0x234>
    3bf4:      	cmp	w9, #0xd
    3bf8:      	b.ne	0x3d70 <read_reg+0x290>
    3bfc:      	add	x0, x0, #0x68
    3c00:      	b	0x3d60 <read_reg+0x280>
    3c04:      	cmp	w9, #0x15
    3c08:      	b.gt	0x3ccc <read_reg+0x1ec>
    3c0c:      	cmp	w9, #0x14
    3c10:      	b.eq	0x3d44 <read_reg+0x264>
    3c14:      	cmp	w9, #0x15
    3c18:      	b.ne	0x3d70 <read_reg+0x290>
    3c1c:      	add	x0, x0, #0xa8
    3c20:      	b	0x3d60 <read_reg+0x280>
    3c24:      	cmp	w9, #0x1a
    3c28:      	b.eq	0x3cec <read_reg+0x20c>
    3c2c:      	cmp	w9, #0x1b
    3c30:      	b.ne	0x3d70 <read_reg+0x290>
    3c34:      	add	x0, x0, #0xd8
    3c38:      	b	0x3d60 <read_reg+0x280>
    3c3c:      	cmp	w9, #0x1c
    3c40:      	b.eq	0x3cf4 <read_reg+0x214>
    3c44:      	cmp	w9, #0x1d
    3c48:      	b.ne	0x3d70 <read_reg+0x290>
    3c4c:      	add	x0, x0, #0xe8
    3c50:      	b	0x3d60 <read_reg+0x280>
    3c54:      	cmp	w9, #0x2
    3c58:      	b.eq	0x3d1c <read_reg+0x23c>
    3c5c:      	cmp	w9, #0x3
    3c60:      	b.ne	0x3d70 <read_reg+0x290>
    3c64:      	add	x0, x0, #0x18
    3c68:      	b	0x3d60 <read_reg+0x280>
    3c6c:      	cmp	w9, #0xa
    3c70:      	b.eq	0x3d24 <read_reg+0x244>
    3c74:      	cmp	w9, #0xb
    3c78:      	b.ne	0x3d70 <read_reg+0x290>
    3c7c:      	add	x0, x0, #0x58
    3c80:      	b	0x3d60 <read_reg+0x280>
    3c84:      	cmp	w9, #0x6
    3c88:      	b.eq	0x3d2c <read_reg+0x24c>
    3c8c:      	cmp	w9, #0x7
    3c90:      	b.ne	0x3d70 <read_reg+0x290>
    3c94:      	add	x0, x0, #0x38
    3c98:      	b	0x3d60 <read_reg+0x280>
    3c9c:      	cmp	w9, #0xe
    3ca0:      	b.eq	0x3d34 <read_reg+0x254>
    3ca4:      	cmp	w9, #0xf
    3ca8:      	b.ne	0x3d70 <read_reg+0x290>
    3cac:      	add	x0, x0, #0x78
    3cb0:      	b	0x3d60 <read_reg+0x280>
    3cb4:      	cmp	w9, #0x12
    3cb8:      	b.eq	0x3d4c <read_reg+0x26c>
    3cbc:      	cmp	w9, #0x13
    3cc0:      	b.ne	0x3d70 <read_reg+0x290>
    3cc4:      	add	x0, x0, #0x98
    3cc8:      	b	0x3d60 <read_reg+0x280>
    3ccc:      	cmp	w9, #0x16
    3cd0:      	b.eq	0x3d54 <read_reg+0x274>
    3cd4:      	cmp	w9, #0x17
    3cd8:      	b.ne	0x3d70 <read_reg+0x290>
    3cdc:      	add	x0, x0, #0xb8
    3ce0:      	b	0x3d60 <read_reg+0x280>
    3ce4:      	add	x0, x0, #0xc0
    3ce8:      	b	0x3d60 <read_reg+0x280>
    3cec:      	add	x0, x0, #0xd0
    3cf0:      	b	0x3d60 <read_reg+0x280>
    3cf4:      	add	x0, x0, #0xe0
    3cf8:      	b	0x3d60 <read_reg+0x280>
    3cfc:      	add	x0, x0, #0x100
    3d00:      	b	0x3d60 <read_reg+0x280>
    3d04:      	add	x0, x0, #0x40
    3d08:      	b	0x3d60 <read_reg+0x280>
    3d0c:      	add	x0, x0, #0x20
    3d10:      	b	0x3d60 <read_reg+0x280>
    3d14:      	add	x0, x0, #0x60
    3d18:      	b	0x3d60 <read_reg+0x280>
    3d1c:      	add	x0, x0, #0x10
    3d20:      	b	0x3d60 <read_reg+0x280>
    3d24:      	add	x0, x0, #0x50
    3d28:      	b	0x3d60 <read_reg+0x280>
    3d2c:      	add	x0, x0, #0x30
    3d30:      	b	0x3d60 <read_reg+0x280>
    3d34:      	add	x0, x0, #0x70
    3d38:      	b	0x3d60 <read_reg+0x280>
    3d3c:      	add	x0, x0, #0x80
    3d40:      	b	0x3d60 <read_reg+0x280>
    3d44:      	add	x0, x0, #0xa0
    3d48:      	b	0x3d60 <read_reg+0x280>
    3d4c:      	add	x0, x0, #0x90
    3d50:      	b	0x3d60 <read_reg+0x280>
    3d54:      	add	x0, x0, #0xb0
    3d58:      	b	0x3d60 <read_reg+0x280>
    3d5c:      	add	x0, x0, #0xf0
    3d60:      	ldr	x8, [x0]
    3d64:      	mov	x9, #-0x1               // =-1
    3d68:      	lsr	x9, x9, x2
    3d6c:      	and	x8, x8, x9
    3d70:      	mov	x0, x8
    3d74:      	ret
    3d78:      	nop
    3d7c:      	nop

0000000000003d80 <try_preload_arg>:
    3d80:      	sub	sp, sp, #0x60
    3d84:      	str	x30, [sp, #0x30]
    3d88:      	stp	x22, x21, [sp, #0x40]
    3d8c:      	stp	x20, x19, [sp, #0x50]
    3d90:      	ldr	x20, [x1]
    3d94:      	and	w19, w0, #0x7
    3d98:      	add	x8, x20, w19, uxtw #2
    3d9c:      	ldr	w8, [x8, #0x18]
    3da0:      	tbnz	w8, #0x8, 0x3dbc <try_preload_arg+0x3c>
    3da4:      	ldp	x20, x19, [sp, #0x50]
    3da8:      	mov	w0, wzr
    3dac:      	ldr	x30, [sp, #0x30]
    3db0:      	ldp	x22, x21, [sp, #0x40]
    3db4:      	add	sp, sp, #0x60
    3db8:      	ret
    3dbc:      	ldr	x0, [x1, #0x8]
    3dc0:      	tbnz	w8, #0x7, 0x3e38 <try_preload_arg+0xb8>
    3dc4:      	mov	w9, #0x18               // =24
    3dc8:      	str	wzr, [sp, #0x38]
    3dcc:      	mov	x8, xzr
    3dd0:      	umaddl	x9, w19, w9, x20
    3dd4:      	add	x21, x9, #0x200
    3dd8:      	ldrb	w9, [x9, #0x211]
    3ddc:      	cmp	w9, #0x2
    3de0:      	b.gt	0x4134 <try_preload_arg+0x3b4>
    3de4:      	cmp	w9, #0x1
    3de8:      	b.eq	0x4200 <try_preload_arg+0x480>
    3dec:      	cmp	w9, #0x2
    3df0:      	b.ne	0x4230 <try_preload_arg+0x4b0>
    3df4:      	mov	w8, #0x18               // =24
    3df8:      	mov	w9, #0x71               // =113
    3dfc:      	add	x10, sp, #0x10
    3e00:      	mov	w1, #0x8                // =8
    3e04:      	umaddl	x8, w19, w8, x20
    3e08:      	ldr	w8, [x8, #0x208]
    3e0c:      	and	x8, x8, #0xfff
    3e10:      	add	x2, x0, x8
    3e14:      	mov	w8, #0x8                // =8
    3e18:      	add	x0, sp, #0x10
    3e1c:      	blr	x9
    3e20:      	cbz	w0, 0x4208 <try_preload_arg+0x488>
    3e24:      	mov	x8, xzr
    3e28:      	cmp	w19, #0x4
    3e2c:      	str	x8, [sp, #0x8]
    3e30:      	b.hi	0x4714 <try_preload_arg+0x994>
    3e34:      	b	0x42b4 <try_preload_arg+0x534>
    3e38:      	str	wzr, [sp, #0x38]
    3e3c:      	add	x21, x20, x19, lsl #2
    3e40:      	mov	w9, #0x40               // =64
    3e44:      	ldrb	w8, [x21, #0x2c2]
    3e48:      	ldrh	w1, [x21, #0x2c0]
    3e4c:      	sub	w2, w9, w8, lsl #3
    3e50:      	bl	0x3ae0 <read_reg>
    3e54:      	str	x0, [sp, #0x8]
    3e58:      	cmp	w19, #0x4
    3e5c:      	ldr	w21, [x21, #0x4]
    3e60:      	b.hi	0x4684 <try_preload_arg+0x904>
    3e64:      	mov	w8, #0x50               // =80
    3e68:      	umaddl	x8, w19, w8, x20
    3e6c:      	ldrh	w9, [x8, #0x76]
    3e70:      	cbz	w9, 0x4684 <try_preload_arg+0x904>
    3e74:      	add	x19, x8, #0x70
    3e78:      	add	x8, sp, #0x8
    3e7c:      	stp	x19, x8, [sp, #0x10]
    3e80:      	mov	w8, #0x1                // =1
    3e84:      	strb	w8, [sp, #0x20]
    3e88:      	add	x8, sp, #0x38
    3e8c:      	str	x8, [sp, #0x28]
    3e90:      	adrp	x8, 0x3000 <filter_char_substring+0x270>
    3e94:      	ldr	x8, [x8]
    3e98:      	ldrb	w8, [x8]
    3e9c:      	cbz	w8, 0x457c <try_preload_arg+0x7fc>
    3ea0:      	ldrh	w8, [x19, #0x6]
    3ea4:      	cbz	w8, 0x4684 <try_preload_arg+0x904>
    3ea8:      	ldr	x8, [sp, #0x8]
    3eac:      	ldr	w9, [x19]
    3eb0:      	add	x8, x8, x9
    3eb4:      	str	x8, [sp, #0x8]
    3eb8:      	ldrh	w9, [x19, #0x4]
    3ebc:      	cbz	w9, 0x3ee0 <try_preload_arg+0x160>
    3ec0:      	mov	w9, #0x8                // =8
    3ec4:      	mov	w10, #0x94              // =148
    3ec8:      	add	x11, sp, #0x8
    3ecc:      	ldr	x2, [sp, #0x8]
    3ed0:      	add	x0, sp, #0x8
    3ed4:      	mov	w1, #0x8                // =8
    3ed8:      	blr	x10
    3edc:      	tbnz	w0, #0x1f, 0x45d4 <try_preload_arg+0x854>
    3ee0:      	ldrh	w8, [x19, #0xe]
    3ee4:      	cbz	w8, 0x4684 <try_preload_arg+0x904>
    3ee8:      	ldr	x8, [sp, #0x8]
    3eec:      	ldr	w9, [x19, #0x8]
    3ef0:      	add	x8, x8, x9
    3ef4:      	str	x8, [sp, #0x8]
    3ef8:      	ldrh	w9, [x19, #0xc]
    3efc:      	cbz	w9, 0x3f20 <try_preload_arg+0x1a0>
    3f00:      	mov	w9, #0x8                // =8
    3f04:      	mov	w10, #0x94              // =148
    3f08:      	add	x11, sp, #0x8
    3f0c:      	ldr	x2, [sp, #0x8]
    3f10:      	add	x0, sp, #0x8
    3f14:      	mov	w1, #0x8                // =8
    3f18:      	blr	x10
    3f1c:      	tbnz	w0, #0x1f, 0x45f0 <try_preload_arg+0x870>
    3f20:      	ldrh	w8, [x19, #0x16]
    3f24:      	cbz	w8, 0x4684 <try_preload_arg+0x904>
    3f28:      	ldr	x8, [sp, #0x8]
    3f2c:      	ldr	w9, [x19, #0x10]
    3f30:      	add	x8, x8, x9
    3f34:      	str	x8, [sp, #0x8]
    3f38:      	ldrh	w9, [x19, #0x14]
    3f3c:      	cbz	w9, 0x3f60 <try_preload_arg+0x1e0>
    3f40:      	mov	w9, #0x8                // =8
    3f44:      	mov	w10, #0x94              // =148
    3f48:      	add	x11, sp, #0x8
    3f4c:      	ldr	x2, [sp, #0x8]
    3f50:      	add	x0, sp, #0x8
    3f54:      	mov	w1, #0x8                // =8
    3f58:      	blr	x10
    3f5c:      	tbnz	w0, #0x1f, 0x460c <try_preload_arg+0x88c>
    3f60:      	ldrh	w8, [x19, #0x1e]
    3f64:      	cbz	w8, 0x4684 <try_preload_arg+0x904>
    3f68:      	ldr	x8, [sp, #0x8]
    3f6c:      	ldr	w9, [x19, #0x18]
    3f70:      	add	x8, x8, x9
    3f74:      	str	x8, [sp, #0x8]
    3f78:      	ldrh	w9, [x19, #0x1c]
    3f7c:      	cbz	w9, 0x3fa0 <try_preload_arg+0x220>
    3f80:      	mov	w9, #0x8                // =8
    3f84:      	mov	w10, #0x94              // =148
    3f88:      	add	x11, sp, #0x8
    3f8c:      	ldr	x2, [sp, #0x8]
    3f90:      	add	x0, sp, #0x8
    3f94:      	mov	w1, #0x8                // =8
    3f98:      	blr	x10
    3f9c:      	tbnz	w0, #0x1f, 0x4628 <try_preload_arg+0x8a8>
    3fa0:      	ldrh	w8, [x19, #0x26]
    3fa4:      	cbz	w8, 0x4684 <try_preload_arg+0x904>
    3fa8:      	ldr	x8, [sp, #0x8]
    3fac:      	ldr	w9, [x19, #0x20]
    3fb0:      	add	x8, x8, x9
    3fb4:      	str	x8, [sp, #0x8]
    3fb8:      	ldrh	w9, [x19, #0x24]
    3fbc:      	cbz	w9, 0x3fe0 <try_preload_arg+0x260>
    3fc0:      	mov	w9, #0x8                // =8
    3fc4:      	mov	w10, #0x94              // =148
    3fc8:      	add	x11, sp, #0x8
    3fcc:      	ldr	x2, [sp, #0x8]
    3fd0:      	add	x0, sp, #0x8
    3fd4:      	mov	w1, #0x8                // =8
    3fd8:      	blr	x10
    3fdc:      	tbnz	w0, #0x1f, 0x4644 <try_preload_arg+0x8c4>
    3fe0:      	ldrh	w8, [x19, #0x2e]
    3fe4:      	cbz	w8, 0x4684 <try_preload_arg+0x904>
    3fe8:      	ldr	x8, [sp, #0x8]
    3fec:      	ldr	w9, [x19, #0x28]
    3ff0:      	add	x8, x8, x9
    3ff4:      	str	x8, [sp, #0x8]
    3ff8:      	ldrh	w9, [x19, #0x2c]
    3ffc:      	cbz	w9, 0x4020 <try_preload_arg+0x2a0>
    4000:      	mov	w9, #0x8                // =8
    4004:      	mov	w10, #0x94              // =148
    4008:      	add	x11, sp, #0x8
    400c:      	ldr	x2, [sp, #0x8]
    4010:      	add	x0, sp, #0x8
    4014:      	mov	w1, #0x8                // =8
    4018:      	blr	x10
    401c:      	tbnz	w0, #0x1f, 0x4660 <try_preload_arg+0x8e0>
    4020:      	ldrh	w8, [x19, #0x36]
    4024:      	cbz	w8, 0x4684 <try_preload_arg+0x904>
    4028:      	ldr	x8, [sp, #0x8]
    402c:      	ldr	w9, [x19, #0x30]
    4030:      	add	x8, x8, x9
    4034:      	str	x8, [sp, #0x8]
    4038:      	ldrh	w9, [x19, #0x34]
    403c:      	cbz	w9, 0x4060 <try_preload_arg+0x2e0>
    4040:      	mov	w9, #0x8                // =8
    4044:      	mov	w10, #0x94              // =148
    4048:      	add	x11, sp, #0x8
    404c:      	ldr	x2, [sp, #0x8]
    4050:      	add	x0, sp, #0x8
    4054:      	mov	w1, #0x8                // =8
    4058:      	blr	x10
    405c:      	tbnz	w0, #0x1f, 0x467c <try_preload_arg+0x8fc>
    4060:      	ldrh	w8, [x19, #0x3e]
    4064:      	cbz	w8, 0x4684 <try_preload_arg+0x904>
    4068:      	ldr	x8, [sp, #0x8]
    406c:      	ldr	w9, [x19, #0x38]
    4070:      	add	x8, x8, x9
    4074:      	str	x8, [sp, #0x8]
    4078:      	ldrh	w9, [x19, #0x3c]
    407c:      	cbz	w9, 0x40a0 <try_preload_arg+0x320>
    4080:      	mov	w20, #0x8               // =8
    4084:      	mov	w9, #0x94               // =148
    4088:      	add	x10, sp, #0x8
    408c:      	ldr	x2, [sp, #0x8]
    4090:      	add	x0, sp, #0x8
    4094:      	mov	w1, #0x8                // =8
    4098:      	blr	x9
    409c:      	tbnz	w0, #0x1f, 0x45d8 <try_preload_arg+0x858>
    40a0:      	ldrh	w8, [x19, #0x46]
    40a4:      	cbz	w8, 0x4684 <try_preload_arg+0x904>
    40a8:      	ldr	x8, [sp, #0x8]
    40ac:      	ldr	w9, [x19, #0x40]
    40b0:      	add	x8, x8, x9
    40b4:      	str	x8, [sp, #0x8]
    40b8:      	ldrh	w9, [x19, #0x44]
    40bc:      	cbz	w9, 0x40e0 <try_preload_arg+0x360>
    40c0:      	mov	w9, #0x8                // =8
    40c4:      	mov	w10, #0x94              // =148
    40c8:      	add	x11, sp, #0x8
    40cc:      	ldr	x2, [sp, #0x8]
    40d0:      	add	x0, sp, #0x8
    40d4:      	mov	w1, #0x8                // =8
    40d8:      	blr	x10
    40dc:      	tbnz	w0, #0x1f, 0x47fc <try_preload_arg+0xa7c>
    40e0:      	ldrh	w8, [x19, #0x4e]
    40e4:      	cbz	w8, 0x4684 <try_preload_arg+0x904>
    40e8:      	ldr	x8, [sp, #0x8]
    40ec:      	ldr	w9, [x19, #0x48]
    40f0:      	add	x8, x8, x9
    40f4:      	str	x8, [sp, #0x8]
    40f8:      	ldrh	w9, [x19, #0x4c]
    40fc:      	cbz	w9, 0x4684 <try_preload_arg+0x904>
    4100:      	mov	w9, #0x8                // =8
    4104:      	mov	w10, #0x94              // =148
    4108:      	add	x11, sp, #0x8
    410c:      	ldr	x2, [sp, #0x8]
    4110:      	add	x0, sp, #0x8
    4114:      	mov	w1, #0x8                // =8
    4118:      	blr	x10
    411c:      	tbz	w0, #0x1f, 0x4684 <try_preload_arg+0x904>
    4120:      	mov	w20, #0xa               // =10
    4124:      	str	w20, [sp, #0x38]
    4128:      	cmp	w21, #0x6
    412c:      	b.eq	0x468c <try_preload_arg+0x90c>
    4130:      	b	0x3da4 <try_preload_arg+0x24>
    4134:      	cmp	w9, #0x3
    4138:      	b.eq	0x4240 <try_preload_arg+0x4c0>
    413c:      	cmp	w9, #0x4
    4140:      	b.ne	0x4230 <try_preload_arg+0x4b0>
    4144:      	mov	w8, #0x18               // =24
    4148:      	mov	w9, #0x71               // =113
    414c:      	add	x10, sp, #0x10
    4150:      	mov	x22, x0
    4154:      	mov	w1, #0x8                // =8
    4158:      	umaddl	x8, w19, w8, x20
    415c:      	ldr	w8, [x8, #0x208]
    4160:      	and	x8, x8, #0xfff
    4164:      	add	x2, x0, x8
    4168:      	mov	w8, #0x8                // =8
    416c:      	add	x0, sp, #0x10
    4170:      	blr	x9
    4174:      	cbnz	w0, 0x42a4 <try_preload_arg+0x524>
    4178:      	mov	w8, #0x18               // =24
    417c:      	mov	w9, #0x71               // =113
    4180:      	add	x10, sp, #0x8
    4184:      	add	x0, sp, #0x8
    4188:      	mov	w1, #0x8                // =8
    418c:      	umaddl	x8, w19, w8, x20
    4190:      	ldr	w8, [x8, #0x20c]
    4194:      	and	x8, x8, #0xfff
    4198:      	add	x2, x22, x8
    419c:      	mov	w8, #0x8                // =8
    41a0:      	blr	x9
    41a4:      	cbnz	w0, 0x42a4 <try_preload_arg+0x524>
    41a8:      	mov	w10, #0x18              // =24
    41ac:      	ldp	x9, x8, [sp, #0x8]
    41b0:      	add	x12, sp, #0x10
    41b4:      	add	x0, sp, #0x10
    41b8:      	mov	w1, #0x8                // =8
    41bc:      	umaddl	x10, w19, w10, x20
    41c0:      	ldrb	w11, [x10, #0x213]
    41c4:      	lsl	x9, x9, x11
    41c8:      	ldr	x11, [x21]
    41cc:      	add	x8, x11, x8
    41d0:      	mov	w11, #0x94              // =148
    41d4:      	add	x8, x8, x9
    41d8:      	mov	w9, #0x8                // =8
    41dc:      	ldrb	w10, [x10, #0x213]
    41e0:      	ldp	x9, x8, [sp, #0x8]
    41e4:      	lsl	x9, x9, x10
    41e8:      	ldr	x10, [x21]
    41ec:      	add	x8, x10, x8
    41f0:      	add	x2, x8, x9
    41f4:      	blr	x11
    41f8:      	cbnz	w0, 0x42a4 <try_preload_arg+0x524>
    41fc:      	b	0x4208 <try_preload_arg+0x488>
    4200:      	ldr	x8, [x21]
    4204:      	str	x8, [sp, #0x10]
    4208:      	mov	w8, #0x18               // =24
    420c:      	ldr	x10, [sp, #0x10]
    4210:      	umaddl	x8, w19, w8, x20
    4214:      	ldrb	w9, [x8, #0x210]
    4218:      	ldrb	w8, [x8, #0x212]
    421c:      	lsl	x10, x10, x9
    4220:      	cmp	w8, #0x0
    4224:      	lsr	x11, x10, x9
    4228:      	asr	x9, x10, x9
    422c:      	csel	x8, x11, x9, eq
    4230:      	cmp	w19, #0x4
    4234:      	str	x8, [sp, #0x8]
    4238:      	b.hi	0x4714 <try_preload_arg+0x994>
    423c:      	b	0x42b4 <try_preload_arg+0x534>
    4240:      	mov	w8, #0x18               // =24
    4244:      	mov	w9, #0x71               // =113
    4248:      	add	x10, sp, #0x10
    424c:      	mov	w1, #0x8                // =8
    4250:      	umaddl	x8, w19, w8, x20
    4254:      	ldr	w8, [x8, #0x208]
    4258:      	and	x8, x8, #0xfff
    425c:      	add	x2, x0, x8
    4260:      	mov	w8, #0x8                // =8
    4264:      	add	x0, sp, #0x10
    4268:      	blr	x9
    426c:      	cbnz	w0, 0x42a4 <try_preload_arg+0x524>
    4270:      	ldr	x8, [sp, #0x10]
    4274:      	ldr	x9, [x21]
    4278:      	mov	w10, #0x94              // =148
    427c:      	add	x11, sp, #0x10
    4280:      	add	x0, sp, #0x10
    4284:      	mov	w1, #0x8                // =8
    4288:      	add	x8, x8, x9
    428c:      	mov	w9, #0x8                // =8
    4290:      	ldr	x8, [sp, #0x10]
    4294:      	ldr	x9, [x21]
    4298:      	add	x2, x8, x9
    429c:      	blr	x10
    42a0:      	cbz	w0, 0x4208 <try_preload_arg+0x488>
    42a4:      	sxtw	x8, w0
    42a8:      	cmp	w19, #0x4
    42ac:      	str	x8, [sp, #0x8]
    42b0:      	b.hi	0x4714 <try_preload_arg+0x994>
    42b4:      	mov	w8, #0x50               // =80
    42b8:      	umaddl	x8, w19, w8, x20
    42bc:      	ldrh	w9, [x8, #0x76]
    42c0:      	cbz	w9, 0x4714 <try_preload_arg+0x994>
    42c4:      	add	x21, x8, #0x70
    42c8:      	add	x8, sp, #0x8
    42cc:      	stp	x21, x8, [sp, #0x10]
    42d0:      	mov	w8, #0x1                // =1
    42d4:      	strb	w8, [sp, #0x20]
    42d8:      	add	x8, sp, #0x38
    42dc:      	str	x8, [sp, #0x28]
    42e0:      	adrp	x8, 0x4000 <try_preload_arg+0x280>
    42e4:      	ldr	x8, [x8]
    42e8:      	ldrb	w8, [x8]
    42ec:      	cbz	w8, 0x45ac <try_preload_arg+0x82c>
    42f0:      	ldrh	w8, [x21, #0x6]
    42f4:      	cbz	w8, 0x4714 <try_preload_arg+0x994>
    42f8:      	ldr	x8, [sp, #0x8]
    42fc:      	ldr	w9, [x21]
    4300:      	add	x8, x8, x9
    4304:      	str	x8, [sp, #0x8]
    4308:      	ldrh	w9, [x21, #0x4]
    430c:      	cbz	w9, 0x4330 <try_preload_arg+0x5b0>
    4310:      	mov	w9, #0x8                // =8
    4314:      	mov	w10, #0x94              // =148
    4318:      	add	x11, sp, #0x8
    431c:      	ldr	x2, [sp, #0x8]
    4320:      	add	x0, sp, #0x8
    4324:      	mov	w1, #0x8                // =8
    4328:      	blr	x10
    432c:      	tbnz	w0, #0x1f, 0x45e8 <try_preload_arg+0x868>
    4330:      	ldrh	w8, [x21, #0xe]
    4334:      	cbz	w8, 0x4714 <try_preload_arg+0x994>
    4338:      	ldr	x8, [sp, #0x8]
    433c:      	ldr	w9, [x21, #0x8]
    4340:      	add	x8, x8, x9
    4344:      	str	x8, [sp, #0x8]
    4348:      	ldrh	w9, [x21, #0xc]
    434c:      	cbz	w9, 0x4370 <try_preload_arg+0x5f0>
    4350:      	mov	w9, #0x8                // =8
    4354:      	mov	w10, #0x94              // =148
    4358:      	add	x11, sp, #0x8
    435c:      	ldr	x2, [sp, #0x8]
    4360:      	add	x0, sp, #0x8
    4364:      	mov	w1, #0x8                // =8
    4368:      	blr	x10
    436c:      	tbnz	w0, #0x1f, 0x4604 <try_preload_arg+0x884>
    4370:      	ldrh	w8, [x21, #0x16]
    4374:      	cbz	w8, 0x4714 <try_preload_arg+0x994>
    4378:      	ldr	x8, [sp, #0x8]
    437c:      	ldr	w9, [x21, #0x10]
    4380:      	add	x8, x8, x9
    4384:      	str	x8, [sp, #0x8]
    4388:      	ldrh	w9, [x21, #0x14]
    438c:      	cbz	w9, 0x43b0 <try_preload_arg+0x630>
    4390:      	mov	w9, #0x8                // =8
    4394:      	mov	w10, #0x94              // =148
    4398:      	add	x11, sp, #0x8
    439c:      	ldr	x2, [sp, #0x8]
    43a0:      	add	x0, sp, #0x8
    43a4:      	mov	w1, #0x8                // =8
    43a8:      	blr	x10
    43ac:      	tbnz	w0, #0x1f, 0x4620 <try_preload_arg+0x8a0>
    43b0:      	ldrh	w8, [x21, #0x1e]
    43b4:      	cbz	w8, 0x4714 <try_preload_arg+0x994>
    43b8:      	ldr	x8, [sp, #0x8]
    43bc:      	ldr	w9, [x21, #0x18]
    43c0:      	add	x8, x8, x9
    43c4:      	str	x8, [sp, #0x8]
    43c8:      	ldrh	w9, [x21, #0x1c]
    43cc:      	cbz	w9, 0x43f0 <try_preload_arg+0x670>
    43d0:      	mov	w9, #0x8                // =8
    43d4:      	mov	w10, #0x94              // =148
    43d8:      	add	x11, sp, #0x8
    43dc:      	ldr	x2, [sp, #0x8]
    43e0:      	add	x0, sp, #0x8
    43e4:      	mov	w1, #0x8                // =8
    43e8:      	blr	x10
    43ec:      	tbnz	w0, #0x1f, 0x463c <try_preload_arg+0x8bc>
    43f0:      	ldrh	w8, [x21, #0x26]
    43f4:      	cbz	w8, 0x4714 <try_preload_arg+0x994>
    43f8:      	ldr	x8, [sp, #0x8]
    43fc:      	ldr	w9, [x21, #0x20]
    4400:      	add	x8, x8, x9
    4404:      	str	x8, [sp, #0x8]
    4408:      	ldrh	w9, [x21, #0x24]
    440c:      	cbz	w9, 0x4430 <try_preload_arg+0x6b0>
    4410:      	mov	w9, #0x8                // =8
    4414:      	mov	w10, #0x94              // =148
    4418:      	add	x11, sp, #0x8
    441c:      	ldr	x2, [sp, #0x8]
    4420:      	add	x0, sp, #0x8
    4424:      	mov	w1, #0x8                // =8
    4428:      	blr	x10
    442c:      	tbnz	w0, #0x1f, 0x4658 <try_preload_arg+0x8d8>
    4430:      	ldrh	w8, [x21, #0x2e]
    4434:      	cbz	w8, 0x4714 <try_preload_arg+0x994>
    4438:      	ldr	x8, [sp, #0x8]
    443c:      	ldr	w9, [x21, #0x28]
    4440:      	add	x8, x8, x9
    4444:      	str	x8, [sp, #0x8]
    4448:      	ldrh	w9, [x21, #0x2c]
    444c:      	cbz	w9, 0x4470 <try_preload_arg+0x6f0>
    4450:      	mov	w9, #0x8                // =8
    4454:      	mov	w10, #0x94              // =148
    4458:      	add	x11, sp, #0x8
    445c:      	ldr	x2, [sp, #0x8]
    4460:      	add	x0, sp, #0x8
    4464:      	mov	w1, #0x8                // =8
    4468:      	blr	x10
    446c:      	tbnz	w0, #0x1f, 0x4674 <try_preload_arg+0x8f4>
    4470:      	ldrh	w8, [x21, #0x36]
    4474:      	cbz	w8, 0x4714 <try_preload_arg+0x994>
    4478:      	ldr	x8, [sp, #0x8]
    447c:      	ldr	w9, [x21, #0x30]
    4480:      	add	x8, x8, x9
    4484:      	str	x8, [sp, #0x8]
    4488:      	ldrh	w9, [x21, #0x34]
    448c:      	cbz	w9, 0x44b0 <try_preload_arg+0x730>
    4490:      	mov	w9, #0x8                // =8
    4494:      	mov	w10, #0x94              // =148
    4498:      	add	x11, sp, #0x8
    449c:      	ldr	x2, [sp, #0x8]
    44a0:      	add	x0, sp, #0x8
    44a4:      	mov	w1, #0x8                // =8
    44a8:      	blr	x10
    44ac:      	tbnz	w0, #0x1f, 0x470c <try_preload_arg+0x98c>
    44b0:      	ldrh	w8, [x21, #0x3e]
    44b4:      	cbz	w8, 0x4714 <try_preload_arg+0x994>
    44b8:      	ldr	x8, [sp, #0x8]
    44bc:      	ldr	w9, [x21, #0x38]
    44c0:      	add	x8, x8, x9
    44c4:      	str	x8, [sp, #0x8]
    44c8:      	ldrh	w9, [x21, #0x3c]
    44cc:      	cbz	w9, 0x44f4 <try_preload_arg+0x774>
    44d0:      	mov	w9, #0x8                // =8
    44d4:      	mov	w10, #0x94              // =148
    44d8:      	add	x11, sp, #0x8
    44dc:      	ldr	x2, [sp, #0x8]
    44e0:      	add	x0, sp, #0x8
    44e4:      	mov	w1, #0x8                // =8
    44e8:      	blr	x10
    44ec:      	mov	w8, #0x8                // =8
    44f0:      	tbnz	w0, #0x1f, 0x4710 <try_preload_arg+0x990>
    44f4:      	ldrh	w8, [x21, #0x46]
    44f8:      	cbz	w8, 0x4714 <try_preload_arg+0x994>
    44fc:      	ldr	x8, [sp, #0x8]
    4500:      	ldr	w9, [x21, #0x40]
    4504:      	add	x8, x8, x9
    4508:      	str	x8, [sp, #0x8]
    450c:      	ldrh	w9, [x21, #0x44]
    4510:      	cbz	w9, 0x4534 <try_preload_arg+0x7b4>
    4514:      	mov	w9, #0x8                // =8
    4518:      	mov	w10, #0x94              // =148
    451c:      	add	x11, sp, #0x8
    4520:      	ldr	x2, [sp, #0x8]
    4524:      	add	x0, sp, #0x8
    4528:      	mov	w1, #0x8                // =8
    452c:      	blr	x10
    4530:      	tbnz	w0, #0x1f, 0x4810 <try_preload_arg+0xa90>
    4534:      	ldrh	w8, [x21, #0x4e]
    4538:      	cbz	w8, 0x4714 <try_preload_arg+0x994>
    453c:      	ldr	x8, [sp, #0x8]
    4540:      	ldr	w9, [x21, #0x48]
    4544:      	add	x8, x8, x9
    4548:      	str	x8, [sp, #0x8]
    454c:      	ldrh	w9, [x21, #0x4c]
    4550:      	cbz	w9, 0x4714 <try_preload_arg+0x994>
    4554:      	mov	w9, #0x8                // =8
    4558:      	mov	w10, #0x94              // =148
    455c:      	add	x11, sp, #0x8
    4560:      	ldr	x2, [sp, #0x8]
    4564:      	add	x0, sp, #0x8
    4568:      	mov	w1, #0x8                // =8
    456c:      	blr	x10
    4570:      	tbz	w0, #0x1f, 0x4714 <try_preload_arg+0x994>
    4574:      	mov	w8, #0xa                // =10
    4578:      	b	0x4710 <try_preload_arg+0x990>
    457c:      	mov	x3, xzr
    4580:      	adrp	x1, 0x4000 <try_preload_arg+0x280>
    4584:      	add	x1, x1, #0x0
    4588:      	mov	w8, #0xa                // =10
    458c:      	mov	w9, #0xb5               // =181
    4590:      	add	x10, sp, #0x10
    4594:      	add	x2, sp, #0x10
    4598:      	mov	w0, #0xa                // =10
    459c:      	blr	x9
    45a0:      	cmp	w21, #0x6
    45a4:      	b.eq	0x468c <try_preload_arg+0x90c>
    45a8:      	b	0x3da4 <try_preload_arg+0x24>
    45ac:      	mov	x3, xzr
    45b0:      	adrp	x1, 0x4000 <try_preload_arg+0x280>
    45b4:      	add	x1, x1, #0x0
    45b8:      	mov	w8, #0xa                // =10
    45bc:      	mov	w9, #0xb5               // =181
    45c0:      	add	x10, sp, #0x10
    45c4:      	add	x2, sp, #0x10
    45c8:      	mov	w0, #0xa                // =10
    45cc:      	blr	x9
    45d0:      	b	0x4714 <try_preload_arg+0x994>
    45d4:      	mov	w20, #0x1               // =1
    45d8:      	str	w20, [sp, #0x38]
    45dc:      	cmp	w21, #0x6
    45e0:      	b.eq	0x468c <try_preload_arg+0x90c>
    45e4:      	b	0x3da4 <try_preload_arg+0x24>
    45e8:      	mov	w8, #0x1                // =1
    45ec:      	b	0x4710 <try_preload_arg+0x990>
    45f0:      	mov	w20, #0x2               // =2
    45f4:      	str	w20, [sp, #0x38]
    45f8:      	cmp	w21, #0x6
    45fc:      	b.eq	0x468c <try_preload_arg+0x90c>
    4600:      	b	0x3da4 <try_preload_arg+0x24>
    4604:      	mov	w8, #0x2                // =2
    4608:      	b	0x4710 <try_preload_arg+0x990>
    460c:      	mov	w20, #0x3               // =3
    4610:      	str	w20, [sp, #0x38]
    4614:      	cmp	w21, #0x6
    4618:      	b.eq	0x468c <try_preload_arg+0x90c>
    461c:      	b	0x3da4 <try_preload_arg+0x24>
    4620:      	mov	w8, #0x3                // =3
    4624:      	b	0x4710 <try_preload_arg+0x990>
    4628:      	mov	w20, #0x4               // =4
    462c:      	str	w20, [sp, #0x38]
    4630:      	cmp	w21, #0x6
    4634:      	b.eq	0x468c <try_preload_arg+0x90c>
    4638:      	b	0x3da4 <try_preload_arg+0x24>
    463c:      	mov	w8, #0x4                // =4
    4640:      	b	0x4710 <try_preload_arg+0x990>
    4644:      	mov	w20, #0x5               // =5
    4648:      	str	w20, [sp, #0x38]
    464c:      	cmp	w21, #0x6
    4650:      	b.eq	0x468c <try_preload_arg+0x90c>
    4654:      	b	0x3da4 <try_preload_arg+0x24>
    4658:      	mov	w8, #0x5                // =5
    465c:      	b	0x4710 <try_preload_arg+0x990>
    4660:      	mov	w20, #0x6               // =6
    4664:      	str	w20, [sp, #0x38]
    4668:      	cmp	w21, #0x6
    466c:      	b.eq	0x468c <try_preload_arg+0x90c>
    4670:      	b	0x3da4 <try_preload_arg+0x24>
    4674:      	mov	w8, #0x6                // =6
    4678:      	b	0x4710 <try_preload_arg+0x990>
    467c:      	mov	w20, #0x7               // =7
    4680:      	str	w20, [sp, #0x38]
    4684:      	cmp	w21, #0x6
    4688:      	b.ne	0x3da4 <try_preload_arg+0x24>
    468c:      	ldr	x19, [sp, #0x8]
    4690:      	ldr	w21, [sp, #0x38]
    4694:      	mov	w8, #0xe                // =14
    4698:      	blr	x8
    469c:      	str	x0, [sp, #0x10]
    46a0:      	str	wzr, [sp, #0x3c]
    46a4:      	adrp	x0, 0x4000 <try_preload_arg+0x280>
    46a8:      	mov	w8, #0x1                // =1
    46ac:      	add	x9, sp, #0x3c
    46b0:      	add	x1, sp, #0x3c
    46b4:      	ldr	x0, [x0]
    46b8:      	blr	x8
    46bc:      	cbz	x0, 0x3da4 <try_preload_arg+0x24>
    46c0:      	adrp	x20, 0x4000 <try_preload_arg+0x280>
    46c4:      	mov	x3, xzr
    46c8:      	mov	w8, #0x2                // =2
    46cc:      	ldr	x20, [x20]
    46d0:      	add	x22, sp, #0x10
    46d4:      	mov	x2, x0
    46d8:      	add	x1, sp, #0x10
    46dc:      	mov	x0, x20
    46e0:      	blr	x8
    46e4:      	mov	w8, #0x1                // =1
    46e8:      	add	x1, sp, #0x10
    46ec:      	mov	x0, x20
    46f0:      	blr	x8
    46f4:      	cbz	x0, 0x3da4 <try_preload_arg+0x24>
    46f8:      	cbnz	w21, 0x47e0 <try_preload_arg+0xa60>
    46fc:      	add	x8, x0, #0x4
    4700:      	mov	w9, #0x1000             // =4096
    4704:      	mov	w10, #0x72              // =114
    4708:      	b	0x47bc <try_preload_arg+0xa3c>
    470c:      	mov	w8, #0x7                // =7
    4710:      	str	w8, [sp, #0x38]
    4714:      	add	x8, x20, x19, lsl #2
    4718:      	mov	w9, #0x4                // =4
    471c:      	add	x10, sp, #0x8
    4720:      	ldr	w19, [x8, #0x4]
    4724:      	mov	w8, #0x8                // =8
    4728:      	add	x0, sp, #0x8
    472c:      	add	x2, sp, #0x8
    4730:      	mov	w1, #0x8                // =8
    4734:      	blr	x9
    4738:      	cmp	w19, #0x6
    473c:      	b.ne	0x3da4 <try_preload_arg+0x24>
    4740:      	ldr	x19, [sp, #0x8]
    4744:      	ldr	w21, [sp, #0x38]
    4748:      	mov	w8, #0xe                // =14
    474c:      	blr	x8
    4750:      	str	x0, [sp, #0x10]
    4754:      	str	wzr, [sp, #0x3c]
    4758:      	adrp	x0, 0x4000 <try_preload_arg+0x280>
    475c:      	mov	w8, #0x1                // =1
    4760:      	add	x9, sp, #0x3c
    4764:      	add	x1, sp, #0x3c
    4768:      	ldr	x0, [x0]
    476c:      	blr	x8
    4770:      	cbz	x0, 0x3da4 <try_preload_arg+0x24>
    4774:      	adrp	x20, 0x4000 <try_preload_arg+0x280>
    4778:      	mov	x3, xzr
    477c:      	mov	w8, #0x2                // =2
    4780:      	ldr	x20, [x20]
    4784:      	add	x22, sp, #0x10
    4788:      	mov	x2, x0
    478c:      	add	x1, sp, #0x10
    4790:      	mov	x0, x20
    4794:      	blr	x8
    4798:      	mov	w8, #0x1                // =1
    479c:      	add	x1, sp, #0x10
    47a0:      	mov	x0, x20
    47a4:      	blr	x8
    47a8:      	cbz	x0, 0x3da4 <try_preload_arg+0x24>
    47ac:      	cbnz	w21, 0x47e0 <try_preload_arg+0xa60>
    47b0:      	add	x8, x0, #0x4
    47b4:      	mov	w9, #0x1000             // =4096
    47b8:      	mov	w10, #0x72              // =114
    47bc:      	mov	x20, x0
    47c0:      	mov	x0, x8
    47c4:      	mov	w1, #0x1000             // =4096
    47c8:      	mov	x2, x19
    47cc:      	blr	x10
    47d0:      	mov	x8, x0
    47d4:      	mov	x0, x20
    47d8:      	tbz	x8, #0x3f, 0x47e0 <try_preload_arg+0xa60>
    47dc:      	mov	w21, #-0x1              // =-1
    47e0:      	str	w21, [x0]
    47e4:      	ldp	x20, x19, [sp, #0x50]
    47e8:      	mov	w0, wzr
    47ec:      	ldr	x30, [sp, #0x30]
    47f0:      	ldp	x22, x21, [sp, #0x40]
    47f4:      	add	sp, sp, #0x60
    47f8:      	ret
    47fc:      	mov	w20, #0x9               // =9
    4800:      	str	w20, [sp, #0x38]
    4804:      	cmp	w21, #0x6
    4808:      	b.eq	0x468c <try_preload_arg+0x90c>
    480c:      	b	0x3da4 <try_preload_arg+0x24>
    4810:      	mov	w8, #0x9                // =9
    4814:      	b	0x4710 <try_preload_arg+0x990>

Disassembly of section uprobe:

0000000000000000 <generic_usdt_setup_event>:
       0:      	sub	sp, sp, #0x50
       4:      	stp	x30, x23, [sp, #0x20]
       8:      	stp	x22, x21, [sp, #0x30]
       c:      	stp	x20, x19, [sp, #0x40]
      10:      	str	wzr, [sp, #0xc]
      14:      	adrp	x20, 0x0 <generic_usdt_setup_event>
      18:      	mov	w8, #0x1                // =1
      1c:      	add	x9, sp, #0xc
      20:      	ldr	x20, [x20]
      24:      	mov	x19, x0
      28:      	add	x1, sp, #0xc
      2c:      	mov	x0, x20
      30:      	blr	x8
      34:      	cbz	x0, 0x978 <generic_usdt_setup_event+0x978>
      38:      	adrp	x21, 0x0 <generic_usdt_setup_event>
      3c:      	mov	w8, #0x5ef8             // =24312
      40:      	mov	x22, x0
      44:      	ldr	x21, [x21]
      48:      	add	x1, x0, x8
      4c:      	mov	w8, #0x1                // =1
      50:      	mov	x0, x21
      54:      	blr	x8
      58:      	cbz	x0, 0x978 <generic_usdt_setup_event+0x978>
      5c:      	mov	w8, #0x1c               // =28
      60:      	strh	wzr, [x22, #0x2]
      64:      	str	wzr, [x22, #0x4]
      68:      	mov	x23, x0
      6c:      	strb	w8, [x22]
      70:      	mov	w8, #0x7d               // =125
      74:      	blr	x8
      78:      	str	x0, [x22, #0x8]
      7c:      	str	xzr, [x22, #0x70]
      80:      	mov	w8, #0xe                // =14
      84:      	str	wzr, [x22, #0x14]
      88:      	blr	x8
      8c:      	str	w0, [x22, #0x7c]
      90:      	mov	x9, xzr
      94:      	ldrb	w8, [x23, #0x211]
      98:      	cmp	w8, #0x2
      9c:      	b.gt	0xf4 <generic_usdt_setup_event+0xf4>
      a0:      	cmp	w8, #0x1
      a4:      	b.eq	0x1a4 <generic_usdt_setup_event+0x1a4>
      a8:      	cmp	w8, #0x2
      ac:      	b.ne	0x1cc <generic_usdt_setup_event+0x1cc>
      b0:      	ldr	w8, [x23, #0x208]
      b4:      	mov	w9, #0x71               // =113
      b8:      	add	x10, sp, #0x18
      bc:      	add	x0, sp, #0x18
      c0:      	mov	w1, #0x8                // =8
      c4:      	and	x8, x8, #0xfff
      c8:      	add	x2, x19, x8
      cc:      	mov	w8, #0x8                // =8
      d0:      	blr	x9
      d4:      	cbz	w0, 0x1ac <generic_usdt_setup_event+0x1ac>
      d8:      	mov	x9, xzr
      dc:      	str	xzr, [x22, #0x5e50]
      e0:      	mov	x8, xzr
      e4:      	ldrb	w9, [x23, #0x229]
      e8:      	cmp	w9, #0x2
      ec:      	b.gt	0x2a8 <generic_usdt_setup_event+0x2a8>
      f0:      	b	0x1e0 <generic_usdt_setup_event+0x1e0>
      f4:      	cmp	w8, #0x3
      f8:      	b.eq	0x234 <generic_usdt_setup_event+0x234>
      fc:      	cmp	w8, #0x4
     100:      	b.ne	0x1cc <generic_usdt_setup_event+0x1cc>
     104:      	ldr	w8, [x23, #0x208]
     108:      	mov	w9, #0x71               // =113
     10c:      	add	x10, sp, #0x18
     110:      	add	x0, sp, #0x18
     114:      	mov	w1, #0x8                // =8
     118:      	and	x8, x8, #0xfff
     11c:      	add	x2, x19, x8
     120:      	mov	w8, #0x8                // =8
     124:      	blr	x9
     128:      	cbnz	w0, 0x290 <generic_usdt_setup_event+0x290>
     12c:      	ldr	w8, [x23, #0x20c]
     130:      	mov	w9, #0x71               // =113
     134:      	add	x10, sp, #0x10
     138:      	add	x0, sp, #0x10
     13c:      	mov	w1, #0x8                // =8
     140:      	and	x8, x8, #0xfff
     144:      	add	x2, x19, x8
     148:      	mov	w8, #0x8                // =8
     14c:      	blr	x9
     150:      	cbnz	w0, 0x290 <generic_usdt_setup_event+0x290>
     154:      	ldp	x9, x8, [sp, #0x10]
     158:      	add	x11, sp, #0x18
     15c:      	add	x0, sp, #0x18
     160:      	mov	w1, #0x8                // =8
     164:      	ldrb	w10, [x23, #0x213]
     168:      	lsl	x9, x9, x10
     16c:      	ldr	x10, [x23, #0x200]
     170:      	add	x8, x10, x8
     174:      	mov	w10, #0x70              // =112
     178:      	add	x8, x8, x9
     17c:      	mov	w9, #0x8                // =8
     180:      	ldp	x9, x8, [sp, #0x10]
     184:      	ldrb	w11, [x23, #0x213]
     188:      	lsl	x9, x9, x11
     18c:      	ldr	x11, [x23, #0x200]
     190:      	add	x8, x11, x8
     194:      	add	x2, x8, x9
     198:      	blr	x10
     19c:      	cbnz	w0, 0x290 <generic_usdt_setup_event+0x290>
     1a0:      	b	0x1ac <generic_usdt_setup_event+0x1ac>
     1a4:      	ldr	x8, [x23, #0x200]
     1a8:      	str	x8, [sp, #0x18]
     1ac:      	ldrb	w8, [x23, #0x210]
     1b0:      	ldr	x9, [sp, #0x18]
     1b4:      	lsl	x9, x9, x8
     1b8:      	ldrb	w10, [x23, #0x212]
     1bc:      	cmp	w10, #0x0
     1c0:      	lsr	x11, x9, x8
     1c4:      	asr	x8, x9, x8
     1c8:      	csel	x9, x11, x8, eq
     1cc:      	str	x9, [x22, #0x5e50]
     1d0:      	mov	x8, xzr
     1d4:      	ldrb	w9, [x23, #0x229]
     1d8:      	cmp	w9, #0x2
     1dc:      	b.gt	0x2a8 <generic_usdt_setup_event+0x2a8>
     1e0:      	cmp	w9, #0x1
     1e4:      	b.eq	0x358 <generic_usdt_setup_event+0x358>
     1e8:      	cmp	w9, #0x2
     1ec:      	b.ne	0x384 <generic_usdt_setup_event+0x384>
     1f0:      	ldr	w8, [x23, #0x220]
     1f4:      	mov	w9, #0x71               // =113
     1f8:      	add	x10, sp, #0x18
     1fc:      	add	x0, sp, #0x18
     200:      	mov	w1, #0x8                // =8
     204:      	and	x8, x8, #0xfff
     208:      	add	x2, x19, x8
     20c:      	mov	w8, #0x8                // =8
     210:      	blr	x9
     214:      	cbz	w0, 0x360 <generic_usdt_setup_event+0x360>
     218:      	mov	x8, xzr
     21c:      	str	xzr, [x22, #0x5e58]
     220:      	mov	x9, xzr
     224:      	ldrb	w8, [x23, #0x241]
     228:      	cmp	w8, #0x2
     22c:      	b.gt	0x460 <generic_usdt_setup_event+0x460>
     230:      	b	0x398 <generic_usdt_setup_event+0x398>
     234:      	ldr	w8, [x23, #0x208]
     238:      	mov	w9, #0x71               // =113
     23c:      	add	x10, sp, #0x18
     240:      	add	x0, sp, #0x18
     244:      	mov	w1, #0x8                // =8
     248:      	and	x8, x8, #0xfff
     24c:      	add	x2, x19, x8
     250:      	mov	w8, #0x8                // =8
     254:      	blr	x9
     258:      	cbnz	w0, 0x290 <generic_usdt_setup_event+0x290>
     25c:      	ldr	x8, [sp, #0x18]
     260:      	ldr	x9, [x23, #0x200]
     264:      	mov	w10, #0x70              // =112
     268:      	add	x11, sp, #0x18
     26c:      	add	x0, sp, #0x18
     270:      	mov	w1, #0x8                // =8
     274:      	add	x8, x8, x9
     278:      	mov	w9, #0x8                // =8
     27c:      	ldr	x8, [sp, #0x18]
     280:      	ldr	x9, [x23, #0x200]
     284:      	add	x2, x8, x9
     288:      	blr	x10
     28c:      	cbz	w0, 0x1ac <generic_usdt_setup_event+0x1ac>
     290:      	sxtw	x9, w0
     294:      	str	x9, [x22, #0x5e50]
     298:      	mov	x8, xzr
     29c:      	ldrb	w9, [x23, #0x229]
     2a0:      	cmp	w9, #0x2
     2a4:      	b.le	0x1e0 <generic_usdt_setup_event+0x1e0>
     2a8:      	cmp	w9, #0x3
     2ac:      	b.eq	0x3ec <generic_usdt_setup_event+0x3ec>
     2b0:      	cmp	w9, #0x4
     2b4:      	b.ne	0x384 <generic_usdt_setup_event+0x384>
     2b8:      	ldr	w8, [x23, #0x220]
     2bc:      	mov	w9, #0x71               // =113
     2c0:      	add	x10, sp, #0x18
     2c4:      	add	x0, sp, #0x18
     2c8:      	mov	w1, #0x8                // =8
     2cc:      	and	x8, x8, #0xfff
     2d0:      	add	x2, x19, x8
     2d4:      	mov	w8, #0x8                // =8
     2d8:      	blr	x9
     2dc:      	cbnz	w0, 0x448 <generic_usdt_setup_event+0x448>
     2e0:      	ldr	w8, [x23, #0x224]
     2e4:      	mov	w9, #0x71               // =113
     2e8:      	add	x10, sp, #0x10
     2ec:      	add	x0, sp, #0x10
     2f0:      	mov	w1, #0x8                // =8
     2f4:      	and	x8, x8, #0xfff
     2f8:      	add	x2, x19, x8
     2fc:      	mov	w8, #0x8                // =8
     300:      	blr	x9
     304:      	cbnz	w0, 0x448 <generic_usdt_setup_event+0x448>
     308:      	ldp	x9, x8, [sp, #0x10]
     30c:      	add	x11, sp, #0x18
     310:      	add	x0, sp, #0x18
     314:      	mov	w1, #0x8                // =8
     318:      	ldrb	w10, [x23, #0x22b]
     31c:      	lsl	x9, x9, x10
     320:      	ldr	x10, [x23, #0x218]
     324:      	add	x8, x10, x8
     328:      	mov	w10, #0x70              // =112
     32c:      	add	x8, x8, x9
     330:      	mov	w9, #0x8                // =8
     334:      	ldp	x9, x8, [sp, #0x10]
     338:      	ldrb	w11, [x23, #0x22b]
     33c:      	lsl	x9, x9, x11
     340:      	ldr	x11, [x23, #0x218]
     344:      	add	x8, x11, x8
     348:      	add	x2, x8, x9
     34c:      	blr	x10
     350:      	cbnz	w0, 0x448 <generic_usdt_setup_event+0x448>
     354:      	b	0x360 <generic_usdt_setup_event+0x360>
     358:      	ldr	x8, [x23, #0x218]
     35c:      	str	x8, [sp, #0x18]
     360:      	ldrb	w8, [x23, #0x228]
     364:      	ldr	x9, [sp, #0x18]
     368:      	lsl	x9, x9, x8
     36c:      	ldrb	w10, [x23, #0x22a]
     370:      	cmp	w10, #0x0
     374:      	lsr	x11, x9, x8
     378:      	asr	x8, x9, x8
     37c:      	csel	x8, x11, x8, eq
     380:      	str	x9, [sp, #0x18]
     384:      	str	x8, [x22, #0x5e58]
     388:      	mov	x9, xzr
     38c:      	ldrb	w8, [x23, #0x241]
     390:      	cmp	w8, #0x2
     394:      	b.gt	0x460 <generic_usdt_setup_event+0x460>
     398:      	cmp	w8, #0x1
     39c:      	b.eq	0x510 <generic_usdt_setup_event+0x510>
     3a0:      	cmp	w8, #0x2
     3a4:      	b.ne	0x53c <generic_usdt_setup_event+0x53c>
     3a8:      	ldr	w8, [x23, #0x238]
     3ac:      	mov	w9, #0x71               // =113
     3b0:      	add	x10, sp, #0x18
     3b4:      	add	x0, sp, #0x18
     3b8:      	mov	w1, #0x8                // =8
     3bc:      	and	x8, x8, #0xfff
     3c0:      	add	x2, x19, x8
     3c4:      	mov	w8, #0x8                // =8
     3c8:      	blr	x9
     3cc:      	cbz	w0, 0x518 <generic_usdt_setup_event+0x518>
     3d0:      	mov	x9, xzr
     3d4:      	str	xzr, [x22, #0x5e60]
     3d8:      	mov	x8, xzr
     3dc:      	ldrb	w9, [x23, #0x259]
     3e0:      	cmp	w9, #0x2
     3e4:      	b.gt	0x618 <generic_usdt_setup_event+0x618>
     3e8:      	b	0x550 <generic_usdt_setup_event+0x550>
     3ec:      	ldr	w8, [x23, #0x220]
     3f0:      	mov	w9, #0x71               // =113
     3f4:      	add	x10, sp, #0x18
     3f8:      	add	x0, sp, #0x18
     3fc:      	mov	w1, #0x8                // =8
     400:      	and	x8, x8, #0xfff
     404:      	add	x2, x19, x8
     408:      	mov	w8, #0x8                // =8
     40c:      	blr	x9
     410:      	cbnz	w0, 0x448 <generic_usdt_setup_event+0x448>
     414:      	ldr	x8, [sp, #0x18]
     418:      	ldr	x9, [x23, #0x218]
     41c:      	mov	w10, #0x70              // =112
     420:      	add	x11, sp, #0x18
     424:      	add	x0, sp, #0x18
     428:      	mov	w1, #0x8                // =8
     42c:      	add	x8, x8, x9
     430:      	mov	w9, #0x8                // =8
     434:      	ldr	x8, [sp, #0x18]
     438:      	ldr	x9, [x23, #0x218]
     43c:      	add	x2, x8, x9
     440:      	blr	x10
     444:      	cbz	w0, 0x360 <generic_usdt_setup_event+0x360>
     448:      	sxtw	x8, w0
     44c:      	str	x8, [x22, #0x5e58]
     450:      	mov	x9, xzr
     454:      	ldrb	w8, [x23, #0x241]
     458:      	cmp	w8, #0x2
     45c:      	b.le	0x398 <generic_usdt_setup_event+0x398>
     460:      	cmp	w8, #0x3
     464:      	b.eq	0x5a4 <generic_usdt_setup_event+0x5a4>
     468:      	cmp	w8, #0x4
     46c:      	b.ne	0x53c <generic_usdt_setup_event+0x53c>
     470:      	ldr	w8, [x23, #0x238]
     474:      	mov	w9, #0x71               // =113
     478:      	add	x10, sp, #0x18
     47c:      	add	x0, sp, #0x18
     480:      	mov	w1, #0x8                // =8
     484:      	and	x8, x8, #0xfff
     488:      	add	x2, x19, x8
     48c:      	mov	w8, #0x8                // =8
     490:      	blr	x9
     494:      	cbnz	w0, 0x600 <generic_usdt_setup_event+0x600>
     498:      	ldr	w8, [x23, #0x23c]
     49c:      	mov	w9, #0x71               // =113
     4a0:      	add	x10, sp, #0x10
     4a4:      	add	x0, sp, #0x10
     4a8:      	mov	w1, #0x8                // =8
     4ac:      	and	x8, x8, #0xfff
     4b0:      	add	x2, x19, x8
     4b4:      	mov	w8, #0x8                // =8
     4b8:      	blr	x9
     4bc:      	cbnz	w0, 0x600 <generic_usdt_setup_event+0x600>
     4c0:      	ldp	x9, x8, [sp, #0x10]
     4c4:      	add	x11, sp, #0x18
     4c8:      	add	x0, sp, #0x18
     4cc:      	mov	w1, #0x8                // =8
     4d0:      	ldrb	w10, [x23, #0x243]
     4d4:      	lsl	x9, x9, x10
     4d8:      	ldr	x10, [x23, #0x230]
     4dc:      	add	x8, x10, x8
     4e0:      	mov	w10, #0x70              // =112
     4e4:      	add	x8, x8, x9
     4e8:      	mov	w9, #0x8                // =8
     4ec:      	ldp	x9, x8, [sp, #0x10]
     4f0:      	ldrb	w11, [x23, #0x243]
     4f4:      	lsl	x9, x9, x11
     4f8:      	ldr	x11, [x23, #0x230]
     4fc:      	add	x8, x11, x8
     500:      	add	x2, x8, x9
     504:      	blr	x10
     508:      	cbnz	w0, 0x600 <generic_usdt_setup_event+0x600>
     50c:      	b	0x518 <generic_usdt_setup_event+0x518>
     510:      	ldr	x8, [x23, #0x230]
     514:      	str	x8, [sp, #0x18]
     518:      	ldrb	w8, [x23, #0x240]
     51c:      	ldr	x9, [sp, #0x18]
     520:      	lsl	x9, x9, x8
     524:      	ldrb	w10, [x23, #0x242]
     528:      	cmp	w10, #0x0
     52c:      	lsr	x11, x9, x8
     530:      	asr	x8, x9, x8
     534:      	str	x9, [sp, #0x18]
     538:      	csel	x9, x11, x8, eq
     53c:      	str	x9, [x22, #0x5e60]
     540:      	mov	x8, xzr
     544:      	ldrb	w9, [x23, #0x259]
     548:      	cmp	w9, #0x2
     54c:      	b.gt	0x618 <generic_usdt_setup_event+0x618>
     550:      	cmp	w9, #0x1
     554:      	b.eq	0x6c8 <generic_usdt_setup_event+0x6c8>
     558:      	cmp	w9, #0x2
     55c:      	b.ne	0x6f4 <generic_usdt_setup_event+0x6f4>
     560:      	ldr	w8, [x23, #0x250]
     564:      	mov	w9, #0x71               // =113
     568:      	add	x10, sp, #0x18
     56c:      	add	x0, sp, #0x18
     570:      	mov	w1, #0x8                // =8
     574:      	and	x8, x8, #0xfff
     578:      	add	x2, x19, x8
     57c:      	mov	w8, #0x8                // =8
     580:      	blr	x9
     584:      	cbz	w0, 0x6d0 <generic_usdt_setup_event+0x6d0>
     588:      	mov	x8, xzr
     58c:      	str	xzr, [x22, #0x5e68]
     590:      	mov	x9, xzr
     594:      	ldrb	w8, [x23, #0x271]
     598:      	cmp	w8, #0x2
     59c:      	b.gt	0x7bc <generic_usdt_setup_event+0x7bc>
     5a0:      	b	0x708 <generic_usdt_setup_event+0x708>
     5a4:      	ldr	w8, [x23, #0x238]
     5a8:      	mov	w9, #0x71               // =113
     5ac:      	add	x10, sp, #0x18
     5b0:      	add	x0, sp, #0x18
     5b4:      	mov	w1, #0x8                // =8
     5b8:      	and	x8, x8, #0xfff
     5bc:      	add	x2, x19, x8
     5c0:      	mov	w8, #0x8                // =8
     5c4:      	blr	x9
     5c8:      	cbnz	w0, 0x600 <generic_usdt_setup_event+0x600>
     5cc:      	ldr	x8, [sp, #0x18]
     5d0:      	ldr	x9, [x23, #0x230]
     5d4:      	mov	w10, #0x70              // =112
     5d8:      	add	x11, sp, #0x18
     5dc:      	add	x0, sp, #0x18
     5e0:      	mov	w1, #0x8                // =8
     5e4:      	add	x8, x8, x9
     5e8:      	mov	w9, #0x8                // =8
     5ec:      	ldr	x8, [sp, #0x18]
     5f0:      	ldr	x9, [x23, #0x230]
     5f4:      	add	x2, x8, x9
     5f8:      	blr	x10
     5fc:      	cbz	w0, 0x518 <generic_usdt_setup_event+0x518>
     600:      	sxtw	x9, w0
     604:      	str	x9, [x22, #0x5e60]
     608:      	mov	x8, xzr
     60c:      	ldrb	w9, [x23, #0x259]
     610:      	cmp	w9, #0x2
     614:      	b.le	0x550 <generic_usdt_setup_event+0x550>
     618:      	cmp	w9, #0x3
     61c:      	b.eq	0x748 <generic_usdt_setup_event+0x748>
     620:      	cmp	w9, #0x4
     624:      	b.ne	0x6f4 <generic_usdt_setup_event+0x6f4>
     628:      	ldr	w8, [x23, #0x250]
     62c:      	mov	w9, #0x71               // =113
     630:      	add	x10, sp, #0x18
     634:      	add	x0, sp, #0x18
     638:      	mov	w1, #0x8                // =8
     63c:      	and	x8, x8, #0xfff
     640:      	add	x2, x19, x8
     644:      	mov	w8, #0x8                // =8
     648:      	blr	x9
     64c:      	cbnz	w0, 0x7a4 <generic_usdt_setup_event+0x7a4>
     650:      	ldr	w8, [x23, #0x254]
     654:      	mov	w9, #0x71               // =113
     658:      	add	x10, sp, #0x10
     65c:      	add	x0, sp, #0x10
     660:      	mov	w1, #0x8                // =8
     664:      	and	x8, x8, #0xfff
     668:      	add	x2, x19, x8
     66c:      	mov	w8, #0x8                // =8
     670:      	blr	x9
     674:      	cbnz	w0, 0x7a4 <generic_usdt_setup_event+0x7a4>
     678:      	ldp	x9, x8, [sp, #0x10]
     67c:      	add	x11, sp, #0x18
     680:      	add	x0, sp, #0x18
     684:      	mov	w1, #0x8                // =8
     688:      	ldrb	w10, [x23, #0x25b]
     68c:      	lsl	x9, x9, x10
     690:      	ldr	x10, [x23, #0x248]
     694:      	add	x8, x10, x8
     698:      	mov	w10, #0x70              // =112
     69c:      	add	x8, x8, x9
     6a0:      	mov	w9, #0x8                // =8
     6a4:      	ldp	x9, x8, [sp, #0x10]
     6a8:      	ldrb	w11, [x23, #0x25b]
     6ac:      	lsl	x9, x9, x11
     6b0:      	ldr	x11, [x23, #0x248]
     6b4:      	add	x8, x11, x8
     6b8:      	add	x2, x8, x9
     6bc:      	blr	x10
     6c0:      	cbnz	w0, 0x7a4 <generic_usdt_setup_event+0x7a4>
     6c4:      	b	0x6d0 <generic_usdt_setup_event+0x6d0>
     6c8:      	ldr	x8, [x23, #0x248]
     6cc:      	str	x8, [sp, #0x18]
     6d0:      	ldrb	w8, [x23, #0x258]
     6d4:      	ldr	x9, [sp, #0x18]
     6d8:      	lsl	x9, x9, x8
     6dc:      	ldrb	w10, [x23, #0x25a]
     6e0:      	cmp	w10, #0x0
     6e4:      	lsr	x11, x9, x8
     6e8:      	asr	x8, x9, x8
     6ec:      	csel	x8, x11, x8, eq
     6f0:      	str	x9, [sp, #0x18]
     6f4:      	str	x8, [x22, #0x5e68]
     6f8:      	mov	x9, xzr
     6fc:      	ldrb	w8, [x23, #0x271]
     700:      	cmp	w8, #0x2
     704:      	b.gt	0x7bc <generic_usdt_setup_event+0x7bc>
     708:      	cmp	w8, #0x1
     70c:      	b.eq	0x86c <generic_usdt_setup_event+0x86c>
     710:      	cmp	w8, #0x2
     714:      	b.ne	0x8fc <generic_usdt_setup_event+0x8fc>
     718:      	ldr	w8, [x23, #0x268]
     71c:      	mov	w9, #0x71               // =113
     720:      	add	x10, sp, #0x18
     724:      	add	x0, sp, #0x18
     728:      	mov	w1, #0x8                // =8
     72c:      	and	x8, x8, #0xfff
     730:      	add	x2, x19, x8
     734:      	mov	w8, #0x8                // =8
     738:      	blr	x9
     73c:      	cbz	w0, 0x874 <generic_usdt_setup_event+0x874>
     740:      	mov	x9, xzr
     744:      	b	0x8fc <generic_usdt_setup_event+0x8fc>
     748:      	ldr	w8, [x23, #0x250]
     74c:      	mov	w9, #0x71               // =113
     750:      	add	x10, sp, #0x18
     754:      	add	x0, sp, #0x18
     758:      	mov	w1, #0x8                // =8
     75c:      	and	x8, x8, #0xfff
     760:      	add	x2, x19, x8
     764:      	mov	w8, #0x8                // =8
     768:      	blr	x9
     76c:      	cbnz	w0, 0x7a4 <generic_usdt_setup_event+0x7a4>
     770:      	ldr	x8, [sp, #0x18]
     774:      	ldr	x9, [x23, #0x248]
     778:      	mov	w10, #0x70              // =112
     77c:      	add	x11, sp, #0x18
     780:      	add	x0, sp, #0x18
     784:      	mov	w1, #0x8                // =8
     788:      	add	x8, x8, x9
     78c:      	mov	w9, #0x8                // =8
     790:      	ldr	x8, [sp, #0x18]
     794:      	ldr	x9, [x23, #0x248]
     798:      	add	x2, x8, x9
     79c:      	blr	x10
     7a0:      	cbz	w0, 0x6d0 <generic_usdt_setup_event+0x6d0>
     7a4:      	sxtw	x8, w0
     7a8:      	str	x8, [x22, #0x5e68]
     7ac:      	mov	x9, xzr
     7b0:      	ldrb	w8, [x23, #0x271]
     7b4:      	cmp	w8, #0x2
     7b8:      	b.le	0x708 <generic_usdt_setup_event+0x708>
     7bc:      	cmp	w8, #0x3
     7c0:      	b.eq	0x89c <generic_usdt_setup_event+0x89c>
     7c4:      	cmp	w8, #0x4
     7c8:      	b.ne	0x8fc <generic_usdt_setup_event+0x8fc>
     7cc:      	ldr	w8, [x23, #0x268]
     7d0:      	mov	w9, #0x71               // =113
     7d4:      	add	x10, sp, #0x18
     7d8:      	add	x0, sp, #0x18
     7dc:      	mov	w1, #0x8                // =8
     7e0:      	and	x8, x8, #0xfff
     7e4:      	add	x2, x19, x8
     7e8:      	mov	w8, #0x8                // =8
     7ec:      	blr	x9
     7f0:      	cbnz	w0, 0x8f8 <generic_usdt_setup_event+0x8f8>
     7f4:      	ldr	w8, [x23, #0x26c]
     7f8:      	mov	w9, #0x71               // =113
     7fc:      	add	x10, sp, #0x10
     800:      	add	x0, sp, #0x10
     804:      	mov	w1, #0x8                // =8
     808:      	and	x8, x8, #0xfff
     80c:      	add	x2, x19, x8
     810:      	mov	w8, #0x8                // =8
     814:      	blr	x9
     818:      	cbnz	w0, 0x8f8 <generic_usdt_setup_event+0x8f8>
     81c:      	ldp	x9, x8, [sp, #0x10]
     820:      	add	x11, sp, #0x18
     824:      	add	x0, sp, #0x18
     828:      	mov	w1, #0x8                // =8
     82c:      	ldrb	w10, [x23, #0x273]
     830:      	lsl	x9, x9, x10
     834:      	ldr	x10, [x23, #0x260]
     838:      	add	x8, x10, x8
     83c:      	mov	w10, #0x70              // =112
     840:      	add	x8, x8, x9
     844:      	mov	w9, #0x8                // =8
     848:      	ldp	x9, x8, [sp, #0x10]
     84c:      	ldrb	w11, [x23, #0x273]
     850:      	lsl	x9, x9, x11
     854:      	ldr	x11, [x23, #0x260]
     858:      	add	x8, x11, x8
     85c:      	add	x2, x8, x9
     860:      	blr	x10
     864:      	cbnz	w0, 0x8f8 <generic_usdt_setup_event+0x8f8>
     868:      	b	0x874 <generic_usdt_setup_event+0x874>
     86c:      	ldr	x8, [x23, #0x260]
     870:      	str	x8, [sp, #0x18]
     874:      	ldrb	w8, [x23, #0x270]
     878:      	ldr	x9, [sp, #0x18]
     87c:      	lsl	x9, x9, x8
     880:      	ldrb	w10, [x23, #0x272]
     884:      	cmp	w10, #0x0
     888:      	lsr	x11, x9, x8
     88c:      	asr	x8, x9, x8
     890:      	str	x9, [sp, #0x18]
     894:      	csel	x9, x11, x8, eq
     898:      	b	0x8fc <generic_usdt_setup_event+0x8fc>
     89c:      	ldr	w8, [x23, #0x268]
     8a0:      	mov	w9, #0x71               // =113
     8a4:      	add	x10, sp, #0x18
     8a8:      	add	x0, sp, #0x18
     8ac:      	mov	w1, #0x8                // =8
     8b0:      	and	x8, x8, #0xfff
     8b4:      	add	x2, x19, x8
     8b8:      	mov	w8, #0x8                // =8
     8bc:      	blr	x9
     8c0:      	cbnz	w0, 0x8f8 <generic_usdt_setup_event+0x8f8>
     8c4:      	ldr	x8, [sp, #0x18]
     8c8:      	ldr	x9, [x23, #0x260]
     8cc:      	mov	w10, #0x70              // =112
     8d0:      	add	x11, sp, #0x18
     8d4:      	add	x0, sp, #0x18
     8d8:      	mov	w1, #0x8                // =8
     8dc:      	add	x8, x8, x9
     8e0:      	mov	w9, #0x8                // =8
     8e4:      	ldr	x8, [sp, #0x18]
     8e8:      	ldr	x9, [x23, #0x260]
     8ec:      	add	x2, x8, x9
     8f0:      	blr	x10
     8f4:      	cbz	w0, 0x874 <generic_usdt_setup_event+0x874>
     8f8:      	sxtw	x9, w0
     8fc:      	str	x9, [x22, #0x5e70]
     900:      	str	wzr, [sp, #0x18]
     904:      	mov	w8, #0x1                // =1
     908:      	add	x9, sp, #0x18
     90c:      	add	x1, sp, #0x18
     910:      	mov	x0, x20
     914:      	blr	x8
     918:      	adrp	x20, 0x0 <generic_usdt_setup_event>
     91c:      	ldr	x20, [x20]
     920:      	cbz	x0, 0x948 <generic_usdt_setup_event+0x948>
     924:      	mov	w8, #0x5ef8             // =24312
     928:      	add	x1, x0, x8
     92c:      	mov	w8, #0x1                // =1
     930:      	mov	x0, x21
     934:      	blr	x8
     938:      	cbz	x0, 0x948 <generic_usdt_setup_event+0x948>
     93c:      	ldr	w8, [x0, #0x40]
     940:      	cmn	w8, #0x1
     944:      	b.ne	0x960 <generic_usdt_setup_event+0x960>
     948:      	mov	w8, #0x3                // =3
     94c:      	mov	w9, #0xc                // =12
     950:      	mov	x0, x19
     954:      	mov	x1, x20
     958:      	mov	w2, #0x3                // =3
     95c:      	blr	x9
     960:      	mov	w8, #0x1                // =1
     964:      	mov	w9, #0xc                // =12
     968:      	mov	x0, x19
     96c:      	mov	x1, x20
     970:      	mov	w2, #0x1                // =1
     974:      	blr	x9
     978:      	ldp	x20, x19, [sp, #0x40]
     97c:      	mov	w0, wzr
     980:      	ldp	x22, x21, [sp, #0x30]
     984:      	ldp	x30, x23, [sp, #0x20]
     988:      	add	sp, sp, #0x50
     98c:      	ret

0000000000000990 <generic_usdt_process_event>:
     990:      	sub	sp, sp, #0x150
     994:      	str	x29, [sp, #0x100]
     998:      	stp	x30, x25, [sp, #0x110]
     99c:      	stp	x24, x23, [sp, #0x120]
     9a0:      	stp	x22, x21, [sp, #0x130]
     9a4:      	stp	x20, x19, [sp, #0x140]
     9a8:      	str	wzr, [sp, #0x4c]
     9ac:      	adrp	x21, 0x0 <generic_usdt_setup_event>
     9b0:      	mov	w8, #0x1                // =1
     9b4:      	add	x9, sp, #0x4c
     9b8:      	ldr	x21, [x21]
     9bc:      	mov	x19, x0
     9c0:      	add	x1, sp, #0x4c
     9c4:      	mov	x0, x21
     9c8:      	blr	x8
     9cc:      	cbz	x0, 0xec0 <generic_usdt_process_event+0x530>
     9d0:      	ldr	w24, [x0, #0x4]
     9d4:      	mov	w25, #0x5efc            // =24316
     9d8:      	mov	x20, x0
     9dc:      	ldr	w23, [x0, x25]
     9e0:      	lsr	w8, w24, #3
     9e4:      	cmp	w8, #0x464
     9e8:      	b.hi	0xe24 <generic_usdt_process_event+0x494>
     9ec:      	str	wzr, [sp, #0x58]
     9f0:      	mov	w8, #0x1                // =1
     9f4:      	add	x9, sp, #0x58
     9f8:      	add	x1, sp, #0x58
     9fc:      	mov	x0, x21
     a00:      	blr	x8
     a04:      	cbz	x0, 0xe24 <generic_usdt_process_event+0x494>
     a08:      	mov	w8, #0x5ef8             // =24312
     a0c:      	mov	x22, x0
     a10:      	add	x1, x0, x8
     a14:      	adrp	x0, 0x0 <generic_usdt_setup_event>
     a18:      	mov	w8, #0x1                // =1
     a1c:      	ldr	x0, [x0]
     a20:      	blr	x8
     a24:      	cmp	w23, #0x4
     a28:      	ccmp	x0, #0x0, #0x4, le
     a2c:      	b.eq	0xe24 <generic_usdt_process_event+0x494>
     a30:      	and	x29, x23, #0x7
     a34:      	str	x24, [sp, #0x108]
     a38:      	mov	w9, #0x5ea0             // =24224
     a3c:      	str	x23, [sp, #0x40]
     a40:      	add	x21, sp, #0xd0
     a44:      	add	x8, x0, x29, lsl #2
     a48:      	ldr	w24, [x8, #0x4]
     a4c:      	ldrsw	x10, [x8, #0x18]
     a50:      	add	x8, x22, x29, lsl #2
     a54:      	add	x23, x8, x9
     a58:      	add	x8, x22, x29, lsl #3
     a5c:      	ldr	x22, [x8, #0x5e50]
     a60:      	str	wzr, [x23]
     a64:      	str	x10, [sp, #0x38]
     a68:      	str	x22, [sp, #0x50]
     a6c:      	tbnz	w10, #0x8, 0xa84 <generic_usdt_process_event+0xf4>
     a70:      	cmp	w29, #0x4
     a74:      	b.ls	0xaf8 <generic_usdt_process_event+0x168>
     a78:      	adrp	x21, 0x0 <generic_usdt_setup_event>
     a7c:      	ldr	x21, [x21]
     a80:      	b	0xbf0 <generic_usdt_process_event+0x260>
     a84:      	str	xzr, [sp, #0x88]
     a88:      	mov	w8, #0xe                // =14
     a8c:      	blr	x8
     a90:      	str	x0, [x21, #0x10]
     a94:      	adrp	x0, 0x0 <generic_usdt_setup_event>
     a98:      	mov	w8, #0x1                // =1
     a9c:      	add	x9, sp, #0xe0
     aa0:      	ldr	x0, [x0]
     aa4:      	add	x1, sp, #0xe0
     aa8:      	blr	x8
     aac:      	cbz	x0, 0xae4 <generic_usdt_process_event+0x154>
     ab0:      	ldr	w8, [x0]
     ab4:      	cmp	w24, #0x6
     ab8:      	str	w8, [x23]
     abc:      	b.ne	0xae4 <generic_usdt_process_event+0x154>
     ac0:      	add	x8, x0, #0x4
     ac4:      	mov	w9, #0x4                // =4
     ac8:      	add	x10, sp, #0x88
     acc:      	str	x8, [sp, #0x88]
     ad0:      	mov	w8, #0x8                // =8
     ad4:      	add	x0, sp, #0x88
     ad8:      	add	x2, sp, #0x88
     adc:      	mov	w1, #0x8                // =8
     ae0:      	blr	x9
     ae4:      	ldr	x22, [sp, #0x88]
     ae8:      	adrp	x21, 0x0 <generic_usdt_setup_event>
     aec:      	str	x22, [sp, #0x50]
     af0:      	ldr	x21, [x21]
     af4:      	b	0xbf0 <generic_usdt_process_event+0x260>
     af8:      	mov	w8, #0x50               // =80
     afc:      	adrp	x21, 0x0 <generic_usdt_setup_event>
     b00:      	umaddl	x8, w29, w8, x0
     b04:      	ldrh	w9, [x8, #0x76]
     b08:      	ldr	x21, [x21]
     b0c:      	cbz	w9, 0xbf0 <generic_usdt_process_event+0x260>
     b10:      	add	x8, x8, #0x70
     b14:      	add	x9, sp, #0x50
     b18:      	strb	wzr, [sp, #0x98]
     b1c:      	str	x23, [sp, #0xa0]
     b20:      	stp	x8, x9, [sp, #0x88]
     b24:      	adrp	x8, 0x0 <generic_usdt_setup_event>
     b28:      	ldr	x8, [x8]
     b2c:      	ldrb	w8, [x8]
     b30:      	cbz	w8, 0xbc4 <generic_usdt_process_event+0x234>
     b34:      	mov	x23, xzr
     b38:      	mov	w22, #0x1               // =1
     b3c:      	mov	w25, #0x8               // =8
     b40:      	b	0xb6c <generic_usdt_process_event+0x1dc>
     b44:      	mov	w10, #0x4               // =4
     b48:      	ldr	x0, [sp, #0x90]
     b4c:      	mov	w1, #0x8                // =8
     b50:      	ldr	x2, [x0]
     b54:      	blr	x10
     b58:      	tbnz	w0, #0x1f, 0xbb8 <generic_usdt_process_event+0x228>
     b5c:      	add	x23, x23, #0x8
     b60:      	add	w22, w22, #0x1
     b64:      	cmp	x23, #0x50
     b68:      	b.eq	0xbe8 <generic_usdt_process_event+0x258>
     b6c:      	ldr	x8, [sp, #0x88]
     b70:      	add	x10, x8, x23
     b74:      	ldrh	w8, [x10, #0x6]
     b78:      	cbz	w8, 0xbe8 <generic_usdt_process_event+0x258>
     b7c:      	ldr	x8, [sp, #0x90]
     b80:      	ldr	w11, [x10]
     b84:      	ldr	x9, [x8]
     b88:      	add	x9, x9, x11
     b8c:      	str	x9, [x8]
     b90:      	ldrh	w10, [x10, #0x4]
     b94:      	cbz	w10, 0xb5c <generic_usdt_process_event+0x1cc>
     b98:      	ldrb	w10, [sp, #0x98]
     b9c:      	cbz	w10, 0xb44 <generic_usdt_process_event+0x1b4>
     ba0:      	mov	w10, #0x94              // =148
     ba4:      	ldr	x0, [sp, #0x90]
     ba8:      	mov	w1, #0x8                // =8
     bac:      	ldr	x2, [x0]
     bb0:      	blr	x10
     bb4:      	tbz	w0, #0x1f, 0xb5c <generic_usdt_process_event+0x1cc>
     bb8:      	ldr	x8, [sp, #0xa0]
     bbc:      	str	w22, [x8]
     bc0:      	b	0xbe8 <generic_usdt_process_event+0x258>
     bc4:      	mov	x3, xzr
     bc8:      	adrp	x1, 0x0 <generic_usdt_setup_event>
     bcc:      	add	x1, x1, #0x0
     bd0:      	mov	w8, #0xa                // =10
     bd4:      	mov	w9, #0xb5               // =181
     bd8:      	add	x10, sp, #0x88
     bdc:      	add	x2, sp, #0x88
     be0:      	mov	w0, #0xa                // =10
     be4:      	blr	x9
     be8:      	ldr	x22, [sp, #0x50]
     bec:      	mov	w25, #0x5efc            // =24316
     bf0:      	mov	w23, #0x1000            // =4096
     bf4:      	cmp	w24, #0x15
     bf8:      	b.gt	0xc2c <generic_usdt_process_event+0x29c>
     bfc:      	cmp	w24, #0xb
     c00:      	b.gt	0xc5c <generic_usdt_process_event+0x2cc>
     c04:      	cmp	w24, #0x5
     c08:      	b.gt	0xccc <generic_usdt_process_event+0x33c>
     c0c:      	cmp	w24, #0x3
     c10:      	b.gt	0xd60 <generic_usdt_process_event+0x3d0>
     c14:      	sub	w8, w24, #0x2
     c18:      	cmp	w8, #0x2
     c1c:      	b.lo	0xd1c <generic_usdt_process_event+0x38c>
     c20:      	cmp	w24, #0x1
     c24:      	b.eq	0xd1c <generic_usdt_process_event+0x38c>
     c28:      	b	0xd98 <generic_usdt_process_event+0x408>
     c2c:      	cmp	w24, #0x20
     c30:      	b.le	0xc80 <generic_usdt_process_event+0x2f0>
     c34:      	cmp	w24, #0x27
     c38:      	b.gt	0xca4 <generic_usdt_process_event+0x314>
     c3c:      	sub	w8, w24, #0x21
     c40:      	cmp	w8, #0x4
     c44:      	b.lo	0xd78 <generic_usdt_process_event+0x3e8>
     c48:      	cmp	w24, #0x25
     c4c:      	b.eq	0xd9c <generic_usdt_process_event+0x40c>
     c50:      	cmp	w24, #0x27
     c54:      	b.eq	0xd24 <generic_usdt_process_event+0x394>
     c58:      	b	0xd98 <generic_usdt_process_event+0x408>
     c5c:      	cmp	w24, #0x11
     c60:      	b.gt	0xcf0 <generic_usdt_process_event+0x360>
     c64:      	sub	w8, w24, #0xf
     c68:      	cmp	w8, #0x3
     c6c:      	b.lo	0xd9c <generic_usdt_process_event+0x40c>
     c70:      	sub	w8, w24, #0xc
     c74:      	cmp	w8, #0x2
     c78:      	b.lo	0xd1c <generic_usdt_process_event+0x38c>
     c7c:      	b	0xd98 <generic_usdt_process_event+0x408>
     c80:      	cmp	w24, #0x1a
     c84:      	b.gt	0xd10 <generic_usdt_process_event+0x380>
     c88:      	cmp	w24, #0x16
     c8c:      	b.eq	0xd24 <generic_usdt_process_event+0x394>
     c90:      	cmp	w24, #0x17
     c94:      	b.eq	0xd78 <generic_usdt_process_event+0x3e8>
     c98:      	cmp	w24, #0x1a
     c9c:      	b.eq	0xd90 <generic_usdt_process_event+0x400>
     ca0:      	b	0xd98 <generic_usdt_process_event+0x408>
     ca4:      	cmp	w24, #0x29
     ca8:      	b.le	0xd44 <generic_usdt_process_event+0x3b4>
     cac:      	cmp	w24, #0x2a
     cb0:      	b.eq	0xd9c <generic_usdt_process_event+0x40c>
     cb4:      	cmp	w24, #0x2b
     cb8:      	b.eq	0xd58 <generic_usdt_process_event+0x3c8>
     cbc:      	cmp	w24, #0x2c
     cc0:      	b.ne	0xd98 <generic_usdt_process_event+0x408>
     cc4:      	mov	w23, #0x70              // =112
     cc8:      	b	0xd9c <generic_usdt_process_event+0x40c>
     ccc:      	cmp	w24, #0x9
     cd0:      	b.gt	0xd78 <generic_usdt_process_event+0x3e8>
     cd4:      	cmp	w24, #0x6
     cd8:      	b.eq	0xd9c <generic_usdt_process_event+0x40c>
     cdc:      	cmp	w24, #0x7
     ce0:      	b.eq	0xd70 <generic_usdt_process_event+0x3e0>
     ce4:      	cmp	w24, #0x8
     ce8:      	b.eq	0xd90 <generic_usdt_process_event+0x400>
     cec:      	b	0xd98 <generic_usdt_process_event+0x408>
     cf0:      	cmp	w24, #0x13
     cf4:      	b.gt	0xd2c <generic_usdt_process_event+0x39c>
     cf8:      	ldr	x23, [sp, #0x38]
     cfc:      	cmp	w24, #0x12
     d00:      	b.eq	0xd9c <generic_usdt_process_event+0x40c>
     d04:      	cmp	w24, #0x13
     d08:      	b.eq	0xd58 <generic_usdt_process_event+0x3c8>
     d0c:      	b	0xd98 <generic_usdt_process_event+0x408>
     d10:      	sub	w8, w24, #0x1d
     d14:      	cmp	w8, #0x4
     d18:      	b.hs	0xd88 <generic_usdt_process_event+0x3f8>
     d1c:      	mov	w23, #0x4               // =4
     d20:      	b	0xd9c <generic_usdt_process_event+0x40c>
     d24:      	mov	w23, #0x10              // =16
     d28:      	b	0xd9c <generic_usdt_process_event+0x40c>
     d2c:      	cmp	w24, #0x14
     d30:      	b.eq	0xd80 <generic_usdt_process_event+0x3f0>
     d34:      	cmp	w24, #0x15
     d38:      	b.ne	0xd98 <generic_usdt_process_event+0x408>
     d3c:      	mov	w23, #0x20              // =32
     d40:      	b	0xd9c <generic_usdt_process_event+0x40c>
     d44:      	cmp	w24, #0x28
     d48:      	b.eq	0xd58 <generic_usdt_process_event+0x3c8>
     d4c:      	cmp	w24, #0x29
     d50:      	b.eq	0xd70 <generic_usdt_process_event+0x3e0>
     d54:      	b	0xd98 <generic_usdt_process_event+0x408>
     d58:      	mov	w23, #0x18              // =24
     d5c:      	b	0xd9c <generic_usdt_process_event+0x40c>
     d60:      	cmp	w24, #0x4
     d64:      	b.eq	0xd78 <generic_usdt_process_event+0x3e8>
     d68:      	cmp	w24, #0x5
     d6c:      	b.ne	0xd98 <generic_usdt_process_event+0x408>
     d70:      	mov	w23, #0x40              // =64
     d74:      	b	0xd9c <generic_usdt_process_event+0x40c>
     d78:      	mov	w23, #0x8               // =8
     d7c:      	b	0xd9c <generic_usdt_process_event+0x40c>
     d80:      	mov	w23, #0x98              // =152
     d84:      	b	0xd9c <generic_usdt_process_event+0x40c>
     d88:      	cmp	w24, #0x1b
     d8c:      	b.ne	0xd98 <generic_usdt_process_event+0x408>
     d90:      	mov	w23, #0x50              // =80
     d94:      	b	0xd9c <generic_usdt_process_event+0x40c>
     d98:      	mov	x23, xzr
     d9c:      	str	wzr, [sp, #0x5c]
     da0:      	mov	w8, #0x1                // =1
     da4:      	add	x9, sp, #0x5c
     da8:      	add	x1, sp, #0x5c
     dac:      	mov	x0, x21
     db0:      	blr	x8
     db4:      	cbz	x0, 0xe1c <generic_usdt_process_event+0x48c>
     db8:      	ldr	x9, [sp, #0x108]
     dbc:      	mov	w8, #0x3ffb             // =16379
     dc0:      	sub	x8, x8, x23
     dc4:      	cmp	x8, x9
     dc8:      	b.ls	0xe1c <generic_usdt_process_event+0x48c>
     dcc:      	add	x23, x0, x29, lsl #2
     dd0:      	mov	w8, #0x5ea0             // =24224
     dd4:      	add	x11, x0, #0x90
     dd8:      	ldr	w9, [x23, x8]
     ddc:      	ldr	x8, [sp, #0x108]
     de0:      	add	x10, x0, x29, lsl #3
     de4:      	str	w9, [x11, x8]
     de8:      	add	x8, x8, #0x4
     dec:      	str	x8, [x10, #0x5e78]
     df0:      	cbz	w9, 0xee0 <generic_usdt_process_event+0x550>
     df4:      	ldr	x23, [sp, #0x40]
     df8:      	ldr	x24, [sp, #0x108]
     dfc:      	mov	w8, #0x4                // =4
     e00:      	add	w24, w8, w24
     e04:      	str	w24, [x20, #0x4]
     e08:      	adrp	x22, 0x0 <generic_usdt_setup_event>
     e0c:      	cmp	w23, #0x3
     e10:      	ldr	x22, [x22]
     e14:      	b.le	0xe38 <generic_usdt_process_event+0x4a8>
     e18:      	b	0xea4 <generic_usdt_process_event+0x514>
     e1c:      	ldr	x23, [sp, #0x40]
     e20:      	ldr	x24, [sp, #0x108]
     e24:      	str	w24, [x20, #0x4]
     e28:      	adrp	x22, 0x0 <generic_usdt_setup_event>
     e2c:      	cmp	w23, #0x3
     e30:      	ldr	x22, [x22]
     e34:      	b.gt	0xea4 <generic_usdt_process_event+0x514>
     e38:      	str	wzr, [sp, #0x88]
     e3c:      	mov	w8, #0x1                // =1
     e40:      	add	x9, sp, #0x88
     e44:      	add	x1, sp, #0x88
     e48:      	mov	x0, x21
     e4c:      	blr	x8
     e50:      	cbz	x0, 0xea4 <generic_usdt_process_event+0x514>
     e54:      	mov	w8, #0x5ef8             // =24312
     e58:      	add	x1, x0, x8
     e5c:      	adrp	x0, 0x0 <generic_usdt_setup_event>
     e60:      	mov	w8, #0x1                // =1
     e64:      	ldr	x0, [x0]
     e68:      	blr	x8
     e6c:      	cbz	x0, 0xea4 <generic_usdt_process_event+0x514>
     e70:      	add	w8, w23, #0x1
     e74:      	and	w9, w8, #0x7
     e78:      	add	x9, x0, w9, uxtw #2
     e7c:      	ldr	w9, [x9, #0x40]
     e80:      	cmn	w9, #0x1
     e84:      	b.eq	0xea4 <generic_usdt_process_event+0x514>
     e88:      	str	w8, [x20, x25]
     e8c:      	mov	w8, #0x1                // =1
     e90:      	mov	w9, #0xc                // =12
     e94:      	mov	x0, x19
     e98:      	mov	x1, x22
     e9c:      	mov	w2, #0x1                // =1
     ea0:      	blr	x9
     ea4:      	str	wzr, [x20, x25]
     ea8:      	mov	w8, #0x3                // =3
     eac:      	mov	w9, #0xc                // =12
     eb0:      	mov	x0, x19
     eb4:      	mov	x1, x22
     eb8:      	mov	w2, #0x3                // =3
     ebc:      	blr	x9
     ec0:      	ldp	x20, x19, [sp, #0x140]
     ec4:      	mov	w0, wzr
     ec8:      	ldr	x29, [sp, #0x100]
     ecc:      	ldp	x22, x21, [sp, #0x130]
     ed0:      	ldp	x24, x23, [sp, #0x120]
     ed4:      	ldp	x30, x25, [sp, #0x110]
     ed8:      	add	sp, sp, #0x150
     edc:      	ret
     ee0:      	ldr	x9, [sp, #0x38]
     ee4:      	and	x29, x8, #0x3fff
     ee8:      	cmp	w24, #0x17
     eec:      	str	x22, [sp, #0x88]
     ef0:      	add	x8, x11, x29
     ef4:      	and	x9, x9, #0xffffffff
     ef8:      	stp	x8, x11, [sp, #0x18]
     efc:      	add	x8, sp, #0xd0
     f00:      	str	xzr, [x8, #0x10]
     f04:      	b.le	0xf30 <generic_usdt_process_event+0x5a0>
     f08:      	cmp	w24, #0x18
     f0c:      	b.eq	0xf50 <generic_usdt_process_event+0x5c0>
     f10:      	cmp	w24, #0x25
     f14:      	b.eq	0xfb4 <generic_usdt_process_event+0x624>
     f18:      	cmp	w24, #0x2a
     f1c:      	b.ne	0x15f4 <generic_usdt_process_event+0xc64>
     f20:      	add	x8, sp, #0x60
     f24:      	stp	xzr, x22, [sp, #0x60]
     f28:      	str	x8, [sp, #0x28]
     f2c:      	b	0x1020 <generic_usdt_process_event+0x690>
     f30:      	cmp	w24, #0xf
     f34:      	b.eq	0xfec <generic_usdt_process_event+0x65c>
     f38:      	cmp	w24, #0x10
     f3c:      	b.ne	0x15f4 <generic_usdt_process_event+0xc64>
     f40:      	mov	x24, x23
     f44:      	add	x23, sp, #0xf0
     f48:      	add	x21, sp, #0xd0
     f4c:      	b	0xf7c <generic_usdt_process_event+0x5ec>
     f50:      	mov	x24, x23
     f54:      	add	x23, sp, #0xf0
     f58:      	mov	w8, #0x8                // =8
     f5c:      	mov	w9, #0x4                // =4
     f60:      	ldr	x2, [sp, #0x88]
     f64:      	add	x0, sp, #0xf0
     f68:      	mov	w1, #0x8                // =8
     f6c:      	blr	x9
     f70:      	add	x21, sp, #0xd0
     f74:      	ldr	x8, [x21, #0x20]
     f78:      	str	x8, [sp, #0x88]
     f7c:      	mov	w8, #0x8                // =8
     f80:      	mov	w9, #0x4                // =4
     f84:      	add	x10, sp, #0x88
     f88:      	add	x0, sp, #0xf0
     f8c:      	add	x2, sp, #0x88
     f90:      	mov	w1, #0x8                // =8
     f94:      	blr	x9
     f98:      	ldr	x8, [x21, #0x20]
     f9c:      	adrp	x21, 0x0 <generic_usdt_setup_event>
     fa0:      	mov	x23, x24
     fa4:      	add	x8, x8, #0x40
     fa8:      	str	x8, [sp, #0x28]
     fac:      	ldr	x21, [x21]
     fb0:      	b	0x1020 <generic_usdt_process_event+0x690>
     fb4:      	add	x8, x22, #0x40
     fb8:      	mov	w9, #0x8                // =8
     fbc:      	mov	w10, #0x4               // =4
     fc0:      	str	x8, [sp, #0x88]
     fc4:      	add	x11, sp, #0xf0
     fc8:      	add	x0, sp, #0xf0
     fcc:      	mov	w1, #0x8                // =8
     fd0:      	ldr	x2, [sp, #0x88]
     fd4:      	blr	x10
     fd8:      	add	x8, sp, #0xd0
     fdc:      	ldr	x8, [x8, #0x20]
     fe0:      	add	x8, x8, #0x40
     fe4:      	str	x8, [sp, #0x28]
     fe8:      	b	0x1020 <generic_usdt_process_event+0x690>
     fec:      	str	x9, [sp, #0x30]
     ff0:      	mov	w8, #0x8                // =8
     ff4:      	mov	w9, #0x4                // =4
     ff8:      	add	x10, sp, #0xe0
     ffc:      	add	x11, sp, #0x88
    1000:      	add	x0, sp, #0xe0
    1004:      	add	x2, sp, #0x88
    1008:      	mov	w1, #0x8                // =8
    100c:      	blr	x9
    1010:      	add	x8, sp, #0xd0
    1014:      	ldr	x8, [x8, #0x10]
    1018:      	str	x8, [sp, #0x28]
    101c:      	cbz	x8, 0x16a4 <generic_usdt_process_event+0xd14>
    1020:      	str	wzr, [sp, #0x74]
    1024:      	adrp	x0, 0x1000 <generic_usdt_process_event+0x670>
    1028:      	mov	w8, #0x1                // =1
    102c:      	add	x9, sp, #0x74
    1030:      	ldr	x0, [x0]
    1034:      	add	x1, sp, #0x74
    1038:      	blr	x8
    103c:      	cbz	x0, 0x10d4 <generic_usdt_process_event+0x744>
    1040:      	add	x8, x0, #0x1, lsl #12   // =0x1000
    1044:      	str	x23, [sp, #0x10]
    1048:      	mov	x24, x0
    104c:      	str	x8, [sp, #0x30]
    1050:      	mov	w8, #0x23               // =35
    1054:      	blr	x8
    1058:      	add	x2, x0, #0xb30
    105c:      	mov	w25, #0x8               // =8
    1060:      	add	x8, sp, #0x78
    1064:      	mov	w9, #0x4                // =4
    1068:      	add	x0, sp, #0x78
    106c:      	mov	w1, #0x8                // =8
    1070:      	mov	w22, #0x4               // =4
    1074:      	blr	x9
    1078:      	ldr	x8, [sp, #0x78]
    107c:      	mov	w9, #0x4                // =4
    1080:      	add	x0, sp, #0x80
    1084:      	mov	w1, #0x8                // =8
    1088:      	str	x8, [sp, #0x8]
    108c:      	add	x8, x8, #0x18
    1090:      	str	x8, [sp, #0x38]
    1094:      	ldr	x8, [sp, #0x28]
    1098:      	add	x21, x8, #0x8
    109c:      	add	x8, sp, #0x80
    10a0:      	mov	x2, x21
    10a4:      	blr	x9
    10a8:      	ldr	x23, [sp, #0x80]
    10ac:      	add	x29, sp, #0x88
    10b0:      	add	x0, sp, #0x88
    10b4:      	mov	w1, #0x8                // =8
    10b8:      	add	x2, x23, #0x10
    10bc:      	blr	x22
    10c0:      	ldr	x8, [sp, #0x88]
    10c4:      	cbz	x8, 0x10dc <generic_usdt_process_event+0x74c>
    10c8:      	ldr	x9, [sp, #0x30]
    10cc:      	mov	w8, #0x1000             // =4096
    10d0:      	b	0x1124 <generic_usdt_process_event+0x794>
    10d4:      	mov	x9, xzr
    10d8:      	b	0x1698 <generic_usdt_process_event+0xd08>
    10dc:      	add	x2, x23, #0x18
    10e0:      	mov	w8, #0x8                // =8
    10e4:      	mov	w9, #0x4                // =4
    10e8:      	add	x10, sp, #0x88
    10ec:      	add	x0, sp, #0x88
    10f0:      	mov	w1, #0x8                // =8
    10f4:      	blr	x9
    10f8:      	ldr	x8, [sp, #0x88]
    10fc:      	cmp	x8, x23
    1100:      	b.eq	0x10c8 <generic_usdt_process_event+0x738>
    1104:      	mov	w8, #0x2964             // =10596
    1108:      	add	x9, x24, #0xff6
    110c:      	strh	w8, [x24, #0xffe]
    1110:      	adrp	x8, 0x1000 <generic_usdt_process_event+0x670>
    1114:      	add	x8, x8, #0x0
    1118:      	ldr	x8, [x8]
    111c:      	str	x8, [x9]
    1120:      	mov	w8, #0xff6              // =4086
    1124:      	str	x9, [sp, #0x30]
    1128:      	str	x9, [sp, #0xb8]
    112c:      	ldr	x9, [sp, #0x8]
    1130:      	add	x10, sp, #0x88
    1134:      	mov	w22, #0x8               // =8
    1138:      	add	x0, sp, #0x88
    113c:      	stp	xzr, xzr, [sp, #0x88]
    1140:      	mov	w1, #0x8                // =8
    1144:      	add	x23, x29, #0x8
    1148:      	add	x29, x10, #0x18
    114c:      	mov	w25, #0x4               // =4
    1150:      	add	x2, x9, #0x20
    1154:      	stp	x24, xzr, [sp, #0x98]
    1158:      	stp	xzr, xzr, [sp, #0xa8]
    115c:      	str	w8, [sp, #0xc0]
    1160:      	mov	w8, #0x4                // =4
    1164:      	add	x24, x10, #0x20
    1168:      	strb	wzr, [sp, #0xc4]
    116c:      	blr	x8
    1170:      	ldr	x2, [sp, #0x38]
    1174:      	mov	w8, #0x4                // =4
    1178:      	mov	x0, x23
    117c:      	mov	w1, #0x8                // =8
    1180:      	blr	x8
    1184:      	mov	w8, #0x4                // =4
    1188:      	mov	x0, x29
    118c:      	mov	w1, #0x8                // =8
    1190:      	str	x29, [sp, #0x38]
    1194:      	str	x21, [sp, #0x8]
    1198:      	mov	x2, x21
    119c:      	blr	x8
    11a0:      	ldr	x2, [sp, #0x28]
    11a4:      	mov	x0, x24
    11a8:      	mov	w1, #0x8                // =8
    11ac:      	blr	x25
    11b0:      	ldr	x8, [sp, #0xa8]
    11b4:      	sub	x8, x8, #0x20
    11b8:      	str	x8, [sp, #0xb0]
    11bc:      	adrp	x8, 0x1000 <generic_usdt_process_event+0x670>
    11c0:      	ldr	x8, [x8]
    11c4:      	ldrb	w8, [x8]
    11c8:      	cbz	w8, 0x135c <generic_usdt_process_event+0x9cc>
    11cc:      	mov	w23, #0x800             // =2048
    11d0:      	mov	w24, #0x8               // =8
    11d4:      	add	x21, sp, #0xd0
    11d8:      	ldp	x25, x2, [sp, #0xa0]
    11dc:      	ldp	x8, x9, [sp, #0x88]
    11e0:      	cmp	x25, x8
    11e4:      	ccmp	x2, x9, #0x0, eq
    11e8:      	b.eq	0x14e8 <generic_usdt_process_event+0xb58>
    11ec:      	ldr	x29, [sp, #0xb0]
    11f0:      	mov	w8, #0x4                // =4
    11f4:      	add	x9, sp, #0xd0
    11f8:      	add	x0, sp, #0xd0
    11fc:      	mov	w1, #0x8                // =8
    1200:      	blr	x8
    1204:      	ldr	x8, [x21]
    1208:      	add	x21, sp, #0xd0
    120c:      	cmp	x25, x8
    1210:      	b.eq	0x1304 <generic_usdt_process_event+0x974>
    1214:      	add	x22, x25, #0x18
    1218:      	mov	w8, #0x4                // =4
    121c:      	add	x9, sp, #0xf0
    1220:      	add	x0, sp, #0xf0
    1224:      	mov	w1, #0x8                // =8
    1228:      	mov	x2, x22
    122c:      	blr	x8
    1230:      	ldr	x8, [x21, #0x20]
    1234:      	cmp	x8, x25
    1238:      	b.eq	0x1304 <generic_usdt_process_event+0x974>
    123c:      	mov	w8, #0x4                // =4
    1240:      	add	x9, sp, #0xd8
    1244:      	add	x0, sp, #0xd8
    1248:      	mov	w1, #0x8                // =8
    124c:      	mov	x2, x22
    1250:      	blr	x8
    1254:      	add	x2, x25, #0x20
    1258:      	mov	w8, #0x4                // =4
    125c:      	mov	w9, #0x10               // =16
    1260:      	add	x10, sp, #0xe0
    1264:      	add	x0, sp, #0xe0
    1268:      	mov	w1, #0x10               // =16
    126c:      	blr	x8
    1270:      	ldr	w22, [sp, #0xe4]
    1274:      	ldr	x8, [sp, #0x98]
    1278:      	ldr	x10, [sp, #0xb8]
    127c:      	sub	x12, x10, x8
    1280:      	ldr	w25, [sp, #0xc0]
    1284:      	subs	w10, w22, w25
    1288:      	ldr	x9, [x21, #0x18]
    128c:      	csel	w10, wzr, w10, lo
    1290:      	cmp	w25, w22
    1294:      	csel	w11, w25, w22, lo
    1298:      	cinc	w13, w11, hi
    129c:      	sub	w14, w25, w13
    12a0:      	subs	x12, x12, x13
    12a4:      	str	w14, [sp, #0xc0]
    12a8:      	b.lo	0x14f0 <generic_usdt_process_event+0xb60>
    12ac:      	cmp	x12, #0xfff
    12b0:      	b.hi	0x14f0 <generic_usdt_process_event+0xb60>
    12b4:      	cmp	w25, w22
    12b8:      	b.ls	0x12c4 <generic_usdt_process_event+0x934>
    12bc:      	mov	w13, #0x2f              // =47
    12c0:      	strb	w13, [x8, x12]
    12c4:      	add	x29, x8, x12
    12c8:      	cmp	w25, w22
    12cc:      	add	x2, x9, x10
    12d0:      	and	w1, w11, #0xff
    12d4:      	mov	w8, #0x4                // =4
    12d8:      	cinc	x0, x29, hi
    12dc:      	blr	x8
    12e0:      	cmp	w25, w22
    12e4:      	str	x29, [sp, #0xb8]
    12e8:      	b.ls	0x14f0 <generic_usdt_process_event+0xb60>
    12ec:      	add	x21, sp, #0xd0
    12f0:      	ldr	x8, [x21, #0x8]
    12f4:      	str	x8, [sp, #0xa0]
    12f8:      	subs	w23, w23, #0x1
    12fc:      	b.ne	0x11d8 <generic_usdt_process_event+0x848>
    1300:      	b	0x14f0 <generic_usdt_process_event+0xb60>
    1304:      	add	x2, x29, #0x10
    1308:      	mov	w8, #0x4                // =4
    130c:      	add	x9, sp, #0xf0
    1310:      	add	x0, sp, #0xf0
    1314:      	mov	w1, #0x8                // =8
    1318:      	blr	x8
    131c:      	ldr	x8, [sp, #0xb0]
    1320:      	ldr	x9, [x21, #0x20]
    1324:      	add	x21, sp, #0xd0
    1328:      	cmp	x8, x9
    132c:      	b.eq	0x14e8 <generic_usdt_process_event+0xb58>
    1330:      	ldr	x0, [sp, #0x38]
    1334:      	add	x2, x29, #0x18
    1338:      	mov	w8, #0x4                // =4
    133c:      	mov	w1, #0x8                // =8
    1340:      	blr	x8
    1344:      	ldr	x8, [x21, #0x20]
    1348:      	add	x9, x8, #0x20
    134c:      	stp	x9, x8, [sp, #0xa8]
    1350:      	subs	w23, w23, #0x1
    1354:      	b.ne	0x11d8 <generic_usdt_process_event+0x848>
    1358:      	b	0x14f0 <generic_usdt_process_event+0xb60>
    135c:      	mov	w23, #0x800             // =2048
    1360:      	mov	w24, #0x8               // =8
    1364:      	add	x21, sp, #0xd0
    1368:      	b	0x1374 <generic_usdt_process_event+0x9e4>
    136c:      	subs	w23, w23, #0x1
    1370:      	b.eq	0x14f0 <generic_usdt_process_event+0xb60>
    1374:      	ldp	x25, x2, [sp, #0xa0]
    1378:      	ldp	x8, x9, [sp, #0x88]
    137c:      	cmp	x25, x8
    1380:      	ccmp	x2, x9, #0x0, eq
    1384:      	b.eq	0x14e8 <generic_usdt_process_event+0xb58>
    1388:      	ldr	x29, [sp, #0xb0]
    138c:      	mov	w8, #0x4                // =4
    1390:      	add	x9, sp, #0xd0
    1394:      	add	x0, sp, #0xd0
    1398:      	mov	w1, #0x8                // =8
    139c:      	blr	x8
    13a0:      	ldr	x8, [x21]
    13a4:      	add	x21, sp, #0xd0
    13a8:      	cmp	x25, x8
    13ac:      	b.eq	0x1498 <generic_usdt_process_event+0xb08>
    13b0:      	add	x22, x25, #0x18
    13b4:      	mov	w8, #0x4                // =4
    13b8:      	add	x9, sp, #0xf0
    13bc:      	add	x0, sp, #0xf0
    13c0:      	mov	w1, #0x8                // =8
    13c4:      	mov	x2, x22
    13c8:      	blr	x8
    13cc:      	ldr	x8, [x21, #0x20]
    13d0:      	cmp	x8, x25
    13d4:      	b.eq	0x1498 <generic_usdt_process_event+0xb08>
    13d8:      	mov	w8, #0x4                // =4
    13dc:      	add	x9, sp, #0xd8
    13e0:      	add	x0, sp, #0xd8
    13e4:      	mov	w1, #0x8                // =8
    13e8:      	mov	x2, x22
    13ec:      	blr	x8
    13f0:      	add	x2, x25, #0x20
    13f4:      	mov	w8, #0x4                // =4
    13f8:      	mov	w9, #0x10               // =16
    13fc:      	add	x10, sp, #0xe0
    1400:      	add	x0, sp, #0xe0
    1404:      	mov	w1, #0x10               // =16
    1408:      	blr	x8
    140c:      	ldr	w22, [sp, #0xe4]
    1410:      	ldr	x8, [sp, #0x98]
    1414:      	ldr	x10, [sp, #0xb8]
    1418:      	sub	x12, x10, x8
    141c:      	ldr	w25, [sp, #0xc0]
    1420:      	subs	w10, w22, w25
    1424:      	ldr	x9, [x21, #0x18]
    1428:      	csel	w10, wzr, w10, lo
    142c:      	cmp	w25, w22
    1430:      	csel	w11, w25, w22, lo
    1434:      	cinc	w13, w11, hi
    1438:      	sub	w14, w25, w13
    143c:      	subs	x12, x12, x13
    1440:      	str	w14, [sp, #0xc0]
    1444:      	b.lo	0x14f0 <generic_usdt_process_event+0xb60>
    1448:      	cmp	x12, #0xfff
    144c:      	b.hi	0x14f0 <generic_usdt_process_event+0xb60>
    1450:      	cmp	w25, w22
    1454:      	b.ls	0x1460 <generic_usdt_process_event+0xad0>
    1458:      	mov	w13, #0x2f              // =47
    145c:      	strb	w13, [x8, x12]
    1460:      	add	x29, x8, x12
    1464:      	cmp	w25, w22
    1468:      	add	x2, x9, x10
    146c:      	and	w1, w11, #0xff
    1470:      	mov	w8, #0x4                // =4
    1474:      	cinc	x0, x29, hi
    1478:      	blr	x8
    147c:      	cmp	w25, w22
    1480:      	str	x29, [sp, #0xb8]
    1484:      	b.ls	0x14f0 <generic_usdt_process_event+0xb60>
    1488:      	add	x21, sp, #0xd0
    148c:      	ldr	x8, [x21, #0x8]
    1490:      	str	x8, [sp, #0xa0]
    1494:      	b	0x136c <generic_usdt_process_event+0x9dc>
    1498:      	add	x2, x29, #0x10
    149c:      	mov	w8, #0x4                // =4
    14a0:      	add	x9, sp, #0xf0
    14a4:      	add	x0, sp, #0xf0
    14a8:      	mov	w1, #0x8                // =8
    14ac:      	blr	x8
    14b0:      	ldr	x8, [sp, #0xb0]
    14b4:      	ldr	x9, [x21, #0x20]
    14b8:      	add	x21, sp, #0xd0
    14bc:      	cmp	x8, x9
    14c0:      	b.eq	0x14e8 <generic_usdt_process_event+0xb58>
    14c4:      	ldr	x0, [sp, #0x38]
    14c8:      	add	x2, x29, #0x18
    14cc:      	mov	w8, #0x4                // =4
    14d0:      	mov	w1, #0x8                // =8
    14d4:      	blr	x8
    14d8:      	ldr	x8, [x21, #0x20]
    14dc:      	add	x9, x8, #0x20
    14e0:      	stp	x9, x8, [sp, #0xa8]
    14e4:      	b	0x136c <generic_usdt_process_event+0x9dc>
    14e8:      	mov	w8, #0x1                // =1
    14ec:      	strb	w8, [sp, #0xc4]
    14f0:      	ldr	x8, [sp, #0xb8]
    14f4:      	ldr	x2, [sp, #0x30]
    14f8:      	cmp	x8, x2
    14fc:      	b.eq	0x1538 <generic_usdt_process_event+0xba8>
    1500:      	ldrb	w9, [sp, #0xc4]
    1504:      	adrp	x21, 0x1000 <generic_usdt_process_event+0x670>
    1508:      	mov	w11, #0x1000            // =4096
    150c:      	cmp	w9, #0x0
    1510:      	ldr	w9, [sp, #0xc0]
    1514:      	ldr	x21, [x21]
    1518:      	cset	w10, eq
    151c:      	sub	w11, w11, w9
    1520:      	cmp	w9, #0x0
    1524:      	csel	w9, w11, w9, gt
    1528:      	cbz	x8, 0x1690 <generic_usdt_process_event+0xd00>
    152c:      	lsl	w23, w10, #1
    1530:      	mov	x2, x8
    1534:      	b	0x1548 <generic_usdt_process_event+0xbb8>
    1538:      	adrp	x21, 0x1000 <generic_usdt_process_event+0x670>
    153c:      	mov	w23, wzr
    1540:      	mov	w9, wzr
    1544:      	ldr	x21, [x21]
    1548:      	ldr	x29, [sp, #0x18]
    154c:      	and	w22, w9, #0xfff
    1550:      	mov	w8, #0x4                // =4
    1554:      	mov	w24, #0x4               // =4
    1558:      	mov	w1, w22
    155c:      	add	x0, x29, #0x4
    1560:      	blr	x8
    1564:      	str	w22, [x29]
    1568:      	ldr	x2, [sp, #0x8]
    156c:      	mov	w25, #0x8               // =8
    1570:      	add	x8, sp, #0x88
    1574:      	mov	w9, #0x4                // =4
    1578:      	add	x0, sp, #0x88
    157c:      	mov	w1, #0x8                // =8
    1580:      	blr	x9
    1584:      	ldr	x8, [sp, #0x88]
    1588:      	add	x9, sp, #0xe0
    158c:      	mov	w10, #0x4               // =4
    1590:      	add	x0, sp, #0xe0
    1594:      	mov	w1, #0x8                // =8
    1598:      	add	x8, x8, #0x30
    159c:      	ldr	x8, [sp, #0x88]
    15a0:      	add	x2, x8, #0x30
    15a4:      	blr	x10
    15a8:      	add	x11, sp, #0xd0
    15ac:      	mov	w9, #0x2                // =2
    15b0:      	add	x10, sp, #0xf0
    15b4:      	ldr	x8, [x11, #0x10]
    15b8:      	add	x0, sp, #0xf0
    15bc:      	mov	w1, #0x2                // =2
    15c0:      	ldr	x2, [x11, #0x10]
    15c4:      	blr	x24
    15c8:      	add	x8, x29, x22
    15cc:      	ldr	x24, [sp, #0x108]
    15d0:      	ldr	x11, [sp, #0x20]
    15d4:      	mov	w25, #0x5efc            // =24316
    15d8:      	mov	w10, #0x5ea0            // =24224
    15dc:      	str	w23, [x8, #0x4]
    15e0:      	ldr	x23, [sp, #0x40]
    15e4:      	ldrh	w9, [sp, #0xf0]
    15e8:      	strh	w9, [x8, #0x8]
    15ec:      	add	w9, w22, #0xa
    15f0:      	b	0x38e4 <generic_usdt_process_event+0x2f54>
    15f4:      	cmp	w24, #0x2c
    15f8:      	str	x9, [sp, #0x30]
    15fc:      	b.hi	0x16a4 <generic_usdt_process_event+0xd14>
    1600:      	mov	x9, #0x7cf2             // =31986
    1604:      	mov	w8, #0x1                // =1
    1608:      	movk	x9, #0xf202, lsl #16
    160c:      	lsl	x8, x8, x24
    1610:      	movk	x9, #0x11c1, lsl #32
    1614:      	tst	x8, x9
    1618:      	b.eq	0x16a4 <generic_usdt_process_event+0xd14>
    161c:      	add	x8, sp, #0xd0
    1620:      	str	wzr, [sp, #0x78]
    1624:      	mov	x0, x21
    1628:      	add	x9, sp, #0x78
    162c:      	str	x22, [x8]
    1630:      	mov	w8, #0x1                // =1
    1634:      	add	x1, sp, #0x78
    1638:      	add	x21, sp, #0xd0
    163c:      	blr	x8
    1640:      	mov	x9, xzr
    1644:      	str	x23, [sp, #0x10]
    1648:      	cbz	x0, 0x38cc <generic_usdt_process_event+0x2f3c>
    164c:      	ldr	x11, [sp, #0x20]
    1650:      	cmp	w24, #0x10
    1654:      	b.le	0x1710 <generic_usdt_process_event+0xd80>
    1658:      	cmp	w24, #0x1e
    165c:      	b.le	0x1834 <generic_usdt_process_event+0xea4>
    1660:      	cmp	w24, #0x26
    1664:      	b.gt	0x1924 <generic_usdt_process_event+0xf94>
    1668:      	sub	w8, w24, #0x1f
    166c:      	cmp	w8, #0x2
    1670:      	b.hs	0x1d6c <generic_usdt_process_event+0x13dc>
    1674:      	mov	w8, #0x1                // =1
    1678:      	add	x9, sp, #0xd0
    167c:      	mov	w10, #0x4               // =4
    1680:      	ldr	x0, [sp, #0x18]
    1684:      	add	x2, sp, #0xd0
    1688:      	mov	w1, #0x1                // =1
    168c:      	b	0x1a6c <generic_usdt_process_event+0x10dc>
    1690:      	mov	x9, xzr
    1694:      	mov	w25, #0x5efc            // =24316
    1698:      	ldr	x23, [sp, #0x40]
    169c:      	ldr	x24, [sp, #0x108]
    16a0:      	b	0x38e8 <generic_usdt_process_event+0x2f58>
    16a4:      	str	wzr, [sp, #0x78]
    16a8:      	mov	w8, #0x1                // =1
    16ac:      	add	x9, sp, #0x78
    16b0:      	add	x1, sp, #0x78
    16b4:      	mov	x0, x21
    16b8:      	blr	x8
    16bc:      	mov	x9, xzr
    16c0:      	str	x23, [sp, #0x10]
    16c4:      	cbz	x0, 0x2a08 <generic_usdt_process_event+0x2078>
    16c8:      	cmp	w24, #0x19
    16cc:      	b.gt	0x18f0 <generic_usdt_process_event+0xf60>
    16d0:      	cmp	w24, #0x12
    16d4:      	b.le	0x19f8 <generic_usdt_process_event+0x1068>
    16d8:      	cmp	w24, #0x14
    16dc:      	b.le	0x1cb4 <generic_usdt_process_event+0x1324>
    16e0:      	cmp	w24, #0x15
    16e4:      	b.eq	0x2404 <generic_usdt_process_event+0x1a74>
    16e8:      	cmp	w24, #0x16
    16ec:      	b.eq	0x23a8 <generic_usdt_process_event+0x1a18>
    16f0:      	ldr	x11, [sp, #0x20]
    16f4:      	cmp	w24, #0x17
    16f8:      	mov	w10, #0x5ea0            // =24224
    16fc:      	b.ne	0x38dc <generic_usdt_process_event+0x2f4c>
    1700:      	ldr	x8, [sp, #0x18]
    1704:      	mov	w9, #0x8                // =8
    1708:      	stp	w22, wzr, [x8]
    170c:      	b	0x38dc <generic_usdt_process_event+0x2f4c>
    1710:      	cmp	w24, #0x9
    1714:      	mov	w10, #0x5ea0            // =24224
    1718:      	b.gt	0x1868 <generic_usdt_process_event+0xed8>
    171c:      	cmp	w24, #0x4
    1720:      	b.le	0x1a80 <generic_usdt_process_event+0x10f0>
    1724:      	cmp	w24, #0x5
    1728:      	b.eq	0x1fc8 <generic_usdt_process_event+0x1638>
    172c:      	adrp	x21, 0x1000 <generic_usdt_process_event+0x670>
    1730:      	ldr	x22, [sp, #0x18]
    1734:      	add	x29, sp, #0xd0
    1738:      	cmp	w24, #0x6
    173c:      	ldr	x21, [x21]
    1740:      	b.eq	0x18d4 <generic_usdt_process_event+0xf44>
    1744:      	ldr	x11, [sp, #0x20]
    1748:      	cmp	w24, #0x7
    174c:      	mov	w10, #0x5ea0            // =24224
    1750:      	str	x0, [sp, #0x38]
    1754:      	b.ne	0x38dc <generic_usdt_process_event+0x2f4c>
    1758:      	ldr	x23, [x29]
    175c:      	add	x0, x22, #0x26
    1760:      	mov	w24, #0x2               // =2
    1764:      	mov	w8, #0x4                // =4
    1768:      	str	x23, [x22, #0x28]
    176c:      	add	x2, x23, #0x10
    1770:      	mov	w1, #0x2                // =2
    1774:      	mov	x25, x22
    1778:      	mov	w22, #0x4               // =4
    177c:      	blr	x8
    1780:      	add	x0, x25, #0x3a
    1784:      	add	x2, x23, #0x12
    1788:      	mov	w8, #0x1                // =1
    178c:      	mov	w9, #0x4                // =4
    1790:      	mov	w1, #0x1                // =1
    1794:      	blr	x9
    1798:      	add	x0, x25, #0x38
    179c:      	add	x2, x23, #0x21e
    17a0:      	mov	w8, #0x4                // =4
    17a4:      	mov	w1, #0x2                // =2
    17a8:      	blr	x8
    17ac:      	add	x0, x25, #0x24
    17b0:      	add	x2, x23, #0x21c
    17b4:      	mov	w8, #0x4                // =4
    17b8:      	mov	w1, #0x2                // =2
    17bc:      	blr	x8
    17c0:      	add	x0, x25, #0x30
    17c4:      	add	x2, x23, #0x214
    17c8:      	mov	w8, #0x4                // =4
    17cc:      	mov	w1, #0x4                // =4
    17d0:      	blr	x8
    17d4:      	add	x0, x25, #0x34
    17d8:      	add	x2, x23, #0x210
    17dc:      	mov	w1, #0x4                // =4
    17e0:      	blr	x22
    17e4:      	ldrh	w8, [x25, #0x26]
    17e8:      	mov	x22, x25
    17ec:      	stp	xzr, xzr, [x25]
    17f0:      	cmp	w8, #0xa
    17f4:      	str	xzr, [x25, #0x18]
    17f8:      	str	xzr, [x22, #0x10]!
    17fc:      	b.eq	0x27c4 <generic_usdt_process_event+0x1e34>
    1800:      	cmp	w8, #0x2
    1804:      	b.ne	0x27f0 <generic_usdt_process_event+0x1e60>
    1808:      	ldr	x0, [sp, #0x18]
    180c:      	add	x2, x23, #0x4
    1810:      	mov	w8, #0x4                // =4
    1814:      	mov	w1, #0x4                // =4
    1818:      	mov	w24, #0x4               // =4
    181c:      	blr	x8
    1820:      	mov	x0, x22
    1824:      	mov	w1, #0x4                // =4
    1828:      	mov	x2, x23
    182c:      	blr	x24
    1830:      	b	0x27f0 <generic_usdt_process_event+0x1e60>
    1834:      	cmp	w24, #0x1c
    1838:      	b.gt	0x1a54 <generic_usdt_process_event+0x10c4>
    183c:      	adrp	x21, 0x1000 <generic_usdt_process_event+0x670>
    1840:      	cmp	w24, #0x11
    1844:      	ldr	x21, [x21]
    1848:      	b.eq	0x1dbc <generic_usdt_process_event+0x142c>
    184c:      	cmp	w24, #0x19
    1850:      	b.eq	0x1e70 <generic_usdt_process_event+0x14e0>
    1854:      	ldr	x0, [sp, #0x18]
    1858:      	cmp	w24, #0x1c
    185c:      	mov	w10, #0x5ea0            // =24224
    1860:      	b.eq	0x1a9c <generic_usdt_process_event+0x110c>
    1864:      	b	0x38dc <generic_usdt_process_event+0x2f4c>
    1868:      	adrp	x21, 0x1000 <generic_usdt_process_event+0x670>
    186c:      	ldr	x0, [sp, #0x18]
    1870:      	sub	w8, w24, #0xa
    1874:      	add	x29, sp, #0xd0
    1878:      	ldr	x21, [x21]
    187c:      	cmp	w8, #0x2
    1880:      	b.lo	0x1a9c <generic_usdt_process_event+0x110c>
    1884:      	sub	w8, w24, #0xc
    1888:      	cmp	w8, #0x2
    188c:      	b.lo	0x1abc <generic_usdt_process_event+0x112c>
    1890:      	cmp	w24, #0xe
    1894:      	b.ne	0x38dc <generic_usdt_process_event+0x2f4c>
    1898:      	mov	w22, #0x8               // =8
    189c:      	add	x8, sp, #0x88
    18a0:      	add	x24, sp, #0xd0
    18a4:      	mov	w9, #0x4                // =4
    18a8:      	add	x0, sp, #0x88
    18ac:      	add	x2, sp, #0xd0
    18b0:      	mov	w1, #0x8                // =8
    18b4:      	mov	w23, #0x4               // =4
    18b8:      	blr	x9
    18bc:      	ldr	x8, [sp, #0x88]
    18c0:      	add	x0, sp, #0xd0
    18c4:      	mov	w1, #0x8                // =8
    18c8:      	ldr	x2, [sp, #0x88]
    18cc:      	blr	x23
    18d0:      	ldr	x22, [sp, #0x18]
    18d4:      	ldr	x2, [x29]
    18d8:      	add	x0, x22, #0x4
    18dc:      	mov	w8, #0x1001             // =4097
    18e0:      	mov	w9, #0x2d               // =45
    18e4:      	mov	w1, #0x1001             // =4097
    18e8:      	blr	x9
    18ec:      	b	0x1da4 <generic_usdt_process_event+0x1414>
    18f0:      	cmp	w24, #0x20
    18f4:      	b.le	0x1bf0 <generic_usdt_process_event+0x1260>
    18f8:      	sub	w8, w24, #0x21
    18fc:      	cmp	w8, #0x4
    1900:      	b.hs	0x1ad8 <generic_usdt_process_event+0x1148>
    1904:      	ldr	x0, [sp, #0x18]
    1908:      	mov	w9, #0x8                // =8
    190c:      	mov	w8, #0x4                // =4
    1910:      	mov	w1, #0x8                // =8
    1914:      	mov	x2, x22
    1918:      	blr	x8
    191c:      	mov	w9, #0x8                // =8
    1920:      	b	0x2a08 <generic_usdt_process_event+0x2078>
    1924:      	cmp	w24, #0x27
    1928:      	b.eq	0x2120 <generic_usdt_process_event+0x1790>
    192c:      	cmp	w24, #0x28
    1930:      	b.eq	0x2158 <generic_usdt_process_event+0x17c8>
    1934:      	adrp	x21, 0x1000 <generic_usdt_process_event+0x670>
    1938:      	ldr	x0, [sp, #0x18]
    193c:      	add	x8, sp, #0xd0
    1940:      	cmp	w24, #0x2c
    1944:      	ldr	x21, [x21]
    1948:      	mov	w10, #0x5ea0            // =24224
    194c:      	b.ne	0x38dc <generic_usdt_process_event+0x2f4c>
    1950:      	ldr	x22, [x8]
    1954:      	strb	wzr, [sp, #0x88]
    1958:      	mov	w8, #0x2                // =2
    195c:      	mov	w9, #0x4                // =4
    1960:      	mov	w1, #0x2                // =2
    1964:      	mov	x2, x22
    1968:      	stp	xzr, xzr, [x0]
    196c:      	stp	xzr, xzr, [x0, #0x10]
    1970:      	stp	xzr, xzr, [x0, #0x20]
    1974:      	stp	xzr, xzr, [x0, #0x30]
    1978:      	stp	xzr, xzr, [x0, #0x40]
    197c:      	stp	xzr, xzr, [x0, #0x50]
    1980:      	stp	xzr, xzr, [x0, #0x60]
    1984:      	blr	x9
    1988:      	tbnz	x0, #0x3f, 0x2a04 <generic_usdt_process_event+0x2074>
    198c:      	add	x23, x22, #0x2
    1990:      	mov	w8, #0x1                // =1
    1994:      	mov	w9, #0x4                // =4
    1998:      	add	x10, sp, #0x88
    199c:      	add	x0, sp, #0x88
    19a0:      	mov	w1, #0x1                // =1
    19a4:      	mov	x2, x23
    19a8:      	blr	x9
    19ac:      	tbnz	x0, #0x3f, 0x2a04 <generic_usdt_process_event+0x2074>
    19b0:      	ldrb	w8, [sp, #0x88]
    19b4:      	ldr	x10, [sp, #0x18]
    19b8:      	cmp	w8, #0x0
    19bc:      	add	x0, x10, #0x4
    19c0:      	cset	w9, eq
    19c4:      	strb	w9, [x10, #0x2]
    19c8:      	cbz	w8, 0x29d8 <generic_usdt_process_event+0x2048>
    19cc:      	mov	w8, #0x6c               // =108
    19d0:      	mov	w9, #0x2d               // =45
    19d4:      	mov	w1, #0x6c               // =108
    19d8:      	mov	x2, x23
    19dc:      	blr	x9
    19e0:      	adrp	x21, 0x1000 <generic_usdt_process_event+0x670>
    19e4:      	mov	w25, #0x5efc            // =24316
    19e8:      	ldr	x21, [x21]
    19ec:      	tbnz	w0, #0x1f, 0x2a04 <generic_usdt_process_event+0x2074>
    19f0:      	sub	w22, w0, #0x1
    19f4:      	b	0x29fc <generic_usdt_process_event+0x206c>
    19f8:      	cmp	w24, #0x7
    19fc:      	b.gt	0x1c68 <generic_usdt_process_event+0x12d8>
    1a00:      	cmp	w24, #0x2
    1a04:      	b.eq	0x21d0 <generic_usdt_process_event+0x1840>
    1a08:      	ldr	x11, [sp, #0x20]
    1a0c:      	cmp	w24, #0x3
    1a10:      	mov	w10, #0x5ea0            // =24224
    1a14:      	b.ne	0x38dc <generic_usdt_process_event+0x2f4c>
    1a18:      	ldr	x8, [sp, #0x30]
    1a1c:      	add	x21, x0, #0x90
    1a20:      	mov	x23, x0
    1a24:      	add	x25, x21, x29
    1a28:      	and	w8, w8, #0xf
    1a2c:      	cmp	w8, #0x2
    1a30:      	b.le	0x2950 <generic_usdt_process_event+0x1fc0>
    1a34:      	cmp	w8, #0x3
    1a38:      	b.eq	0x2ae0 <generic_usdt_process_event+0x2150>
    1a3c:      	cmp	w8, #0x4
    1a40:      	b.eq	0x2ae8 <generic_usdt_process_event+0x2158>
    1a44:      	cmp	w8, #0x5
    1a48:      	b.ne	0x2b3c <generic_usdt_process_event+0x21ac>
    1a4c:      	mov	w8, #0x5e70             // =24176
    1a50:      	b	0x2af4 <generic_usdt_process_event+0x2164>
    1a54:      	ldr	x0, [sp, #0x18]
    1a58:      	mov	w8, #0x2                // =2
    1a5c:      	add	x9, sp, #0xd0
    1a60:      	mov	w10, #0x4               // =4
    1a64:      	add	x2, sp, #0xd0
    1a68:      	mov	w1, #0x2                // =2
    1a6c:      	blr	x10
    1a70:      	adrp	x21, 0x1000 <generic_usdt_process_event+0x670>
    1a74:      	ldr	x11, [sp, #0x20]
    1a78:      	mov	w9, #0x4                // =4
    1a7c:      	b	0x38d4 <generic_usdt_process_event+0x2f44>
    1a80:      	adrp	x21, 0x1000 <generic_usdt_process_event+0x670>
    1a84:      	ldr	x0, [sp, #0x18]
    1a88:      	cmp	w24, #0x1
    1a8c:      	ldr	x21, [x21]
    1a90:      	b.eq	0x1abc <generic_usdt_process_event+0x112c>
    1a94:      	cmp	w24, #0x4
    1a98:      	b.ne	0x38dc <generic_usdt_process_event+0x2f4c>
    1a9c:      	mov	w10, #0x8               // =8
    1aa0:      	mov	w8, #0x4                // =4
    1aa4:      	add	x9, sp, #0xd0
    1aa8:      	add	x2, sp, #0xd0
    1aac:      	mov	w1, #0x8                // =8
    1ab0:      	blr	x8
    1ab4:      	mov	w9, #0x8                // =8
    1ab8:      	b	0x2a08 <generic_usdt_process_event+0x2078>
    1abc:      	add	x8, sp, #0xd0
    1ac0:      	mov	w9, #0x4                // =4
    1ac4:      	add	x2, sp, #0xd0
    1ac8:      	mov	w1, #0x4                // =4
    1acc:      	blr	x9
    1ad0:      	mov	w9, #0x4                // =4
    1ad4:      	b	0x2a08 <generic_usdt_process_event+0x2078>
    1ad8:      	cmp	w24, #0x2b
    1adc:      	b.eq	0x24c4 <generic_usdt_process_event+0x1b34>
    1ae0:      	ldr	x11, [sp, #0x20]
    1ae4:      	cmp	w24, #0x29
    1ae8:      	mov	w10, #0x5ea0            // =24224
    1aec:      	b.ne	0x38dc <generic_usdt_process_event+0x2f4c>
    1af0:      	add	x2, x22, #0x18
    1af4:      	mov	w8, #0x8                // =8
    1af8:      	mov	w9, #0x4                // =4
    1afc:      	add	x10, sp, #0x88
    1b00:      	mov	x29, x0
    1b04:      	add	x0, sp, #0x88
    1b08:      	mov	w1, #0x8                // =8
    1b0c:      	blr	x9
    1b10:      	ldr	x23, [sp, #0x88]
    1b14:      	cbz	x23, 0x2a9c <generic_usdt_process_event+0x210c>
    1b18:      	ldr	x25, [sp, #0x18]
    1b1c:      	add	x2, x23, #0x10
    1b20:      	mov	w24, #0x2               // =2
    1b24:      	mov	w8, #0x4                // =4
    1b28:      	str	x23, [x25, #0x28]
    1b2c:      	add	x0, x25, #0x26
    1b30:      	mov	w1, #0x2                // =2
    1b34:      	mov	w22, #0x4               // =4
    1b38:      	blr	x8
    1b3c:      	add	x0, x25, #0x3a
    1b40:      	add	x2, x23, #0x12
    1b44:      	mov	w8, #0x1                // =1
    1b48:      	mov	w9, #0x4                // =4
    1b4c:      	mov	w1, #0x1                // =1
    1b50:      	blr	x9
    1b54:      	add	x0, x25, #0x38
    1b58:      	add	x2, x23, #0x21e
    1b5c:      	mov	w8, #0x4                // =4
    1b60:      	mov	w1, #0x2                // =2
    1b64:      	blr	x8
    1b68:      	add	x0, x25, #0x24
    1b6c:      	add	x2, x23, #0x21c
    1b70:      	mov	w8, #0x4                // =4
    1b74:      	mov	w1, #0x2                // =2
    1b78:      	blr	x8
    1b7c:      	add	x0, x25, #0x30
    1b80:      	add	x2, x23, #0x214
    1b84:      	mov	w8, #0x4                // =4
    1b88:      	mov	w1, #0x4                // =4
    1b8c:      	blr	x8
    1b90:      	add	x0, x25, #0x34
    1b94:      	add	x2, x23, #0x210
    1b98:      	mov	w1, #0x4                // =4
    1b9c:      	blr	x22
    1ba0:      	ldrh	w8, [x25, #0x26]
    1ba4:      	mov	x22, x25
    1ba8:      	stp	xzr, xzr, [x25]
    1bac:      	cmp	w8, #0xa
    1bb0:      	str	xzr, [x25, #0x18]
    1bb4:      	str	xzr, [x22, #0x10]!
    1bb8:      	b.eq	0x2a2c <generic_usdt_process_event+0x209c>
    1bbc:      	cmp	w8, #0x2
    1bc0:      	b.ne	0x2a58 <generic_usdt_process_event+0x20c8>
    1bc4:      	ldr	x0, [sp, #0x18]
    1bc8:      	add	x2, x23, #0x4
    1bcc:      	mov	w8, #0x4                // =4
    1bd0:      	mov	w1, #0x4                // =4
    1bd4:      	mov	w24, #0x4               // =4
    1bd8:      	blr	x8
    1bdc:      	mov	x0, x22
    1be0:      	mov	w1, #0x4                // =4
    1be4:      	mov	x2, x23
    1be8:      	blr	x24
    1bec:      	b	0x2a58 <generic_usdt_process_event+0x20c8>
    1bf0:      	cmp	w24, #0x1a
    1bf4:      	b.eq	0x2550 <generic_usdt_process_event+0x1bc0>
    1bf8:      	ldr	x11, [sp, #0x20]
    1bfc:      	cmp	w24, #0x1b
    1c00:      	mov	w10, #0x5ea0            // =24224
    1c04:      	b.ne	0x38dc <generic_usdt_process_event+0x2f4c>
    1c08:      	ldr	x10, [sp, #0x18]
    1c0c:      	add	x2, x22, #0x18
    1c10:      	mov	w8, #0x3f               // =63
    1c14:      	mov	w9, #0x2d               // =45
    1c18:      	stp	xzr, xzr, [x10, #0x40]
    1c1c:      	mov	x0, x10
    1c20:      	stp	xzr, xzr, [x10, #0x30]
    1c24:      	stp	xzr, xzr, [x10, #0x20]
    1c28:      	str	xzr, [x10, #0x18]
    1c2c:      	stp	xzr, xzr, [x10]
    1c30:      	mov	w1, #0x3f               // =63
    1c34:      	mov	x23, x11
    1c38:      	str	xzr, [x0, #0x10]!
    1c3c:      	blr	x9
    1c40:      	tbnz	x0, #0x3f, 0x29bc <generic_usdt_process_event+0x202c>
    1c44:      	ldr	x8, [sp, #0x18]
    1c48:      	add	x2, x22, #0x360
    1c4c:      	mov	w9, #0x4                // =4
    1c50:      	mov	w1, #0x8                // =8
    1c54:      	add	x0, x8, #0x8
    1c58:      	mov	w8, #0x8                // =8
    1c5c:      	blr	x9
    1c60:      	mov	w9, #0x50               // =80
    1c64:      	b	0x29c0 <generic_usdt_process_event+0x2030>
    1c68:      	cmp	w24, #0x8
    1c6c:      	b.eq	0x2228 <generic_usdt_process_event+0x1898>
    1c70:      	ldr	x11, [sp, #0x20]
    1c74:      	cmp	w24, #0x12
    1c78:      	mov	w25, #0x5efc            // =24316
    1c7c:      	mov	w10, #0x5ea0            // =24224
    1c80:      	b.ne	0x38dc <generic_usdt_process_event+0x2f4c>
    1c84:      	ldr	x8, [sp, #0x30]
    1c88:      	ldr	x0, [sp, #0x18]
    1c8c:      	mov	x2, x22
    1c90:      	and	x23, x8, #0x3ff
    1c94:      	mov	w8, #0x4                // =4
    1c98:      	mov	x22, x11
    1c9c:      	mov	w1, w23
    1ca0:      	blr	x8
    1ca4:      	mov	x9, x23
    1ca8:      	mov	x11, x22
    1cac:      	mov	w10, #0x5ea0            // =24224
    1cb0:      	b	0x38dc <generic_usdt_process_event+0x2f4c>
    1cb4:      	cmp	w24, #0x13
    1cb8:      	b.eq	0x2478 <generic_usdt_process_event+0x1ae8>
    1cbc:      	ldr	x11, [sp, #0x20]
    1cc0:      	cmp	w24, #0x14
    1cc4:      	mov	w10, #0x5ea0            // =24224
    1cc8:      	b.ne	0x38dc <generic_usdt_process_event+0x2f4c>
    1ccc:      	str	xzr, [sp, #0x88]
    1cd0:      	add	x2, x22, #0x110
    1cd4:      	mov	w10, #0x8               // =8
    1cd8:      	add	x8, sp, #0x88
    1cdc:      	mov	w9, #0x4                // =4
    1ce0:      	add	x0, sp, #0x88
    1ce4:      	mov	w1, #0x8                // =8
    1ce8:      	add	x23, x22, #0xd8
    1cec:      	mov	w24, #0x4               // =4
    1cf0:      	mov	x29, x11
    1cf4:      	blr	x9
    1cf8:      	ldr	x8, [sp, #0x88]
    1cfc:      	mov	w9, #0x80               // =128
    1d00:      	mov	w10, #0x2d              // =45
    1d04:      	ldr	x25, [sp, #0x18]
    1d08:      	mov	w1, #0x80               // =128
    1d0c:      	mov	x0, x25
    1d10:      	ldr	x2, [sp, #0x88]
    1d14:      	blr	x10
    1d18:      	add	x0, x25, #0x90
    1d1c:      	mov	w8, #0x4                // =4
    1d20:      	mov	w1, #0x4                // =4
    1d24:      	mov	x2, x23
    1d28:      	blr	x8
    1d2c:      	add	x0, x25, #0x80
    1d30:      	add	x2, x22, #0xe0
    1d34:      	mov	w8, #0x4                // =4
    1d38:      	mov	w9, #0x8                // =8
    1d3c:      	mov	w1, #0x8                // =8
    1d40:      	mov	w23, #0x8               // =8
    1d44:      	blr	x8
    1d48:      	add	x0, x25, #0x88
    1d4c:      	add	x2, x22, #0x118
    1d50:      	mov	w1, #0x8                // =8
    1d54:      	mov	w25, #0x5efc            // =24316
    1d58:      	blr	x24
    1d5c:      	mov	x11, x29
    1d60:      	mov	w10, #0x5ea0            // =24224
    1d64:      	mov	w9, #0x98               // =152
    1d68:      	b	0x38dc <generic_usdt_process_event+0x2f4c>
    1d6c:      	adrp	x21, 0x1000 <generic_usdt_process_event+0x670>
    1d70:      	ldr	x22, [sp, #0x18]
    1d74:      	add	x8, sp, #0xd0
    1d78:      	cmp	w24, #0x26
    1d7c:      	ldr	x21, [x21]
    1d80:      	mov	w10, #0x5ea0            // =24224
    1d84:      	b.ne	0x38dc <generic_usdt_process_event+0x2f4c>
    1d88:      	ldr	x8, [x8]
    1d8c:      	add	x0, x22, #0x4
    1d90:      	add	x2, x19, w8, uxth
    1d94:      	ubfx	w8, w8, #16, #12
    1d98:      	add	w1, w8, #0x1
    1d9c:      	mov	w8, #0x2d               // =45
    1da0:      	blr	x8
    1da4:      	mov	x9, x0
    1da8:      	tbnz	x0, #0x3f, 0x2a08 <generic_usdt_process_event+0x2078>
    1dac:      	sub	w8, w9, #0x1
    1db0:      	add	x9, x9, #0x3
    1db4:      	str	w8, [x22]
    1db8:      	b	0x2a08 <generic_usdt_process_event+0x2078>
    1dbc:      	str	xzr, [sp, #0x90]
    1dc0:      	mov	w8, #0xe                // =14
    1dc4:      	blr	x8
    1dc8:      	lsr	x8, x0, #32
    1dcc:      	add	x9, sp, #0xe0
    1dd0:      	add	x10, sp, #0xd0
    1dd4:      	str	x8, [sp, #0x88]
    1dd8:      	mov	w8, #0x4                // =4
    1ddc:      	add	x0, sp, #0xe0
    1de0:      	add	x2, sp, #0xd0
    1de4:      	mov	w1, #0x4                // =4
    1de8:      	blr	x8
    1dec:      	ldr	w8, [sp, #0xe0]
    1df0:      	adrp	x0, 0x1000 <generic_usdt_process_event+0x670>
    1df4:      	add	x9, sp, #0x88
    1df8:      	add	x1, sp, #0x88
    1dfc:      	str	w8, [sp, #0x90]
    1e00:      	mov	w8, #0x1                // =1
    1e04:      	ldr	x0, [x0]
    1e08:      	blr	x8
    1e0c:      	cbz	x0, 0x262c <generic_usdt_process_event+0x1c9c>
    1e10:      	ldr	x25, [sp, #0x18]
    1e14:      	ldr	w23, [x0]
    1e18:      	add	x8, sp, #0xe0
    1e1c:      	mov	w9, #0x4                // =4
    1e20:      	add	x2, sp, #0xe0
    1e24:      	mov	x22, x0
    1e28:      	mov	w1, #0x4                // =4
    1e2c:      	mov	w24, #0x4               // =4
    1e30:      	mov	x0, x25
    1e34:      	blr	x9
    1e38:      	and	x23, x23, #0xfff
    1e3c:      	add	x0, x25, #0x4
    1e40:      	mov	w8, #0x4                // =4
    1e44:      	mov	x2, x22
    1e48:      	add	x1, x23, #0x4
    1e4c:      	blr	x8
    1e50:      	add	w23, w23, #0x8
    1e54:      	mov	w1, #0x4                // =4
    1e58:      	add	x8, x23, x22
    1e5c:      	add	x0, x25, x23
    1e60:      	sub	x2, x8, #0x4
    1e64:      	blr	x24
    1e68:      	add	x9, x23, #0x4
    1e6c:      	b	0x38c8 <generic_usdt_process_event+0x2f38>
    1e70:      	add	x8, sp, #0xd0
    1e74:      	mov	w9, #0x4                // =4
    1e78:      	add	x10, sp, #0x74
    1e7c:      	ldr	x22, [x8]
    1e80:      	mov	w8, #0x1                // =1
    1e84:      	mov	x23, x0
    1e88:      	add	x0, sp, #0x74
    1e8c:      	mov	w1, #0x1                // =1
    1e90:      	mov	x2, x22
    1e94:      	blr	x9
    1e98:      	ldrb	w8, [sp, #0x74]
    1e9c:      	cbz	w8, 0x2634 <generic_usdt_process_event+0x1ca4>
    1ea0:      	cmp	w8, #0x1
    1ea4:      	b.ne	0x2878 <generic_usdt_process_event+0x1ee8>
    1ea8:      	add	x2, x22, #0x10
    1eac:      	mov	w22, #0x8               // =8
    1eb0:      	add	x8, sp, #0xe0
    1eb4:      	mov	w9, #0x4                // =4
    1eb8:      	add	x0, sp, #0xe0
    1ebc:      	mov	w1, #0x8                // =8
    1ec0:      	mov	w24, #0x4               // =4
    1ec4:      	blr	x9
    1ec8:      	add	x21, sp, #0xd0
    1ecc:      	add	x8, sp, #0xf0
    1ed0:      	mov	w9, #0x4                // =4
    1ed4:      	ldr	x2, [x21, #0x10]
    1ed8:      	add	x0, sp, #0xf0
    1edc:      	mov	w1, #0x8                // =8
    1ee0:      	blr	x9
    1ee4:      	ldr	x8, [x21, #0x10]
    1ee8:      	add	x0, sp, #0xd8
    1eec:      	mov	w1, #0x8                // =8
    1ef0:      	add	x2, x8, #0x8
    1ef4:      	add	x8, sp, #0xd8
    1ef8:      	blr	x24
    1efc:      	ldr	x25, [x21, #0x20]
    1f00:      	ldr	x21, [x21, #0x8]
    1f04:      	add	x8, x23, #0x90
    1f08:      	add	x29, x8, x29
    1f0c:      	ldr	x9, [sp, #0x38]
    1f10:      	tbz	w9, #0x5, 0x2c3c <generic_usdt_process_event+0x22ac>
    1f14:      	cmp	x21, #0x1, lsl #12      // =0x1000
    1f18:      	b.lo	0x2c24 <generic_usdt_process_event+0x2294>
    1f1c:      	mov	w8, #0x1                // =1
    1f20:      	adrp	x0, 0x1000 <generic_usdt_process_event+0x670>
    1f24:      	add	x9, sp, #0x80
    1f28:      	str	w8, [x29]
    1f2c:      	str	wzr, [sp, #0x80]
    1f30:      	add	x1, sp, #0x80
    1f34:      	ldr	x0, [x0]
    1f38:      	blr	x8
    1f3c:      	cbz	x0, 0x3170 <generic_usdt_process_event+0x27e0>
    1f40:      	mov	w8, #0x18               // =24
    1f44:      	mov	x24, x0
    1f48:      	str	w8, [x0]
    1f4c:      	mov	w8, #0xe                // =14
    1f50:      	blr	x8
    1f54:      	mov	x22, x24
    1f58:      	cmn	x0, #0x16
    1f5c:      	str	x0, [x22, #0x10]!
    1f60:      	b.ne	0x1f88 <generic_usdt_process_event+0x15f8>
    1f64:      	add	x2, x19, #0xe8
    1f68:      	mov	w8, #0x8                // =8
    1f6c:      	mov	w9, #0x4                // =4
    1f70:      	add	x10, sp, #0x88
    1f74:      	add	x0, sp, #0x88
    1f78:      	mov	w1, #0x8                // =8
    1f7c:      	blr	x9
    1f80:      	ldr	x8, [sp, #0x88]
    1f84:      	str	x8, [x22]
    1f88:      	mov	w8, #0x7d               // =125
    1f8c:      	blr	x8
    1f90:      	str	x0, [x24, #0x18]
    1f94:      	mov	x0, x19
    1f98:      	mov	x1, x24
    1f9c:      	mov	x2, x25
    1fa0:      	ldp	x8, x9, [x22]
    1fa4:      	mov	x3, x21
    1fa8:      	stur	x9, [x29, #0x1c]
    1fac:      	stur	x8, [x29, #0x14]
    1fb0:      	bl	0x1fb0 <generic_usdt_process_event+0x1620>
    1fb4:      	tbnz	w0, #0x1f, 0x2ed0 <generic_usdt_process_event+0x2540>
    1fb8:      	sub	w8, w21, w0
    1fbc:      	cmn	x21, #0x1
    1fc0:      	stur	xzr, [x29, #0x4]
    1fc4:      	b	0x2734 <generic_usdt_process_event+0x1da4>
    1fc8:      	ldr	x24, [x21]
    1fcc:      	ldr	x22, [sp, #0x18]
    1fd0:      	mov	w8, #0x4                // =4
    1fd4:      	mov	w1, #0x4                // =4
    1fd8:      	mov	w23, #0x4               // =4
    1fdc:      	add	x0, x22, #0x28
    1fe0:      	add	x2, x24, #0x98
    1fe4:      	blr	x8
    1fe8:      	add	x0, x22, #0x2c
    1fec:      	add	x2, x24, #0x70
    1ff0:      	mov	w8, #0x4                // =4
    1ff4:      	mov	w1, #0x4                // =4
    1ff8:      	blr	x8
    1ffc:      	add	x0, x22, #0x30
    2000:      	add	x2, x24, #0x90
    2004:      	mov	w8, #0x4                // =4
    2008:      	mov	w1, #0x4                // =4
    200c:      	blr	x8
    2010:      	add	x0, x22, #0x34
    2014:      	add	x2, x24, #0xa8
    2018:      	mov	w8, #0x4                // =4
    201c:      	mov	w1, #0x4                // =4
    2020:      	blr	x8
    2024:      	str	xzr, [sp, #0x88]
    2028:      	add	x2, x24, #0xc8
    202c:      	mov	w8, #0x8                // =8
    2030:      	add	x9, sp, #0x88
    2034:      	mov	w10, #0x4               // =4
    2038:      	add	x0, sp, #0x88
    203c:      	mov	w1, #0x8                // =8
    2040:      	blr	x10
    2044:      	add	x2, x24, #0xb8
    2048:      	mov	w8, #0x2                // =2
    204c:      	add	x9, sp, #0xd8
    2050:      	mov	w10, #0x4               // =4
    2054:      	add	x0, sp, #0xd8
    2058:      	mov	w1, #0x2                // =2
    205c:      	blr	x10
    2060:      	ldr	x8, [sp, #0x88]
    2064:      	ldrh	w9, [sp, #0xd8]
    2068:      	add	x0, sp, #0xcc
    206c:      	mov	w1, #0x1                // =1
    2070:      	add	x22, x8, x9
    2074:      	mov	w8, #0x1                // =1
    2078:      	add	x9, sp, #0xcc
    207c:      	mov	x2, x22
    2080:      	blr	x23
    2084:      	ldrb	w8, [sp, #0xcc]
    2088:      	lsr	w8, w8, #4
    208c:      	cmp	w8, #0x6
    2090:      	b.eq	0x273c <generic_usdt_process_event+0x1dac>
    2094:      	cmp	w8, #0x4
    2098:      	b.ne	0x38c4 <generic_usdt_process_event+0x2f34>
    209c:      	add	x2, x22, #0x9
    20a0:      	mov	w8, #0x1                // =1
    20a4:      	add	x9, sp, #0x74
    20a8:      	mov	w10, #0x4               // =4
    20ac:      	add	x0, sp, #0x74
    20b0:      	mov	w1, #0x1                // =1
    20b4:      	mov	w25, #0x4               // =4
    20b8:      	blr	x10
    20bc:      	ldr	x0, [sp, #0x18]
    20c0:      	ldrb	w8, [sp, #0x74]
    20c4:      	mov	w29, #0x2               // =2
    20c8:      	add	x2, x22, #0xc
    20cc:      	mov	w1, #0x4                // =4
    20d0:      	mov	x23, x0
    20d4:      	strh	w8, [x0, #0x24]
    20d8:      	strh	w29, [x0, #0x26]
    20dc:      	stp	xzr, xzr, [x0]
    20e0:      	str	xzr, [x0, #0x18]
    20e4:      	mov	w8, #0x4                // =4
    20e8:      	str	xzr, [x23, #0x10]!
    20ec:      	blr	x8
    20f0:      	add	x2, x22, #0x10
    20f4:      	mov	w8, #0x4                // =4
    20f8:      	mov	x0, x23
    20fc:      	mov	w1, #0x4                // =4
    2100:      	blr	x8
    2104:      	add	x2, x24, #0xb6
    2108:      	add	x8, sp, #0x80
    210c:      	add	x0, sp, #0x80
    2110:      	mov	w1, #0x2                // =2
    2114:      	blr	x25
    2118:      	ldrb	w29, [sp, #0x74]
    211c:      	b	0x3788 <generic_usdt_process_event+0x2df8>
    2120:      	ldr	x8, [x21]
    2124:      	ldr	x22, [sp, #0x18]
    2128:      	mov	w9, #0x2d               // =45
    212c:      	mov	w1, #0x11               // =17
    2130:      	add	x2, x8, #0x118
    2134:      	add	x0, x22, #0x4
    2138:      	mov	w8, #0x11               // =17
    213c:      	blr	x9
    2140:      	mov	x9, x0
    2144:      	tbnz	x0, #0x3f, 0x38cc <generic_usdt_process_event+0x2f3c>
    2148:      	sub	w8, w9, #0x1
    214c:      	add	x9, x9, #0x3
    2150:      	str	w8, [x22]
    2154:      	b	0x38cc <generic_usdt_process_event+0x2f3c>
    2158:      	ldr	x23, [sp, #0x18]
    215c:      	ldr	x22, [x21]
    2160:      	mov	w8, #0x2                // =2
    2164:      	mov	w9, #0x4                // =4
    2168:      	mov	w1, #0x2                // =2
    216c:      	mov	x0, x23
    2170:      	str	xzr, [x23]
    2174:      	stp	xzr, xzr, [x23, #0x8]
    2178:      	mov	x2, x22
    217c:      	blr	x9
    2180:      	tbnz	x0, #0x3f, 0x29b4 <generic_usdt_process_event+0x2024>
    2184:      	ldrh	w8, [x23]
    2188:      	cmp	w8, #0xa
    218c:      	b.eq	0x2968 <generic_usdt_process_event+0x1fd8>
    2190:      	cmp	w8, #0x2
    2194:      	b.ne	0x299c <generic_usdt_process_event+0x200c>
    2198:      	add	x2, x22, #0x4
    219c:      	add	x8, sp, #0x88
    21a0:      	mov	w9, #0x4                // =4
    21a4:      	add	x0, sp, #0x88
    21a8:      	mov	w1, #0x4                // =4
    21ac:      	mov	w23, #0x4               // =4
    21b0:      	blr	x9
    21b4:      	ldr	w8, [sp, #0x88]
    21b8:      	ldr	x9, [sp, #0x18]
    21bc:      	add	x2, x22, #0x2
    21c0:      	add	x0, x9, #0x2
    21c4:      	str	x8, [x9, #0x8]
    21c8:      	mov	w8, #0x2                // =2
    21cc:      	b	0x2994 <generic_usdt_process_event+0x2004>
    21d0:      	add	x24, x0, #0x90
    21d4:      	mov	x23, x0
    21d8:      	add	x8, x24, x29
    21dc:      	str	x8, [sp, #0x30]
    21e0:      	add	x8, sp, #0xd0
    21e4:      	str	xzr, [x8]
    21e8:      	ldr	x8, [sp, #0x38]
    21ec:      	tbnz	w8, #0x4, 0x288c <generic_usdt_process_event+0x1efc>
    21f0:      	ldr	x9, [sp, #0x38]
    21f4:      	mov	x8, xzr
    21f8:      	and	x29, x9, #0xffffffff
    21fc:      	and	w9, w9, #0xf
    2200:      	cmp	w9, #0x2
    2204:      	b.le	0x2a14 <generic_usdt_process_event+0x2084>
    2208:      	cmp	w9, #0x3
    220c:      	b.eq	0x2d54 <generic_usdt_process_event+0x23c4>
    2210:      	cmp	w9, #0x4
    2214:      	b.eq	0x2d5c <generic_usdt_process_event+0x23cc>
    2218:      	cmp	w9, #0x5
    221c:      	b.ne	0x2d70 <generic_usdt_process_event+0x23e0>
    2220:      	mov	w8, #0x5e70             // =24176
    2224:      	b	0x2d68 <generic_usdt_process_event+0x23d8>
    2228:      	ldr	x24, [sp, #0x18]
    222c:      	add	x2, x22, #0x8
    2230:      	mov	w1, #0x4                // =4
    2234:      	mov	w29, #0x4               // =4
    2238:      	add	x8, x24, #0x40
    223c:      	mov	x0, x24
    2240:      	add	x23, x24, #0x28
    2244:      	str	x8, [sp, #0x38]
    2248:      	mov	w8, #0x4                // =4
    224c:      	blr	x8
    2250:      	add	x0, x24, #0x4
    2254:      	add	x2, x22, #0xc
    2258:      	mov	w8, #0x4                // =4
    225c:      	mov	w1, #0x4                // =4
    2260:      	blr	x8
    2264:      	add	x0, x24, #0x10
    2268:      	add	x2, x22, #0x18
    226c:      	mov	w8, #0x4                // =4
    2270:      	mov	w1, #0x4                // =4
    2274:      	blr	x8
    2278:      	add	x0, x24, #0x14
    227c:      	add	x2, x22, #0x1c
    2280:      	mov	w8, #0x4                // =4
    2284:      	mov	w1, #0x4                // =4
    2288:      	blr	x8
    228c:      	add	x0, x24, #0x8
    2290:      	add	x2, x22, #0x10
    2294:      	mov	w8, #0x4                // =4
    2298:      	mov	w1, #0x4                // =4
    229c:      	blr	x8
    22a0:      	add	x0, x24, #0xc
    22a4:      	add	x2, x22, #0x14
    22a8:      	mov	w8, #0x4                // =4
    22ac:      	mov	w1, #0x4                // =4
    22b0:      	blr	x8
    22b4:      	add	x0, x24, #0x18
    22b8:      	add	x2, x22, #0x20
    22bc:      	mov	w8, #0x4                // =4
    22c0:      	mov	w1, #0x4                // =4
    22c4:      	blr	x8
    22c8:      	add	x0, x24, #0x1c
    22cc:      	add	x2, x22, #0x24
    22d0:      	mov	w8, #0x4                // =4
    22d4:      	mov	w1, #0x4                // =4
    22d8:      	blr	x8
    22dc:      	str	wzr, [x24, #0x24]
    22e0:      	add	x0, x24, #0x20
    22e4:      	add	x2, x22, #0x28
    22e8:      	mov	w8, #0x4                // =4
    22ec:      	mov	w1, #0x4                // =4
    22f0:      	blr	x8
    22f4:      	add	x0, x24, #0x30
    22f8:      	add	x2, x22, #0x40
    22fc:      	mov	w25, #0x8               // =8
    2300:      	mov	w8, #0x4                // =4
    2304:      	mov	w1, #0x8                // =8
    2308:      	blr	x8
    230c:      	add	x0, x24, #0x38
    2310:      	add	x2, x22, #0x30
    2314:      	mov	w8, #0x4                // =4
    2318:      	mov	w1, #0x8                // =8
    231c:      	blr	x8
    2320:      	add	x2, x22, #0x38
    2324:      	mov	w8, #0x4                // =4
    2328:      	mov	x0, x23
    232c:      	mov	w1, #0x8                // =8
    2330:      	blr	x8
    2334:      	add	x2, x22, #0x90
    2338:      	add	x8, sp, #0x88
    233c:      	mov	w9, #0x4                // =4
    2340:      	add	x0, sp, #0x88
    2344:      	mov	w1, #0x8                // =8
    2348:      	blr	x9
    234c:      	ldr	x22, [sp, #0x88]
    2350:      	ldr	x0, [sp, #0x38]
    2354:      	mov	w8, #0x4                // =4
    2358:      	mov	w1, #0x4                // =4
    235c:      	add	x2, x22, #0xc8
    2360:      	blr	x8
    2364:      	add	x0, x24, #0x44
    2368:      	add	x2, x22, #0xcc
    236c:      	mov	w8, #0x4                // =4
    2370:      	mov	w1, #0x4                // =4
    2374:      	blr	x8
    2378:      	add	x0, x24, #0x48
    237c:      	add	x2, x22, #0xd0
    2380:      	mov	w8, #0x4                // =4
    2384:      	mov	w1, #0x4                // =4
    2388:      	blr	x8
    238c:      	add	x0, x24, #0x4c
    2390:      	add	x2, x22, #0x158
    2394:      	mov	w1, #0x4                // =4
    2398:      	blr	x29
    239c:      	mov	w9, #0x50               // =80
    23a0:      	mov	w25, #0x5efc            // =24316
    23a4:      	b	0x2a08 <generic_usdt_process_event+0x2078>
    23a8:      	ldr	x24, [sp, #0x18]
    23ac:      	add	x2, x22, #0xc8
    23b0:      	mov	w8, #0x4                // =4
    23b4:      	mov	w1, #0x4                // =4
    23b8:      	mov	w23, #0x4               // =4
    23bc:      	mov	x0, x24
    23c0:      	blr	x8
    23c4:      	add	x0, x24, #0x4
    23c8:      	add	x2, x22, #0xcc
    23cc:      	mov	w8, #0x4                // =4
    23d0:      	mov	w1, #0x4                // =4
    23d4:      	blr	x8
    23d8:      	add	x0, x24, #0x8
    23dc:      	add	x2, x22, #0xd0
    23e0:      	mov	w8, #0x4                // =4
    23e4:      	mov	w1, #0x4                // =4
    23e8:      	blr	x8
    23ec:      	add	x0, x24, #0xc
    23f0:      	add	x2, x22, #0x158
    23f4:      	mov	w1, #0x4                // =4
    23f8:      	blr	x23
    23fc:      	mov	w9, #0x10               // =16
    2400:      	b	0x2a08 <generic_usdt_process_event+0x2078>
    2404:      	ldr	x24, [sp, #0x18]
    2408:      	add	x2, x22, #0x38
    240c:      	mov	w8, #0x4                // =4
    2410:      	mov	w1, #0x4                // =4
    2414:      	mov	w23, #0x4               // =4
    2418:      	mov	x0, x24
    241c:      	blr	x8
    2420:      	add	x0, x24, #0x4
    2424:      	add	x2, x22, #0x3c
    2428:      	mov	w8, #0x4                // =4
    242c:      	mov	w1, #0x4                // =4
    2430:      	blr	x8
    2434:      	add	x0, x24, #0x8
    2438:      	add	x2, x22, #0x40
    243c:      	mov	w8, #0x4                // =4
    2440:      	mov	w1, #0x4                // =4
    2444:      	blr	x8
    2448:      	add	x0, x24, #0xc
    244c:      	add	x2, x22, #0x44
    2450:      	mov	w8, #0x4                // =4
    2454:      	mov	w1, #0x4                // =4
    2458:      	blr	x8
    245c:      	add	x0, x24, #0x10
    2460:      	add	x2, x22, #0x80
    2464:      	mov	w8, #0x10               // =16
    2468:      	mov	w1, #0x10               // =16
    246c:      	blr	x23
    2470:      	mov	w9, #0x20               // =32
    2474:      	b	0x2a08 <generic_usdt_process_event+0x2078>
    2478:      	ldr	x24, [sp, #0x18]
    247c:      	mov	w8, #0x4                // =4
    2480:      	mov	w1, #0x4                // =4
    2484:      	mov	x2, x22
    2488:      	mov	w23, #0x4               // =4
    248c:      	mov	x0, x24
    2490:      	blr	x8
    2494:      	add	x0, x24, #0x4
    2498:      	add	x2, x22, #0x4
    249c:      	mov	w8, #0x4                // =4
    24a0:      	mov	w1, #0x4                // =4
    24a4:      	blr	x8
    24a8:      	add	x0, x24, #0x8
    24ac:      	add	x2, x22, #0x30
    24b0:      	mov	w8, #0x10               // =16
    24b4:      	mov	w1, #0x10               // =16
    24b8:      	blr	x23
    24bc:      	mov	w9, #0x18               // =24
    24c0:      	b	0x2a08 <generic_usdt_process_event+0x2078>
    24c4:      	add	x2, x22, #0x4
    24c8:      	add	x8, sp, #0x88
    24cc:      	mov	w9, #0x4                // =4
    24d0:      	add	x0, sp, #0x88
    24d4:      	mov	w1, #0x4                // =4
    24d8:      	mov	w23, #0x4               // =4
    24dc:      	blr	x9
    24e0:      	ldr	w8, [sp, #0x88]
    24e4:      	ldr	x24, [sp, #0x18]
    24e8:      	add	x2, x22, #0xc
    24ec:      	add	x0, sp, #0x88
    24f0:      	mov	w1, #0x4                // =4
    24f4:      	str	w8, [x24]
    24f8:      	add	x8, sp, #0x88
    24fc:      	blr	x23
    2500:      	ldr	w8, [sp, #0x88]
    2504:      	add	x2, x22, #0x50
    2508:      	add	x9, sp, #0x88
    250c:      	mov	w10, #0x2d              // =45
    2510:      	str	w8, [x24, #0x4]
    2514:      	mov	w8, #0x8                // =8
    2518:      	add	x0, sp, #0x88
    251c:      	mov	w1, #0x8                // =8
    2520:      	mov	w22, #0x2d              // =45
    2524:      	blr	x10
    2528:      	ldr	x8, [sp, #0x88]
    252c:      	add	x0, x24, #0x8
    2530:      	mov	w9, #0x10               // =16
    2534:      	mov	w1, #0x10               // =16
    2538:      	add	x8, x8, #0x3f8
    253c:      	ldr	x8, [sp, #0x88]
    2540:      	add	x2, x8, #0x3f8
    2544:      	blr	x22
    2548:      	mov	w9, #0x18               // =24
    254c:      	b	0x2a08 <generic_usdt_process_event+0x2078>
    2550:      	ldr	x11, [sp, #0x18]
    2554:      	mov	w8, #0x8                // =8
    2558:      	mov	w9, #0x4                // =4
    255c:      	add	x10, sp, #0x88
    2560:      	stp	xzr, xzr, [x11, #0x40]
    2564:      	add	x0, sp, #0x88
    2568:      	stp	xzr, xzr, [x11, #0x30]
    256c:      	stp	xzr, xzr, [x11, #0x20]
    2570:      	mov	w1, #0x8                // =8
    2574:      	mov	x2, x22
    2578:      	stp	xzr, xzr, [x11, #0x10]
    257c:      	stp	xzr, xzr, [x11]
    2580:      	blr	x9
    2584:      	mov	x9, xzr
    2588:      	cbnz	x0, 0x38c8 <generic_usdt_process_event+0x2f38>
    258c:      	ldr	x8, [sp, #0x18]
    2590:      	mov	w9, #0x3f               // =63
    2594:      	mov	w10, #0x2d              // =45
    2598:      	mov	w1, #0x3f               // =63
    259c:      	add	x0, x8, #0x10
    25a0:      	ldr	x8, [sp, #0x88]
    25a4:      	ldr	x2, [sp, #0x88]
    25a8:      	blr	x10
    25ac:      	tbnz	x0, #0x3f, 0x2cc8 <generic_usdt_process_event+0x2338>
    25b0:      	add	x2, x22, #0x8
    25b4:      	mov	w23, #0x8               // =8
    25b8:      	add	x8, sp, #0xe0
    25bc:      	mov	w9, #0x4                // =4
    25c0:      	add	x0, sp, #0xe0
    25c4:      	mov	w1, #0x8                // =8
    25c8:      	mov	w24, #0x4               // =4
    25cc:      	blr	x9
    25d0:      	ldr	x8, [sp, #0x18]
    25d4:      	add	x10, sp, #0xd0
    25d8:      	mov	w9, #0x4                // =4
    25dc:      	mov	w1, #0x8                // =8
    25e0:      	add	x0, x8, #0x8
    25e4:      	ldr	x8, [x10, #0x10]
    25e8:      	add	x8, x8, #0x360
    25ec:      	ldr	x8, [x10, #0x10]
    25f0:      	add	x2, x8, #0x360
    25f4:      	blr	x9
    25f8:      	add	x2, x22, #0x58
    25fc:      	add	x8, sp, #0xe0
    2600:      	add	x0, sp, #0xe0
    2604:      	mov	w1, #0x4                // =4
    2608:      	blr	x24
    260c:      	cbnz	x0, 0x2624 <generic_usdt_process_event+0x1c94>
    2610:      	ldr	w8, [sp, #0xe0]
    2614:      	ldr	x9, [sp, #0x18]
    2618:      	cmp	w8, #0x0
    261c:      	cset	w8, ne
    2620:      	str	w8, [x9]
    2624:      	mov	w9, #0x50               // =80
    2628:      	b	0x38c8 <generic_usdt_process_event+0x2f38>
    262c:      	mov	x9, #-0x1               // =-1
    2630:      	b	0x38c8 <generic_usdt_process_event+0x2f38>
    2634:      	add	x2, x22, #0x10
    2638:      	mov	w25, #0x8               // =8
    263c:      	add	x8, sp, #0xf0
    2640:      	mov	w9, #0x4                // =4
    2644:      	add	x0, sp, #0xf0
    2648:      	mov	w1, #0x8                // =8
    264c:      	mov	w24, #0x4               // =4
    2650:      	blr	x9
    2654:      	add	x2, x22, #0x18
    2658:      	add	x8, sp, #0xd8
    265c:      	add	x0, sp, #0xd8
    2660:      	mov	w1, #0x8                // =8
    2664:      	blr	x24
    2668:      	add	x8, sp, #0xd0
    266c:      	ldr	x9, [sp, #0x30]
    2670:      	ldr	x21, [x8, #0x20]
    2674:      	ldr	x22, [x8, #0x8]
    2678:      	add	x8, x23, #0x90
    267c:      	add	x29, x8, x29
    2680:      	tbz	w9, #0x5, 0x2c84 <generic_usdt_process_event+0x22f4>
    2684:      	cmp	x22, #0x1, lsl #12      // =0x1000
    2688:      	b.lo	0x2c6c <generic_usdt_process_event+0x22dc>
    268c:      	mov	w8, #0x1                // =1
    2690:      	adrp	x0, 0x2000 <generic_usdt_process_event+0x1670>
    2694:      	add	x9, sp, #0x80
    2698:      	str	w8, [x29]
    269c:      	str	wzr, [sp, #0x80]
    26a0:      	add	x1, sp, #0x80
    26a4:      	ldr	x0, [x0]
    26a8:      	blr	x8
    26ac:      	cbz	x0, 0x3170 <generic_usdt_process_event+0x27e0>
    26b0:      	mov	w8, #0x18               // =24
    26b4:      	mov	x24, x0
    26b8:      	str	w8, [x0]
    26bc:      	mov	w8, #0xe                // =14
    26c0:      	blr	x8
    26c4:      	mov	x23, x24
    26c8:      	cmn	x0, #0x16
    26cc:      	str	x0, [x23, #0x10]!
    26d0:      	b.ne	0x26f8 <generic_usdt_process_event+0x1d68>
    26d4:      	add	x2, x19, #0xe8
    26d8:      	mov	w8, #0x8                // =8
    26dc:      	mov	w9, #0x4                // =4
    26e0:      	add	x10, sp, #0x88
    26e4:      	add	x0, sp, #0x88
    26e8:      	mov	w1, #0x8                // =8
    26ec:      	blr	x9
    26f0:      	ldr	x8, [sp, #0x88]
    26f4:      	str	x8, [x23]
    26f8:      	mov	w8, #0x7d               // =125
    26fc:      	blr	x8
    2700:      	str	x0, [x24, #0x18]
    2704:      	mov	x0, x19
    2708:      	mov	x1, x24
    270c:      	mov	x2, x21
    2710:      	ldp	x8, x9, [x23]
    2714:      	mov	x3, x22
    2718:      	stur	x9, [x29, #0x1c]
    271c:      	stur	x8, [x29, #0x14]
    2720:      	bl	0x2720 <generic_usdt_process_event+0x1d90>
    2724:      	tbnz	w0, #0x1f, 0x2ed0 <generic_usdt_process_event+0x2540>
    2728:      	stur	xzr, [x29, #0x4]
    272c:      	sub	w8, w22, w0
    2730:      	cmn	x22, #0x1
    2734:      	csel	w8, wzr, w8, eq
    2738:      	b	0x2edc <generic_usdt_process_event+0x254c>
    273c:      	str	wzr, [sp, #0xe0]
    2740:      	adrp	x0, 0x2000 <generic_usdt_process_event+0x1670>
    2744:      	ldr	x25, [sp, #0x88]
    2748:      	mov	w8, #0x1                // =1
    274c:      	add	x9, sp, #0xe0
    2750:      	add	x1, sp, #0xe0
    2754:      	ldrh	w22, [sp, #0xd8]
    2758:      	ldr	x0, [x0]
    275c:      	add	x21, x25, x22
    2760:      	blr	x8
    2764:      	cbz	x0, 0x3744 <generic_usdt_process_event+0x2db4>
    2768:      	mov	w8, #0xff               // =255
    276c:      	strh	w22, [x0]
    2770:      	strb	wzr, [x0, #0x7]
    2774:      	add	x22, x0, #0x6
    2778:      	add	x2, x21, #0x6
    277c:      	mov	w9, #0x4                // =4
    2780:      	strb	w8, [x0, #0x5]
    2784:      	mov	w8, #0x1                // =1
    2788:      	mov	x23, x0
    278c:      	mov	x0, x22
    2790:      	mov	w1, #0x1                // =1
    2794:      	blr	x9
    2798:      	tbnz	x0, #0x3f, 0x3744 <generic_usdt_process_event+0x2db4>
    279c:      	ldrb	w8, [x23, #0x5]
    27a0:      	cmp	w8, #0x32
    27a4:      	b.gt	0x2cd0 <generic_usdt_process_event+0x2340>
    27a8:      	cbz	w8, 0x2d48 <generic_usdt_process_event+0x23b8>
    27ac:      	cmp	w8, #0x2b
    27b0:      	b.eq	0x2d48 <generic_usdt_process_event+0x23b8>
    27b4:      	cmp	w8, #0x2c
    27b8:      	b.ne	0x3238 <generic_usdt_process_event+0x28a8>
    27bc:      	mov	w8, #0x8                // =8
    27c0:      	b	0x3184 <generic_usdt_process_event+0x27f4>
    27c4:      	ldr	x0, [sp, #0x18]
    27c8:      	add	x2, x23, #0x48
    27cc:      	mov	w24, #0x10              // =16
    27d0:      	mov	w8, #0x4                // =4
    27d4:      	mov	w1, #0x10               // =16
    27d8:      	mov	w25, #0x4               // =4
    27dc:      	blr	x8
    27e0:      	add	x2, x23, #0x38
    27e4:      	mov	x0, x22
    27e8:      	mov	w1, #0x10               // =16
    27ec:      	blr	x25
    27f0:      	ldr	x25, [sp, #0x18]
    27f4:      	add	x22, x23, #0xc
    27f8:      	add	x2, x23, #0xe
    27fc:      	mov	w23, #0x2               // =2
    2800:      	mov	w8, #0x4                // =4
    2804:      	mov	w1, #0x2                // =2
    2808:      	mov	w24, #0x4               // =4
    280c:      	add	x0, x25, #0x20
    2810:      	blr	x8
    2814:      	add	x0, x25, #0x22
    2818:      	mov	w1, #0x2                // =2
    281c:      	mov	x2, x22
    2820:      	blr	x24
    2824:      	ldrh	w8, [x25, #0x22]
    2828:      	adrp	x0, 0x2000 <generic_usdt_process_event+0x1670>
    282c:      	add	x9, sp, #0x88
    2830:      	add	x1, sp, #0x88
    2834:      	rev	w8, w8
    2838:      	lsr	w8, w8, #16
    283c:      	strh	w8, [x25, #0x22]
    2840:      	ldr	x8, [x29]
    2844:      	str	x8, [sp, #0x88]
    2848:      	mov	w8, #0x1                // =1
    284c:      	ldr	x0, [x0]
    2850:      	blr	x8
    2854:      	cbz	x0, 0x38c4 <generic_usdt_process_event+0x2f34>
    2858:      	ldr	w8, [x0]
    285c:      	ldr	x29, [sp, #0x38]
    2860:      	str	w8, [x29, #0x10]
    2864:      	ldr	x8, [x0, #0x8]
    2868:      	str	x8, [x29, #0x18]
    286c:      	ldr	w8, [x0, #0x4]
    2870:      	str	w8, [x29, #0x7c]
    2874:      	b	0x38c4 <generic_usdt_process_event+0x2f34>
    2878:      	add	x8, x23, x29
    287c:      	mov	w9, #0x8                // =8
    2880:      	mov	w25, #0x5efc            // =24316
    2884:      	str	xzr, [x8, #0x90]
    2888:      	b	0x38cc <generic_usdt_process_event+0x2f3c>
    288c:      	mov	w8, #0xe                // =14
    2890:      	blr	x8
    2894:      	cmn	x0, #0x16
    2898:      	b.ne	0x28bc <generic_usdt_process_event+0x1f2c>
    289c:      	add	x2, x19, #0xe8
    28a0:      	mov	w8, #0x8                // =8
    28a4:      	mov	w9, #0x4                // =4
    28a8:      	add	x10, sp, #0x88
    28ac:      	add	x0, sp, #0x88
    28b0:      	mov	w1, #0x8                // =8
    28b4:      	blr	x9
    28b8:      	ldr	x0, [sp, #0x88]
    28bc:      	ldr	x9, [x23, #0x8]
    28c0:      	ldr	x8, [x23, #0x60]
    28c4:      	mov	x3, xzr
    28c8:      	add	x10, sp, #0x88
    28cc:      	add	x1, sp, #0xe0
    28d0:      	add	x2, sp, #0x88
    28d4:      	str	xzr, [sp, #0x98]
    28d8:      	add	x21, sp, #0xd0
    28dc:      	stp	x9, x22, [sp, #0x88]
    28e0:      	add	x9, sp, #0xd0
    28e4:      	stp	x8, x0, [x9, #0x10]
    28e8:      	adrp	x0, 0x2000 <generic_usdt_process_event+0x1670>
    28ec:      	mov	w8, #0x2                // =2
    28f0:      	add	x9, sp, #0xe0
    28f4:      	ldr	x0, [x0]
    28f8:      	blr	x8
    28fc:      	cbz	x0, 0x2d14 <generic_usdt_process_event+0x2384>
    2900:      	neg	w8, w0
    2904:      	adrp	x22, 0x2000 <generic_usdt_process_event+0x1670>
    2908:      	mov	w9, #0x1                // =1
    290c:      	strh	w8, [sp, #0xf0]
    2910:      	mov	w8, #0x5                // =5
    2914:      	add	x1, sp, #0xf0
    2918:      	mov	w23, #0x1               // =1
    291c:      	strh	w8, [sp, #0xf2]
    2920:      	mov	x8, #0x46               // =70
    2924:      	movk	x8, #0x2, lsl #32
    2928:      	stur	x8, [x21, #0x24]
    292c:      	add	x8, sp, #0xf0
    2930:      	ldr	x22, [x22]
    2934:      	mov	x0, x22
    2938:      	blr	x9
    293c:      	cbz	x0, 0x2cf0 <generic_usdt_process_event+0x2360>
    2940:      	ldr	w8, [x0]
    2944:      	add	w8, w8, #0x1
    2948:      	str	w8, [x0]
    294c:      	b	0x2d14 <generic_usdt_process_event+0x2384>
    2950:      	cmp	w8, #0x1
    2954:      	b.eq	0x2af0 <generic_usdt_process_event+0x2160>
    2958:      	cmp	w8, #0x2
    295c:      	b.ne	0x2b3c <generic_usdt_process_event+0x21ac>
    2960:      	mov	w8, #0x5e58             // =24152
    2964:      	b	0x2af4 <generic_usdt_process_event+0x2164>
    2968:      	ldr	x24, [sp, #0x18]
    296c:      	add	x2, x22, #0x8
    2970:      	mov	w8, #0x10               // =16
    2974:      	mov	w9, #0x4                // =4
    2978:      	mov	w1, #0x10               // =16
    297c:      	mov	w23, #0x4               // =4
    2980:      	add	x0, x24, #0x8
    2984:      	blr	x9
    2988:      	add	x0, x24, #0x2
    298c:      	add	x2, x22, #0x2
    2990:      	mov	w8, #0x2                // =2
    2994:      	mov	w1, #0x2                // =2
    2998:      	blr	x23
    299c:      	ldr	x9, [sp, #0x18]
    29a0:      	mov	w25, #0x5efc            // =24316
    29a4:      	ldrh	w8, [x9, #0x2]
    29a8:      	rev	w8, w8
    29ac:      	lsr	w8, w8, #16
    29b0:      	strh	w8, [x9, #0x2]
    29b4:      	mov	w9, #0x18               // =24
    29b8:      	b	0x38cc <generic_usdt_process_event+0x2f3c>
    29bc:      	mov	x9, xzr
    29c0:      	adrp	x21, 0x2000 <generic_usdt_process_event+0x1670>
    29c4:      	mov	w25, #0x5efc            // =24316
    29c8:      	mov	w10, #0x5ea0            // =24224
    29cc:      	ldr	x21, [x21]
    29d0:      	mov	x11, x23
    29d4:      	b	0x38dc <generic_usdt_process_event+0x2f4c>
    29d8:      	add	x2, x22, #0x3
    29dc:      	mov	w22, #0x6b              // =107
    29e0:      	mov	w8, #0x71               // =113
    29e4:      	mov	w1, #0x6b               // =107
    29e8:      	blr	x8
    29ec:      	adrp	x21, 0x2000 <generic_usdt_process_event+0x1670>
    29f0:      	mov	w25, #0x5efc            // =24316
    29f4:      	ldr	x21, [x21]
    29f8:      	tbnz	w0, #0x1f, 0x2a04 <generic_usdt_process_event+0x2074>
    29fc:      	ldr	x8, [sp, #0x18]
    2a00:      	strb	w22, [x8, #0x3]
    2a04:      	mov	w9, #0x70               // =112
    2a08:      	ldr	x11, [sp, #0x20]
    2a0c:      	mov	w10, #0x5ea0            // =24224
    2a10:      	b	0x38dc <generic_usdt_process_event+0x2f4c>
    2a14:      	cmp	w9, #0x1
    2a18:      	b.eq	0x2d64 <generic_usdt_process_event+0x23d4>
    2a1c:      	cmp	w9, #0x2
    2a20:      	b.ne	0x2d70 <generic_usdt_process_event+0x23e0>
    2a24:      	mov	w8, #0x5e58             // =24152
    2a28:      	b	0x2d68 <generic_usdt_process_event+0x23d8>
    2a2c:      	ldr	x0, [sp, #0x18]
    2a30:      	add	x2, x23, #0x48
    2a34:      	mov	w24, #0x10              // =16
    2a38:      	mov	w8, #0x4                // =4
    2a3c:      	mov	w1, #0x10               // =16
    2a40:      	mov	w25, #0x4               // =4
    2a44:      	blr	x8
    2a48:      	add	x2, x23, #0x38
    2a4c:      	mov	x0, x22
    2a50:      	mov	w1, #0x10               // =16
    2a54:      	blr	x25
    2a58:      	ldr	x25, [sp, #0x18]
    2a5c:      	add	x22, x23, #0xc
    2a60:      	add	x2, x23, #0xe
    2a64:      	mov	w23, #0x2               // =2
    2a68:      	mov	w8, #0x4                // =4
    2a6c:      	mov	w1, #0x2                // =2
    2a70:      	mov	w24, #0x4               // =4
    2a74:      	add	x0, x25, #0x20
    2a78:      	blr	x8
    2a7c:      	add	x0, x25, #0x22
    2a80:      	mov	w1, #0x2                // =2
    2a84:      	mov	x2, x22
    2a88:      	blr	x24
    2a8c:      	ldrh	w8, [x25, #0x22]
    2a90:      	rev	w8, w8
    2a94:      	lsr	w8, w8, #16
    2a98:      	strh	w8, [x25, #0x22]
    2a9c:      	ldr	x8, [sp, #0x18]
    2aa0:      	adrp	x0, 0x2000 <generic_usdt_process_event+0x1670>
    2aa4:      	add	x9, sp, #0x88
    2aa8:      	add	x1, sp, #0x88
    2aac:      	ldr	x8, [x8, #0x28]
    2ab0:      	str	x8, [sp, #0x88]
    2ab4:      	mov	w8, #0x1                // =1
    2ab8:      	ldr	x0, [x0]
    2abc:      	blr	x8
    2ac0:      	cbz	x0, 0x38c4 <generic_usdt_process_event+0x2f34>
    2ac4:      	ldr	w8, [x0]
    2ac8:      	str	w8, [x29, #0x10]
    2acc:      	ldr	x8, [x0, #0x8]
    2ad0:      	str	x8, [x29, #0x18]
    2ad4:      	ldr	w8, [x0, #0x4]
    2ad8:      	str	w8, [x29, #0x7c]
    2adc:      	b	0x38c4 <generic_usdt_process_event+0x2f34>
    2ae0:      	mov	w8, #0x5e60             // =24160
    2ae4:      	b	0x2af4 <generic_usdt_process_event+0x2164>
    2ae8:      	mov	w8, #0x5e68             // =24168
    2aec:      	b	0x2af4 <generic_usdt_process_event+0x2164>
    2af0:      	mov	w8, #0x5e50             // =24144
    2af4:      	add	x8, x23, x8
    2af8:      	ldr	x24, [x8]
    2afc:      	ldr	x8, [sp, #0x30]
    2b00:      	tbnz	w8, #0x4, 0x2b4c <generic_usdt_process_event+0x21bc>
    2b04:      	cbz	x24, 0x2c14 <generic_usdt_process_event+0x2284>
    2b08:      	mov	w8, #0x10               // =16
    2b0c:      	mov	w9, #0x4                // =4
    2b10:      	add	x10, sp, #0x88
    2b14:      	add	x0, sp, #0x88
    2b18:      	mov	w1, #0x10               // =16
    2b1c:      	mov	x2, x22
    2b20:      	blr	x9
    2b24:      	tbnz	w0, #0x1f, 0x3168 <generic_usdt_process_event+0x27d8>
    2b28:      	ldr	x29, [sp, #0x90]
    2b2c:      	cmp	x29, #0xffe
    2b30:      	b.ls	0x2ee8 <generic_usdt_process_event+0x2558>
    2b34:      	mov	w8, #-0x3               // =-3
    2b38:      	b	0x316c <generic_usdt_process_event+0x27dc>
    2b3c:      	ldr	x8, [sp, #0x30]
    2b40:      	mov	x24, xzr
    2b44:      	mov	x29, xzr
    2b48:      	tbz	w8, #0x4, 0x2c18 <generic_usdt_process_event+0x2288>
    2b4c:      	mov	w8, #0xe                // =14
    2b50:      	blr	x8
    2b54:      	cmn	x0, #0x16
    2b58:      	b.ne	0x2b7c <generic_usdt_process_event+0x21ec>
    2b5c:      	add	x2, x19, #0xe8
    2b60:      	mov	w8, #0x8                // =8
    2b64:      	mov	w9, #0x4                // =4
    2b68:      	add	x10, sp, #0x88
    2b6c:      	add	x0, sp, #0x88
    2b70:      	mov	w1, #0x8                // =8
    2b74:      	blr	x9
    2b78:      	ldr	x0, [sp, #0x88]
    2b7c:      	ldr	x9, [x23, #0x8]
    2b80:      	ldr	x8, [x23, #0x60]
    2b84:      	mov	x3, xzr
    2b88:      	add	x10, sp, #0x88
    2b8c:      	add	x1, sp, #0xe0
    2b90:      	add	x2, sp, #0x88
    2b94:      	str	x24, [sp, #0x98]
    2b98:      	add	x21, sp, #0xd0
    2b9c:      	stp	x9, x22, [sp, #0x88]
    2ba0:      	add	x9, sp, #0xd0
    2ba4:      	stp	x8, x0, [x9, #0x10]
    2ba8:      	adrp	x0, 0x2000 <generic_usdt_process_event+0x1670>
    2bac:      	mov	w8, #0x2                // =2
    2bb0:      	add	x9, sp, #0xe0
    2bb4:      	ldr	x0, [x0]
    2bb8:      	blr	x8
    2bbc:      	cbz	x0, 0x2d40 <generic_usdt_process_event+0x23b0>
    2bc0:      	neg	w8, w0
    2bc4:      	adrp	x22, 0x2000 <generic_usdt_process_event+0x1670>
    2bc8:      	mov	w9, #0x1                // =1
    2bcc:      	strh	w8, [sp, #0xf0]
    2bd0:      	mov	w8, #0x5                // =5
    2bd4:      	add	x1, sp, #0xf0
    2bd8:      	mov	w23, #0x1               // =1
    2bdc:      	strh	w8, [sp, #0xf2]
    2be0:      	mov	x8, #0x57               // =87
    2be4:      	movk	x8, #0x2, lsl #32
    2be8:      	stur	x8, [x21, #0x24]
    2bec:      	add	x8, sp, #0xf0
    2bf0:      	ldr	x22, [x22]
    2bf4:      	mov	x0, x22
    2bf8:      	blr	x9
    2bfc:      	cbz	x0, 0x2d1c <generic_usdt_process_event+0x238c>
    2c00:      	ldr	w8, [x0]
    2c04:      	add	w8, w8, #0x1
    2c08:      	str	w8, [x0]
    2c0c:      	mov	w8, #-0x4               // =-4
    2c10:      	b	0x316c <generic_usdt_process_event+0x27dc>
    2c14:      	mov	x29, xzr
    2c18:      	stp	w29, w29, [x25]
    2c1c:      	add	x9, x29, #0x8
    2c20:      	b	0x38c8 <generic_usdt_process_event+0x2f38>
    2c24:      	ldr	x9, [sp, #0x108]
    2c28:      	str	wzr, [x29]
    2c2c:      	mov	w22, #0xc               // =12
    2c30:      	add	w9, w9, #0x8
    2c34:      	and	x9, x9, #0x3fff
    2c38:      	add	x29, x8, x9
    2c3c:      	cmp	x21, #0xfff
    2c40:      	mov	w8, #0xfff              // =4095
    2c44:      	add	x0, x29, #0x8
    2c48:      	mov	x2, x25
    2c4c:      	csel	x24, x21, x8, lo
    2c50:      	mov	w8, #0x4                // =4
    2c54:      	mov	w1, w24
    2c58:      	blr	x8
    2c5c:      	tbnz	w0, #0x1f, 0x2cb4 <generic_usdt_process_event+0x2324>
    2c60:      	stp	w21, w24, [x29]
    2c64:      	add	x9, x22, x24
    2c68:      	b	0x38c8 <generic_usdt_process_event+0x2f38>
    2c6c:      	ldr	x9, [sp, #0x108]
    2c70:      	str	wzr, [x29]
    2c74:      	mov	w25, #0xc               // =12
    2c78:      	add	w9, w9, #0x8
    2c7c:      	and	x9, x9, #0x3fff
    2c80:      	add	x29, x8, x9
    2c84:      	cmp	x22, #0xfff
    2c88:      	mov	w8, #0xfff              // =4095
    2c8c:      	add	x0, x29, #0x8
    2c90:      	mov	x2, x21
    2c94:      	csel	x24, x22, x8, lo
    2c98:      	mov	w8, #0x4                // =4
    2c9c:      	mov	w1, w24
    2ca0:      	blr	x8
    2ca4:      	tbnz	w0, #0x1f, 0x2cb4 <generic_usdt_process_event+0x2324>
    2ca8:      	stp	w22, w24, [x29]
    2cac:      	add	x9, x25, x24
    2cb0:      	b	0x38c8 <generic_usdt_process_event+0x2f38>
    2cb4:      	mov	w8, #-0x2               // =-2
    2cb8:      	mov	w9, #0x4                // =4
    2cbc:      	mov	w25, #0x5efc            // =24316
    2cc0:      	str	w8, [x29]
    2cc4:      	b	0x38cc <generic_usdt_process_event+0x2f3c>
    2cc8:      	mov	x9, xzr
    2ccc:      	b	0x38c8 <generic_usdt_process_event+0x2f38>
    2cd0:      	cmp	w8, #0x33
    2cd4:      	b.eq	0x3178 <generic_usdt_process_event+0x27e8>
    2cd8:      	cmp	w8, #0x3c
    2cdc:      	b.eq	0x2d48 <generic_usdt_process_event+0x23b8>
    2ce0:      	cmp	w8, #0xff
    2ce4:      	b.ne	0x3238 <generic_usdt_process_event+0x28a8>
    2ce8:      	mov	w8, #0x28               // =40
    2cec:      	b	0x3184 <generic_usdt_process_event+0x27f4>
    2cf0:      	str	w23, [sp, #0x80]
    2cf4:      	mov	x3, xzr
    2cf8:      	mov	w8, #0x2                // =2
    2cfc:      	add	x9, sp, #0xf0
    2d00:      	add	x10, sp, #0x80
    2d04:      	add	x1, sp, #0xf0
    2d08:      	add	x2, sp, #0x80
    2d0c:      	mov	x0, x22
    2d10:      	blr	x8
    2d14:      	mov	w8, #-0x4               // =-4
    2d18:      	b	0x2ec4 <generic_usdt_process_event+0x2534>
    2d1c:      	str	w23, [sp, #0xd8]
    2d20:      	mov	x3, xzr
    2d24:      	mov	w8, #0x2                // =2
    2d28:      	add	x9, sp, #0xf0
    2d2c:      	add	x10, sp, #0xd8
    2d30:      	add	x1, sp, #0xf0
    2d34:      	add	x2, sp, #0xd8
    2d38:      	mov	x0, x22
    2d3c:      	blr	x8
    2d40:      	mov	w8, #-0x4               // =-4
    2d44:      	b	0x316c <generic_usdt_process_event+0x27dc>
    2d48:      	ldrb	w8, [x23, #0x7]
    2d4c:      	lsl	w8, w8, #3
    2d50:      	b	0x3180 <generic_usdt_process_event+0x27f0>
    2d54:      	mov	w8, #0x5e60             // =24160
    2d58:      	b	0x2d68 <generic_usdt_process_event+0x23d8>
    2d5c:      	mov	w8, #0x5e68             // =24168
    2d60:      	b	0x2d68 <generic_usdt_process_event+0x23d8>
    2d64:      	mov	w8, #0x5e50             // =24144
    2d68:      	add	x8, x23, x8
    2d6c:      	ldr	x8, [x8]
    2d70:      	add	x21, sp, #0xd0
    2d74:      	mov	w25, #0x8               // =8
    2d78:      	add	x9, sp, #0xd0
    2d7c:      	str	x8, [x21, #0x8]
    2d80:      	mov	w8, #0x4                // =4
    2d84:      	add	x10, sp, #0xd8
    2d88:      	add	x0, sp, #0xd0
    2d8c:      	add	x2, sp, #0xd8
    2d90:      	mov	w1, #0x8                // =8
    2d94:      	blr	x8
    2d98:      	ldr	x23, [x21]
    2d9c:      	tbz	w29, #0x5, 0x2e84 <generic_usdt_process_event+0x24f4>
    2da0:      	cmp	x23, #0x1, lsl #12      // =0x1000
    2da4:      	b.lo	0x2e64 <generic_usdt_process_event+0x24d4>
    2da8:      	ldr	x9, [sp, #0x30]
    2dac:      	mov	w8, #0x1                // =1
    2db0:      	adrp	x0, 0x2000 <generic_usdt_process_event+0x1670>
    2db4:      	add	x1, sp, #0xe0
    2db8:      	str	w8, [x9]
    2dbc:      	str	wzr, [sp, #0xe0]
    2dc0:      	add	x9, sp, #0xe0
    2dc4:      	ldr	x0, [x0]
    2dc8:      	blr	x8
    2dcc:      	cbz	x0, 0x3170 <generic_usdt_process_event+0x27e0>
    2dd0:      	mov	w8, #0x18               // =24
    2dd4:      	mov	x24, x0
    2dd8:      	str	w8, [x0]
    2ddc:      	mov	w8, #0xe                // =14
    2de0:      	blr	x8
    2de4:      	mov	x25, x24
    2de8:      	cmn	x0, #0x16
    2dec:      	str	x0, [x25, #0x10]!
    2df0:      	b.ne	0x2e18 <generic_usdt_process_event+0x2488>
    2df4:      	add	x2, x19, #0xe8
    2df8:      	mov	w8, #0x8                // =8
    2dfc:      	mov	w9, #0x4                // =4
    2e00:      	add	x10, sp, #0x88
    2e04:      	add	x0, sp, #0x88
    2e08:      	mov	w1, #0x8                // =8
    2e0c:      	blr	x9
    2e10:      	ldr	x8, [sp, #0x88]
    2e14:      	str	x8, [x25]
    2e18:      	mov	w8, #0x7d               // =125
    2e1c:      	blr	x8
    2e20:      	str	x0, [x24, #0x18]
    2e24:      	ldr	x10, [sp, #0x30]
    2e28:      	mov	x0, x19
    2e2c:      	mov	x1, x24
    2e30:      	mov	x2, x22
    2e34:      	mov	x3, x23
    2e38:      	ldp	x8, x9, [x25]
    2e3c:      	stur	x9, [x10, #0x1c]
    2e40:      	stur	x8, [x10, #0x14]
    2e44:      	bl	0x2e44 <generic_usdt_process_event+0x24b4>
    2e48:      	tbnz	w0, #0x1f, 0x325c <generic_usdt_process_event+0x28cc>
    2e4c:      	ldr	x8, [sp, #0x30]
    2e50:      	cmn	x23, #0x1
    2e54:      	stur	xzr, [x8, #0x4]
    2e58:      	sub	w8, w23, w0
    2e5c:      	csel	w8, wzr, w8, eq
    2e60:      	b	0x326c <generic_usdt_process_event+0x28dc>
    2e64:      	ldr	x8, [sp, #0x30]
    2e68:      	mov	w25, #0xc               // =12
    2e6c:      	str	wzr, [x8]
    2e70:      	ldr	x8, [sp, #0x108]
    2e74:      	add	w8, w8, #0x8
    2e78:      	and	x8, x8, #0x3fff
    2e7c:      	add	x8, x24, x8
    2e80:      	str	x8, [sp, #0x30]
    2e84:      	cmp	x23, #0xfff
    2e88:      	mov	w8, #0xfff              // =4095
    2e8c:      	mov	x2, x22
    2e90:      	csel	x24, x23, x8, lo
    2e94:      	ldr	x8, [sp, #0x30]
    2e98:      	mov	w1, w24
    2e9c:      	add	x0, x8, #0x8
    2ea0:      	mov	w8, #0x4                // =4
    2ea4:      	blr	x8
    2ea8:      	tbnz	w0, #0x1f, 0x2ec0 <generic_usdt_process_event+0x2530>
    2eac:      	ldr	x8, [sp, #0x30]
    2eb0:      	add	x9, x25, x24
    2eb4:      	mov	w25, #0x5efc            // =24316
    2eb8:      	stp	w23, w24, [x8]
    2ebc:      	b	0x38cc <generic_usdt_process_event+0x2f3c>
    2ec0:      	mov	w8, #-0x2               // =-2
    2ec4:      	ldr	x9, [sp, #0x30]
    2ec8:      	str	w8, [x9]
    2ecc:      	b	0x3170 <generic_usdt_process_event+0x27e0>
    2ed0:      	mov	w8, wzr
    2ed4:      	stp	w0, wzr, [x29, #0x4]
    2ed8:      	mov	w0, wzr
    2edc:      	stp	w8, w0, [x29, #0xc]
    2ee0:      	mov	w9, #0x24               // =36
    2ee4:      	b	0x38c8 <generic_usdt_process_event+0x2f38>
    2ee8:      	ldr	x8, [sp, #0x108]
    2eec:      	mov	w9, #0x4                // =4
    2ef0:      	mov	w1, w29
    2ef4:      	add	x23, x8, #0xc
    2ef8:      	and	x8, x23, #0x3fff
    2efc:      	add	x0, x21, x8
    2f00:      	ldr	x8, [sp, #0x88]
    2f04:      	ldr	x2, [sp, #0x88]
    2f08:      	blr	x9
    2f0c:      	tbnz	w0, #0x1f, 0x3168 <generic_usdt_process_event+0x27d8>
    2f10:      	cmp	x24, #0x1
    2f14:      	b.eq	0x2c18 <generic_usdt_process_event+0x2288>
    2f18:      	add	x2, x22, #0x10
    2f1c:      	mov	w8, #0x10               // =16
    2f20:      	mov	w9, #0x4                // =4
    2f24:      	add	x10, sp, #0x88
    2f28:      	add	x0, sp, #0x88
    2f2c:      	mov	w1, #0x10               // =16
    2f30:      	blr	x9
    2f34:      	tbnz	w0, #0x1f, 0x3168 <generic_usdt_process_event+0x27d8>
    2f38:      	ldr	x8, [sp, #0x90]
    2f3c:      	cmp	x8, #0xffe
    2f40:      	str	x8, [sp, #0x38]
    2f44:      	b.hi	0x2b34 <generic_usdt_process_event+0x21a4>
    2f48:      	add	x23, x29, x23
    2f4c:      	mov	w9, #0x4                // =4
    2f50:      	ldr	x1, [sp, #0x38]
    2f54:      	and	x8, x23, #0x3fff
    2f58:      	add	x0, x21, x8
    2f5c:      	ldr	x8, [sp, #0x88]
    2f60:      	ldr	x2, [sp, #0x88]
    2f64:      	blr	x9
    2f68:      	tbnz	w0, #0x1f, 0x3168 <generic_usdt_process_event+0x27d8>
    2f6c:      	ldr	x8, [sp, #0x38]
    2f70:      	cmp	x24, #0x3
    2f74:      	add	x29, x8, x29
    2f78:      	b.lo	0x2c18 <generic_usdt_process_event+0x2288>
    2f7c:      	add	x2, x22, #0x20
    2f80:      	mov	w8, #0x10               // =16
    2f84:      	mov	w9, #0x4                // =4
    2f88:      	add	x10, sp, #0x88
    2f8c:      	add	x0, sp, #0x88
    2f90:      	mov	w1, #0x10               // =16
    2f94:      	blr	x9
    2f98:      	tbnz	w0, #0x1f, 0x3168 <generic_usdt_process_event+0x27d8>
    2f9c:      	ldr	x8, [sp, #0x90]
    2fa0:      	cmp	x8, #0xffe
    2fa4:      	str	x8, [sp, #0x30]
    2fa8:      	b.hi	0x2b34 <generic_usdt_process_event+0x21a4>
    2fac:      	ldp	x1, x8, [sp, #0x30]
    2fb0:      	mov	w9, #0x4                // =4
    2fb4:      	add	x23, x8, x23
    2fb8:      	and	x8, x23, #0x3fff
    2fbc:      	add	x0, x21, x8
    2fc0:      	ldr	x8, [sp, #0x88]
    2fc4:      	ldr	x2, [sp, #0x88]
    2fc8:      	blr	x9
    2fcc:      	tbnz	w0, #0x1f, 0x3168 <generic_usdt_process_event+0x27d8>
    2fd0:      	ldr	x8, [sp, #0x30]
    2fd4:      	cmp	x24, #0x3
    2fd8:      	add	x29, x8, x29
    2fdc:      	b.eq	0x2c18 <generic_usdt_process_event+0x2288>
    2fe0:      	add	x2, x22, #0x30
    2fe4:      	mov	w8, #0x10               // =16
    2fe8:      	mov	w9, #0x4                // =4
    2fec:      	add	x10, sp, #0x88
    2ff0:      	add	x0, sp, #0x88
    2ff4:      	mov	w1, #0x10               // =16
    2ff8:      	blr	x9
    2ffc:      	tbnz	w0, #0x1f, 0x3168 <generic_usdt_process_event+0x27d8>
    3000:      	ldr	x8, [sp, #0x90]
    3004:      	cmp	x8, #0xffe
    3008:      	str	x8, [sp, #0x38]
    300c:      	b.hi	0x2b34 <generic_usdt_process_event+0x21a4>
    3010:      	ldp	x8, x1, [sp, #0x30]
    3014:      	mov	w9, #0x4                // =4
    3018:      	add	x23, x8, x23
    301c:      	and	x8, x23, #0x3fff
    3020:      	add	x0, x21, x8
    3024:      	ldr	x8, [sp, #0x88]
    3028:      	ldr	x2, [sp, #0x88]
    302c:      	blr	x9
    3030:      	tbnz	w0, #0x1f, 0x3168 <generic_usdt_process_event+0x27d8>
    3034:      	ldr	x8, [sp, #0x38]
    3038:      	cmp	x24, #0x5
    303c:      	add	x29, x8, x29
    3040:      	b.lo	0x2c18 <generic_usdt_process_event+0x2288>
    3044:      	add	x2, x22, #0x40
    3048:      	mov	w8, #0x10               // =16
    304c:      	mov	w9, #0x4                // =4
    3050:      	add	x10, sp, #0x88
    3054:      	add	x0, sp, #0x88
    3058:      	mov	w1, #0x10               // =16
    305c:      	blr	x9
    3060:      	tbnz	w0, #0x1f, 0x3168 <generic_usdt_process_event+0x27d8>
    3064:      	ldr	x8, [sp, #0x90]
    3068:      	cmp	x8, #0xffe
    306c:      	str	x8, [sp, #0x30]
    3070:      	b.hi	0x2b34 <generic_usdt_process_event+0x21a4>
    3074:      	ldp	x1, x8, [sp, #0x30]
    3078:      	mov	w9, #0x4                // =4
    307c:      	add	x23, x8, x23
    3080:      	and	x8, x23, #0x3fff
    3084:      	add	x0, x21, x8
    3088:      	ldr	x8, [sp, #0x88]
    308c:      	ldr	x2, [sp, #0x88]
    3090:      	blr	x9
    3094:      	tbnz	w0, #0x1f, 0x3168 <generic_usdt_process_event+0x27d8>
    3098:      	ldr	x8, [sp, #0x30]
    309c:      	cmp	x24, #0x5
    30a0:      	add	x29, x8, x29
    30a4:      	b.eq	0x2c18 <generic_usdt_process_event+0x2288>
    30a8:      	add	x2, x22, #0x50
    30ac:      	mov	w8, #0x10               // =16
    30b0:      	mov	w9, #0x4                // =4
    30b4:      	add	x10, sp, #0x88
    30b8:      	add	x0, sp, #0x88
    30bc:      	mov	w1, #0x10               // =16
    30c0:      	blr	x9
    30c4:      	tbnz	w0, #0x1f, 0x3168 <generic_usdt_process_event+0x27d8>
    30c8:      	ldr	x8, [sp, #0x90]
    30cc:      	cmp	x8, #0xffe
    30d0:      	str	x8, [sp, #0x38]
    30d4:      	b.hi	0x2b34 <generic_usdt_process_event+0x21a4>
    30d8:      	ldp	x8, x1, [sp, #0x30]
    30dc:      	mov	w9, #0x4                // =4
    30e0:      	add	x23, x8, x23
    30e4:      	and	x8, x23, #0x3fff
    30e8:      	add	x0, x21, x8
    30ec:      	ldr	x8, [sp, #0x88]
    30f0:      	ldr	x2, [sp, #0x88]
    30f4:      	blr	x9
    30f8:      	tbnz	w0, #0x1f, 0x3168 <generic_usdt_process_event+0x27d8>
    30fc:      	ldr	x8, [sp, #0x38]
    3100:      	cmp	x24, #0x7
    3104:      	add	x29, x8, x29
    3108:      	b.lo	0x2c18 <generic_usdt_process_event+0x2288>
    310c:      	add	x2, x22, #0x60
    3110:      	mov	w8, #0x10               // =16
    3114:      	mov	w9, #0x4                // =4
    3118:      	add	x10, sp, #0x88
    311c:      	add	x0, sp, #0x88
    3120:      	mov	w1, #0x10               // =16
    3124:      	blr	x9
    3128:      	tbnz	w0, #0x1f, 0x3168 <generic_usdt_process_event+0x27d8>
    312c:      	ldr	x22, [sp, #0x90]
    3130:      	cmp	x22, #0xffe
    3134:      	b.hi	0x2b34 <generic_usdt_process_event+0x21a4>
    3138:      	ldr	x8, [sp, #0x38]
    313c:      	mov	w9, #0x4                // =4
    3140:      	mov	w1, w22
    3144:      	add	x8, x8, x23
    3148:      	and	x8, x8, #0x3fff
    314c:      	add	x0, x21, x8
    3150:      	ldr	x8, [sp, #0x88]
    3154:      	ldr	x2, [sp, #0x88]
    3158:      	blr	x9
    315c:      	tbnz	w0, #0x1f, 0x3168 <generic_usdt_process_event+0x27d8>
    3160:      	add	x29, x22, x29
    3164:      	b	0x2c18 <generic_usdt_process_event+0x2288>
    3168:      	mov	w8, #-0x2               // =-2
    316c:      	str	w8, [x25]
    3170:      	mov	w9, #0x4                // =4
    3174:      	b	0x38c8 <generic_usdt_process_event+0x2f38>
    3178:      	ldrb	w8, [x23, #0x7]
    317c:      	lsl	w8, w8, #2
    3180:      	add	w8, w8, #0x8
    3184:      	strh	w8, [x23, #0x2]
    3188:      	ldrh	w9, [x23]
    318c:      	ldrb	w29, [x23, #0x6]
    3190:      	add	w8, w9, w8
    3194:      	cmp	w29, #0x3c
    3198:      	strh	w8, [x23]
    319c:      	b.hi	0x3254 <generic_usdt_process_event+0x28c4>
    31a0:      	mov	x10, #0x1               // =1
    31a4:      	mov	w9, #0x1                // =1
    31a8:      	movk	x10, #0x1800, lsl #32
    31ac:      	lsl	x9, x9, x29
    31b0:      	movk	x10, #0x1008, lsl #48
    31b4:      	tst	x9, x10
    31b8:      	b.eq	0x3254 <generic_usdt_process_event+0x28c4>
    31bc:      	strb	w29, [x23, #0x5]
    31c0:      	add	x8, x25, w8, uxth
    31c4:      	mov	w9, #0x2                // =2
    31c8:      	mov	w10, #0x4               // =4
    31cc:      	mov	x0, x22
    31d0:      	mov	w1, #0x2                // =2
    31d4:      	ldrh	w8, [x23]
    31d8:      	add	x2, x25, x8
    31dc:      	blr	x10
    31e0:      	tbnz	x0, #0x3f, 0x3744 <generic_usdt_process_event+0x2db4>
    31e4:      	ldrb	w8, [x23, #0x5]
    31e8:      	cmp	w8, #0x32
    31ec:      	b.gt	0x320c <generic_usdt_process_event+0x287c>
    31f0:      	cbz	w8, 0x322c <generic_usdt_process_event+0x289c>
    31f4:      	cmp	w8, #0x2b
    31f8:      	b.eq	0x322c <generic_usdt_process_event+0x289c>
    31fc:      	cmp	w8, #0x2c
    3200:      	b.ne	0x333c <generic_usdt_process_event+0x29ac>
    3204:      	mov	w8, #0x8                // =8
    3208:      	b	0x3288 <generic_usdt_process_event+0x28f8>
    320c:      	cmp	w8, #0x33
    3210:      	b.eq	0x327c <generic_usdt_process_event+0x28ec>
    3214:      	cmp	w8, #0x3c
    3218:      	b.eq	0x322c <generic_usdt_process_event+0x289c>
    321c:      	cmp	w8, #0xff
    3220:      	b.ne	0x333c <generic_usdt_process_event+0x29ac>
    3224:      	mov	w8, #0x28               // =40
    3228:      	b	0x3288 <generic_usdt_process_event+0x28f8>
    322c:      	ldrb	w8, [x23, #0x7]
    3230:      	lsl	w8, w8, #3
    3234:      	b	0x3284 <generic_usdt_process_event+0x28f4>
    3238:      	ldrh	w8, [x23, #0x2]
    323c:      	ldrh	w9, [x23]
    3240:      	ldrb	w29, [x23, #0x6]
    3244:      	add	w8, w9, w8
    3248:      	cmp	w29, #0x3c
    324c:      	strh	w8, [x23]
    3250:      	b.ls	0x31a0 <generic_usdt_process_event+0x2810>
    3254:      	strh	w8, [sp, #0x80]
    3258:      	b	0x3748 <generic_usdt_process_event+0x2db8>
    325c:      	ldr	x9, [sp, #0x30]
    3260:      	mov	w8, wzr
    3264:      	stp	w0, wzr, [x9, #0x4]
    3268:      	mov	w0, wzr
    326c:      	ldr	x9, [sp, #0x30]
    3270:      	stp	w8, w0, [x9, #0xc]
    3274:      	mov	w9, #0x24               // =36
    3278:      	b	0x38c8 <generic_usdt_process_event+0x2f38>
    327c:      	ldrb	w8, [x23, #0x7]
    3280:      	lsl	w8, w8, #2
    3284:      	add	w8, w8, #0x8
    3288:      	strh	w8, [x23, #0x2]
    328c:      	ldrh	w9, [x23]
    3290:      	ldrb	w29, [x23, #0x6]
    3294:      	add	w8, w9, w8
    3298:      	cmp	w29, #0x3c
    329c:      	strh	w8, [x23]
    32a0:      	b.hi	0x393c <generic_usdt_process_event+0x2fac>
    32a4:      	mov	x10, #0x1               // =1
    32a8:      	mov	w9, #0x1                // =1
    32ac:      	movk	x10, #0x1800, lsl #32
    32b0:      	lsl	x9, x9, x29
    32b4:      	movk	x10, #0x1008, lsl #48
    32b8:      	tst	x9, x10
    32bc:      	b.eq	0x393c <generic_usdt_process_event+0x2fac>
    32c0:      	strb	w29, [x23, #0x5]
    32c4:      	add	x8, x25, w8, uxth
    32c8:      	mov	w9, #0x2                // =2
    32cc:      	mov	w10, #0x4               // =4
    32d0:      	mov	x0, x22
    32d4:      	mov	w1, #0x2                // =2
    32d8:      	ldrh	w8, [x23]
    32dc:      	add	x2, x25, x8
    32e0:      	blr	x10
    32e4:      	tbnz	x0, #0x3f, 0x3744 <generic_usdt_process_event+0x2db4>
    32e8:      	ldrb	w8, [x23, #0x5]
    32ec:      	cmp	w8, #0x32
    32f0:      	b.gt	0x3310 <generic_usdt_process_event+0x2980>
    32f4:      	cbz	w8, 0x3330 <generic_usdt_process_event+0x29a0>
    32f8:      	cmp	w8, #0x2b
    32fc:      	b.eq	0x3330 <generic_usdt_process_event+0x29a0>
    3300:      	cmp	w8, #0x2c
    3304:      	b.ne	0x341c <generic_usdt_process_event+0x2a8c>
    3308:      	mov	w8, #0x8                // =8
    330c:      	b	0x3368 <generic_usdt_process_event+0x29d8>
    3310:      	cmp	w8, #0x33
    3314:      	b.eq	0x335c <generic_usdt_process_event+0x29cc>
    3318:      	cmp	w8, #0x3c
    331c:      	b.eq	0x3330 <generic_usdt_process_event+0x29a0>
    3320:      	cmp	w8, #0xff
    3324:      	b.ne	0x341c <generic_usdt_process_event+0x2a8c>
    3328:      	mov	w8, #0x28               // =40
    332c:      	b	0x3368 <generic_usdt_process_event+0x29d8>
    3330:      	ldrb	w8, [x23, #0x7]
    3334:      	lsl	w8, w8, #3
    3338:      	b	0x3364 <generic_usdt_process_event+0x29d4>
    333c:      	ldrh	w8, [x23, #0x2]
    3340:      	ldrh	w9, [x23]
    3344:      	ldrb	w29, [x23, #0x6]
    3348:      	add	w8, w9, w8
    334c:      	cmp	w29, #0x3c
    3350:      	strh	w8, [x23]
    3354:      	b.ls	0x32a4 <generic_usdt_process_event+0x2914>
    3358:      	b	0x393c <generic_usdt_process_event+0x2fac>
    335c:      	ldrb	w8, [x23, #0x7]
    3360:      	lsl	w8, w8, #2
    3364:      	add	w8, w8, #0x8
    3368:      	strh	w8, [x23, #0x2]
    336c:      	ldrh	w9, [x23]
    3370:      	ldrb	w29, [x23, #0x6]
    3374:      	add	w8, w9, w8
    3378:      	cmp	w29, #0x3c
    337c:      	strh	w8, [x23]
    3380:      	b.hi	0x393c <generic_usdt_process_event+0x2fac>
    3384:      	mov	x10, #0x1               // =1
    3388:      	mov	w9, #0x1                // =1
    338c:      	movk	x10, #0x1800, lsl #32
    3390:      	lsl	x9, x9, x29
    3394:      	movk	x10, #0x1008, lsl #48
    3398:      	tst	x9, x10
    339c:      	b.eq	0x393c <generic_usdt_process_event+0x2fac>
    33a0:      	strb	w29, [x23, #0x5]
    33a4:      	add	x8, x25, w8, uxth
    33a8:      	mov	w9, #0x2                // =2
    33ac:      	mov	w10, #0x4               // =4
    33b0:      	mov	x0, x22
    33b4:      	mov	w1, #0x2                // =2
    33b8:      	ldrh	w8, [x23]
    33bc:      	add	x2, x25, x8
    33c0:      	blr	x10
    33c4:      	tbnz	x0, #0x3f, 0x3744 <generic_usdt_process_event+0x2db4>
    33c8:      	ldrb	w8, [x23, #0x5]
    33cc:      	cmp	w8, #0x32
    33d0:      	b.gt	0x33f0 <generic_usdt_process_event+0x2a60>
    33d4:      	cbz	w8, 0x3410 <generic_usdt_process_event+0x2a80>
    33d8:      	cmp	w8, #0x2b
    33dc:      	b.eq	0x3410 <generic_usdt_process_event+0x2a80>
    33e0:      	cmp	w8, #0x2c
    33e4:      	b.ne	0x34fc <generic_usdt_process_event+0x2b6c>
    33e8:      	mov	w8, #0x8                // =8
    33ec:      	b	0x3448 <generic_usdt_process_event+0x2ab8>
    33f0:      	cmp	w8, #0x33
    33f4:      	b.eq	0x343c <generic_usdt_process_event+0x2aac>
    33f8:      	cmp	w8, #0x3c
    33fc:      	b.eq	0x3410 <generic_usdt_process_event+0x2a80>
    3400:      	cmp	w8, #0xff
    3404:      	b.ne	0x34fc <generic_usdt_process_event+0x2b6c>
    3408:      	mov	w8, #0x28               // =40
    340c:      	b	0x3448 <generic_usdt_process_event+0x2ab8>
    3410:      	ldrb	w8, [x23, #0x7]
    3414:      	lsl	w8, w8, #3
    3418:      	b	0x3444 <generic_usdt_process_event+0x2ab4>
    341c:      	ldrh	w8, [x23, #0x2]
    3420:      	ldrh	w9, [x23]
    3424:      	ldrb	w29, [x23, #0x6]
    3428:      	add	w8, w9, w8
    342c:      	cmp	w29, #0x3c
    3430:      	strh	w8, [x23]
    3434:      	b.ls	0x3384 <generic_usdt_process_event+0x29f4>
    3438:      	b	0x393c <generic_usdt_process_event+0x2fac>
    343c:      	ldrb	w8, [x23, #0x7]
    3440:      	lsl	w8, w8, #2
    3444:      	add	w8, w8, #0x8
    3448:      	strh	w8, [x23, #0x2]
    344c:      	ldrh	w9, [x23]
    3450:      	ldrb	w29, [x23, #0x6]
    3454:      	add	w8, w9, w8
    3458:      	cmp	w29, #0x3c
    345c:      	strh	w8, [x23]
    3460:      	b.hi	0x393c <generic_usdt_process_event+0x2fac>
    3464:      	mov	x10, #0x1               // =1
    3468:      	mov	w9, #0x1                // =1
    346c:      	movk	x10, #0x1800, lsl #32
    3470:      	lsl	x9, x9, x29
    3474:      	movk	x10, #0x1008, lsl #48
    3478:      	tst	x9, x10
    347c:      	b.eq	0x393c <generic_usdt_process_event+0x2fac>
    3480:      	strb	w29, [x23, #0x5]
    3484:      	add	x8, x25, w8, uxth
    3488:      	mov	w9, #0x2                // =2
    348c:      	mov	w10, #0x4               // =4
    3490:      	mov	x0, x22
    3494:      	mov	w1, #0x2                // =2
    3498:      	ldrh	w8, [x23]
    349c:      	add	x2, x25, x8
    34a0:      	blr	x10
    34a4:      	tbnz	x0, #0x3f, 0x3744 <generic_usdt_process_event+0x2db4>
    34a8:      	ldrb	w8, [x23, #0x5]
    34ac:      	cmp	w8, #0x32
    34b0:      	b.gt	0x34d0 <generic_usdt_process_event+0x2b40>
    34b4:      	cbz	w8, 0x34f0 <generic_usdt_process_event+0x2b60>
    34b8:      	cmp	w8, #0x2b
    34bc:      	b.eq	0x34f0 <generic_usdt_process_event+0x2b60>
    34c0:      	cmp	w8, #0x2c
    34c4:      	b.ne	0x35dc <generic_usdt_process_event+0x2c4c>
    34c8:      	mov	w8, #0x8                // =8
    34cc:      	b	0x3528 <generic_usdt_process_event+0x2b98>
    34d0:      	cmp	w8, #0x33
    34d4:      	b.eq	0x351c <generic_usdt_process_event+0x2b8c>
    34d8:      	cmp	w8, #0x3c
    34dc:      	b.eq	0x34f0 <generic_usdt_process_event+0x2b60>
    34e0:      	cmp	w8, #0xff
    34e4:      	b.ne	0x35dc <generic_usdt_process_event+0x2c4c>
    34e8:      	mov	w8, #0x28               // =40
    34ec:      	b	0x3528 <generic_usdt_process_event+0x2b98>
    34f0:      	ldrb	w8, [x23, #0x7]
    34f4:      	lsl	w8, w8, #3
    34f8:      	b	0x3524 <generic_usdt_process_event+0x2b94>
    34fc:      	ldrh	w8, [x23, #0x2]
    3500:      	ldrh	w9, [x23]
    3504:      	ldrb	w29, [x23, #0x6]
    3508:      	add	w8, w9, w8
    350c:      	cmp	w29, #0x3c
    3510:      	strh	w8, [x23]
    3514:      	b.ls	0x3464 <generic_usdt_process_event+0x2ad4>
    3518:      	b	0x393c <generic_usdt_process_event+0x2fac>
    351c:      	ldrb	w8, [x23, #0x7]
    3520:      	lsl	w8, w8, #2
    3524:      	add	w8, w8, #0x8
    3528:      	strh	w8, [x23, #0x2]
    352c:      	ldrh	w9, [x23]
    3530:      	ldrb	w29, [x23, #0x6]
    3534:      	add	w8, w9, w8
    3538:      	cmp	w29, #0x3c
    353c:      	strh	w8, [x23]
    3540:      	b.hi	0x393c <generic_usdt_process_event+0x2fac>
    3544:      	mov	x10, #0x1               // =1
    3548:      	mov	w9, #0x1                // =1
    354c:      	movk	x10, #0x1800, lsl #32
    3550:      	lsl	x9, x9, x29
    3554:      	movk	x10, #0x1008, lsl #48
    3558:      	tst	x9, x10
    355c:      	b.eq	0x393c <generic_usdt_process_event+0x2fac>
    3560:      	strb	w29, [x23, #0x5]
    3564:      	add	x8, x25, w8, uxth
    3568:      	mov	w9, #0x2                // =2
    356c:      	mov	w10, #0x4               // =4
    3570:      	mov	x0, x22
    3574:      	mov	w1, #0x2                // =2
    3578:      	ldrh	w8, [x23]
    357c:      	add	x2, x25, x8
    3580:      	blr	x10
    3584:      	tbnz	x0, #0x3f, 0x3744 <generic_usdt_process_event+0x2db4>
    3588:      	ldrb	w8, [x23, #0x5]
    358c:      	cmp	w8, #0x32
    3590:      	b.gt	0x35b0 <generic_usdt_process_event+0x2c20>
    3594:      	cbz	w8, 0x35d0 <generic_usdt_process_event+0x2c40>
    3598:      	cmp	w8, #0x2b
    359c:      	b.eq	0x35d0 <generic_usdt_process_event+0x2c40>
    35a0:      	cmp	w8, #0x2c
    35a4:      	b.ne	0x36bc <generic_usdt_process_event+0x2d2c>
    35a8:      	mov	w8, #0x8                // =8
    35ac:      	b	0x3608 <generic_usdt_process_event+0x2c78>
    35b0:      	cmp	w8, #0x33
    35b4:      	b.eq	0x35fc <generic_usdt_process_event+0x2c6c>
    35b8:      	cmp	w8, #0x3c
    35bc:      	b.eq	0x35d0 <generic_usdt_process_event+0x2c40>
    35c0:      	cmp	w8, #0xff
    35c4:      	b.ne	0x36bc <generic_usdt_process_event+0x2d2c>
    35c8:      	mov	w8, #0x28               // =40
    35cc:      	b	0x3608 <generic_usdt_process_event+0x2c78>
    35d0:      	ldrb	w8, [x23, #0x7]
    35d4:      	lsl	w8, w8, #3
    35d8:      	b	0x3604 <generic_usdt_process_event+0x2c74>
    35dc:      	ldrh	w8, [x23, #0x2]
    35e0:      	ldrh	w9, [x23]
    35e4:      	ldrb	w29, [x23, #0x6]
    35e8:      	add	w8, w9, w8
    35ec:      	cmp	w29, #0x3c
    35f0:      	strh	w8, [x23]
    35f4:      	b.ls	0x3544 <generic_usdt_process_event+0x2bb4>
    35f8:      	b	0x393c <generic_usdt_process_event+0x2fac>
    35fc:      	ldrb	w8, [x23, #0x7]
    3600:      	lsl	w8, w8, #2
    3604:      	add	w8, w8, #0x8
    3608:      	strh	w8, [x23, #0x2]
    360c:      	ldrh	w9, [x23]
    3610:      	ldrb	w29, [x23, #0x6]
    3614:      	add	w8, w9, w8
    3618:      	cmp	w29, #0x3c
    361c:      	strh	w8, [x23]
    3620:      	b.hi	0x393c <generic_usdt_process_event+0x2fac>
    3624:      	mov	x10, #0x1               // =1
    3628:      	mov	w9, #0x1                // =1
    362c:      	movk	x10, #0x1800, lsl #32
    3630:      	lsl	x9, x9, x29
    3634:      	movk	x10, #0x1008, lsl #48
    3638:      	tst	x9, x10
    363c:      	b.eq	0x393c <generic_usdt_process_event+0x2fac>
    3640:      	strb	w29, [x23, #0x5]
    3644:      	add	x8, x25, w8, uxth
    3648:      	mov	w9, #0x2                // =2
    364c:      	mov	w10, #0x4               // =4
    3650:      	mov	x0, x22
    3654:      	mov	w1, #0x2                // =2
    3658:      	ldrh	w8, [x23]
    365c:      	add	x2, x25, x8
    3660:      	blr	x10
    3664:      	tbnz	x0, #0x3f, 0x3744 <generic_usdt_process_event+0x2db4>
    3668:      	ldrb	w8, [x23, #0x5]
    366c:      	cmp	w8, #0x32
    3670:      	b.gt	0x3690 <generic_usdt_process_event+0x2d00>
    3674:      	cbz	w8, 0x36b0 <generic_usdt_process_event+0x2d20>
    3678:      	cmp	w8, #0x2b
    367c:      	b.eq	0x36b0 <generic_usdt_process_event+0x2d20>
    3680:      	cmp	w8, #0x2c
    3684:      	b.ne	0x3920 <generic_usdt_process_event+0x2f90>
    3688:      	mov	w8, #0x8                // =8
    368c:      	b	0x36e8 <generic_usdt_process_event+0x2d58>
    3690:      	cmp	w8, #0x33
    3694:      	b.eq	0x36dc <generic_usdt_process_event+0x2d4c>
    3698:      	cmp	w8, #0x3c
    369c:      	b.eq	0x36b0 <generic_usdt_process_event+0x2d20>
    36a0:      	cmp	w8, #0xff
    36a4:      	b.ne	0x3920 <generic_usdt_process_event+0x2f90>
    36a8:      	mov	w8, #0x28               // =40
    36ac:      	b	0x36e8 <generic_usdt_process_event+0x2d58>
    36b0:      	ldrb	w8, [x23, #0x7]
    36b4:      	lsl	w8, w8, #3
    36b8:      	b	0x36e4 <generic_usdt_process_event+0x2d54>
    36bc:      	ldrh	w8, [x23, #0x2]
    36c0:      	ldrh	w9, [x23]
    36c4:      	ldrb	w29, [x23, #0x6]
    36c8:      	add	w8, w9, w8
    36cc:      	cmp	w29, #0x3c
    36d0:      	strh	w8, [x23]
    36d4:      	b.ls	0x3624 <generic_usdt_process_event+0x2c94>
    36d8:      	b	0x393c <generic_usdt_process_event+0x2fac>
    36dc:      	ldrb	w8, [x23, #0x7]
    36e0:      	lsl	w8, w8, #2
    36e4:      	add	w8, w8, #0x8
    36e8:      	strh	w8, [x23, #0x2]
    36ec:      	ldrh	w9, [x23]
    36f0:      	ldrb	w29, [x23, #0x6]
    36f4:      	add	w8, w9, w8
    36f8:      	cmp	w29, #0x3c
    36fc:      	strh	w8, [x23]
    3700:      	b.hi	0x393c <generic_usdt_process_event+0x2fac>
    3704:      	mov	x10, #0x1               // =1
    3708:      	mov	w9, #0x1                // =1
    370c:      	movk	x10, #0x1800, lsl #32
    3710:      	lsl	x9, x9, x29
    3714:      	movk	x10, #0x1008, lsl #48
    3718:      	tst	x9, x10
    371c:      	b.eq	0x393c <generic_usdt_process_event+0x2fac>
    3720:      	strb	w29, [x23, #0x5]
    3724:      	add	x8, x25, w8, uxth
    3728:      	mov	w9, #0x2                // =2
    372c:      	mov	w10, #0x4               // =4
    3730:      	mov	x0, x22
    3734:      	mov	w1, #0x2                // =2
    3738:      	ldrh	w8, [x23]
    373c:      	add	x2, x25, x8
    3740:      	blr	x10
    3744:      	mov	w29, wzr
    3748:      	ldr	x25, [sp, #0x18]
    374c:      	mov	w8, #0xa                // =10
    3750:      	strb	w29, [sp, #0x74]
    3754:      	add	x2, x21, #0x8
    3758:      	mov	w22, #0x10              // =16
    375c:      	mov	w1, #0x10               // =16
    3760:      	mov	w23, #0x4               // =4
    3764:      	strh	w29, [x25, #0x24]
    3768:      	strh	w8, [x25, #0x26]
    376c:      	mov	w8, #0x4                // =4
    3770:      	mov	x0, x25
    3774:      	blr	x8
    3778:      	add	x0, x25, #0x10
    377c:      	add	x2, x21, #0x18
    3780:      	mov	w1, #0x10               // =16
    3784:      	blr	x23
    3788:      	cmp	w29, #0x11
    378c:      	b.eq	0x37d0 <generic_usdt_process_event+0x2e40>
    3790:      	cmp	w29, #0x6
    3794:      	b.ne	0x3810 <generic_usdt_process_event+0x2e80>
    3798:      	ldr	x8, [sp, #0x88]
    379c:      	ldrh	w9, [sp, #0x80]
    37a0:      	mov	w23, #0x2               // =2
    37a4:      	mov	w1, #0x2                // =2
    37a8:      	mov	w25, #0x4               // =4
    37ac:      	add	x22, x8, x9
    37b0:      	ldr	x29, [sp, #0x18]
    37b4:      	add	x0, x29, #0x20
    37b8:      	mov	w8, #0x4                // =4
    37bc:      	mov	x2, x22
    37c0:      	blr	x8
    37c4:      	add	x0, x29, #0x22
    37c8:      	add	x2, x22, #0x2
    37cc:      	b	0x3804 <generic_usdt_process_event+0x2e74>
    37d0:      	ldr	x8, [sp, #0x88]
    37d4:      	ldrh	w9, [sp, #0x80]
    37d8:      	mov	w23, #0x2               // =2
    37dc:      	mov	w1, #0x2                // =2
    37e0:      	mov	w25, #0x4               // =4
    37e4:      	add	x22, x8, x9
    37e8:      	ldr	x29, [sp, #0x18]
    37ec:      	add	x0, x29, #0x20
    37f0:      	mov	w8, #0x4                // =4
    37f4:      	mov	x2, x22
    37f8:      	blr	x8
    37fc:      	add	x0, x29, #0x22
    3800:      	add	x2, x22, #0x2
    3804:      	mov	w1, #0x2                // =2
    3808:      	blr	x25
    380c:      	b	0x3818 <generic_usdt_process_event+0x2e88>
    3810:      	ldr	x8, [sp, #0x18]
    3814:      	str	wzr, [x8, #0x20]
    3818:      	ldr	x9, [sp, #0x18]
    381c:      	add	x2, x24, #0xe0
    3820:      	add	x10, sp, #0xe0
    3824:      	add	x0, sp, #0xe0
    3828:      	ldrh	w8, [x9, #0x20]
    382c:      	mov	w1, #0x8                // =8
    3830:      	rev	w8, w8
    3834:      	lsr	w8, w8, #16
    3838:      	strh	w8, [x9, #0x20]
    383c:      	ldrh	w8, [x9, #0x22]
    3840:      	rev	w8, w8
    3844:      	lsr	w8, w8, #16
    3848:      	strh	w8, [x9, #0x22]
    384c:      	mov	w8, #0x8                // =8
    3850:      	mov	w9, #0x4                // =4
    3854:      	blr	x9
    3858:      	add	x8, sp, #0xd0
    385c:      	ldr	x8, [x8, #0x10]
    3860:      	cbz	x8, 0x38c4 <generic_usdt_process_event+0x2f34>
    3864:      	add	x8, x8, #0x5
    3868:      	mov	w9, #0x8                // =8
    386c:      	add	x10, sp, #0xf0
    3870:      	mov	w11, #0x4               // =4
    3874:      	add	x21, sp, #0xd0
    3878:      	ldr	x8, [x21, #0x10]
    387c:      	add	x0, sp, #0xf0
    3880:      	mov	w1, #0x8                // =8
    3884:      	mov	w22, #0x4               // =4
    3888:      	add	x2, x8, #0x5
    388c:      	blr	x11
    3890:      	ldr	x8, [x21, #0x10]
    3894:      	ldr	x9, [x21, #0x20]
    3898:      	mov	w1, #0x4                // =4
    389c:      	add	x23, x8, x9, lsl #3
    38a0:      	ldr	x24, [sp, #0x18]
    38a4:      	add	x0, x24, #0x38
    38a8:      	mov	w8, #0x4                // =4
    38ac:      	add	x2, x23, #0x44
    38b0:      	blr	x8
    38b4:      	add	x0, x24, #0x3c
    38b8:      	add	x2, x23, #0x45
    38bc:      	mov	w1, #0x4                // =4
    38c0:      	blr	x22
    38c4:      	mov	w9, #0x40               // =64
    38c8:      	mov	w25, #0x5efc            // =24316
    38cc:      	adrp	x21, 0x3000 <generic_usdt_process_event+0x2670>
    38d0:      	ldr	x11, [sp, #0x20]
    38d4:      	mov	w10, #0x5ea0            // =24224
    38d8:      	ldr	x21, [x21]
    38dc:      	ldr	x23, [sp, #0x40]
    38e0:      	ldr	x24, [sp, #0x108]
    38e4:      	tbnz	w9, #0x1f, 0x390c <generic_usdt_process_event+0x2f7c>
    38e8:      	and	w8, w9, #0x7fffffff
    38ec:      	add	w8, w8, #0x4
    38f0:      	add	w24, w8, w24
    38f4:      	str	w24, [x20, #0x4]
    38f8:      	adrp	x22, 0x3000 <generic_usdt_process_event+0x2670>
    38fc:      	cmp	w23, #0x3
    3900:      	ldr	x22, [x22]
    3904:      	b.le	0xe38 <generic_usdt_process_event+0x4a8>
    3908:      	b	0xea4 <generic_usdt_process_event+0x514>
    390c:      	ldr	x9, [sp, #0x10]
    3910:      	mov	w8, #-0x1               // =-1
    3914:      	str	w8, [x9, x10]
    3918:      	str	w8, [x11, x24]
    391c:      	b	0xdfc <generic_usdt_process_event+0x46c>
    3920:      	ldrh	w8, [x23, #0x2]
    3924:      	ldrh	w9, [x23]
    3928:      	ldrb	w29, [x23, #0x6]
    392c:      	add	w8, w9, w8
    3930:      	cmp	w29, #0x3c
    3934:      	strh	w8, [x23]
    3938:      	b.ls	0x3704 <generic_usdt_process_event+0x2d74>
    393c:      	strh	w8, [sp, #0x80]
    3940:      	b	0x3748 <generic_usdt_process_event+0x2db8>
    3944:      	nop
    3948:      	nop
    394c:      	nop

0000000000003950 <generic_usdt_process_filter>:
    3950:      	sub	sp, sp, #0x130
    3954:      	str	x29, [sp, #0xe0]
    3958:      	stp	x30, x25, [sp, #0xf0]
    395c:      	stp	x24, x23, [sp, #0x100]
    3960:      	stp	x22, x21, [sp, #0x110]
    3964:      	stp	x20, x19, [sp, #0x120]
    3968:      	mov	x20, x0
    396c:      	str	wzr, [sp, #0x54]
    3970:      	adrp	x0, 0x3000 <generic_usdt_process_event+0x2670>
    3974:      	mov	w8, #0x1                // =1
    3978:      	ldr	x0, [x0]
    397c:      	add	x9, sp, #0x54
    3980:      	add	x1, sp, #0x54
    3984:      	blr	x8
    3988:      	cbz	x0, 0x5c8c <generic_usdt_process_filter+0x233c>
    398c:      	mov	w8, #0x5ec0             // =24256
    3990:      	mov	x22, x0
    3994:      	add	x29, x0, x8
    3998:      	mov	w8, #0x23               // =35
    399c:      	blr	x8
    39a0:      	str	x0, [sp, #0x58]
    39a4:      	add	x8, x0, #0x8d4
    39a8:      	mov	w9, #0x4                // =4
    39ac:      	mov	w10, #0x71              // =113
    39b0:      	add	x11, sp, #0xd8
    39b4:      	add	x0, sp, #0xd8
    39b8:      	mov	w1, #0x4                // =4
    39bc:      	ldr	x8, [sp, #0x58]
    39c0:      	add	x2, x8, #0x8d4
    39c4:      	blr	x10
    39c8:      	ldr	w8, [sp, #0xd8]
    39cc:      	adrp	x19, 0x3000 <generic_usdt_process_event+0x2670>
    39d0:      	add	x9, sp, #0xc8
    39d4:      	add	x1, sp, #0xc8
    39d8:      	str	w8, [sp, #0xc8]
    39dc:      	mov	w8, #0x1                // =1
    39e0:      	ldr	x19, [x19]
    39e4:      	mov	x0, x19
    39e8:      	blr	x8
    39ec:      	cbz	x0, 0x39fc <generic_usdt_process_filter+0xac>
    39f0:      	ldr	x8, [x0, #0x8]
    39f4:      	mov	x24, x0
    39f8:      	cbnz	x8, 0x47ec <generic_usdt_process_filter+0xe9c>
    39fc:      	ldr	x8, [sp, #0x58]
    3a00:      	mov	w9, #0x8                // =8
    3a04:      	mov	w10, #0x71              // =113
    3a08:      	add	x11, sp, #0x58
    3a0c:      	add	x0, sp, #0x58
    3a10:      	mov	w1, #0x8                // =8
    3a14:      	add	x8, x8, #0x8e0
    3a18:      	ldr	x8, [sp, #0x58]
    3a1c:      	add	x2, x8, #0x8e0
    3a20:      	blr	x10
    3a24:      	ldr	x8, [sp, #0x58]
    3a28:      	cbz	x8, 0x3ba4 <generic_usdt_process_filter+0x254>
    3a2c:      	add	x8, x8, #0x8d4
    3a30:      	mov	w9, #0x4                // =4
    3a34:      	mov	w10, #0x71              // =113
    3a38:      	add	x11, sp, #0xd8
    3a3c:      	ldr	x8, [sp, #0x58]
    3a40:      	add	x0, sp, #0xd8
    3a44:      	mov	w1, #0x4                // =4
    3a48:      	add	x2, x8, #0x8d4
    3a4c:      	blr	x10
    3a50:      	ldr	w8, [sp, #0xd8]
    3a54:      	add	x9, sp, #0xc8
    3a58:      	add	x1, sp, #0xc8
    3a5c:      	mov	x0, x19
    3a60:      	str	w8, [sp, #0xc8]
    3a64:      	mov	w8, #0x1                // =1
    3a68:      	blr	x8
    3a6c:      	cbz	x0, 0x3a7c <generic_usdt_process_filter+0x12c>
    3a70:      	ldr	x8, [x0, #0x8]
    3a74:      	mov	x24, x0
    3a78:      	cbnz	x8, 0x47ec <generic_usdt_process_filter+0xe9c>
    3a7c:      	ldr	x8, [sp, #0x58]
    3a80:      	mov	w9, #0x8                // =8
    3a84:      	mov	w10, #0x71              // =113
    3a88:      	add	x11, sp, #0x58
    3a8c:      	add	x0, sp, #0x58
    3a90:      	mov	w1, #0x8                // =8
    3a94:      	add	x8, x8, #0x8e0
    3a98:      	ldr	x8, [sp, #0x58]
    3a9c:      	add	x2, x8, #0x8e0
    3aa0:      	blr	x10
    3aa4:      	ldr	x8, [sp, #0x58]
    3aa8:      	cbz	x8, 0x3ba4 <generic_usdt_process_filter+0x254>
    3aac:      	add	x8, x8, #0x8d4
    3ab0:      	mov	w9, #0x4                // =4
    3ab4:      	mov	w10, #0x71              // =113
    3ab8:      	add	x11, sp, #0xd8
    3abc:      	ldr	x8, [sp, #0x58]
    3ac0:      	add	x0, sp, #0xd8
    3ac4:      	mov	w1, #0x4                // =4
    3ac8:      	add	x2, x8, #0x8d4
    3acc:      	blr	x10
    3ad0:      	ldr	w8, [sp, #0xd8]
    3ad4:      	add	x9, sp, #0xc8
    3ad8:      	add	x1, sp, #0xc8
    3adc:      	mov	x0, x19
    3ae0:      	str	w8, [sp, #0xc8]
    3ae4:      	mov	w8, #0x1                // =1
    3ae8:      	blr	x8
    3aec:      	cbz	x0, 0x3afc <generic_usdt_process_filter+0x1ac>
    3af0:      	ldr	x8, [x0, #0x8]
    3af4:      	mov	x24, x0
    3af8:      	cbnz	x8, 0x47ec <generic_usdt_process_filter+0xe9c>
    3afc:      	ldr	x8, [sp, #0x58]
    3b00:      	mov	w9, #0x8                // =8
    3b04:      	mov	w10, #0x71              // =113
    3b08:      	add	x11, sp, #0x58
    3b0c:      	add	x0, sp, #0x58
    3b10:      	mov	w1, #0x8                // =8
    3b14:      	add	x8, x8, #0x8e0
    3b18:      	ldr	x8, [sp, #0x58]
    3b1c:      	add	x2, x8, #0x8e0
    3b20:      	blr	x10
    3b24:      	ldr	x8, [sp, #0x58]
    3b28:      	cbz	x8, 0x3ba4 <generic_usdt_process_filter+0x254>
    3b2c:      	add	x8, x8, #0x8d4
    3b30:      	mov	w9, #0x4                // =4
    3b34:      	mov	w10, #0x71              // =113
    3b38:      	add	x11, sp, #0xd8
    3b3c:      	ldr	x8, [sp, #0x58]
    3b40:      	add	x0, sp, #0xd8
    3b44:      	mov	w1, #0x4                // =4
    3b48:      	add	x2, x8, #0x8d4
    3b4c:      	blr	x10
    3b50:      	ldr	w8, [sp, #0xd8]
    3b54:      	add	x9, sp, #0xc8
    3b58:      	add	x1, sp, #0xc8
    3b5c:      	mov	x0, x19
    3b60:      	str	w8, [sp, #0xc8]
    3b64:      	mov	w8, #0x1                // =1
    3b68:      	blr	x8
    3b6c:      	cbz	x0, 0x3b7c <generic_usdt_process_filter+0x22c>
    3b70:      	ldr	x8, [x0, #0x8]
    3b74:      	mov	x24, x0
    3b78:      	cbnz	x8, 0x47ec <generic_usdt_process_filter+0xe9c>
    3b7c:      	ldr	x8, [sp, #0x58]
    3b80:      	mov	w9, #0x8                // =8
    3b84:      	mov	w10, #0x71              // =113
    3b88:      	add	x11, sp, #0x58
    3b8c:      	add	x0, sp, #0x58
    3b90:      	mov	w1, #0x8                // =8
    3b94:      	add	x8, x8, #0x8e0
    3b98:      	ldr	x8, [sp, #0x58]
    3b9c:      	add	x2, x8, #0x8e0
    3ba0:      	blr	x10
    3ba4:      	str	x20, [sp, #0x38]
    3ba8:      	mov	w8, #0x23               // =35
    3bac:      	blr	x8
    3bb0:      	add	x2, x0, #0x8d4
    3bb4:      	mov	w8, #0x4                // =4
    3bb8:      	add	x9, sp, #0x58
    3bbc:      	mov	x24, x0
    3bc0:      	add	x0, sp, #0x58
    3bc4:      	mov	w1, #0x4                // =4
    3bc8:      	blr	x8
    3bcc:      	ldr	w8, [sp, #0x58]
    3bd0:      	mov	x19, x29
    3bd4:      	str	w8, [x19, #0x50]!
    3bd8:      	mov	w8, #0x7d               // =125
    3bdc:      	blr	x8
    3be0:      	str	x0, [x22, #0x5f18]
    3be4:      	str	wzr, [x19, #0x10]
    3be8:      	add	x2, x24, #0x60
    3bec:      	mov	w8, #0x8                // =8
    3bf0:      	mov	w9, #0x71               // =113
    3bf4:      	add	x10, sp, #0xc8
    3bf8:      	str	xzr, [x22, #0x5f28]
    3bfc:      	str	x19, [sp, #0x48]
    3c00:      	add	x0, sp, #0xc8
    3c04:      	mov	w1, #0x8                // =8
    3c08:      	str	wzr, [x19, #0x20]
    3c0c:      	blr	x9
    3c10:      	ldr	x8, [sp, #0xc8]
    3c14:      	cbz	x8, 0x3c84 <generic_usdt_process_filter+0x334>
    3c18:      	add	x8, x8, #0x4
    3c1c:      	mov	w9, #0x4                // =4
    3c20:      	mov	w10, #0x71              // =113
    3c24:      	add	x11, sp, #0xd8
    3c28:      	ldr	x8, [sp, #0xc8]
    3c2c:      	add	x0, sp, #0xd8
    3c30:      	mov	w1, #0x4                // =4
    3c34:      	add	x2, x8, #0x4
    3c38:      	blr	x10
    3c3c:      	ldr	w8, [sp, #0xd8]
    3c40:      	cbz	w8, 0x3c84 <generic_usdt_process_filter+0x334>
    3c44:      	ldr	x9, [sp, #0xc8]
    3c48:      	lsl	w8, w8, #4
    3c4c:      	mov	w10, #0x71              // =113
    3c50:      	add	x11, sp, #0x58
    3c54:      	add	x0, sp, #0x58
    3c58:      	mov	w1, #0x10               // =16
    3c5c:      	add	x8, x9, x8
    3c60:      	mov	w9, #0x10               // =16
    3c64:      	add	x8, x8, #0x80
    3c68:      	ldr	w9, [sp, #0xd8]
    3c6c:      	ldr	x8, [sp, #0xc8]
    3c70:      	lsl	w9, w9, #4
    3c74:      	add	x8, x8, x9
    3c78:      	add	x2, x8, #0x80
    3c7c:      	blr	x10
    3c80:      	ldr	w8, [sp, #0x58]
    3c84:      	str	w8, [x29, #0x74]
    3c88:      	mov	w8, #0x5f60             // =24416
    3c8c:      	str	x22, [sp, #0xe8]
    3c90:      	add	x23, x24, #0xae0
    3c94:      	mov	w19, #0x8               // =8
    3c98:      	add	x25, x22, x8
    3c9c:      	add	x8, sp, #0x58
    3ca0:      	mov	w9, #0x4                // =4
    3ca4:      	add	x0, sp, #0x58
    3ca8:      	mov	w1, #0x8                // =8
    3cac:      	mov	x2, x23
    3cb0:      	mov	w21, #0x4               // =4
    3cb4:      	blr	x9
    3cb8:      	ldr	x20, [sp, #0x58]
    3cbc:      	ldr	x9, [sp, #0xe8]
    3cc0:      	mov	w8, #0x5f68             // =24424
    3cc4:      	mov	w1, #0x8                // =8
    3cc8:      	add	x0, x9, x8
    3ccc:      	add	x2, x20, #0x40
    3cd0:      	mov	w8, #0x4                // =4
    3cd4:      	blr	x8
    3cd8:      	ldr	x9, [sp, #0xe8]
    3cdc:      	mov	w8, #0x5f70             // =24432
    3ce0:      	add	x2, x20, #0x30
    3ce4:      	mov	w1, #0x8                // =8
    3ce8:      	add	x0, x9, x8
    3cec:      	mov	w8, #0x4                // =4
    3cf0:      	blr	x8
    3cf4:      	add	x2, x20, #0x38
    3cf8:      	mov	w8, #0x4                // =4
    3cfc:      	mov	x0, x25
    3d00:      	mov	w1, #0x8                // =8
    3d04:      	blr	x8
    3d08:      	ldr	x9, [sp, #0xe8]
    3d0c:      	mov	w8, #0x5f38             // =24376
    3d10:      	add	x2, x24, #0xb50
    3d14:      	add	x0, sp, #0xd8
    3d18:      	mov	w1, #0x8                // =8
    3d1c:      	add	x25, x9, x8
    3d20:      	add	x8, sp, #0xd8
    3d24:      	mov	w9, #0x4                // =4
    3d28:      	blr	x9
    3d2c:      	add	x12, sp, #0xd8
    3d30:      	mov	w9, #0x48               // =72
    3d34:      	add	x10, sp, #0x58
    3d38:      	ldr	x8, [x12]
    3d3c:      	mov	w11, #0x4               // =4
    3d40:      	add	x0, sp, #0x58
    3d44:      	mov	w1, #0x48               // =72
    3d48:      	ldr	x2, [x12]
    3d4c:      	blr	x11
    3d50:      	ldr	x8, [sp, #0x60]
    3d54:      	mov	w9, #0x4                // =4
    3d58:      	mov	x0, x25
    3d5c:      	mov	w1, #0x4                // =4
    3d60:      	add	x8, x8, #0x218
    3d64:      	ldr	x8, [sp, #0x60]
    3d68:      	ldr	x22, [sp, #0xe8]
    3d6c:      	add	x2, x8, #0x218
    3d70:      	blr	x9
    3d74:      	mov	w8, #0x5f3c             // =24380
    3d78:      	mov	w9, #0x4                // =4
    3d7c:      	mov	w1, #0x4                // =4
    3d80:      	add	x0, x22, x8
    3d84:      	ldr	x8, [sp, #0x68]
    3d88:      	add	x8, x8, #0x4d8
    3d8c:      	ldr	x8, [sp, #0x68]
    3d90:      	add	x2, x8, #0x4d8
    3d94:      	blr	x9
    3d98:      	mov	w8, #0x5f40             // =24384
    3d9c:      	mov	w9, #0x4                // =4
    3da0:      	mov	w1, #0x4                // =4
    3da4:      	add	x0, x22, x8
    3da8:      	ldr	x8, [sp, #0x70]
    3dac:      	add	x8, x8, #0x58
    3db0:      	ldr	x8, [sp, #0x70]
    3db4:      	add	x2, x8, #0x58
    3db8:      	blr	x9
    3dbc:      	str	xzr, [sp, #0xc0]
    3dc0:      	add	x2, x24, #0x938
    3dc4:      	add	x8, sp, #0xc0
    3dc8:      	add	x0, sp, #0xc0
    3dcc:      	mov	w1, #0x8                // =8
    3dd0:      	blr	x21
    3dd4:      	ldr	x8, [sp, #0xc0]
    3dd8:      	cbz	x8, 0x3e60 <generic_usdt_process_filter+0x510>
    3ddc:      	str	wzr, [sp, #0xb8]
    3de0:      	add	x8, x8, #0x4
    3de4:      	add	x9, sp, #0xb8
    3de8:      	mov	w10, #0x4               // =4
    3dec:      	add	x0, sp, #0xb8
    3df0:      	mov	w1, #0x4                // =4
    3df4:      	mov	w19, #0x4               // =4
    3df8:      	ldr	x8, [sp, #0xc0]
    3dfc:      	add	x2, x8, #0x4
    3e00:      	blr	x10
    3e04:      	ldr	x8, [sp, #0xc0]
    3e08:      	ldrsw	x9, [sp, #0xb8]
    3e0c:      	add	x10, sp, #0xc8
    3e10:      	mov	w11, #0x4               // =4
    3e14:      	add	x0, sp, #0xc8
    3e18:      	mov	w1, #0x10               // =16
    3e1c:      	add	x8, x8, x9, lsl #4
    3e20:      	mov	w9, #0x10               // =16
    3e24:      	add	x8, x8, #0x80
    3e28:      	ldr	x8, [sp, #0xc0]
    3e2c:      	ldrsw	x9, [sp, #0xb8]
    3e30:      	add	x8, x8, x9, lsl #4
    3e34:      	add	x2, x8, #0x80
    3e38:      	blr	x11
    3e3c:      	mov	w8, #0x5f44             // =24388
    3e40:      	mov	w1, #0x4                // =4
    3e44:      	add	x0, x22, x8
    3e48:      	ldr	x8, [sp, #0xd0]
    3e4c:      	add	x8, x8, #0x158
    3e50:      	ldr	x8, [sp, #0xd0]
    3e54:      	add	x2, x8, #0x158
    3e58:      	blr	x19
    3e5c:      	b	0x3e64 <generic_usdt_process_filter+0x514>
    3e60:      	str	wzr, [x29, #0x84]
    3e64:      	mov	w8, #0x5f48             // =24392
    3e68:      	mov	w9, #0x4                // =4
    3e6c:      	mov	w1, #0x4                // =4
    3e70:      	mov	w19, #0x4               // =4
    3e74:      	add	x0, x22, x8
    3e78:      	ldr	x8, [sp, #0x78]
    3e7c:      	add	x8, x8, #0x158
    3e80:      	ldr	x8, [sp, #0x78]
    3e84:      	add	x2, x8, #0x158
    3e88:      	blr	x9
    3e8c:      	mov	w8, #0x5f4c             // =24396
    3e90:      	mov	w9, #0x4                // =4
    3e94:      	mov	w1, #0x4                // =4
    3e98:      	add	x0, x22, x8
    3e9c:      	ldr	x8, [sp, #0x80]
    3ea0:      	add	x8, x8, #0x118
    3ea4:      	ldr	x8, [sp, #0x80]
    3ea8:      	add	x2, x8, #0x118
    3eac:      	blr	x9
    3eb0:      	mov	w8, #0x5f50             // =24400
    3eb4:      	mov	w9, #0x4                // =4
    3eb8:      	mov	w1, #0x4                // =4
    3ebc:      	add	x0, x22, x8
    3ec0:      	ldr	x8, [sp, #0x88]
    3ec4:      	add	x8, x8, #0x98
    3ec8:      	ldr	x8, [sp, #0x88]
    3ecc:      	add	x2, x8, #0x98
    3ed0:      	blr	x9
    3ed4:      	mov	w8, #0x5f54             // =24404
    3ed8:      	mov	w9, #0x4                // =4
    3edc:      	mov	w1, #0x4                // =4
    3ee0:      	add	x0, x22, x8
    3ee4:      	ldr	x8, [sp, #0x90]
    3ee8:      	add	x8, x8, #0x98
    3eec:      	ldr	x8, [sp, #0x90]
    3ef0:      	add	x2, x8, #0x98
    3ef4:      	blr	x9
    3ef8:      	mov	w8, #0x5f58             // =24408
    3efc:      	mov	w9, #0x4                // =4
    3f00:      	mov	w1, #0x4                // =4
    3f04:      	add	x0, x22, x8
    3f08:      	ldr	x8, [sp, #0x98]
    3f0c:      	add	x8, x8, #0x58
    3f10:      	ldr	x8, [sp, #0x98]
    3f14:      	add	x2, x8, #0x58
    3f18:      	blr	x9
    3f1c:      	stp	xzr, xzr, [sp, #0xc0]
    3f20:      	mov	w20, #0x8               // =8
    3f24:      	add	x8, sp, #0xc8
    3f28:      	mov	w9, #0x4                // =4
    3f2c:      	add	x0, sp, #0xc8
    3f30:      	mov	w1, #0x8                // =8
    3f34:      	mov	x2, x23
    3f38:      	blr	x9
    3f3c:      	ldr	x8, [sp, #0xc8]
    3f40:      	add	x9, sp, #0xc0
    3f44:      	mov	w10, #0x4               // =4
    3f48:      	add	x0, sp, #0xc0
    3f4c:      	mov	w1, #0x8                // =8
    3f50:      	add	x8, x8, #0x90
    3f54:      	ldr	x8, [sp, #0xc8]
    3f58:      	add	x2, x8, #0x90
    3f5c:      	blr	x10
    3f60:      	mov	w8, #0x5f5c             // =24412
    3f64:      	mov	w1, #0x4                // =4
    3f68:      	add	x0, x22, x8
    3f6c:      	ldr	x8, [sp, #0xc0]
    3f70:      	add	x8, x8, #0x158
    3f74:      	ldr	x8, [sp, #0xc0]
    3f78:      	add	x2, x8, #0x158
    3f7c:      	blr	x19
    3f80:      	ldr	w8, [x29, #0x74]
    3f84:      	cmp	w8, #0x1
    3f88:      	b.ne	0x3f98 <generic_usdt_process_filter+0x648>
    3f8c:      	ldr	w8, [x29, #0x70]
    3f90:      	orr	w8, w8, #0x2000000
    3f94:      	str	w8, [x29, #0x70]
    3f98:      	add	x0, x29, #0xb8
    3f9c:      	mov	w1, wzr
    3fa0:      	mov	w2, #0x308              // =776
    3fa4:      	bl	0x3fa4 <generic_usdt_process_filter+0x654>
    3fa8:      	mov	w8, #0x6290             // =25232
    3fac:      	add	x2, x24, #0x858
    3fb0:      	mov	w19, #0x8               // =8
    3fb4:      	mov	w9, #0x4                // =4
    3fb8:      	add	x0, sp, #0xc8
    3fbc:      	mov	w1, #0x8                // =8
    3fc0:      	mov	w20, #0x4               // =4
    3fc4:      	add	x21, x22, x8
    3fc8:      	add	x8, sp, #0xc8
    3fcc:      	blr	x9
    3fd0:      	ldr	x8, [sp, #0xc8]
    3fd4:      	add	x9, sp, #0x58
    3fd8:      	add	x0, sp, #0x58
    3fdc:      	mov	w1, #0x8                // =8
    3fe0:      	add	x8, x8, #0x528
    3fe4:      	ldr	x8, [sp, #0xc8]
    3fe8:      	add	x2, x8, #0x528
    3fec:      	blr	x20
    3ff0:      	str	wzr, [sp, #0xa4]
    3ff4:      	adrp	x0, 0x3000 <generic_usdt_process_event+0x2670>
    3ff8:      	ldr	x19, [sp, #0x58]
    3ffc:      	mov	w8, #0x1                // =1
    4000:      	add	x9, sp, #0xa4
    4004:      	add	x1, sp, #0xa4
    4008:      	ldr	x0, [x0]
    400c:      	blr	x8
    4010:      	cbz	x0, 0x4634 <generic_usdt_process_filter+0xce4>
    4014:      	mov	w8, #0x1000             // =4096
    4018:      	str	x21, [sp, #0x30]
    401c:      	str	x29, [sp, #0x40]
    4020:      	mov	x24, x0
    4024:      	add	x20, x0, #0x1, lsl #12  // =0x1000
    4028:      	str	w8, [x29, #0x550]
    402c:      	mov	w8, #0x23               // =35
    4030:      	blr	x8
    4034:      	add	x2, x0, #0xb30
    4038:      	mov	w23, #0x8               // =8
    403c:      	add	x8, sp, #0xa8
    4040:      	mov	w9, #0x4                // =4
    4044:      	add	x0, sp, #0xa8
    4048:      	mov	w1, #0x8                // =8
    404c:      	mov	w29, #0x4               // =4
    4050:      	blr	x9
    4054:      	ldr	x22, [sp, #0xa8]
    4058:      	add	x25, x19, #0x48
    405c:      	add	x8, sp, #0xb0
    4060:      	mov	w9, #0x4                // =4
    4064:      	add	x0, sp, #0xb0
    4068:      	mov	w1, #0x8                // =8
    406c:      	mov	x2, x25
    4070:      	blr	x9
    4074:      	ldr	x21, [sp, #0xb0]
    4078:      	add	x8, sp, #0x58
    407c:      	add	x0, sp, #0x58
    4080:      	mov	w1, #0x8                // =8
    4084:      	add	x2, x21, #0x10
    4088:      	blr	x29
    408c:      	ldr	x8, [sp, #0x58]
    4090:      	cbz	x8, 0x42d0 <generic_usdt_process_filter+0x980>
    4094:      	ldr	x8, [sp, #0x40]
    4098:      	stp	xzr, xzr, [sp, #0x58]
    409c:      	add	x21, x22, #0x18
    40a0:      	add	x9, sp, #0x58
    40a4:      	add	x2, x22, #0x20
    40a8:      	mov	w22, #0x8               // =8
    40ac:      	stp	x24, xzr, [sp, #0x68]
    40b0:      	add	x0, sp, #0x58
    40b4:      	mov	w1, #0x8                // =8
    40b8:      	add	x29, x19, #0x40
    40bc:      	add	x19, x9, #0x8
    40c0:      	add	x24, x9, #0x18
    40c4:      	stp	xzr, xzr, [sp, #0x78]
    40c8:      	add	x23, x9, #0x20
    40cc:      	str	x20, [sp, #0x88]
    40d0:      	str	x20, [sp, #0x28]
    40d4:      	mov	w20, #0x4               // =4
    40d8:      	ldr	w8, [x8, #0x550]
    40dc:      	strb	wzr, [sp, #0x94]
    40e0:      	str	w8, [sp, #0x90]
    40e4:      	mov	w8, #0x4                // =4
    40e8:      	blr	x8
    40ec:      	mov	w8, #0x4                // =4
    40f0:      	mov	x0, x19
    40f4:      	mov	w1, #0x8                // =8
    40f8:      	mov	x2, x21
    40fc:      	blr	x8
    4100:      	mov	w8, #0x4                // =4
    4104:      	mov	x0, x24
    4108:      	mov	w1, #0x8                // =8
    410c:      	mov	x2, x25
    4110:      	blr	x8
    4114:      	mov	x0, x23
    4118:      	mov	w1, #0x8                // =8
    411c:      	mov	x2, x29
    4120:      	blr	x20
    4124:      	ldr	x8, [sp, #0x78]
    4128:      	sub	x8, x8, #0x20
    412c:      	str	x8, [sp, #0x80]
    4130:      	adrp	x8, 0x4000 <generic_usdt_process_filter+0x6b0>
    4134:      	ldr	x8, [x8]
    4138:      	ldrb	w8, [x8]
    413c:      	cbz	w8, 0x4324 <generic_usdt_process_filter+0x9d4>
    4140:      	mov	w19, #0x800             // =2048
    4144:      	mov	w21, #0x8               // =8
    4148:      	add	x23, sp, #0xb8
    414c:      	add	x29, sp, #0xd8
    4150:      	b	0x41b0 <generic_usdt_process_filter+0x860>
    4154:      	nop
    4158:      	nop
    415c:      	nop
    4160:      	add	x2, x22, #0x10
    4164:      	mov	w8, #0x4                // =4
    4168:      	add	x0, sp, #0xd8
    416c:      	mov	w1, #0x8                // =8
    4170:      	blr	x8
    4174:      	add	x20, sp, #0xd8
    4178:      	ldr	x8, [sp, #0x80]
    417c:      	ldr	x9, [x20]
    4180:      	cmp	x8, x9
    4184:      	b.eq	0x44b0 <generic_usdt_process_filter+0xb60>
    4188:      	add	x2, x22, #0x18
    418c:      	mov	w8, #0x4                // =4
    4190:      	mov	x0, x24
    4194:      	mov	w1, #0x8                // =8
    4198:      	blr	x8
    419c:      	ldr	x8, [x20]
    41a0:      	add	x9, x8, #0x20
    41a4:      	stp	x9, x8, [sp, #0x78]
    41a8:      	subs	w19, w19, #0x1
    41ac:      	b.eq	0x44b8 <generic_usdt_process_filter+0xb68>
    41b0:      	ldp	x20, x2, [sp, #0x70]
    41b4:      	ldp	x8, x9, [sp, #0x58]
    41b8:      	cmp	x20, x8
    41bc:      	ccmp	x2, x9, #0x0, eq
    41c0:      	b.eq	0x44b0 <generic_usdt_process_filter+0xb60>
    41c4:      	ldr	x22, [sp, #0x80]
    41c8:      	mov	w8, #0x4                // =4
    41cc:      	add	x0, sp, #0xb8
    41d0:      	mov	w1, #0x8                // =8
    41d4:      	blr	x8
    41d8:      	ldr	x8, [sp, #0xb8]
    41dc:      	cmp	x20, x8
    41e0:      	b.eq	0x4160 <generic_usdt_process_filter+0x810>
    41e4:      	add	x25, x20, #0x18
    41e8:      	mov	w8, #0x4                // =4
    41ec:      	add	x0, sp, #0xd8
    41f0:      	mov	w1, #0x8                // =8
    41f4:      	mov	x2, x25
    41f8:      	blr	x8
    41fc:      	add	x8, sp, #0xd8
    4200:      	ldr	x8, [x8]
    4204:      	cmp	x8, x20
    4208:      	b.eq	0x4160 <generic_usdt_process_filter+0x810>
    420c:      	mov	w8, #0x4                // =4
    4210:      	add	x9, sp, #0xc0
    4214:      	add	x0, sp, #0xc0
    4218:      	mov	w1, #0x8                // =8
    421c:      	mov	x2, x25
    4220:      	blr	x8
    4224:      	add	x2, x20, #0x20
    4228:      	mov	w8, #0x4                // =4
    422c:      	mov	w9, #0x10               // =16
    4230:      	add	x10, sp, #0xc8
    4234:      	add	x0, sp, #0xc8
    4238:      	mov	w1, #0x10               // =16
    423c:      	blr	x8
    4240:      	ldr	w20, [sp, #0xcc]
    4244:      	ldr	x8, [sp, #0x68]
    4248:      	ldr	x10, [sp, #0x88]
    424c:      	sub	x12, x10, x8
    4250:      	ldr	w22, [sp, #0x90]
    4254:      	subs	w10, w20, w22
    4258:      	ldr	x9, [sp, #0xd0]
    425c:      	csel	w10, wzr, w10, lo
    4260:      	cmp	w22, w20
    4264:      	csel	w11, w22, w20, lo
    4268:      	cinc	w13, w11, hi
    426c:      	sub	w14, w22, w13
    4270:      	subs	x12, x12, x13
    4274:      	str	w14, [sp, #0x90]
    4278:      	b.lo	0x44b8 <generic_usdt_process_filter+0xb68>
    427c:      	cmp	x12, #0xfff
    4280:      	b.hi	0x44b8 <generic_usdt_process_filter+0xb68>
    4284:      	cmp	w22, w20
    4288:      	b.ls	0x4294 <generic_usdt_process_filter+0x944>
    428c:      	mov	w13, #0x2f              // =47
    4290:      	strb	w13, [x8, x12]
    4294:      	add	x25, x8, x12
    4298:      	cmp	w22, w20
    429c:      	add	x2, x9, x10
    42a0:      	and	w1, w11, #0xff
    42a4:      	mov	w8, #0x4                // =4
    42a8:      	cinc	x0, x25, hi
    42ac:      	blr	x8
    42b0:      	cmp	w22, w20
    42b4:      	str	x25, [sp, #0x88]
    42b8:      	b.ls	0x44b8 <generic_usdt_process_filter+0xb68>
    42bc:      	ldr	x8, [sp, #0xc0]
    42c0:      	str	x8, [sp, #0x70]
    42c4:      	subs	w19, w19, #0x1
    42c8:      	b.ne	0x41b0 <generic_usdt_process_filter+0x860>
    42cc:      	b	0x44b8 <generic_usdt_process_filter+0xb68>
    42d0:      	add	x2, x21, #0x18
    42d4:      	mov	w8, #0x8                // =8
    42d8:      	mov	w9, #0x4                // =4
    42dc:      	add	x10, sp, #0x58
    42e0:      	add	x0, sp, #0x58
    42e4:      	mov	w1, #0x8                // =8
    42e8:      	blr	x9
    42ec:      	ldr	x8, [sp, #0x58]
    42f0:      	cmp	x8, x21
    42f4:      	b.eq	0x4094 <generic_usdt_process_filter+0x744>
    42f8:      	ldr	x29, [sp, #0x40]
    42fc:      	ldr	w9, [x29, #0x550]
    4300:      	sub	w8, w9, #0xa
    4304:      	cmp	w9, #0x9
    4308:      	str	w8, [x29, #0x550]
    430c:      	b.gt	0x49e0 <generic_usdt_process_filter+0x1090>
    4310:      	ldr	x21, [sp, #0x30]
    4314:      	mov	w9, #-0x24              // =-36
    4318:      	mov	x24, x20
    431c:      	str	w9, [x29, #0x554]
    4320:      	b	0x451c <generic_usdt_process_filter+0xbcc>
    4324:      	mov	w19, #0x800             // =2048
    4328:      	mov	w21, #0x8               // =8
    432c:      	add	x23, sp, #0xb8
    4330:      	add	x29, sp, #0xd8
    4334:      	b	0x4390 <generic_usdt_process_filter+0xa40>
    4338:      	nop
    433c:      	nop
    4340:      	add	x2, x22, #0x10
    4344:      	mov	w8, #0x4                // =4
    4348:      	add	x0, sp, #0xd8
    434c:      	mov	w1, #0x8                // =8
    4350:      	blr	x8
    4354:      	add	x20, sp, #0xd8
    4358:      	ldr	x8, [sp, #0x80]
    435c:      	ldr	x9, [x20]
    4360:      	cmp	x8, x9
    4364:      	b.eq	0x44b0 <generic_usdt_process_filter+0xb60>
    4368:      	add	x2, x22, #0x18
    436c:      	mov	w8, #0x4                // =4
    4370:      	mov	x0, x24
    4374:      	mov	w1, #0x8                // =8
    4378:      	blr	x8
    437c:      	ldr	x8, [x20]
    4380:      	add	x9, x8, #0x20
    4384:      	stp	x9, x8, [sp, #0x78]
    4388:      	subs	w19, w19, #0x1
    438c:      	b.eq	0x44b8 <generic_usdt_process_filter+0xb68>
    4390:      	ldp	x20, x2, [sp, #0x70]
    4394:      	ldp	x8, x9, [sp, #0x58]
    4398:      	cmp	x20, x8
    439c:      	ccmp	x2, x9, #0x0, eq
    43a0:      	b.eq	0x44b0 <generic_usdt_process_filter+0xb60>
    43a4:      	ldr	x22, [sp, #0x80]
    43a8:      	mov	w8, #0x4                // =4
    43ac:      	add	x0, sp, #0xb8
    43b0:      	mov	w1, #0x8                // =8
    43b4:      	blr	x8
    43b8:      	ldr	x8, [sp, #0xb8]
    43bc:      	cmp	x20, x8
    43c0:      	b.eq	0x4340 <generic_usdt_process_filter+0x9f0>
    43c4:      	add	x25, x20, #0x18
    43c8:      	mov	w8, #0x4                // =4
    43cc:      	add	x0, sp, #0xd8
    43d0:      	mov	w1, #0x8                // =8
    43d4:      	mov	x2, x25
    43d8:      	blr	x8
    43dc:      	add	x8, sp, #0xd8
    43e0:      	ldr	x8, [x8]
    43e4:      	cmp	x8, x20
    43e8:      	b.eq	0x4340 <generic_usdt_process_filter+0x9f0>
    43ec:      	mov	w8, #0x4                // =4
    43f0:      	add	x9, sp, #0xc0
    43f4:      	add	x0, sp, #0xc0
    43f8:      	mov	w1, #0x8                // =8
    43fc:      	mov	x2, x25
    4400:      	blr	x8
    4404:      	add	x2, x20, #0x20
    4408:      	mov	w8, #0x4                // =4
    440c:      	mov	w9, #0x10               // =16
    4410:      	add	x10, sp, #0xc8
    4414:      	add	x0, sp, #0xc8
    4418:      	mov	w1, #0x10               // =16
    441c:      	blr	x8
    4420:      	ldr	w20, [sp, #0xcc]
    4424:      	ldr	x8, [sp, #0x68]
    4428:      	ldr	x10, [sp, #0x88]
    442c:      	sub	x12, x10, x8
    4430:      	ldr	w22, [sp, #0x90]
    4434:      	subs	w10, w20, w22
    4438:      	ldr	x9, [sp, #0xd0]
    443c:      	csel	w10, wzr, w10, lo
    4440:      	cmp	w22, w20
    4444:      	csel	w11, w22, w20, lo
    4448:      	cinc	w13, w11, hi
    444c:      	sub	w14, w22, w13
    4450:      	subs	x12, x12, x13
    4454:      	str	w14, [sp, #0x90]
    4458:      	b.lo	0x44b8 <generic_usdt_process_filter+0xb68>
    445c:      	cmp	x12, #0xfff
    4460:      	b.hi	0x44b8 <generic_usdt_process_filter+0xb68>
    4464:      	cmp	w22, w20
    4468:      	b.ls	0x4474 <generic_usdt_process_filter+0xb24>
    446c:      	mov	w13, #0x2f              // =47
    4470:      	strb	w13, [x8, x12]
    4474:      	add	x25, x8, x12
    4478:      	cmp	w22, w20
    447c:      	add	x2, x9, x10
    4480:      	and	w1, w11, #0xff
    4484:      	mov	w8, #0x4                // =4
    4488:      	cinc	x0, x25, hi
    448c:      	blr	x8
    4490:      	cmp	w22, w20
    4494:      	str	x25, [sp, #0x88]
    4498:      	b.ls	0x44b8 <generic_usdt_process_filter+0xb68>
    449c:      	ldr	x8, [sp, #0xc0]
    44a0:      	str	x8, [sp, #0x70]
    44a4:      	subs	w19, w19, #0x1
    44a8:      	b.ne	0x4390 <generic_usdt_process_filter+0xa40>
    44ac:      	b	0x44b8 <generic_usdt_process_filter+0xb68>
    44b0:      	mov	w8, #0x1                // =1
    44b4:      	strb	w8, [sp, #0x94]
    44b8:      	ldr	x24, [sp, #0x88]
    44bc:      	ldr	x9, [sp, #0x28]
    44c0:      	cmp	x24, x9
    44c4:      	b.eq	0x4508 <generic_usdt_process_filter+0xbb8>
    44c8:      	ldrb	w8, [sp, #0x94]
    44cc:      	ldr	x29, [sp, #0x40]
    44d0:      	cmp	w8, #0x0
    44d4:      	ldr	x21, [sp, #0x30]
    44d8:      	cset	w8, eq
    44dc:      	lsl	w9, w8, #1
    44e0:      	ldr	w8, [sp, #0x90]
    44e4:      	cmp	w8, #0x1
    44e8:      	str	w8, [x29, #0x550]
    44ec:      	str	w9, [x29, #0x554]
    44f0:      	b.lt	0x4500 <generic_usdt_process_filter+0xbb0>
    44f4:      	mov	w9, #0x1000             // =4096
    44f8:      	sub	w8, w9, w8
    44fc:      	str	w8, [x29, #0x550]
    4500:      	cbnz	x24, 0x451c <generic_usdt_process_filter+0xbcc>
    4504:      	b	0x4634 <generic_usdt_process_filter+0xce4>
    4508:      	ldr	x29, [sp, #0x40]
    450c:      	ldr	x21, [sp, #0x30]
    4510:      	mov	w8, wzr
    4514:      	mov	x24, x9
    4518:      	str	xzr, [x29, #0x550]
    451c:      	subs	w9, w8, #0x7f
    4520:      	mov	w10, #0x7f              // =127
    4524:      	mov	x11, x29
    4528:      	mov	x0, x21
    452c:      	mov	x2, x24
    4530:      	csel	w29, w8, w10, lo
    4534:      	csel	w19, wzr, w9, lo
    4538:      	cmp	w8, #0xff
    453c:      	mov	w9, #0xff               // =255
    4540:      	csel	w8, w8, w9, lo
    4544:      	and	w1, w8, #0xff
    4548:      	str	w1, [x11, #0x550]
    454c:      	mov	w8, #0x4                // =4
    4550:      	blr	x8
    4554:      	adrp	x25, 0x4000 <generic_usdt_process_filter+0x6b0>
    4558:      	ldr	x25, [x25]
    455c:      	cbz	x0, 0x45cc <generic_usdt_process_filter+0xc7c>
    4560:      	neg	w8, w0
    4564:      	mov	w9, #0x1                // =1
    4568:      	add	x1, sp, #0x58
    456c:      	strh	w8, [sp, #0x58]
    4570:      	mov	w8, #0x8                // =8
    4574:      	mov	x0, x25
    4578:      	mov	w20, #0x1               // =1
    457c:      	strh	w8, [sp, #0x5a]
    4580:      	mov	x8, #0x2de              // =734
    4584:      	movk	x8, #0x4, lsl #32
    4588:      	stur	x8, [sp, #0x5c]
    458c:      	add	x8, sp, #0x58
    4590:      	blr	x9
    4594:      	cbz	x0, 0x45a8 <generic_usdt_process_filter+0xc58>
    4598:      	ldr	w8, [x0]
    459c:      	add	w8, w8, #0x1
    45a0:      	str	w8, [x0]
    45a4:      	b	0x45cc <generic_usdt_process_filter+0xc7c>
    45a8:      	str	w20, [sp, #0xc8]
    45ac:      	mov	x3, xzr
    45b0:      	mov	w8, #0x2                // =2
    45b4:      	add	x9, sp, #0x58
    45b8:      	add	x10, sp, #0xc8
    45bc:      	add	x1, sp, #0x58
    45c0:      	add	x2, sp, #0xc8
    45c4:      	mov	x0, x25
    45c8:      	blr	x8
    45cc:      	ldr	x9, [sp, #0xe8]
    45d0:      	mov	w8, #0x6390             // =25488
    45d4:      	add	x2, x24, x19
    45d8:      	mov	w1, w29
    45dc:      	add	x0, x9, x8
    45e0:      	mov	w8, #0x4                // =4
    45e4:      	blr	x8
    45e8:      	ldr	x29, [sp, #0x40]
    45ec:      	cbz	x0, 0x4634 <generic_usdt_process_filter+0xce4>
    45f0:      	neg	w8, w0
    45f4:      	mov	w9, #0x1                // =1
    45f8:      	add	x1, sp, #0x58
    45fc:      	strh	w8, [sp, #0x58]
    4600:      	mov	w8, #0x8                // =8
    4604:      	mov	x0, x25
    4608:      	mov	w19, #0x1               // =1
    460c:      	strh	w8, [sp, #0x5a]
    4610:      	mov	x8, #0x2e0              // =736
    4614:      	movk	x8, #0x4, lsl #32
    4618:      	stur	x8, [sp, #0x5c]
    461c:      	add	x8, sp, #0x58
    4620:      	blr	x9
    4624:      	cbz	x0, 0x465c <generic_usdt_process_filter+0xd0c>
    4628:      	ldr	w8, [x0]
    462c:      	add	w8, w8, #0x1
    4630:      	str	w8, [x0]
    4634:      	ldr	w8, [x29, #0x550]
    4638:      	sub	w9, w8, #0x101
    463c:      	cmn	w9, #0x101
    4640:      	b.hi	0x4690 <generic_usdt_process_filter+0xd40>
    4644:      	ldr	x20, [sp, #0x38]
    4648:      	ldr	x22, [sp, #0xe8]
    464c:      	mov	w8, #-0x1               // =-1
    4650:      	ldr	x24, [sp, #0x48]
    4654:      	stur	w8, [x29, #0xb8]
    4658:      	b	0x47e0 <generic_usdt_process_filter+0xe90>
    465c:      	str	w19, [sp, #0xc8]
    4660:      	mov	x3, xzr
    4664:      	mov	w8, #0x2                // =2
    4668:      	add	x9, sp, #0x58
    466c:      	add	x10, sp, #0xc8
    4670:      	add	x1, sp, #0x58
    4674:      	add	x2, sp, #0xc8
    4678:      	mov	x0, x25
    467c:      	blr	x8
    4680:      	ldr	w8, [x29, #0x550]
    4684:      	sub	w9, w8, #0x101
    4688:      	cmn	w9, #0x101
    468c:      	b.ls	0x4644 <generic_usdt_process_filter+0xcf4>
    4690:      	ldr	x22, [sp, #0xe8]
    4694:      	and	x24, x8, #0xff
    4698:      	mov	w8, #0x5f80             // =24448
    469c:      	mov	x2, x21
    46a0:      	mov	w1, w24
    46a4:      	add	x0, x22, x8
    46a8:      	mov	w8, #0x4                // =4
    46ac:      	blr	x8
    46b0:      	mov	x23, x0
    46b4:      	cbz	x0, 0x4730 <generic_usdt_process_filter+0xde0>
    46b8:      	neg	w8, w23
    46bc:      	adrp	x25, 0x4000 <generic_usdt_process_filter+0x6b0>
    46c0:      	mov	w9, #0x1                // =1
    46c4:      	strh	w8, [sp, #0x58]
    46c8:      	mov	w8, #0xf                // =15
    46cc:      	add	x1, sp, #0x58
    46d0:      	mov	w19, #0x1               // =1
    46d4:      	strh	w8, [sp, #0x5a]
    46d8:      	mov	x8, #0x164              // =356
    46dc:      	movk	x8, #0x4, lsl #32
    46e0:      	stur	x8, [sp, #0x5c]
    46e4:      	add	x8, sp, #0x58
    46e8:      	ldr	x25, [x25]
    46ec:      	mov	x0, x25
    46f0:      	blr	x9
    46f4:      	cbz	x0, 0x4708 <generic_usdt_process_filter+0xdb8>
    46f8:      	ldr	w8, [x0]
    46fc:      	add	w8, w8, #0x1
    4700:      	str	w8, [x0]
    4704:      	b	0x472c <generic_usdt_process_filter+0xddc>
    4708:      	str	w19, [sp, #0xc8]
    470c:      	mov	x3, xzr
    4710:      	mov	w8, #0x2                // =2
    4714:      	add	x9, sp, #0x58
    4718:      	add	x10, sp, #0xc8
    471c:      	add	x1, sp, #0x58
    4720:      	add	x2, sp, #0xc8
    4724:      	mov	x0, x25
    4728:      	blr	x8
    472c:      	ldr	x22, [sp, #0xe8]
    4730:      	cmp	w23, #0x0
    4734:      	csel	w8, w24, w23, eq
    4738:      	cmp	w24, #0x7f
    473c:      	stur	w8, [x29, #0xb8]
    4740:      	mov	w8, #0x7f               // =127
    4744:      	csel	w1, w24, w8, lo
    4748:      	mov	w8, #0x6080             // =24704
    474c:      	add	x0, x22, x8
    4750:      	mov	w8, #0x6390             // =25488
    4754:      	add	x2, x22, x8
    4758:      	mov	w8, #0x4                // =4
    475c:      	blr	x8
    4760:      	ldr	x20, [sp, #0x38]
    4764:      	ldr	x24, [sp, #0x48]
    4768:      	cbz	x0, 0x47e0 <generic_usdt_process_filter+0xe90>
    476c:      	neg	w8, w0
    4770:      	adrp	x23, 0x4000 <generic_usdt_process_filter+0x6b0>
    4774:      	mov	w9, #0x1                // =1
    4778:      	strh	w8, [sp, #0x58]
    477c:      	mov	w8, #0xf                // =15
    4780:      	add	x1, sp, #0x58
    4784:      	mov	w19, #0x1               // =1
    4788:      	strh	w8, [sp, #0x5a]
    478c:      	mov	x8, #0x16a              // =362
    4790:      	movk	x8, #0x4, lsl #32
    4794:      	stur	x8, [sp, #0x5c]
    4798:      	add	x8, sp, #0x58
    479c:      	ldr	x23, [x23]
    47a0:      	mov	x0, x23
    47a4:      	blr	x9
    47a8:      	cbz	x0, 0x47bc <generic_usdt_process_filter+0xe6c>
    47ac:      	ldr	w8, [x0]
    47b0:      	add	w8, w8, #0x1
    47b4:      	str	w8, [x0]
    47b8:      	b	0x47e0 <generic_usdt_process_filter+0xe90>
    47bc:      	str	w19, [sp, #0xc8]
    47c0:      	mov	x3, xzr
    47c4:      	mov	w8, #0x2                // =2
    47c8:      	add	x9, sp, #0x58
    47cc:      	add	x10, sp, #0xc8
    47d0:      	add	x1, sp, #0x58
    47d4:      	add	x2, sp, #0xc8
    47d8:      	mov	x0, x23
    47dc:      	blr	x8
    47e0:      	ldrb	w8, [x22, #0x1]
    47e4:      	orr	w8, w8, #0x10
    47e8:      	strb	w8, [x22, #0x1]
    47ec:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    47f0:      	mov	w8, #0x5ef8             // =24312
    47f4:      	ldr	x0, [x0]
    47f8:      	add	x1, x22, x8
    47fc:      	mov	w8, #0x1                // =1
    4800:      	blr	x8
    4804:      	cbz	x0, 0x5c8c <generic_usdt_process_filter+0x233c>
    4808:      	ldr	x21, [x22, #0x5eb8]
    480c:      	cmp	x21, #0x6
    4810:      	b.hs	0x49a8 <generic_usdt_process_filter+0x1058>
    4814:      	ldrsw	x8, [x0]
    4818:      	mov	x23, x0
    481c:      	cbz	w8, 0x49c4 <generic_usdt_process_filter+0x1074>
    4820:      	cmp	x21, x8
    4824:      	b.hs	0x49a8 <generic_usdt_process_filter+0x1058>
    4828:      	str	x8, [sp, #0x28]
    482c:      	stp	x29, x24, [sp, #0x40]
    4830:      	adrp	x24, 0x4000 <generic_usdt_process_filter+0x6b0>
    4834:      	mov	w8, #0x1                // =1
    4838:      	add	x9, sp, #0xd8
    483c:      	str	x22, [sp, #0xe8]
    4840:      	add	x1, sp, #0xd8
    4844:      	str	x20, [sp, #0x38]
    4848:      	str	w21, [sp, #0xd8]
    484c:      	str	wzr, [sp, #0xc0]
    4850:      	ldr	x24, [x24]
    4854:      	mov	x0, x24
    4858:      	blr	x8
    485c:      	cbz	x0, 0x4c6c <generic_usdt_process_filter+0x131c>
    4860:      	ldr	w8, [x0]
    4864:      	mov	x25, x0
    4868:      	cbz	w8, 0x4c6c <generic_usdt_process_filter+0x131c>
    486c:      	ldr	x9, [sp, #0x48]
    4870:      	ldr	w9, [x9, #0x68]
    4874:      	tbnz	w9, #0x1f, 0x5c34 <generic_usdt_process_filter+0x22e4>
    4878:      	cmp	w8, #0x1b
    487c:      	b.hi	0x5c34 <generic_usdt_process_filter+0x22e4>
    4880:      	mov	w9, #0x1                // =1
    4884:      	lsl	w9, w9, w8
    4888:      	tst	w9, #0x60
    488c:      	b.ne	0x4a84 <generic_usdt_process_filter+0x1134>
    4890:      	mov	w10, #0x100             // =256
    4894:      	movk	w10, #0x400, lsl #16
    4898:      	tst	w9, w10
    489c:      	b.ne	0x4a00 <generic_usdt_process_filter+0x10b0>
    48a0:      	mov	w9, #0x1                // =1
    48a4:      	lsl	w8, w9, w8
    48a8:      	mov	w9, #0x200              // =512
    48ac:      	movk	w9, #0x800, lsl #16
    48b0:      	tst	w8, w9
    48b4:      	b.eq	0x5c34 <generic_usdt_process_filter+0x22e4>
    48b8:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    48bc:      	add	x1, x25, #0x4
    48c0:      	mov	w8, #0x1                // =1
    48c4:      	ldr	x0, [x0]
    48c8:      	blr	x8
    48cc:      	cbz	x0, 0x5c34 <generic_usdt_process_filter+0x22e4>
    48d0:      	ldr	x8, [sp, #0x48]
    48d4:      	mov	x20, x0
    48d8:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    48dc:      	mov	w9, #0x7f               // =127
    48e0:      	ldr	w8, [x8, #0x68]
    48e4:      	ldr	x0, [x0]
    48e8:      	add	x1, sp, #0xc0
    48ec:      	cmp	w8, #0x7f
    48f0:      	csel	w19, w8, w9, lt
    48f4:      	mov	w8, #0x1                // =1
    48f8:      	add	x9, sp, #0xc0
    48fc:      	blr	x8
    4900:      	cbz	x0, 0x5c34 <generic_usdt_process_filter+0x22e4>
    4904:      	sxtw	x1, w19
    4908:      	mov	x29, x0
    490c:      	lsl	w8, w1, #3
    4910:      	str	w8, [x0]
    4914:      	ldr	x8, [sp, #0x48]
    4918:      	ldr	w8, [x8, #0x6c]
    491c:      	cbnz	w8, 0x497c <generic_usdt_process_filter+0x102c>
    4920:      	ldr	x11, [sp, #0x48]
    4924:      	and	w13, w1, #0x7f
    4928:      	mov	x8, xzr
    492c:      	ldr	w12, [x11, #0x68]
    4930:      	add	x9, x11, #0x1f0
    4934:      	add	x10, x11, #0x170
    4938:      	sub	w11, w12, w1
    493c:      	add	w12, w12, w13
    4940:      	add	w11, w11, w13
    4944:      	mvn	w13, w1
    4948:      	add	w12, w13, w12
    494c:      	cmp	x8, #0x7f
    4950:      	b.eq	0x4970 <generic_usdt_process_filter+0x1020>
    4954:      	and	x13, x12, #0x7f
    4958:      	sub	w12, w12, #0x1
    495c:      	ldrb	w13, [x10, x13]
    4960:      	strb	w13, [x9, x8]
    4964:      	add	x8, x8, #0x1
    4968:      	cmp	x11, x8
    496c:      	b.ne	0x494c <generic_usdt_process_filter+0xffc>
    4970:      	ldr	x9, [sp, #0x48]
    4974:      	mov	w8, #0x1                // =1
    4978:      	str	w8, [x9, #0x6c]
    497c:      	cmp	w1, #0x7f
    4980:      	b.hi	0x499c <generic_usdt_process_filter+0x104c>
    4984:      	ldr	x8, [sp, #0x48]
    4988:      	add	x0, x29, #0x4
    498c:      	add	x2, x8, #0x1f0
    4990:      	mov	w8, #0x4                // =4
    4994:      	blr	x8
    4998:      	tbnz	x0, #0x3f, 0x5c34 <generic_usdt_process_filter+0x22e4>
    499c:      	mov	w8, #0x1                // =1
    49a0:      	mov	x0, x20
    49a4:      	b	0x4a7c <generic_usdt_process_filter+0x112c>
    49a8:      	ldr	w8, [x24]
    49ac:      	str	w8, [x22, #0x10]
    49b0:      	ldr	x8, [x24, #0x8]
    49b4:      	str	x8, [x22, #0x18]
    49b8:      	ldrb	w8, [x29]
    49bc:      	cbnz	w8, 0x5c70 <generic_usdt_process_filter+0x2320>
    49c0:      	b	0x5c8c <generic_usdt_process_filter+0x233c>
    49c4:      	mov	w8, #0x1                // =1
    49c8:      	strb	w8, [x29]
    49cc:      	ldr	w8, [x24]
    49d0:      	str	w8, [x22, #0x10]
    49d4:      	ldr	x8, [x24, #0x8]
    49d8:      	str	x8, [x22, #0x18]
    49dc:      	b	0x5c70 <generic_usdt_process_filter+0x2320>
    49e0:      	mov	w8, #0x2964             // =10596
    49e4:      	add	x20, x24, #0xff6
    49e8:      	strh	w8, [x24, #0xffe]
    49ec:      	adrp	x8, 0x4000 <generic_usdt_process_filter+0x6b0>
    49f0:      	add	x8, x8, #0x0
    49f4:      	ldr	x8, [x8]
    49f8:      	str	x8, [x20]
    49fc:      	b	0x4094 <generic_usdt_process_filter+0x744>
    4a00:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4a04:      	add	x1, x25, #0x4
    4a08:      	mov	w8, #0x1                // =1
    4a0c:      	ldr	x0, [x0]
    4a10:      	blr	x8
    4a14:      	cbz	x0, 0x5c34 <generic_usdt_process_filter+0x22e4>
    4a18:      	mov	x19, x0
    4a1c:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4a20:      	mov	w8, #0x1                // =1
    4a24:      	ldr	x0, [x0]
    4a28:      	add	x9, sp, #0xc0
    4a2c:      	add	x1, sp, #0xc0
    4a30:      	blr	x8
    4a34:      	cbz	x0, 0x5c34 <generic_usdt_process_filter+0x22e4>
    4a38:      	mov	w1, wzr
    4a3c:      	mov	w2, #0x104              // =260
    4a40:      	mov	x29, x0
    4a44:      	bl	0x4a44 <generic_usdt_process_filter+0x10f4>
    4a48:      	ldr	x10, [sp, #0x48]
    4a4c:      	mov	x0, x29
    4a50:      	ldr	w8, [x10, #0x68]
    4a54:      	add	x2, x10, #0x70
    4a58:      	lsl	w9, w8, #3
    4a5c:      	and	x8, x8, #0xff
    4a60:      	str	w9, [x0], #0x4
    4a64:      	mov	w9, #0x4                // =4
    4a68:      	ldrb	w1, [x10, #0x68]
    4a6c:      	blr	x9
    4a70:      	tbnz	x0, #0x3f, 0x5c34 <generic_usdt_process_filter+0x22e4>
    4a74:      	mov	w8, #0x1                // =1
    4a78:      	mov	x0, x19
    4a7c:      	mov	x1, x29
    4a80:      	b	0x4c34 <generic_usdt_process_filter+0x12e4>
    4a84:      	str	wzr, [sp, #0xc8]
    4a88:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4a8c:      	mov	w8, #0x1                // =1
    4a90:      	add	x9, sp, #0xc8
    4a94:      	ldr	x0, [x0]
    4a98:      	add	x1, sp, #0xc8
    4a9c:      	blr	x8
    4aa0:      	cbz	x0, 0x4be0 <generic_usdt_process_filter+0x1290>
    4aa4:      	ldr	x9, [sp, #0x48]
    4aa8:      	ldr	x8, [x0]
    4aac:      	ldr	x9, [x9, #0x378]
    4ab0:      	cmp	x8, x9
    4ab4:      	b.eq	0x4be0 <generic_usdt_process_filter+0x1290>
    4ab8:      	str	x0, [sp, #0x30]
    4abc:      	adrp	x8, 0x4000 <generic_usdt_process_filter+0x6b0>
    4ac0:      	mov	w20, wzr
    4ac4:      	mov	x19, xzr
    4ac8:      	ldr	x8, [x8]
    4acc:      	ldrb	w8, [x8]
    4ad0:      	ldr	x9, [sp, #0x48]
    4ad4:      	add	x22, x9, #0x370
    4ad8:      	cbz	w8, 0x4ba8 <generic_usdt_process_filter+0x1258>
    4adc:      	ldr	x8, [sp, #0x48]
    4ae0:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4ae4:      	add	x9, sp, #0x58
    4ae8:      	add	x1, sp, #0x58
    4aec:      	ldr	w8, [x8, #0x10]
    4af0:      	str	w8, [sp, #0x58]
    4af4:      	mov	w8, #0x1                // =1
    4af8:      	ldr	x0, [x0]
    4afc:      	blr	x8
    4b00:      	cbz	x0, 0x4bd0 <generic_usdt_process_filter+0x1280>
    4b04:      	mov	x29, x0
    4b08:      	add	x1, x0, #0x70
    4b0c:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4b10:      	ldr	x0, [x0]
    4b14:      	mov	w8, #0x1                // =1
    4b18:      	blr	x8
    4b1c:      	cbz	x0, 0x4b38 <generic_usdt_process_filter+0x11e8>
    4b20:      	ldr	x8, [x0]
    4b24:      	cbz	x8, 0x4b38 <generic_usdt_process_filter+0x11e8>
    4b28:      	ldaxr	x9, [x22]
    4b2c:      	orr	x9, x9, x8
    4b30:      	stlxr	w10, x9, [x22]
    4b34:      	cbnz	w10, 0x4b28 <generic_usdt_process_filter+0x11d8>
    4b38:      	cmp	x29, x19
    4b3c:      	b.eq	0x4bd0 <generic_usdt_process_filter+0x1280>
    4b40:      	mov	w8, #0x86a0             // =34464
    4b44:      	add	w20, w20, #0x1
    4b48:      	mov	x19, x29
    4b4c:      	movk	w8, #0x1, lsl #16
    4b50:      	cmp	w20, w8
    4b54:      	b.ne	0x4adc <generic_usdt_process_filter+0x118c>
    4b58:      	b	0x4bd0 <generic_usdt_process_filter+0x1280>
    4b5c:      	mov	x29, x0
    4b60:      	add	x1, x0, #0x70
    4b64:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4b68:      	ldr	x0, [x0]
    4b6c:      	mov	w8, #0x1                // =1
    4b70:      	blr	x8
    4b74:      	cbz	x0, 0x4b90 <generic_usdt_process_filter+0x1240>
    4b78:      	ldr	x8, [x0]
    4b7c:      	cbz	x8, 0x4b90 <generic_usdt_process_filter+0x1240>
    4b80:      	ldaxr	x9, [x22]
    4b84:      	orr	x9, x9, x8
    4b88:      	stlxr	w10, x9, [x22]
    4b8c:      	cbnz	w10, 0x4b80 <generic_usdt_process_filter+0x1230>
    4b90:      	cmp	x29, x19
    4b94:      	b.eq	0x4bd0 <generic_usdt_process_filter+0x1280>
    4b98:      	add	w20, w20, #0x1
    4b9c:      	mov	x19, x29
    4ba0:      	cmp	w20, #0x400
    4ba4:      	b.eq	0x4bd0 <generic_usdt_process_filter+0x1280>
    4ba8:      	ldr	x8, [sp, #0x48]
    4bac:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4bb0:      	add	x9, sp, #0x58
    4bb4:      	add	x1, sp, #0x58
    4bb8:      	ldr	w8, [x8, #0x10]
    4bbc:      	str	w8, [sp, #0x58]
    4bc0:      	mov	w8, #0x1                // =1
    4bc4:      	ldr	x0, [x0]
    4bc8:      	blr	x8
    4bcc:      	cbnz	x0, 0x4b5c <generic_usdt_process_filter+0x120c>
    4bd0:      	ldr	x8, [sp, #0x30]
    4bd4:      	ldr	x9, [sp, #0x48]
    4bd8:      	ldr	x8, [x8]
    4bdc:      	str	x8, [x9, #0x378]
    4be0:      	ldr	w8, [x25, #0x8]
    4be4:      	cmn	w8, #0x1
    4be8:      	b.eq	0x4c0c <generic_usdt_process_filter+0x12bc>
    4bec:      	ldr	x9, [sp, #0x48]
    4bf0:      	ldr	x9, [x9, #0x370]
    4bf4:      	lsr	x8, x9, x8
    4bf8:      	tbz	w8, #0x0, 0x4c0c <generic_usdt_process_filter+0x12bc>
    4bfc:      	mov	x0, #0xffee             // =65518
    4c00:      	movk	x0, #0xadc0, lsl #16
    4c04:      	movk	x0, #0xb, lsl #32
    4c08:      	b	0x4c38 <generic_usdt_process_filter+0x12e8>
    4c0c:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4c10:      	mov	w8, #0x1                // =1
    4c14:      	add	x9, sp, #0xd8
    4c18:      	ldr	x0, [x0]
    4c1c:      	add	x1, sp, #0xd8
    4c20:      	blr	x8
    4c24:      	cbz	x0, 0x5c34 <generic_usdt_process_filter+0x22e4>
    4c28:      	ldr	x8, [sp, #0x48]
    4c2c:      	add	x1, x8, #0x70
    4c30:      	mov	w8, #0x1                // =1
    4c34:      	blr	x8
    4c38:      	ldr	w8, [x25]
    4c3c:      	cmp	w8, #0x25
    4c40:      	b.hi	0x4c68 <generic_usdt_process_filter+0x1318>
    4c44:      	mov	w9, #0x1                // =1
    4c48:      	lsl	x8, x9, x8
    4c4c:      	mov	x9, #0x50               // =80
    4c50:      	movk	x9, #0xc00, lsl #16
    4c54:      	movk	x9, #0x20, lsl #32
    4c58:      	tst	x8, x9
    4c5c:      	b.eq	0x4c68 <generic_usdt_process_filter+0x1318>
    4c60:      	cbnz	x0, 0x5c34 <generic_usdt_process_filter+0x22e4>
    4c64:      	b	0x4c6c <generic_usdt_process_filter+0x131c>
    4c68:      	cbz	x0, 0x5c34 <generic_usdt_process_filter+0x22e4>
    4c6c:      	adrp	x8, 0x4000 <generic_usdt_process_filter+0x6b0>
    4c70:      	ldr	x8, [x8]
    4c74:      	ldrb	w8, [x8]
    4c78:      	cbz	w8, 0x5040 <generic_usdt_process_filter+0x16f0>
    4c7c:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4c80:      	mov	w8, #0x1                // =1
    4c84:      	ldr	x0, [x0]
    4c88:      	ldr	x1, [sp, #0x48]
    4c8c:      	blr	x8
    4c90:      	cbz	x0, 0x5040 <generic_usdt_process_filter+0x16f0>
    4c94:      	add	w8, w21, #0x5
    4c98:      	str	wzr, [sp, #0xc0]
    4c9c:      	add	x9, sp, #0xd8
    4ca0:      	mov	x25, x0
    4ca4:      	str	w8, [sp, #0xd8]
    4ca8:      	mov	w8, #0x1                // =1
    4cac:      	add	x1, sp, #0xd8
    4cb0:      	mov	x0, x24
    4cb4:      	blr	x8
    4cb8:      	cbz	x0, 0x5040 <generic_usdt_process_filter+0x16f0>
    4cbc:      	ldr	w8, [x0]
    4cc0:      	mov	x24, x0
    4cc4:      	cbz	w8, 0x5040 <generic_usdt_process_filter+0x16f0>
    4cc8:      	ldr	w9, [x25]
    4ccc:      	tbnz	w9, #0x1f, 0x5c34 <generic_usdt_process_filter+0x22e4>
    4cd0:      	cmp	w8, #0x1b
    4cd4:      	b.hi	0x5c34 <generic_usdt_process_filter+0x22e4>
    4cd8:      	mov	w9, #0x1                // =1
    4cdc:      	lsl	w9, w9, w8
    4ce0:      	tst	w9, #0x60
    4ce4:      	b.ne	0x4e6c <generic_usdt_process_filter+0x151c>
    4ce8:      	mov	w10, #0x100             // =256
    4cec:      	movk	w10, #0x400, lsl #16
    4cf0:      	tst	w9, w10
    4cf4:      	b.ne	0x4dec <generic_usdt_process_filter+0x149c>
    4cf8:      	mov	w9, #0x1                // =1
    4cfc:      	lsl	w8, w9, w8
    4d00:      	mov	w9, #0x200              // =512
    4d04:      	movk	w9, #0x800, lsl #16
    4d08:      	tst	w8, w9
    4d0c:      	b.eq	0x5c34 <generic_usdt_process_filter+0x22e4>
    4d10:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4d14:      	add	x1, x24, #0x4
    4d18:      	mov	w8, #0x1                // =1
    4d1c:      	ldr	x0, [x0]
    4d20:      	blr	x8
    4d24:      	cbz	x0, 0x5c34 <generic_usdt_process_filter+0x22e4>
    4d28:      	ldr	w8, [x25]
    4d2c:      	mov	x20, x0
    4d30:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4d34:      	mov	w9, #0x7f               // =127
    4d38:      	ldr	x0, [x0]
    4d3c:      	add	x1, sp, #0xc0
    4d40:      	cmp	w8, #0x7f
    4d44:      	csel	w19, w8, w9, lt
    4d48:      	mov	w8, #0x1                // =1
    4d4c:      	add	x9, sp, #0xc0
    4d50:      	blr	x8
    4d54:      	cbz	x0, 0x5c34 <generic_usdt_process_filter+0x22e4>
    4d58:      	sxtw	x1, w19
    4d5c:      	mov	x29, x0
    4d60:      	lsl	w8, w1, #3
    4d64:      	str	w8, [x0]
    4d68:      	ldr	w8, [x25, #0x4]
    4d6c:      	cbnz	w8, 0x4dc4 <generic_usdt_process_filter+0x1474>
    4d70:      	ldr	w12, [x25]
    4d74:      	and	w13, w1, #0x7f
    4d78:      	mov	x8, xzr
    4d7c:      	add	x9, x25, #0x188
    4d80:      	add	x10, x25, #0x108
    4d84:      	sub	w11, w12, w1
    4d88:      	add	w12, w12, w13
    4d8c:      	add	w11, w11, w13
    4d90:      	mvn	w13, w1
    4d94:      	add	w12, w13, w12
    4d98:      	cmp	x8, #0x7f
    4d9c:      	b.eq	0x4dbc <generic_usdt_process_filter+0x146c>
    4da0:      	and	x13, x12, #0x7f
    4da4:      	sub	w12, w12, #0x1
    4da8:      	ldrb	w13, [x10, x13]
    4dac:      	strb	w13, [x9, x8]
    4db0:      	add	x8, x8, #0x1
    4db4:      	cmp	x11, x8
    4db8:      	b.ne	0x4d98 <generic_usdt_process_filter+0x1448>
    4dbc:      	mov	w8, #0x1                // =1
    4dc0:      	str	w8, [x25, #0x4]
    4dc4:      	cmp	w1, #0x7f
    4dc8:      	b.hi	0x4de0 <generic_usdt_process_filter+0x1490>
    4dcc:      	add	x0, x29, #0x4
    4dd0:      	add	x2, x25, #0x188
    4dd4:      	mov	w8, #0x4                // =4
    4dd8:      	blr	x8
    4ddc:      	tbnz	x0, #0x3f, 0x5c34 <generic_usdt_process_filter+0x22e4>
    4de0:      	mov	w8, #0x1                // =1
    4de4:      	mov	x0, x20
    4de8:      	b	0x4e64 <generic_usdt_process_filter+0x1514>
    4dec:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4df0:      	add	x1, x24, #0x4
    4df4:      	mov	w8, #0x1                // =1
    4df8:      	ldr	x0, [x0]
    4dfc:      	blr	x8
    4e00:      	cbz	x0, 0x5c34 <generic_usdt_process_filter+0x22e4>
    4e04:      	mov	x19, x0
    4e08:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4e0c:      	mov	w8, #0x1                // =1
    4e10:      	ldr	x0, [x0]
    4e14:      	add	x9, sp, #0xc0
    4e18:      	add	x1, sp, #0xc0
    4e1c:      	blr	x8
    4e20:      	cbz	x0, 0x5c34 <generic_usdt_process_filter+0x22e4>
    4e24:      	mov	w1, wzr
    4e28:      	mov	w2, #0x104              // =260
    4e2c:      	mov	x29, x0
    4e30:      	bl	0x4e30 <generic_usdt_process_filter+0x14e0>
    4e34:      	ldr	w8, [x25]
    4e38:      	mov	x0, x29
    4e3c:      	add	x2, x25, #0x8
    4e40:      	lsl	w9, w8, #3
    4e44:      	and	x8, x8, #0xff
    4e48:      	str	w9, [x0], #0x4
    4e4c:      	mov	w9, #0x4                // =4
    4e50:      	ldrb	w1, [x25]
    4e54:      	blr	x9
    4e58:      	tbnz	x0, #0x3f, 0x5c34 <generic_usdt_process_filter+0x22e4>
    4e5c:      	mov	w8, #0x1                // =1
    4e60:      	mov	x0, x19
    4e64:      	mov	x1, x29
    4e68:      	b	0x5008 <generic_usdt_process_filter+0x16b8>
    4e6c:      	str	wzr, [sp, #0xc8]
    4e70:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4e74:      	mov	w8, #0x1                // =1
    4e78:      	add	x9, sp, #0xc8
    4e7c:      	ldr	x0, [x0]
    4e80:      	add	x1, sp, #0xc8
    4e84:      	blr	x8
    4e88:      	cbz	x0, 0x4fbc <generic_usdt_process_filter+0x166c>
    4e8c:      	ldr	x8, [x0]
    4e90:      	ldr	x9, [x25, #0x310]
    4e94:      	cmp	x8, x9
    4e98:      	b.eq	0x4fbc <generic_usdt_process_filter+0x166c>
    4e9c:      	str	x0, [sp, #0x30]
    4ea0:      	adrp	x8, 0x4000 <generic_usdt_process_filter+0x6b0>
    4ea4:      	add	x22, x25, #0x308
    4ea8:      	mov	w20, wzr
    4eac:      	ldr	x8, [x8]
    4eb0:      	mov	x19, xzr
    4eb4:      	ldrb	w8, [x8]
    4eb8:      	cbz	w8, 0x4f88 <generic_usdt_process_filter+0x1638>
    4ebc:      	ldr	x8, [sp, #0x48]
    4ec0:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4ec4:      	add	x9, sp, #0x58
    4ec8:      	add	x1, sp, #0x58
    4ecc:      	ldr	w8, [x8, #0x10]
    4ed0:      	str	w8, [sp, #0x58]
    4ed4:      	mov	w8, #0x1                // =1
    4ed8:      	ldr	x0, [x0]
    4edc:      	blr	x8
    4ee0:      	cbz	x0, 0x4fb0 <generic_usdt_process_filter+0x1660>
    4ee4:      	mov	x29, x0
    4ee8:      	add	x1, x0, #0x70
    4eec:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4ef0:      	ldr	x0, [x0]
    4ef4:      	mov	w8, #0x1                // =1
    4ef8:      	blr	x8
    4efc:      	cbz	x0, 0x4f18 <generic_usdt_process_filter+0x15c8>
    4f00:      	ldr	x8, [x0]
    4f04:      	cbz	x8, 0x4f18 <generic_usdt_process_filter+0x15c8>
    4f08:      	ldaxr	x9, [x22]
    4f0c:      	orr	x9, x9, x8
    4f10:      	stlxr	w10, x9, [x22]
    4f14:      	cbnz	w10, 0x4f08 <generic_usdt_process_filter+0x15b8>
    4f18:      	cmp	x29, x19
    4f1c:      	b.eq	0x4fb0 <generic_usdt_process_filter+0x1660>
    4f20:      	mov	w8, #0x86a0             // =34464
    4f24:      	add	w20, w20, #0x1
    4f28:      	mov	x19, x29
    4f2c:      	movk	w8, #0x1, lsl #16
    4f30:      	cmp	w20, w8
    4f34:      	b.ne	0x4ebc <generic_usdt_process_filter+0x156c>
    4f38:      	b	0x4fb0 <generic_usdt_process_filter+0x1660>
    4f3c:      	mov	x29, x0
    4f40:      	add	x1, x0, #0x70
    4f44:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4f48:      	ldr	x0, [x0]
    4f4c:      	mov	w8, #0x1                // =1
    4f50:      	blr	x8
    4f54:      	cbz	x0, 0x4f70 <generic_usdt_process_filter+0x1620>
    4f58:      	ldr	x8, [x0]
    4f5c:      	cbz	x8, 0x4f70 <generic_usdt_process_filter+0x1620>
    4f60:      	ldaxr	x9, [x22]
    4f64:      	orr	x9, x9, x8
    4f68:      	stlxr	w10, x9, [x22]
    4f6c:      	cbnz	w10, 0x4f60 <generic_usdt_process_filter+0x1610>
    4f70:      	cmp	x29, x19
    4f74:      	b.eq	0x4fb0 <generic_usdt_process_filter+0x1660>
    4f78:      	add	w20, w20, #0x1
    4f7c:      	mov	x19, x29
    4f80:      	cmp	w20, #0x400
    4f84:      	b.eq	0x4fb0 <generic_usdt_process_filter+0x1660>
    4f88:      	ldr	x8, [sp, #0x48]
    4f8c:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4f90:      	add	x9, sp, #0x58
    4f94:      	add	x1, sp, #0x58
    4f98:      	ldr	w8, [x8, #0x10]
    4f9c:      	str	w8, [sp, #0x58]
    4fa0:      	mov	w8, #0x1                // =1
    4fa4:      	ldr	x0, [x0]
    4fa8:      	blr	x8
    4fac:      	cbnz	x0, 0x4f3c <generic_usdt_process_filter+0x15ec>
    4fb0:      	ldr	x8, [sp, #0x30]
    4fb4:      	ldr	x8, [x8]
    4fb8:      	str	x8, [x25, #0x310]
    4fbc:      	ldr	w8, [x24, #0x8]
    4fc0:      	cmn	w8, #0x1
    4fc4:      	b.eq	0x4fe4 <generic_usdt_process_filter+0x1694>
    4fc8:      	ldr	x9, [x25, #0x308]
    4fcc:      	lsr	x8, x9, x8
    4fd0:      	tbz	w8, #0x0, 0x4fe4 <generic_usdt_process_filter+0x1694>
    4fd4:      	mov	x0, #0xffee             // =65518
    4fd8:      	movk	x0, #0xadc0, lsl #16
    4fdc:      	movk	x0, #0xb, lsl #32
    4fe0:      	b	0x500c <generic_usdt_process_filter+0x16bc>
    4fe4:      	adrp	x0, 0x4000 <generic_usdt_process_filter+0x6b0>
    4fe8:      	mov	w8, #0x1                // =1
    4fec:      	add	x9, sp, #0xd8
    4ff0:      	ldr	x0, [x0]
    4ff4:      	add	x1, sp, #0xd8
    4ff8:      	blr	x8
    4ffc:      	cbz	x0, 0x5c34 <generic_usdt_process_filter+0x22e4>
    5000:      	add	x1, x25, #0x8
    5004:      	mov	w8, #0x1                // =1
    5008:      	blr	x8
    500c:      	ldr	w8, [x24]
    5010:      	cmp	w8, #0x25
    5014:      	b.hi	0x503c <generic_usdt_process_filter+0x16ec>
    5018:      	mov	w9, #0x1                // =1
    501c:      	lsl	x8, x9, x8
    5020:      	mov	x9, #0x50               // =80
    5024:      	movk	x9, #0xc00, lsl #16
    5028:      	movk	x9, #0x20, lsl #32
    502c:      	tst	x8, x9
    5030:      	b.eq	0x503c <generic_usdt_process_filter+0x16ec>
    5034:      	cbnz	x0, 0x5c34 <generic_usdt_process_filter+0x22e4>
    5038:      	b	0x5040 <generic_usdt_process_filter+0x16f0>
    503c:      	cbz	x0, 0x5c34 <generic_usdt_process_filter+0x22e4>
    5040:      	lsl	w8, w21, #2
    5044:      	add	x9, x8, #0x4
    5048:      	ldr	w8, [x9, x23]
    504c:      	add	w9, w8, w9
    5050:      	and	w11, w9, #0x3ff
    5054:      	add	w9, w9, #0x4
    5058:      	and	x9, x9, #0x3ff
    505c:      	add	x10, x11, #0x8
    5060:      	ldr	w9, [x9, x23]
    5064:      	cmp	w9, #0x5
    5068:      	b.lo	0x50f8 <generic_usdt_process_filter+0x17a8>
    506c:      	add	x9, x10, x23
    5070:      	ldr	w10, [x9, #0x8]
    5074:      	ldp	w12, w22, [x9]
    5078:      	stp	x9, x11, [sp, #0x8]
    507c:      	mov	w9, #0x4                // =4
    5080:      	cmp	w10, #0x4
    5084:      	stp	xzr, xzr, [sp, #0x58]
    5088:      	csel	w9, w10, w9, lo
    508c:      	cmp	w12, #0x6
    5090:      	b.ne	0x509c <generic_usdt_process_filter+0x174c>
    5094:      	mov	x11, #0x100000001       // =4294967297
    5098:      	stp	x11, x11, [sp, #0x58]
    509c:      	cbz	w10, 0x5500 <generic_usdt_process_filter+0x1bb0>
    50a0:      	ldr	x10, [sp, #0x48]
    50a4:      	add	w8, w8, w21, lsl #2
    50a8:      	tst	x22, #0x1
    50ac:      	add	x25, sp, #0x58
    50b0:      	str	w12, [sp, #0x30]
    50b4:      	add	w8, w8, #0x4
    50b8:      	and	x8, x8, #0x3ff
    50bc:      	add	x21, x8, #0x14
    50c0:      	sub	x8, x9, #0x1
    50c4:      	mov	w9, #0x3                // =3
    50c8:      	add	x11, x10, #0x24
    50cc:      	str	x11, [sp, #0x20]
    50d0:      	csel	x11, x10, x11, eq
    50d4:      	cmp	x8, #0x3
    50d8:      	add	x10, x10, #0x10
    50dc:      	csel	x8, x8, x9, lo
    50e0:      	and	x9, x21, #0x7fc
    50e4:      	mov	x20, x11
    50e8:      	str	x10, [sp, #0x18]
    50ec:      	add	x19, x23, x9
    50f0:      	add	x24, x8, #0x1
    50f4:      	b	0x5130 <generic_usdt_process_filter+0x17e0>
    50f8:      	mov	w9, #0x1                // =1
    50fc:      	mov	w8, w10
    5100:      	b	0x5548 <generic_usdt_process_filter+0x1bf8>
    5104:      	mov	w8, #0x1                // =1
    5108:      	ldr	w12, [sp, #0x30]
    510c:      	mov	x11, x20
    5110:      	cmp	w12, #0x6
    5114:      	eor	w8, w8, #0x1
    5118:      	csinc	w9, w8, wzr, eq
    511c:      	str	w9, [x25], #0x4
    5120:      	add	x21, x21, #0x4
    5124:      	add	x19, x19, #0x4
    5128:      	subs	x24, x24, #0x1
    512c:      	b.eq	0x5500 <generic_usdt_process_filter+0x1bb0>
    5130:      	cmp	x21, #0x3e8
    5134:      	b.ls	0x5358 <generic_usdt_process_filter+0x1a08>
    5138:      	mov	x29, xzr
    513c:      	tbz	w22, #0x1, 0x5360 <generic_usdt_process_filter+0x1a10>
    5140:      	tbnz	w22, #0x0, 0x538c <generic_usdt_process_filter+0x1a3c>
    5144:      	ldr	x10, [sp, #0x48]
    5148:      	mov	w8, #0x1                // =1
    514c:      	ldr	w9, [x10]
    5150:      	cmp	x29, x9
    5154:      	b.eq	0x5110 <generic_usdt_process_filter+0x17c0>
    5158:      	ldr	w9, [x10, #0x10]
    515c:      	cmp	x29, x9
    5160:      	b.eq	0x5110 <generic_usdt_process_filter+0x17c0>
    5164:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    5168:      	mov	w8, #0x1                // =1
    516c:      	ldr	x0, [x0]
    5170:      	ldr	x1, [sp, #0x18]
    5174:      	blr	x8
    5178:      	cbz	x0, 0x54e4 <generic_usdt_process_filter+0x1b94>
    517c:      	ldr	w9, [x0]
    5180:      	mov	x1, x0
    5184:      	mov	w8, #0x1                // =1
    5188:      	cmp	x29, x9
    518c:      	b.eq	0x5108 <generic_usdt_process_filter+0x17b8>
    5190:      	ldr	w9, [x1, #0x10]!
    5194:      	ldr	w12, [sp, #0x30]
    5198:      	mov	x11, x20
    519c:      	cmp	x29, x9
    51a0:      	b.eq	0x5110 <generic_usdt_process_filter+0x17c0>
    51a4:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    51a8:      	mov	w8, #0x1                // =1
    51ac:      	ldr	x0, [x0]
    51b0:      	blr	x8
    51b4:      	cbz	x0, 0x54e4 <generic_usdt_process_filter+0x1b94>
    51b8:      	ldr	w9, [x0]
    51bc:      	mov	x1, x0
    51c0:      	mov	w8, #0x1                // =1
    51c4:      	cmp	x29, x9
    51c8:      	b.eq	0x5108 <generic_usdt_process_filter+0x17b8>
    51cc:      	ldr	w9, [x1, #0x10]!
    51d0:      	ldr	w12, [sp, #0x30]
    51d4:      	mov	x11, x20
    51d8:      	cmp	x29, x9
    51dc:      	b.eq	0x5110 <generic_usdt_process_filter+0x17c0>
    51e0:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    51e4:      	mov	w8, #0x1                // =1
    51e8:      	ldr	x0, [x0]
    51ec:      	blr	x8
    51f0:      	cbz	x0, 0x54e4 <generic_usdt_process_filter+0x1b94>
    51f4:      	ldr	w9, [x0]
    51f8:      	mov	x1, x0
    51fc:      	mov	w8, #0x1                // =1
    5200:      	cmp	x29, x9
    5204:      	b.eq	0x5108 <generic_usdt_process_filter+0x17b8>
    5208:      	ldr	w9, [x1, #0x10]!
    520c:      	ldr	w12, [sp, #0x30]
    5210:      	mov	x11, x20
    5214:      	cmp	x29, x9
    5218:      	b.eq	0x5110 <generic_usdt_process_filter+0x17c0>
    521c:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    5220:      	mov	w8, #0x1                // =1
    5224:      	ldr	x0, [x0]
    5228:      	blr	x8
    522c:      	cbz	x0, 0x54e4 <generic_usdt_process_filter+0x1b94>
    5230:      	ldr	w9, [x0]
    5234:      	mov	x1, x0
    5238:      	mov	w8, #0x1                // =1
    523c:      	cmp	x29, x9
    5240:      	b.eq	0x5108 <generic_usdt_process_filter+0x17b8>
    5244:      	ldr	w9, [x1, #0x10]!
    5248:      	ldr	w12, [sp, #0x30]
    524c:      	mov	x11, x20
    5250:      	cmp	x29, x9
    5254:      	b.eq	0x5110 <generic_usdt_process_filter+0x17c0>
    5258:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    525c:      	mov	w8, #0x1                // =1
    5260:      	ldr	x0, [x0]
    5264:      	blr	x8
    5268:      	cbz	x0, 0x54e4 <generic_usdt_process_filter+0x1b94>
    526c:      	ldr	w9, [x0]
    5270:      	mov	x1, x0
    5274:      	mov	w8, #0x1                // =1
    5278:      	cmp	x29, x9
    527c:      	b.eq	0x5108 <generic_usdt_process_filter+0x17b8>
    5280:      	ldr	w9, [x1, #0x10]!
    5284:      	ldr	w12, [sp, #0x30]
    5288:      	mov	x11, x20
    528c:      	cmp	x29, x9
    5290:      	b.eq	0x5110 <generic_usdt_process_filter+0x17c0>
    5294:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    5298:      	mov	w8, #0x1                // =1
    529c:      	ldr	x0, [x0]
    52a0:      	blr	x8
    52a4:      	cbz	x0, 0x54e4 <generic_usdt_process_filter+0x1b94>
    52a8:      	ldr	w9, [x0]
    52ac:      	mov	x1, x0
    52b0:      	mov	w8, #0x1                // =1
    52b4:      	cmp	x29, x9
    52b8:      	b.eq	0x5108 <generic_usdt_process_filter+0x17b8>
    52bc:      	ldr	w9, [x1, #0x10]!
    52c0:      	ldr	w12, [sp, #0x30]
    52c4:      	mov	x11, x20
    52c8:      	cmp	x29, x9
    52cc:      	b.eq	0x5110 <generic_usdt_process_filter+0x17c0>
    52d0:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    52d4:      	mov	w8, #0x1                // =1
    52d8:      	ldr	x0, [x0]
    52dc:      	blr	x8
    52e0:      	cbz	x0, 0x54e4 <generic_usdt_process_filter+0x1b94>
    52e4:      	ldr	w9, [x0]
    52e8:      	mov	x1, x0
    52ec:      	mov	w8, #0x1                // =1
    52f0:      	cmp	x29, x9
    52f4:      	b.eq	0x5108 <generic_usdt_process_filter+0x17b8>
    52f8:      	ldr	w9, [x1, #0x10]!
    52fc:      	ldr	w12, [sp, #0x30]
    5300:      	mov	x11, x20
    5304:      	cmp	x29, x9
    5308:      	b.eq	0x5110 <generic_usdt_process_filter+0x17c0>
    530c:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    5310:      	mov	w8, #0x1                // =1
    5314:      	ldr	x0, [x0]
    5318:      	blr	x8
    531c:      	cbz	x0, 0x54e4 <generic_usdt_process_filter+0x1b94>
    5320:      	ldr	w9, [x0]
    5324:      	mov	x1, x0
    5328:      	mov	w8, #0x1                // =1
    532c:      	cmp	x29, x9
    5330:      	b.eq	0x5108 <generic_usdt_process_filter+0x17b8>
    5334:      	ldr	w9, [x1, #0x10]!
    5338:      	ldr	w12, [sp, #0x30]
    533c:      	mov	x11, x20
    5340:      	cmp	x29, x9
    5344:      	b.eq	0x5110 <generic_usdt_process_filter+0x17c0>
    5348:      	adrp	x9, 0x5000 <generic_usdt_process_filter+0x16b0>
    534c:      	mov	w8, #0x1                // =1
    5350:      	ldr	x9, [x9]
    5354:      	b	0x54d8 <generic_usdt_process_filter+0x1b88>
    5358:      	ldr	w29, [x19]
    535c:      	tbnz	w22, #0x1, 0x5140 <generic_usdt_process_filter+0x17f0>
    5360:      	ldr	w8, [x11]
    5364:      	cmp	w12, #0x5
    5368:      	b.ne	0x537c <generic_usdt_process_filter+0x1a2c>
    536c:      	cmp	x29, x8
    5370:      	b.eq	0x537c <generic_usdt_process_filter+0x1a2c>
    5374:      	mov	w9, wzr
    5378:      	b	0x511c <generic_usdt_process_filter+0x17cc>
    537c:      	cmp	w12, #0x6
    5380:      	ccmp	x29, x8, #0x0, eq
    5384:      	cset	w9, ne
    5388:      	b	0x511c <generic_usdt_process_filter+0x17cc>
    538c:      	ldr	x8, [sp, #0x20]
    5390:      	ldr	w9, [x8]
    5394:      	cbz	w9, 0x511c <generic_usdt_process_filter+0x17cc>
    5398:      	mov	w8, #0x1                // =1
    539c:      	cbz	x29, 0x5110 <generic_usdt_process_filter+0x17c0>
    53a0:      	cmp	x29, x9
    53a4:      	b.eq	0x5110 <generic_usdt_process_filter+0x17c0>
    53a8:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    53ac:      	mov	w8, #0x1                // =1
    53b0:      	ldr	x0, [x0]
    53b4:      	ldr	x1, [sp, #0x18]
    53b8:      	blr	x8
    53bc:      	cbz	x0, 0x54e4 <generic_usdt_process_filter+0x1b94>
    53c0:      	ldr	w8, [x0, #0x24]
    53c4:      	cmp	x29, x8
    53c8:      	b.eq	0x5104 <generic_usdt_process_filter+0x17b4>
    53cc:      	add	x1, x0, #0x10
    53d0:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    53d4:      	mov	w8, #0x1                // =1
    53d8:      	ldr	x0, [x0]
    53dc:      	blr	x8
    53e0:      	cbz	x0, 0x54e4 <generic_usdt_process_filter+0x1b94>
    53e4:      	ldr	w8, [x0, #0x24]
    53e8:      	cmp	x29, x8
    53ec:      	b.eq	0x5104 <generic_usdt_process_filter+0x17b4>
    53f0:      	add	x1, x0, #0x10
    53f4:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    53f8:      	mov	w8, #0x1                // =1
    53fc:      	ldr	x0, [x0]
    5400:      	blr	x8
    5404:      	cbz	x0, 0x54e4 <generic_usdt_process_filter+0x1b94>
    5408:      	ldr	w8, [x0, #0x24]
    540c:      	cmp	x29, x8
    5410:      	b.eq	0x5104 <generic_usdt_process_filter+0x17b4>
    5414:      	add	x1, x0, #0x10
    5418:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    541c:      	mov	w8, #0x1                // =1
    5420:      	ldr	x0, [x0]
    5424:      	blr	x8
    5428:      	cbz	x0, 0x54e4 <generic_usdt_process_filter+0x1b94>
    542c:      	ldr	w8, [x0, #0x24]
    5430:      	cmp	x29, x8
    5434:      	b.eq	0x5104 <generic_usdt_process_filter+0x17b4>
    5438:      	add	x1, x0, #0x10
    543c:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    5440:      	mov	w8, #0x1                // =1
    5444:      	ldr	x0, [x0]
    5448:      	blr	x8
    544c:      	cbz	x0, 0x54e4 <generic_usdt_process_filter+0x1b94>
    5450:      	ldr	w8, [x0, #0x24]
    5454:      	cmp	x29, x8
    5458:      	b.eq	0x5104 <generic_usdt_process_filter+0x17b4>
    545c:      	add	x1, x0, #0x10
    5460:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    5464:      	mov	w8, #0x1                // =1
    5468:      	ldr	x0, [x0]
    546c:      	blr	x8
    5470:      	cbz	x0, 0x54e4 <generic_usdt_process_filter+0x1b94>
    5474:      	ldr	w8, [x0, #0x24]
    5478:      	cmp	x29, x8
    547c:      	b.eq	0x5104 <generic_usdt_process_filter+0x17b4>
    5480:      	add	x1, x0, #0x10
    5484:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    5488:      	mov	w8, #0x1                // =1
    548c:      	ldr	x0, [x0]
    5490:      	blr	x8
    5494:      	cbz	x0, 0x54e4 <generic_usdt_process_filter+0x1b94>
    5498:      	ldr	w8, [x0, #0x24]
    549c:      	cmp	x29, x8
    54a0:      	b.eq	0x5104 <generic_usdt_process_filter+0x17b4>
    54a4:      	add	x1, x0, #0x10
    54a8:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    54ac:      	mov	w8, #0x1                // =1
    54b0:      	ldr	x0, [x0]
    54b4:      	blr	x8
    54b8:      	cbz	x0, 0x54e4 <generic_usdt_process_filter+0x1b94>
    54bc:      	ldr	w8, [x0, #0x24]
    54c0:      	cmp	x29, x8
    54c4:      	b.eq	0x5104 <generic_usdt_process_filter+0x17b4>
    54c8:      	adrp	x9, 0x5000 <generic_usdt_process_filter+0x16b0>
    54cc:      	add	x1, x0, #0x10
    54d0:      	mov	w8, #0x1                // =1
    54d4:      	ldr	x9, [x9]
    54d8:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    54dc:      	ldr	x0, [x0]
    54e0:      	blr	x8
    54e4:      	ldr	w12, [sp, #0x30]
    54e8:      	mov	w8, wzr
    54ec:      	mov	w9, wzr
    54f0:      	mov	x11, x20
    54f4:      	cmp	w12, #0x5
    54f8:      	b.ne	0x5110 <generic_usdt_process_filter+0x17c0>
    54fc:      	b	0x511c <generic_usdt_process_filter+0x17cc>
    5500:      	ldp	w8, w9, [sp, #0x58]
    5504:      	ldp	w10, w11, [sp, #0x60]
    5508:      	cmp	w12, #0x6
    550c:      	b.ne	0x5520 <generic_usdt_process_filter+0x1bd0>
    5510:      	and	w8, w9, w8
    5514:      	and	w9, w10, w11
    5518:      	and	w9, w8, w9
    551c:      	b	0x552c <generic_usdt_process_filter+0x1bdc>
    5520:      	orr	w8, w9, w8
    5524:      	orr	w9, w10, w11
    5528:      	orr	w9, w8, w9
    552c:      	ldr	x8, [sp, #0x10]
    5530:      	cbz	w9, 0x5c34 <generic_usdt_process_filter+0x22e4>
    5534:      	ldr	x10, [sp, #0x8]
    5538:      	add	w8, w8, #0x14
    553c:      	ldr	w10, [x10, #0x8]
    5540:      	ubfiz	w10, w10, #2, #3
    5544:      	add	w8, w10, w8
    5548:      	and	x10, x8, #0x3ff
    554c:      	add	w8, w8, #0x4
    5550:      	mov	w19, #0xa               // =10
    5554:      	ldr	w10, [x10, x23]
    5558:      	mov	w20, #0x4               // =4
    555c:      	mov	x25, #0x100000001       // =4294967297
    5560:      	sub	w22, w10, #0x4
    5564:      	ldr	x10, [sp, #0xe8]
    5568:      	add	x10, x10, #0x20
    556c:      	str	x10, [sp, #0x30]
    5570:      	b	0x5588 <generic_usdt_process_filter+0x1c38>
    5574:      	nop
    5578:      	nop
    557c:      	nop
    5580:      	subs	x19, x19, #0x1
    5584:      	b.eq	0x5754 <generic_usdt_process_filter+0x1e04>
    5588:      	cbz	w22, 0x5580 <generic_usdt_process_filter+0x1c30>
    558c:      	and	x9, x8, #0x3ff
    5590:      	add	x10, x9, x23
    5594:      	ldr	w29, [x10, #0x8]
    5598:      	ldp	w9, w24, [x10]
    559c:      	stp	xzr, xzr, [sp, #0x58]
    55a0:      	cmp	w29, #0x4
    55a4:      	csel	w10, w29, w20, lo
    55a8:      	cmp	w24, #0x6
    55ac:      	b.ne	0x55b4 <generic_usdt_process_filter+0x1c64>
    55b0:      	stp	x25, x25, [sp, #0x58]
    55b4:      	add	w21, w8, #0xc
    55b8:      	cbz	w29, 0x570c <generic_usdt_process_filter+0x1dbc>
    55bc:      	and	x9, x9, #0xf
    55c0:      	cmp	w9, #0xa
    55c4:      	b.lo	0x55f0 <generic_usdt_process_filter+0x1ca0>
    55c8:      	sub	x8, x10, #0x1
    55cc:      	mov	w9, #0x3                // =3
    55d0:      	add	x0, sp, #0x58
    55d4:      	mov	w1, wzr
    55d8:      	cmp	x8, #0x3
    55dc:      	csel	x8, x8, x9, lo
    55e0:      	lsl	x8, x8, #2
    55e4:      	add	x2, x8, #0x4
    55e8:      	bl	0x55e8 <generic_usdt_process_filter+0x1c98>
    55ec:      	b	0x570c <generic_usdt_process_filter+0x1dbc>
    55f0:      	cmp	w21, #0x3e8
    55f4:      	b.ls	0x5600 <generic_usdt_process_filter+0x1cb0>
    55f8:      	mov	w11, wzr
    55fc:      	b	0x5608 <generic_usdt_process_filter+0x1cb8>
    5600:      	and	w11, w21, #0xfffffffc
    5604:      	ldr	w11, [x23, w11, uxtw]
    5608:      	ldr	x12, [sp, #0x30]
    560c:      	cmp	w24, #0x5
    5610:      	sub	x10, x10, #0x1
    5614:      	ldr	w9, [x12, x9, lsl #2]
    5618:      	cset	w12, ne
    561c:      	cmp	w24, #0x6
    5620:      	cset	w13, ne
    5624:      	cmp	w11, w9
    5628:      	csinc	w11, w12, wzr, ne
    562c:      	csinc	w12, w13, wzr, eq
    5630:      	and	w11, w11, w12
    5634:      	str	w11, [sp, #0x58]
    5638:      	cbz	x10, 0x570c <generic_usdt_process_filter+0x1dbc>
    563c:      	add	w11, w8, #0x10
    5640:      	cmp	w11, #0x3e8
    5644:      	b.ls	0x5650 <generic_usdt_process_filter+0x1d00>
    5648:      	mov	w11, wzr
    564c:      	b	0x5658 <generic_usdt_process_filter+0x1d08>
    5650:      	and	w11, w11, #0xfffffffc
    5654:      	ldr	w11, [x23, w11, uxtw]
    5658:      	cmp	w24, #0x5
    565c:      	cset	w12, ne
    5660:      	cmp	w24, #0x6
    5664:      	cset	w13, ne
    5668:      	cmp	w11, w9
    566c:      	csinc	w11, w12, wzr, ne
    5670:      	csinc	w12, w13, wzr, eq
    5674:      	cmp	x10, #0x1
    5678:      	and	w11, w11, w12
    567c:      	str	w11, [sp, #0x5c]
    5680:      	b.eq	0x570c <generic_usdt_process_filter+0x1dbc>
    5684:      	add	w11, w8, #0x14
    5688:      	cmp	w11, #0x3e8
    568c:      	b.ls	0x5698 <generic_usdt_process_filter+0x1d48>
    5690:      	mov	w11, wzr
    5694:      	b	0x56a0 <generic_usdt_process_filter+0x1d50>
    5698:      	and	w11, w11, #0xfffffffc
    569c:      	ldr	w11, [x23, w11, uxtw]
    56a0:      	cmp	w24, #0x5
    56a4:      	cset	w12, ne
    56a8:      	cmp	w24, #0x6
    56ac:      	cset	w13, ne
    56b0:      	cmp	w11, w9
    56b4:      	csinc	w11, w12, wzr, ne
    56b8:      	csinc	w12, w13, wzr, eq
    56bc:      	cmp	x10, #0x2
    56c0:      	and	w11, w11, w12
    56c4:      	str	w11, [sp, #0x60]
    56c8:      	b.eq	0x570c <generic_usdt_process_filter+0x1dbc>
    56cc:      	add	w8, w8, #0x18
    56d0:      	cmp	w8, #0x3e8
    56d4:      	b.ls	0x56e0 <generic_usdt_process_filter+0x1d90>
    56d8:      	mov	w8, wzr
    56dc:      	b	0x56e8 <generic_usdt_process_filter+0x1d98>
    56e0:      	and	w8, w8, #0xfffffffc
    56e4:      	ldr	w8, [x23, w8, uxtw]
    56e8:      	cmp	w24, #0x5
    56ec:      	cset	w10, ne
    56f0:      	cmp	w24, #0x6
    56f4:      	cset	w11, ne
    56f8:      	cmp	w8, w9
    56fc:      	csinc	w8, w10, wzr, ne
    5700:      	csinc	w9, w11, wzr, eq
    5704:      	and	w8, w8, w9
    5708:      	str	w8, [sp, #0x64]
    570c:      	ldp	w8, w9, [sp, #0x58]
    5710:      	ldp	w10, w11, [sp, #0x60]
    5714:      	cmp	w24, #0x6
    5718:      	b.ne	0x572c <generic_usdt_process_filter+0x1ddc>
    571c:      	and	w8, w9, w8
    5720:      	and	w9, w10, w11
    5724:      	and	w9, w8, w9
    5728:      	b	0x5738 <generic_usdt_process_filter+0x1de8>
    572c:      	orr	w8, w9, w8
    5730:      	orr	w9, w10, w11
    5734:      	orr	w9, w8, w9
    5738:      	cbz	w9, 0x5c34 <generic_usdt_process_filter+0x22e4>
    573c:      	lsl	w8, w29, #2
    5740:      	sub	w10, w22, w29, lsl #2
    5744:      	and	w8, w8, #0x1c
    5748:      	sub	w22, w10, #0xc
    574c:      	add	w8, w8, w21
    5750:      	b	0x5580 <generic_usdt_process_filter+0x1c30>
    5754:      	mov	w10, w8
    5758:      	add	w19, w8, #0x4
    575c:      	and	x10, x10, #0x3ff
    5760:      	ldr	w10, [x10, x23]
    5764:      	cmp	w10, #0x4
    5768:      	b.ne	0x5800 <generic_usdt_process_filter+0x1eb0>
    576c:      	cbz	w9, 0x5c34 <generic_usdt_process_filter+0x22e4>
    5770:      	mov	w8, w19
    5774:      	and	x8, x8, #0x3ff
    5778:      	ldr	w9, [x8, x23]
    577c:      	add	w8, w19, #0x4
    5780:      	cmp	w9, #0x4
    5784:      	mov	w9, w8
    5788:      	b.eq	0x5b30 <generic_usdt_process_filter+0x21e0>
    578c:      	and	x8, x8, #0x3ff
    5790:      	add	x8, x8, x23
    5794:      	ldp	w20, w22, [x8]
    5798:      	mov	w8, #0xe                // =14
    579c:      	blr	x8
    57a0:      	lsr	x8, x0, #32
    57a4:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    57a8:      	add	x9, sp, #0x58
    57ac:      	str	w8, [sp, #0x58]
    57b0:      	mov	w8, #0x1                // =1
    57b4:      	add	x1, sp, #0x58
    57b8:      	ldr	x0, [x0]
    57bc:      	blr	x8
    57c0:      	cbz	x0, 0x5c34 <generic_usdt_process_filter+0x22e4>
    57c4:      	cmp	w20, #0x5
    57c8:      	b.eq	0x587c <generic_usdt_process_filter+0x1f2c>
    57cc:      	cmp	w20, #0x6
    57d0:      	b.ne	0x5c34 <generic_usdt_process_filter+0x22e4>
    57d4:      	ldr	x11, [sp, #0xe8]
    57d8:      	mov	w8, #0x5ee8             // =24296
    57dc:      	add	x8, x11, x8
    57e0:      	tbnz	w22, #0x0, 0x58b0 <generic_usdt_process_filter+0x1f60>
    57e4:      	ldr	w9, [x0, #0x28]
    57e8:      	cbz	w9, 0x58a8 <generic_usdt_process_filter+0x1f58>
    57ec:      	ldr	x10, [sp, #0x30]
    57f0:      	ldr	w10, [x10]
    57f4:      	cmp	w9, w10
    57f8:      	b.eq	0x58b0 <generic_usdt_process_filter+0x1f60>
    57fc:      	b	0x5b24 <generic_usdt_process_filter+0x21d4>
    5800:      	and	x9, x19, #0x3ff
    5804:      	add	w19, w8, #0x18
    5808:      	add	x9, x9, x23
    580c:      	ldp	w8, w10, [x9]
    5810:      	ldr	w12, [x9, #0x8]
    5814:      	ldur	x11, [x9, #0xc]
    5818:      	cbz	w12, 0x583c <generic_usdt_process_filter+0x1eec>
    581c:      	ldr	x14, [sp, #0xe8]
    5820:      	mov	w9, wzr
    5824:      	cmp	w8, #0x2
    5828:      	b.hi	0x576c <generic_usdt_process_filter+0x1e1c>
    582c:      	ldr	w13, [x14, #0x44]
    5830:      	cmp	w13, w12
    5834:      	b.ne	0x5850 <generic_usdt_process_filter+0x1f00>
    5838:      	b	0x576c <generic_usdt_process_filter+0x1e1c>
    583c:      	ldr	x14, [sp, #0xe8]
    5840:      	cmp	w8, #0x2
    5844:      	b.ls	0x5850 <generic_usdt_process_filter+0x1f00>
    5848:      	mov	w9, wzr
    584c:      	b	0x576c <generic_usdt_process_filter+0x1e1c>
    5850:      	add	x9, x14, #0x48
    5854:      	cmp	w10, #0x5
    5858:      	ldr	x8, [x9, x8, lsl #3]
    585c:      	and	x8, x8, x11
    5860:      	b.ne	0x5870 <generic_usdt_process_filter+0x1f20>
    5864:      	cmp	x8, #0x0
    5868:      	cset	w9, ne
    586c:      	b	0x576c <generic_usdt_process_filter+0x1e1c>
    5870:      	cmp	x8, #0x0
    5874:      	cset	w9, eq
    5878:      	b	0x576c <generic_usdt_process_filter+0x1e1c>
    587c:      	ldr	x11, [sp, #0xe8]
    5880:      	mov	w8, #0x5ee8             // =24296
    5884:      	add	x8, x11, x8
    5888:      	tbz	w22, #0x0, 0x58d4 <generic_usdt_process_filter+0x1f84>
    588c:      	ldr	w9, [x0, #0x28]
    5890:      	cbz	w9, 0x58cc <generic_usdt_process_filter+0x1f7c>
    5894:      	ldr	x10, [sp, #0x30]
    5898:      	ldr	w10, [x10]
    589c:      	cmp	w9, w10
    58a0:      	b.eq	0x58d4 <generic_usdt_process_filter+0x1f84>
    58a4:      	b	0x5b24 <generic_usdt_process_filter+0x21d4>
    58a8:      	mov	w9, #0x1                // =1
    58ac:      	str	x9, [x8]
    58b0:      	tbnz	w22, #0x1, 0x58f8 <generic_usdt_process_filter+0x1fa8>
    58b4:      	ldr	w9, [x0, #0x2c]
    58b8:      	cbz	w9, 0x58f0 <generic_usdt_process_filter+0x1fa0>
    58bc:      	ldr	w10, [x11, #0x24]
    58c0:      	cmp	w9, w10
    58c4:      	b.eq	0x58f8 <generic_usdt_process_filter+0x1fa8>
    58c8:      	b	0x5b24 <generic_usdt_process_filter+0x21d4>
    58cc:      	mov	w9, #0x1                // =1
    58d0:      	str	x9, [x8]
    58d4:      	tbz	w22, #0x1, 0x591c <generic_usdt_process_filter+0x1fcc>
    58d8:      	ldr	w9, [x0, #0x2c]
    58dc:      	cbz	w9, 0x5914 <generic_usdt_process_filter+0x1fc4>
    58e0:      	ldr	w10, [x11, #0x24]
    58e4:      	cmp	w9, w10
    58e8:      	b.eq	0x591c <generic_usdt_process_filter+0x1fcc>
    58ec:      	b	0x5b24 <generic_usdt_process_filter+0x21d4>
    58f0:      	mov	w9, #0x1                // =1
    58f4:      	str	x9, [x8]
    58f8:      	tbnz	w22, #0x2, 0x5940 <generic_usdt_process_filter+0x1ff0>
    58fc:      	ldr	w9, [x0, #0x30]
    5900:      	cbz	w9, 0x5938 <generic_usdt_process_filter+0x1fe8>
    5904:      	ldr	w10, [x11, #0x28]
    5908:      	cmp	w9, w10
    590c:      	b.eq	0x5940 <generic_usdt_process_filter+0x1ff0>
    5910:      	b	0x5b24 <generic_usdt_process_filter+0x21d4>
    5914:      	mov	w9, #0x1                // =1
    5918:      	str	x9, [x8]
    591c:      	tbz	w22, #0x2, 0x5964 <generic_usdt_process_filter+0x2014>
    5920:      	ldr	w9, [x0, #0x30]
    5924:      	cbz	w9, 0x595c <generic_usdt_process_filter+0x200c>
    5928:      	ldr	w10, [x11, #0x28]
    592c:      	cmp	w9, w10
    5930:      	b.eq	0x5964 <generic_usdt_process_filter+0x2014>
    5934:      	b	0x5b24 <generic_usdt_process_filter+0x21d4>
    5938:      	mov	w9, #0x1                // =1
    593c:      	str	x9, [x8]
    5940:      	tbnz	w22, #0x3, 0x5988 <generic_usdt_process_filter+0x2038>
    5944:      	ldr	w9, [x0, #0x34]
    5948:      	cbz	w9, 0x5980 <generic_usdt_process_filter+0x2030>
    594c:      	ldr	w10, [x11, #0x2c]
    5950:      	cmp	w9, w10
    5954:      	b.eq	0x5988 <generic_usdt_process_filter+0x2038>
    5958:      	b	0x5b24 <generic_usdt_process_filter+0x21d4>
    595c:      	mov	w9, #0x1                // =1
    5960:      	str	x9, [x8]
    5964:      	tbz	w22, #0x3, 0x59ac <generic_usdt_process_filter+0x205c>
    5968:      	ldr	w9, [x0, #0x34]
    596c:      	cbz	w9, 0x59a4 <generic_usdt_process_filter+0x2054>
    5970:      	ldr	w10, [x11, #0x2c]
    5974:      	cmp	w9, w10
    5978:      	b.eq	0x59ac <generic_usdt_process_filter+0x205c>
    597c:      	b	0x5b24 <generic_usdt_process_filter+0x21d4>
    5980:      	mov	w9, #0x1                // =1
    5984:      	str	x9, [x8]
    5988:      	tbnz	w22, #0x4, 0x59d0 <generic_usdt_process_filter+0x2080>
    598c:      	ldr	w9, [x0, #0x38]
    5990:      	cbz	w9, 0x59c8 <generic_usdt_process_filter+0x2078>
    5994:      	ldr	w10, [x11, #0x30]
    5998:      	cmp	w9, w10
    599c:      	b.eq	0x59d0 <generic_usdt_process_filter+0x2080>
    59a0:      	b	0x5b24 <generic_usdt_process_filter+0x21d4>
    59a4:      	mov	w9, #0x1                // =1
    59a8:      	str	x9, [x8]
    59ac:      	tbz	w22, #0x4, 0x59f4 <generic_usdt_process_filter+0x20a4>
    59b0:      	ldr	w9, [x0, #0x38]
    59b4:      	cbz	w9, 0x59ec <generic_usdt_process_filter+0x209c>
    59b8:      	ldr	w10, [x11, #0x30]
    59bc:      	cmp	w9, w10
    59c0:      	b.eq	0x59f4 <generic_usdt_process_filter+0x20a4>
    59c4:      	b	0x5b24 <generic_usdt_process_filter+0x21d4>
    59c8:      	mov	w9, #0x1                // =1
    59cc:      	str	x9, [x8]
    59d0:      	tbnz	w22, #0x5, 0x5a18 <generic_usdt_process_filter+0x20c8>
    59d4:      	ldr	w9, [x0, #0x3c]
    59d8:      	cbz	w9, 0x5a10 <generic_usdt_process_filter+0x20c0>
    59dc:      	ldr	w10, [x11, #0x34]
    59e0:      	cmp	w9, w10
    59e4:      	b.eq	0x5a18 <generic_usdt_process_filter+0x20c8>
    59e8:      	b	0x5b24 <generic_usdt_process_filter+0x21d4>
    59ec:      	mov	w9, #0x1                // =1
    59f0:      	str	x9, [x8]
    59f4:      	tbz	w22, #0x5, 0x5a3c <generic_usdt_process_filter+0x20ec>
    59f8:      	ldr	w9, [x0, #0x3c]
    59fc:      	cbz	w9, 0x5a34 <generic_usdt_process_filter+0x20e4>
    5a00:      	ldr	w10, [x11, #0x34]
    5a04:      	cmp	w9, w10
    5a08:      	b.eq	0x5a3c <generic_usdt_process_filter+0x20ec>
    5a0c:      	b	0x5b24 <generic_usdt_process_filter+0x21d4>
    5a10:      	mov	w9, #0x1                // =1
    5a14:      	str	x9, [x8]
    5a18:      	tbnz	w22, #0x6, 0x5a60 <generic_usdt_process_filter+0x2110>
    5a1c:      	ldr	w9, [x0, #0x40]
    5a20:      	cbz	w9, 0x5a58 <generic_usdt_process_filter+0x2108>
    5a24:      	ldr	w10, [x11, #0x38]
    5a28:      	cmp	w9, w10
    5a2c:      	b.eq	0x5a60 <generic_usdt_process_filter+0x2110>
    5a30:      	b	0x5b24 <generic_usdt_process_filter+0x21d4>
    5a34:      	mov	w9, #0x1                // =1
    5a38:      	str	x9, [x8]
    5a3c:      	tbz	w22, #0x6, 0x5a84 <generic_usdt_process_filter+0x2134>
    5a40:      	ldr	w9, [x0, #0x40]
    5a44:      	cbz	w9, 0x5a7c <generic_usdt_process_filter+0x212c>
    5a48:      	ldr	w10, [x11, #0x38]
    5a4c:      	cmp	w9, w10
    5a50:      	b.eq	0x5a84 <generic_usdt_process_filter+0x2134>
    5a54:      	b	0x5b24 <generic_usdt_process_filter+0x21d4>
    5a58:      	mov	w9, #0x1                // =1
    5a5c:      	str	x9, [x8]
    5a60:      	tbnz	w22, #0x7, 0x5aa8 <generic_usdt_process_filter+0x2158>
    5a64:      	ldr	w9, [x0, #0x44]
    5a68:      	cbz	w9, 0x5aa0 <generic_usdt_process_filter+0x2150>
    5a6c:      	ldr	w10, [x11, #0x3c]
    5a70:      	cmp	w9, w10
    5a74:      	b.eq	0x5aa8 <generic_usdt_process_filter+0x2158>
    5a78:      	b	0x5b24 <generic_usdt_process_filter+0x21d4>
    5a7c:      	mov	w9, #0x1                // =1
    5a80:      	str	x9, [x8]
    5a84:      	tbz	w22, #0x7, 0x5ad0 <generic_usdt_process_filter+0x2180>
    5a88:      	ldr	w9, [x0, #0x44]
    5a8c:      	cbz	w9, 0x5ac8 <generic_usdt_process_filter+0x2178>
    5a90:      	ldr	w10, [x11, #0x3c]
    5a94:      	cmp	w9, w10
    5a98:      	b.eq	0x5ad0 <generic_usdt_process_filter+0x2180>
    5a9c:      	b	0x5b24 <generic_usdt_process_filter+0x21d4>
    5aa0:      	mov	w9, #0x1                // =1
    5aa4:      	str	x9, [x8]
    5aa8:      	tbnz	w22, #0x8, 0x5af8 <generic_usdt_process_filter+0x21a8>
    5aac:      	ldr	w9, [x0, #0x48]
    5ab0:      	cbz	w9, 0x5af0 <generic_usdt_process_filter+0x21a0>
    5ab4:      	ldr	x10, [sp, #0xe8]
    5ab8:      	ldr	w10, [x10, #0x40]
    5abc:      	cmp	w9, w10
    5ac0:      	b.eq	0x5af8 <generic_usdt_process_filter+0x21a8>
    5ac4:      	b	0x5b24 <generic_usdt_process_filter+0x21d4>
    5ac8:      	mov	w9, #0x1                // =1
    5acc:      	str	x9, [x8]
    5ad0:      	tbz	w22, #0x8, 0x5b08 <generic_usdt_process_filter+0x21b8>
    5ad4:      	ldr	w9, [x0, #0x48]
    5ad8:      	cbz	w9, 0x5b00 <generic_usdt_process_filter+0x21b0>
    5adc:      	ldr	x10, [sp, #0xe8]
    5ae0:      	ldr	w10, [x10, #0x40]
    5ae4:      	cmp	w9, w10
    5ae8:      	b.eq	0x5b08 <generic_usdt_process_filter+0x21b8>
    5aec:      	b	0x5b24 <generic_usdt_process_filter+0x21d4>
    5af0:      	mov	w9, #0x1                // =1
    5af4:      	str	x9, [x8]
    5af8:      	tbz	w22, #0x9, 0x5b0c <generic_usdt_process_filter+0x21bc>
    5afc:      	b	0x5c34 <generic_usdt_process_filter+0x22e4>
    5b00:      	mov	w9, #0x1                // =1
    5b04:      	str	x9, [x8]
    5b08:      	tbz	w22, #0x9, 0x5c34 <generic_usdt_process_filter+0x22e4>
    5b0c:      	ldr	w9, [x0, #0x4c]
    5b10:      	cbz	w9, 0x5c2c <generic_usdt_process_filter+0x22dc>
    5b14:      	ldr	x10, [sp, #0xe8]
    5b18:      	ldr	w10, [x10, #0x44]
    5b1c:      	cmp	w9, w10
    5b20:      	b.eq	0x5c34 <generic_usdt_process_filter+0x22e4>
    5b24:      	add	w9, w19, #0xc
    5b28:      	mov	w10, #0x1               // =1
    5b2c:      	str	x10, [x8]
    5b30:      	and	x8, x9, #0x3ff
    5b34:      	adrp	x24, 0x5000 <generic_usdt_process_filter+0x16b0>
    5b38:      	ldr	w8, [x8, x23]
    5b3c:      	ldr	x24, [x24]
    5b40:      	cmp	w8, #0x4
    5b44:      	b.ne	0x5b78 <generic_usdt_process_filter+0x2228>
    5b48:      	ldr	x9, [sp, #0xe8]
    5b4c:      	mov	w8, #0x5eb8             // =24248
    5b50:      	add	x8, x9, x8
    5b54:      	ldr	x9, [x9, #0x5eb8]
    5b58:      	and	x9, x9, #0x1f
    5b5c:      	add	x8, x8, x9
    5b60:      	mov	w9, #0x1                // =1
    5b64:      	strb	w9, [x8, #0x9]
    5b68:      	ldr	x8, [sp, #0x40]
    5b6c:      	strb	w9, [x8, #0x20]
    5b70:      	strb	w9, [x8]
    5b74:      	b	0x5c34 <generic_usdt_process_filter+0x22e4>
    5b78:      	add	w8, w9, #0x4
    5b7c:      	and	x8, x8, #0x3ff
    5b80:      	add	x8, x8, x23
    5b84:      	ldp	w21, w19, [x8]
    5b88:      	ldr	w22, [x8, #0x8]
    5b8c:      	ldur	x20, [x8, #0xc]
    5b90:      	mov	w8, #0xe                // =14
    5b94:      	blr	x8
    5b98:      	lsr	x8, x0, #32
    5b9c:      	add	x9, sp, #0x58
    5ba0:      	add	x1, sp, #0x58
    5ba4:      	str	w8, [sp, #0x58]
    5ba8:      	mov	w8, #0x1                // =1
    5bac:      	mov	x0, x24
    5bb0:      	blr	x8
    5bb4:      	cbz	x0, 0x5c34 <generic_usdt_process_filter+0x22e4>
    5bb8:      	cmp	w21, #0x2
    5bbc:      	cbz	w22, 0x5bd8 <generic_usdt_process_filter+0x2288>
    5bc0:      	b.hi	0x5c34 <generic_usdt_process_filter+0x22e4>
    5bc4:      	ldr	x8, [sp, #0xe8]
    5bc8:      	ldr	w8, [x8, #0x44]
    5bcc:      	cmp	w8, w22
    5bd0:      	b.ne	0x5bdc <generic_usdt_process_filter+0x228c>
    5bd4:      	b	0x5c34 <generic_usdt_process_filter+0x22e4>
    5bd8:      	b.hi	0x5c34 <generic_usdt_process_filter+0x22e4>
    5bdc:      	ldr	x8, [sp, #0xe8]
    5be0:      	lsl	x10, x21, #3
    5be4:      	add	x9, x8, #0x48
    5be8:      	add	x8, x0, x21, lsl #3
    5bec:      	ldr	x8, [x8, #0x50]
    5bf0:      	ldr	x9, [x9, x10]
    5bf4:      	eor	x10, x9, x8
    5bf8:      	tst	x10, x20
    5bfc:      	b.eq	0x5c0c <generic_usdt_process_filter+0x22bc>
    5c00:      	cmp	w19, #0x5
    5c04:      	b.eq	0x5c1c <generic_usdt_process_filter+0x22cc>
    5c08:      	b	0x5c34 <generic_usdt_process_filter+0x22e4>
    5c0c:      	cmp	x8, x9
    5c10:      	b.eq	0x5c34 <generic_usdt_process_filter+0x22e4>
    5c14:      	cmp	w19, #0x6
    5c18:      	b.ne	0x5c34 <generic_usdt_process_filter+0x22e4>
    5c1c:      	ldr	x9, [sp, #0xe8]
    5c20:      	mov	w8, #0x1                // =1
    5c24:      	str	x8, [x9, #0x5ef0]
    5c28:      	b	0x5b48 <generic_usdt_process_filter+0x21f8>
    5c2c:      	mov	w9, #0x1                // =1
    5c30:      	str	x9, [x8]
    5c34:      	ldr	x9, [sp, #0xe8]
    5c38:      	ldr	x10, [sp, #0x28]
    5c3c:      	ldr	x8, [x9, #0x5eb8]
    5c40:      	add	x8, x8, #0x1
    5c44:      	cmp	x8, x10
    5c48:      	str	x8, [x9, #0x5eb8]
    5c4c:      	b.ls	0x5cac <generic_usdt_process_filter+0x235c>
    5c50:      	ldr	x10, [sp, #0x48]
    5c54:      	ldr	w8, [x10]
    5c58:      	str	w8, [x9, #0x10]
    5c5c:      	ldr	x8, [x10, #0x8]
    5c60:      	str	x8, [x9, #0x18]
    5c64:      	ldp	x20, x8, [sp, #0x38]
    5c68:      	ldrb	w8, [x8]
    5c6c:      	cbz	w8, 0x5c8c <generic_usdt_process_filter+0x233c>
    5c70:      	adrp	x1, 0x5000 <generic_usdt_process_filter+0x16b0>
    5c74:      	mov	x8, xzr
    5c78:      	mov	w9, #0xc                // =12
    5c7c:      	ldr	x1, [x1]
    5c80:      	mov	x0, x20
    5c84:      	mov	w2, wzr
    5c88:      	blr	x9
    5c8c:      	ldp	x20, x19, [sp, #0x120]
    5c90:      	mov	w0, wzr
    5c94:      	ldr	x29, [sp, #0xe0]
    5c98:      	ldp	x22, x21, [sp, #0x110]
    5c9c:      	ldp	x24, x23, [sp, #0x100]
    5ca0:      	ldp	x30, x25, [sp, #0xf0]
    5ca4:      	add	sp, sp, #0x130
    5ca8:      	ret
    5cac:      	adrp	x1, 0x5000 <generic_usdt_process_filter+0x16b0>
    5cb0:      	mov	w8, #0x2                // =2
    5cb4:      	mov	w9, #0xc                // =12
    5cb8:      	ldr	x1, [x1]
    5cbc:      	ldr	x0, [sp, #0x38]
    5cc0:      	mov	w2, #0x2                // =2
    5cc4:      	b	0x5c88 <generic_usdt_process_filter+0x2338>
    5cc8:      	nop
    5ccc:      	nop

0000000000005cd0 <generic_usdt_filter_arg>:
    5cd0:      	sub	sp, sp, #0x70
    5cd4:      	str	x29, [sp, #0x20]
    5cd8:      	stp	x30, x25, [sp, #0x30]
    5cdc:      	stp	x24, x23, [sp, #0x40]
    5ce0:      	stp	x22, x21, [sp, #0x50]
    5ce4:      	stp	x20, x19, [sp, #0x60]
    5ce8:      	mov	x19, x0
    5cec:      	str	wzr, [sp, #0x2c]
    5cf0:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    5cf4:      	mov	w8, #0x1                // =1
    5cf8:      	ldr	x0, [x0]
    5cfc:      	add	x9, sp, #0x2c
    5d00:      	add	x1, sp, #0x2c
    5d04:      	blr	x8
    5d08:      	cbz	x0, 0x6094 <generic_usdt_filter_arg+0x3c4>
    5d0c:      	mov	w8, #0x5ec1             // =24257
    5d10:      	mov	x20, x0
    5d14:      	add	x22, x0, x8
    5d18:      	mov	w8, #0x5ef8             // =24312
    5d1c:      	add	x1, x0, x8
    5d20:      	adrp	x0, 0x5000 <generic_usdt_process_filter+0x16b0>
    5d24:      	ldur	w23, [x22, #0x3f]
    5d28:      	mov	w8, #0x1                // =1
    5d2c:      	ldr	x0, [x0]
    5d30:      	blr	x8
    5d34:      	cbz	x0, 0x6078 <generic_usdt_filter_arg+0x3a8>
    5d38:      	ldrb	w8, [x22, #0x1f]
    5d3c:      	cbz	w8, 0x6078 <generic_usdt_filter_arg+0x3a8>
    5d40:      	and	x8, x23, #0x7
    5d44:      	mov	w10, #0x5ec1            // =24257
    5d48:      	add	x9, x20, x8
    5d4c:      	ldrb	w9, [x9, x10]
    5d50:      	cbz	w9, 0x5dd0 <generic_usdt_filter_arg+0x100>
    5d54:      	lsl	w8, w8, #2
    5d58:      	mov	x21, x0
    5d5c:      	add	x8, x8, #0x4
    5d60:      	ldr	w9, [x8, x0]
    5d64:      	add	x8, x8, x9
    5d68:      	add	x8, x8, #0x4
    5d6c:      	and	x9, x8, #0x3ff
    5d70:      	ldr	w9, [x9, x0]
    5d74:      	add	x8, x8, x9
    5d78:      	and	x9, x8, #0x3ff
    5d7c:      	ldr	w9, [x9, x0]
    5d80:      	add	x8, x8, x9
    5d84:      	and	x9, x8, #0x3ff
    5d88:      	ldr	w9, [x9, x0]
    5d8c:      	add	x8, x8, x9
    5d90:      	and	x9, x8, #0x3ff
    5d94:      	ldr	w9, [x9, x0]
    5d98:      	add	x8, x8, x9
    5d9c:      	and	x9, x8, #0x3ff
    5da0:      	ldr	w9, [x9, x0]
    5da4:      	add	x25, x8, x9
    5da8:      	and	x8, x25, #0x3ff
    5dac:      	add	x29, x0, x8
    5db0:      	str	x8, [sp, #0x8]
    5db4:      	ldr	w8, [x29]
    5db8:      	cmp	w8, #0x19
    5dbc:      	b.hs	0x5e18 <generic_usdt_filter_arg+0x148>
    5dc0:      	ldr	x8, [sp, #0x8]
    5dc4:      	cmp	w8, #0x1
    5dc8:      	b.eq	0x6078 <generic_usdt_filter_arg+0x3a8>
    5dcc:      	cbnz	w8, 0x6054 <generic_usdt_filter_arg+0x384>
    5dd0:      	cmp	w23, #0x1
    5dd4:      	b.gt	0x5df0 <generic_usdt_filter_arg+0x120>
    5dd8:      	cmn	w23, #0x1
    5ddc:      	b.eq	0x60b4 <generic_usdt_filter_arg+0x3e4>
    5de0:      	cbz	w23, 0x60c4 <generic_usdt_filter_arg+0x3f4>
    5de4:      	cmp	w23, #0x1
    5de8:      	b.eq	0x60d4 <generic_usdt_filter_arg+0x404>
    5dec:      	b	0x5e08 <generic_usdt_filter_arg+0x138>
    5df0:      	cmp	w23, #0x2
    5df4:      	b.eq	0x60e4 <generic_usdt_filter_arg+0x414>
    5df8:      	cmp	w23, #0x3
    5dfc:      	b.eq	0x60f4 <generic_usdt_filter_arg+0x424>
    5e00:      	cmp	w23, #0x4
    5e04:      	b.eq	0x6104 <generic_usdt_filter_arg+0x434>
    5e08:      	cmp	w23, #0x4
    5e0c:      	b.gt	0x6130 <generic_usdt_filter_arg+0x460>
    5e10:      	add	w8, w23, #0x1
    5e14:      	b	0x6110 <generic_usdt_filter_arg+0x440>
    5e18:      	mov	w24, #0x4               // =4
    5e1c:      	nop
    5e20:      	ldr	w8, [x29, x24]
    5e24:      	tst	w8, #0x3ff
    5e28:      	b.eq	0x5dc0 <generic_usdt_filter_arg+0xf0>
    5e2c:      	add	w8, w25, w8
    5e30:      	and	x8, x8, #0x3ff
    5e34:      	add	x0, x21, x8
    5e38:      	ldr	w9, [x0, #0x4]
    5e3c:      	cmp	w9, #0x23
    5e40:      	b.eq	0x5dd0 <generic_usdt_filter_arg+0x100>
    5e44:      	ldr	w8, [x0]
    5e48:      	cmp	w8, #0x4
    5e4c:      	b.hi	0x5dd0 <generic_usdt_filter_arg+0x100>
    5e50:      	add	x10, x20, x8, lsl #2
    5e54:      	mov	w11, #0x5ea0            // =24224
    5e58:      	ldr	w10, [x10, x11]
    5e5c:      	cbnz	w10, 0x5dd0 <generic_usdt_filter_arg+0x100>
    5e60:      	add	x8, x20, x8, lsl #3
    5e64:      	ldr	x8, [x8, #0x5e78]
    5e68:      	and	x8, x8, #0x7ff
    5e6c:      	add	x8, x20, x8
    5e70:      	add	x1, x8, #0x90
    5e74:      	ldr	w8, [x0, #0xc]
    5e78:      	cmp	w8, #0x1b
    5e7c:      	b.le	0x5ea0 <generic_usdt_filter_arg+0x1d0>
    5e80:      	cmp	w8, #0x25
    5e84:      	b.gt	0x5ed4 <generic_usdt_filter_arg+0x204>
    5e88:      	sub	w10, w8, #0x1c
    5e8c:      	cmp	w10, #0x9
    5e90:      	b.lo	0x5f18 <generic_usdt_filter_arg+0x248>
    5e94:      	cmp	w8, #0x25
    5e98:      	b.eq	0x6000 <generic_usdt_filter_arg+0x330>
    5e9c:      	b	0x6044 <generic_usdt_filter_arg+0x374>
    5ea0:      	cmp	w8, #0x9
    5ea4:      	b.le	0x5ef8 <generic_usdt_filter_arg+0x228>
    5ea8:      	sub	w10, w8, #0xa
    5eac:      	cmp	w10, #0x4
    5eb0:      	b.lo	0x5f18 <generic_usdt_filter_arg+0x248>
    5eb4:      	sub	w9, w8, #0xf
    5eb8:      	cmp	w9, #0x2
    5ebc:      	b.lo	0x6000 <generic_usdt_filter_arg+0x330>
    5ec0:      	cmp	w8, #0x11
    5ec4:      	b.ne	0x6044 <generic_usdt_filter_arg+0x374>
    5ec8:      	add	x1, x1, #0x4
    5ecc:      	bl	0x5ecc <generic_usdt_filter_arg+0x1fc>
    5ed0:      	b	0x6040 <generic_usdt_filter_arg+0x370>
    5ed4:      	cmp	w8, #0x29
    5ed8:      	b.gt	0x5fe8 <generic_usdt_filter_arg+0x318>
    5edc:      	sub	w9, w8, #0x26
    5ee0:      	cmp	w9, #0x2
    5ee4:      	b.lo	0x5f9c <generic_usdt_filter_arg+0x2cc>
    5ee8:      	sub	w8, w8, #0x28
    5eec:      	cmp	w8, #0x2
    5ef0:      	b.lo	0x5f94 <generic_usdt_filter_arg+0x2c4>
    5ef4:      	b	0x6044 <generic_usdt_filter_arg+0x374>
    5ef8:      	cmp	w8, #0x4
    5efc:      	b.gt	0x5f7c <generic_usdt_filter_arg+0x2ac>
    5f00:      	cmp	w8, #0x1
    5f04:      	b.eq	0x5f18 <generic_usdt_filter_arg+0x248>
    5f08:      	cmp	w8, #0x2
    5f0c:      	b.eq	0x6024 <generic_usdt_filter_arg+0x354>
    5f10:      	cmp	w8, #0x4
    5f14:      	b.ne	0x6044 <generic_usdt_filter_arg+0x374>
    5f18:      	cmp	w8, #0xb
    5f1c:      	b.le	0x5f5c <generic_usdt_filter_arg+0x28c>
    5f20:      	cmp	w8, #0x24
    5f24:      	b.hi	0x6008 <generic_usdt_filter_arg+0x338>
    5f28:      	mov	w11, #0x1               // =1
    5f2c:      	lsl	x10, x11, x8
    5f30:      	tst	x10, #0x1e00000000
    5f34:      	b.ne	0x5fa4 <generic_usdt_filter_arg+0x2d4>
    5f38:      	lsl	x9, x11, x8
    5f3c:      	tst	x9, #0x60000000
    5f40:      	mov	w9, #0x1                // =1
    5f44:      	b.ne	0x601c <generic_usdt_filter_arg+0x34c>
    5f48:      	lsl	x9, x9, x8
    5f4c:      	tst	x9, #0x180000000
    5f50:      	b.eq	0x6008 <generic_usdt_filter_arg+0x338>
    5f54:      	bl	0x5f54 <generic_usdt_filter_arg+0x284>
    5f58:      	b	0x6040 <generic_usdt_filter_arg+0x370>
    5f5c:      	sub	w9, w8, #0xa
    5f60:      	cmp	w9, #0x2
    5f64:      	b.lo	0x6038 <generic_usdt_filter_arg+0x368>
    5f68:      	cmp	w8, #0x1
    5f6c:      	b.eq	0x6014 <generic_usdt_filter_arg+0x344>
    5f70:      	cmp	w8, #0x4
    5f74:      	b.eq	0x6014 <generic_usdt_filter_arg+0x344>
    5f78:      	b	0x6044 <generic_usdt_filter_arg+0x374>
    5f7c:      	cmp	w8, #0x5
    5f80:      	b.eq	0x5f94 <generic_usdt_filter_arg+0x2c4>
    5f84:      	cmp	w8, #0x6
    5f88:      	b.eq	0x5f9c <generic_usdt_filter_arg+0x2cc>
    5f8c:      	cmp	w8, #0x7
    5f90:      	b.ne	0x6044 <generic_usdt_filter_arg+0x374>
    5f94:      	bl	0x5f94 <generic_usdt_filter_arg+0x2c4>
    5f98:      	b	0x6040 <generic_usdt_filter_arg+0x370>
    5f9c:      	mov	w2, #0x4                // =4
    5fa0:      	b	0x6028 <generic_usdt_filter_arg+0x358>
    5fa4:      	cmp	w9, #0x1e
    5fa8:      	b.ne	0x6038 <generic_usdt_filter_arg+0x368>
    5fac:      	ldr	w8, [x0, #0x10]
    5fb0:      	mov	w10, #0x5ea0            // =24224
    5fb4:      	and	x8, x8, #0x7
    5fb8:      	add	x9, x20, x8, lsl #2
    5fbc:      	ldr	w9, [x9, x10]
    5fc0:      	cbnz	w9, 0x5dd0 <generic_usdt_filter_arg+0x100>
    5fc4:      	add	x8, x20, x8, lsl #3
    5fc8:      	ldr	x9, [x1]
    5fcc:      	ldr	x8, [x8, #0x5e78]
    5fd0:      	and	x8, x8, #0x7ff
    5fd4:      	add	x8, x20, x8
    5fd8:      	ldr	x8, [x8, #0x90]
    5fdc:      	bics	xzr, x8, x9
    5fe0:      	cset	w0, ne
    5fe4:      	b	0x6040 <generic_usdt_filter_arg+0x370>
    5fe8:      	cmp	w8, #0x2a
    5fec:      	b.eq	0x6000 <generic_usdt_filter_arg+0x330>
    5ff0:      	cmp	w8, #0x2c
    5ff4:      	b.ne	0x6044 <generic_usdt_filter_arg+0x374>
    5ff8:      	bl	0x5ff8 <generic_usdt_filter_arg+0x328>
    5ffc:      	b	0x6040 <generic_usdt_filter_arg+0x370>
    6000:      	bl	0x6000 <generic_usdt_filter_arg+0x330>
    6004:      	b	0x6040 <generic_usdt_filter_arg+0x370>
    6008:      	sub	w9, w8, #0xc
    600c:      	cmp	w9, #0x2
    6010:      	b.hs	0x6030 <generic_usdt_filter_arg+0x360>
    6014:      	bl	0x6014 <generic_usdt_filter_arg+0x344>
    6018:      	b	0x6040 <generic_usdt_filter_arg+0x370>
    601c:      	bl	0x601c <generic_usdt_filter_arg+0x34c>
    6020:      	b	0x6040 <generic_usdt_filter_arg+0x370>
    6024:      	mov	w2, #0x8                // =8
    6028:      	bl	0x6028 <generic_usdt_filter_arg+0x358>
    602c:      	b	0x6040 <generic_usdt_filter_arg+0x370>
    6030:      	cmp	w8, #0x1c
    6034:      	b.ne	0x6044 <generic_usdt_filter_arg+0x374>
    6038:      	bl	0x6038 <generic_usdt_filter_arg+0x368>
    603c:      	nop
    6040:      	cbz	x0, 0x5dd0 <generic_usdt_filter_arg+0x100>
    6044:      	add	x24, x24, #0x4
    6048:      	cmp	x24, #0x18
    604c:      	b.ne	0x5e20 <generic_usdt_filter_arg+0x150>
    6050:      	b	0x5dc0 <generic_usdt_filter_arg+0xf0>
    6054:      	ldr	x8, [sp, #0x8]
    6058:      	adrp	x1, 0x6000 <generic_usdt_filter_arg+0x330>
    605c:      	mov	w9, #0xc                // =12
    6060:      	mov	x0, x19
    6064:      	stur	w8, [x22, #0x43]
    6068:      	mov	w8, #0x4                // =4
    606c:      	mov	w2, #0x4                // =4
    6070:      	ldr	x1, [x1]
    6074:      	blr	x9
    6078:      	adrp	x1, 0x6000 <generic_usdt_filter_arg+0x330>
    607c:      	mov	w8, #0x5                // =5
    6080:      	mov	w9, #0xc                // =12
    6084:      	ldr	x1, [x1]
    6088:      	mov	x0, x19
    608c:      	mov	w2, #0x5                // =5
    6090:      	blr	x9
    6094:      	ldp	x20, x19, [sp, #0x60]
    6098:      	mov	w0, wzr
    609c:      	ldr	x29, [sp, #0x20]
    60a0:      	ldp	x22, x21, [sp, #0x50]
    60a4:      	ldp	x24, x23, [sp, #0x40]
    60a8:      	ldp	x30, x25, [sp, #0x30]
    60ac:      	add	sp, sp, #0x70
    60b0:      	ret
    60b4:      	ldrb	w8, [x22]
    60b8:      	cbz	w8, 0x60c4 <generic_usdt_filter_arg+0x3f4>
    60bc:      	mov	w8, wzr
    60c0:      	b	0x6110 <generic_usdt_filter_arg+0x440>
    60c4:      	ldrb	w8, [x22, #0x1]
    60c8:      	cbz	w8, 0x60d4 <generic_usdt_filter_arg+0x404>
    60cc:      	mov	w8, #0x1                // =1
    60d0:      	b	0x6110 <generic_usdt_filter_arg+0x440>
    60d4:      	ldrb	w8, [x22, #0x2]
    60d8:      	cbz	w8, 0x60e4 <generic_usdt_filter_arg+0x414>
    60dc:      	mov	w8, #0x2                // =2
    60e0:      	b	0x6110 <generic_usdt_filter_arg+0x440>
    60e4:      	ldrb	w8, [x22, #0x3]
    60e8:      	cbz	w8, 0x60f4 <generic_usdt_filter_arg+0x424>
    60ec:      	mov	w8, #0x3                // =3
    60f0:      	b	0x6110 <generic_usdt_filter_arg+0x440>
    60f4:      	ldrb	w8, [x22, #0x4]
    60f8:      	cbz	w8, 0x6104 <generic_usdt_filter_arg+0x434>
    60fc:      	mov	w8, #0x4                // =4
    6100:      	b	0x6110 <generic_usdt_filter_arg+0x440>
    6104:      	ldrb	w8, [x22, #0x5]
    6108:      	cbz	w8, 0x6130 <generic_usdt_filter_arg+0x460>
    610c:      	mov	w8, #0x5                // =5
    6110:      	stur	w8, [x22, #0x3f]
    6114:      	adrp	x1, 0x6000 <generic_usdt_filter_arg+0x330>
    6118:      	mov	w8, #0x3                // =3
    611c:      	mov	w9, #0xc                // =12
    6120:      	ldr	x1, [x1]
    6124:      	mov	x0, x19
    6128:      	mov	w2, #0x3                // =3
    612c:      	blr	x9
    6130:      	ldr	x19, [x20, #0x60]
    6134:      	mov	w8, #0xe                // =14
    6138:      	blr	x8
    613c:      	stp	x19, x0, [sp, #0x10]
    6140:      	adrp	x19, 0x6000 <generic_usdt_filter_arg+0x330>
    6144:      	mov	w8, #0x1                // =1
    6148:      	add	x9, sp, #0x10
    614c:      	add	x1, sp, #0x10
    6150:      	ldr	x19, [x19]
    6154:      	mov	x0, x19
    6158:      	blr	x8
    615c:      	cbz	x0, 0x6094 <generic_usdt_filter_arg+0x3c4>
    6160:      	mov	w8, #0x3                // =3
    6164:      	add	x9, sp, #0x10
    6168:      	add	x1, sp, #0x10
    616c:      	mov	x0, x19
    6170:      	blr	x8
    6174:      	b	0x6094 <generic_usdt_filter_arg+0x3c4>
    6178:      	nop
    617c:      	nop

0000000000006180 <generic_usdt_actions>:
    6180:      	sub	sp, sp, #0x40
    6184:      	str	x30, [sp, #0x10]
    6188:      	stp	x22, x21, [sp, #0x20]
    618c:      	stp	x20, x19, [sp, #0x30]
    6190:      	mov	x19, x0
    6194:      	str	wzr, [sp, #0xc]
    6198:      	adrp	x0, 0x6000 <generic_usdt_filter_arg+0x330>
    619c:      	mov	w8, #0x1                // =1
    61a0:      	ldr	x0, [x0]
    61a4:      	add	x9, sp, #0xc
    61a8:      	add	x1, sp, #0xc
    61ac:      	blr	x8
    61b0:      	cbz	x0, 0x62c8 <generic_usdt_actions+0x148>
    61b4:      	mov	w8, #0x5f04             // =24324
    61b8:      	ldr	w22, [x0, x8]
    61bc:      	cmp	w22, #0x2
    61c0:      	b.lt	0x62c8 <generic_usdt_actions+0x148>
    61c4:      	mov	w8, #0x5ef8             // =24312
    61c8:      	mov	w20, #0x1               // =1
    61cc:      	add	x1, x0, x8
    61d0:      	adrp	x0, 0x6000 <generic_usdt_filter_arg+0x330>
    61d4:      	mov	w8, #0x1                // =1
    61d8:      	ldr	x0, [x0]
    61dc:      	blr	x8
    61e0:      	cbz	x0, 0x62c8 <generic_usdt_actions+0x148>
    61e4:      	and	x8, x22, #0x7ff
    61e8:      	mov	x21, x0
    61ec:      	strb	w20, [sp, #0x1c]
    61f0:      	mov	w9, #0x1                // =1
    61f4:      	ldr	w8, [x0, x8]
    61f8:      	str	wzr, [sp, #0x18]
    61fc:      	adrp	x0, 0x6000 <generic_usdt_filter_arg+0x330>
    6200:      	add	x1, sp, #0x18
    6204:      	ldr	x0, [x0]
    6208:      	add	w8, w8, w22
    620c:      	and	w22, w8, #0x7ff
    6210:      	add	x8, sp, #0x18
    6214:      	blr	x9
    6218:      	cbz	x0, 0x6228 <generic_usdt_actions+0xa8>
    621c:      	ldrb	w8, [x0]
    6220:      	cmp	w8, #0x0
    6224:      	cset	w20, eq
    6228:      	ldr	w8, [x21, x22]
    622c:      	cmp	w8, #0x5
    6230:      	b.lo	0x62a4 <generic_usdt_actions+0x124>
    6234:      	add	x2, x21, x22
    6238:      	add	x3, sp, #0x1c
    623c:      	mov	x0, x19
    6240:      	mov	w1, wzr
    6244:      	mov	w4, w20
    6248:      	bl	0x6248 <generic_usdt_actions+0xc8>
    624c:      	ldr	w9, [x21, x22]
    6250:      	lsl	w8, w0, #2
    6254:      	add	w8, w8, #0x4
    6258:      	cmp	w8, w9
    625c:      	b.hs	0x62a4 <generic_usdt_actions+0x124>
    6260:      	mov	w1, w0
    6264:      	add	x2, x21, x22
    6268:      	add	x3, sp, #0x1c
    626c:      	mov	x0, x19
    6270:      	mov	w4, w20
    6274:      	bl	0x6274 <generic_usdt_actions+0xf4>
    6278:      	ldr	w9, [x21, x22]
    627c:      	lsl	w8, w0, #2
    6280:      	add	w8, w8, #0x4
    6284:      	cmp	w8, w9
    6288:      	b.hs	0x62a4 <generic_usdt_actions+0x124>
    628c:      	mov	w1, w0
    6290:      	add	x2, x21, x22
    6294:      	add	x3, sp, #0x1c
    6298:      	mov	x0, x19
    629c:      	mov	w4, w20
    62a0:      	bl	0x62a0 <generic_usdt_actions+0x120>
    62a4:      	ldrb	w8, [sp, #0x1c]
    62a8:      	cbz	w8, 0x62c8 <generic_usdt_actions+0x148>
    62ac:      	adrp	x1, 0x6000 <generic_usdt_filter_arg+0x330>
    62b0:      	mov	w8, #0x5                // =5
    62b4:      	mov	w9, #0xc                // =12
    62b8:      	ldr	x1, [x1]
    62bc:      	mov	x0, x19
    62c0:      	mov	w2, #0x5                // =5
    62c4:      	blr	x9
    62c8:      	ldp	x20, x19, [sp, #0x30]
    62cc:      	mov	w0, wzr
    62d0:      	ldr	x30, [sp, #0x10]
    62d4:      	ldp	x22, x21, [sp, #0x20]
    62d8:      	add	sp, sp, #0x40
    62dc:      	ret

00000000000062e0 <generic_usdt_output>:
    62e0:      	sub	sp, sp, #0xc0
    62e4:      	str	x29, [sp, #0x70]
    62e8:      	stp	x30, x25, [sp, #0x80]
    62ec:      	stp	x24, x23, [sp, #0x90]
    62f0:      	stp	x22, x21, [sp, #0xa0]
    62f4:      	stp	x20, x19, [sp, #0xb0]
    62f8:      	mov	x20, x0
    62fc:      	str	wzr, [sp, #0x4]
    6300:      	adrp	x0, 0x6000 <generic_usdt_filter_arg+0x330>
    6304:      	mov	w8, #0x1                // =1
    6308:      	ldr	x0, [x0]
    630c:      	add	x9, sp, #0x4
    6310:      	add	x1, sp, #0x4
    6314:      	blr	x8
    6318:      	cbz	x0, 0x68b0 <generic_usdt_output+0x5d0>
    631c:      	adrp	x21, 0x6000 <generic_usdt_filter_arg+0x330>
    6320:      	ldr	x8, [x0, #0x5ee8]
    6324:      	mov	x19, x0
    6328:      	ldr	x21, [x21]
    632c:      	cbz	x8, 0x65b8 <generic_usdt_output+0x2d8>
    6330:      	mov	w8, #0xe                // =14
    6334:      	blr	x8
    6338:      	mov	w8, #0x23               // =35
    633c:      	lsr	x22, x0, #32
    6340:      	blr	x8
    6344:      	str	w22, [sp, #0x28]
    6348:      	mov	w8, #0x1                // =1
    634c:      	add	x9, sp, #0x28
    6350:      	mov	x23, x0
    6354:      	add	x1, sp, #0x28
    6358:      	mov	x0, x21
    635c:      	blr	x8
    6360:      	cbz	x0, 0x65b8 <generic_usdt_output+0x2d8>
    6364:      	add	x2, x23, #0xb50
    6368:      	mov	w29, #0x8               // =8
    636c:      	add	x8, sp, #0x78
    6370:      	mov	w9, #0x4                // =4
    6374:      	mov	x22, x0
    6378:      	add	x24, x0, #0x28
    637c:      	add	x0, sp, #0x78
    6380:      	mov	w1, #0x8                // =8
    6384:      	mov	w25, #0x4               // =4
    6388:      	blr	x9
    638c:      	ldr	x8, [sp, #0x78]
    6390:      	mov	w9, #0x48               // =72
    6394:      	add	x10, sp, #0x28
    6398:      	mov	w11, #0x4               // =4
    639c:      	ldr	x2, [sp, #0x78]
    63a0:      	add	x0, sp, #0x28
    63a4:      	mov	w1, #0x48               // =72
    63a8:      	blr	x11
    63ac:      	ldr	x8, [sp, #0x30]
    63b0:      	mov	w9, #0x4                // =4
    63b4:      	mov	x0, x24
    63b8:      	mov	w1, #0x4                // =4
    63bc:      	add	x8, x8, #0x218
    63c0:      	ldr	x8, [sp, #0x30]
    63c4:      	add	x2, x8, #0x218
    63c8:      	blr	x9
    63cc:      	ldr	x8, [sp, #0x38]
    63d0:      	add	x0, x22, #0x2c
    63d4:      	mov	w9, #0x4                // =4
    63d8:      	mov	w1, #0x4                // =4
    63dc:      	add	x8, x8, #0x4d8
    63e0:      	ldr	x8, [sp, #0x38]
    63e4:      	add	x2, x8, #0x4d8
    63e8:      	blr	x9
    63ec:      	ldr	x8, [sp, #0x40]
    63f0:      	add	x0, x22, #0x30
    63f4:      	mov	w9, #0x4                // =4
    63f8:      	mov	w1, #0x4                // =4
    63fc:      	add	x8, x8, #0x58
    6400:      	ldr	x8, [sp, #0x40]
    6404:      	add	x2, x8, #0x58
    6408:      	blr	x9
    640c:      	str	xzr, [sp, #0x20]
    6410:      	add	x2, x23, #0x938
    6414:      	add	x8, sp, #0x20
    6418:      	add	x0, sp, #0x20
    641c:      	mov	w1, #0x8                // =8
    6420:      	blr	x25
    6424:      	ldr	x8, [sp, #0x20]
    6428:      	cbz	x8, 0x64ac <generic_usdt_output+0x1cc>
    642c:      	str	wzr, [sp, #0x1c]
    6430:      	add	x8, x8, #0x4
    6434:      	add	x9, sp, #0x1c
    6438:      	mov	w10, #0x4               // =4
    643c:      	add	x0, sp, #0x1c
    6440:      	mov	w1, #0x4                // =4
    6444:      	mov	w24, #0x4               // =4
    6448:      	ldr	x8, [sp, #0x20]
    644c:      	add	x2, x8, #0x4
    6450:      	blr	x10
    6454:      	ldr	x8, [sp, #0x20]
    6458:      	ldrsw	x9, [sp, #0x1c]
    645c:      	add	x10, sp, #0x8
    6460:      	mov	w11, #0x4               // =4
    6464:      	add	x0, sp, #0x8
    6468:      	mov	w1, #0x10               // =16
    646c:      	add	x8, x8, x9, lsl #4
    6470:      	mov	w9, #0x10               // =16
    6474:      	add	x8, x8, #0x80
    6478:      	ldr	x8, [sp, #0x20]
    647c:      	ldrsw	x9, [sp, #0x1c]
    6480:      	add	x8, x8, x9, lsl #4
    6484:      	add	x2, x8, #0x80
    6488:      	blr	x11
    648c:      	ldr	x8, [sp, #0x10]
    6490:      	add	x0, x22, #0x34
    6494:      	mov	w1, #0x4                // =4
    6498:      	add	x8, x8, #0x158
    649c:      	ldr	x8, [sp, #0x10]
    64a0:      	add	x2, x8, #0x158
    64a4:      	blr	x24
    64a8:      	b	0x64b0 <generic_usdt_output+0x1d0>
    64ac:      	str	wzr, [x22, #0x34]
    64b0:      	ldr	x8, [sp, #0x48]
    64b4:      	add	x0, x22, #0x38
    64b8:      	mov	w9, #0x4                // =4
    64bc:      	mov	w1, #0x4                // =4
    64c0:      	mov	w24, #0x4               // =4
    64c4:      	add	x8, x8, #0x158
    64c8:      	ldr	x8, [sp, #0x48]
    64cc:      	add	x2, x8, #0x158
    64d0:      	blr	x9
    64d4:      	ldr	x8, [sp, #0x50]
    64d8:      	add	x0, x22, #0x3c
    64dc:      	mov	w9, #0x4                // =4
    64e0:      	mov	w1, #0x4                // =4
    64e4:      	add	x8, x8, #0x118
    64e8:      	ldr	x8, [sp, #0x50]
    64ec:      	add	x2, x8, #0x118
    64f0:      	blr	x9
    64f4:      	ldr	x8, [sp, #0x58]
    64f8:      	add	x0, x22, #0x40
    64fc:      	mov	w9, #0x4                // =4
    6500:      	mov	w1, #0x4                // =4
    6504:      	add	x8, x8, #0x98
    6508:      	ldr	x8, [sp, #0x58]
    650c:      	add	x2, x8, #0x98
    6510:      	blr	x9
    6514:      	ldr	x8, [sp, #0x60]
    6518:      	add	x0, x22, #0x44
    651c:      	mov	w9, #0x4                // =4
    6520:      	mov	w1, #0x4                // =4
    6524:      	add	x8, x8, #0x98
    6528:      	ldr	x8, [sp, #0x60]
    652c:      	add	x2, x8, #0x98
    6530:      	blr	x9
    6534:      	ldr	x8, [sp, #0x68]
    6538:      	add	x0, x22, #0x48
    653c:      	mov	w9, #0x4                // =4
    6540:      	mov	w1, #0x4                // =4
    6544:      	add	x8, x8, #0x58
    6548:      	ldr	x8, [sp, #0x68]
    654c:      	add	x2, x8, #0x58
    6550:      	blr	x9
    6554:      	str	xzr, [sp, #0x8]
    6558:      	str	xzr, [sp, #0x20]
    655c:      	add	x2, x23, #0xae0
    6560:      	mov	w23, #0x8               // =8
    6564:      	add	x8, sp, #0x8
    6568:      	mov	w9, #0x4                // =4
    656c:      	add	x0, sp, #0x8
    6570:      	mov	w1, #0x8                // =8
    6574:      	blr	x9
    6578:      	ldr	x8, [sp, #0x8]
    657c:      	add	x9, sp, #0x20
    6580:      	mov	w10, #0x4               // =4
    6584:      	add	x0, sp, #0x20
    6588:      	mov	w1, #0x8                // =8
    658c:      	add	x8, x8, #0x90
    6590:      	ldr	x8, [sp, #0x8]
    6594:      	add	x2, x8, #0x90
    6598:      	blr	x10
    659c:      	ldr	x8, [sp, #0x20]
    65a0:      	add	x0, x22, #0x4c
    65a4:      	mov	w1, #0x4                // =4
    65a8:      	add	x8, x8, #0x158
    65ac:      	ldr	x8, [sp, #0x20]
    65b0:      	add	x2, x8, #0x158
    65b4:      	blr	x24
    65b8:      	ldr	x8, [x19, #0x5ef0]
    65bc:      	cbz	x8, 0x6658 <generic_usdt_output+0x378>
    65c0:      	mov	w8, #0xe                // =14
    65c4:      	blr	x8
    65c8:      	mov	w8, #0x23               // =35
    65cc:      	lsr	x23, x0, #32
    65d0:      	blr	x8
    65d4:      	str	w23, [sp, #0x28]
    65d8:      	mov	w8, #0x1                // =1
    65dc:      	add	x9, sp, #0x28
    65e0:      	mov	x22, x0
    65e4:      	add	x1, sp, #0x28
    65e8:      	mov	x0, x21
    65ec:      	blr	x8
    65f0:      	cbz	x0, 0x6658 <generic_usdt_output+0x378>
    65f4:      	add	x2, x22, #0xae0
    65f8:      	mov	w22, #0x8               // =8
    65fc:      	add	x8, sp, #0x28
    6600:      	mov	w9, #0x4                // =4
    6604:      	add	x21, x0, #0x50
    6608:      	mov	x24, x0
    660c:      	add	x0, sp, #0x28
    6610:      	mov	w1, #0x8                // =8
    6614:      	mov	w23, #0x4               // =4
    6618:      	blr	x9
    661c:      	ldr	x25, [sp, #0x28]
    6620:      	add	x0, x24, #0x58
    6624:      	mov	w8, #0x4                // =4
    6628:      	mov	w1, #0x8                // =8
    662c:      	add	x2, x25, #0x40
    6630:      	blr	x8
    6634:      	add	x0, x24, #0x60
    6638:      	add	x2, x25, #0x30
    663c:      	mov	w8, #0x4                // =4
    6640:      	mov	w1, #0x8                // =8
    6644:      	blr	x8
    6648:      	add	x2, x25, #0x38
    664c:      	mov	x0, x21
    6650:      	mov	w1, #0x8                // =8
    6654:      	blr	x23
    6658:      	ldr	w8, [x19, #0x4]
    665c:      	mov	w9, #0x2328             // =9000
    6660:      	str	wzr, [sp, #0x8]
    6664:      	adrp	x0, 0x6000 <generic_usdt_filter_arg+0x330>
    6668:      	add	x1, sp, #0x8
    666c:      	add	w8, w8, #0x90
    6670:      	ldr	x0, [x0]
    6674:      	and	w8, w8, #0x7fff
    6678:      	cmp	w8, w9
    667c:      	csel	w21, w8, w9, lo
    6680:      	mov	w8, #0x1                // =1
    6684:      	add	x9, sp, #0x8
    6688:      	blr	x8
    668c:      	cbz	x0, 0x66f8 <generic_usdt_output+0x418>
    6690:      	ldrb	w8, [x0, #0x28]
    6694:      	cbz	w8, 0x66f8 <generic_usdt_output+0x418>
    6698:      	adrp	x1, 0x6000 <generic_usdt_filter_arg+0x330>
    669c:      	mov	w8, #-0x1               // =-1
    66a0:      	mov	w9, #0x19               // =25
    66a4:      	ldr	x1, [x1]
    66a8:      	mov	x0, x20
    66ac:      	mov	w2, #-0x1               // =-1
    66b0:      	mov	x3, x19
    66b4:      	mov	x4, x21
    66b8:      	blr	x9
    66bc:      	tbnz	x0, #0x3f, 0x67a4 <generic_usdt_output+0x4c4>
    66c0:      	str	wzr, [sp, #0x28]
    66c4:      	adrp	x0, 0x6000 <generic_usdt_filter_arg+0x330>
    66c8:      	mov	w8, #0x1                // =1
    66cc:      	add	x9, sp, #0x28
    66d0:      	ldr	x0, [x0]
    66d4:      	add	x1, sp, #0x28
    66d8:      	blr	x8
    66dc:      	cbz	x0, 0x68b0 <generic_usdt_output+0x5d0>
    66e0:      	add	x8, x0, #0x8
    66e4:      	ldaxr	x9, [x8]
    66e8:      	add	x9, x9, #0x1
    66ec:      	stlxr	w10, x9, [x8]
    66f0:      	cbnz	w10, 0x66e4 <generic_usdt_output+0x404>
    66f4:      	b	0x68b0 <generic_usdt_output+0x5d0>
    66f8:      	adrp	x0, 0x6000 <generic_usdt_filter_arg+0x330>
    66fc:      	mov	x3, xzr
    6700:      	mov	w8, #0x82               // =130
    6704:      	ldr	x0, [x0]
    6708:      	mov	x1, x19
    670c:      	mov	x2, x21
    6710:      	blr	x8
    6714:      	tbnz	x0, #0x3f, 0x6754 <generic_usdt_output+0x474>
    6718:      	str	wzr, [sp, #0x28]
    671c:      	adrp	x0, 0x6000 <generic_usdt_filter_arg+0x330>
    6720:      	mov	w8, #0x1                // =1
    6724:      	add	x9, sp, #0x28
    6728:      	ldr	x0, [x0]
    672c:      	add	x1, sp, #0x28
    6730:      	blr	x8
    6734:      	cbz	x0, 0x68b0 <generic_usdt_output+0x5d0>
    6738:      	add	x8, x0, #0x8
    673c:      	nop
    6740:      	ldaxr	x9, [x8]
    6744:      	add	x9, x9, #0x1
    6748:      	stlxr	w10, x9, [x8]
    674c:      	cbnz	w10, 0x6740 <generic_usdt_output+0x460>
    6750:      	b	0x68b0 <generic_usdt_output+0x5d0>
    6754:      	mov	x19, x0
    6758:      	str	wzr, [sp, #0x28]
    675c:      	adrp	x0, 0x6000 <generic_usdt_filter_arg+0x330>
    6760:      	mov	w8, #0x1                // =1
    6764:      	ldr	x0, [x0]
    6768:      	add	x9, sp, #0x28
    676c:      	add	x1, sp, #0x28
    6770:      	blr	x8
    6774:      	cbz	x0, 0x68b0 <generic_usdt_output+0x5d0>
    6778:      	mov	x8, x19
    677c:      	cmn	x19, #0xc
    6780:      	b.gt	0x67f4 <generic_usdt_output+0x514>
    6784:      	cmn	x8, #0x1c
    6788:      	b.eq	0x6834 <generic_usdt_output+0x554>
    678c:      	cmn	x8, #0x16
    6790:      	b.eq	0x684c <generic_usdt_output+0x56c>
    6794:      	cmn	x8, #0x10
    6798:      	b.ne	0x6844 <generic_usdt_output+0x564>
    679c:      	add	x8, x0, #0x638
    67a0:      	b	0x6860 <generic_usdt_output+0x580>
    67a4:      	mov	x19, x0
    67a8:      	str	wzr, [sp, #0x28]
    67ac:      	adrp	x0, 0x6000 <generic_usdt_filter_arg+0x330>
    67b0:      	mov	w8, #0x1                // =1
    67b4:      	ldr	x0, [x0]
    67b8:      	add	x9, sp, #0x28
    67bc:      	add	x1, sp, #0x28
    67c0:      	blr	x8
    67c4:      	cbz	x0, 0x68b0 <generic_usdt_output+0x5d0>
    67c8:      	mov	x8, x19
    67cc:      	cmn	x19, #0xc
    67d0:      	b.gt	0x6814 <generic_usdt_output+0x534>
    67d4:      	cmn	x8, #0x1c
    67d8:      	b.eq	0x6874 <generic_usdt_output+0x594>
    67dc:      	cmn	x8, #0x16
    67e0:      	b.eq	0x688c <generic_usdt_output+0x5ac>
    67e4:      	cmn	x8, #0x10
    67e8:      	b.ne	0x6884 <generic_usdt_output+0x5a4>
    67ec:      	add	x8, x0, #0x638
    67f0:      	b	0x68a0 <generic_usdt_output+0x5c0>
    67f4:      	cmn	x8, #0xb
    67f8:      	b.eq	0x683c <generic_usdt_output+0x55c>
    67fc:      	cmn	x8, #0x7
    6800:      	b.eq	0x6854 <generic_usdt_output+0x574>
    6804:      	cmn	x8, #0x2
    6808:      	b.ne	0x6844 <generic_usdt_output+0x564>
    680c:      	add	x8, x0, #0x628
    6810:      	b	0x6860 <generic_usdt_output+0x580>
    6814:      	cmn	x8, #0xb
    6818:      	b.eq	0x687c <generic_usdt_output+0x59c>
    681c:      	cmn	x8, #0x7
    6820:      	b.eq	0x6894 <generic_usdt_output+0x5b4>
    6824:      	cmn	x8, #0x2
    6828:      	b.ne	0x6884 <generic_usdt_output+0x5a4>
    682c:      	add	x8, x0, #0x628
    6830:      	b	0x68a0 <generic_usdt_output+0x5c0>
    6834:      	add	x8, x0, #0x648
    6838:      	b	0x6860 <generic_usdt_output+0x580>
    683c:      	add	x8, x0, #0x650
    6840:      	b	0x6860 <generic_usdt_output+0x580>
    6844:      	add	x8, x0, #0x620
    6848:      	b	0x6860 <generic_usdt_output+0x580>
    684c:      	add	x8, x0, #0x640
    6850:      	b	0x6860 <generic_usdt_output+0x580>
    6854:      	add	x8, x0, #0x630
    6858:      	nop
    685c:      	nop
    6860:      	ldaxr	x9, [x8]
    6864:      	add	x9, x9, #0x1
    6868:      	stlxr	w10, x9, [x8]
    686c:      	cbnz	w10, 0x6860 <generic_usdt_output+0x580>
    6870:      	b	0x68b0 <generic_usdt_output+0x5d0>
    6874:      	add	x8, x0, #0x648
    6878:      	b	0x68a0 <generic_usdt_output+0x5c0>
    687c:      	add	x8, x0, #0x650
    6880:      	b	0x68a0 <generic_usdt_output+0x5c0>
    6884:      	add	x8, x0, #0x620
    6888:      	b	0x68a0 <generic_usdt_output+0x5c0>
    688c:      	add	x8, x0, #0x640
    6890:      	b	0x68a0 <generic_usdt_output+0x5c0>
    6894:      	add	x8, x0, #0x630
    6898:      	nop
    689c:      	nop
    68a0:      	ldaxr	x9, [x8]
    68a4:      	add	x9, x9, #0x1
    68a8:      	stlxr	w10, x9, [x8]
    68ac:      	cbnz	w10, 0x68a0 <generic_usdt_output+0x5c0>
    68b0:      	ldp	x20, x19, [sp, #0xb0]
    68b4:      	mov	w0, wzr
    68b8:      	ldr	x29, [sp, #0x70]
    68bc:      	ldp	x22, x21, [sp, #0xa0]
    68c0:      	ldp	x24, x23, [sp, #0x90]
    68c4:      	ldp	x30, x25, [sp, #0x80]
    68c8:      	add	sp, sp, #0xc0
    68cc:      	ret

Disassembly of section uprobe/generic_usdt:

0000000000000000 <generic_usdt_event>:
       0:      	sub	sp, sp, #0xd0
       4:      	stp	x30, x25, [sp, #0x90]
       8:      	stp	x24, x23, [sp, #0xa0]
       c:      	stp	x22, x21, [sp, #0xb0]
      10:      	stp	x20, x19, [sp, #0xc0]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0xc]
      1c:      	adrp	x0, 0x0 <generic_usdt_event>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0xc
      2c:      	add	x1, sp, #0xc
      30:      	blr	x8
      34:      	cbz	x0, 0x538 <generic_usdt_event+0x538>
      38:      	add	x23, x0, #0x5, lsl #12  // =0x5000
      3c:      	mov	x20, x0
      40:      	adrp	x0, 0x0 <generic_usdt_event>
      44:      	str	wzr, [x23, #0xef8]
      48:      	add	x1, x23, #0xef8
      4c:      	mov	w8, #0x1                // =1
      50:      	ldr	x0, [x0]
      54:      	blr	x8
      58:      	cbz	x0, 0x538 <generic_usdt_event+0x538>
      5c:      	ldr	w8, [x0, #0x64]
      60:      	str	w8, [sp, #0x1c]
      64:      	cbz	w8, 0x220 <generic_usdt_event+0x220>
      68:      	adrp	x21, 0x0 <generic_usdt_event>
      6c:      	mov	w8, #0x1                // =1
      70:      	add	x9, sp, #0x1c
      74:      	ldr	x21, [x21]
      78:      	mov	x24, x0
      7c:      	add	x1, sp, #0x1c
      80:      	mov	x0, x21
      84:      	blr	x8
      88:      	cbz	x0, 0x538 <generic_usdt_event+0x538>
      8c:      	mov	x22, x0
      90:      	str	wzr, [sp, #0x84]
      94:      	adrp	x0, 0x0 <generic_usdt_event>
      98:      	mov	w8, #0x1                // =1
      9c:      	ldr	x0, [x0]
      a0:      	add	x9, sp, #0x84
      a4:      	add	x1, sp, #0x84
      a8:      	blr	x8
      ac:      	cbz	x0, 0xd8 <generic_usdt_event+0xd8>
      b0:      	ldr	x8, [x0, #0x20]
      b4:      	mov	w9, #0x7270             // =29296
      b8:      	movk	w9, #0x6367, lsl #16
      bc:      	cmp	x8, x9
      c0:      	b.ne	0xe0 <generic_usdt_event+0xe0>
      c4:      	mov	w8, #0x50               // =80
      c8:      	blr	x8
      cc:      	str	x0, [sp, #0x30]
      d0:      	cbnz	x0, 0x1d4 <generic_usdt_event+0x1d4>
      d4:      	b	0x538 <generic_usdt_event+0x538>
      d8:      	mov	w25, wzr
      dc:      	b	0xe4 <generic_usdt_event+0xe4>
      e0:      	ldr	w25, [x0, #0x10]
      e4:      	mov	w8, #0x23               // =35
      e8:      	blr	x8
      ec:      	str	xzr, [sp, #0x88]
      f0:      	add	x2, x0, #0xcd0
      f4:      	mov	w8, #0x8                // =8
      f8:      	mov	w9, #0x71               // =113
      fc:      	add	x10, sp, #0x20
     100:      	add	x0, sp, #0x20
     104:      	mov	w1, #0x8                // =8
     108:      	blr	x9
     10c:      	ldr	x8, [sp, #0x20]
     110:      	cbz	x8, 0x538 <generic_usdt_event+0x538>
     114:      	cmp	w25, #0xb
     118:      	b.hi	0x538 <generic_usdt_event+0x538>
     11c:      	ubfiz	x9, x25, #3, #32
     120:      	mov	w10, #0x8               // =8
     124:      	mov	w11, #0x71              // =113
     128:      	add	x12, sp, #0x38
     12c:      	add	x0, sp, #0x38
     130:      	mov	w1, #0x8                // =8
     134:      	add	x8, x8, x9
     138:      	ldr	x8, [sp, #0x20]
     13c:      	add	x2, x8, x9
     140:      	blr	x11
     144:      	ldr	x8, [sp, #0x38]
     148:      	cbz	x8, 0x538 <generic_usdt_event+0x538>
     14c:      	mov	w9, #0x8                // =8
     150:      	mov	w10, #0x71              // =113
     154:      	add	x11, sp, #0x88
     158:      	ldr	x2, [sp, #0x38]
     15c:      	add	x0, sp, #0x88
     160:      	mov	w1, #0x8                // =8
     164:      	blr	x10
     168:      	ldr	x8, [sp, #0x88]
     16c:      	cbz	x8, 0x538 <generic_usdt_event+0x538>
     170:      	str	xzr, [sp, #0x38]
     174:      	add	x2, x8, #0x100
     178:      	mov	w8, #0x8                // =8
     17c:      	mov	w9, #0x71               // =113
     180:      	add	x10, sp, #0x38
     184:      	add	x0, sp, #0x38
     188:      	mov	w1, #0x8                // =8
     18c:      	blr	x9
     190:      	ldr	x8, [sp, #0x38]
     194:      	str	xzr, [sp, #0x38]
     198:      	cbz	x8, 0x1c8 <generic_usdt_event+0x1c8>
     19c:      	add	x2, x8, #0x60
     1a0:      	mov	w8, #0x8                // =8
     1a4:      	mov	w9, #0x71               // =113
     1a8:      	add	x10, sp, #0x38
     1ac:      	add	x0, sp, #0x38
     1b0:      	mov	w1, #0x8                // =8
     1b4:      	blr	x9
     1b8:      	ldr	x0, [sp, #0x38]
     1bc:      	str	x0, [sp, #0x30]
     1c0:      	cbnz	x0, 0x1d4 <generic_usdt_event+0x1d4>
     1c4:      	b	0x538 <generic_usdt_event+0x538>
     1c8:      	mov	x0, xzr
     1cc:      	str	xzr, [sp, #0x30]
     1d0:      	cbz	xzr, 0x538 <generic_usdt_event+0x538>
     1d4:      	str	x0, [sp, #0x38]
     1d8:      	adrp	x0, 0x0 <generic_usdt_event>
     1dc:      	mov	w8, #0x1                // =1
     1e0:      	add	x9, sp, #0x38
     1e4:      	ldr	x0, [x0]
     1e8:      	add	x1, sp, #0x38
     1ec:      	blr	x8
     1f0:      	cbz	x0, 0x200 <generic_usdt_event+0x200>
     1f4:      	ldr	x8, [x0]
     1f8:      	cbz	x8, 0x200 <generic_usdt_event+0x200>
     1fc:      	str	x8, [sp, #0x30]
     200:      	mov	w8, #0x1                // =1
     204:      	add	x9, sp, #0x30
     208:      	add	x1, sp, #0x30
     20c:      	mov	x0, x22
     210:      	blr	x8
     214:      	mov	x8, x0
     218:      	mov	x0, x24
     21c:      	cbz	x8, 0x554 <generic_usdt_event+0x554>
     220:      	ldr	w8, [x0]
     224:      	add	x9, x23, #0xefc
     228:      	str	xzr, [x20, #0x5eb8]
     22c:      	str	xzr, [x20, #0x5ec0]
     230:      	str	xzr, [x20, #0x5ec8]
     234:      	str	xzr, [x9]
     238:      	str	xzr, [x20, #0x5ed0]
     23c:      	str	xzr, [x20, #0x5ed8]
     240:      	stp	x8, xzr, [x20, #0x60]
     244:      	mov	w8, #0x5eb8             // =24248
     248:      	add	x8, x20, x8
     24c:      	strb	wzr, [x8, #0x28]
     250:      	mov	w8, #0x23               // =35
     254:      	blr	x8
     258:      	add	x2, x0, #0xb50
     25c:      	mov	w25, #0x8               // =8
     260:      	add	x8, sp, #0x88
     264:      	mov	w9, #0x4                // =4
     268:      	mov	x21, x0
     26c:      	add	x0, sp, #0x88
     270:      	mov	w1, #0x8                // =8
     274:      	add	x22, x20, #0x20
     278:      	mov	w24, #0x4               // =4
     27c:      	blr	x9
     280:      	ldr	x8, [sp, #0x88]
     284:      	mov	w9, #0x48               // =72
     288:      	add	x10, sp, #0x38
     28c:      	mov	w11, #0x4               // =4
     290:      	ldr	x2, [sp, #0x88]
     294:      	add	x0, sp, #0x38
     298:      	mov	w1, #0x48               // =72
     29c:      	blr	x11
     2a0:      	ldr	x8, [sp, #0x40]
     2a4:      	mov	w9, #0x4                // =4
     2a8:      	mov	x0, x22
     2ac:      	mov	w1, #0x4                // =4
     2b0:      	add	x8, x8, #0x218
     2b4:      	ldr	x8, [sp, #0x40]
     2b8:      	add	x2, x8, #0x218
     2bc:      	blr	x9
     2c0:      	ldr	x8, [sp, #0x48]
     2c4:      	add	x0, x20, #0x24
     2c8:      	mov	w9, #0x4                // =4
     2cc:      	mov	w1, #0x4                // =4
     2d0:      	add	x8, x8, #0x4d8
     2d4:      	ldr	x8, [sp, #0x48]
     2d8:      	add	x2, x8, #0x4d8
     2dc:      	blr	x9
     2e0:      	ldr	x8, [sp, #0x50]
     2e4:      	add	x0, x20, #0x28
     2e8:      	mov	w9, #0x4                // =4
     2ec:      	mov	w1, #0x4                // =4
     2f0:      	add	x8, x8, #0x58
     2f4:      	ldr	x8, [sp, #0x50]
     2f8:      	add	x2, x8, #0x58
     2fc:      	blr	x9
     300:      	str	xzr, [sp, #0x30]
     304:      	add	x2, x21, #0x938
     308:      	add	x8, sp, #0x30
     30c:      	add	x0, sp, #0x30
     310:      	mov	w1, #0x8                // =8
     314:      	blr	x24
     318:      	ldr	x8, [sp, #0x30]
     31c:      	cbz	x8, 0x3a0 <generic_usdt_event+0x3a0>
     320:      	str	wzr, [sp, #0x10]
     324:      	add	x8, x8, #0x4
     328:      	add	x9, sp, #0x10
     32c:      	mov	w10, #0x4               // =4
     330:      	add	x0, sp, #0x10
     334:      	mov	w1, #0x4                // =4
     338:      	mov	w22, #0x4               // =4
     33c:      	ldr	x8, [sp, #0x30]
     340:      	add	x2, x8, #0x4
     344:      	blr	x10
     348:      	ldr	x8, [sp, #0x30]
     34c:      	ldrsw	x9, [sp, #0x10]
     350:      	add	x10, sp, #0x20
     354:      	mov	w11, #0x4               // =4
     358:      	add	x0, sp, #0x20
     35c:      	mov	w1, #0x10               // =16
     360:      	add	x8, x8, x9, lsl #4
     364:      	mov	w9, #0x10               // =16
     368:      	add	x8, x8, #0x80
     36c:      	ldr	x8, [sp, #0x30]
     370:      	ldrsw	x9, [sp, #0x10]
     374:      	add	x8, x8, x9, lsl #4
     378:      	add	x2, x8, #0x80
     37c:      	blr	x11
     380:      	ldr	x8, [sp, #0x28]
     384:      	add	x0, x20, #0x2c
     388:      	mov	w1, #0x4                // =4
     38c:      	add	x8, x8, #0x158
     390:      	ldr	x8, [sp, #0x28]
     394:      	add	x2, x8, #0x158
     398:      	blr	x22
     39c:      	b	0x3a4 <generic_usdt_event+0x3a4>
     3a0:      	str	wzr, [x20, #0x2c]
     3a4:      	ldr	x8, [sp, #0x58]
     3a8:      	add	x0, x20, #0x30
     3ac:      	mov	w9, #0x4                // =4
     3b0:      	mov	w1, #0x4                // =4
     3b4:      	mov	w24, #0x4               // =4
     3b8:      	add	x8, x8, #0x158
     3bc:      	ldr	x8, [sp, #0x58]
     3c0:      	add	x2, x8, #0x158
     3c4:      	blr	x9
     3c8:      	ldr	x8, [sp, #0x60]
     3cc:      	add	x0, x20, #0x34
     3d0:      	mov	w9, #0x4                // =4
     3d4:      	mov	w1, #0x4                // =4
     3d8:      	add	x8, x8, #0x118
     3dc:      	ldr	x8, [sp, #0x60]
     3e0:      	add	x2, x8, #0x118
     3e4:      	blr	x9
     3e8:      	ldr	x8, [sp, #0x68]
     3ec:      	add	x0, x20, #0x38
     3f0:      	mov	w9, #0x4                // =4
     3f4:      	mov	w1, #0x4                // =4
     3f8:      	add	x8, x8, #0x98
     3fc:      	ldr	x8, [sp, #0x68]
     400:      	add	x2, x8, #0x98
     404:      	blr	x9
     408:      	ldr	x8, [sp, #0x70]
     40c:      	add	x0, x20, #0x3c
     410:      	mov	w9, #0x4                // =4
     414:      	mov	w1, #0x4                // =4
     418:      	add	x8, x8, #0x98
     41c:      	ldr	x8, [sp, #0x70]
     420:      	add	x2, x8, #0x98
     424:      	blr	x9
     428:      	ldr	x8, [sp, #0x78]
     42c:      	add	x0, x20, #0x40
     430:      	mov	w9, #0x4                // =4
     434:      	mov	w1, #0x4                // =4
     438:      	add	x8, x8, #0x58
     43c:      	ldr	x8, [sp, #0x78]
     440:      	add	x2, x8, #0x58
     444:      	blr	x9
     448:      	str	xzr, [sp, #0x20]
     44c:      	str	xzr, [sp, #0x30]
     450:      	add	x21, x21, #0xae0
     454:      	mov	w25, #0x8               // =8
     458:      	add	x8, sp, #0x20
     45c:      	mov	w9, #0x4                // =4
     460:      	add	x0, sp, #0x20
     464:      	mov	w1, #0x8                // =8
     468:      	mov	x2, x21
     46c:      	blr	x9
     470:      	ldr	x8, [sp, #0x20]
     474:      	add	x9, sp, #0x30
     478:      	mov	w10, #0x4               // =4
     47c:      	add	x0, sp, #0x30
     480:      	mov	w1, #0x8                // =8
     484:      	add	x8, x8, #0x90
     488:      	ldr	x8, [sp, #0x20]
     48c:      	add	x2, x8, #0x90
     490:      	blr	x10
     494:      	ldr	x8, [sp, #0x30]
     498:      	add	x0, x20, #0x44
     49c:      	mov	w9, #0x4                // =4
     4a0:      	mov	w1, #0x4                // =4
     4a4:      	add	x8, x8, #0x158
     4a8:      	ldr	x8, [sp, #0x30]
     4ac:      	add	x2, x8, #0x158
     4b0:      	blr	x9
     4b4:      	add	x8, sp, #0x38
     4b8:      	mov	w9, #0x4                // =4
     4bc:      	add	x0, sp, #0x38
     4c0:      	mov	w1, #0x8                // =8
     4c4:      	mov	x2, x21
     4c8:      	add	x22, x20, #0x48
     4cc:      	blr	x9
     4d0:      	ldr	x21, [sp, #0x38]
     4d4:      	add	x0, x20, #0x50
     4d8:      	mov	w8, #0x4                // =4
     4dc:      	mov	w1, #0x8                // =8
     4e0:      	add	x2, x21, #0x40
     4e4:      	blr	x8
     4e8:      	add	x0, x20, #0x58
     4ec:      	add	x2, x21, #0x30
     4f0:      	mov	w8, #0x4                // =4
     4f4:      	mov	w1, #0x8                // =8
     4f8:      	blr	x8
     4fc:      	add	x2, x21, #0x38
     500:      	mov	x0, x22
     504:      	mov	w1, #0x8                // =8
     508:      	blr	x24
     50c:      	strb	wzr, [x23, #0xf08]
     510:      	strb	wzr, [x20, #0x1]
     514:      	adrp	x1, 0x0 <generic_usdt_event>
     518:      	mov	w8, #0x2                // =2
     51c:      	mov	w9, #0xc                // =12
     520:      	mov	x0, x19
     524:      	str	xzr, [x20, #0x5ee8]
     528:      	str	xzr, [x20, #0x5ef0]
     52c:      	ldr	x1, [x1]
     530:      	mov	w2, #0x2                // =2
     534:      	blr	x9
     538:      	ldp	x20, x19, [sp, #0xc0]
     53c:      	mov	w0, wzr
     540:      	ldp	x22, x21, [sp, #0xb0]
     544:      	ldp	x24, x23, [sp, #0xa0]
     548:      	ldp	x30, x25, [sp, #0x90]
     54c:      	add	sp, sp, #0xd0
     550:      	ret
     554:      	mov	x8, #-0x1               // =-1
     558:      	mov	w9, #0x1                // =1
     55c:      	add	x1, sp, #0x10
     560:      	str	x8, [sp, #0x10]
     564:      	add	x8, sp, #0x10
     568:      	mov	x0, x22
     56c:      	mov	w25, #0x1               // =1
     570:      	blr	x9
     574:      	cbz	x0, 0x538 <generic_usdt_event+0x538>
     578:      	str	w25, [sp, #0x1c]
     57c:      	add	x8, sp, #0x1c
     580:      	add	x1, sp, #0x1c
     584:      	mov	x0, x21
     588:      	blr	x25
     58c:      	cbz	x0, 0x538 <generic_usdt_event+0x538>
     590:      	mov	w8, #0x1                // =1
     594:      	add	x9, sp, #0x30
     598:      	add	x1, sp, #0x30
     59c:      	blr	x8
     5a0:      	mov	x8, x0
     5a4:      	mov	x0, x24
     5a8:      	cbnz	x8, 0x538 <generic_usdt_event+0x538>
     5ac:      	b	0x220 <generic_usdt_event+0x220>

Disassembly of section uprobe.s/generic_usdt:

0000000000000000 <generic_sleepable_preload>:
       0:      	sub	sp, sp, #0x30
       4:      	stp	x30, x19, [sp, #0x20]
       8:      	mov	x19, x0
       c:      	str	wzr, [sp, #0x1c]
      10:      	adrp	x0, 0x0 <generic_sleepable_preload>
      14:      	mov	w8, #0x1                // =1
      18:      	ldr	x0, [x0]
      1c:      	add	x9, sp, #0x1c
      20:      	add	x1, sp, #0x1c
      24:      	blr	x8
      28:      	cbz	x0, 0x7c <generic_sleepable_preload+0x7c>
      2c:      	stp	x0, x19, [sp, #0x8]
      30:      	adrp	x8, 0x0 <generic_sleepable_preload>
      34:      	ldr	x8, [x8]
      38:      	ldrb	w8, [x8]
      3c:      	cbz	w8, 0x8c <generic_sleepable_preload+0x8c>
      40:      	add	x1, sp, #0x8
      44:      	mov	w0, wzr
      48:      	bl	0x48 <generic_sleepable_preload+0x48>
      4c:      	add	x1, sp, #0x8
      50:      	mov	w0, #0x1                // =1
      54:      	bl	0x54 <generic_sleepable_preload+0x54>
      58:      	add	x1, sp, #0x8
      5c:      	mov	w0, #0x2                // =2
      60:      	bl	0x60 <generic_sleepable_preload+0x60>
      64:      	add	x1, sp, #0x8
      68:      	mov	w0, #0x3                // =3
      6c:      	bl	0x6c <generic_sleepable_preload+0x6c>
      70:      	add	x1, sp, #0x8
      74:      	mov	w0, #0x4                // =4
      78:      	bl	0x78 <generic_sleepable_preload+0x78>
      7c:      	ldp	x30, x19, [sp, #0x20]
      80:      	mov	w0, wzr
      84:      	add	sp, sp, #0x30
      88:      	ret
      8c:      	mov	x3, xzr
      90:      	adrp	x1, 0x0 <generic_sleepable_preload>
      94:      	add	x1, x1, #0x0
      98:      	mov	w8, #0x5                // =5
      9c:      	mov	w9, #0xb5               // =181
      a0:      	add	x10, sp, #0x8
      a4:      	add	x2, sp, #0x8
      a8:      	mov	w0, #0x5                // =5
      ac:      	blr	x9
      b0:      	ldp	x30, x19, [sp, #0x20]
      b4:      	mov	w0, wzr
      b8:      	add	sp, sp, #0x30
      bc:      	ret

00000000000000c0 <generic_sleepable_preload_cleanup>:
      c0:      	str	x30, [sp, #-0x10]!
      c4:      	mov	w8, #0xe                // =14
      c8:      	blr	x8
      cc:      	str	x0, [sp, #0x8]
      d0:      	adrp	x0, 0x0 <generic_sleepable_preload>
      d4:      	mov	w8, #0x3                // =3
      d8:      	add	x9, sp, #0x8
      dc:      	ldr	x0, [x0]
      e0:      	add	x1, sp, #0x8
      e4:      	blr	x8
      e8:      	mov	w0, wzr
      ec:      	ldr	x30, [sp], #0x10
      f0:      	ret
      f4:      	nop
      f8:      	nop
      fc:      	nop

0000000000000100 <generic_sleepable_offload>:
     100:      	sub	sp, sp, #0x20
     104:      	stp	x30, x19, [sp, #0x10]
     108:      	mov	w8, #0xe                // =14
     10c:      	blr	x8
     110:      	str	x0, [sp, #0x8]
     114:      	adrp	x19, 0x0 <generic_sleepable_preload>
     118:      	mov	w8, #0x1                // =1
     11c:      	add	x9, sp, #0x8
     120:      	ldr	x19, [x19]
     124:      	add	x1, sp, #0x8
     128:      	mov	x0, x19
     12c:      	blr	x8
     130:      	cbz	x0, 0x164 <generic_sleepable_offload+0x64>
     134:      	ldr	x8, [x0]
     138:      	add	x1, x0, #0x8
     13c:      	mov	w9, #0x4                // =4
     140:      	mov	w10, #0x24              // =36
     144:      	ldr	x0, [x0]
     148:      	mov	w2, #0x4                // =4
     14c:      	blr	x10
     150:      	mov	w8, #0x3                // =3
     154:      	add	x9, sp, #0x8
     158:      	add	x1, sp, #0x8
     15c:      	mov	x0, x19
     160:      	blr	x8
     164:      	ldp	x30, x19, [sp, #0x10]
     168:      	mov	w0, wzr
     16c:      	add	sp, sp, #0x20
     170:      	ret
