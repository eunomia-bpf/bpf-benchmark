
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/otel/ruby_tracer.native.o:	file format elf64-littleaarch64

Disassembly of section perf_event/unwind_ruby:

0000000000000000 <perf_unwind_ruby>:
       0:      	sub	sp, sp, #0xd0
       4:      	str	x29, [sp, #0x80]
       8:      	stp	x30, x25, [sp, #0x90]
       c:      	stp	x24, x23, [sp, #0xa0]
      10:      	stp	x22, x21, [sp, #0xb0]
      14:      	stp	x20, x19, [sp, #0xc0]
      18:      	str	wzr, [sp, #0x8]
      1c:      	adrp	x21, 0x0 <perf_unwind_ruby>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x8
      28:      	ldr	x21, [x21]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0x8
      34:      	mov	x0, x21
      38:      	blr	x8
      3c:      	cbz	x0, 0x390 <perf_unwind_ruby+0x390>
      40:      	ldr	w8, [x0]
      44:      	mov	x22, x0
      48:      	adrp	x0, 0x0 <perf_unwind_ruby>
      4c:      	add	x9, sp, #0x4c
      50:      	str	w8, [sp, #0x4c]
      54:      	mov	w8, #0x1                // =1
      58:      	add	x1, sp, #0x4c
      5c:      	ldr	x0, [x0]
      60:      	blr	x8
      64:      	adrp	x25, 0x0 <perf_unwind_ruby>
      68:      	adrp	x20, 0x0 <perf_unwind_ruby>
      6c:      	ldr	x25, [x25]
      70:      	ldr	x20, [x20]
      74:      	cbz	x0, 0x130 <perf_unwind_ruby+0x130>
      78:      	mov	w8, #0x35               // =53
      7c:      	add	x9, sp, #0x78
      80:      	mov	x23, x0
      84:      	str	w8, [sp, #0x78]
      88:      	mov	w8, #0x1                // =1
      8c:      	add	x1, sp, #0x78
      90:      	mov	x0, x20
      94:      	blr	x8
      98:      	cbz	x0, 0x168 <perf_unwind_ruby+0x168>
      9c:      	ldr	x8, [x0]
      a0:      	add	x8, x8, #0x1
      a4:      	str	x8, [x0]
      a8:      	ldr	x8, [x23, #0x8]
      ac:      	str	xzr, [sp, #0x40]
      b0:      	cbnz	x8, 0x17c <perf_unwind_ruby+0x17c>
      b4:      	ldr	w8, [x23]
      b8:      	cmp	w8, #0x30, lsl #12      // =0x30000
      bc:      	b.lo	0x288 <perf_unwind_ruby+0x288>
      c0:      	str	xzr, [sp, #0x8]
      c4:      	ldr	x8, [x23, #0x10]
      c8:      	mov	w9, #0x8                // =8
      cc:      	mov	w10, #0x70              // =112
      d0:      	add	x11, sp, #0x8
      d4:      	add	x0, sp, #0x8
      d8:      	mov	w1, #0x8                // =8
      dc:      	ldr	x2, [x23, #0x10]
      e0:      	blr	x10
      e4:      	cbnz	x0, 0x2b8 <perf_unwind_ruby+0x2b8>
      e8:      	ldr	x8, [sp, #0x8]
      ec:      	ldrh	w9, [x23, #0x24]
      f0:      	mov	w10, #0x70              // =112
      f4:      	add	x11, sp, #0x40
      f8:      	add	x0, sp, #0x40
      fc:      	mov	w1, #0x8                // =8
     100:      	add	x8, x8, x9
     104:      	mov	w9, #0x8                // =8
     108:      	ldr	x8, [sp, #0x8]
     10c:      	ldrh	w9, [x23, #0x24]
     110:      	add	x2, x8, x9
     114:      	blr	x10
     118:      	mov	w8, wzr
     11c:      	mov	w24, #0x1               // =1
     120:      	cbnz	x0, 0x2c0 <perf_unwind_ruby+0x2c0>
     124:      	ldr	x29, [sp, #0x40]
     128:      	cbnz	x29, 0x5f4 <perf_unwind_ruby+0x5f4>
     12c:      	b	0x2c0 <perf_unwind_ruby+0x2c0>
     130:      	ldr	w8, [x25]
     134:      	cbnz	w8, 0x3b0 <perf_unwind_ruby+0x3b0>
     138:      	mov	w8, #0x49               // =73
     13c:      	add	x9, sp, #0x78
     140:      	add	x1, sp, #0x78
     144:      	str	w8, [sp, #0x78]
     148:      	mov	w8, #0x1                // =1
     14c:      	mov	x0, x20
     150:      	blr	x8
     154:      	cbz	x0, 0x278 <perf_unwind_ruby+0x278>
     158:      	ldr	x8, [x0]
     15c:      	add	x8, x8, #0x1
     160:      	str	x8, [x0]
     164:      	b	0x280 <perf_unwind_ruby+0x280>
     168:      	ldr	w8, [x25]
     16c:      	cbnz	w8, 0x42c <perf_unwind_ruby+0x42c>
     170:      	ldr	x8, [x23, #0x8]
     174:      	str	xzr, [sp, #0x40]
     178:      	cbz	x8, 0xb4 <perf_unwind_ruby+0xb4>
     17c:      	mov	w8, #0x23               // =35
     180:      	blr	x8
     184:      	adrp	x8, 0x0 <perf_unwind_ruby>
     188:      	mov	w9, #0x71               // =113
     18c:      	add	x10, sp, #0x78
     190:      	ldr	x8, [x8]
     194:      	mov	w1, #0x8                // =8
     198:      	ldr	x8, [x8]
     19c:      	add	x2, x0, x8
     1a0:      	mov	w8, #0x8                // =8
     1a4:      	add	x0, sp, #0x78
     1a8:      	blr	x9
     1ac:      	cbz	x0, 0x234 <perf_unwind_ruby+0x234>
     1b0:      	ldr	w8, [x25]
     1b4:      	cbnz	w8, 0x3f0 <perf_unwind_ruby+0x3f0>
     1b8:      	mov	w8, #0x4                // =4
     1bc:      	add	x9, sp, #0x70
     1c0:      	add	x1, sp, #0x70
     1c4:      	str	w8, [sp, #0x70]
     1c8:      	mov	w8, #0x1                // =1
     1cc:      	mov	x0, x20
     1d0:      	blr	x8
     1d4:      	cbz	x0, 0x348 <perf_unwind_ruby+0x348>
     1d8:      	ldr	x8, [x0]
     1dc:      	add	x8, x8, #0x1
     1e0:      	str	x8, [x0]
     1e4:      	ldr	w8, [x25]
     1e8:      	cbz	w8, 0x350 <perf_unwind_ruby+0x350>
     1ec:      	mov	w8, #0x7075             // =28789
     1f0:      	add	x0, sp, #0x8
     1f4:      	mov	w1, #0x34               // =52
     1f8:      	movk	w8, #0xa, lsl #16
     1fc:      	str	w8, [sp, #0x38]
     200:      	adrp	x8, 0x0 <perf_unwind_ruby>
     204:      	add	x8, x8, #0x0
     208:      	ldp	x9, x10, [x8, #0x10]
     20c:      	stp	x9, x10, [sp, #0x18]
     210:      	ldp	x9, x10, [x8, #0x20]
     214:      	stp	x9, x10, [sp, #0x28]
     218:      	ldp	x9, x8, [x8]
     21c:      	add	x10, sp, #0x8
     220:      	stp	x9, x8, [sp, #0x8]
     224:      	mov	w8, #0x34               // =52
     228:      	mov	w9, #0x6                // =6
     22c:      	blr	x9
     230:      	b	0x350 <perf_unwind_ruby+0x350>
     234:      	ldr	x8, [sp, #0x78]
     238:      	ldr	x9, [x23, #0x8]
     23c:      	add	x2, x9, x8
     240:      	ldr	w8, [x25]
     244:      	cbnz	w8, 0x480 <perf_unwind_ruby+0x480>
     248:      	mov	w8, #0x8                // =8
     24c:      	mov	w9, #0x70               // =112
     250:      	add	x10, sp, #0x40
     254:      	add	x0, sp, #0x40
     258:      	mov	w1, #0x8                // =8
     25c:      	blr	x9
     260:      	cbnz	x0, 0x2b8 <perf_unwind_ruby+0x2b8>
     264:      	ldr	w8, [x25]
     268:      	cbnz	w8, 0x5ac <perf_unwind_ruby+0x5ac>
     26c:      	ldr	x29, [sp, #0x40]
     270:      	cbnz	x29, 0x5f4 <perf_unwind_ruby+0x5f4>
     274:      	b	0x2b8 <perf_unwind_ruby+0x2b8>
     278:      	ldr	w8, [x25]
     27c:      	cbnz	w8, 0x4cc <perf_unwind_ruby+0x4cc>
     280:      	mov	w8, #0xbb8              // =3000
     284:      	b	0x2bc <perf_unwind_ruby+0x2bc>
     288:      	ldr	x8, [x23, #0x10]
     28c:      	mov	w9, #0x8                // =8
     290:      	mov	w10, #0x70              // =112
     294:      	add	x11, sp, #0x40
     298:      	ldr	x2, [x23, #0x10]
     29c:      	add	x0, sp, #0x40
     2a0:      	mov	w1, #0x8                // =8
     2a4:      	blr	x10
     2a8:      	ldr	x29, [sp, #0x40]
     2ac:      	cmp	x0, #0x0
     2b0:      	ccmp	x29, #0x0, #0x4, eq
     2b4:      	b.ne	0x5f4 <perf_unwind_ruby+0x5f4>
     2b8:      	mov	w8, wzr
     2bc:      	mov	w24, #0x1               // =1
     2c0:      	str	w8, [x22, #0xf1c]
     2c4:      	str	wzr, [sp, #0x8]
     2c8:      	mov	w8, #0x1                // =1
     2cc:      	add	x9, sp, #0x8
     2d0:      	add	x1, sp, #0x8
     2d4:      	mov	x0, x21
     2d8:      	blr	x8
     2dc:      	cbz	x0, 0x32c <perf_unwind_ruby+0x32c>
     2e0:      	mov	w21, #0x1374            // =4980
     2e4:      	ldrb	w8, [x0, x21]
     2e8:      	cmp	w8, #0x1d
     2ec:      	b.lo	0x36c <perf_unwind_ruby+0x36c>
     2f0:      	mov	w8, #0x5                // =5
     2f4:      	add	x9, sp, #0x78
     2f8:      	mov	x22, x0
     2fc:      	str	w8, [x0, #0xf1c]
     300:      	mov	w8, #0x44               // =68
     304:      	add	x1, sp, #0x78
     308:      	mov	x0, x20
     30c:      	str	w8, [sp, #0x78]
     310:      	mov	w8, #0x1                // =1
     314:      	blr	x8
     318:      	cbz	x0, 0x358 <perf_unwind_ruby+0x358>
     31c:      	ldr	x8, [x0]
     320:      	add	x8, x8, #0x1
     324:      	str	x8, [x0]
     328:      	b	0x360 <perf_unwind_ruby+0x360>
     32c:      	adrp	x1, 0x0 <perf_unwind_ruby>
     330:      	mov	x8, xzr
     334:      	mov	w9, #0xc                // =12
     338:      	ldr	x1, [x1]
     33c:      	mov	x0, x19
     340:      	mov	w2, wzr
     344:      	b	0x38c <perf_unwind_ruby+0x38c>
     348:      	ldr	w8, [x25]
     34c:      	cbnz	w8, 0x514 <perf_unwind_ruby+0x514>
     350:      	mov	w0, wzr
     354:      	b	0x394 <perf_unwind_ruby+0x394>
     358:      	ldr	w8, [x25]
     35c:      	cbnz	w8, 0x564 <perf_unwind_ruby+0x564>
     360:      	ldrb	w8, [x22, x21]
     364:      	mov	w24, wzr
     368:      	mov	x0, x22
     36c:      	add	w8, w8, #0x1
     370:      	adrp	x1, 0x0 <perf_unwind_ruby>
     374:      	mov	w9, #0xc                // =12
     378:      	strb	w8, [x0, x21]
     37c:      	mov	w8, w24
     380:      	mov	x0, x19
     384:      	mov	w2, w24
     388:      	ldr	x1, [x1]
     38c:      	blr	x9
     390:      	mov	w0, #-0x1               // =-1
     394:      	ldp	x20, x19, [sp, #0xc0]
     398:      	ldr	x29, [sp, #0x80]
     39c:      	ldp	x22, x21, [sp, #0xb0]
     3a0:      	ldp	x24, x23, [sp, #0xa0]
     3a4:      	ldp	x30, x25, [sp, #0x90]
     3a8:      	add	sp, sp, #0xd0
     3ac:      	ret
     3b0:      	mov	w8, #0x6174             // =24948
     3b4:      	add	x0, sp, #0x8
     3b8:      	mov	w1, #0x1c               // =28
     3bc:      	movk	w8, #0xa, lsl #16
     3c0:      	str	w8, [sp, #0x20]
     3c4:      	adrp	x8, 0x0 <perf_unwind_ruby>
     3c8:      	add	x8, x8, #0x0
     3cc:      	ldp	x9, x10, [x8]
     3d0:      	ldr	x8, [x8, #0x10]
     3d4:      	stp	x9, x10, [sp, #0x8]
     3d8:      	str	x8, [sp, #0x18]
     3dc:      	mov	w8, #0x1c               // =28
     3e0:      	mov	w9, #0x6                // =6
     3e4:      	add	x10, sp, #0x8
     3e8:      	blr	x9
     3ec:      	b	0x138 <perf_unwind_ruby+0x138>
     3f0:      	adrp	x8, 0x0 <perf_unwind_ruby>
     3f4:      	add	x8, x8, #0x0
     3f8:      	add	x0, sp, #0x8
     3fc:      	ldp	x9, x10, [x8]
     400:      	mov	w1, #0x1d               // =29
     404:      	stp	x9, x10, [sp, #0x8]
     408:      	ldr	x9, [x8, #0x10]
     40c:      	ldur	x8, [x8, #0x15]
     410:      	add	x10, sp, #0x8
     414:      	str	x9, [sp, #0x18]
     418:      	stur	x8, [sp, #0x1d]
     41c:      	mov	w8, #0x1d               // =29
     420:      	mov	w9, #0x6                // =6
     424:      	blr	x9
     428:      	b	0x1b8 <perf_unwind_ruby+0x1b8>
     42c:      	adrp	x8, 0x0 <perf_unwind_ruby>
     430:      	add	x8, x8, #0x0
     434:      	add	x0, sp, #0x8
     438:      	ldp	x9, x10, [x8, #0x10]
     43c:      	mov	w1, #0x2e               // =46
     440:      	stp	x9, x10, [sp, #0x18]
     444:      	ldr	x9, [x8, #0x20]
     448:      	add	x10, sp, #0x8
     44c:      	str	x9, [sp, #0x28]
     450:      	ldur	x9, [x8, #0x26]
     454:      	stur	x9, [sp, #0x2e]
     458:      	ldp	x9, x8, [x8]
     45c:      	stp	x9, x8, [sp, #0x8]
     460:      	mov	w8, #0x2e               // =46
     464:      	mov	w9, #0x6                // =6
     468:      	ldr	w2, [sp, #0x78]
     46c:      	blr	x9
     470:      	ldr	x8, [x23, #0x8]
     474:      	str	xzr, [sp, #0x40]
     478:      	cbnz	x8, 0x17c <perf_unwind_ruby+0x17c>
     47c:      	b	0xb4 <perf_unwind_ruby+0xb4>
     480:      	adrp	x8, 0x0 <perf_unwind_ruby>
     484:      	add	x8, x8, #0x0
     488:      	strb	wzr, [sp, #0x38]
     48c:      	add	x0, sp, #0x8
     490:      	ldp	x9, x10, [x8, #0x10]
     494:      	mov	w1, #0x31               // =49
     498:      	mov	x3, x2
     49c:      	mov	x24, x2
     4a0:      	stp	x9, x10, [sp, #0x18]
     4a4:      	ldp	x9, x10, [x8, #0x20]
     4a8:      	stp	x9, x10, [sp, #0x28]
     4ac:      	ldp	x9, x8, [x8]
     4b0:      	add	x10, sp, #0x8
     4b4:      	stp	x9, x8, [sp, #0x8]
     4b8:      	mov	w8, #0x31               // =49
     4bc:      	mov	w9, #0x6                // =6
     4c0:      	blr	x9
     4c4:      	mov	x2, x24
     4c8:      	b	0x248 <perf_unwind_ruby+0x248>
     4cc:      	adrp	x8, 0x0 <perf_unwind_ruby>
     4d0:      	add	x8, x8, #0x0
     4d4:      	add	x0, sp, #0x8
     4d8:      	ldp	x9, x10, [x8, #0x10]
     4dc:      	mov	w1, #0x2e               // =46
     4e0:      	stp	x9, x10, [sp, #0x18]
     4e4:      	ldr	x9, [x8, #0x20]
     4e8:      	add	x10, sp, #0x8
     4ec:      	str	x9, [sp, #0x28]
     4f0:      	ldur	x9, [x8, #0x26]
     4f4:      	stur	x9, [sp, #0x2e]
     4f8:      	ldp	x9, x8, [x8]
     4fc:      	stp	x9, x8, [sp, #0x8]
     500:      	mov	w8, #0x2e               // =46
     504:      	mov	w9, #0x6                // =6
     508:      	ldr	w2, [sp, #0x78]
     50c:      	blr	x9
     510:      	b	0x280 <perf_unwind_ruby+0x280>
     514:      	adrp	x8, 0x0 <perf_unwind_ruby>
     518:      	add	x8, x8, #0x0
     51c:      	add	x0, sp, #0x8
     520:      	ldp	x9, x10, [x8, #0x10]
     524:      	mov	w1, #0x2e               // =46
     528:      	stp	x9, x10, [sp, #0x18]
     52c:      	ldr	x9, [x8, #0x20]
     530:      	add	x10, sp, #0x8
     534:      	str	x9, [sp, #0x28]
     538:      	ldur	x9, [x8, #0x26]
     53c:      	stur	x9, [sp, #0x2e]
     540:      	ldp	x9, x8, [x8]
     544:      	stp	x9, x8, [sp, #0x8]
     548:      	mov	w8, #0x2e               // =46
     54c:      	mov	w9, #0x6                // =6
     550:      	ldr	w2, [sp, #0x70]
     554:      	blr	x9
     558:      	ldr	w8, [x25]
     55c:      	cbz	w8, 0x350 <perf_unwind_ruby+0x350>
     560:      	b	0x1ec <perf_unwind_ruby+0x1ec>
     564:      	adrp	x8, 0x0 <perf_unwind_ruby>
     568:      	add	x8, x8, #0x0
     56c:      	add	x0, sp, #0x8
     570:      	ldp	x9, x10, [x8, #0x10]
     574:      	mov	w1, #0x2e               // =46
     578:      	stp	x9, x10, [sp, #0x18]
     57c:      	ldr	x9, [x8, #0x20]
     580:      	add	x10, sp, #0x8
     584:      	str	x9, [sp, #0x28]
     588:      	ldur	x9, [x8, #0x26]
     58c:      	stur	x9, [sp, #0x2e]
     590:      	ldp	x9, x8, [x8]
     594:      	stp	x9, x8, [sp, #0x8]
     598:      	mov	w8, #0x2e               // =46
     59c:      	mov	w9, #0x6                // =6
     5a0:      	ldr	w2, [sp, #0x78]
     5a4:      	blr	x9
     5a8:      	b	0x360 <perf_unwind_ruby+0x360>
     5ac:      	mov	w8, #0x786c             // =30828
     5b0:      	add	x0, sp, #0x8
     5b4:      	mov	w1, #0x1b               // =27
     5b8:      	movk	w8, #0xa, lsl #16
     5bc:      	stur	w8, [sp, #0x1f]
     5c0:      	adrp	x8, 0x0 <perf_unwind_ruby>
     5c4:      	add	x8, x8, #0x0
     5c8:      	ldp	x9, x10, [x8]
     5cc:      	ldr	x8, [x8, #0x10]
     5d0:      	stp	x9, x10, [sp, #0x8]
     5d4:      	str	x8, [sp, #0x18]
     5d8:      	mov	w8, #0x1b               // =27
     5dc:      	mov	w9, #0x6                // =6
     5e0:      	add	x10, sp, #0x8
     5e4:      	ldr	x2, [sp, #0x40]
     5e8:      	blr	x9
     5ec:      	ldr	x29, [sp, #0x40]
     5f0:      	cbz	x29, 0x2b8 <perf_unwind_ruby+0x2b8>
     5f4:      	ldr	x8, [x22, #0xf58]
     5f8:      	str	x8, [sp, #0x78]
     5fc:      	cbz	x8, 0x6ec <perf_unwind_ruby+0x6ec>
     600:      	ldr	x9, [x22, #0xf60]
     604:      	cbz	x9, 0x6ec <perf_unwind_ruby+0x6ec>
     608:      	str	x9, [sp]
     60c:      	ldrb	w9, [x23, #0x1c]
     610:      	mov	x29, x20
     614:      	mov	w20, #0x8               // =8
     618:      	mov	w10, #0x70              // =112
     61c:      	add	x0, sp, #0x70
     620:      	mov	w1, #0x8                // =8
     624:      	str	xzr, [sp, #0x60]
     628:      	str	xzr, [sp, #0x70]
     62c:      	mov	w24, #0x70              // =112
     630:      	add	x8, x8, x9
     634:      	add	x9, sp, #0x70
     638:      	ldr	x8, [sp, #0x78]
     63c:      	ldrb	w9, [x23, #0x1c]
     640:      	add	x2, x8, x9
     644:      	blr	x10
     648:      	ldr	x8, [sp, #0x78]
     64c:      	ldrb	w9, [x23, #0x1b]
     650:      	add	x0, sp, #0x60
     654:      	mov	w1, #0x8                // =8
     658:      	add	x8, x8, x9
     65c:      	add	x9, sp, #0x60
     660:      	ldr	x8, [sp, #0x78]
     664:      	ldrb	w9, [x23, #0x1b]
     668:      	add	x2, x8, x9
     66c:      	blr	x24
     670:      	ldr	x8, [sp, #0x60]
     674:      	cbz	x8, 0x758 <perf_unwind_ruby+0x758>
     678:      	ldr	x8, [sp, #0x70]
     67c:      	cbz	x8, 0x758 <perf_unwind_ruby+0x758>
     680:      	ldrb	w9, [x23, #0x1f]
     684:      	mov	w10, #0x70              // =112
     688:      	add	x11, sp, #0x68
     68c:      	add	x0, sp, #0x68
     690:      	mov	w1, #0x8                // =8
     694:      	add	x8, x8, x9
     698:      	mov	w9, #0x8                // =8
     69c:      	ldr	x8, [sp, #0x70]
     6a0:      	ldrb	w9, [x23, #0x1f]
     6a4:      	add	x2, x8, x9
     6a8:      	blr	x10
     6ac:      	mov	x20, x29
     6b0:      	cbz	x0, 0x9f4 <perf_unwind_ruby+0x9f4>
     6b4:      	ldr	w8, [x25]
     6b8:      	cbnz	w8, 0x171c <perf_unwind_ruby+0x171c>
     6bc:      	mov	w8, #0x4e               // =78
     6c0:      	add	x9, sp, #0x50
     6c4:      	add	x1, sp, #0x50
     6c8:      	str	w8, [sp, #0x50]
     6cc:      	mov	w8, #0x1                // =1
     6d0:      	mov	x0, x20
     6d4:      	blr	x8
     6d8:      	cbz	x0, 0xa60 <perf_unwind_ruby+0xa60>
     6dc:      	ldr	x8, [x0]
     6e0:      	add	x8, x8, #0x1
     6e4:      	str	x8, [x0]
     6e8:      	b	0xa68 <perf_unwind_ruby+0xa68>
     6ec:      	ldrb	w8, [x23, #0x18]
     6f0:      	mov	w9, #0x8                // =8
     6f4:      	mov	w10, #0x70              // =112
     6f8:      	add	x11, sp, #0x70
     6fc:      	add	x0, sp, #0x70
     700:      	mov	w1, #0x8                // =8
     704:      	add	x8, x29, x8
     708:      	ldrb	w8, [x23, #0x18]
     70c:      	add	x2, x29, x8
     710:      	blr	x10
     714:      	cbz	x0, 0x904 <perf_unwind_ruby+0x904>
     718:      	ldr	w8, [x25]
     71c:      	cbnz	w8, 0x16d4 <perf_unwind_ruby+0x16d4>
     720:      	mov	w8, #0x4a               // =74
     724:      	add	x9, sp, #0x60
     728:      	add	x1, sp, #0x60
     72c:      	str	w8, [sp, #0x60]
     730:      	mov	w8, #0x1                // =1
     734:      	mov	x0, x20
     738:      	blr	x8
     73c:      	cbz	x0, 0x9e0 <perf_unwind_ruby+0x9e0>
     740:      	ldr	x8, [x0]
     744:      	mov	w24, wzr
     748:      	add	x8, x8, #0x1
     74c:      	str	x8, [x0]
     750:      	mov	w8, #0xbb9              // =3001
     754:      	b	0x2c0 <perf_unwind_ruby+0x2c0>
     758:      	ldr	w8, [x23]
     75c:      	mov	x20, x29
     760:      	lsr	w8, w8, #9
     764:      	cmp	w8, #0x103
     768:      	b.hs	0x970 <perf_unwind_ruby+0x970>
     76c:      	ldr	x8, [sp, #0x78]
     770:      	ldr	x9, [sp]
     774:      	cmp	x9, x8
     778:      	b.ls	0x2b8 <perf_unwind_ruby+0x2b8>
     77c:      	ldrb	w9, [x23, #0x1e]
     780:      	str	xzr, [sp, #0x60]
     784:      	mov	w20, #0x8               // =8
     788:      	mov	w10, #0x70              // =112
     78c:      	add	x0, sp, #0x70
     790:      	mov	w1, #0x8                // =8
     794:      	mov	w24, #0x70              // =112
     798:      	add	x8, x8, x9
     79c:      	ldrb	w9, [x23, #0x1c]
     7a0:      	stp	xzr, x8, [sp, #0x70]
     7a4:      	add	x8, x8, x9
     7a8:      	add	x9, sp, #0x70
     7ac:      	ldr	x8, [sp, #0x78]
     7b0:      	ldrb	w9, [x23, #0x1c]
     7b4:      	add	x2, x8, x9
     7b8:      	blr	x10
     7bc:      	ldr	x8, [sp, #0x78]
     7c0:      	ldrb	w9, [x23, #0x1b]
     7c4:      	add	x0, sp, #0x60
     7c8:      	mov	w1, #0x8                // =8
     7cc:      	add	x8, x8, x9
     7d0:      	add	x9, sp, #0x60
     7d4:      	ldr	x8, [sp, #0x78]
     7d8:      	ldrb	w9, [x23, #0x1b]
     7dc:      	add	x2, x8, x9
     7e0:      	blr	x24
     7e4:      	ldr	x8, [sp, #0x60]
     7e8:      	cbz	x8, 0xb48 <perf_unwind_ruby+0xb48>
     7ec:      	ldr	x8, [sp, #0x70]
     7f0:      	cbz	x8, 0xb48 <perf_unwind_ruby+0xb48>
     7f4:      	ldrb	w9, [x23, #0x1f]
     7f8:      	mov	w10, #0x70              // =112
     7fc:      	add	x11, sp, #0x68
     800:      	add	x0, sp, #0x68
     804:      	mov	w1, #0x8                // =8
     808:      	add	x8, x8, x9
     80c:      	mov	w9, #0x8                // =8
     810:      	ldr	x8, [sp, #0x70]
     814:      	ldrb	w9, [x23, #0x1f]
     818:      	add	x2, x8, x9
     81c:      	blr	x10
     820:      	mov	x20, x29
     824:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
     828:      	ldr	x8, [sp, #0x68]
     82c:      	ldrb	w9, [x23, #0x21]
     830:      	mov	w10, #0x70              // =112
     834:      	add	x11, sp, #0x58
     838:      	add	x0, sp, #0x58
     83c:      	mov	w1, #0x8                // =8
     840:      	add	x8, x8, x9
     844:      	mov	w9, #0x8                // =8
     848:      	ldr	x8, [sp, #0x68]
     84c:      	ldrb	w9, [x23, #0x21]
     850:      	add	x2, x8, x9
     854:      	blr	x10
     858:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
     85c:      	ldr	x8, [sp, #0x68]
     860:      	ldrb	w9, [x23, #0x22]
     864:      	mov	w10, #0x70              // =112
     868:      	add	x11, sp, #0x88
     86c:      	add	x0, sp, #0x88
     870:      	mov	w1, #0x4                // =4
     874:      	add	x8, x8, x9
     878:      	mov	w9, #0x4                // =4
     87c:      	ldr	x8, [sp, #0x68]
     880:      	ldrb	w9, [x23, #0x22]
     884:      	add	x2, x8, x9
     888:      	blr	x10
     88c:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
     890:      	ldrb	w9, [x23, #0x23]
     894:      	ldr	x8, [sp, #0x60]
     898:      	cbz	x9, 0x1200 <perf_unwind_ruby+0x1200>
     89c:      	ldr	x10, [sp, #0x58]
     8a0:      	sub	x10, x8, x10
     8a4:      	udiv	x9, x10, x9
     8a8:      	ldr	w10, [sp, #0x88]
     8ac:      	cmp	x9, x10
     8b0:      	b.ls	0x1200 <perf_unwind_ruby+0x1200>
     8b4:      	ldr	w8, [x25]
     8b8:      	mov	x20, x29
     8bc:      	cbz	w8, 0xb5c <perf_unwind_ruby+0xb5c>
     8c0:      	adrp	x8, 0x0 <perf_unwind_ruby>
     8c4:      	add	x8, x8, #0x0
     8c8:      	add	x0, sp, #0x8
     8cc:      	ldp	x9, x10, [x8, #0x10]
     8d0:      	mov	w1, #0x2d               // =45
     8d4:      	stp	x9, x10, [sp, #0x18]
     8d8:      	ldr	x9, [x8, #0x20]
     8dc:      	add	x10, sp, #0x8
     8e0:      	str	x9, [sp, #0x28]
     8e4:      	ldur	x9, [x8, #0x25]
     8e8:      	stur	x9, [sp, #0x2d]
     8ec:      	ldp	x9, x8, [x8]
     8f0:      	stp	x9, x8, [sp, #0x8]
     8f4:      	mov	w8, #0x2d               // =45
     8f8:      	mov	w9, #0x6                // =6
     8fc:      	blr	x9
     900:      	b	0xb5c <perf_unwind_ruby+0xb5c>
     904:      	ldrb	w8, [x23, #0x19]
     908:      	mov	w9, #0x8                // =8
     90c:      	mov	w10, #0x70              // =112
     910:      	add	x11, sp, #0x68
     914:      	add	x0, sp, #0x68
     918:      	mov	w1, #0x8                // =8
     91c:      	add	x8, x29, x8
     920:      	ldrb	w8, [x23, #0x19]
     924:      	add	x2, x29, x8
     928:      	blr	x10
     92c:      	cbz	x0, 0xa74 <perf_unwind_ruby+0xa74>
     930:      	ldr	w8, [x25]
     934:      	cbnz	w8, 0x17b4 <perf_unwind_ruby+0x17b4>
     938:      	mov	w8, #0x4b               // =75
     93c:      	add	x9, sp, #0x60
     940:      	add	x1, sp, #0x60
     944:      	str	w8, [sp, #0x60]
     948:      	mov	w8, #0x1                // =1
     94c:      	mov	x0, x20
     950:      	blr	x8
     954:      	cbz	x0, 0xb34 <perf_unwind_ruby+0xb34>
     958:      	ldr	x8, [x0]
     95c:      	mov	w24, wzr
     960:      	add	x8, x8, #0x1
     964:      	str	x8, [x0]
     968:      	mov	w8, #0xbba              // =3002
     96c:      	b	0x2c0 <perf_unwind_ruby+0x2c0>
     970:      	ldr	x8, [sp, #0x78]
     974:      	ldrb	w9, [x23, #0x1d]
     978:      	mov	w10, #0x70              // =112
     97c:      	add	x11, sp, #0x50
     980:      	add	x0, sp, #0x50
     984:      	mov	w1, #0x8                // =8
     988:      	str	xzr, [sp, #0x50]
     98c:      	add	x8, x8, x9
     990:      	mov	w9, #0x8                // =8
     994:      	ldr	x8, [sp, #0x78]
     998:      	ldrb	w9, [x23, #0x1d]
     99c:      	add	x2, x8, x9
     9a0:      	blr	x10
     9a4:      	cbz	x0, 0xaf8 <perf_unwind_ruby+0xaf8>
     9a8:      	ldr	w8, [x25]
     9ac:      	cbnz	w8, 0x1830 <perf_unwind_ruby+0x1830>
     9b0:      	mov	w8, #0x4d               // =77
     9b4:      	add	x9, sp, #0x8c
     9b8:      	add	x1, sp, #0x8c
     9bc:      	str	w8, [sp, #0x8c]
     9c0:      	mov	w8, #0x1                // =1
     9c4:      	mov	x0, x20
     9c8:      	blr	x8
     9cc:      	cbz	x0, 0xd68 <perf_unwind_ruby+0xd68>
     9d0:      	ldr	x8, [x0]
     9d4:      	add	x8, x8, #0x1
     9d8:      	str	x8, [x0]
     9dc:      	b	0xd70 <perf_unwind_ruby+0xd70>
     9e0:      	ldr	w8, [x25]
     9e4:      	cbnz	w8, 0x17e8 <perf_unwind_ruby+0x17e8>
     9e8:      	mov	w8, #0xbb9              // =3001
     9ec:      	mov	w24, wzr
     9f0:      	b	0x2c0 <perf_unwind_ruby+0x2c0>
     9f4:      	ldr	x8, [sp, #0x68]
     9f8:      	ldrb	w9, [x23, #0x21]
     9fc:      	mov	w10, #0x70              // =112
     a00:      	add	x11, sp, #0x58
     a04:      	add	x0, sp, #0x58
     a08:      	mov	w1, #0x8                // =8
     a0c:      	add	x8, x8, x9
     a10:      	mov	w9, #0x8                // =8
     a14:      	ldr	x8, [sp, #0x68]
     a18:      	ldrb	w9, [x23, #0x21]
     a1c:      	add	x2, x8, x9
     a20:      	blr	x10
     a24:      	cbz	x0, 0xcfc <perf_unwind_ruby+0xcfc>
     a28:      	ldr	w8, [x25]
     a2c:      	cbnz	w8, 0x18fc <perf_unwind_ruby+0x18fc>
     a30:      	mov	w8, #0x4f               // =79
     a34:      	add	x9, sp, #0x50
     a38:      	add	x1, sp, #0x50
     a3c:      	str	w8, [sp, #0x50]
     a40:      	mov	w8, #0x1                // =1
     a44:      	mov	x0, x20
     a48:      	blr	x8
     a4c:      	cbz	x0, 0xd7c <perf_unwind_ruby+0xd7c>
     a50:      	ldr	x8, [x0]
     a54:      	add	x8, x8, #0x1
     a58:      	str	x8, [x0]
     a5c:      	b	0xd84 <perf_unwind_ruby+0xd84>
     a60:      	ldr	w8, [x25]
     a64:      	cbnz	w8, 0x1938 <perf_unwind_ruby+0x1938>
     a68:      	mov	w24, wzr
     a6c:      	mov	w8, #0xbbd              // =3005
     a70:      	b	0x2c0 <perf_unwind_ruby+0x2c0>
     a74:      	ldp	x20, x8, [sp, #0x68]
     a78:      	mov	w9, #0x8                // =8
     a7c:      	mov	w10, #0x70              // =112
     a80:      	add	x11, sp, #0x78
     a84:      	add	x0, sp, #0x78
     a88:      	ldrb	w25, [x23, #0x23]
     a8c:      	mov	w1, #0x8                // =8
     a90:      	ldrb	w24, [x23, #0x1e]
     a94:      	str	x8, [sp]
     a98:      	ldrb	w8, [x23, #0x1a]
     a9c:      	add	x8, x29, x8
     aa0:      	ldrb	w8, [x23, #0x1a]
     aa4:      	add	x2, x29, x8
     aa8:      	blr	x10
     aac:      	cbz	x0, 0xd90 <perf_unwind_ruby+0xd90>
     ab0:      	adrp	x25, 0x0 <perf_unwind_ruby>
     ab4:      	ldr	x25, [x25]
     ab8:      	ldr	w8, [x25]
     abc:      	cbnz	w8, 0x1b34 <perf_unwind_ruby+0x1b34>
     ac0:      	mov	w8, #0x4c               // =76
     ac4:      	adrp	x20, 0x0 <perf_unwind_ruby>
     ac8:      	add	x9, sp, #0x60
     acc:      	str	w8, [sp, #0x60]
     ad0:      	mov	w8, #0x1                // =1
     ad4:      	add	x1, sp, #0x60
     ad8:      	ldr	x20, [x20]
     adc:      	mov	x0, x20
     ae0:      	blr	x8
     ae4:      	cbz	x0, 0xe04 <perf_unwind_ruby+0xe04>
     ae8:      	ldr	x8, [x0]
     aec:      	add	x8, x8, #0x1
     af0:      	str	x8, [x0]
     af4:      	b	0xe0c <perf_unwind_ruby+0xe0c>
     af8:      	ldr	w8, [sp, #0x50]
     afc:      	mov	w9, #0x140              // =320
     b00:      	mvn	w8, w8
     b04:      	tst	x8, x9
     b08:      	b.eq	0x76c <perf_unwind_ruby+0x76c>
     b0c:      	ldrb	w8, [x23, #0x1e]
     b10:      	ldr	x9, [sp, #0x78]
     b14:      	mov	w24, #0x1               // =1
     b18:      	add	x9, x9, x8
     b1c:      	str	x9, [sp, #0x78]
     b20:      	str	x9, [x22, #0xf58]
     b24:      	ldr	x9, [sp]
     b28:      	mov	w8, wzr
     b2c:      	str	x9, [x22, #0xf60]
     b30:      	b	0x2c0 <perf_unwind_ruby+0x2c0>
     b34:      	ldr	w8, [x25]
     b38:      	cbnz	w8, 0x1b6c <perf_unwind_ruby+0x1b6c>
     b3c:      	mov	w8, #0xbba              // =3002
     b40:      	mov	w24, wzr
     b44:      	b	0x2c0 <perf_unwind_ruby+0x2c0>
     b48:      	ldr	w8, [x23]
     b4c:      	mov	x20, x29
     b50:      	lsr	w8, w8, #9
     b54:      	cmp	w8, #0x103
     b58:      	b.hs	0xdb4 <perf_unwind_ruby+0xdb4>
     b5c:      	ldr	x8, [sp, #0x78]
     b60:      	ldr	x9, [sp]
     b64:      	cmp	x9, x8
     b68:      	b.ls	0x2b8 <perf_unwind_ruby+0x2b8>
     b6c:      	ldrb	w9, [x23, #0x1e]
     b70:      	str	xzr, [sp, #0x60]
     b74:      	mov	w20, #0x8               // =8
     b78:      	mov	w10, #0x70              // =112
     b7c:      	add	x0, sp, #0x70
     b80:      	mov	w1, #0x8                // =8
     b84:      	mov	w24, #0x70              // =112
     b88:      	add	x8, x8, x9
     b8c:      	ldrb	w9, [x23, #0x1c]
     b90:      	stp	xzr, x8, [sp, #0x70]
     b94:      	add	x8, x8, x9
     b98:      	add	x9, sp, #0x70
     b9c:      	ldr	x8, [sp, #0x78]
     ba0:      	ldrb	w9, [x23, #0x1c]
     ba4:      	add	x2, x8, x9
     ba8:      	blr	x10
     bac:      	ldr	x8, [sp, #0x78]
     bb0:      	ldrb	w9, [x23, #0x1b]
     bb4:      	add	x0, sp, #0x60
     bb8:      	mov	w1, #0x8                // =8
     bbc:      	add	x8, x8, x9
     bc0:      	add	x9, sp, #0x60
     bc4:      	ldr	x8, [sp, #0x78]
     bc8:      	ldrb	w9, [x23, #0x1b]
     bcc:      	add	x2, x8, x9
     bd0:      	blr	x24
     bd4:      	ldr	x8, [sp, #0x60]
     bd8:      	cbz	x8, 0xf28 <perf_unwind_ruby+0xf28>
     bdc:      	ldr	x8, [sp, #0x70]
     be0:      	cbz	x8, 0xf28 <perf_unwind_ruby+0xf28>
     be4:      	ldrb	w9, [x23, #0x1f]
     be8:      	mov	w10, #0x70              // =112
     bec:      	add	x11, sp, #0x68
     bf0:      	add	x0, sp, #0x68
     bf4:      	mov	w1, #0x8                // =8
     bf8:      	add	x8, x8, x9
     bfc:      	mov	w9, #0x8                // =8
     c00:      	ldr	x8, [sp, #0x70]
     c04:      	ldrb	w9, [x23, #0x1f]
     c08:      	add	x2, x8, x9
     c0c:      	blr	x10
     c10:      	mov	x20, x29
     c14:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
     c18:      	ldr	x8, [sp, #0x68]
     c1c:      	ldrb	w9, [x23, #0x21]
     c20:      	mov	w10, #0x70              // =112
     c24:      	add	x11, sp, #0x58
     c28:      	add	x0, sp, #0x58
     c2c:      	mov	w1, #0x8                // =8
     c30:      	add	x8, x8, x9
     c34:      	mov	w9, #0x8                // =8
     c38:      	ldr	x8, [sp, #0x68]
     c3c:      	ldrb	w9, [x23, #0x21]
     c40:      	add	x2, x8, x9
     c44:      	blr	x10
     c48:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
     c4c:      	ldr	x8, [sp, #0x68]
     c50:      	ldrb	w9, [x23, #0x22]
     c54:      	mov	w10, #0x70              // =112
     c58:      	add	x11, sp, #0x88
     c5c:      	add	x0, sp, #0x88
     c60:      	mov	w1, #0x4                // =4
     c64:      	add	x8, x8, x9
     c68:      	mov	w9, #0x4                // =4
     c6c:      	ldr	x8, [sp, #0x68]
     c70:      	ldrb	w9, [x23, #0x22]
     c74:      	add	x2, x8, x9
     c78:      	blr	x10
     c7c:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
     c80:      	ldrb	w9, [x23, #0x23]
     c84:      	ldr	x8, [sp, #0x60]
     c88:      	mov	x20, x25
     c8c:      	cbz	x9, 0x14a0 <perf_unwind_ruby+0x14a0>
     c90:      	ldr	x10, [sp, #0x58]
     c94:      	sub	x10, x8, x10
     c98:      	udiv	x9, x10, x9
     c9c:      	ldr	w10, [sp, #0x88]
     ca0:      	cmp	x9, x10
     ca4:      	b.ls	0x14a0 <perf_unwind_ruby+0x14a0>
     ca8:      	ldr	w8, [x20]
     cac:      	mov	x25, x20
     cb0:      	mov	x20, x29
     cb4:      	cbz	w8, 0xf3c <perf_unwind_ruby+0xf3c>
     cb8:      	adrp	x8, 0x0 <perf_unwind_ruby>
     cbc:      	add	x8, x8, #0x0
     cc0:      	add	x0, sp, #0x8
     cc4:      	ldp	x9, x10, [x8, #0x10]
     cc8:      	mov	w1, #0x2d               // =45
     ccc:      	stp	x9, x10, [sp, #0x18]
     cd0:      	ldr	x9, [x8, #0x20]
     cd4:      	add	x10, sp, #0x8
     cd8:      	str	x9, [sp, #0x28]
     cdc:      	ldur	x9, [x8, #0x25]
     ce0:      	stur	x9, [sp, #0x2d]
     ce4:      	ldp	x9, x8, [x8]
     ce8:      	stp	x9, x8, [sp, #0x8]
     cec:      	mov	w8, #0x2d               // =45
     cf0:      	mov	w9, #0x6                // =6
     cf4:      	blr	x9
     cf8:      	b	0xf3c <perf_unwind_ruby+0xf3c>
     cfc:      	ldr	x8, [sp, #0x68]
     d00:      	ldrb	w9, [x23, #0x22]
     d04:      	mov	w10, #0x70              // =112
     d08:      	add	x11, sp, #0x88
     d0c:      	add	x0, sp, #0x88
     d10:      	mov	w1, #0x4                // =4
     d14:      	add	x8, x8, x9
     d18:      	mov	w9, #0x4                // =4
     d1c:      	ldr	x8, [sp, #0x68]
     d20:      	ldrb	w9, [x23, #0x22]
     d24:      	add	x2, x8, x9
     d28:      	blr	x10
     d2c:      	cbz	x0, 0xe18 <perf_unwind_ruby+0xe18>
     d30:      	ldr	w8, [x25]
     d34:      	cbnz	w8, 0x1bfc <perf_unwind_ruby+0x1bfc>
     d38:      	mov	w8, #0x50               // =80
     d3c:      	add	x9, sp, #0x50
     d40:      	add	x1, sp, #0x50
     d44:      	str	w8, [sp, #0x50]
     d48:      	mov	w8, #0x1                // =1
     d4c:      	mov	x0, x20
     d50:      	blr	x8
     d54:      	cbz	x0, 0xe88 <perf_unwind_ruby+0xe88>
     d58:      	ldr	x8, [x0]
     d5c:      	add	x8, x8, #0x1
     d60:      	str	x8, [x0]
     d64:      	b	0xe90 <perf_unwind_ruby+0xe90>
     d68:      	ldr	w8, [x25]
     d6c:      	cbnz	w8, 0x1bb4 <perf_unwind_ruby+0x1bb4>
     d70:      	mov	w24, wzr
     d74:      	mov	w8, #0xbbc              // =3004
     d78:      	b	0x2c0 <perf_unwind_ruby+0x2c0>
     d7c:      	ldr	w8, [x25]
     d80:      	cbnz	w8, 0x1c38 <perf_unwind_ruby+0x1c38>
     d84:      	mov	w24, wzr
     d88:      	mov	w8, #0xbbe              // =3006
     d8c:      	b	0x2c0 <perf_unwind_ruby+0x2c0>
     d90:      	ldr	x8, [sp]
     d94:      	madd	x8, x20, x25, x8
     d98:      	adrp	x25, 0x0 <perf_unwind_ruby>
     d9c:      	adrp	x20, 0x0 <perf_unwind_ruby>
     da0:      	sub	x9, x8, x24, lsl #1
     da4:      	ldr	x8, [sp, #0x78]
     da8:      	ldr	x25, [x25]
     dac:      	ldr	x20, [x20]
     db0:      	b	0x608 <perf_unwind_ruby+0x608>
     db4:      	ldr	x8, [sp, #0x78]
     db8:      	ldrb	w9, [x23, #0x1d]
     dbc:      	mov	w10, #0x70              // =112
     dc0:      	add	x11, sp, #0x50
     dc4:      	add	x0, sp, #0x50
     dc8:      	mov	w1, #0x8                // =8
     dcc:      	str	xzr, [sp, #0x50]
     dd0:      	add	x8, x8, x9
     dd4:      	mov	w9, #0x8                // =8
     dd8:      	ldr	x8, [sp, #0x78]
     ddc:      	ldrb	w9, [x23, #0x1d]
     de0:      	add	x2, x8, x9
     de4:      	blr	x10
     de8:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
     dec:      	ldr	w8, [sp, #0x50]
     df0:      	mov	w9, #0x140              // =320
     df4:      	mvn	w8, w8
     df8:      	tst	x8, x9
     dfc:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
     e00:      	b	0xb5c <perf_unwind_ruby+0xb5c>
     e04:      	ldr	w8, [x25]
     e08:      	cbnz	w8, 0x1cdc <perf_unwind_ruby+0x1cdc>
     e0c:      	mov	w8, #0xbbb              // =3003
     e10:      	mov	w24, wzr
     e14:      	b	0x2c0 <perf_unwind_ruby+0x2c0>
     e18:      	ldrb	w9, [x23, #0x23]
     e1c:      	ldr	x8, [sp, #0x60]
     e20:      	cbz	x9, 0xe9c <perf_unwind_ruby+0xe9c>
     e24:      	ldr	x10, [sp, #0x58]
     e28:      	sub	x10, x8, x10
     e2c:      	udiv	x9, x10, x9
     e30:      	ldr	w10, [sp, #0x88]
     e34:      	cmp	x9, x10
     e38:      	b.ls	0xe9c <perf_unwind_ruby+0xe9c>
     e3c:      	ldr	w8, [x25]
     e40:      	cbz	w8, 0x76c <perf_unwind_ruby+0x76c>
     e44:      	adrp	x8, 0x0 <perf_unwind_ruby>
     e48:      	add	x8, x8, #0x0
     e4c:      	add	x0, sp, #0x8
     e50:      	ldp	x9, x10, [x8, #0x10]
     e54:      	mov	w1, #0x2d               // =45
     e58:      	stp	x9, x10, [sp, #0x18]
     e5c:      	ldr	x9, [x8, #0x20]
     e60:      	add	x10, sp, #0x8
     e64:      	str	x9, [sp, #0x28]
     e68:      	ldur	x9, [x8, #0x25]
     e6c:      	stur	x9, [sp, #0x2d]
     e70:      	ldp	x9, x8, [x8]
     e74:      	stp	x9, x8, [sp, #0x8]
     e78:      	mov	w8, #0x2d               // =45
     e7c:      	mov	w9, #0x6                // =6
     e80:      	blr	x9
     e84:      	b	0x76c <perf_unwind_ruby+0x76c>
     e88:      	ldr	w8, [x25]
     e8c:      	cbnz	w8, 0x1e00 <perf_unwind_ruby+0x1e00>
     e90:      	mov	w24, wzr
     e94:      	mov	w8, #0xbbf              // =3007
     e98:      	b	0x2c0 <perf_unwind_ruby+0x2c0>
     e9c:      	ldr	w9, [x22, #0x2c0]
     ea0:      	cmp	w9, #0x7f
     ea4:      	b.lo	0x10d8 <perf_unwind_ruby+0x10d8>
     ea8:      	ldr	w8, [x25]
     eac:      	cbnz	w8, 0x1ffc <perf_unwind_ruby+0x1ffc>
     eb0:      	mov	w8, #0x2                // =2
     eb4:      	add	x9, sp, #0x8c
     eb8:      	add	x1, sp, #0x8c
     ebc:      	str	w8, [sp, #0x8c]
     ec0:      	mov	w8, #0x1                // =1
     ec4:      	mov	x0, x29
     ec8:      	mov	x20, x29
     ecc:      	blr	x8
     ed0:      	cbz	x0, 0x119c <perf_unwind_ruby+0x119c>
     ed4:      	ldr	x8, [x0]
     ed8:      	add	x8, x8, #0x1
     edc:      	str	x8, [x0]
     ee0:      	ldr	w8, [x25]
     ee4:      	cbz	w8, 0x11a4 <perf_unwind_ruby+0x11a4>
     ee8:      	mov	w8, #0x656d             // =25965
     eec:      	add	x0, sp, #0x8
     ef0:      	mov	w1, #0x1c               // =28
     ef4:      	movk	w8, #0xa, lsl #16
     ef8:      	str	w8, [sp, #0x20]
     efc:      	adrp	x8, 0x0 <perf_unwind_ruby>
     f00:      	add	x8, x8, #0x0
     f04:      	ldp	x9, x10, [x8]
     f08:      	ldr	x8, [x8, #0x10]
     f0c:      	stp	x9, x10, [sp, #0x8]
     f10:      	str	x8, [sp, #0x18]
     f14:      	mov	w8, #0x1c               // =28
     f18:      	mov	w9, #0x6                // =6
     f1c:      	add	x10, sp, #0x8
     f20:      	blr	x9
     f24:      	b	0x11a4 <perf_unwind_ruby+0x11a4>
     f28:      	ldr	w8, [x23]
     f2c:      	mov	x20, x29
     f30:      	lsr	w8, w8, #9
     f34:      	cmp	w8, #0x103
     f38:      	b.hs	0x114c <perf_unwind_ruby+0x114c>
     f3c:      	ldr	x8, [sp, #0x78]
     f40:      	ldr	x9, [sp]
     f44:      	cmp	x9, x8
     f48:      	b.ls	0x2b8 <perf_unwind_ruby+0x2b8>
     f4c:      	ldrb	w9, [x23, #0x1e]
     f50:      	str	xzr, [sp, #0x60]
     f54:      	mov	w20, #0x8               // =8
     f58:      	mov	w10, #0x70              // =112
     f5c:      	add	x0, sp, #0x70
     f60:      	mov	w1, #0x8                // =8
     f64:      	mov	w24, #0x70              // =112
     f68:      	add	x8, x8, x9
     f6c:      	ldrb	w9, [x23, #0x1c]
     f70:      	stp	xzr, x8, [sp, #0x70]
     f74:      	add	x8, x8, x9
     f78:      	add	x9, sp, #0x70
     f7c:      	ldr	x8, [sp, #0x78]
     f80:      	ldrb	w9, [x23, #0x1c]
     f84:      	add	x2, x8, x9
     f88:      	blr	x10
     f8c:      	ldr	x8, [sp, #0x78]
     f90:      	ldrb	w9, [x23, #0x1b]
     f94:      	add	x0, sp, #0x60
     f98:      	mov	w1, #0x8                // =8
     f9c:      	add	x8, x8, x9
     fa0:      	add	x9, sp, #0x60
     fa4:      	ldr	x8, [sp, #0x78]
     fa8:      	ldrb	w9, [x23, #0x1b]
     fac:      	add	x2, x8, x9
     fb0:      	blr	x24
     fb4:      	ldr	x8, [sp, #0x60]
     fb8:      	cbz	x8, 0x1280 <perf_unwind_ruby+0x1280>
     fbc:      	ldr	x8, [sp, #0x70]
     fc0:      	cbz	x8, 0x1280 <perf_unwind_ruby+0x1280>
     fc4:      	ldrb	w9, [x23, #0x1f]
     fc8:      	mov	w10, #0x70              // =112
     fcc:      	add	x11, sp, #0x68
     fd0:      	add	x0, sp, #0x68
     fd4:      	mov	w1, #0x8                // =8
     fd8:      	add	x8, x8, x9
     fdc:      	mov	w9, #0x8                // =8
     fe0:      	ldr	x8, [sp, #0x70]
     fe4:      	ldrb	w9, [x23, #0x1f]
     fe8:      	add	x2, x8, x9
     fec:      	blr	x10
     ff0:      	mov	x20, x29
     ff4:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
     ff8:      	ldr	x8, [sp, #0x68]
     ffc:      	ldrb	w9, [x23, #0x21]
    1000:      	mov	w10, #0x70              // =112
    1004:      	add	x11, sp, #0x58
    1008:      	add	x0, sp, #0x58
    100c:      	mov	w1, #0x8                // =8
    1010:      	add	x8, x8, x9
    1014:      	mov	w9, #0x8                // =8
    1018:      	ldr	x8, [sp, #0x68]
    101c:      	ldrb	w9, [x23, #0x21]
    1020:      	add	x2, x8, x9
    1024:      	blr	x10
    1028:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    102c:      	ldr	x8, [sp, #0x68]
    1030:      	ldrb	w9, [x23, #0x22]
    1034:      	mov	w10, #0x70              // =112
    1038:      	add	x11, sp, #0x88
    103c:      	add	x0, sp, #0x88
    1040:      	mov	w1, #0x4                // =4
    1044:      	add	x8, x8, x9
    1048:      	mov	w9, #0x4                // =4
    104c:      	ldr	x8, [sp, #0x68]
    1050:      	ldrb	w9, [x23, #0x22]
    1054:      	add	x2, x8, x9
    1058:      	blr	x10
    105c:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    1060:      	ldrb	w9, [x23, #0x23]
    1064:      	ldr	x8, [sp, #0x60]
    1068:      	cbz	x9, 0x1878 <perf_unwind_ruby+0x1878>
    106c:      	ldr	x10, [sp, #0x58]
    1070:      	sub	x10, x8, x10
    1074:      	udiv	x9, x10, x9
    1078:      	ldr	w10, [sp, #0x88]
    107c:      	cmp	x9, x10
    1080:      	b.ls	0x1878 <perf_unwind_ruby+0x1878>
    1084:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1088:      	ldr	x8, [x8]
    108c:      	ldr	w8, [x8]
    1090:      	cbz	w8, 0x1290 <perf_unwind_ruby+0x1290>
    1094:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1098:      	add	x8, x8, #0x0
    109c:      	add	x0, sp, #0x8
    10a0:      	ldp	x9, x10, [x8, #0x10]
    10a4:      	mov	w1, #0x2d               // =45
    10a8:      	stp	x9, x10, [sp, #0x18]
    10ac:      	ldr	x9, [x8, #0x20]
    10b0:      	add	x10, sp, #0x8
    10b4:      	str	x9, [sp, #0x28]
    10b8:      	ldur	x9, [x8, #0x25]
    10bc:      	stur	x9, [sp, #0x2d]
    10c0:      	ldp	x9, x8, [x8]
    10c4:      	stp	x9, x8, [sp, #0x8]
    10c8:      	mov	w8, #0x2d               // =45
    10cc:      	mov	w9, #0x6                // =6
    10d0:      	blr	x9
    10d4:      	b	0x1290 <perf_unwind_ruby+0x1290>
    10d8:      	ldr	x10, [sp, #0x68]
    10dc:      	add	w11, w9, #0x1
    10e0:      	str	wzr, [sp, #0x50]
    10e4:      	add	x1, sp, #0x50
    10e8:      	mov	x0, x29
    10ec:      	mov	x20, x29
    10f0:      	str	w11, [x22, #0x2c0]
    10f4:      	mov	w11, #0x18              // =24
    10f8:      	strh	wzr, [sp, #0x54]
    10fc:      	umaddl	x9, w9, w11, x22
    1100:      	str	x10, [x9, #0x2d0]
    1104:      	mov	w10, #0x6               // =6
    1108:      	str	x8, [x9, #0x2d8]
    110c:      	add	x8, x9, #0x2d0
    1110:      	strh	w10, [x9, #0x2e0]
    1114:      	ldr	w11, [sp, #0x50]
    1118:      	ldrh	w10, [sp, #0x54]
    111c:      	stur	w11, [x8, #0x12]
    1120:      	mov	w8, #0x36               // =54
    1124:      	strh	w10, [x9, #0x2e6]
    1128:      	add	x9, sp, #0x50
    112c:      	str	w8, [sp, #0x50]
    1130:      	mov	w8, #0x1                // =1
    1134:      	blr	x8
    1138:      	cbz	x0, 0x11b0 <perf_unwind_ruby+0x11b0>
    113c:      	ldr	x8, [x0]
    1140:      	add	x8, x8, #0x1
    1144:      	str	x8, [x0]
    1148:      	b	0x76c <perf_unwind_ruby+0x76c>
    114c:      	ldr	x8, [sp, #0x78]
    1150:      	ldrb	w9, [x23, #0x1d]
    1154:      	mov	w10, #0x70              // =112
    1158:      	add	x11, sp, #0x50
    115c:      	add	x0, sp, #0x50
    1160:      	mov	w1, #0x8                // =8
    1164:      	str	xzr, [sp, #0x50]
    1168:      	add	x8, x8, x9
    116c:      	mov	w9, #0x8                // =8
    1170:      	ldr	x8, [sp, #0x78]
    1174:      	ldrb	w9, [x23, #0x1d]
    1178:      	add	x2, x8, x9
    117c:      	blr	x10
    1180:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    1184:      	ldr	w8, [sp, #0x50]
    1188:      	mov	w9, #0x140              // =320
    118c:      	mvn	w8, w8
    1190:      	tst	x8, x9
    1194:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    1198:      	b	0xf3c <perf_unwind_ruby+0xf3c>
    119c:      	ldr	w8, [x25]
    11a0:      	cbnz	w8, 0x20ec <perf_unwind_ruby+0x20ec>
    11a4:      	mov	w24, wzr
    11a8:      	mov	w8, #0x2                // =2
    11ac:      	b	0x2c0 <perf_unwind_ruby+0x2c0>
    11b0:      	ldr	w8, [x25]
    11b4:      	cbz	w8, 0x76c <perf_unwind_ruby+0x76c>
    11b8:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    11bc:      	add	x8, x8, #0x0
    11c0:      	add	x0, sp, #0x8
    11c4:      	ldp	x9, x10, [x8, #0x10]
    11c8:      	mov	w1, #0x2e               // =46
    11cc:      	stp	x9, x10, [sp, #0x18]
    11d0:      	ldr	x9, [x8, #0x20]
    11d4:      	add	x10, sp, #0x8
    11d8:      	str	x9, [sp, #0x28]
    11dc:      	ldur	x9, [x8, #0x26]
    11e0:      	stur	x9, [sp, #0x2e]
    11e4:      	ldp	x9, x8, [x8]
    11e8:      	stp	x9, x8, [sp, #0x8]
    11ec:      	mov	w8, #0x2e               // =46
    11f0:      	mov	w9, #0x6                // =6
    11f4:      	ldr	w2, [sp, #0x50]
    11f8:      	blr	x9
    11fc:      	b	0x76c <perf_unwind_ruby+0x76c>
    1200:      	ldr	w9, [x22, #0x2c0]
    1204:      	cmp	w9, #0x7e
    1208:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    120c:      	ldr	x10, [sp, #0x68]
    1210:      	add	w11, w9, #0x1
    1214:      	str	wzr, [sp, #0x50]
    1218:      	mov	x0, x29
    121c:      	add	x1, sp, #0x50
    1220:      	strh	wzr, [sp, #0x54]
    1224:      	str	w11, [x22, #0x2c0]
    1228:      	mov	w11, #0x18              // =24
    122c:      	umaddl	x9, w9, w11, x22
    1230:      	str	x10, [x9, #0x2d0]
    1234:      	mov	w10, #0x6               // =6
    1238:      	str	x8, [x9, #0x2d8]
    123c:      	add	x8, x9, #0x2d0
    1240:      	strh	w10, [x9, #0x2e0]
    1244:      	ldr	w11, [sp, #0x50]
    1248:      	ldrh	w10, [sp, #0x54]
    124c:      	stur	w11, [x8, #0x12]
    1250:      	mov	w8, #0x36               // =54
    1254:      	strh	w10, [x9, #0x2e6]
    1258:      	add	x9, sp, #0x50
    125c:      	str	w8, [sp, #0x50]
    1260:      	mov	w8, #0x1                // =1
    1264:      	blr	x8
    1268:      	cbz	x0, 0x1490 <perf_unwind_ruby+0x1490>
    126c:      	ldr	x8, [x0]
    1270:      	mov	x20, x29
    1274:      	add	x8, x8, #0x1
    1278:      	str	x8, [x0]
    127c:      	b	0xb5c <perf_unwind_ruby+0xb5c>
    1280:      	ldr	w8, [x23]
    1284:      	lsr	w8, w8, #9
    1288:      	cmp	w8, #0x103
    128c:      	b.hs	0x1434 <perf_unwind_ruby+0x1434>
    1290:      	ldr	x8, [sp, #0x78]
    1294:      	ldr	x9, [sp]
    1298:      	cmp	x9, x8
    129c:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    12a0:      	ldrb	w9, [x23, #0x1e]
    12a4:      	str	xzr, [sp, #0x60]
    12a8:      	mov	w20, #0x8               // =8
    12ac:      	mov	w10, #0x70              // =112
    12b0:      	add	x0, sp, #0x70
    12b4:      	mov	w1, #0x8                // =8
    12b8:      	mov	w24, #0x70              // =112
    12bc:      	add	x8, x8, x9
    12c0:      	ldrb	w9, [x23, #0x1c]
    12c4:      	stp	xzr, x8, [sp, #0x70]
    12c8:      	add	x8, x8, x9
    12cc:      	add	x9, sp, #0x70
    12d0:      	ldr	x8, [sp, #0x78]
    12d4:      	ldrb	w9, [x23, #0x1c]
    12d8:      	add	x2, x8, x9
    12dc:      	blr	x10
    12e0:      	ldr	x8, [sp, #0x78]
    12e4:      	ldrb	w9, [x23, #0x1b]
    12e8:      	add	x0, sp, #0x60
    12ec:      	mov	w1, #0x8                // =8
    12f0:      	add	x8, x8, x9
    12f4:      	add	x9, sp, #0x60
    12f8:      	ldr	x8, [sp, #0x78]
    12fc:      	ldrb	w9, [x23, #0x1b]
    1300:      	add	x2, x8, x9
    1304:      	blr	x24
    1308:      	ldr	x8, [sp, #0x60]
    130c:      	cbz	x8, 0x1520 <perf_unwind_ruby+0x1520>
    1310:      	ldr	x8, [sp, #0x70]
    1314:      	cbz	x8, 0x1520 <perf_unwind_ruby+0x1520>
    1318:      	ldrb	w9, [x23, #0x1f]
    131c:      	mov	w10, #0x70              // =112
    1320:      	add	x11, sp, #0x68
    1324:      	add	x0, sp, #0x68
    1328:      	mov	w1, #0x8                // =8
    132c:      	add	x8, x8, x9
    1330:      	mov	w9, #0x8                // =8
    1334:      	ldr	x8, [sp, #0x70]
    1338:      	ldrb	w9, [x23, #0x1f]
    133c:      	add	x2, x8, x9
    1340:      	blr	x10
    1344:      	adrp	x25, 0x1000 <perf_unwind_ruby+0x1000>
    1348:      	mov	x20, x29
    134c:      	ldr	x25, [x25]
    1350:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    1354:      	ldr	x8, [sp, #0x68]
    1358:      	ldrb	w9, [x23, #0x21]
    135c:      	mov	w10, #0x70              // =112
    1360:      	add	x11, sp, #0x58
    1364:      	add	x0, sp, #0x58
    1368:      	mov	w1, #0x8                // =8
    136c:      	add	x8, x8, x9
    1370:      	mov	w9, #0x8                // =8
    1374:      	ldr	x8, [sp, #0x68]
    1378:      	ldrb	w9, [x23, #0x21]
    137c:      	add	x2, x8, x9
    1380:      	blr	x10
    1384:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    1388:      	ldr	x8, [sp, #0x68]
    138c:      	ldrb	w9, [x23, #0x22]
    1390:      	mov	w10, #0x70              // =112
    1394:      	add	x11, sp, #0x88
    1398:      	add	x0, sp, #0x88
    139c:      	mov	w1, #0x4                // =4
    13a0:      	add	x8, x8, x9
    13a4:      	mov	w9, #0x4                // =4
    13a8:      	ldr	x8, [sp, #0x68]
    13ac:      	ldrb	w9, [x23, #0x22]
    13b0:      	add	x2, x8, x9
    13b4:      	blr	x10
    13b8:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    13bc:      	ldrb	w9, [x23, #0x23]
    13c0:      	ldr	x8, [sp, #0x60]
    13c4:      	cbz	x9, 0x1d7c <perf_unwind_ruby+0x1d7c>
    13c8:      	ldr	x10, [sp, #0x58]
    13cc:      	sub	x10, x8, x10
    13d0:      	udiv	x9, x10, x9
    13d4:      	ldr	w10, [sp, #0x88]
    13d8:      	cmp	x9, x10
    13dc:      	b.ls	0x1d7c <perf_unwind_ruby+0x1d7c>
    13e0:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    13e4:      	ldr	x8, [x8]
    13e8:      	ldr	w8, [x8]
    13ec:      	cbz	w8, 0x1530 <perf_unwind_ruby+0x1530>
    13f0:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    13f4:      	add	x8, x8, #0x0
    13f8:      	add	x0, sp, #0x8
    13fc:      	ldp	x9, x10, [x8, #0x10]
    1400:      	mov	w1, #0x2d               // =45
    1404:      	stp	x9, x10, [sp, #0x18]
    1408:      	ldr	x9, [x8, #0x20]
    140c:      	add	x10, sp, #0x8
    1410:      	str	x9, [sp, #0x28]
    1414:      	ldur	x9, [x8, #0x25]
    1418:      	stur	x9, [sp, #0x2d]
    141c:      	ldp	x9, x8, [x8]
    1420:      	stp	x9, x8, [sp, #0x8]
    1424:      	mov	w8, #0x2d               // =45
    1428:      	mov	w9, #0x6                // =6
    142c:      	blr	x9
    1430:      	b	0x1530 <perf_unwind_ruby+0x1530>
    1434:      	ldr	x8, [sp, #0x78]
    1438:      	ldrb	w9, [x23, #0x1d]
    143c:      	mov	w10, #0x70              // =112
    1440:      	add	x11, sp, #0x50
    1444:      	add	x0, sp, #0x50
    1448:      	mov	w1, #0x8                // =8
    144c:      	str	xzr, [sp, #0x50]
    1450:      	add	x8, x8, x9
    1454:      	mov	w9, #0x8                // =8
    1458:      	ldr	x8, [sp, #0x78]
    145c:      	ldrb	w9, [x23, #0x1d]
    1460:      	add	x2, x8, x9
    1464:      	blr	x10
    1468:      	adrp	x25, 0x1000 <perf_unwind_ruby+0x1000>
    146c:      	mov	x20, x29
    1470:      	ldr	x25, [x25]
    1474:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    1478:      	ldr	w8, [sp, #0x50]
    147c:      	mov	w9, #0x140              // =320
    1480:      	mvn	w8, w8
    1484:      	tst	x8, x9
    1488:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    148c:      	b	0x1290 <perf_unwind_ruby+0x1290>
    1490:      	ldr	w8, [x25]
    1494:      	cbnz	w8, 0x24ac <perf_unwind_ruby+0x24ac>
    1498:      	mov	x20, x29
    149c:      	b	0xb5c <perf_unwind_ruby+0xb5c>
    14a0:      	ldr	w9, [x22, #0x2c0]
    14a4:      	mov	x25, x20
    14a8:      	cmp	w9, #0x7e
    14ac:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    14b0:      	ldr	x10, [sp, #0x68]
    14b4:      	add	w11, w9, #0x1
    14b8:      	str	wzr, [sp, #0x50]
    14bc:      	mov	x0, x29
    14c0:      	add	x1, sp, #0x50
    14c4:      	strh	wzr, [sp, #0x54]
    14c8:      	str	w11, [x22, #0x2c0]
    14cc:      	mov	w11, #0x18              // =24
    14d0:      	umaddl	x9, w9, w11, x22
    14d4:      	str	x10, [x9, #0x2d0]
    14d8:      	mov	w10, #0x6               // =6
    14dc:      	str	x8, [x9, #0x2d8]
    14e0:      	add	x8, x9, #0x2d0
    14e4:      	strh	w10, [x9, #0x2e0]
    14e8:      	ldr	w11, [sp, #0x50]
    14ec:      	ldrh	w10, [sp, #0x54]
    14f0:      	stur	w11, [x8, #0x12]
    14f4:      	mov	w8, #0x36               // =54
    14f8:      	strh	w10, [x9, #0x2e6]
    14fc:      	add	x9, sp, #0x50
    1500:      	str	w8, [sp, #0x50]
    1504:      	mov	w8, #0x1                // =1
    1508:      	blr	x8
    150c:      	cbz	x0, 0x1864 <perf_unwind_ruby+0x1864>
    1510:      	ldr	x8, [x0]
    1514:      	add	x8, x8, #0x1
    1518:      	str	x8, [x0]
    151c:      	b	0x186c <perf_unwind_ruby+0x186c>
    1520:      	ldr	w8, [x23]
    1524:      	lsr	w8, w8, #9
    1528:      	cmp	w8, #0x103
    152c:      	b.hs	0x1758 <perf_unwind_ruby+0x1758>
    1530:      	ldr	x8, [sp, #0x78]
    1534:      	ldr	x9, [sp]
    1538:      	cmp	x9, x8
    153c:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    1540:      	ldrb	w9, [x23, #0x1e]
    1544:      	str	xzr, [sp, #0x60]
    1548:      	mov	w20, #0x8               // =8
    154c:      	mov	w10, #0x70              // =112
    1550:      	add	x0, sp, #0x70
    1554:      	mov	w1, #0x8                // =8
    1558:      	mov	w24, #0x70              // =112
    155c:      	add	x8, x8, x9
    1560:      	ldrb	w9, [x23, #0x1c]
    1564:      	stp	xzr, x8, [sp, #0x70]
    1568:      	add	x8, x8, x9
    156c:      	add	x9, sp, #0x70
    1570:      	ldr	x8, [sp, #0x78]
    1574:      	ldrb	w9, [x23, #0x1c]
    1578:      	add	x2, x8, x9
    157c:      	blr	x10
    1580:      	ldr	x8, [sp, #0x78]
    1584:      	ldrb	w9, [x23, #0x1b]
    1588:      	add	x0, sp, #0x60
    158c:      	mov	w1, #0x8                // =8
    1590:      	add	x8, x8, x9
    1594:      	add	x9, sp, #0x60
    1598:      	ldr	x8, [sp, #0x78]
    159c:      	ldrb	w9, [x23, #0x1b]
    15a0:      	add	x2, x8, x9
    15a4:      	blr	x24
    15a8:      	ldr	x8, [sp, #0x60]
    15ac:      	cbz	x8, 0x1980 <perf_unwind_ruby+0x1980>
    15b0:      	ldr	x8, [sp, #0x70]
    15b4:      	cbz	x8, 0x1980 <perf_unwind_ruby+0x1980>
    15b8:      	ldrb	w9, [x23, #0x1f]
    15bc:      	mov	w10, #0x70              // =112
    15c0:      	add	x11, sp, #0x68
    15c4:      	add	x0, sp, #0x68
    15c8:      	mov	w1, #0x8                // =8
    15cc:      	add	x8, x8, x9
    15d0:      	mov	w9, #0x8                // =8
    15d4:      	ldr	x8, [sp, #0x70]
    15d8:      	ldrb	w9, [x23, #0x1f]
    15dc:      	add	x2, x8, x9
    15e0:      	blr	x10
    15e4:      	adrp	x25, 0x1000 <perf_unwind_ruby+0x1000>
    15e8:      	mov	x20, x29
    15ec:      	ldr	x25, [x25]
    15f0:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    15f4:      	ldr	x8, [sp, #0x68]
    15f8:      	ldrb	w9, [x23, #0x21]
    15fc:      	mov	w10, #0x70              // =112
    1600:      	add	x11, sp, #0x58
    1604:      	add	x0, sp, #0x58
    1608:      	mov	w1, #0x8                // =8
    160c:      	add	x8, x8, x9
    1610:      	mov	w9, #0x8                // =8
    1614:      	ldr	x8, [sp, #0x68]
    1618:      	ldrb	w9, [x23, #0x21]
    161c:      	add	x2, x8, x9
    1620:      	blr	x10
    1624:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    1628:      	ldr	x8, [sp, #0x68]
    162c:      	ldrb	w9, [x23, #0x22]
    1630:      	mov	w10, #0x70              // =112
    1634:      	add	x11, sp, #0x88
    1638:      	add	x0, sp, #0x88
    163c:      	mov	w1, #0x4                // =4
    1640:      	add	x8, x8, x9
    1644:      	mov	w9, #0x4                // =4
    1648:      	ldr	x8, [sp, #0x68]
    164c:      	ldrb	w9, [x23, #0x22]
    1650:      	add	x2, x8, x9
    1654:      	blr	x10
    1658:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    165c:      	ldrb	w9, [x23, #0x23]
    1660:      	ldr	x8, [sp, #0x60]
    1664:      	cbz	x9, 0x213c <perf_unwind_ruby+0x213c>
    1668:      	ldr	x10, [sp, #0x58]
    166c:      	sub	x10, x8, x10
    1670:      	udiv	x9, x10, x9
    1674:      	ldr	w10, [sp, #0x88]
    1678:      	cmp	x9, x10
    167c:      	b.ls	0x213c <perf_unwind_ruby+0x213c>
    1680:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1684:      	ldr	x8, [x8]
    1688:      	ldr	w8, [x8]
    168c:      	cbz	w8, 0x1990 <perf_unwind_ruby+0x1990>
    1690:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1694:      	add	x8, x8, #0x0
    1698:      	add	x0, sp, #0x8
    169c:      	ldp	x9, x10, [x8, #0x10]
    16a0:      	mov	w1, #0x2d               // =45
    16a4:      	stp	x9, x10, [sp, #0x18]
    16a8:      	ldr	x9, [x8, #0x20]
    16ac:      	add	x10, sp, #0x8
    16b0:      	str	x9, [sp, #0x28]
    16b4:      	ldur	x9, [x8, #0x25]
    16b8:      	stur	x9, [sp, #0x2d]
    16bc:      	ldp	x9, x8, [x8]
    16c0:      	stp	x9, x8, [sp, #0x8]
    16c4:      	mov	w8, #0x2d               // =45
    16c8:      	mov	w9, #0x6                // =6
    16cc:      	blr	x9
    16d0:      	b	0x1990 <perf_unwind_ruby+0x1990>
    16d4:      	mov	w8, #0x7265             // =29285
    16d8:      	add	x0, sp, #0x8
    16dc:      	mov	w1, #0x2c               // =44
    16e0:      	movk	w8, #0xa, lsl #16
    16e4:      	str	w8, [sp, #0x30]
    16e8:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    16ec:      	add	x8, x8, #0x0
    16f0:      	ldp	x9, x10, [x8, #0x10]
    16f4:      	stp	x9, x10, [sp, #0x18]
    16f8:      	ldr	x9, [x8, #0x20]
    16fc:      	add	x10, sp, #0x8
    1700:      	str	x9, [sp, #0x28]
    1704:      	ldp	x8, x9, [x8]
    1708:      	stp	x8, x9, [sp, #0x8]
    170c:      	mov	w8, #0x2c               // =44
    1710:      	mov	w9, #0x6                // =6
    1714:      	blr	x9
    1718:      	b	0x720 <perf_unwind_ruby+0x720>
    171c:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1720:      	add	x8, x8, #0x0
    1724:      	add	x0, sp, #0x8
    1728:      	ldp	x9, x10, [x8]
    172c:      	mov	w1, #0x1f               // =31
    1730:      	stp	x9, x10, [sp, #0x8]
    1734:      	ldr	x9, [x8, #0x10]
    1738:      	ldur	x8, [x8, #0x17]
    173c:      	add	x10, sp, #0x8
    1740:      	str	x9, [sp, #0x18]
    1744:      	stur	x8, [sp, #0x1f]
    1748:      	mov	w8, #0x1f               // =31
    174c:      	mov	w9, #0x6                // =6
    1750:      	blr	x9
    1754:      	b	0x6bc <perf_unwind_ruby+0x6bc>
    1758:      	ldr	x8, [sp, #0x78]
    175c:      	ldrb	w9, [x23, #0x1d]
    1760:      	mov	w10, #0x70              // =112
    1764:      	add	x11, sp, #0x50
    1768:      	add	x0, sp, #0x50
    176c:      	mov	w1, #0x8                // =8
    1770:      	str	xzr, [sp, #0x50]
    1774:      	add	x8, x8, x9
    1778:      	mov	w9, #0x8                // =8
    177c:      	ldr	x8, [sp, #0x78]
    1780:      	ldrb	w9, [x23, #0x1d]
    1784:      	add	x2, x8, x9
    1788:      	blr	x10
    178c:      	adrp	x25, 0x1000 <perf_unwind_ruby+0x1000>
    1790:      	mov	x20, x29
    1794:      	ldr	x25, [x25]
    1798:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    179c:      	ldr	w8, [sp, #0x50]
    17a0:      	mov	w9, #0x140              // =320
    17a4:      	mvn	w8, w8
    17a8:      	tst	x8, x9
    17ac:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    17b0:      	b	0x1530 <perf_unwind_ruby+0x1530>
    17b4:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    17b8:      	add	x8, x8, #0x0
    17bc:      	add	x0, sp, #0x8
    17c0:      	ldp	x9, x10, [x8]
    17c4:      	mov	w1, #0x20               // =32
    17c8:      	stp	x9, x10, [sp, #0x8]
    17cc:      	ldp	x9, x8, [x8, #0x10]
    17d0:      	add	x10, sp, #0x8
    17d4:      	stp	x9, x8, [sp, #0x18]
    17d8:      	mov	w8, #0x20               // =32
    17dc:      	mov	w9, #0x6                // =6
    17e0:      	blr	x9
    17e4:      	b	0x938 <perf_unwind_ruby+0x938>
    17e8:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    17ec:      	add	x8, x8, #0x0
    17f0:      	add	x0, sp, #0x8
    17f4:      	ldp	x9, x10, [x8, #0x10]
    17f8:      	mov	w1, #0x2e               // =46
    17fc:      	stp	x9, x10, [sp, #0x18]
    1800:      	ldr	x9, [x8, #0x20]
    1804:      	add	x10, sp, #0x8
    1808:      	str	x9, [sp, #0x28]
    180c:      	ldur	x9, [x8, #0x26]
    1810:      	stur	x9, [sp, #0x2e]
    1814:      	ldp	x9, x8, [x8]
    1818:      	stp	x9, x8, [sp, #0x8]
    181c:      	mov	w8, #0x2e               // =46
    1820:      	mov	w9, #0x6                // =6
    1824:      	ldr	w2, [sp, #0x60]
    1828:      	blr	x9
    182c:      	b	0x9e8 <perf_unwind_ruby+0x9e8>
    1830:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1834:      	add	x8, x8, #0x0
    1838:      	add	x0, sp, #0x8
    183c:      	ldp	x9, x10, [x8]
    1840:      	ldr	x8, [x8, #0x10]
    1844:      	mov	w1, #0x18               // =24
    1848:      	stp	x9, x10, [sp, #0x8]
    184c:      	str	x8, [sp, #0x18]
    1850:      	mov	w8, #0x18               // =24
    1854:      	mov	w9, #0x6                // =6
    1858:      	add	x10, sp, #0x8
    185c:      	blr	x9
    1860:      	b	0x9b0 <perf_unwind_ruby+0x9b0>
    1864:      	ldr	w8, [x20]
    1868:      	cbnz	w8, 0x27e0 <perf_unwind_ruby+0x27e0>
    186c:      	mov	x25, x20
    1870:      	mov	x20, x29
    1874:      	b	0xf3c <perf_unwind_ruby+0xf3c>
    1878:      	ldr	w9, [x22, #0x2c0]
    187c:      	adrp	x25, 0x1000 <perf_unwind_ruby+0x1000>
    1880:      	ldr	x25, [x25]
    1884:      	cmp	w9, #0x7e
    1888:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    188c:      	ldr	x10, [sp, #0x68]
    1890:      	add	w11, w9, #0x1
    1894:      	str	wzr, [sp, #0x50]
    1898:      	mov	x0, x29
    189c:      	add	x1, sp, #0x50
    18a0:      	strh	wzr, [sp, #0x54]
    18a4:      	str	w11, [x22, #0x2c0]
    18a8:      	mov	w11, #0x18              // =24
    18ac:      	umaddl	x9, w9, w11, x22
    18b0:      	str	x10, [x9, #0x2d0]
    18b4:      	mov	w10, #0x6               // =6
    18b8:      	str	x8, [x9, #0x2d8]
    18bc:      	add	x8, x9, #0x2d0
    18c0:      	strh	w10, [x9, #0x2e0]
    18c4:      	ldr	w11, [sp, #0x50]
    18c8:      	ldrh	w10, [sp, #0x54]
    18cc:      	stur	w11, [x8, #0x12]
    18d0:      	mov	w8, #0x36               // =54
    18d4:      	strh	w10, [x9, #0x2e6]
    18d8:      	add	x9, sp, #0x50
    18dc:      	str	w8, [sp, #0x50]
    18e0:      	mov	w8, #0x1                // =1
    18e4:      	blr	x8
    18e8:      	cbz	x0, 0x1d24 <perf_unwind_ruby+0x1d24>
    18ec:      	ldr	x8, [x0]
    18f0:      	add	x8, x8, #0x1
    18f4:      	str	x8, [x0]
    18f8:      	b	0x1290 <perf_unwind_ruby+0x1290>
    18fc:      	mov	w8, #0xa                // =10
    1900:      	add	x0, sp, #0x8
    1904:      	mov	w1, #0x22               // =34
    1908:      	strh	w8, [sp, #0x28]
    190c:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1910:      	add	x8, x8, #0x0
    1914:      	ldp	x9, x10, [x8]
    1918:      	stp	x9, x10, [sp, #0x8]
    191c:      	ldp	x9, x8, [x8, #0x10]
    1920:      	add	x10, sp, #0x8
    1924:      	stp	x9, x8, [sp, #0x18]
    1928:      	mov	w8, #0x22               // =34
    192c:      	mov	w9, #0x6                // =6
    1930:      	blr	x9
    1934:      	b	0xa30 <perf_unwind_ruby+0xa30>
    1938:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    193c:      	add	x8, x8, #0x0
    1940:      	add	x0, sp, #0x8
    1944:      	ldp	x9, x10, [x8, #0x10]
    1948:      	mov	w1, #0x2e               // =46
    194c:      	stp	x9, x10, [sp, #0x18]
    1950:      	ldr	x9, [x8, #0x20]
    1954:      	add	x10, sp, #0x8
    1958:      	str	x9, [sp, #0x28]
    195c:      	ldur	x9, [x8, #0x26]
    1960:      	stur	x9, [sp, #0x2e]
    1964:      	ldp	x9, x8, [x8]
    1968:      	stp	x9, x8, [sp, #0x8]
    196c:      	mov	w8, #0x2e               // =46
    1970:      	mov	w9, #0x6                // =6
    1974:      	ldr	w2, [sp, #0x50]
    1978:      	blr	x9
    197c:      	b	0xa68 <perf_unwind_ruby+0xa68>
    1980:      	ldr	w8, [x23]
    1984:      	lsr	w8, w8, #9
    1988:      	cmp	w8, #0x103
    198c:      	b.hs	0x1c80 <perf_unwind_ruby+0x1c80>
    1990:      	ldr	x8, [sp, #0x78]
    1994:      	ldr	x9, [sp]
    1998:      	cmp	x9, x8
    199c:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    19a0:      	ldrb	w9, [x23, #0x1e]
    19a4:      	str	xzr, [sp, #0x60]
    19a8:      	mov	w20, #0x8               // =8
    19ac:      	mov	w10, #0x70              // =112
    19b0:      	add	x0, sp, #0x70
    19b4:      	mov	w1, #0x8                // =8
    19b8:      	mov	w24, #0x70              // =112
    19bc:      	add	x8, x8, x9
    19c0:      	ldrb	w9, [x23, #0x1c]
    19c4:      	stp	xzr, x8, [sp, #0x70]
    19c8:      	add	x8, x8, x9
    19cc:      	add	x9, sp, #0x70
    19d0:      	ldr	x8, [sp, #0x78]
    19d4:      	ldrb	w9, [x23, #0x1c]
    19d8:      	add	x2, x8, x9
    19dc:      	blr	x10
    19e0:      	ldr	x8, [sp, #0x78]
    19e4:      	ldrb	w9, [x23, #0x1b]
    19e8:      	add	x0, sp, #0x60
    19ec:      	mov	w1, #0x8                // =8
    19f0:      	add	x8, x8, x9
    19f4:      	add	x9, sp, #0x60
    19f8:      	ldr	x8, [sp, #0x78]
    19fc:      	ldrb	w9, [x23, #0x1b]
    1a00:      	add	x2, x8, x9
    1a04:      	blr	x24
    1a08:      	ldr	x8, [sp, #0x60]
    1a0c:      	cbz	x8, 0x1e48 <perf_unwind_ruby+0x1e48>
    1a10:      	ldr	x8, [sp, #0x70]
    1a14:      	cbz	x8, 0x1e48 <perf_unwind_ruby+0x1e48>
    1a18:      	ldrb	w9, [x23, #0x1f]
    1a1c:      	mov	w10, #0x70              // =112
    1a20:      	add	x11, sp, #0x68
    1a24:      	add	x0, sp, #0x68
    1a28:      	mov	w1, #0x8                // =8
    1a2c:      	add	x8, x8, x9
    1a30:      	mov	w9, #0x8                // =8
    1a34:      	ldr	x8, [sp, #0x70]
    1a38:      	ldrb	w9, [x23, #0x1f]
    1a3c:      	add	x2, x8, x9
    1a40:      	blr	x10
    1a44:      	adrp	x25, 0x1000 <perf_unwind_ruby+0x1000>
    1a48:      	mov	x20, x29
    1a4c:      	ldr	x25, [x25]
    1a50:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    1a54:      	ldr	x8, [sp, #0x68]
    1a58:      	ldrb	w9, [x23, #0x21]
    1a5c:      	mov	w10, #0x70              // =112
    1a60:      	add	x11, sp, #0x58
    1a64:      	add	x0, sp, #0x58
    1a68:      	mov	w1, #0x8                // =8
    1a6c:      	add	x8, x8, x9
    1a70:      	mov	w9, #0x8                // =8
    1a74:      	ldr	x8, [sp, #0x68]
    1a78:      	ldrb	w9, [x23, #0x21]
    1a7c:      	add	x2, x8, x9
    1a80:      	blr	x10
    1a84:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    1a88:      	ldr	x8, [sp, #0x68]
    1a8c:      	ldrb	w9, [x23, #0x22]
    1a90:      	mov	w10, #0x70              // =112
    1a94:      	add	x11, sp, #0x88
    1a98:      	add	x0, sp, #0x88
    1a9c:      	mov	w1, #0x4                // =4
    1aa0:      	add	x8, x8, x9
    1aa4:      	mov	w9, #0x4                // =4
    1aa8:      	ldr	x8, [sp, #0x68]
    1aac:      	ldrb	w9, [x23, #0x22]
    1ab0:      	add	x2, x8, x9
    1ab4:      	blr	x10
    1ab8:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    1abc:      	ldrb	w9, [x23, #0x23]
    1ac0:      	ldr	x8, [sp, #0x60]
    1ac4:      	cbz	x9, 0x2428 <perf_unwind_ruby+0x2428>
    1ac8:      	ldr	x10, [sp, #0x58]
    1acc:      	sub	x10, x8, x10
    1ad0:      	udiv	x9, x10, x9
    1ad4:      	ldr	w10, [sp, #0x88]
    1ad8:      	cmp	x9, x10
    1adc:      	b.ls	0x2428 <perf_unwind_ruby+0x2428>
    1ae0:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1ae4:      	ldr	x8, [x8]
    1ae8:      	ldr	w8, [x8]
    1aec:      	cbz	w8, 0x1e58 <perf_unwind_ruby+0x1e58>
    1af0:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1af4:      	add	x8, x8, #0x0
    1af8:      	add	x0, sp, #0x8
    1afc:      	ldp	x9, x10, [x8, #0x10]
    1b00:      	mov	w1, #0x2d               // =45
    1b04:      	stp	x9, x10, [sp, #0x18]
    1b08:      	ldr	x9, [x8, #0x20]
    1b0c:      	add	x10, sp, #0x8
    1b10:      	str	x9, [sp, #0x28]
    1b14:      	ldur	x9, [x8, #0x25]
    1b18:      	stur	x9, [sp, #0x2d]
    1b1c:      	ldp	x9, x8, [x8]
    1b20:      	stp	x9, x8, [sp, #0x8]
    1b24:      	mov	w8, #0x2d               // =45
    1b28:      	mov	w9, #0x6                // =6
    1b2c:      	blr	x9
    1b30:      	b	0x1e58 <perf_unwind_ruby+0x1e58>
    1b34:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1b38:      	add	x8, x8, #0x0
    1b3c:      	strb	wzr, [sp, #0x20]
    1b40:      	add	x0, sp, #0x8
    1b44:      	ldp	x9, x10, [x8]
    1b48:      	ldr	x8, [x8, #0x10]
    1b4c:      	mov	w1, #0x19               // =25
    1b50:      	str	x8, [sp, #0x18]
    1b54:      	stp	x9, x10, [sp, #0x8]
    1b58:      	mov	w8, #0x19               // =25
    1b5c:      	mov	w9, #0x6                // =6
    1b60:      	add	x10, sp, #0x8
    1b64:      	blr	x9
    1b68:      	b	0xac0 <perf_unwind_ruby+0xac0>
    1b6c:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1b70:      	add	x8, x8, #0x0
    1b74:      	add	x0, sp, #0x8
    1b78:      	ldp	x9, x10, [x8, #0x10]
    1b7c:      	mov	w1, #0x2e               // =46
    1b80:      	stp	x9, x10, [sp, #0x18]
    1b84:      	ldr	x9, [x8, #0x20]
    1b88:      	add	x10, sp, #0x8
    1b8c:      	str	x9, [sp, #0x28]
    1b90:      	ldur	x9, [x8, #0x26]
    1b94:      	stur	x9, [sp, #0x2e]
    1b98:      	ldp	x9, x8, [x8]
    1b9c:      	stp	x9, x8, [sp, #0x8]
    1ba0:      	mov	w8, #0x2e               // =46
    1ba4:      	mov	w9, #0x6                // =6
    1ba8:      	ldr	w2, [sp, #0x60]
    1bac:      	blr	x9
    1bb0:      	b	0xb3c <perf_unwind_ruby+0xb3c>
    1bb4:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1bb8:      	add	x8, x8, #0x0
    1bbc:      	add	x0, sp, #0x8
    1bc0:      	ldp	x9, x10, [x8, #0x10]
    1bc4:      	mov	w1, #0x2e               // =46
    1bc8:      	stp	x9, x10, [sp, #0x18]
    1bcc:      	ldr	x9, [x8, #0x20]
    1bd0:      	add	x10, sp, #0x8
    1bd4:      	str	x9, [sp, #0x28]
    1bd8:      	ldur	x9, [x8, #0x26]
    1bdc:      	stur	x9, [sp, #0x2e]
    1be0:      	ldp	x9, x8, [x8]
    1be4:      	stp	x9, x8, [sp, #0x8]
    1be8:      	mov	w8, #0x2e               // =46
    1bec:      	mov	w9, #0x6                // =6
    1bf0:      	ldr	w2, [sp, #0x8c]
    1bf4:      	blr	x9
    1bf8:      	b	0xd70 <perf_unwind_ruby+0xd70>
    1bfc:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1c00:      	add	x8, x8, #0x0
    1c04:      	add	x0, sp, #0x8
    1c08:      	ldp	x9, x10, [x8]
    1c0c:      	mov	w1, #0x1f               // =31
    1c10:      	stp	x9, x10, [sp, #0x8]
    1c14:      	ldr	x9, [x8, #0x10]
    1c18:      	ldur	x8, [x8, #0x17]
    1c1c:      	add	x10, sp, #0x8
    1c20:      	str	x9, [sp, #0x18]
    1c24:      	stur	x8, [sp, #0x1f]
    1c28:      	mov	w8, #0x1f               // =31
    1c2c:      	mov	w9, #0x6                // =6
    1c30:      	blr	x9
    1c34:      	b	0xd38 <perf_unwind_ruby+0xd38>
    1c38:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1c3c:      	add	x8, x8, #0x0
    1c40:      	add	x0, sp, #0x8
    1c44:      	ldp	x9, x10, [x8, #0x10]
    1c48:      	mov	w1, #0x2e               // =46
    1c4c:      	stp	x9, x10, [sp, #0x18]
    1c50:      	ldr	x9, [x8, #0x20]
    1c54:      	add	x10, sp, #0x8
    1c58:      	str	x9, [sp, #0x28]
    1c5c:      	ldur	x9, [x8, #0x26]
    1c60:      	stur	x9, [sp, #0x2e]
    1c64:      	ldp	x9, x8, [x8]
    1c68:      	stp	x9, x8, [sp, #0x8]
    1c6c:      	mov	w8, #0x2e               // =46
    1c70:      	mov	w9, #0x6                // =6
    1c74:      	ldr	w2, [sp, #0x50]
    1c78:      	blr	x9
    1c7c:      	b	0xd84 <perf_unwind_ruby+0xd84>
    1c80:      	ldr	x8, [sp, #0x78]
    1c84:      	ldrb	w9, [x23, #0x1d]
    1c88:      	mov	w10, #0x70              // =112
    1c8c:      	add	x11, sp, #0x50
    1c90:      	add	x0, sp, #0x50
    1c94:      	mov	w1, #0x8                // =8
    1c98:      	str	xzr, [sp, #0x50]
    1c9c:      	add	x8, x8, x9
    1ca0:      	mov	w9, #0x8                // =8
    1ca4:      	ldr	x8, [sp, #0x78]
    1ca8:      	ldrb	w9, [x23, #0x1d]
    1cac:      	add	x2, x8, x9
    1cb0:      	blr	x10
    1cb4:      	adrp	x25, 0x1000 <perf_unwind_ruby+0x1000>
    1cb8:      	mov	x20, x29
    1cbc:      	ldr	x25, [x25]
    1cc0:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    1cc4:      	ldr	w8, [sp, #0x50]
    1cc8:      	mov	w9, #0x140              // =320
    1ccc:      	mvn	w8, w8
    1cd0:      	tst	x8, x9
    1cd4:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    1cd8:      	b	0x1990 <perf_unwind_ruby+0x1990>
    1cdc:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1ce0:      	add	x8, x8, #0x0
    1ce4:      	add	x0, sp, #0x8
    1ce8:      	ldp	x9, x10, [x8, #0x10]
    1cec:      	mov	w1, #0x2e               // =46
    1cf0:      	stp	x9, x10, [sp, #0x18]
    1cf4:      	ldr	x9, [x8, #0x20]
    1cf8:      	add	x10, sp, #0x8
    1cfc:      	str	x9, [sp, #0x28]
    1d00:      	ldur	x9, [x8, #0x26]
    1d04:      	stur	x9, [sp, #0x2e]
    1d08:      	ldp	x9, x8, [x8]
    1d0c:      	stp	x9, x8, [sp, #0x8]
    1d10:      	mov	w8, #0x2e               // =46
    1d14:      	mov	w9, #0x6                // =6
    1d18:      	ldr	w2, [sp, #0x60]
    1d1c:      	blr	x9
    1d20:      	b	0xe0c <perf_unwind_ruby+0xe0c>
    1d24:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1d28:      	ldr	x8, [x8]
    1d2c:      	ldr	w8, [x8]
    1d30:      	cbz	w8, 0x1290 <perf_unwind_ruby+0x1290>
    1d34:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1d38:      	add	x8, x8, #0x0
    1d3c:      	add	x0, sp, #0x8
    1d40:      	ldp	x9, x10, [x8, #0x10]
    1d44:      	mov	w1, #0x2e               // =46
    1d48:      	stp	x9, x10, [sp, #0x18]
    1d4c:      	ldr	x9, [x8, #0x20]
    1d50:      	add	x10, sp, #0x8
    1d54:      	str	x9, [sp, #0x28]
    1d58:      	ldur	x9, [x8, #0x26]
    1d5c:      	stur	x9, [sp, #0x2e]
    1d60:      	ldp	x9, x8, [x8]
    1d64:      	stp	x9, x8, [sp, #0x8]
    1d68:      	mov	w8, #0x2e               // =46
    1d6c:      	mov	w9, #0x6                // =6
    1d70:      	ldr	w2, [sp, #0x50]
    1d74:      	blr	x9
    1d78:      	b	0x1290 <perf_unwind_ruby+0x1290>
    1d7c:      	ldr	w9, [x22, #0x2c0]
    1d80:      	adrp	x25, 0x1000 <perf_unwind_ruby+0x1000>
    1d84:      	ldr	x25, [x25]
    1d88:      	cmp	w9, #0x7e
    1d8c:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    1d90:      	ldr	x10, [sp, #0x68]
    1d94:      	add	w11, w9, #0x1
    1d98:      	str	wzr, [sp, #0x50]
    1d9c:      	mov	x0, x29
    1da0:      	add	x1, sp, #0x50
    1da4:      	strh	wzr, [sp, #0x54]
    1da8:      	str	w11, [x22, #0x2c0]
    1dac:      	mov	w11, #0x18              // =24
    1db0:      	umaddl	x9, w9, w11, x22
    1db4:      	str	x10, [x9, #0x2d0]
    1db8:      	mov	w10, #0x6               // =6
    1dbc:      	str	x8, [x9, #0x2d8]
    1dc0:      	add	x8, x9, #0x2d0
    1dc4:      	strh	w10, [x9, #0x2e0]
    1dc8:      	ldr	w11, [sp, #0x50]
    1dcc:      	ldrh	w10, [sp, #0x54]
    1dd0:      	stur	w11, [x8, #0x12]
    1dd4:      	mov	w8, #0x36               // =54
    1dd8:      	strh	w10, [x9, #0x2e6]
    1ddc:      	add	x9, sp, #0x50
    1de0:      	str	w8, [sp, #0x50]
    1de4:      	mov	w8, #0x1                // =1
    1de8:      	blr	x8
    1dec:      	cbz	x0, 0x2094 <perf_unwind_ruby+0x2094>
    1df0:      	ldr	x8, [x0]
    1df4:      	add	x8, x8, #0x1
    1df8:      	str	x8, [x0]
    1dfc:      	b	0x1530 <perf_unwind_ruby+0x1530>
    1e00:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1e04:      	add	x8, x8, #0x0
    1e08:      	add	x0, sp, #0x8
    1e0c:      	ldp	x9, x10, [x8, #0x10]
    1e10:      	mov	w1, #0x2e               // =46
    1e14:      	stp	x9, x10, [sp, #0x18]
    1e18:      	ldr	x9, [x8, #0x20]
    1e1c:      	add	x10, sp, #0x8
    1e20:      	str	x9, [sp, #0x28]
    1e24:      	ldur	x9, [x8, #0x26]
    1e28:      	stur	x9, [sp, #0x2e]
    1e2c:      	ldp	x9, x8, [x8]
    1e30:      	stp	x9, x8, [sp, #0x8]
    1e34:      	mov	w8, #0x2e               // =46
    1e38:      	mov	w9, #0x6                // =6
    1e3c:      	ldr	w2, [sp, #0x50]
    1e40:      	blr	x9
    1e44:      	b	0xe90 <perf_unwind_ruby+0xe90>
    1e48:      	ldr	w8, [x23]
    1e4c:      	lsr	w8, w8, #9
    1e50:      	cmp	w8, #0x103
    1e54:      	b.hs	0x2038 <perf_unwind_ruby+0x2038>
    1e58:      	ldr	x8, [sp, #0x78]
    1e5c:      	ldr	x9, [sp]
    1e60:      	cmp	x9, x8
    1e64:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    1e68:      	ldrb	w9, [x23, #0x1e]
    1e6c:      	str	xzr, [sp, #0x60]
    1e70:      	mov	w20, #0x8               // =8
    1e74:      	mov	w10, #0x70              // =112
    1e78:      	add	x0, sp, #0x70
    1e7c:      	mov	w1, #0x8                // =8
    1e80:      	mov	w24, #0x70              // =112
    1e84:      	add	x8, x8, x9
    1e88:      	ldrb	w9, [x23, #0x1c]
    1e8c:      	stp	xzr, x8, [sp, #0x70]
    1e90:      	add	x8, x8, x9
    1e94:      	add	x9, sp, #0x70
    1e98:      	ldr	x8, [sp, #0x78]
    1e9c:      	ldrb	w9, [x23, #0x1c]
    1ea0:      	add	x2, x8, x9
    1ea4:      	blr	x10
    1ea8:      	ldr	x8, [sp, #0x78]
    1eac:      	ldrb	w9, [x23, #0x1b]
    1eb0:      	add	x0, sp, #0x60
    1eb4:      	mov	w1, #0x8                // =8
    1eb8:      	add	x8, x8, x9
    1ebc:      	add	x9, sp, #0x60
    1ec0:      	ldr	x8, [sp, #0x78]
    1ec4:      	ldrb	w9, [x23, #0x1b]
    1ec8:      	add	x2, x8, x9
    1ecc:      	blr	x24
    1ed0:      	ldr	x8, [sp, #0x60]
    1ed4:      	cbz	x8, 0x21c0 <perf_unwind_ruby+0x21c0>
    1ed8:      	ldr	x8, [sp, #0x70]
    1edc:      	cbz	x8, 0x21c0 <perf_unwind_ruby+0x21c0>
    1ee0:      	ldrb	w9, [x23, #0x1f]
    1ee4:      	mov	w10, #0x70              // =112
    1ee8:      	add	x11, sp, #0x68
    1eec:      	add	x0, sp, #0x68
    1ef0:      	mov	w1, #0x8                // =8
    1ef4:      	add	x8, x8, x9
    1ef8:      	mov	w9, #0x8                // =8
    1efc:      	ldr	x8, [sp, #0x70]
    1f00:      	ldrb	w9, [x23, #0x1f]
    1f04:      	add	x2, x8, x9
    1f08:      	blr	x10
    1f0c:      	adrp	x25, 0x1000 <perf_unwind_ruby+0x1000>
    1f10:      	mov	x20, x29
    1f14:      	ldr	x25, [x25]
    1f18:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    1f1c:      	ldr	x8, [sp, #0x68]
    1f20:      	ldrb	w9, [x23, #0x21]
    1f24:      	mov	w10, #0x70              // =112
    1f28:      	add	x11, sp, #0x58
    1f2c:      	add	x0, sp, #0x58
    1f30:      	mov	w1, #0x8                // =8
    1f34:      	add	x8, x8, x9
    1f38:      	mov	w9, #0x8                // =8
    1f3c:      	ldr	x8, [sp, #0x68]
    1f40:      	ldrb	w9, [x23, #0x21]
    1f44:      	add	x2, x8, x9
    1f48:      	blr	x10
    1f4c:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    1f50:      	ldr	x8, [sp, #0x68]
    1f54:      	ldrb	w9, [x23, #0x22]
    1f58:      	mov	w10, #0x70              // =112
    1f5c:      	add	x11, sp, #0x88
    1f60:      	add	x0, sp, #0x88
    1f64:      	mov	w1, #0x4                // =4
    1f68:      	add	x8, x8, x9
    1f6c:      	mov	w9, #0x4                // =4
    1f70:      	ldr	x8, [sp, #0x68]
    1f74:      	ldrb	w9, [x23, #0x22]
    1f78:      	add	x2, x8, x9
    1f7c:      	blr	x10
    1f80:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    1f84:      	ldrb	w9, [x23, #0x23]
    1f88:      	ldr	x8, [sp, #0x60]
    1f8c:      	cbz	x9, 0x275c <perf_unwind_ruby+0x275c>
    1f90:      	ldr	x10, [sp, #0x58]
    1f94:      	sub	x10, x8, x10
    1f98:      	udiv	x9, x10, x9
    1f9c:      	ldr	w10, [sp, #0x88]
    1fa0:      	cmp	x9, x10
    1fa4:      	b.ls	0x275c <perf_unwind_ruby+0x275c>
    1fa8:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1fac:      	ldr	x8, [x8]
    1fb0:      	ldr	w8, [x8]
    1fb4:      	cbz	w8, 0x21d0 <perf_unwind_ruby+0x21d0>
    1fb8:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    1fbc:      	add	x8, x8, #0x0
    1fc0:      	add	x0, sp, #0x8
    1fc4:      	ldp	x9, x10, [x8, #0x10]
    1fc8:      	mov	w1, #0x2d               // =45
    1fcc:      	stp	x9, x10, [sp, #0x18]
    1fd0:      	ldr	x9, [x8, #0x20]
    1fd4:      	add	x10, sp, #0x8
    1fd8:      	str	x9, [sp, #0x28]
    1fdc:      	ldur	x9, [x8, #0x25]
    1fe0:      	stur	x9, [sp, #0x2d]
    1fe4:      	ldp	x9, x8, [x8]
    1fe8:      	stp	x9, x8, [sp, #0x8]
    1fec:      	mov	w8, #0x2d               // =45
    1ff0:      	mov	w9, #0x6                // =6
    1ff4:      	blr	x9
    1ff8:      	b	0x21d0 <perf_unwind_ruby+0x21d0>
    1ffc:      	adrp	x8, 0x1000 <perf_unwind_ruby+0x1000>
    2000:      	add	x8, x8, #0x0
    2004:      	add	x0, sp, #0x8
    2008:      	ldp	x9, x10, [x8, #0x10]
    200c:      	mov	w1, #0x25               // =37
    2010:      	stp	x9, x10, [sp, #0x18]
    2014:      	ldur	x9, [x8, #0x1d]
    2018:      	add	x10, sp, #0x8
    201c:      	stur	x9, [sp, #0x25]
    2020:      	ldp	x8, x9, [x8]
    2024:      	stp	x8, x9, [sp, #0x8]
    2028:      	mov	w8, #0x25               // =37
    202c:      	mov	w9, #0x6                // =6
    2030:      	blr	x9
    2034:      	b	0xeb0 <perf_unwind_ruby+0xeb0>
    2038:      	ldr	x8, [sp, #0x78]
    203c:      	ldrb	w9, [x23, #0x1d]
    2040:      	mov	w10, #0x70              // =112
    2044:      	add	x11, sp, #0x50
    2048:      	add	x0, sp, #0x50
    204c:      	mov	w1, #0x8                // =8
    2050:      	str	xzr, [sp, #0x50]
    2054:      	add	x8, x8, x9
    2058:      	mov	w9, #0x8                // =8
    205c:      	ldr	x8, [sp, #0x78]
    2060:      	ldrb	w9, [x23, #0x1d]
    2064:      	add	x2, x8, x9
    2068:      	blr	x10
    206c:      	adrp	x25, 0x2000 <perf_unwind_ruby+0x2000>
    2070:      	mov	x20, x29
    2074:      	ldr	x25, [x25]
    2078:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    207c:      	ldr	w8, [sp, #0x50]
    2080:      	mov	w9, #0x140              // =320
    2084:      	mvn	w8, w8
    2088:      	tst	x8, x9
    208c:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    2090:      	b	0x1e58 <perf_unwind_ruby+0x1e58>
    2094:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    2098:      	ldr	x8, [x8]
    209c:      	ldr	w8, [x8]
    20a0:      	cbz	w8, 0x1530 <perf_unwind_ruby+0x1530>
    20a4:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    20a8:      	add	x8, x8, #0x0
    20ac:      	add	x0, sp, #0x8
    20b0:      	ldp	x9, x10, [x8, #0x10]
    20b4:      	mov	w1, #0x2e               // =46
    20b8:      	stp	x9, x10, [sp, #0x18]
    20bc:      	ldr	x9, [x8, #0x20]
    20c0:      	add	x10, sp, #0x8
    20c4:      	str	x9, [sp, #0x28]
    20c8:      	ldur	x9, [x8, #0x26]
    20cc:      	stur	x9, [sp, #0x2e]
    20d0:      	ldp	x9, x8, [x8]
    20d4:      	stp	x9, x8, [sp, #0x8]
    20d8:      	mov	w8, #0x2e               // =46
    20dc:      	mov	w9, #0x6                // =6
    20e0:      	ldr	w2, [sp, #0x50]
    20e4:      	blr	x9
    20e8:      	b	0x1530 <perf_unwind_ruby+0x1530>
    20ec:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    20f0:      	add	x8, x8, #0x0
    20f4:      	add	x0, sp, #0x8
    20f8:      	ldp	x9, x10, [x8, #0x10]
    20fc:      	mov	w1, #0x2e               // =46
    2100:      	stp	x9, x10, [sp, #0x18]
    2104:      	ldr	x9, [x8, #0x20]
    2108:      	add	x10, sp, #0x8
    210c:      	str	x9, [sp, #0x28]
    2110:      	ldur	x9, [x8, #0x26]
    2114:      	stur	x9, [sp, #0x2e]
    2118:      	ldp	x9, x8, [x8]
    211c:      	stp	x9, x8, [sp, #0x8]
    2120:      	mov	w8, #0x2e               // =46
    2124:      	mov	w9, #0x6                // =6
    2128:      	ldr	w2, [sp, #0x8c]
    212c:      	blr	x9
    2130:      	ldr	w8, [x25]
    2134:      	cbnz	w8, 0xee8 <perf_unwind_ruby+0xee8>
    2138:      	b	0x11a4 <perf_unwind_ruby+0x11a4>
    213c:      	ldr	w9, [x22, #0x2c0]
    2140:      	adrp	x25, 0x2000 <perf_unwind_ruby+0x2000>
    2144:      	ldr	x25, [x25]
    2148:      	cmp	w9, #0x7e
    214c:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    2150:      	ldr	x10, [sp, #0x68]
    2154:      	add	w11, w9, #0x1
    2158:      	str	wzr, [sp, #0x50]
    215c:      	mov	x0, x29
    2160:      	add	x1, sp, #0x50
    2164:      	strh	wzr, [sp, #0x54]
    2168:      	str	w11, [x22, #0x2c0]
    216c:      	mov	w11, #0x18              // =24
    2170:      	umaddl	x9, w9, w11, x22
    2174:      	str	x10, [x9, #0x2d0]
    2178:      	mov	w10, #0x6               // =6
    217c:      	str	x8, [x9, #0x2d8]
    2180:      	add	x8, x9, #0x2d0
    2184:      	strh	w10, [x9, #0x2e0]
    2188:      	ldr	w11, [sp, #0x50]
    218c:      	ldrh	w10, [sp, #0x54]
    2190:      	stur	w11, [x8, #0x12]
    2194:      	mov	w8, #0x36               // =54
    2198:      	strh	w10, [x9, #0x2e6]
    219c:      	add	x9, sp, #0x50
    21a0:      	str	w8, [sp, #0x50]
    21a4:      	mov	w8, #0x1                // =1
    21a8:      	blr	x8
    21ac:      	cbz	x0, 0x23d0 <perf_unwind_ruby+0x23d0>
    21b0:      	ldr	x8, [x0]
    21b4:      	add	x8, x8, #0x1
    21b8:      	str	x8, [x0]
    21bc:      	b	0x1990 <perf_unwind_ruby+0x1990>
    21c0:      	ldr	w8, [x23]
    21c4:      	lsr	w8, w8, #9
    21c8:      	cmp	w8, #0x103
    21cc:      	b.hs	0x2374 <perf_unwind_ruby+0x2374>
    21d0:      	ldr	x8, [sp, #0x78]
    21d4:      	ldr	x9, [sp]
    21d8:      	cmp	x9, x8
    21dc:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    21e0:      	ldrb	w9, [x23, #0x1e]
    21e4:      	str	xzr, [sp, #0x60]
    21e8:      	mov	w20, #0x8               // =8
    21ec:      	mov	w10, #0x70              // =112
    21f0:      	add	x0, sp, #0x70
    21f4:      	mov	w1, #0x8                // =8
    21f8:      	mov	w24, #0x70              // =112
    21fc:      	add	x8, x8, x9
    2200:      	ldrb	w9, [x23, #0x1c]
    2204:      	stp	xzr, x8, [sp, #0x70]
    2208:      	add	x8, x8, x9
    220c:      	add	x9, sp, #0x70
    2210:      	ldr	x8, [sp, #0x78]
    2214:      	ldrb	w9, [x23, #0x1c]
    2218:      	add	x2, x8, x9
    221c:      	blr	x10
    2220:      	ldr	x8, [sp, #0x78]
    2224:      	ldrb	w9, [x23, #0x1b]
    2228:      	add	x0, sp, #0x60
    222c:      	mov	w1, #0x8                // =8
    2230:      	add	x8, x8, x9
    2234:      	add	x9, sp, #0x60
    2238:      	ldr	x8, [sp, #0x78]
    223c:      	ldrb	w9, [x23, #0x1b]
    2240:      	add	x2, x8, x9
    2244:      	blr	x24
    2248:      	ldr	x8, [sp, #0x60]
    224c:      	cbz	x8, 0x24f4 <perf_unwind_ruby+0x24f4>
    2250:      	ldr	x8, [sp, #0x70]
    2254:      	cbz	x8, 0x24f4 <perf_unwind_ruby+0x24f4>
    2258:      	ldrb	w9, [x23, #0x1f]
    225c:      	mov	w10, #0x70              // =112
    2260:      	add	x11, sp, #0x68
    2264:      	add	x0, sp, #0x68
    2268:      	mov	w1, #0x8                // =8
    226c:      	add	x8, x8, x9
    2270:      	mov	w9, #0x8                // =8
    2274:      	ldr	x8, [sp, #0x70]
    2278:      	ldrb	w9, [x23, #0x1f]
    227c:      	add	x2, x8, x9
    2280:      	blr	x10
    2284:      	adrp	x25, 0x2000 <perf_unwind_ruby+0x2000>
    2288:      	mov	x20, x29
    228c:      	ldr	x25, [x25]
    2290:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    2294:      	ldr	x8, [sp, #0x68]
    2298:      	ldrb	w9, [x23, #0x21]
    229c:      	mov	w10, #0x70              // =112
    22a0:      	add	x11, sp, #0x58
    22a4:      	add	x0, sp, #0x58
    22a8:      	mov	w1, #0x8                // =8
    22ac:      	add	x8, x8, x9
    22b0:      	mov	w9, #0x8                // =8
    22b4:      	ldr	x8, [sp, #0x68]
    22b8:      	ldrb	w9, [x23, #0x21]
    22bc:      	add	x2, x8, x9
    22c0:      	blr	x10
    22c4:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    22c8:      	ldr	x8, [sp, #0x68]
    22cc:      	ldrb	w9, [x23, #0x22]
    22d0:      	mov	w10, #0x70              // =112
    22d4:      	add	x11, sp, #0x88
    22d8:      	add	x0, sp, #0x88
    22dc:      	mov	w1, #0x4                // =4
    22e0:      	add	x8, x8, x9
    22e4:      	mov	w9, #0x4                // =4
    22e8:      	ldr	x8, [sp, #0x68]
    22ec:      	ldrb	w9, [x23, #0x22]
    22f0:      	add	x2, x8, x9
    22f4:      	blr	x10
    22f8:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    22fc:      	ldrb	w9, [x23, #0x23]
    2300:      	ldr	x8, [sp, #0x60]
    2304:      	cbz	x9, 0x2a90 <perf_unwind_ruby+0x2a90>
    2308:      	ldr	x10, [sp, #0x58]
    230c:      	sub	x10, x8, x10
    2310:      	udiv	x9, x10, x9
    2314:      	ldr	w10, [sp, #0x88]
    2318:      	cmp	x9, x10
    231c:      	b.ls	0x2a90 <perf_unwind_ruby+0x2a90>
    2320:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    2324:      	ldr	x8, [x8]
    2328:      	ldr	w8, [x8]
    232c:      	cbz	w8, 0x2504 <perf_unwind_ruby+0x2504>
    2330:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    2334:      	add	x8, x8, #0x0
    2338:      	add	x0, sp, #0x8
    233c:      	ldp	x9, x10, [x8, #0x10]
    2340:      	mov	w1, #0x2d               // =45
    2344:      	stp	x9, x10, [sp, #0x18]
    2348:      	ldr	x9, [x8, #0x20]
    234c:      	add	x10, sp, #0x8
    2350:      	str	x9, [sp, #0x28]
    2354:      	ldur	x9, [x8, #0x25]
    2358:      	stur	x9, [sp, #0x2d]
    235c:      	ldp	x9, x8, [x8]
    2360:      	stp	x9, x8, [sp, #0x8]
    2364:      	mov	w8, #0x2d               // =45
    2368:      	mov	w9, #0x6                // =6
    236c:      	blr	x9
    2370:      	b	0x2504 <perf_unwind_ruby+0x2504>
    2374:      	ldr	x8, [sp, #0x78]
    2378:      	ldrb	w9, [x23, #0x1d]
    237c:      	mov	w10, #0x70              // =112
    2380:      	add	x11, sp, #0x50
    2384:      	add	x0, sp, #0x50
    2388:      	mov	w1, #0x8                // =8
    238c:      	str	xzr, [sp, #0x50]
    2390:      	add	x8, x8, x9
    2394:      	mov	w9, #0x8                // =8
    2398:      	ldr	x8, [sp, #0x78]
    239c:      	ldrb	w9, [x23, #0x1d]
    23a0:      	add	x2, x8, x9
    23a4:      	blr	x10
    23a8:      	adrp	x25, 0x2000 <perf_unwind_ruby+0x2000>
    23ac:      	mov	x20, x29
    23b0:      	ldr	x25, [x25]
    23b4:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    23b8:      	ldr	w8, [sp, #0x50]
    23bc:      	mov	w9, #0x140              // =320
    23c0:      	mvn	w8, w8
    23c4:      	tst	x8, x9
    23c8:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    23cc:      	b	0x21d0 <perf_unwind_ruby+0x21d0>
    23d0:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    23d4:      	ldr	x8, [x8]
    23d8:      	ldr	w8, [x8]
    23dc:      	cbz	w8, 0x1990 <perf_unwind_ruby+0x1990>
    23e0:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    23e4:      	add	x8, x8, #0x0
    23e8:      	add	x0, sp, #0x8
    23ec:      	ldp	x9, x10, [x8, #0x10]
    23f0:      	mov	w1, #0x2e               // =46
    23f4:      	stp	x9, x10, [sp, #0x18]
    23f8:      	ldr	x9, [x8, #0x20]
    23fc:      	add	x10, sp, #0x8
    2400:      	str	x9, [sp, #0x28]
    2404:      	ldur	x9, [x8, #0x26]
    2408:      	stur	x9, [sp, #0x2e]
    240c:      	ldp	x9, x8, [x8]
    2410:      	stp	x9, x8, [sp, #0x8]
    2414:      	mov	w8, #0x2e               // =46
    2418:      	mov	w9, #0x6                // =6
    241c:      	ldr	w2, [sp, #0x50]
    2420:      	blr	x9
    2424:      	b	0x1990 <perf_unwind_ruby+0x1990>
    2428:      	ldr	w9, [x22, #0x2c0]
    242c:      	adrp	x25, 0x2000 <perf_unwind_ruby+0x2000>
    2430:      	ldr	x25, [x25]
    2434:      	cmp	w9, #0x7e
    2438:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    243c:      	ldr	x10, [sp, #0x68]
    2440:      	add	w11, w9, #0x1
    2444:      	str	wzr, [sp, #0x50]
    2448:      	mov	x0, x29
    244c:      	add	x1, sp, #0x50
    2450:      	strh	wzr, [sp, #0x54]
    2454:      	str	w11, [x22, #0x2c0]
    2458:      	mov	w11, #0x18              // =24
    245c:      	umaddl	x9, w9, w11, x22
    2460:      	str	x10, [x9, #0x2d0]
    2464:      	mov	w10, #0x6               // =6
    2468:      	str	x8, [x9, #0x2d8]
    246c:      	add	x8, x9, #0x2d0
    2470:      	strh	w10, [x9, #0x2e0]
    2474:      	ldr	w11, [sp, #0x50]
    2478:      	ldrh	w10, [sp, #0x54]
    247c:      	stur	w11, [x8, #0x12]
    2480:      	mov	w8, #0x36               // =54
    2484:      	strh	w10, [x9, #0x2e6]
    2488:      	add	x9, sp, #0x50
    248c:      	str	w8, [sp, #0x50]
    2490:      	mov	w8, #0x1                // =1
    2494:      	blr	x8
    2498:      	cbz	x0, 0x2704 <perf_unwind_ruby+0x2704>
    249c:      	ldr	x8, [x0]
    24a0:      	add	x8, x8, #0x1
    24a4:      	str	x8, [x0]
    24a8:      	b	0x1e58 <perf_unwind_ruby+0x1e58>
    24ac:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    24b0:      	add	x8, x8, #0x0
    24b4:      	add	x0, sp, #0x8
    24b8:      	ldp	x9, x10, [x8, #0x10]
    24bc:      	mov	w1, #0x2e               // =46
    24c0:      	stp	x9, x10, [sp, #0x18]
    24c4:      	ldr	x9, [x8, #0x20]
    24c8:      	add	x10, sp, #0x8
    24cc:      	str	x9, [sp, #0x28]
    24d0:      	ldur	x9, [x8, #0x26]
    24d4:      	stur	x9, [sp, #0x2e]
    24d8:      	ldp	x9, x8, [x8]
    24dc:      	stp	x9, x8, [sp, #0x8]
    24e0:      	mov	w8, #0x2e               // =46
    24e4:      	mov	w9, #0x6                // =6
    24e8:      	ldr	w2, [sp, #0x50]
    24ec:      	blr	x9
    24f0:      	b	0x1498 <perf_unwind_ruby+0x1498>
    24f4:      	ldr	w8, [x23]
    24f8:      	lsr	w8, w8, #9
    24fc:      	cmp	w8, #0x103
    2500:      	b.hs	0x26a8 <perf_unwind_ruby+0x26a8>
    2504:      	ldr	x8, [sp, #0x78]
    2508:      	ldr	x9, [sp]
    250c:      	cmp	x9, x8
    2510:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    2514:      	ldrb	w9, [x23, #0x1e]
    2518:      	str	xzr, [sp, #0x60]
    251c:      	mov	w20, #0x8               // =8
    2520:      	mov	w10, #0x70              // =112
    2524:      	add	x0, sp, #0x70
    2528:      	mov	w1, #0x8                // =8
    252c:      	mov	w24, #0x70              // =112
    2530:      	add	x8, x8, x9
    2534:      	ldrb	w9, [x23, #0x1c]
    2538:      	stp	xzr, x8, [sp, #0x70]
    253c:      	add	x8, x8, x9
    2540:      	add	x9, sp, #0x70
    2544:      	ldr	x8, [sp, #0x78]
    2548:      	ldrb	w9, [x23, #0x1c]
    254c:      	add	x2, x8, x9
    2550:      	blr	x10
    2554:      	ldr	x8, [sp, #0x78]
    2558:      	ldrb	w9, [x23, #0x1b]
    255c:      	add	x0, sp, #0x60
    2560:      	mov	w1, #0x8                // =8
    2564:      	add	x8, x8, x9
    2568:      	add	x9, sp, #0x60
    256c:      	ldr	x8, [sp, #0x78]
    2570:      	ldrb	w9, [x23, #0x1b]
    2574:      	add	x2, x8, x9
    2578:      	blr	x24
    257c:      	ldr	x8, [sp, #0x60]
    2580:      	cbz	x8, 0x2828 <perf_unwind_ruby+0x2828>
    2584:      	ldr	x8, [sp, #0x70]
    2588:      	cbz	x8, 0x2828 <perf_unwind_ruby+0x2828>
    258c:      	ldrb	w9, [x23, #0x1f]
    2590:      	mov	w10, #0x70              // =112
    2594:      	add	x11, sp, #0x68
    2598:      	add	x0, sp, #0x68
    259c:      	mov	w1, #0x8                // =8
    25a0:      	add	x8, x8, x9
    25a4:      	mov	w9, #0x8                // =8
    25a8:      	ldr	x8, [sp, #0x70]
    25ac:      	ldrb	w9, [x23, #0x1f]
    25b0:      	add	x2, x8, x9
    25b4:      	blr	x10
    25b8:      	adrp	x25, 0x2000 <perf_unwind_ruby+0x2000>
    25bc:      	mov	x20, x29
    25c0:      	ldr	x25, [x25]
    25c4:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    25c8:      	ldr	x8, [sp, #0x68]
    25cc:      	ldrb	w9, [x23, #0x21]
    25d0:      	mov	w10, #0x70              // =112
    25d4:      	add	x11, sp, #0x58
    25d8:      	add	x0, sp, #0x58
    25dc:      	mov	w1, #0x8                // =8
    25e0:      	add	x8, x8, x9
    25e4:      	mov	w9, #0x8                // =8
    25e8:      	ldr	x8, [sp, #0x68]
    25ec:      	ldrb	w9, [x23, #0x21]
    25f0:      	add	x2, x8, x9
    25f4:      	blr	x10
    25f8:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    25fc:      	ldr	x8, [sp, #0x68]
    2600:      	ldrb	w9, [x23, #0x22]
    2604:      	mov	w10, #0x70              // =112
    2608:      	add	x11, sp, #0x88
    260c:      	add	x0, sp, #0x88
    2610:      	mov	w1, #0x4                // =4
    2614:      	add	x8, x8, x9
    2618:      	mov	w9, #0x4                // =4
    261c:      	ldr	x8, [sp, #0x68]
    2620:      	ldrb	w9, [x23, #0x22]
    2624:      	add	x2, x8, x9
    2628:      	blr	x10
    262c:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    2630:      	ldrb	w9, [x23, #0x23]
    2634:      	ldr	x8, [sp, #0x60]
    2638:      	cbz	x9, 0x2d7c <perf_unwind_ruby+0x2d7c>
    263c:      	ldr	x10, [sp, #0x58]
    2640:      	sub	x10, x8, x10
    2644:      	udiv	x9, x10, x9
    2648:      	ldr	w10, [sp, #0x88]
    264c:      	cmp	x9, x10
    2650:      	b.ls	0x2d7c <perf_unwind_ruby+0x2d7c>
    2654:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    2658:      	ldr	x8, [x8]
    265c:      	ldr	w8, [x8]
    2660:      	cbz	w8, 0x2838 <perf_unwind_ruby+0x2838>
    2664:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    2668:      	add	x8, x8, #0x0
    266c:      	add	x0, sp, #0x8
    2670:      	ldp	x9, x10, [x8, #0x10]
    2674:      	mov	w1, #0x2d               // =45
    2678:      	stp	x9, x10, [sp, #0x18]
    267c:      	ldr	x9, [x8, #0x20]
    2680:      	add	x10, sp, #0x8
    2684:      	str	x9, [sp, #0x28]
    2688:      	ldur	x9, [x8, #0x25]
    268c:      	stur	x9, [sp, #0x2d]
    2690:      	ldp	x9, x8, [x8]
    2694:      	stp	x9, x8, [sp, #0x8]
    2698:      	mov	w8, #0x2d               // =45
    269c:      	mov	w9, #0x6                // =6
    26a0:      	blr	x9
    26a4:      	b	0x2838 <perf_unwind_ruby+0x2838>
    26a8:      	ldr	x8, [sp, #0x78]
    26ac:      	ldrb	w9, [x23, #0x1d]
    26b0:      	mov	w10, #0x70              // =112
    26b4:      	add	x11, sp, #0x50
    26b8:      	add	x0, sp, #0x50
    26bc:      	mov	w1, #0x8                // =8
    26c0:      	str	xzr, [sp, #0x50]
    26c4:      	add	x8, x8, x9
    26c8:      	mov	w9, #0x8                // =8
    26cc:      	ldr	x8, [sp, #0x78]
    26d0:      	ldrb	w9, [x23, #0x1d]
    26d4:      	add	x2, x8, x9
    26d8:      	blr	x10
    26dc:      	adrp	x25, 0x2000 <perf_unwind_ruby+0x2000>
    26e0:      	mov	x20, x29
    26e4:      	ldr	x25, [x25]
    26e8:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    26ec:      	ldr	w8, [sp, #0x50]
    26f0:      	mov	w9, #0x140              // =320
    26f4:      	mvn	w8, w8
    26f8:      	tst	x8, x9
    26fc:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    2700:      	b	0x2504 <perf_unwind_ruby+0x2504>
    2704:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    2708:      	ldr	x8, [x8]
    270c:      	ldr	w8, [x8]
    2710:      	cbz	w8, 0x1e58 <perf_unwind_ruby+0x1e58>
    2714:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    2718:      	add	x8, x8, #0x0
    271c:      	add	x0, sp, #0x8
    2720:      	ldp	x9, x10, [x8, #0x10]
    2724:      	mov	w1, #0x2e               // =46
    2728:      	stp	x9, x10, [sp, #0x18]
    272c:      	ldr	x9, [x8, #0x20]
    2730:      	add	x10, sp, #0x8
    2734:      	str	x9, [sp, #0x28]
    2738:      	ldur	x9, [x8, #0x26]
    273c:      	stur	x9, [sp, #0x2e]
    2740:      	ldp	x9, x8, [x8]
    2744:      	stp	x9, x8, [sp, #0x8]
    2748:      	mov	w8, #0x2e               // =46
    274c:      	mov	w9, #0x6                // =6
    2750:      	ldr	w2, [sp, #0x50]
    2754:      	blr	x9
    2758:      	b	0x1e58 <perf_unwind_ruby+0x1e58>
    275c:      	ldr	w9, [x22, #0x2c0]
    2760:      	adrp	x25, 0x2000 <perf_unwind_ruby+0x2000>
    2764:      	ldr	x25, [x25]
    2768:      	cmp	w9, #0x7e
    276c:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    2770:      	ldr	x10, [sp, #0x68]
    2774:      	add	w11, w9, #0x1
    2778:      	str	wzr, [sp, #0x50]
    277c:      	mov	x0, x29
    2780:      	add	x1, sp, #0x50
    2784:      	strh	wzr, [sp, #0x54]
    2788:      	str	w11, [x22, #0x2c0]
    278c:      	mov	w11, #0x18              // =24
    2790:      	umaddl	x9, w9, w11, x22
    2794:      	str	x10, [x9, #0x2d0]
    2798:      	mov	w10, #0x6               // =6
    279c:      	str	x8, [x9, #0x2d8]
    27a0:      	add	x8, x9, #0x2d0
    27a4:      	strh	w10, [x9, #0x2e0]
    27a8:      	ldr	w11, [sp, #0x50]
    27ac:      	ldrh	w10, [sp, #0x54]
    27b0:      	stur	w11, [x8, #0x12]
    27b4:      	mov	w8, #0x36               // =54
    27b8:      	strh	w10, [x9, #0x2e6]
    27bc:      	add	x9, sp, #0x50
    27c0:      	str	w8, [sp, #0x50]
    27c4:      	mov	w8, #0x1                // =1
    27c8:      	blr	x8
    27cc:      	cbz	x0, 0x2a38 <perf_unwind_ruby+0x2a38>
    27d0:      	ldr	x8, [x0]
    27d4:      	add	x8, x8, #0x1
    27d8:      	str	x8, [x0]
    27dc:      	b	0x21d0 <perf_unwind_ruby+0x21d0>
    27e0:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    27e4:      	add	x8, x8, #0x0
    27e8:      	add	x0, sp, #0x8
    27ec:      	ldp	x9, x10, [x8, #0x10]
    27f0:      	mov	w1, #0x2e               // =46
    27f4:      	stp	x9, x10, [sp, #0x18]
    27f8:      	ldr	x9, [x8, #0x20]
    27fc:      	add	x10, sp, #0x8
    2800:      	str	x9, [sp, #0x28]
    2804:      	ldur	x9, [x8, #0x26]
    2808:      	stur	x9, [sp, #0x2e]
    280c:      	ldp	x9, x8, [x8]
    2810:      	stp	x9, x8, [sp, #0x8]
    2814:      	mov	w8, #0x2e               // =46
    2818:      	mov	w9, #0x6                // =6
    281c:      	ldr	w2, [sp, #0x50]
    2820:      	blr	x9
    2824:      	b	0x186c <perf_unwind_ruby+0x186c>
    2828:      	ldr	w8, [x23]
    282c:      	lsr	w8, w8, #9
    2830:      	cmp	w8, #0x103
    2834:      	b.hs	0x29dc <perf_unwind_ruby+0x29dc>
    2838:      	ldr	x8, [sp, #0x78]
    283c:      	ldr	x9, [sp]
    2840:      	cmp	x9, x8
    2844:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    2848:      	ldrb	w9, [x23, #0x1e]
    284c:      	str	xzr, [sp, #0x60]
    2850:      	mov	w20, #0x8               // =8
    2854:      	mov	w10, #0x70              // =112
    2858:      	add	x0, sp, #0x70
    285c:      	mov	w1, #0x8                // =8
    2860:      	mov	w24, #0x70              // =112
    2864:      	add	x8, x8, x9
    2868:      	ldrb	w9, [x23, #0x1c]
    286c:      	stp	xzr, x8, [sp, #0x70]
    2870:      	add	x8, x8, x9
    2874:      	add	x9, sp, #0x70
    2878:      	ldr	x8, [sp, #0x78]
    287c:      	ldrb	w9, [x23, #0x1c]
    2880:      	add	x2, x8, x9
    2884:      	blr	x10
    2888:      	ldr	x8, [sp, #0x78]
    288c:      	ldrb	w9, [x23, #0x1b]
    2890:      	add	x0, sp, #0x60
    2894:      	mov	w1, #0x8                // =8
    2898:      	add	x8, x8, x9
    289c:      	add	x9, sp, #0x60
    28a0:      	ldr	x8, [sp, #0x78]
    28a4:      	ldrb	w9, [x23, #0x1b]
    28a8:      	add	x2, x8, x9
    28ac:      	blr	x24
    28b0:      	ldr	x8, [sp, #0x60]
    28b4:      	cbz	x8, 0x2b14 <perf_unwind_ruby+0x2b14>
    28b8:      	ldr	x8, [sp, #0x70]
    28bc:      	cbz	x8, 0x2b14 <perf_unwind_ruby+0x2b14>
    28c0:      	ldrb	w9, [x23, #0x1f]
    28c4:      	mov	w10, #0x70              // =112
    28c8:      	add	x11, sp, #0x68
    28cc:      	add	x0, sp, #0x68
    28d0:      	mov	w1, #0x8                // =8
    28d4:      	add	x8, x8, x9
    28d8:      	mov	w9, #0x8                // =8
    28dc:      	ldr	x8, [sp, #0x70]
    28e0:      	ldrb	w9, [x23, #0x1f]
    28e4:      	add	x2, x8, x9
    28e8:      	blr	x10
    28ec:      	adrp	x25, 0x2000 <perf_unwind_ruby+0x2000>
    28f0:      	mov	x20, x29
    28f4:      	ldr	x25, [x25]
    28f8:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    28fc:      	ldr	x8, [sp, #0x68]
    2900:      	ldrb	w9, [x23, #0x21]
    2904:      	mov	w10, #0x70              // =112
    2908:      	add	x11, sp, #0x58
    290c:      	add	x0, sp, #0x58
    2910:      	mov	w1, #0x8                // =8
    2914:      	add	x8, x8, x9
    2918:      	mov	w9, #0x8                // =8
    291c:      	ldr	x8, [sp, #0x68]
    2920:      	ldrb	w9, [x23, #0x21]
    2924:      	add	x2, x8, x9
    2928:      	blr	x10
    292c:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    2930:      	ldr	x8, [sp, #0x68]
    2934:      	ldrb	w9, [x23, #0x22]
    2938:      	mov	w10, #0x70              // =112
    293c:      	add	x11, sp, #0x88
    2940:      	add	x0, sp, #0x88
    2944:      	mov	w1, #0x4                // =4
    2948:      	add	x8, x8, x9
    294c:      	mov	w9, #0x4                // =4
    2950:      	ldr	x8, [sp, #0x68]
    2954:      	ldrb	w9, [x23, #0x22]
    2958:      	add	x2, x8, x9
    295c:      	blr	x10
    2960:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    2964:      	ldrb	w9, [x23, #0x23]
    2968:      	ldr	x8, [sp, #0x60]
    296c:      	cbz	x9, 0x3068 <perf_unwind_ruby+0x3068>
    2970:      	ldr	x10, [sp, #0x58]
    2974:      	sub	x10, x8, x10
    2978:      	udiv	x9, x10, x9
    297c:      	ldr	w10, [sp, #0x88]
    2980:      	cmp	x9, x10
    2984:      	b.ls	0x3068 <perf_unwind_ruby+0x3068>
    2988:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    298c:      	ldr	x8, [x8]
    2990:      	ldr	w8, [x8]
    2994:      	cbz	w8, 0x2b24 <perf_unwind_ruby+0x2b24>
    2998:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    299c:      	add	x8, x8, #0x0
    29a0:      	add	x0, sp, #0x8
    29a4:      	ldp	x9, x10, [x8, #0x10]
    29a8:      	mov	w1, #0x2d               // =45
    29ac:      	stp	x9, x10, [sp, #0x18]
    29b0:      	ldr	x9, [x8, #0x20]
    29b4:      	add	x10, sp, #0x8
    29b8:      	str	x9, [sp, #0x28]
    29bc:      	ldur	x9, [x8, #0x25]
    29c0:      	stur	x9, [sp, #0x2d]
    29c4:      	ldp	x9, x8, [x8]
    29c8:      	stp	x9, x8, [sp, #0x8]
    29cc:      	mov	w8, #0x2d               // =45
    29d0:      	mov	w9, #0x6                // =6
    29d4:      	blr	x9
    29d8:      	b	0x2b24 <perf_unwind_ruby+0x2b24>
    29dc:      	ldr	x8, [sp, #0x78]
    29e0:      	ldrb	w9, [x23, #0x1d]
    29e4:      	mov	w10, #0x70              // =112
    29e8:      	add	x11, sp, #0x50
    29ec:      	add	x0, sp, #0x50
    29f0:      	mov	w1, #0x8                // =8
    29f4:      	str	xzr, [sp, #0x50]
    29f8:      	add	x8, x8, x9
    29fc:      	mov	w9, #0x8                // =8
    2a00:      	ldr	x8, [sp, #0x78]
    2a04:      	ldrb	w9, [x23, #0x1d]
    2a08:      	add	x2, x8, x9
    2a0c:      	blr	x10
    2a10:      	adrp	x25, 0x2000 <perf_unwind_ruby+0x2000>
    2a14:      	mov	x20, x29
    2a18:      	ldr	x25, [x25]
    2a1c:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    2a20:      	ldr	w8, [sp, #0x50]
    2a24:      	mov	w9, #0x140              // =320
    2a28:      	mvn	w8, w8
    2a2c:      	tst	x8, x9
    2a30:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    2a34:      	b	0x2838 <perf_unwind_ruby+0x2838>
    2a38:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    2a3c:      	ldr	x8, [x8]
    2a40:      	ldr	w8, [x8]
    2a44:      	cbz	w8, 0x21d0 <perf_unwind_ruby+0x21d0>
    2a48:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    2a4c:      	add	x8, x8, #0x0
    2a50:      	add	x0, sp, #0x8
    2a54:      	ldp	x9, x10, [x8, #0x10]
    2a58:      	mov	w1, #0x2e               // =46
    2a5c:      	stp	x9, x10, [sp, #0x18]
    2a60:      	ldr	x9, [x8, #0x20]
    2a64:      	add	x10, sp, #0x8
    2a68:      	str	x9, [sp, #0x28]
    2a6c:      	ldur	x9, [x8, #0x26]
    2a70:      	stur	x9, [sp, #0x2e]
    2a74:      	ldp	x9, x8, [x8]
    2a78:      	stp	x9, x8, [sp, #0x8]
    2a7c:      	mov	w8, #0x2e               // =46
    2a80:      	mov	w9, #0x6                // =6
    2a84:      	ldr	w2, [sp, #0x50]
    2a88:      	blr	x9
    2a8c:      	b	0x21d0 <perf_unwind_ruby+0x21d0>
    2a90:      	ldr	w9, [x22, #0x2c0]
    2a94:      	adrp	x25, 0x2000 <perf_unwind_ruby+0x2000>
    2a98:      	ldr	x25, [x25]
    2a9c:      	cmp	w9, #0x7e
    2aa0:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    2aa4:      	ldr	x10, [sp, #0x68]
    2aa8:      	add	w11, w9, #0x1
    2aac:      	str	wzr, [sp, #0x50]
    2ab0:      	mov	x0, x29
    2ab4:      	add	x1, sp, #0x50
    2ab8:      	strh	wzr, [sp, #0x54]
    2abc:      	str	w11, [x22, #0x2c0]
    2ac0:      	mov	w11, #0x18              // =24
    2ac4:      	umaddl	x9, w9, w11, x22
    2ac8:      	str	x10, [x9, #0x2d0]
    2acc:      	mov	w10, #0x6               // =6
    2ad0:      	str	x8, [x9, #0x2d8]
    2ad4:      	add	x8, x9, #0x2d0
    2ad8:      	strh	w10, [x9, #0x2e0]
    2adc:      	ldr	w11, [sp, #0x50]
    2ae0:      	ldrh	w10, [sp, #0x54]
    2ae4:      	stur	w11, [x8, #0x12]
    2ae8:      	mov	w8, #0x36               // =54
    2aec:      	strh	w10, [x9, #0x2e6]
    2af0:      	add	x9, sp, #0x50
    2af4:      	str	w8, [sp, #0x50]
    2af8:      	mov	w8, #0x1                // =1
    2afc:      	blr	x8
    2b00:      	cbz	x0, 0x2d24 <perf_unwind_ruby+0x2d24>
    2b04:      	ldr	x8, [x0]
    2b08:      	add	x8, x8, #0x1
    2b0c:      	str	x8, [x0]
    2b10:      	b	0x2504 <perf_unwind_ruby+0x2504>
    2b14:      	ldr	w8, [x23]
    2b18:      	lsr	w8, w8, #9
    2b1c:      	cmp	w8, #0x103
    2b20:      	b.hs	0x2cc8 <perf_unwind_ruby+0x2cc8>
    2b24:      	ldr	x8, [sp, #0x78]
    2b28:      	ldr	x9, [sp]
    2b2c:      	cmp	x9, x8
    2b30:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    2b34:      	ldrb	w9, [x23, #0x1e]
    2b38:      	str	xzr, [sp, #0x60]
    2b3c:      	mov	w20, #0x8               // =8
    2b40:      	mov	w10, #0x70              // =112
    2b44:      	add	x0, sp, #0x70
    2b48:      	mov	w1, #0x8                // =8
    2b4c:      	mov	w24, #0x70              // =112
    2b50:      	add	x8, x8, x9
    2b54:      	ldrb	w9, [x23, #0x1c]
    2b58:      	stp	xzr, x8, [sp, #0x70]
    2b5c:      	add	x8, x8, x9
    2b60:      	add	x9, sp, #0x70
    2b64:      	ldr	x8, [sp, #0x78]
    2b68:      	ldrb	w9, [x23, #0x1c]
    2b6c:      	add	x2, x8, x9
    2b70:      	blr	x10
    2b74:      	ldr	x8, [sp, #0x78]
    2b78:      	ldrb	w9, [x23, #0x1b]
    2b7c:      	add	x0, sp, #0x60
    2b80:      	mov	w1, #0x8                // =8
    2b84:      	add	x8, x8, x9
    2b88:      	add	x9, sp, #0x60
    2b8c:      	ldr	x8, [sp, #0x78]
    2b90:      	ldrb	w9, [x23, #0x1b]
    2b94:      	add	x2, x8, x9
    2b98:      	blr	x24
    2b9c:      	ldr	x8, [sp, #0x60]
    2ba0:      	cbz	x8, 0x2e00 <perf_unwind_ruby+0x2e00>
    2ba4:      	ldr	x8, [sp, #0x70]
    2ba8:      	cbz	x8, 0x2e00 <perf_unwind_ruby+0x2e00>
    2bac:      	ldrb	w9, [x23, #0x1f]
    2bb0:      	mov	w10, #0x70              // =112
    2bb4:      	add	x11, sp, #0x68
    2bb8:      	add	x0, sp, #0x68
    2bbc:      	mov	w1, #0x8                // =8
    2bc0:      	add	x8, x8, x9
    2bc4:      	mov	w9, #0x8                // =8
    2bc8:      	ldr	x8, [sp, #0x70]
    2bcc:      	ldrb	w9, [x23, #0x1f]
    2bd0:      	add	x2, x8, x9
    2bd4:      	blr	x10
    2bd8:      	adrp	x25, 0x2000 <perf_unwind_ruby+0x2000>
    2bdc:      	mov	x20, x29
    2be0:      	ldr	x25, [x25]
    2be4:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    2be8:      	ldr	x8, [sp, #0x68]
    2bec:      	ldrb	w9, [x23, #0x21]
    2bf0:      	mov	w10, #0x70              // =112
    2bf4:      	add	x11, sp, #0x58
    2bf8:      	add	x0, sp, #0x58
    2bfc:      	mov	w1, #0x8                // =8
    2c00:      	add	x8, x8, x9
    2c04:      	mov	w9, #0x8                // =8
    2c08:      	ldr	x8, [sp, #0x68]
    2c0c:      	ldrb	w9, [x23, #0x21]
    2c10:      	add	x2, x8, x9
    2c14:      	blr	x10
    2c18:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    2c1c:      	ldr	x8, [sp, #0x68]
    2c20:      	ldrb	w9, [x23, #0x22]
    2c24:      	mov	w10, #0x70              // =112
    2c28:      	add	x11, sp, #0x88
    2c2c:      	add	x0, sp, #0x88
    2c30:      	mov	w1, #0x4                // =4
    2c34:      	add	x8, x8, x9
    2c38:      	mov	w9, #0x4                // =4
    2c3c:      	ldr	x8, [sp, #0x68]
    2c40:      	ldrb	w9, [x23, #0x22]
    2c44:      	add	x2, x8, x9
    2c48:      	blr	x10
    2c4c:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    2c50:      	ldrb	w9, [x23, #0x23]
    2c54:      	ldr	x8, [sp, #0x60]
    2c58:      	cbz	x9, 0x3354 <perf_unwind_ruby+0x3354>
    2c5c:      	ldr	x10, [sp, #0x58]
    2c60:      	sub	x10, x8, x10
    2c64:      	udiv	x9, x10, x9
    2c68:      	ldr	w10, [sp, #0x88]
    2c6c:      	cmp	x9, x10
    2c70:      	b.ls	0x3354 <perf_unwind_ruby+0x3354>
    2c74:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    2c78:      	ldr	x8, [x8]
    2c7c:      	ldr	w8, [x8]
    2c80:      	cbz	w8, 0x2e10 <perf_unwind_ruby+0x2e10>
    2c84:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    2c88:      	add	x8, x8, #0x0
    2c8c:      	add	x0, sp, #0x8
    2c90:      	ldp	x9, x10, [x8, #0x10]
    2c94:      	mov	w1, #0x2d               // =45
    2c98:      	stp	x9, x10, [sp, #0x18]
    2c9c:      	ldr	x9, [x8, #0x20]
    2ca0:      	add	x10, sp, #0x8
    2ca4:      	str	x9, [sp, #0x28]
    2ca8:      	ldur	x9, [x8, #0x25]
    2cac:      	stur	x9, [sp, #0x2d]
    2cb0:      	ldp	x9, x8, [x8]
    2cb4:      	stp	x9, x8, [sp, #0x8]
    2cb8:      	mov	w8, #0x2d               // =45
    2cbc:      	mov	w9, #0x6                // =6
    2cc0:      	blr	x9
    2cc4:      	b	0x2e10 <perf_unwind_ruby+0x2e10>
    2cc8:      	ldr	x8, [sp, #0x78]
    2ccc:      	ldrb	w9, [x23, #0x1d]
    2cd0:      	mov	w10, #0x70              // =112
    2cd4:      	add	x11, sp, #0x50
    2cd8:      	add	x0, sp, #0x50
    2cdc:      	mov	w1, #0x8                // =8
    2ce0:      	str	xzr, [sp, #0x50]
    2ce4:      	add	x8, x8, x9
    2ce8:      	mov	w9, #0x8                // =8
    2cec:      	ldr	x8, [sp, #0x78]
    2cf0:      	ldrb	w9, [x23, #0x1d]
    2cf4:      	add	x2, x8, x9
    2cf8:      	blr	x10
    2cfc:      	adrp	x25, 0x2000 <perf_unwind_ruby+0x2000>
    2d00:      	mov	x20, x29
    2d04:      	ldr	x25, [x25]
    2d08:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    2d0c:      	ldr	w8, [sp, #0x50]
    2d10:      	mov	w9, #0x140              // =320
    2d14:      	mvn	w8, w8
    2d18:      	tst	x8, x9
    2d1c:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    2d20:      	b	0x2b24 <perf_unwind_ruby+0x2b24>
    2d24:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    2d28:      	ldr	x8, [x8]
    2d2c:      	ldr	w8, [x8]
    2d30:      	cbz	w8, 0x2504 <perf_unwind_ruby+0x2504>
    2d34:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    2d38:      	add	x8, x8, #0x0
    2d3c:      	add	x0, sp, #0x8
    2d40:      	ldp	x9, x10, [x8, #0x10]
    2d44:      	mov	w1, #0x2e               // =46
    2d48:      	stp	x9, x10, [sp, #0x18]
    2d4c:      	ldr	x9, [x8, #0x20]
    2d50:      	add	x10, sp, #0x8
    2d54:      	str	x9, [sp, #0x28]
    2d58:      	ldur	x9, [x8, #0x26]
    2d5c:      	stur	x9, [sp, #0x2e]
    2d60:      	ldp	x9, x8, [x8]
    2d64:      	stp	x9, x8, [sp, #0x8]
    2d68:      	mov	w8, #0x2e               // =46
    2d6c:      	mov	w9, #0x6                // =6
    2d70:      	ldr	w2, [sp, #0x50]
    2d74:      	blr	x9
    2d78:      	b	0x2504 <perf_unwind_ruby+0x2504>
    2d7c:      	ldr	w9, [x22, #0x2c0]
    2d80:      	adrp	x25, 0x2000 <perf_unwind_ruby+0x2000>
    2d84:      	ldr	x25, [x25]
    2d88:      	cmp	w9, #0x7e
    2d8c:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    2d90:      	ldr	x10, [sp, #0x68]
    2d94:      	add	w11, w9, #0x1
    2d98:      	str	wzr, [sp, #0x50]
    2d9c:      	mov	x0, x29
    2da0:      	add	x1, sp, #0x50
    2da4:      	strh	wzr, [sp, #0x54]
    2da8:      	str	w11, [x22, #0x2c0]
    2dac:      	mov	w11, #0x18              // =24
    2db0:      	umaddl	x9, w9, w11, x22
    2db4:      	str	x10, [x9, #0x2d0]
    2db8:      	mov	w10, #0x6               // =6
    2dbc:      	str	x8, [x9, #0x2d8]
    2dc0:      	add	x8, x9, #0x2d0
    2dc4:      	strh	w10, [x9, #0x2e0]
    2dc8:      	ldr	w11, [sp, #0x50]
    2dcc:      	ldrh	w10, [sp, #0x54]
    2dd0:      	stur	w11, [x8, #0x12]
    2dd4:      	mov	w8, #0x36               // =54
    2dd8:      	strh	w10, [x9, #0x2e6]
    2ddc:      	add	x9, sp, #0x50
    2de0:      	str	w8, [sp, #0x50]
    2de4:      	mov	w8, #0x1                // =1
    2de8:      	blr	x8
    2dec:      	cbz	x0, 0x3010 <perf_unwind_ruby+0x3010>
    2df0:      	ldr	x8, [x0]
    2df4:      	add	x8, x8, #0x1
    2df8:      	str	x8, [x0]
    2dfc:      	b	0x2838 <perf_unwind_ruby+0x2838>
    2e00:      	ldr	w8, [x23]
    2e04:      	lsr	w8, w8, #9
    2e08:      	cmp	w8, #0x103
    2e0c:      	b.hs	0x2fb4 <perf_unwind_ruby+0x2fb4>
    2e10:      	ldr	x8, [sp, #0x78]
    2e14:      	ldr	x9, [sp]
    2e18:      	cmp	x9, x8
    2e1c:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    2e20:      	ldrb	w9, [x23, #0x1e]
    2e24:      	str	xzr, [sp, #0x60]
    2e28:      	mov	w20, #0x8               // =8
    2e2c:      	mov	w10, #0x70              // =112
    2e30:      	add	x0, sp, #0x70
    2e34:      	mov	w1, #0x8                // =8
    2e38:      	mov	w24, #0x70              // =112
    2e3c:      	add	x8, x8, x9
    2e40:      	ldrb	w9, [x23, #0x1c]
    2e44:      	stp	xzr, x8, [sp, #0x70]
    2e48:      	add	x8, x8, x9
    2e4c:      	add	x9, sp, #0x70
    2e50:      	ldr	x8, [sp, #0x78]
    2e54:      	ldrb	w9, [x23, #0x1c]
    2e58:      	add	x2, x8, x9
    2e5c:      	blr	x10
    2e60:      	ldr	x8, [sp, #0x78]
    2e64:      	ldrb	w9, [x23, #0x1b]
    2e68:      	add	x0, sp, #0x60
    2e6c:      	mov	w1, #0x8                // =8
    2e70:      	add	x8, x8, x9
    2e74:      	add	x9, sp, #0x60
    2e78:      	ldr	x8, [sp, #0x78]
    2e7c:      	ldrb	w9, [x23, #0x1b]
    2e80:      	add	x2, x8, x9
    2e84:      	blr	x24
    2e88:      	ldr	x8, [sp, #0x60]
    2e8c:      	cbz	x8, 0x30ec <perf_unwind_ruby+0x30ec>
    2e90:      	ldr	x8, [sp, #0x70]
    2e94:      	cbz	x8, 0x30ec <perf_unwind_ruby+0x30ec>
    2e98:      	ldrb	w9, [x23, #0x1f]
    2e9c:      	mov	w10, #0x70              // =112
    2ea0:      	add	x11, sp, #0x68
    2ea4:      	add	x0, sp, #0x68
    2ea8:      	mov	w1, #0x8                // =8
    2eac:      	add	x8, x8, x9
    2eb0:      	mov	w9, #0x8                // =8
    2eb4:      	ldr	x8, [sp, #0x70]
    2eb8:      	ldrb	w9, [x23, #0x1f]
    2ebc:      	add	x2, x8, x9
    2ec0:      	blr	x10
    2ec4:      	adrp	x25, 0x2000 <perf_unwind_ruby+0x2000>
    2ec8:      	mov	x20, x29
    2ecc:      	ldr	x25, [x25]
    2ed0:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    2ed4:      	ldr	x8, [sp, #0x68]
    2ed8:      	ldrb	w9, [x23, #0x21]
    2edc:      	mov	w10, #0x70              // =112
    2ee0:      	add	x11, sp, #0x58
    2ee4:      	add	x0, sp, #0x58
    2ee8:      	mov	w1, #0x8                // =8
    2eec:      	add	x8, x8, x9
    2ef0:      	mov	w9, #0x8                // =8
    2ef4:      	ldr	x8, [sp, #0x68]
    2ef8:      	ldrb	w9, [x23, #0x21]
    2efc:      	add	x2, x8, x9
    2f00:      	blr	x10
    2f04:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    2f08:      	ldr	x8, [sp, #0x68]
    2f0c:      	ldrb	w9, [x23, #0x22]
    2f10:      	mov	w10, #0x70              // =112
    2f14:      	add	x11, sp, #0x88
    2f18:      	add	x0, sp, #0x88
    2f1c:      	mov	w1, #0x4                // =4
    2f20:      	add	x8, x8, x9
    2f24:      	mov	w9, #0x4                // =4
    2f28:      	ldr	x8, [sp, #0x68]
    2f2c:      	ldrb	w9, [x23, #0x22]
    2f30:      	add	x2, x8, x9
    2f34:      	blr	x10
    2f38:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    2f3c:      	ldrb	w9, [x23, #0x23]
    2f40:      	ldr	x8, [sp, #0x60]
    2f44:      	cbz	x9, 0x3640 <perf_unwind_ruby+0x3640>
    2f48:      	ldr	x10, [sp, #0x58]
    2f4c:      	sub	x10, x8, x10
    2f50:      	udiv	x9, x10, x9
    2f54:      	ldr	w10, [sp, #0x88]
    2f58:      	cmp	x9, x10
    2f5c:      	b.ls	0x3640 <perf_unwind_ruby+0x3640>
    2f60:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    2f64:      	ldr	x8, [x8]
    2f68:      	ldr	w8, [x8]
    2f6c:      	cbz	w8, 0x30fc <perf_unwind_ruby+0x30fc>
    2f70:      	adrp	x8, 0x2000 <perf_unwind_ruby+0x2000>
    2f74:      	add	x8, x8, #0x0
    2f78:      	add	x0, sp, #0x8
    2f7c:      	ldp	x9, x10, [x8, #0x10]
    2f80:      	mov	w1, #0x2d               // =45
    2f84:      	stp	x9, x10, [sp, #0x18]
    2f88:      	ldr	x9, [x8, #0x20]
    2f8c:      	add	x10, sp, #0x8
    2f90:      	str	x9, [sp, #0x28]
    2f94:      	ldur	x9, [x8, #0x25]
    2f98:      	stur	x9, [sp, #0x2d]
    2f9c:      	ldp	x9, x8, [x8]
    2fa0:      	stp	x9, x8, [sp, #0x8]
    2fa4:      	mov	w8, #0x2d               // =45
    2fa8:      	mov	w9, #0x6                // =6
    2fac:      	blr	x9
    2fb0:      	b	0x30fc <perf_unwind_ruby+0x30fc>
    2fb4:      	ldr	x8, [sp, #0x78]
    2fb8:      	ldrb	w9, [x23, #0x1d]
    2fbc:      	mov	w10, #0x70              // =112
    2fc0:      	add	x11, sp, #0x50
    2fc4:      	add	x0, sp, #0x50
    2fc8:      	mov	w1, #0x8                // =8
    2fcc:      	str	xzr, [sp, #0x50]
    2fd0:      	add	x8, x8, x9
    2fd4:      	mov	w9, #0x8                // =8
    2fd8:      	ldr	x8, [sp, #0x78]
    2fdc:      	ldrb	w9, [x23, #0x1d]
    2fe0:      	add	x2, x8, x9
    2fe4:      	blr	x10
    2fe8:      	adrp	x25, 0x2000 <perf_unwind_ruby+0x2000>
    2fec:      	mov	x20, x29
    2ff0:      	ldr	x25, [x25]
    2ff4:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    2ff8:      	ldr	w8, [sp, #0x50]
    2ffc:      	mov	w9, #0x140              // =320
    3000:      	mvn	w8, w8
    3004:      	tst	x8, x9
    3008:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    300c:      	b	0x2e10 <perf_unwind_ruby+0x2e10>
    3010:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    3014:      	ldr	x8, [x8]
    3018:      	ldr	w8, [x8]
    301c:      	cbz	w8, 0x2838 <perf_unwind_ruby+0x2838>
    3020:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    3024:      	add	x8, x8, #0x0
    3028:      	add	x0, sp, #0x8
    302c:      	ldp	x9, x10, [x8, #0x10]
    3030:      	mov	w1, #0x2e               // =46
    3034:      	stp	x9, x10, [sp, #0x18]
    3038:      	ldr	x9, [x8, #0x20]
    303c:      	add	x10, sp, #0x8
    3040:      	str	x9, [sp, #0x28]
    3044:      	ldur	x9, [x8, #0x26]
    3048:      	stur	x9, [sp, #0x2e]
    304c:      	ldp	x9, x8, [x8]
    3050:      	stp	x9, x8, [sp, #0x8]
    3054:      	mov	w8, #0x2e               // =46
    3058:      	mov	w9, #0x6                // =6
    305c:      	ldr	w2, [sp, #0x50]
    3060:      	blr	x9
    3064:      	b	0x2838 <perf_unwind_ruby+0x2838>
    3068:      	ldr	w9, [x22, #0x2c0]
    306c:      	adrp	x25, 0x3000 <perf_unwind_ruby+0x3000>
    3070:      	ldr	x25, [x25]
    3074:      	cmp	w9, #0x7e
    3078:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    307c:      	ldr	x10, [sp, #0x68]
    3080:      	add	w11, w9, #0x1
    3084:      	str	wzr, [sp, #0x50]
    3088:      	mov	x0, x29
    308c:      	add	x1, sp, #0x50
    3090:      	strh	wzr, [sp, #0x54]
    3094:      	str	w11, [x22, #0x2c0]
    3098:      	mov	w11, #0x18              // =24
    309c:      	umaddl	x9, w9, w11, x22
    30a0:      	str	x10, [x9, #0x2d0]
    30a4:      	mov	w10, #0x6               // =6
    30a8:      	str	x8, [x9, #0x2d8]
    30ac:      	add	x8, x9, #0x2d0
    30b0:      	strh	w10, [x9, #0x2e0]
    30b4:      	ldr	w11, [sp, #0x50]
    30b8:      	ldrh	w10, [sp, #0x54]
    30bc:      	stur	w11, [x8, #0x12]
    30c0:      	mov	w8, #0x36               // =54
    30c4:      	strh	w10, [x9, #0x2e6]
    30c8:      	add	x9, sp, #0x50
    30cc:      	str	w8, [sp, #0x50]
    30d0:      	mov	w8, #0x1                // =1
    30d4:      	blr	x8
    30d8:      	cbz	x0, 0x32fc <perf_unwind_ruby+0x32fc>
    30dc:      	ldr	x8, [x0]
    30e0:      	add	x8, x8, #0x1
    30e4:      	str	x8, [x0]
    30e8:      	b	0x2b24 <perf_unwind_ruby+0x2b24>
    30ec:      	ldr	w8, [x23]
    30f0:      	lsr	w8, w8, #9
    30f4:      	cmp	w8, #0x103
    30f8:      	b.hs	0x32a0 <perf_unwind_ruby+0x32a0>
    30fc:      	ldr	x8, [sp, #0x78]
    3100:      	ldr	x9, [sp]
    3104:      	cmp	x9, x8
    3108:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    310c:      	ldrb	w9, [x23, #0x1e]
    3110:      	str	xzr, [sp, #0x60]
    3114:      	mov	w20, #0x8               // =8
    3118:      	mov	w10, #0x70              // =112
    311c:      	add	x0, sp, #0x70
    3120:      	mov	w1, #0x8                // =8
    3124:      	mov	w24, #0x70              // =112
    3128:      	add	x8, x8, x9
    312c:      	ldrb	w9, [x23, #0x1c]
    3130:      	stp	xzr, x8, [sp, #0x70]
    3134:      	add	x8, x8, x9
    3138:      	add	x9, sp, #0x70
    313c:      	ldr	x8, [sp, #0x78]
    3140:      	ldrb	w9, [x23, #0x1c]
    3144:      	add	x2, x8, x9
    3148:      	blr	x10
    314c:      	ldr	x8, [sp, #0x78]
    3150:      	ldrb	w9, [x23, #0x1b]
    3154:      	add	x0, sp, #0x60
    3158:      	mov	w1, #0x8                // =8
    315c:      	add	x8, x8, x9
    3160:      	add	x9, sp, #0x60
    3164:      	ldr	x8, [sp, #0x78]
    3168:      	ldrb	w9, [x23, #0x1b]
    316c:      	add	x2, x8, x9
    3170:      	blr	x24
    3174:      	ldr	x8, [sp, #0x60]
    3178:      	cbz	x8, 0x33d8 <perf_unwind_ruby+0x33d8>
    317c:      	ldr	x8, [sp, #0x70]
    3180:      	cbz	x8, 0x33d8 <perf_unwind_ruby+0x33d8>
    3184:      	ldrb	w9, [x23, #0x1f]
    3188:      	mov	w10, #0x70              // =112
    318c:      	add	x11, sp, #0x68
    3190:      	add	x0, sp, #0x68
    3194:      	mov	w1, #0x8                // =8
    3198:      	add	x8, x8, x9
    319c:      	mov	w9, #0x8                // =8
    31a0:      	ldr	x8, [sp, #0x70]
    31a4:      	ldrb	w9, [x23, #0x1f]
    31a8:      	add	x2, x8, x9
    31ac:      	blr	x10
    31b0:      	adrp	x25, 0x3000 <perf_unwind_ruby+0x3000>
    31b4:      	mov	x20, x29
    31b8:      	ldr	x25, [x25]
    31bc:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    31c0:      	ldr	x8, [sp, #0x68]
    31c4:      	ldrb	w9, [x23, #0x21]
    31c8:      	mov	w10, #0x70              // =112
    31cc:      	add	x11, sp, #0x58
    31d0:      	add	x0, sp, #0x58
    31d4:      	mov	w1, #0x8                // =8
    31d8:      	add	x8, x8, x9
    31dc:      	mov	w9, #0x8                // =8
    31e0:      	ldr	x8, [sp, #0x68]
    31e4:      	ldrb	w9, [x23, #0x21]
    31e8:      	add	x2, x8, x9
    31ec:      	blr	x10
    31f0:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    31f4:      	ldr	x8, [sp, #0x68]
    31f8:      	ldrb	w9, [x23, #0x22]
    31fc:      	mov	w10, #0x70              // =112
    3200:      	add	x11, sp, #0x88
    3204:      	add	x0, sp, #0x88
    3208:      	mov	w1, #0x4                // =4
    320c:      	add	x8, x8, x9
    3210:      	mov	w9, #0x4                // =4
    3214:      	ldr	x8, [sp, #0x68]
    3218:      	ldrb	w9, [x23, #0x22]
    321c:      	add	x2, x8, x9
    3220:      	blr	x10
    3224:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    3228:      	ldrb	w9, [x23, #0x23]
    322c:      	ldr	x8, [sp, #0x60]
    3230:      	cbz	x9, 0x392c <perf_unwind_ruby+0x392c>
    3234:      	ldr	x10, [sp, #0x58]
    3238:      	sub	x10, x8, x10
    323c:      	udiv	x9, x10, x9
    3240:      	ldr	w10, [sp, #0x88]
    3244:      	cmp	x9, x10
    3248:      	b.ls	0x392c <perf_unwind_ruby+0x392c>
    324c:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    3250:      	ldr	x8, [x8]
    3254:      	ldr	w8, [x8]
    3258:      	cbz	w8, 0x33e8 <perf_unwind_ruby+0x33e8>
    325c:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    3260:      	add	x8, x8, #0x0
    3264:      	add	x0, sp, #0x8
    3268:      	ldp	x9, x10, [x8, #0x10]
    326c:      	mov	w1, #0x2d               // =45
    3270:      	stp	x9, x10, [sp, #0x18]
    3274:      	ldr	x9, [x8, #0x20]
    3278:      	add	x10, sp, #0x8
    327c:      	str	x9, [sp, #0x28]
    3280:      	ldur	x9, [x8, #0x25]
    3284:      	stur	x9, [sp, #0x2d]
    3288:      	ldp	x9, x8, [x8]
    328c:      	stp	x9, x8, [sp, #0x8]
    3290:      	mov	w8, #0x2d               // =45
    3294:      	mov	w9, #0x6                // =6
    3298:      	blr	x9
    329c:      	b	0x33e8 <perf_unwind_ruby+0x33e8>
    32a0:      	ldr	x8, [sp, #0x78]
    32a4:      	ldrb	w9, [x23, #0x1d]
    32a8:      	mov	w10, #0x70              // =112
    32ac:      	add	x11, sp, #0x50
    32b0:      	add	x0, sp, #0x50
    32b4:      	mov	w1, #0x8                // =8
    32b8:      	str	xzr, [sp, #0x50]
    32bc:      	add	x8, x8, x9
    32c0:      	mov	w9, #0x8                // =8
    32c4:      	ldr	x8, [sp, #0x78]
    32c8:      	ldrb	w9, [x23, #0x1d]
    32cc:      	add	x2, x8, x9
    32d0:      	blr	x10
    32d4:      	adrp	x25, 0x3000 <perf_unwind_ruby+0x3000>
    32d8:      	mov	x20, x29
    32dc:      	ldr	x25, [x25]
    32e0:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    32e4:      	ldr	w8, [sp, #0x50]
    32e8:      	mov	w9, #0x140              // =320
    32ec:      	mvn	w8, w8
    32f0:      	tst	x8, x9
    32f4:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    32f8:      	b	0x30fc <perf_unwind_ruby+0x30fc>
    32fc:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    3300:      	ldr	x8, [x8]
    3304:      	ldr	w8, [x8]
    3308:      	cbz	w8, 0x2b24 <perf_unwind_ruby+0x2b24>
    330c:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    3310:      	add	x8, x8, #0x0
    3314:      	add	x0, sp, #0x8
    3318:      	ldp	x9, x10, [x8, #0x10]
    331c:      	mov	w1, #0x2e               // =46
    3320:      	stp	x9, x10, [sp, #0x18]
    3324:      	ldr	x9, [x8, #0x20]
    3328:      	add	x10, sp, #0x8
    332c:      	str	x9, [sp, #0x28]
    3330:      	ldur	x9, [x8, #0x26]
    3334:      	stur	x9, [sp, #0x2e]
    3338:      	ldp	x9, x8, [x8]
    333c:      	stp	x9, x8, [sp, #0x8]
    3340:      	mov	w8, #0x2e               // =46
    3344:      	mov	w9, #0x6                // =6
    3348:      	ldr	w2, [sp, #0x50]
    334c:      	blr	x9
    3350:      	b	0x2b24 <perf_unwind_ruby+0x2b24>
    3354:      	ldr	w9, [x22, #0x2c0]
    3358:      	adrp	x25, 0x3000 <perf_unwind_ruby+0x3000>
    335c:      	ldr	x25, [x25]
    3360:      	cmp	w9, #0x7e
    3364:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    3368:      	ldr	x10, [sp, #0x68]
    336c:      	add	w11, w9, #0x1
    3370:      	str	wzr, [sp, #0x50]
    3374:      	mov	x0, x29
    3378:      	add	x1, sp, #0x50
    337c:      	strh	wzr, [sp, #0x54]
    3380:      	str	w11, [x22, #0x2c0]
    3384:      	mov	w11, #0x18              // =24
    3388:      	umaddl	x9, w9, w11, x22
    338c:      	str	x10, [x9, #0x2d0]
    3390:      	mov	w10, #0x6               // =6
    3394:      	str	x8, [x9, #0x2d8]
    3398:      	add	x8, x9, #0x2d0
    339c:      	strh	w10, [x9, #0x2e0]
    33a0:      	ldr	w11, [sp, #0x50]
    33a4:      	ldrh	w10, [sp, #0x54]
    33a8:      	stur	w11, [x8, #0x12]
    33ac:      	mov	w8, #0x36               // =54
    33b0:      	strh	w10, [x9, #0x2e6]
    33b4:      	add	x9, sp, #0x50
    33b8:      	str	w8, [sp, #0x50]
    33bc:      	mov	w8, #0x1                // =1
    33c0:      	blr	x8
    33c4:      	cbz	x0, 0x35e8 <perf_unwind_ruby+0x35e8>
    33c8:      	ldr	x8, [x0]
    33cc:      	add	x8, x8, #0x1
    33d0:      	str	x8, [x0]
    33d4:      	b	0x2e10 <perf_unwind_ruby+0x2e10>
    33d8:      	ldr	w8, [x23]
    33dc:      	lsr	w8, w8, #9
    33e0:      	cmp	w8, #0x103
    33e4:      	b.hs	0x358c <perf_unwind_ruby+0x358c>
    33e8:      	ldr	x8, [sp, #0x78]
    33ec:      	ldr	x9, [sp]
    33f0:      	cmp	x9, x8
    33f4:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    33f8:      	ldrb	w9, [x23, #0x1e]
    33fc:      	str	xzr, [sp, #0x60]
    3400:      	mov	w20, #0x8               // =8
    3404:      	mov	w10, #0x70              // =112
    3408:      	add	x0, sp, #0x70
    340c:      	mov	w1, #0x8                // =8
    3410:      	mov	w24, #0x70              // =112
    3414:      	add	x8, x8, x9
    3418:      	ldrb	w9, [x23, #0x1c]
    341c:      	stp	xzr, x8, [sp, #0x70]
    3420:      	add	x8, x8, x9
    3424:      	add	x9, sp, #0x70
    3428:      	ldr	x8, [sp, #0x78]
    342c:      	ldrb	w9, [x23, #0x1c]
    3430:      	add	x2, x8, x9
    3434:      	blr	x10
    3438:      	ldr	x8, [sp, #0x78]
    343c:      	ldrb	w9, [x23, #0x1b]
    3440:      	add	x0, sp, #0x60
    3444:      	mov	w1, #0x8                // =8
    3448:      	add	x8, x8, x9
    344c:      	add	x9, sp, #0x60
    3450:      	ldr	x8, [sp, #0x78]
    3454:      	ldrb	w9, [x23, #0x1b]
    3458:      	add	x2, x8, x9
    345c:      	blr	x24
    3460:      	ldr	x8, [sp, #0x60]
    3464:      	cbz	x8, 0x36c4 <perf_unwind_ruby+0x36c4>
    3468:      	ldr	x8, [sp, #0x70]
    346c:      	cbz	x8, 0x36c4 <perf_unwind_ruby+0x36c4>
    3470:      	ldrb	w9, [x23, #0x1f]
    3474:      	mov	w10, #0x70              // =112
    3478:      	add	x11, sp, #0x68
    347c:      	add	x0, sp, #0x68
    3480:      	mov	w1, #0x8                // =8
    3484:      	add	x8, x8, x9
    3488:      	mov	w9, #0x8                // =8
    348c:      	ldr	x8, [sp, #0x70]
    3490:      	ldrb	w9, [x23, #0x1f]
    3494:      	add	x2, x8, x9
    3498:      	blr	x10
    349c:      	adrp	x25, 0x3000 <perf_unwind_ruby+0x3000>
    34a0:      	mov	x20, x29
    34a4:      	ldr	x25, [x25]
    34a8:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    34ac:      	ldr	x8, [sp, #0x68]
    34b0:      	ldrb	w9, [x23, #0x21]
    34b4:      	mov	w10, #0x70              // =112
    34b8:      	add	x11, sp, #0x58
    34bc:      	add	x0, sp, #0x58
    34c0:      	mov	w1, #0x8                // =8
    34c4:      	add	x8, x8, x9
    34c8:      	mov	w9, #0x8                // =8
    34cc:      	ldr	x8, [sp, #0x68]
    34d0:      	ldrb	w9, [x23, #0x21]
    34d4:      	add	x2, x8, x9
    34d8:      	blr	x10
    34dc:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    34e0:      	ldr	x8, [sp, #0x68]
    34e4:      	ldrb	w9, [x23, #0x22]
    34e8:      	mov	w10, #0x70              // =112
    34ec:      	add	x11, sp, #0x88
    34f0:      	add	x0, sp, #0x88
    34f4:      	mov	w1, #0x4                // =4
    34f8:      	add	x8, x8, x9
    34fc:      	mov	w9, #0x4                // =4
    3500:      	ldr	x8, [sp, #0x68]
    3504:      	ldrb	w9, [x23, #0x22]
    3508:      	add	x2, x8, x9
    350c:      	blr	x10
    3510:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    3514:      	ldrb	w9, [x23, #0x23]
    3518:      	ldr	x8, [sp, #0x60]
    351c:      	cbz	x9, 0x3c18 <perf_unwind_ruby+0x3c18>
    3520:      	ldr	x10, [sp, #0x58]
    3524:      	sub	x10, x8, x10
    3528:      	udiv	x9, x10, x9
    352c:      	ldr	w10, [sp, #0x88]
    3530:      	cmp	x9, x10
    3534:      	b.ls	0x3c18 <perf_unwind_ruby+0x3c18>
    3538:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    353c:      	ldr	x8, [x8]
    3540:      	ldr	w8, [x8]
    3544:      	cbz	w8, 0x36d4 <perf_unwind_ruby+0x36d4>
    3548:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    354c:      	add	x8, x8, #0x0
    3550:      	add	x0, sp, #0x8
    3554:      	ldp	x9, x10, [x8, #0x10]
    3558:      	mov	w1, #0x2d               // =45
    355c:      	stp	x9, x10, [sp, #0x18]
    3560:      	ldr	x9, [x8, #0x20]
    3564:      	add	x10, sp, #0x8
    3568:      	str	x9, [sp, #0x28]
    356c:      	ldur	x9, [x8, #0x25]
    3570:      	stur	x9, [sp, #0x2d]
    3574:      	ldp	x9, x8, [x8]
    3578:      	stp	x9, x8, [sp, #0x8]
    357c:      	mov	w8, #0x2d               // =45
    3580:      	mov	w9, #0x6                // =6
    3584:      	blr	x9
    3588:      	b	0x36d4 <perf_unwind_ruby+0x36d4>
    358c:      	ldr	x8, [sp, #0x78]
    3590:      	ldrb	w9, [x23, #0x1d]
    3594:      	mov	w10, #0x70              // =112
    3598:      	add	x11, sp, #0x50
    359c:      	add	x0, sp, #0x50
    35a0:      	mov	w1, #0x8                // =8
    35a4:      	str	xzr, [sp, #0x50]
    35a8:      	add	x8, x8, x9
    35ac:      	mov	w9, #0x8                // =8
    35b0:      	ldr	x8, [sp, #0x78]
    35b4:      	ldrb	w9, [x23, #0x1d]
    35b8:      	add	x2, x8, x9
    35bc:      	blr	x10
    35c0:      	adrp	x25, 0x3000 <perf_unwind_ruby+0x3000>
    35c4:      	mov	x20, x29
    35c8:      	ldr	x25, [x25]
    35cc:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    35d0:      	ldr	w8, [sp, #0x50]
    35d4:      	mov	w9, #0x140              // =320
    35d8:      	mvn	w8, w8
    35dc:      	tst	x8, x9
    35e0:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    35e4:      	b	0x33e8 <perf_unwind_ruby+0x33e8>
    35e8:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    35ec:      	ldr	x8, [x8]
    35f0:      	ldr	w8, [x8]
    35f4:      	cbz	w8, 0x2e10 <perf_unwind_ruby+0x2e10>
    35f8:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    35fc:      	add	x8, x8, #0x0
    3600:      	add	x0, sp, #0x8
    3604:      	ldp	x9, x10, [x8, #0x10]
    3608:      	mov	w1, #0x2e               // =46
    360c:      	stp	x9, x10, [sp, #0x18]
    3610:      	ldr	x9, [x8, #0x20]
    3614:      	add	x10, sp, #0x8
    3618:      	str	x9, [sp, #0x28]
    361c:      	ldur	x9, [x8, #0x26]
    3620:      	stur	x9, [sp, #0x2e]
    3624:      	ldp	x9, x8, [x8]
    3628:      	stp	x9, x8, [sp, #0x8]
    362c:      	mov	w8, #0x2e               // =46
    3630:      	mov	w9, #0x6                // =6
    3634:      	ldr	w2, [sp, #0x50]
    3638:      	blr	x9
    363c:      	b	0x2e10 <perf_unwind_ruby+0x2e10>
    3640:      	ldr	w9, [x22, #0x2c0]
    3644:      	adrp	x25, 0x3000 <perf_unwind_ruby+0x3000>
    3648:      	ldr	x25, [x25]
    364c:      	cmp	w9, #0x7e
    3650:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    3654:      	ldr	x10, [sp, #0x68]
    3658:      	add	w11, w9, #0x1
    365c:      	str	wzr, [sp, #0x50]
    3660:      	mov	x0, x29
    3664:      	add	x1, sp, #0x50
    3668:      	strh	wzr, [sp, #0x54]
    366c:      	str	w11, [x22, #0x2c0]
    3670:      	mov	w11, #0x18              // =24
    3674:      	umaddl	x9, w9, w11, x22
    3678:      	str	x10, [x9, #0x2d0]
    367c:      	mov	w10, #0x6               // =6
    3680:      	str	x8, [x9, #0x2d8]
    3684:      	add	x8, x9, #0x2d0
    3688:      	strh	w10, [x9, #0x2e0]
    368c:      	ldr	w11, [sp, #0x50]
    3690:      	ldrh	w10, [sp, #0x54]
    3694:      	stur	w11, [x8, #0x12]
    3698:      	mov	w8, #0x36               // =54
    369c:      	strh	w10, [x9, #0x2e6]
    36a0:      	add	x9, sp, #0x50
    36a4:      	str	w8, [sp, #0x50]
    36a8:      	mov	w8, #0x1                // =1
    36ac:      	blr	x8
    36b0:      	cbz	x0, 0x38d4 <perf_unwind_ruby+0x38d4>
    36b4:      	ldr	x8, [x0]
    36b8:      	add	x8, x8, #0x1
    36bc:      	str	x8, [x0]
    36c0:      	b	0x30fc <perf_unwind_ruby+0x30fc>
    36c4:      	ldr	w8, [x23]
    36c8:      	lsr	w8, w8, #9
    36cc:      	cmp	w8, #0x103
    36d0:      	b.hs	0x3878 <perf_unwind_ruby+0x3878>
    36d4:      	ldr	x8, [sp, #0x78]
    36d8:      	ldr	x9, [sp]
    36dc:      	cmp	x9, x8
    36e0:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    36e4:      	ldrb	w9, [x23, #0x1e]
    36e8:      	str	xzr, [sp, #0x60]
    36ec:      	mov	w20, #0x8               // =8
    36f0:      	mov	w10, #0x70              // =112
    36f4:      	add	x0, sp, #0x70
    36f8:      	mov	w1, #0x8                // =8
    36fc:      	mov	w24, #0x70              // =112
    3700:      	add	x8, x8, x9
    3704:      	ldrb	w9, [x23, #0x1c]
    3708:      	stp	xzr, x8, [sp, #0x70]
    370c:      	add	x8, x8, x9
    3710:      	add	x9, sp, #0x70
    3714:      	ldr	x8, [sp, #0x78]
    3718:      	ldrb	w9, [x23, #0x1c]
    371c:      	add	x2, x8, x9
    3720:      	blr	x10
    3724:      	ldr	x8, [sp, #0x78]
    3728:      	ldrb	w9, [x23, #0x1b]
    372c:      	add	x0, sp, #0x60
    3730:      	mov	w1, #0x8                // =8
    3734:      	add	x8, x8, x9
    3738:      	add	x9, sp, #0x60
    373c:      	ldr	x8, [sp, #0x78]
    3740:      	ldrb	w9, [x23, #0x1b]
    3744:      	add	x2, x8, x9
    3748:      	blr	x24
    374c:      	ldr	x8, [sp, #0x60]
    3750:      	cbz	x8, 0x39b0 <perf_unwind_ruby+0x39b0>
    3754:      	ldr	x8, [sp, #0x70]
    3758:      	cbz	x8, 0x39b0 <perf_unwind_ruby+0x39b0>
    375c:      	ldrb	w9, [x23, #0x1f]
    3760:      	mov	w10, #0x70              // =112
    3764:      	add	x11, sp, #0x68
    3768:      	add	x0, sp, #0x68
    376c:      	mov	w1, #0x8                // =8
    3770:      	add	x8, x8, x9
    3774:      	mov	w9, #0x8                // =8
    3778:      	ldr	x8, [sp, #0x70]
    377c:      	ldrb	w9, [x23, #0x1f]
    3780:      	add	x2, x8, x9
    3784:      	blr	x10
    3788:      	adrp	x25, 0x3000 <perf_unwind_ruby+0x3000>
    378c:      	mov	x20, x29
    3790:      	ldr	x25, [x25]
    3794:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    3798:      	ldr	x8, [sp, #0x68]
    379c:      	ldrb	w9, [x23, #0x21]
    37a0:      	mov	w10, #0x70              // =112
    37a4:      	add	x11, sp, #0x58
    37a8:      	add	x0, sp, #0x58
    37ac:      	mov	w1, #0x8                // =8
    37b0:      	add	x8, x8, x9
    37b4:      	mov	w9, #0x8                // =8
    37b8:      	ldr	x8, [sp, #0x68]
    37bc:      	ldrb	w9, [x23, #0x21]
    37c0:      	add	x2, x8, x9
    37c4:      	blr	x10
    37c8:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    37cc:      	ldr	x8, [sp, #0x68]
    37d0:      	ldrb	w9, [x23, #0x22]
    37d4:      	mov	w10, #0x70              // =112
    37d8:      	add	x11, sp, #0x88
    37dc:      	add	x0, sp, #0x88
    37e0:      	mov	w1, #0x4                // =4
    37e4:      	add	x8, x8, x9
    37e8:      	mov	w9, #0x4                // =4
    37ec:      	ldr	x8, [sp, #0x68]
    37f0:      	ldrb	w9, [x23, #0x22]
    37f4:      	add	x2, x8, x9
    37f8:      	blr	x10
    37fc:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    3800:      	ldrb	w9, [x23, #0x23]
    3804:      	ldr	x8, [sp, #0x60]
    3808:      	cbz	x9, 0x3f04 <perf_unwind_ruby+0x3f04>
    380c:      	ldr	x10, [sp, #0x58]
    3810:      	sub	x10, x8, x10
    3814:      	udiv	x9, x10, x9
    3818:      	ldr	w10, [sp, #0x88]
    381c:      	cmp	x9, x10
    3820:      	b.ls	0x3f04 <perf_unwind_ruby+0x3f04>
    3824:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    3828:      	ldr	x8, [x8]
    382c:      	ldr	w8, [x8]
    3830:      	cbz	w8, 0x39c0 <perf_unwind_ruby+0x39c0>
    3834:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    3838:      	add	x8, x8, #0x0
    383c:      	add	x0, sp, #0x8
    3840:      	ldp	x9, x10, [x8, #0x10]
    3844:      	mov	w1, #0x2d               // =45
    3848:      	stp	x9, x10, [sp, #0x18]
    384c:      	ldr	x9, [x8, #0x20]
    3850:      	add	x10, sp, #0x8
    3854:      	str	x9, [sp, #0x28]
    3858:      	ldur	x9, [x8, #0x25]
    385c:      	stur	x9, [sp, #0x2d]
    3860:      	ldp	x9, x8, [x8]
    3864:      	stp	x9, x8, [sp, #0x8]
    3868:      	mov	w8, #0x2d               // =45
    386c:      	mov	w9, #0x6                // =6
    3870:      	blr	x9
    3874:      	b	0x39c0 <perf_unwind_ruby+0x39c0>
    3878:      	ldr	x8, [sp, #0x78]
    387c:      	ldrb	w9, [x23, #0x1d]
    3880:      	mov	w10, #0x70              // =112
    3884:      	add	x11, sp, #0x50
    3888:      	add	x0, sp, #0x50
    388c:      	mov	w1, #0x8                // =8
    3890:      	str	xzr, [sp, #0x50]
    3894:      	add	x8, x8, x9
    3898:      	mov	w9, #0x8                // =8
    389c:      	ldr	x8, [sp, #0x78]
    38a0:      	ldrb	w9, [x23, #0x1d]
    38a4:      	add	x2, x8, x9
    38a8:      	blr	x10
    38ac:      	adrp	x25, 0x3000 <perf_unwind_ruby+0x3000>
    38b0:      	mov	x20, x29
    38b4:      	ldr	x25, [x25]
    38b8:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    38bc:      	ldr	w8, [sp, #0x50]
    38c0:      	mov	w9, #0x140              // =320
    38c4:      	mvn	w8, w8
    38c8:      	tst	x8, x9
    38cc:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    38d0:      	b	0x36d4 <perf_unwind_ruby+0x36d4>
    38d4:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    38d8:      	ldr	x8, [x8]
    38dc:      	ldr	w8, [x8]
    38e0:      	cbz	w8, 0x30fc <perf_unwind_ruby+0x30fc>
    38e4:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    38e8:      	add	x8, x8, #0x0
    38ec:      	add	x0, sp, #0x8
    38f0:      	ldp	x9, x10, [x8, #0x10]
    38f4:      	mov	w1, #0x2e               // =46
    38f8:      	stp	x9, x10, [sp, #0x18]
    38fc:      	ldr	x9, [x8, #0x20]
    3900:      	add	x10, sp, #0x8
    3904:      	str	x9, [sp, #0x28]
    3908:      	ldur	x9, [x8, #0x26]
    390c:      	stur	x9, [sp, #0x2e]
    3910:      	ldp	x9, x8, [x8]
    3914:      	stp	x9, x8, [sp, #0x8]
    3918:      	mov	w8, #0x2e               // =46
    391c:      	mov	w9, #0x6                // =6
    3920:      	ldr	w2, [sp, #0x50]
    3924:      	blr	x9
    3928:      	b	0x30fc <perf_unwind_ruby+0x30fc>
    392c:      	ldr	w9, [x22, #0x2c0]
    3930:      	adrp	x25, 0x3000 <perf_unwind_ruby+0x3000>
    3934:      	ldr	x25, [x25]
    3938:      	cmp	w9, #0x7e
    393c:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    3940:      	ldr	x10, [sp, #0x68]
    3944:      	add	w11, w9, #0x1
    3948:      	str	wzr, [sp, #0x50]
    394c:      	mov	x0, x29
    3950:      	add	x1, sp, #0x50
    3954:      	strh	wzr, [sp, #0x54]
    3958:      	str	w11, [x22, #0x2c0]
    395c:      	mov	w11, #0x18              // =24
    3960:      	umaddl	x9, w9, w11, x22
    3964:      	str	x10, [x9, #0x2d0]
    3968:      	mov	w10, #0x6               // =6
    396c:      	str	x8, [x9, #0x2d8]
    3970:      	add	x8, x9, #0x2d0
    3974:      	strh	w10, [x9, #0x2e0]
    3978:      	ldr	w11, [sp, #0x50]
    397c:      	ldrh	w10, [sp, #0x54]
    3980:      	stur	w11, [x8, #0x12]
    3984:      	mov	w8, #0x36               // =54
    3988:      	strh	w10, [x9, #0x2e6]
    398c:      	add	x9, sp, #0x50
    3990:      	str	w8, [sp, #0x50]
    3994:      	mov	w8, #0x1                // =1
    3998:      	blr	x8
    399c:      	cbz	x0, 0x3bc0 <perf_unwind_ruby+0x3bc0>
    39a0:      	ldr	x8, [x0]
    39a4:      	add	x8, x8, #0x1
    39a8:      	str	x8, [x0]
    39ac:      	b	0x33e8 <perf_unwind_ruby+0x33e8>
    39b0:      	ldr	w8, [x23]
    39b4:      	lsr	w8, w8, #9
    39b8:      	cmp	w8, #0x103
    39bc:      	b.hs	0x3b64 <perf_unwind_ruby+0x3b64>
    39c0:      	ldr	x8, [sp, #0x78]
    39c4:      	ldr	x9, [sp]
    39c8:      	cmp	x9, x8
    39cc:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    39d0:      	ldrb	w9, [x23, #0x1e]
    39d4:      	str	xzr, [sp, #0x60]
    39d8:      	mov	w20, #0x8               // =8
    39dc:      	mov	w10, #0x70              // =112
    39e0:      	add	x0, sp, #0x70
    39e4:      	mov	w1, #0x8                // =8
    39e8:      	mov	w24, #0x70              // =112
    39ec:      	add	x8, x8, x9
    39f0:      	ldrb	w9, [x23, #0x1c]
    39f4:      	stp	xzr, x8, [sp, #0x70]
    39f8:      	add	x8, x8, x9
    39fc:      	add	x9, sp, #0x70
    3a00:      	ldr	x8, [sp, #0x78]
    3a04:      	ldrb	w9, [x23, #0x1c]
    3a08:      	add	x2, x8, x9
    3a0c:      	blr	x10
    3a10:      	ldr	x8, [sp, #0x78]
    3a14:      	ldrb	w9, [x23, #0x1b]
    3a18:      	add	x0, sp, #0x60
    3a1c:      	mov	w1, #0x8                // =8
    3a20:      	add	x8, x8, x9
    3a24:      	add	x9, sp, #0x60
    3a28:      	ldr	x8, [sp, #0x78]
    3a2c:      	ldrb	w9, [x23, #0x1b]
    3a30:      	add	x2, x8, x9
    3a34:      	blr	x24
    3a38:      	ldr	x8, [sp, #0x60]
    3a3c:      	cbz	x8, 0x3c9c <perf_unwind_ruby+0x3c9c>
    3a40:      	ldr	x8, [sp, #0x70]
    3a44:      	cbz	x8, 0x3c9c <perf_unwind_ruby+0x3c9c>
    3a48:      	ldrb	w9, [x23, #0x1f]
    3a4c:      	mov	w10, #0x70              // =112
    3a50:      	add	x11, sp, #0x68
    3a54:      	add	x0, sp, #0x68
    3a58:      	mov	w1, #0x8                // =8
    3a5c:      	add	x8, x8, x9
    3a60:      	mov	w9, #0x8                // =8
    3a64:      	ldr	x8, [sp, #0x70]
    3a68:      	ldrb	w9, [x23, #0x1f]
    3a6c:      	add	x2, x8, x9
    3a70:      	blr	x10
    3a74:      	adrp	x25, 0x3000 <perf_unwind_ruby+0x3000>
    3a78:      	mov	x20, x29
    3a7c:      	ldr	x25, [x25]
    3a80:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    3a84:      	ldr	x8, [sp, #0x68]
    3a88:      	ldrb	w9, [x23, #0x21]
    3a8c:      	mov	w10, #0x70              // =112
    3a90:      	add	x11, sp, #0x58
    3a94:      	add	x0, sp, #0x58
    3a98:      	mov	w1, #0x8                // =8
    3a9c:      	add	x8, x8, x9
    3aa0:      	mov	w9, #0x8                // =8
    3aa4:      	ldr	x8, [sp, #0x68]
    3aa8:      	ldrb	w9, [x23, #0x21]
    3aac:      	add	x2, x8, x9
    3ab0:      	blr	x10
    3ab4:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    3ab8:      	ldr	x8, [sp, #0x68]
    3abc:      	ldrb	w9, [x23, #0x22]
    3ac0:      	mov	w10, #0x70              // =112
    3ac4:      	add	x11, sp, #0x88
    3ac8:      	add	x0, sp, #0x88
    3acc:      	mov	w1, #0x4                // =4
    3ad0:      	add	x8, x8, x9
    3ad4:      	mov	w9, #0x4                // =4
    3ad8:      	ldr	x8, [sp, #0x68]
    3adc:      	ldrb	w9, [x23, #0x22]
    3ae0:      	add	x2, x8, x9
    3ae4:      	blr	x10
    3ae8:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    3aec:      	ldrb	w9, [x23, #0x23]
    3af0:      	ldr	x8, [sp, #0x60]
    3af4:      	cbz	x9, 0x404c <perf_unwind_ruby+0x404c>
    3af8:      	ldr	x10, [sp, #0x58]
    3afc:      	sub	x10, x8, x10
    3b00:      	udiv	x9, x10, x9
    3b04:      	ldr	w10, [sp, #0x88]
    3b08:      	cmp	x9, x10
    3b0c:      	b.ls	0x404c <perf_unwind_ruby+0x404c>
    3b10:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    3b14:      	ldr	x8, [x8]
    3b18:      	ldr	w8, [x8]
    3b1c:      	cbz	w8, 0x3cac <perf_unwind_ruby+0x3cac>
    3b20:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    3b24:      	add	x8, x8, #0x0
    3b28:      	add	x0, sp, #0x8
    3b2c:      	ldp	x9, x10, [x8, #0x10]
    3b30:      	mov	w1, #0x2d               // =45
    3b34:      	stp	x9, x10, [sp, #0x18]
    3b38:      	ldr	x9, [x8, #0x20]
    3b3c:      	add	x10, sp, #0x8
    3b40:      	str	x9, [sp, #0x28]
    3b44:      	ldur	x9, [x8, #0x25]
    3b48:      	stur	x9, [sp, #0x2d]
    3b4c:      	ldp	x9, x8, [x8]
    3b50:      	stp	x9, x8, [sp, #0x8]
    3b54:      	mov	w8, #0x2d               // =45
    3b58:      	mov	w9, #0x6                // =6
    3b5c:      	blr	x9
    3b60:      	b	0x3cac <perf_unwind_ruby+0x3cac>
    3b64:      	ldr	x8, [sp, #0x78]
    3b68:      	ldrb	w9, [x23, #0x1d]
    3b6c:      	mov	w10, #0x70              // =112
    3b70:      	add	x11, sp, #0x50
    3b74:      	add	x0, sp, #0x50
    3b78:      	mov	w1, #0x8                // =8
    3b7c:      	str	xzr, [sp, #0x50]
    3b80:      	add	x8, x8, x9
    3b84:      	mov	w9, #0x8                // =8
    3b88:      	ldr	x8, [sp, #0x78]
    3b8c:      	ldrb	w9, [x23, #0x1d]
    3b90:      	add	x2, x8, x9
    3b94:      	blr	x10
    3b98:      	adrp	x25, 0x3000 <perf_unwind_ruby+0x3000>
    3b9c:      	mov	x20, x29
    3ba0:      	ldr	x25, [x25]
    3ba4:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    3ba8:      	ldr	w8, [sp, #0x50]
    3bac:      	mov	w9, #0x140              // =320
    3bb0:      	mvn	w8, w8
    3bb4:      	tst	x8, x9
    3bb8:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    3bbc:      	b	0x39c0 <perf_unwind_ruby+0x39c0>
    3bc0:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    3bc4:      	ldr	x8, [x8]
    3bc8:      	ldr	w8, [x8]
    3bcc:      	cbz	w8, 0x33e8 <perf_unwind_ruby+0x33e8>
    3bd0:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    3bd4:      	add	x8, x8, #0x0
    3bd8:      	add	x0, sp, #0x8
    3bdc:      	ldp	x9, x10, [x8, #0x10]
    3be0:      	mov	w1, #0x2e               // =46
    3be4:      	stp	x9, x10, [sp, #0x18]
    3be8:      	ldr	x9, [x8, #0x20]
    3bec:      	add	x10, sp, #0x8
    3bf0:      	str	x9, [sp, #0x28]
    3bf4:      	ldur	x9, [x8, #0x26]
    3bf8:      	stur	x9, [sp, #0x2e]
    3bfc:      	ldp	x9, x8, [x8]
    3c00:      	stp	x9, x8, [sp, #0x8]
    3c04:      	mov	w8, #0x2e               // =46
    3c08:      	mov	w9, #0x6                // =6
    3c0c:      	ldr	w2, [sp, #0x50]
    3c10:      	blr	x9
    3c14:      	b	0x33e8 <perf_unwind_ruby+0x33e8>
    3c18:      	ldr	w9, [x22, #0x2c0]
    3c1c:      	adrp	x25, 0x3000 <perf_unwind_ruby+0x3000>
    3c20:      	ldr	x25, [x25]
    3c24:      	cmp	w9, #0x7e
    3c28:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    3c2c:      	ldr	x10, [sp, #0x68]
    3c30:      	add	w11, w9, #0x1
    3c34:      	str	wzr, [sp, #0x50]
    3c38:      	mov	x0, x29
    3c3c:      	add	x1, sp, #0x50
    3c40:      	strh	wzr, [sp, #0x54]
    3c44:      	str	w11, [x22, #0x2c0]
    3c48:      	mov	w11, #0x18              // =24
    3c4c:      	umaddl	x9, w9, w11, x22
    3c50:      	str	x10, [x9, #0x2d0]
    3c54:      	mov	w10, #0x6               // =6
    3c58:      	str	x8, [x9, #0x2d8]
    3c5c:      	add	x8, x9, #0x2d0
    3c60:      	strh	w10, [x9, #0x2e0]
    3c64:      	ldr	w11, [sp, #0x50]
    3c68:      	ldrh	w10, [sp, #0x54]
    3c6c:      	stur	w11, [x8, #0x12]
    3c70:      	mov	w8, #0x36               // =54
    3c74:      	strh	w10, [x9, #0x2e6]
    3c78:      	add	x9, sp, #0x50
    3c7c:      	str	w8, [sp, #0x50]
    3c80:      	mov	w8, #0x1                // =1
    3c84:      	blr	x8
    3c88:      	cbz	x0, 0x3eac <perf_unwind_ruby+0x3eac>
    3c8c:      	ldr	x8, [x0]
    3c90:      	add	x8, x8, #0x1
    3c94:      	str	x8, [x0]
    3c98:      	b	0x36d4 <perf_unwind_ruby+0x36d4>
    3c9c:      	ldr	w8, [x23]
    3ca0:      	lsr	w8, w8, #9
    3ca4:      	cmp	w8, #0x103
    3ca8:      	b.hs	0x3e50 <perf_unwind_ruby+0x3e50>
    3cac:      	ldr	x8, [sp, #0x78]
    3cb0:      	ldr	x9, [sp]
    3cb4:      	cmp	x9, x8
    3cb8:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    3cbc:      	ldrb	w9, [x23, #0x1e]
    3cc0:      	str	xzr, [sp, #0x60]
    3cc4:      	mov	w20, #0x8               // =8
    3cc8:      	mov	w10, #0x70              // =112
    3ccc:      	add	x0, sp, #0x70
    3cd0:      	mov	w1, #0x8                // =8
    3cd4:      	mov	w24, #0x70              // =112
    3cd8:      	add	x8, x8, x9
    3cdc:      	ldrb	w9, [x23, #0x1c]
    3ce0:      	stp	xzr, x8, [sp, #0x70]
    3ce4:      	add	x8, x8, x9
    3ce8:      	add	x9, sp, #0x70
    3cec:      	ldr	x8, [sp, #0x78]
    3cf0:      	ldrb	w9, [x23, #0x1c]
    3cf4:      	add	x2, x8, x9
    3cf8:      	blr	x10
    3cfc:      	ldr	x8, [sp, #0x78]
    3d00:      	ldrb	w9, [x23, #0x1b]
    3d04:      	add	x0, sp, #0x60
    3d08:      	mov	w1, #0x8                // =8
    3d0c:      	add	x8, x8, x9
    3d10:      	add	x9, sp, #0x60
    3d14:      	ldr	x8, [sp, #0x78]
    3d18:      	ldrb	w9, [x23, #0x1b]
    3d1c:      	add	x2, x8, x9
    3d20:      	blr	x24
    3d24:      	ldr	x8, [sp, #0x60]
    3d28:      	cbz	x8, 0x3f88 <perf_unwind_ruby+0x3f88>
    3d2c:      	ldr	x8, [sp, #0x70]
    3d30:      	cbz	x8, 0x3f88 <perf_unwind_ruby+0x3f88>
    3d34:      	ldrb	w9, [x23, #0x1f]
    3d38:      	mov	w10, #0x70              // =112
    3d3c:      	add	x11, sp, #0x68
    3d40:      	add	x0, sp, #0x68
    3d44:      	mov	w1, #0x8                // =8
    3d48:      	add	x8, x8, x9
    3d4c:      	mov	w9, #0x8                // =8
    3d50:      	ldr	x8, [sp, #0x70]
    3d54:      	ldrb	w9, [x23, #0x1f]
    3d58:      	add	x2, x8, x9
    3d5c:      	blr	x10
    3d60:      	adrp	x25, 0x3000 <perf_unwind_ruby+0x3000>
    3d64:      	mov	x20, x29
    3d68:      	ldr	x25, [x25]
    3d6c:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    3d70:      	ldr	x8, [sp, #0x68]
    3d74:      	ldrb	w9, [x23, #0x21]
    3d78:      	mov	w10, #0x70              // =112
    3d7c:      	add	x11, sp, #0x58
    3d80:      	add	x0, sp, #0x58
    3d84:      	mov	w1, #0x8                // =8
    3d88:      	add	x8, x8, x9
    3d8c:      	mov	w9, #0x8                // =8
    3d90:      	ldr	x8, [sp, #0x68]
    3d94:      	ldrb	w9, [x23, #0x21]
    3d98:      	add	x2, x8, x9
    3d9c:      	blr	x10
    3da0:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    3da4:      	ldr	x8, [sp, #0x68]
    3da8:      	ldrb	w9, [x23, #0x22]
    3dac:      	mov	w10, #0x70              // =112
    3db0:      	add	x11, sp, #0x88
    3db4:      	add	x0, sp, #0x88
    3db8:      	mov	w1, #0x4                // =4
    3dbc:      	add	x8, x8, x9
    3dc0:      	mov	w9, #0x4                // =4
    3dc4:      	ldr	x8, [sp, #0x68]
    3dc8:      	ldrb	w9, [x23, #0x22]
    3dcc:      	add	x2, x8, x9
    3dd0:      	blr	x10
    3dd4:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    3dd8:      	ldrb	w9, [x23, #0x23]
    3ddc:      	ldr	x8, [sp, #0x60]
    3de0:      	cbz	x9, 0x40d0 <perf_unwind_ruby+0x40d0>
    3de4:      	ldr	x10, [sp, #0x58]
    3de8:      	sub	x10, x8, x10
    3dec:      	udiv	x9, x10, x9
    3df0:      	ldr	w10, [sp, #0x88]
    3df4:      	cmp	x9, x10
    3df8:      	b.ls	0x40d0 <perf_unwind_ruby+0x40d0>
    3dfc:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    3e00:      	ldr	x8, [x8]
    3e04:      	ldr	w8, [x8]
    3e08:      	cbz	w8, 0x4200 <perf_unwind_ruby+0x4200>
    3e0c:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    3e10:      	add	x8, x8, #0x0
    3e14:      	add	x0, sp, #0x8
    3e18:      	ldp	x9, x10, [x8, #0x10]
    3e1c:      	mov	w1, #0x2d               // =45
    3e20:      	stp	x9, x10, [sp, #0x18]
    3e24:      	ldr	x9, [x8, #0x20]
    3e28:      	add	x10, sp, #0x8
    3e2c:      	str	x9, [sp, #0x28]
    3e30:      	ldur	x9, [x8, #0x25]
    3e34:      	stur	x9, [sp, #0x2d]
    3e38:      	ldp	x9, x8, [x8]
    3e3c:      	stp	x9, x8, [sp, #0x8]
    3e40:      	mov	w8, #0x2d               // =45
    3e44:      	mov	w9, #0x6                // =6
    3e48:      	blr	x9
    3e4c:      	b	0x4200 <perf_unwind_ruby+0x4200>
    3e50:      	ldr	x8, [sp, #0x78]
    3e54:      	ldrb	w9, [x23, #0x1d]
    3e58:      	mov	w10, #0x70              // =112
    3e5c:      	add	x11, sp, #0x50
    3e60:      	add	x0, sp, #0x50
    3e64:      	mov	w1, #0x8                // =8
    3e68:      	str	xzr, [sp, #0x50]
    3e6c:      	add	x8, x8, x9
    3e70:      	mov	w9, #0x8                // =8
    3e74:      	ldr	x8, [sp, #0x78]
    3e78:      	ldrb	w9, [x23, #0x1d]
    3e7c:      	add	x2, x8, x9
    3e80:      	blr	x10
    3e84:      	adrp	x25, 0x3000 <perf_unwind_ruby+0x3000>
    3e88:      	mov	x20, x29
    3e8c:      	ldr	x25, [x25]
    3e90:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    3e94:      	ldr	w8, [sp, #0x50]
    3e98:      	mov	w9, #0x140              // =320
    3e9c:      	mvn	w8, w8
    3ea0:      	tst	x8, x9
    3ea4:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    3ea8:      	b	0x3cac <perf_unwind_ruby+0x3cac>
    3eac:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    3eb0:      	ldr	x8, [x8]
    3eb4:      	ldr	w8, [x8]
    3eb8:      	cbz	w8, 0x36d4 <perf_unwind_ruby+0x36d4>
    3ebc:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    3ec0:      	add	x8, x8, #0x0
    3ec4:      	add	x0, sp, #0x8
    3ec8:      	ldp	x9, x10, [x8, #0x10]
    3ecc:      	mov	w1, #0x2e               // =46
    3ed0:      	stp	x9, x10, [sp, #0x18]
    3ed4:      	ldr	x9, [x8, #0x20]
    3ed8:      	add	x10, sp, #0x8
    3edc:      	str	x9, [sp, #0x28]
    3ee0:      	ldur	x9, [x8, #0x26]
    3ee4:      	stur	x9, [sp, #0x2e]
    3ee8:      	ldp	x9, x8, [x8]
    3eec:      	stp	x9, x8, [sp, #0x8]
    3ef0:      	mov	w8, #0x2e               // =46
    3ef4:      	mov	w9, #0x6                // =6
    3ef8:      	ldr	w2, [sp, #0x50]
    3efc:      	blr	x9
    3f00:      	b	0x36d4 <perf_unwind_ruby+0x36d4>
    3f04:      	ldr	w9, [x22, #0x2c0]
    3f08:      	adrp	x25, 0x3000 <perf_unwind_ruby+0x3000>
    3f0c:      	ldr	x25, [x25]
    3f10:      	cmp	w9, #0x7e
    3f14:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    3f18:      	ldr	x10, [sp, #0x68]
    3f1c:      	add	w11, w9, #0x1
    3f20:      	str	wzr, [sp, #0x50]
    3f24:      	mov	x0, x29
    3f28:      	add	x1, sp, #0x50
    3f2c:      	strh	wzr, [sp, #0x54]
    3f30:      	str	w11, [x22, #0x2c0]
    3f34:      	mov	w11, #0x18              // =24
    3f38:      	umaddl	x9, w9, w11, x22
    3f3c:      	str	x10, [x9, #0x2d0]
    3f40:      	mov	w10, #0x6               // =6
    3f44:      	str	x8, [x9, #0x2d8]
    3f48:      	add	x8, x9, #0x2d0
    3f4c:      	strh	w10, [x9, #0x2e0]
    3f50:      	ldr	w11, [sp, #0x50]
    3f54:      	ldrh	w10, [sp, #0x54]
    3f58:      	stur	w11, [x8, #0x12]
    3f5c:      	mov	w8, #0x36               // =54
    3f60:      	strh	w10, [x9, #0x2e6]
    3f64:      	add	x9, sp, #0x50
    3f68:      	str	w8, [sp, #0x50]
    3f6c:      	mov	w8, #0x1                // =1
    3f70:      	blr	x8
    3f74:      	cbz	x0, 0x3ff4 <perf_unwind_ruby+0x3ff4>
    3f78:      	ldr	x8, [x0]
    3f7c:      	add	x8, x8, #0x1
    3f80:      	str	x8, [x0]
    3f84:      	b	0x39c0 <perf_unwind_ruby+0x39c0>
    3f88:      	ldr	w8, [x23]
    3f8c:      	lsr	w8, w8, #9
    3f90:      	cmp	w8, #0x103
    3f94:      	b.lo	0x4200 <perf_unwind_ruby+0x4200>
    3f98:      	ldr	x8, [sp, #0x78]
    3f9c:      	ldrb	w9, [x23, #0x1d]
    3fa0:      	mov	w10, #0x70              // =112
    3fa4:      	add	x11, sp, #0x50
    3fa8:      	add	x0, sp, #0x50
    3fac:      	mov	w1, #0x8                // =8
    3fb0:      	str	xzr, [sp, #0x50]
    3fb4:      	add	x8, x8, x9
    3fb8:      	mov	w9, #0x8                // =8
    3fbc:      	ldr	x8, [sp, #0x78]
    3fc0:      	ldrb	w9, [x23, #0x1d]
    3fc4:      	add	x2, x8, x9
    3fc8:      	blr	x10
    3fcc:      	adrp	x25, 0x3000 <perf_unwind_ruby+0x3000>
    3fd0:      	mov	x20, x29
    3fd4:      	ldr	x25, [x25]
    3fd8:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    3fdc:      	ldr	w8, [sp, #0x50]
    3fe0:      	mov	w9, #0x140              // =320
    3fe4:      	mvn	w8, w8
    3fe8:      	tst	x8, x9
    3fec:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    3ff0:      	b	0x4200 <perf_unwind_ruby+0x4200>
    3ff4:      	adrp	x8, 0x3000 <perf_unwind_ruby+0x3000>
    3ff8:      	ldr	x8, [x8]
    3ffc:      	ldr	w8, [x8]
    4000:      	cbz	w8, 0x39c0 <perf_unwind_ruby+0x39c0>
    4004:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    4008:      	add	x8, x8, #0x0
    400c:      	add	x0, sp, #0x8
    4010:      	ldp	x9, x10, [x8, #0x10]
    4014:      	mov	w1, #0x2e               // =46
    4018:      	stp	x9, x10, [sp, #0x18]
    401c:      	ldr	x9, [x8, #0x20]
    4020:      	add	x10, sp, #0x8
    4024:      	str	x9, [sp, #0x28]
    4028:      	ldur	x9, [x8, #0x26]
    402c:      	stur	x9, [sp, #0x2e]
    4030:      	ldp	x9, x8, [x8]
    4034:      	stp	x9, x8, [sp, #0x8]
    4038:      	mov	w8, #0x2e               // =46
    403c:      	mov	w9, #0x6                // =6
    4040:      	ldr	w2, [sp, #0x50]
    4044:      	blr	x9
    4048:      	b	0x39c0 <perf_unwind_ruby+0x39c0>
    404c:      	ldr	w9, [x22, #0x2c0]
    4050:      	adrp	x25, 0x4000 <perf_unwind_ruby+0x4000>
    4054:      	ldr	x25, [x25]
    4058:      	cmp	w9, #0x7e
    405c:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    4060:      	ldr	x10, [sp, #0x68]
    4064:      	add	w11, w9, #0x1
    4068:      	str	wzr, [sp, #0x50]
    406c:      	mov	x0, x29
    4070:      	add	x1, sp, #0x50
    4074:      	strh	wzr, [sp, #0x54]
    4078:      	str	w11, [x22, #0x2c0]
    407c:      	mov	w11, #0x18              // =24
    4080:      	umaddl	x9, w9, w11, x22
    4084:      	str	x10, [x9, #0x2d0]
    4088:      	mov	w10, #0x6               // =6
    408c:      	str	x8, [x9, #0x2d8]
    4090:      	add	x8, x9, #0x2d0
    4094:      	strh	w10, [x9, #0x2e0]
    4098:      	ldr	w11, [sp, #0x50]
    409c:      	ldrh	w10, [sp, #0x54]
    40a0:      	stur	w11, [x8, #0x12]
    40a4:      	mov	w8, #0x36               // =54
    40a8:      	strh	w10, [x9, #0x2e6]
    40ac:      	add	x9, sp, #0x50
    40b0:      	str	w8, [sp, #0x50]
    40b4:      	mov	w8, #0x1                // =1
    40b8:      	blr	x8
    40bc:      	cbz	x0, 0x4154 <perf_unwind_ruby+0x4154>
    40c0:      	ldr	x8, [x0]
    40c4:      	add	x8, x8, #0x1
    40c8:      	str	x8, [x0]
    40cc:      	b	0x3cac <perf_unwind_ruby+0x3cac>
    40d0:      	ldr	w9, [x22, #0x2c0]
    40d4:      	adrp	x25, 0x4000 <perf_unwind_ruby+0x4000>
    40d8:      	ldr	x25, [x25]
    40dc:      	cmp	w9, #0x7e
    40e0:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    40e4:      	ldr	x10, [sp, #0x68]
    40e8:      	add	w11, w9, #0x1
    40ec:      	str	wzr, [sp, #0x50]
    40f0:      	mov	x0, x29
    40f4:      	add	x1, sp, #0x50
    40f8:      	strh	wzr, [sp, #0x54]
    40fc:      	str	w11, [x22, #0x2c0]
    4100:      	mov	w11, #0x18              // =24
    4104:      	umaddl	x9, w9, w11, x22
    4108:      	str	x10, [x9, #0x2d0]
    410c:      	mov	w10, #0x6               // =6
    4110:      	str	x8, [x9, #0x2d8]
    4114:      	add	x8, x9, #0x2d0
    4118:      	strh	w10, [x9, #0x2e0]
    411c:      	ldr	w11, [sp, #0x50]
    4120:      	ldrh	w10, [sp, #0x54]
    4124:      	stur	w11, [x8, #0x12]
    4128:      	mov	w8, #0x36               // =54
    412c:      	strh	w10, [x9, #0x2e6]
    4130:      	add	x9, sp, #0x50
    4134:      	str	w8, [sp, #0x50]
    4138:      	mov	w8, #0x1                // =1
    413c:      	blr	x8
    4140:      	cbz	x0, 0x41ac <perf_unwind_ruby+0x41ac>
    4144:      	ldr	x8, [x0]
    4148:      	add	x8, x8, #0x1
    414c:      	str	x8, [x0]
    4150:      	b	0x4200 <perf_unwind_ruby+0x4200>
    4154:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    4158:      	ldr	x8, [x8]
    415c:      	ldr	w8, [x8]
    4160:      	cbz	w8, 0x3cac <perf_unwind_ruby+0x3cac>
    4164:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    4168:      	add	x8, x8, #0x0
    416c:      	add	x0, sp, #0x8
    4170:      	ldp	x9, x10, [x8, #0x10]
    4174:      	mov	w1, #0x2e               // =46
    4178:      	stp	x9, x10, [sp, #0x18]
    417c:      	ldr	x9, [x8, #0x20]
    4180:      	add	x10, sp, #0x8
    4184:      	str	x9, [sp, #0x28]
    4188:      	ldur	x9, [x8, #0x26]
    418c:      	stur	x9, [sp, #0x2e]
    4190:      	ldp	x9, x8, [x8]
    4194:      	stp	x9, x8, [sp, #0x8]
    4198:      	mov	w8, #0x2e               // =46
    419c:      	mov	w9, #0x6                // =6
    41a0:      	ldr	w2, [sp, #0x50]
    41a4:      	blr	x9
    41a8:      	b	0x3cac <perf_unwind_ruby+0x3cac>
    41ac:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    41b0:      	ldr	x8, [x8]
    41b4:      	ldr	w8, [x8]
    41b8:      	cbz	w8, 0x4200 <perf_unwind_ruby+0x4200>
    41bc:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    41c0:      	add	x8, x8, #0x0
    41c4:      	add	x0, sp, #0x8
    41c8:      	ldp	x9, x10, [x8, #0x10]
    41cc:      	mov	w1, #0x2e               // =46
    41d0:      	stp	x9, x10, [sp, #0x18]
    41d4:      	ldr	x9, [x8, #0x20]
    41d8:      	add	x10, sp, #0x8
    41dc:      	str	x9, [sp, #0x28]
    41e0:      	ldur	x9, [x8, #0x26]
    41e4:      	stur	x9, [sp, #0x2e]
    41e8:      	ldp	x9, x8, [x8]
    41ec:      	stp	x9, x8, [sp, #0x8]
    41f0:      	mov	w8, #0x2e               // =46
    41f4:      	mov	w9, #0x6                // =6
    41f8:      	ldr	w2, [sp, #0x50]
    41fc:      	blr	x9
    4200:      	ldr	x8, [sp, #0x78]
    4204:      	ldr	x9, [sp]
    4208:      	cmp	x9, x8
    420c:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    4210:      	ldrb	w9, [x23, #0x1e]
    4214:      	str	xzr, [sp, #0x60]
    4218:      	mov	w20, #0x8               // =8
    421c:      	mov	w10, #0x70              // =112
    4220:      	mov	w24, #0x600             // =1536
    4224:      	add	x0, sp, #0x70
    4228:      	mov	w1, #0x8                // =8
    422c:      	movk	w24, #0x2, lsl #16
    4230:      	mov	w25, #0x70              // =112
    4234:      	add	x8, x8, x9
    4238:      	ldrb	w9, [x23, #0x1c]
    423c:      	stp	xzr, x8, [sp, #0x70]
    4240:      	add	x8, x8, x9
    4244:      	add	x9, sp, #0x70
    4248:      	ldr	x8, [sp, #0x78]
    424c:      	ldrb	w9, [x23, #0x1c]
    4250:      	add	x2, x8, x9
    4254:      	blr	x10
    4258:      	ldr	x8, [sp, #0x78]
    425c:      	ldrb	w9, [x23, #0x1b]
    4260:      	add	x0, sp, #0x60
    4264:      	mov	w1, #0x8                // =8
    4268:      	add	x8, x8, x9
    426c:      	add	x9, sp, #0x60
    4270:      	ldr	x8, [sp, #0x78]
    4274:      	ldrb	w9, [x23, #0x1b]
    4278:      	add	x2, x8, x9
    427c:      	blr	x25
    4280:      	ldr	x8, [sp, #0x60]
    4284:      	cbz	x8, 0x43ac <perf_unwind_ruby+0x43ac>
    4288:      	ldr	x8, [sp, #0x70]
    428c:      	cbz	x8, 0x43ac <perf_unwind_ruby+0x43ac>
    4290:      	ldrb	w9, [x23, #0x1f]
    4294:      	mov	w10, #0x70              // =112
    4298:      	add	x11, sp, #0x68
    429c:      	add	x0, sp, #0x68
    42a0:      	mov	w1, #0x8                // =8
    42a4:      	add	x8, x8, x9
    42a8:      	mov	w9, #0x8                // =8
    42ac:      	ldr	x8, [sp, #0x70]
    42b0:      	ldrb	w9, [x23, #0x1f]
    42b4:      	add	x2, x8, x9
    42b8:      	blr	x10
    42bc:      	adrp	x25, 0x4000 <perf_unwind_ruby+0x4000>
    42c0:      	mov	x20, x29
    42c4:      	ldr	x25, [x25]
    42c8:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    42cc:      	ldr	x8, [sp, #0x68]
    42d0:      	ldrb	w9, [x23, #0x21]
    42d4:      	mov	w10, #0x70              // =112
    42d8:      	add	x11, sp, #0x58
    42dc:      	add	x0, sp, #0x58
    42e0:      	mov	w1, #0x8                // =8
    42e4:      	add	x8, x8, x9
    42e8:      	mov	w9, #0x8                // =8
    42ec:      	ldr	x8, [sp, #0x68]
    42f0:      	ldrb	w9, [x23, #0x21]
    42f4:      	add	x2, x8, x9
    42f8:      	blr	x10
    42fc:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    4300:      	ldr	x8, [sp, #0x68]
    4304:      	ldrb	w9, [x23, #0x22]
    4308:      	mov	w10, #0x70              // =112
    430c:      	add	x11, sp, #0x88
    4310:      	add	x0, sp, #0x88
    4314:      	mov	w1, #0x4                // =4
    4318:      	add	x8, x8, x9
    431c:      	mov	w9, #0x4                // =4
    4320:      	ldr	x8, [sp, #0x68]
    4324:      	ldrb	w9, [x23, #0x22]
    4328:      	add	x2, x8, x9
    432c:      	blr	x10
    4330:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    4334:      	ldrb	w9, [x23, #0x23]
    4338:      	ldr	x8, [sp, #0x60]
    433c:      	cbz	x9, 0x4414 <perf_unwind_ruby+0x4414>
    4340:      	ldr	x10, [sp, #0x58]
    4344:      	sub	x10, x8, x10
    4348:      	udiv	x9, x10, x9
    434c:      	ldr	w10, [sp, #0x88]
    4350:      	cmp	x9, x10
    4354:      	b.ls	0x4414 <perf_unwind_ruby+0x4414>
    4358:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    435c:      	ldr	x8, [x8]
    4360:      	ldr	w8, [x8]
    4364:      	cbz	w8, 0x44ec <perf_unwind_ruby+0x44ec>
    4368:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    436c:      	add	x8, x8, #0x0
    4370:      	add	x0, sp, #0x8
    4374:      	ldp	x9, x10, [x8, #0x10]
    4378:      	mov	w1, #0x2d               // =45
    437c:      	stp	x9, x10, [sp, #0x18]
    4380:      	ldr	x9, [x8, #0x20]
    4384:      	add	x10, sp, #0x8
    4388:      	str	x9, [sp, #0x28]
    438c:      	ldur	x9, [x8, #0x25]
    4390:      	stur	x9, [sp, #0x2d]
    4394:      	ldp	x9, x8, [x8]
    4398:      	stp	x9, x8, [sp, #0x8]
    439c:      	mov	w8, #0x2d               // =45
    43a0:      	mov	w9, #0x6                // =6
    43a4:      	blr	x9
    43a8:      	b	0x44ec <perf_unwind_ruby+0x44ec>
    43ac:      	ldr	w8, [x23]
    43b0:      	cmp	w8, w24
    43b4:      	b.lo	0x44ec <perf_unwind_ruby+0x44ec>
    43b8:      	ldr	x8, [sp, #0x78]
    43bc:      	ldrb	w9, [x23, #0x1d]
    43c0:      	mov	w10, #0x70              // =112
    43c4:      	add	x11, sp, #0x50
    43c8:      	add	x0, sp, #0x50
    43cc:      	mov	w1, #0x8                // =8
    43d0:      	str	xzr, [sp, #0x50]
    43d4:      	add	x8, x8, x9
    43d8:      	mov	w9, #0x8                // =8
    43dc:      	ldr	x8, [sp, #0x78]
    43e0:      	ldrb	w9, [x23, #0x1d]
    43e4:      	add	x2, x8, x9
    43e8:      	blr	x10
    43ec:      	adrp	x25, 0x4000 <perf_unwind_ruby+0x4000>
    43f0:      	mov	x20, x29
    43f4:      	ldr	x25, [x25]
    43f8:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    43fc:      	ldr	w8, [sp, #0x50]
    4400:      	mov	w9, #0x140              // =320
    4404:      	mvn	w8, w8
    4408:      	tst	x8, x9
    440c:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    4410:      	b	0x44ec <perf_unwind_ruby+0x44ec>
    4414:      	ldr	w9, [x22, #0x2c0]
    4418:      	adrp	x25, 0x4000 <perf_unwind_ruby+0x4000>
    441c:      	ldr	x25, [x25]
    4420:      	cmp	w9, #0x7e
    4424:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    4428:      	ldr	x10, [sp, #0x68]
    442c:      	add	w11, w9, #0x1
    4430:      	str	wzr, [sp, #0x50]
    4434:      	mov	x0, x29
    4438:      	add	x1, sp, #0x50
    443c:      	strh	wzr, [sp, #0x54]
    4440:      	str	w11, [x22, #0x2c0]
    4444:      	mov	w11, #0x18              // =24
    4448:      	umaddl	x9, w9, w11, x22
    444c:      	str	x10, [x9, #0x2d0]
    4450:      	mov	w10, #0x6               // =6
    4454:      	str	x8, [x9, #0x2d8]
    4458:      	add	x8, x9, #0x2d0
    445c:      	strh	w10, [x9, #0x2e0]
    4460:      	ldr	w11, [sp, #0x50]
    4464:      	ldrh	w10, [sp, #0x54]
    4468:      	stur	w11, [x8, #0x12]
    446c:      	mov	w8, #0x36               // =54
    4470:      	strh	w10, [x9, #0x2e6]
    4474:      	add	x9, sp, #0x50
    4478:      	str	w8, [sp, #0x50]
    447c:      	mov	w8, #0x1                // =1
    4480:      	blr	x8
    4484:      	cbz	x0, 0x4498 <perf_unwind_ruby+0x4498>
    4488:      	ldr	x8, [x0]
    448c:      	add	x8, x8, #0x1
    4490:      	str	x8, [x0]
    4494:      	b	0x44ec <perf_unwind_ruby+0x44ec>
    4498:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    449c:      	ldr	x8, [x8]
    44a0:      	ldr	w8, [x8]
    44a4:      	cbz	w8, 0x44ec <perf_unwind_ruby+0x44ec>
    44a8:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    44ac:      	add	x8, x8, #0x0
    44b0:      	add	x0, sp, #0x8
    44b4:      	ldp	x9, x10, [x8, #0x10]
    44b8:      	mov	w1, #0x2e               // =46
    44bc:      	stp	x9, x10, [sp, #0x18]
    44c0:      	ldr	x9, [x8, #0x20]
    44c4:      	add	x10, sp, #0x8
    44c8:      	str	x9, [sp, #0x28]
    44cc:      	ldur	x9, [x8, #0x26]
    44d0:      	stur	x9, [sp, #0x2e]
    44d4:      	ldp	x9, x8, [x8]
    44d8:      	stp	x9, x8, [sp, #0x8]
    44dc:      	mov	w8, #0x2e               // =46
    44e0:      	mov	w9, #0x6                // =6
    44e4:      	ldr	w2, [sp, #0x50]
    44e8:      	blr	x9
    44ec:      	ldr	x8, [sp, #0x78]
    44f0:      	ldr	x9, [sp]
    44f4:      	cmp	x9, x8
    44f8:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    44fc:      	ldrb	w9, [x23, #0x1e]
    4500:      	str	xzr, [sp, #0x60]
    4504:      	mov	w20, #0x8               // =8
    4508:      	mov	w10, #0x70              // =112
    450c:      	add	x0, sp, #0x70
    4510:      	mov	w1, #0x8                // =8
    4514:      	mov	w25, #0x70              // =112
    4518:      	add	x8, x8, x9
    451c:      	ldrb	w9, [x23, #0x1c]
    4520:      	stp	xzr, x8, [sp, #0x70]
    4524:      	add	x8, x8, x9
    4528:      	add	x9, sp, #0x70
    452c:      	ldr	x8, [sp, #0x78]
    4530:      	ldrb	w9, [x23, #0x1c]
    4534:      	add	x2, x8, x9
    4538:      	blr	x10
    453c:      	ldr	x8, [sp, #0x78]
    4540:      	ldrb	w9, [x23, #0x1b]
    4544:      	add	x0, sp, #0x60
    4548:      	mov	w1, #0x8                // =8
    454c:      	add	x8, x8, x9
    4550:      	add	x9, sp, #0x60
    4554:      	ldr	x8, [sp, #0x78]
    4558:      	ldrb	w9, [x23, #0x1b]
    455c:      	add	x2, x8, x9
    4560:      	blr	x25
    4564:      	ldr	x8, [sp, #0x60]
    4568:      	cbz	x8, 0x4690 <perf_unwind_ruby+0x4690>
    456c:      	ldr	x8, [sp, #0x70]
    4570:      	cbz	x8, 0x4690 <perf_unwind_ruby+0x4690>
    4574:      	ldrb	w9, [x23, #0x1f]
    4578:      	mov	w10, #0x70              // =112
    457c:      	add	x11, sp, #0x68
    4580:      	add	x0, sp, #0x68
    4584:      	mov	w1, #0x8                // =8
    4588:      	add	x8, x8, x9
    458c:      	mov	w9, #0x8                // =8
    4590:      	ldr	x8, [sp, #0x70]
    4594:      	ldrb	w9, [x23, #0x1f]
    4598:      	add	x2, x8, x9
    459c:      	blr	x10
    45a0:      	adrp	x25, 0x4000 <perf_unwind_ruby+0x4000>
    45a4:      	mov	x20, x29
    45a8:      	ldr	x25, [x25]
    45ac:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    45b0:      	ldr	x8, [sp, #0x68]
    45b4:      	ldrb	w9, [x23, #0x21]
    45b8:      	mov	w10, #0x70              // =112
    45bc:      	add	x11, sp, #0x58
    45c0:      	add	x0, sp, #0x58
    45c4:      	mov	w1, #0x8                // =8
    45c8:      	add	x8, x8, x9
    45cc:      	mov	w9, #0x8                // =8
    45d0:      	ldr	x8, [sp, #0x68]
    45d4:      	ldrb	w9, [x23, #0x21]
    45d8:      	add	x2, x8, x9
    45dc:      	blr	x10
    45e0:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    45e4:      	ldr	x8, [sp, #0x68]
    45e8:      	ldrb	w9, [x23, #0x22]
    45ec:      	mov	w10, #0x70              // =112
    45f0:      	add	x11, sp, #0x88
    45f4:      	add	x0, sp, #0x88
    45f8:      	mov	w1, #0x4                // =4
    45fc:      	add	x8, x8, x9
    4600:      	mov	w9, #0x4                // =4
    4604:      	ldr	x8, [sp, #0x68]
    4608:      	ldrb	w9, [x23, #0x22]
    460c:      	add	x2, x8, x9
    4610:      	blr	x10
    4614:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    4618:      	ldrb	w9, [x23, #0x23]
    461c:      	ldr	x8, [sp, #0x60]
    4620:      	cbz	x9, 0x46f8 <perf_unwind_ruby+0x46f8>
    4624:      	ldr	x10, [sp, #0x58]
    4628:      	sub	x10, x8, x10
    462c:      	udiv	x9, x10, x9
    4630:      	ldr	w10, [sp, #0x88]
    4634:      	cmp	x9, x10
    4638:      	b.ls	0x46f8 <perf_unwind_ruby+0x46f8>
    463c:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    4640:      	ldr	x8, [x8]
    4644:      	ldr	w8, [x8]
    4648:      	cbz	w8, 0x47d0 <perf_unwind_ruby+0x47d0>
    464c:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    4650:      	add	x8, x8, #0x0
    4654:      	add	x0, sp, #0x8
    4658:      	ldp	x9, x10, [x8, #0x10]
    465c:      	mov	w1, #0x2d               // =45
    4660:      	stp	x9, x10, [sp, #0x18]
    4664:      	ldr	x9, [x8, #0x20]
    4668:      	add	x10, sp, #0x8
    466c:      	str	x9, [sp, #0x28]
    4670:      	ldur	x9, [x8, #0x25]
    4674:      	stur	x9, [sp, #0x2d]
    4678:      	ldp	x9, x8, [x8]
    467c:      	stp	x9, x8, [sp, #0x8]
    4680:      	mov	w8, #0x2d               // =45
    4684:      	mov	w9, #0x6                // =6
    4688:      	blr	x9
    468c:      	b	0x47d0 <perf_unwind_ruby+0x47d0>
    4690:      	ldr	w8, [x23]
    4694:      	cmp	w8, w24
    4698:      	b.lo	0x47d0 <perf_unwind_ruby+0x47d0>
    469c:      	ldr	x8, [sp, #0x78]
    46a0:      	ldrb	w9, [x23, #0x1d]
    46a4:      	mov	w10, #0x70              // =112
    46a8:      	add	x11, sp, #0x50
    46ac:      	add	x0, sp, #0x50
    46b0:      	mov	w1, #0x8                // =8
    46b4:      	str	xzr, [sp, #0x50]
    46b8:      	add	x8, x8, x9
    46bc:      	mov	w9, #0x8                // =8
    46c0:      	ldr	x8, [sp, #0x78]
    46c4:      	ldrb	w9, [x23, #0x1d]
    46c8:      	add	x2, x8, x9
    46cc:      	blr	x10
    46d0:      	adrp	x25, 0x4000 <perf_unwind_ruby+0x4000>
    46d4:      	mov	x20, x29
    46d8:      	ldr	x25, [x25]
    46dc:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    46e0:      	ldr	w8, [sp, #0x50]
    46e4:      	mov	w9, #0x140              // =320
    46e8:      	mvn	w8, w8
    46ec:      	tst	x8, x9
    46f0:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    46f4:      	b	0x47d0 <perf_unwind_ruby+0x47d0>
    46f8:      	ldr	w9, [x22, #0x2c0]
    46fc:      	adrp	x25, 0x4000 <perf_unwind_ruby+0x4000>
    4700:      	ldr	x25, [x25]
    4704:      	cmp	w9, #0x7e
    4708:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    470c:      	ldr	x10, [sp, #0x68]
    4710:      	add	w11, w9, #0x1
    4714:      	str	wzr, [sp, #0x50]
    4718:      	mov	x0, x29
    471c:      	add	x1, sp, #0x50
    4720:      	strh	wzr, [sp, #0x54]
    4724:      	str	w11, [x22, #0x2c0]
    4728:      	mov	w11, #0x18              // =24
    472c:      	umaddl	x9, w9, w11, x22
    4730:      	str	x10, [x9, #0x2d0]
    4734:      	mov	w10, #0x6               // =6
    4738:      	str	x8, [x9, #0x2d8]
    473c:      	add	x8, x9, #0x2d0
    4740:      	strh	w10, [x9, #0x2e0]
    4744:      	ldr	w11, [sp, #0x50]
    4748:      	ldrh	w10, [sp, #0x54]
    474c:      	stur	w11, [x8, #0x12]
    4750:      	mov	w8, #0x36               // =54
    4754:      	strh	w10, [x9, #0x2e6]
    4758:      	add	x9, sp, #0x50
    475c:      	str	w8, [sp, #0x50]
    4760:      	mov	w8, #0x1                // =1
    4764:      	blr	x8
    4768:      	cbz	x0, 0x477c <perf_unwind_ruby+0x477c>
    476c:      	ldr	x8, [x0]
    4770:      	add	x8, x8, #0x1
    4774:      	str	x8, [x0]
    4778:      	b	0x47d0 <perf_unwind_ruby+0x47d0>
    477c:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    4780:      	ldr	x8, [x8]
    4784:      	ldr	w8, [x8]
    4788:      	cbz	w8, 0x47d0 <perf_unwind_ruby+0x47d0>
    478c:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    4790:      	add	x8, x8, #0x0
    4794:      	add	x0, sp, #0x8
    4798:      	ldp	x9, x10, [x8, #0x10]
    479c:      	mov	w1, #0x2e               // =46
    47a0:      	stp	x9, x10, [sp, #0x18]
    47a4:      	ldr	x9, [x8, #0x20]
    47a8:      	add	x10, sp, #0x8
    47ac:      	str	x9, [sp, #0x28]
    47b0:      	ldur	x9, [x8, #0x26]
    47b4:      	stur	x9, [sp, #0x2e]
    47b8:      	ldp	x9, x8, [x8]
    47bc:      	stp	x9, x8, [sp, #0x8]
    47c0:      	mov	w8, #0x2e               // =46
    47c4:      	mov	w9, #0x6                // =6
    47c8:      	ldr	w2, [sp, #0x50]
    47cc:      	blr	x9
    47d0:      	ldr	x8, [sp, #0x78]
    47d4:      	ldr	x9, [sp]
    47d8:      	cmp	x9, x8
    47dc:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    47e0:      	ldrb	w9, [x23, #0x1e]
    47e4:      	str	xzr, [sp, #0x60]
    47e8:      	mov	w20, #0x8               // =8
    47ec:      	mov	w10, #0x70              // =112
    47f0:      	add	x0, sp, #0x70
    47f4:      	mov	w1, #0x8                // =8
    47f8:      	mov	w25, #0x70              // =112
    47fc:      	add	x8, x8, x9
    4800:      	ldrb	w9, [x23, #0x1c]
    4804:      	stp	xzr, x8, [sp, #0x70]
    4808:      	add	x8, x8, x9
    480c:      	add	x9, sp, #0x70
    4810:      	ldr	x8, [sp, #0x78]
    4814:      	ldrb	w9, [x23, #0x1c]
    4818:      	add	x2, x8, x9
    481c:      	blr	x10
    4820:      	ldr	x8, [sp, #0x78]
    4824:      	ldrb	w9, [x23, #0x1b]
    4828:      	add	x0, sp, #0x60
    482c:      	mov	w1, #0x8                // =8
    4830:      	add	x8, x8, x9
    4834:      	add	x9, sp, #0x60
    4838:      	ldr	x8, [sp, #0x78]
    483c:      	ldrb	w9, [x23, #0x1b]
    4840:      	add	x2, x8, x9
    4844:      	blr	x25
    4848:      	ldr	x8, [sp, #0x60]
    484c:      	cbz	x8, 0x4974 <perf_unwind_ruby+0x4974>
    4850:      	ldr	x8, [sp, #0x70]
    4854:      	cbz	x8, 0x4974 <perf_unwind_ruby+0x4974>
    4858:      	ldrb	w9, [x23, #0x1f]
    485c:      	mov	w10, #0x70              // =112
    4860:      	add	x11, sp, #0x68
    4864:      	add	x0, sp, #0x68
    4868:      	mov	w1, #0x8                // =8
    486c:      	add	x8, x8, x9
    4870:      	mov	w9, #0x8                // =8
    4874:      	ldr	x8, [sp, #0x70]
    4878:      	ldrb	w9, [x23, #0x1f]
    487c:      	add	x2, x8, x9
    4880:      	blr	x10
    4884:      	adrp	x25, 0x4000 <perf_unwind_ruby+0x4000>
    4888:      	mov	x20, x29
    488c:      	ldr	x25, [x25]
    4890:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    4894:      	ldr	x8, [sp, #0x68]
    4898:      	ldrb	w9, [x23, #0x21]
    489c:      	mov	w10, #0x70              // =112
    48a0:      	add	x11, sp, #0x58
    48a4:      	add	x0, sp, #0x58
    48a8:      	mov	w1, #0x8                // =8
    48ac:      	add	x8, x8, x9
    48b0:      	mov	w9, #0x8                // =8
    48b4:      	ldr	x8, [sp, #0x68]
    48b8:      	ldrb	w9, [x23, #0x21]
    48bc:      	add	x2, x8, x9
    48c0:      	blr	x10
    48c4:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    48c8:      	ldr	x8, [sp, #0x68]
    48cc:      	ldrb	w9, [x23, #0x22]
    48d0:      	mov	w10, #0x70              // =112
    48d4:      	add	x11, sp, #0x88
    48d8:      	add	x0, sp, #0x88
    48dc:      	mov	w1, #0x4                // =4
    48e0:      	add	x8, x8, x9
    48e4:      	mov	w9, #0x4                // =4
    48e8:      	ldr	x8, [sp, #0x68]
    48ec:      	ldrb	w9, [x23, #0x22]
    48f0:      	add	x2, x8, x9
    48f4:      	blr	x10
    48f8:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    48fc:      	ldrb	w9, [x23, #0x23]
    4900:      	ldr	x8, [sp, #0x60]
    4904:      	cbz	x9, 0x49dc <perf_unwind_ruby+0x49dc>
    4908:      	ldr	x10, [sp, #0x58]
    490c:      	sub	x10, x8, x10
    4910:      	udiv	x9, x10, x9
    4914:      	ldr	w10, [sp, #0x88]
    4918:      	cmp	x9, x10
    491c:      	b.ls	0x49dc <perf_unwind_ruby+0x49dc>
    4920:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    4924:      	ldr	x8, [x8]
    4928:      	ldr	w8, [x8]
    492c:      	cbz	w8, 0x4ab4 <perf_unwind_ruby+0x4ab4>
    4930:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    4934:      	add	x8, x8, #0x0
    4938:      	add	x0, sp, #0x8
    493c:      	ldp	x9, x10, [x8, #0x10]
    4940:      	mov	w1, #0x2d               // =45
    4944:      	stp	x9, x10, [sp, #0x18]
    4948:      	ldr	x9, [x8, #0x20]
    494c:      	add	x10, sp, #0x8
    4950:      	str	x9, [sp, #0x28]
    4954:      	ldur	x9, [x8, #0x25]
    4958:      	stur	x9, [sp, #0x2d]
    495c:      	ldp	x9, x8, [x8]
    4960:      	stp	x9, x8, [sp, #0x8]
    4964:      	mov	w8, #0x2d               // =45
    4968:      	mov	w9, #0x6                // =6
    496c:      	blr	x9
    4970:      	b	0x4ab4 <perf_unwind_ruby+0x4ab4>
    4974:      	ldr	w8, [x23]
    4978:      	cmp	w8, w24
    497c:      	b.lo	0x4ab4 <perf_unwind_ruby+0x4ab4>
    4980:      	ldr	x8, [sp, #0x78]
    4984:      	ldrb	w9, [x23, #0x1d]
    4988:      	mov	w10, #0x70              // =112
    498c:      	add	x11, sp, #0x50
    4990:      	add	x0, sp, #0x50
    4994:      	mov	w1, #0x8                // =8
    4998:      	str	xzr, [sp, #0x50]
    499c:      	add	x8, x8, x9
    49a0:      	mov	w9, #0x8                // =8
    49a4:      	ldr	x8, [sp, #0x78]
    49a8:      	ldrb	w9, [x23, #0x1d]
    49ac:      	add	x2, x8, x9
    49b0:      	blr	x10
    49b4:      	adrp	x25, 0x4000 <perf_unwind_ruby+0x4000>
    49b8:      	mov	x20, x29
    49bc:      	ldr	x25, [x25]
    49c0:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    49c4:      	ldr	w8, [sp, #0x50]
    49c8:      	mov	w9, #0x140              // =320
    49cc:      	mvn	w8, w8
    49d0:      	tst	x8, x9
    49d4:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    49d8:      	b	0x4ab4 <perf_unwind_ruby+0x4ab4>
    49dc:      	ldr	w9, [x22, #0x2c0]
    49e0:      	adrp	x25, 0x4000 <perf_unwind_ruby+0x4000>
    49e4:      	ldr	x25, [x25]
    49e8:      	cmp	w9, #0x7e
    49ec:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    49f0:      	ldr	x10, [sp, #0x68]
    49f4:      	add	w11, w9, #0x1
    49f8:      	str	wzr, [sp, #0x50]
    49fc:      	mov	x0, x29
    4a00:      	add	x1, sp, #0x50
    4a04:      	strh	wzr, [sp, #0x54]
    4a08:      	str	w11, [x22, #0x2c0]
    4a0c:      	mov	w11, #0x18              // =24
    4a10:      	umaddl	x9, w9, w11, x22
    4a14:      	str	x10, [x9, #0x2d0]
    4a18:      	mov	w10, #0x6               // =6
    4a1c:      	str	x8, [x9, #0x2d8]
    4a20:      	add	x8, x9, #0x2d0
    4a24:      	strh	w10, [x9, #0x2e0]
    4a28:      	ldr	w11, [sp, #0x50]
    4a2c:      	ldrh	w10, [sp, #0x54]
    4a30:      	stur	w11, [x8, #0x12]
    4a34:      	mov	w8, #0x36               // =54
    4a38:      	strh	w10, [x9, #0x2e6]
    4a3c:      	add	x9, sp, #0x50
    4a40:      	str	w8, [sp, #0x50]
    4a44:      	mov	w8, #0x1                // =1
    4a48:      	blr	x8
    4a4c:      	cbz	x0, 0x4a60 <perf_unwind_ruby+0x4a60>
    4a50:      	ldr	x8, [x0]
    4a54:      	add	x8, x8, #0x1
    4a58:      	str	x8, [x0]
    4a5c:      	b	0x4ab4 <perf_unwind_ruby+0x4ab4>
    4a60:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    4a64:      	ldr	x8, [x8]
    4a68:      	ldr	w8, [x8]
    4a6c:      	cbz	w8, 0x4ab4 <perf_unwind_ruby+0x4ab4>
    4a70:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    4a74:      	add	x8, x8, #0x0
    4a78:      	add	x0, sp, #0x8
    4a7c:      	ldp	x9, x10, [x8, #0x10]
    4a80:      	mov	w1, #0x2e               // =46
    4a84:      	stp	x9, x10, [sp, #0x18]
    4a88:      	ldr	x9, [x8, #0x20]
    4a8c:      	add	x10, sp, #0x8
    4a90:      	str	x9, [sp, #0x28]
    4a94:      	ldur	x9, [x8, #0x26]
    4a98:      	stur	x9, [sp, #0x2e]
    4a9c:      	ldp	x9, x8, [x8]
    4aa0:      	stp	x9, x8, [sp, #0x8]
    4aa4:      	mov	w8, #0x2e               // =46
    4aa8:      	mov	w9, #0x6                // =6
    4aac:      	ldr	w2, [sp, #0x50]
    4ab0:      	blr	x9
    4ab4:      	ldr	x8, [sp, #0x78]
    4ab8:      	ldr	x9, [sp]
    4abc:      	cmp	x9, x8
    4ac0:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    4ac4:      	ldrb	w9, [x23, #0x1e]
    4ac8:      	str	xzr, [sp, #0x60]
    4acc:      	mov	w20, #0x8               // =8
    4ad0:      	mov	w10, #0x70              // =112
    4ad4:      	add	x0, sp, #0x70
    4ad8:      	mov	w1, #0x8                // =8
    4adc:      	mov	w25, #0x70              // =112
    4ae0:      	add	x8, x8, x9
    4ae4:      	ldrb	w9, [x23, #0x1c]
    4ae8:      	stp	xzr, x8, [sp, #0x70]
    4aec:      	add	x8, x8, x9
    4af0:      	add	x9, sp, #0x70
    4af4:      	ldr	x8, [sp, #0x78]
    4af8:      	ldrb	w9, [x23, #0x1c]
    4afc:      	add	x2, x8, x9
    4b00:      	blr	x10
    4b04:      	ldr	x8, [sp, #0x78]
    4b08:      	ldrb	w9, [x23, #0x1b]
    4b0c:      	add	x0, sp, #0x60
    4b10:      	mov	w1, #0x8                // =8
    4b14:      	add	x8, x8, x9
    4b18:      	add	x9, sp, #0x60
    4b1c:      	ldr	x8, [sp, #0x78]
    4b20:      	ldrb	w9, [x23, #0x1b]
    4b24:      	add	x2, x8, x9
    4b28:      	blr	x25
    4b2c:      	ldr	x8, [sp, #0x60]
    4b30:      	cbz	x8, 0x4c58 <perf_unwind_ruby+0x4c58>
    4b34:      	ldr	x8, [sp, #0x70]
    4b38:      	cbz	x8, 0x4c58 <perf_unwind_ruby+0x4c58>
    4b3c:      	ldrb	w9, [x23, #0x1f]
    4b40:      	mov	w10, #0x70              // =112
    4b44:      	add	x11, sp, #0x68
    4b48:      	add	x0, sp, #0x68
    4b4c:      	mov	w1, #0x8                // =8
    4b50:      	add	x8, x8, x9
    4b54:      	mov	w9, #0x8                // =8
    4b58:      	ldr	x8, [sp, #0x70]
    4b5c:      	ldrb	w9, [x23, #0x1f]
    4b60:      	add	x2, x8, x9
    4b64:      	blr	x10
    4b68:      	adrp	x25, 0x4000 <perf_unwind_ruby+0x4000>
    4b6c:      	mov	x20, x29
    4b70:      	ldr	x25, [x25]
    4b74:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    4b78:      	ldr	x8, [sp, #0x68]
    4b7c:      	ldrb	w9, [x23, #0x21]
    4b80:      	mov	w10, #0x70              // =112
    4b84:      	add	x11, sp, #0x58
    4b88:      	add	x0, sp, #0x58
    4b8c:      	mov	w1, #0x8                // =8
    4b90:      	add	x8, x8, x9
    4b94:      	mov	w9, #0x8                // =8
    4b98:      	ldr	x8, [sp, #0x68]
    4b9c:      	ldrb	w9, [x23, #0x21]
    4ba0:      	add	x2, x8, x9
    4ba4:      	blr	x10
    4ba8:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    4bac:      	ldr	x8, [sp, #0x68]
    4bb0:      	ldrb	w9, [x23, #0x22]
    4bb4:      	mov	w10, #0x70              // =112
    4bb8:      	add	x11, sp, #0x88
    4bbc:      	add	x0, sp, #0x88
    4bc0:      	mov	w1, #0x4                // =4
    4bc4:      	add	x8, x8, x9
    4bc8:      	mov	w9, #0x4                // =4
    4bcc:      	ldr	x8, [sp, #0x68]
    4bd0:      	ldrb	w9, [x23, #0x22]
    4bd4:      	add	x2, x8, x9
    4bd8:      	blr	x10
    4bdc:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    4be0:      	ldrb	w9, [x23, #0x23]
    4be4:      	ldr	x8, [sp, #0x60]
    4be8:      	cbz	x9, 0x4cc0 <perf_unwind_ruby+0x4cc0>
    4bec:      	ldr	x10, [sp, #0x58]
    4bf0:      	sub	x10, x8, x10
    4bf4:      	udiv	x9, x10, x9
    4bf8:      	ldr	w10, [sp, #0x88]
    4bfc:      	cmp	x9, x10
    4c00:      	b.ls	0x4cc0 <perf_unwind_ruby+0x4cc0>
    4c04:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    4c08:      	ldr	x8, [x8]
    4c0c:      	ldr	w8, [x8]
    4c10:      	cbz	w8, 0x4d98 <perf_unwind_ruby+0x4d98>
    4c14:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    4c18:      	add	x8, x8, #0x0
    4c1c:      	add	x0, sp, #0x8
    4c20:      	ldp	x9, x10, [x8, #0x10]
    4c24:      	mov	w1, #0x2d               // =45
    4c28:      	stp	x9, x10, [sp, #0x18]
    4c2c:      	ldr	x9, [x8, #0x20]
    4c30:      	add	x10, sp, #0x8
    4c34:      	str	x9, [sp, #0x28]
    4c38:      	ldur	x9, [x8, #0x25]
    4c3c:      	stur	x9, [sp, #0x2d]
    4c40:      	ldp	x9, x8, [x8]
    4c44:      	stp	x9, x8, [sp, #0x8]
    4c48:      	mov	w8, #0x2d               // =45
    4c4c:      	mov	w9, #0x6                // =6
    4c50:      	blr	x9
    4c54:      	b	0x4d98 <perf_unwind_ruby+0x4d98>
    4c58:      	ldr	w8, [x23]
    4c5c:      	cmp	w8, w24
    4c60:      	b.lo	0x4d98 <perf_unwind_ruby+0x4d98>
    4c64:      	ldr	x8, [sp, #0x78]
    4c68:      	ldrb	w9, [x23, #0x1d]
    4c6c:      	mov	w10, #0x70              // =112
    4c70:      	add	x11, sp, #0x50
    4c74:      	add	x0, sp, #0x50
    4c78:      	mov	w1, #0x8                // =8
    4c7c:      	str	xzr, [sp, #0x50]
    4c80:      	add	x8, x8, x9
    4c84:      	mov	w9, #0x8                // =8
    4c88:      	ldr	x8, [sp, #0x78]
    4c8c:      	ldrb	w9, [x23, #0x1d]
    4c90:      	add	x2, x8, x9
    4c94:      	blr	x10
    4c98:      	adrp	x25, 0x4000 <perf_unwind_ruby+0x4000>
    4c9c:      	mov	x20, x29
    4ca0:      	ldr	x25, [x25]
    4ca4:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    4ca8:      	ldr	w8, [sp, #0x50]
    4cac:      	mov	w9, #0x140              // =320
    4cb0:      	mvn	w8, w8
    4cb4:      	tst	x8, x9
    4cb8:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    4cbc:      	b	0x4d98 <perf_unwind_ruby+0x4d98>
    4cc0:      	ldr	w9, [x22, #0x2c0]
    4cc4:      	adrp	x25, 0x4000 <perf_unwind_ruby+0x4000>
    4cc8:      	ldr	x25, [x25]
    4ccc:      	cmp	w9, #0x7e
    4cd0:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    4cd4:      	ldr	x10, [sp, #0x68]
    4cd8:      	add	w11, w9, #0x1
    4cdc:      	str	wzr, [sp, #0x50]
    4ce0:      	mov	x0, x29
    4ce4:      	add	x1, sp, #0x50
    4ce8:      	strh	wzr, [sp, #0x54]
    4cec:      	str	w11, [x22, #0x2c0]
    4cf0:      	mov	w11, #0x18              // =24
    4cf4:      	umaddl	x9, w9, w11, x22
    4cf8:      	str	x10, [x9, #0x2d0]
    4cfc:      	mov	w10, #0x6               // =6
    4d00:      	str	x8, [x9, #0x2d8]
    4d04:      	add	x8, x9, #0x2d0
    4d08:      	strh	w10, [x9, #0x2e0]
    4d0c:      	ldr	w11, [sp, #0x50]
    4d10:      	ldrh	w10, [sp, #0x54]
    4d14:      	stur	w11, [x8, #0x12]
    4d18:      	mov	w8, #0x36               // =54
    4d1c:      	strh	w10, [x9, #0x2e6]
    4d20:      	add	x9, sp, #0x50
    4d24:      	str	w8, [sp, #0x50]
    4d28:      	mov	w8, #0x1                // =1
    4d2c:      	blr	x8
    4d30:      	cbz	x0, 0x4d44 <perf_unwind_ruby+0x4d44>
    4d34:      	ldr	x8, [x0]
    4d38:      	add	x8, x8, #0x1
    4d3c:      	str	x8, [x0]
    4d40:      	b	0x4d98 <perf_unwind_ruby+0x4d98>
    4d44:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    4d48:      	ldr	x8, [x8]
    4d4c:      	ldr	w8, [x8]
    4d50:      	cbz	w8, 0x4d98 <perf_unwind_ruby+0x4d98>
    4d54:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    4d58:      	add	x8, x8, #0x0
    4d5c:      	add	x0, sp, #0x8
    4d60:      	ldp	x9, x10, [x8, #0x10]
    4d64:      	mov	w1, #0x2e               // =46
    4d68:      	stp	x9, x10, [sp, #0x18]
    4d6c:      	ldr	x9, [x8, #0x20]
    4d70:      	add	x10, sp, #0x8
    4d74:      	str	x9, [sp, #0x28]
    4d78:      	ldur	x9, [x8, #0x26]
    4d7c:      	stur	x9, [sp, #0x2e]
    4d80:      	ldp	x9, x8, [x8]
    4d84:      	stp	x9, x8, [sp, #0x8]
    4d88:      	mov	w8, #0x2e               // =46
    4d8c:      	mov	w9, #0x6                // =6
    4d90:      	ldr	w2, [sp, #0x50]
    4d94:      	blr	x9
    4d98:      	ldr	x8, [sp, #0x78]
    4d9c:      	ldr	x9, [sp]
    4da0:      	cmp	x9, x8
    4da4:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    4da8:      	ldrb	w9, [x23, #0x1e]
    4dac:      	str	xzr, [sp, #0x60]
    4db0:      	mov	w20, #0x8               // =8
    4db4:      	mov	w10, #0x70              // =112
    4db8:      	add	x0, sp, #0x70
    4dbc:      	mov	w1, #0x8                // =8
    4dc0:      	mov	w25, #0x70              // =112
    4dc4:      	add	x8, x8, x9
    4dc8:      	ldrb	w9, [x23, #0x1c]
    4dcc:      	stp	xzr, x8, [sp, #0x70]
    4dd0:      	add	x8, x8, x9
    4dd4:      	add	x9, sp, #0x70
    4dd8:      	ldr	x8, [sp, #0x78]
    4ddc:      	ldrb	w9, [x23, #0x1c]
    4de0:      	add	x2, x8, x9
    4de4:      	blr	x10
    4de8:      	ldr	x8, [sp, #0x78]
    4dec:      	ldrb	w9, [x23, #0x1b]
    4df0:      	add	x0, sp, #0x60
    4df4:      	mov	w1, #0x8                // =8
    4df8:      	add	x8, x8, x9
    4dfc:      	add	x9, sp, #0x60
    4e00:      	ldr	x8, [sp, #0x78]
    4e04:      	ldrb	w9, [x23, #0x1b]
    4e08:      	add	x2, x8, x9
    4e0c:      	blr	x25
    4e10:      	ldr	x8, [sp, #0x60]
    4e14:      	cbz	x8, 0x4f3c <perf_unwind_ruby+0x4f3c>
    4e18:      	ldr	x8, [sp, #0x70]
    4e1c:      	cbz	x8, 0x4f3c <perf_unwind_ruby+0x4f3c>
    4e20:      	ldrb	w9, [x23, #0x1f]
    4e24:      	mov	w10, #0x70              // =112
    4e28:      	add	x11, sp, #0x68
    4e2c:      	add	x0, sp, #0x68
    4e30:      	mov	w1, #0x8                // =8
    4e34:      	add	x8, x8, x9
    4e38:      	mov	w9, #0x8                // =8
    4e3c:      	ldr	x8, [sp, #0x70]
    4e40:      	ldrb	w9, [x23, #0x1f]
    4e44:      	add	x2, x8, x9
    4e48:      	blr	x10
    4e4c:      	adrp	x25, 0x4000 <perf_unwind_ruby+0x4000>
    4e50:      	mov	x20, x29
    4e54:      	ldr	x25, [x25]
    4e58:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    4e5c:      	ldr	x8, [sp, #0x68]
    4e60:      	ldrb	w9, [x23, #0x21]
    4e64:      	mov	w10, #0x70              // =112
    4e68:      	add	x11, sp, #0x58
    4e6c:      	add	x0, sp, #0x58
    4e70:      	mov	w1, #0x8                // =8
    4e74:      	add	x8, x8, x9
    4e78:      	mov	w9, #0x8                // =8
    4e7c:      	ldr	x8, [sp, #0x68]
    4e80:      	ldrb	w9, [x23, #0x21]
    4e84:      	add	x2, x8, x9
    4e88:      	blr	x10
    4e8c:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    4e90:      	ldr	x8, [sp, #0x68]
    4e94:      	ldrb	w9, [x23, #0x22]
    4e98:      	mov	w10, #0x70              // =112
    4e9c:      	add	x11, sp, #0x88
    4ea0:      	add	x0, sp, #0x88
    4ea4:      	mov	w1, #0x4                // =4
    4ea8:      	add	x8, x8, x9
    4eac:      	mov	w9, #0x4                // =4
    4eb0:      	ldr	x8, [sp, #0x68]
    4eb4:      	ldrb	w9, [x23, #0x22]
    4eb8:      	add	x2, x8, x9
    4ebc:      	blr	x10
    4ec0:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    4ec4:      	ldrb	w9, [x23, #0x23]
    4ec8:      	ldr	x8, [sp, #0x60]
    4ecc:      	cbz	x9, 0x4fa4 <perf_unwind_ruby+0x4fa4>
    4ed0:      	ldr	x10, [sp, #0x58]
    4ed4:      	sub	x10, x8, x10
    4ed8:      	udiv	x9, x10, x9
    4edc:      	ldr	w10, [sp, #0x88]
    4ee0:      	cmp	x9, x10
    4ee4:      	b.ls	0x4fa4 <perf_unwind_ruby+0x4fa4>
    4ee8:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    4eec:      	ldr	x8, [x8]
    4ef0:      	ldr	w8, [x8]
    4ef4:      	cbz	w8, 0x507c <perf_unwind_ruby+0x507c>
    4ef8:      	adrp	x8, 0x4000 <perf_unwind_ruby+0x4000>
    4efc:      	add	x8, x8, #0x0
    4f00:      	add	x0, sp, #0x8
    4f04:      	ldp	x9, x10, [x8, #0x10]
    4f08:      	mov	w1, #0x2d               // =45
    4f0c:      	stp	x9, x10, [sp, #0x18]
    4f10:      	ldr	x9, [x8, #0x20]
    4f14:      	add	x10, sp, #0x8
    4f18:      	str	x9, [sp, #0x28]
    4f1c:      	ldur	x9, [x8, #0x25]
    4f20:      	stur	x9, [sp, #0x2d]
    4f24:      	ldp	x9, x8, [x8]
    4f28:      	stp	x9, x8, [sp, #0x8]
    4f2c:      	mov	w8, #0x2d               // =45
    4f30:      	mov	w9, #0x6                // =6
    4f34:      	blr	x9
    4f38:      	b	0x507c <perf_unwind_ruby+0x507c>
    4f3c:      	ldr	w8, [x23]
    4f40:      	cmp	w8, w24
    4f44:      	b.lo	0x507c <perf_unwind_ruby+0x507c>
    4f48:      	ldr	x8, [sp, #0x78]
    4f4c:      	ldrb	w9, [x23, #0x1d]
    4f50:      	mov	w10, #0x70              // =112
    4f54:      	add	x11, sp, #0x50
    4f58:      	add	x0, sp, #0x50
    4f5c:      	mov	w1, #0x8                // =8
    4f60:      	str	xzr, [sp, #0x50]
    4f64:      	add	x8, x8, x9
    4f68:      	mov	w9, #0x8                // =8
    4f6c:      	ldr	x8, [sp, #0x78]
    4f70:      	ldrb	w9, [x23, #0x1d]
    4f74:      	add	x2, x8, x9
    4f78:      	blr	x10
    4f7c:      	adrp	x25, 0x4000 <perf_unwind_ruby+0x4000>
    4f80:      	mov	x20, x29
    4f84:      	ldr	x25, [x25]
    4f88:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    4f8c:      	ldr	w8, [sp, #0x50]
    4f90:      	mov	w9, #0x140              // =320
    4f94:      	mvn	w8, w8
    4f98:      	tst	x8, x9
    4f9c:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    4fa0:      	b	0x507c <perf_unwind_ruby+0x507c>
    4fa4:      	ldr	w9, [x22, #0x2c0]
    4fa8:      	adrp	x25, 0x4000 <perf_unwind_ruby+0x4000>
    4fac:      	ldr	x25, [x25]
    4fb0:      	cmp	w9, #0x7e
    4fb4:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    4fb8:      	ldr	x10, [sp, #0x68]
    4fbc:      	add	w11, w9, #0x1
    4fc0:      	str	wzr, [sp, #0x50]
    4fc4:      	mov	x0, x29
    4fc8:      	add	x1, sp, #0x50
    4fcc:      	strh	wzr, [sp, #0x54]
    4fd0:      	str	w11, [x22, #0x2c0]
    4fd4:      	mov	w11, #0x18              // =24
    4fd8:      	umaddl	x9, w9, w11, x22
    4fdc:      	str	x10, [x9, #0x2d0]
    4fe0:      	mov	w10, #0x6               // =6
    4fe4:      	str	x8, [x9, #0x2d8]
    4fe8:      	add	x8, x9, #0x2d0
    4fec:      	strh	w10, [x9, #0x2e0]
    4ff0:      	ldr	w11, [sp, #0x50]
    4ff4:      	ldrh	w10, [sp, #0x54]
    4ff8:      	stur	w11, [x8, #0x12]
    4ffc:      	mov	w8, #0x36               // =54
    5000:      	strh	w10, [x9, #0x2e6]
    5004:      	add	x9, sp, #0x50
    5008:      	str	w8, [sp, #0x50]
    500c:      	mov	w8, #0x1                // =1
    5010:      	blr	x8
    5014:      	cbz	x0, 0x5028 <perf_unwind_ruby+0x5028>
    5018:      	ldr	x8, [x0]
    501c:      	add	x8, x8, #0x1
    5020:      	str	x8, [x0]
    5024:      	b	0x507c <perf_unwind_ruby+0x507c>
    5028:      	adrp	x8, 0x5000 <perf_unwind_ruby+0x5000>
    502c:      	ldr	x8, [x8]
    5030:      	ldr	w8, [x8]
    5034:      	cbz	w8, 0x507c <perf_unwind_ruby+0x507c>
    5038:      	adrp	x8, 0x5000 <perf_unwind_ruby+0x5000>
    503c:      	add	x8, x8, #0x0
    5040:      	add	x0, sp, #0x8
    5044:      	ldp	x9, x10, [x8, #0x10]
    5048:      	mov	w1, #0x2e               // =46
    504c:      	stp	x9, x10, [sp, #0x18]
    5050:      	ldr	x9, [x8, #0x20]
    5054:      	add	x10, sp, #0x8
    5058:      	str	x9, [sp, #0x28]
    505c:      	ldur	x9, [x8, #0x26]
    5060:      	stur	x9, [sp, #0x2e]
    5064:      	ldp	x9, x8, [x8]
    5068:      	stp	x9, x8, [sp, #0x8]
    506c:      	mov	w8, #0x2e               // =46
    5070:      	mov	w9, #0x6                // =6
    5074:      	ldr	w2, [sp, #0x50]
    5078:      	blr	x9
    507c:      	ldr	x8, [sp, #0x78]
    5080:      	ldr	x9, [sp]
    5084:      	cmp	x9, x8
    5088:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    508c:      	ldrb	w9, [x23, #0x1e]
    5090:      	str	xzr, [sp, #0x60]
    5094:      	mov	w20, #0x8               // =8
    5098:      	mov	w10, #0x70              // =112
    509c:      	add	x0, sp, #0x70
    50a0:      	mov	w1, #0x8                // =8
    50a4:      	mov	w25, #0x70              // =112
    50a8:      	add	x8, x8, x9
    50ac:      	ldrb	w9, [x23, #0x1c]
    50b0:      	stp	xzr, x8, [sp, #0x70]
    50b4:      	add	x8, x8, x9
    50b8:      	add	x9, sp, #0x70
    50bc:      	ldr	x8, [sp, #0x78]
    50c0:      	ldrb	w9, [x23, #0x1c]
    50c4:      	add	x2, x8, x9
    50c8:      	blr	x10
    50cc:      	ldr	x8, [sp, #0x78]
    50d0:      	ldrb	w9, [x23, #0x1b]
    50d4:      	add	x0, sp, #0x60
    50d8:      	mov	w1, #0x8                // =8
    50dc:      	add	x8, x8, x9
    50e0:      	add	x9, sp, #0x60
    50e4:      	ldr	x8, [sp, #0x78]
    50e8:      	ldrb	w9, [x23, #0x1b]
    50ec:      	add	x2, x8, x9
    50f0:      	blr	x25
    50f4:      	ldr	x8, [sp, #0x60]
    50f8:      	cbz	x8, 0x5220 <perf_unwind_ruby+0x5220>
    50fc:      	ldr	x8, [sp, #0x70]
    5100:      	cbz	x8, 0x5220 <perf_unwind_ruby+0x5220>
    5104:      	ldrb	w9, [x23, #0x1f]
    5108:      	mov	w10, #0x70              // =112
    510c:      	add	x11, sp, #0x68
    5110:      	add	x0, sp, #0x68
    5114:      	mov	w1, #0x8                // =8
    5118:      	add	x8, x8, x9
    511c:      	mov	w9, #0x8                // =8
    5120:      	ldr	x8, [sp, #0x70]
    5124:      	ldrb	w9, [x23, #0x1f]
    5128:      	add	x2, x8, x9
    512c:      	blr	x10
    5130:      	adrp	x25, 0x5000 <perf_unwind_ruby+0x5000>
    5134:      	mov	x20, x29
    5138:      	ldr	x25, [x25]
    513c:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    5140:      	ldr	x8, [sp, #0x68]
    5144:      	ldrb	w9, [x23, #0x21]
    5148:      	mov	w10, #0x70              // =112
    514c:      	add	x11, sp, #0x58
    5150:      	add	x0, sp, #0x58
    5154:      	mov	w1, #0x8                // =8
    5158:      	add	x8, x8, x9
    515c:      	mov	w9, #0x8                // =8
    5160:      	ldr	x8, [sp, #0x68]
    5164:      	ldrb	w9, [x23, #0x21]
    5168:      	add	x2, x8, x9
    516c:      	blr	x10
    5170:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    5174:      	ldr	x8, [sp, #0x68]
    5178:      	ldrb	w9, [x23, #0x22]
    517c:      	mov	w10, #0x70              // =112
    5180:      	add	x11, sp, #0x88
    5184:      	add	x0, sp, #0x88
    5188:      	mov	w1, #0x4                // =4
    518c:      	add	x8, x8, x9
    5190:      	mov	w9, #0x4                // =4
    5194:      	ldr	x8, [sp, #0x68]
    5198:      	ldrb	w9, [x23, #0x22]
    519c:      	add	x2, x8, x9
    51a0:      	blr	x10
    51a4:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    51a8:      	ldrb	w9, [x23, #0x23]
    51ac:      	ldr	x8, [sp, #0x60]
    51b0:      	cbz	x9, 0x5288 <perf_unwind_ruby+0x5288>
    51b4:      	ldr	x10, [sp, #0x58]
    51b8:      	sub	x10, x8, x10
    51bc:      	udiv	x9, x10, x9
    51c0:      	ldr	w10, [sp, #0x88]
    51c4:      	cmp	x9, x10
    51c8:      	b.ls	0x5288 <perf_unwind_ruby+0x5288>
    51cc:      	adrp	x8, 0x5000 <perf_unwind_ruby+0x5000>
    51d0:      	ldr	x8, [x8]
    51d4:      	ldr	w8, [x8]
    51d8:      	cbz	w8, 0x5360 <perf_unwind_ruby+0x5360>
    51dc:      	adrp	x8, 0x5000 <perf_unwind_ruby+0x5000>
    51e0:      	add	x8, x8, #0x0
    51e4:      	add	x0, sp, #0x8
    51e8:      	ldp	x9, x10, [x8, #0x10]
    51ec:      	mov	w1, #0x2d               // =45
    51f0:      	stp	x9, x10, [sp, #0x18]
    51f4:      	ldr	x9, [x8, #0x20]
    51f8:      	add	x10, sp, #0x8
    51fc:      	str	x9, [sp, #0x28]
    5200:      	ldur	x9, [x8, #0x25]
    5204:      	stur	x9, [sp, #0x2d]
    5208:      	ldp	x9, x8, [x8]
    520c:      	stp	x9, x8, [sp, #0x8]
    5210:      	mov	w8, #0x2d               // =45
    5214:      	mov	w9, #0x6                // =6
    5218:      	blr	x9
    521c:      	b	0x5360 <perf_unwind_ruby+0x5360>
    5220:      	ldr	w8, [x23]
    5224:      	cmp	w8, w24
    5228:      	b.lo	0x5360 <perf_unwind_ruby+0x5360>
    522c:      	ldr	x8, [sp, #0x78]
    5230:      	ldrb	w9, [x23, #0x1d]
    5234:      	mov	w10, #0x70              // =112
    5238:      	add	x11, sp, #0x50
    523c:      	add	x0, sp, #0x50
    5240:      	mov	w1, #0x8                // =8
    5244:      	str	xzr, [sp, #0x50]
    5248:      	add	x8, x8, x9
    524c:      	mov	w9, #0x8                // =8
    5250:      	ldr	x8, [sp, #0x78]
    5254:      	ldrb	w9, [x23, #0x1d]
    5258:      	add	x2, x8, x9
    525c:      	blr	x10
    5260:      	adrp	x25, 0x5000 <perf_unwind_ruby+0x5000>
    5264:      	mov	x20, x29
    5268:      	ldr	x25, [x25]
    526c:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    5270:      	ldr	w8, [sp, #0x50]
    5274:      	mov	w9, #0x140              // =320
    5278:      	mvn	w8, w8
    527c:      	tst	x8, x9
    5280:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    5284:      	b	0x5360 <perf_unwind_ruby+0x5360>
    5288:      	ldr	w9, [x22, #0x2c0]
    528c:      	adrp	x25, 0x5000 <perf_unwind_ruby+0x5000>
    5290:      	ldr	x25, [x25]
    5294:      	cmp	w9, #0x7e
    5298:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    529c:      	ldr	x10, [sp, #0x68]
    52a0:      	add	w11, w9, #0x1
    52a4:      	str	wzr, [sp, #0x50]
    52a8:      	mov	x0, x29
    52ac:      	add	x1, sp, #0x50
    52b0:      	strh	wzr, [sp, #0x54]
    52b4:      	str	w11, [x22, #0x2c0]
    52b8:      	mov	w11, #0x18              // =24
    52bc:      	umaddl	x9, w9, w11, x22
    52c0:      	str	x10, [x9, #0x2d0]
    52c4:      	mov	w10, #0x6               // =6
    52c8:      	str	x8, [x9, #0x2d8]
    52cc:      	add	x8, x9, #0x2d0
    52d0:      	strh	w10, [x9, #0x2e0]
    52d4:      	ldr	w11, [sp, #0x50]
    52d8:      	ldrh	w10, [sp, #0x54]
    52dc:      	stur	w11, [x8, #0x12]
    52e0:      	mov	w8, #0x36               // =54
    52e4:      	strh	w10, [x9, #0x2e6]
    52e8:      	add	x9, sp, #0x50
    52ec:      	str	w8, [sp, #0x50]
    52f0:      	mov	w8, #0x1                // =1
    52f4:      	blr	x8
    52f8:      	cbz	x0, 0x530c <perf_unwind_ruby+0x530c>
    52fc:      	ldr	x8, [x0]
    5300:      	add	x8, x8, #0x1
    5304:      	str	x8, [x0]
    5308:      	b	0x5360 <perf_unwind_ruby+0x5360>
    530c:      	adrp	x8, 0x5000 <perf_unwind_ruby+0x5000>
    5310:      	ldr	x8, [x8]
    5314:      	ldr	w8, [x8]
    5318:      	cbz	w8, 0x5360 <perf_unwind_ruby+0x5360>
    531c:      	adrp	x8, 0x5000 <perf_unwind_ruby+0x5000>
    5320:      	add	x8, x8, #0x0
    5324:      	add	x0, sp, #0x8
    5328:      	ldp	x9, x10, [x8, #0x10]
    532c:      	mov	w1, #0x2e               // =46
    5330:      	stp	x9, x10, [sp, #0x18]
    5334:      	ldr	x9, [x8, #0x20]
    5338:      	add	x10, sp, #0x8
    533c:      	str	x9, [sp, #0x28]
    5340:      	ldur	x9, [x8, #0x26]
    5344:      	stur	x9, [sp, #0x2e]
    5348:      	ldp	x9, x8, [x8]
    534c:      	stp	x9, x8, [sp, #0x8]
    5350:      	mov	w8, #0x2e               // =46
    5354:      	mov	w9, #0x6                // =6
    5358:      	ldr	w2, [sp, #0x50]
    535c:      	blr	x9
    5360:      	ldr	x8, [sp, #0x78]
    5364:      	ldr	x9, [sp]
    5368:      	cmp	x9, x8
    536c:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    5370:      	ldrb	w9, [x23, #0x1e]
    5374:      	str	xzr, [sp, #0x60]
    5378:      	mov	w20, #0x8               // =8
    537c:      	mov	w10, #0x70              // =112
    5380:      	add	x0, sp, #0x70
    5384:      	mov	w1, #0x8                // =8
    5388:      	mov	w25, #0x70              // =112
    538c:      	add	x8, x8, x9
    5390:      	ldrb	w9, [x23, #0x1c]
    5394:      	stp	xzr, x8, [sp, #0x70]
    5398:      	add	x8, x8, x9
    539c:      	add	x9, sp, #0x70
    53a0:      	ldr	x8, [sp, #0x78]
    53a4:      	ldrb	w9, [x23, #0x1c]
    53a8:      	add	x2, x8, x9
    53ac:      	blr	x10
    53b0:      	ldr	x8, [sp, #0x78]
    53b4:      	ldrb	w9, [x23, #0x1b]
    53b8:      	add	x0, sp, #0x60
    53bc:      	mov	w1, #0x8                // =8
    53c0:      	add	x8, x8, x9
    53c4:      	add	x9, sp, #0x60
    53c8:      	ldr	x8, [sp, #0x78]
    53cc:      	ldrb	w9, [x23, #0x1b]
    53d0:      	add	x2, x8, x9
    53d4:      	blr	x25
    53d8:      	ldr	x8, [sp, #0x60]
    53dc:      	cbz	x8, 0x5504 <perf_unwind_ruby+0x5504>
    53e0:      	ldr	x8, [sp, #0x70]
    53e4:      	cbz	x8, 0x5504 <perf_unwind_ruby+0x5504>
    53e8:      	ldrb	w9, [x23, #0x1f]
    53ec:      	mov	w10, #0x70              // =112
    53f0:      	add	x11, sp, #0x68
    53f4:      	add	x0, sp, #0x68
    53f8:      	mov	w1, #0x8                // =8
    53fc:      	add	x8, x8, x9
    5400:      	mov	w9, #0x8                // =8
    5404:      	ldr	x8, [sp, #0x70]
    5408:      	ldrb	w9, [x23, #0x1f]
    540c:      	add	x2, x8, x9
    5410:      	blr	x10
    5414:      	adrp	x25, 0x5000 <perf_unwind_ruby+0x5000>
    5418:      	mov	x20, x29
    541c:      	ldr	x25, [x25]
    5420:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    5424:      	ldr	x8, [sp, #0x68]
    5428:      	ldrb	w9, [x23, #0x21]
    542c:      	mov	w10, #0x70              // =112
    5430:      	add	x11, sp, #0x58
    5434:      	add	x0, sp, #0x58
    5438:      	mov	w1, #0x8                // =8
    543c:      	add	x8, x8, x9
    5440:      	mov	w9, #0x8                // =8
    5444:      	ldr	x8, [sp, #0x68]
    5448:      	ldrb	w9, [x23, #0x21]
    544c:      	add	x2, x8, x9
    5450:      	blr	x10
    5454:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    5458:      	ldr	x8, [sp, #0x68]
    545c:      	ldrb	w9, [x23, #0x22]
    5460:      	mov	w10, #0x70              // =112
    5464:      	add	x11, sp, #0x88
    5468:      	add	x0, sp, #0x88
    546c:      	mov	w1, #0x4                // =4
    5470:      	add	x8, x8, x9
    5474:      	mov	w9, #0x4                // =4
    5478:      	ldr	x8, [sp, #0x68]
    547c:      	ldrb	w9, [x23, #0x22]
    5480:      	add	x2, x8, x9
    5484:      	blr	x10
    5488:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    548c:      	ldrb	w9, [x23, #0x23]
    5490:      	ldr	x8, [sp, #0x60]
    5494:      	cbz	x9, 0x556c <perf_unwind_ruby+0x556c>
    5498:      	ldr	x10, [sp, #0x58]
    549c:      	sub	x10, x8, x10
    54a0:      	udiv	x9, x10, x9
    54a4:      	ldr	w10, [sp, #0x88]
    54a8:      	cmp	x9, x10
    54ac:      	b.ls	0x556c <perf_unwind_ruby+0x556c>
    54b0:      	adrp	x8, 0x5000 <perf_unwind_ruby+0x5000>
    54b4:      	ldr	x8, [x8]
    54b8:      	ldr	w8, [x8]
    54bc:      	cbz	w8, 0x5644 <perf_unwind_ruby+0x5644>
    54c0:      	adrp	x8, 0x5000 <perf_unwind_ruby+0x5000>
    54c4:      	add	x8, x8, #0x0
    54c8:      	add	x0, sp, #0x8
    54cc:      	ldp	x9, x10, [x8, #0x10]
    54d0:      	mov	w1, #0x2d               // =45
    54d4:      	stp	x9, x10, [sp, #0x18]
    54d8:      	ldr	x9, [x8, #0x20]
    54dc:      	add	x10, sp, #0x8
    54e0:      	str	x9, [sp, #0x28]
    54e4:      	ldur	x9, [x8, #0x25]
    54e8:      	stur	x9, [sp, #0x2d]
    54ec:      	ldp	x9, x8, [x8]
    54f0:      	stp	x9, x8, [sp, #0x8]
    54f4:      	mov	w8, #0x2d               // =45
    54f8:      	mov	w9, #0x6                // =6
    54fc:      	blr	x9
    5500:      	b	0x5644 <perf_unwind_ruby+0x5644>
    5504:      	ldr	w8, [x23]
    5508:      	cmp	w8, w24
    550c:      	b.lo	0x5644 <perf_unwind_ruby+0x5644>
    5510:      	ldr	x8, [sp, #0x78]
    5514:      	ldrb	w9, [x23, #0x1d]
    5518:      	mov	w10, #0x70              // =112
    551c:      	add	x11, sp, #0x50
    5520:      	add	x0, sp, #0x50
    5524:      	mov	w1, #0x8                // =8
    5528:      	str	xzr, [sp, #0x50]
    552c:      	add	x8, x8, x9
    5530:      	mov	w9, #0x8                // =8
    5534:      	ldr	x8, [sp, #0x78]
    5538:      	ldrb	w9, [x23, #0x1d]
    553c:      	add	x2, x8, x9
    5540:      	blr	x10
    5544:      	adrp	x25, 0x5000 <perf_unwind_ruby+0x5000>
    5548:      	mov	x20, x29
    554c:      	ldr	x25, [x25]
    5550:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    5554:      	ldr	w8, [sp, #0x50]
    5558:      	mov	w9, #0x140              // =320
    555c:      	mvn	w8, w8
    5560:      	tst	x8, x9
    5564:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    5568:      	b	0x5644 <perf_unwind_ruby+0x5644>
    556c:      	ldr	w9, [x22, #0x2c0]
    5570:      	adrp	x25, 0x5000 <perf_unwind_ruby+0x5000>
    5574:      	ldr	x25, [x25]
    5578:      	cmp	w9, #0x7e
    557c:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    5580:      	ldr	x10, [sp, #0x68]
    5584:      	add	w11, w9, #0x1
    5588:      	str	wzr, [sp, #0x50]
    558c:      	mov	x0, x29
    5590:      	add	x1, sp, #0x50
    5594:      	strh	wzr, [sp, #0x54]
    5598:      	str	w11, [x22, #0x2c0]
    559c:      	mov	w11, #0x18              // =24
    55a0:      	umaddl	x9, w9, w11, x22
    55a4:      	str	x10, [x9, #0x2d0]
    55a8:      	mov	w10, #0x6               // =6
    55ac:      	str	x8, [x9, #0x2d8]
    55b0:      	add	x8, x9, #0x2d0
    55b4:      	strh	w10, [x9, #0x2e0]
    55b8:      	ldr	w11, [sp, #0x50]
    55bc:      	ldrh	w10, [sp, #0x54]
    55c0:      	stur	w11, [x8, #0x12]
    55c4:      	mov	w8, #0x36               // =54
    55c8:      	strh	w10, [x9, #0x2e6]
    55cc:      	add	x9, sp, #0x50
    55d0:      	str	w8, [sp, #0x50]
    55d4:      	mov	w8, #0x1                // =1
    55d8:      	blr	x8
    55dc:      	cbz	x0, 0x55f0 <perf_unwind_ruby+0x55f0>
    55e0:      	ldr	x8, [x0]
    55e4:      	add	x8, x8, #0x1
    55e8:      	str	x8, [x0]
    55ec:      	b	0x5644 <perf_unwind_ruby+0x5644>
    55f0:      	adrp	x8, 0x5000 <perf_unwind_ruby+0x5000>
    55f4:      	ldr	x8, [x8]
    55f8:      	ldr	w8, [x8]
    55fc:      	cbz	w8, 0x5644 <perf_unwind_ruby+0x5644>
    5600:      	adrp	x8, 0x5000 <perf_unwind_ruby+0x5000>
    5604:      	add	x8, x8, #0x0
    5608:      	add	x0, sp, #0x8
    560c:      	ldp	x9, x10, [x8, #0x10]
    5610:      	mov	w1, #0x2e               // =46
    5614:      	stp	x9, x10, [sp, #0x18]
    5618:      	ldr	x9, [x8, #0x20]
    561c:      	add	x10, sp, #0x8
    5620:      	str	x9, [sp, #0x28]
    5624:      	ldur	x9, [x8, #0x26]
    5628:      	stur	x9, [sp, #0x2e]
    562c:      	ldp	x9, x8, [x8]
    5630:      	stp	x9, x8, [sp, #0x8]
    5634:      	mov	w8, #0x2e               // =46
    5638:      	mov	w9, #0x6                // =6
    563c:      	ldr	w2, [sp, #0x50]
    5640:      	blr	x9
    5644:      	ldr	x8, [sp, #0x78]
    5648:      	ldr	x9, [sp]
    564c:      	cmp	x9, x8
    5650:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    5654:      	ldrb	w9, [x23, #0x1e]
    5658:      	str	xzr, [sp, #0x60]
    565c:      	mov	w20, #0x8               // =8
    5660:      	mov	w10, #0x70              // =112
    5664:      	add	x0, sp, #0x70
    5668:      	mov	w1, #0x8                // =8
    566c:      	mov	w25, #0x70              // =112
    5670:      	add	x8, x8, x9
    5674:      	ldrb	w9, [x23, #0x1c]
    5678:      	stp	xzr, x8, [sp, #0x70]
    567c:      	add	x8, x8, x9
    5680:      	add	x9, sp, #0x70
    5684:      	ldr	x8, [sp, #0x78]
    5688:      	ldrb	w9, [x23, #0x1c]
    568c:      	add	x2, x8, x9
    5690:      	blr	x10
    5694:      	ldr	x8, [sp, #0x78]
    5698:      	ldrb	w9, [x23, #0x1b]
    569c:      	add	x0, sp, #0x60
    56a0:      	mov	w1, #0x8                // =8
    56a4:      	add	x8, x8, x9
    56a8:      	add	x9, sp, #0x60
    56ac:      	ldr	x8, [sp, #0x78]
    56b0:      	ldrb	w9, [x23, #0x1b]
    56b4:      	add	x2, x8, x9
    56b8:      	blr	x25
    56bc:      	ldr	x8, [sp, #0x60]
    56c0:      	cbz	x8, 0x57e8 <perf_unwind_ruby+0x57e8>
    56c4:      	ldr	x8, [sp, #0x70]
    56c8:      	cbz	x8, 0x57e8 <perf_unwind_ruby+0x57e8>
    56cc:      	ldrb	w9, [x23, #0x1f]
    56d0:      	mov	w10, #0x70              // =112
    56d4:      	add	x11, sp, #0x68
    56d8:      	add	x0, sp, #0x68
    56dc:      	mov	w1, #0x8                // =8
    56e0:      	add	x8, x8, x9
    56e4:      	mov	w9, #0x8                // =8
    56e8:      	ldr	x8, [sp, #0x70]
    56ec:      	ldrb	w9, [x23, #0x1f]
    56f0:      	add	x2, x8, x9
    56f4:      	blr	x10
    56f8:      	adrp	x25, 0x5000 <perf_unwind_ruby+0x5000>
    56fc:      	mov	x20, x29
    5700:      	ldr	x25, [x25]
    5704:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    5708:      	ldr	x8, [sp, #0x68]
    570c:      	ldrb	w9, [x23, #0x21]
    5710:      	mov	w10, #0x70              // =112
    5714:      	add	x11, sp, #0x58
    5718:      	add	x0, sp, #0x58
    571c:      	mov	w1, #0x8                // =8
    5720:      	add	x8, x8, x9
    5724:      	mov	w9, #0x8                // =8
    5728:      	ldr	x8, [sp, #0x68]
    572c:      	ldrb	w9, [x23, #0x21]
    5730:      	add	x2, x8, x9
    5734:      	blr	x10
    5738:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    573c:      	ldr	x8, [sp, #0x68]
    5740:      	ldrb	w9, [x23, #0x22]
    5744:      	mov	w10, #0x70              // =112
    5748:      	add	x11, sp, #0x88
    574c:      	add	x0, sp, #0x88
    5750:      	mov	w1, #0x4                // =4
    5754:      	add	x8, x8, x9
    5758:      	mov	w9, #0x4                // =4
    575c:      	ldr	x8, [sp, #0x68]
    5760:      	ldrb	w9, [x23, #0x22]
    5764:      	add	x2, x8, x9
    5768:      	blr	x10
    576c:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    5770:      	ldrb	w9, [x23, #0x23]
    5774:      	ldr	x8, [sp, #0x60]
    5778:      	cbz	x9, 0x5850 <perf_unwind_ruby+0x5850>
    577c:      	ldr	x10, [sp, #0x58]
    5780:      	sub	x10, x8, x10
    5784:      	udiv	x9, x10, x9
    5788:      	ldr	w10, [sp, #0x88]
    578c:      	cmp	x9, x10
    5790:      	b.ls	0x5850 <perf_unwind_ruby+0x5850>
    5794:      	adrp	x8, 0x5000 <perf_unwind_ruby+0x5000>
    5798:      	ldr	x8, [x8]
    579c:      	ldr	w8, [x8]
    57a0:      	cbz	w8, 0x5928 <perf_unwind_ruby+0x5928>
    57a4:      	adrp	x8, 0x5000 <perf_unwind_ruby+0x5000>
    57a8:      	add	x8, x8, #0x0
    57ac:      	add	x0, sp, #0x8
    57b0:      	ldp	x9, x10, [x8, #0x10]
    57b4:      	mov	w1, #0x2d               // =45
    57b8:      	stp	x9, x10, [sp, #0x18]
    57bc:      	ldr	x9, [x8, #0x20]
    57c0:      	add	x10, sp, #0x8
    57c4:      	str	x9, [sp, #0x28]
    57c8:      	ldur	x9, [x8, #0x25]
    57cc:      	stur	x9, [sp, #0x2d]
    57d0:      	ldp	x9, x8, [x8]
    57d4:      	stp	x9, x8, [sp, #0x8]
    57d8:      	mov	w8, #0x2d               // =45
    57dc:      	mov	w9, #0x6                // =6
    57e0:      	blr	x9
    57e4:      	b	0x5928 <perf_unwind_ruby+0x5928>
    57e8:      	ldr	w8, [x23]
    57ec:      	cmp	w8, w24
    57f0:      	b.lo	0x5928 <perf_unwind_ruby+0x5928>
    57f4:      	ldr	x8, [sp, #0x78]
    57f8:      	ldrb	w9, [x23, #0x1d]
    57fc:      	mov	w10, #0x70              // =112
    5800:      	add	x11, sp, #0x50
    5804:      	add	x0, sp, #0x50
    5808:      	mov	w1, #0x8                // =8
    580c:      	str	xzr, [sp, #0x50]
    5810:      	add	x8, x8, x9
    5814:      	mov	w9, #0x8                // =8
    5818:      	ldr	x8, [sp, #0x78]
    581c:      	ldrb	w9, [x23, #0x1d]
    5820:      	add	x2, x8, x9
    5824:      	blr	x10
    5828:      	adrp	x25, 0x5000 <perf_unwind_ruby+0x5000>
    582c:      	mov	x20, x29
    5830:      	ldr	x25, [x25]
    5834:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    5838:      	ldr	w8, [sp, #0x50]
    583c:      	mov	w9, #0x140              // =320
    5840:      	mvn	w8, w8
    5844:      	tst	x8, x9
    5848:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    584c:      	b	0x5928 <perf_unwind_ruby+0x5928>
    5850:      	ldr	w9, [x22, #0x2c0]
    5854:      	adrp	x25, 0x5000 <perf_unwind_ruby+0x5000>
    5858:      	ldr	x25, [x25]
    585c:      	cmp	w9, #0x7e
    5860:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    5864:      	ldr	x10, [sp, #0x68]
    5868:      	add	w11, w9, #0x1
    586c:      	str	wzr, [sp, #0x50]
    5870:      	mov	x0, x29
    5874:      	add	x1, sp, #0x50
    5878:      	strh	wzr, [sp, #0x54]
    587c:      	str	w11, [x22, #0x2c0]
    5880:      	mov	w11, #0x18              // =24
    5884:      	umaddl	x9, w9, w11, x22
    5888:      	str	x10, [x9, #0x2d0]
    588c:      	mov	w10, #0x6               // =6
    5890:      	str	x8, [x9, #0x2d8]
    5894:      	add	x8, x9, #0x2d0
    5898:      	strh	w10, [x9, #0x2e0]
    589c:      	ldr	w11, [sp, #0x50]
    58a0:      	ldrh	w10, [sp, #0x54]
    58a4:      	stur	w11, [x8, #0x12]
    58a8:      	mov	w8, #0x36               // =54
    58ac:      	strh	w10, [x9, #0x2e6]
    58b0:      	add	x9, sp, #0x50
    58b4:      	str	w8, [sp, #0x50]
    58b8:      	mov	w8, #0x1                // =1
    58bc:      	blr	x8
    58c0:      	cbz	x0, 0x58d4 <perf_unwind_ruby+0x58d4>
    58c4:      	ldr	x8, [x0]
    58c8:      	add	x8, x8, #0x1
    58cc:      	str	x8, [x0]
    58d0:      	b	0x5928 <perf_unwind_ruby+0x5928>
    58d4:      	adrp	x8, 0x5000 <perf_unwind_ruby+0x5000>
    58d8:      	ldr	x8, [x8]
    58dc:      	ldr	w8, [x8]
    58e0:      	cbz	w8, 0x5928 <perf_unwind_ruby+0x5928>
    58e4:      	adrp	x8, 0x5000 <perf_unwind_ruby+0x5000>
    58e8:      	add	x8, x8, #0x0
    58ec:      	add	x0, sp, #0x8
    58f0:      	ldp	x9, x10, [x8, #0x10]
    58f4:      	mov	w1, #0x2e               // =46
    58f8:      	stp	x9, x10, [sp, #0x18]
    58fc:      	ldr	x9, [x8, #0x20]
    5900:      	add	x10, sp, #0x8
    5904:      	str	x9, [sp, #0x28]
    5908:      	ldur	x9, [x8, #0x26]
    590c:      	stur	x9, [sp, #0x2e]
    5910:      	ldp	x9, x8, [x8]
    5914:      	stp	x9, x8, [sp, #0x8]
    5918:      	mov	w8, #0x2e               // =46
    591c:      	mov	w9, #0x6                // =6
    5920:      	ldr	w2, [sp, #0x50]
    5924:      	blr	x9
    5928:      	ldr	x8, [sp, #0x78]
    592c:      	ldr	x9, [sp]
    5930:      	cmp	x9, x8
    5934:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    5938:      	ldrb	w9, [x23, #0x1e]
    593c:      	str	xzr, [sp, #0x60]
    5940:      	mov	w20, #0x8               // =8
    5944:      	mov	w10, #0x70              // =112
    5948:      	add	x0, sp, #0x70
    594c:      	mov	w1, #0x8                // =8
    5950:      	mov	w25, #0x70              // =112
    5954:      	add	x8, x8, x9
    5958:      	ldrb	w9, [x23, #0x1c]
    595c:      	stp	xzr, x8, [sp, #0x70]
    5960:      	add	x8, x8, x9
    5964:      	add	x9, sp, #0x70
    5968:      	ldr	x8, [sp, #0x78]
    596c:      	ldrb	w9, [x23, #0x1c]
    5970:      	add	x2, x8, x9
    5974:      	blr	x10
    5978:      	ldr	x8, [sp, #0x78]
    597c:      	ldrb	w9, [x23, #0x1b]
    5980:      	add	x0, sp, #0x60
    5984:      	mov	w1, #0x8                // =8
    5988:      	add	x8, x8, x9
    598c:      	add	x9, sp, #0x60
    5990:      	ldr	x8, [sp, #0x78]
    5994:      	ldrb	w9, [x23, #0x1b]
    5998:      	add	x2, x8, x9
    599c:      	blr	x25
    59a0:      	ldr	x8, [sp, #0x60]
    59a4:      	cbz	x8, 0x5acc <perf_unwind_ruby+0x5acc>
    59a8:      	ldr	x8, [sp, #0x70]
    59ac:      	cbz	x8, 0x5acc <perf_unwind_ruby+0x5acc>
    59b0:      	ldrb	w9, [x23, #0x1f]
    59b4:      	mov	w10, #0x70              // =112
    59b8:      	add	x11, sp, #0x68
    59bc:      	add	x0, sp, #0x68
    59c0:      	mov	w1, #0x8                // =8
    59c4:      	add	x8, x8, x9
    59c8:      	mov	w9, #0x8                // =8
    59cc:      	ldr	x8, [sp, #0x70]
    59d0:      	ldrb	w9, [x23, #0x1f]
    59d4:      	add	x2, x8, x9
    59d8:      	blr	x10
    59dc:      	adrp	x25, 0x5000 <perf_unwind_ruby+0x5000>
    59e0:      	mov	x20, x29
    59e4:      	ldr	x25, [x25]
    59e8:      	cbnz	x0, 0x6b4 <perf_unwind_ruby+0x6b4>
    59ec:      	ldr	x8, [sp, #0x68]
    59f0:      	ldrb	w9, [x23, #0x21]
    59f4:      	mov	w10, #0x70              // =112
    59f8:      	add	x11, sp, #0x58
    59fc:      	add	x0, sp, #0x58
    5a00:      	mov	w1, #0x8                // =8
    5a04:      	add	x8, x8, x9
    5a08:      	mov	w9, #0x8                // =8
    5a0c:      	ldr	x8, [sp, #0x68]
    5a10:      	ldrb	w9, [x23, #0x21]
    5a14:      	add	x2, x8, x9
    5a18:      	blr	x10
    5a1c:      	cbnz	x0, 0xa28 <perf_unwind_ruby+0xa28>
    5a20:      	ldr	x8, [sp, #0x68]
    5a24:      	ldrb	w9, [x23, #0x22]
    5a28:      	mov	w10, #0x70              // =112
    5a2c:      	add	x11, sp, #0x88
    5a30:      	add	x0, sp, #0x88
    5a34:      	mov	w1, #0x4                // =4
    5a38:      	add	x8, x8, x9
    5a3c:      	mov	w9, #0x4                // =4
    5a40:      	ldr	x8, [sp, #0x68]
    5a44:      	ldrb	w9, [x23, #0x22]
    5a48:      	add	x2, x8, x9
    5a4c:      	blr	x10
    5a50:      	cbnz	x0, 0xd30 <perf_unwind_ruby+0xd30>
    5a54:      	ldrb	w9, [x23, #0x23]
    5a58:      	ldr	x8, [sp, #0x60]
    5a5c:      	cbz	x9, 0x5b34 <perf_unwind_ruby+0x5b34>
    5a60:      	ldr	x10, [sp, #0x58]
    5a64:      	sub	x10, x8, x10
    5a68:      	udiv	x9, x10, x9
    5a6c:      	ldr	w10, [sp, #0x88]
    5a70:      	cmp	x9, x10
    5a74:      	b.ls	0x5b34 <perf_unwind_ruby+0x5b34>
    5a78:      	adrp	x8, 0x5000 <perf_unwind_ruby+0x5000>
    5a7c:      	ldr	x8, [x8]
    5a80:      	ldr	w8, [x8]
    5a84:      	cbz	w8, 0x5c0c <perf_unwind_ruby+0x5c0c>
    5a88:      	adrp	x8, 0x5000 <perf_unwind_ruby+0x5000>
    5a8c:      	add	x8, x8, #0x0
    5a90:      	add	x0, sp, #0x8
    5a94:      	ldp	x9, x10, [x8, #0x10]
    5a98:      	mov	w1, #0x2d               // =45
    5a9c:      	stp	x9, x10, [sp, #0x18]
    5aa0:      	ldr	x9, [x8, #0x20]
    5aa4:      	add	x10, sp, #0x8
    5aa8:      	str	x9, [sp, #0x28]
    5aac:      	ldur	x9, [x8, #0x25]
    5ab0:      	stur	x9, [sp, #0x2d]
    5ab4:      	ldp	x9, x8, [x8]
    5ab8:      	stp	x9, x8, [sp, #0x8]
    5abc:      	mov	w8, #0x2d               // =45
    5ac0:      	mov	w9, #0x6                // =6
    5ac4:      	blr	x9
    5ac8:      	b	0x5c0c <perf_unwind_ruby+0x5c0c>
    5acc:      	ldr	w8, [x23]
    5ad0:      	cmp	w8, w24
    5ad4:      	b.lo	0x5c0c <perf_unwind_ruby+0x5c0c>
    5ad8:      	ldr	x8, [sp, #0x78]
    5adc:      	ldrb	w9, [x23, #0x1d]
    5ae0:      	mov	w10, #0x70              // =112
    5ae4:      	add	x11, sp, #0x50
    5ae8:      	add	x0, sp, #0x50
    5aec:      	mov	w1, #0x8                // =8
    5af0:      	str	xzr, [sp, #0x50]
    5af4:      	add	x8, x8, x9
    5af8:      	mov	w9, #0x8                // =8
    5afc:      	ldr	x8, [sp, #0x78]
    5b00:      	ldrb	w9, [x23, #0x1d]
    5b04:      	add	x2, x8, x9
    5b08:      	blr	x10
    5b0c:      	adrp	x25, 0x5000 <perf_unwind_ruby+0x5000>
    5b10:      	mov	x20, x29
    5b14:      	ldr	x25, [x25]
    5b18:      	cbnz	x0, 0x9a8 <perf_unwind_ruby+0x9a8>
    5b1c:      	ldr	w8, [sp, #0x50]
    5b20:      	mov	w9, #0x140              // =320
    5b24:      	mvn	w8, w8
    5b28:      	tst	x8, x9
    5b2c:      	b.ne	0xb0c <perf_unwind_ruby+0xb0c>
    5b30:      	b	0x5c0c <perf_unwind_ruby+0x5c0c>
    5b34:      	ldr	w9, [x22, #0x2c0]
    5b38:      	adrp	x25, 0x5000 <perf_unwind_ruby+0x5000>
    5b3c:      	ldr	x25, [x25]
    5b40:      	cmp	w9, #0x7e
    5b44:      	b.hi	0xea8 <perf_unwind_ruby+0xea8>
    5b48:      	ldr	x10, [sp, #0x68]
    5b4c:      	add	w11, w9, #0x1
    5b50:      	str	wzr, [sp, #0x50]
    5b54:      	mov	x0, x29
    5b58:      	add	x1, sp, #0x50
    5b5c:      	strh	wzr, [sp, #0x54]
    5b60:      	str	w11, [x22, #0x2c0]
    5b64:      	mov	w11, #0x18              // =24
    5b68:      	umaddl	x9, w9, w11, x22
    5b6c:      	str	x10, [x9, #0x2d0]
    5b70:      	mov	w10, #0x6               // =6
    5b74:      	str	x8, [x9, #0x2d8]
    5b78:      	add	x8, x9, #0x2d0
    5b7c:      	strh	w10, [x9, #0x2e0]
    5b80:      	ldr	w11, [sp, #0x50]
    5b84:      	ldrh	w10, [sp, #0x54]
    5b88:      	stur	w11, [x8, #0x12]
    5b8c:      	mov	w8, #0x36               // =54
    5b90:      	strh	w10, [x9, #0x2e6]
    5b94:      	add	x9, sp, #0x50
    5b98:      	str	w8, [sp, #0x50]
    5b9c:      	mov	w8, #0x1                // =1
    5ba0:      	blr	x8
    5ba4:      	cbz	x0, 0x5bb8 <perf_unwind_ruby+0x5bb8>
    5ba8:      	ldr	x8, [x0]
    5bac:      	add	x8, x8, #0x1
    5bb0:      	str	x8, [x0]
    5bb4:      	b	0x5c0c <perf_unwind_ruby+0x5c0c>
    5bb8:      	adrp	x8, 0x5000 <perf_unwind_ruby+0x5000>
    5bbc:      	ldr	x8, [x8]
    5bc0:      	ldr	w8, [x8]
    5bc4:      	cbz	w8, 0x5c0c <perf_unwind_ruby+0x5c0c>
    5bc8:      	adrp	x8, 0x5000 <perf_unwind_ruby+0x5000>
    5bcc:      	add	x8, x8, #0x0
    5bd0:      	add	x0, sp, #0x8
    5bd4:      	ldp	x9, x10, [x8, #0x10]
    5bd8:      	mov	w1, #0x2e               // =46
    5bdc:      	stp	x9, x10, [sp, #0x18]
    5be0:      	ldr	x9, [x8, #0x20]
    5be4:      	add	x10, sp, #0x8
    5be8:      	str	x9, [sp, #0x28]
    5bec:      	ldur	x9, [x8, #0x26]
    5bf0:      	stur	x9, [sp, #0x2e]
    5bf4:      	ldp	x9, x8, [x8]
    5bf8:      	stp	x9, x8, [sp, #0x8]
    5bfc:      	mov	w8, #0x2e               // =46
    5c00:      	mov	w9, #0x6                // =6
    5c04:      	ldr	w2, [sp, #0x50]
    5c08:      	blr	x9
    5c0c:      	ldr	x8, [sp, #0x78]
    5c10:      	ldr	x9, [sp]
    5c14:      	cmp	x9, x8
    5c18:      	b.ls	0x5c3c <perf_unwind_ruby+0x5c3c>
    5c1c:      	ldrb	w9, [x23, #0x1e]
    5c20:      	adrp	x25, 0x5000 <perf_unwind_ruby+0x5000>
    5c24:      	mov	w24, #0x6               // =6
    5c28:      	mov	x20, x29
    5c2c:      	add	x9, x8, x9
    5c30:      	str	x9, [sp, #0x78]
    5c34:      	ldr	x25, [x25]
    5c38:      	b	0xb20 <perf_unwind_ruby+0xb20>
    5c3c:      	adrp	x25, 0x5000 <perf_unwind_ruby+0x5000>
    5c40:      	mov	w8, wzr
    5c44:      	mov	w24, #0x1               // =1
    5c48:      	ldr	x25, [x25]
    5c4c:      	mov	x20, x29
    5c50:      	b	0x2c0 <perf_unwind_ruby+0x2c0>

Disassembly of section kprobe/unwind_ruby:

0000000000000000 <kprobe_unwind_ruby>:
       0:      	sub	sp, sp, #0xd0
       4:      	str	x29, [sp, #0x80]
       8:      	stp	x30, x25, [sp, #0x90]
       c:      	stp	x24, x23, [sp, #0xa0]
      10:      	stp	x22, x21, [sp, #0xb0]
      14:      	stp	x20, x19, [sp, #0xc0]
      18:      	str	wzr, [sp, #0x8]
      1c:      	adrp	x21, 0x0 <kprobe_unwind_ruby>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x8
      28:      	ldr	x21, [x21]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0x8
      34:      	mov	x0, x21
      38:      	blr	x8
      3c:      	cbz	x0, 0x390 <kprobe_unwind_ruby+0x390>
      40:      	ldr	w8, [x0]
      44:      	mov	x22, x0
      48:      	adrp	x0, 0x0 <kprobe_unwind_ruby>
      4c:      	add	x9, sp, #0x4c
      50:      	str	w8, [sp, #0x4c]
      54:      	mov	w8, #0x1                // =1
      58:      	add	x1, sp, #0x4c
      5c:      	ldr	x0, [x0]
      60:      	blr	x8
      64:      	adrp	x25, 0x0 <kprobe_unwind_ruby>
      68:      	adrp	x20, 0x0 <kprobe_unwind_ruby>
      6c:      	ldr	x25, [x25]
      70:      	ldr	x20, [x20]
      74:      	cbz	x0, 0x130 <kprobe_unwind_ruby+0x130>
      78:      	mov	w8, #0x35               // =53
      7c:      	add	x9, sp, #0x78
      80:      	mov	x23, x0
      84:      	str	w8, [sp, #0x78]
      88:      	mov	w8, #0x1                // =1
      8c:      	add	x1, sp, #0x78
      90:      	mov	x0, x20
      94:      	blr	x8
      98:      	cbz	x0, 0x168 <kprobe_unwind_ruby+0x168>
      9c:      	ldr	x8, [x0]
      a0:      	add	x8, x8, #0x1
      a4:      	str	x8, [x0]
      a8:      	ldr	x8, [x23, #0x8]
      ac:      	str	xzr, [sp, #0x40]
      b0:      	cbnz	x8, 0x17c <kprobe_unwind_ruby+0x17c>
      b4:      	ldr	w8, [x23]
      b8:      	cmp	w8, #0x30, lsl #12      // =0x30000
      bc:      	b.lo	0x288 <kprobe_unwind_ruby+0x288>
      c0:      	str	xzr, [sp, #0x8]
      c4:      	ldr	x8, [x23, #0x10]
      c8:      	mov	w9, #0x8                // =8
      cc:      	mov	w10, #0x70              // =112
      d0:      	add	x11, sp, #0x8
      d4:      	add	x0, sp, #0x8
      d8:      	mov	w1, #0x8                // =8
      dc:      	ldr	x2, [x23, #0x10]
      e0:      	blr	x10
      e4:      	cbnz	x0, 0x2b8 <kprobe_unwind_ruby+0x2b8>
      e8:      	ldr	x8, [sp, #0x8]
      ec:      	ldrh	w9, [x23, #0x24]
      f0:      	mov	w10, #0x70              // =112
      f4:      	add	x11, sp, #0x40
      f8:      	add	x0, sp, #0x40
      fc:      	mov	w1, #0x8                // =8
     100:      	add	x8, x8, x9
     104:      	mov	w9, #0x8                // =8
     108:      	ldr	x8, [sp, #0x8]
     10c:      	ldrh	w9, [x23, #0x24]
     110:      	add	x2, x8, x9
     114:      	blr	x10
     118:      	mov	w8, wzr
     11c:      	mov	w24, #0x1               // =1
     120:      	cbnz	x0, 0x2c0 <kprobe_unwind_ruby+0x2c0>
     124:      	ldr	x29, [sp, #0x40]
     128:      	cbnz	x29, 0x5f4 <kprobe_unwind_ruby+0x5f4>
     12c:      	b	0x2c0 <kprobe_unwind_ruby+0x2c0>
     130:      	ldr	w8, [x25]
     134:      	cbnz	w8, 0x3b0 <kprobe_unwind_ruby+0x3b0>
     138:      	mov	w8, #0x49               // =73
     13c:      	add	x9, sp, #0x78
     140:      	add	x1, sp, #0x78
     144:      	str	w8, [sp, #0x78]
     148:      	mov	w8, #0x1                // =1
     14c:      	mov	x0, x20
     150:      	blr	x8
     154:      	cbz	x0, 0x278 <kprobe_unwind_ruby+0x278>
     158:      	ldr	x8, [x0]
     15c:      	add	x8, x8, #0x1
     160:      	str	x8, [x0]
     164:      	b	0x280 <kprobe_unwind_ruby+0x280>
     168:      	ldr	w8, [x25]
     16c:      	cbnz	w8, 0x42c <kprobe_unwind_ruby+0x42c>
     170:      	ldr	x8, [x23, #0x8]
     174:      	str	xzr, [sp, #0x40]
     178:      	cbz	x8, 0xb4 <kprobe_unwind_ruby+0xb4>
     17c:      	mov	w8, #0x23               // =35
     180:      	blr	x8
     184:      	adrp	x8, 0x0 <kprobe_unwind_ruby>
     188:      	mov	w9, #0x71               // =113
     18c:      	add	x10, sp, #0x78
     190:      	ldr	x8, [x8]
     194:      	mov	w1, #0x8                // =8
     198:      	ldr	x8, [x8]
     19c:      	add	x2, x0, x8
     1a0:      	mov	w8, #0x8                // =8
     1a4:      	add	x0, sp, #0x78
     1a8:      	blr	x9
     1ac:      	cbz	x0, 0x234 <kprobe_unwind_ruby+0x234>
     1b0:      	ldr	w8, [x25]
     1b4:      	cbnz	w8, 0x3f0 <kprobe_unwind_ruby+0x3f0>
     1b8:      	mov	w8, #0x4                // =4
     1bc:      	add	x9, sp, #0x70
     1c0:      	add	x1, sp, #0x70
     1c4:      	str	w8, [sp, #0x70]
     1c8:      	mov	w8, #0x1                // =1
     1cc:      	mov	x0, x20
     1d0:      	blr	x8
     1d4:      	cbz	x0, 0x348 <kprobe_unwind_ruby+0x348>
     1d8:      	ldr	x8, [x0]
     1dc:      	add	x8, x8, #0x1
     1e0:      	str	x8, [x0]
     1e4:      	ldr	w8, [x25]
     1e8:      	cbz	w8, 0x350 <kprobe_unwind_ruby+0x350>
     1ec:      	mov	w8, #0x7075             // =28789
     1f0:      	add	x0, sp, #0x8
     1f4:      	mov	w1, #0x34               // =52
     1f8:      	movk	w8, #0xa, lsl #16
     1fc:      	str	w8, [sp, #0x38]
     200:      	adrp	x8, 0x0 <kprobe_unwind_ruby>
     204:      	add	x8, x8, #0x0
     208:      	ldp	x9, x10, [x8, #0x10]
     20c:      	stp	x9, x10, [sp, #0x18]
     210:      	ldp	x9, x10, [x8, #0x20]
     214:      	stp	x9, x10, [sp, #0x28]
     218:      	ldp	x9, x8, [x8]
     21c:      	add	x10, sp, #0x8
     220:      	stp	x9, x8, [sp, #0x8]
     224:      	mov	w8, #0x34               // =52
     228:      	mov	w9, #0x6                // =6
     22c:      	blr	x9
     230:      	b	0x350 <kprobe_unwind_ruby+0x350>
     234:      	ldr	x8, [sp, #0x78]
     238:      	ldr	x9, [x23, #0x8]
     23c:      	add	x2, x9, x8
     240:      	ldr	w8, [x25]
     244:      	cbnz	w8, 0x480 <kprobe_unwind_ruby+0x480>
     248:      	mov	w8, #0x8                // =8
     24c:      	mov	w9, #0x70               // =112
     250:      	add	x10, sp, #0x40
     254:      	add	x0, sp, #0x40
     258:      	mov	w1, #0x8                // =8
     25c:      	blr	x9
     260:      	cbnz	x0, 0x2b8 <kprobe_unwind_ruby+0x2b8>
     264:      	ldr	w8, [x25]
     268:      	cbnz	w8, 0x5ac <kprobe_unwind_ruby+0x5ac>
     26c:      	ldr	x29, [sp, #0x40]
     270:      	cbnz	x29, 0x5f4 <kprobe_unwind_ruby+0x5f4>
     274:      	b	0x2b8 <kprobe_unwind_ruby+0x2b8>
     278:      	ldr	w8, [x25]
     27c:      	cbnz	w8, 0x4cc <kprobe_unwind_ruby+0x4cc>
     280:      	mov	w8, #0xbb8              // =3000
     284:      	b	0x2bc <kprobe_unwind_ruby+0x2bc>
     288:      	ldr	x8, [x23, #0x10]
     28c:      	mov	w9, #0x8                // =8
     290:      	mov	w10, #0x70              // =112
     294:      	add	x11, sp, #0x40
     298:      	ldr	x2, [x23, #0x10]
     29c:      	add	x0, sp, #0x40
     2a0:      	mov	w1, #0x8                // =8
     2a4:      	blr	x10
     2a8:      	ldr	x29, [sp, #0x40]
     2ac:      	cmp	x0, #0x0
     2b0:      	ccmp	x29, #0x0, #0x4, eq
     2b4:      	b.ne	0x5f4 <kprobe_unwind_ruby+0x5f4>
     2b8:      	mov	w8, wzr
     2bc:      	mov	w24, #0x1               // =1
     2c0:      	str	w8, [x22, #0xf1c]
     2c4:      	str	wzr, [sp, #0x8]
     2c8:      	mov	w8, #0x1                // =1
     2cc:      	add	x9, sp, #0x8
     2d0:      	add	x1, sp, #0x8
     2d4:      	mov	x0, x21
     2d8:      	blr	x8
     2dc:      	cbz	x0, 0x32c <kprobe_unwind_ruby+0x32c>
     2e0:      	mov	w21, #0x1374            // =4980
     2e4:      	ldrb	w8, [x0, x21]
     2e8:      	cmp	w8, #0x1d
     2ec:      	b.lo	0x36c <kprobe_unwind_ruby+0x36c>
     2f0:      	mov	w8, #0x5                // =5
     2f4:      	add	x9, sp, #0x78
     2f8:      	mov	x22, x0
     2fc:      	str	w8, [x0, #0xf1c]
     300:      	mov	w8, #0x44               // =68
     304:      	add	x1, sp, #0x78
     308:      	mov	x0, x20
     30c:      	str	w8, [sp, #0x78]
     310:      	mov	w8, #0x1                // =1
     314:      	blr	x8
     318:      	cbz	x0, 0x358 <kprobe_unwind_ruby+0x358>
     31c:      	ldr	x8, [x0]
     320:      	add	x8, x8, #0x1
     324:      	str	x8, [x0]
     328:      	b	0x360 <kprobe_unwind_ruby+0x360>
     32c:      	adrp	x1, 0x0 <kprobe_unwind_ruby>
     330:      	mov	x8, xzr
     334:      	mov	w9, #0xc                // =12
     338:      	ldr	x1, [x1]
     33c:      	mov	x0, x19
     340:      	mov	w2, wzr
     344:      	b	0x38c <kprobe_unwind_ruby+0x38c>
     348:      	ldr	w8, [x25]
     34c:      	cbnz	w8, 0x514 <kprobe_unwind_ruby+0x514>
     350:      	mov	w0, wzr
     354:      	b	0x394 <kprobe_unwind_ruby+0x394>
     358:      	ldr	w8, [x25]
     35c:      	cbnz	w8, 0x564 <kprobe_unwind_ruby+0x564>
     360:      	ldrb	w8, [x22, x21]
     364:      	mov	w24, wzr
     368:      	mov	x0, x22
     36c:      	add	w8, w8, #0x1
     370:      	adrp	x1, 0x0 <kprobe_unwind_ruby>
     374:      	mov	w9, #0xc                // =12
     378:      	strb	w8, [x0, x21]
     37c:      	mov	w8, w24
     380:      	mov	x0, x19
     384:      	mov	w2, w24
     388:      	ldr	x1, [x1]
     38c:      	blr	x9
     390:      	mov	w0, #-0x1               // =-1
     394:      	ldp	x20, x19, [sp, #0xc0]
     398:      	ldr	x29, [sp, #0x80]
     39c:      	ldp	x22, x21, [sp, #0xb0]
     3a0:      	ldp	x24, x23, [sp, #0xa0]
     3a4:      	ldp	x30, x25, [sp, #0x90]
     3a8:      	add	sp, sp, #0xd0
     3ac:      	ret
     3b0:      	mov	w8, #0x6174             // =24948
     3b4:      	add	x0, sp, #0x8
     3b8:      	mov	w1, #0x1c               // =28
     3bc:      	movk	w8, #0xa, lsl #16
     3c0:      	str	w8, [sp, #0x20]
     3c4:      	adrp	x8, 0x0 <kprobe_unwind_ruby>
     3c8:      	add	x8, x8, #0x0
     3cc:      	ldp	x9, x10, [x8]
     3d0:      	ldr	x8, [x8, #0x10]
     3d4:      	stp	x9, x10, [sp, #0x8]
     3d8:      	str	x8, [sp, #0x18]
     3dc:      	mov	w8, #0x1c               // =28
     3e0:      	mov	w9, #0x6                // =6
     3e4:      	add	x10, sp, #0x8
     3e8:      	blr	x9
     3ec:      	b	0x138 <kprobe_unwind_ruby+0x138>
     3f0:      	adrp	x8, 0x0 <kprobe_unwind_ruby>
     3f4:      	add	x8, x8, #0x0
     3f8:      	add	x0, sp, #0x8
     3fc:      	ldp	x9, x10, [x8]
     400:      	mov	w1, #0x1d               // =29
     404:      	stp	x9, x10, [sp, #0x8]
     408:      	ldr	x9, [x8, #0x10]
     40c:      	ldur	x8, [x8, #0x15]
     410:      	add	x10, sp, #0x8
     414:      	str	x9, [sp, #0x18]
     418:      	stur	x8, [sp, #0x1d]
     41c:      	mov	w8, #0x1d               // =29
     420:      	mov	w9, #0x6                // =6
     424:      	blr	x9
     428:      	b	0x1b8 <kprobe_unwind_ruby+0x1b8>
     42c:      	adrp	x8, 0x0 <kprobe_unwind_ruby>
     430:      	add	x8, x8, #0x0
     434:      	add	x0, sp, #0x8
     438:      	ldp	x9, x10, [x8, #0x10]
     43c:      	mov	w1, #0x2e               // =46
     440:      	stp	x9, x10, [sp, #0x18]
     444:      	ldr	x9, [x8, #0x20]
     448:      	add	x10, sp, #0x8
     44c:      	str	x9, [sp, #0x28]
     450:      	ldur	x9, [x8, #0x26]
     454:      	stur	x9, [sp, #0x2e]
     458:      	ldp	x9, x8, [x8]
     45c:      	stp	x9, x8, [sp, #0x8]
     460:      	mov	w8, #0x2e               // =46
     464:      	mov	w9, #0x6                // =6
     468:      	ldr	w2, [sp, #0x78]
     46c:      	blr	x9
     470:      	ldr	x8, [x23, #0x8]
     474:      	str	xzr, [sp, #0x40]
     478:      	cbnz	x8, 0x17c <kprobe_unwind_ruby+0x17c>
     47c:      	b	0xb4 <kprobe_unwind_ruby+0xb4>
     480:      	adrp	x8, 0x0 <kprobe_unwind_ruby>
     484:      	add	x8, x8, #0x0
     488:      	strb	wzr, [sp, #0x38]
     48c:      	add	x0, sp, #0x8
     490:      	ldp	x9, x10, [x8, #0x10]
     494:      	mov	w1, #0x31               // =49
     498:      	mov	x3, x2
     49c:      	mov	x24, x2
     4a0:      	stp	x9, x10, [sp, #0x18]
     4a4:      	ldp	x9, x10, [x8, #0x20]
     4a8:      	stp	x9, x10, [sp, #0x28]
     4ac:      	ldp	x9, x8, [x8]
     4b0:      	add	x10, sp, #0x8
     4b4:      	stp	x9, x8, [sp, #0x8]
     4b8:      	mov	w8, #0x31               // =49
     4bc:      	mov	w9, #0x6                // =6
     4c0:      	blr	x9
     4c4:      	mov	x2, x24
     4c8:      	b	0x248 <kprobe_unwind_ruby+0x248>
     4cc:      	adrp	x8, 0x0 <kprobe_unwind_ruby>
     4d0:      	add	x8, x8, #0x0
     4d4:      	add	x0, sp, #0x8
     4d8:      	ldp	x9, x10, [x8, #0x10]
     4dc:      	mov	w1, #0x2e               // =46
     4e0:      	stp	x9, x10, [sp, #0x18]
     4e4:      	ldr	x9, [x8, #0x20]
     4e8:      	add	x10, sp, #0x8
     4ec:      	str	x9, [sp, #0x28]
     4f0:      	ldur	x9, [x8, #0x26]
     4f4:      	stur	x9, [sp, #0x2e]
     4f8:      	ldp	x9, x8, [x8]
     4fc:      	stp	x9, x8, [sp, #0x8]
     500:      	mov	w8, #0x2e               // =46
     504:      	mov	w9, #0x6                // =6
     508:      	ldr	w2, [sp, #0x78]
     50c:      	blr	x9
     510:      	b	0x280 <kprobe_unwind_ruby+0x280>
     514:      	adrp	x8, 0x0 <kprobe_unwind_ruby>
     518:      	add	x8, x8, #0x0
     51c:      	add	x0, sp, #0x8
     520:      	ldp	x9, x10, [x8, #0x10]
     524:      	mov	w1, #0x2e               // =46
     528:      	stp	x9, x10, [sp, #0x18]
     52c:      	ldr	x9, [x8, #0x20]
     530:      	add	x10, sp, #0x8
     534:      	str	x9, [sp, #0x28]
     538:      	ldur	x9, [x8, #0x26]
     53c:      	stur	x9, [sp, #0x2e]
     540:      	ldp	x9, x8, [x8]
     544:      	stp	x9, x8, [sp, #0x8]
     548:      	mov	w8, #0x2e               // =46
     54c:      	mov	w9, #0x6                // =6
     550:      	ldr	w2, [sp, #0x70]
     554:      	blr	x9
     558:      	ldr	w8, [x25]
     55c:      	cbz	w8, 0x350 <kprobe_unwind_ruby+0x350>
     560:      	b	0x1ec <kprobe_unwind_ruby+0x1ec>
     564:      	adrp	x8, 0x0 <kprobe_unwind_ruby>
     568:      	add	x8, x8, #0x0
     56c:      	add	x0, sp, #0x8
     570:      	ldp	x9, x10, [x8, #0x10]
     574:      	mov	w1, #0x2e               // =46
     578:      	stp	x9, x10, [sp, #0x18]
     57c:      	ldr	x9, [x8, #0x20]
     580:      	add	x10, sp, #0x8
     584:      	str	x9, [sp, #0x28]
     588:      	ldur	x9, [x8, #0x26]
     58c:      	stur	x9, [sp, #0x2e]
     590:      	ldp	x9, x8, [x8]
     594:      	stp	x9, x8, [sp, #0x8]
     598:      	mov	w8, #0x2e               // =46
     59c:      	mov	w9, #0x6                // =6
     5a0:      	ldr	w2, [sp, #0x78]
     5a4:      	blr	x9
     5a8:      	b	0x360 <kprobe_unwind_ruby+0x360>
     5ac:      	mov	w8, #0x786c             // =30828
     5b0:      	add	x0, sp, #0x8
     5b4:      	mov	w1, #0x1b               // =27
     5b8:      	movk	w8, #0xa, lsl #16
     5bc:      	stur	w8, [sp, #0x1f]
     5c0:      	adrp	x8, 0x0 <kprobe_unwind_ruby>
     5c4:      	add	x8, x8, #0x0
     5c8:      	ldp	x9, x10, [x8]
     5cc:      	ldr	x8, [x8, #0x10]
     5d0:      	stp	x9, x10, [sp, #0x8]
     5d4:      	str	x8, [sp, #0x18]
     5d8:      	mov	w8, #0x1b               // =27
     5dc:      	mov	w9, #0x6                // =6
     5e0:      	add	x10, sp, #0x8
     5e4:      	ldr	x2, [sp, #0x40]
     5e8:      	blr	x9
     5ec:      	ldr	x29, [sp, #0x40]
     5f0:      	cbz	x29, 0x2b8 <kprobe_unwind_ruby+0x2b8>
     5f4:      	ldr	x8, [x22, #0xf58]
     5f8:      	str	x8, [sp, #0x78]
     5fc:      	cbz	x8, 0x6ec <kprobe_unwind_ruby+0x6ec>
     600:      	ldr	x9, [x22, #0xf60]
     604:      	cbz	x9, 0x6ec <kprobe_unwind_ruby+0x6ec>
     608:      	str	x9, [sp]
     60c:      	ldrb	w9, [x23, #0x1c]
     610:      	mov	x29, x20
     614:      	mov	w20, #0x8               // =8
     618:      	mov	w10, #0x70              // =112
     61c:      	add	x0, sp, #0x70
     620:      	mov	w1, #0x8                // =8
     624:      	str	xzr, [sp, #0x60]
     628:      	str	xzr, [sp, #0x70]
     62c:      	mov	w24, #0x70              // =112
     630:      	add	x8, x8, x9
     634:      	add	x9, sp, #0x70
     638:      	ldr	x8, [sp, #0x78]
     63c:      	ldrb	w9, [x23, #0x1c]
     640:      	add	x2, x8, x9
     644:      	blr	x10
     648:      	ldr	x8, [sp, #0x78]
     64c:      	ldrb	w9, [x23, #0x1b]
     650:      	add	x0, sp, #0x60
     654:      	mov	w1, #0x8                // =8
     658:      	add	x8, x8, x9
     65c:      	add	x9, sp, #0x60
     660:      	ldr	x8, [sp, #0x78]
     664:      	ldrb	w9, [x23, #0x1b]
     668:      	add	x2, x8, x9
     66c:      	blr	x24
     670:      	ldr	x8, [sp, #0x60]
     674:      	cbz	x8, 0x758 <kprobe_unwind_ruby+0x758>
     678:      	ldr	x8, [sp, #0x70]
     67c:      	cbz	x8, 0x758 <kprobe_unwind_ruby+0x758>
     680:      	ldrb	w9, [x23, #0x1f]
     684:      	mov	w10, #0x70              // =112
     688:      	add	x11, sp, #0x68
     68c:      	add	x0, sp, #0x68
     690:      	mov	w1, #0x8                // =8
     694:      	add	x8, x8, x9
     698:      	mov	w9, #0x8                // =8
     69c:      	ldr	x8, [sp, #0x70]
     6a0:      	ldrb	w9, [x23, #0x1f]
     6a4:      	add	x2, x8, x9
     6a8:      	blr	x10
     6ac:      	mov	x20, x29
     6b0:      	cbz	x0, 0x9f4 <kprobe_unwind_ruby+0x9f4>
     6b4:      	ldr	w8, [x25]
     6b8:      	cbnz	w8, 0x171c <kprobe_unwind_ruby+0x171c>
     6bc:      	mov	w8, #0x4e               // =78
     6c0:      	add	x9, sp, #0x50
     6c4:      	add	x1, sp, #0x50
     6c8:      	str	w8, [sp, #0x50]
     6cc:      	mov	w8, #0x1                // =1
     6d0:      	mov	x0, x20
     6d4:      	blr	x8
     6d8:      	cbz	x0, 0xa60 <kprobe_unwind_ruby+0xa60>
     6dc:      	ldr	x8, [x0]
     6e0:      	add	x8, x8, #0x1
     6e4:      	str	x8, [x0]
     6e8:      	b	0xa68 <kprobe_unwind_ruby+0xa68>
     6ec:      	ldrb	w8, [x23, #0x18]
     6f0:      	mov	w9, #0x8                // =8
     6f4:      	mov	w10, #0x70              // =112
     6f8:      	add	x11, sp, #0x70
     6fc:      	add	x0, sp, #0x70
     700:      	mov	w1, #0x8                // =8
     704:      	add	x8, x29, x8
     708:      	ldrb	w8, [x23, #0x18]
     70c:      	add	x2, x29, x8
     710:      	blr	x10
     714:      	cbz	x0, 0x904 <kprobe_unwind_ruby+0x904>
     718:      	ldr	w8, [x25]
     71c:      	cbnz	w8, 0x16d4 <kprobe_unwind_ruby+0x16d4>
     720:      	mov	w8, #0x4a               // =74
     724:      	add	x9, sp, #0x60
     728:      	add	x1, sp, #0x60
     72c:      	str	w8, [sp, #0x60]
     730:      	mov	w8, #0x1                // =1
     734:      	mov	x0, x20
     738:      	blr	x8
     73c:      	cbz	x0, 0x9e0 <kprobe_unwind_ruby+0x9e0>
     740:      	ldr	x8, [x0]
     744:      	mov	w24, wzr
     748:      	add	x8, x8, #0x1
     74c:      	str	x8, [x0]
     750:      	mov	w8, #0xbb9              // =3001
     754:      	b	0x2c0 <kprobe_unwind_ruby+0x2c0>
     758:      	ldr	w8, [x23]
     75c:      	mov	x20, x29
     760:      	lsr	w8, w8, #9
     764:      	cmp	w8, #0x103
     768:      	b.hs	0x970 <kprobe_unwind_ruby+0x970>
     76c:      	ldr	x8, [sp, #0x78]
     770:      	ldr	x9, [sp]
     774:      	cmp	x9, x8
     778:      	b.ls	0x2b8 <kprobe_unwind_ruby+0x2b8>
     77c:      	ldrb	w9, [x23, #0x1e]
     780:      	str	xzr, [sp, #0x60]
     784:      	mov	w20, #0x8               // =8
     788:      	mov	w10, #0x70              // =112
     78c:      	add	x0, sp, #0x70
     790:      	mov	w1, #0x8                // =8
     794:      	mov	w24, #0x70              // =112
     798:      	add	x8, x8, x9
     79c:      	ldrb	w9, [x23, #0x1c]
     7a0:      	stp	xzr, x8, [sp, #0x70]
     7a4:      	add	x8, x8, x9
     7a8:      	add	x9, sp, #0x70
     7ac:      	ldr	x8, [sp, #0x78]
     7b0:      	ldrb	w9, [x23, #0x1c]
     7b4:      	add	x2, x8, x9
     7b8:      	blr	x10
     7bc:      	ldr	x8, [sp, #0x78]
     7c0:      	ldrb	w9, [x23, #0x1b]
     7c4:      	add	x0, sp, #0x60
     7c8:      	mov	w1, #0x8                // =8
     7cc:      	add	x8, x8, x9
     7d0:      	add	x9, sp, #0x60
     7d4:      	ldr	x8, [sp, #0x78]
     7d8:      	ldrb	w9, [x23, #0x1b]
     7dc:      	add	x2, x8, x9
     7e0:      	blr	x24
     7e4:      	ldr	x8, [sp, #0x60]
     7e8:      	cbz	x8, 0xb48 <kprobe_unwind_ruby+0xb48>
     7ec:      	ldr	x8, [sp, #0x70]
     7f0:      	cbz	x8, 0xb48 <kprobe_unwind_ruby+0xb48>
     7f4:      	ldrb	w9, [x23, #0x1f]
     7f8:      	mov	w10, #0x70              // =112
     7fc:      	add	x11, sp, #0x68
     800:      	add	x0, sp, #0x68
     804:      	mov	w1, #0x8                // =8
     808:      	add	x8, x8, x9
     80c:      	mov	w9, #0x8                // =8
     810:      	ldr	x8, [sp, #0x70]
     814:      	ldrb	w9, [x23, #0x1f]
     818:      	add	x2, x8, x9
     81c:      	blr	x10
     820:      	mov	x20, x29
     824:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
     828:      	ldr	x8, [sp, #0x68]
     82c:      	ldrb	w9, [x23, #0x21]
     830:      	mov	w10, #0x70              // =112
     834:      	add	x11, sp, #0x58
     838:      	add	x0, sp, #0x58
     83c:      	mov	w1, #0x8                // =8
     840:      	add	x8, x8, x9
     844:      	mov	w9, #0x8                // =8
     848:      	ldr	x8, [sp, #0x68]
     84c:      	ldrb	w9, [x23, #0x21]
     850:      	add	x2, x8, x9
     854:      	blr	x10
     858:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
     85c:      	ldr	x8, [sp, #0x68]
     860:      	ldrb	w9, [x23, #0x22]
     864:      	mov	w10, #0x70              // =112
     868:      	add	x11, sp, #0x88
     86c:      	add	x0, sp, #0x88
     870:      	mov	w1, #0x4                // =4
     874:      	add	x8, x8, x9
     878:      	mov	w9, #0x4                // =4
     87c:      	ldr	x8, [sp, #0x68]
     880:      	ldrb	w9, [x23, #0x22]
     884:      	add	x2, x8, x9
     888:      	blr	x10
     88c:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
     890:      	ldrb	w9, [x23, #0x23]
     894:      	ldr	x8, [sp, #0x60]
     898:      	cbz	x9, 0x1200 <kprobe_unwind_ruby+0x1200>
     89c:      	ldr	x10, [sp, #0x58]
     8a0:      	sub	x10, x8, x10
     8a4:      	udiv	x9, x10, x9
     8a8:      	ldr	w10, [sp, #0x88]
     8ac:      	cmp	x9, x10
     8b0:      	b.ls	0x1200 <kprobe_unwind_ruby+0x1200>
     8b4:      	ldr	w8, [x25]
     8b8:      	mov	x20, x29
     8bc:      	cbz	w8, 0xb5c <kprobe_unwind_ruby+0xb5c>
     8c0:      	adrp	x8, 0x0 <kprobe_unwind_ruby>
     8c4:      	add	x8, x8, #0x0
     8c8:      	add	x0, sp, #0x8
     8cc:      	ldp	x9, x10, [x8, #0x10]
     8d0:      	mov	w1, #0x2d               // =45
     8d4:      	stp	x9, x10, [sp, #0x18]
     8d8:      	ldr	x9, [x8, #0x20]
     8dc:      	add	x10, sp, #0x8
     8e0:      	str	x9, [sp, #0x28]
     8e4:      	ldur	x9, [x8, #0x25]
     8e8:      	stur	x9, [sp, #0x2d]
     8ec:      	ldp	x9, x8, [x8]
     8f0:      	stp	x9, x8, [sp, #0x8]
     8f4:      	mov	w8, #0x2d               // =45
     8f8:      	mov	w9, #0x6                // =6
     8fc:      	blr	x9
     900:      	b	0xb5c <kprobe_unwind_ruby+0xb5c>
     904:      	ldrb	w8, [x23, #0x19]
     908:      	mov	w9, #0x8                // =8
     90c:      	mov	w10, #0x70              // =112
     910:      	add	x11, sp, #0x68
     914:      	add	x0, sp, #0x68
     918:      	mov	w1, #0x8                // =8
     91c:      	add	x8, x29, x8
     920:      	ldrb	w8, [x23, #0x19]
     924:      	add	x2, x29, x8
     928:      	blr	x10
     92c:      	cbz	x0, 0xa74 <kprobe_unwind_ruby+0xa74>
     930:      	ldr	w8, [x25]
     934:      	cbnz	w8, 0x17b4 <kprobe_unwind_ruby+0x17b4>
     938:      	mov	w8, #0x4b               // =75
     93c:      	add	x9, sp, #0x60
     940:      	add	x1, sp, #0x60
     944:      	str	w8, [sp, #0x60]
     948:      	mov	w8, #0x1                // =1
     94c:      	mov	x0, x20
     950:      	blr	x8
     954:      	cbz	x0, 0xb34 <kprobe_unwind_ruby+0xb34>
     958:      	ldr	x8, [x0]
     95c:      	mov	w24, wzr
     960:      	add	x8, x8, #0x1
     964:      	str	x8, [x0]
     968:      	mov	w8, #0xbba              // =3002
     96c:      	b	0x2c0 <kprobe_unwind_ruby+0x2c0>
     970:      	ldr	x8, [sp, #0x78]
     974:      	ldrb	w9, [x23, #0x1d]
     978:      	mov	w10, #0x70              // =112
     97c:      	add	x11, sp, #0x50
     980:      	add	x0, sp, #0x50
     984:      	mov	w1, #0x8                // =8
     988:      	str	xzr, [sp, #0x50]
     98c:      	add	x8, x8, x9
     990:      	mov	w9, #0x8                // =8
     994:      	ldr	x8, [sp, #0x78]
     998:      	ldrb	w9, [x23, #0x1d]
     99c:      	add	x2, x8, x9
     9a0:      	blr	x10
     9a4:      	cbz	x0, 0xaf8 <kprobe_unwind_ruby+0xaf8>
     9a8:      	ldr	w8, [x25]
     9ac:      	cbnz	w8, 0x1830 <kprobe_unwind_ruby+0x1830>
     9b0:      	mov	w8, #0x4d               // =77
     9b4:      	add	x9, sp, #0x8c
     9b8:      	add	x1, sp, #0x8c
     9bc:      	str	w8, [sp, #0x8c]
     9c0:      	mov	w8, #0x1                // =1
     9c4:      	mov	x0, x20
     9c8:      	blr	x8
     9cc:      	cbz	x0, 0xd68 <kprobe_unwind_ruby+0xd68>
     9d0:      	ldr	x8, [x0]
     9d4:      	add	x8, x8, #0x1
     9d8:      	str	x8, [x0]
     9dc:      	b	0xd70 <kprobe_unwind_ruby+0xd70>
     9e0:      	ldr	w8, [x25]
     9e4:      	cbnz	w8, 0x17e8 <kprobe_unwind_ruby+0x17e8>
     9e8:      	mov	w8, #0xbb9              // =3001
     9ec:      	mov	w24, wzr
     9f0:      	b	0x2c0 <kprobe_unwind_ruby+0x2c0>
     9f4:      	ldr	x8, [sp, #0x68]
     9f8:      	ldrb	w9, [x23, #0x21]
     9fc:      	mov	w10, #0x70              // =112
     a00:      	add	x11, sp, #0x58
     a04:      	add	x0, sp, #0x58
     a08:      	mov	w1, #0x8                // =8
     a0c:      	add	x8, x8, x9
     a10:      	mov	w9, #0x8                // =8
     a14:      	ldr	x8, [sp, #0x68]
     a18:      	ldrb	w9, [x23, #0x21]
     a1c:      	add	x2, x8, x9
     a20:      	blr	x10
     a24:      	cbz	x0, 0xcfc <kprobe_unwind_ruby+0xcfc>
     a28:      	ldr	w8, [x25]
     a2c:      	cbnz	w8, 0x18fc <kprobe_unwind_ruby+0x18fc>
     a30:      	mov	w8, #0x4f               // =79
     a34:      	add	x9, sp, #0x50
     a38:      	add	x1, sp, #0x50
     a3c:      	str	w8, [sp, #0x50]
     a40:      	mov	w8, #0x1                // =1
     a44:      	mov	x0, x20
     a48:      	blr	x8
     a4c:      	cbz	x0, 0xd7c <kprobe_unwind_ruby+0xd7c>
     a50:      	ldr	x8, [x0]
     a54:      	add	x8, x8, #0x1
     a58:      	str	x8, [x0]
     a5c:      	b	0xd84 <kprobe_unwind_ruby+0xd84>
     a60:      	ldr	w8, [x25]
     a64:      	cbnz	w8, 0x1938 <kprobe_unwind_ruby+0x1938>
     a68:      	mov	w24, wzr
     a6c:      	mov	w8, #0xbbd              // =3005
     a70:      	b	0x2c0 <kprobe_unwind_ruby+0x2c0>
     a74:      	ldp	x20, x8, [sp, #0x68]
     a78:      	mov	w9, #0x8                // =8
     a7c:      	mov	w10, #0x70              // =112
     a80:      	add	x11, sp, #0x78
     a84:      	add	x0, sp, #0x78
     a88:      	ldrb	w25, [x23, #0x23]
     a8c:      	mov	w1, #0x8                // =8
     a90:      	ldrb	w24, [x23, #0x1e]
     a94:      	str	x8, [sp]
     a98:      	ldrb	w8, [x23, #0x1a]
     a9c:      	add	x8, x29, x8
     aa0:      	ldrb	w8, [x23, #0x1a]
     aa4:      	add	x2, x29, x8
     aa8:      	blr	x10
     aac:      	cbz	x0, 0xd90 <kprobe_unwind_ruby+0xd90>
     ab0:      	adrp	x25, 0x0 <kprobe_unwind_ruby>
     ab4:      	ldr	x25, [x25]
     ab8:      	ldr	w8, [x25]
     abc:      	cbnz	w8, 0x1b34 <kprobe_unwind_ruby+0x1b34>
     ac0:      	mov	w8, #0x4c               // =76
     ac4:      	adrp	x20, 0x0 <kprobe_unwind_ruby>
     ac8:      	add	x9, sp, #0x60
     acc:      	str	w8, [sp, #0x60]
     ad0:      	mov	w8, #0x1                // =1
     ad4:      	add	x1, sp, #0x60
     ad8:      	ldr	x20, [x20]
     adc:      	mov	x0, x20
     ae0:      	blr	x8
     ae4:      	cbz	x0, 0xe04 <kprobe_unwind_ruby+0xe04>
     ae8:      	ldr	x8, [x0]
     aec:      	add	x8, x8, #0x1
     af0:      	str	x8, [x0]
     af4:      	b	0xe0c <kprobe_unwind_ruby+0xe0c>
     af8:      	ldr	w8, [sp, #0x50]
     afc:      	mov	w9, #0x140              // =320
     b00:      	mvn	w8, w8
     b04:      	tst	x8, x9
     b08:      	b.eq	0x76c <kprobe_unwind_ruby+0x76c>
     b0c:      	ldrb	w8, [x23, #0x1e]
     b10:      	ldr	x9, [sp, #0x78]
     b14:      	mov	w24, #0x1               // =1
     b18:      	add	x9, x9, x8
     b1c:      	str	x9, [sp, #0x78]
     b20:      	str	x9, [x22, #0xf58]
     b24:      	ldr	x9, [sp]
     b28:      	mov	w8, wzr
     b2c:      	str	x9, [x22, #0xf60]
     b30:      	b	0x2c0 <kprobe_unwind_ruby+0x2c0>
     b34:      	ldr	w8, [x25]
     b38:      	cbnz	w8, 0x1b6c <kprobe_unwind_ruby+0x1b6c>
     b3c:      	mov	w8, #0xbba              // =3002
     b40:      	mov	w24, wzr
     b44:      	b	0x2c0 <kprobe_unwind_ruby+0x2c0>
     b48:      	ldr	w8, [x23]
     b4c:      	mov	x20, x29
     b50:      	lsr	w8, w8, #9
     b54:      	cmp	w8, #0x103
     b58:      	b.hs	0xdb4 <kprobe_unwind_ruby+0xdb4>
     b5c:      	ldr	x8, [sp, #0x78]
     b60:      	ldr	x9, [sp]
     b64:      	cmp	x9, x8
     b68:      	b.ls	0x2b8 <kprobe_unwind_ruby+0x2b8>
     b6c:      	ldrb	w9, [x23, #0x1e]
     b70:      	str	xzr, [sp, #0x60]
     b74:      	mov	w20, #0x8               // =8
     b78:      	mov	w10, #0x70              // =112
     b7c:      	add	x0, sp, #0x70
     b80:      	mov	w1, #0x8                // =8
     b84:      	mov	w24, #0x70              // =112
     b88:      	add	x8, x8, x9
     b8c:      	ldrb	w9, [x23, #0x1c]
     b90:      	stp	xzr, x8, [sp, #0x70]
     b94:      	add	x8, x8, x9
     b98:      	add	x9, sp, #0x70
     b9c:      	ldr	x8, [sp, #0x78]
     ba0:      	ldrb	w9, [x23, #0x1c]
     ba4:      	add	x2, x8, x9
     ba8:      	blr	x10
     bac:      	ldr	x8, [sp, #0x78]
     bb0:      	ldrb	w9, [x23, #0x1b]
     bb4:      	add	x0, sp, #0x60
     bb8:      	mov	w1, #0x8                // =8
     bbc:      	add	x8, x8, x9
     bc0:      	add	x9, sp, #0x60
     bc4:      	ldr	x8, [sp, #0x78]
     bc8:      	ldrb	w9, [x23, #0x1b]
     bcc:      	add	x2, x8, x9
     bd0:      	blr	x24
     bd4:      	ldr	x8, [sp, #0x60]
     bd8:      	cbz	x8, 0xf28 <kprobe_unwind_ruby+0xf28>
     bdc:      	ldr	x8, [sp, #0x70]
     be0:      	cbz	x8, 0xf28 <kprobe_unwind_ruby+0xf28>
     be4:      	ldrb	w9, [x23, #0x1f]
     be8:      	mov	w10, #0x70              // =112
     bec:      	add	x11, sp, #0x68
     bf0:      	add	x0, sp, #0x68
     bf4:      	mov	w1, #0x8                // =8
     bf8:      	add	x8, x8, x9
     bfc:      	mov	w9, #0x8                // =8
     c00:      	ldr	x8, [sp, #0x70]
     c04:      	ldrb	w9, [x23, #0x1f]
     c08:      	add	x2, x8, x9
     c0c:      	blr	x10
     c10:      	mov	x20, x29
     c14:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
     c18:      	ldr	x8, [sp, #0x68]
     c1c:      	ldrb	w9, [x23, #0x21]
     c20:      	mov	w10, #0x70              // =112
     c24:      	add	x11, sp, #0x58
     c28:      	add	x0, sp, #0x58
     c2c:      	mov	w1, #0x8                // =8
     c30:      	add	x8, x8, x9
     c34:      	mov	w9, #0x8                // =8
     c38:      	ldr	x8, [sp, #0x68]
     c3c:      	ldrb	w9, [x23, #0x21]
     c40:      	add	x2, x8, x9
     c44:      	blr	x10
     c48:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
     c4c:      	ldr	x8, [sp, #0x68]
     c50:      	ldrb	w9, [x23, #0x22]
     c54:      	mov	w10, #0x70              // =112
     c58:      	add	x11, sp, #0x88
     c5c:      	add	x0, sp, #0x88
     c60:      	mov	w1, #0x4                // =4
     c64:      	add	x8, x8, x9
     c68:      	mov	w9, #0x4                // =4
     c6c:      	ldr	x8, [sp, #0x68]
     c70:      	ldrb	w9, [x23, #0x22]
     c74:      	add	x2, x8, x9
     c78:      	blr	x10
     c7c:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
     c80:      	ldrb	w9, [x23, #0x23]
     c84:      	ldr	x8, [sp, #0x60]
     c88:      	mov	x20, x25
     c8c:      	cbz	x9, 0x14a0 <kprobe_unwind_ruby+0x14a0>
     c90:      	ldr	x10, [sp, #0x58]
     c94:      	sub	x10, x8, x10
     c98:      	udiv	x9, x10, x9
     c9c:      	ldr	w10, [sp, #0x88]
     ca0:      	cmp	x9, x10
     ca4:      	b.ls	0x14a0 <kprobe_unwind_ruby+0x14a0>
     ca8:      	ldr	w8, [x20]
     cac:      	mov	x25, x20
     cb0:      	mov	x20, x29
     cb4:      	cbz	w8, 0xf3c <kprobe_unwind_ruby+0xf3c>
     cb8:      	adrp	x8, 0x0 <kprobe_unwind_ruby>
     cbc:      	add	x8, x8, #0x0
     cc0:      	add	x0, sp, #0x8
     cc4:      	ldp	x9, x10, [x8, #0x10]
     cc8:      	mov	w1, #0x2d               // =45
     ccc:      	stp	x9, x10, [sp, #0x18]
     cd0:      	ldr	x9, [x8, #0x20]
     cd4:      	add	x10, sp, #0x8
     cd8:      	str	x9, [sp, #0x28]
     cdc:      	ldur	x9, [x8, #0x25]
     ce0:      	stur	x9, [sp, #0x2d]
     ce4:      	ldp	x9, x8, [x8]
     ce8:      	stp	x9, x8, [sp, #0x8]
     cec:      	mov	w8, #0x2d               // =45
     cf0:      	mov	w9, #0x6                // =6
     cf4:      	blr	x9
     cf8:      	b	0xf3c <kprobe_unwind_ruby+0xf3c>
     cfc:      	ldr	x8, [sp, #0x68]
     d00:      	ldrb	w9, [x23, #0x22]
     d04:      	mov	w10, #0x70              // =112
     d08:      	add	x11, sp, #0x88
     d0c:      	add	x0, sp, #0x88
     d10:      	mov	w1, #0x4                // =4
     d14:      	add	x8, x8, x9
     d18:      	mov	w9, #0x4                // =4
     d1c:      	ldr	x8, [sp, #0x68]
     d20:      	ldrb	w9, [x23, #0x22]
     d24:      	add	x2, x8, x9
     d28:      	blr	x10
     d2c:      	cbz	x0, 0xe18 <kprobe_unwind_ruby+0xe18>
     d30:      	ldr	w8, [x25]
     d34:      	cbnz	w8, 0x1bfc <kprobe_unwind_ruby+0x1bfc>
     d38:      	mov	w8, #0x50               // =80
     d3c:      	add	x9, sp, #0x50
     d40:      	add	x1, sp, #0x50
     d44:      	str	w8, [sp, #0x50]
     d48:      	mov	w8, #0x1                // =1
     d4c:      	mov	x0, x20
     d50:      	blr	x8
     d54:      	cbz	x0, 0xe88 <kprobe_unwind_ruby+0xe88>
     d58:      	ldr	x8, [x0]
     d5c:      	add	x8, x8, #0x1
     d60:      	str	x8, [x0]
     d64:      	b	0xe90 <kprobe_unwind_ruby+0xe90>
     d68:      	ldr	w8, [x25]
     d6c:      	cbnz	w8, 0x1bb4 <kprobe_unwind_ruby+0x1bb4>
     d70:      	mov	w24, wzr
     d74:      	mov	w8, #0xbbc              // =3004
     d78:      	b	0x2c0 <kprobe_unwind_ruby+0x2c0>
     d7c:      	ldr	w8, [x25]
     d80:      	cbnz	w8, 0x1c38 <kprobe_unwind_ruby+0x1c38>
     d84:      	mov	w24, wzr
     d88:      	mov	w8, #0xbbe              // =3006
     d8c:      	b	0x2c0 <kprobe_unwind_ruby+0x2c0>
     d90:      	ldr	x8, [sp]
     d94:      	madd	x8, x20, x25, x8
     d98:      	adrp	x25, 0x0 <kprobe_unwind_ruby>
     d9c:      	adrp	x20, 0x0 <kprobe_unwind_ruby>
     da0:      	sub	x9, x8, x24, lsl #1
     da4:      	ldr	x8, [sp, #0x78]
     da8:      	ldr	x25, [x25]
     dac:      	ldr	x20, [x20]
     db0:      	b	0x608 <kprobe_unwind_ruby+0x608>
     db4:      	ldr	x8, [sp, #0x78]
     db8:      	ldrb	w9, [x23, #0x1d]
     dbc:      	mov	w10, #0x70              // =112
     dc0:      	add	x11, sp, #0x50
     dc4:      	add	x0, sp, #0x50
     dc8:      	mov	w1, #0x8                // =8
     dcc:      	str	xzr, [sp, #0x50]
     dd0:      	add	x8, x8, x9
     dd4:      	mov	w9, #0x8                // =8
     dd8:      	ldr	x8, [sp, #0x78]
     ddc:      	ldrb	w9, [x23, #0x1d]
     de0:      	add	x2, x8, x9
     de4:      	blr	x10
     de8:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
     dec:      	ldr	w8, [sp, #0x50]
     df0:      	mov	w9, #0x140              // =320
     df4:      	mvn	w8, w8
     df8:      	tst	x8, x9
     dfc:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
     e00:      	b	0xb5c <kprobe_unwind_ruby+0xb5c>
     e04:      	ldr	w8, [x25]
     e08:      	cbnz	w8, 0x1cdc <kprobe_unwind_ruby+0x1cdc>
     e0c:      	mov	w8, #0xbbb              // =3003
     e10:      	mov	w24, wzr
     e14:      	b	0x2c0 <kprobe_unwind_ruby+0x2c0>
     e18:      	ldrb	w9, [x23, #0x23]
     e1c:      	ldr	x8, [sp, #0x60]
     e20:      	cbz	x9, 0xe9c <kprobe_unwind_ruby+0xe9c>
     e24:      	ldr	x10, [sp, #0x58]
     e28:      	sub	x10, x8, x10
     e2c:      	udiv	x9, x10, x9
     e30:      	ldr	w10, [sp, #0x88]
     e34:      	cmp	x9, x10
     e38:      	b.ls	0xe9c <kprobe_unwind_ruby+0xe9c>
     e3c:      	ldr	w8, [x25]
     e40:      	cbz	w8, 0x76c <kprobe_unwind_ruby+0x76c>
     e44:      	adrp	x8, 0x0 <kprobe_unwind_ruby>
     e48:      	add	x8, x8, #0x0
     e4c:      	add	x0, sp, #0x8
     e50:      	ldp	x9, x10, [x8, #0x10]
     e54:      	mov	w1, #0x2d               // =45
     e58:      	stp	x9, x10, [sp, #0x18]
     e5c:      	ldr	x9, [x8, #0x20]
     e60:      	add	x10, sp, #0x8
     e64:      	str	x9, [sp, #0x28]
     e68:      	ldur	x9, [x8, #0x25]
     e6c:      	stur	x9, [sp, #0x2d]
     e70:      	ldp	x9, x8, [x8]
     e74:      	stp	x9, x8, [sp, #0x8]
     e78:      	mov	w8, #0x2d               // =45
     e7c:      	mov	w9, #0x6                // =6
     e80:      	blr	x9
     e84:      	b	0x76c <kprobe_unwind_ruby+0x76c>
     e88:      	ldr	w8, [x25]
     e8c:      	cbnz	w8, 0x1e00 <kprobe_unwind_ruby+0x1e00>
     e90:      	mov	w24, wzr
     e94:      	mov	w8, #0xbbf              // =3007
     e98:      	b	0x2c0 <kprobe_unwind_ruby+0x2c0>
     e9c:      	ldr	w9, [x22, #0x2c0]
     ea0:      	cmp	w9, #0x7f
     ea4:      	b.lo	0x10d8 <kprobe_unwind_ruby+0x10d8>
     ea8:      	ldr	w8, [x25]
     eac:      	cbnz	w8, 0x1ffc <kprobe_unwind_ruby+0x1ffc>
     eb0:      	mov	w8, #0x2                // =2
     eb4:      	add	x9, sp, #0x8c
     eb8:      	add	x1, sp, #0x8c
     ebc:      	str	w8, [sp, #0x8c]
     ec0:      	mov	w8, #0x1                // =1
     ec4:      	mov	x0, x29
     ec8:      	mov	x20, x29
     ecc:      	blr	x8
     ed0:      	cbz	x0, 0x119c <kprobe_unwind_ruby+0x119c>
     ed4:      	ldr	x8, [x0]
     ed8:      	add	x8, x8, #0x1
     edc:      	str	x8, [x0]
     ee0:      	ldr	w8, [x25]
     ee4:      	cbz	w8, 0x11a4 <kprobe_unwind_ruby+0x11a4>
     ee8:      	mov	w8, #0x656d             // =25965
     eec:      	add	x0, sp, #0x8
     ef0:      	mov	w1, #0x1c               // =28
     ef4:      	movk	w8, #0xa, lsl #16
     ef8:      	str	w8, [sp, #0x20]
     efc:      	adrp	x8, 0x0 <kprobe_unwind_ruby>
     f00:      	add	x8, x8, #0x0
     f04:      	ldp	x9, x10, [x8]
     f08:      	ldr	x8, [x8, #0x10]
     f0c:      	stp	x9, x10, [sp, #0x8]
     f10:      	str	x8, [sp, #0x18]
     f14:      	mov	w8, #0x1c               // =28
     f18:      	mov	w9, #0x6                // =6
     f1c:      	add	x10, sp, #0x8
     f20:      	blr	x9
     f24:      	b	0x11a4 <kprobe_unwind_ruby+0x11a4>
     f28:      	ldr	w8, [x23]
     f2c:      	mov	x20, x29
     f30:      	lsr	w8, w8, #9
     f34:      	cmp	w8, #0x103
     f38:      	b.hs	0x114c <kprobe_unwind_ruby+0x114c>
     f3c:      	ldr	x8, [sp, #0x78]
     f40:      	ldr	x9, [sp]
     f44:      	cmp	x9, x8
     f48:      	b.ls	0x2b8 <kprobe_unwind_ruby+0x2b8>
     f4c:      	ldrb	w9, [x23, #0x1e]
     f50:      	str	xzr, [sp, #0x60]
     f54:      	mov	w20, #0x8               // =8
     f58:      	mov	w10, #0x70              // =112
     f5c:      	add	x0, sp, #0x70
     f60:      	mov	w1, #0x8                // =8
     f64:      	mov	w24, #0x70              // =112
     f68:      	add	x8, x8, x9
     f6c:      	ldrb	w9, [x23, #0x1c]
     f70:      	stp	xzr, x8, [sp, #0x70]
     f74:      	add	x8, x8, x9
     f78:      	add	x9, sp, #0x70
     f7c:      	ldr	x8, [sp, #0x78]
     f80:      	ldrb	w9, [x23, #0x1c]
     f84:      	add	x2, x8, x9
     f88:      	blr	x10
     f8c:      	ldr	x8, [sp, #0x78]
     f90:      	ldrb	w9, [x23, #0x1b]
     f94:      	add	x0, sp, #0x60
     f98:      	mov	w1, #0x8                // =8
     f9c:      	add	x8, x8, x9
     fa0:      	add	x9, sp, #0x60
     fa4:      	ldr	x8, [sp, #0x78]
     fa8:      	ldrb	w9, [x23, #0x1b]
     fac:      	add	x2, x8, x9
     fb0:      	blr	x24
     fb4:      	ldr	x8, [sp, #0x60]
     fb8:      	cbz	x8, 0x1280 <kprobe_unwind_ruby+0x1280>
     fbc:      	ldr	x8, [sp, #0x70]
     fc0:      	cbz	x8, 0x1280 <kprobe_unwind_ruby+0x1280>
     fc4:      	ldrb	w9, [x23, #0x1f]
     fc8:      	mov	w10, #0x70              // =112
     fcc:      	add	x11, sp, #0x68
     fd0:      	add	x0, sp, #0x68
     fd4:      	mov	w1, #0x8                // =8
     fd8:      	add	x8, x8, x9
     fdc:      	mov	w9, #0x8                // =8
     fe0:      	ldr	x8, [sp, #0x70]
     fe4:      	ldrb	w9, [x23, #0x1f]
     fe8:      	add	x2, x8, x9
     fec:      	blr	x10
     ff0:      	mov	x20, x29
     ff4:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
     ff8:      	ldr	x8, [sp, #0x68]
     ffc:      	ldrb	w9, [x23, #0x21]
    1000:      	mov	w10, #0x70              // =112
    1004:      	add	x11, sp, #0x58
    1008:      	add	x0, sp, #0x58
    100c:      	mov	w1, #0x8                // =8
    1010:      	add	x8, x8, x9
    1014:      	mov	w9, #0x8                // =8
    1018:      	ldr	x8, [sp, #0x68]
    101c:      	ldrb	w9, [x23, #0x21]
    1020:      	add	x2, x8, x9
    1024:      	blr	x10
    1028:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    102c:      	ldr	x8, [sp, #0x68]
    1030:      	ldrb	w9, [x23, #0x22]
    1034:      	mov	w10, #0x70              // =112
    1038:      	add	x11, sp, #0x88
    103c:      	add	x0, sp, #0x88
    1040:      	mov	w1, #0x4                // =4
    1044:      	add	x8, x8, x9
    1048:      	mov	w9, #0x4                // =4
    104c:      	ldr	x8, [sp, #0x68]
    1050:      	ldrb	w9, [x23, #0x22]
    1054:      	add	x2, x8, x9
    1058:      	blr	x10
    105c:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    1060:      	ldrb	w9, [x23, #0x23]
    1064:      	ldr	x8, [sp, #0x60]
    1068:      	cbz	x9, 0x1878 <kprobe_unwind_ruby+0x1878>
    106c:      	ldr	x10, [sp, #0x58]
    1070:      	sub	x10, x8, x10
    1074:      	udiv	x9, x10, x9
    1078:      	ldr	w10, [sp, #0x88]
    107c:      	cmp	x9, x10
    1080:      	b.ls	0x1878 <kprobe_unwind_ruby+0x1878>
    1084:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1088:      	ldr	x8, [x8]
    108c:      	ldr	w8, [x8]
    1090:      	cbz	w8, 0x1290 <kprobe_unwind_ruby+0x1290>
    1094:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1098:      	add	x8, x8, #0x0
    109c:      	add	x0, sp, #0x8
    10a0:      	ldp	x9, x10, [x8, #0x10]
    10a4:      	mov	w1, #0x2d               // =45
    10a8:      	stp	x9, x10, [sp, #0x18]
    10ac:      	ldr	x9, [x8, #0x20]
    10b0:      	add	x10, sp, #0x8
    10b4:      	str	x9, [sp, #0x28]
    10b8:      	ldur	x9, [x8, #0x25]
    10bc:      	stur	x9, [sp, #0x2d]
    10c0:      	ldp	x9, x8, [x8]
    10c4:      	stp	x9, x8, [sp, #0x8]
    10c8:      	mov	w8, #0x2d               // =45
    10cc:      	mov	w9, #0x6                // =6
    10d0:      	blr	x9
    10d4:      	b	0x1290 <kprobe_unwind_ruby+0x1290>
    10d8:      	ldr	x10, [sp, #0x68]
    10dc:      	add	w11, w9, #0x1
    10e0:      	str	wzr, [sp, #0x50]
    10e4:      	add	x1, sp, #0x50
    10e8:      	mov	x0, x29
    10ec:      	mov	x20, x29
    10f0:      	str	w11, [x22, #0x2c0]
    10f4:      	mov	w11, #0x18              // =24
    10f8:      	strh	wzr, [sp, #0x54]
    10fc:      	umaddl	x9, w9, w11, x22
    1100:      	str	x10, [x9, #0x2d0]
    1104:      	mov	w10, #0x6               // =6
    1108:      	str	x8, [x9, #0x2d8]
    110c:      	add	x8, x9, #0x2d0
    1110:      	strh	w10, [x9, #0x2e0]
    1114:      	ldr	w11, [sp, #0x50]
    1118:      	ldrh	w10, [sp, #0x54]
    111c:      	stur	w11, [x8, #0x12]
    1120:      	mov	w8, #0x36               // =54
    1124:      	strh	w10, [x9, #0x2e6]
    1128:      	add	x9, sp, #0x50
    112c:      	str	w8, [sp, #0x50]
    1130:      	mov	w8, #0x1                // =1
    1134:      	blr	x8
    1138:      	cbz	x0, 0x11b0 <kprobe_unwind_ruby+0x11b0>
    113c:      	ldr	x8, [x0]
    1140:      	add	x8, x8, #0x1
    1144:      	str	x8, [x0]
    1148:      	b	0x76c <kprobe_unwind_ruby+0x76c>
    114c:      	ldr	x8, [sp, #0x78]
    1150:      	ldrb	w9, [x23, #0x1d]
    1154:      	mov	w10, #0x70              // =112
    1158:      	add	x11, sp, #0x50
    115c:      	add	x0, sp, #0x50
    1160:      	mov	w1, #0x8                // =8
    1164:      	str	xzr, [sp, #0x50]
    1168:      	add	x8, x8, x9
    116c:      	mov	w9, #0x8                // =8
    1170:      	ldr	x8, [sp, #0x78]
    1174:      	ldrb	w9, [x23, #0x1d]
    1178:      	add	x2, x8, x9
    117c:      	blr	x10
    1180:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    1184:      	ldr	w8, [sp, #0x50]
    1188:      	mov	w9, #0x140              // =320
    118c:      	mvn	w8, w8
    1190:      	tst	x8, x9
    1194:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    1198:      	b	0xf3c <kprobe_unwind_ruby+0xf3c>
    119c:      	ldr	w8, [x25]
    11a0:      	cbnz	w8, 0x20ec <kprobe_unwind_ruby+0x20ec>
    11a4:      	mov	w24, wzr
    11a8:      	mov	w8, #0x2                // =2
    11ac:      	b	0x2c0 <kprobe_unwind_ruby+0x2c0>
    11b0:      	ldr	w8, [x25]
    11b4:      	cbz	w8, 0x76c <kprobe_unwind_ruby+0x76c>
    11b8:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    11bc:      	add	x8, x8, #0x0
    11c0:      	add	x0, sp, #0x8
    11c4:      	ldp	x9, x10, [x8, #0x10]
    11c8:      	mov	w1, #0x2e               // =46
    11cc:      	stp	x9, x10, [sp, #0x18]
    11d0:      	ldr	x9, [x8, #0x20]
    11d4:      	add	x10, sp, #0x8
    11d8:      	str	x9, [sp, #0x28]
    11dc:      	ldur	x9, [x8, #0x26]
    11e0:      	stur	x9, [sp, #0x2e]
    11e4:      	ldp	x9, x8, [x8]
    11e8:      	stp	x9, x8, [sp, #0x8]
    11ec:      	mov	w8, #0x2e               // =46
    11f0:      	mov	w9, #0x6                // =6
    11f4:      	ldr	w2, [sp, #0x50]
    11f8:      	blr	x9
    11fc:      	b	0x76c <kprobe_unwind_ruby+0x76c>
    1200:      	ldr	w9, [x22, #0x2c0]
    1204:      	cmp	w9, #0x7e
    1208:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    120c:      	ldr	x10, [sp, #0x68]
    1210:      	add	w11, w9, #0x1
    1214:      	str	wzr, [sp, #0x50]
    1218:      	mov	x0, x29
    121c:      	add	x1, sp, #0x50
    1220:      	strh	wzr, [sp, #0x54]
    1224:      	str	w11, [x22, #0x2c0]
    1228:      	mov	w11, #0x18              // =24
    122c:      	umaddl	x9, w9, w11, x22
    1230:      	str	x10, [x9, #0x2d0]
    1234:      	mov	w10, #0x6               // =6
    1238:      	str	x8, [x9, #0x2d8]
    123c:      	add	x8, x9, #0x2d0
    1240:      	strh	w10, [x9, #0x2e0]
    1244:      	ldr	w11, [sp, #0x50]
    1248:      	ldrh	w10, [sp, #0x54]
    124c:      	stur	w11, [x8, #0x12]
    1250:      	mov	w8, #0x36               // =54
    1254:      	strh	w10, [x9, #0x2e6]
    1258:      	add	x9, sp, #0x50
    125c:      	str	w8, [sp, #0x50]
    1260:      	mov	w8, #0x1                // =1
    1264:      	blr	x8
    1268:      	cbz	x0, 0x1490 <kprobe_unwind_ruby+0x1490>
    126c:      	ldr	x8, [x0]
    1270:      	mov	x20, x29
    1274:      	add	x8, x8, #0x1
    1278:      	str	x8, [x0]
    127c:      	b	0xb5c <kprobe_unwind_ruby+0xb5c>
    1280:      	ldr	w8, [x23]
    1284:      	lsr	w8, w8, #9
    1288:      	cmp	w8, #0x103
    128c:      	b.hs	0x1434 <kprobe_unwind_ruby+0x1434>
    1290:      	ldr	x8, [sp, #0x78]
    1294:      	ldr	x9, [sp]
    1298:      	cmp	x9, x8
    129c:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    12a0:      	ldrb	w9, [x23, #0x1e]
    12a4:      	str	xzr, [sp, #0x60]
    12a8:      	mov	w20, #0x8               // =8
    12ac:      	mov	w10, #0x70              // =112
    12b0:      	add	x0, sp, #0x70
    12b4:      	mov	w1, #0x8                // =8
    12b8:      	mov	w24, #0x70              // =112
    12bc:      	add	x8, x8, x9
    12c0:      	ldrb	w9, [x23, #0x1c]
    12c4:      	stp	xzr, x8, [sp, #0x70]
    12c8:      	add	x8, x8, x9
    12cc:      	add	x9, sp, #0x70
    12d0:      	ldr	x8, [sp, #0x78]
    12d4:      	ldrb	w9, [x23, #0x1c]
    12d8:      	add	x2, x8, x9
    12dc:      	blr	x10
    12e0:      	ldr	x8, [sp, #0x78]
    12e4:      	ldrb	w9, [x23, #0x1b]
    12e8:      	add	x0, sp, #0x60
    12ec:      	mov	w1, #0x8                // =8
    12f0:      	add	x8, x8, x9
    12f4:      	add	x9, sp, #0x60
    12f8:      	ldr	x8, [sp, #0x78]
    12fc:      	ldrb	w9, [x23, #0x1b]
    1300:      	add	x2, x8, x9
    1304:      	blr	x24
    1308:      	ldr	x8, [sp, #0x60]
    130c:      	cbz	x8, 0x1520 <kprobe_unwind_ruby+0x1520>
    1310:      	ldr	x8, [sp, #0x70]
    1314:      	cbz	x8, 0x1520 <kprobe_unwind_ruby+0x1520>
    1318:      	ldrb	w9, [x23, #0x1f]
    131c:      	mov	w10, #0x70              // =112
    1320:      	add	x11, sp, #0x68
    1324:      	add	x0, sp, #0x68
    1328:      	mov	w1, #0x8                // =8
    132c:      	add	x8, x8, x9
    1330:      	mov	w9, #0x8                // =8
    1334:      	ldr	x8, [sp, #0x70]
    1338:      	ldrb	w9, [x23, #0x1f]
    133c:      	add	x2, x8, x9
    1340:      	blr	x10
    1344:      	adrp	x25, 0x1000 <kprobe_unwind_ruby+0x1000>
    1348:      	mov	x20, x29
    134c:      	ldr	x25, [x25]
    1350:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    1354:      	ldr	x8, [sp, #0x68]
    1358:      	ldrb	w9, [x23, #0x21]
    135c:      	mov	w10, #0x70              // =112
    1360:      	add	x11, sp, #0x58
    1364:      	add	x0, sp, #0x58
    1368:      	mov	w1, #0x8                // =8
    136c:      	add	x8, x8, x9
    1370:      	mov	w9, #0x8                // =8
    1374:      	ldr	x8, [sp, #0x68]
    1378:      	ldrb	w9, [x23, #0x21]
    137c:      	add	x2, x8, x9
    1380:      	blr	x10
    1384:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    1388:      	ldr	x8, [sp, #0x68]
    138c:      	ldrb	w9, [x23, #0x22]
    1390:      	mov	w10, #0x70              // =112
    1394:      	add	x11, sp, #0x88
    1398:      	add	x0, sp, #0x88
    139c:      	mov	w1, #0x4                // =4
    13a0:      	add	x8, x8, x9
    13a4:      	mov	w9, #0x4                // =4
    13a8:      	ldr	x8, [sp, #0x68]
    13ac:      	ldrb	w9, [x23, #0x22]
    13b0:      	add	x2, x8, x9
    13b4:      	blr	x10
    13b8:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    13bc:      	ldrb	w9, [x23, #0x23]
    13c0:      	ldr	x8, [sp, #0x60]
    13c4:      	cbz	x9, 0x1d7c <kprobe_unwind_ruby+0x1d7c>
    13c8:      	ldr	x10, [sp, #0x58]
    13cc:      	sub	x10, x8, x10
    13d0:      	udiv	x9, x10, x9
    13d4:      	ldr	w10, [sp, #0x88]
    13d8:      	cmp	x9, x10
    13dc:      	b.ls	0x1d7c <kprobe_unwind_ruby+0x1d7c>
    13e0:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    13e4:      	ldr	x8, [x8]
    13e8:      	ldr	w8, [x8]
    13ec:      	cbz	w8, 0x1530 <kprobe_unwind_ruby+0x1530>
    13f0:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    13f4:      	add	x8, x8, #0x0
    13f8:      	add	x0, sp, #0x8
    13fc:      	ldp	x9, x10, [x8, #0x10]
    1400:      	mov	w1, #0x2d               // =45
    1404:      	stp	x9, x10, [sp, #0x18]
    1408:      	ldr	x9, [x8, #0x20]
    140c:      	add	x10, sp, #0x8
    1410:      	str	x9, [sp, #0x28]
    1414:      	ldur	x9, [x8, #0x25]
    1418:      	stur	x9, [sp, #0x2d]
    141c:      	ldp	x9, x8, [x8]
    1420:      	stp	x9, x8, [sp, #0x8]
    1424:      	mov	w8, #0x2d               // =45
    1428:      	mov	w9, #0x6                // =6
    142c:      	blr	x9
    1430:      	b	0x1530 <kprobe_unwind_ruby+0x1530>
    1434:      	ldr	x8, [sp, #0x78]
    1438:      	ldrb	w9, [x23, #0x1d]
    143c:      	mov	w10, #0x70              // =112
    1440:      	add	x11, sp, #0x50
    1444:      	add	x0, sp, #0x50
    1448:      	mov	w1, #0x8                // =8
    144c:      	str	xzr, [sp, #0x50]
    1450:      	add	x8, x8, x9
    1454:      	mov	w9, #0x8                // =8
    1458:      	ldr	x8, [sp, #0x78]
    145c:      	ldrb	w9, [x23, #0x1d]
    1460:      	add	x2, x8, x9
    1464:      	blr	x10
    1468:      	adrp	x25, 0x1000 <kprobe_unwind_ruby+0x1000>
    146c:      	mov	x20, x29
    1470:      	ldr	x25, [x25]
    1474:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    1478:      	ldr	w8, [sp, #0x50]
    147c:      	mov	w9, #0x140              // =320
    1480:      	mvn	w8, w8
    1484:      	tst	x8, x9
    1488:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    148c:      	b	0x1290 <kprobe_unwind_ruby+0x1290>
    1490:      	ldr	w8, [x25]
    1494:      	cbnz	w8, 0x24ac <kprobe_unwind_ruby+0x24ac>
    1498:      	mov	x20, x29
    149c:      	b	0xb5c <kprobe_unwind_ruby+0xb5c>
    14a0:      	ldr	w9, [x22, #0x2c0]
    14a4:      	mov	x25, x20
    14a8:      	cmp	w9, #0x7e
    14ac:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    14b0:      	ldr	x10, [sp, #0x68]
    14b4:      	add	w11, w9, #0x1
    14b8:      	str	wzr, [sp, #0x50]
    14bc:      	mov	x0, x29
    14c0:      	add	x1, sp, #0x50
    14c4:      	strh	wzr, [sp, #0x54]
    14c8:      	str	w11, [x22, #0x2c0]
    14cc:      	mov	w11, #0x18              // =24
    14d0:      	umaddl	x9, w9, w11, x22
    14d4:      	str	x10, [x9, #0x2d0]
    14d8:      	mov	w10, #0x6               // =6
    14dc:      	str	x8, [x9, #0x2d8]
    14e0:      	add	x8, x9, #0x2d0
    14e4:      	strh	w10, [x9, #0x2e0]
    14e8:      	ldr	w11, [sp, #0x50]
    14ec:      	ldrh	w10, [sp, #0x54]
    14f0:      	stur	w11, [x8, #0x12]
    14f4:      	mov	w8, #0x36               // =54
    14f8:      	strh	w10, [x9, #0x2e6]
    14fc:      	add	x9, sp, #0x50
    1500:      	str	w8, [sp, #0x50]
    1504:      	mov	w8, #0x1                // =1
    1508:      	blr	x8
    150c:      	cbz	x0, 0x1864 <kprobe_unwind_ruby+0x1864>
    1510:      	ldr	x8, [x0]
    1514:      	add	x8, x8, #0x1
    1518:      	str	x8, [x0]
    151c:      	b	0x186c <kprobe_unwind_ruby+0x186c>
    1520:      	ldr	w8, [x23]
    1524:      	lsr	w8, w8, #9
    1528:      	cmp	w8, #0x103
    152c:      	b.hs	0x1758 <kprobe_unwind_ruby+0x1758>
    1530:      	ldr	x8, [sp, #0x78]
    1534:      	ldr	x9, [sp]
    1538:      	cmp	x9, x8
    153c:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    1540:      	ldrb	w9, [x23, #0x1e]
    1544:      	str	xzr, [sp, #0x60]
    1548:      	mov	w20, #0x8               // =8
    154c:      	mov	w10, #0x70              // =112
    1550:      	add	x0, sp, #0x70
    1554:      	mov	w1, #0x8                // =8
    1558:      	mov	w24, #0x70              // =112
    155c:      	add	x8, x8, x9
    1560:      	ldrb	w9, [x23, #0x1c]
    1564:      	stp	xzr, x8, [sp, #0x70]
    1568:      	add	x8, x8, x9
    156c:      	add	x9, sp, #0x70
    1570:      	ldr	x8, [sp, #0x78]
    1574:      	ldrb	w9, [x23, #0x1c]
    1578:      	add	x2, x8, x9
    157c:      	blr	x10
    1580:      	ldr	x8, [sp, #0x78]
    1584:      	ldrb	w9, [x23, #0x1b]
    1588:      	add	x0, sp, #0x60
    158c:      	mov	w1, #0x8                // =8
    1590:      	add	x8, x8, x9
    1594:      	add	x9, sp, #0x60
    1598:      	ldr	x8, [sp, #0x78]
    159c:      	ldrb	w9, [x23, #0x1b]
    15a0:      	add	x2, x8, x9
    15a4:      	blr	x24
    15a8:      	ldr	x8, [sp, #0x60]
    15ac:      	cbz	x8, 0x1980 <kprobe_unwind_ruby+0x1980>
    15b0:      	ldr	x8, [sp, #0x70]
    15b4:      	cbz	x8, 0x1980 <kprobe_unwind_ruby+0x1980>
    15b8:      	ldrb	w9, [x23, #0x1f]
    15bc:      	mov	w10, #0x70              // =112
    15c0:      	add	x11, sp, #0x68
    15c4:      	add	x0, sp, #0x68
    15c8:      	mov	w1, #0x8                // =8
    15cc:      	add	x8, x8, x9
    15d0:      	mov	w9, #0x8                // =8
    15d4:      	ldr	x8, [sp, #0x70]
    15d8:      	ldrb	w9, [x23, #0x1f]
    15dc:      	add	x2, x8, x9
    15e0:      	blr	x10
    15e4:      	adrp	x25, 0x1000 <kprobe_unwind_ruby+0x1000>
    15e8:      	mov	x20, x29
    15ec:      	ldr	x25, [x25]
    15f0:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    15f4:      	ldr	x8, [sp, #0x68]
    15f8:      	ldrb	w9, [x23, #0x21]
    15fc:      	mov	w10, #0x70              // =112
    1600:      	add	x11, sp, #0x58
    1604:      	add	x0, sp, #0x58
    1608:      	mov	w1, #0x8                // =8
    160c:      	add	x8, x8, x9
    1610:      	mov	w9, #0x8                // =8
    1614:      	ldr	x8, [sp, #0x68]
    1618:      	ldrb	w9, [x23, #0x21]
    161c:      	add	x2, x8, x9
    1620:      	blr	x10
    1624:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    1628:      	ldr	x8, [sp, #0x68]
    162c:      	ldrb	w9, [x23, #0x22]
    1630:      	mov	w10, #0x70              // =112
    1634:      	add	x11, sp, #0x88
    1638:      	add	x0, sp, #0x88
    163c:      	mov	w1, #0x4                // =4
    1640:      	add	x8, x8, x9
    1644:      	mov	w9, #0x4                // =4
    1648:      	ldr	x8, [sp, #0x68]
    164c:      	ldrb	w9, [x23, #0x22]
    1650:      	add	x2, x8, x9
    1654:      	blr	x10
    1658:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    165c:      	ldrb	w9, [x23, #0x23]
    1660:      	ldr	x8, [sp, #0x60]
    1664:      	cbz	x9, 0x213c <kprobe_unwind_ruby+0x213c>
    1668:      	ldr	x10, [sp, #0x58]
    166c:      	sub	x10, x8, x10
    1670:      	udiv	x9, x10, x9
    1674:      	ldr	w10, [sp, #0x88]
    1678:      	cmp	x9, x10
    167c:      	b.ls	0x213c <kprobe_unwind_ruby+0x213c>
    1680:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1684:      	ldr	x8, [x8]
    1688:      	ldr	w8, [x8]
    168c:      	cbz	w8, 0x1990 <kprobe_unwind_ruby+0x1990>
    1690:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1694:      	add	x8, x8, #0x0
    1698:      	add	x0, sp, #0x8
    169c:      	ldp	x9, x10, [x8, #0x10]
    16a0:      	mov	w1, #0x2d               // =45
    16a4:      	stp	x9, x10, [sp, #0x18]
    16a8:      	ldr	x9, [x8, #0x20]
    16ac:      	add	x10, sp, #0x8
    16b0:      	str	x9, [sp, #0x28]
    16b4:      	ldur	x9, [x8, #0x25]
    16b8:      	stur	x9, [sp, #0x2d]
    16bc:      	ldp	x9, x8, [x8]
    16c0:      	stp	x9, x8, [sp, #0x8]
    16c4:      	mov	w8, #0x2d               // =45
    16c8:      	mov	w9, #0x6                // =6
    16cc:      	blr	x9
    16d0:      	b	0x1990 <kprobe_unwind_ruby+0x1990>
    16d4:      	mov	w8, #0x7265             // =29285
    16d8:      	add	x0, sp, #0x8
    16dc:      	mov	w1, #0x2c               // =44
    16e0:      	movk	w8, #0xa, lsl #16
    16e4:      	str	w8, [sp, #0x30]
    16e8:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    16ec:      	add	x8, x8, #0x0
    16f0:      	ldp	x9, x10, [x8, #0x10]
    16f4:      	stp	x9, x10, [sp, #0x18]
    16f8:      	ldr	x9, [x8, #0x20]
    16fc:      	add	x10, sp, #0x8
    1700:      	str	x9, [sp, #0x28]
    1704:      	ldp	x8, x9, [x8]
    1708:      	stp	x8, x9, [sp, #0x8]
    170c:      	mov	w8, #0x2c               // =44
    1710:      	mov	w9, #0x6                // =6
    1714:      	blr	x9
    1718:      	b	0x720 <kprobe_unwind_ruby+0x720>
    171c:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1720:      	add	x8, x8, #0x0
    1724:      	add	x0, sp, #0x8
    1728:      	ldp	x9, x10, [x8]
    172c:      	mov	w1, #0x1f               // =31
    1730:      	stp	x9, x10, [sp, #0x8]
    1734:      	ldr	x9, [x8, #0x10]
    1738:      	ldur	x8, [x8, #0x17]
    173c:      	add	x10, sp, #0x8
    1740:      	str	x9, [sp, #0x18]
    1744:      	stur	x8, [sp, #0x1f]
    1748:      	mov	w8, #0x1f               // =31
    174c:      	mov	w9, #0x6                // =6
    1750:      	blr	x9
    1754:      	b	0x6bc <kprobe_unwind_ruby+0x6bc>
    1758:      	ldr	x8, [sp, #0x78]
    175c:      	ldrb	w9, [x23, #0x1d]
    1760:      	mov	w10, #0x70              // =112
    1764:      	add	x11, sp, #0x50
    1768:      	add	x0, sp, #0x50
    176c:      	mov	w1, #0x8                // =8
    1770:      	str	xzr, [sp, #0x50]
    1774:      	add	x8, x8, x9
    1778:      	mov	w9, #0x8                // =8
    177c:      	ldr	x8, [sp, #0x78]
    1780:      	ldrb	w9, [x23, #0x1d]
    1784:      	add	x2, x8, x9
    1788:      	blr	x10
    178c:      	adrp	x25, 0x1000 <kprobe_unwind_ruby+0x1000>
    1790:      	mov	x20, x29
    1794:      	ldr	x25, [x25]
    1798:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    179c:      	ldr	w8, [sp, #0x50]
    17a0:      	mov	w9, #0x140              // =320
    17a4:      	mvn	w8, w8
    17a8:      	tst	x8, x9
    17ac:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    17b0:      	b	0x1530 <kprobe_unwind_ruby+0x1530>
    17b4:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    17b8:      	add	x8, x8, #0x0
    17bc:      	add	x0, sp, #0x8
    17c0:      	ldp	x9, x10, [x8]
    17c4:      	mov	w1, #0x20               // =32
    17c8:      	stp	x9, x10, [sp, #0x8]
    17cc:      	ldp	x9, x8, [x8, #0x10]
    17d0:      	add	x10, sp, #0x8
    17d4:      	stp	x9, x8, [sp, #0x18]
    17d8:      	mov	w8, #0x20               // =32
    17dc:      	mov	w9, #0x6                // =6
    17e0:      	blr	x9
    17e4:      	b	0x938 <kprobe_unwind_ruby+0x938>
    17e8:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    17ec:      	add	x8, x8, #0x0
    17f0:      	add	x0, sp, #0x8
    17f4:      	ldp	x9, x10, [x8, #0x10]
    17f8:      	mov	w1, #0x2e               // =46
    17fc:      	stp	x9, x10, [sp, #0x18]
    1800:      	ldr	x9, [x8, #0x20]
    1804:      	add	x10, sp, #0x8
    1808:      	str	x9, [sp, #0x28]
    180c:      	ldur	x9, [x8, #0x26]
    1810:      	stur	x9, [sp, #0x2e]
    1814:      	ldp	x9, x8, [x8]
    1818:      	stp	x9, x8, [sp, #0x8]
    181c:      	mov	w8, #0x2e               // =46
    1820:      	mov	w9, #0x6                // =6
    1824:      	ldr	w2, [sp, #0x60]
    1828:      	blr	x9
    182c:      	b	0x9e8 <kprobe_unwind_ruby+0x9e8>
    1830:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1834:      	add	x8, x8, #0x0
    1838:      	add	x0, sp, #0x8
    183c:      	ldp	x9, x10, [x8]
    1840:      	ldr	x8, [x8, #0x10]
    1844:      	mov	w1, #0x18               // =24
    1848:      	stp	x9, x10, [sp, #0x8]
    184c:      	str	x8, [sp, #0x18]
    1850:      	mov	w8, #0x18               // =24
    1854:      	mov	w9, #0x6                // =6
    1858:      	add	x10, sp, #0x8
    185c:      	blr	x9
    1860:      	b	0x9b0 <kprobe_unwind_ruby+0x9b0>
    1864:      	ldr	w8, [x20]
    1868:      	cbnz	w8, 0x27e0 <kprobe_unwind_ruby+0x27e0>
    186c:      	mov	x25, x20
    1870:      	mov	x20, x29
    1874:      	b	0xf3c <kprobe_unwind_ruby+0xf3c>
    1878:      	ldr	w9, [x22, #0x2c0]
    187c:      	adrp	x25, 0x1000 <kprobe_unwind_ruby+0x1000>
    1880:      	ldr	x25, [x25]
    1884:      	cmp	w9, #0x7e
    1888:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    188c:      	ldr	x10, [sp, #0x68]
    1890:      	add	w11, w9, #0x1
    1894:      	str	wzr, [sp, #0x50]
    1898:      	mov	x0, x29
    189c:      	add	x1, sp, #0x50
    18a0:      	strh	wzr, [sp, #0x54]
    18a4:      	str	w11, [x22, #0x2c0]
    18a8:      	mov	w11, #0x18              // =24
    18ac:      	umaddl	x9, w9, w11, x22
    18b0:      	str	x10, [x9, #0x2d0]
    18b4:      	mov	w10, #0x6               // =6
    18b8:      	str	x8, [x9, #0x2d8]
    18bc:      	add	x8, x9, #0x2d0
    18c0:      	strh	w10, [x9, #0x2e0]
    18c4:      	ldr	w11, [sp, #0x50]
    18c8:      	ldrh	w10, [sp, #0x54]
    18cc:      	stur	w11, [x8, #0x12]
    18d0:      	mov	w8, #0x36               // =54
    18d4:      	strh	w10, [x9, #0x2e6]
    18d8:      	add	x9, sp, #0x50
    18dc:      	str	w8, [sp, #0x50]
    18e0:      	mov	w8, #0x1                // =1
    18e4:      	blr	x8
    18e8:      	cbz	x0, 0x1d24 <kprobe_unwind_ruby+0x1d24>
    18ec:      	ldr	x8, [x0]
    18f0:      	add	x8, x8, #0x1
    18f4:      	str	x8, [x0]
    18f8:      	b	0x1290 <kprobe_unwind_ruby+0x1290>
    18fc:      	mov	w8, #0xa                // =10
    1900:      	add	x0, sp, #0x8
    1904:      	mov	w1, #0x22               // =34
    1908:      	strh	w8, [sp, #0x28]
    190c:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1910:      	add	x8, x8, #0x0
    1914:      	ldp	x9, x10, [x8]
    1918:      	stp	x9, x10, [sp, #0x8]
    191c:      	ldp	x9, x8, [x8, #0x10]
    1920:      	add	x10, sp, #0x8
    1924:      	stp	x9, x8, [sp, #0x18]
    1928:      	mov	w8, #0x22               // =34
    192c:      	mov	w9, #0x6                // =6
    1930:      	blr	x9
    1934:      	b	0xa30 <kprobe_unwind_ruby+0xa30>
    1938:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    193c:      	add	x8, x8, #0x0
    1940:      	add	x0, sp, #0x8
    1944:      	ldp	x9, x10, [x8, #0x10]
    1948:      	mov	w1, #0x2e               // =46
    194c:      	stp	x9, x10, [sp, #0x18]
    1950:      	ldr	x9, [x8, #0x20]
    1954:      	add	x10, sp, #0x8
    1958:      	str	x9, [sp, #0x28]
    195c:      	ldur	x9, [x8, #0x26]
    1960:      	stur	x9, [sp, #0x2e]
    1964:      	ldp	x9, x8, [x8]
    1968:      	stp	x9, x8, [sp, #0x8]
    196c:      	mov	w8, #0x2e               // =46
    1970:      	mov	w9, #0x6                // =6
    1974:      	ldr	w2, [sp, #0x50]
    1978:      	blr	x9
    197c:      	b	0xa68 <kprobe_unwind_ruby+0xa68>
    1980:      	ldr	w8, [x23]
    1984:      	lsr	w8, w8, #9
    1988:      	cmp	w8, #0x103
    198c:      	b.hs	0x1c80 <kprobe_unwind_ruby+0x1c80>
    1990:      	ldr	x8, [sp, #0x78]
    1994:      	ldr	x9, [sp]
    1998:      	cmp	x9, x8
    199c:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    19a0:      	ldrb	w9, [x23, #0x1e]
    19a4:      	str	xzr, [sp, #0x60]
    19a8:      	mov	w20, #0x8               // =8
    19ac:      	mov	w10, #0x70              // =112
    19b0:      	add	x0, sp, #0x70
    19b4:      	mov	w1, #0x8                // =8
    19b8:      	mov	w24, #0x70              // =112
    19bc:      	add	x8, x8, x9
    19c0:      	ldrb	w9, [x23, #0x1c]
    19c4:      	stp	xzr, x8, [sp, #0x70]
    19c8:      	add	x8, x8, x9
    19cc:      	add	x9, sp, #0x70
    19d0:      	ldr	x8, [sp, #0x78]
    19d4:      	ldrb	w9, [x23, #0x1c]
    19d8:      	add	x2, x8, x9
    19dc:      	blr	x10
    19e0:      	ldr	x8, [sp, #0x78]
    19e4:      	ldrb	w9, [x23, #0x1b]
    19e8:      	add	x0, sp, #0x60
    19ec:      	mov	w1, #0x8                // =8
    19f0:      	add	x8, x8, x9
    19f4:      	add	x9, sp, #0x60
    19f8:      	ldr	x8, [sp, #0x78]
    19fc:      	ldrb	w9, [x23, #0x1b]
    1a00:      	add	x2, x8, x9
    1a04:      	blr	x24
    1a08:      	ldr	x8, [sp, #0x60]
    1a0c:      	cbz	x8, 0x1e48 <kprobe_unwind_ruby+0x1e48>
    1a10:      	ldr	x8, [sp, #0x70]
    1a14:      	cbz	x8, 0x1e48 <kprobe_unwind_ruby+0x1e48>
    1a18:      	ldrb	w9, [x23, #0x1f]
    1a1c:      	mov	w10, #0x70              // =112
    1a20:      	add	x11, sp, #0x68
    1a24:      	add	x0, sp, #0x68
    1a28:      	mov	w1, #0x8                // =8
    1a2c:      	add	x8, x8, x9
    1a30:      	mov	w9, #0x8                // =8
    1a34:      	ldr	x8, [sp, #0x70]
    1a38:      	ldrb	w9, [x23, #0x1f]
    1a3c:      	add	x2, x8, x9
    1a40:      	blr	x10
    1a44:      	adrp	x25, 0x1000 <kprobe_unwind_ruby+0x1000>
    1a48:      	mov	x20, x29
    1a4c:      	ldr	x25, [x25]
    1a50:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    1a54:      	ldr	x8, [sp, #0x68]
    1a58:      	ldrb	w9, [x23, #0x21]
    1a5c:      	mov	w10, #0x70              // =112
    1a60:      	add	x11, sp, #0x58
    1a64:      	add	x0, sp, #0x58
    1a68:      	mov	w1, #0x8                // =8
    1a6c:      	add	x8, x8, x9
    1a70:      	mov	w9, #0x8                // =8
    1a74:      	ldr	x8, [sp, #0x68]
    1a78:      	ldrb	w9, [x23, #0x21]
    1a7c:      	add	x2, x8, x9
    1a80:      	blr	x10
    1a84:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    1a88:      	ldr	x8, [sp, #0x68]
    1a8c:      	ldrb	w9, [x23, #0x22]
    1a90:      	mov	w10, #0x70              // =112
    1a94:      	add	x11, sp, #0x88
    1a98:      	add	x0, sp, #0x88
    1a9c:      	mov	w1, #0x4                // =4
    1aa0:      	add	x8, x8, x9
    1aa4:      	mov	w9, #0x4                // =4
    1aa8:      	ldr	x8, [sp, #0x68]
    1aac:      	ldrb	w9, [x23, #0x22]
    1ab0:      	add	x2, x8, x9
    1ab4:      	blr	x10
    1ab8:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    1abc:      	ldrb	w9, [x23, #0x23]
    1ac0:      	ldr	x8, [sp, #0x60]
    1ac4:      	cbz	x9, 0x2428 <kprobe_unwind_ruby+0x2428>
    1ac8:      	ldr	x10, [sp, #0x58]
    1acc:      	sub	x10, x8, x10
    1ad0:      	udiv	x9, x10, x9
    1ad4:      	ldr	w10, [sp, #0x88]
    1ad8:      	cmp	x9, x10
    1adc:      	b.ls	0x2428 <kprobe_unwind_ruby+0x2428>
    1ae0:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1ae4:      	ldr	x8, [x8]
    1ae8:      	ldr	w8, [x8]
    1aec:      	cbz	w8, 0x1e58 <kprobe_unwind_ruby+0x1e58>
    1af0:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1af4:      	add	x8, x8, #0x0
    1af8:      	add	x0, sp, #0x8
    1afc:      	ldp	x9, x10, [x8, #0x10]
    1b00:      	mov	w1, #0x2d               // =45
    1b04:      	stp	x9, x10, [sp, #0x18]
    1b08:      	ldr	x9, [x8, #0x20]
    1b0c:      	add	x10, sp, #0x8
    1b10:      	str	x9, [sp, #0x28]
    1b14:      	ldur	x9, [x8, #0x25]
    1b18:      	stur	x9, [sp, #0x2d]
    1b1c:      	ldp	x9, x8, [x8]
    1b20:      	stp	x9, x8, [sp, #0x8]
    1b24:      	mov	w8, #0x2d               // =45
    1b28:      	mov	w9, #0x6                // =6
    1b2c:      	blr	x9
    1b30:      	b	0x1e58 <kprobe_unwind_ruby+0x1e58>
    1b34:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1b38:      	add	x8, x8, #0x0
    1b3c:      	strb	wzr, [sp, #0x20]
    1b40:      	add	x0, sp, #0x8
    1b44:      	ldp	x9, x10, [x8]
    1b48:      	ldr	x8, [x8, #0x10]
    1b4c:      	mov	w1, #0x19               // =25
    1b50:      	str	x8, [sp, #0x18]
    1b54:      	stp	x9, x10, [sp, #0x8]
    1b58:      	mov	w8, #0x19               // =25
    1b5c:      	mov	w9, #0x6                // =6
    1b60:      	add	x10, sp, #0x8
    1b64:      	blr	x9
    1b68:      	b	0xac0 <kprobe_unwind_ruby+0xac0>
    1b6c:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1b70:      	add	x8, x8, #0x0
    1b74:      	add	x0, sp, #0x8
    1b78:      	ldp	x9, x10, [x8, #0x10]
    1b7c:      	mov	w1, #0x2e               // =46
    1b80:      	stp	x9, x10, [sp, #0x18]
    1b84:      	ldr	x9, [x8, #0x20]
    1b88:      	add	x10, sp, #0x8
    1b8c:      	str	x9, [sp, #0x28]
    1b90:      	ldur	x9, [x8, #0x26]
    1b94:      	stur	x9, [sp, #0x2e]
    1b98:      	ldp	x9, x8, [x8]
    1b9c:      	stp	x9, x8, [sp, #0x8]
    1ba0:      	mov	w8, #0x2e               // =46
    1ba4:      	mov	w9, #0x6                // =6
    1ba8:      	ldr	w2, [sp, #0x60]
    1bac:      	blr	x9
    1bb0:      	b	0xb3c <kprobe_unwind_ruby+0xb3c>
    1bb4:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1bb8:      	add	x8, x8, #0x0
    1bbc:      	add	x0, sp, #0x8
    1bc0:      	ldp	x9, x10, [x8, #0x10]
    1bc4:      	mov	w1, #0x2e               // =46
    1bc8:      	stp	x9, x10, [sp, #0x18]
    1bcc:      	ldr	x9, [x8, #0x20]
    1bd0:      	add	x10, sp, #0x8
    1bd4:      	str	x9, [sp, #0x28]
    1bd8:      	ldur	x9, [x8, #0x26]
    1bdc:      	stur	x9, [sp, #0x2e]
    1be0:      	ldp	x9, x8, [x8]
    1be4:      	stp	x9, x8, [sp, #0x8]
    1be8:      	mov	w8, #0x2e               // =46
    1bec:      	mov	w9, #0x6                // =6
    1bf0:      	ldr	w2, [sp, #0x8c]
    1bf4:      	blr	x9
    1bf8:      	b	0xd70 <kprobe_unwind_ruby+0xd70>
    1bfc:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1c00:      	add	x8, x8, #0x0
    1c04:      	add	x0, sp, #0x8
    1c08:      	ldp	x9, x10, [x8]
    1c0c:      	mov	w1, #0x1f               // =31
    1c10:      	stp	x9, x10, [sp, #0x8]
    1c14:      	ldr	x9, [x8, #0x10]
    1c18:      	ldur	x8, [x8, #0x17]
    1c1c:      	add	x10, sp, #0x8
    1c20:      	str	x9, [sp, #0x18]
    1c24:      	stur	x8, [sp, #0x1f]
    1c28:      	mov	w8, #0x1f               // =31
    1c2c:      	mov	w9, #0x6                // =6
    1c30:      	blr	x9
    1c34:      	b	0xd38 <kprobe_unwind_ruby+0xd38>
    1c38:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1c3c:      	add	x8, x8, #0x0
    1c40:      	add	x0, sp, #0x8
    1c44:      	ldp	x9, x10, [x8, #0x10]
    1c48:      	mov	w1, #0x2e               // =46
    1c4c:      	stp	x9, x10, [sp, #0x18]
    1c50:      	ldr	x9, [x8, #0x20]
    1c54:      	add	x10, sp, #0x8
    1c58:      	str	x9, [sp, #0x28]
    1c5c:      	ldur	x9, [x8, #0x26]
    1c60:      	stur	x9, [sp, #0x2e]
    1c64:      	ldp	x9, x8, [x8]
    1c68:      	stp	x9, x8, [sp, #0x8]
    1c6c:      	mov	w8, #0x2e               // =46
    1c70:      	mov	w9, #0x6                // =6
    1c74:      	ldr	w2, [sp, #0x50]
    1c78:      	blr	x9
    1c7c:      	b	0xd84 <kprobe_unwind_ruby+0xd84>
    1c80:      	ldr	x8, [sp, #0x78]
    1c84:      	ldrb	w9, [x23, #0x1d]
    1c88:      	mov	w10, #0x70              // =112
    1c8c:      	add	x11, sp, #0x50
    1c90:      	add	x0, sp, #0x50
    1c94:      	mov	w1, #0x8                // =8
    1c98:      	str	xzr, [sp, #0x50]
    1c9c:      	add	x8, x8, x9
    1ca0:      	mov	w9, #0x8                // =8
    1ca4:      	ldr	x8, [sp, #0x78]
    1ca8:      	ldrb	w9, [x23, #0x1d]
    1cac:      	add	x2, x8, x9
    1cb0:      	blr	x10
    1cb4:      	adrp	x25, 0x1000 <kprobe_unwind_ruby+0x1000>
    1cb8:      	mov	x20, x29
    1cbc:      	ldr	x25, [x25]
    1cc0:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    1cc4:      	ldr	w8, [sp, #0x50]
    1cc8:      	mov	w9, #0x140              // =320
    1ccc:      	mvn	w8, w8
    1cd0:      	tst	x8, x9
    1cd4:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    1cd8:      	b	0x1990 <kprobe_unwind_ruby+0x1990>
    1cdc:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1ce0:      	add	x8, x8, #0x0
    1ce4:      	add	x0, sp, #0x8
    1ce8:      	ldp	x9, x10, [x8, #0x10]
    1cec:      	mov	w1, #0x2e               // =46
    1cf0:      	stp	x9, x10, [sp, #0x18]
    1cf4:      	ldr	x9, [x8, #0x20]
    1cf8:      	add	x10, sp, #0x8
    1cfc:      	str	x9, [sp, #0x28]
    1d00:      	ldur	x9, [x8, #0x26]
    1d04:      	stur	x9, [sp, #0x2e]
    1d08:      	ldp	x9, x8, [x8]
    1d0c:      	stp	x9, x8, [sp, #0x8]
    1d10:      	mov	w8, #0x2e               // =46
    1d14:      	mov	w9, #0x6                // =6
    1d18:      	ldr	w2, [sp, #0x60]
    1d1c:      	blr	x9
    1d20:      	b	0xe0c <kprobe_unwind_ruby+0xe0c>
    1d24:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1d28:      	ldr	x8, [x8]
    1d2c:      	ldr	w8, [x8]
    1d30:      	cbz	w8, 0x1290 <kprobe_unwind_ruby+0x1290>
    1d34:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1d38:      	add	x8, x8, #0x0
    1d3c:      	add	x0, sp, #0x8
    1d40:      	ldp	x9, x10, [x8, #0x10]
    1d44:      	mov	w1, #0x2e               // =46
    1d48:      	stp	x9, x10, [sp, #0x18]
    1d4c:      	ldr	x9, [x8, #0x20]
    1d50:      	add	x10, sp, #0x8
    1d54:      	str	x9, [sp, #0x28]
    1d58:      	ldur	x9, [x8, #0x26]
    1d5c:      	stur	x9, [sp, #0x2e]
    1d60:      	ldp	x9, x8, [x8]
    1d64:      	stp	x9, x8, [sp, #0x8]
    1d68:      	mov	w8, #0x2e               // =46
    1d6c:      	mov	w9, #0x6                // =6
    1d70:      	ldr	w2, [sp, #0x50]
    1d74:      	blr	x9
    1d78:      	b	0x1290 <kprobe_unwind_ruby+0x1290>
    1d7c:      	ldr	w9, [x22, #0x2c0]
    1d80:      	adrp	x25, 0x1000 <kprobe_unwind_ruby+0x1000>
    1d84:      	ldr	x25, [x25]
    1d88:      	cmp	w9, #0x7e
    1d8c:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    1d90:      	ldr	x10, [sp, #0x68]
    1d94:      	add	w11, w9, #0x1
    1d98:      	str	wzr, [sp, #0x50]
    1d9c:      	mov	x0, x29
    1da0:      	add	x1, sp, #0x50
    1da4:      	strh	wzr, [sp, #0x54]
    1da8:      	str	w11, [x22, #0x2c0]
    1dac:      	mov	w11, #0x18              // =24
    1db0:      	umaddl	x9, w9, w11, x22
    1db4:      	str	x10, [x9, #0x2d0]
    1db8:      	mov	w10, #0x6               // =6
    1dbc:      	str	x8, [x9, #0x2d8]
    1dc0:      	add	x8, x9, #0x2d0
    1dc4:      	strh	w10, [x9, #0x2e0]
    1dc8:      	ldr	w11, [sp, #0x50]
    1dcc:      	ldrh	w10, [sp, #0x54]
    1dd0:      	stur	w11, [x8, #0x12]
    1dd4:      	mov	w8, #0x36               // =54
    1dd8:      	strh	w10, [x9, #0x2e6]
    1ddc:      	add	x9, sp, #0x50
    1de0:      	str	w8, [sp, #0x50]
    1de4:      	mov	w8, #0x1                // =1
    1de8:      	blr	x8
    1dec:      	cbz	x0, 0x2094 <kprobe_unwind_ruby+0x2094>
    1df0:      	ldr	x8, [x0]
    1df4:      	add	x8, x8, #0x1
    1df8:      	str	x8, [x0]
    1dfc:      	b	0x1530 <kprobe_unwind_ruby+0x1530>
    1e00:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1e04:      	add	x8, x8, #0x0
    1e08:      	add	x0, sp, #0x8
    1e0c:      	ldp	x9, x10, [x8, #0x10]
    1e10:      	mov	w1, #0x2e               // =46
    1e14:      	stp	x9, x10, [sp, #0x18]
    1e18:      	ldr	x9, [x8, #0x20]
    1e1c:      	add	x10, sp, #0x8
    1e20:      	str	x9, [sp, #0x28]
    1e24:      	ldur	x9, [x8, #0x26]
    1e28:      	stur	x9, [sp, #0x2e]
    1e2c:      	ldp	x9, x8, [x8]
    1e30:      	stp	x9, x8, [sp, #0x8]
    1e34:      	mov	w8, #0x2e               // =46
    1e38:      	mov	w9, #0x6                // =6
    1e3c:      	ldr	w2, [sp, #0x50]
    1e40:      	blr	x9
    1e44:      	b	0xe90 <kprobe_unwind_ruby+0xe90>
    1e48:      	ldr	w8, [x23]
    1e4c:      	lsr	w8, w8, #9
    1e50:      	cmp	w8, #0x103
    1e54:      	b.hs	0x2038 <kprobe_unwind_ruby+0x2038>
    1e58:      	ldr	x8, [sp, #0x78]
    1e5c:      	ldr	x9, [sp]
    1e60:      	cmp	x9, x8
    1e64:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    1e68:      	ldrb	w9, [x23, #0x1e]
    1e6c:      	str	xzr, [sp, #0x60]
    1e70:      	mov	w20, #0x8               // =8
    1e74:      	mov	w10, #0x70              // =112
    1e78:      	add	x0, sp, #0x70
    1e7c:      	mov	w1, #0x8                // =8
    1e80:      	mov	w24, #0x70              // =112
    1e84:      	add	x8, x8, x9
    1e88:      	ldrb	w9, [x23, #0x1c]
    1e8c:      	stp	xzr, x8, [sp, #0x70]
    1e90:      	add	x8, x8, x9
    1e94:      	add	x9, sp, #0x70
    1e98:      	ldr	x8, [sp, #0x78]
    1e9c:      	ldrb	w9, [x23, #0x1c]
    1ea0:      	add	x2, x8, x9
    1ea4:      	blr	x10
    1ea8:      	ldr	x8, [sp, #0x78]
    1eac:      	ldrb	w9, [x23, #0x1b]
    1eb0:      	add	x0, sp, #0x60
    1eb4:      	mov	w1, #0x8                // =8
    1eb8:      	add	x8, x8, x9
    1ebc:      	add	x9, sp, #0x60
    1ec0:      	ldr	x8, [sp, #0x78]
    1ec4:      	ldrb	w9, [x23, #0x1b]
    1ec8:      	add	x2, x8, x9
    1ecc:      	blr	x24
    1ed0:      	ldr	x8, [sp, #0x60]
    1ed4:      	cbz	x8, 0x21c0 <kprobe_unwind_ruby+0x21c0>
    1ed8:      	ldr	x8, [sp, #0x70]
    1edc:      	cbz	x8, 0x21c0 <kprobe_unwind_ruby+0x21c0>
    1ee0:      	ldrb	w9, [x23, #0x1f]
    1ee4:      	mov	w10, #0x70              // =112
    1ee8:      	add	x11, sp, #0x68
    1eec:      	add	x0, sp, #0x68
    1ef0:      	mov	w1, #0x8                // =8
    1ef4:      	add	x8, x8, x9
    1ef8:      	mov	w9, #0x8                // =8
    1efc:      	ldr	x8, [sp, #0x70]
    1f00:      	ldrb	w9, [x23, #0x1f]
    1f04:      	add	x2, x8, x9
    1f08:      	blr	x10
    1f0c:      	adrp	x25, 0x1000 <kprobe_unwind_ruby+0x1000>
    1f10:      	mov	x20, x29
    1f14:      	ldr	x25, [x25]
    1f18:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    1f1c:      	ldr	x8, [sp, #0x68]
    1f20:      	ldrb	w9, [x23, #0x21]
    1f24:      	mov	w10, #0x70              // =112
    1f28:      	add	x11, sp, #0x58
    1f2c:      	add	x0, sp, #0x58
    1f30:      	mov	w1, #0x8                // =8
    1f34:      	add	x8, x8, x9
    1f38:      	mov	w9, #0x8                // =8
    1f3c:      	ldr	x8, [sp, #0x68]
    1f40:      	ldrb	w9, [x23, #0x21]
    1f44:      	add	x2, x8, x9
    1f48:      	blr	x10
    1f4c:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    1f50:      	ldr	x8, [sp, #0x68]
    1f54:      	ldrb	w9, [x23, #0x22]
    1f58:      	mov	w10, #0x70              // =112
    1f5c:      	add	x11, sp, #0x88
    1f60:      	add	x0, sp, #0x88
    1f64:      	mov	w1, #0x4                // =4
    1f68:      	add	x8, x8, x9
    1f6c:      	mov	w9, #0x4                // =4
    1f70:      	ldr	x8, [sp, #0x68]
    1f74:      	ldrb	w9, [x23, #0x22]
    1f78:      	add	x2, x8, x9
    1f7c:      	blr	x10
    1f80:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    1f84:      	ldrb	w9, [x23, #0x23]
    1f88:      	ldr	x8, [sp, #0x60]
    1f8c:      	cbz	x9, 0x275c <kprobe_unwind_ruby+0x275c>
    1f90:      	ldr	x10, [sp, #0x58]
    1f94:      	sub	x10, x8, x10
    1f98:      	udiv	x9, x10, x9
    1f9c:      	ldr	w10, [sp, #0x88]
    1fa0:      	cmp	x9, x10
    1fa4:      	b.ls	0x275c <kprobe_unwind_ruby+0x275c>
    1fa8:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1fac:      	ldr	x8, [x8]
    1fb0:      	ldr	w8, [x8]
    1fb4:      	cbz	w8, 0x21d0 <kprobe_unwind_ruby+0x21d0>
    1fb8:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    1fbc:      	add	x8, x8, #0x0
    1fc0:      	add	x0, sp, #0x8
    1fc4:      	ldp	x9, x10, [x8, #0x10]
    1fc8:      	mov	w1, #0x2d               // =45
    1fcc:      	stp	x9, x10, [sp, #0x18]
    1fd0:      	ldr	x9, [x8, #0x20]
    1fd4:      	add	x10, sp, #0x8
    1fd8:      	str	x9, [sp, #0x28]
    1fdc:      	ldur	x9, [x8, #0x25]
    1fe0:      	stur	x9, [sp, #0x2d]
    1fe4:      	ldp	x9, x8, [x8]
    1fe8:      	stp	x9, x8, [sp, #0x8]
    1fec:      	mov	w8, #0x2d               // =45
    1ff0:      	mov	w9, #0x6                // =6
    1ff4:      	blr	x9
    1ff8:      	b	0x21d0 <kprobe_unwind_ruby+0x21d0>
    1ffc:      	adrp	x8, 0x1000 <kprobe_unwind_ruby+0x1000>
    2000:      	add	x8, x8, #0x0
    2004:      	add	x0, sp, #0x8
    2008:      	ldp	x9, x10, [x8, #0x10]
    200c:      	mov	w1, #0x25               // =37
    2010:      	stp	x9, x10, [sp, #0x18]
    2014:      	ldur	x9, [x8, #0x1d]
    2018:      	add	x10, sp, #0x8
    201c:      	stur	x9, [sp, #0x25]
    2020:      	ldp	x8, x9, [x8]
    2024:      	stp	x8, x9, [sp, #0x8]
    2028:      	mov	w8, #0x25               // =37
    202c:      	mov	w9, #0x6                // =6
    2030:      	blr	x9
    2034:      	b	0xeb0 <kprobe_unwind_ruby+0xeb0>
    2038:      	ldr	x8, [sp, #0x78]
    203c:      	ldrb	w9, [x23, #0x1d]
    2040:      	mov	w10, #0x70              // =112
    2044:      	add	x11, sp, #0x50
    2048:      	add	x0, sp, #0x50
    204c:      	mov	w1, #0x8                // =8
    2050:      	str	xzr, [sp, #0x50]
    2054:      	add	x8, x8, x9
    2058:      	mov	w9, #0x8                // =8
    205c:      	ldr	x8, [sp, #0x78]
    2060:      	ldrb	w9, [x23, #0x1d]
    2064:      	add	x2, x8, x9
    2068:      	blr	x10
    206c:      	adrp	x25, 0x2000 <kprobe_unwind_ruby+0x2000>
    2070:      	mov	x20, x29
    2074:      	ldr	x25, [x25]
    2078:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    207c:      	ldr	w8, [sp, #0x50]
    2080:      	mov	w9, #0x140              // =320
    2084:      	mvn	w8, w8
    2088:      	tst	x8, x9
    208c:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    2090:      	b	0x1e58 <kprobe_unwind_ruby+0x1e58>
    2094:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    2098:      	ldr	x8, [x8]
    209c:      	ldr	w8, [x8]
    20a0:      	cbz	w8, 0x1530 <kprobe_unwind_ruby+0x1530>
    20a4:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    20a8:      	add	x8, x8, #0x0
    20ac:      	add	x0, sp, #0x8
    20b0:      	ldp	x9, x10, [x8, #0x10]
    20b4:      	mov	w1, #0x2e               // =46
    20b8:      	stp	x9, x10, [sp, #0x18]
    20bc:      	ldr	x9, [x8, #0x20]
    20c0:      	add	x10, sp, #0x8
    20c4:      	str	x9, [sp, #0x28]
    20c8:      	ldur	x9, [x8, #0x26]
    20cc:      	stur	x9, [sp, #0x2e]
    20d0:      	ldp	x9, x8, [x8]
    20d4:      	stp	x9, x8, [sp, #0x8]
    20d8:      	mov	w8, #0x2e               // =46
    20dc:      	mov	w9, #0x6                // =6
    20e0:      	ldr	w2, [sp, #0x50]
    20e4:      	blr	x9
    20e8:      	b	0x1530 <kprobe_unwind_ruby+0x1530>
    20ec:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    20f0:      	add	x8, x8, #0x0
    20f4:      	add	x0, sp, #0x8
    20f8:      	ldp	x9, x10, [x8, #0x10]
    20fc:      	mov	w1, #0x2e               // =46
    2100:      	stp	x9, x10, [sp, #0x18]
    2104:      	ldr	x9, [x8, #0x20]
    2108:      	add	x10, sp, #0x8
    210c:      	str	x9, [sp, #0x28]
    2110:      	ldur	x9, [x8, #0x26]
    2114:      	stur	x9, [sp, #0x2e]
    2118:      	ldp	x9, x8, [x8]
    211c:      	stp	x9, x8, [sp, #0x8]
    2120:      	mov	w8, #0x2e               // =46
    2124:      	mov	w9, #0x6                // =6
    2128:      	ldr	w2, [sp, #0x8c]
    212c:      	blr	x9
    2130:      	ldr	w8, [x25]
    2134:      	cbnz	w8, 0xee8 <kprobe_unwind_ruby+0xee8>
    2138:      	b	0x11a4 <kprobe_unwind_ruby+0x11a4>
    213c:      	ldr	w9, [x22, #0x2c0]
    2140:      	adrp	x25, 0x2000 <kprobe_unwind_ruby+0x2000>
    2144:      	ldr	x25, [x25]
    2148:      	cmp	w9, #0x7e
    214c:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    2150:      	ldr	x10, [sp, #0x68]
    2154:      	add	w11, w9, #0x1
    2158:      	str	wzr, [sp, #0x50]
    215c:      	mov	x0, x29
    2160:      	add	x1, sp, #0x50
    2164:      	strh	wzr, [sp, #0x54]
    2168:      	str	w11, [x22, #0x2c0]
    216c:      	mov	w11, #0x18              // =24
    2170:      	umaddl	x9, w9, w11, x22
    2174:      	str	x10, [x9, #0x2d0]
    2178:      	mov	w10, #0x6               // =6
    217c:      	str	x8, [x9, #0x2d8]
    2180:      	add	x8, x9, #0x2d0
    2184:      	strh	w10, [x9, #0x2e0]
    2188:      	ldr	w11, [sp, #0x50]
    218c:      	ldrh	w10, [sp, #0x54]
    2190:      	stur	w11, [x8, #0x12]
    2194:      	mov	w8, #0x36               // =54
    2198:      	strh	w10, [x9, #0x2e6]
    219c:      	add	x9, sp, #0x50
    21a0:      	str	w8, [sp, #0x50]
    21a4:      	mov	w8, #0x1                // =1
    21a8:      	blr	x8
    21ac:      	cbz	x0, 0x23d0 <kprobe_unwind_ruby+0x23d0>
    21b0:      	ldr	x8, [x0]
    21b4:      	add	x8, x8, #0x1
    21b8:      	str	x8, [x0]
    21bc:      	b	0x1990 <kprobe_unwind_ruby+0x1990>
    21c0:      	ldr	w8, [x23]
    21c4:      	lsr	w8, w8, #9
    21c8:      	cmp	w8, #0x103
    21cc:      	b.hs	0x2374 <kprobe_unwind_ruby+0x2374>
    21d0:      	ldr	x8, [sp, #0x78]
    21d4:      	ldr	x9, [sp]
    21d8:      	cmp	x9, x8
    21dc:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    21e0:      	ldrb	w9, [x23, #0x1e]
    21e4:      	str	xzr, [sp, #0x60]
    21e8:      	mov	w20, #0x8               // =8
    21ec:      	mov	w10, #0x70              // =112
    21f0:      	add	x0, sp, #0x70
    21f4:      	mov	w1, #0x8                // =8
    21f8:      	mov	w24, #0x70              // =112
    21fc:      	add	x8, x8, x9
    2200:      	ldrb	w9, [x23, #0x1c]
    2204:      	stp	xzr, x8, [sp, #0x70]
    2208:      	add	x8, x8, x9
    220c:      	add	x9, sp, #0x70
    2210:      	ldr	x8, [sp, #0x78]
    2214:      	ldrb	w9, [x23, #0x1c]
    2218:      	add	x2, x8, x9
    221c:      	blr	x10
    2220:      	ldr	x8, [sp, #0x78]
    2224:      	ldrb	w9, [x23, #0x1b]
    2228:      	add	x0, sp, #0x60
    222c:      	mov	w1, #0x8                // =8
    2230:      	add	x8, x8, x9
    2234:      	add	x9, sp, #0x60
    2238:      	ldr	x8, [sp, #0x78]
    223c:      	ldrb	w9, [x23, #0x1b]
    2240:      	add	x2, x8, x9
    2244:      	blr	x24
    2248:      	ldr	x8, [sp, #0x60]
    224c:      	cbz	x8, 0x24f4 <kprobe_unwind_ruby+0x24f4>
    2250:      	ldr	x8, [sp, #0x70]
    2254:      	cbz	x8, 0x24f4 <kprobe_unwind_ruby+0x24f4>
    2258:      	ldrb	w9, [x23, #0x1f]
    225c:      	mov	w10, #0x70              // =112
    2260:      	add	x11, sp, #0x68
    2264:      	add	x0, sp, #0x68
    2268:      	mov	w1, #0x8                // =8
    226c:      	add	x8, x8, x9
    2270:      	mov	w9, #0x8                // =8
    2274:      	ldr	x8, [sp, #0x70]
    2278:      	ldrb	w9, [x23, #0x1f]
    227c:      	add	x2, x8, x9
    2280:      	blr	x10
    2284:      	adrp	x25, 0x2000 <kprobe_unwind_ruby+0x2000>
    2288:      	mov	x20, x29
    228c:      	ldr	x25, [x25]
    2290:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    2294:      	ldr	x8, [sp, #0x68]
    2298:      	ldrb	w9, [x23, #0x21]
    229c:      	mov	w10, #0x70              // =112
    22a0:      	add	x11, sp, #0x58
    22a4:      	add	x0, sp, #0x58
    22a8:      	mov	w1, #0x8                // =8
    22ac:      	add	x8, x8, x9
    22b0:      	mov	w9, #0x8                // =8
    22b4:      	ldr	x8, [sp, #0x68]
    22b8:      	ldrb	w9, [x23, #0x21]
    22bc:      	add	x2, x8, x9
    22c0:      	blr	x10
    22c4:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    22c8:      	ldr	x8, [sp, #0x68]
    22cc:      	ldrb	w9, [x23, #0x22]
    22d0:      	mov	w10, #0x70              // =112
    22d4:      	add	x11, sp, #0x88
    22d8:      	add	x0, sp, #0x88
    22dc:      	mov	w1, #0x4                // =4
    22e0:      	add	x8, x8, x9
    22e4:      	mov	w9, #0x4                // =4
    22e8:      	ldr	x8, [sp, #0x68]
    22ec:      	ldrb	w9, [x23, #0x22]
    22f0:      	add	x2, x8, x9
    22f4:      	blr	x10
    22f8:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    22fc:      	ldrb	w9, [x23, #0x23]
    2300:      	ldr	x8, [sp, #0x60]
    2304:      	cbz	x9, 0x2a90 <kprobe_unwind_ruby+0x2a90>
    2308:      	ldr	x10, [sp, #0x58]
    230c:      	sub	x10, x8, x10
    2310:      	udiv	x9, x10, x9
    2314:      	ldr	w10, [sp, #0x88]
    2318:      	cmp	x9, x10
    231c:      	b.ls	0x2a90 <kprobe_unwind_ruby+0x2a90>
    2320:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    2324:      	ldr	x8, [x8]
    2328:      	ldr	w8, [x8]
    232c:      	cbz	w8, 0x2504 <kprobe_unwind_ruby+0x2504>
    2330:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    2334:      	add	x8, x8, #0x0
    2338:      	add	x0, sp, #0x8
    233c:      	ldp	x9, x10, [x8, #0x10]
    2340:      	mov	w1, #0x2d               // =45
    2344:      	stp	x9, x10, [sp, #0x18]
    2348:      	ldr	x9, [x8, #0x20]
    234c:      	add	x10, sp, #0x8
    2350:      	str	x9, [sp, #0x28]
    2354:      	ldur	x9, [x8, #0x25]
    2358:      	stur	x9, [sp, #0x2d]
    235c:      	ldp	x9, x8, [x8]
    2360:      	stp	x9, x8, [sp, #0x8]
    2364:      	mov	w8, #0x2d               // =45
    2368:      	mov	w9, #0x6                // =6
    236c:      	blr	x9
    2370:      	b	0x2504 <kprobe_unwind_ruby+0x2504>
    2374:      	ldr	x8, [sp, #0x78]
    2378:      	ldrb	w9, [x23, #0x1d]
    237c:      	mov	w10, #0x70              // =112
    2380:      	add	x11, sp, #0x50
    2384:      	add	x0, sp, #0x50
    2388:      	mov	w1, #0x8                // =8
    238c:      	str	xzr, [sp, #0x50]
    2390:      	add	x8, x8, x9
    2394:      	mov	w9, #0x8                // =8
    2398:      	ldr	x8, [sp, #0x78]
    239c:      	ldrb	w9, [x23, #0x1d]
    23a0:      	add	x2, x8, x9
    23a4:      	blr	x10
    23a8:      	adrp	x25, 0x2000 <kprobe_unwind_ruby+0x2000>
    23ac:      	mov	x20, x29
    23b0:      	ldr	x25, [x25]
    23b4:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    23b8:      	ldr	w8, [sp, #0x50]
    23bc:      	mov	w9, #0x140              // =320
    23c0:      	mvn	w8, w8
    23c4:      	tst	x8, x9
    23c8:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    23cc:      	b	0x21d0 <kprobe_unwind_ruby+0x21d0>
    23d0:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    23d4:      	ldr	x8, [x8]
    23d8:      	ldr	w8, [x8]
    23dc:      	cbz	w8, 0x1990 <kprobe_unwind_ruby+0x1990>
    23e0:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    23e4:      	add	x8, x8, #0x0
    23e8:      	add	x0, sp, #0x8
    23ec:      	ldp	x9, x10, [x8, #0x10]
    23f0:      	mov	w1, #0x2e               // =46
    23f4:      	stp	x9, x10, [sp, #0x18]
    23f8:      	ldr	x9, [x8, #0x20]
    23fc:      	add	x10, sp, #0x8
    2400:      	str	x9, [sp, #0x28]
    2404:      	ldur	x9, [x8, #0x26]
    2408:      	stur	x9, [sp, #0x2e]
    240c:      	ldp	x9, x8, [x8]
    2410:      	stp	x9, x8, [sp, #0x8]
    2414:      	mov	w8, #0x2e               // =46
    2418:      	mov	w9, #0x6                // =6
    241c:      	ldr	w2, [sp, #0x50]
    2420:      	blr	x9
    2424:      	b	0x1990 <kprobe_unwind_ruby+0x1990>
    2428:      	ldr	w9, [x22, #0x2c0]
    242c:      	adrp	x25, 0x2000 <kprobe_unwind_ruby+0x2000>
    2430:      	ldr	x25, [x25]
    2434:      	cmp	w9, #0x7e
    2438:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    243c:      	ldr	x10, [sp, #0x68]
    2440:      	add	w11, w9, #0x1
    2444:      	str	wzr, [sp, #0x50]
    2448:      	mov	x0, x29
    244c:      	add	x1, sp, #0x50
    2450:      	strh	wzr, [sp, #0x54]
    2454:      	str	w11, [x22, #0x2c0]
    2458:      	mov	w11, #0x18              // =24
    245c:      	umaddl	x9, w9, w11, x22
    2460:      	str	x10, [x9, #0x2d0]
    2464:      	mov	w10, #0x6               // =6
    2468:      	str	x8, [x9, #0x2d8]
    246c:      	add	x8, x9, #0x2d0
    2470:      	strh	w10, [x9, #0x2e0]
    2474:      	ldr	w11, [sp, #0x50]
    2478:      	ldrh	w10, [sp, #0x54]
    247c:      	stur	w11, [x8, #0x12]
    2480:      	mov	w8, #0x36               // =54
    2484:      	strh	w10, [x9, #0x2e6]
    2488:      	add	x9, sp, #0x50
    248c:      	str	w8, [sp, #0x50]
    2490:      	mov	w8, #0x1                // =1
    2494:      	blr	x8
    2498:      	cbz	x0, 0x2704 <kprobe_unwind_ruby+0x2704>
    249c:      	ldr	x8, [x0]
    24a0:      	add	x8, x8, #0x1
    24a4:      	str	x8, [x0]
    24a8:      	b	0x1e58 <kprobe_unwind_ruby+0x1e58>
    24ac:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    24b0:      	add	x8, x8, #0x0
    24b4:      	add	x0, sp, #0x8
    24b8:      	ldp	x9, x10, [x8, #0x10]
    24bc:      	mov	w1, #0x2e               // =46
    24c0:      	stp	x9, x10, [sp, #0x18]
    24c4:      	ldr	x9, [x8, #0x20]
    24c8:      	add	x10, sp, #0x8
    24cc:      	str	x9, [sp, #0x28]
    24d0:      	ldur	x9, [x8, #0x26]
    24d4:      	stur	x9, [sp, #0x2e]
    24d8:      	ldp	x9, x8, [x8]
    24dc:      	stp	x9, x8, [sp, #0x8]
    24e0:      	mov	w8, #0x2e               // =46
    24e4:      	mov	w9, #0x6                // =6
    24e8:      	ldr	w2, [sp, #0x50]
    24ec:      	blr	x9
    24f0:      	b	0x1498 <kprobe_unwind_ruby+0x1498>
    24f4:      	ldr	w8, [x23]
    24f8:      	lsr	w8, w8, #9
    24fc:      	cmp	w8, #0x103
    2500:      	b.hs	0x26a8 <kprobe_unwind_ruby+0x26a8>
    2504:      	ldr	x8, [sp, #0x78]
    2508:      	ldr	x9, [sp]
    250c:      	cmp	x9, x8
    2510:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    2514:      	ldrb	w9, [x23, #0x1e]
    2518:      	str	xzr, [sp, #0x60]
    251c:      	mov	w20, #0x8               // =8
    2520:      	mov	w10, #0x70              // =112
    2524:      	add	x0, sp, #0x70
    2528:      	mov	w1, #0x8                // =8
    252c:      	mov	w24, #0x70              // =112
    2530:      	add	x8, x8, x9
    2534:      	ldrb	w9, [x23, #0x1c]
    2538:      	stp	xzr, x8, [sp, #0x70]
    253c:      	add	x8, x8, x9
    2540:      	add	x9, sp, #0x70
    2544:      	ldr	x8, [sp, #0x78]
    2548:      	ldrb	w9, [x23, #0x1c]
    254c:      	add	x2, x8, x9
    2550:      	blr	x10
    2554:      	ldr	x8, [sp, #0x78]
    2558:      	ldrb	w9, [x23, #0x1b]
    255c:      	add	x0, sp, #0x60
    2560:      	mov	w1, #0x8                // =8
    2564:      	add	x8, x8, x9
    2568:      	add	x9, sp, #0x60
    256c:      	ldr	x8, [sp, #0x78]
    2570:      	ldrb	w9, [x23, #0x1b]
    2574:      	add	x2, x8, x9
    2578:      	blr	x24
    257c:      	ldr	x8, [sp, #0x60]
    2580:      	cbz	x8, 0x2828 <kprobe_unwind_ruby+0x2828>
    2584:      	ldr	x8, [sp, #0x70]
    2588:      	cbz	x8, 0x2828 <kprobe_unwind_ruby+0x2828>
    258c:      	ldrb	w9, [x23, #0x1f]
    2590:      	mov	w10, #0x70              // =112
    2594:      	add	x11, sp, #0x68
    2598:      	add	x0, sp, #0x68
    259c:      	mov	w1, #0x8                // =8
    25a0:      	add	x8, x8, x9
    25a4:      	mov	w9, #0x8                // =8
    25a8:      	ldr	x8, [sp, #0x70]
    25ac:      	ldrb	w9, [x23, #0x1f]
    25b0:      	add	x2, x8, x9
    25b4:      	blr	x10
    25b8:      	adrp	x25, 0x2000 <kprobe_unwind_ruby+0x2000>
    25bc:      	mov	x20, x29
    25c0:      	ldr	x25, [x25]
    25c4:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    25c8:      	ldr	x8, [sp, #0x68]
    25cc:      	ldrb	w9, [x23, #0x21]
    25d0:      	mov	w10, #0x70              // =112
    25d4:      	add	x11, sp, #0x58
    25d8:      	add	x0, sp, #0x58
    25dc:      	mov	w1, #0x8                // =8
    25e0:      	add	x8, x8, x9
    25e4:      	mov	w9, #0x8                // =8
    25e8:      	ldr	x8, [sp, #0x68]
    25ec:      	ldrb	w9, [x23, #0x21]
    25f0:      	add	x2, x8, x9
    25f4:      	blr	x10
    25f8:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    25fc:      	ldr	x8, [sp, #0x68]
    2600:      	ldrb	w9, [x23, #0x22]
    2604:      	mov	w10, #0x70              // =112
    2608:      	add	x11, sp, #0x88
    260c:      	add	x0, sp, #0x88
    2610:      	mov	w1, #0x4                // =4
    2614:      	add	x8, x8, x9
    2618:      	mov	w9, #0x4                // =4
    261c:      	ldr	x8, [sp, #0x68]
    2620:      	ldrb	w9, [x23, #0x22]
    2624:      	add	x2, x8, x9
    2628:      	blr	x10
    262c:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    2630:      	ldrb	w9, [x23, #0x23]
    2634:      	ldr	x8, [sp, #0x60]
    2638:      	cbz	x9, 0x2d7c <kprobe_unwind_ruby+0x2d7c>
    263c:      	ldr	x10, [sp, #0x58]
    2640:      	sub	x10, x8, x10
    2644:      	udiv	x9, x10, x9
    2648:      	ldr	w10, [sp, #0x88]
    264c:      	cmp	x9, x10
    2650:      	b.ls	0x2d7c <kprobe_unwind_ruby+0x2d7c>
    2654:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    2658:      	ldr	x8, [x8]
    265c:      	ldr	w8, [x8]
    2660:      	cbz	w8, 0x2838 <kprobe_unwind_ruby+0x2838>
    2664:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    2668:      	add	x8, x8, #0x0
    266c:      	add	x0, sp, #0x8
    2670:      	ldp	x9, x10, [x8, #0x10]
    2674:      	mov	w1, #0x2d               // =45
    2678:      	stp	x9, x10, [sp, #0x18]
    267c:      	ldr	x9, [x8, #0x20]
    2680:      	add	x10, sp, #0x8
    2684:      	str	x9, [sp, #0x28]
    2688:      	ldur	x9, [x8, #0x25]
    268c:      	stur	x9, [sp, #0x2d]
    2690:      	ldp	x9, x8, [x8]
    2694:      	stp	x9, x8, [sp, #0x8]
    2698:      	mov	w8, #0x2d               // =45
    269c:      	mov	w9, #0x6                // =6
    26a0:      	blr	x9
    26a4:      	b	0x2838 <kprobe_unwind_ruby+0x2838>
    26a8:      	ldr	x8, [sp, #0x78]
    26ac:      	ldrb	w9, [x23, #0x1d]
    26b0:      	mov	w10, #0x70              // =112
    26b4:      	add	x11, sp, #0x50
    26b8:      	add	x0, sp, #0x50
    26bc:      	mov	w1, #0x8                // =8
    26c0:      	str	xzr, [sp, #0x50]
    26c4:      	add	x8, x8, x9
    26c8:      	mov	w9, #0x8                // =8
    26cc:      	ldr	x8, [sp, #0x78]
    26d0:      	ldrb	w9, [x23, #0x1d]
    26d4:      	add	x2, x8, x9
    26d8:      	blr	x10
    26dc:      	adrp	x25, 0x2000 <kprobe_unwind_ruby+0x2000>
    26e0:      	mov	x20, x29
    26e4:      	ldr	x25, [x25]
    26e8:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    26ec:      	ldr	w8, [sp, #0x50]
    26f0:      	mov	w9, #0x140              // =320
    26f4:      	mvn	w8, w8
    26f8:      	tst	x8, x9
    26fc:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    2700:      	b	0x2504 <kprobe_unwind_ruby+0x2504>
    2704:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    2708:      	ldr	x8, [x8]
    270c:      	ldr	w8, [x8]
    2710:      	cbz	w8, 0x1e58 <kprobe_unwind_ruby+0x1e58>
    2714:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    2718:      	add	x8, x8, #0x0
    271c:      	add	x0, sp, #0x8
    2720:      	ldp	x9, x10, [x8, #0x10]
    2724:      	mov	w1, #0x2e               // =46
    2728:      	stp	x9, x10, [sp, #0x18]
    272c:      	ldr	x9, [x8, #0x20]
    2730:      	add	x10, sp, #0x8
    2734:      	str	x9, [sp, #0x28]
    2738:      	ldur	x9, [x8, #0x26]
    273c:      	stur	x9, [sp, #0x2e]
    2740:      	ldp	x9, x8, [x8]
    2744:      	stp	x9, x8, [sp, #0x8]
    2748:      	mov	w8, #0x2e               // =46
    274c:      	mov	w9, #0x6                // =6
    2750:      	ldr	w2, [sp, #0x50]
    2754:      	blr	x9
    2758:      	b	0x1e58 <kprobe_unwind_ruby+0x1e58>
    275c:      	ldr	w9, [x22, #0x2c0]
    2760:      	adrp	x25, 0x2000 <kprobe_unwind_ruby+0x2000>
    2764:      	ldr	x25, [x25]
    2768:      	cmp	w9, #0x7e
    276c:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    2770:      	ldr	x10, [sp, #0x68]
    2774:      	add	w11, w9, #0x1
    2778:      	str	wzr, [sp, #0x50]
    277c:      	mov	x0, x29
    2780:      	add	x1, sp, #0x50
    2784:      	strh	wzr, [sp, #0x54]
    2788:      	str	w11, [x22, #0x2c0]
    278c:      	mov	w11, #0x18              // =24
    2790:      	umaddl	x9, w9, w11, x22
    2794:      	str	x10, [x9, #0x2d0]
    2798:      	mov	w10, #0x6               // =6
    279c:      	str	x8, [x9, #0x2d8]
    27a0:      	add	x8, x9, #0x2d0
    27a4:      	strh	w10, [x9, #0x2e0]
    27a8:      	ldr	w11, [sp, #0x50]
    27ac:      	ldrh	w10, [sp, #0x54]
    27b0:      	stur	w11, [x8, #0x12]
    27b4:      	mov	w8, #0x36               // =54
    27b8:      	strh	w10, [x9, #0x2e6]
    27bc:      	add	x9, sp, #0x50
    27c0:      	str	w8, [sp, #0x50]
    27c4:      	mov	w8, #0x1                // =1
    27c8:      	blr	x8
    27cc:      	cbz	x0, 0x2a38 <kprobe_unwind_ruby+0x2a38>
    27d0:      	ldr	x8, [x0]
    27d4:      	add	x8, x8, #0x1
    27d8:      	str	x8, [x0]
    27dc:      	b	0x21d0 <kprobe_unwind_ruby+0x21d0>
    27e0:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    27e4:      	add	x8, x8, #0x0
    27e8:      	add	x0, sp, #0x8
    27ec:      	ldp	x9, x10, [x8, #0x10]
    27f0:      	mov	w1, #0x2e               // =46
    27f4:      	stp	x9, x10, [sp, #0x18]
    27f8:      	ldr	x9, [x8, #0x20]
    27fc:      	add	x10, sp, #0x8
    2800:      	str	x9, [sp, #0x28]
    2804:      	ldur	x9, [x8, #0x26]
    2808:      	stur	x9, [sp, #0x2e]
    280c:      	ldp	x9, x8, [x8]
    2810:      	stp	x9, x8, [sp, #0x8]
    2814:      	mov	w8, #0x2e               // =46
    2818:      	mov	w9, #0x6                // =6
    281c:      	ldr	w2, [sp, #0x50]
    2820:      	blr	x9
    2824:      	b	0x186c <kprobe_unwind_ruby+0x186c>
    2828:      	ldr	w8, [x23]
    282c:      	lsr	w8, w8, #9
    2830:      	cmp	w8, #0x103
    2834:      	b.hs	0x29dc <kprobe_unwind_ruby+0x29dc>
    2838:      	ldr	x8, [sp, #0x78]
    283c:      	ldr	x9, [sp]
    2840:      	cmp	x9, x8
    2844:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    2848:      	ldrb	w9, [x23, #0x1e]
    284c:      	str	xzr, [sp, #0x60]
    2850:      	mov	w20, #0x8               // =8
    2854:      	mov	w10, #0x70              // =112
    2858:      	add	x0, sp, #0x70
    285c:      	mov	w1, #0x8                // =8
    2860:      	mov	w24, #0x70              // =112
    2864:      	add	x8, x8, x9
    2868:      	ldrb	w9, [x23, #0x1c]
    286c:      	stp	xzr, x8, [sp, #0x70]
    2870:      	add	x8, x8, x9
    2874:      	add	x9, sp, #0x70
    2878:      	ldr	x8, [sp, #0x78]
    287c:      	ldrb	w9, [x23, #0x1c]
    2880:      	add	x2, x8, x9
    2884:      	blr	x10
    2888:      	ldr	x8, [sp, #0x78]
    288c:      	ldrb	w9, [x23, #0x1b]
    2890:      	add	x0, sp, #0x60
    2894:      	mov	w1, #0x8                // =8
    2898:      	add	x8, x8, x9
    289c:      	add	x9, sp, #0x60
    28a0:      	ldr	x8, [sp, #0x78]
    28a4:      	ldrb	w9, [x23, #0x1b]
    28a8:      	add	x2, x8, x9
    28ac:      	blr	x24
    28b0:      	ldr	x8, [sp, #0x60]
    28b4:      	cbz	x8, 0x2b14 <kprobe_unwind_ruby+0x2b14>
    28b8:      	ldr	x8, [sp, #0x70]
    28bc:      	cbz	x8, 0x2b14 <kprobe_unwind_ruby+0x2b14>
    28c0:      	ldrb	w9, [x23, #0x1f]
    28c4:      	mov	w10, #0x70              // =112
    28c8:      	add	x11, sp, #0x68
    28cc:      	add	x0, sp, #0x68
    28d0:      	mov	w1, #0x8                // =8
    28d4:      	add	x8, x8, x9
    28d8:      	mov	w9, #0x8                // =8
    28dc:      	ldr	x8, [sp, #0x70]
    28e0:      	ldrb	w9, [x23, #0x1f]
    28e4:      	add	x2, x8, x9
    28e8:      	blr	x10
    28ec:      	adrp	x25, 0x2000 <kprobe_unwind_ruby+0x2000>
    28f0:      	mov	x20, x29
    28f4:      	ldr	x25, [x25]
    28f8:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    28fc:      	ldr	x8, [sp, #0x68]
    2900:      	ldrb	w9, [x23, #0x21]
    2904:      	mov	w10, #0x70              // =112
    2908:      	add	x11, sp, #0x58
    290c:      	add	x0, sp, #0x58
    2910:      	mov	w1, #0x8                // =8
    2914:      	add	x8, x8, x9
    2918:      	mov	w9, #0x8                // =8
    291c:      	ldr	x8, [sp, #0x68]
    2920:      	ldrb	w9, [x23, #0x21]
    2924:      	add	x2, x8, x9
    2928:      	blr	x10
    292c:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    2930:      	ldr	x8, [sp, #0x68]
    2934:      	ldrb	w9, [x23, #0x22]
    2938:      	mov	w10, #0x70              // =112
    293c:      	add	x11, sp, #0x88
    2940:      	add	x0, sp, #0x88
    2944:      	mov	w1, #0x4                // =4
    2948:      	add	x8, x8, x9
    294c:      	mov	w9, #0x4                // =4
    2950:      	ldr	x8, [sp, #0x68]
    2954:      	ldrb	w9, [x23, #0x22]
    2958:      	add	x2, x8, x9
    295c:      	blr	x10
    2960:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    2964:      	ldrb	w9, [x23, #0x23]
    2968:      	ldr	x8, [sp, #0x60]
    296c:      	cbz	x9, 0x3068 <kprobe_unwind_ruby+0x3068>
    2970:      	ldr	x10, [sp, #0x58]
    2974:      	sub	x10, x8, x10
    2978:      	udiv	x9, x10, x9
    297c:      	ldr	w10, [sp, #0x88]
    2980:      	cmp	x9, x10
    2984:      	b.ls	0x3068 <kprobe_unwind_ruby+0x3068>
    2988:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    298c:      	ldr	x8, [x8]
    2990:      	ldr	w8, [x8]
    2994:      	cbz	w8, 0x2b24 <kprobe_unwind_ruby+0x2b24>
    2998:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    299c:      	add	x8, x8, #0x0
    29a0:      	add	x0, sp, #0x8
    29a4:      	ldp	x9, x10, [x8, #0x10]
    29a8:      	mov	w1, #0x2d               // =45
    29ac:      	stp	x9, x10, [sp, #0x18]
    29b0:      	ldr	x9, [x8, #0x20]
    29b4:      	add	x10, sp, #0x8
    29b8:      	str	x9, [sp, #0x28]
    29bc:      	ldur	x9, [x8, #0x25]
    29c0:      	stur	x9, [sp, #0x2d]
    29c4:      	ldp	x9, x8, [x8]
    29c8:      	stp	x9, x8, [sp, #0x8]
    29cc:      	mov	w8, #0x2d               // =45
    29d0:      	mov	w9, #0x6                // =6
    29d4:      	blr	x9
    29d8:      	b	0x2b24 <kprobe_unwind_ruby+0x2b24>
    29dc:      	ldr	x8, [sp, #0x78]
    29e0:      	ldrb	w9, [x23, #0x1d]
    29e4:      	mov	w10, #0x70              // =112
    29e8:      	add	x11, sp, #0x50
    29ec:      	add	x0, sp, #0x50
    29f0:      	mov	w1, #0x8                // =8
    29f4:      	str	xzr, [sp, #0x50]
    29f8:      	add	x8, x8, x9
    29fc:      	mov	w9, #0x8                // =8
    2a00:      	ldr	x8, [sp, #0x78]
    2a04:      	ldrb	w9, [x23, #0x1d]
    2a08:      	add	x2, x8, x9
    2a0c:      	blr	x10
    2a10:      	adrp	x25, 0x2000 <kprobe_unwind_ruby+0x2000>
    2a14:      	mov	x20, x29
    2a18:      	ldr	x25, [x25]
    2a1c:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    2a20:      	ldr	w8, [sp, #0x50]
    2a24:      	mov	w9, #0x140              // =320
    2a28:      	mvn	w8, w8
    2a2c:      	tst	x8, x9
    2a30:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    2a34:      	b	0x2838 <kprobe_unwind_ruby+0x2838>
    2a38:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    2a3c:      	ldr	x8, [x8]
    2a40:      	ldr	w8, [x8]
    2a44:      	cbz	w8, 0x21d0 <kprobe_unwind_ruby+0x21d0>
    2a48:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    2a4c:      	add	x8, x8, #0x0
    2a50:      	add	x0, sp, #0x8
    2a54:      	ldp	x9, x10, [x8, #0x10]
    2a58:      	mov	w1, #0x2e               // =46
    2a5c:      	stp	x9, x10, [sp, #0x18]
    2a60:      	ldr	x9, [x8, #0x20]
    2a64:      	add	x10, sp, #0x8
    2a68:      	str	x9, [sp, #0x28]
    2a6c:      	ldur	x9, [x8, #0x26]
    2a70:      	stur	x9, [sp, #0x2e]
    2a74:      	ldp	x9, x8, [x8]
    2a78:      	stp	x9, x8, [sp, #0x8]
    2a7c:      	mov	w8, #0x2e               // =46
    2a80:      	mov	w9, #0x6                // =6
    2a84:      	ldr	w2, [sp, #0x50]
    2a88:      	blr	x9
    2a8c:      	b	0x21d0 <kprobe_unwind_ruby+0x21d0>
    2a90:      	ldr	w9, [x22, #0x2c0]
    2a94:      	adrp	x25, 0x2000 <kprobe_unwind_ruby+0x2000>
    2a98:      	ldr	x25, [x25]
    2a9c:      	cmp	w9, #0x7e
    2aa0:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    2aa4:      	ldr	x10, [sp, #0x68]
    2aa8:      	add	w11, w9, #0x1
    2aac:      	str	wzr, [sp, #0x50]
    2ab0:      	mov	x0, x29
    2ab4:      	add	x1, sp, #0x50
    2ab8:      	strh	wzr, [sp, #0x54]
    2abc:      	str	w11, [x22, #0x2c0]
    2ac0:      	mov	w11, #0x18              // =24
    2ac4:      	umaddl	x9, w9, w11, x22
    2ac8:      	str	x10, [x9, #0x2d0]
    2acc:      	mov	w10, #0x6               // =6
    2ad0:      	str	x8, [x9, #0x2d8]
    2ad4:      	add	x8, x9, #0x2d0
    2ad8:      	strh	w10, [x9, #0x2e0]
    2adc:      	ldr	w11, [sp, #0x50]
    2ae0:      	ldrh	w10, [sp, #0x54]
    2ae4:      	stur	w11, [x8, #0x12]
    2ae8:      	mov	w8, #0x36               // =54
    2aec:      	strh	w10, [x9, #0x2e6]
    2af0:      	add	x9, sp, #0x50
    2af4:      	str	w8, [sp, #0x50]
    2af8:      	mov	w8, #0x1                // =1
    2afc:      	blr	x8
    2b00:      	cbz	x0, 0x2d24 <kprobe_unwind_ruby+0x2d24>
    2b04:      	ldr	x8, [x0]
    2b08:      	add	x8, x8, #0x1
    2b0c:      	str	x8, [x0]
    2b10:      	b	0x2504 <kprobe_unwind_ruby+0x2504>
    2b14:      	ldr	w8, [x23]
    2b18:      	lsr	w8, w8, #9
    2b1c:      	cmp	w8, #0x103
    2b20:      	b.hs	0x2cc8 <kprobe_unwind_ruby+0x2cc8>
    2b24:      	ldr	x8, [sp, #0x78]
    2b28:      	ldr	x9, [sp]
    2b2c:      	cmp	x9, x8
    2b30:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    2b34:      	ldrb	w9, [x23, #0x1e]
    2b38:      	str	xzr, [sp, #0x60]
    2b3c:      	mov	w20, #0x8               // =8
    2b40:      	mov	w10, #0x70              // =112
    2b44:      	add	x0, sp, #0x70
    2b48:      	mov	w1, #0x8                // =8
    2b4c:      	mov	w24, #0x70              // =112
    2b50:      	add	x8, x8, x9
    2b54:      	ldrb	w9, [x23, #0x1c]
    2b58:      	stp	xzr, x8, [sp, #0x70]
    2b5c:      	add	x8, x8, x9
    2b60:      	add	x9, sp, #0x70
    2b64:      	ldr	x8, [sp, #0x78]
    2b68:      	ldrb	w9, [x23, #0x1c]
    2b6c:      	add	x2, x8, x9
    2b70:      	blr	x10
    2b74:      	ldr	x8, [sp, #0x78]
    2b78:      	ldrb	w9, [x23, #0x1b]
    2b7c:      	add	x0, sp, #0x60
    2b80:      	mov	w1, #0x8                // =8
    2b84:      	add	x8, x8, x9
    2b88:      	add	x9, sp, #0x60
    2b8c:      	ldr	x8, [sp, #0x78]
    2b90:      	ldrb	w9, [x23, #0x1b]
    2b94:      	add	x2, x8, x9
    2b98:      	blr	x24
    2b9c:      	ldr	x8, [sp, #0x60]
    2ba0:      	cbz	x8, 0x2e00 <kprobe_unwind_ruby+0x2e00>
    2ba4:      	ldr	x8, [sp, #0x70]
    2ba8:      	cbz	x8, 0x2e00 <kprobe_unwind_ruby+0x2e00>
    2bac:      	ldrb	w9, [x23, #0x1f]
    2bb0:      	mov	w10, #0x70              // =112
    2bb4:      	add	x11, sp, #0x68
    2bb8:      	add	x0, sp, #0x68
    2bbc:      	mov	w1, #0x8                // =8
    2bc0:      	add	x8, x8, x9
    2bc4:      	mov	w9, #0x8                // =8
    2bc8:      	ldr	x8, [sp, #0x70]
    2bcc:      	ldrb	w9, [x23, #0x1f]
    2bd0:      	add	x2, x8, x9
    2bd4:      	blr	x10
    2bd8:      	adrp	x25, 0x2000 <kprobe_unwind_ruby+0x2000>
    2bdc:      	mov	x20, x29
    2be0:      	ldr	x25, [x25]
    2be4:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    2be8:      	ldr	x8, [sp, #0x68]
    2bec:      	ldrb	w9, [x23, #0x21]
    2bf0:      	mov	w10, #0x70              // =112
    2bf4:      	add	x11, sp, #0x58
    2bf8:      	add	x0, sp, #0x58
    2bfc:      	mov	w1, #0x8                // =8
    2c00:      	add	x8, x8, x9
    2c04:      	mov	w9, #0x8                // =8
    2c08:      	ldr	x8, [sp, #0x68]
    2c0c:      	ldrb	w9, [x23, #0x21]
    2c10:      	add	x2, x8, x9
    2c14:      	blr	x10
    2c18:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    2c1c:      	ldr	x8, [sp, #0x68]
    2c20:      	ldrb	w9, [x23, #0x22]
    2c24:      	mov	w10, #0x70              // =112
    2c28:      	add	x11, sp, #0x88
    2c2c:      	add	x0, sp, #0x88
    2c30:      	mov	w1, #0x4                // =4
    2c34:      	add	x8, x8, x9
    2c38:      	mov	w9, #0x4                // =4
    2c3c:      	ldr	x8, [sp, #0x68]
    2c40:      	ldrb	w9, [x23, #0x22]
    2c44:      	add	x2, x8, x9
    2c48:      	blr	x10
    2c4c:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    2c50:      	ldrb	w9, [x23, #0x23]
    2c54:      	ldr	x8, [sp, #0x60]
    2c58:      	cbz	x9, 0x3354 <kprobe_unwind_ruby+0x3354>
    2c5c:      	ldr	x10, [sp, #0x58]
    2c60:      	sub	x10, x8, x10
    2c64:      	udiv	x9, x10, x9
    2c68:      	ldr	w10, [sp, #0x88]
    2c6c:      	cmp	x9, x10
    2c70:      	b.ls	0x3354 <kprobe_unwind_ruby+0x3354>
    2c74:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    2c78:      	ldr	x8, [x8]
    2c7c:      	ldr	w8, [x8]
    2c80:      	cbz	w8, 0x2e10 <kprobe_unwind_ruby+0x2e10>
    2c84:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    2c88:      	add	x8, x8, #0x0
    2c8c:      	add	x0, sp, #0x8
    2c90:      	ldp	x9, x10, [x8, #0x10]
    2c94:      	mov	w1, #0x2d               // =45
    2c98:      	stp	x9, x10, [sp, #0x18]
    2c9c:      	ldr	x9, [x8, #0x20]
    2ca0:      	add	x10, sp, #0x8
    2ca4:      	str	x9, [sp, #0x28]
    2ca8:      	ldur	x9, [x8, #0x25]
    2cac:      	stur	x9, [sp, #0x2d]
    2cb0:      	ldp	x9, x8, [x8]
    2cb4:      	stp	x9, x8, [sp, #0x8]
    2cb8:      	mov	w8, #0x2d               // =45
    2cbc:      	mov	w9, #0x6                // =6
    2cc0:      	blr	x9
    2cc4:      	b	0x2e10 <kprobe_unwind_ruby+0x2e10>
    2cc8:      	ldr	x8, [sp, #0x78]
    2ccc:      	ldrb	w9, [x23, #0x1d]
    2cd0:      	mov	w10, #0x70              // =112
    2cd4:      	add	x11, sp, #0x50
    2cd8:      	add	x0, sp, #0x50
    2cdc:      	mov	w1, #0x8                // =8
    2ce0:      	str	xzr, [sp, #0x50]
    2ce4:      	add	x8, x8, x9
    2ce8:      	mov	w9, #0x8                // =8
    2cec:      	ldr	x8, [sp, #0x78]
    2cf0:      	ldrb	w9, [x23, #0x1d]
    2cf4:      	add	x2, x8, x9
    2cf8:      	blr	x10
    2cfc:      	adrp	x25, 0x2000 <kprobe_unwind_ruby+0x2000>
    2d00:      	mov	x20, x29
    2d04:      	ldr	x25, [x25]
    2d08:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    2d0c:      	ldr	w8, [sp, #0x50]
    2d10:      	mov	w9, #0x140              // =320
    2d14:      	mvn	w8, w8
    2d18:      	tst	x8, x9
    2d1c:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    2d20:      	b	0x2b24 <kprobe_unwind_ruby+0x2b24>
    2d24:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    2d28:      	ldr	x8, [x8]
    2d2c:      	ldr	w8, [x8]
    2d30:      	cbz	w8, 0x2504 <kprobe_unwind_ruby+0x2504>
    2d34:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    2d38:      	add	x8, x8, #0x0
    2d3c:      	add	x0, sp, #0x8
    2d40:      	ldp	x9, x10, [x8, #0x10]
    2d44:      	mov	w1, #0x2e               // =46
    2d48:      	stp	x9, x10, [sp, #0x18]
    2d4c:      	ldr	x9, [x8, #0x20]
    2d50:      	add	x10, sp, #0x8
    2d54:      	str	x9, [sp, #0x28]
    2d58:      	ldur	x9, [x8, #0x26]
    2d5c:      	stur	x9, [sp, #0x2e]
    2d60:      	ldp	x9, x8, [x8]
    2d64:      	stp	x9, x8, [sp, #0x8]
    2d68:      	mov	w8, #0x2e               // =46
    2d6c:      	mov	w9, #0x6                // =6
    2d70:      	ldr	w2, [sp, #0x50]
    2d74:      	blr	x9
    2d78:      	b	0x2504 <kprobe_unwind_ruby+0x2504>
    2d7c:      	ldr	w9, [x22, #0x2c0]
    2d80:      	adrp	x25, 0x2000 <kprobe_unwind_ruby+0x2000>
    2d84:      	ldr	x25, [x25]
    2d88:      	cmp	w9, #0x7e
    2d8c:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    2d90:      	ldr	x10, [sp, #0x68]
    2d94:      	add	w11, w9, #0x1
    2d98:      	str	wzr, [sp, #0x50]
    2d9c:      	mov	x0, x29
    2da0:      	add	x1, sp, #0x50
    2da4:      	strh	wzr, [sp, #0x54]
    2da8:      	str	w11, [x22, #0x2c0]
    2dac:      	mov	w11, #0x18              // =24
    2db0:      	umaddl	x9, w9, w11, x22
    2db4:      	str	x10, [x9, #0x2d0]
    2db8:      	mov	w10, #0x6               // =6
    2dbc:      	str	x8, [x9, #0x2d8]
    2dc0:      	add	x8, x9, #0x2d0
    2dc4:      	strh	w10, [x9, #0x2e0]
    2dc8:      	ldr	w11, [sp, #0x50]
    2dcc:      	ldrh	w10, [sp, #0x54]
    2dd0:      	stur	w11, [x8, #0x12]
    2dd4:      	mov	w8, #0x36               // =54
    2dd8:      	strh	w10, [x9, #0x2e6]
    2ddc:      	add	x9, sp, #0x50
    2de0:      	str	w8, [sp, #0x50]
    2de4:      	mov	w8, #0x1                // =1
    2de8:      	blr	x8
    2dec:      	cbz	x0, 0x3010 <kprobe_unwind_ruby+0x3010>
    2df0:      	ldr	x8, [x0]
    2df4:      	add	x8, x8, #0x1
    2df8:      	str	x8, [x0]
    2dfc:      	b	0x2838 <kprobe_unwind_ruby+0x2838>
    2e00:      	ldr	w8, [x23]
    2e04:      	lsr	w8, w8, #9
    2e08:      	cmp	w8, #0x103
    2e0c:      	b.hs	0x2fb4 <kprobe_unwind_ruby+0x2fb4>
    2e10:      	ldr	x8, [sp, #0x78]
    2e14:      	ldr	x9, [sp]
    2e18:      	cmp	x9, x8
    2e1c:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    2e20:      	ldrb	w9, [x23, #0x1e]
    2e24:      	str	xzr, [sp, #0x60]
    2e28:      	mov	w20, #0x8               // =8
    2e2c:      	mov	w10, #0x70              // =112
    2e30:      	add	x0, sp, #0x70
    2e34:      	mov	w1, #0x8                // =8
    2e38:      	mov	w24, #0x70              // =112
    2e3c:      	add	x8, x8, x9
    2e40:      	ldrb	w9, [x23, #0x1c]
    2e44:      	stp	xzr, x8, [sp, #0x70]
    2e48:      	add	x8, x8, x9
    2e4c:      	add	x9, sp, #0x70
    2e50:      	ldr	x8, [sp, #0x78]
    2e54:      	ldrb	w9, [x23, #0x1c]
    2e58:      	add	x2, x8, x9
    2e5c:      	blr	x10
    2e60:      	ldr	x8, [sp, #0x78]
    2e64:      	ldrb	w9, [x23, #0x1b]
    2e68:      	add	x0, sp, #0x60
    2e6c:      	mov	w1, #0x8                // =8
    2e70:      	add	x8, x8, x9
    2e74:      	add	x9, sp, #0x60
    2e78:      	ldr	x8, [sp, #0x78]
    2e7c:      	ldrb	w9, [x23, #0x1b]
    2e80:      	add	x2, x8, x9
    2e84:      	blr	x24
    2e88:      	ldr	x8, [sp, #0x60]
    2e8c:      	cbz	x8, 0x30ec <kprobe_unwind_ruby+0x30ec>
    2e90:      	ldr	x8, [sp, #0x70]
    2e94:      	cbz	x8, 0x30ec <kprobe_unwind_ruby+0x30ec>
    2e98:      	ldrb	w9, [x23, #0x1f]
    2e9c:      	mov	w10, #0x70              // =112
    2ea0:      	add	x11, sp, #0x68
    2ea4:      	add	x0, sp, #0x68
    2ea8:      	mov	w1, #0x8                // =8
    2eac:      	add	x8, x8, x9
    2eb0:      	mov	w9, #0x8                // =8
    2eb4:      	ldr	x8, [sp, #0x70]
    2eb8:      	ldrb	w9, [x23, #0x1f]
    2ebc:      	add	x2, x8, x9
    2ec0:      	blr	x10
    2ec4:      	adrp	x25, 0x2000 <kprobe_unwind_ruby+0x2000>
    2ec8:      	mov	x20, x29
    2ecc:      	ldr	x25, [x25]
    2ed0:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    2ed4:      	ldr	x8, [sp, #0x68]
    2ed8:      	ldrb	w9, [x23, #0x21]
    2edc:      	mov	w10, #0x70              // =112
    2ee0:      	add	x11, sp, #0x58
    2ee4:      	add	x0, sp, #0x58
    2ee8:      	mov	w1, #0x8                // =8
    2eec:      	add	x8, x8, x9
    2ef0:      	mov	w9, #0x8                // =8
    2ef4:      	ldr	x8, [sp, #0x68]
    2ef8:      	ldrb	w9, [x23, #0x21]
    2efc:      	add	x2, x8, x9
    2f00:      	blr	x10
    2f04:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    2f08:      	ldr	x8, [sp, #0x68]
    2f0c:      	ldrb	w9, [x23, #0x22]
    2f10:      	mov	w10, #0x70              // =112
    2f14:      	add	x11, sp, #0x88
    2f18:      	add	x0, sp, #0x88
    2f1c:      	mov	w1, #0x4                // =4
    2f20:      	add	x8, x8, x9
    2f24:      	mov	w9, #0x4                // =4
    2f28:      	ldr	x8, [sp, #0x68]
    2f2c:      	ldrb	w9, [x23, #0x22]
    2f30:      	add	x2, x8, x9
    2f34:      	blr	x10
    2f38:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    2f3c:      	ldrb	w9, [x23, #0x23]
    2f40:      	ldr	x8, [sp, #0x60]
    2f44:      	cbz	x9, 0x3640 <kprobe_unwind_ruby+0x3640>
    2f48:      	ldr	x10, [sp, #0x58]
    2f4c:      	sub	x10, x8, x10
    2f50:      	udiv	x9, x10, x9
    2f54:      	ldr	w10, [sp, #0x88]
    2f58:      	cmp	x9, x10
    2f5c:      	b.ls	0x3640 <kprobe_unwind_ruby+0x3640>
    2f60:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    2f64:      	ldr	x8, [x8]
    2f68:      	ldr	w8, [x8]
    2f6c:      	cbz	w8, 0x30fc <kprobe_unwind_ruby+0x30fc>
    2f70:      	adrp	x8, 0x2000 <kprobe_unwind_ruby+0x2000>
    2f74:      	add	x8, x8, #0x0
    2f78:      	add	x0, sp, #0x8
    2f7c:      	ldp	x9, x10, [x8, #0x10]
    2f80:      	mov	w1, #0x2d               // =45
    2f84:      	stp	x9, x10, [sp, #0x18]
    2f88:      	ldr	x9, [x8, #0x20]
    2f8c:      	add	x10, sp, #0x8
    2f90:      	str	x9, [sp, #0x28]
    2f94:      	ldur	x9, [x8, #0x25]
    2f98:      	stur	x9, [sp, #0x2d]
    2f9c:      	ldp	x9, x8, [x8]
    2fa0:      	stp	x9, x8, [sp, #0x8]
    2fa4:      	mov	w8, #0x2d               // =45
    2fa8:      	mov	w9, #0x6                // =6
    2fac:      	blr	x9
    2fb0:      	b	0x30fc <kprobe_unwind_ruby+0x30fc>
    2fb4:      	ldr	x8, [sp, #0x78]
    2fb8:      	ldrb	w9, [x23, #0x1d]
    2fbc:      	mov	w10, #0x70              // =112
    2fc0:      	add	x11, sp, #0x50
    2fc4:      	add	x0, sp, #0x50
    2fc8:      	mov	w1, #0x8                // =8
    2fcc:      	str	xzr, [sp, #0x50]
    2fd0:      	add	x8, x8, x9
    2fd4:      	mov	w9, #0x8                // =8
    2fd8:      	ldr	x8, [sp, #0x78]
    2fdc:      	ldrb	w9, [x23, #0x1d]
    2fe0:      	add	x2, x8, x9
    2fe4:      	blr	x10
    2fe8:      	adrp	x25, 0x2000 <kprobe_unwind_ruby+0x2000>
    2fec:      	mov	x20, x29
    2ff0:      	ldr	x25, [x25]
    2ff4:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    2ff8:      	ldr	w8, [sp, #0x50]
    2ffc:      	mov	w9, #0x140              // =320
    3000:      	mvn	w8, w8
    3004:      	tst	x8, x9
    3008:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    300c:      	b	0x2e10 <kprobe_unwind_ruby+0x2e10>
    3010:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    3014:      	ldr	x8, [x8]
    3018:      	ldr	w8, [x8]
    301c:      	cbz	w8, 0x2838 <kprobe_unwind_ruby+0x2838>
    3020:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    3024:      	add	x8, x8, #0x0
    3028:      	add	x0, sp, #0x8
    302c:      	ldp	x9, x10, [x8, #0x10]
    3030:      	mov	w1, #0x2e               // =46
    3034:      	stp	x9, x10, [sp, #0x18]
    3038:      	ldr	x9, [x8, #0x20]
    303c:      	add	x10, sp, #0x8
    3040:      	str	x9, [sp, #0x28]
    3044:      	ldur	x9, [x8, #0x26]
    3048:      	stur	x9, [sp, #0x2e]
    304c:      	ldp	x9, x8, [x8]
    3050:      	stp	x9, x8, [sp, #0x8]
    3054:      	mov	w8, #0x2e               // =46
    3058:      	mov	w9, #0x6                // =6
    305c:      	ldr	w2, [sp, #0x50]
    3060:      	blr	x9
    3064:      	b	0x2838 <kprobe_unwind_ruby+0x2838>
    3068:      	ldr	w9, [x22, #0x2c0]
    306c:      	adrp	x25, 0x3000 <kprobe_unwind_ruby+0x3000>
    3070:      	ldr	x25, [x25]
    3074:      	cmp	w9, #0x7e
    3078:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    307c:      	ldr	x10, [sp, #0x68]
    3080:      	add	w11, w9, #0x1
    3084:      	str	wzr, [sp, #0x50]
    3088:      	mov	x0, x29
    308c:      	add	x1, sp, #0x50
    3090:      	strh	wzr, [sp, #0x54]
    3094:      	str	w11, [x22, #0x2c0]
    3098:      	mov	w11, #0x18              // =24
    309c:      	umaddl	x9, w9, w11, x22
    30a0:      	str	x10, [x9, #0x2d0]
    30a4:      	mov	w10, #0x6               // =6
    30a8:      	str	x8, [x9, #0x2d8]
    30ac:      	add	x8, x9, #0x2d0
    30b0:      	strh	w10, [x9, #0x2e0]
    30b4:      	ldr	w11, [sp, #0x50]
    30b8:      	ldrh	w10, [sp, #0x54]
    30bc:      	stur	w11, [x8, #0x12]
    30c0:      	mov	w8, #0x36               // =54
    30c4:      	strh	w10, [x9, #0x2e6]
    30c8:      	add	x9, sp, #0x50
    30cc:      	str	w8, [sp, #0x50]
    30d0:      	mov	w8, #0x1                // =1
    30d4:      	blr	x8
    30d8:      	cbz	x0, 0x32fc <kprobe_unwind_ruby+0x32fc>
    30dc:      	ldr	x8, [x0]
    30e0:      	add	x8, x8, #0x1
    30e4:      	str	x8, [x0]
    30e8:      	b	0x2b24 <kprobe_unwind_ruby+0x2b24>
    30ec:      	ldr	w8, [x23]
    30f0:      	lsr	w8, w8, #9
    30f4:      	cmp	w8, #0x103
    30f8:      	b.hs	0x32a0 <kprobe_unwind_ruby+0x32a0>
    30fc:      	ldr	x8, [sp, #0x78]
    3100:      	ldr	x9, [sp]
    3104:      	cmp	x9, x8
    3108:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    310c:      	ldrb	w9, [x23, #0x1e]
    3110:      	str	xzr, [sp, #0x60]
    3114:      	mov	w20, #0x8               // =8
    3118:      	mov	w10, #0x70              // =112
    311c:      	add	x0, sp, #0x70
    3120:      	mov	w1, #0x8                // =8
    3124:      	mov	w24, #0x70              // =112
    3128:      	add	x8, x8, x9
    312c:      	ldrb	w9, [x23, #0x1c]
    3130:      	stp	xzr, x8, [sp, #0x70]
    3134:      	add	x8, x8, x9
    3138:      	add	x9, sp, #0x70
    313c:      	ldr	x8, [sp, #0x78]
    3140:      	ldrb	w9, [x23, #0x1c]
    3144:      	add	x2, x8, x9
    3148:      	blr	x10
    314c:      	ldr	x8, [sp, #0x78]
    3150:      	ldrb	w9, [x23, #0x1b]
    3154:      	add	x0, sp, #0x60
    3158:      	mov	w1, #0x8                // =8
    315c:      	add	x8, x8, x9
    3160:      	add	x9, sp, #0x60
    3164:      	ldr	x8, [sp, #0x78]
    3168:      	ldrb	w9, [x23, #0x1b]
    316c:      	add	x2, x8, x9
    3170:      	blr	x24
    3174:      	ldr	x8, [sp, #0x60]
    3178:      	cbz	x8, 0x33d8 <kprobe_unwind_ruby+0x33d8>
    317c:      	ldr	x8, [sp, #0x70]
    3180:      	cbz	x8, 0x33d8 <kprobe_unwind_ruby+0x33d8>
    3184:      	ldrb	w9, [x23, #0x1f]
    3188:      	mov	w10, #0x70              // =112
    318c:      	add	x11, sp, #0x68
    3190:      	add	x0, sp, #0x68
    3194:      	mov	w1, #0x8                // =8
    3198:      	add	x8, x8, x9
    319c:      	mov	w9, #0x8                // =8
    31a0:      	ldr	x8, [sp, #0x70]
    31a4:      	ldrb	w9, [x23, #0x1f]
    31a8:      	add	x2, x8, x9
    31ac:      	blr	x10
    31b0:      	adrp	x25, 0x3000 <kprobe_unwind_ruby+0x3000>
    31b4:      	mov	x20, x29
    31b8:      	ldr	x25, [x25]
    31bc:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    31c0:      	ldr	x8, [sp, #0x68]
    31c4:      	ldrb	w9, [x23, #0x21]
    31c8:      	mov	w10, #0x70              // =112
    31cc:      	add	x11, sp, #0x58
    31d0:      	add	x0, sp, #0x58
    31d4:      	mov	w1, #0x8                // =8
    31d8:      	add	x8, x8, x9
    31dc:      	mov	w9, #0x8                // =8
    31e0:      	ldr	x8, [sp, #0x68]
    31e4:      	ldrb	w9, [x23, #0x21]
    31e8:      	add	x2, x8, x9
    31ec:      	blr	x10
    31f0:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    31f4:      	ldr	x8, [sp, #0x68]
    31f8:      	ldrb	w9, [x23, #0x22]
    31fc:      	mov	w10, #0x70              // =112
    3200:      	add	x11, sp, #0x88
    3204:      	add	x0, sp, #0x88
    3208:      	mov	w1, #0x4                // =4
    320c:      	add	x8, x8, x9
    3210:      	mov	w9, #0x4                // =4
    3214:      	ldr	x8, [sp, #0x68]
    3218:      	ldrb	w9, [x23, #0x22]
    321c:      	add	x2, x8, x9
    3220:      	blr	x10
    3224:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    3228:      	ldrb	w9, [x23, #0x23]
    322c:      	ldr	x8, [sp, #0x60]
    3230:      	cbz	x9, 0x392c <kprobe_unwind_ruby+0x392c>
    3234:      	ldr	x10, [sp, #0x58]
    3238:      	sub	x10, x8, x10
    323c:      	udiv	x9, x10, x9
    3240:      	ldr	w10, [sp, #0x88]
    3244:      	cmp	x9, x10
    3248:      	b.ls	0x392c <kprobe_unwind_ruby+0x392c>
    324c:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    3250:      	ldr	x8, [x8]
    3254:      	ldr	w8, [x8]
    3258:      	cbz	w8, 0x33e8 <kprobe_unwind_ruby+0x33e8>
    325c:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    3260:      	add	x8, x8, #0x0
    3264:      	add	x0, sp, #0x8
    3268:      	ldp	x9, x10, [x8, #0x10]
    326c:      	mov	w1, #0x2d               // =45
    3270:      	stp	x9, x10, [sp, #0x18]
    3274:      	ldr	x9, [x8, #0x20]
    3278:      	add	x10, sp, #0x8
    327c:      	str	x9, [sp, #0x28]
    3280:      	ldur	x9, [x8, #0x25]
    3284:      	stur	x9, [sp, #0x2d]
    3288:      	ldp	x9, x8, [x8]
    328c:      	stp	x9, x8, [sp, #0x8]
    3290:      	mov	w8, #0x2d               // =45
    3294:      	mov	w9, #0x6                // =6
    3298:      	blr	x9
    329c:      	b	0x33e8 <kprobe_unwind_ruby+0x33e8>
    32a0:      	ldr	x8, [sp, #0x78]
    32a4:      	ldrb	w9, [x23, #0x1d]
    32a8:      	mov	w10, #0x70              // =112
    32ac:      	add	x11, sp, #0x50
    32b0:      	add	x0, sp, #0x50
    32b4:      	mov	w1, #0x8                // =8
    32b8:      	str	xzr, [sp, #0x50]
    32bc:      	add	x8, x8, x9
    32c0:      	mov	w9, #0x8                // =8
    32c4:      	ldr	x8, [sp, #0x78]
    32c8:      	ldrb	w9, [x23, #0x1d]
    32cc:      	add	x2, x8, x9
    32d0:      	blr	x10
    32d4:      	adrp	x25, 0x3000 <kprobe_unwind_ruby+0x3000>
    32d8:      	mov	x20, x29
    32dc:      	ldr	x25, [x25]
    32e0:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    32e4:      	ldr	w8, [sp, #0x50]
    32e8:      	mov	w9, #0x140              // =320
    32ec:      	mvn	w8, w8
    32f0:      	tst	x8, x9
    32f4:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    32f8:      	b	0x30fc <kprobe_unwind_ruby+0x30fc>
    32fc:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    3300:      	ldr	x8, [x8]
    3304:      	ldr	w8, [x8]
    3308:      	cbz	w8, 0x2b24 <kprobe_unwind_ruby+0x2b24>
    330c:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    3310:      	add	x8, x8, #0x0
    3314:      	add	x0, sp, #0x8
    3318:      	ldp	x9, x10, [x8, #0x10]
    331c:      	mov	w1, #0x2e               // =46
    3320:      	stp	x9, x10, [sp, #0x18]
    3324:      	ldr	x9, [x8, #0x20]
    3328:      	add	x10, sp, #0x8
    332c:      	str	x9, [sp, #0x28]
    3330:      	ldur	x9, [x8, #0x26]
    3334:      	stur	x9, [sp, #0x2e]
    3338:      	ldp	x9, x8, [x8]
    333c:      	stp	x9, x8, [sp, #0x8]
    3340:      	mov	w8, #0x2e               // =46
    3344:      	mov	w9, #0x6                // =6
    3348:      	ldr	w2, [sp, #0x50]
    334c:      	blr	x9
    3350:      	b	0x2b24 <kprobe_unwind_ruby+0x2b24>
    3354:      	ldr	w9, [x22, #0x2c0]
    3358:      	adrp	x25, 0x3000 <kprobe_unwind_ruby+0x3000>
    335c:      	ldr	x25, [x25]
    3360:      	cmp	w9, #0x7e
    3364:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    3368:      	ldr	x10, [sp, #0x68]
    336c:      	add	w11, w9, #0x1
    3370:      	str	wzr, [sp, #0x50]
    3374:      	mov	x0, x29
    3378:      	add	x1, sp, #0x50
    337c:      	strh	wzr, [sp, #0x54]
    3380:      	str	w11, [x22, #0x2c0]
    3384:      	mov	w11, #0x18              // =24
    3388:      	umaddl	x9, w9, w11, x22
    338c:      	str	x10, [x9, #0x2d0]
    3390:      	mov	w10, #0x6               // =6
    3394:      	str	x8, [x9, #0x2d8]
    3398:      	add	x8, x9, #0x2d0
    339c:      	strh	w10, [x9, #0x2e0]
    33a0:      	ldr	w11, [sp, #0x50]
    33a4:      	ldrh	w10, [sp, #0x54]
    33a8:      	stur	w11, [x8, #0x12]
    33ac:      	mov	w8, #0x36               // =54
    33b0:      	strh	w10, [x9, #0x2e6]
    33b4:      	add	x9, sp, #0x50
    33b8:      	str	w8, [sp, #0x50]
    33bc:      	mov	w8, #0x1                // =1
    33c0:      	blr	x8
    33c4:      	cbz	x0, 0x35e8 <kprobe_unwind_ruby+0x35e8>
    33c8:      	ldr	x8, [x0]
    33cc:      	add	x8, x8, #0x1
    33d0:      	str	x8, [x0]
    33d4:      	b	0x2e10 <kprobe_unwind_ruby+0x2e10>
    33d8:      	ldr	w8, [x23]
    33dc:      	lsr	w8, w8, #9
    33e0:      	cmp	w8, #0x103
    33e4:      	b.hs	0x358c <kprobe_unwind_ruby+0x358c>
    33e8:      	ldr	x8, [sp, #0x78]
    33ec:      	ldr	x9, [sp]
    33f0:      	cmp	x9, x8
    33f4:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    33f8:      	ldrb	w9, [x23, #0x1e]
    33fc:      	str	xzr, [sp, #0x60]
    3400:      	mov	w20, #0x8               // =8
    3404:      	mov	w10, #0x70              // =112
    3408:      	add	x0, sp, #0x70
    340c:      	mov	w1, #0x8                // =8
    3410:      	mov	w24, #0x70              // =112
    3414:      	add	x8, x8, x9
    3418:      	ldrb	w9, [x23, #0x1c]
    341c:      	stp	xzr, x8, [sp, #0x70]
    3420:      	add	x8, x8, x9
    3424:      	add	x9, sp, #0x70
    3428:      	ldr	x8, [sp, #0x78]
    342c:      	ldrb	w9, [x23, #0x1c]
    3430:      	add	x2, x8, x9
    3434:      	blr	x10
    3438:      	ldr	x8, [sp, #0x78]
    343c:      	ldrb	w9, [x23, #0x1b]
    3440:      	add	x0, sp, #0x60
    3444:      	mov	w1, #0x8                // =8
    3448:      	add	x8, x8, x9
    344c:      	add	x9, sp, #0x60
    3450:      	ldr	x8, [sp, #0x78]
    3454:      	ldrb	w9, [x23, #0x1b]
    3458:      	add	x2, x8, x9
    345c:      	blr	x24
    3460:      	ldr	x8, [sp, #0x60]
    3464:      	cbz	x8, 0x36c4 <kprobe_unwind_ruby+0x36c4>
    3468:      	ldr	x8, [sp, #0x70]
    346c:      	cbz	x8, 0x36c4 <kprobe_unwind_ruby+0x36c4>
    3470:      	ldrb	w9, [x23, #0x1f]
    3474:      	mov	w10, #0x70              // =112
    3478:      	add	x11, sp, #0x68
    347c:      	add	x0, sp, #0x68
    3480:      	mov	w1, #0x8                // =8
    3484:      	add	x8, x8, x9
    3488:      	mov	w9, #0x8                // =8
    348c:      	ldr	x8, [sp, #0x70]
    3490:      	ldrb	w9, [x23, #0x1f]
    3494:      	add	x2, x8, x9
    3498:      	blr	x10
    349c:      	adrp	x25, 0x3000 <kprobe_unwind_ruby+0x3000>
    34a0:      	mov	x20, x29
    34a4:      	ldr	x25, [x25]
    34a8:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    34ac:      	ldr	x8, [sp, #0x68]
    34b0:      	ldrb	w9, [x23, #0x21]
    34b4:      	mov	w10, #0x70              // =112
    34b8:      	add	x11, sp, #0x58
    34bc:      	add	x0, sp, #0x58
    34c0:      	mov	w1, #0x8                // =8
    34c4:      	add	x8, x8, x9
    34c8:      	mov	w9, #0x8                // =8
    34cc:      	ldr	x8, [sp, #0x68]
    34d0:      	ldrb	w9, [x23, #0x21]
    34d4:      	add	x2, x8, x9
    34d8:      	blr	x10
    34dc:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    34e0:      	ldr	x8, [sp, #0x68]
    34e4:      	ldrb	w9, [x23, #0x22]
    34e8:      	mov	w10, #0x70              // =112
    34ec:      	add	x11, sp, #0x88
    34f0:      	add	x0, sp, #0x88
    34f4:      	mov	w1, #0x4                // =4
    34f8:      	add	x8, x8, x9
    34fc:      	mov	w9, #0x4                // =4
    3500:      	ldr	x8, [sp, #0x68]
    3504:      	ldrb	w9, [x23, #0x22]
    3508:      	add	x2, x8, x9
    350c:      	blr	x10
    3510:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    3514:      	ldrb	w9, [x23, #0x23]
    3518:      	ldr	x8, [sp, #0x60]
    351c:      	cbz	x9, 0x3c18 <kprobe_unwind_ruby+0x3c18>
    3520:      	ldr	x10, [sp, #0x58]
    3524:      	sub	x10, x8, x10
    3528:      	udiv	x9, x10, x9
    352c:      	ldr	w10, [sp, #0x88]
    3530:      	cmp	x9, x10
    3534:      	b.ls	0x3c18 <kprobe_unwind_ruby+0x3c18>
    3538:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    353c:      	ldr	x8, [x8]
    3540:      	ldr	w8, [x8]
    3544:      	cbz	w8, 0x36d4 <kprobe_unwind_ruby+0x36d4>
    3548:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    354c:      	add	x8, x8, #0x0
    3550:      	add	x0, sp, #0x8
    3554:      	ldp	x9, x10, [x8, #0x10]
    3558:      	mov	w1, #0x2d               // =45
    355c:      	stp	x9, x10, [sp, #0x18]
    3560:      	ldr	x9, [x8, #0x20]
    3564:      	add	x10, sp, #0x8
    3568:      	str	x9, [sp, #0x28]
    356c:      	ldur	x9, [x8, #0x25]
    3570:      	stur	x9, [sp, #0x2d]
    3574:      	ldp	x9, x8, [x8]
    3578:      	stp	x9, x8, [sp, #0x8]
    357c:      	mov	w8, #0x2d               // =45
    3580:      	mov	w9, #0x6                // =6
    3584:      	blr	x9
    3588:      	b	0x36d4 <kprobe_unwind_ruby+0x36d4>
    358c:      	ldr	x8, [sp, #0x78]
    3590:      	ldrb	w9, [x23, #0x1d]
    3594:      	mov	w10, #0x70              // =112
    3598:      	add	x11, sp, #0x50
    359c:      	add	x0, sp, #0x50
    35a0:      	mov	w1, #0x8                // =8
    35a4:      	str	xzr, [sp, #0x50]
    35a8:      	add	x8, x8, x9
    35ac:      	mov	w9, #0x8                // =8
    35b0:      	ldr	x8, [sp, #0x78]
    35b4:      	ldrb	w9, [x23, #0x1d]
    35b8:      	add	x2, x8, x9
    35bc:      	blr	x10
    35c0:      	adrp	x25, 0x3000 <kprobe_unwind_ruby+0x3000>
    35c4:      	mov	x20, x29
    35c8:      	ldr	x25, [x25]
    35cc:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    35d0:      	ldr	w8, [sp, #0x50]
    35d4:      	mov	w9, #0x140              // =320
    35d8:      	mvn	w8, w8
    35dc:      	tst	x8, x9
    35e0:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    35e4:      	b	0x33e8 <kprobe_unwind_ruby+0x33e8>
    35e8:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    35ec:      	ldr	x8, [x8]
    35f0:      	ldr	w8, [x8]
    35f4:      	cbz	w8, 0x2e10 <kprobe_unwind_ruby+0x2e10>
    35f8:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    35fc:      	add	x8, x8, #0x0
    3600:      	add	x0, sp, #0x8
    3604:      	ldp	x9, x10, [x8, #0x10]
    3608:      	mov	w1, #0x2e               // =46
    360c:      	stp	x9, x10, [sp, #0x18]
    3610:      	ldr	x9, [x8, #0x20]
    3614:      	add	x10, sp, #0x8
    3618:      	str	x9, [sp, #0x28]
    361c:      	ldur	x9, [x8, #0x26]
    3620:      	stur	x9, [sp, #0x2e]
    3624:      	ldp	x9, x8, [x8]
    3628:      	stp	x9, x8, [sp, #0x8]
    362c:      	mov	w8, #0x2e               // =46
    3630:      	mov	w9, #0x6                // =6
    3634:      	ldr	w2, [sp, #0x50]
    3638:      	blr	x9
    363c:      	b	0x2e10 <kprobe_unwind_ruby+0x2e10>
    3640:      	ldr	w9, [x22, #0x2c0]
    3644:      	adrp	x25, 0x3000 <kprobe_unwind_ruby+0x3000>
    3648:      	ldr	x25, [x25]
    364c:      	cmp	w9, #0x7e
    3650:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    3654:      	ldr	x10, [sp, #0x68]
    3658:      	add	w11, w9, #0x1
    365c:      	str	wzr, [sp, #0x50]
    3660:      	mov	x0, x29
    3664:      	add	x1, sp, #0x50
    3668:      	strh	wzr, [sp, #0x54]
    366c:      	str	w11, [x22, #0x2c0]
    3670:      	mov	w11, #0x18              // =24
    3674:      	umaddl	x9, w9, w11, x22
    3678:      	str	x10, [x9, #0x2d0]
    367c:      	mov	w10, #0x6               // =6
    3680:      	str	x8, [x9, #0x2d8]
    3684:      	add	x8, x9, #0x2d0
    3688:      	strh	w10, [x9, #0x2e0]
    368c:      	ldr	w11, [sp, #0x50]
    3690:      	ldrh	w10, [sp, #0x54]
    3694:      	stur	w11, [x8, #0x12]
    3698:      	mov	w8, #0x36               // =54
    369c:      	strh	w10, [x9, #0x2e6]
    36a0:      	add	x9, sp, #0x50
    36a4:      	str	w8, [sp, #0x50]
    36a8:      	mov	w8, #0x1                // =1
    36ac:      	blr	x8
    36b0:      	cbz	x0, 0x38d4 <kprobe_unwind_ruby+0x38d4>
    36b4:      	ldr	x8, [x0]
    36b8:      	add	x8, x8, #0x1
    36bc:      	str	x8, [x0]
    36c0:      	b	0x30fc <kprobe_unwind_ruby+0x30fc>
    36c4:      	ldr	w8, [x23]
    36c8:      	lsr	w8, w8, #9
    36cc:      	cmp	w8, #0x103
    36d0:      	b.hs	0x3878 <kprobe_unwind_ruby+0x3878>
    36d4:      	ldr	x8, [sp, #0x78]
    36d8:      	ldr	x9, [sp]
    36dc:      	cmp	x9, x8
    36e0:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    36e4:      	ldrb	w9, [x23, #0x1e]
    36e8:      	str	xzr, [sp, #0x60]
    36ec:      	mov	w20, #0x8               // =8
    36f0:      	mov	w10, #0x70              // =112
    36f4:      	add	x0, sp, #0x70
    36f8:      	mov	w1, #0x8                // =8
    36fc:      	mov	w24, #0x70              // =112
    3700:      	add	x8, x8, x9
    3704:      	ldrb	w9, [x23, #0x1c]
    3708:      	stp	xzr, x8, [sp, #0x70]
    370c:      	add	x8, x8, x9
    3710:      	add	x9, sp, #0x70
    3714:      	ldr	x8, [sp, #0x78]
    3718:      	ldrb	w9, [x23, #0x1c]
    371c:      	add	x2, x8, x9
    3720:      	blr	x10
    3724:      	ldr	x8, [sp, #0x78]
    3728:      	ldrb	w9, [x23, #0x1b]
    372c:      	add	x0, sp, #0x60
    3730:      	mov	w1, #0x8                // =8
    3734:      	add	x8, x8, x9
    3738:      	add	x9, sp, #0x60
    373c:      	ldr	x8, [sp, #0x78]
    3740:      	ldrb	w9, [x23, #0x1b]
    3744:      	add	x2, x8, x9
    3748:      	blr	x24
    374c:      	ldr	x8, [sp, #0x60]
    3750:      	cbz	x8, 0x39b0 <kprobe_unwind_ruby+0x39b0>
    3754:      	ldr	x8, [sp, #0x70]
    3758:      	cbz	x8, 0x39b0 <kprobe_unwind_ruby+0x39b0>
    375c:      	ldrb	w9, [x23, #0x1f]
    3760:      	mov	w10, #0x70              // =112
    3764:      	add	x11, sp, #0x68
    3768:      	add	x0, sp, #0x68
    376c:      	mov	w1, #0x8                // =8
    3770:      	add	x8, x8, x9
    3774:      	mov	w9, #0x8                // =8
    3778:      	ldr	x8, [sp, #0x70]
    377c:      	ldrb	w9, [x23, #0x1f]
    3780:      	add	x2, x8, x9
    3784:      	blr	x10
    3788:      	adrp	x25, 0x3000 <kprobe_unwind_ruby+0x3000>
    378c:      	mov	x20, x29
    3790:      	ldr	x25, [x25]
    3794:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    3798:      	ldr	x8, [sp, #0x68]
    379c:      	ldrb	w9, [x23, #0x21]
    37a0:      	mov	w10, #0x70              // =112
    37a4:      	add	x11, sp, #0x58
    37a8:      	add	x0, sp, #0x58
    37ac:      	mov	w1, #0x8                // =8
    37b0:      	add	x8, x8, x9
    37b4:      	mov	w9, #0x8                // =8
    37b8:      	ldr	x8, [sp, #0x68]
    37bc:      	ldrb	w9, [x23, #0x21]
    37c0:      	add	x2, x8, x9
    37c4:      	blr	x10
    37c8:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    37cc:      	ldr	x8, [sp, #0x68]
    37d0:      	ldrb	w9, [x23, #0x22]
    37d4:      	mov	w10, #0x70              // =112
    37d8:      	add	x11, sp, #0x88
    37dc:      	add	x0, sp, #0x88
    37e0:      	mov	w1, #0x4                // =4
    37e4:      	add	x8, x8, x9
    37e8:      	mov	w9, #0x4                // =4
    37ec:      	ldr	x8, [sp, #0x68]
    37f0:      	ldrb	w9, [x23, #0x22]
    37f4:      	add	x2, x8, x9
    37f8:      	blr	x10
    37fc:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    3800:      	ldrb	w9, [x23, #0x23]
    3804:      	ldr	x8, [sp, #0x60]
    3808:      	cbz	x9, 0x3f04 <kprobe_unwind_ruby+0x3f04>
    380c:      	ldr	x10, [sp, #0x58]
    3810:      	sub	x10, x8, x10
    3814:      	udiv	x9, x10, x9
    3818:      	ldr	w10, [sp, #0x88]
    381c:      	cmp	x9, x10
    3820:      	b.ls	0x3f04 <kprobe_unwind_ruby+0x3f04>
    3824:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    3828:      	ldr	x8, [x8]
    382c:      	ldr	w8, [x8]
    3830:      	cbz	w8, 0x39c0 <kprobe_unwind_ruby+0x39c0>
    3834:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    3838:      	add	x8, x8, #0x0
    383c:      	add	x0, sp, #0x8
    3840:      	ldp	x9, x10, [x8, #0x10]
    3844:      	mov	w1, #0x2d               // =45
    3848:      	stp	x9, x10, [sp, #0x18]
    384c:      	ldr	x9, [x8, #0x20]
    3850:      	add	x10, sp, #0x8
    3854:      	str	x9, [sp, #0x28]
    3858:      	ldur	x9, [x8, #0x25]
    385c:      	stur	x9, [sp, #0x2d]
    3860:      	ldp	x9, x8, [x8]
    3864:      	stp	x9, x8, [sp, #0x8]
    3868:      	mov	w8, #0x2d               // =45
    386c:      	mov	w9, #0x6                // =6
    3870:      	blr	x9
    3874:      	b	0x39c0 <kprobe_unwind_ruby+0x39c0>
    3878:      	ldr	x8, [sp, #0x78]
    387c:      	ldrb	w9, [x23, #0x1d]
    3880:      	mov	w10, #0x70              // =112
    3884:      	add	x11, sp, #0x50
    3888:      	add	x0, sp, #0x50
    388c:      	mov	w1, #0x8                // =8
    3890:      	str	xzr, [sp, #0x50]
    3894:      	add	x8, x8, x9
    3898:      	mov	w9, #0x8                // =8
    389c:      	ldr	x8, [sp, #0x78]
    38a0:      	ldrb	w9, [x23, #0x1d]
    38a4:      	add	x2, x8, x9
    38a8:      	blr	x10
    38ac:      	adrp	x25, 0x3000 <kprobe_unwind_ruby+0x3000>
    38b0:      	mov	x20, x29
    38b4:      	ldr	x25, [x25]
    38b8:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    38bc:      	ldr	w8, [sp, #0x50]
    38c0:      	mov	w9, #0x140              // =320
    38c4:      	mvn	w8, w8
    38c8:      	tst	x8, x9
    38cc:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    38d0:      	b	0x36d4 <kprobe_unwind_ruby+0x36d4>
    38d4:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    38d8:      	ldr	x8, [x8]
    38dc:      	ldr	w8, [x8]
    38e0:      	cbz	w8, 0x30fc <kprobe_unwind_ruby+0x30fc>
    38e4:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    38e8:      	add	x8, x8, #0x0
    38ec:      	add	x0, sp, #0x8
    38f0:      	ldp	x9, x10, [x8, #0x10]
    38f4:      	mov	w1, #0x2e               // =46
    38f8:      	stp	x9, x10, [sp, #0x18]
    38fc:      	ldr	x9, [x8, #0x20]
    3900:      	add	x10, sp, #0x8
    3904:      	str	x9, [sp, #0x28]
    3908:      	ldur	x9, [x8, #0x26]
    390c:      	stur	x9, [sp, #0x2e]
    3910:      	ldp	x9, x8, [x8]
    3914:      	stp	x9, x8, [sp, #0x8]
    3918:      	mov	w8, #0x2e               // =46
    391c:      	mov	w9, #0x6                // =6
    3920:      	ldr	w2, [sp, #0x50]
    3924:      	blr	x9
    3928:      	b	0x30fc <kprobe_unwind_ruby+0x30fc>
    392c:      	ldr	w9, [x22, #0x2c0]
    3930:      	adrp	x25, 0x3000 <kprobe_unwind_ruby+0x3000>
    3934:      	ldr	x25, [x25]
    3938:      	cmp	w9, #0x7e
    393c:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    3940:      	ldr	x10, [sp, #0x68]
    3944:      	add	w11, w9, #0x1
    3948:      	str	wzr, [sp, #0x50]
    394c:      	mov	x0, x29
    3950:      	add	x1, sp, #0x50
    3954:      	strh	wzr, [sp, #0x54]
    3958:      	str	w11, [x22, #0x2c0]
    395c:      	mov	w11, #0x18              // =24
    3960:      	umaddl	x9, w9, w11, x22
    3964:      	str	x10, [x9, #0x2d0]
    3968:      	mov	w10, #0x6               // =6
    396c:      	str	x8, [x9, #0x2d8]
    3970:      	add	x8, x9, #0x2d0
    3974:      	strh	w10, [x9, #0x2e0]
    3978:      	ldr	w11, [sp, #0x50]
    397c:      	ldrh	w10, [sp, #0x54]
    3980:      	stur	w11, [x8, #0x12]
    3984:      	mov	w8, #0x36               // =54
    3988:      	strh	w10, [x9, #0x2e6]
    398c:      	add	x9, sp, #0x50
    3990:      	str	w8, [sp, #0x50]
    3994:      	mov	w8, #0x1                // =1
    3998:      	blr	x8
    399c:      	cbz	x0, 0x3bc0 <kprobe_unwind_ruby+0x3bc0>
    39a0:      	ldr	x8, [x0]
    39a4:      	add	x8, x8, #0x1
    39a8:      	str	x8, [x0]
    39ac:      	b	0x33e8 <kprobe_unwind_ruby+0x33e8>
    39b0:      	ldr	w8, [x23]
    39b4:      	lsr	w8, w8, #9
    39b8:      	cmp	w8, #0x103
    39bc:      	b.hs	0x3b64 <kprobe_unwind_ruby+0x3b64>
    39c0:      	ldr	x8, [sp, #0x78]
    39c4:      	ldr	x9, [sp]
    39c8:      	cmp	x9, x8
    39cc:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    39d0:      	ldrb	w9, [x23, #0x1e]
    39d4:      	str	xzr, [sp, #0x60]
    39d8:      	mov	w20, #0x8               // =8
    39dc:      	mov	w10, #0x70              // =112
    39e0:      	add	x0, sp, #0x70
    39e4:      	mov	w1, #0x8                // =8
    39e8:      	mov	w24, #0x70              // =112
    39ec:      	add	x8, x8, x9
    39f0:      	ldrb	w9, [x23, #0x1c]
    39f4:      	stp	xzr, x8, [sp, #0x70]
    39f8:      	add	x8, x8, x9
    39fc:      	add	x9, sp, #0x70
    3a00:      	ldr	x8, [sp, #0x78]
    3a04:      	ldrb	w9, [x23, #0x1c]
    3a08:      	add	x2, x8, x9
    3a0c:      	blr	x10
    3a10:      	ldr	x8, [sp, #0x78]
    3a14:      	ldrb	w9, [x23, #0x1b]
    3a18:      	add	x0, sp, #0x60
    3a1c:      	mov	w1, #0x8                // =8
    3a20:      	add	x8, x8, x9
    3a24:      	add	x9, sp, #0x60
    3a28:      	ldr	x8, [sp, #0x78]
    3a2c:      	ldrb	w9, [x23, #0x1b]
    3a30:      	add	x2, x8, x9
    3a34:      	blr	x24
    3a38:      	ldr	x8, [sp, #0x60]
    3a3c:      	cbz	x8, 0x3c9c <kprobe_unwind_ruby+0x3c9c>
    3a40:      	ldr	x8, [sp, #0x70]
    3a44:      	cbz	x8, 0x3c9c <kprobe_unwind_ruby+0x3c9c>
    3a48:      	ldrb	w9, [x23, #0x1f]
    3a4c:      	mov	w10, #0x70              // =112
    3a50:      	add	x11, sp, #0x68
    3a54:      	add	x0, sp, #0x68
    3a58:      	mov	w1, #0x8                // =8
    3a5c:      	add	x8, x8, x9
    3a60:      	mov	w9, #0x8                // =8
    3a64:      	ldr	x8, [sp, #0x70]
    3a68:      	ldrb	w9, [x23, #0x1f]
    3a6c:      	add	x2, x8, x9
    3a70:      	blr	x10
    3a74:      	adrp	x25, 0x3000 <kprobe_unwind_ruby+0x3000>
    3a78:      	mov	x20, x29
    3a7c:      	ldr	x25, [x25]
    3a80:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    3a84:      	ldr	x8, [sp, #0x68]
    3a88:      	ldrb	w9, [x23, #0x21]
    3a8c:      	mov	w10, #0x70              // =112
    3a90:      	add	x11, sp, #0x58
    3a94:      	add	x0, sp, #0x58
    3a98:      	mov	w1, #0x8                // =8
    3a9c:      	add	x8, x8, x9
    3aa0:      	mov	w9, #0x8                // =8
    3aa4:      	ldr	x8, [sp, #0x68]
    3aa8:      	ldrb	w9, [x23, #0x21]
    3aac:      	add	x2, x8, x9
    3ab0:      	blr	x10
    3ab4:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    3ab8:      	ldr	x8, [sp, #0x68]
    3abc:      	ldrb	w9, [x23, #0x22]
    3ac0:      	mov	w10, #0x70              // =112
    3ac4:      	add	x11, sp, #0x88
    3ac8:      	add	x0, sp, #0x88
    3acc:      	mov	w1, #0x4                // =4
    3ad0:      	add	x8, x8, x9
    3ad4:      	mov	w9, #0x4                // =4
    3ad8:      	ldr	x8, [sp, #0x68]
    3adc:      	ldrb	w9, [x23, #0x22]
    3ae0:      	add	x2, x8, x9
    3ae4:      	blr	x10
    3ae8:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    3aec:      	ldrb	w9, [x23, #0x23]
    3af0:      	ldr	x8, [sp, #0x60]
    3af4:      	cbz	x9, 0x404c <kprobe_unwind_ruby+0x404c>
    3af8:      	ldr	x10, [sp, #0x58]
    3afc:      	sub	x10, x8, x10
    3b00:      	udiv	x9, x10, x9
    3b04:      	ldr	w10, [sp, #0x88]
    3b08:      	cmp	x9, x10
    3b0c:      	b.ls	0x404c <kprobe_unwind_ruby+0x404c>
    3b10:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    3b14:      	ldr	x8, [x8]
    3b18:      	ldr	w8, [x8]
    3b1c:      	cbz	w8, 0x3cac <kprobe_unwind_ruby+0x3cac>
    3b20:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    3b24:      	add	x8, x8, #0x0
    3b28:      	add	x0, sp, #0x8
    3b2c:      	ldp	x9, x10, [x8, #0x10]
    3b30:      	mov	w1, #0x2d               // =45
    3b34:      	stp	x9, x10, [sp, #0x18]
    3b38:      	ldr	x9, [x8, #0x20]
    3b3c:      	add	x10, sp, #0x8
    3b40:      	str	x9, [sp, #0x28]
    3b44:      	ldur	x9, [x8, #0x25]
    3b48:      	stur	x9, [sp, #0x2d]
    3b4c:      	ldp	x9, x8, [x8]
    3b50:      	stp	x9, x8, [sp, #0x8]
    3b54:      	mov	w8, #0x2d               // =45
    3b58:      	mov	w9, #0x6                // =6
    3b5c:      	blr	x9
    3b60:      	b	0x3cac <kprobe_unwind_ruby+0x3cac>
    3b64:      	ldr	x8, [sp, #0x78]
    3b68:      	ldrb	w9, [x23, #0x1d]
    3b6c:      	mov	w10, #0x70              // =112
    3b70:      	add	x11, sp, #0x50
    3b74:      	add	x0, sp, #0x50
    3b78:      	mov	w1, #0x8                // =8
    3b7c:      	str	xzr, [sp, #0x50]
    3b80:      	add	x8, x8, x9
    3b84:      	mov	w9, #0x8                // =8
    3b88:      	ldr	x8, [sp, #0x78]
    3b8c:      	ldrb	w9, [x23, #0x1d]
    3b90:      	add	x2, x8, x9
    3b94:      	blr	x10
    3b98:      	adrp	x25, 0x3000 <kprobe_unwind_ruby+0x3000>
    3b9c:      	mov	x20, x29
    3ba0:      	ldr	x25, [x25]
    3ba4:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    3ba8:      	ldr	w8, [sp, #0x50]
    3bac:      	mov	w9, #0x140              // =320
    3bb0:      	mvn	w8, w8
    3bb4:      	tst	x8, x9
    3bb8:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    3bbc:      	b	0x39c0 <kprobe_unwind_ruby+0x39c0>
    3bc0:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    3bc4:      	ldr	x8, [x8]
    3bc8:      	ldr	w8, [x8]
    3bcc:      	cbz	w8, 0x33e8 <kprobe_unwind_ruby+0x33e8>
    3bd0:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    3bd4:      	add	x8, x8, #0x0
    3bd8:      	add	x0, sp, #0x8
    3bdc:      	ldp	x9, x10, [x8, #0x10]
    3be0:      	mov	w1, #0x2e               // =46
    3be4:      	stp	x9, x10, [sp, #0x18]
    3be8:      	ldr	x9, [x8, #0x20]
    3bec:      	add	x10, sp, #0x8
    3bf0:      	str	x9, [sp, #0x28]
    3bf4:      	ldur	x9, [x8, #0x26]
    3bf8:      	stur	x9, [sp, #0x2e]
    3bfc:      	ldp	x9, x8, [x8]
    3c00:      	stp	x9, x8, [sp, #0x8]
    3c04:      	mov	w8, #0x2e               // =46
    3c08:      	mov	w9, #0x6                // =6
    3c0c:      	ldr	w2, [sp, #0x50]
    3c10:      	blr	x9
    3c14:      	b	0x33e8 <kprobe_unwind_ruby+0x33e8>
    3c18:      	ldr	w9, [x22, #0x2c0]
    3c1c:      	adrp	x25, 0x3000 <kprobe_unwind_ruby+0x3000>
    3c20:      	ldr	x25, [x25]
    3c24:      	cmp	w9, #0x7e
    3c28:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    3c2c:      	ldr	x10, [sp, #0x68]
    3c30:      	add	w11, w9, #0x1
    3c34:      	str	wzr, [sp, #0x50]
    3c38:      	mov	x0, x29
    3c3c:      	add	x1, sp, #0x50
    3c40:      	strh	wzr, [sp, #0x54]
    3c44:      	str	w11, [x22, #0x2c0]
    3c48:      	mov	w11, #0x18              // =24
    3c4c:      	umaddl	x9, w9, w11, x22
    3c50:      	str	x10, [x9, #0x2d0]
    3c54:      	mov	w10, #0x6               // =6
    3c58:      	str	x8, [x9, #0x2d8]
    3c5c:      	add	x8, x9, #0x2d0
    3c60:      	strh	w10, [x9, #0x2e0]
    3c64:      	ldr	w11, [sp, #0x50]
    3c68:      	ldrh	w10, [sp, #0x54]
    3c6c:      	stur	w11, [x8, #0x12]
    3c70:      	mov	w8, #0x36               // =54
    3c74:      	strh	w10, [x9, #0x2e6]
    3c78:      	add	x9, sp, #0x50
    3c7c:      	str	w8, [sp, #0x50]
    3c80:      	mov	w8, #0x1                // =1
    3c84:      	blr	x8
    3c88:      	cbz	x0, 0x3eac <kprobe_unwind_ruby+0x3eac>
    3c8c:      	ldr	x8, [x0]
    3c90:      	add	x8, x8, #0x1
    3c94:      	str	x8, [x0]
    3c98:      	b	0x36d4 <kprobe_unwind_ruby+0x36d4>
    3c9c:      	ldr	w8, [x23]
    3ca0:      	lsr	w8, w8, #9
    3ca4:      	cmp	w8, #0x103
    3ca8:      	b.hs	0x3e50 <kprobe_unwind_ruby+0x3e50>
    3cac:      	ldr	x8, [sp, #0x78]
    3cb0:      	ldr	x9, [sp]
    3cb4:      	cmp	x9, x8
    3cb8:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    3cbc:      	ldrb	w9, [x23, #0x1e]
    3cc0:      	str	xzr, [sp, #0x60]
    3cc4:      	mov	w20, #0x8               // =8
    3cc8:      	mov	w10, #0x70              // =112
    3ccc:      	add	x0, sp, #0x70
    3cd0:      	mov	w1, #0x8                // =8
    3cd4:      	mov	w24, #0x70              // =112
    3cd8:      	add	x8, x8, x9
    3cdc:      	ldrb	w9, [x23, #0x1c]
    3ce0:      	stp	xzr, x8, [sp, #0x70]
    3ce4:      	add	x8, x8, x9
    3ce8:      	add	x9, sp, #0x70
    3cec:      	ldr	x8, [sp, #0x78]
    3cf0:      	ldrb	w9, [x23, #0x1c]
    3cf4:      	add	x2, x8, x9
    3cf8:      	blr	x10
    3cfc:      	ldr	x8, [sp, #0x78]
    3d00:      	ldrb	w9, [x23, #0x1b]
    3d04:      	add	x0, sp, #0x60
    3d08:      	mov	w1, #0x8                // =8
    3d0c:      	add	x8, x8, x9
    3d10:      	add	x9, sp, #0x60
    3d14:      	ldr	x8, [sp, #0x78]
    3d18:      	ldrb	w9, [x23, #0x1b]
    3d1c:      	add	x2, x8, x9
    3d20:      	blr	x24
    3d24:      	ldr	x8, [sp, #0x60]
    3d28:      	cbz	x8, 0x3f88 <kprobe_unwind_ruby+0x3f88>
    3d2c:      	ldr	x8, [sp, #0x70]
    3d30:      	cbz	x8, 0x3f88 <kprobe_unwind_ruby+0x3f88>
    3d34:      	ldrb	w9, [x23, #0x1f]
    3d38:      	mov	w10, #0x70              // =112
    3d3c:      	add	x11, sp, #0x68
    3d40:      	add	x0, sp, #0x68
    3d44:      	mov	w1, #0x8                // =8
    3d48:      	add	x8, x8, x9
    3d4c:      	mov	w9, #0x8                // =8
    3d50:      	ldr	x8, [sp, #0x70]
    3d54:      	ldrb	w9, [x23, #0x1f]
    3d58:      	add	x2, x8, x9
    3d5c:      	blr	x10
    3d60:      	adrp	x25, 0x3000 <kprobe_unwind_ruby+0x3000>
    3d64:      	mov	x20, x29
    3d68:      	ldr	x25, [x25]
    3d6c:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    3d70:      	ldr	x8, [sp, #0x68]
    3d74:      	ldrb	w9, [x23, #0x21]
    3d78:      	mov	w10, #0x70              // =112
    3d7c:      	add	x11, sp, #0x58
    3d80:      	add	x0, sp, #0x58
    3d84:      	mov	w1, #0x8                // =8
    3d88:      	add	x8, x8, x9
    3d8c:      	mov	w9, #0x8                // =8
    3d90:      	ldr	x8, [sp, #0x68]
    3d94:      	ldrb	w9, [x23, #0x21]
    3d98:      	add	x2, x8, x9
    3d9c:      	blr	x10
    3da0:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    3da4:      	ldr	x8, [sp, #0x68]
    3da8:      	ldrb	w9, [x23, #0x22]
    3dac:      	mov	w10, #0x70              // =112
    3db0:      	add	x11, sp, #0x88
    3db4:      	add	x0, sp, #0x88
    3db8:      	mov	w1, #0x4                // =4
    3dbc:      	add	x8, x8, x9
    3dc0:      	mov	w9, #0x4                // =4
    3dc4:      	ldr	x8, [sp, #0x68]
    3dc8:      	ldrb	w9, [x23, #0x22]
    3dcc:      	add	x2, x8, x9
    3dd0:      	blr	x10
    3dd4:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    3dd8:      	ldrb	w9, [x23, #0x23]
    3ddc:      	ldr	x8, [sp, #0x60]
    3de0:      	cbz	x9, 0x40d0 <kprobe_unwind_ruby+0x40d0>
    3de4:      	ldr	x10, [sp, #0x58]
    3de8:      	sub	x10, x8, x10
    3dec:      	udiv	x9, x10, x9
    3df0:      	ldr	w10, [sp, #0x88]
    3df4:      	cmp	x9, x10
    3df8:      	b.ls	0x40d0 <kprobe_unwind_ruby+0x40d0>
    3dfc:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    3e00:      	ldr	x8, [x8]
    3e04:      	ldr	w8, [x8]
    3e08:      	cbz	w8, 0x4200 <kprobe_unwind_ruby+0x4200>
    3e0c:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    3e10:      	add	x8, x8, #0x0
    3e14:      	add	x0, sp, #0x8
    3e18:      	ldp	x9, x10, [x8, #0x10]
    3e1c:      	mov	w1, #0x2d               // =45
    3e20:      	stp	x9, x10, [sp, #0x18]
    3e24:      	ldr	x9, [x8, #0x20]
    3e28:      	add	x10, sp, #0x8
    3e2c:      	str	x9, [sp, #0x28]
    3e30:      	ldur	x9, [x8, #0x25]
    3e34:      	stur	x9, [sp, #0x2d]
    3e38:      	ldp	x9, x8, [x8]
    3e3c:      	stp	x9, x8, [sp, #0x8]
    3e40:      	mov	w8, #0x2d               // =45
    3e44:      	mov	w9, #0x6                // =6
    3e48:      	blr	x9
    3e4c:      	b	0x4200 <kprobe_unwind_ruby+0x4200>
    3e50:      	ldr	x8, [sp, #0x78]
    3e54:      	ldrb	w9, [x23, #0x1d]
    3e58:      	mov	w10, #0x70              // =112
    3e5c:      	add	x11, sp, #0x50
    3e60:      	add	x0, sp, #0x50
    3e64:      	mov	w1, #0x8                // =8
    3e68:      	str	xzr, [sp, #0x50]
    3e6c:      	add	x8, x8, x9
    3e70:      	mov	w9, #0x8                // =8
    3e74:      	ldr	x8, [sp, #0x78]
    3e78:      	ldrb	w9, [x23, #0x1d]
    3e7c:      	add	x2, x8, x9
    3e80:      	blr	x10
    3e84:      	adrp	x25, 0x3000 <kprobe_unwind_ruby+0x3000>
    3e88:      	mov	x20, x29
    3e8c:      	ldr	x25, [x25]
    3e90:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    3e94:      	ldr	w8, [sp, #0x50]
    3e98:      	mov	w9, #0x140              // =320
    3e9c:      	mvn	w8, w8
    3ea0:      	tst	x8, x9
    3ea4:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    3ea8:      	b	0x3cac <kprobe_unwind_ruby+0x3cac>
    3eac:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    3eb0:      	ldr	x8, [x8]
    3eb4:      	ldr	w8, [x8]
    3eb8:      	cbz	w8, 0x36d4 <kprobe_unwind_ruby+0x36d4>
    3ebc:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    3ec0:      	add	x8, x8, #0x0
    3ec4:      	add	x0, sp, #0x8
    3ec8:      	ldp	x9, x10, [x8, #0x10]
    3ecc:      	mov	w1, #0x2e               // =46
    3ed0:      	stp	x9, x10, [sp, #0x18]
    3ed4:      	ldr	x9, [x8, #0x20]
    3ed8:      	add	x10, sp, #0x8
    3edc:      	str	x9, [sp, #0x28]
    3ee0:      	ldur	x9, [x8, #0x26]
    3ee4:      	stur	x9, [sp, #0x2e]
    3ee8:      	ldp	x9, x8, [x8]
    3eec:      	stp	x9, x8, [sp, #0x8]
    3ef0:      	mov	w8, #0x2e               // =46
    3ef4:      	mov	w9, #0x6                // =6
    3ef8:      	ldr	w2, [sp, #0x50]
    3efc:      	blr	x9
    3f00:      	b	0x36d4 <kprobe_unwind_ruby+0x36d4>
    3f04:      	ldr	w9, [x22, #0x2c0]
    3f08:      	adrp	x25, 0x3000 <kprobe_unwind_ruby+0x3000>
    3f0c:      	ldr	x25, [x25]
    3f10:      	cmp	w9, #0x7e
    3f14:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    3f18:      	ldr	x10, [sp, #0x68]
    3f1c:      	add	w11, w9, #0x1
    3f20:      	str	wzr, [sp, #0x50]
    3f24:      	mov	x0, x29
    3f28:      	add	x1, sp, #0x50
    3f2c:      	strh	wzr, [sp, #0x54]
    3f30:      	str	w11, [x22, #0x2c0]
    3f34:      	mov	w11, #0x18              // =24
    3f38:      	umaddl	x9, w9, w11, x22
    3f3c:      	str	x10, [x9, #0x2d0]
    3f40:      	mov	w10, #0x6               // =6
    3f44:      	str	x8, [x9, #0x2d8]
    3f48:      	add	x8, x9, #0x2d0
    3f4c:      	strh	w10, [x9, #0x2e0]
    3f50:      	ldr	w11, [sp, #0x50]
    3f54:      	ldrh	w10, [sp, #0x54]
    3f58:      	stur	w11, [x8, #0x12]
    3f5c:      	mov	w8, #0x36               // =54
    3f60:      	strh	w10, [x9, #0x2e6]
    3f64:      	add	x9, sp, #0x50
    3f68:      	str	w8, [sp, #0x50]
    3f6c:      	mov	w8, #0x1                // =1
    3f70:      	blr	x8
    3f74:      	cbz	x0, 0x3ff4 <kprobe_unwind_ruby+0x3ff4>
    3f78:      	ldr	x8, [x0]
    3f7c:      	add	x8, x8, #0x1
    3f80:      	str	x8, [x0]
    3f84:      	b	0x39c0 <kprobe_unwind_ruby+0x39c0>
    3f88:      	ldr	w8, [x23]
    3f8c:      	lsr	w8, w8, #9
    3f90:      	cmp	w8, #0x103
    3f94:      	b.lo	0x4200 <kprobe_unwind_ruby+0x4200>
    3f98:      	ldr	x8, [sp, #0x78]
    3f9c:      	ldrb	w9, [x23, #0x1d]
    3fa0:      	mov	w10, #0x70              // =112
    3fa4:      	add	x11, sp, #0x50
    3fa8:      	add	x0, sp, #0x50
    3fac:      	mov	w1, #0x8                // =8
    3fb0:      	str	xzr, [sp, #0x50]
    3fb4:      	add	x8, x8, x9
    3fb8:      	mov	w9, #0x8                // =8
    3fbc:      	ldr	x8, [sp, #0x78]
    3fc0:      	ldrb	w9, [x23, #0x1d]
    3fc4:      	add	x2, x8, x9
    3fc8:      	blr	x10
    3fcc:      	adrp	x25, 0x3000 <kprobe_unwind_ruby+0x3000>
    3fd0:      	mov	x20, x29
    3fd4:      	ldr	x25, [x25]
    3fd8:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    3fdc:      	ldr	w8, [sp, #0x50]
    3fe0:      	mov	w9, #0x140              // =320
    3fe4:      	mvn	w8, w8
    3fe8:      	tst	x8, x9
    3fec:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    3ff0:      	b	0x4200 <kprobe_unwind_ruby+0x4200>
    3ff4:      	adrp	x8, 0x3000 <kprobe_unwind_ruby+0x3000>
    3ff8:      	ldr	x8, [x8]
    3ffc:      	ldr	w8, [x8]
    4000:      	cbz	w8, 0x39c0 <kprobe_unwind_ruby+0x39c0>
    4004:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    4008:      	add	x8, x8, #0x0
    400c:      	add	x0, sp, #0x8
    4010:      	ldp	x9, x10, [x8, #0x10]
    4014:      	mov	w1, #0x2e               // =46
    4018:      	stp	x9, x10, [sp, #0x18]
    401c:      	ldr	x9, [x8, #0x20]
    4020:      	add	x10, sp, #0x8
    4024:      	str	x9, [sp, #0x28]
    4028:      	ldur	x9, [x8, #0x26]
    402c:      	stur	x9, [sp, #0x2e]
    4030:      	ldp	x9, x8, [x8]
    4034:      	stp	x9, x8, [sp, #0x8]
    4038:      	mov	w8, #0x2e               // =46
    403c:      	mov	w9, #0x6                // =6
    4040:      	ldr	w2, [sp, #0x50]
    4044:      	blr	x9
    4048:      	b	0x39c0 <kprobe_unwind_ruby+0x39c0>
    404c:      	ldr	w9, [x22, #0x2c0]
    4050:      	adrp	x25, 0x4000 <kprobe_unwind_ruby+0x4000>
    4054:      	ldr	x25, [x25]
    4058:      	cmp	w9, #0x7e
    405c:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    4060:      	ldr	x10, [sp, #0x68]
    4064:      	add	w11, w9, #0x1
    4068:      	str	wzr, [sp, #0x50]
    406c:      	mov	x0, x29
    4070:      	add	x1, sp, #0x50
    4074:      	strh	wzr, [sp, #0x54]
    4078:      	str	w11, [x22, #0x2c0]
    407c:      	mov	w11, #0x18              // =24
    4080:      	umaddl	x9, w9, w11, x22
    4084:      	str	x10, [x9, #0x2d0]
    4088:      	mov	w10, #0x6               // =6
    408c:      	str	x8, [x9, #0x2d8]
    4090:      	add	x8, x9, #0x2d0
    4094:      	strh	w10, [x9, #0x2e0]
    4098:      	ldr	w11, [sp, #0x50]
    409c:      	ldrh	w10, [sp, #0x54]
    40a0:      	stur	w11, [x8, #0x12]
    40a4:      	mov	w8, #0x36               // =54
    40a8:      	strh	w10, [x9, #0x2e6]
    40ac:      	add	x9, sp, #0x50
    40b0:      	str	w8, [sp, #0x50]
    40b4:      	mov	w8, #0x1                // =1
    40b8:      	blr	x8
    40bc:      	cbz	x0, 0x4154 <kprobe_unwind_ruby+0x4154>
    40c0:      	ldr	x8, [x0]
    40c4:      	add	x8, x8, #0x1
    40c8:      	str	x8, [x0]
    40cc:      	b	0x3cac <kprobe_unwind_ruby+0x3cac>
    40d0:      	ldr	w9, [x22, #0x2c0]
    40d4:      	adrp	x25, 0x4000 <kprobe_unwind_ruby+0x4000>
    40d8:      	ldr	x25, [x25]
    40dc:      	cmp	w9, #0x7e
    40e0:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    40e4:      	ldr	x10, [sp, #0x68]
    40e8:      	add	w11, w9, #0x1
    40ec:      	str	wzr, [sp, #0x50]
    40f0:      	mov	x0, x29
    40f4:      	add	x1, sp, #0x50
    40f8:      	strh	wzr, [sp, #0x54]
    40fc:      	str	w11, [x22, #0x2c0]
    4100:      	mov	w11, #0x18              // =24
    4104:      	umaddl	x9, w9, w11, x22
    4108:      	str	x10, [x9, #0x2d0]
    410c:      	mov	w10, #0x6               // =6
    4110:      	str	x8, [x9, #0x2d8]
    4114:      	add	x8, x9, #0x2d0
    4118:      	strh	w10, [x9, #0x2e0]
    411c:      	ldr	w11, [sp, #0x50]
    4120:      	ldrh	w10, [sp, #0x54]
    4124:      	stur	w11, [x8, #0x12]
    4128:      	mov	w8, #0x36               // =54
    412c:      	strh	w10, [x9, #0x2e6]
    4130:      	add	x9, sp, #0x50
    4134:      	str	w8, [sp, #0x50]
    4138:      	mov	w8, #0x1                // =1
    413c:      	blr	x8
    4140:      	cbz	x0, 0x41ac <kprobe_unwind_ruby+0x41ac>
    4144:      	ldr	x8, [x0]
    4148:      	add	x8, x8, #0x1
    414c:      	str	x8, [x0]
    4150:      	b	0x4200 <kprobe_unwind_ruby+0x4200>
    4154:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    4158:      	ldr	x8, [x8]
    415c:      	ldr	w8, [x8]
    4160:      	cbz	w8, 0x3cac <kprobe_unwind_ruby+0x3cac>
    4164:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    4168:      	add	x8, x8, #0x0
    416c:      	add	x0, sp, #0x8
    4170:      	ldp	x9, x10, [x8, #0x10]
    4174:      	mov	w1, #0x2e               // =46
    4178:      	stp	x9, x10, [sp, #0x18]
    417c:      	ldr	x9, [x8, #0x20]
    4180:      	add	x10, sp, #0x8
    4184:      	str	x9, [sp, #0x28]
    4188:      	ldur	x9, [x8, #0x26]
    418c:      	stur	x9, [sp, #0x2e]
    4190:      	ldp	x9, x8, [x8]
    4194:      	stp	x9, x8, [sp, #0x8]
    4198:      	mov	w8, #0x2e               // =46
    419c:      	mov	w9, #0x6                // =6
    41a0:      	ldr	w2, [sp, #0x50]
    41a4:      	blr	x9
    41a8:      	b	0x3cac <kprobe_unwind_ruby+0x3cac>
    41ac:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    41b0:      	ldr	x8, [x8]
    41b4:      	ldr	w8, [x8]
    41b8:      	cbz	w8, 0x4200 <kprobe_unwind_ruby+0x4200>
    41bc:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    41c0:      	add	x8, x8, #0x0
    41c4:      	add	x0, sp, #0x8
    41c8:      	ldp	x9, x10, [x8, #0x10]
    41cc:      	mov	w1, #0x2e               // =46
    41d0:      	stp	x9, x10, [sp, #0x18]
    41d4:      	ldr	x9, [x8, #0x20]
    41d8:      	add	x10, sp, #0x8
    41dc:      	str	x9, [sp, #0x28]
    41e0:      	ldur	x9, [x8, #0x26]
    41e4:      	stur	x9, [sp, #0x2e]
    41e8:      	ldp	x9, x8, [x8]
    41ec:      	stp	x9, x8, [sp, #0x8]
    41f0:      	mov	w8, #0x2e               // =46
    41f4:      	mov	w9, #0x6                // =6
    41f8:      	ldr	w2, [sp, #0x50]
    41fc:      	blr	x9
    4200:      	ldr	x8, [sp, #0x78]
    4204:      	ldr	x9, [sp]
    4208:      	cmp	x9, x8
    420c:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    4210:      	ldrb	w9, [x23, #0x1e]
    4214:      	str	xzr, [sp, #0x60]
    4218:      	mov	w20, #0x8               // =8
    421c:      	mov	w10, #0x70              // =112
    4220:      	mov	w24, #0x600             // =1536
    4224:      	add	x0, sp, #0x70
    4228:      	mov	w1, #0x8                // =8
    422c:      	movk	w24, #0x2, lsl #16
    4230:      	mov	w25, #0x70              // =112
    4234:      	add	x8, x8, x9
    4238:      	ldrb	w9, [x23, #0x1c]
    423c:      	stp	xzr, x8, [sp, #0x70]
    4240:      	add	x8, x8, x9
    4244:      	add	x9, sp, #0x70
    4248:      	ldr	x8, [sp, #0x78]
    424c:      	ldrb	w9, [x23, #0x1c]
    4250:      	add	x2, x8, x9
    4254:      	blr	x10
    4258:      	ldr	x8, [sp, #0x78]
    425c:      	ldrb	w9, [x23, #0x1b]
    4260:      	add	x0, sp, #0x60
    4264:      	mov	w1, #0x8                // =8
    4268:      	add	x8, x8, x9
    426c:      	add	x9, sp, #0x60
    4270:      	ldr	x8, [sp, #0x78]
    4274:      	ldrb	w9, [x23, #0x1b]
    4278:      	add	x2, x8, x9
    427c:      	blr	x25
    4280:      	ldr	x8, [sp, #0x60]
    4284:      	cbz	x8, 0x43ac <kprobe_unwind_ruby+0x43ac>
    4288:      	ldr	x8, [sp, #0x70]
    428c:      	cbz	x8, 0x43ac <kprobe_unwind_ruby+0x43ac>
    4290:      	ldrb	w9, [x23, #0x1f]
    4294:      	mov	w10, #0x70              // =112
    4298:      	add	x11, sp, #0x68
    429c:      	add	x0, sp, #0x68
    42a0:      	mov	w1, #0x8                // =8
    42a4:      	add	x8, x8, x9
    42a8:      	mov	w9, #0x8                // =8
    42ac:      	ldr	x8, [sp, #0x70]
    42b0:      	ldrb	w9, [x23, #0x1f]
    42b4:      	add	x2, x8, x9
    42b8:      	blr	x10
    42bc:      	adrp	x25, 0x4000 <kprobe_unwind_ruby+0x4000>
    42c0:      	mov	x20, x29
    42c4:      	ldr	x25, [x25]
    42c8:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    42cc:      	ldr	x8, [sp, #0x68]
    42d0:      	ldrb	w9, [x23, #0x21]
    42d4:      	mov	w10, #0x70              // =112
    42d8:      	add	x11, sp, #0x58
    42dc:      	add	x0, sp, #0x58
    42e0:      	mov	w1, #0x8                // =8
    42e4:      	add	x8, x8, x9
    42e8:      	mov	w9, #0x8                // =8
    42ec:      	ldr	x8, [sp, #0x68]
    42f0:      	ldrb	w9, [x23, #0x21]
    42f4:      	add	x2, x8, x9
    42f8:      	blr	x10
    42fc:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    4300:      	ldr	x8, [sp, #0x68]
    4304:      	ldrb	w9, [x23, #0x22]
    4308:      	mov	w10, #0x70              // =112
    430c:      	add	x11, sp, #0x88
    4310:      	add	x0, sp, #0x88
    4314:      	mov	w1, #0x4                // =4
    4318:      	add	x8, x8, x9
    431c:      	mov	w9, #0x4                // =4
    4320:      	ldr	x8, [sp, #0x68]
    4324:      	ldrb	w9, [x23, #0x22]
    4328:      	add	x2, x8, x9
    432c:      	blr	x10
    4330:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    4334:      	ldrb	w9, [x23, #0x23]
    4338:      	ldr	x8, [sp, #0x60]
    433c:      	cbz	x9, 0x4414 <kprobe_unwind_ruby+0x4414>
    4340:      	ldr	x10, [sp, #0x58]
    4344:      	sub	x10, x8, x10
    4348:      	udiv	x9, x10, x9
    434c:      	ldr	w10, [sp, #0x88]
    4350:      	cmp	x9, x10
    4354:      	b.ls	0x4414 <kprobe_unwind_ruby+0x4414>
    4358:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    435c:      	ldr	x8, [x8]
    4360:      	ldr	w8, [x8]
    4364:      	cbz	w8, 0x44ec <kprobe_unwind_ruby+0x44ec>
    4368:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    436c:      	add	x8, x8, #0x0
    4370:      	add	x0, sp, #0x8
    4374:      	ldp	x9, x10, [x8, #0x10]
    4378:      	mov	w1, #0x2d               // =45
    437c:      	stp	x9, x10, [sp, #0x18]
    4380:      	ldr	x9, [x8, #0x20]
    4384:      	add	x10, sp, #0x8
    4388:      	str	x9, [sp, #0x28]
    438c:      	ldur	x9, [x8, #0x25]
    4390:      	stur	x9, [sp, #0x2d]
    4394:      	ldp	x9, x8, [x8]
    4398:      	stp	x9, x8, [sp, #0x8]
    439c:      	mov	w8, #0x2d               // =45
    43a0:      	mov	w9, #0x6                // =6
    43a4:      	blr	x9
    43a8:      	b	0x44ec <kprobe_unwind_ruby+0x44ec>
    43ac:      	ldr	w8, [x23]
    43b0:      	cmp	w8, w24
    43b4:      	b.lo	0x44ec <kprobe_unwind_ruby+0x44ec>
    43b8:      	ldr	x8, [sp, #0x78]
    43bc:      	ldrb	w9, [x23, #0x1d]
    43c0:      	mov	w10, #0x70              // =112
    43c4:      	add	x11, sp, #0x50
    43c8:      	add	x0, sp, #0x50
    43cc:      	mov	w1, #0x8                // =8
    43d0:      	str	xzr, [sp, #0x50]
    43d4:      	add	x8, x8, x9
    43d8:      	mov	w9, #0x8                // =8
    43dc:      	ldr	x8, [sp, #0x78]
    43e0:      	ldrb	w9, [x23, #0x1d]
    43e4:      	add	x2, x8, x9
    43e8:      	blr	x10
    43ec:      	adrp	x25, 0x4000 <kprobe_unwind_ruby+0x4000>
    43f0:      	mov	x20, x29
    43f4:      	ldr	x25, [x25]
    43f8:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    43fc:      	ldr	w8, [sp, #0x50]
    4400:      	mov	w9, #0x140              // =320
    4404:      	mvn	w8, w8
    4408:      	tst	x8, x9
    440c:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    4410:      	b	0x44ec <kprobe_unwind_ruby+0x44ec>
    4414:      	ldr	w9, [x22, #0x2c0]
    4418:      	adrp	x25, 0x4000 <kprobe_unwind_ruby+0x4000>
    441c:      	ldr	x25, [x25]
    4420:      	cmp	w9, #0x7e
    4424:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    4428:      	ldr	x10, [sp, #0x68]
    442c:      	add	w11, w9, #0x1
    4430:      	str	wzr, [sp, #0x50]
    4434:      	mov	x0, x29
    4438:      	add	x1, sp, #0x50
    443c:      	strh	wzr, [sp, #0x54]
    4440:      	str	w11, [x22, #0x2c0]
    4444:      	mov	w11, #0x18              // =24
    4448:      	umaddl	x9, w9, w11, x22
    444c:      	str	x10, [x9, #0x2d0]
    4450:      	mov	w10, #0x6               // =6
    4454:      	str	x8, [x9, #0x2d8]
    4458:      	add	x8, x9, #0x2d0
    445c:      	strh	w10, [x9, #0x2e0]
    4460:      	ldr	w11, [sp, #0x50]
    4464:      	ldrh	w10, [sp, #0x54]
    4468:      	stur	w11, [x8, #0x12]
    446c:      	mov	w8, #0x36               // =54
    4470:      	strh	w10, [x9, #0x2e6]
    4474:      	add	x9, sp, #0x50
    4478:      	str	w8, [sp, #0x50]
    447c:      	mov	w8, #0x1                // =1
    4480:      	blr	x8
    4484:      	cbz	x0, 0x4498 <kprobe_unwind_ruby+0x4498>
    4488:      	ldr	x8, [x0]
    448c:      	add	x8, x8, #0x1
    4490:      	str	x8, [x0]
    4494:      	b	0x44ec <kprobe_unwind_ruby+0x44ec>
    4498:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    449c:      	ldr	x8, [x8]
    44a0:      	ldr	w8, [x8]
    44a4:      	cbz	w8, 0x44ec <kprobe_unwind_ruby+0x44ec>
    44a8:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    44ac:      	add	x8, x8, #0x0
    44b0:      	add	x0, sp, #0x8
    44b4:      	ldp	x9, x10, [x8, #0x10]
    44b8:      	mov	w1, #0x2e               // =46
    44bc:      	stp	x9, x10, [sp, #0x18]
    44c0:      	ldr	x9, [x8, #0x20]
    44c4:      	add	x10, sp, #0x8
    44c8:      	str	x9, [sp, #0x28]
    44cc:      	ldur	x9, [x8, #0x26]
    44d0:      	stur	x9, [sp, #0x2e]
    44d4:      	ldp	x9, x8, [x8]
    44d8:      	stp	x9, x8, [sp, #0x8]
    44dc:      	mov	w8, #0x2e               // =46
    44e0:      	mov	w9, #0x6                // =6
    44e4:      	ldr	w2, [sp, #0x50]
    44e8:      	blr	x9
    44ec:      	ldr	x8, [sp, #0x78]
    44f0:      	ldr	x9, [sp]
    44f4:      	cmp	x9, x8
    44f8:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    44fc:      	ldrb	w9, [x23, #0x1e]
    4500:      	str	xzr, [sp, #0x60]
    4504:      	mov	w20, #0x8               // =8
    4508:      	mov	w10, #0x70              // =112
    450c:      	add	x0, sp, #0x70
    4510:      	mov	w1, #0x8                // =8
    4514:      	mov	w25, #0x70              // =112
    4518:      	add	x8, x8, x9
    451c:      	ldrb	w9, [x23, #0x1c]
    4520:      	stp	xzr, x8, [sp, #0x70]
    4524:      	add	x8, x8, x9
    4528:      	add	x9, sp, #0x70
    452c:      	ldr	x8, [sp, #0x78]
    4530:      	ldrb	w9, [x23, #0x1c]
    4534:      	add	x2, x8, x9
    4538:      	blr	x10
    453c:      	ldr	x8, [sp, #0x78]
    4540:      	ldrb	w9, [x23, #0x1b]
    4544:      	add	x0, sp, #0x60
    4548:      	mov	w1, #0x8                // =8
    454c:      	add	x8, x8, x9
    4550:      	add	x9, sp, #0x60
    4554:      	ldr	x8, [sp, #0x78]
    4558:      	ldrb	w9, [x23, #0x1b]
    455c:      	add	x2, x8, x9
    4560:      	blr	x25
    4564:      	ldr	x8, [sp, #0x60]
    4568:      	cbz	x8, 0x4690 <kprobe_unwind_ruby+0x4690>
    456c:      	ldr	x8, [sp, #0x70]
    4570:      	cbz	x8, 0x4690 <kprobe_unwind_ruby+0x4690>
    4574:      	ldrb	w9, [x23, #0x1f]
    4578:      	mov	w10, #0x70              // =112
    457c:      	add	x11, sp, #0x68
    4580:      	add	x0, sp, #0x68
    4584:      	mov	w1, #0x8                // =8
    4588:      	add	x8, x8, x9
    458c:      	mov	w9, #0x8                // =8
    4590:      	ldr	x8, [sp, #0x70]
    4594:      	ldrb	w9, [x23, #0x1f]
    4598:      	add	x2, x8, x9
    459c:      	blr	x10
    45a0:      	adrp	x25, 0x4000 <kprobe_unwind_ruby+0x4000>
    45a4:      	mov	x20, x29
    45a8:      	ldr	x25, [x25]
    45ac:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    45b0:      	ldr	x8, [sp, #0x68]
    45b4:      	ldrb	w9, [x23, #0x21]
    45b8:      	mov	w10, #0x70              // =112
    45bc:      	add	x11, sp, #0x58
    45c0:      	add	x0, sp, #0x58
    45c4:      	mov	w1, #0x8                // =8
    45c8:      	add	x8, x8, x9
    45cc:      	mov	w9, #0x8                // =8
    45d0:      	ldr	x8, [sp, #0x68]
    45d4:      	ldrb	w9, [x23, #0x21]
    45d8:      	add	x2, x8, x9
    45dc:      	blr	x10
    45e0:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    45e4:      	ldr	x8, [sp, #0x68]
    45e8:      	ldrb	w9, [x23, #0x22]
    45ec:      	mov	w10, #0x70              // =112
    45f0:      	add	x11, sp, #0x88
    45f4:      	add	x0, sp, #0x88
    45f8:      	mov	w1, #0x4                // =4
    45fc:      	add	x8, x8, x9
    4600:      	mov	w9, #0x4                // =4
    4604:      	ldr	x8, [sp, #0x68]
    4608:      	ldrb	w9, [x23, #0x22]
    460c:      	add	x2, x8, x9
    4610:      	blr	x10
    4614:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    4618:      	ldrb	w9, [x23, #0x23]
    461c:      	ldr	x8, [sp, #0x60]
    4620:      	cbz	x9, 0x46f8 <kprobe_unwind_ruby+0x46f8>
    4624:      	ldr	x10, [sp, #0x58]
    4628:      	sub	x10, x8, x10
    462c:      	udiv	x9, x10, x9
    4630:      	ldr	w10, [sp, #0x88]
    4634:      	cmp	x9, x10
    4638:      	b.ls	0x46f8 <kprobe_unwind_ruby+0x46f8>
    463c:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    4640:      	ldr	x8, [x8]
    4644:      	ldr	w8, [x8]
    4648:      	cbz	w8, 0x47d0 <kprobe_unwind_ruby+0x47d0>
    464c:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    4650:      	add	x8, x8, #0x0
    4654:      	add	x0, sp, #0x8
    4658:      	ldp	x9, x10, [x8, #0x10]
    465c:      	mov	w1, #0x2d               // =45
    4660:      	stp	x9, x10, [sp, #0x18]
    4664:      	ldr	x9, [x8, #0x20]
    4668:      	add	x10, sp, #0x8
    466c:      	str	x9, [sp, #0x28]
    4670:      	ldur	x9, [x8, #0x25]
    4674:      	stur	x9, [sp, #0x2d]
    4678:      	ldp	x9, x8, [x8]
    467c:      	stp	x9, x8, [sp, #0x8]
    4680:      	mov	w8, #0x2d               // =45
    4684:      	mov	w9, #0x6                // =6
    4688:      	blr	x9
    468c:      	b	0x47d0 <kprobe_unwind_ruby+0x47d0>
    4690:      	ldr	w8, [x23]
    4694:      	cmp	w8, w24
    4698:      	b.lo	0x47d0 <kprobe_unwind_ruby+0x47d0>
    469c:      	ldr	x8, [sp, #0x78]
    46a0:      	ldrb	w9, [x23, #0x1d]
    46a4:      	mov	w10, #0x70              // =112
    46a8:      	add	x11, sp, #0x50
    46ac:      	add	x0, sp, #0x50
    46b0:      	mov	w1, #0x8                // =8
    46b4:      	str	xzr, [sp, #0x50]
    46b8:      	add	x8, x8, x9
    46bc:      	mov	w9, #0x8                // =8
    46c0:      	ldr	x8, [sp, #0x78]
    46c4:      	ldrb	w9, [x23, #0x1d]
    46c8:      	add	x2, x8, x9
    46cc:      	blr	x10
    46d0:      	adrp	x25, 0x4000 <kprobe_unwind_ruby+0x4000>
    46d4:      	mov	x20, x29
    46d8:      	ldr	x25, [x25]
    46dc:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    46e0:      	ldr	w8, [sp, #0x50]
    46e4:      	mov	w9, #0x140              // =320
    46e8:      	mvn	w8, w8
    46ec:      	tst	x8, x9
    46f0:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    46f4:      	b	0x47d0 <kprobe_unwind_ruby+0x47d0>
    46f8:      	ldr	w9, [x22, #0x2c0]
    46fc:      	adrp	x25, 0x4000 <kprobe_unwind_ruby+0x4000>
    4700:      	ldr	x25, [x25]
    4704:      	cmp	w9, #0x7e
    4708:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    470c:      	ldr	x10, [sp, #0x68]
    4710:      	add	w11, w9, #0x1
    4714:      	str	wzr, [sp, #0x50]
    4718:      	mov	x0, x29
    471c:      	add	x1, sp, #0x50
    4720:      	strh	wzr, [sp, #0x54]
    4724:      	str	w11, [x22, #0x2c0]
    4728:      	mov	w11, #0x18              // =24
    472c:      	umaddl	x9, w9, w11, x22
    4730:      	str	x10, [x9, #0x2d0]
    4734:      	mov	w10, #0x6               // =6
    4738:      	str	x8, [x9, #0x2d8]
    473c:      	add	x8, x9, #0x2d0
    4740:      	strh	w10, [x9, #0x2e0]
    4744:      	ldr	w11, [sp, #0x50]
    4748:      	ldrh	w10, [sp, #0x54]
    474c:      	stur	w11, [x8, #0x12]
    4750:      	mov	w8, #0x36               // =54
    4754:      	strh	w10, [x9, #0x2e6]
    4758:      	add	x9, sp, #0x50
    475c:      	str	w8, [sp, #0x50]
    4760:      	mov	w8, #0x1                // =1
    4764:      	blr	x8
    4768:      	cbz	x0, 0x477c <kprobe_unwind_ruby+0x477c>
    476c:      	ldr	x8, [x0]
    4770:      	add	x8, x8, #0x1
    4774:      	str	x8, [x0]
    4778:      	b	0x47d0 <kprobe_unwind_ruby+0x47d0>
    477c:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    4780:      	ldr	x8, [x8]
    4784:      	ldr	w8, [x8]
    4788:      	cbz	w8, 0x47d0 <kprobe_unwind_ruby+0x47d0>
    478c:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    4790:      	add	x8, x8, #0x0
    4794:      	add	x0, sp, #0x8
    4798:      	ldp	x9, x10, [x8, #0x10]
    479c:      	mov	w1, #0x2e               // =46
    47a0:      	stp	x9, x10, [sp, #0x18]
    47a4:      	ldr	x9, [x8, #0x20]
    47a8:      	add	x10, sp, #0x8
    47ac:      	str	x9, [sp, #0x28]
    47b0:      	ldur	x9, [x8, #0x26]
    47b4:      	stur	x9, [sp, #0x2e]
    47b8:      	ldp	x9, x8, [x8]
    47bc:      	stp	x9, x8, [sp, #0x8]
    47c0:      	mov	w8, #0x2e               // =46
    47c4:      	mov	w9, #0x6                // =6
    47c8:      	ldr	w2, [sp, #0x50]
    47cc:      	blr	x9
    47d0:      	ldr	x8, [sp, #0x78]
    47d4:      	ldr	x9, [sp]
    47d8:      	cmp	x9, x8
    47dc:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    47e0:      	ldrb	w9, [x23, #0x1e]
    47e4:      	str	xzr, [sp, #0x60]
    47e8:      	mov	w20, #0x8               // =8
    47ec:      	mov	w10, #0x70              // =112
    47f0:      	add	x0, sp, #0x70
    47f4:      	mov	w1, #0x8                // =8
    47f8:      	mov	w25, #0x70              // =112
    47fc:      	add	x8, x8, x9
    4800:      	ldrb	w9, [x23, #0x1c]
    4804:      	stp	xzr, x8, [sp, #0x70]
    4808:      	add	x8, x8, x9
    480c:      	add	x9, sp, #0x70
    4810:      	ldr	x8, [sp, #0x78]
    4814:      	ldrb	w9, [x23, #0x1c]
    4818:      	add	x2, x8, x9
    481c:      	blr	x10
    4820:      	ldr	x8, [sp, #0x78]
    4824:      	ldrb	w9, [x23, #0x1b]
    4828:      	add	x0, sp, #0x60
    482c:      	mov	w1, #0x8                // =8
    4830:      	add	x8, x8, x9
    4834:      	add	x9, sp, #0x60
    4838:      	ldr	x8, [sp, #0x78]
    483c:      	ldrb	w9, [x23, #0x1b]
    4840:      	add	x2, x8, x9
    4844:      	blr	x25
    4848:      	ldr	x8, [sp, #0x60]
    484c:      	cbz	x8, 0x4974 <kprobe_unwind_ruby+0x4974>
    4850:      	ldr	x8, [sp, #0x70]
    4854:      	cbz	x8, 0x4974 <kprobe_unwind_ruby+0x4974>
    4858:      	ldrb	w9, [x23, #0x1f]
    485c:      	mov	w10, #0x70              // =112
    4860:      	add	x11, sp, #0x68
    4864:      	add	x0, sp, #0x68
    4868:      	mov	w1, #0x8                // =8
    486c:      	add	x8, x8, x9
    4870:      	mov	w9, #0x8                // =8
    4874:      	ldr	x8, [sp, #0x70]
    4878:      	ldrb	w9, [x23, #0x1f]
    487c:      	add	x2, x8, x9
    4880:      	blr	x10
    4884:      	adrp	x25, 0x4000 <kprobe_unwind_ruby+0x4000>
    4888:      	mov	x20, x29
    488c:      	ldr	x25, [x25]
    4890:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    4894:      	ldr	x8, [sp, #0x68]
    4898:      	ldrb	w9, [x23, #0x21]
    489c:      	mov	w10, #0x70              // =112
    48a0:      	add	x11, sp, #0x58
    48a4:      	add	x0, sp, #0x58
    48a8:      	mov	w1, #0x8                // =8
    48ac:      	add	x8, x8, x9
    48b0:      	mov	w9, #0x8                // =8
    48b4:      	ldr	x8, [sp, #0x68]
    48b8:      	ldrb	w9, [x23, #0x21]
    48bc:      	add	x2, x8, x9
    48c0:      	blr	x10
    48c4:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    48c8:      	ldr	x8, [sp, #0x68]
    48cc:      	ldrb	w9, [x23, #0x22]
    48d0:      	mov	w10, #0x70              // =112
    48d4:      	add	x11, sp, #0x88
    48d8:      	add	x0, sp, #0x88
    48dc:      	mov	w1, #0x4                // =4
    48e0:      	add	x8, x8, x9
    48e4:      	mov	w9, #0x4                // =4
    48e8:      	ldr	x8, [sp, #0x68]
    48ec:      	ldrb	w9, [x23, #0x22]
    48f0:      	add	x2, x8, x9
    48f4:      	blr	x10
    48f8:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    48fc:      	ldrb	w9, [x23, #0x23]
    4900:      	ldr	x8, [sp, #0x60]
    4904:      	cbz	x9, 0x49dc <kprobe_unwind_ruby+0x49dc>
    4908:      	ldr	x10, [sp, #0x58]
    490c:      	sub	x10, x8, x10
    4910:      	udiv	x9, x10, x9
    4914:      	ldr	w10, [sp, #0x88]
    4918:      	cmp	x9, x10
    491c:      	b.ls	0x49dc <kprobe_unwind_ruby+0x49dc>
    4920:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    4924:      	ldr	x8, [x8]
    4928:      	ldr	w8, [x8]
    492c:      	cbz	w8, 0x4ab4 <kprobe_unwind_ruby+0x4ab4>
    4930:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    4934:      	add	x8, x8, #0x0
    4938:      	add	x0, sp, #0x8
    493c:      	ldp	x9, x10, [x8, #0x10]
    4940:      	mov	w1, #0x2d               // =45
    4944:      	stp	x9, x10, [sp, #0x18]
    4948:      	ldr	x9, [x8, #0x20]
    494c:      	add	x10, sp, #0x8
    4950:      	str	x9, [sp, #0x28]
    4954:      	ldur	x9, [x8, #0x25]
    4958:      	stur	x9, [sp, #0x2d]
    495c:      	ldp	x9, x8, [x8]
    4960:      	stp	x9, x8, [sp, #0x8]
    4964:      	mov	w8, #0x2d               // =45
    4968:      	mov	w9, #0x6                // =6
    496c:      	blr	x9
    4970:      	b	0x4ab4 <kprobe_unwind_ruby+0x4ab4>
    4974:      	ldr	w8, [x23]
    4978:      	cmp	w8, w24
    497c:      	b.lo	0x4ab4 <kprobe_unwind_ruby+0x4ab4>
    4980:      	ldr	x8, [sp, #0x78]
    4984:      	ldrb	w9, [x23, #0x1d]
    4988:      	mov	w10, #0x70              // =112
    498c:      	add	x11, sp, #0x50
    4990:      	add	x0, sp, #0x50
    4994:      	mov	w1, #0x8                // =8
    4998:      	str	xzr, [sp, #0x50]
    499c:      	add	x8, x8, x9
    49a0:      	mov	w9, #0x8                // =8
    49a4:      	ldr	x8, [sp, #0x78]
    49a8:      	ldrb	w9, [x23, #0x1d]
    49ac:      	add	x2, x8, x9
    49b0:      	blr	x10
    49b4:      	adrp	x25, 0x4000 <kprobe_unwind_ruby+0x4000>
    49b8:      	mov	x20, x29
    49bc:      	ldr	x25, [x25]
    49c0:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    49c4:      	ldr	w8, [sp, #0x50]
    49c8:      	mov	w9, #0x140              // =320
    49cc:      	mvn	w8, w8
    49d0:      	tst	x8, x9
    49d4:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    49d8:      	b	0x4ab4 <kprobe_unwind_ruby+0x4ab4>
    49dc:      	ldr	w9, [x22, #0x2c0]
    49e0:      	adrp	x25, 0x4000 <kprobe_unwind_ruby+0x4000>
    49e4:      	ldr	x25, [x25]
    49e8:      	cmp	w9, #0x7e
    49ec:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    49f0:      	ldr	x10, [sp, #0x68]
    49f4:      	add	w11, w9, #0x1
    49f8:      	str	wzr, [sp, #0x50]
    49fc:      	mov	x0, x29
    4a00:      	add	x1, sp, #0x50
    4a04:      	strh	wzr, [sp, #0x54]
    4a08:      	str	w11, [x22, #0x2c0]
    4a0c:      	mov	w11, #0x18              // =24
    4a10:      	umaddl	x9, w9, w11, x22
    4a14:      	str	x10, [x9, #0x2d0]
    4a18:      	mov	w10, #0x6               // =6
    4a1c:      	str	x8, [x9, #0x2d8]
    4a20:      	add	x8, x9, #0x2d0
    4a24:      	strh	w10, [x9, #0x2e0]
    4a28:      	ldr	w11, [sp, #0x50]
    4a2c:      	ldrh	w10, [sp, #0x54]
    4a30:      	stur	w11, [x8, #0x12]
    4a34:      	mov	w8, #0x36               // =54
    4a38:      	strh	w10, [x9, #0x2e6]
    4a3c:      	add	x9, sp, #0x50
    4a40:      	str	w8, [sp, #0x50]
    4a44:      	mov	w8, #0x1                // =1
    4a48:      	blr	x8
    4a4c:      	cbz	x0, 0x4a60 <kprobe_unwind_ruby+0x4a60>
    4a50:      	ldr	x8, [x0]
    4a54:      	add	x8, x8, #0x1
    4a58:      	str	x8, [x0]
    4a5c:      	b	0x4ab4 <kprobe_unwind_ruby+0x4ab4>
    4a60:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    4a64:      	ldr	x8, [x8]
    4a68:      	ldr	w8, [x8]
    4a6c:      	cbz	w8, 0x4ab4 <kprobe_unwind_ruby+0x4ab4>
    4a70:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    4a74:      	add	x8, x8, #0x0
    4a78:      	add	x0, sp, #0x8
    4a7c:      	ldp	x9, x10, [x8, #0x10]
    4a80:      	mov	w1, #0x2e               // =46
    4a84:      	stp	x9, x10, [sp, #0x18]
    4a88:      	ldr	x9, [x8, #0x20]
    4a8c:      	add	x10, sp, #0x8
    4a90:      	str	x9, [sp, #0x28]
    4a94:      	ldur	x9, [x8, #0x26]
    4a98:      	stur	x9, [sp, #0x2e]
    4a9c:      	ldp	x9, x8, [x8]
    4aa0:      	stp	x9, x8, [sp, #0x8]
    4aa4:      	mov	w8, #0x2e               // =46
    4aa8:      	mov	w9, #0x6                // =6
    4aac:      	ldr	w2, [sp, #0x50]
    4ab0:      	blr	x9
    4ab4:      	ldr	x8, [sp, #0x78]
    4ab8:      	ldr	x9, [sp]
    4abc:      	cmp	x9, x8
    4ac0:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    4ac4:      	ldrb	w9, [x23, #0x1e]
    4ac8:      	str	xzr, [sp, #0x60]
    4acc:      	mov	w20, #0x8               // =8
    4ad0:      	mov	w10, #0x70              // =112
    4ad4:      	add	x0, sp, #0x70
    4ad8:      	mov	w1, #0x8                // =8
    4adc:      	mov	w25, #0x70              // =112
    4ae0:      	add	x8, x8, x9
    4ae4:      	ldrb	w9, [x23, #0x1c]
    4ae8:      	stp	xzr, x8, [sp, #0x70]
    4aec:      	add	x8, x8, x9
    4af0:      	add	x9, sp, #0x70
    4af4:      	ldr	x8, [sp, #0x78]
    4af8:      	ldrb	w9, [x23, #0x1c]
    4afc:      	add	x2, x8, x9
    4b00:      	blr	x10
    4b04:      	ldr	x8, [sp, #0x78]
    4b08:      	ldrb	w9, [x23, #0x1b]
    4b0c:      	add	x0, sp, #0x60
    4b10:      	mov	w1, #0x8                // =8
    4b14:      	add	x8, x8, x9
    4b18:      	add	x9, sp, #0x60
    4b1c:      	ldr	x8, [sp, #0x78]
    4b20:      	ldrb	w9, [x23, #0x1b]
    4b24:      	add	x2, x8, x9
    4b28:      	blr	x25
    4b2c:      	ldr	x8, [sp, #0x60]
    4b30:      	cbz	x8, 0x4c58 <kprobe_unwind_ruby+0x4c58>
    4b34:      	ldr	x8, [sp, #0x70]
    4b38:      	cbz	x8, 0x4c58 <kprobe_unwind_ruby+0x4c58>
    4b3c:      	ldrb	w9, [x23, #0x1f]
    4b40:      	mov	w10, #0x70              // =112
    4b44:      	add	x11, sp, #0x68
    4b48:      	add	x0, sp, #0x68
    4b4c:      	mov	w1, #0x8                // =8
    4b50:      	add	x8, x8, x9
    4b54:      	mov	w9, #0x8                // =8
    4b58:      	ldr	x8, [sp, #0x70]
    4b5c:      	ldrb	w9, [x23, #0x1f]
    4b60:      	add	x2, x8, x9
    4b64:      	blr	x10
    4b68:      	adrp	x25, 0x4000 <kprobe_unwind_ruby+0x4000>
    4b6c:      	mov	x20, x29
    4b70:      	ldr	x25, [x25]
    4b74:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    4b78:      	ldr	x8, [sp, #0x68]
    4b7c:      	ldrb	w9, [x23, #0x21]
    4b80:      	mov	w10, #0x70              // =112
    4b84:      	add	x11, sp, #0x58
    4b88:      	add	x0, sp, #0x58
    4b8c:      	mov	w1, #0x8                // =8
    4b90:      	add	x8, x8, x9
    4b94:      	mov	w9, #0x8                // =8
    4b98:      	ldr	x8, [sp, #0x68]
    4b9c:      	ldrb	w9, [x23, #0x21]
    4ba0:      	add	x2, x8, x9
    4ba4:      	blr	x10
    4ba8:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    4bac:      	ldr	x8, [sp, #0x68]
    4bb0:      	ldrb	w9, [x23, #0x22]
    4bb4:      	mov	w10, #0x70              // =112
    4bb8:      	add	x11, sp, #0x88
    4bbc:      	add	x0, sp, #0x88
    4bc0:      	mov	w1, #0x4                // =4
    4bc4:      	add	x8, x8, x9
    4bc8:      	mov	w9, #0x4                // =4
    4bcc:      	ldr	x8, [sp, #0x68]
    4bd0:      	ldrb	w9, [x23, #0x22]
    4bd4:      	add	x2, x8, x9
    4bd8:      	blr	x10
    4bdc:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    4be0:      	ldrb	w9, [x23, #0x23]
    4be4:      	ldr	x8, [sp, #0x60]
    4be8:      	cbz	x9, 0x4cc0 <kprobe_unwind_ruby+0x4cc0>
    4bec:      	ldr	x10, [sp, #0x58]
    4bf0:      	sub	x10, x8, x10
    4bf4:      	udiv	x9, x10, x9
    4bf8:      	ldr	w10, [sp, #0x88]
    4bfc:      	cmp	x9, x10
    4c00:      	b.ls	0x4cc0 <kprobe_unwind_ruby+0x4cc0>
    4c04:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    4c08:      	ldr	x8, [x8]
    4c0c:      	ldr	w8, [x8]
    4c10:      	cbz	w8, 0x4d98 <kprobe_unwind_ruby+0x4d98>
    4c14:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    4c18:      	add	x8, x8, #0x0
    4c1c:      	add	x0, sp, #0x8
    4c20:      	ldp	x9, x10, [x8, #0x10]
    4c24:      	mov	w1, #0x2d               // =45
    4c28:      	stp	x9, x10, [sp, #0x18]
    4c2c:      	ldr	x9, [x8, #0x20]
    4c30:      	add	x10, sp, #0x8
    4c34:      	str	x9, [sp, #0x28]
    4c38:      	ldur	x9, [x8, #0x25]
    4c3c:      	stur	x9, [sp, #0x2d]
    4c40:      	ldp	x9, x8, [x8]
    4c44:      	stp	x9, x8, [sp, #0x8]
    4c48:      	mov	w8, #0x2d               // =45
    4c4c:      	mov	w9, #0x6                // =6
    4c50:      	blr	x9
    4c54:      	b	0x4d98 <kprobe_unwind_ruby+0x4d98>
    4c58:      	ldr	w8, [x23]
    4c5c:      	cmp	w8, w24
    4c60:      	b.lo	0x4d98 <kprobe_unwind_ruby+0x4d98>
    4c64:      	ldr	x8, [sp, #0x78]
    4c68:      	ldrb	w9, [x23, #0x1d]
    4c6c:      	mov	w10, #0x70              // =112
    4c70:      	add	x11, sp, #0x50
    4c74:      	add	x0, sp, #0x50
    4c78:      	mov	w1, #0x8                // =8
    4c7c:      	str	xzr, [sp, #0x50]
    4c80:      	add	x8, x8, x9
    4c84:      	mov	w9, #0x8                // =8
    4c88:      	ldr	x8, [sp, #0x78]
    4c8c:      	ldrb	w9, [x23, #0x1d]
    4c90:      	add	x2, x8, x9
    4c94:      	blr	x10
    4c98:      	adrp	x25, 0x4000 <kprobe_unwind_ruby+0x4000>
    4c9c:      	mov	x20, x29
    4ca0:      	ldr	x25, [x25]
    4ca4:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    4ca8:      	ldr	w8, [sp, #0x50]
    4cac:      	mov	w9, #0x140              // =320
    4cb0:      	mvn	w8, w8
    4cb4:      	tst	x8, x9
    4cb8:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    4cbc:      	b	0x4d98 <kprobe_unwind_ruby+0x4d98>
    4cc0:      	ldr	w9, [x22, #0x2c0]
    4cc4:      	adrp	x25, 0x4000 <kprobe_unwind_ruby+0x4000>
    4cc8:      	ldr	x25, [x25]
    4ccc:      	cmp	w9, #0x7e
    4cd0:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    4cd4:      	ldr	x10, [sp, #0x68]
    4cd8:      	add	w11, w9, #0x1
    4cdc:      	str	wzr, [sp, #0x50]
    4ce0:      	mov	x0, x29
    4ce4:      	add	x1, sp, #0x50
    4ce8:      	strh	wzr, [sp, #0x54]
    4cec:      	str	w11, [x22, #0x2c0]
    4cf0:      	mov	w11, #0x18              // =24
    4cf4:      	umaddl	x9, w9, w11, x22
    4cf8:      	str	x10, [x9, #0x2d0]
    4cfc:      	mov	w10, #0x6               // =6
    4d00:      	str	x8, [x9, #0x2d8]
    4d04:      	add	x8, x9, #0x2d0
    4d08:      	strh	w10, [x9, #0x2e0]
    4d0c:      	ldr	w11, [sp, #0x50]
    4d10:      	ldrh	w10, [sp, #0x54]
    4d14:      	stur	w11, [x8, #0x12]
    4d18:      	mov	w8, #0x36               // =54
    4d1c:      	strh	w10, [x9, #0x2e6]
    4d20:      	add	x9, sp, #0x50
    4d24:      	str	w8, [sp, #0x50]
    4d28:      	mov	w8, #0x1                // =1
    4d2c:      	blr	x8
    4d30:      	cbz	x0, 0x4d44 <kprobe_unwind_ruby+0x4d44>
    4d34:      	ldr	x8, [x0]
    4d38:      	add	x8, x8, #0x1
    4d3c:      	str	x8, [x0]
    4d40:      	b	0x4d98 <kprobe_unwind_ruby+0x4d98>
    4d44:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    4d48:      	ldr	x8, [x8]
    4d4c:      	ldr	w8, [x8]
    4d50:      	cbz	w8, 0x4d98 <kprobe_unwind_ruby+0x4d98>
    4d54:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    4d58:      	add	x8, x8, #0x0
    4d5c:      	add	x0, sp, #0x8
    4d60:      	ldp	x9, x10, [x8, #0x10]
    4d64:      	mov	w1, #0x2e               // =46
    4d68:      	stp	x9, x10, [sp, #0x18]
    4d6c:      	ldr	x9, [x8, #0x20]
    4d70:      	add	x10, sp, #0x8
    4d74:      	str	x9, [sp, #0x28]
    4d78:      	ldur	x9, [x8, #0x26]
    4d7c:      	stur	x9, [sp, #0x2e]
    4d80:      	ldp	x9, x8, [x8]
    4d84:      	stp	x9, x8, [sp, #0x8]
    4d88:      	mov	w8, #0x2e               // =46
    4d8c:      	mov	w9, #0x6                // =6
    4d90:      	ldr	w2, [sp, #0x50]
    4d94:      	blr	x9
    4d98:      	ldr	x8, [sp, #0x78]
    4d9c:      	ldr	x9, [sp]
    4da0:      	cmp	x9, x8
    4da4:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    4da8:      	ldrb	w9, [x23, #0x1e]
    4dac:      	str	xzr, [sp, #0x60]
    4db0:      	mov	w20, #0x8               // =8
    4db4:      	mov	w10, #0x70              // =112
    4db8:      	add	x0, sp, #0x70
    4dbc:      	mov	w1, #0x8                // =8
    4dc0:      	mov	w25, #0x70              // =112
    4dc4:      	add	x8, x8, x9
    4dc8:      	ldrb	w9, [x23, #0x1c]
    4dcc:      	stp	xzr, x8, [sp, #0x70]
    4dd0:      	add	x8, x8, x9
    4dd4:      	add	x9, sp, #0x70
    4dd8:      	ldr	x8, [sp, #0x78]
    4ddc:      	ldrb	w9, [x23, #0x1c]
    4de0:      	add	x2, x8, x9
    4de4:      	blr	x10
    4de8:      	ldr	x8, [sp, #0x78]
    4dec:      	ldrb	w9, [x23, #0x1b]
    4df0:      	add	x0, sp, #0x60
    4df4:      	mov	w1, #0x8                // =8
    4df8:      	add	x8, x8, x9
    4dfc:      	add	x9, sp, #0x60
    4e00:      	ldr	x8, [sp, #0x78]
    4e04:      	ldrb	w9, [x23, #0x1b]
    4e08:      	add	x2, x8, x9
    4e0c:      	blr	x25
    4e10:      	ldr	x8, [sp, #0x60]
    4e14:      	cbz	x8, 0x4f3c <kprobe_unwind_ruby+0x4f3c>
    4e18:      	ldr	x8, [sp, #0x70]
    4e1c:      	cbz	x8, 0x4f3c <kprobe_unwind_ruby+0x4f3c>
    4e20:      	ldrb	w9, [x23, #0x1f]
    4e24:      	mov	w10, #0x70              // =112
    4e28:      	add	x11, sp, #0x68
    4e2c:      	add	x0, sp, #0x68
    4e30:      	mov	w1, #0x8                // =8
    4e34:      	add	x8, x8, x9
    4e38:      	mov	w9, #0x8                // =8
    4e3c:      	ldr	x8, [sp, #0x70]
    4e40:      	ldrb	w9, [x23, #0x1f]
    4e44:      	add	x2, x8, x9
    4e48:      	blr	x10
    4e4c:      	adrp	x25, 0x4000 <kprobe_unwind_ruby+0x4000>
    4e50:      	mov	x20, x29
    4e54:      	ldr	x25, [x25]
    4e58:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    4e5c:      	ldr	x8, [sp, #0x68]
    4e60:      	ldrb	w9, [x23, #0x21]
    4e64:      	mov	w10, #0x70              // =112
    4e68:      	add	x11, sp, #0x58
    4e6c:      	add	x0, sp, #0x58
    4e70:      	mov	w1, #0x8                // =8
    4e74:      	add	x8, x8, x9
    4e78:      	mov	w9, #0x8                // =8
    4e7c:      	ldr	x8, [sp, #0x68]
    4e80:      	ldrb	w9, [x23, #0x21]
    4e84:      	add	x2, x8, x9
    4e88:      	blr	x10
    4e8c:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    4e90:      	ldr	x8, [sp, #0x68]
    4e94:      	ldrb	w9, [x23, #0x22]
    4e98:      	mov	w10, #0x70              // =112
    4e9c:      	add	x11, sp, #0x88
    4ea0:      	add	x0, sp, #0x88
    4ea4:      	mov	w1, #0x4                // =4
    4ea8:      	add	x8, x8, x9
    4eac:      	mov	w9, #0x4                // =4
    4eb0:      	ldr	x8, [sp, #0x68]
    4eb4:      	ldrb	w9, [x23, #0x22]
    4eb8:      	add	x2, x8, x9
    4ebc:      	blr	x10
    4ec0:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    4ec4:      	ldrb	w9, [x23, #0x23]
    4ec8:      	ldr	x8, [sp, #0x60]
    4ecc:      	cbz	x9, 0x4fa4 <kprobe_unwind_ruby+0x4fa4>
    4ed0:      	ldr	x10, [sp, #0x58]
    4ed4:      	sub	x10, x8, x10
    4ed8:      	udiv	x9, x10, x9
    4edc:      	ldr	w10, [sp, #0x88]
    4ee0:      	cmp	x9, x10
    4ee4:      	b.ls	0x4fa4 <kprobe_unwind_ruby+0x4fa4>
    4ee8:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    4eec:      	ldr	x8, [x8]
    4ef0:      	ldr	w8, [x8]
    4ef4:      	cbz	w8, 0x507c <kprobe_unwind_ruby+0x507c>
    4ef8:      	adrp	x8, 0x4000 <kprobe_unwind_ruby+0x4000>
    4efc:      	add	x8, x8, #0x0
    4f00:      	add	x0, sp, #0x8
    4f04:      	ldp	x9, x10, [x8, #0x10]
    4f08:      	mov	w1, #0x2d               // =45
    4f0c:      	stp	x9, x10, [sp, #0x18]
    4f10:      	ldr	x9, [x8, #0x20]
    4f14:      	add	x10, sp, #0x8
    4f18:      	str	x9, [sp, #0x28]
    4f1c:      	ldur	x9, [x8, #0x25]
    4f20:      	stur	x9, [sp, #0x2d]
    4f24:      	ldp	x9, x8, [x8]
    4f28:      	stp	x9, x8, [sp, #0x8]
    4f2c:      	mov	w8, #0x2d               // =45
    4f30:      	mov	w9, #0x6                // =6
    4f34:      	blr	x9
    4f38:      	b	0x507c <kprobe_unwind_ruby+0x507c>
    4f3c:      	ldr	w8, [x23]
    4f40:      	cmp	w8, w24
    4f44:      	b.lo	0x507c <kprobe_unwind_ruby+0x507c>
    4f48:      	ldr	x8, [sp, #0x78]
    4f4c:      	ldrb	w9, [x23, #0x1d]
    4f50:      	mov	w10, #0x70              // =112
    4f54:      	add	x11, sp, #0x50
    4f58:      	add	x0, sp, #0x50
    4f5c:      	mov	w1, #0x8                // =8
    4f60:      	str	xzr, [sp, #0x50]
    4f64:      	add	x8, x8, x9
    4f68:      	mov	w9, #0x8                // =8
    4f6c:      	ldr	x8, [sp, #0x78]
    4f70:      	ldrb	w9, [x23, #0x1d]
    4f74:      	add	x2, x8, x9
    4f78:      	blr	x10
    4f7c:      	adrp	x25, 0x4000 <kprobe_unwind_ruby+0x4000>
    4f80:      	mov	x20, x29
    4f84:      	ldr	x25, [x25]
    4f88:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    4f8c:      	ldr	w8, [sp, #0x50]
    4f90:      	mov	w9, #0x140              // =320
    4f94:      	mvn	w8, w8
    4f98:      	tst	x8, x9
    4f9c:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    4fa0:      	b	0x507c <kprobe_unwind_ruby+0x507c>
    4fa4:      	ldr	w9, [x22, #0x2c0]
    4fa8:      	adrp	x25, 0x4000 <kprobe_unwind_ruby+0x4000>
    4fac:      	ldr	x25, [x25]
    4fb0:      	cmp	w9, #0x7e
    4fb4:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    4fb8:      	ldr	x10, [sp, #0x68]
    4fbc:      	add	w11, w9, #0x1
    4fc0:      	str	wzr, [sp, #0x50]
    4fc4:      	mov	x0, x29
    4fc8:      	add	x1, sp, #0x50
    4fcc:      	strh	wzr, [sp, #0x54]
    4fd0:      	str	w11, [x22, #0x2c0]
    4fd4:      	mov	w11, #0x18              // =24
    4fd8:      	umaddl	x9, w9, w11, x22
    4fdc:      	str	x10, [x9, #0x2d0]
    4fe0:      	mov	w10, #0x6               // =6
    4fe4:      	str	x8, [x9, #0x2d8]
    4fe8:      	add	x8, x9, #0x2d0
    4fec:      	strh	w10, [x9, #0x2e0]
    4ff0:      	ldr	w11, [sp, #0x50]
    4ff4:      	ldrh	w10, [sp, #0x54]
    4ff8:      	stur	w11, [x8, #0x12]
    4ffc:      	mov	w8, #0x36               // =54
    5000:      	strh	w10, [x9, #0x2e6]
    5004:      	add	x9, sp, #0x50
    5008:      	str	w8, [sp, #0x50]
    500c:      	mov	w8, #0x1                // =1
    5010:      	blr	x8
    5014:      	cbz	x0, 0x5028 <kprobe_unwind_ruby+0x5028>
    5018:      	ldr	x8, [x0]
    501c:      	add	x8, x8, #0x1
    5020:      	str	x8, [x0]
    5024:      	b	0x507c <kprobe_unwind_ruby+0x507c>
    5028:      	adrp	x8, 0x5000 <kprobe_unwind_ruby+0x5000>
    502c:      	ldr	x8, [x8]
    5030:      	ldr	w8, [x8]
    5034:      	cbz	w8, 0x507c <kprobe_unwind_ruby+0x507c>
    5038:      	adrp	x8, 0x5000 <kprobe_unwind_ruby+0x5000>
    503c:      	add	x8, x8, #0x0
    5040:      	add	x0, sp, #0x8
    5044:      	ldp	x9, x10, [x8, #0x10]
    5048:      	mov	w1, #0x2e               // =46
    504c:      	stp	x9, x10, [sp, #0x18]
    5050:      	ldr	x9, [x8, #0x20]
    5054:      	add	x10, sp, #0x8
    5058:      	str	x9, [sp, #0x28]
    505c:      	ldur	x9, [x8, #0x26]
    5060:      	stur	x9, [sp, #0x2e]
    5064:      	ldp	x9, x8, [x8]
    5068:      	stp	x9, x8, [sp, #0x8]
    506c:      	mov	w8, #0x2e               // =46
    5070:      	mov	w9, #0x6                // =6
    5074:      	ldr	w2, [sp, #0x50]
    5078:      	blr	x9
    507c:      	ldr	x8, [sp, #0x78]
    5080:      	ldr	x9, [sp]
    5084:      	cmp	x9, x8
    5088:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    508c:      	ldrb	w9, [x23, #0x1e]
    5090:      	str	xzr, [sp, #0x60]
    5094:      	mov	w20, #0x8               // =8
    5098:      	mov	w10, #0x70              // =112
    509c:      	add	x0, sp, #0x70
    50a0:      	mov	w1, #0x8                // =8
    50a4:      	mov	w25, #0x70              // =112
    50a8:      	add	x8, x8, x9
    50ac:      	ldrb	w9, [x23, #0x1c]
    50b0:      	stp	xzr, x8, [sp, #0x70]
    50b4:      	add	x8, x8, x9
    50b8:      	add	x9, sp, #0x70
    50bc:      	ldr	x8, [sp, #0x78]
    50c0:      	ldrb	w9, [x23, #0x1c]
    50c4:      	add	x2, x8, x9
    50c8:      	blr	x10
    50cc:      	ldr	x8, [sp, #0x78]
    50d0:      	ldrb	w9, [x23, #0x1b]
    50d4:      	add	x0, sp, #0x60
    50d8:      	mov	w1, #0x8                // =8
    50dc:      	add	x8, x8, x9
    50e0:      	add	x9, sp, #0x60
    50e4:      	ldr	x8, [sp, #0x78]
    50e8:      	ldrb	w9, [x23, #0x1b]
    50ec:      	add	x2, x8, x9
    50f0:      	blr	x25
    50f4:      	ldr	x8, [sp, #0x60]
    50f8:      	cbz	x8, 0x5220 <kprobe_unwind_ruby+0x5220>
    50fc:      	ldr	x8, [sp, #0x70]
    5100:      	cbz	x8, 0x5220 <kprobe_unwind_ruby+0x5220>
    5104:      	ldrb	w9, [x23, #0x1f]
    5108:      	mov	w10, #0x70              // =112
    510c:      	add	x11, sp, #0x68
    5110:      	add	x0, sp, #0x68
    5114:      	mov	w1, #0x8                // =8
    5118:      	add	x8, x8, x9
    511c:      	mov	w9, #0x8                // =8
    5120:      	ldr	x8, [sp, #0x70]
    5124:      	ldrb	w9, [x23, #0x1f]
    5128:      	add	x2, x8, x9
    512c:      	blr	x10
    5130:      	adrp	x25, 0x5000 <kprobe_unwind_ruby+0x5000>
    5134:      	mov	x20, x29
    5138:      	ldr	x25, [x25]
    513c:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    5140:      	ldr	x8, [sp, #0x68]
    5144:      	ldrb	w9, [x23, #0x21]
    5148:      	mov	w10, #0x70              // =112
    514c:      	add	x11, sp, #0x58
    5150:      	add	x0, sp, #0x58
    5154:      	mov	w1, #0x8                // =8
    5158:      	add	x8, x8, x9
    515c:      	mov	w9, #0x8                // =8
    5160:      	ldr	x8, [sp, #0x68]
    5164:      	ldrb	w9, [x23, #0x21]
    5168:      	add	x2, x8, x9
    516c:      	blr	x10
    5170:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    5174:      	ldr	x8, [sp, #0x68]
    5178:      	ldrb	w9, [x23, #0x22]
    517c:      	mov	w10, #0x70              // =112
    5180:      	add	x11, sp, #0x88
    5184:      	add	x0, sp, #0x88
    5188:      	mov	w1, #0x4                // =4
    518c:      	add	x8, x8, x9
    5190:      	mov	w9, #0x4                // =4
    5194:      	ldr	x8, [sp, #0x68]
    5198:      	ldrb	w9, [x23, #0x22]
    519c:      	add	x2, x8, x9
    51a0:      	blr	x10
    51a4:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    51a8:      	ldrb	w9, [x23, #0x23]
    51ac:      	ldr	x8, [sp, #0x60]
    51b0:      	cbz	x9, 0x5288 <kprobe_unwind_ruby+0x5288>
    51b4:      	ldr	x10, [sp, #0x58]
    51b8:      	sub	x10, x8, x10
    51bc:      	udiv	x9, x10, x9
    51c0:      	ldr	w10, [sp, #0x88]
    51c4:      	cmp	x9, x10
    51c8:      	b.ls	0x5288 <kprobe_unwind_ruby+0x5288>
    51cc:      	adrp	x8, 0x5000 <kprobe_unwind_ruby+0x5000>
    51d0:      	ldr	x8, [x8]
    51d4:      	ldr	w8, [x8]
    51d8:      	cbz	w8, 0x5360 <kprobe_unwind_ruby+0x5360>
    51dc:      	adrp	x8, 0x5000 <kprobe_unwind_ruby+0x5000>
    51e0:      	add	x8, x8, #0x0
    51e4:      	add	x0, sp, #0x8
    51e8:      	ldp	x9, x10, [x8, #0x10]
    51ec:      	mov	w1, #0x2d               // =45
    51f0:      	stp	x9, x10, [sp, #0x18]
    51f4:      	ldr	x9, [x8, #0x20]
    51f8:      	add	x10, sp, #0x8
    51fc:      	str	x9, [sp, #0x28]
    5200:      	ldur	x9, [x8, #0x25]
    5204:      	stur	x9, [sp, #0x2d]
    5208:      	ldp	x9, x8, [x8]
    520c:      	stp	x9, x8, [sp, #0x8]
    5210:      	mov	w8, #0x2d               // =45
    5214:      	mov	w9, #0x6                // =6
    5218:      	blr	x9
    521c:      	b	0x5360 <kprobe_unwind_ruby+0x5360>
    5220:      	ldr	w8, [x23]
    5224:      	cmp	w8, w24
    5228:      	b.lo	0x5360 <kprobe_unwind_ruby+0x5360>
    522c:      	ldr	x8, [sp, #0x78]
    5230:      	ldrb	w9, [x23, #0x1d]
    5234:      	mov	w10, #0x70              // =112
    5238:      	add	x11, sp, #0x50
    523c:      	add	x0, sp, #0x50
    5240:      	mov	w1, #0x8                // =8
    5244:      	str	xzr, [sp, #0x50]
    5248:      	add	x8, x8, x9
    524c:      	mov	w9, #0x8                // =8
    5250:      	ldr	x8, [sp, #0x78]
    5254:      	ldrb	w9, [x23, #0x1d]
    5258:      	add	x2, x8, x9
    525c:      	blr	x10
    5260:      	adrp	x25, 0x5000 <kprobe_unwind_ruby+0x5000>
    5264:      	mov	x20, x29
    5268:      	ldr	x25, [x25]
    526c:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    5270:      	ldr	w8, [sp, #0x50]
    5274:      	mov	w9, #0x140              // =320
    5278:      	mvn	w8, w8
    527c:      	tst	x8, x9
    5280:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    5284:      	b	0x5360 <kprobe_unwind_ruby+0x5360>
    5288:      	ldr	w9, [x22, #0x2c0]
    528c:      	adrp	x25, 0x5000 <kprobe_unwind_ruby+0x5000>
    5290:      	ldr	x25, [x25]
    5294:      	cmp	w9, #0x7e
    5298:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    529c:      	ldr	x10, [sp, #0x68]
    52a0:      	add	w11, w9, #0x1
    52a4:      	str	wzr, [sp, #0x50]
    52a8:      	mov	x0, x29
    52ac:      	add	x1, sp, #0x50
    52b0:      	strh	wzr, [sp, #0x54]
    52b4:      	str	w11, [x22, #0x2c0]
    52b8:      	mov	w11, #0x18              // =24
    52bc:      	umaddl	x9, w9, w11, x22
    52c0:      	str	x10, [x9, #0x2d0]
    52c4:      	mov	w10, #0x6               // =6
    52c8:      	str	x8, [x9, #0x2d8]
    52cc:      	add	x8, x9, #0x2d0
    52d0:      	strh	w10, [x9, #0x2e0]
    52d4:      	ldr	w11, [sp, #0x50]
    52d8:      	ldrh	w10, [sp, #0x54]
    52dc:      	stur	w11, [x8, #0x12]
    52e0:      	mov	w8, #0x36               // =54
    52e4:      	strh	w10, [x9, #0x2e6]
    52e8:      	add	x9, sp, #0x50
    52ec:      	str	w8, [sp, #0x50]
    52f0:      	mov	w8, #0x1                // =1
    52f4:      	blr	x8
    52f8:      	cbz	x0, 0x530c <kprobe_unwind_ruby+0x530c>
    52fc:      	ldr	x8, [x0]
    5300:      	add	x8, x8, #0x1
    5304:      	str	x8, [x0]
    5308:      	b	0x5360 <kprobe_unwind_ruby+0x5360>
    530c:      	adrp	x8, 0x5000 <kprobe_unwind_ruby+0x5000>
    5310:      	ldr	x8, [x8]
    5314:      	ldr	w8, [x8]
    5318:      	cbz	w8, 0x5360 <kprobe_unwind_ruby+0x5360>
    531c:      	adrp	x8, 0x5000 <kprobe_unwind_ruby+0x5000>
    5320:      	add	x8, x8, #0x0
    5324:      	add	x0, sp, #0x8
    5328:      	ldp	x9, x10, [x8, #0x10]
    532c:      	mov	w1, #0x2e               // =46
    5330:      	stp	x9, x10, [sp, #0x18]
    5334:      	ldr	x9, [x8, #0x20]
    5338:      	add	x10, sp, #0x8
    533c:      	str	x9, [sp, #0x28]
    5340:      	ldur	x9, [x8, #0x26]
    5344:      	stur	x9, [sp, #0x2e]
    5348:      	ldp	x9, x8, [x8]
    534c:      	stp	x9, x8, [sp, #0x8]
    5350:      	mov	w8, #0x2e               // =46
    5354:      	mov	w9, #0x6                // =6
    5358:      	ldr	w2, [sp, #0x50]
    535c:      	blr	x9
    5360:      	ldr	x8, [sp, #0x78]
    5364:      	ldr	x9, [sp]
    5368:      	cmp	x9, x8
    536c:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    5370:      	ldrb	w9, [x23, #0x1e]
    5374:      	str	xzr, [sp, #0x60]
    5378:      	mov	w20, #0x8               // =8
    537c:      	mov	w10, #0x70              // =112
    5380:      	add	x0, sp, #0x70
    5384:      	mov	w1, #0x8                // =8
    5388:      	mov	w25, #0x70              // =112
    538c:      	add	x8, x8, x9
    5390:      	ldrb	w9, [x23, #0x1c]
    5394:      	stp	xzr, x8, [sp, #0x70]
    5398:      	add	x8, x8, x9
    539c:      	add	x9, sp, #0x70
    53a0:      	ldr	x8, [sp, #0x78]
    53a4:      	ldrb	w9, [x23, #0x1c]
    53a8:      	add	x2, x8, x9
    53ac:      	blr	x10
    53b0:      	ldr	x8, [sp, #0x78]
    53b4:      	ldrb	w9, [x23, #0x1b]
    53b8:      	add	x0, sp, #0x60
    53bc:      	mov	w1, #0x8                // =8
    53c0:      	add	x8, x8, x9
    53c4:      	add	x9, sp, #0x60
    53c8:      	ldr	x8, [sp, #0x78]
    53cc:      	ldrb	w9, [x23, #0x1b]
    53d0:      	add	x2, x8, x9
    53d4:      	blr	x25
    53d8:      	ldr	x8, [sp, #0x60]
    53dc:      	cbz	x8, 0x5504 <kprobe_unwind_ruby+0x5504>
    53e0:      	ldr	x8, [sp, #0x70]
    53e4:      	cbz	x8, 0x5504 <kprobe_unwind_ruby+0x5504>
    53e8:      	ldrb	w9, [x23, #0x1f]
    53ec:      	mov	w10, #0x70              // =112
    53f0:      	add	x11, sp, #0x68
    53f4:      	add	x0, sp, #0x68
    53f8:      	mov	w1, #0x8                // =8
    53fc:      	add	x8, x8, x9
    5400:      	mov	w9, #0x8                // =8
    5404:      	ldr	x8, [sp, #0x70]
    5408:      	ldrb	w9, [x23, #0x1f]
    540c:      	add	x2, x8, x9
    5410:      	blr	x10
    5414:      	adrp	x25, 0x5000 <kprobe_unwind_ruby+0x5000>
    5418:      	mov	x20, x29
    541c:      	ldr	x25, [x25]
    5420:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    5424:      	ldr	x8, [sp, #0x68]
    5428:      	ldrb	w9, [x23, #0x21]
    542c:      	mov	w10, #0x70              // =112
    5430:      	add	x11, sp, #0x58
    5434:      	add	x0, sp, #0x58
    5438:      	mov	w1, #0x8                // =8
    543c:      	add	x8, x8, x9
    5440:      	mov	w9, #0x8                // =8
    5444:      	ldr	x8, [sp, #0x68]
    5448:      	ldrb	w9, [x23, #0x21]
    544c:      	add	x2, x8, x9
    5450:      	blr	x10
    5454:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    5458:      	ldr	x8, [sp, #0x68]
    545c:      	ldrb	w9, [x23, #0x22]
    5460:      	mov	w10, #0x70              // =112
    5464:      	add	x11, sp, #0x88
    5468:      	add	x0, sp, #0x88
    546c:      	mov	w1, #0x4                // =4
    5470:      	add	x8, x8, x9
    5474:      	mov	w9, #0x4                // =4
    5478:      	ldr	x8, [sp, #0x68]
    547c:      	ldrb	w9, [x23, #0x22]
    5480:      	add	x2, x8, x9
    5484:      	blr	x10
    5488:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    548c:      	ldrb	w9, [x23, #0x23]
    5490:      	ldr	x8, [sp, #0x60]
    5494:      	cbz	x9, 0x556c <kprobe_unwind_ruby+0x556c>
    5498:      	ldr	x10, [sp, #0x58]
    549c:      	sub	x10, x8, x10
    54a0:      	udiv	x9, x10, x9
    54a4:      	ldr	w10, [sp, #0x88]
    54a8:      	cmp	x9, x10
    54ac:      	b.ls	0x556c <kprobe_unwind_ruby+0x556c>
    54b0:      	adrp	x8, 0x5000 <kprobe_unwind_ruby+0x5000>
    54b4:      	ldr	x8, [x8]
    54b8:      	ldr	w8, [x8]
    54bc:      	cbz	w8, 0x5644 <kprobe_unwind_ruby+0x5644>
    54c0:      	adrp	x8, 0x5000 <kprobe_unwind_ruby+0x5000>
    54c4:      	add	x8, x8, #0x0
    54c8:      	add	x0, sp, #0x8
    54cc:      	ldp	x9, x10, [x8, #0x10]
    54d0:      	mov	w1, #0x2d               // =45
    54d4:      	stp	x9, x10, [sp, #0x18]
    54d8:      	ldr	x9, [x8, #0x20]
    54dc:      	add	x10, sp, #0x8
    54e0:      	str	x9, [sp, #0x28]
    54e4:      	ldur	x9, [x8, #0x25]
    54e8:      	stur	x9, [sp, #0x2d]
    54ec:      	ldp	x9, x8, [x8]
    54f0:      	stp	x9, x8, [sp, #0x8]
    54f4:      	mov	w8, #0x2d               // =45
    54f8:      	mov	w9, #0x6                // =6
    54fc:      	blr	x9
    5500:      	b	0x5644 <kprobe_unwind_ruby+0x5644>
    5504:      	ldr	w8, [x23]
    5508:      	cmp	w8, w24
    550c:      	b.lo	0x5644 <kprobe_unwind_ruby+0x5644>
    5510:      	ldr	x8, [sp, #0x78]
    5514:      	ldrb	w9, [x23, #0x1d]
    5518:      	mov	w10, #0x70              // =112
    551c:      	add	x11, sp, #0x50
    5520:      	add	x0, sp, #0x50
    5524:      	mov	w1, #0x8                // =8
    5528:      	str	xzr, [sp, #0x50]
    552c:      	add	x8, x8, x9
    5530:      	mov	w9, #0x8                // =8
    5534:      	ldr	x8, [sp, #0x78]
    5538:      	ldrb	w9, [x23, #0x1d]
    553c:      	add	x2, x8, x9
    5540:      	blr	x10
    5544:      	adrp	x25, 0x5000 <kprobe_unwind_ruby+0x5000>
    5548:      	mov	x20, x29
    554c:      	ldr	x25, [x25]
    5550:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    5554:      	ldr	w8, [sp, #0x50]
    5558:      	mov	w9, #0x140              // =320
    555c:      	mvn	w8, w8
    5560:      	tst	x8, x9
    5564:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    5568:      	b	0x5644 <kprobe_unwind_ruby+0x5644>
    556c:      	ldr	w9, [x22, #0x2c0]
    5570:      	adrp	x25, 0x5000 <kprobe_unwind_ruby+0x5000>
    5574:      	ldr	x25, [x25]
    5578:      	cmp	w9, #0x7e
    557c:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    5580:      	ldr	x10, [sp, #0x68]
    5584:      	add	w11, w9, #0x1
    5588:      	str	wzr, [sp, #0x50]
    558c:      	mov	x0, x29
    5590:      	add	x1, sp, #0x50
    5594:      	strh	wzr, [sp, #0x54]
    5598:      	str	w11, [x22, #0x2c0]
    559c:      	mov	w11, #0x18              // =24
    55a0:      	umaddl	x9, w9, w11, x22
    55a4:      	str	x10, [x9, #0x2d0]
    55a8:      	mov	w10, #0x6               // =6
    55ac:      	str	x8, [x9, #0x2d8]
    55b0:      	add	x8, x9, #0x2d0
    55b4:      	strh	w10, [x9, #0x2e0]
    55b8:      	ldr	w11, [sp, #0x50]
    55bc:      	ldrh	w10, [sp, #0x54]
    55c0:      	stur	w11, [x8, #0x12]
    55c4:      	mov	w8, #0x36               // =54
    55c8:      	strh	w10, [x9, #0x2e6]
    55cc:      	add	x9, sp, #0x50
    55d0:      	str	w8, [sp, #0x50]
    55d4:      	mov	w8, #0x1                // =1
    55d8:      	blr	x8
    55dc:      	cbz	x0, 0x55f0 <kprobe_unwind_ruby+0x55f0>
    55e0:      	ldr	x8, [x0]
    55e4:      	add	x8, x8, #0x1
    55e8:      	str	x8, [x0]
    55ec:      	b	0x5644 <kprobe_unwind_ruby+0x5644>
    55f0:      	adrp	x8, 0x5000 <kprobe_unwind_ruby+0x5000>
    55f4:      	ldr	x8, [x8]
    55f8:      	ldr	w8, [x8]
    55fc:      	cbz	w8, 0x5644 <kprobe_unwind_ruby+0x5644>
    5600:      	adrp	x8, 0x5000 <kprobe_unwind_ruby+0x5000>
    5604:      	add	x8, x8, #0x0
    5608:      	add	x0, sp, #0x8
    560c:      	ldp	x9, x10, [x8, #0x10]
    5610:      	mov	w1, #0x2e               // =46
    5614:      	stp	x9, x10, [sp, #0x18]
    5618:      	ldr	x9, [x8, #0x20]
    561c:      	add	x10, sp, #0x8
    5620:      	str	x9, [sp, #0x28]
    5624:      	ldur	x9, [x8, #0x26]
    5628:      	stur	x9, [sp, #0x2e]
    562c:      	ldp	x9, x8, [x8]
    5630:      	stp	x9, x8, [sp, #0x8]
    5634:      	mov	w8, #0x2e               // =46
    5638:      	mov	w9, #0x6                // =6
    563c:      	ldr	w2, [sp, #0x50]
    5640:      	blr	x9
    5644:      	ldr	x8, [sp, #0x78]
    5648:      	ldr	x9, [sp]
    564c:      	cmp	x9, x8
    5650:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    5654:      	ldrb	w9, [x23, #0x1e]
    5658:      	str	xzr, [sp, #0x60]
    565c:      	mov	w20, #0x8               // =8
    5660:      	mov	w10, #0x70              // =112
    5664:      	add	x0, sp, #0x70
    5668:      	mov	w1, #0x8                // =8
    566c:      	mov	w25, #0x70              // =112
    5670:      	add	x8, x8, x9
    5674:      	ldrb	w9, [x23, #0x1c]
    5678:      	stp	xzr, x8, [sp, #0x70]
    567c:      	add	x8, x8, x9
    5680:      	add	x9, sp, #0x70
    5684:      	ldr	x8, [sp, #0x78]
    5688:      	ldrb	w9, [x23, #0x1c]
    568c:      	add	x2, x8, x9
    5690:      	blr	x10
    5694:      	ldr	x8, [sp, #0x78]
    5698:      	ldrb	w9, [x23, #0x1b]
    569c:      	add	x0, sp, #0x60
    56a0:      	mov	w1, #0x8                // =8
    56a4:      	add	x8, x8, x9
    56a8:      	add	x9, sp, #0x60
    56ac:      	ldr	x8, [sp, #0x78]
    56b0:      	ldrb	w9, [x23, #0x1b]
    56b4:      	add	x2, x8, x9
    56b8:      	blr	x25
    56bc:      	ldr	x8, [sp, #0x60]
    56c0:      	cbz	x8, 0x57e8 <kprobe_unwind_ruby+0x57e8>
    56c4:      	ldr	x8, [sp, #0x70]
    56c8:      	cbz	x8, 0x57e8 <kprobe_unwind_ruby+0x57e8>
    56cc:      	ldrb	w9, [x23, #0x1f]
    56d0:      	mov	w10, #0x70              // =112
    56d4:      	add	x11, sp, #0x68
    56d8:      	add	x0, sp, #0x68
    56dc:      	mov	w1, #0x8                // =8
    56e0:      	add	x8, x8, x9
    56e4:      	mov	w9, #0x8                // =8
    56e8:      	ldr	x8, [sp, #0x70]
    56ec:      	ldrb	w9, [x23, #0x1f]
    56f0:      	add	x2, x8, x9
    56f4:      	blr	x10
    56f8:      	adrp	x25, 0x5000 <kprobe_unwind_ruby+0x5000>
    56fc:      	mov	x20, x29
    5700:      	ldr	x25, [x25]
    5704:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    5708:      	ldr	x8, [sp, #0x68]
    570c:      	ldrb	w9, [x23, #0x21]
    5710:      	mov	w10, #0x70              // =112
    5714:      	add	x11, sp, #0x58
    5718:      	add	x0, sp, #0x58
    571c:      	mov	w1, #0x8                // =8
    5720:      	add	x8, x8, x9
    5724:      	mov	w9, #0x8                // =8
    5728:      	ldr	x8, [sp, #0x68]
    572c:      	ldrb	w9, [x23, #0x21]
    5730:      	add	x2, x8, x9
    5734:      	blr	x10
    5738:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    573c:      	ldr	x8, [sp, #0x68]
    5740:      	ldrb	w9, [x23, #0x22]
    5744:      	mov	w10, #0x70              // =112
    5748:      	add	x11, sp, #0x88
    574c:      	add	x0, sp, #0x88
    5750:      	mov	w1, #0x4                // =4
    5754:      	add	x8, x8, x9
    5758:      	mov	w9, #0x4                // =4
    575c:      	ldr	x8, [sp, #0x68]
    5760:      	ldrb	w9, [x23, #0x22]
    5764:      	add	x2, x8, x9
    5768:      	blr	x10
    576c:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    5770:      	ldrb	w9, [x23, #0x23]
    5774:      	ldr	x8, [sp, #0x60]
    5778:      	cbz	x9, 0x5850 <kprobe_unwind_ruby+0x5850>
    577c:      	ldr	x10, [sp, #0x58]
    5780:      	sub	x10, x8, x10
    5784:      	udiv	x9, x10, x9
    5788:      	ldr	w10, [sp, #0x88]
    578c:      	cmp	x9, x10
    5790:      	b.ls	0x5850 <kprobe_unwind_ruby+0x5850>
    5794:      	adrp	x8, 0x5000 <kprobe_unwind_ruby+0x5000>
    5798:      	ldr	x8, [x8]
    579c:      	ldr	w8, [x8]
    57a0:      	cbz	w8, 0x5928 <kprobe_unwind_ruby+0x5928>
    57a4:      	adrp	x8, 0x5000 <kprobe_unwind_ruby+0x5000>
    57a8:      	add	x8, x8, #0x0
    57ac:      	add	x0, sp, #0x8
    57b0:      	ldp	x9, x10, [x8, #0x10]
    57b4:      	mov	w1, #0x2d               // =45
    57b8:      	stp	x9, x10, [sp, #0x18]
    57bc:      	ldr	x9, [x8, #0x20]
    57c0:      	add	x10, sp, #0x8
    57c4:      	str	x9, [sp, #0x28]
    57c8:      	ldur	x9, [x8, #0x25]
    57cc:      	stur	x9, [sp, #0x2d]
    57d0:      	ldp	x9, x8, [x8]
    57d4:      	stp	x9, x8, [sp, #0x8]
    57d8:      	mov	w8, #0x2d               // =45
    57dc:      	mov	w9, #0x6                // =6
    57e0:      	blr	x9
    57e4:      	b	0x5928 <kprobe_unwind_ruby+0x5928>
    57e8:      	ldr	w8, [x23]
    57ec:      	cmp	w8, w24
    57f0:      	b.lo	0x5928 <kprobe_unwind_ruby+0x5928>
    57f4:      	ldr	x8, [sp, #0x78]
    57f8:      	ldrb	w9, [x23, #0x1d]
    57fc:      	mov	w10, #0x70              // =112
    5800:      	add	x11, sp, #0x50
    5804:      	add	x0, sp, #0x50
    5808:      	mov	w1, #0x8                // =8
    580c:      	str	xzr, [sp, #0x50]
    5810:      	add	x8, x8, x9
    5814:      	mov	w9, #0x8                // =8
    5818:      	ldr	x8, [sp, #0x78]
    581c:      	ldrb	w9, [x23, #0x1d]
    5820:      	add	x2, x8, x9
    5824:      	blr	x10
    5828:      	adrp	x25, 0x5000 <kprobe_unwind_ruby+0x5000>
    582c:      	mov	x20, x29
    5830:      	ldr	x25, [x25]
    5834:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    5838:      	ldr	w8, [sp, #0x50]
    583c:      	mov	w9, #0x140              // =320
    5840:      	mvn	w8, w8
    5844:      	tst	x8, x9
    5848:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    584c:      	b	0x5928 <kprobe_unwind_ruby+0x5928>
    5850:      	ldr	w9, [x22, #0x2c0]
    5854:      	adrp	x25, 0x5000 <kprobe_unwind_ruby+0x5000>
    5858:      	ldr	x25, [x25]
    585c:      	cmp	w9, #0x7e
    5860:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    5864:      	ldr	x10, [sp, #0x68]
    5868:      	add	w11, w9, #0x1
    586c:      	str	wzr, [sp, #0x50]
    5870:      	mov	x0, x29
    5874:      	add	x1, sp, #0x50
    5878:      	strh	wzr, [sp, #0x54]
    587c:      	str	w11, [x22, #0x2c0]
    5880:      	mov	w11, #0x18              // =24
    5884:      	umaddl	x9, w9, w11, x22
    5888:      	str	x10, [x9, #0x2d0]
    588c:      	mov	w10, #0x6               // =6
    5890:      	str	x8, [x9, #0x2d8]
    5894:      	add	x8, x9, #0x2d0
    5898:      	strh	w10, [x9, #0x2e0]
    589c:      	ldr	w11, [sp, #0x50]
    58a0:      	ldrh	w10, [sp, #0x54]
    58a4:      	stur	w11, [x8, #0x12]
    58a8:      	mov	w8, #0x36               // =54
    58ac:      	strh	w10, [x9, #0x2e6]
    58b0:      	add	x9, sp, #0x50
    58b4:      	str	w8, [sp, #0x50]
    58b8:      	mov	w8, #0x1                // =1
    58bc:      	blr	x8
    58c0:      	cbz	x0, 0x58d4 <kprobe_unwind_ruby+0x58d4>
    58c4:      	ldr	x8, [x0]
    58c8:      	add	x8, x8, #0x1
    58cc:      	str	x8, [x0]
    58d0:      	b	0x5928 <kprobe_unwind_ruby+0x5928>
    58d4:      	adrp	x8, 0x5000 <kprobe_unwind_ruby+0x5000>
    58d8:      	ldr	x8, [x8]
    58dc:      	ldr	w8, [x8]
    58e0:      	cbz	w8, 0x5928 <kprobe_unwind_ruby+0x5928>
    58e4:      	adrp	x8, 0x5000 <kprobe_unwind_ruby+0x5000>
    58e8:      	add	x8, x8, #0x0
    58ec:      	add	x0, sp, #0x8
    58f0:      	ldp	x9, x10, [x8, #0x10]
    58f4:      	mov	w1, #0x2e               // =46
    58f8:      	stp	x9, x10, [sp, #0x18]
    58fc:      	ldr	x9, [x8, #0x20]
    5900:      	add	x10, sp, #0x8
    5904:      	str	x9, [sp, #0x28]
    5908:      	ldur	x9, [x8, #0x26]
    590c:      	stur	x9, [sp, #0x2e]
    5910:      	ldp	x9, x8, [x8]
    5914:      	stp	x9, x8, [sp, #0x8]
    5918:      	mov	w8, #0x2e               // =46
    591c:      	mov	w9, #0x6                // =6
    5920:      	ldr	w2, [sp, #0x50]
    5924:      	blr	x9
    5928:      	ldr	x8, [sp, #0x78]
    592c:      	ldr	x9, [sp]
    5930:      	cmp	x9, x8
    5934:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    5938:      	ldrb	w9, [x23, #0x1e]
    593c:      	str	xzr, [sp, #0x60]
    5940:      	mov	w20, #0x8               // =8
    5944:      	mov	w10, #0x70              // =112
    5948:      	add	x0, sp, #0x70
    594c:      	mov	w1, #0x8                // =8
    5950:      	mov	w25, #0x70              // =112
    5954:      	add	x8, x8, x9
    5958:      	ldrb	w9, [x23, #0x1c]
    595c:      	stp	xzr, x8, [sp, #0x70]
    5960:      	add	x8, x8, x9
    5964:      	add	x9, sp, #0x70
    5968:      	ldr	x8, [sp, #0x78]
    596c:      	ldrb	w9, [x23, #0x1c]
    5970:      	add	x2, x8, x9
    5974:      	blr	x10
    5978:      	ldr	x8, [sp, #0x78]
    597c:      	ldrb	w9, [x23, #0x1b]
    5980:      	add	x0, sp, #0x60
    5984:      	mov	w1, #0x8                // =8
    5988:      	add	x8, x8, x9
    598c:      	add	x9, sp, #0x60
    5990:      	ldr	x8, [sp, #0x78]
    5994:      	ldrb	w9, [x23, #0x1b]
    5998:      	add	x2, x8, x9
    599c:      	blr	x25
    59a0:      	ldr	x8, [sp, #0x60]
    59a4:      	cbz	x8, 0x5acc <kprobe_unwind_ruby+0x5acc>
    59a8:      	ldr	x8, [sp, #0x70]
    59ac:      	cbz	x8, 0x5acc <kprobe_unwind_ruby+0x5acc>
    59b0:      	ldrb	w9, [x23, #0x1f]
    59b4:      	mov	w10, #0x70              // =112
    59b8:      	add	x11, sp, #0x68
    59bc:      	add	x0, sp, #0x68
    59c0:      	mov	w1, #0x8                // =8
    59c4:      	add	x8, x8, x9
    59c8:      	mov	w9, #0x8                // =8
    59cc:      	ldr	x8, [sp, #0x70]
    59d0:      	ldrb	w9, [x23, #0x1f]
    59d4:      	add	x2, x8, x9
    59d8:      	blr	x10
    59dc:      	adrp	x25, 0x5000 <kprobe_unwind_ruby+0x5000>
    59e0:      	mov	x20, x29
    59e4:      	ldr	x25, [x25]
    59e8:      	cbnz	x0, 0x6b4 <kprobe_unwind_ruby+0x6b4>
    59ec:      	ldr	x8, [sp, #0x68]
    59f0:      	ldrb	w9, [x23, #0x21]
    59f4:      	mov	w10, #0x70              // =112
    59f8:      	add	x11, sp, #0x58
    59fc:      	add	x0, sp, #0x58
    5a00:      	mov	w1, #0x8                // =8
    5a04:      	add	x8, x8, x9
    5a08:      	mov	w9, #0x8                // =8
    5a0c:      	ldr	x8, [sp, #0x68]
    5a10:      	ldrb	w9, [x23, #0x21]
    5a14:      	add	x2, x8, x9
    5a18:      	blr	x10
    5a1c:      	cbnz	x0, 0xa28 <kprobe_unwind_ruby+0xa28>
    5a20:      	ldr	x8, [sp, #0x68]
    5a24:      	ldrb	w9, [x23, #0x22]
    5a28:      	mov	w10, #0x70              // =112
    5a2c:      	add	x11, sp, #0x88
    5a30:      	add	x0, sp, #0x88
    5a34:      	mov	w1, #0x4                // =4
    5a38:      	add	x8, x8, x9
    5a3c:      	mov	w9, #0x4                // =4
    5a40:      	ldr	x8, [sp, #0x68]
    5a44:      	ldrb	w9, [x23, #0x22]
    5a48:      	add	x2, x8, x9
    5a4c:      	blr	x10
    5a50:      	cbnz	x0, 0xd30 <kprobe_unwind_ruby+0xd30>
    5a54:      	ldrb	w9, [x23, #0x23]
    5a58:      	ldr	x8, [sp, #0x60]
    5a5c:      	cbz	x9, 0x5b34 <kprobe_unwind_ruby+0x5b34>
    5a60:      	ldr	x10, [sp, #0x58]
    5a64:      	sub	x10, x8, x10
    5a68:      	udiv	x9, x10, x9
    5a6c:      	ldr	w10, [sp, #0x88]
    5a70:      	cmp	x9, x10
    5a74:      	b.ls	0x5b34 <kprobe_unwind_ruby+0x5b34>
    5a78:      	adrp	x8, 0x5000 <kprobe_unwind_ruby+0x5000>
    5a7c:      	ldr	x8, [x8]
    5a80:      	ldr	w8, [x8]
    5a84:      	cbz	w8, 0x5c0c <kprobe_unwind_ruby+0x5c0c>
    5a88:      	adrp	x8, 0x5000 <kprobe_unwind_ruby+0x5000>
    5a8c:      	add	x8, x8, #0x0
    5a90:      	add	x0, sp, #0x8
    5a94:      	ldp	x9, x10, [x8, #0x10]
    5a98:      	mov	w1, #0x2d               // =45
    5a9c:      	stp	x9, x10, [sp, #0x18]
    5aa0:      	ldr	x9, [x8, #0x20]
    5aa4:      	add	x10, sp, #0x8
    5aa8:      	str	x9, [sp, #0x28]
    5aac:      	ldur	x9, [x8, #0x25]
    5ab0:      	stur	x9, [sp, #0x2d]
    5ab4:      	ldp	x9, x8, [x8]
    5ab8:      	stp	x9, x8, [sp, #0x8]
    5abc:      	mov	w8, #0x2d               // =45
    5ac0:      	mov	w9, #0x6                // =6
    5ac4:      	blr	x9
    5ac8:      	b	0x5c0c <kprobe_unwind_ruby+0x5c0c>
    5acc:      	ldr	w8, [x23]
    5ad0:      	cmp	w8, w24
    5ad4:      	b.lo	0x5c0c <kprobe_unwind_ruby+0x5c0c>
    5ad8:      	ldr	x8, [sp, #0x78]
    5adc:      	ldrb	w9, [x23, #0x1d]
    5ae0:      	mov	w10, #0x70              // =112
    5ae4:      	add	x11, sp, #0x50
    5ae8:      	add	x0, sp, #0x50
    5aec:      	mov	w1, #0x8                // =8
    5af0:      	str	xzr, [sp, #0x50]
    5af4:      	add	x8, x8, x9
    5af8:      	mov	w9, #0x8                // =8
    5afc:      	ldr	x8, [sp, #0x78]
    5b00:      	ldrb	w9, [x23, #0x1d]
    5b04:      	add	x2, x8, x9
    5b08:      	blr	x10
    5b0c:      	adrp	x25, 0x5000 <kprobe_unwind_ruby+0x5000>
    5b10:      	mov	x20, x29
    5b14:      	ldr	x25, [x25]
    5b18:      	cbnz	x0, 0x9a8 <kprobe_unwind_ruby+0x9a8>
    5b1c:      	ldr	w8, [sp, #0x50]
    5b20:      	mov	w9, #0x140              // =320
    5b24:      	mvn	w8, w8
    5b28:      	tst	x8, x9
    5b2c:      	b.ne	0xb0c <kprobe_unwind_ruby+0xb0c>
    5b30:      	b	0x5c0c <kprobe_unwind_ruby+0x5c0c>
    5b34:      	ldr	w9, [x22, #0x2c0]
    5b38:      	adrp	x25, 0x5000 <kprobe_unwind_ruby+0x5000>
    5b3c:      	ldr	x25, [x25]
    5b40:      	cmp	w9, #0x7e
    5b44:      	b.hi	0xea8 <kprobe_unwind_ruby+0xea8>
    5b48:      	ldr	x10, [sp, #0x68]
    5b4c:      	add	w11, w9, #0x1
    5b50:      	str	wzr, [sp, #0x50]
    5b54:      	mov	x0, x29
    5b58:      	add	x1, sp, #0x50
    5b5c:      	strh	wzr, [sp, #0x54]
    5b60:      	str	w11, [x22, #0x2c0]
    5b64:      	mov	w11, #0x18              // =24
    5b68:      	umaddl	x9, w9, w11, x22
    5b6c:      	str	x10, [x9, #0x2d0]
    5b70:      	mov	w10, #0x6               // =6
    5b74:      	str	x8, [x9, #0x2d8]
    5b78:      	add	x8, x9, #0x2d0
    5b7c:      	strh	w10, [x9, #0x2e0]
    5b80:      	ldr	w11, [sp, #0x50]
    5b84:      	ldrh	w10, [sp, #0x54]
    5b88:      	stur	w11, [x8, #0x12]
    5b8c:      	mov	w8, #0x36               // =54
    5b90:      	strh	w10, [x9, #0x2e6]
    5b94:      	add	x9, sp, #0x50
    5b98:      	str	w8, [sp, #0x50]
    5b9c:      	mov	w8, #0x1                // =1
    5ba0:      	blr	x8
    5ba4:      	cbz	x0, 0x5bb8 <kprobe_unwind_ruby+0x5bb8>
    5ba8:      	ldr	x8, [x0]
    5bac:      	add	x8, x8, #0x1
    5bb0:      	str	x8, [x0]
    5bb4:      	b	0x5c0c <kprobe_unwind_ruby+0x5c0c>
    5bb8:      	adrp	x8, 0x5000 <kprobe_unwind_ruby+0x5000>
    5bbc:      	ldr	x8, [x8]
    5bc0:      	ldr	w8, [x8]
    5bc4:      	cbz	w8, 0x5c0c <kprobe_unwind_ruby+0x5c0c>
    5bc8:      	adrp	x8, 0x5000 <kprobe_unwind_ruby+0x5000>
    5bcc:      	add	x8, x8, #0x0
    5bd0:      	add	x0, sp, #0x8
    5bd4:      	ldp	x9, x10, [x8, #0x10]
    5bd8:      	mov	w1, #0x2e               // =46
    5bdc:      	stp	x9, x10, [sp, #0x18]
    5be0:      	ldr	x9, [x8, #0x20]
    5be4:      	add	x10, sp, #0x8
    5be8:      	str	x9, [sp, #0x28]
    5bec:      	ldur	x9, [x8, #0x26]
    5bf0:      	stur	x9, [sp, #0x2e]
    5bf4:      	ldp	x9, x8, [x8]
    5bf8:      	stp	x9, x8, [sp, #0x8]
    5bfc:      	mov	w8, #0x2e               // =46
    5c00:      	mov	w9, #0x6                // =6
    5c04:      	ldr	w2, [sp, #0x50]
    5c08:      	blr	x9
    5c0c:      	ldr	x8, [sp, #0x78]
    5c10:      	ldr	x9, [sp]
    5c14:      	cmp	x9, x8
    5c18:      	b.ls	0x5c3c <kprobe_unwind_ruby+0x5c3c>
    5c1c:      	ldrb	w9, [x23, #0x1e]
    5c20:      	adrp	x25, 0x5000 <kprobe_unwind_ruby+0x5000>
    5c24:      	mov	w24, #0x6               // =6
    5c28:      	mov	x20, x29
    5c2c:      	add	x9, x8, x9
    5c30:      	str	x9, [sp, #0x78]
    5c34:      	ldr	x25, [x25]
    5c38:      	b	0xb20 <kprobe_unwind_ruby+0xb20>
    5c3c:      	adrp	x25, 0x5000 <kprobe_unwind_ruby+0x5000>
    5c40:      	mov	w8, wzr
    5c44:      	mov	w24, #0x1               // =1
    5c48:      	ldr	x25, [x25]
    5c4c:      	mov	x20, x29
    5c50:      	b	0x2c0 <kprobe_unwind_ruby+0x2c0>
