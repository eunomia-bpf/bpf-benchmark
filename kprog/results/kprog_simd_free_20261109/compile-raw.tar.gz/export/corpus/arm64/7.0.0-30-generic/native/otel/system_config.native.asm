
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/otel/system_config.native.o:	file format elf64-littleaarch64

Disassembly of section tracepoint/syscalls/sys_enter_bpf:

0000000000000000 <read_kernel_memory>:
       0:      	sub	sp, sp, #0x40
       4:      	str	x30, [sp, #0x20]
       8:      	stp	x20, x19, [sp, #0x30]
       c:      	str	wzr, [sp, #0x2c]
      10:      	adrp	x0, 0x0 <read_kernel_memory>
      14:      	mov	w8, #0x1                // =1
      18:      	add	x9, sp, #0x2c
      1c:      	ldr	x0, [x0]
      20:      	add	x1, sp, #0x2c
      24:      	blr	x8
      28:      	cbz	x0, 0x7c <read_kernel_memory+0x7c>
      2c:      	ldr	w20, [x0, #0x8]
      30:      	mov	w8, #0xe                // =14
      34:      	mov	x19, x0
      38:      	blr	x8
      3c:      	cmp	x20, x0, lsr #32
      40:      	b.ne	0x8c <read_kernel_memory+0x8c>
      44:      	str	wzr, [x19, #0x8]
      48:      	add	x0, x19, #0xc
      4c:      	ldr	x8, [x19]
      50:      	mov	w9, #0x80               // =128
      54:      	mov	w10, #0x71              // =113
      58:      	mov	w1, #0x80               // =128
      5c:      	ldr	x2, [x19]
      60:      	blr	x10
      64:      	cbz	x0, 0x7c <read_kernel_memory+0x7c>
      68:      	adrp	x8, 0x0 <read_kernel_memory>
      6c:      	ldr	x8, [x8]
      70:      	ldr	w8, [x8]
      74:      	cbnz	w8, 0xa0 <read_kernel_memory+0xa0>
      78:      	mov	w0, #-0x1               // =-1
      7c:      	ldp	x20, x19, [sp, #0x30]
      80:      	ldr	x30, [sp, #0x20]
      84:      	add	sp, sp, #0x40
      88:      	ret
      8c:      	mov	w0, wzr
      90:      	ldp	x20, x19, [sp, #0x30]
      94:      	ldr	x30, [sp, #0x20]
      98:      	add	sp, sp, #0x40
      9c:      	ret
      a0:      	adrp	x8, 0x0 <read_kernel_memory>
      a4:      	add	x8, x8, #0x0
      a8:      	mov	x0, sp
      ac:      	ldp	x9, x10, [x8]
      b0:      	mov	w1, #0x20               // =32
      b4:      	stp	x9, x10, [sp]
      b8:      	ldp	x9, x8, [x8, #0x10]
      bc:      	mov	x10, sp
      c0:      	stp	x9, x8, [sp, #0x10]
      c4:      	mov	w8, #0x20               // =32
      c8:      	mov	w9, #0x6                // =6
      cc:      	ldr	x2, [x19]
      d0:      	blr	x9
      d4:      	b	0x78 <read_kernel_memory+0x78>

Disassembly of section raw_tracepoint/sys_enter:

0000000000000000 <read_task_struct>:
       0:      	sub	sp, sp, #0x50
       4:      	stp	x30, x21, [sp, #0x30]
       8:      	stp	x20, x19, [sp, #0x40]
       c:      	ldr	x21, [x0]
      10:      	str	wzr, [sp, #0x2c]
      14:      	adrp	x0, 0x0 <read_task_struct>
      18:      	mov	w8, #0x1                // =1
      1c:      	add	x9, sp, #0x2c
      20:      	add	x1, sp, #0x2c
      24:      	ldr	x0, [x0]
      28:      	blr	x8
      2c:      	cbz	x0, 0x90 <read_task_struct+0x90>
      30:      	ldr	w19, [x0, #0x8]
      34:      	mov	w8, #0xe                // =14
      38:      	mov	x20, x0
      3c:      	blr	x8
      40:      	cmp	x19, x0, lsr #32
      44:      	b.ne	0xa0 <read_task_struct+0xa0>
      48:      	str	wzr, [x20, #0x8]
      4c:      	mov	w8, #0x23               // =35
      50:      	blr	x8
      54:      	ldr	x8, [x20]
      58:      	str	x21, [x20]
      5c:      	mov	w9, #0x71               // =113
      60:      	mov	w1, #0x80               // =128
      64:      	add	x19, x8, x0
      68:      	add	x0, x20, #0xc
      6c:      	mov	w8, #0x80               // =128
      70:      	mov	x2, x19
      74:      	blr	x9
      78:      	cbz	x0, 0x90 <read_task_struct+0x90>
      7c:      	adrp	x8, 0x0 <read_task_struct>
      80:      	ldr	x8, [x8]
      84:      	ldr	w8, [x8]
      88:      	cbnz	w8, 0xb4 <read_task_struct+0xb4>
      8c:      	mov	w0, #-0x1               // =-1
      90:      	ldp	x20, x19, [sp, #0x40]
      94:      	ldp	x30, x21, [sp, #0x30]
      98:      	add	sp, sp, #0x50
      9c:      	ret
      a0:      	mov	w0, wzr
      a4:      	ldp	x20, x19, [sp, #0x40]
      a8:      	ldp	x30, x21, [sp, #0x30]
      ac:      	add	sp, sp, #0x50
      b0:      	ret
      b4:      	adrp	x8, 0x0 <read_task_struct>
      b8:      	add	x8, x8, #0x0
      bc:      	mov	x0, sp
      c0:      	ldp	x9, x10, [x8, #0x10]
      c4:      	mov	w1, #0x27               // =39
      c8:      	mov	x2, x19
      cc:      	stp	x9, x10, [sp, #0x10]
      d0:      	ldur	x9, [x8, #0x1f]
      d4:      	mov	x10, sp
      d8:      	stur	x9, [sp, #0x1f]
      dc:      	ldp	x8, x9, [x8]
      e0:      	stp	x8, x9, [sp]
      e4:      	mov	w8, #0x27               // =39
      e8:      	mov	w9, #0x6                // =6
      ec:      	blr	x9
      f0:      	b	0x8c <read_task_struct+0x8c>
