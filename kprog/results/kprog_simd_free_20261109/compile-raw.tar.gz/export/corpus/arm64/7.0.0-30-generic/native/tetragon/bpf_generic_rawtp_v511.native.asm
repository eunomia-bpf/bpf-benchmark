
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_rawtp_v511.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	cbz	x2, 0x8c <native_bpf_strncasestr+0x8c>
       4:      	mov	x8, x0
       8:      	mov	x0, xzr
       c:      	mov	x9, x2
      10:      	b	0x34 <native_bpf_strncasestr+0x34>
      14:      	nop
      18:      	nop
      1c:      	nop
      20:      	add	x0, x0, #0x1
      24:      	sub	x9, x9, #0x1
      28:      	add	x8, x8, #0x1
      2c:      	cmp	x0, x2
      30:      	b.eq	0x8c <native_bpf_strncasestr+0x8c>
      34:      	mov	x10, xzr
      38:      	nop
      3c:      	nop
      40:      	cmp	x9, x10
      44:      	b.eq	0x20 <native_bpf_strncasestr+0x20>
      48:      	ldrb	w11, [x1, x10]
      4c:      	cbz	w11, 0x90 <native_bpf_strncasestr+0x90>
      50:      	ldrb	w12, [x8, x10]
      54:      	sub	w13, w12, #0x41
      58:      	orr	w14, w12, #0x20
      5c:      	cmp	w13, #0x1a
      60:      	sub	w13, w11, #0x41
      64:      	csel	w12, w14, w12, lo
      68:      	orr	w14, w11, #0x20
      6c:      	cmp	w13, #0x1a
      70:      	csel	w11, w14, w11, lo
      74:      	cmp	w12, w11
      78:      	b.ne	0x20 <native_bpf_strncasestr+0x20>
      7c:      	cmp	x10, #0x63
      80:      	add	x10, x10, #0x1
      84:      	b.lo	0x40 <native_bpf_strncasestr+0x40>
      88:      	b	0x20 <native_bpf_strncasestr+0x20>
      8c:      	mov	w0, #-0x1               // =-1
      90:      	ret

Disassembly of section raw_tp:

0000000000000000 <generic_rawtp_setup_event>:
       0:      	sub	sp, sp, #0x50
       4:      	str	x30, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	str	wzr, [sp, #0x1c]
      18:      	adrp	x20, 0x0 <generic_rawtp_setup_event>
      1c:      	mov	w8, #0x1                // =1
      20:      	add	x9, sp, #0x1c
      24:      	ldr	x20, [x20]
      28:      	mov	x19, x0
      2c:      	add	x1, sp, #0x1c
      30:      	mov	x0, x20
      34:      	blr	x8
      38:      	cbz	x0, 0x1a8 <generic_rawtp_setup_event+0x1a8>
      3c:      	adrp	x21, 0x0 <generic_rawtp_setup_event>
      40:      	mov	w8, #0x5ef8             // =24312
      44:      	mov	x22, x0
      48:      	ldr	x21, [x21]
      4c:      	add	x1, x0, x8
      50:      	mov	w8, #0x1                // =1
      54:      	mov	x0, x21
      58:      	blr	x8
      5c:      	cbz	x0, 0x1a8 <generic_rawtp_setup_event+0x1a8>
      60:      	mov	w24, #0x8               // =8
      64:      	add	x8, sp, #0x8
      68:      	mov	w9, #0x4                // =4
      6c:      	add	x0, sp, #0x8
      70:      	mov	w1, #0x8                // =8
      74:      	mov	x2, x19
      78:      	mov	w23, #0x4               // =4
      7c:      	blr	x9
      80:      	ldr	x8, [sp, #0x8]
      84:      	add	x2, x19, #0x8
      88:      	mov	w9, #0x4                // =4
      8c:      	add	x0, sp, #0x8
      90:      	str	x8, [x22, #0x5e50]
      94:      	add	x8, sp, #0x8
      98:      	mov	w1, #0x8                // =8
      9c:      	blr	x9
      a0:      	ldr	x8, [sp, #0x8]
      a4:      	add	x2, x19, #0x10
      a8:      	mov	w9, #0x4                // =4
      ac:      	add	x0, sp, #0x8
      b0:      	str	x8, [x22, #0x5e58]
      b4:      	add	x8, sp, #0x8
      b8:      	mov	w1, #0x8                // =8
      bc:      	blr	x9
      c0:      	ldr	x8, [sp, #0x8]
      c4:      	add	x2, x19, #0x18
      c8:      	mov	w9, #0x4                // =4
      cc:      	add	x0, sp, #0x8
      d0:      	str	x8, [x22, #0x5e60]
      d4:      	add	x8, sp, #0x8
      d8:      	mov	w1, #0x8                // =8
      dc:      	blr	x9
      e0:      	ldr	x8, [sp, #0x8]
      e4:      	add	x2, x19, #0x20
      e8:      	add	x0, sp, #0x8
      ec:      	mov	w1, #0x8                // =8
      f0:      	str	x8, [x22, #0x5e68]
      f4:      	add	x8, sp, #0x8
      f8:      	blr	x23
      fc:      	ldr	x8, [sp, #0x8]
     100:      	mov	w23, #0xe               // =14
     104:      	strh	wzr, [x22, #0x2]
     108:      	str	wzr, [x22, #0x4]
     10c:      	strb	w23, [x22]
     110:      	str	x8, [x22, #0x5e70]
     114:      	mov	w8, #0x7d               // =125
     118:      	blr	x8
     11c:      	str	x0, [x22, #0x8]
     120:      	str	xzr, [x22, #0x70]
     124:      	str	wzr, [x22, #0x14]
     128:      	blr	x23
     12c:      	str	w0, [x22, #0x7c]
     130:      	str	wzr, [sp, #0x8]
     134:      	mov	w8, #0x1                // =1
     138:      	add	x9, sp, #0x8
     13c:      	add	x1, sp, #0x8
     140:      	mov	x0, x20
     144:      	blr	x8
     148:      	adrp	x20, 0x0 <generic_rawtp_setup_event>
     14c:      	ldr	x20, [x20]
     150:      	cbz	x0, 0x178 <generic_rawtp_setup_event+0x178>
     154:      	mov	w8, #0x5ef8             // =24312
     158:      	add	x1, x0, x8
     15c:      	mov	w8, #0x1                // =1
     160:      	mov	x0, x21
     164:      	blr	x8
     168:      	cbz	x0, 0x178 <generic_rawtp_setup_event+0x178>
     16c:      	ldr	w8, [x0, #0x40]
     170:      	cmn	w8, #0x1
     174:      	b.ne	0x190 <generic_rawtp_setup_event+0x190>
     178:      	mov	w8, #0x3                // =3
     17c:      	mov	w9, #0xc                // =12
     180:      	mov	x0, x19
     184:      	mov	x1, x20
     188:      	mov	w2, #0x3                // =3
     18c:      	blr	x9
     190:      	mov	w8, #0x1                // =1
     194:      	mov	w9, #0xc                // =12
     198:      	mov	x0, x19
     19c:      	mov	x1, x20
     1a0:      	mov	w2, #0x1                // =1
     1a4:      	blr	x9
     1a8:      	ldp	x20, x19, [sp, #0x40]
     1ac:      	mov	w0, wzr
     1b0:      	ldr	x30, [sp, #0x10]
     1b4:      	ldp	x22, x21, [sp, #0x30]
     1b8:      	ldp	x24, x23, [sp, #0x20]
     1bc:      	add	sp, sp, #0x50
     1c0:      	ret
     1c4:      	nop
     1c8:      	nop
     1cc:      	nop

00000000000001d0 <generic_rawtp_process_event>:
     1d0:      	sub	sp, sp, #0x140
     1d4:      	str	x29, [sp, #0xf0]
     1d8:      	stp	x30, x25, [sp, #0x100]
     1dc:      	stp	x24, x23, [sp, #0x110]
     1e0:      	stp	x22, x21, [sp, #0x120]
     1e4:      	stp	x20, x19, [sp, #0x130]
     1e8:      	str	wzr, [sp, #0x4c]
     1ec:      	adrp	x21, 0x0 <generic_rawtp_setup_event>
     1f0:      	mov	w8, #0x1                // =1
     1f4:      	add	x9, sp, #0x4c
     1f8:      	ldr	x21, [x21]
     1fc:      	mov	x19, x0
     200:      	add	x1, sp, #0x4c
     204:      	mov	x0, x21
     208:      	blr	x8
     20c:      	cbz	x0, 0x3a20 <generic_rawtp_process_event+0x3850>
     210:      	ldr	w24, [x0, #0x4]
     214:      	mov	w22, #0x5efc            // =24316
     218:      	adrp	x29, 0x0 <generic_rawtp_setup_event>
     21c:      	mov	x20, x0
     220:      	ldr	w25, [x0, x22]
     224:      	ldr	x29, [x29]
     228:      	lsr	w8, w24, #3
     22c:      	cmp	w8, #0x464
     230:      	b.hi	0x398c <generic_rawtp_process_event+0x37bc>
     234:      	str	wzr, [sp, #0x58]
     238:      	mov	w8, #0x1                // =1
     23c:      	add	x9, sp, #0x58
     240:      	add	x1, sp, #0x58
     244:      	mov	x0, x21
     248:      	blr	x8
     24c:      	cbz	x0, 0x398c <generic_rawtp_process_event+0x37bc>
     250:      	mov	w8, #0x5ef8             // =24312
     254:      	mov	x23, x0
     258:      	add	x1, x0, x8
     25c:      	adrp	x0, 0x0 <generic_rawtp_setup_event>
     260:      	mov	w8, #0x1                // =1
     264:      	ldr	x0, [x0]
     268:      	blr	x8
     26c:      	cmp	w25, #0x4
     270:      	ccmp	x0, #0x0, #0x4, le
     274:      	b.eq	0x398c <generic_rawtp_process_event+0x37bc>
     278:      	str	x25, [sp, #0x40]
     27c:      	and	x25, x25, #0x7
     280:      	str	x24, [sp, #0xf8]
     284:      	mov	w9, #0x5ea0             // =24224
     288:      	add	x8, x0, x25, lsl #2
     28c:      	ldrsw	x21, [x8, #0x18]
     290:      	ldr	w24, [x8, #0x4]
     294:      	add	x8, x23, x25, lsl #2
     298:      	str	wzr, [x8, x9]
     29c:      	and	x11, x21, #0xffffffff
     2a0:      	tbnz	w21, #0x8, 0x2c8 <generic_rawtp_process_event+0xf8>
     2a4:      	str	x8, [sp, #0x38]
     2a8:      	tbnz	w21, #0x7, 0x2d0 <generic_rawtp_process_event+0x100>
     2ac:      	tbnz	w11, #0x6, 0x2dc <generic_rawtp_process_event+0x10c>
     2b0:      	add	x8, x0, x25, lsl #2
     2b4:      	ldr	w8, [x8, #0x40]
     2b8:      	and	x8, x8, #0x7
     2bc:      	add	x8, x23, x8, lsl #3
     2c0:      	ldr	x8, [x8, #0x5e50]
     2c4:      	b	0x2f8 <generic_rawtp_process_event+0x128>
     2c8:      	str	xzr, [sp, #0x50]
     2cc:      	b	0x8e8 <generic_rawtp_process_event+0x718>
     2d0:      	mov	x8, xzr
     2d4:      	str	xzr, [sp, #0x50]
     2d8:      	b	0x2fc <generic_rawtp_process_event+0x12c>
     2dc:      	mov	w8, #0x23               // =35
     2e0:      	mov	x23, x0
     2e4:      	mov	x22, x11
     2e8:      	blr	x8
     2ec:      	mov	x11, x22
     2f0:      	mov	x8, x0
     2f4:      	mov	x0, x23
     2f8:      	str	x8, [sp, #0x50]
     2fc:      	cmp	w25, #0x4
     300:      	b.hi	0x8e8 <generic_rawtp_process_event+0x718>
     304:      	mov	w9, #0x50               // =80
     308:      	umaddl	x23, w25, w9, x0
     30c:      	ldrh	w9, [x23, #0x76]
     310:      	cbz	w9, 0x8e8 <generic_rawtp_process_event+0x718>
     314:      	adrp	x9, 0x0 <generic_rawtp_setup_event>
     318:      	ldr	x9, [x9]
     31c:      	ldrb	w10, [x9]
     320:      	ldur	w9, [x23, #0x70]
     324:      	add	x8, x8, x9
     328:      	str	x8, [sp, #0x50]
     32c:      	ldurh	w9, [x23, #0x74]
     330:      	cbz	w10, 0x5fc <generic_rawtp_process_event+0x42c>
     334:      	cbz	w9, 0x360 <generic_rawtp_process_event+0x190>
     338:      	mov	w9, #0x8                // =8
     33c:      	mov	w10, #0x4               // =4
     340:      	mov	x22, x11
     344:      	add	x11, sp, #0x50
     348:      	ldr	x2, [sp, #0x50]
     34c:      	add	x0, sp, #0x50
     350:      	mov	w1, #0x8                // =8
     354:      	blr	x10
     358:      	mov	x11, x22
     35c:      	tbnz	w0, #0x1f, 0x8c8 <generic_rawtp_process_event+0x6f8>
     360:      	ldurh	w8, [x23, #0x7e]
     364:      	cbz	w8, 0x8e8 <generic_rawtp_process_event+0x718>
     368:      	ldr	x8, [sp, #0x50]
     36c:      	ldur	w9, [x23, #0x78]
     370:      	add	x8, x8, x9
     374:      	str	x8, [sp, #0x50]
     378:      	ldurh	w9, [x23, #0x7c]
     37c:      	cbz	w9, 0x3a8 <generic_rawtp_process_event+0x1d8>
     380:      	mov	w9, #0x8                // =8
     384:      	mov	w10, #0x4               // =4
     388:      	mov	x22, x11
     38c:      	add	x11, sp, #0x50
     390:      	ldr	x2, [sp, #0x50]
     394:      	add	x0, sp, #0x50
     398:      	mov	w1, #0x8                // =8
     39c:      	blr	x10
     3a0:      	mov	x11, x22
     3a4:      	tbnz	w0, #0x1f, 0x8d0 <generic_rawtp_process_event+0x700>
     3a8:      	ldurh	w8, [x23, #0x86]
     3ac:      	cbz	w8, 0x8e8 <generic_rawtp_process_event+0x718>
     3b0:      	ldr	x8, [sp, #0x50]
     3b4:      	ldur	w9, [x23, #0x80]
     3b8:      	add	x8, x8, x9
     3bc:      	str	x8, [sp, #0x50]
     3c0:      	ldurh	w9, [x23, #0x84]
     3c4:      	cbz	w9, 0x3f0 <generic_rawtp_process_event+0x220>
     3c8:      	mov	w9, #0x8                // =8
     3cc:      	mov	w10, #0x4               // =4
     3d0:      	mov	x22, x11
     3d4:      	add	x11, sp, #0x50
     3d8:      	ldr	x2, [sp, #0x50]
     3dc:      	add	x0, sp, #0x50
     3e0:      	mov	w1, #0x8                // =8
     3e4:      	blr	x10
     3e8:      	mov	x11, x22
     3ec:      	tbnz	w0, #0x1f, 0x8d8 <generic_rawtp_process_event+0x708>
     3f0:      	ldurh	w8, [x23, #0x8e]
     3f4:      	cbz	w8, 0x8e8 <generic_rawtp_process_event+0x718>
     3f8:      	ldr	x8, [sp, #0x50]
     3fc:      	ldur	w9, [x23, #0x88]
     400:      	add	x8, x8, x9
     404:      	str	x8, [sp, #0x50]
     408:      	ldurh	w9, [x23, #0x8c]
     40c:      	cbz	w9, 0x43c <generic_rawtp_process_event+0x26c>
     410:      	mov	w9, #0x8                // =8
     414:      	add	x10, sp, #0x50
     418:      	mov	x22, x11
     41c:      	mov	w11, #0x4               // =4
     420:      	ldr	x2, [sp, #0x50]
     424:      	add	x0, sp, #0x50
     428:      	mov	w1, #0x8                // =8
     42c:      	blr	x11
     430:      	mov	w10, #0x4               // =4
     434:      	mov	x11, x22
     438:      	tbnz	w0, #0x1f, 0x8dc <generic_rawtp_process_event+0x70c>
     43c:      	ldurh	w8, [x23, #0x96]
     440:      	cbz	w8, 0x8e8 <generic_rawtp_process_event+0x718>
     444:      	ldr	x8, [sp, #0x50]
     448:      	ldur	w9, [x23, #0x90]
     44c:      	add	x8, x8, x9
     450:      	str	x8, [sp, #0x50]
     454:      	ldurh	w9, [x23, #0x94]
     458:      	cbz	w9, 0x484 <generic_rawtp_process_event+0x2b4>
     45c:      	mov	w9, #0x8                // =8
     460:      	mov	w10, #0x4               // =4
     464:      	mov	x22, x11
     468:      	add	x11, sp, #0x50
     46c:      	ldr	x2, [sp, #0x50]
     470:      	add	x0, sp, #0x50
     474:      	mov	w1, #0x8                // =8
     478:      	blr	x10
     47c:      	mov	x11, x22
     480:      	tbnz	w0, #0x1f, 0x15c4 <generic_rawtp_process_event+0x13f4>
     484:      	ldurh	w8, [x23, #0x9e]
     488:      	cbz	w8, 0x8e8 <generic_rawtp_process_event+0x718>
     48c:      	ldr	x8, [sp, #0x50]
     490:      	ldur	w9, [x23, #0x98]
     494:      	mov	x22, x11
     498:      	add	x8, x8, x9
     49c:      	str	x8, [sp, #0x50]
     4a0:      	ldurh	w9, [x23, #0x9c]
     4a4:      	cbz	w9, 0x4c8 <generic_rawtp_process_event+0x2f8>
     4a8:      	mov	w9, #0x8                // =8
     4ac:      	mov	w10, #0x4               // =4
     4b0:      	add	x11, sp, #0x50
     4b4:      	ldr	x2, [sp, #0x50]
     4b8:      	add	x0, sp, #0x50
     4bc:      	mov	w1, #0x8                // =8
     4c0:      	blr	x10
     4c4:      	tbnz	w0, #0x1f, 0x17b0 <generic_rawtp_process_event+0x15e0>
     4c8:      	ldurh	w8, [x23, #0xa6]
     4cc:      	mov	x11, x22
     4d0:      	cbz	w8, 0x8e8 <generic_rawtp_process_event+0x718>
     4d4:      	ldr	x8, [sp, #0x50]
     4d8:      	ldur	w9, [x23, #0xa0]
     4dc:      	add	x8, x8, x9
     4e0:      	str	x8, [sp, #0x50]
     4e4:      	ldurh	w9, [x23, #0xa4]
     4e8:      	cbz	w9, 0x50c <generic_rawtp_process_event+0x33c>
     4ec:      	mov	w9, #0x8                // =8
     4f0:      	mov	w10, #0x4               // =4
     4f4:      	add	x11, sp, #0x50
     4f8:      	ldr	x2, [sp, #0x50]
     4fc:      	add	x0, sp, #0x50
     500:      	mov	w1, #0x8                // =8
     504:      	blr	x10
     508:      	tbnz	w0, #0x1f, 0x190c <generic_rawtp_process_event+0x173c>
     50c:      	adrp	x29, 0x0 <generic_rawtp_setup_event>
     510:      	ldurh	w8, [x23, #0xae]
     514:      	mov	x11, x22
     518:      	ldr	x29, [x29]
     51c:      	cbz	w8, 0x8e8 <generic_rawtp_process_event+0x718>
     520:      	ldr	x8, [sp, #0x50]
     524:      	ldur	w9, [x23, #0xa8]
     528:      	add	x8, x8, x9
     52c:      	str	x8, [sp, #0x50]
     530:      	ldurh	w9, [x23, #0xac]
     534:      	cbz	w9, 0x568 <generic_rawtp_process_event+0x398>
     538:      	mov	w29, #0x8               // =8
     53c:      	mov	w9, #0x4                // =4
     540:      	add	x10, sp, #0x50
     544:      	ldr	x2, [sp, #0x50]
     548:      	add	x0, sp, #0x50
     54c:      	mov	w1, #0x8                // =8
     550:      	blr	x9
     554:      	mov	w10, w29
     558:      	adrp	x29, 0x0 <generic_rawtp_setup_event>
     55c:      	mov	x11, x22
     560:      	ldr	x29, [x29]
     564:      	tbnz	w0, #0x1f, 0x8dc <generic_rawtp_process_event+0x70c>
     568:      	ldurh	w8, [x23, #0xb6]
     56c:      	cbz	w8, 0x8e8 <generic_rawtp_process_event+0x718>
     570:      	ldr	x8, [sp, #0x50]
     574:      	ldur	w9, [x23, #0xb0]
     578:      	add	x8, x8, x9
     57c:      	str	x8, [sp, #0x50]
     580:      	ldurh	w9, [x23, #0xb4]
     584:      	cbz	w9, 0x5a8 <generic_rawtp_process_event+0x3d8>
     588:      	mov	w9, #0x8                // =8
     58c:      	mov	w10, #0x4               // =4
     590:      	add	x11, sp, #0x50
     594:      	ldr	x2, [sp, #0x50]
     598:      	add	x0, sp, #0x50
     59c:      	mov	w1, #0x8                // =8
     5a0:      	blr	x10
     5a4:      	tbnz	w0, #0x1f, 0x25c8 <generic_rawtp_process_event+0x23f8>
     5a8:      	adrp	x29, 0x0 <generic_rawtp_setup_event>
     5ac:      	ldurh	w8, [x23, #0xbe]
     5b0:      	mov	x11, x22
     5b4:      	ldr	x29, [x29]
     5b8:      	cbz	w8, 0x8e8 <generic_rawtp_process_event+0x718>
     5bc:      	ldr	x8, [sp, #0x50]
     5c0:      	ldur	w9, [x23, #0xb8]
     5c4:      	add	x8, x8, x9
     5c8:      	str	x8, [sp, #0x50]
     5cc:      	ldurh	w9, [x23, #0xbc]
     5d0:      	cbz	w9, 0x8e8 <generic_rawtp_process_event+0x718>
     5d4:      	mov	w9, #0x8                // =8
     5d8:      	mov	w10, #0x4               // =4
     5dc:      	add	x11, sp, #0x50
     5e0:      	ldr	x2, [sp, #0x50]
     5e4:      	add	x0, sp, #0x50
     5e8:      	mov	w1, #0x8                // =8
     5ec:      	blr	x10
     5f0:      	mov	x11, x22
     5f4:      	tbz	w0, #0x1f, 0x8e8 <generic_rawtp_process_event+0x718>
     5f8:      	b	0x8c0 <generic_rawtp_process_event+0x6f0>
     5fc:      	cbz	w9, 0x628 <generic_rawtp_process_event+0x458>
     600:      	mov	w9, #0x8                // =8
     604:      	mov	w10, #0x4               // =4
     608:      	mov	x22, x11
     60c:      	add	x11, sp, #0x50
     610:      	ldr	x2, [sp, #0x50]
     614:      	add	x0, sp, #0x50
     618:      	mov	w1, #0x8                // =8
     61c:      	blr	x10
     620:      	mov	x11, x22
     624:      	tbnz	w0, #0x1f, 0x8c8 <generic_rawtp_process_event+0x6f8>
     628:      	ldurh	w8, [x23, #0x7e]
     62c:      	cbz	w8, 0x8e8 <generic_rawtp_process_event+0x718>
     630:      	ldr	x8, [sp, #0x50]
     634:      	ldur	w9, [x23, #0x78]
     638:      	add	x8, x8, x9
     63c:      	str	x8, [sp, #0x50]
     640:      	ldurh	w9, [x23, #0x7c]
     644:      	cbz	w9, 0x670 <generic_rawtp_process_event+0x4a0>
     648:      	mov	w9, #0x8                // =8
     64c:      	mov	w10, #0x4               // =4
     650:      	mov	x22, x11
     654:      	add	x11, sp, #0x50
     658:      	ldr	x2, [sp, #0x50]
     65c:      	add	x0, sp, #0x50
     660:      	mov	w1, #0x8                // =8
     664:      	blr	x10
     668:      	mov	x11, x22
     66c:      	tbnz	w0, #0x1f, 0x8d0 <generic_rawtp_process_event+0x700>
     670:      	ldurh	w8, [x23, #0x86]
     674:      	cbz	w8, 0x8e8 <generic_rawtp_process_event+0x718>
     678:      	ldr	x8, [sp, #0x50]
     67c:      	ldur	w9, [x23, #0x80]
     680:      	add	x8, x8, x9
     684:      	str	x8, [sp, #0x50]
     688:      	ldurh	w9, [x23, #0x84]
     68c:      	cbz	w9, 0x6b8 <generic_rawtp_process_event+0x4e8>
     690:      	mov	w9, #0x8                // =8
     694:      	mov	w10, #0x4               // =4
     698:      	mov	x22, x11
     69c:      	add	x11, sp, #0x50
     6a0:      	ldr	x2, [sp, #0x50]
     6a4:      	add	x0, sp, #0x50
     6a8:      	mov	w1, #0x8                // =8
     6ac:      	blr	x10
     6b0:      	mov	x11, x22
     6b4:      	tbnz	w0, #0x1f, 0x8d8 <generic_rawtp_process_event+0x708>
     6b8:      	ldurh	w8, [x23, #0x8e]
     6bc:      	cbz	w8, 0x8e8 <generic_rawtp_process_event+0x718>
     6c0:      	ldr	x8, [sp, #0x50]
     6c4:      	ldur	w9, [x23, #0x88]
     6c8:      	add	x8, x8, x9
     6cc:      	str	x8, [sp, #0x50]
     6d0:      	ldurh	w9, [x23, #0x8c]
     6d4:      	cbz	w9, 0x704 <generic_rawtp_process_event+0x534>
     6d8:      	mov	w9, #0x8                // =8
     6dc:      	add	x10, sp, #0x50
     6e0:      	mov	x22, x11
     6e4:      	mov	w11, #0x4               // =4
     6e8:      	ldr	x2, [sp, #0x50]
     6ec:      	add	x0, sp, #0x50
     6f0:      	mov	w1, #0x8                // =8
     6f4:      	blr	x11
     6f8:      	mov	w10, #0x4               // =4
     6fc:      	mov	x11, x22
     700:      	tbnz	w0, #0x1f, 0x8dc <generic_rawtp_process_event+0x70c>
     704:      	ldurh	w8, [x23, #0x96]
     708:      	cbz	w8, 0x8e8 <generic_rawtp_process_event+0x718>
     70c:      	ldr	x8, [sp, #0x50]
     710:      	ldur	w9, [x23, #0x90]
     714:      	add	x8, x8, x9
     718:      	str	x8, [sp, #0x50]
     71c:      	ldurh	w9, [x23, #0x94]
     720:      	cbz	w9, 0x74c <generic_rawtp_process_event+0x57c>
     724:      	mov	w9, #0x8                // =8
     728:      	mov	w10, #0x4               // =4
     72c:      	mov	x22, x11
     730:      	add	x11, sp, #0x50
     734:      	ldr	x2, [sp, #0x50]
     738:      	add	x0, sp, #0x50
     73c:      	mov	w1, #0x8                // =8
     740:      	blr	x10
     744:      	mov	x11, x22
     748:      	tbnz	w0, #0x1f, 0x15c4 <generic_rawtp_process_event+0x13f4>
     74c:      	ldurh	w8, [x23, #0x9e]
     750:      	cbz	w8, 0x8e8 <generic_rawtp_process_event+0x718>
     754:      	ldr	x8, [sp, #0x50]
     758:      	ldur	w9, [x23, #0x98]
     75c:      	mov	x22, x11
     760:      	add	x8, x8, x9
     764:      	str	x8, [sp, #0x50]
     768:      	ldurh	w9, [x23, #0x9c]
     76c:      	cbz	w9, 0x790 <generic_rawtp_process_event+0x5c0>
     770:      	mov	w9, #0x8                // =8
     774:      	mov	w10, #0x4               // =4
     778:      	add	x11, sp, #0x50
     77c:      	ldr	x2, [sp, #0x50]
     780:      	add	x0, sp, #0x50
     784:      	mov	w1, #0x8                // =8
     788:      	blr	x10
     78c:      	tbnz	w0, #0x1f, 0x17b0 <generic_rawtp_process_event+0x15e0>
     790:      	ldurh	w8, [x23, #0xa6]
     794:      	mov	x11, x22
     798:      	cbz	w8, 0x8e8 <generic_rawtp_process_event+0x718>
     79c:      	ldr	x8, [sp, #0x50]
     7a0:      	ldur	w9, [x23, #0xa0]
     7a4:      	add	x8, x8, x9
     7a8:      	str	x8, [sp, #0x50]
     7ac:      	ldurh	w9, [x23, #0xa4]
     7b0:      	cbz	w9, 0x7d4 <generic_rawtp_process_event+0x604>
     7b4:      	mov	w9, #0x8                // =8
     7b8:      	mov	w10, #0x4               // =4
     7bc:      	add	x11, sp, #0x50
     7c0:      	ldr	x2, [sp, #0x50]
     7c4:      	add	x0, sp, #0x50
     7c8:      	mov	w1, #0x8                // =8
     7cc:      	blr	x10
     7d0:      	tbnz	w0, #0x1f, 0x190c <generic_rawtp_process_event+0x173c>
     7d4:      	adrp	x29, 0x0 <generic_rawtp_setup_event>
     7d8:      	ldurh	w8, [x23, #0xae]
     7dc:      	mov	x11, x22
     7e0:      	ldr	x29, [x29]
     7e4:      	cbz	w8, 0x8e8 <generic_rawtp_process_event+0x718>
     7e8:      	ldr	x8, [sp, #0x50]
     7ec:      	ldur	w9, [x23, #0xa8]
     7f0:      	add	x8, x8, x9
     7f4:      	str	x8, [sp, #0x50]
     7f8:      	ldurh	w9, [x23, #0xac]
     7fc:      	cbz	w9, 0x830 <generic_rawtp_process_event+0x660>
     800:      	mov	w29, #0x8               // =8
     804:      	mov	w9, #0x4                // =4
     808:      	add	x10, sp, #0x50
     80c:      	ldr	x2, [sp, #0x50]
     810:      	add	x0, sp, #0x50
     814:      	mov	w1, #0x8                // =8
     818:      	blr	x9
     81c:      	mov	w10, w29
     820:      	adrp	x29, 0x0 <generic_rawtp_setup_event>
     824:      	mov	x11, x22
     828:      	ldr	x29, [x29]
     82c:      	tbnz	w0, #0x1f, 0x8dc <generic_rawtp_process_event+0x70c>
     830:      	ldurh	w8, [x23, #0xb6]
     834:      	cbz	w8, 0x8e8 <generic_rawtp_process_event+0x718>
     838:      	ldr	x8, [sp, #0x50]
     83c:      	ldur	w9, [x23, #0xb0]
     840:      	add	x8, x8, x9
     844:      	str	x8, [sp, #0x50]
     848:      	ldurh	w9, [x23, #0xb4]
     84c:      	cbz	w9, 0x870 <generic_rawtp_process_event+0x6a0>
     850:      	mov	w9, #0x8                // =8
     854:      	mov	w10, #0x4               // =4
     858:      	add	x11, sp, #0x50
     85c:      	ldr	x2, [sp, #0x50]
     860:      	add	x0, sp, #0x50
     864:      	mov	w1, #0x8                // =8
     868:      	blr	x10
     86c:      	tbnz	w0, #0x1f, 0x25c8 <generic_rawtp_process_event+0x23f8>
     870:      	adrp	x29, 0x0 <generic_rawtp_setup_event>
     874:      	ldurh	w8, [x23, #0xbe]
     878:      	mov	x11, x22
     87c:      	ldr	x29, [x29]
     880:      	cbz	w8, 0x8e8 <generic_rawtp_process_event+0x718>
     884:      	ldr	x8, [sp, #0x50]
     888:      	ldur	w9, [x23, #0xb8]
     88c:      	add	x8, x8, x9
     890:      	str	x8, [sp, #0x50]
     894:      	ldurh	w9, [x23, #0xbc]
     898:      	cbz	w9, 0x8e8 <generic_rawtp_process_event+0x718>
     89c:      	mov	w9, #0x8                // =8
     8a0:      	mov	w10, #0x4               // =4
     8a4:      	add	x11, sp, #0x50
     8a8:      	ldr	x2, [sp, #0x50]
     8ac:      	add	x0, sp, #0x50
     8b0:      	mov	w1, #0x8                // =8
     8b4:      	blr	x10
     8b8:      	mov	x11, x22
     8bc:      	tbz	w0, #0x1f, 0x8e8 <generic_rawtp_process_event+0x718>
     8c0:      	mov	w10, #0xa               // =10
     8c4:      	b	0x8dc <generic_rawtp_process_event+0x70c>
     8c8:      	mov	w10, #0x1               // =1
     8cc:      	b	0x8dc <generic_rawtp_process_event+0x70c>
     8d0:      	mov	w10, #0x2               // =2
     8d4:      	b	0x8dc <generic_rawtp_process_event+0x70c>
     8d8:      	mov	w10, #0x3               // =3
     8dc:      	ldr	x8, [sp, #0x38]
     8e0:      	mov	w9, #0x5ea0             // =24224
     8e4:      	str	w10, [x8, x9]
     8e8:      	mov	x9, #0x8000             // =32768
     8ec:      	mov	w8, #0x1                // =1
     8f0:      	cmp	w24, #0x2a
     8f4:      	add	x22, sp, #0xd0
     8f8:      	movk	x9, #0x101, lsl #16
     8fc:      	lsl	x8, x8, x24
     900:      	movk	x9, #0x420, lsl #32
     904:      	and	x8, x8, x9
     908:      	ccmp	x8, #0x0, #0x4, ls
     90c:      	b.eq	0x9f8 <generic_rawtp_process_event+0x828>
     910:      	str	wzr, [sp, #0xd8]
     914:      	adrp	x0, 0x0 <generic_rawtp_setup_event>
     918:      	ldr	x21, [sp, #0x50]
     91c:      	mov	w8, #0x1                // =1
     920:      	add	x9, sp, #0xd8
     924:      	add	x1, sp, #0xd8
     928:      	ldr	x0, [x0]
     92c:      	blr	x8
     930:      	cbz	x0, 0x9a4 <generic_rawtp_process_event+0x7d4>
     934:      	mov	w8, #0x6420             // =25632
     938:      	mov	x22, x29
     93c:      	mov	x23, x0
     940:      	add	x29, x0, x8
     944:      	ldr	w8, [x29]
     948:      	cbz	w8, 0x9ac <generic_rawtp_process_event+0x7dc>
     94c:      	str	wzr, [x29]
     950:      	adrp	x0, 0x0 <generic_rawtp_setup_event>
     954:      	mov	w8, #0x1                // =1
     958:      	add	x9, sp, #0xd8
     95c:      	ldr	x0, [x0]
     960:      	add	x1, sp, #0xd8
     964:      	blr	x8
     968:      	cbz	x0, 0xa44 <generic_rawtp_process_event+0x874>
     96c:      	add	x8, x23, x25, lsl #2
     970:      	mov	w9, #0x5ea0             // =24224
     974:      	ldr	x24, [sp, #0xf8]
     978:      	add	x11, x23, x25, lsl #3
     97c:      	ldr	w10, [x8, x9]
     980:      	add	x8, x23, #0x90
     984:      	adrp	x21, 0x0 <generic_rawtp_setup_event>
     988:      	add	x9, x24, #0x4
     98c:      	str	w10, [x8, x24]
     990:      	str	x9, [x11, #0x5e78]
     994:      	ldr	x21, [x21]
     998:      	cbz	w10, 0xaa0 <generic_rawtp_process_event+0x8d0>
     99c:      	mov	w8, #0x4                // =4
     9a0:      	b	0xb58 <generic_rawtp_process_event+0x988>
     9a4:      	mov	x8, xzr
     9a8:      	b	0x3974 <generic_rawtp_process_event+0x37a4>
     9ac:      	add	x8, sp, #0xd0
     9b0:      	cmp	w24, #0x17
     9b4:      	str	x21, [sp, #0x88]
     9b8:      	str	xzr, [x8, #0x10]
     9bc:      	b.le	0xa78 <generic_rawtp_process_event+0x8a8>
     9c0:      	ldr	x25, [sp, #0x40]
     9c4:      	cmp	w24, #0x18
     9c8:      	mov	x29, x22
     9cc:      	mov	w22, #0x5efc            // =24316
     9d0:      	b.eq	0xbb4 <generic_rawtp_process_event+0x9e4>
     9d4:      	cmp	w24, #0x25
     9d8:      	b.eq	0xbf8 <generic_rawtp_process_event+0xa28>
     9dc:      	cmp	w24, #0x2a
     9e0:      	b.ne	0xc84 <generic_rawtp_process_event+0xab4>
     9e4:      	mov	w8, #0x6430             // =25648
     9e8:      	str	xzr, [x23, #0x6430]
     9ec:      	str	x21, [x23, #0x6438]
     9f0:      	add	x8, x23, x8
     9f4:      	b	0xc24 <generic_rawtp_process_event+0xa54>
     9f8:      	ldr	x8, [sp, #0x50]
     9fc:      	cmp	w24, #0x15
     a00:      	stp	x11, x8, [sp, #0x30]
     a04:      	b.gt	0xa50 <generic_rawtp_process_event+0x880>
     a08:      	mov	w23, #0x1000            // =4096
     a0c:      	cmp	w24, #0x9
     a10:      	b.le	0xb68 <generic_rawtp_process_event+0x998>
     a14:      	cmp	w24, #0x10
     a18:      	b.le	0xc8c <generic_rawtp_process_event+0xabc>
     a1c:      	cmp	w24, #0x12
     a20:      	b.le	0xd24 <generic_rawtp_process_event+0xb54>
     a24:      	cmp	w24, #0x13
     a28:      	b.eq	0xd1c <generic_rawtp_process_event+0xb4c>
     a2c:      	cmp	w24, #0x14
     a30:      	b.eq	0xd5c <generic_rawtp_process_event+0xb8c>
     a34:      	cmp	w24, #0x15
     a38:      	b.ne	0xd6c <generic_rawtp_process_event+0xb9c>
     a3c:      	mov	w23, #0x20              // =32
     a40:      	b	0xd70 <generic_rawtp_process_event+0xba0>
     a44:      	mov	x8, xzr
     a48:      	mov	x29, x22
     a4c:      	b	0x3974 <generic_rawtp_process_event+0x37a4>
     a50:      	cmp	w24, #0x20
     a54:      	b.le	0xb90 <generic_rawtp_process_event+0x9c0>
     a58:      	cmp	w24, #0x27
     a5c:      	b.gt	0xcb0 <generic_rawtp_process_event+0xae0>
     a60:      	sub	w8, w24, #0x21
     a64:      	cmp	w8, #0x4
     a68:      	b.lo	0xca8 <generic_rawtp_process_event+0xad8>
     a6c:      	cmp	w24, #0x27
     a70:      	b.eq	0xcfc <generic_rawtp_process_event+0xb2c>
     a74:      	b	0xd6c <generic_rawtp_process_event+0xb9c>
     a78:      	ldr	x25, [sp, #0x40]
     a7c:      	add	x21, sp, #0xd0
     a80:      	cmp	w24, #0xf
     a84:      	mov	x29, x22
     a88:      	mov	w22, #0x5efc            // =24316
     a8c:      	b.eq	0xc50 <generic_rawtp_process_event+0xa80>
     a90:      	cmp	w24, #0x10
     a94:      	b.ne	0xc84 <generic_rawtp_process_event+0xab4>
     a98:      	add	x24, sp, #0x60
     a9c:      	b	0xbd8 <generic_rawtp_process_event+0xa08>
     aa0:      	add	x21, x8, x9
     aa4:      	ldr	w8, [x29, #0x4]
     aa8:      	ldr	x25, [x23, #0x6440]
     aac:      	mov	w24, #0x4               // =4
     ab0:      	and	x9, x8, #0xfff
     ab4:      	add	x2, x0, x9
     ab8:      	mov	w9, #0xfff              // =4095
     abc:      	add	x0, x21, #0x4
     ac0:      	sub	w8, w9, w8
     ac4:      	and	w23, w8, #0xfff
     ac8:      	mov	w8, #0x4                // =4
     acc:      	mov	w1, w23
     ad0:      	blr	x8
     ad4:      	str	w23, [x21]
     ad8:      	add	x2, x25, #0x8
     adc:      	mov	w25, #0x8               // =8
     ae0:      	add	x8, sp, #0x88
     ae4:      	mov	w9, #0x4                // =4
     ae8:      	add	x0, sp, #0x88
     aec:      	mov	w1, #0x8                // =8
     af0:      	blr	x9
     af4:      	ldr	x8, [sp, #0x88]
     af8:      	add	x9, sp, #0xe0
     afc:      	mov	w10, #0x4               // =4
     b00:      	add	x0, sp, #0xe0
     b04:      	mov	w1, #0x8                // =8
     b08:      	add	x8, x8, #0x30
     b0c:      	ldr	x8, [sp, #0x88]
     b10:      	add	x2, x8, #0x30
     b14:      	blr	x10
     b18:      	add	x11, sp, #0xd0
     b1c:      	mov	w9, #0x2                // =2
     b20:      	add	x10, sp, #0x60
     b24:      	ldr	x8, [x11, #0x10]
     b28:      	add	x0, sp, #0x60
     b2c:      	mov	w1, #0x2                // =2
     b30:      	ldr	x2, [x11, #0x10]
     b34:      	blr	x24
     b38:      	add	x8, x21, x23
     b3c:      	adrp	x21, 0x0 <generic_rawtp_setup_event>
     b40:      	ldr	x24, [sp, #0xf8]
     b44:      	ldr	x21, [x21]
     b48:      	str	wzr, [x8, #0x4]
     b4c:      	ldrh	w9, [sp, #0x60]
     b50:      	strh	w9, [x8, #0x8]
     b54:      	add	w8, w23, #0xe
     b58:      	ldr	x25, [sp, #0x40]
     b5c:      	mov	x29, x22
     b60:      	mov	w22, #0x5efc            // =24316
     b64:      	b	0x3988 <generic_rawtp_process_event+0x37b8>
     b68:      	cmp	w24, #0x4
     b6c:      	b.gt	0xccc <generic_rawtp_process_event+0xafc>
     b70:      	sub	w8, w24, #0x2
     b74:      	cmp	w8, #0x2
     b78:      	b.lo	0xcf4 <generic_rawtp_process_event+0xb24>
     b7c:      	cmp	w24, #0x1
     b80:      	b.eq	0xcf4 <generic_rawtp_process_event+0xb24>
     b84:      	cmp	w24, #0x4
     b88:      	b.eq	0xca8 <generic_rawtp_process_event+0xad8>
     b8c:      	b	0xd6c <generic_rawtp_process_event+0xb9c>
     b90:      	cmp	w24, #0x1a
     b94:      	b.gt	0xce8 <generic_rawtp_process_event+0xb18>
     b98:      	cmp	w24, #0x16
     b9c:      	b.eq	0xcfc <generic_rawtp_process_event+0xb2c>
     ba0:      	cmp	w24, #0x17
     ba4:      	b.eq	0xca8 <generic_rawtp_process_event+0xad8>
     ba8:      	cmp	w24, #0x1a
     bac:      	b.eq	0xd4c <generic_rawtp_process_event+0xb7c>
     bb0:      	b	0xd6c <generic_rawtp_process_event+0xb9c>
     bb4:      	add	x24, sp, #0x60
     bb8:      	mov	w8, #0x8                // =8
     bbc:      	mov	w9, #0x4                // =4
     bc0:      	ldr	x2, [sp, #0x88]
     bc4:      	add	x0, sp, #0x60
     bc8:      	mov	w1, #0x8                // =8
     bcc:      	blr	x9
     bd0:      	ldr	x8, [sp, #0x60]
     bd4:      	str	x8, [sp, #0x88]
     bd8:      	mov	w8, #0x8                // =8
     bdc:      	mov	w9, #0x4                // =4
     be0:      	add	x10, sp, #0x88
     be4:      	add	x0, sp, #0x60
     be8:      	add	x2, sp, #0x88
     bec:      	mov	w1, #0x8                // =8
     bf0:      	blr	x9
     bf4:      	b	0xc1c <generic_rawtp_process_event+0xa4c>
     bf8:      	add	x8, x21, #0x40
     bfc:      	mov	w9, #0x8                // =8
     c00:      	mov	w10, #0x4               // =4
     c04:      	str	x8, [sp, #0x88]
     c08:      	add	x11, sp, #0x60
     c0c:      	add	x0, sp, #0x60
     c10:      	mov	w1, #0x8                // =8
     c14:      	ldr	x2, [sp, #0x88]
     c18:      	blr	x10
     c1c:      	ldr	x8, [sp, #0x60]
     c20:      	add	x8, x8, #0x40
     c24:      	adrp	x21, 0x0 <generic_rawtp_setup_event>
     c28:      	ldr	x21, [x21]
     c2c:      	str	x8, [x23, #0x6440]
     c30:      	mov	w8, #0x6                // =6
     c34:      	mov	w9, #0xc                // =12
     c38:      	mov	x0, x19
     c3c:      	mov	x1, x29
     c40:      	mov	w2, #0x6                // =6
     c44:      	blr	x9
     c48:      	mov	x8, xzr
     c4c:      	b	0x3984 <generic_rawtp_process_event+0x37b4>
     c50:      	mov	w8, #0x8                // =8
     c54:      	mov	w9, #0x4                // =4
     c58:      	add	x10, sp, #0xe0
     c5c:      	add	x11, sp, #0x88
     c60:      	add	x0, sp, #0xe0
     c64:      	add	x2, sp, #0x88
     c68:      	mov	w1, #0x8                // =8
     c6c:      	blr	x9
     c70:      	ldr	x8, [x21, #0x10]
     c74:      	adrp	x21, 0x0 <generic_rawtp_setup_event>
     c78:      	ldr	x21, [x21]
     c7c:      	cbnz	x8, 0xc2c <generic_rawtp_process_event+0xa5c>
     c80:      	b	0x3984 <generic_rawtp_process_event+0x37b4>
     c84:      	mov	x8, xzr
     c88:      	b	0x397c <generic_rawtp_process_event+0x37ac>
     c8c:      	sub	w8, w24, #0xa
     c90:      	cmp	w8, #0x2
     c94:      	b.lo	0xca8 <generic_rawtp_process_event+0xad8>
     c98:      	sub	w8, w24, #0xc
     c9c:      	cmp	w8, #0x2
     ca0:      	b.lo	0xcf4 <generic_rawtp_process_event+0xb24>
     ca4:      	b	0xd6c <generic_rawtp_process_event+0xb9c>
     ca8:      	mov	w23, #0x8               // =8
     cac:      	b	0xd70 <generic_rawtp_process_event+0xba0>
     cb0:      	cmp	w24, #0x2a
     cb4:      	b.gt	0xd04 <generic_rawtp_process_event+0xb34>
     cb8:      	cmp	w24, #0x28
     cbc:      	b.eq	0xd1c <generic_rawtp_process_event+0xb4c>
     cc0:      	cmp	w24, #0x29
     cc4:      	b.eq	0xd54 <generic_rawtp_process_event+0xb84>
     cc8:      	b	0xd6c <generic_rawtp_process_event+0xb9c>
     ccc:      	cmp	w24, #0x6
     cd0:      	b.gt	0xd3c <generic_rawtp_process_event+0xb6c>
     cd4:      	cmp	w24, #0x5
     cd8:      	b.eq	0xd54 <generic_rawtp_process_event+0xb84>
     cdc:      	cmp	w24, #0x6
     ce0:      	b.eq	0xd70 <generic_rawtp_process_event+0xba0>
     ce4:      	b	0xd6c <generic_rawtp_process_event+0xb9c>
     ce8:      	sub	w8, w24, #0x1d
     cec:      	cmp	w8, #0x4
     cf0:      	b.hs	0xd64 <generic_rawtp_process_event+0xb94>
     cf4:      	mov	w23, #0x4               // =4
     cf8:      	b	0xd70 <generic_rawtp_process_event+0xba0>
     cfc:      	mov	w23, #0x10              // =16
     d00:      	b	0xd70 <generic_rawtp_process_event+0xba0>
     d04:      	cmp	w24, #0x2b
     d08:      	b.eq	0xd1c <generic_rawtp_process_event+0xb4c>
     d0c:      	cmp	w24, #0x2c
     d10:      	b.ne	0xd6c <generic_rawtp_process_event+0xb9c>
     d14:      	mov	w23, #0x70              // =112
     d18:      	b	0xd70 <generic_rawtp_process_event+0xba0>
     d1c:      	mov	w23, #0x18              // =24
     d20:      	b	0xd70 <generic_rawtp_process_event+0xba0>
     d24:      	cmp	w24, #0x11
     d28:      	b.eq	0xd70 <generic_rawtp_process_event+0xba0>
     d2c:      	cmp	w24, #0x12
     d30:      	mov	x23, x21
     d34:      	b.eq	0xd70 <generic_rawtp_process_event+0xba0>
     d38:      	b	0xd6c <generic_rawtp_process_event+0xb9c>
     d3c:      	cmp	w24, #0x7
     d40:      	b.eq	0xd54 <generic_rawtp_process_event+0xb84>
     d44:      	cmp	w24, #0x8
     d48:      	b.ne	0xd6c <generic_rawtp_process_event+0xb9c>
     d4c:      	mov	w23, #0x50              // =80
     d50:      	b	0xd70 <generic_rawtp_process_event+0xba0>
     d54:      	mov	w23, #0x40              // =64
     d58:      	b	0xd70 <generic_rawtp_process_event+0xba0>
     d5c:      	mov	w23, #0x98              // =152
     d60:      	b	0xd70 <generic_rawtp_process_event+0xba0>
     d64:      	cmp	w24, #0x1b
     d68:      	b.eq	0xd4c <generic_rawtp_process_event+0xb7c>
     d6c:      	mov	x23, xzr
     d70:      	str	wzr, [sp, #0x5c]
     d74:      	adrp	x0, 0x0 <generic_rawtp_setup_event>
     d78:      	mov	w8, #0x1                // =1
     d7c:      	add	x9, sp, #0x5c
     d80:      	ldr	x0, [x0]
     d84:      	add	x1, sp, #0x5c
     d88:      	blr	x8
     d8c:      	mov	x8, xzr
     d90:      	cbz	x0, 0x3974 <generic_rawtp_process_event+0x37a4>
     d94:      	ldr	x10, [sp, #0xf8]
     d98:      	mov	w9, #0x3ffb             // =16379
     d9c:      	sub	x9, x9, x23
     da0:      	cmp	x9, x10
     da4:      	b.ls	0x3974 <generic_rawtp_process_event+0x37a4>
     da8:      	add	x12, x0, x25, lsl #2
     dac:      	mov	w8, #0x5ea0             // =24224
     db0:      	ldr	x9, [sp, #0xf8]
     db4:      	add	x10, x0, #0x90
     db8:      	ldr	w8, [x12, x8]
     dbc:      	add	x23, x9, #0x4
     dc0:      	str	w8, [x10, x9]
     dc4:      	add	x9, x0, x25, lsl #3
     dc8:      	str	x23, [x9, #0x5e78]
     dcc:      	cbz	w8, 0xdd8 <generic_rawtp_process_event+0xc08>
     dd0:      	mov	w8, #0x4                // =4
     dd4:      	b	0x3974 <generic_rawtp_process_event+0x37a4>
     dd8:      	ldr	x11, [sp, #0x38]
     ddc:      	add	x8, x10, x23
     de0:      	cmp	w24, #0x17
     de4:      	str	xzr, [x22, #0x10]
     de8:      	str	x12, [sp, #0x28]
     dec:      	stp	x8, x10, [sp, #0x18]
     df0:      	str	x11, [sp, #0x88]
     df4:      	b.le	0xe1c <generic_rawtp_process_event+0xc4c>
     df8:      	cmp	w24, #0x18
     dfc:      	b.eq	0xe34 <generic_rawtp_process_event+0xc64>
     e00:      	cmp	w24, #0x25
     e04:      	b.eq	0xe78 <generic_rawtp_process_event+0xca8>
     e08:      	cmp	w24, #0x2a
     e0c:      	b.ne	0x1520 <generic_rawtp_process_event+0x1350>
     e10:      	stp	xzr, x11, [sp, #0x60]
     e14:      	add	x25, sp, #0x60
     e18:      	b	0xea4 <generic_rawtp_process_event+0xcd4>
     e1c:      	cmp	w24, #0xf
     e20:      	b.eq	0x147c <generic_rawtp_process_event+0x12ac>
     e24:      	cmp	w24, #0x10
     e28:      	b.ne	0x1520 <generic_rawtp_process_event+0x1350>
     e2c:      	add	x21, sp, #0xd8
     e30:      	b	0xe58 <generic_rawtp_process_event+0xc88>
     e34:      	add	x21, sp, #0xd8
     e38:      	mov	w8, #0x8                // =8
     e3c:      	mov	w9, #0x4                // =4
     e40:      	ldr	x2, [sp, #0x88]
     e44:      	add	x0, sp, #0xd8
     e48:      	mov	w1, #0x8                // =8
     e4c:      	blr	x9
     e50:      	ldr	x8, [x22, #0x8]
     e54:      	str	x8, [sp, #0x88]
     e58:      	mov	w8, #0x8                // =8
     e5c:      	mov	w9, #0x4                // =4
     e60:      	add	x10, sp, #0x88
     e64:      	add	x0, sp, #0xd8
     e68:      	add	x2, sp, #0x88
     e6c:      	mov	w1, #0x8                // =8
     e70:      	blr	x9
     e74:      	b	0xe9c <generic_rawtp_process_event+0xccc>
     e78:      	add	x8, x11, #0x40
     e7c:      	mov	w9, #0x8                // =8
     e80:      	mov	w10, #0x4               // =4
     e84:      	str	x8, [sp, #0x88]
     e88:      	add	x11, sp, #0xd8
     e8c:      	add	x0, sp, #0xd8
     e90:      	mov	w1, #0x8                // =8
     e94:      	ldr	x2, [sp, #0x88]
     e98:      	blr	x10
     e9c:      	ldr	x8, [x22, #0x8]
     ea0:      	add	x25, x8, #0x40
     ea4:      	str	wzr, [sp, #0x74]
     ea8:      	adrp	x0, 0x0 <generic_rawtp_setup_event>
     eac:      	mov	w8, #0x1                // =1
     eb0:      	add	x9, sp, #0x74
     eb4:      	ldr	x0, [x0]
     eb8:      	add	x1, sp, #0x74
     ebc:      	blr	x8
     ec0:      	cbz	x0, 0x13d0 <generic_rawtp_process_event+0x1200>
     ec4:      	add	x8, x0, #0x1, lsl #12   // =0x1000
     ec8:      	mov	x24, x0
     ecc:      	str	x8, [sp, #0x30]
     ed0:      	mov	w8, #0x23               // =35
     ed4:      	blr	x8
     ed8:      	add	x2, x0, #0xb30
     edc:      	mov	w29, #0x8               // =8
     ee0:      	add	x8, sp, #0x78
     ee4:      	mov	w9, #0x4                // =4
     ee8:      	add	x0, sp, #0x78
     eec:      	mov	w1, #0x8                // =8
     ef0:      	mov	w21, #0x4               // =4
     ef4:      	blr	x9
     ef8:      	ldr	x8, [sp, #0x78]
     efc:      	add	x2, x25, #0x8
     f00:      	mov	w9, #0x4                // =4
     f04:      	add	x0, sp, #0x80
     f08:      	mov	w1, #0x8                // =8
     f0c:      	mov	x22, x8
     f10:      	add	x8, x8, #0x18
     f14:      	str	x8, [sp, #0x38]
     f18:      	add	x8, sp, #0x80
     f1c:      	str	x2, [sp, #0x10]
     f20:      	blr	x9
     f24:      	ldr	x23, [sp, #0x80]
     f28:      	add	x8, sp, #0x88
     f2c:      	add	x0, sp, #0x88
     f30:      	mov	w1, #0x8                // =8
     f34:      	add	x2, x23, #0x10
     f38:      	blr	x21
     f3c:      	ldr	x8, [sp, #0x88]
     f40:      	str	x25, [sp, #0x8]
     f44:      	cbz	x8, 0xf54 <generic_rawtp_process_event+0xd84>
     f48:      	ldr	x9, [sp, #0x30]
     f4c:      	mov	w8, #0x1000             // =4096
     f50:      	b	0xf9c <generic_rawtp_process_event+0xdcc>
     f54:      	add	x2, x23, #0x18
     f58:      	mov	w8, #0x8                // =8
     f5c:      	mov	w9, #0x4                // =4
     f60:      	add	x10, sp, #0x88
     f64:      	add	x0, sp, #0x88
     f68:      	mov	w1, #0x8                // =8
     f6c:      	blr	x9
     f70:      	ldr	x8, [sp, #0x88]
     f74:      	cmp	x8, x23
     f78:      	b.eq	0xf48 <generic_rawtp_process_event+0xd78>
     f7c:      	mov	w8, #0x2964             // =10596
     f80:      	add	x9, x24, #0xff6
     f84:      	strh	w8, [x24, #0xffe]
     f88:      	adrp	x8, 0x0 <generic_rawtp_setup_event>
     f8c:      	add	x8, x8, #0x0
     f90:      	ldr	x8, [x8]
     f94:      	str	x8, [x9]
     f98:      	mov	w8, #0xff6              // =4086
     f9c:      	stp	xzr, xzr, [sp, #0x88]
     fa0:      	add	x10, sp, #0x88
     fa4:      	add	x2, x22, #0x20
     fa8:      	mov	w21, #0x8               // =8
     fac:      	add	x0, sp, #0x88
     fb0:      	mov	w1, #0x8                // =8
     fb4:      	stp	x24, xzr, [sp, #0x98]
     fb8:      	add	x23, x10, #0x8
     fbc:      	add	x25, x10, #0x18
     fc0:      	stp	xzr, xzr, [sp, #0xa8]
     fc4:      	add	x24, x10, #0x20
     fc8:      	mov	w29, #0x4               // =4
     fcc:      	str	x9, [sp, #0x30]
     fd0:      	str	x9, [sp, #0xb8]
     fd4:      	str	w8, [sp, #0xc0]
     fd8:      	mov	w8, #0x4                // =4
     fdc:      	strb	wzr, [sp, #0xc4]
     fe0:      	blr	x8
     fe4:      	ldr	x2, [sp, #0x38]
     fe8:      	mov	w8, #0x4                // =4
     fec:      	mov	x0, x23
     ff0:      	mov	w1, #0x8                // =8
     ff4:      	blr	x8
     ff8:      	ldr	x2, [sp, #0x10]
     ffc:      	mov	w8, #0x4                // =4
    1000:      	mov	x0, x25
    1004:      	mov	w1, #0x8                // =8
    1008:      	str	x25, [sp, #0x38]
    100c:      	blr	x8
    1010:      	ldr	x2, [sp, #0x8]
    1014:      	mov	x0, x24
    1018:      	mov	w1, #0x8                // =8
    101c:      	blr	x29
    1020:      	ldr	x8, [sp, #0xa8]
    1024:      	sub	x8, x8, #0x20
    1028:      	str	x8, [sp, #0xb0]
    102c:      	adrp	x8, 0x1000 <generic_rawtp_process_event+0xe30>
    1030:      	ldr	x8, [x8]
    1034:      	ldrb	w8, [x8]
    1038:      	cbz	w8, 0x11e0 <generic_rawtp_process_event+0x1010>
    103c:      	adrp	x29, 0x1000 <generic_rawtp_process_event+0xe30>
    1040:      	mov	w21, #0x80              // =128
    1044:      	mov	w23, #0x8               // =8
    1048:      	ldr	x29, [x29]
    104c:      	b	0x1058 <generic_rawtp_process_event+0xe88>
    1050:      	subs	w21, w21, #0x1
    1054:      	b.eq	0x1390 <generic_rawtp_process_event+0x11c0>
    1058:      	ldp	x25, x2, [sp, #0xa0]
    105c:      	ldp	x8, x9, [sp, #0x88]
    1060:      	cmp	x25, x8
    1064:      	ccmp	x2, x9, #0x0, eq
    1068:      	b.eq	0x1388 <generic_rawtp_process_event+0x11b8>
    106c:      	ldr	x24, [sp, #0xb0]
    1070:      	mov	w8, #0x4                // =4
    1074:      	add	x9, sp, #0xc8
    1078:      	add	x0, sp, #0xc8
    107c:      	mov	w1, #0x8                // =8
    1080:      	blr	x8
    1084:      	ldr	x8, [sp, #0xc8]
    1088:      	mov	w22, #0x8               // =8
    108c:      	cmp	x25, x8
    1090:      	b.eq	0x1188 <generic_rawtp_process_event+0xfb8>
    1094:      	add	x23, x25, #0x18
    1098:      	mov	w8, #0x4                // =4
    109c:      	add	x9, sp, #0xd8
    10a0:      	add	x0, sp, #0xd8
    10a4:      	mov	w1, #0x8                // =8
    10a8:      	mov	x2, x23
    10ac:      	blr	x8
    10b0:      	add	x8, sp, #0xd0
    10b4:      	ldr	x8, [x8, #0x8]
    10b8:      	cmp	x8, x25
    10bc:      	b.eq	0x1188 <generic_rawtp_process_event+0xfb8>
    10c0:      	mov	w8, #0x4                // =4
    10c4:      	add	x9, sp, #0xd0
    10c8:      	add	x0, sp, #0xd0
    10cc:      	mov	w1, #0x8                // =8
    10d0:      	mov	x2, x23
    10d4:      	blr	x8
    10d8:      	add	x2, x25, #0x20
    10dc:      	mov	w8, #0x4                // =4
    10e0:      	mov	w9, #0x10               // =16
    10e4:      	add	x10, sp, #0xe0
    10e8:      	add	x0, sp, #0xe0
    10ec:      	mov	w1, #0x10               // =16
    10f0:      	blr	x8
    10f4:      	add	x8, sp, #0xd0
    10f8:      	ldr	w23, [sp, #0xe4]
    10fc:      	ldr	x10, [sp, #0xb8]
    1100:      	add	x22, sp, #0xd0
    1104:      	ldr	w24, [sp, #0xc0]
    1108:      	ldr	x9, [x8, #0x18]
    110c:      	ldr	x8, [sp, #0x98]
    1110:      	sub	x12, x10, x8
    1114:      	subs	w10, w23, w24
    1118:      	csel	w10, wzr, w10, lo
    111c:      	cmp	w24, w23
    1120:      	csel	w11, w24, w23, lo
    1124:      	cinc	w13, w11, hi
    1128:      	sub	w14, w24, w13
    112c:      	subs	x12, x12, x13
    1130:      	str	w14, [sp, #0xc0]
    1134:      	b.lo	0x1390 <generic_rawtp_process_event+0x11c0>
    1138:      	cmp	x12, #0xfff
    113c:      	b.hi	0x1390 <generic_rawtp_process_event+0x11c0>
    1140:      	cmp	w24, w23
    1144:      	b.ls	0x1150 <generic_rawtp_process_event+0xf80>
    1148:      	mov	w13, #0x2f              // =47
    114c:      	strb	w13, [x8, x12]
    1150:      	add	x25, x8, x12
    1154:      	cmp	w24, w23
    1158:      	add	x2, x9, x10
    115c:      	and	w1, w11, #0xff
    1160:      	mov	w8, #0x4                // =4
    1164:      	cinc	x0, x25, hi
    1168:      	blr	x8
    116c:      	cmp	w24, w23
    1170:      	str	x25, [sp, #0xb8]
    1174:      	b.ls	0x1390 <generic_rawtp_process_event+0x11c0>
    1178:      	ldr	x8, [x22]
    117c:      	mov	w23, #0x8               // =8
    1180:      	str	x8, [sp, #0xa0]
    1184:      	b	0x1050 <generic_rawtp_process_event+0xe80>
    1188:      	add	x2, x24, #0x10
    118c:      	mov	w8, #0x4                // =4
    1190:      	add	x9, sp, #0xd8
    1194:      	add	x0, sp, #0xd8
    1198:      	mov	w1, #0x8                // =8
    119c:      	blr	x8
    11a0:      	add	x9, sp, #0xd0
    11a4:      	ldr	x8, [sp, #0xb0]
    11a8:      	mov	w23, #0x8               // =8
    11ac:      	add	x22, sp, #0xd0
    11b0:      	ldr	x9, [x9, #0x8]
    11b4:      	cmp	x8, x9
    11b8:      	b.eq	0x1388 <generic_rawtp_process_event+0x11b8>
    11bc:      	ldr	x0, [sp, #0x38]
    11c0:      	add	x2, x24, #0x18
    11c4:      	mov	w8, #0x4                // =4
    11c8:      	mov	w1, #0x8                // =8
    11cc:      	blr	x8
    11d0:      	ldr	x8, [x22, #0x8]
    11d4:      	add	x9, x8, #0x20
    11d8:      	stp	x9, x8, [sp, #0xa8]
    11dc:      	b	0x1050 <generic_rawtp_process_event+0xe80>
    11e0:      	adrp	x29, 0x1000 <generic_rawtp_process_event+0xe30>
    11e4:      	mov	w21, #0x80              // =128
    11e8:      	mov	w23, #0x8               // =8
    11ec:      	ldr	x29, [x29]
    11f0:      	ldp	x25, x2, [sp, #0xa0]
    11f4:      	ldp	x8, x9, [sp, #0x88]
    11f8:      	cmp	x25, x8
    11fc:      	ccmp	x2, x9, #0x0, eq
    1200:      	b.eq	0x1388 <generic_rawtp_process_event+0x11b8>
    1204:      	ldr	x24, [sp, #0xb0]
    1208:      	mov	w8, #0x4                // =4
    120c:      	add	x9, sp, #0xc8
    1210:      	add	x0, sp, #0xc8
    1214:      	mov	w1, #0x8                // =8
    1218:      	blr	x8
    121c:      	ldr	x8, [sp, #0xc8]
    1220:      	mov	w22, #0x8               // =8
    1224:      	cmp	x25, x8
    1228:      	b.eq	0x1328 <generic_rawtp_process_event+0x1158>
    122c:      	add	x23, x25, #0x18
    1230:      	mov	w8, #0x4                // =4
    1234:      	add	x9, sp, #0xd8
    1238:      	add	x0, sp, #0xd8
    123c:      	mov	w1, #0x8                // =8
    1240:      	mov	x2, x23
    1244:      	blr	x8
    1248:      	add	x8, sp, #0xd0
    124c:      	ldr	x8, [x8, #0x8]
    1250:      	cmp	x8, x25
    1254:      	b.eq	0x1328 <generic_rawtp_process_event+0x1158>
    1258:      	mov	w8, #0x4                // =4
    125c:      	add	x9, sp, #0xd0
    1260:      	add	x0, sp, #0xd0
    1264:      	mov	w1, #0x8                // =8
    1268:      	mov	x2, x23
    126c:      	blr	x8
    1270:      	add	x2, x25, #0x20
    1274:      	mov	w8, #0x4                // =4
    1278:      	mov	w9, #0x10               // =16
    127c:      	add	x10, sp, #0xe0
    1280:      	add	x0, sp, #0xe0
    1284:      	mov	w1, #0x10               // =16
    1288:      	blr	x8
    128c:      	add	x8, sp, #0xd0
    1290:      	ldr	w23, [sp, #0xe4]
    1294:      	ldr	x10, [sp, #0xb8]
    1298:      	add	x22, sp, #0xd0
    129c:      	ldr	w24, [sp, #0xc0]
    12a0:      	ldr	x9, [x8, #0x18]
    12a4:      	ldr	x8, [sp, #0x98]
    12a8:      	sub	x12, x10, x8
    12ac:      	subs	w10, w23, w24
    12b0:      	csel	w10, wzr, w10, lo
    12b4:      	cmp	w24, w23
    12b8:      	csel	w11, w24, w23, lo
    12bc:      	cinc	w13, w11, hi
    12c0:      	sub	w14, w24, w13
    12c4:      	subs	x12, x12, x13
    12c8:      	str	w14, [sp, #0xc0]
    12cc:      	b.lo	0x1390 <generic_rawtp_process_event+0x11c0>
    12d0:      	cmp	x12, #0xfff
    12d4:      	b.hi	0x1390 <generic_rawtp_process_event+0x11c0>
    12d8:      	cmp	w24, w23
    12dc:      	b.ls	0x12e8 <generic_rawtp_process_event+0x1118>
    12e0:      	mov	w13, #0x2f              // =47
    12e4:      	strb	w13, [x8, x12]
    12e8:      	add	x25, x8, x12
    12ec:      	cmp	w24, w23
    12f0:      	add	x2, x9, x10
    12f4:      	and	w1, w11, #0xff
    12f8:      	mov	w8, #0x4                // =4
    12fc:      	cinc	x0, x25, hi
    1300:      	blr	x8
    1304:      	cmp	w24, w23
    1308:      	str	x25, [sp, #0xb8]
    130c:      	b.ls	0x1390 <generic_rawtp_process_event+0x11c0>
    1310:      	ldr	x8, [x22]
    1314:      	mov	w23, #0x8               // =8
    1318:      	str	x8, [sp, #0xa0]
    131c:      	subs	w21, w21, #0x1
    1320:      	b.ne	0x11f0 <generic_rawtp_process_event+0x1020>
    1324:      	b	0x1390 <generic_rawtp_process_event+0x11c0>
    1328:      	add	x2, x24, #0x10
    132c:      	mov	w8, #0x4                // =4
    1330:      	add	x9, sp, #0xd8
    1334:      	add	x0, sp, #0xd8
    1338:      	mov	w1, #0x8                // =8
    133c:      	blr	x8
    1340:      	add	x9, sp, #0xd0
    1344:      	ldr	x8, [sp, #0xb0]
    1348:      	mov	w23, #0x8               // =8
    134c:      	add	x22, sp, #0xd0
    1350:      	ldr	x9, [x9, #0x8]
    1354:      	cmp	x8, x9
    1358:      	b.eq	0x1388 <generic_rawtp_process_event+0x11b8>
    135c:      	ldr	x0, [sp, #0x38]
    1360:      	add	x2, x24, #0x18
    1364:      	mov	w8, #0x4                // =4
    1368:      	mov	w1, #0x8                // =8
    136c:      	blr	x8
    1370:      	ldr	x8, [x22, #0x8]
    1374:      	add	x9, x8, #0x20
    1378:      	stp	x9, x8, [sp, #0xa8]
    137c:      	subs	w21, w21, #0x1
    1380:      	b.ne	0x11f0 <generic_rawtp_process_event+0x1020>
    1384:      	b	0x1390 <generic_rawtp_process_event+0x11c0>
    1388:      	mov	w8, #0x1                // =1
    138c:      	strb	w8, [sp, #0xc4]
    1390:      	ldr	x8, [sp, #0xb8]
    1394:      	ldr	x2, [sp, #0x30]
    1398:      	cmp	x8, x2
    139c:      	b.eq	0x13d8 <generic_rawtp_process_event+0x1208>
    13a0:      	ldrb	w9, [sp, #0xc4]
    13a4:      	mov	w11, #0x1000            // =4096
    13a8:      	cmp	w9, #0x0
    13ac:      	ldr	w9, [sp, #0xc0]
    13b0:      	cset	w10, eq
    13b4:      	sub	w11, w11, w9
    13b8:      	cmp	w9, #0x0
    13bc:      	csel	w9, w11, w9, gt
    13c0:      	cbz	x8, 0x13d0 <generic_rawtp_process_event+0x1200>
    13c4:      	lsl	w21, w10, #1
    13c8:      	mov	x2, x8
    13cc:      	b	0x13e0 <generic_rawtp_process_event+0x1210>
    13d0:      	mov	x25, xzr
    13d4:      	b	0x396c <generic_rawtp_process_event+0x379c>
    13d8:      	mov	w9, wzr
    13dc:      	mov	w21, wzr
    13e0:      	ldr	x22, [sp, #0x18]
    13e4:      	and	w23, w9, #0xfff
    13e8:      	mov	w8, #0x4                // =4
    13ec:      	mov	w24, #0x4               // =4
    13f0:      	mov	w1, w23
    13f4:      	add	x0, x22, #0x4
    13f8:      	blr	x8
    13fc:      	str	w23, [x22]
    1400:      	ldr	x2, [sp, #0x10]
    1404:      	mov	w25, #0x8               // =8
    1408:      	add	x8, sp, #0x88
    140c:      	mov	w9, #0x4                // =4
    1410:      	add	x0, sp, #0x88
    1414:      	mov	w1, #0x8                // =8
    1418:      	blr	x9
    141c:      	ldr	x8, [sp, #0x88]
    1420:      	add	x9, sp, #0xe0
    1424:      	mov	w10, #0x4               // =4
    1428:      	add	x0, sp, #0xe0
    142c:      	mov	w1, #0x8                // =8
    1430:      	add	x8, x8, #0x30
    1434:      	ldr	x8, [sp, #0x88]
    1438:      	add	x2, x8, #0x30
    143c:      	blr	x10
    1440:      	add	x11, sp, #0xd0
    1444:      	mov	w9, #0x2                // =2
    1448:      	add	x10, sp, #0xd8
    144c:      	ldr	x8, [x11, #0x10]
    1450:      	add	x0, sp, #0xd8
    1454:      	mov	w1, #0x2                // =2
    1458:      	ldr	x2, [x11, #0x10]
    145c:      	blr	x24
    1460:      	add	x8, x22, x23
    1464:      	add	w25, w23, #0xa
    1468:      	str	w21, [x8, #0x4]
    146c:      	ldrh	w9, [sp, #0xd8]
    1470:      	strh	w9, [x8, #0x8]
    1474:      	ldp	x10, x12, [sp, #0x20]
    1478:      	b	0x3964 <generic_rawtp_process_event+0x3794>
    147c:      	mov	w8, #0x8                // =8
    1480:      	mov	w9, #0x4                // =4
    1484:      	add	x10, sp, #0xe0
    1488:      	add	x11, sp, #0x88
    148c:      	add	x0, sp, #0xe0
    1490:      	add	x2, sp, #0x88
    1494:      	mov	w1, #0x8                // =8
    1498:      	blr	x9
    149c:      	ldr	x25, [x22, #0x10]
    14a0:      	cbnz	x25, 0xea4 <generic_rawtp_process_event+0xcd4>
    14a4:      	str	wzr, [sp, #0x80]
    14a8:      	adrp	x0, 0x1000 <generic_rawtp_process_event+0xe30>
    14ac:      	mov	w8, #0x1                // =1
    14b0:      	add	x9, sp, #0x80
    14b4:      	ldr	x0, [x0]
    14b8:      	add	x1, sp, #0x80
    14bc:      	blr	x8
    14c0:      	mov	x25, xzr
    14c4:      	cbz	x0, 0x395c <generic_rawtp_process_event+0x378c>
    14c8:      	cmp	w24, #0x19
    14cc:      	b.gt	0x17bc <generic_rawtp_process_event+0x15ec>
    14d0:      	add	x9, sp, #0xd0
    14d4:      	cmp	w24, #0x12
    14d8:      	str	x0, [sp, #0x10]
    14dc:      	b.le	0x18b0 <generic_rawtp_process_event+0x16e0>
    14e0:      	cmp	w24, #0x14
    14e4:      	b.le	0x1b90 <generic_rawtp_process_event+0x19c0>
    14e8:      	cmp	w24, #0x15
    14ec:      	b.eq	0x2388 <generic_rawtp_process_event+0x21b8>
    14f0:      	cmp	w24, #0x16
    14f4:      	b.eq	0x2328 <generic_rawtp_process_event+0x2158>
    14f8:      	adrp	x29, 0x1000 <generic_rawtp_process_event+0xe30>
    14fc:      	cmp	w24, #0x17
    1500:      	ldr	x29, [x29]
    1504:      	ldr	x12, [sp, #0x28]
    1508:      	b.ne	0x3960 <generic_rawtp_process_event+0x3790>
    150c:      	ldr	x8, [sp, #0x18]
    1510:      	ldr	x9, [sp, #0x38]
    1514:      	mov	w25, #0x8               // =8
    1518:      	stp	w9, wzr, [x8]
    151c:      	b	0x3960 <generic_rawtp_process_event+0x3790>
    1520:      	cmp	w24, #0x2c
    1524:      	b.hi	0x14a4 <generic_rawtp_process_event+0x12d4>
    1528:      	mov	x9, #0x7cf2             // =31986
    152c:      	mov	w8, #0x1                // =1
    1530:      	movk	x9, #0xf202, lsl #16
    1534:      	lsl	x8, x8, x24
    1538:      	movk	x9, #0x11c1, lsl #32
    153c:      	tst	x8, x9
    1540:      	b.eq	0x14a4 <generic_rawtp_process_event+0x12d4>
    1544:      	str	x11, [x22]
    1548:      	str	wzr, [sp, #0x80]
    154c:      	adrp	x0, 0x1000 <generic_rawtp_process_event+0xe30>
    1550:      	mov	w8, #0x1                // =1
    1554:      	add	x9, sp, #0x80
    1558:      	add	x1, sp, #0x80
    155c:      	ldr	x0, [x0]
    1560:      	blr	x8
    1564:      	mov	x25, xzr
    1568:      	cbz	x0, 0x1474 <generic_rawtp_process_event+0x12a4>
    156c:      	ldr	x12, [sp, #0x28]
    1570:      	cmp	w24, #0x10
    1574:      	b.le	0x15cc <generic_rawtp_process_event+0x13fc>
    1578:      	add	x11, sp, #0xd0
    157c:      	cmp	w24, #0x1e
    1580:      	b.le	0x16e8 <generic_rawtp_process_event+0x1518>
    1584:      	mov	x21, x29
    1588:      	cmp	w24, #0x26
    158c:      	b.gt	0x17ec <generic_rawtp_process_event+0x161c>
    1590:      	sub	w8, w24, #0x1f
    1594:      	cmp	w8, #0x2
    1598:      	b.hs	0x1c48 <generic_rawtp_process_event+0x1a78>
    159c:      	ldr	x0, [sp, #0x18]
    15a0:      	mov	w8, #0x1                // =1
    15a4:      	add	x9, sp, #0xd0
    15a8:      	mov	w10, #0x4               // =4
    15ac:      	add	x2, sp, #0xd0
    15b0:      	mov	w1, #0x1                // =1
    15b4:      	mov	w25, #0x4               // =4
    15b8:      	blr	x10
    15bc:      	mov	x29, x21
    15c0:      	b	0x395c <generic_rawtp_process_event+0x378c>
    15c4:      	mov	w10, #0x5               // =5
    15c8:      	b	0x8dc <generic_rawtp_process_event+0x70c>
    15cc:      	cmp	w24, #0x9
    15d0:      	b.gt	0x170c <generic_rawtp_process_event+0x153c>
    15d4:      	cmp	w24, #0x4
    15d8:      	b.le	0x1944 <generic_rawtp_process_event+0x1774>
    15dc:      	cmp	w24, #0x5
    15e0:      	b.eq	0x1f48 <generic_rawtp_process_event+0x1d78>
    15e4:      	cmp	w24, #0x6
    15e8:      	b.eq	0x1774 <generic_rawtp_process_event+0x15a4>
    15ec:      	adrp	x29, 0x1000 <generic_rawtp_process_event+0xe30>
    15f0:      	cmp	w24, #0x7
    15f4:      	mov	w9, #0x5ea0             // =24224
    15f8:      	ldr	x29, [x29]
    15fc:      	ldp	x10, x12, [sp, #0x20]
    1600:      	b.ne	0x3968 <generic_rawtp_process_event+0x3798>
    1604:      	add	x8, sp, #0xd0
    1608:      	ldr	x22, [sp, #0x18]
    160c:      	mov	x21, x0
    1610:      	mov	w25, #0x2               // =2
    1614:      	ldr	x23, [x8]
    1618:      	mov	w8, #0x4                // =4
    161c:      	mov	w1, #0x2                // =2
    1620:      	mov	w24, #0x4               // =4
    1624:      	str	x23, [x22, #0x28]
    1628:      	add	x0, x22, #0x26
    162c:      	add	x2, x23, #0x10
    1630:      	blr	x8
    1634:      	add	x0, x22, #0x3a
    1638:      	add	x2, x23, #0x12
    163c:      	mov	w8, #0x1                // =1
    1640:      	mov	w9, #0x4                // =4
    1644:      	mov	w1, #0x1                // =1
    1648:      	blr	x9
    164c:      	add	x0, x22, #0x38
    1650:      	add	x2, x23, #0x21e
    1654:      	mov	w8, #0x4                // =4
    1658:      	mov	w1, #0x2                // =2
    165c:      	blr	x8
    1660:      	add	x0, x22, #0x24
    1664:      	add	x2, x23, #0x21c
    1668:      	mov	w8, #0x4                // =4
    166c:      	mov	w1, #0x2                // =2
    1670:      	blr	x8
    1674:      	add	x0, x22, #0x30
    1678:      	add	x2, x23, #0x214
    167c:      	mov	w8, #0x4                // =4
    1680:      	mov	w1, #0x4                // =4
    1684:      	blr	x8
    1688:      	add	x0, x22, #0x34
    168c:      	add	x2, x23, #0x210
    1690:      	mov	w1, #0x4                // =4
    1694:      	blr	x24
    1698:      	ldrh	w8, [x22, #0x26]
    169c:      	mov	x24, x22
    16a0:      	stp	xzr, xzr, [x22]
    16a4:      	cmp	w8, #0xa
    16a8:      	str	xzr, [x22, #0x18]
    16ac:      	str	xzr, [x24, #0x10]!
    16b0:      	b.eq	0x2660 <generic_rawtp_process_event+0x2490>
    16b4:      	cmp	w8, #0x2
    16b8:      	b.ne	0x268c <generic_rawtp_process_event+0x24bc>
    16bc:      	ldr	x0, [sp, #0x18]
    16c0:      	add	x2, x23, #0x4
    16c4:      	mov	w8, #0x4                // =4
    16c8:      	mov	w1, #0x4                // =4
    16cc:      	mov	w25, #0x4               // =4
    16d0:      	blr	x8
    16d4:      	mov	x0, x24
    16d8:      	mov	w1, #0x4                // =4
    16dc:      	mov	x2, x23
    16e0:      	blr	x25
    16e4:      	b	0x268c <generic_rawtp_process_event+0x24bc>
    16e8:      	cmp	w24, #0x1c
    16ec:      	str	x0, [sp, #0x38]
    16f0:      	b.gt	0x1920 <generic_rawtp_process_event+0x1750>
    16f4:      	cmp	w24, #0x11
    16f8:      	b.eq	0x1c80 <generic_rawtp_process_event+0x1ab0>
    16fc:      	cmp	w24, #0x19
    1700:      	b.eq	0x1d34 <generic_rawtp_process_event+0x1b64>
    1704:      	cmp	w24, #0x1c
    1708:      	b	0x1958 <generic_rawtp_process_event+0x1788>
    170c:      	sub	w8, w24, #0xa
    1710:      	cmp	w8, #0x2
    1714:      	b.lo	0x1964 <generic_rawtp_process_event+0x1794>
    1718:      	sub	w8, w24, #0xc
    171c:      	cmp	w8, #0x2
    1720:      	b.lo	0x1990 <generic_rawtp_process_event+0x17c0>
    1724:      	adrp	x29, 0x1000 <generic_rawtp_process_event+0xe30>
    1728:      	cmp	w24, #0xe
    172c:      	mov	w9, #0x5ea0             // =24224
    1730:      	ldr	x29, [x29]
    1734:      	ldp	x10, x12, [sp, #0x20]
    1738:      	b.ne	0x3968 <generic_rawtp_process_event+0x3798>
    173c:      	mov	w21, #0x8               // =8
    1740:      	add	x8, sp, #0x88
    1744:      	add	x24, sp, #0xd0
    1748:      	mov	w9, #0x4                // =4
    174c:      	add	x0, sp, #0x88
    1750:      	add	x2, sp, #0xd0
    1754:      	mov	w1, #0x8                // =8
    1758:      	mov	w23, #0x4               // =4
    175c:      	blr	x9
    1760:      	ldr	x8, [sp, #0x88]
    1764:      	add	x0, sp, #0xd0
    1768:      	mov	w1, #0x8                // =8
    176c:      	ldr	x2, [sp, #0x88]
    1770:      	blr	x23
    1774:      	add	x8, sp, #0xd0
    1778:      	mov	w9, #0x2d               // =45
    177c:      	mov	w1, #0x1001             // =4097
    1780:      	ldr	x2, [x8]
    1784:      	ldr	x8, [sp, #0x18]
    1788:      	add	x0, x8, #0x4
    178c:      	mov	w8, #0x1001             // =4097
    1790:      	blr	x9
    1794:      	mov	x25, x0
    1798:      	tbnz	x0, #0x3f, 0x3954 <generic_rawtp_process_event+0x3784>
    179c:      	ldr	x9, [sp, #0x18]
    17a0:      	sub	w8, w25, #0x1
    17a4:      	add	x25, x25, #0x3
    17a8:      	str	w8, [x9]
    17ac:      	b	0x3954 <generic_rawtp_process_event+0x3784>
    17b0:      	mov	w10, #0x6               // =6
    17b4:      	mov	x11, x22
    17b8:      	b	0x8dc <generic_rawtp_process_event+0x70c>
    17bc:      	cmp	w24, #0x20
    17c0:      	b.le	0x1ad0 <generic_rawtp_process_event+0x1900>
    17c4:      	sub	w8, w24, #0x21
    17c8:      	cmp	w8, #0x4
    17cc:      	b.hs	0x19b0 <generic_rawtp_process_event+0x17e0>
    17d0:      	ldr	x0, [sp, #0x18]
    17d4:      	ldr	x2, [sp, #0x38]
    17d8:      	mov	w25, #0x8               // =8
    17dc:      	mov	w8, #0x4                // =4
    17e0:      	mov	w1, #0x8                // =8
    17e4:      	blr	x8
    17e8:      	b	0x3954 <generic_rawtp_process_event+0x3784>
    17ec:      	cmp	w24, #0x27
    17f0:      	b.eq	0x20a4 <generic_rawtp_process_event+0x1ed4>
    17f4:      	cmp	w24, #0x28
    17f8:      	b.eq	0x20e4 <generic_rawtp_process_event+0x1f14>
    17fc:      	ldp	x10, x12, [sp, #0x20]
    1800:      	cmp	w24, #0x2c
    1804:      	mov	x29, x21
    1808:      	mov	w9, #0x5ea0             // =24224
    180c:      	b.ne	0x3968 <generic_rawtp_process_event+0x3798>
    1810:      	ldr	x0, [sp, #0x18]
    1814:      	ldr	x23, [x11]
    1818:      	mov	w8, #0x2                // =2
    181c:      	mov	w9, #0x4                // =4
    1820:      	mov	w1, #0x2                // =2
    1824:      	mov	x2, x23
    1828:      	strb	wzr, [sp, #0x88]
    182c:      	stp	xzr, xzr, [x0]
    1830:      	stp	xzr, xzr, [x0, #0x10]
    1834:      	stp	xzr, xzr, [x0, #0x20]
    1838:      	stp	xzr, xzr, [x0, #0x30]
    183c:      	stp	xzr, xzr, [x0, #0x40]
    1840:      	stp	xzr, xzr, [x0, #0x50]
    1844:      	stp	xzr, xzr, [x0, #0x60]
    1848:      	blr	x9
    184c:      	tbnz	x0, #0x3f, 0x2874 <generic_rawtp_process_event+0x26a4>
    1850:      	add	x24, x23, #0x2
    1854:      	mov	w8, #0x1                // =1
    1858:      	mov	w9, #0x4                // =4
    185c:      	add	x10, sp, #0x88
    1860:      	add	x0, sp, #0x88
    1864:      	mov	w1, #0x1                // =1
    1868:      	mov	x2, x24
    186c:      	blr	x9
    1870:      	tbnz	x0, #0x3f, 0x2874 <generic_rawtp_process_event+0x26a4>
    1874:      	ldrb	w8, [sp, #0x88]
    1878:      	ldr	x10, [sp, #0x18]
    187c:      	cmp	w8, #0x0
    1880:      	add	x0, x10, #0x4
    1884:      	cset	w9, eq
    1888:      	strb	w9, [x10, #0x2]
    188c:      	cbz	w8, 0x2854 <generic_rawtp_process_event+0x2684>
    1890:      	mov	w8, #0x6c               // =108
    1894:      	mov	w9, #0x2d               // =45
    1898:      	mov	w1, #0x6c               // =108
    189c:      	mov	x2, x24
    18a0:      	blr	x9
    18a4:      	tbnz	w0, #0x1f, 0x2874 <generic_rawtp_process_event+0x26a4>
    18a8:      	sub	w22, w0, #0x1
    18ac:      	b	0x286c <generic_rawtp_process_event+0x269c>
    18b0:      	cmp	w24, #0x7
    18b4:      	b.gt	0x1b50 <generic_rawtp_process_event+0x1980>
    18b8:      	cmp	w24, #0x2
    18bc:      	b.eq	0x215c <generic_rawtp_process_event+0x1f8c>
    18c0:      	adrp	x29, 0x1000 <generic_rawtp_process_event+0xe30>
    18c4:      	cmp	w24, #0x3
    18c8:      	ldr	x29, [x29]
    18cc:      	ldr	x12, [sp, #0x28]
    18d0:      	b.ne	0x3960 <generic_rawtp_process_event+0x3790>
    18d4:      	ldr	x8, [sp, #0x10]
    18d8:      	add	x24, x8, #0x90
    18dc:      	and	w8, w21, #0xf
    18e0:      	add	x22, x24, x23
    18e4:      	cmp	w8, #0x2
    18e8:      	b.le	0x27e8 <generic_rawtp_process_event+0x2618>
    18ec:      	cmp	w8, #0x3
    18f0:      	b.eq	0x29b0 <generic_rawtp_process_event+0x27e0>
    18f4:      	cmp	w8, #0x4
    18f8:      	b.eq	0x29b8 <generic_rawtp_process_event+0x27e8>
    18fc:      	cmp	w8, #0x5
    1900:      	b.ne	0x2a10 <generic_rawtp_process_event+0x2840>
    1904:      	mov	w9, #0x5e70             // =24176
    1908:      	b	0x29c4 <generic_rawtp_process_event+0x27f4>
    190c:      	mov	w10, #0x7               // =7
    1910:      	adrp	x29, 0x1000 <generic_rawtp_process_event+0xe30>
    1914:      	mov	x11, x22
    1918:      	ldr	x29, [x29]
    191c:      	b	0x8dc <generic_rawtp_process_event+0x70c>
    1920:      	ldr	x0, [sp, #0x18]
    1924:      	mov	w8, #0x2                // =2
    1928:      	add	x9, sp, #0xd0
    192c:      	mov	w10, #0x4               // =4
    1930:      	add	x2, sp, #0xd0
    1934:      	mov	w1, #0x2                // =2
    1938:      	mov	w25, #0x4               // =4
    193c:      	blr	x10
    1940:      	b	0x395c <generic_rawtp_process_event+0x378c>
    1944:      	cmp	w24, #0x1
    1948:      	b.eq	0x1990 <generic_rawtp_process_event+0x17c0>
    194c:      	adrp	x29, 0x1000 <generic_rawtp_process_event+0xe30>
    1950:      	cmp	w24, #0x4
    1954:      	ldr	x29, [x29]
    1958:      	ldp	x10, x12, [sp, #0x20]
    195c:      	mov	w9, #0x5ea0             // =24224
    1960:      	b.ne	0x3968 <generic_rawtp_process_event+0x3798>
    1964:      	ldr	x0, [sp, #0x18]
    1968:      	mov	w25, #0x8               // =8
    196c:      	mov	w8, #0x4                // =4
    1970:      	add	x9, sp, #0xd0
    1974:      	add	x2, sp, #0xd0
    1978:      	mov	w1, #0x8                // =8
    197c:      	mov	x21, x12
    1980:      	blr	x8
    1984:      	ldr	x10, [sp, #0x20]
    1988:      	mov	x12, x21
    198c:      	b	0x3964 <generic_rawtp_process_event+0x3794>
    1990:      	ldr	x0, [sp, #0x18]
    1994:      	add	x8, sp, #0xd0
    1998:      	mov	w9, #0x4                // =4
    199c:      	add	x2, sp, #0xd0
    19a0:      	mov	w1, #0x4                // =4
    19a4:      	mov	w25, #0x4               // =4
    19a8:      	blr	x9
    19ac:      	b	0x3954 <generic_rawtp_process_event+0x3784>
    19b0:      	cmp	w24, #0x2b
    19b4:      	b.eq	0x2444 <generic_rawtp_process_event+0x2274>
    19b8:      	adrp	x29, 0x1000 <generic_rawtp_process_event+0xe30>
    19bc:      	cmp	w24, #0x29
    19c0:      	ldr	x29, [x29]
    19c4:      	ldr	x12, [sp, #0x28]
    19c8:      	b.ne	0x3960 <generic_rawtp_process_event+0x3790>
    19cc:      	ldr	x8, [sp, #0x38]
    19d0:      	mov	w9, #0x4                // =4
    19d4:      	add	x10, sp, #0x88
    19d8:      	mov	x21, x0
    19dc:      	add	x0, sp, #0x88
    19e0:      	mov	w1, #0x8                // =8
    19e4:      	add	x2, x8, #0x18
    19e8:      	mov	w8, #0x8                // =8
    19ec:      	blr	x9
    19f0:      	ldr	x23, [sp, #0x88]
    19f4:      	cbz	x23, 0x296c <generic_rawtp_process_event+0x279c>
    19f8:      	ldr	x22, [sp, #0x18]
    19fc:      	add	x2, x23, #0x10
    1a00:      	mov	w25, #0x2               // =2
    1a04:      	mov	w8, #0x4                // =4
    1a08:      	str	x23, [x22, #0x28]
    1a0c:      	add	x0, x22, #0x26
    1a10:      	mov	w1, #0x2                // =2
    1a14:      	mov	w24, #0x4               // =4
    1a18:      	blr	x8
    1a1c:      	add	x0, x22, #0x3a
    1a20:      	add	x2, x23, #0x12
    1a24:      	mov	w8, #0x1                // =1
    1a28:      	mov	w9, #0x4                // =4
    1a2c:      	mov	w1, #0x1                // =1
    1a30:      	blr	x9
    1a34:      	add	x0, x22, #0x38
    1a38:      	add	x2, x23, #0x21e
    1a3c:      	mov	w8, #0x4                // =4
    1a40:      	mov	w1, #0x2                // =2
    1a44:      	blr	x8
    1a48:      	add	x0, x22, #0x24
    1a4c:      	add	x2, x23, #0x21c
    1a50:      	mov	w8, #0x4                // =4
    1a54:      	mov	w1, #0x2                // =2
    1a58:      	blr	x8
    1a5c:      	add	x0, x22, #0x30
    1a60:      	add	x2, x23, #0x214
    1a64:      	mov	w8, #0x4                // =4
    1a68:      	mov	w1, #0x4                // =4
    1a6c:      	blr	x8
    1a70:      	add	x0, x22, #0x34
    1a74:      	add	x2, x23, #0x210
    1a78:      	mov	w1, #0x4                // =4
    1a7c:      	blr	x24
    1a80:      	ldrh	w8, [x22, #0x26]
    1a84:      	mov	x24, x22
    1a88:      	stp	xzr, xzr, [x22]
    1a8c:      	cmp	w8, #0xa
    1a90:      	str	xzr, [x22, #0x18]
    1a94:      	str	xzr, [x24, #0x10]!
    1a98:      	b.eq	0x28fc <generic_rawtp_process_event+0x272c>
    1a9c:      	cmp	w8, #0x2
    1aa0:      	b.ne	0x2928 <generic_rawtp_process_event+0x2758>
    1aa4:      	ldr	x0, [sp, #0x18]
    1aa8:      	add	x2, x23, #0x4
    1aac:      	mov	w8, #0x4                // =4
    1ab0:      	mov	w1, #0x4                // =4
    1ab4:      	mov	w25, #0x4               // =4
    1ab8:      	blr	x8
    1abc:      	mov	x0, x24
    1ac0:      	mov	w1, #0x4                // =4
    1ac4:      	mov	x2, x23
    1ac8:      	blr	x25
    1acc:      	b	0x2928 <generic_rawtp_process_event+0x2758>
    1ad0:      	cmp	w24, #0x1a
    1ad4:      	b.eq	0x24d4 <generic_rawtp_process_event+0x2304>
    1ad8:      	adrp	x29, 0x1000 <generic_rawtp_process_event+0xe30>
    1adc:      	cmp	w24, #0x1b
    1ae0:      	ldr	x29, [x29]
    1ae4:      	ldr	x12, [sp, #0x28]
    1ae8:      	b.ne	0x3960 <generic_rawtp_process_event+0x3790>
    1aec:      	ldr	x10, [sp, #0x18]
    1af0:      	ldr	x8, [sp, #0x38]
    1af4:      	mov	w9, #0x2d               // =45
    1af8:      	mov	w1, #0x3f               // =63
    1afc:      	mov	x0, x10
    1b00:      	stp	xzr, xzr, [x10, #0x40]
    1b04:      	stp	xzr, xzr, [x10, #0x30]
    1b08:      	stp	xzr, xzr, [x10, #0x20]
    1b0c:      	str	xzr, [x10, #0x18]
    1b10:      	stp	xzr, xzr, [x10]
    1b14:      	add	x2, x8, #0x18
    1b18:      	mov	w8, #0x3f               // =63
    1b1c:      	str	xzr, [x0, #0x10]!
    1b20:      	blr	x9
    1b24:      	tbnz	x0, #0x3f, 0x2718 <generic_rawtp_process_event+0x2548>
    1b28:      	ldr	x8, [sp, #0x18]
    1b2c:      	mov	w9, #0x4                // =4
    1b30:      	mov	w1, #0x8                // =8
    1b34:      	add	x0, x8, #0x8
    1b38:      	ldr	x8, [sp, #0x38]
    1b3c:      	add	x2, x8, #0x360
    1b40:      	mov	w8, #0x8                // =8
    1b44:      	blr	x9
    1b48:      	mov	w25, #0x50              // =80
    1b4c:      	b	0x3954 <generic_rawtp_process_event+0x3784>
    1b50:      	cmp	w24, #0x8
    1b54:      	b.eq	0x21ac <generic_rawtp_process_event+0x1fdc>
    1b58:      	adrp	x29, 0x1000 <generic_rawtp_process_event+0xe30>
    1b5c:      	cmp	w24, #0x12
    1b60:      	ldr	x29, [x29]
    1b64:      	ldr	x12, [sp, #0x28]
    1b68:      	b.ne	0x3960 <generic_rawtp_process_event+0x3790>
    1b6c:      	ldp	x8, x2, [sp, #0x30]
    1b70:      	mov	x21, x12
    1b74:      	and	x25, x8, #0x3ff
    1b78:      	ldr	x0, [sp, #0x18]
    1b7c:      	mov	w8, #0x4                // =4
    1b80:      	mov	w1, w25
    1b84:      	blr	x8
    1b88:      	mov	x12, x21
    1b8c:      	b	0x3960 <generic_rawtp_process_event+0x3790>
    1b90:      	cmp	w24, #0x13
    1b94:      	b.eq	0x2400 <generic_rawtp_process_event+0x2230>
    1b98:      	adrp	x29, 0x1000 <generic_rawtp_process_event+0xe30>
    1b9c:      	cmp	w24, #0x14
    1ba0:      	ldr	x29, [x29]
    1ba4:      	ldr	x12, [sp, #0x28]
    1ba8:      	b.ne	0x3960 <generic_rawtp_process_event+0x3790>
    1bac:      	ldr	x22, [sp, #0x38]
    1bb0:      	str	xzr, [sp, #0x88]
    1bb4:      	mov	w10, #0x8               // =8
    1bb8:      	add	x8, sp, #0x88
    1bbc:      	mov	w9, #0x4                // =4
    1bc0:      	add	x0, sp, #0x88
    1bc4:      	mov	w1, #0x8                // =8
    1bc8:      	mov	w21, #0x4               // =4
    1bcc:      	mov	x24, x12
    1bd0:      	add	x2, x22, #0x110
    1bd4:      	add	x23, x22, #0xd8
    1bd8:      	blr	x9
    1bdc:      	ldr	x8, [sp, #0x88]
    1be0:      	mov	w9, #0x80               // =128
    1be4:      	mov	w10, #0x2d              // =45
    1be8:      	ldr	x25, [sp, #0x18]
    1bec:      	mov	w1, #0x80               // =128
    1bf0:      	mov	x0, x25
    1bf4:      	ldr	x2, [sp, #0x88]
    1bf8:      	blr	x10
    1bfc:      	add	x0, x25, #0x90
    1c00:      	mov	w8, #0x4                // =4
    1c04:      	mov	w1, #0x4                // =4
    1c08:      	mov	x2, x23
    1c0c:      	blr	x8
    1c10:      	add	x0, x25, #0x80
    1c14:      	add	x2, x22, #0xe0
    1c18:      	mov	w8, #0x4                // =4
    1c1c:      	mov	w9, #0x8                // =8
    1c20:      	mov	w1, #0x8                // =8
    1c24:      	mov	w23, #0x8               // =8
    1c28:      	blr	x8
    1c2c:      	add	x0, x25, #0x88
    1c30:      	add	x2, x22, #0x118
    1c34:      	mov	w1, #0x8                // =8
    1c38:      	blr	x21
    1c3c:      	mov	x12, x24
    1c40:      	mov	w25, #0x98              // =152
    1c44:      	b	0x3960 <generic_rawtp_process_event+0x3790>
    1c48:      	ldp	x10, x12, [sp, #0x20]
    1c4c:      	cmp	w24, #0x26
    1c50:      	mov	x29, x21
    1c54:      	mov	w9, #0x5ea0             // =24224
    1c58:      	b.ne	0x3968 <generic_rawtp_process_event+0x3798>
    1c5c:      	ldr	x8, [x11]
    1c60:      	ldr	x9, [sp, #0x18]
    1c64:      	add	x2, x19, w8, uxth
    1c68:      	ubfx	w8, w8, #16, #12
    1c6c:      	add	x0, x9, #0x4
    1c70:      	add	w1, w8, #0x1
    1c74:      	mov	w8, #0x2d               // =45
    1c78:      	blr	x8
    1c7c:      	b	0x20c4 <generic_rawtp_process_event+0x1ef4>
    1c80:      	str	xzr, [sp, #0x90]
    1c84:      	mov	w8, #0xe                // =14
    1c88:      	blr	x8
    1c8c:      	lsr	x8, x0, #32
    1c90:      	add	x9, sp, #0xe0
    1c94:      	add	x10, sp, #0xd0
    1c98:      	str	x8, [sp, #0x88]
    1c9c:      	mov	w8, #0x4                // =4
    1ca0:      	add	x0, sp, #0xe0
    1ca4:      	add	x2, sp, #0xd0
    1ca8:      	mov	w1, #0x4                // =4
    1cac:      	blr	x8
    1cb0:      	ldr	w8, [sp, #0xe0]
    1cb4:      	adrp	x0, 0x1000 <generic_rawtp_process_event+0xe30>
    1cb8:      	add	x9, sp, #0x88
    1cbc:      	add	x1, sp, #0x88
    1cc0:      	str	w8, [sp, #0x90]
    1cc4:      	mov	w8, #0x1                // =1
    1cc8:      	ldr	x0, [x0]
    1ccc:      	blr	x8
    1cd0:      	cbz	x0, 0x25d0 <generic_rawtp_process_event+0x2400>
    1cd4:      	ldr	x25, [sp, #0x18]
    1cd8:      	ldr	w21, [x0]
    1cdc:      	add	x8, sp, #0xe0
    1ce0:      	mov	w9, #0x4                // =4
    1ce4:      	mov	x23, x0
    1ce8:      	add	x2, sp, #0xe0
    1cec:      	mov	w1, #0x4                // =4
    1cf0:      	mov	w24, #0x4               // =4
    1cf4:      	mov	x0, x25
    1cf8:      	blr	x9
    1cfc:      	and	x21, x21, #0xfff
    1d00:      	add	x0, x25, #0x4
    1d04:      	mov	w8, #0x4                // =4
    1d08:      	mov	x2, x23
    1d0c:      	add	x1, x21, #0x4
    1d10:      	blr	x8
    1d14:      	add	w21, w21, #0x8
    1d18:      	mov	w1, #0x4                // =4
    1d1c:      	add	x8, x21, x23
    1d20:      	add	x0, x25, x21
    1d24:      	sub	x2, x8, #0x4
    1d28:      	blr	x24
    1d2c:      	add	x25, x21, #0x4
    1d30:      	b	0x395c <generic_rawtp_process_event+0x378c>
    1d34:      	ldr	x24, [x11]
    1d38:      	mov	w8, #0x1                // =1
    1d3c:      	mov	w9, #0x4                // =4
    1d40:      	add	x10, sp, #0x78
    1d44:      	add	x0, sp, #0x78
    1d48:      	mov	w1, #0x1                // =1
    1d4c:      	mov	x2, x24
    1d50:      	blr	x9
    1d54:      	ldrb	w8, [sp, #0x78]
    1d58:      	cmp	w8, #0x1
    1d5c:      	b.ne	0x25b4 <generic_rawtp_process_event+0x23e4>
    1d60:      	add	x2, x24, #0x10
    1d64:      	mov	w24, #0x8               // =8
    1d68:      	add	x8, sp, #0xe0
    1d6c:      	mov	w9, #0x4                // =4
    1d70:      	add	x0, sp, #0xe0
    1d74:      	mov	w1, #0x8                // =8
    1d78:      	mov	w25, #0x4               // =4
    1d7c:      	blr	x9
    1d80:      	add	x22, sp, #0xd0
    1d84:      	add	x8, sp, #0x60
    1d88:      	mov	w9, #0x4                // =4
    1d8c:      	ldr	x2, [x22, #0x10]
    1d90:      	add	x0, sp, #0x60
    1d94:      	mov	w1, #0x8                // =8
    1d98:      	blr	x9
    1d9c:      	ldr	x8, [x22, #0x10]
    1da0:      	add	x0, sp, #0xd8
    1da4:      	mov	w1, #0x8                // =8
    1da8:      	add	x2, x8, #0x8
    1dac:      	add	x8, sp, #0xd8
    1db0:      	blr	x25
    1db4:      	ldr	x8, [sp, #0x38]
    1db8:      	ldr	x10, [sp, #0x60]
    1dbc:      	add	x8, x8, #0x90
    1dc0:      	ldr	x22, [x22, #0x8]
    1dc4:      	add	x9, x8, x23
    1dc8:      	stp	x10, x9, [sp, #0x30]
    1dcc:      	tbz	w21, #0x5, 0x289c <generic_rawtp_process_event+0x26cc>
    1dd0:      	cmp	x22, #0x1, lsl #12      // =0x1000
    1dd4:      	b.lo	0x2880 <generic_rawtp_process_event+0x26b0>
    1dd8:      	ldr	x9, [sp, #0x38]
    1ddc:      	mov	w8, #0x1                // =1
    1de0:      	adrp	x0, 0x1000 <generic_rawtp_process_event+0xe30>
    1de4:      	add	x1, sp, #0xc8
    1de8:      	str	w8, [x9]
    1dec:      	str	wzr, [sp, #0xc8]
    1df0:      	add	x9, sp, #0xc8
    1df4:      	ldr	x0, [x0]
    1df8:      	blr	x8
    1dfc:      	str	x0, [sp, #0x18]
    1e00:      	cbz	x0, 0x2b80 <generic_rawtp_process_event+0x29b0>
    1e04:      	ldr	x23, [sp, #0x18]
    1e08:      	mov	w8, #0x18               // =24
    1e0c:      	str	w8, [x23]
    1e10:      	mov	w8, #0xe                // =14
    1e14:      	blr	x8
    1e18:      	str	x0, [x23, #0x10]!
    1e1c:      	cmn	x0, #0x16
    1e20:      	b.ne	0x1e48 <generic_rawtp_process_event+0x1c78>
    1e24:      	add	x2, x19, #0xe8
    1e28:      	mov	w8, #0x8                // =8
    1e2c:      	mov	w9, #0x4                // =4
    1e30:      	add	x10, sp, #0x88
    1e34:      	add	x0, sp, #0x88
    1e38:      	mov	w1, #0x8                // =8
    1e3c:      	blr	x9
    1e40:      	ldr	x8, [sp, #0x88]
    1e44:      	str	x8, [x23]
    1e48:      	mov	w8, #0x7d               // =125
    1e4c:      	blr	x8
    1e50:      	ldr	x8, [sp, #0x18]
    1e54:      	ldr	x10, [sp, #0x38]
    1e58:      	mov	x21, xzr
    1e5c:      	mov	w25, #0xa               // =10
    1e60:      	str	x0, [x8, #0x18]
    1e64:      	add	x8, x8, #0x20
    1e68:      	str	x8, [sp, #0x10]
    1e6c:      	ldp	x8, x9, [x23]
    1e70:      	stur	x8, [x10, #0x14]
    1e74:      	stur	x9, [x10, #0x1c]
    1e78:      	subs	x8, x22, x21
    1e7c:      	b.mi	0x304c <generic_rawtp_process_event+0x2e7c>
    1e80:      	ldr	x9, [sp, #0x30]
    1e84:      	ldr	x0, [sp, #0x10]
    1e88:      	add	x2, x21, x9
    1e8c:      	mov	w9, #0x7fe0             // =32736
    1e90:      	cmp	x8, x9
    1e94:      	csel	x24, x8, x9, lo
    1e98:      	mov	w8, #0x4                // =4
    1e9c:      	mov	w1, w24
    1ea0:      	blr	x8
    1ea4:      	tbnz	w0, #0x1f, 0x1f24 <generic_rawtp_process_event+0x1d54>
    1ea8:      	ldr	x8, [sp, #0x18]
    1eac:      	add	w23, w24, #0x20
    1eb0:      	str	wzr, [sp, #0x88]
    1eb4:      	adrp	x0, 0x1000 <generic_rawtp_process_event+0xe30>
    1eb8:      	add	x9, sp, #0x88
    1ebc:      	add	x1, sp, #0x88
    1ec0:      	str	w23, [x8, #0x4]
    1ec4:      	mov	w8, #0x1                // =1
    1ec8:      	ldr	x0, [x0]
    1ecc:      	blr	x8
    1ed0:      	cbz	x0, 0x1f04 <generic_rawtp_process_event+0x1d34>
    1ed4:      	ldrb	w8, [x0, #0x28]
    1ed8:      	cbz	w8, 0x1f04 <generic_rawtp_process_event+0x1d34>
    1edc:      	adrp	x1, 0x1000 <generic_rawtp_process_event+0xe30>
    1ee0:      	ldr	x3, [sp, #0x18]
    1ee4:      	mov	w8, #0x19               // =25
    1ee8:      	mov	w9, #-0x1               // =-1
    1eec:      	ldr	x1, [x1]
    1ef0:      	mov	x0, x19
    1ef4:      	mov	w2, #-0x1               // =-1
    1ef8:      	mov	x4, x23
    1efc:      	blr	x8
    1f00:      	b	0x1f20 <generic_rawtp_process_event+0x1d50>
    1f04:      	adrp	x0, 0x1000 <generic_rawtp_process_event+0xe30>
    1f08:      	ldr	x1, [sp, #0x18]
    1f0c:      	mov	x3, xzr
    1f10:      	mov	w8, #0x82               // =130
    1f14:      	ldr	x0, [x0]
    1f18:      	mov	x2, x23
    1f1c:      	blr	x8
    1f20:      	tbz	w0, #0x1f, 0x1f28 <generic_rawtp_process_event+0x1d58>
    1f24:      	sxtw	x24, w0
    1f28:      	tbnz	w24, #0x1f, 0x3054 <generic_rawtp_process_event+0x2e84>
    1f2c:      	and	x8, x24, #0x7fffffff
    1f30:      	add	x21, x8, x21
    1f34:      	cmp	x21, x22
    1f38:      	b.eq	0x30a0 <generic_rawtp_process_event+0x2ed0>
    1f3c:      	subs	w25, w25, #0x1
    1f40:      	b.ne	0x1e78 <generic_rawtp_process_event+0x1ca8>
    1f44:      	b	0x341c <generic_rawtp_process_event+0x324c>
    1f48:      	add	x8, sp, #0xd0
    1f4c:      	ldr	x22, [sp, #0x18]
    1f50:      	mov	w1, #0x4                // =4
    1f54:      	mov	w24, #0x4               // =4
    1f58:      	ldr	x21, [x8]
    1f5c:      	mov	w8, #0x4                // =4
    1f60:      	add	x0, x22, #0x28
    1f64:      	add	x2, x21, #0x98
    1f68:      	blr	x8
    1f6c:      	add	x0, x22, #0x2c
    1f70:      	add	x2, x21, #0x70
    1f74:      	mov	w8, #0x4                // =4
    1f78:      	mov	w1, #0x4                // =4
    1f7c:      	blr	x8
    1f80:      	add	x0, x22, #0x30
    1f84:      	add	x2, x21, #0x90
    1f88:      	mov	w8, #0x4                // =4
    1f8c:      	mov	w1, #0x4                // =4
    1f90:      	blr	x8
    1f94:      	add	x0, x22, #0x34
    1f98:      	add	x2, x21, #0xa8
    1f9c:      	mov	w8, #0x4                // =4
    1fa0:      	mov	w1, #0x4                // =4
    1fa4:      	blr	x8
    1fa8:      	str	xzr, [sp, #0x88]
    1fac:      	add	x2, x21, #0xc8
    1fb0:      	mov	w8, #0x8                // =8
    1fb4:      	add	x9, sp, #0x88
    1fb8:      	mov	w10, #0x4               // =4
    1fbc:      	add	x0, sp, #0x88
    1fc0:      	mov	w1, #0x8                // =8
    1fc4:      	blr	x10
    1fc8:      	add	x2, x21, #0xb8
    1fcc:      	mov	w8, #0x2                // =2
    1fd0:      	add	x9, sp, #0xd8
    1fd4:      	mov	w10, #0x4               // =4
    1fd8:      	add	x0, sp, #0xd8
    1fdc:      	mov	w1, #0x2                // =2
    1fe0:      	blr	x10
    1fe4:      	ldr	x8, [sp, #0x88]
    1fe8:      	ldrh	w9, [sp, #0xd8]
    1fec:      	add	x0, sp, #0x74
    1ff0:      	mov	w1, #0x1                // =1
    1ff4:      	add	x23, x8, x9
    1ff8:      	mov	w8, #0x1                // =1
    1ffc:      	add	x9, sp, #0x74
    2000:      	mov	x2, x23
    2004:      	blr	x24
    2008:      	ldrb	w8, [sp, #0x74]
    200c:      	lsr	w8, w8, #4
    2010:      	cmp	w8, #0x6
    2014:      	b.eq	0x25d8 <generic_rawtp_process_event+0x2408>
    2018:      	cmp	w8, #0x4
    201c:      	b.ne	0x3950 <generic_rawtp_process_event+0x3780>
    2020:      	add	x2, x23, #0x9
    2024:      	mov	w8, #0x1                // =1
    2028:      	add	x9, sp, #0x78
    202c:      	mov	w10, #0x4               // =4
    2030:      	add	x0, sp, #0x78
    2034:      	mov	w1, #0x1                // =1
    2038:      	mov	w25, #0x4               // =4
    203c:      	blr	x10
    2040:      	ldr	x0, [sp, #0x18]
    2044:      	ldrb	w8, [sp, #0x78]
    2048:      	mov	w29, #0x2               // =2
    204c:      	add	x2, x23, #0xc
    2050:      	mov	w1, #0x4                // =4
    2054:      	mov	x24, x0
    2058:      	strh	w8, [x0, #0x24]
    205c:      	strh	w29, [x0, #0x26]
    2060:      	stp	xzr, xzr, [x0]
    2064:      	str	xzr, [x0, #0x18]
    2068:      	mov	w8, #0x4                // =4
    206c:      	str	xzr, [x24, #0x10]!
    2070:      	blr	x8
    2074:      	add	x2, x23, #0x10
    2078:      	mov	w8, #0x4                // =4
    207c:      	mov	x0, x24
    2080:      	mov	w1, #0x4                // =4
    2084:      	blr	x8
    2088:      	add	x2, x21, #0xb6
    208c:      	add	x8, sp, #0xc8
    2090:      	add	x0, sp, #0xc8
    2094:      	mov	w1, #0x2                // =2
    2098:      	blr	x25
    209c:      	ldrb	w25, [sp, #0x78]
    20a0:      	b	0x3814 <generic_rawtp_process_event+0x3644>
    20a4:      	ldr	x8, [x11]
    20a8:      	mov	w9, #0x2d               // =45
    20ac:      	mov	w1, #0x11               // =17
    20b0:      	add	x2, x8, #0x118
    20b4:      	ldr	x8, [sp, #0x18]
    20b8:      	add	x0, x8, #0x4
    20bc:      	mov	w8, #0x11               // =17
    20c0:      	blr	x9
    20c4:      	mov	x25, x0
    20c8:      	tbnz	x0, #0x3f, 0x2878 <generic_rawtp_process_event+0x26a8>
    20cc:      	ldr	x9, [sp, #0x18]
    20d0:      	sub	w8, w25, #0x1
    20d4:      	add	x25, x25, #0x3
    20d8:      	mov	x29, x21
    20dc:      	str	w8, [x9]
    20e0:      	b	0x395c <generic_rawtp_process_event+0x378c>
    20e4:      	ldr	x0, [sp, #0x18]
    20e8:      	ldr	x23, [x11]
    20ec:      	mov	w8, #0x2                // =2
    20f0:      	mov	w9, #0x4                // =4
    20f4:      	mov	w1, #0x2                // =2
    20f8:      	mov	x2, x23
    20fc:      	str	xzr, [x0]
    2100:      	stp	xzr, xzr, [x0, #0x8]
    2104:      	blr	x9
    2108:      	tbnz	x0, #0x3f, 0x2848 <generic_rawtp_process_event+0x2678>
    210c:      	ldr	x8, [sp, #0x18]
    2110:      	ldrh	w8, [x8]
    2114:      	cmp	w8, #0xa
    2118:      	b.eq	0x2800 <generic_rawtp_process_event+0x2630>
    211c:      	cmp	w8, #0x2
    2120:      	b.ne	0x2834 <generic_rawtp_process_event+0x2664>
    2124:      	add	x2, x23, #0x4
    2128:      	add	x8, sp, #0x88
    212c:      	mov	w9, #0x4                // =4
    2130:      	add	x0, sp, #0x88
    2134:      	mov	w1, #0x4                // =4
    2138:      	mov	w22, #0x4               // =4
    213c:      	blr	x9
    2140:      	ldr	w8, [sp, #0x88]
    2144:      	ldr	x9, [sp, #0x18]
    2148:      	add	x2, x23, #0x2
    214c:      	add	x0, x9, #0x2
    2150:      	str	x8, [x9, #0x8]
    2154:      	mov	w8, #0x2                // =2
    2158:      	b	0x282c <generic_rawtp_process_event+0x265c>
    215c:      	ldr	x8, [sp, #0x10]
    2160:      	str	xzr, [x9]
    2164:      	add	x24, x8, #0x90
    2168:      	add	x8, x24, x23
    216c:      	str	x8, [sp, #0x18]
    2170:      	tbnz	w21, #0x4, 0x2720 <generic_rawtp_process_event+0x2550>
    2174:      	ldr	x9, [sp, #0x30]
    2178:      	mov	x8, xzr
    217c:      	and	x23, x21, #0xffffffff
    2180:      	and	w9, w9, #0xf
    2184:      	cmp	w9, #0x2
    2188:      	b.le	0x28e4 <generic_rawtp_process_event+0x2714>
    218c:      	cmp	w9, #0x3
    2190:      	b.eq	0x2b88 <generic_rawtp_process_event+0x29b8>
    2194:      	cmp	w9, #0x4
    2198:      	b.eq	0x2b90 <generic_rawtp_process_event+0x29c0>
    219c:      	cmp	w9, #0x5
    21a0:      	b.ne	0x2ba8 <generic_rawtp_process_event+0x29d8>
    21a4:      	mov	w9, #0x5e70             // =24176
    21a8:      	b	0x2b9c <generic_rawtp_process_event+0x29cc>
    21ac:      	ldr	x25, [sp, #0x38]
    21b0:      	ldr	x22, [sp, #0x18]
    21b4:      	mov	w8, #0x4                // =4
    21b8:      	mov	w1, #0x4                // =4
    21bc:      	mov	w21, #0x4               // =4
    21c0:      	add	x2, x25, #0x8
    21c4:      	mov	x0, x22
    21c8:      	add	x23, x22, #0x28
    21cc:      	add	x29, x22, #0x40
    21d0:      	blr	x8
    21d4:      	add	x0, x22, #0x4
    21d8:      	add	x2, x25, #0xc
    21dc:      	mov	w8, #0x4                // =4
    21e0:      	mov	w1, #0x4                // =4
    21e4:      	blr	x8
    21e8:      	add	x0, x22, #0x10
    21ec:      	add	x2, x25, #0x18
    21f0:      	mov	w8, #0x4                // =4
    21f4:      	mov	w1, #0x4                // =4
    21f8:      	blr	x8
    21fc:      	add	x0, x22, #0x14
    2200:      	add	x2, x25, #0x1c
    2204:      	mov	w8, #0x4                // =4
    2208:      	mov	w1, #0x4                // =4
    220c:      	blr	x8
    2210:      	add	x0, x22, #0x8
    2214:      	add	x2, x25, #0x10
    2218:      	mov	w8, #0x4                // =4
    221c:      	mov	w1, #0x4                // =4
    2220:      	blr	x8
    2224:      	add	x0, x22, #0xc
    2228:      	add	x2, x25, #0x14
    222c:      	mov	w8, #0x4                // =4
    2230:      	mov	w1, #0x4                // =4
    2234:      	blr	x8
    2238:      	add	x0, x22, #0x18
    223c:      	add	x2, x25, #0x20
    2240:      	mov	w8, #0x4                // =4
    2244:      	mov	w1, #0x4                // =4
    2248:      	blr	x8
    224c:      	add	x0, x22, #0x1c
    2250:      	add	x2, x25, #0x24
    2254:      	mov	w8, #0x4                // =4
    2258:      	mov	w1, #0x4                // =4
    225c:      	blr	x8
    2260:      	str	wzr, [x22, #0x24]
    2264:      	add	x0, x22, #0x20
    2268:      	add	x2, x25, #0x28
    226c:      	mov	w8, #0x4                // =4
    2270:      	mov	w1, #0x4                // =4
    2274:      	blr	x8
    2278:      	add	x0, x22, #0x30
    227c:      	add	x2, x25, #0x40
    2280:      	mov	w24, #0x8               // =8
    2284:      	mov	w8, #0x4                // =4
    2288:      	mov	w1, #0x8                // =8
    228c:      	blr	x8
    2290:      	add	x0, x22, #0x38
    2294:      	add	x2, x25, #0x30
    2298:      	mov	w8, #0x4                // =4
    229c:      	mov	w1, #0x8                // =8
    22a0:      	blr	x8
    22a4:      	add	x2, x25, #0x38
    22a8:      	mov	w8, #0x4                // =4
    22ac:      	mov	x0, x23
    22b0:      	mov	w1, #0x8                // =8
    22b4:      	blr	x8
    22b8:      	add	x2, x25, #0x90
    22bc:      	add	x8, sp, #0x88
    22c0:      	mov	w9, #0x4                // =4
    22c4:      	add	x0, sp, #0x88
    22c8:      	mov	w1, #0x8                // =8
    22cc:      	blr	x9
    22d0:      	ldr	x23, [sp, #0x88]
    22d4:      	mov	w8, #0x4                // =4
    22d8:      	mov	x0, x29
    22dc:      	mov	w1, #0x4                // =4
    22e0:      	add	x2, x23, #0xc8
    22e4:      	blr	x8
    22e8:      	add	x0, x22, #0x44
    22ec:      	add	x2, x23, #0xcc
    22f0:      	mov	w8, #0x4                // =4
    22f4:      	mov	w1, #0x4                // =4
    22f8:      	blr	x8
    22fc:      	add	x0, x22, #0x48
    2300:      	add	x2, x23, #0xd0
    2304:      	mov	w8, #0x4                // =4
    2308:      	mov	w1, #0x4                // =4
    230c:      	blr	x8
    2310:      	add	x0, x22, #0x4c
    2314:      	add	x2, x23, #0x158
    2318:      	mov	w1, #0x4                // =4
    231c:      	blr	x21
    2320:      	mov	w25, #0x50              // =80
    2324:      	b	0x3954 <generic_rawtp_process_event+0x3784>
    2328:      	ldr	x23, [sp, #0x38]
    232c:      	ldr	x22, [sp, #0x18]
    2330:      	mov	w8, #0x4                // =4
    2334:      	mov	w1, #0x4                // =4
    2338:      	mov	w21, #0x4               // =4
    233c:      	add	x2, x23, #0xc8
    2340:      	mov	x0, x22
    2344:      	blr	x8
    2348:      	add	x0, x22, #0x4
    234c:      	add	x2, x23, #0xcc
    2350:      	mov	w8, #0x4                // =4
    2354:      	mov	w1, #0x4                // =4
    2358:      	blr	x8
    235c:      	add	x0, x22, #0x8
    2360:      	add	x2, x23, #0xd0
    2364:      	mov	w8, #0x4                // =4
    2368:      	mov	w1, #0x4                // =4
    236c:      	blr	x8
    2370:      	add	x0, x22, #0xc
    2374:      	add	x2, x23, #0x158
    2378:      	mov	w1, #0x4                // =4
    237c:      	blr	x21
    2380:      	mov	w25, #0x10              // =16
    2384:      	b	0x3954 <generic_rawtp_process_event+0x3784>
    2388:      	ldr	x23, [sp, #0x38]
    238c:      	ldr	x22, [sp, #0x18]
    2390:      	mov	w8, #0x4                // =4
    2394:      	mov	w1, #0x4                // =4
    2398:      	mov	w21, #0x4               // =4
    239c:      	add	x2, x23, #0x38
    23a0:      	mov	x0, x22
    23a4:      	blr	x8
    23a8:      	add	x0, x22, #0x4
    23ac:      	add	x2, x23, #0x3c
    23b0:      	mov	w8, #0x4                // =4
    23b4:      	mov	w1, #0x4                // =4
    23b8:      	blr	x8
    23bc:      	add	x0, x22, #0x8
    23c0:      	add	x2, x23, #0x40
    23c4:      	mov	w8, #0x4                // =4
    23c8:      	mov	w1, #0x4                // =4
    23cc:      	blr	x8
    23d0:      	add	x0, x22, #0xc
    23d4:      	add	x2, x23, #0x44
    23d8:      	mov	w8, #0x4                // =4
    23dc:      	mov	w1, #0x4                // =4
    23e0:      	blr	x8
    23e4:      	add	x0, x22, #0x10
    23e8:      	add	x2, x23, #0x80
    23ec:      	mov	w8, #0x10               // =16
    23f0:      	mov	w1, #0x10               // =16
    23f4:      	blr	x21
    23f8:      	mov	w25, #0x20              // =32
    23fc:      	b	0x3954 <generic_rawtp_process_event+0x3784>
    2400:      	ldr	x22, [sp, #0x18]
    2404:      	ldr	x23, [sp, #0x38]
    2408:      	mov	w8, #0x4                // =4
    240c:      	mov	w1, #0x4                // =4
    2410:      	mov	w21, #0x4               // =4
    2414:      	mov	x0, x22
    2418:      	mov	x2, x23
    241c:      	blr	x8
    2420:      	add	x0, x22, #0x4
    2424:      	add	x2, x23, #0x4
    2428:      	mov	w8, #0x4                // =4
    242c:      	mov	w1, #0x4                // =4
    2430:      	blr	x8
    2434:      	add	x0, x22, #0x8
    2438:      	add	x2, x23, #0x30
    243c:      	mov	w8, #0x10               // =16
    2440:      	b	0x24c4 <generic_rawtp_process_event+0x22f4>
    2444:      	ldr	x23, [sp, #0x38]
    2448:      	add	x8, sp, #0x88
    244c:      	mov	w9, #0x4                // =4
    2450:      	add	x0, sp, #0x88
    2454:      	mov	w1, #0x4                // =4
    2458:      	mov	w21, #0x4               // =4
    245c:      	add	x2, x23, #0x4
    2460:      	blr	x9
    2464:      	ldr	w8, [sp, #0x88]
    2468:      	ldr	x22, [sp, #0x18]
    246c:      	add	x2, x23, #0xc
    2470:      	add	x0, sp, #0x88
    2474:      	mov	w1, #0x4                // =4
    2478:      	str	w8, [x22]
    247c:      	add	x8, sp, #0x88
    2480:      	blr	x21
    2484:      	ldr	w8, [sp, #0x88]
    2488:      	add	x2, x23, #0x50
    248c:      	add	x9, sp, #0x88
    2490:      	mov	w10, #0x2d              // =45
    2494:      	str	w8, [x22, #0x4]
    2498:      	mov	w8, #0x8                // =8
    249c:      	add	x0, sp, #0x88
    24a0:      	mov	w1, #0x8                // =8
    24a4:      	mov	w21, #0x2d              // =45
    24a8:      	blr	x10
    24ac:      	ldr	x8, [sp, #0x88]
    24b0:      	add	x0, x22, #0x8
    24b4:      	mov	w9, #0x10               // =16
    24b8:      	add	x8, x8, #0x3f8
    24bc:      	ldr	x8, [sp, #0x88]
    24c0:      	add	x2, x8, #0x3f8
    24c4:      	mov	w1, #0x10               // =16
    24c8:      	blr	x21
    24cc:      	mov	w25, #0x18              // =24
    24d0:      	b	0x3954 <generic_rawtp_process_event+0x3784>
    24d4:      	ldr	x11, [sp, #0x18]
    24d8:      	ldr	x2, [sp, #0x38]
    24dc:      	mov	w8, #0x8                // =8
    24e0:      	mov	w9, #0x4                // =4
    24e4:      	add	x10, sp, #0x88
    24e8:      	add	x0, sp, #0x88
    24ec:      	mov	w1, #0x8                // =8
    24f0:      	stp	xzr, xzr, [x11, #0x40]
    24f4:      	stp	xzr, xzr, [x11, #0x30]
    24f8:      	stp	xzr, xzr, [x11, #0x20]
    24fc:      	stp	xzr, xzr, [x11, #0x10]
    2500:      	stp	xzr, xzr, [x11]
    2504:      	blr	x9
    2508:      	mov	x25, xzr
    250c:      	cbnz	x0, 0x3954 <generic_rawtp_process_event+0x3784>
    2510:      	ldr	x8, [sp, #0x18]
    2514:      	mov	w9, #0x3f               // =63
    2518:      	mov	w10, #0x2d              // =45
    251c:      	mov	w1, #0x3f               // =63
    2520:      	add	x0, x8, #0x10
    2524:      	ldr	x8, [sp, #0x88]
    2528:      	ldr	x2, [sp, #0x88]
    252c:      	blr	x10
    2530:      	tbnz	x0, #0x3f, 0x2718 <generic_rawtp_process_event+0x2548>
    2534:      	ldr	x22, [sp, #0x38]
    2538:      	mov	w21, #0x8               // =8
    253c:      	add	x8, sp, #0xe0
    2540:      	mov	w9, #0x4                // =4
    2544:      	add	x0, sp, #0xe0
    2548:      	mov	w1, #0x8                // =8
    254c:      	mov	w23, #0x4               // =4
    2550:      	add	x2, x22, #0x8
    2554:      	blr	x9
    2558:      	ldr	x8, [sp, #0x18]
    255c:      	add	x10, sp, #0xd0
    2560:      	mov	w9, #0x4                // =4
    2564:      	mov	w1, #0x8                // =8
    2568:      	add	x0, x8, #0x8
    256c:      	ldr	x8, [x10, #0x10]
    2570:      	add	x8, x8, #0x360
    2574:      	ldr	x8, [x10, #0x10]
    2578:      	add	x2, x8, #0x360
    257c:      	blr	x9
    2580:      	add	x2, x22, #0x58
    2584:      	add	x8, sp, #0xe0
    2588:      	add	x0, sp, #0xe0
    258c:      	mov	w1, #0x4                // =4
    2590:      	blr	x23
    2594:      	cbnz	x0, 0x25ac <generic_rawtp_process_event+0x23dc>
    2598:      	ldr	w8, [sp, #0xe0]
    259c:      	ldr	x9, [sp, #0x18]
    25a0:      	cmp	w8, #0x0
    25a4:      	cset	w8, ne
    25a8:      	str	w8, [x9]
    25ac:      	mov	w25, #0x50              // =80
    25b0:      	b	0x3954 <generic_rawtp_process_event+0x3784>
    25b4:      	ldr	x8, [sp, #0x38]
    25b8:      	mov	w25, #0x8               // =8
    25bc:      	add	x8, x8, x23
    25c0:      	str	xzr, [x8, #0x90]
    25c4:      	b	0x395c <generic_rawtp_process_event+0x378c>
    25c8:      	mov	w10, #0x9               // =9
    25cc:      	b	0x1910 <generic_rawtp_process_event+0x1740>
    25d0:      	mov	x25, #-0x1              // =-1
    25d4:      	b	0x395c <generic_rawtp_process_event+0x378c>
    25d8:      	str	wzr, [sp, #0xe0]
    25dc:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    25e0:      	ldr	x22, [sp, #0x88]
    25e4:      	mov	w8, #0x1                // =1
    25e8:      	add	x9, sp, #0xe0
    25ec:      	add	x1, sp, #0xe0
    25f0:      	ldrh	w23, [sp, #0xd8]
    25f4:      	ldr	x0, [x0]
    25f8:      	add	x29, x22, x23
    25fc:      	blr	x8
    2600:      	cbz	x0, 0x37d0 <generic_rawtp_process_event+0x3600>
    2604:      	mov	w8, #0xff               // =255
    2608:      	strh	w23, [x0]
    260c:      	strb	wzr, [x0, #0x7]
    2610:      	add	x23, x0, #0x6
    2614:      	add	x2, x29, #0x6
    2618:      	mov	w9, #0x4                // =4
    261c:      	strb	w8, [x0, #0x5]
    2620:      	mov	w8, #0x1                // =1
    2624:      	mov	x24, x0
    2628:      	mov	x0, x23
    262c:      	mov	w1, #0x1                // =1
    2630:      	blr	x9
    2634:      	tbnz	x0, #0x3f, 0x37d0 <generic_rawtp_process_event+0x3600>
    2638:      	ldrb	w8, [x24, #0x5]
    263c:      	cmp	w8, #0x32
    2640:      	b.gt	0x2afc <generic_rawtp_process_event+0x292c>
    2644:      	cbz	w8, 0x2b74 <generic_rawtp_process_event+0x29a4>
    2648:      	cmp	w8, #0x2b
    264c:      	b.eq	0x2b74 <generic_rawtp_process_event+0x29a4>
    2650:      	cmp	w8, #0x2c
    2654:      	b.ne	0x3168 <generic_rawtp_process_event+0x2f98>
    2658:      	mov	w8, #0x8                // =8
    265c:      	b	0x30b4 <generic_rawtp_process_event+0x2ee4>
    2660:      	ldr	x0, [sp, #0x18]
    2664:      	add	x2, x23, #0x48
    2668:      	mov	w25, #0x10              // =16
    266c:      	mov	w8, #0x4                // =4
    2670:      	mov	w1, #0x10               // =16
    2674:      	mov	w29, #0x4               // =4
    2678:      	blr	x8
    267c:      	add	x2, x23, #0x38
    2680:      	mov	x0, x24
    2684:      	mov	w1, #0x10               // =16
    2688:      	blr	x29
    268c:      	ldr	x22, [sp, #0x18]
    2690:      	add	x24, x23, #0xc
    2694:      	add	x2, x23, #0xe
    2698:      	mov	w23, #0x2               // =2
    269c:      	mov	w8, #0x4                // =4
    26a0:      	mov	w1, #0x2                // =2
    26a4:      	mov	w25, #0x4               // =4
    26a8:      	add	x0, x22, #0x20
    26ac:      	blr	x8
    26b0:      	add	x0, x22, #0x22
    26b4:      	mov	w1, #0x2                // =2
    26b8:      	mov	x2, x24
    26bc:      	blr	x25
    26c0:      	ldrh	w8, [x22, #0x22]
    26c4:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    26c8:      	add	x9, sp, #0x88
    26cc:      	add	x1, sp, #0x88
    26d0:      	rev	w8, w8
    26d4:      	lsr	w8, w8, #16
    26d8:      	strh	w8, [x22, #0x22]
    26dc:      	add	x8, sp, #0xd0
    26e0:      	ldr	x8, [x8]
    26e4:      	str	x8, [sp, #0x88]
    26e8:      	mov	w8, #0x1                // =1
    26ec:      	ldr	x0, [x0]
    26f0:      	blr	x8
    26f4:      	cbz	x0, 0x3950 <generic_rawtp_process_event+0x3780>
    26f8:      	ldr	w8, [x0]
    26fc:      	mov	w25, #0x40              // =64
    2700:      	str	w8, [x21, #0x10]
    2704:      	ldr	x8, [x0, #0x8]
    2708:      	str	x8, [x21, #0x18]
    270c:      	ldr	w8, [x0, #0x4]
    2710:      	str	w8, [x21, #0x7c]
    2714:      	b	0x3954 <generic_rawtp_process_event+0x3784>
    2718:      	mov	x25, xzr
    271c:      	b	0x3954 <generic_rawtp_process_event+0x3784>
    2720:      	mov	w8, #0xe                // =14
    2724:      	blr	x8
    2728:      	cmn	x0, #0x16
    272c:      	b.ne	0x2750 <generic_rawtp_process_event+0x2580>
    2730:      	add	x2, x19, #0xe8
    2734:      	mov	w8, #0x8                // =8
    2738:      	mov	w9, #0x4                // =4
    273c:      	add	x10, sp, #0x88
    2740:      	add	x0, sp, #0x88
    2744:      	mov	w1, #0x8                // =8
    2748:      	blr	x9
    274c:      	ldr	x0, [sp, #0x88]
    2750:      	ldr	x8, [sp, #0x10]
    2754:      	mov	x3, xzr
    2758:      	add	x1, sp, #0xe0
    275c:      	add	x2, sp, #0x88
    2760:      	ldr	x9, [x8, #0x60]
    2764:      	ldr	x10, [x8, #0x8]
    2768:      	ldr	x8, [sp, #0x38]
    276c:      	str	xzr, [sp, #0x98]
    2770:      	stp	x10, x8, [sp, #0x88]
    2774:      	add	x8, sp, #0xd0
    2778:      	add	x10, sp, #0x88
    277c:      	stp	x9, x0, [x8, #0x10]
    2780:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    2784:      	mov	w8, #0x2                // =2
    2788:      	add	x9, sp, #0xe0
    278c:      	ldr	x0, [x0]
    2790:      	blr	x8
    2794:      	cbz	x0, 0x2b40 <generic_rawtp_process_event+0x2970>
    2798:      	neg	w8, w0
    279c:      	adrp	x23, 0x2000 <generic_rawtp_process_event+0x1e30>
    27a0:      	mov	w9, #0x1                // =1
    27a4:      	strh	w8, [sp, #0x60]
    27a8:      	mov	w8, #0x5                // =5
    27ac:      	add	x1, sp, #0x60
    27b0:      	mov	w21, #0x1               // =1
    27b4:      	strh	w8, [sp, #0x62]
    27b8:      	mov	x8, #0x46               // =70
    27bc:      	movk	x8, #0x2, lsl #32
    27c0:      	stur	x8, [sp, #0x64]
    27c4:      	add	x8, sp, #0x60
    27c8:      	ldr	x23, [x23]
    27cc:      	mov	x0, x23
    27d0:      	blr	x9
    27d4:      	cbz	x0, 0x2b1c <generic_rawtp_process_event+0x294c>
    27d8:      	ldr	w8, [x0]
    27dc:      	add	w8, w8, #0x1
    27e0:      	str	w8, [x0]
    27e4:      	b	0x2b40 <generic_rawtp_process_event+0x2970>
    27e8:      	cmp	w8, #0x1
    27ec:      	b.eq	0x29c0 <generic_rawtp_process_event+0x27f0>
    27f0:      	cmp	w8, #0x2
    27f4:      	b.ne	0x2a10 <generic_rawtp_process_event+0x2840>
    27f8:      	mov	w9, #0x5e58             // =24152
    27fc:      	b	0x29c4 <generic_rawtp_process_event+0x27f4>
    2800:      	ldr	x24, [sp, #0x18]
    2804:      	add	x2, x23, #0x8
    2808:      	mov	w8, #0x10               // =16
    280c:      	mov	w9, #0x4                // =4
    2810:      	mov	w1, #0x10               // =16
    2814:      	mov	w22, #0x4               // =4
    2818:      	add	x0, x24, #0x8
    281c:      	blr	x9
    2820:      	add	x0, x24, #0x2
    2824:      	add	x2, x23, #0x2
    2828:      	mov	w8, #0x2                // =2
    282c:      	mov	w1, #0x2                // =2
    2830:      	blr	x22
    2834:      	ldr	x9, [sp, #0x18]
    2838:      	ldrh	w8, [x9, #0x2]
    283c:      	rev	w8, w8
    2840:      	lsr	w8, w8, #16
    2844:      	strh	w8, [x9, #0x2]
    2848:      	mov	w25, #0x18              // =24
    284c:      	mov	x29, x21
    2850:      	b	0x395c <generic_rawtp_process_event+0x378c>
    2854:      	add	x2, x23, #0x3
    2858:      	mov	w22, #0x6b              // =107
    285c:      	mov	w8, #0x71               // =113
    2860:      	mov	w1, #0x6b               // =107
    2864:      	blr	x8
    2868:      	tbnz	w0, #0x1f, 0x2874 <generic_rawtp_process_event+0x26a4>
    286c:      	ldr	x8, [sp, #0x18]
    2870:      	strb	w22, [x8, #0x3]
    2874:      	mov	w25, #0x70              // =112
    2878:      	mov	x29, x21
    287c:      	b	0x395c <generic_rawtp_process_event+0x378c>
    2880:      	ldr	x9, [sp, #0x38]
    2884:      	mov	w24, #0xc               // =12
    2888:      	str	wzr, [x9]
    288c:      	ldr	x9, [sp, #0xf8]
    2890:      	add	x8, x8, x9
    2894:      	add	x8, x8, #0x8
    2898:      	str	x8, [sp, #0x38]
    289c:      	cmp	x22, #0xfff
    28a0:      	mov	w8, #0xfff              // =4095
    28a4:      	csel	x23, x22, x8, lo
    28a8:      	ldp	x2, x8, [sp, #0x30]
    28ac:      	mov	w1, w23
    28b0:      	add	x0, x8, #0x8
    28b4:      	mov	w8, #0x4                // =4
    28b8:      	blr	x8
    28bc:      	tbnz	w0, #0x1f, 0x28d0 <generic_rawtp_process_event+0x2700>
    28c0:      	ldr	x8, [sp, #0x38]
    28c4:      	add	x25, x24, x23
    28c8:      	stp	w22, w23, [x8]
    28cc:      	b	0x395c <generic_rawtp_process_event+0x378c>
    28d0:      	ldr	x9, [sp, #0x38]
    28d4:      	mov	w8, #-0x2               // =-2
    28d8:      	mov	w25, #0x4               // =4
    28dc:      	str	w8, [x9]
    28e0:      	b	0x395c <generic_rawtp_process_event+0x378c>
    28e4:      	cmp	w9, #0x1
    28e8:      	b.eq	0x2b98 <generic_rawtp_process_event+0x29c8>
    28ec:      	cmp	w9, #0x2
    28f0:      	b.ne	0x2ba8 <generic_rawtp_process_event+0x29d8>
    28f4:      	mov	w9, #0x5e58             // =24152
    28f8:      	b	0x2b9c <generic_rawtp_process_event+0x29cc>
    28fc:      	ldr	x0, [sp, #0x18]
    2900:      	add	x2, x23, #0x48
    2904:      	mov	w25, #0x10              // =16
    2908:      	mov	w8, #0x4                // =4
    290c:      	mov	w1, #0x10               // =16
    2910:      	mov	w29, #0x4               // =4
    2914:      	blr	x8
    2918:      	add	x2, x23, #0x38
    291c:      	mov	x0, x24
    2920:      	mov	w1, #0x10               // =16
    2924:      	blr	x29
    2928:      	ldr	x22, [sp, #0x18]
    292c:      	add	x24, x23, #0xc
    2930:      	add	x2, x23, #0xe
    2934:      	mov	w23, #0x2               // =2
    2938:      	mov	w8, #0x4                // =4
    293c:      	mov	w1, #0x2                // =2
    2940:      	mov	w25, #0x4               // =4
    2944:      	add	x0, x22, #0x20
    2948:      	blr	x8
    294c:      	add	x0, x22, #0x22
    2950:      	mov	w1, #0x2                // =2
    2954:      	mov	x2, x24
    2958:      	blr	x25
    295c:      	ldrh	w8, [x22, #0x22]
    2960:      	rev	w8, w8
    2964:      	lsr	w8, w8, #16
    2968:      	strh	w8, [x22, #0x22]
    296c:      	ldr	x8, [sp, #0x18]
    2970:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    2974:      	add	x9, sp, #0x88
    2978:      	add	x1, sp, #0x88
    297c:      	ldr	x8, [x8, #0x28]
    2980:      	str	x8, [sp, #0x88]
    2984:      	mov	w8, #0x1                // =1
    2988:      	ldr	x0, [x0]
    298c:      	blr	x8
    2990:      	cbz	x0, 0x3950 <generic_rawtp_process_event+0x3780>
    2994:      	ldr	w8, [x0]
    2998:      	str	w8, [x21, #0x10]
    299c:      	ldr	x8, [x0, #0x8]
    29a0:      	str	x8, [x21, #0x18]
    29a4:      	ldr	w8, [x0, #0x4]
    29a8:      	str	w8, [x21, #0x7c]
    29ac:      	b	0x3950 <generic_rawtp_process_event+0x3780>
    29b0:      	mov	w9, #0x5e60             // =24160
    29b4:      	b	0x29c4 <generic_rawtp_process_event+0x27f4>
    29b8:      	mov	w9, #0x5e68             // =24168
    29bc:      	b	0x29c4 <generic_rawtp_process_event+0x27f4>
    29c0:      	mov	w9, #0x5e50             // =24144
    29c4:      	ldr	x8, [sp, #0x10]
    29c8:      	add	x8, x8, x9
    29cc:      	ldr	x21, [x8]
    29d0:      	ldr	x8, [sp, #0x30]
    29d4:      	tbnz	w8, #0x4, 0x2a20 <generic_rawtp_process_event+0x2850>
    29d8:      	cbz	x21, 0x2aec <generic_rawtp_process_event+0x291c>
    29dc:      	ldr	x2, [sp, #0x38]
    29e0:      	mov	w8, #0x10               // =16
    29e4:      	mov	w9, #0x4                // =4
    29e8:      	add	x10, sp, #0x88
    29ec:      	add	x0, sp, #0x88
    29f0:      	mov	w1, #0x10               // =16
    29f4:      	blr	x9
    29f8:      	tbnz	w0, #0x1f, 0x303c <generic_rawtp_process_event+0x2e6c>
    29fc:      	ldr	x23, [sp, #0x90]
    2a00:      	cmp	x23, #0xffe
    2a04:      	b.ls	0x2db0 <generic_rawtp_process_event+0x2be0>
    2a08:      	mov	w8, #-0x3               // =-3
    2a0c:      	b	0x3040 <generic_rawtp_process_event+0x2e70>
    2a10:      	ldr	x8, [sp, #0x30]
    2a14:      	mov	x21, xzr
    2a18:      	mov	x23, xzr
    2a1c:      	tbz	w8, #0x4, 0x2af0 <generic_rawtp_process_event+0x2920>
    2a20:      	mov	w8, #0xe                // =14
    2a24:      	blr	x8
    2a28:      	cmn	x0, #0x16
    2a2c:      	b.ne	0x2a50 <generic_rawtp_process_event+0x2880>
    2a30:      	add	x2, x19, #0xe8
    2a34:      	mov	w8, #0x8                // =8
    2a38:      	mov	w9, #0x4                // =4
    2a3c:      	add	x10, sp, #0x88
    2a40:      	add	x0, sp, #0x88
    2a44:      	mov	w1, #0x8                // =8
    2a48:      	blr	x9
    2a4c:      	ldr	x0, [sp, #0x88]
    2a50:      	ldr	x8, [sp, #0x10]
    2a54:      	mov	x3, xzr
    2a58:      	add	x1, sp, #0xe0
    2a5c:      	add	x2, sp, #0x88
    2a60:      	ldr	x9, [x8, #0x60]
    2a64:      	ldr	x10, [x8, #0x8]
    2a68:      	ldr	x8, [sp, #0x38]
    2a6c:      	str	x21, [sp, #0x98]
    2a70:      	stp	x10, x8, [sp, #0x88]
    2a74:      	add	x8, sp, #0xd0
    2a78:      	add	x10, sp, #0x88
    2a7c:      	stp	x9, x0, [x8, #0x10]
    2a80:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    2a84:      	mov	w8, #0x2                // =2
    2a88:      	add	x9, sp, #0xe0
    2a8c:      	ldr	x0, [x0]
    2a90:      	blr	x8
    2a94:      	cbz	x0, 0x2b6c <generic_rawtp_process_event+0x299c>
    2a98:      	neg	w8, w0
    2a9c:      	adrp	x23, 0x2000 <generic_rawtp_process_event+0x1e30>
    2aa0:      	mov	w9, #0x1                // =1
    2aa4:      	strh	w8, [sp, #0x60]
    2aa8:      	mov	w8, #0x5                // =5
    2aac:      	add	x1, sp, #0x60
    2ab0:      	mov	w21, #0x1               // =1
    2ab4:      	strh	w8, [sp, #0x62]
    2ab8:      	mov	x8, #0x57               // =87
    2abc:      	movk	x8, #0x2, lsl #32
    2ac0:      	stur	x8, [sp, #0x64]
    2ac4:      	add	x8, sp, #0x60
    2ac8:      	ldr	x23, [x23]
    2acc:      	mov	x0, x23
    2ad0:      	blr	x9
    2ad4:      	cbz	x0, 0x2b48 <generic_rawtp_process_event+0x2978>
    2ad8:      	ldr	w8, [x0]
    2adc:      	add	w8, w8, #0x1
    2ae0:      	str	w8, [x0]
    2ae4:      	mov	w8, #-0x4               // =-4
    2ae8:      	b	0x3040 <generic_rawtp_process_event+0x2e70>
    2aec:      	mov	x23, xzr
    2af0:      	stp	w23, w23, [x22]
    2af4:      	add	x25, x23, #0x8
    2af8:      	b	0x3954 <generic_rawtp_process_event+0x3784>
    2afc:      	cmp	w8, #0x33
    2b00:      	b.eq	0x30a8 <generic_rawtp_process_event+0x2ed8>
    2b04:      	cmp	w8, #0x3c
    2b08:      	b.eq	0x2b74 <generic_rawtp_process_event+0x29a4>
    2b0c:      	cmp	w8, #0xff
    2b10:      	b.ne	0x3168 <generic_rawtp_process_event+0x2f98>
    2b14:      	mov	w8, #0x28               // =40
    2b18:      	b	0x30b4 <generic_rawtp_process_event+0x2ee4>
    2b1c:      	str	w21, [sp, #0xc8]
    2b20:      	mov	x3, xzr
    2b24:      	mov	w8, #0x2                // =2
    2b28:      	add	x9, sp, #0x60
    2b2c:      	add	x10, sp, #0xc8
    2b30:      	add	x1, sp, #0x60
    2b34:      	add	x2, sp, #0xc8
    2b38:      	mov	x0, x23
    2b3c:      	blr	x8
    2b40:      	mov	w8, #-0x4               // =-4
    2b44:      	b	0x2da0 <generic_rawtp_process_event+0x2bd0>
    2b48:      	str	w21, [sp, #0xd8]
    2b4c:      	mov	x3, xzr
    2b50:      	mov	w8, #0x2                // =2
    2b54:      	add	x9, sp, #0x60
    2b58:      	add	x10, sp, #0xd8
    2b5c:      	add	x1, sp, #0x60
    2b60:      	add	x2, sp, #0xd8
    2b64:      	mov	x0, x23
    2b68:      	blr	x8
    2b6c:      	mov	w8, #-0x4               // =-4
    2b70:      	b	0x3040 <generic_rawtp_process_event+0x2e70>
    2b74:      	ldrb	w8, [x24, #0x7]
    2b78:      	lsl	w8, w8, #3
    2b7c:      	b	0x30b0 <generic_rawtp_process_event+0x2ee0>
    2b80:      	mov	w25, #0x4               // =4
    2b84:      	b	0x395c <generic_rawtp_process_event+0x378c>
    2b88:      	mov	w9, #0x5e60             // =24160
    2b8c:      	b	0x2b9c <generic_rawtp_process_event+0x29cc>
    2b90:      	mov	w9, #0x5e68             // =24168
    2b94:      	b	0x2b9c <generic_rawtp_process_event+0x29cc>
    2b98:      	mov	w9, #0x5e50             // =24144
    2b9c:      	ldr	x8, [sp, #0x10]
    2ba0:      	add	x8, x8, x9
    2ba4:      	ldr	x8, [x8]
    2ba8:      	add	x21, sp, #0xd0
    2bac:      	mov	w25, #0x8               // =8
    2bb0:      	add	x9, sp, #0xd0
    2bb4:      	str	x8, [x21, #0x8]
    2bb8:      	mov	w8, #0x4                // =4
    2bbc:      	add	x10, sp, #0xd8
    2bc0:      	add	x0, sp, #0xd0
    2bc4:      	add	x2, sp, #0xd8
    2bc8:      	mov	w1, #0x8                // =8
    2bcc:      	blr	x8
    2bd0:      	ldr	x21, [x21]
    2bd4:      	tbz	w23, #0x5, 0x2d64 <generic_rawtp_process_event+0x2b94>
    2bd8:      	cmp	x21, #0x1, lsl #12      // =0x1000
    2bdc:      	b.lo	0x2d48 <generic_rawtp_process_event+0x2b78>
    2be0:      	ldr	x9, [sp, #0x18]
    2be4:      	mov	w8, #0x1                // =1
    2be8:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    2bec:      	add	x1, sp, #0xe0
    2bf0:      	str	w8, [x9]
    2bf4:      	str	wzr, [sp, #0xe0]
    2bf8:      	add	x9, sp, #0xe0
    2bfc:      	ldr	x0, [x0]
    2c00:      	blr	x8
    2c04:      	cbz	x0, 0x3044 <generic_rawtp_process_event+0x2e74>
    2c08:      	mov	w8, #0x18               // =24
    2c0c:      	mov	x29, x0
    2c10:      	str	w8, [x0]
    2c14:      	mov	w8, #0xe                // =14
    2c18:      	blr	x8
    2c1c:      	mov	x23, x29
    2c20:      	cmn	x0, #0x16
    2c24:      	str	x0, [x23, #0x10]!
    2c28:      	b.ne	0x2c50 <generic_rawtp_process_event+0x2a80>
    2c2c:      	add	x2, x19, #0xe8
    2c30:      	mov	w8, #0x8                // =8
    2c34:      	mov	w9, #0x4                // =4
    2c38:      	add	x10, sp, #0x88
    2c3c:      	add	x0, sp, #0x88
    2c40:      	mov	w1, #0x8                // =8
    2c44:      	blr	x9
    2c48:      	ldr	x8, [sp, #0x88]
    2c4c:      	str	x8, [x23]
    2c50:      	mov	w8, #0x7d               // =125
    2c54:      	blr	x8
    2c58:      	str	x0, [x29, #0x18]
    2c5c:      	add	x8, x29, #0x20
    2c60:      	ldr	x10, [sp, #0x18]
    2c64:      	mov	x25, xzr
    2c68:      	mov	w24, #0xa               // =10
    2c6c:      	str	x8, [sp, #0x30]
    2c70:      	ldp	x8, x9, [x23]
    2c74:      	stur	x8, [x10, #0x14]
    2c78:      	stur	x9, [x10, #0x1c]
    2c7c:      	subs	x8, x21, x25
    2c80:      	b.mi	0x31ac <generic_rawtp_process_event+0x2fdc>
    2c84:      	ldp	x0, x9, [sp, #0x30]
    2c88:      	add	x2, x25, x9
    2c8c:      	mov	w9, #0x7fe0             // =32736
    2c90:      	cmp	x8, x9
    2c94:      	csel	x23, x8, x9, lo
    2c98:      	mov	w8, #0x4                // =4
    2c9c:      	mov	w1, w23
    2ca0:      	blr	x8
    2ca4:      	tbnz	w0, #0x1f, 0x2d24 <generic_rawtp_process_event+0x2b54>
    2ca8:      	add	w8, w23, #0x20
    2cac:      	str	wzr, [sp, #0x88]
    2cb0:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    2cb4:      	add	x9, sp, #0x88
    2cb8:      	str	w8, [x29, #0x4]
    2cbc:      	mov	x22, x8
    2cc0:      	mov	w8, #0x1                // =1
    2cc4:      	add	x1, sp, #0x88
    2cc8:      	ldr	x0, [x0]
    2ccc:      	blr	x8
    2cd0:      	cbz	x0, 0x2d04 <generic_rawtp_process_event+0x2b34>
    2cd4:      	ldrb	w8, [x0, #0x28]
    2cd8:      	cbz	w8, 0x2d04 <generic_rawtp_process_event+0x2b34>
    2cdc:      	adrp	x1, 0x2000 <generic_rawtp_process_event+0x1e30>
    2ce0:      	mov	w8, #0x19               // =25
    2ce4:      	mov	w9, #-0x1               // =-1
    2ce8:      	ldr	x1, [x1]
    2cec:      	mov	x0, x19
    2cf0:      	mov	w2, #-0x1               // =-1
    2cf4:      	mov	x3, x29
    2cf8:      	mov	x4, x22
    2cfc:      	blr	x8
    2d00:      	b	0x2d20 <generic_rawtp_process_event+0x2b50>
    2d04:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    2d08:      	mov	x3, xzr
    2d0c:      	mov	w8, #0x82               // =130
    2d10:      	ldr	x0, [x0]
    2d14:      	mov	x1, x29
    2d18:      	mov	x2, x22
    2d1c:      	blr	x8
    2d20:      	tbz	w0, #0x1f, 0x2d28 <generic_rawtp_process_event+0x2b58>
    2d24:      	sxtw	x23, w0
    2d28:      	tbnz	w23, #0x1f, 0x31b4 <generic_rawtp_process_event+0x2fe4>
    2d2c:      	and	x8, x23, #0x7fffffff
    2d30:      	add	x25, x8, x25
    2d34:      	cmp	x25, x21
    2d38:      	b.eq	0x3200 <generic_rawtp_process_event+0x3030>
    2d3c:      	subs	w24, w24, #0x1
    2d40:      	b.ne	0x2c7c <generic_rawtp_process_event+0x2aac>
    2d44:      	b	0x356c <generic_rawtp_process_event+0x339c>
    2d48:      	ldr	x8, [sp, #0x18]
    2d4c:      	mov	w25, #0xc               // =12
    2d50:      	str	wzr, [x8]
    2d54:      	ldr	x8, [sp, #0xf8]
    2d58:      	add	x8, x24, x8
    2d5c:      	add	x8, x8, #0x8
    2d60:      	str	x8, [sp, #0x18]
    2d64:      	cmp	x21, #0xfff
    2d68:      	mov	w8, #0xfff              // =4095
    2d6c:      	ldr	x2, [sp, #0x38]
    2d70:      	csel	x23, x21, x8, lo
    2d74:      	ldr	x8, [sp, #0x18]
    2d78:      	mov	w1, w23
    2d7c:      	add	x0, x8, #0x8
    2d80:      	mov	w8, #0x4                // =4
    2d84:      	blr	x8
    2d88:      	tbnz	w0, #0x1f, 0x2d9c <generic_rawtp_process_event+0x2bcc>
    2d8c:      	ldr	x8, [sp, #0x18]
    2d90:      	add	x25, x25, x23
    2d94:      	stp	w21, w23, [x8]
    2d98:      	b	0x3954 <generic_rawtp_process_event+0x3784>
    2d9c:      	mov	w8, #-0x2               // =-2
    2da0:      	ldr	x9, [sp, #0x18]
    2da4:      	mov	w25, #0x4               // =4
    2da8:      	str	w8, [x9]
    2dac:      	b	0x3954 <generic_rawtp_process_event+0x3784>
    2db0:      	ldr	x8, [sp, #0xf8]
    2db4:      	mov	w9, #0x4                // =4
    2db8:      	mov	w1, w23
    2dbc:      	add	x25, x8, #0xc
    2dc0:      	ldr	x8, [sp, #0x88]
    2dc4:      	add	x0, x24, x25
    2dc8:      	ldr	x2, [sp, #0x88]
    2dcc:      	blr	x9
    2dd0:      	tbnz	w0, #0x1f, 0x303c <generic_rawtp_process_event+0x2e6c>
    2dd4:      	cmp	x21, #0x1
    2dd8:      	b.eq	0x2af0 <generic_rawtp_process_event+0x2920>
    2ddc:      	ldr	x8, [sp, #0x38]
    2de0:      	mov	w9, #0x4                // =4
    2de4:      	add	x10, sp, #0x88
    2de8:      	add	x0, sp, #0x88
    2dec:      	mov	w1, #0x10               // =16
    2df0:      	add	x2, x8, #0x10
    2df4:      	mov	w8, #0x10               // =16
    2df8:      	blr	x9
    2dfc:      	tbnz	w0, #0x1f, 0x303c <generic_rawtp_process_event+0x2e6c>
    2e00:      	ldr	x8, [sp, #0x90]
    2e04:      	cmp	x8, #0xffe
    2e08:      	b.hi	0x2a08 <generic_rawtp_process_event+0x2838>
    2e0c:      	add	x25, x23, x25
    2e10:      	mov	x29, x8
    2e14:      	ldr	x8, [sp, #0x88]
    2e18:      	mov	w9, #0x4                // =4
    2e1c:      	add	x0, x24, x25
    2e20:      	mov	x1, x29
    2e24:      	ldr	x2, [sp, #0x88]
    2e28:      	blr	x9
    2e2c:      	tbnz	w0, #0x1f, 0x303c <generic_rawtp_process_event+0x2e6c>
    2e30:      	add	x23, x29, x23
    2e34:      	cmp	x21, #0x3
    2e38:      	b.lo	0x2af0 <generic_rawtp_process_event+0x2920>
    2e3c:      	ldr	x8, [sp, #0x38]
    2e40:      	mov	w9, #0x4                // =4
    2e44:      	add	x10, sp, #0x88
    2e48:      	add	x0, sp, #0x88
    2e4c:      	mov	w1, #0x10               // =16
    2e50:      	add	x2, x8, #0x20
    2e54:      	mov	w8, #0x10               // =16
    2e58:      	blr	x9
    2e5c:      	tbnz	w0, #0x1f, 0x303c <generic_rawtp_process_event+0x2e6c>
    2e60:      	ldr	x8, [sp, #0x90]
    2e64:      	cmp	x8, #0xffe
    2e68:      	str	x8, [sp, #0x30]
    2e6c:      	b.hi	0x2a08 <generic_rawtp_process_event+0x2838>
    2e70:      	add	x25, x29, x25
    2e74:      	mov	w9, #0x4                // =4
    2e78:      	ldr	x1, [sp, #0x30]
    2e7c:      	and	x8, x25, #0x3fff
    2e80:      	add	x0, x24, x8
    2e84:      	ldr	x8, [sp, #0x88]
    2e88:      	ldr	x2, [sp, #0x88]
    2e8c:      	blr	x9
    2e90:      	tbnz	w0, #0x1f, 0x303c <generic_rawtp_process_event+0x2e6c>
    2e94:      	ldr	x8, [sp, #0x30]
    2e98:      	cmp	x21, #0x3
    2e9c:      	add	x23, x8, x23
    2ea0:      	b.eq	0x2af0 <generic_rawtp_process_event+0x2920>
    2ea4:      	ldr	x8, [sp, #0x38]
    2ea8:      	mov	w9, #0x4                // =4
    2eac:      	add	x10, sp, #0x88
    2eb0:      	add	x0, sp, #0x88
    2eb4:      	mov	w1, #0x10               // =16
    2eb8:      	add	x2, x8, #0x30
    2ebc:      	mov	w8, #0x10               // =16
    2ec0:      	blr	x9
    2ec4:      	tbnz	w0, #0x1f, 0x303c <generic_rawtp_process_event+0x2e6c>
    2ec8:      	ldr	x8, [sp, #0x90]
    2ecc:      	cmp	x8, #0xffe
    2ed0:      	str	x8, [sp, #0x18]
    2ed4:      	b.hi	0x2a08 <generic_rawtp_process_event+0x2838>
    2ed8:      	ldr	x8, [sp, #0x30]
    2edc:      	mov	w9, #0x4                // =4
    2ee0:      	ldr	x1, [sp, #0x18]
    2ee4:      	add	x25, x8, x25
    2ee8:      	and	x8, x25, #0x3fff
    2eec:      	add	x0, x24, x8
    2ef0:      	ldr	x8, [sp, #0x88]
    2ef4:      	ldr	x2, [sp, #0x88]
    2ef8:      	blr	x9
    2efc:      	tbnz	w0, #0x1f, 0x303c <generic_rawtp_process_event+0x2e6c>
    2f00:      	ldr	x8, [sp, #0x18]
    2f04:      	cmp	x21, #0x5
    2f08:      	add	x23, x8, x23
    2f0c:      	b.lo	0x2af0 <generic_rawtp_process_event+0x2920>
    2f10:      	ldr	x8, [sp, #0x38]
    2f14:      	mov	w9, #0x4                // =4
    2f18:      	add	x10, sp, #0x88
    2f1c:      	add	x0, sp, #0x88
    2f20:      	mov	w1, #0x10               // =16
    2f24:      	add	x2, x8, #0x40
    2f28:      	mov	w8, #0x10               // =16
    2f2c:      	blr	x9
    2f30:      	tbnz	w0, #0x1f, 0x303c <generic_rawtp_process_event+0x2e6c>
    2f34:      	ldr	x29, [sp, #0x90]
    2f38:      	cmp	x29, #0xffe
    2f3c:      	b.hi	0x2a08 <generic_rawtp_process_event+0x2838>
    2f40:      	ldr	x8, [sp, #0x18]
    2f44:      	mov	w9, #0x4                // =4
    2f48:      	mov	w1, w29
    2f4c:      	add	x25, x8, x25
    2f50:      	and	x8, x25, #0x3fff
    2f54:      	add	x0, x24, x8
    2f58:      	ldr	x8, [sp, #0x88]
    2f5c:      	ldr	x2, [sp, #0x88]
    2f60:      	blr	x9
    2f64:      	tbnz	w0, #0x1f, 0x303c <generic_rawtp_process_event+0x2e6c>
    2f68:      	add	x23, x29, x23
    2f6c:      	cmp	x21, #0x5
    2f70:      	b.eq	0x2af0 <generic_rawtp_process_event+0x2920>
    2f74:      	ldr	x8, [sp, #0x38]
    2f78:      	mov	w9, #0x4                // =4
    2f7c:      	add	x10, sp, #0x88
    2f80:      	add	x0, sp, #0x88
    2f84:      	mov	w1, #0x10               // =16
    2f88:      	add	x2, x8, #0x50
    2f8c:      	mov	w8, #0x10               // =16
    2f90:      	blr	x9
    2f94:      	tbnz	w0, #0x1f, 0x303c <generic_rawtp_process_event+0x2e6c>
    2f98:      	ldr	x8, [sp, #0x90]
    2f9c:      	cmp	x8, #0xffe
    2fa0:      	str	x8, [sp, #0x30]
    2fa4:      	b.hi	0x2a08 <generic_rawtp_process_event+0x2838>
    2fa8:      	add	x25, x29, x25
    2fac:      	mov	w9, #0x4                // =4
    2fb0:      	ldr	x1, [sp, #0x30]
    2fb4:      	and	x8, x25, #0x3fff
    2fb8:      	add	x0, x24, x8
    2fbc:      	ldr	x8, [sp, #0x88]
    2fc0:      	ldr	x2, [sp, #0x88]
    2fc4:      	blr	x9
    2fc8:      	tbnz	w0, #0x1f, 0x303c <generic_rawtp_process_event+0x2e6c>
    2fcc:      	ldr	x8, [sp, #0x30]
    2fd0:      	cmp	x21, #0x7
    2fd4:      	add	x23, x8, x23
    2fd8:      	b.lo	0x2af0 <generic_rawtp_process_event+0x2920>
    2fdc:      	ldr	x8, [sp, #0x38]
    2fe0:      	mov	w9, #0x4                // =4
    2fe4:      	add	x10, sp, #0x88
    2fe8:      	add	x0, sp, #0x88
    2fec:      	mov	w1, #0x10               // =16
    2ff0:      	add	x2, x8, #0x60
    2ff4:      	mov	w8, #0x10               // =16
    2ff8:      	blr	x9
    2ffc:      	tbnz	w0, #0x1f, 0x303c <generic_rawtp_process_event+0x2e6c>
    3000:      	ldr	x21, [sp, #0x90]
    3004:      	cmp	x21, #0xffe
    3008:      	b.hi	0x2a08 <generic_rawtp_process_event+0x2838>
    300c:      	ldr	x8, [sp, #0x30]
    3010:      	mov	w9, #0x4                // =4
    3014:      	mov	w1, w21
    3018:      	add	x8, x8, x25
    301c:      	and	x8, x8, #0x3fff
    3020:      	add	x0, x24, x8
    3024:      	ldr	x8, [sp, #0x88]
    3028:      	ldr	x2, [sp, #0x88]
    302c:      	blr	x9
    3030:      	tbnz	w0, #0x1f, 0x303c <generic_rawtp_process_event+0x2e6c>
    3034:      	add	x23, x21, x23
    3038:      	b	0x2af0 <generic_rawtp_process_event+0x2920>
    303c:      	mov	w8, #-0x2               // =-2
    3040:      	str	w8, [x22]
    3044:      	mov	w25, #0x4               // =4
    3048:      	b	0x3954 <generic_rawtp_process_event+0x3784>
    304c:      	mov	x21, #-0x1              // =-1
    3050:      	b	0x3058 <generic_rawtp_process_event+0x2e88>
    3054:      	mov	x21, x24
    3058:      	str	wzr, [sp, #0x88]
    305c:      	adrp	x0, 0x3000 <generic_rawtp_process_event+0x2e30>
    3060:      	mov	w8, #0x1                // =1
    3064:      	add	x9, sp, #0x88
    3068:      	ldr	x0, [x0]
    306c:      	add	x1, sp, #0x88
    3070:      	blr	x8
    3074:      	cbz	x0, 0x341c <generic_rawtp_process_event+0x324c>
    3078:      	cmn	x21, #0xc
    307c:      	b.gt	0x318c <generic_rawtp_process_event+0x2fbc>
    3080:      	cmn	x21, #0x1c
    3084:      	b.eq	0x33e8 <generic_rawtp_process_event+0x3218>
    3088:      	cmn	x21, #0x16
    308c:      	b.eq	0x3400 <generic_rawtp_process_event+0x3230>
    3090:      	cmn	x21, #0x10
    3094:      	b.ne	0x33f8 <generic_rawtp_process_event+0x3228>
    3098:      	add	x8, x0, #0x558
    309c:      	b	0x340c <generic_rawtp_process_event+0x323c>
    30a0:      	mov	x21, x22
    30a4:      	b	0x341c <generic_rawtp_process_event+0x324c>
    30a8:      	ldrb	w8, [x24, #0x7]
    30ac:      	lsl	w8, w8, #2
    30b0:      	add	w8, w8, #0x8
    30b4:      	strh	w8, [x24, #0x2]
    30b8:      	ldrh	w9, [x24]
    30bc:      	ldrb	w25, [x24, #0x6]
    30c0:      	add	w8, w9, w8
    30c4:      	cmp	w25, #0x3c
    30c8:      	strh	w8, [x24]
    30cc:      	b.hi	0x3184 <generic_rawtp_process_event+0x2fb4>
    30d0:      	mov	x10, #0x1               // =1
    30d4:      	mov	w9, #0x1                // =1
    30d8:      	movk	x10, #0x1800, lsl #32
    30dc:      	lsl	x9, x9, x25
    30e0:      	movk	x10, #0x1008, lsl #48
    30e4:      	tst	x9, x10
    30e8:      	b.eq	0x3184 <generic_rawtp_process_event+0x2fb4>
    30ec:      	strb	w25, [x24, #0x5]
    30f0:      	add	x8, x22, w8, uxth
    30f4:      	mov	w9, #0x2                // =2
    30f8:      	mov	w10, #0x4               // =4
    30fc:      	mov	x0, x23
    3100:      	mov	w1, #0x2                // =2
    3104:      	ldrh	w8, [x24]
    3108:      	add	x2, x22, x8
    310c:      	blr	x10
    3110:      	tbnz	x0, #0x3f, 0x37d0 <generic_rawtp_process_event+0x3600>
    3114:      	ldrb	w8, [x24, #0x5]
    3118:      	cmp	w8, #0x32
    311c:      	b.gt	0x313c <generic_rawtp_process_event+0x2f6c>
    3120:      	cbz	w8, 0x315c <generic_rawtp_process_event+0x2f8c>
    3124:      	cmp	w8, #0x2b
    3128:      	b.eq	0x315c <generic_rawtp_process_event+0x2f8c>
    312c:      	cmp	w8, #0x2c
    3130:      	b.ne	0x32c8 <generic_rawtp_process_event+0x30f8>
    3134:      	mov	w8, #0x8                // =8
    3138:      	b	0x3214 <generic_rawtp_process_event+0x3044>
    313c:      	cmp	w8, #0x33
    3140:      	b.eq	0x3208 <generic_rawtp_process_event+0x3038>
    3144:      	cmp	w8, #0x3c
    3148:      	b.eq	0x315c <generic_rawtp_process_event+0x2f8c>
    314c:      	cmp	w8, #0xff
    3150:      	b.ne	0x32c8 <generic_rawtp_process_event+0x30f8>
    3154:      	mov	w8, #0x28               // =40
    3158:      	b	0x3214 <generic_rawtp_process_event+0x3044>
    315c:      	ldrb	w8, [x24, #0x7]
    3160:      	lsl	w8, w8, #3
    3164:      	b	0x3210 <generic_rawtp_process_event+0x3040>
    3168:      	ldrh	w8, [x24, #0x2]
    316c:      	ldrh	w9, [x24]
    3170:      	ldrb	w25, [x24, #0x6]
    3174:      	add	w8, w9, w8
    3178:      	cmp	w25, #0x3c
    317c:      	strh	w8, [x24]
    3180:      	b.ls	0x30d0 <generic_rawtp_process_event+0x2f00>
    3184:      	strh	w8, [sp, #0xc8]
    3188:      	b	0x37d4 <generic_rawtp_process_event+0x3604>
    318c:      	cmn	x21, #0xb
    3190:      	b.eq	0x33f0 <generic_rawtp_process_event+0x3220>
    3194:      	cmn	x21, #0x7
    3198:      	b.eq	0x3408 <generic_rawtp_process_event+0x3238>
    319c:      	cmn	x21, #0x2
    31a0:      	b.ne	0x33f8 <generic_rawtp_process_event+0x3228>
    31a4:      	add	x8, x0, #0x548
    31a8:      	b	0x340c <generic_rawtp_process_event+0x323c>
    31ac:      	mov	x25, #-0x1              // =-1
    31b0:      	b	0x31b8 <generic_rawtp_process_event+0x2fe8>
    31b4:      	mov	x25, x23
    31b8:      	str	wzr, [sp, #0x88]
    31bc:      	adrp	x0, 0x3000 <generic_rawtp_process_event+0x2e30>
    31c0:      	mov	w8, #0x1                // =1
    31c4:      	add	x9, sp, #0x88
    31c8:      	ldr	x0, [x0]
    31cc:      	add	x1, sp, #0x88
    31d0:      	blr	x8
    31d4:      	cbz	x0, 0x356c <generic_rawtp_process_event+0x339c>
    31d8:      	cmn	x25, #0xc
    31dc:      	b.gt	0x32e8 <generic_rawtp_process_event+0x3118>
    31e0:      	cmn	x25, #0x1c
    31e4:      	b.eq	0x3538 <generic_rawtp_process_event+0x3368>
    31e8:      	cmn	x25, #0x16
    31ec:      	b.eq	0x3550 <generic_rawtp_process_event+0x3380>
    31f0:      	cmn	x25, #0x10
    31f4:      	b.ne	0x3548 <generic_rawtp_process_event+0x3378>
    31f8:      	add	x8, x0, #0x558
    31fc:      	b	0x355c <generic_rawtp_process_event+0x338c>
    3200:      	mov	x25, x21
    3204:      	b	0x356c <generic_rawtp_process_event+0x339c>
    3208:      	ldrb	w8, [x24, #0x7]
    320c:      	lsl	w8, w8, #2
    3210:      	add	w8, w8, #0x8
    3214:      	strh	w8, [x24, #0x2]
    3218:      	ldrh	w9, [x24]
    321c:      	ldrb	w25, [x24, #0x6]
    3220:      	add	w8, w9, w8
    3224:      	cmp	w25, #0x3c
    3228:      	strh	w8, [x24]
    322c:      	b.hi	0x3a70 <generic_rawtp_process_event+0x38a0>
    3230:      	mov	x10, #0x1               // =1
    3234:      	mov	w9, #0x1                // =1
    3238:      	movk	x10, #0x1800, lsl #32
    323c:      	lsl	x9, x9, x25
    3240:      	movk	x10, #0x1008, lsl #48
    3244:      	tst	x9, x10
    3248:      	b.eq	0x3a70 <generic_rawtp_process_event+0x38a0>
    324c:      	strb	w25, [x24, #0x5]
    3250:      	add	x8, x22, w8, uxth
    3254:      	mov	w9, #0x2                // =2
    3258:      	mov	w10, #0x4               // =4
    325c:      	mov	x0, x23
    3260:      	mov	w1, #0x2                // =2
    3264:      	ldrh	w8, [x24]
    3268:      	add	x2, x22, x8
    326c:      	blr	x10
    3270:      	tbnz	x0, #0x3f, 0x37d0 <generic_rawtp_process_event+0x3600>
    3274:      	ldrb	w8, [x24, #0x5]
    3278:      	cmp	w8, #0x32
    327c:      	b.gt	0x329c <generic_rawtp_process_event+0x30cc>
    3280:      	cbz	w8, 0x32bc <generic_rawtp_process_event+0x30ec>
    3284:      	cmp	w8, #0x2b
    3288:      	b.eq	0x32bc <generic_rawtp_process_event+0x30ec>
    328c:      	cmp	w8, #0x2c
    3290:      	b.ne	0x33c8 <generic_rawtp_process_event+0x31f8>
    3294:      	mov	w8, #0x8                // =8
    3298:      	b	0x3314 <generic_rawtp_process_event+0x3144>
    329c:      	cmp	w8, #0x33
    32a0:      	b.eq	0x3308 <generic_rawtp_process_event+0x3138>
    32a4:      	cmp	w8, #0x3c
    32a8:      	b.eq	0x32bc <generic_rawtp_process_event+0x30ec>
    32ac:      	cmp	w8, #0xff
    32b0:      	b.ne	0x33c8 <generic_rawtp_process_event+0x31f8>
    32b4:      	mov	w8, #0x28               // =40
    32b8:      	b	0x3314 <generic_rawtp_process_event+0x3144>
    32bc:      	ldrb	w8, [x24, #0x7]
    32c0:      	lsl	w8, w8, #3
    32c4:      	b	0x3310 <generic_rawtp_process_event+0x3140>
    32c8:      	ldrh	w8, [x24, #0x2]
    32cc:      	ldrh	w9, [x24]
    32d0:      	ldrb	w25, [x24, #0x6]
    32d4:      	add	w8, w9, w8
    32d8:      	cmp	w25, #0x3c
    32dc:      	strh	w8, [x24]
    32e0:      	b.ls	0x3230 <generic_rawtp_process_event+0x3060>
    32e4:      	b	0x3a70 <generic_rawtp_process_event+0x38a0>
    32e8:      	cmn	x25, #0xb
    32ec:      	b.eq	0x3540 <generic_rawtp_process_event+0x3370>
    32f0:      	cmn	x25, #0x7
    32f4:      	b.eq	0x3558 <generic_rawtp_process_event+0x3388>
    32f8:      	cmn	x25, #0x2
    32fc:      	b.ne	0x3548 <generic_rawtp_process_event+0x3378>
    3300:      	add	x8, x0, #0x548
    3304:      	b	0x355c <generic_rawtp_process_event+0x338c>
    3308:      	ldrb	w8, [x24, #0x7]
    330c:      	lsl	w8, w8, #2
    3310:      	add	w8, w8, #0x8
    3314:      	strh	w8, [x24, #0x2]
    3318:      	ldrh	w9, [x24]
    331c:      	ldrb	w25, [x24, #0x6]
    3320:      	add	w8, w9, w8
    3324:      	cmp	w25, #0x3c
    3328:      	strh	w8, [x24]
    332c:      	b.hi	0x3a70 <generic_rawtp_process_event+0x38a0>
    3330:      	mov	x10, #0x1               // =1
    3334:      	mov	w9, #0x1                // =1
    3338:      	movk	x10, #0x1800, lsl #32
    333c:      	lsl	x9, x9, x25
    3340:      	movk	x10, #0x1008, lsl #48
    3344:      	tst	x9, x10
    3348:      	b.eq	0x3a70 <generic_rawtp_process_event+0x38a0>
    334c:      	strb	w25, [x24, #0x5]
    3350:      	add	x8, x22, w8, uxth
    3354:      	mov	w9, #0x2                // =2
    3358:      	mov	w10, #0x4               // =4
    335c:      	mov	x0, x23
    3360:      	mov	w1, #0x2                // =2
    3364:      	ldrh	w8, [x24]
    3368:      	add	x2, x22, x8
    336c:      	blr	x10
    3370:      	tbnz	x0, #0x3f, 0x37d0 <generic_rawtp_process_event+0x3600>
    3374:      	ldrb	w8, [x24, #0x5]
    3378:      	cmp	w8, #0x32
    337c:      	b.gt	0x339c <generic_rawtp_process_event+0x31cc>
    3380:      	cbz	w8, 0x33bc <generic_rawtp_process_event+0x31ec>
    3384:      	cmp	w8, #0x2b
    3388:      	b.eq	0x33bc <generic_rawtp_process_event+0x31ec>
    338c:      	cmp	w8, #0x2c
    3390:      	b.ne	0x3518 <generic_rawtp_process_event+0x3348>
    3394:      	mov	w8, #0x8                // =8
    3398:      	b	0x3464 <generic_rawtp_process_event+0x3294>
    339c:      	cmp	w8, #0x33
    33a0:      	b.eq	0x3458 <generic_rawtp_process_event+0x3288>
    33a4:      	cmp	w8, #0x3c
    33a8:      	b.eq	0x33bc <generic_rawtp_process_event+0x31ec>
    33ac:      	cmp	w8, #0xff
    33b0:      	b.ne	0x3518 <generic_rawtp_process_event+0x3348>
    33b4:      	mov	w8, #0x28               // =40
    33b8:      	b	0x3464 <generic_rawtp_process_event+0x3294>
    33bc:      	ldrb	w8, [x24, #0x7]
    33c0:      	lsl	w8, w8, #3
    33c4:      	b	0x3460 <generic_rawtp_process_event+0x3290>
    33c8:      	ldrh	w8, [x24, #0x2]
    33cc:      	ldrh	w9, [x24]
    33d0:      	ldrb	w25, [x24, #0x6]
    33d4:      	add	w8, w9, w8
    33d8:      	cmp	w25, #0x3c
    33dc:      	strh	w8, [x24]
    33e0:      	b.ls	0x3330 <generic_rawtp_process_event+0x3160>
    33e4:      	b	0x3a70 <generic_rawtp_process_event+0x38a0>
    33e8:      	add	x8, x0, #0x568
    33ec:      	b	0x340c <generic_rawtp_process_event+0x323c>
    33f0:      	add	x8, x0, #0x570
    33f4:      	b	0x340c <generic_rawtp_process_event+0x323c>
    33f8:      	add	x8, x0, #0x540
    33fc:      	b	0x340c <generic_rawtp_process_event+0x323c>
    3400:      	add	x8, x0, #0x560
    3404:      	b	0x340c <generic_rawtp_process_event+0x323c>
    3408:      	add	x8, x0, #0x550
    340c:      	ldaxr	x9, [x8]
    3410:      	add	x9, x9, #0x1
    3414:      	stlxr	w10, x9, [x8]
    3418:      	cbnz	w10, 0x340c <generic_rawtp_process_event+0x323c>
    341c:      	tbnz	w21, #0x1f, 0x3438 <generic_rawtp_process_event+0x3268>
    3420:      	ldr	x8, [sp, #0x38]
    3424:      	cmn	x22, #0x1
    3428:      	stur	xzr, [x8, #0x4]
    342c:      	sub	w8, w22, w21
    3430:      	csel	w8, wzr, w8, eq
    3434:      	b	0x3448 <generic_rawtp_process_event+0x3278>
    3438:      	ldr	x9, [sp, #0x38]
    343c:      	mov	w8, wzr
    3440:      	stp	w21, wzr, [x9, #0x4]
    3444:      	mov	w21, wzr
    3448:      	ldr	x9, [sp, #0x38]
    344c:      	mov	w25, #0x24              // =36
    3450:      	stp	w8, w21, [x9, #0xc]
    3454:      	b	0x395c <generic_rawtp_process_event+0x378c>
    3458:      	ldrb	w8, [x24, #0x7]
    345c:      	lsl	w8, w8, #2
    3460:      	add	w8, w8, #0x8
    3464:      	strh	w8, [x24, #0x2]
    3468:      	ldrh	w9, [x24]
    346c:      	ldrb	w25, [x24, #0x6]
    3470:      	add	w8, w9, w8
    3474:      	cmp	w25, #0x3c
    3478:      	strh	w8, [x24]
    347c:      	b.hi	0x3a70 <generic_rawtp_process_event+0x38a0>
    3480:      	mov	x10, #0x1               // =1
    3484:      	mov	w9, #0x1                // =1
    3488:      	movk	x10, #0x1800, lsl #32
    348c:      	lsl	x9, x9, x25
    3490:      	movk	x10, #0x1008, lsl #48
    3494:      	tst	x9, x10
    3498:      	b.eq	0x3a70 <generic_rawtp_process_event+0x38a0>
    349c:      	strb	w25, [x24, #0x5]
    34a0:      	add	x8, x22, w8, uxth
    34a4:      	mov	w9, #0x2                // =2
    34a8:      	mov	w10, #0x4               // =4
    34ac:      	mov	x0, x23
    34b0:      	mov	w1, #0x2                // =2
    34b4:      	ldrh	w8, [x24]
    34b8:      	add	x2, x22, x8
    34bc:      	blr	x10
    34c0:      	tbnz	x0, #0x3f, 0x37d0 <generic_rawtp_process_event+0x3600>
    34c4:      	ldrb	w8, [x24, #0x5]
    34c8:      	cmp	w8, #0x32
    34cc:      	b.gt	0x34ec <generic_rawtp_process_event+0x331c>
    34d0:      	cbz	w8, 0x350c <generic_rawtp_process_event+0x333c>
    34d4:      	cmp	w8, #0x2b
    34d8:      	b.eq	0x350c <generic_rawtp_process_event+0x333c>
    34dc:      	cmp	w8, #0x2c
    34e0:      	b.ne	0x3668 <generic_rawtp_process_event+0x3498>
    34e4:      	mov	w8, #0x8                // =8
    34e8:      	b	0x35b4 <generic_rawtp_process_event+0x33e4>
    34ec:      	cmp	w8, #0x33
    34f0:      	b.eq	0x35a8 <generic_rawtp_process_event+0x33d8>
    34f4:      	cmp	w8, #0x3c
    34f8:      	b.eq	0x350c <generic_rawtp_process_event+0x333c>
    34fc:      	cmp	w8, #0xff
    3500:      	b.ne	0x3668 <generic_rawtp_process_event+0x3498>
    3504:      	mov	w8, #0x28               // =40
    3508:      	b	0x35b4 <generic_rawtp_process_event+0x33e4>
    350c:      	ldrb	w8, [x24, #0x7]
    3510:      	lsl	w8, w8, #3
    3514:      	b	0x35b0 <generic_rawtp_process_event+0x33e0>
    3518:      	ldrh	w8, [x24, #0x2]
    351c:      	ldrh	w9, [x24]
    3520:      	ldrb	w25, [x24, #0x6]
    3524:      	add	w8, w9, w8
    3528:      	cmp	w25, #0x3c
    352c:      	strh	w8, [x24]
    3530:      	b.ls	0x3480 <generic_rawtp_process_event+0x32b0>
    3534:      	b	0x3a70 <generic_rawtp_process_event+0x38a0>
    3538:      	add	x8, x0, #0x568
    353c:      	b	0x355c <generic_rawtp_process_event+0x338c>
    3540:      	add	x8, x0, #0x570
    3544:      	b	0x355c <generic_rawtp_process_event+0x338c>
    3548:      	add	x8, x0, #0x540
    354c:      	b	0x355c <generic_rawtp_process_event+0x338c>
    3550:      	add	x8, x0, #0x560
    3554:      	b	0x355c <generic_rawtp_process_event+0x338c>
    3558:      	add	x8, x0, #0x550
    355c:      	ldaxr	x9, [x8]
    3560:      	add	x9, x9, #0x1
    3564:      	stlxr	w10, x9, [x8]
    3568:      	cbnz	w10, 0x355c <generic_rawtp_process_event+0x338c>
    356c:      	tbnz	w25, #0x1f, 0x3588 <generic_rawtp_process_event+0x33b8>
    3570:      	ldr	x8, [sp, #0x18]
    3574:      	cmn	x21, #0x1
    3578:      	stur	xzr, [x8, #0x4]
    357c:      	sub	w8, w21, w25
    3580:      	csel	w8, wzr, w8, eq
    3584:      	b	0x3598 <generic_rawtp_process_event+0x33c8>
    3588:      	ldr	x9, [sp, #0x18]
    358c:      	mov	w8, wzr
    3590:      	stp	w25, wzr, [x9, #0x4]
    3594:      	mov	w25, wzr
    3598:      	ldr	x9, [sp, #0x18]
    359c:      	stp	w8, w25, [x9, #0xc]
    35a0:      	mov	w25, #0x24              // =36
    35a4:      	b	0x3954 <generic_rawtp_process_event+0x3784>
    35a8:      	ldrb	w8, [x24, #0x7]
    35ac:      	lsl	w8, w8, #2
    35b0:      	add	w8, w8, #0x8
    35b4:      	strh	w8, [x24, #0x2]
    35b8:      	ldrh	w9, [x24]
    35bc:      	ldrb	w25, [x24, #0x6]
    35c0:      	add	w8, w9, w8
    35c4:      	cmp	w25, #0x3c
    35c8:      	strh	w8, [x24]
    35cc:      	b.hi	0x3a70 <generic_rawtp_process_event+0x38a0>
    35d0:      	mov	x10, #0x1               // =1
    35d4:      	mov	w9, #0x1                // =1
    35d8:      	movk	x10, #0x1800, lsl #32
    35dc:      	lsl	x9, x9, x25
    35e0:      	movk	x10, #0x1008, lsl #48
    35e4:      	tst	x9, x10
    35e8:      	b.eq	0x3a70 <generic_rawtp_process_event+0x38a0>
    35ec:      	strb	w25, [x24, #0x5]
    35f0:      	add	x8, x22, w8, uxth
    35f4:      	mov	w9, #0x2                // =2
    35f8:      	mov	w10, #0x4               // =4
    35fc:      	mov	x0, x23
    3600:      	mov	w1, #0x2                // =2
    3604:      	ldrh	w8, [x24]
    3608:      	add	x2, x22, x8
    360c:      	blr	x10
    3610:      	tbnz	x0, #0x3f, 0x37d0 <generic_rawtp_process_event+0x3600>
    3614:      	ldrb	w8, [x24, #0x5]
    3618:      	cmp	w8, #0x32
    361c:      	b.gt	0x363c <generic_rawtp_process_event+0x346c>
    3620:      	cbz	w8, 0x365c <generic_rawtp_process_event+0x348c>
    3624:      	cmp	w8, #0x2b
    3628:      	b.eq	0x365c <generic_rawtp_process_event+0x348c>
    362c:      	cmp	w8, #0x2c
    3630:      	b.ne	0x3748 <generic_rawtp_process_event+0x3578>
    3634:      	mov	w8, #0x8                // =8
    3638:      	b	0x3694 <generic_rawtp_process_event+0x34c4>
    363c:      	cmp	w8, #0x33
    3640:      	b.eq	0x3688 <generic_rawtp_process_event+0x34b8>
    3644:      	cmp	w8, #0x3c
    3648:      	b.eq	0x365c <generic_rawtp_process_event+0x348c>
    364c:      	cmp	w8, #0xff
    3650:      	b.ne	0x3748 <generic_rawtp_process_event+0x3578>
    3654:      	mov	w8, #0x28               // =40
    3658:      	b	0x3694 <generic_rawtp_process_event+0x34c4>
    365c:      	ldrb	w8, [x24, #0x7]
    3660:      	lsl	w8, w8, #3
    3664:      	b	0x3690 <generic_rawtp_process_event+0x34c0>
    3668:      	ldrh	w8, [x24, #0x2]
    366c:      	ldrh	w9, [x24]
    3670:      	ldrb	w25, [x24, #0x6]
    3674:      	add	w8, w9, w8
    3678:      	cmp	w25, #0x3c
    367c:      	strh	w8, [x24]
    3680:      	b.ls	0x35d0 <generic_rawtp_process_event+0x3400>
    3684:      	b	0x3a70 <generic_rawtp_process_event+0x38a0>
    3688:      	ldrb	w8, [x24, #0x7]
    368c:      	lsl	w8, w8, #2
    3690:      	add	w8, w8, #0x8
    3694:      	strh	w8, [x24, #0x2]
    3698:      	ldrh	w9, [x24]
    369c:      	ldrb	w25, [x24, #0x6]
    36a0:      	add	w8, w9, w8
    36a4:      	cmp	w25, #0x3c
    36a8:      	strh	w8, [x24]
    36ac:      	b.hi	0x3a70 <generic_rawtp_process_event+0x38a0>
    36b0:      	mov	x10, #0x1               // =1
    36b4:      	mov	w9, #0x1                // =1
    36b8:      	movk	x10, #0x1800, lsl #32
    36bc:      	lsl	x9, x9, x25
    36c0:      	movk	x10, #0x1008, lsl #48
    36c4:      	tst	x9, x10
    36c8:      	b.eq	0x3a70 <generic_rawtp_process_event+0x38a0>
    36cc:      	strb	w25, [x24, #0x5]
    36d0:      	add	x8, x22, w8, uxth
    36d4:      	mov	w9, #0x2                // =2
    36d8:      	mov	w10, #0x4               // =4
    36dc:      	mov	x0, x23
    36e0:      	mov	w1, #0x2                // =2
    36e4:      	ldrh	w8, [x24]
    36e8:      	add	x2, x22, x8
    36ec:      	blr	x10
    36f0:      	tbnz	x0, #0x3f, 0x37d0 <generic_rawtp_process_event+0x3600>
    36f4:      	ldrb	w8, [x24, #0x5]
    36f8:      	cmp	w8, #0x32
    36fc:      	b.gt	0x371c <generic_rawtp_process_event+0x354c>
    3700:      	cbz	w8, 0x373c <generic_rawtp_process_event+0x356c>
    3704:      	cmp	w8, #0x2b
    3708:      	b.eq	0x373c <generic_rawtp_process_event+0x356c>
    370c:      	cmp	w8, #0x2c
    3710:      	b.ne	0x3a54 <generic_rawtp_process_event+0x3884>
    3714:      	mov	w8, #0x8                // =8
    3718:      	b	0x3774 <generic_rawtp_process_event+0x35a4>
    371c:      	cmp	w8, #0x33
    3720:      	b.eq	0x3768 <generic_rawtp_process_event+0x3598>
    3724:      	cmp	w8, #0x3c
    3728:      	b.eq	0x373c <generic_rawtp_process_event+0x356c>
    372c:      	cmp	w8, #0xff
    3730:      	b.ne	0x3a54 <generic_rawtp_process_event+0x3884>
    3734:      	mov	w8, #0x28               // =40
    3738:      	b	0x3774 <generic_rawtp_process_event+0x35a4>
    373c:      	ldrb	w8, [x24, #0x7]
    3740:      	lsl	w8, w8, #3
    3744:      	b	0x3770 <generic_rawtp_process_event+0x35a0>
    3748:      	ldrh	w8, [x24, #0x2]
    374c:      	ldrh	w9, [x24]
    3750:      	ldrb	w25, [x24, #0x6]
    3754:      	add	w8, w9, w8
    3758:      	cmp	w25, #0x3c
    375c:      	strh	w8, [x24]
    3760:      	b.ls	0x36b0 <generic_rawtp_process_event+0x34e0>
    3764:      	b	0x3a70 <generic_rawtp_process_event+0x38a0>
    3768:      	ldrb	w8, [x24, #0x7]
    376c:      	lsl	w8, w8, #2
    3770:      	add	w8, w8, #0x8
    3774:      	strh	w8, [x24, #0x2]
    3778:      	ldrh	w9, [x24]
    377c:      	ldrb	w25, [x24, #0x6]
    3780:      	add	w8, w9, w8
    3784:      	cmp	w25, #0x3c
    3788:      	strh	w8, [x24]
    378c:      	b.hi	0x3a70 <generic_rawtp_process_event+0x38a0>
    3790:      	mov	x10, #0x1               // =1
    3794:      	mov	w9, #0x1                // =1
    3798:      	movk	x10, #0x1800, lsl #32
    379c:      	lsl	x9, x9, x25
    37a0:      	movk	x10, #0x1008, lsl #48
    37a4:      	tst	x9, x10
    37a8:      	b.eq	0x3a70 <generic_rawtp_process_event+0x38a0>
    37ac:      	strb	w25, [x24, #0x5]
    37b0:      	add	x8, x22, w8, uxth
    37b4:      	mov	w9, #0x2                // =2
    37b8:      	mov	w10, #0x4               // =4
    37bc:      	mov	x0, x23
    37c0:      	mov	w1, #0x2                // =2
    37c4:      	ldrh	w8, [x24]
    37c8:      	add	x2, x22, x8
    37cc:      	blr	x10
    37d0:      	mov	w25, wzr
    37d4:      	ldr	x22, [sp, #0x18]
    37d8:      	mov	w8, #0xa                // =10
    37dc:      	strb	w25, [sp, #0x78]
    37e0:      	add	x2, x29, #0x8
    37e4:      	mov	w23, #0x10              // =16
    37e8:      	mov	w1, #0x10               // =16
    37ec:      	mov	w24, #0x4               // =4
    37f0:      	strh	w25, [x22, #0x24]
    37f4:      	strh	w8, [x22, #0x26]
    37f8:      	mov	w8, #0x4                // =4
    37fc:      	mov	x0, x22
    3800:      	blr	x8
    3804:      	add	x0, x22, #0x10
    3808:      	add	x2, x29, #0x18
    380c:      	mov	w1, #0x10               // =16
    3810:      	blr	x24
    3814:      	cmp	w25, #0x11
    3818:      	b.eq	0x385c <generic_rawtp_process_event+0x368c>
    381c:      	cmp	w25, #0x6
    3820:      	b.ne	0x389c <generic_rawtp_process_event+0x36cc>
    3824:      	ldr	x8, [sp, #0x88]
    3828:      	ldrh	w9, [sp, #0xc8]
    382c:      	mov	w24, #0x2               // =2
    3830:      	mov	w1, #0x2                // =2
    3834:      	mov	w25, #0x4               // =4
    3838:      	add	x23, x8, x9
    383c:      	ldr	x22, [sp, #0x18]
    3840:      	add	x0, x22, #0x20
    3844:      	mov	w8, #0x4                // =4
    3848:      	mov	x2, x23
    384c:      	blr	x8
    3850:      	add	x0, x22, #0x22
    3854:      	add	x2, x23, #0x2
    3858:      	b	0x3890 <generic_rawtp_process_event+0x36c0>
    385c:      	ldr	x8, [sp, #0x88]
    3860:      	ldrh	w9, [sp, #0xc8]
    3864:      	mov	w24, #0x2               // =2
    3868:      	mov	w1, #0x2                // =2
    386c:      	mov	w25, #0x4               // =4
    3870:      	add	x23, x8, x9
    3874:      	ldr	x22, [sp, #0x18]
    3878:      	add	x0, x22, #0x20
    387c:      	mov	w8, #0x4                // =4
    3880:      	mov	x2, x23
    3884:      	blr	x8
    3888:      	add	x0, x22, #0x22
    388c:      	add	x2, x23, #0x2
    3890:      	mov	w1, #0x2                // =2
    3894:      	blr	x25
    3898:      	b	0x38a4 <generic_rawtp_process_event+0x36d4>
    389c:      	ldr	x8, [sp, #0x18]
    38a0:      	str	wzr, [x8, #0x20]
    38a4:      	ldr	x9, [sp, #0x18]
    38a8:      	add	x2, x21, #0xe0
    38ac:      	add	x10, sp, #0xe0
    38b0:      	add	x0, sp, #0xe0
    38b4:      	ldrh	w8, [x9, #0x20]
    38b8:      	mov	w1, #0x8                // =8
    38bc:      	rev	w8, w8
    38c0:      	lsr	w8, w8, #16
    38c4:      	strh	w8, [x9, #0x20]
    38c8:      	ldrh	w8, [x9, #0x22]
    38cc:      	rev	w8, w8
    38d0:      	lsr	w8, w8, #16
    38d4:      	strh	w8, [x9, #0x22]
    38d8:      	mov	w8, #0x8                // =8
    38dc:      	mov	w9, #0x4                // =4
    38e0:      	blr	x9
    38e4:      	add	x8, sp, #0xd0
    38e8:      	ldr	x8, [x8, #0x10]
    38ec:      	cbz	x8, 0x3950 <generic_rawtp_process_event+0x3780>
    38f0:      	add	x8, x8, #0x5
    38f4:      	mov	w9, #0x8                // =8
    38f8:      	add	x10, sp, #0x60
    38fc:      	mov	w11, #0x4               // =4
    3900:      	add	x22, sp, #0xd0
    3904:      	ldr	x8, [x22, #0x10]
    3908:      	add	x0, sp, #0x60
    390c:      	mov	w1, #0x8                // =8
    3910:      	mov	w21, #0x4               // =4
    3914:      	add	x2, x8, #0x5
    3918:      	blr	x11
    391c:      	ldr	x8, [x22, #0x10]
    3920:      	ldr	x9, [sp, #0x60]
    3924:      	mov	w1, #0x4                // =4
    3928:      	add	x23, x8, x9, lsl #3
    392c:      	ldr	x22, [sp, #0x18]
    3930:      	add	x0, x22, #0x38
    3934:      	mov	w8, #0x4                // =4
    3938:      	add	x2, x23, #0x44
    393c:      	blr	x8
    3940:      	add	x0, x22, #0x3c
    3944:      	add	x2, x23, #0x45
    3948:      	mov	w1, #0x4                // =4
    394c:      	blr	x21
    3950:      	mov	w25, #0x40              // =64
    3954:      	adrp	x29, 0x3000 <generic_rawtp_process_event+0x2e30>
    3958:      	ldr	x29, [x29]
    395c:      	ldr	x12, [sp, #0x28]
    3960:      	ldr	x10, [sp, #0x20]
    3964:      	mov	w9, #0x5ea0             // =24224
    3968:      	tbnz	w25, #0x1f, 0x3a40 <generic_rawtp_process_event+0x3870>
    396c:      	and	x8, x25, #0x7fffffff
    3970:      	add	x8, x8, #0x4
    3974:      	ldr	x25, [sp, #0x40]
    3978:      	mov	w22, #0x5efc            // =24316
    397c:      	adrp	x21, 0x3000 <generic_rawtp_process_event+0x2e30>
    3980:      	ldr	x21, [x21]
    3984:      	ldr	x24, [sp, #0xf8]
    3988:      	add	w24, w24, w8
    398c:      	cmp	w25, #0x3
    3990:      	str	w24, [x20, #0x4]
    3994:      	b.gt	0x3a04 <generic_rawtp_process_event+0x3834>
    3998:      	str	wzr, [sp, #0x88]
    399c:      	mov	w8, #0x1                // =1
    39a0:      	add	x9, sp, #0x88
    39a4:      	add	x1, sp, #0x88
    39a8:      	mov	x0, x21
    39ac:      	blr	x8
    39b0:      	cbz	x0, 0x3a04 <generic_rawtp_process_event+0x3834>
    39b4:      	mov	w8, #0x5ef8             // =24312
    39b8:      	add	x1, x0, x8
    39bc:      	adrp	x0, 0x3000 <generic_rawtp_process_event+0x2e30>
    39c0:      	mov	w8, #0x1                // =1
    39c4:      	ldr	x0, [x0]
    39c8:      	blr	x8
    39cc:      	cbz	x0, 0x3a04 <generic_rawtp_process_event+0x3834>
    39d0:      	add	w8, w25, #0x1
    39d4:      	and	w9, w8, #0x7
    39d8:      	add	x9, x0, w9, uxtw #2
    39dc:      	ldr	w9, [x9, #0x40]
    39e0:      	cmn	w9, #0x1
    39e4:      	b.eq	0x3a04 <generic_rawtp_process_event+0x3834>
    39e8:      	str	w8, [x20, x22]
    39ec:      	mov	w8, #0x1                // =1
    39f0:      	mov	w9, #0xc                // =12
    39f4:      	mov	x0, x19
    39f8:      	mov	x1, x29
    39fc:      	mov	w2, #0x1                // =1
    3a00:      	blr	x9
    3a04:      	str	wzr, [x20, x22]
    3a08:      	mov	w8, #0x3                // =3
    3a0c:      	mov	w9, #0xc                // =12
    3a10:      	mov	x0, x19
    3a14:      	mov	x1, x29
    3a18:      	mov	w2, #0x3                // =3
    3a1c:      	blr	x9
    3a20:      	ldp	x20, x19, [sp, #0x130]
    3a24:      	mov	w0, wzr
    3a28:      	ldr	x29, [sp, #0xf0]
    3a2c:      	ldp	x22, x21, [sp, #0x120]
    3a30:      	ldp	x24, x23, [sp, #0x110]
    3a34:      	ldp	x30, x25, [sp, #0x100]
    3a38:      	add	sp, sp, #0x140
    3a3c:      	ret
    3a40:      	mov	w8, #-0x1               // =-1
    3a44:      	str	w8, [x12, x9]
    3a48:      	ldr	x9, [sp, #0xf8]
    3a4c:      	str	w8, [x10, x9]
    3a50:      	b	0xdd0 <generic_rawtp_process_event+0xc00>
    3a54:      	ldrh	w8, [x24, #0x2]
    3a58:      	ldrh	w9, [x24]
    3a5c:      	ldrb	w25, [x24, #0x6]
    3a60:      	add	w8, w9, w8
    3a64:      	cmp	w25, #0x3c
    3a68:      	strh	w8, [x24]
    3a6c:      	b.ls	0x3790 <generic_rawtp_process_event+0x35c0>
    3a70:      	strh	w8, [sp, #0xc8]
    3a74:      	b	0x37d4 <generic_rawtp_process_event+0x3604>
    3a78:      	nop
    3a7c:      	nop

0000000000003a80 <generic_rawtp_process_filter>:
    3a80:      	sub	sp, sp, #0x130
    3a84:      	str	x29, [sp, #0xe0]
    3a88:      	stp	x30, x25, [sp, #0xf0]
    3a8c:      	stp	x24, x23, [sp, #0x100]
    3a90:      	stp	x22, x21, [sp, #0x110]
    3a94:      	stp	x20, x19, [sp, #0x120]
    3a98:      	mov	x20, x0
    3a9c:      	str	wzr, [sp, #0x54]
    3aa0:      	adrp	x0, 0x3000 <generic_rawtp_process_event+0x2e30>
    3aa4:      	mov	w8, #0x1                // =1
    3aa8:      	ldr	x0, [x0]
    3aac:      	add	x9, sp, #0x54
    3ab0:      	add	x1, sp, #0x54
    3ab4:      	blr	x8
    3ab8:      	cbz	x0, 0x5dac <generic_rawtp_process_filter+0x232c>
    3abc:      	mov	w8, #0x5ec0             // =24256
    3ac0:      	mov	x22, x0
    3ac4:      	add	x29, x0, x8
    3ac8:      	mov	w8, #0x23               // =35
    3acc:      	blr	x8
    3ad0:      	str	x0, [sp, #0x58]
    3ad4:      	add	x8, x0, #0x8d4
    3ad8:      	mov	w9, #0x4                // =4
    3adc:      	mov	w10, #0x71              // =113
    3ae0:      	add	x11, sp, #0xd8
    3ae4:      	add	x0, sp, #0xd8
    3ae8:      	mov	w1, #0x4                // =4
    3aec:      	ldr	x8, [sp, #0x58]
    3af0:      	add	x2, x8, #0x8d4
    3af4:      	blr	x10
    3af8:      	ldr	w8, [sp, #0xd8]
    3afc:      	adrp	x19, 0x3000 <generic_rawtp_process_event+0x2e30>
    3b00:      	add	x9, sp, #0xc8
    3b04:      	add	x1, sp, #0xc8
    3b08:      	str	w8, [sp, #0xc8]
    3b0c:      	mov	w8, #0x1                // =1
    3b10:      	ldr	x19, [x19]
    3b14:      	mov	x0, x19
    3b18:      	blr	x8
    3b1c:      	cbz	x0, 0x3b2c <generic_rawtp_process_filter+0xac>
    3b20:      	ldr	x8, [x0, #0x8]
    3b24:      	mov	x24, x0
    3b28:      	cbnz	x8, 0x490c <generic_rawtp_process_filter+0xe8c>
    3b2c:      	ldr	x8, [sp, #0x58]
    3b30:      	mov	w9, #0x8                // =8
    3b34:      	mov	w10, #0x71              // =113
    3b38:      	add	x11, sp, #0x58
    3b3c:      	add	x0, sp, #0x58
    3b40:      	mov	w1, #0x8                // =8
    3b44:      	add	x8, x8, #0x8e0
    3b48:      	ldr	x8, [sp, #0x58]
    3b4c:      	add	x2, x8, #0x8e0
    3b50:      	blr	x10
    3b54:      	ldr	x8, [sp, #0x58]
    3b58:      	cbz	x8, 0x3cd4 <generic_rawtp_process_filter+0x254>
    3b5c:      	add	x8, x8, #0x8d4
    3b60:      	mov	w9, #0x4                // =4
    3b64:      	mov	w10, #0x71              // =113
    3b68:      	add	x11, sp, #0xd8
    3b6c:      	ldr	x8, [sp, #0x58]
    3b70:      	add	x0, sp, #0xd8
    3b74:      	mov	w1, #0x4                // =4
    3b78:      	add	x2, x8, #0x8d4
    3b7c:      	blr	x10
    3b80:      	ldr	w8, [sp, #0xd8]
    3b84:      	add	x9, sp, #0xc8
    3b88:      	add	x1, sp, #0xc8
    3b8c:      	mov	x0, x19
    3b90:      	str	w8, [sp, #0xc8]
    3b94:      	mov	w8, #0x1                // =1
    3b98:      	blr	x8
    3b9c:      	cbz	x0, 0x3bac <generic_rawtp_process_filter+0x12c>
    3ba0:      	ldr	x8, [x0, #0x8]
    3ba4:      	mov	x24, x0
    3ba8:      	cbnz	x8, 0x490c <generic_rawtp_process_filter+0xe8c>
    3bac:      	ldr	x8, [sp, #0x58]
    3bb0:      	mov	w9, #0x8                // =8
    3bb4:      	mov	w10, #0x71              // =113
    3bb8:      	add	x11, sp, #0x58
    3bbc:      	add	x0, sp, #0x58
    3bc0:      	mov	w1, #0x8                // =8
    3bc4:      	add	x8, x8, #0x8e0
    3bc8:      	ldr	x8, [sp, #0x58]
    3bcc:      	add	x2, x8, #0x8e0
    3bd0:      	blr	x10
    3bd4:      	ldr	x8, [sp, #0x58]
    3bd8:      	cbz	x8, 0x3cd4 <generic_rawtp_process_filter+0x254>
    3bdc:      	add	x8, x8, #0x8d4
    3be0:      	mov	w9, #0x4                // =4
    3be4:      	mov	w10, #0x71              // =113
    3be8:      	add	x11, sp, #0xd8
    3bec:      	ldr	x8, [sp, #0x58]
    3bf0:      	add	x0, sp, #0xd8
    3bf4:      	mov	w1, #0x4                // =4
    3bf8:      	add	x2, x8, #0x8d4
    3bfc:      	blr	x10
    3c00:      	ldr	w8, [sp, #0xd8]
    3c04:      	add	x9, sp, #0xc8
    3c08:      	add	x1, sp, #0xc8
    3c0c:      	mov	x0, x19
    3c10:      	str	w8, [sp, #0xc8]
    3c14:      	mov	w8, #0x1                // =1
    3c18:      	blr	x8
    3c1c:      	cbz	x0, 0x3c2c <generic_rawtp_process_filter+0x1ac>
    3c20:      	ldr	x8, [x0, #0x8]
    3c24:      	mov	x24, x0
    3c28:      	cbnz	x8, 0x490c <generic_rawtp_process_filter+0xe8c>
    3c2c:      	ldr	x8, [sp, #0x58]
    3c30:      	mov	w9, #0x8                // =8
    3c34:      	mov	w10, #0x71              // =113
    3c38:      	add	x11, sp, #0x58
    3c3c:      	add	x0, sp, #0x58
    3c40:      	mov	w1, #0x8                // =8
    3c44:      	add	x8, x8, #0x8e0
    3c48:      	ldr	x8, [sp, #0x58]
    3c4c:      	add	x2, x8, #0x8e0
    3c50:      	blr	x10
    3c54:      	ldr	x8, [sp, #0x58]
    3c58:      	cbz	x8, 0x3cd4 <generic_rawtp_process_filter+0x254>
    3c5c:      	add	x8, x8, #0x8d4
    3c60:      	mov	w9, #0x4                // =4
    3c64:      	mov	w10, #0x71              // =113
    3c68:      	add	x11, sp, #0xd8
    3c6c:      	ldr	x8, [sp, #0x58]
    3c70:      	add	x0, sp, #0xd8
    3c74:      	mov	w1, #0x4                // =4
    3c78:      	add	x2, x8, #0x8d4
    3c7c:      	blr	x10
    3c80:      	ldr	w8, [sp, #0xd8]
    3c84:      	add	x9, sp, #0xc8
    3c88:      	add	x1, sp, #0xc8
    3c8c:      	mov	x0, x19
    3c90:      	str	w8, [sp, #0xc8]
    3c94:      	mov	w8, #0x1                // =1
    3c98:      	blr	x8
    3c9c:      	cbz	x0, 0x3cac <generic_rawtp_process_filter+0x22c>
    3ca0:      	ldr	x8, [x0, #0x8]
    3ca4:      	mov	x24, x0
    3ca8:      	cbnz	x8, 0x490c <generic_rawtp_process_filter+0xe8c>
    3cac:      	ldr	x8, [sp, #0x58]
    3cb0:      	mov	w9, #0x8                // =8
    3cb4:      	mov	w10, #0x71              // =113
    3cb8:      	add	x11, sp, #0x58
    3cbc:      	add	x0, sp, #0x58
    3cc0:      	mov	w1, #0x8                // =8
    3cc4:      	add	x8, x8, #0x8e0
    3cc8:      	ldr	x8, [sp, #0x58]
    3ccc:      	add	x2, x8, #0x8e0
    3cd0:      	blr	x10
    3cd4:      	str	x20, [sp, #0x38]
    3cd8:      	mov	w8, #0x23               // =35
    3cdc:      	blr	x8
    3ce0:      	add	x2, x0, #0x8d4
    3ce4:      	mov	w8, #0x4                // =4
    3ce8:      	add	x9, sp, #0x58
    3cec:      	mov	x24, x0
    3cf0:      	add	x0, sp, #0x58
    3cf4:      	mov	w1, #0x4                // =4
    3cf8:      	blr	x8
    3cfc:      	ldr	w8, [sp, #0x58]
    3d00:      	mov	x19, x29
    3d04:      	str	w8, [x19, #0x50]!
    3d08:      	mov	w8, #0x7d               // =125
    3d0c:      	blr	x8
    3d10:      	str	x0, [x22, #0x5f18]
    3d14:      	str	wzr, [x19, #0x10]
    3d18:      	add	x2, x24, #0x60
    3d1c:      	mov	w8, #0x8                // =8
    3d20:      	mov	w9, #0x71               // =113
    3d24:      	add	x10, sp, #0xc8
    3d28:      	str	xzr, [x22, #0x5f28]
    3d2c:      	str	x19, [sp, #0x48]
    3d30:      	add	x0, sp, #0xc8
    3d34:      	mov	w1, #0x8                // =8
    3d38:      	str	wzr, [x19, #0x20]
    3d3c:      	blr	x9
    3d40:      	ldr	x8, [sp, #0xc8]
    3d44:      	cbz	x8, 0x3db4 <generic_rawtp_process_filter+0x334>
    3d48:      	add	x8, x8, #0x4
    3d4c:      	mov	w9, #0x4                // =4
    3d50:      	mov	w10, #0x71              // =113
    3d54:      	add	x11, sp, #0xd8
    3d58:      	ldr	x8, [sp, #0xc8]
    3d5c:      	add	x0, sp, #0xd8
    3d60:      	mov	w1, #0x4                // =4
    3d64:      	add	x2, x8, #0x4
    3d68:      	blr	x10
    3d6c:      	ldr	w8, [sp, #0xd8]
    3d70:      	cbz	w8, 0x3db4 <generic_rawtp_process_filter+0x334>
    3d74:      	ldr	x9, [sp, #0xc8]
    3d78:      	lsl	w8, w8, #4
    3d7c:      	mov	w10, #0x71              // =113
    3d80:      	add	x11, sp, #0x58
    3d84:      	add	x0, sp, #0x58
    3d88:      	mov	w1, #0x10               // =16
    3d8c:      	add	x8, x9, x8
    3d90:      	mov	w9, #0x10               // =16
    3d94:      	add	x8, x8, #0x80
    3d98:      	ldr	w9, [sp, #0xd8]
    3d9c:      	ldr	x8, [sp, #0xc8]
    3da0:      	lsl	w9, w9, #4
    3da4:      	add	x8, x8, x9
    3da8:      	add	x2, x8, #0x80
    3dac:      	blr	x10
    3db0:      	ldr	w8, [sp, #0x58]
    3db4:      	str	w8, [x29, #0x74]
    3db8:      	mov	w8, #0x5f60             // =24416
    3dbc:      	str	x22, [sp, #0xe8]
    3dc0:      	add	x23, x24, #0xae0
    3dc4:      	mov	w19, #0x8               // =8
    3dc8:      	add	x25, x22, x8
    3dcc:      	add	x8, sp, #0x58
    3dd0:      	mov	w9, #0x4                // =4
    3dd4:      	add	x0, sp, #0x58
    3dd8:      	mov	w1, #0x8                // =8
    3ddc:      	mov	x2, x23
    3de0:      	mov	w21, #0x4               // =4
    3de4:      	blr	x9
    3de8:      	ldr	x20, [sp, #0x58]
    3dec:      	ldr	x9, [sp, #0xe8]
    3df0:      	mov	w8, #0x5f68             // =24424
    3df4:      	mov	w1, #0x8                // =8
    3df8:      	add	x0, x9, x8
    3dfc:      	add	x2, x20, #0x40
    3e00:      	mov	w8, #0x4                // =4
    3e04:      	blr	x8
    3e08:      	ldr	x9, [sp, #0xe8]
    3e0c:      	mov	w8, #0x5f70             // =24432
    3e10:      	add	x2, x20, #0x30
    3e14:      	mov	w1, #0x8                // =8
    3e18:      	add	x0, x9, x8
    3e1c:      	mov	w8, #0x4                // =4
    3e20:      	blr	x8
    3e24:      	add	x2, x20, #0x38
    3e28:      	mov	w8, #0x4                // =4
    3e2c:      	mov	x0, x25
    3e30:      	mov	w1, #0x8                // =8
    3e34:      	blr	x8
    3e38:      	ldr	x9, [sp, #0xe8]
    3e3c:      	mov	w8, #0x5f38             // =24376
    3e40:      	add	x2, x24, #0xb50
    3e44:      	add	x0, sp, #0xd8
    3e48:      	mov	w1, #0x8                // =8
    3e4c:      	add	x25, x9, x8
    3e50:      	add	x8, sp, #0xd8
    3e54:      	mov	w9, #0x4                // =4
    3e58:      	blr	x9
    3e5c:      	add	x12, sp, #0xd8
    3e60:      	mov	w9, #0x48               // =72
    3e64:      	add	x10, sp, #0x58
    3e68:      	ldr	x8, [x12]
    3e6c:      	mov	w11, #0x4               // =4
    3e70:      	add	x0, sp, #0x58
    3e74:      	mov	w1, #0x48               // =72
    3e78:      	ldr	x2, [x12]
    3e7c:      	blr	x11
    3e80:      	ldr	x8, [sp, #0x60]
    3e84:      	mov	w9, #0x4                // =4
    3e88:      	mov	x0, x25
    3e8c:      	mov	w1, #0x4                // =4
    3e90:      	add	x8, x8, #0x218
    3e94:      	ldr	x8, [sp, #0x60]
    3e98:      	ldr	x22, [sp, #0xe8]
    3e9c:      	add	x2, x8, #0x218
    3ea0:      	blr	x9
    3ea4:      	mov	w8, #0x5f3c             // =24380
    3ea8:      	mov	w9, #0x4                // =4
    3eac:      	mov	w1, #0x4                // =4
    3eb0:      	add	x0, x22, x8
    3eb4:      	ldr	x8, [sp, #0x68]
    3eb8:      	add	x8, x8, #0x4d8
    3ebc:      	ldr	x8, [sp, #0x68]
    3ec0:      	add	x2, x8, #0x4d8
    3ec4:      	blr	x9
    3ec8:      	mov	w8, #0x5f40             // =24384
    3ecc:      	mov	w9, #0x4                // =4
    3ed0:      	mov	w1, #0x4                // =4
    3ed4:      	add	x0, x22, x8
    3ed8:      	ldr	x8, [sp, #0x70]
    3edc:      	add	x8, x8, #0x58
    3ee0:      	ldr	x8, [sp, #0x70]
    3ee4:      	add	x2, x8, #0x58
    3ee8:      	blr	x9
    3eec:      	str	xzr, [sp, #0xc0]
    3ef0:      	add	x2, x24, #0x938
    3ef4:      	add	x8, sp, #0xc0
    3ef8:      	add	x0, sp, #0xc0
    3efc:      	mov	w1, #0x8                // =8
    3f00:      	blr	x21
    3f04:      	ldr	x8, [sp, #0xc0]
    3f08:      	cbz	x8, 0x3f90 <generic_rawtp_process_filter+0x510>
    3f0c:      	str	wzr, [sp, #0xb8]
    3f10:      	add	x8, x8, #0x4
    3f14:      	add	x9, sp, #0xb8
    3f18:      	mov	w10, #0x4               // =4
    3f1c:      	add	x0, sp, #0xb8
    3f20:      	mov	w1, #0x4                // =4
    3f24:      	mov	w19, #0x4               // =4
    3f28:      	ldr	x8, [sp, #0xc0]
    3f2c:      	add	x2, x8, #0x4
    3f30:      	blr	x10
    3f34:      	ldr	x8, [sp, #0xc0]
    3f38:      	ldrsw	x9, [sp, #0xb8]
    3f3c:      	add	x10, sp, #0xc8
    3f40:      	mov	w11, #0x4               // =4
    3f44:      	add	x0, sp, #0xc8
    3f48:      	mov	w1, #0x10               // =16
    3f4c:      	add	x8, x8, x9, lsl #4
    3f50:      	mov	w9, #0x10               // =16
    3f54:      	add	x8, x8, #0x80
    3f58:      	ldr	x8, [sp, #0xc0]
    3f5c:      	ldrsw	x9, [sp, #0xb8]
    3f60:      	add	x8, x8, x9, lsl #4
    3f64:      	add	x2, x8, #0x80
    3f68:      	blr	x11
    3f6c:      	mov	w8, #0x5f44             // =24388
    3f70:      	mov	w1, #0x4                // =4
    3f74:      	add	x0, x22, x8
    3f78:      	ldr	x8, [sp, #0xd0]
    3f7c:      	add	x8, x8, #0x158
    3f80:      	ldr	x8, [sp, #0xd0]
    3f84:      	add	x2, x8, #0x158
    3f88:      	blr	x19
    3f8c:      	b	0x3f94 <generic_rawtp_process_filter+0x514>
    3f90:      	str	wzr, [x29, #0x84]
    3f94:      	mov	w8, #0x5f48             // =24392
    3f98:      	mov	w9, #0x4                // =4
    3f9c:      	mov	w1, #0x4                // =4
    3fa0:      	mov	w19, #0x4               // =4
    3fa4:      	add	x0, x22, x8
    3fa8:      	ldr	x8, [sp, #0x78]
    3fac:      	add	x8, x8, #0x158
    3fb0:      	ldr	x8, [sp, #0x78]
    3fb4:      	add	x2, x8, #0x158
    3fb8:      	blr	x9
    3fbc:      	mov	w8, #0x5f4c             // =24396
    3fc0:      	mov	w9, #0x4                // =4
    3fc4:      	mov	w1, #0x4                // =4
    3fc8:      	add	x0, x22, x8
    3fcc:      	ldr	x8, [sp, #0x80]
    3fd0:      	add	x8, x8, #0x118
    3fd4:      	ldr	x8, [sp, #0x80]
    3fd8:      	add	x2, x8, #0x118
    3fdc:      	blr	x9
    3fe0:      	mov	w8, #0x5f50             // =24400
    3fe4:      	mov	w9, #0x4                // =4
    3fe8:      	mov	w1, #0x4                // =4
    3fec:      	add	x0, x22, x8
    3ff0:      	ldr	x8, [sp, #0x88]
    3ff4:      	add	x8, x8, #0x98
    3ff8:      	ldr	x8, [sp, #0x88]
    3ffc:      	add	x2, x8, #0x98
    4000:      	blr	x9
    4004:      	mov	w8, #0x5f54             // =24404
    4008:      	mov	w9, #0x4                // =4
    400c:      	mov	w1, #0x4                // =4
    4010:      	add	x0, x22, x8
    4014:      	ldr	x8, [sp, #0x90]
    4018:      	add	x8, x8, #0x98
    401c:      	ldr	x8, [sp, #0x90]
    4020:      	add	x2, x8, #0x98
    4024:      	blr	x9
    4028:      	mov	w8, #0x5f58             // =24408
    402c:      	mov	w9, #0x4                // =4
    4030:      	mov	w1, #0x4                // =4
    4034:      	add	x0, x22, x8
    4038:      	ldr	x8, [sp, #0x98]
    403c:      	add	x8, x8, #0x58
    4040:      	ldr	x8, [sp, #0x98]
    4044:      	add	x2, x8, #0x58
    4048:      	blr	x9
    404c:      	stp	xzr, xzr, [sp, #0xc0]
    4050:      	mov	w20, #0x8               // =8
    4054:      	add	x8, sp, #0xc8
    4058:      	mov	w9, #0x4                // =4
    405c:      	add	x0, sp, #0xc8
    4060:      	mov	w1, #0x8                // =8
    4064:      	mov	x2, x23
    4068:      	blr	x9
    406c:      	ldr	x8, [sp, #0xc8]
    4070:      	add	x9, sp, #0xc0
    4074:      	mov	w10, #0x4               // =4
    4078:      	add	x0, sp, #0xc0
    407c:      	mov	w1, #0x8                // =8
    4080:      	add	x8, x8, #0x90
    4084:      	ldr	x8, [sp, #0xc8]
    4088:      	add	x2, x8, #0x90
    408c:      	blr	x10
    4090:      	mov	w8, #0x5f5c             // =24412
    4094:      	mov	w1, #0x4                // =4
    4098:      	add	x0, x22, x8
    409c:      	ldr	x8, [sp, #0xc0]
    40a0:      	add	x8, x8, #0x158
    40a4:      	ldr	x8, [sp, #0xc0]
    40a8:      	add	x2, x8, #0x158
    40ac:      	blr	x19
    40b0:      	ldr	w8, [x29, #0x74]
    40b4:      	cmp	w8, #0x1
    40b8:      	b.ne	0x40c8 <generic_rawtp_process_filter+0x648>
    40bc:      	ldr	w8, [x29, #0x70]
    40c0:      	orr	w8, w8, #0x2000000
    40c4:      	str	w8, [x29, #0x70]
    40c8:      	add	x0, x29, #0xb8
    40cc:      	mov	w1, wzr
    40d0:      	mov	w2, #0x308              // =776
    40d4:      	bl	0x40d4 <generic_rawtp_process_filter+0x654>
    40d8:      	mov	w8, #0x6290             // =25232
    40dc:      	add	x2, x24, #0x858
    40e0:      	mov	w19, #0x8               // =8
    40e4:      	mov	w9, #0x4                // =4
    40e8:      	add	x0, sp, #0xc8
    40ec:      	mov	w1, #0x8                // =8
    40f0:      	mov	w20, #0x4               // =4
    40f4:      	add	x21, x22, x8
    40f8:      	add	x8, sp, #0xc8
    40fc:      	blr	x9
    4100:      	ldr	x8, [sp, #0xc8]
    4104:      	add	x9, sp, #0x58
    4108:      	add	x0, sp, #0x58
    410c:      	mov	w1, #0x8                // =8
    4110:      	add	x8, x8, #0x528
    4114:      	ldr	x8, [sp, #0xc8]
    4118:      	add	x2, x8, #0x528
    411c:      	blr	x20
    4120:      	str	wzr, [sp, #0xa4]
    4124:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x580>
    4128:      	ldr	x19, [sp, #0x58]
    412c:      	mov	w8, #0x1                // =1
    4130:      	add	x9, sp, #0xa4
    4134:      	add	x1, sp, #0xa4
    4138:      	ldr	x0, [x0]
    413c:      	blr	x8
    4140:      	cbz	x0, 0x4754 <generic_rawtp_process_filter+0xcd4>
    4144:      	mov	w8, #0x1000             // =4096
    4148:      	str	x21, [sp, #0x30]
    414c:      	str	x29, [sp, #0x40]
    4150:      	mov	x24, x0
    4154:      	add	x20, x0, #0x1, lsl #12  // =0x1000
    4158:      	str	w8, [x29, #0x550]
    415c:      	mov	w8, #0x23               // =35
    4160:      	blr	x8
    4164:      	add	x2, x0, #0xb30
    4168:      	mov	w23, #0x8               // =8
    416c:      	add	x8, sp, #0xa8
    4170:      	mov	w9, #0x4                // =4
    4174:      	add	x0, sp, #0xa8
    4178:      	mov	w1, #0x8                // =8
    417c:      	mov	w29, #0x4               // =4
    4180:      	blr	x9
    4184:      	ldr	x22, [sp, #0xa8]
    4188:      	add	x25, x19, #0x48
    418c:      	add	x8, sp, #0xb0
    4190:      	mov	w9, #0x4                // =4
    4194:      	add	x0, sp, #0xb0
    4198:      	mov	w1, #0x8                // =8
    419c:      	mov	x2, x25
    41a0:      	blr	x9
    41a4:      	ldr	x21, [sp, #0xb0]
    41a8:      	add	x8, sp, #0x58
    41ac:      	add	x0, sp, #0x58
    41b0:      	mov	w1, #0x8                // =8
    41b4:      	add	x2, x21, #0x10
    41b8:      	blr	x29
    41bc:      	ldr	x8, [sp, #0x58]
    41c0:      	cbz	x8, 0x43f4 <generic_rawtp_process_filter+0x974>
    41c4:      	ldr	x8, [sp, #0x40]
    41c8:      	stp	xzr, xzr, [sp, #0x58]
    41cc:      	add	x21, x22, #0x18
    41d0:      	add	x9, sp, #0x58
    41d4:      	add	x2, x22, #0x20
    41d8:      	mov	w22, #0x8               // =8
    41dc:      	stp	x24, xzr, [sp, #0x68]
    41e0:      	add	x0, sp, #0x58
    41e4:      	mov	w1, #0x8                // =8
    41e8:      	add	x29, x19, #0x40
    41ec:      	add	x19, x9, #0x8
    41f0:      	add	x24, x9, #0x18
    41f4:      	stp	xzr, xzr, [sp, #0x78]
    41f8:      	add	x23, x9, #0x20
    41fc:      	str	x20, [sp, #0x88]
    4200:      	str	x20, [sp, #0x28]
    4204:      	mov	w20, #0x4               // =4
    4208:      	ldr	w8, [x8, #0x550]
    420c:      	strb	wzr, [sp, #0x94]
    4210:      	str	w8, [sp, #0x90]
    4214:      	mov	w8, #0x4                // =4
    4218:      	blr	x8
    421c:      	mov	w8, #0x4                // =4
    4220:      	mov	x0, x19
    4224:      	mov	w1, #0x8                // =8
    4228:      	mov	x2, x21
    422c:      	blr	x8
    4230:      	mov	w8, #0x4                // =4
    4234:      	mov	x0, x24
    4238:      	mov	w1, #0x8                // =8
    423c:      	mov	x2, x25
    4240:      	blr	x8
    4244:      	mov	x0, x23
    4248:      	mov	w1, #0x8                // =8
    424c:      	mov	x2, x29
    4250:      	blr	x20
    4254:      	ldr	x8, [sp, #0x78]
    4258:      	sub	x8, x8, #0x20
    425c:      	str	x8, [sp, #0x80]
    4260:      	adrp	x8, 0x4000 <generic_rawtp_process_filter+0x580>
    4264:      	ldr	x8, [x8]
    4268:      	ldrb	w8, [x8]
    426c:      	cbz	w8, 0x4448 <generic_rawtp_process_filter+0x9c8>
    4270:      	mov	w19, #0x80              // =128
    4274:      	mov	w21, #0x8               // =8
    4278:      	add	x23, sp, #0xb8
    427c:      	add	x29, sp, #0xd8
    4280:      	b	0x42d4 <generic_rawtp_process_filter+0x854>
    4284:      	add	x2, x22, #0x10
    4288:      	mov	w8, #0x4                // =4
    428c:      	add	x0, sp, #0xd8
    4290:      	mov	w1, #0x8                // =8
    4294:      	blr	x8
    4298:      	add	x20, sp, #0xd8
    429c:      	ldr	x8, [sp, #0x80]
    42a0:      	ldr	x9, [x20]
    42a4:      	cmp	x8, x9
    42a8:      	b.eq	0x45d0 <generic_rawtp_process_filter+0xb50>
    42ac:      	add	x2, x22, #0x18
    42b0:      	mov	w8, #0x4                // =4
    42b4:      	mov	x0, x24
    42b8:      	mov	w1, #0x8                // =8
    42bc:      	blr	x8
    42c0:      	ldr	x8, [x20]
    42c4:      	add	x9, x8, #0x20
    42c8:      	stp	x9, x8, [sp, #0x78]
    42cc:      	subs	w19, w19, #0x1
    42d0:      	b.eq	0x45d8 <generic_rawtp_process_filter+0xb58>
    42d4:      	ldp	x20, x2, [sp, #0x70]
    42d8:      	ldp	x8, x9, [sp, #0x58]
    42dc:      	cmp	x20, x8
    42e0:      	ccmp	x2, x9, #0x0, eq
    42e4:      	b.eq	0x45d0 <generic_rawtp_process_filter+0xb50>
    42e8:      	ldr	x22, [sp, #0x80]
    42ec:      	mov	w8, #0x4                // =4
    42f0:      	add	x0, sp, #0xb8
    42f4:      	mov	w1, #0x8                // =8
    42f8:      	blr	x8
    42fc:      	ldr	x8, [sp, #0xb8]
    4300:      	cmp	x20, x8
    4304:      	b.eq	0x4284 <generic_rawtp_process_filter+0x804>
    4308:      	add	x25, x20, #0x18
    430c:      	mov	w8, #0x4                // =4
    4310:      	add	x0, sp, #0xd8
    4314:      	mov	w1, #0x8                // =8
    4318:      	mov	x2, x25
    431c:      	blr	x8
    4320:      	add	x8, sp, #0xd8
    4324:      	ldr	x8, [x8]
    4328:      	cmp	x8, x20
    432c:      	b.eq	0x4284 <generic_rawtp_process_filter+0x804>
    4330:      	mov	w8, #0x4                // =4
    4334:      	add	x9, sp, #0xc0
    4338:      	add	x0, sp, #0xc0
    433c:      	mov	w1, #0x8                // =8
    4340:      	mov	x2, x25
    4344:      	blr	x8
    4348:      	add	x2, x20, #0x20
    434c:      	mov	w8, #0x4                // =4
    4350:      	mov	w9, #0x10               // =16
    4354:      	add	x10, sp, #0xc8
    4358:      	add	x0, sp, #0xc8
    435c:      	mov	w1, #0x10               // =16
    4360:      	blr	x8
    4364:      	ldr	w20, [sp, #0xcc]
    4368:      	ldr	x8, [sp, #0x68]
    436c:      	ldr	x10, [sp, #0x88]
    4370:      	sub	x12, x10, x8
    4374:      	ldr	w22, [sp, #0x90]
    4378:      	subs	w10, w20, w22
    437c:      	ldr	x9, [sp, #0xd0]
    4380:      	csel	w10, wzr, w10, lo
    4384:      	cmp	w22, w20
    4388:      	csel	w11, w22, w20, lo
    438c:      	cinc	w13, w11, hi
    4390:      	sub	w14, w22, w13
    4394:      	subs	x12, x12, x13
    4398:      	str	w14, [sp, #0x90]
    439c:      	b.lo	0x45d8 <generic_rawtp_process_filter+0xb58>
    43a0:      	cmp	x12, #0xfff
    43a4:      	b.hi	0x45d8 <generic_rawtp_process_filter+0xb58>
    43a8:      	cmp	w22, w20
    43ac:      	b.ls	0x43b8 <generic_rawtp_process_filter+0x938>
    43b0:      	mov	w13, #0x2f              // =47
    43b4:      	strb	w13, [x8, x12]
    43b8:      	add	x25, x8, x12
    43bc:      	cmp	w22, w20
    43c0:      	add	x2, x9, x10
    43c4:      	and	w1, w11, #0xff
    43c8:      	mov	w8, #0x4                // =4
    43cc:      	cinc	x0, x25, hi
    43d0:      	blr	x8
    43d4:      	cmp	w22, w20
    43d8:      	str	x25, [sp, #0x88]
    43dc:      	b.ls	0x45d8 <generic_rawtp_process_filter+0xb58>
    43e0:      	ldr	x8, [sp, #0xc0]
    43e4:      	str	x8, [sp, #0x70]
    43e8:      	subs	w19, w19, #0x1
    43ec:      	b.ne	0x42d4 <generic_rawtp_process_filter+0x854>
    43f0:      	b	0x45d8 <generic_rawtp_process_filter+0xb58>
    43f4:      	add	x2, x21, #0x18
    43f8:      	mov	w8, #0x8                // =8
    43fc:      	mov	w9, #0x4                // =4
    4400:      	add	x10, sp, #0x58
    4404:      	add	x0, sp, #0x58
    4408:      	mov	w1, #0x8                // =8
    440c:      	blr	x9
    4410:      	ldr	x8, [sp, #0x58]
    4414:      	cmp	x8, x21
    4418:      	b.eq	0x41c4 <generic_rawtp_process_filter+0x744>
    441c:      	ldr	x29, [sp, #0x40]
    4420:      	ldr	w9, [x29, #0x550]
    4424:      	sub	w8, w9, #0xa
    4428:      	cmp	w9, #0x9
    442c:      	str	w8, [x29, #0x550]
    4430:      	b.gt	0x4b00 <generic_rawtp_process_filter+0x1080>
    4434:      	ldr	x21, [sp, #0x30]
    4438:      	mov	w9, #-0x24              // =-36
    443c:      	mov	x24, x20
    4440:      	str	w9, [x29, #0x554]
    4444:      	b	0x463c <generic_rawtp_process_filter+0xbbc>
    4448:      	mov	w19, #0x80              // =128
    444c:      	mov	w21, #0x8               // =8
    4450:      	add	x23, sp, #0xb8
    4454:      	add	x29, sp, #0xd8
    4458:      	b	0x44b0 <generic_rawtp_process_filter+0xa30>
    445c:      	nop
    4460:      	add	x2, x22, #0x10
    4464:      	mov	w8, #0x4                // =4
    4468:      	add	x0, sp, #0xd8
    446c:      	mov	w1, #0x8                // =8
    4470:      	blr	x8
    4474:      	add	x20, sp, #0xd8
    4478:      	ldr	x8, [sp, #0x80]
    447c:      	ldr	x9, [x20]
    4480:      	cmp	x8, x9
    4484:      	b.eq	0x45d0 <generic_rawtp_process_filter+0xb50>
    4488:      	add	x2, x22, #0x18
    448c:      	mov	w8, #0x4                // =4
    4490:      	mov	x0, x24
    4494:      	mov	w1, #0x8                // =8
    4498:      	blr	x8
    449c:      	ldr	x8, [x20]
    44a0:      	add	x9, x8, #0x20
    44a4:      	stp	x9, x8, [sp, #0x78]
    44a8:      	subs	w19, w19, #0x1
    44ac:      	b.eq	0x45d8 <generic_rawtp_process_filter+0xb58>
    44b0:      	ldp	x20, x2, [sp, #0x70]
    44b4:      	ldp	x8, x9, [sp, #0x58]
    44b8:      	cmp	x20, x8
    44bc:      	ccmp	x2, x9, #0x0, eq
    44c0:      	b.eq	0x45d0 <generic_rawtp_process_filter+0xb50>
    44c4:      	ldr	x22, [sp, #0x80]
    44c8:      	mov	w8, #0x4                // =4
    44cc:      	add	x0, sp, #0xb8
    44d0:      	mov	w1, #0x8                // =8
    44d4:      	blr	x8
    44d8:      	ldr	x8, [sp, #0xb8]
    44dc:      	cmp	x20, x8
    44e0:      	b.eq	0x4460 <generic_rawtp_process_filter+0x9e0>
    44e4:      	add	x25, x20, #0x18
    44e8:      	mov	w8, #0x4                // =4
    44ec:      	add	x0, sp, #0xd8
    44f0:      	mov	w1, #0x8                // =8
    44f4:      	mov	x2, x25
    44f8:      	blr	x8
    44fc:      	add	x8, sp, #0xd8
    4500:      	ldr	x8, [x8]
    4504:      	cmp	x8, x20
    4508:      	b.eq	0x4460 <generic_rawtp_process_filter+0x9e0>
    450c:      	mov	w8, #0x4                // =4
    4510:      	add	x9, sp, #0xc0
    4514:      	add	x0, sp, #0xc0
    4518:      	mov	w1, #0x8                // =8
    451c:      	mov	x2, x25
    4520:      	blr	x8
    4524:      	add	x2, x20, #0x20
    4528:      	mov	w8, #0x4                // =4
    452c:      	mov	w9, #0x10               // =16
    4530:      	add	x10, sp, #0xc8
    4534:      	add	x0, sp, #0xc8
    4538:      	mov	w1, #0x10               // =16
    453c:      	blr	x8
    4540:      	ldr	w20, [sp, #0xcc]
    4544:      	ldr	x8, [sp, #0x68]
    4548:      	ldr	x10, [sp, #0x88]
    454c:      	sub	x12, x10, x8
    4550:      	ldr	w22, [sp, #0x90]
    4554:      	subs	w10, w20, w22
    4558:      	ldr	x9, [sp, #0xd0]
    455c:      	csel	w10, wzr, w10, lo
    4560:      	cmp	w22, w20
    4564:      	csel	w11, w22, w20, lo
    4568:      	cinc	w13, w11, hi
    456c:      	sub	w14, w22, w13
    4570:      	subs	x12, x12, x13
    4574:      	str	w14, [sp, #0x90]
    4578:      	b.lo	0x45d8 <generic_rawtp_process_filter+0xb58>
    457c:      	cmp	x12, #0xfff
    4580:      	b.hi	0x45d8 <generic_rawtp_process_filter+0xb58>
    4584:      	cmp	w22, w20
    4588:      	b.ls	0x4594 <generic_rawtp_process_filter+0xb14>
    458c:      	mov	w13, #0x2f              // =47
    4590:      	strb	w13, [x8, x12]
    4594:      	add	x25, x8, x12
    4598:      	cmp	w22, w20
    459c:      	add	x2, x9, x10
    45a0:      	and	w1, w11, #0xff
    45a4:      	mov	w8, #0x4                // =4
    45a8:      	cinc	x0, x25, hi
    45ac:      	blr	x8
    45b0:      	cmp	w22, w20
    45b4:      	str	x25, [sp, #0x88]
    45b8:      	b.ls	0x45d8 <generic_rawtp_process_filter+0xb58>
    45bc:      	ldr	x8, [sp, #0xc0]
    45c0:      	str	x8, [sp, #0x70]
    45c4:      	subs	w19, w19, #0x1
    45c8:      	b.ne	0x44b0 <generic_rawtp_process_filter+0xa30>
    45cc:      	b	0x45d8 <generic_rawtp_process_filter+0xb58>
    45d0:      	mov	w8, #0x1                // =1
    45d4:      	strb	w8, [sp, #0x94]
    45d8:      	ldr	x24, [sp, #0x88]
    45dc:      	ldr	x9, [sp, #0x28]
    45e0:      	cmp	x24, x9
    45e4:      	b.eq	0x4628 <generic_rawtp_process_filter+0xba8>
    45e8:      	ldrb	w8, [sp, #0x94]
    45ec:      	ldr	x29, [sp, #0x40]
    45f0:      	cmp	w8, #0x0
    45f4:      	ldr	x21, [sp, #0x30]
    45f8:      	cset	w8, eq
    45fc:      	lsl	w9, w8, #1
    4600:      	ldr	w8, [sp, #0x90]
    4604:      	cmp	w8, #0x1
    4608:      	str	w8, [x29, #0x550]
    460c:      	str	w9, [x29, #0x554]
    4610:      	b.lt	0x4620 <generic_rawtp_process_filter+0xba0>
    4614:      	mov	w9, #0x1000             // =4096
    4618:      	sub	w8, w9, w8
    461c:      	str	w8, [x29, #0x550]
    4620:      	cbnz	x24, 0x463c <generic_rawtp_process_filter+0xbbc>
    4624:      	b	0x4754 <generic_rawtp_process_filter+0xcd4>
    4628:      	ldr	x29, [sp, #0x40]
    462c:      	ldr	x21, [sp, #0x30]
    4630:      	mov	w8, wzr
    4634:      	mov	x24, x9
    4638:      	str	xzr, [x29, #0x550]
    463c:      	subs	w9, w8, #0x7f
    4640:      	mov	w10, #0x7f              // =127
    4644:      	mov	x11, x29
    4648:      	mov	x0, x21
    464c:      	mov	x2, x24
    4650:      	csel	w29, w8, w10, lo
    4654:      	csel	w19, wzr, w9, lo
    4658:      	cmp	w8, #0xff
    465c:      	mov	w9, #0xff               // =255
    4660:      	csel	w8, w8, w9, lo
    4664:      	and	w1, w8, #0xff
    4668:      	str	w1, [x11, #0x550]
    466c:      	mov	w8, #0x4                // =4
    4670:      	blr	x8
    4674:      	adrp	x25, 0x4000 <generic_rawtp_process_filter+0x580>
    4678:      	ldr	x25, [x25]
    467c:      	cbz	x0, 0x46ec <generic_rawtp_process_filter+0xc6c>
    4680:      	neg	w8, w0
    4684:      	mov	w9, #0x1                // =1
    4688:      	add	x1, sp, #0x58
    468c:      	strh	w8, [sp, #0x58]
    4690:      	mov	w8, #0x8                // =8
    4694:      	mov	x0, x25
    4698:      	mov	w20, #0x1               // =1
    469c:      	strh	w8, [sp, #0x5a]
    46a0:      	mov	x8, #0x2de              // =734
    46a4:      	movk	x8, #0x4, lsl #32
    46a8:      	stur	x8, [sp, #0x5c]
    46ac:      	add	x8, sp, #0x58
    46b0:      	blr	x9
    46b4:      	cbz	x0, 0x46c8 <generic_rawtp_process_filter+0xc48>
    46b8:      	ldr	w8, [x0]
    46bc:      	add	w8, w8, #0x1
    46c0:      	str	w8, [x0]
    46c4:      	b	0x46ec <generic_rawtp_process_filter+0xc6c>
    46c8:      	str	w20, [sp, #0xc8]
    46cc:      	mov	x3, xzr
    46d0:      	mov	w8, #0x2                // =2
    46d4:      	add	x9, sp, #0x58
    46d8:      	add	x10, sp, #0xc8
    46dc:      	add	x1, sp, #0x58
    46e0:      	add	x2, sp, #0xc8
    46e4:      	mov	x0, x25
    46e8:      	blr	x8
    46ec:      	ldr	x9, [sp, #0xe8]
    46f0:      	mov	w8, #0x6390             // =25488
    46f4:      	add	x2, x24, x19
    46f8:      	mov	w1, w29
    46fc:      	add	x0, x9, x8
    4700:      	mov	w8, #0x4                // =4
    4704:      	blr	x8
    4708:      	ldr	x29, [sp, #0x40]
    470c:      	cbz	x0, 0x4754 <generic_rawtp_process_filter+0xcd4>
    4710:      	neg	w8, w0
    4714:      	mov	w9, #0x1                // =1
    4718:      	add	x1, sp, #0x58
    471c:      	strh	w8, [sp, #0x58]
    4720:      	mov	w8, #0x8                // =8
    4724:      	mov	x0, x25
    4728:      	mov	w19, #0x1               // =1
    472c:      	strh	w8, [sp, #0x5a]
    4730:      	mov	x8, #0x2e0              // =736
    4734:      	movk	x8, #0x4, lsl #32
    4738:      	stur	x8, [sp, #0x5c]
    473c:      	add	x8, sp, #0x58
    4740:      	blr	x9
    4744:      	cbz	x0, 0x477c <generic_rawtp_process_filter+0xcfc>
    4748:      	ldr	w8, [x0]
    474c:      	add	w8, w8, #0x1
    4750:      	str	w8, [x0]
    4754:      	ldr	w8, [x29, #0x550]
    4758:      	sub	w9, w8, #0x101
    475c:      	cmn	w9, #0x101
    4760:      	b.hi	0x47b0 <generic_rawtp_process_filter+0xd30>
    4764:      	ldr	x20, [sp, #0x38]
    4768:      	ldr	x22, [sp, #0xe8]
    476c:      	mov	w8, #-0x1               // =-1
    4770:      	ldr	x24, [sp, #0x48]
    4774:      	stur	w8, [x29, #0xb8]
    4778:      	b	0x4900 <generic_rawtp_process_filter+0xe80>
    477c:      	str	w19, [sp, #0xc8]
    4780:      	mov	x3, xzr
    4784:      	mov	w8, #0x2                // =2
    4788:      	add	x9, sp, #0x58
    478c:      	add	x10, sp, #0xc8
    4790:      	add	x1, sp, #0x58
    4794:      	add	x2, sp, #0xc8
    4798:      	mov	x0, x25
    479c:      	blr	x8
    47a0:      	ldr	w8, [x29, #0x550]
    47a4:      	sub	w9, w8, #0x101
    47a8:      	cmn	w9, #0x101
    47ac:      	b.ls	0x4764 <generic_rawtp_process_filter+0xce4>
    47b0:      	ldr	x22, [sp, #0xe8]
    47b4:      	and	x24, x8, #0xff
    47b8:      	mov	w8, #0x5f80             // =24448
    47bc:      	mov	x2, x21
    47c0:      	mov	w1, w24
    47c4:      	add	x0, x22, x8
    47c8:      	mov	w8, #0x4                // =4
    47cc:      	blr	x8
    47d0:      	mov	x23, x0
    47d4:      	cbz	x0, 0x4850 <generic_rawtp_process_filter+0xdd0>
    47d8:      	neg	w8, w23
    47dc:      	adrp	x25, 0x4000 <generic_rawtp_process_filter+0x580>
    47e0:      	mov	w9, #0x1                // =1
    47e4:      	strh	w8, [sp, #0x58]
    47e8:      	mov	w8, #0xf                // =15
    47ec:      	add	x1, sp, #0x58
    47f0:      	mov	w19, #0x1               // =1
    47f4:      	strh	w8, [sp, #0x5a]
    47f8:      	mov	x8, #0x164              // =356
    47fc:      	movk	x8, #0x4, lsl #32
    4800:      	stur	x8, [sp, #0x5c]
    4804:      	add	x8, sp, #0x58
    4808:      	ldr	x25, [x25]
    480c:      	mov	x0, x25
    4810:      	blr	x9
    4814:      	cbz	x0, 0x4828 <generic_rawtp_process_filter+0xda8>
    4818:      	ldr	w8, [x0]
    481c:      	add	w8, w8, #0x1
    4820:      	str	w8, [x0]
    4824:      	b	0x484c <generic_rawtp_process_filter+0xdcc>
    4828:      	str	w19, [sp, #0xc8]
    482c:      	mov	x3, xzr
    4830:      	mov	w8, #0x2                // =2
    4834:      	add	x9, sp, #0x58
    4838:      	add	x10, sp, #0xc8
    483c:      	add	x1, sp, #0x58
    4840:      	add	x2, sp, #0xc8
    4844:      	mov	x0, x25
    4848:      	blr	x8
    484c:      	ldr	x22, [sp, #0xe8]
    4850:      	cmp	w23, #0x0
    4854:      	csel	w8, w24, w23, eq
    4858:      	cmp	w24, #0x7f
    485c:      	stur	w8, [x29, #0xb8]
    4860:      	mov	w8, #0x7f               // =127
    4864:      	csel	w1, w24, w8, lo
    4868:      	mov	w8, #0x6080             // =24704
    486c:      	add	x0, x22, x8
    4870:      	mov	w8, #0x6390             // =25488
    4874:      	add	x2, x22, x8
    4878:      	mov	w8, #0x4                // =4
    487c:      	blr	x8
    4880:      	ldr	x20, [sp, #0x38]
    4884:      	ldr	x24, [sp, #0x48]
    4888:      	cbz	x0, 0x4900 <generic_rawtp_process_filter+0xe80>
    488c:      	neg	w8, w0
    4890:      	adrp	x23, 0x4000 <generic_rawtp_process_filter+0x580>
    4894:      	mov	w9, #0x1                // =1
    4898:      	strh	w8, [sp, #0x58]
    489c:      	mov	w8, #0xf                // =15
    48a0:      	add	x1, sp, #0x58
    48a4:      	mov	w19, #0x1               // =1
    48a8:      	strh	w8, [sp, #0x5a]
    48ac:      	mov	x8, #0x16a              // =362
    48b0:      	movk	x8, #0x4, lsl #32
    48b4:      	stur	x8, [sp, #0x5c]
    48b8:      	add	x8, sp, #0x58
    48bc:      	ldr	x23, [x23]
    48c0:      	mov	x0, x23
    48c4:      	blr	x9
    48c8:      	cbz	x0, 0x48dc <generic_rawtp_process_filter+0xe5c>
    48cc:      	ldr	w8, [x0]
    48d0:      	add	w8, w8, #0x1
    48d4:      	str	w8, [x0]
    48d8:      	b	0x4900 <generic_rawtp_process_filter+0xe80>
    48dc:      	str	w19, [sp, #0xc8]
    48e0:      	mov	x3, xzr
    48e4:      	mov	w8, #0x2                // =2
    48e8:      	add	x9, sp, #0x58
    48ec:      	add	x10, sp, #0xc8
    48f0:      	add	x1, sp, #0x58
    48f4:      	add	x2, sp, #0xc8
    48f8:      	mov	x0, x23
    48fc:      	blr	x8
    4900:      	ldrb	w8, [x22, #0x1]
    4904:      	orr	w8, w8, #0x10
    4908:      	strb	w8, [x22, #0x1]
    490c:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x580>
    4910:      	mov	w8, #0x5ef8             // =24312
    4914:      	ldr	x0, [x0]
    4918:      	add	x1, x22, x8
    491c:      	mov	w8, #0x1                // =1
    4920:      	blr	x8
    4924:      	cbz	x0, 0x5dac <generic_rawtp_process_filter+0x232c>
    4928:      	ldr	x21, [x22, #0x5eb8]
    492c:      	cmp	x21, #0x6
    4930:      	b.hs	0x4ac8 <generic_rawtp_process_filter+0x1048>
    4934:      	ldrsw	x8, [x0]
    4938:      	mov	x23, x0
    493c:      	cbz	w8, 0x4ae4 <generic_rawtp_process_filter+0x1064>
    4940:      	cmp	x21, x8
    4944:      	b.hs	0x4ac8 <generic_rawtp_process_filter+0x1048>
    4948:      	str	x8, [sp, #0x28]
    494c:      	stp	x29, x24, [sp, #0x40]
    4950:      	adrp	x24, 0x4000 <generic_rawtp_process_filter+0x580>
    4954:      	mov	w8, #0x1                // =1
    4958:      	add	x9, sp, #0xd8
    495c:      	str	x22, [sp, #0xe8]
    4960:      	add	x1, sp, #0xd8
    4964:      	str	x20, [sp, #0x38]
    4968:      	str	w21, [sp, #0xd8]
    496c:      	str	wzr, [sp, #0xc0]
    4970:      	ldr	x24, [x24]
    4974:      	mov	x0, x24
    4978:      	blr	x8
    497c:      	cbz	x0, 0x4d94 <generic_rawtp_process_filter+0x1314>
    4980:      	ldr	w8, [x0]
    4984:      	mov	x25, x0
    4988:      	cbz	w8, 0x4d94 <generic_rawtp_process_filter+0x1314>
    498c:      	ldr	x9, [sp, #0x48]
    4990:      	ldr	w9, [x9, #0x68]
    4994:      	tbnz	w9, #0x1f, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    4998:      	cmp	w8, #0x1b
    499c:      	b.hi	0x5d54 <generic_rawtp_process_filter+0x22d4>
    49a0:      	mov	w9, #0x1                // =1
    49a4:      	lsl	w9, w9, w8
    49a8:      	tst	w9, #0x60
    49ac:      	b.ne	0x4ba4 <generic_rawtp_process_filter+0x1124>
    49b0:      	mov	w10, #0x100             // =256
    49b4:      	movk	w10, #0x400, lsl #16
    49b8:      	tst	w9, w10
    49bc:      	b.ne	0x4b20 <generic_rawtp_process_filter+0x10a0>
    49c0:      	mov	w9, #0x1                // =1
    49c4:      	lsl	w8, w9, w8
    49c8:      	mov	w9, #0x200              // =512
    49cc:      	movk	w9, #0x800, lsl #16
    49d0:      	tst	w8, w9
    49d4:      	b.eq	0x5d54 <generic_rawtp_process_filter+0x22d4>
    49d8:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x580>
    49dc:      	add	x1, x25, #0x4
    49e0:      	mov	w8, #0x1                // =1
    49e4:      	ldr	x0, [x0]
    49e8:      	blr	x8
    49ec:      	cbz	x0, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    49f0:      	ldr	x8, [sp, #0x48]
    49f4:      	mov	x20, x0
    49f8:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x580>
    49fc:      	mov	w9, #0x7f               // =127
    4a00:      	ldr	w8, [x8, #0x68]
    4a04:      	ldr	x0, [x0]
    4a08:      	add	x1, sp, #0xc0
    4a0c:      	cmp	w8, #0x7f
    4a10:      	csel	w19, w8, w9, lt
    4a14:      	mov	w8, #0x1                // =1
    4a18:      	add	x9, sp, #0xc0
    4a1c:      	blr	x8
    4a20:      	cbz	x0, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    4a24:      	sxtw	x1, w19
    4a28:      	mov	x29, x0
    4a2c:      	lsl	w8, w1, #3
    4a30:      	str	w8, [x0]
    4a34:      	ldr	x8, [sp, #0x48]
    4a38:      	ldr	w8, [x8, #0x6c]
    4a3c:      	cbnz	w8, 0x4a9c <generic_rawtp_process_filter+0x101c>
    4a40:      	ldr	x11, [sp, #0x48]
    4a44:      	and	w13, w1, #0x7f
    4a48:      	mov	x8, xzr
    4a4c:      	ldr	w12, [x11, #0x68]
    4a50:      	add	x9, x11, #0x1f0
    4a54:      	add	x10, x11, #0x170
    4a58:      	sub	w11, w12, w1
    4a5c:      	add	w12, w12, w13
    4a60:      	add	w11, w11, w13
    4a64:      	mvn	w13, w1
    4a68:      	add	w12, w13, w12
    4a6c:      	cmp	x8, #0x7f
    4a70:      	b.eq	0x4a90 <generic_rawtp_process_filter+0x1010>
    4a74:      	and	x13, x12, #0x7f
    4a78:      	sub	w12, w12, #0x1
    4a7c:      	ldrb	w13, [x10, x13]
    4a80:      	strb	w13, [x9, x8]
    4a84:      	add	x8, x8, #0x1
    4a88:      	cmp	x11, x8
    4a8c:      	b.ne	0x4a6c <generic_rawtp_process_filter+0xfec>
    4a90:      	ldr	x9, [sp, #0x48]
    4a94:      	mov	w8, #0x1                // =1
    4a98:      	str	w8, [x9, #0x6c]
    4a9c:      	cmp	w1, #0x7f
    4aa0:      	b.hi	0x4abc <generic_rawtp_process_filter+0x103c>
    4aa4:      	ldr	x8, [sp, #0x48]
    4aa8:      	add	x0, x29, #0x4
    4aac:      	add	x2, x8, #0x1f0
    4ab0:      	mov	w8, #0x4                // =4
    4ab4:      	blr	x8
    4ab8:      	tbnz	x0, #0x3f, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    4abc:      	mov	w8, #0x1                // =1
    4ac0:      	mov	x0, x20
    4ac4:      	b	0x4b9c <generic_rawtp_process_filter+0x111c>
    4ac8:      	ldr	w8, [x24]
    4acc:      	str	w8, [x22, #0x10]
    4ad0:      	ldr	x8, [x24, #0x8]
    4ad4:      	str	x8, [x22, #0x18]
    4ad8:      	ldrb	w8, [x29]
    4adc:      	cbnz	w8, 0x5d90 <generic_rawtp_process_filter+0x2310>
    4ae0:      	b	0x5dac <generic_rawtp_process_filter+0x232c>
    4ae4:      	mov	w8, #0x1                // =1
    4ae8:      	strb	w8, [x29]
    4aec:      	ldr	w8, [x24]
    4af0:      	str	w8, [x22, #0x10]
    4af4:      	ldr	x8, [x24, #0x8]
    4af8:      	str	x8, [x22, #0x18]
    4afc:      	b	0x5d90 <generic_rawtp_process_filter+0x2310>
    4b00:      	mov	w8, #0x2964             // =10596
    4b04:      	add	x20, x24, #0xff6
    4b08:      	strh	w8, [x24, #0xffe]
    4b0c:      	adrp	x8, 0x4000 <generic_rawtp_process_filter+0x580>
    4b10:      	add	x8, x8, #0x0
    4b14:      	ldr	x8, [x8]
    4b18:      	str	x8, [x20]
    4b1c:      	b	0x41c4 <generic_rawtp_process_filter+0x744>
    4b20:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x580>
    4b24:      	add	x1, x25, #0x4
    4b28:      	mov	w8, #0x1                // =1
    4b2c:      	ldr	x0, [x0]
    4b30:      	blr	x8
    4b34:      	cbz	x0, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    4b38:      	mov	x19, x0
    4b3c:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x580>
    4b40:      	mov	w8, #0x1                // =1
    4b44:      	ldr	x0, [x0]
    4b48:      	add	x9, sp, #0xc0
    4b4c:      	add	x1, sp, #0xc0
    4b50:      	blr	x8
    4b54:      	cbz	x0, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    4b58:      	mov	w1, wzr
    4b5c:      	mov	w2, #0x104              // =260
    4b60:      	mov	x29, x0
    4b64:      	bl	0x4b64 <generic_rawtp_process_filter+0x10e4>
    4b68:      	ldr	x10, [sp, #0x48]
    4b6c:      	mov	x0, x29
    4b70:      	ldr	w8, [x10, #0x68]
    4b74:      	add	x2, x10, #0x70
    4b78:      	lsl	w9, w8, #3
    4b7c:      	and	x8, x8, #0xff
    4b80:      	str	w9, [x0], #0x4
    4b84:      	mov	w9, #0x4                // =4
    4b88:      	ldrb	w1, [x10, #0x68]
    4b8c:      	blr	x9
    4b90:      	tbnz	x0, #0x3f, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    4b94:      	mov	w8, #0x1                // =1
    4b98:      	mov	x0, x19
    4b9c:      	mov	x1, x29
    4ba0:      	b	0x4d5c <generic_rawtp_process_filter+0x12dc>
    4ba4:      	str	wzr, [sp, #0xc8]
    4ba8:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x580>
    4bac:      	mov	w8, #0x1                // =1
    4bb0:      	add	x9, sp, #0xc8
    4bb4:      	ldr	x0, [x0]
    4bb8:      	add	x1, sp, #0xc8
    4bbc:      	blr	x8
    4bc0:      	cbz	x0, 0x4d08 <generic_rawtp_process_filter+0x1288>
    4bc4:      	ldr	x9, [sp, #0x48]
    4bc8:      	ldr	x8, [x0]
    4bcc:      	ldr	x9, [x9, #0x378]
    4bd0:      	cmp	x8, x9
    4bd4:      	b.eq	0x4d08 <generic_rawtp_process_filter+0x1288>
    4bd8:      	str	x0, [sp, #0x30]
    4bdc:      	adrp	x8, 0x4000 <generic_rawtp_process_filter+0x580>
    4be0:      	ldr	x8, [x8]
    4be4:      	ldrb	w8, [x8]
    4be8:      	cbz	w8, 0x4c74 <generic_rawtp_process_filter+0x11f4>
    4bec:      	adrp	x19, 0x4000 <generic_rawtp_process_filter+0x580>
    4bf0:      	mov	w20, #0x869f            // =34463
    4bf4:      	mov	x22, xzr
    4bf8:      	ldr	x19, [x19]
    4bfc:      	movk	w20, #0x1, lsl #16
    4c00:      	b	0x4c18 <generic_rawtp_process_filter+0x1198>
    4c04:      	cmp	x29, x22
    4c08:      	mov	x22, x29
    4c0c:      	ccmp	w20, #0x0, #0x4, ne
    4c10:      	sub	w20, w20, #0x1
    4c14:      	b.eq	0x4cf8 <generic_rawtp_process_filter+0x1278>
    4c18:      	ldr	x8, [sp, #0x48]
    4c1c:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x580>
    4c20:      	add	x9, sp, #0x58
    4c24:      	add	x1, sp, #0x58
    4c28:      	ldr	w8, [x8, #0x10]
    4c2c:      	str	w8, [sp, #0x58]
    4c30:      	mov	w8, #0x1                // =1
    4c34:      	ldr	x0, [x0]
    4c38:      	blr	x8
    4c3c:      	cbz	x0, 0x4cf8 <generic_rawtp_process_filter+0x1278>
    4c40:      	add	x1, x0, #0x70
    4c44:      	mov	w8, #0x1                // =1
    4c48:      	mov	x29, x0
    4c4c:      	mov	x0, x19
    4c50:      	blr	x8
    4c54:      	cbz	x0, 0x4c04 <generic_rawtp_process_filter+0x1184>
    4c58:      	ldr	x8, [x0]
    4c5c:      	cbz	x8, 0x4c04 <generic_rawtp_process_filter+0x1184>
    4c60:      	ldr	x10, [sp, #0x48]
    4c64:      	ldr	x9, [x10, #0x370]
    4c68:      	orr	x8, x9, x8
    4c6c:      	str	x8, [x10, #0x370]
    4c70:      	b	0x4c04 <generic_rawtp_process_filter+0x1184>
    4c74:      	adrp	x19, 0x4000 <generic_rawtp_process_filter+0x580>
    4c78:      	mov	x22, xzr
    4c7c:      	mov	w20, #0x3ff             // =1023
    4c80:      	ldr	x19, [x19]
    4c84:      	b	0x4c9c <generic_rawtp_process_filter+0x121c>
    4c88:      	cmp	x29, x22
    4c8c:      	mov	x22, x29
    4c90:      	ccmp	w20, #0x0, #0x4, ne
    4c94:      	sub	w20, w20, #0x1
    4c98:      	b.eq	0x4cf8 <generic_rawtp_process_filter+0x1278>
    4c9c:      	ldr	x8, [sp, #0x48]
    4ca0:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x580>
    4ca4:      	add	x9, sp, #0x58
    4ca8:      	add	x1, sp, #0x58
    4cac:      	ldr	w8, [x8, #0x10]
    4cb0:      	str	w8, [sp, #0x58]
    4cb4:      	mov	w8, #0x1                // =1
    4cb8:      	ldr	x0, [x0]
    4cbc:      	blr	x8
    4cc0:      	cbz	x0, 0x4cf8 <generic_rawtp_process_filter+0x1278>
    4cc4:      	add	x1, x0, #0x70
    4cc8:      	mov	w8, #0x1                // =1
    4ccc:      	mov	x29, x0
    4cd0:      	mov	x0, x19
    4cd4:      	blr	x8
    4cd8:      	cbz	x0, 0x4c88 <generic_rawtp_process_filter+0x1208>
    4cdc:      	ldr	x8, [x0]
    4ce0:      	cbz	x8, 0x4c88 <generic_rawtp_process_filter+0x1208>
    4ce4:      	ldr	x10, [sp, #0x48]
    4ce8:      	ldr	x9, [x10, #0x370]
    4cec:      	orr	x8, x9, x8
    4cf0:      	str	x8, [x10, #0x370]
    4cf4:      	b	0x4c88 <generic_rawtp_process_filter+0x1208>
    4cf8:      	ldr	x8, [sp, #0x30]
    4cfc:      	ldr	x9, [sp, #0x48]
    4d00:      	ldr	x8, [x8]
    4d04:      	str	x8, [x9, #0x378]
    4d08:      	ldr	w8, [x25, #0x8]
    4d0c:      	cmn	w8, #0x1
    4d10:      	b.eq	0x4d34 <generic_rawtp_process_filter+0x12b4>
    4d14:      	ldr	x9, [sp, #0x48]
    4d18:      	ldr	x9, [x9, #0x370]
    4d1c:      	lsr	x8, x9, x8
    4d20:      	tbz	w8, #0x0, 0x4d34 <generic_rawtp_process_filter+0x12b4>
    4d24:      	mov	x0, #0xffee             // =65518
    4d28:      	movk	x0, #0xadc0, lsl #16
    4d2c:      	movk	x0, #0xb, lsl #32
    4d30:      	b	0x4d60 <generic_rawtp_process_filter+0x12e0>
    4d34:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x580>
    4d38:      	mov	w8, #0x1                // =1
    4d3c:      	add	x9, sp, #0xd8
    4d40:      	ldr	x0, [x0]
    4d44:      	add	x1, sp, #0xd8
    4d48:      	blr	x8
    4d4c:      	cbz	x0, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    4d50:      	ldr	x8, [sp, #0x48]
    4d54:      	add	x1, x8, #0x70
    4d58:      	mov	w8, #0x1                // =1
    4d5c:      	blr	x8
    4d60:      	ldr	w8, [x25]
    4d64:      	cmp	w8, #0x25
    4d68:      	b.hi	0x4d90 <generic_rawtp_process_filter+0x1310>
    4d6c:      	mov	w9, #0x1                // =1
    4d70:      	lsl	x8, x9, x8
    4d74:      	mov	x9, #0x50               // =80
    4d78:      	movk	x9, #0xc00, lsl #16
    4d7c:      	movk	x9, #0x20, lsl #32
    4d80:      	tst	x8, x9
    4d84:      	b.eq	0x4d90 <generic_rawtp_process_filter+0x1310>
    4d88:      	cbnz	x0, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    4d8c:      	b	0x4d94 <generic_rawtp_process_filter+0x1314>
    4d90:      	cbz	x0, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    4d94:      	adrp	x8, 0x4000 <generic_rawtp_process_filter+0x580>
    4d98:      	ldr	x8, [x8]
    4d9c:      	ldrb	w8, [x8]
    4da0:      	cbz	w8, 0x516c <generic_rawtp_process_filter+0x16ec>
    4da4:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x580>
    4da8:      	mov	w8, #0x1                // =1
    4dac:      	ldr	x0, [x0]
    4db0:      	ldr	x1, [sp, #0x48]
    4db4:      	blr	x8
    4db8:      	cbz	x0, 0x516c <generic_rawtp_process_filter+0x16ec>
    4dbc:      	add	w8, w21, #0x5
    4dc0:      	str	wzr, [sp, #0xc0]
    4dc4:      	add	x9, sp, #0xd8
    4dc8:      	mov	x25, x0
    4dcc:      	str	w8, [sp, #0xd8]
    4dd0:      	mov	w8, #0x1                // =1
    4dd4:      	add	x1, sp, #0xd8
    4dd8:      	mov	x0, x24
    4ddc:      	blr	x8
    4de0:      	cbz	x0, 0x516c <generic_rawtp_process_filter+0x16ec>
    4de4:      	ldr	w8, [x0]
    4de8:      	mov	x24, x0
    4dec:      	cbz	w8, 0x516c <generic_rawtp_process_filter+0x16ec>
    4df0:      	ldr	w9, [x25]
    4df4:      	tbnz	w9, #0x1f, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    4df8:      	cmp	w8, #0x1b
    4dfc:      	b.hi	0x5d54 <generic_rawtp_process_filter+0x22d4>
    4e00:      	mov	w9, #0x1                // =1
    4e04:      	lsl	w9, w9, w8
    4e08:      	tst	w9, #0x60
    4e0c:      	b.ne	0x4f94 <generic_rawtp_process_filter+0x1514>
    4e10:      	mov	w10, #0x100             // =256
    4e14:      	movk	w10, #0x400, lsl #16
    4e18:      	tst	w9, w10
    4e1c:      	b.ne	0x4f14 <generic_rawtp_process_filter+0x1494>
    4e20:      	mov	w9, #0x1                // =1
    4e24:      	lsl	w8, w9, w8
    4e28:      	mov	w9, #0x200              // =512
    4e2c:      	movk	w9, #0x800, lsl #16
    4e30:      	tst	w8, w9
    4e34:      	b.eq	0x5d54 <generic_rawtp_process_filter+0x22d4>
    4e38:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x580>
    4e3c:      	add	x1, x24, #0x4
    4e40:      	mov	w8, #0x1                // =1
    4e44:      	ldr	x0, [x0]
    4e48:      	blr	x8
    4e4c:      	cbz	x0, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    4e50:      	ldr	w8, [x25]
    4e54:      	mov	x20, x0
    4e58:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x580>
    4e5c:      	mov	w9, #0x7f               // =127
    4e60:      	ldr	x0, [x0]
    4e64:      	add	x1, sp, #0xc0
    4e68:      	cmp	w8, #0x7f
    4e6c:      	csel	w19, w8, w9, lt
    4e70:      	mov	w8, #0x1                // =1
    4e74:      	add	x9, sp, #0xc0
    4e78:      	blr	x8
    4e7c:      	cbz	x0, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    4e80:      	sxtw	x1, w19
    4e84:      	mov	x29, x0
    4e88:      	lsl	w8, w1, #3
    4e8c:      	str	w8, [x0]
    4e90:      	ldr	w8, [x25, #0x4]
    4e94:      	cbnz	w8, 0x4eec <generic_rawtp_process_filter+0x146c>
    4e98:      	ldr	w12, [x25]
    4e9c:      	and	w13, w1, #0x7f
    4ea0:      	mov	x8, xzr
    4ea4:      	add	x9, x25, #0x188
    4ea8:      	add	x10, x25, #0x108
    4eac:      	sub	w11, w12, w1
    4eb0:      	add	w12, w12, w13
    4eb4:      	add	w11, w11, w13
    4eb8:      	mvn	w13, w1
    4ebc:      	add	w12, w13, w12
    4ec0:      	cmp	x8, #0x7f
    4ec4:      	b.eq	0x4ee4 <generic_rawtp_process_filter+0x1464>
    4ec8:      	and	x13, x12, #0x7f
    4ecc:      	sub	w12, w12, #0x1
    4ed0:      	ldrb	w13, [x10, x13]
    4ed4:      	strb	w13, [x9, x8]
    4ed8:      	add	x8, x8, #0x1
    4edc:      	cmp	x11, x8
    4ee0:      	b.ne	0x4ec0 <generic_rawtp_process_filter+0x1440>
    4ee4:      	mov	w8, #0x1                // =1
    4ee8:      	str	w8, [x25, #0x4]
    4eec:      	cmp	w1, #0x7f
    4ef0:      	b.hi	0x4f08 <generic_rawtp_process_filter+0x1488>
    4ef4:      	add	x0, x29, #0x4
    4ef8:      	add	x2, x25, #0x188
    4efc:      	mov	w8, #0x4                // =4
    4f00:      	blr	x8
    4f04:      	tbnz	x0, #0x3f, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    4f08:      	mov	w8, #0x1                // =1
    4f0c:      	mov	x0, x20
    4f10:      	b	0x4f8c <generic_rawtp_process_filter+0x150c>
    4f14:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x580>
    4f18:      	add	x1, x24, #0x4
    4f1c:      	mov	w8, #0x1                // =1
    4f20:      	ldr	x0, [x0]
    4f24:      	blr	x8
    4f28:      	cbz	x0, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    4f2c:      	mov	x19, x0
    4f30:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x580>
    4f34:      	mov	w8, #0x1                // =1
    4f38:      	ldr	x0, [x0]
    4f3c:      	add	x9, sp, #0xc0
    4f40:      	add	x1, sp, #0xc0
    4f44:      	blr	x8
    4f48:      	cbz	x0, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    4f4c:      	mov	w1, wzr
    4f50:      	mov	w2, #0x104              // =260
    4f54:      	mov	x29, x0
    4f58:      	bl	0x4f58 <generic_rawtp_process_filter+0x14d8>
    4f5c:      	ldr	w8, [x25]
    4f60:      	mov	x0, x29
    4f64:      	add	x2, x25, #0x8
    4f68:      	lsl	w9, w8, #3
    4f6c:      	and	x8, x8, #0xff
    4f70:      	str	w9, [x0], #0x4
    4f74:      	mov	w9, #0x4                // =4
    4f78:      	ldrb	w1, [x25]
    4f7c:      	blr	x9
    4f80:      	tbnz	x0, #0x3f, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    4f84:      	mov	w8, #0x1                // =1
    4f88:      	mov	x0, x19
    4f8c:      	mov	x1, x29
    4f90:      	b	0x5134 <generic_rawtp_process_filter+0x16b4>
    4f94:      	str	wzr, [sp, #0xc8]
    4f98:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x580>
    4f9c:      	mov	w8, #0x1                // =1
    4fa0:      	add	x9, sp, #0xc8
    4fa4:      	ldr	x0, [x0]
    4fa8:      	add	x1, sp, #0xc8
    4fac:      	blr	x8
    4fb0:      	cbz	x0, 0x50e8 <generic_rawtp_process_filter+0x1668>
    4fb4:      	ldr	x8, [x0]
    4fb8:      	ldr	x9, [x25, #0x310]
    4fbc:      	cmp	x8, x9
    4fc0:      	b.eq	0x50e8 <generic_rawtp_process_filter+0x1668>
    4fc4:      	str	x0, [sp, #0x30]
    4fc8:      	adrp	x8, 0x4000 <generic_rawtp_process_filter+0x580>
    4fcc:      	ldr	x8, [x8]
    4fd0:      	ldrb	w8, [x8]
    4fd4:      	cbz	w8, 0x505c <generic_rawtp_process_filter+0x15dc>
    4fd8:      	adrp	x19, 0x4000 <generic_rawtp_process_filter+0x580>
    4fdc:      	mov	w20, #0x869f            // =34463
    4fe0:      	mov	x22, xzr
    4fe4:      	ldr	x19, [x19]
    4fe8:      	movk	w20, #0x1, lsl #16
    4fec:      	b	0x5004 <generic_rawtp_process_filter+0x1584>
    4ff0:      	cmp	x29, x22
    4ff4:      	mov	x22, x29
    4ff8:      	ccmp	w20, #0x0, #0x4, ne
    4ffc:      	sub	w20, w20, #0x1
    5000:      	b.eq	0x50dc <generic_rawtp_process_filter+0x165c>
    5004:      	ldr	x8, [sp, #0x48]
    5008:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    500c:      	add	x9, sp, #0x58
    5010:      	add	x1, sp, #0x58
    5014:      	ldr	w8, [x8, #0x10]
    5018:      	str	w8, [sp, #0x58]
    501c:      	mov	w8, #0x1                // =1
    5020:      	ldr	x0, [x0]
    5024:      	blr	x8
    5028:      	cbz	x0, 0x50dc <generic_rawtp_process_filter+0x165c>
    502c:      	add	x1, x0, #0x70
    5030:      	mov	w8, #0x1                // =1
    5034:      	mov	x29, x0
    5038:      	mov	x0, x19
    503c:      	blr	x8
    5040:      	cbz	x0, 0x4ff0 <generic_rawtp_process_filter+0x1570>
    5044:      	ldr	x8, [x0]
    5048:      	cbz	x8, 0x4ff0 <generic_rawtp_process_filter+0x1570>
    504c:      	ldr	x9, [x25, #0x308]
    5050:      	orr	x8, x9, x8
    5054:      	str	x8, [x25, #0x308]
    5058:      	b	0x4ff0 <generic_rawtp_process_filter+0x1570>
    505c:      	adrp	x19, 0x5000 <generic_rawtp_process_filter+0x1580>
    5060:      	mov	x22, xzr
    5064:      	mov	w20, #0x3ff             // =1023
    5068:      	ldr	x19, [x19]
    506c:      	b	0x5084 <generic_rawtp_process_filter+0x1604>
    5070:      	cmp	x29, x22
    5074:      	mov	x22, x29
    5078:      	ccmp	w20, #0x0, #0x4, ne
    507c:      	sub	w20, w20, #0x1
    5080:      	b.eq	0x50dc <generic_rawtp_process_filter+0x165c>
    5084:      	ldr	x8, [sp, #0x48]
    5088:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    508c:      	add	x9, sp, #0x58
    5090:      	add	x1, sp, #0x58
    5094:      	ldr	w8, [x8, #0x10]
    5098:      	str	w8, [sp, #0x58]
    509c:      	mov	w8, #0x1                // =1
    50a0:      	ldr	x0, [x0]
    50a4:      	blr	x8
    50a8:      	cbz	x0, 0x50dc <generic_rawtp_process_filter+0x165c>
    50ac:      	add	x1, x0, #0x70
    50b0:      	mov	w8, #0x1                // =1
    50b4:      	mov	x29, x0
    50b8:      	mov	x0, x19
    50bc:      	blr	x8
    50c0:      	cbz	x0, 0x5070 <generic_rawtp_process_filter+0x15f0>
    50c4:      	ldr	x8, [x0]
    50c8:      	cbz	x8, 0x5070 <generic_rawtp_process_filter+0x15f0>
    50cc:      	ldr	x9, [x25, #0x308]
    50d0:      	orr	x8, x9, x8
    50d4:      	str	x8, [x25, #0x308]
    50d8:      	b	0x5070 <generic_rawtp_process_filter+0x15f0>
    50dc:      	ldr	x8, [sp, #0x30]
    50e0:      	ldr	x8, [x8]
    50e4:      	str	x8, [x25, #0x310]
    50e8:      	ldr	w8, [x24, #0x8]
    50ec:      	cmn	w8, #0x1
    50f0:      	b.eq	0x5110 <generic_rawtp_process_filter+0x1690>
    50f4:      	ldr	x9, [x25, #0x308]
    50f8:      	lsr	x8, x9, x8
    50fc:      	tbz	w8, #0x0, 0x5110 <generic_rawtp_process_filter+0x1690>
    5100:      	mov	x0, #0xffee             // =65518
    5104:      	movk	x0, #0xadc0, lsl #16
    5108:      	movk	x0, #0xb, lsl #32
    510c:      	b	0x5138 <generic_rawtp_process_filter+0x16b8>
    5110:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    5114:      	mov	w8, #0x1                // =1
    5118:      	add	x9, sp, #0xd8
    511c:      	ldr	x0, [x0]
    5120:      	add	x1, sp, #0xd8
    5124:      	blr	x8
    5128:      	cbz	x0, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    512c:      	add	x1, x25, #0x8
    5130:      	mov	w8, #0x1                // =1
    5134:      	blr	x8
    5138:      	ldr	w8, [x24]
    513c:      	cmp	w8, #0x25
    5140:      	b.hi	0x5168 <generic_rawtp_process_filter+0x16e8>
    5144:      	mov	w9, #0x1                // =1
    5148:      	lsl	x8, x9, x8
    514c:      	mov	x9, #0x50               // =80
    5150:      	movk	x9, #0xc00, lsl #16
    5154:      	movk	x9, #0x20, lsl #32
    5158:      	tst	x8, x9
    515c:      	b.eq	0x5168 <generic_rawtp_process_filter+0x16e8>
    5160:      	cbnz	x0, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    5164:      	b	0x516c <generic_rawtp_process_filter+0x16ec>
    5168:      	cbz	x0, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    516c:      	lsl	w8, w21, #2
    5170:      	add	x9, x8, #0x4
    5174:      	ldr	w8, [x9, x23]
    5178:      	add	w9, w8, w9
    517c:      	and	w11, w9, #0x3ff
    5180:      	add	w9, w9, #0x4
    5184:      	and	x9, x9, #0x3ff
    5188:      	add	x10, x11, #0x8
    518c:      	ldr	w9, [x9, x23]
    5190:      	cmp	w9, #0x5
    5194:      	b.lo	0x5224 <generic_rawtp_process_filter+0x17a4>
    5198:      	add	x9, x10, x23
    519c:      	ldr	w10, [x9, #0x8]
    51a0:      	ldp	w12, w22, [x9]
    51a4:      	stp	x9, x11, [sp, #0x8]
    51a8:      	mov	w9, #0x4                // =4
    51ac:      	cmp	w10, #0x4
    51b0:      	stp	xzr, xzr, [sp, #0x58]
    51b4:      	csel	w9, w10, w9, lo
    51b8:      	cmp	w12, #0x6
    51bc:      	b.ne	0x51c8 <generic_rawtp_process_filter+0x1748>
    51c0:      	mov	x11, #0x100000001       // =4294967297
    51c4:      	stp	x11, x11, [sp, #0x58]
    51c8:      	cbz	w10, 0x562c <generic_rawtp_process_filter+0x1bac>
    51cc:      	ldr	x10, [sp, #0x48]
    51d0:      	add	w8, w8, w21, lsl #2
    51d4:      	tst	x22, #0x1
    51d8:      	add	x25, sp, #0x58
    51dc:      	str	w12, [sp, #0x30]
    51e0:      	add	w8, w8, #0x4
    51e4:      	and	x8, x8, #0x3ff
    51e8:      	add	x21, x8, #0x14
    51ec:      	sub	x8, x9, #0x1
    51f0:      	mov	w9, #0x3                // =3
    51f4:      	add	x11, x10, #0x24
    51f8:      	str	x11, [sp, #0x20]
    51fc:      	csel	x11, x10, x11, eq
    5200:      	cmp	x8, #0x3
    5204:      	add	x10, x10, #0x10
    5208:      	csel	x8, x8, x9, lo
    520c:      	and	x9, x21, #0x7fc
    5210:      	mov	x20, x11
    5214:      	str	x10, [sp, #0x18]
    5218:      	add	x19, x23, x9
    521c:      	add	x24, x8, #0x1
    5220:      	b	0x525c <generic_rawtp_process_filter+0x17dc>
    5224:      	mov	w9, #0x1                // =1
    5228:      	mov	w8, w10
    522c:      	b	0x5674 <generic_rawtp_process_filter+0x1bf4>
    5230:      	mov	w8, #0x1                // =1
    5234:      	ldr	w12, [sp, #0x30]
    5238:      	mov	x11, x20
    523c:      	cmp	w12, #0x6
    5240:      	eor	w8, w8, #0x1
    5244:      	csinc	w9, w8, wzr, eq
    5248:      	str	w9, [x25], #0x4
    524c:      	add	x21, x21, #0x4
    5250:      	add	x19, x19, #0x4
    5254:      	subs	x24, x24, #0x1
    5258:      	b.eq	0x562c <generic_rawtp_process_filter+0x1bac>
    525c:      	cmp	x21, #0x3e8
    5260:      	b.ls	0x5484 <generic_rawtp_process_filter+0x1a04>
    5264:      	mov	x29, xzr
    5268:      	tbz	w22, #0x1, 0x548c <generic_rawtp_process_filter+0x1a0c>
    526c:      	tbnz	w22, #0x0, 0x54b8 <generic_rawtp_process_filter+0x1a38>
    5270:      	ldr	x10, [sp, #0x48]
    5274:      	mov	w8, #0x1                // =1
    5278:      	ldr	w9, [x10]
    527c:      	cmp	x29, x9
    5280:      	b.eq	0x523c <generic_rawtp_process_filter+0x17bc>
    5284:      	ldr	w9, [x10, #0x10]
    5288:      	cmp	x29, x9
    528c:      	b.eq	0x523c <generic_rawtp_process_filter+0x17bc>
    5290:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    5294:      	mov	w8, #0x1                // =1
    5298:      	ldr	x0, [x0]
    529c:      	ldr	x1, [sp, #0x18]
    52a0:      	blr	x8
    52a4:      	cbz	x0, 0x5610 <generic_rawtp_process_filter+0x1b90>
    52a8:      	ldr	w9, [x0]
    52ac:      	mov	x1, x0
    52b0:      	mov	w8, #0x1                // =1
    52b4:      	cmp	x29, x9
    52b8:      	b.eq	0x5234 <generic_rawtp_process_filter+0x17b4>
    52bc:      	ldr	w9, [x1, #0x10]!
    52c0:      	ldr	w12, [sp, #0x30]
    52c4:      	mov	x11, x20
    52c8:      	cmp	x29, x9
    52cc:      	b.eq	0x523c <generic_rawtp_process_filter+0x17bc>
    52d0:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    52d4:      	mov	w8, #0x1                // =1
    52d8:      	ldr	x0, [x0]
    52dc:      	blr	x8
    52e0:      	cbz	x0, 0x5610 <generic_rawtp_process_filter+0x1b90>
    52e4:      	ldr	w9, [x0]
    52e8:      	mov	x1, x0
    52ec:      	mov	w8, #0x1                // =1
    52f0:      	cmp	x29, x9
    52f4:      	b.eq	0x5234 <generic_rawtp_process_filter+0x17b4>
    52f8:      	ldr	w9, [x1, #0x10]!
    52fc:      	ldr	w12, [sp, #0x30]
    5300:      	mov	x11, x20
    5304:      	cmp	x29, x9
    5308:      	b.eq	0x523c <generic_rawtp_process_filter+0x17bc>
    530c:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    5310:      	mov	w8, #0x1                // =1
    5314:      	ldr	x0, [x0]
    5318:      	blr	x8
    531c:      	cbz	x0, 0x5610 <generic_rawtp_process_filter+0x1b90>
    5320:      	ldr	w9, [x0]
    5324:      	mov	x1, x0
    5328:      	mov	w8, #0x1                // =1
    532c:      	cmp	x29, x9
    5330:      	b.eq	0x5234 <generic_rawtp_process_filter+0x17b4>
    5334:      	ldr	w9, [x1, #0x10]!
    5338:      	ldr	w12, [sp, #0x30]
    533c:      	mov	x11, x20
    5340:      	cmp	x29, x9
    5344:      	b.eq	0x523c <generic_rawtp_process_filter+0x17bc>
    5348:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    534c:      	mov	w8, #0x1                // =1
    5350:      	ldr	x0, [x0]
    5354:      	blr	x8
    5358:      	cbz	x0, 0x5610 <generic_rawtp_process_filter+0x1b90>
    535c:      	ldr	w9, [x0]
    5360:      	mov	x1, x0
    5364:      	mov	w8, #0x1                // =1
    5368:      	cmp	x29, x9
    536c:      	b.eq	0x5234 <generic_rawtp_process_filter+0x17b4>
    5370:      	ldr	w9, [x1, #0x10]!
    5374:      	ldr	w12, [sp, #0x30]
    5378:      	mov	x11, x20
    537c:      	cmp	x29, x9
    5380:      	b.eq	0x523c <generic_rawtp_process_filter+0x17bc>
    5384:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    5388:      	mov	w8, #0x1                // =1
    538c:      	ldr	x0, [x0]
    5390:      	blr	x8
    5394:      	cbz	x0, 0x5610 <generic_rawtp_process_filter+0x1b90>
    5398:      	ldr	w9, [x0]
    539c:      	mov	x1, x0
    53a0:      	mov	w8, #0x1                // =1
    53a4:      	cmp	x29, x9
    53a8:      	b.eq	0x5234 <generic_rawtp_process_filter+0x17b4>
    53ac:      	ldr	w9, [x1, #0x10]!
    53b0:      	ldr	w12, [sp, #0x30]
    53b4:      	mov	x11, x20
    53b8:      	cmp	x29, x9
    53bc:      	b.eq	0x523c <generic_rawtp_process_filter+0x17bc>
    53c0:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    53c4:      	mov	w8, #0x1                // =1
    53c8:      	ldr	x0, [x0]
    53cc:      	blr	x8
    53d0:      	cbz	x0, 0x5610 <generic_rawtp_process_filter+0x1b90>
    53d4:      	ldr	w9, [x0]
    53d8:      	mov	x1, x0
    53dc:      	mov	w8, #0x1                // =1
    53e0:      	cmp	x29, x9
    53e4:      	b.eq	0x5234 <generic_rawtp_process_filter+0x17b4>
    53e8:      	ldr	w9, [x1, #0x10]!
    53ec:      	ldr	w12, [sp, #0x30]
    53f0:      	mov	x11, x20
    53f4:      	cmp	x29, x9
    53f8:      	b.eq	0x523c <generic_rawtp_process_filter+0x17bc>
    53fc:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    5400:      	mov	w8, #0x1                // =1
    5404:      	ldr	x0, [x0]
    5408:      	blr	x8
    540c:      	cbz	x0, 0x5610 <generic_rawtp_process_filter+0x1b90>
    5410:      	ldr	w9, [x0]
    5414:      	mov	x1, x0
    5418:      	mov	w8, #0x1                // =1
    541c:      	cmp	x29, x9
    5420:      	b.eq	0x5234 <generic_rawtp_process_filter+0x17b4>
    5424:      	ldr	w9, [x1, #0x10]!
    5428:      	ldr	w12, [sp, #0x30]
    542c:      	mov	x11, x20
    5430:      	cmp	x29, x9
    5434:      	b.eq	0x523c <generic_rawtp_process_filter+0x17bc>
    5438:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    543c:      	mov	w8, #0x1                // =1
    5440:      	ldr	x0, [x0]
    5444:      	blr	x8
    5448:      	cbz	x0, 0x5610 <generic_rawtp_process_filter+0x1b90>
    544c:      	ldr	w9, [x0]
    5450:      	mov	x1, x0
    5454:      	mov	w8, #0x1                // =1
    5458:      	cmp	x29, x9
    545c:      	b.eq	0x5234 <generic_rawtp_process_filter+0x17b4>
    5460:      	ldr	w9, [x1, #0x10]!
    5464:      	ldr	w12, [sp, #0x30]
    5468:      	mov	x11, x20
    546c:      	cmp	x29, x9
    5470:      	b.eq	0x523c <generic_rawtp_process_filter+0x17bc>
    5474:      	adrp	x9, 0x5000 <generic_rawtp_process_filter+0x1580>
    5478:      	mov	w8, #0x1                // =1
    547c:      	ldr	x9, [x9]
    5480:      	b	0x5604 <generic_rawtp_process_filter+0x1b84>
    5484:      	ldr	w29, [x19]
    5488:      	tbnz	w22, #0x1, 0x526c <generic_rawtp_process_filter+0x17ec>
    548c:      	ldr	w8, [x11]
    5490:      	cmp	w12, #0x5
    5494:      	b.ne	0x54a8 <generic_rawtp_process_filter+0x1a28>
    5498:      	cmp	x29, x8
    549c:      	b.eq	0x54a8 <generic_rawtp_process_filter+0x1a28>
    54a0:      	mov	w9, wzr
    54a4:      	b	0x5248 <generic_rawtp_process_filter+0x17c8>
    54a8:      	cmp	w12, #0x6
    54ac:      	ccmp	x29, x8, #0x0, eq
    54b0:      	cset	w9, ne
    54b4:      	b	0x5248 <generic_rawtp_process_filter+0x17c8>
    54b8:      	ldr	x8, [sp, #0x20]
    54bc:      	ldr	w9, [x8]
    54c0:      	cbz	w9, 0x5248 <generic_rawtp_process_filter+0x17c8>
    54c4:      	mov	w8, #0x1                // =1
    54c8:      	cbz	x29, 0x523c <generic_rawtp_process_filter+0x17bc>
    54cc:      	cmp	x29, x9
    54d0:      	b.eq	0x523c <generic_rawtp_process_filter+0x17bc>
    54d4:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    54d8:      	mov	w8, #0x1                // =1
    54dc:      	ldr	x0, [x0]
    54e0:      	ldr	x1, [sp, #0x18]
    54e4:      	blr	x8
    54e8:      	cbz	x0, 0x5610 <generic_rawtp_process_filter+0x1b90>
    54ec:      	ldr	w8, [x0, #0x24]
    54f0:      	cmp	x29, x8
    54f4:      	b.eq	0x5230 <generic_rawtp_process_filter+0x17b0>
    54f8:      	add	x1, x0, #0x10
    54fc:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    5500:      	mov	w8, #0x1                // =1
    5504:      	ldr	x0, [x0]
    5508:      	blr	x8
    550c:      	cbz	x0, 0x5610 <generic_rawtp_process_filter+0x1b90>
    5510:      	ldr	w8, [x0, #0x24]
    5514:      	cmp	x29, x8
    5518:      	b.eq	0x5230 <generic_rawtp_process_filter+0x17b0>
    551c:      	add	x1, x0, #0x10
    5520:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    5524:      	mov	w8, #0x1                // =1
    5528:      	ldr	x0, [x0]
    552c:      	blr	x8
    5530:      	cbz	x0, 0x5610 <generic_rawtp_process_filter+0x1b90>
    5534:      	ldr	w8, [x0, #0x24]
    5538:      	cmp	x29, x8
    553c:      	b.eq	0x5230 <generic_rawtp_process_filter+0x17b0>
    5540:      	add	x1, x0, #0x10
    5544:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    5548:      	mov	w8, #0x1                // =1
    554c:      	ldr	x0, [x0]
    5550:      	blr	x8
    5554:      	cbz	x0, 0x5610 <generic_rawtp_process_filter+0x1b90>
    5558:      	ldr	w8, [x0, #0x24]
    555c:      	cmp	x29, x8
    5560:      	b.eq	0x5230 <generic_rawtp_process_filter+0x17b0>
    5564:      	add	x1, x0, #0x10
    5568:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    556c:      	mov	w8, #0x1                // =1
    5570:      	ldr	x0, [x0]
    5574:      	blr	x8
    5578:      	cbz	x0, 0x5610 <generic_rawtp_process_filter+0x1b90>
    557c:      	ldr	w8, [x0, #0x24]
    5580:      	cmp	x29, x8
    5584:      	b.eq	0x5230 <generic_rawtp_process_filter+0x17b0>
    5588:      	add	x1, x0, #0x10
    558c:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    5590:      	mov	w8, #0x1                // =1
    5594:      	ldr	x0, [x0]
    5598:      	blr	x8
    559c:      	cbz	x0, 0x5610 <generic_rawtp_process_filter+0x1b90>
    55a0:      	ldr	w8, [x0, #0x24]
    55a4:      	cmp	x29, x8
    55a8:      	b.eq	0x5230 <generic_rawtp_process_filter+0x17b0>
    55ac:      	add	x1, x0, #0x10
    55b0:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    55b4:      	mov	w8, #0x1                // =1
    55b8:      	ldr	x0, [x0]
    55bc:      	blr	x8
    55c0:      	cbz	x0, 0x5610 <generic_rawtp_process_filter+0x1b90>
    55c4:      	ldr	w8, [x0, #0x24]
    55c8:      	cmp	x29, x8
    55cc:      	b.eq	0x5230 <generic_rawtp_process_filter+0x17b0>
    55d0:      	add	x1, x0, #0x10
    55d4:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    55d8:      	mov	w8, #0x1                // =1
    55dc:      	ldr	x0, [x0]
    55e0:      	blr	x8
    55e4:      	cbz	x0, 0x5610 <generic_rawtp_process_filter+0x1b90>
    55e8:      	ldr	w8, [x0, #0x24]
    55ec:      	cmp	x29, x8
    55f0:      	b.eq	0x5230 <generic_rawtp_process_filter+0x17b0>
    55f4:      	adrp	x9, 0x5000 <generic_rawtp_process_filter+0x1580>
    55f8:      	add	x1, x0, #0x10
    55fc:      	mov	w8, #0x1                // =1
    5600:      	ldr	x9, [x9]
    5604:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    5608:      	ldr	x0, [x0]
    560c:      	blr	x8
    5610:      	ldr	w12, [sp, #0x30]
    5614:      	mov	w8, wzr
    5618:      	mov	w9, wzr
    561c:      	mov	x11, x20
    5620:      	cmp	w12, #0x5
    5624:      	b.ne	0x523c <generic_rawtp_process_filter+0x17bc>
    5628:      	b	0x5248 <generic_rawtp_process_filter+0x17c8>
    562c:      	ldp	w8, w9, [sp, #0x58]
    5630:      	ldp	w10, w11, [sp, #0x60]
    5634:      	cmp	w12, #0x6
    5638:      	b.ne	0x564c <generic_rawtp_process_filter+0x1bcc>
    563c:      	and	w8, w9, w8
    5640:      	and	w9, w10, w11
    5644:      	and	w9, w8, w9
    5648:      	b	0x5658 <generic_rawtp_process_filter+0x1bd8>
    564c:      	orr	w8, w9, w8
    5650:      	orr	w9, w10, w11
    5654:      	orr	w9, w8, w9
    5658:      	ldr	x8, [sp, #0x10]
    565c:      	cbz	w9, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    5660:      	ldr	x10, [sp, #0x8]
    5664:      	add	w8, w8, #0x14
    5668:      	ldr	w10, [x10, #0x8]
    566c:      	ubfiz	w10, w10, #2, #3
    5670:      	add	w8, w10, w8
    5674:      	and	x10, x8, #0x3ff
    5678:      	add	w8, w8, #0x4
    567c:      	mov	w19, #0xa               // =10
    5680:      	ldr	w10, [x10, x23]
    5684:      	mov	w20, #0x4               // =4
    5688:      	mov	x25, #0x100000001       // =4294967297
    568c:      	sub	w22, w10, #0x4
    5690:      	ldr	x10, [sp, #0xe8]
    5694:      	add	x10, x10, #0x20
    5698:      	str	x10, [sp, #0x30]
    569c:      	b	0x56a8 <generic_rawtp_process_filter+0x1c28>
    56a0:      	subs	x19, x19, #0x1
    56a4:      	b.eq	0x5874 <generic_rawtp_process_filter+0x1df4>
    56a8:      	cbz	w22, 0x56a0 <generic_rawtp_process_filter+0x1c20>
    56ac:      	and	x9, x8, #0x3ff
    56b0:      	add	x10, x9, x23
    56b4:      	ldr	w29, [x10, #0x8]
    56b8:      	ldp	w9, w24, [x10]
    56bc:      	stp	xzr, xzr, [sp, #0x58]
    56c0:      	cmp	w29, #0x4
    56c4:      	csel	w10, w29, w20, lo
    56c8:      	cmp	w24, #0x6
    56cc:      	b.ne	0x56d4 <generic_rawtp_process_filter+0x1c54>
    56d0:      	stp	x25, x25, [sp, #0x58]
    56d4:      	add	w21, w8, #0xc
    56d8:      	cbz	w29, 0x582c <generic_rawtp_process_filter+0x1dac>
    56dc:      	and	x9, x9, #0xf
    56e0:      	cmp	w9, #0xa
    56e4:      	b.lo	0x5710 <generic_rawtp_process_filter+0x1c90>
    56e8:      	sub	x8, x10, #0x1
    56ec:      	mov	w9, #0x3                // =3
    56f0:      	add	x0, sp, #0x58
    56f4:      	mov	w1, wzr
    56f8:      	cmp	x8, #0x3
    56fc:      	csel	x8, x8, x9, lo
    5700:      	lsl	x8, x8, #2
    5704:      	add	x2, x8, #0x4
    5708:      	bl	0x5708 <generic_rawtp_process_filter+0x1c88>
    570c:      	b	0x582c <generic_rawtp_process_filter+0x1dac>
    5710:      	cmp	w21, #0x3e8
    5714:      	b.ls	0x5720 <generic_rawtp_process_filter+0x1ca0>
    5718:      	mov	w11, wzr
    571c:      	b	0x5728 <generic_rawtp_process_filter+0x1ca8>
    5720:      	and	w11, w21, #0xfffffffc
    5724:      	ldr	w11, [x23, w11, uxtw]
    5728:      	ldr	x12, [sp, #0x30]
    572c:      	cmp	w24, #0x5
    5730:      	sub	x10, x10, #0x1
    5734:      	ldr	w9, [x12, x9, lsl #2]
    5738:      	cset	w12, ne
    573c:      	cmp	w24, #0x6
    5740:      	cset	w13, ne
    5744:      	cmp	w11, w9
    5748:      	csinc	w11, w12, wzr, ne
    574c:      	csinc	w12, w13, wzr, eq
    5750:      	and	w11, w11, w12
    5754:      	str	w11, [sp, #0x58]
    5758:      	cbz	x10, 0x582c <generic_rawtp_process_filter+0x1dac>
    575c:      	add	w11, w8, #0x10
    5760:      	cmp	w11, #0x3e8
    5764:      	b.ls	0x5770 <generic_rawtp_process_filter+0x1cf0>
    5768:      	mov	w11, wzr
    576c:      	b	0x5778 <generic_rawtp_process_filter+0x1cf8>
    5770:      	and	w11, w11, #0xfffffffc
    5774:      	ldr	w11, [x23, w11, uxtw]
    5778:      	cmp	w24, #0x5
    577c:      	cset	w12, ne
    5780:      	cmp	w24, #0x6
    5784:      	cset	w13, ne
    5788:      	cmp	w11, w9
    578c:      	csinc	w11, w12, wzr, ne
    5790:      	csinc	w12, w13, wzr, eq
    5794:      	cmp	x10, #0x1
    5798:      	and	w11, w11, w12
    579c:      	str	w11, [sp, #0x5c]
    57a0:      	b.eq	0x582c <generic_rawtp_process_filter+0x1dac>
    57a4:      	add	w11, w8, #0x14
    57a8:      	cmp	w11, #0x3e8
    57ac:      	b.ls	0x57b8 <generic_rawtp_process_filter+0x1d38>
    57b0:      	mov	w11, wzr
    57b4:      	b	0x57c0 <generic_rawtp_process_filter+0x1d40>
    57b8:      	and	w11, w11, #0xfffffffc
    57bc:      	ldr	w11, [x23, w11, uxtw]
    57c0:      	cmp	w24, #0x5
    57c4:      	cset	w12, ne
    57c8:      	cmp	w24, #0x6
    57cc:      	cset	w13, ne
    57d0:      	cmp	w11, w9
    57d4:      	csinc	w11, w12, wzr, ne
    57d8:      	csinc	w12, w13, wzr, eq
    57dc:      	cmp	x10, #0x2
    57e0:      	and	w11, w11, w12
    57e4:      	str	w11, [sp, #0x60]
    57e8:      	b.eq	0x582c <generic_rawtp_process_filter+0x1dac>
    57ec:      	add	w8, w8, #0x18
    57f0:      	cmp	w8, #0x3e8
    57f4:      	b.ls	0x5800 <generic_rawtp_process_filter+0x1d80>
    57f8:      	mov	w8, wzr
    57fc:      	b	0x5808 <generic_rawtp_process_filter+0x1d88>
    5800:      	and	w8, w8, #0xfffffffc
    5804:      	ldr	w8, [x23, w8, uxtw]
    5808:      	cmp	w24, #0x5
    580c:      	cset	w10, ne
    5810:      	cmp	w24, #0x6
    5814:      	cset	w11, ne
    5818:      	cmp	w8, w9
    581c:      	csinc	w8, w10, wzr, ne
    5820:      	csinc	w9, w11, wzr, eq
    5824:      	and	w8, w8, w9
    5828:      	str	w8, [sp, #0x64]
    582c:      	ldp	w8, w9, [sp, #0x58]
    5830:      	ldp	w10, w11, [sp, #0x60]
    5834:      	cmp	w24, #0x6
    5838:      	b.ne	0x584c <generic_rawtp_process_filter+0x1dcc>
    583c:      	and	w8, w9, w8
    5840:      	and	w9, w10, w11
    5844:      	and	w9, w8, w9
    5848:      	b	0x5858 <generic_rawtp_process_filter+0x1dd8>
    584c:      	orr	w8, w9, w8
    5850:      	orr	w9, w10, w11
    5854:      	orr	w9, w8, w9
    5858:      	cbz	w9, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    585c:      	lsl	w8, w29, #2
    5860:      	sub	w10, w22, w29, lsl #2
    5864:      	and	w8, w8, #0x1c
    5868:      	sub	w22, w10, #0xc
    586c:      	add	w8, w8, w21
    5870:      	b	0x56a0 <generic_rawtp_process_filter+0x1c20>
    5874:      	mov	w10, w8
    5878:      	add	w19, w8, #0x4
    587c:      	and	x10, x10, #0x3ff
    5880:      	ldr	w10, [x10, x23]
    5884:      	cmp	w10, #0x4
    5888:      	b.ne	0x5920 <generic_rawtp_process_filter+0x1ea0>
    588c:      	cbz	w9, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    5890:      	mov	w8, w19
    5894:      	and	x8, x8, #0x3ff
    5898:      	ldr	w9, [x8, x23]
    589c:      	add	w8, w19, #0x4
    58a0:      	cmp	w9, #0x4
    58a4:      	mov	w9, w8
    58a8:      	b.eq	0x5c50 <generic_rawtp_process_filter+0x21d0>
    58ac:      	and	x8, x8, #0x3ff
    58b0:      	add	x8, x8, x23
    58b4:      	ldp	w20, w22, [x8]
    58b8:      	mov	w8, #0xe                // =14
    58bc:      	blr	x8
    58c0:      	lsr	x8, x0, #32
    58c4:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    58c8:      	add	x9, sp, #0x58
    58cc:      	str	w8, [sp, #0x58]
    58d0:      	mov	w8, #0x1                // =1
    58d4:      	add	x1, sp, #0x58
    58d8:      	ldr	x0, [x0]
    58dc:      	blr	x8
    58e0:      	cbz	x0, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    58e4:      	cmp	w20, #0x5
    58e8:      	b.eq	0x599c <generic_rawtp_process_filter+0x1f1c>
    58ec:      	cmp	w20, #0x6
    58f0:      	b.ne	0x5d54 <generic_rawtp_process_filter+0x22d4>
    58f4:      	ldr	x11, [sp, #0xe8]
    58f8:      	mov	w8, #0x5ee8             // =24296
    58fc:      	add	x8, x11, x8
    5900:      	tbnz	w22, #0x0, 0x59d0 <generic_rawtp_process_filter+0x1f50>
    5904:      	ldr	w9, [x0, #0x28]
    5908:      	cbz	w9, 0x59c8 <generic_rawtp_process_filter+0x1f48>
    590c:      	ldr	x10, [sp, #0x30]
    5910:      	ldr	w10, [x10]
    5914:      	cmp	w9, w10
    5918:      	b.eq	0x59d0 <generic_rawtp_process_filter+0x1f50>
    591c:      	b	0x5c44 <generic_rawtp_process_filter+0x21c4>
    5920:      	and	x9, x19, #0x3ff
    5924:      	add	w19, w8, #0x18
    5928:      	add	x9, x9, x23
    592c:      	ldp	w8, w10, [x9]
    5930:      	ldr	w12, [x9, #0x8]
    5934:      	ldur	x11, [x9, #0xc]
    5938:      	cbz	w12, 0x595c <generic_rawtp_process_filter+0x1edc>
    593c:      	ldr	x14, [sp, #0xe8]
    5940:      	mov	w9, wzr
    5944:      	cmp	w8, #0x2
    5948:      	b.hi	0x588c <generic_rawtp_process_filter+0x1e0c>
    594c:      	ldr	w13, [x14, #0x44]
    5950:      	cmp	w13, w12
    5954:      	b.ne	0x5970 <generic_rawtp_process_filter+0x1ef0>
    5958:      	b	0x588c <generic_rawtp_process_filter+0x1e0c>
    595c:      	ldr	x14, [sp, #0xe8]
    5960:      	cmp	w8, #0x2
    5964:      	b.ls	0x5970 <generic_rawtp_process_filter+0x1ef0>
    5968:      	mov	w9, wzr
    596c:      	b	0x588c <generic_rawtp_process_filter+0x1e0c>
    5970:      	add	x9, x14, #0x48
    5974:      	cmp	w10, #0x5
    5978:      	ldr	x8, [x9, x8, lsl #3]
    597c:      	and	x8, x8, x11
    5980:      	b.ne	0x5990 <generic_rawtp_process_filter+0x1f10>
    5984:      	cmp	x8, #0x0
    5988:      	cset	w9, ne
    598c:      	b	0x588c <generic_rawtp_process_filter+0x1e0c>
    5990:      	cmp	x8, #0x0
    5994:      	cset	w9, eq
    5998:      	b	0x588c <generic_rawtp_process_filter+0x1e0c>
    599c:      	ldr	x11, [sp, #0xe8]
    59a0:      	mov	w8, #0x5ee8             // =24296
    59a4:      	add	x8, x11, x8
    59a8:      	tbz	w22, #0x0, 0x59f4 <generic_rawtp_process_filter+0x1f74>
    59ac:      	ldr	w9, [x0, #0x28]
    59b0:      	cbz	w9, 0x59ec <generic_rawtp_process_filter+0x1f6c>
    59b4:      	ldr	x10, [sp, #0x30]
    59b8:      	ldr	w10, [x10]
    59bc:      	cmp	w9, w10
    59c0:      	b.eq	0x59f4 <generic_rawtp_process_filter+0x1f74>
    59c4:      	b	0x5c44 <generic_rawtp_process_filter+0x21c4>
    59c8:      	mov	w9, #0x1                // =1
    59cc:      	str	x9, [x8]
    59d0:      	tbnz	w22, #0x1, 0x5a18 <generic_rawtp_process_filter+0x1f98>
    59d4:      	ldr	w9, [x0, #0x2c]
    59d8:      	cbz	w9, 0x5a10 <generic_rawtp_process_filter+0x1f90>
    59dc:      	ldr	w10, [x11, #0x24]
    59e0:      	cmp	w9, w10
    59e4:      	b.eq	0x5a18 <generic_rawtp_process_filter+0x1f98>
    59e8:      	b	0x5c44 <generic_rawtp_process_filter+0x21c4>
    59ec:      	mov	w9, #0x1                // =1
    59f0:      	str	x9, [x8]
    59f4:      	tbz	w22, #0x1, 0x5a3c <generic_rawtp_process_filter+0x1fbc>
    59f8:      	ldr	w9, [x0, #0x2c]
    59fc:      	cbz	w9, 0x5a34 <generic_rawtp_process_filter+0x1fb4>
    5a00:      	ldr	w10, [x11, #0x24]
    5a04:      	cmp	w9, w10
    5a08:      	b.eq	0x5a3c <generic_rawtp_process_filter+0x1fbc>
    5a0c:      	b	0x5c44 <generic_rawtp_process_filter+0x21c4>
    5a10:      	mov	w9, #0x1                // =1
    5a14:      	str	x9, [x8]
    5a18:      	tbnz	w22, #0x2, 0x5a60 <generic_rawtp_process_filter+0x1fe0>
    5a1c:      	ldr	w9, [x0, #0x30]
    5a20:      	cbz	w9, 0x5a58 <generic_rawtp_process_filter+0x1fd8>
    5a24:      	ldr	w10, [x11, #0x28]
    5a28:      	cmp	w9, w10
    5a2c:      	b.eq	0x5a60 <generic_rawtp_process_filter+0x1fe0>
    5a30:      	b	0x5c44 <generic_rawtp_process_filter+0x21c4>
    5a34:      	mov	w9, #0x1                // =1
    5a38:      	str	x9, [x8]
    5a3c:      	tbz	w22, #0x2, 0x5a84 <generic_rawtp_process_filter+0x2004>
    5a40:      	ldr	w9, [x0, #0x30]
    5a44:      	cbz	w9, 0x5a7c <generic_rawtp_process_filter+0x1ffc>
    5a48:      	ldr	w10, [x11, #0x28]
    5a4c:      	cmp	w9, w10
    5a50:      	b.eq	0x5a84 <generic_rawtp_process_filter+0x2004>
    5a54:      	b	0x5c44 <generic_rawtp_process_filter+0x21c4>
    5a58:      	mov	w9, #0x1                // =1
    5a5c:      	str	x9, [x8]
    5a60:      	tbnz	w22, #0x3, 0x5aa8 <generic_rawtp_process_filter+0x2028>
    5a64:      	ldr	w9, [x0, #0x34]
    5a68:      	cbz	w9, 0x5aa0 <generic_rawtp_process_filter+0x2020>
    5a6c:      	ldr	w10, [x11, #0x2c]
    5a70:      	cmp	w9, w10
    5a74:      	b.eq	0x5aa8 <generic_rawtp_process_filter+0x2028>
    5a78:      	b	0x5c44 <generic_rawtp_process_filter+0x21c4>
    5a7c:      	mov	w9, #0x1                // =1
    5a80:      	str	x9, [x8]
    5a84:      	tbz	w22, #0x3, 0x5acc <generic_rawtp_process_filter+0x204c>
    5a88:      	ldr	w9, [x0, #0x34]
    5a8c:      	cbz	w9, 0x5ac4 <generic_rawtp_process_filter+0x2044>
    5a90:      	ldr	w10, [x11, #0x2c]
    5a94:      	cmp	w9, w10
    5a98:      	b.eq	0x5acc <generic_rawtp_process_filter+0x204c>
    5a9c:      	b	0x5c44 <generic_rawtp_process_filter+0x21c4>
    5aa0:      	mov	w9, #0x1                // =1
    5aa4:      	str	x9, [x8]
    5aa8:      	tbnz	w22, #0x4, 0x5af0 <generic_rawtp_process_filter+0x2070>
    5aac:      	ldr	w9, [x0, #0x38]
    5ab0:      	cbz	w9, 0x5ae8 <generic_rawtp_process_filter+0x2068>
    5ab4:      	ldr	w10, [x11, #0x30]
    5ab8:      	cmp	w9, w10
    5abc:      	b.eq	0x5af0 <generic_rawtp_process_filter+0x2070>
    5ac0:      	b	0x5c44 <generic_rawtp_process_filter+0x21c4>
    5ac4:      	mov	w9, #0x1                // =1
    5ac8:      	str	x9, [x8]
    5acc:      	tbz	w22, #0x4, 0x5b14 <generic_rawtp_process_filter+0x2094>
    5ad0:      	ldr	w9, [x0, #0x38]
    5ad4:      	cbz	w9, 0x5b0c <generic_rawtp_process_filter+0x208c>
    5ad8:      	ldr	w10, [x11, #0x30]
    5adc:      	cmp	w9, w10
    5ae0:      	b.eq	0x5b14 <generic_rawtp_process_filter+0x2094>
    5ae4:      	b	0x5c44 <generic_rawtp_process_filter+0x21c4>
    5ae8:      	mov	w9, #0x1                // =1
    5aec:      	str	x9, [x8]
    5af0:      	tbnz	w22, #0x5, 0x5b38 <generic_rawtp_process_filter+0x20b8>
    5af4:      	ldr	w9, [x0, #0x3c]
    5af8:      	cbz	w9, 0x5b30 <generic_rawtp_process_filter+0x20b0>
    5afc:      	ldr	w10, [x11, #0x34]
    5b00:      	cmp	w9, w10
    5b04:      	b.eq	0x5b38 <generic_rawtp_process_filter+0x20b8>
    5b08:      	b	0x5c44 <generic_rawtp_process_filter+0x21c4>
    5b0c:      	mov	w9, #0x1                // =1
    5b10:      	str	x9, [x8]
    5b14:      	tbz	w22, #0x5, 0x5b5c <generic_rawtp_process_filter+0x20dc>
    5b18:      	ldr	w9, [x0, #0x3c]
    5b1c:      	cbz	w9, 0x5b54 <generic_rawtp_process_filter+0x20d4>
    5b20:      	ldr	w10, [x11, #0x34]
    5b24:      	cmp	w9, w10
    5b28:      	b.eq	0x5b5c <generic_rawtp_process_filter+0x20dc>
    5b2c:      	b	0x5c44 <generic_rawtp_process_filter+0x21c4>
    5b30:      	mov	w9, #0x1                // =1
    5b34:      	str	x9, [x8]
    5b38:      	tbnz	w22, #0x6, 0x5b80 <generic_rawtp_process_filter+0x2100>
    5b3c:      	ldr	w9, [x0, #0x40]
    5b40:      	cbz	w9, 0x5b78 <generic_rawtp_process_filter+0x20f8>
    5b44:      	ldr	w10, [x11, #0x38]
    5b48:      	cmp	w9, w10
    5b4c:      	b.eq	0x5b80 <generic_rawtp_process_filter+0x2100>
    5b50:      	b	0x5c44 <generic_rawtp_process_filter+0x21c4>
    5b54:      	mov	w9, #0x1                // =1
    5b58:      	str	x9, [x8]
    5b5c:      	tbz	w22, #0x6, 0x5ba4 <generic_rawtp_process_filter+0x2124>
    5b60:      	ldr	w9, [x0, #0x40]
    5b64:      	cbz	w9, 0x5b9c <generic_rawtp_process_filter+0x211c>
    5b68:      	ldr	w10, [x11, #0x38]
    5b6c:      	cmp	w9, w10
    5b70:      	b.eq	0x5ba4 <generic_rawtp_process_filter+0x2124>
    5b74:      	b	0x5c44 <generic_rawtp_process_filter+0x21c4>
    5b78:      	mov	w9, #0x1                // =1
    5b7c:      	str	x9, [x8]
    5b80:      	tbnz	w22, #0x7, 0x5bc8 <generic_rawtp_process_filter+0x2148>
    5b84:      	ldr	w9, [x0, #0x44]
    5b88:      	cbz	w9, 0x5bc0 <generic_rawtp_process_filter+0x2140>
    5b8c:      	ldr	w10, [x11, #0x3c]
    5b90:      	cmp	w9, w10
    5b94:      	b.eq	0x5bc8 <generic_rawtp_process_filter+0x2148>
    5b98:      	b	0x5c44 <generic_rawtp_process_filter+0x21c4>
    5b9c:      	mov	w9, #0x1                // =1
    5ba0:      	str	x9, [x8]
    5ba4:      	tbz	w22, #0x7, 0x5bf0 <generic_rawtp_process_filter+0x2170>
    5ba8:      	ldr	w9, [x0, #0x44]
    5bac:      	cbz	w9, 0x5be8 <generic_rawtp_process_filter+0x2168>
    5bb0:      	ldr	w10, [x11, #0x3c]
    5bb4:      	cmp	w9, w10
    5bb8:      	b.eq	0x5bf0 <generic_rawtp_process_filter+0x2170>
    5bbc:      	b	0x5c44 <generic_rawtp_process_filter+0x21c4>
    5bc0:      	mov	w9, #0x1                // =1
    5bc4:      	str	x9, [x8]
    5bc8:      	tbnz	w22, #0x8, 0x5c18 <generic_rawtp_process_filter+0x2198>
    5bcc:      	ldr	w9, [x0, #0x48]
    5bd0:      	cbz	w9, 0x5c10 <generic_rawtp_process_filter+0x2190>
    5bd4:      	ldr	x10, [sp, #0xe8]
    5bd8:      	ldr	w10, [x10, #0x40]
    5bdc:      	cmp	w9, w10
    5be0:      	b.eq	0x5c18 <generic_rawtp_process_filter+0x2198>
    5be4:      	b	0x5c44 <generic_rawtp_process_filter+0x21c4>
    5be8:      	mov	w9, #0x1                // =1
    5bec:      	str	x9, [x8]
    5bf0:      	tbz	w22, #0x8, 0x5c28 <generic_rawtp_process_filter+0x21a8>
    5bf4:      	ldr	w9, [x0, #0x48]
    5bf8:      	cbz	w9, 0x5c20 <generic_rawtp_process_filter+0x21a0>
    5bfc:      	ldr	x10, [sp, #0xe8]
    5c00:      	ldr	w10, [x10, #0x40]
    5c04:      	cmp	w9, w10
    5c08:      	b.eq	0x5c28 <generic_rawtp_process_filter+0x21a8>
    5c0c:      	b	0x5c44 <generic_rawtp_process_filter+0x21c4>
    5c10:      	mov	w9, #0x1                // =1
    5c14:      	str	x9, [x8]
    5c18:      	tbz	w22, #0x9, 0x5c2c <generic_rawtp_process_filter+0x21ac>
    5c1c:      	b	0x5d54 <generic_rawtp_process_filter+0x22d4>
    5c20:      	mov	w9, #0x1                // =1
    5c24:      	str	x9, [x8]
    5c28:      	tbz	w22, #0x9, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    5c2c:      	ldr	w9, [x0, #0x4c]
    5c30:      	cbz	w9, 0x5d4c <generic_rawtp_process_filter+0x22cc>
    5c34:      	ldr	x10, [sp, #0xe8]
    5c38:      	ldr	w10, [x10, #0x44]
    5c3c:      	cmp	w9, w10
    5c40:      	b.eq	0x5d54 <generic_rawtp_process_filter+0x22d4>
    5c44:      	add	w9, w19, #0xc
    5c48:      	mov	w10, #0x1               // =1
    5c4c:      	str	x10, [x8]
    5c50:      	and	x8, x9, #0x3ff
    5c54:      	adrp	x24, 0x5000 <generic_rawtp_process_filter+0x1580>
    5c58:      	ldr	w8, [x8, x23]
    5c5c:      	ldr	x24, [x24]
    5c60:      	cmp	w8, #0x4
    5c64:      	b.ne	0x5c98 <generic_rawtp_process_filter+0x2218>
    5c68:      	ldr	x9, [sp, #0xe8]
    5c6c:      	mov	w8, #0x5eb8             // =24248
    5c70:      	add	x8, x9, x8
    5c74:      	ldr	x9, [x9, #0x5eb8]
    5c78:      	and	x9, x9, #0x1f
    5c7c:      	add	x8, x8, x9
    5c80:      	mov	w9, #0x1                // =1
    5c84:      	strb	w9, [x8, #0x9]
    5c88:      	ldr	x8, [sp, #0x40]
    5c8c:      	strb	w9, [x8, #0x20]
    5c90:      	strb	w9, [x8]
    5c94:      	b	0x5d54 <generic_rawtp_process_filter+0x22d4>
    5c98:      	add	w8, w9, #0x4
    5c9c:      	and	x8, x8, #0x3ff
    5ca0:      	add	x8, x8, x23
    5ca4:      	ldp	w21, w19, [x8]
    5ca8:      	ldr	w22, [x8, #0x8]
    5cac:      	ldur	x20, [x8, #0xc]
    5cb0:      	mov	w8, #0xe                // =14
    5cb4:      	blr	x8
    5cb8:      	lsr	x8, x0, #32
    5cbc:      	add	x9, sp, #0x58
    5cc0:      	add	x1, sp, #0x58
    5cc4:      	str	w8, [sp, #0x58]
    5cc8:      	mov	w8, #0x1                // =1
    5ccc:      	mov	x0, x24
    5cd0:      	blr	x8
    5cd4:      	cbz	x0, 0x5d54 <generic_rawtp_process_filter+0x22d4>
    5cd8:      	cmp	w21, #0x2
    5cdc:      	cbz	w22, 0x5cf8 <generic_rawtp_process_filter+0x2278>
    5ce0:      	b.hi	0x5d54 <generic_rawtp_process_filter+0x22d4>
    5ce4:      	ldr	x8, [sp, #0xe8]
    5ce8:      	ldr	w8, [x8, #0x44]
    5cec:      	cmp	w8, w22
    5cf0:      	b.ne	0x5cfc <generic_rawtp_process_filter+0x227c>
    5cf4:      	b	0x5d54 <generic_rawtp_process_filter+0x22d4>
    5cf8:      	b.hi	0x5d54 <generic_rawtp_process_filter+0x22d4>
    5cfc:      	ldr	x8, [sp, #0xe8]
    5d00:      	lsl	x10, x21, #3
    5d04:      	add	x9, x8, #0x48
    5d08:      	add	x8, x0, x21, lsl #3
    5d0c:      	ldr	x8, [x8, #0x50]
    5d10:      	ldr	x9, [x9, x10]
    5d14:      	eor	x10, x9, x8
    5d18:      	tst	x10, x20
    5d1c:      	b.eq	0x5d2c <generic_rawtp_process_filter+0x22ac>
    5d20:      	cmp	w19, #0x5
    5d24:      	b.eq	0x5d3c <generic_rawtp_process_filter+0x22bc>
    5d28:      	b	0x5d54 <generic_rawtp_process_filter+0x22d4>
    5d2c:      	cmp	x8, x9
    5d30:      	b.eq	0x5d54 <generic_rawtp_process_filter+0x22d4>
    5d34:      	cmp	w19, #0x6
    5d38:      	b.ne	0x5d54 <generic_rawtp_process_filter+0x22d4>
    5d3c:      	ldr	x9, [sp, #0xe8]
    5d40:      	mov	w8, #0x1                // =1
    5d44:      	str	x8, [x9, #0x5ef0]
    5d48:      	b	0x5c68 <generic_rawtp_process_filter+0x21e8>
    5d4c:      	mov	w9, #0x1                // =1
    5d50:      	str	x9, [x8]
    5d54:      	ldr	x9, [sp, #0xe8]
    5d58:      	ldr	x10, [sp, #0x28]
    5d5c:      	ldr	x8, [x9, #0x5eb8]
    5d60:      	add	x8, x8, #0x1
    5d64:      	cmp	x8, x10
    5d68:      	str	x8, [x9, #0x5eb8]
    5d6c:      	b.ls	0x5dcc <generic_rawtp_process_filter+0x234c>
    5d70:      	ldr	x10, [sp, #0x48]
    5d74:      	ldr	w8, [x10]
    5d78:      	str	w8, [x9, #0x10]
    5d7c:      	ldr	x8, [x10, #0x8]
    5d80:      	str	x8, [x9, #0x18]
    5d84:      	ldp	x20, x8, [sp, #0x38]
    5d88:      	ldrb	w8, [x8]
    5d8c:      	cbz	w8, 0x5dac <generic_rawtp_process_filter+0x232c>
    5d90:      	adrp	x1, 0x5000 <generic_rawtp_process_filter+0x1580>
    5d94:      	mov	x8, xzr
    5d98:      	mov	w9, #0xc                // =12
    5d9c:      	ldr	x1, [x1]
    5da0:      	mov	x0, x20
    5da4:      	mov	w2, wzr
    5da8:      	blr	x9
    5dac:      	ldp	x20, x19, [sp, #0x120]
    5db0:      	mov	w0, wzr
    5db4:      	ldr	x29, [sp, #0xe0]
    5db8:      	ldp	x22, x21, [sp, #0x110]
    5dbc:      	ldp	x24, x23, [sp, #0x100]
    5dc0:      	ldp	x30, x25, [sp, #0xf0]
    5dc4:      	add	sp, sp, #0x130
    5dc8:      	ret
    5dcc:      	adrp	x1, 0x5000 <generic_rawtp_process_filter+0x1580>
    5dd0:      	mov	w8, #0x2                // =2
    5dd4:      	mov	w9, #0xc                // =12
    5dd8:      	ldr	x1, [x1]
    5ddc:      	ldr	x0, [sp, #0x38]
    5de0:      	mov	w2, #0x2                // =2
    5de4:      	b	0x5da8 <generic_rawtp_process_filter+0x2328>
    5de8:      	nop
    5dec:      	nop

0000000000005df0 <generic_rawtp_filter_arg>:
    5df0:      	sub	sp, sp, #0xf0
    5df4:      	str	x29, [sp, #0xa0]
    5df8:      	stp	x30, x25, [sp, #0xb0]
    5dfc:      	stp	x24, x23, [sp, #0xc0]
    5e00:      	stp	x22, x21, [sp, #0xd0]
    5e04:      	stp	x20, x19, [sp, #0xe0]
    5e08:      	mov	x19, x0
    5e0c:      	str	wzr, [sp, #0xa8]
    5e10:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    5e14:      	mov	w8, #0x1                // =1
    5e18:      	ldr	x0, [x0]
    5e1c:      	add	x9, sp, #0xa8
    5e20:      	add	x1, sp, #0xa8
    5e24:      	blr	x8
    5e28:      	cbz	x0, 0x5f98 <generic_rawtp_filter_arg+0x1a8>
    5e2c:      	mov	w8, #0x5ec1             // =24257
    5e30:      	mov	x20, x0
    5e34:      	add	x22, x0, x8
    5e38:      	mov	w8, #0x5ef8             // =24312
    5e3c:      	add	x1, x0, x8
    5e40:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x1580>
    5e44:      	ldur	w23, [x22, #0x3f]
    5e48:      	mov	w8, #0x1                // =1
    5e4c:      	ldr	x0, [x0]
    5e50:      	blr	x8
    5e54:      	cbz	x0, 0x5f7c <generic_rawtp_filter_arg+0x18c>
    5e58:      	ldrb	w8, [x22, #0x1f]
    5e5c:      	cbz	w8, 0x5f7c <generic_rawtp_filter_arg+0x18c>
    5e60:      	and	x8, x23, #0x7
    5e64:      	mov	w10, #0x5ec1            // =24257
    5e68:      	stp	x23, x22, [sp, #0x50]
    5e6c:      	add	x9, x20, x8
    5e70:      	ldrb	w9, [x9, x10]
    5e74:      	cbz	w9, 0x5eec <generic_rawtp_filter_arg+0xfc>
    5e78:      	lsl	w8, w8, #2
    5e7c:      	mov	x21, x0
    5e80:      	add	x8, x8, #0x4
    5e84:      	ldr	w9, [x8, x0]
    5e88:      	add	x8, x8, x9
    5e8c:      	add	x8, x8, #0x4
    5e90:      	and	x9, x8, #0x3ff
    5e94:      	ldr	w9, [x9, x0]
    5e98:      	add	x8, x8, x9
    5e9c:      	and	x9, x8, #0x3ff
    5ea0:      	ldr	w9, [x9, x0]
    5ea4:      	add	x8, x8, x9
    5ea8:      	and	x9, x8, #0x3ff
    5eac:      	ldr	w9, [x9, x0]
    5eb0:      	add	x8, x8, x9
    5eb4:      	and	x9, x8, #0x3ff
    5eb8:      	ldr	w9, [x9, x0]
    5ebc:      	add	x8, x8, x9
    5ec0:      	and	x9, x8, #0x3ff
    5ec4:      	ldr	w9, [x9, x0]
    5ec8:      	add	x16, x8, x9
    5ecc:      	and	x15, x16, #0x3ff
    5ed0:      	add	x17, x0, x15
    5ed4:      	ldr	w8, [x17]
    5ed8:      	cmp	w8, #0x19
    5edc:      	b.hs	0x5f40 <generic_rawtp_filter_arg+0x150>
    5ee0:      	cmp	w15, #0x1
    5ee4:      	b.eq	0x5f7c <generic_rawtp_filter_arg+0x18c>
    5ee8:      	cbnz	w15, 0x5f58 <generic_rawtp_filter_arg+0x168>
    5eec:      	ldr	x8, [sp, #0x50]
    5ef0:      	cmp	w8, #0x1
    5ef4:      	b.gt	0x5f14 <generic_rawtp_filter_arg+0x124>
    5ef8:      	ldr	x9, [sp, #0x58]
    5efc:      	cmn	w8, #0x1
    5f00:      	b.eq	0x5fb8 <generic_rawtp_filter_arg+0x1c8>
    5f04:      	cbz	w8, 0x5fc8 <generic_rawtp_filter_arg+0x1d8>
    5f08:      	cmp	w8, #0x1
    5f0c:      	b.eq	0x5fd8 <generic_rawtp_filter_arg+0x1e8>
    5f10:      	b	0x5f30 <generic_rawtp_filter_arg+0x140>
    5f14:      	ldr	x9, [sp, #0x58]
    5f18:      	cmp	w8, #0x2
    5f1c:      	b.eq	0x5fe8 <generic_rawtp_filter_arg+0x1f8>
    5f20:      	cmp	w8, #0x3
    5f24:      	b.eq	0x5ff8 <generic_rawtp_filter_arg+0x208>
    5f28:      	cmp	w8, #0x4
    5f2c:      	b.eq	0x6008 <generic_rawtp_filter_arg+0x218>
    5f30:      	cmp	w8, #0x4
    5f34:      	b.gt	0x6034 <generic_rawtp_filter_arg+0x244>
    5f38:      	add	w8, w8, #0x1
    5f3c:      	b	0x6014 <generic_rawtp_filter_arg+0x224>
    5f40:      	mov	x24, xzr
    5f44:      	mov	w2, #0x5ea0             // =24224
    5f48:      	mov	w12, #0x1               // =1
    5f4c:      	stp	x19, x17, [sp, #0x30]
    5f50:      	stp	x16, x15, [sp, #0x40]
    5f54:      	b	0x6094 <generic_rawtp_filter_arg+0x2a4>
    5f58:      	ldr	x8, [sp, #0x58]
    5f5c:      	adrp	x1, 0x5000 <generic_rawtp_process_filter+0x1580>
    5f60:      	mov	w9, #0xc                // =12
    5f64:      	mov	x0, x19
    5f68:      	stur	w15, [x8, #0x43]
    5f6c:      	mov	w8, #0x4                // =4
    5f70:      	mov	w2, #0x4                // =4
    5f74:      	ldr	x1, [x1]
    5f78:      	blr	x9
    5f7c:      	adrp	x1, 0x5000 <generic_rawtp_process_filter+0x1580>
    5f80:      	mov	w8, #0x5                // =5
    5f84:      	mov	w9, #0xc                // =12
    5f88:      	ldr	x1, [x1]
    5f8c:      	mov	x0, x19
    5f90:      	mov	w2, #0x5                // =5
    5f94:      	blr	x9
    5f98:      	ldp	x20, x19, [sp, #0xe0]
    5f9c:      	mov	w0, wzr
    5fa0:      	ldr	x29, [sp, #0xa0]
    5fa4:      	ldp	x22, x21, [sp, #0xd0]
    5fa8:      	ldp	x24, x23, [sp, #0xc0]
    5fac:      	ldp	x30, x25, [sp, #0xb0]
    5fb0:      	add	sp, sp, #0xf0
    5fb4:      	ret
    5fb8:      	ldrb	w8, [x9]
    5fbc:      	cbz	w8, 0x5fc8 <generic_rawtp_filter_arg+0x1d8>
    5fc0:      	mov	w8, wzr
    5fc4:      	b	0x6014 <generic_rawtp_filter_arg+0x224>
    5fc8:      	ldrb	w8, [x9, #0x1]
    5fcc:      	cbz	w8, 0x5fd8 <generic_rawtp_filter_arg+0x1e8>
    5fd0:      	mov	w8, #0x1                // =1
    5fd4:      	b	0x6014 <generic_rawtp_filter_arg+0x224>
    5fd8:      	ldrb	w8, [x9, #0x2]
    5fdc:      	cbz	w8, 0x5fe8 <generic_rawtp_filter_arg+0x1f8>
    5fe0:      	mov	w8, #0x2                // =2
    5fe4:      	b	0x6014 <generic_rawtp_filter_arg+0x224>
    5fe8:      	ldrb	w8, [x9, #0x3]
    5fec:      	cbz	w8, 0x5ff8 <generic_rawtp_filter_arg+0x208>
    5ff0:      	mov	w8, #0x3                // =3
    5ff4:      	b	0x6014 <generic_rawtp_filter_arg+0x224>
    5ff8:      	ldrb	w8, [x9, #0x4]
    5ffc:      	cbz	w8, 0x6008 <generic_rawtp_filter_arg+0x218>
    6000:      	mov	w8, #0x4                // =4
    6004:      	b	0x6014 <generic_rawtp_filter_arg+0x224>
    6008:      	ldrb	w8, [x9, #0x5]
    600c:      	cbz	w8, 0x6034 <generic_rawtp_filter_arg+0x244>
    6010:      	mov	w8, #0x5                // =5
    6014:      	stur	w8, [x9, #0x3f]
    6018:      	adrp	x1, 0x6000 <generic_rawtp_filter_arg+0x210>
    601c:      	mov	w8, #0x3                // =3
    6020:      	mov	w9, #0xc                // =12
    6024:      	ldr	x1, [x1]
    6028:      	mov	x0, x19
    602c:      	mov	w2, #0x3                // =3
    6030:      	blr	x9
    6034:      	ldr	x19, [x20, #0x60]
    6038:      	mov	w8, #0xe                // =14
    603c:      	blr	x8
    6040:      	stp	x19, x0, [sp, #0x60]
    6044:      	adrp	x19, 0x6000 <generic_rawtp_filter_arg+0x210>
    6048:      	mov	w8, #0x1                // =1
    604c:      	add	x9, sp, #0x60
    6050:      	add	x1, sp, #0x60
    6054:      	ldr	x19, [x19]
    6058:      	mov	x0, x19
    605c:      	blr	x8
    6060:      	cbz	x0, 0x5f98 <generic_rawtp_filter_arg+0x1a8>
    6064:      	mov	w8, #0x3                // =3
    6068:      	add	x9, sp, #0x60
    606c:      	add	x1, sp, #0x60
    6070:      	mov	x0, x19
    6074:      	blr	x8
    6078:      	b	0x5f98 <generic_rawtp_filter_arg+0x1a8>
    607c:      	cmp	w8, #0x3
    6080:      	cset	w22, eq
    6084:      	cbz	x22, 0x5eec <generic_rawtp_filter_arg+0xfc>
    6088:      	add	x24, x24, #0x1
    608c:      	cmp	x24, #0x5
    6090:      	b.eq	0x5ee0 <generic_rawtp_filter_arg+0xf0>
    6094:      	add	x8, x17, x24, lsl #2
    6098:      	ldr	w8, [x8, #0x4]
    609c:      	tst	w8, #0x3ff
    60a0:      	b.eq	0x5ee0 <generic_rawtp_filter_arg+0xf0>
    60a4:      	add	w8, w16, w8
    60a8:      	and	x8, x8, #0x3ff
    60ac:      	add	x23, x21, x8
    60b0:      	ldr	w8, [x23, #0x4]
    60b4:      	cmp	w8, #0x23
    60b8:      	b.eq	0x5eec <generic_rawtp_filter_arg+0xfc>
    60bc:      	ldr	w9, [x23]
    60c0:      	cmp	w9, #0x4
    60c4:      	b.hi	0x5eec <generic_rawtp_filter_arg+0xfc>
    60c8:      	add	x10, x20, x9, lsl #2
    60cc:      	ldr	w10, [x10, x2]
    60d0:      	cbnz	w10, 0x5eec <generic_rawtp_filter_arg+0xfc>
    60d4:      	add	x9, x20, x9, lsl #3
    60d8:      	ldr	x9, [x9, #0x5e78]
    60dc:      	and	x9, x9, #0x7ff
    60e0:      	add	x9, x20, x9
    60e4:      	add	x25, x9, #0x90
    60e8:      	ldr	w9, [x23, #0xc]
    60ec:      	cmp	w9, #0x1b
    60f0:      	b.le	0x6114 <generic_rawtp_filter_arg+0x324>
    60f4:      	cmp	w9, #0x25
    60f8:      	b.gt	0x6144 <generic_rawtp_filter_arg+0x354>
    60fc:      	sub	w10, w9, #0x1c
    6100:      	cmp	w10, #0x9
    6104:      	b.lo	0x6188 <generic_rawtp_filter_arg+0x398>
    6108:      	cmp	w9, #0x25
    610c:      	b.eq	0x633c <generic_rawtp_filter_arg+0x54c>
    6110:      	b	0x6088 <generic_rawtp_filter_arg+0x298>
    6114:      	cmp	w9, #0x9
    6118:      	b.le	0x6168 <generic_rawtp_filter_arg+0x378>
    611c:      	sub	w10, w9, #0xa
    6120:      	cmp	w10, #0x4
    6124:      	b.lo	0x6188 <generic_rawtp_filter_arg+0x398>
    6128:      	sub	w10, w9, #0xf
    612c:      	cmp	w10, #0x2
    6130:      	b.lo	0x633c <generic_rawtp_filter_arg+0x54c>
    6134:      	cmp	w9, #0x11
    6138:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    613c:      	add	x25, x25, #0x4
    6140:      	b	0x633c <generic_rawtp_filter_arg+0x54c>
    6144:      	cmp	w9, #0x29
    6148:      	b.gt	0x62b4 <generic_rawtp_filter_arg+0x4c4>
    614c:      	sub	w10, w9, #0x26
    6150:      	cmp	w10, #0x2
    6154:      	b.lo	0x625c <generic_rawtp_filter_arg+0x46c>
    6158:      	sub	w10, w9, #0x28
    615c:      	cmp	w10, #0x2
    6160:      	b.lo	0x6234 <generic_rawtp_filter_arg+0x444>
    6164:      	b	0x6088 <generic_rawtp_filter_arg+0x298>
    6168:      	cmp	w9, #0x4
    616c:      	b.gt	0x621c <generic_rawtp_filter_arg+0x42c>
    6170:      	cmp	w9, #0x1
    6174:      	b.eq	0x6188 <generic_rawtp_filter_arg+0x398>
    6178:      	cmp	w9, #0x2
    617c:      	b.eq	0x676c <generic_rawtp_filter_arg+0x97c>
    6180:      	cmp	w9, #0x4
    6184:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    6188:      	cmp	w9, #0xb
    618c:      	b.le	0x61fc <generic_rawtp_filter_arg+0x40c>
    6190:      	cmp	w9, #0x24
    6194:      	b.hi	0x63f8 <generic_rawtp_filter_arg+0x608>
    6198:      	lsl	x10, x12, x9
    619c:      	tst	x10, #0x1e00000000
    61a0:      	b.ne	0x628c <generic_rawtp_filter_arg+0x49c>
    61a4:      	lsl	x10, x12, x9
    61a8:      	tst	x10, #0x60000000
    61ac:      	b.ne	0x65b4 <generic_rawtp_filter_arg+0x7c4>
    61b0:      	lsl	x10, x12, x9
    61b4:      	tst	x10, #0x180000000
    61b8:      	b.eq	0x63f8 <generic_rawtp_filter_arg+0x608>
    61bc:      	cmp	w8, #0x20
    61c0:      	b.hi	0x5eec <generic_rawtp_filter_arg+0xfc>
    61c4:      	lsl	x9, x12, x8
    61c8:      	mov	w10, #0x101e            // =4126
    61cc:      	tst	x9, x10
    61d0:      	b.eq	0x6bf4 <generic_rawtp_filter_arg+0xe04>
    61d4:      	ldr	w9, [x23, #0x10]
    61d8:      	cmp	w8, #0x2
    61dc:      	b.le	0x7190 <generic_rawtp_filter_arg+0x13a0>
    61e0:      	sub	w10, w8, #0x3
    61e4:      	cmp	w10, #0x2
    61e8:      	b.hs	0x7744 <generic_rawtp_filter_arg+0x1954>
    61ec:      	ldrb	w10, [x25]
    61f0:      	cmp	w9, w10
    61f4:      	b.eq	0x607c <generic_rawtp_filter_arg+0x28c>
    61f8:      	b	0x78cc <generic_rawtp_filter_arg+0x1adc>
    61fc:      	sub	w10, w9, #0xa
    6200:      	cmp	w10, #0x2
    6204:      	b.lo	0x67e0 <generic_rawtp_filter_arg+0x9f0>
    6208:      	cmp	w9, #0x1
    620c:      	b.eq	0x6404 <generic_rawtp_filter_arg+0x614>
    6210:      	cmp	w9, #0x4
    6214:      	b.eq	0x6404 <generic_rawtp_filter_arg+0x614>
    6218:      	b	0x6088 <generic_rawtp_filter_arg+0x298>
    621c:      	cmp	w9, #0x5
    6220:      	b.eq	0x6234 <generic_rawtp_filter_arg+0x444>
    6224:      	cmp	w9, #0x6
    6228:      	b.eq	0x625c <generic_rawtp_filter_arg+0x46c>
    622c:      	cmp	w9, #0x7
    6230:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    6234:      	mov	x22, xzr
    6238:      	cmp	w9, #0x27
    623c:      	stp	xzr, xzr, [sp, #0x78]
    6240:      	str	xzr, [sp, #0x60]
    6244:      	stp	xzr, xzr, [sp, #0x68]
    6248:      	b.gt	0x6444 <generic_rawtp_filter_arg+0x654>
    624c:      	cmp	w9, #0x5
    6250:      	b.eq	0x6900 <generic_rawtp_filter_arg+0xb10>
    6254:      	cmp	w9, #0x7
    6258:      	b	0x6450 <generic_rawtp_filter_arg+0x660>
    625c:      	ldr	w29, [x25], #0x4
    6260:      	mov	x22, xzr
    6264:      	cmp	w8, #0x19
    6268:      	b.gt	0x64b0 <generic_rawtp_filter_arg+0x6c0>
    626c:      	sub	w9, w8, #0x3
    6270:      	cmp	w9, #0x2
    6274:      	b.lo	0x6b84 <generic_rawtp_filter_arg+0xd94>
    6278:      	cmp	w8, #0x8
    627c:      	b.eq	0x6aec <generic_rawtp_filter_arg+0xcfc>
    6280:      	cmp	w8, #0x9
    6284:      	b.eq	0x64c8 <generic_rawtp_filter_arg+0x6d8>
    6288:      	b	0x70b0 <generic_rawtp_filter_arg+0x12c0>
    628c:      	cmp	w8, #0x9
    6290:      	b.le	0x675c <generic_rawtp_filter_arg+0x96c>
    6294:      	cmp	w8, #0x1d
    6298:      	b.gt	0x6aac <generic_rawtp_filter_arg+0xcbc>
    629c:      	sub	w10, w8, #0xa
    62a0:      	cmp	w10, #0x2
    62a4:      	b.lo	0x686c <generic_rawtp_filter_arg+0xa7c>
    62a8:      	cmp	w8, #0xc
    62ac:      	b.eq	0x67f8 <generic_rawtp_filter_arg+0xa08>
    62b0:      	b	0x5eec <generic_rawtp_filter_arg+0xfc>
    62b4:      	cmp	w9, #0x2a
    62b8:      	b.eq	0x633c <generic_rawtp_filter_arg+0x54c>
    62bc:      	cmp	w9, #0x2c
    62c0:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    62c4:      	ldrb	w29, [x25, #0x3]
    62c8:      	add	x10, x25, #0x4
    62cc:      	cmp	w8, #0x19
    62d0:      	b.gt	0x6e80 <generic_rawtp_filter_arg+0x1090>
    62d4:      	sub	w9, w8, #0x3
    62d8:      	cmp	w9, #0x2
    62dc:      	b.hs	0x73e4 <generic_rawtp_filter_arg+0x15f4>
    62e0:      	cmp	w29, #0x90
    62e4:      	str	wzr, [sp, #0x88]
    62e8:      	b.hi	0x7480 <generic_rawtp_filter_arg+0x1690>
    62ec:      	mov	w8, #0xaaab             // =43691
    62f0:      	mov	w9, #0x18               // =24
    62f4:      	movk	w8, #0xaaa, lsl #16
    62f8:      	umull	x8, w29, w8
    62fc:      	lsr	x8, x8, #32
    6300:      	msub	w8, w8, w9, w29
    6304:      	cbz	w29, 0x6310 <generic_rawtp_filter_arg+0x520>
    6308:      	mov	w13, w29
    630c:      	cbz	w8, 0x6324 <generic_rawtp_filter_arg+0x534>
    6310:      	sub	w8, w29, w8, uxtb
    6314:      	add	w9, w8, #0x18
    6318:      	cmp	w8, #0x78
    631c:      	and	w13, w9, #0xffff
    6320:      	b.hi	0x7484 <generic_rawtp_filter_arg+0x1694>
    6324:      	and	w8, w13, #0xff
    6328:      	mov	w9, #0xab               // =171
    632c:      	mul	w8, w8, w9
    6330:      	lsr	w8, w8, #12
    6334:      	sub	w11, w8, #0x1
    6338:      	b	0x7e78 <generic_rawtp_filter_arg+0x2088>
    633c:      	ldr	w29, [x25]
    6340:      	and	w9, w8, #0xfffffffe
    6344:      	cmp	w9, #0x24
    6348:      	b.eq	0x6350 <generic_rawtp_filter_arg+0x560>
    634c:      	cbz	w29, 0x5eec <generic_rawtp_filter_arg+0xfc>
    6350:      	cmp	w8, #0x25
    6354:      	b.hi	0x6594 <generic_rawtp_filter_arg+0x7a4>
    6358:      	mov	w10, #0x100             // =256
    635c:      	lsl	x9, x12, x8
    6360:      	movk	w10, #0x400, lsl #16
    6364:      	tst	x9, x10
    6368:      	b.ne	0x66c4 <generic_rawtp_filter_arg+0x8d4>
    636c:      	mov	w10, #0x200             // =512
    6370:      	lsl	x9, x12, x8
    6374:      	movk	w10, #0x800, lsl #16
    6378:      	tst	x9, x10
    637c:      	b.ne	0x65f4 <generic_rawtp_filter_arg+0x804>
    6380:      	lsl	x9, x12, x8
    6384:      	tst	x9, #0x3000000000
    6388:      	b.eq	0x6594 <generic_rawtp_filter_arg+0x7a4>
    638c:      	cmp	w29, #0x1, lsl #12      // =0x1000
    6390:      	strh	wzr, [sp, #0x60]
    6394:      	b.hi	0x65ac <generic_rawtp_filter_arg+0x7bc>
    6398:      	add	x8, x25, #0x4
    639c:      	mov	w10, #0x4               // =4
    63a0:      	add	x11, sp, #0x60
    63a4:      	mov	w12, #0x2               // =2
    63a8:      	add	x0, sp, #0x60
    63ac:      	mov	w1, #0x2                // =2
    63b0:      	add	x9, x8, x29
    63b4:      	add	x9, x9, #0x4
    63b8:      	ldr	w9, [x25]
    63bc:      	add	x8, x8, x9
    63c0:      	add	x2, x8, #0x4
    63c4:      	blr	x10
    63c8:      	ldr	w9, [x23, #0x10]
    63cc:      	cbz	w9, 0x8bd0 <generic_rawtp_filter_arg+0x2de0>
    63d0:      	ldrh	w8, [sp, #0x60]
    63d4:      	ldp	x16, x15, [sp, #0x40]
    63d8:      	mov	w2, #0x5ea0             // =24224
    63dc:      	mov	w12, #0x1               // =1
    63e0:      	and	w8, w8, #0xf000
    63e4:      	ldr	x17, [sp, #0x38]
    63e8:      	cmp	w9, w8
    63ec:      	b.ne	0x7774 <generic_rawtp_filter_arg+0x1984>
    63f0:      	mov	w22, #0x1               // =1
    63f4:      	b	0x8be4 <generic_rawtp_filter_arg+0x2df4>
    63f8:      	sub	w10, w9, #0xc
    63fc:      	cmp	w10, #0x2
    6400:      	b.hs	0x67d8 <generic_rawtp_filter_arg+0x9e8>
    6404:      	cmp	w8, #0x20
    6408:      	b.hi	0x5eec <generic_rawtp_filter_arg+0xfc>
    640c:      	lsl	x10, x12, x8
    6410:      	mov	w11, #0x101e            // =4126
    6414:      	tst	x10, x11
    6418:      	b.eq	0x645c <generic_rawtp_filter_arg+0x66c>
    641c:      	ldr	w10, [x23, #0x10]
    6420:      	cmp	w8, #0x2
    6424:      	b.le	0x67a0 <generic_rawtp_filter_arg+0x9b0>
    6428:      	sub	w11, w8, #0x3
    642c:      	cmp	w11, #0x2
    6430:      	b.hs	0x6bdc <generic_rawtp_filter_arg+0xdec>
    6434:      	ldr	w11, [x25]
    6438:      	cmp	w11, w10
    643c:      	b.eq	0x607c <generic_rawtp_filter_arg+0x28c>
    6440:      	b	0x7ca0 <generic_rawtp_filter_arg+0x1eb0>
    6444:      	cmp	w9, #0x28
    6448:      	b.eq	0x6908 <generic_rawtp_filter_arg+0xb18>
    644c:      	cmp	w9, #0x29
    6450:      	mov	x10, x25
    6454:      	b.eq	0x6930 <generic_rawtp_filter_arg+0xb40>
    6458:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    645c:      	lsl	x10, x12, x8
    6460:      	tst	x10, #0xc00
    6464:      	b.ne	0x68c8 <generic_rawtp_filter_arg+0xad8>
    6468:      	lsl	x10, x12, x8
    646c:      	tst	x10, #0x180000000
    6470:      	b.eq	0x5eec <generic_rawtp_filter_arg+0xfc>
    6474:      	cmp	w8, #0x1f
    6478:      	b.ne	0x6e50 <generic_rawtp_filter_arg+0x1060>
    647c:      	ldp	w11, w10, [x23, #0x10]
    6480:      	cmp	w9, #0xc
    6484:      	b.hi	0x7940 <generic_rawtp_filter_arg+0x1b50>
    6488:      	lsl	w8, w12, w9
    648c:      	mov	w13, #0x1402            // =5122
    6490:      	tst	w8, w13
    6494:      	b.eq	0x7940 <generic_rawtp_filter_arg+0x1b50>
    6498:      	ldr	w8, [x25]
    649c:      	cmp	w11, w8
    64a0:      	b.gt	0x7954 <generic_rawtp_filter_arg+0x1b64>
    64a4:      	cmp	w8, w10
    64a8:      	b.le	0x6088 <generic_rawtp_filter_arg+0x298>
    64ac:      	b	0x7954 <generic_rawtp_filter_arg+0x1b64>
    64b0:      	cmp	w8, #0x20
    64b4:      	b.gt	0x69a4 <generic_rawtp_filter_arg+0xbb4>
    64b8:      	cmp	w8, #0x1a
    64bc:      	b.eq	0x6aec <generic_rawtp_filter_arg+0xcfc>
    64c0:      	cmp	w8, #0x1b
    64c4:      	b.ne	0x70b0 <generic_rawtp_filter_arg+0x12c0>
    64c8:      	ldr	w8, [x23, #0x10]
    64cc:      	str	wzr, [sp, #0x88]
    64d0:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0x210>
    64d4:      	add	x9, sp, #0x60
    64d8:      	add	x1, sp, #0x60
    64dc:      	str	w8, [sp, #0x60]
    64e0:      	mov	w8, #0x1                // =1
    64e4:      	ldr	x0, [x0]
    64e8:      	blr	x8
    64ec:      	mov	x22, xzr
    64f0:      	cbz	w29, 0x70a0 <generic_rawtp_filter_arg+0x12b0>
    64f4:      	cbz	x0, 0x70a0 <generic_rawtp_filter_arg+0x12b0>
    64f8:      	mov	x19, x0
    64fc:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0x210>
    6500:      	mov	w8, #0x1                // =1
    6504:      	ldr	x0, [x0]
    6508:      	add	x9, sp, #0x88
    650c:      	add	x1, sp, #0x88
    6510:      	blr	x8
    6514:      	cbz	x0, 0x7098 <generic_rawtp_filter_arg+0x12a8>
    6518:      	cmp	w29, #0x7f
    651c:      	mov	w9, #0x7f               // =127
    6520:      	mov	w11, #0x1               // =1
    6524:      	mov	x1, x0
    6528:      	mov	x8, xzr
    652c:      	sub	w12, w29, #0x2
    6530:      	sub	w13, w29, #0x1
    6534:      	csel	w9, w29, w9, lo
    6538:      	sub	x11, x11, x29
    653c:      	lsl	w10, w9, #3
    6540:      	mov	x9, x0
    6544:      	str	w10, [x9], #0x5
    6548:      	neg	x10, x29
    654c:      	add	w14, w13, w8
    6550:      	cmp	x11, x8
    6554:      	and	x14, x14, #0xfff
    6558:      	ldrb	w14, [x25, x14]
    655c:      	sturb	w14, [x9, #-0x1]
    6560:      	b.eq	0x6588 <generic_rawtp_filter_arg+0x798>
    6564:      	cmn	x8, #0x7e
    6568:      	b.eq	0x6588 <generic_rawtp_filter_arg+0x798>
    656c:      	add	w14, w12, w8
    6570:      	sub	x8, x8, #0x2
    6574:      	and	x14, x14, #0xfff
    6578:      	cmp	x10, x8
    657c:      	ldrb	w14, [x25, x14]
    6580:      	strb	w14, [x9], #0x2
    6584:      	b.ne	0x654c <generic_rawtp_filter_arg+0x75c>
    6588:      	mov	w8, #0x1                // =1
    658c:      	mov	x0, x19
    6590:      	b	0x6b74 <generic_rawtp_filter_arg+0xd84>
    6594:      	sub	w8, w8, #0x3
    6598:      	cmp	w8, #0x2
    659c:      	b.hs	0x65ac <generic_rawtp_filter_arg+0x7bc>
    65a0:      	cmp	w29, #0x1, lsl #12      // =0x1000
    65a4:      	str	wzr, [sp, #0x88]
    65a8:      	b.ls	0x6ce4 <generic_rawtp_filter_arg+0xef4>
    65ac:      	mov	x22, xzr
    65b0:      	b	0x8be4 <generic_rawtp_filter_arg+0x2df4>
    65b4:      	cmp	w8, #0x20
    65b8:      	b.hi	0x5eec <generic_rawtp_filter_arg+0xfc>
    65bc:      	lsl	x9, x12, x8
    65c0:      	mov	w10, #0x101e            // =4126
    65c4:      	tst	x9, x10
    65c8:      	b.eq	0x6c20 <generic_rawtp_filter_arg+0xe30>
    65cc:      	ldr	w9, [x23, #0x10]
    65d0:      	cmp	w8, #0x2
    65d4:      	b.le	0x71b0 <generic_rawtp_filter_arg+0x13c0>
    65d8:      	sub	w10, w8, #0x3
    65dc:      	cmp	w10, #0x2
    65e0:      	b.hs	0x775c <generic_rawtp_filter_arg+0x196c>
    65e4:      	ldrh	w10, [x25]
    65e8:      	cmp	w9, w10
    65ec:      	b.eq	0x607c <generic_rawtp_filter_arg+0x28c>
    65f0:      	b	0x790c <generic_rawtp_filter_arg+0x1b1c>
    65f4:      	ldr	w8, [x23, #0x10]
    65f8:      	str	wzr, [sp, #0x88]
    65fc:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0x210>
    6600:      	add	x9, sp, #0x60
    6604:      	add	x1, sp, #0x60
    6608:      	str	w8, [sp, #0x60]
    660c:      	mov	w8, #0x1                // =1
    6610:      	ldr	x0, [x0]
    6614:      	blr	x8
    6618:      	mov	x22, xzr
    661c:      	cbz	w29, 0x8bd4 <generic_rawtp_filter_arg+0x2de4>
    6620:      	cbz	x0, 0x8bd4 <generic_rawtp_filter_arg+0x2de4>
    6624:      	mov	x19, x0
    6628:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0x210>
    662c:      	mov	w8, #0x1                // =1
    6630:      	ldr	x0, [x0]
    6634:      	add	x9, sp, #0x88
    6638:      	add	x1, sp, #0x88
    663c:      	blr	x8
    6640:      	cbz	x0, 0x77c4 <generic_rawtp_filter_arg+0x19d4>
    6644:      	cmp	w29, #0x7f
    6648:      	mov	w10, #0x7f              // =127
    664c:      	mov	w12, #0x1               // =1
    6650:      	mov	x1, x0
    6654:      	mov	x8, xzr
    6658:      	add	x9, x25, #0x4
    665c:      	sub	w13, w29, #0x2
    6660:      	sub	w14, w29, #0x1
    6664:      	csel	w10, w29, w10, lo
    6668:      	sub	x12, x12, x29
    666c:      	lsl	w11, w10, #3
    6670:      	mov	x10, x0
    6674:      	str	w11, [x10], #0x5
    6678:      	neg	x11, x29
    667c:      	add	w15, w14, w8
    6680:      	cmp	x12, x8
    6684:      	and	x15, x15, #0xfff
    6688:      	ldrb	w15, [x9, x15]
    668c:      	sturb	w15, [x10, #-0x1]
    6690:      	b.eq	0x66b8 <generic_rawtp_filter_arg+0x8c8>
    6694:      	cmn	x8, #0x7e
    6698:      	b.eq	0x66b8 <generic_rawtp_filter_arg+0x8c8>
    669c:      	add	w15, w13, w8
    66a0:      	sub	x8, x8, #0x2
    66a4:      	and	x15, x15, #0xfff
    66a8:      	cmp	x11, x8
    66ac:      	ldrb	w15, [x9, x15]
    66b0:      	strb	w15, [x10], #0x2
    66b4:      	b.ne	0x667c <generic_rawtp_filter_arg+0x88c>
    66b8:      	mov	w8, #0x1                // =1
    66bc:      	mov	x0, x19
    66c0:      	b	0x674c <generic_rawtp_filter_arg+0x95c>
    66c4:      	ldr	w8, [x23, #0x10]
    66c8:      	str	wzr, [sp, #0x88]
    66cc:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0x210>
    66d0:      	add	x9, sp, #0x60
    66d4:      	add	x1, sp, #0x60
    66d8:      	str	w8, [sp, #0x60]
    66dc:      	mov	w8, #0x1                // =1
    66e0:      	ldr	x0, [x0]
    66e4:      	blr	x8
    66e8:      	mov	x22, xzr
    66ec:      	cbz	w29, 0x8bd4 <generic_rawtp_filter_arg+0x2de4>
    66f0:      	cbz	x0, 0x8bd4 <generic_rawtp_filter_arg+0x2de4>
    66f4:      	mov	x19, x0
    66f8:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0x210>
    66fc:      	mov	w8, #0x1                // =1
    6700:      	ldr	x0, [x0]
    6704:      	add	x9, sp, #0x88
    6708:      	add	x1, sp, #0x88
    670c:      	blr	x8
    6710:      	cbz	x0, 0x77c4 <generic_rawtp_filter_arg+0x19d4>
    6714:      	cmp	w29, #0xff
    6718:      	mov	w8, #0xff               // =255
    671c:      	add	x2, x25, #0x4
    6720:      	mov	x22, x0
    6724:      	csel	w1, w29, w8, lo
    6728:      	mov	x8, x0
    672c:      	lsl	w9, w1, #3
    6730:      	str	w9, [x8], #0x4
    6734:      	mov	w9, #0x4                // =4
    6738:      	mov	x0, x8
    673c:      	blr	x9
    6740:      	mov	w8, #0x1                // =1
    6744:      	mov	x0, x19
    6748:      	mov	x1, x22
    674c:      	blr	x8
    6750:      	cmp	x0, #0x0
    6754:      	cset	w22, ne
    6758:      	b	0x77c8 <generic_rawtp_filter_arg+0x19d8>
    675c:      	sub	w10, w8, #0x1
    6760:      	cmp	w10, #0x4
    6764:      	b.lo	0x67f8 <generic_rawtp_filter_arg+0xa08>
    6768:      	b	0x5eec <generic_rawtp_filter_arg+0xfc>
    676c:      	add	x29, x25, #0x8
    6770:      	ldr	w25, [x25, #0x4]
    6774:      	mov	x22, xzr
    6778:      	cmp	w8, #0x19
    677c:      	b.gt	0x6d54 <generic_rawtp_filter_arg+0xf64>
    6780:      	sub	w9, w8, #0x3
    6784:      	cmp	w9, #0x2
    6788:      	b.lo	0x7570 <generic_rawtp_filter_arg+0x1780>
    678c:      	cmp	w8, #0x8
    6790:      	b.eq	0x74e4 <generic_rawtp_filter_arg+0x16f4>
    6794:      	cmp	w8, #0x9
    6798:      	b.eq	0x6d6c <generic_rawtp_filter_arg+0xf7c>
    679c:      	b	0x9174 <generic_rawtp_filter_arg+0x3384>
    67a0:      	cmp	w8, #0x1
    67a4:      	b.eq	0x6fbc <generic_rawtp_filter_arg+0x11cc>
    67a8:      	cmp	w8, #0x2
    67ac:      	b.ne	0x7ca0 <generic_rawtp_filter_arg+0x1eb0>
    67b0:      	cmp	w9, #0xc
    67b4:      	b.hi	0x7c94 <generic_rawtp_filter_arg+0x1ea4>
    67b8:      	lsl	w11, w12, w9
    67bc:      	mov	w13, #0x1402            // =5122
    67c0:      	tst	w11, w13
    67c4:      	b.eq	0x7c94 <generic_rawtp_filter_arg+0x1ea4>
    67c8:      	ldr	w11, [x25]
    67cc:      	cmp	w11, w10
    67d0:      	b.lt	0x6088 <generic_rawtp_filter_arg+0x298>
    67d4:      	b	0x7ca0 <generic_rawtp_filter_arg+0x1eb0>
    67d8:      	cmp	w9, #0x1c
    67dc:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    67e0:      	cmp	w8, #0x20
    67e4:      	b.hi	0x5eec <generic_rawtp_filter_arg+0xfc>
    67e8:      	lsl	x10, x12, x8
    67ec:      	mov	w11, #0x101e            // =4126
    67f0:      	tst	x10, x11
    67f4:      	b.eq	0x6820 <generic_rawtp_filter_arg+0xa30>
    67f8:      	ldr	x10, [x23, #0x10]
    67fc:      	cmp	w8, #0x2
    6800:      	b.le	0x683c <generic_rawtp_filter_arg+0xa4c>
    6804:      	sub	w11, w8, #0x3
    6808:      	cmp	w11, #0x2
    680c:      	b.hs	0x6a94 <generic_rawtp_filter_arg+0xca4>
    6810:      	ldr	x11, [x25]
    6814:      	cmp	x11, x10
    6818:      	b.eq	0x607c <generic_rawtp_filter_arg+0x28c>
    681c:      	b	0x76b8 <generic_rawtp_filter_arg+0x18c8>
    6820:      	lsl	x10, x12, x8
    6824:      	tst	x10, #0xc00
    6828:      	b.ne	0x686c <generic_rawtp_filter_arg+0xa7c>
    682c:      	lsl	x10, x12, x8
    6830:      	tst	x10, #0x180000000
    6834:      	b.ne	0x6ab8 <generic_rawtp_filter_arg+0xcc8>
    6838:      	b	0x5eec <generic_rawtp_filter_arg+0xfc>
    683c:      	cmp	w8, #0x1
    6840:      	b.eq	0x6cc4 <generic_rawtp_filter_arg+0xed4>
    6844:      	cmp	w8, #0x2
    6848:      	b.ne	0x76b8 <generic_rawtp_filter_arg+0x18c8>
    684c:      	cmp	w9, #0xc
    6850:      	b.eq	0x685c <generic_rawtp_filter_arg+0xa6c>
    6854:      	cmp	w9, #0xa
    6858:      	b.ne	0x76ac <generic_rawtp_filter_arg+0x18bc>
    685c:      	ldr	x11, [x25]
    6860:      	cmp	x11, x10
    6864:      	b.lt	0x6088 <generic_rawtp_filter_arg+0x298>
    6868:      	b	0x76b8 <generic_rawtp_filter_arg+0x18c8>
    686c:      	ldrb	w8, [x23, #0x10]
    6870:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0x210>
    6874:      	add	x9, sp, #0x88
    6878:      	add	x1, sp, #0x88
    687c:      	str	w8, [sp, #0x88]
    6880:      	mov	w8, #0x1                // =1
    6884:      	ldr	x0, [x0]
    6888:      	blr	x8
    688c:      	cbz	x0, 0x6e38 <generic_rawtp_filter_arg+0x1048>
    6890:      	ldr	x8, [x25]
    6894:      	add	x9, sp, #0x60
    6898:      	add	x1, sp, #0x60
    689c:      	str	x8, [sp, #0x60]
    68a0:      	mov	w8, #0x1                // =1
    68a4:      	blr	x8
    68a8:      	ldr	w8, [x23, #0x4]
    68ac:      	cmp	w8, #0xb
    68b0:      	b.eq	0x7264 <generic_rawtp_filter_arg+0x1474>
    68b4:      	cmp	w8, #0xa
    68b8:      	mov	w12, #0x1               // =1
    68bc:      	b.eq	0x7304 <generic_rawtp_filter_arg+0x1514>
    68c0:      	mov	w8, wzr
    68c4:      	b	0x730c <generic_rawtp_filter_arg+0x151c>
    68c8:      	ldrb	w8, [x23, #0x10]
    68cc:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0x210>
    68d0:      	add	x9, sp, #0x88
    68d4:      	add	x1, sp, #0x88
    68d8:      	str	w8, [sp, #0x88]
    68dc:      	mov	w8, #0x1                // =1
    68e0:      	ldr	x0, [x0]
    68e4:      	blr	x8
    68e8:      	cbz	x0, 0x7680 <generic_rawtp_filter_arg+0x1890>
    68ec:      	ldr	w8, [x25]
    68f0:      	add	x9, sp, #0x60
    68f4:      	str	x8, [sp, #0x60]
    68f8:      	mov	w8, #0x1                // =1
    68fc:      	b	0x723c <generic_rawtp_filter_arg+0x144c>
    6900:      	mov	x10, xzr
    6904:      	b	0x6930 <generic_rawtp_filter_arg+0xb40>
    6908:      	ldrh	w11, [x25]
    690c:      	mov	x10, xzr
    6910:      	strh	w11, [sp, #0x86]
    6914:      	ldrh	w11, [x25, #0x2]
    6918:      	strh	w11, [sp, #0x80]
    691c:      	ldr	x11, [x25, #0x8]
    6920:      	str	x11, [sp, #0x60]
    6924:      	ldr	x11, [x25, #0x10]
    6928:      	add	x25, sp, #0x60
    692c:      	str	x11, [sp, #0x68]
    6930:      	mov	x22, xzr
    6934:      	cmp	w8, #0x13
    6938:      	b.le	0x6960 <generic_rawtp_filter_arg+0xb70>
    693c:      	cmp	w8, #0x17
    6940:      	b.gt	0x6988 <generic_rawtp_filter_arg+0xb98>
    6944:      	sub	w9, w8, #0x14
    6948:      	cmp	w9, #0x2
    694c:      	b.lo	0x6ebc <generic_rawtp_filter_arg+0x10cc>
    6950:      	sub	w9, w8, #0x16
    6954:      	cmp	w9, #0x2
    6958:      	b.lo	0x6ea8 <generic_rawtp_filter_arg+0x10b8>
    695c:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    6960:      	cmp	w8, #0xf
    6964:      	b.le	0x6b98 <generic_rawtp_filter_arg+0xda8>
    6968:      	cmp	w8, #0x11
    696c:      	b.gt	0x6e98 <generic_rawtp_filter_arg+0x10a8>
    6970:      	cmp	w8, #0x10
    6974:      	b.eq	0x6ea8 <generic_rawtp_filter_arg+0x10b8>
    6978:      	cmp	w8, #0x11
    697c:      	b.ne	0x6084 <generic_rawtp_filter_arg+0x294>
    6980:      	ldrh	w22, [x25, #0x24]
    6984:      	b	0x7614 <generic_rawtp_filter_arg+0x1824>
    6988:      	cmp	w8, #0x1b
    698c:      	b.gt	0x6ed0 <generic_rawtp_filter_arg+0x10e0>
    6990:      	cmp	w8, #0x18
    6994:      	b.eq	0x6f00 <generic_rawtp_filter_arg+0x1110>
    6998:      	cmp	w8, #0x19
    699c:      	b.eq	0x6ef4 <generic_rawtp_filter_arg+0x1104>
    69a0:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    69a4:      	cmp	w8, #0x21
    69a8:      	b.eq	0x6fe4 <generic_rawtp_filter_arg+0x11f4>
    69ac:      	cmp	w8, #0x22
    69b0:      	b.ne	0x70b0 <generic_rawtp_filter_arg+0x12c0>
    69b4:      	mov	x22, xzr
    69b8:      	mov	w19, wzr
    69bc:      	add	x8, x23, #0x10
    69c0:      	str	x8, [sp, #0x28]
    69c4:      	ldr	x8, [sp, #0x28]
    69c8:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0x210>
    69cc:      	add	x9, sp, #0x60
    69d0:      	add	x1, sp, #0x60
    69d4:      	ldr	w8, [x8, x22, lsl #2]
    69d8:      	str	w8, [sp, #0x60]
    69dc:      	mov	w8, #0x1                // =1
    69e0:      	ldr	x0, [x0]
    69e4:      	blr	x8
    69e8:      	cbz	x0, 0x7098 <generic_rawtp_filter_arg+0x12a8>
    69ec:      	cbz	w29, 0x6a70 <generic_rawtp_filter_arg+0xc80>
    69f0:      	mov	x8, xzr
    69f4:      	mov	x9, x25
    69f8:      	mov	x10, x29
    69fc:      	b	0x6a14 <generic_rawtp_filter_arg+0xc24>
    6a00:      	add	x8, x8, #0x1
    6a04:      	sub	x10, x10, #0x1
    6a08:      	add	x9, x9, #0x1
    6a0c:      	cmp	x8, x29
    6a10:      	b.eq	0x6a70 <generic_rawtp_filter_arg+0xc80>
    6a14:      	mov	x11, xzr
    6a18:      	nop
    6a1c:      	nop
    6a20:      	cmp	x10, x11
    6a24:      	b.eq	0x6a00 <generic_rawtp_filter_arg+0xc10>
    6a28:      	ldrb	w12, [x0, x11]
    6a2c:      	cbz	w12, 0x6a6c <generic_rawtp_filter_arg+0xc7c>
    6a30:      	ldrb	w13, [x9, x11]
    6a34:      	sub	w14, w13, #0x41
    6a38:      	orr	w15, w13, #0x20
    6a3c:      	cmp	w14, #0x1a
    6a40:      	sub	w14, w12, #0x41
    6a44:      	csel	w13, w15, w13, lo
    6a48:      	orr	w15, w12, #0x20
    6a4c:      	cmp	w14, #0x1a
    6a50:      	csel	w12, w15, w12, lo
    6a54:      	cmp	x11, #0x62
    6a58:      	b.hi	0x6a00 <generic_rawtp_filter_arg+0xc10>
    6a5c:      	add	x11, x11, #0x1
    6a60:      	cmp	w13, w12
    6a64:      	b.eq	0x6a20 <generic_rawtp_filter_arg+0xc30>
    6a68:      	b	0x6a00 <generic_rawtp_filter_arg+0xc10>
    6a6c:      	tbz	w8, #0x1f, 0x78b8 <generic_rawtp_filter_arg+0x1ac8>
    6a70:      	ldr	w9, [x23, #0x8]
    6a74:      	add	w8, w19, #0xc
    6a78:      	cmp	w8, w9
    6a7c:      	b.hs	0x7098 <generic_rawtp_filter_arg+0x12a8>
    6a80:      	add	x22, x22, #0x1
    6a84:      	add	w19, w19, #0x4
    6a88:      	cmp	x22, #0x64
    6a8c:      	b.ne	0x69c4 <generic_rawtp_filter_arg+0xbd4>
    6a90:      	b	0x7098 <generic_rawtp_filter_arg+0x12a8>
    6a94:      	cmp	w8, #0xc
    6a98:      	b.ne	0x76b8 <generic_rawtp_filter_arg+0x18c8>
    6a9c:      	ldr	x11, [x25]
    6aa0:      	tst	x11, x10
    6aa4:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    6aa8:      	b	0x76b8 <generic_rawtp_filter_arg+0x18c8>
    6aac:      	sub	w10, w8, #0x1f
    6ab0:      	cmp	w10, #0x2
    6ab4:      	b.hs	0x7330 <generic_rawtp_filter_arg+0x1540>
    6ab8:      	cmp	w8, #0x1f
    6abc:      	b.ne	0x6bb4 <generic_rawtp_filter_arg+0xdc4>
    6ac0:      	ldp	x11, x10, [x23, #0x10]
    6ac4:      	cmp	w9, #0xa
    6ac8:      	b.eq	0x6ad4 <generic_rawtp_filter_arg+0xce4>
    6acc:      	cmp	w9, #0xc
    6ad0:      	b.ne	0x7584 <generic_rawtp_filter_arg+0x1794>
    6ad4:      	ldr	x8, [x25]
    6ad8:      	cmp	x11, x8
    6adc:      	b.gt	0x7598 <generic_rawtp_filter_arg+0x17a8>
    6ae0:      	cmp	x8, x10
    6ae4:      	b.le	0x6088 <generic_rawtp_filter_arg+0x298>
    6ae8:      	b	0x7598 <generic_rawtp_filter_arg+0x17a8>
    6aec:      	ldr	w8, [x23, #0x10]
    6af0:      	str	wzr, [sp, #0x88]
    6af4:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0x210>
    6af8:      	add	x9, sp, #0x60
    6afc:      	add	x1, sp, #0x60
    6b00:      	str	w8, [sp, #0x60]
    6b04:      	mov	w8, #0x1                // =1
    6b08:      	ldr	x0, [x0]
    6b0c:      	blr	x8
    6b10:      	mov	x22, xzr
    6b14:      	cbz	w29, 0x70a0 <generic_rawtp_filter_arg+0x12b0>
    6b18:      	cbz	x0, 0x70a0 <generic_rawtp_filter_arg+0x12b0>
    6b1c:      	mov	x19, x0
    6b20:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0x210>
    6b24:      	mov	w8, #0x1                // =1
    6b28:      	ldr	x0, [x0]
    6b2c:      	add	x9, sp, #0x88
    6b30:      	add	x1, sp, #0x88
    6b34:      	blr	x8
    6b38:      	cbz	x0, 0x7098 <generic_rawtp_filter_arg+0x12a8>
    6b3c:      	cmp	w29, #0xff
    6b40:      	mov	w8, #0xff               // =255
    6b44:      	mov	x22, x0
    6b48:      	mov	x2, x25
    6b4c:      	csel	w1, w29, w8, lo
    6b50:      	mov	x8, x0
    6b54:      	lsl	w9, w1, #3
    6b58:      	str	w9, [x8], #0x4
    6b5c:      	mov	w9, #0x4                // =4
    6b60:      	mov	x0, x8
    6b64:      	blr	x9
    6b68:      	mov	w8, #0x1                // =1
    6b6c:      	mov	x0, x19
    6b70:      	mov	x1, x22
    6b74:      	blr	x8
    6b78:      	cmp	x0, #0x0
    6b7c:      	cset	w22, ne
    6b80:      	b	0x709c <generic_rawtp_filter_arg+0x12ac>
    6b84:      	cmp	w29, #0x1, lsl #12      // =0x1000
    6b88:      	str	wzr, [sp, #0x88]
    6b8c:      	b.ls	0x70d8 <generic_rawtp_filter_arg+0x12e8>
    6b90:      	mov	x22, xzr
    6b94:      	b	0x70b0 <generic_rawtp_filter_arg+0x12c0>
    6b98:      	cmp	w8, #0xd
    6b9c:      	b.eq	0x6f00 <generic_rawtp_filter_arg+0x1110>
    6ba0:      	cmp	w8, #0xe
    6ba4:      	b.eq	0x6ef4 <generic_rawtp_filter_arg+0x1104>
    6ba8:      	cmp	w8, #0xf
    6bac:      	b.eq	0x6ebc <generic_rawtp_filter_arg+0x10cc>
    6bb0:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    6bb4:      	ldp	x11, x8, [x23, #0x10]
    6bb8:      	cmp	w9, #0xc
    6bbc:      	b.eq	0x6bc8 <generic_rawtp_filter_arg+0xdd8>
    6bc0:      	cmp	w9, #0xa
    6bc4:      	b.ne	0x75d0 <generic_rawtp_filter_arg+0x17e0>
    6bc8:      	ldr	x10, [x25]
    6bcc:      	cmp	x11, x10
    6bd0:      	ccmp	x10, x8, #0x0, le
    6bd4:      	cset	w8, le
    6bd8:      	b	0x75e0 <generic_rawtp_filter_arg+0x17f0>
    6bdc:      	cmp	w8, #0xc
    6be0:      	b.ne	0x7ca0 <generic_rawtp_filter_arg+0x1eb0>
    6be4:      	ldr	w11, [x25]
    6be8:      	tst	w11, w10
    6bec:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    6bf0:      	b	0x7ca0 <generic_rawtp_filter_arg+0x1eb0>
    6bf4:      	lsl	x9, x12, x8
    6bf8:      	tst	x9, #0xc00
    6bfc:      	b.ne	0x71d0 <generic_rawtp_filter_arg+0x13e0>
    6c00:      	lsl	x9, x12, x8
    6c04:      	tst	x9, #0x180000000
    6c08:      	b.eq	0x5eec <generic_rawtp_filter_arg+0xfc>
    6c0c:      	cmp	w8, #0x1f
    6c10:      	b.ne	0x77f4 <generic_rawtp_filter_arg+0x1a04>
    6c14:      	ldr	w9, [x23, #0x10]
    6c18:      	ldrb	w8, [x25]
    6c1c:      	b	0x6c48 <generic_rawtp_filter_arg+0xe58>
    6c20:      	lsl	x9, x12, x8
    6c24:      	tst	x9, #0xc00
    6c28:      	b.ne	0x7208 <generic_rawtp_filter_arg+0x1418>
    6c2c:      	lsl	x9, x12, x8
    6c30:      	tst	x9, #0x180000000
    6c34:      	b.eq	0x5eec <generic_rawtp_filter_arg+0xfc>
    6c38:      	cmp	w8, #0x1f
    6c3c:      	b.ne	0x7818 <generic_rawtp_filter_arg+0x1a28>
    6c40:      	ldr	w9, [x23, #0x10]
    6c44:      	ldrh	w8, [x25]
    6c48:      	cmp	w9, w8
    6c4c:      	b.hi	0x6c5c <generic_rawtp_filter_arg+0xe6c>
    6c50:      	ldr	w9, [x23, #0x14]
    6c54:      	cmp	w9, w8
    6c58:      	b.hs	0x6088 <generic_rawtp_filter_arg+0x298>
    6c5c:      	ldr	w9, [x23, #0x8]
    6c60:      	cmp	w9, #0x11
    6c64:      	b.lo	0x5eec <generic_rawtp_filter_arg+0xfc>
    6c68:      	ldr	w10, [x23, #0x18]
    6c6c:      	cmp	w10, w8
    6c70:      	b.hi	0x6c80 <generic_rawtp_filter_arg+0xe90>
    6c74:      	ldr	w10, [x23, #0x1c]
    6c78:      	cmp	w10, w8
    6c7c:      	b.hs	0x6088 <generic_rawtp_filter_arg+0x298>
    6c80:      	cmp	w9, #0x19
    6c84:      	b.lo	0x5eec <generic_rawtp_filter_arg+0xfc>
    6c88:      	ldr	w10, [x23, #0x20]
    6c8c:      	cmp	w10, w8
    6c90:      	b.hi	0x6ca0 <generic_rawtp_filter_arg+0xeb0>
    6c94:      	ldr	w10, [x23, #0x24]
    6c98:      	cmp	w10, w8
    6c9c:      	b.hs	0x6088 <generic_rawtp_filter_arg+0x298>
    6ca0:      	cmp	w9, #0x21
    6ca4:      	b.lo	0x5eec <generic_rawtp_filter_arg+0xfc>
    6ca8:      	ldr	w9, [x23, #0x28]
    6cac:      	cmp	w9, w8
    6cb0:      	b.hi	0x5eec <generic_rawtp_filter_arg+0xfc>
    6cb4:      	ldr	w9, [x23, #0x2c]
    6cb8:      	cmp	w9, w8
    6cbc:      	b.hs	0x6088 <generic_rawtp_filter_arg+0x298>
    6cc0:      	b	0x5eec <generic_rawtp_filter_arg+0xfc>
    6cc4:      	cmp	w9, #0xc
    6cc8:      	b.eq	0x6cd4 <generic_rawtp_filter_arg+0xee4>
    6ccc:      	cmp	w9, #0xa
    6cd0:      	b.ne	0x769c <generic_rawtp_filter_arg+0x18ac>
    6cd4:      	ldr	x11, [x25]
    6cd8:      	cmp	x11, x10
    6cdc:      	b.gt	0x6088 <generic_rawtp_filter_arg+0x298>
    6ce0:      	b	0x76b8 <generic_rawtp_filter_arg+0x18c8>
    6ce4:      	and	w8, w29, #0xffff
    6ce8:      	cmp	w8, #0x90
    6cec:      	b.hi	0x7284 <generic_rawtp_filter_arg+0x1494>
    6cf0:      	and	w8, w29, #0xff
    6cf4:      	mov	w9, #0xab               // =171
    6cf8:      	tst	w29, #0xffff
    6cfc:      	mul	w8, w8, w9
    6d00:      	mov	w9, #0x18               // =24
    6d04:      	lsr	w8, w8, #12
    6d08:      	msub	w8, w8, w9, w29
    6d0c:      	b.eq	0x6d20 <generic_rawtp_filter_arg+0xf30>
    6d10:      	tst	w8, #0xff
    6d14:      	mov	w9, w29
    6d18:      	mov	w11, w29
    6d1c:      	b.eq	0x6d3c <generic_rawtp_filter_arg+0xf4c>
    6d20:      	sub	w8, w29, w8, uxtb
    6d24:      	and	w9, w8, #0xffff
    6d28:      	add	w8, w8, #0x18
    6d2c:      	and	w11, w8, #0xffff
    6d30:      	cmp	w9, #0x78
    6d34:      	b.hi	0x8240 <generic_rawtp_filter_arg+0x2450>
    6d38:      	mov	w9, w11
    6d3c:      	and	w8, w9, #0xff
    6d40:      	mov	w9, #0xab               // =171
    6d44:      	mul	w8, w8, w9
    6d48:      	lsr	w8, w8, #12
    6d4c:      	sub	w10, w8, #0x1
    6d50:      	b	0x8290 <generic_rawtp_filter_arg+0x24a0>
    6d54:      	cmp	w8, #0x20
    6d58:      	b.gt	0x7370 <generic_rawtp_filter_arg+0x1580>
    6d5c:      	cmp	w8, #0x1a
    6d60:      	b.eq	0x74e4 <generic_rawtp_filter_arg+0x16f4>
    6d64:      	cmp	w8, #0x1b
    6d68:      	b.ne	0x9174 <generic_rawtp_filter_arg+0x3384>
    6d6c:      	ldr	w8, [x23, #0x10]
    6d70:      	str	wzr, [sp, #0x88]
    6d74:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0x210>
    6d78:      	add	x9, sp, #0x60
    6d7c:      	add	x1, sp, #0x60
    6d80:      	mov	w19, #0x1               // =1
    6d84:      	str	w8, [sp, #0x60]
    6d88:      	mov	w8, #0x1                // =1
    6d8c:      	ldr	x0, [x0]
    6d90:      	blr	x8
    6d94:      	mov	x22, xzr
    6d98:      	cbz	w25, 0x9170 <generic_rawtp_filter_arg+0x3380>
    6d9c:      	cbz	x0, 0x9170 <generic_rawtp_filter_arg+0x3380>
    6da0:      	mov	x22, x0
    6da4:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0x210>
    6da8:      	mov	w8, #0x1                // =1
    6dac:      	ldr	x0, [x0]
    6db0:      	add	x9, sp, #0x88
    6db4:      	add	x1, sp, #0x88
    6db8:      	blr	x8
    6dbc:      	cbz	x0, 0x916c <generic_rawtp_filter_arg+0x337c>
    6dc0:      	cmp	w25, #0x7f
    6dc4:      	mov	w9, #0x7f               // =127
    6dc8:      	mov	x1, x0
    6dcc:      	mov	x8, xzr
    6dd0:      	sub	x11, x19, x25
    6dd4:      	sub	w12, w25, #0x2
    6dd8:      	sub	w13, w25, #0x1
    6ddc:      	csel	w9, w25, w9, lo
    6de0:      	lsl	w10, w9, #3
    6de4:      	mov	x9, x0
    6de8:      	str	w10, [x9], #0x5
    6dec:      	neg	x10, x25
    6df0:      	add	w14, w13, w8
    6df4:      	cmp	x11, x8
    6df8:      	and	x14, x14, #0xfff
    6dfc:      	ldrb	w14, [x29, x14]
    6e00:      	sturb	w14, [x9, #-0x1]
    6e04:      	b.eq	0x6e2c <generic_rawtp_filter_arg+0x103c>
    6e08:      	cmn	x8, #0x7e
    6e0c:      	b.eq	0x6e2c <generic_rawtp_filter_arg+0x103c>
    6e10:      	add	w14, w12, w8
    6e14:      	sub	x8, x8, #0x2
    6e18:      	and	x14, x14, #0xfff
    6e1c:      	cmp	x10, x8
    6e20:      	ldrb	w14, [x29, x14]
    6e24:      	strb	w14, [x9], #0x2
    6e28:      	b.ne	0x6df0 <generic_rawtp_filter_arg+0x1000>
    6e2c:      	mov	w8, #0x1                // =1
    6e30:      	mov	x0, x22
    6e34:      	b	0x915c <generic_rawtp_filter_arg+0x336c>
    6e38:      	mov	x22, xzr
    6e3c:      	ldp	x16, x15, [sp, #0x40]
    6e40:      	mov	w2, #0x5ea0             // =24224
    6e44:      	mov	w12, #0x1               // =1
    6e48:      	ldr	x17, [sp, #0x38]
    6e4c:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    6e50:      	ldp	w11, w8, [x23, #0x10]
    6e54:      	cmp	w9, #0xc
    6e58:      	b.hi	0x7998 <generic_rawtp_filter_arg+0x1ba8>
    6e5c:      	lsl	w10, w12, w9
    6e60:      	mov	w13, #0x1402            // =5122
    6e64:      	tst	w10, w13
    6e68:      	b.eq	0x7998 <generic_rawtp_filter_arg+0x1ba8>
    6e6c:      	ldr	w10, [x25]
    6e70:      	cmp	w11, w10
    6e74:      	ccmp	w10, w8, #0x0, le
    6e78:      	cset	w8, le
    6e7c:      	b	0x79a8 <generic_rawtp_filter_arg+0x1bb8>
    6e80:      	cmp	w8, #0x1c
    6e84:      	b.eq	0x74a8 <generic_rawtp_filter_arg+0x16b8>
    6e88:      	mov	x25, x10
    6e8c:      	cmp	w8, #0x1a
    6e90:      	b.eq	0x73f0 <generic_rawtp_filter_arg+0x1600>
    6e94:      	b	0x5eec <generic_rawtp_filter_arg+0xfc>
    6e98:      	cmp	w8, #0x12
    6e9c:      	b.eq	0x6ebc <generic_rawtp_filter_arg+0x10cc>
    6ea0:      	cmp	w8, #0x13
    6ea4:      	b.ne	0x6084 <generic_rawtp_filter_arg+0x294>
    6ea8:      	ldrh	w29, [x25, #0x22]
    6eac:      	mov	w11, wzr
    6eb0:      	mov	w13, wzr
    6eb4:      	mov	x19, xzr
    6eb8:      	b	0x6f0c <generic_rawtp_filter_arg+0x111c>
    6ebc:      	ldrh	w29, [x25, #0x20]
    6ec0:      	mov	w11, wzr
    6ec4:      	mov	w13, wzr
    6ec8:      	mov	x19, xzr
    6ecc:      	b	0x6f0c <generic_rawtp_filter_arg+0x111c>
    6ed0:      	cmp	w8, #0x1c
    6ed4:      	b.eq	0x7610 <generic_rawtp_filter_arg+0x1820>
    6ed8:      	cmp	w8, #0x1d
    6edc:      	b.ne	0x6084 <generic_rawtp_filter_arg+0x294>
    6ee0:      	cmp	w9, #0x7
    6ee4:      	b.ne	0x7b44 <generic_rawtp_filter_arg+0x1d54>
    6ee8:      	cbnz	x10, 0x7b54 <generic_rawtp_filter_arg+0x1d64>
    6eec:      	mov	x19, xzr
    6ef0:      	b	0x7b68 <generic_rawtp_filter_arg+0x1d78>
    6ef4:      	ldp	w11, w13, [x25, #0x10]
    6ef8:      	ldr	x19, [x25, #0x18]
    6efc:      	b	0x6f08 <generic_rawtp_filter_arg+0x1118>
    6f00:      	ldp	w11, w13, [x25]
    6f04:      	ldr	x19, [x25, #0x8]
    6f08:      	mov	x29, xzr
    6f0c:      	mov	x22, xzr
    6f10:      	cmp	w8, #0x11
    6f14:      	b.gt	0x6f40 <generic_rawtp_filter_arg+0x1150>
    6f18:      	sub	w9, w8, #0xd
    6f1c:      	cmp	w9, #0x2
    6f20:      	b.lo	0x6f6c <generic_rawtp_filter_arg+0x117c>
    6f24:      	ldr	x19, [sp, #0x30]
    6f28:      	sub	w9, w8, #0xf
    6f2c:      	cmp	w9, #0x2
    6f30:      	b.lo	0x7158 <generic_rawtp_filter_arg+0x1368>
    6f34:      	cmp	w8, #0x11
    6f38:      	b.eq	0x7614 <generic_rawtp_filter_arg+0x1824>
    6f3c:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    6f40:      	cmp	w8, #0x19
    6f44:      	b.hi	0x7148 <generic_rawtp_filter_arg+0x1358>
    6f48:      	lsl	w9, w12, w8
    6f4c:      	mov	w10, #0x500000          // =5242880
    6f50:      	tst	w9, w10
    6f54:      	b.ne	0x7244 <generic_rawtp_filter_arg+0x1454>
    6f58:      	mov	w10, #0xa00000          // =10485760
    6f5c:      	tst	w9, w10
    6f60:      	b.ne	0x7254 <generic_rawtp_filter_arg+0x1464>
    6f64:      	tst	w9, #0x3000000
    6f68:      	b.eq	0x7148 <generic_rawtp_filter_arg+0x1358>
    6f6c:      	ldrh	w8, [x25, #0x26]
    6f70:      	cmp	w8, #0xa
    6f74:      	b.eq	0x7294 <generic_rawtp_filter_arg+0x14a4>
    6f78:      	cmp	w8, #0x2
    6f7c:      	b.ne	0x7320 <generic_rawtp_filter_arg+0x1530>
    6f80:      	ldr	w8, [x23, #0x10]
    6f84:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0x210>
    6f88:      	add	x9, sp, #0xac
    6f8c:      	add	x1, sp, #0xac
    6f90:      	str	w8, [sp, #0xac]
    6f94:      	mov	w8, #0x1                // =1
    6f98:      	mov	w22, w11
    6f9c:      	ldr	x0, [x0]
    6fa0:      	blr	x8
    6fa4:      	ldr	x19, [sp, #0x30]
    6fa8:      	cbz	x0, 0x7c50 <generic_rawtp_filter_arg+0x1e60>
    6fac:      	mov	w8, #0x20               // =32
    6fb0:      	add	x1, sp, #0x88
    6fb4:      	stp	w8, w22, [sp, #0x88]
    6fb8:      	b	0x72dc <generic_rawtp_filter_arg+0x14ec>
    6fbc:      	cmp	w9, #0xc
    6fc0:      	b.hi	0x7c84 <generic_rawtp_filter_arg+0x1e94>
    6fc4:      	lsl	w11, w12, w9
    6fc8:      	mov	w13, #0x1402            // =5122
    6fcc:      	tst	w11, w13
    6fd0:      	b.eq	0x7c84 <generic_rawtp_filter_arg+0x1e94>
    6fd4:      	ldr	w11, [x25]
    6fd8:      	cmp	w11, w10
    6fdc:      	b.gt	0x6088 <generic_rawtp_filter_arg+0x298>
    6fe0:      	b	0x7ca0 <generic_rawtp_filter_arg+0x1eb0>
    6fe4:      	mov	x19, xzr
    6fe8:      	mov	w22, wzr
    6fec:      	add	x8, x23, #0x10
    6ff0:      	str	x8, [sp, #0x28]
    6ff4:      	ldr	x8, [sp, #0x28]
    6ff8:      	adrp	x0, 0x6000 <generic_rawtp_filter_arg+0x210>
    6ffc:      	add	x9, sp, #0x60
    7000:      	add	x1, sp, #0x60
    7004:      	ldr	w8, [x8, x19, lsl #2]
    7008:      	str	w8, [sp, #0x60]
    700c:      	mov	w8, #0x1                // =1
    7010:      	ldr	x0, [x0]
    7014:      	blr	x8
    7018:      	cbz	x0, 0x7098 <generic_rawtp_filter_arg+0x12a8>
    701c:      	cbz	w29, 0x7078 <generic_rawtp_filter_arg+0x1288>
    7020:      	mov	x8, xzr
    7024:      	mov	x9, x25
    7028:      	mov	x10, x29
    702c:      	b	0x7044 <generic_rawtp_filter_arg+0x1254>
    7030:      	add	x8, x8, #0x1
    7034:      	sub	x10, x10, #0x1
    7038:      	add	x9, x9, #0x1
    703c:      	cmp	x8, x29
    7040:      	b.eq	0x7078 <generic_rawtp_filter_arg+0x1288>
    7044:      	mov	x11, xzr
    7048:      	cmp	x10, x11
    704c:      	b.eq	0x7030 <generic_rawtp_filter_arg+0x1240>
    7050:      	ldrb	w12, [x0, x11]
    7054:      	cbz	w12, 0x7074 <generic_rawtp_filter_arg+0x1284>
    7058:      	cmp	x11, #0x62
    705c:      	b.hi	0x7030 <generic_rawtp_filter_arg+0x1240>
    7060:      	ldrb	w13, [x9, x11]
    7064:      	add	x11, x11, #0x1
    7068:      	cmp	w13, w12
    706c:      	b.eq	0x7048 <generic_rawtp_filter_arg+0x1258>
    7070:      	b	0x7030 <generic_rawtp_filter_arg+0x1240>
    7074:      	tbz	w8, #0x1f, 0x78b8 <generic_rawtp_filter_arg+0x1ac8>
    7078:      	ldr	w9, [x23, #0x8]
    707c:      	add	w8, w22, #0xc
    7080:      	cmp	w8, w9
    7084:      	b.hs	0x7098 <generic_rawtp_filter_arg+0x12a8>
    7088:      	add	x19, x19, #0x1
    708c:      	add	w22, w22, #0x4
    7090:      	cmp	x19, #0x64
    7094:      	b.ne	0x6ff4 <generic_rawtp_filter_arg+0x1204>
    7098:      	mov	x22, xzr
    709c:      	ldr	x19, [sp, #0x30]
    70a0:      	ldp	x16, x15, [sp, #0x40]
    70a4:      	mov	w2, #0x5ea0             // =24224
    70a8:      	ldr	x17, [sp, #0x38]
    70ac:      	mov	w12, #0x1               // =1
    70b0:      	ldr	w8, [x23, #0x4]
    70b4:      	cmp	w8, #0x25
    70b8:      	b.hi	0x6084 <generic_rawtp_filter_arg+0x294>
    70bc:      	mov	x9, #0x50               // =80
    70c0:      	lsl	x8, x12, x8
    70c4:      	movk	x9, #0xc00, lsl #16
    70c8:      	movk	x9, #0x20, lsl #32
    70cc:      	tst	x8, x9
    70d0:      	b.ne	0x91a8 <generic_rawtp_filter_arg+0x33b8>
    70d4:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    70d8:      	and	w8, w29, #0xffff
    70dc:      	cmp	w8, #0x90
    70e0:      	b.hi	0x768c <generic_rawtp_filter_arg+0x189c>
    70e4:      	and	w8, w29, #0xff
    70e8:      	mov	w9, #0xab               // =171
    70ec:      	tst	w29, #0xffff
    70f0:      	mul	w8, w8, w9
    70f4:      	mov	w9, #0x18               // =24
    70f8:      	lsr	w8, w8, #12
    70fc:      	msub	w8, w8, w9, w29
    7100:      	b.eq	0x7114 <generic_rawtp_filter_arg+0x1324>
    7104:      	tst	w8, #0xff
    7108:      	mov	w9, w29
    710c:      	mov	w11, w29
    7110:      	b.eq	0x7130 <generic_rawtp_filter_arg+0x1340>
    7114:      	sub	w8, w29, w8, uxtb
    7118:      	and	w9, w8, #0xffff
    711c:      	add	w8, w8, #0x18
    7120:      	and	w11, w8, #0xffff
    7124:      	cmp	w9, #0x78
    7128:      	b.hi	0x870c <generic_rawtp_filter_arg+0x291c>
    712c:      	mov	w9, w11
    7130:      	and	w8, w9, #0xff
    7134:      	mov	w9, #0xab               // =171
    7138:      	mul	w8, w8, w9
    713c:      	lsr	w8, w8, #12
    7140:      	sub	w10, w8, #0x1
    7144:      	b	0x875c <generic_rawtp_filter_arg+0x296c>
    7148:      	ldr	x19, [sp, #0x30]
    714c:      	sub	w8, w8, #0x12
    7150:      	cmp	w8, #0x2
    7154:      	b.hs	0x6084 <generic_rawtp_filter_arg+0x294>
    7158:      	ldrb	w8, [x23, #0x10]
    715c:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1210>
    7160:      	add	x9, sp, #0xac
    7164:      	add	x1, sp, #0xac
    7168:      	str	w8, [sp, #0xac]
    716c:      	mov	w8, #0x1                // =1
    7170:      	ldr	x0, [x0]
    7174:      	blr	x8
    7178:      	cbz	x0, 0x7680 <generic_rawtp_filter_arg+0x1890>
    717c:      	str	x29, [sp, #0x88]
    7180:      	mov	w8, #0x1                // =1
    7184:      	add	x9, sp, #0x88
    7188:      	add	x1, sp, #0x88
    718c:      	b	0x7648 <generic_rawtp_filter_arg+0x1858>
    7190:      	cmp	w8, #0x1
    7194:      	b.eq	0x78c0 <generic_rawtp_filter_arg+0x1ad0>
    7198:      	cmp	w8, #0x2
    719c:      	b.ne	0x78cc <generic_rawtp_filter_arg+0x1adc>
    71a0:      	ldrb	w10, [x25]
    71a4:      	cmp	w9, w10
    71a8:      	b.hi	0x6088 <generic_rawtp_filter_arg+0x298>
    71ac:      	b	0x78cc <generic_rawtp_filter_arg+0x1adc>
    71b0:      	cmp	w8, #0x1
    71b4:      	b.eq	0x7900 <generic_rawtp_filter_arg+0x1b10>
    71b8:      	cmp	w8, #0x2
    71bc:      	b.ne	0x790c <generic_rawtp_filter_arg+0x1b1c>
    71c0:      	ldrh	w10, [x25]
    71c4:      	cmp	w9, w10
    71c8:      	b.hi	0x6088 <generic_rawtp_filter_arg+0x298>
    71cc:      	b	0x790c <generic_rawtp_filter_arg+0x1b1c>
    71d0:      	ldrb	w8, [x23, #0x10]
    71d4:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1210>
    71d8:      	add	x9, sp, #0x88
    71dc:      	add	x1, sp, #0x88
    71e0:      	str	w8, [sp, #0x88]
    71e4:      	mov	w8, #0x1                // =1
    71e8:      	ldr	x0, [x0]
    71ec:      	blr	x8
    71f0:      	cbz	x0, 0x7680 <generic_rawtp_filter_arg+0x1890>
    71f4:      	ldrb	w8, [x25]
    71f8:      	add	x9, sp, #0x60
    71fc:      	str	x8, [sp, #0x60]
    7200:      	mov	w8, #0x1                // =1
    7204:      	b	0x723c <generic_rawtp_filter_arg+0x144c>
    7208:      	ldrb	w8, [x23, #0x10]
    720c:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1210>
    7210:      	add	x9, sp, #0x88
    7214:      	add	x1, sp, #0x88
    7218:      	str	w8, [sp, #0x88]
    721c:      	mov	w8, #0x1                // =1
    7220:      	ldr	x0, [x0]
    7224:      	blr	x8
    7228:      	cbz	x0, 0x7680 <generic_rawtp_filter_arg+0x1890>
    722c:      	ldrh	w8, [x25]
    7230:      	add	x9, sp, #0x60
    7234:      	str	x8, [sp, #0x60]
    7238:      	mov	w8, #0x1                // =1
    723c:      	add	x1, sp, #0x60
    7240:      	b	0x7648 <generic_rawtp_filter_arg+0x1858>
    7244:      	ldr	x19, [sp, #0x30]
    7248:      	cmp	x29, #0x400
    724c:      	cset	w22, lo
    7250:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    7254:      	ldr	x19, [sp, #0x30]
    7258:      	cmp	x29, #0x3ff
    725c:      	cset	w22, hi
    7260:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    7264:      	ldp	x16, x15, [sp, #0x40]
    7268:      	cmp	x0, #0x0
    726c:      	mov	w2, #0x5ea0             // =24224
    7270:      	mov	w12, #0x1               // =1
    7274:      	cset	w8, eq
    7278:      	ldr	x17, [sp, #0x38]
    727c:      	mov	w22, w8
    7280:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    7284:      	cmp	w8, #0x101
    7288:      	b.hs	0x789c <generic_rawtp_filter_arg+0x1aac>
    728c:      	mov	w11, #0x100             // =256
    7290:      	b	0x8240 <generic_rawtp_filter_arg+0x2450>
    7294:      	ldr	w8, [x23, #0x14]
    7298:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1210>
    729c:      	add	x9, sp, #0xac
    72a0:      	add	x1, sp, #0xac
    72a4:      	str	w8, [sp, #0xac]
    72a8:      	mov	w8, #0x1                // =1
    72ac:      	mov	w25, w13
    72b0:      	mov	w22, w11
    72b4:      	ldr	x0, [x0]
    72b8:      	blr	x8
    72bc:      	cbz	x0, 0x7c58 <generic_rawtp_filter_arg+0x1e68>
    72c0:      	mov	w8, #0x80               // =128
    72c4:      	stp	w25, w19, [sp, #0x90]
    72c8:      	add	x1, sp, #0x88
    72cc:      	stp	w8, w22, [sp, #0x88]
    72d0:      	lsr	x8, x19, #32
    72d4:      	ldr	x19, [sp, #0x30]
    72d8:      	str	w8, [sp, #0x98]
    72dc:      	mov	w8, #0x1                // =1
    72e0:      	blr	x8
    72e4:      	ldr	w8, [x23, #0x4]
    72e8:      	sub	w9, w8, #0x18
    72ec:      	cmp	w9, #0x2
    72f0:      	b.lo	0x78b0 <generic_rawtp_filter_arg+0x1ac0>
    72f4:      	sub	w8, w8, #0xd
    72f8:      	mov	w12, #0x1               // =1
    72fc:      	cmp	w8, #0x1
    7300:      	b.hi	0x68c0 <generic_rawtp_filter_arg+0xad0>
    7304:      	cmp	x0, #0x0
    7308:      	cset	w8, ne
    730c:      	ldp	x16, x15, [sp, #0x40]
    7310:      	mov	w2, #0x5ea0             // =24224
    7314:      	mov	w22, w8
    7318:      	ldr	x17, [sp, #0x38]
    731c:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    7320:      	ldr	x19, [sp, #0x30]
    7324:      	mov	w8, wzr
    7328:      	mov	w22, wzr
    732c:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    7330:      	cmp	w8, #0x1e
    7334:      	b.ne	0x5eec <generic_rawtp_filter_arg+0xfc>
    7338:      	ldr	w8, [x23, #0x10]
    733c:      	and	x8, x8, #0x7
    7340:      	add	x9, x20, x8, lsl #2
    7344:      	ldr	w9, [x9, x2]
    7348:      	cbnz	w9, 0x5eec <generic_rawtp_filter_arg+0xfc>
    734c:      	add	x8, x20, x8, lsl #3
    7350:      	ldr	x9, [x25]
    7354:      	ldr	x8, [x8, #0x5e78]
    7358:      	and	x8, x8, #0x7ff
    735c:      	add	x8, x20, x8
    7360:      	ldr	x8, [x8, #0x90]
    7364:      	bics	xzr, x8, x9
    7368:      	cset	w22, ne
    736c:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    7370:      	cmp	w8, #0x21
    7374:      	b.eq	0x79e4 <generic_rawtp_filter_arg+0x1bf4>
    7378:      	cmp	w8, #0x22
    737c:      	b.ne	0x9174 <generic_rawtp_filter_arg+0x3384>
    7380:      	mov	w19, #0x10              // =16
    7384:      	ldr	w8, [x23, x19]
    7388:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1210>
    738c:      	add	x9, sp, #0x60
    7390:      	add	x1, sp, #0x60
    7394:      	str	w8, [sp, #0x60]
    7398:      	mov	w8, #0x1                // =1
    739c:      	ldr	x0, [x0]
    73a0:      	blr	x8
    73a4:      	cbz	x0, 0x916c <generic_rawtp_filter_arg+0x337c>
    73a8:      	mov	x1, x0
    73ac:      	mov	x0, x29
    73b0:      	mov	x2, x25
    73b4:      	bl	0x73b4 <generic_rawtp_filter_arg+0x15c4>
    73b8:      	tbz	w0, #0x1f, 0x81c4 <generic_rawtp_filter_arg+0x23d4>
    73bc:      	ldr	w8, [x23, #0x8]
    73c0:      	add	x19, x19, #0x4
    73c4:      	mov	w12, #0x1               // =1
    73c8:      	mov	x22, xzr
    73cc:      	sub	w9, w19, #0x8
    73d0:      	cmp	w9, w8
    73d4:      	b.hs	0x9174 <generic_rawtp_filter_arg+0x3384>
    73d8:      	cmp	x19, #0x1a0
    73dc:      	b.ne	0x7384 <generic_rawtp_filter_arg+0x1594>
    73e0:      	b	0x9174 <generic_rawtp_filter_arg+0x3384>
    73e4:      	mov	x25, x10
    73e8:      	cmp	w8, #0x8
    73ec:      	b.ne	0x5eec <generic_rawtp_filter_arg+0xfc>
    73f0:      	ldr	w8, [x23, #0x10]
    73f4:      	str	wzr, [sp, #0x88]
    73f8:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1210>
    73fc:      	add	x9, sp, #0x60
    7400:      	add	x1, sp, #0x60
    7404:      	str	w8, [sp, #0x60]
    7408:      	mov	w8, #0x1                // =1
    740c:      	ldr	x0, [x0]
    7410:      	blr	x8
    7414:      	mov	x22, xzr
    7418:      	cbz	w29, 0x7d84 <generic_rawtp_filter_arg+0x1f94>
    741c:      	cbz	x0, 0x7d84 <generic_rawtp_filter_arg+0x1f94>
    7420:      	mov	x19, x0
    7424:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1210>
    7428:      	mov	w8, #0x1                // =1
    742c:      	ldr	x0, [x0]
    7430:      	add	x9, sp, #0x88
    7434:      	add	x1, sp, #0x88
    7438:      	blr	x8
    743c:      	cbz	x0, 0x7d7c <generic_rawtp_filter_arg+0x1f8c>
    7440:      	lsl	w9, w29, #3
    7444:      	mov	x8, x0
    7448:      	mov	x2, x25
    744c:      	mov	w1, w29
    7450:      	str	w9, [x8], #0x4
    7454:      	mov	w9, #0x4                // =4
    7458:      	mov	x25, x0
    745c:      	mov	x0, x8
    7460:      	blr	x9
    7464:      	mov	w8, #0x1                // =1
    7468:      	mov	x0, x19
    746c:      	mov	x1, x25
    7470:      	blr	x8
    7474:      	cmp	x0, #0x0
    7478:      	cset	w22, ne
    747c:      	b	0x7d80 <generic_rawtp_filter_arg+0x1f90>
    7480:      	mov	w13, #0x100             // =256
    7484:      	sub	w8, w13, #0x100
    7488:      	ror	w8, w8, #0x8
    748c:      	cmp	w8, #0x2
    7490:      	b.gt	0x7884 <generic_rawtp_filter_arg+0x1a94>
    7494:      	cbz	w8, 0x7e6c <generic_rawtp_filter_arg+0x207c>
    7498:      	cmp	w8, #0x1
    749c:      	b.ne	0x7e64 <generic_rawtp_filter_arg+0x2074>
    74a0:      	mov	w11, #0x7               // =7
    74a4:      	b	0x7e78 <generic_rawtp_filter_arg+0x2088>
    74a8:      	ldrb	w8, [x23, #0x10]
    74ac:      	ldrh	w19, [x25]
    74b0:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1210>
    74b4:      	add	x9, sp, #0x88
    74b8:      	add	x1, sp, #0x88
    74bc:      	str	w8, [sp, #0x88]
    74c0:      	mov	w8, #0x1                // =1
    74c4:      	ldr	x0, [x0]
    74c8:      	blr	x8
    74cc:      	cbz	x0, 0x7bf8 <generic_rawtp_filter_arg+0x1e08>
    74d0:      	str	x19, [sp, #0x60]
    74d4:      	mov	w8, #0x1                // =1
    74d8:      	add	x9, sp, #0x60
    74dc:      	add	x1, sp, #0x60
    74e0:      	b	0x7b9c <generic_rawtp_filter_arg+0x1dac>
    74e4:      	ldr	w8, [x23, #0x10]
    74e8:      	str	wzr, [sp, #0x88]
    74ec:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1210>
    74f0:      	add	x9, sp, #0x60
    74f4:      	add	x1, sp, #0x60
    74f8:      	str	w8, [sp, #0x60]
    74fc:      	mov	w8, #0x1                // =1
    7500:      	ldr	x0, [x0]
    7504:      	blr	x8
    7508:      	mov	x22, xzr
    750c:      	cbz	w25, 0x9170 <generic_rawtp_filter_arg+0x3380>
    7510:      	cbz	x0, 0x9170 <generic_rawtp_filter_arg+0x3380>
    7514:      	mov	x19, x0
    7518:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1210>
    751c:      	mov	w8, #0x1                // =1
    7520:      	ldr	x0, [x0]
    7524:      	add	x9, sp, #0x88
    7528:      	add	x1, sp, #0x88
    752c:      	blr	x8
    7530:      	cbz	x0, 0x916c <generic_rawtp_filter_arg+0x337c>
    7534:      	cmp	w25, #0xff
    7538:      	mov	w8, #0xff               // =255
    753c:      	mov	x22, x0
    7540:      	mov	x2, x29
    7544:      	csel	w1, w25, w8, lo
    7548:      	mov	x8, x0
    754c:      	lsl	w9, w1, #3
    7550:      	str	w9, [x8], #0x4
    7554:      	mov	w9, #0x4                // =4
    7558:      	mov	x0, x8
    755c:      	blr	x9
    7560:      	mov	w8, #0x1                // =1
    7564:      	mov	x0, x19
    7568:      	mov	x1, x22
    756c:      	b	0x915c <generic_rawtp_filter_arg+0x336c>
    7570:      	cmp	w25, #0x1, lsl #12      // =0x1000
    7574:      	str	wzr, [sp, #0x88]
    7578:      	b.ls	0x7a98 <generic_rawtp_filter_arg+0x1ca8>
    757c:      	mov	x22, xzr
    7580:      	b	0x9174 <generic_rawtp_filter_arg+0x3384>
    7584:      	ldr	x8, [x25]
    7588:      	cmp	x11, x8
    758c:      	b.hi	0x7598 <generic_rawtp_filter_arg+0x17a8>
    7590:      	cmp	x8, x10
    7594:      	b.ls	0x6088 <generic_rawtp_filter_arg+0x298>
    7598:      	ldr	w10, [x23, #0x8]
    759c:      	cmp	w10, #0x19
    75a0:      	b.lo	0x5eec <generic_rawtp_filter_arg+0xfc>
    75a4:      	ldp	x12, x11, [x23, #0x20]
    75a8:      	cmp	w9, #0xc
    75ac:      	b.eq	0x75b8 <generic_rawtp_filter_arg+0x17c8>
    75b0:      	cmp	w9, #0xa
    75b4:      	b.ne	0x7c08 <generic_rawtp_filter_arg+0x1e18>
    75b8:      	cmp	x12, x8
    75bc:      	mov	w12, #0x1               // =1
    75c0:      	b.gt	0x7c1c <generic_rawtp_filter_arg+0x1e2c>
    75c4:      	cmp	x8, x11
    75c8:      	b.le	0x6088 <generic_rawtp_filter_arg+0x298>
    75cc:      	b	0x7c1c <generic_rawtp_filter_arg+0x1e2c>
    75d0:      	ldr	x10, [x25]
    75d4:      	cmp	x11, x10
    75d8:      	ccmp	x10, x8, #0x2, ls
    75dc:      	cset	w8, ls
    75e0:      	ldr	w11, [x23, #0x8]
    75e4:      	cmp	w11, #0x19
    75e8:      	b.lo	0x8678 <generic_rawtp_filter_arg+0x2888>
    75ec:      	ldp	x13, x12, [x23, #0x20]
    75f0:      	cmp	w9, #0xc
    75f4:      	b.eq	0x7600 <generic_rawtp_filter_arg+0x1810>
    75f8:      	cmp	w9, #0xa
    75fc:      	b.ne	0x7b08 <generic_rawtp_filter_arg+0x1d18>
    7600:      	cmp	x13, x10
    7604:      	ccmp	x10, x12, #0x0, le
    7608:      	cset	w12, le
    760c:      	b	0x7b14 <generic_rawtp_filter_arg+0x1d24>
    7610:      	ldrh	w22, [x25, #0x26]
    7614:      	ldrb	w8, [x23, #0x10]
    7618:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1210>
    761c:      	add	x9, sp, #0xac
    7620:      	add	x1, sp, #0xac
    7624:      	str	w8, [sp, #0xac]
    7628:      	mov	w8, #0x1                // =1
    762c:      	ldr	x0, [x0]
    7630:      	blr	x8
    7634:      	cbz	x0, 0x7680 <generic_rawtp_filter_arg+0x1890>
    7638:      	str	x22, [sp, #0x88]
    763c:      	mov	w8, #0x1                // =1
    7640:      	add	x9, sp, #0x88
    7644:      	add	x1, sp, #0x88
    7648:      	blr	x8
    764c:      	ldr	w9, [x23, #0x4]
    7650:      	mov	w8, wzr
    7654:      	mov	w12, #0x1               // =1
    7658:      	cmp	w9, #0x1d
    765c:      	b.hi	0x7be4 <generic_rawtp_filter_arg+0x1df4>
    7660:      	mov	w10, #0x8400            // =33792
    7664:      	lsl	w9, w12, w9
    7668:      	movk	w10, #0x3003, lsl #16
    766c:      	tst	w9, w10
    7670:      	b.eq	0x7bcc <generic_rawtp_filter_arg+0x1ddc>
    7674:      	cmp	x0, #0x0
    7678:      	cset	w8, ne
    767c:      	b	0x7be4 <generic_rawtp_filter_arg+0x1df4>
    7680:      	mov	x22, xzr
    7684:      	mov	w12, #0x1               // =1
    7688:      	b	0x7be8 <generic_rawtp_filter_arg+0x1df8>
    768c:      	cmp	w8, #0x101
    7690:      	b.hs	0x7d68 <generic_rawtp_filter_arg+0x1f78>
    7694:      	mov	w11, #0x100             // =256
    7698:      	b	0x870c <generic_rawtp_filter_arg+0x291c>
    769c:      	ldr	x11, [x25]
    76a0:      	cmp	x11, x10
    76a4:      	b.hi	0x6088 <generic_rawtp_filter_arg+0x298>
    76a8:      	b	0x76b8 <generic_rawtp_filter_arg+0x18c8>
    76ac:      	ldr	x11, [x25]
    76b0:      	cmp	x11, x10
    76b4:      	b.lo	0x6088 <generic_rawtp_filter_arg+0x298>
    76b8:      	ldr	w10, [x23, #0x8]
    76bc:      	cmp	w10, #0x11
    76c0:      	b.lo	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    76c4:      	ldr	x11, [x23, #0x18]
    76c8:      	cmp	w8, #0x2
    76cc:      	b.le	0x76f0 <generic_rawtp_filter_arg+0x1900>
    76d0:      	sub	w12, w8, #0x3
    76d4:      	cmp	w12, #0x2
    76d8:      	b.hs	0x7724 <generic_rawtp_filter_arg+0x1934>
    76dc:      	ldr	x12, [x25]
    76e0:      	cmp	x12, x11
    76e4:      	mov	w12, #0x1               // =1
    76e8:      	b.eq	0x607c <generic_rawtp_filter_arg+0x28c>
    76ec:      	b	0x810c <generic_rawtp_filter_arg+0x231c>
    76f0:      	cmp	w8, #0x1
    76f4:      	b.eq	0x77d0 <generic_rawtp_filter_arg+0x19e0>
    76f8:      	cmp	w8, #0x2
    76fc:      	b.ne	0x810c <generic_rawtp_filter_arg+0x231c>
    7700:      	cmp	w9, #0xc
    7704:      	b.eq	0x7710 <generic_rawtp_filter_arg+0x1920>
    7708:      	cmp	w9, #0xa
    770c:      	b.ne	0x80fc <generic_rawtp_filter_arg+0x230c>
    7710:      	ldr	x12, [x25]
    7714:      	cmp	x12, x11
    7718:      	mov	w12, #0x1               // =1
    771c:      	b.lt	0x6088 <generic_rawtp_filter_arg+0x298>
    7720:      	b	0x810c <generic_rawtp_filter_arg+0x231c>
    7724:      	cmp	w8, #0xc
    7728:      	mov	w12, #0x1               // =1
    772c:      	b.ne	0x810c <generic_rawtp_filter_arg+0x231c>
    7730:      	ldr	x12, [x25]
    7734:      	tst	x12, x11
    7738:      	mov	w12, #0x1               // =1
    773c:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    7740:      	b	0x810c <generic_rawtp_filter_arg+0x231c>
    7744:      	cmp	w8, #0xc
    7748:      	b.ne	0x78cc <generic_rawtp_filter_arg+0x1adc>
    774c:      	ldrb	w10, [x25]
    7750:      	tst	w9, w10
    7754:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    7758:      	b	0x78cc <generic_rawtp_filter_arg+0x1adc>
    775c:      	cmp	w8, #0xc
    7760:      	b.ne	0x790c <generic_rawtp_filter_arg+0x1b1c>
    7764:      	ldrh	w10, [x25]
    7768:      	tst	w9, w10
    776c:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    7770:      	b	0x790c <generic_rawtp_filter_arg+0x1b1c>
    7774:      	ldr	w9, [x23, #0x8]
    7778:      	cmp	w9, #0xd
    777c:      	b.lo	0x65ac <generic_rawtp_filter_arg+0x7bc>
    7780:      	ldr	w10, [x23, #0x14]
    7784:      	cbz	w10, 0x65ac <generic_rawtp_filter_arg+0x7bc>
    7788:      	cmp	w10, w8
    778c:      	b.eq	0x63f0 <generic_rawtp_filter_arg+0x600>
    7790:      	cmp	w9, #0x11
    7794:      	b.lo	0x65ac <generic_rawtp_filter_arg+0x7bc>
    7798:      	ldr	w10, [x23, #0x18]
    779c:      	cbz	w10, 0x65ac <generic_rawtp_filter_arg+0x7bc>
    77a0:      	cmp	w10, w8
    77a4:      	b.eq	0x63f0 <generic_rawtp_filter_arg+0x600>
    77a8:      	cmp	w9, #0x15
    77ac:      	b.lo	0x77c4 <generic_rawtp_filter_arg+0x19d4>
    77b0:      	ldr	w9, [x23, #0x1c]
    77b4:      	cbz	w9, 0x77c4 <generic_rawtp_filter_arg+0x19d4>
    77b8:      	cmp	w9, w8
    77bc:      	cset	w22, eq
    77c0:      	b	0x77c8 <generic_rawtp_filter_arg+0x19d8>
    77c4:      	mov	x22, xzr
    77c8:      	ldr	x19, [sp, #0x30]
    77cc:      	b	0x8bd4 <generic_rawtp_filter_arg+0x2de4>
    77d0:      	cmp	w9, #0xc
    77d4:      	b.eq	0x77e0 <generic_rawtp_filter_arg+0x19f0>
    77d8:      	cmp	w9, #0xa
    77dc:      	b.ne	0x80e8 <generic_rawtp_filter_arg+0x22f8>
    77e0:      	ldr	x12, [x25]
    77e4:      	cmp	x12, x11
    77e8:      	mov	w12, #0x1               // =1
    77ec:      	b.gt	0x6088 <generic_rawtp_filter_arg+0x298>
    77f0:      	b	0x810c <generic_rawtp_filter_arg+0x231c>
    77f4:      	ldp	w8, w11, [x23, #0x10]
    77f8:      	ldrb	w9, [x25]
    77fc:      	cmp	w8, w9
    7800:      	ldr	w10, [x23, #0x8]
    7804:      	ccmp	w11, w9, #0x0, ls
    7808:      	cset	w8, hs
    780c:      	cmp	w10, #0x11
    7810:      	b.lo	0x894c <generic_rawtp_filter_arg+0x2b5c>
    7814:      	b	0x7838 <generic_rawtp_filter_arg+0x1a48>
    7818:      	ldp	w8, w11, [x23, #0x10]
    781c:      	ldrh	w9, [x25]
    7820:      	cmp	w8, w9
    7824:      	ldr	w10, [x23, #0x8]
    7828:      	ccmp	w11, w9, #0x0, ls
    782c:      	cset	w8, hs
    7830:      	cmp	w10, #0x11
    7834:      	b.lo	0x894c <generic_rawtp_filter_arg+0x2b5c>
    7838:      	ldp	w11, w12, [x23, #0x18]
    783c:      	cmp	w11, w9
    7840:      	ccmp	w12, w9, #0x0, ls
    7844:      	mov	w12, #0x1               // =1
    7848:      	csinc	w8, w8, wzr, lo
    784c:      	cmp	w10, #0x19
    7850:      	b.lo	0x894c <generic_rawtp_filter_arg+0x2b5c>
    7854:      	ldp	w11, w12, [x23, #0x20]
    7858:      	cmp	w11, w9
    785c:      	ccmp	w12, w9, #0x0, ls
    7860:      	mov	w12, #0x1               // =1
    7864:      	csinc	w8, w8, wzr, lo
    7868:      	cmp	w10, #0x21
    786c:      	b.lo	0x894c <generic_rawtp_filter_arg+0x2b5c>
    7870:      	ldp	w10, w11, [x23, #0x28]
    7874:      	cmp	w10, w9
    7878:      	ccmp	w11, w9, #0x0, ls
    787c:      	csinc	w8, w8, wzr, lo
    7880:      	b	0x894c <generic_rawtp_filter_arg+0x2b5c>
    7884:      	cmp	w8, #0x3
    7888:      	b.eq	0x7e74 <generic_rawtp_filter_arg+0x2084>
    788c:      	cmp	w8, #0x7
    7890:      	b.ne	0x7e64 <generic_rawtp_filter_arg+0x2074>
    7894:      	mov	w11, #0x9               // =9
    7898:      	b	0x7e78 <generic_rawtp_filter_arg+0x2088>
    789c:      	and	w8, w29, #0xffff
    78a0:      	cmp	w8, #0x201
    78a4:      	b.hs	0x7dfc <generic_rawtp_filter_arg+0x200c>
    78a8:      	mov	w11, #0x200             // =512
    78ac:      	b	0x8240 <generic_rawtp_filter_arg+0x2450>
    78b0:      	cmp	x0, #0x0
    78b4:      	b	0x7c68 <generic_rawtp_filter_arg+0x1e78>
    78b8:      	mov	w22, #0x1               // =1
    78bc:      	b	0x709c <generic_rawtp_filter_arg+0x12ac>
    78c0:      	ldrb	w10, [x25]
    78c4:      	cmp	w9, w10
    78c8:      	b.lo	0x6088 <generic_rawtp_filter_arg+0x298>
    78cc:      	ldr	w9, [x23, #0x8]
    78d0:      	cmp	w9, #0xd
    78d4:      	b.lo	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    78d8:      	ldr	w10, [x23, #0x14]
    78dc:      	cmp	w8, #0x2
    78e0:      	b.le	0x7dbc <generic_rawtp_filter_arg+0x1fcc>
    78e4:      	sub	w11, w8, #0x3
    78e8:      	cmp	w11, #0x2
    78ec:      	b.hs	0x8194 <generic_rawtp_filter_arg+0x23a4>
    78f0:      	ldrb	w11, [x25]
    78f4:      	cmp	w10, w11
    78f8:      	b.eq	0x607c <generic_rawtp_filter_arg+0x28c>
    78fc:      	b	0x8448 <generic_rawtp_filter_arg+0x2658>
    7900:      	ldrh	w10, [x25]
    7904:      	cmp	w9, w10
    7908:      	b.lo	0x6088 <generic_rawtp_filter_arg+0x298>
    790c:      	ldr	w9, [x23, #0x8]
    7910:      	cmp	w9, #0xd
    7914:      	b.lo	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    7918:      	ldr	w10, [x23, #0x14]
    791c:      	cmp	w8, #0x2
    7920:      	b.le	0x7ddc <generic_rawtp_filter_arg+0x1fec>
    7924:      	sub	w11, w8, #0x3
    7928:      	cmp	w11, #0x2
    792c:      	b.hs	0x81ac <generic_rawtp_filter_arg+0x23bc>
    7930:      	ldrh	w11, [x25]
    7934:      	cmp	w10, w11
    7938:      	b.eq	0x607c <generic_rawtp_filter_arg+0x28c>
    793c:      	b	0x8484 <generic_rawtp_filter_arg+0x2694>
    7940:      	ldr	w8, [x25]
    7944:      	cmp	w11, w8
    7948:      	b.hi	0x7954 <generic_rawtp_filter_arg+0x1b64>
    794c:      	cmp	w8, w10
    7950:      	b.ls	0x6088 <generic_rawtp_filter_arg+0x298>
    7954:      	ldr	w10, [x23, #0x8]
    7958:      	cmp	w10, #0x11
    795c:      	b.lo	0x5eec <generic_rawtp_filter_arg+0xfc>
    7960:      	ldp	w12, w11, [x23, #0x18]
    7964:      	mov	w13, #0x1               // =1
    7968:      	cmp	w9, #0xc
    796c:      	b.hi	0x8004 <generic_rawtp_filter_arg+0x2214>
    7970:      	lsl	w13, w13, w9
    7974:      	mov	w14, #0x1402            // =5122
    7978:      	tst	w13, w14
    797c:      	b.eq	0x8004 <generic_rawtp_filter_arg+0x2214>
    7980:      	cmp	w12, w8
    7984:      	mov	w12, #0x1               // =1
    7988:      	b.gt	0x8018 <generic_rawtp_filter_arg+0x2228>
    798c:      	cmp	w8, w11
    7990:      	b.le	0x6088 <generic_rawtp_filter_arg+0x298>
    7994:      	b	0x8018 <generic_rawtp_filter_arg+0x2228>
    7998:      	ldr	w10, [x25]
    799c:      	cmp	w11, w10
    79a0:      	ccmp	w10, w8, #0x2, ls
    79a4:      	cset	w8, ls
    79a8:      	ldr	w11, [x23, #0x8]
    79ac:      	cmp	w11, #0x11
    79b0:      	b.lo	0x894c <generic_rawtp_filter_arg+0x2b5c>
    79b4:      	ldp	w13, w12, [x23, #0x18]
    79b8:      	mov	w14, #0x1               // =1
    79bc:      	cmp	w9, #0xc
    79c0:      	b.hi	0x7e0c <generic_rawtp_filter_arg+0x201c>
    79c4:      	lsl	w14, w14, w9
    79c8:      	mov	w1, #0x1402             // =5122
    79cc:      	tst	w14, w1
    79d0:      	b.eq	0x7e0c <generic_rawtp_filter_arg+0x201c>
    79d4:      	cmp	w13, w10
    79d8:      	ccmp	w10, w12, #0x0, le
    79dc:      	cset	w12, le
    79e0:      	b	0x7e18 <generic_rawtp_filter_arg+0x2028>
    79e4:      	str	x29, [sp, #0x28]
    79e8:      	mov	x19, xzr
    79ec:      	mov	w22, wzr
    79f0:      	add	x29, x23, #0x10
    79f4:      	ldr	w8, [x29, x19, lsl #2]
    79f8:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1210>
    79fc:      	add	x9, sp, #0x60
    7a00:      	add	x1, sp, #0x60
    7a04:      	str	w8, [sp, #0x60]
    7a08:      	mov	w8, #0x1                // =1
    7a0c:      	ldr	x0, [x0]
    7a10:      	blr	x8
    7a14:      	cbz	x0, 0x916c <generic_rawtp_filter_arg+0x337c>
    7a18:      	cbz	w25, 0x7a74 <generic_rawtp_filter_arg+0x1c84>
    7a1c:      	ldr	x9, [sp, #0x28]
    7a20:      	mov	x8, xzr
    7a24:      	mov	x10, x25
    7a28:      	b	0x7a40 <generic_rawtp_filter_arg+0x1c50>
    7a2c:      	add	x8, x8, #0x1
    7a30:      	sub	x10, x10, #0x1
    7a34:      	add	x9, x9, #0x1
    7a38:      	cmp	x8, x25
    7a3c:      	b.eq	0x7a74 <generic_rawtp_filter_arg+0x1c84>
    7a40:      	mov	x11, xzr
    7a44:      	cmp	x10, x11
    7a48:      	b.eq	0x7a2c <generic_rawtp_filter_arg+0x1c3c>
    7a4c:      	ldrb	w12, [x0, x11]
    7a50:      	cbz	w12, 0x7a70 <generic_rawtp_filter_arg+0x1c80>
    7a54:      	cmp	x11, #0x62
    7a58:      	b.hi	0x7a2c <generic_rawtp_filter_arg+0x1c3c>
    7a5c:      	ldrb	w13, [x9, x11]
    7a60:      	add	x11, x11, #0x1
    7a64:      	cmp	w13, w12
    7a68:      	b.eq	0x7a44 <generic_rawtp_filter_arg+0x1c54>
    7a6c:      	b	0x7a2c <generic_rawtp_filter_arg+0x1c3c>
    7a70:      	tbz	w8, #0x1f, 0x81c4 <generic_rawtp_filter_arg+0x23d4>
    7a74:      	ldr	w9, [x23, #0x8]
    7a78:      	add	w8, w22, #0xc
    7a7c:      	cmp	w8, w9
    7a80:      	b.hs	0x916c <generic_rawtp_filter_arg+0x337c>
    7a84:      	add	x19, x19, #0x1
    7a88:      	add	w22, w22, #0x4
    7a8c:      	cmp	x19, #0x64
    7a90:      	b.ne	0x79f4 <generic_rawtp_filter_arg+0x1c04>
    7a94:      	b	0x916c <generic_rawtp_filter_arg+0x337c>
    7a98:      	and	w8, w25, #0xffff
    7a9c:      	cmp	w8, #0x90
    7aa0:      	b.hi	0x8058 <generic_rawtp_filter_arg+0x2268>
    7aa4:      	and	w8, w25, #0xff
    7aa8:      	mov	w9, #0xab               // =171
    7aac:      	tst	w25, #0xffff
    7ab0:      	mul	w8, w8, w9
    7ab4:      	mov	w9, #0x18               // =24
    7ab8:      	lsr	w8, w8, #12
    7abc:      	msub	w8, w8, w9, w25
    7ac0:      	b.eq	0x7ad4 <generic_rawtp_filter_arg+0x1ce4>
    7ac4:      	tst	w8, #0xff
    7ac8:      	mov	w9, w25
    7acc:      	mov	w11, w25
    7ad0:      	b.eq	0x7af0 <generic_rawtp_filter_arg+0x1d00>
    7ad4:      	sub	w8, w25, w8, uxtb
    7ad8:      	and	w9, w8, #0xffff
    7adc:      	add	w8, w8, #0x18
    7ae0:      	and	w11, w8, #0xffff
    7ae4:      	cmp	w9, #0x78
    7ae8:      	b.hi	0x8e60 <generic_rawtp_filter_arg+0x3070>
    7aec:      	mov	w9, w11
    7af0:      	and	w8, w9, #0xff
    7af4:      	mov	w9, #0xab               // =171
    7af8:      	mul	w8, w8, w9
    7afc:      	lsr	w8, w8, #12
    7b00:      	sub	w10, w8, #0x1
    7b04:      	b	0x8eb0 <generic_rawtp_filter_arg+0x30c0>
    7b08:      	cmp	x13, x10
    7b0c:      	ccmp	x10, x12, #0x2, ls
    7b10:      	cset	w12, ls
    7b14:      	orr	w8, w8, w12
    7b18:      	cmp	w11, #0x29
    7b1c:      	b.lo	0x8678 <generic_rawtp_filter_arg+0x2888>
    7b20:      	ldp	x13, x12, [x23, #0x30]
    7b24:      	cmp	w9, #0xc
    7b28:      	b.eq	0x7b34 <generic_rawtp_filter_arg+0x1d44>
    7b2c:      	cmp	w9, #0xa
    7b30:      	b.ne	0x8068 <generic_rawtp_filter_arg+0x2278>
    7b34:      	cmp	x13, x10
    7b38:      	ccmp	x10, x12, #0x0, le
    7b3c:      	cset	w12, le
    7b40:      	b	0x8074 <generic_rawtp_filter_arg+0x2284>
    7b44:      	mov	x19, xzr
    7b48:      	cmp	w9, #0x29
    7b4c:      	b.ne	0x7b58 <generic_rawtp_filter_arg+0x1d68>
    7b50:      	cbz	x10, 0x7b58 <generic_rawtp_filter_arg+0x1d68>
    7b54:      	ldrb	w19, [x10, #0x3a]
    7b58:      	cmp	w9, #0x29
    7b5c:      	b.eq	0x7b68 <generic_rawtp_filter_arg+0x1d78>
    7b60:      	cmp	w9, #0x7
    7b64:      	b.ne	0x7e58 <generic_rawtp_filter_arg+0x2068>
    7b68:      	ldrb	w8, [x23, #0x10]
    7b6c:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1210>
    7b70:      	add	x9, sp, #0xac
    7b74:      	add	x1, sp, #0xac
    7b78:      	str	w8, [sp, #0xac]
    7b7c:      	mov	w8, #0x1                // =1
    7b80:      	ldr	x0, [x0]
    7b84:      	blr	x8
    7b88:      	cbz	x0, 0x7bf8 <generic_rawtp_filter_arg+0x1e08>
    7b8c:      	str	x19, [sp, #0x88]
    7b90:      	mov	w8, #0x1                // =1
    7b94:      	add	x9, sp, #0x88
    7b98:      	add	x1, sp, #0x88
    7b9c:      	blr	x8
    7ba0:      	ldr	w9, [x23, #0x4]
    7ba4:      	mov	w8, wzr
    7ba8:      	cmp	w9, #0x1d
    7bac:      	b.hi	0x8b18 <generic_rawtp_filter_arg+0x2d28>
    7bb0:      	ldr	x19, [sp, #0x30]
    7bb4:      	mov	w12, #0x1               // =1
    7bb8:      	mov	w10, #0x8400            // =33792
    7bbc:      	lsl	w9, w12, w9
    7bc0:      	movk	w10, #0x3003, lsl #16
    7bc4:      	tst	w9, w10
    7bc8:      	b.ne	0x7674 <generic_rawtp_filter_arg+0x1884>
    7bcc:      	mov	w10, #0x800             // =2048
    7bd0:      	movk	w10, #0xc, lsl #16
    7bd4:      	tst	w9, w10
    7bd8:      	b.eq	0x7be4 <generic_rawtp_filter_arg+0x1df4>
    7bdc:      	cmp	x0, #0x0
    7be0:      	cset	w8, eq
    7be4:      	mov	w22, w8
    7be8:      	ldp	x16, x15, [sp, #0x40]
    7bec:      	mov	w2, #0x5ea0             // =24224
    7bf0:      	ldr	x17, [sp, #0x38]
    7bf4:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    7bf8:      	ldr	x19, [sp, #0x30]
    7bfc:      	mov	x22, xzr
    7c00:      	mov	w12, #0x1               // =1
    7c04:      	b	0x7be8 <generic_rawtp_filter_arg+0x1df8>
    7c08:      	cmp	x12, x8
    7c0c:      	mov	w12, #0x1               // =1
    7c10:      	b.hi	0x7c1c <generic_rawtp_filter_arg+0x1e2c>
    7c14:      	cmp	x8, x11
    7c18:      	b.ls	0x6088 <generic_rawtp_filter_arg+0x298>
    7c1c:      	cmp	w10, #0x29
    7c20:      	b.lo	0x5eec <generic_rawtp_filter_arg+0xfc>
    7c24:      	ldp	x12, x11, [x23, #0x30]
    7c28:      	cmp	w9, #0xc
    7c2c:      	b.eq	0x7c38 <generic_rawtp_filter_arg+0x1e48>
    7c30:      	cmp	w9, #0xa
    7c34:      	b.ne	0x80a4 <generic_rawtp_filter_arg+0x22b4>
    7c38:      	cmp	x12, x8
    7c3c:      	mov	w12, #0x1               // =1
    7c40:      	b.gt	0x80b8 <generic_rawtp_filter_arg+0x22c8>
    7c44:      	cmp	x8, x11
    7c48:      	b.le	0x6088 <generic_rawtp_filter_arg+0x298>
    7c4c:      	b	0x80b8 <generic_rawtp_filter_arg+0x22c8>
    7c50:      	ldr	w8, [x23, #0x4]
    7c54:      	b	0x7c60 <generic_rawtp_filter_arg+0x1e70>
    7c58:      	ldr	w8, [x23, #0x4]
    7c5c:      	ldr	x19, [sp, #0x30]
    7c60:      	and	w8, w8, #0xfffffffe
    7c64:      	cmp	w8, #0x18
    7c68:      	cset	w8, eq
    7c6c:      	ldp	x16, x15, [sp, #0x40]
    7c70:      	mov	w2, #0x5ea0             // =24224
    7c74:      	mov	w12, #0x1               // =1
    7c78:      	mov	w22, w8
    7c7c:      	ldr	x17, [sp, #0x38]
    7c80:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    7c84:      	ldr	w11, [x25]
    7c88:      	cmp	w11, w10
    7c8c:      	b.hi	0x6088 <generic_rawtp_filter_arg+0x298>
    7c90:      	b	0x7ca0 <generic_rawtp_filter_arg+0x1eb0>
    7c94:      	ldr	w11, [x25]
    7c98:      	cmp	w11, w10
    7c9c:      	b.lo	0x6088 <generic_rawtp_filter_arg+0x298>
    7ca0:      	ldr	w10, [x23, #0x8]
    7ca4:      	cmp	w10, #0xd
    7ca8:      	b.lo	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    7cac:      	ldr	w11, [x23, #0x14]
    7cb0:      	cmp	w8, #0x2
    7cb4:      	b.le	0x7cd8 <generic_rawtp_filter_arg+0x1ee8>
    7cb8:      	sub	w12, w8, #0x3
    7cbc:      	cmp	w12, #0x2
    7cc0:      	b.hs	0x7d18 <generic_rawtp_filter_arg+0x1f28>
    7cc4:      	ldr	w12, [x25]
    7cc8:      	cmp	w12, w11
    7ccc:      	mov	w12, #0x1               // =1
    7cd0:      	b.eq	0x607c <generic_rawtp_filter_arg+0x28c>
    7cd4:      	b	0x85a4 <generic_rawtp_filter_arg+0x27b4>
    7cd8:      	cmp	w8, #0x1
    7cdc:      	b.eq	0x7d38 <generic_rawtp_filter_arg+0x1f48>
    7ce0:      	cmp	w8, #0x2
    7ce4:      	b.ne	0x85a4 <generic_rawtp_filter_arg+0x27b4>
    7ce8:      	mov	w12, #0x1               // =1
    7cec:      	cmp	w9, #0xc
    7cf0:      	b.hi	0x8594 <generic_rawtp_filter_arg+0x27a4>
    7cf4:      	lsl	w12, w12, w9
    7cf8:      	mov	w13, #0x1402            // =5122
    7cfc:      	tst	w12, w13
    7d00:      	b.eq	0x8594 <generic_rawtp_filter_arg+0x27a4>
    7d04:      	ldr	w12, [x25]
    7d08:      	cmp	w12, w11
    7d0c:      	mov	w12, #0x1               // =1
    7d10:      	b.lt	0x6088 <generic_rawtp_filter_arg+0x298>
    7d14:      	b	0x85a4 <generic_rawtp_filter_arg+0x27b4>
    7d18:      	cmp	w8, #0xc
    7d1c:      	mov	w12, #0x1               // =1
    7d20:      	b.ne	0x85a4 <generic_rawtp_filter_arg+0x27b4>
    7d24:      	ldr	w12, [x25]
    7d28:      	tst	w12, w11
    7d2c:      	mov	w12, #0x1               // =1
    7d30:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    7d34:      	b	0x85a4 <generic_rawtp_filter_arg+0x27b4>
    7d38:      	mov	w12, #0x1               // =1
    7d3c:      	cmp	w9, #0xc
    7d40:      	b.hi	0x8580 <generic_rawtp_filter_arg+0x2790>
    7d44:      	lsl	w12, w12, w9
    7d48:      	mov	w13, #0x1402            // =5122
    7d4c:      	tst	w12, w13
    7d50:      	b.eq	0x8580 <generic_rawtp_filter_arg+0x2790>
    7d54:      	ldr	w12, [x25]
    7d58:      	cmp	w12, w11
    7d5c:      	mov	w12, #0x1               // =1
    7d60:      	b.gt	0x6088 <generic_rawtp_filter_arg+0x298>
    7d64:      	b	0x85a4 <generic_rawtp_filter_arg+0x27b4>
    7d68:      	and	w8, w29, #0xffff
    7d6c:      	cmp	w8, #0x201
    7d70:      	b.hs	0x81cc <generic_rawtp_filter_arg+0x23dc>
    7d74:      	mov	w11, #0x200             // =512
    7d78:      	b	0x870c <generic_rawtp_filter_arg+0x291c>
    7d7c:      	mov	x22, xzr
    7d80:      	ldr	x19, [sp, #0x30]
    7d84:      	ldr	w8, [x23, #0x4]
    7d88:      	cmp	w8, #0x25
    7d8c:      	b.hi	0x6e3c <generic_rawtp_filter_arg+0x104c>
    7d90:      	mov	x9, #0x50               // =80
    7d94:      	ldp	x16, x15, [sp, #0x40]
    7d98:      	mov	w12, #0x1               // =1
    7d9c:      	mov	w2, #0x5ea0             // =24224
    7da0:      	movk	x9, #0xc00, lsl #16
    7da4:      	ldr	x17, [sp, #0x38]
    7da8:      	lsl	x8, x12, x8
    7dac:      	movk	x9, #0x20, lsl #32
    7db0:      	tst	x8, x9
    7db4:      	b.ne	0x8c08 <generic_rawtp_filter_arg+0x2e18>
    7db8:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    7dbc:      	cmp	w8, #0x1
    7dc0:      	b.eq	0x843c <generic_rawtp_filter_arg+0x264c>
    7dc4:      	cmp	w8, #0x2
    7dc8:      	b.ne	0x8448 <generic_rawtp_filter_arg+0x2658>
    7dcc:      	ldrb	w11, [x25]
    7dd0:      	cmp	w10, w11
    7dd4:      	b.hi	0x6088 <generic_rawtp_filter_arg+0x298>
    7dd8:      	b	0x8448 <generic_rawtp_filter_arg+0x2658>
    7ddc:      	cmp	w8, #0x1
    7de0:      	b.eq	0x8478 <generic_rawtp_filter_arg+0x2688>
    7de4:      	cmp	w8, #0x2
    7de8:      	b.ne	0x8484 <generic_rawtp_filter_arg+0x2694>
    7dec:      	ldrh	w11, [x25]
    7df0:      	cmp	w10, w11
    7df4:      	b.hi	0x6088 <generic_rawtp_filter_arg+0x298>
    7df8:      	b	0x8484 <generic_rawtp_filter_arg+0x2694>
    7dfc:      	cmp	w8, #0x401
    7e00:      	b.hs	0x822c <generic_rawtp_filter_arg+0x243c>
    7e04:      	mov	w11, #0x400             // =1024
    7e08:      	b	0x8240 <generic_rawtp_filter_arg+0x2450>
    7e0c:      	cmp	w13, w10
    7e10:      	ccmp	w10, w12, #0x2, ls
    7e14:      	cset	w12, ls
    7e18:      	orr	w8, w8, w12
    7e1c:      	cmp	w11, #0x19
    7e20:      	mov	w12, #0x1               // =1
    7e24:      	b.lo	0x894c <generic_rawtp_filter_arg+0x2b5c>
    7e28:      	ldp	w13, w12, [x23, #0x20]
    7e2c:      	mov	w14, #0x1               // =1
    7e30:      	cmp	w9, #0xc
    7e34:      	b.hi	0x84d4 <generic_rawtp_filter_arg+0x26e4>
    7e38:      	lsl	w14, w14, w9
    7e3c:      	mov	w1, #0x1402             // =5122
    7e40:      	tst	w14, w1
    7e44:      	b.eq	0x84d4 <generic_rawtp_filter_arg+0x26e4>
    7e48:      	cmp	w13, w10
    7e4c:      	ccmp	w10, w12, #0x0, le
    7e50:      	cset	w12, le
    7e54:      	b	0x84e0 <generic_rawtp_filter_arg+0x26f0>
    7e58:      	ldr	x19, [sp, #0x30]
    7e5c:      	mov	x22, xzr
    7e60:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    7e64:      	mov	w11, #0xa               // =10
    7e68:      	b	0x7e78 <generic_rawtp_filter_arg+0x2088>
    7e6c:      	mov	w11, #0x6               // =6
    7e70:      	b	0x7e78 <generic_rawtp_filter_arg+0x2088>
    7e74:      	mov	w11, #0x8               // =8
    7e78:      	add	x8, x23, #0x10
    7e7c:      	and	w9, w11, #0xf
    7e80:      	ldr	w8, [x8, w9, uxtw #2]
    7e84:      	cmn	w8, #0x1
    7e88:      	b.eq	0x7f38 <generic_rawtp_filter_arg+0x2148>
    7e8c:      	str	w8, [sp, #0x10]
    7e90:      	stp	w13, w11, [sp, #0x1c]
    7e94:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1210>
    7e98:      	mov	w8, #0x1                // =1
    7e9c:      	add	x22, sp, #0x88
    7ea0:      	add	x1, sp, #0x88
    7ea4:      	str	x10, [sp, #0x28]
    7ea8:      	ldr	x0, [x0]
    7eac:      	blr	x8
    7eb0:      	mov	x25, x0
    7eb4:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1210>
    7eb8:      	mov	w8, #0x1                // =1
    7ebc:      	ldr	x0, [x0]
    7ec0:      	add	x1, sp, #0x88
    7ec4:      	blr	x8
    7ec8:      	mov	x22, xzr
    7ecc:      	cbz	x25, 0x8bd4 <generic_rawtp_filter_arg+0x2de4>
    7ed0:      	ldp	x16, x15, [sp, #0x40]
    7ed4:      	mov	w2, #0x5ea0             // =24224
    7ed8:      	mov	w12, #0x1               // =1
    7edc:      	ldr	x17, [sp, #0x38]
    7ee0:      	cbz	x0, 0x8be4 <generic_rawtp_filter_arg+0x2df4>
    7ee4:      	mov	x8, x25
    7ee8:      	ldr	w25, [sp, #0x20]
    7eec:      	mov	x22, x0
    7ef0:      	mov	x0, x8
    7ef4:      	str	x8, [sp, #0x8]
    7ef8:      	cmp	w25, #0x5
    7efc:      	b.gt	0x7f4c <generic_rawtp_filter_arg+0x215c>
    7f00:      	strb	w29, [x0], #0x1
    7f04:      	ldr	x2, [sp, #0x28]
    7f08:      	mov	w8, #0x4                // =4
    7f0c:      	mov	w1, w29
    7f10:      	blr	x8
    7f14:      	ldr	w8, [sp, #0x1c]
    7f18:      	subs	w8, w8, w29
    7f1c:      	b.ls	0x7f88 <generic_rawtp_filter_arg+0x2198>
    7f20:      	ldr	x9, [sp, #0x8]
    7f24:      	and	w1, w8, #0xfff
    7f28:      	mov	w8, #0x4                // =4
    7f2c:      	add	x9, x9, x29
    7f30:      	add	x0, x9, #0x1
    7f34:      	b	0x7f80 <generic_rawtp_filter_arg+0x2190>
    7f38:      	mov	x22, xzr
    7f3c:      	ldr	w8, [x23, #0x4]
    7f40:      	cmp	w8, #0x25
    7f44:      	b.ls	0x8bf0 <generic_rawtp_filter_arg+0x2e00>
    7f48:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    7f4c:      	strh	w29, [x0], #0x2
    7f50:      	ldr	x2, [sp, #0x28]
    7f54:      	mov	w8, #0x4                // =4
    7f58:      	mov	w1, w29
    7f5c:      	blr	x8
    7f60:      	ldr	w8, [sp, #0x1c]
    7f64:      	subs	w8, w8, w29
    7f68:      	b.ls	0x7f88 <generic_rawtp_filter_arg+0x2198>
    7f6c:      	ldr	x9, [sp, #0x8]
    7f70:      	and	w1, w8, #0xfff
    7f74:      	mov	w8, #0x4                // =4
    7f78:      	add	x9, x9, x29
    7f7c:      	add	x0, x9, #0x2
    7f80:      	mov	x2, x22
    7f84:      	blr	x8
    7f88:      	ldr	w8, [sp, #0x10]
    7f8c:      	cmp	w25, #0x4
    7f90:      	mov	w12, #0x1               // =1
    7f94:      	str	w8, [sp, #0x60]
    7f98:      	b.le	0x7fd0 <generic_rawtp_filter_arg+0x21e0>
    7f9c:      	cmp	w25, #0x7
    7fa0:      	b.gt	0x8200 <generic_rawtp_filter_arg+0x2410>
    7fa4:      	cmp	w25, #0x5
    7fa8:      	b.eq	0x8b88 <generic_rawtp_filter_arg+0x2d98>
    7fac:      	cmp	w25, #0x6
    7fb0:      	b.eq	0x8b4c <generic_rawtp_filter_arg+0x2d5c>
    7fb4:      	cmp	w25, #0x7
    7fb8:      	b.ne	0x8c10 <generic_rawtp_filter_arg+0x2e20>
    7fbc:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1210>
    7fc0:      	mov	w8, #0x1                // =1
    7fc4:      	add	x9, sp, #0x60
    7fc8:      	ldr	x0, [x0]
    7fcc:      	b	0x8bac <generic_rawtp_filter_arg+0x2dbc>
    7fd0:      	cmp	w25, #0x1
    7fd4:      	b.le	0x8684 <generic_rawtp_filter_arg+0x2894>
    7fd8:      	cmp	w25, #0x2
    7fdc:      	b.eq	0x8b74 <generic_rawtp_filter_arg+0x2d84>
    7fe0:      	cmp	w25, #0x3
    7fe4:      	b.eq	0x8b38 <generic_rawtp_filter_arg+0x2d48>
    7fe8:      	cmp	w25, #0x4
    7fec:      	b.ne	0x8c10 <generic_rawtp_filter_arg+0x2e20>
    7ff0:      	adrp	x0, 0x7000 <generic_rawtp_filter_arg+0x1210>
    7ff4:      	mov	w8, #0x1                // =1
    7ff8:      	add	x9, sp, #0x60
    7ffc:      	ldr	x0, [x0]
    8000:      	b	0x8bac <generic_rawtp_filter_arg+0x2dbc>
    8004:      	cmp	w12, w8
    8008:      	mov	w12, #0x1               // =1
    800c:      	b.hi	0x8018 <generic_rawtp_filter_arg+0x2228>
    8010:      	cmp	w8, w11
    8014:      	b.ls	0x6088 <generic_rawtp_filter_arg+0x298>
    8018:      	cmp	w10, #0x19
    801c:      	b.lo	0x5eec <generic_rawtp_filter_arg+0xfc>
    8020:      	ldp	w12, w11, [x23, #0x20]
    8024:      	mov	w13, #0x1               // =1
    8028:      	cmp	w9, #0xc
    802c:      	b.hi	0x8534 <generic_rawtp_filter_arg+0x2744>
    8030:      	lsl	w13, w13, w9
    8034:      	mov	w14, #0x1402            // =5122
    8038:      	tst	w13, w14
    803c:      	b.eq	0x8534 <generic_rawtp_filter_arg+0x2744>
    8040:      	cmp	w12, w8
    8044:      	mov	w12, #0x1               // =1
    8048:      	b.gt	0x8548 <generic_rawtp_filter_arg+0x2758>
    804c:      	cmp	w8, w11
    8050:      	b.le	0x6088 <generic_rawtp_filter_arg+0x298>
    8054:      	b	0x8548 <generic_rawtp_filter_arg+0x2758>
    8058:      	cmp	w8, #0x101
    805c:      	b.hs	0x8520 <generic_rawtp_filter_arg+0x2730>
    8060:      	mov	w11, #0x100             // =256
    8064:      	b	0x8e60 <generic_rawtp_filter_arg+0x3070>
    8068:      	cmp	x13, x10
    806c:      	ccmp	x10, x12, #0x2, ls
    8070:      	cset	w12, ls
    8074:      	orr	w8, w8, w12
    8078:      	cmp	w11, #0x39
    807c:      	b.lo	0x8678 <generic_rawtp_filter_arg+0x2888>
    8080:      	ldp	x12, x11, [x23, #0x40]
    8084:      	cmp	w9, #0xc
    8088:      	b.eq	0x8094 <generic_rawtp_filter_arg+0x22a4>
    808c:      	cmp	w9, #0xa
    8090:      	b.ne	0x8668 <generic_rawtp_filter_arg+0x2878>
    8094:      	cmp	x12, x10
    8098:      	ccmp	x10, x11, #0x0, le
    809c:      	cset	w9, le
    80a0:      	b	0x8674 <generic_rawtp_filter_arg+0x2884>
    80a4:      	cmp	x12, x8
    80a8:      	mov	w12, #0x1               // =1
    80ac:      	b.hi	0x80b8 <generic_rawtp_filter_arg+0x22c8>
    80b0:      	cmp	x8, x11
    80b4:      	b.ls	0x6088 <generic_rawtp_filter_arg+0x298>
    80b8:      	cmp	w10, #0x39
    80bc:      	b.lo	0x5eec <generic_rawtp_filter_arg+0xfc>
    80c0:      	ldp	x11, x10, [x23, #0x40]
    80c4:      	cmp	w9, #0xc
    80c8:      	b.eq	0x80d4 <generic_rawtp_filter_arg+0x22e4>
    80cc:      	cmp	w9, #0xa
    80d0:      	b.ne	0x86a4 <generic_rawtp_filter_arg+0x28b4>
    80d4:      	cmp	x11, x8
    80d8:      	b.gt	0x5eec <generic_rawtp_filter_arg+0xfc>
    80dc:      	cmp	x8, x10
    80e0:      	b.le	0x6088 <generic_rawtp_filter_arg+0x298>
    80e4:      	b	0x5eec <generic_rawtp_filter_arg+0xfc>
    80e8:      	ldr	x12, [x25]
    80ec:      	cmp	x12, x11
    80f0:      	mov	w12, #0x1               // =1
    80f4:      	b.hi	0x6088 <generic_rawtp_filter_arg+0x298>
    80f8:      	b	0x810c <generic_rawtp_filter_arg+0x231c>
    80fc:      	ldr	x12, [x25]
    8100:      	cmp	x12, x11
    8104:      	mov	w12, #0x1               // =1
    8108:      	b.lo	0x6088 <generic_rawtp_filter_arg+0x298>
    810c:      	cmp	w10, #0x19
    8110:      	b.lo	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    8114:      	ldr	x11, [x23, #0x20]
    8118:      	cmp	w8, #0x2
    811c:      	b.le	0x8140 <generic_rawtp_filter_arg+0x2350>
    8120:      	sub	w12, w8, #0x3
    8124:      	cmp	w12, #0x2
    8128:      	b.hs	0x8174 <generic_rawtp_filter_arg+0x2384>
    812c:      	ldr	x12, [x25]
    8130:      	cmp	x12, x11
    8134:      	mov	w12, #0x1               // =1
    8138:      	b.eq	0x607c <generic_rawtp_filter_arg+0x28c>
    813c:      	b	0x8978 <generic_rawtp_filter_arg+0x2b88>
    8140:      	cmp	w8, #0x1
    8144:      	b.eq	0x81dc <generic_rawtp_filter_arg+0x23ec>
    8148:      	cmp	w8, #0x2
    814c:      	b.ne	0x8978 <generic_rawtp_filter_arg+0x2b88>
    8150:      	cmp	w9, #0xc
    8154:      	b.eq	0x8160 <generic_rawtp_filter_arg+0x2370>
    8158:      	cmp	w9, #0xa
    815c:      	b.ne	0x8968 <generic_rawtp_filter_arg+0x2b78>
    8160:      	ldr	x12, [x25]
    8164:      	cmp	x12, x11
    8168:      	mov	w12, #0x1               // =1
    816c:      	b.lt	0x6088 <generic_rawtp_filter_arg+0x298>
    8170:      	b	0x8978 <generic_rawtp_filter_arg+0x2b88>
    8174:      	cmp	w8, #0xc
    8178:      	mov	w12, #0x1               // =1
    817c:      	b.ne	0x8978 <generic_rawtp_filter_arg+0x2b88>
    8180:      	ldr	x12, [x25]
    8184:      	tst	x12, x11
    8188:      	mov	w12, #0x1               // =1
    818c:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    8190:      	b	0x8978 <generic_rawtp_filter_arg+0x2b88>
    8194:      	cmp	w8, #0xc
    8198:      	b.ne	0x8448 <generic_rawtp_filter_arg+0x2658>
    819c:      	ldrb	w11, [x25]
    81a0:      	tst	w10, w11
    81a4:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    81a8:      	b	0x8448 <generic_rawtp_filter_arg+0x2658>
    81ac:      	cmp	w8, #0xc
    81b0:      	b.ne	0x8484 <generic_rawtp_filter_arg+0x2694>
    81b4:      	ldrh	w11, [x25]
    81b8:      	tst	w10, w11
    81bc:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    81c0:      	b	0x8484 <generic_rawtp_filter_arg+0x2694>
    81c4:      	mov	w22, #0x1               // =1
    81c8:      	b	0x9170 <generic_rawtp_filter_arg+0x3380>
    81cc:      	cmp	w8, #0x401
    81d0:      	b.hs	0x86f8 <generic_rawtp_filter_arg+0x2908>
    81d4:      	mov	w11, #0x400             // =1024
    81d8:      	b	0x870c <generic_rawtp_filter_arg+0x291c>
    81dc:      	cmp	w9, #0xc
    81e0:      	b.eq	0x81ec <generic_rawtp_filter_arg+0x23fc>
    81e4:      	cmp	w9, #0xa
    81e8:      	b.ne	0x8954 <generic_rawtp_filter_arg+0x2b64>
    81ec:      	ldr	x12, [x25]
    81f0:      	cmp	x12, x11
    81f4:      	mov	w12, #0x1               // =1
    81f8:      	b.gt	0x6088 <generic_rawtp_filter_arg+0x298>
    81fc:      	b	0x8978 <generic_rawtp_filter_arg+0x2b88>
    8200:      	cmp	w25, #0x8
    8204:      	b.eq	0x8b9c <generic_rawtp_filter_arg+0x2dac>
    8208:      	cmp	w25, #0x9
    820c:      	b.eq	0x8b60 <generic_rawtp_filter_arg+0x2d70>
    8210:      	cmp	w25, #0xa
    8214:      	b.ne	0x8c10 <generic_rawtp_filter_arg+0x2e20>
    8218:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    821c:      	mov	w8, #0x1                // =1
    8220:      	add	x9, sp, #0x60
    8224:      	ldr	x0, [x0]
    8228:      	b	0x8bac <generic_rawtp_filter_arg+0x2dbc>
    822c:      	and	w8, w29, #0xffff
    8230:      	mov	w9, #0x1000             // =4096
    8234:      	cmp	w8, #0x800
    8238:      	mov	w8, #0x800              // =2048
    823c:      	csel	w11, w9, w8, hi
    8240:      	sub	w8, w11, #0x100
    8244:      	ror	w8, w8, #0x8
    8248:      	cmp	w8, #0x2
    824c:      	b.gt	0x8264 <generic_rawtp_filter_arg+0x2474>
    8250:      	cbz	w8, 0x8284 <generic_rawtp_filter_arg+0x2494>
    8254:      	cmp	w8, #0x1
    8258:      	b.ne	0x827c <generic_rawtp_filter_arg+0x248c>
    825c:      	mov	w10, #0x7               // =7
    8260:      	b	0x8290 <generic_rawtp_filter_arg+0x24a0>
    8264:      	cmp	w8, #0x3
    8268:      	b.eq	0x828c <generic_rawtp_filter_arg+0x249c>
    826c:      	cmp	w8, #0x7
    8270:      	b.ne	0x827c <generic_rawtp_filter_arg+0x248c>
    8274:      	mov	w10, #0x9               // =9
    8278:      	b	0x8290 <generic_rawtp_filter_arg+0x24a0>
    827c:      	mov	w10, #0xa               // =10
    8280:      	b	0x8290 <generic_rawtp_filter_arg+0x24a0>
    8284:      	mov	w10, #0x6               // =6
    8288:      	b	0x8290 <generic_rawtp_filter_arg+0x24a0>
    828c:      	mov	w10, #0x8               // =8
    8290:      	add	x8, x23, #0x10
    8294:      	and	w9, w10, #0xf
    8298:      	ldr	w8, [x8, w9, uxtw #2]
    829c:      	cmn	w8, #0x1
    82a0:      	b.eq	0x8bd0 <generic_rawtp_filter_arg+0x2de0>
    82a4:      	str	w8, [sp, #0x10]
    82a8:      	str	w11, [sp, #0x1c]
    82ac:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    82b0:      	mov	w8, #0x1                // =1
    82b4:      	add	x22, sp, #0x88
    82b8:      	add	x1, sp, #0x88
    82bc:      	str	w10, [sp, #0x28]
    82c0:      	ldr	x0, [x0]
    82c4:      	blr	x8
    82c8:      	str	x0, [sp, #0x20]
    82cc:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    82d0:      	mov	w8, #0x1                // =1
    82d4:      	add	x1, sp, #0x88
    82d8:      	ldr	x0, [x0]
    82dc:      	blr	x8
    82e0:      	ldr	x9, [sp, #0x20]
    82e4:      	mov	x22, xzr
    82e8:      	cbz	x9, 0x8bd4 <generic_rawtp_filter_arg+0x2de4>
    82ec:      	ldp	x16, x15, [sp, #0x40]
    82f0:      	mov	w2, #0x5ea0             // =24224
    82f4:      	mov	w12, #0x1               // =1
    82f8:      	ldr	x17, [sp, #0x38]
    82fc:      	cbz	x0, 0x8be4 <generic_rawtp_filter_arg+0x2df4>
    8300:      	mov	x8, x9
    8304:      	ldr	w9, [sp, #0x28]
    8308:      	mov	x22, x0
    830c:      	add	x2, x25, #0x4
    8310:      	mov	x25, x8
    8314:      	mov	x0, x8
    8318:      	cmp	w9, #0x5
    831c:      	b.gt	0x8350 <generic_rawtp_filter_arg+0x2560>
    8320:      	strb	w29, [x0], #0x1
    8324:      	mov	w8, #0x4                // =4
    8328:      	mov	w1, w29
    832c:      	blr	x8
    8330:      	ldr	w8, [sp, #0x1c]
    8334:      	subs	w8, w8, w29
    8338:      	b.ls	0x8384 <generic_rawtp_filter_arg+0x2594>
    833c:      	add	x9, x25, x29
    8340:      	and	w1, w8, #0xfff
    8344:      	mov	w8, #0x4                // =4
    8348:      	add	x0, x9, #0x1
    834c:      	b	0x837c <generic_rawtp_filter_arg+0x258c>
    8350:      	strh	w29, [x0], #0x2
    8354:      	mov	w8, #0x4                // =4
    8358:      	mov	w1, w29
    835c:      	blr	x8
    8360:      	ldr	w8, [sp, #0x1c]
    8364:      	subs	w8, w8, w29
    8368:      	b.ls	0x8384 <generic_rawtp_filter_arg+0x2594>
    836c:      	add	x9, x25, x29
    8370:      	and	w1, w8, #0xfff
    8374:      	mov	w8, #0x4                // =4
    8378:      	add	x0, x9, #0x2
    837c:      	mov	x2, x22
    8380:      	blr	x8
    8384:      	ldr	w8, [sp, #0x10]
    8388:      	ldp	x16, x15, [sp, #0x40]
    838c:      	mov	w2, #0x5ea0             // =24224
    8390:      	mov	w12, #0x1               // =1
    8394:      	ldr	x17, [sp, #0x38]
    8398:      	str	w8, [sp, #0x60]
    839c:      	ldr	w8, [sp, #0x28]
    83a0:      	cmp	w8, #0x4
    83a4:      	b.le	0x83dc <generic_rawtp_filter_arg+0x25ec>
    83a8:      	cmp	w8, #0x7
    83ac:      	b.gt	0x8410 <generic_rawtp_filter_arg+0x2620>
    83b0:      	cmp	w8, #0x5
    83b4:      	b.eq	0x8a8c <generic_rawtp_filter_arg+0x2c9c>
    83b8:      	cmp	w8, #0x6
    83bc:      	b.eq	0x8a50 <generic_rawtp_filter_arg+0x2c60>
    83c0:      	cmp	w8, #0x7
    83c4:      	b.ne	0x65ac <generic_rawtp_filter_arg+0x7bc>
    83c8:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    83cc:      	mov	w8, #0x1                // =1
    83d0:      	add	x9, sp, #0x60
    83d4:      	ldr	x0, [x0]
    83d8:      	b	0x8ab0 <generic_rawtp_filter_arg+0x2cc0>
    83dc:      	cmp	w8, #0x1
    83e0:      	b.le	0x84b4 <generic_rawtp_filter_arg+0x26c4>
    83e4:      	cmp	w8, #0x2
    83e8:      	b.eq	0x8a78 <generic_rawtp_filter_arg+0x2c88>
    83ec:      	cmp	w8, #0x3
    83f0:      	b.eq	0x8a3c <generic_rawtp_filter_arg+0x2c4c>
    83f4:      	cmp	w8, #0x4
    83f8:      	b.ne	0x65ac <generic_rawtp_filter_arg+0x7bc>
    83fc:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8400:      	mov	w8, #0x1                // =1
    8404:      	add	x9, sp, #0x60
    8408:      	ldr	x0, [x0]
    840c:      	b	0x8ab0 <generic_rawtp_filter_arg+0x2cc0>
    8410:      	cmp	w8, #0x8
    8414:      	b.eq	0x8aa0 <generic_rawtp_filter_arg+0x2cb0>
    8418:      	cmp	w8, #0x9
    841c:      	b.eq	0x8a64 <generic_rawtp_filter_arg+0x2c74>
    8420:      	cmp	w8, #0xa
    8424:      	b.ne	0x65ac <generic_rawtp_filter_arg+0x7bc>
    8428:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    842c:      	mov	w8, #0x1                // =1
    8430:      	add	x9, sp, #0x60
    8434:      	ldr	x0, [x0]
    8438:      	b	0x8ab0 <generic_rawtp_filter_arg+0x2cc0>
    843c:      	ldrb	w11, [x25]
    8440:      	cmp	w10, w11
    8444:      	b.lo	0x6088 <generic_rawtp_filter_arg+0x298>
    8448:      	cmp	w9, #0x11
    844c:      	b.lo	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    8450:      	ldr	w10, [x23, #0x18]
    8454:      	cmp	w8, #0x2
    8458:      	b.le	0x86b8 <generic_rawtp_filter_arg+0x28c8>
    845c:      	sub	w11, w8, #0x3
    8460:      	cmp	w11, #0x2
    8464:      	b.hs	0x89f8 <generic_rawtp_filter_arg+0x2c08>
    8468:      	ldrb	w11, [x25]
    846c:      	cmp	w10, w11
    8470:      	b.eq	0x607c <generic_rawtp_filter_arg+0x28c>
    8474:      	b	0x8d04 <generic_rawtp_filter_arg+0x2f14>
    8478:      	ldrh	w11, [x25]
    847c:      	cmp	w10, w11
    8480:      	b.lo	0x6088 <generic_rawtp_filter_arg+0x298>
    8484:      	cmp	w9, #0x11
    8488:      	b.lo	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    848c:      	ldr	w10, [x23, #0x18]
    8490:      	cmp	w8, #0x2
    8494:      	b.le	0x86d8 <generic_rawtp_filter_arg+0x28e8>
    8498:      	sub	w11, w8, #0x3
    849c:      	cmp	w11, #0x2
    84a0:      	b.hs	0x8a10 <generic_rawtp_filter_arg+0x2c20>
    84a4:      	ldrh	w11, [x25]
    84a8:      	cmp	w10, w11
    84ac:      	b.eq	0x607c <generic_rawtp_filter_arg+0x28c>
    84b0:      	b	0x8d48 <generic_rawtp_filter_arg+0x2f58>
    84b4:      	cbz	w8, 0x8a28 <generic_rawtp_filter_arg+0x2c38>
    84b8:      	cmp	w8, #0x1
    84bc:      	b.ne	0x65ac <generic_rawtp_filter_arg+0x7bc>
    84c0:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    84c4:      	mov	w8, #0x1                // =1
    84c8:      	add	x9, sp, #0x60
    84cc:      	ldr	x0, [x0]
    84d0:      	b	0x8ab0 <generic_rawtp_filter_arg+0x2cc0>
    84d4:      	cmp	w13, w10
    84d8:      	ccmp	w10, w12, #0x2, ls
    84dc:      	cset	w12, ls
    84e0:      	orr	w8, w8, w12
    84e4:      	cmp	w11, #0x21
    84e8:      	mov	w12, #0x1               // =1
    84ec:      	b.lo	0x894c <generic_rawtp_filter_arg+0x2b5c>
    84f0:      	ldp	w12, w11, [x23, #0x28]
    84f4:      	mov	w13, #0x1               // =1
    84f8:      	cmp	w9, #0xc
    84fc:      	b.hi	0x8938 <generic_rawtp_filter_arg+0x2b48>
    8500:      	lsl	w9, w13, w9
    8504:      	mov	w13, #0x1402            // =5122
    8508:      	tst	w9, w13
    850c:      	b.eq	0x8938 <generic_rawtp_filter_arg+0x2b48>
    8510:      	cmp	w12, w10
    8514:      	ccmp	w10, w11, #0x0, le
    8518:      	cset	w9, le
    851c:      	b	0x8944 <generic_rawtp_filter_arg+0x2b54>
    8520:      	and	w8, w25, #0xffff
    8524:      	cmp	w8, #0x201
    8528:      	b.hs	0x8ad4 <generic_rawtp_filter_arg+0x2ce4>
    852c:      	mov	w11, #0x200             // =512
    8530:      	b	0x8e60 <generic_rawtp_filter_arg+0x3070>
    8534:      	cmp	w12, w8
    8538:      	mov	w12, #0x1               // =1
    853c:      	b.hi	0x8548 <generic_rawtp_filter_arg+0x2758>
    8540:      	cmp	w8, w11
    8544:      	b.ls	0x6088 <generic_rawtp_filter_arg+0x298>
    8548:      	cmp	w10, #0x21
    854c:      	b.lo	0x5eec <generic_rawtp_filter_arg+0xfc>
    8550:      	ldp	w11, w10, [x23, #0x28]
    8554:      	cmp	w9, #0xc
    8558:      	b.hi	0x8ae4 <generic_rawtp_filter_arg+0x2cf4>
    855c:      	lsl	w9, w12, w9
    8560:      	mov	w13, #0x1402            // =5122
    8564:      	tst	w9, w13
    8568:      	b.eq	0x8ae4 <generic_rawtp_filter_arg+0x2cf4>
    856c:      	cmp	w11, w8
    8570:      	b.gt	0x5eec <generic_rawtp_filter_arg+0xfc>
    8574:      	cmp	w8, w10
    8578:      	b.le	0x6088 <generic_rawtp_filter_arg+0x298>
    857c:      	b	0x5eec <generic_rawtp_filter_arg+0xfc>
    8580:      	ldr	w12, [x25]
    8584:      	cmp	w12, w11
    8588:      	mov	w12, #0x1               // =1
    858c:      	b.hi	0x6088 <generic_rawtp_filter_arg+0x298>
    8590:      	b	0x85a4 <generic_rawtp_filter_arg+0x27b4>
    8594:      	ldr	w12, [x25]
    8598:      	cmp	w12, w11
    859c:      	mov	w12, #0x1               // =1
    85a0:      	b.lo	0x6088 <generic_rawtp_filter_arg+0x298>
    85a4:      	cmp	w10, #0x11
    85a8:      	b.lo	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    85ac:      	ldr	w11, [x23, #0x18]
    85b0:      	cmp	w8, #0x2
    85b4:      	b.le	0x85d8 <generic_rawtp_filter_arg+0x27e8>
    85b8:      	sub	w12, w8, #0x3
    85bc:      	cmp	w12, #0x2
    85c0:      	b.hs	0x8618 <generic_rawtp_filter_arg+0x2828>
    85c4:      	ldr	w12, [x25]
    85c8:      	cmp	w12, w11
    85cc:      	mov	w12, #0x1               // =1
    85d0:      	b.eq	0x607c <generic_rawtp_filter_arg+0x28c>
    85d4:      	b	0x8da4 <generic_rawtp_filter_arg+0x2fb4>
    85d8:      	cmp	w8, #0x1
    85dc:      	b.eq	0x8638 <generic_rawtp_filter_arg+0x2848>
    85e0:      	cmp	w8, #0x2
    85e4:      	b.ne	0x8da4 <generic_rawtp_filter_arg+0x2fb4>
    85e8:      	mov	w12, #0x1               // =1
    85ec:      	cmp	w9, #0xc
    85f0:      	b.hi	0x8d94 <generic_rawtp_filter_arg+0x2fa4>
    85f4:      	lsl	w12, w12, w9
    85f8:      	mov	w13, #0x1402            // =5122
    85fc:      	tst	w12, w13
    8600:      	b.eq	0x8d94 <generic_rawtp_filter_arg+0x2fa4>
    8604:      	ldr	w12, [x25]
    8608:      	cmp	w12, w11
    860c:      	mov	w12, #0x1               // =1
    8610:      	b.lt	0x6088 <generic_rawtp_filter_arg+0x298>
    8614:      	b	0x8da4 <generic_rawtp_filter_arg+0x2fb4>
    8618:      	cmp	w8, #0xc
    861c:      	mov	w12, #0x1               // =1
    8620:      	b.ne	0x8da4 <generic_rawtp_filter_arg+0x2fb4>
    8624:      	ldr	w12, [x25]
    8628:      	tst	w12, w11
    862c:      	mov	w12, #0x1               // =1
    8630:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    8634:      	b	0x8da4 <generic_rawtp_filter_arg+0x2fb4>
    8638:      	mov	w12, #0x1               // =1
    863c:      	cmp	w9, #0xc
    8640:      	b.hi	0x8d80 <generic_rawtp_filter_arg+0x2f90>
    8644:      	lsl	w12, w12, w9
    8648:      	mov	w13, #0x1402            // =5122
    864c:      	tst	w12, w13
    8650:      	b.eq	0x8d80 <generic_rawtp_filter_arg+0x2f90>
    8654:      	ldr	w12, [x25]
    8658:      	cmp	w12, w11
    865c:      	mov	w12, #0x1               // =1
    8660:      	b.gt	0x6088 <generic_rawtp_filter_arg+0x298>
    8664:      	b	0x8da4 <generic_rawtp_filter_arg+0x2fb4>
    8668:      	cmp	x12, x10
    866c:      	ccmp	x10, x11, #0x2, ls
    8670:      	cset	w9, ls
    8674:      	orr	w8, w8, w9
    8678:      	mov	w12, #0x1               // =1
    867c:      	tbz	w8, #0x0, 0x6088 <generic_rawtp_filter_arg+0x298>
    8680:      	b	0x5eec <generic_rawtp_filter_arg+0xfc>
    8684:      	cbz	w25, 0x8b24 <generic_rawtp_filter_arg+0x2d34>
    8688:      	cmp	w25, #0x1
    868c:      	b.ne	0x8c10 <generic_rawtp_filter_arg+0x2e20>
    8690:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8694:      	mov	w8, #0x1                // =1
    8698:      	add	x9, sp, #0x60
    869c:      	ldr	x0, [x0]
    86a0:      	b	0x8bac <generic_rawtp_filter_arg+0x2dbc>
    86a4:      	cmp	x11, x8
    86a8:      	b.hi	0x5eec <generic_rawtp_filter_arg+0xfc>
    86ac:      	cmp	x8, x10
    86b0:      	b.ls	0x6088 <generic_rawtp_filter_arg+0x298>
    86b4:      	b	0x5eec <generic_rawtp_filter_arg+0xfc>
    86b8:      	cmp	w8, #0x1
    86bc:      	b.eq	0x8cf8 <generic_rawtp_filter_arg+0x2f08>
    86c0:      	cmp	w8, #0x2
    86c4:      	b.ne	0x8d04 <generic_rawtp_filter_arg+0x2f14>
    86c8:      	ldrb	w11, [x25]
    86cc:      	cmp	w10, w11
    86d0:      	b.hi	0x6088 <generic_rawtp_filter_arg+0x298>
    86d4:      	b	0x8d04 <generic_rawtp_filter_arg+0x2f14>
    86d8:      	cmp	w8, #0x1
    86dc:      	b.eq	0x8d3c <generic_rawtp_filter_arg+0x2f4c>
    86e0:      	cmp	w8, #0x2
    86e4:      	b.ne	0x8d48 <generic_rawtp_filter_arg+0x2f58>
    86e8:      	ldrh	w11, [x25]
    86ec:      	cmp	w10, w11
    86f0:      	b.hi	0x6088 <generic_rawtp_filter_arg+0x298>
    86f4:      	b	0x8d48 <generic_rawtp_filter_arg+0x2f58>
    86f8:      	and	w8, w29, #0xffff
    86fc:      	mov	w9, #0x1000             // =4096
    8700:      	cmp	w8, #0x800
    8704:      	mov	w8, #0x800              // =2048
    8708:      	csel	w11, w9, w8, hi
    870c:      	sub	w8, w11, #0x100
    8710:      	ror	w8, w8, #0x8
    8714:      	cmp	w8, #0x2
    8718:      	b.gt	0x8730 <generic_rawtp_filter_arg+0x2940>
    871c:      	cbz	w8, 0x8750 <generic_rawtp_filter_arg+0x2960>
    8720:      	cmp	w8, #0x1
    8724:      	b.ne	0x8748 <generic_rawtp_filter_arg+0x2958>
    8728:      	mov	w10, #0x7               // =7
    872c:      	b	0x875c <generic_rawtp_filter_arg+0x296c>
    8730:      	cmp	w8, #0x3
    8734:      	b.eq	0x8758 <generic_rawtp_filter_arg+0x2968>
    8738:      	cmp	w8, #0x7
    873c:      	b.ne	0x8748 <generic_rawtp_filter_arg+0x2958>
    8740:      	mov	w10, #0x9               // =9
    8744:      	b	0x875c <generic_rawtp_filter_arg+0x296c>
    8748:      	mov	w10, #0xa               // =10
    874c:      	b	0x875c <generic_rawtp_filter_arg+0x296c>
    8750:      	mov	w10, #0x6               // =6
    8754:      	b	0x875c <generic_rawtp_filter_arg+0x296c>
    8758:      	mov	w10, #0x8               // =8
    875c:      	add	x8, x23, #0x10
    8760:      	and	w9, w10, #0xf
    8764:      	ldr	w8, [x8, w9, uxtw #2]
    8768:      	cmn	w8, #0x1
    876c:      	b.eq	0x8820 <generic_rawtp_filter_arg+0x2a30>
    8770:      	str	w8, [sp, #0x1c]
    8774:      	str	w11, [sp, #0x10]
    8778:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    877c:      	mov	w8, #0x1                // =1
    8780:      	add	x22, sp, #0x88
    8784:      	add	x1, sp, #0x88
    8788:      	str	w10, [sp, #0x28]
    878c:      	ldr	x0, [x0]
    8790:      	blr	x8
    8794:      	str	x0, [sp, #0x20]
    8798:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    879c:      	mov	w8, #0x1                // =1
    87a0:      	add	x1, sp, #0x88
    87a4:      	ldr	x0, [x0]
    87a8:      	blr	x8
    87ac:      	ldr	x9, [sp, #0x20]
    87b0:      	mov	x22, xzr
    87b4:      	cbz	x9, 0x70a0 <generic_rawtp_filter_arg+0x12b0>
    87b8:      	ldp	x16, x15, [sp, #0x40]
    87bc:      	mov	w2, #0x5ea0             // =24224
    87c0:      	mov	w12, #0x1               // =1
    87c4:      	ldr	x17, [sp, #0x38]
    87c8:      	cbz	x0, 0x70b0 <generic_rawtp_filter_arg+0x12c0>
    87cc:      	mov	x8, x9
    87d0:      	ldr	w9, [sp, #0x28]
    87d4:      	mov	x22, x0
    87d8:      	cmp	w9, #0x5
    87dc:      	b.gt	0x8828 <generic_rawtp_filter_arg+0x2a38>
    87e0:      	mov	x0, x8
    87e4:      	mov	x9, x8
    87e8:      	mov	w8, #0x4                // =4
    87ec:      	mov	w1, w29
    87f0:      	mov	x2, x25
    87f4:      	strb	w29, [x0], #0x1
    87f8:      	mov	x25, x9
    87fc:      	blr	x8
    8800:      	ldr	w8, [sp, #0x10]
    8804:      	subs	w8, w8, w29
    8808:      	b.ls	0x886c <generic_rawtp_filter_arg+0x2a7c>
    880c:      	add	x9, x25, x29
    8810:      	and	w1, w8, #0xfff
    8814:      	mov	w8, #0x4                // =4
    8818:      	add	x0, x9, #0x1
    881c:      	b	0x8864 <generic_rawtp_filter_arg+0x2a74>
    8820:      	mov	x22, xzr
    8824:      	b	0x70ac <generic_rawtp_filter_arg+0x12bc>
    8828:      	mov	x0, x8
    882c:      	mov	x9, x8
    8830:      	mov	w8, #0x4                // =4
    8834:      	mov	w1, w29
    8838:      	mov	x2, x25
    883c:      	strh	w29, [x0], #0x2
    8840:      	mov	x25, x9
    8844:      	blr	x8
    8848:      	ldr	w8, [sp, #0x10]
    884c:      	subs	w8, w8, w29
    8850:      	b.ls	0x886c <generic_rawtp_filter_arg+0x2a7c>
    8854:      	add	x9, x25, x29
    8858:      	and	w1, w8, #0xfff
    885c:      	mov	w8, #0x4                // =4
    8860:      	add	x0, x9, #0x2
    8864:      	mov	x2, x22
    8868:      	blr	x8
    886c:      	ldr	w8, [sp, #0x1c]
    8870:      	mov	w12, #0x1               // =1
    8874:      	str	w8, [sp, #0x60]
    8878:      	ldr	w8, [sp, #0x28]
    887c:      	cmp	w8, #0x4
    8880:      	b.le	0x88b8 <generic_rawtp_filter_arg+0x2ac8>
    8884:      	cmp	w8, #0x7
    8888:      	b.gt	0x88ec <generic_rawtp_filter_arg+0x2afc>
    888c:      	cmp	w8, #0x5
    8890:      	b.eq	0x8c94 <generic_rawtp_filter_arg+0x2ea4>
    8894:      	cmp	w8, #0x6
    8898:      	b.eq	0x8c58 <generic_rawtp_filter_arg+0x2e68>
    889c:      	cmp	w8, #0x7
    88a0:      	b.ne	0x8ce4 <generic_rawtp_filter_arg+0x2ef4>
    88a4:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    88a8:      	mov	w8, #0x1                // =1
    88ac:      	add	x9, sp, #0x60
    88b0:      	ldr	x0, [x0]
    88b4:      	b	0x8cb8 <generic_rawtp_filter_arg+0x2ec8>
    88b8:      	cmp	w8, #0x1
    88bc:      	b.le	0x8918 <generic_rawtp_filter_arg+0x2b28>
    88c0:      	cmp	w8, #0x2
    88c4:      	b.eq	0x8c80 <generic_rawtp_filter_arg+0x2e90>
    88c8:      	cmp	w8, #0x3
    88cc:      	b.eq	0x8c44 <generic_rawtp_filter_arg+0x2e54>
    88d0:      	cmp	w8, #0x4
    88d4:      	b.ne	0x8ce4 <generic_rawtp_filter_arg+0x2ef4>
    88d8:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    88dc:      	mov	w8, #0x1                // =1
    88e0:      	add	x9, sp, #0x60
    88e4:      	ldr	x0, [x0]
    88e8:      	b	0x8cb8 <generic_rawtp_filter_arg+0x2ec8>
    88ec:      	cmp	w8, #0x8
    88f0:      	b.eq	0x8ca8 <generic_rawtp_filter_arg+0x2eb8>
    88f4:      	cmp	w8, #0x9
    88f8:      	b.eq	0x8c6c <generic_rawtp_filter_arg+0x2e7c>
    88fc:      	cmp	w8, #0xa
    8900:      	b.ne	0x8ce4 <generic_rawtp_filter_arg+0x2ef4>
    8904:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8908:      	mov	w8, #0x1                // =1
    890c:      	add	x9, sp, #0x60
    8910:      	ldr	x0, [x0]
    8914:      	b	0x8cb8 <generic_rawtp_filter_arg+0x2ec8>
    8918:      	cbz	w8, 0x8c30 <generic_rawtp_filter_arg+0x2e40>
    891c:      	cmp	w8, #0x1
    8920:      	b.ne	0x8ce4 <generic_rawtp_filter_arg+0x2ef4>
    8924:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8928:      	mov	w8, #0x1                // =1
    892c:      	add	x9, sp, #0x60
    8930:      	ldr	x0, [x0]
    8934:      	b	0x8cb8 <generic_rawtp_filter_arg+0x2ec8>
    8938:      	cmp	w12, w10
    893c:      	ccmp	w10, w11, #0x2, ls
    8940:      	cset	w9, ls
    8944:      	orr	w8, w8, w9
    8948:      	mov	w12, #0x1               // =1
    894c:      	tbz	w8, #0x0, 0x6088 <generic_rawtp_filter_arg+0x298>
    8950:      	b	0x5eec <generic_rawtp_filter_arg+0xfc>
    8954:      	ldr	x12, [x25]
    8958:      	cmp	x12, x11
    895c:      	mov	w12, #0x1               // =1
    8960:      	b.hi	0x6088 <generic_rawtp_filter_arg+0x298>
    8964:      	b	0x8978 <generic_rawtp_filter_arg+0x2b88>
    8968:      	ldr	x12, [x25]
    896c:      	cmp	x12, x11
    8970:      	mov	w12, #0x1               // =1
    8974:      	b.lo	0x6088 <generic_rawtp_filter_arg+0x298>
    8978:      	cmp	w10, #0x21
    897c:      	b.lo	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    8980:      	ldr	x10, [x23, #0x28]
    8984:      	cmp	w8, #0x2
    8988:      	b.le	0x89b8 <generic_rawtp_filter_arg+0x2bc8>
    898c:      	sub	w9, w8, #0x3
    8990:      	cmp	w9, #0x2
    8994:      	b.lo	0x89e8 <generic_rawtp_filter_arg+0x2bf8>
    8998:      	cmp	w8, #0x6
    899c:      	b.eq	0x6088 <generic_rawtp_filter_arg+0x298>
    89a0:      	cmp	w8, #0xc
    89a4:      	b.ne	0x5eec <generic_rawtp_filter_arg+0xfc>
    89a8:      	ldr	x9, [x25]
    89ac:      	tst	x9, x10
    89b0:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    89b4:      	b	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    89b8:      	cmp	w8, #0x1
    89bc:      	b.eq	0x8af8 <generic_rawtp_filter_arg+0x2d08>
    89c0:      	cmp	w8, #0x2
    89c4:      	b.ne	0x5eec <generic_rawtp_filter_arg+0xfc>
    89c8:      	cmp	w9, #0xc
    89cc:      	b.eq	0x89d8 <generic_rawtp_filter_arg+0x2be8>
    89d0:      	cmp	w9, #0xa
    89d4:      	b.ne	0x90a0 <generic_rawtp_filter_arg+0x32b0>
    89d8:      	ldr	x9, [x25]
    89dc:      	cmp	x9, x10
    89e0:      	b.lt	0x6088 <generic_rawtp_filter_arg+0x298>
    89e4:      	b	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    89e8:      	ldr	x9, [x25]
    89ec:      	cmp	x9, x10
    89f0:      	b.ne	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    89f4:      	b	0x607c <generic_rawtp_filter_arg+0x28c>
    89f8:      	cmp	w8, #0xc
    89fc:      	b.ne	0x8d04 <generic_rawtp_filter_arg+0x2f14>
    8a00:      	ldrb	w11, [x25]
    8a04:      	tst	w10, w11
    8a08:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    8a0c:      	b	0x8d04 <generic_rawtp_filter_arg+0x2f14>
    8a10:      	cmp	w8, #0xc
    8a14:      	b.ne	0x8d48 <generic_rawtp_filter_arg+0x2f58>
    8a18:      	ldrh	w11, [x25]
    8a1c:      	tst	w10, w11
    8a20:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    8a24:      	b	0x8d48 <generic_rawtp_filter_arg+0x2f58>
    8a28:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8a2c:      	mov	w8, #0x1                // =1
    8a30:      	add	x9, sp, #0x60
    8a34:      	ldr	x0, [x0]
    8a38:      	b	0x8ab0 <generic_rawtp_filter_arg+0x2cc0>
    8a3c:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8a40:      	mov	w8, #0x1                // =1
    8a44:      	add	x9, sp, #0x60
    8a48:      	ldr	x0, [x0]
    8a4c:      	b	0x8ab0 <generic_rawtp_filter_arg+0x2cc0>
    8a50:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8a54:      	mov	w8, #0x1                // =1
    8a58:      	add	x9, sp, #0x60
    8a5c:      	ldr	x0, [x0]
    8a60:      	b	0x8ab0 <generic_rawtp_filter_arg+0x2cc0>
    8a64:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8a68:      	mov	w8, #0x1                // =1
    8a6c:      	add	x9, sp, #0x60
    8a70:      	ldr	x0, [x0]
    8a74:      	b	0x8ab0 <generic_rawtp_filter_arg+0x2cc0>
    8a78:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8a7c:      	mov	w8, #0x1                // =1
    8a80:      	add	x9, sp, #0x60
    8a84:      	ldr	x0, [x0]
    8a88:      	b	0x8ab0 <generic_rawtp_filter_arg+0x2cc0>
    8a8c:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8a90:      	mov	w8, #0x1                // =1
    8a94:      	add	x9, sp, #0x60
    8a98:      	ldr	x0, [x0]
    8a9c:      	b	0x8ab0 <generic_rawtp_filter_arg+0x2cc0>
    8aa0:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8aa4:      	mov	w8, #0x1                // =1
    8aa8:      	add	x9, sp, #0x60
    8aac:      	ldr	x0, [x0]
    8ab0:      	add	x1, sp, #0x60
    8ab4:      	blr	x8
    8ab8:      	cbz	x0, 0x8bd0 <generic_rawtp_filter_arg+0x2de0>
    8abc:      	mov	w8, #0x1                // =1
    8ac0:      	mov	x1, x25
    8ac4:      	blr	x8
    8ac8:      	cmp	x0, #0x0
    8acc:      	cset	w22, ne
    8ad0:      	b	0x8bd4 <generic_rawtp_filter_arg+0x2de4>
    8ad4:      	cmp	w8, #0x401
    8ad8:      	b.hs	0x8e4c <generic_rawtp_filter_arg+0x305c>
    8adc:      	mov	w11, #0x400             // =1024
    8ae0:      	b	0x8e60 <generic_rawtp_filter_arg+0x3070>
    8ae4:      	cmp	w11, w8
    8ae8:      	b.hi	0x5eec <generic_rawtp_filter_arg+0xfc>
    8aec:      	cmp	w8, w10
    8af0:      	b.ls	0x6088 <generic_rawtp_filter_arg+0x298>
    8af4:      	b	0x5eec <generic_rawtp_filter_arg+0xfc>
    8af8:      	cmp	w9, #0xc
    8afc:      	b.eq	0x8b08 <generic_rawtp_filter_arg+0x2d18>
    8b00:      	cmp	w9, #0xa
    8b04:      	b.ne	0x90b0 <generic_rawtp_filter_arg+0x32c0>
    8b08:      	ldr	x9, [x25]
    8b0c:      	cmp	x9, x10
    8b10:      	b.gt	0x6088 <generic_rawtp_filter_arg+0x298>
    8b14:      	b	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    8b18:      	ldr	x19, [sp, #0x30]
    8b1c:      	mov	w12, #0x1               // =1
    8b20:      	b	0x7be4 <generic_rawtp_filter_arg+0x1df4>
    8b24:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8b28:      	mov	w8, #0x1                // =1
    8b2c:      	add	x9, sp, #0x60
    8b30:      	ldr	x0, [x0]
    8b34:      	b	0x8bac <generic_rawtp_filter_arg+0x2dbc>
    8b38:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8b3c:      	mov	w8, #0x1                // =1
    8b40:      	add	x9, sp, #0x60
    8b44:      	ldr	x0, [x0]
    8b48:      	b	0x8bac <generic_rawtp_filter_arg+0x2dbc>
    8b4c:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8b50:      	mov	w8, #0x1                // =1
    8b54:      	add	x9, sp, #0x60
    8b58:      	ldr	x0, [x0]
    8b5c:      	b	0x8bac <generic_rawtp_filter_arg+0x2dbc>
    8b60:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8b64:      	mov	w8, #0x1                // =1
    8b68:      	add	x9, sp, #0x60
    8b6c:      	ldr	x0, [x0]
    8b70:      	b	0x8bac <generic_rawtp_filter_arg+0x2dbc>
    8b74:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8b78:      	mov	w8, #0x1                // =1
    8b7c:      	add	x9, sp, #0x60
    8b80:      	ldr	x0, [x0]
    8b84:      	b	0x8bac <generic_rawtp_filter_arg+0x2dbc>
    8b88:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8b8c:      	mov	w8, #0x1                // =1
    8b90:      	add	x9, sp, #0x60
    8b94:      	ldr	x0, [x0]
    8b98:      	b	0x8bac <generic_rawtp_filter_arg+0x2dbc>
    8b9c:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8ba0:      	mov	w8, #0x1                // =1
    8ba4:      	add	x9, sp, #0x60
    8ba8:      	ldr	x0, [x0]
    8bac:      	add	x1, sp, #0x60
    8bb0:      	blr	x8
    8bb4:      	cbz	x0, 0x8bd0 <generic_rawtp_filter_arg+0x2de0>
    8bb8:      	ldr	x1, [sp, #0x8]
    8bbc:      	mov	w8, #0x1                // =1
    8bc0:      	blr	x8
    8bc4:      	cmp	x0, #0x0
    8bc8:      	cset	w22, ne
    8bcc:      	b	0x8bd4 <generic_rawtp_filter_arg+0x2de4>
    8bd0:      	mov	x22, xzr
    8bd4:      	ldp	x16, x15, [sp, #0x40]
    8bd8:      	mov	w2, #0x5ea0             // =24224
    8bdc:      	mov	w12, #0x1               // =1
    8be0:      	ldr	x17, [sp, #0x38]
    8be4:      	ldr	w8, [x23, #0x4]
    8be8:      	cmp	w8, #0x25
    8bec:      	b.hi	0x6084 <generic_rawtp_filter_arg+0x294>
    8bf0:      	mov	x9, #0x50               // =80
    8bf4:      	lsl	x8, x12, x8
    8bf8:      	movk	x9, #0xc00, lsl #16
    8bfc:      	movk	x9, #0x20, lsl #32
    8c00:      	tst	x8, x9
    8c04:      	b.eq	0x6084 <generic_rawtp_filter_arg+0x294>
    8c08:      	eor	x22, x22, #0x1
    8c0c:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    8c10:      	ldp	x16, x15, [sp, #0x40]
    8c14:      	mov	x22, xzr
    8c18:      	mov	w2, #0x5ea0             // =24224
    8c1c:      	ldr	x17, [sp, #0x38]
    8c20:      	ldr	w8, [x23, #0x4]
    8c24:      	cmp	w8, #0x25
    8c28:      	b.ls	0x8bf0 <generic_rawtp_filter_arg+0x2e00>
    8c2c:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    8c30:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8c34:      	mov	w8, #0x1                // =1
    8c38:      	add	x9, sp, #0x60
    8c3c:      	ldr	x0, [x0]
    8c40:      	b	0x8cb8 <generic_rawtp_filter_arg+0x2ec8>
    8c44:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8c48:      	mov	w8, #0x1                // =1
    8c4c:      	add	x9, sp, #0x60
    8c50:      	ldr	x0, [x0]
    8c54:      	b	0x8cb8 <generic_rawtp_filter_arg+0x2ec8>
    8c58:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8c5c:      	mov	w8, #0x1                // =1
    8c60:      	add	x9, sp, #0x60
    8c64:      	ldr	x0, [x0]
    8c68:      	b	0x8cb8 <generic_rawtp_filter_arg+0x2ec8>
    8c6c:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8c70:      	mov	w8, #0x1                // =1
    8c74:      	add	x9, sp, #0x60
    8c78:      	ldr	x0, [x0]
    8c7c:      	b	0x8cb8 <generic_rawtp_filter_arg+0x2ec8>
    8c80:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8c84:      	mov	w8, #0x1                // =1
    8c88:      	add	x9, sp, #0x60
    8c8c:      	ldr	x0, [x0]
    8c90:      	b	0x8cb8 <generic_rawtp_filter_arg+0x2ec8>
    8c94:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8c98:      	mov	w8, #0x1                // =1
    8c9c:      	add	x9, sp, #0x60
    8ca0:      	ldr	x0, [x0]
    8ca4:      	b	0x8cb8 <generic_rawtp_filter_arg+0x2ec8>
    8ca8:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8cac:      	mov	w8, #0x1                // =1
    8cb0:      	add	x9, sp, #0x60
    8cb4:      	ldr	x0, [x0]
    8cb8:      	add	x1, sp, #0x60
    8cbc:      	blr	x8
    8cc0:      	cbz	x0, 0x8cdc <generic_rawtp_filter_arg+0x2eec>
    8cc4:      	mov	w8, #0x1                // =1
    8cc8:      	mov	x1, x25
    8ccc:      	blr	x8
    8cd0:      	cmp	x0, #0x0
    8cd4:      	cset	w22, ne
    8cd8:      	b	0x70a0 <generic_rawtp_filter_arg+0x12b0>
    8cdc:      	mov	x22, xzr
    8ce0:      	b	0x70a0 <generic_rawtp_filter_arg+0x12b0>
    8ce4:      	ldp	x16, x15, [sp, #0x40]
    8ce8:      	mov	x22, xzr
    8cec:      	mov	w2, #0x5ea0             // =24224
    8cf0:      	ldr	x17, [sp, #0x38]
    8cf4:      	b	0x70b0 <generic_rawtp_filter_arg+0x12c0>
    8cf8:      	ldrb	w11, [x25]
    8cfc:      	cmp	w10, w11
    8d00:      	b.lo	0x6088 <generic_rawtp_filter_arg+0x298>
    8d04:      	cmp	w9, #0x15
    8d08:      	b.lo	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    8d0c:      	ldr	w9, [x23, #0x1c]
    8d10:      	cmp	w8, #0x2
    8d14:      	b.le	0x9058 <generic_rawtp_filter_arg+0x3268>
    8d18:      	sub	w10, w8, #0x3
    8d1c:      	cmp	w10, #0x2
    8d20:      	b.lo	0x9088 <generic_rawtp_filter_arg+0x3298>
    8d24:      	cmp	w8, #0x6
    8d28:      	b.eq	0x6088 <generic_rawtp_filter_arg+0x298>
    8d2c:      	cmp	w8, #0xc
    8d30:      	b.ne	0x5eec <generic_rawtp_filter_arg+0xfc>
    8d34:      	ldrb	w10, [x25]
    8d38:      	b	0x8dd8 <generic_rawtp_filter_arg+0x2fe8>
    8d3c:      	ldrh	w11, [x25]
    8d40:      	cmp	w10, w11
    8d44:      	b.lo	0x6088 <generic_rawtp_filter_arg+0x298>
    8d48:      	cmp	w9, #0x15
    8d4c:      	b.lo	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    8d50:      	ldr	w9, [x23, #0x1c]
    8d54:      	cmp	w8, #0x2
    8d58:      	b.le	0x9070 <generic_rawtp_filter_arg+0x3280>
    8d5c:      	sub	w10, w8, #0x3
    8d60:      	cmp	w10, #0x2
    8d64:      	b.lo	0x9090 <generic_rawtp_filter_arg+0x32a0>
    8d68:      	cmp	w8, #0x6
    8d6c:      	b.eq	0x6088 <generic_rawtp_filter_arg+0x298>
    8d70:      	cmp	w8, #0xc
    8d74:      	b.ne	0x5eec <generic_rawtp_filter_arg+0xfc>
    8d78:      	ldrh	w10, [x25]
    8d7c:      	b	0x8dd8 <generic_rawtp_filter_arg+0x2fe8>
    8d80:      	ldr	w12, [x25]
    8d84:      	cmp	w12, w11
    8d88:      	mov	w12, #0x1               // =1
    8d8c:      	b.hi	0x6088 <generic_rawtp_filter_arg+0x298>
    8d90:      	b	0x8da4 <generic_rawtp_filter_arg+0x2fb4>
    8d94:      	ldr	w12, [x25]
    8d98:      	cmp	w12, w11
    8d9c:      	mov	w12, #0x1               // =1
    8da0:      	b.lo	0x6088 <generic_rawtp_filter_arg+0x298>
    8da4:      	cmp	w10, #0x15
    8da8:      	b.lo	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    8dac:      	ldr	w10, [x23, #0x1c]
    8db0:      	cmp	w8, #0x2
    8db4:      	b.le	0x8de4 <generic_rawtp_filter_arg+0x2ff4>
    8db8:      	sub	w9, w8, #0x3
    8dbc:      	cmp	w9, #0x2
    8dc0:      	b.lo	0x8e1c <generic_rawtp_filter_arg+0x302c>
    8dc4:      	cmp	w8, #0x6
    8dc8:      	b.eq	0x6088 <generic_rawtp_filter_arg+0x298>
    8dcc:      	cmp	w8, #0xc
    8dd0:      	b.ne	0x5eec <generic_rawtp_filter_arg+0xfc>
    8dd4:      	ldr	w9, [x25]
    8dd8:      	tst	w9, w10
    8ddc:      	b.ne	0x6088 <generic_rawtp_filter_arg+0x298>
    8de0:      	b	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    8de4:      	cmp	w8, #0x1
    8de8:      	b.eq	0x8e24 <generic_rawtp_filter_arg+0x3034>
    8dec:      	cmp	w8, #0x2
    8df0:      	b.ne	0x5eec <generic_rawtp_filter_arg+0xfc>
    8df4:      	cmp	w9, #0xc
    8df8:      	b.hi	0x91c8 <generic_rawtp_filter_arg+0x33d8>
    8dfc:      	lsl	w9, w12, w9
    8e00:      	mov	w11, #0x1402            // =5122
    8e04:      	tst	w9, w11
    8e08:      	b.eq	0x91c8 <generic_rawtp_filter_arg+0x33d8>
    8e0c:      	ldr	w9, [x25]
    8e10:      	cmp	w9, w10
    8e14:      	b.lt	0x6088 <generic_rawtp_filter_arg+0x298>
    8e18:      	b	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    8e1c:      	ldr	w9, [x25]
    8e20:      	b	0x9094 <generic_rawtp_filter_arg+0x32a4>
    8e24:      	cmp	w9, #0xc
    8e28:      	b.hi	0x91d8 <generic_rawtp_filter_arg+0x33e8>
    8e2c:      	lsl	w9, w12, w9
    8e30:      	mov	w11, #0x1402            // =5122
    8e34:      	tst	w9, w11
    8e38:      	b.eq	0x91d8 <generic_rawtp_filter_arg+0x33e8>
    8e3c:      	ldr	w9, [x25]
    8e40:      	cmp	w9, w10
    8e44:      	b.gt	0x6088 <generic_rawtp_filter_arg+0x298>
    8e48:      	b	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    8e4c:      	and	w8, w25, #0xffff
    8e50:      	mov	w9, #0x1000             // =4096
    8e54:      	cmp	w8, #0x800
    8e58:      	mov	w8, #0x800              // =2048
    8e5c:      	csel	w11, w9, w8, hi
    8e60:      	sub	w8, w11, #0x100
    8e64:      	ror	w8, w8, #0x8
    8e68:      	cmp	w8, #0x2
    8e6c:      	b.gt	0x8e84 <generic_rawtp_filter_arg+0x3094>
    8e70:      	cbz	w8, 0x8ea4 <generic_rawtp_filter_arg+0x30b4>
    8e74:      	cmp	w8, #0x1
    8e78:      	b.ne	0x8e9c <generic_rawtp_filter_arg+0x30ac>
    8e7c:      	mov	w10, #0x7               // =7
    8e80:      	b	0x8eb0 <generic_rawtp_filter_arg+0x30c0>
    8e84:      	cmp	w8, #0x3
    8e88:      	b.eq	0x8eac <generic_rawtp_filter_arg+0x30bc>
    8e8c:      	cmp	w8, #0x7
    8e90:      	b.ne	0x8e9c <generic_rawtp_filter_arg+0x30ac>
    8e94:      	mov	w10, #0x9               // =9
    8e98:      	b	0x8eb0 <generic_rawtp_filter_arg+0x30c0>
    8e9c:      	mov	w10, #0xa               // =10
    8ea0:      	b	0x8eb0 <generic_rawtp_filter_arg+0x30c0>
    8ea4:      	mov	w10, #0x6               // =6
    8ea8:      	b	0x8eb0 <generic_rawtp_filter_arg+0x30c0>
    8eac:      	mov	w10, #0x8               // =8
    8eb0:      	add	x8, x23, #0x10
    8eb4:      	and	w9, w10, #0xf
    8eb8:      	ldr	w8, [x8, w9, uxtw #2]
    8ebc:      	cmn	w8, #0x1
    8ec0:      	b.eq	0x916c <generic_rawtp_filter_arg+0x337c>
    8ec4:      	stp	w8, w11, [sp, #0x1c]
    8ec8:      	str	w10, [sp, #0x28]
    8ecc:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8ed0:      	mov	w8, #0x1                // =1
    8ed4:      	add	x19, sp, #0x88
    8ed8:      	add	x1, sp, #0x88
    8edc:      	ldr	x0, [x0]
    8ee0:      	blr	x8
    8ee4:      	mov	x9, x0
    8ee8:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8eec:      	mov	w8, #0x1                // =1
    8ef0:      	ldr	x0, [x0]
    8ef4:      	add	x1, sp, #0x88
    8ef8:      	mov	x19, x9
    8efc:      	blr	x8
    8f00:      	mov	x22, xzr
    8f04:      	cbz	x19, 0x9170 <generic_rawtp_filter_arg+0x3380>
    8f08:      	mov	w12, #0x1               // =1
    8f0c:      	cbz	x0, 0x9174 <generic_rawtp_filter_arg+0x3384>
    8f10:      	ldr	w22, [sp, #0x28]
    8f14:      	str	x0, [sp, #0x10]
    8f18:      	mov	x0, x19
    8f1c:      	cmp	w22, #0x5
    8f20:      	b.gt	0x8f5c <generic_rawtp_filter_arg+0x316c>
    8f24:      	strb	w25, [x0], #0x1
    8f28:      	mov	w8, #0x4                // =4
    8f2c:      	mov	w1, w25
    8f30:      	mov	x2, x29
    8f34:      	blr	x8
    8f38:      	ldr	w8, [sp, #0x20]
    8f3c:      	subs	w8, w8, w25
    8f40:      	b.ls	0x8f94 <generic_rawtp_filter_arg+0x31a4>
    8f44:      	add	x9, x19, x25
    8f48:      	and	w1, w8, #0xfff
    8f4c:      	mov	w8, #0x4                // =4
    8f50:      	ldr	x2, [sp, #0x10]
    8f54:      	add	x0, x9, #0x1
    8f58:      	b	0x8f90 <generic_rawtp_filter_arg+0x31a0>
    8f5c:      	strh	w25, [x0], #0x2
    8f60:      	mov	w8, #0x4                // =4
    8f64:      	mov	w1, w25
    8f68:      	mov	x2, x29
    8f6c:      	blr	x8
    8f70:      	ldr	w8, [sp, #0x20]
    8f74:      	subs	w8, w8, w25
    8f78:      	b.ls	0x8f94 <generic_rawtp_filter_arg+0x31a4>
    8f7c:      	add	x9, x19, x25
    8f80:      	ldr	x2, [sp, #0x10]
    8f84:      	and	w1, w8, #0xfff
    8f88:      	mov	w8, #0x4                // =4
    8f8c:      	add	x0, x9, #0x2
    8f90:      	blr	x8
    8f94:      	ldr	w8, [sp, #0x1c]
    8f98:      	cmp	w22, #0x4
    8f9c:      	str	w8, [sp, #0x60]
    8fa0:      	b.le	0x8fd8 <generic_rawtp_filter_arg+0x31e8>
    8fa4:      	cmp	w22, #0x7
    8fa8:      	b.gt	0x900c <generic_rawtp_filter_arg+0x321c>
    8fac:      	cmp	w22, #0x5
    8fb0:      	b.eq	0x9124 <generic_rawtp_filter_arg+0x3334>
    8fb4:      	cmp	w22, #0x6
    8fb8:      	b.eq	0x90e8 <generic_rawtp_filter_arg+0x32f8>
    8fbc:      	cmp	w22, #0x7
    8fc0:      	b.ne	0x916c <generic_rawtp_filter_arg+0x337c>
    8fc4:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8fc8:      	mov	w8, #0x1                // =1
    8fcc:      	add	x9, sp, #0x60
    8fd0:      	ldr	x0, [x0]
    8fd4:      	b	0x9148 <generic_rawtp_filter_arg+0x3358>
    8fd8:      	cmp	w22, #0x1
    8fdc:      	b.le	0x9038 <generic_rawtp_filter_arg+0x3248>
    8fe0:      	cmp	w22, #0x2
    8fe4:      	b.eq	0x9110 <generic_rawtp_filter_arg+0x3320>
    8fe8:      	cmp	w22, #0x3
    8fec:      	b.eq	0x90d4 <generic_rawtp_filter_arg+0x32e4>
    8ff0:      	cmp	w22, #0x4
    8ff4:      	b.ne	0x916c <generic_rawtp_filter_arg+0x337c>
    8ff8:      	adrp	x0, 0x8000 <generic_rawtp_filter_arg+0x2210>
    8ffc:      	mov	w8, #0x1                // =1
    9000:      	add	x9, sp, #0x60
    9004:      	ldr	x0, [x0]
    9008:      	b	0x9148 <generic_rawtp_filter_arg+0x3358>
    900c:      	cmp	w22, #0x8
    9010:      	b.eq	0x9138 <generic_rawtp_filter_arg+0x3348>
    9014:      	cmp	w22, #0x9
    9018:      	b.eq	0x90fc <generic_rawtp_filter_arg+0x330c>
    901c:      	cmp	w22, #0xa
    9020:      	b.ne	0x916c <generic_rawtp_filter_arg+0x337c>
    9024:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9028:      	mov	w8, #0x1                // =1
    902c:      	add	x9, sp, #0x60
    9030:      	ldr	x0, [x0]
    9034:      	b	0x9148 <generic_rawtp_filter_arg+0x3358>
    9038:      	cbz	w22, 0x90c0 <generic_rawtp_filter_arg+0x32d0>
    903c:      	cmp	w22, #0x1
    9040:      	b.ne	0x916c <generic_rawtp_filter_arg+0x337c>
    9044:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9048:      	mov	w8, #0x1                // =1
    904c:      	add	x9, sp, #0x60
    9050:      	ldr	x0, [x0]
    9054:      	b	0x9148 <generic_rawtp_filter_arg+0x3358>
    9058:      	cmp	w8, #0x1
    905c:      	b.eq	0x91b8 <generic_rawtp_filter_arg+0x33c8>
    9060:      	cmp	w8, #0x2
    9064:      	b.ne	0x5eec <generic_rawtp_filter_arg+0xfc>
    9068:      	ldrb	w10, [x25]
    906c:      	b	0x91dc <generic_rawtp_filter_arg+0x33ec>
    9070:      	cmp	w8, #0x1
    9074:      	b.eq	0x91c0 <generic_rawtp_filter_arg+0x33d0>
    9078:      	cmp	w8, #0x2
    907c:      	b.ne	0x5eec <generic_rawtp_filter_arg+0xfc>
    9080:      	ldrh	w10, [x25]
    9084:      	b	0x91dc <generic_rawtp_filter_arg+0x33ec>
    9088:      	ldrb	w10, [x25]
    908c:      	b	0x9094 <generic_rawtp_filter_arg+0x32a4>
    9090:      	ldrh	w10, [x25]
    9094:      	cmp	w9, w10
    9098:      	b.eq	0x607c <generic_rawtp_filter_arg+0x28c>
    909c:      	b	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    90a0:      	ldr	x9, [x25]
    90a4:      	cmp	x9, x10
    90a8:      	b.lo	0x6088 <generic_rawtp_filter_arg+0x298>
    90ac:      	b	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    90b0:      	ldr	x9, [x25]
    90b4:      	cmp	x9, x10
    90b8:      	b.hi	0x6088 <generic_rawtp_filter_arg+0x298>
    90bc:      	b	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    90c0:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    90c4:      	mov	w8, #0x1                // =1
    90c8:      	add	x9, sp, #0x60
    90cc:      	ldr	x0, [x0]
    90d0:      	b	0x9148 <generic_rawtp_filter_arg+0x3358>
    90d4:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    90d8:      	mov	w8, #0x1                // =1
    90dc:      	add	x9, sp, #0x60
    90e0:      	ldr	x0, [x0]
    90e4:      	b	0x9148 <generic_rawtp_filter_arg+0x3358>
    90e8:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    90ec:      	mov	w8, #0x1                // =1
    90f0:      	add	x9, sp, #0x60
    90f4:      	ldr	x0, [x0]
    90f8:      	b	0x9148 <generic_rawtp_filter_arg+0x3358>
    90fc:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9100:      	mov	w8, #0x1                // =1
    9104:      	add	x9, sp, #0x60
    9108:      	ldr	x0, [x0]
    910c:      	b	0x9148 <generic_rawtp_filter_arg+0x3358>
    9110:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9114:      	mov	w8, #0x1                // =1
    9118:      	add	x9, sp, #0x60
    911c:      	ldr	x0, [x0]
    9120:      	b	0x9148 <generic_rawtp_filter_arg+0x3358>
    9124:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9128:      	mov	w8, #0x1                // =1
    912c:      	add	x9, sp, #0x60
    9130:      	ldr	x0, [x0]
    9134:      	b	0x9148 <generic_rawtp_filter_arg+0x3358>
    9138:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    913c:      	mov	w8, #0x1                // =1
    9140:      	add	x9, sp, #0x60
    9144:      	ldr	x0, [x0]
    9148:      	add	x1, sp, #0x60
    914c:      	blr	x8
    9150:      	cbz	x0, 0x916c <generic_rawtp_filter_arg+0x337c>
    9154:      	mov	w8, #0x1                // =1
    9158:      	mov	x1, x19
    915c:      	blr	x8
    9160:      	cmp	x0, #0x0
    9164:      	cset	w22, ne
    9168:      	b	0x9170 <generic_rawtp_filter_arg+0x3380>
    916c:      	mov	x22, xzr
    9170:      	mov	w12, #0x1               // =1
    9174:      	ldr	w8, [x23, #0x4]
    9178:      	ldp	x16, x15, [sp, #0x40]
    917c:      	mov	w2, #0x5ea0             // =24224
    9180:      	cmp	w8, #0x25
    9184:      	ldr	x17, [sp, #0x38]
    9188:      	b.hi	0x91b0 <generic_rawtp_filter_arg+0x33c0>
    918c:      	mov	x9, #0x50               // =80
    9190:      	ldr	x19, [sp, #0x30]
    9194:      	lsl	x8, x12, x8
    9198:      	movk	x9, #0xc00, lsl #16
    919c:      	movk	x9, #0x20, lsl #32
    91a0:      	tst	x8, x9
    91a4:      	b.eq	0x6084 <generic_rawtp_filter_arg+0x294>
    91a8:      	cmp	x22, #0x0
    91ac:      	b	0x6080 <generic_rawtp_filter_arg+0x290>
    91b0:      	ldr	x19, [sp, #0x30]
    91b4:      	b	0x6084 <generic_rawtp_filter_arg+0x294>
    91b8:      	ldrb	w10, [x25]
    91bc:      	b	0x91cc <generic_rawtp_filter_arg+0x33dc>
    91c0:      	ldrh	w10, [x25]
    91c4:      	b	0x91cc <generic_rawtp_filter_arg+0x33dc>
    91c8:      	ldr	w9, [x25]
    91cc:      	cmp	w9, w10
    91d0:      	b.lo	0x6088 <generic_rawtp_filter_arg+0x298>
    91d4:      	b	0x91e4 <generic_rawtp_filter_arg+0x33f4>
    91d8:      	ldr	w9, [x25]
    91dc:      	cmp	w9, w10
    91e0:      	b.hi	0x6088 <generic_rawtp_filter_arg+0x298>
    91e4:      	orr	w8, w8, #0x2
    91e8:      	cmp	w8, #0x6
    91ec:      	b.eq	0x6088 <generic_rawtp_filter_arg+0x298>
    91f0:      	b	0x5eec <generic_rawtp_filter_arg+0xfc>
    91f4:      	nop
    91f8:      	nop
    91fc:      	nop

0000000000009200 <generic_rawtp_actions>:
    9200:      	sub	sp, sp, #0xe0
    9204:      	str	x29, [sp, #0x90]
    9208:      	stp	x30, x25, [sp, #0xa0]
    920c:      	stp	x24, x23, [sp, #0xb0]
    9210:      	stp	x22, x21, [sp, #0xc0]
    9214:      	stp	x20, x19, [sp, #0xd0]
    9218:      	str	x0, [sp, #0x50]
    921c:      	str	wzr, [sp, #0x5c]
    9220:      	adrp	x29, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9224:      	mov	w8, #0x1                // =1
    9228:      	add	x9, sp, #0x5c
    922c:      	add	x1, sp, #0x5c
    9230:      	ldr	x29, [x29]
    9234:      	mov	x0, x29
    9238:      	blr	x8
    923c:      	cbz	x0, 0x9cc4 <generic_rawtp_actions+0xac4>
    9240:      	mov	w8, #0x5f04             // =24324
    9244:      	ldr	w19, [x0, x8]
    9248:      	cmp	w19, #0x2
    924c:      	b.lt	0x9cc4 <generic_rawtp_actions+0xac4>
    9250:      	mov	w8, #0x5ef8             // =24312
    9254:      	add	x1, x0, x8
    9258:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    925c:      	mov	w8, #0x1                // =1
    9260:      	ldr	x0, [x0]
    9264:      	blr	x8
    9268:      	cbz	x0, 0x9cc4 <generic_rawtp_actions+0xac4>
    926c:      	and	x8, x19, #0x7ff
    9270:      	add	x9, sp, #0x60
    9274:      	add	x1, sp, #0x60
    9278:      	ldr	w8, [x0, x8]
    927c:      	str	wzr, [sp, #0x60]
    9280:      	add	w8, w8, w19
    9284:      	and	w8, w8, #0x7ff
    9288:      	add	x21, x0, x8
    928c:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9290:      	mov	w8, #0x1                // =1
    9294:      	ldr	x0, [x0]
    9298:      	blr	x8
    929c:      	cbz	x0, 0x92e4 <generic_rawtp_actions+0xe4>
    92a0:      	ldrb	w8, [x0]
    92a4:      	mov	w11, #0x6               // =6
    92a8:      	mov	w14, #0x7               // =7
    92ac:      	mov	w10, #0x8               // =8
    92b0:      	mov	w12, #0x5               // =5
    92b4:      	mov	w13, #0x9               // =9
    92b8:      	ands	w8, w8, #0xff
    92bc:      	cset	w9, eq
    92c0:      	cmp	w8, #0x0
    92c4:      	str	w9, [sp, #0x48]
    92c8:      	mov	w9, #0x4                // =4
    92cc:      	csel	x8, x11, x14, eq
    92d0:      	csel	x11, x10, x13, eq
    92d4:      	str	x8, [sp, #0x30]
    92d8:      	csel	x8, x9, x12, eq
    92dc:      	stp	x11, x8, [sp, #0x38]
    92e0:      	b	0x9304 <generic_rawtp_actions+0x104>
    92e4:      	mov	w8, #0x1                // =1
    92e8:      	str	w8, [sp, #0x48]
    92ec:      	mov	w8, #0x4                // =4
    92f0:      	str	x8, [sp, #0x40]
    92f4:      	mov	w8, #0x8                // =8
    92f8:      	str	x8, [sp, #0x38]
    92fc:      	mov	w8, #0x6                // =6
    9300:      	str	x8, [sp, #0x30]
    9304:      	adrp	x25, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9308:      	mov	w23, wzr
    930c:      	mov	w19, wzr
    9310:      	ldr	x25, [x25]
    9314:      	add	x20, sp, #0x64
    9318:      	mov	w8, #0x1                // =1
    931c:      	str	w8, [sp, #0x4c]
    9320:      	b	0x9334 <generic_rawtp_actions+0x134>
    9324:      	mov	w19, wzr
    9328:      	add	w23, w23, #0x1
    932c:      	cmp	w23, #0x3
    9330:      	b.eq	0x9ca0 <generic_rawtp_actions+0xaa0>
    9334:      	ldr	w9, [x21]
    9338:      	lsl	w8, w19, #2
    933c:      	add	w8, w8, #0x4
    9340:      	cmp	w8, w9
    9344:      	b.hs	0x9ca0 <generic_rawtp_actions+0xaa0>
    9348:      	add	x8, x21, w19, uxtw #2
    934c:      	add	x1, sp, #0x64
    9350:      	mov	x0, x29
    9354:      	ldrsw	x24, [x8, #0x4]
    9358:      	str	wzr, [sp, #0x64]
    935c:      	mov	w8, #0x1                // =1
    9360:      	blr	x8
    9364:      	cbz	x0, 0x9324 <generic_rawtp_actions+0x124>
    9368:      	mov	x22, x0
    936c:      	cmp	w24, #0x7
    9370:      	b.gt	0x93a0 <generic_rawtp_actions+0x1a0>
    9374:      	cmp	w24, #0x3
    9378:      	b.gt	0x93f0 <generic_rawtp_actions+0x1f0>
    937c:      	cmp	w24, #0x1
    9380:      	b.gt	0x9470 <generic_rawtp_actions+0x270>
    9384:      	cbz	w24, 0x95d4 <generic_rawtp_actions+0x3d4>
    9388:      	cmp	w24, #0x1
    938c:      	b.eq	0x9480 <generic_rawtp_actions+0x280>
    9390:      	adrp	x25, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9394:      	b	0x96d8 <generic_rawtp_actions+0x4d8>
    9398:      	nop
    939c:      	nop
    93a0:      	cmp	w24, #0xb
    93a4:      	b.gt	0x9448 <generic_rawtp_actions+0x248>
    93a8:      	sub	w8, w24, #0xa
    93ac:      	cmp	w8, #0x2
    93b0:      	b.lo	0x94e4 <generic_rawtp_actions+0x2e4>
    93b4:      	cmp	w24, #0x8
    93b8:      	b.eq	0x952c <generic_rawtp_actions+0x32c>
    93bc:      	cmp	w24, #0x9
    93c0:      	b.ne	0x96dc <generic_rawtp_actions+0x4dc>
    93c4:      	add	w19, w19, #0x1
    93c8:      	add	x8, x21, w19, uxtw #2
    93cc:      	ldr	w0, [x8, #0x4]
    93d0:      	ldr	w8, [sp, #0x48]
    93d4:      	add	x25, sp, #0x68
    93d8:      	cbz	w8, 0x967c <generic_rawtp_actions+0x47c>
    93dc:      	sxtw	x8, w0
    93e0:      	mov	w9, #0x6d               // =109
    93e4:      	blr	x9
    93e8:      	mov	w20, #0x2               // =2
    93ec:      	b	0x9690 <generic_rawtp_actions+0x490>
    93f0:      	sub	w8, w24, #0x6
    93f4:      	cmp	w8, #0x2
    93f8:      	b.lo	0x9518 <generic_rawtp_actions+0x318>
    93fc:      	cmp	w24, #0x4
    9400:      	b.eq	0x9534 <generic_rawtp_actions+0x334>
    9404:      	cmp	w24, #0x5
    9408:      	b.ne	0x96dc <generic_rawtp_actions+0x4dc>
    940c:      	add	w8, w19, #0x1
    9410:      	add	x9, x21, #0x4
    9414:      	add	w19, w19, #0x2
    9418:      	ldr	w8, [x9, w8, uxtw #2]
    941c:      	ldr	w20, [x9, w19, uxtw #2]
    9420:      	stp	xzr, xzr, [sp, #0x68]
    9424:      	and	x8, x8, #0x7
    9428:      	cmp	w8, #0x4
    942c:      	b.hi	0x9440 <generic_rawtp_actions+0x240>
    9430:      	add	x9, x22, x8, lsl #2
    9434:      	mov	w10, #0x5ea0            // =24224
    9438:      	ldr	w9, [x9, x10]
    943c:      	cbz	w9, 0x98b8 <generic_rawtp_actions+0x6b8>
    9440:      	add	x20, sp, #0x64
    9444:      	b	0x96dc <generic_rawtp_actions+0x4dc>
    9448:      	cmp	w24, #0xc
    944c:      	b.eq	0x9684 <generic_rawtp_actions+0x484>
    9450:      	cmp	w24, #0xd
    9454:      	b.eq	0x9544 <generic_rawtp_actions+0x344>
    9458:      	cmp	w24, #0xe
    945c:      	b.ne	0x96dc <generic_rawtp_actions+0x4dc>
    9460:      	ldr	x20, [sp, #0x38]
    9464:      	add	x25, sp, #0x68
    9468:      	add	w19, w19, #0x2
    946c:      	b	0x9690 <generic_rawtp_actions+0x490>
    9470:      	cmp	w24, #0x2
    9474:      	b.eq	0x966c <generic_rawtp_actions+0x46c>
    9478:      	cmp	w24, #0x3
    947c:      	b.ne	0x9390 <generic_rawtp_actions+0x190>
    9480:      	add	w8, w19, #0x1
    9484:      	add	x9, x21, #0x4
    9488:      	add	w19, w19, #0x2
    948c:      	ldr	w20, [x9, w19, uxtw #2]
    9490:      	mov	x25, x21
    9494:      	ldr	w21, [x9, w8, uxtw #2]
    9498:      	str	wzr, [sp, #0x78]
    949c:      	stp	xzr, xzr, [sp, #0x68]
    94a0:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    94a4:      	mov	w8, #0x1                // =1
    94a8:      	add	x9, sp, #0x78
    94ac:      	add	x1, sp, #0x78
    94b0:      	ldr	x0, [x0]
    94b4:      	blr	x8
    94b8:      	cbz	x0, 0x94cc <generic_rawtp_actions+0x2cc>
    94bc:      	and	x8, x21, #0x7
    94c0:      	cmp	w8, #0x4
    94c4:      	b.ls	0x96f4 <generic_rawtp_actions+0x4f4>
    94c8:      	mov	w0, wzr
    94cc:      	mov	x21, x25
    94d0:      	adrp	x25, 0x9000 <generic_rawtp_filter_arg+0x3210>
    94d4:      	add	x20, sp, #0x64
    94d8:      	ldr	x25, [x25]
    94dc:      	cbnz	w0, 0x9324 <generic_rawtp_actions+0x124>
    94e0:      	b	0x96dc <generic_rawtp_actions+0x4dc>
    94e4:      	add	w19, w19, #0x1
    94e8:      	add	x8, x21, w19, uxtw #2
    94ec:      	ldr	w8, [x8, #0x4]
    94f0:      	and	x8, x8, #0x7
    94f4:      	cmp	w8, #0x4
    94f8:      	b.hi	0x950c <generic_rawtp_actions+0x30c>
    94fc:      	add	x9, x22, x8, lsl #2
    9500:      	mov	w10, #0x5ea0            // =24224
    9504:      	ldr	w9, [x9, x10]
    9508:      	cbz	w9, 0x9710 <generic_rawtp_actions+0x510>
    950c:      	mov	w0, wzr
    9510:      	cbnz	w0, 0x9324 <generic_rawtp_actions+0x124>
    9514:      	b	0x96dc <generic_rawtp_actions+0x4dc>
    9518:      	add	w19, w19, #0x1
    951c:      	add	x8, x21, w19, uxtw #2
    9520:      	ldr	w8, [x8, #0x4]
    9524:      	str	w8, [x22, #0x78]
    9528:      	b	0x96dc <generic_rawtp_actions+0x4dc>
    952c:      	str	wzr, [sp, #0x4c]
    9530:      	b	0x96dc <generic_rawtp_actions+0x4dc>
    9534:      	ldr	x20, [sp, #0x40]
    9538:      	add	x25, sp, #0x68
    953c:      	add	w19, w19, #0x1
    9540:      	b	0x9690 <generic_rawtp_actions+0x490>
    9544:      	mov	w8, #0xe                // =14
    9548:      	blr	x8
    954c:      	str	x0, [sp, #0x88]
    9550:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9554:      	mov	w8, #0x1                // =1
    9558:      	add	x9, sp, #0x88
    955c:      	ldr	x0, [x0]
    9560:      	add	x1, sp, #0x88
    9564:      	blr	x8
    9568:      	cbz	x0, 0x96dc <generic_rawtp_actions+0x4dc>
    956c:      	ldur	x8, [x0, #0x4]
    9570:      	mov	x20, x21
    9574:      	add	x21, sp, #0x78
    9578:      	add	x1, sp, #0x78
    957c:      	str	x8, [sp, #0x78]
    9580:      	mov	w8, #0x2                // =2
    9584:      	mov	x0, x25
    9588:      	str	w8, [sp, #0x80]
    958c:      	mov	w8, #0x1                // =1
    9590:      	blr	x8
    9594:      	mov	w9, #0x1                // =1
    9598:      	str	w9, [sp, #0x98]
    959c:      	cbz	x0, 0x9848 <generic_rawtp_actions+0x648>
    95a0:      	ldaxr	w8, [x0]
    95a4:      	add	w8, w8, #0x1
    95a8:      	stlxr	w9, w8, [x0]
    95ac:      	cbnz	w9, 0x95a0 <generic_rawtp_actions+0x3a0>
    95b0:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    95b4:      	mov	w8, #0x3                // =3
    95b8:      	add	x9, sp, #0x88
    95bc:      	ldr	x0, [x0]
    95c0:      	add	x1, sp, #0x88
    95c4:      	blr	x8
    95c8:      	mov	x21, x20
    95cc:      	add	x20, sp, #0x64
    95d0:      	b	0x96dc <generic_rawtp_actions+0x4dc>
    95d4:      	add	w8, w19, #0x1
    95d8:      	add	x9, x21, #0x4
    95dc:      	ldr	w25, [x9, w8, uxtw #2]
    95e0:      	add	w8, w19, #0x2
    95e4:      	ldr	w20, [x9, w8, uxtw #2]
    95e8:      	mov	w8, #0x7d               // =125
    95ec:      	blr	x8
    95f0:      	str	x0, [sp, #0x68]
    95f4:      	str	wzr, [sp, #0x88]
    95f8:      	str	x25, [sp, #0x18]
    95fc:      	cbz	w25, 0x9b9c <generic_rawtp_actions+0x99c>
    9600:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9604:      	mov	w8, #0x1                // =1
    9608:      	add	x9, sp, #0x88
    960c:      	ldr	x0, [x0]
    9610:      	add	x1, sp, #0x88
    9614:      	blr	x8
    9618:      	cbz	x0, 0x9b9c <generic_rawtp_actions+0x99c>
    961c:      	mov	x25, x0
    9620:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9624:      	mov	w8, #0x1                // =1
    9628:      	ldr	x0, [x0]
    962c:      	add	x9, sp, #0x88
    9630:      	add	x1, sp, #0x88
    9634:      	blr	x8
    9638:      	ldr	x8, [x22, #0x60]
    963c:      	mov	x2, x0
    9640:      	cmp	w20, #0x2
    9644:      	str	x8, [x25]
    9648:      	ldr	x8, [x22, #0x70]
    964c:      	str	x8, [x25, #0x8]
    9650:      	b.eq	0x99bc <generic_rawtp_actions+0x7bc>
    9654:      	cmp	w20, #0x1
    9658:      	b.eq	0x99b0 <generic_rawtp_actions+0x7b0>
    965c:      	cbnz	w20, 0x9b9c <generic_rawtp_actions+0x99c>
    9660:      	ldr	w8, [x22, #0x7c]
    9664:      	str	x21, [sp, #0x8]
    9668:      	b	0x99c4 <generic_rawtp_actions+0x7c4>
    966c:      	mov	w0, #0x9                // =9
    9670:      	ldr	w8, [sp, #0x48]
    9674:      	add	x25, sp, #0x68
    9678:      	cbnz	w8, 0x93dc <generic_rawtp_actions+0x1dc>
    967c:      	mov	w20, #0x3               // =3
    9680:      	b	0x9690 <generic_rawtp_actions+0x490>
    9684:      	ldr	x20, [sp, #0x30]
    9688:      	add	x25, sp, #0x68
    968c:      	add	w19, w19, #0x3
    9690:      	str	wzr, [sp, #0x68]
    9694:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9698:      	mov	w8, #0x1                // =1
    969c:      	add	x1, sp, #0x68
    96a0:      	ldr	x0, [x0]
    96a4:      	blr	x8
    96a8:      	cbz	x0, 0x96d0 <generic_rawtp_actions+0x4d0>
    96ac:      	add	x8, x0, x20, lsl #3
    96b0:      	nop
    96b4:      	nop
    96b8:      	nop
    96bc:      	nop
    96c0:      	ldaxr	x9, [x8]
    96c4:      	add	x9, x9, #0x1
    96c8:      	stlxr	w10, x9, [x8]
    96cc:      	cbnz	w10, 0x96c0 <generic_rawtp_actions+0x4c0>
    96d0:      	adrp	x25, 0x9000 <generic_rawtp_filter_arg+0x3210>
    96d4:      	add	x20, sp, #0x64
    96d8:      	ldr	x25, [x25]
    96dc:      	add	w19, w19, #0x1
    96e0:      	str	x24, [x22, #0x70]
    96e4:      	add	w23, w23, #0x1
    96e8:      	cmp	w23, #0x3
    96ec:      	b.ne	0x9334 <generic_rawtp_actions+0x134>
    96f0:      	b	0x9ca0 <generic_rawtp_actions+0xaa0>
    96f4:      	add	x9, x22, x8, lsl #2
    96f8:      	mov	w10, #0x5ea0            // =24224
    96fc:      	ldr	w9, [x9, x10]
    9700:      	cbz	w9, 0x97a8 <generic_rawtp_actions+0x5a8>
    9704:      	mov	x21, x25
    9708:      	mov	w0, wzr
    970c:      	b	0x94d0 <generic_rawtp_actions+0x2d0>
    9710:      	add	x8, x22, x8, lsl #3
    9714:      	ldr	x8, [x8, #0x5e78]
    9718:      	and	x8, x8, #0x7ff
    971c:      	add	x8, x22, x8
    9720:      	ldr	x8, [x8, #0xb8]
    9724:      	str	x8, [sp, #0x78]
    9728:      	cbz	x8, 0x950c <generic_rawtp_actions+0x30c>
    972c:      	cmp	w24, #0xa
    9730:      	b.ne	0x9990 <generic_rawtp_actions+0x790>
    9734:      	mov	w8, #0xe                // =14
    9738:      	add	x25, sp, #0x68
    973c:      	mov	x20, x21
    9740:      	blr	x8
    9744:      	lsr	x8, x0, #32
    9748:      	mov	x21, x0
    974c:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9750:      	str	w8, [sp, #0x68]
    9754:      	mov	w8, #0x1                // =1
    9758:      	add	x1, sp, #0x68
    975c:      	ldr	x0, [x0]
    9760:      	blr	x8
    9764:      	cbz	x0, 0x979c <generic_rawtp_actions+0x59c>
    9768:      	ldr	w8, [x0]
    976c:      	mov	x3, xzr
    9770:      	add	x9, sp, #0x78
    9774:      	add	x1, sp, #0x78
    9778:      	stp	w8, w21, [sp, #0x68]
    977c:      	ldr	x8, [x0, #0x8]
    9780:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9784:      	add	x2, sp, #0x68
    9788:      	str	x8, [sp, #0x70]
    978c:      	mov	w8, #0x2                // =2
    9790:      	ldr	x0, [x0]
    9794:      	blr	x8
    9798:      	mov	w0, wzr
    979c:      	adrp	x25, 0x9000 <generic_rawtp_filter_arg+0x3210>
    97a0:      	mov	x21, x20
    97a4:      	b	0x94d4 <generic_rawtp_actions+0x2d4>
    97a8:      	add	x8, x22, x8, lsl #3
    97ac:      	mov	x21, x0
    97b0:      	ldr	x8, [x8, #0x5e78]
    97b4:      	str	wzr, [sp, #0x74]
    97b8:      	and	x8, x8, #0x7ff
    97bc:      	add	x8, x22, x8
    97c0:      	ldr	w8, [x8, #0x90]
    97c4:      	str	w8, [sp, #0x70]
    97c8:      	mov	w8, #0xe                // =14
    97cc:      	blr	x8
    97d0:      	lsr	x8, x0, #32
    97d4:      	cmp	w24, #0x1
    97d8:      	str	x8, [sp, #0x68]
    97dc:      	b.ne	0x9974 <generic_rawtp_actions+0x774>
    97e0:      	and	x8, x20, #0x7
    97e4:      	cmp	w8, #0x4
    97e8:      	b.hi	0x94c8 <generic_rawtp_actions+0x2c8>
    97ec:      	add	x9, x22, x8, lsl #2
    97f0:      	mov	w10, #0x5ea0            // =24224
    97f4:      	add	x20, sp, #0x68
    97f8:      	ldr	w9, [x9, x10]
    97fc:      	cbnz	w9, 0x94c8 <generic_rawtp_actions+0x2c8>
    9800:      	add	x8, x22, x8, lsl #3
    9804:      	mov	x0, x21
    9808:      	ldr	x8, [x8, #0x5e78]
    980c:      	and	x8, x8, #0x7ff
    9810:      	add	x2, x22, x8
    9814:      	ldr	w8, [x2, #0x90]!
    9818:      	and	x8, x8, #0xfff
    981c:      	add	x1, x8, #0x8
    9820:      	mov	w8, #0x4                // =4
    9824:      	blr	x8
    9828:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    982c:      	mov	x3, xzr
    9830:      	mov	w8, #0x2                // =2
    9834:      	ldr	x0, [x0]
    9838:      	add	x1, sp, #0x68
    983c:      	mov	x2, x21
    9840:      	blr	x8
    9844:      	b	0x94c8 <generic_rawtp_actions+0x2c8>
    9848:      	mov	w8, #0x2                // =2
    984c:      	add	x10, sp, #0x98
    9850:      	add	x1, sp, #0x78
    9854:      	add	x2, sp, #0x98
    9858:      	mov	x0, x25
    985c:      	mov	w3, #0x1                // =1
    9860:      	blr	x8
    9864:      	cbz	x0, 0x95b0 <generic_rawtp_actions+0x3b0>
    9868:      	mov	x21, x0
    986c:      	adrp	x25, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9870:      	add	x9, sp, #0x68
    9874:      	add	x1, sp, #0x68
    9878:      	neg	w8, w21
    987c:      	strh	w8, [sp, #0x68]
    9880:      	mov	w8, #0x3                // =3
    9884:      	strh	w8, [sp, #0x6a]
    9888:      	mov	x8, #0x3b               // =59
    988c:      	movk	x8, #0x2, lsl #32
    9890:      	stur	x8, [sp, #0x6c]
    9894:      	mov	w8, #0x1                // =1
    9898:      	ldr	x25, [x25]
    989c:      	mov	x0, x25
    98a0:      	blr	x8
    98a4:      	cbz	x0, 0x9c3c <generic_rawtp_actions+0xa3c>
    98a8:      	ldr	w8, [x0]
    98ac:      	add	w8, w8, #0x1
    98b0:      	str	w8, [x0]
    98b4:      	b	0x9c64 <generic_rawtp_actions+0xa64>
    98b8:      	add	x8, x22, x8, lsl #3
    98bc:      	ldr	x8, [x8, #0x5e78]
    98c0:      	and	x8, x8, #0x7ff
    98c4:      	add	x8, x22, x8
    98c8:      	ldr	w8, [x8, #0x90]
    98cc:      	str	w8, [sp, #0x70]
    98d0:      	mov	w8, #0xe                // =14
    98d4:      	blr	x8
    98d8:      	lsr	x8, x0, #32
    98dc:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    98e0:      	add	x9, sp, #0x68
    98e4:      	str	x8, [sp, #0x68]
    98e8:      	mov	w8, #0x1                // =1
    98ec:      	add	x1, sp, #0x68
    98f0:      	ldr	x0, [x0]
    98f4:      	blr	x8
    98f8:      	cbz	x0, 0x9440 <generic_rawtp_actions+0x240>
    98fc:      	and	x8, x20, #0x7
    9900:      	cmp	w8, #0x4
    9904:      	b.hi	0x9440 <generic_rawtp_actions+0x240>
    9908:      	add	x9, x22, x8, lsl #2
    990c:      	mov	w10, #0x5ea0            // =24224
    9910:      	ldr	w9, [x9, x10]
    9914:      	cbnz	w9, 0x9440 <generic_rawtp_actions+0x240>
    9918:      	add	x8, x22, x8, lsl #3
    991c:      	mov	x20, x21
    9920:      	mov	x21, x0
    9924:      	ldr	x8, [x8, #0x5e78]
    9928:      	str	wzr, [sp, #0x74]
    992c:      	and	x8, x8, #0x7ff
    9930:      	add	x8, x22, x8
    9934:      	ldr	w8, [x8, #0x90]
    9938:      	str	w8, [sp, #0x70]
    993c:      	mov	w8, #0xe                // =14
    9940:      	blr	x8
    9944:      	lsr	x8, x0, #32
    9948:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    994c:      	mov	x3, xzr
    9950:      	str	x8, [sp, #0x68]
    9954:      	mov	w8, #0x2                // =2
    9958:      	add	x9, sp, #0x68
    995c:      	add	x1, sp, #0x68
    9960:      	ldr	x0, [x0]
    9964:      	mov	x2, x21
    9968:      	mov	x21, x20
    996c:      	blr	x8
    9970:      	b	0x9440 <generic_rawtp_actions+0x240>
    9974:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9978:      	mov	w8, #0x3                // =3
    997c:      	add	x9, sp, #0x68
    9980:      	ldr	x0, [x0]
    9984:      	add	x1, sp, #0x68
    9988:      	blr	x8
    998c:      	b	0x94cc <generic_rawtp_actions+0x2cc>
    9990:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9994:      	mov	w8, #0x3                // =3
    9998:      	add	x9, sp, #0x78
    999c:      	ldr	x0, [x0]
    99a0:      	add	x1, sp, #0x78
    99a4:      	blr	x8
    99a8:      	cbnz	w0, 0x9324 <generic_rawtp_actions+0x124>
    99ac:      	b	0x96dc <generic_rawtp_actions+0x4dc>
    99b0:      	ldr	w8, [x22, #0x10]
    99b4:      	str	x21, [sp, #0x8]
    99b8:      	b	0x99c4 <generic_rawtp_actions+0x7c4>
    99bc:      	str	x21, [sp, #0x8]
    99c0:      	mov	x8, xzr
    99c4:      	str	x8, [x25, #0x10]
    99c8:      	str	x25, [sp, #0x10]
    99cc:      	add	x0, x25, #0x18
    99d0:      	mov	w8, #0x4                // =4
    99d4:      	mov	w9, #0xc8               // =200
    99d8:      	mov	w1, #0xc8               // =200
    99dc:      	str	x0, [sp, #0x20]
    99e0:      	blr	x8
    99e4:      	str	wzr, [sp, #0x2c]
    99e8:      	adrp	x25, 0x9000 <generic_rawtp_filter_arg+0x3210>
    99ec:      	mov	w8, #0x5e78             // =24184
    99f0:      	mov	x21, xzr
    99f4:      	ldr	x25, [x25]
    99f8:      	add	x20, x22, x8
    99fc:      	b	0x9a10 <generic_rawtp_actions+0x810>
    9a00:      	add	x21, x21, #0x4
    9a04:      	add	x20, x20, #0x8
    9a08:      	cmp	x21, #0x14
    9a0c:      	b.eq	0x9b38 <generic_rawtp_actions+0x938>
    9a10:      	str	wzr, [sp, #0x78]
    9a14:      	mov	w8, #0x1                // =1
    9a18:      	add	x9, sp, #0x78
    9a1c:      	add	x1, sp, #0x78
    9a20:      	mov	x0, x29
    9a24:      	blr	x8
    9a28:      	cbz	x0, 0x9b38 <generic_rawtp_actions+0x938>
    9a2c:      	mov	w8, #0x5ef8             // =24312
    9a30:      	add	x1, x0, x8
    9a34:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9a38:      	mov	w8, #0x1                // =1
    9a3c:      	ldr	x0, [x0]
    9a40:      	blr	x8
    9a44:      	cbz	x0, 0x9b38 <generic_rawtp_actions+0x938>
    9a48:      	add	x8, x0, x21
    9a4c:      	ldr	w8, [x8, #0x40]
    9a50:      	cmn	w8, #0x1
    9a54:      	b.eq	0x9b38 <generic_rawtp_actions+0x938>
    9a58:      	ldr	x8, [x20]
    9a5c:      	ldr	w9, [x22, #0x4]
    9a60:      	cmp	x8, x9
    9a64:      	b.ge	0x9b38 <generic_rawtp_actions+0x938>
    9a68:      	cmp	x21, #0x10
    9a6c:      	b.eq	0x9acc <generic_rawtp_actions+0x8cc>
    9a70:      	str	wzr, [sp, #0x78]
    9a74:      	mov	w8, #0x1                // =1
    9a78:      	add	x9, sp, #0x78
    9a7c:      	add	x1, sp, #0x78
    9a80:      	mov	x0, x29
    9a84:      	blr	x8
    9a88:      	cbz	x0, 0x9ac8 <generic_rawtp_actions+0x8c8>
    9a8c:      	mov	w8, #0x5ef8             // =24312
    9a90:      	add	x1, x0, x8
    9a94:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9a98:      	mov	w8, #0x1                // =1
    9a9c:      	ldr	x0, [x0]
    9aa0:      	blr	x8
    9aa4:      	cbz	x0, 0x9ac8 <generic_rawtp_actions+0x8c8>
    9aa8:      	add	x8, x0, x21
    9aac:      	ldr	w9, [x8, #0x44]
    9ab0:      	ldr	x8, [x20]
    9ab4:      	cmn	w9, #0x1
    9ab8:      	b.eq	0x9acc <generic_rawtp_actions+0x8cc>
    9abc:      	ldr	w9, [x20, #0x8]
    9ac0:      	sub	w9, w9, w8
    9ac4:      	b	0x9ad8 <generic_rawtp_actions+0x8d8>
    9ac8:      	ldr	x8, [x20]
    9acc:      	ldr	w9, [x22, #0x4]
    9ad0:      	sub	w9, w9, w8
    9ad4:      	add	w9, w9, #0x4
    9ad8:      	cmp	w9, #0x1
    9adc:      	b.lt	0x9a00 <generic_rawtp_actions+0x800>
    9ae0:      	mov	w10, #0x3ffc            // =16380
    9ae4:      	cmp	w9, #0x28
    9ae8:      	add	w8, w8, w10
    9aec:      	mov	w10, #0x28              // =40
    9af0:      	csel	w29, w9, w10, lt
    9af4:      	ldr	w9, [sp, #0x2c]
    9af8:      	and	x8, x8, #0x3fff
    9afc:      	add	x8, x22, x8
    9b00:      	mov	w1, w29
    9b04:      	add	x2, x8, #0x90
    9b08:      	mov	w8, #0x4                // =4
    9b0c:      	and	w25, w9, #0xff
    9b10:      	ldr	x9, [sp, #0x20]
    9b14:      	add	x0, x9, x25
    9b18:      	blr	x8
    9b1c:      	add	w8, w29, w25
    9b20:      	adrp	x25, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9b24:      	adrp	x29, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9b28:      	str	w8, [sp, #0x2c]
    9b2c:      	ldr	x25, [x25]
    9b30:      	ldr	x29, [x29]
    9b34:      	b	0x9a00 <generic_rawtp_actions+0x800>
    9b38:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9b3c:      	mov	w8, #0x1                // =1
    9b40:      	ldr	x0, [x0]
    9b44:      	ldr	x1, [sp, #0x10]
    9b48:      	blr	x8
    9b4c:      	ldr	x21, [sp, #0x8]
    9b50:      	cbz	x0, 0x9b7c <generic_rawtp_actions+0x97c>
    9b54:      	ldr	x9, [sp, #0x68]
    9b58:      	ldr	x11, [sp, #0x18]
    9b5c:      	mov	x10, #-0x4240           // =-16960
    9b60:      	movk	x10, #0xfff0, lsl #16
    9b64:      	ldr	x8, [x0]
    9b68:      	madd	x9, x11, x10, x9
    9b6c:      	cmp	x8, x9
    9b70:      	b.ls	0x9b7c <generic_rawtp_actions+0x97c>
    9b74:      	str	wzr, [sp, #0x4c]
    9b78:      	b	0x9ba4 <generic_rawtp_actions+0x9a4>
    9b7c:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9b80:      	mov	x3, xzr
    9b84:      	mov	w8, #0x2                // =2
    9b88:      	ldr	x0, [x0]
    9b8c:      	ldr	x1, [sp, #0x10]
    9b90:      	add	x9, sp, #0x68
    9b94:      	add	x2, sp, #0x68
    9b98:      	blr	x8
    9b9c:      	adrp	x25, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9ba0:      	ldr	x25, [x25]
    9ba4:      	add	w8, w19, #0x3
    9ba8:      	add	x20, sp, #0x64
    9bac:      	add	x8, x21, w8, uxtw #2
    9bb0:      	ldr	w8, [x8, #0x4]
    9bb4:      	cbz	w8, 0x9be0 <generic_rawtp_actions+0x9e0>
    9bb8:      	ldrb	w8, [x22, #0x1]
    9bbc:      	adrp	x1, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9bc0:      	ldr	x0, [sp, #0x50]
    9bc4:      	mov	x2, xzr
    9bc8:      	orr	w8, w8, #0x2
    9bcc:      	strb	w8, [x22, #0x1]
    9bd0:      	mov	w8, #0x1b               // =27
    9bd4:      	ldr	x1, [x1]
    9bd8:      	blr	x8
    9bdc:      	str	x0, [x22, #0x80]
    9be0:      	add	w8, w19, #0x4
    9be4:      	add	x8, x21, w8, uxtw #2
    9be8:      	ldr	w8, [x8, #0x4]
    9bec:      	cbz	w8, 0x9c1c <generic_rawtp_actions+0xa1c>
    9bf0:      	ldrb	w8, [x22, #0x1]
    9bf4:      	adrp	x1, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9bf8:      	ldr	x0, [sp, #0x50]
    9bfc:      	mov	w9, #0x100              // =256
    9c00:      	mov	w2, #0x100              // =256
    9c04:      	orr	w8, w8, #0x4
    9c08:      	strb	w8, [x22, #0x1]
    9c0c:      	mov	w8, #0x1b               // =27
    9c10:      	ldr	x1, [x1]
    9c14:      	blr	x8
    9c18:      	str	x0, [x22, #0x88]
    9c1c:      	add	w19, w19, #0x5
    9c20:      	add	x8, x21, w19, uxtw #2
    9c24:      	ldr	w8, [x8, #0x4]
    9c28:      	cbz	w8, 0x96dc <generic_rawtp_actions+0x4dc>
    9c2c:      	ldrb	w8, [x22, #0x1]
    9c30:      	orr	w8, w8, #0x8
    9c34:      	strb	w8, [x22, #0x1]
    9c38:      	b	0x96dc <generic_rawtp_actions+0x4dc>
    9c3c:      	mov	w8, #0x1                // =1
    9c40:      	mov	x3, xzr
    9c44:      	add	x9, sp, #0x9c
    9c48:      	str	w8, [sp, #0x9c]
    9c4c:      	mov	w8, #0x2                // =2
    9c50:      	add	x10, sp, #0x68
    9c54:      	add	x1, sp, #0x68
    9c58:      	add	x2, sp, #0x9c
    9c5c:      	mov	x0, x25
    9c60:      	blr	x8
    9c64:      	adrp	x25, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9c68:      	ldr	x25, [x25]
    9c6c:      	cbz	w21, 0x95b0 <generic_rawtp_actions+0x3b0>
    9c70:      	mov	w8, #0x1                // =1
    9c74:      	add	x9, sp, #0x78
    9c78:      	add	x1, sp, #0x78
    9c7c:      	mov	x0, x25
    9c80:      	blr	x8
    9c84:      	cbz	x0, 0x95b0 <generic_rawtp_actions+0x3b0>
    9c88:      	ldr	w8, [sp, #0x98]
    9c8c:      	ldaxr	w9, [x0]
    9c90:      	add	w9, w9, w8
    9c94:      	stlxr	w10, w9, [x0]
    9c98:      	cbnz	w10, 0x9c8c <generic_rawtp_actions+0xa8c>
    9c9c:      	b	0x95b0 <generic_rawtp_actions+0x3b0>
    9ca0:      	ldr	w8, [sp, #0x4c]
    9ca4:      	cbz	w8, 0x9cc4 <generic_rawtp_actions+0xac4>
    9ca8:      	adrp	x1, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9cac:      	mov	w8, #0x5                // =5
    9cb0:      	mov	w9, #0xc                // =12
    9cb4:      	ldr	x1, [x1]
    9cb8:      	ldr	x0, [sp, #0x50]
    9cbc:      	mov	w2, #0x5                // =5
    9cc0:      	blr	x9
    9cc4:      	ldp	x20, x19, [sp, #0xd0]
    9cc8:      	mov	w0, wzr
    9ccc:      	ldr	x29, [sp, #0x90]
    9cd0:      	ldp	x22, x21, [sp, #0xc0]
    9cd4:      	ldp	x24, x23, [sp, #0xb0]
    9cd8:      	ldp	x30, x25, [sp, #0xa0]
    9cdc:      	add	sp, sp, #0xe0
    9ce0:      	ret
    9ce4:      	nop
    9ce8:      	nop
    9cec:      	nop

0000000000009cf0 <generic_rawtp_output>:
    9cf0:      	sub	sp, sp, #0xc0
    9cf4:      	str	x29, [sp, #0x70]
    9cf8:      	stp	x30, x25, [sp, #0x80]
    9cfc:      	stp	x24, x23, [sp, #0x90]
    9d00:      	stp	x22, x21, [sp, #0xa0]
    9d04:      	stp	x20, x19, [sp, #0xb0]
    9d08:      	mov	x20, x0
    9d0c:      	str	wzr, [sp, #0x4]
    9d10:      	adrp	x0, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9d14:      	mov	w8, #0x1                // =1
    9d18:      	ldr	x0, [x0]
    9d1c:      	add	x9, sp, #0x4
    9d20:      	add	x1, sp, #0x4
    9d24:      	blr	x8
    9d28:      	cbz	x0, 0xa2d0 <generic_rawtp_output+0x5e0>
    9d2c:      	adrp	x21, 0x9000 <generic_rawtp_filter_arg+0x3210>
    9d30:      	ldr	x8, [x0, #0x5ee8]
    9d34:      	mov	x19, x0
    9d38:      	ldr	x21, [x21]
    9d3c:      	cbz	x8, 0x9fc8 <generic_rawtp_output+0x2d8>
    9d40:      	mov	w8, #0xe                // =14
    9d44:      	blr	x8
    9d48:      	mov	w8, #0x23               // =35
    9d4c:      	lsr	x22, x0, #32
    9d50:      	blr	x8
    9d54:      	str	w22, [sp, #0x28]
    9d58:      	mov	w8, #0x1                // =1
    9d5c:      	add	x9, sp, #0x28
    9d60:      	mov	x23, x0
    9d64:      	add	x1, sp, #0x28
    9d68:      	mov	x0, x21
    9d6c:      	blr	x8
    9d70:      	cbz	x0, 0x9fc8 <generic_rawtp_output+0x2d8>
    9d74:      	add	x2, x23, #0xb50
    9d78:      	mov	w29, #0x8               // =8
    9d7c:      	add	x8, sp, #0x78
    9d80:      	mov	w9, #0x4                // =4
    9d84:      	mov	x22, x0
    9d88:      	add	x24, x0, #0x28
    9d8c:      	add	x0, sp, #0x78
    9d90:      	mov	w1, #0x8                // =8
    9d94:      	mov	w25, #0x4               // =4
    9d98:      	blr	x9
    9d9c:      	ldr	x8, [sp, #0x78]
    9da0:      	mov	w9, #0x48               // =72
    9da4:      	add	x10, sp, #0x28
    9da8:      	mov	w11, #0x4               // =4
    9dac:      	ldr	x2, [sp, #0x78]
    9db0:      	add	x0, sp, #0x28
    9db4:      	mov	w1, #0x48               // =72
    9db8:      	blr	x11
    9dbc:      	ldr	x8, [sp, #0x30]
    9dc0:      	mov	w9, #0x4                // =4
    9dc4:      	mov	x0, x24
    9dc8:      	mov	w1, #0x4                // =4
    9dcc:      	add	x8, x8, #0x218
    9dd0:      	ldr	x8, [sp, #0x30]
    9dd4:      	add	x2, x8, #0x218
    9dd8:      	blr	x9
    9ddc:      	ldr	x8, [sp, #0x38]
    9de0:      	add	x0, x22, #0x2c
    9de4:      	mov	w9, #0x4                // =4
    9de8:      	mov	w1, #0x4                // =4
    9dec:      	add	x8, x8, #0x4d8
    9df0:      	ldr	x8, [sp, #0x38]
    9df4:      	add	x2, x8, #0x4d8
    9df8:      	blr	x9
    9dfc:      	ldr	x8, [sp, #0x40]
    9e00:      	add	x0, x22, #0x30
    9e04:      	mov	w9, #0x4                // =4
    9e08:      	mov	w1, #0x4                // =4
    9e0c:      	add	x8, x8, #0x58
    9e10:      	ldr	x8, [sp, #0x40]
    9e14:      	add	x2, x8, #0x58
    9e18:      	blr	x9
    9e1c:      	str	xzr, [sp, #0x20]
    9e20:      	add	x2, x23, #0x938
    9e24:      	add	x8, sp, #0x20
    9e28:      	add	x0, sp, #0x20
    9e2c:      	mov	w1, #0x8                // =8
    9e30:      	blr	x25
    9e34:      	ldr	x8, [sp, #0x20]
    9e38:      	cbz	x8, 0x9ebc <generic_rawtp_output+0x1cc>
    9e3c:      	str	wzr, [sp, #0x1c]
    9e40:      	add	x8, x8, #0x4
    9e44:      	add	x9, sp, #0x1c
    9e48:      	mov	w10, #0x4               // =4
    9e4c:      	add	x0, sp, #0x1c
    9e50:      	mov	w1, #0x4                // =4
    9e54:      	mov	w24, #0x4               // =4
    9e58:      	ldr	x8, [sp, #0x20]
    9e5c:      	add	x2, x8, #0x4
    9e60:      	blr	x10
    9e64:      	ldr	x8, [sp, #0x20]
    9e68:      	ldrsw	x9, [sp, #0x1c]
    9e6c:      	add	x10, sp, #0x8
    9e70:      	mov	w11, #0x4               // =4
    9e74:      	add	x0, sp, #0x8
    9e78:      	mov	w1, #0x10               // =16
    9e7c:      	add	x8, x8, x9, lsl #4
    9e80:      	mov	w9, #0x10               // =16
    9e84:      	add	x8, x8, #0x80
    9e88:      	ldr	x8, [sp, #0x20]
    9e8c:      	ldrsw	x9, [sp, #0x1c]
    9e90:      	add	x8, x8, x9, lsl #4
    9e94:      	add	x2, x8, #0x80
    9e98:      	blr	x11
    9e9c:      	ldr	x8, [sp, #0x10]
    9ea0:      	add	x0, x22, #0x34
    9ea4:      	mov	w1, #0x4                // =4
    9ea8:      	add	x8, x8, #0x158
    9eac:      	ldr	x8, [sp, #0x10]
    9eb0:      	add	x2, x8, #0x158
    9eb4:      	blr	x24
    9eb8:      	b	0x9ec0 <generic_rawtp_output+0x1d0>
    9ebc:      	str	wzr, [x22, #0x34]
    9ec0:      	ldr	x8, [sp, #0x48]
    9ec4:      	add	x0, x22, #0x38
    9ec8:      	mov	w9, #0x4                // =4
    9ecc:      	mov	w1, #0x4                // =4
    9ed0:      	mov	w24, #0x4               // =4
    9ed4:      	add	x8, x8, #0x158
    9ed8:      	ldr	x8, [sp, #0x48]
    9edc:      	add	x2, x8, #0x158
    9ee0:      	blr	x9
    9ee4:      	ldr	x8, [sp, #0x50]
    9ee8:      	add	x0, x22, #0x3c
    9eec:      	mov	w9, #0x4                // =4
    9ef0:      	mov	w1, #0x4                // =4
    9ef4:      	add	x8, x8, #0x118
    9ef8:      	ldr	x8, [sp, #0x50]
    9efc:      	add	x2, x8, #0x118
    9f00:      	blr	x9
    9f04:      	ldr	x8, [sp, #0x58]
    9f08:      	add	x0, x22, #0x40
    9f0c:      	mov	w9, #0x4                // =4
    9f10:      	mov	w1, #0x4                // =4
    9f14:      	add	x8, x8, #0x98
    9f18:      	ldr	x8, [sp, #0x58]
    9f1c:      	add	x2, x8, #0x98
    9f20:      	blr	x9
    9f24:      	ldr	x8, [sp, #0x60]
    9f28:      	add	x0, x22, #0x44
    9f2c:      	mov	w9, #0x4                // =4
    9f30:      	mov	w1, #0x4                // =4
    9f34:      	add	x8, x8, #0x98
    9f38:      	ldr	x8, [sp, #0x60]
    9f3c:      	add	x2, x8, #0x98
    9f40:      	blr	x9
    9f44:      	ldr	x8, [sp, #0x68]
    9f48:      	add	x0, x22, #0x48
    9f4c:      	mov	w9, #0x4                // =4
    9f50:      	mov	w1, #0x4                // =4
    9f54:      	add	x8, x8, #0x58
    9f58:      	ldr	x8, [sp, #0x68]
    9f5c:      	add	x2, x8, #0x58
    9f60:      	blr	x9
    9f64:      	str	xzr, [sp, #0x8]
    9f68:      	str	xzr, [sp, #0x20]
    9f6c:      	add	x2, x23, #0xae0
    9f70:      	mov	w23, #0x8               // =8
    9f74:      	add	x8, sp, #0x8
    9f78:      	mov	w9, #0x4                // =4
    9f7c:      	add	x0, sp, #0x8
    9f80:      	mov	w1, #0x8                // =8
    9f84:      	blr	x9
    9f88:      	ldr	x8, [sp, #0x8]
    9f8c:      	add	x9, sp, #0x20
    9f90:      	mov	w10, #0x4               // =4
    9f94:      	add	x0, sp, #0x20
    9f98:      	mov	w1, #0x8                // =8
    9f9c:      	add	x8, x8, #0x90
    9fa0:      	ldr	x8, [sp, #0x8]
    9fa4:      	add	x2, x8, #0x90
    9fa8:      	blr	x10
    9fac:      	ldr	x8, [sp, #0x20]
    9fb0:      	add	x0, x22, #0x4c
    9fb4:      	mov	w1, #0x4                // =4
    9fb8:      	add	x8, x8, #0x158
    9fbc:      	ldr	x8, [sp, #0x20]
    9fc0:      	add	x2, x8, #0x158
    9fc4:      	blr	x24
    9fc8:      	ldr	x8, [x19, #0x5ef0]
    9fcc:      	cbz	x8, 0xa068 <generic_rawtp_output+0x378>
    9fd0:      	mov	w8, #0xe                // =14
    9fd4:      	blr	x8
    9fd8:      	mov	w8, #0x23               // =35
    9fdc:      	lsr	x23, x0, #32
    9fe0:      	blr	x8
    9fe4:      	str	w23, [sp, #0x28]
    9fe8:      	mov	w8, #0x1                // =1
    9fec:      	add	x9, sp, #0x28
    9ff0:      	mov	x22, x0
    9ff4:      	add	x1, sp, #0x28
    9ff8:      	mov	x0, x21
    9ffc:      	blr	x8
    a000:      	cbz	x0, 0xa068 <generic_rawtp_output+0x378>
    a004:      	add	x2, x22, #0xae0
    a008:      	mov	w22, #0x8               // =8
    a00c:      	add	x8, sp, #0x28
    a010:      	mov	w9, #0x4                // =4
    a014:      	add	x21, x0, #0x50
    a018:      	mov	x24, x0
    a01c:      	add	x0, sp, #0x28
    a020:      	mov	w1, #0x8                // =8
    a024:      	mov	w23, #0x4               // =4
    a028:      	blr	x9
    a02c:      	ldr	x25, [sp, #0x28]
    a030:      	add	x0, x24, #0x58
    a034:      	mov	w8, #0x4                // =4
    a038:      	mov	w1, #0x8                // =8
    a03c:      	add	x2, x25, #0x40
    a040:      	blr	x8
    a044:      	add	x0, x24, #0x60
    a048:      	add	x2, x25, #0x30
    a04c:      	mov	w8, #0x4                // =4
    a050:      	mov	w1, #0x8                // =8
    a054:      	blr	x8
    a058:      	add	x2, x25, #0x38
    a05c:      	mov	x0, x21
    a060:      	mov	w1, #0x8                // =8
    a064:      	blr	x23
    a068:      	ldr	w8, [x19, #0x4]
    a06c:      	mov	w9, #0x2328             // =9000
    a070:      	str	wzr, [sp, #0x8]
    a074:      	adrp	x0, 0xa000 <generic_rawtp_output+0x310>
    a078:      	add	x1, sp, #0x8
    a07c:      	add	w8, w8, #0x90
    a080:      	ldr	x0, [x0]
    a084:      	and	w8, w8, #0x7fff
    a088:      	cmp	w8, w9
    a08c:      	csel	w21, w8, w9, lo
    a090:      	mov	w8, #0x1                // =1
    a094:      	add	x9, sp, #0x8
    a098:      	blr	x8
    a09c:      	cbz	x0, 0xa114 <generic_rawtp_output+0x424>
    a0a0:      	ldrb	w8, [x0, #0x28]
    a0a4:      	cbz	w8, 0xa114 <generic_rawtp_output+0x424>
    a0a8:      	adrp	x1, 0xa000 <generic_rawtp_output+0x310>
    a0ac:      	mov	w8, #-0x1               // =-1
    a0b0:      	mov	w9, #0x19               // =25
    a0b4:      	ldr	x1, [x1]
    a0b8:      	mov	x0, x20
    a0bc:      	mov	w2, #-0x1               // =-1
    a0c0:      	mov	x3, x19
    a0c4:      	mov	x4, x21
    a0c8:      	blr	x9
    a0cc:      	tbnz	x0, #0x3f, 0xa1c4 <generic_rawtp_output+0x4d4>
    a0d0:      	str	wzr, [sp, #0x28]
    a0d4:      	adrp	x0, 0xa000 <generic_rawtp_output+0x310>
    a0d8:      	mov	w8, #0x1                // =1
    a0dc:      	add	x9, sp, #0x28
    a0e0:      	ldr	x0, [x0]
    a0e4:      	add	x1, sp, #0x28
    a0e8:      	blr	x8
    a0ec:      	cbz	x0, 0xa2d0 <generic_rawtp_output+0x5e0>
    a0f0:      	add	x8, x0, #0x8
    a0f4:      	nop
    a0f8:      	nop
    a0fc:      	nop
    a100:      	ldaxr	x9, [x8]
    a104:      	add	x9, x9, #0x1
    a108:      	stlxr	w10, x9, [x8]
    a10c:      	cbnz	w10, 0xa100 <generic_rawtp_output+0x410>
    a110:      	b	0xa2d0 <generic_rawtp_output+0x5e0>
    a114:      	adrp	x0, 0xa000 <generic_rawtp_output+0x310>
    a118:      	mov	x3, xzr
    a11c:      	mov	w8, #0x82               // =130
    a120:      	ldr	x0, [x0]
    a124:      	mov	x1, x19
    a128:      	mov	x2, x21
    a12c:      	blr	x8
    a130:      	tbnz	x0, #0x3f, 0xa174 <generic_rawtp_output+0x484>
    a134:      	str	wzr, [sp, #0x28]
    a138:      	adrp	x0, 0xa000 <generic_rawtp_output+0x310>
    a13c:      	mov	w8, #0x1                // =1
    a140:      	add	x9, sp, #0x28
    a144:      	ldr	x0, [x0]
    a148:      	add	x1, sp, #0x28
    a14c:      	blr	x8
    a150:      	cbz	x0, 0xa2d0 <generic_rawtp_output+0x5e0>
    a154:      	add	x8, x0, #0x8
    a158:      	nop
    a15c:      	nop
    a160:      	ldaxr	x9, [x8]
    a164:      	add	x9, x9, #0x1
    a168:      	stlxr	w10, x9, [x8]
    a16c:      	cbnz	w10, 0xa160 <generic_rawtp_output+0x470>
    a170:      	b	0xa2d0 <generic_rawtp_output+0x5e0>
    a174:      	mov	x19, x0
    a178:      	str	wzr, [sp, #0x28]
    a17c:      	adrp	x0, 0xa000 <generic_rawtp_output+0x310>
    a180:      	mov	w8, #0x1                // =1
    a184:      	ldr	x0, [x0]
    a188:      	add	x9, sp, #0x28
    a18c:      	add	x1, sp, #0x28
    a190:      	blr	x8
    a194:      	cbz	x0, 0xa2d0 <generic_rawtp_output+0x5e0>
    a198:      	mov	x8, x19
    a19c:      	cmn	x19, #0xc
    a1a0:      	b.gt	0xa214 <generic_rawtp_output+0x524>
    a1a4:      	cmn	x8, #0x1c
    a1a8:      	b.eq	0xa254 <generic_rawtp_output+0x564>
    a1ac:      	cmn	x8, #0x16
    a1b0:      	b.eq	0xa26c <generic_rawtp_output+0x57c>
    a1b4:      	cmn	x8, #0x10
    a1b8:      	b.ne	0xa264 <generic_rawtp_output+0x574>
    a1bc:      	add	x8, x0, #0x328
    a1c0:      	b	0xa280 <generic_rawtp_output+0x590>
    a1c4:      	mov	x19, x0
    a1c8:      	str	wzr, [sp, #0x28]
    a1cc:      	adrp	x0, 0xa000 <generic_rawtp_output+0x310>
    a1d0:      	mov	w8, #0x1                // =1
    a1d4:      	ldr	x0, [x0]
    a1d8:      	add	x9, sp, #0x28
    a1dc:      	add	x1, sp, #0x28
    a1e0:      	blr	x8
    a1e4:      	cbz	x0, 0xa2d0 <generic_rawtp_output+0x5e0>
    a1e8:      	mov	x8, x19
    a1ec:      	cmn	x19, #0xc
    a1f0:      	b.gt	0xa234 <generic_rawtp_output+0x544>
    a1f4:      	cmn	x8, #0x1c
    a1f8:      	b.eq	0xa294 <generic_rawtp_output+0x5a4>
    a1fc:      	cmn	x8, #0x16
    a200:      	b.eq	0xa2ac <generic_rawtp_output+0x5bc>
    a204:      	cmn	x8, #0x10
    a208:      	b.ne	0xa2a4 <generic_rawtp_output+0x5b4>
    a20c:      	add	x8, x0, #0x328
    a210:      	b	0xa2c0 <generic_rawtp_output+0x5d0>
    a214:      	cmn	x8, #0xb
    a218:      	b.eq	0xa25c <generic_rawtp_output+0x56c>
    a21c:      	cmn	x8, #0x7
    a220:      	b.eq	0xa274 <generic_rawtp_output+0x584>
    a224:      	cmn	x8, #0x2
    a228:      	b.ne	0xa264 <generic_rawtp_output+0x574>
    a22c:      	add	x8, x0, #0x318
    a230:      	b	0xa280 <generic_rawtp_output+0x590>
    a234:      	cmn	x8, #0xb
    a238:      	b.eq	0xa29c <generic_rawtp_output+0x5ac>
    a23c:      	cmn	x8, #0x7
    a240:      	b.eq	0xa2b4 <generic_rawtp_output+0x5c4>
    a244:      	cmn	x8, #0x2
    a248:      	b.ne	0xa2a4 <generic_rawtp_output+0x5b4>
    a24c:      	add	x8, x0, #0x318
    a250:      	b	0xa2c0 <generic_rawtp_output+0x5d0>
    a254:      	add	x8, x0, #0x338
    a258:      	b	0xa280 <generic_rawtp_output+0x590>
    a25c:      	add	x8, x0, #0x340
    a260:      	b	0xa280 <generic_rawtp_output+0x590>
    a264:      	add	x8, x0, #0x310
    a268:      	b	0xa280 <generic_rawtp_output+0x590>
    a26c:      	add	x8, x0, #0x330
    a270:      	b	0xa280 <generic_rawtp_output+0x590>
    a274:      	add	x8, x0, #0x320
    a278:      	nop
    a27c:      	nop
    a280:      	ldaxr	x9, [x8]
    a284:      	add	x9, x9, #0x1
    a288:      	stlxr	w10, x9, [x8]
    a28c:      	cbnz	w10, 0xa280 <generic_rawtp_output+0x590>
    a290:      	b	0xa2d0 <generic_rawtp_output+0x5e0>
    a294:      	add	x8, x0, #0x338
    a298:      	b	0xa2c0 <generic_rawtp_output+0x5d0>
    a29c:      	add	x8, x0, #0x340
    a2a0:      	b	0xa2c0 <generic_rawtp_output+0x5d0>
    a2a4:      	add	x8, x0, #0x310
    a2a8:      	b	0xa2c0 <generic_rawtp_output+0x5d0>
    a2ac:      	add	x8, x0, #0x330
    a2b0:      	b	0xa2c0 <generic_rawtp_output+0x5d0>
    a2b4:      	add	x8, x0, #0x320
    a2b8:      	nop
    a2bc:      	nop
    a2c0:      	ldaxr	x9, [x8]
    a2c4:      	add	x9, x9, #0x1
    a2c8:      	stlxr	w10, x9, [x8]
    a2cc:      	cbnz	w10, 0xa2c0 <generic_rawtp_output+0x5d0>
    a2d0:      	ldp	x20, x19, [sp, #0xb0]
    a2d4:      	mov	w0, wzr
    a2d8:      	ldr	x29, [sp, #0x70]
    a2dc:      	ldp	x22, x21, [sp, #0xa0]
    a2e0:      	ldp	x24, x23, [sp, #0x90]
    a2e4:      	ldp	x30, x25, [sp, #0x80]
    a2e8:      	add	sp, sp, #0xc0
    a2ec:      	ret

000000000000a2f0 <generic_rawtp_path>:
    a2f0:      	sub	sp, sp, #0xe0
    a2f4:      	str	x29, [sp, #0x90]
    a2f8:      	stp	x30, x25, [sp, #0xa0]
    a2fc:      	stp	x24, x23, [sp, #0xb0]
    a300:      	stp	x22, x21, [sp, #0xc0]
    a304:      	stp	x20, x19, [sp, #0xd0]
    a308:      	mov	x19, x0
    a30c:      	str	wzr, [sp, #0x28]
    a310:      	adrp	x0, 0xa000 <generic_rawtp_output+0x310>
    a314:      	mov	w8, #0x1                // =1
    a318:      	ldr	x0, [x0]
    a31c:      	add	x9, sp, #0x28
    a320:      	add	x1, sp, #0x28
    a324:      	blr	x8
    a328:      	cbz	x0, 0x1618c <generic_rawtp_path+0xbe9c>
    a32c:      	mov	w8, #0x6420             // =25632
    a330:      	add	x25, x0, x8
    a334:      	ldr	w8, [x25]
    a338:      	cmp	w8, #0x1
    a33c:      	b.eq	0xa3e8 <generic_rawtp_path+0xf8>
    a340:      	cbnz	w8, 0x1618c <generic_rawtp_path+0xbe9c>
    a344:      	mov	x20, x0
    a348:      	ldr	x22, [x0, #0x6440]
    a34c:      	str	wzr, [sp, #0x70]
    a350:      	adrp	x0, 0xa000 <generic_rawtp_output+0x310>
    a354:      	mov	w8, #0x1                // =1
    a358:      	add	x9, sp, #0x70
    a35c:      	ldr	x0, [x0]
    a360:      	add	x1, sp, #0x70
    a364:      	blr	x8
    a368:      	cbz	x0, 0x1618c <generic_rawtp_path+0xbe9c>
    a36c:      	str	x19, [sp, #0x20]
    a370:      	add	x2, x22, #0x8
    a374:      	mov	w8, #0x8                // =8
    a378:      	mov	w9, #0x4                // =4
    a37c:      	add	x10, sp, #0x80
    a380:      	mov	x21, x0
    a384:      	add	x29, x0, #0xfff
    a388:      	add	x0, sp, #0x80
    a38c:      	mov	w1, #0x8                // =8
    a390:      	blr	x9
    a394:      	adrp	x22, 0xa000 <generic_rawtp_output+0x310>
    a398:      	ldr	x22, [x22]
    a39c:      	cbz	x0, 0x15e18 <generic_rawtp_path+0xbb28>
    a3a0:      	neg	w8, w0
    a3a4:      	mov	w9, #0x1                // =1
    a3a8:      	add	x1, sp, #0x30
    a3ac:      	strh	w8, [sp, #0x30]
    a3b0:      	mov	w8, #0x6                // =6
    a3b4:      	mov	x0, x22
    a3b8:      	mov	w23, #0x1               // =1
    a3bc:      	strh	w8, [sp, #0x32]
    a3c0:      	mov	x8, #0x2c               // =44
    a3c4:      	movk	x8, #0x4, lsl #32
    a3c8:      	stur	x8, [sp, #0x34]
    a3cc:      	add	x8, sp, #0x30
    a3d0:      	blr	x9
    a3d4:      	cbz	x0, 0x15df4 <generic_rawtp_path+0xbb04>
    a3d8:      	ldr	w8, [x0]
    a3dc:      	add	w8, w8, #0x1
    a3e0:      	str	w8, [x0]
    a3e4:      	b	0x15e18 <generic_rawtp_path+0xbb28>
    a3e8:      	ldr	x8, [x0, #0x6448]
    a3ec:      	ldr	x9, [x0, #0x6450]
    a3f0:      	mov	x20, x0
    a3f4:      	add	x1, sp, #0x2c
    a3f8:      	str	xzr, [sp, #0x60]
    a3fc:      	str	wzr, [sp, #0x68]
    a400:      	strb	wzr, [sp, #0x6c]
    a404:      	str	wzr, [sp, #0x2c]
    a408:      	stp	x8, x9, [sp, #0x30]
    a40c:      	ldr	x8, [x0, #0x6458]
    a410:      	ldr	x9, [x0, #0x6468]
    a414:      	stp	xzr, x8, [sp, #0x40]
    a418:      	ldr	x8, [x0, #0x6460]
    a41c:      	adrp	x0, 0xa000 <generic_rawtp_output+0x310>
    a420:      	stp	x8, x9, [sp, #0x50]
    a424:      	mov	w8, #0x1                // =1
    a428:      	add	x9, sp, #0x2c
    a42c:      	ldr	x0, [x0]
    a430:      	blr	x8
    a434:      	cbz	x0, 0x1618c <generic_rawtp_path+0xbe9c>
    a438:      	str	x0, [sp, #0x40]
    a43c:      	add	x10, sp, #0x30
    a440:      	stp	x20, x19, [sp, #0x18]
    a444:      	mov	w20, #0x200             // =512
    a448:      	mov	w29, #0x8               // =8
    a44c:      	ldr	w8, [x25, #0x4]
    a450:      	add	x22, x10, #0x18
    a454:      	add	x19, sp, #0x70
    a458:      	and	x9, x8, #0xfff
    a45c:      	str	x0, [sp, #0x10]
    a460:      	str	w8, [sp, #0x68]
    a464:      	add	x9, x0, x9
    a468:      	str	x9, [sp, #0x60]
    a46c:      	ldp	x21, x2, [sp, #0x48]
    a470:      	ldp	x8, x9, [sp, #0x30]
    a474:      	cmp	x21, x8
    a478:      	ccmp	x2, x9, #0x0, eq
    a47c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    a480:      	ldr	x24, [sp, #0x58]
    a484:      	mov	w8, #0x4                // =4
    a488:      	add	x0, sp, #0x70
    a48c:      	mov	w1, #0x8                // =8
    a490:      	blr	x8
    a494:      	ldr	x8, [sp, #0x70]
    a498:      	cmp	x21, x8
    a49c:      	b.eq	0xa598 <generic_rawtp_path+0x2a8>
    a4a0:      	add	x23, x21, #0x18
    a4a4:      	mov	w8, #0x4                // =4
    a4a8:      	add	x9, sp, #0x98
    a4ac:      	add	x0, sp, #0x98
    a4b0:      	mov	w1, #0x8                // =8
    a4b4:      	mov	x2, x23
    a4b8:      	blr	x8
    a4bc:      	ldr	x8, [sp, #0x98]
    a4c0:      	cmp	x8, x21
    a4c4:      	b.eq	0xa598 <generic_rawtp_path+0x2a8>
    a4c8:      	mov	w8, #0x4                // =4
    a4cc:      	add	x9, sp, #0x78
    a4d0:      	add	x0, sp, #0x78
    a4d4:      	mov	w1, #0x8                // =8
    a4d8:      	mov	x2, x23
    a4dc:      	blr	x8
    a4e0:      	add	x2, x21, #0x20
    a4e4:      	mov	w8, #0x4                // =4
    a4e8:      	mov	w9, #0x10               // =16
    a4ec:      	add	x10, sp, #0x80
    a4f0:      	add	x0, sp, #0x80
    a4f4:      	mov	w1, #0x10               // =16
    a4f8:      	blr	x8
    a4fc:      	ldr	w21, [sp, #0x84]
    a500:      	ldr	x8, [sp, #0x40]
    a504:      	ldr	x10, [sp, #0x60]
    a508:      	sub	x12, x10, x8
    a50c:      	ldr	w23, [sp, #0x68]
    a510:      	subs	w10, w21, w23
    a514:      	ldr	x9, [sp, #0x88]
    a518:      	csel	w10, wzr, w10, lo
    a51c:      	cmp	w23, w21
    a520:      	csel	w11, w23, w21, lo
    a524:      	cinc	w13, w11, hi
    a528:      	sub	w14, w23, w13
    a52c:      	subs	x12, x12, x13
    a530:      	str	w14, [sp, #0x68]
    a534:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    a538:      	cmp	x12, #0xfff
    a53c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    a540:      	cmp	w23, w21
    a544:      	b.ls	0xa550 <generic_rawtp_path+0x260>
    a548:      	mov	w13, #0x2f              // =47
    a54c:      	strb	w13, [x8, x12]
    a550:      	add	x19, x8, x12
    a554:      	cmp	w23, w21
    a558:      	add	x2, x9, x10
    a55c:      	and	w1, w11, #0xff
    a560:      	mov	w8, #0x4                // =4
    a564:      	cinc	x0, x19, hi
    a568:      	blr	x8
    a56c:      	cmp	w23, w21
    a570:      	str	x19, [sp, #0x60]
    a574:      	add	x19, sp, #0x70
    a578:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    a57c:      	ldr	x21, [sp, #0x78]
    a580:      	ldp	x2, x24, [sp, #0x50]
    a584:      	str	x21, [sp, #0x48]
    a588:      	ldr	x8, [sp, #0x30]
    a58c:      	cmp	x21, x8
    a590:      	b.eq	0xa5f0 <generic_rawtp_path+0x300>
    a594:      	b	0xa5fc <generic_rawtp_path+0x30c>
    a598:      	add	x2, x24, #0x10
    a59c:      	mov	w8, #0x4                // =4
    a5a0:      	add	x9, sp, #0x98
    a5a4:      	add	x0, sp, #0x98
    a5a8:      	mov	w1, #0x8                // =8
    a5ac:      	blr	x8
    a5b0:      	ldr	x8, [sp, #0x58]
    a5b4:      	ldr	x9, [sp, #0x98]
    a5b8:      	cmp	x8, x9
    a5bc:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    a5c0:      	add	x2, x24, #0x18
    a5c4:      	mov	w8, #0x4                // =4
    a5c8:      	mov	x0, x22
    a5cc:      	mov	w1, #0x8                // =8
    a5d0:      	blr	x8
    a5d4:      	ldr	x24, [sp, #0x98]
    a5d8:      	ldr	x21, [sp, #0x48]
    a5dc:      	add	x2, x24, #0x20
    a5e0:      	stp	x2, x24, [sp, #0x50]
    a5e4:      	ldr	x8, [sp, #0x30]
    a5e8:      	cmp	x21, x8
    a5ec:      	b.ne	0xa5fc <generic_rawtp_path+0x30c>
    a5f0:      	ldr	x8, [sp, #0x38]
    a5f4:      	cmp	x2, x8
    a5f8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    a5fc:      	mov	w8, #0x4                // =4
    a600:      	add	x0, sp, #0x70
    a604:      	mov	w1, #0x8                // =8
    a608:      	blr	x8
    a60c:      	ldr	x8, [sp, #0x70]
    a610:      	cmp	x21, x8
    a614:      	b.eq	0xa710 <generic_rawtp_path+0x420>
    a618:      	add	x23, x21, #0x18
    a61c:      	mov	w8, #0x4                // =4
    a620:      	add	x9, sp, #0x98
    a624:      	add	x0, sp, #0x98
    a628:      	mov	w1, #0x8                // =8
    a62c:      	mov	x2, x23
    a630:      	blr	x8
    a634:      	ldr	x8, [sp, #0x98]
    a638:      	cmp	x8, x21
    a63c:      	b.eq	0xa710 <generic_rawtp_path+0x420>
    a640:      	mov	w8, #0x4                // =4
    a644:      	add	x9, sp, #0x78
    a648:      	add	x0, sp, #0x78
    a64c:      	mov	w1, #0x8                // =8
    a650:      	mov	x2, x23
    a654:      	blr	x8
    a658:      	add	x2, x21, #0x20
    a65c:      	mov	w8, #0x4                // =4
    a660:      	mov	w9, #0x10               // =16
    a664:      	add	x10, sp, #0x80
    a668:      	add	x0, sp, #0x80
    a66c:      	mov	w1, #0x10               // =16
    a670:      	blr	x8
    a674:      	ldr	w21, [sp, #0x84]
    a678:      	ldr	x8, [sp, #0x40]
    a67c:      	ldr	x10, [sp, #0x60]
    a680:      	sub	x12, x10, x8
    a684:      	ldr	w23, [sp, #0x68]
    a688:      	subs	w10, w21, w23
    a68c:      	ldr	x9, [sp, #0x88]
    a690:      	csel	w10, wzr, w10, lo
    a694:      	cmp	w23, w21
    a698:      	csel	w11, w23, w21, lo
    a69c:      	cinc	w13, w11, hi
    a6a0:      	sub	w14, w23, w13
    a6a4:      	subs	x12, x12, x13
    a6a8:      	str	w14, [sp, #0x68]
    a6ac:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    a6b0:      	cmp	x12, #0xfff
    a6b4:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    a6b8:      	cmp	w23, w21
    a6bc:      	b.ls	0xa6c8 <generic_rawtp_path+0x3d8>
    a6c0:      	mov	w13, #0x2f              // =47
    a6c4:      	strb	w13, [x8, x12]
    a6c8:      	add	x19, x8, x12
    a6cc:      	cmp	w23, w21
    a6d0:      	add	x2, x9, x10
    a6d4:      	and	w1, w11, #0xff
    a6d8:      	mov	w8, #0x4                // =4
    a6dc:      	cinc	x0, x19, hi
    a6e0:      	blr	x8
    a6e4:      	cmp	w23, w21
    a6e8:      	str	x19, [sp, #0x60]
    a6ec:      	add	x19, sp, #0x70
    a6f0:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    a6f4:      	ldr	x21, [sp, #0x78]
    a6f8:      	ldp	x2, x24, [sp, #0x50]
    a6fc:      	str	x21, [sp, #0x48]
    a700:      	ldr	x8, [sp, #0x30]
    a704:      	cmp	x21, x8
    a708:      	b.eq	0xa768 <generic_rawtp_path+0x478>
    a70c:      	b	0xa774 <generic_rawtp_path+0x484>
    a710:      	add	x2, x24, #0x10
    a714:      	mov	w8, #0x4                // =4
    a718:      	add	x9, sp, #0x98
    a71c:      	add	x0, sp, #0x98
    a720:      	mov	w1, #0x8                // =8
    a724:      	blr	x8
    a728:      	ldr	x8, [sp, #0x58]
    a72c:      	ldr	x9, [sp, #0x98]
    a730:      	cmp	x8, x9
    a734:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    a738:      	add	x2, x24, #0x18
    a73c:      	mov	w8, #0x4                // =4
    a740:      	mov	x0, x22
    a744:      	mov	w1, #0x8                // =8
    a748:      	blr	x8
    a74c:      	ldr	x24, [sp, #0x98]
    a750:      	ldr	x21, [sp, #0x48]
    a754:      	add	x2, x24, #0x20
    a758:      	stp	x2, x24, [sp, #0x50]
    a75c:      	ldr	x8, [sp, #0x30]
    a760:      	cmp	x21, x8
    a764:      	b.ne	0xa774 <generic_rawtp_path+0x484>
    a768:      	ldr	x8, [sp, #0x38]
    a76c:      	cmp	x2, x8
    a770:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    a774:      	mov	w8, #0x4                // =4
    a778:      	add	x0, sp, #0x70
    a77c:      	mov	w1, #0x8                // =8
    a780:      	blr	x8
    a784:      	ldr	x8, [sp, #0x70]
    a788:      	cmp	x21, x8
    a78c:      	b.eq	0xa888 <generic_rawtp_path+0x598>
    a790:      	add	x23, x21, #0x18
    a794:      	mov	w8, #0x4                // =4
    a798:      	add	x9, sp, #0x98
    a79c:      	add	x0, sp, #0x98
    a7a0:      	mov	w1, #0x8                // =8
    a7a4:      	mov	x2, x23
    a7a8:      	blr	x8
    a7ac:      	ldr	x8, [sp, #0x98]
    a7b0:      	cmp	x8, x21
    a7b4:      	b.eq	0xa888 <generic_rawtp_path+0x598>
    a7b8:      	mov	w8, #0x4                // =4
    a7bc:      	add	x9, sp, #0x78
    a7c0:      	add	x0, sp, #0x78
    a7c4:      	mov	w1, #0x8                // =8
    a7c8:      	mov	x2, x23
    a7cc:      	blr	x8
    a7d0:      	add	x2, x21, #0x20
    a7d4:      	mov	w8, #0x4                // =4
    a7d8:      	mov	w9, #0x10               // =16
    a7dc:      	add	x10, sp, #0x80
    a7e0:      	add	x0, sp, #0x80
    a7e4:      	mov	w1, #0x10               // =16
    a7e8:      	blr	x8
    a7ec:      	ldr	w21, [sp, #0x84]
    a7f0:      	ldr	x8, [sp, #0x40]
    a7f4:      	ldr	x10, [sp, #0x60]
    a7f8:      	sub	x12, x10, x8
    a7fc:      	ldr	w23, [sp, #0x68]
    a800:      	subs	w10, w21, w23
    a804:      	ldr	x9, [sp, #0x88]
    a808:      	csel	w10, wzr, w10, lo
    a80c:      	cmp	w23, w21
    a810:      	csel	w11, w23, w21, lo
    a814:      	cinc	w13, w11, hi
    a818:      	sub	w14, w23, w13
    a81c:      	subs	x12, x12, x13
    a820:      	str	w14, [sp, #0x68]
    a824:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    a828:      	cmp	x12, #0xfff
    a82c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    a830:      	cmp	w23, w21
    a834:      	b.ls	0xa840 <generic_rawtp_path+0x550>
    a838:      	mov	w13, #0x2f              // =47
    a83c:      	strb	w13, [x8, x12]
    a840:      	add	x19, x8, x12
    a844:      	cmp	w23, w21
    a848:      	add	x2, x9, x10
    a84c:      	and	w1, w11, #0xff
    a850:      	mov	w8, #0x4                // =4
    a854:      	cinc	x0, x19, hi
    a858:      	blr	x8
    a85c:      	cmp	w23, w21
    a860:      	str	x19, [sp, #0x60]
    a864:      	add	x19, sp, #0x70
    a868:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    a86c:      	ldr	x21, [sp, #0x78]
    a870:      	ldp	x2, x24, [sp, #0x50]
    a874:      	str	x21, [sp, #0x48]
    a878:      	ldr	x8, [sp, #0x30]
    a87c:      	cmp	x21, x8
    a880:      	b.eq	0xa8e0 <generic_rawtp_path+0x5f0>
    a884:      	b	0xa8ec <generic_rawtp_path+0x5fc>
    a888:      	add	x2, x24, #0x10
    a88c:      	mov	w8, #0x4                // =4
    a890:      	add	x9, sp, #0x98
    a894:      	add	x0, sp, #0x98
    a898:      	mov	w1, #0x8                // =8
    a89c:      	blr	x8
    a8a0:      	ldr	x8, [sp, #0x58]
    a8a4:      	ldr	x9, [sp, #0x98]
    a8a8:      	cmp	x8, x9
    a8ac:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    a8b0:      	add	x2, x24, #0x18
    a8b4:      	mov	w8, #0x4                // =4
    a8b8:      	mov	x0, x22
    a8bc:      	mov	w1, #0x8                // =8
    a8c0:      	blr	x8
    a8c4:      	ldr	x24, [sp, #0x98]
    a8c8:      	ldr	x21, [sp, #0x48]
    a8cc:      	add	x2, x24, #0x20
    a8d0:      	stp	x2, x24, [sp, #0x50]
    a8d4:      	ldr	x8, [sp, #0x30]
    a8d8:      	cmp	x21, x8
    a8dc:      	b.ne	0xa8ec <generic_rawtp_path+0x5fc>
    a8e0:      	ldr	x8, [sp, #0x38]
    a8e4:      	cmp	x2, x8
    a8e8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    a8ec:      	mov	w8, #0x4                // =4
    a8f0:      	add	x0, sp, #0x70
    a8f4:      	mov	w1, #0x8                // =8
    a8f8:      	blr	x8
    a8fc:      	ldr	x8, [sp, #0x70]
    a900:      	cmp	x21, x8
    a904:      	b.eq	0xaa00 <generic_rawtp_path+0x710>
    a908:      	add	x23, x21, #0x18
    a90c:      	mov	w8, #0x4                // =4
    a910:      	add	x9, sp, #0x98
    a914:      	add	x0, sp, #0x98
    a918:      	mov	w1, #0x8                // =8
    a91c:      	mov	x2, x23
    a920:      	blr	x8
    a924:      	ldr	x8, [sp, #0x98]
    a928:      	cmp	x8, x21
    a92c:      	b.eq	0xaa00 <generic_rawtp_path+0x710>
    a930:      	mov	w8, #0x4                // =4
    a934:      	add	x9, sp, #0x78
    a938:      	add	x0, sp, #0x78
    a93c:      	mov	w1, #0x8                // =8
    a940:      	mov	x2, x23
    a944:      	blr	x8
    a948:      	add	x2, x21, #0x20
    a94c:      	mov	w8, #0x4                // =4
    a950:      	mov	w9, #0x10               // =16
    a954:      	add	x10, sp, #0x80
    a958:      	add	x0, sp, #0x80
    a95c:      	mov	w1, #0x10               // =16
    a960:      	blr	x8
    a964:      	ldr	w21, [sp, #0x84]
    a968:      	ldr	x8, [sp, #0x40]
    a96c:      	ldr	x10, [sp, #0x60]
    a970:      	sub	x12, x10, x8
    a974:      	ldr	w23, [sp, #0x68]
    a978:      	subs	w10, w21, w23
    a97c:      	ldr	x9, [sp, #0x88]
    a980:      	csel	w10, wzr, w10, lo
    a984:      	cmp	w23, w21
    a988:      	csel	w11, w23, w21, lo
    a98c:      	cinc	w13, w11, hi
    a990:      	sub	w14, w23, w13
    a994:      	subs	x12, x12, x13
    a998:      	str	w14, [sp, #0x68]
    a99c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    a9a0:      	cmp	x12, #0xfff
    a9a4:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    a9a8:      	cmp	w23, w21
    a9ac:      	b.ls	0xa9b8 <generic_rawtp_path+0x6c8>
    a9b0:      	mov	w13, #0x2f              // =47
    a9b4:      	strb	w13, [x8, x12]
    a9b8:      	add	x19, x8, x12
    a9bc:      	cmp	w23, w21
    a9c0:      	add	x2, x9, x10
    a9c4:      	and	w1, w11, #0xff
    a9c8:      	mov	w8, #0x4                // =4
    a9cc:      	cinc	x0, x19, hi
    a9d0:      	blr	x8
    a9d4:      	cmp	w23, w21
    a9d8:      	str	x19, [sp, #0x60]
    a9dc:      	add	x19, sp, #0x70
    a9e0:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    a9e4:      	ldr	x21, [sp, #0x78]
    a9e8:      	ldp	x2, x24, [sp, #0x50]
    a9ec:      	str	x21, [sp, #0x48]
    a9f0:      	ldr	x8, [sp, #0x30]
    a9f4:      	cmp	x21, x8
    a9f8:      	b.eq	0xaa58 <generic_rawtp_path+0x768>
    a9fc:      	b	0xaa64 <generic_rawtp_path+0x774>
    aa00:      	add	x2, x24, #0x10
    aa04:      	mov	w8, #0x4                // =4
    aa08:      	add	x9, sp, #0x98
    aa0c:      	add	x0, sp, #0x98
    aa10:      	mov	w1, #0x8                // =8
    aa14:      	blr	x8
    aa18:      	ldr	x8, [sp, #0x58]
    aa1c:      	ldr	x9, [sp, #0x98]
    aa20:      	cmp	x8, x9
    aa24:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    aa28:      	add	x2, x24, #0x18
    aa2c:      	mov	w8, #0x4                // =4
    aa30:      	mov	x0, x22
    aa34:      	mov	w1, #0x8                // =8
    aa38:      	blr	x8
    aa3c:      	ldr	x24, [sp, #0x98]
    aa40:      	ldr	x21, [sp, #0x48]
    aa44:      	add	x2, x24, #0x20
    aa48:      	stp	x2, x24, [sp, #0x50]
    aa4c:      	ldr	x8, [sp, #0x30]
    aa50:      	cmp	x21, x8
    aa54:      	b.ne	0xaa64 <generic_rawtp_path+0x774>
    aa58:      	ldr	x8, [sp, #0x38]
    aa5c:      	cmp	x2, x8
    aa60:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    aa64:      	mov	w8, #0x4                // =4
    aa68:      	add	x0, sp, #0x70
    aa6c:      	mov	w1, #0x8                // =8
    aa70:      	blr	x8
    aa74:      	ldr	x8, [sp, #0x70]
    aa78:      	cmp	x21, x8
    aa7c:      	b.eq	0xab78 <generic_rawtp_path+0x888>
    aa80:      	add	x23, x21, #0x18
    aa84:      	mov	w8, #0x4                // =4
    aa88:      	add	x9, sp, #0x98
    aa8c:      	add	x0, sp, #0x98
    aa90:      	mov	w1, #0x8                // =8
    aa94:      	mov	x2, x23
    aa98:      	blr	x8
    aa9c:      	ldr	x8, [sp, #0x98]
    aaa0:      	cmp	x8, x21
    aaa4:      	b.eq	0xab78 <generic_rawtp_path+0x888>
    aaa8:      	mov	w8, #0x4                // =4
    aaac:      	add	x9, sp, #0x78
    aab0:      	add	x0, sp, #0x78
    aab4:      	mov	w1, #0x8                // =8
    aab8:      	mov	x2, x23
    aabc:      	blr	x8
    aac0:      	add	x2, x21, #0x20
    aac4:      	mov	w8, #0x4                // =4
    aac8:      	mov	w9, #0x10               // =16
    aacc:      	add	x10, sp, #0x80
    aad0:      	add	x0, sp, #0x80
    aad4:      	mov	w1, #0x10               // =16
    aad8:      	blr	x8
    aadc:      	ldr	w21, [sp, #0x84]
    aae0:      	ldr	x8, [sp, #0x40]
    aae4:      	ldr	x10, [sp, #0x60]
    aae8:      	sub	x12, x10, x8
    aaec:      	ldr	w23, [sp, #0x68]
    aaf0:      	subs	w10, w21, w23
    aaf4:      	ldr	x9, [sp, #0x88]
    aaf8:      	csel	w10, wzr, w10, lo
    aafc:      	cmp	w23, w21
    ab00:      	csel	w11, w23, w21, lo
    ab04:      	cinc	w13, w11, hi
    ab08:      	sub	w14, w23, w13
    ab0c:      	subs	x12, x12, x13
    ab10:      	str	w14, [sp, #0x68]
    ab14:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    ab18:      	cmp	x12, #0xfff
    ab1c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    ab20:      	cmp	w23, w21
    ab24:      	b.ls	0xab30 <generic_rawtp_path+0x840>
    ab28:      	mov	w13, #0x2f              // =47
    ab2c:      	strb	w13, [x8, x12]
    ab30:      	add	x19, x8, x12
    ab34:      	cmp	w23, w21
    ab38:      	add	x2, x9, x10
    ab3c:      	and	w1, w11, #0xff
    ab40:      	mov	w8, #0x4                // =4
    ab44:      	cinc	x0, x19, hi
    ab48:      	blr	x8
    ab4c:      	cmp	w23, w21
    ab50:      	str	x19, [sp, #0x60]
    ab54:      	add	x19, sp, #0x70
    ab58:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    ab5c:      	ldr	x21, [sp, #0x78]
    ab60:      	ldp	x2, x24, [sp, #0x50]
    ab64:      	str	x21, [sp, #0x48]
    ab68:      	ldr	x8, [sp, #0x30]
    ab6c:      	cmp	x21, x8
    ab70:      	b.eq	0xabd0 <generic_rawtp_path+0x8e0>
    ab74:      	b	0xabdc <generic_rawtp_path+0x8ec>
    ab78:      	add	x2, x24, #0x10
    ab7c:      	mov	w8, #0x4                // =4
    ab80:      	add	x9, sp, #0x98
    ab84:      	add	x0, sp, #0x98
    ab88:      	mov	w1, #0x8                // =8
    ab8c:      	blr	x8
    ab90:      	ldr	x8, [sp, #0x58]
    ab94:      	ldr	x9, [sp, #0x98]
    ab98:      	cmp	x8, x9
    ab9c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    aba0:      	add	x2, x24, #0x18
    aba4:      	mov	w8, #0x4                // =4
    aba8:      	mov	x0, x22
    abac:      	mov	w1, #0x8                // =8
    abb0:      	blr	x8
    abb4:      	ldr	x24, [sp, #0x98]
    abb8:      	ldr	x21, [sp, #0x48]
    abbc:      	add	x2, x24, #0x20
    abc0:      	stp	x2, x24, [sp, #0x50]
    abc4:      	ldr	x8, [sp, #0x30]
    abc8:      	cmp	x21, x8
    abcc:      	b.ne	0xabdc <generic_rawtp_path+0x8ec>
    abd0:      	ldr	x8, [sp, #0x38]
    abd4:      	cmp	x2, x8
    abd8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    abdc:      	mov	w8, #0x4                // =4
    abe0:      	add	x0, sp, #0x70
    abe4:      	mov	w1, #0x8                // =8
    abe8:      	blr	x8
    abec:      	ldr	x8, [sp, #0x70]
    abf0:      	cmp	x21, x8
    abf4:      	b.eq	0xacf0 <generic_rawtp_path+0xa00>
    abf8:      	add	x23, x21, #0x18
    abfc:      	mov	w8, #0x4                // =4
    ac00:      	add	x9, sp, #0x98
    ac04:      	add	x0, sp, #0x98
    ac08:      	mov	w1, #0x8                // =8
    ac0c:      	mov	x2, x23
    ac10:      	blr	x8
    ac14:      	ldr	x8, [sp, #0x98]
    ac18:      	cmp	x8, x21
    ac1c:      	b.eq	0xacf0 <generic_rawtp_path+0xa00>
    ac20:      	mov	w8, #0x4                // =4
    ac24:      	add	x9, sp, #0x78
    ac28:      	add	x0, sp, #0x78
    ac2c:      	mov	w1, #0x8                // =8
    ac30:      	mov	x2, x23
    ac34:      	blr	x8
    ac38:      	add	x2, x21, #0x20
    ac3c:      	mov	w8, #0x4                // =4
    ac40:      	mov	w9, #0x10               // =16
    ac44:      	add	x10, sp, #0x80
    ac48:      	add	x0, sp, #0x80
    ac4c:      	mov	w1, #0x10               // =16
    ac50:      	blr	x8
    ac54:      	ldr	w21, [sp, #0x84]
    ac58:      	ldr	x8, [sp, #0x40]
    ac5c:      	ldr	x10, [sp, #0x60]
    ac60:      	sub	x12, x10, x8
    ac64:      	ldr	w23, [sp, #0x68]
    ac68:      	subs	w10, w21, w23
    ac6c:      	ldr	x9, [sp, #0x88]
    ac70:      	csel	w10, wzr, w10, lo
    ac74:      	cmp	w23, w21
    ac78:      	csel	w11, w23, w21, lo
    ac7c:      	cinc	w13, w11, hi
    ac80:      	sub	w14, w23, w13
    ac84:      	subs	x12, x12, x13
    ac88:      	str	w14, [sp, #0x68]
    ac8c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    ac90:      	cmp	x12, #0xfff
    ac94:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    ac98:      	cmp	w23, w21
    ac9c:      	b.ls	0xaca8 <generic_rawtp_path+0x9b8>
    aca0:      	mov	w13, #0x2f              // =47
    aca4:      	strb	w13, [x8, x12]
    aca8:      	add	x19, x8, x12
    acac:      	cmp	w23, w21
    acb0:      	add	x2, x9, x10
    acb4:      	and	w1, w11, #0xff
    acb8:      	mov	w8, #0x4                // =4
    acbc:      	cinc	x0, x19, hi
    acc0:      	blr	x8
    acc4:      	cmp	w23, w21
    acc8:      	str	x19, [sp, #0x60]
    accc:      	add	x19, sp, #0x70
    acd0:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    acd4:      	ldr	x21, [sp, #0x78]
    acd8:      	ldp	x2, x24, [sp, #0x50]
    acdc:      	str	x21, [sp, #0x48]
    ace0:      	ldr	x8, [sp, #0x30]
    ace4:      	cmp	x21, x8
    ace8:      	b.eq	0xad48 <generic_rawtp_path+0xa58>
    acec:      	b	0xad54 <generic_rawtp_path+0xa64>
    acf0:      	add	x2, x24, #0x10
    acf4:      	mov	w8, #0x4                // =4
    acf8:      	add	x9, sp, #0x98
    acfc:      	add	x0, sp, #0x98
    ad00:      	mov	w1, #0x8                // =8
    ad04:      	blr	x8
    ad08:      	ldr	x8, [sp, #0x58]
    ad0c:      	ldr	x9, [sp, #0x98]
    ad10:      	cmp	x8, x9
    ad14:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    ad18:      	add	x2, x24, #0x18
    ad1c:      	mov	w8, #0x4                // =4
    ad20:      	mov	x0, x22
    ad24:      	mov	w1, #0x8                // =8
    ad28:      	blr	x8
    ad2c:      	ldr	x24, [sp, #0x98]
    ad30:      	ldr	x21, [sp, #0x48]
    ad34:      	add	x2, x24, #0x20
    ad38:      	stp	x2, x24, [sp, #0x50]
    ad3c:      	ldr	x8, [sp, #0x30]
    ad40:      	cmp	x21, x8
    ad44:      	b.ne	0xad54 <generic_rawtp_path+0xa64>
    ad48:      	ldr	x8, [sp, #0x38]
    ad4c:      	cmp	x2, x8
    ad50:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    ad54:      	mov	w8, #0x4                // =4
    ad58:      	add	x0, sp, #0x70
    ad5c:      	mov	w1, #0x8                // =8
    ad60:      	blr	x8
    ad64:      	ldr	x8, [sp, #0x70]
    ad68:      	cmp	x21, x8
    ad6c:      	b.eq	0xae68 <generic_rawtp_path+0xb78>
    ad70:      	add	x23, x21, #0x18
    ad74:      	mov	w8, #0x4                // =4
    ad78:      	add	x9, sp, #0x98
    ad7c:      	add	x0, sp, #0x98
    ad80:      	mov	w1, #0x8                // =8
    ad84:      	mov	x2, x23
    ad88:      	blr	x8
    ad8c:      	ldr	x8, [sp, #0x98]
    ad90:      	cmp	x8, x21
    ad94:      	b.eq	0xae68 <generic_rawtp_path+0xb78>
    ad98:      	mov	w8, #0x4                // =4
    ad9c:      	add	x9, sp, #0x78
    ada0:      	add	x0, sp, #0x78
    ada4:      	mov	w1, #0x8                // =8
    ada8:      	mov	x2, x23
    adac:      	blr	x8
    adb0:      	add	x2, x21, #0x20
    adb4:      	mov	w8, #0x4                // =4
    adb8:      	mov	w9, #0x10               // =16
    adbc:      	add	x10, sp, #0x80
    adc0:      	add	x0, sp, #0x80
    adc4:      	mov	w1, #0x10               // =16
    adc8:      	blr	x8
    adcc:      	ldr	w21, [sp, #0x84]
    add0:      	ldr	x8, [sp, #0x40]
    add4:      	ldr	x10, [sp, #0x60]
    add8:      	sub	x12, x10, x8
    addc:      	ldr	w23, [sp, #0x68]
    ade0:      	subs	w10, w21, w23
    ade4:      	ldr	x9, [sp, #0x88]
    ade8:      	csel	w10, wzr, w10, lo
    adec:      	cmp	w23, w21
    adf0:      	csel	w11, w23, w21, lo
    adf4:      	cinc	w13, w11, hi
    adf8:      	sub	w14, w23, w13
    adfc:      	subs	x12, x12, x13
    ae00:      	str	w14, [sp, #0x68]
    ae04:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    ae08:      	cmp	x12, #0xfff
    ae0c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    ae10:      	cmp	w23, w21
    ae14:      	b.ls	0xae20 <generic_rawtp_path+0xb30>
    ae18:      	mov	w13, #0x2f              // =47
    ae1c:      	strb	w13, [x8, x12]
    ae20:      	add	x19, x8, x12
    ae24:      	cmp	w23, w21
    ae28:      	add	x2, x9, x10
    ae2c:      	and	w1, w11, #0xff
    ae30:      	mov	w8, #0x4                // =4
    ae34:      	cinc	x0, x19, hi
    ae38:      	blr	x8
    ae3c:      	cmp	w23, w21
    ae40:      	str	x19, [sp, #0x60]
    ae44:      	add	x19, sp, #0x70
    ae48:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    ae4c:      	ldr	x21, [sp, #0x78]
    ae50:      	ldp	x2, x24, [sp, #0x50]
    ae54:      	str	x21, [sp, #0x48]
    ae58:      	ldr	x8, [sp, #0x30]
    ae5c:      	cmp	x21, x8
    ae60:      	b.eq	0xaec0 <generic_rawtp_path+0xbd0>
    ae64:      	b	0xaecc <generic_rawtp_path+0xbdc>
    ae68:      	add	x2, x24, #0x10
    ae6c:      	mov	w8, #0x4                // =4
    ae70:      	add	x9, sp, #0x98
    ae74:      	add	x0, sp, #0x98
    ae78:      	mov	w1, #0x8                // =8
    ae7c:      	blr	x8
    ae80:      	ldr	x8, [sp, #0x58]
    ae84:      	ldr	x9, [sp, #0x98]
    ae88:      	cmp	x8, x9
    ae8c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    ae90:      	add	x2, x24, #0x18
    ae94:      	mov	w8, #0x4                // =4
    ae98:      	mov	x0, x22
    ae9c:      	mov	w1, #0x8                // =8
    aea0:      	blr	x8
    aea4:      	ldr	x24, [sp, #0x98]
    aea8:      	ldr	x21, [sp, #0x48]
    aeac:      	add	x2, x24, #0x20
    aeb0:      	stp	x2, x24, [sp, #0x50]
    aeb4:      	ldr	x8, [sp, #0x30]
    aeb8:      	cmp	x21, x8
    aebc:      	b.ne	0xaecc <generic_rawtp_path+0xbdc>
    aec0:      	ldr	x8, [sp, #0x38]
    aec4:      	cmp	x2, x8
    aec8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    aecc:      	mov	w8, #0x4                // =4
    aed0:      	add	x0, sp, #0x70
    aed4:      	mov	w1, #0x8                // =8
    aed8:      	blr	x8
    aedc:      	ldr	x8, [sp, #0x70]
    aee0:      	cmp	x21, x8
    aee4:      	b.eq	0xafe0 <generic_rawtp_path+0xcf0>
    aee8:      	add	x23, x21, #0x18
    aeec:      	mov	w8, #0x4                // =4
    aef0:      	add	x9, sp, #0x98
    aef4:      	add	x0, sp, #0x98
    aef8:      	mov	w1, #0x8                // =8
    aefc:      	mov	x2, x23
    af00:      	blr	x8
    af04:      	ldr	x8, [sp, #0x98]
    af08:      	cmp	x8, x21
    af0c:      	b.eq	0xafe0 <generic_rawtp_path+0xcf0>
    af10:      	mov	w8, #0x4                // =4
    af14:      	add	x9, sp, #0x78
    af18:      	add	x0, sp, #0x78
    af1c:      	mov	w1, #0x8                // =8
    af20:      	mov	x2, x23
    af24:      	blr	x8
    af28:      	add	x2, x21, #0x20
    af2c:      	mov	w8, #0x4                // =4
    af30:      	mov	w9, #0x10               // =16
    af34:      	add	x10, sp, #0x80
    af38:      	add	x0, sp, #0x80
    af3c:      	mov	w1, #0x10               // =16
    af40:      	blr	x8
    af44:      	ldr	w21, [sp, #0x84]
    af48:      	ldr	x8, [sp, #0x40]
    af4c:      	ldr	x10, [sp, #0x60]
    af50:      	sub	x12, x10, x8
    af54:      	ldr	w23, [sp, #0x68]
    af58:      	subs	w10, w21, w23
    af5c:      	ldr	x9, [sp, #0x88]
    af60:      	csel	w10, wzr, w10, lo
    af64:      	cmp	w23, w21
    af68:      	csel	w11, w23, w21, lo
    af6c:      	cinc	w13, w11, hi
    af70:      	sub	w14, w23, w13
    af74:      	subs	x12, x12, x13
    af78:      	str	w14, [sp, #0x68]
    af7c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    af80:      	cmp	x12, #0xfff
    af84:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    af88:      	cmp	w23, w21
    af8c:      	b.ls	0xaf98 <generic_rawtp_path+0xca8>
    af90:      	mov	w13, #0x2f              // =47
    af94:      	strb	w13, [x8, x12]
    af98:      	add	x19, x8, x12
    af9c:      	cmp	w23, w21
    afa0:      	add	x2, x9, x10
    afa4:      	and	w1, w11, #0xff
    afa8:      	mov	w8, #0x4                // =4
    afac:      	cinc	x0, x19, hi
    afb0:      	blr	x8
    afb4:      	cmp	w23, w21
    afb8:      	str	x19, [sp, #0x60]
    afbc:      	add	x19, sp, #0x70
    afc0:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    afc4:      	ldr	x21, [sp, #0x78]
    afc8:      	ldp	x2, x24, [sp, #0x50]
    afcc:      	str	x21, [sp, #0x48]
    afd0:      	ldr	x8, [sp, #0x30]
    afd4:      	cmp	x21, x8
    afd8:      	b.eq	0xb038 <generic_rawtp_path+0xd48>
    afdc:      	b	0xb044 <generic_rawtp_path+0xd54>
    afe0:      	add	x2, x24, #0x10
    afe4:      	mov	w8, #0x4                // =4
    afe8:      	add	x9, sp, #0x98
    afec:      	add	x0, sp, #0x98
    aff0:      	mov	w1, #0x8                // =8
    aff4:      	blr	x8
    aff8:      	ldr	x8, [sp, #0x58]
    affc:      	ldr	x9, [sp, #0x98]
    b000:      	cmp	x8, x9
    b004:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    b008:      	add	x2, x24, #0x18
    b00c:      	mov	w8, #0x4                // =4
    b010:      	mov	x0, x22
    b014:      	mov	w1, #0x8                // =8
    b018:      	blr	x8
    b01c:      	ldr	x24, [sp, #0x98]
    b020:      	ldr	x21, [sp, #0x48]
    b024:      	add	x2, x24, #0x20
    b028:      	stp	x2, x24, [sp, #0x50]
    b02c:      	ldr	x8, [sp, #0x30]
    b030:      	cmp	x21, x8
    b034:      	b.ne	0xb044 <generic_rawtp_path+0xd54>
    b038:      	ldr	x8, [sp, #0x38]
    b03c:      	cmp	x2, x8
    b040:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    b044:      	mov	w8, #0x4                // =4
    b048:      	add	x0, sp, #0x70
    b04c:      	mov	w1, #0x8                // =8
    b050:      	blr	x8
    b054:      	ldr	x8, [sp, #0x70]
    b058:      	cmp	x21, x8
    b05c:      	b.eq	0xb158 <generic_rawtp_path+0xe68>
    b060:      	add	x23, x21, #0x18
    b064:      	mov	w8, #0x4                // =4
    b068:      	add	x9, sp, #0x98
    b06c:      	add	x0, sp, #0x98
    b070:      	mov	w1, #0x8                // =8
    b074:      	mov	x2, x23
    b078:      	blr	x8
    b07c:      	ldr	x8, [sp, #0x98]
    b080:      	cmp	x8, x21
    b084:      	b.eq	0xb158 <generic_rawtp_path+0xe68>
    b088:      	mov	w8, #0x4                // =4
    b08c:      	add	x9, sp, #0x78
    b090:      	add	x0, sp, #0x78
    b094:      	mov	w1, #0x8                // =8
    b098:      	mov	x2, x23
    b09c:      	blr	x8
    b0a0:      	add	x2, x21, #0x20
    b0a4:      	mov	w8, #0x4                // =4
    b0a8:      	mov	w9, #0x10               // =16
    b0ac:      	add	x10, sp, #0x80
    b0b0:      	add	x0, sp, #0x80
    b0b4:      	mov	w1, #0x10               // =16
    b0b8:      	blr	x8
    b0bc:      	ldr	w21, [sp, #0x84]
    b0c0:      	ldr	x8, [sp, #0x40]
    b0c4:      	ldr	x10, [sp, #0x60]
    b0c8:      	sub	x12, x10, x8
    b0cc:      	ldr	w23, [sp, #0x68]
    b0d0:      	subs	w10, w21, w23
    b0d4:      	ldr	x9, [sp, #0x88]
    b0d8:      	csel	w10, wzr, w10, lo
    b0dc:      	cmp	w23, w21
    b0e0:      	csel	w11, w23, w21, lo
    b0e4:      	cinc	w13, w11, hi
    b0e8:      	sub	w14, w23, w13
    b0ec:      	subs	x12, x12, x13
    b0f0:      	str	w14, [sp, #0x68]
    b0f4:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    b0f8:      	cmp	x12, #0xfff
    b0fc:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    b100:      	cmp	w23, w21
    b104:      	b.ls	0xb110 <generic_rawtp_path+0xe20>
    b108:      	mov	w13, #0x2f              // =47
    b10c:      	strb	w13, [x8, x12]
    b110:      	add	x19, x8, x12
    b114:      	cmp	w23, w21
    b118:      	add	x2, x9, x10
    b11c:      	and	w1, w11, #0xff
    b120:      	mov	w8, #0x4                // =4
    b124:      	cinc	x0, x19, hi
    b128:      	blr	x8
    b12c:      	cmp	w23, w21
    b130:      	str	x19, [sp, #0x60]
    b134:      	add	x19, sp, #0x70
    b138:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    b13c:      	ldr	x21, [sp, #0x78]
    b140:      	ldp	x2, x24, [sp, #0x50]
    b144:      	str	x21, [sp, #0x48]
    b148:      	ldr	x8, [sp, #0x30]
    b14c:      	cmp	x21, x8
    b150:      	b.eq	0xb1b0 <generic_rawtp_path+0xec0>
    b154:      	b	0xb1bc <generic_rawtp_path+0xecc>
    b158:      	add	x2, x24, #0x10
    b15c:      	mov	w8, #0x4                // =4
    b160:      	add	x9, sp, #0x98
    b164:      	add	x0, sp, #0x98
    b168:      	mov	w1, #0x8                // =8
    b16c:      	blr	x8
    b170:      	ldr	x8, [sp, #0x58]
    b174:      	ldr	x9, [sp, #0x98]
    b178:      	cmp	x8, x9
    b17c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    b180:      	add	x2, x24, #0x18
    b184:      	mov	w8, #0x4                // =4
    b188:      	mov	x0, x22
    b18c:      	mov	w1, #0x8                // =8
    b190:      	blr	x8
    b194:      	ldr	x24, [sp, #0x98]
    b198:      	ldr	x21, [sp, #0x48]
    b19c:      	add	x2, x24, #0x20
    b1a0:      	stp	x2, x24, [sp, #0x50]
    b1a4:      	ldr	x8, [sp, #0x30]
    b1a8:      	cmp	x21, x8
    b1ac:      	b.ne	0xb1bc <generic_rawtp_path+0xecc>
    b1b0:      	ldr	x8, [sp, #0x38]
    b1b4:      	cmp	x2, x8
    b1b8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    b1bc:      	mov	w8, #0x4                // =4
    b1c0:      	add	x0, sp, #0x70
    b1c4:      	mov	w1, #0x8                // =8
    b1c8:      	blr	x8
    b1cc:      	ldr	x8, [sp, #0x70]
    b1d0:      	cmp	x21, x8
    b1d4:      	b.eq	0xb2c4 <generic_rawtp_path+0xfd4>
    b1d8:      	add	x23, x21, #0x18
    b1dc:      	mov	w8, #0x4                // =4
    b1e0:      	add	x9, sp, #0x98
    b1e4:      	add	x0, sp, #0x98
    b1e8:      	mov	w1, #0x8                // =8
    b1ec:      	mov	x2, x23
    b1f0:      	blr	x8
    b1f4:      	ldr	x8, [sp, #0x98]
    b1f8:      	cmp	x8, x21
    b1fc:      	b.eq	0xb2c4 <generic_rawtp_path+0xfd4>
    b200:      	mov	w8, #0x4                // =4
    b204:      	add	x9, sp, #0x78
    b208:      	add	x0, sp, #0x78
    b20c:      	mov	w1, #0x8                // =8
    b210:      	mov	x2, x23
    b214:      	blr	x8
    b218:      	add	x2, x21, #0x20
    b21c:      	mov	w8, #0x4                // =4
    b220:      	mov	w9, #0x10               // =16
    b224:      	add	x10, sp, #0x80
    b228:      	add	x0, sp, #0x80
    b22c:      	mov	w1, #0x10               // =16
    b230:      	blr	x8
    b234:      	ldr	w21, [sp, #0x84]
    b238:      	ldr	x8, [sp, #0x40]
    b23c:      	ldr	x10, [sp, #0x60]
    b240:      	sub	x12, x10, x8
    b244:      	ldr	w23, [sp, #0x68]
    b248:      	subs	w10, w21, w23
    b24c:      	ldr	x9, [sp, #0x88]
    b250:      	csel	w10, wzr, w10, lo
    b254:      	cmp	w23, w21
    b258:      	csel	w11, w23, w21, lo
    b25c:      	cinc	w13, w11, hi
    b260:      	sub	w14, w23, w13
    b264:      	subs	x12, x12, x13
    b268:      	str	w14, [sp, #0x68]
    b26c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    b270:      	cmp	x12, #0xfff
    b274:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    b278:      	cmp	w23, w21
    b27c:      	b.ls	0xb288 <generic_rawtp_path+0xf98>
    b280:      	mov	w13, #0x2f              // =47
    b284:      	strb	w13, [x8, x12]
    b288:      	add	x19, x8, x12
    b28c:      	cmp	w23, w21
    b290:      	add	x2, x9, x10
    b294:      	and	w1, w11, #0xff
    b298:      	mov	w8, #0x4                // =4
    b29c:      	cinc	x0, x19, hi
    b2a0:      	blr	x8
    b2a4:      	cmp	w23, w21
    b2a8:      	str	x19, [sp, #0x60]
    b2ac:      	add	x19, sp, #0x70
    b2b0:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    b2b4:      	ldr	x21, [sp, #0x78]
    b2b8:      	ldp	x2, x24, [sp, #0x50]
    b2bc:      	str	x21, [sp, #0x48]
    b2c0:      	b	0xb310 <generic_rawtp_path+0x1020>
    b2c4:      	add	x2, x24, #0x10
    b2c8:      	mov	w8, #0x4                // =4
    b2cc:      	add	x9, sp, #0x98
    b2d0:      	add	x0, sp, #0x98
    b2d4:      	mov	w1, #0x8                // =8
    b2d8:      	blr	x8
    b2dc:      	ldr	x8, [sp, #0x58]
    b2e0:      	ldr	x9, [sp, #0x98]
    b2e4:      	cmp	x8, x9
    b2e8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    b2ec:      	add	x2, x24, #0x18
    b2f0:      	mov	w8, #0x4                // =4
    b2f4:      	mov	x0, x22
    b2f8:      	mov	w1, #0x8                // =8
    b2fc:      	blr	x8
    b300:      	ldr	x24, [sp, #0x98]
    b304:      	ldr	x21, [sp, #0x48]
    b308:      	add	x2, x24, #0x20
    b30c:      	stp	x2, x24, [sp, #0x50]
    b310:      	ldr	x8, [sp, #0x30]
    b314:      	cmp	x21, x8
    b318:      	b.ne	0xb328 <generic_rawtp_path+0x1038>
    b31c:      	ldr	x8, [sp, #0x38]
    b320:      	cmp	x2, x8
    b324:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    b328:      	mov	w8, #0x4                // =4
    b32c:      	add	x0, sp, #0x70
    b330:      	mov	w1, #0x8                // =8
    b334:      	blr	x8
    b338:      	ldr	x8, [sp, #0x70]
    b33c:      	cmp	x21, x8
    b340:      	b.eq	0xb430 <generic_rawtp_path+0x1140>
    b344:      	add	x23, x21, #0x18
    b348:      	mov	w8, #0x4                // =4
    b34c:      	add	x9, sp, #0x98
    b350:      	add	x0, sp, #0x98
    b354:      	mov	w1, #0x8                // =8
    b358:      	mov	x2, x23
    b35c:      	blr	x8
    b360:      	ldr	x8, [sp, #0x98]
    b364:      	cmp	x8, x21
    b368:      	b.eq	0xb430 <generic_rawtp_path+0x1140>
    b36c:      	mov	w8, #0x4                // =4
    b370:      	add	x9, sp, #0x78
    b374:      	add	x0, sp, #0x78
    b378:      	mov	w1, #0x8                // =8
    b37c:      	mov	x2, x23
    b380:      	blr	x8
    b384:      	add	x2, x21, #0x20
    b388:      	mov	w8, #0x4                // =4
    b38c:      	mov	w9, #0x10               // =16
    b390:      	add	x10, sp, #0x80
    b394:      	add	x0, sp, #0x80
    b398:      	mov	w1, #0x10               // =16
    b39c:      	blr	x8
    b3a0:      	ldr	w21, [sp, #0x84]
    b3a4:      	ldr	x8, [sp, #0x40]
    b3a8:      	ldr	x10, [sp, #0x60]
    b3ac:      	sub	x12, x10, x8
    b3b0:      	ldr	w23, [sp, #0x68]
    b3b4:      	subs	w10, w21, w23
    b3b8:      	ldr	x9, [sp, #0x88]
    b3bc:      	csel	w10, wzr, w10, lo
    b3c0:      	cmp	w23, w21
    b3c4:      	csel	w11, w23, w21, lo
    b3c8:      	cinc	w13, w11, hi
    b3cc:      	sub	w14, w23, w13
    b3d0:      	subs	x12, x12, x13
    b3d4:      	str	w14, [sp, #0x68]
    b3d8:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    b3dc:      	cmp	x12, #0xfff
    b3e0:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    b3e4:      	cmp	w23, w21
    b3e8:      	b.ls	0xb3f4 <generic_rawtp_path+0x1104>
    b3ec:      	mov	w13, #0x2f              // =47
    b3f0:      	strb	w13, [x8, x12]
    b3f4:      	add	x19, x8, x12
    b3f8:      	cmp	w23, w21
    b3fc:      	add	x2, x9, x10
    b400:      	and	w1, w11, #0xff
    b404:      	mov	w8, #0x4                // =4
    b408:      	cinc	x0, x19, hi
    b40c:      	blr	x8
    b410:      	cmp	w23, w21
    b414:      	str	x19, [sp, #0x60]
    b418:      	add	x19, sp, #0x70
    b41c:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    b420:      	ldr	x21, [sp, #0x78]
    b424:      	ldp	x2, x24, [sp, #0x50]
    b428:      	str	x21, [sp, #0x48]
    b42c:      	b	0xb47c <generic_rawtp_path+0x118c>
    b430:      	add	x2, x24, #0x10
    b434:      	mov	w8, #0x4                // =4
    b438:      	add	x9, sp, #0x98
    b43c:      	add	x0, sp, #0x98
    b440:      	mov	w1, #0x8                // =8
    b444:      	blr	x8
    b448:      	ldr	x8, [sp, #0x58]
    b44c:      	ldr	x9, [sp, #0x98]
    b450:      	cmp	x8, x9
    b454:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    b458:      	add	x2, x24, #0x18
    b45c:      	mov	w8, #0x4                // =4
    b460:      	mov	x0, x22
    b464:      	mov	w1, #0x8                // =8
    b468:      	blr	x8
    b46c:      	ldr	x24, [sp, #0x98]
    b470:      	ldr	x21, [sp, #0x48]
    b474:      	add	x2, x24, #0x20
    b478:      	stp	x2, x24, [sp, #0x50]
    b47c:      	ldr	x8, [sp, #0x30]
    b480:      	cmp	x21, x8
    b484:      	b.ne	0xb494 <generic_rawtp_path+0x11a4>
    b488:      	ldr	x8, [sp, #0x38]
    b48c:      	cmp	x2, x8
    b490:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    b494:      	mov	w8, #0x4                // =4
    b498:      	add	x0, sp, #0x70
    b49c:      	mov	w1, #0x8                // =8
    b4a0:      	blr	x8
    b4a4:      	ldr	x8, [sp, #0x70]
    b4a8:      	cmp	x21, x8
    b4ac:      	b.eq	0xb59c <generic_rawtp_path+0x12ac>
    b4b0:      	add	x23, x21, #0x18
    b4b4:      	mov	w8, #0x4                // =4
    b4b8:      	add	x9, sp, #0x98
    b4bc:      	add	x0, sp, #0x98
    b4c0:      	mov	w1, #0x8                // =8
    b4c4:      	mov	x2, x23
    b4c8:      	blr	x8
    b4cc:      	ldr	x8, [sp, #0x98]
    b4d0:      	cmp	x8, x21
    b4d4:      	b.eq	0xb59c <generic_rawtp_path+0x12ac>
    b4d8:      	mov	w8, #0x4                // =4
    b4dc:      	add	x9, sp, #0x78
    b4e0:      	add	x0, sp, #0x78
    b4e4:      	mov	w1, #0x8                // =8
    b4e8:      	mov	x2, x23
    b4ec:      	blr	x8
    b4f0:      	add	x2, x21, #0x20
    b4f4:      	mov	w8, #0x4                // =4
    b4f8:      	mov	w9, #0x10               // =16
    b4fc:      	add	x10, sp, #0x80
    b500:      	add	x0, sp, #0x80
    b504:      	mov	w1, #0x10               // =16
    b508:      	blr	x8
    b50c:      	ldr	w21, [sp, #0x84]
    b510:      	ldr	x8, [sp, #0x40]
    b514:      	ldr	x10, [sp, #0x60]
    b518:      	sub	x12, x10, x8
    b51c:      	ldr	w23, [sp, #0x68]
    b520:      	subs	w10, w21, w23
    b524:      	ldr	x9, [sp, #0x88]
    b528:      	csel	w10, wzr, w10, lo
    b52c:      	cmp	w23, w21
    b530:      	csel	w11, w23, w21, lo
    b534:      	cinc	w13, w11, hi
    b538:      	sub	w14, w23, w13
    b53c:      	subs	x12, x12, x13
    b540:      	str	w14, [sp, #0x68]
    b544:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    b548:      	cmp	x12, #0xfff
    b54c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    b550:      	cmp	w23, w21
    b554:      	b.ls	0xb560 <generic_rawtp_path+0x1270>
    b558:      	mov	w13, #0x2f              // =47
    b55c:      	strb	w13, [x8, x12]
    b560:      	add	x19, x8, x12
    b564:      	cmp	w23, w21
    b568:      	add	x2, x9, x10
    b56c:      	and	w1, w11, #0xff
    b570:      	mov	w8, #0x4                // =4
    b574:      	cinc	x0, x19, hi
    b578:      	blr	x8
    b57c:      	cmp	w23, w21
    b580:      	str	x19, [sp, #0x60]
    b584:      	add	x19, sp, #0x70
    b588:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    b58c:      	ldr	x21, [sp, #0x78]
    b590:      	ldp	x2, x24, [sp, #0x50]
    b594:      	str	x21, [sp, #0x48]
    b598:      	b	0xb5e8 <generic_rawtp_path+0x12f8>
    b59c:      	add	x2, x24, #0x10
    b5a0:      	mov	w8, #0x4                // =4
    b5a4:      	add	x9, sp, #0x98
    b5a8:      	add	x0, sp, #0x98
    b5ac:      	mov	w1, #0x8                // =8
    b5b0:      	blr	x8
    b5b4:      	ldr	x8, [sp, #0x58]
    b5b8:      	ldr	x9, [sp, #0x98]
    b5bc:      	cmp	x8, x9
    b5c0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    b5c4:      	add	x2, x24, #0x18
    b5c8:      	mov	w8, #0x4                // =4
    b5cc:      	mov	x0, x22
    b5d0:      	mov	w1, #0x8                // =8
    b5d4:      	blr	x8
    b5d8:      	ldr	x24, [sp, #0x98]
    b5dc:      	ldr	x21, [sp, #0x48]
    b5e0:      	add	x2, x24, #0x20
    b5e4:      	stp	x2, x24, [sp, #0x50]
    b5e8:      	ldr	x8, [sp, #0x30]
    b5ec:      	cmp	x21, x8
    b5f0:      	b.ne	0xb600 <generic_rawtp_path+0x1310>
    b5f4:      	ldr	x8, [sp, #0x38]
    b5f8:      	cmp	x2, x8
    b5fc:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    b600:      	mov	w8, #0x4                // =4
    b604:      	add	x0, sp, #0x70
    b608:      	mov	w1, #0x8                // =8
    b60c:      	blr	x8
    b610:      	ldr	x8, [sp, #0x70]
    b614:      	cmp	x21, x8
    b618:      	b.eq	0xb708 <generic_rawtp_path+0x1418>
    b61c:      	add	x23, x21, #0x18
    b620:      	mov	w8, #0x4                // =4
    b624:      	add	x9, sp, #0x98
    b628:      	add	x0, sp, #0x98
    b62c:      	mov	w1, #0x8                // =8
    b630:      	mov	x2, x23
    b634:      	blr	x8
    b638:      	ldr	x8, [sp, #0x98]
    b63c:      	cmp	x8, x21
    b640:      	b.eq	0xb708 <generic_rawtp_path+0x1418>
    b644:      	mov	w8, #0x4                // =4
    b648:      	add	x9, sp, #0x78
    b64c:      	add	x0, sp, #0x78
    b650:      	mov	w1, #0x8                // =8
    b654:      	mov	x2, x23
    b658:      	blr	x8
    b65c:      	add	x2, x21, #0x20
    b660:      	mov	w8, #0x4                // =4
    b664:      	mov	w9, #0x10               // =16
    b668:      	add	x10, sp, #0x80
    b66c:      	add	x0, sp, #0x80
    b670:      	mov	w1, #0x10               // =16
    b674:      	blr	x8
    b678:      	ldr	w21, [sp, #0x84]
    b67c:      	ldr	x8, [sp, #0x40]
    b680:      	ldr	x10, [sp, #0x60]
    b684:      	sub	x12, x10, x8
    b688:      	ldr	w23, [sp, #0x68]
    b68c:      	subs	w10, w21, w23
    b690:      	ldr	x9, [sp, #0x88]
    b694:      	csel	w10, wzr, w10, lo
    b698:      	cmp	w23, w21
    b69c:      	csel	w11, w23, w21, lo
    b6a0:      	cinc	w13, w11, hi
    b6a4:      	sub	w14, w23, w13
    b6a8:      	subs	x12, x12, x13
    b6ac:      	str	w14, [sp, #0x68]
    b6b0:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    b6b4:      	cmp	x12, #0xfff
    b6b8:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    b6bc:      	cmp	w23, w21
    b6c0:      	b.ls	0xb6cc <generic_rawtp_path+0x13dc>
    b6c4:      	mov	w13, #0x2f              // =47
    b6c8:      	strb	w13, [x8, x12]
    b6cc:      	add	x19, x8, x12
    b6d0:      	cmp	w23, w21
    b6d4:      	add	x2, x9, x10
    b6d8:      	and	w1, w11, #0xff
    b6dc:      	mov	w8, #0x4                // =4
    b6e0:      	cinc	x0, x19, hi
    b6e4:      	blr	x8
    b6e8:      	cmp	w23, w21
    b6ec:      	str	x19, [sp, #0x60]
    b6f0:      	add	x19, sp, #0x70
    b6f4:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    b6f8:      	ldr	x21, [sp, #0x78]
    b6fc:      	ldp	x2, x24, [sp, #0x50]
    b700:      	str	x21, [sp, #0x48]
    b704:      	b	0xb754 <generic_rawtp_path+0x1464>
    b708:      	add	x2, x24, #0x10
    b70c:      	mov	w8, #0x4                // =4
    b710:      	add	x9, sp, #0x98
    b714:      	add	x0, sp, #0x98
    b718:      	mov	w1, #0x8                // =8
    b71c:      	blr	x8
    b720:      	ldr	x8, [sp, #0x58]
    b724:      	ldr	x9, [sp, #0x98]
    b728:      	cmp	x8, x9
    b72c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    b730:      	add	x2, x24, #0x18
    b734:      	mov	w8, #0x4                // =4
    b738:      	mov	x0, x22
    b73c:      	mov	w1, #0x8                // =8
    b740:      	blr	x8
    b744:      	ldr	x24, [sp, #0x98]
    b748:      	ldr	x21, [sp, #0x48]
    b74c:      	add	x2, x24, #0x20
    b750:      	stp	x2, x24, [sp, #0x50]
    b754:      	ldr	x8, [sp, #0x30]
    b758:      	cmp	x21, x8
    b75c:      	b.ne	0xb76c <generic_rawtp_path+0x147c>
    b760:      	ldr	x8, [sp, #0x38]
    b764:      	cmp	x2, x8
    b768:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    b76c:      	mov	w8, #0x4                // =4
    b770:      	add	x0, sp, #0x70
    b774:      	mov	w1, #0x8                // =8
    b778:      	blr	x8
    b77c:      	ldr	x8, [sp, #0x70]
    b780:      	cmp	x21, x8
    b784:      	b.eq	0xb874 <generic_rawtp_path+0x1584>
    b788:      	add	x23, x21, #0x18
    b78c:      	mov	w8, #0x4                // =4
    b790:      	add	x9, sp, #0x98
    b794:      	add	x0, sp, #0x98
    b798:      	mov	w1, #0x8                // =8
    b79c:      	mov	x2, x23
    b7a0:      	blr	x8
    b7a4:      	ldr	x8, [sp, #0x98]
    b7a8:      	cmp	x8, x21
    b7ac:      	b.eq	0xb874 <generic_rawtp_path+0x1584>
    b7b0:      	mov	w8, #0x4                // =4
    b7b4:      	add	x9, sp, #0x78
    b7b8:      	add	x0, sp, #0x78
    b7bc:      	mov	w1, #0x8                // =8
    b7c0:      	mov	x2, x23
    b7c4:      	blr	x8
    b7c8:      	add	x2, x21, #0x20
    b7cc:      	mov	w8, #0x4                // =4
    b7d0:      	mov	w9, #0x10               // =16
    b7d4:      	add	x10, sp, #0x80
    b7d8:      	add	x0, sp, #0x80
    b7dc:      	mov	w1, #0x10               // =16
    b7e0:      	blr	x8
    b7e4:      	ldr	w21, [sp, #0x84]
    b7e8:      	ldr	x8, [sp, #0x40]
    b7ec:      	ldr	x10, [sp, #0x60]
    b7f0:      	sub	x12, x10, x8
    b7f4:      	ldr	w23, [sp, #0x68]
    b7f8:      	subs	w10, w21, w23
    b7fc:      	ldr	x9, [sp, #0x88]
    b800:      	csel	w10, wzr, w10, lo
    b804:      	cmp	w23, w21
    b808:      	csel	w11, w23, w21, lo
    b80c:      	cinc	w13, w11, hi
    b810:      	sub	w14, w23, w13
    b814:      	subs	x12, x12, x13
    b818:      	str	w14, [sp, #0x68]
    b81c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    b820:      	cmp	x12, #0xfff
    b824:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    b828:      	cmp	w23, w21
    b82c:      	b.ls	0xb838 <generic_rawtp_path+0x1548>
    b830:      	mov	w13, #0x2f              // =47
    b834:      	strb	w13, [x8, x12]
    b838:      	add	x19, x8, x12
    b83c:      	cmp	w23, w21
    b840:      	add	x2, x9, x10
    b844:      	and	w1, w11, #0xff
    b848:      	mov	w8, #0x4                // =4
    b84c:      	cinc	x0, x19, hi
    b850:      	blr	x8
    b854:      	cmp	w23, w21
    b858:      	str	x19, [sp, #0x60]
    b85c:      	add	x19, sp, #0x70
    b860:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    b864:      	ldr	x21, [sp, #0x78]
    b868:      	ldp	x2, x24, [sp, #0x50]
    b86c:      	str	x21, [sp, #0x48]
    b870:      	b	0xb8c0 <generic_rawtp_path+0x15d0>
    b874:      	add	x2, x24, #0x10
    b878:      	mov	w8, #0x4                // =4
    b87c:      	add	x9, sp, #0x98
    b880:      	add	x0, sp, #0x98
    b884:      	mov	w1, #0x8                // =8
    b888:      	blr	x8
    b88c:      	ldr	x8, [sp, #0x58]
    b890:      	ldr	x9, [sp, #0x98]
    b894:      	cmp	x8, x9
    b898:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    b89c:      	add	x2, x24, #0x18
    b8a0:      	mov	w8, #0x4                // =4
    b8a4:      	mov	x0, x22
    b8a8:      	mov	w1, #0x8                // =8
    b8ac:      	blr	x8
    b8b0:      	ldr	x24, [sp, #0x98]
    b8b4:      	ldr	x21, [sp, #0x48]
    b8b8:      	add	x2, x24, #0x20
    b8bc:      	stp	x2, x24, [sp, #0x50]
    b8c0:      	ldr	x8, [sp, #0x30]
    b8c4:      	cmp	x21, x8
    b8c8:      	b.ne	0xb8d8 <generic_rawtp_path+0x15e8>
    b8cc:      	ldr	x8, [sp, #0x38]
    b8d0:      	cmp	x2, x8
    b8d4:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    b8d8:      	mov	w8, #0x4                // =4
    b8dc:      	add	x0, sp, #0x70
    b8e0:      	mov	w1, #0x8                // =8
    b8e4:      	blr	x8
    b8e8:      	ldr	x8, [sp, #0x70]
    b8ec:      	cmp	x21, x8
    b8f0:      	b.eq	0xb9e0 <generic_rawtp_path+0x16f0>
    b8f4:      	add	x23, x21, #0x18
    b8f8:      	mov	w8, #0x4                // =4
    b8fc:      	add	x9, sp, #0x98
    b900:      	add	x0, sp, #0x98
    b904:      	mov	w1, #0x8                // =8
    b908:      	mov	x2, x23
    b90c:      	blr	x8
    b910:      	ldr	x8, [sp, #0x98]
    b914:      	cmp	x8, x21
    b918:      	b.eq	0xb9e0 <generic_rawtp_path+0x16f0>
    b91c:      	mov	w8, #0x4                // =4
    b920:      	add	x9, sp, #0x78
    b924:      	add	x0, sp, #0x78
    b928:      	mov	w1, #0x8                // =8
    b92c:      	mov	x2, x23
    b930:      	blr	x8
    b934:      	add	x2, x21, #0x20
    b938:      	mov	w8, #0x4                // =4
    b93c:      	mov	w9, #0x10               // =16
    b940:      	add	x10, sp, #0x80
    b944:      	add	x0, sp, #0x80
    b948:      	mov	w1, #0x10               // =16
    b94c:      	blr	x8
    b950:      	ldr	w21, [sp, #0x84]
    b954:      	ldr	x8, [sp, #0x40]
    b958:      	ldr	x10, [sp, #0x60]
    b95c:      	sub	x12, x10, x8
    b960:      	ldr	w23, [sp, #0x68]
    b964:      	subs	w10, w21, w23
    b968:      	ldr	x9, [sp, #0x88]
    b96c:      	csel	w10, wzr, w10, lo
    b970:      	cmp	w23, w21
    b974:      	csel	w11, w23, w21, lo
    b978:      	cinc	w13, w11, hi
    b97c:      	sub	w14, w23, w13
    b980:      	subs	x12, x12, x13
    b984:      	str	w14, [sp, #0x68]
    b988:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    b98c:      	cmp	x12, #0xfff
    b990:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    b994:      	cmp	w23, w21
    b998:      	b.ls	0xb9a4 <generic_rawtp_path+0x16b4>
    b99c:      	mov	w13, #0x2f              // =47
    b9a0:      	strb	w13, [x8, x12]
    b9a4:      	add	x19, x8, x12
    b9a8:      	cmp	w23, w21
    b9ac:      	add	x2, x9, x10
    b9b0:      	and	w1, w11, #0xff
    b9b4:      	mov	w8, #0x4                // =4
    b9b8:      	cinc	x0, x19, hi
    b9bc:      	blr	x8
    b9c0:      	cmp	w23, w21
    b9c4:      	str	x19, [sp, #0x60]
    b9c8:      	add	x19, sp, #0x70
    b9cc:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    b9d0:      	ldr	x21, [sp, #0x78]
    b9d4:      	ldp	x2, x24, [sp, #0x50]
    b9d8:      	str	x21, [sp, #0x48]
    b9dc:      	b	0xba2c <generic_rawtp_path+0x173c>
    b9e0:      	add	x2, x24, #0x10
    b9e4:      	mov	w8, #0x4                // =4
    b9e8:      	add	x9, sp, #0x98
    b9ec:      	add	x0, sp, #0x98
    b9f0:      	mov	w1, #0x8                // =8
    b9f4:      	blr	x8
    b9f8:      	ldr	x8, [sp, #0x58]
    b9fc:      	ldr	x9, [sp, #0x98]
    ba00:      	cmp	x8, x9
    ba04:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    ba08:      	add	x2, x24, #0x18
    ba0c:      	mov	w8, #0x4                // =4
    ba10:      	mov	x0, x22
    ba14:      	mov	w1, #0x8                // =8
    ba18:      	blr	x8
    ba1c:      	ldr	x24, [sp, #0x98]
    ba20:      	ldr	x21, [sp, #0x48]
    ba24:      	add	x2, x24, #0x20
    ba28:      	stp	x2, x24, [sp, #0x50]
    ba2c:      	ldr	x8, [sp, #0x30]
    ba30:      	cmp	x21, x8
    ba34:      	b.ne	0xba44 <generic_rawtp_path+0x1754>
    ba38:      	ldr	x8, [sp, #0x38]
    ba3c:      	cmp	x2, x8
    ba40:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    ba44:      	mov	w8, #0x4                // =4
    ba48:      	add	x0, sp, #0x70
    ba4c:      	mov	w1, #0x8                // =8
    ba50:      	blr	x8
    ba54:      	ldr	x8, [sp, #0x70]
    ba58:      	cmp	x21, x8
    ba5c:      	b.eq	0xbb4c <generic_rawtp_path+0x185c>
    ba60:      	add	x23, x21, #0x18
    ba64:      	mov	w8, #0x4                // =4
    ba68:      	add	x9, sp, #0x98
    ba6c:      	add	x0, sp, #0x98
    ba70:      	mov	w1, #0x8                // =8
    ba74:      	mov	x2, x23
    ba78:      	blr	x8
    ba7c:      	ldr	x8, [sp, #0x98]
    ba80:      	cmp	x8, x21
    ba84:      	b.eq	0xbb4c <generic_rawtp_path+0x185c>
    ba88:      	mov	w8, #0x4                // =4
    ba8c:      	add	x9, sp, #0x78
    ba90:      	add	x0, sp, #0x78
    ba94:      	mov	w1, #0x8                // =8
    ba98:      	mov	x2, x23
    ba9c:      	blr	x8
    baa0:      	add	x2, x21, #0x20
    baa4:      	mov	w8, #0x4                // =4
    baa8:      	mov	w9, #0x10               // =16
    baac:      	add	x10, sp, #0x80
    bab0:      	add	x0, sp, #0x80
    bab4:      	mov	w1, #0x10               // =16
    bab8:      	blr	x8
    babc:      	ldr	w21, [sp, #0x84]
    bac0:      	ldr	x8, [sp, #0x40]
    bac4:      	ldr	x10, [sp, #0x60]
    bac8:      	sub	x12, x10, x8
    bacc:      	ldr	w23, [sp, #0x68]
    bad0:      	subs	w10, w21, w23
    bad4:      	ldr	x9, [sp, #0x88]
    bad8:      	csel	w10, wzr, w10, lo
    badc:      	cmp	w23, w21
    bae0:      	csel	w11, w23, w21, lo
    bae4:      	cinc	w13, w11, hi
    bae8:      	sub	w14, w23, w13
    baec:      	subs	x12, x12, x13
    baf0:      	str	w14, [sp, #0x68]
    baf4:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    baf8:      	cmp	x12, #0xfff
    bafc:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    bb00:      	cmp	w23, w21
    bb04:      	b.ls	0xbb10 <generic_rawtp_path+0x1820>
    bb08:      	mov	w13, #0x2f              // =47
    bb0c:      	strb	w13, [x8, x12]
    bb10:      	add	x19, x8, x12
    bb14:      	cmp	w23, w21
    bb18:      	add	x2, x9, x10
    bb1c:      	and	w1, w11, #0xff
    bb20:      	mov	w8, #0x4                // =4
    bb24:      	cinc	x0, x19, hi
    bb28:      	blr	x8
    bb2c:      	cmp	w23, w21
    bb30:      	str	x19, [sp, #0x60]
    bb34:      	add	x19, sp, #0x70
    bb38:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    bb3c:      	ldr	x21, [sp, #0x78]
    bb40:      	ldp	x2, x24, [sp, #0x50]
    bb44:      	str	x21, [sp, #0x48]
    bb48:      	b	0xbb98 <generic_rawtp_path+0x18a8>
    bb4c:      	add	x2, x24, #0x10
    bb50:      	mov	w8, #0x4                // =4
    bb54:      	add	x9, sp, #0x98
    bb58:      	add	x0, sp, #0x98
    bb5c:      	mov	w1, #0x8                // =8
    bb60:      	blr	x8
    bb64:      	ldr	x8, [sp, #0x58]
    bb68:      	ldr	x9, [sp, #0x98]
    bb6c:      	cmp	x8, x9
    bb70:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    bb74:      	add	x2, x24, #0x18
    bb78:      	mov	w8, #0x4                // =4
    bb7c:      	mov	x0, x22
    bb80:      	mov	w1, #0x8                // =8
    bb84:      	blr	x8
    bb88:      	ldr	x24, [sp, #0x98]
    bb8c:      	ldr	x21, [sp, #0x48]
    bb90:      	add	x2, x24, #0x20
    bb94:      	stp	x2, x24, [sp, #0x50]
    bb98:      	ldr	x8, [sp, #0x30]
    bb9c:      	cmp	x21, x8
    bba0:      	b.ne	0xbbb0 <generic_rawtp_path+0x18c0>
    bba4:      	ldr	x8, [sp, #0x38]
    bba8:      	cmp	x2, x8
    bbac:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    bbb0:      	mov	w8, #0x4                // =4
    bbb4:      	add	x0, sp, #0x70
    bbb8:      	mov	w1, #0x8                // =8
    bbbc:      	blr	x8
    bbc0:      	ldr	x8, [sp, #0x70]
    bbc4:      	cmp	x21, x8
    bbc8:      	b.eq	0xbcb8 <generic_rawtp_path+0x19c8>
    bbcc:      	add	x23, x21, #0x18
    bbd0:      	mov	w8, #0x4                // =4
    bbd4:      	add	x9, sp, #0x98
    bbd8:      	add	x0, sp, #0x98
    bbdc:      	mov	w1, #0x8                // =8
    bbe0:      	mov	x2, x23
    bbe4:      	blr	x8
    bbe8:      	ldr	x8, [sp, #0x98]
    bbec:      	cmp	x8, x21
    bbf0:      	b.eq	0xbcb8 <generic_rawtp_path+0x19c8>
    bbf4:      	mov	w8, #0x4                // =4
    bbf8:      	add	x9, sp, #0x78
    bbfc:      	add	x0, sp, #0x78
    bc00:      	mov	w1, #0x8                // =8
    bc04:      	mov	x2, x23
    bc08:      	blr	x8
    bc0c:      	add	x2, x21, #0x20
    bc10:      	mov	w8, #0x4                // =4
    bc14:      	mov	w9, #0x10               // =16
    bc18:      	add	x10, sp, #0x80
    bc1c:      	add	x0, sp, #0x80
    bc20:      	mov	w1, #0x10               // =16
    bc24:      	blr	x8
    bc28:      	ldr	w21, [sp, #0x84]
    bc2c:      	ldr	x8, [sp, #0x40]
    bc30:      	ldr	x10, [sp, #0x60]
    bc34:      	sub	x12, x10, x8
    bc38:      	ldr	w23, [sp, #0x68]
    bc3c:      	subs	w10, w21, w23
    bc40:      	ldr	x9, [sp, #0x88]
    bc44:      	csel	w10, wzr, w10, lo
    bc48:      	cmp	w23, w21
    bc4c:      	csel	w11, w23, w21, lo
    bc50:      	cinc	w13, w11, hi
    bc54:      	sub	w14, w23, w13
    bc58:      	subs	x12, x12, x13
    bc5c:      	str	w14, [sp, #0x68]
    bc60:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    bc64:      	cmp	x12, #0xfff
    bc68:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    bc6c:      	cmp	w23, w21
    bc70:      	b.ls	0xbc7c <generic_rawtp_path+0x198c>
    bc74:      	mov	w13, #0x2f              // =47
    bc78:      	strb	w13, [x8, x12]
    bc7c:      	add	x19, x8, x12
    bc80:      	cmp	w23, w21
    bc84:      	add	x2, x9, x10
    bc88:      	and	w1, w11, #0xff
    bc8c:      	mov	w8, #0x4                // =4
    bc90:      	cinc	x0, x19, hi
    bc94:      	blr	x8
    bc98:      	cmp	w23, w21
    bc9c:      	str	x19, [sp, #0x60]
    bca0:      	add	x19, sp, #0x70
    bca4:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    bca8:      	ldr	x21, [sp, #0x78]
    bcac:      	ldp	x2, x24, [sp, #0x50]
    bcb0:      	str	x21, [sp, #0x48]
    bcb4:      	b	0xbd04 <generic_rawtp_path+0x1a14>
    bcb8:      	add	x2, x24, #0x10
    bcbc:      	mov	w8, #0x4                // =4
    bcc0:      	add	x9, sp, #0x98
    bcc4:      	add	x0, sp, #0x98
    bcc8:      	mov	w1, #0x8                // =8
    bccc:      	blr	x8
    bcd0:      	ldr	x8, [sp, #0x58]
    bcd4:      	ldr	x9, [sp, #0x98]
    bcd8:      	cmp	x8, x9
    bcdc:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    bce0:      	add	x2, x24, #0x18
    bce4:      	mov	w8, #0x4                // =4
    bce8:      	mov	x0, x22
    bcec:      	mov	w1, #0x8                // =8
    bcf0:      	blr	x8
    bcf4:      	ldr	x24, [sp, #0x98]
    bcf8:      	ldr	x21, [sp, #0x48]
    bcfc:      	add	x2, x24, #0x20
    bd00:      	stp	x2, x24, [sp, #0x50]
    bd04:      	ldr	x8, [sp, #0x30]
    bd08:      	cmp	x21, x8
    bd0c:      	b.ne	0xbd1c <generic_rawtp_path+0x1a2c>
    bd10:      	ldr	x8, [sp, #0x38]
    bd14:      	cmp	x2, x8
    bd18:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    bd1c:      	mov	w8, #0x4                // =4
    bd20:      	add	x0, sp, #0x70
    bd24:      	mov	w1, #0x8                // =8
    bd28:      	blr	x8
    bd2c:      	ldr	x8, [sp, #0x70]
    bd30:      	cmp	x21, x8
    bd34:      	b.eq	0xbe24 <generic_rawtp_path+0x1b34>
    bd38:      	add	x23, x21, #0x18
    bd3c:      	mov	w8, #0x4                // =4
    bd40:      	add	x9, sp, #0x98
    bd44:      	add	x0, sp, #0x98
    bd48:      	mov	w1, #0x8                // =8
    bd4c:      	mov	x2, x23
    bd50:      	blr	x8
    bd54:      	ldr	x8, [sp, #0x98]
    bd58:      	cmp	x8, x21
    bd5c:      	b.eq	0xbe24 <generic_rawtp_path+0x1b34>
    bd60:      	mov	w8, #0x4                // =4
    bd64:      	add	x9, sp, #0x78
    bd68:      	add	x0, sp, #0x78
    bd6c:      	mov	w1, #0x8                // =8
    bd70:      	mov	x2, x23
    bd74:      	blr	x8
    bd78:      	add	x2, x21, #0x20
    bd7c:      	mov	w8, #0x4                // =4
    bd80:      	mov	w9, #0x10               // =16
    bd84:      	add	x10, sp, #0x80
    bd88:      	add	x0, sp, #0x80
    bd8c:      	mov	w1, #0x10               // =16
    bd90:      	blr	x8
    bd94:      	ldr	w21, [sp, #0x84]
    bd98:      	ldr	x8, [sp, #0x40]
    bd9c:      	ldr	x10, [sp, #0x60]
    bda0:      	sub	x12, x10, x8
    bda4:      	ldr	w23, [sp, #0x68]
    bda8:      	subs	w10, w21, w23
    bdac:      	ldr	x9, [sp, #0x88]
    bdb0:      	csel	w10, wzr, w10, lo
    bdb4:      	cmp	w23, w21
    bdb8:      	csel	w11, w23, w21, lo
    bdbc:      	cinc	w13, w11, hi
    bdc0:      	sub	w14, w23, w13
    bdc4:      	subs	x12, x12, x13
    bdc8:      	str	w14, [sp, #0x68]
    bdcc:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    bdd0:      	cmp	x12, #0xfff
    bdd4:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    bdd8:      	cmp	w23, w21
    bddc:      	b.ls	0xbde8 <generic_rawtp_path+0x1af8>
    bde0:      	mov	w13, #0x2f              // =47
    bde4:      	strb	w13, [x8, x12]
    bde8:      	add	x19, x8, x12
    bdec:      	cmp	w23, w21
    bdf0:      	add	x2, x9, x10
    bdf4:      	and	w1, w11, #0xff
    bdf8:      	mov	w8, #0x4                // =4
    bdfc:      	cinc	x0, x19, hi
    be00:      	blr	x8
    be04:      	cmp	w23, w21
    be08:      	str	x19, [sp, #0x60]
    be0c:      	add	x19, sp, #0x70
    be10:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    be14:      	ldr	x21, [sp, #0x78]
    be18:      	ldp	x2, x24, [sp, #0x50]
    be1c:      	str	x21, [sp, #0x48]
    be20:      	b	0xbe70 <generic_rawtp_path+0x1b80>
    be24:      	add	x2, x24, #0x10
    be28:      	mov	w8, #0x4                // =4
    be2c:      	add	x9, sp, #0x98
    be30:      	add	x0, sp, #0x98
    be34:      	mov	w1, #0x8                // =8
    be38:      	blr	x8
    be3c:      	ldr	x8, [sp, #0x58]
    be40:      	ldr	x9, [sp, #0x98]
    be44:      	cmp	x8, x9
    be48:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    be4c:      	add	x2, x24, #0x18
    be50:      	mov	w8, #0x4                // =4
    be54:      	mov	x0, x22
    be58:      	mov	w1, #0x8                // =8
    be5c:      	blr	x8
    be60:      	ldr	x24, [sp, #0x98]
    be64:      	ldr	x21, [sp, #0x48]
    be68:      	add	x2, x24, #0x20
    be6c:      	stp	x2, x24, [sp, #0x50]
    be70:      	ldr	x8, [sp, #0x30]
    be74:      	cmp	x21, x8
    be78:      	b.ne	0xbe88 <generic_rawtp_path+0x1b98>
    be7c:      	ldr	x8, [sp, #0x38]
    be80:      	cmp	x2, x8
    be84:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    be88:      	mov	w8, #0x4                // =4
    be8c:      	add	x0, sp, #0x70
    be90:      	mov	w1, #0x8                // =8
    be94:      	blr	x8
    be98:      	ldr	x8, [sp, #0x70]
    be9c:      	cmp	x21, x8
    bea0:      	b.eq	0xbf90 <generic_rawtp_path+0x1ca0>
    bea4:      	add	x23, x21, #0x18
    bea8:      	mov	w8, #0x4                // =4
    beac:      	add	x9, sp, #0x98
    beb0:      	add	x0, sp, #0x98
    beb4:      	mov	w1, #0x8                // =8
    beb8:      	mov	x2, x23
    bebc:      	blr	x8
    bec0:      	ldr	x8, [sp, #0x98]
    bec4:      	cmp	x8, x21
    bec8:      	b.eq	0xbf90 <generic_rawtp_path+0x1ca0>
    becc:      	mov	w8, #0x4                // =4
    bed0:      	add	x9, sp, #0x78
    bed4:      	add	x0, sp, #0x78
    bed8:      	mov	w1, #0x8                // =8
    bedc:      	mov	x2, x23
    bee0:      	blr	x8
    bee4:      	add	x2, x21, #0x20
    bee8:      	mov	w8, #0x4                // =4
    beec:      	mov	w9, #0x10               // =16
    bef0:      	add	x10, sp, #0x80
    bef4:      	add	x0, sp, #0x80
    bef8:      	mov	w1, #0x10               // =16
    befc:      	blr	x8
    bf00:      	ldr	w21, [sp, #0x84]
    bf04:      	ldr	x8, [sp, #0x40]
    bf08:      	ldr	x10, [sp, #0x60]
    bf0c:      	sub	x12, x10, x8
    bf10:      	ldr	w23, [sp, #0x68]
    bf14:      	subs	w10, w21, w23
    bf18:      	ldr	x9, [sp, #0x88]
    bf1c:      	csel	w10, wzr, w10, lo
    bf20:      	cmp	w23, w21
    bf24:      	csel	w11, w23, w21, lo
    bf28:      	cinc	w13, w11, hi
    bf2c:      	sub	w14, w23, w13
    bf30:      	subs	x12, x12, x13
    bf34:      	str	w14, [sp, #0x68]
    bf38:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    bf3c:      	cmp	x12, #0xfff
    bf40:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    bf44:      	cmp	w23, w21
    bf48:      	b.ls	0xbf54 <generic_rawtp_path+0x1c64>
    bf4c:      	mov	w13, #0x2f              // =47
    bf50:      	strb	w13, [x8, x12]
    bf54:      	add	x19, x8, x12
    bf58:      	cmp	w23, w21
    bf5c:      	add	x2, x9, x10
    bf60:      	and	w1, w11, #0xff
    bf64:      	mov	w8, #0x4                // =4
    bf68:      	cinc	x0, x19, hi
    bf6c:      	blr	x8
    bf70:      	cmp	w23, w21
    bf74:      	str	x19, [sp, #0x60]
    bf78:      	add	x19, sp, #0x70
    bf7c:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    bf80:      	ldr	x21, [sp, #0x78]
    bf84:      	ldp	x2, x24, [sp, #0x50]
    bf88:      	str	x21, [sp, #0x48]
    bf8c:      	b	0xbfdc <generic_rawtp_path+0x1cec>
    bf90:      	add	x2, x24, #0x10
    bf94:      	mov	w8, #0x4                // =4
    bf98:      	add	x9, sp, #0x98
    bf9c:      	add	x0, sp, #0x98
    bfa0:      	mov	w1, #0x8                // =8
    bfa4:      	blr	x8
    bfa8:      	ldr	x8, [sp, #0x58]
    bfac:      	ldr	x9, [sp, #0x98]
    bfb0:      	cmp	x8, x9
    bfb4:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    bfb8:      	add	x2, x24, #0x18
    bfbc:      	mov	w8, #0x4                // =4
    bfc0:      	mov	x0, x22
    bfc4:      	mov	w1, #0x8                // =8
    bfc8:      	blr	x8
    bfcc:      	ldr	x24, [sp, #0x98]
    bfd0:      	ldr	x21, [sp, #0x48]
    bfd4:      	add	x2, x24, #0x20
    bfd8:      	stp	x2, x24, [sp, #0x50]
    bfdc:      	ldr	x8, [sp, #0x30]
    bfe0:      	cmp	x21, x8
    bfe4:      	b.ne	0xbff4 <generic_rawtp_path+0x1d04>
    bfe8:      	ldr	x8, [sp, #0x38]
    bfec:      	cmp	x2, x8
    bff0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    bff4:      	mov	w8, #0x4                // =4
    bff8:      	add	x0, sp, #0x70
    bffc:      	mov	w1, #0x8                // =8
    c000:      	blr	x8
    c004:      	ldr	x8, [sp, #0x70]
    c008:      	cmp	x21, x8
    c00c:      	b.eq	0xc0fc <generic_rawtp_path+0x1e0c>
    c010:      	add	x23, x21, #0x18
    c014:      	mov	w8, #0x4                // =4
    c018:      	add	x9, sp, #0x98
    c01c:      	add	x0, sp, #0x98
    c020:      	mov	w1, #0x8                // =8
    c024:      	mov	x2, x23
    c028:      	blr	x8
    c02c:      	ldr	x8, [sp, #0x98]
    c030:      	cmp	x8, x21
    c034:      	b.eq	0xc0fc <generic_rawtp_path+0x1e0c>
    c038:      	mov	w8, #0x4                // =4
    c03c:      	add	x9, sp, #0x78
    c040:      	add	x0, sp, #0x78
    c044:      	mov	w1, #0x8                // =8
    c048:      	mov	x2, x23
    c04c:      	blr	x8
    c050:      	add	x2, x21, #0x20
    c054:      	mov	w8, #0x4                // =4
    c058:      	mov	w9, #0x10               // =16
    c05c:      	add	x10, sp, #0x80
    c060:      	add	x0, sp, #0x80
    c064:      	mov	w1, #0x10               // =16
    c068:      	blr	x8
    c06c:      	ldr	w21, [sp, #0x84]
    c070:      	ldr	x8, [sp, #0x40]
    c074:      	ldr	x10, [sp, #0x60]
    c078:      	sub	x12, x10, x8
    c07c:      	ldr	w23, [sp, #0x68]
    c080:      	subs	w10, w21, w23
    c084:      	ldr	x9, [sp, #0x88]
    c088:      	csel	w10, wzr, w10, lo
    c08c:      	cmp	w23, w21
    c090:      	csel	w11, w23, w21, lo
    c094:      	cinc	w13, w11, hi
    c098:      	sub	w14, w23, w13
    c09c:      	subs	x12, x12, x13
    c0a0:      	str	w14, [sp, #0x68]
    c0a4:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    c0a8:      	cmp	x12, #0xfff
    c0ac:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    c0b0:      	cmp	w23, w21
    c0b4:      	b.ls	0xc0c0 <generic_rawtp_path+0x1dd0>
    c0b8:      	mov	w13, #0x2f              // =47
    c0bc:      	strb	w13, [x8, x12]
    c0c0:      	add	x19, x8, x12
    c0c4:      	cmp	w23, w21
    c0c8:      	add	x2, x9, x10
    c0cc:      	and	w1, w11, #0xff
    c0d0:      	mov	w8, #0x4                // =4
    c0d4:      	cinc	x0, x19, hi
    c0d8:      	blr	x8
    c0dc:      	cmp	w23, w21
    c0e0:      	str	x19, [sp, #0x60]
    c0e4:      	add	x19, sp, #0x70
    c0e8:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    c0ec:      	ldr	x21, [sp, #0x78]
    c0f0:      	ldp	x2, x24, [sp, #0x50]
    c0f4:      	str	x21, [sp, #0x48]
    c0f8:      	b	0xc148 <generic_rawtp_path+0x1e58>
    c0fc:      	add	x2, x24, #0x10
    c100:      	mov	w8, #0x4                // =4
    c104:      	add	x9, sp, #0x98
    c108:      	add	x0, sp, #0x98
    c10c:      	mov	w1, #0x8                // =8
    c110:      	blr	x8
    c114:      	ldr	x8, [sp, #0x58]
    c118:      	ldr	x9, [sp, #0x98]
    c11c:      	cmp	x8, x9
    c120:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    c124:      	add	x2, x24, #0x18
    c128:      	mov	w8, #0x4                // =4
    c12c:      	mov	x0, x22
    c130:      	mov	w1, #0x8                // =8
    c134:      	blr	x8
    c138:      	ldr	x24, [sp, #0x98]
    c13c:      	ldr	x21, [sp, #0x48]
    c140:      	add	x2, x24, #0x20
    c144:      	stp	x2, x24, [sp, #0x50]
    c148:      	ldr	x8, [sp, #0x30]
    c14c:      	cmp	x21, x8
    c150:      	b.ne	0xc160 <generic_rawtp_path+0x1e70>
    c154:      	ldr	x8, [sp, #0x38]
    c158:      	cmp	x2, x8
    c15c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    c160:      	mov	w8, #0x4                // =4
    c164:      	add	x0, sp, #0x70
    c168:      	mov	w1, #0x8                // =8
    c16c:      	blr	x8
    c170:      	ldr	x8, [sp, #0x70]
    c174:      	cmp	x21, x8
    c178:      	b.eq	0xc268 <generic_rawtp_path+0x1f78>
    c17c:      	add	x23, x21, #0x18
    c180:      	mov	w8, #0x4                // =4
    c184:      	add	x9, sp, #0x98
    c188:      	add	x0, sp, #0x98
    c18c:      	mov	w1, #0x8                // =8
    c190:      	mov	x2, x23
    c194:      	blr	x8
    c198:      	ldr	x8, [sp, #0x98]
    c19c:      	cmp	x8, x21
    c1a0:      	b.eq	0xc268 <generic_rawtp_path+0x1f78>
    c1a4:      	mov	w8, #0x4                // =4
    c1a8:      	add	x9, sp, #0x78
    c1ac:      	add	x0, sp, #0x78
    c1b0:      	mov	w1, #0x8                // =8
    c1b4:      	mov	x2, x23
    c1b8:      	blr	x8
    c1bc:      	add	x2, x21, #0x20
    c1c0:      	mov	w8, #0x4                // =4
    c1c4:      	mov	w9, #0x10               // =16
    c1c8:      	add	x10, sp, #0x80
    c1cc:      	add	x0, sp, #0x80
    c1d0:      	mov	w1, #0x10               // =16
    c1d4:      	blr	x8
    c1d8:      	ldr	w21, [sp, #0x84]
    c1dc:      	ldr	x8, [sp, #0x40]
    c1e0:      	ldr	x10, [sp, #0x60]
    c1e4:      	sub	x12, x10, x8
    c1e8:      	ldr	w23, [sp, #0x68]
    c1ec:      	subs	w10, w21, w23
    c1f0:      	ldr	x9, [sp, #0x88]
    c1f4:      	csel	w10, wzr, w10, lo
    c1f8:      	cmp	w23, w21
    c1fc:      	csel	w11, w23, w21, lo
    c200:      	cinc	w13, w11, hi
    c204:      	sub	w14, w23, w13
    c208:      	subs	x12, x12, x13
    c20c:      	str	w14, [sp, #0x68]
    c210:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    c214:      	cmp	x12, #0xfff
    c218:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    c21c:      	cmp	w23, w21
    c220:      	b.ls	0xc22c <generic_rawtp_path+0x1f3c>
    c224:      	mov	w13, #0x2f              // =47
    c228:      	strb	w13, [x8, x12]
    c22c:      	add	x19, x8, x12
    c230:      	cmp	w23, w21
    c234:      	add	x2, x9, x10
    c238:      	and	w1, w11, #0xff
    c23c:      	mov	w8, #0x4                // =4
    c240:      	cinc	x0, x19, hi
    c244:      	blr	x8
    c248:      	cmp	w23, w21
    c24c:      	str	x19, [sp, #0x60]
    c250:      	add	x19, sp, #0x70
    c254:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    c258:      	ldr	x21, [sp, #0x78]
    c25c:      	ldp	x2, x24, [sp, #0x50]
    c260:      	str	x21, [sp, #0x48]
    c264:      	b	0xc2b4 <generic_rawtp_path+0x1fc4>
    c268:      	add	x2, x24, #0x10
    c26c:      	mov	w8, #0x4                // =4
    c270:      	add	x9, sp, #0x98
    c274:      	add	x0, sp, #0x98
    c278:      	mov	w1, #0x8                // =8
    c27c:      	blr	x8
    c280:      	ldr	x8, [sp, #0x58]
    c284:      	ldr	x9, [sp, #0x98]
    c288:      	cmp	x8, x9
    c28c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    c290:      	add	x2, x24, #0x18
    c294:      	mov	w8, #0x4                // =4
    c298:      	mov	x0, x22
    c29c:      	mov	w1, #0x8                // =8
    c2a0:      	blr	x8
    c2a4:      	ldr	x24, [sp, #0x98]
    c2a8:      	ldr	x21, [sp, #0x48]
    c2ac:      	add	x2, x24, #0x20
    c2b0:      	stp	x2, x24, [sp, #0x50]
    c2b4:      	ldr	x8, [sp, #0x30]
    c2b8:      	cmp	x21, x8
    c2bc:      	b.ne	0xc2cc <generic_rawtp_path+0x1fdc>
    c2c0:      	ldr	x8, [sp, #0x38]
    c2c4:      	cmp	x2, x8
    c2c8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    c2cc:      	mov	w8, #0x4                // =4
    c2d0:      	add	x0, sp, #0x70
    c2d4:      	mov	w1, #0x8                // =8
    c2d8:      	blr	x8
    c2dc:      	ldr	x8, [sp, #0x70]
    c2e0:      	cmp	x21, x8
    c2e4:      	b.eq	0xc3d4 <generic_rawtp_path+0x20e4>
    c2e8:      	add	x23, x21, #0x18
    c2ec:      	mov	w8, #0x4                // =4
    c2f0:      	add	x9, sp, #0x98
    c2f4:      	add	x0, sp, #0x98
    c2f8:      	mov	w1, #0x8                // =8
    c2fc:      	mov	x2, x23
    c300:      	blr	x8
    c304:      	ldr	x8, [sp, #0x98]
    c308:      	cmp	x8, x21
    c30c:      	b.eq	0xc3d4 <generic_rawtp_path+0x20e4>
    c310:      	mov	w8, #0x4                // =4
    c314:      	add	x9, sp, #0x78
    c318:      	add	x0, sp, #0x78
    c31c:      	mov	w1, #0x8                // =8
    c320:      	mov	x2, x23
    c324:      	blr	x8
    c328:      	add	x2, x21, #0x20
    c32c:      	mov	w8, #0x4                // =4
    c330:      	mov	w9, #0x10               // =16
    c334:      	add	x10, sp, #0x80
    c338:      	add	x0, sp, #0x80
    c33c:      	mov	w1, #0x10               // =16
    c340:      	blr	x8
    c344:      	ldr	w21, [sp, #0x84]
    c348:      	ldr	x8, [sp, #0x40]
    c34c:      	ldr	x10, [sp, #0x60]
    c350:      	sub	x12, x10, x8
    c354:      	ldr	w23, [sp, #0x68]
    c358:      	subs	w10, w21, w23
    c35c:      	ldr	x9, [sp, #0x88]
    c360:      	csel	w10, wzr, w10, lo
    c364:      	cmp	w23, w21
    c368:      	csel	w11, w23, w21, lo
    c36c:      	cinc	w13, w11, hi
    c370:      	sub	w14, w23, w13
    c374:      	subs	x12, x12, x13
    c378:      	str	w14, [sp, #0x68]
    c37c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    c380:      	cmp	x12, #0xfff
    c384:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    c388:      	cmp	w23, w21
    c38c:      	b.ls	0xc398 <generic_rawtp_path+0x20a8>
    c390:      	mov	w13, #0x2f              // =47
    c394:      	strb	w13, [x8, x12]
    c398:      	add	x19, x8, x12
    c39c:      	cmp	w23, w21
    c3a0:      	add	x2, x9, x10
    c3a4:      	and	w1, w11, #0xff
    c3a8:      	mov	w8, #0x4                // =4
    c3ac:      	cinc	x0, x19, hi
    c3b0:      	blr	x8
    c3b4:      	cmp	w23, w21
    c3b8:      	str	x19, [sp, #0x60]
    c3bc:      	add	x19, sp, #0x70
    c3c0:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    c3c4:      	ldr	x21, [sp, #0x78]
    c3c8:      	ldp	x2, x24, [sp, #0x50]
    c3cc:      	str	x21, [sp, #0x48]
    c3d0:      	b	0xc420 <generic_rawtp_path+0x2130>
    c3d4:      	add	x2, x24, #0x10
    c3d8:      	mov	w8, #0x4                // =4
    c3dc:      	add	x9, sp, #0x98
    c3e0:      	add	x0, sp, #0x98
    c3e4:      	mov	w1, #0x8                // =8
    c3e8:      	blr	x8
    c3ec:      	ldr	x8, [sp, #0x58]
    c3f0:      	ldr	x9, [sp, #0x98]
    c3f4:      	cmp	x8, x9
    c3f8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    c3fc:      	add	x2, x24, #0x18
    c400:      	mov	w8, #0x4                // =4
    c404:      	mov	x0, x22
    c408:      	mov	w1, #0x8                // =8
    c40c:      	blr	x8
    c410:      	ldr	x24, [sp, #0x98]
    c414:      	ldr	x21, [sp, #0x48]
    c418:      	add	x2, x24, #0x20
    c41c:      	stp	x2, x24, [sp, #0x50]
    c420:      	ldr	x8, [sp, #0x30]
    c424:      	cmp	x21, x8
    c428:      	b.ne	0xc438 <generic_rawtp_path+0x2148>
    c42c:      	ldr	x8, [sp, #0x38]
    c430:      	cmp	x2, x8
    c434:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    c438:      	mov	w8, #0x4                // =4
    c43c:      	add	x0, sp, #0x70
    c440:      	mov	w1, #0x8                // =8
    c444:      	blr	x8
    c448:      	ldr	x8, [sp, #0x70]
    c44c:      	cmp	x21, x8
    c450:      	b.eq	0xc540 <generic_rawtp_path+0x2250>
    c454:      	add	x23, x21, #0x18
    c458:      	mov	w8, #0x4                // =4
    c45c:      	add	x9, sp, #0x98
    c460:      	add	x0, sp, #0x98
    c464:      	mov	w1, #0x8                // =8
    c468:      	mov	x2, x23
    c46c:      	blr	x8
    c470:      	ldr	x8, [sp, #0x98]
    c474:      	cmp	x8, x21
    c478:      	b.eq	0xc540 <generic_rawtp_path+0x2250>
    c47c:      	mov	w8, #0x4                // =4
    c480:      	add	x9, sp, #0x78
    c484:      	add	x0, sp, #0x78
    c488:      	mov	w1, #0x8                // =8
    c48c:      	mov	x2, x23
    c490:      	blr	x8
    c494:      	add	x2, x21, #0x20
    c498:      	mov	w8, #0x4                // =4
    c49c:      	mov	w9, #0x10               // =16
    c4a0:      	add	x10, sp, #0x80
    c4a4:      	add	x0, sp, #0x80
    c4a8:      	mov	w1, #0x10               // =16
    c4ac:      	blr	x8
    c4b0:      	ldr	w21, [sp, #0x84]
    c4b4:      	ldr	x8, [sp, #0x40]
    c4b8:      	ldr	x10, [sp, #0x60]
    c4bc:      	sub	x12, x10, x8
    c4c0:      	ldr	w23, [sp, #0x68]
    c4c4:      	subs	w10, w21, w23
    c4c8:      	ldr	x9, [sp, #0x88]
    c4cc:      	csel	w10, wzr, w10, lo
    c4d0:      	cmp	w23, w21
    c4d4:      	csel	w11, w23, w21, lo
    c4d8:      	cinc	w13, w11, hi
    c4dc:      	sub	w14, w23, w13
    c4e0:      	subs	x12, x12, x13
    c4e4:      	str	w14, [sp, #0x68]
    c4e8:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    c4ec:      	cmp	x12, #0xfff
    c4f0:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    c4f4:      	cmp	w23, w21
    c4f8:      	b.ls	0xc504 <generic_rawtp_path+0x2214>
    c4fc:      	mov	w13, #0x2f              // =47
    c500:      	strb	w13, [x8, x12]
    c504:      	add	x19, x8, x12
    c508:      	cmp	w23, w21
    c50c:      	add	x2, x9, x10
    c510:      	and	w1, w11, #0xff
    c514:      	mov	w8, #0x4                // =4
    c518:      	cinc	x0, x19, hi
    c51c:      	blr	x8
    c520:      	cmp	w23, w21
    c524:      	str	x19, [sp, #0x60]
    c528:      	add	x19, sp, #0x70
    c52c:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    c530:      	ldr	x21, [sp, #0x78]
    c534:      	ldp	x2, x24, [sp, #0x50]
    c538:      	str	x21, [sp, #0x48]
    c53c:      	b	0xc58c <generic_rawtp_path+0x229c>
    c540:      	add	x2, x24, #0x10
    c544:      	mov	w8, #0x4                // =4
    c548:      	add	x9, sp, #0x98
    c54c:      	add	x0, sp, #0x98
    c550:      	mov	w1, #0x8                // =8
    c554:      	blr	x8
    c558:      	ldr	x8, [sp, #0x58]
    c55c:      	ldr	x9, [sp, #0x98]
    c560:      	cmp	x8, x9
    c564:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    c568:      	add	x2, x24, #0x18
    c56c:      	mov	w8, #0x4                // =4
    c570:      	mov	x0, x22
    c574:      	mov	w1, #0x8                // =8
    c578:      	blr	x8
    c57c:      	ldr	x24, [sp, #0x98]
    c580:      	ldr	x21, [sp, #0x48]
    c584:      	add	x2, x24, #0x20
    c588:      	stp	x2, x24, [sp, #0x50]
    c58c:      	ldr	x8, [sp, #0x30]
    c590:      	cmp	x21, x8
    c594:      	b.ne	0xc5a4 <generic_rawtp_path+0x22b4>
    c598:      	ldr	x8, [sp, #0x38]
    c59c:      	cmp	x2, x8
    c5a0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    c5a4:      	mov	w8, #0x4                // =4
    c5a8:      	add	x0, sp, #0x70
    c5ac:      	mov	w1, #0x8                // =8
    c5b0:      	blr	x8
    c5b4:      	ldr	x8, [sp, #0x70]
    c5b8:      	cmp	x21, x8
    c5bc:      	b.eq	0xc6ac <generic_rawtp_path+0x23bc>
    c5c0:      	add	x23, x21, #0x18
    c5c4:      	mov	w8, #0x4                // =4
    c5c8:      	add	x9, sp, #0x98
    c5cc:      	add	x0, sp, #0x98
    c5d0:      	mov	w1, #0x8                // =8
    c5d4:      	mov	x2, x23
    c5d8:      	blr	x8
    c5dc:      	ldr	x8, [sp, #0x98]
    c5e0:      	cmp	x8, x21
    c5e4:      	b.eq	0xc6ac <generic_rawtp_path+0x23bc>
    c5e8:      	mov	w8, #0x4                // =4
    c5ec:      	add	x9, sp, #0x78
    c5f0:      	add	x0, sp, #0x78
    c5f4:      	mov	w1, #0x8                // =8
    c5f8:      	mov	x2, x23
    c5fc:      	blr	x8
    c600:      	add	x2, x21, #0x20
    c604:      	mov	w8, #0x4                // =4
    c608:      	mov	w9, #0x10               // =16
    c60c:      	add	x10, sp, #0x80
    c610:      	add	x0, sp, #0x80
    c614:      	mov	w1, #0x10               // =16
    c618:      	blr	x8
    c61c:      	ldr	w21, [sp, #0x84]
    c620:      	ldr	x8, [sp, #0x40]
    c624:      	ldr	x10, [sp, #0x60]
    c628:      	sub	x12, x10, x8
    c62c:      	ldr	w23, [sp, #0x68]
    c630:      	subs	w10, w21, w23
    c634:      	ldr	x9, [sp, #0x88]
    c638:      	csel	w10, wzr, w10, lo
    c63c:      	cmp	w23, w21
    c640:      	csel	w11, w23, w21, lo
    c644:      	cinc	w13, w11, hi
    c648:      	sub	w14, w23, w13
    c64c:      	subs	x12, x12, x13
    c650:      	str	w14, [sp, #0x68]
    c654:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    c658:      	cmp	x12, #0xfff
    c65c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    c660:      	cmp	w23, w21
    c664:      	b.ls	0xc670 <generic_rawtp_path+0x2380>
    c668:      	mov	w13, #0x2f              // =47
    c66c:      	strb	w13, [x8, x12]
    c670:      	add	x19, x8, x12
    c674:      	cmp	w23, w21
    c678:      	add	x2, x9, x10
    c67c:      	and	w1, w11, #0xff
    c680:      	mov	w8, #0x4                // =4
    c684:      	cinc	x0, x19, hi
    c688:      	blr	x8
    c68c:      	cmp	w23, w21
    c690:      	str	x19, [sp, #0x60]
    c694:      	add	x19, sp, #0x70
    c698:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    c69c:      	ldr	x21, [sp, #0x78]
    c6a0:      	ldp	x2, x24, [sp, #0x50]
    c6a4:      	str	x21, [sp, #0x48]
    c6a8:      	b	0xc6f8 <generic_rawtp_path+0x2408>
    c6ac:      	add	x2, x24, #0x10
    c6b0:      	mov	w8, #0x4                // =4
    c6b4:      	add	x9, sp, #0x98
    c6b8:      	add	x0, sp, #0x98
    c6bc:      	mov	w1, #0x8                // =8
    c6c0:      	blr	x8
    c6c4:      	ldr	x8, [sp, #0x58]
    c6c8:      	ldr	x9, [sp, #0x98]
    c6cc:      	cmp	x8, x9
    c6d0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    c6d4:      	add	x2, x24, #0x18
    c6d8:      	mov	w8, #0x4                // =4
    c6dc:      	mov	x0, x22
    c6e0:      	mov	w1, #0x8                // =8
    c6e4:      	blr	x8
    c6e8:      	ldr	x24, [sp, #0x98]
    c6ec:      	ldr	x21, [sp, #0x48]
    c6f0:      	add	x2, x24, #0x20
    c6f4:      	stp	x2, x24, [sp, #0x50]
    c6f8:      	ldr	x8, [sp, #0x30]
    c6fc:      	cmp	x21, x8
    c700:      	b.ne	0xc710 <generic_rawtp_path+0x2420>
    c704:      	ldr	x8, [sp, #0x38]
    c708:      	cmp	x2, x8
    c70c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    c710:      	mov	w8, #0x4                // =4
    c714:      	add	x0, sp, #0x70
    c718:      	mov	w1, #0x8                // =8
    c71c:      	blr	x8
    c720:      	ldr	x8, [sp, #0x70]
    c724:      	cmp	x21, x8
    c728:      	b.eq	0xc818 <generic_rawtp_path+0x2528>
    c72c:      	add	x23, x21, #0x18
    c730:      	mov	w8, #0x4                // =4
    c734:      	add	x9, sp, #0x98
    c738:      	add	x0, sp, #0x98
    c73c:      	mov	w1, #0x8                // =8
    c740:      	mov	x2, x23
    c744:      	blr	x8
    c748:      	ldr	x8, [sp, #0x98]
    c74c:      	cmp	x8, x21
    c750:      	b.eq	0xc818 <generic_rawtp_path+0x2528>
    c754:      	mov	w8, #0x4                // =4
    c758:      	add	x9, sp, #0x78
    c75c:      	add	x0, sp, #0x78
    c760:      	mov	w1, #0x8                // =8
    c764:      	mov	x2, x23
    c768:      	blr	x8
    c76c:      	add	x2, x21, #0x20
    c770:      	mov	w8, #0x4                // =4
    c774:      	mov	w9, #0x10               // =16
    c778:      	add	x10, sp, #0x80
    c77c:      	add	x0, sp, #0x80
    c780:      	mov	w1, #0x10               // =16
    c784:      	blr	x8
    c788:      	ldr	w21, [sp, #0x84]
    c78c:      	ldr	x8, [sp, #0x40]
    c790:      	ldr	x10, [sp, #0x60]
    c794:      	sub	x12, x10, x8
    c798:      	ldr	w23, [sp, #0x68]
    c79c:      	subs	w10, w21, w23
    c7a0:      	ldr	x9, [sp, #0x88]
    c7a4:      	csel	w10, wzr, w10, lo
    c7a8:      	cmp	w23, w21
    c7ac:      	csel	w11, w23, w21, lo
    c7b0:      	cinc	w13, w11, hi
    c7b4:      	sub	w14, w23, w13
    c7b8:      	subs	x12, x12, x13
    c7bc:      	str	w14, [sp, #0x68]
    c7c0:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    c7c4:      	cmp	x12, #0xfff
    c7c8:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    c7cc:      	cmp	w23, w21
    c7d0:      	b.ls	0xc7dc <generic_rawtp_path+0x24ec>
    c7d4:      	mov	w13, #0x2f              // =47
    c7d8:      	strb	w13, [x8, x12]
    c7dc:      	add	x19, x8, x12
    c7e0:      	cmp	w23, w21
    c7e4:      	add	x2, x9, x10
    c7e8:      	and	w1, w11, #0xff
    c7ec:      	mov	w8, #0x4                // =4
    c7f0:      	cinc	x0, x19, hi
    c7f4:      	blr	x8
    c7f8:      	cmp	w23, w21
    c7fc:      	str	x19, [sp, #0x60]
    c800:      	add	x19, sp, #0x70
    c804:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    c808:      	ldr	x21, [sp, #0x78]
    c80c:      	ldp	x2, x24, [sp, #0x50]
    c810:      	str	x21, [sp, #0x48]
    c814:      	b	0xc864 <generic_rawtp_path+0x2574>
    c818:      	add	x2, x24, #0x10
    c81c:      	mov	w8, #0x4                // =4
    c820:      	add	x9, sp, #0x98
    c824:      	add	x0, sp, #0x98
    c828:      	mov	w1, #0x8                // =8
    c82c:      	blr	x8
    c830:      	ldr	x8, [sp, #0x58]
    c834:      	ldr	x9, [sp, #0x98]
    c838:      	cmp	x8, x9
    c83c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    c840:      	add	x2, x24, #0x18
    c844:      	mov	w8, #0x4                // =4
    c848:      	mov	x0, x22
    c84c:      	mov	w1, #0x8                // =8
    c850:      	blr	x8
    c854:      	ldr	x24, [sp, #0x98]
    c858:      	ldr	x21, [sp, #0x48]
    c85c:      	add	x2, x24, #0x20
    c860:      	stp	x2, x24, [sp, #0x50]
    c864:      	ldr	x8, [sp, #0x30]
    c868:      	cmp	x21, x8
    c86c:      	b.ne	0xc87c <generic_rawtp_path+0x258c>
    c870:      	ldr	x8, [sp, #0x38]
    c874:      	cmp	x2, x8
    c878:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    c87c:      	mov	w8, #0x4                // =4
    c880:      	add	x0, sp, #0x70
    c884:      	mov	w1, #0x8                // =8
    c888:      	blr	x8
    c88c:      	ldr	x8, [sp, #0x70]
    c890:      	cmp	x21, x8
    c894:      	b.eq	0xc984 <generic_rawtp_path+0x2694>
    c898:      	add	x23, x21, #0x18
    c89c:      	mov	w8, #0x4                // =4
    c8a0:      	add	x9, sp, #0x98
    c8a4:      	add	x0, sp, #0x98
    c8a8:      	mov	w1, #0x8                // =8
    c8ac:      	mov	x2, x23
    c8b0:      	blr	x8
    c8b4:      	ldr	x8, [sp, #0x98]
    c8b8:      	cmp	x8, x21
    c8bc:      	b.eq	0xc984 <generic_rawtp_path+0x2694>
    c8c0:      	mov	w8, #0x4                // =4
    c8c4:      	add	x9, sp, #0x78
    c8c8:      	add	x0, sp, #0x78
    c8cc:      	mov	w1, #0x8                // =8
    c8d0:      	mov	x2, x23
    c8d4:      	blr	x8
    c8d8:      	add	x2, x21, #0x20
    c8dc:      	mov	w8, #0x4                // =4
    c8e0:      	mov	w9, #0x10               // =16
    c8e4:      	add	x10, sp, #0x80
    c8e8:      	add	x0, sp, #0x80
    c8ec:      	mov	w1, #0x10               // =16
    c8f0:      	blr	x8
    c8f4:      	ldr	w21, [sp, #0x84]
    c8f8:      	ldr	x8, [sp, #0x40]
    c8fc:      	ldr	x10, [sp, #0x60]
    c900:      	sub	x12, x10, x8
    c904:      	ldr	w23, [sp, #0x68]
    c908:      	subs	w10, w21, w23
    c90c:      	ldr	x9, [sp, #0x88]
    c910:      	csel	w10, wzr, w10, lo
    c914:      	cmp	w23, w21
    c918:      	csel	w11, w23, w21, lo
    c91c:      	cinc	w13, w11, hi
    c920:      	sub	w14, w23, w13
    c924:      	subs	x12, x12, x13
    c928:      	str	w14, [sp, #0x68]
    c92c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    c930:      	cmp	x12, #0xfff
    c934:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    c938:      	cmp	w23, w21
    c93c:      	b.ls	0xc948 <generic_rawtp_path+0x2658>
    c940:      	mov	w13, #0x2f              // =47
    c944:      	strb	w13, [x8, x12]
    c948:      	add	x19, x8, x12
    c94c:      	cmp	w23, w21
    c950:      	add	x2, x9, x10
    c954:      	and	w1, w11, #0xff
    c958:      	mov	w8, #0x4                // =4
    c95c:      	cinc	x0, x19, hi
    c960:      	blr	x8
    c964:      	cmp	w23, w21
    c968:      	str	x19, [sp, #0x60]
    c96c:      	add	x19, sp, #0x70
    c970:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    c974:      	ldr	x21, [sp, #0x78]
    c978:      	ldp	x2, x24, [sp, #0x50]
    c97c:      	str	x21, [sp, #0x48]
    c980:      	b	0xc9d0 <generic_rawtp_path+0x26e0>
    c984:      	add	x2, x24, #0x10
    c988:      	mov	w8, #0x4                // =4
    c98c:      	add	x9, sp, #0x98
    c990:      	add	x0, sp, #0x98
    c994:      	mov	w1, #0x8                // =8
    c998:      	blr	x8
    c99c:      	ldr	x8, [sp, #0x58]
    c9a0:      	ldr	x9, [sp, #0x98]
    c9a4:      	cmp	x8, x9
    c9a8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    c9ac:      	add	x2, x24, #0x18
    c9b0:      	mov	w8, #0x4                // =4
    c9b4:      	mov	x0, x22
    c9b8:      	mov	w1, #0x8                // =8
    c9bc:      	blr	x8
    c9c0:      	ldr	x24, [sp, #0x98]
    c9c4:      	ldr	x21, [sp, #0x48]
    c9c8:      	add	x2, x24, #0x20
    c9cc:      	stp	x2, x24, [sp, #0x50]
    c9d0:      	ldr	x8, [sp, #0x30]
    c9d4:      	cmp	x21, x8
    c9d8:      	b.ne	0xc9e8 <generic_rawtp_path+0x26f8>
    c9dc:      	ldr	x8, [sp, #0x38]
    c9e0:      	cmp	x2, x8
    c9e4:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    c9e8:      	mov	w8, #0x4                // =4
    c9ec:      	add	x0, sp, #0x70
    c9f0:      	mov	w1, #0x8                // =8
    c9f4:      	blr	x8
    c9f8:      	ldr	x8, [sp, #0x70]
    c9fc:      	cmp	x21, x8
    ca00:      	b.eq	0xcaf0 <generic_rawtp_path+0x2800>
    ca04:      	add	x23, x21, #0x18
    ca08:      	mov	w8, #0x4                // =4
    ca0c:      	add	x9, sp, #0x98
    ca10:      	add	x0, sp, #0x98
    ca14:      	mov	w1, #0x8                // =8
    ca18:      	mov	x2, x23
    ca1c:      	blr	x8
    ca20:      	ldr	x8, [sp, #0x98]
    ca24:      	cmp	x8, x21
    ca28:      	b.eq	0xcaf0 <generic_rawtp_path+0x2800>
    ca2c:      	mov	w8, #0x4                // =4
    ca30:      	add	x9, sp, #0x78
    ca34:      	add	x0, sp, #0x78
    ca38:      	mov	w1, #0x8                // =8
    ca3c:      	mov	x2, x23
    ca40:      	blr	x8
    ca44:      	add	x2, x21, #0x20
    ca48:      	mov	w8, #0x4                // =4
    ca4c:      	mov	w9, #0x10               // =16
    ca50:      	add	x10, sp, #0x80
    ca54:      	add	x0, sp, #0x80
    ca58:      	mov	w1, #0x10               // =16
    ca5c:      	blr	x8
    ca60:      	ldr	w21, [sp, #0x84]
    ca64:      	ldr	x8, [sp, #0x40]
    ca68:      	ldr	x10, [sp, #0x60]
    ca6c:      	sub	x12, x10, x8
    ca70:      	ldr	w23, [sp, #0x68]
    ca74:      	subs	w10, w21, w23
    ca78:      	ldr	x9, [sp, #0x88]
    ca7c:      	csel	w10, wzr, w10, lo
    ca80:      	cmp	w23, w21
    ca84:      	csel	w11, w23, w21, lo
    ca88:      	cinc	w13, w11, hi
    ca8c:      	sub	w14, w23, w13
    ca90:      	subs	x12, x12, x13
    ca94:      	str	w14, [sp, #0x68]
    ca98:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    ca9c:      	cmp	x12, #0xfff
    caa0:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    caa4:      	cmp	w23, w21
    caa8:      	b.ls	0xcab4 <generic_rawtp_path+0x27c4>
    caac:      	mov	w13, #0x2f              // =47
    cab0:      	strb	w13, [x8, x12]
    cab4:      	add	x19, x8, x12
    cab8:      	cmp	w23, w21
    cabc:      	add	x2, x9, x10
    cac0:      	and	w1, w11, #0xff
    cac4:      	mov	w8, #0x4                // =4
    cac8:      	cinc	x0, x19, hi
    cacc:      	blr	x8
    cad0:      	cmp	w23, w21
    cad4:      	str	x19, [sp, #0x60]
    cad8:      	add	x19, sp, #0x70
    cadc:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    cae0:      	ldr	x21, [sp, #0x78]
    cae4:      	ldp	x2, x24, [sp, #0x50]
    cae8:      	str	x21, [sp, #0x48]
    caec:      	b	0xcb3c <generic_rawtp_path+0x284c>
    caf0:      	add	x2, x24, #0x10
    caf4:      	mov	w8, #0x4                // =4
    caf8:      	add	x9, sp, #0x98
    cafc:      	add	x0, sp, #0x98
    cb00:      	mov	w1, #0x8                // =8
    cb04:      	blr	x8
    cb08:      	ldr	x8, [sp, #0x58]
    cb0c:      	ldr	x9, [sp, #0x98]
    cb10:      	cmp	x8, x9
    cb14:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    cb18:      	add	x2, x24, #0x18
    cb1c:      	mov	w8, #0x4                // =4
    cb20:      	mov	x0, x22
    cb24:      	mov	w1, #0x8                // =8
    cb28:      	blr	x8
    cb2c:      	ldr	x24, [sp, #0x98]
    cb30:      	ldr	x21, [sp, #0x48]
    cb34:      	add	x2, x24, #0x20
    cb38:      	stp	x2, x24, [sp, #0x50]
    cb3c:      	ldr	x8, [sp, #0x30]
    cb40:      	cmp	x21, x8
    cb44:      	b.ne	0xcb54 <generic_rawtp_path+0x2864>
    cb48:      	ldr	x8, [sp, #0x38]
    cb4c:      	cmp	x2, x8
    cb50:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    cb54:      	mov	w8, #0x4                // =4
    cb58:      	add	x0, sp, #0x70
    cb5c:      	mov	w1, #0x8                // =8
    cb60:      	blr	x8
    cb64:      	ldr	x8, [sp, #0x70]
    cb68:      	cmp	x21, x8
    cb6c:      	b.eq	0xcc5c <generic_rawtp_path+0x296c>
    cb70:      	add	x23, x21, #0x18
    cb74:      	mov	w8, #0x4                // =4
    cb78:      	add	x9, sp, #0x98
    cb7c:      	add	x0, sp, #0x98
    cb80:      	mov	w1, #0x8                // =8
    cb84:      	mov	x2, x23
    cb88:      	blr	x8
    cb8c:      	ldr	x8, [sp, #0x98]
    cb90:      	cmp	x8, x21
    cb94:      	b.eq	0xcc5c <generic_rawtp_path+0x296c>
    cb98:      	mov	w8, #0x4                // =4
    cb9c:      	add	x9, sp, #0x78
    cba0:      	add	x0, sp, #0x78
    cba4:      	mov	w1, #0x8                // =8
    cba8:      	mov	x2, x23
    cbac:      	blr	x8
    cbb0:      	add	x2, x21, #0x20
    cbb4:      	mov	w8, #0x4                // =4
    cbb8:      	mov	w9, #0x10               // =16
    cbbc:      	add	x10, sp, #0x80
    cbc0:      	add	x0, sp, #0x80
    cbc4:      	mov	w1, #0x10               // =16
    cbc8:      	blr	x8
    cbcc:      	ldr	w21, [sp, #0x84]
    cbd0:      	ldr	x8, [sp, #0x40]
    cbd4:      	ldr	x10, [sp, #0x60]
    cbd8:      	sub	x12, x10, x8
    cbdc:      	ldr	w23, [sp, #0x68]
    cbe0:      	subs	w10, w21, w23
    cbe4:      	ldr	x9, [sp, #0x88]
    cbe8:      	csel	w10, wzr, w10, lo
    cbec:      	cmp	w23, w21
    cbf0:      	csel	w11, w23, w21, lo
    cbf4:      	cinc	w13, w11, hi
    cbf8:      	sub	w14, w23, w13
    cbfc:      	subs	x12, x12, x13
    cc00:      	str	w14, [sp, #0x68]
    cc04:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    cc08:      	cmp	x12, #0xfff
    cc0c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    cc10:      	cmp	w23, w21
    cc14:      	b.ls	0xcc20 <generic_rawtp_path+0x2930>
    cc18:      	mov	w13, #0x2f              // =47
    cc1c:      	strb	w13, [x8, x12]
    cc20:      	add	x19, x8, x12
    cc24:      	cmp	w23, w21
    cc28:      	add	x2, x9, x10
    cc2c:      	and	w1, w11, #0xff
    cc30:      	mov	w8, #0x4                // =4
    cc34:      	cinc	x0, x19, hi
    cc38:      	blr	x8
    cc3c:      	cmp	w23, w21
    cc40:      	str	x19, [sp, #0x60]
    cc44:      	add	x19, sp, #0x70
    cc48:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    cc4c:      	ldr	x21, [sp, #0x78]
    cc50:      	ldp	x2, x24, [sp, #0x50]
    cc54:      	str	x21, [sp, #0x48]
    cc58:      	b	0xcca8 <generic_rawtp_path+0x29b8>
    cc5c:      	add	x2, x24, #0x10
    cc60:      	mov	w8, #0x4                // =4
    cc64:      	add	x9, sp, #0x98
    cc68:      	add	x0, sp, #0x98
    cc6c:      	mov	w1, #0x8                // =8
    cc70:      	blr	x8
    cc74:      	ldr	x8, [sp, #0x58]
    cc78:      	ldr	x9, [sp, #0x98]
    cc7c:      	cmp	x8, x9
    cc80:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    cc84:      	add	x2, x24, #0x18
    cc88:      	mov	w8, #0x4                // =4
    cc8c:      	mov	x0, x22
    cc90:      	mov	w1, #0x8                // =8
    cc94:      	blr	x8
    cc98:      	ldr	x24, [sp, #0x98]
    cc9c:      	ldr	x21, [sp, #0x48]
    cca0:      	add	x2, x24, #0x20
    cca4:      	stp	x2, x24, [sp, #0x50]
    cca8:      	ldr	x8, [sp, #0x30]
    ccac:      	cmp	x21, x8
    ccb0:      	b.ne	0xccc0 <generic_rawtp_path+0x29d0>
    ccb4:      	ldr	x8, [sp, #0x38]
    ccb8:      	cmp	x2, x8
    ccbc:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    ccc0:      	mov	w8, #0x4                // =4
    ccc4:      	add	x0, sp, #0x70
    ccc8:      	mov	w1, #0x8                // =8
    cccc:      	blr	x8
    ccd0:      	ldr	x8, [sp, #0x70]
    ccd4:      	cmp	x21, x8
    ccd8:      	b.eq	0xcdc8 <generic_rawtp_path+0x2ad8>
    ccdc:      	add	x23, x21, #0x18
    cce0:      	mov	w8, #0x4                // =4
    cce4:      	add	x9, sp, #0x98
    cce8:      	add	x0, sp, #0x98
    ccec:      	mov	w1, #0x8                // =8
    ccf0:      	mov	x2, x23
    ccf4:      	blr	x8
    ccf8:      	ldr	x8, [sp, #0x98]
    ccfc:      	cmp	x8, x21
    cd00:      	b.eq	0xcdc8 <generic_rawtp_path+0x2ad8>
    cd04:      	mov	w8, #0x4                // =4
    cd08:      	add	x9, sp, #0x78
    cd0c:      	add	x0, sp, #0x78
    cd10:      	mov	w1, #0x8                // =8
    cd14:      	mov	x2, x23
    cd18:      	blr	x8
    cd1c:      	add	x2, x21, #0x20
    cd20:      	mov	w8, #0x4                // =4
    cd24:      	mov	w9, #0x10               // =16
    cd28:      	add	x10, sp, #0x80
    cd2c:      	add	x0, sp, #0x80
    cd30:      	mov	w1, #0x10               // =16
    cd34:      	blr	x8
    cd38:      	ldr	w21, [sp, #0x84]
    cd3c:      	ldr	x8, [sp, #0x40]
    cd40:      	ldr	x10, [sp, #0x60]
    cd44:      	sub	x12, x10, x8
    cd48:      	ldr	w23, [sp, #0x68]
    cd4c:      	subs	w10, w21, w23
    cd50:      	ldr	x9, [sp, #0x88]
    cd54:      	csel	w10, wzr, w10, lo
    cd58:      	cmp	w23, w21
    cd5c:      	csel	w11, w23, w21, lo
    cd60:      	cinc	w13, w11, hi
    cd64:      	sub	w14, w23, w13
    cd68:      	subs	x12, x12, x13
    cd6c:      	str	w14, [sp, #0x68]
    cd70:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    cd74:      	cmp	x12, #0xfff
    cd78:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    cd7c:      	cmp	w23, w21
    cd80:      	b.ls	0xcd8c <generic_rawtp_path+0x2a9c>
    cd84:      	mov	w13, #0x2f              // =47
    cd88:      	strb	w13, [x8, x12]
    cd8c:      	add	x19, x8, x12
    cd90:      	cmp	w23, w21
    cd94:      	add	x2, x9, x10
    cd98:      	and	w1, w11, #0xff
    cd9c:      	mov	w8, #0x4                // =4
    cda0:      	cinc	x0, x19, hi
    cda4:      	blr	x8
    cda8:      	cmp	w23, w21
    cdac:      	str	x19, [sp, #0x60]
    cdb0:      	add	x19, sp, #0x70
    cdb4:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    cdb8:      	ldr	x21, [sp, #0x78]
    cdbc:      	ldp	x2, x24, [sp, #0x50]
    cdc0:      	str	x21, [sp, #0x48]
    cdc4:      	b	0xce14 <generic_rawtp_path+0x2b24>
    cdc8:      	add	x2, x24, #0x10
    cdcc:      	mov	w8, #0x4                // =4
    cdd0:      	add	x9, sp, #0x98
    cdd4:      	add	x0, sp, #0x98
    cdd8:      	mov	w1, #0x8                // =8
    cddc:      	blr	x8
    cde0:      	ldr	x8, [sp, #0x58]
    cde4:      	ldr	x9, [sp, #0x98]
    cde8:      	cmp	x8, x9
    cdec:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    cdf0:      	add	x2, x24, #0x18
    cdf4:      	mov	w8, #0x4                // =4
    cdf8:      	mov	x0, x22
    cdfc:      	mov	w1, #0x8                // =8
    ce00:      	blr	x8
    ce04:      	ldr	x24, [sp, #0x98]
    ce08:      	ldr	x21, [sp, #0x48]
    ce0c:      	add	x2, x24, #0x20
    ce10:      	stp	x2, x24, [sp, #0x50]
    ce14:      	ldr	x8, [sp, #0x30]
    ce18:      	cmp	x21, x8
    ce1c:      	b.ne	0xce2c <generic_rawtp_path+0x2b3c>
    ce20:      	ldr	x8, [sp, #0x38]
    ce24:      	cmp	x2, x8
    ce28:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    ce2c:      	mov	w8, #0x4                // =4
    ce30:      	add	x0, sp, #0x70
    ce34:      	mov	w1, #0x8                // =8
    ce38:      	blr	x8
    ce3c:      	ldr	x8, [sp, #0x70]
    ce40:      	cmp	x21, x8
    ce44:      	b.eq	0xcf34 <generic_rawtp_path+0x2c44>
    ce48:      	add	x23, x21, #0x18
    ce4c:      	mov	w8, #0x4                // =4
    ce50:      	add	x9, sp, #0x98
    ce54:      	add	x0, sp, #0x98
    ce58:      	mov	w1, #0x8                // =8
    ce5c:      	mov	x2, x23
    ce60:      	blr	x8
    ce64:      	ldr	x8, [sp, #0x98]
    ce68:      	cmp	x8, x21
    ce6c:      	b.eq	0xcf34 <generic_rawtp_path+0x2c44>
    ce70:      	mov	w8, #0x4                // =4
    ce74:      	add	x9, sp, #0x78
    ce78:      	add	x0, sp, #0x78
    ce7c:      	mov	w1, #0x8                // =8
    ce80:      	mov	x2, x23
    ce84:      	blr	x8
    ce88:      	add	x2, x21, #0x20
    ce8c:      	mov	w8, #0x4                // =4
    ce90:      	mov	w9, #0x10               // =16
    ce94:      	add	x10, sp, #0x80
    ce98:      	add	x0, sp, #0x80
    ce9c:      	mov	w1, #0x10               // =16
    cea0:      	blr	x8
    cea4:      	ldr	w21, [sp, #0x84]
    cea8:      	ldr	x8, [sp, #0x40]
    ceac:      	ldr	x10, [sp, #0x60]
    ceb0:      	sub	x12, x10, x8
    ceb4:      	ldr	w23, [sp, #0x68]
    ceb8:      	subs	w10, w21, w23
    cebc:      	ldr	x9, [sp, #0x88]
    cec0:      	csel	w10, wzr, w10, lo
    cec4:      	cmp	w23, w21
    cec8:      	csel	w11, w23, w21, lo
    cecc:      	cinc	w13, w11, hi
    ced0:      	sub	w14, w23, w13
    ced4:      	subs	x12, x12, x13
    ced8:      	str	w14, [sp, #0x68]
    cedc:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    cee0:      	cmp	x12, #0xfff
    cee4:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    cee8:      	cmp	w23, w21
    ceec:      	b.ls	0xcef8 <generic_rawtp_path+0x2c08>
    cef0:      	mov	w13, #0x2f              // =47
    cef4:      	strb	w13, [x8, x12]
    cef8:      	add	x19, x8, x12
    cefc:      	cmp	w23, w21
    cf00:      	add	x2, x9, x10
    cf04:      	and	w1, w11, #0xff
    cf08:      	mov	w8, #0x4                // =4
    cf0c:      	cinc	x0, x19, hi
    cf10:      	blr	x8
    cf14:      	cmp	w23, w21
    cf18:      	str	x19, [sp, #0x60]
    cf1c:      	add	x19, sp, #0x70
    cf20:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    cf24:      	ldr	x21, [sp, #0x78]
    cf28:      	ldp	x2, x24, [sp, #0x50]
    cf2c:      	str	x21, [sp, #0x48]
    cf30:      	b	0xcf80 <generic_rawtp_path+0x2c90>
    cf34:      	add	x2, x24, #0x10
    cf38:      	mov	w8, #0x4                // =4
    cf3c:      	add	x9, sp, #0x98
    cf40:      	add	x0, sp, #0x98
    cf44:      	mov	w1, #0x8                // =8
    cf48:      	blr	x8
    cf4c:      	ldr	x8, [sp, #0x58]
    cf50:      	ldr	x9, [sp, #0x98]
    cf54:      	cmp	x8, x9
    cf58:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    cf5c:      	add	x2, x24, #0x18
    cf60:      	mov	w8, #0x4                // =4
    cf64:      	mov	x0, x22
    cf68:      	mov	w1, #0x8                // =8
    cf6c:      	blr	x8
    cf70:      	ldr	x24, [sp, #0x98]
    cf74:      	ldr	x21, [sp, #0x48]
    cf78:      	add	x2, x24, #0x20
    cf7c:      	stp	x2, x24, [sp, #0x50]
    cf80:      	ldr	x8, [sp, #0x30]
    cf84:      	cmp	x21, x8
    cf88:      	b.ne	0xcf98 <generic_rawtp_path+0x2ca8>
    cf8c:      	ldr	x8, [sp, #0x38]
    cf90:      	cmp	x2, x8
    cf94:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    cf98:      	mov	w8, #0x4                // =4
    cf9c:      	add	x0, sp, #0x70
    cfa0:      	mov	w1, #0x8                // =8
    cfa4:      	blr	x8
    cfa8:      	ldr	x8, [sp, #0x70]
    cfac:      	cmp	x21, x8
    cfb0:      	b.eq	0xd0a0 <generic_rawtp_path+0x2db0>
    cfb4:      	add	x23, x21, #0x18
    cfb8:      	mov	w8, #0x4                // =4
    cfbc:      	add	x9, sp, #0x98
    cfc0:      	add	x0, sp, #0x98
    cfc4:      	mov	w1, #0x8                // =8
    cfc8:      	mov	x2, x23
    cfcc:      	blr	x8
    cfd0:      	ldr	x8, [sp, #0x98]
    cfd4:      	cmp	x8, x21
    cfd8:      	b.eq	0xd0a0 <generic_rawtp_path+0x2db0>
    cfdc:      	mov	w8, #0x4                // =4
    cfe0:      	add	x9, sp, #0x78
    cfe4:      	add	x0, sp, #0x78
    cfe8:      	mov	w1, #0x8                // =8
    cfec:      	mov	x2, x23
    cff0:      	blr	x8
    cff4:      	add	x2, x21, #0x20
    cff8:      	mov	w8, #0x4                // =4
    cffc:      	mov	w9, #0x10               // =16
    d000:      	add	x10, sp, #0x80
    d004:      	add	x0, sp, #0x80
    d008:      	mov	w1, #0x10               // =16
    d00c:      	blr	x8
    d010:      	ldr	w21, [sp, #0x84]
    d014:      	ldr	x8, [sp, #0x40]
    d018:      	ldr	x10, [sp, #0x60]
    d01c:      	sub	x12, x10, x8
    d020:      	ldr	w23, [sp, #0x68]
    d024:      	subs	w10, w21, w23
    d028:      	ldr	x9, [sp, #0x88]
    d02c:      	csel	w10, wzr, w10, lo
    d030:      	cmp	w23, w21
    d034:      	csel	w11, w23, w21, lo
    d038:      	cinc	w13, w11, hi
    d03c:      	sub	w14, w23, w13
    d040:      	subs	x12, x12, x13
    d044:      	str	w14, [sp, #0x68]
    d048:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    d04c:      	cmp	x12, #0xfff
    d050:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    d054:      	cmp	w23, w21
    d058:      	b.ls	0xd064 <generic_rawtp_path+0x2d74>
    d05c:      	mov	w13, #0x2f              // =47
    d060:      	strb	w13, [x8, x12]
    d064:      	add	x19, x8, x12
    d068:      	cmp	w23, w21
    d06c:      	add	x2, x9, x10
    d070:      	and	w1, w11, #0xff
    d074:      	mov	w8, #0x4                // =4
    d078:      	cinc	x0, x19, hi
    d07c:      	blr	x8
    d080:      	cmp	w23, w21
    d084:      	str	x19, [sp, #0x60]
    d088:      	add	x19, sp, #0x70
    d08c:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    d090:      	ldr	x21, [sp, #0x78]
    d094:      	ldp	x2, x24, [sp, #0x50]
    d098:      	str	x21, [sp, #0x48]
    d09c:      	b	0xd0ec <generic_rawtp_path+0x2dfc>
    d0a0:      	add	x2, x24, #0x10
    d0a4:      	mov	w8, #0x4                // =4
    d0a8:      	add	x9, sp, #0x98
    d0ac:      	add	x0, sp, #0x98
    d0b0:      	mov	w1, #0x8                // =8
    d0b4:      	blr	x8
    d0b8:      	ldr	x8, [sp, #0x58]
    d0bc:      	ldr	x9, [sp, #0x98]
    d0c0:      	cmp	x8, x9
    d0c4:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    d0c8:      	add	x2, x24, #0x18
    d0cc:      	mov	w8, #0x4                // =4
    d0d0:      	mov	x0, x22
    d0d4:      	mov	w1, #0x8                // =8
    d0d8:      	blr	x8
    d0dc:      	ldr	x24, [sp, #0x98]
    d0e0:      	ldr	x21, [sp, #0x48]
    d0e4:      	add	x2, x24, #0x20
    d0e8:      	stp	x2, x24, [sp, #0x50]
    d0ec:      	ldr	x8, [sp, #0x30]
    d0f0:      	cmp	x21, x8
    d0f4:      	b.ne	0xd104 <generic_rawtp_path+0x2e14>
    d0f8:      	ldr	x8, [sp, #0x38]
    d0fc:      	cmp	x2, x8
    d100:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    d104:      	mov	w8, #0x4                // =4
    d108:      	add	x0, sp, #0x70
    d10c:      	mov	w1, #0x8                // =8
    d110:      	blr	x8
    d114:      	ldr	x8, [sp, #0x70]
    d118:      	cmp	x21, x8
    d11c:      	b.eq	0xd20c <generic_rawtp_path+0x2f1c>
    d120:      	add	x23, x21, #0x18
    d124:      	mov	w8, #0x4                // =4
    d128:      	add	x9, sp, #0x98
    d12c:      	add	x0, sp, #0x98
    d130:      	mov	w1, #0x8                // =8
    d134:      	mov	x2, x23
    d138:      	blr	x8
    d13c:      	ldr	x8, [sp, #0x98]
    d140:      	cmp	x8, x21
    d144:      	b.eq	0xd20c <generic_rawtp_path+0x2f1c>
    d148:      	mov	w8, #0x4                // =4
    d14c:      	add	x9, sp, #0x78
    d150:      	add	x0, sp, #0x78
    d154:      	mov	w1, #0x8                // =8
    d158:      	mov	x2, x23
    d15c:      	blr	x8
    d160:      	add	x2, x21, #0x20
    d164:      	mov	w8, #0x4                // =4
    d168:      	mov	w9, #0x10               // =16
    d16c:      	add	x10, sp, #0x80
    d170:      	add	x0, sp, #0x80
    d174:      	mov	w1, #0x10               // =16
    d178:      	blr	x8
    d17c:      	ldr	w21, [sp, #0x84]
    d180:      	ldr	x8, [sp, #0x40]
    d184:      	ldr	x10, [sp, #0x60]
    d188:      	sub	x12, x10, x8
    d18c:      	ldr	w23, [sp, #0x68]
    d190:      	subs	w10, w21, w23
    d194:      	ldr	x9, [sp, #0x88]
    d198:      	csel	w10, wzr, w10, lo
    d19c:      	cmp	w23, w21
    d1a0:      	csel	w11, w23, w21, lo
    d1a4:      	cinc	w13, w11, hi
    d1a8:      	sub	w14, w23, w13
    d1ac:      	subs	x12, x12, x13
    d1b0:      	str	w14, [sp, #0x68]
    d1b4:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    d1b8:      	cmp	x12, #0xfff
    d1bc:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    d1c0:      	cmp	w23, w21
    d1c4:      	b.ls	0xd1d0 <generic_rawtp_path+0x2ee0>
    d1c8:      	mov	w13, #0x2f              // =47
    d1cc:      	strb	w13, [x8, x12]
    d1d0:      	add	x19, x8, x12
    d1d4:      	cmp	w23, w21
    d1d8:      	add	x2, x9, x10
    d1dc:      	and	w1, w11, #0xff
    d1e0:      	mov	w8, #0x4                // =4
    d1e4:      	cinc	x0, x19, hi
    d1e8:      	blr	x8
    d1ec:      	cmp	w23, w21
    d1f0:      	str	x19, [sp, #0x60]
    d1f4:      	add	x19, sp, #0x70
    d1f8:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    d1fc:      	ldr	x21, [sp, #0x78]
    d200:      	ldp	x2, x24, [sp, #0x50]
    d204:      	str	x21, [sp, #0x48]
    d208:      	b	0xd258 <generic_rawtp_path+0x2f68>
    d20c:      	add	x2, x24, #0x10
    d210:      	mov	w8, #0x4                // =4
    d214:      	add	x9, sp, #0x98
    d218:      	add	x0, sp, #0x98
    d21c:      	mov	w1, #0x8                // =8
    d220:      	blr	x8
    d224:      	ldr	x8, [sp, #0x58]
    d228:      	ldr	x9, [sp, #0x98]
    d22c:      	cmp	x8, x9
    d230:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    d234:      	add	x2, x24, #0x18
    d238:      	mov	w8, #0x4                // =4
    d23c:      	mov	x0, x22
    d240:      	mov	w1, #0x8                // =8
    d244:      	blr	x8
    d248:      	ldr	x24, [sp, #0x98]
    d24c:      	ldr	x21, [sp, #0x48]
    d250:      	add	x2, x24, #0x20
    d254:      	stp	x2, x24, [sp, #0x50]
    d258:      	ldr	x8, [sp, #0x30]
    d25c:      	cmp	x21, x8
    d260:      	b.ne	0xd270 <generic_rawtp_path+0x2f80>
    d264:      	ldr	x8, [sp, #0x38]
    d268:      	cmp	x2, x8
    d26c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    d270:      	mov	w8, #0x4                // =4
    d274:      	add	x0, sp, #0x70
    d278:      	mov	w1, #0x8                // =8
    d27c:      	blr	x8
    d280:      	ldr	x8, [sp, #0x70]
    d284:      	cmp	x21, x8
    d288:      	b.eq	0xd378 <generic_rawtp_path+0x3088>
    d28c:      	add	x23, x21, #0x18
    d290:      	mov	w8, #0x4                // =4
    d294:      	add	x9, sp, #0x98
    d298:      	add	x0, sp, #0x98
    d29c:      	mov	w1, #0x8                // =8
    d2a0:      	mov	x2, x23
    d2a4:      	blr	x8
    d2a8:      	ldr	x8, [sp, #0x98]
    d2ac:      	cmp	x8, x21
    d2b0:      	b.eq	0xd378 <generic_rawtp_path+0x3088>
    d2b4:      	mov	w8, #0x4                // =4
    d2b8:      	add	x9, sp, #0x78
    d2bc:      	add	x0, sp, #0x78
    d2c0:      	mov	w1, #0x8                // =8
    d2c4:      	mov	x2, x23
    d2c8:      	blr	x8
    d2cc:      	add	x2, x21, #0x20
    d2d0:      	mov	w8, #0x4                // =4
    d2d4:      	mov	w9, #0x10               // =16
    d2d8:      	add	x10, sp, #0x80
    d2dc:      	add	x0, sp, #0x80
    d2e0:      	mov	w1, #0x10               // =16
    d2e4:      	blr	x8
    d2e8:      	ldr	w21, [sp, #0x84]
    d2ec:      	ldr	x8, [sp, #0x40]
    d2f0:      	ldr	x10, [sp, #0x60]
    d2f4:      	sub	x12, x10, x8
    d2f8:      	ldr	w23, [sp, #0x68]
    d2fc:      	subs	w10, w21, w23
    d300:      	ldr	x9, [sp, #0x88]
    d304:      	csel	w10, wzr, w10, lo
    d308:      	cmp	w23, w21
    d30c:      	csel	w11, w23, w21, lo
    d310:      	cinc	w13, w11, hi
    d314:      	sub	w14, w23, w13
    d318:      	subs	x12, x12, x13
    d31c:      	str	w14, [sp, #0x68]
    d320:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    d324:      	cmp	x12, #0xfff
    d328:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    d32c:      	cmp	w23, w21
    d330:      	b.ls	0xd33c <generic_rawtp_path+0x304c>
    d334:      	mov	w13, #0x2f              // =47
    d338:      	strb	w13, [x8, x12]
    d33c:      	add	x19, x8, x12
    d340:      	cmp	w23, w21
    d344:      	add	x2, x9, x10
    d348:      	and	w1, w11, #0xff
    d34c:      	mov	w8, #0x4                // =4
    d350:      	cinc	x0, x19, hi
    d354:      	blr	x8
    d358:      	cmp	w23, w21
    d35c:      	str	x19, [sp, #0x60]
    d360:      	add	x19, sp, #0x70
    d364:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    d368:      	ldr	x21, [sp, #0x78]
    d36c:      	ldp	x2, x24, [sp, #0x50]
    d370:      	str	x21, [sp, #0x48]
    d374:      	b	0xd3c4 <generic_rawtp_path+0x30d4>
    d378:      	add	x2, x24, #0x10
    d37c:      	mov	w8, #0x4                // =4
    d380:      	add	x9, sp, #0x98
    d384:      	add	x0, sp, #0x98
    d388:      	mov	w1, #0x8                // =8
    d38c:      	blr	x8
    d390:      	ldr	x8, [sp, #0x58]
    d394:      	ldr	x9, [sp, #0x98]
    d398:      	cmp	x8, x9
    d39c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    d3a0:      	add	x2, x24, #0x18
    d3a4:      	mov	w8, #0x4                // =4
    d3a8:      	mov	x0, x22
    d3ac:      	mov	w1, #0x8                // =8
    d3b0:      	blr	x8
    d3b4:      	ldr	x24, [sp, #0x98]
    d3b8:      	ldr	x21, [sp, #0x48]
    d3bc:      	add	x2, x24, #0x20
    d3c0:      	stp	x2, x24, [sp, #0x50]
    d3c4:      	ldr	x8, [sp, #0x30]
    d3c8:      	cmp	x21, x8
    d3cc:      	b.ne	0xd3dc <generic_rawtp_path+0x30ec>
    d3d0:      	ldr	x8, [sp, #0x38]
    d3d4:      	cmp	x2, x8
    d3d8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    d3dc:      	mov	w8, #0x4                // =4
    d3e0:      	add	x0, sp, #0x70
    d3e4:      	mov	w1, #0x8                // =8
    d3e8:      	blr	x8
    d3ec:      	ldr	x8, [sp, #0x70]
    d3f0:      	cmp	x21, x8
    d3f4:      	b.eq	0xd4e4 <generic_rawtp_path+0x31f4>
    d3f8:      	add	x23, x21, #0x18
    d3fc:      	mov	w8, #0x4                // =4
    d400:      	add	x9, sp, #0x98
    d404:      	add	x0, sp, #0x98
    d408:      	mov	w1, #0x8                // =8
    d40c:      	mov	x2, x23
    d410:      	blr	x8
    d414:      	ldr	x8, [sp, #0x98]
    d418:      	cmp	x8, x21
    d41c:      	b.eq	0xd4e4 <generic_rawtp_path+0x31f4>
    d420:      	mov	w8, #0x4                // =4
    d424:      	add	x9, sp, #0x78
    d428:      	add	x0, sp, #0x78
    d42c:      	mov	w1, #0x8                // =8
    d430:      	mov	x2, x23
    d434:      	blr	x8
    d438:      	add	x2, x21, #0x20
    d43c:      	mov	w8, #0x4                // =4
    d440:      	mov	w9, #0x10               // =16
    d444:      	add	x10, sp, #0x80
    d448:      	add	x0, sp, #0x80
    d44c:      	mov	w1, #0x10               // =16
    d450:      	blr	x8
    d454:      	ldr	w21, [sp, #0x84]
    d458:      	ldr	x8, [sp, #0x40]
    d45c:      	ldr	x10, [sp, #0x60]
    d460:      	sub	x12, x10, x8
    d464:      	ldr	w23, [sp, #0x68]
    d468:      	subs	w10, w21, w23
    d46c:      	ldr	x9, [sp, #0x88]
    d470:      	csel	w10, wzr, w10, lo
    d474:      	cmp	w23, w21
    d478:      	csel	w11, w23, w21, lo
    d47c:      	cinc	w13, w11, hi
    d480:      	sub	w14, w23, w13
    d484:      	subs	x12, x12, x13
    d488:      	str	w14, [sp, #0x68]
    d48c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    d490:      	cmp	x12, #0xfff
    d494:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    d498:      	cmp	w23, w21
    d49c:      	b.ls	0xd4a8 <generic_rawtp_path+0x31b8>
    d4a0:      	mov	w13, #0x2f              // =47
    d4a4:      	strb	w13, [x8, x12]
    d4a8:      	add	x19, x8, x12
    d4ac:      	cmp	w23, w21
    d4b0:      	add	x2, x9, x10
    d4b4:      	and	w1, w11, #0xff
    d4b8:      	mov	w8, #0x4                // =4
    d4bc:      	cinc	x0, x19, hi
    d4c0:      	blr	x8
    d4c4:      	cmp	w23, w21
    d4c8:      	str	x19, [sp, #0x60]
    d4cc:      	add	x19, sp, #0x70
    d4d0:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    d4d4:      	ldr	x21, [sp, #0x78]
    d4d8:      	ldp	x2, x24, [sp, #0x50]
    d4dc:      	str	x21, [sp, #0x48]
    d4e0:      	b	0xd530 <generic_rawtp_path+0x3240>
    d4e4:      	add	x2, x24, #0x10
    d4e8:      	mov	w8, #0x4                // =4
    d4ec:      	add	x9, sp, #0x98
    d4f0:      	add	x0, sp, #0x98
    d4f4:      	mov	w1, #0x8                // =8
    d4f8:      	blr	x8
    d4fc:      	ldr	x8, [sp, #0x58]
    d500:      	ldr	x9, [sp, #0x98]
    d504:      	cmp	x8, x9
    d508:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    d50c:      	add	x2, x24, #0x18
    d510:      	mov	w8, #0x4                // =4
    d514:      	mov	x0, x22
    d518:      	mov	w1, #0x8                // =8
    d51c:      	blr	x8
    d520:      	ldr	x24, [sp, #0x98]
    d524:      	ldr	x21, [sp, #0x48]
    d528:      	add	x2, x24, #0x20
    d52c:      	stp	x2, x24, [sp, #0x50]
    d530:      	ldr	x8, [sp, #0x30]
    d534:      	cmp	x21, x8
    d538:      	b.ne	0xd548 <generic_rawtp_path+0x3258>
    d53c:      	ldr	x8, [sp, #0x38]
    d540:      	cmp	x2, x8
    d544:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    d548:      	mov	w8, #0x4                // =4
    d54c:      	add	x0, sp, #0x70
    d550:      	mov	w1, #0x8                // =8
    d554:      	blr	x8
    d558:      	ldr	x8, [sp, #0x70]
    d55c:      	cmp	x21, x8
    d560:      	b.eq	0xd650 <generic_rawtp_path+0x3360>
    d564:      	add	x23, x21, #0x18
    d568:      	mov	w8, #0x4                // =4
    d56c:      	add	x9, sp, #0x98
    d570:      	add	x0, sp, #0x98
    d574:      	mov	w1, #0x8                // =8
    d578:      	mov	x2, x23
    d57c:      	blr	x8
    d580:      	ldr	x8, [sp, #0x98]
    d584:      	cmp	x8, x21
    d588:      	b.eq	0xd650 <generic_rawtp_path+0x3360>
    d58c:      	mov	w8, #0x4                // =4
    d590:      	add	x9, sp, #0x78
    d594:      	add	x0, sp, #0x78
    d598:      	mov	w1, #0x8                // =8
    d59c:      	mov	x2, x23
    d5a0:      	blr	x8
    d5a4:      	add	x2, x21, #0x20
    d5a8:      	mov	w8, #0x4                // =4
    d5ac:      	mov	w9, #0x10               // =16
    d5b0:      	add	x10, sp, #0x80
    d5b4:      	add	x0, sp, #0x80
    d5b8:      	mov	w1, #0x10               // =16
    d5bc:      	blr	x8
    d5c0:      	ldr	w21, [sp, #0x84]
    d5c4:      	ldr	x8, [sp, #0x40]
    d5c8:      	ldr	x10, [sp, #0x60]
    d5cc:      	sub	x12, x10, x8
    d5d0:      	ldr	w23, [sp, #0x68]
    d5d4:      	subs	w10, w21, w23
    d5d8:      	ldr	x9, [sp, #0x88]
    d5dc:      	csel	w10, wzr, w10, lo
    d5e0:      	cmp	w23, w21
    d5e4:      	csel	w11, w23, w21, lo
    d5e8:      	cinc	w13, w11, hi
    d5ec:      	sub	w14, w23, w13
    d5f0:      	subs	x12, x12, x13
    d5f4:      	str	w14, [sp, #0x68]
    d5f8:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    d5fc:      	cmp	x12, #0xfff
    d600:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    d604:      	cmp	w23, w21
    d608:      	b.ls	0xd614 <generic_rawtp_path+0x3324>
    d60c:      	mov	w13, #0x2f              // =47
    d610:      	strb	w13, [x8, x12]
    d614:      	add	x19, x8, x12
    d618:      	cmp	w23, w21
    d61c:      	add	x2, x9, x10
    d620:      	and	w1, w11, #0xff
    d624:      	mov	w8, #0x4                // =4
    d628:      	cinc	x0, x19, hi
    d62c:      	blr	x8
    d630:      	cmp	w23, w21
    d634:      	str	x19, [sp, #0x60]
    d638:      	add	x19, sp, #0x70
    d63c:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    d640:      	ldr	x21, [sp, #0x78]
    d644:      	ldp	x2, x24, [sp, #0x50]
    d648:      	str	x21, [sp, #0x48]
    d64c:      	b	0xd69c <generic_rawtp_path+0x33ac>
    d650:      	add	x2, x24, #0x10
    d654:      	mov	w8, #0x4                // =4
    d658:      	add	x9, sp, #0x98
    d65c:      	add	x0, sp, #0x98
    d660:      	mov	w1, #0x8                // =8
    d664:      	blr	x8
    d668:      	ldr	x8, [sp, #0x58]
    d66c:      	ldr	x9, [sp, #0x98]
    d670:      	cmp	x8, x9
    d674:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    d678:      	add	x2, x24, #0x18
    d67c:      	mov	w8, #0x4                // =4
    d680:      	mov	x0, x22
    d684:      	mov	w1, #0x8                // =8
    d688:      	blr	x8
    d68c:      	ldr	x24, [sp, #0x98]
    d690:      	ldr	x21, [sp, #0x48]
    d694:      	add	x2, x24, #0x20
    d698:      	stp	x2, x24, [sp, #0x50]
    d69c:      	ldr	x8, [sp, #0x30]
    d6a0:      	cmp	x21, x8
    d6a4:      	b.ne	0xd6b4 <generic_rawtp_path+0x33c4>
    d6a8:      	ldr	x8, [sp, #0x38]
    d6ac:      	cmp	x2, x8
    d6b0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    d6b4:      	mov	w8, #0x4                // =4
    d6b8:      	add	x0, sp, #0x70
    d6bc:      	mov	w1, #0x8                // =8
    d6c0:      	blr	x8
    d6c4:      	ldr	x8, [sp, #0x70]
    d6c8:      	cmp	x21, x8
    d6cc:      	b.eq	0xd7bc <generic_rawtp_path+0x34cc>
    d6d0:      	add	x23, x21, #0x18
    d6d4:      	mov	w8, #0x4                // =4
    d6d8:      	add	x9, sp, #0x98
    d6dc:      	add	x0, sp, #0x98
    d6e0:      	mov	w1, #0x8                // =8
    d6e4:      	mov	x2, x23
    d6e8:      	blr	x8
    d6ec:      	ldr	x8, [sp, #0x98]
    d6f0:      	cmp	x8, x21
    d6f4:      	b.eq	0xd7bc <generic_rawtp_path+0x34cc>
    d6f8:      	mov	w8, #0x4                // =4
    d6fc:      	add	x9, sp, #0x78
    d700:      	add	x0, sp, #0x78
    d704:      	mov	w1, #0x8                // =8
    d708:      	mov	x2, x23
    d70c:      	blr	x8
    d710:      	add	x2, x21, #0x20
    d714:      	mov	w8, #0x4                // =4
    d718:      	mov	w9, #0x10               // =16
    d71c:      	add	x10, sp, #0x80
    d720:      	add	x0, sp, #0x80
    d724:      	mov	w1, #0x10               // =16
    d728:      	blr	x8
    d72c:      	ldr	w21, [sp, #0x84]
    d730:      	ldr	x8, [sp, #0x40]
    d734:      	ldr	x10, [sp, #0x60]
    d738:      	sub	x12, x10, x8
    d73c:      	ldr	w23, [sp, #0x68]
    d740:      	subs	w10, w21, w23
    d744:      	ldr	x9, [sp, #0x88]
    d748:      	csel	w10, wzr, w10, lo
    d74c:      	cmp	w23, w21
    d750:      	csel	w11, w23, w21, lo
    d754:      	cinc	w13, w11, hi
    d758:      	sub	w14, w23, w13
    d75c:      	subs	x12, x12, x13
    d760:      	str	w14, [sp, #0x68]
    d764:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    d768:      	cmp	x12, #0xfff
    d76c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    d770:      	cmp	w23, w21
    d774:      	b.ls	0xd780 <generic_rawtp_path+0x3490>
    d778:      	mov	w13, #0x2f              // =47
    d77c:      	strb	w13, [x8, x12]
    d780:      	add	x19, x8, x12
    d784:      	cmp	w23, w21
    d788:      	add	x2, x9, x10
    d78c:      	and	w1, w11, #0xff
    d790:      	mov	w8, #0x4                // =4
    d794:      	cinc	x0, x19, hi
    d798:      	blr	x8
    d79c:      	cmp	w23, w21
    d7a0:      	str	x19, [sp, #0x60]
    d7a4:      	add	x19, sp, #0x70
    d7a8:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    d7ac:      	ldr	x21, [sp, #0x78]
    d7b0:      	ldp	x2, x24, [sp, #0x50]
    d7b4:      	str	x21, [sp, #0x48]
    d7b8:      	b	0xd808 <generic_rawtp_path+0x3518>
    d7bc:      	add	x2, x24, #0x10
    d7c0:      	mov	w8, #0x4                // =4
    d7c4:      	add	x9, sp, #0x98
    d7c8:      	add	x0, sp, #0x98
    d7cc:      	mov	w1, #0x8                // =8
    d7d0:      	blr	x8
    d7d4:      	ldr	x8, [sp, #0x58]
    d7d8:      	ldr	x9, [sp, #0x98]
    d7dc:      	cmp	x8, x9
    d7e0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    d7e4:      	add	x2, x24, #0x18
    d7e8:      	mov	w8, #0x4                // =4
    d7ec:      	mov	x0, x22
    d7f0:      	mov	w1, #0x8                // =8
    d7f4:      	blr	x8
    d7f8:      	ldr	x24, [sp, #0x98]
    d7fc:      	ldr	x21, [sp, #0x48]
    d800:      	add	x2, x24, #0x20
    d804:      	stp	x2, x24, [sp, #0x50]
    d808:      	ldr	x8, [sp, #0x30]
    d80c:      	cmp	x21, x8
    d810:      	b.ne	0xd820 <generic_rawtp_path+0x3530>
    d814:      	ldr	x8, [sp, #0x38]
    d818:      	cmp	x2, x8
    d81c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    d820:      	mov	w8, #0x4                // =4
    d824:      	add	x0, sp, #0x70
    d828:      	mov	w1, #0x8                // =8
    d82c:      	blr	x8
    d830:      	ldr	x8, [sp, #0x70]
    d834:      	cmp	x21, x8
    d838:      	b.eq	0xd928 <generic_rawtp_path+0x3638>
    d83c:      	add	x23, x21, #0x18
    d840:      	mov	w8, #0x4                // =4
    d844:      	add	x9, sp, #0x98
    d848:      	add	x0, sp, #0x98
    d84c:      	mov	w1, #0x8                // =8
    d850:      	mov	x2, x23
    d854:      	blr	x8
    d858:      	ldr	x8, [sp, #0x98]
    d85c:      	cmp	x8, x21
    d860:      	b.eq	0xd928 <generic_rawtp_path+0x3638>
    d864:      	mov	w8, #0x4                // =4
    d868:      	add	x9, sp, #0x78
    d86c:      	add	x0, sp, #0x78
    d870:      	mov	w1, #0x8                // =8
    d874:      	mov	x2, x23
    d878:      	blr	x8
    d87c:      	add	x2, x21, #0x20
    d880:      	mov	w8, #0x4                // =4
    d884:      	mov	w9, #0x10               // =16
    d888:      	add	x10, sp, #0x80
    d88c:      	add	x0, sp, #0x80
    d890:      	mov	w1, #0x10               // =16
    d894:      	blr	x8
    d898:      	ldr	w21, [sp, #0x84]
    d89c:      	ldr	x8, [sp, #0x40]
    d8a0:      	ldr	x10, [sp, #0x60]
    d8a4:      	sub	x12, x10, x8
    d8a8:      	ldr	w23, [sp, #0x68]
    d8ac:      	subs	w10, w21, w23
    d8b0:      	ldr	x9, [sp, #0x88]
    d8b4:      	csel	w10, wzr, w10, lo
    d8b8:      	cmp	w23, w21
    d8bc:      	csel	w11, w23, w21, lo
    d8c0:      	cinc	w13, w11, hi
    d8c4:      	sub	w14, w23, w13
    d8c8:      	subs	x12, x12, x13
    d8cc:      	str	w14, [sp, #0x68]
    d8d0:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    d8d4:      	cmp	x12, #0xfff
    d8d8:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    d8dc:      	cmp	w23, w21
    d8e0:      	b.ls	0xd8ec <generic_rawtp_path+0x35fc>
    d8e4:      	mov	w13, #0x2f              // =47
    d8e8:      	strb	w13, [x8, x12]
    d8ec:      	add	x19, x8, x12
    d8f0:      	cmp	w23, w21
    d8f4:      	add	x2, x9, x10
    d8f8:      	and	w1, w11, #0xff
    d8fc:      	mov	w8, #0x4                // =4
    d900:      	cinc	x0, x19, hi
    d904:      	blr	x8
    d908:      	cmp	w23, w21
    d90c:      	str	x19, [sp, #0x60]
    d910:      	add	x19, sp, #0x70
    d914:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    d918:      	ldr	x21, [sp, #0x78]
    d91c:      	ldp	x2, x24, [sp, #0x50]
    d920:      	str	x21, [sp, #0x48]
    d924:      	b	0xd974 <generic_rawtp_path+0x3684>
    d928:      	add	x2, x24, #0x10
    d92c:      	mov	w8, #0x4                // =4
    d930:      	add	x9, sp, #0x98
    d934:      	add	x0, sp, #0x98
    d938:      	mov	w1, #0x8                // =8
    d93c:      	blr	x8
    d940:      	ldr	x8, [sp, #0x58]
    d944:      	ldr	x9, [sp, #0x98]
    d948:      	cmp	x8, x9
    d94c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    d950:      	add	x2, x24, #0x18
    d954:      	mov	w8, #0x4                // =4
    d958:      	mov	x0, x22
    d95c:      	mov	w1, #0x8                // =8
    d960:      	blr	x8
    d964:      	ldr	x24, [sp, #0x98]
    d968:      	ldr	x21, [sp, #0x48]
    d96c:      	add	x2, x24, #0x20
    d970:      	stp	x2, x24, [sp, #0x50]
    d974:      	ldr	x8, [sp, #0x30]
    d978:      	cmp	x21, x8
    d97c:      	b.ne	0xd98c <generic_rawtp_path+0x369c>
    d980:      	ldr	x8, [sp, #0x38]
    d984:      	cmp	x2, x8
    d988:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    d98c:      	mov	w8, #0x4                // =4
    d990:      	add	x0, sp, #0x70
    d994:      	mov	w1, #0x8                // =8
    d998:      	blr	x8
    d99c:      	ldr	x8, [sp, #0x70]
    d9a0:      	cmp	x21, x8
    d9a4:      	b.eq	0xda94 <generic_rawtp_path+0x37a4>
    d9a8:      	add	x23, x21, #0x18
    d9ac:      	mov	w8, #0x4                // =4
    d9b0:      	add	x9, sp, #0x98
    d9b4:      	add	x0, sp, #0x98
    d9b8:      	mov	w1, #0x8                // =8
    d9bc:      	mov	x2, x23
    d9c0:      	blr	x8
    d9c4:      	ldr	x8, [sp, #0x98]
    d9c8:      	cmp	x8, x21
    d9cc:      	b.eq	0xda94 <generic_rawtp_path+0x37a4>
    d9d0:      	mov	w8, #0x4                // =4
    d9d4:      	add	x9, sp, #0x78
    d9d8:      	add	x0, sp, #0x78
    d9dc:      	mov	w1, #0x8                // =8
    d9e0:      	mov	x2, x23
    d9e4:      	blr	x8
    d9e8:      	add	x2, x21, #0x20
    d9ec:      	mov	w8, #0x4                // =4
    d9f0:      	mov	w9, #0x10               // =16
    d9f4:      	add	x10, sp, #0x80
    d9f8:      	add	x0, sp, #0x80
    d9fc:      	mov	w1, #0x10               // =16
    da00:      	blr	x8
    da04:      	ldr	w21, [sp, #0x84]
    da08:      	ldr	x8, [sp, #0x40]
    da0c:      	ldr	x10, [sp, #0x60]
    da10:      	sub	x12, x10, x8
    da14:      	ldr	w23, [sp, #0x68]
    da18:      	subs	w10, w21, w23
    da1c:      	ldr	x9, [sp, #0x88]
    da20:      	csel	w10, wzr, w10, lo
    da24:      	cmp	w23, w21
    da28:      	csel	w11, w23, w21, lo
    da2c:      	cinc	w13, w11, hi
    da30:      	sub	w14, w23, w13
    da34:      	subs	x12, x12, x13
    da38:      	str	w14, [sp, #0x68]
    da3c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    da40:      	cmp	x12, #0xfff
    da44:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    da48:      	cmp	w23, w21
    da4c:      	b.ls	0xda58 <generic_rawtp_path+0x3768>
    da50:      	mov	w13, #0x2f              // =47
    da54:      	strb	w13, [x8, x12]
    da58:      	add	x19, x8, x12
    da5c:      	cmp	w23, w21
    da60:      	add	x2, x9, x10
    da64:      	and	w1, w11, #0xff
    da68:      	mov	w8, #0x4                // =4
    da6c:      	cinc	x0, x19, hi
    da70:      	blr	x8
    da74:      	cmp	w23, w21
    da78:      	str	x19, [sp, #0x60]
    da7c:      	add	x19, sp, #0x70
    da80:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    da84:      	ldr	x21, [sp, #0x78]
    da88:      	ldp	x2, x24, [sp, #0x50]
    da8c:      	str	x21, [sp, #0x48]
    da90:      	b	0xdae0 <generic_rawtp_path+0x37f0>
    da94:      	add	x2, x24, #0x10
    da98:      	mov	w8, #0x4                // =4
    da9c:      	add	x9, sp, #0x98
    daa0:      	add	x0, sp, #0x98
    daa4:      	mov	w1, #0x8                // =8
    daa8:      	blr	x8
    daac:      	ldr	x8, [sp, #0x58]
    dab0:      	ldr	x9, [sp, #0x98]
    dab4:      	cmp	x8, x9
    dab8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    dabc:      	add	x2, x24, #0x18
    dac0:      	mov	w8, #0x4                // =4
    dac4:      	mov	x0, x22
    dac8:      	mov	w1, #0x8                // =8
    dacc:      	blr	x8
    dad0:      	ldr	x24, [sp, #0x98]
    dad4:      	ldr	x21, [sp, #0x48]
    dad8:      	add	x2, x24, #0x20
    dadc:      	stp	x2, x24, [sp, #0x50]
    dae0:      	ldr	x8, [sp, #0x30]
    dae4:      	cmp	x21, x8
    dae8:      	b.ne	0xdaf8 <generic_rawtp_path+0x3808>
    daec:      	ldr	x8, [sp, #0x38]
    daf0:      	cmp	x2, x8
    daf4:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    daf8:      	mov	w8, #0x4                // =4
    dafc:      	add	x0, sp, #0x70
    db00:      	mov	w1, #0x8                // =8
    db04:      	blr	x8
    db08:      	ldr	x8, [sp, #0x70]
    db0c:      	cmp	x21, x8
    db10:      	b.eq	0xdc00 <generic_rawtp_path+0x3910>
    db14:      	add	x23, x21, #0x18
    db18:      	mov	w8, #0x4                // =4
    db1c:      	add	x9, sp, #0x98
    db20:      	add	x0, sp, #0x98
    db24:      	mov	w1, #0x8                // =8
    db28:      	mov	x2, x23
    db2c:      	blr	x8
    db30:      	ldr	x8, [sp, #0x98]
    db34:      	cmp	x8, x21
    db38:      	b.eq	0xdc00 <generic_rawtp_path+0x3910>
    db3c:      	mov	w8, #0x4                // =4
    db40:      	add	x9, sp, #0x78
    db44:      	add	x0, sp, #0x78
    db48:      	mov	w1, #0x8                // =8
    db4c:      	mov	x2, x23
    db50:      	blr	x8
    db54:      	add	x2, x21, #0x20
    db58:      	mov	w8, #0x4                // =4
    db5c:      	mov	w9, #0x10               // =16
    db60:      	add	x10, sp, #0x80
    db64:      	add	x0, sp, #0x80
    db68:      	mov	w1, #0x10               // =16
    db6c:      	blr	x8
    db70:      	ldr	w21, [sp, #0x84]
    db74:      	ldr	x8, [sp, #0x40]
    db78:      	ldr	x10, [sp, #0x60]
    db7c:      	sub	x12, x10, x8
    db80:      	ldr	w23, [sp, #0x68]
    db84:      	subs	w10, w21, w23
    db88:      	ldr	x9, [sp, #0x88]
    db8c:      	csel	w10, wzr, w10, lo
    db90:      	cmp	w23, w21
    db94:      	csel	w11, w23, w21, lo
    db98:      	cinc	w13, w11, hi
    db9c:      	sub	w14, w23, w13
    dba0:      	subs	x12, x12, x13
    dba4:      	str	w14, [sp, #0x68]
    dba8:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    dbac:      	cmp	x12, #0xfff
    dbb0:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    dbb4:      	cmp	w23, w21
    dbb8:      	b.ls	0xdbc4 <generic_rawtp_path+0x38d4>
    dbbc:      	mov	w13, #0x2f              // =47
    dbc0:      	strb	w13, [x8, x12]
    dbc4:      	add	x19, x8, x12
    dbc8:      	cmp	w23, w21
    dbcc:      	add	x2, x9, x10
    dbd0:      	and	w1, w11, #0xff
    dbd4:      	mov	w8, #0x4                // =4
    dbd8:      	cinc	x0, x19, hi
    dbdc:      	blr	x8
    dbe0:      	cmp	w23, w21
    dbe4:      	str	x19, [sp, #0x60]
    dbe8:      	add	x19, sp, #0x70
    dbec:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    dbf0:      	ldr	x21, [sp, #0x78]
    dbf4:      	ldp	x2, x24, [sp, #0x50]
    dbf8:      	str	x21, [sp, #0x48]
    dbfc:      	b	0xdc4c <generic_rawtp_path+0x395c>
    dc00:      	add	x2, x24, #0x10
    dc04:      	mov	w8, #0x4                // =4
    dc08:      	add	x9, sp, #0x98
    dc0c:      	add	x0, sp, #0x98
    dc10:      	mov	w1, #0x8                // =8
    dc14:      	blr	x8
    dc18:      	ldr	x8, [sp, #0x58]
    dc1c:      	ldr	x9, [sp, #0x98]
    dc20:      	cmp	x8, x9
    dc24:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    dc28:      	add	x2, x24, #0x18
    dc2c:      	mov	w8, #0x4                // =4
    dc30:      	mov	x0, x22
    dc34:      	mov	w1, #0x8                // =8
    dc38:      	blr	x8
    dc3c:      	ldr	x24, [sp, #0x98]
    dc40:      	ldr	x21, [sp, #0x48]
    dc44:      	add	x2, x24, #0x20
    dc48:      	stp	x2, x24, [sp, #0x50]
    dc4c:      	ldr	x8, [sp, #0x30]
    dc50:      	cmp	x21, x8
    dc54:      	b.ne	0xdc64 <generic_rawtp_path+0x3974>
    dc58:      	ldr	x8, [sp, #0x38]
    dc5c:      	cmp	x2, x8
    dc60:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    dc64:      	mov	w8, #0x4                // =4
    dc68:      	add	x0, sp, #0x70
    dc6c:      	mov	w1, #0x8                // =8
    dc70:      	blr	x8
    dc74:      	ldr	x8, [sp, #0x70]
    dc78:      	cmp	x21, x8
    dc7c:      	b.eq	0xdd6c <generic_rawtp_path+0x3a7c>
    dc80:      	add	x23, x21, #0x18
    dc84:      	mov	w8, #0x4                // =4
    dc88:      	add	x9, sp, #0x98
    dc8c:      	add	x0, sp, #0x98
    dc90:      	mov	w1, #0x8                // =8
    dc94:      	mov	x2, x23
    dc98:      	blr	x8
    dc9c:      	ldr	x8, [sp, #0x98]
    dca0:      	cmp	x8, x21
    dca4:      	b.eq	0xdd6c <generic_rawtp_path+0x3a7c>
    dca8:      	mov	w8, #0x4                // =4
    dcac:      	add	x9, sp, #0x78
    dcb0:      	add	x0, sp, #0x78
    dcb4:      	mov	w1, #0x8                // =8
    dcb8:      	mov	x2, x23
    dcbc:      	blr	x8
    dcc0:      	add	x2, x21, #0x20
    dcc4:      	mov	w8, #0x4                // =4
    dcc8:      	mov	w9, #0x10               // =16
    dccc:      	add	x10, sp, #0x80
    dcd0:      	add	x0, sp, #0x80
    dcd4:      	mov	w1, #0x10               // =16
    dcd8:      	blr	x8
    dcdc:      	ldr	w21, [sp, #0x84]
    dce0:      	ldr	x8, [sp, #0x40]
    dce4:      	ldr	x10, [sp, #0x60]
    dce8:      	sub	x12, x10, x8
    dcec:      	ldr	w23, [sp, #0x68]
    dcf0:      	subs	w10, w21, w23
    dcf4:      	ldr	x9, [sp, #0x88]
    dcf8:      	csel	w10, wzr, w10, lo
    dcfc:      	cmp	w23, w21
    dd00:      	csel	w11, w23, w21, lo
    dd04:      	cinc	w13, w11, hi
    dd08:      	sub	w14, w23, w13
    dd0c:      	subs	x12, x12, x13
    dd10:      	str	w14, [sp, #0x68]
    dd14:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    dd18:      	cmp	x12, #0xfff
    dd1c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    dd20:      	cmp	w23, w21
    dd24:      	b.ls	0xdd30 <generic_rawtp_path+0x3a40>
    dd28:      	mov	w13, #0x2f              // =47
    dd2c:      	strb	w13, [x8, x12]
    dd30:      	add	x19, x8, x12
    dd34:      	cmp	w23, w21
    dd38:      	add	x2, x9, x10
    dd3c:      	and	w1, w11, #0xff
    dd40:      	mov	w8, #0x4                // =4
    dd44:      	cinc	x0, x19, hi
    dd48:      	blr	x8
    dd4c:      	cmp	w23, w21
    dd50:      	str	x19, [sp, #0x60]
    dd54:      	add	x19, sp, #0x70
    dd58:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    dd5c:      	ldr	x21, [sp, #0x78]
    dd60:      	ldp	x2, x24, [sp, #0x50]
    dd64:      	str	x21, [sp, #0x48]
    dd68:      	b	0xddb8 <generic_rawtp_path+0x3ac8>
    dd6c:      	add	x2, x24, #0x10
    dd70:      	mov	w8, #0x4                // =4
    dd74:      	add	x9, sp, #0x98
    dd78:      	add	x0, sp, #0x98
    dd7c:      	mov	w1, #0x8                // =8
    dd80:      	blr	x8
    dd84:      	ldr	x8, [sp, #0x58]
    dd88:      	ldr	x9, [sp, #0x98]
    dd8c:      	cmp	x8, x9
    dd90:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    dd94:      	add	x2, x24, #0x18
    dd98:      	mov	w8, #0x4                // =4
    dd9c:      	mov	x0, x22
    dda0:      	mov	w1, #0x8                // =8
    dda4:      	blr	x8
    dda8:      	ldr	x24, [sp, #0x98]
    ddac:      	ldr	x21, [sp, #0x48]
    ddb0:      	add	x2, x24, #0x20
    ddb4:      	stp	x2, x24, [sp, #0x50]
    ddb8:      	ldr	x8, [sp, #0x30]
    ddbc:      	cmp	x21, x8
    ddc0:      	b.ne	0xddd0 <generic_rawtp_path+0x3ae0>
    ddc4:      	ldr	x8, [sp, #0x38]
    ddc8:      	cmp	x2, x8
    ddcc:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    ddd0:      	mov	w8, #0x4                // =4
    ddd4:      	add	x0, sp, #0x70
    ddd8:      	mov	w1, #0x8                // =8
    dddc:      	blr	x8
    dde0:      	ldr	x8, [sp, #0x70]
    dde4:      	cmp	x21, x8
    dde8:      	b.eq	0xded8 <generic_rawtp_path+0x3be8>
    ddec:      	add	x23, x21, #0x18
    ddf0:      	mov	w8, #0x4                // =4
    ddf4:      	add	x9, sp, #0x98
    ddf8:      	add	x0, sp, #0x98
    ddfc:      	mov	w1, #0x8                // =8
    de00:      	mov	x2, x23
    de04:      	blr	x8
    de08:      	ldr	x8, [sp, #0x98]
    de0c:      	cmp	x8, x21
    de10:      	b.eq	0xded8 <generic_rawtp_path+0x3be8>
    de14:      	mov	w8, #0x4                // =4
    de18:      	add	x9, sp, #0x78
    de1c:      	add	x0, sp, #0x78
    de20:      	mov	w1, #0x8                // =8
    de24:      	mov	x2, x23
    de28:      	blr	x8
    de2c:      	add	x2, x21, #0x20
    de30:      	mov	w8, #0x4                // =4
    de34:      	mov	w9, #0x10               // =16
    de38:      	add	x10, sp, #0x80
    de3c:      	add	x0, sp, #0x80
    de40:      	mov	w1, #0x10               // =16
    de44:      	blr	x8
    de48:      	ldr	w21, [sp, #0x84]
    de4c:      	ldr	x8, [sp, #0x40]
    de50:      	ldr	x10, [sp, #0x60]
    de54:      	sub	x12, x10, x8
    de58:      	ldr	w23, [sp, #0x68]
    de5c:      	subs	w10, w21, w23
    de60:      	ldr	x9, [sp, #0x88]
    de64:      	csel	w10, wzr, w10, lo
    de68:      	cmp	w23, w21
    de6c:      	csel	w11, w23, w21, lo
    de70:      	cinc	w13, w11, hi
    de74:      	sub	w14, w23, w13
    de78:      	subs	x12, x12, x13
    de7c:      	str	w14, [sp, #0x68]
    de80:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    de84:      	cmp	x12, #0xfff
    de88:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    de8c:      	cmp	w23, w21
    de90:      	b.ls	0xde9c <generic_rawtp_path+0x3bac>
    de94:      	mov	w13, #0x2f              // =47
    de98:      	strb	w13, [x8, x12]
    de9c:      	add	x19, x8, x12
    dea0:      	cmp	w23, w21
    dea4:      	add	x2, x9, x10
    dea8:      	and	w1, w11, #0xff
    deac:      	mov	w8, #0x4                // =4
    deb0:      	cinc	x0, x19, hi
    deb4:      	blr	x8
    deb8:      	cmp	w23, w21
    debc:      	str	x19, [sp, #0x60]
    dec0:      	add	x19, sp, #0x70
    dec4:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    dec8:      	ldr	x21, [sp, #0x78]
    decc:      	ldp	x2, x24, [sp, #0x50]
    ded0:      	str	x21, [sp, #0x48]
    ded4:      	b	0xdf24 <generic_rawtp_path+0x3c34>
    ded8:      	add	x2, x24, #0x10
    dedc:      	mov	w8, #0x4                // =4
    dee0:      	add	x9, sp, #0x98
    dee4:      	add	x0, sp, #0x98
    dee8:      	mov	w1, #0x8                // =8
    deec:      	blr	x8
    def0:      	ldr	x8, [sp, #0x58]
    def4:      	ldr	x9, [sp, #0x98]
    def8:      	cmp	x8, x9
    defc:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    df00:      	add	x2, x24, #0x18
    df04:      	mov	w8, #0x4                // =4
    df08:      	mov	x0, x22
    df0c:      	mov	w1, #0x8                // =8
    df10:      	blr	x8
    df14:      	ldr	x24, [sp, #0x98]
    df18:      	ldr	x21, [sp, #0x48]
    df1c:      	add	x2, x24, #0x20
    df20:      	stp	x2, x24, [sp, #0x50]
    df24:      	ldr	x8, [sp, #0x30]
    df28:      	cmp	x21, x8
    df2c:      	b.ne	0xdf3c <generic_rawtp_path+0x3c4c>
    df30:      	ldr	x8, [sp, #0x38]
    df34:      	cmp	x2, x8
    df38:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    df3c:      	mov	w8, #0x4                // =4
    df40:      	add	x0, sp, #0x70
    df44:      	mov	w1, #0x8                // =8
    df48:      	blr	x8
    df4c:      	ldr	x8, [sp, #0x70]
    df50:      	cmp	x21, x8
    df54:      	b.eq	0xe044 <generic_rawtp_path+0x3d54>
    df58:      	add	x23, x21, #0x18
    df5c:      	mov	w8, #0x4                // =4
    df60:      	add	x9, sp, #0x98
    df64:      	add	x0, sp, #0x98
    df68:      	mov	w1, #0x8                // =8
    df6c:      	mov	x2, x23
    df70:      	blr	x8
    df74:      	ldr	x8, [sp, #0x98]
    df78:      	cmp	x8, x21
    df7c:      	b.eq	0xe044 <generic_rawtp_path+0x3d54>
    df80:      	mov	w8, #0x4                // =4
    df84:      	add	x9, sp, #0x78
    df88:      	add	x0, sp, #0x78
    df8c:      	mov	w1, #0x8                // =8
    df90:      	mov	x2, x23
    df94:      	blr	x8
    df98:      	add	x2, x21, #0x20
    df9c:      	mov	w8, #0x4                // =4
    dfa0:      	mov	w9, #0x10               // =16
    dfa4:      	add	x10, sp, #0x80
    dfa8:      	add	x0, sp, #0x80
    dfac:      	mov	w1, #0x10               // =16
    dfb0:      	blr	x8
    dfb4:      	ldr	w21, [sp, #0x84]
    dfb8:      	ldr	x8, [sp, #0x40]
    dfbc:      	ldr	x10, [sp, #0x60]
    dfc0:      	sub	x12, x10, x8
    dfc4:      	ldr	w23, [sp, #0x68]
    dfc8:      	subs	w10, w21, w23
    dfcc:      	ldr	x9, [sp, #0x88]
    dfd0:      	csel	w10, wzr, w10, lo
    dfd4:      	cmp	w23, w21
    dfd8:      	csel	w11, w23, w21, lo
    dfdc:      	cinc	w13, w11, hi
    dfe0:      	sub	w14, w23, w13
    dfe4:      	subs	x12, x12, x13
    dfe8:      	str	w14, [sp, #0x68]
    dfec:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    dff0:      	cmp	x12, #0xfff
    dff4:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    dff8:      	cmp	w23, w21
    dffc:      	b.ls	0xe008 <generic_rawtp_path+0x3d18>
    e000:      	mov	w13, #0x2f              // =47
    e004:      	strb	w13, [x8, x12]
    e008:      	add	x19, x8, x12
    e00c:      	cmp	w23, w21
    e010:      	add	x2, x9, x10
    e014:      	and	w1, w11, #0xff
    e018:      	mov	w8, #0x4                // =4
    e01c:      	cinc	x0, x19, hi
    e020:      	blr	x8
    e024:      	cmp	w23, w21
    e028:      	str	x19, [sp, #0x60]
    e02c:      	add	x19, sp, #0x70
    e030:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    e034:      	ldr	x21, [sp, #0x78]
    e038:      	ldp	x2, x24, [sp, #0x50]
    e03c:      	str	x21, [sp, #0x48]
    e040:      	b	0xe090 <generic_rawtp_path+0x3da0>
    e044:      	add	x2, x24, #0x10
    e048:      	mov	w8, #0x4                // =4
    e04c:      	add	x9, sp, #0x98
    e050:      	add	x0, sp, #0x98
    e054:      	mov	w1, #0x8                // =8
    e058:      	blr	x8
    e05c:      	ldr	x8, [sp, #0x58]
    e060:      	ldr	x9, [sp, #0x98]
    e064:      	cmp	x8, x9
    e068:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    e06c:      	add	x2, x24, #0x18
    e070:      	mov	w8, #0x4                // =4
    e074:      	mov	x0, x22
    e078:      	mov	w1, #0x8                // =8
    e07c:      	blr	x8
    e080:      	ldr	x24, [sp, #0x98]
    e084:      	ldr	x21, [sp, #0x48]
    e088:      	add	x2, x24, #0x20
    e08c:      	stp	x2, x24, [sp, #0x50]
    e090:      	ldr	x8, [sp, #0x30]
    e094:      	cmp	x21, x8
    e098:      	b.ne	0xe0a8 <generic_rawtp_path+0x3db8>
    e09c:      	ldr	x8, [sp, #0x38]
    e0a0:      	cmp	x2, x8
    e0a4:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    e0a8:      	mov	w8, #0x4                // =4
    e0ac:      	add	x0, sp, #0x70
    e0b0:      	mov	w1, #0x8                // =8
    e0b4:      	blr	x8
    e0b8:      	ldr	x8, [sp, #0x70]
    e0bc:      	cmp	x21, x8
    e0c0:      	b.eq	0xe1b0 <generic_rawtp_path+0x3ec0>
    e0c4:      	add	x23, x21, #0x18
    e0c8:      	mov	w8, #0x4                // =4
    e0cc:      	add	x9, sp, #0x98
    e0d0:      	add	x0, sp, #0x98
    e0d4:      	mov	w1, #0x8                // =8
    e0d8:      	mov	x2, x23
    e0dc:      	blr	x8
    e0e0:      	ldr	x8, [sp, #0x98]
    e0e4:      	cmp	x8, x21
    e0e8:      	b.eq	0xe1b0 <generic_rawtp_path+0x3ec0>
    e0ec:      	mov	w8, #0x4                // =4
    e0f0:      	add	x9, sp, #0x78
    e0f4:      	add	x0, sp, #0x78
    e0f8:      	mov	w1, #0x8                // =8
    e0fc:      	mov	x2, x23
    e100:      	blr	x8
    e104:      	add	x2, x21, #0x20
    e108:      	mov	w8, #0x4                // =4
    e10c:      	mov	w9, #0x10               // =16
    e110:      	add	x10, sp, #0x80
    e114:      	add	x0, sp, #0x80
    e118:      	mov	w1, #0x10               // =16
    e11c:      	blr	x8
    e120:      	ldr	w21, [sp, #0x84]
    e124:      	ldr	x8, [sp, #0x40]
    e128:      	ldr	x10, [sp, #0x60]
    e12c:      	sub	x12, x10, x8
    e130:      	ldr	w23, [sp, #0x68]
    e134:      	subs	w10, w21, w23
    e138:      	ldr	x9, [sp, #0x88]
    e13c:      	csel	w10, wzr, w10, lo
    e140:      	cmp	w23, w21
    e144:      	csel	w11, w23, w21, lo
    e148:      	cinc	w13, w11, hi
    e14c:      	sub	w14, w23, w13
    e150:      	subs	x12, x12, x13
    e154:      	str	w14, [sp, #0x68]
    e158:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    e15c:      	cmp	x12, #0xfff
    e160:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    e164:      	cmp	w23, w21
    e168:      	b.ls	0xe174 <generic_rawtp_path+0x3e84>
    e16c:      	mov	w13, #0x2f              // =47
    e170:      	strb	w13, [x8, x12]
    e174:      	add	x19, x8, x12
    e178:      	cmp	w23, w21
    e17c:      	add	x2, x9, x10
    e180:      	and	w1, w11, #0xff
    e184:      	mov	w8, #0x4                // =4
    e188:      	cinc	x0, x19, hi
    e18c:      	blr	x8
    e190:      	cmp	w23, w21
    e194:      	str	x19, [sp, #0x60]
    e198:      	add	x19, sp, #0x70
    e19c:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    e1a0:      	ldr	x21, [sp, #0x78]
    e1a4:      	ldp	x2, x24, [sp, #0x50]
    e1a8:      	str	x21, [sp, #0x48]
    e1ac:      	b	0xe1fc <generic_rawtp_path+0x3f0c>
    e1b0:      	add	x2, x24, #0x10
    e1b4:      	mov	w8, #0x4                // =4
    e1b8:      	add	x9, sp, #0x98
    e1bc:      	add	x0, sp, #0x98
    e1c0:      	mov	w1, #0x8                // =8
    e1c4:      	blr	x8
    e1c8:      	ldr	x8, [sp, #0x58]
    e1cc:      	ldr	x9, [sp, #0x98]
    e1d0:      	cmp	x8, x9
    e1d4:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    e1d8:      	add	x2, x24, #0x18
    e1dc:      	mov	w8, #0x4                // =4
    e1e0:      	mov	x0, x22
    e1e4:      	mov	w1, #0x8                // =8
    e1e8:      	blr	x8
    e1ec:      	ldr	x24, [sp, #0x98]
    e1f0:      	ldr	x21, [sp, #0x48]
    e1f4:      	add	x2, x24, #0x20
    e1f8:      	stp	x2, x24, [sp, #0x50]
    e1fc:      	ldr	x8, [sp, #0x30]
    e200:      	cmp	x21, x8
    e204:      	b.ne	0xe214 <generic_rawtp_path+0x3f24>
    e208:      	ldr	x8, [sp, #0x38]
    e20c:      	cmp	x2, x8
    e210:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    e214:      	mov	w8, #0x4                // =4
    e218:      	add	x0, sp, #0x70
    e21c:      	mov	w1, #0x8                // =8
    e220:      	blr	x8
    e224:      	ldr	x8, [sp, #0x70]
    e228:      	cmp	x21, x8
    e22c:      	b.eq	0xe31c <generic_rawtp_path+0x402c>
    e230:      	add	x23, x21, #0x18
    e234:      	mov	w8, #0x4                // =4
    e238:      	add	x9, sp, #0x98
    e23c:      	add	x0, sp, #0x98
    e240:      	mov	w1, #0x8                // =8
    e244:      	mov	x2, x23
    e248:      	blr	x8
    e24c:      	ldr	x8, [sp, #0x98]
    e250:      	cmp	x8, x21
    e254:      	b.eq	0xe31c <generic_rawtp_path+0x402c>
    e258:      	mov	w8, #0x4                // =4
    e25c:      	add	x9, sp, #0x78
    e260:      	add	x0, sp, #0x78
    e264:      	mov	w1, #0x8                // =8
    e268:      	mov	x2, x23
    e26c:      	blr	x8
    e270:      	add	x2, x21, #0x20
    e274:      	mov	w8, #0x4                // =4
    e278:      	mov	w9, #0x10               // =16
    e27c:      	add	x10, sp, #0x80
    e280:      	add	x0, sp, #0x80
    e284:      	mov	w1, #0x10               // =16
    e288:      	blr	x8
    e28c:      	ldr	w21, [sp, #0x84]
    e290:      	ldr	x8, [sp, #0x40]
    e294:      	ldr	x10, [sp, #0x60]
    e298:      	sub	x12, x10, x8
    e29c:      	ldr	w23, [sp, #0x68]
    e2a0:      	subs	w10, w21, w23
    e2a4:      	ldr	x9, [sp, #0x88]
    e2a8:      	csel	w10, wzr, w10, lo
    e2ac:      	cmp	w23, w21
    e2b0:      	csel	w11, w23, w21, lo
    e2b4:      	cinc	w13, w11, hi
    e2b8:      	sub	w14, w23, w13
    e2bc:      	subs	x12, x12, x13
    e2c0:      	str	w14, [sp, #0x68]
    e2c4:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    e2c8:      	cmp	x12, #0xfff
    e2cc:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    e2d0:      	cmp	w23, w21
    e2d4:      	b.ls	0xe2e0 <generic_rawtp_path+0x3ff0>
    e2d8:      	mov	w13, #0x2f              // =47
    e2dc:      	strb	w13, [x8, x12]
    e2e0:      	add	x19, x8, x12
    e2e4:      	cmp	w23, w21
    e2e8:      	add	x2, x9, x10
    e2ec:      	and	w1, w11, #0xff
    e2f0:      	mov	w8, #0x4                // =4
    e2f4:      	cinc	x0, x19, hi
    e2f8:      	blr	x8
    e2fc:      	cmp	w23, w21
    e300:      	str	x19, [sp, #0x60]
    e304:      	add	x19, sp, #0x70
    e308:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    e30c:      	ldr	x21, [sp, #0x78]
    e310:      	ldp	x2, x24, [sp, #0x50]
    e314:      	str	x21, [sp, #0x48]
    e318:      	b	0xe368 <generic_rawtp_path+0x4078>
    e31c:      	add	x2, x24, #0x10
    e320:      	mov	w8, #0x4                // =4
    e324:      	add	x9, sp, #0x98
    e328:      	add	x0, sp, #0x98
    e32c:      	mov	w1, #0x8                // =8
    e330:      	blr	x8
    e334:      	ldr	x8, [sp, #0x58]
    e338:      	ldr	x9, [sp, #0x98]
    e33c:      	cmp	x8, x9
    e340:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    e344:      	add	x2, x24, #0x18
    e348:      	mov	w8, #0x4                // =4
    e34c:      	mov	x0, x22
    e350:      	mov	w1, #0x8                // =8
    e354:      	blr	x8
    e358:      	ldr	x24, [sp, #0x98]
    e35c:      	ldr	x21, [sp, #0x48]
    e360:      	add	x2, x24, #0x20
    e364:      	stp	x2, x24, [sp, #0x50]
    e368:      	ldr	x8, [sp, #0x30]
    e36c:      	cmp	x21, x8
    e370:      	b.ne	0xe380 <generic_rawtp_path+0x4090>
    e374:      	ldr	x8, [sp, #0x38]
    e378:      	cmp	x2, x8
    e37c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    e380:      	mov	w8, #0x4                // =4
    e384:      	add	x0, sp, #0x70
    e388:      	mov	w1, #0x8                // =8
    e38c:      	blr	x8
    e390:      	ldr	x8, [sp, #0x70]
    e394:      	cmp	x21, x8
    e398:      	b.eq	0xe488 <generic_rawtp_path+0x4198>
    e39c:      	add	x23, x21, #0x18
    e3a0:      	mov	w8, #0x4                // =4
    e3a4:      	add	x9, sp, #0x98
    e3a8:      	add	x0, sp, #0x98
    e3ac:      	mov	w1, #0x8                // =8
    e3b0:      	mov	x2, x23
    e3b4:      	blr	x8
    e3b8:      	ldr	x8, [sp, #0x98]
    e3bc:      	cmp	x8, x21
    e3c0:      	b.eq	0xe488 <generic_rawtp_path+0x4198>
    e3c4:      	mov	w8, #0x4                // =4
    e3c8:      	add	x9, sp, #0x78
    e3cc:      	add	x0, sp, #0x78
    e3d0:      	mov	w1, #0x8                // =8
    e3d4:      	mov	x2, x23
    e3d8:      	blr	x8
    e3dc:      	add	x2, x21, #0x20
    e3e0:      	mov	w8, #0x4                // =4
    e3e4:      	mov	w9, #0x10               // =16
    e3e8:      	add	x10, sp, #0x80
    e3ec:      	add	x0, sp, #0x80
    e3f0:      	mov	w1, #0x10               // =16
    e3f4:      	blr	x8
    e3f8:      	ldr	w21, [sp, #0x84]
    e3fc:      	ldr	x8, [sp, #0x40]
    e400:      	ldr	x10, [sp, #0x60]
    e404:      	sub	x12, x10, x8
    e408:      	ldr	w23, [sp, #0x68]
    e40c:      	subs	w10, w21, w23
    e410:      	ldr	x9, [sp, #0x88]
    e414:      	csel	w10, wzr, w10, lo
    e418:      	cmp	w23, w21
    e41c:      	csel	w11, w23, w21, lo
    e420:      	cinc	w13, w11, hi
    e424:      	sub	w14, w23, w13
    e428:      	subs	x12, x12, x13
    e42c:      	str	w14, [sp, #0x68]
    e430:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    e434:      	cmp	x12, #0xfff
    e438:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    e43c:      	cmp	w23, w21
    e440:      	b.ls	0xe44c <generic_rawtp_path+0x415c>
    e444:      	mov	w13, #0x2f              // =47
    e448:      	strb	w13, [x8, x12]
    e44c:      	add	x19, x8, x12
    e450:      	cmp	w23, w21
    e454:      	add	x2, x9, x10
    e458:      	and	w1, w11, #0xff
    e45c:      	mov	w8, #0x4                // =4
    e460:      	cinc	x0, x19, hi
    e464:      	blr	x8
    e468:      	cmp	w23, w21
    e46c:      	str	x19, [sp, #0x60]
    e470:      	add	x19, sp, #0x70
    e474:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    e478:      	ldr	x21, [sp, #0x78]
    e47c:      	ldp	x2, x24, [sp, #0x50]
    e480:      	str	x21, [sp, #0x48]
    e484:      	b	0xe4d4 <generic_rawtp_path+0x41e4>
    e488:      	add	x2, x24, #0x10
    e48c:      	mov	w8, #0x4                // =4
    e490:      	add	x9, sp, #0x98
    e494:      	add	x0, sp, #0x98
    e498:      	mov	w1, #0x8                // =8
    e49c:      	blr	x8
    e4a0:      	ldr	x8, [sp, #0x58]
    e4a4:      	ldr	x9, [sp, #0x98]
    e4a8:      	cmp	x8, x9
    e4ac:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    e4b0:      	add	x2, x24, #0x18
    e4b4:      	mov	w8, #0x4                // =4
    e4b8:      	mov	x0, x22
    e4bc:      	mov	w1, #0x8                // =8
    e4c0:      	blr	x8
    e4c4:      	ldr	x24, [sp, #0x98]
    e4c8:      	ldr	x21, [sp, #0x48]
    e4cc:      	add	x2, x24, #0x20
    e4d0:      	stp	x2, x24, [sp, #0x50]
    e4d4:      	ldr	x8, [sp, #0x30]
    e4d8:      	cmp	x21, x8
    e4dc:      	b.ne	0xe4ec <generic_rawtp_path+0x41fc>
    e4e0:      	ldr	x8, [sp, #0x38]
    e4e4:      	cmp	x2, x8
    e4e8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    e4ec:      	mov	w8, #0x4                // =4
    e4f0:      	add	x0, sp, #0x70
    e4f4:      	mov	w1, #0x8                // =8
    e4f8:      	blr	x8
    e4fc:      	ldr	x8, [sp, #0x70]
    e500:      	cmp	x21, x8
    e504:      	b.eq	0xe5f4 <generic_rawtp_path+0x4304>
    e508:      	add	x23, x21, #0x18
    e50c:      	mov	w8, #0x4                // =4
    e510:      	add	x9, sp, #0x98
    e514:      	add	x0, sp, #0x98
    e518:      	mov	w1, #0x8                // =8
    e51c:      	mov	x2, x23
    e520:      	blr	x8
    e524:      	ldr	x8, [sp, #0x98]
    e528:      	cmp	x8, x21
    e52c:      	b.eq	0xe5f4 <generic_rawtp_path+0x4304>
    e530:      	mov	w8, #0x4                // =4
    e534:      	add	x9, sp, #0x78
    e538:      	add	x0, sp, #0x78
    e53c:      	mov	w1, #0x8                // =8
    e540:      	mov	x2, x23
    e544:      	blr	x8
    e548:      	add	x2, x21, #0x20
    e54c:      	mov	w8, #0x4                // =4
    e550:      	mov	w9, #0x10               // =16
    e554:      	add	x10, sp, #0x80
    e558:      	add	x0, sp, #0x80
    e55c:      	mov	w1, #0x10               // =16
    e560:      	blr	x8
    e564:      	ldr	w21, [sp, #0x84]
    e568:      	ldr	x8, [sp, #0x40]
    e56c:      	ldr	x10, [sp, #0x60]
    e570:      	sub	x12, x10, x8
    e574:      	ldr	w23, [sp, #0x68]
    e578:      	subs	w10, w21, w23
    e57c:      	ldr	x9, [sp, #0x88]
    e580:      	csel	w10, wzr, w10, lo
    e584:      	cmp	w23, w21
    e588:      	csel	w11, w23, w21, lo
    e58c:      	cinc	w13, w11, hi
    e590:      	sub	w14, w23, w13
    e594:      	subs	x12, x12, x13
    e598:      	str	w14, [sp, #0x68]
    e59c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    e5a0:      	cmp	x12, #0xfff
    e5a4:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    e5a8:      	cmp	w23, w21
    e5ac:      	b.ls	0xe5b8 <generic_rawtp_path+0x42c8>
    e5b0:      	mov	w13, #0x2f              // =47
    e5b4:      	strb	w13, [x8, x12]
    e5b8:      	add	x19, x8, x12
    e5bc:      	cmp	w23, w21
    e5c0:      	add	x2, x9, x10
    e5c4:      	and	w1, w11, #0xff
    e5c8:      	mov	w8, #0x4                // =4
    e5cc:      	cinc	x0, x19, hi
    e5d0:      	blr	x8
    e5d4:      	cmp	w23, w21
    e5d8:      	str	x19, [sp, #0x60]
    e5dc:      	add	x19, sp, #0x70
    e5e0:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    e5e4:      	ldr	x21, [sp, #0x78]
    e5e8:      	ldp	x2, x24, [sp, #0x50]
    e5ec:      	str	x21, [sp, #0x48]
    e5f0:      	b	0xe640 <generic_rawtp_path+0x4350>
    e5f4:      	add	x2, x24, #0x10
    e5f8:      	mov	w8, #0x4                // =4
    e5fc:      	add	x9, sp, #0x98
    e600:      	add	x0, sp, #0x98
    e604:      	mov	w1, #0x8                // =8
    e608:      	blr	x8
    e60c:      	ldr	x8, [sp, #0x58]
    e610:      	ldr	x9, [sp, #0x98]
    e614:      	cmp	x8, x9
    e618:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    e61c:      	add	x2, x24, #0x18
    e620:      	mov	w8, #0x4                // =4
    e624:      	mov	x0, x22
    e628:      	mov	w1, #0x8                // =8
    e62c:      	blr	x8
    e630:      	ldr	x24, [sp, #0x98]
    e634:      	ldr	x21, [sp, #0x48]
    e638:      	add	x2, x24, #0x20
    e63c:      	stp	x2, x24, [sp, #0x50]
    e640:      	ldr	x8, [sp, #0x30]
    e644:      	cmp	x21, x8
    e648:      	b.ne	0xe658 <generic_rawtp_path+0x4368>
    e64c:      	ldr	x8, [sp, #0x38]
    e650:      	cmp	x2, x8
    e654:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    e658:      	mov	w8, #0x4                // =4
    e65c:      	add	x0, sp, #0x70
    e660:      	mov	w1, #0x8                // =8
    e664:      	blr	x8
    e668:      	ldr	x8, [sp, #0x70]
    e66c:      	cmp	x21, x8
    e670:      	b.eq	0xe760 <generic_rawtp_path+0x4470>
    e674:      	add	x23, x21, #0x18
    e678:      	mov	w8, #0x4                // =4
    e67c:      	add	x9, sp, #0x98
    e680:      	add	x0, sp, #0x98
    e684:      	mov	w1, #0x8                // =8
    e688:      	mov	x2, x23
    e68c:      	blr	x8
    e690:      	ldr	x8, [sp, #0x98]
    e694:      	cmp	x8, x21
    e698:      	b.eq	0xe760 <generic_rawtp_path+0x4470>
    e69c:      	mov	w8, #0x4                // =4
    e6a0:      	add	x9, sp, #0x78
    e6a4:      	add	x0, sp, #0x78
    e6a8:      	mov	w1, #0x8                // =8
    e6ac:      	mov	x2, x23
    e6b0:      	blr	x8
    e6b4:      	add	x2, x21, #0x20
    e6b8:      	mov	w8, #0x4                // =4
    e6bc:      	mov	w9, #0x10               // =16
    e6c0:      	add	x10, sp, #0x80
    e6c4:      	add	x0, sp, #0x80
    e6c8:      	mov	w1, #0x10               // =16
    e6cc:      	blr	x8
    e6d0:      	ldr	w21, [sp, #0x84]
    e6d4:      	ldr	x8, [sp, #0x40]
    e6d8:      	ldr	x10, [sp, #0x60]
    e6dc:      	sub	x12, x10, x8
    e6e0:      	ldr	w23, [sp, #0x68]
    e6e4:      	subs	w10, w21, w23
    e6e8:      	ldr	x9, [sp, #0x88]
    e6ec:      	csel	w10, wzr, w10, lo
    e6f0:      	cmp	w23, w21
    e6f4:      	csel	w11, w23, w21, lo
    e6f8:      	cinc	w13, w11, hi
    e6fc:      	sub	w14, w23, w13
    e700:      	subs	x12, x12, x13
    e704:      	str	w14, [sp, #0x68]
    e708:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    e70c:      	cmp	x12, #0xfff
    e710:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    e714:      	cmp	w23, w21
    e718:      	b.ls	0xe724 <generic_rawtp_path+0x4434>
    e71c:      	mov	w13, #0x2f              // =47
    e720:      	strb	w13, [x8, x12]
    e724:      	add	x19, x8, x12
    e728:      	cmp	w23, w21
    e72c:      	add	x2, x9, x10
    e730:      	and	w1, w11, #0xff
    e734:      	mov	w8, #0x4                // =4
    e738:      	cinc	x0, x19, hi
    e73c:      	blr	x8
    e740:      	cmp	w23, w21
    e744:      	str	x19, [sp, #0x60]
    e748:      	add	x19, sp, #0x70
    e74c:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    e750:      	ldr	x21, [sp, #0x78]
    e754:      	ldp	x2, x24, [sp, #0x50]
    e758:      	str	x21, [sp, #0x48]
    e75c:      	b	0xe7ac <generic_rawtp_path+0x44bc>
    e760:      	add	x2, x24, #0x10
    e764:      	mov	w8, #0x4                // =4
    e768:      	add	x9, sp, #0x98
    e76c:      	add	x0, sp, #0x98
    e770:      	mov	w1, #0x8                // =8
    e774:      	blr	x8
    e778:      	ldr	x8, [sp, #0x58]
    e77c:      	ldr	x9, [sp, #0x98]
    e780:      	cmp	x8, x9
    e784:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    e788:      	add	x2, x24, #0x18
    e78c:      	mov	w8, #0x4                // =4
    e790:      	mov	x0, x22
    e794:      	mov	w1, #0x8                // =8
    e798:      	blr	x8
    e79c:      	ldr	x24, [sp, #0x98]
    e7a0:      	ldr	x21, [sp, #0x48]
    e7a4:      	add	x2, x24, #0x20
    e7a8:      	stp	x2, x24, [sp, #0x50]
    e7ac:      	ldr	x8, [sp, #0x30]
    e7b0:      	cmp	x21, x8
    e7b4:      	b.ne	0xe7c4 <generic_rawtp_path+0x44d4>
    e7b8:      	ldr	x8, [sp, #0x38]
    e7bc:      	cmp	x2, x8
    e7c0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    e7c4:      	mov	w8, #0x4                // =4
    e7c8:      	add	x0, sp, #0x70
    e7cc:      	mov	w1, #0x8                // =8
    e7d0:      	blr	x8
    e7d4:      	ldr	x8, [sp, #0x70]
    e7d8:      	cmp	x21, x8
    e7dc:      	b.eq	0xe8cc <generic_rawtp_path+0x45dc>
    e7e0:      	add	x23, x21, #0x18
    e7e4:      	mov	w8, #0x4                // =4
    e7e8:      	add	x9, sp, #0x98
    e7ec:      	add	x0, sp, #0x98
    e7f0:      	mov	w1, #0x8                // =8
    e7f4:      	mov	x2, x23
    e7f8:      	blr	x8
    e7fc:      	ldr	x8, [sp, #0x98]
    e800:      	cmp	x8, x21
    e804:      	b.eq	0xe8cc <generic_rawtp_path+0x45dc>
    e808:      	mov	w8, #0x4                // =4
    e80c:      	add	x9, sp, #0x78
    e810:      	add	x0, sp, #0x78
    e814:      	mov	w1, #0x8                // =8
    e818:      	mov	x2, x23
    e81c:      	blr	x8
    e820:      	add	x2, x21, #0x20
    e824:      	mov	w8, #0x4                // =4
    e828:      	mov	w9, #0x10               // =16
    e82c:      	add	x10, sp, #0x80
    e830:      	add	x0, sp, #0x80
    e834:      	mov	w1, #0x10               // =16
    e838:      	blr	x8
    e83c:      	ldr	w21, [sp, #0x84]
    e840:      	ldr	x8, [sp, #0x40]
    e844:      	ldr	x10, [sp, #0x60]
    e848:      	sub	x12, x10, x8
    e84c:      	ldr	w23, [sp, #0x68]
    e850:      	subs	w10, w21, w23
    e854:      	ldr	x9, [sp, #0x88]
    e858:      	csel	w10, wzr, w10, lo
    e85c:      	cmp	w23, w21
    e860:      	csel	w11, w23, w21, lo
    e864:      	cinc	w13, w11, hi
    e868:      	sub	w14, w23, w13
    e86c:      	subs	x12, x12, x13
    e870:      	str	w14, [sp, #0x68]
    e874:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    e878:      	cmp	x12, #0xfff
    e87c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    e880:      	cmp	w23, w21
    e884:      	b.ls	0xe890 <generic_rawtp_path+0x45a0>
    e888:      	mov	w13, #0x2f              // =47
    e88c:      	strb	w13, [x8, x12]
    e890:      	add	x19, x8, x12
    e894:      	cmp	w23, w21
    e898:      	add	x2, x9, x10
    e89c:      	and	w1, w11, #0xff
    e8a0:      	mov	w8, #0x4                // =4
    e8a4:      	cinc	x0, x19, hi
    e8a8:      	blr	x8
    e8ac:      	cmp	w23, w21
    e8b0:      	str	x19, [sp, #0x60]
    e8b4:      	add	x19, sp, #0x70
    e8b8:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    e8bc:      	ldr	x21, [sp, #0x78]
    e8c0:      	ldp	x2, x24, [sp, #0x50]
    e8c4:      	str	x21, [sp, #0x48]
    e8c8:      	b	0xe918 <generic_rawtp_path+0x4628>
    e8cc:      	add	x2, x24, #0x10
    e8d0:      	mov	w8, #0x4                // =4
    e8d4:      	add	x9, sp, #0x98
    e8d8:      	add	x0, sp, #0x98
    e8dc:      	mov	w1, #0x8                // =8
    e8e0:      	blr	x8
    e8e4:      	ldr	x8, [sp, #0x58]
    e8e8:      	ldr	x9, [sp, #0x98]
    e8ec:      	cmp	x8, x9
    e8f0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    e8f4:      	add	x2, x24, #0x18
    e8f8:      	mov	w8, #0x4                // =4
    e8fc:      	mov	x0, x22
    e900:      	mov	w1, #0x8                // =8
    e904:      	blr	x8
    e908:      	ldr	x24, [sp, #0x98]
    e90c:      	ldr	x21, [sp, #0x48]
    e910:      	add	x2, x24, #0x20
    e914:      	stp	x2, x24, [sp, #0x50]
    e918:      	ldr	x8, [sp, #0x30]
    e91c:      	cmp	x21, x8
    e920:      	b.ne	0xe930 <generic_rawtp_path+0x4640>
    e924:      	ldr	x8, [sp, #0x38]
    e928:      	cmp	x2, x8
    e92c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    e930:      	mov	w8, #0x4                // =4
    e934:      	add	x0, sp, #0x70
    e938:      	mov	w1, #0x8                // =8
    e93c:      	blr	x8
    e940:      	ldr	x8, [sp, #0x70]
    e944:      	cmp	x21, x8
    e948:      	b.eq	0xea38 <generic_rawtp_path+0x4748>
    e94c:      	add	x23, x21, #0x18
    e950:      	mov	w8, #0x4                // =4
    e954:      	add	x9, sp, #0x98
    e958:      	add	x0, sp, #0x98
    e95c:      	mov	w1, #0x8                // =8
    e960:      	mov	x2, x23
    e964:      	blr	x8
    e968:      	ldr	x8, [sp, #0x98]
    e96c:      	cmp	x8, x21
    e970:      	b.eq	0xea38 <generic_rawtp_path+0x4748>
    e974:      	mov	w8, #0x4                // =4
    e978:      	add	x9, sp, #0x78
    e97c:      	add	x0, sp, #0x78
    e980:      	mov	w1, #0x8                // =8
    e984:      	mov	x2, x23
    e988:      	blr	x8
    e98c:      	add	x2, x21, #0x20
    e990:      	mov	w8, #0x4                // =4
    e994:      	mov	w9, #0x10               // =16
    e998:      	add	x10, sp, #0x80
    e99c:      	add	x0, sp, #0x80
    e9a0:      	mov	w1, #0x10               // =16
    e9a4:      	blr	x8
    e9a8:      	ldr	w21, [sp, #0x84]
    e9ac:      	ldr	x8, [sp, #0x40]
    e9b0:      	ldr	x10, [sp, #0x60]
    e9b4:      	sub	x12, x10, x8
    e9b8:      	ldr	w23, [sp, #0x68]
    e9bc:      	subs	w10, w21, w23
    e9c0:      	ldr	x9, [sp, #0x88]
    e9c4:      	csel	w10, wzr, w10, lo
    e9c8:      	cmp	w23, w21
    e9cc:      	csel	w11, w23, w21, lo
    e9d0:      	cinc	w13, w11, hi
    e9d4:      	sub	w14, w23, w13
    e9d8:      	subs	x12, x12, x13
    e9dc:      	str	w14, [sp, #0x68]
    e9e0:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    e9e4:      	cmp	x12, #0xfff
    e9e8:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    e9ec:      	cmp	w23, w21
    e9f0:      	b.ls	0xe9fc <generic_rawtp_path+0x470c>
    e9f4:      	mov	w13, #0x2f              // =47
    e9f8:      	strb	w13, [x8, x12]
    e9fc:      	add	x19, x8, x12
    ea00:      	cmp	w23, w21
    ea04:      	add	x2, x9, x10
    ea08:      	and	w1, w11, #0xff
    ea0c:      	mov	w8, #0x4                // =4
    ea10:      	cinc	x0, x19, hi
    ea14:      	blr	x8
    ea18:      	cmp	w23, w21
    ea1c:      	str	x19, [sp, #0x60]
    ea20:      	add	x19, sp, #0x70
    ea24:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    ea28:      	ldr	x21, [sp, #0x78]
    ea2c:      	ldp	x2, x24, [sp, #0x50]
    ea30:      	str	x21, [sp, #0x48]
    ea34:      	b	0xea84 <generic_rawtp_path+0x4794>
    ea38:      	add	x2, x24, #0x10
    ea3c:      	mov	w8, #0x4                // =4
    ea40:      	add	x9, sp, #0x98
    ea44:      	add	x0, sp, #0x98
    ea48:      	mov	w1, #0x8                // =8
    ea4c:      	blr	x8
    ea50:      	ldr	x8, [sp, #0x58]
    ea54:      	ldr	x9, [sp, #0x98]
    ea58:      	cmp	x8, x9
    ea5c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    ea60:      	add	x2, x24, #0x18
    ea64:      	mov	w8, #0x4                // =4
    ea68:      	mov	x0, x22
    ea6c:      	mov	w1, #0x8                // =8
    ea70:      	blr	x8
    ea74:      	ldr	x24, [sp, #0x98]
    ea78:      	ldr	x21, [sp, #0x48]
    ea7c:      	add	x2, x24, #0x20
    ea80:      	stp	x2, x24, [sp, #0x50]
    ea84:      	ldr	x8, [sp, #0x30]
    ea88:      	cmp	x21, x8
    ea8c:      	b.ne	0xea9c <generic_rawtp_path+0x47ac>
    ea90:      	ldr	x8, [sp, #0x38]
    ea94:      	cmp	x2, x8
    ea98:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    ea9c:      	mov	w8, #0x4                // =4
    eaa0:      	add	x0, sp, #0x70
    eaa4:      	mov	w1, #0x8                // =8
    eaa8:      	blr	x8
    eaac:      	ldr	x8, [sp, #0x70]
    eab0:      	cmp	x21, x8
    eab4:      	b.eq	0xeba4 <generic_rawtp_path+0x48b4>
    eab8:      	add	x23, x21, #0x18
    eabc:      	mov	w8, #0x4                // =4
    eac0:      	add	x9, sp, #0x98
    eac4:      	add	x0, sp, #0x98
    eac8:      	mov	w1, #0x8                // =8
    eacc:      	mov	x2, x23
    ead0:      	blr	x8
    ead4:      	ldr	x8, [sp, #0x98]
    ead8:      	cmp	x8, x21
    eadc:      	b.eq	0xeba4 <generic_rawtp_path+0x48b4>
    eae0:      	mov	w8, #0x4                // =4
    eae4:      	add	x9, sp, #0x78
    eae8:      	add	x0, sp, #0x78
    eaec:      	mov	w1, #0x8                // =8
    eaf0:      	mov	x2, x23
    eaf4:      	blr	x8
    eaf8:      	add	x2, x21, #0x20
    eafc:      	mov	w8, #0x4                // =4
    eb00:      	mov	w9, #0x10               // =16
    eb04:      	add	x10, sp, #0x80
    eb08:      	add	x0, sp, #0x80
    eb0c:      	mov	w1, #0x10               // =16
    eb10:      	blr	x8
    eb14:      	ldr	w21, [sp, #0x84]
    eb18:      	ldr	x8, [sp, #0x40]
    eb1c:      	ldr	x10, [sp, #0x60]
    eb20:      	sub	x12, x10, x8
    eb24:      	ldr	w23, [sp, #0x68]
    eb28:      	subs	w10, w21, w23
    eb2c:      	ldr	x9, [sp, #0x88]
    eb30:      	csel	w10, wzr, w10, lo
    eb34:      	cmp	w23, w21
    eb38:      	csel	w11, w23, w21, lo
    eb3c:      	cinc	w13, w11, hi
    eb40:      	sub	w14, w23, w13
    eb44:      	subs	x12, x12, x13
    eb48:      	str	w14, [sp, #0x68]
    eb4c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    eb50:      	cmp	x12, #0xfff
    eb54:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    eb58:      	cmp	w23, w21
    eb5c:      	b.ls	0xeb68 <generic_rawtp_path+0x4878>
    eb60:      	mov	w13, #0x2f              // =47
    eb64:      	strb	w13, [x8, x12]
    eb68:      	add	x19, x8, x12
    eb6c:      	cmp	w23, w21
    eb70:      	add	x2, x9, x10
    eb74:      	and	w1, w11, #0xff
    eb78:      	mov	w8, #0x4                // =4
    eb7c:      	cinc	x0, x19, hi
    eb80:      	blr	x8
    eb84:      	cmp	w23, w21
    eb88:      	str	x19, [sp, #0x60]
    eb8c:      	add	x19, sp, #0x70
    eb90:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    eb94:      	ldr	x21, [sp, #0x78]
    eb98:      	ldp	x2, x24, [sp, #0x50]
    eb9c:      	str	x21, [sp, #0x48]
    eba0:      	b	0xebf0 <generic_rawtp_path+0x4900>
    eba4:      	add	x2, x24, #0x10
    eba8:      	mov	w8, #0x4                // =4
    ebac:      	add	x9, sp, #0x98
    ebb0:      	add	x0, sp, #0x98
    ebb4:      	mov	w1, #0x8                // =8
    ebb8:      	blr	x8
    ebbc:      	ldr	x8, [sp, #0x58]
    ebc0:      	ldr	x9, [sp, #0x98]
    ebc4:      	cmp	x8, x9
    ebc8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    ebcc:      	add	x2, x24, #0x18
    ebd0:      	mov	w8, #0x4                // =4
    ebd4:      	mov	x0, x22
    ebd8:      	mov	w1, #0x8                // =8
    ebdc:      	blr	x8
    ebe0:      	ldr	x24, [sp, #0x98]
    ebe4:      	ldr	x21, [sp, #0x48]
    ebe8:      	add	x2, x24, #0x20
    ebec:      	stp	x2, x24, [sp, #0x50]
    ebf0:      	ldr	x8, [sp, #0x30]
    ebf4:      	cmp	x21, x8
    ebf8:      	b.ne	0xec08 <generic_rawtp_path+0x4918>
    ebfc:      	ldr	x8, [sp, #0x38]
    ec00:      	cmp	x2, x8
    ec04:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    ec08:      	mov	w8, #0x4                // =4
    ec0c:      	add	x0, sp, #0x70
    ec10:      	mov	w1, #0x8                // =8
    ec14:      	blr	x8
    ec18:      	ldr	x8, [sp, #0x70]
    ec1c:      	cmp	x21, x8
    ec20:      	b.eq	0xed10 <generic_rawtp_path+0x4a20>
    ec24:      	add	x23, x21, #0x18
    ec28:      	mov	w8, #0x4                // =4
    ec2c:      	add	x9, sp, #0x98
    ec30:      	add	x0, sp, #0x98
    ec34:      	mov	w1, #0x8                // =8
    ec38:      	mov	x2, x23
    ec3c:      	blr	x8
    ec40:      	ldr	x8, [sp, #0x98]
    ec44:      	cmp	x8, x21
    ec48:      	b.eq	0xed10 <generic_rawtp_path+0x4a20>
    ec4c:      	mov	w8, #0x4                // =4
    ec50:      	add	x9, sp, #0x78
    ec54:      	add	x0, sp, #0x78
    ec58:      	mov	w1, #0x8                // =8
    ec5c:      	mov	x2, x23
    ec60:      	blr	x8
    ec64:      	add	x2, x21, #0x20
    ec68:      	mov	w8, #0x4                // =4
    ec6c:      	mov	w9, #0x10               // =16
    ec70:      	add	x10, sp, #0x80
    ec74:      	add	x0, sp, #0x80
    ec78:      	mov	w1, #0x10               // =16
    ec7c:      	blr	x8
    ec80:      	ldr	w21, [sp, #0x84]
    ec84:      	ldr	x8, [sp, #0x40]
    ec88:      	ldr	x10, [sp, #0x60]
    ec8c:      	sub	x12, x10, x8
    ec90:      	ldr	w23, [sp, #0x68]
    ec94:      	subs	w10, w21, w23
    ec98:      	ldr	x9, [sp, #0x88]
    ec9c:      	csel	w10, wzr, w10, lo
    eca0:      	cmp	w23, w21
    eca4:      	csel	w11, w23, w21, lo
    eca8:      	cinc	w13, w11, hi
    ecac:      	sub	w14, w23, w13
    ecb0:      	subs	x12, x12, x13
    ecb4:      	str	w14, [sp, #0x68]
    ecb8:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    ecbc:      	cmp	x12, #0xfff
    ecc0:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    ecc4:      	cmp	w23, w21
    ecc8:      	b.ls	0xecd4 <generic_rawtp_path+0x49e4>
    eccc:      	mov	w13, #0x2f              // =47
    ecd0:      	strb	w13, [x8, x12]
    ecd4:      	add	x19, x8, x12
    ecd8:      	cmp	w23, w21
    ecdc:      	add	x2, x9, x10
    ece0:      	and	w1, w11, #0xff
    ece4:      	mov	w8, #0x4                // =4
    ece8:      	cinc	x0, x19, hi
    ecec:      	blr	x8
    ecf0:      	cmp	w23, w21
    ecf4:      	str	x19, [sp, #0x60]
    ecf8:      	add	x19, sp, #0x70
    ecfc:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    ed00:      	ldr	x21, [sp, #0x78]
    ed04:      	ldp	x2, x24, [sp, #0x50]
    ed08:      	str	x21, [sp, #0x48]
    ed0c:      	b	0xed5c <generic_rawtp_path+0x4a6c>
    ed10:      	add	x2, x24, #0x10
    ed14:      	mov	w8, #0x4                // =4
    ed18:      	add	x9, sp, #0x98
    ed1c:      	add	x0, sp, #0x98
    ed20:      	mov	w1, #0x8                // =8
    ed24:      	blr	x8
    ed28:      	ldr	x8, [sp, #0x58]
    ed2c:      	ldr	x9, [sp, #0x98]
    ed30:      	cmp	x8, x9
    ed34:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    ed38:      	add	x2, x24, #0x18
    ed3c:      	mov	w8, #0x4                // =4
    ed40:      	mov	x0, x22
    ed44:      	mov	w1, #0x8                // =8
    ed48:      	blr	x8
    ed4c:      	ldr	x24, [sp, #0x98]
    ed50:      	ldr	x21, [sp, #0x48]
    ed54:      	add	x2, x24, #0x20
    ed58:      	stp	x2, x24, [sp, #0x50]
    ed5c:      	ldr	x8, [sp, #0x30]
    ed60:      	cmp	x21, x8
    ed64:      	b.ne	0xed74 <generic_rawtp_path+0x4a84>
    ed68:      	ldr	x8, [sp, #0x38]
    ed6c:      	cmp	x2, x8
    ed70:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    ed74:      	mov	w8, #0x4                // =4
    ed78:      	add	x0, sp, #0x70
    ed7c:      	mov	w1, #0x8                // =8
    ed80:      	blr	x8
    ed84:      	ldr	x8, [sp, #0x70]
    ed88:      	cmp	x21, x8
    ed8c:      	b.eq	0xee7c <generic_rawtp_path+0x4b8c>
    ed90:      	add	x23, x21, #0x18
    ed94:      	mov	w8, #0x4                // =4
    ed98:      	add	x9, sp, #0x98
    ed9c:      	add	x0, sp, #0x98
    eda0:      	mov	w1, #0x8                // =8
    eda4:      	mov	x2, x23
    eda8:      	blr	x8
    edac:      	ldr	x8, [sp, #0x98]
    edb0:      	cmp	x8, x21
    edb4:      	b.eq	0xee7c <generic_rawtp_path+0x4b8c>
    edb8:      	mov	w8, #0x4                // =4
    edbc:      	add	x9, sp, #0x78
    edc0:      	add	x0, sp, #0x78
    edc4:      	mov	w1, #0x8                // =8
    edc8:      	mov	x2, x23
    edcc:      	blr	x8
    edd0:      	add	x2, x21, #0x20
    edd4:      	mov	w8, #0x4                // =4
    edd8:      	mov	w9, #0x10               // =16
    eddc:      	add	x10, sp, #0x80
    ede0:      	add	x0, sp, #0x80
    ede4:      	mov	w1, #0x10               // =16
    ede8:      	blr	x8
    edec:      	ldr	w21, [sp, #0x84]
    edf0:      	ldr	x8, [sp, #0x40]
    edf4:      	ldr	x10, [sp, #0x60]
    edf8:      	sub	x12, x10, x8
    edfc:      	ldr	w23, [sp, #0x68]
    ee00:      	subs	w10, w21, w23
    ee04:      	ldr	x9, [sp, #0x88]
    ee08:      	csel	w10, wzr, w10, lo
    ee0c:      	cmp	w23, w21
    ee10:      	csel	w11, w23, w21, lo
    ee14:      	cinc	w13, w11, hi
    ee18:      	sub	w14, w23, w13
    ee1c:      	subs	x12, x12, x13
    ee20:      	str	w14, [sp, #0x68]
    ee24:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    ee28:      	cmp	x12, #0xfff
    ee2c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    ee30:      	cmp	w23, w21
    ee34:      	b.ls	0xee40 <generic_rawtp_path+0x4b50>
    ee38:      	mov	w13, #0x2f              // =47
    ee3c:      	strb	w13, [x8, x12]
    ee40:      	add	x19, x8, x12
    ee44:      	cmp	w23, w21
    ee48:      	add	x2, x9, x10
    ee4c:      	and	w1, w11, #0xff
    ee50:      	mov	w8, #0x4                // =4
    ee54:      	cinc	x0, x19, hi
    ee58:      	blr	x8
    ee5c:      	cmp	w23, w21
    ee60:      	str	x19, [sp, #0x60]
    ee64:      	add	x19, sp, #0x70
    ee68:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    ee6c:      	ldr	x21, [sp, #0x78]
    ee70:      	ldp	x2, x24, [sp, #0x50]
    ee74:      	str	x21, [sp, #0x48]
    ee78:      	b	0xeec8 <generic_rawtp_path+0x4bd8>
    ee7c:      	add	x2, x24, #0x10
    ee80:      	mov	w8, #0x4                // =4
    ee84:      	add	x9, sp, #0x98
    ee88:      	add	x0, sp, #0x98
    ee8c:      	mov	w1, #0x8                // =8
    ee90:      	blr	x8
    ee94:      	ldr	x8, [sp, #0x58]
    ee98:      	ldr	x9, [sp, #0x98]
    ee9c:      	cmp	x8, x9
    eea0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    eea4:      	add	x2, x24, #0x18
    eea8:      	mov	w8, #0x4                // =4
    eeac:      	mov	x0, x22
    eeb0:      	mov	w1, #0x8                // =8
    eeb4:      	blr	x8
    eeb8:      	ldr	x24, [sp, #0x98]
    eebc:      	ldr	x21, [sp, #0x48]
    eec0:      	add	x2, x24, #0x20
    eec4:      	stp	x2, x24, [sp, #0x50]
    eec8:      	ldr	x8, [sp, #0x30]
    eecc:      	cmp	x21, x8
    eed0:      	b.ne	0xeee0 <generic_rawtp_path+0x4bf0>
    eed4:      	ldr	x8, [sp, #0x38]
    eed8:      	cmp	x2, x8
    eedc:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    eee0:      	mov	w8, #0x4                // =4
    eee4:      	add	x0, sp, #0x70
    eee8:      	mov	w1, #0x8                // =8
    eeec:      	blr	x8
    eef0:      	ldr	x8, [sp, #0x70]
    eef4:      	cmp	x21, x8
    eef8:      	b.eq	0xefe8 <generic_rawtp_path+0x4cf8>
    eefc:      	add	x23, x21, #0x18
    ef00:      	mov	w8, #0x4                // =4
    ef04:      	add	x9, sp, #0x98
    ef08:      	add	x0, sp, #0x98
    ef0c:      	mov	w1, #0x8                // =8
    ef10:      	mov	x2, x23
    ef14:      	blr	x8
    ef18:      	ldr	x8, [sp, #0x98]
    ef1c:      	cmp	x8, x21
    ef20:      	b.eq	0xefe8 <generic_rawtp_path+0x4cf8>
    ef24:      	mov	w8, #0x4                // =4
    ef28:      	add	x9, sp, #0x78
    ef2c:      	add	x0, sp, #0x78
    ef30:      	mov	w1, #0x8                // =8
    ef34:      	mov	x2, x23
    ef38:      	blr	x8
    ef3c:      	add	x2, x21, #0x20
    ef40:      	mov	w8, #0x4                // =4
    ef44:      	mov	w9, #0x10               // =16
    ef48:      	add	x10, sp, #0x80
    ef4c:      	add	x0, sp, #0x80
    ef50:      	mov	w1, #0x10               // =16
    ef54:      	blr	x8
    ef58:      	ldr	w21, [sp, #0x84]
    ef5c:      	ldr	x8, [sp, #0x40]
    ef60:      	ldr	x10, [sp, #0x60]
    ef64:      	sub	x12, x10, x8
    ef68:      	ldr	w23, [sp, #0x68]
    ef6c:      	subs	w10, w21, w23
    ef70:      	ldr	x9, [sp, #0x88]
    ef74:      	csel	w10, wzr, w10, lo
    ef78:      	cmp	w23, w21
    ef7c:      	csel	w11, w23, w21, lo
    ef80:      	cinc	w13, w11, hi
    ef84:      	sub	w14, w23, w13
    ef88:      	subs	x12, x12, x13
    ef8c:      	str	w14, [sp, #0x68]
    ef90:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    ef94:      	cmp	x12, #0xfff
    ef98:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    ef9c:      	cmp	w23, w21
    efa0:      	b.ls	0xefac <generic_rawtp_path+0x4cbc>
    efa4:      	mov	w13, #0x2f              // =47
    efa8:      	strb	w13, [x8, x12]
    efac:      	add	x19, x8, x12
    efb0:      	cmp	w23, w21
    efb4:      	add	x2, x9, x10
    efb8:      	and	w1, w11, #0xff
    efbc:      	mov	w8, #0x4                // =4
    efc0:      	cinc	x0, x19, hi
    efc4:      	blr	x8
    efc8:      	cmp	w23, w21
    efcc:      	str	x19, [sp, #0x60]
    efd0:      	add	x19, sp, #0x70
    efd4:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    efd8:      	ldr	x21, [sp, #0x78]
    efdc:      	ldp	x2, x24, [sp, #0x50]
    efe0:      	str	x21, [sp, #0x48]
    efe4:      	b	0xf034 <generic_rawtp_path+0x4d44>
    efe8:      	add	x2, x24, #0x10
    efec:      	mov	w8, #0x4                // =4
    eff0:      	add	x9, sp, #0x98
    eff4:      	add	x0, sp, #0x98
    eff8:      	mov	w1, #0x8                // =8
    effc:      	blr	x8
    f000:      	ldr	x8, [sp, #0x58]
    f004:      	ldr	x9, [sp, #0x98]
    f008:      	cmp	x8, x9
    f00c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    f010:      	add	x2, x24, #0x18
    f014:      	mov	w8, #0x4                // =4
    f018:      	mov	x0, x22
    f01c:      	mov	w1, #0x8                // =8
    f020:      	blr	x8
    f024:      	ldr	x24, [sp, #0x98]
    f028:      	ldr	x21, [sp, #0x48]
    f02c:      	add	x2, x24, #0x20
    f030:      	stp	x2, x24, [sp, #0x50]
    f034:      	ldr	x8, [sp, #0x30]
    f038:      	cmp	x21, x8
    f03c:      	b.ne	0xf04c <generic_rawtp_path+0x4d5c>
    f040:      	ldr	x8, [sp, #0x38]
    f044:      	cmp	x2, x8
    f048:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    f04c:      	mov	w8, #0x4                // =4
    f050:      	add	x0, sp, #0x70
    f054:      	mov	w1, #0x8                // =8
    f058:      	blr	x8
    f05c:      	ldr	x8, [sp, #0x70]
    f060:      	cmp	x21, x8
    f064:      	b.eq	0xf154 <generic_rawtp_path+0x4e64>
    f068:      	add	x23, x21, #0x18
    f06c:      	mov	w8, #0x4                // =4
    f070:      	add	x9, sp, #0x98
    f074:      	add	x0, sp, #0x98
    f078:      	mov	w1, #0x8                // =8
    f07c:      	mov	x2, x23
    f080:      	blr	x8
    f084:      	ldr	x8, [sp, #0x98]
    f088:      	cmp	x8, x21
    f08c:      	b.eq	0xf154 <generic_rawtp_path+0x4e64>
    f090:      	mov	w8, #0x4                // =4
    f094:      	add	x9, sp, #0x78
    f098:      	add	x0, sp, #0x78
    f09c:      	mov	w1, #0x8                // =8
    f0a0:      	mov	x2, x23
    f0a4:      	blr	x8
    f0a8:      	add	x2, x21, #0x20
    f0ac:      	mov	w8, #0x4                // =4
    f0b0:      	mov	w9, #0x10               // =16
    f0b4:      	add	x10, sp, #0x80
    f0b8:      	add	x0, sp, #0x80
    f0bc:      	mov	w1, #0x10               // =16
    f0c0:      	blr	x8
    f0c4:      	ldr	w21, [sp, #0x84]
    f0c8:      	ldr	x8, [sp, #0x40]
    f0cc:      	ldr	x10, [sp, #0x60]
    f0d0:      	sub	x12, x10, x8
    f0d4:      	ldr	w23, [sp, #0x68]
    f0d8:      	subs	w10, w21, w23
    f0dc:      	ldr	x9, [sp, #0x88]
    f0e0:      	csel	w10, wzr, w10, lo
    f0e4:      	cmp	w23, w21
    f0e8:      	csel	w11, w23, w21, lo
    f0ec:      	cinc	w13, w11, hi
    f0f0:      	sub	w14, w23, w13
    f0f4:      	subs	x12, x12, x13
    f0f8:      	str	w14, [sp, #0x68]
    f0fc:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    f100:      	cmp	x12, #0xfff
    f104:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    f108:      	cmp	w23, w21
    f10c:      	b.ls	0xf118 <generic_rawtp_path+0x4e28>
    f110:      	mov	w13, #0x2f              // =47
    f114:      	strb	w13, [x8, x12]
    f118:      	add	x19, x8, x12
    f11c:      	cmp	w23, w21
    f120:      	add	x2, x9, x10
    f124:      	and	w1, w11, #0xff
    f128:      	mov	w8, #0x4                // =4
    f12c:      	cinc	x0, x19, hi
    f130:      	blr	x8
    f134:      	cmp	w23, w21
    f138:      	str	x19, [sp, #0x60]
    f13c:      	add	x19, sp, #0x70
    f140:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    f144:      	ldr	x21, [sp, #0x78]
    f148:      	ldp	x2, x24, [sp, #0x50]
    f14c:      	str	x21, [sp, #0x48]
    f150:      	b	0xf1a0 <generic_rawtp_path+0x4eb0>
    f154:      	add	x2, x24, #0x10
    f158:      	mov	w8, #0x4                // =4
    f15c:      	add	x9, sp, #0x98
    f160:      	add	x0, sp, #0x98
    f164:      	mov	w1, #0x8                // =8
    f168:      	blr	x8
    f16c:      	ldr	x8, [sp, #0x58]
    f170:      	ldr	x9, [sp, #0x98]
    f174:      	cmp	x8, x9
    f178:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    f17c:      	add	x2, x24, #0x18
    f180:      	mov	w8, #0x4                // =4
    f184:      	mov	x0, x22
    f188:      	mov	w1, #0x8                // =8
    f18c:      	blr	x8
    f190:      	ldr	x24, [sp, #0x98]
    f194:      	ldr	x21, [sp, #0x48]
    f198:      	add	x2, x24, #0x20
    f19c:      	stp	x2, x24, [sp, #0x50]
    f1a0:      	ldr	x8, [sp, #0x30]
    f1a4:      	cmp	x21, x8
    f1a8:      	b.ne	0xf1b8 <generic_rawtp_path+0x4ec8>
    f1ac:      	ldr	x8, [sp, #0x38]
    f1b0:      	cmp	x2, x8
    f1b4:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    f1b8:      	mov	w8, #0x4                // =4
    f1bc:      	add	x0, sp, #0x70
    f1c0:      	mov	w1, #0x8                // =8
    f1c4:      	blr	x8
    f1c8:      	ldr	x8, [sp, #0x70]
    f1cc:      	cmp	x21, x8
    f1d0:      	b.eq	0xf2c0 <generic_rawtp_path+0x4fd0>
    f1d4:      	add	x23, x21, #0x18
    f1d8:      	mov	w8, #0x4                // =4
    f1dc:      	add	x9, sp, #0x98
    f1e0:      	add	x0, sp, #0x98
    f1e4:      	mov	w1, #0x8                // =8
    f1e8:      	mov	x2, x23
    f1ec:      	blr	x8
    f1f0:      	ldr	x8, [sp, #0x98]
    f1f4:      	cmp	x8, x21
    f1f8:      	b.eq	0xf2c0 <generic_rawtp_path+0x4fd0>
    f1fc:      	mov	w8, #0x4                // =4
    f200:      	add	x9, sp, #0x78
    f204:      	add	x0, sp, #0x78
    f208:      	mov	w1, #0x8                // =8
    f20c:      	mov	x2, x23
    f210:      	blr	x8
    f214:      	add	x2, x21, #0x20
    f218:      	mov	w8, #0x4                // =4
    f21c:      	mov	w9, #0x10               // =16
    f220:      	add	x10, sp, #0x80
    f224:      	add	x0, sp, #0x80
    f228:      	mov	w1, #0x10               // =16
    f22c:      	blr	x8
    f230:      	ldr	w21, [sp, #0x84]
    f234:      	ldr	x8, [sp, #0x40]
    f238:      	ldr	x10, [sp, #0x60]
    f23c:      	sub	x12, x10, x8
    f240:      	ldr	w23, [sp, #0x68]
    f244:      	subs	w10, w21, w23
    f248:      	ldr	x9, [sp, #0x88]
    f24c:      	csel	w10, wzr, w10, lo
    f250:      	cmp	w23, w21
    f254:      	csel	w11, w23, w21, lo
    f258:      	cinc	w13, w11, hi
    f25c:      	sub	w14, w23, w13
    f260:      	subs	x12, x12, x13
    f264:      	str	w14, [sp, #0x68]
    f268:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    f26c:      	cmp	x12, #0xfff
    f270:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    f274:      	cmp	w23, w21
    f278:      	b.ls	0xf284 <generic_rawtp_path+0x4f94>
    f27c:      	mov	w13, #0x2f              // =47
    f280:      	strb	w13, [x8, x12]
    f284:      	add	x19, x8, x12
    f288:      	cmp	w23, w21
    f28c:      	add	x2, x9, x10
    f290:      	and	w1, w11, #0xff
    f294:      	mov	w8, #0x4                // =4
    f298:      	cinc	x0, x19, hi
    f29c:      	blr	x8
    f2a0:      	cmp	w23, w21
    f2a4:      	str	x19, [sp, #0x60]
    f2a8:      	add	x19, sp, #0x70
    f2ac:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    f2b0:      	ldr	x21, [sp, #0x78]
    f2b4:      	ldp	x2, x24, [sp, #0x50]
    f2b8:      	str	x21, [sp, #0x48]
    f2bc:      	b	0xf30c <generic_rawtp_path+0x501c>
    f2c0:      	add	x2, x24, #0x10
    f2c4:      	mov	w8, #0x4                // =4
    f2c8:      	add	x9, sp, #0x98
    f2cc:      	add	x0, sp, #0x98
    f2d0:      	mov	w1, #0x8                // =8
    f2d4:      	blr	x8
    f2d8:      	ldr	x8, [sp, #0x58]
    f2dc:      	ldr	x9, [sp, #0x98]
    f2e0:      	cmp	x8, x9
    f2e4:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    f2e8:      	add	x2, x24, #0x18
    f2ec:      	mov	w8, #0x4                // =4
    f2f0:      	mov	x0, x22
    f2f4:      	mov	w1, #0x8                // =8
    f2f8:      	blr	x8
    f2fc:      	ldr	x24, [sp, #0x98]
    f300:      	ldr	x21, [sp, #0x48]
    f304:      	add	x2, x24, #0x20
    f308:      	stp	x2, x24, [sp, #0x50]
    f30c:      	ldr	x8, [sp, #0x30]
    f310:      	cmp	x21, x8
    f314:      	b.ne	0xf324 <generic_rawtp_path+0x5034>
    f318:      	ldr	x8, [sp, #0x38]
    f31c:      	cmp	x2, x8
    f320:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    f324:      	mov	w8, #0x4                // =4
    f328:      	add	x0, sp, #0x70
    f32c:      	mov	w1, #0x8                // =8
    f330:      	blr	x8
    f334:      	ldr	x8, [sp, #0x70]
    f338:      	cmp	x21, x8
    f33c:      	b.eq	0xf42c <generic_rawtp_path+0x513c>
    f340:      	add	x23, x21, #0x18
    f344:      	mov	w8, #0x4                // =4
    f348:      	add	x9, sp, #0x98
    f34c:      	add	x0, sp, #0x98
    f350:      	mov	w1, #0x8                // =8
    f354:      	mov	x2, x23
    f358:      	blr	x8
    f35c:      	ldr	x8, [sp, #0x98]
    f360:      	cmp	x8, x21
    f364:      	b.eq	0xf42c <generic_rawtp_path+0x513c>
    f368:      	mov	w8, #0x4                // =4
    f36c:      	add	x9, sp, #0x78
    f370:      	add	x0, sp, #0x78
    f374:      	mov	w1, #0x8                // =8
    f378:      	mov	x2, x23
    f37c:      	blr	x8
    f380:      	add	x2, x21, #0x20
    f384:      	mov	w8, #0x4                // =4
    f388:      	mov	w9, #0x10               // =16
    f38c:      	add	x10, sp, #0x80
    f390:      	add	x0, sp, #0x80
    f394:      	mov	w1, #0x10               // =16
    f398:      	blr	x8
    f39c:      	ldr	w21, [sp, #0x84]
    f3a0:      	ldr	x8, [sp, #0x40]
    f3a4:      	ldr	x10, [sp, #0x60]
    f3a8:      	sub	x12, x10, x8
    f3ac:      	ldr	w23, [sp, #0x68]
    f3b0:      	subs	w10, w21, w23
    f3b4:      	ldr	x9, [sp, #0x88]
    f3b8:      	csel	w10, wzr, w10, lo
    f3bc:      	cmp	w23, w21
    f3c0:      	csel	w11, w23, w21, lo
    f3c4:      	cinc	w13, w11, hi
    f3c8:      	sub	w14, w23, w13
    f3cc:      	subs	x12, x12, x13
    f3d0:      	str	w14, [sp, #0x68]
    f3d4:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    f3d8:      	cmp	x12, #0xfff
    f3dc:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    f3e0:      	cmp	w23, w21
    f3e4:      	b.ls	0xf3f0 <generic_rawtp_path+0x5100>
    f3e8:      	mov	w13, #0x2f              // =47
    f3ec:      	strb	w13, [x8, x12]
    f3f0:      	add	x19, x8, x12
    f3f4:      	cmp	w23, w21
    f3f8:      	add	x2, x9, x10
    f3fc:      	and	w1, w11, #0xff
    f400:      	mov	w8, #0x4                // =4
    f404:      	cinc	x0, x19, hi
    f408:      	blr	x8
    f40c:      	cmp	w23, w21
    f410:      	str	x19, [sp, #0x60]
    f414:      	add	x19, sp, #0x70
    f418:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    f41c:      	ldr	x21, [sp, #0x78]
    f420:      	ldp	x2, x24, [sp, #0x50]
    f424:      	str	x21, [sp, #0x48]
    f428:      	b	0xf478 <generic_rawtp_path+0x5188>
    f42c:      	add	x2, x24, #0x10
    f430:      	mov	w8, #0x4                // =4
    f434:      	add	x9, sp, #0x98
    f438:      	add	x0, sp, #0x98
    f43c:      	mov	w1, #0x8                // =8
    f440:      	blr	x8
    f444:      	ldr	x8, [sp, #0x58]
    f448:      	ldr	x9, [sp, #0x98]
    f44c:      	cmp	x8, x9
    f450:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    f454:      	add	x2, x24, #0x18
    f458:      	mov	w8, #0x4                // =4
    f45c:      	mov	x0, x22
    f460:      	mov	w1, #0x8                // =8
    f464:      	blr	x8
    f468:      	ldr	x24, [sp, #0x98]
    f46c:      	ldr	x21, [sp, #0x48]
    f470:      	add	x2, x24, #0x20
    f474:      	stp	x2, x24, [sp, #0x50]
    f478:      	ldr	x8, [sp, #0x30]
    f47c:      	cmp	x21, x8
    f480:      	b.ne	0xf490 <generic_rawtp_path+0x51a0>
    f484:      	ldr	x8, [sp, #0x38]
    f488:      	cmp	x2, x8
    f48c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    f490:      	mov	w8, #0x4                // =4
    f494:      	add	x0, sp, #0x70
    f498:      	mov	w1, #0x8                // =8
    f49c:      	blr	x8
    f4a0:      	ldr	x8, [sp, #0x70]
    f4a4:      	cmp	x21, x8
    f4a8:      	b.eq	0xf598 <generic_rawtp_path+0x52a8>
    f4ac:      	add	x23, x21, #0x18
    f4b0:      	mov	w8, #0x4                // =4
    f4b4:      	add	x9, sp, #0x98
    f4b8:      	add	x0, sp, #0x98
    f4bc:      	mov	w1, #0x8                // =8
    f4c0:      	mov	x2, x23
    f4c4:      	blr	x8
    f4c8:      	ldr	x8, [sp, #0x98]
    f4cc:      	cmp	x8, x21
    f4d0:      	b.eq	0xf598 <generic_rawtp_path+0x52a8>
    f4d4:      	mov	w8, #0x4                // =4
    f4d8:      	add	x9, sp, #0x78
    f4dc:      	add	x0, sp, #0x78
    f4e0:      	mov	w1, #0x8                // =8
    f4e4:      	mov	x2, x23
    f4e8:      	blr	x8
    f4ec:      	add	x2, x21, #0x20
    f4f0:      	mov	w8, #0x4                // =4
    f4f4:      	mov	w9, #0x10               // =16
    f4f8:      	add	x10, sp, #0x80
    f4fc:      	add	x0, sp, #0x80
    f500:      	mov	w1, #0x10               // =16
    f504:      	blr	x8
    f508:      	ldr	w21, [sp, #0x84]
    f50c:      	ldr	x8, [sp, #0x40]
    f510:      	ldr	x10, [sp, #0x60]
    f514:      	sub	x12, x10, x8
    f518:      	ldr	w23, [sp, #0x68]
    f51c:      	subs	w10, w21, w23
    f520:      	ldr	x9, [sp, #0x88]
    f524:      	csel	w10, wzr, w10, lo
    f528:      	cmp	w23, w21
    f52c:      	csel	w11, w23, w21, lo
    f530:      	cinc	w13, w11, hi
    f534:      	sub	w14, w23, w13
    f538:      	subs	x12, x12, x13
    f53c:      	str	w14, [sp, #0x68]
    f540:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    f544:      	cmp	x12, #0xfff
    f548:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    f54c:      	cmp	w23, w21
    f550:      	b.ls	0xf55c <generic_rawtp_path+0x526c>
    f554:      	mov	w13, #0x2f              // =47
    f558:      	strb	w13, [x8, x12]
    f55c:      	add	x19, x8, x12
    f560:      	cmp	w23, w21
    f564:      	add	x2, x9, x10
    f568:      	and	w1, w11, #0xff
    f56c:      	mov	w8, #0x4                // =4
    f570:      	cinc	x0, x19, hi
    f574:      	blr	x8
    f578:      	cmp	w23, w21
    f57c:      	str	x19, [sp, #0x60]
    f580:      	add	x19, sp, #0x70
    f584:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    f588:      	ldr	x21, [sp, #0x78]
    f58c:      	ldp	x2, x24, [sp, #0x50]
    f590:      	str	x21, [sp, #0x48]
    f594:      	b	0xf5e4 <generic_rawtp_path+0x52f4>
    f598:      	add	x2, x24, #0x10
    f59c:      	mov	w8, #0x4                // =4
    f5a0:      	add	x9, sp, #0x98
    f5a4:      	add	x0, sp, #0x98
    f5a8:      	mov	w1, #0x8                // =8
    f5ac:      	blr	x8
    f5b0:      	ldr	x8, [sp, #0x58]
    f5b4:      	ldr	x9, [sp, #0x98]
    f5b8:      	cmp	x8, x9
    f5bc:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    f5c0:      	add	x2, x24, #0x18
    f5c4:      	mov	w8, #0x4                // =4
    f5c8:      	mov	x0, x22
    f5cc:      	mov	w1, #0x8                // =8
    f5d0:      	blr	x8
    f5d4:      	ldr	x24, [sp, #0x98]
    f5d8:      	ldr	x21, [sp, #0x48]
    f5dc:      	add	x2, x24, #0x20
    f5e0:      	stp	x2, x24, [sp, #0x50]
    f5e4:      	ldr	x8, [sp, #0x30]
    f5e8:      	cmp	x21, x8
    f5ec:      	b.ne	0xf5fc <generic_rawtp_path+0x530c>
    f5f0:      	ldr	x8, [sp, #0x38]
    f5f4:      	cmp	x2, x8
    f5f8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    f5fc:      	mov	w8, #0x4                // =4
    f600:      	add	x0, sp, #0x70
    f604:      	mov	w1, #0x8                // =8
    f608:      	blr	x8
    f60c:      	ldr	x8, [sp, #0x70]
    f610:      	cmp	x21, x8
    f614:      	b.eq	0xf704 <generic_rawtp_path+0x5414>
    f618:      	add	x23, x21, #0x18
    f61c:      	mov	w8, #0x4                // =4
    f620:      	add	x9, sp, #0x98
    f624:      	add	x0, sp, #0x98
    f628:      	mov	w1, #0x8                // =8
    f62c:      	mov	x2, x23
    f630:      	blr	x8
    f634:      	ldr	x8, [sp, #0x98]
    f638:      	cmp	x8, x21
    f63c:      	b.eq	0xf704 <generic_rawtp_path+0x5414>
    f640:      	mov	w8, #0x4                // =4
    f644:      	add	x9, sp, #0x78
    f648:      	add	x0, sp, #0x78
    f64c:      	mov	w1, #0x8                // =8
    f650:      	mov	x2, x23
    f654:      	blr	x8
    f658:      	add	x2, x21, #0x20
    f65c:      	mov	w8, #0x4                // =4
    f660:      	mov	w9, #0x10               // =16
    f664:      	add	x10, sp, #0x80
    f668:      	add	x0, sp, #0x80
    f66c:      	mov	w1, #0x10               // =16
    f670:      	blr	x8
    f674:      	ldr	w21, [sp, #0x84]
    f678:      	ldr	x8, [sp, #0x40]
    f67c:      	ldr	x10, [sp, #0x60]
    f680:      	sub	x12, x10, x8
    f684:      	ldr	w23, [sp, #0x68]
    f688:      	subs	w10, w21, w23
    f68c:      	ldr	x9, [sp, #0x88]
    f690:      	csel	w10, wzr, w10, lo
    f694:      	cmp	w23, w21
    f698:      	csel	w11, w23, w21, lo
    f69c:      	cinc	w13, w11, hi
    f6a0:      	sub	w14, w23, w13
    f6a4:      	subs	x12, x12, x13
    f6a8:      	str	w14, [sp, #0x68]
    f6ac:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    f6b0:      	cmp	x12, #0xfff
    f6b4:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    f6b8:      	cmp	w23, w21
    f6bc:      	b.ls	0xf6c8 <generic_rawtp_path+0x53d8>
    f6c0:      	mov	w13, #0x2f              // =47
    f6c4:      	strb	w13, [x8, x12]
    f6c8:      	add	x19, x8, x12
    f6cc:      	cmp	w23, w21
    f6d0:      	add	x2, x9, x10
    f6d4:      	and	w1, w11, #0xff
    f6d8:      	mov	w8, #0x4                // =4
    f6dc:      	cinc	x0, x19, hi
    f6e0:      	blr	x8
    f6e4:      	cmp	w23, w21
    f6e8:      	str	x19, [sp, #0x60]
    f6ec:      	add	x19, sp, #0x70
    f6f0:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    f6f4:      	ldr	x21, [sp, #0x78]
    f6f8:      	ldp	x2, x24, [sp, #0x50]
    f6fc:      	str	x21, [sp, #0x48]
    f700:      	b	0xf750 <generic_rawtp_path+0x5460>
    f704:      	add	x2, x24, #0x10
    f708:      	mov	w8, #0x4                // =4
    f70c:      	add	x9, sp, #0x98
    f710:      	add	x0, sp, #0x98
    f714:      	mov	w1, #0x8                // =8
    f718:      	blr	x8
    f71c:      	ldr	x8, [sp, #0x58]
    f720:      	ldr	x9, [sp, #0x98]
    f724:      	cmp	x8, x9
    f728:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    f72c:      	add	x2, x24, #0x18
    f730:      	mov	w8, #0x4                // =4
    f734:      	mov	x0, x22
    f738:      	mov	w1, #0x8                // =8
    f73c:      	blr	x8
    f740:      	ldr	x24, [sp, #0x98]
    f744:      	ldr	x21, [sp, #0x48]
    f748:      	add	x2, x24, #0x20
    f74c:      	stp	x2, x24, [sp, #0x50]
    f750:      	ldr	x8, [sp, #0x30]
    f754:      	cmp	x21, x8
    f758:      	b.ne	0xf768 <generic_rawtp_path+0x5478>
    f75c:      	ldr	x8, [sp, #0x38]
    f760:      	cmp	x2, x8
    f764:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    f768:      	mov	w8, #0x4                // =4
    f76c:      	add	x0, sp, #0x70
    f770:      	mov	w1, #0x8                // =8
    f774:      	blr	x8
    f778:      	ldr	x8, [sp, #0x70]
    f77c:      	cmp	x21, x8
    f780:      	b.eq	0xf870 <generic_rawtp_path+0x5580>
    f784:      	add	x23, x21, #0x18
    f788:      	mov	w8, #0x4                // =4
    f78c:      	add	x9, sp, #0x98
    f790:      	add	x0, sp, #0x98
    f794:      	mov	w1, #0x8                // =8
    f798:      	mov	x2, x23
    f79c:      	blr	x8
    f7a0:      	ldr	x8, [sp, #0x98]
    f7a4:      	cmp	x8, x21
    f7a8:      	b.eq	0xf870 <generic_rawtp_path+0x5580>
    f7ac:      	mov	w8, #0x4                // =4
    f7b0:      	add	x9, sp, #0x78
    f7b4:      	add	x0, sp, #0x78
    f7b8:      	mov	w1, #0x8                // =8
    f7bc:      	mov	x2, x23
    f7c0:      	blr	x8
    f7c4:      	add	x2, x21, #0x20
    f7c8:      	mov	w8, #0x4                // =4
    f7cc:      	mov	w9, #0x10               // =16
    f7d0:      	add	x10, sp, #0x80
    f7d4:      	add	x0, sp, #0x80
    f7d8:      	mov	w1, #0x10               // =16
    f7dc:      	blr	x8
    f7e0:      	ldr	w21, [sp, #0x84]
    f7e4:      	ldr	x8, [sp, #0x40]
    f7e8:      	ldr	x10, [sp, #0x60]
    f7ec:      	sub	x12, x10, x8
    f7f0:      	ldr	w23, [sp, #0x68]
    f7f4:      	subs	w10, w21, w23
    f7f8:      	ldr	x9, [sp, #0x88]
    f7fc:      	csel	w10, wzr, w10, lo
    f800:      	cmp	w23, w21
    f804:      	csel	w11, w23, w21, lo
    f808:      	cinc	w13, w11, hi
    f80c:      	sub	w14, w23, w13
    f810:      	subs	x12, x12, x13
    f814:      	str	w14, [sp, #0x68]
    f818:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    f81c:      	cmp	x12, #0xfff
    f820:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    f824:      	cmp	w23, w21
    f828:      	b.ls	0xf834 <generic_rawtp_path+0x5544>
    f82c:      	mov	w13, #0x2f              // =47
    f830:      	strb	w13, [x8, x12]
    f834:      	add	x19, x8, x12
    f838:      	cmp	w23, w21
    f83c:      	add	x2, x9, x10
    f840:      	and	w1, w11, #0xff
    f844:      	mov	w8, #0x4                // =4
    f848:      	cinc	x0, x19, hi
    f84c:      	blr	x8
    f850:      	cmp	w23, w21
    f854:      	str	x19, [sp, #0x60]
    f858:      	add	x19, sp, #0x70
    f85c:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    f860:      	ldr	x21, [sp, #0x78]
    f864:      	ldp	x2, x24, [sp, #0x50]
    f868:      	str	x21, [sp, #0x48]
    f86c:      	b	0xf8bc <generic_rawtp_path+0x55cc>
    f870:      	add	x2, x24, #0x10
    f874:      	mov	w8, #0x4                // =4
    f878:      	add	x9, sp, #0x98
    f87c:      	add	x0, sp, #0x98
    f880:      	mov	w1, #0x8                // =8
    f884:      	blr	x8
    f888:      	ldr	x8, [sp, #0x58]
    f88c:      	ldr	x9, [sp, #0x98]
    f890:      	cmp	x8, x9
    f894:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    f898:      	add	x2, x24, #0x18
    f89c:      	mov	w8, #0x4                // =4
    f8a0:      	mov	x0, x22
    f8a4:      	mov	w1, #0x8                // =8
    f8a8:      	blr	x8
    f8ac:      	ldr	x24, [sp, #0x98]
    f8b0:      	ldr	x21, [sp, #0x48]
    f8b4:      	add	x2, x24, #0x20
    f8b8:      	stp	x2, x24, [sp, #0x50]
    f8bc:      	ldr	x8, [sp, #0x30]
    f8c0:      	cmp	x21, x8
    f8c4:      	b.ne	0xf8d4 <generic_rawtp_path+0x55e4>
    f8c8:      	ldr	x8, [sp, #0x38]
    f8cc:      	cmp	x2, x8
    f8d0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    f8d4:      	mov	w8, #0x4                // =4
    f8d8:      	add	x0, sp, #0x70
    f8dc:      	mov	w1, #0x8                // =8
    f8e0:      	blr	x8
    f8e4:      	ldr	x8, [sp, #0x70]
    f8e8:      	cmp	x21, x8
    f8ec:      	b.eq	0xf9dc <generic_rawtp_path+0x56ec>
    f8f0:      	add	x23, x21, #0x18
    f8f4:      	mov	w8, #0x4                // =4
    f8f8:      	add	x9, sp, #0x98
    f8fc:      	add	x0, sp, #0x98
    f900:      	mov	w1, #0x8                // =8
    f904:      	mov	x2, x23
    f908:      	blr	x8
    f90c:      	ldr	x8, [sp, #0x98]
    f910:      	cmp	x8, x21
    f914:      	b.eq	0xf9dc <generic_rawtp_path+0x56ec>
    f918:      	mov	w8, #0x4                // =4
    f91c:      	add	x9, sp, #0x78
    f920:      	add	x0, sp, #0x78
    f924:      	mov	w1, #0x8                // =8
    f928:      	mov	x2, x23
    f92c:      	blr	x8
    f930:      	add	x2, x21, #0x20
    f934:      	mov	w8, #0x4                // =4
    f938:      	mov	w9, #0x10               // =16
    f93c:      	add	x10, sp, #0x80
    f940:      	add	x0, sp, #0x80
    f944:      	mov	w1, #0x10               // =16
    f948:      	blr	x8
    f94c:      	ldr	w21, [sp, #0x84]
    f950:      	ldr	x8, [sp, #0x40]
    f954:      	ldr	x10, [sp, #0x60]
    f958:      	sub	x12, x10, x8
    f95c:      	ldr	w23, [sp, #0x68]
    f960:      	subs	w10, w21, w23
    f964:      	ldr	x9, [sp, #0x88]
    f968:      	csel	w10, wzr, w10, lo
    f96c:      	cmp	w23, w21
    f970:      	csel	w11, w23, w21, lo
    f974:      	cinc	w13, w11, hi
    f978:      	sub	w14, w23, w13
    f97c:      	subs	x12, x12, x13
    f980:      	str	w14, [sp, #0x68]
    f984:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    f988:      	cmp	x12, #0xfff
    f98c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    f990:      	cmp	w23, w21
    f994:      	b.ls	0xf9a0 <generic_rawtp_path+0x56b0>
    f998:      	mov	w13, #0x2f              // =47
    f99c:      	strb	w13, [x8, x12]
    f9a0:      	add	x19, x8, x12
    f9a4:      	cmp	w23, w21
    f9a8:      	add	x2, x9, x10
    f9ac:      	and	w1, w11, #0xff
    f9b0:      	mov	w8, #0x4                // =4
    f9b4:      	cinc	x0, x19, hi
    f9b8:      	blr	x8
    f9bc:      	cmp	w23, w21
    f9c0:      	str	x19, [sp, #0x60]
    f9c4:      	add	x19, sp, #0x70
    f9c8:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    f9cc:      	ldr	x21, [sp, #0x78]
    f9d0:      	ldp	x2, x24, [sp, #0x50]
    f9d4:      	str	x21, [sp, #0x48]
    f9d8:      	b	0xfa28 <generic_rawtp_path+0x5738>
    f9dc:      	add	x2, x24, #0x10
    f9e0:      	mov	w8, #0x4                // =4
    f9e4:      	add	x9, sp, #0x98
    f9e8:      	add	x0, sp, #0x98
    f9ec:      	mov	w1, #0x8                // =8
    f9f0:      	blr	x8
    f9f4:      	ldr	x8, [sp, #0x58]
    f9f8:      	ldr	x9, [sp, #0x98]
    f9fc:      	cmp	x8, x9
    fa00:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    fa04:      	add	x2, x24, #0x18
    fa08:      	mov	w8, #0x4                // =4
    fa0c:      	mov	x0, x22
    fa10:      	mov	w1, #0x8                // =8
    fa14:      	blr	x8
    fa18:      	ldr	x24, [sp, #0x98]
    fa1c:      	ldr	x21, [sp, #0x48]
    fa20:      	add	x2, x24, #0x20
    fa24:      	stp	x2, x24, [sp, #0x50]
    fa28:      	ldr	x8, [sp, #0x30]
    fa2c:      	cmp	x21, x8
    fa30:      	b.ne	0xfa40 <generic_rawtp_path+0x5750>
    fa34:      	ldr	x8, [sp, #0x38]
    fa38:      	cmp	x2, x8
    fa3c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    fa40:      	mov	w8, #0x4                // =4
    fa44:      	add	x0, sp, #0x70
    fa48:      	mov	w1, #0x8                // =8
    fa4c:      	blr	x8
    fa50:      	ldr	x8, [sp, #0x70]
    fa54:      	cmp	x21, x8
    fa58:      	b.eq	0xfb48 <generic_rawtp_path+0x5858>
    fa5c:      	add	x23, x21, #0x18
    fa60:      	mov	w8, #0x4                // =4
    fa64:      	add	x9, sp, #0x98
    fa68:      	add	x0, sp, #0x98
    fa6c:      	mov	w1, #0x8                // =8
    fa70:      	mov	x2, x23
    fa74:      	blr	x8
    fa78:      	ldr	x8, [sp, #0x98]
    fa7c:      	cmp	x8, x21
    fa80:      	b.eq	0xfb48 <generic_rawtp_path+0x5858>
    fa84:      	mov	w8, #0x4                // =4
    fa88:      	add	x9, sp, #0x78
    fa8c:      	add	x0, sp, #0x78
    fa90:      	mov	w1, #0x8                // =8
    fa94:      	mov	x2, x23
    fa98:      	blr	x8
    fa9c:      	add	x2, x21, #0x20
    faa0:      	mov	w8, #0x4                // =4
    faa4:      	mov	w9, #0x10               // =16
    faa8:      	add	x10, sp, #0x80
    faac:      	add	x0, sp, #0x80
    fab0:      	mov	w1, #0x10               // =16
    fab4:      	blr	x8
    fab8:      	ldr	w21, [sp, #0x84]
    fabc:      	ldr	x8, [sp, #0x40]
    fac0:      	ldr	x10, [sp, #0x60]
    fac4:      	sub	x12, x10, x8
    fac8:      	ldr	w23, [sp, #0x68]
    facc:      	subs	w10, w21, w23
    fad0:      	ldr	x9, [sp, #0x88]
    fad4:      	csel	w10, wzr, w10, lo
    fad8:      	cmp	w23, w21
    fadc:      	csel	w11, w23, w21, lo
    fae0:      	cinc	w13, w11, hi
    fae4:      	sub	w14, w23, w13
    fae8:      	subs	x12, x12, x13
    faec:      	str	w14, [sp, #0x68]
    faf0:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    faf4:      	cmp	x12, #0xfff
    faf8:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    fafc:      	cmp	w23, w21
    fb00:      	b.ls	0xfb0c <generic_rawtp_path+0x581c>
    fb04:      	mov	w13, #0x2f              // =47
    fb08:      	strb	w13, [x8, x12]
    fb0c:      	add	x19, x8, x12
    fb10:      	cmp	w23, w21
    fb14:      	add	x2, x9, x10
    fb18:      	and	w1, w11, #0xff
    fb1c:      	mov	w8, #0x4                // =4
    fb20:      	cinc	x0, x19, hi
    fb24:      	blr	x8
    fb28:      	cmp	w23, w21
    fb2c:      	str	x19, [sp, #0x60]
    fb30:      	add	x19, sp, #0x70
    fb34:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    fb38:      	ldr	x21, [sp, #0x78]
    fb3c:      	ldp	x2, x24, [sp, #0x50]
    fb40:      	str	x21, [sp, #0x48]
    fb44:      	b	0xfb94 <generic_rawtp_path+0x58a4>
    fb48:      	add	x2, x24, #0x10
    fb4c:      	mov	w8, #0x4                // =4
    fb50:      	add	x9, sp, #0x98
    fb54:      	add	x0, sp, #0x98
    fb58:      	mov	w1, #0x8                // =8
    fb5c:      	blr	x8
    fb60:      	ldr	x8, [sp, #0x58]
    fb64:      	ldr	x9, [sp, #0x98]
    fb68:      	cmp	x8, x9
    fb6c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    fb70:      	add	x2, x24, #0x18
    fb74:      	mov	w8, #0x4                // =4
    fb78:      	mov	x0, x22
    fb7c:      	mov	w1, #0x8                // =8
    fb80:      	blr	x8
    fb84:      	ldr	x24, [sp, #0x98]
    fb88:      	ldr	x21, [sp, #0x48]
    fb8c:      	add	x2, x24, #0x20
    fb90:      	stp	x2, x24, [sp, #0x50]
    fb94:      	ldr	x8, [sp, #0x30]
    fb98:      	cmp	x21, x8
    fb9c:      	b.ne	0xfbac <generic_rawtp_path+0x58bc>
    fba0:      	ldr	x8, [sp, #0x38]
    fba4:      	cmp	x2, x8
    fba8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    fbac:      	mov	w8, #0x4                // =4
    fbb0:      	add	x0, sp, #0x70
    fbb4:      	mov	w1, #0x8                // =8
    fbb8:      	blr	x8
    fbbc:      	ldr	x8, [sp, #0x70]
    fbc0:      	cmp	x21, x8
    fbc4:      	b.eq	0xfcb4 <generic_rawtp_path+0x59c4>
    fbc8:      	add	x23, x21, #0x18
    fbcc:      	mov	w8, #0x4                // =4
    fbd0:      	add	x9, sp, #0x98
    fbd4:      	add	x0, sp, #0x98
    fbd8:      	mov	w1, #0x8                // =8
    fbdc:      	mov	x2, x23
    fbe0:      	blr	x8
    fbe4:      	ldr	x8, [sp, #0x98]
    fbe8:      	cmp	x8, x21
    fbec:      	b.eq	0xfcb4 <generic_rawtp_path+0x59c4>
    fbf0:      	mov	w8, #0x4                // =4
    fbf4:      	add	x9, sp, #0x78
    fbf8:      	add	x0, sp, #0x78
    fbfc:      	mov	w1, #0x8                // =8
    fc00:      	mov	x2, x23
    fc04:      	blr	x8
    fc08:      	add	x2, x21, #0x20
    fc0c:      	mov	w8, #0x4                // =4
    fc10:      	mov	w9, #0x10               // =16
    fc14:      	add	x10, sp, #0x80
    fc18:      	add	x0, sp, #0x80
    fc1c:      	mov	w1, #0x10               // =16
    fc20:      	blr	x8
    fc24:      	ldr	w21, [sp, #0x84]
    fc28:      	ldr	x8, [sp, #0x40]
    fc2c:      	ldr	x10, [sp, #0x60]
    fc30:      	sub	x12, x10, x8
    fc34:      	ldr	w23, [sp, #0x68]
    fc38:      	subs	w10, w21, w23
    fc3c:      	ldr	x9, [sp, #0x88]
    fc40:      	csel	w10, wzr, w10, lo
    fc44:      	cmp	w23, w21
    fc48:      	csel	w11, w23, w21, lo
    fc4c:      	cinc	w13, w11, hi
    fc50:      	sub	w14, w23, w13
    fc54:      	subs	x12, x12, x13
    fc58:      	str	w14, [sp, #0x68]
    fc5c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    fc60:      	cmp	x12, #0xfff
    fc64:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    fc68:      	cmp	w23, w21
    fc6c:      	b.ls	0xfc78 <generic_rawtp_path+0x5988>
    fc70:      	mov	w13, #0x2f              // =47
    fc74:      	strb	w13, [x8, x12]
    fc78:      	add	x19, x8, x12
    fc7c:      	cmp	w23, w21
    fc80:      	add	x2, x9, x10
    fc84:      	and	w1, w11, #0xff
    fc88:      	mov	w8, #0x4                // =4
    fc8c:      	cinc	x0, x19, hi
    fc90:      	blr	x8
    fc94:      	cmp	w23, w21
    fc98:      	str	x19, [sp, #0x60]
    fc9c:      	add	x19, sp, #0x70
    fca0:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    fca4:      	ldr	x21, [sp, #0x78]
    fca8:      	ldp	x2, x24, [sp, #0x50]
    fcac:      	str	x21, [sp, #0x48]
    fcb0:      	b	0xfd00 <generic_rawtp_path+0x5a10>
    fcb4:      	add	x2, x24, #0x10
    fcb8:      	mov	w8, #0x4                // =4
    fcbc:      	add	x9, sp, #0x98
    fcc0:      	add	x0, sp, #0x98
    fcc4:      	mov	w1, #0x8                // =8
    fcc8:      	blr	x8
    fccc:      	ldr	x8, [sp, #0x58]
    fcd0:      	ldr	x9, [sp, #0x98]
    fcd4:      	cmp	x8, x9
    fcd8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    fcdc:      	add	x2, x24, #0x18
    fce0:      	mov	w8, #0x4                // =4
    fce4:      	mov	x0, x22
    fce8:      	mov	w1, #0x8                // =8
    fcec:      	blr	x8
    fcf0:      	ldr	x24, [sp, #0x98]
    fcf4:      	ldr	x21, [sp, #0x48]
    fcf8:      	add	x2, x24, #0x20
    fcfc:      	stp	x2, x24, [sp, #0x50]
    fd00:      	ldr	x8, [sp, #0x30]
    fd04:      	cmp	x21, x8
    fd08:      	b.ne	0xfd18 <generic_rawtp_path+0x5a28>
    fd0c:      	ldr	x8, [sp, #0x38]
    fd10:      	cmp	x2, x8
    fd14:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    fd18:      	mov	w8, #0x4                // =4
    fd1c:      	add	x0, sp, #0x70
    fd20:      	mov	w1, #0x8                // =8
    fd24:      	blr	x8
    fd28:      	ldr	x8, [sp, #0x70]
    fd2c:      	cmp	x21, x8
    fd30:      	b.eq	0xfe20 <generic_rawtp_path+0x5b30>
    fd34:      	add	x23, x21, #0x18
    fd38:      	mov	w8, #0x4                // =4
    fd3c:      	add	x9, sp, #0x98
    fd40:      	add	x0, sp, #0x98
    fd44:      	mov	w1, #0x8                // =8
    fd48:      	mov	x2, x23
    fd4c:      	blr	x8
    fd50:      	ldr	x8, [sp, #0x98]
    fd54:      	cmp	x8, x21
    fd58:      	b.eq	0xfe20 <generic_rawtp_path+0x5b30>
    fd5c:      	mov	w8, #0x4                // =4
    fd60:      	add	x9, sp, #0x78
    fd64:      	add	x0, sp, #0x78
    fd68:      	mov	w1, #0x8                // =8
    fd6c:      	mov	x2, x23
    fd70:      	blr	x8
    fd74:      	add	x2, x21, #0x20
    fd78:      	mov	w8, #0x4                // =4
    fd7c:      	mov	w9, #0x10               // =16
    fd80:      	add	x10, sp, #0x80
    fd84:      	add	x0, sp, #0x80
    fd88:      	mov	w1, #0x10               // =16
    fd8c:      	blr	x8
    fd90:      	ldr	w21, [sp, #0x84]
    fd94:      	ldr	x8, [sp, #0x40]
    fd98:      	ldr	x10, [sp, #0x60]
    fd9c:      	sub	x12, x10, x8
    fda0:      	ldr	w23, [sp, #0x68]
    fda4:      	subs	w10, w21, w23
    fda8:      	ldr	x9, [sp, #0x88]
    fdac:      	csel	w10, wzr, w10, lo
    fdb0:      	cmp	w23, w21
    fdb4:      	csel	w11, w23, w21, lo
    fdb8:      	cinc	w13, w11, hi
    fdbc:      	sub	w14, w23, w13
    fdc0:      	subs	x12, x12, x13
    fdc4:      	str	w14, [sp, #0x68]
    fdc8:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    fdcc:      	cmp	x12, #0xfff
    fdd0:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    fdd4:      	cmp	w23, w21
    fdd8:      	b.ls	0xfde4 <generic_rawtp_path+0x5af4>
    fddc:      	mov	w13, #0x2f              // =47
    fde0:      	strb	w13, [x8, x12]
    fde4:      	add	x19, x8, x12
    fde8:      	cmp	w23, w21
    fdec:      	add	x2, x9, x10
    fdf0:      	and	w1, w11, #0xff
    fdf4:      	mov	w8, #0x4                // =4
    fdf8:      	cinc	x0, x19, hi
    fdfc:      	blr	x8
    fe00:      	cmp	w23, w21
    fe04:      	str	x19, [sp, #0x60]
    fe08:      	add	x19, sp, #0x70
    fe0c:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    fe10:      	ldr	x21, [sp, #0x78]
    fe14:      	ldp	x2, x24, [sp, #0x50]
    fe18:      	str	x21, [sp, #0x48]
    fe1c:      	b	0xfe6c <generic_rawtp_path+0x5b7c>
    fe20:      	add	x2, x24, #0x10
    fe24:      	mov	w8, #0x4                // =4
    fe28:      	add	x9, sp, #0x98
    fe2c:      	add	x0, sp, #0x98
    fe30:      	mov	w1, #0x8                // =8
    fe34:      	blr	x8
    fe38:      	ldr	x8, [sp, #0x58]
    fe3c:      	ldr	x9, [sp, #0x98]
    fe40:      	cmp	x8, x9
    fe44:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    fe48:      	add	x2, x24, #0x18
    fe4c:      	mov	w8, #0x4                // =4
    fe50:      	mov	x0, x22
    fe54:      	mov	w1, #0x8                // =8
    fe58:      	blr	x8
    fe5c:      	ldr	x24, [sp, #0x98]
    fe60:      	ldr	x21, [sp, #0x48]
    fe64:      	add	x2, x24, #0x20
    fe68:      	stp	x2, x24, [sp, #0x50]
    fe6c:      	ldr	x8, [sp, #0x30]
    fe70:      	cmp	x21, x8
    fe74:      	b.ne	0xfe84 <generic_rawtp_path+0x5b94>
    fe78:      	ldr	x8, [sp, #0x38]
    fe7c:      	cmp	x2, x8
    fe80:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    fe84:      	mov	w8, #0x4                // =4
    fe88:      	add	x0, sp, #0x70
    fe8c:      	mov	w1, #0x8                // =8
    fe90:      	blr	x8
    fe94:      	ldr	x8, [sp, #0x70]
    fe98:      	cmp	x21, x8
    fe9c:      	b.eq	0xff8c <generic_rawtp_path+0x5c9c>
    fea0:      	add	x23, x21, #0x18
    fea4:      	mov	w8, #0x4                // =4
    fea8:      	add	x9, sp, #0x98
    feac:      	add	x0, sp, #0x98
    feb0:      	mov	w1, #0x8                // =8
    feb4:      	mov	x2, x23
    feb8:      	blr	x8
    febc:      	ldr	x8, [sp, #0x98]
    fec0:      	cmp	x8, x21
    fec4:      	b.eq	0xff8c <generic_rawtp_path+0x5c9c>
    fec8:      	mov	w8, #0x4                // =4
    fecc:      	add	x9, sp, #0x78
    fed0:      	add	x0, sp, #0x78
    fed4:      	mov	w1, #0x8                // =8
    fed8:      	mov	x2, x23
    fedc:      	blr	x8
    fee0:      	add	x2, x21, #0x20
    fee4:      	mov	w8, #0x4                // =4
    fee8:      	mov	w9, #0x10               // =16
    feec:      	add	x10, sp, #0x80
    fef0:      	add	x0, sp, #0x80
    fef4:      	mov	w1, #0x10               // =16
    fef8:      	blr	x8
    fefc:      	ldr	w21, [sp, #0x84]
    ff00:      	ldr	x8, [sp, #0x40]
    ff04:      	ldr	x10, [sp, #0x60]
    ff08:      	sub	x12, x10, x8
    ff0c:      	ldr	w23, [sp, #0x68]
    ff10:      	subs	w10, w21, w23
    ff14:      	ldr	x9, [sp, #0x88]
    ff18:      	csel	w10, wzr, w10, lo
    ff1c:      	cmp	w23, w21
    ff20:      	csel	w11, w23, w21, lo
    ff24:      	cinc	w13, w11, hi
    ff28:      	sub	w14, w23, w13
    ff2c:      	subs	x12, x12, x13
    ff30:      	str	w14, [sp, #0x68]
    ff34:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
    ff38:      	cmp	x12, #0xfff
    ff3c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
    ff40:      	cmp	w23, w21
    ff44:      	b.ls	0xff50 <generic_rawtp_path+0x5c60>
    ff48:      	mov	w13, #0x2f              // =47
    ff4c:      	strb	w13, [x8, x12]
    ff50:      	add	x19, x8, x12
    ff54:      	cmp	w23, w21
    ff58:      	add	x2, x9, x10
    ff5c:      	and	w1, w11, #0xff
    ff60:      	mov	w8, #0x4                // =4
    ff64:      	cinc	x0, x19, hi
    ff68:      	blr	x8
    ff6c:      	cmp	w23, w21
    ff70:      	str	x19, [sp, #0x60]
    ff74:      	add	x19, sp, #0x70
    ff78:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
    ff7c:      	ldr	x21, [sp, #0x78]
    ff80:      	ldp	x2, x24, [sp, #0x50]
    ff84:      	str	x21, [sp, #0x48]
    ff88:      	b	0xffd8 <generic_rawtp_path+0x5ce8>
    ff8c:      	add	x2, x24, #0x10
    ff90:      	mov	w8, #0x4                // =4
    ff94:      	add	x9, sp, #0x98
    ff98:      	add	x0, sp, #0x98
    ff9c:      	mov	w1, #0x8                // =8
    ffa0:      	blr	x8
    ffa4:      	ldr	x8, [sp, #0x58]
    ffa8:      	ldr	x9, [sp, #0x98]
    ffac:      	cmp	x8, x9
    ffb0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    ffb4:      	add	x2, x24, #0x18
    ffb8:      	mov	w8, #0x4                // =4
    ffbc:      	mov	x0, x22
    ffc0:      	mov	w1, #0x8                // =8
    ffc4:      	blr	x8
    ffc8:      	ldr	x24, [sp, #0x98]
    ffcc:      	ldr	x21, [sp, #0x48]
    ffd0:      	add	x2, x24, #0x20
    ffd4:      	stp	x2, x24, [sp, #0x50]
    ffd8:      	ldr	x8, [sp, #0x30]
    ffdc:      	cmp	x21, x8
    ffe0:      	b.ne	0xfff0 <generic_rawtp_path+0x5d00>
    ffe4:      	ldr	x8, [sp, #0x38]
    ffe8:      	cmp	x2, x8
    ffec:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
    fff0:      	mov	w8, #0x4                // =4
    fff4:      	add	x0, sp, #0x70
    fff8:      	mov	w1, #0x8                // =8
    fffc:      	blr	x8
   10000:      	ldr	x8, [sp, #0x70]
   10004:      	cmp	x21, x8
   10008:      	b.eq	0x100f8 <generic_rawtp_path+0x5e08>
   1000c:      	add	x23, x21, #0x18
   10010:      	mov	w8, #0x4                // =4
   10014:      	add	x9, sp, #0x98
   10018:      	add	x0, sp, #0x98
   1001c:      	mov	w1, #0x8                // =8
   10020:      	mov	x2, x23
   10024:      	blr	x8
   10028:      	ldr	x8, [sp, #0x98]
   1002c:      	cmp	x8, x21
   10030:      	b.eq	0x100f8 <generic_rawtp_path+0x5e08>
   10034:      	mov	w8, #0x4                // =4
   10038:      	add	x9, sp, #0x78
   1003c:      	add	x0, sp, #0x78
   10040:      	mov	w1, #0x8                // =8
   10044:      	mov	x2, x23
   10048:      	blr	x8
   1004c:      	add	x2, x21, #0x20
   10050:      	mov	w8, #0x4                // =4
   10054:      	mov	w9, #0x10               // =16
   10058:      	add	x10, sp, #0x80
   1005c:      	add	x0, sp, #0x80
   10060:      	mov	w1, #0x10               // =16
   10064:      	blr	x8
   10068:      	ldr	w21, [sp, #0x84]
   1006c:      	ldr	x8, [sp, #0x40]
   10070:      	ldr	x10, [sp, #0x60]
   10074:      	sub	x12, x10, x8
   10078:      	ldr	w23, [sp, #0x68]
   1007c:      	subs	w10, w21, w23
   10080:      	ldr	x9, [sp, #0x88]
   10084:      	csel	w10, wzr, w10, lo
   10088:      	cmp	w23, w21
   1008c:      	csel	w11, w23, w21, lo
   10090:      	cinc	w13, w11, hi
   10094:      	sub	w14, w23, w13
   10098:      	subs	x12, x12, x13
   1009c:      	str	w14, [sp, #0x68]
   100a0:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   100a4:      	cmp	x12, #0xfff
   100a8:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   100ac:      	cmp	w23, w21
   100b0:      	b.ls	0x100bc <generic_rawtp_path+0x5dcc>
   100b4:      	mov	w13, #0x2f              // =47
   100b8:      	strb	w13, [x8, x12]
   100bc:      	add	x19, x8, x12
   100c0:      	cmp	w23, w21
   100c4:      	add	x2, x9, x10
   100c8:      	and	w1, w11, #0xff
   100cc:      	mov	w8, #0x4                // =4
   100d0:      	cinc	x0, x19, hi
   100d4:      	blr	x8
   100d8:      	cmp	w23, w21
   100dc:      	str	x19, [sp, #0x60]
   100e0:      	add	x19, sp, #0x70
   100e4:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   100e8:      	ldr	x21, [sp, #0x78]
   100ec:      	ldp	x2, x24, [sp, #0x50]
   100f0:      	str	x21, [sp, #0x48]
   100f4:      	b	0x10144 <generic_rawtp_path+0x5e54>
   100f8:      	add	x2, x24, #0x10
   100fc:      	mov	w8, #0x4                // =4
   10100:      	add	x9, sp, #0x98
   10104:      	add	x0, sp, #0x98
   10108:      	mov	w1, #0x8                // =8
   1010c:      	blr	x8
   10110:      	ldr	x8, [sp, #0x58]
   10114:      	ldr	x9, [sp, #0x98]
   10118:      	cmp	x8, x9
   1011c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   10120:      	add	x2, x24, #0x18
   10124:      	mov	w8, #0x4                // =4
   10128:      	mov	x0, x22
   1012c:      	mov	w1, #0x8                // =8
   10130:      	blr	x8
   10134:      	ldr	x24, [sp, #0x98]
   10138:      	ldr	x21, [sp, #0x48]
   1013c:      	add	x2, x24, #0x20
   10140:      	stp	x2, x24, [sp, #0x50]
   10144:      	ldr	x8, [sp, #0x30]
   10148:      	cmp	x21, x8
   1014c:      	b.ne	0x1015c <generic_rawtp_path+0x5e6c>
   10150:      	ldr	x8, [sp, #0x38]
   10154:      	cmp	x2, x8
   10158:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   1015c:      	mov	w8, #0x4                // =4
   10160:      	add	x0, sp, #0x70
   10164:      	mov	w1, #0x8                // =8
   10168:      	blr	x8
   1016c:      	ldr	x8, [sp, #0x70]
   10170:      	cmp	x21, x8
   10174:      	b.eq	0x10264 <generic_rawtp_path+0x5f74>
   10178:      	add	x23, x21, #0x18
   1017c:      	mov	w8, #0x4                // =4
   10180:      	add	x9, sp, #0x98
   10184:      	add	x0, sp, #0x98
   10188:      	mov	w1, #0x8                // =8
   1018c:      	mov	x2, x23
   10190:      	blr	x8
   10194:      	ldr	x8, [sp, #0x98]
   10198:      	cmp	x8, x21
   1019c:      	b.eq	0x10264 <generic_rawtp_path+0x5f74>
   101a0:      	mov	w8, #0x4                // =4
   101a4:      	add	x9, sp, #0x78
   101a8:      	add	x0, sp, #0x78
   101ac:      	mov	w1, #0x8                // =8
   101b0:      	mov	x2, x23
   101b4:      	blr	x8
   101b8:      	add	x2, x21, #0x20
   101bc:      	mov	w8, #0x4                // =4
   101c0:      	mov	w9, #0x10               // =16
   101c4:      	add	x10, sp, #0x80
   101c8:      	add	x0, sp, #0x80
   101cc:      	mov	w1, #0x10               // =16
   101d0:      	blr	x8
   101d4:      	ldr	w21, [sp, #0x84]
   101d8:      	ldr	x8, [sp, #0x40]
   101dc:      	ldr	x10, [sp, #0x60]
   101e0:      	sub	x12, x10, x8
   101e4:      	ldr	w23, [sp, #0x68]
   101e8:      	subs	w10, w21, w23
   101ec:      	ldr	x9, [sp, #0x88]
   101f0:      	csel	w10, wzr, w10, lo
   101f4:      	cmp	w23, w21
   101f8:      	csel	w11, w23, w21, lo
   101fc:      	cinc	w13, w11, hi
   10200:      	sub	w14, w23, w13
   10204:      	subs	x12, x12, x13
   10208:      	str	w14, [sp, #0x68]
   1020c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   10210:      	cmp	x12, #0xfff
   10214:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   10218:      	cmp	w23, w21
   1021c:      	b.ls	0x10228 <generic_rawtp_path+0x5f38>
   10220:      	mov	w13, #0x2f              // =47
   10224:      	strb	w13, [x8, x12]
   10228:      	add	x19, x8, x12
   1022c:      	cmp	w23, w21
   10230:      	add	x2, x9, x10
   10234:      	and	w1, w11, #0xff
   10238:      	mov	w8, #0x4                // =4
   1023c:      	cinc	x0, x19, hi
   10240:      	blr	x8
   10244:      	cmp	w23, w21
   10248:      	str	x19, [sp, #0x60]
   1024c:      	add	x19, sp, #0x70
   10250:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   10254:      	ldr	x21, [sp, #0x78]
   10258:      	ldp	x2, x24, [sp, #0x50]
   1025c:      	str	x21, [sp, #0x48]
   10260:      	b	0x102b0 <generic_rawtp_path+0x5fc0>
   10264:      	add	x2, x24, #0x10
   10268:      	mov	w8, #0x4                // =4
   1026c:      	add	x9, sp, #0x98
   10270:      	add	x0, sp, #0x98
   10274:      	mov	w1, #0x8                // =8
   10278:      	blr	x8
   1027c:      	ldr	x8, [sp, #0x58]
   10280:      	ldr	x9, [sp, #0x98]
   10284:      	cmp	x8, x9
   10288:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   1028c:      	add	x2, x24, #0x18
   10290:      	mov	w8, #0x4                // =4
   10294:      	mov	x0, x22
   10298:      	mov	w1, #0x8                // =8
   1029c:      	blr	x8
   102a0:      	ldr	x24, [sp, #0x98]
   102a4:      	ldr	x21, [sp, #0x48]
   102a8:      	add	x2, x24, #0x20
   102ac:      	stp	x2, x24, [sp, #0x50]
   102b0:      	ldr	x8, [sp, #0x30]
   102b4:      	cmp	x21, x8
   102b8:      	b.ne	0x102c8 <generic_rawtp_path+0x5fd8>
   102bc:      	ldr	x8, [sp, #0x38]
   102c0:      	cmp	x2, x8
   102c4:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   102c8:      	mov	w8, #0x4                // =4
   102cc:      	add	x0, sp, #0x70
   102d0:      	mov	w1, #0x8                // =8
   102d4:      	blr	x8
   102d8:      	ldr	x8, [sp, #0x70]
   102dc:      	cmp	x21, x8
   102e0:      	b.eq	0x103d0 <generic_rawtp_path+0x60e0>
   102e4:      	add	x23, x21, #0x18
   102e8:      	mov	w8, #0x4                // =4
   102ec:      	add	x9, sp, #0x98
   102f0:      	add	x0, sp, #0x98
   102f4:      	mov	w1, #0x8                // =8
   102f8:      	mov	x2, x23
   102fc:      	blr	x8
   10300:      	ldr	x8, [sp, #0x98]
   10304:      	cmp	x8, x21
   10308:      	b.eq	0x103d0 <generic_rawtp_path+0x60e0>
   1030c:      	mov	w8, #0x4                // =4
   10310:      	add	x9, sp, #0x78
   10314:      	add	x0, sp, #0x78
   10318:      	mov	w1, #0x8                // =8
   1031c:      	mov	x2, x23
   10320:      	blr	x8
   10324:      	add	x2, x21, #0x20
   10328:      	mov	w8, #0x4                // =4
   1032c:      	mov	w9, #0x10               // =16
   10330:      	add	x10, sp, #0x80
   10334:      	add	x0, sp, #0x80
   10338:      	mov	w1, #0x10               // =16
   1033c:      	blr	x8
   10340:      	ldr	w21, [sp, #0x84]
   10344:      	ldr	x8, [sp, #0x40]
   10348:      	ldr	x10, [sp, #0x60]
   1034c:      	sub	x12, x10, x8
   10350:      	ldr	w23, [sp, #0x68]
   10354:      	subs	w10, w21, w23
   10358:      	ldr	x9, [sp, #0x88]
   1035c:      	csel	w10, wzr, w10, lo
   10360:      	cmp	w23, w21
   10364:      	csel	w11, w23, w21, lo
   10368:      	cinc	w13, w11, hi
   1036c:      	sub	w14, w23, w13
   10370:      	subs	x12, x12, x13
   10374:      	str	w14, [sp, #0x68]
   10378:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   1037c:      	cmp	x12, #0xfff
   10380:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   10384:      	cmp	w23, w21
   10388:      	b.ls	0x10394 <generic_rawtp_path+0x60a4>
   1038c:      	mov	w13, #0x2f              // =47
   10390:      	strb	w13, [x8, x12]
   10394:      	add	x19, x8, x12
   10398:      	cmp	w23, w21
   1039c:      	add	x2, x9, x10
   103a0:      	and	w1, w11, #0xff
   103a4:      	mov	w8, #0x4                // =4
   103a8:      	cinc	x0, x19, hi
   103ac:      	blr	x8
   103b0:      	cmp	w23, w21
   103b4:      	str	x19, [sp, #0x60]
   103b8:      	add	x19, sp, #0x70
   103bc:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   103c0:      	ldr	x21, [sp, #0x78]
   103c4:      	ldp	x2, x24, [sp, #0x50]
   103c8:      	str	x21, [sp, #0x48]
   103cc:      	b	0x1041c <generic_rawtp_path+0x612c>
   103d0:      	add	x2, x24, #0x10
   103d4:      	mov	w8, #0x4                // =4
   103d8:      	add	x9, sp, #0x98
   103dc:      	add	x0, sp, #0x98
   103e0:      	mov	w1, #0x8                // =8
   103e4:      	blr	x8
   103e8:      	ldr	x8, [sp, #0x58]
   103ec:      	ldr	x9, [sp, #0x98]
   103f0:      	cmp	x8, x9
   103f4:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   103f8:      	add	x2, x24, #0x18
   103fc:      	mov	w8, #0x4                // =4
   10400:      	mov	x0, x22
   10404:      	mov	w1, #0x8                // =8
   10408:      	blr	x8
   1040c:      	ldr	x24, [sp, #0x98]
   10410:      	ldr	x21, [sp, #0x48]
   10414:      	add	x2, x24, #0x20
   10418:      	stp	x2, x24, [sp, #0x50]
   1041c:      	ldr	x8, [sp, #0x30]
   10420:      	cmp	x21, x8
   10424:      	b.ne	0x10434 <generic_rawtp_path+0x6144>
   10428:      	ldr	x8, [sp, #0x38]
   1042c:      	cmp	x2, x8
   10430:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   10434:      	mov	w8, #0x4                // =4
   10438:      	add	x0, sp, #0x70
   1043c:      	mov	w1, #0x8                // =8
   10440:      	blr	x8
   10444:      	ldr	x8, [sp, #0x70]
   10448:      	cmp	x21, x8
   1044c:      	b.eq	0x1053c <generic_rawtp_path+0x624c>
   10450:      	add	x23, x21, #0x18
   10454:      	mov	w8, #0x4                // =4
   10458:      	add	x9, sp, #0x98
   1045c:      	add	x0, sp, #0x98
   10460:      	mov	w1, #0x8                // =8
   10464:      	mov	x2, x23
   10468:      	blr	x8
   1046c:      	ldr	x8, [sp, #0x98]
   10470:      	cmp	x8, x21
   10474:      	b.eq	0x1053c <generic_rawtp_path+0x624c>
   10478:      	mov	w8, #0x4                // =4
   1047c:      	add	x9, sp, #0x78
   10480:      	add	x0, sp, #0x78
   10484:      	mov	w1, #0x8                // =8
   10488:      	mov	x2, x23
   1048c:      	blr	x8
   10490:      	add	x2, x21, #0x20
   10494:      	mov	w8, #0x4                // =4
   10498:      	mov	w9, #0x10               // =16
   1049c:      	add	x10, sp, #0x80
   104a0:      	add	x0, sp, #0x80
   104a4:      	mov	w1, #0x10               // =16
   104a8:      	blr	x8
   104ac:      	ldr	w21, [sp, #0x84]
   104b0:      	ldr	x8, [sp, #0x40]
   104b4:      	ldr	x10, [sp, #0x60]
   104b8:      	sub	x12, x10, x8
   104bc:      	ldr	w23, [sp, #0x68]
   104c0:      	subs	w10, w21, w23
   104c4:      	ldr	x9, [sp, #0x88]
   104c8:      	csel	w10, wzr, w10, lo
   104cc:      	cmp	w23, w21
   104d0:      	csel	w11, w23, w21, lo
   104d4:      	cinc	w13, w11, hi
   104d8:      	sub	w14, w23, w13
   104dc:      	subs	x12, x12, x13
   104e0:      	str	w14, [sp, #0x68]
   104e4:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   104e8:      	cmp	x12, #0xfff
   104ec:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   104f0:      	cmp	w23, w21
   104f4:      	b.ls	0x10500 <generic_rawtp_path+0x6210>
   104f8:      	mov	w13, #0x2f              // =47
   104fc:      	strb	w13, [x8, x12]
   10500:      	add	x19, x8, x12
   10504:      	cmp	w23, w21
   10508:      	add	x2, x9, x10
   1050c:      	and	w1, w11, #0xff
   10510:      	mov	w8, #0x4                // =4
   10514:      	cinc	x0, x19, hi
   10518:      	blr	x8
   1051c:      	cmp	w23, w21
   10520:      	str	x19, [sp, #0x60]
   10524:      	add	x19, sp, #0x70
   10528:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   1052c:      	ldr	x21, [sp, #0x78]
   10530:      	ldp	x2, x24, [sp, #0x50]
   10534:      	str	x21, [sp, #0x48]
   10538:      	b	0x10588 <generic_rawtp_path+0x6298>
   1053c:      	add	x2, x24, #0x10
   10540:      	mov	w8, #0x4                // =4
   10544:      	add	x9, sp, #0x98
   10548:      	add	x0, sp, #0x98
   1054c:      	mov	w1, #0x8                // =8
   10550:      	blr	x8
   10554:      	ldr	x8, [sp, #0x58]
   10558:      	ldr	x9, [sp, #0x98]
   1055c:      	cmp	x8, x9
   10560:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   10564:      	add	x2, x24, #0x18
   10568:      	mov	w8, #0x4                // =4
   1056c:      	mov	x0, x22
   10570:      	mov	w1, #0x8                // =8
   10574:      	blr	x8
   10578:      	ldr	x24, [sp, #0x98]
   1057c:      	ldr	x21, [sp, #0x48]
   10580:      	add	x2, x24, #0x20
   10584:      	stp	x2, x24, [sp, #0x50]
   10588:      	ldr	x8, [sp, #0x30]
   1058c:      	cmp	x21, x8
   10590:      	b.ne	0x105a0 <generic_rawtp_path+0x62b0>
   10594:      	ldr	x8, [sp, #0x38]
   10598:      	cmp	x2, x8
   1059c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   105a0:      	mov	w8, #0x4                // =4
   105a4:      	add	x0, sp, #0x70
   105a8:      	mov	w1, #0x8                // =8
   105ac:      	blr	x8
   105b0:      	ldr	x8, [sp, #0x70]
   105b4:      	cmp	x21, x8
   105b8:      	b.eq	0x106a8 <generic_rawtp_path+0x63b8>
   105bc:      	add	x23, x21, #0x18
   105c0:      	mov	w8, #0x4                // =4
   105c4:      	add	x9, sp, #0x98
   105c8:      	add	x0, sp, #0x98
   105cc:      	mov	w1, #0x8                // =8
   105d0:      	mov	x2, x23
   105d4:      	blr	x8
   105d8:      	ldr	x8, [sp, #0x98]
   105dc:      	cmp	x8, x21
   105e0:      	b.eq	0x106a8 <generic_rawtp_path+0x63b8>
   105e4:      	mov	w8, #0x4                // =4
   105e8:      	add	x9, sp, #0x78
   105ec:      	add	x0, sp, #0x78
   105f0:      	mov	w1, #0x8                // =8
   105f4:      	mov	x2, x23
   105f8:      	blr	x8
   105fc:      	add	x2, x21, #0x20
   10600:      	mov	w8, #0x4                // =4
   10604:      	mov	w9, #0x10               // =16
   10608:      	add	x10, sp, #0x80
   1060c:      	add	x0, sp, #0x80
   10610:      	mov	w1, #0x10               // =16
   10614:      	blr	x8
   10618:      	ldr	w21, [sp, #0x84]
   1061c:      	ldr	x8, [sp, #0x40]
   10620:      	ldr	x10, [sp, #0x60]
   10624:      	sub	x12, x10, x8
   10628:      	ldr	w23, [sp, #0x68]
   1062c:      	subs	w10, w21, w23
   10630:      	ldr	x9, [sp, #0x88]
   10634:      	csel	w10, wzr, w10, lo
   10638:      	cmp	w23, w21
   1063c:      	csel	w11, w23, w21, lo
   10640:      	cinc	w13, w11, hi
   10644:      	sub	w14, w23, w13
   10648:      	subs	x12, x12, x13
   1064c:      	str	w14, [sp, #0x68]
   10650:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   10654:      	cmp	x12, #0xfff
   10658:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   1065c:      	cmp	w23, w21
   10660:      	b.ls	0x1066c <generic_rawtp_path+0x637c>
   10664:      	mov	w13, #0x2f              // =47
   10668:      	strb	w13, [x8, x12]
   1066c:      	add	x19, x8, x12
   10670:      	cmp	w23, w21
   10674:      	add	x2, x9, x10
   10678:      	and	w1, w11, #0xff
   1067c:      	mov	w8, #0x4                // =4
   10680:      	cinc	x0, x19, hi
   10684:      	blr	x8
   10688:      	cmp	w23, w21
   1068c:      	str	x19, [sp, #0x60]
   10690:      	add	x19, sp, #0x70
   10694:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   10698:      	ldr	x21, [sp, #0x78]
   1069c:      	ldp	x2, x24, [sp, #0x50]
   106a0:      	str	x21, [sp, #0x48]
   106a4:      	b	0x106f4 <generic_rawtp_path+0x6404>
   106a8:      	add	x2, x24, #0x10
   106ac:      	mov	w8, #0x4                // =4
   106b0:      	add	x9, sp, #0x98
   106b4:      	add	x0, sp, #0x98
   106b8:      	mov	w1, #0x8                // =8
   106bc:      	blr	x8
   106c0:      	ldr	x8, [sp, #0x58]
   106c4:      	ldr	x9, [sp, #0x98]
   106c8:      	cmp	x8, x9
   106cc:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   106d0:      	add	x2, x24, #0x18
   106d4:      	mov	w8, #0x4                // =4
   106d8:      	mov	x0, x22
   106dc:      	mov	w1, #0x8                // =8
   106e0:      	blr	x8
   106e4:      	ldr	x24, [sp, #0x98]
   106e8:      	ldr	x21, [sp, #0x48]
   106ec:      	add	x2, x24, #0x20
   106f0:      	stp	x2, x24, [sp, #0x50]
   106f4:      	ldr	x8, [sp, #0x30]
   106f8:      	cmp	x21, x8
   106fc:      	b.ne	0x1070c <generic_rawtp_path+0x641c>
   10700:      	ldr	x8, [sp, #0x38]
   10704:      	cmp	x2, x8
   10708:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   1070c:      	mov	w8, #0x4                // =4
   10710:      	add	x0, sp, #0x70
   10714:      	mov	w1, #0x8                // =8
   10718:      	blr	x8
   1071c:      	ldr	x8, [sp, #0x70]
   10720:      	cmp	x21, x8
   10724:      	b.eq	0x10814 <generic_rawtp_path+0x6524>
   10728:      	add	x23, x21, #0x18
   1072c:      	mov	w8, #0x4                // =4
   10730:      	add	x9, sp, #0x98
   10734:      	add	x0, sp, #0x98
   10738:      	mov	w1, #0x8                // =8
   1073c:      	mov	x2, x23
   10740:      	blr	x8
   10744:      	ldr	x8, [sp, #0x98]
   10748:      	cmp	x8, x21
   1074c:      	b.eq	0x10814 <generic_rawtp_path+0x6524>
   10750:      	mov	w8, #0x4                // =4
   10754:      	add	x9, sp, #0x78
   10758:      	add	x0, sp, #0x78
   1075c:      	mov	w1, #0x8                // =8
   10760:      	mov	x2, x23
   10764:      	blr	x8
   10768:      	add	x2, x21, #0x20
   1076c:      	mov	w8, #0x4                // =4
   10770:      	mov	w9, #0x10               // =16
   10774:      	add	x10, sp, #0x80
   10778:      	add	x0, sp, #0x80
   1077c:      	mov	w1, #0x10               // =16
   10780:      	blr	x8
   10784:      	ldr	w21, [sp, #0x84]
   10788:      	ldr	x8, [sp, #0x40]
   1078c:      	ldr	x10, [sp, #0x60]
   10790:      	sub	x12, x10, x8
   10794:      	ldr	w23, [sp, #0x68]
   10798:      	subs	w10, w21, w23
   1079c:      	ldr	x9, [sp, #0x88]
   107a0:      	csel	w10, wzr, w10, lo
   107a4:      	cmp	w23, w21
   107a8:      	csel	w11, w23, w21, lo
   107ac:      	cinc	w13, w11, hi
   107b0:      	sub	w14, w23, w13
   107b4:      	subs	x12, x12, x13
   107b8:      	str	w14, [sp, #0x68]
   107bc:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   107c0:      	cmp	x12, #0xfff
   107c4:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   107c8:      	cmp	w23, w21
   107cc:      	b.ls	0x107d8 <generic_rawtp_path+0x64e8>
   107d0:      	mov	w13, #0x2f              // =47
   107d4:      	strb	w13, [x8, x12]
   107d8:      	add	x19, x8, x12
   107dc:      	cmp	w23, w21
   107e0:      	add	x2, x9, x10
   107e4:      	and	w1, w11, #0xff
   107e8:      	mov	w8, #0x4                // =4
   107ec:      	cinc	x0, x19, hi
   107f0:      	blr	x8
   107f4:      	cmp	w23, w21
   107f8:      	str	x19, [sp, #0x60]
   107fc:      	add	x19, sp, #0x70
   10800:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   10804:      	ldr	x21, [sp, #0x78]
   10808:      	ldp	x2, x24, [sp, #0x50]
   1080c:      	str	x21, [sp, #0x48]
   10810:      	b	0x10860 <generic_rawtp_path+0x6570>
   10814:      	add	x2, x24, #0x10
   10818:      	mov	w8, #0x4                // =4
   1081c:      	add	x9, sp, #0x98
   10820:      	add	x0, sp, #0x98
   10824:      	mov	w1, #0x8                // =8
   10828:      	blr	x8
   1082c:      	ldr	x8, [sp, #0x58]
   10830:      	ldr	x9, [sp, #0x98]
   10834:      	cmp	x8, x9
   10838:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   1083c:      	add	x2, x24, #0x18
   10840:      	mov	w8, #0x4                // =4
   10844:      	mov	x0, x22
   10848:      	mov	w1, #0x8                // =8
   1084c:      	blr	x8
   10850:      	ldr	x24, [sp, #0x98]
   10854:      	ldr	x21, [sp, #0x48]
   10858:      	add	x2, x24, #0x20
   1085c:      	stp	x2, x24, [sp, #0x50]
   10860:      	ldr	x8, [sp, #0x30]
   10864:      	cmp	x21, x8
   10868:      	b.ne	0x10878 <generic_rawtp_path+0x6588>
   1086c:      	ldr	x8, [sp, #0x38]
   10870:      	cmp	x2, x8
   10874:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   10878:      	mov	w8, #0x4                // =4
   1087c:      	add	x0, sp, #0x70
   10880:      	mov	w1, #0x8                // =8
   10884:      	blr	x8
   10888:      	ldr	x8, [sp, #0x70]
   1088c:      	cmp	x21, x8
   10890:      	b.eq	0x10980 <generic_rawtp_path+0x6690>
   10894:      	add	x23, x21, #0x18
   10898:      	mov	w8, #0x4                // =4
   1089c:      	add	x9, sp, #0x98
   108a0:      	add	x0, sp, #0x98
   108a4:      	mov	w1, #0x8                // =8
   108a8:      	mov	x2, x23
   108ac:      	blr	x8
   108b0:      	ldr	x8, [sp, #0x98]
   108b4:      	cmp	x8, x21
   108b8:      	b.eq	0x10980 <generic_rawtp_path+0x6690>
   108bc:      	mov	w8, #0x4                // =4
   108c0:      	add	x9, sp, #0x78
   108c4:      	add	x0, sp, #0x78
   108c8:      	mov	w1, #0x8                // =8
   108cc:      	mov	x2, x23
   108d0:      	blr	x8
   108d4:      	add	x2, x21, #0x20
   108d8:      	mov	w8, #0x4                // =4
   108dc:      	mov	w9, #0x10               // =16
   108e0:      	add	x10, sp, #0x80
   108e4:      	add	x0, sp, #0x80
   108e8:      	mov	w1, #0x10               // =16
   108ec:      	blr	x8
   108f0:      	ldr	w21, [sp, #0x84]
   108f4:      	ldr	x8, [sp, #0x40]
   108f8:      	ldr	x10, [sp, #0x60]
   108fc:      	sub	x12, x10, x8
   10900:      	ldr	w23, [sp, #0x68]
   10904:      	subs	w10, w21, w23
   10908:      	ldr	x9, [sp, #0x88]
   1090c:      	csel	w10, wzr, w10, lo
   10910:      	cmp	w23, w21
   10914:      	csel	w11, w23, w21, lo
   10918:      	cinc	w13, w11, hi
   1091c:      	sub	w14, w23, w13
   10920:      	subs	x12, x12, x13
   10924:      	str	w14, [sp, #0x68]
   10928:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   1092c:      	cmp	x12, #0xfff
   10930:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   10934:      	cmp	w23, w21
   10938:      	b.ls	0x10944 <generic_rawtp_path+0x6654>
   1093c:      	mov	w13, #0x2f              // =47
   10940:      	strb	w13, [x8, x12]
   10944:      	add	x19, x8, x12
   10948:      	cmp	w23, w21
   1094c:      	add	x2, x9, x10
   10950:      	and	w1, w11, #0xff
   10954:      	mov	w8, #0x4                // =4
   10958:      	cinc	x0, x19, hi
   1095c:      	blr	x8
   10960:      	cmp	w23, w21
   10964:      	str	x19, [sp, #0x60]
   10968:      	add	x19, sp, #0x70
   1096c:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   10970:      	ldr	x21, [sp, #0x78]
   10974:      	ldp	x2, x24, [sp, #0x50]
   10978:      	str	x21, [sp, #0x48]
   1097c:      	b	0x109cc <generic_rawtp_path+0x66dc>
   10980:      	add	x2, x24, #0x10
   10984:      	mov	w8, #0x4                // =4
   10988:      	add	x9, sp, #0x98
   1098c:      	add	x0, sp, #0x98
   10990:      	mov	w1, #0x8                // =8
   10994:      	blr	x8
   10998:      	ldr	x8, [sp, #0x58]
   1099c:      	ldr	x9, [sp, #0x98]
   109a0:      	cmp	x8, x9
   109a4:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   109a8:      	add	x2, x24, #0x18
   109ac:      	mov	w8, #0x4                // =4
   109b0:      	mov	x0, x22
   109b4:      	mov	w1, #0x8                // =8
   109b8:      	blr	x8
   109bc:      	ldr	x24, [sp, #0x98]
   109c0:      	ldr	x21, [sp, #0x48]
   109c4:      	add	x2, x24, #0x20
   109c8:      	stp	x2, x24, [sp, #0x50]
   109cc:      	ldr	x8, [sp, #0x30]
   109d0:      	cmp	x21, x8
   109d4:      	b.ne	0x109e4 <generic_rawtp_path+0x66f4>
   109d8:      	ldr	x8, [sp, #0x38]
   109dc:      	cmp	x2, x8
   109e0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   109e4:      	mov	w8, #0x4                // =4
   109e8:      	add	x0, sp, #0x70
   109ec:      	mov	w1, #0x8                // =8
   109f0:      	blr	x8
   109f4:      	ldr	x8, [sp, #0x70]
   109f8:      	cmp	x21, x8
   109fc:      	b.eq	0x10aec <generic_rawtp_path+0x67fc>
   10a00:      	add	x23, x21, #0x18
   10a04:      	mov	w8, #0x4                // =4
   10a08:      	add	x9, sp, #0x98
   10a0c:      	add	x0, sp, #0x98
   10a10:      	mov	w1, #0x8                // =8
   10a14:      	mov	x2, x23
   10a18:      	blr	x8
   10a1c:      	ldr	x8, [sp, #0x98]
   10a20:      	cmp	x8, x21
   10a24:      	b.eq	0x10aec <generic_rawtp_path+0x67fc>
   10a28:      	mov	w8, #0x4                // =4
   10a2c:      	add	x9, sp, #0x78
   10a30:      	add	x0, sp, #0x78
   10a34:      	mov	w1, #0x8                // =8
   10a38:      	mov	x2, x23
   10a3c:      	blr	x8
   10a40:      	add	x2, x21, #0x20
   10a44:      	mov	w8, #0x4                // =4
   10a48:      	mov	w9, #0x10               // =16
   10a4c:      	add	x10, sp, #0x80
   10a50:      	add	x0, sp, #0x80
   10a54:      	mov	w1, #0x10               // =16
   10a58:      	blr	x8
   10a5c:      	ldr	w21, [sp, #0x84]
   10a60:      	ldr	x8, [sp, #0x40]
   10a64:      	ldr	x10, [sp, #0x60]
   10a68:      	sub	x12, x10, x8
   10a6c:      	ldr	w23, [sp, #0x68]
   10a70:      	subs	w10, w21, w23
   10a74:      	ldr	x9, [sp, #0x88]
   10a78:      	csel	w10, wzr, w10, lo
   10a7c:      	cmp	w23, w21
   10a80:      	csel	w11, w23, w21, lo
   10a84:      	cinc	w13, w11, hi
   10a88:      	sub	w14, w23, w13
   10a8c:      	subs	x12, x12, x13
   10a90:      	str	w14, [sp, #0x68]
   10a94:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   10a98:      	cmp	x12, #0xfff
   10a9c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   10aa0:      	cmp	w23, w21
   10aa4:      	b.ls	0x10ab0 <generic_rawtp_path+0x67c0>
   10aa8:      	mov	w13, #0x2f              // =47
   10aac:      	strb	w13, [x8, x12]
   10ab0:      	add	x19, x8, x12
   10ab4:      	cmp	w23, w21
   10ab8:      	add	x2, x9, x10
   10abc:      	and	w1, w11, #0xff
   10ac0:      	mov	w8, #0x4                // =4
   10ac4:      	cinc	x0, x19, hi
   10ac8:      	blr	x8
   10acc:      	cmp	w23, w21
   10ad0:      	str	x19, [sp, #0x60]
   10ad4:      	add	x19, sp, #0x70
   10ad8:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   10adc:      	ldr	x21, [sp, #0x78]
   10ae0:      	ldp	x2, x24, [sp, #0x50]
   10ae4:      	str	x21, [sp, #0x48]
   10ae8:      	b	0x10b38 <generic_rawtp_path+0x6848>
   10aec:      	add	x2, x24, #0x10
   10af0:      	mov	w8, #0x4                // =4
   10af4:      	add	x9, sp, #0x98
   10af8:      	add	x0, sp, #0x98
   10afc:      	mov	w1, #0x8                // =8
   10b00:      	blr	x8
   10b04:      	ldr	x8, [sp, #0x58]
   10b08:      	ldr	x9, [sp, #0x98]
   10b0c:      	cmp	x8, x9
   10b10:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   10b14:      	add	x2, x24, #0x18
   10b18:      	mov	w8, #0x4                // =4
   10b1c:      	mov	x0, x22
   10b20:      	mov	w1, #0x8                // =8
   10b24:      	blr	x8
   10b28:      	ldr	x24, [sp, #0x98]
   10b2c:      	ldr	x21, [sp, #0x48]
   10b30:      	add	x2, x24, #0x20
   10b34:      	stp	x2, x24, [sp, #0x50]
   10b38:      	ldr	x8, [sp, #0x30]
   10b3c:      	cmp	x21, x8
   10b40:      	b.ne	0x10b50 <generic_rawtp_path+0x6860>
   10b44:      	ldr	x8, [sp, #0x38]
   10b48:      	cmp	x2, x8
   10b4c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   10b50:      	mov	w8, #0x4                // =4
   10b54:      	add	x0, sp, #0x70
   10b58:      	mov	w1, #0x8                // =8
   10b5c:      	blr	x8
   10b60:      	ldr	x8, [sp, #0x70]
   10b64:      	cmp	x21, x8
   10b68:      	b.eq	0x10c58 <generic_rawtp_path+0x6968>
   10b6c:      	add	x23, x21, #0x18
   10b70:      	mov	w8, #0x4                // =4
   10b74:      	add	x9, sp, #0x98
   10b78:      	add	x0, sp, #0x98
   10b7c:      	mov	w1, #0x8                // =8
   10b80:      	mov	x2, x23
   10b84:      	blr	x8
   10b88:      	ldr	x8, [sp, #0x98]
   10b8c:      	cmp	x8, x21
   10b90:      	b.eq	0x10c58 <generic_rawtp_path+0x6968>
   10b94:      	mov	w8, #0x4                // =4
   10b98:      	add	x9, sp, #0x78
   10b9c:      	add	x0, sp, #0x78
   10ba0:      	mov	w1, #0x8                // =8
   10ba4:      	mov	x2, x23
   10ba8:      	blr	x8
   10bac:      	add	x2, x21, #0x20
   10bb0:      	mov	w8, #0x4                // =4
   10bb4:      	mov	w9, #0x10               // =16
   10bb8:      	add	x10, sp, #0x80
   10bbc:      	add	x0, sp, #0x80
   10bc0:      	mov	w1, #0x10               // =16
   10bc4:      	blr	x8
   10bc8:      	ldr	w21, [sp, #0x84]
   10bcc:      	ldr	x8, [sp, #0x40]
   10bd0:      	ldr	x10, [sp, #0x60]
   10bd4:      	sub	x12, x10, x8
   10bd8:      	ldr	w23, [sp, #0x68]
   10bdc:      	subs	w10, w21, w23
   10be0:      	ldr	x9, [sp, #0x88]
   10be4:      	csel	w10, wzr, w10, lo
   10be8:      	cmp	w23, w21
   10bec:      	csel	w11, w23, w21, lo
   10bf0:      	cinc	w13, w11, hi
   10bf4:      	sub	w14, w23, w13
   10bf8:      	subs	x12, x12, x13
   10bfc:      	str	w14, [sp, #0x68]
   10c00:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   10c04:      	cmp	x12, #0xfff
   10c08:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   10c0c:      	cmp	w23, w21
   10c10:      	b.ls	0x10c1c <generic_rawtp_path+0x692c>
   10c14:      	mov	w13, #0x2f              // =47
   10c18:      	strb	w13, [x8, x12]
   10c1c:      	add	x19, x8, x12
   10c20:      	cmp	w23, w21
   10c24:      	add	x2, x9, x10
   10c28:      	and	w1, w11, #0xff
   10c2c:      	mov	w8, #0x4                // =4
   10c30:      	cinc	x0, x19, hi
   10c34:      	blr	x8
   10c38:      	cmp	w23, w21
   10c3c:      	str	x19, [sp, #0x60]
   10c40:      	add	x19, sp, #0x70
   10c44:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   10c48:      	ldr	x21, [sp, #0x78]
   10c4c:      	ldp	x2, x24, [sp, #0x50]
   10c50:      	str	x21, [sp, #0x48]
   10c54:      	b	0x10ca4 <generic_rawtp_path+0x69b4>
   10c58:      	add	x2, x24, #0x10
   10c5c:      	mov	w8, #0x4                // =4
   10c60:      	add	x9, sp, #0x98
   10c64:      	add	x0, sp, #0x98
   10c68:      	mov	w1, #0x8                // =8
   10c6c:      	blr	x8
   10c70:      	ldr	x8, [sp, #0x58]
   10c74:      	ldr	x9, [sp, #0x98]
   10c78:      	cmp	x8, x9
   10c7c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   10c80:      	add	x2, x24, #0x18
   10c84:      	mov	w8, #0x4                // =4
   10c88:      	mov	x0, x22
   10c8c:      	mov	w1, #0x8                // =8
   10c90:      	blr	x8
   10c94:      	ldr	x24, [sp, #0x98]
   10c98:      	ldr	x21, [sp, #0x48]
   10c9c:      	add	x2, x24, #0x20
   10ca0:      	stp	x2, x24, [sp, #0x50]
   10ca4:      	ldr	x8, [sp, #0x30]
   10ca8:      	cmp	x21, x8
   10cac:      	b.ne	0x10cbc <generic_rawtp_path+0x69cc>
   10cb0:      	ldr	x8, [sp, #0x38]
   10cb4:      	cmp	x2, x8
   10cb8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   10cbc:      	mov	w8, #0x4                // =4
   10cc0:      	add	x0, sp, #0x70
   10cc4:      	mov	w1, #0x8                // =8
   10cc8:      	blr	x8
   10ccc:      	ldr	x8, [sp, #0x70]
   10cd0:      	cmp	x21, x8
   10cd4:      	b.eq	0x10dc4 <generic_rawtp_path+0x6ad4>
   10cd8:      	add	x23, x21, #0x18
   10cdc:      	mov	w8, #0x4                // =4
   10ce0:      	add	x9, sp, #0x98
   10ce4:      	add	x0, sp, #0x98
   10ce8:      	mov	w1, #0x8                // =8
   10cec:      	mov	x2, x23
   10cf0:      	blr	x8
   10cf4:      	ldr	x8, [sp, #0x98]
   10cf8:      	cmp	x8, x21
   10cfc:      	b.eq	0x10dc4 <generic_rawtp_path+0x6ad4>
   10d00:      	mov	w8, #0x4                // =4
   10d04:      	add	x9, sp, #0x78
   10d08:      	add	x0, sp, #0x78
   10d0c:      	mov	w1, #0x8                // =8
   10d10:      	mov	x2, x23
   10d14:      	blr	x8
   10d18:      	add	x2, x21, #0x20
   10d1c:      	mov	w8, #0x4                // =4
   10d20:      	mov	w9, #0x10               // =16
   10d24:      	add	x10, sp, #0x80
   10d28:      	add	x0, sp, #0x80
   10d2c:      	mov	w1, #0x10               // =16
   10d30:      	blr	x8
   10d34:      	ldr	w21, [sp, #0x84]
   10d38:      	ldr	x8, [sp, #0x40]
   10d3c:      	ldr	x10, [sp, #0x60]
   10d40:      	sub	x12, x10, x8
   10d44:      	ldr	w23, [sp, #0x68]
   10d48:      	subs	w10, w21, w23
   10d4c:      	ldr	x9, [sp, #0x88]
   10d50:      	csel	w10, wzr, w10, lo
   10d54:      	cmp	w23, w21
   10d58:      	csel	w11, w23, w21, lo
   10d5c:      	cinc	w13, w11, hi
   10d60:      	sub	w14, w23, w13
   10d64:      	subs	x12, x12, x13
   10d68:      	str	w14, [sp, #0x68]
   10d6c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   10d70:      	cmp	x12, #0xfff
   10d74:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   10d78:      	cmp	w23, w21
   10d7c:      	b.ls	0x10d88 <generic_rawtp_path+0x6a98>
   10d80:      	mov	w13, #0x2f              // =47
   10d84:      	strb	w13, [x8, x12]
   10d88:      	add	x19, x8, x12
   10d8c:      	cmp	w23, w21
   10d90:      	add	x2, x9, x10
   10d94:      	and	w1, w11, #0xff
   10d98:      	mov	w8, #0x4                // =4
   10d9c:      	cinc	x0, x19, hi
   10da0:      	blr	x8
   10da4:      	cmp	w23, w21
   10da8:      	str	x19, [sp, #0x60]
   10dac:      	add	x19, sp, #0x70
   10db0:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   10db4:      	ldr	x21, [sp, #0x78]
   10db8:      	ldp	x2, x24, [sp, #0x50]
   10dbc:      	str	x21, [sp, #0x48]
   10dc0:      	b	0x10e10 <generic_rawtp_path+0x6b20>
   10dc4:      	add	x2, x24, #0x10
   10dc8:      	mov	w8, #0x4                // =4
   10dcc:      	add	x9, sp, #0x98
   10dd0:      	add	x0, sp, #0x98
   10dd4:      	mov	w1, #0x8                // =8
   10dd8:      	blr	x8
   10ddc:      	ldr	x8, [sp, #0x58]
   10de0:      	ldr	x9, [sp, #0x98]
   10de4:      	cmp	x8, x9
   10de8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   10dec:      	add	x2, x24, #0x18
   10df0:      	mov	w8, #0x4                // =4
   10df4:      	mov	x0, x22
   10df8:      	mov	w1, #0x8                // =8
   10dfc:      	blr	x8
   10e00:      	ldr	x24, [sp, #0x98]
   10e04:      	ldr	x21, [sp, #0x48]
   10e08:      	add	x2, x24, #0x20
   10e0c:      	stp	x2, x24, [sp, #0x50]
   10e10:      	ldr	x8, [sp, #0x30]
   10e14:      	cmp	x21, x8
   10e18:      	b.ne	0x10e28 <generic_rawtp_path+0x6b38>
   10e1c:      	ldr	x8, [sp, #0x38]
   10e20:      	cmp	x2, x8
   10e24:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   10e28:      	mov	w8, #0x4                // =4
   10e2c:      	add	x0, sp, #0x70
   10e30:      	mov	w1, #0x8                // =8
   10e34:      	blr	x8
   10e38:      	ldr	x8, [sp, #0x70]
   10e3c:      	cmp	x21, x8
   10e40:      	b.eq	0x10f30 <generic_rawtp_path+0x6c40>
   10e44:      	add	x23, x21, #0x18
   10e48:      	mov	w8, #0x4                // =4
   10e4c:      	add	x9, sp, #0x98
   10e50:      	add	x0, sp, #0x98
   10e54:      	mov	w1, #0x8                // =8
   10e58:      	mov	x2, x23
   10e5c:      	blr	x8
   10e60:      	ldr	x8, [sp, #0x98]
   10e64:      	cmp	x8, x21
   10e68:      	b.eq	0x10f30 <generic_rawtp_path+0x6c40>
   10e6c:      	mov	w8, #0x4                // =4
   10e70:      	add	x9, sp, #0x78
   10e74:      	add	x0, sp, #0x78
   10e78:      	mov	w1, #0x8                // =8
   10e7c:      	mov	x2, x23
   10e80:      	blr	x8
   10e84:      	add	x2, x21, #0x20
   10e88:      	mov	w8, #0x4                // =4
   10e8c:      	mov	w9, #0x10               // =16
   10e90:      	add	x10, sp, #0x80
   10e94:      	add	x0, sp, #0x80
   10e98:      	mov	w1, #0x10               // =16
   10e9c:      	blr	x8
   10ea0:      	ldr	w21, [sp, #0x84]
   10ea4:      	ldr	x8, [sp, #0x40]
   10ea8:      	ldr	x10, [sp, #0x60]
   10eac:      	sub	x12, x10, x8
   10eb0:      	ldr	w23, [sp, #0x68]
   10eb4:      	subs	w10, w21, w23
   10eb8:      	ldr	x9, [sp, #0x88]
   10ebc:      	csel	w10, wzr, w10, lo
   10ec0:      	cmp	w23, w21
   10ec4:      	csel	w11, w23, w21, lo
   10ec8:      	cinc	w13, w11, hi
   10ecc:      	sub	w14, w23, w13
   10ed0:      	subs	x12, x12, x13
   10ed4:      	str	w14, [sp, #0x68]
   10ed8:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   10edc:      	cmp	x12, #0xfff
   10ee0:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   10ee4:      	cmp	w23, w21
   10ee8:      	b.ls	0x10ef4 <generic_rawtp_path+0x6c04>
   10eec:      	mov	w13, #0x2f              // =47
   10ef0:      	strb	w13, [x8, x12]
   10ef4:      	add	x19, x8, x12
   10ef8:      	cmp	w23, w21
   10efc:      	add	x2, x9, x10
   10f00:      	and	w1, w11, #0xff
   10f04:      	mov	w8, #0x4                // =4
   10f08:      	cinc	x0, x19, hi
   10f0c:      	blr	x8
   10f10:      	cmp	w23, w21
   10f14:      	str	x19, [sp, #0x60]
   10f18:      	add	x19, sp, #0x70
   10f1c:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   10f20:      	ldr	x21, [sp, #0x78]
   10f24:      	ldp	x2, x24, [sp, #0x50]
   10f28:      	str	x21, [sp, #0x48]
   10f2c:      	b	0x10f7c <generic_rawtp_path+0x6c8c>
   10f30:      	add	x2, x24, #0x10
   10f34:      	mov	w8, #0x4                // =4
   10f38:      	add	x9, sp, #0x98
   10f3c:      	add	x0, sp, #0x98
   10f40:      	mov	w1, #0x8                // =8
   10f44:      	blr	x8
   10f48:      	ldr	x8, [sp, #0x58]
   10f4c:      	ldr	x9, [sp, #0x98]
   10f50:      	cmp	x8, x9
   10f54:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   10f58:      	add	x2, x24, #0x18
   10f5c:      	mov	w8, #0x4                // =4
   10f60:      	mov	x0, x22
   10f64:      	mov	w1, #0x8                // =8
   10f68:      	blr	x8
   10f6c:      	ldr	x24, [sp, #0x98]
   10f70:      	ldr	x21, [sp, #0x48]
   10f74:      	add	x2, x24, #0x20
   10f78:      	stp	x2, x24, [sp, #0x50]
   10f7c:      	ldr	x8, [sp, #0x30]
   10f80:      	cmp	x21, x8
   10f84:      	b.ne	0x10f94 <generic_rawtp_path+0x6ca4>
   10f88:      	ldr	x8, [sp, #0x38]
   10f8c:      	cmp	x2, x8
   10f90:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   10f94:      	mov	w8, #0x4                // =4
   10f98:      	add	x0, sp, #0x70
   10f9c:      	mov	w1, #0x8                // =8
   10fa0:      	blr	x8
   10fa4:      	ldr	x8, [sp, #0x70]
   10fa8:      	cmp	x21, x8
   10fac:      	b.eq	0x1109c <generic_rawtp_path+0x6dac>
   10fb0:      	add	x23, x21, #0x18
   10fb4:      	mov	w8, #0x4                // =4
   10fb8:      	add	x9, sp, #0x98
   10fbc:      	add	x0, sp, #0x98
   10fc0:      	mov	w1, #0x8                // =8
   10fc4:      	mov	x2, x23
   10fc8:      	blr	x8
   10fcc:      	ldr	x8, [sp, #0x98]
   10fd0:      	cmp	x8, x21
   10fd4:      	b.eq	0x1109c <generic_rawtp_path+0x6dac>
   10fd8:      	mov	w8, #0x4                // =4
   10fdc:      	add	x9, sp, #0x78
   10fe0:      	add	x0, sp, #0x78
   10fe4:      	mov	w1, #0x8                // =8
   10fe8:      	mov	x2, x23
   10fec:      	blr	x8
   10ff0:      	add	x2, x21, #0x20
   10ff4:      	mov	w8, #0x4                // =4
   10ff8:      	mov	w9, #0x10               // =16
   10ffc:      	add	x10, sp, #0x80
   11000:      	add	x0, sp, #0x80
   11004:      	mov	w1, #0x10               // =16
   11008:      	blr	x8
   1100c:      	ldr	w21, [sp, #0x84]
   11010:      	ldr	x8, [sp, #0x40]
   11014:      	ldr	x10, [sp, #0x60]
   11018:      	sub	x12, x10, x8
   1101c:      	ldr	w23, [sp, #0x68]
   11020:      	subs	w10, w21, w23
   11024:      	ldr	x9, [sp, #0x88]
   11028:      	csel	w10, wzr, w10, lo
   1102c:      	cmp	w23, w21
   11030:      	csel	w11, w23, w21, lo
   11034:      	cinc	w13, w11, hi
   11038:      	sub	w14, w23, w13
   1103c:      	subs	x12, x12, x13
   11040:      	str	w14, [sp, #0x68]
   11044:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   11048:      	cmp	x12, #0xfff
   1104c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   11050:      	cmp	w23, w21
   11054:      	b.ls	0x11060 <generic_rawtp_path+0x6d70>
   11058:      	mov	w13, #0x2f              // =47
   1105c:      	strb	w13, [x8, x12]
   11060:      	add	x19, x8, x12
   11064:      	cmp	w23, w21
   11068:      	add	x2, x9, x10
   1106c:      	and	w1, w11, #0xff
   11070:      	mov	w8, #0x4                // =4
   11074:      	cinc	x0, x19, hi
   11078:      	blr	x8
   1107c:      	cmp	w23, w21
   11080:      	str	x19, [sp, #0x60]
   11084:      	add	x19, sp, #0x70
   11088:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   1108c:      	ldr	x21, [sp, #0x78]
   11090:      	ldp	x2, x24, [sp, #0x50]
   11094:      	str	x21, [sp, #0x48]
   11098:      	b	0x110e8 <generic_rawtp_path+0x6df8>
   1109c:      	add	x2, x24, #0x10
   110a0:      	mov	w8, #0x4                // =4
   110a4:      	add	x9, sp, #0x98
   110a8:      	add	x0, sp, #0x98
   110ac:      	mov	w1, #0x8                // =8
   110b0:      	blr	x8
   110b4:      	ldr	x8, [sp, #0x58]
   110b8:      	ldr	x9, [sp, #0x98]
   110bc:      	cmp	x8, x9
   110c0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   110c4:      	add	x2, x24, #0x18
   110c8:      	mov	w8, #0x4                // =4
   110cc:      	mov	x0, x22
   110d0:      	mov	w1, #0x8                // =8
   110d4:      	blr	x8
   110d8:      	ldr	x24, [sp, #0x98]
   110dc:      	ldr	x21, [sp, #0x48]
   110e0:      	add	x2, x24, #0x20
   110e4:      	stp	x2, x24, [sp, #0x50]
   110e8:      	ldr	x8, [sp, #0x30]
   110ec:      	cmp	x21, x8
   110f0:      	b.ne	0x11100 <generic_rawtp_path+0x6e10>
   110f4:      	ldr	x8, [sp, #0x38]
   110f8:      	cmp	x2, x8
   110fc:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   11100:      	mov	w8, #0x4                // =4
   11104:      	add	x0, sp, #0x70
   11108:      	mov	w1, #0x8                // =8
   1110c:      	blr	x8
   11110:      	ldr	x8, [sp, #0x70]
   11114:      	cmp	x21, x8
   11118:      	b.eq	0x11208 <generic_rawtp_path+0x6f18>
   1111c:      	add	x23, x21, #0x18
   11120:      	mov	w8, #0x4                // =4
   11124:      	add	x9, sp, #0x98
   11128:      	add	x0, sp, #0x98
   1112c:      	mov	w1, #0x8                // =8
   11130:      	mov	x2, x23
   11134:      	blr	x8
   11138:      	ldr	x8, [sp, #0x98]
   1113c:      	cmp	x8, x21
   11140:      	b.eq	0x11208 <generic_rawtp_path+0x6f18>
   11144:      	mov	w8, #0x4                // =4
   11148:      	add	x9, sp, #0x78
   1114c:      	add	x0, sp, #0x78
   11150:      	mov	w1, #0x8                // =8
   11154:      	mov	x2, x23
   11158:      	blr	x8
   1115c:      	add	x2, x21, #0x20
   11160:      	mov	w8, #0x4                // =4
   11164:      	mov	w9, #0x10               // =16
   11168:      	add	x10, sp, #0x80
   1116c:      	add	x0, sp, #0x80
   11170:      	mov	w1, #0x10               // =16
   11174:      	blr	x8
   11178:      	ldr	w21, [sp, #0x84]
   1117c:      	ldr	x8, [sp, #0x40]
   11180:      	ldr	x10, [sp, #0x60]
   11184:      	sub	x12, x10, x8
   11188:      	ldr	w23, [sp, #0x68]
   1118c:      	subs	w10, w21, w23
   11190:      	ldr	x9, [sp, #0x88]
   11194:      	csel	w10, wzr, w10, lo
   11198:      	cmp	w23, w21
   1119c:      	csel	w11, w23, w21, lo
   111a0:      	cinc	w13, w11, hi
   111a4:      	sub	w14, w23, w13
   111a8:      	subs	x12, x12, x13
   111ac:      	str	w14, [sp, #0x68]
   111b0:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   111b4:      	cmp	x12, #0xfff
   111b8:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   111bc:      	cmp	w23, w21
   111c0:      	b.ls	0x111cc <generic_rawtp_path+0x6edc>
   111c4:      	mov	w13, #0x2f              // =47
   111c8:      	strb	w13, [x8, x12]
   111cc:      	add	x19, x8, x12
   111d0:      	cmp	w23, w21
   111d4:      	add	x2, x9, x10
   111d8:      	and	w1, w11, #0xff
   111dc:      	mov	w8, #0x4                // =4
   111e0:      	cinc	x0, x19, hi
   111e4:      	blr	x8
   111e8:      	cmp	w23, w21
   111ec:      	str	x19, [sp, #0x60]
   111f0:      	add	x19, sp, #0x70
   111f4:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   111f8:      	ldr	x21, [sp, #0x78]
   111fc:      	ldp	x2, x24, [sp, #0x50]
   11200:      	str	x21, [sp, #0x48]
   11204:      	b	0x11254 <generic_rawtp_path+0x6f64>
   11208:      	add	x2, x24, #0x10
   1120c:      	mov	w8, #0x4                // =4
   11210:      	add	x9, sp, #0x98
   11214:      	add	x0, sp, #0x98
   11218:      	mov	w1, #0x8                // =8
   1121c:      	blr	x8
   11220:      	ldr	x8, [sp, #0x58]
   11224:      	ldr	x9, [sp, #0x98]
   11228:      	cmp	x8, x9
   1122c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   11230:      	add	x2, x24, #0x18
   11234:      	mov	w8, #0x4                // =4
   11238:      	mov	x0, x22
   1123c:      	mov	w1, #0x8                // =8
   11240:      	blr	x8
   11244:      	ldr	x24, [sp, #0x98]
   11248:      	ldr	x21, [sp, #0x48]
   1124c:      	add	x2, x24, #0x20
   11250:      	stp	x2, x24, [sp, #0x50]
   11254:      	ldr	x8, [sp, #0x30]
   11258:      	cmp	x21, x8
   1125c:      	b.ne	0x1126c <generic_rawtp_path+0x6f7c>
   11260:      	ldr	x8, [sp, #0x38]
   11264:      	cmp	x2, x8
   11268:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   1126c:      	mov	w8, #0x4                // =4
   11270:      	add	x0, sp, #0x70
   11274:      	mov	w1, #0x8                // =8
   11278:      	blr	x8
   1127c:      	ldr	x8, [sp, #0x70]
   11280:      	cmp	x21, x8
   11284:      	b.eq	0x11374 <generic_rawtp_path+0x7084>
   11288:      	add	x23, x21, #0x18
   1128c:      	mov	w8, #0x4                // =4
   11290:      	add	x9, sp, #0x98
   11294:      	add	x0, sp, #0x98
   11298:      	mov	w1, #0x8                // =8
   1129c:      	mov	x2, x23
   112a0:      	blr	x8
   112a4:      	ldr	x8, [sp, #0x98]
   112a8:      	cmp	x8, x21
   112ac:      	b.eq	0x11374 <generic_rawtp_path+0x7084>
   112b0:      	mov	w8, #0x4                // =4
   112b4:      	add	x9, sp, #0x78
   112b8:      	add	x0, sp, #0x78
   112bc:      	mov	w1, #0x8                // =8
   112c0:      	mov	x2, x23
   112c4:      	blr	x8
   112c8:      	add	x2, x21, #0x20
   112cc:      	mov	w8, #0x4                // =4
   112d0:      	mov	w9, #0x10               // =16
   112d4:      	add	x10, sp, #0x80
   112d8:      	add	x0, sp, #0x80
   112dc:      	mov	w1, #0x10               // =16
   112e0:      	blr	x8
   112e4:      	ldr	w21, [sp, #0x84]
   112e8:      	ldr	x8, [sp, #0x40]
   112ec:      	ldr	x10, [sp, #0x60]
   112f0:      	sub	x12, x10, x8
   112f4:      	ldr	w23, [sp, #0x68]
   112f8:      	subs	w10, w21, w23
   112fc:      	ldr	x9, [sp, #0x88]
   11300:      	csel	w10, wzr, w10, lo
   11304:      	cmp	w23, w21
   11308:      	csel	w11, w23, w21, lo
   1130c:      	cinc	w13, w11, hi
   11310:      	sub	w14, w23, w13
   11314:      	subs	x12, x12, x13
   11318:      	str	w14, [sp, #0x68]
   1131c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   11320:      	cmp	x12, #0xfff
   11324:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   11328:      	cmp	w23, w21
   1132c:      	b.ls	0x11338 <generic_rawtp_path+0x7048>
   11330:      	mov	w13, #0x2f              // =47
   11334:      	strb	w13, [x8, x12]
   11338:      	add	x19, x8, x12
   1133c:      	cmp	w23, w21
   11340:      	add	x2, x9, x10
   11344:      	and	w1, w11, #0xff
   11348:      	mov	w8, #0x4                // =4
   1134c:      	cinc	x0, x19, hi
   11350:      	blr	x8
   11354:      	cmp	w23, w21
   11358:      	str	x19, [sp, #0x60]
   1135c:      	add	x19, sp, #0x70
   11360:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   11364:      	ldr	x21, [sp, #0x78]
   11368:      	ldp	x2, x24, [sp, #0x50]
   1136c:      	str	x21, [sp, #0x48]
   11370:      	b	0x113c0 <generic_rawtp_path+0x70d0>
   11374:      	add	x2, x24, #0x10
   11378:      	mov	w8, #0x4                // =4
   1137c:      	add	x9, sp, #0x98
   11380:      	add	x0, sp, #0x98
   11384:      	mov	w1, #0x8                // =8
   11388:      	blr	x8
   1138c:      	ldr	x8, [sp, #0x58]
   11390:      	ldr	x9, [sp, #0x98]
   11394:      	cmp	x8, x9
   11398:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   1139c:      	add	x2, x24, #0x18
   113a0:      	mov	w8, #0x4                // =4
   113a4:      	mov	x0, x22
   113a8:      	mov	w1, #0x8                // =8
   113ac:      	blr	x8
   113b0:      	ldr	x24, [sp, #0x98]
   113b4:      	ldr	x21, [sp, #0x48]
   113b8:      	add	x2, x24, #0x20
   113bc:      	stp	x2, x24, [sp, #0x50]
   113c0:      	ldr	x8, [sp, #0x30]
   113c4:      	cmp	x21, x8
   113c8:      	b.ne	0x113d8 <generic_rawtp_path+0x70e8>
   113cc:      	ldr	x8, [sp, #0x38]
   113d0:      	cmp	x2, x8
   113d4:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   113d8:      	mov	w8, #0x4                // =4
   113dc:      	add	x0, sp, #0x70
   113e0:      	mov	w1, #0x8                // =8
   113e4:      	blr	x8
   113e8:      	ldr	x8, [sp, #0x70]
   113ec:      	cmp	x21, x8
   113f0:      	b.eq	0x114e0 <generic_rawtp_path+0x71f0>
   113f4:      	add	x23, x21, #0x18
   113f8:      	mov	w8, #0x4                // =4
   113fc:      	add	x9, sp, #0x98
   11400:      	add	x0, sp, #0x98
   11404:      	mov	w1, #0x8                // =8
   11408:      	mov	x2, x23
   1140c:      	blr	x8
   11410:      	ldr	x8, [sp, #0x98]
   11414:      	cmp	x8, x21
   11418:      	b.eq	0x114e0 <generic_rawtp_path+0x71f0>
   1141c:      	mov	w8, #0x4                // =4
   11420:      	add	x9, sp, #0x78
   11424:      	add	x0, sp, #0x78
   11428:      	mov	w1, #0x8                // =8
   1142c:      	mov	x2, x23
   11430:      	blr	x8
   11434:      	add	x2, x21, #0x20
   11438:      	mov	w8, #0x4                // =4
   1143c:      	mov	w9, #0x10               // =16
   11440:      	add	x10, sp, #0x80
   11444:      	add	x0, sp, #0x80
   11448:      	mov	w1, #0x10               // =16
   1144c:      	blr	x8
   11450:      	ldr	w21, [sp, #0x84]
   11454:      	ldr	x8, [sp, #0x40]
   11458:      	ldr	x10, [sp, #0x60]
   1145c:      	sub	x12, x10, x8
   11460:      	ldr	w23, [sp, #0x68]
   11464:      	subs	w10, w21, w23
   11468:      	ldr	x9, [sp, #0x88]
   1146c:      	csel	w10, wzr, w10, lo
   11470:      	cmp	w23, w21
   11474:      	csel	w11, w23, w21, lo
   11478:      	cinc	w13, w11, hi
   1147c:      	sub	w14, w23, w13
   11480:      	subs	x12, x12, x13
   11484:      	str	w14, [sp, #0x68]
   11488:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   1148c:      	cmp	x12, #0xfff
   11490:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   11494:      	cmp	w23, w21
   11498:      	b.ls	0x114a4 <generic_rawtp_path+0x71b4>
   1149c:      	mov	w13, #0x2f              // =47
   114a0:      	strb	w13, [x8, x12]
   114a4:      	add	x19, x8, x12
   114a8:      	cmp	w23, w21
   114ac:      	add	x2, x9, x10
   114b0:      	and	w1, w11, #0xff
   114b4:      	mov	w8, #0x4                // =4
   114b8:      	cinc	x0, x19, hi
   114bc:      	blr	x8
   114c0:      	cmp	w23, w21
   114c4:      	str	x19, [sp, #0x60]
   114c8:      	add	x19, sp, #0x70
   114cc:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   114d0:      	ldr	x21, [sp, #0x78]
   114d4:      	ldp	x2, x24, [sp, #0x50]
   114d8:      	str	x21, [sp, #0x48]
   114dc:      	b	0x1152c <generic_rawtp_path+0x723c>
   114e0:      	add	x2, x24, #0x10
   114e4:      	mov	w8, #0x4                // =4
   114e8:      	add	x9, sp, #0x98
   114ec:      	add	x0, sp, #0x98
   114f0:      	mov	w1, #0x8                // =8
   114f4:      	blr	x8
   114f8:      	ldr	x8, [sp, #0x58]
   114fc:      	ldr	x9, [sp, #0x98]
   11500:      	cmp	x8, x9
   11504:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   11508:      	add	x2, x24, #0x18
   1150c:      	mov	w8, #0x4                // =4
   11510:      	mov	x0, x22
   11514:      	mov	w1, #0x8                // =8
   11518:      	blr	x8
   1151c:      	ldr	x24, [sp, #0x98]
   11520:      	ldr	x21, [sp, #0x48]
   11524:      	add	x2, x24, #0x20
   11528:      	stp	x2, x24, [sp, #0x50]
   1152c:      	ldr	x8, [sp, #0x30]
   11530:      	cmp	x21, x8
   11534:      	b.ne	0x11544 <generic_rawtp_path+0x7254>
   11538:      	ldr	x8, [sp, #0x38]
   1153c:      	cmp	x2, x8
   11540:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   11544:      	mov	w8, #0x4                // =4
   11548:      	add	x0, sp, #0x70
   1154c:      	mov	w1, #0x8                // =8
   11550:      	blr	x8
   11554:      	ldr	x8, [sp, #0x70]
   11558:      	cmp	x21, x8
   1155c:      	b.eq	0x1164c <generic_rawtp_path+0x735c>
   11560:      	add	x23, x21, #0x18
   11564:      	mov	w8, #0x4                // =4
   11568:      	add	x9, sp, #0x98
   1156c:      	add	x0, sp, #0x98
   11570:      	mov	w1, #0x8                // =8
   11574:      	mov	x2, x23
   11578:      	blr	x8
   1157c:      	ldr	x8, [sp, #0x98]
   11580:      	cmp	x8, x21
   11584:      	b.eq	0x1164c <generic_rawtp_path+0x735c>
   11588:      	mov	w8, #0x4                // =4
   1158c:      	add	x9, sp, #0x78
   11590:      	add	x0, sp, #0x78
   11594:      	mov	w1, #0x8                // =8
   11598:      	mov	x2, x23
   1159c:      	blr	x8
   115a0:      	add	x2, x21, #0x20
   115a4:      	mov	w8, #0x4                // =4
   115a8:      	mov	w9, #0x10               // =16
   115ac:      	add	x10, sp, #0x80
   115b0:      	add	x0, sp, #0x80
   115b4:      	mov	w1, #0x10               // =16
   115b8:      	blr	x8
   115bc:      	ldr	w21, [sp, #0x84]
   115c0:      	ldr	x8, [sp, #0x40]
   115c4:      	ldr	x10, [sp, #0x60]
   115c8:      	sub	x12, x10, x8
   115cc:      	ldr	w23, [sp, #0x68]
   115d0:      	subs	w10, w21, w23
   115d4:      	ldr	x9, [sp, #0x88]
   115d8:      	csel	w10, wzr, w10, lo
   115dc:      	cmp	w23, w21
   115e0:      	csel	w11, w23, w21, lo
   115e4:      	cinc	w13, w11, hi
   115e8:      	sub	w14, w23, w13
   115ec:      	subs	x12, x12, x13
   115f0:      	str	w14, [sp, #0x68]
   115f4:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   115f8:      	cmp	x12, #0xfff
   115fc:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   11600:      	cmp	w23, w21
   11604:      	b.ls	0x11610 <generic_rawtp_path+0x7320>
   11608:      	mov	w13, #0x2f              // =47
   1160c:      	strb	w13, [x8, x12]
   11610:      	add	x19, x8, x12
   11614:      	cmp	w23, w21
   11618:      	add	x2, x9, x10
   1161c:      	and	w1, w11, #0xff
   11620:      	mov	w8, #0x4                // =4
   11624:      	cinc	x0, x19, hi
   11628:      	blr	x8
   1162c:      	cmp	w23, w21
   11630:      	str	x19, [sp, #0x60]
   11634:      	add	x19, sp, #0x70
   11638:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   1163c:      	ldr	x21, [sp, #0x78]
   11640:      	ldp	x2, x24, [sp, #0x50]
   11644:      	str	x21, [sp, #0x48]
   11648:      	b	0x11698 <generic_rawtp_path+0x73a8>
   1164c:      	add	x2, x24, #0x10
   11650:      	mov	w8, #0x4                // =4
   11654:      	add	x9, sp, #0x98
   11658:      	add	x0, sp, #0x98
   1165c:      	mov	w1, #0x8                // =8
   11660:      	blr	x8
   11664:      	ldr	x8, [sp, #0x58]
   11668:      	ldr	x9, [sp, #0x98]
   1166c:      	cmp	x8, x9
   11670:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   11674:      	add	x2, x24, #0x18
   11678:      	mov	w8, #0x4                // =4
   1167c:      	mov	x0, x22
   11680:      	mov	w1, #0x8                // =8
   11684:      	blr	x8
   11688:      	ldr	x24, [sp, #0x98]
   1168c:      	ldr	x21, [sp, #0x48]
   11690:      	add	x2, x24, #0x20
   11694:      	stp	x2, x24, [sp, #0x50]
   11698:      	ldr	x8, [sp, #0x30]
   1169c:      	cmp	x21, x8
   116a0:      	b.ne	0x116b0 <generic_rawtp_path+0x73c0>
   116a4:      	ldr	x8, [sp, #0x38]
   116a8:      	cmp	x2, x8
   116ac:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   116b0:      	mov	w8, #0x4                // =4
   116b4:      	add	x0, sp, #0x70
   116b8:      	mov	w1, #0x8                // =8
   116bc:      	blr	x8
   116c0:      	ldr	x8, [sp, #0x70]
   116c4:      	cmp	x21, x8
   116c8:      	b.eq	0x117b8 <generic_rawtp_path+0x74c8>
   116cc:      	add	x23, x21, #0x18
   116d0:      	mov	w8, #0x4                // =4
   116d4:      	add	x9, sp, #0x98
   116d8:      	add	x0, sp, #0x98
   116dc:      	mov	w1, #0x8                // =8
   116e0:      	mov	x2, x23
   116e4:      	blr	x8
   116e8:      	ldr	x8, [sp, #0x98]
   116ec:      	cmp	x8, x21
   116f0:      	b.eq	0x117b8 <generic_rawtp_path+0x74c8>
   116f4:      	mov	w8, #0x4                // =4
   116f8:      	add	x9, sp, #0x78
   116fc:      	add	x0, sp, #0x78
   11700:      	mov	w1, #0x8                // =8
   11704:      	mov	x2, x23
   11708:      	blr	x8
   1170c:      	add	x2, x21, #0x20
   11710:      	mov	w8, #0x4                // =4
   11714:      	mov	w9, #0x10               // =16
   11718:      	add	x10, sp, #0x80
   1171c:      	add	x0, sp, #0x80
   11720:      	mov	w1, #0x10               // =16
   11724:      	blr	x8
   11728:      	ldr	w21, [sp, #0x84]
   1172c:      	ldr	x8, [sp, #0x40]
   11730:      	ldr	x10, [sp, #0x60]
   11734:      	sub	x12, x10, x8
   11738:      	ldr	w23, [sp, #0x68]
   1173c:      	subs	w10, w21, w23
   11740:      	ldr	x9, [sp, #0x88]
   11744:      	csel	w10, wzr, w10, lo
   11748:      	cmp	w23, w21
   1174c:      	csel	w11, w23, w21, lo
   11750:      	cinc	w13, w11, hi
   11754:      	sub	w14, w23, w13
   11758:      	subs	x12, x12, x13
   1175c:      	str	w14, [sp, #0x68]
   11760:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   11764:      	cmp	x12, #0xfff
   11768:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   1176c:      	cmp	w23, w21
   11770:      	b.ls	0x1177c <generic_rawtp_path+0x748c>
   11774:      	mov	w13, #0x2f              // =47
   11778:      	strb	w13, [x8, x12]
   1177c:      	add	x19, x8, x12
   11780:      	cmp	w23, w21
   11784:      	add	x2, x9, x10
   11788:      	and	w1, w11, #0xff
   1178c:      	mov	w8, #0x4                // =4
   11790:      	cinc	x0, x19, hi
   11794:      	blr	x8
   11798:      	cmp	w23, w21
   1179c:      	str	x19, [sp, #0x60]
   117a0:      	add	x19, sp, #0x70
   117a4:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   117a8:      	ldr	x21, [sp, #0x78]
   117ac:      	ldp	x2, x24, [sp, #0x50]
   117b0:      	str	x21, [sp, #0x48]
   117b4:      	b	0x11804 <generic_rawtp_path+0x7514>
   117b8:      	add	x2, x24, #0x10
   117bc:      	mov	w8, #0x4                // =4
   117c0:      	add	x9, sp, #0x98
   117c4:      	add	x0, sp, #0x98
   117c8:      	mov	w1, #0x8                // =8
   117cc:      	blr	x8
   117d0:      	ldr	x8, [sp, #0x58]
   117d4:      	ldr	x9, [sp, #0x98]
   117d8:      	cmp	x8, x9
   117dc:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   117e0:      	add	x2, x24, #0x18
   117e4:      	mov	w8, #0x4                // =4
   117e8:      	mov	x0, x22
   117ec:      	mov	w1, #0x8                // =8
   117f0:      	blr	x8
   117f4:      	ldr	x24, [sp, #0x98]
   117f8:      	ldr	x21, [sp, #0x48]
   117fc:      	add	x2, x24, #0x20
   11800:      	stp	x2, x24, [sp, #0x50]
   11804:      	ldr	x8, [sp, #0x30]
   11808:      	cmp	x21, x8
   1180c:      	b.ne	0x1181c <generic_rawtp_path+0x752c>
   11810:      	ldr	x8, [sp, #0x38]
   11814:      	cmp	x2, x8
   11818:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   1181c:      	mov	w8, #0x4                // =4
   11820:      	add	x0, sp, #0x70
   11824:      	mov	w1, #0x8                // =8
   11828:      	blr	x8
   1182c:      	ldr	x8, [sp, #0x70]
   11830:      	cmp	x21, x8
   11834:      	b.eq	0x11924 <generic_rawtp_path+0x7634>
   11838:      	add	x23, x21, #0x18
   1183c:      	mov	w8, #0x4                // =4
   11840:      	add	x9, sp, #0x98
   11844:      	add	x0, sp, #0x98
   11848:      	mov	w1, #0x8                // =8
   1184c:      	mov	x2, x23
   11850:      	blr	x8
   11854:      	ldr	x8, [sp, #0x98]
   11858:      	cmp	x8, x21
   1185c:      	b.eq	0x11924 <generic_rawtp_path+0x7634>
   11860:      	mov	w8, #0x4                // =4
   11864:      	add	x9, sp, #0x78
   11868:      	add	x0, sp, #0x78
   1186c:      	mov	w1, #0x8                // =8
   11870:      	mov	x2, x23
   11874:      	blr	x8
   11878:      	add	x2, x21, #0x20
   1187c:      	mov	w8, #0x4                // =4
   11880:      	mov	w9, #0x10               // =16
   11884:      	add	x10, sp, #0x80
   11888:      	add	x0, sp, #0x80
   1188c:      	mov	w1, #0x10               // =16
   11890:      	blr	x8
   11894:      	ldr	w21, [sp, #0x84]
   11898:      	ldr	x8, [sp, #0x40]
   1189c:      	ldr	x10, [sp, #0x60]
   118a0:      	sub	x12, x10, x8
   118a4:      	ldr	w23, [sp, #0x68]
   118a8:      	subs	w10, w21, w23
   118ac:      	ldr	x9, [sp, #0x88]
   118b0:      	csel	w10, wzr, w10, lo
   118b4:      	cmp	w23, w21
   118b8:      	csel	w11, w23, w21, lo
   118bc:      	cinc	w13, w11, hi
   118c0:      	sub	w14, w23, w13
   118c4:      	subs	x12, x12, x13
   118c8:      	str	w14, [sp, #0x68]
   118cc:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   118d0:      	cmp	x12, #0xfff
   118d4:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   118d8:      	cmp	w23, w21
   118dc:      	b.ls	0x118e8 <generic_rawtp_path+0x75f8>
   118e0:      	mov	w13, #0x2f              // =47
   118e4:      	strb	w13, [x8, x12]
   118e8:      	add	x19, x8, x12
   118ec:      	cmp	w23, w21
   118f0:      	add	x2, x9, x10
   118f4:      	and	w1, w11, #0xff
   118f8:      	mov	w8, #0x4                // =4
   118fc:      	cinc	x0, x19, hi
   11900:      	blr	x8
   11904:      	cmp	w23, w21
   11908:      	str	x19, [sp, #0x60]
   1190c:      	add	x19, sp, #0x70
   11910:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   11914:      	ldr	x21, [sp, #0x78]
   11918:      	ldp	x2, x24, [sp, #0x50]
   1191c:      	str	x21, [sp, #0x48]
   11920:      	b	0x11970 <generic_rawtp_path+0x7680>
   11924:      	add	x2, x24, #0x10
   11928:      	mov	w8, #0x4                // =4
   1192c:      	add	x9, sp, #0x98
   11930:      	add	x0, sp, #0x98
   11934:      	mov	w1, #0x8                // =8
   11938:      	blr	x8
   1193c:      	ldr	x8, [sp, #0x58]
   11940:      	ldr	x9, [sp, #0x98]
   11944:      	cmp	x8, x9
   11948:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   1194c:      	add	x2, x24, #0x18
   11950:      	mov	w8, #0x4                // =4
   11954:      	mov	x0, x22
   11958:      	mov	w1, #0x8                // =8
   1195c:      	blr	x8
   11960:      	ldr	x24, [sp, #0x98]
   11964:      	ldr	x21, [sp, #0x48]
   11968:      	add	x2, x24, #0x20
   1196c:      	stp	x2, x24, [sp, #0x50]
   11970:      	ldr	x8, [sp, #0x30]
   11974:      	cmp	x21, x8
   11978:      	b.ne	0x11988 <generic_rawtp_path+0x7698>
   1197c:      	ldr	x8, [sp, #0x38]
   11980:      	cmp	x2, x8
   11984:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   11988:      	mov	w8, #0x4                // =4
   1198c:      	add	x0, sp, #0x70
   11990:      	mov	w1, #0x8                // =8
   11994:      	blr	x8
   11998:      	ldr	x8, [sp, #0x70]
   1199c:      	cmp	x21, x8
   119a0:      	b.eq	0x11a90 <generic_rawtp_path+0x77a0>
   119a4:      	add	x23, x21, #0x18
   119a8:      	mov	w8, #0x4                // =4
   119ac:      	add	x9, sp, #0x98
   119b0:      	add	x0, sp, #0x98
   119b4:      	mov	w1, #0x8                // =8
   119b8:      	mov	x2, x23
   119bc:      	blr	x8
   119c0:      	ldr	x8, [sp, #0x98]
   119c4:      	cmp	x8, x21
   119c8:      	b.eq	0x11a90 <generic_rawtp_path+0x77a0>
   119cc:      	mov	w8, #0x4                // =4
   119d0:      	add	x9, sp, #0x78
   119d4:      	add	x0, sp, #0x78
   119d8:      	mov	w1, #0x8                // =8
   119dc:      	mov	x2, x23
   119e0:      	blr	x8
   119e4:      	add	x2, x21, #0x20
   119e8:      	mov	w8, #0x4                // =4
   119ec:      	mov	w9, #0x10               // =16
   119f0:      	add	x10, sp, #0x80
   119f4:      	add	x0, sp, #0x80
   119f8:      	mov	w1, #0x10               // =16
   119fc:      	blr	x8
   11a00:      	ldr	w21, [sp, #0x84]
   11a04:      	ldr	x8, [sp, #0x40]
   11a08:      	ldr	x10, [sp, #0x60]
   11a0c:      	sub	x12, x10, x8
   11a10:      	ldr	w23, [sp, #0x68]
   11a14:      	subs	w10, w21, w23
   11a18:      	ldr	x9, [sp, #0x88]
   11a1c:      	csel	w10, wzr, w10, lo
   11a20:      	cmp	w23, w21
   11a24:      	csel	w11, w23, w21, lo
   11a28:      	cinc	w13, w11, hi
   11a2c:      	sub	w14, w23, w13
   11a30:      	subs	x12, x12, x13
   11a34:      	str	w14, [sp, #0x68]
   11a38:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   11a3c:      	cmp	x12, #0xfff
   11a40:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   11a44:      	cmp	w23, w21
   11a48:      	b.ls	0x11a54 <generic_rawtp_path+0x7764>
   11a4c:      	mov	w13, #0x2f              // =47
   11a50:      	strb	w13, [x8, x12]
   11a54:      	add	x19, x8, x12
   11a58:      	cmp	w23, w21
   11a5c:      	add	x2, x9, x10
   11a60:      	and	w1, w11, #0xff
   11a64:      	mov	w8, #0x4                // =4
   11a68:      	cinc	x0, x19, hi
   11a6c:      	blr	x8
   11a70:      	cmp	w23, w21
   11a74:      	str	x19, [sp, #0x60]
   11a78:      	add	x19, sp, #0x70
   11a7c:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   11a80:      	ldr	x21, [sp, #0x78]
   11a84:      	ldp	x2, x24, [sp, #0x50]
   11a88:      	str	x21, [sp, #0x48]
   11a8c:      	b	0x11adc <generic_rawtp_path+0x77ec>
   11a90:      	add	x2, x24, #0x10
   11a94:      	mov	w8, #0x4                // =4
   11a98:      	add	x9, sp, #0x98
   11a9c:      	add	x0, sp, #0x98
   11aa0:      	mov	w1, #0x8                // =8
   11aa4:      	blr	x8
   11aa8:      	ldr	x8, [sp, #0x58]
   11aac:      	ldr	x9, [sp, #0x98]
   11ab0:      	cmp	x8, x9
   11ab4:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   11ab8:      	add	x2, x24, #0x18
   11abc:      	mov	w8, #0x4                // =4
   11ac0:      	mov	x0, x22
   11ac4:      	mov	w1, #0x8                // =8
   11ac8:      	blr	x8
   11acc:      	ldr	x24, [sp, #0x98]
   11ad0:      	ldr	x21, [sp, #0x48]
   11ad4:      	add	x2, x24, #0x20
   11ad8:      	stp	x2, x24, [sp, #0x50]
   11adc:      	ldr	x8, [sp, #0x30]
   11ae0:      	cmp	x21, x8
   11ae4:      	b.ne	0x11af4 <generic_rawtp_path+0x7804>
   11ae8:      	ldr	x8, [sp, #0x38]
   11aec:      	cmp	x2, x8
   11af0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   11af4:      	mov	w8, #0x4                // =4
   11af8:      	add	x0, sp, #0x70
   11afc:      	mov	w1, #0x8                // =8
   11b00:      	blr	x8
   11b04:      	ldr	x8, [sp, #0x70]
   11b08:      	cmp	x21, x8
   11b0c:      	b.eq	0x11bfc <generic_rawtp_path+0x790c>
   11b10:      	add	x23, x21, #0x18
   11b14:      	mov	w8, #0x4                // =4
   11b18:      	add	x9, sp, #0x98
   11b1c:      	add	x0, sp, #0x98
   11b20:      	mov	w1, #0x8                // =8
   11b24:      	mov	x2, x23
   11b28:      	blr	x8
   11b2c:      	ldr	x8, [sp, #0x98]
   11b30:      	cmp	x8, x21
   11b34:      	b.eq	0x11bfc <generic_rawtp_path+0x790c>
   11b38:      	mov	w8, #0x4                // =4
   11b3c:      	add	x9, sp, #0x78
   11b40:      	add	x0, sp, #0x78
   11b44:      	mov	w1, #0x8                // =8
   11b48:      	mov	x2, x23
   11b4c:      	blr	x8
   11b50:      	add	x2, x21, #0x20
   11b54:      	mov	w8, #0x4                // =4
   11b58:      	mov	w9, #0x10               // =16
   11b5c:      	add	x10, sp, #0x80
   11b60:      	add	x0, sp, #0x80
   11b64:      	mov	w1, #0x10               // =16
   11b68:      	blr	x8
   11b6c:      	ldr	w21, [sp, #0x84]
   11b70:      	ldr	x8, [sp, #0x40]
   11b74:      	ldr	x10, [sp, #0x60]
   11b78:      	sub	x12, x10, x8
   11b7c:      	ldr	w23, [sp, #0x68]
   11b80:      	subs	w10, w21, w23
   11b84:      	ldr	x9, [sp, #0x88]
   11b88:      	csel	w10, wzr, w10, lo
   11b8c:      	cmp	w23, w21
   11b90:      	csel	w11, w23, w21, lo
   11b94:      	cinc	w13, w11, hi
   11b98:      	sub	w14, w23, w13
   11b9c:      	subs	x12, x12, x13
   11ba0:      	str	w14, [sp, #0x68]
   11ba4:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   11ba8:      	cmp	x12, #0xfff
   11bac:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   11bb0:      	cmp	w23, w21
   11bb4:      	b.ls	0x11bc0 <generic_rawtp_path+0x78d0>
   11bb8:      	mov	w13, #0x2f              // =47
   11bbc:      	strb	w13, [x8, x12]
   11bc0:      	add	x19, x8, x12
   11bc4:      	cmp	w23, w21
   11bc8:      	add	x2, x9, x10
   11bcc:      	and	w1, w11, #0xff
   11bd0:      	mov	w8, #0x4                // =4
   11bd4:      	cinc	x0, x19, hi
   11bd8:      	blr	x8
   11bdc:      	cmp	w23, w21
   11be0:      	str	x19, [sp, #0x60]
   11be4:      	add	x19, sp, #0x70
   11be8:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   11bec:      	ldr	x21, [sp, #0x78]
   11bf0:      	ldp	x2, x24, [sp, #0x50]
   11bf4:      	str	x21, [sp, #0x48]
   11bf8:      	b	0x11c48 <generic_rawtp_path+0x7958>
   11bfc:      	add	x2, x24, #0x10
   11c00:      	mov	w8, #0x4                // =4
   11c04:      	add	x9, sp, #0x98
   11c08:      	add	x0, sp, #0x98
   11c0c:      	mov	w1, #0x8                // =8
   11c10:      	blr	x8
   11c14:      	ldr	x8, [sp, #0x58]
   11c18:      	ldr	x9, [sp, #0x98]
   11c1c:      	cmp	x8, x9
   11c20:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   11c24:      	add	x2, x24, #0x18
   11c28:      	mov	w8, #0x4                // =4
   11c2c:      	mov	x0, x22
   11c30:      	mov	w1, #0x8                // =8
   11c34:      	blr	x8
   11c38:      	ldr	x24, [sp, #0x98]
   11c3c:      	ldr	x21, [sp, #0x48]
   11c40:      	add	x2, x24, #0x20
   11c44:      	stp	x2, x24, [sp, #0x50]
   11c48:      	ldr	x8, [sp, #0x30]
   11c4c:      	cmp	x21, x8
   11c50:      	b.ne	0x11c60 <generic_rawtp_path+0x7970>
   11c54:      	ldr	x8, [sp, #0x38]
   11c58:      	cmp	x2, x8
   11c5c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   11c60:      	mov	w8, #0x4                // =4
   11c64:      	add	x0, sp, #0x70
   11c68:      	mov	w1, #0x8                // =8
   11c6c:      	blr	x8
   11c70:      	ldr	x8, [sp, #0x70]
   11c74:      	cmp	x21, x8
   11c78:      	b.eq	0x11d68 <generic_rawtp_path+0x7a78>
   11c7c:      	add	x23, x21, #0x18
   11c80:      	mov	w8, #0x4                // =4
   11c84:      	add	x9, sp, #0x98
   11c88:      	add	x0, sp, #0x98
   11c8c:      	mov	w1, #0x8                // =8
   11c90:      	mov	x2, x23
   11c94:      	blr	x8
   11c98:      	ldr	x8, [sp, #0x98]
   11c9c:      	cmp	x8, x21
   11ca0:      	b.eq	0x11d68 <generic_rawtp_path+0x7a78>
   11ca4:      	mov	w8, #0x4                // =4
   11ca8:      	add	x9, sp, #0x78
   11cac:      	add	x0, sp, #0x78
   11cb0:      	mov	w1, #0x8                // =8
   11cb4:      	mov	x2, x23
   11cb8:      	blr	x8
   11cbc:      	add	x2, x21, #0x20
   11cc0:      	mov	w8, #0x4                // =4
   11cc4:      	mov	w9, #0x10               // =16
   11cc8:      	add	x10, sp, #0x80
   11ccc:      	add	x0, sp, #0x80
   11cd0:      	mov	w1, #0x10               // =16
   11cd4:      	blr	x8
   11cd8:      	ldr	w21, [sp, #0x84]
   11cdc:      	ldr	x8, [sp, #0x40]
   11ce0:      	ldr	x10, [sp, #0x60]
   11ce4:      	sub	x12, x10, x8
   11ce8:      	ldr	w23, [sp, #0x68]
   11cec:      	subs	w10, w21, w23
   11cf0:      	ldr	x9, [sp, #0x88]
   11cf4:      	csel	w10, wzr, w10, lo
   11cf8:      	cmp	w23, w21
   11cfc:      	csel	w11, w23, w21, lo
   11d00:      	cinc	w13, w11, hi
   11d04:      	sub	w14, w23, w13
   11d08:      	subs	x12, x12, x13
   11d0c:      	str	w14, [sp, #0x68]
   11d10:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   11d14:      	cmp	x12, #0xfff
   11d18:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   11d1c:      	cmp	w23, w21
   11d20:      	b.ls	0x11d2c <generic_rawtp_path+0x7a3c>
   11d24:      	mov	w13, #0x2f              // =47
   11d28:      	strb	w13, [x8, x12]
   11d2c:      	add	x19, x8, x12
   11d30:      	cmp	w23, w21
   11d34:      	add	x2, x9, x10
   11d38:      	and	w1, w11, #0xff
   11d3c:      	mov	w8, #0x4                // =4
   11d40:      	cinc	x0, x19, hi
   11d44:      	blr	x8
   11d48:      	cmp	w23, w21
   11d4c:      	str	x19, [sp, #0x60]
   11d50:      	add	x19, sp, #0x70
   11d54:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   11d58:      	ldr	x21, [sp, #0x78]
   11d5c:      	ldp	x2, x24, [sp, #0x50]
   11d60:      	str	x21, [sp, #0x48]
   11d64:      	b	0x11db4 <generic_rawtp_path+0x7ac4>
   11d68:      	add	x2, x24, #0x10
   11d6c:      	mov	w8, #0x4                // =4
   11d70:      	add	x9, sp, #0x98
   11d74:      	add	x0, sp, #0x98
   11d78:      	mov	w1, #0x8                // =8
   11d7c:      	blr	x8
   11d80:      	ldr	x8, [sp, #0x58]
   11d84:      	ldr	x9, [sp, #0x98]
   11d88:      	cmp	x8, x9
   11d8c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   11d90:      	add	x2, x24, #0x18
   11d94:      	mov	w8, #0x4                // =4
   11d98:      	mov	x0, x22
   11d9c:      	mov	w1, #0x8                // =8
   11da0:      	blr	x8
   11da4:      	ldr	x24, [sp, #0x98]
   11da8:      	ldr	x21, [sp, #0x48]
   11dac:      	add	x2, x24, #0x20
   11db0:      	stp	x2, x24, [sp, #0x50]
   11db4:      	ldr	x8, [sp, #0x30]
   11db8:      	cmp	x21, x8
   11dbc:      	b.ne	0x11dcc <generic_rawtp_path+0x7adc>
   11dc0:      	ldr	x8, [sp, #0x38]
   11dc4:      	cmp	x2, x8
   11dc8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   11dcc:      	mov	w8, #0x4                // =4
   11dd0:      	add	x0, sp, #0x70
   11dd4:      	mov	w1, #0x8                // =8
   11dd8:      	blr	x8
   11ddc:      	ldr	x8, [sp, #0x70]
   11de0:      	cmp	x21, x8
   11de4:      	b.eq	0x11ed4 <generic_rawtp_path+0x7be4>
   11de8:      	add	x23, x21, #0x18
   11dec:      	mov	w8, #0x4                // =4
   11df0:      	add	x9, sp, #0x98
   11df4:      	add	x0, sp, #0x98
   11df8:      	mov	w1, #0x8                // =8
   11dfc:      	mov	x2, x23
   11e00:      	blr	x8
   11e04:      	ldr	x8, [sp, #0x98]
   11e08:      	cmp	x8, x21
   11e0c:      	b.eq	0x11ed4 <generic_rawtp_path+0x7be4>
   11e10:      	mov	w8, #0x4                // =4
   11e14:      	add	x9, sp, #0x78
   11e18:      	add	x0, sp, #0x78
   11e1c:      	mov	w1, #0x8                // =8
   11e20:      	mov	x2, x23
   11e24:      	blr	x8
   11e28:      	add	x2, x21, #0x20
   11e2c:      	mov	w8, #0x4                // =4
   11e30:      	mov	w9, #0x10               // =16
   11e34:      	add	x10, sp, #0x80
   11e38:      	add	x0, sp, #0x80
   11e3c:      	mov	w1, #0x10               // =16
   11e40:      	blr	x8
   11e44:      	ldr	w21, [sp, #0x84]
   11e48:      	ldr	x8, [sp, #0x40]
   11e4c:      	ldr	x10, [sp, #0x60]
   11e50:      	sub	x12, x10, x8
   11e54:      	ldr	w23, [sp, #0x68]
   11e58:      	subs	w10, w21, w23
   11e5c:      	ldr	x9, [sp, #0x88]
   11e60:      	csel	w10, wzr, w10, lo
   11e64:      	cmp	w23, w21
   11e68:      	csel	w11, w23, w21, lo
   11e6c:      	cinc	w13, w11, hi
   11e70:      	sub	w14, w23, w13
   11e74:      	subs	x12, x12, x13
   11e78:      	str	w14, [sp, #0x68]
   11e7c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   11e80:      	cmp	x12, #0xfff
   11e84:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   11e88:      	cmp	w23, w21
   11e8c:      	b.ls	0x11e98 <generic_rawtp_path+0x7ba8>
   11e90:      	mov	w13, #0x2f              // =47
   11e94:      	strb	w13, [x8, x12]
   11e98:      	add	x19, x8, x12
   11e9c:      	cmp	w23, w21
   11ea0:      	add	x2, x9, x10
   11ea4:      	and	w1, w11, #0xff
   11ea8:      	mov	w8, #0x4                // =4
   11eac:      	cinc	x0, x19, hi
   11eb0:      	blr	x8
   11eb4:      	cmp	w23, w21
   11eb8:      	str	x19, [sp, #0x60]
   11ebc:      	add	x19, sp, #0x70
   11ec0:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   11ec4:      	ldr	x21, [sp, #0x78]
   11ec8:      	ldp	x2, x24, [sp, #0x50]
   11ecc:      	str	x21, [sp, #0x48]
   11ed0:      	b	0x11f20 <generic_rawtp_path+0x7c30>
   11ed4:      	add	x2, x24, #0x10
   11ed8:      	mov	w8, #0x4                // =4
   11edc:      	add	x9, sp, #0x98
   11ee0:      	add	x0, sp, #0x98
   11ee4:      	mov	w1, #0x8                // =8
   11ee8:      	blr	x8
   11eec:      	ldr	x8, [sp, #0x58]
   11ef0:      	ldr	x9, [sp, #0x98]
   11ef4:      	cmp	x8, x9
   11ef8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   11efc:      	add	x2, x24, #0x18
   11f00:      	mov	w8, #0x4                // =4
   11f04:      	mov	x0, x22
   11f08:      	mov	w1, #0x8                // =8
   11f0c:      	blr	x8
   11f10:      	ldr	x24, [sp, #0x98]
   11f14:      	ldr	x21, [sp, #0x48]
   11f18:      	add	x2, x24, #0x20
   11f1c:      	stp	x2, x24, [sp, #0x50]
   11f20:      	ldr	x8, [sp, #0x30]
   11f24:      	cmp	x21, x8
   11f28:      	b.ne	0x11f38 <generic_rawtp_path+0x7c48>
   11f2c:      	ldr	x8, [sp, #0x38]
   11f30:      	cmp	x2, x8
   11f34:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   11f38:      	mov	w8, #0x4                // =4
   11f3c:      	add	x0, sp, #0x70
   11f40:      	mov	w1, #0x8                // =8
   11f44:      	blr	x8
   11f48:      	ldr	x8, [sp, #0x70]
   11f4c:      	cmp	x21, x8
   11f50:      	b.eq	0x12040 <generic_rawtp_path+0x7d50>
   11f54:      	add	x23, x21, #0x18
   11f58:      	mov	w8, #0x4                // =4
   11f5c:      	add	x9, sp, #0x98
   11f60:      	add	x0, sp, #0x98
   11f64:      	mov	w1, #0x8                // =8
   11f68:      	mov	x2, x23
   11f6c:      	blr	x8
   11f70:      	ldr	x8, [sp, #0x98]
   11f74:      	cmp	x8, x21
   11f78:      	b.eq	0x12040 <generic_rawtp_path+0x7d50>
   11f7c:      	mov	w8, #0x4                // =4
   11f80:      	add	x9, sp, #0x78
   11f84:      	add	x0, sp, #0x78
   11f88:      	mov	w1, #0x8                // =8
   11f8c:      	mov	x2, x23
   11f90:      	blr	x8
   11f94:      	add	x2, x21, #0x20
   11f98:      	mov	w8, #0x4                // =4
   11f9c:      	mov	w9, #0x10               // =16
   11fa0:      	add	x10, sp, #0x80
   11fa4:      	add	x0, sp, #0x80
   11fa8:      	mov	w1, #0x10               // =16
   11fac:      	blr	x8
   11fb0:      	ldr	w21, [sp, #0x84]
   11fb4:      	ldr	x8, [sp, #0x40]
   11fb8:      	ldr	x10, [sp, #0x60]
   11fbc:      	sub	x12, x10, x8
   11fc0:      	ldr	w23, [sp, #0x68]
   11fc4:      	subs	w10, w21, w23
   11fc8:      	ldr	x9, [sp, #0x88]
   11fcc:      	csel	w10, wzr, w10, lo
   11fd0:      	cmp	w23, w21
   11fd4:      	csel	w11, w23, w21, lo
   11fd8:      	cinc	w13, w11, hi
   11fdc:      	sub	w14, w23, w13
   11fe0:      	subs	x12, x12, x13
   11fe4:      	str	w14, [sp, #0x68]
   11fe8:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   11fec:      	cmp	x12, #0xfff
   11ff0:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   11ff4:      	cmp	w23, w21
   11ff8:      	b.ls	0x12004 <generic_rawtp_path+0x7d14>
   11ffc:      	mov	w13, #0x2f              // =47
   12000:      	strb	w13, [x8, x12]
   12004:      	add	x19, x8, x12
   12008:      	cmp	w23, w21
   1200c:      	add	x2, x9, x10
   12010:      	and	w1, w11, #0xff
   12014:      	mov	w8, #0x4                // =4
   12018:      	cinc	x0, x19, hi
   1201c:      	blr	x8
   12020:      	cmp	w23, w21
   12024:      	str	x19, [sp, #0x60]
   12028:      	add	x19, sp, #0x70
   1202c:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   12030:      	ldr	x21, [sp, #0x78]
   12034:      	ldp	x2, x24, [sp, #0x50]
   12038:      	str	x21, [sp, #0x48]
   1203c:      	b	0x1208c <generic_rawtp_path+0x7d9c>
   12040:      	add	x2, x24, #0x10
   12044:      	mov	w8, #0x4                // =4
   12048:      	add	x9, sp, #0x98
   1204c:      	add	x0, sp, #0x98
   12050:      	mov	w1, #0x8                // =8
   12054:      	blr	x8
   12058:      	ldr	x8, [sp, #0x58]
   1205c:      	ldr	x9, [sp, #0x98]
   12060:      	cmp	x8, x9
   12064:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   12068:      	add	x2, x24, #0x18
   1206c:      	mov	w8, #0x4                // =4
   12070:      	mov	x0, x22
   12074:      	mov	w1, #0x8                // =8
   12078:      	blr	x8
   1207c:      	ldr	x24, [sp, #0x98]
   12080:      	ldr	x21, [sp, #0x48]
   12084:      	add	x2, x24, #0x20
   12088:      	stp	x2, x24, [sp, #0x50]
   1208c:      	ldr	x8, [sp, #0x30]
   12090:      	cmp	x21, x8
   12094:      	b.ne	0x120a4 <generic_rawtp_path+0x7db4>
   12098:      	ldr	x8, [sp, #0x38]
   1209c:      	cmp	x2, x8
   120a0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   120a4:      	str	x25, [sp, #0x8]
   120a8:      	mov	w8, #0x4                // =4
   120ac:      	add	x0, sp, #0x70
   120b0:      	mov	w1, #0x8                // =8
   120b4:      	blr	x8
   120b8:      	ldr	x8, [sp, #0x70]
   120bc:      	cmp	x21, x8
   120c0:      	b.eq	0x121b4 <generic_rawtp_path+0x7ec4>
   120c4:      	add	x23, x21, #0x18
   120c8:      	mov	w8, #0x4                // =4
   120cc:      	add	x9, sp, #0x98
   120d0:      	add	x0, sp, #0x98
   120d4:      	mov	w1, #0x8                // =8
   120d8:      	mov	x2, x23
   120dc:      	blr	x8
   120e0:      	ldr	x8, [sp, #0x98]
   120e4:      	cmp	x8, x21
   120e8:      	b.eq	0x121b4 <generic_rawtp_path+0x7ec4>
   120ec:      	mov	w8, #0x4                // =4
   120f0:      	add	x9, sp, #0x78
   120f4:      	add	x0, sp, #0x78
   120f8:      	mov	w1, #0x8                // =8
   120fc:      	mov	x2, x23
   12100:      	blr	x8
   12104:      	add	x2, x21, #0x20
   12108:      	mov	w8, #0x4                // =4
   1210c:      	mov	w9, #0x10               // =16
   12110:      	add	x10, sp, #0x80
   12114:      	add	x0, sp, #0x80
   12118:      	mov	w1, #0x10               // =16
   1211c:      	blr	x8
   12120:      	ldr	w21, [sp, #0x84]
   12124:      	ldr	x8, [sp, #0x40]
   12128:      	ldr	x10, [sp, #0x60]
   1212c:      	sub	x12, x10, x8
   12130:      	ldr	w23, [sp, #0x68]
   12134:      	subs	w10, w21, w23
   12138:      	ldr	x9, [sp, #0x88]
   1213c:      	ldr	x25, [sp, #0x8]
   12140:      	csel	w10, wzr, w10, lo
   12144:      	cmp	w23, w21
   12148:      	csel	w11, w23, w21, lo
   1214c:      	cinc	w13, w11, hi
   12150:      	sub	w14, w23, w13
   12154:      	subs	x12, x12, x13
   12158:      	str	w14, [sp, #0x68]
   1215c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   12160:      	cmp	x12, #0xfff
   12164:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   12168:      	cmp	w23, w21
   1216c:      	b.ls	0x12178 <generic_rawtp_path+0x7e88>
   12170:      	mov	w13, #0x2f              // =47
   12174:      	strb	w13, [x8, x12]
   12178:      	add	x19, x8, x12
   1217c:      	cmp	w23, w21
   12180:      	add	x2, x9, x10
   12184:      	and	w1, w11, #0xff
   12188:      	mov	w8, #0x4                // =4
   1218c:      	cinc	x0, x19, hi
   12190:      	blr	x8
   12194:      	ldr	x25, [sp, #0x8]
   12198:      	cmp	w23, w21
   1219c:      	str	x19, [sp, #0x60]
   121a0:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   121a4:      	ldr	x21, [sp, #0x78]
   121a8:      	ldp	x2, x24, [sp, #0x50]
   121ac:      	str	x21, [sp, #0x48]
   121b0:      	b	0x12204 <generic_rawtp_path+0x7f14>
   121b4:      	add	x2, x24, #0x10
   121b8:      	mov	w8, #0x4                // =4
   121bc:      	add	x9, sp, #0x98
   121c0:      	add	x0, sp, #0x98
   121c4:      	mov	w1, #0x8                // =8
   121c8:      	blr	x8
   121cc:      	ldr	x8, [sp, #0x58]
   121d0:      	ldr	x9, [sp, #0x98]
   121d4:      	cmp	x8, x9
   121d8:      	ldr	x25, [sp, #0x8]
   121dc:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   121e0:      	add	x2, x24, #0x18
   121e4:      	mov	w8, #0x4                // =4
   121e8:      	mov	x0, x22
   121ec:      	mov	w1, #0x8                // =8
   121f0:      	blr	x8
   121f4:      	ldr	x24, [sp, #0x98]
   121f8:      	ldr	x21, [sp, #0x48]
   121fc:      	add	x2, x24, #0x20
   12200:      	stp	x2, x24, [sp, #0x50]
   12204:      	ldr	x8, [sp, #0x30]
   12208:      	ldr	x25, [sp, #0x8]
   1220c:      	add	x9, sp, #0x70
   12210:      	cmp	x21, x8
   12214:      	b.ne	0x12224 <generic_rawtp_path+0x7f34>
   12218:      	ldr	x8, [sp, #0x38]
   1221c:      	cmp	x2, x8
   12220:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   12224:      	mov	w8, #0x4                // =4
   12228:      	add	x0, sp, #0x70
   1222c:      	mov	w1, #0x8                // =8
   12230:      	blr	x8
   12234:      	ldr	x8, [sp, #0x70]
   12238:      	cmp	x21, x8
   1223c:      	b.eq	0x12330 <generic_rawtp_path+0x8040>
   12240:      	add	x23, x21, #0x18
   12244:      	mov	w8, #0x4                // =4
   12248:      	add	x9, sp, #0x98
   1224c:      	add	x0, sp, #0x98
   12250:      	mov	w1, #0x8                // =8
   12254:      	mov	x2, x23
   12258:      	blr	x8
   1225c:      	ldr	x8, [sp, #0x98]
   12260:      	cmp	x8, x21
   12264:      	b.eq	0x12330 <generic_rawtp_path+0x8040>
   12268:      	mov	w8, #0x4                // =4
   1226c:      	add	x9, sp, #0x78
   12270:      	add	x0, sp, #0x78
   12274:      	mov	w1, #0x8                // =8
   12278:      	mov	x2, x23
   1227c:      	blr	x8
   12280:      	add	x2, x21, #0x20
   12284:      	mov	w8, #0x4                // =4
   12288:      	mov	w9, #0x10               // =16
   1228c:      	add	x10, sp, #0x80
   12290:      	add	x0, sp, #0x80
   12294:      	mov	w1, #0x10               // =16
   12298:      	blr	x8
   1229c:      	ldr	w21, [sp, #0x84]
   122a0:      	ldr	x8, [sp, #0x40]
   122a4:      	ldr	x10, [sp, #0x60]
   122a8:      	sub	x12, x10, x8
   122ac:      	ldr	w23, [sp, #0x68]
   122b0:      	subs	w10, w21, w23
   122b4:      	ldr	x9, [sp, #0x88]
   122b8:      	ldr	x25, [sp, #0x8]
   122bc:      	csel	w10, wzr, w10, lo
   122c0:      	cmp	w23, w21
   122c4:      	csel	w11, w23, w21, lo
   122c8:      	cinc	w13, w11, hi
   122cc:      	sub	w14, w23, w13
   122d0:      	subs	x12, x12, x13
   122d4:      	str	w14, [sp, #0x68]
   122d8:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   122dc:      	cmp	x12, #0xfff
   122e0:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   122e4:      	cmp	w23, w21
   122e8:      	b.ls	0x122f4 <generic_rawtp_path+0x8004>
   122ec:      	mov	w13, #0x2f              // =47
   122f0:      	strb	w13, [x8, x12]
   122f4:      	add	x19, x8, x12
   122f8:      	cmp	w23, w21
   122fc:      	add	x2, x9, x10
   12300:      	and	w1, w11, #0xff
   12304:      	mov	w8, #0x4                // =4
   12308:      	cinc	x0, x19, hi
   1230c:      	blr	x8
   12310:      	ldr	x25, [sp, #0x8]
   12314:      	cmp	w23, w21
   12318:      	str	x19, [sp, #0x60]
   1231c:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   12320:      	ldr	x21, [sp, #0x78]
   12324:      	ldp	x2, x24, [sp, #0x50]
   12328:      	str	x21, [sp, #0x48]
   1232c:      	b	0x12380 <generic_rawtp_path+0x8090>
   12330:      	add	x2, x24, #0x10
   12334:      	mov	w8, #0x4                // =4
   12338:      	add	x9, sp, #0x98
   1233c:      	add	x0, sp, #0x98
   12340:      	mov	w1, #0x8                // =8
   12344:      	blr	x8
   12348:      	ldr	x8, [sp, #0x58]
   1234c:      	ldr	x9, [sp, #0x98]
   12350:      	cmp	x8, x9
   12354:      	ldr	x25, [sp, #0x8]
   12358:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   1235c:      	add	x2, x24, #0x18
   12360:      	mov	w8, #0x4                // =4
   12364:      	mov	x0, x22
   12368:      	mov	w1, #0x8                // =8
   1236c:      	blr	x8
   12370:      	ldr	x24, [sp, #0x98]
   12374:      	ldr	x21, [sp, #0x48]
   12378:      	add	x2, x24, #0x20
   1237c:      	stp	x2, x24, [sp, #0x50]
   12380:      	ldr	x8, [sp, #0x30]
   12384:      	ldr	x25, [sp, #0x8]
   12388:      	add	x9, sp, #0x70
   1238c:      	cmp	x21, x8
   12390:      	b.ne	0x123a0 <generic_rawtp_path+0x80b0>
   12394:      	ldr	x8, [sp, #0x38]
   12398:      	cmp	x2, x8
   1239c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   123a0:      	mov	w8, #0x4                // =4
   123a4:      	add	x0, sp, #0x70
   123a8:      	mov	w1, #0x8                // =8
   123ac:      	blr	x8
   123b0:      	ldr	x8, [sp, #0x70]
   123b4:      	cmp	x21, x8
   123b8:      	b.eq	0x124ac <generic_rawtp_path+0x81bc>
   123bc:      	add	x23, x21, #0x18
   123c0:      	mov	w8, #0x4                // =4
   123c4:      	add	x9, sp, #0x98
   123c8:      	add	x0, sp, #0x98
   123cc:      	mov	w1, #0x8                // =8
   123d0:      	mov	x2, x23
   123d4:      	blr	x8
   123d8:      	ldr	x8, [sp, #0x98]
   123dc:      	cmp	x8, x21
   123e0:      	b.eq	0x124ac <generic_rawtp_path+0x81bc>
   123e4:      	mov	w8, #0x4                // =4
   123e8:      	add	x9, sp, #0x78
   123ec:      	add	x0, sp, #0x78
   123f0:      	mov	w1, #0x8                // =8
   123f4:      	mov	x2, x23
   123f8:      	blr	x8
   123fc:      	add	x2, x21, #0x20
   12400:      	mov	w8, #0x4                // =4
   12404:      	mov	w9, #0x10               // =16
   12408:      	add	x10, sp, #0x80
   1240c:      	add	x0, sp, #0x80
   12410:      	mov	w1, #0x10               // =16
   12414:      	blr	x8
   12418:      	ldr	w21, [sp, #0x84]
   1241c:      	ldr	x8, [sp, #0x40]
   12420:      	ldr	x10, [sp, #0x60]
   12424:      	sub	x12, x10, x8
   12428:      	ldr	w23, [sp, #0x68]
   1242c:      	subs	w10, w21, w23
   12430:      	ldr	x9, [sp, #0x88]
   12434:      	ldr	x25, [sp, #0x8]
   12438:      	csel	w10, wzr, w10, lo
   1243c:      	cmp	w23, w21
   12440:      	csel	w11, w23, w21, lo
   12444:      	cinc	w13, w11, hi
   12448:      	sub	w14, w23, w13
   1244c:      	subs	x12, x12, x13
   12450:      	str	w14, [sp, #0x68]
   12454:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   12458:      	cmp	x12, #0xfff
   1245c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   12460:      	cmp	w23, w21
   12464:      	b.ls	0x12470 <generic_rawtp_path+0x8180>
   12468:      	mov	w13, #0x2f              // =47
   1246c:      	strb	w13, [x8, x12]
   12470:      	add	x19, x8, x12
   12474:      	cmp	w23, w21
   12478:      	add	x2, x9, x10
   1247c:      	and	w1, w11, #0xff
   12480:      	mov	w8, #0x4                // =4
   12484:      	cinc	x0, x19, hi
   12488:      	blr	x8
   1248c:      	ldr	x25, [sp, #0x8]
   12490:      	cmp	w23, w21
   12494:      	str	x19, [sp, #0x60]
   12498:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   1249c:      	ldr	x21, [sp, #0x78]
   124a0:      	ldp	x2, x24, [sp, #0x50]
   124a4:      	str	x21, [sp, #0x48]
   124a8:      	b	0x124fc <generic_rawtp_path+0x820c>
   124ac:      	add	x2, x24, #0x10
   124b0:      	mov	w8, #0x4                // =4
   124b4:      	add	x9, sp, #0x98
   124b8:      	add	x0, sp, #0x98
   124bc:      	mov	w1, #0x8                // =8
   124c0:      	blr	x8
   124c4:      	ldr	x8, [sp, #0x58]
   124c8:      	ldr	x9, [sp, #0x98]
   124cc:      	cmp	x8, x9
   124d0:      	ldr	x25, [sp, #0x8]
   124d4:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   124d8:      	add	x2, x24, #0x18
   124dc:      	mov	w8, #0x4                // =4
   124e0:      	mov	x0, x22
   124e4:      	mov	w1, #0x8                // =8
   124e8:      	blr	x8
   124ec:      	ldr	x24, [sp, #0x98]
   124f0:      	ldr	x21, [sp, #0x48]
   124f4:      	add	x2, x24, #0x20
   124f8:      	stp	x2, x24, [sp, #0x50]
   124fc:      	ldr	x8, [sp, #0x30]
   12500:      	ldr	x25, [sp, #0x8]
   12504:      	add	x9, sp, #0x70
   12508:      	cmp	x21, x8
   1250c:      	b.ne	0x1251c <generic_rawtp_path+0x822c>
   12510:      	ldr	x8, [sp, #0x38]
   12514:      	cmp	x2, x8
   12518:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   1251c:      	mov	w8, #0x4                // =4
   12520:      	add	x0, sp, #0x70
   12524:      	mov	w1, #0x8                // =8
   12528:      	blr	x8
   1252c:      	ldr	x8, [sp, #0x70]
   12530:      	cmp	x21, x8
   12534:      	b.eq	0x12628 <generic_rawtp_path+0x8338>
   12538:      	add	x23, x21, #0x18
   1253c:      	mov	w8, #0x4                // =4
   12540:      	add	x9, sp, #0x98
   12544:      	add	x0, sp, #0x98
   12548:      	mov	w1, #0x8                // =8
   1254c:      	mov	x2, x23
   12550:      	blr	x8
   12554:      	ldr	x8, [sp, #0x98]
   12558:      	cmp	x8, x21
   1255c:      	b.eq	0x12628 <generic_rawtp_path+0x8338>
   12560:      	mov	w8, #0x4                // =4
   12564:      	add	x9, sp, #0x78
   12568:      	add	x0, sp, #0x78
   1256c:      	mov	w1, #0x8                // =8
   12570:      	mov	x2, x23
   12574:      	blr	x8
   12578:      	add	x2, x21, #0x20
   1257c:      	mov	w8, #0x4                // =4
   12580:      	mov	w9, #0x10               // =16
   12584:      	add	x10, sp, #0x80
   12588:      	add	x0, sp, #0x80
   1258c:      	mov	w1, #0x10               // =16
   12590:      	blr	x8
   12594:      	ldr	w21, [sp, #0x84]
   12598:      	ldr	x8, [sp, #0x40]
   1259c:      	ldr	x10, [sp, #0x60]
   125a0:      	sub	x12, x10, x8
   125a4:      	ldr	w23, [sp, #0x68]
   125a8:      	subs	w10, w21, w23
   125ac:      	ldr	x9, [sp, #0x88]
   125b0:      	ldr	x25, [sp, #0x8]
   125b4:      	csel	w10, wzr, w10, lo
   125b8:      	cmp	w23, w21
   125bc:      	csel	w11, w23, w21, lo
   125c0:      	cinc	w13, w11, hi
   125c4:      	sub	w14, w23, w13
   125c8:      	subs	x12, x12, x13
   125cc:      	str	w14, [sp, #0x68]
   125d0:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   125d4:      	cmp	x12, #0xfff
   125d8:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   125dc:      	cmp	w23, w21
   125e0:      	b.ls	0x125ec <generic_rawtp_path+0x82fc>
   125e4:      	mov	w13, #0x2f              // =47
   125e8:      	strb	w13, [x8, x12]
   125ec:      	add	x19, x8, x12
   125f0:      	cmp	w23, w21
   125f4:      	add	x2, x9, x10
   125f8:      	and	w1, w11, #0xff
   125fc:      	mov	w8, #0x4                // =4
   12600:      	cinc	x0, x19, hi
   12604:      	blr	x8
   12608:      	ldr	x25, [sp, #0x8]
   1260c:      	cmp	w23, w21
   12610:      	str	x19, [sp, #0x60]
   12614:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   12618:      	ldr	x21, [sp, #0x78]
   1261c:      	ldp	x2, x24, [sp, #0x50]
   12620:      	str	x21, [sp, #0x48]
   12624:      	b	0x12678 <generic_rawtp_path+0x8388>
   12628:      	add	x2, x24, #0x10
   1262c:      	mov	w8, #0x4                // =4
   12630:      	add	x9, sp, #0x98
   12634:      	add	x0, sp, #0x98
   12638:      	mov	w1, #0x8                // =8
   1263c:      	blr	x8
   12640:      	ldr	x8, [sp, #0x58]
   12644:      	ldr	x9, [sp, #0x98]
   12648:      	cmp	x8, x9
   1264c:      	ldr	x25, [sp, #0x8]
   12650:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   12654:      	add	x2, x24, #0x18
   12658:      	mov	w8, #0x4                // =4
   1265c:      	mov	x0, x22
   12660:      	mov	w1, #0x8                // =8
   12664:      	blr	x8
   12668:      	ldr	x24, [sp, #0x98]
   1266c:      	ldr	x21, [sp, #0x48]
   12670:      	add	x2, x24, #0x20
   12674:      	stp	x2, x24, [sp, #0x50]
   12678:      	ldr	x8, [sp, #0x30]
   1267c:      	ldr	x25, [sp, #0x8]
   12680:      	add	x9, sp, #0x70
   12684:      	cmp	x21, x8
   12688:      	b.ne	0x12698 <generic_rawtp_path+0x83a8>
   1268c:      	ldr	x8, [sp, #0x38]
   12690:      	cmp	x2, x8
   12694:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   12698:      	mov	w8, #0x4                // =4
   1269c:      	add	x0, sp, #0x70
   126a0:      	mov	w1, #0x8                // =8
   126a4:      	blr	x8
   126a8:      	ldr	x8, [sp, #0x70]
   126ac:      	cmp	x21, x8
   126b0:      	b.eq	0x127a4 <generic_rawtp_path+0x84b4>
   126b4:      	add	x23, x21, #0x18
   126b8:      	mov	w8, #0x4                // =4
   126bc:      	add	x9, sp, #0x98
   126c0:      	add	x0, sp, #0x98
   126c4:      	mov	w1, #0x8                // =8
   126c8:      	mov	x2, x23
   126cc:      	blr	x8
   126d0:      	ldr	x8, [sp, #0x98]
   126d4:      	cmp	x8, x21
   126d8:      	b.eq	0x127a4 <generic_rawtp_path+0x84b4>
   126dc:      	mov	w8, #0x4                // =4
   126e0:      	add	x9, sp, #0x78
   126e4:      	add	x0, sp, #0x78
   126e8:      	mov	w1, #0x8                // =8
   126ec:      	mov	x2, x23
   126f0:      	blr	x8
   126f4:      	add	x2, x21, #0x20
   126f8:      	mov	w8, #0x4                // =4
   126fc:      	mov	w9, #0x10               // =16
   12700:      	add	x10, sp, #0x80
   12704:      	add	x0, sp, #0x80
   12708:      	mov	w1, #0x10               // =16
   1270c:      	blr	x8
   12710:      	ldr	w21, [sp, #0x84]
   12714:      	ldr	x8, [sp, #0x40]
   12718:      	ldr	x10, [sp, #0x60]
   1271c:      	sub	x12, x10, x8
   12720:      	ldr	w23, [sp, #0x68]
   12724:      	subs	w10, w21, w23
   12728:      	ldr	x9, [sp, #0x88]
   1272c:      	ldr	x25, [sp, #0x8]
   12730:      	csel	w10, wzr, w10, lo
   12734:      	cmp	w23, w21
   12738:      	csel	w11, w23, w21, lo
   1273c:      	cinc	w13, w11, hi
   12740:      	sub	w14, w23, w13
   12744:      	subs	x12, x12, x13
   12748:      	str	w14, [sp, #0x68]
   1274c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   12750:      	cmp	x12, #0xfff
   12754:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   12758:      	cmp	w23, w21
   1275c:      	b.ls	0x12768 <generic_rawtp_path+0x8478>
   12760:      	mov	w13, #0x2f              // =47
   12764:      	strb	w13, [x8, x12]
   12768:      	add	x19, x8, x12
   1276c:      	cmp	w23, w21
   12770:      	add	x2, x9, x10
   12774:      	and	w1, w11, #0xff
   12778:      	mov	w8, #0x4                // =4
   1277c:      	cinc	x0, x19, hi
   12780:      	blr	x8
   12784:      	ldr	x25, [sp, #0x8]
   12788:      	cmp	w23, w21
   1278c:      	str	x19, [sp, #0x60]
   12790:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   12794:      	ldr	x21, [sp, #0x78]
   12798:      	ldp	x2, x24, [sp, #0x50]
   1279c:      	str	x21, [sp, #0x48]
   127a0:      	b	0x127f4 <generic_rawtp_path+0x8504>
   127a4:      	add	x2, x24, #0x10
   127a8:      	mov	w8, #0x4                // =4
   127ac:      	add	x9, sp, #0x98
   127b0:      	add	x0, sp, #0x98
   127b4:      	mov	w1, #0x8                // =8
   127b8:      	blr	x8
   127bc:      	ldr	x8, [sp, #0x58]
   127c0:      	ldr	x9, [sp, #0x98]
   127c4:      	cmp	x8, x9
   127c8:      	ldr	x25, [sp, #0x8]
   127cc:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   127d0:      	add	x2, x24, #0x18
   127d4:      	mov	w8, #0x4                // =4
   127d8:      	mov	x0, x22
   127dc:      	mov	w1, #0x8                // =8
   127e0:      	blr	x8
   127e4:      	ldr	x24, [sp, #0x98]
   127e8:      	ldr	x21, [sp, #0x48]
   127ec:      	add	x2, x24, #0x20
   127f0:      	stp	x2, x24, [sp, #0x50]
   127f4:      	ldr	x8, [sp, #0x30]
   127f8:      	ldr	x25, [sp, #0x8]
   127fc:      	add	x9, sp, #0x70
   12800:      	cmp	x21, x8
   12804:      	b.ne	0x12814 <generic_rawtp_path+0x8524>
   12808:      	ldr	x8, [sp, #0x38]
   1280c:      	cmp	x2, x8
   12810:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   12814:      	mov	w8, #0x4                // =4
   12818:      	add	x0, sp, #0x70
   1281c:      	mov	w1, #0x8                // =8
   12820:      	blr	x8
   12824:      	ldr	x8, [sp, #0x70]
   12828:      	cmp	x21, x8
   1282c:      	b.eq	0x12920 <generic_rawtp_path+0x8630>
   12830:      	add	x23, x21, #0x18
   12834:      	mov	w8, #0x4                // =4
   12838:      	add	x9, sp, #0x98
   1283c:      	add	x0, sp, #0x98
   12840:      	mov	w1, #0x8                // =8
   12844:      	mov	x2, x23
   12848:      	blr	x8
   1284c:      	ldr	x8, [sp, #0x98]
   12850:      	cmp	x8, x21
   12854:      	b.eq	0x12920 <generic_rawtp_path+0x8630>
   12858:      	mov	w8, #0x4                // =4
   1285c:      	add	x9, sp, #0x78
   12860:      	add	x0, sp, #0x78
   12864:      	mov	w1, #0x8                // =8
   12868:      	mov	x2, x23
   1286c:      	blr	x8
   12870:      	add	x2, x21, #0x20
   12874:      	mov	w8, #0x4                // =4
   12878:      	mov	w9, #0x10               // =16
   1287c:      	add	x10, sp, #0x80
   12880:      	add	x0, sp, #0x80
   12884:      	mov	w1, #0x10               // =16
   12888:      	blr	x8
   1288c:      	ldr	w21, [sp, #0x84]
   12890:      	ldr	x8, [sp, #0x40]
   12894:      	ldr	x10, [sp, #0x60]
   12898:      	sub	x12, x10, x8
   1289c:      	ldr	w23, [sp, #0x68]
   128a0:      	subs	w10, w21, w23
   128a4:      	ldr	x9, [sp, #0x88]
   128a8:      	ldr	x25, [sp, #0x8]
   128ac:      	csel	w10, wzr, w10, lo
   128b0:      	cmp	w23, w21
   128b4:      	csel	w11, w23, w21, lo
   128b8:      	cinc	w13, w11, hi
   128bc:      	sub	w14, w23, w13
   128c0:      	subs	x12, x12, x13
   128c4:      	str	w14, [sp, #0x68]
   128c8:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   128cc:      	cmp	x12, #0xfff
   128d0:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   128d4:      	cmp	w23, w21
   128d8:      	b.ls	0x128e4 <generic_rawtp_path+0x85f4>
   128dc:      	mov	w13, #0x2f              // =47
   128e0:      	strb	w13, [x8, x12]
   128e4:      	add	x19, x8, x12
   128e8:      	cmp	w23, w21
   128ec:      	add	x2, x9, x10
   128f0:      	and	w1, w11, #0xff
   128f4:      	mov	w8, #0x4                // =4
   128f8:      	cinc	x0, x19, hi
   128fc:      	blr	x8
   12900:      	ldr	x25, [sp, #0x8]
   12904:      	cmp	w23, w21
   12908:      	str	x19, [sp, #0x60]
   1290c:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   12910:      	ldr	x21, [sp, #0x78]
   12914:      	ldp	x2, x24, [sp, #0x50]
   12918:      	str	x21, [sp, #0x48]
   1291c:      	b	0x12970 <generic_rawtp_path+0x8680>
   12920:      	add	x2, x24, #0x10
   12924:      	mov	w8, #0x4                // =4
   12928:      	add	x9, sp, #0x98
   1292c:      	add	x0, sp, #0x98
   12930:      	mov	w1, #0x8                // =8
   12934:      	blr	x8
   12938:      	ldr	x8, [sp, #0x58]
   1293c:      	ldr	x9, [sp, #0x98]
   12940:      	cmp	x8, x9
   12944:      	ldr	x25, [sp, #0x8]
   12948:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   1294c:      	add	x2, x24, #0x18
   12950:      	mov	w8, #0x4                // =4
   12954:      	mov	x0, x22
   12958:      	mov	w1, #0x8                // =8
   1295c:      	blr	x8
   12960:      	ldr	x24, [sp, #0x98]
   12964:      	ldr	x21, [sp, #0x48]
   12968:      	add	x2, x24, #0x20
   1296c:      	stp	x2, x24, [sp, #0x50]
   12970:      	ldr	x8, [sp, #0x30]
   12974:      	ldr	x25, [sp, #0x8]
   12978:      	add	x9, sp, #0x70
   1297c:      	cmp	x21, x8
   12980:      	b.ne	0x12990 <generic_rawtp_path+0x86a0>
   12984:      	ldr	x8, [sp, #0x38]
   12988:      	cmp	x2, x8
   1298c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   12990:      	mov	w8, #0x4                // =4
   12994:      	add	x0, sp, #0x70
   12998:      	mov	w1, #0x8                // =8
   1299c:      	blr	x8
   129a0:      	ldr	x8, [sp, #0x70]
   129a4:      	cmp	x21, x8
   129a8:      	b.eq	0x12a9c <generic_rawtp_path+0x87ac>
   129ac:      	add	x23, x21, #0x18
   129b0:      	mov	w8, #0x4                // =4
   129b4:      	add	x9, sp, #0x98
   129b8:      	add	x0, sp, #0x98
   129bc:      	mov	w1, #0x8                // =8
   129c0:      	mov	x2, x23
   129c4:      	blr	x8
   129c8:      	ldr	x8, [sp, #0x98]
   129cc:      	cmp	x8, x21
   129d0:      	b.eq	0x12a9c <generic_rawtp_path+0x87ac>
   129d4:      	mov	w8, #0x4                // =4
   129d8:      	add	x9, sp, #0x78
   129dc:      	add	x0, sp, #0x78
   129e0:      	mov	w1, #0x8                // =8
   129e4:      	mov	x2, x23
   129e8:      	blr	x8
   129ec:      	add	x2, x21, #0x20
   129f0:      	mov	w8, #0x4                // =4
   129f4:      	mov	w9, #0x10               // =16
   129f8:      	add	x10, sp, #0x80
   129fc:      	add	x0, sp, #0x80
   12a00:      	mov	w1, #0x10               // =16
   12a04:      	blr	x8
   12a08:      	ldr	w21, [sp, #0x84]
   12a0c:      	ldr	x8, [sp, #0x40]
   12a10:      	ldr	x10, [sp, #0x60]
   12a14:      	sub	x12, x10, x8
   12a18:      	ldr	w23, [sp, #0x68]
   12a1c:      	subs	w10, w21, w23
   12a20:      	ldr	x9, [sp, #0x88]
   12a24:      	ldr	x25, [sp, #0x8]
   12a28:      	csel	w10, wzr, w10, lo
   12a2c:      	cmp	w23, w21
   12a30:      	csel	w11, w23, w21, lo
   12a34:      	cinc	w13, w11, hi
   12a38:      	sub	w14, w23, w13
   12a3c:      	subs	x12, x12, x13
   12a40:      	str	w14, [sp, #0x68]
   12a44:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   12a48:      	cmp	x12, #0xfff
   12a4c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   12a50:      	cmp	w23, w21
   12a54:      	b.ls	0x12a60 <generic_rawtp_path+0x8770>
   12a58:      	mov	w13, #0x2f              // =47
   12a5c:      	strb	w13, [x8, x12]
   12a60:      	add	x19, x8, x12
   12a64:      	cmp	w23, w21
   12a68:      	add	x2, x9, x10
   12a6c:      	and	w1, w11, #0xff
   12a70:      	mov	w8, #0x4                // =4
   12a74:      	cinc	x0, x19, hi
   12a78:      	blr	x8
   12a7c:      	ldr	x25, [sp, #0x8]
   12a80:      	cmp	w23, w21
   12a84:      	str	x19, [sp, #0x60]
   12a88:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   12a8c:      	ldr	x21, [sp, #0x78]
   12a90:      	ldp	x2, x24, [sp, #0x50]
   12a94:      	str	x21, [sp, #0x48]
   12a98:      	b	0x12aec <generic_rawtp_path+0x87fc>
   12a9c:      	add	x2, x24, #0x10
   12aa0:      	mov	w8, #0x4                // =4
   12aa4:      	add	x9, sp, #0x98
   12aa8:      	add	x0, sp, #0x98
   12aac:      	mov	w1, #0x8                // =8
   12ab0:      	blr	x8
   12ab4:      	ldr	x8, [sp, #0x58]
   12ab8:      	ldr	x9, [sp, #0x98]
   12abc:      	cmp	x8, x9
   12ac0:      	ldr	x25, [sp, #0x8]
   12ac4:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   12ac8:      	add	x2, x24, #0x18
   12acc:      	mov	w8, #0x4                // =4
   12ad0:      	mov	x0, x22
   12ad4:      	mov	w1, #0x8                // =8
   12ad8:      	blr	x8
   12adc:      	ldr	x24, [sp, #0x98]
   12ae0:      	ldr	x21, [sp, #0x48]
   12ae4:      	add	x2, x24, #0x20
   12ae8:      	stp	x2, x24, [sp, #0x50]
   12aec:      	ldr	x8, [sp, #0x30]
   12af0:      	ldr	x25, [sp, #0x8]
   12af4:      	add	x9, sp, #0x70
   12af8:      	cmp	x21, x8
   12afc:      	b.ne	0x12b0c <generic_rawtp_path+0x881c>
   12b00:      	ldr	x8, [sp, #0x38]
   12b04:      	cmp	x2, x8
   12b08:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   12b0c:      	mov	w8, #0x4                // =4
   12b10:      	add	x0, sp, #0x70
   12b14:      	mov	w1, #0x8                // =8
   12b18:      	blr	x8
   12b1c:      	ldr	x8, [sp, #0x70]
   12b20:      	cmp	x21, x8
   12b24:      	b.eq	0x12c18 <generic_rawtp_path+0x8928>
   12b28:      	add	x23, x21, #0x18
   12b2c:      	mov	w8, #0x4                // =4
   12b30:      	add	x9, sp, #0x98
   12b34:      	add	x0, sp, #0x98
   12b38:      	mov	w1, #0x8                // =8
   12b3c:      	mov	x2, x23
   12b40:      	blr	x8
   12b44:      	ldr	x8, [sp, #0x98]
   12b48:      	cmp	x8, x21
   12b4c:      	b.eq	0x12c18 <generic_rawtp_path+0x8928>
   12b50:      	mov	w8, #0x4                // =4
   12b54:      	add	x9, sp, #0x78
   12b58:      	add	x0, sp, #0x78
   12b5c:      	mov	w1, #0x8                // =8
   12b60:      	mov	x2, x23
   12b64:      	blr	x8
   12b68:      	add	x2, x21, #0x20
   12b6c:      	mov	w8, #0x4                // =4
   12b70:      	mov	w9, #0x10               // =16
   12b74:      	add	x10, sp, #0x80
   12b78:      	add	x0, sp, #0x80
   12b7c:      	mov	w1, #0x10               // =16
   12b80:      	blr	x8
   12b84:      	ldr	w21, [sp, #0x84]
   12b88:      	ldr	x8, [sp, #0x40]
   12b8c:      	ldr	x10, [sp, #0x60]
   12b90:      	sub	x12, x10, x8
   12b94:      	ldr	w23, [sp, #0x68]
   12b98:      	subs	w10, w21, w23
   12b9c:      	ldr	x9, [sp, #0x88]
   12ba0:      	ldr	x25, [sp, #0x8]
   12ba4:      	csel	w10, wzr, w10, lo
   12ba8:      	cmp	w23, w21
   12bac:      	csel	w11, w23, w21, lo
   12bb0:      	cinc	w13, w11, hi
   12bb4:      	sub	w14, w23, w13
   12bb8:      	subs	x12, x12, x13
   12bbc:      	str	w14, [sp, #0x68]
   12bc0:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   12bc4:      	cmp	x12, #0xfff
   12bc8:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   12bcc:      	cmp	w23, w21
   12bd0:      	b.ls	0x12bdc <generic_rawtp_path+0x88ec>
   12bd4:      	mov	w13, #0x2f              // =47
   12bd8:      	strb	w13, [x8, x12]
   12bdc:      	add	x19, x8, x12
   12be0:      	cmp	w23, w21
   12be4:      	add	x2, x9, x10
   12be8:      	and	w1, w11, #0xff
   12bec:      	mov	w8, #0x4                // =4
   12bf0:      	cinc	x0, x19, hi
   12bf4:      	blr	x8
   12bf8:      	ldr	x25, [sp, #0x8]
   12bfc:      	cmp	w23, w21
   12c00:      	str	x19, [sp, #0x60]
   12c04:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   12c08:      	ldr	x21, [sp, #0x78]
   12c0c:      	ldp	x2, x24, [sp, #0x50]
   12c10:      	str	x21, [sp, #0x48]
   12c14:      	b	0x12c68 <generic_rawtp_path+0x8978>
   12c18:      	add	x2, x24, #0x10
   12c1c:      	mov	w8, #0x4                // =4
   12c20:      	add	x9, sp, #0x98
   12c24:      	add	x0, sp, #0x98
   12c28:      	mov	w1, #0x8                // =8
   12c2c:      	blr	x8
   12c30:      	ldr	x8, [sp, #0x58]
   12c34:      	ldr	x9, [sp, #0x98]
   12c38:      	cmp	x8, x9
   12c3c:      	ldr	x25, [sp, #0x8]
   12c40:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   12c44:      	add	x2, x24, #0x18
   12c48:      	mov	w8, #0x4                // =4
   12c4c:      	mov	x0, x22
   12c50:      	mov	w1, #0x8                // =8
   12c54:      	blr	x8
   12c58:      	ldr	x24, [sp, #0x98]
   12c5c:      	ldr	x21, [sp, #0x48]
   12c60:      	add	x2, x24, #0x20
   12c64:      	stp	x2, x24, [sp, #0x50]
   12c68:      	ldr	x8, [sp, #0x30]
   12c6c:      	ldr	x25, [sp, #0x8]
   12c70:      	add	x9, sp, #0x70
   12c74:      	cmp	x21, x8
   12c78:      	b.ne	0x12c88 <generic_rawtp_path+0x8998>
   12c7c:      	ldr	x8, [sp, #0x38]
   12c80:      	cmp	x2, x8
   12c84:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   12c88:      	mov	w8, #0x4                // =4
   12c8c:      	add	x0, sp, #0x70
   12c90:      	mov	w1, #0x8                // =8
   12c94:      	blr	x8
   12c98:      	ldr	x8, [sp, #0x70]
   12c9c:      	cmp	x21, x8
   12ca0:      	b.eq	0x12d94 <generic_rawtp_path+0x8aa4>
   12ca4:      	add	x23, x21, #0x18
   12ca8:      	mov	w8, #0x4                // =4
   12cac:      	add	x9, sp, #0x98
   12cb0:      	add	x0, sp, #0x98
   12cb4:      	mov	w1, #0x8                // =8
   12cb8:      	mov	x2, x23
   12cbc:      	blr	x8
   12cc0:      	ldr	x8, [sp, #0x98]
   12cc4:      	cmp	x8, x21
   12cc8:      	b.eq	0x12d94 <generic_rawtp_path+0x8aa4>
   12ccc:      	mov	w8, #0x4                // =4
   12cd0:      	add	x9, sp, #0x78
   12cd4:      	add	x0, sp, #0x78
   12cd8:      	mov	w1, #0x8                // =8
   12cdc:      	mov	x2, x23
   12ce0:      	blr	x8
   12ce4:      	add	x2, x21, #0x20
   12ce8:      	mov	w8, #0x4                // =4
   12cec:      	mov	w9, #0x10               // =16
   12cf0:      	add	x10, sp, #0x80
   12cf4:      	add	x0, sp, #0x80
   12cf8:      	mov	w1, #0x10               // =16
   12cfc:      	blr	x8
   12d00:      	ldr	w21, [sp, #0x84]
   12d04:      	ldr	x8, [sp, #0x40]
   12d08:      	ldr	x10, [sp, #0x60]
   12d0c:      	sub	x12, x10, x8
   12d10:      	ldr	w23, [sp, #0x68]
   12d14:      	subs	w10, w21, w23
   12d18:      	ldr	x9, [sp, #0x88]
   12d1c:      	ldr	x25, [sp, #0x8]
   12d20:      	csel	w10, wzr, w10, lo
   12d24:      	cmp	w23, w21
   12d28:      	csel	w11, w23, w21, lo
   12d2c:      	cinc	w13, w11, hi
   12d30:      	sub	w14, w23, w13
   12d34:      	subs	x12, x12, x13
   12d38:      	str	w14, [sp, #0x68]
   12d3c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   12d40:      	cmp	x12, #0xfff
   12d44:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   12d48:      	cmp	w23, w21
   12d4c:      	b.ls	0x12d58 <generic_rawtp_path+0x8a68>
   12d50:      	mov	w13, #0x2f              // =47
   12d54:      	strb	w13, [x8, x12]
   12d58:      	add	x19, x8, x12
   12d5c:      	cmp	w23, w21
   12d60:      	add	x2, x9, x10
   12d64:      	and	w1, w11, #0xff
   12d68:      	mov	w8, #0x4                // =4
   12d6c:      	cinc	x0, x19, hi
   12d70:      	blr	x8
   12d74:      	ldr	x25, [sp, #0x8]
   12d78:      	cmp	w23, w21
   12d7c:      	str	x19, [sp, #0x60]
   12d80:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   12d84:      	ldr	x21, [sp, #0x78]
   12d88:      	ldp	x2, x24, [sp, #0x50]
   12d8c:      	str	x21, [sp, #0x48]
   12d90:      	b	0x12de4 <generic_rawtp_path+0x8af4>
   12d94:      	add	x2, x24, #0x10
   12d98:      	mov	w8, #0x4                // =4
   12d9c:      	add	x9, sp, #0x98
   12da0:      	add	x0, sp, #0x98
   12da4:      	mov	w1, #0x8                // =8
   12da8:      	blr	x8
   12dac:      	ldr	x8, [sp, #0x58]
   12db0:      	ldr	x9, [sp, #0x98]
   12db4:      	cmp	x8, x9
   12db8:      	ldr	x25, [sp, #0x8]
   12dbc:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   12dc0:      	add	x2, x24, #0x18
   12dc4:      	mov	w8, #0x4                // =4
   12dc8:      	mov	x0, x22
   12dcc:      	mov	w1, #0x8                // =8
   12dd0:      	blr	x8
   12dd4:      	ldr	x24, [sp, #0x98]
   12dd8:      	ldr	x21, [sp, #0x48]
   12ddc:      	add	x2, x24, #0x20
   12de0:      	stp	x2, x24, [sp, #0x50]
   12de4:      	ldr	x8, [sp, #0x30]
   12de8:      	ldr	x25, [sp, #0x8]
   12dec:      	add	x9, sp, #0x70
   12df0:      	cmp	x21, x8
   12df4:      	b.ne	0x12e04 <generic_rawtp_path+0x8b14>
   12df8:      	ldr	x8, [sp, #0x38]
   12dfc:      	cmp	x2, x8
   12e00:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   12e04:      	mov	w8, #0x4                // =4
   12e08:      	add	x0, sp, #0x70
   12e0c:      	mov	w1, #0x8                // =8
   12e10:      	blr	x8
   12e14:      	ldr	x8, [sp, #0x70]
   12e18:      	cmp	x21, x8
   12e1c:      	b.eq	0x12f10 <generic_rawtp_path+0x8c20>
   12e20:      	add	x23, x21, #0x18
   12e24:      	mov	w8, #0x4                // =4
   12e28:      	add	x9, sp, #0x98
   12e2c:      	add	x0, sp, #0x98
   12e30:      	mov	w1, #0x8                // =8
   12e34:      	mov	x2, x23
   12e38:      	blr	x8
   12e3c:      	ldr	x8, [sp, #0x98]
   12e40:      	cmp	x8, x21
   12e44:      	b.eq	0x12f10 <generic_rawtp_path+0x8c20>
   12e48:      	mov	w8, #0x4                // =4
   12e4c:      	add	x9, sp, #0x78
   12e50:      	add	x0, sp, #0x78
   12e54:      	mov	w1, #0x8                // =8
   12e58:      	mov	x2, x23
   12e5c:      	blr	x8
   12e60:      	add	x2, x21, #0x20
   12e64:      	mov	w8, #0x4                // =4
   12e68:      	mov	w9, #0x10               // =16
   12e6c:      	add	x10, sp, #0x80
   12e70:      	add	x0, sp, #0x80
   12e74:      	mov	w1, #0x10               // =16
   12e78:      	blr	x8
   12e7c:      	ldr	w21, [sp, #0x84]
   12e80:      	ldr	x8, [sp, #0x40]
   12e84:      	ldr	x10, [sp, #0x60]
   12e88:      	sub	x12, x10, x8
   12e8c:      	ldr	w23, [sp, #0x68]
   12e90:      	subs	w10, w21, w23
   12e94:      	ldr	x9, [sp, #0x88]
   12e98:      	ldr	x25, [sp, #0x8]
   12e9c:      	csel	w10, wzr, w10, lo
   12ea0:      	cmp	w23, w21
   12ea4:      	csel	w11, w23, w21, lo
   12ea8:      	cinc	w13, w11, hi
   12eac:      	sub	w14, w23, w13
   12eb0:      	subs	x12, x12, x13
   12eb4:      	str	w14, [sp, #0x68]
   12eb8:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   12ebc:      	cmp	x12, #0xfff
   12ec0:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   12ec4:      	cmp	w23, w21
   12ec8:      	b.ls	0x12ed4 <generic_rawtp_path+0x8be4>
   12ecc:      	mov	w13, #0x2f              // =47
   12ed0:      	strb	w13, [x8, x12]
   12ed4:      	add	x19, x8, x12
   12ed8:      	cmp	w23, w21
   12edc:      	add	x2, x9, x10
   12ee0:      	and	w1, w11, #0xff
   12ee4:      	mov	w8, #0x4                // =4
   12ee8:      	cinc	x0, x19, hi
   12eec:      	blr	x8
   12ef0:      	ldr	x25, [sp, #0x8]
   12ef4:      	cmp	w23, w21
   12ef8:      	str	x19, [sp, #0x60]
   12efc:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   12f00:      	ldr	x21, [sp, #0x78]
   12f04:      	ldp	x2, x24, [sp, #0x50]
   12f08:      	str	x21, [sp, #0x48]
   12f0c:      	b	0x12f60 <generic_rawtp_path+0x8c70>
   12f10:      	add	x2, x24, #0x10
   12f14:      	mov	w8, #0x4                // =4
   12f18:      	add	x9, sp, #0x98
   12f1c:      	add	x0, sp, #0x98
   12f20:      	mov	w1, #0x8                // =8
   12f24:      	blr	x8
   12f28:      	ldr	x8, [sp, #0x58]
   12f2c:      	ldr	x9, [sp, #0x98]
   12f30:      	cmp	x8, x9
   12f34:      	ldr	x25, [sp, #0x8]
   12f38:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   12f3c:      	add	x2, x24, #0x18
   12f40:      	mov	w8, #0x4                // =4
   12f44:      	mov	x0, x22
   12f48:      	mov	w1, #0x8                // =8
   12f4c:      	blr	x8
   12f50:      	ldr	x24, [sp, #0x98]
   12f54:      	ldr	x21, [sp, #0x48]
   12f58:      	add	x2, x24, #0x20
   12f5c:      	stp	x2, x24, [sp, #0x50]
   12f60:      	ldr	x8, [sp, #0x30]
   12f64:      	ldr	x25, [sp, #0x8]
   12f68:      	add	x9, sp, #0x70
   12f6c:      	cmp	x21, x8
   12f70:      	b.ne	0x12f80 <generic_rawtp_path+0x8c90>
   12f74:      	ldr	x8, [sp, #0x38]
   12f78:      	cmp	x2, x8
   12f7c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   12f80:      	mov	w8, #0x4                // =4
   12f84:      	add	x0, sp, #0x70
   12f88:      	mov	w1, #0x8                // =8
   12f8c:      	blr	x8
   12f90:      	ldr	x8, [sp, #0x70]
   12f94:      	cmp	x21, x8
   12f98:      	b.eq	0x1308c <generic_rawtp_path+0x8d9c>
   12f9c:      	add	x23, x21, #0x18
   12fa0:      	mov	w8, #0x4                // =4
   12fa4:      	add	x9, sp, #0x98
   12fa8:      	add	x0, sp, #0x98
   12fac:      	mov	w1, #0x8                // =8
   12fb0:      	mov	x2, x23
   12fb4:      	blr	x8
   12fb8:      	ldr	x8, [sp, #0x98]
   12fbc:      	cmp	x8, x21
   12fc0:      	b.eq	0x1308c <generic_rawtp_path+0x8d9c>
   12fc4:      	mov	w8, #0x4                // =4
   12fc8:      	add	x9, sp, #0x78
   12fcc:      	add	x0, sp, #0x78
   12fd0:      	mov	w1, #0x8                // =8
   12fd4:      	mov	x2, x23
   12fd8:      	blr	x8
   12fdc:      	add	x2, x21, #0x20
   12fe0:      	mov	w8, #0x4                // =4
   12fe4:      	mov	w9, #0x10               // =16
   12fe8:      	add	x10, sp, #0x80
   12fec:      	add	x0, sp, #0x80
   12ff0:      	mov	w1, #0x10               // =16
   12ff4:      	blr	x8
   12ff8:      	ldr	w21, [sp, #0x84]
   12ffc:      	ldr	x8, [sp, #0x40]
   13000:      	ldr	x10, [sp, #0x60]
   13004:      	sub	x12, x10, x8
   13008:      	ldr	w23, [sp, #0x68]
   1300c:      	subs	w10, w21, w23
   13010:      	ldr	x9, [sp, #0x88]
   13014:      	ldr	x25, [sp, #0x8]
   13018:      	csel	w10, wzr, w10, lo
   1301c:      	cmp	w23, w21
   13020:      	csel	w11, w23, w21, lo
   13024:      	cinc	w13, w11, hi
   13028:      	sub	w14, w23, w13
   1302c:      	subs	x12, x12, x13
   13030:      	str	w14, [sp, #0x68]
   13034:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   13038:      	cmp	x12, #0xfff
   1303c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   13040:      	cmp	w23, w21
   13044:      	b.ls	0x13050 <generic_rawtp_path+0x8d60>
   13048:      	mov	w13, #0x2f              // =47
   1304c:      	strb	w13, [x8, x12]
   13050:      	add	x19, x8, x12
   13054:      	cmp	w23, w21
   13058:      	add	x2, x9, x10
   1305c:      	and	w1, w11, #0xff
   13060:      	mov	w8, #0x4                // =4
   13064:      	cinc	x0, x19, hi
   13068:      	blr	x8
   1306c:      	ldr	x25, [sp, #0x8]
   13070:      	cmp	w23, w21
   13074:      	str	x19, [sp, #0x60]
   13078:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   1307c:      	ldr	x21, [sp, #0x78]
   13080:      	ldp	x2, x24, [sp, #0x50]
   13084:      	str	x21, [sp, #0x48]
   13088:      	b	0x130dc <generic_rawtp_path+0x8dec>
   1308c:      	add	x2, x24, #0x10
   13090:      	mov	w8, #0x4                // =4
   13094:      	add	x9, sp, #0x98
   13098:      	add	x0, sp, #0x98
   1309c:      	mov	w1, #0x8                // =8
   130a0:      	blr	x8
   130a4:      	ldr	x8, [sp, #0x58]
   130a8:      	ldr	x9, [sp, #0x98]
   130ac:      	cmp	x8, x9
   130b0:      	ldr	x25, [sp, #0x8]
   130b4:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   130b8:      	add	x2, x24, #0x18
   130bc:      	mov	w8, #0x4                // =4
   130c0:      	mov	x0, x22
   130c4:      	mov	w1, #0x8                // =8
   130c8:      	blr	x8
   130cc:      	ldr	x24, [sp, #0x98]
   130d0:      	ldr	x21, [sp, #0x48]
   130d4:      	add	x2, x24, #0x20
   130d8:      	stp	x2, x24, [sp, #0x50]
   130dc:      	ldr	x8, [sp, #0x30]
   130e0:      	ldr	x25, [sp, #0x8]
   130e4:      	add	x9, sp, #0x70
   130e8:      	cmp	x21, x8
   130ec:      	b.ne	0x130fc <generic_rawtp_path+0x8e0c>
   130f0:      	ldr	x8, [sp, #0x38]
   130f4:      	cmp	x2, x8
   130f8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   130fc:      	mov	w8, #0x4                // =4
   13100:      	add	x0, sp, #0x70
   13104:      	mov	w1, #0x8                // =8
   13108:      	blr	x8
   1310c:      	ldr	x8, [sp, #0x70]
   13110:      	cmp	x21, x8
   13114:      	b.eq	0x13208 <generic_rawtp_path+0x8f18>
   13118:      	add	x23, x21, #0x18
   1311c:      	mov	w8, #0x4                // =4
   13120:      	add	x9, sp, #0x98
   13124:      	add	x0, sp, #0x98
   13128:      	mov	w1, #0x8                // =8
   1312c:      	mov	x2, x23
   13130:      	blr	x8
   13134:      	ldr	x8, [sp, #0x98]
   13138:      	cmp	x8, x21
   1313c:      	b.eq	0x13208 <generic_rawtp_path+0x8f18>
   13140:      	mov	w8, #0x4                // =4
   13144:      	add	x9, sp, #0x78
   13148:      	add	x0, sp, #0x78
   1314c:      	mov	w1, #0x8                // =8
   13150:      	mov	x2, x23
   13154:      	blr	x8
   13158:      	add	x2, x21, #0x20
   1315c:      	mov	w8, #0x4                // =4
   13160:      	mov	w9, #0x10               // =16
   13164:      	add	x10, sp, #0x80
   13168:      	add	x0, sp, #0x80
   1316c:      	mov	w1, #0x10               // =16
   13170:      	blr	x8
   13174:      	ldr	w21, [sp, #0x84]
   13178:      	ldr	x8, [sp, #0x40]
   1317c:      	ldr	x10, [sp, #0x60]
   13180:      	sub	x12, x10, x8
   13184:      	ldr	w23, [sp, #0x68]
   13188:      	subs	w10, w21, w23
   1318c:      	ldr	x9, [sp, #0x88]
   13190:      	ldr	x25, [sp, #0x8]
   13194:      	csel	w10, wzr, w10, lo
   13198:      	cmp	w23, w21
   1319c:      	csel	w11, w23, w21, lo
   131a0:      	cinc	w13, w11, hi
   131a4:      	sub	w14, w23, w13
   131a8:      	subs	x12, x12, x13
   131ac:      	str	w14, [sp, #0x68]
   131b0:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   131b4:      	cmp	x12, #0xfff
   131b8:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   131bc:      	cmp	w23, w21
   131c0:      	b.ls	0x131cc <generic_rawtp_path+0x8edc>
   131c4:      	mov	w13, #0x2f              // =47
   131c8:      	strb	w13, [x8, x12]
   131cc:      	add	x19, x8, x12
   131d0:      	cmp	w23, w21
   131d4:      	add	x2, x9, x10
   131d8:      	and	w1, w11, #0xff
   131dc:      	mov	w8, #0x4                // =4
   131e0:      	cinc	x0, x19, hi
   131e4:      	blr	x8
   131e8:      	ldr	x25, [sp, #0x8]
   131ec:      	cmp	w23, w21
   131f0:      	str	x19, [sp, #0x60]
   131f4:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   131f8:      	ldr	x21, [sp, #0x78]
   131fc:      	ldp	x2, x24, [sp, #0x50]
   13200:      	str	x21, [sp, #0x48]
   13204:      	b	0x13258 <generic_rawtp_path+0x8f68>
   13208:      	add	x2, x24, #0x10
   1320c:      	mov	w8, #0x4                // =4
   13210:      	add	x9, sp, #0x98
   13214:      	add	x0, sp, #0x98
   13218:      	mov	w1, #0x8                // =8
   1321c:      	blr	x8
   13220:      	ldr	x8, [sp, #0x58]
   13224:      	ldr	x9, [sp, #0x98]
   13228:      	cmp	x8, x9
   1322c:      	ldr	x25, [sp, #0x8]
   13230:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   13234:      	add	x2, x24, #0x18
   13238:      	mov	w8, #0x4                // =4
   1323c:      	mov	x0, x22
   13240:      	mov	w1, #0x8                // =8
   13244:      	blr	x8
   13248:      	ldr	x24, [sp, #0x98]
   1324c:      	ldr	x21, [sp, #0x48]
   13250:      	add	x2, x24, #0x20
   13254:      	stp	x2, x24, [sp, #0x50]
   13258:      	ldr	x8, [sp, #0x30]
   1325c:      	ldr	x25, [sp, #0x8]
   13260:      	add	x9, sp, #0x70
   13264:      	cmp	x21, x8
   13268:      	b.ne	0x13278 <generic_rawtp_path+0x8f88>
   1326c:      	ldr	x8, [sp, #0x38]
   13270:      	cmp	x2, x8
   13274:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   13278:      	mov	w8, #0x4                // =4
   1327c:      	add	x0, sp, #0x70
   13280:      	mov	w1, #0x8                // =8
   13284:      	blr	x8
   13288:      	ldr	x8, [sp, #0x70]
   1328c:      	cmp	x21, x8
   13290:      	b.eq	0x13384 <generic_rawtp_path+0x9094>
   13294:      	add	x23, x21, #0x18
   13298:      	mov	w8, #0x4                // =4
   1329c:      	add	x9, sp, #0x98
   132a0:      	add	x0, sp, #0x98
   132a4:      	mov	w1, #0x8                // =8
   132a8:      	mov	x2, x23
   132ac:      	blr	x8
   132b0:      	ldr	x8, [sp, #0x98]
   132b4:      	cmp	x8, x21
   132b8:      	b.eq	0x13384 <generic_rawtp_path+0x9094>
   132bc:      	mov	w8, #0x4                // =4
   132c0:      	add	x9, sp, #0x78
   132c4:      	add	x0, sp, #0x78
   132c8:      	mov	w1, #0x8                // =8
   132cc:      	mov	x2, x23
   132d0:      	blr	x8
   132d4:      	add	x2, x21, #0x20
   132d8:      	mov	w8, #0x4                // =4
   132dc:      	mov	w9, #0x10               // =16
   132e0:      	add	x10, sp, #0x80
   132e4:      	add	x0, sp, #0x80
   132e8:      	mov	w1, #0x10               // =16
   132ec:      	blr	x8
   132f0:      	ldr	w21, [sp, #0x84]
   132f4:      	ldr	x8, [sp, #0x40]
   132f8:      	ldr	x10, [sp, #0x60]
   132fc:      	sub	x12, x10, x8
   13300:      	ldr	w23, [sp, #0x68]
   13304:      	subs	w10, w21, w23
   13308:      	ldr	x9, [sp, #0x88]
   1330c:      	ldr	x25, [sp, #0x8]
   13310:      	csel	w10, wzr, w10, lo
   13314:      	cmp	w23, w21
   13318:      	csel	w11, w23, w21, lo
   1331c:      	cinc	w13, w11, hi
   13320:      	sub	w14, w23, w13
   13324:      	subs	x12, x12, x13
   13328:      	str	w14, [sp, #0x68]
   1332c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   13330:      	cmp	x12, #0xfff
   13334:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   13338:      	cmp	w23, w21
   1333c:      	b.ls	0x13348 <generic_rawtp_path+0x9058>
   13340:      	mov	w13, #0x2f              // =47
   13344:      	strb	w13, [x8, x12]
   13348:      	add	x19, x8, x12
   1334c:      	cmp	w23, w21
   13350:      	add	x2, x9, x10
   13354:      	and	w1, w11, #0xff
   13358:      	mov	w8, #0x4                // =4
   1335c:      	cinc	x0, x19, hi
   13360:      	blr	x8
   13364:      	ldr	x25, [sp, #0x8]
   13368:      	cmp	w23, w21
   1336c:      	str	x19, [sp, #0x60]
   13370:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   13374:      	ldr	x21, [sp, #0x78]
   13378:      	ldp	x2, x24, [sp, #0x50]
   1337c:      	str	x21, [sp, #0x48]
   13380:      	b	0x133d4 <generic_rawtp_path+0x90e4>
   13384:      	add	x2, x24, #0x10
   13388:      	mov	w8, #0x4                // =4
   1338c:      	add	x9, sp, #0x98
   13390:      	add	x0, sp, #0x98
   13394:      	mov	w1, #0x8                // =8
   13398:      	blr	x8
   1339c:      	ldr	x8, [sp, #0x58]
   133a0:      	ldr	x9, [sp, #0x98]
   133a4:      	cmp	x8, x9
   133a8:      	ldr	x25, [sp, #0x8]
   133ac:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   133b0:      	add	x2, x24, #0x18
   133b4:      	mov	w8, #0x4                // =4
   133b8:      	mov	x0, x22
   133bc:      	mov	w1, #0x8                // =8
   133c0:      	blr	x8
   133c4:      	ldr	x24, [sp, #0x98]
   133c8:      	ldr	x21, [sp, #0x48]
   133cc:      	add	x2, x24, #0x20
   133d0:      	stp	x2, x24, [sp, #0x50]
   133d4:      	ldr	x8, [sp, #0x30]
   133d8:      	ldr	x25, [sp, #0x8]
   133dc:      	add	x9, sp, #0x70
   133e0:      	cmp	x21, x8
   133e4:      	b.ne	0x133f4 <generic_rawtp_path+0x9104>
   133e8:      	ldr	x8, [sp, #0x38]
   133ec:      	cmp	x2, x8
   133f0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   133f4:      	mov	w8, #0x4                // =4
   133f8:      	add	x0, sp, #0x70
   133fc:      	mov	w1, #0x8                // =8
   13400:      	blr	x8
   13404:      	ldr	x8, [sp, #0x70]
   13408:      	cmp	x21, x8
   1340c:      	b.eq	0x13500 <generic_rawtp_path+0x9210>
   13410:      	add	x23, x21, #0x18
   13414:      	mov	w8, #0x4                // =4
   13418:      	add	x9, sp, #0x98
   1341c:      	add	x0, sp, #0x98
   13420:      	mov	w1, #0x8                // =8
   13424:      	mov	x2, x23
   13428:      	blr	x8
   1342c:      	ldr	x8, [sp, #0x98]
   13430:      	cmp	x8, x21
   13434:      	b.eq	0x13500 <generic_rawtp_path+0x9210>
   13438:      	mov	w8, #0x4                // =4
   1343c:      	add	x9, sp, #0x78
   13440:      	add	x0, sp, #0x78
   13444:      	mov	w1, #0x8                // =8
   13448:      	mov	x2, x23
   1344c:      	blr	x8
   13450:      	add	x2, x21, #0x20
   13454:      	mov	w8, #0x4                // =4
   13458:      	mov	w9, #0x10               // =16
   1345c:      	add	x10, sp, #0x80
   13460:      	add	x0, sp, #0x80
   13464:      	mov	w1, #0x10               // =16
   13468:      	blr	x8
   1346c:      	ldr	w21, [sp, #0x84]
   13470:      	ldr	x8, [sp, #0x40]
   13474:      	ldr	x10, [sp, #0x60]
   13478:      	sub	x12, x10, x8
   1347c:      	ldr	w23, [sp, #0x68]
   13480:      	subs	w10, w21, w23
   13484:      	ldr	x9, [sp, #0x88]
   13488:      	ldr	x25, [sp, #0x8]
   1348c:      	csel	w10, wzr, w10, lo
   13490:      	cmp	w23, w21
   13494:      	csel	w11, w23, w21, lo
   13498:      	cinc	w13, w11, hi
   1349c:      	sub	w14, w23, w13
   134a0:      	subs	x12, x12, x13
   134a4:      	str	w14, [sp, #0x68]
   134a8:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   134ac:      	cmp	x12, #0xfff
   134b0:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   134b4:      	cmp	w23, w21
   134b8:      	b.ls	0x134c4 <generic_rawtp_path+0x91d4>
   134bc:      	mov	w13, #0x2f              // =47
   134c0:      	strb	w13, [x8, x12]
   134c4:      	add	x19, x8, x12
   134c8:      	cmp	w23, w21
   134cc:      	add	x2, x9, x10
   134d0:      	and	w1, w11, #0xff
   134d4:      	mov	w8, #0x4                // =4
   134d8:      	cinc	x0, x19, hi
   134dc:      	blr	x8
   134e0:      	ldr	x25, [sp, #0x8]
   134e4:      	cmp	w23, w21
   134e8:      	str	x19, [sp, #0x60]
   134ec:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   134f0:      	ldr	x21, [sp, #0x78]
   134f4:      	ldp	x2, x24, [sp, #0x50]
   134f8:      	str	x21, [sp, #0x48]
   134fc:      	b	0x13550 <generic_rawtp_path+0x9260>
   13500:      	add	x2, x24, #0x10
   13504:      	mov	w8, #0x4                // =4
   13508:      	add	x9, sp, #0x98
   1350c:      	add	x0, sp, #0x98
   13510:      	mov	w1, #0x8                // =8
   13514:      	blr	x8
   13518:      	ldr	x8, [sp, #0x58]
   1351c:      	ldr	x9, [sp, #0x98]
   13520:      	cmp	x8, x9
   13524:      	ldr	x25, [sp, #0x8]
   13528:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   1352c:      	add	x2, x24, #0x18
   13530:      	mov	w8, #0x4                // =4
   13534:      	mov	x0, x22
   13538:      	mov	w1, #0x8                // =8
   1353c:      	blr	x8
   13540:      	ldr	x24, [sp, #0x98]
   13544:      	ldr	x21, [sp, #0x48]
   13548:      	add	x2, x24, #0x20
   1354c:      	stp	x2, x24, [sp, #0x50]
   13550:      	ldr	x8, [sp, #0x30]
   13554:      	ldr	x25, [sp, #0x8]
   13558:      	add	x9, sp, #0x70
   1355c:      	cmp	x21, x8
   13560:      	b.ne	0x13570 <generic_rawtp_path+0x9280>
   13564:      	ldr	x8, [sp, #0x38]
   13568:      	cmp	x2, x8
   1356c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   13570:      	mov	w8, #0x4                // =4
   13574:      	add	x0, sp, #0x70
   13578:      	mov	w1, #0x8                // =8
   1357c:      	blr	x8
   13580:      	ldr	x8, [sp, #0x70]
   13584:      	cmp	x21, x8
   13588:      	b.eq	0x1367c <generic_rawtp_path+0x938c>
   1358c:      	add	x23, x21, #0x18
   13590:      	mov	w8, #0x4                // =4
   13594:      	add	x9, sp, #0x98
   13598:      	add	x0, sp, #0x98
   1359c:      	mov	w1, #0x8                // =8
   135a0:      	mov	x2, x23
   135a4:      	blr	x8
   135a8:      	ldr	x8, [sp, #0x98]
   135ac:      	cmp	x8, x21
   135b0:      	b.eq	0x1367c <generic_rawtp_path+0x938c>
   135b4:      	mov	w8, #0x4                // =4
   135b8:      	add	x9, sp, #0x78
   135bc:      	add	x0, sp, #0x78
   135c0:      	mov	w1, #0x8                // =8
   135c4:      	mov	x2, x23
   135c8:      	blr	x8
   135cc:      	add	x2, x21, #0x20
   135d0:      	mov	w8, #0x4                // =4
   135d4:      	mov	w9, #0x10               // =16
   135d8:      	add	x10, sp, #0x80
   135dc:      	add	x0, sp, #0x80
   135e0:      	mov	w1, #0x10               // =16
   135e4:      	blr	x8
   135e8:      	ldr	w21, [sp, #0x84]
   135ec:      	ldr	x8, [sp, #0x40]
   135f0:      	ldr	x10, [sp, #0x60]
   135f4:      	sub	x12, x10, x8
   135f8:      	ldr	w23, [sp, #0x68]
   135fc:      	subs	w10, w21, w23
   13600:      	ldr	x9, [sp, #0x88]
   13604:      	ldr	x25, [sp, #0x8]
   13608:      	csel	w10, wzr, w10, lo
   1360c:      	cmp	w23, w21
   13610:      	csel	w11, w23, w21, lo
   13614:      	cinc	w13, w11, hi
   13618:      	sub	w14, w23, w13
   1361c:      	subs	x12, x12, x13
   13620:      	str	w14, [sp, #0x68]
   13624:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   13628:      	cmp	x12, #0xfff
   1362c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   13630:      	cmp	w23, w21
   13634:      	b.ls	0x13640 <generic_rawtp_path+0x9350>
   13638:      	mov	w13, #0x2f              // =47
   1363c:      	strb	w13, [x8, x12]
   13640:      	add	x19, x8, x12
   13644:      	cmp	w23, w21
   13648:      	add	x2, x9, x10
   1364c:      	and	w1, w11, #0xff
   13650:      	mov	w8, #0x4                // =4
   13654:      	cinc	x0, x19, hi
   13658:      	blr	x8
   1365c:      	ldr	x25, [sp, #0x8]
   13660:      	cmp	w23, w21
   13664:      	str	x19, [sp, #0x60]
   13668:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   1366c:      	ldr	x21, [sp, #0x78]
   13670:      	ldp	x2, x24, [sp, #0x50]
   13674:      	str	x21, [sp, #0x48]
   13678:      	b	0x136cc <generic_rawtp_path+0x93dc>
   1367c:      	add	x2, x24, #0x10
   13680:      	mov	w8, #0x4                // =4
   13684:      	add	x9, sp, #0x98
   13688:      	add	x0, sp, #0x98
   1368c:      	mov	w1, #0x8                // =8
   13690:      	blr	x8
   13694:      	ldr	x8, [sp, #0x58]
   13698:      	ldr	x9, [sp, #0x98]
   1369c:      	cmp	x8, x9
   136a0:      	ldr	x25, [sp, #0x8]
   136a4:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   136a8:      	add	x2, x24, #0x18
   136ac:      	mov	w8, #0x4                // =4
   136b0:      	mov	x0, x22
   136b4:      	mov	w1, #0x8                // =8
   136b8:      	blr	x8
   136bc:      	ldr	x24, [sp, #0x98]
   136c0:      	ldr	x21, [sp, #0x48]
   136c4:      	add	x2, x24, #0x20
   136c8:      	stp	x2, x24, [sp, #0x50]
   136cc:      	ldr	x8, [sp, #0x30]
   136d0:      	ldr	x25, [sp, #0x8]
   136d4:      	add	x9, sp, #0x70
   136d8:      	cmp	x21, x8
   136dc:      	b.ne	0x136ec <generic_rawtp_path+0x93fc>
   136e0:      	ldr	x8, [sp, #0x38]
   136e4:      	cmp	x2, x8
   136e8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   136ec:      	mov	w8, #0x4                // =4
   136f0:      	add	x0, sp, #0x70
   136f4:      	mov	w1, #0x8                // =8
   136f8:      	blr	x8
   136fc:      	ldr	x8, [sp, #0x70]
   13700:      	cmp	x21, x8
   13704:      	b.eq	0x137f8 <generic_rawtp_path+0x9508>
   13708:      	add	x23, x21, #0x18
   1370c:      	mov	w8, #0x4                // =4
   13710:      	add	x9, sp, #0x98
   13714:      	add	x0, sp, #0x98
   13718:      	mov	w1, #0x8                // =8
   1371c:      	mov	x2, x23
   13720:      	blr	x8
   13724:      	ldr	x8, [sp, #0x98]
   13728:      	cmp	x8, x21
   1372c:      	b.eq	0x137f8 <generic_rawtp_path+0x9508>
   13730:      	mov	w8, #0x4                // =4
   13734:      	add	x9, sp, #0x78
   13738:      	add	x0, sp, #0x78
   1373c:      	mov	w1, #0x8                // =8
   13740:      	mov	x2, x23
   13744:      	blr	x8
   13748:      	add	x2, x21, #0x20
   1374c:      	mov	w8, #0x4                // =4
   13750:      	mov	w9, #0x10               // =16
   13754:      	add	x10, sp, #0x80
   13758:      	add	x0, sp, #0x80
   1375c:      	mov	w1, #0x10               // =16
   13760:      	blr	x8
   13764:      	ldr	w21, [sp, #0x84]
   13768:      	ldr	x8, [sp, #0x40]
   1376c:      	ldr	x10, [sp, #0x60]
   13770:      	sub	x12, x10, x8
   13774:      	ldr	w23, [sp, #0x68]
   13778:      	subs	w10, w21, w23
   1377c:      	ldr	x9, [sp, #0x88]
   13780:      	ldr	x25, [sp, #0x8]
   13784:      	csel	w10, wzr, w10, lo
   13788:      	cmp	w23, w21
   1378c:      	csel	w11, w23, w21, lo
   13790:      	cinc	w13, w11, hi
   13794:      	sub	w14, w23, w13
   13798:      	subs	x12, x12, x13
   1379c:      	str	w14, [sp, #0x68]
   137a0:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   137a4:      	cmp	x12, #0xfff
   137a8:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   137ac:      	cmp	w23, w21
   137b0:      	b.ls	0x137bc <generic_rawtp_path+0x94cc>
   137b4:      	mov	w13, #0x2f              // =47
   137b8:      	strb	w13, [x8, x12]
   137bc:      	add	x19, x8, x12
   137c0:      	cmp	w23, w21
   137c4:      	add	x2, x9, x10
   137c8:      	and	w1, w11, #0xff
   137cc:      	mov	w8, #0x4                // =4
   137d0:      	cinc	x0, x19, hi
   137d4:      	blr	x8
   137d8:      	ldr	x25, [sp, #0x8]
   137dc:      	cmp	w23, w21
   137e0:      	str	x19, [sp, #0x60]
   137e4:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   137e8:      	ldr	x21, [sp, #0x78]
   137ec:      	ldp	x2, x24, [sp, #0x50]
   137f0:      	str	x21, [sp, #0x48]
   137f4:      	b	0x13848 <generic_rawtp_path+0x9558>
   137f8:      	add	x2, x24, #0x10
   137fc:      	mov	w8, #0x4                // =4
   13800:      	add	x9, sp, #0x98
   13804:      	add	x0, sp, #0x98
   13808:      	mov	w1, #0x8                // =8
   1380c:      	blr	x8
   13810:      	ldr	x8, [sp, #0x58]
   13814:      	ldr	x9, [sp, #0x98]
   13818:      	cmp	x8, x9
   1381c:      	ldr	x25, [sp, #0x8]
   13820:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   13824:      	add	x2, x24, #0x18
   13828:      	mov	w8, #0x4                // =4
   1382c:      	mov	x0, x22
   13830:      	mov	w1, #0x8                // =8
   13834:      	blr	x8
   13838:      	ldr	x24, [sp, #0x98]
   1383c:      	ldr	x21, [sp, #0x48]
   13840:      	add	x2, x24, #0x20
   13844:      	stp	x2, x24, [sp, #0x50]
   13848:      	ldr	x8, [sp, #0x30]
   1384c:      	ldr	x25, [sp, #0x8]
   13850:      	add	x9, sp, #0x70
   13854:      	cmp	x21, x8
   13858:      	b.ne	0x13868 <generic_rawtp_path+0x9578>
   1385c:      	ldr	x8, [sp, #0x38]
   13860:      	cmp	x2, x8
   13864:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   13868:      	mov	w8, #0x4                // =4
   1386c:      	add	x0, sp, #0x70
   13870:      	mov	w1, #0x8                // =8
   13874:      	blr	x8
   13878:      	ldr	x8, [sp, #0x70]
   1387c:      	cmp	x21, x8
   13880:      	b.eq	0x13974 <generic_rawtp_path+0x9684>
   13884:      	add	x23, x21, #0x18
   13888:      	mov	w8, #0x4                // =4
   1388c:      	add	x9, sp, #0x98
   13890:      	add	x0, sp, #0x98
   13894:      	mov	w1, #0x8                // =8
   13898:      	mov	x2, x23
   1389c:      	blr	x8
   138a0:      	ldr	x8, [sp, #0x98]
   138a4:      	cmp	x8, x21
   138a8:      	b.eq	0x13974 <generic_rawtp_path+0x9684>
   138ac:      	mov	w8, #0x4                // =4
   138b0:      	add	x9, sp, #0x78
   138b4:      	add	x0, sp, #0x78
   138b8:      	mov	w1, #0x8                // =8
   138bc:      	mov	x2, x23
   138c0:      	blr	x8
   138c4:      	add	x2, x21, #0x20
   138c8:      	mov	w8, #0x4                // =4
   138cc:      	mov	w9, #0x10               // =16
   138d0:      	add	x10, sp, #0x80
   138d4:      	add	x0, sp, #0x80
   138d8:      	mov	w1, #0x10               // =16
   138dc:      	blr	x8
   138e0:      	ldr	w21, [sp, #0x84]
   138e4:      	ldr	x8, [sp, #0x40]
   138e8:      	ldr	x10, [sp, #0x60]
   138ec:      	sub	x12, x10, x8
   138f0:      	ldr	w23, [sp, #0x68]
   138f4:      	subs	w10, w21, w23
   138f8:      	ldr	x9, [sp, #0x88]
   138fc:      	ldr	x25, [sp, #0x8]
   13900:      	csel	w10, wzr, w10, lo
   13904:      	cmp	w23, w21
   13908:      	csel	w11, w23, w21, lo
   1390c:      	cinc	w13, w11, hi
   13910:      	sub	w14, w23, w13
   13914:      	subs	x12, x12, x13
   13918:      	str	w14, [sp, #0x68]
   1391c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   13920:      	cmp	x12, #0xfff
   13924:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   13928:      	cmp	w23, w21
   1392c:      	b.ls	0x13938 <generic_rawtp_path+0x9648>
   13930:      	mov	w13, #0x2f              // =47
   13934:      	strb	w13, [x8, x12]
   13938:      	add	x19, x8, x12
   1393c:      	cmp	w23, w21
   13940:      	add	x2, x9, x10
   13944:      	and	w1, w11, #0xff
   13948:      	mov	w8, #0x4                // =4
   1394c:      	cinc	x0, x19, hi
   13950:      	blr	x8
   13954:      	ldr	x25, [sp, #0x8]
   13958:      	cmp	w23, w21
   1395c:      	str	x19, [sp, #0x60]
   13960:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   13964:      	ldr	x21, [sp, #0x78]
   13968:      	ldp	x2, x24, [sp, #0x50]
   1396c:      	str	x21, [sp, #0x48]
   13970:      	b	0x139c4 <generic_rawtp_path+0x96d4>
   13974:      	add	x2, x24, #0x10
   13978:      	mov	w8, #0x4                // =4
   1397c:      	add	x9, sp, #0x98
   13980:      	add	x0, sp, #0x98
   13984:      	mov	w1, #0x8                // =8
   13988:      	blr	x8
   1398c:      	ldr	x8, [sp, #0x58]
   13990:      	ldr	x9, [sp, #0x98]
   13994:      	cmp	x8, x9
   13998:      	ldr	x25, [sp, #0x8]
   1399c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   139a0:      	add	x2, x24, #0x18
   139a4:      	mov	w8, #0x4                // =4
   139a8:      	mov	x0, x22
   139ac:      	mov	w1, #0x8                // =8
   139b0:      	blr	x8
   139b4:      	ldr	x24, [sp, #0x98]
   139b8:      	ldr	x21, [sp, #0x48]
   139bc:      	add	x2, x24, #0x20
   139c0:      	stp	x2, x24, [sp, #0x50]
   139c4:      	ldr	x8, [sp, #0x30]
   139c8:      	ldr	x25, [sp, #0x8]
   139cc:      	add	x9, sp, #0x70
   139d0:      	cmp	x21, x8
   139d4:      	b.ne	0x139e4 <generic_rawtp_path+0x96f4>
   139d8:      	ldr	x8, [sp, #0x38]
   139dc:      	cmp	x2, x8
   139e0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   139e4:      	mov	w8, #0x4                // =4
   139e8:      	add	x0, sp, #0x70
   139ec:      	mov	w1, #0x8                // =8
   139f0:      	blr	x8
   139f4:      	ldr	x8, [sp, #0x70]
   139f8:      	cmp	x21, x8
   139fc:      	b.eq	0x13af0 <generic_rawtp_path+0x9800>
   13a00:      	add	x23, x21, #0x18
   13a04:      	mov	w8, #0x4                // =4
   13a08:      	add	x9, sp, #0x98
   13a0c:      	add	x0, sp, #0x98
   13a10:      	mov	w1, #0x8                // =8
   13a14:      	mov	x2, x23
   13a18:      	blr	x8
   13a1c:      	ldr	x8, [sp, #0x98]
   13a20:      	cmp	x8, x21
   13a24:      	b.eq	0x13af0 <generic_rawtp_path+0x9800>
   13a28:      	mov	w8, #0x4                // =4
   13a2c:      	add	x9, sp, #0x78
   13a30:      	add	x0, sp, #0x78
   13a34:      	mov	w1, #0x8                // =8
   13a38:      	mov	x2, x23
   13a3c:      	blr	x8
   13a40:      	add	x2, x21, #0x20
   13a44:      	mov	w8, #0x4                // =4
   13a48:      	mov	w9, #0x10               // =16
   13a4c:      	add	x10, sp, #0x80
   13a50:      	add	x0, sp, #0x80
   13a54:      	mov	w1, #0x10               // =16
   13a58:      	blr	x8
   13a5c:      	ldr	w21, [sp, #0x84]
   13a60:      	ldr	x8, [sp, #0x40]
   13a64:      	ldr	x10, [sp, #0x60]
   13a68:      	sub	x12, x10, x8
   13a6c:      	ldr	w23, [sp, #0x68]
   13a70:      	subs	w10, w21, w23
   13a74:      	ldr	x9, [sp, #0x88]
   13a78:      	ldr	x25, [sp, #0x8]
   13a7c:      	csel	w10, wzr, w10, lo
   13a80:      	cmp	w23, w21
   13a84:      	csel	w11, w23, w21, lo
   13a88:      	cinc	w13, w11, hi
   13a8c:      	sub	w14, w23, w13
   13a90:      	subs	x12, x12, x13
   13a94:      	str	w14, [sp, #0x68]
   13a98:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   13a9c:      	cmp	x12, #0xfff
   13aa0:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   13aa4:      	cmp	w23, w21
   13aa8:      	b.ls	0x13ab4 <generic_rawtp_path+0x97c4>
   13aac:      	mov	w13, #0x2f              // =47
   13ab0:      	strb	w13, [x8, x12]
   13ab4:      	add	x19, x8, x12
   13ab8:      	cmp	w23, w21
   13abc:      	add	x2, x9, x10
   13ac0:      	and	w1, w11, #0xff
   13ac4:      	mov	w8, #0x4                // =4
   13ac8:      	cinc	x0, x19, hi
   13acc:      	blr	x8
   13ad0:      	ldr	x25, [sp, #0x8]
   13ad4:      	cmp	w23, w21
   13ad8:      	str	x19, [sp, #0x60]
   13adc:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   13ae0:      	ldr	x21, [sp, #0x78]
   13ae4:      	ldp	x2, x24, [sp, #0x50]
   13ae8:      	str	x21, [sp, #0x48]
   13aec:      	b	0x13b40 <generic_rawtp_path+0x9850>
   13af0:      	add	x2, x24, #0x10
   13af4:      	mov	w8, #0x4                // =4
   13af8:      	add	x9, sp, #0x98
   13afc:      	add	x0, sp, #0x98
   13b00:      	mov	w1, #0x8                // =8
   13b04:      	blr	x8
   13b08:      	ldr	x8, [sp, #0x58]
   13b0c:      	ldr	x9, [sp, #0x98]
   13b10:      	cmp	x8, x9
   13b14:      	ldr	x25, [sp, #0x8]
   13b18:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   13b1c:      	add	x2, x24, #0x18
   13b20:      	mov	w8, #0x4                // =4
   13b24:      	mov	x0, x22
   13b28:      	mov	w1, #0x8                // =8
   13b2c:      	blr	x8
   13b30:      	ldr	x24, [sp, #0x98]
   13b34:      	ldr	x21, [sp, #0x48]
   13b38:      	add	x2, x24, #0x20
   13b3c:      	stp	x2, x24, [sp, #0x50]
   13b40:      	ldr	x8, [sp, #0x30]
   13b44:      	ldr	x25, [sp, #0x8]
   13b48:      	add	x9, sp, #0x70
   13b4c:      	cmp	x21, x8
   13b50:      	b.ne	0x13b60 <generic_rawtp_path+0x9870>
   13b54:      	ldr	x8, [sp, #0x38]
   13b58:      	cmp	x2, x8
   13b5c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   13b60:      	mov	w8, #0x4                // =4
   13b64:      	add	x0, sp, #0x70
   13b68:      	mov	w1, #0x8                // =8
   13b6c:      	blr	x8
   13b70:      	ldr	x8, [sp, #0x70]
   13b74:      	cmp	x21, x8
   13b78:      	b.eq	0x13c6c <generic_rawtp_path+0x997c>
   13b7c:      	add	x23, x21, #0x18
   13b80:      	mov	w8, #0x4                // =4
   13b84:      	add	x9, sp, #0x98
   13b88:      	add	x0, sp, #0x98
   13b8c:      	mov	w1, #0x8                // =8
   13b90:      	mov	x2, x23
   13b94:      	blr	x8
   13b98:      	ldr	x8, [sp, #0x98]
   13b9c:      	cmp	x8, x21
   13ba0:      	b.eq	0x13c6c <generic_rawtp_path+0x997c>
   13ba4:      	mov	w8, #0x4                // =4
   13ba8:      	add	x9, sp, #0x78
   13bac:      	add	x0, sp, #0x78
   13bb0:      	mov	w1, #0x8                // =8
   13bb4:      	mov	x2, x23
   13bb8:      	blr	x8
   13bbc:      	add	x2, x21, #0x20
   13bc0:      	mov	w8, #0x4                // =4
   13bc4:      	mov	w9, #0x10               // =16
   13bc8:      	add	x10, sp, #0x80
   13bcc:      	add	x0, sp, #0x80
   13bd0:      	mov	w1, #0x10               // =16
   13bd4:      	blr	x8
   13bd8:      	ldr	w21, [sp, #0x84]
   13bdc:      	ldr	x8, [sp, #0x40]
   13be0:      	ldr	x10, [sp, #0x60]
   13be4:      	sub	x12, x10, x8
   13be8:      	ldr	w23, [sp, #0x68]
   13bec:      	subs	w10, w21, w23
   13bf0:      	ldr	x9, [sp, #0x88]
   13bf4:      	ldr	x25, [sp, #0x8]
   13bf8:      	csel	w10, wzr, w10, lo
   13bfc:      	cmp	w23, w21
   13c00:      	csel	w11, w23, w21, lo
   13c04:      	cinc	w13, w11, hi
   13c08:      	sub	w14, w23, w13
   13c0c:      	subs	x12, x12, x13
   13c10:      	str	w14, [sp, #0x68]
   13c14:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   13c18:      	cmp	x12, #0xfff
   13c1c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   13c20:      	cmp	w23, w21
   13c24:      	b.ls	0x13c30 <generic_rawtp_path+0x9940>
   13c28:      	mov	w13, #0x2f              // =47
   13c2c:      	strb	w13, [x8, x12]
   13c30:      	add	x19, x8, x12
   13c34:      	cmp	w23, w21
   13c38:      	add	x2, x9, x10
   13c3c:      	and	w1, w11, #0xff
   13c40:      	mov	w8, #0x4                // =4
   13c44:      	cinc	x0, x19, hi
   13c48:      	blr	x8
   13c4c:      	ldr	x25, [sp, #0x8]
   13c50:      	cmp	w23, w21
   13c54:      	str	x19, [sp, #0x60]
   13c58:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   13c5c:      	ldr	x21, [sp, #0x78]
   13c60:      	ldp	x2, x24, [sp, #0x50]
   13c64:      	str	x21, [sp, #0x48]
   13c68:      	b	0x13cbc <generic_rawtp_path+0x99cc>
   13c6c:      	add	x2, x24, #0x10
   13c70:      	mov	w8, #0x4                // =4
   13c74:      	add	x9, sp, #0x98
   13c78:      	add	x0, sp, #0x98
   13c7c:      	mov	w1, #0x8                // =8
   13c80:      	blr	x8
   13c84:      	ldr	x8, [sp, #0x58]
   13c88:      	ldr	x9, [sp, #0x98]
   13c8c:      	cmp	x8, x9
   13c90:      	ldr	x25, [sp, #0x8]
   13c94:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   13c98:      	add	x2, x24, #0x18
   13c9c:      	mov	w8, #0x4                // =4
   13ca0:      	mov	x0, x22
   13ca4:      	mov	w1, #0x8                // =8
   13ca8:      	blr	x8
   13cac:      	ldr	x24, [sp, #0x98]
   13cb0:      	ldr	x21, [sp, #0x48]
   13cb4:      	add	x2, x24, #0x20
   13cb8:      	stp	x2, x24, [sp, #0x50]
   13cbc:      	ldr	x8, [sp, #0x30]
   13cc0:      	ldr	x25, [sp, #0x8]
   13cc4:      	add	x9, sp, #0x70
   13cc8:      	cmp	x21, x8
   13ccc:      	b.ne	0x13cdc <generic_rawtp_path+0x99ec>
   13cd0:      	ldr	x8, [sp, #0x38]
   13cd4:      	cmp	x2, x8
   13cd8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   13cdc:      	mov	w8, #0x4                // =4
   13ce0:      	add	x0, sp, #0x70
   13ce4:      	mov	w1, #0x8                // =8
   13ce8:      	blr	x8
   13cec:      	ldr	x8, [sp, #0x70]
   13cf0:      	cmp	x21, x8
   13cf4:      	b.eq	0x13de8 <generic_rawtp_path+0x9af8>
   13cf8:      	add	x23, x21, #0x18
   13cfc:      	mov	w8, #0x4                // =4
   13d00:      	add	x9, sp, #0x98
   13d04:      	add	x0, sp, #0x98
   13d08:      	mov	w1, #0x8                // =8
   13d0c:      	mov	x2, x23
   13d10:      	blr	x8
   13d14:      	ldr	x8, [sp, #0x98]
   13d18:      	cmp	x8, x21
   13d1c:      	b.eq	0x13de8 <generic_rawtp_path+0x9af8>
   13d20:      	mov	w8, #0x4                // =4
   13d24:      	add	x9, sp, #0x78
   13d28:      	add	x0, sp, #0x78
   13d2c:      	mov	w1, #0x8                // =8
   13d30:      	mov	x2, x23
   13d34:      	blr	x8
   13d38:      	add	x2, x21, #0x20
   13d3c:      	mov	w8, #0x4                // =4
   13d40:      	mov	w9, #0x10               // =16
   13d44:      	add	x10, sp, #0x80
   13d48:      	add	x0, sp, #0x80
   13d4c:      	mov	w1, #0x10               // =16
   13d50:      	blr	x8
   13d54:      	ldr	w21, [sp, #0x84]
   13d58:      	ldr	x8, [sp, #0x40]
   13d5c:      	ldr	x10, [sp, #0x60]
   13d60:      	sub	x12, x10, x8
   13d64:      	ldr	w23, [sp, #0x68]
   13d68:      	subs	w10, w21, w23
   13d6c:      	ldr	x9, [sp, #0x88]
   13d70:      	ldr	x25, [sp, #0x8]
   13d74:      	csel	w10, wzr, w10, lo
   13d78:      	cmp	w23, w21
   13d7c:      	csel	w11, w23, w21, lo
   13d80:      	cinc	w13, w11, hi
   13d84:      	sub	w14, w23, w13
   13d88:      	subs	x12, x12, x13
   13d8c:      	str	w14, [sp, #0x68]
   13d90:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   13d94:      	cmp	x12, #0xfff
   13d98:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   13d9c:      	cmp	w23, w21
   13da0:      	b.ls	0x13dac <generic_rawtp_path+0x9abc>
   13da4:      	mov	w13, #0x2f              // =47
   13da8:      	strb	w13, [x8, x12]
   13dac:      	add	x19, x8, x12
   13db0:      	cmp	w23, w21
   13db4:      	add	x2, x9, x10
   13db8:      	and	w1, w11, #0xff
   13dbc:      	mov	w8, #0x4                // =4
   13dc0:      	cinc	x0, x19, hi
   13dc4:      	blr	x8
   13dc8:      	ldr	x25, [sp, #0x8]
   13dcc:      	cmp	w23, w21
   13dd0:      	str	x19, [sp, #0x60]
   13dd4:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   13dd8:      	ldr	x21, [sp, #0x78]
   13ddc:      	ldp	x2, x24, [sp, #0x50]
   13de0:      	str	x21, [sp, #0x48]
   13de4:      	b	0x13e38 <generic_rawtp_path+0x9b48>
   13de8:      	add	x2, x24, #0x10
   13dec:      	mov	w8, #0x4                // =4
   13df0:      	add	x9, sp, #0x98
   13df4:      	add	x0, sp, #0x98
   13df8:      	mov	w1, #0x8                // =8
   13dfc:      	blr	x8
   13e00:      	ldr	x8, [sp, #0x58]
   13e04:      	ldr	x9, [sp, #0x98]
   13e08:      	cmp	x8, x9
   13e0c:      	ldr	x25, [sp, #0x8]
   13e10:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   13e14:      	add	x2, x24, #0x18
   13e18:      	mov	w8, #0x4                // =4
   13e1c:      	mov	x0, x22
   13e20:      	mov	w1, #0x8                // =8
   13e24:      	blr	x8
   13e28:      	ldr	x24, [sp, #0x98]
   13e2c:      	ldr	x21, [sp, #0x48]
   13e30:      	add	x2, x24, #0x20
   13e34:      	stp	x2, x24, [sp, #0x50]
   13e38:      	ldr	x8, [sp, #0x30]
   13e3c:      	ldr	x25, [sp, #0x8]
   13e40:      	add	x9, sp, #0x70
   13e44:      	cmp	x21, x8
   13e48:      	b.ne	0x13e58 <generic_rawtp_path+0x9b68>
   13e4c:      	ldr	x8, [sp, #0x38]
   13e50:      	cmp	x2, x8
   13e54:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   13e58:      	mov	w8, #0x4                // =4
   13e5c:      	add	x0, sp, #0x70
   13e60:      	mov	w1, #0x8                // =8
   13e64:      	blr	x8
   13e68:      	ldr	x8, [sp, #0x70]
   13e6c:      	cmp	x21, x8
   13e70:      	b.eq	0x13f64 <generic_rawtp_path+0x9c74>
   13e74:      	add	x23, x21, #0x18
   13e78:      	mov	w8, #0x4                // =4
   13e7c:      	add	x9, sp, #0x98
   13e80:      	add	x0, sp, #0x98
   13e84:      	mov	w1, #0x8                // =8
   13e88:      	mov	x2, x23
   13e8c:      	blr	x8
   13e90:      	ldr	x8, [sp, #0x98]
   13e94:      	cmp	x8, x21
   13e98:      	b.eq	0x13f64 <generic_rawtp_path+0x9c74>
   13e9c:      	mov	w8, #0x4                // =4
   13ea0:      	add	x9, sp, #0x78
   13ea4:      	add	x0, sp, #0x78
   13ea8:      	mov	w1, #0x8                // =8
   13eac:      	mov	x2, x23
   13eb0:      	blr	x8
   13eb4:      	add	x2, x21, #0x20
   13eb8:      	mov	w8, #0x4                // =4
   13ebc:      	mov	w9, #0x10               // =16
   13ec0:      	add	x10, sp, #0x80
   13ec4:      	add	x0, sp, #0x80
   13ec8:      	mov	w1, #0x10               // =16
   13ecc:      	blr	x8
   13ed0:      	ldr	w21, [sp, #0x84]
   13ed4:      	ldr	x8, [sp, #0x40]
   13ed8:      	ldr	x10, [sp, #0x60]
   13edc:      	sub	x12, x10, x8
   13ee0:      	ldr	w23, [sp, #0x68]
   13ee4:      	subs	w10, w21, w23
   13ee8:      	ldr	x9, [sp, #0x88]
   13eec:      	ldr	x25, [sp, #0x8]
   13ef0:      	csel	w10, wzr, w10, lo
   13ef4:      	cmp	w23, w21
   13ef8:      	csel	w11, w23, w21, lo
   13efc:      	cinc	w13, w11, hi
   13f00:      	sub	w14, w23, w13
   13f04:      	subs	x12, x12, x13
   13f08:      	str	w14, [sp, #0x68]
   13f0c:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   13f10:      	cmp	x12, #0xfff
   13f14:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   13f18:      	cmp	w23, w21
   13f1c:      	b.ls	0x13f28 <generic_rawtp_path+0x9c38>
   13f20:      	mov	w13, #0x2f              // =47
   13f24:      	strb	w13, [x8, x12]
   13f28:      	add	x19, x8, x12
   13f2c:      	cmp	w23, w21
   13f30:      	add	x2, x9, x10
   13f34:      	and	w1, w11, #0xff
   13f38:      	mov	w8, #0x4                // =4
   13f3c:      	cinc	x0, x19, hi
   13f40:      	blr	x8
   13f44:      	ldr	x25, [sp, #0x8]
   13f48:      	cmp	w23, w21
   13f4c:      	str	x19, [sp, #0x60]
   13f50:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   13f54:      	ldr	x21, [sp, #0x78]
   13f58:      	ldp	x2, x24, [sp, #0x50]
   13f5c:      	str	x21, [sp, #0x48]
   13f60:      	b	0x13fb4 <generic_rawtp_path+0x9cc4>
   13f64:      	add	x2, x24, #0x10
   13f68:      	mov	w8, #0x4                // =4
   13f6c:      	add	x9, sp, #0x98
   13f70:      	add	x0, sp, #0x98
   13f74:      	mov	w1, #0x8                // =8
   13f78:      	blr	x8
   13f7c:      	ldr	x8, [sp, #0x58]
   13f80:      	ldr	x9, [sp, #0x98]
   13f84:      	cmp	x8, x9
   13f88:      	ldr	x25, [sp, #0x8]
   13f8c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   13f90:      	add	x2, x24, #0x18
   13f94:      	mov	w8, #0x4                // =4
   13f98:      	mov	x0, x22
   13f9c:      	mov	w1, #0x8                // =8
   13fa0:      	blr	x8
   13fa4:      	ldr	x24, [sp, #0x98]
   13fa8:      	ldr	x21, [sp, #0x48]
   13fac:      	add	x2, x24, #0x20
   13fb0:      	stp	x2, x24, [sp, #0x50]
   13fb4:      	ldr	x8, [sp, #0x30]
   13fb8:      	ldr	x25, [sp, #0x8]
   13fbc:      	add	x9, sp, #0x70
   13fc0:      	cmp	x21, x8
   13fc4:      	b.ne	0x13fd4 <generic_rawtp_path+0x9ce4>
   13fc8:      	ldr	x8, [sp, #0x38]
   13fcc:      	cmp	x2, x8
   13fd0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   13fd4:      	mov	w8, #0x4                // =4
   13fd8:      	add	x0, sp, #0x70
   13fdc:      	mov	w1, #0x8                // =8
   13fe0:      	blr	x8
   13fe4:      	ldr	x8, [sp, #0x70]
   13fe8:      	cmp	x21, x8
   13fec:      	b.eq	0x140e0 <generic_rawtp_path+0x9df0>
   13ff0:      	add	x23, x21, #0x18
   13ff4:      	mov	w8, #0x4                // =4
   13ff8:      	add	x9, sp, #0x98
   13ffc:      	add	x0, sp, #0x98
   14000:      	mov	w1, #0x8                // =8
   14004:      	mov	x2, x23
   14008:      	blr	x8
   1400c:      	ldr	x8, [sp, #0x98]
   14010:      	cmp	x8, x21
   14014:      	b.eq	0x140e0 <generic_rawtp_path+0x9df0>
   14018:      	mov	w8, #0x4                // =4
   1401c:      	add	x9, sp, #0x78
   14020:      	add	x0, sp, #0x78
   14024:      	mov	w1, #0x8                // =8
   14028:      	mov	x2, x23
   1402c:      	blr	x8
   14030:      	add	x2, x21, #0x20
   14034:      	mov	w8, #0x4                // =4
   14038:      	mov	w9, #0x10               // =16
   1403c:      	add	x10, sp, #0x80
   14040:      	add	x0, sp, #0x80
   14044:      	mov	w1, #0x10               // =16
   14048:      	blr	x8
   1404c:      	ldr	w21, [sp, #0x84]
   14050:      	ldr	x8, [sp, #0x40]
   14054:      	ldr	x10, [sp, #0x60]
   14058:      	sub	x12, x10, x8
   1405c:      	ldr	w23, [sp, #0x68]
   14060:      	subs	w10, w21, w23
   14064:      	ldr	x9, [sp, #0x88]
   14068:      	ldr	x25, [sp, #0x8]
   1406c:      	csel	w10, wzr, w10, lo
   14070:      	cmp	w23, w21
   14074:      	csel	w11, w23, w21, lo
   14078:      	cinc	w13, w11, hi
   1407c:      	sub	w14, w23, w13
   14080:      	subs	x12, x12, x13
   14084:      	str	w14, [sp, #0x68]
   14088:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   1408c:      	cmp	x12, #0xfff
   14090:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   14094:      	cmp	w23, w21
   14098:      	b.ls	0x140a4 <generic_rawtp_path+0x9db4>
   1409c:      	mov	w13, #0x2f              // =47
   140a0:      	strb	w13, [x8, x12]
   140a4:      	add	x19, x8, x12
   140a8:      	cmp	w23, w21
   140ac:      	add	x2, x9, x10
   140b0:      	and	w1, w11, #0xff
   140b4:      	mov	w8, #0x4                // =4
   140b8:      	cinc	x0, x19, hi
   140bc:      	blr	x8
   140c0:      	ldr	x25, [sp, #0x8]
   140c4:      	cmp	w23, w21
   140c8:      	str	x19, [sp, #0x60]
   140cc:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   140d0:      	ldr	x21, [sp, #0x78]
   140d4:      	ldp	x2, x24, [sp, #0x50]
   140d8:      	str	x21, [sp, #0x48]
   140dc:      	b	0x14130 <generic_rawtp_path+0x9e40>
   140e0:      	add	x2, x24, #0x10
   140e4:      	mov	w8, #0x4                // =4
   140e8:      	add	x9, sp, #0x98
   140ec:      	add	x0, sp, #0x98
   140f0:      	mov	w1, #0x8                // =8
   140f4:      	blr	x8
   140f8:      	ldr	x8, [sp, #0x58]
   140fc:      	ldr	x9, [sp, #0x98]
   14100:      	cmp	x8, x9
   14104:      	ldr	x25, [sp, #0x8]
   14108:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   1410c:      	add	x2, x24, #0x18
   14110:      	mov	w8, #0x4                // =4
   14114:      	mov	x0, x22
   14118:      	mov	w1, #0x8                // =8
   1411c:      	blr	x8
   14120:      	ldr	x24, [sp, #0x98]
   14124:      	ldr	x21, [sp, #0x48]
   14128:      	add	x2, x24, #0x20
   1412c:      	stp	x2, x24, [sp, #0x50]
   14130:      	ldr	x8, [sp, #0x30]
   14134:      	ldr	x25, [sp, #0x8]
   14138:      	add	x9, sp, #0x70
   1413c:      	cmp	x21, x8
   14140:      	b.ne	0x14150 <generic_rawtp_path+0x9e60>
   14144:      	ldr	x8, [sp, #0x38]
   14148:      	cmp	x2, x8
   1414c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   14150:      	mov	w8, #0x4                // =4
   14154:      	add	x0, sp, #0x70
   14158:      	mov	w1, #0x8                // =8
   1415c:      	blr	x8
   14160:      	ldr	x8, [sp, #0x70]
   14164:      	cmp	x21, x8
   14168:      	b.eq	0x1425c <generic_rawtp_path+0x9f6c>
   1416c:      	add	x23, x21, #0x18
   14170:      	mov	w8, #0x4                // =4
   14174:      	add	x9, sp, #0x98
   14178:      	add	x0, sp, #0x98
   1417c:      	mov	w1, #0x8                // =8
   14180:      	mov	x2, x23
   14184:      	blr	x8
   14188:      	ldr	x8, [sp, #0x98]
   1418c:      	cmp	x8, x21
   14190:      	b.eq	0x1425c <generic_rawtp_path+0x9f6c>
   14194:      	mov	w8, #0x4                // =4
   14198:      	add	x9, sp, #0x78
   1419c:      	add	x0, sp, #0x78
   141a0:      	mov	w1, #0x8                // =8
   141a4:      	mov	x2, x23
   141a8:      	blr	x8
   141ac:      	add	x2, x21, #0x20
   141b0:      	mov	w8, #0x4                // =4
   141b4:      	mov	w9, #0x10               // =16
   141b8:      	add	x10, sp, #0x80
   141bc:      	add	x0, sp, #0x80
   141c0:      	mov	w1, #0x10               // =16
   141c4:      	blr	x8
   141c8:      	ldr	w21, [sp, #0x84]
   141cc:      	ldr	x8, [sp, #0x40]
   141d0:      	ldr	x10, [sp, #0x60]
   141d4:      	sub	x12, x10, x8
   141d8:      	ldr	w23, [sp, #0x68]
   141dc:      	subs	w10, w21, w23
   141e0:      	ldr	x9, [sp, #0x88]
   141e4:      	ldr	x25, [sp, #0x8]
   141e8:      	csel	w10, wzr, w10, lo
   141ec:      	cmp	w23, w21
   141f0:      	csel	w11, w23, w21, lo
   141f4:      	cinc	w13, w11, hi
   141f8:      	sub	w14, w23, w13
   141fc:      	subs	x12, x12, x13
   14200:      	str	w14, [sp, #0x68]
   14204:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   14208:      	cmp	x12, #0xfff
   1420c:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   14210:      	cmp	w23, w21
   14214:      	b.ls	0x14220 <generic_rawtp_path+0x9f30>
   14218:      	mov	w13, #0x2f              // =47
   1421c:      	strb	w13, [x8, x12]
   14220:      	add	x19, x8, x12
   14224:      	cmp	w23, w21
   14228:      	add	x2, x9, x10
   1422c:      	and	w1, w11, #0xff
   14230:      	mov	w8, #0x4                // =4
   14234:      	cinc	x0, x19, hi
   14238:      	blr	x8
   1423c:      	ldr	x25, [sp, #0x8]
   14240:      	cmp	w23, w21
   14244:      	str	x19, [sp, #0x60]
   14248:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   1424c:      	ldr	x21, [sp, #0x78]
   14250:      	ldp	x2, x24, [sp, #0x50]
   14254:      	str	x21, [sp, #0x48]
   14258:      	b	0x142ac <generic_rawtp_path+0x9fbc>
   1425c:      	add	x2, x24, #0x10
   14260:      	mov	w8, #0x4                // =4
   14264:      	add	x9, sp, #0x98
   14268:      	add	x0, sp, #0x98
   1426c:      	mov	w1, #0x8                // =8
   14270:      	blr	x8
   14274:      	ldr	x8, [sp, #0x58]
   14278:      	ldr	x9, [sp, #0x98]
   1427c:      	cmp	x8, x9
   14280:      	ldr	x25, [sp, #0x8]
   14284:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   14288:      	add	x2, x24, #0x18
   1428c:      	mov	w8, #0x4                // =4
   14290:      	mov	x0, x22
   14294:      	mov	w1, #0x8                // =8
   14298:      	blr	x8
   1429c:      	ldr	x24, [sp, #0x98]
   142a0:      	ldr	x21, [sp, #0x48]
   142a4:      	add	x2, x24, #0x20
   142a8:      	stp	x2, x24, [sp, #0x50]
   142ac:      	ldr	x8, [sp, #0x30]
   142b0:      	ldr	x25, [sp, #0x8]
   142b4:      	add	x9, sp, #0x70
   142b8:      	cmp	x21, x8
   142bc:      	b.ne	0x142cc <generic_rawtp_path+0x9fdc>
   142c0:      	ldr	x8, [sp, #0x38]
   142c4:      	cmp	x2, x8
   142c8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   142cc:      	mov	w8, #0x4                // =4
   142d0:      	add	x0, sp, #0x70
   142d4:      	mov	w1, #0x8                // =8
   142d8:      	blr	x8
   142dc:      	ldr	x8, [sp, #0x70]
   142e0:      	cmp	x21, x8
   142e4:      	b.eq	0x143d8 <generic_rawtp_path+0xa0e8>
   142e8:      	add	x23, x21, #0x18
   142ec:      	mov	w8, #0x4                // =4
   142f0:      	add	x9, sp, #0x98
   142f4:      	add	x0, sp, #0x98
   142f8:      	mov	w1, #0x8                // =8
   142fc:      	mov	x2, x23
   14300:      	blr	x8
   14304:      	ldr	x8, [sp, #0x98]
   14308:      	cmp	x8, x21
   1430c:      	b.eq	0x143d8 <generic_rawtp_path+0xa0e8>
   14310:      	mov	w8, #0x4                // =4
   14314:      	add	x9, sp, #0x78
   14318:      	add	x0, sp, #0x78
   1431c:      	mov	w1, #0x8                // =8
   14320:      	mov	x2, x23
   14324:      	blr	x8
   14328:      	add	x2, x21, #0x20
   1432c:      	mov	w8, #0x4                // =4
   14330:      	mov	w9, #0x10               // =16
   14334:      	add	x10, sp, #0x80
   14338:      	add	x0, sp, #0x80
   1433c:      	mov	w1, #0x10               // =16
   14340:      	blr	x8
   14344:      	ldr	w21, [sp, #0x84]
   14348:      	ldr	x8, [sp, #0x40]
   1434c:      	ldr	x10, [sp, #0x60]
   14350:      	sub	x12, x10, x8
   14354:      	ldr	w23, [sp, #0x68]
   14358:      	subs	w10, w21, w23
   1435c:      	ldr	x9, [sp, #0x88]
   14360:      	ldr	x25, [sp, #0x8]
   14364:      	csel	w10, wzr, w10, lo
   14368:      	cmp	w23, w21
   1436c:      	csel	w11, w23, w21, lo
   14370:      	cinc	w13, w11, hi
   14374:      	sub	w14, w23, w13
   14378:      	subs	x12, x12, x13
   1437c:      	str	w14, [sp, #0x68]
   14380:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   14384:      	cmp	x12, #0xfff
   14388:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   1438c:      	cmp	w23, w21
   14390:      	b.ls	0x1439c <generic_rawtp_path+0xa0ac>
   14394:      	mov	w13, #0x2f              // =47
   14398:      	strb	w13, [x8, x12]
   1439c:      	add	x19, x8, x12
   143a0:      	cmp	w23, w21
   143a4:      	add	x2, x9, x10
   143a8:      	and	w1, w11, #0xff
   143ac:      	mov	w8, #0x4                // =4
   143b0:      	cinc	x0, x19, hi
   143b4:      	blr	x8
   143b8:      	ldr	x25, [sp, #0x8]
   143bc:      	cmp	w23, w21
   143c0:      	str	x19, [sp, #0x60]
   143c4:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   143c8:      	ldr	x21, [sp, #0x78]
   143cc:      	ldp	x2, x24, [sp, #0x50]
   143d0:      	str	x21, [sp, #0x48]
   143d4:      	b	0x14428 <generic_rawtp_path+0xa138>
   143d8:      	add	x2, x24, #0x10
   143dc:      	mov	w8, #0x4                // =4
   143e0:      	add	x9, sp, #0x98
   143e4:      	add	x0, sp, #0x98
   143e8:      	mov	w1, #0x8                // =8
   143ec:      	blr	x8
   143f0:      	ldr	x8, [sp, #0x58]
   143f4:      	ldr	x9, [sp, #0x98]
   143f8:      	cmp	x8, x9
   143fc:      	ldr	x25, [sp, #0x8]
   14400:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   14404:      	add	x2, x24, #0x18
   14408:      	mov	w8, #0x4                // =4
   1440c:      	mov	x0, x22
   14410:      	mov	w1, #0x8                // =8
   14414:      	blr	x8
   14418:      	ldr	x24, [sp, #0x98]
   1441c:      	ldr	x21, [sp, #0x48]
   14420:      	add	x2, x24, #0x20
   14424:      	stp	x2, x24, [sp, #0x50]
   14428:      	ldr	x8, [sp, #0x30]
   1442c:      	ldr	x25, [sp, #0x8]
   14430:      	add	x9, sp, #0x70
   14434:      	cmp	x21, x8
   14438:      	b.ne	0x14448 <generic_rawtp_path+0xa158>
   1443c:      	ldr	x8, [sp, #0x38]
   14440:      	cmp	x2, x8
   14444:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   14448:      	mov	w8, #0x4                // =4
   1444c:      	add	x0, sp, #0x70
   14450:      	mov	w1, #0x8                // =8
   14454:      	blr	x8
   14458:      	ldr	x8, [sp, #0x70]
   1445c:      	cmp	x21, x8
   14460:      	b.eq	0x14554 <generic_rawtp_path+0xa264>
   14464:      	add	x23, x21, #0x18
   14468:      	mov	w8, #0x4                // =4
   1446c:      	add	x9, sp, #0x98
   14470:      	add	x0, sp, #0x98
   14474:      	mov	w1, #0x8                // =8
   14478:      	mov	x2, x23
   1447c:      	blr	x8
   14480:      	ldr	x8, [sp, #0x98]
   14484:      	cmp	x8, x21
   14488:      	b.eq	0x14554 <generic_rawtp_path+0xa264>
   1448c:      	mov	w8, #0x4                // =4
   14490:      	add	x9, sp, #0x78
   14494:      	add	x0, sp, #0x78
   14498:      	mov	w1, #0x8                // =8
   1449c:      	mov	x2, x23
   144a0:      	blr	x8
   144a4:      	add	x2, x21, #0x20
   144a8:      	mov	w8, #0x4                // =4
   144ac:      	mov	w9, #0x10               // =16
   144b0:      	add	x10, sp, #0x80
   144b4:      	add	x0, sp, #0x80
   144b8:      	mov	w1, #0x10               // =16
   144bc:      	blr	x8
   144c0:      	ldr	w21, [sp, #0x84]
   144c4:      	ldr	x8, [sp, #0x40]
   144c8:      	ldr	x10, [sp, #0x60]
   144cc:      	sub	x12, x10, x8
   144d0:      	ldr	w23, [sp, #0x68]
   144d4:      	subs	w10, w21, w23
   144d8:      	ldr	x9, [sp, #0x88]
   144dc:      	ldr	x25, [sp, #0x8]
   144e0:      	csel	w10, wzr, w10, lo
   144e4:      	cmp	w23, w21
   144e8:      	csel	w11, w23, w21, lo
   144ec:      	cinc	w13, w11, hi
   144f0:      	sub	w14, w23, w13
   144f4:      	subs	x12, x12, x13
   144f8:      	str	w14, [sp, #0x68]
   144fc:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   14500:      	cmp	x12, #0xfff
   14504:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   14508:      	cmp	w23, w21
   1450c:      	b.ls	0x14518 <generic_rawtp_path+0xa228>
   14510:      	mov	w13, #0x2f              // =47
   14514:      	strb	w13, [x8, x12]
   14518:      	add	x19, x8, x12
   1451c:      	cmp	w23, w21
   14520:      	add	x2, x9, x10
   14524:      	and	w1, w11, #0xff
   14528:      	mov	w8, #0x4                // =4
   1452c:      	cinc	x0, x19, hi
   14530:      	blr	x8
   14534:      	ldr	x25, [sp, #0x8]
   14538:      	cmp	w23, w21
   1453c:      	str	x19, [sp, #0x60]
   14540:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   14544:      	ldr	x21, [sp, #0x78]
   14548:      	ldp	x2, x24, [sp, #0x50]
   1454c:      	str	x21, [sp, #0x48]
   14550:      	b	0x145a4 <generic_rawtp_path+0xa2b4>
   14554:      	add	x2, x24, #0x10
   14558:      	mov	w8, #0x4                // =4
   1455c:      	add	x9, sp, #0x98
   14560:      	add	x0, sp, #0x98
   14564:      	mov	w1, #0x8                // =8
   14568:      	blr	x8
   1456c:      	ldr	x8, [sp, #0x58]
   14570:      	ldr	x9, [sp, #0x98]
   14574:      	cmp	x8, x9
   14578:      	ldr	x25, [sp, #0x8]
   1457c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   14580:      	add	x2, x24, #0x18
   14584:      	mov	w8, #0x4                // =4
   14588:      	mov	x0, x22
   1458c:      	mov	w1, #0x8                // =8
   14590:      	blr	x8
   14594:      	ldr	x24, [sp, #0x98]
   14598:      	ldr	x21, [sp, #0x48]
   1459c:      	add	x2, x24, #0x20
   145a0:      	stp	x2, x24, [sp, #0x50]
   145a4:      	ldr	x8, [sp, #0x30]
   145a8:      	ldr	x25, [sp, #0x8]
   145ac:      	add	x9, sp, #0x70
   145b0:      	cmp	x21, x8
   145b4:      	b.ne	0x145c4 <generic_rawtp_path+0xa2d4>
   145b8:      	ldr	x8, [sp, #0x38]
   145bc:      	cmp	x2, x8
   145c0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   145c4:      	mov	w8, #0x4                // =4
   145c8:      	add	x0, sp, #0x70
   145cc:      	mov	w1, #0x8                // =8
   145d0:      	blr	x8
   145d4:      	ldr	x8, [sp, #0x70]
   145d8:      	cmp	x21, x8
   145dc:      	b.eq	0x146d0 <generic_rawtp_path+0xa3e0>
   145e0:      	add	x23, x21, #0x18
   145e4:      	mov	w8, #0x4                // =4
   145e8:      	add	x9, sp, #0x98
   145ec:      	add	x0, sp, #0x98
   145f0:      	mov	w1, #0x8                // =8
   145f4:      	mov	x2, x23
   145f8:      	blr	x8
   145fc:      	ldr	x8, [sp, #0x98]
   14600:      	cmp	x8, x21
   14604:      	b.eq	0x146d0 <generic_rawtp_path+0xa3e0>
   14608:      	mov	w8, #0x4                // =4
   1460c:      	add	x9, sp, #0x78
   14610:      	add	x0, sp, #0x78
   14614:      	mov	w1, #0x8                // =8
   14618:      	mov	x2, x23
   1461c:      	blr	x8
   14620:      	add	x2, x21, #0x20
   14624:      	mov	w8, #0x4                // =4
   14628:      	mov	w9, #0x10               // =16
   1462c:      	add	x10, sp, #0x80
   14630:      	add	x0, sp, #0x80
   14634:      	mov	w1, #0x10               // =16
   14638:      	blr	x8
   1463c:      	ldr	w21, [sp, #0x84]
   14640:      	ldr	x8, [sp, #0x40]
   14644:      	ldr	x10, [sp, #0x60]
   14648:      	sub	x12, x10, x8
   1464c:      	ldr	w23, [sp, #0x68]
   14650:      	subs	w10, w21, w23
   14654:      	ldr	x9, [sp, #0x88]
   14658:      	ldr	x25, [sp, #0x8]
   1465c:      	csel	w10, wzr, w10, lo
   14660:      	cmp	w23, w21
   14664:      	csel	w11, w23, w21, lo
   14668:      	cinc	w13, w11, hi
   1466c:      	sub	w14, w23, w13
   14670:      	subs	x12, x12, x13
   14674:      	str	w14, [sp, #0x68]
   14678:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   1467c:      	cmp	x12, #0xfff
   14680:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   14684:      	cmp	w23, w21
   14688:      	b.ls	0x14694 <generic_rawtp_path+0xa3a4>
   1468c:      	mov	w13, #0x2f              // =47
   14690:      	strb	w13, [x8, x12]
   14694:      	add	x19, x8, x12
   14698:      	cmp	w23, w21
   1469c:      	add	x2, x9, x10
   146a0:      	and	w1, w11, #0xff
   146a4:      	mov	w8, #0x4                // =4
   146a8:      	cinc	x0, x19, hi
   146ac:      	blr	x8
   146b0:      	ldr	x25, [sp, #0x8]
   146b4:      	cmp	w23, w21
   146b8:      	str	x19, [sp, #0x60]
   146bc:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   146c0:      	ldr	x21, [sp, #0x78]
   146c4:      	ldp	x2, x24, [sp, #0x50]
   146c8:      	str	x21, [sp, #0x48]
   146cc:      	b	0x14720 <generic_rawtp_path+0xa430>
   146d0:      	add	x2, x24, #0x10
   146d4:      	mov	w8, #0x4                // =4
   146d8:      	add	x9, sp, #0x98
   146dc:      	add	x0, sp, #0x98
   146e0:      	mov	w1, #0x8                // =8
   146e4:      	blr	x8
   146e8:      	ldr	x8, [sp, #0x58]
   146ec:      	ldr	x9, [sp, #0x98]
   146f0:      	cmp	x8, x9
   146f4:      	ldr	x25, [sp, #0x8]
   146f8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   146fc:      	add	x2, x24, #0x18
   14700:      	mov	w8, #0x4                // =4
   14704:      	mov	x0, x22
   14708:      	mov	w1, #0x8                // =8
   1470c:      	blr	x8
   14710:      	ldr	x24, [sp, #0x98]
   14714:      	ldr	x21, [sp, #0x48]
   14718:      	add	x2, x24, #0x20
   1471c:      	stp	x2, x24, [sp, #0x50]
   14720:      	ldr	x8, [sp, #0x30]
   14724:      	ldr	x25, [sp, #0x8]
   14728:      	add	x9, sp, #0x70
   1472c:      	cmp	x21, x8
   14730:      	b.ne	0x14740 <generic_rawtp_path+0xa450>
   14734:      	ldr	x8, [sp, #0x38]
   14738:      	cmp	x2, x8
   1473c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   14740:      	mov	w8, #0x4                // =4
   14744:      	add	x0, sp, #0x70
   14748:      	mov	w1, #0x8                // =8
   1474c:      	blr	x8
   14750:      	ldr	x8, [sp, #0x70]
   14754:      	cmp	x21, x8
   14758:      	b.eq	0x1484c <generic_rawtp_path+0xa55c>
   1475c:      	add	x23, x21, #0x18
   14760:      	mov	w8, #0x4                // =4
   14764:      	add	x9, sp, #0x98
   14768:      	add	x0, sp, #0x98
   1476c:      	mov	w1, #0x8                // =8
   14770:      	mov	x2, x23
   14774:      	blr	x8
   14778:      	ldr	x8, [sp, #0x98]
   1477c:      	cmp	x8, x21
   14780:      	b.eq	0x1484c <generic_rawtp_path+0xa55c>
   14784:      	mov	w8, #0x4                // =4
   14788:      	add	x9, sp, #0x78
   1478c:      	add	x0, sp, #0x78
   14790:      	mov	w1, #0x8                // =8
   14794:      	mov	x2, x23
   14798:      	blr	x8
   1479c:      	add	x2, x21, #0x20
   147a0:      	mov	w8, #0x4                // =4
   147a4:      	mov	w9, #0x10               // =16
   147a8:      	add	x10, sp, #0x80
   147ac:      	add	x0, sp, #0x80
   147b0:      	mov	w1, #0x10               // =16
   147b4:      	blr	x8
   147b8:      	ldr	w21, [sp, #0x84]
   147bc:      	ldr	x8, [sp, #0x40]
   147c0:      	ldr	x10, [sp, #0x60]
   147c4:      	sub	x12, x10, x8
   147c8:      	ldr	w23, [sp, #0x68]
   147cc:      	subs	w10, w21, w23
   147d0:      	ldr	x9, [sp, #0x88]
   147d4:      	ldr	x25, [sp, #0x8]
   147d8:      	csel	w10, wzr, w10, lo
   147dc:      	cmp	w23, w21
   147e0:      	csel	w11, w23, w21, lo
   147e4:      	cinc	w13, w11, hi
   147e8:      	sub	w14, w23, w13
   147ec:      	subs	x12, x12, x13
   147f0:      	str	w14, [sp, #0x68]
   147f4:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   147f8:      	cmp	x12, #0xfff
   147fc:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   14800:      	cmp	w23, w21
   14804:      	b.ls	0x14810 <generic_rawtp_path+0xa520>
   14808:      	mov	w13, #0x2f              // =47
   1480c:      	strb	w13, [x8, x12]
   14810:      	add	x19, x8, x12
   14814:      	cmp	w23, w21
   14818:      	add	x2, x9, x10
   1481c:      	and	w1, w11, #0xff
   14820:      	mov	w8, #0x4                // =4
   14824:      	cinc	x0, x19, hi
   14828:      	blr	x8
   1482c:      	ldr	x25, [sp, #0x8]
   14830:      	cmp	w23, w21
   14834:      	str	x19, [sp, #0x60]
   14838:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   1483c:      	ldr	x21, [sp, #0x78]
   14840:      	ldp	x2, x24, [sp, #0x50]
   14844:      	str	x21, [sp, #0x48]
   14848:      	b	0x1489c <generic_rawtp_path+0xa5ac>
   1484c:      	add	x2, x24, #0x10
   14850:      	mov	w8, #0x4                // =4
   14854:      	add	x9, sp, #0x98
   14858:      	add	x0, sp, #0x98
   1485c:      	mov	w1, #0x8                // =8
   14860:      	blr	x8
   14864:      	ldr	x8, [sp, #0x58]
   14868:      	ldr	x9, [sp, #0x98]
   1486c:      	cmp	x8, x9
   14870:      	ldr	x25, [sp, #0x8]
   14874:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   14878:      	add	x2, x24, #0x18
   1487c:      	mov	w8, #0x4                // =4
   14880:      	mov	x0, x22
   14884:      	mov	w1, #0x8                // =8
   14888:      	blr	x8
   1488c:      	ldr	x24, [sp, #0x98]
   14890:      	ldr	x21, [sp, #0x48]
   14894:      	add	x2, x24, #0x20
   14898:      	stp	x2, x24, [sp, #0x50]
   1489c:      	ldr	x8, [sp, #0x30]
   148a0:      	ldr	x25, [sp, #0x8]
   148a4:      	add	x9, sp, #0x70
   148a8:      	cmp	x21, x8
   148ac:      	b.ne	0x148bc <generic_rawtp_path+0xa5cc>
   148b0:      	ldr	x8, [sp, #0x38]
   148b4:      	cmp	x2, x8
   148b8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   148bc:      	mov	w8, #0x4                // =4
   148c0:      	add	x0, sp, #0x70
   148c4:      	mov	w1, #0x8                // =8
   148c8:      	blr	x8
   148cc:      	ldr	x8, [sp, #0x70]
   148d0:      	cmp	x21, x8
   148d4:      	b.eq	0x149c8 <generic_rawtp_path+0xa6d8>
   148d8:      	add	x23, x21, #0x18
   148dc:      	mov	w8, #0x4                // =4
   148e0:      	add	x9, sp, #0x98
   148e4:      	add	x0, sp, #0x98
   148e8:      	mov	w1, #0x8                // =8
   148ec:      	mov	x2, x23
   148f0:      	blr	x8
   148f4:      	ldr	x8, [sp, #0x98]
   148f8:      	cmp	x8, x21
   148fc:      	b.eq	0x149c8 <generic_rawtp_path+0xa6d8>
   14900:      	mov	w8, #0x4                // =4
   14904:      	add	x9, sp, #0x78
   14908:      	add	x0, sp, #0x78
   1490c:      	mov	w1, #0x8                // =8
   14910:      	mov	x2, x23
   14914:      	blr	x8
   14918:      	add	x2, x21, #0x20
   1491c:      	mov	w8, #0x4                // =4
   14920:      	mov	w9, #0x10               // =16
   14924:      	add	x10, sp, #0x80
   14928:      	add	x0, sp, #0x80
   1492c:      	mov	w1, #0x10               // =16
   14930:      	blr	x8
   14934:      	ldr	w21, [sp, #0x84]
   14938:      	ldr	x8, [sp, #0x40]
   1493c:      	ldr	x10, [sp, #0x60]
   14940:      	sub	x12, x10, x8
   14944:      	ldr	w23, [sp, #0x68]
   14948:      	subs	w10, w21, w23
   1494c:      	ldr	x9, [sp, #0x88]
   14950:      	ldr	x25, [sp, #0x8]
   14954:      	csel	w10, wzr, w10, lo
   14958:      	cmp	w23, w21
   1495c:      	csel	w11, w23, w21, lo
   14960:      	cinc	w13, w11, hi
   14964:      	sub	w14, w23, w13
   14968:      	subs	x12, x12, x13
   1496c:      	str	w14, [sp, #0x68]
   14970:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   14974:      	cmp	x12, #0xfff
   14978:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   1497c:      	cmp	w23, w21
   14980:      	b.ls	0x1498c <generic_rawtp_path+0xa69c>
   14984:      	mov	w13, #0x2f              // =47
   14988:      	strb	w13, [x8, x12]
   1498c:      	add	x19, x8, x12
   14990:      	cmp	w23, w21
   14994:      	add	x2, x9, x10
   14998:      	and	w1, w11, #0xff
   1499c:      	mov	w8, #0x4                // =4
   149a0:      	cinc	x0, x19, hi
   149a4:      	blr	x8
   149a8:      	ldr	x25, [sp, #0x8]
   149ac:      	cmp	w23, w21
   149b0:      	str	x19, [sp, #0x60]
   149b4:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   149b8:      	ldr	x21, [sp, #0x78]
   149bc:      	ldp	x2, x24, [sp, #0x50]
   149c0:      	str	x21, [sp, #0x48]
   149c4:      	b	0x14a18 <generic_rawtp_path+0xa728>
   149c8:      	add	x2, x24, #0x10
   149cc:      	mov	w8, #0x4                // =4
   149d0:      	add	x9, sp, #0x98
   149d4:      	add	x0, sp, #0x98
   149d8:      	mov	w1, #0x8                // =8
   149dc:      	blr	x8
   149e0:      	ldr	x8, [sp, #0x58]
   149e4:      	ldr	x9, [sp, #0x98]
   149e8:      	cmp	x8, x9
   149ec:      	ldr	x25, [sp, #0x8]
   149f0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   149f4:      	add	x2, x24, #0x18
   149f8:      	mov	w8, #0x4                // =4
   149fc:      	mov	x0, x22
   14a00:      	mov	w1, #0x8                // =8
   14a04:      	blr	x8
   14a08:      	ldr	x24, [sp, #0x98]
   14a0c:      	ldr	x21, [sp, #0x48]
   14a10:      	add	x2, x24, #0x20
   14a14:      	stp	x2, x24, [sp, #0x50]
   14a18:      	ldr	x8, [sp, #0x30]
   14a1c:      	ldr	x25, [sp, #0x8]
   14a20:      	add	x9, sp, #0x70
   14a24:      	cmp	x21, x8
   14a28:      	b.ne	0x14a38 <generic_rawtp_path+0xa748>
   14a2c:      	ldr	x8, [sp, #0x38]
   14a30:      	cmp	x2, x8
   14a34:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   14a38:      	mov	w8, #0x4                // =4
   14a3c:      	add	x0, sp, #0x70
   14a40:      	mov	w1, #0x8                // =8
   14a44:      	blr	x8
   14a48:      	ldr	x8, [sp, #0x70]
   14a4c:      	cmp	x21, x8
   14a50:      	b.eq	0x14b44 <generic_rawtp_path+0xa854>
   14a54:      	add	x23, x21, #0x18
   14a58:      	mov	w8, #0x4                // =4
   14a5c:      	add	x9, sp, #0x98
   14a60:      	add	x0, sp, #0x98
   14a64:      	mov	w1, #0x8                // =8
   14a68:      	mov	x2, x23
   14a6c:      	blr	x8
   14a70:      	ldr	x8, [sp, #0x98]
   14a74:      	cmp	x8, x21
   14a78:      	b.eq	0x14b44 <generic_rawtp_path+0xa854>
   14a7c:      	mov	w8, #0x4                // =4
   14a80:      	add	x9, sp, #0x78
   14a84:      	add	x0, sp, #0x78
   14a88:      	mov	w1, #0x8                // =8
   14a8c:      	mov	x2, x23
   14a90:      	blr	x8
   14a94:      	add	x2, x21, #0x20
   14a98:      	mov	w8, #0x4                // =4
   14a9c:      	mov	w9, #0x10               // =16
   14aa0:      	add	x10, sp, #0x80
   14aa4:      	add	x0, sp, #0x80
   14aa8:      	mov	w1, #0x10               // =16
   14aac:      	blr	x8
   14ab0:      	ldr	w21, [sp, #0x84]
   14ab4:      	ldr	x8, [sp, #0x40]
   14ab8:      	ldr	x10, [sp, #0x60]
   14abc:      	sub	x12, x10, x8
   14ac0:      	ldr	w23, [sp, #0x68]
   14ac4:      	subs	w10, w21, w23
   14ac8:      	ldr	x9, [sp, #0x88]
   14acc:      	ldr	x25, [sp, #0x8]
   14ad0:      	csel	w10, wzr, w10, lo
   14ad4:      	cmp	w23, w21
   14ad8:      	csel	w11, w23, w21, lo
   14adc:      	cinc	w13, w11, hi
   14ae0:      	sub	w14, w23, w13
   14ae4:      	subs	x12, x12, x13
   14ae8:      	str	w14, [sp, #0x68]
   14aec:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   14af0:      	cmp	x12, #0xfff
   14af4:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   14af8:      	cmp	w23, w21
   14afc:      	b.ls	0x14b08 <generic_rawtp_path+0xa818>
   14b00:      	mov	w13, #0x2f              // =47
   14b04:      	strb	w13, [x8, x12]
   14b08:      	add	x19, x8, x12
   14b0c:      	cmp	w23, w21
   14b10:      	add	x2, x9, x10
   14b14:      	and	w1, w11, #0xff
   14b18:      	mov	w8, #0x4                // =4
   14b1c:      	cinc	x0, x19, hi
   14b20:      	blr	x8
   14b24:      	ldr	x25, [sp, #0x8]
   14b28:      	cmp	w23, w21
   14b2c:      	str	x19, [sp, #0x60]
   14b30:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   14b34:      	ldr	x21, [sp, #0x78]
   14b38:      	ldp	x2, x24, [sp, #0x50]
   14b3c:      	str	x21, [sp, #0x48]
   14b40:      	b	0x14b94 <generic_rawtp_path+0xa8a4>
   14b44:      	add	x2, x24, #0x10
   14b48:      	mov	w8, #0x4                // =4
   14b4c:      	add	x9, sp, #0x98
   14b50:      	add	x0, sp, #0x98
   14b54:      	mov	w1, #0x8                // =8
   14b58:      	blr	x8
   14b5c:      	ldr	x8, [sp, #0x58]
   14b60:      	ldr	x9, [sp, #0x98]
   14b64:      	cmp	x8, x9
   14b68:      	ldr	x25, [sp, #0x8]
   14b6c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   14b70:      	add	x2, x24, #0x18
   14b74:      	mov	w8, #0x4                // =4
   14b78:      	mov	x0, x22
   14b7c:      	mov	w1, #0x8                // =8
   14b80:      	blr	x8
   14b84:      	ldr	x24, [sp, #0x98]
   14b88:      	ldr	x21, [sp, #0x48]
   14b8c:      	add	x2, x24, #0x20
   14b90:      	stp	x2, x24, [sp, #0x50]
   14b94:      	ldr	x8, [sp, #0x30]
   14b98:      	ldr	x25, [sp, #0x8]
   14b9c:      	add	x9, sp, #0x70
   14ba0:      	cmp	x21, x8
   14ba4:      	b.ne	0x14bb4 <generic_rawtp_path+0xa8c4>
   14ba8:      	ldr	x8, [sp, #0x38]
   14bac:      	cmp	x2, x8
   14bb0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   14bb4:      	mov	w8, #0x4                // =4
   14bb8:      	add	x0, sp, #0x70
   14bbc:      	mov	w1, #0x8                // =8
   14bc0:      	blr	x8
   14bc4:      	ldr	x8, [sp, #0x70]
   14bc8:      	cmp	x21, x8
   14bcc:      	b.eq	0x14cc0 <generic_rawtp_path+0xa9d0>
   14bd0:      	add	x23, x21, #0x18
   14bd4:      	mov	w8, #0x4                // =4
   14bd8:      	add	x9, sp, #0x98
   14bdc:      	add	x0, sp, #0x98
   14be0:      	mov	w1, #0x8                // =8
   14be4:      	mov	x2, x23
   14be8:      	blr	x8
   14bec:      	ldr	x8, [sp, #0x98]
   14bf0:      	cmp	x8, x21
   14bf4:      	b.eq	0x14cc0 <generic_rawtp_path+0xa9d0>
   14bf8:      	mov	w8, #0x4                // =4
   14bfc:      	add	x9, sp, #0x78
   14c00:      	add	x0, sp, #0x78
   14c04:      	mov	w1, #0x8                // =8
   14c08:      	mov	x2, x23
   14c0c:      	blr	x8
   14c10:      	add	x2, x21, #0x20
   14c14:      	mov	w8, #0x4                // =4
   14c18:      	mov	w9, #0x10               // =16
   14c1c:      	add	x10, sp, #0x80
   14c20:      	add	x0, sp, #0x80
   14c24:      	mov	w1, #0x10               // =16
   14c28:      	blr	x8
   14c2c:      	ldr	w21, [sp, #0x84]
   14c30:      	ldr	x8, [sp, #0x40]
   14c34:      	ldr	x10, [sp, #0x60]
   14c38:      	sub	x12, x10, x8
   14c3c:      	ldr	w23, [sp, #0x68]
   14c40:      	subs	w10, w21, w23
   14c44:      	ldr	x9, [sp, #0x88]
   14c48:      	ldr	x25, [sp, #0x8]
   14c4c:      	csel	w10, wzr, w10, lo
   14c50:      	cmp	w23, w21
   14c54:      	csel	w11, w23, w21, lo
   14c58:      	cinc	w13, w11, hi
   14c5c:      	sub	w14, w23, w13
   14c60:      	subs	x12, x12, x13
   14c64:      	str	w14, [sp, #0x68]
   14c68:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   14c6c:      	cmp	x12, #0xfff
   14c70:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   14c74:      	cmp	w23, w21
   14c78:      	b.ls	0x14c84 <generic_rawtp_path+0xa994>
   14c7c:      	mov	w13, #0x2f              // =47
   14c80:      	strb	w13, [x8, x12]
   14c84:      	add	x19, x8, x12
   14c88:      	cmp	w23, w21
   14c8c:      	add	x2, x9, x10
   14c90:      	and	w1, w11, #0xff
   14c94:      	mov	w8, #0x4                // =4
   14c98:      	cinc	x0, x19, hi
   14c9c:      	blr	x8
   14ca0:      	ldr	x25, [sp, #0x8]
   14ca4:      	cmp	w23, w21
   14ca8:      	str	x19, [sp, #0x60]
   14cac:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   14cb0:      	ldr	x21, [sp, #0x78]
   14cb4:      	ldp	x2, x24, [sp, #0x50]
   14cb8:      	str	x21, [sp, #0x48]
   14cbc:      	b	0x14d10 <generic_rawtp_path+0xaa20>
   14cc0:      	add	x2, x24, #0x10
   14cc4:      	mov	w8, #0x4                // =4
   14cc8:      	add	x9, sp, #0x98
   14ccc:      	add	x0, sp, #0x98
   14cd0:      	mov	w1, #0x8                // =8
   14cd4:      	blr	x8
   14cd8:      	ldr	x8, [sp, #0x58]
   14cdc:      	ldr	x9, [sp, #0x98]
   14ce0:      	cmp	x8, x9
   14ce4:      	ldr	x25, [sp, #0x8]
   14ce8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   14cec:      	add	x2, x24, #0x18
   14cf0:      	mov	w8, #0x4                // =4
   14cf4:      	mov	x0, x22
   14cf8:      	mov	w1, #0x8                // =8
   14cfc:      	blr	x8
   14d00:      	ldr	x24, [sp, #0x98]
   14d04:      	ldr	x21, [sp, #0x48]
   14d08:      	add	x2, x24, #0x20
   14d0c:      	stp	x2, x24, [sp, #0x50]
   14d10:      	ldr	x8, [sp, #0x30]
   14d14:      	ldr	x25, [sp, #0x8]
   14d18:      	add	x9, sp, #0x70
   14d1c:      	cmp	x21, x8
   14d20:      	b.ne	0x14d30 <generic_rawtp_path+0xaa40>
   14d24:      	ldr	x8, [sp, #0x38]
   14d28:      	cmp	x2, x8
   14d2c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   14d30:      	mov	w8, #0x4                // =4
   14d34:      	add	x0, sp, #0x70
   14d38:      	mov	w1, #0x8                // =8
   14d3c:      	blr	x8
   14d40:      	ldr	x8, [sp, #0x70]
   14d44:      	cmp	x21, x8
   14d48:      	b.eq	0x14e3c <generic_rawtp_path+0xab4c>
   14d4c:      	add	x23, x21, #0x18
   14d50:      	mov	w8, #0x4                // =4
   14d54:      	add	x9, sp, #0x98
   14d58:      	add	x0, sp, #0x98
   14d5c:      	mov	w1, #0x8                // =8
   14d60:      	mov	x2, x23
   14d64:      	blr	x8
   14d68:      	ldr	x8, [sp, #0x98]
   14d6c:      	cmp	x8, x21
   14d70:      	b.eq	0x14e3c <generic_rawtp_path+0xab4c>
   14d74:      	mov	w8, #0x4                // =4
   14d78:      	add	x9, sp, #0x78
   14d7c:      	add	x0, sp, #0x78
   14d80:      	mov	w1, #0x8                // =8
   14d84:      	mov	x2, x23
   14d88:      	blr	x8
   14d8c:      	add	x2, x21, #0x20
   14d90:      	mov	w8, #0x4                // =4
   14d94:      	mov	w9, #0x10               // =16
   14d98:      	add	x10, sp, #0x80
   14d9c:      	add	x0, sp, #0x80
   14da0:      	mov	w1, #0x10               // =16
   14da4:      	blr	x8
   14da8:      	ldr	w21, [sp, #0x84]
   14dac:      	ldr	x8, [sp, #0x40]
   14db0:      	ldr	x10, [sp, #0x60]
   14db4:      	sub	x12, x10, x8
   14db8:      	ldr	w23, [sp, #0x68]
   14dbc:      	subs	w10, w21, w23
   14dc0:      	ldr	x9, [sp, #0x88]
   14dc4:      	ldr	x25, [sp, #0x8]
   14dc8:      	csel	w10, wzr, w10, lo
   14dcc:      	cmp	w23, w21
   14dd0:      	csel	w11, w23, w21, lo
   14dd4:      	cinc	w13, w11, hi
   14dd8:      	sub	w14, w23, w13
   14ddc:      	subs	x12, x12, x13
   14de0:      	str	w14, [sp, #0x68]
   14de4:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   14de8:      	cmp	x12, #0xfff
   14dec:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   14df0:      	cmp	w23, w21
   14df4:      	b.ls	0x14e00 <generic_rawtp_path+0xab10>
   14df8:      	mov	w13, #0x2f              // =47
   14dfc:      	strb	w13, [x8, x12]
   14e00:      	add	x19, x8, x12
   14e04:      	cmp	w23, w21
   14e08:      	add	x2, x9, x10
   14e0c:      	and	w1, w11, #0xff
   14e10:      	mov	w8, #0x4                // =4
   14e14:      	cinc	x0, x19, hi
   14e18:      	blr	x8
   14e1c:      	ldr	x25, [sp, #0x8]
   14e20:      	cmp	w23, w21
   14e24:      	str	x19, [sp, #0x60]
   14e28:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   14e2c:      	ldr	x21, [sp, #0x78]
   14e30:      	ldp	x2, x24, [sp, #0x50]
   14e34:      	str	x21, [sp, #0x48]
   14e38:      	b	0x14e8c <generic_rawtp_path+0xab9c>
   14e3c:      	add	x2, x24, #0x10
   14e40:      	mov	w8, #0x4                // =4
   14e44:      	add	x9, sp, #0x98
   14e48:      	add	x0, sp, #0x98
   14e4c:      	mov	w1, #0x8                // =8
   14e50:      	blr	x8
   14e54:      	ldr	x8, [sp, #0x58]
   14e58:      	ldr	x9, [sp, #0x98]
   14e5c:      	cmp	x8, x9
   14e60:      	ldr	x25, [sp, #0x8]
   14e64:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   14e68:      	add	x2, x24, #0x18
   14e6c:      	mov	w8, #0x4                // =4
   14e70:      	mov	x0, x22
   14e74:      	mov	w1, #0x8                // =8
   14e78:      	blr	x8
   14e7c:      	ldr	x24, [sp, #0x98]
   14e80:      	ldr	x21, [sp, #0x48]
   14e84:      	add	x2, x24, #0x20
   14e88:      	stp	x2, x24, [sp, #0x50]
   14e8c:      	ldr	x8, [sp, #0x30]
   14e90:      	ldr	x25, [sp, #0x8]
   14e94:      	add	x9, sp, #0x70
   14e98:      	cmp	x21, x8
   14e9c:      	b.ne	0x14eac <generic_rawtp_path+0xabbc>
   14ea0:      	ldr	x8, [sp, #0x38]
   14ea4:      	cmp	x2, x8
   14ea8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   14eac:      	mov	w8, #0x4                // =4
   14eb0:      	add	x0, sp, #0x70
   14eb4:      	mov	w1, #0x8                // =8
   14eb8:      	blr	x8
   14ebc:      	ldr	x8, [sp, #0x70]
   14ec0:      	cmp	x21, x8
   14ec4:      	b.eq	0x14fb8 <generic_rawtp_path+0xacc8>
   14ec8:      	add	x23, x21, #0x18
   14ecc:      	mov	w8, #0x4                // =4
   14ed0:      	add	x9, sp, #0x98
   14ed4:      	add	x0, sp, #0x98
   14ed8:      	mov	w1, #0x8                // =8
   14edc:      	mov	x2, x23
   14ee0:      	blr	x8
   14ee4:      	ldr	x8, [sp, #0x98]
   14ee8:      	cmp	x8, x21
   14eec:      	b.eq	0x14fb8 <generic_rawtp_path+0xacc8>
   14ef0:      	mov	w8, #0x4                // =4
   14ef4:      	add	x9, sp, #0x78
   14ef8:      	add	x0, sp, #0x78
   14efc:      	mov	w1, #0x8                // =8
   14f00:      	mov	x2, x23
   14f04:      	blr	x8
   14f08:      	add	x2, x21, #0x20
   14f0c:      	mov	w8, #0x4                // =4
   14f10:      	mov	w9, #0x10               // =16
   14f14:      	add	x10, sp, #0x80
   14f18:      	add	x0, sp, #0x80
   14f1c:      	mov	w1, #0x10               // =16
   14f20:      	blr	x8
   14f24:      	ldr	w21, [sp, #0x84]
   14f28:      	ldr	x8, [sp, #0x40]
   14f2c:      	ldr	x10, [sp, #0x60]
   14f30:      	sub	x12, x10, x8
   14f34:      	ldr	w23, [sp, #0x68]
   14f38:      	subs	w10, w21, w23
   14f3c:      	ldr	x9, [sp, #0x88]
   14f40:      	ldr	x25, [sp, #0x8]
   14f44:      	csel	w10, wzr, w10, lo
   14f48:      	cmp	w23, w21
   14f4c:      	csel	w11, w23, w21, lo
   14f50:      	cinc	w13, w11, hi
   14f54:      	sub	w14, w23, w13
   14f58:      	subs	x12, x12, x13
   14f5c:      	str	w14, [sp, #0x68]
   14f60:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   14f64:      	cmp	x12, #0xfff
   14f68:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   14f6c:      	cmp	w23, w21
   14f70:      	b.ls	0x14f7c <generic_rawtp_path+0xac8c>
   14f74:      	mov	w13, #0x2f              // =47
   14f78:      	strb	w13, [x8, x12]
   14f7c:      	add	x19, x8, x12
   14f80:      	cmp	w23, w21
   14f84:      	add	x2, x9, x10
   14f88:      	and	w1, w11, #0xff
   14f8c:      	mov	w8, #0x4                // =4
   14f90:      	cinc	x0, x19, hi
   14f94:      	blr	x8
   14f98:      	ldr	x25, [sp, #0x8]
   14f9c:      	cmp	w23, w21
   14fa0:      	str	x19, [sp, #0x60]
   14fa4:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   14fa8:      	ldr	x21, [sp, #0x78]
   14fac:      	ldp	x2, x24, [sp, #0x50]
   14fb0:      	str	x21, [sp, #0x48]
   14fb4:      	b	0x15008 <generic_rawtp_path+0xad18>
   14fb8:      	add	x2, x24, #0x10
   14fbc:      	mov	w8, #0x4                // =4
   14fc0:      	add	x9, sp, #0x98
   14fc4:      	add	x0, sp, #0x98
   14fc8:      	mov	w1, #0x8                // =8
   14fcc:      	blr	x8
   14fd0:      	ldr	x8, [sp, #0x58]
   14fd4:      	ldr	x9, [sp, #0x98]
   14fd8:      	cmp	x8, x9
   14fdc:      	ldr	x25, [sp, #0x8]
   14fe0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   14fe4:      	add	x2, x24, #0x18
   14fe8:      	mov	w8, #0x4                // =4
   14fec:      	mov	x0, x22
   14ff0:      	mov	w1, #0x8                // =8
   14ff4:      	blr	x8
   14ff8:      	ldr	x24, [sp, #0x98]
   14ffc:      	ldr	x21, [sp, #0x48]
   15000:      	add	x2, x24, #0x20
   15004:      	stp	x2, x24, [sp, #0x50]
   15008:      	ldr	x8, [sp, #0x30]
   1500c:      	ldr	x25, [sp, #0x8]
   15010:      	add	x9, sp, #0x70
   15014:      	cmp	x21, x8
   15018:      	b.ne	0x15028 <generic_rawtp_path+0xad38>
   1501c:      	ldr	x8, [sp, #0x38]
   15020:      	cmp	x2, x8
   15024:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   15028:      	mov	w8, #0x4                // =4
   1502c:      	add	x0, sp, #0x70
   15030:      	mov	w1, #0x8                // =8
   15034:      	blr	x8
   15038:      	ldr	x8, [sp, #0x70]
   1503c:      	cmp	x21, x8
   15040:      	b.eq	0x15134 <generic_rawtp_path+0xae44>
   15044:      	add	x23, x21, #0x18
   15048:      	mov	w8, #0x4                // =4
   1504c:      	add	x9, sp, #0x98
   15050:      	add	x0, sp, #0x98
   15054:      	mov	w1, #0x8                // =8
   15058:      	mov	x2, x23
   1505c:      	blr	x8
   15060:      	ldr	x8, [sp, #0x98]
   15064:      	cmp	x8, x21
   15068:      	b.eq	0x15134 <generic_rawtp_path+0xae44>
   1506c:      	mov	w8, #0x4                // =4
   15070:      	add	x9, sp, #0x78
   15074:      	add	x0, sp, #0x78
   15078:      	mov	w1, #0x8                // =8
   1507c:      	mov	x2, x23
   15080:      	blr	x8
   15084:      	add	x2, x21, #0x20
   15088:      	mov	w8, #0x4                // =4
   1508c:      	mov	w9, #0x10               // =16
   15090:      	add	x10, sp, #0x80
   15094:      	add	x0, sp, #0x80
   15098:      	mov	w1, #0x10               // =16
   1509c:      	blr	x8
   150a0:      	ldr	w21, [sp, #0x84]
   150a4:      	ldr	x8, [sp, #0x40]
   150a8:      	ldr	x10, [sp, #0x60]
   150ac:      	sub	x12, x10, x8
   150b0:      	ldr	w23, [sp, #0x68]
   150b4:      	subs	w10, w21, w23
   150b8:      	ldr	x9, [sp, #0x88]
   150bc:      	ldr	x25, [sp, #0x8]
   150c0:      	csel	w10, wzr, w10, lo
   150c4:      	cmp	w23, w21
   150c8:      	csel	w11, w23, w21, lo
   150cc:      	cinc	w13, w11, hi
   150d0:      	sub	w14, w23, w13
   150d4:      	subs	x12, x12, x13
   150d8:      	str	w14, [sp, #0x68]
   150dc:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   150e0:      	cmp	x12, #0xfff
   150e4:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   150e8:      	cmp	w23, w21
   150ec:      	b.ls	0x150f8 <generic_rawtp_path+0xae08>
   150f0:      	mov	w13, #0x2f              // =47
   150f4:      	strb	w13, [x8, x12]
   150f8:      	add	x19, x8, x12
   150fc:      	cmp	w23, w21
   15100:      	add	x2, x9, x10
   15104:      	and	w1, w11, #0xff
   15108:      	mov	w8, #0x4                // =4
   1510c:      	cinc	x0, x19, hi
   15110:      	blr	x8
   15114:      	ldr	x25, [sp, #0x8]
   15118:      	cmp	w23, w21
   1511c:      	str	x19, [sp, #0x60]
   15120:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   15124:      	ldr	x21, [sp, #0x78]
   15128:      	ldp	x2, x24, [sp, #0x50]
   1512c:      	str	x21, [sp, #0x48]
   15130:      	b	0x15184 <generic_rawtp_path+0xae94>
   15134:      	add	x2, x24, #0x10
   15138:      	mov	w8, #0x4                // =4
   1513c:      	add	x9, sp, #0x98
   15140:      	add	x0, sp, #0x98
   15144:      	mov	w1, #0x8                // =8
   15148:      	blr	x8
   1514c:      	ldr	x8, [sp, #0x58]
   15150:      	ldr	x9, [sp, #0x98]
   15154:      	cmp	x8, x9
   15158:      	ldr	x25, [sp, #0x8]
   1515c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   15160:      	add	x2, x24, #0x18
   15164:      	mov	w8, #0x4                // =4
   15168:      	mov	x0, x22
   1516c:      	mov	w1, #0x8                // =8
   15170:      	blr	x8
   15174:      	ldr	x24, [sp, #0x98]
   15178:      	ldr	x21, [sp, #0x48]
   1517c:      	add	x2, x24, #0x20
   15180:      	stp	x2, x24, [sp, #0x50]
   15184:      	ldr	x8, [sp, #0x30]
   15188:      	ldr	x25, [sp, #0x8]
   1518c:      	add	x9, sp, #0x70
   15190:      	cmp	x21, x8
   15194:      	b.ne	0x151a4 <generic_rawtp_path+0xaeb4>
   15198:      	ldr	x8, [sp, #0x38]
   1519c:      	cmp	x2, x8
   151a0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   151a4:      	mov	w8, #0x4                // =4
   151a8:      	add	x0, sp, #0x70
   151ac:      	mov	w1, #0x8                // =8
   151b0:      	blr	x8
   151b4:      	ldr	x8, [sp, #0x70]
   151b8:      	cmp	x21, x8
   151bc:      	b.eq	0x152b0 <generic_rawtp_path+0xafc0>
   151c0:      	add	x23, x21, #0x18
   151c4:      	mov	w8, #0x4                // =4
   151c8:      	add	x9, sp, #0x98
   151cc:      	add	x0, sp, #0x98
   151d0:      	mov	w1, #0x8                // =8
   151d4:      	mov	x2, x23
   151d8:      	blr	x8
   151dc:      	ldr	x8, [sp, #0x98]
   151e0:      	cmp	x8, x21
   151e4:      	b.eq	0x152b0 <generic_rawtp_path+0xafc0>
   151e8:      	mov	w8, #0x4                // =4
   151ec:      	add	x9, sp, #0x78
   151f0:      	add	x0, sp, #0x78
   151f4:      	mov	w1, #0x8                // =8
   151f8:      	mov	x2, x23
   151fc:      	blr	x8
   15200:      	add	x2, x21, #0x20
   15204:      	mov	w8, #0x4                // =4
   15208:      	mov	w9, #0x10               // =16
   1520c:      	add	x10, sp, #0x80
   15210:      	add	x0, sp, #0x80
   15214:      	mov	w1, #0x10               // =16
   15218:      	blr	x8
   1521c:      	ldr	w21, [sp, #0x84]
   15220:      	ldr	x8, [sp, #0x40]
   15224:      	ldr	x10, [sp, #0x60]
   15228:      	sub	x12, x10, x8
   1522c:      	ldr	w23, [sp, #0x68]
   15230:      	subs	w10, w21, w23
   15234:      	ldr	x9, [sp, #0x88]
   15238:      	ldr	x25, [sp, #0x8]
   1523c:      	csel	w10, wzr, w10, lo
   15240:      	cmp	w23, w21
   15244:      	csel	w11, w23, w21, lo
   15248:      	cinc	w13, w11, hi
   1524c:      	sub	w14, w23, w13
   15250:      	subs	x12, x12, x13
   15254:      	str	w14, [sp, #0x68]
   15258:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   1525c:      	cmp	x12, #0xfff
   15260:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   15264:      	cmp	w23, w21
   15268:      	b.ls	0x15274 <generic_rawtp_path+0xaf84>
   1526c:      	mov	w13, #0x2f              // =47
   15270:      	strb	w13, [x8, x12]
   15274:      	add	x19, x8, x12
   15278:      	cmp	w23, w21
   1527c:      	add	x2, x9, x10
   15280:      	and	w1, w11, #0xff
   15284:      	mov	w8, #0x4                // =4
   15288:      	cinc	x0, x19, hi
   1528c:      	blr	x8
   15290:      	ldr	x25, [sp, #0x8]
   15294:      	cmp	w23, w21
   15298:      	str	x19, [sp, #0x60]
   1529c:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   152a0:      	ldr	x21, [sp, #0x78]
   152a4:      	ldp	x2, x24, [sp, #0x50]
   152a8:      	str	x21, [sp, #0x48]
   152ac:      	b	0x15300 <generic_rawtp_path+0xb010>
   152b0:      	add	x2, x24, #0x10
   152b4:      	mov	w8, #0x4                // =4
   152b8:      	add	x9, sp, #0x98
   152bc:      	add	x0, sp, #0x98
   152c0:      	mov	w1, #0x8                // =8
   152c4:      	blr	x8
   152c8:      	ldr	x8, [sp, #0x58]
   152cc:      	ldr	x9, [sp, #0x98]
   152d0:      	cmp	x8, x9
   152d4:      	ldr	x25, [sp, #0x8]
   152d8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   152dc:      	add	x2, x24, #0x18
   152e0:      	mov	w8, #0x4                // =4
   152e4:      	mov	x0, x22
   152e8:      	mov	w1, #0x8                // =8
   152ec:      	blr	x8
   152f0:      	ldr	x24, [sp, #0x98]
   152f4:      	ldr	x21, [sp, #0x48]
   152f8:      	add	x2, x24, #0x20
   152fc:      	stp	x2, x24, [sp, #0x50]
   15300:      	ldr	x8, [sp, #0x30]
   15304:      	ldr	x25, [sp, #0x8]
   15308:      	add	x9, sp, #0x70
   1530c:      	cmp	x21, x8
   15310:      	b.ne	0x15320 <generic_rawtp_path+0xb030>
   15314:      	ldr	x8, [sp, #0x38]
   15318:      	cmp	x2, x8
   1531c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   15320:      	mov	w8, #0x4                // =4
   15324:      	add	x0, sp, #0x70
   15328:      	mov	w1, #0x8                // =8
   1532c:      	blr	x8
   15330:      	ldr	x8, [sp, #0x70]
   15334:      	cmp	x21, x8
   15338:      	b.eq	0x1542c <generic_rawtp_path+0xb13c>
   1533c:      	add	x23, x21, #0x18
   15340:      	mov	w8, #0x4                // =4
   15344:      	add	x9, sp, #0x98
   15348:      	add	x0, sp, #0x98
   1534c:      	mov	w1, #0x8                // =8
   15350:      	mov	x2, x23
   15354:      	blr	x8
   15358:      	ldr	x8, [sp, #0x98]
   1535c:      	cmp	x8, x21
   15360:      	b.eq	0x1542c <generic_rawtp_path+0xb13c>
   15364:      	mov	w8, #0x4                // =4
   15368:      	add	x9, sp, #0x78
   1536c:      	add	x0, sp, #0x78
   15370:      	mov	w1, #0x8                // =8
   15374:      	mov	x2, x23
   15378:      	blr	x8
   1537c:      	add	x2, x21, #0x20
   15380:      	mov	w8, #0x4                // =4
   15384:      	mov	w9, #0x10               // =16
   15388:      	add	x10, sp, #0x80
   1538c:      	add	x0, sp, #0x80
   15390:      	mov	w1, #0x10               // =16
   15394:      	blr	x8
   15398:      	ldr	w21, [sp, #0x84]
   1539c:      	ldr	x8, [sp, #0x40]
   153a0:      	ldr	x10, [sp, #0x60]
   153a4:      	sub	x12, x10, x8
   153a8:      	ldr	w23, [sp, #0x68]
   153ac:      	subs	w10, w21, w23
   153b0:      	ldr	x9, [sp, #0x88]
   153b4:      	ldr	x25, [sp, #0x8]
   153b8:      	csel	w10, wzr, w10, lo
   153bc:      	cmp	w23, w21
   153c0:      	csel	w11, w23, w21, lo
   153c4:      	cinc	w13, w11, hi
   153c8:      	sub	w14, w23, w13
   153cc:      	subs	x12, x12, x13
   153d0:      	str	w14, [sp, #0x68]
   153d4:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   153d8:      	cmp	x12, #0xfff
   153dc:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   153e0:      	cmp	w23, w21
   153e4:      	b.ls	0x153f0 <generic_rawtp_path+0xb100>
   153e8:      	mov	w13, #0x2f              // =47
   153ec:      	strb	w13, [x8, x12]
   153f0:      	add	x19, x8, x12
   153f4:      	cmp	w23, w21
   153f8:      	add	x2, x9, x10
   153fc:      	and	w1, w11, #0xff
   15400:      	mov	w8, #0x4                // =4
   15404:      	cinc	x0, x19, hi
   15408:      	blr	x8
   1540c:      	ldr	x25, [sp, #0x8]
   15410:      	cmp	w23, w21
   15414:      	str	x19, [sp, #0x60]
   15418:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   1541c:      	ldr	x21, [sp, #0x78]
   15420:      	ldp	x2, x24, [sp, #0x50]
   15424:      	str	x21, [sp, #0x48]
   15428:      	b	0x1547c <generic_rawtp_path+0xb18c>
   1542c:      	add	x2, x24, #0x10
   15430:      	mov	w8, #0x4                // =4
   15434:      	add	x9, sp, #0x98
   15438:      	add	x0, sp, #0x98
   1543c:      	mov	w1, #0x8                // =8
   15440:      	blr	x8
   15444:      	ldr	x8, [sp, #0x58]
   15448:      	ldr	x9, [sp, #0x98]
   1544c:      	cmp	x8, x9
   15450:      	ldr	x25, [sp, #0x8]
   15454:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   15458:      	add	x2, x24, #0x18
   1545c:      	mov	w8, #0x4                // =4
   15460:      	mov	x0, x22
   15464:      	mov	w1, #0x8                // =8
   15468:      	blr	x8
   1546c:      	ldr	x24, [sp, #0x98]
   15470:      	ldr	x21, [sp, #0x48]
   15474:      	add	x2, x24, #0x20
   15478:      	stp	x2, x24, [sp, #0x50]
   1547c:      	ldr	x8, [sp, #0x30]
   15480:      	ldr	x25, [sp, #0x8]
   15484:      	add	x9, sp, #0x70
   15488:      	cmp	x21, x8
   1548c:      	b.ne	0x1549c <generic_rawtp_path+0xb1ac>
   15490:      	ldr	x8, [sp, #0x38]
   15494:      	cmp	x2, x8
   15498:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   1549c:      	mov	w8, #0x4                // =4
   154a0:      	add	x0, sp, #0x70
   154a4:      	mov	w1, #0x8                // =8
   154a8:      	blr	x8
   154ac:      	ldr	x8, [sp, #0x70]
   154b0:      	cmp	x21, x8
   154b4:      	b.eq	0x155a8 <generic_rawtp_path+0xb2b8>
   154b8:      	add	x23, x21, #0x18
   154bc:      	mov	w8, #0x4                // =4
   154c0:      	add	x9, sp, #0x98
   154c4:      	add	x0, sp, #0x98
   154c8:      	mov	w1, #0x8                // =8
   154cc:      	mov	x2, x23
   154d0:      	blr	x8
   154d4:      	ldr	x8, [sp, #0x98]
   154d8:      	cmp	x8, x21
   154dc:      	b.eq	0x155a8 <generic_rawtp_path+0xb2b8>
   154e0:      	mov	w8, #0x4                // =4
   154e4:      	add	x9, sp, #0x78
   154e8:      	add	x0, sp, #0x78
   154ec:      	mov	w1, #0x8                // =8
   154f0:      	mov	x2, x23
   154f4:      	blr	x8
   154f8:      	add	x2, x21, #0x20
   154fc:      	mov	w8, #0x4                // =4
   15500:      	mov	w9, #0x10               // =16
   15504:      	add	x10, sp, #0x80
   15508:      	add	x0, sp, #0x80
   1550c:      	mov	w1, #0x10               // =16
   15510:      	blr	x8
   15514:      	ldr	w21, [sp, #0x84]
   15518:      	ldr	x8, [sp, #0x40]
   1551c:      	ldr	x10, [sp, #0x60]
   15520:      	sub	x12, x10, x8
   15524:      	ldr	w23, [sp, #0x68]
   15528:      	subs	w10, w21, w23
   1552c:      	ldr	x9, [sp, #0x88]
   15530:      	ldr	x25, [sp, #0x8]
   15534:      	csel	w10, wzr, w10, lo
   15538:      	cmp	w23, w21
   1553c:      	csel	w11, w23, w21, lo
   15540:      	cinc	w13, w11, hi
   15544:      	sub	w14, w23, w13
   15548:      	subs	x12, x12, x13
   1554c:      	str	w14, [sp, #0x68]
   15550:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   15554:      	cmp	x12, #0xfff
   15558:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   1555c:      	cmp	w23, w21
   15560:      	b.ls	0x1556c <generic_rawtp_path+0xb27c>
   15564:      	mov	w13, #0x2f              // =47
   15568:      	strb	w13, [x8, x12]
   1556c:      	add	x19, x8, x12
   15570:      	cmp	w23, w21
   15574:      	add	x2, x9, x10
   15578:      	and	w1, w11, #0xff
   1557c:      	mov	w8, #0x4                // =4
   15580:      	cinc	x0, x19, hi
   15584:      	blr	x8
   15588:      	ldr	x25, [sp, #0x8]
   1558c:      	cmp	w23, w21
   15590:      	str	x19, [sp, #0x60]
   15594:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   15598:      	ldr	x21, [sp, #0x78]
   1559c:      	ldp	x2, x24, [sp, #0x50]
   155a0:      	str	x21, [sp, #0x48]
   155a4:      	b	0x155f8 <generic_rawtp_path+0xb308>
   155a8:      	add	x2, x24, #0x10
   155ac:      	mov	w8, #0x4                // =4
   155b0:      	add	x9, sp, #0x98
   155b4:      	add	x0, sp, #0x98
   155b8:      	mov	w1, #0x8                // =8
   155bc:      	blr	x8
   155c0:      	ldr	x8, [sp, #0x58]
   155c4:      	ldr	x9, [sp, #0x98]
   155c8:      	cmp	x8, x9
   155cc:      	ldr	x25, [sp, #0x8]
   155d0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   155d4:      	add	x2, x24, #0x18
   155d8:      	mov	w8, #0x4                // =4
   155dc:      	mov	x0, x22
   155e0:      	mov	w1, #0x8                // =8
   155e4:      	blr	x8
   155e8:      	ldr	x24, [sp, #0x98]
   155ec:      	ldr	x21, [sp, #0x48]
   155f0:      	add	x2, x24, #0x20
   155f4:      	stp	x2, x24, [sp, #0x50]
   155f8:      	ldr	x8, [sp, #0x30]
   155fc:      	ldr	x25, [sp, #0x8]
   15600:      	add	x9, sp, #0x70
   15604:      	cmp	x21, x8
   15608:      	b.ne	0x15618 <generic_rawtp_path+0xb328>
   1560c:      	ldr	x8, [sp, #0x38]
   15610:      	cmp	x2, x8
   15614:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   15618:      	mov	w8, #0x4                // =4
   1561c:      	add	x0, sp, #0x70
   15620:      	mov	w1, #0x8                // =8
   15624:      	blr	x8
   15628:      	ldr	x8, [sp, #0x70]
   1562c:      	cmp	x21, x8
   15630:      	b.eq	0x15724 <generic_rawtp_path+0xb434>
   15634:      	add	x23, x21, #0x18
   15638:      	mov	w8, #0x4                // =4
   1563c:      	add	x9, sp, #0x98
   15640:      	add	x0, sp, #0x98
   15644:      	mov	w1, #0x8                // =8
   15648:      	mov	x2, x23
   1564c:      	blr	x8
   15650:      	ldr	x8, [sp, #0x98]
   15654:      	cmp	x8, x21
   15658:      	b.eq	0x15724 <generic_rawtp_path+0xb434>
   1565c:      	mov	w8, #0x4                // =4
   15660:      	add	x9, sp, #0x78
   15664:      	add	x0, sp, #0x78
   15668:      	mov	w1, #0x8                // =8
   1566c:      	mov	x2, x23
   15670:      	blr	x8
   15674:      	add	x2, x21, #0x20
   15678:      	mov	w8, #0x4                // =4
   1567c:      	mov	w9, #0x10               // =16
   15680:      	add	x10, sp, #0x80
   15684:      	add	x0, sp, #0x80
   15688:      	mov	w1, #0x10               // =16
   1568c:      	blr	x8
   15690:      	ldr	w21, [sp, #0x84]
   15694:      	ldr	x8, [sp, #0x40]
   15698:      	ldr	x10, [sp, #0x60]
   1569c:      	sub	x12, x10, x8
   156a0:      	ldr	w23, [sp, #0x68]
   156a4:      	subs	w10, w21, w23
   156a8:      	ldr	x9, [sp, #0x88]
   156ac:      	ldr	x25, [sp, #0x8]
   156b0:      	csel	w10, wzr, w10, lo
   156b4:      	cmp	w23, w21
   156b8:      	csel	w11, w23, w21, lo
   156bc:      	cinc	w13, w11, hi
   156c0:      	sub	w14, w23, w13
   156c4:      	subs	x12, x12, x13
   156c8:      	str	w14, [sp, #0x68]
   156cc:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   156d0:      	cmp	x12, #0xfff
   156d4:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   156d8:      	cmp	w23, w21
   156dc:      	b.ls	0x156e8 <generic_rawtp_path+0xb3f8>
   156e0:      	mov	w13, #0x2f              // =47
   156e4:      	strb	w13, [x8, x12]
   156e8:      	add	x19, x8, x12
   156ec:      	cmp	w23, w21
   156f0:      	add	x2, x9, x10
   156f4:      	and	w1, w11, #0xff
   156f8:      	mov	w8, #0x4                // =4
   156fc:      	cinc	x0, x19, hi
   15700:      	blr	x8
   15704:      	ldr	x25, [sp, #0x8]
   15708:      	cmp	w23, w21
   1570c:      	str	x19, [sp, #0x60]
   15710:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   15714:      	ldr	x21, [sp, #0x78]
   15718:      	ldp	x2, x24, [sp, #0x50]
   1571c:      	str	x21, [sp, #0x48]
   15720:      	b	0x15774 <generic_rawtp_path+0xb484>
   15724:      	add	x2, x24, #0x10
   15728:      	mov	w8, #0x4                // =4
   1572c:      	add	x9, sp, #0x98
   15730:      	add	x0, sp, #0x98
   15734:      	mov	w1, #0x8                // =8
   15738:      	blr	x8
   1573c:      	ldr	x8, [sp, #0x58]
   15740:      	ldr	x9, [sp, #0x98]
   15744:      	cmp	x8, x9
   15748:      	ldr	x25, [sp, #0x8]
   1574c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   15750:      	add	x2, x24, #0x18
   15754:      	mov	w8, #0x4                // =4
   15758:      	mov	x0, x22
   1575c:      	mov	w1, #0x8                // =8
   15760:      	blr	x8
   15764:      	ldr	x24, [sp, #0x98]
   15768:      	ldr	x21, [sp, #0x48]
   1576c:      	add	x2, x24, #0x20
   15770:      	stp	x2, x24, [sp, #0x50]
   15774:      	ldr	x8, [sp, #0x30]
   15778:      	ldr	x25, [sp, #0x8]
   1577c:      	add	x9, sp, #0x70
   15780:      	cmp	x21, x8
   15784:      	b.ne	0x15794 <generic_rawtp_path+0xb4a4>
   15788:      	ldr	x8, [sp, #0x38]
   1578c:      	cmp	x2, x8
   15790:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   15794:      	mov	w8, #0x4                // =4
   15798:      	add	x0, sp, #0x70
   1579c:      	mov	w1, #0x8                // =8
   157a0:      	blr	x8
   157a4:      	ldr	x8, [sp, #0x70]
   157a8:      	cmp	x21, x8
   157ac:      	b.eq	0x158a0 <generic_rawtp_path+0xb5b0>
   157b0:      	add	x23, x21, #0x18
   157b4:      	mov	w8, #0x4                // =4
   157b8:      	add	x9, sp, #0x98
   157bc:      	add	x0, sp, #0x98
   157c0:      	mov	w1, #0x8                // =8
   157c4:      	mov	x2, x23
   157c8:      	blr	x8
   157cc:      	ldr	x8, [sp, #0x98]
   157d0:      	cmp	x8, x21
   157d4:      	b.eq	0x158a0 <generic_rawtp_path+0xb5b0>
   157d8:      	mov	w8, #0x4                // =4
   157dc:      	add	x9, sp, #0x78
   157e0:      	add	x0, sp, #0x78
   157e4:      	mov	w1, #0x8                // =8
   157e8:      	mov	x2, x23
   157ec:      	blr	x8
   157f0:      	add	x2, x21, #0x20
   157f4:      	mov	w8, #0x4                // =4
   157f8:      	mov	w9, #0x10               // =16
   157fc:      	add	x10, sp, #0x80
   15800:      	add	x0, sp, #0x80
   15804:      	mov	w1, #0x10               // =16
   15808:      	blr	x8
   1580c:      	ldr	w21, [sp, #0x84]
   15810:      	ldr	x8, [sp, #0x40]
   15814:      	ldr	x10, [sp, #0x60]
   15818:      	sub	x12, x10, x8
   1581c:      	ldr	w23, [sp, #0x68]
   15820:      	subs	w10, w21, w23
   15824:      	ldr	x9, [sp, #0x88]
   15828:      	ldr	x25, [sp, #0x8]
   1582c:      	csel	w10, wzr, w10, lo
   15830:      	cmp	w23, w21
   15834:      	csel	w11, w23, w21, lo
   15838:      	cinc	w13, w11, hi
   1583c:      	sub	w14, w23, w13
   15840:      	subs	x12, x12, x13
   15844:      	str	w14, [sp, #0x68]
   15848:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   1584c:      	cmp	x12, #0xfff
   15850:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   15854:      	cmp	w23, w21
   15858:      	b.ls	0x15864 <generic_rawtp_path+0xb574>
   1585c:      	mov	w13, #0x2f              // =47
   15860:      	strb	w13, [x8, x12]
   15864:      	add	x19, x8, x12
   15868:      	cmp	w23, w21
   1586c:      	add	x2, x9, x10
   15870:      	and	w1, w11, #0xff
   15874:      	mov	w8, #0x4                // =4
   15878:      	cinc	x0, x19, hi
   1587c:      	blr	x8
   15880:      	ldr	x25, [sp, #0x8]
   15884:      	cmp	w23, w21
   15888:      	str	x19, [sp, #0x60]
   1588c:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   15890:      	ldr	x21, [sp, #0x78]
   15894:      	ldp	x2, x24, [sp, #0x50]
   15898:      	str	x21, [sp, #0x48]
   1589c:      	b	0x158f0 <generic_rawtp_path+0xb600>
   158a0:      	add	x2, x24, #0x10
   158a4:      	mov	w8, #0x4                // =4
   158a8:      	add	x9, sp, #0x98
   158ac:      	add	x0, sp, #0x98
   158b0:      	mov	w1, #0x8                // =8
   158b4:      	blr	x8
   158b8:      	ldr	x8, [sp, #0x58]
   158bc:      	ldr	x9, [sp, #0x98]
   158c0:      	cmp	x8, x9
   158c4:      	ldr	x25, [sp, #0x8]
   158c8:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   158cc:      	add	x2, x24, #0x18
   158d0:      	mov	w8, #0x4                // =4
   158d4:      	mov	x0, x22
   158d8:      	mov	w1, #0x8                // =8
   158dc:      	blr	x8
   158e0:      	ldr	x24, [sp, #0x98]
   158e4:      	ldr	x21, [sp, #0x48]
   158e8:      	add	x2, x24, #0x20
   158ec:      	stp	x2, x24, [sp, #0x50]
   158f0:      	ldr	x8, [sp, #0x30]
   158f4:      	ldr	x25, [sp, #0x8]
   158f8:      	add	x9, sp, #0x70
   158fc:      	cmp	x21, x8
   15900:      	b.ne	0x15910 <generic_rawtp_path+0xb620>
   15904:      	ldr	x8, [sp, #0x38]
   15908:      	cmp	x2, x8
   1590c:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   15910:      	mov	w8, #0x4                // =4
   15914:      	add	x0, sp, #0x70
   15918:      	mov	w1, #0x8                // =8
   1591c:      	blr	x8
   15920:      	ldr	x8, [sp, #0x70]
   15924:      	cmp	x21, x8
   15928:      	b.eq	0x15a1c <generic_rawtp_path+0xb72c>
   1592c:      	add	x23, x21, #0x18
   15930:      	mov	w8, #0x4                // =4
   15934:      	add	x9, sp, #0x98
   15938:      	add	x0, sp, #0x98
   1593c:      	mov	w1, #0x8                // =8
   15940:      	mov	x2, x23
   15944:      	blr	x8
   15948:      	ldr	x8, [sp, #0x98]
   1594c:      	cmp	x8, x21
   15950:      	b.eq	0x15a1c <generic_rawtp_path+0xb72c>
   15954:      	mov	w8, #0x4                // =4
   15958:      	add	x9, sp, #0x78
   1595c:      	add	x0, sp, #0x78
   15960:      	mov	w1, #0x8                // =8
   15964:      	mov	x2, x23
   15968:      	blr	x8
   1596c:      	add	x2, x21, #0x20
   15970:      	mov	w8, #0x4                // =4
   15974:      	mov	w9, #0x10               // =16
   15978:      	add	x10, sp, #0x80
   1597c:      	add	x0, sp, #0x80
   15980:      	mov	w1, #0x10               // =16
   15984:      	blr	x8
   15988:      	ldr	w21, [sp, #0x84]
   1598c:      	ldr	x8, [sp, #0x40]
   15990:      	ldr	x10, [sp, #0x60]
   15994:      	sub	x12, x10, x8
   15998:      	ldr	w23, [sp, #0x68]
   1599c:      	subs	w10, w21, w23
   159a0:      	ldr	x9, [sp, #0x88]
   159a4:      	ldr	x25, [sp, #0x8]
   159a8:      	csel	w10, wzr, w10, lo
   159ac:      	cmp	w23, w21
   159b0:      	csel	w11, w23, w21, lo
   159b4:      	cinc	w13, w11, hi
   159b8:      	sub	w14, w23, w13
   159bc:      	subs	x12, x12, x13
   159c0:      	str	w14, [sp, #0x68]
   159c4:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   159c8:      	cmp	x12, #0xfff
   159cc:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   159d0:      	cmp	w23, w21
   159d4:      	b.ls	0x159e0 <generic_rawtp_path+0xb6f0>
   159d8:      	mov	w13, #0x2f              // =47
   159dc:      	strb	w13, [x8, x12]
   159e0:      	add	x19, x8, x12
   159e4:      	cmp	w23, w21
   159e8:      	add	x2, x9, x10
   159ec:      	and	w1, w11, #0xff
   159f0:      	mov	w8, #0x4                // =4
   159f4:      	cinc	x0, x19, hi
   159f8:      	blr	x8
   159fc:      	ldr	x25, [sp, #0x8]
   15a00:      	cmp	w23, w21
   15a04:      	str	x19, [sp, #0x60]
   15a08:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   15a0c:      	ldr	x21, [sp, #0x78]
   15a10:      	ldp	x2, x24, [sp, #0x50]
   15a14:      	str	x21, [sp, #0x48]
   15a18:      	b	0x15a6c <generic_rawtp_path+0xb77c>
   15a1c:      	add	x2, x24, #0x10
   15a20:      	mov	w8, #0x4                // =4
   15a24:      	add	x9, sp, #0x98
   15a28:      	add	x0, sp, #0x98
   15a2c:      	mov	w1, #0x8                // =8
   15a30:      	blr	x8
   15a34:      	ldr	x8, [sp, #0x58]
   15a38:      	ldr	x9, [sp, #0x98]
   15a3c:      	cmp	x8, x9
   15a40:      	ldr	x25, [sp, #0x8]
   15a44:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   15a48:      	add	x2, x24, #0x18
   15a4c:      	mov	w8, #0x4                // =4
   15a50:      	mov	x0, x22
   15a54:      	mov	w1, #0x8                // =8
   15a58:      	blr	x8
   15a5c:      	ldr	x24, [sp, #0x98]
   15a60:      	ldr	x21, [sp, #0x48]
   15a64:      	add	x2, x24, #0x20
   15a68:      	stp	x2, x24, [sp, #0x50]
   15a6c:      	ldr	x8, [sp, #0x30]
   15a70:      	ldr	x25, [sp, #0x8]
   15a74:      	add	x9, sp, #0x70
   15a78:      	cmp	x21, x8
   15a7c:      	b.ne	0x15a8c <generic_rawtp_path+0xb79c>
   15a80:      	ldr	x8, [sp, #0x38]
   15a84:      	cmp	x2, x8
   15a88:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   15a8c:      	mov	w8, #0x4                // =4
   15a90:      	add	x0, sp, #0x70
   15a94:      	mov	w1, #0x8                // =8
   15a98:      	blr	x8
   15a9c:      	ldr	x8, [sp, #0x70]
   15aa0:      	cmp	x21, x8
   15aa4:      	b.eq	0x15b98 <generic_rawtp_path+0xb8a8>
   15aa8:      	add	x23, x21, #0x18
   15aac:      	mov	w8, #0x4                // =4
   15ab0:      	add	x9, sp, #0x98
   15ab4:      	add	x0, sp, #0x98
   15ab8:      	mov	w1, #0x8                // =8
   15abc:      	mov	x2, x23
   15ac0:      	blr	x8
   15ac4:      	ldr	x8, [sp, #0x98]
   15ac8:      	cmp	x8, x21
   15acc:      	b.eq	0x15b98 <generic_rawtp_path+0xb8a8>
   15ad0:      	mov	w8, #0x4                // =4
   15ad4:      	add	x9, sp, #0x78
   15ad8:      	add	x0, sp, #0x78
   15adc:      	mov	w1, #0x8                // =8
   15ae0:      	mov	x2, x23
   15ae4:      	blr	x8
   15ae8:      	add	x2, x21, #0x20
   15aec:      	mov	w8, #0x4                // =4
   15af0:      	mov	w9, #0x10               // =16
   15af4:      	add	x10, sp, #0x80
   15af8:      	add	x0, sp, #0x80
   15afc:      	mov	w1, #0x10               // =16
   15b00:      	blr	x8
   15b04:      	ldr	w21, [sp, #0x84]
   15b08:      	ldr	x8, [sp, #0x40]
   15b0c:      	ldr	x10, [sp, #0x60]
   15b10:      	sub	x12, x10, x8
   15b14:      	ldr	w23, [sp, #0x68]
   15b18:      	subs	w10, w21, w23
   15b1c:      	ldr	x9, [sp, #0x88]
   15b20:      	ldr	x25, [sp, #0x8]
   15b24:      	csel	w10, wzr, w10, lo
   15b28:      	cmp	w23, w21
   15b2c:      	csel	w11, w23, w21, lo
   15b30:      	cinc	w13, w11, hi
   15b34:      	sub	w14, w23, w13
   15b38:      	subs	x12, x12, x13
   15b3c:      	str	w14, [sp, #0x68]
   15b40:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   15b44:      	cmp	x12, #0xfff
   15b48:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   15b4c:      	cmp	w23, w21
   15b50:      	b.ls	0x15b5c <generic_rawtp_path+0xb86c>
   15b54:      	mov	w13, #0x2f              // =47
   15b58:      	strb	w13, [x8, x12]
   15b5c:      	add	x19, x8, x12
   15b60:      	cmp	w23, w21
   15b64:      	add	x2, x9, x10
   15b68:      	and	w1, w11, #0xff
   15b6c:      	mov	w8, #0x4                // =4
   15b70:      	cinc	x0, x19, hi
   15b74:      	blr	x8
   15b78:      	ldr	x25, [sp, #0x8]
   15b7c:      	cmp	w23, w21
   15b80:      	str	x19, [sp, #0x60]
   15b84:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   15b88:      	ldr	x21, [sp, #0x78]
   15b8c:      	ldp	x2, x24, [sp, #0x50]
   15b90:      	str	x21, [sp, #0x48]
   15b94:      	b	0x15be8 <generic_rawtp_path+0xb8f8>
   15b98:      	add	x2, x24, #0x10
   15b9c:      	mov	w8, #0x4                // =4
   15ba0:      	add	x9, sp, #0x98
   15ba4:      	add	x0, sp, #0x98
   15ba8:      	mov	w1, #0x8                // =8
   15bac:      	blr	x8
   15bb0:      	ldr	x8, [sp, #0x58]
   15bb4:      	ldr	x9, [sp, #0x98]
   15bb8:      	cmp	x8, x9
   15bbc:      	ldr	x25, [sp, #0x8]
   15bc0:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   15bc4:      	add	x2, x24, #0x18
   15bc8:      	mov	w8, #0x4                // =4
   15bcc:      	mov	x0, x22
   15bd0:      	mov	w1, #0x8                // =8
   15bd4:      	blr	x8
   15bd8:      	ldr	x24, [sp, #0x98]
   15bdc:      	ldr	x21, [sp, #0x48]
   15be0:      	add	x2, x24, #0x20
   15be4:      	stp	x2, x24, [sp, #0x50]
   15be8:      	ldr	x8, [sp, #0x30]
   15bec:      	ldr	x25, [sp, #0x8]
   15bf0:      	add	x9, sp, #0x70
   15bf4:      	cmp	x21, x8
   15bf8:      	b.ne	0x15c08 <generic_rawtp_path+0xb918>
   15bfc:      	ldr	x8, [sp, #0x38]
   15c00:      	cmp	x2, x8
   15c04:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   15c08:      	mov	w8, #0x4                // =4
   15c0c:      	add	x0, sp, #0x70
   15c10:      	mov	w1, #0x8                // =8
   15c14:      	blr	x8
   15c18:      	ldr	x8, [sp, #0x70]
   15c1c:      	cmp	x21, x8
   15c20:      	b.eq	0x15d10 <generic_rawtp_path+0xba20>
   15c24:      	add	x23, x21, #0x18
   15c28:      	mov	w8, #0x4                // =4
   15c2c:      	add	x9, sp, #0x98
   15c30:      	add	x0, sp, #0x98
   15c34:      	mov	w1, #0x8                // =8
   15c38:      	mov	x2, x23
   15c3c:      	blr	x8
   15c40:      	ldr	x8, [sp, #0x98]
   15c44:      	cmp	x8, x21
   15c48:      	b.eq	0x15d10 <generic_rawtp_path+0xba20>
   15c4c:      	mov	w8, #0x4                // =4
   15c50:      	add	x9, sp, #0x78
   15c54:      	add	x0, sp, #0x78
   15c58:      	mov	w1, #0x8                // =8
   15c5c:      	mov	x2, x23
   15c60:      	blr	x8
   15c64:      	add	x2, x21, #0x20
   15c68:      	mov	w8, #0x4                // =4
   15c6c:      	mov	w9, #0x10               // =16
   15c70:      	add	x10, sp, #0x80
   15c74:      	add	x0, sp, #0x80
   15c78:      	mov	w1, #0x10               // =16
   15c7c:      	blr	x8
   15c80:      	ldr	w21, [sp, #0x84]
   15c84:      	ldr	x8, [sp, #0x40]
   15c88:      	ldr	x10, [sp, #0x60]
   15c8c:      	sub	x12, x10, x8
   15c90:      	ldr	w23, [sp, #0x68]
   15c94:      	subs	w10, w21, w23
   15c98:      	ldr	x9, [sp, #0x88]
   15c9c:      	ldr	x25, [sp, #0x8]
   15ca0:      	csel	w10, wzr, w10, lo
   15ca4:      	cmp	w23, w21
   15ca8:      	csel	w11, w23, w21, lo
   15cac:      	cinc	w13, w11, hi
   15cb0:      	sub	w14, w23, w13
   15cb4:      	subs	x12, x12, x13
   15cb8:      	str	w14, [sp, #0x68]
   15cbc:      	b.lo	0x15d78 <generic_rawtp_path+0xba88>
   15cc0:      	cmp	x12, #0xfff
   15cc4:      	b.hi	0x15d78 <generic_rawtp_path+0xba88>
   15cc8:      	cmp	w23, w21
   15ccc:      	b.ls	0x15cd8 <generic_rawtp_path+0xb9e8>
   15cd0:      	mov	w13, #0x2f              // =47
   15cd4:      	strb	w13, [x8, x12]
   15cd8:      	add	x19, x8, x12
   15cdc:      	cmp	w23, w21
   15ce0:      	add	x2, x9, x10
   15ce4:      	and	w1, w11, #0xff
   15ce8:      	mov	w8, #0x4                // =4
   15cec:      	cinc	x0, x19, hi
   15cf0:      	blr	x8
   15cf4:      	ldr	x25, [sp, #0x8]
   15cf8:      	cmp	w23, w21
   15cfc:      	str	x19, [sp, #0x60]
   15d00:      	b.ls	0x15d78 <generic_rawtp_path+0xba88>
   15d04:      	ldr	x8, [sp, #0x78]
   15d08:      	str	x8, [sp, #0x48]
   15d0c:      	b	0x15d5c <generic_rawtp_path+0xba6c>
   15d10:      	add	x2, x24, #0x10
   15d14:      	mov	w8, #0x4                // =4
   15d18:      	add	x9, sp, #0x98
   15d1c:      	add	x0, sp, #0x98
   15d20:      	mov	w1, #0x8                // =8
   15d24:      	blr	x8
   15d28:      	ldr	x8, [sp, #0x58]
   15d2c:      	ldr	x9, [sp, #0x98]
   15d30:      	cmp	x8, x9
   15d34:      	ldr	x25, [sp, #0x8]
   15d38:      	b.eq	0x15d70 <generic_rawtp_path+0xba80>
   15d3c:      	add	x2, x24, #0x18
   15d40:      	mov	w8, #0x4                // =4
   15d44:      	mov	x0, x22
   15d48:      	mov	w1, #0x8                // =8
   15d4c:      	blr	x8
   15d50:      	ldr	x8, [sp, #0x98]
   15d54:      	add	x9, x8, #0x20
   15d58:      	stp	x9, x8, [sp, #0x50]
   15d5c:      	ldr	x25, [sp, #0x8]
   15d60:      	subs	w20, w20, #0x80
   15d64:      	add	x19, sp, #0x70
   15d68:      	b.ne	0xa46c <generic_rawtp_path+0x17c>
   15d6c:      	b	0x15d78 <generic_rawtp_path+0xba88>
   15d70:      	mov	w8, #0x1                // =1
   15d74:      	strb	w8, [sp, #0x6c]
   15d78:      	ldr	w8, [x25, #0x8]
   15d7c:      	ldp	x10, x20, [sp, #0x10]
   15d80:      	add	w8, w8, #0x1
   15d84:      	str	w8, [x25, #0x8]
   15d88:      	ldr	w9, [sp, #0x60]
   15d8c:      	sub	w9, w9, w10
   15d90:      	str	w9, [x25, #0x4]
   15d94:      	ldrb	w9, [sp, #0x6c]
   15d98:      	cbnz	w9, 0x15dd0 <generic_rawtp_path+0xbae0>
   15d9c:      	cmp	w8, #0x8
   15da0:      	b.eq	0x15dd0 <generic_rawtp_path+0xbae0>
   15da4:      	ldp	x8, x9, [sp, #0x48]
   15da8:      	mov	w2, #0x6                // =6
   15dac:      	str	x8, [x20, #0x6458]
   15db0:      	ldr	x8, [sp, #0x58]
   15db4:      	str	x9, [x20, #0x6460]
   15db8:      	adrp	x9, 0x15000 <generic_rawtp_path+0xad10>
   15dbc:      	str	x8, [x20, #0x6468]
   15dc0:      	mov	w8, #0xc                // =12
   15dc4:      	ldr	x9, [x9]
   15dc8:      	ldr	x0, [sp, #0x20]
   15dcc:      	b	0x15de4 <generic_rawtp_path+0xbaf4>
   15dd0:      	adrp	x9, 0x15000 <generic_rawtp_path+0xad10>
   15dd4:      	mov	w2, #0x1                // =1
   15dd8:      	mov	w8, #0xc                // =12
   15ddc:      	ldr	x9, [x9]
   15de0:      	ldr	x0, [sp, #0x20]
   15de4:      	adrp	x1, 0x15000 <generic_rawtp_path+0xad10>
   15de8:      	ldr	x1, [x1]
   15dec:      	blr	x8
   15df0:      	b	0x1618c <generic_rawtp_path+0xbe9c>
   15df4:      	str	w23, [sp, #0x98]
   15df8:      	mov	x3, xzr
   15dfc:      	mov	w8, #0x2                // =2
   15e00:      	add	x9, sp, #0x30
   15e04:      	add	x10, sp, #0x98
   15e08:      	add	x1, sp, #0x30
   15e0c:      	add	x2, sp, #0x98
   15e10:      	mov	x0, x22
   15e14:      	blr	x8
   15e18:      	ldr	x23, [sp, #0x80]
   15e1c:      	mov	w8, #0x8                // =8
   15e20:      	mov	w9, #0x4                // =4
   15e24:      	add	x10, sp, #0x30
   15e28:      	add	x0, sp, #0x30
   15e2c:      	mov	w1, #0x8                // =8
   15e30:      	add	x2, x23, #0x10
   15e34:      	blr	x9
   15e38:      	ldr	x8, [sp, #0x30]
   15e3c:      	cbnz	x8, 0x15e84 <generic_rawtp_path+0xbb94>
   15e40:      	add	x2, x23, #0x18
   15e44:      	mov	w8, #0x8                // =8
   15e48:      	mov	w9, #0x4                // =4
   15e4c:      	add	x10, sp, #0x30
   15e50:      	add	x0, sp, #0x30
   15e54:      	mov	w1, #0x8                // =8
   15e58:      	blr	x9
   15e5c:      	ldr	x8, [sp, #0x30]
   15e60:      	cmp	x8, x23
   15e64:      	b.eq	0x15e84 <generic_rawtp_path+0xbb94>
   15e68:      	adrp	x8, 0x15000 <generic_rawtp_path+0xad10>
   15e6c:      	add	x8, x8, #0x0
   15e70:      	add	x29, x21, #0xff5
   15e74:      	ldr	x8, [x8]
   15e78:      	str	x8, [x29]
   15e7c:      	mov	w8, #0x2964             // =10596
   15e80:      	strh	w8, [x29, #0x8]
   15e84:      	mov	w8, #0x23               // =35
   15e88:      	blr	x8
   15e8c:      	add	x2, x0, #0xb30
   15e90:      	mov	w8, #0x8                // =8
   15e94:      	mov	w9, #0x4                // =4
   15e98:      	add	x10, sp, #0x98
   15e9c:      	add	x0, sp, #0x98
   15ea0:      	mov	w1, #0x8                // =8
   15ea4:      	blr	x9
   15ea8:      	cbz	x0, 0x15f18 <generic_rawtp_path+0xbc28>
   15eac:      	neg	w8, w0
   15eb0:      	mov	w9, #0x1                // =1
   15eb4:      	add	x1, sp, #0x30
   15eb8:      	strh	w8, [sp, #0x30]
   15ebc:      	mov	w8, #0x6                // =6
   15ec0:      	mov	x0, x22
   15ec4:      	mov	w23, #0x1               // =1
   15ec8:      	strh	w8, [sp, #0x32]
   15ecc:      	mov	x8, #0x33               // =51
   15ed0:      	movk	x8, #0x4, lsl #32
   15ed4:      	stur	x8, [sp, #0x34]
   15ed8:      	add	x8, sp, #0x30
   15edc:      	blr	x9
   15ee0:      	cbz	x0, 0x15ef4 <generic_rawtp_path+0xbc04>
   15ee4:      	ldr	w8, [x0]
   15ee8:      	add	w8, w8, #0x1
   15eec:      	str	w8, [x0]
   15ef0:      	b	0x15f18 <generic_rawtp_path+0xbc28>
   15ef4:      	str	w23, [sp, #0x78]
   15ef8:      	mov	x3, xzr
   15efc:      	mov	w8, #0x2                // =2
   15f00:      	add	x9, sp, #0x30
   15f04:      	add	x10, sp, #0x78
   15f08:      	add	x1, sp, #0x30
   15f0c:      	add	x2, sp, #0x78
   15f10:      	mov	x0, x22
   15f14:      	blr	x8
   15f18:      	ldr	x8, [sp, #0x98]
   15f1c:      	mov	w9, #0x6448             // =25672
   15f20:      	ldr	x23, [x20, #0x6440]
   15f24:      	mov	w1, #0x8                // =8
   15f28:      	add	x0, x20, x9
   15f2c:      	mov	w9, #0x4                // =4
   15f30:      	add	x24, x8, #0x18
   15f34:      	add	x2, x8, #0x20
   15f38:      	mov	w8, #0x8                // =8
   15f3c:      	blr	x9
   15f40:      	cbz	x0, 0x15fb0 <generic_rawtp_path+0xbcc0>
   15f44:      	neg	w8, w0
   15f48:      	mov	w9, #0x1                // =1
   15f4c:      	add	x1, sp, #0x30
   15f50:      	strh	w8, [sp, #0x30]
   15f54:      	mov	w8, #0x6                // =6
   15f58:      	mov	x0, x22
   15f5c:      	mov	w19, #0x1               // =1
   15f60:      	strh	w8, [sp, #0x32]
   15f64:      	mov	x8, #0x38               // =56
   15f68:      	movk	x8, #0x4, lsl #32
   15f6c:      	stur	x8, [sp, #0x34]
   15f70:      	add	x8, sp, #0x30
   15f74:      	blr	x9
   15f78:      	cbz	x0, 0x15f8c <generic_rawtp_path+0xbc9c>
   15f7c:      	ldr	w8, [x0]
   15f80:      	add	w8, w8, #0x1
   15f84:      	str	w8, [x0]
   15f88:      	b	0x15fb0 <generic_rawtp_path+0xbcc0>
   15f8c:      	str	w19, [sp, #0x78]
   15f90:      	mov	x3, xzr
   15f94:      	mov	w8, #0x2                // =2
   15f98:      	add	x9, sp, #0x30
   15f9c:      	add	x10, sp, #0x78
   15fa0:      	add	x1, sp, #0x30
   15fa4:      	add	x2, sp, #0x78
   15fa8:      	mov	x0, x22
   15fac:      	blr	x8
   15fb0:      	mov	w8, #0x6450             // =25680
   15fb4:      	mov	w9, #0x4                // =4
   15fb8:      	mov	w1, #0x8                // =8
   15fbc:      	mov	x2, x24
   15fc0:      	add	x0, x20, x8
   15fc4:      	mov	w8, #0x8                // =8
   15fc8:      	blr	x9
   15fcc:      	cbz	x0, 0x1603c <generic_rawtp_path+0xbd4c>
   15fd0:      	neg	w8, w0
   15fd4:      	mov	w9, #0x1                // =1
   15fd8:      	add	x1, sp, #0x30
   15fdc:      	strh	w8, [sp, #0x30]
   15fe0:      	mov	w8, #0x6                // =6
   15fe4:      	mov	x0, x22
   15fe8:      	mov	w19, #0x1               // =1
   15fec:      	strh	w8, [sp, #0x32]
   15ff0:      	mov	x8, #0x39               // =57
   15ff4:      	movk	x8, #0x4, lsl #32
   15ff8:      	stur	x8, [sp, #0x34]
   15ffc:      	add	x8, sp, #0x30
   16000:      	blr	x9
   16004:      	cbz	x0, 0x16018 <generic_rawtp_path+0xbd28>
   16008:      	ldr	w8, [x0]
   1600c:      	add	w8, w8, #0x1
   16010:      	str	w8, [x0]
   16014:      	b	0x1603c <generic_rawtp_path+0xbd4c>
   16018:      	str	w19, [sp, #0x78]
   1601c:      	mov	x3, xzr
   16020:      	mov	w8, #0x2                // =2
   16024:      	add	x9, sp, #0x30
   16028:      	add	x10, sp, #0x78
   1602c:      	add	x1, sp, #0x30
   16030:      	add	x2, sp, #0x78
   16034:      	mov	x0, x22
   16038:      	blr	x8
   1603c:      	mov	w8, #0x6458             // =25688
   16040:      	add	x2, x23, #0x8
   16044:      	mov	w9, #0x4                // =4
   16048:      	mov	w1, #0x8                // =8
   1604c:      	add	x0, x20, x8
   16050:      	mov	w8, #0x8                // =8
   16054:      	blr	x9
   16058:      	cbz	x0, 0x160c8 <generic_rawtp_path+0xbdd8>
   1605c:      	neg	w8, w0
   16060:      	mov	w9, #0x1                // =1
   16064:      	add	x1, sp, #0x30
   16068:      	strh	w8, [sp, #0x30]
   1606c:      	mov	w8, #0x6                // =6
   16070:      	mov	x0, x22
   16074:      	mov	w19, #0x1               // =1
   16078:      	strh	w8, [sp, #0x32]
   1607c:      	mov	x8, #0x3a               // =58
   16080:      	movk	x8, #0x4, lsl #32
   16084:      	stur	x8, [sp, #0x34]
   16088:      	add	x8, sp, #0x30
   1608c:      	blr	x9
   16090:      	cbz	x0, 0x160a4 <generic_rawtp_path+0xbdb4>
   16094:      	ldr	w8, [x0]
   16098:      	add	w8, w8, #0x1
   1609c:      	str	w8, [x0]
   160a0:      	b	0x160c8 <generic_rawtp_path+0xbdd8>
   160a4:      	str	w19, [sp, #0x78]
   160a8:      	mov	x3, xzr
   160ac:      	mov	w8, #0x2                // =2
   160b0:      	add	x9, sp, #0x30
   160b4:      	add	x10, sp, #0x78
   160b8:      	add	x1, sp, #0x30
   160bc:      	add	x2, sp, #0x78
   160c0:      	mov	x0, x22
   160c4:      	blr	x8
   160c8:      	mov	w8, #0x6460             // =25696
   160cc:      	mov	w9, #0x4                // =4
   160d0:      	mov	w1, #0x8                // =8
   160d4:      	mov	x2, x23
   160d8:      	add	x0, x20, x8
   160dc:      	mov	w8, #0x8                // =8
   160e0:      	blr	x9
   160e4:      	cbz	x0, 0x16154 <generic_rawtp_path+0xbe64>
   160e8:      	neg	w8, w0
   160ec:      	mov	w9, #0x1                // =1
   160f0:      	add	x1, sp, #0x30
   160f4:      	strh	w8, [sp, #0x30]
   160f8:      	mov	w8, #0x6                // =6
   160fc:      	mov	x0, x22
   16100:      	mov	w19, #0x1               // =1
   16104:      	strh	w8, [sp, #0x32]
   16108:      	mov	x8, #0x3b               // =59
   1610c:      	movk	x8, #0x4, lsl #32
   16110:      	stur	x8, [sp, #0x34]
   16114:      	add	x8, sp, #0x30
   16118:      	blr	x9
   1611c:      	cbz	x0, 0x16130 <generic_rawtp_path+0xbe40>
   16120:      	ldr	w8, [x0]
   16124:      	add	w8, w8, #0x1
   16128:      	str	w8, [x0]
   1612c:      	b	0x16154 <generic_rawtp_path+0xbe64>
   16130:      	str	w19, [sp, #0x78]
   16134:      	mov	x3, xzr
   16138:      	mov	w8, #0x2                // =2
   1613c:      	add	x9, sp, #0x30
   16140:      	add	x10, sp, #0x78
   16144:      	add	x1, sp, #0x30
   16148:      	add	x2, sp, #0x78
   1614c:      	mov	x0, x22
   16150:      	blr	x8
   16154:      	ldr	x8, [x20, #0x6460]
   16158:      	mov	w9, #0x1                // =1
   1615c:      	adrp	x1, 0x16000 <generic_rawtp_path+0xbd10>
   16160:      	mov	w2, #0x6                // =6
   16164:      	str	w9, [x25]
   16168:      	mov	w9, #0xc                // =12
   1616c:      	sub	x8, x8, #0x20
   16170:      	str	x8, [x20, #0x6468]
   16174:      	sub	w8, w29, w21
   16178:      	stp	w8, wzr, [x25, #0x4]
   1617c:      	mov	w8, #0x6                // =6
   16180:      	ldr	x1, [x1]
   16184:      	ldr	x0, [sp, #0x20]
   16188:      	blr	x9
   1618c:      	ldp	x20, x19, [sp, #0xd0]
   16190:      	mov	w0, wzr
   16194:      	ldr	x29, [sp, #0x90]
   16198:      	ldp	x22, x21, [sp, #0xc0]
   1619c:      	ldp	x24, x23, [sp, #0xb0]
   161a0:      	ldp	x30, x25, [sp, #0xa0]
   161a4:      	add	sp, sp, #0xe0
   161a8:      	ret

Disassembly of section raw_tp/generic_tracepoint:

0000000000000000 <generic_rawtp_event>:
       0:      	sub	sp, sp, #0xd0
       4:      	stp	x30, x25, [sp, #0x90]
       8:      	stp	x24, x23, [sp, #0xa0]
       c:      	stp	x22, x21, [sp, #0xb0]
      10:      	stp	x20, x19, [sp, #0xc0]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0xc]
      1c:      	adrp	x0, 0x0 <generic_rawtp_event>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0xc
      2c:      	add	x1, sp, #0xc
      30:      	blr	x8
      34:      	cbz	x0, 0x540 <generic_rawtp_event+0x540>
      38:      	mov	w8, #0x5ef8             // =24312
      3c:      	mov	x20, x0
      40:      	add	x21, x0, x8
      44:      	adrp	x0, 0x0 <generic_rawtp_event>
      48:      	mov	w8, #0x1                // =1
      4c:      	str	wzr, [x21]
      50:      	mov	x1, x21
      54:      	ldr	x0, [x0]
      58:      	blr	x8
      5c:      	cbz	x0, 0x540 <generic_rawtp_event+0x540>
      60:      	ldr	w8, [x0, #0x64]
      64:      	str	w8, [sp, #0x1c]
      68:      	cbz	w8, 0x224 <generic_rawtp_event+0x224>
      6c:      	adrp	x22, 0x0 <generic_rawtp_event>
      70:      	mov	w8, #0x1                // =1
      74:      	add	x9, sp, #0x1c
      78:      	ldr	x22, [x22]
      7c:      	mov	x24, x0
      80:      	add	x1, sp, #0x1c
      84:      	mov	x0, x22
      88:      	blr	x8
      8c:      	cbz	x0, 0x540 <generic_rawtp_event+0x540>
      90:      	mov	x23, x0
      94:      	str	wzr, [sp, #0x84]
      98:      	adrp	x0, 0x0 <generic_rawtp_event>
      9c:      	mov	w8, #0x1                // =1
      a0:      	ldr	x0, [x0]
      a4:      	add	x9, sp, #0x84
      a8:      	add	x1, sp, #0x84
      ac:      	blr	x8
      b0:      	cbz	x0, 0xdc <generic_rawtp_event+0xdc>
      b4:      	ldr	x8, [x0, #0x20]
      b8:      	mov	w9, #0x7270             // =29296
      bc:      	movk	w9, #0x6367, lsl #16
      c0:      	cmp	x8, x9
      c4:      	b.ne	0xe4 <generic_rawtp_event+0xe4>
      c8:      	mov	w8, #0x50               // =80
      cc:      	blr	x8
      d0:      	str	x0, [sp, #0x30]
      d4:      	cbnz	x0, 0x1d8 <generic_rawtp_event+0x1d8>
      d8:      	b	0x540 <generic_rawtp_event+0x540>
      dc:      	mov	w25, wzr
      e0:      	b	0xe8 <generic_rawtp_event+0xe8>
      e4:      	ldr	w25, [x0, #0x10]
      e8:      	mov	w8, #0x23               // =35
      ec:      	blr	x8
      f0:      	str	xzr, [sp, #0x88]
      f4:      	add	x2, x0, #0xcd0
      f8:      	mov	w8, #0x8                // =8
      fc:      	mov	w9, #0x71               // =113
     100:      	add	x10, sp, #0x20
     104:      	add	x0, sp, #0x20
     108:      	mov	w1, #0x8                // =8
     10c:      	blr	x9
     110:      	ldr	x8, [sp, #0x20]
     114:      	cbz	x8, 0x540 <generic_rawtp_event+0x540>
     118:      	cmp	w25, #0xb
     11c:      	b.hi	0x540 <generic_rawtp_event+0x540>
     120:      	ubfiz	x9, x25, #3, #32
     124:      	mov	w10, #0x8               // =8
     128:      	mov	w11, #0x71              // =113
     12c:      	add	x12, sp, #0x38
     130:      	add	x0, sp, #0x38
     134:      	mov	w1, #0x8                // =8
     138:      	add	x8, x8, x9
     13c:      	ldr	x8, [sp, #0x20]
     140:      	add	x2, x8, x9
     144:      	blr	x11
     148:      	ldr	x8, [sp, #0x38]
     14c:      	cbz	x8, 0x540 <generic_rawtp_event+0x540>
     150:      	mov	w9, #0x8                // =8
     154:      	mov	w10, #0x71              // =113
     158:      	add	x11, sp, #0x88
     15c:      	ldr	x2, [sp, #0x38]
     160:      	add	x0, sp, #0x88
     164:      	mov	w1, #0x8                // =8
     168:      	blr	x10
     16c:      	ldr	x8, [sp, #0x88]
     170:      	cbz	x8, 0x540 <generic_rawtp_event+0x540>
     174:      	str	xzr, [sp, #0x38]
     178:      	add	x2, x8, #0x100
     17c:      	mov	w8, #0x8                // =8
     180:      	mov	w9, #0x71               // =113
     184:      	add	x10, sp, #0x38
     188:      	add	x0, sp, #0x38
     18c:      	mov	w1, #0x8                // =8
     190:      	blr	x9
     194:      	ldr	x8, [sp, #0x38]
     198:      	str	xzr, [sp, #0x38]
     19c:      	cbz	x8, 0x1cc <generic_rawtp_event+0x1cc>
     1a0:      	add	x2, x8, #0x60
     1a4:      	mov	w8, #0x8                // =8
     1a8:      	mov	w9, #0x71               // =113
     1ac:      	add	x10, sp, #0x38
     1b0:      	add	x0, sp, #0x38
     1b4:      	mov	w1, #0x8                // =8
     1b8:      	blr	x9
     1bc:      	ldr	x0, [sp, #0x38]
     1c0:      	str	x0, [sp, #0x30]
     1c4:      	cbnz	x0, 0x1d8 <generic_rawtp_event+0x1d8>
     1c8:      	b	0x540 <generic_rawtp_event+0x540>
     1cc:      	mov	x0, xzr
     1d0:      	str	xzr, [sp, #0x30]
     1d4:      	cbz	xzr, 0x540 <generic_rawtp_event+0x540>
     1d8:      	str	x0, [sp, #0x38]
     1dc:      	adrp	x0, 0x0 <generic_rawtp_event>
     1e0:      	mov	w8, #0x1                // =1
     1e4:      	add	x9, sp, #0x38
     1e8:      	ldr	x0, [x0]
     1ec:      	add	x1, sp, #0x38
     1f0:      	blr	x8
     1f4:      	cbz	x0, 0x204 <generic_rawtp_event+0x204>
     1f8:      	ldr	x8, [x0]
     1fc:      	cbz	x8, 0x204 <generic_rawtp_event+0x204>
     200:      	str	x8, [sp, #0x30]
     204:      	mov	w8, #0x1                // =1
     208:      	add	x9, sp, #0x30
     20c:      	add	x1, sp, #0x30
     210:      	mov	x0, x23
     214:      	blr	x8
     218:      	mov	x8, x0
     21c:      	mov	x0, x24
     220:      	cbz	x8, 0x55c <generic_rawtp_event+0x55c>
     224:      	ldr	w9, [x0]
     228:      	mov	w8, #0x6420             // =25632
     22c:      	stur	xzr, [x21, #0x4]
     230:      	str	xzr, [x20, #0x5eb8]
     234:      	str	xzr, [x20, #0x5ec0]
     238:      	str	wzr, [x20, x8]
     23c:      	mov	w8, #0x23               // =35
     240:      	str	xzr, [x20, #0x5ec8]
     244:      	str	xzr, [x20, #0x5ed0]
     248:      	str	xzr, [x20, #0x5ed8]
     24c:      	stp	x9, xzr, [x20, #0x60]
     250:      	mov	w9, #0x5eb8             // =24248
     254:      	add	x9, x20, x9
     258:      	strb	wzr, [x9, #0x28]
     25c:      	blr	x8
     260:      	add	x2, x0, #0xb50
     264:      	mov	w25, #0x8               // =8
     268:      	add	x8, sp, #0x88
     26c:      	mov	w9, #0x4                // =4
     270:      	mov	x22, x0
     274:      	add	x0, sp, #0x88
     278:      	mov	w1, #0x8                // =8
     27c:      	add	x23, x20, #0x20
     280:      	mov	w24, #0x4               // =4
     284:      	blr	x9
     288:      	ldr	x8, [sp, #0x88]
     28c:      	mov	w9, #0x48               // =72
     290:      	add	x10, sp, #0x38
     294:      	mov	w11, #0x4               // =4
     298:      	ldr	x2, [sp, #0x88]
     29c:      	add	x0, sp, #0x38
     2a0:      	mov	w1, #0x48               // =72
     2a4:      	blr	x11
     2a8:      	ldr	x8, [sp, #0x40]
     2ac:      	mov	w9, #0x4                // =4
     2b0:      	mov	x0, x23
     2b4:      	mov	w1, #0x4                // =4
     2b8:      	add	x8, x8, #0x218
     2bc:      	ldr	x8, [sp, #0x40]
     2c0:      	add	x2, x8, #0x218
     2c4:      	blr	x9
     2c8:      	ldr	x8, [sp, #0x48]
     2cc:      	add	x0, x20, #0x24
     2d0:      	mov	w9, #0x4                // =4
     2d4:      	mov	w1, #0x4                // =4
     2d8:      	add	x8, x8, #0x4d8
     2dc:      	ldr	x8, [sp, #0x48]
     2e0:      	add	x2, x8, #0x4d8
     2e4:      	blr	x9
     2e8:      	ldr	x8, [sp, #0x50]
     2ec:      	add	x0, x20, #0x28
     2f0:      	mov	w9, #0x4                // =4
     2f4:      	mov	w1, #0x4                // =4
     2f8:      	add	x8, x8, #0x58
     2fc:      	ldr	x8, [sp, #0x50]
     300:      	add	x2, x8, #0x58
     304:      	blr	x9
     308:      	str	xzr, [sp, #0x30]
     30c:      	add	x2, x22, #0x938
     310:      	add	x8, sp, #0x30
     314:      	add	x0, sp, #0x30
     318:      	mov	w1, #0x8                // =8
     31c:      	blr	x24
     320:      	ldr	x8, [sp, #0x30]
     324:      	cbz	x8, 0x3a8 <generic_rawtp_event+0x3a8>
     328:      	str	wzr, [sp, #0x10]
     32c:      	add	x8, x8, #0x4
     330:      	add	x9, sp, #0x10
     334:      	mov	w10, #0x4               // =4
     338:      	add	x0, sp, #0x10
     33c:      	mov	w1, #0x4                // =4
     340:      	mov	w23, #0x4               // =4
     344:      	ldr	x8, [sp, #0x30]
     348:      	add	x2, x8, #0x4
     34c:      	blr	x10
     350:      	ldr	x8, [sp, #0x30]
     354:      	ldrsw	x9, [sp, #0x10]
     358:      	add	x10, sp, #0x20
     35c:      	mov	w11, #0x4               // =4
     360:      	add	x0, sp, #0x20
     364:      	mov	w1, #0x10               // =16
     368:      	add	x8, x8, x9, lsl #4
     36c:      	mov	w9, #0x10               // =16
     370:      	add	x8, x8, #0x80
     374:      	ldr	x8, [sp, #0x30]
     378:      	ldrsw	x9, [sp, #0x10]
     37c:      	add	x8, x8, x9, lsl #4
     380:      	add	x2, x8, #0x80
     384:      	blr	x11
     388:      	ldr	x8, [sp, #0x28]
     38c:      	add	x0, x20, #0x2c
     390:      	mov	w1, #0x4                // =4
     394:      	add	x8, x8, #0x158
     398:      	ldr	x8, [sp, #0x28]
     39c:      	add	x2, x8, #0x158
     3a0:      	blr	x23
     3a4:      	b	0x3ac <generic_rawtp_event+0x3ac>
     3a8:      	str	wzr, [x20, #0x2c]
     3ac:      	ldr	x8, [sp, #0x58]
     3b0:      	add	x0, x20, #0x30
     3b4:      	mov	w9, #0x4                // =4
     3b8:      	mov	w1, #0x4                // =4
     3bc:      	mov	w24, #0x4               // =4
     3c0:      	add	x8, x8, #0x158
     3c4:      	ldr	x8, [sp, #0x58]
     3c8:      	add	x2, x8, #0x158
     3cc:      	blr	x9
     3d0:      	ldr	x8, [sp, #0x60]
     3d4:      	add	x0, x20, #0x34
     3d8:      	mov	w9, #0x4                // =4
     3dc:      	mov	w1, #0x4                // =4
     3e0:      	add	x8, x8, #0x118
     3e4:      	ldr	x8, [sp, #0x60]
     3e8:      	add	x2, x8, #0x118
     3ec:      	blr	x9
     3f0:      	ldr	x8, [sp, #0x68]
     3f4:      	add	x0, x20, #0x38
     3f8:      	mov	w9, #0x4                // =4
     3fc:      	mov	w1, #0x4                // =4
     400:      	add	x8, x8, #0x98
     404:      	ldr	x8, [sp, #0x68]
     408:      	add	x2, x8, #0x98
     40c:      	blr	x9
     410:      	ldr	x8, [sp, #0x70]
     414:      	add	x0, x20, #0x3c
     418:      	mov	w9, #0x4                // =4
     41c:      	mov	w1, #0x4                // =4
     420:      	add	x8, x8, #0x98
     424:      	ldr	x8, [sp, #0x70]
     428:      	add	x2, x8, #0x98
     42c:      	blr	x9
     430:      	ldr	x8, [sp, #0x78]
     434:      	add	x0, x20, #0x40
     438:      	mov	w9, #0x4                // =4
     43c:      	mov	w1, #0x4                // =4
     440:      	add	x8, x8, #0x58
     444:      	ldr	x8, [sp, #0x78]
     448:      	add	x2, x8, #0x58
     44c:      	blr	x9
     450:      	str	xzr, [sp, #0x20]
     454:      	str	xzr, [sp, #0x30]
     458:      	add	x22, x22, #0xae0
     45c:      	mov	w25, #0x8               // =8
     460:      	add	x8, sp, #0x20
     464:      	mov	w9, #0x4                // =4
     468:      	add	x0, sp, #0x20
     46c:      	mov	w1, #0x8                // =8
     470:      	mov	x2, x22
     474:      	blr	x9
     478:      	ldr	x8, [sp, #0x20]
     47c:      	add	x9, sp, #0x30
     480:      	mov	w10, #0x4               // =4
     484:      	add	x0, sp, #0x30
     488:      	mov	w1, #0x8                // =8
     48c:      	add	x8, x8, #0x90
     490:      	ldr	x8, [sp, #0x20]
     494:      	add	x2, x8, #0x90
     498:      	blr	x10
     49c:      	ldr	x8, [sp, #0x30]
     4a0:      	add	x0, x20, #0x44
     4a4:      	mov	w9, #0x4                // =4
     4a8:      	mov	w1, #0x4                // =4
     4ac:      	add	x8, x8, #0x158
     4b0:      	ldr	x8, [sp, #0x30]
     4b4:      	add	x2, x8, #0x158
     4b8:      	blr	x9
     4bc:      	add	x8, sp, #0x38
     4c0:      	mov	w9, #0x4                // =4
     4c4:      	add	x0, sp, #0x38
     4c8:      	mov	w1, #0x8                // =8
     4cc:      	mov	x2, x22
     4d0:      	add	x23, x20, #0x48
     4d4:      	blr	x9
     4d8:      	ldr	x22, [sp, #0x38]
     4dc:      	add	x0, x20, #0x50
     4e0:      	mov	w8, #0x4                // =4
     4e4:      	mov	w1, #0x8                // =8
     4e8:      	add	x2, x22, #0x40
     4ec:      	blr	x8
     4f0:      	add	x0, x20, #0x58
     4f4:      	add	x2, x22, #0x30
     4f8:      	mov	w8, #0x4                // =4
     4fc:      	mov	w1, #0x8                // =8
     500:      	blr	x8
     504:      	add	x2, x22, #0x38
     508:      	mov	x0, x23
     50c:      	mov	w1, #0x8                // =8
     510:      	blr	x24
     514:      	strb	wzr, [x21, #0x10]
     518:      	strb	wzr, [x20, #0x1]
     51c:      	adrp	x1, 0x0 <generic_rawtp_event>
     520:      	mov	w8, #0x2                // =2
     524:      	mov	w9, #0xc                // =12
     528:      	mov	x0, x19
     52c:      	str	xzr, [x20, #0x5ee8]
     530:      	str	xzr, [x20, #0x5ef0]
     534:      	ldr	x1, [x1]
     538:      	mov	w2, #0x2                // =2
     53c:      	blr	x9
     540:      	ldp	x20, x19, [sp, #0xc0]
     544:      	mov	w0, wzr
     548:      	ldp	x22, x21, [sp, #0xb0]
     54c:      	ldp	x24, x23, [sp, #0xa0]
     550:      	ldp	x30, x25, [sp, #0x90]
     554:      	add	sp, sp, #0xd0
     558:      	ret
     55c:      	mov	x8, #-0x1               // =-1
     560:      	mov	w9, #0x1                // =1
     564:      	add	x1, sp, #0x10
     568:      	str	x8, [sp, #0x10]
     56c:      	add	x8, sp, #0x10
     570:      	mov	x0, x23
     574:      	mov	w25, #0x1               // =1
     578:      	blr	x9
     57c:      	cbz	x0, 0x540 <generic_rawtp_event+0x540>
     580:      	str	w25, [sp, #0x1c]
     584:      	add	x8, sp, #0x1c
     588:      	add	x1, sp, #0x1c
     58c:      	mov	x0, x22
     590:      	blr	x25
     594:      	cbz	x0, 0x540 <generic_rawtp_event+0x540>
     598:      	mov	w8, #0x1                // =1
     59c:      	add	x9, sp, #0x30
     5a0:      	add	x1, sp, #0x30
     5a4:      	blr	x8
     5a8:      	mov	x8, x0
     5ac:      	mov	x0, x24
     5b0:      	cbnz	x8, 0x540 <generic_rawtp_event+0x540>
     5b4:      	b	0x224 <generic_rawtp_event+0x224>
