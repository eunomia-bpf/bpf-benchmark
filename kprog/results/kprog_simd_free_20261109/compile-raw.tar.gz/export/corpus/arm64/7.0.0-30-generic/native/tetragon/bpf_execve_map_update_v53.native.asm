
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_execve_map_update_v53.native.o:	file format elf64-littleaarch64

Disassembly of section socket:

0000000000000000 <execve_map_update>:
       0:      	sub	sp, sp, #0x40
       4:      	stp	x30, x23, [sp, #0x10]
       8:      	stp	x22, x21, [sp, #0x20]
       c:      	stp	x20, x19, [sp, #0x30]
      10:      	str	wzr, [sp, #0x8]
      14:      	adrp	x0, 0x0 <execve_map_update>
      18:      	add	x8, sp, #0x8
      1c:      	mov	w9, #0x1                // =1
      20:      	ldr	x0, [x0]
      24:      	add	x1, sp, #0x8
      28:      	mov	w21, #0x1               // =1
      2c:      	blr	x9
      30:      	cbz	x0, 0xbc <execve_map_update+0xbc>
      34:      	adrp	x20, 0x0 <execve_map_update>
      38:      	mov	x19, x0
      3c:      	mov	x22, xzr
      40:      	ldr	x20, [x20]
      44:      	add	x23, sp, #0xc
      48:      	b	0x58 <execve_map_update+0x58>
      4c:      	add	x22, x22, #0x1
      50:      	cmp	x22, #0x400
      54:      	b.eq	0xa4 <execve_map_update+0xa4>
      58:      	ldr	w8, [x19, #0x4]
      5c:      	cmp	x22, x8
      60:      	b.eq	0xa4 <execve_map_update+0xa4>
      64:      	add	x8, x19, x22, lsl #2
      68:      	add	x1, sp, #0xc
      6c:      	mov	x0, x20
      70:      	ldr	w8, [x8, #0x8]
      74:      	str	w8, [sp, #0xc]
      78:      	mov	w8, #0x1                // =1
      7c:      	blr	x8
      80:      	cbz	x0, 0x4c <execve_map_update+0x4c>
      84:      	ldr	w8, [x19]
      88:      	ldr	x9, [x0, #0x370]
      8c:      	lsl	w8, w21, w8
      90:      	mvn	w8, w8
      94:      	sxtw	x8, w8
      98:      	and	x8, x9, x8
      9c:      	str	x8, [x0, #0x370]
      a0:      	b	0x4c <execve_map_update+0x4c>
      a4:      	mov	w0, wzr
      a8:      	ldp	x20, x19, [sp, #0x30]
      ac:      	ldp	x22, x21, [sp, #0x20]
      b0:      	ldp	x30, x23, [sp, #0x10]
      b4:      	add	sp, sp, #0x40
      b8:      	ret
      bc:      	mov	w0, #-0x1               // =-1
      c0:      	ldp	x20, x19, [sp, #0x30]
      c4:      	ldp	x22, x21, [sp, #0x20]
      c8:      	ldp	x30, x23, [sp, #0x10]
      cc:      	add	sp, sp, #0x40
      d0:      	ret
