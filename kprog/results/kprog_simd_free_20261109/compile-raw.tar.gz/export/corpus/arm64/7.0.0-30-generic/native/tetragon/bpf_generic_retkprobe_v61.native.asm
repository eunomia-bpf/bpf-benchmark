
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_retkprobe_v61.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <filter_64ty>:
       0:      	str	x30, [sp, #-0x10]!
       4:      	mov	x8, x0
       8:      	mov	x0, xzr
       c:      	ldr	w9, [x8, #0x4]
      10:      	cmp	w9, #0x20
      14:      	b.hi	0x74 <filter_64ty+0x74>
      18:      	mov	w10, #0x1               // =1
      1c:      	mov	w11, #0x101e            // =4126
      20:      	lsl	x10, x10, x9
      24:      	tst	x10, x11
      28:      	b.eq	0x3c <filter_64ty+0x3c>
      2c:      	mov	x0, x8
      30:      	bl	0x200 <filter_64ty_selector_val>
      34:      	ldr	x30, [sp], #0x10
      38:      	ret
      3c:      	mov	w10, #0x1               // =1
      40:      	lsl	x10, x10, x9
      44:      	tst	x10, #0xc00
      48:      	b.ne	0x6c <filter_64ty+0x6c>
      4c:      	mov	w10, #0x1               // =1
      50:      	lsl	x9, x10, x9
      54:      	tst	x9, #0x180000000
      58:      	b.eq	0x74 <filter_64ty+0x74>
      5c:      	mov	x0, x8
      60:      	bl	0x600 <filter_64ty_range>
      64:      	ldr	x30, [sp], #0x10
      68:      	ret
      6c:      	mov	x0, x8
      70:      	bl	0x560 <filter_64ty_map>
      74:      	ldr	x30, [sp], #0x10
      78:      	ret
      7c:      	nop

0000000000000080 <filter_32ty>:
      80:      	str	x30, [sp, #-0x10]!
      84:      	mov	x8, x0
      88:      	mov	x0, xzr
      8c:      	ldr	w9, [x8, #0x4]
      90:      	cmp	w9, #0x20
      94:      	b.hi	0xf4 <filter_32ty+0x74>
      98:      	mov	w10, #0x1               // =1
      9c:      	mov	w11, #0x101e            // =4126
      a0:      	lsl	x10, x10, x9
      a4:      	tst	x10, x11
      a8:      	b.eq	0xbc <filter_32ty+0x3c>
      ac:      	mov	x0, x8
      b0:      	bl	0x850 <filter_32ty_selector_val>
      b4:      	ldr	x30, [sp], #0x10
      b8:      	ret
      bc:      	mov	w10, #0x1               // =1
      c0:      	lsl	x10, x10, x9
      c4:      	tst	x10, #0xc00
      c8:      	b.ne	0xec <filter_32ty+0x6c>
      cc:      	mov	w10, #0x1               // =1
      d0:      	lsl	x9, x10, x9
      d4:      	tst	x9, #0x180000000
      d8:      	b.eq	0xf4 <filter_32ty+0x74>
      dc:      	mov	x0, x8
      e0:      	bl	0xc70 <filter_32ty_range>
      e4:      	ldr	x30, [sp], #0x10
      e8:      	ret
      ec:      	mov	x0, x8
      f0:      	bl	0xbb0 <filter_32ty_map>
      f4:      	ldr	x30, [sp], #0x10
      f8:      	ret
      fc:      	nop

0000000000000100 <filter_16ty>:
     100:      	str	x30, [sp, #-0x10]!
     104:      	mov	x8, x0
     108:      	mov	x0, xzr
     10c:      	ldr	w9, [x8, #0x4]
     110:      	cmp	w9, #0x20
     114:      	b.hi	0x174 <filter_16ty+0x74>
     118:      	mov	w10, #0x1               // =1
     11c:      	mov	w11, #0x101e            // =4126
     120:      	lsl	x10, x10, x9
     124:      	tst	x10, x11
     128:      	b.eq	0x13c <filter_16ty+0x3c>
     12c:      	mov	x0, x8
     130:      	bl	0xec0 <filter_16ty_selector_val>
     134:      	ldr	x30, [sp], #0x10
     138:      	ret
     13c:      	mov	w10, #0x1               // =1
     140:      	lsl	x10, x10, x9
     144:      	tst	x10, #0xc00
     148:      	b.ne	0x16c <filter_16ty+0x6c>
     14c:      	mov	w10, #0x1               // =1
     150:      	lsl	x9, x10, x9
     154:      	tst	x9, #0x180000000
     158:      	b.eq	0x174 <filter_16ty+0x74>
     15c:      	mov	x0, x8
     160:      	bl	0x12e0 <filter_16ty_range>
     164:      	ldr	x30, [sp], #0x10
     168:      	ret
     16c:      	mov	x0, x8
     170:      	bl	0x1220 <filter_16ty_map>
     174:      	ldr	x30, [sp], #0x10
     178:      	ret
     17c:      	nop

0000000000000180 <filter_8ty>:
     180:      	str	x30, [sp, #-0x10]!
     184:      	mov	x8, x0
     188:      	mov	x0, xzr
     18c:      	ldr	w9, [x8, #0x4]
     190:      	cmp	w9, #0x20
     194:      	b.hi	0x1f4 <filter_8ty+0x74>
     198:      	mov	w10, #0x1               // =1
     19c:      	mov	w11, #0x101e            // =4126
     1a0:      	lsl	x10, x10, x9
     1a4:      	tst	x10, x11
     1a8:      	b.eq	0x1bc <filter_8ty+0x3c>
     1ac:      	mov	x0, x8
     1b0:      	bl	0x1530 <filter_8ty_selector_val>
     1b4:      	ldr	x30, [sp], #0x10
     1b8:      	ret
     1bc:      	mov	w10, #0x1               // =1
     1c0:      	lsl	x10, x10, x9
     1c4:      	tst	x10, #0xc00
     1c8:      	b.ne	0x1ec <filter_8ty+0x6c>
     1cc:      	mov	w10, #0x1               // =1
     1d0:      	lsl	x9, x10, x9
     1d4:      	tst	x9, #0x180000000
     1d8:      	b.eq	0x1f4 <filter_8ty+0x74>
     1dc:      	mov	x0, x8
     1e0:      	bl	0x1950 <filter_8ty_range>
     1e4:      	ldr	x30, [sp], #0x10
     1e8:      	ret
     1ec:      	mov	x0, x8
     1f0:      	bl	0x1890 <filter_8ty_map>
     1f4:      	ldr	x30, [sp], #0x10
     1f8:      	ret
     1fc:      	nop

0000000000000200 <filter_64ty_selector_val>:
     200:      	ldr	w8, [x0, #0x4]
     204:      	cmp	w8, #0x25
     208:      	b.hi	0x27c <filter_64ty_selector_val+0x7c>
     20c:      	mov	x10, #0x40              // =64
     210:      	mov	w9, #0x1                // =1
     214:      	movk	x10, #0xc00, lsl #16
     218:      	lsl	x9, x9, x8
     21c:      	movk	x10, #0x20, lsl #32
     220:      	tst	x9, x10
     224:      	b.eq	0x230 <filter_64ty_selector_val+0x30>
     228:      	mov	w0, #0x1                // =1
     22c:      	ret
     230:      	mov	w9, #0x1                // =1
     234:      	lsl	x9, x9, x8
     238:      	tst	x9, #0x18
     23c:      	b.eq	0x25c <filter_64ty_selector_val+0x5c>
     240:      	ldr	x9, [x1]
     244:      	ldr	x10, [x0, #0x10]
     248:      	cmp	x9, x10
     24c:      	b.ne	0x2fc <filter_64ty_selector_val+0xfc>
     250:      	cmp	w8, #0x3
     254:      	cset	w0, eq
     258:      	ret
     25c:      	cmp	x8, #0xc
     260:      	b.ne	0x27c <filter_64ty_selector_val+0x7c>
     264:      	ldr	x8, [x1]
     268:      	ldr	x9, [x0, #0x10]
     26c:      	tst	x8, x9
     270:      	b.eq	0x3a8 <filter_64ty_selector_val+0x1a8>
     274:      	mov	w0, #0x1                // =1
     278:      	ret
     27c:      	cmp	w8, #0x1
     280:      	b.eq	0x2c4 <filter_64ty_selector_val+0xc4>
     284:      	cmp	w8, #0x2
     288:      	b.ne	0x550 <filter_64ty_selector_val+0x350>
     28c:      	ldr	w8, [x0, #0xc]
     290:      	cmp	w8, #0xc
     294:      	b.hi	0x3e0 <filter_64ty_selector_val+0x1e0>
     298:      	mov	w9, #0x1                // =1
     29c:      	lsl	w8, w9, w8
     2a0:      	mov	w9, #0x1402             // =5122
     2a4:      	tst	w8, w9
     2a8:      	b.eq	0x3e0 <filter_64ty_selector_val+0x1e0>
     2ac:      	ldr	x8, [x1]
     2b0:      	ldr	x9, [x0, #0x10]
     2b4:      	cmp	x8, x9
     2b8:      	b.ge	0x388 <filter_64ty_selector_val+0x188>
     2bc:      	mov	w0, #0x1                // =1
     2c0:      	ret
     2c4:      	ldr	w8, [x0, #0xc]
     2c8:      	cmp	w8, #0xc
     2cc:      	b.hi	0x3c8 <filter_64ty_selector_val+0x1c8>
     2d0:      	mov	w9, #0x1                // =1
     2d4:      	lsl	w8, w9, w8
     2d8:      	mov	w9, #0x1402             // =5122
     2dc:      	tst	w8, w9
     2e0:      	b.eq	0x3c8 <filter_64ty_selector_val+0x1c8>
     2e4:      	ldr	x8, [x1]
     2e8:      	ldr	x9, [x0, #0x10]
     2ec:      	cmp	x8, x9
     2f0:      	b.le	0x368 <filter_64ty_selector_val+0x168>
     2f4:      	mov	w0, #0x1                // =1
     2f8:      	ret
     2fc:      	ldr	w10, [x0, #0x8]
     300:      	cmp	w10, #0x11
     304:      	b.lo	0x33c <filter_64ty_selector_val+0x13c>
     308:      	ldr	x11, [x0, #0x18]
     30c:      	cmp	x9, x11
     310:      	b.eq	0x250 <filter_64ty_selector_val+0x50>
     314:      	cmp	w10, #0x19
     318:      	b.lo	0x33c <filter_64ty_selector_val+0x13c>
     31c:      	ldr	x11, [x0, #0x20]
     320:      	cmp	x9, x11
     324:      	b.eq	0x250 <filter_64ty_selector_val+0x50>
     328:      	cmp	w10, #0x21
     32c:      	b.lo	0x33c <filter_64ty_selector_val+0x13c>
     330:      	ldr	x10, [x0, #0x28]
     334:      	cmp	x9, x10
     338:      	b.eq	0x250 <filter_64ty_selector_val+0x50>
     33c:      	cmp	w8, #0x25
     340:      	b.hi	0x550 <filter_64ty_selector_val+0x350>
     344:      	mov	w9, #0x1                // =1
     348:      	lsl	x8, x9, x8
     34c:      	mov	x9, #0x50               // =80
     350:      	movk	x9, #0xc00, lsl #16
     354:      	movk	x9, #0x20, lsl #32
     358:      	tst	x8, x9
     35c:      	b.eq	0x550 <filter_64ty_selector_val+0x350>
     360:      	mov	w0, #0x1                // =1
     364:      	ret
     368:      	ldr	w9, [x0, #0x8]
     36c:      	cmp	w9, #0x11
     370:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     374:      	ldr	x10, [x0, #0x18]
     378:      	cmp	x8, x10
     37c:      	b.le	0x438 <filter_64ty_selector_val+0x238>
     380:      	mov	w0, #0x1                // =1
     384:      	ret
     388:      	ldr	w9, [x0, #0x8]
     38c:      	cmp	w9, #0x11
     390:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     394:      	ldr	x10, [x0, #0x18]
     398:      	cmp	x8, x10
     39c:      	b.ge	0x454 <filter_64ty_selector_val+0x254>
     3a0:      	mov	w0, #0x1                // =1
     3a4:      	ret
     3a8:      	ldr	w9, [x0, #0x8]
     3ac:      	cmp	w9, #0x11
     3b0:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     3b4:      	ldr	x10, [x0, #0x18]
     3b8:      	tst	x8, x10
     3bc:      	b.eq	0x470 <filter_64ty_selector_val+0x270>
     3c0:      	mov	w0, #0x1                // =1
     3c4:      	ret
     3c8:      	ldr	x8, [x1]
     3cc:      	ldr	x9, [x0, #0x10]
     3d0:      	cmp	x8, x9
     3d4:      	b.ls	0x3f8 <filter_64ty_selector_val+0x1f8>
     3d8:      	mov	w0, #0x1                // =1
     3dc:      	ret
     3e0:      	ldr	x8, [x1]
     3e4:      	ldr	x9, [x0, #0x10]
     3e8:      	cmp	x8, x9
     3ec:      	b.hs	0x418 <filter_64ty_selector_val+0x218>
     3f0:      	mov	w0, #0x1                // =1
     3f4:      	ret
     3f8:      	ldr	w9, [x0, #0x8]
     3fc:      	cmp	w9, #0x11
     400:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     404:      	ldr	x10, [x0, #0x18]
     408:      	cmp	x8, x10
     40c:      	b.ls	0x48c <filter_64ty_selector_val+0x28c>
     410:      	mov	w0, #0x1                // =1
     414:      	ret
     418:      	ldr	w9, [x0, #0x8]
     41c:      	cmp	w9, #0x11
     420:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     424:      	ldr	x10, [x0, #0x18]
     428:      	cmp	x8, x10
     42c:      	b.hs	0x4a8 <filter_64ty_selector_val+0x2a8>
     430:      	mov	w0, #0x1                // =1
     434:      	ret
     438:      	cmp	w9, #0x19
     43c:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     440:      	ldr	x10, [x0, #0x20]
     444:      	cmp	x8, x10
     448:      	b.le	0x4c4 <filter_64ty_selector_val+0x2c4>
     44c:      	mov	w0, #0x1                // =1
     450:      	ret
     454:      	cmp	w9, #0x19
     458:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     45c:      	ldr	x10, [x0, #0x20]
     460:      	cmp	x8, x10
     464:      	b.ge	0x4e0 <filter_64ty_selector_val+0x2e0>
     468:      	mov	w0, #0x1                // =1
     46c:      	ret
     470:      	cmp	w9, #0x19
     474:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     478:      	ldr	x10, [x0, #0x20]
     47c:      	tst	x8, x10
     480:      	b.eq	0x4fc <filter_64ty_selector_val+0x2fc>
     484:      	mov	w0, #0x1                // =1
     488:      	ret
     48c:      	cmp	w9, #0x19
     490:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     494:      	ldr	x10, [x0, #0x20]
     498:      	cmp	x8, x10
     49c:      	b.ls	0x518 <filter_64ty_selector_val+0x318>
     4a0:      	mov	w0, #0x1                // =1
     4a4:      	ret
     4a8:      	cmp	w9, #0x19
     4ac:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     4b0:      	ldr	x10, [x0, #0x20]
     4b4:      	cmp	x8, x10
     4b8:      	b.hs	0x534 <filter_64ty_selector_val+0x334>
     4bc:      	mov	w0, #0x1                // =1
     4c0:      	ret
     4c4:      	cmp	w9, #0x21
     4c8:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     4cc:      	ldr	x9, [x0, #0x28]
     4d0:      	cmp	x8, x9
     4d4:      	b.le	0x550 <filter_64ty_selector_val+0x350>
     4d8:      	mov	w0, #0x1                // =1
     4dc:      	ret
     4e0:      	cmp	w9, #0x21
     4e4:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     4e8:      	ldr	x9, [x0, #0x28]
     4ec:      	cmp	x8, x9
     4f0:      	b.ge	0x550 <filter_64ty_selector_val+0x350>
     4f4:      	mov	w0, #0x1                // =1
     4f8:      	ret
     4fc:      	cmp	w9, #0x21
     500:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     504:      	ldr	x9, [x0, #0x28]
     508:      	tst	x8, x9
     50c:      	b.eq	0x550 <filter_64ty_selector_val+0x350>
     510:      	mov	w0, #0x1                // =1
     514:      	ret
     518:      	cmp	w9, #0x21
     51c:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     520:      	ldr	x9, [x0, #0x28]
     524:      	cmp	x8, x9
     528:      	b.ls	0x550 <filter_64ty_selector_val+0x350>
     52c:      	mov	w0, #0x1                // =1
     530:      	ret
     534:      	cmp	w9, #0x21
     538:      	b.lo	0x550 <filter_64ty_selector_val+0x350>
     53c:      	ldr	x9, [x0, #0x28]
     540:      	cmp	x8, x9
     544:      	b.hs	0x550 <filter_64ty_selector_val+0x350>
     548:      	mov	w0, #0x1                // =1
     54c:      	ret
     550:      	mov	x0, xzr
     554:      	ret
     558:      	nop
     55c:      	nop

0000000000000560 <filter_64ty_map>:
     560:      	sub	sp, sp, #0x30
     564:      	str	x30, [sp, #0x10]
     568:      	stp	x20, x19, [sp, #0x20]
     56c:      	ldrb	w8, [x0, #0x10]
     570:      	mov	x19, x0
     574:      	adrp	x0, 0x0 <filter_64ty>
     578:      	add	x9, sp, #0x1c
     57c:      	str	w8, [sp, #0x1c]
     580:      	mov	w8, #0x1                // =1
     584:      	mov	x20, x1
     588:      	add	x1, sp, #0x1c
     58c:      	ldr	x0, [x0]
     590:      	blr	x8
     594:      	cbz	x0, 0x5e4 <filter_64ty_map+0x84>
     598:      	ldr	x8, [x20]
     59c:      	add	x9, sp, #0x8
     5a0:      	add	x1, sp, #0x8
     5a4:      	str	x8, [sp, #0x8]
     5a8:      	mov	w8, #0x1                // =1
     5ac:      	blr	x8
     5b0:      	ldr	w8, [x19, #0x4]
     5b4:      	cmp	w8, #0xb
     5b8:      	b.eq	0x5d0 <filter_64ty_map+0x70>
     5bc:      	cmp	w8, #0xa
     5c0:      	b.ne	0x5dc <filter_64ty_map+0x7c>
     5c4:      	cmp	x0, #0x0
     5c8:      	cset	w8, ne
     5cc:      	b	0x5e0 <filter_64ty_map+0x80>
     5d0:      	cmp	x0, #0x0
     5d4:      	cset	w8, eq
     5d8:      	b	0x5e0 <filter_64ty_map+0x80>
     5dc:      	mov	w8, wzr
     5e0:      	mov	w0, w8
     5e4:      	ldp	x20, x19, [sp, #0x20]
     5e8:      	ldr	x30, [sp, #0x10]
     5ec:      	add	sp, sp, #0x30
     5f0:      	ret
     5f4:      	nop
     5f8:      	nop
     5fc:      	nop

0000000000000600 <filter_64ty_range>:
     600:      	ldr	w9, [x0, #0xc]
     604:      	ldr	w8, [x0, #0x4]
     608:      	mov	w10, #0x1               // =1
     60c:      	cmp	w9, #0xc
     610:      	lsl	w9, w10, w9
     614:      	mov	w10, #0x1402            // =5122
     618:      	and	w9, w9, w10
     61c:      	ccmp	w9, #0x0, #0x4, ls
     620:      	b.eq	0x720 <filter_64ty_range+0x120>
     624:      	ldr	x10, [x1]
     628:      	cmp	w8, #0x1f
     62c:      	b.ne	0x6b4 <filter_64ty_range+0xb4>
     630:      	ldr	x9, [x0, #0x10]
     634:      	cmp	x9, x10
     638:      	b.gt	0x648 <filter_64ty_range+0x48>
     63c:      	ldr	x9, [x0, #0x18]
     640:      	cmp	x10, x9
     644:      	b.le	0x744 <filter_64ty_range+0x144>
     648:      	ldr	w9, [x0, #0x8]
     64c:      	cmp	w9, #0x19
     650:      	b.lo	0x830 <filter_64ty_range+0x230>
     654:      	ldr	x11, [x0, #0x20]
     658:      	cmp	x11, x10
     65c:      	b.gt	0x66c <filter_64ty_range+0x6c>
     660:      	ldr	x11, [x0, #0x28]
     664:      	cmp	x10, x11
     668:      	b.le	0x744 <filter_64ty_range+0x144>
     66c:      	cmp	w9, #0x29
     670:      	b.lo	0x830 <filter_64ty_range+0x230>
     674:      	ldr	x11, [x0, #0x30]
     678:      	cmp	x11, x10
     67c:      	b.gt	0x68c <filter_64ty_range+0x8c>
     680:      	ldr	x11, [x0, #0x38]
     684:      	cmp	x10, x11
     688:      	b.le	0x744 <filter_64ty_range+0x144>
     68c:      	cmp	w9, #0x39
     690:      	b.lo	0x830 <filter_64ty_range+0x230>
     694:      	ldr	x11, [x0, #0x40]
     698:      	mov	w9, wzr
     69c:      	cmp	x11, x10
     6a0:      	b.gt	0x820 <filter_64ty_range+0x220>
     6a4:      	ldr	x11, [x0, #0x48]
     6a8:      	cmp	x10, x11
     6ac:      	b.le	0x744 <filter_64ty_range+0x144>
     6b0:      	b	0x820 <filter_64ty_range+0x220>
     6b4:      	ldp	x9, x12, [x0, #0x10]
     6b8:      	cmp	x9, x10
     6bc:      	ldr	w11, [x0, #0x8]
     6c0:      	ccmp	x10, x12, #0x0, le
     6c4:      	cset	w9, le
     6c8:      	cmp	w11, #0x19
     6cc:      	b.lo	0x820 <filter_64ty_range+0x220>
     6d0:      	ldp	x12, x13, [x0, #0x20]
     6d4:      	cmp	x12, x10
     6d8:      	ccmp	x10, x13, #0x0, le
     6dc:      	csinc	w9, w9, wzr, gt
     6e0:      	cmp	w11, #0x29
     6e4:      	b.lo	0x820 <filter_64ty_range+0x220>
     6e8:      	ldp	x12, x13, [x0, #0x30]
     6ec:      	cmp	x12, x10
     6f0:      	ccmp	x10, x13, #0x0, le
     6f4:      	csinc	w9, w9, wzr, gt
     6f8:      	cmp	w11, #0x39
     6fc:      	b.lo	0x820 <filter_64ty_range+0x220>
     700:      	ldp	x11, x12, [x0, #0x40]
     704:      	cmp	x11, x10
     708:      	ccmp	x10, x12, #0x0, le
     70c:      	csinc	w9, w9, wzr, gt
     710:      	cmp	w8, #0x20
     714:      	eor	w8, w9, #0x1
     718:      	csel	w0, wzr, w8, ne
     71c:      	ret
     720:      	ldr	x10, [x1]
     724:      	cmp	w8, #0x1f
     728:      	b.ne	0x74c <filter_64ty_range+0x14c>
     72c:      	ldr	x9, [x0, #0x10]
     730:      	cmp	x9, x10
     734:      	b.hi	0x7b8 <filter_64ty_range+0x1b8>
     738:      	ldr	x9, [x0, #0x18]
     73c:      	cmp	x10, x9
     740:      	b.hi	0x7b8 <filter_64ty_range+0x1b8>
     744:      	mov	w0, #0x1                // =1
     748:      	ret
     74c:      	ldp	x9, x12, [x0, #0x10]
     750:      	cmp	x9, x10
     754:      	ldr	w11, [x0, #0x8]
     758:      	ccmp	x10, x12, #0x2, ls
     75c:      	cset	w9, ls
     760:      	cmp	w11, #0x19
     764:      	b.lo	0x820 <filter_64ty_range+0x220>
     768:      	ldp	x12, x13, [x0, #0x20]
     76c:      	cmp	x12, x10
     770:      	ccmp	x10, x13, #0x2, ls
     774:      	csinc	w9, w9, wzr, hi
     778:      	cmp	w11, #0x29
     77c:      	b.lo	0x820 <filter_64ty_range+0x220>
     780:      	ldp	x12, x13, [x0, #0x30]
     784:      	cmp	x12, x10
     788:      	ccmp	x10, x13, #0x2, ls
     78c:      	csinc	w9, w9, wzr, hi
     790:      	cmp	w11, #0x39
     794:      	b.lo	0x820 <filter_64ty_range+0x220>
     798:      	ldp	x11, x12, [x0, #0x40]
     79c:      	cmp	x11, x10
     7a0:      	ccmp	x10, x12, #0x2, ls
     7a4:      	csinc	w9, w9, wzr, hi
     7a8:      	cmp	w8, #0x20
     7ac:      	eor	w8, w9, #0x1
     7b0:      	csel	w0, wzr, w8, ne
     7b4:      	ret
     7b8:      	ldr	w9, [x0, #0x8]
     7bc:      	cmp	w9, #0x19
     7c0:      	b.lo	0x830 <filter_64ty_range+0x230>
     7c4:      	ldr	x11, [x0, #0x20]
     7c8:      	cmp	x11, x10
     7cc:      	b.hi	0x7dc <filter_64ty_range+0x1dc>
     7d0:      	ldr	x11, [x0, #0x28]
     7d4:      	cmp	x10, x11
     7d8:      	b.ls	0x744 <filter_64ty_range+0x144>
     7dc:      	cmp	w9, #0x29
     7e0:      	b.lo	0x830 <filter_64ty_range+0x230>
     7e4:      	ldr	x11, [x0, #0x30]
     7e8:      	cmp	x11, x10
     7ec:      	b.hi	0x7fc <filter_64ty_range+0x1fc>
     7f0:      	ldr	x11, [x0, #0x38]
     7f4:      	cmp	x10, x11
     7f8:      	b.ls	0x744 <filter_64ty_range+0x144>
     7fc:      	cmp	w9, #0x39
     800:      	b.lo	0x830 <filter_64ty_range+0x230>
     804:      	ldr	x11, [x0, #0x40]
     808:      	mov	w9, wzr
     80c:      	cmp	x11, x10
     810:      	b.hi	0x820 <filter_64ty_range+0x220>
     814:      	ldr	x11, [x0, #0x48]
     818:      	cmp	x10, x11
     81c:      	b.ls	0x744 <filter_64ty_range+0x144>
     820:      	cmp	w8, #0x20
     824:      	eor	w8, w9, #0x1
     828:      	csel	w0, wzr, w8, ne
     82c:      	ret
     830:      	mov	w9, wzr
     834:      	cmp	w8, #0x20
     838:      	eor	w8, w9, #0x1
     83c:      	csel	w0, wzr, w8, ne
     840:      	ret
     844:      	nop
     848:      	nop
     84c:      	nop

0000000000000850 <filter_32ty_selector_val>:
     850:      	ldr	w8, [x0, #0x4]
     854:      	cmp	w8, #0x25
     858:      	b.hi	0x8cc <filter_32ty_selector_val+0x7c>
     85c:      	mov	x10, #0x40              // =64
     860:      	mov	w9, #0x1                // =1
     864:      	movk	x10, #0xc00, lsl #16
     868:      	lsl	x9, x9, x8
     86c:      	movk	x10, #0x20, lsl #32
     870:      	tst	x9, x10
     874:      	b.eq	0x880 <filter_32ty_selector_val+0x30>
     878:      	mov	w0, #0x1                // =1
     87c:      	ret
     880:      	mov	w9, #0x1                // =1
     884:      	lsl	x9, x9, x8
     888:      	tst	x9, #0x18
     88c:      	b.eq	0x8ac <filter_32ty_selector_val+0x5c>
     890:      	ldr	w9, [x1]
     894:      	ldr	w10, [x0, #0x10]
     898:      	cmp	w9, w10
     89c:      	b.ne	0x94c <filter_32ty_selector_val+0xfc>
     8a0:      	cmp	w8, #0x3
     8a4:      	cset	w0, eq
     8a8:      	ret
     8ac:      	cmp	x8, #0xc
     8b0:      	b.ne	0x8cc <filter_32ty_selector_val+0x7c>
     8b4:      	ldr	w8, [x1]
     8b8:      	ldr	w9, [x0, #0x10]
     8bc:      	tst	w8, w9
     8c0:      	b.eq	0x9f8 <filter_32ty_selector_val+0x1a8>
     8c4:      	mov	w0, #0x1                // =1
     8c8:      	ret
     8cc:      	cmp	w8, #0x1
     8d0:      	b.eq	0x914 <filter_32ty_selector_val+0xc4>
     8d4:      	cmp	w8, #0x2
     8d8:      	b.ne	0xba0 <filter_32ty_selector_val+0x350>
     8dc:      	ldr	w8, [x0, #0xc]
     8e0:      	cmp	w8, #0xc
     8e4:      	b.hi	0xa30 <filter_32ty_selector_val+0x1e0>
     8e8:      	mov	w9, #0x1                // =1
     8ec:      	lsl	w8, w9, w8
     8f0:      	mov	w9, #0x1402             // =5122
     8f4:      	tst	w8, w9
     8f8:      	b.eq	0xa30 <filter_32ty_selector_val+0x1e0>
     8fc:      	ldr	w8, [x1]
     900:      	ldr	w9, [x0, #0x10]
     904:      	cmp	w8, w9
     908:      	b.ge	0x9d8 <filter_32ty_selector_val+0x188>
     90c:      	mov	w0, #0x1                // =1
     910:      	ret
     914:      	ldr	w8, [x0, #0xc]
     918:      	cmp	w8, #0xc
     91c:      	b.hi	0xa18 <filter_32ty_selector_val+0x1c8>
     920:      	mov	w9, #0x1                // =1
     924:      	lsl	w8, w9, w8
     928:      	mov	w9, #0x1402             // =5122
     92c:      	tst	w8, w9
     930:      	b.eq	0xa18 <filter_32ty_selector_val+0x1c8>
     934:      	ldr	w8, [x1]
     938:      	ldr	w9, [x0, #0x10]
     93c:      	cmp	w8, w9
     940:      	b.le	0x9b8 <filter_32ty_selector_val+0x168>
     944:      	mov	w0, #0x1                // =1
     948:      	ret
     94c:      	ldr	w10, [x0, #0x8]
     950:      	cmp	w10, #0xd
     954:      	b.lo	0x98c <filter_32ty_selector_val+0x13c>
     958:      	ldr	w11, [x0, #0x14]
     95c:      	cmp	w9, w11
     960:      	b.eq	0x8a0 <filter_32ty_selector_val+0x50>
     964:      	cmp	w10, #0x11
     968:      	b.lo	0x98c <filter_32ty_selector_val+0x13c>
     96c:      	ldr	w11, [x0, #0x18]
     970:      	cmp	w9, w11
     974:      	b.eq	0x8a0 <filter_32ty_selector_val+0x50>
     978:      	cmp	w10, #0x15
     97c:      	b.lo	0x98c <filter_32ty_selector_val+0x13c>
     980:      	ldr	w10, [x0, #0x1c]
     984:      	cmp	w9, w10
     988:      	b.eq	0x8a0 <filter_32ty_selector_val+0x50>
     98c:      	cmp	w8, #0x25
     990:      	b.hi	0xba0 <filter_32ty_selector_val+0x350>
     994:      	mov	w9, #0x1                // =1
     998:      	lsl	x8, x9, x8
     99c:      	mov	x9, #0x50               // =80
     9a0:      	movk	x9, #0xc00, lsl #16
     9a4:      	movk	x9, #0x20, lsl #32
     9a8:      	tst	x8, x9
     9ac:      	b.eq	0xba0 <filter_32ty_selector_val+0x350>
     9b0:      	mov	w0, #0x1                // =1
     9b4:      	ret
     9b8:      	ldr	w9, [x0, #0x8]
     9bc:      	cmp	w9, #0xd
     9c0:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     9c4:      	ldr	w10, [x0, #0x14]
     9c8:      	cmp	w8, w10
     9cc:      	b.le	0xa88 <filter_32ty_selector_val+0x238>
     9d0:      	mov	w0, #0x1                // =1
     9d4:      	ret
     9d8:      	ldr	w9, [x0, #0x8]
     9dc:      	cmp	w9, #0xd
     9e0:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     9e4:      	ldr	w10, [x0, #0x14]
     9e8:      	cmp	w8, w10
     9ec:      	b.ge	0xaa4 <filter_32ty_selector_val+0x254>
     9f0:      	mov	w0, #0x1                // =1
     9f4:      	ret
     9f8:      	ldr	w9, [x0, #0x8]
     9fc:      	cmp	w9, #0xd
     a00:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     a04:      	ldr	w10, [x0, #0x14]
     a08:      	tst	w8, w10
     a0c:      	b.eq	0xac0 <filter_32ty_selector_val+0x270>
     a10:      	mov	w0, #0x1                // =1
     a14:      	ret
     a18:      	ldr	w8, [x1]
     a1c:      	ldr	w9, [x0, #0x10]
     a20:      	cmp	w8, w9
     a24:      	b.ls	0xa48 <filter_32ty_selector_val+0x1f8>
     a28:      	mov	w0, #0x1                // =1
     a2c:      	ret
     a30:      	ldr	w8, [x1]
     a34:      	ldr	w9, [x0, #0x10]
     a38:      	cmp	w8, w9
     a3c:      	b.hs	0xa68 <filter_32ty_selector_val+0x218>
     a40:      	mov	w0, #0x1                // =1
     a44:      	ret
     a48:      	ldr	w9, [x0, #0x8]
     a4c:      	cmp	w9, #0xd
     a50:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     a54:      	ldr	w10, [x0, #0x14]
     a58:      	cmp	w8, w10
     a5c:      	b.ls	0xadc <filter_32ty_selector_val+0x28c>
     a60:      	mov	w0, #0x1                // =1
     a64:      	ret
     a68:      	ldr	w9, [x0, #0x8]
     a6c:      	cmp	w9, #0xd
     a70:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     a74:      	ldr	w10, [x0, #0x14]
     a78:      	cmp	w8, w10
     a7c:      	b.hs	0xaf8 <filter_32ty_selector_val+0x2a8>
     a80:      	mov	w0, #0x1                // =1
     a84:      	ret
     a88:      	cmp	w9, #0x11
     a8c:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     a90:      	ldr	w10, [x0, #0x18]
     a94:      	cmp	w8, w10
     a98:      	b.le	0xb14 <filter_32ty_selector_val+0x2c4>
     a9c:      	mov	w0, #0x1                // =1
     aa0:      	ret
     aa4:      	cmp	w9, #0x11
     aa8:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     aac:      	ldr	w10, [x0, #0x18]
     ab0:      	cmp	w8, w10
     ab4:      	b.ge	0xb30 <filter_32ty_selector_val+0x2e0>
     ab8:      	mov	w0, #0x1                // =1
     abc:      	ret
     ac0:      	cmp	w9, #0x11
     ac4:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     ac8:      	ldr	w10, [x0, #0x18]
     acc:      	tst	w8, w10
     ad0:      	b.eq	0xb4c <filter_32ty_selector_val+0x2fc>
     ad4:      	mov	w0, #0x1                // =1
     ad8:      	ret
     adc:      	cmp	w9, #0x11
     ae0:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     ae4:      	ldr	w10, [x0, #0x18]
     ae8:      	cmp	w8, w10
     aec:      	b.ls	0xb68 <filter_32ty_selector_val+0x318>
     af0:      	mov	w0, #0x1                // =1
     af4:      	ret
     af8:      	cmp	w9, #0x11
     afc:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     b00:      	ldr	w10, [x0, #0x18]
     b04:      	cmp	w8, w10
     b08:      	b.hs	0xb84 <filter_32ty_selector_val+0x334>
     b0c:      	mov	w0, #0x1                // =1
     b10:      	ret
     b14:      	cmp	w9, #0x15
     b18:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     b1c:      	ldr	w9, [x0, #0x1c]
     b20:      	cmp	w8, w9
     b24:      	b.le	0xba0 <filter_32ty_selector_val+0x350>
     b28:      	mov	w0, #0x1                // =1
     b2c:      	ret
     b30:      	cmp	w9, #0x15
     b34:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     b38:      	ldr	w9, [x0, #0x1c]
     b3c:      	cmp	w8, w9
     b40:      	b.ge	0xba0 <filter_32ty_selector_val+0x350>
     b44:      	mov	w0, #0x1                // =1
     b48:      	ret
     b4c:      	cmp	w9, #0x15
     b50:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     b54:      	ldr	w9, [x0, #0x1c]
     b58:      	tst	w8, w9
     b5c:      	b.eq	0xba0 <filter_32ty_selector_val+0x350>
     b60:      	mov	w0, #0x1                // =1
     b64:      	ret
     b68:      	cmp	w9, #0x15
     b6c:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     b70:      	ldr	w9, [x0, #0x1c]
     b74:      	cmp	w8, w9
     b78:      	b.ls	0xba0 <filter_32ty_selector_val+0x350>
     b7c:      	mov	w0, #0x1                // =1
     b80:      	ret
     b84:      	cmp	w9, #0x15
     b88:      	b.lo	0xba0 <filter_32ty_selector_val+0x350>
     b8c:      	ldr	w9, [x0, #0x1c]
     b90:      	cmp	w8, w9
     b94:      	b.hs	0xba0 <filter_32ty_selector_val+0x350>
     b98:      	mov	w0, #0x1                // =1
     b9c:      	ret
     ba0:      	mov	x0, xzr
     ba4:      	ret
     ba8:      	nop
     bac:      	nop

0000000000000bb0 <filter_32ty_map>:
     bb0:      	sub	sp, sp, #0x30
     bb4:      	str	x30, [sp, #0x10]
     bb8:      	stp	x20, x19, [sp, #0x20]
     bbc:      	ldrb	w8, [x0, #0x10]
     bc0:      	mov	x19, x0
     bc4:      	adrp	x0, 0x0 <filter_64ty>
     bc8:      	add	x9, sp, #0x1c
     bcc:      	str	w8, [sp, #0x1c]
     bd0:      	mov	w8, #0x1                // =1
     bd4:      	mov	x20, x1
     bd8:      	add	x1, sp, #0x1c
     bdc:      	ldr	x0, [x0]
     be0:      	blr	x8
     be4:      	cbz	x0, 0xc58 <filter_32ty_map+0xa8>
     be8:      	ldr	w8, [x20]
     bec:      	mov	w9, #0x1                // =1
     bf0:      	add	x1, sp, #0x8
     bf4:      	mov	w20, #0x1               // =1
     bf8:      	str	x8, [sp, #0x8]
     bfc:      	add	x8, sp, #0x8
     c00:      	blr	x9
     c04:      	ldr	w9, [x19, #0x4]
     c08:      	mov	w8, wzr
     c0c:      	cmp	w9, #0x1d
     c10:      	b.hi	0xc54 <filter_32ty_map+0xa4>
     c14:      	mov	w11, #0x8400            // =33792
     c18:      	lsl	w10, w20, w9
     c1c:      	movk	w11, #0x3003, lsl #16
     c20:      	tst	w10, w11
     c24:      	b.eq	0xc34 <filter_32ty_map+0x84>
     c28:      	cmp	x0, #0x0
     c2c:      	cset	w8, ne
     c30:      	b	0xc54 <filter_32ty_map+0xa4>
     c34:      	mov	w10, #0x1               // =1
     c38:      	lsl	w9, w10, w9
     c3c:      	mov	w10, #0x800             // =2048
     c40:      	movk	w10, #0xc, lsl #16
     c44:      	tst	w9, w10
     c48:      	b.eq	0xc54 <filter_32ty_map+0xa4>
     c4c:      	cmp	x0, #0x0
     c50:      	cset	w8, eq
     c54:      	mov	w0, w8
     c58:      	ldp	x20, x19, [sp, #0x20]
     c5c:      	ldr	x30, [sp, #0x10]
     c60:      	add	sp, sp, #0x30
     c64:      	ret
     c68:      	nop
     c6c:      	nop

0000000000000c70 <filter_32ty_range>:
     c70:      	ldr	w9, [x0, #0xc]
     c74:      	ldr	w8, [x0, #0x4]
     c78:      	mov	w10, #0x1               // =1
     c7c:      	cmp	w9, #0xc
     c80:      	lsl	w9, w10, w9
     c84:      	mov	w10, #0x1402            // =5122
     c88:      	and	w9, w9, w10
     c8c:      	ccmp	w9, #0x0, #0x4, ls
     c90:      	b.eq	0xd90 <filter_32ty_range+0x120>
     c94:      	ldr	w10, [x1]
     c98:      	cmp	w8, #0x1f
     c9c:      	b.ne	0xd24 <filter_32ty_range+0xb4>
     ca0:      	ldr	w9, [x0, #0x10]
     ca4:      	cmp	w9, w10
     ca8:      	b.gt	0xcb8 <filter_32ty_range+0x48>
     cac:      	ldr	w9, [x0, #0x14]
     cb0:      	cmp	w10, w9
     cb4:      	b.le	0xdb4 <filter_32ty_range+0x144>
     cb8:      	ldr	w9, [x0, #0x8]
     cbc:      	cmp	w9, #0x11
     cc0:      	b.lo	0xea0 <filter_32ty_range+0x230>
     cc4:      	ldr	w11, [x0, #0x18]
     cc8:      	cmp	w11, w10
     ccc:      	b.gt	0xcdc <filter_32ty_range+0x6c>
     cd0:      	ldr	w11, [x0, #0x1c]
     cd4:      	cmp	w10, w11
     cd8:      	b.le	0xdb4 <filter_32ty_range+0x144>
     cdc:      	cmp	w9, #0x19
     ce0:      	b.lo	0xea0 <filter_32ty_range+0x230>
     ce4:      	ldr	w11, [x0, #0x20]
     ce8:      	cmp	w11, w10
     cec:      	b.gt	0xcfc <filter_32ty_range+0x8c>
     cf0:      	ldr	w11, [x0, #0x24]
     cf4:      	cmp	w10, w11
     cf8:      	b.le	0xdb4 <filter_32ty_range+0x144>
     cfc:      	cmp	w9, #0x21
     d00:      	b.lo	0xea0 <filter_32ty_range+0x230>
     d04:      	ldr	w11, [x0, #0x28]
     d08:      	mov	w9, wzr
     d0c:      	cmp	w11, w10
     d10:      	b.gt	0xe90 <filter_32ty_range+0x220>
     d14:      	ldr	w11, [x0, #0x2c]
     d18:      	cmp	w10, w11
     d1c:      	b.le	0xdb4 <filter_32ty_range+0x144>
     d20:      	b	0xe90 <filter_32ty_range+0x220>
     d24:      	ldp	w9, w12, [x0, #0x10]
     d28:      	ldr	w11, [x0, #0x8]
     d2c:      	cmp	w9, w10
     d30:      	ccmp	w10, w12, #0x0, le
     d34:      	cset	w9, le
     d38:      	cmp	w11, #0x11
     d3c:      	b.lo	0xe90 <filter_32ty_range+0x220>
     d40:      	ldp	w12, w13, [x0, #0x18]
     d44:      	cmp	w12, w10
     d48:      	ccmp	w10, w13, #0x0, le
     d4c:      	csinc	w9, w9, wzr, gt
     d50:      	cmp	w11, #0x19
     d54:      	b.lo	0xe90 <filter_32ty_range+0x220>
     d58:      	ldp	w12, w13, [x0, #0x20]
     d5c:      	cmp	w12, w10
     d60:      	ccmp	w10, w13, #0x0, le
     d64:      	csinc	w9, w9, wzr, gt
     d68:      	cmp	w11, #0x21
     d6c:      	b.lo	0xe90 <filter_32ty_range+0x220>
     d70:      	ldp	w11, w12, [x0, #0x28]
     d74:      	cmp	w11, w10
     d78:      	ccmp	w10, w12, #0x0, le
     d7c:      	csinc	w9, w9, wzr, gt
     d80:      	cmp	w8, #0x20
     d84:      	eor	w8, w9, #0x1
     d88:      	csel	w0, wzr, w8, ne
     d8c:      	ret
     d90:      	ldr	w10, [x1]
     d94:      	cmp	w8, #0x1f
     d98:      	b.ne	0xdbc <filter_32ty_range+0x14c>
     d9c:      	ldr	w9, [x0, #0x10]
     da0:      	cmp	w9, w10
     da4:      	b.hi	0xe28 <filter_32ty_range+0x1b8>
     da8:      	ldr	w9, [x0, #0x14]
     dac:      	cmp	w10, w9
     db0:      	b.hi	0xe28 <filter_32ty_range+0x1b8>
     db4:      	mov	w0, #0x1                // =1
     db8:      	ret
     dbc:      	ldp	w9, w12, [x0, #0x10]
     dc0:      	ldr	w11, [x0, #0x8]
     dc4:      	cmp	w9, w10
     dc8:      	ccmp	w10, w12, #0x2, ls
     dcc:      	cset	w9, ls
     dd0:      	cmp	w11, #0x11
     dd4:      	b.lo	0xe90 <filter_32ty_range+0x220>
     dd8:      	ldp	w12, w13, [x0, #0x18]
     ddc:      	cmp	w12, w10
     de0:      	ccmp	w10, w13, #0x2, ls
     de4:      	csinc	w9, w9, wzr, hi
     de8:      	cmp	w11, #0x19
     dec:      	b.lo	0xe90 <filter_32ty_range+0x220>
     df0:      	ldp	w12, w13, [x0, #0x20]
     df4:      	cmp	w12, w10
     df8:      	ccmp	w10, w13, #0x2, ls
     dfc:      	csinc	w9, w9, wzr, hi
     e00:      	cmp	w11, #0x21
     e04:      	b.lo	0xe90 <filter_32ty_range+0x220>
     e08:      	ldp	w11, w12, [x0, #0x28]
     e0c:      	cmp	w11, w10
     e10:      	ccmp	w10, w12, #0x2, ls
     e14:      	csinc	w9, w9, wzr, hi
     e18:      	cmp	w8, #0x20
     e1c:      	eor	w8, w9, #0x1
     e20:      	csel	w0, wzr, w8, ne
     e24:      	ret
     e28:      	ldr	w9, [x0, #0x8]
     e2c:      	cmp	w9, #0x11
     e30:      	b.lo	0xea0 <filter_32ty_range+0x230>
     e34:      	ldr	w11, [x0, #0x18]
     e38:      	cmp	w11, w10
     e3c:      	b.hi	0xe4c <filter_32ty_range+0x1dc>
     e40:      	ldr	w11, [x0, #0x1c]
     e44:      	cmp	w10, w11
     e48:      	b.ls	0xdb4 <filter_32ty_range+0x144>
     e4c:      	cmp	w9, #0x19
     e50:      	b.lo	0xea0 <filter_32ty_range+0x230>
     e54:      	ldr	w11, [x0, #0x20]
     e58:      	cmp	w11, w10
     e5c:      	b.hi	0xe6c <filter_32ty_range+0x1fc>
     e60:      	ldr	w11, [x0, #0x24]
     e64:      	cmp	w10, w11
     e68:      	b.ls	0xdb4 <filter_32ty_range+0x144>
     e6c:      	cmp	w9, #0x21
     e70:      	b.lo	0xea0 <filter_32ty_range+0x230>
     e74:      	ldr	w11, [x0, #0x28]
     e78:      	mov	w9, wzr
     e7c:      	cmp	w11, w10
     e80:      	b.hi	0xe90 <filter_32ty_range+0x220>
     e84:      	ldr	w11, [x0, #0x2c]
     e88:      	cmp	w10, w11
     e8c:      	b.ls	0xdb4 <filter_32ty_range+0x144>
     e90:      	cmp	w8, #0x20
     e94:      	eor	w8, w9, #0x1
     e98:      	csel	w0, wzr, w8, ne
     e9c:      	ret
     ea0:      	mov	w9, wzr
     ea4:      	cmp	w8, #0x20
     ea8:      	eor	w8, w9, #0x1
     eac:      	csel	w0, wzr, w8, ne
     eb0:      	ret
     eb4:      	nop
     eb8:      	nop
     ebc:      	nop

0000000000000ec0 <filter_16ty_selector_val>:
     ec0:      	ldr	w8, [x0, #0x4]
     ec4:      	cmp	w8, #0x25
     ec8:      	b.hi	0xf3c <filter_16ty_selector_val+0x7c>
     ecc:      	mov	x10, #0x40              // =64
     ed0:      	mov	w9, #0x1                // =1
     ed4:      	movk	x10, #0xc00, lsl #16
     ed8:      	lsl	x9, x9, x8
     edc:      	movk	x10, #0x20, lsl #32
     ee0:      	tst	x9, x10
     ee4:      	b.eq	0xef0 <filter_16ty_selector_val+0x30>
     ee8:      	mov	w0, #0x1                // =1
     eec:      	ret
     ef0:      	mov	w9, #0x1                // =1
     ef4:      	lsl	x9, x9, x8
     ef8:      	tst	x9, #0x18
     efc:      	b.eq	0xf1c <filter_16ty_selector_val+0x5c>
     f00:      	ldrh	w9, [x1]
     f04:      	ldr	w10, [x0, #0x10]
     f08:      	cmp	w10, w9
     f0c:      	b.ne	0xfbc <filter_16ty_selector_val+0xfc>
     f10:      	cmp	w8, #0x3
     f14:      	cset	w0, eq
     f18:      	ret
     f1c:      	cmp	x8, #0xc
     f20:      	b.ne	0xf3c <filter_16ty_selector_val+0x7c>
     f24:      	ldrh	w8, [x1]
     f28:      	ldr	w9, [x0, #0x10]
     f2c:      	tst	w9, w8
     f30:      	b.eq	0x1068 <filter_16ty_selector_val+0x1a8>
     f34:      	mov	w0, #0x1                // =1
     f38:      	ret
     f3c:      	cmp	w8, #0x1
     f40:      	b.eq	0xf84 <filter_16ty_selector_val+0xc4>
     f44:      	cmp	w8, #0x2
     f48:      	b.ne	0x1210 <filter_16ty_selector_val+0x350>
     f4c:      	ldr	w8, [x0, #0xc]
     f50:      	cmp	w8, #0xc
     f54:      	b.hi	0x10a0 <filter_16ty_selector_val+0x1e0>
     f58:      	mov	w9, #0x1                // =1
     f5c:      	lsl	w8, w9, w8
     f60:      	mov	w9, #0x1402             // =5122
     f64:      	tst	w8, w9
     f68:      	b.eq	0x10a0 <filter_16ty_selector_val+0x1e0>
     f6c:      	ldrsh	w8, [x1]
     f70:      	ldr	w9, [x0, #0x10]
     f74:      	cmp	w9, w8
     f78:      	b.le	0x1048 <filter_16ty_selector_val+0x188>
     f7c:      	mov	w0, #0x1                // =1
     f80:      	ret
     f84:      	ldr	w8, [x0, #0xc]
     f88:      	cmp	w8, #0xc
     f8c:      	b.hi	0x1088 <filter_16ty_selector_val+0x1c8>
     f90:      	mov	w9, #0x1                // =1
     f94:      	lsl	w8, w9, w8
     f98:      	mov	w9, #0x1402             // =5122
     f9c:      	tst	w8, w9
     fa0:      	b.eq	0x1088 <filter_16ty_selector_val+0x1c8>
     fa4:      	ldrsh	w8, [x1]
     fa8:      	ldr	w9, [x0, #0x10]
     fac:      	cmp	w9, w8
     fb0:      	b.ge	0x1028 <filter_16ty_selector_val+0x168>
     fb4:      	mov	w0, #0x1                // =1
     fb8:      	ret
     fbc:      	ldr	w10, [x0, #0x8]
     fc0:      	cmp	w10, #0xd
     fc4:      	b.lo	0xffc <filter_16ty_selector_val+0x13c>
     fc8:      	ldr	w11, [x0, #0x14]
     fcc:      	cmp	w11, w9
     fd0:      	b.eq	0xf10 <filter_16ty_selector_val+0x50>
     fd4:      	cmp	w10, #0x11
     fd8:      	b.lo	0xffc <filter_16ty_selector_val+0x13c>
     fdc:      	ldr	w11, [x0, #0x18]
     fe0:      	cmp	w11, w9
     fe4:      	b.eq	0xf10 <filter_16ty_selector_val+0x50>
     fe8:      	cmp	w10, #0x15
     fec:      	b.lo	0xffc <filter_16ty_selector_val+0x13c>
     ff0:      	ldr	w10, [x0, #0x1c]
     ff4:      	cmp	w10, w9
     ff8:      	b.eq	0xf10 <filter_16ty_selector_val+0x50>
     ffc:      	cmp	w8, #0x25
    1000:      	b.hi	0x1210 <filter_16ty_selector_val+0x350>
    1004:      	mov	w9, #0x1                // =1
    1008:      	lsl	x8, x9, x8
    100c:      	mov	x9, #0x50               // =80
    1010:      	movk	x9, #0xc00, lsl #16
    1014:      	movk	x9, #0x20, lsl #32
    1018:      	tst	x8, x9
    101c:      	b.eq	0x1210 <filter_16ty_selector_val+0x350>
    1020:      	mov	w0, #0x1                // =1
    1024:      	ret
    1028:      	ldr	w9, [x0, #0x8]
    102c:      	cmp	w9, #0xd
    1030:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    1034:      	ldr	w10, [x0, #0x14]
    1038:      	cmp	w10, w8
    103c:      	b.ge	0x10f8 <filter_16ty_selector_val+0x238>
    1040:      	mov	w0, #0x1                // =1
    1044:      	ret
    1048:      	ldr	w9, [x0, #0x8]
    104c:      	cmp	w9, #0xd
    1050:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    1054:      	ldr	w10, [x0, #0x14]
    1058:      	cmp	w10, w8
    105c:      	b.le	0x1114 <filter_16ty_selector_val+0x254>
    1060:      	mov	w0, #0x1                // =1
    1064:      	ret
    1068:      	ldr	w9, [x0, #0x8]
    106c:      	cmp	w9, #0xd
    1070:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    1074:      	ldr	w10, [x0, #0x14]
    1078:      	tst	w10, w8
    107c:      	b.eq	0x1130 <filter_16ty_selector_val+0x270>
    1080:      	mov	w0, #0x1                // =1
    1084:      	ret
    1088:      	ldrh	w8, [x1]
    108c:      	ldr	w9, [x0, #0x10]
    1090:      	cmp	w9, w8
    1094:      	b.hs	0x10b8 <filter_16ty_selector_val+0x1f8>
    1098:      	mov	w0, #0x1                // =1
    109c:      	ret
    10a0:      	ldrh	w8, [x1]
    10a4:      	ldr	w9, [x0, #0x10]
    10a8:      	cmp	w9, w8
    10ac:      	b.ls	0x10d8 <filter_16ty_selector_val+0x218>
    10b0:      	mov	w0, #0x1                // =1
    10b4:      	ret
    10b8:      	ldr	w9, [x0, #0x8]
    10bc:      	cmp	w9, #0xd
    10c0:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    10c4:      	ldr	w10, [x0, #0x14]
    10c8:      	cmp	w10, w8
    10cc:      	b.hs	0x114c <filter_16ty_selector_val+0x28c>
    10d0:      	mov	w0, #0x1                // =1
    10d4:      	ret
    10d8:      	ldr	w9, [x0, #0x8]
    10dc:      	cmp	w9, #0xd
    10e0:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    10e4:      	ldr	w10, [x0, #0x14]
    10e8:      	cmp	w10, w8
    10ec:      	b.ls	0x1168 <filter_16ty_selector_val+0x2a8>
    10f0:      	mov	w0, #0x1                // =1
    10f4:      	ret
    10f8:      	cmp	w9, #0x11
    10fc:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    1100:      	ldr	w10, [x0, #0x18]
    1104:      	cmp	w10, w8
    1108:      	b.ge	0x1184 <filter_16ty_selector_val+0x2c4>
    110c:      	mov	w0, #0x1                // =1
    1110:      	ret
    1114:      	cmp	w9, #0x11
    1118:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    111c:      	ldr	w10, [x0, #0x18]
    1120:      	cmp	w10, w8
    1124:      	b.le	0x11a0 <filter_16ty_selector_val+0x2e0>
    1128:      	mov	w0, #0x1                // =1
    112c:      	ret
    1130:      	cmp	w9, #0x11
    1134:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    1138:      	ldr	w10, [x0, #0x18]
    113c:      	tst	w10, w8
    1140:      	b.eq	0x11bc <filter_16ty_selector_val+0x2fc>
    1144:      	mov	w0, #0x1                // =1
    1148:      	ret
    114c:      	cmp	w9, #0x11
    1150:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    1154:      	ldr	w10, [x0, #0x18]
    1158:      	cmp	w10, w8
    115c:      	b.hs	0x11d8 <filter_16ty_selector_val+0x318>
    1160:      	mov	w0, #0x1                // =1
    1164:      	ret
    1168:      	cmp	w9, #0x11
    116c:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    1170:      	ldr	w10, [x0, #0x18]
    1174:      	cmp	w10, w8
    1178:      	b.ls	0x11f4 <filter_16ty_selector_val+0x334>
    117c:      	mov	w0, #0x1                // =1
    1180:      	ret
    1184:      	cmp	w9, #0x15
    1188:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    118c:      	ldr	w9, [x0, #0x1c]
    1190:      	cmp	w9, w8
    1194:      	b.ge	0x1210 <filter_16ty_selector_val+0x350>
    1198:      	mov	w0, #0x1                // =1
    119c:      	ret
    11a0:      	cmp	w9, #0x15
    11a4:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    11a8:      	ldr	w9, [x0, #0x1c]
    11ac:      	cmp	w9, w8
    11b0:      	b.le	0x1210 <filter_16ty_selector_val+0x350>
    11b4:      	mov	w0, #0x1                // =1
    11b8:      	ret
    11bc:      	cmp	w9, #0x15
    11c0:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    11c4:      	ldr	w9, [x0, #0x1c]
    11c8:      	tst	w9, w8
    11cc:      	b.eq	0x1210 <filter_16ty_selector_val+0x350>
    11d0:      	mov	w0, #0x1                // =1
    11d4:      	ret
    11d8:      	cmp	w9, #0x15
    11dc:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    11e0:      	ldr	w9, [x0, #0x1c]
    11e4:      	cmp	w9, w8
    11e8:      	b.hs	0x1210 <filter_16ty_selector_val+0x350>
    11ec:      	mov	w0, #0x1                // =1
    11f0:      	ret
    11f4:      	cmp	w9, #0x15
    11f8:      	b.lo	0x1210 <filter_16ty_selector_val+0x350>
    11fc:      	ldr	w9, [x0, #0x1c]
    1200:      	cmp	w9, w8
    1204:      	b.ls	0x1210 <filter_16ty_selector_val+0x350>
    1208:      	mov	w0, #0x1                // =1
    120c:      	ret
    1210:      	mov	x0, xzr
    1214:      	ret
    1218:      	nop
    121c:      	nop

0000000000001220 <filter_16ty_map>:
    1220:      	sub	sp, sp, #0x30
    1224:      	str	x30, [sp, #0x10]
    1228:      	stp	x20, x19, [sp, #0x20]
    122c:      	ldrb	w8, [x0, #0x10]
    1230:      	mov	x19, x0
    1234:      	adrp	x0, 0x1000 <filter_16ty_selector_val+0x140>
    1238:      	add	x9, sp, #0x1c
    123c:      	str	w8, [sp, #0x1c]
    1240:      	mov	w8, #0x1                // =1
    1244:      	mov	x20, x1
    1248:      	add	x1, sp, #0x1c
    124c:      	ldr	x0, [x0]
    1250:      	blr	x8
    1254:      	cbz	x0, 0x12c8 <filter_16ty_map+0xa8>
    1258:      	ldrh	w8, [x20]
    125c:      	mov	w9, #0x1                // =1
    1260:      	add	x1, sp, #0x8
    1264:      	mov	w20, #0x1               // =1
    1268:      	str	x8, [sp, #0x8]
    126c:      	add	x8, sp, #0x8
    1270:      	blr	x9
    1274:      	ldr	w9, [x19, #0x4]
    1278:      	mov	w8, wzr
    127c:      	cmp	w9, #0x1d
    1280:      	b.hi	0x12c4 <filter_16ty_map+0xa4>
    1284:      	mov	w11, #0x8400            // =33792
    1288:      	lsl	w10, w20, w9
    128c:      	movk	w11, #0x3003, lsl #16
    1290:      	tst	w10, w11
    1294:      	b.eq	0x12a4 <filter_16ty_map+0x84>
    1298:      	cmp	x0, #0x0
    129c:      	cset	w8, ne
    12a0:      	b	0x12c4 <filter_16ty_map+0xa4>
    12a4:      	mov	w10, #0x1               // =1
    12a8:      	lsl	w9, w10, w9
    12ac:      	mov	w10, #0x800             // =2048
    12b0:      	movk	w10, #0xc, lsl #16
    12b4:      	tst	w9, w10
    12b8:      	b.eq	0x12c4 <filter_16ty_map+0xa4>
    12bc:      	cmp	x0, #0x0
    12c0:      	cset	w8, eq
    12c4:      	mov	w0, w8
    12c8:      	ldp	x20, x19, [sp, #0x20]
    12cc:      	ldr	x30, [sp, #0x10]
    12d0:      	add	sp, sp, #0x30
    12d4:      	ret
    12d8:      	nop
    12dc:      	nop

00000000000012e0 <filter_16ty_range>:
    12e0:      	ldr	w9, [x0, #0xc]
    12e4:      	ldr	w8, [x0, #0x4]
    12e8:      	mov	w10, #0x1               // =1
    12ec:      	cmp	w9, #0xc
    12f0:      	lsl	w9, w10, w9
    12f4:      	mov	w10, #0x1402            // =5122
    12f8:      	and	w9, w9, w10
    12fc:      	ccmp	w9, #0x0, #0x4, ls
    1300:      	b.eq	0x1400 <filter_16ty_range+0x120>
    1304:      	ldrsh	w10, [x1]
    1308:      	cmp	w8, #0x1f
    130c:      	b.ne	0x1394 <filter_16ty_range+0xb4>
    1310:      	ldr	w9, [x0, #0x10]
    1314:      	cmp	w9, w10
    1318:      	b.gt	0x1328 <filter_16ty_range+0x48>
    131c:      	ldr	w9, [x0, #0x14]
    1320:      	cmp	w9, w10
    1324:      	b.ge	0x1424 <filter_16ty_range+0x144>
    1328:      	ldr	w9, [x0, #0x8]
    132c:      	cmp	w9, #0x11
    1330:      	b.lo	0x1510 <filter_16ty_range+0x230>
    1334:      	ldr	w11, [x0, #0x18]
    1338:      	cmp	w11, w10
    133c:      	b.gt	0x134c <filter_16ty_range+0x6c>
    1340:      	ldr	w11, [x0, #0x1c]
    1344:      	cmp	w11, w10
    1348:      	b.ge	0x1424 <filter_16ty_range+0x144>
    134c:      	cmp	w9, #0x19
    1350:      	b.lo	0x1510 <filter_16ty_range+0x230>
    1354:      	ldr	w11, [x0, #0x20]
    1358:      	cmp	w11, w10
    135c:      	b.gt	0x136c <filter_16ty_range+0x8c>
    1360:      	ldr	w11, [x0, #0x24]
    1364:      	cmp	w11, w10
    1368:      	b.ge	0x1424 <filter_16ty_range+0x144>
    136c:      	cmp	w9, #0x21
    1370:      	b.lo	0x1510 <filter_16ty_range+0x230>
    1374:      	ldr	w11, [x0, #0x28]
    1378:      	mov	w9, wzr
    137c:      	cmp	w11, w10
    1380:      	b.gt	0x1500 <filter_16ty_range+0x220>
    1384:      	ldr	w11, [x0, #0x2c]
    1388:      	cmp	w11, w10
    138c:      	b.ge	0x1424 <filter_16ty_range+0x144>
    1390:      	b	0x1500 <filter_16ty_range+0x220>
    1394:      	ldp	w9, w12, [x0, #0x10]
    1398:      	ldr	w11, [x0, #0x8]
    139c:      	cmp	w9, w10
    13a0:      	ccmp	w12, w10, #0x8, le
    13a4:      	cset	w9, ge
    13a8:      	cmp	w11, #0x11
    13ac:      	b.lo	0x1500 <filter_16ty_range+0x220>
    13b0:      	ldp	w12, w13, [x0, #0x18]
    13b4:      	cmp	w12, w10
    13b8:      	ccmp	w13, w10, #0x8, le
    13bc:      	csinc	w9, w9, wzr, lt
    13c0:      	cmp	w11, #0x19
    13c4:      	b.lo	0x1500 <filter_16ty_range+0x220>
    13c8:      	ldp	w12, w13, [x0, #0x20]
    13cc:      	cmp	w12, w10
    13d0:      	ccmp	w13, w10, #0x8, le
    13d4:      	csinc	w9, w9, wzr, lt
    13d8:      	cmp	w11, #0x21
    13dc:      	b.lo	0x1500 <filter_16ty_range+0x220>
    13e0:      	ldp	w11, w12, [x0, #0x28]
    13e4:      	cmp	w11, w10
    13e8:      	ccmp	w12, w10, #0x8, le
    13ec:      	csinc	w9, w9, wzr, lt
    13f0:      	cmp	w8, #0x20
    13f4:      	eor	w8, w9, #0x1
    13f8:      	csel	w0, wzr, w8, ne
    13fc:      	ret
    1400:      	ldrh	w10, [x1]
    1404:      	cmp	w8, #0x1f
    1408:      	b.ne	0x142c <filter_16ty_range+0x14c>
    140c:      	ldr	w9, [x0, #0x10]
    1410:      	cmp	w9, w10
    1414:      	b.hi	0x1498 <filter_16ty_range+0x1b8>
    1418:      	ldr	w9, [x0, #0x14]
    141c:      	cmp	w9, w10
    1420:      	b.lo	0x1498 <filter_16ty_range+0x1b8>
    1424:      	mov	w0, #0x1                // =1
    1428:      	ret
    142c:      	ldp	w9, w12, [x0, #0x10]
    1430:      	ldr	w11, [x0, #0x8]
    1434:      	cmp	w9, w10
    1438:      	ccmp	w12, w10, #0x0, ls
    143c:      	cset	w9, hs
    1440:      	cmp	w11, #0x11
    1444:      	b.lo	0x1500 <filter_16ty_range+0x220>
    1448:      	ldp	w12, w13, [x0, #0x18]
    144c:      	cmp	w12, w10
    1450:      	ccmp	w13, w10, #0x0, ls
    1454:      	csinc	w9, w9, wzr, lo
    1458:      	cmp	w11, #0x19
    145c:      	b.lo	0x1500 <filter_16ty_range+0x220>
    1460:      	ldp	w12, w13, [x0, #0x20]
    1464:      	cmp	w12, w10
    1468:      	ccmp	w13, w10, #0x0, ls
    146c:      	csinc	w9, w9, wzr, lo
    1470:      	cmp	w11, #0x21
    1474:      	b.lo	0x1500 <filter_16ty_range+0x220>
    1478:      	ldp	w11, w12, [x0, #0x28]
    147c:      	cmp	w11, w10
    1480:      	ccmp	w12, w10, #0x0, ls
    1484:      	csinc	w9, w9, wzr, lo
    1488:      	cmp	w8, #0x20
    148c:      	eor	w8, w9, #0x1
    1490:      	csel	w0, wzr, w8, ne
    1494:      	ret
    1498:      	ldr	w9, [x0, #0x8]
    149c:      	cmp	w9, #0x11
    14a0:      	b.lo	0x1510 <filter_16ty_range+0x230>
    14a4:      	ldr	w11, [x0, #0x18]
    14a8:      	cmp	w11, w10
    14ac:      	b.hi	0x14bc <filter_16ty_range+0x1dc>
    14b0:      	ldr	w11, [x0, #0x1c]
    14b4:      	cmp	w11, w10
    14b8:      	b.hs	0x1424 <filter_16ty_range+0x144>
    14bc:      	cmp	w9, #0x19
    14c0:      	b.lo	0x1510 <filter_16ty_range+0x230>
    14c4:      	ldr	w11, [x0, #0x20]
    14c8:      	cmp	w11, w10
    14cc:      	b.hi	0x14dc <filter_16ty_range+0x1fc>
    14d0:      	ldr	w11, [x0, #0x24]
    14d4:      	cmp	w11, w10
    14d8:      	b.hs	0x1424 <filter_16ty_range+0x144>
    14dc:      	cmp	w9, #0x21
    14e0:      	b.lo	0x1510 <filter_16ty_range+0x230>
    14e4:      	ldr	w11, [x0, #0x28]
    14e8:      	mov	w9, wzr
    14ec:      	cmp	w11, w10
    14f0:      	b.hi	0x1500 <filter_16ty_range+0x220>
    14f4:      	ldr	w11, [x0, #0x2c]
    14f8:      	cmp	w11, w10
    14fc:      	b.hs	0x1424 <filter_16ty_range+0x144>
    1500:      	cmp	w8, #0x20
    1504:      	eor	w8, w9, #0x1
    1508:      	csel	w0, wzr, w8, ne
    150c:      	ret
    1510:      	mov	w9, wzr
    1514:      	cmp	w8, #0x20
    1518:      	eor	w8, w9, #0x1
    151c:      	csel	w0, wzr, w8, ne
    1520:      	ret
    1524:      	nop
    1528:      	nop
    152c:      	nop

0000000000001530 <filter_8ty_selector_val>:
    1530:      	ldr	w8, [x0, #0x4]
    1534:      	cmp	w8, #0x25
    1538:      	b.hi	0x15ac <filter_8ty_selector_val+0x7c>
    153c:      	mov	x10, #0x40              // =64
    1540:      	mov	w9, #0x1                // =1
    1544:      	movk	x10, #0xc00, lsl #16
    1548:      	lsl	x9, x9, x8
    154c:      	movk	x10, #0x20, lsl #32
    1550:      	tst	x9, x10
    1554:      	b.eq	0x1560 <filter_8ty_selector_val+0x30>
    1558:      	mov	w0, #0x1                // =1
    155c:      	ret
    1560:      	mov	w9, #0x1                // =1
    1564:      	lsl	x9, x9, x8
    1568:      	tst	x9, #0x18
    156c:      	b.eq	0x158c <filter_8ty_selector_val+0x5c>
    1570:      	ldrb	w9, [x1]
    1574:      	ldr	w10, [x0, #0x10]
    1578:      	cmp	w10, w9
    157c:      	b.ne	0x162c <filter_8ty_selector_val+0xfc>
    1580:      	cmp	w8, #0x3
    1584:      	cset	w0, eq
    1588:      	ret
    158c:      	cmp	x8, #0xc
    1590:      	b.ne	0x15ac <filter_8ty_selector_val+0x7c>
    1594:      	ldrb	w8, [x1]
    1598:      	ldr	w9, [x0, #0x10]
    159c:      	tst	w9, w8
    15a0:      	b.eq	0x16d8 <filter_8ty_selector_val+0x1a8>
    15a4:      	mov	w0, #0x1                // =1
    15a8:      	ret
    15ac:      	cmp	w8, #0x1
    15b0:      	b.eq	0x15f4 <filter_8ty_selector_val+0xc4>
    15b4:      	cmp	w8, #0x2
    15b8:      	b.ne	0x1880 <filter_8ty_selector_val+0x350>
    15bc:      	ldr	w8, [x0, #0xc]
    15c0:      	cmp	w8, #0xc
    15c4:      	b.hi	0x1710 <filter_8ty_selector_val+0x1e0>
    15c8:      	mov	w9, #0x1                // =1
    15cc:      	lsl	w8, w9, w8
    15d0:      	mov	w9, #0x1402             // =5122
    15d4:      	tst	w8, w9
    15d8:      	b.eq	0x1710 <filter_8ty_selector_val+0x1e0>
    15dc:      	ldrsb	w8, [x1]
    15e0:      	ldr	w9, [x0, #0x10]
    15e4:      	cmp	w9, w8
    15e8:      	b.le	0x16b8 <filter_8ty_selector_val+0x188>
    15ec:      	mov	w0, #0x1                // =1
    15f0:      	ret
    15f4:      	ldr	w8, [x0, #0xc]
    15f8:      	cmp	w8, #0xc
    15fc:      	b.hi	0x16f8 <filter_8ty_selector_val+0x1c8>
    1600:      	mov	w9, #0x1                // =1
    1604:      	lsl	w8, w9, w8
    1608:      	mov	w9, #0x1402             // =5122
    160c:      	tst	w8, w9
    1610:      	b.eq	0x16f8 <filter_8ty_selector_val+0x1c8>
    1614:      	ldrsb	w8, [x1]
    1618:      	ldr	w9, [x0, #0x10]
    161c:      	cmp	w9, w8
    1620:      	b.ge	0x1698 <filter_8ty_selector_val+0x168>
    1624:      	mov	w0, #0x1                // =1
    1628:      	ret
    162c:      	ldr	w10, [x0, #0x8]
    1630:      	cmp	w10, #0xd
    1634:      	b.lo	0x166c <filter_8ty_selector_val+0x13c>
    1638:      	ldr	w11, [x0, #0x14]
    163c:      	cmp	w11, w9
    1640:      	b.eq	0x1580 <filter_8ty_selector_val+0x50>
    1644:      	cmp	w10, #0x11
    1648:      	b.lo	0x166c <filter_8ty_selector_val+0x13c>
    164c:      	ldr	w11, [x0, #0x18]
    1650:      	cmp	w11, w9
    1654:      	b.eq	0x1580 <filter_8ty_selector_val+0x50>
    1658:      	cmp	w10, #0x15
    165c:      	b.lo	0x166c <filter_8ty_selector_val+0x13c>
    1660:      	ldr	w10, [x0, #0x1c]
    1664:      	cmp	w10, w9
    1668:      	b.eq	0x1580 <filter_8ty_selector_val+0x50>
    166c:      	cmp	w8, #0x25
    1670:      	b.hi	0x1880 <filter_8ty_selector_val+0x350>
    1674:      	mov	w9, #0x1                // =1
    1678:      	lsl	x8, x9, x8
    167c:      	mov	x9, #0x50               // =80
    1680:      	movk	x9, #0xc00, lsl #16
    1684:      	movk	x9, #0x20, lsl #32
    1688:      	tst	x8, x9
    168c:      	b.eq	0x1880 <filter_8ty_selector_val+0x350>
    1690:      	mov	w0, #0x1                // =1
    1694:      	ret
    1698:      	ldr	w9, [x0, #0x8]
    169c:      	cmp	w9, #0xd
    16a0:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    16a4:      	ldr	w10, [x0, #0x14]
    16a8:      	cmp	w10, w8
    16ac:      	b.ge	0x1768 <filter_8ty_selector_val+0x238>
    16b0:      	mov	w0, #0x1                // =1
    16b4:      	ret
    16b8:      	ldr	w9, [x0, #0x8]
    16bc:      	cmp	w9, #0xd
    16c0:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    16c4:      	ldr	w10, [x0, #0x14]
    16c8:      	cmp	w10, w8
    16cc:      	b.le	0x1784 <filter_8ty_selector_val+0x254>
    16d0:      	mov	w0, #0x1                // =1
    16d4:      	ret
    16d8:      	ldr	w9, [x0, #0x8]
    16dc:      	cmp	w9, #0xd
    16e0:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    16e4:      	ldr	w10, [x0, #0x14]
    16e8:      	tst	w10, w8
    16ec:      	b.eq	0x17a0 <filter_8ty_selector_val+0x270>
    16f0:      	mov	w0, #0x1                // =1
    16f4:      	ret
    16f8:      	ldrb	w8, [x1]
    16fc:      	ldr	w9, [x0, #0x10]
    1700:      	cmp	w9, w8
    1704:      	b.hs	0x1728 <filter_8ty_selector_val+0x1f8>
    1708:      	mov	w0, #0x1                // =1
    170c:      	ret
    1710:      	ldrb	w8, [x1]
    1714:      	ldr	w9, [x0, #0x10]
    1718:      	cmp	w9, w8
    171c:      	b.ls	0x1748 <filter_8ty_selector_val+0x218>
    1720:      	mov	w0, #0x1                // =1
    1724:      	ret
    1728:      	ldr	w9, [x0, #0x8]
    172c:      	cmp	w9, #0xd
    1730:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    1734:      	ldr	w10, [x0, #0x14]
    1738:      	cmp	w10, w8
    173c:      	b.hs	0x17bc <filter_8ty_selector_val+0x28c>
    1740:      	mov	w0, #0x1                // =1
    1744:      	ret
    1748:      	ldr	w9, [x0, #0x8]
    174c:      	cmp	w9, #0xd
    1750:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    1754:      	ldr	w10, [x0, #0x14]
    1758:      	cmp	w10, w8
    175c:      	b.ls	0x17d8 <filter_8ty_selector_val+0x2a8>
    1760:      	mov	w0, #0x1                // =1
    1764:      	ret
    1768:      	cmp	w9, #0x11
    176c:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    1770:      	ldr	w10, [x0, #0x18]
    1774:      	cmp	w10, w8
    1778:      	b.ge	0x17f4 <filter_8ty_selector_val+0x2c4>
    177c:      	mov	w0, #0x1                // =1
    1780:      	ret
    1784:      	cmp	w9, #0x11
    1788:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    178c:      	ldr	w10, [x0, #0x18]
    1790:      	cmp	w10, w8
    1794:      	b.le	0x1810 <filter_8ty_selector_val+0x2e0>
    1798:      	mov	w0, #0x1                // =1
    179c:      	ret
    17a0:      	cmp	w9, #0x11
    17a4:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    17a8:      	ldr	w10, [x0, #0x18]
    17ac:      	tst	w10, w8
    17b0:      	b.eq	0x182c <filter_8ty_selector_val+0x2fc>
    17b4:      	mov	w0, #0x1                // =1
    17b8:      	ret
    17bc:      	cmp	w9, #0x11
    17c0:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    17c4:      	ldr	w10, [x0, #0x18]
    17c8:      	cmp	w10, w8
    17cc:      	b.hs	0x1848 <filter_8ty_selector_val+0x318>
    17d0:      	mov	w0, #0x1                // =1
    17d4:      	ret
    17d8:      	cmp	w9, #0x11
    17dc:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    17e0:      	ldr	w10, [x0, #0x18]
    17e4:      	cmp	w10, w8
    17e8:      	b.ls	0x1864 <filter_8ty_selector_val+0x334>
    17ec:      	mov	w0, #0x1                // =1
    17f0:      	ret
    17f4:      	cmp	w9, #0x15
    17f8:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    17fc:      	ldr	w9, [x0, #0x1c]
    1800:      	cmp	w9, w8
    1804:      	b.ge	0x1880 <filter_8ty_selector_val+0x350>
    1808:      	mov	w0, #0x1                // =1
    180c:      	ret
    1810:      	cmp	w9, #0x15
    1814:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    1818:      	ldr	w9, [x0, #0x1c]
    181c:      	cmp	w9, w8
    1820:      	b.le	0x1880 <filter_8ty_selector_val+0x350>
    1824:      	mov	w0, #0x1                // =1
    1828:      	ret
    182c:      	cmp	w9, #0x15
    1830:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    1834:      	ldr	w9, [x0, #0x1c]
    1838:      	tst	w9, w8
    183c:      	b.eq	0x1880 <filter_8ty_selector_val+0x350>
    1840:      	mov	w0, #0x1                // =1
    1844:      	ret
    1848:      	cmp	w9, #0x15
    184c:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    1850:      	ldr	w9, [x0, #0x1c]
    1854:      	cmp	w9, w8
    1858:      	b.hs	0x1880 <filter_8ty_selector_val+0x350>
    185c:      	mov	w0, #0x1                // =1
    1860:      	ret
    1864:      	cmp	w9, #0x15
    1868:      	b.lo	0x1880 <filter_8ty_selector_val+0x350>
    186c:      	ldr	w9, [x0, #0x1c]
    1870:      	cmp	w9, w8
    1874:      	b.ls	0x1880 <filter_8ty_selector_val+0x350>
    1878:      	mov	w0, #0x1                // =1
    187c:      	ret
    1880:      	mov	x0, xzr
    1884:      	ret
    1888:      	nop
    188c:      	nop

0000000000001890 <filter_8ty_map>:
    1890:      	sub	sp, sp, #0x30
    1894:      	str	x30, [sp, #0x10]
    1898:      	stp	x20, x19, [sp, #0x20]
    189c:      	ldrb	w8, [x0, #0x10]
    18a0:      	mov	x19, x0
    18a4:      	adrp	x0, 0x1000 <filter_16ty_selector_val+0x140>
    18a8:      	add	x9, sp, #0x1c
    18ac:      	str	w8, [sp, #0x1c]
    18b0:      	mov	w8, #0x1                // =1
    18b4:      	mov	x20, x1
    18b8:      	add	x1, sp, #0x1c
    18bc:      	ldr	x0, [x0]
    18c0:      	blr	x8
    18c4:      	cbz	x0, 0x1938 <filter_8ty_map+0xa8>
    18c8:      	ldrb	w8, [x20]
    18cc:      	mov	w9, #0x1                // =1
    18d0:      	add	x1, sp, #0x8
    18d4:      	mov	w20, #0x1               // =1
    18d8:      	str	x8, [sp, #0x8]
    18dc:      	add	x8, sp, #0x8
    18e0:      	blr	x9
    18e4:      	ldr	w9, [x19, #0x4]
    18e8:      	mov	w8, wzr
    18ec:      	cmp	w9, #0x1d
    18f0:      	b.hi	0x1934 <filter_8ty_map+0xa4>
    18f4:      	mov	w11, #0x8400            // =33792
    18f8:      	lsl	w10, w20, w9
    18fc:      	movk	w11, #0x3003, lsl #16
    1900:      	tst	w10, w11
    1904:      	b.eq	0x1914 <filter_8ty_map+0x84>
    1908:      	cmp	x0, #0x0
    190c:      	cset	w8, ne
    1910:      	b	0x1934 <filter_8ty_map+0xa4>
    1914:      	mov	w10, #0x1               // =1
    1918:      	lsl	w9, w10, w9
    191c:      	mov	w10, #0x800             // =2048
    1920:      	movk	w10, #0xc, lsl #16
    1924:      	tst	w9, w10
    1928:      	b.eq	0x1934 <filter_8ty_map+0xa4>
    192c:      	cmp	x0, #0x0
    1930:      	cset	w8, eq
    1934:      	mov	w0, w8
    1938:      	ldp	x20, x19, [sp, #0x20]
    193c:      	ldr	x30, [sp, #0x10]
    1940:      	add	sp, sp, #0x30
    1944:      	ret
    1948:      	nop
    194c:      	nop

0000000000001950 <filter_8ty_range>:
    1950:      	ldr	w9, [x0, #0xc]
    1954:      	ldr	w8, [x0, #0x4]
    1958:      	mov	w10, #0x1               // =1
    195c:      	cmp	w9, #0xc
    1960:      	lsl	w9, w10, w9
    1964:      	mov	w10, #0x1402            // =5122
    1968:      	and	w9, w9, w10
    196c:      	ccmp	w9, #0x0, #0x4, ls
    1970:      	b.eq	0x1a70 <filter_8ty_range+0x120>
    1974:      	ldrsb	w10, [x1]
    1978:      	cmp	w8, #0x1f
    197c:      	b.ne	0x1a04 <filter_8ty_range+0xb4>
    1980:      	ldr	w9, [x0, #0x10]
    1984:      	cmp	w9, w10
    1988:      	b.gt	0x1998 <filter_8ty_range+0x48>
    198c:      	ldr	w9, [x0, #0x14]
    1990:      	cmp	w9, w10
    1994:      	b.ge	0x1a94 <filter_8ty_range+0x144>
    1998:      	ldr	w9, [x0, #0x8]
    199c:      	cmp	w9, #0x11
    19a0:      	b.lo	0x1b80 <filter_8ty_range+0x230>
    19a4:      	ldr	w11, [x0, #0x18]
    19a8:      	cmp	w11, w10
    19ac:      	b.gt	0x19bc <filter_8ty_range+0x6c>
    19b0:      	ldr	w11, [x0, #0x1c]
    19b4:      	cmp	w11, w10
    19b8:      	b.ge	0x1a94 <filter_8ty_range+0x144>
    19bc:      	cmp	w9, #0x19
    19c0:      	b.lo	0x1b80 <filter_8ty_range+0x230>
    19c4:      	ldr	w11, [x0, #0x20]
    19c8:      	cmp	w11, w10
    19cc:      	b.gt	0x19dc <filter_8ty_range+0x8c>
    19d0:      	ldr	w11, [x0, #0x24]
    19d4:      	cmp	w11, w10
    19d8:      	b.ge	0x1a94 <filter_8ty_range+0x144>
    19dc:      	cmp	w9, #0x21
    19e0:      	b.lo	0x1b80 <filter_8ty_range+0x230>
    19e4:      	ldr	w11, [x0, #0x28]
    19e8:      	mov	w9, wzr
    19ec:      	cmp	w11, w10
    19f0:      	b.gt	0x1b70 <filter_8ty_range+0x220>
    19f4:      	ldr	w11, [x0, #0x2c]
    19f8:      	cmp	w11, w10
    19fc:      	b.ge	0x1a94 <filter_8ty_range+0x144>
    1a00:      	b	0x1b70 <filter_8ty_range+0x220>
    1a04:      	ldp	w9, w12, [x0, #0x10]
    1a08:      	ldr	w11, [x0, #0x8]
    1a0c:      	cmp	w9, w10
    1a10:      	ccmp	w12, w10, #0x8, le
    1a14:      	cset	w9, ge
    1a18:      	cmp	w11, #0x11
    1a1c:      	b.lo	0x1b70 <filter_8ty_range+0x220>
    1a20:      	ldp	w12, w13, [x0, #0x18]
    1a24:      	cmp	w12, w10
    1a28:      	ccmp	w13, w10, #0x8, le
    1a2c:      	csinc	w9, w9, wzr, lt
    1a30:      	cmp	w11, #0x19
    1a34:      	b.lo	0x1b70 <filter_8ty_range+0x220>
    1a38:      	ldp	w12, w13, [x0, #0x20]
    1a3c:      	cmp	w12, w10
    1a40:      	ccmp	w13, w10, #0x8, le
    1a44:      	csinc	w9, w9, wzr, lt
    1a48:      	cmp	w11, #0x21
    1a4c:      	b.lo	0x1b70 <filter_8ty_range+0x220>
    1a50:      	ldp	w11, w12, [x0, #0x28]
    1a54:      	cmp	w11, w10
    1a58:      	ccmp	w12, w10, #0x8, le
    1a5c:      	csinc	w9, w9, wzr, lt
    1a60:      	cmp	w8, #0x20
    1a64:      	eor	w8, w9, #0x1
    1a68:      	csel	w0, wzr, w8, ne
    1a6c:      	ret
    1a70:      	ldrb	w10, [x1]
    1a74:      	cmp	w8, #0x1f
    1a78:      	b.ne	0x1a9c <filter_8ty_range+0x14c>
    1a7c:      	ldr	w9, [x0, #0x10]
    1a80:      	cmp	w9, w10
    1a84:      	b.hi	0x1b08 <filter_8ty_range+0x1b8>
    1a88:      	ldr	w9, [x0, #0x14]
    1a8c:      	cmp	w9, w10
    1a90:      	b.lo	0x1b08 <filter_8ty_range+0x1b8>
    1a94:      	mov	w0, #0x1                // =1
    1a98:      	ret
    1a9c:      	ldp	w9, w12, [x0, #0x10]
    1aa0:      	ldr	w11, [x0, #0x8]
    1aa4:      	cmp	w9, w10
    1aa8:      	ccmp	w12, w10, #0x0, ls
    1aac:      	cset	w9, hs
    1ab0:      	cmp	w11, #0x11
    1ab4:      	b.lo	0x1b70 <filter_8ty_range+0x220>
    1ab8:      	ldp	w12, w13, [x0, #0x18]
    1abc:      	cmp	w12, w10
    1ac0:      	ccmp	w13, w10, #0x0, ls
    1ac4:      	csinc	w9, w9, wzr, lo
    1ac8:      	cmp	w11, #0x19
    1acc:      	b.lo	0x1b70 <filter_8ty_range+0x220>
    1ad0:      	ldp	w12, w13, [x0, #0x20]
    1ad4:      	cmp	w12, w10
    1ad8:      	ccmp	w13, w10, #0x0, ls
    1adc:      	csinc	w9, w9, wzr, lo
    1ae0:      	cmp	w11, #0x21
    1ae4:      	b.lo	0x1b70 <filter_8ty_range+0x220>
    1ae8:      	ldp	w11, w12, [x0, #0x28]
    1aec:      	cmp	w11, w10
    1af0:      	ccmp	w12, w10, #0x0, ls
    1af4:      	csinc	w9, w9, wzr, lo
    1af8:      	cmp	w8, #0x20
    1afc:      	eor	w8, w9, #0x1
    1b00:      	csel	w0, wzr, w8, ne
    1b04:      	ret
    1b08:      	ldr	w9, [x0, #0x8]
    1b0c:      	cmp	w9, #0x11
    1b10:      	b.lo	0x1b80 <filter_8ty_range+0x230>
    1b14:      	ldr	w11, [x0, #0x18]
    1b18:      	cmp	w11, w10
    1b1c:      	b.hi	0x1b2c <filter_8ty_range+0x1dc>
    1b20:      	ldr	w11, [x0, #0x1c]
    1b24:      	cmp	w11, w10
    1b28:      	b.hs	0x1a94 <filter_8ty_range+0x144>
    1b2c:      	cmp	w9, #0x19
    1b30:      	b.lo	0x1b80 <filter_8ty_range+0x230>
    1b34:      	ldr	w11, [x0, #0x20]
    1b38:      	cmp	w11, w10
    1b3c:      	b.hi	0x1b4c <filter_8ty_range+0x1fc>
    1b40:      	ldr	w11, [x0, #0x24]
    1b44:      	cmp	w11, w10
    1b48:      	b.hs	0x1a94 <filter_8ty_range+0x144>
    1b4c:      	cmp	w9, #0x21
    1b50:      	b.lo	0x1b80 <filter_8ty_range+0x230>
    1b54:      	ldr	w11, [x0, #0x28]
    1b58:      	mov	w9, wzr
    1b5c:      	cmp	w11, w10
    1b60:      	b.hi	0x1b70 <filter_8ty_range+0x220>
    1b64:      	ldr	w11, [x0, #0x2c]
    1b68:      	cmp	w11, w10
    1b6c:      	b.hs	0x1a94 <filter_8ty_range+0x144>
    1b70:      	cmp	w8, #0x20
    1b74:      	eor	w8, w9, #0x1
    1b78:      	csel	w0, wzr, w8, ne
    1b7c:      	ret
    1b80:      	mov	w9, wzr
    1b84:      	cmp	w8, #0x20
    1b88:      	eor	w8, w9, #0x1
    1b8c:      	csel	w0, wzr, w8, ne
    1b90:      	ret
    1b94:      	nop
    1b98:      	nop
    1b9c:      	nop

0000000000001ba0 <filter_file_buf>:
    1ba0:      	stp	x30, x19, [sp, #-0x10]!
    1ba4:      	ldr	w2, [x1]
    1ba8:      	ldr	w8, [x0, #0x4]
    1bac:      	mov	x19, x0
    1bb0:      	cbnz	w2, 0x1bcc <filter_file_buf+0x2c>
    1bb4:      	and	w9, w8, #0xfffffffe
    1bb8:      	cmp	w9, #0x24
    1bbc:      	b.eq	0x1bcc <filter_file_buf+0x2c>
    1bc0:      	mov	x0, xzr
    1bc4:      	ldp	x30, x19, [sp], #0x10
    1bc8:      	ret
    1bcc:      	cmp	w8, #0x25
    1bd0:      	b.hi	0x1c2c <filter_file_buf+0x8c>
    1bd4:      	mov	w9, #0x1                // =1
    1bd8:      	mov	w10, #0x100             // =256
    1bdc:      	lsl	x9, x9, x8
    1be0:      	movk	w10, #0x400, lsl #16
    1be4:      	tst	x9, x10
    1be8:      	b.ne	0x1c70 <filter_file_buf+0xd0>
    1bec:      	mov	w9, #0x1                // =1
    1bf0:      	mov	w10, #0x200             // =512
    1bf4:      	lsl	x9, x9, x8
    1bf8:      	movk	w10, #0x800, lsl #16
    1bfc:      	tst	x9, x10
    1c00:      	b.ne	0x1c54 <filter_file_buf+0xb4>
    1c04:      	mov	w9, #0x1                // =1
    1c08:      	lsl	x9, x9, x8
    1c0c:      	tst	x9, #0x3000000000
    1c10:      	b.eq	0x1c2c <filter_file_buf+0x8c>
    1c14:      	mov	x0, x19
    1c18:      	bl	0x2870 <filter_file_type>
    1c1c:      	ldr	w8, [x19, #0x4]
    1c20:      	cmp	w8, #0x25
    1c24:      	b.ls	0x1c98 <filter_file_buf+0xf8>
    1c28:      	b	0x1cbc <filter_file_buf+0x11c>
    1c2c:      	sub	w9, w8, #0x3
    1c30:      	cmp	w9, #0x2
    1c34:      	b.hs	0x1c8c <filter_file_buf+0xec>
    1c38:      	add	x1, x1, #0x4
    1c3c:      	mov	x0, x19
    1c40:      	bl	0x22b0 <filter_char_buf_equal>
    1c44:      	ldr	w8, [x19, #0x4]
    1c48:      	cmp	w8, #0x25
    1c4c:      	b.ls	0x1c98 <filter_file_buf+0xf8>
    1c50:      	b	0x1cbc <filter_file_buf+0x11c>
    1c54:      	ldr	w0, [x19, #0x10]
    1c58:      	add	x1, x1, #0x4
    1c5c:      	bl	0x27a0 <filter_char_buf_postfix>
    1c60:      	ldr	w8, [x19, #0x4]
    1c64:      	cmp	w8, #0x25
    1c68:      	b.ls	0x1c98 <filter_file_buf+0xf8>
    1c6c:      	b	0x1cbc <filter_file_buf+0x11c>
    1c70:      	ldr	w0, [x19, #0x10]
    1c74:      	add	x1, x1, #0x4
    1c78:      	bl	0x26e0 <filter_char_buf_prefix>
    1c7c:      	ldr	w8, [x19, #0x4]
    1c80:      	cmp	w8, #0x25
    1c84:      	b.ls	0x1c98 <filter_file_buf+0xf8>
    1c88:      	b	0x1cbc <filter_file_buf+0x11c>
    1c8c:      	mov	x0, xzr
    1c90:      	cmp	w8, #0x25
    1c94:      	b.hi	0x1cbc <filter_file_buf+0x11c>
    1c98:      	mov	w8, w8
    1c9c:      	mov	w9, #0x1                // =1
    1ca0:      	lsl	x8, x9, x8
    1ca4:      	mov	x9, #0x50               // =80
    1ca8:      	movk	x9, #0xc00, lsl #16
    1cac:      	movk	x9, #0x20, lsl #32
    1cb0:      	tst	x8, x9
    1cb4:      	b.eq	0x1cbc <filter_file_buf+0x11c>
    1cb8:      	eor	x0, x0, #0x1
    1cbc:      	ldp	x30, x19, [sp], #0x10
    1cc0:      	ret
    1cc4:      	nop
    1cc8:      	nop
    1ccc:      	nop

0000000000001cd0 <filter_char_buf>:
    1cd0:      	stp	x30, x19, [sp, #-0x10]!
    1cd4:      	mov	w8, w2
    1cd8:      	mov	x19, x0
    1cdc:      	add	x9, x1, w2, sxtw
    1ce0:      	ldur	w2, [x9, #-0x4]
    1ce4:      	add	x1, x1, w8, uxtw
    1ce8:      	ldr	w8, [x0, #0x4]
    1cec:      	mov	x0, xzr
    1cf0:      	cmp	w8, #0x19
    1cf4:      	b.gt	0x1d18 <filter_char_buf+0x48>
    1cf8:      	sub	w9, w8, #0x3
    1cfc:      	cmp	w9, #0x2
    1d00:      	b.lo	0x1d64 <filter_char_buf+0x94>
    1d04:      	cmp	w8, #0x8
    1d08:      	b.eq	0x1d58 <filter_char_buf+0x88>
    1d0c:      	cmp	w8, #0x9
    1d10:      	b.eq	0x1d30 <filter_char_buf+0x60>
    1d14:      	b	0x1d80 <filter_char_buf+0xb0>
    1d18:      	cmp	w8, #0x20
    1d1c:      	b.gt	0x1d3c <filter_char_buf+0x6c>
    1d20:      	cmp	w8, #0x1a
    1d24:      	b.eq	0x1d58 <filter_char_buf+0x88>
    1d28:      	cmp	w8, #0x1b
    1d2c:      	b.ne	0x1d80 <filter_char_buf+0xb0>
    1d30:      	ldr	w0, [x19, #0x10]
    1d34:      	bl	0x27a0 <filter_char_buf_postfix>
    1d38:      	b	0x1d7c <filter_char_buf+0xac>
    1d3c:      	cmp	w8, #0x21
    1d40:      	b.eq	0x1d70 <filter_char_buf+0xa0>
    1d44:      	cmp	w8, #0x22
    1d48:      	b.ne	0x1d80 <filter_char_buf+0xb0>
    1d4c:      	mov	x0, x19
    1d50:      	mov	w3, #0x1                // =1
    1d54:      	b	0x1d78 <filter_char_buf+0xa8>
    1d58:      	ldr	w0, [x19, #0x10]
    1d5c:      	bl	0x26e0 <filter_char_buf_prefix>
    1d60:      	b	0x1d7c <filter_char_buf+0xac>
    1d64:      	mov	x0, x19
    1d68:      	bl	0x22b0 <filter_char_buf_equal>
    1d6c:      	b	0x1d7c <filter_char_buf+0xac>
    1d70:      	mov	x0, x19
    1d74:      	mov	w3, wzr
    1d78:      	bl	0x2970 <filter_char_substring>
    1d7c:      	ldr	w8, [x19, #0x4]
    1d80:      	cmp	w8, #0x25
    1d84:      	b.hi	0x1db0 <filter_char_buf+0xe0>
    1d88:      	mov	w8, w8
    1d8c:      	mov	w9, #0x1                // =1
    1d90:      	lsl	x8, x9, x8
    1d94:      	mov	x9, #0x50               // =80
    1d98:      	movk	x9, #0xc00, lsl #16
    1d9c:      	movk	x9, #0x20, lsl #32
    1da0:      	tst	x8, x9
    1da4:      	b.eq	0x1db0 <filter_char_buf+0xe0>
    1da8:      	cmp	x0, #0x0
    1dac:      	cset	w0, eq
    1db0:      	ldp	x30, x19, [sp], #0x10
    1db4:      	ret
    1db8:      	nop
    1dbc:      	nop

0000000000001dc0 <filter_inet>:
    1dc0:      	sub	sp, sp, #0x80
    1dc4:      	str	x30, [sp, #0x50]
    1dc8:      	stp	x22, x21, [sp, #0x60]
    1dcc:      	stp	x20, x19, [sp, #0x70]
    1dd0:      	ldr	w10, [x0, #0xc]
    1dd4:      	mov	x8, xzr
    1dd8:      	stp	xzr, xzr, [sp, #0x28]
    1ddc:      	cmp	w10, #0x27
    1de0:      	str	xzr, [sp, #0x10]
    1de4:      	stp	xzr, xzr, [sp, #0x18]
    1de8:      	str	wzr, [sp, #0x58]
    1dec:      	str	wzr, [sp, #0xc]
    1df0:      	b.gt	0x1e3c <filter_inet+0x7c>
    1df4:      	cmp	w10, #0x5
    1df8:      	b.eq	0x1e70 <filter_inet+0xb0>
    1dfc:      	cmp	w10, #0x7
    1e00:      	mov	x11, x1
    1e04:      	b.ne	0x2044 <filter_inet+0x284>
    1e08:      	ldr	w9, [x0, #0x4]
    1e0c:      	mov	x8, xzr
    1e10:      	cmp	w9, #0x13
    1e14:      	b.le	0x1eb8 <filter_inet+0xf8>
    1e18:      	cmp	w9, #0x17
    1e1c:      	b.gt	0x1e54 <filter_inet+0x94>
    1e20:      	sub	w10, w9, #0x14
    1e24:      	cmp	w10, #0x2
    1e28:      	b.lo	0x1f14 <filter_inet+0x154>
    1e2c:      	sub	w10, w9, #0x16
    1e30:      	cmp	w10, #0x2
    1e34:      	b.lo	0x1f0c <filter_inet+0x14c>
    1e38:      	b	0x2044 <filter_inet+0x284>
    1e3c:      	cmp	w10, #0x28
    1e40:      	b.eq	0x1e88 <filter_inet+0xc8>
    1e44:      	cmp	w10, #0x29
    1e48:      	mov	x11, x1
    1e4c:      	b.eq	0x1e08 <filter_inet+0x48>
    1e50:      	b	0x2044 <filter_inet+0x284>
    1e54:      	cmp	w9, #0x1b
    1e58:      	b.gt	0x1f58 <filter_inet+0x198>
    1e5c:      	cmp	w9, #0x18
    1e60:      	b.eq	0x2014 <filter_inet+0x254>
    1e64:      	cmp	w9, #0x19
    1e68:      	b.eq	0x1f78 <filter_inet+0x1b8>
    1e6c:      	b	0x2044 <filter_inet+0x284>
    1e70:      	mov	x11, xzr
    1e74:      	ldr	w9, [x0, #0x4]
    1e78:      	mov	x8, xzr
    1e7c:      	cmp	w9, #0x13
    1e80:      	b.gt	0x1e18 <filter_inet+0x58>
    1e84:      	b	0x1eb8 <filter_inet+0xf8>
    1e88:      	ldrh	w8, [x1]
    1e8c:      	ldrh	w9, [x1, #0x2]
    1e90:      	mov	x11, xzr
    1e94:      	strh	w8, [sp, #0x36]
    1e98:      	strh	w9, [sp, #0x30]
    1e9c:      	ldp	x8, x9, [x1, #0x8]
    1ea0:      	add	x1, sp, #0x10
    1ea4:      	stp	x8, x9, [sp, #0x10]
    1ea8:      	ldr	w9, [x0, #0x4]
    1eac:      	mov	x8, xzr
    1eb0:      	cmp	w9, #0x13
    1eb4:      	b.gt	0x1e18 <filter_inet+0x58>
    1eb8:      	cmp	w9, #0xf
    1ebc:      	b.le	0x1ee0 <filter_inet+0x120>
    1ec0:      	cmp	w9, #0x11
    1ec4:      	b.gt	0x1efc <filter_inet+0x13c>
    1ec8:      	cmp	w9, #0x10
    1ecc:      	b.eq	0x1f0c <filter_inet+0x14c>
    1ed0:      	cmp	w9, #0x11
    1ed4:      	b.ne	0x2044 <filter_inet+0x284>
    1ed8:      	ldrh	w8, [x1, #0x24]
    1edc:      	b	0x212c <filter_inet+0x36c>
    1ee0:      	cmp	w9, #0xd
    1ee4:      	b.eq	0x2014 <filter_inet+0x254>
    1ee8:      	cmp	w9, #0xe
    1eec:      	b.eq	0x1f78 <filter_inet+0x1b8>
    1ef0:      	cmp	w9, #0xf
    1ef4:      	b.eq	0x1f14 <filter_inet+0x154>
    1ef8:      	b	0x2044 <filter_inet+0x284>
    1efc:      	cmp	w9, #0x12
    1f00:      	b.eq	0x1f14 <filter_inet+0x154>
    1f04:      	cmp	w9, #0x13
    1f08:      	b.ne	0x2044 <filter_inet+0x284>
    1f0c:      	ldrh	w10, [x1, #0x22]
    1f10:      	b	0x1f18 <filter_inet+0x158>
    1f14:      	ldrh	w10, [x1, #0x20]
    1f18:      	mov	w19, wzr
    1f1c:      	mov	w20, wzr
    1f20:      	mov	x21, xzr
    1f24:      	str	w10, [sp, #0xc]
    1f28:      	mov	x8, xzr
    1f2c:      	cmp	w9, #0x11
    1f30:      	b.gt	0x1f90 <filter_inet+0x1d0>
    1f34:      	sub	w10, w9, #0xd
    1f38:      	cmp	w10, #0x2
    1f3c:      	b.lo	0x1fc8 <filter_inet+0x208>
    1f40:      	sub	w10, w9, #0xf
    1f44:      	cmp	w10, #0x2
    1f48:      	b.lo	0x203c <filter_inet+0x27c>
    1f4c:      	cmp	w9, #0x11
    1f50:      	b.eq	0x2130 <filter_inet+0x370>
    1f54:      	b	0x2044 <filter_inet+0x284>
    1f58:      	cmp	w9, #0x1c
    1f5c:      	b.eq	0x2128 <filter_inet+0x368>
    1f60:      	cmp	w9, #0x1d
    1f64:      	b.ne	0x2044 <filter_inet+0x284>
    1f68:      	cmp	w10, #0x7
    1f6c:      	b.ne	0x2180 <filter_inet+0x3c0>
    1f70:      	cbnz	x11, 0x218c <filter_inet+0x3cc>
    1f74:      	b	0x2130 <filter_inet+0x370>
    1f78:      	ldp	w19, w20, [x1, #0x10]
    1f7c:      	ldr	x21, [x1, #0x18]
    1f80:      	mov	w10, wzr
    1f84:      	mov	x8, xzr
    1f88:      	cmp	w9, #0x11
    1f8c:      	b.le	0x1f34 <filter_inet+0x174>
    1f90:      	cmp	w9, #0x19
    1f94:      	b.hi	0x2030 <filter_inet+0x270>
    1f98:      	mov	w11, #0x1               // =1
    1f9c:      	mov	w12, #0x500000          // =5242880
    1fa0:      	lsl	w11, w11, w9
    1fa4:      	tst	w11, w12
    1fa8:      	b.ne	0x205c <filter_inet+0x29c>
    1fac:      	mov	w12, #0xa00000          // =10485760
    1fb0:      	tst	w11, w12
    1fb4:      	b.ne	0x207c <filter_inet+0x2bc>
    1fb8:      	mov	w10, #0x1               // =1
    1fbc:      	lsl	w10, w10, w9
    1fc0:      	tst	w10, #0x3000000
    1fc4:      	b.eq	0x2030 <filter_inet+0x270>
    1fc8:      	ldrh	w8, [x1, #0x26]
    1fcc:      	cmp	w8, #0xa
    1fd0:      	b.eq	0x209c <filter_inet+0x2dc>
    1fd4:      	cmp	w8, #0x2
    1fd8:      	b.ne	0x210c <filter_inet+0x34c>
    1fdc:      	ldr	w8, [x0, #0x10]
    1fe0:      	mov	x22, x0
    1fe4:      	adrp	x0, 0x1000 <filter_16ty_selector_val+0x140>
    1fe8:      	add	x9, sp, #0x5c
    1fec:      	str	w8, [sp, #0x5c]
    1ff0:      	mov	w8, #0x1                // =1
    1ff4:      	add	x1, sp, #0x5c
    1ff8:      	ldr	x0, [x0]
    1ffc:      	blr	x8
    2000:      	cbz	x0, 0x214c <filter_inet+0x38c>
    2004:      	mov	w8, #0x20               // =32
    2008:      	add	x1, sp, #0x3c
    200c:      	stp	w8, w19, [sp, #0x3c]
    2010:      	b	0x20dc <filter_inet+0x31c>
    2014:      	ldp	w19, w20, [x1]
    2018:      	ldr	x21, [x1, #0x8]
    201c:      	mov	w10, wzr
    2020:      	mov	x8, xzr
    2024:      	cmp	w9, #0x11
    2028:      	b.le	0x1f34 <filter_inet+0x174>
    202c:      	b	0x1f90 <filter_inet+0x1d0>
    2030:      	sub	w9, w9, #0x12
    2034:      	cmp	w9, #0x2
    2038:      	b.hs	0x2044 <filter_inet+0x284>
    203c:      	add	x1, sp, #0xc
    2040:      	b	0x2134 <filter_inet+0x374>
    2044:      	ldp	x20, x19, [sp, #0x70]
    2048:      	mov	x0, x8
    204c:      	ldr	x30, [sp, #0x50]
    2050:      	ldp	x22, x21, [sp, #0x60]
    2054:      	add	sp, sp, #0x80
    2058:      	ret
    205c:      	cmp	w10, #0x400
    2060:      	cset	w8, lo
    2064:      	ldp	x20, x19, [sp, #0x70]
    2068:      	mov	x0, x8
    206c:      	ldr	x30, [sp, #0x50]
    2070:      	ldp	x22, x21, [sp, #0x60]
    2074:      	add	sp, sp, #0x80
    2078:      	ret
    207c:      	cmp	w10, #0x3ff
    2080:      	cset	w8, hi
    2084:      	ldp	x20, x19, [sp, #0x70]
    2088:      	mov	x0, x8
    208c:      	ldr	x30, [sp, #0x50]
    2090:      	ldp	x22, x21, [sp, #0x60]
    2094:      	add	sp, sp, #0x80
    2098:      	ret
    209c:      	ldr	w8, [x0, #0x14]
    20a0:      	mov	x22, x0
    20a4:      	adrp	x0, 0x2000 <filter_inet+0x240>
    20a8:      	add	x9, sp, #0x5c
    20ac:      	str	w8, [sp, #0x5c]
    20b0:      	mov	w8, #0x1                // =1
    20b4:      	add	x1, sp, #0x5c
    20b8:      	ldr	x0, [x0]
    20bc:      	blr	x8
    20c0:      	cbz	x0, 0x214c <filter_inet+0x38c>
    20c4:      	mov	w8, #0x80               // =128
    20c8:      	add	x1, sp, #0x3c
    20cc:      	stp	w20, w21, [sp, #0x44]
    20d0:      	stp	w8, w19, [sp, #0x3c]
    20d4:      	lsr	x8, x21, #32
    20d8:      	str	w8, [sp, #0x4c]
    20dc:      	mov	w8, #0x1                // =1
    20e0:      	blr	x8
    20e4:      	ldr	w8, [x22, #0x4]
    20e8:      	sub	w9, w8, #0x18
    20ec:      	cmp	w9, #0x2
    20f0:      	b.lo	0x215c <filter_inet+0x39c>
    20f4:      	sub	w8, w8, #0xd
    20f8:      	cmp	w8, #0x1
    20fc:      	b.hi	0x210c <filter_inet+0x34c>
    2100:      	cmp	x0, #0x0
    2104:      	cset	w8, ne
    2108:      	b	0x2164 <filter_inet+0x3a4>
    210c:      	mov	w8, wzr
    2110:      	ldp	x20, x19, [sp, #0x70]
    2114:      	mov	x0, x8
    2118:      	ldr	x30, [sp, #0x50]
    211c:      	ldp	x22, x21, [sp, #0x60]
    2120:      	add	sp, sp, #0x80
    2124:      	ret
    2128:      	ldrh	w8, [x1, #0x26]
    212c:      	str	w8, [sp, #0x58]
    2130:      	add	x1, sp, #0x58
    2134:      	bl	0xbb0 <filter_32ty_map>
    2138:      	ldp	x20, x19, [sp, #0x70]
    213c:      	ldr	x30, [sp, #0x50]
    2140:      	ldp	x22, x21, [sp, #0x60]
    2144:      	add	sp, sp, #0x80
    2148:      	ret
    214c:      	ldr	w8, [x22, #0x4]
    2150:      	and	w8, w8, #0xfffffffe
    2154:      	cmp	w8, #0x18
    2158:      	b	0x2160 <filter_inet+0x3a0>
    215c:      	cmp	x0, #0x0
    2160:      	cset	w8, eq
    2164:      	mov	w8, w8
    2168:      	ldp	x20, x19, [sp, #0x70]
    216c:      	mov	x0, x8
    2170:      	ldr	x30, [sp, #0x50]
    2174:      	ldp	x22, x21, [sp, #0x60]
    2178:      	add	sp, sp, #0x80
    217c:      	ret
    2180:      	cmp	w10, #0x29
    2184:      	b.ne	0x2194 <filter_inet+0x3d4>
    2188:      	cbz	x11, 0x2194 <filter_inet+0x3d4>
    218c:      	ldrb	w8, [x11, #0x3a]
    2190:      	str	w8, [sp, #0x58]
    2194:      	cmp	w10, #0x29
    2198:      	b.eq	0x2130 <filter_inet+0x370>
    219c:      	cmp	w10, #0x7
    21a0:      	b.eq	0x2130 <filter_inet+0x370>
    21a4:      	mov	x8, xzr
    21a8:      	ldp	x20, x19, [sp, #0x70]
    21ac:      	mov	x0, x8
    21b0:      	ldr	x30, [sp, #0x50]
    21b4:      	ldp	x22, x21, [sp, #0x60]
    21b8:      	add	sp, sp, #0x80
    21bc:      	ret

00000000000021c0 <filter_sockaddr_un>:
    21c0:      	sub	sp, sp, #0x20
    21c4:      	stp	x30, x19, [sp, #0x10]
    21c8:      	mov	x19, x0
    21cc:      	ldrb	w2, [x1, #0x3]
    21d0:      	mov	x0, xzr
    21d4:      	ldr	w8, [x19, #0x4]
    21d8:      	cmp	w8, #0x19
    21dc:      	b.gt	0x2230 <filter_sockaddr_un+0x70>
    21e0:      	sub	w9, w8, #0x3
    21e4:      	cmp	w9, #0x2
    21e8:      	b.hs	0x2244 <filter_sockaddr_un+0x84>
    21ec:      	add	x1, x1, #0x4
    21f0:      	mov	x0, x19
    21f4:      	bl	0x22b0 <filter_char_buf_equal>
    21f8:      	ldr	w8, [x19, #0x4]
    21fc:      	cmp	w8, #0x25
    2200:      	b.hi	0x2224 <filter_sockaddr_un+0x64>
    2204:      	mov	w9, #0x1                // =1
    2208:      	lsl	x8, x9, x8
    220c:      	mov	x9, #0x50               // =80
    2210:      	movk	x9, #0xc00, lsl #16
    2214:      	movk	x9, #0x20, lsl #32
    2218:      	tst	x8, x9
    221c:      	b.eq	0x2224 <filter_sockaddr_un+0x64>
    2220:      	eor	x0, x0, #0x1
    2224:      	ldp	x30, x19, [sp, #0x10]
    2228:      	add	sp, sp, #0x20
    222c:      	ret
    2230:      	cmp	w8, #0x1c
    2234:      	b.eq	0x2290 <filter_sockaddr_un+0xd0>
    2238:      	cmp	w8, #0x1a
    223c:      	b.eq	0x224c <filter_sockaddr_un+0x8c>
    2240:      	b	0x2224 <filter_sockaddr_un+0x64>
    2244:      	cmp	w8, #0x8
    2248:      	b.ne	0x2224 <filter_sockaddr_un+0x64>
    224c:      	ldr	w0, [x19, #0x10]
    2250:      	add	x1, x1, #0x4
    2254:      	bl	0x26e0 <filter_char_buf_prefix>
    2258:      	ldr	w8, [x19, #0x4]
    225c:      	cmp	w8, #0x25
    2260:      	b.hi	0x2224 <filter_sockaddr_un+0x64>
    2264:      	mov	w9, #0x1                // =1
    2268:      	lsl	x8, x9, x8
    226c:      	mov	x9, #0x50               // =80
    2270:      	movk	x9, #0xc00, lsl #16
    2274:      	movk	x9, #0x20, lsl #32
    2278:      	tst	x8, x9
    227c:      	b.eq	0x2224 <filter_sockaddr_un+0x64>
    2280:      	eor	x0, x0, #0x1
    2284:      	ldp	x30, x19, [sp, #0x10]
    2288:      	add	sp, sp, #0x20
    228c:      	ret
    2290:      	ldrh	w8, [x1]
    2294:      	add	x1, sp, #0xc
    2298:      	mov	x0, x19
    229c:      	str	w8, [sp, #0xc]
    22a0:      	bl	0xbb0 <filter_32ty_map>
    22a4:      	ldp	x30, x19, [sp, #0x10]
    22a8:      	add	sp, sp, #0x20
    22ac:      	ret

00000000000022b0 <filter_char_buf_equal>:
    22b0:      	str	x29, [sp, #-0x50]!
    22b4:      	stp	x30, x25, [sp, #0x10]
    22b8:      	stp	x24, x23, [sp, #0x20]
    22bc:      	stp	x22, x21, [sp, #0x30]
    22c0:      	stp	x20, x19, [sp, #0x40]
    22c4:      	cmp	w2, #0x1, lsl #12       // =0x1000
    22c8:      	str	wzr, [sp, #0x8]
    22cc:      	b.ls	0x22ec <filter_char_buf_equal+0x3c>
    22d0:      	mov	x0, xzr
    22d4:      	ldp	x20, x19, [sp, #0x40]
    22d8:      	ldp	x22, x21, [sp, #0x30]
    22dc:      	ldp	x24, x23, [sp, #0x20]
    22e0:      	ldp	x30, x25, [sp, #0x10]
    22e4:      	ldr	x29, [sp], #0x50
    22e8:      	ret
    22ec:      	and	w9, w2, #0xffff
    22f0:      	add	x8, x0, #0x10
    22f4:      	cmp	w9, #0x90
    22f8:      	b.hi	0x2368 <filter_char_buf_equal+0xb8>
    22fc:      	and	w9, w2, #0xff
    2300:      	mov	w10, #0xab              // =171
    2304:      	tst	w2, #0xffff
    2308:      	mul	w9, w9, w10
    230c:      	mov	w10, #0x18              // =24
    2310:      	lsr	w9, w9, #12
    2314:      	msub	w9, w9, w10, w2
    2318:      	b.eq	0x2328 <filter_char_buf_equal+0x78>
    231c:      	tst	w9, #0xff
    2320:      	mov	w23, w2
    2324:      	b.eq	0x2340 <filter_char_buf_equal+0x90>
    2328:      	sub	w9, w2, w9, uxtb
    232c:      	and	w10, w9, #0xffff
    2330:      	add	w9, w9, #0x18
    2334:      	and	w23, w9, #0xffff
    2338:      	cmp	w10, #0x78
    233c:      	b.hi	0x23dc <filter_char_buf_equal+0x12c>
    2340:      	and	w9, w23, #0xff
    2344:      	mov	w10, #0xab              // =171
    2348:      	mul	w9, w9, w10
    234c:      	lsr	w9, w9, #12
    2350:      	sub	w22, w9, #0x1
    2354:      	and	w9, w22, #0xf
    2358:      	ldr	w24, [x8, w9, uxtw #2]
    235c:      	cmn	w24, #0x1
    2360:      	b.ne	0x2454 <filter_char_buf_equal+0x1a4>
    2364:      	b	0x25fc <filter_char_buf_equal+0x34c>
    2368:      	cmp	w9, #0x101
    236c:      	b.hs	0x23ac <filter_char_buf_equal+0xfc>
    2370:      	mov	w23, #0x100             // =256
    2374:      	sub	w9, w23, #0x100
    2378:      	ror	w9, w9, #0x8
    237c:      	cmp	w9, #0x2
    2380:      	b.le	0x23ec <filter_char_buf_equal+0x13c>
    2384:      	cmp	w9, #0x3
    2388:      	b.eq	0x2428 <filter_char_buf_equal+0x178>
    238c:      	cmp	w9, #0x7
    2390:      	b.ne	0x2410 <filter_char_buf_equal+0x160>
    2394:      	mov	w22, #0x9               // =9
    2398:      	and	w9, w22, #0xf
    239c:      	ldr	w24, [x8, w9, uxtw #2]
    23a0:      	cmn	w24, #0x1
    23a4:      	b.ne	0x2454 <filter_char_buf_equal+0x1a4>
    23a8:      	b	0x25fc <filter_char_buf_equal+0x34c>
    23ac:      	and	w9, w2, #0xffff
    23b0:      	cmp	w9, #0x201
    23b4:      	b.hs	0x23d0 <filter_char_buf_equal+0x120>
    23b8:      	mov	w23, #0x200             // =512
    23bc:      	sub	w9, w23, #0x100
    23c0:      	ror	w9, w9, #0x8
    23c4:      	cmp	w9, #0x2
    23c8:      	b.le	0x23ec <filter_char_buf_equal+0x13c>
    23cc:      	b	0x2384 <filter_char_buf_equal+0xd4>
    23d0:      	cmp	w9, #0x401
    23d4:      	b.hs	0x25b4 <filter_char_buf_equal+0x304>
    23d8:      	mov	w23, #0x400             // =1024
    23dc:      	sub	w9, w23, #0x100
    23e0:      	ror	w9, w9, #0x8
    23e4:      	cmp	w9, #0x2
    23e8:      	b.gt	0x2384 <filter_char_buf_equal+0xd4>
    23ec:      	cbz	w9, 0x2440 <filter_char_buf_equal+0x190>
    23f0:      	cmp	w9, #0x1
    23f4:      	b.ne	0x2410 <filter_char_buf_equal+0x160>
    23f8:      	mov	w22, #0x7               // =7
    23fc:      	and	w9, w22, #0xf
    2400:      	ldr	w24, [x8, w9, uxtw #2]
    2404:      	cmn	w24, #0x1
    2408:      	b.ne	0x2454 <filter_char_buf_equal+0x1a4>
    240c:      	b	0x25fc <filter_char_buf_equal+0x34c>
    2410:      	mov	w22, #0xa               // =10
    2414:      	and	w9, w22, #0xf
    2418:      	ldr	w24, [x8, w9, uxtw #2]
    241c:      	cmn	w24, #0x1
    2420:      	b.ne	0x2454 <filter_char_buf_equal+0x1a4>
    2424:      	b	0x25fc <filter_char_buf_equal+0x34c>
    2428:      	mov	w22, #0x8               // =8
    242c:      	and	w9, w22, #0xf
    2430:      	ldr	w24, [x8, w9, uxtw #2]
    2434:      	cmn	w24, #0x1
    2438:      	b.ne	0x2454 <filter_char_buf_equal+0x1a4>
    243c:      	b	0x25fc <filter_char_buf_equal+0x34c>
    2440:      	mov	w22, #0x6               // =6
    2444:      	and	w9, w22, #0xf
    2448:      	ldr	w24, [x8, w9, uxtw #2]
    244c:      	cmn	w24, #0x1
    2450:      	b.eq	0x25fc <filter_char_buf_equal+0x34c>
    2454:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2458:      	add	x29, sp, #0x8
    245c:      	mov	w8, #0x1                // =1
    2460:      	ldr	x0, [x0]
    2464:      	mov	x25, x1
    2468:      	add	x1, sp, #0x8
    246c:      	mov	w21, w2
    2470:      	mov	w20, #0x1               // =1
    2474:      	blr	x8
    2478:      	mov	x19, x0
    247c:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2480:      	add	x1, sp, #0x8
    2484:      	ldr	x0, [x0]
    2488:      	blr	x20
    248c:      	mov	x20, x0
    2490:      	mov	x0, xzr
    2494:      	cbz	x19, 0x22d4 <filter_char_buf_equal+0x24>
    2498:      	cbz	x20, 0x22d4 <filter_char_buf_equal+0x24>
    249c:      	mov	x0, x19
    24a0:      	cmp	w22, #0x5
    24a4:      	b.gt	0x24dc <filter_char_buf_equal+0x22c>
    24a8:      	strb	w21, [x0], #0x1
    24ac:      	mov	w29, w21
    24b0:      	mov	w8, #0x4                // =4
    24b4:      	mov	x2, x25
    24b8:      	mov	w1, w21
    24bc:      	blr	x8
    24c0:      	subs	w8, w23, w21
    24c4:      	b.ls	0x2514 <filter_char_buf_equal+0x264>
    24c8:      	add	x9, x19, x29
    24cc:      	and	w1, w8, #0xfff
    24d0:      	mov	w8, #0x4                // =4
    24d4:      	add	x0, x9, #0x1
    24d8:      	b	0x250c <filter_char_buf_equal+0x25c>
    24dc:      	strh	w21, [x0], #0x2
    24e0:      	mov	w29, w21
    24e4:      	mov	w8, #0x4                // =4
    24e8:      	mov	x2, x25
    24ec:      	mov	w1, w21
    24f0:      	blr	x8
    24f4:      	subs	w8, w23, w21
    24f8:      	b.ls	0x2514 <filter_char_buf_equal+0x264>
    24fc:      	add	x9, x19, x29
    2500:      	and	w1, w8, #0xfff
    2504:      	mov	w8, #0x4                // =4
    2508:      	add	x0, x9, #0x2
    250c:      	mov	x2, x20
    2510:      	blr	x8
    2514:      	cmp	w22, #0x4
    2518:      	str	w24, [sp, #0xc]
    251c:      	b.le	0x2554 <filter_char_buf_equal+0x2a4>
    2520:      	cmp	w22, #0x7
    2524:      	b.gt	0x2588 <filter_char_buf_equal+0x2d8>
    2528:      	cmp	w22, #0x5
    252c:      	b.eq	0x267c <filter_char_buf_equal+0x3cc>
    2530:      	cmp	w22, #0x6
    2534:      	b.eq	0x2640 <filter_char_buf_equal+0x390>
    2538:      	cmp	w22, #0x7
    253c:      	b.ne	0x25fc <filter_char_buf_equal+0x34c>
    2540:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2544:      	mov	w8, #0x1                // =1
    2548:      	add	x9, sp, #0xc
    254c:      	ldr	x0, [x0]
    2550:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    2554:      	cmp	w22, #0x1
    2558:      	b.le	0x25dc <filter_char_buf_equal+0x32c>
    255c:      	cmp	w22, #0x2
    2560:      	b.eq	0x2668 <filter_char_buf_equal+0x3b8>
    2564:      	cmp	w22, #0x3
    2568:      	b.eq	0x262c <filter_char_buf_equal+0x37c>
    256c:      	cmp	w22, #0x4
    2570:      	b.ne	0x25fc <filter_char_buf_equal+0x34c>
    2574:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2578:      	mov	w8, #0x1                // =1
    257c:      	add	x9, sp, #0xc
    2580:      	ldr	x0, [x0]
    2584:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    2588:      	cmp	w22, #0x8
    258c:      	b.eq	0x2690 <filter_char_buf_equal+0x3e0>
    2590:      	cmp	w22, #0x9
    2594:      	b.eq	0x2654 <filter_char_buf_equal+0x3a4>
    2598:      	cmp	w22, #0xa
    259c:      	b.ne	0x25fc <filter_char_buf_equal+0x34c>
    25a0:      	adrp	x0, 0x2000 <filter_inet+0x240>
    25a4:      	mov	w8, #0x1                // =1
    25a8:      	add	x9, sp, #0xc
    25ac:      	ldr	x0, [x0]
    25b0:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    25b4:      	and	w9, w2, #0xffff
    25b8:      	mov	w10, #0x1000            // =4096
    25bc:      	cmp	w9, #0x800
    25c0:      	mov	w9, #0x800              // =2048
    25c4:      	csel	w23, w10, w9, hi
    25c8:      	sub	w9, w23, #0x100
    25cc:      	ror	w9, w9, #0x8
    25d0:      	cmp	w9, #0x2
    25d4:      	b.le	0x23ec <filter_char_buf_equal+0x13c>
    25d8:      	b	0x2384 <filter_char_buf_equal+0xd4>
    25dc:      	cbz	w22, 0x2618 <filter_char_buf_equal+0x368>
    25e0:      	cmp	w22, #0x1
    25e4:      	b.ne	0x25fc <filter_char_buf_equal+0x34c>
    25e8:      	adrp	x0, 0x2000 <filter_inet+0x240>
    25ec:      	mov	w8, #0x1                // =1
    25f0:      	add	x9, sp, #0xc
    25f4:      	ldr	x0, [x0]
    25f8:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    25fc:      	mov	x0, xzr
    2600:      	ldp	x20, x19, [sp, #0x40]
    2604:      	ldp	x22, x21, [sp, #0x30]
    2608:      	ldp	x24, x23, [sp, #0x20]
    260c:      	ldp	x30, x25, [sp, #0x10]
    2610:      	ldr	x29, [sp], #0x50
    2614:      	ret
    2618:      	adrp	x0, 0x2000 <filter_inet+0x240>
    261c:      	mov	w8, #0x1                // =1
    2620:      	add	x9, sp, #0xc
    2624:      	ldr	x0, [x0]
    2628:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    262c:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2630:      	mov	w8, #0x1                // =1
    2634:      	add	x9, sp, #0xc
    2638:      	ldr	x0, [x0]
    263c:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    2640:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2644:      	mov	w8, #0x1                // =1
    2648:      	add	x9, sp, #0xc
    264c:      	ldr	x0, [x0]
    2650:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    2654:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2658:      	mov	w8, #0x1                // =1
    265c:      	add	x9, sp, #0xc
    2660:      	ldr	x0, [x0]
    2664:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    2668:      	adrp	x0, 0x2000 <filter_inet+0x240>
    266c:      	mov	w8, #0x1                // =1
    2670:      	add	x9, sp, #0xc
    2674:      	ldr	x0, [x0]
    2678:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    267c:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2680:      	mov	w8, #0x1                // =1
    2684:      	add	x9, sp, #0xc
    2688:      	ldr	x0, [x0]
    268c:      	b	0x26a0 <filter_char_buf_equal+0x3f0>
    2690:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2694:      	mov	w8, #0x1                // =1
    2698:      	add	x9, sp, #0xc
    269c:      	ldr	x0, [x0]
    26a0:      	add	x1, sp, #0xc
    26a4:      	blr	x8
    26a8:      	cbz	x0, 0x22d4 <filter_char_buf_equal+0x24>
    26ac:      	mov	w8, #0x1                // =1
    26b0:      	mov	x1, x19
    26b4:      	blr	x8
    26b8:      	cmp	x0, #0x0
    26bc:      	cset	w0, ne
    26c0:      	ldp	x20, x19, [sp, #0x40]
    26c4:      	ldp	x22, x21, [sp, #0x30]
    26c8:      	ldp	x24, x23, [sp, #0x20]
    26cc:      	ldp	x30, x25, [sp, #0x10]
    26d0:      	ldr	x29, [sp], #0x50
    26d4:      	ret
    26d8:      	nop
    26dc:      	nop

00000000000026e0 <filter_char_buf_prefix>:
    26e0:      	sub	sp, sp, #0x30
    26e4:      	stp	x30, x21, [sp, #0x10]
    26e8:      	stp	x20, x19, [sp, #0x20]
    26ec:      	stp	wzr, w0, [sp, #0x8]
    26f0:      	adrp	x0, 0x2000 <filter_inet+0x240>
    26f4:      	mov	w8, #0x1                // =1
    26f8:      	add	x9, sp, #0xc
    26fc:      	ldr	x0, [x0]
    2700:      	mov	x19, x1
    2704:      	add	x1, sp, #0xc
    2708:      	mov	w20, w2
    270c:      	blr	x8
    2710:      	mov	x8, x0
    2714:      	mov	x0, xzr
    2718:      	cbz	w20, 0x2784 <filter_char_buf_prefix+0xa4>
    271c:      	cbz	x8, 0x2784 <filter_char_buf_prefix+0xa4>
    2720:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2724:      	mov	x21, x8
    2728:      	mov	w8, #0x1                // =1
    272c:      	ldr	x0, [x0]
    2730:      	add	x9, sp, #0x8
    2734:      	add	x1, sp, #0x8
    2738:      	blr	x8
    273c:      	cbz	x0, 0x2784 <filter_char_buf_prefix+0xa4>
    2740:      	cmp	w20, #0xff
    2744:      	mov	w8, #0xff               // =255
    2748:      	mov	x2, x19
    274c:      	csel	w1, w20, w8, lo
    2750:      	mov	x8, x0
    2754:      	mov	x20, x0
    2758:      	lsl	w9, w1, #3
    275c:      	str	w9, [x8], #0x4
    2760:      	mov	w9, #0x4                // =4
    2764:      	mov	x0, x8
    2768:      	blr	x9
    276c:      	mov	w8, #0x1                // =1
    2770:      	mov	x0, x21
    2774:      	mov	x1, x20
    2778:      	blr	x8
    277c:      	cmp	x0, #0x0
    2780:      	cset	w0, ne
    2784:      	ldp	x20, x19, [sp, #0x20]
    2788:      	ldp	x30, x21, [sp, #0x10]
    278c:      	add	sp, sp, #0x30
    2790:      	ret
    2794:      	nop
    2798:      	nop
    279c:      	nop

00000000000027a0 <filter_char_buf_postfix>:
    27a0:      	sub	sp, sp, #0x30
    27a4:      	stp	x30, x21, [sp, #0x10]
    27a8:      	stp	x20, x19, [sp, #0x20]
    27ac:      	stp	wzr, w0, [sp, #0x8]
    27b0:      	adrp	x0, 0x2000 <filter_inet+0x240>
    27b4:      	mov	w8, #0x1                // =1
    27b8:      	add	x9, sp, #0xc
    27bc:      	ldr	x0, [x0]
    27c0:      	mov	x19, x1
    27c4:      	add	x1, sp, #0xc
    27c8:      	mov	w20, w2
    27cc:      	blr	x8
    27d0:      	mov	x8, x0
    27d4:      	mov	x0, xzr
    27d8:      	cbz	w20, 0x2860 <filter_char_buf_postfix+0xc0>
    27dc:      	cbz	x8, 0x2860 <filter_char_buf_postfix+0xc0>
    27e0:      	adrp	x0, 0x2000 <filter_inet+0x240>
    27e4:      	mov	x21, x8
    27e8:      	mov	w8, #0x1                // =1
    27ec:      	ldr	x0, [x0]
    27f0:      	add	x9, sp, #0x8
    27f4:      	add	x1, sp, #0x8
    27f8:      	blr	x8
    27fc:      	cbz	x0, 0x2860 <filter_char_buf_postfix+0xc0>
    2800:      	cmp	w20, #0x7f
    2804:      	mov	w9, #0x7f               // =127
    2808:      	mov	x1, x0
    280c:      	mov	x8, xzr
    2810:      	sub	w10, w20, #0x1
    2814:      	csel	w9, w20, w9, lo
    2818:      	lsl	w9, w9, #3
    281c:      	str	w9, [x0]
    2820:      	mov	w9, w20
    2824:      	cmp	x8, #0x7f
    2828:      	b.eq	0x284c <filter_char_buf_postfix+0xac>
    282c:      	and	x11, x10, #0xfff
    2830:      	add	x12, x1, x8
    2834:      	add	x8, x8, #0x1
    2838:      	ldrb	w11, [x19, x11]
    283c:      	sub	w10, w10, #0x1
    2840:      	cmp	x9, x8
    2844:      	strb	w11, [x12, #0x4]
    2848:      	b.ne	0x2824 <filter_char_buf_postfix+0x84>
    284c:      	mov	w8, #0x1                // =1
    2850:      	mov	x0, x21
    2854:      	blr	x8
    2858:      	cmp	x0, #0x0
    285c:      	cset	w0, ne
    2860:      	ldp	x20, x19, [sp, #0x20]
    2864:      	ldp	x30, x21, [sp, #0x10]
    2868:      	add	sp, sp, #0x30
    286c:      	ret

0000000000002870 <filter_file_type>:
    2870:      	sub	sp, sp, #0x20
    2874:      	stp	x30, x19, [sp, #0x10]
    2878:      	ldr	w8, [x1]
    287c:      	strh	wzr, [sp, #0xc]
    2880:      	cmp	w8, #0x1, lsl #12       // =0x1000
    2884:      	b.hi	0x295c <filter_file_type+0xec>
    2888:      	add	x9, x1, #0x4
    288c:      	mov	w10, #0x2               // =2
    2890:      	mov	w11, #0x4               // =4
    2894:      	add	x12, sp, #0xc
    2898:      	mov	x19, x0
    289c:      	add	x0, sp, #0xc
    28a0:      	add	x8, x9, x8
    28a4:      	add	x8, x8, #0x4
    28a8:      	ldr	w8, [x1]
    28ac:      	mov	w1, #0x2                // =2
    28b0:      	add	x8, x9, x8
    28b4:      	add	x2, x8, #0x4
    28b8:      	blr	x11
    28bc:      	ldr	w9, [x19, #0x10]
    28c0:      	cbz	w9, 0x295c <filter_file_type+0xec>
    28c4:      	ldrh	w8, [sp, #0xc]
    28c8:      	and	w8, w8, #0xf000
    28cc:      	cmp	w9, w8
    28d0:      	b.ne	0x28e4 <filter_file_type+0x74>
    28d4:      	mov	w0, #0x1                // =1
    28d8:      	ldp	x30, x19, [sp, #0x10]
    28dc:      	add	sp, sp, #0x20
    28e0:      	ret
    28e4:      	ldr	w9, [x19, #0x8]
    28e8:      	cmp	w9, #0xc
    28ec:      	b.ls	0x295c <filter_file_type+0xec>
    28f0:      	ldr	w10, [x19, #0x14]
    28f4:      	cbz	w10, 0x295c <filter_file_type+0xec>
    28f8:      	cmp	w10, w8
    28fc:      	b.ne	0x2910 <filter_file_type+0xa0>
    2900:      	mov	w0, #0x1                // =1
    2904:      	ldp	x30, x19, [sp, #0x10]
    2908:      	add	sp, sp, #0x20
    290c:      	ret
    2910:      	cmp	w9, #0x11
    2914:      	b.lo	0x295c <filter_file_type+0xec>
    2918:      	ldr	w10, [x19, #0x18]
    291c:      	cbz	w10, 0x295c <filter_file_type+0xec>
    2920:      	cmp	w10, w8
    2924:      	b.ne	0x2938 <filter_file_type+0xc8>
    2928:      	mov	w0, #0x1                // =1
    292c:      	ldp	x30, x19, [sp, #0x10]
    2930:      	add	sp, sp, #0x20
    2934:      	ret
    2938:      	cmp	w9, #0x15
    293c:      	b.lo	0x295c <filter_file_type+0xec>
    2940:      	ldr	w9, [x19, #0x1c]
    2944:      	cbz	w9, 0x295c <filter_file_type+0xec>
    2948:      	cmp	w9, w8
    294c:      	cset	w0, eq
    2950:      	ldp	x30, x19, [sp, #0x10]
    2954:      	add	sp, sp, #0x20
    2958:      	ret
    295c:      	mov	x0, xzr
    2960:      	ldp	x30, x19, [sp, #0x10]
    2964:      	add	sp, sp, #0x20
    2968:      	ret
    296c:      	nop

0000000000002970 <filter_char_substring>:
    2970:      	str	x29, [sp, #-0x50]!
    2974:      	stp	x30, x25, [sp, #0x10]
    2978:      	stp	x24, x23, [sp, #0x20]
    297c:      	stp	x22, x21, [sp, #0x30]
    2980:      	stp	x20, x19, [sp, #0x40]
    2984:      	mov	x21, x1
    2988:      	mov	x19, x0
    298c:      	add	x23, x0, #0x10
    2990:      	mov	w24, w2
    2994:      	tbz	w3, #0x0, 0x2a88 <filter_char_substring+0x118>
    2998:      	cbz	w2, 0x2b48 <filter_char_substring+0x1d8>
    299c:      	adrp	x22, 0x2000 <filter_inet+0x240>
    29a0:      	mov	x25, xzr
    29a4:      	mov	w29, wzr
    29a8:      	ldr	x22, [x22]
    29ac:      	add	x20, sp, #0xc
    29b0:      	nop
    29b4:      	nop
    29b8:      	nop
    29bc:      	nop
    29c0:      	ldr	w8, [x23, x25, lsl #2]
    29c4:      	add	x1, sp, #0xc
    29c8:      	mov	x0, x22
    29cc:      	str	w8, [sp, #0xc]
    29d0:      	mov	w8, #0x1                // =1
    29d4:      	blr	x8
    29d8:      	cbz	x0, 0x2be8 <filter_char_substring+0x278>
    29dc:      	mov	x8, xzr
    29e0:      	mov	x9, x21
    29e4:      	mov	x10, x24
    29e8:      	b	0x2a00 <filter_char_substring+0x90>
    29ec:      	add	x8, x8, #0x1
    29f0:      	sub	x10, x10, #0x1
    29f4:      	add	x9, x9, #0x1
    29f8:      	cmp	x8, x24
    29fc:      	b.eq	0x2a64 <filter_char_substring+0xf4>
    2a00:      	mov	x11, xzr
    2a04:      	cmp	x10, x11
    2a08:      	b.eq	0x29ec <filter_char_substring+0x7c>
    2a0c:      	ldrb	w12, [x0, x11]
    2a10:      	cbz	w12, 0x2a60 <filter_char_substring+0xf0>
    2a14:      	ldrb	w13, [x9, x11]
    2a18:      	sub	w14, w13, #0x41
    2a1c:      	orr	w15, w13, #0x20
    2a20:      	cmp	w14, #0x1a
    2a24:      	sub	w14, w12, #0x41
    2a28:      	csel	w13, w15, w13, lo
    2a2c:      	orr	w15, w12, #0x20
    2a30:      	cmp	w14, #0x1a
    2a34:      	csel	w12, w15, w12, lo
    2a38:      	cmp	x11, #0x62
    2a3c:      	b.hi	0x29ec <filter_char_substring+0x7c>
    2a40:      	add	x11, x11, #0x1
    2a44:      	cmp	w13, w12
    2a48:      	b.eq	0x2a04 <filter_char_substring+0x94>
    2a4c:      	b	0x29ec <filter_char_substring+0x7c>
    2a50:      	nop
    2a54:      	nop
    2a58:      	nop
    2a5c:      	nop
    2a60:      	tbz	w8, #0x1f, 0x2c00 <filter_char_substring+0x290>
    2a64:      	ldr	w9, [x19, #0x8]
    2a68:      	add	w8, w29, #0xc
    2a6c:      	cmp	w8, w9
    2a70:      	b.hs	0x2be4 <filter_char_substring+0x274>
    2a74:      	add	x25, x25, #0x1
    2a78:      	add	w29, w29, #0x4
    2a7c:      	cmp	x25, #0x64
    2a80:      	b.ne	0x29c0 <filter_char_substring+0x50>
    2a84:      	b	0x2be4 <filter_char_substring+0x274>
    2a88:      	cbz	w2, 0x2b9c <filter_char_substring+0x22c>
    2a8c:      	adrp	x22, 0x2000 <filter_inet+0x240>
    2a90:      	mov	x25, xzr
    2a94:      	mov	w29, wzr
    2a98:      	ldr	x22, [x22]
    2a9c:      	add	x20, sp, #0xc
    2aa0:      	ldr	w8, [x23, x25, lsl #2]
    2aa4:      	add	x1, sp, #0xc
    2aa8:      	mov	x0, x22
    2aac:      	str	w8, [sp, #0xc]
    2ab0:      	mov	w8, #0x1                // =1
    2ab4:      	blr	x8
    2ab8:      	cbz	x0, 0x2be8 <filter_char_substring+0x278>
    2abc:      	mov	x8, xzr
    2ac0:      	mov	x9, x21
    2ac4:      	mov	x10, x24
    2ac8:      	b	0x2ae0 <filter_char_substring+0x170>
    2acc:      	add	x8, x8, #0x1
    2ad0:      	sub	x10, x10, #0x1
    2ad4:      	add	x9, x9, #0x1
    2ad8:      	cmp	x8, x24
    2adc:      	b.eq	0x2b24 <filter_char_substring+0x1b4>
    2ae0:      	mov	x11, xzr
    2ae4:      	cmp	x10, x11
    2ae8:      	b.eq	0x2acc <filter_char_substring+0x15c>
    2aec:      	ldrb	w12, [x0, x11]
    2af0:      	cbz	w12, 0x2b20 <filter_char_substring+0x1b0>
    2af4:      	cmp	x11, #0x62
    2af8:      	b.hi	0x2acc <filter_char_substring+0x15c>
    2afc:      	ldrb	w13, [x9, x11]
    2b00:      	add	x11, x11, #0x1
    2b04:      	cmp	w13, w12
    2b08:      	b.eq	0x2ae4 <filter_char_substring+0x174>
    2b0c:      	b	0x2acc <filter_char_substring+0x15c>
    2b10:      	nop
    2b14:      	nop
    2b18:      	nop
    2b1c:      	nop
    2b20:      	tbz	w8, #0x1f, 0x2c00 <filter_char_substring+0x290>
    2b24:      	ldr	w9, [x19, #0x8]
    2b28:      	add	w8, w29, #0xc
    2b2c:      	cmp	w8, w9
    2b30:      	b.hs	0x2be4 <filter_char_substring+0x274>
    2b34:      	add	x25, x25, #0x1
    2b38:      	add	w29, w29, #0x4
    2b3c:      	cmp	x25, #0x64
    2b40:      	b.ne	0x2aa0 <filter_char_substring+0x130>
    2b44:      	b	0x2be4 <filter_char_substring+0x274>
    2b48:      	adrp	x20, 0x2000 <filter_inet+0x240>
    2b4c:      	mov	w21, #0x10              // =16
    2b50:      	add	x22, sp, #0xc
    2b54:      	ldr	x20, [x20]
    2b58:      	nop
    2b5c:      	nop
    2b60:      	ldr	w8, [x19, x21]
    2b64:      	add	x1, sp, #0xc
    2b68:      	mov	x0, x20
    2b6c:      	str	w8, [sp, #0xc]
    2b70:      	mov	w8, #0x1                // =1
    2b74:      	blr	x8
    2b78:      	cbz	x0, 0x2be8 <filter_char_substring+0x278>
    2b7c:      	ldr	w8, [x19, #0x8]
    2b80:      	add	x21, x21, #0x4
    2b84:      	sub	w9, w21, #0x8
    2b88:      	cmp	w9, w8
    2b8c:      	b.hs	0x2be4 <filter_char_substring+0x274>
    2b90:      	cmp	x21, #0x1a0
    2b94:      	b.ne	0x2b60 <filter_char_substring+0x1f0>
    2b98:      	b	0x2be4 <filter_char_substring+0x274>
    2b9c:      	adrp	x20, 0x2000 <filter_inet+0x240>
    2ba0:      	mov	w21, #0x10              // =16
    2ba4:      	add	x22, sp, #0xc
    2ba8:      	ldr	x20, [x20]
    2bac:      	ldr	w8, [x19, x21]
    2bb0:      	add	x1, sp, #0xc
    2bb4:      	mov	x0, x20
    2bb8:      	str	w8, [sp, #0xc]
    2bbc:      	mov	w8, #0x1                // =1
    2bc0:      	blr	x8
    2bc4:      	cbz	x0, 0x2be8 <filter_char_substring+0x278>
    2bc8:      	ldr	w8, [x19, #0x8]
    2bcc:      	add	x21, x21, #0x4
    2bd0:      	sub	w9, w21, #0x8
    2bd4:      	cmp	w9, w8
    2bd8:      	b.hs	0x2be4 <filter_char_substring+0x274>
    2bdc:      	cmp	x21, #0x1a0
    2be0:      	b.ne	0x2bac <filter_char_substring+0x23c>
    2be4:      	mov	x0, xzr
    2be8:      	ldp	x20, x19, [sp, #0x40]
    2bec:      	ldp	x22, x21, [sp, #0x30]
    2bf0:      	ldp	x24, x23, [sp, #0x20]
    2bf4:      	ldp	x30, x25, [sp, #0x10]
    2bf8:      	ldr	x29, [sp], #0x50
    2bfc:      	ret
    2c00:      	mov	w0, #0x1                // =1
    2c04:      	ldp	x20, x19, [sp, #0x40]
    2c08:      	ldp	x22, x21, [sp, #0x30]
    2c0c:      	ldp	x24, x23, [sp, #0x20]
    2c10:      	ldp	x30, x25, [sp, #0x10]
    2c14:      	ldr	x29, [sp], #0x50
    2c18:      	ret
    2c1c:      	nop

0000000000002c20 <do_action>:
    2c20:      	sub	sp, sp, #0xc0
    2c24:      	str	x29, [sp, #0x70]
    2c28:      	stp	x30, x25, [sp, #0x80]
    2c2c:      	stp	x24, x23, [sp, #0x90]
    2c30:      	stp	x22, x21, [sp, #0xa0]
    2c34:      	stp	x20, x19, [sp, #0xb0]
    2c38:      	add	x8, x2, w1, uxtw #2
    2c3c:      	str	wzr, [sp, #0x44]
    2c40:      	adrp	x24, 0x2000 <filter_inet+0x240>
    2c44:      	add	x9, sp, #0x44
    2c48:      	mov	w19, w1
    2c4c:      	ldrsw	x22, [x8, #0x4]
    2c50:      	ldr	x24, [x24]
    2c54:      	mov	w8, #0x1                // =1
    2c58:      	mov	x20, x0
    2c5c:      	add	x1, sp, #0x44
    2c60:      	mov	w25, w4
    2c64:      	mov	x23, x3
    2c68:      	mov	x21, x2
    2c6c:      	mov	x0, x24
    2c70:      	blr	x8
    2c74:      	cbz	x0, 0x3118 <do_action+0x4f8>
    2c78:      	mov	x29, x0
    2c7c:      	cmp	w22, #0x7
    2c80:      	b.gt	0x2ca4 <do_action+0x84>
    2c84:      	cmp	w22, #0x3
    2c88:      	b.gt	0x2cec <do_action+0xcc>
    2c8c:      	cmp	w22, #0x1
    2c90:      	b.gt	0x2e18 <do_action+0x1f8>
    2c94:      	cbz	w22, 0x3008 <do_action+0x3e8>
    2c98:      	cmp	w22, #0x1
    2c9c:      	b.eq	0x2e28 <do_action+0x208>
    2ca0:      	b	0x3110 <do_action+0x4f0>
    2ca4:      	cmp	w22, #0xb
    2ca8:      	b.gt	0x2df0 <do_action+0x1d0>
    2cac:      	sub	w8, w22, #0xa
    2cb0:      	cmp	w8, #0x2
    2cb4:      	b.lo	0x2f18 <do_action+0x2f8>
    2cb8:      	cmp	w22, #0x8
    2cbc:      	b.eq	0x2f64 <do_action+0x344>
    2cc0:      	cmp	w22, #0x9
    2cc4:      	b.ne	0x3110 <do_action+0x4f0>
    2cc8:      	add	w19, w19, #0x1
    2ccc:      	add	x8, x21, w19, uxtw #2
    2cd0:      	ldr	w0, [x8, #0x4]
    2cd4:      	tbz	w25, #0x0, 0x30b4 <do_action+0x494>
    2cd8:      	sxtw	x8, w0
    2cdc:      	mov	w9, #0x6d               // =109
    2ce0:      	blr	x9
    2ce4:      	mov	w20, #0x2               // =2
    2ce8:      	b	0x30cc <do_action+0x4ac>
    2cec:      	sub	w8, w22, #0x6
    2cf0:      	cmp	w8, #0x2
    2cf4:      	b.lo	0x2f50 <do_action+0x330>
    2cf8:      	cmp	w22, #0x4
    2cfc:      	b.eq	0x2f6c <do_action+0x34c>
    2d00:      	cmp	w22, #0x5
    2d04:      	b.ne	0x3110 <do_action+0x4f0>
    2d08:      	add	w9, w19, #0x1
    2d0c:      	add	x8, x21, #0x4
    2d10:      	add	w19, w19, #0x2
    2d14:      	ldr	w9, [x8, w9, uxtw #2]
    2d18:      	and	x9, x9, #0x7
    2d1c:      	cmp	w9, #0x4
    2d20:      	b.hi	0x3110 <do_action+0x4f0>
    2d24:      	add	x10, x29, x9, lsl #2
    2d28:      	mov	w11, #0x5ea0            // =24224
    2d2c:      	ldr	w10, [x10, x11]
    2d30:      	cbnz	w10, 0x3110 <do_action+0x4f0>
    2d34:      	ldr	w20, [x8, w19, uxtw #2]
    2d38:      	add	x8, x29, x9, lsl #3
    2d3c:      	ldr	x8, [x8, #0x5e78]
    2d40:      	str	wzr, [sp, #0x54]
    2d44:      	and	x8, x8, #0x7ff
    2d48:      	add	x8, x29, x8
    2d4c:      	ldr	w8, [x8, #0x90]
    2d50:      	str	w8, [sp, #0x50]
    2d54:      	mov	w8, #0xe                // =14
    2d58:      	blr	x8
    2d5c:      	lsr	x8, x0, #32
    2d60:      	adrp	x21, 0x2000 <filter_inet+0x240>
    2d64:      	add	x9, sp, #0x48
    2d68:      	str	x8, [sp, #0x48]
    2d6c:      	mov	w8, #0x1                // =1
    2d70:      	add	x1, sp, #0x48
    2d74:      	ldr	x21, [x21]
    2d78:      	mov	x0, x21
    2d7c:      	blr	x8
    2d80:      	cbz	x0, 0x3110 <do_action+0x4f0>
    2d84:      	and	x8, x20, #0x7
    2d88:      	cmp	w8, #0x4
    2d8c:      	b.hi	0x3110 <do_action+0x4f0>
    2d90:      	add	x9, x29, x8, lsl #2
    2d94:      	mov	w10, #0x5ea0            // =24224
    2d98:      	ldr	w9, [x9, x10]
    2d9c:      	cbnz	w9, 0x3110 <do_action+0x4f0>
    2da0:      	add	x8, x29, x8, lsl #3
    2da4:      	mov	x23, x0
    2da8:      	ldr	x8, [x8, #0x5e78]
    2dac:      	str	wzr, [sp, #0x54]
    2db0:      	and	x8, x8, #0x7ff
    2db4:      	add	x8, x29, x8
    2db8:      	ldr	w8, [x8, #0x90]
    2dbc:      	str	w8, [sp, #0x50]
    2dc0:      	mov	w8, #0xe                // =14
    2dc4:      	blr	x8
    2dc8:      	lsr	x8, x0, #32
    2dcc:      	mov	x3, xzr
    2dd0:      	add	x9, sp, #0x48
    2dd4:      	str	x8, [sp, #0x48]
    2dd8:      	mov	w8, #0x2                // =2
    2ddc:      	add	x1, sp, #0x48
    2de0:      	mov	x0, x21
    2de4:      	mov	x2, x23
    2de8:      	blr	x8
    2dec:      	b	0x3110 <do_action+0x4f0>
    2df0:      	cmp	w22, #0xc
    2df4:      	b.eq	0x30bc <do_action+0x49c>
    2df8:      	cmp	w22, #0xd
    2dfc:      	b.eq	0x2f7c <do_action+0x35c>
    2e00:      	cmp	w22, #0xe
    2e04:      	b.ne	0x3110 <do_action+0x4f0>
    2e08:      	tst	w25, #0x1
    2e0c:      	mov	w8, #0x8                // =8
    2e10:      	add	w19, w19, #0x2
    2e14:      	b	0x30c8 <do_action+0x4a8>
    2e18:      	cmp	w22, #0x2
    2e1c:      	b.eq	0x30ac <do_action+0x48c>
    2e20:      	cmp	w22, #0x3
    2e24:      	b.ne	0x3110 <do_action+0x4f0>
    2e28:      	add	w8, w19, #0x1
    2e2c:      	add	x9, x21, #0x4
    2e30:      	add	w19, w19, #0x2
    2e34:      	str	wzr, [sp, #0x58]
    2e38:      	ldr	w21, [x9, w8, uxtw #2]
    2e3c:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2e40:      	ldr	w20, [x9, w19, uxtw #2]
    2e44:      	ldr	x0, [x0]
    2e48:      	mov	w8, #0x1                // =1
    2e4c:      	add	x9, sp, #0x58
    2e50:      	add	x1, sp, #0x58
    2e54:      	blr	x8
    2e58:      	cbz	x0, 0x2f44 <do_action+0x324>
    2e5c:      	and	x8, x21, #0x7
    2e60:      	cmp	w8, #0x4
    2e64:      	b.hi	0x2f40 <do_action+0x320>
    2e68:      	add	x9, x29, x8, lsl #2
    2e6c:      	mov	w10, #0x5ea0            // =24224
    2e70:      	ldr	w9, [x9, x10]
    2e74:      	cbnz	w9, 0x2f40 <do_action+0x320>
    2e78:      	add	x8, x29, x8, lsl #3
    2e7c:      	mov	x21, x0
    2e80:      	ldr	x8, [x8, #0x5e78]
    2e84:      	str	wzr, [sp, #0x54]
    2e88:      	and	x8, x8, #0x7ff
    2e8c:      	add	x8, x29, x8
    2e90:      	ldr	w8, [x8, #0x90]
    2e94:      	str	w8, [sp, #0x50]
    2e98:      	mov	w8, #0xe                // =14
    2e9c:      	blr	x8
    2ea0:      	lsr	x8, x0, #32
    2ea4:      	cmp	w22, #0x1
    2ea8:      	str	x8, [sp, #0x48]
    2eac:      	b.ne	0x323c <do_action+0x61c>
    2eb0:      	and	x8, x20, #0x7
    2eb4:      	cmp	w8, #0x4
    2eb8:      	b.hi	0x2f40 <do_action+0x320>
    2ebc:      	add	x9, x29, x8, lsl #2
    2ec0:      	mov	w10, #0x5ea0            // =24224
    2ec4:      	ldr	w9, [x9, x10]
    2ec8:      	cbnz	w9, 0x2f40 <do_action+0x320>
    2ecc:      	add	x8, x29, x8, lsl #3
    2ed0:      	mov	x0, x21
    2ed4:      	ldr	x8, [x8, #0x5e78]
    2ed8:      	and	x8, x8, #0x7ff
    2edc:      	add	x2, x29, x8
    2ee0:      	ldr	w8, [x2, #0x90]!
    2ee4:      	and	x8, x8, #0xfff
    2ee8:      	add	x1, x8, #0x8
    2eec:      	mov	w8, #0x4                // =4
    2ef0:      	blr	x8
    2ef4:      	adrp	x0, 0x2000 <filter_inet+0x240>
    2ef8:      	mov	x3, xzr
    2efc:      	mov	w8, #0x2                // =2
    2f00:      	ldr	x0, [x0]
    2f04:      	add	x9, sp, #0x48
    2f08:      	add	x1, sp, #0x48
    2f0c:      	mov	x2, x21
    2f10:      	blr	x8
    2f14:      	b	0x2f40 <do_action+0x320>
    2f18:      	add	w19, w19, #0x1
    2f1c:      	add	x8, x21, w19, uxtw #2
    2f20:      	ldr	w8, [x8, #0x4]
    2f24:      	and	x8, x8, #0x7
    2f28:      	cmp	w8, #0x4
    2f2c:      	b.hi	0x2f40 <do_action+0x320>
    2f30:      	add	x9, x29, x8, lsl #2
    2f34:      	mov	w10, #0x5ea0            // =24224
    2f38:      	ldr	w9, [x9, x10]
    2f3c:      	cbz	w9, 0x3134 <do_action+0x514>
    2f40:      	mov	w0, wzr
    2f44:      	cbz	w0, 0x3110 <do_action+0x4f0>
    2f48:      	mov	w0, wzr
    2f4c:      	b	0x3118 <do_action+0x4f8>
    2f50:      	add	w19, w19, #0x1
    2f54:      	add	x8, x21, w19, uxtw #2
    2f58:      	ldr	w8, [x8, #0x4]
    2f5c:      	str	w8, [x29, #0x78]
    2f60:      	b	0x3110 <do_action+0x4f0>
    2f64:      	strb	wzr, [x23]
    2f68:      	b	0x3110 <do_action+0x4f0>
    2f6c:      	tst	w25, #0x1
    2f70:      	mov	w8, #0x4                // =4
    2f74:      	add	w19, w19, #0x1
    2f78:      	b	0x30c8 <do_action+0x4a8>
    2f7c:      	mov	w8, #0xe                // =14
    2f80:      	blr	x8
    2f84:      	str	x0, [sp, #0x68]
    2f88:      	adrp	x21, 0x2000 <filter_inet+0x240>
    2f8c:      	add	x8, sp, #0x68
    2f90:      	mov	w9, #0x1                // =1
    2f94:      	ldr	x21, [x21]
    2f98:      	add	x1, sp, #0x68
    2f9c:      	mov	w20, #0x1               // =1
    2fa0:      	mov	x0, x21
    2fa4:      	blr	x9
    2fa8:      	cbz	x0, 0x3110 <do_action+0x4f0>
    2fac:      	ldur	x8, [x0, #0x4]
    2fb0:      	adrp	x25, 0x2000 <filter_inet+0x240>
    2fb4:      	mov	w9, #0x1                // =1
    2fb8:      	add	x1, sp, #0x58
    2fbc:      	str	x8, [sp, #0x58]
    2fc0:      	mov	w8, #0x2                // =2
    2fc4:      	str	w8, [sp, #0x60]
    2fc8:      	add	x8, sp, #0x58
    2fcc:      	ldr	x25, [x25]
    2fd0:      	mov	x0, x25
    2fd4:      	blr	x9
    2fd8:      	str	w20, [sp, #0x78]
    2fdc:      	cbz	x0, 0x31c0 <do_action+0x5a0>
    2fe0:      	ldaxr	w8, [x0]
    2fe4:      	add	w8, w8, #0x1
    2fe8:      	stlxr	w9, w8, [x0]
    2fec:      	cbnz	w9, 0x2fe0 <do_action+0x3c0>
    2ff0:      	mov	w8, #0x3                // =3
    2ff4:      	add	x9, sp, #0x68
    2ff8:      	add	x1, sp, #0x68
    2ffc:      	mov	x0, x21
    3000:      	blr	x8
    3004:      	b	0x3110 <do_action+0x4f0>
    3008:      	add	w8, w19, #0x1
    300c:      	add	x9, x21, #0x4
    3010:      	str	x20, [sp, #0x30]
    3014:      	ldr	w25, [x9, w8, uxtw #2]
    3018:      	add	w8, w19, #0x2
    301c:      	ldr	w20, [x9, w8, uxtw #2]
    3020:      	mov	w8, #0x7d               // =125
    3024:      	blr	x8
    3028:      	str	x0, [sp, #0x8]
    302c:      	str	x0, [sp, #0x48]
    3030:      	str	wzr, [sp, #0x68]
    3034:      	cbz	w25, 0x3468 <do_action+0x848>
    3038:      	adrp	x0, 0x3000 <do_action+0x3e0>
    303c:      	mov	w8, #0x1                // =1
    3040:      	add	x9, sp, #0x68
    3044:      	ldr	x0, [x0]
    3048:      	add	x1, sp, #0x68
    304c:      	blr	x8
    3050:      	cbz	x0, 0x3468 <do_action+0x848>
    3054:      	mov	x10, x0
    3058:      	adrp	x0, 0x3000 <do_action+0x3e0>
    305c:      	mov	w8, #0x1                // =1
    3060:      	ldr	x0, [x0]
    3064:      	add	x9, sp, #0x68
    3068:      	add	x1, sp, #0x68
    306c:      	str	x10, [sp, #0x10]
    3070:      	blr	x8
    3074:      	ldr	x9, [sp, #0x10]
    3078:      	ldr	x8, [x29, #0x60]
    307c:      	mov	x2, x0
    3080:      	cmp	w20, #0x2
    3084:      	str	x8, [x9]
    3088:      	ldr	x8, [x29, #0x70]
    308c:      	str	x8, [x9, #0x8]
    3090:      	b.eq	0x3280 <do_action+0x660>
    3094:      	cmp	w20, #0x1
    3098:      	b.eq	0x3274 <do_action+0x654>
    309c:      	cbnz	w20, 0x3468 <do_action+0x848>
    30a0:      	ldr	w8, [x29, #0x7c]
    30a4:      	str	x25, [sp]
    30a8:      	b	0x3288 <do_action+0x668>
    30ac:      	mov	w0, #0x9                // =9
    30b0:      	tbnz	w25, #0x0, 0x2cd8 <do_action+0xb8>
    30b4:      	mov	w20, #0x3               // =3
    30b8:      	b	0x30cc <do_action+0x4ac>
    30bc:      	tst	w25, #0x1
    30c0:      	mov	w8, #0x6                // =6
    30c4:      	add	w19, w19, #0x3
    30c8:      	cinc	x20, x8, eq
    30cc:      	str	wzr, [sp, #0x48]
    30d0:      	adrp	x0, 0x3000 <do_action+0x3e0>
    30d4:      	mov	w8, #0x1                // =1
    30d8:      	add	x9, sp, #0x48
    30dc:      	ldr	x0, [x0]
    30e0:      	add	x1, sp, #0x48
    30e4:      	blr	x8
    30e8:      	cbz	x0, 0x3110 <do_action+0x4f0>
    30ec:      	add	x8, x0, x20, lsl #3
    30f0:      	nop
    30f4:      	nop
    30f8:      	nop
    30fc:      	nop
    3100:      	ldaxr	x9, [x8]
    3104:      	add	x9, x9, #0x1
    3108:      	stlxr	w10, x9, [x8]
    310c:      	cbnz	w10, 0x3100 <do_action+0x4e0>
    3110:      	add	w0, w19, #0x1
    3114:      	str	x22, [x29, #0x70]
    3118:      	ldp	x20, x19, [sp, #0xb0]
    311c:      	ldr	x29, [sp, #0x70]
    3120:      	ldp	x22, x21, [sp, #0xa0]
    3124:      	ldp	x24, x23, [sp, #0x90]
    3128:      	ldp	x30, x25, [sp, #0x80]
    312c:      	add	sp, sp, #0xc0
    3130:      	ret
    3134:      	add	x8, x29, x8, lsl #3
    3138:      	ldr	x8, [x8, #0x5e78]
    313c:      	and	x8, x8, #0x7ff
    3140:      	add	x8, x29, x8
    3144:      	ldr	x8, [x8, #0xb8]
    3148:      	str	x8, [sp, #0x58]
    314c:      	cbz	x8, 0x2f40 <do_action+0x320>
    3150:      	cmp	w22, #0xa
    3154:      	b.ne	0x3258 <do_action+0x638>
    3158:      	mov	w8, #0xe                // =14
    315c:      	blr	x8
    3160:      	lsr	x8, x0, #32
    3164:      	mov	x21, x0
    3168:      	adrp	x0, 0x3000 <do_action+0x3e0>
    316c:      	str	w8, [sp, #0x48]
    3170:      	mov	w8, #0x1                // =1
    3174:      	add	x9, sp, #0x48
    3178:      	add	x1, sp, #0x48
    317c:      	ldr	x0, [x0]
    3180:      	blr	x8
    3184:      	cbz	x0, 0x2f44 <do_action+0x324>
    3188:      	ldr	w8, [x0]
    318c:      	mov	x3, xzr
    3190:      	add	x9, sp, #0x58
    3194:      	add	x10, sp, #0x48
    3198:      	stp	w8, w21, [sp, #0x48]
    319c:      	ldr	x8, [x0, #0x8]
    31a0:      	adrp	x0, 0x3000 <do_action+0x3e0>
    31a4:      	add	x1, sp, #0x58
    31a8:      	add	x2, sp, #0x48
    31ac:      	str	x8, [sp, #0x50]
    31b0:      	mov	w8, #0x2                // =2
    31b4:      	ldr	x0, [x0]
    31b8:      	blr	x8
    31bc:      	b	0x2f40 <do_action+0x320>
    31c0:      	mov	w8, #0x1                // =1
    31c4:      	mov	w9, #0x2                // =2
    31c8:      	add	x10, sp, #0x58
    31cc:      	add	x11, sp, #0x78
    31d0:      	add	x1, sp, #0x58
    31d4:      	add	x2, sp, #0x78
    31d8:      	mov	x0, x25
    31dc:      	mov	w3, #0x1                // =1
    31e0:      	blr	x9
    31e4:      	cbz	x0, 0x2ff0 <do_action+0x3d0>
    31e8:      	mov	x23, x0
    31ec:      	adrp	x24, 0x3000 <do_action+0x3e0>
    31f0:      	mov	w9, #0x1                // =1
    31f4:      	add	x1, sp, #0x48
    31f8:      	mov	w20, #0x1               // =1
    31fc:      	neg	w8, w23
    3200:      	strh	w8, [sp, #0x48]
    3204:      	mov	w8, #0x3                // =3
    3208:      	strh	w8, [sp, #0x4a]
    320c:      	mov	x8, #0x3b               // =59
    3210:      	movk	x8, #0x2, lsl #32
    3214:      	stur	x8, [sp, #0x4c]
    3218:      	add	x8, sp, #0x48
    321c:      	ldr	x24, [x24]
    3220:      	mov	x0, x24
    3224:      	blr	x9
    3228:      	cbz	x0, 0x3500 <do_action+0x8e0>
    322c:      	ldr	w8, [x0]
    3230:      	add	w8, w8, #0x1
    3234:      	str	w8, [x0]
    3238:      	b	0x3524 <do_action+0x904>
    323c:      	adrp	x0, 0x3000 <do_action+0x3e0>
    3240:      	mov	w8, #0x3                // =3
    3244:      	add	x9, sp, #0x48
    3248:      	ldr	x0, [x0]
    324c:      	add	x1, sp, #0x48
    3250:      	blr	x8
    3254:      	b	0x2f44 <do_action+0x324>
    3258:      	adrp	x0, 0x3000 <do_action+0x3e0>
    325c:      	mov	w8, #0x3                // =3
    3260:      	add	x9, sp, #0x58
    3264:      	ldr	x0, [x0]
    3268:      	add	x1, sp, #0x58
    326c:      	blr	x8
    3270:      	b	0x2f44 <do_action+0x324>
    3274:      	ldr	w8, [x29, #0x10]
    3278:      	str	x25, [sp]
    327c:      	b	0x3288 <do_action+0x668>
    3280:      	str	x25, [sp]
    3284:      	mov	w8, wzr
    3288:      	mov	w8, w8
    328c:      	add	x0, x9, #0x18
    3290:      	mov	w1, #0xc8               // =200
    3294:      	str	x8, [x9, #0x10]
    3298:      	mov	w8, #0xc8               // =200
    329c:      	mov	w9, #0x4                // =4
    32a0:      	str	x0, [sp, #0x18]
    32a4:      	blr	x9
    32a8:      	ldr	x20, [sp, #0x30]
    32ac:      	mov	w8, #0x5e78             // =24184
    32b0:      	mov	x25, xzr
    32b4:      	str	wzr, [sp, #0x2c]
    32b8:      	add	x10, x29, x8
    32bc:      	str	x23, [sp, #0x20]
    32c0:      	b	0x32d4 <do_action+0x6b4>
    32c4:      	add	x25, x25, #0x4
    32c8:      	add	x10, x10, #0x8
    32cc:      	cmp	x25, #0x14
    32d0:      	b.eq	0x340c <do_action+0x7ec>
    32d4:      	str	x10, [sp, #0x38]
    32d8:      	str	wzr, [sp, #0x58]
    32dc:      	mov	w8, #0x1                // =1
    32e0:      	add	x9, sp, #0x58
    32e4:      	add	x1, sp, #0x58
    32e8:      	mov	x0, x24
    32ec:      	blr	x8
    32f0:      	cbz	x0, 0x340c <do_action+0x7ec>
    32f4:      	mov	w8, #0x5ef8             // =24312
    32f8:      	add	x1, x0, x8
    32fc:      	adrp	x0, 0x3000 <do_action+0x3e0>
    3300:      	mov	w8, #0x1                // =1
    3304:      	ldr	x0, [x0]
    3308:      	blr	x8
    330c:      	cbz	x0, 0x340c <do_action+0x7ec>
    3310:      	add	x8, x0, x25
    3314:      	ldr	x10, [sp, #0x38]
    3318:      	ldr	w8, [x8, #0x40]
    331c:      	cmn	w8, #0x1
    3320:      	b.eq	0x340c <do_action+0x7ec>
    3324:      	ldr	x8, [x10]
    3328:      	ldr	w9, [x29, #0x4]
    332c:      	cmp	x8, x9
    3330:      	b.ge	0x340c <do_action+0x7ec>
    3334:      	cmp	x25, #0x10
    3338:      	b.eq	0x33a0 <do_action+0x780>
    333c:      	str	wzr, [sp, #0x58]
    3340:      	mov	w8, #0x1                // =1
    3344:      	add	x9, sp, #0x58
    3348:      	add	x1, sp, #0x58
    334c:      	mov	x0, x24
    3350:      	blr	x8
    3354:      	cbz	x0, 0x3398 <do_action+0x778>
    3358:      	mov	w8, #0x5ef8             // =24312
    335c:      	add	x1, x0, x8
    3360:      	adrp	x0, 0x3000 <do_action+0x3e0>
    3364:      	mov	w8, #0x1                // =1
    3368:      	ldr	x0, [x0]
    336c:      	blr	x8
    3370:      	cbz	x0, 0x3398 <do_action+0x778>
    3374:      	ldr	x10, [sp, #0x38]
    3378:      	add	x8, x0, x25
    337c:      	ldr	w9, [x8, #0x44]
    3380:      	ldr	x8, [x10]
    3384:      	cmn	w9, #0x1
    3388:      	b.eq	0x33a0 <do_action+0x780>
    338c:      	ldr	w9, [x10, #0x8]
    3390:      	sub	w9, w9, w8
    3394:      	b	0x33ac <do_action+0x78c>
    3398:      	ldr	x10, [sp, #0x38]
    339c:      	ldr	x8, [x10]
    33a0:      	ldr	w9, [x29, #0x4]
    33a4:      	sub	w9, w9, w8
    33a8:      	add	w9, w9, #0x4
    33ac:      	cmp	w9, #0x1
    33b0:      	b.lt	0x32c4 <do_action+0x6a4>
    33b4:      	mov	w10, #0x3ffc            // =16380
    33b8:      	cmp	w9, #0x28
    33bc:      	mov	x23, x29
    33c0:      	add	w8, w8, w10
    33c4:      	mov	w10, #0x28              // =40
    33c8:      	csel	w29, w9, w10, lt
    33cc:      	ldr	w9, [sp, #0x2c]
    33d0:      	and	x8, x8, #0x3fff
    33d4:      	add	x8, x23, x8
    33d8:      	mov	w1, w29
    33dc:      	add	x2, x8, #0x90
    33e0:      	mov	w8, #0x4                // =4
    33e4:      	and	w20, w9, #0xff
    33e8:      	ldr	x9, [sp, #0x18]
    33ec:      	add	x0, x9, x20
    33f0:      	blr	x8
    33f4:      	add	w8, w29, w20
    33f8:      	ldp	x20, x10, [sp, #0x30]
    33fc:      	mov	x29, x23
    3400:      	ldr	x23, [sp, #0x20]
    3404:      	str	w8, [sp, #0x2c]
    3408:      	b	0x32c4 <do_action+0x6a4>
    340c:      	adrp	x24, 0x3000 <do_action+0x3e0>
    3410:      	mov	w8, #0x1                // =1
    3414:      	ldr	x24, [x24]
    3418:      	ldr	x1, [sp, #0x10]
    341c:      	mov	x0, x24
    3420:      	blr	x8
    3424:      	cbz	x0, 0x344c <do_action+0x82c>
    3428:      	ldp	x10, x11, [sp]
    342c:      	mov	x9, #-0x4240            // =-16960
    3430:      	movk	x9, #0xfff0, lsl #16
    3434:      	ldr	x8, [x0]
    3438:      	madd	x9, x10, x9, x11
    343c:      	cmp	x8, x9
    3440:      	b.ls	0x344c <do_action+0x82c>
    3444:      	strb	wzr, [x23]
    3448:      	b	0x346c <do_action+0x84c>
    344c:      	ldr	x1, [sp, #0x10]
    3450:      	mov	x3, xzr
    3454:      	mov	w8, #0x2                // =2
    3458:      	add	x9, sp, #0x48
    345c:      	add	x2, sp, #0x48
    3460:      	mov	x0, x24
    3464:      	blr	x8
    3468:      	ldr	x20, [sp, #0x30]
    346c:      	add	w8, w19, #0x3
    3470:      	adrp	x23, 0x3000 <do_action+0x3e0>
    3474:      	add	x8, x21, w8, uxtw #2
    3478:      	ldr	w8, [x8, #0x4]
    347c:      	ldr	x23, [x23]
    3480:      	cbz	w8, 0x34a8 <do_action+0x888>
    3484:      	ldrb	w8, [x29, #0x1]
    3488:      	mov	x2, xzr
    348c:      	mov	x0, x20
    3490:      	mov	x1, x23
    3494:      	orr	w8, w8, #0x2
    3498:      	strb	w8, [x29, #0x1]
    349c:      	mov	w8, #0x1b               // =27
    34a0:      	blr	x8
    34a4:      	str	x0, [x29, #0x80]
    34a8:      	add	w8, w19, #0x4
    34ac:      	add	x8, x21, w8, uxtw #2
    34b0:      	ldr	w8, [x8, #0x4]
    34b4:      	cbz	w8, 0x34e0 <do_action+0x8c0>
    34b8:      	ldrb	w8, [x29, #0x1]
    34bc:      	mov	w9, #0x1b               // =27
    34c0:      	mov	x0, x20
    34c4:      	mov	x1, x23
    34c8:      	mov	w2, #0x100              // =256
    34cc:      	orr	w8, w8, #0x4
    34d0:      	strb	w8, [x29, #0x1]
    34d4:      	mov	w8, #0x100              // =256
    34d8:      	blr	x9
    34dc:      	str	x0, [x29, #0x88]
    34e0:      	add	w19, w19, #0x5
    34e4:      	add	x8, x21, w19, uxtw #2
    34e8:      	ldr	w8, [x8, #0x4]
    34ec:      	cbz	w8, 0x3110 <do_action+0x4f0>
    34f0:      	ldrb	w8, [x29, #0x1]
    34f4:      	orr	w8, w8, #0x8
    34f8:      	strb	w8, [x29, #0x1]
    34fc:      	b	0x3110 <do_action+0x4f0>
    3500:      	str	w20, [sp, #0x7c]
    3504:      	mov	x3, xzr
    3508:      	mov	w8, #0x2                // =2
    350c:      	add	x9, sp, #0x48
    3510:      	add	x10, sp, #0x7c
    3514:      	add	x1, sp, #0x48
    3518:      	add	x2, sp, #0x7c
    351c:      	mov	x0, x24
    3520:      	blr	x8
    3524:      	cbz	w23, 0x2ff0 <do_action+0x3d0>
    3528:      	mov	w8, #0x1                // =1
    352c:      	add	x9, sp, #0x58
    3530:      	add	x1, sp, #0x58
    3534:      	mov	x0, x25
    3538:      	blr	x8
    353c:      	cbz	x0, 0x2ff0 <do_action+0x3d0>
    3540:      	ldr	w8, [sp, #0x78]
    3544:      	ldaxr	w9, [x0]
    3548:      	add	w9, w9, w8
    354c:      	stlxr	w10, w9, [x0]
    3550:      	cbnz	w10, 0x3544 <do_action+0x924>
    3554:      	b	0x2ff0 <do_action+0x3d0>

Disassembly of section kprobe:

0000000000000000 <generic_retkprobe_filter_arg>:
       0:      	sub	sp, sp, #0x70
       4:      	str	x29, [sp, #0x20]
       8:      	stp	x30, x25, [sp, #0x30]
       c:      	stp	x24, x23, [sp, #0x40]
      10:      	stp	x22, x21, [sp, #0x50]
      14:      	stp	x20, x19, [sp, #0x60]
      18:      	mov	x19, x0
      1c:      	str	wzr, [sp, #0x2c]
      20:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
      24:      	mov	w8, #0x1                // =1
      28:      	ldr	x0, [x0]
      2c:      	add	x9, sp, #0x2c
      30:      	add	x1, sp, #0x2c
      34:      	blr	x8
      38:      	cbz	x0, 0x394 <generic_retkprobe_filter_arg+0x394>
      3c:      	mov	w8, #0x5ec1             // =24257
      40:      	mov	x20, x0
      44:      	add	x22, x0, x8
      48:      	mov	w8, #0x5ef8             // =24312
      4c:      	add	x1, x0, x8
      50:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
      54:      	ldur	w23, [x22, #0x3f]
      58:      	mov	w8, #0x1                // =1
      5c:      	ldr	x0, [x0]
      60:      	blr	x8
      64:      	cbz	x0, 0x378 <generic_retkprobe_filter_arg+0x378>
      68:      	ldrb	w8, [x22, #0x1f]
      6c:      	cbz	w8, 0x378 <generic_retkprobe_filter_arg+0x378>
      70:      	and	x8, x23, #0x7
      74:      	mov	w10, #0x5ec1            // =24257
      78:      	add	x9, x20, x8
      7c:      	ldrb	w9, [x9, x10]
      80:      	cbz	w9, 0xc4 <generic_retkprobe_filter_arg+0xc4>
      84:      	lsl	w8, w8, #2
      88:      	mov	x21, x0
      8c:      	add	x8, x8, #0x4
      90:      	ldr	w9, [x8, x0]
      94:      	add	x8, x8, x9
      98:      	add	x25, x8, #0x4
      9c:      	and	x8, x25, #0x3ff
      a0:      	add	x29, x0, x8
      a4:      	str	x8, [sp, #0x8]
      a8:      	ldr	w8, [x29]
      ac:      	cmp	w8, #0x19
      b0:      	b.hs	0x10c <generic_retkprobe_filter_arg+0x10c>
      b4:      	ldr	x8, [sp, #0x8]
      b8:      	cmp	w8, #0x1
      bc:      	b.eq	0x378 <generic_retkprobe_filter_arg+0x378>
      c0:      	cbnz	w8, 0x354 <generic_retkprobe_filter_arg+0x354>
      c4:      	cmp	w23, #0x1
      c8:      	b.gt	0xe4 <generic_retkprobe_filter_arg+0xe4>
      cc:      	cmn	w23, #0x1
      d0:      	b.eq	0x3b4 <generic_retkprobe_filter_arg+0x3b4>
      d4:      	cbz	w23, 0x3c4 <generic_retkprobe_filter_arg+0x3c4>
      d8:      	cmp	w23, #0x1
      dc:      	b.eq	0x3d4 <generic_retkprobe_filter_arg+0x3d4>
      e0:      	b	0xfc <generic_retkprobe_filter_arg+0xfc>
      e4:      	cmp	w23, #0x2
      e8:      	b.eq	0x3e4 <generic_retkprobe_filter_arg+0x3e4>
      ec:      	cmp	w23, #0x3
      f0:      	b.eq	0x3f4 <generic_retkprobe_filter_arg+0x3f4>
      f4:      	cmp	w23, #0x4
      f8:      	b.eq	0x404 <generic_retkprobe_filter_arg+0x404>
      fc:      	cmp	w23, #0x4
     100:      	b.gt	0x430 <generic_retkprobe_filter_arg+0x430>
     104:      	add	w8, w23, #0x1
     108:      	b	0x410 <generic_retkprobe_filter_arg+0x410>
     10c:      	mov	w24, #0x4               // =4
     110:      	nop
     114:      	nop
     118:      	nop
     11c:      	nop
     120:      	ldr	w8, [x29, x24]
     124:      	tst	w8, #0x3ff
     128:      	b.eq	0xb4 <generic_retkprobe_filter_arg+0xb4>
     12c:      	add	w8, w25, w8
     130:      	and	x8, x8, #0x3ff
     134:      	add	x0, x21, x8
     138:      	ldr	w9, [x0, #0x4]
     13c:      	cmp	w9, #0x23
     140:      	b.eq	0xc4 <generic_retkprobe_filter_arg+0xc4>
     144:      	ldr	w8, [x0]
     148:      	cmp	w8, #0x4
     14c:      	b.hi	0xc4 <generic_retkprobe_filter_arg+0xc4>
     150:      	add	x10, x20, x8, lsl #2
     154:      	mov	w11, #0x5ea0            // =24224
     158:      	ldr	w10, [x10, x11]
     15c:      	cbnz	w10, 0xc4 <generic_retkprobe_filter_arg+0xc4>
     160:      	add	x8, x20, x8, lsl #3
     164:      	ldr	x8, [x8, #0x5e78]
     168:      	and	x8, x8, #0x7ff
     16c:      	add	x8, x20, x8
     170:      	add	x1, x8, #0x90
     174:      	ldr	w8, [x0, #0xc]
     178:      	cmp	w8, #0x1b
     17c:      	b.le	0x1a0 <generic_retkprobe_filter_arg+0x1a0>
     180:      	cmp	w8, #0x25
     184:      	b.gt	0x1d4 <generic_retkprobe_filter_arg+0x1d4>
     188:      	sub	w10, w8, #0x1c
     18c:      	cmp	w10, #0x9
     190:      	b.lo	0x218 <generic_retkprobe_filter_arg+0x218>
     194:      	cmp	w8, #0x25
     198:      	b.eq	0x300 <generic_retkprobe_filter_arg+0x300>
     19c:      	b	0x344 <generic_retkprobe_filter_arg+0x344>
     1a0:      	cmp	w8, #0x9
     1a4:      	b.le	0x1f8 <generic_retkprobe_filter_arg+0x1f8>
     1a8:      	sub	w10, w8, #0xa
     1ac:      	cmp	w10, #0x4
     1b0:      	b.lo	0x218 <generic_retkprobe_filter_arg+0x218>
     1b4:      	sub	w9, w8, #0xf
     1b8:      	cmp	w9, #0x2
     1bc:      	b.lo	0x300 <generic_retkprobe_filter_arg+0x300>
     1c0:      	cmp	w8, #0x11
     1c4:      	b.ne	0x344 <generic_retkprobe_filter_arg+0x344>
     1c8:      	add	x1, x1, #0x4
     1cc:      	bl	0x1cc <generic_retkprobe_filter_arg+0x1cc>
     1d0:      	b	0x340 <generic_retkprobe_filter_arg+0x340>
     1d4:      	cmp	w8, #0x29
     1d8:      	b.gt	0x2e8 <generic_retkprobe_filter_arg+0x2e8>
     1dc:      	sub	w9, w8, #0x26
     1e0:      	cmp	w9, #0x2
     1e4:      	b.lo	0x29c <generic_retkprobe_filter_arg+0x29c>
     1e8:      	sub	w8, w8, #0x28
     1ec:      	cmp	w8, #0x2
     1f0:      	b.lo	0x294 <generic_retkprobe_filter_arg+0x294>
     1f4:      	b	0x344 <generic_retkprobe_filter_arg+0x344>
     1f8:      	cmp	w8, #0x4
     1fc:      	b.gt	0x27c <generic_retkprobe_filter_arg+0x27c>
     200:      	cmp	w8, #0x1
     204:      	b.eq	0x218 <generic_retkprobe_filter_arg+0x218>
     208:      	cmp	w8, #0x2
     20c:      	b.eq	0x324 <generic_retkprobe_filter_arg+0x324>
     210:      	cmp	w8, #0x4
     214:      	b.ne	0x344 <generic_retkprobe_filter_arg+0x344>
     218:      	cmp	w8, #0xb
     21c:      	b.le	0x25c <generic_retkprobe_filter_arg+0x25c>
     220:      	cmp	w8, #0x24
     224:      	b.hi	0x308 <generic_retkprobe_filter_arg+0x308>
     228:      	mov	w11, #0x1               // =1
     22c:      	lsl	x10, x11, x8
     230:      	tst	x10, #0x1e00000000
     234:      	b.ne	0x2a4 <generic_retkprobe_filter_arg+0x2a4>
     238:      	lsl	x9, x11, x8
     23c:      	tst	x9, #0x60000000
     240:      	mov	w9, #0x1                // =1
     244:      	b.ne	0x31c <generic_retkprobe_filter_arg+0x31c>
     248:      	lsl	x9, x9, x8
     24c:      	tst	x9, #0x180000000
     250:      	b.eq	0x308 <generic_retkprobe_filter_arg+0x308>
     254:      	bl	0x254 <generic_retkprobe_filter_arg+0x254>
     258:      	b	0x340 <generic_retkprobe_filter_arg+0x340>
     25c:      	sub	w9, w8, #0xa
     260:      	cmp	w9, #0x2
     264:      	b.lo	0x338 <generic_retkprobe_filter_arg+0x338>
     268:      	cmp	w8, #0x1
     26c:      	b.eq	0x314 <generic_retkprobe_filter_arg+0x314>
     270:      	cmp	w8, #0x4
     274:      	b.eq	0x314 <generic_retkprobe_filter_arg+0x314>
     278:      	b	0x344 <generic_retkprobe_filter_arg+0x344>
     27c:      	cmp	w8, #0x5
     280:      	b.eq	0x294 <generic_retkprobe_filter_arg+0x294>
     284:      	cmp	w8, #0x6
     288:      	b.eq	0x29c <generic_retkprobe_filter_arg+0x29c>
     28c:      	cmp	w8, #0x7
     290:      	b.ne	0x344 <generic_retkprobe_filter_arg+0x344>
     294:      	bl	0x294 <generic_retkprobe_filter_arg+0x294>
     298:      	b	0x340 <generic_retkprobe_filter_arg+0x340>
     29c:      	mov	w2, #0x4                // =4
     2a0:      	b	0x328 <generic_retkprobe_filter_arg+0x328>
     2a4:      	cmp	w9, #0x1e
     2a8:      	b.ne	0x338 <generic_retkprobe_filter_arg+0x338>
     2ac:      	ldr	w8, [x0, #0x10]
     2b0:      	mov	w10, #0x5ea0            // =24224
     2b4:      	and	x8, x8, #0x7
     2b8:      	add	x9, x20, x8, lsl #2
     2bc:      	ldr	w9, [x9, x10]
     2c0:      	cbnz	w9, 0xc4 <generic_retkprobe_filter_arg+0xc4>
     2c4:      	add	x8, x20, x8, lsl #3
     2c8:      	ldr	x9, [x1]
     2cc:      	ldr	x8, [x8, #0x5e78]
     2d0:      	and	x8, x8, #0x7ff
     2d4:      	add	x8, x20, x8
     2d8:      	ldr	x8, [x8, #0x90]
     2dc:      	bics	xzr, x8, x9
     2e0:      	cset	w0, ne
     2e4:      	b	0x340 <generic_retkprobe_filter_arg+0x340>
     2e8:      	cmp	w8, #0x2a
     2ec:      	b.eq	0x300 <generic_retkprobe_filter_arg+0x300>
     2f0:      	cmp	w8, #0x2c
     2f4:      	b.ne	0x344 <generic_retkprobe_filter_arg+0x344>
     2f8:      	bl	0x2f8 <generic_retkprobe_filter_arg+0x2f8>
     2fc:      	b	0x340 <generic_retkprobe_filter_arg+0x340>
     300:      	bl	0x300 <generic_retkprobe_filter_arg+0x300>
     304:      	b	0x340 <generic_retkprobe_filter_arg+0x340>
     308:      	sub	w9, w8, #0xc
     30c:      	cmp	w9, #0x2
     310:      	b.hs	0x330 <generic_retkprobe_filter_arg+0x330>
     314:      	bl	0x314 <generic_retkprobe_filter_arg+0x314>
     318:      	b	0x340 <generic_retkprobe_filter_arg+0x340>
     31c:      	bl	0x31c <generic_retkprobe_filter_arg+0x31c>
     320:      	b	0x340 <generic_retkprobe_filter_arg+0x340>
     324:      	mov	w2, #0x8                // =8
     328:      	bl	0x328 <generic_retkprobe_filter_arg+0x328>
     32c:      	b	0x340 <generic_retkprobe_filter_arg+0x340>
     330:      	cmp	w8, #0x1c
     334:      	b.ne	0x344 <generic_retkprobe_filter_arg+0x344>
     338:      	bl	0x338 <generic_retkprobe_filter_arg+0x338>
     33c:      	nop
     340:      	cbz	x0, 0xc4 <generic_retkprobe_filter_arg+0xc4>
     344:      	add	x24, x24, #0x4
     348:      	cmp	x24, #0x18
     34c:      	b.ne	0x120 <generic_retkprobe_filter_arg+0x120>
     350:      	b	0xb4 <generic_retkprobe_filter_arg+0xb4>
     354:      	ldr	x8, [sp, #0x8]
     358:      	adrp	x1, 0x0 <generic_retkprobe_filter_arg>
     35c:      	mov	w9, #0xc                // =12
     360:      	mov	x0, x19
     364:      	stur	w8, [x22, #0x43]
     368:      	mov	w8, #0x4                // =4
     36c:      	mov	w2, #0x4                // =4
     370:      	ldr	x1, [x1]
     374:      	blr	x9
     378:      	adrp	x1, 0x0 <generic_retkprobe_filter_arg>
     37c:      	mov	w8, #0x5                // =5
     380:      	mov	w9, #0xc                // =12
     384:      	ldr	x1, [x1]
     388:      	mov	x0, x19
     38c:      	mov	w2, #0x5                // =5
     390:      	blr	x9
     394:      	ldp	x20, x19, [sp, #0x60]
     398:      	mov	w0, wzr
     39c:      	ldr	x29, [sp, #0x20]
     3a0:      	ldp	x22, x21, [sp, #0x50]
     3a4:      	ldp	x24, x23, [sp, #0x40]
     3a8:      	ldp	x30, x25, [sp, #0x30]
     3ac:      	add	sp, sp, #0x70
     3b0:      	ret
     3b4:      	ldrb	w8, [x22]
     3b8:      	cbz	w8, 0x3c4 <generic_retkprobe_filter_arg+0x3c4>
     3bc:      	mov	w8, wzr
     3c0:      	b	0x410 <generic_retkprobe_filter_arg+0x410>
     3c4:      	ldrb	w8, [x22, #0x1]
     3c8:      	cbz	w8, 0x3d4 <generic_retkprobe_filter_arg+0x3d4>
     3cc:      	mov	w8, #0x1                // =1
     3d0:      	b	0x410 <generic_retkprobe_filter_arg+0x410>
     3d4:      	ldrb	w8, [x22, #0x2]
     3d8:      	cbz	w8, 0x3e4 <generic_retkprobe_filter_arg+0x3e4>
     3dc:      	mov	w8, #0x2                // =2
     3e0:      	b	0x410 <generic_retkprobe_filter_arg+0x410>
     3e4:      	ldrb	w8, [x22, #0x3]
     3e8:      	cbz	w8, 0x3f4 <generic_retkprobe_filter_arg+0x3f4>
     3ec:      	mov	w8, #0x3                // =3
     3f0:      	b	0x410 <generic_retkprobe_filter_arg+0x410>
     3f4:      	ldrb	w8, [x22, #0x4]
     3f8:      	cbz	w8, 0x404 <generic_retkprobe_filter_arg+0x404>
     3fc:      	mov	w8, #0x4                // =4
     400:      	b	0x410 <generic_retkprobe_filter_arg+0x410>
     404:      	ldrb	w8, [x22, #0x5]
     408:      	cbz	w8, 0x430 <generic_retkprobe_filter_arg+0x430>
     40c:      	mov	w8, #0x5                // =5
     410:      	stur	w8, [x22, #0x3f]
     414:      	adrp	x1, 0x0 <generic_retkprobe_filter_arg>
     418:      	mov	w8, #0x3                // =3
     41c:      	mov	w9, #0xc                // =12
     420:      	ldr	x1, [x1]
     424:      	mov	x0, x19
     428:      	mov	w2, #0x3                // =3
     42c:      	blr	x9
     430:      	ldr	x19, [x20, #0x60]
     434:      	mov	w8, #0xe                // =14
     438:      	blr	x8
     43c:      	stp	x19, x0, [sp, #0x10]
     440:      	adrp	x19, 0x0 <generic_retkprobe_filter_arg>
     444:      	mov	w8, #0x1                // =1
     448:      	add	x9, sp, #0x10
     44c:      	add	x1, sp, #0x10
     450:      	ldr	x19, [x19]
     454:      	mov	x0, x19
     458:      	blr	x8
     45c:      	cbz	x0, 0x394 <generic_retkprobe_filter_arg+0x394>
     460:      	mov	w8, #0x3                // =3
     464:      	add	x9, sp, #0x10
     468:      	add	x1, sp, #0x10
     46c:      	mov	x0, x19
     470:      	blr	x8
     474:      	b	0x394 <generic_retkprobe_filter_arg+0x394>
     478:      	nop
     47c:      	nop

0000000000000480 <generic_retkprobe_actions>:
     480:      	sub	sp, sp, #0x40
     484:      	str	x30, [sp, #0x10]
     488:      	stp	x22, x21, [sp, #0x20]
     48c:      	stp	x20, x19, [sp, #0x30]
     490:      	mov	x19, x0
     494:      	str	wzr, [sp, #0xc]
     498:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     49c:      	mov	w8, #0x1                // =1
     4a0:      	ldr	x0, [x0]
     4a4:      	add	x9, sp, #0xc
     4a8:      	add	x1, sp, #0xc
     4ac:      	blr	x8
     4b0:      	cbz	x0, 0x5c8 <generic_retkprobe_actions+0x148>
     4b4:      	mov	w8, #0x5f04             // =24324
     4b8:      	ldr	w22, [x0, x8]
     4bc:      	cmp	w22, #0x2
     4c0:      	b.lt	0x5c8 <generic_retkprobe_actions+0x148>
     4c4:      	mov	w8, #0x5ef8             // =24312
     4c8:      	mov	w20, #0x1               // =1
     4cc:      	add	x1, x0, x8
     4d0:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     4d4:      	mov	w8, #0x1                // =1
     4d8:      	ldr	x0, [x0]
     4dc:      	blr	x8
     4e0:      	cbz	x0, 0x5c8 <generic_retkprobe_actions+0x148>
     4e4:      	and	x8, x22, #0x7ff
     4e8:      	mov	x21, x0
     4ec:      	strb	w20, [sp, #0x1c]
     4f0:      	mov	w9, #0x1                // =1
     4f4:      	ldr	w8, [x0, x8]
     4f8:      	str	wzr, [sp, #0x18]
     4fc:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     500:      	add	x1, sp, #0x18
     504:      	ldr	x0, [x0]
     508:      	add	w8, w8, w22
     50c:      	and	w22, w8, #0x7ff
     510:      	add	x8, sp, #0x18
     514:      	blr	x9
     518:      	cbz	x0, 0x528 <generic_retkprobe_actions+0xa8>
     51c:      	ldrb	w8, [x0]
     520:      	cmp	w8, #0x0
     524:      	cset	w20, eq
     528:      	ldr	w8, [x21, x22]
     52c:      	cmp	w8, #0x5
     530:      	b.lo	0x5a4 <generic_retkprobe_actions+0x124>
     534:      	add	x2, x21, x22
     538:      	add	x3, sp, #0x1c
     53c:      	mov	x0, x19
     540:      	mov	w1, wzr
     544:      	mov	w4, w20
     548:      	bl	0x548 <generic_retkprobe_actions+0xc8>
     54c:      	ldr	w9, [x21, x22]
     550:      	lsl	w8, w0, #2
     554:      	add	w8, w8, #0x4
     558:      	cmp	w8, w9
     55c:      	b.hs	0x5a4 <generic_retkprobe_actions+0x124>
     560:      	mov	w1, w0
     564:      	add	x2, x21, x22
     568:      	add	x3, sp, #0x1c
     56c:      	mov	x0, x19
     570:      	mov	w4, w20
     574:      	bl	0x574 <generic_retkprobe_actions+0xf4>
     578:      	ldr	w9, [x21, x22]
     57c:      	lsl	w8, w0, #2
     580:      	add	w8, w8, #0x4
     584:      	cmp	w8, w9
     588:      	b.hs	0x5a4 <generic_retkprobe_actions+0x124>
     58c:      	mov	w1, w0
     590:      	add	x2, x21, x22
     594:      	add	x3, sp, #0x1c
     598:      	mov	x0, x19
     59c:      	mov	w4, w20
     5a0:      	bl	0x5a0 <generic_retkprobe_actions+0x120>
     5a4:      	ldrb	w8, [sp, #0x1c]
     5a8:      	cbz	w8, 0x5c8 <generic_retkprobe_actions+0x148>
     5ac:      	adrp	x1, 0x0 <generic_retkprobe_filter_arg>
     5b0:      	mov	w8, #0x5                // =5
     5b4:      	mov	w9, #0xc                // =12
     5b8:      	ldr	x1, [x1]
     5bc:      	mov	x0, x19
     5c0:      	mov	w2, #0x5                // =5
     5c4:      	blr	x9
     5c8:      	ldp	x20, x19, [sp, #0x30]
     5cc:      	mov	w0, wzr
     5d0:      	ldr	x30, [sp, #0x10]
     5d4:      	ldp	x22, x21, [sp, #0x20]
     5d8:      	add	sp, sp, #0x40
     5dc:      	ret

00000000000005e0 <generic_retkprobe_output>:
     5e0:      	sub	sp, sp, #0x30
     5e4:      	stp	x30, x21, [sp, #0x10]
     5e8:      	stp	x20, x19, [sp, #0x20]
     5ec:      	mov	x20, x0
     5f0:      	str	wzr, [sp, #0x4]
     5f4:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     5f8:      	mov	w8, #0x1                // =1
     5fc:      	ldr	x0, [x0]
     600:      	add	x9, sp, #0x4
     604:      	add	x1, sp, #0x4
     608:      	blr	x8
     60c:      	cbz	x0, 0x870 <generic_retkprobe_output+0x290>
     610:      	ldr	w8, [x0, #0x4]
     614:      	mov	x19, x0
     618:      	mov	w9, #0x2328             // =9000
     61c:      	str	wzr, [sp, #0x8]
     620:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     624:      	add	x1, sp, #0x8
     628:      	ldr	x0, [x0]
     62c:      	add	w8, w8, #0x90
     630:      	and	w8, w8, #0x7fff
     634:      	cmp	w8, w9
     638:      	csel	w21, w8, w9, lo
     63c:      	mov	w8, #0x1                // =1
     640:      	add	x9, sp, #0x8
     644:      	blr	x8
     648:      	cbz	x0, 0x6b4 <generic_retkprobe_output+0xd4>
     64c:      	ldrb	w8, [x0, #0x28]
     650:      	cbz	w8, 0x6b4 <generic_retkprobe_output+0xd4>
     654:      	adrp	x1, 0x0 <generic_retkprobe_filter_arg>
     658:      	mov	w8, #-0x1               // =-1
     65c:      	mov	w9, #0x19               // =25
     660:      	ldr	x1, [x1]
     664:      	mov	x0, x20
     668:      	mov	w2, #-0x1               // =-1
     66c:      	mov	x3, x19
     670:      	mov	x4, x21
     674:      	blr	x9
     678:      	tbnz	x0, #0x3f, 0x764 <generic_retkprobe_output+0x184>
     67c:      	str	wzr, [sp, #0xc]
     680:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     684:      	mov	w8, #0x1                // =1
     688:      	add	x9, sp, #0xc
     68c:      	ldr	x0, [x0]
     690:      	add	x1, sp, #0xc
     694:      	blr	x8
     698:      	cbz	x0, 0x870 <generic_retkprobe_output+0x290>
     69c:      	add	x8, x0, #0x8
     6a0:      	ldaxr	x9, [x8]
     6a4:      	add	x9, x9, #0x1
     6a8:      	stlxr	w10, x9, [x8]
     6ac:      	cbnz	w10, 0x6a0 <generic_retkprobe_output+0xc0>
     6b0:      	b	0x870 <generic_retkprobe_output+0x290>
     6b4:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     6b8:      	mov	x3, xzr
     6bc:      	mov	w8, #0x82               // =130
     6c0:      	ldr	x0, [x0]
     6c4:      	mov	x1, x19
     6c8:      	mov	x2, x21
     6cc:      	blr	x8
     6d0:      	tbnz	x0, #0x3f, 0x714 <generic_retkprobe_output+0x134>
     6d4:      	str	wzr, [sp, #0xc]
     6d8:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     6dc:      	mov	w8, #0x1                // =1
     6e0:      	add	x9, sp, #0xc
     6e4:      	ldr	x0, [x0]
     6e8:      	add	x1, sp, #0xc
     6ec:      	blr	x8
     6f0:      	cbz	x0, 0x870 <generic_retkprobe_output+0x290>
     6f4:      	add	x8, x0, #0x8
     6f8:      	nop
     6fc:      	nop
     700:      	ldaxr	x9, [x8]
     704:      	add	x9, x9, #0x1
     708:      	stlxr	w10, x9, [x8]
     70c:      	cbnz	w10, 0x700 <generic_retkprobe_output+0x120>
     710:      	b	0x870 <generic_retkprobe_output+0x290>
     714:      	mov	x19, x0
     718:      	str	wzr, [sp, #0xc]
     71c:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     720:      	mov	w8, #0x1                // =1
     724:      	ldr	x0, [x0]
     728:      	add	x9, sp, #0xc
     72c:      	add	x1, sp, #0xc
     730:      	blr	x8
     734:      	cbz	x0, 0x870 <generic_retkprobe_output+0x290>
     738:      	mov	x8, x19
     73c:      	cmn	x19, #0xc
     740:      	b.gt	0x7b4 <generic_retkprobe_output+0x1d4>
     744:      	cmn	x8, #0x1c
     748:      	b.eq	0x7f4 <generic_retkprobe_output+0x214>
     74c:      	cmn	x8, #0x16
     750:      	b.eq	0x80c <generic_retkprobe_output+0x22c>
     754:      	cmn	x8, #0x10
     758:      	b.ne	0x804 <generic_retkprobe_output+0x224>
     75c:      	add	x8, x0, #0x2f0
     760:      	b	0x820 <generic_retkprobe_output+0x240>
     764:      	mov	x19, x0
     768:      	str	wzr, [sp, #0xc]
     76c:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     770:      	mov	w8, #0x1                // =1
     774:      	ldr	x0, [x0]
     778:      	add	x9, sp, #0xc
     77c:      	add	x1, sp, #0xc
     780:      	blr	x8
     784:      	cbz	x0, 0x870 <generic_retkprobe_output+0x290>
     788:      	mov	x8, x19
     78c:      	cmn	x19, #0xc
     790:      	b.gt	0x7d4 <generic_retkprobe_output+0x1f4>
     794:      	cmn	x8, #0x1c
     798:      	b.eq	0x834 <generic_retkprobe_output+0x254>
     79c:      	cmn	x8, #0x16
     7a0:      	b.eq	0x84c <generic_retkprobe_output+0x26c>
     7a4:      	cmn	x8, #0x10
     7a8:      	b.ne	0x844 <generic_retkprobe_output+0x264>
     7ac:      	add	x8, x0, #0x2f0
     7b0:      	b	0x860 <generic_retkprobe_output+0x280>
     7b4:      	cmn	x8, #0xb
     7b8:      	b.eq	0x7fc <generic_retkprobe_output+0x21c>
     7bc:      	cmn	x8, #0x7
     7c0:      	b.eq	0x814 <generic_retkprobe_output+0x234>
     7c4:      	cmn	x8, #0x2
     7c8:      	b.ne	0x804 <generic_retkprobe_output+0x224>
     7cc:      	add	x8, x0, #0x2e0
     7d0:      	b	0x820 <generic_retkprobe_output+0x240>
     7d4:      	cmn	x8, #0xb
     7d8:      	b.eq	0x83c <generic_retkprobe_output+0x25c>
     7dc:      	cmn	x8, #0x7
     7e0:      	b.eq	0x854 <generic_retkprobe_output+0x274>
     7e4:      	cmn	x8, #0x2
     7e8:      	b.ne	0x844 <generic_retkprobe_output+0x264>
     7ec:      	add	x8, x0, #0x2e0
     7f0:      	b	0x860 <generic_retkprobe_output+0x280>
     7f4:      	add	x8, x0, #0x300
     7f8:      	b	0x820 <generic_retkprobe_output+0x240>
     7fc:      	add	x8, x0, #0x308
     800:      	b	0x820 <generic_retkprobe_output+0x240>
     804:      	add	x8, x0, #0x2d8
     808:      	b	0x820 <generic_retkprobe_output+0x240>
     80c:      	add	x8, x0, #0x2f8
     810:      	b	0x820 <generic_retkprobe_output+0x240>
     814:      	add	x8, x0, #0x2e8
     818:      	nop
     81c:      	nop
     820:      	ldaxr	x9, [x8]
     824:      	add	x9, x9, #0x1
     828:      	stlxr	w10, x9, [x8]
     82c:      	cbnz	w10, 0x820 <generic_retkprobe_output+0x240>
     830:      	b	0x870 <generic_retkprobe_output+0x290>
     834:      	add	x8, x0, #0x300
     838:      	b	0x860 <generic_retkprobe_output+0x280>
     83c:      	add	x8, x0, #0x308
     840:      	b	0x860 <generic_retkprobe_output+0x280>
     844:      	add	x8, x0, #0x2d8
     848:      	b	0x860 <generic_retkprobe_output+0x280>
     84c:      	add	x8, x0, #0x2f8
     850:      	b	0x860 <generic_retkprobe_output+0x280>
     854:      	add	x8, x0, #0x2e8
     858:      	nop
     85c:      	nop
     860:      	ldaxr	x9, [x8]
     864:      	add	x9, x9, #0x1
     868:      	stlxr	w10, x9, [x8]
     86c:      	cbnz	w10, 0x860 <generic_retkprobe_output+0x280>
     870:      	ldp	x20, x19, [sp, #0x20]
     874:      	mov	w0, wzr
     878:      	ldp	x30, x21, [sp, #0x10]
     87c:      	add	sp, sp, #0x30
     880:      	ret

Disassembly of section kprobe/generic_retkprobe:

0000000000000000 <generic_retkprobe_event>:
       0:      	sub	sp, sp, #0x160
       4:      	str	x29, [sp, #0x110]
       8:      	stp	x30, x25, [sp, #0x120]
       c:      	stp	x24, x23, [sp, #0x130]
      10:      	stp	x22, x21, [sp, #0x140]
      14:      	stp	x20, x19, [sp, #0x150]
      18:      	ldr	x8, [x0]
      1c:      	str	wzr, [sp, #0x6c]
      20:      	adrp	x24, 0x0 <generic_retkprobe_event>
      24:      	add	x9, sp, #0x6c
      28:      	mov	x19, x0
      2c:      	add	x1, sp, #0x6c
      30:      	str	x8, [sp, #0x70]
      34:      	mov	w8, #0x1                // =1
      38:      	ldr	x24, [x24]
      3c:      	mov	x0, x24
      40:      	blr	x8
      44:      	cbz	x0, 0x5a4 <generic_retkprobe_event+0x5a4>
      48:      	mov	w8, #0x5ea0             // =24224
      4c:      	mov	x20, x0
      50:      	add	x25, x0, x8
      54:      	adrp	x0, 0x0 <generic_retkprobe_event>
      58:      	mov	w8, #0x1                // =1
      5c:      	mov	x1, x25
      60:      	str	wzr, [x1, #0x58]!
      64:      	ldr	x0, [x0]
      68:      	blr	x8
      6c:      	cbz	x0, 0x5a4 <generic_retkprobe_event+0x5a4>
      70:      	ldr	w8, [x0]
      74:      	mov	x29, x0
      78:      	str	x8, [x20, #0x60]
      7c:      	mov	w8, #0xe                // =14
      80:      	blr	x8
      84:      	cmn	x0, #0x16
      88:      	b.ne	0xac <generic_retkprobe_event+0xac>
      8c:      	add	x2, x19, #0xe8
      90:      	mov	w8, #0x8                // =8
      94:      	mov	w9, #0x4                // =4
      98:      	add	x10, sp, #0xa8
      9c:      	add	x0, sp, #0xa8
      a0:      	mov	w1, #0x8                // =8
      a4:      	blr	x9
      a8:      	ldr	x0, [sp, #0xa8]
      ac:      	str	x0, [x20, #0x68]
      b0:      	mov	w8, #0xe                // =14
      b4:      	blr	x8
      b8:      	ldp	x8, x9, [x20, #0x60]
      bc:      	adrp	x22, 0x0 <generic_retkprobe_event>
      c0:      	add	x1, sp, #0xa8
      c4:      	str	w0, [x20, #0x7c]
      c8:      	stp	x8, x9, [sp, #0xa8]
      cc:      	mov	w8, #0x1                // =1
      d0:      	add	x9, sp, #0xa8
      d4:      	ldr	x22, [x22]
      d8:      	mov	x0, x22
      dc:      	blr	x8
      e0:      	cbz	x0, 0x5a4 <generic_retkprobe_event+0x5a4>
      e4:      	ldp	x21, x8, [x0]
      e8:      	add	x9, sp, #0xa8
      ec:      	add	x1, sp, #0xa8
      f0:      	str	x8, [sp, #0x118]
      f4:      	ldr	x8, [x0, #0x10]
      f8:      	mov	x0, x22
      fc:      	str	x8, [sp, #0x60]
     100:      	mov	w8, #0x3                // =3
     104:      	blr	x8
     108:      	mov	x22, x20
     10c:      	str	x21, [x22, #0x90]!
     110:      	ldp	w8, w23, [x29, #0x58]
     114:      	cbz	w23, 0x208 <generic_retkprobe_event+0x208>
     118:      	str	w8, [sp, #0x58]
     11c:      	str	wzr, [x25]
     120:      	mov	w8, #0x1                // =1
     124:      	add	x9, sp, #0x7c
     128:      	add	x1, sp, #0x7c
     12c:      	mov	x0, x24
     130:      	str	wzr, [sp, #0x7c]
     134:      	ldr	x25, [sp, #0x70]
     138:      	blr	x8
     13c:      	cbz	x0, 0x274 <generic_retkprobe_event+0x274>
     140:      	mov	w21, #0x5ea0            // =24224
     144:      	mov	w9, #0xc                // =12
     148:      	ldr	w8, [x0, x21]
     14c:      	str	x9, [x0, #0x5e78]
     150:      	str	w8, [x0, #0x98]
     154:      	cbz	w8, 0x2c4 <generic_retkprobe_event+0x2c4>
     158:      	mov	w8, #0x4                // =4
     15c:      	add	x21, x8, #0x8
     160:      	ldr	w8, [x29, #0x60]
     164:      	cmp	w8, #0xb
     168:      	b.eq	0x288 <generic_retkprobe_event+0x288>
     16c:      	cmp	w8, #0xa
     170:      	b.ne	0x1ac <generic_retkprobe_event+0x1ac>
     174:      	ldr	w8, [x20, #0x10]
     178:      	ldr	w9, [x20, #0x7c]
     17c:      	adrp	x0, 0x0 <generic_retkprobe_event>
     180:      	mov	x3, xzr
     184:      	add	x10, sp, #0xa8
     188:      	add	x1, sp, #0x70
     18c:      	stp	w8, w9, [sp, #0xa8]
     190:      	ldr	x8, [x20, #0x18]
     194:      	add	x9, sp, #0x70
     198:      	add	x2, sp, #0xa8
     19c:      	str	x8, [sp, #0xb0]
     1a0:      	mov	w8, #0x2                // =2
     1a4:      	ldr	x0, [x0]
     1a8:      	blr	x8
     1ac:      	ldr	w8, [sp, #0x58]
     1b0:      	and	x24, x21, #0x1fff
     1b4:      	cmp	w8, #0x3
     1b8:      	b.eq	0x214 <generic_retkprobe_event+0x214>
     1bc:      	cmp	w8, #0x2
     1c0:      	b.ne	0x33c <generic_retkprobe_event+0x33c>
     1c4:      	str	wzr, [x22, x24]
     1c8:      	add	x21, x24, #0x4
     1cc:      	mov	w8, #0xfff              // =4095
     1d0:      	ldr	x2, [sp, #0x118]
     1d4:      	mov	w25, #0x4               // =4
     1d8:      	add	x23, x22, x21
     1dc:      	ldr	x24, [sp, #0x70]
     1e0:      	add	x0, x23, #0x8
     1e4:      	cmp	x24, #0xfff
     1e8:      	csel	x22, x24, x8, lo
     1ec:      	mov	w8, #0x4                // =4
     1f0:      	mov	w1, w22
     1f4:      	blr	x8
     1f8:      	tbnz	w0, #0x1f, 0x2b4 <generic_retkprobe_event+0x2b4>
     1fc:      	add	x25, x22, #0x8
     200:      	str	w22, [x23, #0x4]
     204:      	b	0x2b8 <generic_retkprobe_event+0x2b8>
     208:      	mov	w24, #0x8               // =8
     20c:      	cmp	w8, #0x3
     210:      	b.ne	0x1bc <generic_retkprobe_event+0x1bc>
     214:      	ldr	x8, [sp, #0x60]
     218:      	add	x25, x24, #0x4
     21c:      	str	wzr, [x22, x24]
     220:      	cbz	x8, 0x30c <generic_retkprobe_event+0x30c>
     224:      	ldr	x2, [sp, #0x118]
     228:      	ldr	x21, [sp, #0x70]
     22c:      	mov	w8, #0x10               // =16
     230:      	mov	w9, #0x4                // =4
     234:      	add	x10, sp, #0xa8
     238:      	add	x0, sp, #0xa8
     23c:      	mov	w1, #0x10               // =16
     240:      	blr	x9
     244:      	tbnz	w0, #0x1f, 0x32c <generic_retkprobe_event+0x32c>
     248:      	ldr	x8, [sp, #0xb0]
     24c:      	str	x29, [sp, #0x48]
     250:      	cmp	x8, x21
     254:      	csel	x23, x8, x21, lo
     258:      	cmp	x21, #0x0
     25c:      	csel	x29, x8, x23, eq
     260:      	cmp	x29, #0xffe
     264:      	b.ls	0x5d8 <generic_retkprobe_event+0x5d8>
     268:      	ldr	x29, [sp, #0x48]
     26c:      	mov	w8, #-0x3               // =-3
     270:      	b	0x330 <generic_retkprobe_event+0x330>
     274:      	mov	x8, xzr
     278:      	add	x21, x8, #0x8
     27c:      	ldr	w8, [x29, #0x60]
     280:      	cmp	w8, #0xb
     284:      	b.ne	0x16c <generic_retkprobe_event+0x16c>
     288:      	adrp	x0, 0x0 <generic_retkprobe_event>
     28c:      	mov	w8, #0x3                // =3
     290:      	add	x9, sp, #0x70
     294:      	ldr	x0, [x0]
     298:      	add	x1, sp, #0x70
     29c:      	blr	x8
     2a0:      	ldr	w8, [sp, #0x58]
     2a4:      	and	x24, x21, #0x1fff
     2a8:      	cmp	w8, #0x3
     2ac:      	b.ne	0x1bc <generic_retkprobe_event+0x1bc>
     2b0:      	b	0x214 <generic_retkprobe_event+0x214>
     2b4:      	mov	w24, #-0x2              // =-2
     2b8:      	str	w24, [x23]
     2bc:      	add	x24, x25, x21
     2c0:      	b	0x33c <generic_retkprobe_event+0x33c>
     2c4:      	stp	x29, x19, [sp, #0x48]
     2c8:      	add	x9, sp, #0xf0
     2cc:      	add	x8, x0, #0x9c
     2d0:      	add	x19, sp, #0xf0
     2d4:      	cmp	w23, #0x17
     2d8:      	stp	x8, x0, [sp, #0x28]
     2dc:      	str	x25, [sp, #0xa8]
     2e0:      	str	xzr, [x9, #0x8]
     2e4:      	b.le	0x5c0 <generic_retkprobe_event+0x5c0>
     2e8:      	cmp	w23, #0x18
     2ec:      	b.eq	0x670 <generic_retkprobe_event+0x670>
     2f0:      	cmp	w23, #0x25
     2f4:      	b.eq	0x6b8 <generic_retkprobe_event+0x6b8>
     2f8:      	cmp	w23, #0x2a
     2fc:      	b.ne	0xc3c <generic_retkprobe_event+0xc3c>
     300:      	add	x8, sp, #0x80
     304:      	stp	xzr, x25, [sp, #0x80]
     308:      	b	0x6e4 <generic_retkprobe_event+0x6e4>
     30c:      	mov	x24, x22
     310:      	str	x29, [sp, #0x48]
     314:      	mov	x29, xzr
     318:      	add	x8, x24, x25
     31c:      	stp	w29, w29, [x8]
     320:      	add	x8, x29, #0x8
     324:      	ldr	x29, [sp, #0x48]
     328:      	b	0x338 <generic_retkprobe_event+0x338>
     32c:      	mov	w8, #-0x2               // =-2
     330:      	str	w8, [x22, x25]
     334:      	mov	w8, #0x4                // =4
     338:      	add	x24, x8, x25
     33c:      	mov	w8, #0x23               // =35
     340:      	blr	x8
     344:      	str	x0, [sp, #0xa8]
     348:      	add	x8, x0, #0x8d4
     34c:      	mov	w9, #0x4                // =4
     350:      	mov	w10, #0x71              // =113
     354:      	add	x11, sp, #0x80
     358:      	add	x0, sp, #0x80
     35c:      	mov	w1, #0x4                // =4
     360:      	ldr	x8, [sp, #0xa8]
     364:      	add	x2, x8, #0x8d4
     368:      	blr	x10
     36c:      	ldr	w8, [sp, #0x80]
     370:      	adrp	x22, 0x0 <generic_retkprobe_event>
     374:      	add	x9, sp, #0xf8
     378:      	add	x1, sp, #0xf8
     37c:      	str	w8, [sp, #0xf8]
     380:      	mov	w8, #0x1                // =1
     384:      	ldr	x22, [x22]
     388:      	mov	x0, x22
     38c:      	blr	x8
     390:      	cbz	x0, 0x3a0 <generic_retkprobe_event+0x3a0>
     394:      	ldr	x8, [x0, #0x8]
     398:      	mov	x23, x0
     39c:      	cbnz	x8, 0x54c <generic_retkprobe_event+0x54c>
     3a0:      	ldr	x8, [sp, #0xa8]
     3a4:      	mov	w9, #0x8                // =8
     3a8:      	mov	w10, #0x71              // =113
     3ac:      	add	x11, sp, #0xa8
     3b0:      	add	x0, sp, #0xa8
     3b4:      	mov	w1, #0x8                // =8
     3b8:      	add	x8, x8, #0x8e0
     3bc:      	ldr	x8, [sp, #0xa8]
     3c0:      	add	x2, x8, #0x8e0
     3c4:      	blr	x10
     3c8:      	ldr	x8, [sp, #0xa8]
     3cc:      	cbz	x8, 0x548 <generic_retkprobe_event+0x548>
     3d0:      	add	x8, x8, #0x8d4
     3d4:      	mov	w9, #0x4                // =4
     3d8:      	mov	w10, #0x71              // =113
     3dc:      	add	x11, sp, #0x80
     3e0:      	ldr	x8, [sp, #0xa8]
     3e4:      	add	x0, sp, #0x80
     3e8:      	mov	w1, #0x4                // =4
     3ec:      	add	x2, x8, #0x8d4
     3f0:      	blr	x10
     3f4:      	ldr	w8, [sp, #0x80]
     3f8:      	add	x9, sp, #0xf8
     3fc:      	add	x1, sp, #0xf8
     400:      	mov	x0, x22
     404:      	str	w8, [sp, #0xf8]
     408:      	mov	w8, #0x1                // =1
     40c:      	blr	x8
     410:      	cbz	x0, 0x420 <generic_retkprobe_event+0x420>
     414:      	ldr	x8, [x0, #0x8]
     418:      	mov	x23, x0
     41c:      	cbnz	x8, 0x54c <generic_retkprobe_event+0x54c>
     420:      	ldr	x8, [sp, #0xa8]
     424:      	mov	w9, #0x8                // =8
     428:      	mov	w10, #0x71              // =113
     42c:      	add	x11, sp, #0xa8
     430:      	add	x0, sp, #0xa8
     434:      	mov	w1, #0x8                // =8
     438:      	add	x8, x8, #0x8e0
     43c:      	ldr	x8, [sp, #0xa8]
     440:      	add	x2, x8, #0x8e0
     444:      	blr	x10
     448:      	ldr	x8, [sp, #0xa8]
     44c:      	cbz	x8, 0x548 <generic_retkprobe_event+0x548>
     450:      	add	x8, x8, #0x8d4
     454:      	mov	w9, #0x4                // =4
     458:      	mov	w10, #0x71              // =113
     45c:      	add	x11, sp, #0x80
     460:      	ldr	x8, [sp, #0xa8]
     464:      	add	x0, sp, #0x80
     468:      	mov	w1, #0x4                // =4
     46c:      	add	x2, x8, #0x8d4
     470:      	blr	x10
     474:      	ldr	w8, [sp, #0x80]
     478:      	add	x9, sp, #0xf8
     47c:      	add	x1, sp, #0xf8
     480:      	mov	x0, x22
     484:      	str	w8, [sp, #0xf8]
     488:      	mov	w8, #0x1                // =1
     48c:      	blr	x8
     490:      	cbz	x0, 0x4a0 <generic_retkprobe_event+0x4a0>
     494:      	ldr	x8, [x0, #0x8]
     498:      	mov	x23, x0
     49c:      	cbnz	x8, 0x54c <generic_retkprobe_event+0x54c>
     4a0:      	ldr	x8, [sp, #0xa8]
     4a4:      	mov	w9, #0x8                // =8
     4a8:      	mov	w10, #0x71              // =113
     4ac:      	add	x11, sp, #0xa8
     4b0:      	add	x0, sp, #0xa8
     4b4:      	mov	w1, #0x8                // =8
     4b8:      	add	x8, x8, #0x8e0
     4bc:      	ldr	x8, [sp, #0xa8]
     4c0:      	add	x2, x8, #0x8e0
     4c4:      	blr	x10
     4c8:      	ldr	x8, [sp, #0xa8]
     4cc:      	cbz	x8, 0x548 <generic_retkprobe_event+0x548>
     4d0:      	add	x8, x8, #0x8d4
     4d4:      	mov	w9, #0x4                // =4
     4d8:      	mov	w10, #0x71              // =113
     4dc:      	add	x11, sp, #0x80
     4e0:      	ldr	x8, [sp, #0xa8]
     4e4:      	add	x0, sp, #0x80
     4e8:      	mov	w1, #0x4                // =4
     4ec:      	add	x2, x8, #0x8d4
     4f0:      	blr	x10
     4f4:      	ldr	w8, [sp, #0x80]
     4f8:      	add	x9, sp, #0xf8
     4fc:      	add	x1, sp, #0xf8
     500:      	mov	x0, x22
     504:      	str	w8, [sp, #0xf8]
     508:      	mov	w8, #0x1                // =1
     50c:      	blr	x8
     510:      	cbz	x0, 0x520 <generic_retkprobe_event+0x520>
     514:      	ldr	x8, [x0, #0x8]
     518:      	mov	x23, x0
     51c:      	cbnz	x8, 0x54c <generic_retkprobe_event+0x54c>
     520:      	ldr	x8, [sp, #0xa8]
     524:      	mov	w9, #0x8                // =8
     528:      	mov	w10, #0x71              // =113
     52c:      	add	x11, sp, #0xa8
     530:      	add	x0, sp, #0xa8
     534:      	mov	w1, #0x8                // =8
     538:      	add	x8, x8, #0x8e0
     53c:      	ldr	x8, [sp, #0xa8]
     540:      	add	x2, x8, #0x8e0
     544:      	blr	x10
     548:      	mov	x23, xzr
     54c:      	mov	w8, #0x10d              // =269
     550:      	stp	w8, w24, [x20]
     554:      	mov	w8, #0x7d               // =125
     558:      	blr	x8
     55c:      	str	x0, [x20, #0x8]
     560:      	cbz	x23, 0x574 <generic_retkprobe_event+0x574>
     564:      	ldr	w8, [x23]
     568:      	str	w8, [x20, #0x10]
     56c:      	ldr	x8, [x23, #0x8]
     570:      	str	x8, [x20, #0x18]
     574:      	str	wzr, [x20, #0x14]
     578:      	adrp	x1, 0x0 <generic_retkprobe_event>
     57c:      	mov	w9, #0xc                // =12
     580:      	mov	x0, x19
     584:      	ldr	w8, [x29]
     588:      	str	w24, [x20, #0x4]
     58c:      	mov	w2, #0x3                // =3
     590:      	str	x8, [x20, #0x60]
     594:      	mov	w8, #0x3                // =3
     598:      	ldr	x1, [x1]
     59c:      	blr	x9
     5a0:      	mov	w0, #0x1                // =1
     5a4:      	ldp	x20, x19, [sp, #0x150]
     5a8:      	ldr	x29, [sp, #0x110]
     5ac:      	ldp	x22, x21, [sp, #0x140]
     5b0:      	ldp	x24, x23, [sp, #0x130]
     5b4:      	ldp	x30, x25, [sp, #0x120]
     5b8:      	add	sp, sp, #0x160
     5bc:      	ret
     5c0:      	cmp	w23, #0xf
     5c4:      	b.eq	0xbac <generic_retkprobe_event+0xbac>
     5c8:      	cmp	w23, #0x10
     5cc:      	b.ne	0xc3c <generic_retkprobe_event+0xc3c>
     5d0:      	add	x21, sp, #0x108
     5d4:      	b	0x698 <generic_retkprobe_event+0x698>
     5d8:      	mov	x8, x22
     5dc:      	add	x22, x24, #0xc
     5e0:      	mov	w9, #0x4                // =4
     5e4:      	mov	w1, w29
     5e8:      	mov	x24, x8
     5ec:      	add	x0, x8, x22
     5f0:      	ldr	x8, [sp, #0xa8]
     5f4:      	ldr	x2, [sp, #0xa8]
     5f8:      	blr	x9
     5fc:      	tbnz	w0, #0x1f, 0x660 <generic_retkprobe_event+0x660>
     600:      	cbz	x21, 0x60c <generic_retkprobe_event+0x60c>
     604:      	subs	x21, x21, x23
     608:      	b.eq	0xf24 <generic_retkprobe_event+0xf24>
     60c:      	ldr	x8, [sp, #0x60]
     610:      	cmp	x8, #0x1
     614:      	b.eq	0x318 <generic_retkprobe_event+0x318>
     618:      	ldr	x8, [sp, #0x118]
     61c:      	mov	w9, #0x4                // =4
     620:      	add	x10, sp, #0xa8
     624:      	add	x0, sp, #0xa8
     628:      	mov	w1, #0x10               // =16
     62c:      	add	x2, x8, #0x10
     630:      	mov	w8, #0x10               // =16
     634:      	blr	x9
     638:      	tbnz	w0, #0x1f, 0x1094 <generic_retkprobe_event+0x1094>
     63c:      	ldr	x8, [sp, #0xb0]
     640:      	cmp	x8, x21
     644:      	csel	x23, x8, x21, lo
     648:      	cmp	x21, #0x0
     64c:      	csel	x10, x8, x23, eq
     650:      	cmp	x10, #0xffe
     654:      	b.ls	0x1000 <generic_retkprobe_event+0x1000>
     658:      	mov	w8, #-0x3               // =-3
     65c:      	b	0x1098 <generic_retkprobe_event+0x1098>
     660:      	ldr	x29, [sp, #0x48]
     664:      	mov	w8, #-0x2               // =-2
     668:      	mov	x22, x24
     66c:      	b	0x330 <generic_retkprobe_event+0x330>
     670:      	add	x21, sp, #0x108
     674:      	mov	w8, #0x8                // =8
     678:      	mov	w9, #0x4                // =4
     67c:      	ldr	x2, [sp, #0xa8]
     680:      	add	x0, sp, #0x108
     684:      	mov	w1, #0x8                // =8
     688:      	blr	x9
     68c:      	add	x19, sp, #0xf0
     690:      	ldr	x8, [x19, #0x18]
     694:      	str	x8, [sp, #0xa8]
     698:      	mov	w8, #0x8                // =8
     69c:      	mov	w9, #0x4                // =4
     6a0:      	add	x10, sp, #0xa8
     6a4:      	add	x0, sp, #0x108
     6a8:      	add	x2, sp, #0xa8
     6ac:      	mov	w1, #0x8                // =8
     6b0:      	blr	x9
     6b4:      	b	0x6dc <generic_retkprobe_event+0x6dc>
     6b8:      	add	x8, x25, #0x40
     6bc:      	mov	w9, #0x8                // =8
     6c0:      	mov	w10, #0x4               // =4
     6c4:      	str	x8, [sp, #0xa8]
     6c8:      	add	x11, sp, #0x108
     6cc:      	add	x0, sp, #0x108
     6d0:      	mov	w1, #0x8                // =8
     6d4:      	ldr	x2, [sp, #0xa8]
     6d8:      	blr	x10
     6dc:      	ldr	x8, [x19, #0x18]
     6e0:      	add	x8, x8, #0x40
     6e4:      	str	x8, [sp, #0x38]
     6e8:      	str	wzr, [sp, #0x94]
     6ec:      	adrp	x0, 0x0 <generic_retkprobe_event>
     6f0:      	mov	w8, #0x1                // =1
     6f4:      	add	x9, sp, #0x94
     6f8:      	ldr	x0, [x0]
     6fc:      	add	x1, sp, #0x94
     700:      	blr	x8
     704:      	ldr	x19, [sp, #0x50]
     708:      	cbz	x0, 0xdf4 <generic_retkprobe_event+0xdf4>
     70c:      	add	x8, x0, #0x1, lsl #12   // =0x1000
     710:      	str	x22, [sp, #0x18]
     714:      	mov	x23, x0
     718:      	str	x8, [sp, #0x40]
     71c:      	mov	w8, #0x23               // =35
     720:      	blr	x8
     724:      	add	x2, x0, #0xb30
     728:      	mov	w24, #0x8               // =8
     72c:      	add	x8, sp, #0x98
     730:      	mov	w9, #0x4                // =4
     734:      	add	x0, sp, #0x98
     738:      	mov	w1, #0x8                // =8
     73c:      	mov	w25, #0x4               // =4
     740:      	blr	x9
     744:      	ldr	x29, [sp, #0x98]
     748:      	mov	w9, #0x4                // =4
     74c:      	add	x0, sp, #0xa0
     750:      	mov	w1, #0x8                // =8
     754:      	add	x8, x29, #0x18
     758:      	str	x8, [sp, #0x10]
     75c:      	ldr	x8, [sp, #0x38]
     760:      	add	x2, x8, #0x8
     764:      	add	x8, sp, #0xa0
     768:      	str	x2, [sp, #0x20]
     76c:      	blr	x9
     770:      	ldr	x21, [sp, #0xa0]
     774:      	add	x22, sp, #0xa8
     778:      	add	x0, sp, #0xa8
     77c:      	mov	w1, #0x8                // =8
     780:      	add	x2, x21, #0x10
     784:      	blr	x25
     788:      	ldr	x8, [sp, #0xa8]
     78c:      	cbz	x8, 0x79c <generic_retkprobe_event+0x79c>
     790:      	ldr	x9, [sp, #0x40]
     794:      	mov	w8, #0x1000             // =4096
     798:      	b	0x7e4 <generic_retkprobe_event+0x7e4>
     79c:      	add	x2, x21, #0x18
     7a0:      	mov	w8, #0x8                // =8
     7a4:      	mov	w9, #0x4                // =4
     7a8:      	add	x10, sp, #0xa8
     7ac:      	add	x0, sp, #0xa8
     7b0:      	mov	w1, #0x8                // =8
     7b4:      	blr	x9
     7b8:      	ldr	x8, [sp, #0xa8]
     7bc:      	cmp	x8, x21
     7c0:      	b.eq	0x790 <generic_retkprobe_event+0x790>
     7c4:      	mov	w8, #0x2964             // =10596
     7c8:      	add	x9, x23, #0xff6
     7cc:      	strh	w8, [x23, #0xffe]
     7d0:      	adrp	x8, 0x0 <generic_retkprobe_event>
     7d4:      	add	x8, x8, #0x0
     7d8:      	ldr	x8, [x8]
     7dc:      	str	x8, [x9]
     7e0:      	mov	w8, #0xff6              // =4086
     7e4:      	stp	xzr, xzr, [sp, #0xa8]
     7e8:      	add	x2, x29, #0x20
     7ec:      	mov	w21, #0x8               // =8
     7f0:      	add	x0, sp, #0xa8
     7f4:      	mov	w1, #0x8                // =8
     7f8:      	add	x25, x22, #0x8
     7fc:      	stp	x23, xzr, [sp, #0xb8]
     800:      	add	x24, x22, #0x18
     804:      	add	x23, x22, #0x20
     808:      	stp	xzr, xzr, [sp, #0xc8]
     80c:      	mov	w29, #0x4               // =4
     810:      	str	x9, [sp, #0x40]
     814:      	str	x9, [sp, #0xd8]
     818:      	str	w8, [sp, #0xe0]
     81c:      	mov	w8, #0x4                // =4
     820:      	strb	wzr, [sp, #0xe4]
     824:      	blr	x8
     828:      	ldr	x2, [sp, #0x10]
     82c:      	mov	w8, #0x4                // =4
     830:      	mov	x0, x25
     834:      	mov	w1, #0x8                // =8
     838:      	blr	x8
     83c:      	ldr	x2, [sp, #0x20]
     840:      	mov	w8, #0x4                // =4
     844:      	mov	x0, x24
     848:      	mov	w1, #0x8                // =8
     84c:      	blr	x8
     850:      	ldr	x2, [sp, #0x38]
     854:      	mov	x0, x23
     858:      	mov	w1, #0x8                // =8
     85c:      	blr	x29
     860:      	ldr	x8, [sp, #0xc8]
     864:      	sub	x8, x8, #0x20
     868:      	str	x8, [sp, #0xd0]
     86c:      	adrp	x8, 0x0 <generic_retkprobe_event>
     870:      	ldr	x8, [x8]
     874:      	ldrb	w8, [x8]
     878:      	cbz	w8, 0xa14 <generic_retkprobe_event+0xa14>
     87c:      	mov	w23, #0x800             // =2048
     880:      	mov	w25, #0x8               // =8
     884:      	ldp	x29, x2, [sp, #0xc0]
     888:      	ldp	x8, x9, [sp, #0xa8]
     88c:      	cmp	x29, x8
     890:      	ccmp	x2, x9, #0x0, eq
     894:      	b.eq	0xcd8 <generic_retkprobe_event+0xcd8>
     898:      	ldr	x21, [sp, #0xd0]
     89c:      	mov	w8, #0x4                // =4
     8a0:      	add	x9, sp, #0xe8
     8a4:      	add	x0, sp, #0xe8
     8a8:      	mov	w1, #0x8                // =8
     8ac:      	blr	x8
     8b0:      	ldr	x8, [sp, #0xe8]
     8b4:      	add	x19, sp, #0xf0
     8b8:      	cmp	x29, x8
     8bc:      	b.eq	0x9b8 <generic_retkprobe_event+0x9b8>
     8c0:      	add	x22, x29, #0x18
     8c4:      	mov	w8, #0x4                // =4
     8c8:      	add	x9, sp, #0x108
     8cc:      	add	x0, sp, #0x108
     8d0:      	mov	w1, #0x8                // =8
     8d4:      	mov	x2, x22
     8d8:      	blr	x8
     8dc:      	ldr	x8, [x19, #0x18]
     8e0:      	cmp	x8, x29
     8e4:      	b.eq	0x9b8 <generic_retkprobe_event+0x9b8>
     8e8:      	mov	w8, #0x4                // =4
     8ec:      	add	x9, sp, #0xf0
     8f0:      	add	x0, sp, #0xf0
     8f4:      	mov	w1, #0x8                // =8
     8f8:      	mov	x2, x22
     8fc:      	blr	x8
     900:      	add	x2, x29, #0x20
     904:      	mov	w8, #0x4                // =4
     908:      	mov	w9, #0x10               // =16
     90c:      	add	x10, sp, #0xf8
     910:      	add	x0, sp, #0xf8
     914:      	mov	w1, #0x10               // =16
     918:      	blr	x8
     91c:      	ldr	w21, [sp, #0xfc]
     920:      	ldr	x8, [sp, #0xb8]
     924:      	add	x29, sp, #0xf0
     928:      	ldr	x10, [sp, #0xd8]
     92c:      	sub	x12, x10, x8
     930:      	ldr	w22, [sp, #0xe0]
     934:      	subs	w10, w21, w22
     938:      	ldr	x9, [x19, #0x10]
     93c:      	ldr	x19, [sp, #0x50]
     940:      	csel	w10, wzr, w10, lo
     944:      	cmp	w22, w21
     948:      	csel	w11, w22, w21, lo
     94c:      	cinc	w13, w11, hi
     950:      	sub	w14, w22, w13
     954:      	subs	x12, x12, x13
     958:      	str	w14, [sp, #0xe0]
     95c:      	b.lo	0xcf0 <generic_retkprobe_event+0xcf0>
     960:      	cmp	x12, #0xfff
     964:      	b.hi	0xcf0 <generic_retkprobe_event+0xcf0>
     968:      	cmp	w22, w21
     96c:      	b.ls	0x978 <generic_retkprobe_event+0x978>
     970:      	mov	w13, #0x2f              // =47
     974:      	strb	w13, [x8, x12]
     978:      	add	x29, x8, x12
     97c:      	cmp	w22, w21
     980:      	add	x2, x9, x10
     984:      	and	w1, w11, #0xff
     988:      	mov	w8, #0x4                // =4
     98c:      	cinc	x0, x29, hi
     990:      	blr	x8
     994:      	cmp	w22, w21
     998:      	str	x29, [sp, #0xd8]
     99c:      	add	x29, sp, #0xf0
     9a0:      	b.ls	0xcf0 <generic_retkprobe_event+0xcf0>
     9a4:      	ldr	x8, [x29]
     9a8:      	str	x8, [sp, #0xc0]
     9ac:      	subs	w23, w23, #0x1
     9b0:      	b.ne	0x884 <generic_retkprobe_event+0x884>
     9b4:      	b	0xcf0 <generic_retkprobe_event+0xcf0>
     9b8:      	add	x2, x21, #0x10
     9bc:      	mov	w8, #0x4                // =4
     9c0:      	add	x9, sp, #0x108
     9c4:      	add	x0, sp, #0x108
     9c8:      	mov	w1, #0x8                // =8
     9cc:      	blr	x8
     9d0:      	ldr	x8, [sp, #0xd0]
     9d4:      	ldr	x9, [x19, #0x18]
     9d8:      	add	x29, sp, #0xf0
     9dc:      	cmp	x8, x9
     9e0:      	b.eq	0xce4 <generic_retkprobe_event+0xce4>
     9e4:      	add	x2, x21, #0x18
     9e8:      	mov	w8, #0x4                // =4
     9ec:      	mov	x0, x24
     9f0:      	mov	w1, #0x8                // =8
     9f4:      	blr	x8
     9f8:      	ldr	x8, [x29, #0x18]
     9fc:      	ldr	x19, [sp, #0x50]
     a00:      	add	x9, x8, #0x20
     a04:      	stp	x9, x8, [sp, #0xc8]
     a08:      	subs	w23, w23, #0x1
     a0c:      	b.ne	0x884 <generic_retkprobe_event+0x884>
     a10:      	b	0xcf0 <generic_retkprobe_event+0xcf0>
     a14:      	mov	w23, #0x800             // =2048
     a18:      	mov	w25, #0x8               // =8
     a1c:      	ldp	x29, x2, [sp, #0xc0]
     a20:      	ldp	x8, x9, [sp, #0xa8]
     a24:      	cmp	x29, x8
     a28:      	ccmp	x2, x9, #0x0, eq
     a2c:      	b.eq	0xcd8 <generic_retkprobe_event+0xcd8>
     a30:      	ldr	x21, [sp, #0xd0]
     a34:      	mov	w8, #0x4                // =4
     a38:      	add	x9, sp, #0xe8
     a3c:      	add	x0, sp, #0xe8
     a40:      	mov	w1, #0x8                // =8
     a44:      	blr	x8
     a48:      	ldr	x8, [sp, #0xe8]
     a4c:      	add	x19, sp, #0xf0
     a50:      	cmp	x29, x8
     a54:      	b.eq	0xb50 <generic_retkprobe_event+0xb50>
     a58:      	add	x22, x29, #0x18
     a5c:      	mov	w8, #0x4                // =4
     a60:      	add	x9, sp, #0x108
     a64:      	add	x0, sp, #0x108
     a68:      	mov	w1, #0x8                // =8
     a6c:      	mov	x2, x22
     a70:      	blr	x8
     a74:      	ldr	x8, [x19, #0x18]
     a78:      	cmp	x8, x29
     a7c:      	b.eq	0xb50 <generic_retkprobe_event+0xb50>
     a80:      	mov	w8, #0x4                // =4
     a84:      	add	x9, sp, #0xf0
     a88:      	add	x0, sp, #0xf0
     a8c:      	mov	w1, #0x8                // =8
     a90:      	mov	x2, x22
     a94:      	blr	x8
     a98:      	add	x2, x29, #0x20
     a9c:      	mov	w8, #0x4                // =4
     aa0:      	mov	w9, #0x10               // =16
     aa4:      	add	x10, sp, #0xf8
     aa8:      	add	x0, sp, #0xf8
     aac:      	mov	w1, #0x10               // =16
     ab0:      	blr	x8
     ab4:      	ldr	w21, [sp, #0xfc]
     ab8:      	ldr	x8, [sp, #0xb8]
     abc:      	add	x29, sp, #0xf0
     ac0:      	ldr	x10, [sp, #0xd8]
     ac4:      	sub	x12, x10, x8
     ac8:      	ldr	w22, [sp, #0xe0]
     acc:      	subs	w10, w21, w22
     ad0:      	ldr	x9, [x19, #0x10]
     ad4:      	ldr	x19, [sp, #0x50]
     ad8:      	csel	w10, wzr, w10, lo
     adc:      	cmp	w22, w21
     ae0:      	csel	w11, w22, w21, lo
     ae4:      	cinc	w13, w11, hi
     ae8:      	sub	w14, w22, w13
     aec:      	subs	x12, x12, x13
     af0:      	str	w14, [sp, #0xe0]
     af4:      	b.lo	0xcf0 <generic_retkprobe_event+0xcf0>
     af8:      	cmp	x12, #0xfff
     afc:      	b.hi	0xcf0 <generic_retkprobe_event+0xcf0>
     b00:      	cmp	w22, w21
     b04:      	b.ls	0xb10 <generic_retkprobe_event+0xb10>
     b08:      	mov	w13, #0x2f              // =47
     b0c:      	strb	w13, [x8, x12]
     b10:      	add	x29, x8, x12
     b14:      	cmp	w22, w21
     b18:      	add	x2, x9, x10
     b1c:      	and	w1, w11, #0xff
     b20:      	mov	w8, #0x4                // =4
     b24:      	cinc	x0, x29, hi
     b28:      	blr	x8
     b2c:      	cmp	w22, w21
     b30:      	str	x29, [sp, #0xd8]
     b34:      	add	x29, sp, #0xf0
     b38:      	b.ls	0xcf0 <generic_retkprobe_event+0xcf0>
     b3c:      	ldr	x8, [x29]
     b40:      	str	x8, [sp, #0xc0]
     b44:      	subs	w23, w23, #0x1
     b48:      	b.ne	0xa1c <generic_retkprobe_event+0xa1c>
     b4c:      	b	0xcf0 <generic_retkprobe_event+0xcf0>
     b50:      	add	x2, x21, #0x10
     b54:      	mov	w8, #0x4                // =4
     b58:      	add	x9, sp, #0x108
     b5c:      	add	x0, sp, #0x108
     b60:      	mov	w1, #0x8                // =8
     b64:      	blr	x8
     b68:      	ldr	x8, [sp, #0xd0]
     b6c:      	ldr	x9, [x19, #0x18]
     b70:      	add	x29, sp, #0xf0
     b74:      	cmp	x8, x9
     b78:      	b.eq	0xce4 <generic_retkprobe_event+0xce4>
     b7c:      	add	x2, x21, #0x18
     b80:      	mov	w8, #0x4                // =4
     b84:      	mov	x0, x24
     b88:      	mov	w1, #0x8                // =8
     b8c:      	blr	x8
     b90:      	ldr	x8, [x29, #0x18]
     b94:      	ldr	x19, [sp, #0x50]
     b98:      	add	x9, x8, #0x20
     b9c:      	stp	x9, x8, [sp, #0xc8]
     ba0:      	subs	w23, w23, #0x1
     ba4:      	b.ne	0xa1c <generic_retkprobe_event+0xa1c>
     ba8:      	b	0xcf0 <generic_retkprobe_event+0xcf0>
     bac:      	mov	w8, #0x8                // =8
     bb0:      	mov	w9, #0x4                // =4
     bb4:      	add	x10, sp, #0xf8
     bb8:      	add	x11, sp, #0xa8
     bbc:      	add	x0, sp, #0xf8
     bc0:      	add	x2, sp, #0xa8
     bc4:      	mov	w1, #0x8                // =8
     bc8:      	blr	x9
     bcc:      	ldr	x8, [x19, #0x8]
     bd0:      	str	x8, [sp, #0x38]
     bd4:      	cbnz	x8, 0x6e8 <generic_retkprobe_event+0x6e8>
     bd8:      	str	wzr, [sp, #0x80]
     bdc:      	mov	w8, #0x1                // =1
     be0:      	add	x9, sp, #0x80
     be4:      	add	x1, sp, #0x80
     be8:      	mov	x0, x24
     bec:      	blr	x8
     bf0:      	ldr	x19, [sp, #0x50]
     bf4:      	mov	x29, xzr
     bf8:      	cbz	x0, 0xdd4 <generic_retkprobe_event+0xdd4>
     bfc:      	cmp	w23, #0x19
     c00:      	b.gt	0xfd8 <generic_retkprobe_event+0xfd8>
     c04:      	cmp	w23, #0x12
     c08:      	b.le	0x1160 <generic_retkprobe_event+0x1160>
     c0c:      	cmp	w23, #0x14
     c10:      	b.le	0x13a0 <generic_retkprobe_event+0x13a0>
     c14:      	cmp	w23, #0x15
     c18:      	b.eq	0x1a34 <generic_retkprobe_event+0x1a34>
     c1c:      	cmp	w23, #0x16
     c20:      	b.eq	0x19d4 <generic_retkprobe_event+0x19d4>
     c24:      	cmp	w23, #0x17
     c28:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
     c2c:      	ldr	x8, [sp, #0x30]
     c30:      	mov	w29, #0x8               // =8
     c34:      	stp	w25, wzr, [x8, #0x9c]
     c38:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
     c3c:      	cmp	w23, #0x2c
     c40:      	b.hi	0xbd8 <generic_retkprobe_event+0xbd8>
     c44:      	mov	x9, #0x7cf2             // =31986
     c48:      	mov	w8, #0x1                // =1
     c4c:      	movk	x9, #0xf202, lsl #16
     c50:      	lsl	x8, x8, x23
     c54:      	movk	x9, #0x11c1, lsl #32
     c58:      	tst	x8, x9
     c5c:      	b.eq	0xbd8 <generic_retkprobe_event+0xbd8>
     c60:      	add	x8, sp, #0xf0
     c64:      	str	wzr, [sp, #0xf0]
     c68:      	add	x9, sp, #0xf0
     c6c:      	add	x1, sp, #0xf0
     c70:      	str	x25, [x8, #0x18]
     c74:      	mov	w8, #0x1                // =1
     c78:      	mov	x0, x24
     c7c:      	blr	x8
     c80:      	ldr	x19, [sp, #0x50]
     c84:      	cbz	x0, 0x136c <generic_retkprobe_event+0x136c>
     c88:      	add	x25, sp, #0xf0
     c8c:      	mov	x29, xzr
     c90:      	cmp	w23, #0x10
     c94:      	b.le	0xe18 <generic_retkprobe_event+0xe18>
     c98:      	cmp	w23, #0x1e
     c9c:      	b.le	0xf2c <generic_retkprobe_event+0xf2c>
     ca0:      	cmp	w23, #0x26
     ca4:      	b.gt	0x10a4 <generic_retkprobe_event+0x10a4>
     ca8:      	ldr	x0, [sp, #0x28]
     cac:      	sub	w8, w23, #0x1f
     cb0:      	cmp	w8, #0x2
     cb4:      	b.hs	0x1444 <generic_retkprobe_event+0x1444>
     cb8:      	mov	w8, #0x1                // =1
     cbc:      	add	x9, sp, #0x108
     cc0:      	mov	w10, #0x4               // =4
     cc4:      	add	x2, sp, #0x108
     cc8:      	mov	w1, #0x1                // =1
     ccc:      	mov	w29, #0x4               // =4
     cd0:      	blr	x10
     cd4:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
     cd8:      	mov	w8, #0x1                // =1
     cdc:      	add	x29, sp, #0xf0
     ce0:      	b	0xcec <generic_retkprobe_event+0xcec>
     ce4:      	ldr	x19, [sp, #0x50]
     ce8:      	mov	w8, #0x1                // =1
     cec:      	strb	w8, [sp, #0xe4]
     cf0:      	ldr	x8, [sp, #0xd8]
     cf4:      	ldr	x2, [sp, #0x40]
     cf8:      	cmp	x8, x2
     cfc:      	b.eq	0xd30 <generic_retkprobe_event+0xd30>
     d00:      	ldrb	w9, [sp, #0xe4]
     d04:      	mov	w11, #0x1000            // =4096
     d08:      	cmp	w9, #0x0
     d0c:      	ldr	w9, [sp, #0xe0]
     d10:      	cset	w10, eq
     d14:      	sub	w11, w11, w9
     d18:      	cmp	w9, #0x0
     d1c:      	csel	w9, w11, w9, gt
     d20:      	cbz	x8, 0xdf0 <generic_retkprobe_event+0xdf0>
     d24:      	lsl	w23, w10, #1
     d28:      	mov	x2, x8
     d2c:      	b	0xd38 <generic_retkprobe_event+0xd38>
     d30:      	mov	w23, wzr
     d34:      	mov	w9, wzr
     d38:      	ldr	x21, [sp, #0x30]
     d3c:      	and	w22, w9, #0xfff
     d40:      	mov	w8, #0x4                // =4
     d44:      	mov	w24, #0x4               // =4
     d48:      	mov	w1, w22
     d4c:      	add	x0, x21, #0xa0
     d50:      	blr	x8
     d54:      	str	w22, [x21, #0x9c]
     d58:      	ldr	x2, [sp, #0x20]
     d5c:      	mov	w21, #0x8               // =8
     d60:      	add	x8, sp, #0xa8
     d64:      	mov	w9, #0x4                // =4
     d68:      	add	x0, sp, #0xa8
     d6c:      	mov	w1, #0x8                // =8
     d70:      	blr	x9
     d74:      	ldr	x8, [sp, #0xa8]
     d78:      	add	x9, sp, #0xf8
     d7c:      	mov	w10, #0x4               // =4
     d80:      	add	x0, sp, #0xf8
     d84:      	mov	w1, #0x8                // =8
     d88:      	add	x8, x8, #0x30
     d8c:      	ldr	x8, [sp, #0xa8]
     d90:      	add	x2, x8, #0x30
     d94:      	blr	x10
     d98:      	ldr	x8, [x29, #0x8]
     d9c:      	mov	w9, #0x2                // =2
     da0:      	add	x10, sp, #0x108
     da4:      	add	x0, sp, #0x108
     da8:      	ldr	x2, [x29, #0x8]
     dac:      	mov	w1, #0x2                // =2
     db0:      	blr	x24
     db4:      	ldr	x8, [sp, #0x28]
     db8:      	add	w29, w22, #0xa
     dbc:      	mov	w21, #0x5ea0            // =24224
     dc0:      	add	x8, x8, x22
     dc4:      	ldr	x22, [sp, #0x18]
     dc8:      	str	w23, [x8, #0x4]
     dcc:      	ldrh	w9, [sp, #0x108]
     dd0:      	strh	w9, [x8, #0x8]
     dd4:      	tbz	w29, #0x1f, 0xdf8 <generic_retkprobe_event+0xdf8>
     dd8:      	ldr	x9, [sp, #0x30]
     ddc:      	mov	w8, #-0x1               // =-1
     de0:      	str	w8, [x9, x21]
     de4:      	str	w8, [x9, #0x98]
     de8:      	mov	w8, #0x4                // =4
     dec:      	b	0xe00 <generic_retkprobe_event+0xe00>
     df0:      	ldr	x22, [sp, #0x18]
     df4:      	mov	x29, xzr
     df8:      	and	x8, x29, #0x7fffffff
     dfc:      	add	x8, x8, #0x4
     e00:      	ldr	x29, [sp, #0x48]
     e04:      	add	x21, x8, #0x8
     e08:      	ldr	w8, [x29, #0x60]
     e0c:      	cmp	w8, #0xb
     e10:      	b.ne	0x16c <generic_retkprobe_event+0x16c>
     e14:      	b	0x288 <generic_retkprobe_event+0x288>
     e18:      	cmp	w23, #0x9
     e1c:      	b.gt	0xf54 <generic_retkprobe_event+0xf54>
     e20:      	cmp	w23, #0x4
     e24:      	b.le	0x11a8 <generic_retkprobe_event+0x11a8>
     e28:      	cmp	w23, #0x5
     e2c:      	b.eq	0x15d8 <generic_retkprobe_event+0x15d8>
     e30:      	cmp	w23, #0x6
     e34:      	b.eq	0xfbc <generic_retkprobe_event+0xfbc>
     e38:      	cmp	w23, #0x7
     e3c:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
     e40:      	add	x29, sp, #0xf0
     e44:      	str	x22, [sp, #0x18]
     e48:      	ldr	x25, [sp, #0x30]
     e4c:      	mov	x24, x0
     e50:      	mov	w21, #0x2               // =2
     e54:      	mov	w8, #0x4                // =4
     e58:      	ldr	x22, [x29, #0x18]
     e5c:      	mov	w1, #0x2                // =2
     e60:      	mov	w23, #0x4               // =4
     e64:      	stur	x22, [x25, #0xc4]
     e68:      	add	x0, x25, #0xc2
     e6c:      	add	x2, x22, #0x10
     e70:      	blr	x8
     e74:      	add	x0, x25, #0xd6
     e78:      	add	x2, x22, #0x12
     e7c:      	mov	w8, #0x1                // =1
     e80:      	mov	w9, #0x4                // =4
     e84:      	mov	w1, #0x1                // =1
     e88:      	blr	x9
     e8c:      	add	x0, x25, #0xd4
     e90:      	add	x2, x22, #0x21e
     e94:      	mov	w8, #0x4                // =4
     e98:      	mov	w1, #0x2                // =2
     e9c:      	blr	x8
     ea0:      	add	x0, x25, #0xc0
     ea4:      	add	x2, x22, #0x21c
     ea8:      	mov	w8, #0x4                // =4
     eac:      	mov	w1, #0x2                // =2
     eb0:      	blr	x8
     eb4:      	add	x0, x25, #0xcc
     eb8:      	add	x2, x22, #0x214
     ebc:      	mov	w8, #0x4                // =4
     ec0:      	mov	w1, #0x4                // =4
     ec4:      	blr	x8
     ec8:      	add	x0, x25, #0xd0
     ecc:      	add	x2, x22, #0x210
     ed0:      	mov	w1, #0x4                // =4
     ed4:      	blr	x23
     ed8:      	ldrh	w8, [x25, #0xc2]
     edc:      	ldr	x0, [sp, #0x28]
     ee0:      	add	x23, x25, #0xac
     ee4:      	cmp	w8, #0xa
     ee8:      	stp	xzr, xzr, [x0]
     eec:      	stp	xzr, xzr, [x0, #0x10]
     ef0:      	b.eq	0x1d74 <generic_retkprobe_event+0x1d74>
     ef4:      	cmp	w8, #0x2
     ef8:      	b.ne	0x1d9c <generic_retkprobe_event+0x1d9c>
     efc:      	add	x2, x22, #0x4
     f00:      	mov	w8, #0x4                // =4
     f04:      	mov	w1, #0x4                // =4
     f08:      	mov	w21, #0x4               // =4
     f0c:      	blr	x8
     f10:      	mov	x0, x23
     f14:      	mov	w1, #0x4                // =4
     f18:      	mov	x2, x22
     f1c:      	blr	x21
     f20:      	b	0x1d9c <generic_retkprobe_event+0x1d9c>
     f24:      	mov	x29, x23
     f28:      	b	0x318 <generic_retkprobe_event+0x318>
     f2c:      	cmp	w23, #0x1c
     f30:      	b.gt	0x1184 <generic_retkprobe_event+0x1184>
     f34:      	cmp	w23, #0x11
     f38:      	b.eq	0x1470 <generic_retkprobe_event+0x1470>
     f3c:      	cmp	w23, #0x19
     f40:      	b.eq	0x152c <generic_retkprobe_event+0x152c>
     f44:      	ldr	x0, [sp, #0x28]
     f48:      	cmp	w23, #0x1c
     f4c:      	b.eq	0x11bc <generic_retkprobe_event+0x11bc>
     f50:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
     f54:      	ldr	x0, [sp, #0x28]
     f58:      	sub	w8, w23, #0xa
     f5c:      	cmp	w8, #0x2
     f60:      	b.lo	0x11bc <generic_retkprobe_event+0x11bc>
     f64:      	sub	w8, w23, #0xc
     f68:      	cmp	w8, #0x2
     f6c:      	b.lo	0x11d4 <generic_retkprobe_event+0x11d4>
     f70:      	cmp	w23, #0xe
     f74:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
     f78:      	mov	w21, #0x8               // =8
     f7c:      	add	x8, sp, #0xa8
     f80:      	add	x23, sp, #0x108
     f84:      	mov	w9, #0x4                // =4
     f88:      	add	x0, sp, #0xa8
     f8c:      	add	x2, sp, #0x108
     f90:      	mov	w1, #0x8                // =8
     f94:      	mov	x24, x22
     f98:      	mov	w22, #0x4               // =4
     f9c:      	blr	x9
     fa0:      	ldr	x8, [sp, #0xa8]
     fa4:      	add	x0, sp, #0x108
     fa8:      	mov	w1, #0x8                // =8
     fac:      	mov	w21, #0x5ea0            // =24224
     fb0:      	ldr	x2, [sp, #0xa8]
     fb4:      	blr	x22
     fb8:      	mov	x22, x24
     fbc:      	ldr	x8, [sp, #0x30]
     fc0:      	ldr	x2, [x25, #0x18]
     fc4:      	mov	w9, #0x2d               // =45
     fc8:      	mov	w1, #0x1001             // =4097
     fcc:      	add	x0, x8, #0xa0
     fd0:      	mov	w8, #0x1001             // =4097
     fd4:      	b	0x174c <generic_retkprobe_event+0x174c>
     fd8:      	cmp	w23, #0x20
     fdc:      	b.le	0x1304 <generic_retkprobe_event+0x1304>
     fe0:      	sub	w8, w23, #0x21
     fe4:      	cmp	w8, #0x4
     fe8:      	b.hs	0x11f0 <generic_retkprobe_event+0x11f0>
     fec:      	ldr	x0, [sp, #0x28]
     ff0:      	mov	w29, #0x8               // =8
     ff4:      	mov	w8, #0x4                // =4
     ff8:      	mov	w1, #0x8                // =8
     ffc:      	b	0x1394 <generic_retkprobe_event+0x1394>
    1000:      	add	x8, x29, x22
    1004:      	mov	w9, #0x4                // =4
    1008:      	mov	x22, x10
    100c:      	str	x8, [sp, #0x58]
    1010:      	add	x0, x24, x8
    1014:      	ldr	x8, [sp, #0xa8]
    1018:      	mov	w1, w22
    101c:      	ldr	x2, [sp, #0xa8]
    1020:      	blr	x9
    1024:      	tbnz	w0, #0x1f, 0x1094 <generic_retkprobe_event+0x1094>
    1028:      	add	x29, x22, x29
    102c:      	cbz	x21, 0x1038 <generic_retkprobe_event+0x1038>
    1030:      	subs	x21, x21, x23
    1034:      	b.eq	0x318 <generic_retkprobe_event+0x318>
    1038:      	ldr	x8, [sp, #0x60]
    103c:      	cmp	x8, #0x3
    1040:      	b.lo	0x318 <generic_retkprobe_event+0x318>
    1044:      	ldr	x8, [sp, #0x118]
    1048:      	str	x19, [sp, #0x50]
    104c:      	mov	w9, #0x4                // =4
    1050:      	add	x10, sp, #0xa8
    1054:      	add	x0, sp, #0xa8
    1058:      	mov	w1, #0x10               // =16
    105c:      	add	x2, x8, #0x20
    1060:      	mov	w8, #0x10               // =16
    1064:      	blr	x9
    1068:      	tbnz	w0, #0x1f, 0x2110 <generic_retkprobe_event+0x2110>
    106c:      	ldr	x8, [sp, #0xb0]
    1070:      	cmp	x8, x21
    1074:      	csel	x23, x8, x21, lo
    1078:      	cmp	x21, #0x0
    107c:      	csel	x8, x8, x23, eq
    1080:      	cmp	x8, #0xffe
    1084:      	str	x8, [sp, #0x40]
    1088:      	b.ls	0x1ea0 <generic_retkprobe_event+0x1ea0>
    108c:      	mov	w8, #-0x3               // =-3
    1090:      	b	0x2114 <generic_retkprobe_event+0x2114>
    1094:      	mov	w8, #-0x2               // =-2
    1098:      	str	w8, [x24, x25]
    109c:      	mov	w8, #0x4                // =4
    10a0:      	b	0x324 <generic_retkprobe_event+0x324>
    10a4:      	ldr	x0, [sp, #0x28]
    10a8:      	cmp	w23, #0x27
    10ac:      	b.eq	0x1730 <generic_retkprobe_event+0x1730>
    10b0:      	cmp	w23, #0x28
    10b4:      	b.eq	0x176c <generic_retkprobe_event+0x176c>
    10b8:      	cmp	w23, #0x2c
    10bc:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
    10c0:      	mov	x24, x22
    10c4:      	ldr	x22, [x25, #0x18]
    10c8:      	strb	wzr, [sp, #0xa8]
    10cc:      	mov	w8, #0x2                // =2
    10d0:      	mov	w9, #0x4                // =4
    10d4:      	mov	w1, #0x2                // =2
    10d8:      	mov	x2, x22
    10dc:      	stp	xzr, xzr, [x0]
    10e0:      	stp	xzr, xzr, [x0, #0x10]
    10e4:      	stp	xzr, xzr, [x0, #0x20]
    10e8:      	stp	xzr, xzr, [x0, #0x30]
    10ec:      	stp	xzr, xzr, [x0, #0x40]
    10f0:      	stp	xzr, xzr, [x0, #0x50]
    10f4:      	stp	xzr, xzr, [x0, #0x60]
    10f8:      	blr	x9
    10fc:      	tbnz	x0, #0x3f, 0x2140 <generic_retkprobe_event+0x2140>
    1100:      	add	x23, x22, #0x2
    1104:      	mov	w8, #0x1                // =1
    1108:      	mov	w9, #0x4                // =4
    110c:      	add	x10, sp, #0xa8
    1110:      	add	x0, sp, #0xa8
    1114:      	mov	w1, #0x1                // =1
    1118:      	mov	x2, x23
    111c:      	blr	x9
    1120:      	tbnz	x0, #0x3f, 0x2140 <generic_retkprobe_event+0x2140>
    1124:      	ldrb	w8, [sp, #0xa8]
    1128:      	ldr	x10, [sp, #0x30]
    112c:      	cmp	w8, #0x0
    1130:      	add	x0, x10, #0xa0
    1134:      	cset	w9, eq
    1138:      	strb	w9, [x10, #0x9e]
    113c:      	cbz	w8, 0x2120 <generic_retkprobe_event+0x2120>
    1140:      	mov	w8, #0x6c               // =108
    1144:      	mov	w9, #0x2d               // =45
    1148:      	mov	w1, #0x6c               // =108
    114c:      	mov	x2, x23
    1150:      	blr	x9
    1154:      	tbnz	w0, #0x1f, 0x2140 <generic_retkprobe_event+0x2140>
    1158:      	sub	w21, w0, #0x1
    115c:      	b	0x2138 <generic_retkprobe_event+0x2138>
    1160:      	cmp	w23, #0x7
    1164:      	b.gt	0x1374 <generic_retkprobe_event+0x1374>
    1168:      	cmp	w23, #0x2
    116c:      	b.eq	0x17e4 <generic_retkprobe_event+0x17e4>
    1170:      	cmp	w23, #0x3
    1174:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
    1178:      	stur	xzr, [x0, #0x9c]
    117c:      	mov	w29, #0x8               // =8
    1180:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    1184:      	ldr	x0, [sp, #0x28]
    1188:      	mov	w8, #0x2                // =2
    118c:      	add	x9, sp, #0x108
    1190:      	mov	w10, #0x4               // =4
    1194:      	add	x2, sp, #0x108
    1198:      	mov	w1, #0x2                // =2
    119c:      	mov	w29, #0x4               // =4
    11a0:      	blr	x10
    11a4:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    11a8:      	ldr	x0, [sp, #0x28]
    11ac:      	cmp	w23, #0x1
    11b0:      	b.eq	0x11d4 <generic_retkprobe_event+0x11d4>
    11b4:      	cmp	w23, #0x4
    11b8:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
    11bc:      	mov	w29, #0x8               // =8
    11c0:      	mov	w8, #0x4                // =4
    11c4:      	add	x9, sp, #0x108
    11c8:      	add	x2, sp, #0x108
    11cc:      	mov	w1, #0x8                // =8
    11d0:      	b	0x1398 <generic_retkprobe_event+0x1398>
    11d4:      	add	x8, sp, #0x108
    11d8:      	mov	w9, #0x4                // =4
    11dc:      	add	x2, sp, #0x108
    11e0:      	mov	w1, #0x4                // =4
    11e4:      	mov	w29, #0x4               // =4
    11e8:      	blr	x9
    11ec:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    11f0:      	cmp	w23, #0x2b
    11f4:      	b.eq	0x1af4 <generic_retkprobe_event+0x1af4>
    11f8:      	cmp	w23, #0x29
    11fc:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
    1200:      	str	x22, [sp, #0x18]
    1204:      	add	x2, x25, #0x18
    1208:      	mov	w8, #0x8                // =8
    120c:      	mov	w9, #0x4                // =4
    1210:      	add	x10, sp, #0xa8
    1214:      	mov	x24, x0
    1218:      	add	x0, sp, #0xa8
    121c:      	mov	w1, #0x8                // =8
    1220:      	blr	x9
    1224:      	ldr	x22, [sp, #0xa8]
    1228:      	cbz	x22, 0x21c0 <generic_retkprobe_event+0x21c0>
    122c:      	ldr	x25, [sp, #0x30]
    1230:      	add	x2, x22, #0x10
    1234:      	mov	w21, #0x2               // =2
    1238:      	mov	w8, #0x4                // =4
    123c:      	stur	x22, [x25, #0xc4]
    1240:      	add	x0, x25, #0xc2
    1244:      	mov	w1, #0x2                // =2
    1248:      	mov	w23, #0x4               // =4
    124c:      	blr	x8
    1250:      	add	x0, x25, #0xd6
    1254:      	add	x2, x22, #0x12
    1258:      	mov	w8, #0x1                // =1
    125c:      	mov	w9, #0x4                // =4
    1260:      	mov	w1, #0x1                // =1
    1264:      	blr	x9
    1268:      	add	x0, x25, #0xd4
    126c:      	add	x2, x22, #0x21e
    1270:      	mov	w8, #0x4                // =4
    1274:      	mov	w1, #0x2                // =2
    1278:      	blr	x8
    127c:      	add	x0, x25, #0xc0
    1280:      	add	x2, x22, #0x21c
    1284:      	mov	w8, #0x4                // =4
    1288:      	mov	w1, #0x2                // =2
    128c:      	blr	x8
    1290:      	add	x0, x25, #0xcc
    1294:      	add	x2, x22, #0x214
    1298:      	mov	w8, #0x4                // =4
    129c:      	mov	w1, #0x4                // =4
    12a0:      	blr	x8
    12a4:      	add	x0, x25, #0xd0
    12a8:      	add	x2, x22, #0x210
    12ac:      	mov	w1, #0x4                // =4
    12b0:      	blr	x23
    12b4:      	ldr	x8, [sp, #0x28]
    12b8:      	add	x23, x25, #0xac
    12bc:      	stp	xzr, xzr, [x8]
    12c0:      	stp	xzr, xzr, [x8, #0x10]
    12c4:      	ldrh	w8, [x25, #0xc2]
    12c8:      	cmp	w8, #0xa
    12cc:      	b.eq	0x2150 <generic_retkprobe_event+0x2150>
    12d0:      	cmp	w8, #0x2
    12d4:      	b.ne	0x217c <generic_retkprobe_event+0x217c>
    12d8:      	ldr	x0, [sp, #0x28]
    12dc:      	add	x2, x22, #0x4
    12e0:      	mov	w8, #0x4                // =4
    12e4:      	mov	w1, #0x4                // =4
    12e8:      	mov	w21, #0x4               // =4
    12ec:      	blr	x8
    12f0:      	mov	x0, x23
    12f4:      	mov	w1, #0x4                // =4
    12f8:      	mov	x2, x22
    12fc:      	blr	x21
    1300:      	b	0x217c <generic_retkprobe_event+0x217c>
    1304:      	cmp	w23, #0x1a
    1308:      	b.eq	0x1b84 <generic_retkprobe_event+0x1b84>
    130c:      	cmp	w23, #0x1b
    1310:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
    1314:      	ldp	x9, x8, [sp, #0x28]
    1318:      	add	x2, x25, #0x18
    131c:      	mov	w1, #0x3f               // =63
    1320:      	add	x0, x8, #0xac
    1324:      	stp	xzr, xzr, [x9, #0x40]
    1328:      	stp	xzr, xzr, [x9, #0x30]
    132c:      	stp	xzr, xzr, [x9, #0x20]
    1330:      	mov	w8, #0x3f               // =63
    1334:      	stp	xzr, xzr, [x9, #0x10]
    1338:      	stp	xzr, xzr, [x9]
    133c:      	mov	w9, #0x2d               // =45
    1340:      	blr	x9
    1344:      	tbnz	x0, #0x3f, 0x136c <generic_retkprobe_event+0x136c>
    1348:      	ldr	x8, [sp, #0x30]
    134c:      	add	x2, x25, #0x360
    1350:      	mov	w9, #0x4                // =4
    1354:      	mov	w1, #0x8                // =8
    1358:      	add	x0, x8, #0xa4
    135c:      	mov	w8, #0x8                // =8
    1360:      	blr	x9
    1364:      	mov	w29, #0x50              // =80
    1368:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    136c:      	mov	x29, xzr
    1370:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    1374:      	cmp	w23, #0x8
    1378:      	b.eq	0x1854 <generic_retkprobe_event+0x1854>
    137c:      	cmp	w23, #0x12
    1380:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
    1384:      	mov	x29, xzr
    1388:      	mov	w8, #0x4                // =4
    138c:      	ldr	x0, [sp, #0x28]
    1390:      	mov	w1, wzr
    1394:      	mov	x2, x25
    1398:      	blr	x8
    139c:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    13a0:      	cmp	w23, #0x13
    13a4:      	b.eq	0x1ab4 <generic_retkprobe_event+0x1ab4>
    13a8:      	cmp	w23, #0x14
    13ac:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
    13b0:      	str	xzr, [sp, #0xa8]
    13b4:      	add	x2, x25, #0x110
    13b8:      	mov	w24, #0x8               // =8
    13bc:      	add	x8, sp, #0xa8
    13c0:      	mov	w9, #0x4                // =4
    13c4:      	add	x0, sp, #0xa8
    13c8:      	mov	w1, #0x8                // =8
    13cc:      	mov	x21, x22
    13d0:      	add	x22, x25, #0xd8
    13d4:      	mov	w23, #0x4               // =4
    13d8:      	blr	x9
    13dc:      	ldr	x8, [sp, #0xa8]
    13e0:      	mov	w9, #0x80               // =128
    13e4:      	mov	w10, #0x2d              // =45
    13e8:      	ldr	x0, [sp, #0x28]
    13ec:      	mov	w1, #0x80               // =128
    13f0:      	ldr	x2, [sp, #0xa8]
    13f4:      	blr	x10
    13f8:      	ldr	x29, [sp, #0x30]
    13fc:      	mov	w8, #0x4                // =4
    1400:      	mov	w1, #0x4                // =4
    1404:      	mov	x2, x22
    1408:      	add	x0, x29, #0x12c
    140c:      	mov	x22, x21
    1410:      	mov	w21, #0x5ea0            // =24224
    1414:      	blr	x8
    1418:      	add	x0, x29, #0x11c
    141c:      	add	x2, x25, #0xe0
    1420:      	mov	w8, #0x4                // =4
    1424:      	mov	w1, #0x8                // =8
    1428:      	blr	x8
    142c:      	add	x0, x29, #0x124
    1430:      	add	x2, x25, #0x118
    1434:      	mov	w1, #0x8                // =8
    1438:      	blr	x23
    143c:      	mov	w29, #0x98              // =152
    1440:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    1444:      	cmp	w23, #0x26
    1448:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
    144c:      	ldr	x8, [x25, #0x18]
    1450:      	ldr	x9, [sp, #0x30]
    1454:      	add	x2, x19, w8, uxth
    1458:      	ubfx	w8, w8, #16, #12
    145c:      	add	x0, x9, #0xa0
    1460:      	add	w1, w8, #0x1
    1464:      	mov	w8, #0x2d               // =45
    1468:      	blr	x8
    146c:      	b	0x1750 <generic_retkprobe_event+0x1750>
    1470:      	stp	xzr, xzr, [sp, #0xa8]
    1474:      	mov	w8, #0xe                // =14
    1478:      	mov	x24, x22
    147c:      	blr	x8
    1480:      	lsr	x8, x0, #32
    1484:      	add	x9, sp, #0xf8
    1488:      	add	x10, sp, #0x108
    148c:      	str	x8, [sp, #0xa8]
    1490:      	mov	w8, #0x4                // =4
    1494:      	add	x0, sp, #0xf8
    1498:      	add	x2, sp, #0x108
    149c:      	mov	w1, #0x4                // =4
    14a0:      	blr	x8
    14a4:      	ldr	w8, [sp, #0xf8]
    14a8:      	adrp	x0, 0x1000 <generic_retkprobe_event+0x1000>
    14ac:      	add	x9, sp, #0xa8
    14b0:      	add	x1, sp, #0xa8
    14b4:      	str	w8, [sp, #0xb0]
    14b8:      	mov	w8, #0x1                // =1
    14bc:      	ldr	x0, [x0]
    14c0:      	blr	x8
    14c4:      	cbz	x0, 0x1c68 <generic_retkprobe_event+0x1c68>
    14c8:      	ldr	x25, [sp, #0x28]
    14cc:      	ldr	w21, [x0]
    14d0:      	add	x8, sp, #0xf8
    14d4:      	mov	w9, #0x4                // =4
    14d8:      	add	x2, sp, #0xf8
    14dc:      	mov	x22, x0
    14e0:      	mov	w1, #0x4                // =4
    14e4:      	mov	w23, #0x4               // =4
    14e8:      	mov	x0, x25
    14ec:      	blr	x9
    14f0:      	ldr	x8, [sp, #0x30]
    14f4:      	and	x21, x21, #0xfff
    14f8:      	mov	x2, x22
    14fc:      	add	x1, x21, #0x4
    1500:      	add	x0, x8, #0xa0
    1504:      	mov	w8, #0x4                // =4
    1508:      	blr	x8
    150c:      	add	w21, w21, #0x8
    1510:      	mov	w1, #0x4                // =4
    1514:      	add	x8, x21, x22
    1518:      	add	x0, x25, x21
    151c:      	sub	x2, x8, #0x4
    1520:      	blr	x23
    1524:      	add	x29, x21, #0x4
    1528:      	b	0x2144 <generic_retkprobe_event+0x2144>
    152c:      	add	x29, sp, #0xf0
    1530:      	mov	x25, x22
    1534:      	mov	w8, #0x1                // =1
    1538:      	ldr	x22, [x29, #0x18]
    153c:      	mov	w9, #0x4                // =4
    1540:      	add	x10, sp, #0xe8
    1544:      	mov	x23, x0
    1548:      	add	x0, sp, #0xe8
    154c:      	mov	w1, #0x1                // =1
    1550:      	mov	x2, x22
    1554:      	blr	x9
    1558:      	ldrb	w8, [sp, #0xe8]
    155c:      	cbz	w8, 0x1c70 <generic_retkprobe_event+0x1c70>
    1560:      	cmp	w8, #0x1
    1564:      	b.ne	0x1e20 <generic_retkprobe_event+0x1e20>
    1568:      	add	x2, x22, #0x10
    156c:      	mov	w21, #0x8               // =8
    1570:      	add	x8, sp, #0xa8
    1574:      	mov	w9, #0x4                // =4
    1578:      	add	x0, sp, #0xa8
    157c:      	mov	w1, #0x8                // =8
    1580:      	mov	w24, #0x4               // =4
    1584:      	blr	x9
    1588:      	ldr	x2, [sp, #0xa8]
    158c:      	add	x8, sp, #0xf8
    1590:      	mov	w9, #0x4                // =4
    1594:      	add	x0, sp, #0xf8
    1598:      	mov	w1, #0x8                // =8
    159c:      	blr	x9
    15a0:      	ldr	x8, [sp, #0xa8]
    15a4:      	mov	w9, #0x4                // =4
    15a8:      	add	x0, sp, #0x80
    15ac:      	mov	w1, #0x8                // =8
    15b0:      	add	x2, x8, #0x8
    15b4:      	add	x8, sp, #0x80
    15b8:      	blr	x9
    15bc:      	ldr	x21, [sp, #0x80]
    15c0:      	mov	w8, #0xfff              // =4095
    15c4:      	ldr	x2, [x29, #0x8]
    15c8:      	add	x0, x23, #0xa4
    15cc:      	cmp	x21, #0xfff
    15d0:      	csel	x22, x21, x8, lo
    15d4:      	b	0x1cc0 <generic_retkprobe_event+0x1cc0>
    15d8:      	add	x8, sp, #0xf0
    15dc:      	ldr	x21, [sp, #0x30]
    15e0:      	str	x22, [sp, #0x18]
    15e4:      	mov	w1, #0x4                // =4
    15e8:      	mov	w23, #0x4               // =4
    15ec:      	add	x0, x21, #0xc4
    15f0:      	ldr	x24, [x8, #0x18]
    15f4:      	mov	w8, #0x4                // =4
    15f8:      	add	x2, x24, #0x98
    15fc:      	blr	x8
    1600:      	add	x0, x21, #0xc8
    1604:      	add	x2, x24, #0x70
    1608:      	mov	w8, #0x4                // =4
    160c:      	mov	w1, #0x4                // =4
    1610:      	blr	x8
    1614:      	add	x0, x21, #0xcc
    1618:      	add	x2, x24, #0x90
    161c:      	mov	w8, #0x4                // =4
    1620:      	mov	w1, #0x4                // =4
    1624:      	blr	x8
    1628:      	add	x0, x21, #0xd0
    162c:      	add	x2, x24, #0xa8
    1630:      	mov	w8, #0x4                // =4
    1634:      	mov	w1, #0x4                // =4
    1638:      	blr	x8
    163c:      	str	xzr, [sp, #0xa8]
    1640:      	add	x2, x24, #0xc8
    1644:      	mov	w8, #0x8                // =8
    1648:      	add	x9, sp, #0xa8
    164c:      	mov	w10, #0x4               // =4
    1650:      	add	x0, sp, #0xa8
    1654:      	mov	w1, #0x8                // =8
    1658:      	blr	x10
    165c:      	add	x2, x24, #0xb8
    1660:      	mov	w8, #0x2                // =2
    1664:      	add	x9, sp, #0xe8
    1668:      	mov	w10, #0x4               // =4
    166c:      	add	x0, sp, #0xe8
    1670:      	mov	w1, #0x2                // =2
    1674:      	blr	x10
    1678:      	ldr	x8, [sp, #0xa8]
    167c:      	ldrh	w9, [sp, #0xe8]
    1680:      	add	x0, sp, #0x94
    1684:      	mov	w1, #0x1                // =1
    1688:      	add	x22, x8, x9
    168c:      	mov	w8, #0x1                // =1
    1690:      	add	x9, sp, #0x94
    1694:      	mov	x2, x22
    1698:      	blr	x23
    169c:      	ldrb	w8, [sp, #0x94]
    16a0:      	lsr	w8, w8, #4
    16a4:      	cmp	w8, #0x6
    16a8:      	b.eq	0x1cec <generic_retkprobe_event+0x1cec>
    16ac:      	cmp	w8, #0x4
    16b0:      	b.ne	0x292c <generic_retkprobe_event+0x292c>
    16b4:      	add	x2, x22, #0x9
    16b8:      	mov	w8, #0x1                // =1
    16bc:      	add	x9, sp, #0x98
    16c0:      	mov	w10, #0x4               // =4
    16c4:      	add	x0, sp, #0x98
    16c8:      	mov	w1, #0x1                // =1
    16cc:      	mov	w25, #0x4               // =4
    16d0:      	blr	x10
    16d4:      	ldrb	w8, [sp, #0x98]
    16d8:      	ldp	x0, x9, [sp, #0x28]
    16dc:      	mov	w21, #0x2               // =2
    16e0:      	add	x2, x22, #0xc
    16e4:      	mov	w1, #0x4                // =4
    16e8:      	add	x23, x9, #0xac
    16ec:      	strh	w8, [x9, #0xc0]
    16f0:      	strh	w21, [x9, #0xc2]
    16f4:      	stp	xzr, xzr, [x0]
    16f8:      	mov	w8, #0x4                // =4
    16fc:      	stp	xzr, xzr, [x0, #0x10]
    1700:      	blr	x8
    1704:      	add	x2, x22, #0x10
    1708:      	mov	w8, #0x4                // =4
    170c:      	mov	x0, x23
    1710:      	mov	w1, #0x4                // =4
    1714:      	blr	x8
    1718:      	add	x2, x24, #0xb6
    171c:      	add	x8, sp, #0xa0
    1720:      	add	x0, sp, #0xa0
    1724:      	mov	w1, #0x2                // =2
    1728:      	blr	x25
    172c:      	b	0x27f0 <generic_retkprobe_event+0x27f0>
    1730:      	ldr	x8, [x25, #0x18]
    1734:      	mov	w9, #0x2d               // =45
    1738:      	mov	w1, #0x11               // =17
    173c:      	add	x2, x8, #0x118
    1740:      	ldr	x8, [sp, #0x30]
    1744:      	add	x0, x8, #0xa0
    1748:      	mov	w8, #0x11               // =17
    174c:      	blr	x9
    1750:      	mov	x29, x0
    1754:      	tbnz	x0, #0x3f, 0xdd4 <generic_retkprobe_event+0xdd4>
    1758:      	ldr	x9, [sp, #0x28]
    175c:      	sub	w8, w29, #0x1
    1760:      	add	x29, x29, #0x3
    1764:      	str	w8, [x9]
    1768:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    176c:      	mov	x23, x22
    1770:      	ldr	x22, [x25, #0x18]
    1774:      	stp	xzr, xzr, [x0, #0x8]
    1778:      	mov	w8, #0x2                // =2
    177c:      	mov	w9, #0x4                // =4
    1780:      	mov	w1, #0x2                // =2
    1784:      	str	xzr, [x0]
    1788:      	mov	x24, x0
    178c:      	mov	x2, x22
    1790:      	blr	x9
    1794:      	tbnz	x0, #0x3f, 0x1e94 <generic_retkprobe_event+0x1e94>
    1798:      	ldrh	w8, [x24]
    179c:      	cmp	w8, #0xa
    17a0:      	b.eq	0x1e44 <generic_retkprobe_event+0x1e44>
    17a4:      	cmp	w8, #0x2
    17a8:      	b.ne	0x1e78 <generic_retkprobe_event+0x1e78>
    17ac:      	add	x2, x22, #0x4
    17b0:      	add	x8, sp, #0xa8
    17b4:      	mov	w9, #0x4                // =4
    17b8:      	add	x0, sp, #0xa8
    17bc:      	mov	w1, #0x4                // =4
    17c0:      	mov	w21, #0x4               // =4
    17c4:      	blr	x9
    17c8:      	ldr	w8, [sp, #0xa8]
    17cc:      	ldr	x9, [sp, #0x30]
    17d0:      	add	x2, x22, #0x2
    17d4:      	add	x0, x9, #0x9e
    17d8:      	stur	x8, [x9, #0xa4]
    17dc:      	mov	w8, #0x2                // =2
    17e0:      	b	0x1e70 <generic_retkprobe_event+0x1e70>
    17e4:      	add	x19, sp, #0xf0
    17e8:      	str	x22, [sp, #0x18]
    17ec:      	str	xzr, [sp, #0xa8]
    17f0:      	mov	w8, #0x8                // =8
    17f4:      	add	x9, sp, #0xf8
    17f8:      	add	x10, sp, #0xa8
    17fc:      	str	xzr, [x19, #0x8]
    1800:      	mov	w11, #0x4               // =4
    1804:      	mov	x24, x0
    1808:      	add	x0, sp, #0xf8
    180c:      	add	x2, sp, #0xa8
    1810:      	mov	w1, #0x8                // =8
    1814:      	mov	w29, #0x4               // =4
    1818:      	blr	x11
    181c:      	ldr	x21, [x19, #0x8]
    1820:      	mov	w8, #0xfff              // =4095
    1824:      	add	x0, x24, #0xa4
    1828:      	mov	x2, x25
    182c:      	mov	x23, x24
    1830:      	cmp	x21, #0xfff
    1834:      	csel	x22, x21, x8, lo
    1838:      	mov	w8, #0x4                // =4
    183c:      	mov	w1, w22
    1840:      	blr	x8
    1844:      	tbnz	w0, #0x1f, 0x1e34 <generic_retkprobe_event+0x1e34>
    1848:      	add	x29, x22, #0x8
    184c:      	str	w22, [x23, #0xa0]
    1850:      	b	0x1e38 <generic_retkprobe_event+0x1e38>
    1854:      	ldp	x0, x29, [sp, #0x28]
    1858:      	add	x2, x25, #0x8
    185c:      	mov	w8, #0x4                // =4
    1860:      	mov	w1, #0x4                // =4
    1864:      	mov	w23, #0x4               // =4
    1868:      	str	x22, [sp, #0x18]
    186c:      	add	x24, x29, #0xc4
    1870:      	add	x22, x29, #0xdc
    1874:      	blr	x8
    1878:      	add	x0, x29, #0xa0
    187c:      	add	x2, x25, #0xc
    1880:      	mov	w8, #0x4                // =4
    1884:      	mov	w1, #0x4                // =4
    1888:      	blr	x8
    188c:      	add	x0, x29, #0xac
    1890:      	add	x2, x25, #0x18
    1894:      	mov	w8, #0x4                // =4
    1898:      	mov	w1, #0x4                // =4
    189c:      	blr	x8
    18a0:      	add	x0, x29, #0xb0
    18a4:      	add	x2, x25, #0x1c
    18a8:      	mov	w8, #0x4                // =4
    18ac:      	mov	w1, #0x4                // =4
    18b0:      	blr	x8
    18b4:      	add	x0, x29, #0xa4
    18b8:      	add	x2, x25, #0x10
    18bc:      	mov	w8, #0x4                // =4
    18c0:      	mov	w1, #0x4                // =4
    18c4:      	blr	x8
    18c8:      	add	x0, x29, #0xa8
    18cc:      	add	x2, x25, #0x14
    18d0:      	mov	w8, #0x4                // =4
    18d4:      	mov	w1, #0x4                // =4
    18d8:      	blr	x8
    18dc:      	add	x0, x29, #0xb4
    18e0:      	add	x2, x25, #0x20
    18e4:      	mov	w8, #0x4                // =4
    18e8:      	mov	w1, #0x4                // =4
    18ec:      	blr	x8
    18f0:      	add	x0, x29, #0xb8
    18f4:      	add	x2, x25, #0x24
    18f8:      	mov	w8, #0x4                // =4
    18fc:      	mov	w1, #0x4                // =4
    1900:      	blr	x8
    1904:      	str	wzr, [x29, #0xc0]
    1908:      	add	x0, x29, #0xbc
    190c:      	add	x2, x25, #0x28
    1910:      	mov	w8, #0x4                // =4
    1914:      	mov	w1, #0x4                // =4
    1918:      	blr	x8
    191c:      	add	x0, x29, #0xcc
    1920:      	add	x2, x25, #0x40
    1924:      	mov	w21, #0x8               // =8
    1928:      	mov	w8, #0x4                // =4
    192c:      	mov	w1, #0x8                // =8
    1930:      	blr	x8
    1934:      	add	x0, x29, #0xd4
    1938:      	add	x2, x25, #0x30
    193c:      	mov	w8, #0x4                // =4
    1940:      	mov	w1, #0x8                // =8
    1944:      	blr	x8
    1948:      	add	x2, x25, #0x38
    194c:      	mov	w8, #0x4                // =4
    1950:      	mov	x0, x24
    1954:      	mov	w1, #0x8                // =8
    1958:      	blr	x8
    195c:      	add	x2, x25, #0x90
    1960:      	add	x8, sp, #0xa8
    1964:      	mov	w9, #0x4                // =4
    1968:      	add	x0, sp, #0xa8
    196c:      	mov	w1, #0x8                // =8
    1970:      	blr	x9
    1974:      	ldr	x21, [sp, #0xa8]
    1978:      	mov	w8, #0x4                // =4
    197c:      	mov	x0, x22
    1980:      	mov	w1, #0x4                // =4
    1984:      	add	x2, x21, #0xc8
    1988:      	ldr	x22, [sp, #0x18]
    198c:      	blr	x8
    1990:      	add	x0, x29, #0xe0
    1994:      	add	x2, x21, #0xcc
    1998:      	mov	w8, #0x4                // =4
    199c:      	mov	w1, #0x4                // =4
    19a0:      	blr	x8
    19a4:      	add	x0, x29, #0xe4
    19a8:      	add	x2, x21, #0xd0
    19ac:      	mov	w8, #0x4                // =4
    19b0:      	mov	w1, #0x4                // =4
    19b4:      	blr	x8
    19b8:      	add	x0, x29, #0xe8
    19bc:      	add	x2, x21, #0x158
    19c0:      	mov	w1, #0x4                // =4
    19c4:      	mov	w21, #0x5ea0            // =24224
    19c8:      	blr	x23
    19cc:      	mov	w29, #0x50              // =80
    19d0:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    19d4:      	ldr	x0, [sp, #0x28]
    19d8:      	add	x2, x25, #0xc8
    19dc:      	mov	w8, #0x4                // =4
    19e0:      	mov	w1, #0x4                // =4
    19e4:      	mov	w21, #0x4               // =4
    19e8:      	blr	x8
    19ec:      	ldr	x23, [sp, #0x30]
    19f0:      	add	x2, x25, #0xcc
    19f4:      	mov	w8, #0x4                // =4
    19f8:      	mov	w1, #0x4                // =4
    19fc:      	add	x0, x23, #0xa0
    1a00:      	blr	x8
    1a04:      	add	x0, x23, #0xa4
    1a08:      	add	x2, x25, #0xd0
    1a0c:      	mov	w8, #0x4                // =4
    1a10:      	mov	w1, #0x4                // =4
    1a14:      	blr	x8
    1a18:      	add	x0, x23, #0xa8
    1a1c:      	add	x2, x25, #0x158
    1a20:      	mov	w1, #0x4                // =4
    1a24:      	blr	x21
    1a28:      	mov	w21, #0x5ea0            // =24224
    1a2c:      	mov	w29, #0x10              // =16
    1a30:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    1a34:      	ldr	x0, [sp, #0x28]
    1a38:      	add	x2, x25, #0x38
    1a3c:      	mov	w8, #0x4                // =4
    1a40:      	mov	w1, #0x4                // =4
    1a44:      	mov	x21, x22
    1a48:      	mov	w22, #0x4               // =4
    1a4c:      	blr	x8
    1a50:      	ldr	x23, [sp, #0x30]
    1a54:      	add	x2, x25, #0x3c
    1a58:      	mov	w8, #0x4                // =4
    1a5c:      	mov	w1, #0x4                // =4
    1a60:      	add	x0, x23, #0xa0
    1a64:      	blr	x8
    1a68:      	add	x0, x23, #0xa4
    1a6c:      	add	x2, x25, #0x40
    1a70:      	mov	w8, #0x4                // =4
    1a74:      	mov	w1, #0x4                // =4
    1a78:      	blr	x8
    1a7c:      	add	x0, x23, #0xa8
    1a80:      	add	x2, x25, #0x44
    1a84:      	mov	w8, #0x4                // =4
    1a88:      	mov	w1, #0x4                // =4
    1a8c:      	blr	x8
    1a90:      	add	x0, x23, #0xac
    1a94:      	add	x2, x25, #0x80
    1a98:      	mov	w8, #0x10               // =16
    1a9c:      	mov	w1, #0x10               // =16
    1aa0:      	blr	x22
    1aa4:      	mov	x22, x21
    1aa8:      	mov	w21, #0x5ea0            // =24224
    1aac:      	mov	w29, #0x20              // =32
    1ab0:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    1ab4:      	ldr	x0, [sp, #0x28]
    1ab8:      	mov	w8, #0x4                // =4
    1abc:      	mov	w1, #0x4                // =4
    1ac0:      	mov	x2, x25
    1ac4:      	mov	w21, #0x4               // =4
    1ac8:      	blr	x8
    1acc:      	ldr	x23, [sp, #0x30]
    1ad0:      	add	x2, x25, #0x4
    1ad4:      	mov	w8, #0x4                // =4
    1ad8:      	mov	w1, #0x4                // =4
    1adc:      	add	x0, x23, #0xa0
    1ae0:      	blr	x8
    1ae4:      	add	x0, x23, #0xa4
    1ae8:      	add	x2, x25, #0x30
    1aec:      	mov	w8, #0x10               // =16
    1af0:      	b	0x1b70 <generic_retkprobe_event+0x1b70>
    1af4:      	add	x2, x25, #0x4
    1af8:      	add	x8, sp, #0xa8
    1afc:      	mov	w9, #0x4                // =4
    1b00:      	add	x0, sp, #0xa8
    1b04:      	mov	w1, #0x4                // =4
    1b08:      	mov	w21, #0x4               // =4
    1b0c:      	blr	x9
    1b10:      	ldr	w8, [sp, #0xa8]
    1b14:      	ldr	x23, [sp, #0x30]
    1b18:      	add	x2, x25, #0xc
    1b1c:      	add	x0, sp, #0xa8
    1b20:      	mov	w1, #0x4                // =4
    1b24:      	str	w8, [x23, #0x9c]
    1b28:      	add	x8, sp, #0xa8
    1b2c:      	blr	x21
    1b30:      	ldr	w8, [sp, #0xa8]
    1b34:      	add	x2, x25, #0x50
    1b38:      	add	x9, sp, #0xa8
    1b3c:      	mov	w10, #0x2d              // =45
    1b40:      	str	w8, [x23, #0xa0]
    1b44:      	mov	w8, #0x8                // =8
    1b48:      	add	x0, sp, #0xa8
    1b4c:      	mov	w1, #0x8                // =8
    1b50:      	mov	w21, #0x2d              // =45
    1b54:      	blr	x10
    1b58:      	ldr	x8, [sp, #0xa8]
    1b5c:      	add	x0, x23, #0xa4
    1b60:      	mov	w9, #0x10               // =16
    1b64:      	add	x8, x8, #0x3f8
    1b68:      	ldr	x8, [sp, #0xa8]
    1b6c:      	add	x2, x8, #0x3f8
    1b70:      	mov	w1, #0x10               // =16
    1b74:      	blr	x21
    1b78:      	mov	w21, #0x5ea0            // =24224
    1b7c:      	mov	w29, #0x18              // =24
    1b80:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    1b84:      	ldr	x11, [sp, #0x28]
    1b88:      	mov	w8, #0x8                // =8
    1b8c:      	mov	w9, #0x4                // =4
    1b90:      	add	x10, sp, #0xa8
    1b94:      	stp	xzr, xzr, [x11, #0x40]
    1b98:      	add	x0, sp, #0xa8
    1b9c:      	stp	xzr, xzr, [x11, #0x30]
    1ba0:      	stp	xzr, xzr, [x11, #0x20]
    1ba4:      	mov	w1, #0x8                // =8
    1ba8:      	mov	x2, x25
    1bac:      	stp	xzr, xzr, [x11, #0x10]
    1bb0:      	stp	xzr, xzr, [x11]
    1bb4:      	blr	x9
    1bb8:      	mov	x29, xzr
    1bbc:      	cbnz	x0, 0xdd4 <generic_retkprobe_event+0xdd4>
    1bc0:      	ldr	x8, [sp, #0x30]
    1bc4:      	mov	w9, #0x3f               // =63
    1bc8:      	mov	w10, #0x2d              // =45
    1bcc:      	mov	w1, #0x3f               // =63
    1bd0:      	mov	x23, x22
    1bd4:      	add	x0, x8, #0xac
    1bd8:      	ldr	x8, [sp, #0xa8]
    1bdc:      	ldr	x2, [sp, #0xa8]
    1be0:      	blr	x10
    1be4:      	tbnz	x0, #0x3f, 0x2214 <generic_retkprobe_event+0x2214>
    1be8:      	add	x2, x25, #0x8
    1bec:      	mov	w21, #0x8               // =8
    1bf0:      	add	x8, sp, #0xf8
    1bf4:      	mov	w9, #0x4                // =4
    1bf8:      	add	x0, sp, #0xf8
    1bfc:      	mov	w1, #0x8                // =8
    1c00:      	mov	w22, #0x4               // =4
    1c04:      	blr	x9
    1c08:      	ldr	x8, [sp, #0x30]
    1c0c:      	add	x10, sp, #0xf0
    1c10:      	mov	w9, #0x4                // =4
    1c14:      	mov	w1, #0x8                // =8
    1c18:      	add	x0, x8, #0xa4
    1c1c:      	ldr	x8, [x10, #0x8]
    1c20:      	add	x8, x8, #0x360
    1c24:      	ldr	x8, [x10, #0x8]
    1c28:      	add	x2, x8, #0x360
    1c2c:      	blr	x9
    1c30:      	add	x2, x25, #0x58
    1c34:      	add	x8, sp, #0xf8
    1c38:      	add	x0, sp, #0xf8
    1c3c:      	mov	w1, #0x4                // =4
    1c40:      	blr	x22
    1c44:      	cbnz	x0, 0x1c5c <generic_retkprobe_event+0x1c5c>
    1c48:      	ldr	w8, [sp, #0xf8]
    1c4c:      	ldr	x9, [sp, #0x28]
    1c50:      	cmp	w8, #0x0
    1c54:      	cset	w8, ne
    1c58:      	str	w8, [x9]
    1c5c:      	mov	w29, #0x50              // =80
    1c60:      	mov	x22, x23
    1c64:      	b	0x2208 <generic_retkprobe_event+0x2208>
    1c68:      	mov	x29, #-0x1              // =-1
    1c6c:      	b	0x2144 <generic_retkprobe_event+0x2144>
    1c70:      	add	x2, x22, #0x10
    1c74:      	mov	w21, #0x8               // =8
    1c78:      	add	x8, sp, #0xf8
    1c7c:      	mov	w9, #0x4                // =4
    1c80:      	add	x0, sp, #0xf8
    1c84:      	mov	w1, #0x8                // =8
    1c88:      	mov	w24, #0x4               // =4
    1c8c:      	blr	x9
    1c90:      	add	x2, x22, #0x18
    1c94:      	add	x8, sp, #0x80
    1c98:      	mov	w9, #0x4                // =4
    1c9c:      	add	x0, sp, #0x80
    1ca0:      	mov	w1, #0x8                // =8
    1ca4:      	blr	x9
    1ca8:      	ldr	x21, [sp, #0x80]
    1cac:      	ldr	x2, [x29, #0x8]
    1cb0:      	mov	w8, #0xfff              // =4095
    1cb4:      	add	x0, x23, #0xa4
    1cb8:      	cmp	x21, #0xfff
    1cbc:      	csel	x22, x21, x8, lo
    1cc0:      	mov	w1, w22
    1cc4:      	blr	x24
    1cc8:      	tbnz	w0, #0x1f, 0x1cd8 <generic_retkprobe_event+0x1cd8>
    1ccc:      	stp	w21, w22, [x23, #0x9c]
    1cd0:      	add	x29, x22, #0x8
    1cd4:      	b	0x1ce4 <generic_retkprobe_event+0x1ce4>
    1cd8:      	mov	w8, #-0x2               // =-2
    1cdc:      	mov	w29, #0x4               // =4
    1ce0:      	str	w8, [x23, #0x9c]
    1ce4:      	mov	x22, x25
    1ce8:      	b	0x2208 <generic_retkprobe_event+0x2208>
    1cec:      	str	wzr, [sp, #0xf8]
    1cf0:      	adrp	x0, 0x1000 <generic_retkprobe_event+0x1000>
    1cf4:      	ldr	x23, [sp, #0xa8]
    1cf8:      	mov	w8, #0x1                // =1
    1cfc:      	add	x9, sp, #0xf8
    1d00:      	add	x1, sp, #0xf8
    1d04:      	ldrh	w21, [sp, #0xe8]
    1d08:      	ldr	x0, [x0]
    1d0c:      	add	x22, x23, x21
    1d10:      	blr	x8
    1d14:      	cbz	x0, 0x27b0 <generic_retkprobe_event+0x27b0>
    1d18:      	mov	w8, #0xff               // =255
    1d1c:      	strh	w21, [x0]
    1d20:      	strb	wzr, [x0, #0x7]
    1d24:      	add	x29, x0, #0x6
    1d28:      	add	x2, x22, #0x6
    1d2c:      	mov	w9, #0x4                // =4
    1d30:      	strb	w8, [x0, #0x5]
    1d34:      	mov	w8, #0x1                // =1
    1d38:      	mov	x25, x0
    1d3c:      	mov	x0, x29
    1d40:      	mov	w1, #0x1                // =1
    1d44:      	blr	x9
    1d48:      	tbnz	x0, #0x3f, 0x27b0 <generic_retkprobe_event+0x27b0>
    1d4c:      	ldrb	w8, [x25, #0x5]
    1d50:      	cmp	w8, #0x32
    1d54:      	b.gt	0x2220 <generic_retkprobe_event+0x2220>
    1d58:      	cbz	w8, 0x2240 <generic_retkprobe_event+0x2240>
    1d5c:      	cmp	w8, #0x2b
    1d60:      	b.eq	0x2240 <generic_retkprobe_event+0x2240>
    1d64:      	cmp	w8, #0x2c
    1d68:      	b.ne	0x230c <generic_retkprobe_event+0x230c>
    1d6c:      	mov	w8, #0x8                // =8
    1d70:      	b	0x2258 <generic_retkprobe_event+0x2258>
    1d74:      	add	x2, x22, #0x48
    1d78:      	mov	w21, #0x10              // =16
    1d7c:      	mov	w8, #0x4                // =4
    1d80:      	mov	w1, #0x10               // =16
    1d84:      	mov	w25, #0x4               // =4
    1d88:      	blr	x8
    1d8c:      	add	x2, x22, #0x38
    1d90:      	mov	x0, x23
    1d94:      	mov	w1, #0x10               // =16
    1d98:      	blr	x25
    1d9c:      	ldr	x25, [sp, #0x30]
    1da0:      	add	x2, x22, #0xe
    1da4:      	mov	w21, #0x2               // =2
    1da8:      	mov	w8, #0x4                // =4
    1dac:      	mov	w1, #0x2                // =2
    1db0:      	add	x23, x22, #0xc
    1db4:      	mov	w22, #0x4               // =4
    1db8:      	add	x0, x25, #0xbc
    1dbc:      	blr	x8
    1dc0:      	add	x0, x25, #0xbe
    1dc4:      	mov	w1, #0x2                // =2
    1dc8:      	mov	x2, x23
    1dcc:      	blr	x22
    1dd0:      	ldrh	w8, [x25, #0xbe]
    1dd4:      	adrp	x0, 0x1000 <generic_retkprobe_event+0x1000>
    1dd8:      	add	x9, sp, #0xa8
    1ddc:      	add	x1, sp, #0xa8
    1de0:      	rev	w8, w8
    1de4:      	lsr	w8, w8, #16
    1de8:      	strh	w8, [x25, #0xbe]
    1dec:      	ldr	x8, [x29, #0x18]
    1df0:      	str	x8, [sp, #0xa8]
    1df4:      	mov	w8, #0x1                // =1
    1df8:      	ldr	x0, [x0]
    1dfc:      	blr	x8
    1e00:      	cbz	x0, 0x292c <generic_retkprobe_event+0x292c>
    1e04:      	ldr	w8, [x0]
    1e08:      	str	w8, [x24, #0x10]
    1e0c:      	ldr	x8, [x0, #0x8]
    1e10:      	str	x8, [x24, #0x18]
    1e14:      	ldr	w8, [x0, #0x4]
    1e18:      	str	w8, [x24, #0x7c]
    1e1c:      	b	0x292c <generic_retkprobe_event+0x292c>
    1e20:      	stur	xzr, [x23, #0x9c]
    1e24:      	mov	w29, #0x8               // =8
    1e28:      	mov	x22, x25
    1e2c:      	mov	w21, #0x5ea0            // =24224
    1e30:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    1e34:      	mov	w21, #-0x2              // =-2
    1e38:      	ldr	x22, [sp, #0x18]
    1e3c:      	str	w21, [x23, #0x9c]
    1e40:      	b	0x2208 <generic_retkprobe_event+0x2208>
    1e44:      	ldr	x24, [sp, #0x30]
    1e48:      	add	x2, x22, #0x8
    1e4c:      	mov	w8, #0x10               // =16
    1e50:      	mov	w9, #0x4                // =4
    1e54:      	mov	w1, #0x10               // =16
    1e58:      	mov	w21, #0x4               // =4
    1e5c:      	add	x0, x24, #0xa4
    1e60:      	blr	x9
    1e64:      	add	x0, x24, #0x9e
    1e68:      	add	x2, x22, #0x2
    1e6c:      	mov	w8, #0x2                // =2
    1e70:      	mov	w1, #0x2                // =2
    1e74:      	blr	x21
    1e78:      	ldr	x9, [sp, #0x30]
    1e7c:      	ldr	x19, [sp, #0x50]
    1e80:      	mov	w21, #0x5ea0            // =24224
    1e84:      	ldrh	w8, [x9, #0x9e]
    1e88:      	rev	w8, w8
    1e8c:      	lsr	w8, w8, #16
    1e90:      	strh	w8, [x9, #0x9e]
    1e94:      	mov	w29, #0x18              // =24
    1e98:      	mov	x22, x23
    1e9c:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    1ea0:      	ldr	x8, [sp, #0x58]
    1ea4:      	mov	w9, #0x4                // =4
    1ea8:      	ldr	x1, [sp, #0x40]
    1eac:      	add	x22, x22, x8
    1eb0:      	and	x8, x22, #0x3fff
    1eb4:      	add	x0, x24, x8
    1eb8:      	ldr	x8, [sp, #0xa8]
    1ebc:      	ldr	x2, [sp, #0xa8]
    1ec0:      	blr	x9
    1ec4:      	tbnz	w0, #0x1f, 0x2110 <generic_retkprobe_event+0x2110>
    1ec8:      	ldr	x8, [sp, #0x40]
    1ecc:      	add	x29, x8, x29
    1ed0:      	cbz	x21, 0x1edc <generic_retkprobe_event+0x1edc>
    1ed4:      	subs	x21, x21, x23
    1ed8:      	b.eq	0x2108 <generic_retkprobe_event+0x2108>
    1edc:      	ldr	x8, [sp, #0x60]
    1ee0:      	ldr	x19, [sp, #0x50]
    1ee4:      	cmp	x8, #0x3
    1ee8:      	b.eq	0x318 <generic_retkprobe_event+0x318>
    1eec:      	ldr	x8, [sp, #0x118]
    1ef0:      	mov	w9, #0x4                // =4
    1ef4:      	add	x10, sp, #0xa8
    1ef8:      	add	x0, sp, #0xa8
    1efc:      	mov	w1, #0x10               // =16
    1f00:      	add	x2, x8, #0x30
    1f04:      	mov	w8, #0x10               // =16
    1f08:      	blr	x9
    1f0c:      	tbnz	w0, #0x1f, 0x2110 <generic_retkprobe_event+0x2110>
    1f10:      	ldr	x8, [sp, #0xb0]
    1f14:      	cmp	x8, x21
    1f18:      	csel	x23, x8, x21, lo
    1f1c:      	cmp	x21, #0x0
    1f20:      	csel	x8, x8, x23, eq
    1f24:      	cmp	x8, #0xffe
    1f28:      	str	x8, [sp, #0x58]
    1f2c:      	b.hi	0x108c <generic_retkprobe_event+0x108c>
    1f30:      	ldr	x8, [sp, #0x40]
    1f34:      	mov	w9, #0x4                // =4
    1f38:      	ldr	x1, [sp, #0x58]
    1f3c:      	add	x22, x8, x22
    1f40:      	and	x8, x22, #0x3fff
    1f44:      	add	x0, x24, x8
    1f48:      	ldr	x8, [sp, #0xa8]
    1f4c:      	ldr	x2, [sp, #0xa8]
    1f50:      	blr	x9
    1f54:      	tbnz	w0, #0x1f, 0x2110 <generic_retkprobe_event+0x2110>
    1f58:      	ldr	x8, [sp, #0x58]
    1f5c:      	add	x29, x8, x29
    1f60:      	cbz	x21, 0x1f6c <generic_retkprobe_event+0x1f6c>
    1f64:      	subs	x21, x21, x23
    1f68:      	b.eq	0x2108 <generic_retkprobe_event+0x2108>
    1f6c:      	ldr	x8, [sp, #0x60]
    1f70:      	ldr	x19, [sp, #0x50]
    1f74:      	cmp	x8, #0x5
    1f78:      	b.lo	0x318 <generic_retkprobe_event+0x318>
    1f7c:      	ldr	x8, [sp, #0x118]
    1f80:      	mov	w9, #0x4                // =4
    1f84:      	add	x10, sp, #0xa8
    1f88:      	add	x0, sp, #0xa8
    1f8c:      	mov	w1, #0x10               // =16
    1f90:      	add	x2, x8, #0x40
    1f94:      	mov	w8, #0x10               // =16
    1f98:      	blr	x9
    1f9c:      	tbnz	w0, #0x1f, 0x2110 <generic_retkprobe_event+0x2110>
    1fa0:      	ldr	x8, [sp, #0xb0]
    1fa4:      	cmp	x8, x21
    1fa8:      	csel	x23, x8, x21, lo
    1fac:      	cmp	x21, #0x0
    1fb0:      	csel	x8, x8, x23, eq
    1fb4:      	cmp	x8, #0xffe
    1fb8:      	str	x8, [sp, #0x40]
    1fbc:      	b.hi	0x108c <generic_retkprobe_event+0x108c>
    1fc0:      	ldr	x8, [sp, #0x58]
    1fc4:      	mov	w9, #0x4                // =4
    1fc8:      	ldr	x1, [sp, #0x40]
    1fcc:      	add	x22, x8, x22
    1fd0:      	and	x8, x22, #0x3fff
    1fd4:      	add	x0, x24, x8
    1fd8:      	ldr	x8, [sp, #0xa8]
    1fdc:      	ldr	x2, [sp, #0xa8]
    1fe0:      	blr	x9
    1fe4:      	tbnz	w0, #0x1f, 0x2110 <generic_retkprobe_event+0x2110>
    1fe8:      	ldr	x8, [sp, #0x40]
    1fec:      	add	x29, x8, x29
    1ff0:      	cbz	x21, 0x1ffc <generic_retkprobe_event+0x1ffc>
    1ff4:      	subs	x21, x21, x23
    1ff8:      	b.eq	0x2108 <generic_retkprobe_event+0x2108>
    1ffc:      	ldr	x8, [sp, #0x60]
    2000:      	ldr	x19, [sp, #0x50]
    2004:      	cmp	x8, #0x5
    2008:      	b.eq	0x318 <generic_retkprobe_event+0x318>
    200c:      	ldr	x8, [sp, #0x118]
    2010:      	mov	w9, #0x4                // =4
    2014:      	add	x10, sp, #0xa8
    2018:      	add	x0, sp, #0xa8
    201c:      	mov	w1, #0x10               // =16
    2020:      	add	x2, x8, #0x50
    2024:      	mov	w8, #0x10               // =16
    2028:      	blr	x9
    202c:      	tbnz	w0, #0x1f, 0x2110 <generic_retkprobe_event+0x2110>
    2030:      	ldr	x8, [sp, #0xb0]
    2034:      	cmp	x8, x21
    2038:      	csel	x23, x8, x21, lo
    203c:      	cmp	x21, #0x0
    2040:      	csel	x8, x8, x23, eq
    2044:      	cmp	x8, #0xffe
    2048:      	str	x8, [sp, #0x58]
    204c:      	b.hi	0x108c <generic_retkprobe_event+0x108c>
    2050:      	ldr	x8, [sp, #0x40]
    2054:      	mov	w9, #0x4                // =4
    2058:      	ldr	x1, [sp, #0x58]
    205c:      	add	x22, x8, x22
    2060:      	and	x8, x22, #0x3fff
    2064:      	add	x0, x24, x8
    2068:      	ldr	x8, [sp, #0xa8]
    206c:      	ldr	x2, [sp, #0xa8]
    2070:      	blr	x9
    2074:      	tbnz	w0, #0x1f, 0x2110 <generic_retkprobe_event+0x2110>
    2078:      	ldr	x8, [sp, #0x58]
    207c:      	add	x29, x8, x29
    2080:      	cbz	x21, 0x208c <generic_retkprobe_event+0x208c>
    2084:      	subs	x21, x21, x23
    2088:      	b.eq	0x2108 <generic_retkprobe_event+0x2108>
    208c:      	ldr	x8, [sp, #0x60]
    2090:      	ldr	x19, [sp, #0x50]
    2094:      	cmp	x8, #0x7
    2098:      	b.lo	0x318 <generic_retkprobe_event+0x318>
    209c:      	ldr	x8, [sp, #0x118]
    20a0:      	mov	w9, #0x4                // =4
    20a4:      	add	x10, sp, #0xa8
    20a8:      	add	x0, sp, #0xa8
    20ac:      	mov	w1, #0x10               // =16
    20b0:      	add	x2, x8, #0x60
    20b4:      	mov	w8, #0x10               // =16
    20b8:      	blr	x9
    20bc:      	tbnz	w0, #0x1f, 0x2110 <generic_retkprobe_event+0x2110>
    20c0:      	ldr	x8, [sp, #0xb0]
    20c4:      	cmp	x8, x21
    20c8:      	csel	x9, x8, x21, lo
    20cc:      	cmp	x21, #0x0
    20d0:      	csel	x21, x8, x9, eq
    20d4:      	cmp	x21, #0xffe
    20d8:      	b.hi	0x108c <generic_retkprobe_event+0x108c>
    20dc:      	ldr	x8, [sp, #0x58]
    20e0:      	mov	w9, #0x4                // =4
    20e4:      	mov	w1, w21
    20e8:      	add	x8, x8, x22
    20ec:      	and	x8, x8, #0x3fff
    20f0:      	add	x0, x24, x8
    20f4:      	ldr	x8, [sp, #0xa8]
    20f8:      	ldr	x2, [sp, #0xa8]
    20fc:      	blr	x9
    2100:      	tbnz	w0, #0x1f, 0x2110 <generic_retkprobe_event+0x2110>
    2104:      	add	x29, x21, x29
    2108:      	ldr	x19, [sp, #0x50]
    210c:      	b	0x318 <generic_retkprobe_event+0x318>
    2110:      	mov	w8, #-0x2               // =-2
    2114:      	ldp	x29, x19, [sp, #0x48]
    2118:      	str	w8, [x24, x25]
    211c:      	b	0x334 <generic_retkprobe_event+0x334>
    2120:      	add	x2, x22, #0x3
    2124:      	mov	w21, #0x6b              // =107
    2128:      	mov	w8, #0x71               // =113
    212c:      	mov	w1, #0x6b               // =107
    2130:      	blr	x8
    2134:      	tbnz	w0, #0x1f, 0x2140 <generic_retkprobe_event+0x2140>
    2138:      	ldr	x8, [sp, #0x30]
    213c:      	strb	w21, [x8, #0x9f]
    2140:      	mov	w29, #0x70              // =112
    2144:      	mov	x22, x24
    2148:      	mov	w21, #0x5ea0            // =24224
    214c:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    2150:      	ldr	x0, [sp, #0x28]
    2154:      	add	x2, x22, #0x48
    2158:      	mov	w21, #0x10              // =16
    215c:      	mov	w8, #0x4                // =4
    2160:      	mov	w1, #0x10               // =16
    2164:      	mov	w25, #0x4               // =4
    2168:      	blr	x8
    216c:      	add	x2, x22, #0x38
    2170:      	mov	x0, x23
    2174:      	mov	w1, #0x10               // =16
    2178:      	blr	x25
    217c:      	ldr	x25, [sp, #0x30]
    2180:      	add	x2, x22, #0xe
    2184:      	mov	w21, #0x2               // =2
    2188:      	mov	w8, #0x4                // =4
    218c:      	mov	w1, #0x2                // =2
    2190:      	add	x23, x22, #0xc
    2194:      	mov	w22, #0x4               // =4
    2198:      	add	x0, x25, #0xbc
    219c:      	blr	x8
    21a0:      	add	x0, x25, #0xbe
    21a4:      	mov	w1, #0x2                // =2
    21a8:      	mov	x2, x23
    21ac:      	blr	x22
    21b0:      	ldrh	w8, [x25, #0xbe]
    21b4:      	rev	w8, w8
    21b8:      	lsr	w8, w8, #16
    21bc:      	strh	w8, [x25, #0xbe]
    21c0:      	ldr	x8, [sp, #0x30]
    21c4:      	adrp	x0, 0x2000 <generic_retkprobe_event+0x2000>
    21c8:      	add	x9, sp, #0xa8
    21cc:      	add	x1, sp, #0xa8
    21d0:      	ldur	x8, [x8, #0xc4]
    21d4:      	str	x8, [sp, #0xa8]
    21d8:      	mov	w8, #0x1                // =1
    21dc:      	ldr	x0, [x0]
    21e0:      	blr	x8
    21e4:      	cbz	x0, 0x2200 <generic_retkprobe_event+0x2200>
    21e8:      	ldr	w8, [x0]
    21ec:      	str	w8, [x24, #0x10]
    21f0:      	ldr	x8, [x0, #0x8]
    21f4:      	str	x8, [x24, #0x18]
    21f8:      	ldr	w8, [x0, #0x4]
    21fc:      	str	w8, [x24, #0x7c]
    2200:      	ldr	x22, [sp, #0x18]
    2204:      	mov	w29, #0x40              // =64
    2208:      	ldr	x19, [sp, #0x50]
    220c:      	mov	w21, #0x5ea0            // =24224
    2210:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    2214:      	mov	x29, xzr
    2218:      	mov	x22, x23
    221c:      	b	0x2208 <generic_retkprobe_event+0x2208>
    2220:      	cmp	w8, #0x33
    2224:      	b.eq	0x224c <generic_retkprobe_event+0x224c>
    2228:      	cmp	w8, #0x3c
    222c:      	b.eq	0x2240 <generic_retkprobe_event+0x2240>
    2230:      	cmp	w8, #0xff
    2234:      	b.ne	0x230c <generic_retkprobe_event+0x230c>
    2238:      	mov	w8, #0x28               // =40
    223c:      	b	0x2258 <generic_retkprobe_event+0x2258>
    2240:      	ldrb	w8, [x25, #0x7]
    2244:      	lsl	w8, w8, #3
    2248:      	b	0x2254 <generic_retkprobe_event+0x2254>
    224c:      	ldrb	w8, [x25, #0x7]
    2250:      	lsl	w8, w8, #2
    2254:      	add	w8, w8, #0x8
    2258:      	strh	w8, [x25, #0x2]
    225c:      	ldrh	w9, [x25]
    2260:      	add	w9, w9, w8
    2264:      	ldrb	w8, [x25, #0x6]
    2268:      	strh	w9, [x25]
    226c:      	cmp	w8, #0x3c
    2270:      	b.hi	0x2328 <generic_retkprobe_event+0x2328>
    2274:      	mov	x19, #0x1               // =1
    2278:      	mov	w10, #0x1               // =1
    227c:      	movk	x19, #0x1800, lsl #32
    2280:      	lsl	x10, x10, x8
    2284:      	movk	x19, #0x1008, lsl #48
    2288:      	tst	x10, x19
    228c:      	b.eq	0x2328 <generic_retkprobe_event+0x2328>
    2290:      	strb	w8, [x25, #0x5]
    2294:      	add	x8, x23, w9, uxth
    2298:      	mov	w9, #0x2                // =2
    229c:      	mov	w10, #0x4               // =4
    22a0:      	mov	x0, x29
    22a4:      	mov	w1, #0x2                // =2
    22a8:      	ldrh	w8, [x25]
    22ac:      	add	x2, x23, x8
    22b0:      	blr	x10
    22b4:      	tbnz	x0, #0x3f, 0x27b0 <generic_retkprobe_event+0x27b0>
    22b8:      	ldrb	w8, [x25, #0x5]
    22bc:      	cmp	w8, #0x32
    22c0:      	b.gt	0x22e0 <generic_retkprobe_event+0x22e0>
    22c4:      	cbz	w8, 0x2300 <generic_retkprobe_event+0x2300>
    22c8:      	cmp	w8, #0x2b
    22cc:      	b.eq	0x2300 <generic_retkprobe_event+0x2300>
    22d0:      	cmp	w8, #0x2c
    22d4:      	b.ne	0x23e4 <generic_retkprobe_event+0x23e4>
    22d8:      	mov	w8, #0x8                // =8
    22dc:      	b	0x233c <generic_retkprobe_event+0x233c>
    22e0:      	cmp	w8, #0x33
    22e4:      	b.eq	0x2330 <generic_retkprobe_event+0x2330>
    22e8:      	cmp	w8, #0x3c
    22ec:      	b.eq	0x2300 <generic_retkprobe_event+0x2300>
    22f0:      	cmp	w8, #0xff
    22f4:      	b.ne	0x23e4 <generic_retkprobe_event+0x23e4>
    22f8:      	mov	w8, #0x28               // =40
    22fc:      	b	0x233c <generic_retkprobe_event+0x233c>
    2300:      	ldrb	w8, [x25, #0x7]
    2304:      	lsl	w8, w8, #3
    2308:      	b	0x2338 <generic_retkprobe_event+0x2338>
    230c:      	ldrh	w8, [x25, #0x2]
    2310:      	ldrh	w9, [x25]
    2314:      	add	w9, w9, w8
    2318:      	ldrb	w8, [x25, #0x6]
    231c:      	strh	w9, [x25]
    2320:      	cmp	w8, #0x3c
    2324:      	b.ls	0x2274 <generic_retkprobe_event+0x2274>
    2328:      	strh	w9, [sp, #0xa0]
    232c:      	b	0x27b4 <generic_retkprobe_event+0x27b4>
    2330:      	ldrb	w8, [x25, #0x7]
    2334:      	lsl	w8, w8, #2
    2338:      	add	w8, w8, #0x8
    233c:      	strh	w8, [x25, #0x2]
    2340:      	ldrh	w9, [x25]
    2344:      	add	w9, w9, w8
    2348:      	ldrb	w8, [x25, #0x6]
    234c:      	strh	w9, [x25]
    2350:      	cmp	w8, #0x3c
    2354:      	b.hi	0x2958 <generic_retkprobe_event+0x2958>
    2358:      	mov	w10, #0x1               // =1
    235c:      	lsl	x10, x10, x8
    2360:      	tst	x10, x19
    2364:      	b.eq	0x2958 <generic_retkprobe_event+0x2958>
    2368:      	strb	w8, [x25, #0x5]
    236c:      	add	x8, x23, w9, uxth
    2370:      	mov	w9, #0x2                // =2
    2374:      	mov	w10, #0x4               // =4
    2378:      	mov	x0, x29
    237c:      	mov	w1, #0x2                // =2
    2380:      	ldrh	w8, [x25]
    2384:      	add	x2, x23, x8
    2388:      	blr	x10
    238c:      	tbnz	x0, #0x3f, 0x27b0 <generic_retkprobe_event+0x27b0>
    2390:      	ldrb	w8, [x25, #0x5]
    2394:      	cmp	w8, #0x32
    2398:      	b.gt	0x23b8 <generic_retkprobe_event+0x23b8>
    239c:      	cbz	w8, 0x23d8 <generic_retkprobe_event+0x23d8>
    23a0:      	cmp	w8, #0x2b
    23a4:      	b.eq	0x23d8 <generic_retkprobe_event+0x23d8>
    23a8:      	cmp	w8, #0x2c
    23ac:      	b.ne	0x24b8 <generic_retkprobe_event+0x24b8>
    23b0:      	mov	w8, #0x8                // =8
    23b4:      	b	0x2410 <generic_retkprobe_event+0x2410>
    23b8:      	cmp	w8, #0x33
    23bc:      	b.eq	0x2404 <generic_retkprobe_event+0x2404>
    23c0:      	cmp	w8, #0x3c
    23c4:      	b.eq	0x23d8 <generic_retkprobe_event+0x23d8>
    23c8:      	cmp	w8, #0xff
    23cc:      	b.ne	0x24b8 <generic_retkprobe_event+0x24b8>
    23d0:      	mov	w8, #0x28               // =40
    23d4:      	b	0x2410 <generic_retkprobe_event+0x2410>
    23d8:      	ldrb	w8, [x25, #0x7]
    23dc:      	lsl	w8, w8, #3
    23e0:      	b	0x240c <generic_retkprobe_event+0x240c>
    23e4:      	ldrh	w8, [x25, #0x2]
    23e8:      	ldrh	w9, [x25]
    23ec:      	add	w9, w9, w8
    23f0:      	ldrb	w8, [x25, #0x6]
    23f4:      	strh	w9, [x25]
    23f8:      	cmp	w8, #0x3c
    23fc:      	b.ls	0x2358 <generic_retkprobe_event+0x2358>
    2400:      	b	0x2958 <generic_retkprobe_event+0x2958>
    2404:      	ldrb	w8, [x25, #0x7]
    2408:      	lsl	w8, w8, #2
    240c:      	add	w8, w8, #0x8
    2410:      	strh	w8, [x25, #0x2]
    2414:      	ldrh	w9, [x25]
    2418:      	add	w9, w9, w8
    241c:      	ldrb	w8, [x25, #0x6]
    2420:      	strh	w9, [x25]
    2424:      	cmp	w8, #0x3c
    2428:      	b.hi	0x2958 <generic_retkprobe_event+0x2958>
    242c:      	mov	w10, #0x1               // =1
    2430:      	lsl	x10, x10, x8
    2434:      	tst	x10, x19
    2438:      	b.eq	0x2958 <generic_retkprobe_event+0x2958>
    243c:      	strb	w8, [x25, #0x5]
    2440:      	add	x8, x23, w9, uxth
    2444:      	mov	w9, #0x2                // =2
    2448:      	mov	w10, #0x4               // =4
    244c:      	mov	x0, x29
    2450:      	mov	w1, #0x2                // =2
    2454:      	ldrh	w8, [x25]
    2458:      	add	x2, x23, x8
    245c:      	blr	x10
    2460:      	tbnz	x0, #0x3f, 0x27b0 <generic_retkprobe_event+0x27b0>
    2464:      	ldrb	w8, [x25, #0x5]
    2468:      	cmp	w8, #0x32
    246c:      	b.gt	0x248c <generic_retkprobe_event+0x248c>
    2470:      	cbz	w8, 0x24ac <generic_retkprobe_event+0x24ac>
    2474:      	cmp	w8, #0x2b
    2478:      	b.eq	0x24ac <generic_retkprobe_event+0x24ac>
    247c:      	cmp	w8, #0x2c
    2480:      	b.ne	0x258c <generic_retkprobe_event+0x258c>
    2484:      	mov	w8, #0x8                // =8
    2488:      	b	0x24e4 <generic_retkprobe_event+0x24e4>
    248c:      	cmp	w8, #0x33
    2490:      	b.eq	0x24d8 <generic_retkprobe_event+0x24d8>
    2494:      	cmp	w8, #0x3c
    2498:      	b.eq	0x24ac <generic_retkprobe_event+0x24ac>
    249c:      	cmp	w8, #0xff
    24a0:      	b.ne	0x258c <generic_retkprobe_event+0x258c>
    24a4:      	mov	w8, #0x28               // =40
    24a8:      	b	0x24e4 <generic_retkprobe_event+0x24e4>
    24ac:      	ldrb	w8, [x25, #0x7]
    24b0:      	lsl	w8, w8, #3
    24b4:      	b	0x24e0 <generic_retkprobe_event+0x24e0>
    24b8:      	ldrh	w8, [x25, #0x2]
    24bc:      	ldrh	w9, [x25]
    24c0:      	add	w9, w9, w8
    24c4:      	ldrb	w8, [x25, #0x6]
    24c8:      	strh	w9, [x25]
    24cc:      	cmp	w8, #0x3c
    24d0:      	b.ls	0x242c <generic_retkprobe_event+0x242c>
    24d4:      	b	0x2958 <generic_retkprobe_event+0x2958>
    24d8:      	ldrb	w8, [x25, #0x7]
    24dc:      	lsl	w8, w8, #2
    24e0:      	add	w8, w8, #0x8
    24e4:      	strh	w8, [x25, #0x2]
    24e8:      	ldrh	w9, [x25]
    24ec:      	add	w9, w9, w8
    24f0:      	ldrb	w8, [x25, #0x6]
    24f4:      	strh	w9, [x25]
    24f8:      	cmp	w8, #0x3c
    24fc:      	b.hi	0x2958 <generic_retkprobe_event+0x2958>
    2500:      	mov	w10, #0x1               // =1
    2504:      	lsl	x10, x10, x8
    2508:      	tst	x10, x19
    250c:      	b.eq	0x2958 <generic_retkprobe_event+0x2958>
    2510:      	strb	w8, [x25, #0x5]
    2514:      	add	x8, x23, w9, uxth
    2518:      	mov	w9, #0x2                // =2
    251c:      	mov	w10, #0x4               // =4
    2520:      	mov	x0, x29
    2524:      	mov	w1, #0x2                // =2
    2528:      	ldrh	w8, [x25]
    252c:      	add	x2, x23, x8
    2530:      	blr	x10
    2534:      	tbnz	x0, #0x3f, 0x27b0 <generic_retkprobe_event+0x27b0>
    2538:      	ldrb	w8, [x25, #0x5]
    253c:      	cmp	w8, #0x32
    2540:      	b.gt	0x2560 <generic_retkprobe_event+0x2560>
    2544:      	cbz	w8, 0x2580 <generic_retkprobe_event+0x2580>
    2548:      	cmp	w8, #0x2b
    254c:      	b.eq	0x2580 <generic_retkprobe_event+0x2580>
    2550:      	cmp	w8, #0x2c
    2554:      	b.ne	0x2660 <generic_retkprobe_event+0x2660>
    2558:      	mov	w8, #0x8                // =8
    255c:      	b	0x25b8 <generic_retkprobe_event+0x25b8>
    2560:      	cmp	w8, #0x33
    2564:      	b.eq	0x25ac <generic_retkprobe_event+0x25ac>
    2568:      	cmp	w8, #0x3c
    256c:      	b.eq	0x2580 <generic_retkprobe_event+0x2580>
    2570:      	cmp	w8, #0xff
    2574:      	b.ne	0x2660 <generic_retkprobe_event+0x2660>
    2578:      	mov	w8, #0x28               // =40
    257c:      	b	0x25b8 <generic_retkprobe_event+0x25b8>
    2580:      	ldrb	w8, [x25, #0x7]
    2584:      	lsl	w8, w8, #3
    2588:      	b	0x25b4 <generic_retkprobe_event+0x25b4>
    258c:      	ldrh	w8, [x25, #0x2]
    2590:      	ldrh	w9, [x25]
    2594:      	add	w9, w9, w8
    2598:      	ldrb	w8, [x25, #0x6]
    259c:      	strh	w9, [x25]
    25a0:      	cmp	w8, #0x3c
    25a4:      	b.ls	0x2500 <generic_retkprobe_event+0x2500>
    25a8:      	b	0x2958 <generic_retkprobe_event+0x2958>
    25ac:      	ldrb	w8, [x25, #0x7]
    25b0:      	lsl	w8, w8, #2
    25b4:      	add	w8, w8, #0x8
    25b8:      	strh	w8, [x25, #0x2]
    25bc:      	ldrh	w9, [x25]
    25c0:      	add	w9, w9, w8
    25c4:      	ldrb	w8, [x25, #0x6]
    25c8:      	strh	w9, [x25]
    25cc:      	cmp	w8, #0x3c
    25d0:      	b.hi	0x2958 <generic_retkprobe_event+0x2958>
    25d4:      	mov	w10, #0x1               // =1
    25d8:      	lsl	x10, x10, x8
    25dc:      	tst	x10, x19
    25e0:      	b.eq	0x2958 <generic_retkprobe_event+0x2958>
    25e4:      	strb	w8, [x25, #0x5]
    25e8:      	add	x8, x23, w9, uxth
    25ec:      	mov	w9, #0x2                // =2
    25f0:      	mov	w10, #0x4               // =4
    25f4:      	mov	x0, x29
    25f8:      	mov	w1, #0x2                // =2
    25fc:      	ldrh	w8, [x25]
    2600:      	add	x2, x23, x8
    2604:      	blr	x10
    2608:      	tbnz	x0, #0x3f, 0x27b0 <generic_retkprobe_event+0x27b0>
    260c:      	ldrb	w8, [x25, #0x5]
    2610:      	cmp	w8, #0x32
    2614:      	b.gt	0x2634 <generic_retkprobe_event+0x2634>
    2618:      	cbz	w8, 0x2654 <generic_retkprobe_event+0x2654>
    261c:      	cmp	w8, #0x2b
    2620:      	b.eq	0x2654 <generic_retkprobe_event+0x2654>
    2624:      	cmp	w8, #0x2c
    2628:      	b.ne	0x2734 <generic_retkprobe_event+0x2734>
    262c:      	mov	w8, #0x8                // =8
    2630:      	b	0x268c <generic_retkprobe_event+0x268c>
    2634:      	cmp	w8, #0x33
    2638:      	b.eq	0x2680 <generic_retkprobe_event+0x2680>
    263c:      	cmp	w8, #0x3c
    2640:      	b.eq	0x2654 <generic_retkprobe_event+0x2654>
    2644:      	cmp	w8, #0xff
    2648:      	b.ne	0x2734 <generic_retkprobe_event+0x2734>
    264c:      	mov	w8, #0x28               // =40
    2650:      	b	0x268c <generic_retkprobe_event+0x268c>
    2654:      	ldrb	w8, [x25, #0x7]
    2658:      	lsl	w8, w8, #3
    265c:      	b	0x2688 <generic_retkprobe_event+0x2688>
    2660:      	ldrh	w8, [x25, #0x2]
    2664:      	ldrh	w9, [x25]
    2668:      	add	w9, w9, w8
    266c:      	ldrb	w8, [x25, #0x6]
    2670:      	strh	w9, [x25]
    2674:      	cmp	w8, #0x3c
    2678:      	b.ls	0x25d4 <generic_retkprobe_event+0x25d4>
    267c:      	b	0x2958 <generic_retkprobe_event+0x2958>
    2680:      	ldrb	w8, [x25, #0x7]
    2684:      	lsl	w8, w8, #2
    2688:      	add	w8, w8, #0x8
    268c:      	strh	w8, [x25, #0x2]
    2690:      	ldrh	w9, [x25]
    2694:      	add	w9, w9, w8
    2698:      	ldrb	w8, [x25, #0x6]
    269c:      	strh	w9, [x25]
    26a0:      	cmp	w8, #0x3c
    26a4:      	b.hi	0x2958 <generic_retkprobe_event+0x2958>
    26a8:      	mov	w10, #0x1               // =1
    26ac:      	lsl	x10, x10, x8
    26b0:      	tst	x10, x19
    26b4:      	b.eq	0x2958 <generic_retkprobe_event+0x2958>
    26b8:      	strb	w8, [x25, #0x5]
    26bc:      	add	x8, x23, w9, uxth
    26c0:      	mov	w9, #0x2                // =2
    26c4:      	mov	w10, #0x4               // =4
    26c8:      	mov	x0, x29
    26cc:      	mov	w1, #0x2                // =2
    26d0:      	ldrh	w8, [x25]
    26d4:      	add	x2, x23, x8
    26d8:      	blr	x10
    26dc:      	tbnz	x0, #0x3f, 0x27b0 <generic_retkprobe_event+0x27b0>
    26e0:      	ldrb	w8, [x25, #0x5]
    26e4:      	cmp	w8, #0x32
    26e8:      	b.gt	0x2708 <generic_retkprobe_event+0x2708>
    26ec:      	cbz	w8, 0x2728 <generic_retkprobe_event+0x2728>
    26f0:      	cmp	w8, #0x2b
    26f4:      	b.eq	0x2728 <generic_retkprobe_event+0x2728>
    26f8:      	cmp	w8, #0x2c
    26fc:      	b.ne	0x293c <generic_retkprobe_event+0x293c>
    2700:      	mov	w8, #0x8                // =8
    2704:      	b	0x2760 <generic_retkprobe_event+0x2760>
    2708:      	cmp	w8, #0x33
    270c:      	b.eq	0x2754 <generic_retkprobe_event+0x2754>
    2710:      	cmp	w8, #0x3c
    2714:      	b.eq	0x2728 <generic_retkprobe_event+0x2728>
    2718:      	cmp	w8, #0xff
    271c:      	b.ne	0x293c <generic_retkprobe_event+0x293c>
    2720:      	mov	w8, #0x28               // =40
    2724:      	b	0x2760 <generic_retkprobe_event+0x2760>
    2728:      	ldrb	w8, [x25, #0x7]
    272c:      	lsl	w8, w8, #3
    2730:      	b	0x275c <generic_retkprobe_event+0x275c>
    2734:      	ldrh	w8, [x25, #0x2]
    2738:      	ldrh	w9, [x25]
    273c:      	add	w9, w9, w8
    2740:      	ldrb	w8, [x25, #0x6]
    2744:      	strh	w9, [x25]
    2748:      	cmp	w8, #0x3c
    274c:      	b.ls	0x26a8 <generic_retkprobe_event+0x26a8>
    2750:      	b	0x2958 <generic_retkprobe_event+0x2958>
    2754:      	ldrb	w8, [x25, #0x7]
    2758:      	lsl	w8, w8, #2
    275c:      	add	w8, w8, #0x8
    2760:      	strh	w8, [x25, #0x2]
    2764:      	ldrh	w9, [x25]
    2768:      	add	w9, w9, w8
    276c:      	ldrb	w8, [x25, #0x6]
    2770:      	strh	w9, [x25]
    2774:      	cmp	w8, #0x3c
    2778:      	b.hi	0x2958 <generic_retkprobe_event+0x2958>
    277c:      	mov	w10, #0x1               // =1
    2780:      	lsl	x10, x10, x8
    2784:      	tst	x10, x19
    2788:      	b.eq	0x2958 <generic_retkprobe_event+0x2958>
    278c:      	strb	w8, [x25, #0x5]
    2790:      	add	x8, x23, w9, uxth
    2794:      	mov	w9, #0x2                // =2
    2798:      	mov	w10, #0x4               // =4
    279c:      	mov	x0, x29
    27a0:      	mov	w1, #0x2                // =2
    27a4:      	ldrh	w8, [x25]
    27a8:      	add	x2, x23, x8
    27ac:      	blr	x10
    27b0:      	mov	w8, wzr
    27b4:      	ldp	x0, x25, [sp, #0x28]
    27b8:      	add	x2, x22, #0x8
    27bc:      	mov	w21, #0x10              // =16
    27c0:      	mov	w1, #0x10               // =16
    27c4:      	mov	w23, #0x4               // =4
    27c8:      	strb	w8, [sp, #0x98]
    27cc:      	strh	w8, [x25, #0xc0]
    27d0:      	mov	w8, #0xa                // =10
    27d4:      	strh	w8, [x25, #0xc2]
    27d8:      	mov	w8, #0x4                // =4
    27dc:      	blr	x8
    27e0:      	add	x0, x25, #0xac
    27e4:      	add	x2, x22, #0x18
    27e8:      	mov	w1, #0x10               // =16
    27ec:      	blr	x23
    27f0:      	ldrb	w8, [sp, #0x98]
    27f4:      	cmp	w8, #0x11
    27f8:      	b.eq	0x283c <generic_retkprobe_event+0x283c>
    27fc:      	cmp	w8, #0x6
    2800:      	b.ne	0x287c <generic_retkprobe_event+0x287c>
    2804:      	ldr	x8, [sp, #0xa8]
    2808:      	ldrh	w9, [sp, #0xa0]
    280c:      	mov	w21, #0x2               // =2
    2810:      	mov	w1, #0x2                // =2
    2814:      	mov	w23, #0x4               // =4
    2818:      	add	x22, x8, x9
    281c:      	ldr	x25, [sp, #0x30]
    2820:      	add	x0, x25, #0xbc
    2824:      	mov	w8, #0x4                // =4
    2828:      	mov	x2, x22
    282c:      	blr	x8
    2830:      	add	x0, x25, #0xbe
    2834:      	add	x2, x22, #0x2
    2838:      	b	0x2870 <generic_retkprobe_event+0x2870>
    283c:      	ldr	x8, [sp, #0xa8]
    2840:      	ldrh	w9, [sp, #0xa0]
    2844:      	mov	w21, #0x2               // =2
    2848:      	mov	w1, #0x2                // =2
    284c:      	mov	w23, #0x4               // =4
    2850:      	add	x22, x8, x9
    2854:      	ldr	x25, [sp, #0x30]
    2858:      	add	x0, x25, #0xbc
    285c:      	mov	w8, #0x4                // =4
    2860:      	mov	x2, x22
    2864:      	blr	x8
    2868:      	add	x0, x25, #0xbe
    286c:      	add	x2, x22, #0x2
    2870:      	mov	w1, #0x2                // =2
    2874:      	blr	x23
    2878:      	b	0x2884 <generic_retkprobe_event+0x2884>
    287c:      	ldr	x25, [sp, #0x30]
    2880:      	str	wzr, [x25, #0xbc]
    2884:      	ldrh	w8, [x25, #0xbc]
    2888:      	add	x2, x24, #0xe0
    288c:      	mov	w9, #0x4                // =4
    2890:      	add	x10, sp, #0xf8
    2894:      	add	x0, sp, #0xf8
    2898:      	mov	w1, #0x8                // =8
    289c:      	rev	w8, w8
    28a0:      	lsr	w8, w8, #16
    28a4:      	strh	w8, [x25, #0xbc]
    28a8:      	ldrh	w8, [x25, #0xbe]
    28ac:      	rev	w8, w8
    28b0:      	lsr	w8, w8, #16
    28b4:      	strh	w8, [x25, #0xbe]
    28b8:      	mov	w8, #0x8                // =8
    28bc:      	blr	x9
    28c0:      	add	x19, sp, #0xf0
    28c4:      	ldr	x8, [x19, #0x8]
    28c8:      	cbz	x8, 0x2928 <generic_retkprobe_event+0x2928>
    28cc:      	add	x8, x8, #0x5
    28d0:      	mov	w9, #0x8                // =8
    28d4:      	add	x10, sp, #0x80
    28d8:      	mov	w11, #0x4               // =4
    28dc:      	ldr	x8, [x19, #0x8]
    28e0:      	add	x0, sp, #0x80
    28e4:      	mov	w1, #0x8                // =8
    28e8:      	mov	w21, #0x4               // =4
    28ec:      	add	x2, x8, #0x5
    28f0:      	blr	x11
    28f4:      	ldr	x8, [x19, #0x8]
    28f8:      	ldr	x9, [sp, #0x80]
    28fc:      	mov	w1, #0x4                // =4
    2900:      	add	x22, x8, x9, lsl #3
    2904:      	ldr	x23, [sp, #0x30]
    2908:      	add	x0, x23, #0xd4
    290c:      	mov	w8, #0x4                // =4
    2910:      	add	x2, x22, #0x44
    2914:      	blr	x8
    2918:      	add	x0, x23, #0xd8
    291c:      	add	x2, x22, #0x45
    2920:      	mov	w1, #0x4                // =4
    2924:      	blr	x21
    2928:      	ldr	x19, [sp, #0x50]
    292c:      	ldr	x22, [sp, #0x18]
    2930:      	mov	w29, #0x40              // =64
    2934:      	mov	w21, #0x5ea0            // =24224
    2938:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    293c:      	ldrh	w8, [x25, #0x2]
    2940:      	ldrh	w9, [x25]
    2944:      	add	w9, w9, w8
    2948:      	ldrb	w8, [x25, #0x6]
    294c:      	strh	w9, [x25]
    2950:      	cmp	w8, #0x3c
    2954:      	b.ls	0x277c <generic_retkprobe_event+0x277c>
    2958:      	strh	w9, [sp, #0xa0]
    295c:      	b	0x27b4 <generic_retkprobe_event+0x27b4>
