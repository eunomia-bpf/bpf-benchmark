
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/bcc/vfsstat.native.o:	file format elf64-littleaarch64

Disassembly of section kprobe/vfs_read:

0000000000000000 <kprobe_vfs_read>:
       0:      	adrp	x8, 0x0 <kprobe_vfs_read>
       4:      	ldr	x8, [x8]
       8:      	ldxr	x9, [x8]
       c:      	add	x9, x9, #0x1
      10:      	stxr	w10, x9, [x8]
      14:      	cbnz	w10, 0x8 <kprobe_vfs_read+0x8>
      18:      	mov	w0, wzr
      1c:      	ret

Disassembly of section kprobe/vfs_write:

0000000000000000 <kprobe_vfs_write>:
       0:      	adrp	x8, 0x0 <kprobe_vfs_write>
       4:      	ldr	x8, [x8]
       8:      	add	x8, x8, #0x8
       c:      	ldxr	x9, [x8]
      10:      	add	x9, x9, #0x1
      14:      	stxr	w10, x9, [x8]
      18:      	cbnz	w10, 0xc <kprobe_vfs_write+0xc>
      1c:      	mov	w0, wzr
      20:      	ret

Disassembly of section kprobe/vfs_fsync:

0000000000000000 <kprobe_vfs_fsync>:
       0:      	adrp	x8, 0x0 <kprobe_vfs_fsync>
       4:      	ldr	x8, [x8]
       8:      	add	x8, x8, #0x10
       c:      	ldxr	x9, [x8]
      10:      	add	x9, x9, #0x1
      14:      	stxr	w10, x9, [x8]
      18:      	cbnz	w10, 0xc <kprobe_vfs_fsync+0xc>
      1c:      	mov	w0, wzr
      20:      	ret

Disassembly of section kprobe/vfs_open:

0000000000000000 <kprobe_vfs_open>:
       0:      	adrp	x8, 0x0 <kprobe_vfs_open>
       4:      	ldr	x8, [x8]
       8:      	add	x8, x8, #0x18
       c:      	ldxr	x9, [x8]
      10:      	add	x9, x9, #0x1
      14:      	stxr	w10, x9, [x8]
      18:      	cbnz	w10, 0xc <kprobe_vfs_open+0xc>
      1c:      	mov	w0, wzr
      20:      	ret

Disassembly of section kprobe/vfs_create:

0000000000000000 <kprobe_vfs_create>:
       0:      	adrp	x8, 0x0 <kprobe_vfs_create>
       4:      	ldr	x8, [x8]
       8:      	add	x8, x8, #0x20
       c:      	ldxr	x9, [x8]
      10:      	add	x9, x9, #0x1
      14:      	stxr	w10, x9, [x8]
      18:      	cbnz	w10, 0xc <kprobe_vfs_create+0xc>
      1c:      	mov	w0, wzr
      20:      	ret

Disassembly of section fentry/vfs_read:

0000000000000000 <fentry_vfs_read>:
       0:      	adrp	x8, 0x0 <fentry_vfs_read>
       4:      	ldr	x8, [x8]
       8:      	ldxr	x9, [x8]
       c:      	add	x9, x9, #0x1
      10:      	stxr	w10, x9, [x8]
      14:      	cbnz	w10, 0x8 <fentry_vfs_read+0x8>
      18:      	mov	w0, wzr
      1c:      	ret

Disassembly of section fentry/vfs_write:

0000000000000000 <fentry_vfs_write>:
       0:      	adrp	x8, 0x0 <fentry_vfs_write>
       4:      	ldr	x8, [x8]
       8:      	add	x8, x8, #0x8
       c:      	ldxr	x9, [x8]
      10:      	add	x9, x9, #0x1
      14:      	stxr	w10, x9, [x8]
      18:      	cbnz	w10, 0xc <fentry_vfs_write+0xc>
      1c:      	mov	w0, wzr
      20:      	ret

Disassembly of section fentry/vfs_fsync:

0000000000000000 <fentry_vfs_fsync>:
       0:      	adrp	x8, 0x0 <fentry_vfs_fsync>
       4:      	ldr	x8, [x8]
       8:      	add	x8, x8, #0x10
       c:      	ldxr	x9, [x8]
      10:      	add	x9, x9, #0x1
      14:      	stxr	w10, x9, [x8]
      18:      	cbnz	w10, 0xc <fentry_vfs_fsync+0xc>
      1c:      	mov	w0, wzr
      20:      	ret

Disassembly of section fentry/vfs_open:

0000000000000000 <fentry_vfs_open>:
       0:      	adrp	x8, 0x0 <fentry_vfs_open>
       4:      	ldr	x8, [x8]
       8:      	add	x8, x8, #0x18
       c:      	ldxr	x9, [x8]
      10:      	add	x9, x9, #0x1
      14:      	stxr	w10, x9, [x8]
      18:      	cbnz	w10, 0xc <fentry_vfs_open+0xc>
      1c:      	mov	w0, wzr
      20:      	ret

Disassembly of section fentry/vfs_create:

0000000000000000 <fentry_vfs_create>:
       0:      	adrp	x8, 0x0 <fentry_vfs_create>
       4:      	ldr	x8, [x8]
       8:      	add	x8, x8, #0x20
       c:      	ldxr	x9, [x8]
      10:      	add	x9, x9, #0x1
      14:      	stxr	w10, x9, [x8]
      18:      	cbnz	w10, 0xc <fentry_vfs_create+0xc>
      1c:      	mov	w0, wzr
      20:      	ret
