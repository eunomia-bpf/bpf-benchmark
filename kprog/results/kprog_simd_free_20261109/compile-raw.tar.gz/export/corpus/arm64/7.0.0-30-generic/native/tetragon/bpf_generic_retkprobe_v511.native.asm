
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_retkprobe_v511.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	cbz	x2, 0x8c <native_bpf_strncasestr+0x8c>
       4:      	mov	x8, x0
       8:      	mov	x0, xzr
       c:      	mov	x9, x2
      10:      	b	0x34 <native_bpf_strncasestr+0x34>
      14:      	nop
      18:      	nop
      1c:      	nop
      20:      	add	x0, x0, #0x1
      24:      	sub	x9, x9, #0x1
      28:      	add	x8, x8, #0x1
      2c:      	cmp	x0, x2
      30:      	b.eq	0x8c <native_bpf_strncasestr+0x8c>
      34:      	mov	x10, xzr
      38:      	nop
      3c:      	nop
      40:      	cmp	x9, x10
      44:      	b.eq	0x20 <native_bpf_strncasestr+0x20>
      48:      	ldrb	w11, [x1, x10]
      4c:      	cbz	w11, 0x90 <native_bpf_strncasestr+0x90>
      50:      	ldrb	w12, [x8, x10]
      54:      	sub	w13, w12, #0x41
      58:      	orr	w14, w12, #0x20
      5c:      	cmp	w13, #0x1a
      60:      	sub	w13, w11, #0x41
      64:      	csel	w12, w14, w12, lo
      68:      	orr	w14, w11, #0x20
      6c:      	cmp	w13, #0x1a
      70:      	csel	w11, w14, w11, lo
      74:      	cmp	w12, w11
      78:      	b.ne	0x20 <native_bpf_strncasestr+0x20>
      7c:      	cmp	x10, #0x63
      80:      	add	x10, x10, #0x1
      84:      	b.lo	0x40 <native_bpf_strncasestr+0x40>
      88:      	b	0x20 <native_bpf_strncasestr+0x20>
      8c:      	mov	w0, #-0x1               // =-1
      90:      	ret

Disassembly of section kprobe:

0000000000000000 <generic_retkprobe_filter_arg>:
       0:      	sub	sp, sp, #0xf0
       4:      	str	x29, [sp, #0xa0]
       8:      	stp	x30, x25, [sp, #0xb0]
       c:      	stp	x24, x23, [sp, #0xc0]
      10:      	stp	x22, x21, [sp, #0xd0]
      14:      	stp	x20, x19, [sp, #0xe0]
      18:      	mov	x23, x0
      1c:      	str	wzr, [sp, #0xa8]
      20:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
      24:      	mov	w8, #0x1                // =1
      28:      	ldr	x0, [x0]
      2c:      	add	x9, sp, #0xa8
      30:      	add	x1, sp, #0xa8
      34:      	blr	x8
      38:      	cbz	x0, 0x337c <generic_retkprobe_filter_arg+0x337c>
      3c:      	mov	w8, #0x5ec1             // =24257
      40:      	mov	x20, x0
      44:      	add	x19, x0, x8
      48:      	mov	w8, #0x5ef8             // =24312
      4c:      	add	x1, x0, x8
      50:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
      54:      	ldur	w21, [x19, #0x3f]
      58:      	mov	w8, #0x1                // =1
      5c:      	ldr	x0, [x0]
      60:      	blr	x8
      64:      	cbz	x0, 0x3360 <generic_retkprobe_filter_arg+0x3360>
      68:      	ldrb	w8, [x19, #0x1f]
      6c:      	cbz	w8, 0x3360 <generic_retkprobe_filter_arg+0x3360>
      70:      	and	x8, x21, #0x7
      74:      	mov	w10, #0x5ec1            // =24257
      78:      	str	x21, [sp, #0x58]
      7c:      	add	x9, x20, x8
      80:      	ldrb	w9, [x9, x10]
      84:      	cbz	w9, 0xc4 <generic_retkprobe_filter_arg+0xc4>
      88:      	lsl	w8, w8, #2
      8c:      	add	x8, x8, #0x4
      90:      	ldr	w9, [x8, x0]
      94:      	add	x8, x8, x9
      98:      	add	x12, x8, #0x4
      9c:      	and	x8, x12, #0x3ff
      a0:      	add	x16, x0, x8
      a4:      	str	x8, [sp, #0x40]
      a8:      	ldr	w8, [x16]
      ac:      	cmp	w8, #0x19
      b0:      	b.hs	0x110 <generic_retkprobe_filter_arg+0x110>
      b4:      	ldr	x8, [sp, #0x40]
      b8:      	cmp	w8, #0x1
      bc:      	b.eq	0x3360 <generic_retkprobe_filter_arg+0x3360>
      c0:      	cbnz	w8, 0x333c <generic_retkprobe_filter_arg+0x333c>
      c4:      	ldr	x8, [sp, #0x58]
      c8:      	cmp	w8, #0x1
      cc:      	b.gt	0xe8 <generic_retkprobe_filter_arg+0xe8>
      d0:      	cmn	w8, #0x1
      d4:      	b.eq	0x339c <generic_retkprobe_filter_arg+0x339c>
      d8:      	cbz	w8, 0x33ac <generic_retkprobe_filter_arg+0x33ac>
      dc:      	cmp	w8, #0x1
      e0:      	b.eq	0x33bc <generic_retkprobe_filter_arg+0x33bc>
      e4:      	b	0x100 <generic_retkprobe_filter_arg+0x100>
      e8:      	cmp	w8, #0x2
      ec:      	b.eq	0x33cc <generic_retkprobe_filter_arg+0x33cc>
      f0:      	cmp	w8, #0x3
      f4:      	b.eq	0x33dc <generic_retkprobe_filter_arg+0x33dc>
      f8:      	cmp	w8, #0x4
      fc:      	b.eq	0x33ec <generic_retkprobe_filter_arg+0x33ec>
     100:      	cmp	w8, #0x4
     104:      	b.gt	0x3418 <generic_retkprobe_filter_arg+0x3418>
     108:      	add	w8, w8, #0x1
     10c:      	b	0x33f8 <generic_retkprobe_filter_arg+0x33f8>
     110:      	mov	x24, xzr
     114:      	mov	w17, #0x1               // =1
     118:      	stp	x19, x0, [sp, #0x30]
     11c:      	stp	x12, x16, [sp, #0x48]
     120:      	b	0x14c <generic_retkprobe_filter_arg+0x14c>
     124:      	orr	w8, w8, #0x2
     128:      	cmp	w8, #0x6
     12c:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
     130:      	nop
     134:      	nop
     138:      	nop
     13c:      	nop
     140:      	add	x24, x24, #0x1
     144:      	cmp	x24, #0x5
     148:      	b.eq	0xb4 <generic_retkprobe_filter_arg+0xb4>
     14c:      	add	x8, x16, x24, lsl #2
     150:      	ldr	w8, [x8, #0x4]
     154:      	tst	w8, #0x3ff
     158:      	b.eq	0xb4 <generic_retkprobe_filter_arg+0xb4>
     15c:      	add	w8, w12, w8
     160:      	and	x8, x8, #0x3ff
     164:      	add	x21, x0, x8
     168:      	ldr	w8, [x21, #0x4]
     16c:      	cmp	w8, #0x23
     170:      	b.eq	0xc4 <generic_retkprobe_filter_arg+0xc4>
     174:      	ldr	w9, [x21]
     178:      	cmp	w9, #0x4
     17c:      	b.hi	0xc4 <generic_retkprobe_filter_arg+0xc4>
     180:      	add	x10, x20, x9, lsl #2
     184:      	mov	w11, #0x5ea0            // =24224
     188:      	ldr	w10, [x10, x11]
     18c:      	cbnz	w10, 0xc4 <generic_retkprobe_filter_arg+0xc4>
     190:      	add	x9, x20, x9, lsl #3
     194:      	ldr	x9, [x9, #0x5e78]
     198:      	and	x9, x9, #0x7ff
     19c:      	add	x9, x20, x9
     1a0:      	add	x25, x9, #0x90
     1a4:      	ldr	w9, [x21, #0xc]
     1a8:      	cmp	w9, #0x1b
     1ac:      	b.le	0x1d0 <generic_retkprobe_filter_arg+0x1d0>
     1b0:      	cmp	w9, #0x25
     1b4:      	b.gt	0x200 <generic_retkprobe_filter_arg+0x200>
     1b8:      	sub	w10, w9, #0x1c
     1bc:      	cmp	w10, #0x9
     1c0:      	b.lo	0x244 <generic_retkprobe_filter_arg+0x244>
     1c4:      	cmp	w9, #0x25
     1c8:      	b.eq	0x3f8 <generic_retkprobe_filter_arg+0x3f8>
     1cc:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
     1d0:      	cmp	w9, #0x9
     1d4:      	b.le	0x224 <generic_retkprobe_filter_arg+0x224>
     1d8:      	sub	w10, w9, #0xa
     1dc:      	cmp	w10, #0x4
     1e0:      	b.lo	0x244 <generic_retkprobe_filter_arg+0x244>
     1e4:      	sub	w10, w9, #0xf
     1e8:      	cmp	w10, #0x2
     1ec:      	b.lo	0x3f8 <generic_retkprobe_filter_arg+0x3f8>
     1f0:      	cmp	w9, #0x11
     1f4:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
     1f8:      	add	x25, x25, #0x4
     1fc:      	b	0x3f8 <generic_retkprobe_filter_arg+0x3f8>
     200:      	cmp	w9, #0x29
     204:      	b.gt	0x370 <generic_retkprobe_filter_arg+0x370>
     208:      	sub	w10, w9, #0x26
     20c:      	cmp	w10, #0x2
     210:      	b.lo	0x318 <generic_retkprobe_filter_arg+0x318>
     214:      	sub	w10, w9, #0x28
     218:      	cmp	w10, #0x2
     21c:      	b.lo	0x2f0 <generic_retkprobe_filter_arg+0x2f0>
     220:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
     224:      	cmp	w9, #0x4
     228:      	b.gt	0x2d8 <generic_retkprobe_filter_arg+0x2d8>
     22c:      	cmp	w9, #0x1
     230:      	b.eq	0x244 <generic_retkprobe_filter_arg+0x244>
     234:      	cmp	w9, #0x2
     238:      	b.eq	0x824 <generic_retkprobe_filter_arg+0x824>
     23c:      	cmp	w9, #0x4
     240:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
     244:      	cmp	w9, #0xb
     248:      	b.le	0x2b8 <generic_retkprobe_filter_arg+0x2b8>
     24c:      	cmp	w9, #0x24
     250:      	b.hi	0x4b0 <generic_retkprobe_filter_arg+0x4b0>
     254:      	lsl	x10, x17, x9
     258:      	tst	x10, #0x1e00000000
     25c:      	b.ne	0x348 <generic_retkprobe_filter_arg+0x348>
     260:      	lsl	x10, x17, x9
     264:      	tst	x10, #0x60000000
     268:      	b.ne	0x66c <generic_retkprobe_filter_arg+0x66c>
     26c:      	lsl	x10, x17, x9
     270:      	tst	x10, #0x180000000
     274:      	b.eq	0x4b0 <generic_retkprobe_filter_arg+0x4b0>
     278:      	cmp	w8, #0x20
     27c:      	b.hi	0xc4 <generic_retkprobe_filter_arg+0xc4>
     280:      	lsl	x9, x17, x8
     284:      	mov	w10, #0x101e            // =4126
     288:      	tst	x9, x10
     28c:      	b.eq	0xcb8 <generic_retkprobe_filter_arg+0xcb8>
     290:      	ldr	w9, [x21, #0x10]
     294:      	cmp	w8, #0x2
     298:      	b.le	0x1230 <generic_retkprobe_filter_arg+0x1230>
     29c:      	sub	w10, w8, #0x3
     2a0:      	cmp	w10, #0x2
     2a4:      	b.hs	0x1844 <generic_retkprobe_filter_arg+0x1844>
     2a8:      	ldrb	w10, [x25]
     2ac:      	cmp	w9, w10
     2b0:      	b.ne	0x19d0 <generic_retkprobe_filter_arg+0x19d0>
     2b4:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
     2b8:      	sub	w10, w9, #0xa
     2bc:      	cmp	w10, #0x2
     2c0:      	b.lo	0x898 <generic_retkprobe_filter_arg+0x898>
     2c4:      	cmp	w9, #0x1
     2c8:      	b.eq	0x4bc <generic_retkprobe_filter_arg+0x4bc>
     2cc:      	cmp	w9, #0x4
     2d0:      	b.eq	0x4bc <generic_retkprobe_filter_arg+0x4bc>
     2d4:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
     2d8:      	cmp	w9, #0x5
     2dc:      	b.eq	0x2f0 <generic_retkprobe_filter_arg+0x2f0>
     2e0:      	cmp	w9, #0x6
     2e4:      	b.eq	0x318 <generic_retkprobe_filter_arg+0x318>
     2e8:      	cmp	w9, #0x7
     2ec:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
     2f0:      	mov	x22, xzr
     2f4:      	cmp	w9, #0x27
     2f8:      	stp	xzr, xzr, [sp, #0x78]
     2fc:      	str	xzr, [sp, #0x60]
     300:      	stp	xzr, xzr, [sp, #0x68]
     304:      	b.gt	0x4fc <generic_retkprobe_filter_arg+0x4fc>
     308:      	cmp	w9, #0x5
     30c:      	b.eq	0x9c8 <generic_retkprobe_filter_arg+0x9c8>
     310:      	cmp	w9, #0x7
     314:      	b	0x508 <generic_retkprobe_filter_arg+0x508>
     318:      	ldr	w29, [x25], #0x4
     31c:      	mov	x22, xzr
     320:      	cmp	w8, #0x19
     324:      	b.gt	0x568 <generic_retkprobe_filter_arg+0x568>
     328:      	sub	w9, w8, #0x3
     32c:      	cmp	w9, #0x2
     330:      	b.lo	0xc48 <generic_retkprobe_filter_arg+0xc48>
     334:      	cmp	w8, #0x8
     338:      	b.eq	0xbb0 <generic_retkprobe_filter_arg+0xbb0>
     33c:      	cmp	w8, #0x9
     340:      	b.eq	0x580 <generic_retkprobe_filter_arg+0x580>
     344:      	b	0x1d18 <generic_retkprobe_filter_arg+0x1d18>
     348:      	cmp	w8, #0x9
     34c:      	b.le	0x814 <generic_retkprobe_filter_arg+0x814>
     350:      	cmp	w8, #0x1d
     354:      	b.gt	0xb70 <generic_retkprobe_filter_arg+0xb70>
     358:      	sub	w10, w8, #0xa
     35c:      	cmp	w10, #0x2
     360:      	b.lo	0x924 <generic_retkprobe_filter_arg+0x924>
     364:      	cmp	w8, #0xc
     368:      	b.eq	0x8b0 <generic_retkprobe_filter_arg+0x8b0>
     36c:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
     370:      	cmp	w9, #0x2a
     374:      	b.eq	0x3f8 <generic_retkprobe_filter_arg+0x3f8>
     378:      	cmp	w9, #0x2c
     37c:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
     380:      	ldrb	w29, [x25, #0x3]
     384:      	add	x10, x25, #0x4
     388:      	cmp	w8, #0x19
     38c:      	b.gt	0xf44 <generic_retkprobe_filter_arg+0xf44>
     390:      	sub	w9, w8, #0x3
     394:      	cmp	w9, #0x2
     398:      	b.hs	0x14b4 <generic_retkprobe_filter_arg+0x14b4>
     39c:      	cmp	w29, #0x90
     3a0:      	str	wzr, [sp, #0x88]
     3a4:      	b.hi	0x1550 <generic_retkprobe_filter_arg+0x1550>
     3a8:      	mov	w8, #0xaaab             // =43691
     3ac:      	mov	w9, #0x18               // =24
     3b0:      	movk	w8, #0xaaa, lsl #16
     3b4:      	umull	x8, w29, w8
     3b8:      	lsr	x8, x8, #32
     3bc:      	msub	w8, w8, w9, w29
     3c0:      	cbz	w29, 0x3cc <generic_retkprobe_filter_arg+0x3cc>
     3c4:      	mov	w13, w29
     3c8:      	cbz	w8, 0x3e0 <generic_retkprobe_filter_arg+0x3e0>
     3cc:      	sub	w8, w29, w8, uxtb
     3d0:      	add	w9, w8, #0x18
     3d4:      	cmp	w8, #0x78
     3d8:      	and	w13, w9, #0xffff
     3dc:      	b.hi	0x1554 <generic_retkprobe_filter_arg+0x1554>
     3e0:      	and	w8, w13, #0xff
     3e4:      	mov	w9, #0xab               // =171
     3e8:      	mul	w8, w8, w9
     3ec:      	lsr	w8, w8, #12
     3f0:      	sub	w11, w8, #0x1
     3f4:      	b	0x1fd0 <generic_retkprobe_filter_arg+0x1fd0>
     3f8:      	ldr	w29, [x25]
     3fc:      	and	w9, w8, #0xfffffffe
     400:      	cmp	w9, #0x24
     404:      	b.eq	0x40c <generic_retkprobe_filter_arg+0x40c>
     408:      	cbz	w29, 0xc4 <generic_retkprobe_filter_arg+0xc4>
     40c:      	cmp	w8, #0x25
     410:      	b.hi	0x64c <generic_retkprobe_filter_arg+0x64c>
     414:      	mov	w10, #0x100             // =256
     418:      	lsl	x9, x17, x8
     41c:      	movk	w10, #0x400, lsl #16
     420:      	tst	x9, x10
     424:      	b.ne	0x77c <generic_retkprobe_filter_arg+0x77c>
     428:      	mov	w10, #0x200             // =512
     42c:      	lsl	x9, x17, x8
     430:      	movk	w10, #0x800, lsl #16
     434:      	tst	x9, x10
     438:      	b.ne	0x6ac <generic_retkprobe_filter_arg+0x6ac>
     43c:      	lsl	x9, x17, x8
     440:      	tst	x9, #0x3000000000
     444:      	b.eq	0x64c <generic_retkprobe_filter_arg+0x64c>
     448:      	cmp	w29, #0x1, lsl #12      // =0x1000
     44c:      	strh	wzr, [sp, #0x60]
     450:      	b.hi	0x664 <generic_retkprobe_filter_arg+0x664>
     454:      	add	x8, x25, #0x4
     458:      	mov	w10, #0x4               // =4
     45c:      	add	x11, sp, #0x60
     460:      	mov	w12, #0x2               // =2
     464:      	add	x0, sp, #0x60
     468:      	mov	w1, #0x2                // =2
     46c:      	add	x9, x8, x29
     470:      	add	x9, x9, #0x4
     474:      	ldr	w9, [x25]
     478:      	add	x8, x8, x9
     47c:      	add	x2, x8, #0x4
     480:      	blr	x10
     484:      	ldr	w9, [x21, #0x10]
     488:      	cbz	w9, 0x2d1c <generic_retkprobe_filter_arg+0x2d1c>
     48c:      	ldrh	w8, [sp, #0x60]
     490:      	ldr	x0, [sp, #0x38]
     494:      	mov	w17, #0x1               // =1
     498:      	and	w8, w8, #0xf000
     49c:      	ldp	x12, x16, [sp, #0x48]
     4a0:      	cmp	w9, w8
     4a4:      	b.ne	0x1874 <generic_retkprobe_filter_arg+0x1874>
     4a8:      	mov	w22, #0x1               // =1
     4ac:      	b	0x2d2c <generic_retkprobe_filter_arg+0x2d2c>
     4b0:      	sub	w10, w9, #0xc
     4b4:      	cmp	w10, #0x2
     4b8:      	b.hs	0x890 <generic_retkprobe_filter_arg+0x890>
     4bc:      	cmp	w8, #0x20
     4c0:      	b.hi	0xc4 <generic_retkprobe_filter_arg+0xc4>
     4c4:      	lsl	x10, x17, x8
     4c8:      	mov	w11, #0x101e            // =4126
     4cc:      	tst	x10, x11
     4d0:      	b.eq	0x514 <generic_retkprobe_filter_arg+0x514>
     4d4:      	ldr	w10, [x21, #0x10]
     4d8:      	cmp	w8, #0x2
     4dc:      	b.le	0x858 <generic_retkprobe_filter_arg+0x858>
     4e0:      	sub	w11, w8, #0x3
     4e4:      	cmp	w11, #0x2
     4e8:      	b.hs	0xca0 <generic_retkprobe_filter_arg+0xca0>
     4ec:      	ldr	w11, [x25]
     4f0:      	cmp	w11, w10
     4f4:      	b.ne	0x1df4 <generic_retkprobe_filter_arg+0x1df4>
     4f8:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
     4fc:      	cmp	w9, #0x28
     500:      	b.eq	0x9d0 <generic_retkprobe_filter_arg+0x9d0>
     504:      	cmp	w9, #0x29
     508:      	mov	x10, x25
     50c:      	b.eq	0x9f8 <generic_retkprobe_filter_arg+0x9f8>
     510:      	b	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
     514:      	lsl	x10, x17, x8
     518:      	tst	x10, #0xc00
     51c:      	b.ne	0x990 <generic_retkprobe_filter_arg+0x990>
     520:      	lsl	x10, x17, x8
     524:      	tst	x10, #0x180000000
     528:      	b.eq	0xc4 <generic_retkprobe_filter_arg+0xc4>
     52c:      	cmp	w8, #0x1f
     530:      	b.ne	0xf14 <generic_retkprobe_filter_arg+0xf14>
     534:      	ldp	w11, w10, [x21, #0x10]
     538:      	cmp	w9, #0xc
     53c:      	b.hi	0x1a44 <generic_retkprobe_filter_arg+0x1a44>
     540:      	lsl	w8, w17, w9
     544:      	mov	w13, #0x1402            // =5122
     548:      	tst	w8, w13
     54c:      	b.eq	0x1a44 <generic_retkprobe_filter_arg+0x1a44>
     550:      	ldr	w8, [x25]
     554:      	cmp	w11, w8
     558:      	b.gt	0x1a58 <generic_retkprobe_filter_arg+0x1a58>
     55c:      	cmp	w8, w10
     560:      	b.le	0x140 <generic_retkprobe_filter_arg+0x140>
     564:      	b	0x1a58 <generic_retkprobe_filter_arg+0x1a58>
     568:      	cmp	w8, #0x20
     56c:      	b.gt	0xa6c <generic_retkprobe_filter_arg+0xa6c>
     570:      	cmp	w8, #0x1a
     574:      	b.eq	0xbb0 <generic_retkprobe_filter_arg+0xbb0>
     578:      	cmp	w8, #0x1b
     57c:      	b.ne	0x1d18 <generic_retkprobe_filter_arg+0x1d18>
     580:      	ldr	w8, [x21, #0x10]
     584:      	str	wzr, [sp, #0x88]
     588:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     58c:      	add	x9, sp, #0x60
     590:      	add	x1, sp, #0x60
     594:      	str	w8, [sp, #0x60]
     598:      	mov	w8, #0x1                // =1
     59c:      	ldr	x0, [x0]
     5a0:      	blr	x8
     5a4:      	mov	x22, xzr
     5a8:      	cbz	w29, 0x1314 <generic_retkprobe_filter_arg+0x1314>
     5ac:      	cbz	x0, 0x1314 <generic_retkprobe_filter_arg+0x1314>
     5b0:      	mov	x19, x0
     5b4:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     5b8:      	mov	w8, #0x1                // =1
     5bc:      	ldr	x0, [x0]
     5c0:      	add	x9, sp, #0x88
     5c4:      	add	x1, sp, #0x88
     5c8:      	blr	x8
     5cc:      	cbz	x0, 0x130c <generic_retkprobe_filter_arg+0x130c>
     5d0:      	cmp	w29, #0x7f
     5d4:      	mov	w9, #0x7f               // =127
     5d8:      	mov	w11, #0x1               // =1
     5dc:      	mov	x1, x0
     5e0:      	mov	x8, xzr
     5e4:      	sub	w12, w29, #0x2
     5e8:      	sub	w13, w29, #0x1
     5ec:      	csel	w9, w29, w9, lo
     5f0:      	sub	x11, x11, x29
     5f4:      	lsl	w10, w9, #3
     5f8:      	mov	x9, x0
     5fc:      	str	w10, [x9], #0x5
     600:      	neg	x10, x29
     604:      	add	w14, w13, w8
     608:      	cmp	x11, x8
     60c:      	and	x14, x14, #0xfff
     610:      	ldrb	w14, [x25, x14]
     614:      	sturb	w14, [x9, #-0x1]
     618:      	b.eq	0x640 <generic_retkprobe_filter_arg+0x640>
     61c:      	cmn	x8, #0x7e
     620:      	b.eq	0x640 <generic_retkprobe_filter_arg+0x640>
     624:      	add	w14, w12, w8
     628:      	sub	x8, x8, #0x2
     62c:      	and	x14, x14, #0xfff
     630:      	cmp	x10, x8
     634:      	ldrb	w14, [x25, x14]
     638:      	strb	w14, [x9], #0x2
     63c:      	b.ne	0x604 <generic_retkprobe_filter_arg+0x604>
     640:      	mov	w8, #0x1                // =1
     644:      	mov	x0, x19
     648:      	b	0xc38 <generic_retkprobe_filter_arg+0xc38>
     64c:      	sub	w8, w8, #0x3
     650:      	cmp	w8, #0x2
     654:      	b.hs	0x664 <generic_retkprobe_filter_arg+0x664>
     658:      	cmp	w29, #0x1, lsl #12      // =0x1000
     65c:      	str	wzr, [sp, #0x88]
     660:      	b.ls	0xda8 <generic_retkprobe_filter_arg+0xda8>
     664:      	mov	x22, xzr
     668:      	b	0x2d2c <generic_retkprobe_filter_arg+0x2d2c>
     66c:      	cmp	w8, #0x20
     670:      	b.hi	0xc4 <generic_retkprobe_filter_arg+0xc4>
     674:      	lsl	x9, x17, x8
     678:      	mov	w10, #0x101e            // =4126
     67c:      	tst	x9, x10
     680:      	b.eq	0xce4 <generic_retkprobe_filter_arg+0xce4>
     684:      	ldr	w9, [x21, #0x10]
     688:      	cmp	w8, #0x2
     68c:      	b.le	0x1250 <generic_retkprobe_filter_arg+0x1250>
     690:      	sub	w10, w8, #0x3
     694:      	cmp	w10, #0x2
     698:      	b.hs	0x185c <generic_retkprobe_filter_arg+0x185c>
     69c:      	ldrh	w10, [x25]
     6a0:      	cmp	w9, w10
     6a4:      	b.ne	0x1a10 <generic_retkprobe_filter_arg+0x1a10>
     6a8:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
     6ac:      	ldr	w8, [x21, #0x10]
     6b0:      	str	wzr, [sp, #0x88]
     6b4:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     6b8:      	add	x9, sp, #0x60
     6bc:      	add	x1, sp, #0x60
     6c0:      	str	w8, [sp, #0x60]
     6c4:      	mov	w8, #0x1                // =1
     6c8:      	ldr	x0, [x0]
     6cc:      	blr	x8
     6d0:      	mov	x22, xzr
     6d4:      	cbz	w29, 0x2d20 <generic_retkprobe_filter_arg+0x2d20>
     6d8:      	cbz	x0, 0x2d20 <generic_retkprobe_filter_arg+0x2d20>
     6dc:      	mov	x19, x0
     6e0:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     6e4:      	mov	w8, #0x1                // =1
     6e8:      	ldr	x0, [x0]
     6ec:      	add	x9, sp, #0x88
     6f0:      	add	x1, sp, #0x88
     6f4:      	blr	x8
     6f8:      	cbz	x0, 0x18c4 <generic_retkprobe_filter_arg+0x18c4>
     6fc:      	cmp	w29, #0x7f
     700:      	mov	w10, #0x7f              // =127
     704:      	mov	w12, #0x1               // =1
     708:      	mov	x1, x0
     70c:      	mov	x8, xzr
     710:      	add	x9, x25, #0x4
     714:      	sub	w13, w29, #0x2
     718:      	sub	w14, w29, #0x1
     71c:      	csel	w10, w29, w10, lo
     720:      	sub	x12, x12, x29
     724:      	lsl	w11, w10, #3
     728:      	mov	x10, x0
     72c:      	str	w11, [x10], #0x5
     730:      	neg	x11, x29
     734:      	add	w15, w14, w8
     738:      	cmp	x12, x8
     73c:      	and	x15, x15, #0xfff
     740:      	ldrb	w15, [x9, x15]
     744:      	sturb	w15, [x10, #-0x1]
     748:      	b.eq	0x770 <generic_retkprobe_filter_arg+0x770>
     74c:      	cmn	x8, #0x7e
     750:      	b.eq	0x770 <generic_retkprobe_filter_arg+0x770>
     754:      	add	w15, w13, w8
     758:      	sub	x8, x8, #0x2
     75c:      	and	x15, x15, #0xfff
     760:      	cmp	x11, x8
     764:      	ldrb	w15, [x9, x15]
     768:      	strb	w15, [x10], #0x2
     76c:      	b.ne	0x734 <generic_retkprobe_filter_arg+0x734>
     770:      	mov	w8, #0x1                // =1
     774:      	mov	x0, x19
     778:      	b	0x804 <generic_retkprobe_filter_arg+0x804>
     77c:      	ldr	w8, [x21, #0x10]
     780:      	str	wzr, [sp, #0x88]
     784:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     788:      	add	x9, sp, #0x60
     78c:      	add	x1, sp, #0x60
     790:      	str	w8, [sp, #0x60]
     794:      	mov	w8, #0x1                // =1
     798:      	ldr	x0, [x0]
     79c:      	blr	x8
     7a0:      	mov	x22, xzr
     7a4:      	cbz	w29, 0x2d20 <generic_retkprobe_filter_arg+0x2d20>
     7a8:      	cbz	x0, 0x2d20 <generic_retkprobe_filter_arg+0x2d20>
     7ac:      	mov	x19, x0
     7b0:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     7b4:      	mov	w8, #0x1                // =1
     7b8:      	ldr	x0, [x0]
     7bc:      	add	x9, sp, #0x88
     7c0:      	add	x1, sp, #0x88
     7c4:      	blr	x8
     7c8:      	cbz	x0, 0x18c4 <generic_retkprobe_filter_arg+0x18c4>
     7cc:      	cmp	w29, #0xff
     7d0:      	mov	w8, #0xff               // =255
     7d4:      	add	x2, x25, #0x4
     7d8:      	mov	x22, x0
     7dc:      	csel	w1, w29, w8, lo
     7e0:      	mov	x8, x0
     7e4:      	lsl	w9, w1, #3
     7e8:      	str	w9, [x8], #0x4
     7ec:      	mov	w9, #0x4                // =4
     7f0:      	mov	x0, x8
     7f4:      	blr	x9
     7f8:      	mov	w8, #0x1                // =1
     7fc:      	mov	x0, x19
     800:      	mov	x1, x22
     804:      	blr	x8
     808:      	cmp	x0, #0x0
     80c:      	cset	w22, ne
     810:      	b	0x18c8 <generic_retkprobe_filter_arg+0x18c8>
     814:      	sub	w10, w8, #0x1
     818:      	cmp	w10, #0x4
     81c:      	b.lo	0x8b0 <generic_retkprobe_filter_arg+0x8b0>
     820:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
     824:      	add	x29, x25, #0x8
     828:      	ldr	w25, [x25, #0x4]
     82c:      	mov	x22, xzr
     830:      	cmp	w8, #0x19
     834:      	b.gt	0xe18 <generic_retkprobe_filter_arg+0xe18>
     838:      	sub	w9, w8, #0x3
     83c:      	cmp	w9, #0x2
     840:      	b.lo	0x1658 <generic_retkprobe_filter_arg+0x1658>
     844:      	cmp	w8, #0x8
     848:      	b.eq	0x15cc <generic_retkprobe_filter_arg+0x15cc>
     84c:      	cmp	w8, #0x9
     850:      	b.eq	0xe30 <generic_retkprobe_filter_arg+0xe30>
     854:      	b	0x32c4 <generic_retkprobe_filter_arg+0x32c4>
     858:      	cmp	w8, #0x1
     85c:      	b.eq	0x1080 <generic_retkprobe_filter_arg+0x1080>
     860:      	cmp	w8, #0x2
     864:      	b.ne	0x1df4 <generic_retkprobe_filter_arg+0x1df4>
     868:      	cmp	w9, #0xc
     86c:      	b.hi	0x1de8 <generic_retkprobe_filter_arg+0x1de8>
     870:      	lsl	w11, w17, w9
     874:      	mov	w13, #0x1402            // =5122
     878:      	tst	w11, w13
     87c:      	b.eq	0x1de8 <generic_retkprobe_filter_arg+0x1de8>
     880:      	ldr	w11, [x25]
     884:      	cmp	w11, w10
     888:      	b.lt	0x140 <generic_retkprobe_filter_arg+0x140>
     88c:      	b	0x1df4 <generic_retkprobe_filter_arg+0x1df4>
     890:      	cmp	w9, #0x1c
     894:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
     898:      	cmp	w8, #0x20
     89c:      	b.hi	0xc4 <generic_retkprobe_filter_arg+0xc4>
     8a0:      	lsl	x10, x17, x8
     8a4:      	mov	w11, #0x101e            // =4126
     8a8:      	tst	x10, x11
     8ac:      	b.eq	0x8d8 <generic_retkprobe_filter_arg+0x8d8>
     8b0:      	ldr	x10, [x21, #0x10]
     8b4:      	cmp	w8, #0x2
     8b8:      	b.le	0x8f4 <generic_retkprobe_filter_arg+0x8f4>
     8bc:      	sub	w11, w8, #0x3
     8c0:      	cmp	w11, #0x2
     8c4:      	b.hs	0xb58 <generic_retkprobe_filter_arg+0xb58>
     8c8:      	ldr	x11, [x25]
     8cc:      	cmp	x11, x10
     8d0:      	b.ne	0x17b8 <generic_retkprobe_filter_arg+0x17b8>
     8d4:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
     8d8:      	lsl	x10, x17, x8
     8dc:      	tst	x10, #0xc00
     8e0:      	b.ne	0x924 <generic_retkprobe_filter_arg+0x924>
     8e4:      	lsl	x10, x17, x8
     8e8:      	tst	x10, #0x180000000
     8ec:      	b.ne	0xb7c <generic_retkprobe_filter_arg+0xb7c>
     8f0:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
     8f4:      	cmp	w8, #0x1
     8f8:      	b.eq	0xd88 <generic_retkprobe_filter_arg+0xd88>
     8fc:      	cmp	w8, #0x2
     900:      	b.ne	0x17b8 <generic_retkprobe_filter_arg+0x17b8>
     904:      	cmp	w9, #0xc
     908:      	b.eq	0x914 <generic_retkprobe_filter_arg+0x914>
     90c:      	cmp	w9, #0xa
     910:      	b.ne	0x17ac <generic_retkprobe_filter_arg+0x17ac>
     914:      	ldr	x11, [x25]
     918:      	cmp	x11, x10
     91c:      	b.lt	0x140 <generic_retkprobe_filter_arg+0x140>
     920:      	b	0x17b8 <generic_retkprobe_filter_arg+0x17b8>
     924:      	ldrb	w8, [x21, #0x10]
     928:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     92c:      	add	x9, sp, #0x88
     930:      	add	x1, sp, #0x88
     934:      	str	w8, [sp, #0x88]
     938:      	mov	w8, #0x1                // =1
     93c:      	ldr	x0, [x0]
     940:      	blr	x8
     944:      	cbz	x0, 0xefc <generic_retkprobe_filter_arg+0xefc>
     948:      	ldr	x8, [x25]
     94c:      	add	x9, sp, #0x60
     950:      	add	x1, sp, #0x60
     954:      	str	x8, [sp, #0x60]
     958:      	mov	w8, #0x1                // =1
     95c:      	blr	x8
     960:      	ldr	w8, [x21, #0x4]
     964:      	cmp	w8, #0xb
     968:      	b.eq	0x1324 <generic_retkprobe_filter_arg+0x1324>
     96c:      	ldp	x12, x16, [sp, #0x48]
     970:      	cmp	w8, #0xa
     974:      	mov	w17, #0x1               // =1
     978:      	b.eq	0x13c8 <generic_retkprobe_filter_arg+0x13c8>
     97c:      	ldr	x0, [sp, #0x38]
     980:      	mov	w22, wzr
     984:      	mov	w8, wzr
     988:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
     98c:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
     990:      	ldrb	w8, [x21, #0x10]
     994:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     998:      	add	x9, sp, #0x88
     99c:      	add	x1, sp, #0x88
     9a0:      	str	w8, [sp, #0x88]
     9a4:      	mov	w8, #0x1                // =1
     9a8:      	ldr	x0, [x0]
     9ac:      	blr	x8
     9b0:      	cbz	x0, 0x1cd4 <generic_retkprobe_filter_arg+0x1cd4>
     9b4:      	ldr	w8, [x25]
     9b8:      	add	x9, sp, #0x60
     9bc:      	str	x8, [sp, #0x60]
     9c0:      	mov	w8, #0x1                // =1
     9c4:      	b	0x12dc <generic_retkprobe_filter_arg+0x12dc>
     9c8:      	mov	x10, xzr
     9cc:      	b	0x9f8 <generic_retkprobe_filter_arg+0x9f8>
     9d0:      	ldrh	w11, [x25]
     9d4:      	mov	x10, xzr
     9d8:      	strh	w11, [sp, #0x86]
     9dc:      	ldrh	w11, [x25, #0x2]
     9e0:      	strh	w11, [sp, #0x80]
     9e4:      	ldr	x11, [x25, #0x8]
     9e8:      	str	x11, [sp, #0x60]
     9ec:      	ldr	x11, [x25, #0x10]
     9f0:      	add	x25, sp, #0x60
     9f4:      	str	x11, [sp, #0x68]
     9f8:      	mov	x22, xzr
     9fc:      	cmp	w8, #0x13
     a00:      	b.le	0xa28 <generic_retkprobe_filter_arg+0xa28>
     a04:      	cmp	w8, #0x17
     a08:      	b.gt	0xa50 <generic_retkprobe_filter_arg+0xa50>
     a0c:      	sub	w9, w8, #0x14
     a10:      	cmp	w9, #0x2
     a14:      	b.lo	0xf80 <generic_retkprobe_filter_arg+0xf80>
     a18:      	sub	w9, w8, #0x16
     a1c:      	cmp	w9, #0x2
     a20:      	b.lo	0xf6c <generic_retkprobe_filter_arg+0xf6c>
     a24:      	b	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
     a28:      	cmp	w8, #0xf
     a2c:      	b.le	0xc5c <generic_retkprobe_filter_arg+0xc5c>
     a30:      	cmp	w8, #0x11
     a34:      	b.gt	0xf5c <generic_retkprobe_filter_arg+0xf5c>
     a38:      	cmp	w8, #0x10
     a3c:      	b.eq	0xf6c <generic_retkprobe_filter_arg+0xf6c>
     a40:      	cmp	w8, #0x11
     a44:      	b.ne	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
     a48:      	ldrh	w22, [x25, #0x24]
     a4c:      	b	0x16fc <generic_retkprobe_filter_arg+0x16fc>
     a50:      	cmp	w8, #0x1b
     a54:      	b.gt	0xf94 <generic_retkprobe_filter_arg+0xf94>
     a58:      	cmp	w8, #0x18
     a5c:      	b.eq	0xfc4 <generic_retkprobe_filter_arg+0xfc4>
     a60:      	cmp	w8, #0x19
     a64:      	b.eq	0xfb8 <generic_retkprobe_filter_arg+0xfb8>
     a68:      	b	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
     a6c:      	cmp	w8, #0x21
     a70:      	b.eq	0x10a8 <generic_retkprobe_filter_arg+0x10a8>
     a74:      	cmp	w8, #0x22
     a78:      	b.ne	0x1d18 <generic_retkprobe_filter_arg+0x1d18>
     a7c:      	str	x23, [sp, #0x28]
     a80:      	mov	x22, xzr
     a84:      	mov	w23, wzr
     a88:      	add	x19, x21, #0x10
     a8c:      	ldr	w8, [x19, x22, lsl #2]
     a90:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     a94:      	add	x9, sp, #0x60
     a98:      	add	x1, sp, #0x60
     a9c:      	str	w8, [sp, #0x60]
     aa0:      	mov	w8, #0x1                // =1
     aa4:      	ldr	x0, [x0]
     aa8:      	blr	x8
     aac:      	cbz	x0, 0x1d00 <generic_retkprobe_filter_arg+0x1d00>
     ab0:      	ldr	x16, [sp, #0x50]
     ab4:      	mov	w17, #0x1               // =1
     ab8:      	cbz	w29, 0xb34 <generic_retkprobe_filter_arg+0xb34>
     abc:      	mov	x8, xzr
     ac0:      	mov	x9, x25
     ac4:      	mov	x10, x29
     ac8:      	b	0xae0 <generic_retkprobe_filter_arg+0xae0>
     acc:      	add	x8, x8, #0x1
     ad0:      	sub	x10, x10, #0x1
     ad4:      	add	x9, x9, #0x1
     ad8:      	cmp	x8, x29
     adc:      	b.eq	0xb34 <generic_retkprobe_filter_arg+0xb34>
     ae0:      	mov	x11, xzr
     ae4:      	cmp	x10, x11
     ae8:      	b.eq	0xacc <generic_retkprobe_filter_arg+0xacc>
     aec:      	ldrb	w12, [x0, x11]
     af0:      	cbz	w12, 0xb30 <generic_retkprobe_filter_arg+0xb30>
     af4:      	ldrb	w13, [x9, x11]
     af8:      	sub	w14, w13, #0x41
     afc:      	orr	w15, w13, #0x20
     b00:      	cmp	w14, #0x1a
     b04:      	sub	w14, w12, #0x41
     b08:      	csel	w13, w15, w13, lo
     b0c:      	orr	w15, w12, #0x20
     b10:      	cmp	w14, #0x1a
     b14:      	csel	w12, w15, w12, lo
     b18:      	cmp	x11, #0x62
     b1c:      	b.hi	0xacc <generic_retkprobe_filter_arg+0xacc>
     b20:      	add	x11, x11, #0x1
     b24:      	cmp	w13, w12
     b28:      	b.eq	0xae4 <generic_retkprobe_filter_arg+0xae4>
     b2c:      	b	0xacc <generic_retkprobe_filter_arg+0xacc>
     b30:      	tbz	w8, #0x1f, 0x19bc <generic_retkprobe_filter_arg+0x19bc>
     b34:      	ldr	w9, [x21, #0x8]
     b38:      	add	w8, w23, #0xc
     b3c:      	cmp	w8, w9
     b40:      	b.hs	0x1170 <generic_retkprobe_filter_arg+0x1170>
     b44:      	add	x22, x22, #0x1
     b48:      	add	w23, w23, #0x4
     b4c:      	cmp	x22, #0x64
     b50:      	b.ne	0xa8c <generic_retkprobe_filter_arg+0xa8c>
     b54:      	b	0x1170 <generic_retkprobe_filter_arg+0x1170>
     b58:      	cmp	w8, #0xc
     b5c:      	b.ne	0x17b8 <generic_retkprobe_filter_arg+0x17b8>
     b60:      	ldr	x11, [x25]
     b64:      	tst	x11, x10
     b68:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
     b6c:      	b	0x17b8 <generic_retkprobe_filter_arg+0x17b8>
     b70:      	sub	w10, w8, #0x1f
     b74:      	cmp	w10, #0x2
     b78:      	b.hs	0x13f4 <generic_retkprobe_filter_arg+0x13f4>
     b7c:      	cmp	w8, #0x1f
     b80:      	b.ne	0xc78 <generic_retkprobe_filter_arg+0xc78>
     b84:      	ldp	x11, x10, [x21, #0x10]
     b88:      	cmp	w9, #0xa
     b8c:      	b.eq	0xb98 <generic_retkprobe_filter_arg+0xb98>
     b90:      	cmp	w9, #0xc
     b94:      	b.ne	0x166c <generic_retkprobe_filter_arg+0x166c>
     b98:      	ldr	x8, [x25]
     b9c:      	cmp	x11, x8
     ba0:      	b.gt	0x1680 <generic_retkprobe_filter_arg+0x1680>
     ba4:      	cmp	x8, x10
     ba8:      	b.le	0x140 <generic_retkprobe_filter_arg+0x140>
     bac:      	b	0x1680 <generic_retkprobe_filter_arg+0x1680>
     bb0:      	ldr	w8, [x21, #0x10]
     bb4:      	str	wzr, [sp, #0x88]
     bb8:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     bbc:      	add	x9, sp, #0x60
     bc0:      	add	x1, sp, #0x60
     bc4:      	str	w8, [sp, #0x60]
     bc8:      	mov	w8, #0x1                // =1
     bcc:      	ldr	x0, [x0]
     bd0:      	blr	x8
     bd4:      	mov	x22, xzr
     bd8:      	cbz	w29, 0x1314 <generic_retkprobe_filter_arg+0x1314>
     bdc:      	cbz	x0, 0x1314 <generic_retkprobe_filter_arg+0x1314>
     be0:      	mov	x19, x0
     be4:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     be8:      	mov	w8, #0x1                // =1
     bec:      	ldr	x0, [x0]
     bf0:      	add	x9, sp, #0x88
     bf4:      	add	x1, sp, #0x88
     bf8:      	blr	x8
     bfc:      	cbz	x0, 0x130c <generic_retkprobe_filter_arg+0x130c>
     c00:      	cmp	w29, #0xff
     c04:      	mov	w8, #0xff               // =255
     c08:      	mov	x22, x0
     c0c:      	mov	x2, x25
     c10:      	csel	w1, w29, w8, lo
     c14:      	mov	x8, x0
     c18:      	lsl	w9, w1, #3
     c1c:      	str	w9, [x8], #0x4
     c20:      	mov	w9, #0x4                // =4
     c24:      	mov	x0, x8
     c28:      	blr	x9
     c2c:      	mov	w8, #0x1                // =1
     c30:      	mov	x0, x19
     c34:      	mov	x1, x22
     c38:      	blr	x8
     c3c:      	cmp	x0, #0x0
     c40:      	cset	w22, ne
     c44:      	b	0x1310 <generic_retkprobe_filter_arg+0x1310>
     c48:      	cmp	w29, #0x1, lsl #12      // =0x1000
     c4c:      	str	wzr, [sp, #0x88]
     c50:      	b.ls	0x1178 <generic_retkprobe_filter_arg+0x1178>
     c54:      	mov	x22, xzr
     c58:      	b	0x1d18 <generic_retkprobe_filter_arg+0x1d18>
     c5c:      	cmp	w8, #0xd
     c60:      	b.eq	0xfc4 <generic_retkprobe_filter_arg+0xfc4>
     c64:      	cmp	w8, #0xe
     c68:      	b.eq	0xfb8 <generic_retkprobe_filter_arg+0xfb8>
     c6c:      	cmp	w8, #0xf
     c70:      	b.eq	0xf80 <generic_retkprobe_filter_arg+0xf80>
     c74:      	b	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
     c78:      	ldp	x11, x8, [x21, #0x10]
     c7c:      	cmp	w9, #0xc
     c80:      	b.eq	0xc8c <generic_retkprobe_filter_arg+0xc8c>
     c84:      	cmp	w9, #0xa
     c88:      	b.ne	0x16b8 <generic_retkprobe_filter_arg+0x16b8>
     c8c:      	ldr	x10, [x25]
     c90:      	cmp	x11, x10
     c94:      	ccmp	x10, x8, #0x0, le
     c98:      	cset	w8, le
     c9c:      	b	0x16c8 <generic_retkprobe_filter_arg+0x16c8>
     ca0:      	cmp	w8, #0xc
     ca4:      	b.ne	0x1df4 <generic_retkprobe_filter_arg+0x1df4>
     ca8:      	ldr	w11, [x25]
     cac:      	tst	w11, w10
     cb0:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
     cb4:      	b	0x1df4 <generic_retkprobe_filter_arg+0x1df4>
     cb8:      	lsl	x9, x17, x8
     cbc:      	tst	x9, #0xc00
     cc0:      	b.ne	0x1270 <generic_retkprobe_filter_arg+0x1270>
     cc4:      	lsl	x9, x17, x8
     cc8:      	tst	x9, #0x180000000
     ccc:      	b.eq	0xc4 <generic_retkprobe_filter_arg+0xc4>
     cd0:      	cmp	w8, #0x1f
     cd4:      	b.ne	0x18f4 <generic_retkprobe_filter_arg+0x18f4>
     cd8:      	ldr	w9, [x21, #0x10]
     cdc:      	ldrb	w8, [x25]
     ce0:      	b	0xd0c <generic_retkprobe_filter_arg+0xd0c>
     ce4:      	lsl	x9, x17, x8
     ce8:      	tst	x9, #0xc00
     cec:      	b.ne	0x12a8 <generic_retkprobe_filter_arg+0x12a8>
     cf0:      	lsl	x9, x17, x8
     cf4:      	tst	x9, #0x180000000
     cf8:      	b.eq	0xc4 <generic_retkprobe_filter_arg+0xc4>
     cfc:      	cmp	w8, #0x1f
     d00:      	b.ne	0x1918 <generic_retkprobe_filter_arg+0x1918>
     d04:      	ldr	w9, [x21, #0x10]
     d08:      	ldrh	w8, [x25]
     d0c:      	cmp	w9, w8
     d10:      	b.hi	0xd20 <generic_retkprobe_filter_arg+0xd20>
     d14:      	ldr	w9, [x21, #0x14]
     d18:      	cmp	w9, w8
     d1c:      	b.hs	0x140 <generic_retkprobe_filter_arg+0x140>
     d20:      	ldr	w9, [x21, #0x8]
     d24:      	cmp	w9, #0x11
     d28:      	b.lo	0xc4 <generic_retkprobe_filter_arg+0xc4>
     d2c:      	ldr	w10, [x21, #0x18]
     d30:      	cmp	w10, w8
     d34:      	b.hi	0xd44 <generic_retkprobe_filter_arg+0xd44>
     d38:      	ldr	w10, [x21, #0x1c]
     d3c:      	cmp	w10, w8
     d40:      	b.hs	0x140 <generic_retkprobe_filter_arg+0x140>
     d44:      	cmp	w9, #0x19
     d48:      	b.lo	0xc4 <generic_retkprobe_filter_arg+0xc4>
     d4c:      	ldr	w10, [x21, #0x20]
     d50:      	cmp	w10, w8
     d54:      	b.hi	0xd64 <generic_retkprobe_filter_arg+0xd64>
     d58:      	ldr	w10, [x21, #0x24]
     d5c:      	cmp	w10, w8
     d60:      	b.hs	0x140 <generic_retkprobe_filter_arg+0x140>
     d64:      	cmp	w9, #0x21
     d68:      	b.lo	0xc4 <generic_retkprobe_filter_arg+0xc4>
     d6c:      	ldr	w9, [x21, #0x28]
     d70:      	cmp	w9, w8
     d74:      	b.hi	0xc4 <generic_retkprobe_filter_arg+0xc4>
     d78:      	ldr	w9, [x21, #0x2c]
     d7c:      	cmp	w9, w8
     d80:      	b.hs	0x140 <generic_retkprobe_filter_arg+0x140>
     d84:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
     d88:      	cmp	w9, #0xc
     d8c:      	b.eq	0xd98 <generic_retkprobe_filter_arg+0xd98>
     d90:      	cmp	w9, #0xa
     d94:      	b.ne	0x179c <generic_retkprobe_filter_arg+0x179c>
     d98:      	ldr	x11, [x25]
     d9c:      	cmp	x11, x10
     da0:      	b.gt	0x140 <generic_retkprobe_filter_arg+0x140>
     da4:      	b	0x17b8 <generic_retkprobe_filter_arg+0x17b8>
     da8:      	and	w8, w29, #0xffff
     dac:      	cmp	w8, #0x90
     db0:      	b.hi	0x1344 <generic_retkprobe_filter_arg+0x1344>
     db4:      	and	w8, w29, #0xff
     db8:      	mov	w9, #0xab               // =171
     dbc:      	tst	w29, #0xffff
     dc0:      	mul	w8, w8, w9
     dc4:      	mov	w9, #0x18               // =24
     dc8:      	lsr	w8, w8, #12
     dcc:      	msub	w8, w8, w9, w29
     dd0:      	b.eq	0xde4 <generic_retkprobe_filter_arg+0xde4>
     dd4:      	tst	w8, #0xff
     dd8:      	mov	w9, w29
     ddc:      	mov	w11, w29
     de0:      	b.eq	0xe00 <generic_retkprobe_filter_arg+0xe00>
     de4:      	sub	w8, w29, w8, uxtb
     de8:      	and	w9, w8, #0xffff
     dec:      	add	w8, w8, #0x18
     df0:      	and	w11, w8, #0xffff
     df4:      	cmp	w9, #0x78
     df8:      	b.hi	0x2390 <generic_retkprobe_filter_arg+0x2390>
     dfc:      	mov	w9, w11
     e00:      	and	w8, w9, #0xff
     e04:      	mov	w9, #0xab               // =171
     e08:      	mul	w8, w8, w9
     e0c:      	lsr	w8, w8, #12
     e10:      	sub	w10, w8, #0x1
     e14:      	b	0x23e0 <generic_retkprobe_filter_arg+0x23e0>
     e18:      	cmp	w8, #0x20
     e1c:      	b.gt	0x143c <generic_retkprobe_filter_arg+0x143c>
     e20:      	cmp	w8, #0x1a
     e24:      	b.eq	0x15cc <generic_retkprobe_filter_arg+0x15cc>
     e28:      	cmp	w8, #0x1b
     e2c:      	b.ne	0x32c4 <generic_retkprobe_filter_arg+0x32c4>
     e30:      	ldr	w8, [x21, #0x10]
     e34:      	str	wzr, [sp, #0x88]
     e38:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     e3c:      	add	x9, sp, #0x60
     e40:      	add	x1, sp, #0x60
     e44:      	mov	w19, #0x1               // =1
     e48:      	str	w8, [sp, #0x60]
     e4c:      	mov	w8, #0x1                // =1
     e50:      	ldr	x0, [x0]
     e54:      	blr	x8
     e58:      	mov	x22, xzr
     e5c:      	cbz	w25, 0x32bc <generic_retkprobe_filter_arg+0x32bc>
     e60:      	cbz	x0, 0x32bc <generic_retkprobe_filter_arg+0x32bc>
     e64:      	mov	x22, x0
     e68:      	adrp	x0, 0x0 <generic_retkprobe_filter_arg>
     e6c:      	mov	w8, #0x1                // =1
     e70:      	ldr	x0, [x0]
     e74:      	add	x9, sp, #0x88
     e78:      	add	x1, sp, #0x88
     e7c:      	blr	x8
     e80:      	cbz	x0, 0x32b8 <generic_retkprobe_filter_arg+0x32b8>
     e84:      	cmp	w25, #0x7f
     e88:      	mov	w9, #0x7f               // =127
     e8c:      	mov	x1, x0
     e90:      	mov	x8, xzr
     e94:      	sub	x11, x19, x25
     e98:      	sub	w12, w25, #0x2
     e9c:      	sub	w13, w25, #0x1
     ea0:      	csel	w9, w25, w9, lo
     ea4:      	lsl	w10, w9, #3
     ea8:      	mov	x9, x0
     eac:      	str	w10, [x9], #0x5
     eb0:      	neg	x10, x25
     eb4:      	add	w14, w13, w8
     eb8:      	cmp	x11, x8
     ebc:      	and	x14, x14, #0xfff
     ec0:      	ldrb	w14, [x29, x14]
     ec4:      	sturb	w14, [x9, #-0x1]
     ec8:      	b.eq	0xef0 <generic_retkprobe_filter_arg+0xef0>
     ecc:      	cmn	x8, #0x7e
     ed0:      	b.eq	0xef0 <generic_retkprobe_filter_arg+0xef0>
     ed4:      	add	w14, w12, w8
     ed8:      	sub	x8, x8, #0x2
     edc:      	and	x14, x14, #0xfff
     ee0:      	cmp	x10, x8
     ee4:      	ldrb	w14, [x29, x14]
     ee8:      	strb	w14, [x9], #0x2
     eec:      	b.ne	0xeb4 <generic_retkprobe_filter_arg+0xeb4>
     ef0:      	mov	w8, #0x1                // =1
     ef4:      	mov	x0, x22
     ef8:      	b	0x32a8 <generic_retkprobe_filter_arg+0x32a8>
     efc:      	mov	x22, xzr
     f00:      	ldr	x0, [sp, #0x38]
     f04:      	ldp	x12, x16, [sp, #0x48]
     f08:      	mov	w17, #0x1               // =1
     f0c:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
     f10:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
     f14:      	ldp	w11, w8, [x21, #0x10]
     f18:      	cmp	w9, #0xc
     f1c:      	b.hi	0x1a98 <generic_retkprobe_filter_arg+0x1a98>
     f20:      	lsl	w10, w17, w9
     f24:      	mov	w12, #0x1402            // =5122
     f28:      	tst	w10, w12
     f2c:      	b.eq	0x1a98 <generic_retkprobe_filter_arg+0x1a98>
     f30:      	ldr	w10, [x25]
     f34:      	cmp	w11, w10
     f38:      	ccmp	w10, w8, #0x0, le
     f3c:      	cset	w8, le
     f40:      	b	0x1aa8 <generic_retkprobe_filter_arg+0x1aa8>
     f44:      	cmp	w8, #0x1c
     f48:      	b.eq	0x1578 <generic_retkprobe_filter_arg+0x1578>
     f4c:      	mov	x25, x10
     f50:      	cmp	w8, #0x1a
     f54:      	b.eq	0x14c0 <generic_retkprobe_filter_arg+0x14c0>
     f58:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
     f5c:      	cmp	w8, #0x12
     f60:      	b.eq	0xf80 <generic_retkprobe_filter_arg+0xf80>
     f64:      	cmp	w8, #0x13
     f68:      	b.ne	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
     f6c:      	ldrh	w29, [x25, #0x22]
     f70:      	mov	w11, wzr
     f74:      	mov	w13, wzr
     f78:      	mov	x19, xzr
     f7c:      	b	0xfd0 <generic_retkprobe_filter_arg+0xfd0>
     f80:      	ldrh	w29, [x25, #0x20]
     f84:      	mov	w11, wzr
     f88:      	mov	w13, wzr
     f8c:      	mov	x19, xzr
     f90:      	b	0xfd0 <generic_retkprobe_filter_arg+0xfd0>
     f94:      	cmp	w8, #0x1c
     f98:      	b.eq	0x16f8 <generic_retkprobe_filter_arg+0x16f8>
     f9c:      	cmp	w8, #0x1d
     fa0:      	b.ne	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
     fa4:      	cmp	w9, #0x7
     fa8:      	b.ne	0x1c54 <generic_retkprobe_filter_arg+0x1c54>
     fac:      	cbnz	x10, 0x1c64 <generic_retkprobe_filter_arg+0x1c64>
     fb0:      	mov	x19, xzr
     fb4:      	b	0x1c78 <generic_retkprobe_filter_arg+0x1c78>
     fb8:      	ldp	w11, w13, [x25, #0x10]
     fbc:      	ldr	x19, [x25, #0x18]
     fc0:      	b	0xfcc <generic_retkprobe_filter_arg+0xfcc>
     fc4:      	ldp	w11, w13, [x25]
     fc8:      	ldr	x19, [x25, #0x8]
     fcc:      	mov	x29, xzr
     fd0:      	mov	x22, xzr
     fd4:      	cmp	w8, #0x11
     fd8:      	b.gt	0x1004 <generic_retkprobe_filter_arg+0x1004>
     fdc:      	sub	w9, w8, #0xd
     fe0:      	cmp	w9, #0x2
     fe4:      	b.lo	0x1030 <generic_retkprobe_filter_arg+0x1030>
     fe8:      	ldr	x19, [sp, #0x30]
     fec:      	sub	w9, w8, #0xf
     ff0:      	cmp	w9, #0x2
     ff4:      	b.lo	0x11f8 <generic_retkprobe_filter_arg+0x11f8>
     ff8:      	cmp	w8, #0x11
     ffc:      	b.eq	0x16fc <generic_retkprobe_filter_arg+0x16fc>
    1000:      	b	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    1004:      	cmp	w8, #0x19
    1008:      	b.hi	0x11e8 <generic_retkprobe_filter_arg+0x11e8>
    100c:      	lsl	w9, w17, w8
    1010:      	mov	w10, #0x500000          // =5242880
    1014:      	tst	w9, w10
    1018:      	b.ne	0x12e4 <generic_retkprobe_filter_arg+0x12e4>
    101c:      	mov	w10, #0xa00000          // =10485760
    1020:      	tst	w9, w10
    1024:      	b.ne	0x12f8 <generic_retkprobe_filter_arg+0x12f8>
    1028:      	tst	w9, #0x3000000
    102c:      	b.eq	0x11e8 <generic_retkprobe_filter_arg+0x11e8>
    1030:      	ldrh	w8, [x25, #0x26]
    1034:      	cmp	w8, #0xa
    1038:      	b.eq	0x1354 <generic_retkprobe_filter_arg+0x1354>
    103c:      	cmp	w8, #0x2
    1040:      	b.ne	0x13e0 <generic_retkprobe_filter_arg+0x13e0>
    1044:      	ldr	w8, [x21, #0x10]
    1048:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    104c:      	add	x9, sp, #0xac
    1050:      	add	x1, sp, #0xac
    1054:      	str	w8, [sp, #0xac]
    1058:      	mov	w8, #0x1                // =1
    105c:      	mov	w22, w11
    1060:      	ldr	x0, [x0]
    1064:      	blr	x8
    1068:      	ldr	x19, [sp, #0x30]
    106c:      	cbz	x0, 0x1d88 <generic_retkprobe_filter_arg+0x1d88>
    1070:      	mov	w8, #0x20               // =32
    1074:      	add	x1, sp, #0x88
    1078:      	stp	w8, w22, [sp, #0x88]
    107c:      	b	0x139c <generic_retkprobe_filter_arg+0x139c>
    1080:      	cmp	w9, #0xc
    1084:      	b.hi	0x1dd8 <generic_retkprobe_filter_arg+0x1dd8>
    1088:      	lsl	w11, w17, w9
    108c:      	mov	w13, #0x1402            // =5122
    1090:      	tst	w11, w13
    1094:      	b.eq	0x1dd8 <generic_retkprobe_filter_arg+0x1dd8>
    1098:      	ldr	w11, [x25]
    109c:      	cmp	w11, w10
    10a0:      	b.gt	0x140 <generic_retkprobe_filter_arg+0x140>
    10a4:      	b	0x1df4 <generic_retkprobe_filter_arg+0x1df4>
    10a8:      	str	x23, [sp, #0x28]
    10ac:      	mov	x19, xzr
    10b0:      	mov	w22, wzr
    10b4:      	add	x23, x21, #0x10
    10b8:      	ldr	w8, [x23, x19, lsl #2]
    10bc:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    10c0:      	add	x9, sp, #0x60
    10c4:      	add	x1, sp, #0x60
    10c8:      	str	w8, [sp, #0x60]
    10cc:      	mov	w8, #0x1                // =1
    10d0:      	ldr	x0, [x0]
    10d4:      	blr	x8
    10d8:      	cbz	x0, 0x1cec <generic_retkprobe_filter_arg+0x1cec>
    10dc:      	ldr	x16, [sp, #0x50]
    10e0:      	mov	w17, #0x1               // =1
    10e4:      	cbz	w29, 0x1150 <generic_retkprobe_filter_arg+0x1150>
    10e8:      	mov	x8, xzr
    10ec:      	mov	x9, x25
    10f0:      	mov	x10, x29
    10f4:      	b	0x110c <generic_retkprobe_filter_arg+0x110c>
    10f8:      	add	x8, x8, #0x1
    10fc:      	sub	x10, x10, #0x1
    1100:      	add	x9, x9, #0x1
    1104:      	cmp	x8, x29
    1108:      	b.eq	0x1150 <generic_retkprobe_filter_arg+0x1150>
    110c:      	mov	x11, xzr
    1110:      	nop
    1114:      	nop
    1118:      	nop
    111c:      	nop
    1120:      	cmp	x10, x11
    1124:      	b.eq	0x10f8 <generic_retkprobe_filter_arg+0x10f8>
    1128:      	ldrb	w12, [x0, x11]
    112c:      	cbz	w12, 0x114c <generic_retkprobe_filter_arg+0x114c>
    1130:      	cmp	x11, #0x62
    1134:      	b.hi	0x10f8 <generic_retkprobe_filter_arg+0x10f8>
    1138:      	ldrb	w13, [x9, x11]
    113c:      	add	x11, x11, #0x1
    1140:      	cmp	w13, w12
    1144:      	b.eq	0x1120 <generic_retkprobe_filter_arg+0x1120>
    1148:      	b	0x10f8 <generic_retkprobe_filter_arg+0x10f8>
    114c:      	tbz	w8, #0x1f, 0x19bc <generic_retkprobe_filter_arg+0x19bc>
    1150:      	ldr	w9, [x21, #0x8]
    1154:      	add	w8, w22, #0xc
    1158:      	cmp	w8, w9
    115c:      	b.hs	0x1170 <generic_retkprobe_filter_arg+0x1170>
    1160:      	add	x19, x19, #0x1
    1164:      	add	w22, w22, #0x4
    1168:      	cmp	x19, #0x64
    116c:      	b.ne	0x10b8 <generic_retkprobe_filter_arg+0x10b8>
    1170:      	mov	x22, xzr
    1174:      	b	0x1d0c <generic_retkprobe_filter_arg+0x1d0c>
    1178:      	and	w8, w29, #0xffff
    117c:      	cmp	w8, #0x90
    1180:      	b.hi	0x178c <generic_retkprobe_filter_arg+0x178c>
    1184:      	and	w8, w29, #0xff
    1188:      	mov	w9, #0xab               // =171
    118c:      	tst	w29, #0xffff
    1190:      	mul	w8, w8, w9
    1194:      	mov	w9, #0x18               // =24
    1198:      	lsr	w8, w8, #12
    119c:      	msub	w8, w8, w9, w29
    11a0:      	b.eq	0x11b4 <generic_retkprobe_filter_arg+0x11b4>
    11a4:      	tst	w8, #0xff
    11a8:      	mov	w9, w29
    11ac:      	mov	w11, w29
    11b0:      	b.eq	0x11d0 <generic_retkprobe_filter_arg+0x11d0>
    11b4:      	sub	w8, w29, w8, uxtb
    11b8:      	and	w9, w8, #0xffff
    11bc:      	add	w8, w8, #0x18
    11c0:      	and	w11, w8, #0xffff
    11c4:      	cmp	w9, #0x78
    11c8:      	b.hi	0x2850 <generic_retkprobe_filter_arg+0x2850>
    11cc:      	mov	w9, w11
    11d0:      	and	w8, w9, #0xff
    11d4:      	mov	w9, #0xab               // =171
    11d8:      	mul	w8, w8, w9
    11dc:      	lsr	w8, w8, #12
    11e0:      	sub	w10, w8, #0x1
    11e4:      	b	0x28a0 <generic_retkprobe_filter_arg+0x28a0>
    11e8:      	ldr	x19, [sp, #0x30]
    11ec:      	sub	w8, w8, #0x12
    11f0:      	cmp	w8, #0x2
    11f4:      	b.hs	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    11f8:      	ldrb	w8, [x21, #0x10]
    11fc:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    1200:      	add	x9, sp, #0xac
    1204:      	add	x1, sp, #0xac
    1208:      	str	w8, [sp, #0xac]
    120c:      	mov	w8, #0x1                // =1
    1210:      	ldr	x0, [x0]
    1214:      	blr	x8
    1218:      	cbz	x0, 0x1cd4 <generic_retkprobe_filter_arg+0x1cd4>
    121c:      	str	x29, [sp, #0x88]
    1220:      	mov	w8, #0x1                // =1
    1224:      	add	x9, sp, #0x88
    1228:      	add	x1, sp, #0x88
    122c:      	b	0x1730 <generic_retkprobe_filter_arg+0x1730>
    1230:      	cmp	w8, #0x1
    1234:      	b.eq	0x19c4 <generic_retkprobe_filter_arg+0x19c4>
    1238:      	cmp	w8, #0x2
    123c:      	b.ne	0x19d0 <generic_retkprobe_filter_arg+0x19d0>
    1240:      	ldrb	w10, [x25]
    1244:      	cmp	w9, w10
    1248:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    124c:      	b	0x19d0 <generic_retkprobe_filter_arg+0x19d0>
    1250:      	cmp	w8, #0x1
    1254:      	b.eq	0x1a04 <generic_retkprobe_filter_arg+0x1a04>
    1258:      	cmp	w8, #0x2
    125c:      	b.ne	0x1a10 <generic_retkprobe_filter_arg+0x1a10>
    1260:      	ldrh	w10, [x25]
    1264:      	cmp	w9, w10
    1268:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    126c:      	b	0x1a10 <generic_retkprobe_filter_arg+0x1a10>
    1270:      	ldrb	w8, [x21, #0x10]
    1274:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    1278:      	add	x9, sp, #0x88
    127c:      	add	x1, sp, #0x88
    1280:      	str	w8, [sp, #0x88]
    1284:      	mov	w8, #0x1                // =1
    1288:      	ldr	x0, [x0]
    128c:      	blr	x8
    1290:      	cbz	x0, 0x1cd4 <generic_retkprobe_filter_arg+0x1cd4>
    1294:      	ldrb	w8, [x25]
    1298:      	add	x9, sp, #0x60
    129c:      	str	x8, [sp, #0x60]
    12a0:      	mov	w8, #0x1                // =1
    12a4:      	b	0x12dc <generic_retkprobe_filter_arg+0x12dc>
    12a8:      	ldrb	w8, [x21, #0x10]
    12ac:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    12b0:      	add	x9, sp, #0x88
    12b4:      	add	x1, sp, #0x88
    12b8:      	str	w8, [sp, #0x88]
    12bc:      	mov	w8, #0x1                // =1
    12c0:      	ldr	x0, [x0]
    12c4:      	blr	x8
    12c8:      	cbz	x0, 0x1cd4 <generic_retkprobe_filter_arg+0x1cd4>
    12cc:      	ldrh	w8, [x25]
    12d0:      	add	x9, sp, #0x60
    12d4:      	str	x8, [sp, #0x60]
    12d8:      	mov	w8, #0x1                // =1
    12dc:      	add	x1, sp, #0x60
    12e0:      	b	0x1730 <generic_retkprobe_filter_arg+0x1730>
    12e4:      	ldr	x19, [sp, #0x30]
    12e8:      	cmp	x29, #0x400
    12ec:      	cset	w22, lo
    12f0:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    12f4:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    12f8:      	ldr	x19, [sp, #0x30]
    12fc:      	cmp	x29, #0x3ff
    1300:      	cset	w22, hi
    1304:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    1308:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    130c:      	mov	x22, xzr
    1310:      	ldr	x19, [sp, #0x30]
    1314:      	ldr	x0, [sp, #0x38]
    1318:      	ldp	x12, x16, [sp, #0x48]
    131c:      	mov	w17, #0x1               // =1
    1320:      	b	0x1d18 <generic_retkprobe_filter_arg+0x1d18>
    1324:      	cmp	x0, #0x0
    1328:      	ldr	x0, [sp, #0x38]
    132c:      	ldp	x12, x16, [sp, #0x48]
    1330:      	mov	w17, #0x1               // =1
    1334:      	cset	w8, eq
    1338:      	mov	w22, w8
    133c:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    1340:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    1344:      	cmp	w8, #0x101
    1348:      	b.hs	0x19a0 <generic_retkprobe_filter_arg+0x19a0>
    134c:      	mov	w11, #0x100             // =256
    1350:      	b	0x2390 <generic_retkprobe_filter_arg+0x2390>
    1354:      	ldr	w8, [x21, #0x14]
    1358:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    135c:      	add	x9, sp, #0xac
    1360:      	add	x1, sp, #0xac
    1364:      	str	w8, [sp, #0xac]
    1368:      	mov	w8, #0x1                // =1
    136c:      	mov	w25, w13
    1370:      	mov	w22, w11
    1374:      	ldr	x0, [x0]
    1378:      	blr	x8
    137c:      	cbz	x0, 0x1db0 <generic_retkprobe_filter_arg+0x1db0>
    1380:      	mov	w8, #0x80               // =128
    1384:      	stp	w25, w19, [sp, #0x90]
    1388:      	add	x1, sp, #0x88
    138c:      	stp	w8, w22, [sp, #0x88]
    1390:      	lsr	x8, x19, #32
    1394:      	ldr	x19, [sp, #0x30]
    1398:      	str	w8, [sp, #0x98]
    139c:      	mov	w8, #0x1                // =1
    13a0:      	blr	x8
    13a4:      	ldr	w8, [x21, #0x4]
    13a8:      	sub	w9, w8, #0x18
    13ac:      	cmp	w9, #0x2
    13b0:      	b.lo	0x19b4 <generic_retkprobe_filter_arg+0x19b4>
    13b4:      	ldp	x12, x16, [sp, #0x48]
    13b8:      	sub	w8, w8, #0xd
    13bc:      	mov	w17, #0x1               // =1
    13c0:      	cmp	w8, #0x1
    13c4:      	b.hi	0x1f54 <generic_retkprobe_filter_arg+0x1f54>
    13c8:      	cmp	x0, #0x0
    13cc:      	ldr	x0, [sp, #0x38]
    13d0:      	cset	w8, ne
    13d4:      	mov	w22, w8
    13d8:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    13dc:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    13e0:      	ldr	x19, [sp, #0x30]
    13e4:      	mov	w8, wzr
    13e8:      	mov	w22, wzr
    13ec:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    13f0:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    13f4:      	cmp	w8, #0x1e
    13f8:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    13fc:      	ldr	w8, [x21, #0x10]
    1400:      	mov	w10, #0x5ea0            // =24224
    1404:      	and	x8, x8, #0x7
    1408:      	add	x9, x20, x8, lsl #2
    140c:      	ldr	w9, [x9, x10]
    1410:      	cbnz	w9, 0xc4 <generic_retkprobe_filter_arg+0xc4>
    1414:      	add	x8, x20, x8, lsl #3
    1418:      	ldr	x9, [x25]
    141c:      	ldr	x8, [x8, #0x5e78]
    1420:      	and	x8, x8, #0x7ff
    1424:      	add	x8, x20, x8
    1428:      	ldr	x8, [x8, #0x90]
    142c:      	bics	xzr, x8, x9
    1430:      	cset	w22, ne
    1434:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    1438:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    143c:      	cmp	w8, #0x21
    1440:      	b.eq	0x1ae0 <generic_retkprobe_filter_arg+0x1ae0>
    1444:      	cmp	w8, #0x22
    1448:      	b.ne	0x32c4 <generic_retkprobe_filter_arg+0x32c4>
    144c:      	mov	w19, #0x10              // =16
    1450:      	ldr	w8, [x21, x19]
    1454:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    1458:      	add	x9, sp, #0x60
    145c:      	add	x1, sp, #0x60
    1460:      	str	w8, [sp, #0x60]
    1464:      	mov	w8, #0x1                // =1
    1468:      	ldr	x0, [x0]
    146c:      	blr	x8
    1470:      	cbz	x0, 0x32b8 <generic_retkprobe_filter_arg+0x32b8>
    1474:      	mov	x1, x0
    1478:      	mov	x0, x29
    147c:      	mov	x2, x25
    1480:      	bl	0x1480 <generic_retkprobe_filter_arg+0x1480>
    1484:      	tbz	w0, #0x1f, 0x2674 <generic_retkprobe_filter_arg+0x2674>
    1488:      	ldr	w8, [x21, #0x8]
    148c:      	ldp	x12, x16, [sp, #0x48]
    1490:      	add	x19, x19, #0x4
    1494:      	mov	w17, #0x1               // =1
    1498:      	mov	x22, xzr
    149c:      	sub	w9, w19, #0x8
    14a0:      	cmp	w9, w8
    14a4:      	b.hs	0x32c4 <generic_retkprobe_filter_arg+0x32c4>
    14a8:      	cmp	x19, #0x1a0
    14ac:      	b.ne	0x1450 <generic_retkprobe_filter_arg+0x1450>
    14b0:      	b	0x32c4 <generic_retkprobe_filter_arg+0x32c4>
    14b4:      	mov	x25, x10
    14b8:      	cmp	w8, #0x8
    14bc:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    14c0:      	ldr	w8, [x21, #0x10]
    14c4:      	str	wzr, [sp, #0x88]
    14c8:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    14cc:      	add	x9, sp, #0x60
    14d0:      	add	x1, sp, #0x60
    14d4:      	str	w8, [sp, #0x60]
    14d8:      	mov	w8, #0x1                // =1
    14dc:      	ldr	x0, [x0]
    14e0:      	blr	x8
    14e4:      	mov	x22, xzr
    14e8:      	cbz	w29, 0x1ed0 <generic_retkprobe_filter_arg+0x1ed0>
    14ec:      	cbz	x0, 0x1ed0 <generic_retkprobe_filter_arg+0x1ed0>
    14f0:      	mov	x19, x0
    14f4:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    14f8:      	mov	w8, #0x1                // =1
    14fc:      	ldr	x0, [x0]
    1500:      	add	x9, sp, #0x88
    1504:      	add	x1, sp, #0x88
    1508:      	blr	x8
    150c:      	cbz	x0, 0x1ec8 <generic_retkprobe_filter_arg+0x1ec8>
    1510:      	lsl	w9, w29, #3
    1514:      	mov	x8, x0
    1518:      	mov	x2, x25
    151c:      	mov	w1, w29
    1520:      	str	w9, [x8], #0x4
    1524:      	mov	w9, #0x4                // =4
    1528:      	mov	x25, x0
    152c:      	mov	x0, x8
    1530:      	blr	x9
    1534:      	mov	w8, #0x1                // =1
    1538:      	mov	x0, x19
    153c:      	mov	x1, x25
    1540:      	blr	x8
    1544:      	cmp	x0, #0x0
    1548:      	cset	w22, ne
    154c:      	b	0x1ecc <generic_retkprobe_filter_arg+0x1ecc>
    1550:      	mov	w13, #0x100             // =256
    1554:      	sub	w8, w13, #0x100
    1558:      	ror	w8, w8, #0x8
    155c:      	cmp	w8, #0x2
    1560:      	b.gt	0x1988 <generic_retkprobe_filter_arg+0x1988>
    1564:      	cbz	w8, 0x1fc4 <generic_retkprobe_filter_arg+0x1fc4>
    1568:      	cmp	w8, #0x1
    156c:      	b.ne	0x1fbc <generic_retkprobe_filter_arg+0x1fbc>
    1570:      	mov	w11, #0x7               // =7
    1574:      	b	0x1fd0 <generic_retkprobe_filter_arg+0x1fd0>
    1578:      	ldrb	w8, [x21, #0x10]
    157c:      	ldrh	w19, [x25]
    1580:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    1584:      	add	x9, sp, #0x88
    1588:      	add	x1, sp, #0x88
    158c:      	str	w8, [sp, #0x88]
    1590:      	mov	w8, #0x1                // =1
    1594:      	ldr	x0, [x0]
    1598:      	blr	x8
    159c:      	cbz	x0, 0x1cd0 <generic_retkprobe_filter_arg+0x1cd0>
    15a0:      	str	x19, [sp, #0x60]
    15a4:      	mov	w8, #0x1                // =1
    15a8:      	add	x9, sp, #0x60
    15ac:      	add	x1, sp, #0x60
    15b0:      	blr	x8
    15b4:      	ldr	w9, [x21, #0x4]
    15b8:      	mov	w8, wzr
    15bc:      	cmp	w9, #0x1d
    15c0:      	b.hi	0x1cc0 <generic_retkprobe_filter_arg+0x1cc0>
    15c4:      	ldr	x19, [sp, #0x30]
    15c8:      	b	0x1744 <generic_retkprobe_filter_arg+0x1744>
    15cc:      	ldr	w8, [x21, #0x10]
    15d0:      	str	wzr, [sp, #0x88]
    15d4:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    15d8:      	add	x9, sp, #0x60
    15dc:      	add	x1, sp, #0x60
    15e0:      	str	w8, [sp, #0x60]
    15e4:      	mov	w8, #0x1                // =1
    15e8:      	ldr	x0, [x0]
    15ec:      	blr	x8
    15f0:      	mov	x22, xzr
    15f4:      	cbz	w25, 0x32bc <generic_retkprobe_filter_arg+0x32bc>
    15f8:      	cbz	x0, 0x32bc <generic_retkprobe_filter_arg+0x32bc>
    15fc:      	mov	x19, x0
    1600:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    1604:      	mov	w8, #0x1                // =1
    1608:      	ldr	x0, [x0]
    160c:      	add	x9, sp, #0x88
    1610:      	add	x1, sp, #0x88
    1614:      	blr	x8
    1618:      	cbz	x0, 0x32b8 <generic_retkprobe_filter_arg+0x32b8>
    161c:      	cmp	w25, #0xff
    1620:      	mov	w8, #0xff               // =255
    1624:      	mov	x22, x0
    1628:      	mov	x2, x29
    162c:      	csel	w1, w25, w8, lo
    1630:      	mov	x8, x0
    1634:      	lsl	w9, w1, #3
    1638:      	str	w9, [x8], #0x4
    163c:      	mov	w9, #0x4                // =4
    1640:      	mov	x0, x8
    1644:      	blr	x9
    1648:      	mov	w8, #0x1                // =1
    164c:      	mov	x0, x19
    1650:      	mov	x1, x22
    1654:      	b	0x32a8 <generic_retkprobe_filter_arg+0x32a8>
    1658:      	cmp	w25, #0x1, lsl #12      // =0x1000
    165c:      	str	wzr, [sp, #0x88]
    1660:      	b.ls	0x1ba8 <generic_retkprobe_filter_arg+0x1ba8>
    1664:      	mov	x22, xzr
    1668:      	b	0x32c4 <generic_retkprobe_filter_arg+0x32c4>
    166c:      	ldr	x8, [x25]
    1670:      	cmp	x11, x8
    1674:      	b.hi	0x1680 <generic_retkprobe_filter_arg+0x1680>
    1678:      	cmp	x8, x10
    167c:      	b.ls	0x140 <generic_retkprobe_filter_arg+0x140>
    1680:      	ldr	w10, [x21, #0x8]
    1684:      	cmp	w10, #0x19
    1688:      	b.lo	0xc4 <generic_retkprobe_filter_arg+0xc4>
    168c:      	ldp	x12, x11, [x21, #0x20]
    1690:      	cmp	w9, #0xc
    1694:      	b.eq	0x16a0 <generic_retkprobe_filter_arg+0x16a0>
    1698:      	cmp	w9, #0xa
    169c:      	b.ne	0x1d40 <generic_retkprobe_filter_arg+0x1d40>
    16a0:      	cmp	x12, x8
    16a4:      	ldr	x12, [sp, #0x48]
    16a8:      	b.gt	0x1d54 <generic_retkprobe_filter_arg+0x1d54>
    16ac:      	cmp	x8, x11
    16b0:      	b.le	0x140 <generic_retkprobe_filter_arg+0x140>
    16b4:      	b	0x1d54 <generic_retkprobe_filter_arg+0x1d54>
    16b8:      	ldr	x10, [x25]
    16bc:      	cmp	x11, x10
    16c0:      	ccmp	x10, x8, #0x2, ls
    16c4:      	cset	w8, ls
    16c8:      	ldr	w11, [x21, #0x8]
    16cc:      	cmp	w11, #0x19
    16d0:      	b.lo	0x2aa0 <generic_retkprobe_filter_arg+0x2aa0>
    16d4:      	ldp	x13, x12, [x21, #0x20]
    16d8:      	cmp	w9, #0xc
    16dc:      	b.eq	0x16e8 <generic_retkprobe_filter_arg+0x16e8>
    16e0:      	cmp	w9, #0xa
    16e4:      	b.ne	0x1c18 <generic_retkprobe_filter_arg+0x1c18>
    16e8:      	cmp	x13, x10
    16ec:      	ccmp	x10, x12, #0x0, le
    16f0:      	cset	w12, le
    16f4:      	b	0x1c24 <generic_retkprobe_filter_arg+0x1c24>
    16f8:      	ldrh	w22, [x25, #0x26]
    16fc:      	ldrb	w8, [x21, #0x10]
    1700:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    1704:      	add	x9, sp, #0xac
    1708:      	add	x1, sp, #0xac
    170c:      	str	w8, [sp, #0xac]
    1710:      	mov	w8, #0x1                // =1
    1714:      	ldr	x0, [x0]
    1718:      	blr	x8
    171c:      	cbz	x0, 0x1cd4 <generic_retkprobe_filter_arg+0x1cd4>
    1720:      	str	x22, [sp, #0x88]
    1724:      	mov	w8, #0x1                // =1
    1728:      	add	x9, sp, #0x88
    172c:      	add	x1, sp, #0x88
    1730:      	blr	x8
    1734:      	ldr	w9, [x21, #0x4]
    1738:      	mov	w8, wzr
    173c:      	cmp	w9, #0x1d
    1740:      	b.hi	0x1cc4 <generic_retkprobe_filter_arg+0x1cc4>
    1744:      	mov	w17, #0x1               // =1
    1748:      	mov	w10, #0x8400            // =33792
    174c:      	lsl	w9, w17, w9
    1750:      	movk	w10, #0x3003, lsl #16
    1754:      	tst	w9, w10
    1758:      	ldp	x12, x16, [sp, #0x48]
    175c:      	b.eq	0x176c <generic_retkprobe_filter_arg+0x176c>
    1760:      	cmp	x0, #0x0
    1764:      	cset	w8, ne
    1768:      	b	0x1784 <generic_retkprobe_filter_arg+0x1784>
    176c:      	mov	w10, #0x800             // =2048
    1770:      	movk	w10, #0xc, lsl #16
    1774:      	tst	w9, w10
    1778:      	b.eq	0x1784 <generic_retkprobe_filter_arg+0x1784>
    177c:      	cmp	x0, #0x0
    1780:      	cset	w8, eq
    1784:      	mov	w22, w8
    1788:      	b	0x1ce0 <generic_retkprobe_filter_arg+0x1ce0>
    178c:      	cmp	w8, #0x101
    1790:      	b.hs	0x1eb4 <generic_retkprobe_filter_arg+0x1eb4>
    1794:      	mov	w11, #0x100             // =256
    1798:      	b	0x2850 <generic_retkprobe_filter_arg+0x2850>
    179c:      	ldr	x11, [x25]
    17a0:      	cmp	x11, x10
    17a4:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    17a8:      	b	0x17b8 <generic_retkprobe_filter_arg+0x17b8>
    17ac:      	ldr	x11, [x25]
    17b0:      	cmp	x11, x10
    17b4:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    17b8:      	ldr	w10, [x21, #0x8]
    17bc:      	cmp	w10, #0x11
    17c0:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    17c4:      	ldr	x11, [x21, #0x18]
    17c8:      	cmp	w8, #0x2
    17cc:      	b.le	0x17f0 <generic_retkprobe_filter_arg+0x17f0>
    17d0:      	sub	w12, w8, #0x3
    17d4:      	cmp	w12, #0x2
    17d8:      	b.hs	0x1824 <generic_retkprobe_filter_arg+0x1824>
    17dc:      	ldr	x12, [x25]
    17e0:      	cmp	x12, x11
    17e4:      	ldr	x12, [sp, #0x48]
    17e8:      	b.ne	0x2264 <generic_retkprobe_filter_arg+0x2264>
    17ec:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
    17f0:      	cmp	w8, #0x1
    17f4:      	b.eq	0x18d0 <generic_retkprobe_filter_arg+0x18d0>
    17f8:      	cmp	w8, #0x2
    17fc:      	b.ne	0x2264 <generic_retkprobe_filter_arg+0x2264>
    1800:      	cmp	w9, #0xc
    1804:      	b.eq	0x1810 <generic_retkprobe_filter_arg+0x1810>
    1808:      	cmp	w9, #0xa
    180c:      	b.ne	0x2254 <generic_retkprobe_filter_arg+0x2254>
    1810:      	ldr	x12, [x25]
    1814:      	cmp	x12, x11
    1818:      	ldr	x12, [sp, #0x48]
    181c:      	b.lt	0x140 <generic_retkprobe_filter_arg+0x140>
    1820:      	b	0x2264 <generic_retkprobe_filter_arg+0x2264>
    1824:      	ldr	x12, [sp, #0x48]
    1828:      	cmp	w8, #0xc
    182c:      	b.ne	0x2264 <generic_retkprobe_filter_arg+0x2264>
    1830:      	ldr	x12, [x25]
    1834:      	tst	x12, x11
    1838:      	ldr	x12, [sp, #0x48]
    183c:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    1840:      	b	0x2264 <generic_retkprobe_filter_arg+0x2264>
    1844:      	cmp	w8, #0xc
    1848:      	b.ne	0x19d0 <generic_retkprobe_filter_arg+0x19d0>
    184c:      	ldrb	w10, [x25]
    1850:      	tst	w9, w10
    1854:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    1858:      	b	0x19d0 <generic_retkprobe_filter_arg+0x19d0>
    185c:      	cmp	w8, #0xc
    1860:      	b.ne	0x1a10 <generic_retkprobe_filter_arg+0x1a10>
    1864:      	ldrh	w10, [x25]
    1868:      	tst	w9, w10
    186c:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    1870:      	b	0x1a10 <generic_retkprobe_filter_arg+0x1a10>
    1874:      	ldr	w9, [x21, #0x8]
    1878:      	cmp	w9, #0xd
    187c:      	b.lo	0x664 <generic_retkprobe_filter_arg+0x664>
    1880:      	ldr	w10, [x21, #0x14]
    1884:      	cbz	w10, 0x664 <generic_retkprobe_filter_arg+0x664>
    1888:      	cmp	w10, w8
    188c:      	b.eq	0x4a8 <generic_retkprobe_filter_arg+0x4a8>
    1890:      	cmp	w9, #0x11
    1894:      	b.lo	0x664 <generic_retkprobe_filter_arg+0x664>
    1898:      	ldr	w10, [x21, #0x18]
    189c:      	cbz	w10, 0x664 <generic_retkprobe_filter_arg+0x664>
    18a0:      	cmp	w10, w8
    18a4:      	b.eq	0x4a8 <generic_retkprobe_filter_arg+0x4a8>
    18a8:      	cmp	w9, #0x15
    18ac:      	b.lo	0x18c4 <generic_retkprobe_filter_arg+0x18c4>
    18b0:      	ldr	w9, [x21, #0x1c]
    18b4:      	cbz	w9, 0x18c4 <generic_retkprobe_filter_arg+0x18c4>
    18b8:      	cmp	w9, w8
    18bc:      	cset	w22, eq
    18c0:      	b	0x18c8 <generic_retkprobe_filter_arg+0x18c8>
    18c4:      	mov	x22, xzr
    18c8:      	ldr	x19, [sp, #0x30]
    18cc:      	b	0x2d20 <generic_retkprobe_filter_arg+0x2d20>
    18d0:      	cmp	w9, #0xc
    18d4:      	b.eq	0x18e0 <generic_retkprobe_filter_arg+0x18e0>
    18d8:      	cmp	w9, #0xa
    18dc:      	b.ne	0x2240 <generic_retkprobe_filter_arg+0x2240>
    18e0:      	ldr	x12, [x25]
    18e4:      	cmp	x12, x11
    18e8:      	ldr	x12, [sp, #0x48]
    18ec:      	b.gt	0x140 <generic_retkprobe_filter_arg+0x140>
    18f0:      	b	0x2264 <generic_retkprobe_filter_arg+0x2264>
    18f4:      	ldp	w8, w11, [x21, #0x10]
    18f8:      	ldrb	w9, [x25]
    18fc:      	cmp	w8, w9
    1900:      	ldr	w10, [x21, #0x8]
    1904:      	ccmp	w11, w9, #0x0, ls
    1908:      	cset	w8, hs
    190c:      	cmp	w10, #0x11
    1910:      	b.hs	0x1938 <generic_retkprobe_filter_arg+0x1938>
    1914:      	b	0x1980 <generic_retkprobe_filter_arg+0x1980>
    1918:      	ldp	w8, w11, [x21, #0x10]
    191c:      	ldrh	w9, [x25]
    1920:      	cmp	w8, w9
    1924:      	ldr	w10, [x21, #0x8]
    1928:      	ccmp	w11, w9, #0x0, ls
    192c:      	cset	w8, hs
    1930:      	cmp	w10, #0x11
    1934:      	b.lo	0x1980 <generic_retkprobe_filter_arg+0x1980>
    1938:      	ldp	w11, w12, [x21, #0x18]
    193c:      	cmp	w11, w9
    1940:      	ccmp	w12, w9, #0x0, ls
    1944:      	ldr	x12, [sp, #0x48]
    1948:      	csinc	w8, w8, wzr, lo
    194c:      	cmp	w10, #0x19
    1950:      	b.lo	0x1980 <generic_retkprobe_filter_arg+0x1980>
    1954:      	ldp	w11, w12, [x21, #0x20]
    1958:      	cmp	w11, w9
    195c:      	ccmp	w12, w9, #0x0, ls
    1960:      	ldr	x12, [sp, #0x48]
    1964:      	csinc	w8, w8, wzr, lo
    1968:      	cmp	w10, #0x21
    196c:      	b.lo	0x1980 <generic_retkprobe_filter_arg+0x1980>
    1970:      	ldp	w10, w11, [x21, #0x28]
    1974:      	cmp	w10, w9
    1978:      	ccmp	w11, w9, #0x0, ls
    197c:      	csinc	w8, w8, wzr, lo
    1980:      	tbz	w8, #0x0, 0x140 <generic_retkprobe_filter_arg+0x140>
    1984:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    1988:      	cmp	w8, #0x3
    198c:      	b.eq	0x1fcc <generic_retkprobe_filter_arg+0x1fcc>
    1990:      	cmp	w8, #0x7
    1994:      	b.ne	0x1fbc <generic_retkprobe_filter_arg+0x1fbc>
    1998:      	mov	w11, #0x9               // =9
    199c:      	b	0x1fd0 <generic_retkprobe_filter_arg+0x1fd0>
    19a0:      	and	w8, w29, #0xffff
    19a4:      	cmp	w8, #0x201
    19a8:      	b.hs	0x1f44 <generic_retkprobe_filter_arg+0x1f44>
    19ac:      	mov	w11, #0x200             // =512
    19b0:      	b	0x2390 <generic_retkprobe_filter_arg+0x2390>
    19b4:      	cmp	x0, #0x0
    19b8:      	b	0x1d94 <generic_retkprobe_filter_arg+0x1d94>
    19bc:      	mov	w22, #0x1               // =1
    19c0:      	b	0x1d0c <generic_retkprobe_filter_arg+0x1d0c>
    19c4:      	ldrb	w10, [x25]
    19c8:      	cmp	w9, w10
    19cc:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    19d0:      	ldr	w9, [x21, #0x8]
    19d4:      	cmp	w9, #0xd
    19d8:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    19dc:      	ldr	w10, [x21, #0x14]
    19e0:      	cmp	w8, #0x2
    19e4:      	b.le	0x1f04 <generic_retkprobe_filter_arg+0x1f04>
    19e8:      	sub	w11, w8, #0x3
    19ec:      	cmp	w11, #0x2
    19f0:      	b.hs	0x22ec <generic_retkprobe_filter_arg+0x22ec>
    19f4:      	ldrb	w11, [x25]
    19f8:      	cmp	w10, w11
    19fc:      	b.ne	0x2594 <generic_retkprobe_filter_arg+0x2594>
    1a00:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
    1a04:      	ldrh	w10, [x25]
    1a08:      	cmp	w9, w10
    1a0c:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    1a10:      	ldr	w9, [x21, #0x8]
    1a14:      	cmp	w9, #0xd
    1a18:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    1a1c:      	ldr	w10, [x21, #0x14]
    1a20:      	cmp	w8, #0x2
    1a24:      	b.le	0x1f24 <generic_retkprobe_filter_arg+0x1f24>
    1a28:      	sub	w11, w8, #0x3
    1a2c:      	cmp	w11, #0x2
    1a30:      	b.hs	0x2304 <generic_retkprobe_filter_arg+0x2304>
    1a34:      	ldrh	w11, [x25]
    1a38:      	cmp	w10, w11
    1a3c:      	b.ne	0x25d0 <generic_retkprobe_filter_arg+0x25d0>
    1a40:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
    1a44:      	ldr	w8, [x25]
    1a48:      	cmp	w11, w8
    1a4c:      	b.hi	0x1a58 <generic_retkprobe_filter_arg+0x1a58>
    1a50:      	cmp	w8, w10
    1a54:      	b.ls	0x140 <generic_retkprobe_filter_arg+0x140>
    1a58:      	ldr	w10, [x21, #0x8]
    1a5c:      	cmp	w10, #0x11
    1a60:      	b.lo	0xc4 <generic_retkprobe_filter_arg+0xc4>
    1a64:      	ldp	w12, w11, [x21, #0x18]
    1a68:      	cmp	w9, #0xc
    1a6c:      	b.hi	0x2160 <generic_retkprobe_filter_arg+0x2160>
    1a70:      	lsl	w13, w17, w9
    1a74:      	mov	w14, #0x1402            // =5122
    1a78:      	tst	w13, w14
    1a7c:      	b.eq	0x2160 <generic_retkprobe_filter_arg+0x2160>
    1a80:      	cmp	w12, w8
    1a84:      	ldr	x12, [sp, #0x48]
    1a88:      	b.gt	0x2174 <generic_retkprobe_filter_arg+0x2174>
    1a8c:      	cmp	w8, w11
    1a90:      	b.le	0x140 <generic_retkprobe_filter_arg+0x140>
    1a94:      	b	0x2174 <generic_retkprobe_filter_arg+0x2174>
    1a98:      	ldr	w10, [x25]
    1a9c:      	cmp	w11, w10
    1aa0:      	ccmp	w10, w8, #0x2, ls
    1aa4:      	cset	w8, ls
    1aa8:      	ldr	w11, [x21, #0x8]
    1aac:      	cmp	w11, #0x11
    1ab0:      	b.lo	0x2aa0 <generic_retkprobe_filter_arg+0x2aa0>
    1ab4:      	ldp	w13, w12, [x21, #0x18]
    1ab8:      	cmp	w9, #0xc
    1abc:      	b.hi	0x1f68 <generic_retkprobe_filter_arg+0x1f68>
    1ac0:      	lsl	w14, w17, w9
    1ac4:      	mov	w15, #0x1402            // =5122
    1ac8:      	tst	w14, w15
    1acc:      	b.eq	0x1f68 <generic_retkprobe_filter_arg+0x1f68>
    1ad0:      	cmp	w13, w10
    1ad4:      	ccmp	w10, w12, #0x0, le
    1ad8:      	cset	w12, le
    1adc:      	b	0x1f74 <generic_retkprobe_filter_arg+0x1f74>
    1ae0:      	str	x23, [sp, #0x28]
    1ae4:      	mov	x19, xzr
    1ae8:      	mov	w22, wzr
    1aec:      	add	x23, x21, #0x10
    1af0:      	ldr	w8, [x23, x19, lsl #2]
    1af4:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    1af8:      	add	x9, sp, #0x60
    1afc:      	add	x1, sp, #0x60
    1b00:      	str	w8, [sp, #0x60]
    1b04:      	mov	w8, #0x1                // =1
    1b08:      	ldr	x0, [x0]
    1b0c:      	blr	x8
    1b10:      	cbz	x0, 0x2600 <generic_retkprobe_filter_arg+0x2600>
    1b14:      	ldr	x16, [sp, #0x50]
    1b18:      	mov	w17, #0x1               // =1
    1b1c:      	cbz	w25, 0x1b78 <generic_retkprobe_filter_arg+0x1b78>
    1b20:      	mov	x8, xzr
    1b24:      	mov	x9, x29
    1b28:      	mov	x10, x25
    1b2c:      	b	0x1b44 <generic_retkprobe_filter_arg+0x1b44>
    1b30:      	add	x8, x8, #0x1
    1b34:      	sub	x10, x10, #0x1
    1b38:      	add	x9, x9, #0x1
    1b3c:      	cmp	x8, x25
    1b40:      	b.eq	0x1b78 <generic_retkprobe_filter_arg+0x1b78>
    1b44:      	mov	x11, xzr
    1b48:      	cmp	x10, x11
    1b4c:      	b.eq	0x1b30 <generic_retkprobe_filter_arg+0x1b30>
    1b50:      	ldrb	w12, [x0, x11]
    1b54:      	cbz	w12, 0x1b74 <generic_retkprobe_filter_arg+0x1b74>
    1b58:      	cmp	x11, #0x62
    1b5c:      	b.hi	0x1b30 <generic_retkprobe_filter_arg+0x1b30>
    1b60:      	ldrb	w13, [x9, x11]
    1b64:      	add	x11, x11, #0x1
    1b68:      	cmp	w13, w12
    1b6c:      	b.eq	0x1b48 <generic_retkprobe_filter_arg+0x1b48>
    1b70:      	b	0x1b30 <generic_retkprobe_filter_arg+0x1b30>
    1b74:      	tbz	w8, #0x1f, 0x2a80 <generic_retkprobe_filter_arg+0x2a80>
    1b78:      	ldr	w9, [x21, #0x8]
    1b7c:      	add	w8, w22, #0xc
    1b80:      	cmp	w8, w9
    1b84:      	b.hs	0x1b98 <generic_retkprobe_filter_arg+0x1b98>
    1b88:      	add	x19, x19, #0x1
    1b8c:      	add	w22, w22, #0x4
    1b90:      	cmp	x19, #0x64
    1b94:      	b.ne	0x1af0 <generic_retkprobe_filter_arg+0x1af0>
    1b98:      	ldr	x23, [sp, #0x28]
    1b9c:      	ldr	x12, [sp, #0x48]
    1ba0:      	mov	x22, xzr
    1ba4:      	b	0x32c4 <generic_retkprobe_filter_arg+0x32c4>
    1ba8:      	and	w8, w25, #0xffff
    1bac:      	cmp	w8, #0x90
    1bb0:      	b.hi	0x21b0 <generic_retkprobe_filter_arg+0x21b0>
    1bb4:      	and	w8, w25, #0xff
    1bb8:      	mov	w9, #0xab               // =171
    1bbc:      	tst	w25, #0xffff
    1bc0:      	mul	w8, w8, w9
    1bc4:      	mov	w9, #0x18               // =24
    1bc8:      	lsr	w8, w8, #12
    1bcc:      	msub	w8, w8, w9, w25
    1bd0:      	b.eq	0x1be4 <generic_retkprobe_filter_arg+0x1be4>
    1bd4:      	tst	w8, #0xff
    1bd8:      	mov	w9, w25
    1bdc:      	mov	w11, w25
    1be0:      	b.eq	0x1c00 <generic_retkprobe_filter_arg+0x1c00>
    1be4:      	sub	w8, w25, w8, uxtb
    1be8:      	and	w9, w8, #0xffff
    1bec:      	add	w8, w8, #0x18
    1bf0:      	and	w11, w8, #0xffff
    1bf4:      	cmp	w9, #0x78
    1bf8:      	b.hi	0x2f9c <generic_retkprobe_filter_arg+0x2f9c>
    1bfc:      	mov	w9, w11
    1c00:      	and	w8, w9, #0xff
    1c04:      	mov	w9, #0xab               // =171
    1c08:      	mul	w8, w8, w9
    1c0c:      	lsr	w8, w8, #12
    1c10:      	sub	w10, w8, #0x1
    1c14:      	b	0x2fec <generic_retkprobe_filter_arg+0x2fec>
    1c18:      	cmp	x13, x10
    1c1c:      	ccmp	x10, x12, #0x2, ls
    1c20:      	cset	w12, ls
    1c24:      	orr	w8, w8, w12
    1c28:      	cmp	w11, #0x29
    1c2c:      	b.lo	0x2aa0 <generic_retkprobe_filter_arg+0x2aa0>
    1c30:      	ldp	x13, x12, [x21, #0x30]
    1c34:      	cmp	w9, #0xc
    1c38:      	b.eq	0x1c44 <generic_retkprobe_filter_arg+0x1c44>
    1c3c:      	cmp	w9, #0xa
    1c40:      	b.ne	0x21c0 <generic_retkprobe_filter_arg+0x21c0>
    1c44:      	cmp	x13, x10
    1c48:      	ccmp	x10, x12, #0x0, le
    1c4c:      	cset	w12, le
    1c50:      	b	0x21cc <generic_retkprobe_filter_arg+0x21cc>
    1c54:      	mov	x19, xzr
    1c58:      	cmp	w9, #0x29
    1c5c:      	b.ne	0x1c68 <generic_retkprobe_filter_arg+0x1c68>
    1c60:      	cbz	x10, 0x1c68 <generic_retkprobe_filter_arg+0x1c68>
    1c64:      	ldrb	w19, [x10, #0x3a]
    1c68:      	cmp	w9, #0x29
    1c6c:      	b.eq	0x1c78 <generic_retkprobe_filter_arg+0x1c78>
    1c70:      	cmp	w9, #0x7
    1c74:      	b.ne	0x1fac <generic_retkprobe_filter_arg+0x1fac>
    1c78:      	ldrb	w8, [x21, #0x10]
    1c7c:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    1c80:      	add	x9, sp, #0xac
    1c84:      	add	x1, sp, #0xac
    1c88:      	str	w8, [sp, #0xac]
    1c8c:      	mov	w8, #0x1                // =1
    1c90:      	ldr	x0, [x0]
    1c94:      	blr	x8
    1c98:      	cbz	x0, 0x1cd0 <generic_retkprobe_filter_arg+0x1cd0>
    1c9c:      	str	x19, [sp, #0x88]
    1ca0:      	mov	w8, #0x1                // =1
    1ca4:      	add	x9, sp, #0x88
    1ca8:      	add	x1, sp, #0x88
    1cac:      	blr	x8
    1cb0:      	ldr	w9, [x21, #0x4]
    1cb4:      	mov	w8, wzr
    1cb8:      	cmp	w9, #0x1d
    1cbc:      	b.ls	0x15c4 <generic_retkprobe_filter_arg+0x15c4>
    1cc0:      	ldr	x19, [sp, #0x30]
    1cc4:      	ldp	x12, x16, [sp, #0x48]
    1cc8:      	mov	w17, #0x1               // =1
    1ccc:      	b	0x1784 <generic_retkprobe_filter_arg+0x1784>
    1cd0:      	ldr	x19, [sp, #0x30]
    1cd4:      	mov	x22, xzr
    1cd8:      	ldp	x12, x16, [sp, #0x48]
    1cdc:      	mov	w17, #0x1               // =1
    1ce0:      	ldr	x0, [sp, #0x38]
    1ce4:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    1ce8:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    1cec:      	ldp	x23, x19, [sp, #0x28]
    1cf0:      	mov	x22, xzr
    1cf4:      	mov	w17, #0x1               // =1
    1cf8:      	ldr	x16, [sp, #0x50]
    1cfc:      	b	0x1d10 <generic_retkprobe_filter_arg+0x1d10>
    1d00:      	ldr	x16, [sp, #0x50]
    1d04:      	mov	x22, xzr
    1d08:      	mov	w17, #0x1               // =1
    1d0c:      	ldp	x23, x19, [sp, #0x28]
    1d10:      	ldr	x0, [sp, #0x38]
    1d14:      	ldr	x12, [sp, #0x48]
    1d18:      	ldr	w8, [x21, #0x4]
    1d1c:      	cmp	w8, #0x25
    1d20:      	b.hi	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    1d24:      	mov	x9, #0x50               // =80
    1d28:      	lsl	x8, x17, x8
    1d2c:      	movk	x9, #0xc00, lsl #16
    1d30:      	movk	x9, #0x20, lsl #32
    1d34:      	tst	x8, x9
    1d38:      	b.ne	0x32f0 <generic_retkprobe_filter_arg+0x32f0>
    1d3c:      	b	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    1d40:      	cmp	x12, x8
    1d44:      	ldr	x12, [sp, #0x48]
    1d48:      	b.hi	0x1d54 <generic_retkprobe_filter_arg+0x1d54>
    1d4c:      	cmp	x8, x11
    1d50:      	b.ls	0x140 <generic_retkprobe_filter_arg+0x140>
    1d54:      	cmp	w10, #0x29
    1d58:      	b.lo	0xc4 <generic_retkprobe_filter_arg+0xc4>
    1d5c:      	ldp	x12, x11, [x21, #0x30]
    1d60:      	cmp	w9, #0xc
    1d64:      	b.eq	0x1d70 <generic_retkprobe_filter_arg+0x1d70>
    1d68:      	cmp	w9, #0xa
    1d6c:      	b.ne	0x21fc <generic_retkprobe_filter_arg+0x21fc>
    1d70:      	cmp	x12, x8
    1d74:      	ldr	x12, [sp, #0x48]
    1d78:      	b.gt	0x2210 <generic_retkprobe_filter_arg+0x2210>
    1d7c:      	cmp	x8, x11
    1d80:      	b.le	0x140 <generic_retkprobe_filter_arg+0x140>
    1d84:      	b	0x2210 <generic_retkprobe_filter_arg+0x2210>
    1d88:      	ldr	w8, [x21, #0x4]
    1d8c:      	and	w8, w8, #0xfffffffe
    1d90:      	cmp	w8, #0x18
    1d94:      	cset	w8, eq
    1d98:      	ldr	x0, [sp, #0x38]
    1d9c:      	ldp	x12, x16, [sp, #0x48]
    1da0:      	mov	w17, #0x1               // =1
    1da4:      	mov	w22, w8
    1da8:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    1dac:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    1db0:      	ldr	w8, [x21, #0x4]
    1db4:      	ldp	x19, x0, [sp, #0x30]
    1db8:      	and	w8, w8, #0xfffffffe
    1dbc:      	cmp	w8, #0x18
    1dc0:      	cset	w8, eq
    1dc4:      	ldp	x12, x16, [sp, #0x48]
    1dc8:      	mov	w17, #0x1               // =1
    1dcc:      	mov	w22, w8
    1dd0:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    1dd4:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    1dd8:      	ldr	w11, [x25]
    1ddc:      	cmp	w11, w10
    1de0:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    1de4:      	b	0x1df4 <generic_retkprobe_filter_arg+0x1df4>
    1de8:      	ldr	w11, [x25]
    1dec:      	cmp	w11, w10
    1df0:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    1df4:      	ldr	w10, [x21, #0x8]
    1df8:      	cmp	w10, #0xd
    1dfc:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    1e00:      	ldr	w11, [x21, #0x14]
    1e04:      	cmp	w8, #0x2
    1e08:      	b.le	0x1e2c <generic_retkprobe_filter_arg+0x1e2c>
    1e0c:      	sub	w12, w8, #0x3
    1e10:      	cmp	w12, #0x2
    1e14:      	b.hs	0x1e68 <generic_retkprobe_filter_arg+0x1e68>
    1e18:      	ldr	w12, [x25]
    1e1c:      	cmp	w12, w11
    1e20:      	ldr	x12, [sp, #0x48]
    1e24:      	b.ne	0x2700 <generic_retkprobe_filter_arg+0x2700>
    1e28:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
    1e2c:      	cmp	w8, #0x1
    1e30:      	b.eq	0x1e88 <generic_retkprobe_filter_arg+0x1e88>
    1e34:      	cmp	w8, #0x2
    1e38:      	b.ne	0x2700 <generic_retkprobe_filter_arg+0x2700>
    1e3c:      	cmp	w9, #0xc
    1e40:      	b.hi	0x26f0 <generic_retkprobe_filter_arg+0x26f0>
    1e44:      	lsl	w12, w17, w9
    1e48:      	mov	w13, #0x1402            // =5122
    1e4c:      	tst	w12, w13
    1e50:      	b.eq	0x26f0 <generic_retkprobe_filter_arg+0x26f0>
    1e54:      	ldr	w12, [x25]
    1e58:      	cmp	w12, w11
    1e5c:      	ldr	x12, [sp, #0x48]
    1e60:      	b.lt	0x140 <generic_retkprobe_filter_arg+0x140>
    1e64:      	b	0x2700 <generic_retkprobe_filter_arg+0x2700>
    1e68:      	ldr	x12, [sp, #0x48]
    1e6c:      	cmp	w8, #0xc
    1e70:      	b.ne	0x2700 <generic_retkprobe_filter_arg+0x2700>
    1e74:      	ldr	w12, [x25]
    1e78:      	tst	w12, w11
    1e7c:      	ldr	x12, [sp, #0x48]
    1e80:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    1e84:      	b	0x2700 <generic_retkprobe_filter_arg+0x2700>
    1e88:      	cmp	w9, #0xc
    1e8c:      	b.hi	0x26dc <generic_retkprobe_filter_arg+0x26dc>
    1e90:      	lsl	w12, w17, w9
    1e94:      	mov	w13, #0x1402            // =5122
    1e98:      	tst	w12, w13
    1e9c:      	b.eq	0x26dc <generic_retkprobe_filter_arg+0x26dc>
    1ea0:      	ldr	w12, [x25]
    1ea4:      	cmp	w12, w11
    1ea8:      	ldr	x12, [sp, #0x48]
    1eac:      	b.gt	0x140 <generic_retkprobe_filter_arg+0x140>
    1eb0:      	b	0x2700 <generic_retkprobe_filter_arg+0x2700>
    1eb4:      	and	w8, w29, #0xffff
    1eb8:      	cmp	w8, #0x201
    1ebc:      	b.hs	0x231c <generic_retkprobe_filter_arg+0x231c>
    1ec0:      	mov	w11, #0x200             // =512
    1ec4:      	b	0x2850 <generic_retkprobe_filter_arg+0x2850>
    1ec8:      	mov	x22, xzr
    1ecc:      	ldr	x19, [sp, #0x30]
    1ed0:      	ldr	w8, [x21, #0x4]
    1ed4:      	cmp	w8, #0x25
    1ed8:      	b.hi	0xf00 <generic_retkprobe_filter_arg+0xf00>
    1edc:      	mov	x9, #0x50               // =80
    1ee0:      	ldr	x0, [sp, #0x38]
    1ee4:      	ldp	x12, x16, [sp, #0x48]
    1ee8:      	mov	w17, #0x1               // =1
    1eec:      	movk	x9, #0xc00, lsl #16
    1ef0:      	lsl	x8, x17, x8
    1ef4:      	movk	x9, #0x20, lsl #32
    1ef8:      	tst	x8, x9
    1efc:      	b.ne	0x2d50 <generic_retkprobe_filter_arg+0x2d50>
    1f00:      	b	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    1f04:      	cmp	w8, #0x1
    1f08:      	b.eq	0x2588 <generic_retkprobe_filter_arg+0x2588>
    1f0c:      	cmp	w8, #0x2
    1f10:      	b.ne	0x2594 <generic_retkprobe_filter_arg+0x2594>
    1f14:      	ldrb	w11, [x25]
    1f18:      	cmp	w10, w11
    1f1c:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    1f20:      	b	0x2594 <generic_retkprobe_filter_arg+0x2594>
    1f24:      	cmp	w8, #0x1
    1f28:      	b.eq	0x25c4 <generic_retkprobe_filter_arg+0x25c4>
    1f2c:      	cmp	w8, #0x2
    1f30:      	b.ne	0x25d0 <generic_retkprobe_filter_arg+0x25d0>
    1f34:      	ldrh	w11, [x25]
    1f38:      	cmp	w10, w11
    1f3c:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    1f40:      	b	0x25d0 <generic_retkprobe_filter_arg+0x25d0>
    1f44:      	cmp	w8, #0x401
    1f48:      	b.hs	0x237c <generic_retkprobe_filter_arg+0x237c>
    1f4c:      	mov	w11, #0x400             // =1024
    1f50:      	b	0x2390 <generic_retkprobe_filter_arg+0x2390>
    1f54:      	ldr	x0, [sp, #0x38]
    1f58:      	mov	w8, wzr
    1f5c:      	mov	w22, wzr
    1f60:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    1f64:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    1f68:      	cmp	w13, w10
    1f6c:      	ccmp	w10, w12, #0x2, ls
    1f70:      	cset	w12, ls
    1f74:      	orr	w8, w8, w12
    1f78:      	cmp	w11, #0x19
    1f7c:      	b.lo	0x2aa0 <generic_retkprobe_filter_arg+0x2aa0>
    1f80:      	ldp	w13, w12, [x21, #0x20]
    1f84:      	cmp	w9, #0xc
    1f88:      	b.hi	0x2630 <generic_retkprobe_filter_arg+0x2630>
    1f8c:      	lsl	w14, w17, w9
    1f90:      	mov	w15, #0x1402            // =5122
    1f94:      	tst	w14, w15
    1f98:      	b.eq	0x2630 <generic_retkprobe_filter_arg+0x2630>
    1f9c:      	cmp	w13, w10
    1fa0:      	ccmp	w10, w12, #0x0, le
    1fa4:      	cset	w12, le
    1fa8:      	b	0x263c <generic_retkprobe_filter_arg+0x263c>
    1fac:      	ldr	x19, [sp, #0x30]
    1fb0:      	mov	x22, xzr
    1fb4:      	cbnz	xzr, 0x140 <generic_retkprobe_filter_arg+0x140>
    1fb8:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    1fbc:      	mov	w11, #0xa               // =10
    1fc0:      	b	0x1fd0 <generic_retkprobe_filter_arg+0x1fd0>
    1fc4:      	mov	w11, #0x6               // =6
    1fc8:      	b	0x1fd0 <generic_retkprobe_filter_arg+0x1fd0>
    1fcc:      	mov	w11, #0x8               // =8
    1fd0:      	add	x8, x21, #0x10
    1fd4:      	and	w9, w11, #0xf
    1fd8:      	ldr	w8, [x8, w9, uxtw #2]
    1fdc:      	cmn	w8, #0x1
    1fe0:      	b.eq	0x2090 <generic_retkprobe_filter_arg+0x2090>
    1fe4:      	str	w8, [sp, #0x10]
    1fe8:      	stp	w13, w11, [sp, #0x1c]
    1fec:      	adrp	x0, 0x1000 <generic_retkprobe_filter_arg+0x1000>
    1ff0:      	mov	w8, #0x1                // =1
    1ff4:      	add	x22, sp, #0x88
    1ff8:      	add	x1, sp, #0x88
    1ffc:      	str	x10, [sp, #0x28]
    2000:      	ldr	x0, [x0]
    2004:      	blr	x8
    2008:      	mov	x25, x0
    200c:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2010:      	mov	w8, #0x1                // =1
    2014:      	ldr	x0, [x0]
    2018:      	add	x1, sp, #0x88
    201c:      	blr	x8
    2020:      	mov	x22, xzr
    2024:      	cbz	x25, 0x2d20 <generic_retkprobe_filter_arg+0x2d20>
    2028:      	mov	x9, x0
    202c:      	ldr	x0, [sp, #0x38]
    2030:      	ldp	x12, x16, [sp, #0x48]
    2034:      	mov	w17, #0x1               // =1
    2038:      	cbz	x9, 0x2d2c <generic_retkprobe_filter_arg+0x2d2c>
    203c:      	mov	x8, x25
    2040:      	ldr	w25, [sp, #0x20]
    2044:      	mov	x22, x9
    2048:      	mov	x0, x8
    204c:      	str	x8, [sp, #0x8]
    2050:      	cmp	w25, #0x5
    2054:      	b.gt	0x20a4 <generic_retkprobe_filter_arg+0x20a4>
    2058:      	strb	w29, [x0], #0x1
    205c:      	ldr	x2, [sp, #0x28]
    2060:      	mov	w8, #0x4                // =4
    2064:      	mov	w1, w29
    2068:      	blr	x8
    206c:      	ldr	w8, [sp, #0x1c]
    2070:      	subs	w8, w8, w29
    2074:      	b.ls	0x20e0 <generic_retkprobe_filter_arg+0x20e0>
    2078:      	ldr	x9, [sp, #0x8]
    207c:      	and	w1, w8, #0xfff
    2080:      	mov	w8, #0x4                // =4
    2084:      	add	x9, x9, x29
    2088:      	add	x0, x9, #0x1
    208c:      	b	0x20d8 <generic_retkprobe_filter_arg+0x20d8>
    2090:      	mov	x22, xzr
    2094:      	ldr	w8, [x21, #0x4]
    2098:      	cmp	w8, #0x25
    209c:      	b.ls	0x2d38 <generic_retkprobe_filter_arg+0x2d38>
    20a0:      	b	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    20a4:      	strh	w29, [x0], #0x2
    20a8:      	ldr	x2, [sp, #0x28]
    20ac:      	mov	w8, #0x4                // =4
    20b0:      	mov	w1, w29
    20b4:      	blr	x8
    20b8:      	ldr	w8, [sp, #0x1c]
    20bc:      	subs	w8, w8, w29
    20c0:      	b.ls	0x20e0 <generic_retkprobe_filter_arg+0x20e0>
    20c4:      	ldr	x9, [sp, #0x8]
    20c8:      	and	w1, w8, #0xfff
    20cc:      	mov	w8, #0x4                // =4
    20d0:      	add	x9, x9, x29
    20d4:      	add	x0, x9, #0x2
    20d8:      	mov	x2, x22
    20dc:      	blr	x8
    20e0:      	ldr	w8, [sp, #0x10]
    20e4:      	ldp	x12, x16, [sp, #0x48]
    20e8:      	cmp	w25, #0x4
    20ec:      	mov	w17, #0x1               // =1
    20f0:      	str	w8, [sp, #0x60]
    20f4:      	b.le	0x212c <generic_retkprobe_filter_arg+0x212c>
    20f8:      	cmp	w25, #0x7
    20fc:      	b.gt	0x2350 <generic_retkprobe_filter_arg+0x2350>
    2100:      	cmp	w25, #0x5
    2104:      	b.eq	0x2cd4 <generic_retkprobe_filter_arg+0x2cd4>
    2108:      	cmp	w25, #0x6
    210c:      	b.eq	0x2c98 <generic_retkprobe_filter_arg+0x2c98>
    2110:      	cmp	w25, #0x7
    2114:      	b.ne	0x2d5c <generic_retkprobe_filter_arg+0x2d5c>
    2118:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    211c:      	mov	w8, #0x1                // =1
    2120:      	add	x9, sp, #0x60
    2124:      	ldr	x0, [x0]
    2128:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    212c:      	cmp	w25, #0x1
    2130:      	b.le	0x27c8 <generic_retkprobe_filter_arg+0x27c8>
    2134:      	cmp	w25, #0x2
    2138:      	b.eq	0x2cc0 <generic_retkprobe_filter_arg+0x2cc0>
    213c:      	cmp	w25, #0x3
    2140:      	b.eq	0x2c84 <generic_retkprobe_filter_arg+0x2c84>
    2144:      	cmp	w25, #0x4
    2148:      	b.ne	0x2d5c <generic_retkprobe_filter_arg+0x2d5c>
    214c:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2150:      	mov	w8, #0x1                // =1
    2154:      	add	x9, sp, #0x60
    2158:      	ldr	x0, [x0]
    215c:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    2160:      	cmp	w12, w8
    2164:      	ldr	x12, [sp, #0x48]
    2168:      	b.hi	0x2174 <generic_retkprobe_filter_arg+0x2174>
    216c:      	cmp	w8, w11
    2170:      	b.ls	0x140 <generic_retkprobe_filter_arg+0x140>
    2174:      	cmp	w10, #0x19
    2178:      	b.lo	0xc4 <generic_retkprobe_filter_arg+0xc4>
    217c:      	ldp	w12, w11, [x21, #0x20]
    2180:      	cmp	w9, #0xc
    2184:      	b.hi	0x2690 <generic_retkprobe_filter_arg+0x2690>
    2188:      	lsl	w13, w17, w9
    218c:      	mov	w14, #0x1402            // =5122
    2190:      	tst	w13, w14
    2194:      	b.eq	0x2690 <generic_retkprobe_filter_arg+0x2690>
    2198:      	cmp	w12, w8
    219c:      	ldr	x12, [sp, #0x48]
    21a0:      	b.gt	0x26a4 <generic_retkprobe_filter_arg+0x26a4>
    21a4:      	cmp	w8, w11
    21a8:      	b.le	0x140 <generic_retkprobe_filter_arg+0x140>
    21ac:      	b	0x26a4 <generic_retkprobe_filter_arg+0x26a4>
    21b0:      	cmp	w8, #0x101
    21b4:      	b.hs	0x267c <generic_retkprobe_filter_arg+0x267c>
    21b8:      	mov	w11, #0x100             // =256
    21bc:      	b	0x2f9c <generic_retkprobe_filter_arg+0x2f9c>
    21c0:      	cmp	x13, x10
    21c4:      	ccmp	x10, x12, #0x2, ls
    21c8:      	cset	w12, ls
    21cc:      	orr	w8, w8, w12
    21d0:      	cmp	w11, #0x39
    21d4:      	b.lo	0x2aa0 <generic_retkprobe_filter_arg+0x2aa0>
    21d8:      	ldp	x12, x11, [x21, #0x40]
    21dc:      	cmp	w9, #0xc
    21e0:      	b.eq	0x21ec <generic_retkprobe_filter_arg+0x21ec>
    21e4:      	cmp	w9, #0xa
    21e8:      	b.ne	0x27bc <generic_retkprobe_filter_arg+0x27bc>
    21ec:      	cmp	x12, x10
    21f0:      	ccmp	x10, x11, #0x0, le
    21f4:      	cset	w9, le
    21f8:      	b	0x2a9c <generic_retkprobe_filter_arg+0x2a9c>
    21fc:      	cmp	x12, x8
    2200:      	ldr	x12, [sp, #0x48]
    2204:      	b.hi	0x2210 <generic_retkprobe_filter_arg+0x2210>
    2208:      	cmp	x8, x11
    220c:      	b.ls	0x140 <generic_retkprobe_filter_arg+0x140>
    2210:      	cmp	w10, #0x39
    2214:      	b.lo	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2218:      	ldp	x11, x10, [x21, #0x40]
    221c:      	cmp	w9, #0xc
    2220:      	b.eq	0x222c <generic_retkprobe_filter_arg+0x222c>
    2224:      	cmp	w9, #0xa
    2228:      	b.ne	0x27e8 <generic_retkprobe_filter_arg+0x27e8>
    222c:      	cmp	x11, x8
    2230:      	b.gt	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2234:      	cmp	x8, x10
    2238:      	b.le	0x140 <generic_retkprobe_filter_arg+0x140>
    223c:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2240:      	ldr	x12, [x25]
    2244:      	cmp	x12, x11
    2248:      	ldr	x12, [sp, #0x48]
    224c:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    2250:      	b	0x2264 <generic_retkprobe_filter_arg+0x2264>
    2254:      	ldr	x12, [x25]
    2258:      	cmp	x12, x11
    225c:      	ldr	x12, [sp, #0x48]
    2260:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    2264:      	cmp	w10, #0x19
    2268:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    226c:      	ldr	x11, [x21, #0x20]
    2270:      	cmp	w8, #0x2
    2274:      	b.le	0x2298 <generic_retkprobe_filter_arg+0x2298>
    2278:      	sub	w12, w8, #0x3
    227c:      	cmp	w12, #0x2
    2280:      	b.hs	0x22cc <generic_retkprobe_filter_arg+0x22cc>
    2284:      	ldr	x12, [x25]
    2288:      	cmp	x12, x11
    228c:      	ldr	x12, [sp, #0x48]
    2290:      	b.ne	0x2ad0 <generic_retkprobe_filter_arg+0x2ad0>
    2294:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
    2298:      	cmp	w8, #0x1
    229c:      	b.eq	0x232c <generic_retkprobe_filter_arg+0x232c>
    22a0:      	cmp	w8, #0x2
    22a4:      	b.ne	0x2ad0 <generic_retkprobe_filter_arg+0x2ad0>
    22a8:      	cmp	w9, #0xc
    22ac:      	b.eq	0x22b8 <generic_retkprobe_filter_arg+0x22b8>
    22b0:      	cmp	w9, #0xa
    22b4:      	b.ne	0x2ac0 <generic_retkprobe_filter_arg+0x2ac0>
    22b8:      	ldr	x12, [x25]
    22bc:      	cmp	x12, x11
    22c0:      	ldr	x12, [sp, #0x48]
    22c4:      	b.lt	0x140 <generic_retkprobe_filter_arg+0x140>
    22c8:      	b	0x2ad0 <generic_retkprobe_filter_arg+0x2ad0>
    22cc:      	ldr	x12, [sp, #0x48]
    22d0:      	cmp	w8, #0xc
    22d4:      	b.ne	0x2ad0 <generic_retkprobe_filter_arg+0x2ad0>
    22d8:      	ldr	x12, [x25]
    22dc:      	tst	x12, x11
    22e0:      	ldr	x12, [sp, #0x48]
    22e4:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    22e8:      	b	0x2ad0 <generic_retkprobe_filter_arg+0x2ad0>
    22ec:      	cmp	w8, #0xc
    22f0:      	b.ne	0x2594 <generic_retkprobe_filter_arg+0x2594>
    22f4:      	ldrb	w11, [x25]
    22f8:      	tst	w10, w11
    22fc:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    2300:      	b	0x2594 <generic_retkprobe_filter_arg+0x2594>
    2304:      	cmp	w8, #0xc
    2308:      	b.ne	0x25d0 <generic_retkprobe_filter_arg+0x25d0>
    230c:      	ldrh	w11, [x25]
    2310:      	tst	w10, w11
    2314:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    2318:      	b	0x25d0 <generic_retkprobe_filter_arg+0x25d0>
    231c:      	cmp	w8, #0x401
    2320:      	b.hs	0x283c <generic_retkprobe_filter_arg+0x283c>
    2324:      	mov	w11, #0x400             // =1024
    2328:      	b	0x2850 <generic_retkprobe_filter_arg+0x2850>
    232c:      	cmp	w9, #0xc
    2330:      	b.eq	0x233c <generic_retkprobe_filter_arg+0x233c>
    2334:      	cmp	w9, #0xa
    2338:      	b.ne	0x2aac <generic_retkprobe_filter_arg+0x2aac>
    233c:      	ldr	x12, [x25]
    2340:      	cmp	x12, x11
    2344:      	ldr	x12, [sp, #0x48]
    2348:      	b.gt	0x140 <generic_retkprobe_filter_arg+0x140>
    234c:      	b	0x2ad0 <generic_retkprobe_filter_arg+0x2ad0>
    2350:      	cmp	w25, #0x8
    2354:      	b.eq	0x2ce8 <generic_retkprobe_filter_arg+0x2ce8>
    2358:      	cmp	w25, #0x9
    235c:      	b.eq	0x2cac <generic_retkprobe_filter_arg+0x2cac>
    2360:      	cmp	w25, #0xa
    2364:      	b.ne	0x2d5c <generic_retkprobe_filter_arg+0x2d5c>
    2368:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    236c:      	mov	w8, #0x1                // =1
    2370:      	add	x9, sp, #0x60
    2374:      	ldr	x0, [x0]
    2378:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    237c:      	and	w8, w29, #0xffff
    2380:      	mov	w9, #0x1000             // =4096
    2384:      	cmp	w8, #0x800
    2388:      	mov	w8, #0x800              // =2048
    238c:      	csel	w11, w9, w8, hi
    2390:      	sub	w8, w11, #0x100
    2394:      	ror	w8, w8, #0x8
    2398:      	cmp	w8, #0x2
    239c:      	b.gt	0x23b4 <generic_retkprobe_filter_arg+0x23b4>
    23a0:      	cbz	w8, 0x23d4 <generic_retkprobe_filter_arg+0x23d4>
    23a4:      	cmp	w8, #0x1
    23a8:      	b.ne	0x23cc <generic_retkprobe_filter_arg+0x23cc>
    23ac:      	mov	w10, #0x7               // =7
    23b0:      	b	0x23e0 <generic_retkprobe_filter_arg+0x23e0>
    23b4:      	cmp	w8, #0x3
    23b8:      	b.eq	0x23dc <generic_retkprobe_filter_arg+0x23dc>
    23bc:      	cmp	w8, #0x7
    23c0:      	b.ne	0x23cc <generic_retkprobe_filter_arg+0x23cc>
    23c4:      	mov	w10, #0x9               // =9
    23c8:      	b	0x23e0 <generic_retkprobe_filter_arg+0x23e0>
    23cc:      	mov	w10, #0xa               // =10
    23d0:      	b	0x23e0 <generic_retkprobe_filter_arg+0x23e0>
    23d4:      	mov	w10, #0x6               // =6
    23d8:      	b	0x23e0 <generic_retkprobe_filter_arg+0x23e0>
    23dc:      	mov	w10, #0x8               // =8
    23e0:      	add	x8, x21, #0x10
    23e4:      	and	w9, w10, #0xf
    23e8:      	ldr	w8, [x8, w9, uxtw #2]
    23ec:      	cmn	w8, #0x1
    23f0:      	b.eq	0x2d1c <generic_retkprobe_filter_arg+0x2d1c>
    23f4:      	str	w8, [sp, #0x10]
    23f8:      	str	w11, [sp, #0x1c]
    23fc:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2400:      	mov	w8, #0x1                // =1
    2404:      	add	x22, sp, #0x88
    2408:      	add	x1, sp, #0x88
    240c:      	str	w10, [sp, #0x28]
    2410:      	ldr	x0, [x0]
    2414:      	blr	x8
    2418:      	str	x0, [sp, #0x20]
    241c:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2420:      	mov	w8, #0x1                // =1
    2424:      	add	x1, sp, #0x88
    2428:      	ldr	x0, [x0]
    242c:      	blr	x8
    2430:      	ldr	x10, [sp, #0x20]
    2434:      	mov	x22, xzr
    2438:      	cbz	x10, 0x2d20 <generic_retkprobe_filter_arg+0x2d20>
    243c:      	mov	x9, x0
    2440:      	ldr	x0, [sp, #0x38]
    2444:      	ldp	x12, x16, [sp, #0x48]
    2448:      	mov	w17, #0x1               // =1
    244c:      	cbz	x9, 0x2d2c <generic_retkprobe_filter_arg+0x2d2c>
    2450:      	mov	x22, x9
    2454:      	ldr	w9, [sp, #0x28]
    2458:      	mov	x8, x10
    245c:      	add	x2, x25, #0x4
    2460:      	mov	x25, x10
    2464:      	mov	x0, x8
    2468:      	cmp	w9, #0x5
    246c:      	b.gt	0x24a0 <generic_retkprobe_filter_arg+0x24a0>
    2470:      	strb	w29, [x0], #0x1
    2474:      	mov	w8, #0x4                // =4
    2478:      	mov	w1, w29
    247c:      	blr	x8
    2480:      	ldr	w8, [sp, #0x1c]
    2484:      	subs	w8, w8, w29
    2488:      	b.ls	0x24d4 <generic_retkprobe_filter_arg+0x24d4>
    248c:      	add	x9, x25, x29
    2490:      	and	w1, w8, #0xfff
    2494:      	mov	w8, #0x4                // =4
    2498:      	add	x0, x9, #0x1
    249c:      	b	0x24cc <generic_retkprobe_filter_arg+0x24cc>
    24a0:      	strh	w29, [x0], #0x2
    24a4:      	mov	w8, #0x4                // =4
    24a8:      	mov	w1, w29
    24ac:      	blr	x8
    24b0:      	ldr	w8, [sp, #0x1c]
    24b4:      	subs	w8, w8, w29
    24b8:      	b.ls	0x24d4 <generic_retkprobe_filter_arg+0x24d4>
    24bc:      	add	x9, x25, x29
    24c0:      	and	w1, w8, #0xfff
    24c4:      	mov	w8, #0x4                // =4
    24c8:      	add	x0, x9, #0x2
    24cc:      	mov	x2, x22
    24d0:      	blr	x8
    24d4:      	ldr	w8, [sp, #0x10]
    24d8:      	ldr	x0, [sp, #0x38]
    24dc:      	mov	w17, #0x1               // =1
    24e0:      	str	w8, [sp, #0x60]
    24e4:      	ldr	w8, [sp, #0x28]
    24e8:      	ldp	x12, x16, [sp, #0x48]
    24ec:      	cmp	w8, #0x4
    24f0:      	b.le	0x2528 <generic_retkprobe_filter_arg+0x2528>
    24f4:      	cmp	w8, #0x7
    24f8:      	b.gt	0x255c <generic_retkprobe_filter_arg+0x255c>
    24fc:      	cmp	w8, #0x5
    2500:      	b.eq	0x2be4 <generic_retkprobe_filter_arg+0x2be4>
    2504:      	cmp	w8, #0x6
    2508:      	b.eq	0x2ba8 <generic_retkprobe_filter_arg+0x2ba8>
    250c:      	cmp	w8, #0x7
    2510:      	b.ne	0x664 <generic_retkprobe_filter_arg+0x664>
    2514:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2518:      	mov	w8, #0x1                // =1
    251c:      	add	x9, sp, #0x60
    2520:      	ldr	x0, [x0]
    2524:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    2528:      	cmp	w8, #0x1
    252c:      	b.le	0x2610 <generic_retkprobe_filter_arg+0x2610>
    2530:      	cmp	w8, #0x2
    2534:      	b.eq	0x2bd0 <generic_retkprobe_filter_arg+0x2bd0>
    2538:      	cmp	w8, #0x3
    253c:      	b.eq	0x2b94 <generic_retkprobe_filter_arg+0x2b94>
    2540:      	cmp	w8, #0x4
    2544:      	b.ne	0x664 <generic_retkprobe_filter_arg+0x664>
    2548:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    254c:      	mov	w8, #0x1                // =1
    2550:      	add	x9, sp, #0x60
    2554:      	ldr	x0, [x0]
    2558:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    255c:      	cmp	w8, #0x8
    2560:      	b.eq	0x2bf8 <generic_retkprobe_filter_arg+0x2bf8>
    2564:      	cmp	w8, #0x9
    2568:      	b.eq	0x2bbc <generic_retkprobe_filter_arg+0x2bbc>
    256c:      	cmp	w8, #0xa
    2570:      	b.ne	0x664 <generic_retkprobe_filter_arg+0x664>
    2574:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2578:      	mov	w8, #0x1                // =1
    257c:      	add	x9, sp, #0x60
    2580:      	ldr	x0, [x0]
    2584:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    2588:      	ldrb	w11, [x25]
    258c:      	cmp	w10, w11
    2590:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    2594:      	cmp	w9, #0x11
    2598:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    259c:      	ldr	w10, [x21, #0x18]
    25a0:      	cmp	w8, #0x2
    25a4:      	b.le	0x27fc <generic_retkprobe_filter_arg+0x27fc>
    25a8:      	sub	w11, w8, #0x3
    25ac:      	cmp	w11, #0x2
    25b0:      	b.hs	0x2b50 <generic_retkprobe_filter_arg+0x2b50>
    25b4:      	ldrb	w11, [x25]
    25b8:      	cmp	w10, w11
    25bc:      	b.ne	0x2e40 <generic_retkprobe_filter_arg+0x2e40>
    25c0:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
    25c4:      	ldrh	w11, [x25]
    25c8:      	cmp	w10, w11
    25cc:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    25d0:      	cmp	w9, #0x11
    25d4:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    25d8:      	ldr	w10, [x21, #0x18]
    25dc:      	cmp	w8, #0x2
    25e0:      	b.le	0x281c <generic_retkprobe_filter_arg+0x281c>
    25e4:      	sub	w11, w8, #0x3
    25e8:      	cmp	w11, #0x2
    25ec:      	b.hs	0x2b68 <generic_retkprobe_filter_arg+0x2b68>
    25f0:      	ldrh	w11, [x25]
    25f4:      	cmp	w10, w11
    25f8:      	b.ne	0x2e84 <generic_retkprobe_filter_arg+0x2e84>
    25fc:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
    2600:      	ldr	x23, [sp, #0x28]
    2604:      	ldp	x12, x16, [sp, #0x48]
    2608:      	mov	x22, xzr
    260c:      	b	0x32c0 <generic_retkprobe_filter_arg+0x32c0>
    2610:      	cbz	w8, 0x2b80 <generic_retkprobe_filter_arg+0x2b80>
    2614:      	cmp	w8, #0x1
    2618:      	b.ne	0x664 <generic_retkprobe_filter_arg+0x664>
    261c:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2620:      	mov	w8, #0x1                // =1
    2624:      	add	x9, sp, #0x60
    2628:      	ldr	x0, [x0]
    262c:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    2630:      	cmp	w13, w10
    2634:      	ccmp	w10, w12, #0x2, ls
    2638:      	cset	w12, ls
    263c:      	orr	w8, w8, w12
    2640:      	cmp	w11, #0x21
    2644:      	b.lo	0x2aa0 <generic_retkprobe_filter_arg+0x2aa0>
    2648:      	ldp	w12, w11, [x21, #0x28]
    264c:      	cmp	w9, #0xc
    2650:      	b.hi	0x2a90 <generic_retkprobe_filter_arg+0x2a90>
    2654:      	lsl	w9, w17, w9
    2658:      	mov	w13, #0x1402            // =5122
    265c:      	tst	w9, w13
    2660:      	b.eq	0x2a90 <generic_retkprobe_filter_arg+0x2a90>
    2664:      	cmp	w12, w10
    2668:      	ccmp	w10, w11, #0x0, le
    266c:      	cset	w9, le
    2670:      	b	0x2a9c <generic_retkprobe_filter_arg+0x2a9c>
    2674:      	mov	w22, #0x1               // =1
    2678:      	b	0x32bc <generic_retkprobe_filter_arg+0x32bc>
    267c:      	and	w8, w25, #0xffff
    2680:      	cmp	w8, #0x201
    2684:      	b.hs	0x2c2c <generic_retkprobe_filter_arg+0x2c2c>
    2688:      	mov	w11, #0x200             // =512
    268c:      	b	0x2f9c <generic_retkprobe_filter_arg+0x2f9c>
    2690:      	cmp	w12, w8
    2694:      	ldr	x12, [sp, #0x48]
    2698:      	b.hi	0x26a4 <generic_retkprobe_filter_arg+0x26a4>
    269c:      	cmp	w8, w11
    26a0:      	b.ls	0x140 <generic_retkprobe_filter_arg+0x140>
    26a4:      	cmp	w10, #0x21
    26a8:      	b.lo	0xc4 <generic_retkprobe_filter_arg+0xc4>
    26ac:      	ldp	w11, w10, [x21, #0x28]
    26b0:      	cmp	w9, #0xc
    26b4:      	b.hi	0x2c3c <generic_retkprobe_filter_arg+0x2c3c>
    26b8:      	lsl	w9, w17, w9
    26bc:      	mov	w13, #0x1402            // =5122
    26c0:      	tst	w9, w13
    26c4:      	b.eq	0x2c3c <generic_retkprobe_filter_arg+0x2c3c>
    26c8:      	cmp	w11, w8
    26cc:      	b.gt	0xc4 <generic_retkprobe_filter_arg+0xc4>
    26d0:      	cmp	w8, w10
    26d4:      	b.le	0x140 <generic_retkprobe_filter_arg+0x140>
    26d8:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    26dc:      	ldr	w12, [x25]
    26e0:      	cmp	w12, w11
    26e4:      	ldr	x12, [sp, #0x48]
    26e8:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    26ec:      	b	0x2700 <generic_retkprobe_filter_arg+0x2700>
    26f0:      	ldr	w12, [x25]
    26f4:      	cmp	w12, w11
    26f8:      	ldr	x12, [sp, #0x48]
    26fc:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    2700:      	cmp	w10, #0x11
    2704:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    2708:      	ldr	w11, [x21, #0x18]
    270c:      	cmp	w8, #0x2
    2710:      	b.le	0x2734 <generic_retkprobe_filter_arg+0x2734>
    2714:      	sub	w12, w8, #0x3
    2718:      	cmp	w12, #0x2
    271c:      	b.hs	0x2770 <generic_retkprobe_filter_arg+0x2770>
    2720:      	ldr	w12, [x25]
    2724:      	cmp	w12, w11
    2728:      	ldr	x12, [sp, #0x48]
    272c:      	b.ne	0x2ee0 <generic_retkprobe_filter_arg+0x2ee0>
    2730:      	b	0x31dc <generic_retkprobe_filter_arg+0x31dc>
    2734:      	cmp	w8, #0x1
    2738:      	b.eq	0x2790 <generic_retkprobe_filter_arg+0x2790>
    273c:      	cmp	w8, #0x2
    2740:      	b.ne	0x2ee0 <generic_retkprobe_filter_arg+0x2ee0>
    2744:      	cmp	w9, #0xc
    2748:      	b.hi	0x2ed0 <generic_retkprobe_filter_arg+0x2ed0>
    274c:      	lsl	w12, w17, w9
    2750:      	mov	w13, #0x1402            // =5122
    2754:      	tst	w12, w13
    2758:      	b.eq	0x2ed0 <generic_retkprobe_filter_arg+0x2ed0>
    275c:      	ldr	w12, [x25]
    2760:      	cmp	w12, w11
    2764:      	ldr	x12, [sp, #0x48]
    2768:      	b.lt	0x140 <generic_retkprobe_filter_arg+0x140>
    276c:      	b	0x2ee0 <generic_retkprobe_filter_arg+0x2ee0>
    2770:      	ldr	x12, [sp, #0x48]
    2774:      	cmp	w8, #0xc
    2778:      	b.ne	0x2ee0 <generic_retkprobe_filter_arg+0x2ee0>
    277c:      	ldr	w12, [x25]
    2780:      	tst	w12, w11
    2784:      	ldr	x12, [sp, #0x48]
    2788:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    278c:      	b	0x2ee0 <generic_retkprobe_filter_arg+0x2ee0>
    2790:      	cmp	w9, #0xc
    2794:      	b.hi	0x2ebc <generic_retkprobe_filter_arg+0x2ebc>
    2798:      	lsl	w12, w17, w9
    279c:      	mov	w13, #0x1402            // =5122
    27a0:      	tst	w12, w13
    27a4:      	b.eq	0x2ebc <generic_retkprobe_filter_arg+0x2ebc>
    27a8:      	ldr	w12, [x25]
    27ac:      	cmp	w12, w11
    27b0:      	ldr	x12, [sp, #0x48]
    27b4:      	b.gt	0x140 <generic_retkprobe_filter_arg+0x140>
    27b8:      	b	0x2ee0 <generic_retkprobe_filter_arg+0x2ee0>
    27bc:      	cmp	x12, x10
    27c0:      	ccmp	x10, x11, #0x2, ls
    27c4:      	b	0x2a98 <generic_retkprobe_filter_arg+0x2a98>
    27c8:      	cbz	w25, 0x2c70 <generic_retkprobe_filter_arg+0x2c70>
    27cc:      	cmp	w25, #0x1
    27d0:      	b.ne	0x2d5c <generic_retkprobe_filter_arg+0x2d5c>
    27d4:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    27d8:      	mov	w8, #0x1                // =1
    27dc:      	add	x9, sp, #0x60
    27e0:      	ldr	x0, [x0]
    27e4:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    27e8:      	cmp	x11, x8
    27ec:      	b.hi	0xc4 <generic_retkprobe_filter_arg+0xc4>
    27f0:      	cmp	x8, x10
    27f4:      	b.ls	0x140 <generic_retkprobe_filter_arg+0x140>
    27f8:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    27fc:      	cmp	w8, #0x1
    2800:      	b.eq	0x2e34 <generic_retkprobe_filter_arg+0x2e34>
    2804:      	cmp	w8, #0x2
    2808:      	b.ne	0x2e40 <generic_retkprobe_filter_arg+0x2e40>
    280c:      	ldrb	w11, [x25]
    2810:      	cmp	w10, w11
    2814:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    2818:      	b	0x2e40 <generic_retkprobe_filter_arg+0x2e40>
    281c:      	cmp	w8, #0x1
    2820:      	b.eq	0x2e78 <generic_retkprobe_filter_arg+0x2e78>
    2824:      	cmp	w8, #0x2
    2828:      	b.ne	0x2e84 <generic_retkprobe_filter_arg+0x2e84>
    282c:      	ldrh	w11, [x25]
    2830:      	cmp	w10, w11
    2834:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    2838:      	b	0x2e84 <generic_retkprobe_filter_arg+0x2e84>
    283c:      	and	w8, w29, #0xffff
    2840:      	mov	w9, #0x1000             // =4096
    2844:      	cmp	w8, #0x800
    2848:      	mov	w8, #0x800              // =2048
    284c:      	csel	w11, w9, w8, hi
    2850:      	sub	w8, w11, #0x100
    2854:      	ror	w8, w8, #0x8
    2858:      	cmp	w8, #0x2
    285c:      	b.gt	0x2874 <generic_retkprobe_filter_arg+0x2874>
    2860:      	cbz	w8, 0x2894 <generic_retkprobe_filter_arg+0x2894>
    2864:      	cmp	w8, #0x1
    2868:      	b.ne	0x288c <generic_retkprobe_filter_arg+0x288c>
    286c:      	mov	w10, #0x7               // =7
    2870:      	b	0x28a0 <generic_retkprobe_filter_arg+0x28a0>
    2874:      	cmp	w8, #0x3
    2878:      	b.eq	0x289c <generic_retkprobe_filter_arg+0x289c>
    287c:      	cmp	w8, #0x7
    2880:      	b.ne	0x288c <generic_retkprobe_filter_arg+0x288c>
    2884:      	mov	w10, #0x9               // =9
    2888:      	b	0x28a0 <generic_retkprobe_filter_arg+0x28a0>
    288c:      	mov	w10, #0xa               // =10
    2890:      	b	0x28a0 <generic_retkprobe_filter_arg+0x28a0>
    2894:      	mov	w10, #0x6               // =6
    2898:      	b	0x28a0 <generic_retkprobe_filter_arg+0x28a0>
    289c:      	mov	w10, #0x8               // =8
    28a0:      	add	x8, x21, #0x10
    28a4:      	and	w9, w10, #0xf
    28a8:      	ldr	w8, [x8, w9, uxtw #2]
    28ac:      	cmn	w8, #0x1
    28b0:      	b.eq	0x2964 <generic_retkprobe_filter_arg+0x2964>
    28b4:      	str	w8, [sp, #0x1c]
    28b8:      	str	w11, [sp, #0x10]
    28bc:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    28c0:      	mov	w8, #0x1                // =1
    28c4:      	add	x22, sp, #0x88
    28c8:      	add	x1, sp, #0x88
    28cc:      	str	w10, [sp, #0x28]
    28d0:      	ldr	x0, [x0]
    28d4:      	blr	x8
    28d8:      	str	x0, [sp, #0x20]
    28dc:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    28e0:      	mov	w8, #0x1                // =1
    28e4:      	add	x1, sp, #0x88
    28e8:      	ldr	x0, [x0]
    28ec:      	blr	x8
    28f0:      	ldr	x10, [sp, #0x20]
    28f4:      	mov	x22, xzr
    28f8:      	cbz	x10, 0x1314 <generic_retkprobe_filter_arg+0x1314>
    28fc:      	mov	x9, x0
    2900:      	ldr	x0, [sp, #0x38]
    2904:      	ldp	x12, x16, [sp, #0x48]
    2908:      	mov	w17, #0x1               // =1
    290c:      	cbz	x9, 0x1d18 <generic_retkprobe_filter_arg+0x1d18>
    2910:      	mov	x22, x9
    2914:      	ldr	w9, [sp, #0x28]
    2918:      	mov	x8, x10
    291c:      	cmp	w9, #0x5
    2920:      	b.gt	0x296c <generic_retkprobe_filter_arg+0x296c>
    2924:      	mov	x0, x8
    2928:      	mov	x9, x8
    292c:      	mov	w8, #0x4                // =4
    2930:      	mov	w1, w29
    2934:      	mov	x2, x25
    2938:      	strb	w29, [x0], #0x1
    293c:      	mov	x25, x9
    2940:      	blr	x8
    2944:      	ldr	w8, [sp, #0x10]
    2948:      	subs	w8, w8, w29
    294c:      	b.ls	0x29b0 <generic_retkprobe_filter_arg+0x29b0>
    2950:      	add	x9, x25, x29
    2954:      	and	w1, w8, #0xfff
    2958:      	mov	w8, #0x4                // =4
    295c:      	add	x0, x9, #0x1
    2960:      	b	0x29a8 <generic_retkprobe_filter_arg+0x29a8>
    2964:      	mov	x22, xzr
    2968:      	b	0x131c <generic_retkprobe_filter_arg+0x131c>
    296c:      	mov	x0, x8
    2970:      	mov	x9, x8
    2974:      	mov	w8, #0x4                // =4
    2978:      	mov	w1, w29
    297c:      	mov	x2, x25
    2980:      	strh	w29, [x0], #0x2
    2984:      	mov	x25, x9
    2988:      	blr	x8
    298c:      	ldr	w8, [sp, #0x10]
    2990:      	subs	w8, w8, w29
    2994:      	b.ls	0x29b0 <generic_retkprobe_filter_arg+0x29b0>
    2998:      	add	x9, x25, x29
    299c:      	and	w1, w8, #0xfff
    29a0:      	mov	w8, #0x4                // =4
    29a4:      	add	x0, x9, #0x2
    29a8:      	mov	x2, x22
    29ac:      	blr	x8
    29b0:      	ldr	w8, [sp, #0x1c]
    29b4:      	ldp	x12, x16, [sp, #0x48]
    29b8:      	mov	w17, #0x1               // =1
    29bc:      	str	w8, [sp, #0x60]
    29c0:      	ldr	w8, [sp, #0x28]
    29c4:      	cmp	w8, #0x4
    29c8:      	b.le	0x2a00 <generic_retkprobe_filter_arg+0x2a00>
    29cc:      	cmp	w8, #0x7
    29d0:      	b.gt	0x2a34 <generic_retkprobe_filter_arg+0x2a34>
    29d4:      	cmp	w8, #0x5
    29d8:      	b.eq	0x2dd8 <generic_retkprobe_filter_arg+0x2dd8>
    29dc:      	cmp	w8, #0x6
    29e0:      	b.eq	0x2d9c <generic_retkprobe_filter_arg+0x2d9c>
    29e4:      	cmp	w8, #0x7
    29e8:      	b.ne	0x2e28 <generic_retkprobe_filter_arg+0x2e28>
    29ec:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    29f0:      	mov	w8, #0x1                // =1
    29f4:      	add	x9, sp, #0x60
    29f8:      	ldr	x0, [x0]
    29fc:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2a00:      	cmp	w8, #0x1
    2a04:      	b.le	0x2a60 <generic_retkprobe_filter_arg+0x2a60>
    2a08:      	cmp	w8, #0x2
    2a0c:      	b.eq	0x2dc4 <generic_retkprobe_filter_arg+0x2dc4>
    2a10:      	cmp	w8, #0x3
    2a14:      	b.eq	0x2d88 <generic_retkprobe_filter_arg+0x2d88>
    2a18:      	cmp	w8, #0x4
    2a1c:      	b.ne	0x2e28 <generic_retkprobe_filter_arg+0x2e28>
    2a20:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2a24:      	mov	w8, #0x1                // =1
    2a28:      	add	x9, sp, #0x60
    2a2c:      	ldr	x0, [x0]
    2a30:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2a34:      	cmp	w8, #0x8
    2a38:      	b.eq	0x2dec <generic_retkprobe_filter_arg+0x2dec>
    2a3c:      	cmp	w8, #0x9
    2a40:      	b.eq	0x2db0 <generic_retkprobe_filter_arg+0x2db0>
    2a44:      	cmp	w8, #0xa
    2a48:      	b.ne	0x2e28 <generic_retkprobe_filter_arg+0x2e28>
    2a4c:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2a50:      	mov	w8, #0x1                // =1
    2a54:      	add	x9, sp, #0x60
    2a58:      	ldr	x0, [x0]
    2a5c:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2a60:      	cbz	w8, 0x2d74 <generic_retkprobe_filter_arg+0x2d74>
    2a64:      	cmp	w8, #0x1
    2a68:      	b.ne	0x2e28 <generic_retkprobe_filter_arg+0x2e28>
    2a6c:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2a70:      	mov	w8, #0x1                // =1
    2a74:      	add	x9, sp, #0x60
    2a78:      	ldr	x0, [x0]
    2a7c:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2a80:      	ldr	x23, [sp, #0x28]
    2a84:      	ldr	x12, [sp, #0x48]
    2a88:      	mov	w22, #0x1               // =1
    2a8c:      	b	0x32c4 <generic_retkprobe_filter_arg+0x32c4>
    2a90:      	cmp	w12, w10
    2a94:      	ccmp	w10, w11, #0x2, ls
    2a98:      	cset	w9, ls
    2a9c:      	orr	w8, w8, w9
    2aa0:      	ldr	x12, [sp, #0x48]
    2aa4:      	tbz	w8, #0x0, 0x140 <generic_retkprobe_filter_arg+0x140>
    2aa8:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2aac:      	ldr	x12, [x25]
    2ab0:      	cmp	x12, x11
    2ab4:      	ldr	x12, [sp, #0x48]
    2ab8:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    2abc:      	b	0x2ad0 <generic_retkprobe_filter_arg+0x2ad0>
    2ac0:      	ldr	x12, [x25]
    2ac4:      	cmp	x12, x11
    2ac8:      	ldr	x12, [sp, #0x48]
    2acc:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    2ad0:      	cmp	w10, #0x21
    2ad4:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    2ad8:      	ldr	x10, [x21, #0x28]
    2adc:      	cmp	w8, #0x2
    2ae0:      	b.le	0x2b10 <generic_retkprobe_filter_arg+0x2b10>
    2ae4:      	sub	w9, w8, #0x3
    2ae8:      	cmp	w9, #0x2
    2aec:      	b.lo	0x2b40 <generic_retkprobe_filter_arg+0x2b40>
    2af0:      	cmp	w8, #0x6
    2af4:      	b.eq	0x140 <generic_retkprobe_filter_arg+0x140>
    2af8:      	cmp	w8, #0xc
    2afc:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2b00:      	ldr	x9, [x25]
    2b04:      	tst	x9, x10
    2b08:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    2b0c:      	b	0x124 <generic_retkprobe_filter_arg+0x124>
    2b10:      	cmp	w8, #0x1
    2b14:      	b.eq	0x2c50 <generic_retkprobe_filter_arg+0x2c50>
    2b18:      	cmp	w8, #0x2
    2b1c:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2b20:      	cmp	w9, #0xc
    2b24:      	b.eq	0x2b30 <generic_retkprobe_filter_arg+0x2b30>
    2b28:      	cmp	w9, #0xa
    2b2c:      	b.ne	0x31ec <generic_retkprobe_filter_arg+0x31ec>
    2b30:      	ldr	x9, [x25]
    2b34:      	cmp	x9, x10
    2b38:      	b.ge	0x124 <generic_retkprobe_filter_arg+0x124>
    2b3c:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
    2b40:      	ldr	x9, [x25]
    2b44:      	cmp	x9, x10
    2b48:      	b.eq	0x31dc <generic_retkprobe_filter_arg+0x31dc>
    2b4c:      	b	0x124 <generic_retkprobe_filter_arg+0x124>
    2b50:      	cmp	w8, #0xc
    2b54:      	b.ne	0x2e40 <generic_retkprobe_filter_arg+0x2e40>
    2b58:      	ldrb	w11, [x25]
    2b5c:      	tst	w10, w11
    2b60:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    2b64:      	b	0x2e40 <generic_retkprobe_filter_arg+0x2e40>
    2b68:      	cmp	w8, #0xc
    2b6c:      	b.ne	0x2e84 <generic_retkprobe_filter_arg+0x2e84>
    2b70:      	ldrh	w11, [x25]
    2b74:      	tst	w10, w11
    2b78:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    2b7c:      	b	0x2e84 <generic_retkprobe_filter_arg+0x2e84>
    2b80:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2b84:      	mov	w8, #0x1                // =1
    2b88:      	add	x9, sp, #0x60
    2b8c:      	ldr	x0, [x0]
    2b90:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    2b94:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2b98:      	mov	w8, #0x1                // =1
    2b9c:      	add	x9, sp, #0x60
    2ba0:      	ldr	x0, [x0]
    2ba4:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    2ba8:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2bac:      	mov	w8, #0x1                // =1
    2bb0:      	add	x9, sp, #0x60
    2bb4:      	ldr	x0, [x0]
    2bb8:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    2bbc:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2bc0:      	mov	w8, #0x1                // =1
    2bc4:      	add	x9, sp, #0x60
    2bc8:      	ldr	x0, [x0]
    2bcc:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    2bd0:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2bd4:      	mov	w8, #0x1                // =1
    2bd8:      	add	x9, sp, #0x60
    2bdc:      	ldr	x0, [x0]
    2be0:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    2be4:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2be8:      	mov	w8, #0x1                // =1
    2bec:      	add	x9, sp, #0x60
    2bf0:      	ldr	x0, [x0]
    2bf4:      	b	0x2c08 <generic_retkprobe_filter_arg+0x2c08>
    2bf8:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2bfc:      	mov	w8, #0x1                // =1
    2c00:      	add	x9, sp, #0x60
    2c04:      	ldr	x0, [x0]
    2c08:      	add	x1, sp, #0x60
    2c0c:      	blr	x8
    2c10:      	cbz	x0, 0x2d1c <generic_retkprobe_filter_arg+0x2d1c>
    2c14:      	mov	w8, #0x1                // =1
    2c18:      	mov	x1, x25
    2c1c:      	blr	x8
    2c20:      	cmp	x0, #0x0
    2c24:      	cset	w22, ne
    2c28:      	b	0x2d20 <generic_retkprobe_filter_arg+0x2d20>
    2c2c:      	cmp	w8, #0x401
    2c30:      	b.hs	0x2f88 <generic_retkprobe_filter_arg+0x2f88>
    2c34:      	mov	w11, #0x400             // =1024
    2c38:      	b	0x2f9c <generic_retkprobe_filter_arg+0x2f9c>
    2c3c:      	cmp	w11, w8
    2c40:      	b.hi	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2c44:      	cmp	w8, w10
    2c48:      	b.ls	0x140 <generic_retkprobe_filter_arg+0x140>
    2c4c:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2c50:      	cmp	w9, #0xc
    2c54:      	b.eq	0x2c60 <generic_retkprobe_filter_arg+0x2c60>
    2c58:      	cmp	w9, #0xa
    2c5c:      	b.ne	0x31fc <generic_retkprobe_filter_arg+0x31fc>
    2c60:      	ldr	x9, [x25]
    2c64:      	cmp	x9, x10
    2c68:      	b.le	0x124 <generic_retkprobe_filter_arg+0x124>
    2c6c:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
    2c70:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2c74:      	mov	w8, #0x1                // =1
    2c78:      	add	x9, sp, #0x60
    2c7c:      	ldr	x0, [x0]
    2c80:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    2c84:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2c88:      	mov	w8, #0x1                // =1
    2c8c:      	add	x9, sp, #0x60
    2c90:      	ldr	x0, [x0]
    2c94:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    2c98:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2c9c:      	mov	w8, #0x1                // =1
    2ca0:      	add	x9, sp, #0x60
    2ca4:      	ldr	x0, [x0]
    2ca8:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    2cac:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2cb0:      	mov	w8, #0x1                // =1
    2cb4:      	add	x9, sp, #0x60
    2cb8:      	ldr	x0, [x0]
    2cbc:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    2cc0:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2cc4:      	mov	w8, #0x1                // =1
    2cc8:      	add	x9, sp, #0x60
    2ccc:      	ldr	x0, [x0]
    2cd0:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    2cd4:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2cd8:      	mov	w8, #0x1                // =1
    2cdc:      	add	x9, sp, #0x60
    2ce0:      	ldr	x0, [x0]
    2ce4:      	b	0x2cf8 <generic_retkprobe_filter_arg+0x2cf8>
    2ce8:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2cec:      	mov	w8, #0x1                // =1
    2cf0:      	add	x9, sp, #0x60
    2cf4:      	ldr	x0, [x0]
    2cf8:      	add	x1, sp, #0x60
    2cfc:      	blr	x8
    2d00:      	cbz	x0, 0x2d1c <generic_retkprobe_filter_arg+0x2d1c>
    2d04:      	ldr	x1, [sp, #0x8]
    2d08:      	mov	w8, #0x1                // =1
    2d0c:      	blr	x8
    2d10:      	cmp	x0, #0x0
    2d14:      	cset	w22, ne
    2d18:      	b	0x2d20 <generic_retkprobe_filter_arg+0x2d20>
    2d1c:      	mov	x22, xzr
    2d20:      	ldr	x0, [sp, #0x38]
    2d24:      	ldp	x12, x16, [sp, #0x48]
    2d28:      	mov	w17, #0x1               // =1
    2d2c:      	ldr	w8, [x21, #0x4]
    2d30:      	cmp	w8, #0x25
    2d34:      	b.hi	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    2d38:      	mov	x9, #0x50               // =80
    2d3c:      	lsl	x8, x17, x8
    2d40:      	movk	x9, #0xc00, lsl #16
    2d44:      	movk	x9, #0x20, lsl #32
    2d48:      	tst	x8, x9
    2d4c:      	b.eq	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    2d50:      	eor	x22, x22, #0x1
    2d54:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    2d58:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2d5c:      	ldr	x0, [sp, #0x38]
    2d60:      	mov	x22, xzr
    2d64:      	ldr	w8, [x21, #0x4]
    2d68:      	cmp	w8, #0x25
    2d6c:      	b.ls	0x2d38 <generic_retkprobe_filter_arg+0x2d38>
    2d70:      	b	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    2d74:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2d78:      	mov	w8, #0x1                // =1
    2d7c:      	add	x9, sp, #0x60
    2d80:      	ldr	x0, [x0]
    2d84:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2d88:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2d8c:      	mov	w8, #0x1                // =1
    2d90:      	add	x9, sp, #0x60
    2d94:      	ldr	x0, [x0]
    2d98:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2d9c:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2da0:      	mov	w8, #0x1                // =1
    2da4:      	add	x9, sp, #0x60
    2da8:      	ldr	x0, [x0]
    2dac:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2db0:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2db4:      	mov	w8, #0x1                // =1
    2db8:      	add	x9, sp, #0x60
    2dbc:      	ldr	x0, [x0]
    2dc0:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2dc4:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2dc8:      	mov	w8, #0x1                // =1
    2dcc:      	add	x9, sp, #0x60
    2dd0:      	ldr	x0, [x0]
    2dd4:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2dd8:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2ddc:      	mov	w8, #0x1                // =1
    2de0:      	add	x9, sp, #0x60
    2de4:      	ldr	x0, [x0]
    2de8:      	b	0x2dfc <generic_retkprobe_filter_arg+0x2dfc>
    2dec:      	adrp	x0, 0x2000 <generic_retkprobe_filter_arg+0x2000>
    2df0:      	mov	w8, #0x1                // =1
    2df4:      	add	x9, sp, #0x60
    2df8:      	ldr	x0, [x0]
    2dfc:      	add	x1, sp, #0x60
    2e00:      	blr	x8
    2e04:      	cbz	x0, 0x2e20 <generic_retkprobe_filter_arg+0x2e20>
    2e08:      	mov	w8, #0x1                // =1
    2e0c:      	mov	x1, x25
    2e10:      	blr	x8
    2e14:      	cmp	x0, #0x0
    2e18:      	cset	w22, ne
    2e1c:      	b	0x1314 <generic_retkprobe_filter_arg+0x1314>
    2e20:      	mov	x22, xzr
    2e24:      	b	0x1314 <generic_retkprobe_filter_arg+0x1314>
    2e28:      	ldr	x0, [sp, #0x38]
    2e2c:      	mov	x22, xzr
    2e30:      	b	0x1d18 <generic_retkprobe_filter_arg+0x1d18>
    2e34:      	ldrb	w11, [x25]
    2e38:      	cmp	w10, w11
    2e3c:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    2e40:      	cmp	w9, #0x15
    2e44:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    2e48:      	ldr	w9, [x21, #0x1c]
    2e4c:      	cmp	w8, #0x2
    2e50:      	b.le	0x3198 <generic_retkprobe_filter_arg+0x3198>
    2e54:      	sub	w10, w8, #0x3
    2e58:      	cmp	w10, #0x2
    2e5c:      	b.lo	0x31c8 <generic_retkprobe_filter_arg+0x31c8>
    2e60:      	cmp	w8, #0x6
    2e64:      	b.eq	0x140 <generic_retkprobe_filter_arg+0x140>
    2e68:      	cmp	w8, #0xc
    2e6c:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2e70:      	ldrb	w10, [x25]
    2e74:      	b	0x2f14 <generic_retkprobe_filter_arg+0x2f14>
    2e78:      	ldrh	w11, [x25]
    2e7c:      	cmp	w10, w11
    2e80:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    2e84:      	cmp	w9, #0x15
    2e88:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    2e8c:      	ldr	w9, [x21, #0x1c]
    2e90:      	cmp	w8, #0x2
    2e94:      	b.le	0x31b0 <generic_retkprobe_filter_arg+0x31b0>
    2e98:      	sub	w10, w8, #0x3
    2e9c:      	cmp	w10, #0x2
    2ea0:      	b.lo	0x31d0 <generic_retkprobe_filter_arg+0x31d0>
    2ea4:      	cmp	w8, #0x6
    2ea8:      	b.eq	0x140 <generic_retkprobe_filter_arg+0x140>
    2eac:      	cmp	w8, #0xc
    2eb0:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2eb4:      	ldrh	w10, [x25]
    2eb8:      	b	0x2f14 <generic_retkprobe_filter_arg+0x2f14>
    2ebc:      	ldr	w12, [x25]
    2ec0:      	cmp	w12, w11
    2ec4:      	ldr	x12, [sp, #0x48]
    2ec8:      	b.hi	0x140 <generic_retkprobe_filter_arg+0x140>
    2ecc:      	b	0x2ee0 <generic_retkprobe_filter_arg+0x2ee0>
    2ed0:      	ldr	w12, [x25]
    2ed4:      	cmp	w12, w11
    2ed8:      	ldr	x12, [sp, #0x48]
    2edc:      	b.lo	0x140 <generic_retkprobe_filter_arg+0x140>
    2ee0:      	cmp	w10, #0x15
    2ee4:      	b.lo	0x124 <generic_retkprobe_filter_arg+0x124>
    2ee8:      	ldr	w10, [x21, #0x1c]
    2eec:      	cmp	w8, #0x2
    2ef0:      	b.le	0x2f20 <generic_retkprobe_filter_arg+0x2f20>
    2ef4:      	sub	w9, w8, #0x3
    2ef8:      	cmp	w9, #0x2
    2efc:      	b.lo	0x2f58 <generic_retkprobe_filter_arg+0x2f58>
    2f00:      	cmp	w8, #0x6
    2f04:      	b.eq	0x140 <generic_retkprobe_filter_arg+0x140>
    2f08:      	cmp	w8, #0xc
    2f0c:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2f10:      	ldr	w9, [x25]
    2f14:      	tst	w9, w10
    2f18:      	b.ne	0x140 <generic_retkprobe_filter_arg+0x140>
    2f1c:      	b	0x124 <generic_retkprobe_filter_arg+0x124>
    2f20:      	cmp	w8, #0x1
    2f24:      	b.eq	0x2f60 <generic_retkprobe_filter_arg+0x2f60>
    2f28:      	cmp	w8, #0x2
    2f2c:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    2f30:      	cmp	w9, #0xc
    2f34:      	b.hi	0x331c <generic_retkprobe_filter_arg+0x331c>
    2f38:      	lsl	w9, w17, w9
    2f3c:      	mov	w11, #0x1402            // =5122
    2f40:      	tst	w9, w11
    2f44:      	b.eq	0x331c <generic_retkprobe_filter_arg+0x331c>
    2f48:      	ldr	w9, [x25]
    2f4c:      	cmp	w9, w10
    2f50:      	b.ge	0x124 <generic_retkprobe_filter_arg+0x124>
    2f54:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
    2f58:      	ldr	w9, [x25]
    2f5c:      	b	0x31d4 <generic_retkprobe_filter_arg+0x31d4>
    2f60:      	cmp	w9, #0xc
    2f64:      	b.hi	0x332c <generic_retkprobe_filter_arg+0x332c>
    2f68:      	lsl	w9, w17, w9
    2f6c:      	mov	w11, #0x1402            // =5122
    2f70:      	tst	w9, w11
    2f74:      	b.eq	0x332c <generic_retkprobe_filter_arg+0x332c>
    2f78:      	ldr	w9, [x25]
    2f7c:      	cmp	w9, w10
    2f80:      	b.le	0x124 <generic_retkprobe_filter_arg+0x124>
    2f84:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
    2f88:      	and	w8, w25, #0xffff
    2f8c:      	mov	w9, #0x1000             // =4096
    2f90:      	cmp	w8, #0x800
    2f94:      	mov	w8, #0x800              // =2048
    2f98:      	csel	w11, w9, w8, hi
    2f9c:      	sub	w8, w11, #0x100
    2fa0:      	ror	w8, w8, #0x8
    2fa4:      	cmp	w8, #0x2
    2fa8:      	b.gt	0x2fc0 <generic_retkprobe_filter_arg+0x2fc0>
    2fac:      	cbz	w8, 0x2fe0 <generic_retkprobe_filter_arg+0x2fe0>
    2fb0:      	cmp	w8, #0x1
    2fb4:      	b.ne	0x2fd8 <generic_retkprobe_filter_arg+0x2fd8>
    2fb8:      	mov	w10, #0x7               // =7
    2fbc:      	b	0x2fec <generic_retkprobe_filter_arg+0x2fec>
    2fc0:      	cmp	w8, #0x3
    2fc4:      	b.eq	0x2fe8 <generic_retkprobe_filter_arg+0x2fe8>
    2fc8:      	cmp	w8, #0x7
    2fcc:      	b.ne	0x2fd8 <generic_retkprobe_filter_arg+0x2fd8>
    2fd0:      	mov	w10, #0x9               // =9
    2fd4:      	b	0x2fec <generic_retkprobe_filter_arg+0x2fec>
    2fd8:      	mov	w10, #0xa               // =10
    2fdc:      	b	0x2fec <generic_retkprobe_filter_arg+0x2fec>
    2fe0:      	mov	w10, #0x6               // =6
    2fe4:      	b	0x2fec <generic_retkprobe_filter_arg+0x2fec>
    2fe8:      	mov	w10, #0x8               // =8
    2fec:      	add	x8, x21, #0x10
    2ff0:      	and	w9, w10, #0xf
    2ff4:      	ldr	w8, [x8, w9, uxtw #2]
    2ff8:      	cmn	w8, #0x1
    2ffc:      	b.eq	0x32b8 <generic_retkprobe_filter_arg+0x32b8>
    3000:      	stp	w8, w11, [sp, #0x1c]
    3004:      	str	w10, [sp, #0x28]
    3008:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    300c:      	mov	w8, #0x1                // =1
    3010:      	add	x19, sp, #0x88
    3014:      	add	x1, sp, #0x88
    3018:      	ldr	x0, [x0]
    301c:      	blr	x8
    3020:      	mov	x9, x0
    3024:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3028:      	mov	w8, #0x1                // =1
    302c:      	ldr	x0, [x0]
    3030:      	add	x1, sp, #0x88
    3034:      	mov	x19, x9
    3038:      	blr	x8
    303c:      	mov	x22, xzr
    3040:      	cbz	x19, 0x32bc <generic_retkprobe_filter_arg+0x32bc>
    3044:      	ldp	x12, x16, [sp, #0x48]
    3048:      	mov	w17, #0x1               // =1
    304c:      	cbz	x0, 0x32c4 <generic_retkprobe_filter_arg+0x32c4>
    3050:      	ldr	w22, [sp, #0x28]
    3054:      	str	x0, [sp, #0x10]
    3058:      	mov	x0, x19
    305c:      	cmp	w22, #0x5
    3060:      	b.gt	0x309c <generic_retkprobe_filter_arg+0x309c>
    3064:      	strb	w25, [x0], #0x1
    3068:      	mov	w8, #0x4                // =4
    306c:      	mov	w1, w25
    3070:      	mov	x2, x29
    3074:      	blr	x8
    3078:      	ldr	w8, [sp, #0x20]
    307c:      	subs	w8, w8, w25
    3080:      	b.ls	0x30d4 <generic_retkprobe_filter_arg+0x30d4>
    3084:      	add	x9, x19, x25
    3088:      	and	w1, w8, #0xfff
    308c:      	mov	w8, #0x4                // =4
    3090:      	ldr	x2, [sp, #0x10]
    3094:      	add	x0, x9, #0x1
    3098:      	b	0x30d0 <generic_retkprobe_filter_arg+0x30d0>
    309c:      	strh	w25, [x0], #0x2
    30a0:      	mov	w8, #0x4                // =4
    30a4:      	mov	w1, w25
    30a8:      	mov	x2, x29
    30ac:      	blr	x8
    30b0:      	ldr	w8, [sp, #0x20]
    30b4:      	subs	w8, w8, w25
    30b8:      	b.ls	0x30d4 <generic_retkprobe_filter_arg+0x30d4>
    30bc:      	add	x9, x19, x25
    30c0:      	ldr	x2, [sp, #0x10]
    30c4:      	and	w1, w8, #0xfff
    30c8:      	mov	w8, #0x4                // =4
    30cc:      	add	x0, x9, #0x2
    30d0:      	blr	x8
    30d4:      	ldr	w8, [sp, #0x1c]
    30d8:      	cmp	w22, #0x4
    30dc:      	str	w8, [sp, #0x60]
    30e0:      	b.le	0x3118 <generic_retkprobe_filter_arg+0x3118>
    30e4:      	cmp	w22, #0x7
    30e8:      	b.gt	0x314c <generic_retkprobe_filter_arg+0x314c>
    30ec:      	cmp	w22, #0x5
    30f0:      	b.eq	0x3270 <generic_retkprobe_filter_arg+0x3270>
    30f4:      	cmp	w22, #0x6
    30f8:      	b.eq	0x3234 <generic_retkprobe_filter_arg+0x3234>
    30fc:      	cmp	w22, #0x7
    3100:      	b.ne	0x32b8 <generic_retkprobe_filter_arg+0x32b8>
    3104:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3108:      	mov	w8, #0x1                // =1
    310c:      	add	x9, sp, #0x60
    3110:      	ldr	x0, [x0]
    3114:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    3118:      	cmp	w22, #0x1
    311c:      	b.le	0x3178 <generic_retkprobe_filter_arg+0x3178>
    3120:      	cmp	w22, #0x2
    3124:      	b.eq	0x325c <generic_retkprobe_filter_arg+0x325c>
    3128:      	cmp	w22, #0x3
    312c:      	b.eq	0x3220 <generic_retkprobe_filter_arg+0x3220>
    3130:      	cmp	w22, #0x4
    3134:      	b.ne	0x32b8 <generic_retkprobe_filter_arg+0x32b8>
    3138:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    313c:      	mov	w8, #0x1                // =1
    3140:      	add	x9, sp, #0x60
    3144:      	ldr	x0, [x0]
    3148:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    314c:      	cmp	w22, #0x8
    3150:      	b.eq	0x3284 <generic_retkprobe_filter_arg+0x3284>
    3154:      	cmp	w22, #0x9
    3158:      	b.eq	0x3248 <generic_retkprobe_filter_arg+0x3248>
    315c:      	cmp	w22, #0xa
    3160:      	b.ne	0x32b8 <generic_retkprobe_filter_arg+0x32b8>
    3164:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3168:      	mov	w8, #0x1                // =1
    316c:      	add	x9, sp, #0x60
    3170:      	ldr	x0, [x0]
    3174:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    3178:      	cbz	w22, 0x320c <generic_retkprobe_filter_arg+0x320c>
    317c:      	cmp	w22, #0x1
    3180:      	b.ne	0x32b8 <generic_retkprobe_filter_arg+0x32b8>
    3184:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3188:      	mov	w8, #0x1                // =1
    318c:      	add	x9, sp, #0x60
    3190:      	ldr	x0, [x0]
    3194:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    3198:      	cmp	w8, #0x1
    319c:      	b.eq	0x330c <generic_retkprobe_filter_arg+0x330c>
    31a0:      	cmp	w8, #0x2
    31a4:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    31a8:      	ldrb	w10, [x25]
    31ac:      	b	0x3330 <generic_retkprobe_filter_arg+0x3330>
    31b0:      	cmp	w8, #0x1
    31b4:      	b.eq	0x3314 <generic_retkprobe_filter_arg+0x3314>
    31b8:      	cmp	w8, #0x2
    31bc:      	b.ne	0xc4 <generic_retkprobe_filter_arg+0xc4>
    31c0:      	ldrh	w10, [x25]
    31c4:      	b	0x3330 <generic_retkprobe_filter_arg+0x3330>
    31c8:      	ldrb	w10, [x25]
    31cc:      	b	0x31d4 <generic_retkprobe_filter_arg+0x31d4>
    31d0:      	ldrh	w10, [x25]
    31d4:      	cmp	w9, w10
    31d8:      	b.ne	0x124 <generic_retkprobe_filter_arg+0x124>
    31dc:      	cmp	w8, #0x3
    31e0:      	cset	w22, eq
    31e4:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    31e8:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    31ec:      	ldr	x9, [x25]
    31f0:      	cmp	x9, x10
    31f4:      	b.hs	0x124 <generic_retkprobe_filter_arg+0x124>
    31f8:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
    31fc:      	ldr	x9, [x25]
    3200:      	cmp	x9, x10
    3204:      	b.ls	0x124 <generic_retkprobe_filter_arg+0x124>
    3208:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
    320c:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3210:      	mov	w8, #0x1                // =1
    3214:      	add	x9, sp, #0x60
    3218:      	ldr	x0, [x0]
    321c:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    3220:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3224:      	mov	w8, #0x1                // =1
    3228:      	add	x9, sp, #0x60
    322c:      	ldr	x0, [x0]
    3230:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    3234:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3238:      	mov	w8, #0x1                // =1
    323c:      	add	x9, sp, #0x60
    3240:      	ldr	x0, [x0]
    3244:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    3248:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    324c:      	mov	w8, #0x1                // =1
    3250:      	add	x9, sp, #0x60
    3254:      	ldr	x0, [x0]
    3258:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    325c:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3260:      	mov	w8, #0x1                // =1
    3264:      	add	x9, sp, #0x60
    3268:      	ldr	x0, [x0]
    326c:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    3270:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3274:      	mov	w8, #0x1                // =1
    3278:      	add	x9, sp, #0x60
    327c:      	ldr	x0, [x0]
    3280:      	b	0x3294 <generic_retkprobe_filter_arg+0x3294>
    3284:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3288:      	mov	w8, #0x1                // =1
    328c:      	add	x9, sp, #0x60
    3290:      	ldr	x0, [x0]
    3294:      	add	x1, sp, #0x60
    3298:      	blr	x8
    329c:      	cbz	x0, 0x32b8 <generic_retkprobe_filter_arg+0x32b8>
    32a0:      	mov	w8, #0x1                // =1
    32a4:      	mov	x1, x19
    32a8:      	blr	x8
    32ac:      	cmp	x0, #0x0
    32b0:      	cset	w22, ne
    32b4:      	b	0x32bc <generic_retkprobe_filter_arg+0x32bc>
    32b8:      	mov	x22, xzr
    32bc:      	ldp	x12, x16, [sp, #0x48]
    32c0:      	mov	w17, #0x1               // =1
    32c4:      	ldr	w8, [x21, #0x4]
    32c8:      	ldr	x0, [sp, #0x38]
    32cc:      	cmp	w8, #0x25
    32d0:      	b.hi	0x3300 <generic_retkprobe_filter_arg+0x3300>
    32d4:      	mov	x9, #0x50               // =80
    32d8:      	ldr	x19, [sp, #0x30]
    32dc:      	lsl	x8, x17, x8
    32e0:      	movk	x9, #0xc00, lsl #16
    32e4:      	movk	x9, #0x20, lsl #32
    32e8:      	tst	x8, x9
    32ec:      	b.eq	0x1ce4 <generic_retkprobe_filter_arg+0x1ce4>
    32f0:      	cmp	x22, #0x0
    32f4:      	cset	w22, eq
    32f8:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    32fc:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    3300:      	ldr	x19, [sp, #0x30]
    3304:      	cbnz	x22, 0x140 <generic_retkprobe_filter_arg+0x140>
    3308:      	b	0xc4 <generic_retkprobe_filter_arg+0xc4>
    330c:      	ldrb	w10, [x25]
    3310:      	b	0x3320 <generic_retkprobe_filter_arg+0x3320>
    3314:      	ldrh	w10, [x25]
    3318:      	b	0x3320 <generic_retkprobe_filter_arg+0x3320>
    331c:      	ldr	w9, [x25]
    3320:      	cmp	w9, w10
    3324:      	b.hs	0x124 <generic_retkprobe_filter_arg+0x124>
    3328:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
    332c:      	ldr	w9, [x25]
    3330:      	cmp	w9, w10
    3334:      	b.ls	0x124 <generic_retkprobe_filter_arg+0x124>
    3338:      	b	0x140 <generic_retkprobe_filter_arg+0x140>
    333c:      	ldr	x8, [sp, #0x40]
    3340:      	adrp	x1, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3344:      	mov	w9, #0xc                // =12
    3348:      	mov	x0, x23
    334c:      	stur	w8, [x19, #0x43]
    3350:      	mov	w8, #0x4                // =4
    3354:      	mov	w2, #0x4                // =4
    3358:      	ldr	x1, [x1]
    335c:      	blr	x9
    3360:      	adrp	x1, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3364:      	mov	w8, #0x5                // =5
    3368:      	mov	w9, #0xc                // =12
    336c:      	ldr	x1, [x1]
    3370:      	mov	x0, x23
    3374:      	mov	w2, #0x5                // =5
    3378:      	blr	x9
    337c:      	ldp	x20, x19, [sp, #0xe0]
    3380:      	mov	w0, wzr
    3384:      	ldr	x29, [sp, #0xa0]
    3388:      	ldp	x22, x21, [sp, #0xd0]
    338c:      	ldp	x24, x23, [sp, #0xc0]
    3390:      	ldp	x30, x25, [sp, #0xb0]
    3394:      	add	sp, sp, #0xf0
    3398:      	ret
    339c:      	ldrb	w8, [x19]
    33a0:      	cbz	w8, 0x33ac <generic_retkprobe_filter_arg+0x33ac>
    33a4:      	mov	w8, wzr
    33a8:      	b	0x33f8 <generic_retkprobe_filter_arg+0x33f8>
    33ac:      	ldrb	w8, [x19, #0x1]
    33b0:      	cbz	w8, 0x33bc <generic_retkprobe_filter_arg+0x33bc>
    33b4:      	mov	w8, #0x1                // =1
    33b8:      	b	0x33f8 <generic_retkprobe_filter_arg+0x33f8>
    33bc:      	ldrb	w8, [x19, #0x2]
    33c0:      	cbz	w8, 0x33cc <generic_retkprobe_filter_arg+0x33cc>
    33c4:      	mov	w8, #0x2                // =2
    33c8:      	b	0x33f8 <generic_retkprobe_filter_arg+0x33f8>
    33cc:      	ldrb	w8, [x19, #0x3]
    33d0:      	cbz	w8, 0x33dc <generic_retkprobe_filter_arg+0x33dc>
    33d4:      	mov	w8, #0x3                // =3
    33d8:      	b	0x33f8 <generic_retkprobe_filter_arg+0x33f8>
    33dc:      	ldrb	w8, [x19, #0x4]
    33e0:      	cbz	w8, 0x33ec <generic_retkprobe_filter_arg+0x33ec>
    33e4:      	mov	w8, #0x4                // =4
    33e8:      	b	0x33f8 <generic_retkprobe_filter_arg+0x33f8>
    33ec:      	ldrb	w8, [x19, #0x5]
    33f0:      	cbz	w8, 0x3418 <generic_retkprobe_filter_arg+0x3418>
    33f4:      	mov	w8, #0x5                // =5
    33f8:      	stur	w8, [x19, #0x3f]
    33fc:      	adrp	x1, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3400:      	mov	w8, #0x3                // =3
    3404:      	mov	w9, #0xc                // =12
    3408:      	ldr	x1, [x1]
    340c:      	mov	x0, x23
    3410:      	mov	w2, #0x3                // =3
    3414:      	blr	x9
    3418:      	ldr	x19, [x20, #0x60]
    341c:      	mov	w8, #0xe                // =14
    3420:      	blr	x8
    3424:      	stp	x19, x0, [sp, #0x60]
    3428:      	adrp	x19, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    342c:      	mov	w8, #0x1                // =1
    3430:      	add	x9, sp, #0x60
    3434:      	add	x1, sp, #0x60
    3438:      	ldr	x19, [x19]
    343c:      	mov	x0, x19
    3440:      	blr	x8
    3444:      	cbz	x0, 0x337c <generic_retkprobe_filter_arg+0x337c>
    3448:      	mov	w8, #0x3                // =3
    344c:      	add	x9, sp, #0x60
    3450:      	add	x1, sp, #0x60
    3454:      	mov	x0, x19
    3458:      	blr	x8
    345c:      	b	0x337c <generic_retkprobe_filter_arg+0x337c>

0000000000003460 <generic_retkprobe_actions>:
    3460:      	sub	sp, sp, #0xe0
    3464:      	str	x29, [sp, #0x90]
    3468:      	stp	x30, x25, [sp, #0xa0]
    346c:      	stp	x24, x23, [sp, #0xb0]
    3470:      	stp	x22, x21, [sp, #0xc0]
    3474:      	stp	x20, x19, [sp, #0xd0]
    3478:      	str	x0, [sp, #0x50]
    347c:      	str	wzr, [sp, #0x5c]
    3480:      	adrp	x29, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3484:      	mov	w8, #0x1                // =1
    3488:      	add	x9, sp, #0x5c
    348c:      	add	x1, sp, #0x5c
    3490:      	ldr	x29, [x29]
    3494:      	mov	x0, x29
    3498:      	blr	x8
    349c:      	cbz	x0, 0x3f24 <generic_retkprobe_actions+0xac4>
    34a0:      	mov	w8, #0x5f04             // =24324
    34a4:      	ldr	w19, [x0, x8]
    34a8:      	cmp	w19, #0x2
    34ac:      	b.lt	0x3f24 <generic_retkprobe_actions+0xac4>
    34b0:      	mov	w8, #0x5ef8             // =24312
    34b4:      	add	x1, x0, x8
    34b8:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    34bc:      	mov	w8, #0x1                // =1
    34c0:      	ldr	x0, [x0]
    34c4:      	blr	x8
    34c8:      	cbz	x0, 0x3f24 <generic_retkprobe_actions+0xac4>
    34cc:      	and	x8, x19, #0x7ff
    34d0:      	add	x9, sp, #0x60
    34d4:      	add	x1, sp, #0x60
    34d8:      	ldr	w8, [x0, x8]
    34dc:      	str	wzr, [sp, #0x60]
    34e0:      	add	w8, w8, w19
    34e4:      	and	w8, w8, #0x7ff
    34e8:      	add	x21, x0, x8
    34ec:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    34f0:      	mov	w8, #0x1                // =1
    34f4:      	ldr	x0, [x0]
    34f8:      	blr	x8
    34fc:      	cbz	x0, 0x3544 <generic_retkprobe_actions+0xe4>
    3500:      	ldrb	w8, [x0]
    3504:      	mov	w11, #0x6               // =6
    3508:      	mov	w14, #0x7               // =7
    350c:      	mov	w10, #0x8               // =8
    3510:      	mov	w12, #0x5               // =5
    3514:      	mov	w13, #0x9               // =9
    3518:      	ands	w8, w8, #0xff
    351c:      	cset	w9, eq
    3520:      	cmp	w8, #0x0
    3524:      	str	w9, [sp, #0x48]
    3528:      	mov	w9, #0x4                // =4
    352c:      	csel	x8, x11, x14, eq
    3530:      	csel	x11, x10, x13, eq
    3534:      	str	x8, [sp, #0x30]
    3538:      	csel	x8, x9, x12, eq
    353c:      	stp	x11, x8, [sp, #0x38]
    3540:      	b	0x3564 <generic_retkprobe_actions+0x104>
    3544:      	mov	w8, #0x1                // =1
    3548:      	str	w8, [sp, #0x48]
    354c:      	mov	w8, #0x4                // =4
    3550:      	str	x8, [sp, #0x40]
    3554:      	mov	w8, #0x8                // =8
    3558:      	str	x8, [sp, #0x38]
    355c:      	mov	w8, #0x6                // =6
    3560:      	str	x8, [sp, #0x30]
    3564:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3568:      	mov	w23, wzr
    356c:      	mov	w19, wzr
    3570:      	ldr	x25, [x25]
    3574:      	add	x20, sp, #0x64
    3578:      	mov	w8, #0x1                // =1
    357c:      	str	w8, [sp, #0x4c]
    3580:      	b	0x3594 <generic_retkprobe_actions+0x134>
    3584:      	mov	w19, wzr
    3588:      	add	w23, w23, #0x1
    358c:      	cmp	w23, #0x3
    3590:      	b.eq	0x3f00 <generic_retkprobe_actions+0xaa0>
    3594:      	ldr	w9, [x21]
    3598:      	lsl	w8, w19, #2
    359c:      	add	w8, w8, #0x4
    35a0:      	cmp	w8, w9
    35a4:      	b.hs	0x3f00 <generic_retkprobe_actions+0xaa0>
    35a8:      	add	x8, x21, w19, uxtw #2
    35ac:      	add	x1, sp, #0x64
    35b0:      	mov	x0, x29
    35b4:      	ldrsw	x24, [x8, #0x4]
    35b8:      	str	wzr, [sp, #0x64]
    35bc:      	mov	w8, #0x1                // =1
    35c0:      	blr	x8
    35c4:      	cbz	x0, 0x3584 <generic_retkprobe_actions+0x124>
    35c8:      	mov	x22, x0
    35cc:      	cmp	w24, #0x7
    35d0:      	b.gt	0x3600 <generic_retkprobe_actions+0x1a0>
    35d4:      	cmp	w24, #0x3
    35d8:      	b.gt	0x3650 <generic_retkprobe_actions+0x1f0>
    35dc:      	cmp	w24, #0x1
    35e0:      	b.gt	0x36d0 <generic_retkprobe_actions+0x270>
    35e4:      	cbz	w24, 0x3834 <generic_retkprobe_actions+0x3d4>
    35e8:      	cmp	w24, #0x1
    35ec:      	b.eq	0x36e0 <generic_retkprobe_actions+0x280>
    35f0:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    35f4:      	b	0x3938 <generic_retkprobe_actions+0x4d8>
    35f8:      	nop
    35fc:      	nop
    3600:      	cmp	w24, #0xb
    3604:      	b.gt	0x36a8 <generic_retkprobe_actions+0x248>
    3608:      	sub	w8, w24, #0xa
    360c:      	cmp	w8, #0x2
    3610:      	b.lo	0x3744 <generic_retkprobe_actions+0x2e4>
    3614:      	cmp	w24, #0x8
    3618:      	b.eq	0x378c <generic_retkprobe_actions+0x32c>
    361c:      	cmp	w24, #0x9
    3620:      	b.ne	0x393c <generic_retkprobe_actions+0x4dc>
    3624:      	add	w19, w19, #0x1
    3628:      	add	x8, x21, w19, uxtw #2
    362c:      	ldr	w0, [x8, #0x4]
    3630:      	ldr	w8, [sp, #0x48]
    3634:      	add	x25, sp, #0x68
    3638:      	cbz	w8, 0x38dc <generic_retkprobe_actions+0x47c>
    363c:      	sxtw	x8, w0
    3640:      	mov	w9, #0x6d               // =109
    3644:      	blr	x9
    3648:      	mov	w20, #0x2               // =2
    364c:      	b	0x38f0 <generic_retkprobe_actions+0x490>
    3650:      	sub	w8, w24, #0x6
    3654:      	cmp	w8, #0x2
    3658:      	b.lo	0x3778 <generic_retkprobe_actions+0x318>
    365c:      	cmp	w24, #0x4
    3660:      	b.eq	0x3794 <generic_retkprobe_actions+0x334>
    3664:      	cmp	w24, #0x5
    3668:      	b.ne	0x393c <generic_retkprobe_actions+0x4dc>
    366c:      	add	w8, w19, #0x1
    3670:      	add	x9, x21, #0x4
    3674:      	add	w19, w19, #0x2
    3678:      	ldr	w8, [x9, w8, uxtw #2]
    367c:      	ldr	w20, [x9, w19, uxtw #2]
    3680:      	stp	xzr, xzr, [sp, #0x68]
    3684:      	and	x8, x8, #0x7
    3688:      	cmp	w8, #0x4
    368c:      	b.hi	0x36a0 <generic_retkprobe_actions+0x240>
    3690:      	add	x9, x22, x8, lsl #2
    3694:      	mov	w10, #0x5ea0            // =24224
    3698:      	ldr	w9, [x9, x10]
    369c:      	cbz	w9, 0x3b18 <generic_retkprobe_actions+0x6b8>
    36a0:      	add	x20, sp, #0x64
    36a4:      	b	0x393c <generic_retkprobe_actions+0x4dc>
    36a8:      	cmp	w24, #0xc
    36ac:      	b.eq	0x38e4 <generic_retkprobe_actions+0x484>
    36b0:      	cmp	w24, #0xd
    36b4:      	b.eq	0x37a4 <generic_retkprobe_actions+0x344>
    36b8:      	cmp	w24, #0xe
    36bc:      	b.ne	0x393c <generic_retkprobe_actions+0x4dc>
    36c0:      	ldr	x20, [sp, #0x38]
    36c4:      	add	x25, sp, #0x68
    36c8:      	add	w19, w19, #0x2
    36cc:      	b	0x38f0 <generic_retkprobe_actions+0x490>
    36d0:      	cmp	w24, #0x2
    36d4:      	b.eq	0x38cc <generic_retkprobe_actions+0x46c>
    36d8:      	cmp	w24, #0x3
    36dc:      	b.ne	0x35f0 <generic_retkprobe_actions+0x190>
    36e0:      	add	w8, w19, #0x1
    36e4:      	add	x9, x21, #0x4
    36e8:      	add	w19, w19, #0x2
    36ec:      	ldr	w20, [x9, w19, uxtw #2]
    36f0:      	mov	x25, x21
    36f4:      	ldr	w21, [x9, w8, uxtw #2]
    36f8:      	str	wzr, [sp, #0x78]
    36fc:      	stp	xzr, xzr, [sp, #0x68]
    3700:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3704:      	mov	w8, #0x1                // =1
    3708:      	add	x9, sp, #0x78
    370c:      	add	x1, sp, #0x78
    3710:      	ldr	x0, [x0]
    3714:      	blr	x8
    3718:      	cbz	x0, 0x372c <generic_retkprobe_actions+0x2cc>
    371c:      	and	x8, x21, #0x7
    3720:      	cmp	w8, #0x4
    3724:      	b.ls	0x3954 <generic_retkprobe_actions+0x4f4>
    3728:      	mov	w0, wzr
    372c:      	mov	x21, x25
    3730:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3734:      	add	x20, sp, #0x64
    3738:      	ldr	x25, [x25]
    373c:      	cbnz	w0, 0x3584 <generic_retkprobe_actions+0x124>
    3740:      	b	0x393c <generic_retkprobe_actions+0x4dc>
    3744:      	add	w19, w19, #0x1
    3748:      	add	x8, x21, w19, uxtw #2
    374c:      	ldr	w8, [x8, #0x4]
    3750:      	and	x8, x8, #0x7
    3754:      	cmp	w8, #0x4
    3758:      	b.hi	0x376c <generic_retkprobe_actions+0x30c>
    375c:      	add	x9, x22, x8, lsl #2
    3760:      	mov	w10, #0x5ea0            // =24224
    3764:      	ldr	w9, [x9, x10]
    3768:      	cbz	w9, 0x3970 <generic_retkprobe_actions+0x510>
    376c:      	mov	w0, wzr
    3770:      	cbnz	w0, 0x3584 <generic_retkprobe_actions+0x124>
    3774:      	b	0x393c <generic_retkprobe_actions+0x4dc>
    3778:      	add	w19, w19, #0x1
    377c:      	add	x8, x21, w19, uxtw #2
    3780:      	ldr	w8, [x8, #0x4]
    3784:      	str	w8, [x22, #0x78]
    3788:      	b	0x393c <generic_retkprobe_actions+0x4dc>
    378c:      	str	wzr, [sp, #0x4c]
    3790:      	b	0x393c <generic_retkprobe_actions+0x4dc>
    3794:      	ldr	x20, [sp, #0x40]
    3798:      	add	x25, sp, #0x68
    379c:      	add	w19, w19, #0x1
    37a0:      	b	0x38f0 <generic_retkprobe_actions+0x490>
    37a4:      	mov	w8, #0xe                // =14
    37a8:      	blr	x8
    37ac:      	str	x0, [sp, #0x88]
    37b0:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    37b4:      	mov	w8, #0x1                // =1
    37b8:      	add	x9, sp, #0x88
    37bc:      	ldr	x0, [x0]
    37c0:      	add	x1, sp, #0x88
    37c4:      	blr	x8
    37c8:      	cbz	x0, 0x393c <generic_retkprobe_actions+0x4dc>
    37cc:      	ldur	x8, [x0, #0x4]
    37d0:      	mov	x20, x21
    37d4:      	add	x21, sp, #0x78
    37d8:      	add	x1, sp, #0x78
    37dc:      	str	x8, [sp, #0x78]
    37e0:      	mov	w8, #0x2                // =2
    37e4:      	mov	x0, x25
    37e8:      	str	w8, [sp, #0x80]
    37ec:      	mov	w8, #0x1                // =1
    37f0:      	blr	x8
    37f4:      	mov	w9, #0x1                // =1
    37f8:      	str	w9, [sp, #0x98]
    37fc:      	cbz	x0, 0x3aa8 <generic_retkprobe_actions+0x648>
    3800:      	ldaxr	w8, [x0]
    3804:      	add	w8, w8, #0x1
    3808:      	stlxr	w9, w8, [x0]
    380c:      	cbnz	w9, 0x3800 <generic_retkprobe_actions+0x3a0>
    3810:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3814:      	mov	w8, #0x3                // =3
    3818:      	add	x9, sp, #0x88
    381c:      	ldr	x0, [x0]
    3820:      	add	x1, sp, #0x88
    3824:      	blr	x8
    3828:      	mov	x21, x20
    382c:      	add	x20, sp, #0x64
    3830:      	b	0x393c <generic_retkprobe_actions+0x4dc>
    3834:      	add	w8, w19, #0x1
    3838:      	add	x9, x21, #0x4
    383c:      	ldr	w25, [x9, w8, uxtw #2]
    3840:      	add	w8, w19, #0x2
    3844:      	ldr	w20, [x9, w8, uxtw #2]
    3848:      	mov	w8, #0x7d               // =125
    384c:      	blr	x8
    3850:      	str	x0, [sp, #0x68]
    3854:      	str	wzr, [sp, #0x88]
    3858:      	str	x25, [sp, #0x18]
    385c:      	cbz	w25, 0x3dfc <generic_retkprobe_actions+0x99c>
    3860:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3864:      	mov	w8, #0x1                // =1
    3868:      	add	x9, sp, #0x88
    386c:      	ldr	x0, [x0]
    3870:      	add	x1, sp, #0x88
    3874:      	blr	x8
    3878:      	cbz	x0, 0x3dfc <generic_retkprobe_actions+0x99c>
    387c:      	mov	x25, x0
    3880:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3884:      	mov	w8, #0x1                // =1
    3888:      	ldr	x0, [x0]
    388c:      	add	x9, sp, #0x88
    3890:      	add	x1, sp, #0x88
    3894:      	blr	x8
    3898:      	ldr	x8, [x22, #0x60]
    389c:      	mov	x2, x0
    38a0:      	cmp	w20, #0x2
    38a4:      	str	x8, [x25]
    38a8:      	ldr	x8, [x22, #0x70]
    38ac:      	str	x8, [x25, #0x8]
    38b0:      	b.eq	0x3c1c <generic_retkprobe_actions+0x7bc>
    38b4:      	cmp	w20, #0x1
    38b8:      	b.eq	0x3c10 <generic_retkprobe_actions+0x7b0>
    38bc:      	cbnz	w20, 0x3dfc <generic_retkprobe_actions+0x99c>
    38c0:      	ldr	w8, [x22, #0x7c]
    38c4:      	str	x21, [sp, #0x8]
    38c8:      	b	0x3c24 <generic_retkprobe_actions+0x7c4>
    38cc:      	mov	w0, #0x9                // =9
    38d0:      	ldr	w8, [sp, #0x48]
    38d4:      	add	x25, sp, #0x68
    38d8:      	cbnz	w8, 0x363c <generic_retkprobe_actions+0x1dc>
    38dc:      	mov	w20, #0x3               // =3
    38e0:      	b	0x38f0 <generic_retkprobe_actions+0x490>
    38e4:      	ldr	x20, [sp, #0x30]
    38e8:      	add	x25, sp, #0x68
    38ec:      	add	w19, w19, #0x3
    38f0:      	str	wzr, [sp, #0x68]
    38f4:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    38f8:      	mov	w8, #0x1                // =1
    38fc:      	add	x1, sp, #0x68
    3900:      	ldr	x0, [x0]
    3904:      	blr	x8
    3908:      	cbz	x0, 0x3930 <generic_retkprobe_actions+0x4d0>
    390c:      	add	x8, x0, x20, lsl #3
    3910:      	nop
    3914:      	nop
    3918:      	nop
    391c:      	nop
    3920:      	ldaxr	x9, [x8]
    3924:      	add	x9, x9, #0x1
    3928:      	stlxr	w10, x9, [x8]
    392c:      	cbnz	w10, 0x3920 <generic_retkprobe_actions+0x4c0>
    3930:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3934:      	add	x20, sp, #0x64
    3938:      	ldr	x25, [x25]
    393c:      	add	w19, w19, #0x1
    3940:      	str	x24, [x22, #0x70]
    3944:      	add	w23, w23, #0x1
    3948:      	cmp	w23, #0x3
    394c:      	b.ne	0x3594 <generic_retkprobe_actions+0x134>
    3950:      	b	0x3f00 <generic_retkprobe_actions+0xaa0>
    3954:      	add	x9, x22, x8, lsl #2
    3958:      	mov	w10, #0x5ea0            // =24224
    395c:      	ldr	w9, [x9, x10]
    3960:      	cbz	w9, 0x3a08 <generic_retkprobe_actions+0x5a8>
    3964:      	mov	x21, x25
    3968:      	mov	w0, wzr
    396c:      	b	0x3730 <generic_retkprobe_actions+0x2d0>
    3970:      	add	x8, x22, x8, lsl #3
    3974:      	ldr	x8, [x8, #0x5e78]
    3978:      	and	x8, x8, #0x7ff
    397c:      	add	x8, x22, x8
    3980:      	ldr	x8, [x8, #0xb8]
    3984:      	str	x8, [sp, #0x78]
    3988:      	cbz	x8, 0x376c <generic_retkprobe_actions+0x30c>
    398c:      	cmp	w24, #0xa
    3990:      	b.ne	0x3bf0 <generic_retkprobe_actions+0x790>
    3994:      	mov	w8, #0xe                // =14
    3998:      	add	x25, sp, #0x68
    399c:      	mov	x20, x21
    39a0:      	blr	x8
    39a4:      	lsr	x8, x0, #32
    39a8:      	mov	x21, x0
    39ac:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    39b0:      	str	w8, [sp, #0x68]
    39b4:      	mov	w8, #0x1                // =1
    39b8:      	add	x1, sp, #0x68
    39bc:      	ldr	x0, [x0]
    39c0:      	blr	x8
    39c4:      	cbz	x0, 0x39fc <generic_retkprobe_actions+0x59c>
    39c8:      	ldr	w8, [x0]
    39cc:      	mov	x3, xzr
    39d0:      	add	x9, sp, #0x78
    39d4:      	add	x1, sp, #0x78
    39d8:      	stp	w8, w21, [sp, #0x68]
    39dc:      	ldr	x8, [x0, #0x8]
    39e0:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    39e4:      	add	x2, sp, #0x68
    39e8:      	str	x8, [sp, #0x70]
    39ec:      	mov	w8, #0x2                // =2
    39f0:      	ldr	x0, [x0]
    39f4:      	blr	x8
    39f8:      	mov	w0, wzr
    39fc:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3a00:      	mov	x21, x20
    3a04:      	b	0x3734 <generic_retkprobe_actions+0x2d4>
    3a08:      	add	x8, x22, x8, lsl #3
    3a0c:      	mov	x21, x0
    3a10:      	ldr	x8, [x8, #0x5e78]
    3a14:      	str	wzr, [sp, #0x74]
    3a18:      	and	x8, x8, #0x7ff
    3a1c:      	add	x8, x22, x8
    3a20:      	ldr	w8, [x8, #0x90]
    3a24:      	str	w8, [sp, #0x70]
    3a28:      	mov	w8, #0xe                // =14
    3a2c:      	blr	x8
    3a30:      	lsr	x8, x0, #32
    3a34:      	cmp	w24, #0x1
    3a38:      	str	x8, [sp, #0x68]
    3a3c:      	b.ne	0x3bd4 <generic_retkprobe_actions+0x774>
    3a40:      	and	x8, x20, #0x7
    3a44:      	cmp	w8, #0x4
    3a48:      	b.hi	0x3728 <generic_retkprobe_actions+0x2c8>
    3a4c:      	add	x9, x22, x8, lsl #2
    3a50:      	mov	w10, #0x5ea0            // =24224
    3a54:      	add	x20, sp, #0x68
    3a58:      	ldr	w9, [x9, x10]
    3a5c:      	cbnz	w9, 0x3728 <generic_retkprobe_actions+0x2c8>
    3a60:      	add	x8, x22, x8, lsl #3
    3a64:      	mov	x0, x21
    3a68:      	ldr	x8, [x8, #0x5e78]
    3a6c:      	and	x8, x8, #0x7ff
    3a70:      	add	x2, x22, x8
    3a74:      	ldr	w8, [x2, #0x90]!
    3a78:      	and	x8, x8, #0xfff
    3a7c:      	add	x1, x8, #0x8
    3a80:      	mov	w8, #0x4                // =4
    3a84:      	blr	x8
    3a88:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3a8c:      	mov	x3, xzr
    3a90:      	mov	w8, #0x2                // =2
    3a94:      	ldr	x0, [x0]
    3a98:      	add	x1, sp, #0x68
    3a9c:      	mov	x2, x21
    3aa0:      	blr	x8
    3aa4:      	b	0x3728 <generic_retkprobe_actions+0x2c8>
    3aa8:      	mov	w8, #0x2                // =2
    3aac:      	add	x10, sp, #0x98
    3ab0:      	add	x1, sp, #0x78
    3ab4:      	add	x2, sp, #0x98
    3ab8:      	mov	x0, x25
    3abc:      	mov	w3, #0x1                // =1
    3ac0:      	blr	x8
    3ac4:      	cbz	x0, 0x3810 <generic_retkprobe_actions+0x3b0>
    3ac8:      	mov	x21, x0
    3acc:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3ad0:      	add	x9, sp, #0x68
    3ad4:      	add	x1, sp, #0x68
    3ad8:      	neg	w8, w21
    3adc:      	strh	w8, [sp, #0x68]
    3ae0:      	mov	w8, #0x3                // =3
    3ae4:      	strh	w8, [sp, #0x6a]
    3ae8:      	mov	x8, #0x3b               // =59
    3aec:      	movk	x8, #0x2, lsl #32
    3af0:      	stur	x8, [sp, #0x6c]
    3af4:      	mov	w8, #0x1                // =1
    3af8:      	ldr	x25, [x25]
    3afc:      	mov	x0, x25
    3b00:      	blr	x8
    3b04:      	cbz	x0, 0x3e9c <generic_retkprobe_actions+0xa3c>
    3b08:      	ldr	w8, [x0]
    3b0c:      	add	w8, w8, #0x1
    3b10:      	str	w8, [x0]
    3b14:      	b	0x3ec4 <generic_retkprobe_actions+0xa64>
    3b18:      	add	x8, x22, x8, lsl #3
    3b1c:      	ldr	x8, [x8, #0x5e78]
    3b20:      	and	x8, x8, #0x7ff
    3b24:      	add	x8, x22, x8
    3b28:      	ldr	w8, [x8, #0x90]
    3b2c:      	str	w8, [sp, #0x70]
    3b30:      	mov	w8, #0xe                // =14
    3b34:      	blr	x8
    3b38:      	lsr	x8, x0, #32
    3b3c:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3b40:      	add	x9, sp, #0x68
    3b44:      	str	x8, [sp, #0x68]
    3b48:      	mov	w8, #0x1                // =1
    3b4c:      	add	x1, sp, #0x68
    3b50:      	ldr	x0, [x0]
    3b54:      	blr	x8
    3b58:      	cbz	x0, 0x36a0 <generic_retkprobe_actions+0x240>
    3b5c:      	and	x8, x20, #0x7
    3b60:      	cmp	w8, #0x4
    3b64:      	b.hi	0x36a0 <generic_retkprobe_actions+0x240>
    3b68:      	add	x9, x22, x8, lsl #2
    3b6c:      	mov	w10, #0x5ea0            // =24224
    3b70:      	ldr	w9, [x9, x10]
    3b74:      	cbnz	w9, 0x36a0 <generic_retkprobe_actions+0x240>
    3b78:      	add	x8, x22, x8, lsl #3
    3b7c:      	mov	x20, x21
    3b80:      	mov	x21, x0
    3b84:      	ldr	x8, [x8, #0x5e78]
    3b88:      	str	wzr, [sp, #0x74]
    3b8c:      	and	x8, x8, #0x7ff
    3b90:      	add	x8, x22, x8
    3b94:      	ldr	w8, [x8, #0x90]
    3b98:      	str	w8, [sp, #0x70]
    3b9c:      	mov	w8, #0xe                // =14
    3ba0:      	blr	x8
    3ba4:      	lsr	x8, x0, #32
    3ba8:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3bac:      	mov	x3, xzr
    3bb0:      	str	x8, [sp, #0x68]
    3bb4:      	mov	w8, #0x2                // =2
    3bb8:      	add	x9, sp, #0x68
    3bbc:      	add	x1, sp, #0x68
    3bc0:      	ldr	x0, [x0]
    3bc4:      	mov	x2, x21
    3bc8:      	mov	x21, x20
    3bcc:      	blr	x8
    3bd0:      	b	0x36a0 <generic_retkprobe_actions+0x240>
    3bd4:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3bd8:      	mov	w8, #0x3                // =3
    3bdc:      	add	x9, sp, #0x68
    3be0:      	ldr	x0, [x0]
    3be4:      	add	x1, sp, #0x68
    3be8:      	blr	x8
    3bec:      	b	0x372c <generic_retkprobe_actions+0x2cc>
    3bf0:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3bf4:      	mov	w8, #0x3                // =3
    3bf8:      	add	x9, sp, #0x78
    3bfc:      	ldr	x0, [x0]
    3c00:      	add	x1, sp, #0x78
    3c04:      	blr	x8
    3c08:      	cbnz	w0, 0x3584 <generic_retkprobe_actions+0x124>
    3c0c:      	b	0x393c <generic_retkprobe_actions+0x4dc>
    3c10:      	ldr	w8, [x22, #0x10]
    3c14:      	str	x21, [sp, #0x8]
    3c18:      	b	0x3c24 <generic_retkprobe_actions+0x7c4>
    3c1c:      	str	x21, [sp, #0x8]
    3c20:      	mov	x8, xzr
    3c24:      	str	x8, [x25, #0x10]
    3c28:      	str	x25, [sp, #0x10]
    3c2c:      	add	x0, x25, #0x18
    3c30:      	mov	w8, #0x4                // =4
    3c34:      	mov	w9, #0xc8               // =200
    3c38:      	mov	w1, #0xc8               // =200
    3c3c:      	str	x0, [sp, #0x20]
    3c40:      	blr	x8
    3c44:      	str	wzr, [sp, #0x2c]
    3c48:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3c4c:      	mov	w8, #0x5e78             // =24184
    3c50:      	mov	x21, xzr
    3c54:      	ldr	x25, [x25]
    3c58:      	add	x20, x22, x8
    3c5c:      	b	0x3c70 <generic_retkprobe_actions+0x810>
    3c60:      	add	x21, x21, #0x4
    3c64:      	add	x20, x20, #0x8
    3c68:      	cmp	x21, #0x14
    3c6c:      	b.eq	0x3d98 <generic_retkprobe_actions+0x938>
    3c70:      	str	wzr, [sp, #0x78]
    3c74:      	mov	w8, #0x1                // =1
    3c78:      	add	x9, sp, #0x78
    3c7c:      	add	x1, sp, #0x78
    3c80:      	mov	x0, x29
    3c84:      	blr	x8
    3c88:      	cbz	x0, 0x3d98 <generic_retkprobe_actions+0x938>
    3c8c:      	mov	w8, #0x5ef8             // =24312
    3c90:      	add	x1, x0, x8
    3c94:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3c98:      	mov	w8, #0x1                // =1
    3c9c:      	ldr	x0, [x0]
    3ca0:      	blr	x8
    3ca4:      	cbz	x0, 0x3d98 <generic_retkprobe_actions+0x938>
    3ca8:      	add	x8, x0, x21
    3cac:      	ldr	w8, [x8, #0x40]
    3cb0:      	cmn	w8, #0x1
    3cb4:      	b.eq	0x3d98 <generic_retkprobe_actions+0x938>
    3cb8:      	ldr	x8, [x20]
    3cbc:      	ldr	w9, [x22, #0x4]
    3cc0:      	cmp	x8, x9
    3cc4:      	b.ge	0x3d98 <generic_retkprobe_actions+0x938>
    3cc8:      	cmp	x21, #0x10
    3ccc:      	b.eq	0x3d2c <generic_retkprobe_actions+0x8cc>
    3cd0:      	str	wzr, [sp, #0x78]
    3cd4:      	mov	w8, #0x1                // =1
    3cd8:      	add	x9, sp, #0x78
    3cdc:      	add	x1, sp, #0x78
    3ce0:      	mov	x0, x29
    3ce4:      	blr	x8
    3ce8:      	cbz	x0, 0x3d28 <generic_retkprobe_actions+0x8c8>
    3cec:      	mov	w8, #0x5ef8             // =24312
    3cf0:      	add	x1, x0, x8
    3cf4:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3cf8:      	mov	w8, #0x1                // =1
    3cfc:      	ldr	x0, [x0]
    3d00:      	blr	x8
    3d04:      	cbz	x0, 0x3d28 <generic_retkprobe_actions+0x8c8>
    3d08:      	add	x8, x0, x21
    3d0c:      	ldr	w9, [x8, #0x44]
    3d10:      	ldr	x8, [x20]
    3d14:      	cmn	w9, #0x1
    3d18:      	b.eq	0x3d2c <generic_retkprobe_actions+0x8cc>
    3d1c:      	ldr	w9, [x20, #0x8]
    3d20:      	sub	w9, w9, w8
    3d24:      	b	0x3d38 <generic_retkprobe_actions+0x8d8>
    3d28:      	ldr	x8, [x20]
    3d2c:      	ldr	w9, [x22, #0x4]
    3d30:      	sub	w9, w9, w8
    3d34:      	add	w9, w9, #0x4
    3d38:      	cmp	w9, #0x1
    3d3c:      	b.lt	0x3c60 <generic_retkprobe_actions+0x800>
    3d40:      	mov	w10, #0x3ffc            // =16380
    3d44:      	cmp	w9, #0x28
    3d48:      	add	w8, w8, w10
    3d4c:      	mov	w10, #0x28              // =40
    3d50:      	csel	w29, w9, w10, lt
    3d54:      	ldr	w9, [sp, #0x2c]
    3d58:      	and	x8, x8, #0x3fff
    3d5c:      	add	x8, x22, x8
    3d60:      	mov	w1, w29
    3d64:      	add	x2, x8, #0x90
    3d68:      	mov	w8, #0x4                // =4
    3d6c:      	and	w25, w9, #0xff
    3d70:      	ldr	x9, [sp, #0x20]
    3d74:      	add	x0, x9, x25
    3d78:      	blr	x8
    3d7c:      	add	w8, w29, w25
    3d80:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3d84:      	adrp	x29, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3d88:      	str	w8, [sp, #0x2c]
    3d8c:      	ldr	x25, [x25]
    3d90:      	ldr	x29, [x29]
    3d94:      	b	0x3c60 <generic_retkprobe_actions+0x800>
    3d98:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3d9c:      	mov	w8, #0x1                // =1
    3da0:      	ldr	x0, [x0]
    3da4:      	ldr	x1, [sp, #0x10]
    3da8:      	blr	x8
    3dac:      	ldr	x21, [sp, #0x8]
    3db0:      	cbz	x0, 0x3ddc <generic_retkprobe_actions+0x97c>
    3db4:      	ldr	x9, [sp, #0x68]
    3db8:      	ldr	x11, [sp, #0x18]
    3dbc:      	mov	x10, #-0x4240           // =-16960
    3dc0:      	movk	x10, #0xfff0, lsl #16
    3dc4:      	ldr	x8, [x0]
    3dc8:      	madd	x9, x11, x10, x9
    3dcc:      	cmp	x8, x9
    3dd0:      	b.ls	0x3ddc <generic_retkprobe_actions+0x97c>
    3dd4:      	str	wzr, [sp, #0x4c]
    3dd8:      	b	0x3e04 <generic_retkprobe_actions+0x9a4>
    3ddc:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3de0:      	mov	x3, xzr
    3de4:      	mov	w8, #0x2                // =2
    3de8:      	ldr	x0, [x0]
    3dec:      	ldr	x1, [sp, #0x10]
    3df0:      	add	x9, sp, #0x68
    3df4:      	add	x2, sp, #0x68
    3df8:      	blr	x8
    3dfc:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3e00:      	ldr	x25, [x25]
    3e04:      	add	w8, w19, #0x3
    3e08:      	add	x20, sp, #0x64
    3e0c:      	add	x8, x21, w8, uxtw #2
    3e10:      	ldr	w8, [x8, #0x4]
    3e14:      	cbz	w8, 0x3e40 <generic_retkprobe_actions+0x9e0>
    3e18:      	ldrb	w8, [x22, #0x1]
    3e1c:      	adrp	x1, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3e20:      	ldr	x0, [sp, #0x50]
    3e24:      	mov	x2, xzr
    3e28:      	orr	w8, w8, #0x2
    3e2c:      	strb	w8, [x22, #0x1]
    3e30:      	mov	w8, #0x1b               // =27
    3e34:      	ldr	x1, [x1]
    3e38:      	blr	x8
    3e3c:      	str	x0, [x22, #0x80]
    3e40:      	add	w8, w19, #0x4
    3e44:      	add	x8, x21, w8, uxtw #2
    3e48:      	ldr	w8, [x8, #0x4]
    3e4c:      	cbz	w8, 0x3e7c <generic_retkprobe_actions+0xa1c>
    3e50:      	ldrb	w8, [x22, #0x1]
    3e54:      	adrp	x1, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3e58:      	ldr	x0, [sp, #0x50]
    3e5c:      	mov	w9, #0x100              // =256
    3e60:      	mov	w2, #0x100              // =256
    3e64:      	orr	w8, w8, #0x4
    3e68:      	strb	w8, [x22, #0x1]
    3e6c:      	mov	w8, #0x1b               // =27
    3e70:      	ldr	x1, [x1]
    3e74:      	blr	x8
    3e78:      	str	x0, [x22, #0x88]
    3e7c:      	add	w19, w19, #0x5
    3e80:      	add	x8, x21, w19, uxtw #2
    3e84:      	ldr	w8, [x8, #0x4]
    3e88:      	cbz	w8, 0x393c <generic_retkprobe_actions+0x4dc>
    3e8c:      	ldrb	w8, [x22, #0x1]
    3e90:      	orr	w8, w8, #0x8
    3e94:      	strb	w8, [x22, #0x1]
    3e98:      	b	0x393c <generic_retkprobe_actions+0x4dc>
    3e9c:      	mov	w8, #0x1                // =1
    3ea0:      	mov	x3, xzr
    3ea4:      	add	x9, sp, #0x9c
    3ea8:      	str	w8, [sp, #0x9c]
    3eac:      	mov	w8, #0x2                // =2
    3eb0:      	add	x10, sp, #0x68
    3eb4:      	add	x1, sp, #0x68
    3eb8:      	add	x2, sp, #0x9c
    3ebc:      	mov	x0, x25
    3ec0:      	blr	x8
    3ec4:      	adrp	x25, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3ec8:      	ldr	x25, [x25]
    3ecc:      	cbz	w21, 0x3810 <generic_retkprobe_actions+0x3b0>
    3ed0:      	mov	w8, #0x1                // =1
    3ed4:      	add	x9, sp, #0x78
    3ed8:      	add	x1, sp, #0x78
    3edc:      	mov	x0, x25
    3ee0:      	blr	x8
    3ee4:      	cbz	x0, 0x3810 <generic_retkprobe_actions+0x3b0>
    3ee8:      	ldr	w8, [sp, #0x98]
    3eec:      	ldaxr	w9, [x0]
    3ef0:      	add	w9, w9, w8
    3ef4:      	stlxr	w10, w9, [x0]
    3ef8:      	cbnz	w10, 0x3eec <generic_retkprobe_actions+0xa8c>
    3efc:      	b	0x3810 <generic_retkprobe_actions+0x3b0>
    3f00:      	ldr	w8, [sp, #0x4c]
    3f04:      	cbz	w8, 0x3f24 <generic_retkprobe_actions+0xac4>
    3f08:      	adrp	x1, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3f0c:      	mov	w8, #0x5                // =5
    3f10:      	mov	w9, #0xc                // =12
    3f14:      	ldr	x1, [x1]
    3f18:      	ldr	x0, [sp, #0x50]
    3f1c:      	mov	w2, #0x5                // =5
    3f20:      	blr	x9
    3f24:      	ldp	x20, x19, [sp, #0xd0]
    3f28:      	mov	w0, wzr
    3f2c:      	ldr	x29, [sp, #0x90]
    3f30:      	ldp	x22, x21, [sp, #0xc0]
    3f34:      	ldp	x24, x23, [sp, #0xb0]
    3f38:      	ldp	x30, x25, [sp, #0xa0]
    3f3c:      	add	sp, sp, #0xe0
    3f40:      	ret
    3f44:      	nop
    3f48:      	nop
    3f4c:      	nop

0000000000003f50 <generic_retkprobe_output>:
    3f50:      	sub	sp, sp, #0x30
    3f54:      	stp	x30, x21, [sp, #0x10]
    3f58:      	stp	x20, x19, [sp, #0x20]
    3f5c:      	mov	x20, x0
    3f60:      	str	wzr, [sp, #0x4]
    3f64:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3f68:      	mov	w8, #0x1                // =1
    3f6c:      	ldr	x0, [x0]
    3f70:      	add	x9, sp, #0x4
    3f74:      	add	x1, sp, #0x4
    3f78:      	blr	x8
    3f7c:      	cbz	x0, 0x41f0 <generic_retkprobe_output+0x2a0>
    3f80:      	ldr	w8, [x0, #0x4]
    3f84:      	mov	x19, x0
    3f88:      	mov	w9, #0x2328             // =9000
    3f8c:      	str	wzr, [sp, #0x8]
    3f90:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3f94:      	add	x1, sp, #0x8
    3f98:      	ldr	x0, [x0]
    3f9c:      	add	w8, w8, #0x90
    3fa0:      	and	w8, w8, #0x7fff
    3fa4:      	cmp	w8, w9
    3fa8:      	csel	w21, w8, w9, lo
    3fac:      	mov	w8, #0x1                // =1
    3fb0:      	add	x9, sp, #0x8
    3fb4:      	blr	x8
    3fb8:      	cbz	x0, 0x4034 <generic_retkprobe_output+0xe4>
    3fbc:      	ldrb	w8, [x0, #0x28]
    3fc0:      	cbz	w8, 0x4034 <generic_retkprobe_output+0xe4>
    3fc4:      	adrp	x1, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3fc8:      	mov	w8, #-0x1               // =-1
    3fcc:      	mov	w9, #0x19               // =25
    3fd0:      	ldr	x1, [x1]
    3fd4:      	mov	x0, x20
    3fd8:      	mov	w2, #-0x1               // =-1
    3fdc:      	mov	x3, x19
    3fe0:      	mov	x4, x21
    3fe4:      	blr	x9
    3fe8:      	tbnz	x0, #0x3f, 0x40e4 <generic_retkprobe_output+0x194>
    3fec:      	str	wzr, [sp, #0xc]
    3ff0:      	adrp	x0, 0x3000 <generic_retkprobe_filter_arg+0x3000>
    3ff4:      	mov	w8, #0x1                // =1
    3ff8:      	add	x9, sp, #0xc
    3ffc:      	ldr	x0, [x0]
    4000:      	add	x1, sp, #0xc
    4004:      	blr	x8
    4008:      	cbz	x0, 0x41f0 <generic_retkprobe_output+0x2a0>
    400c:      	add	x8, x0, #0x8
    4010:      	nop
    4014:      	nop
    4018:      	nop
    401c:      	nop
    4020:      	ldaxr	x9, [x8]
    4024:      	add	x9, x9, #0x1
    4028:      	stlxr	w10, x9, [x8]
    402c:      	cbnz	w10, 0x4020 <generic_retkprobe_output+0xd0>
    4030:      	b	0x41f0 <generic_retkprobe_output+0x2a0>
    4034:      	adrp	x0, 0x4000 <generic_retkprobe_output+0xb0>
    4038:      	mov	x3, xzr
    403c:      	mov	w8, #0x82               // =130
    4040:      	ldr	x0, [x0]
    4044:      	mov	x1, x19
    4048:      	mov	x2, x21
    404c:      	blr	x8
    4050:      	tbnz	x0, #0x3f, 0x4094 <generic_retkprobe_output+0x144>
    4054:      	str	wzr, [sp, #0xc]
    4058:      	adrp	x0, 0x4000 <generic_retkprobe_output+0xb0>
    405c:      	mov	w8, #0x1                // =1
    4060:      	add	x9, sp, #0xc
    4064:      	ldr	x0, [x0]
    4068:      	add	x1, sp, #0xc
    406c:      	blr	x8
    4070:      	cbz	x0, 0x41f0 <generic_retkprobe_output+0x2a0>
    4074:      	add	x8, x0, #0x8
    4078:      	nop
    407c:      	nop
    4080:      	ldaxr	x9, [x8]
    4084:      	add	x9, x9, #0x1
    4088:      	stlxr	w10, x9, [x8]
    408c:      	cbnz	w10, 0x4080 <generic_retkprobe_output+0x130>
    4090:      	b	0x41f0 <generic_retkprobe_output+0x2a0>
    4094:      	mov	x19, x0
    4098:      	str	wzr, [sp, #0xc]
    409c:      	adrp	x0, 0x4000 <generic_retkprobe_output+0xb0>
    40a0:      	mov	w8, #0x1                // =1
    40a4:      	ldr	x0, [x0]
    40a8:      	add	x9, sp, #0xc
    40ac:      	add	x1, sp, #0xc
    40b0:      	blr	x8
    40b4:      	cbz	x0, 0x41f0 <generic_retkprobe_output+0x2a0>
    40b8:      	mov	x8, x19
    40bc:      	cmn	x19, #0xc
    40c0:      	b.gt	0x4134 <generic_retkprobe_output+0x1e4>
    40c4:      	cmn	x8, #0x1c
    40c8:      	b.eq	0x4174 <generic_retkprobe_output+0x224>
    40cc:      	cmn	x8, #0x16
    40d0:      	b.eq	0x418c <generic_retkprobe_output+0x23c>
    40d4:      	cmn	x8, #0x10
    40d8:      	b.ne	0x4184 <generic_retkprobe_output+0x234>
    40dc:      	add	x8, x0, #0x2f0
    40e0:      	b	0x41a0 <generic_retkprobe_output+0x250>
    40e4:      	mov	x19, x0
    40e8:      	str	wzr, [sp, #0xc]
    40ec:      	adrp	x0, 0x4000 <generic_retkprobe_output+0xb0>
    40f0:      	mov	w8, #0x1                // =1
    40f4:      	ldr	x0, [x0]
    40f8:      	add	x9, sp, #0xc
    40fc:      	add	x1, sp, #0xc
    4100:      	blr	x8
    4104:      	cbz	x0, 0x41f0 <generic_retkprobe_output+0x2a0>
    4108:      	mov	x8, x19
    410c:      	cmn	x19, #0xc
    4110:      	b.gt	0x4154 <generic_retkprobe_output+0x204>
    4114:      	cmn	x8, #0x1c
    4118:      	b.eq	0x41b4 <generic_retkprobe_output+0x264>
    411c:      	cmn	x8, #0x16
    4120:      	b.eq	0x41cc <generic_retkprobe_output+0x27c>
    4124:      	cmn	x8, #0x10
    4128:      	b.ne	0x41c4 <generic_retkprobe_output+0x274>
    412c:      	add	x8, x0, #0x2f0
    4130:      	b	0x41e0 <generic_retkprobe_output+0x290>
    4134:      	cmn	x8, #0xb
    4138:      	b.eq	0x417c <generic_retkprobe_output+0x22c>
    413c:      	cmn	x8, #0x7
    4140:      	b.eq	0x4194 <generic_retkprobe_output+0x244>
    4144:      	cmn	x8, #0x2
    4148:      	b.ne	0x4184 <generic_retkprobe_output+0x234>
    414c:      	add	x8, x0, #0x2e0
    4150:      	b	0x41a0 <generic_retkprobe_output+0x250>
    4154:      	cmn	x8, #0xb
    4158:      	b.eq	0x41bc <generic_retkprobe_output+0x26c>
    415c:      	cmn	x8, #0x7
    4160:      	b.eq	0x41d4 <generic_retkprobe_output+0x284>
    4164:      	cmn	x8, #0x2
    4168:      	b.ne	0x41c4 <generic_retkprobe_output+0x274>
    416c:      	add	x8, x0, #0x2e0
    4170:      	b	0x41e0 <generic_retkprobe_output+0x290>
    4174:      	add	x8, x0, #0x300
    4178:      	b	0x41a0 <generic_retkprobe_output+0x250>
    417c:      	add	x8, x0, #0x308
    4180:      	b	0x41a0 <generic_retkprobe_output+0x250>
    4184:      	add	x8, x0, #0x2d8
    4188:      	b	0x41a0 <generic_retkprobe_output+0x250>
    418c:      	add	x8, x0, #0x2f8
    4190:      	b	0x41a0 <generic_retkprobe_output+0x250>
    4194:      	add	x8, x0, #0x2e8
    4198:      	nop
    419c:      	nop
    41a0:      	ldaxr	x9, [x8]
    41a4:      	add	x9, x9, #0x1
    41a8:      	stlxr	w10, x9, [x8]
    41ac:      	cbnz	w10, 0x41a0 <generic_retkprobe_output+0x250>
    41b0:      	b	0x41f0 <generic_retkprobe_output+0x2a0>
    41b4:      	add	x8, x0, #0x300
    41b8:      	b	0x41e0 <generic_retkprobe_output+0x290>
    41bc:      	add	x8, x0, #0x308
    41c0:      	b	0x41e0 <generic_retkprobe_output+0x290>
    41c4:      	add	x8, x0, #0x2d8
    41c8:      	b	0x41e0 <generic_retkprobe_output+0x290>
    41cc:      	add	x8, x0, #0x2f8
    41d0:      	b	0x41e0 <generic_retkprobe_output+0x290>
    41d4:      	add	x8, x0, #0x2e8
    41d8:      	nop
    41dc:      	nop
    41e0:      	ldaxr	x9, [x8]
    41e4:      	add	x9, x9, #0x1
    41e8:      	stlxr	w10, x9, [x8]
    41ec:      	cbnz	w10, 0x41e0 <generic_retkprobe_output+0x290>
    41f0:      	ldp	x20, x19, [sp, #0x20]
    41f4:      	mov	w0, wzr
    41f8:      	ldp	x30, x21, [sp, #0x10]
    41fc:      	add	sp, sp, #0x30
    4200:      	ret

Disassembly of section kprobe/generic_retkprobe:

0000000000000000 <generic_retkprobe_event>:
       0:      	sub	sp, sp, #0x160
       4:      	str	x29, [sp, #0x110]
       8:      	stp	x30, x25, [sp, #0x120]
       c:      	stp	x24, x23, [sp, #0x130]
      10:      	stp	x22, x21, [sp, #0x140]
      14:      	stp	x20, x19, [sp, #0x150]
      18:      	ldr	x8, [x0]
      1c:      	str	wzr, [sp, #0x6c]
      20:      	adrp	x24, 0x0 <generic_retkprobe_event>
      24:      	add	x9, sp, #0x6c
      28:      	mov	x19, x0
      2c:      	add	x1, sp, #0x6c
      30:      	str	x8, [sp, #0x70]
      34:      	mov	w8, #0x1                // =1
      38:      	ldr	x24, [x24]
      3c:      	mov	x0, x24
      40:      	blr	x8
      44:      	cbz	x0, 0x5a4 <generic_retkprobe_event+0x5a4>
      48:      	mov	w8, #0x5ea0             // =24224
      4c:      	mov	x20, x0
      50:      	add	x25, x0, x8
      54:      	adrp	x0, 0x0 <generic_retkprobe_event>
      58:      	mov	w8, #0x1                // =1
      5c:      	mov	x1, x25
      60:      	str	wzr, [x1, #0x58]!
      64:      	ldr	x0, [x0]
      68:      	blr	x8
      6c:      	cbz	x0, 0x5a4 <generic_retkprobe_event+0x5a4>
      70:      	ldr	w8, [x0]
      74:      	mov	x29, x0
      78:      	str	x8, [x20, #0x60]
      7c:      	mov	w8, #0xe                // =14
      80:      	blr	x8
      84:      	cmn	x0, #0x16
      88:      	b.ne	0xac <generic_retkprobe_event+0xac>
      8c:      	add	x2, x19, #0xe8
      90:      	mov	w8, #0x8                // =8
      94:      	mov	w9, #0x4                // =4
      98:      	add	x10, sp, #0xa8
      9c:      	add	x0, sp, #0xa8
      a0:      	mov	w1, #0x8                // =8
      a4:      	blr	x9
      a8:      	ldr	x0, [sp, #0xa8]
      ac:      	str	x0, [x20, #0x68]
      b0:      	mov	w8, #0xe                // =14
      b4:      	blr	x8
      b8:      	ldp	x8, x9, [x20, #0x60]
      bc:      	adrp	x22, 0x0 <generic_retkprobe_event>
      c0:      	add	x1, sp, #0xa8
      c4:      	str	w0, [x20, #0x7c]
      c8:      	stp	x8, x9, [sp, #0xa8]
      cc:      	mov	w8, #0x1                // =1
      d0:      	add	x9, sp, #0xa8
      d4:      	ldr	x22, [x22]
      d8:      	mov	x0, x22
      dc:      	blr	x8
      e0:      	cbz	x0, 0x5a4 <generic_retkprobe_event+0x5a4>
      e4:      	ldp	x21, x8, [x0]
      e8:      	add	x9, sp, #0xa8
      ec:      	add	x1, sp, #0xa8
      f0:      	str	x8, [sp, #0x118]
      f4:      	ldr	x8, [x0, #0x10]
      f8:      	mov	x0, x22
      fc:      	str	x8, [sp, #0x60]
     100:      	mov	w8, #0x3                // =3
     104:      	blr	x8
     108:      	mov	x22, x20
     10c:      	str	x21, [x22, #0x90]!
     110:      	ldp	w8, w23, [x29, #0x58]
     114:      	cbz	w23, 0x208 <generic_retkprobe_event+0x208>
     118:      	str	w8, [sp, #0x58]
     11c:      	str	wzr, [x25]
     120:      	mov	w8, #0x1                // =1
     124:      	add	x9, sp, #0x7c
     128:      	add	x1, sp, #0x7c
     12c:      	mov	x0, x24
     130:      	str	wzr, [sp, #0x7c]
     134:      	ldr	x25, [sp, #0x70]
     138:      	blr	x8
     13c:      	cbz	x0, 0x274 <generic_retkprobe_event+0x274>
     140:      	mov	w21, #0x5ea0            // =24224
     144:      	mov	w9, #0xc                // =12
     148:      	ldr	w8, [x0, x21]
     14c:      	str	x9, [x0, #0x5e78]
     150:      	str	w8, [x0, #0x98]
     154:      	cbz	w8, 0x2c4 <generic_retkprobe_event+0x2c4>
     158:      	mov	w8, #0x4                // =4
     15c:      	add	x21, x8, #0x8
     160:      	ldr	w8, [x29, #0x60]
     164:      	cmp	w8, #0xb
     168:      	b.eq	0x288 <generic_retkprobe_event+0x288>
     16c:      	cmp	w8, #0xa
     170:      	b.ne	0x1ac <generic_retkprobe_event+0x1ac>
     174:      	ldr	w8, [x20, #0x10]
     178:      	ldr	w9, [x20, #0x7c]
     17c:      	adrp	x0, 0x0 <generic_retkprobe_event>
     180:      	mov	x3, xzr
     184:      	add	x10, sp, #0xa8
     188:      	add	x1, sp, #0x70
     18c:      	stp	w8, w9, [sp, #0xa8]
     190:      	ldr	x8, [x20, #0x18]
     194:      	add	x9, sp, #0x70
     198:      	add	x2, sp, #0xa8
     19c:      	str	x8, [sp, #0xb0]
     1a0:      	mov	w8, #0x2                // =2
     1a4:      	ldr	x0, [x0]
     1a8:      	blr	x8
     1ac:      	ldr	w8, [sp, #0x58]
     1b0:      	and	x24, x21, #0x1fff
     1b4:      	cmp	w8, #0x3
     1b8:      	b.eq	0x214 <generic_retkprobe_event+0x214>
     1bc:      	cmp	w8, #0x2
     1c0:      	b.ne	0x33c <generic_retkprobe_event+0x33c>
     1c4:      	str	wzr, [x22, x24]
     1c8:      	add	x21, x24, #0x4
     1cc:      	mov	w8, #0xfff              // =4095
     1d0:      	ldr	x2, [sp, #0x118]
     1d4:      	mov	w25, #0x4               // =4
     1d8:      	add	x23, x22, x21
     1dc:      	ldr	x24, [sp, #0x70]
     1e0:      	add	x0, x23, #0x8
     1e4:      	cmp	x24, #0xfff
     1e8:      	csel	x22, x24, x8, lo
     1ec:      	mov	w8, #0x4                // =4
     1f0:      	mov	w1, w22
     1f4:      	blr	x8
     1f8:      	tbnz	w0, #0x1f, 0x2b4 <generic_retkprobe_event+0x2b4>
     1fc:      	add	x25, x22, #0x8
     200:      	str	w22, [x23, #0x4]
     204:      	b	0x2b8 <generic_retkprobe_event+0x2b8>
     208:      	mov	w24, #0x8               // =8
     20c:      	cmp	w8, #0x3
     210:      	b.ne	0x1bc <generic_retkprobe_event+0x1bc>
     214:      	ldr	x8, [sp, #0x60]
     218:      	add	x25, x24, #0x4
     21c:      	str	wzr, [x22, x24]
     220:      	cbz	x8, 0x30c <generic_retkprobe_event+0x30c>
     224:      	ldr	x2, [sp, #0x118]
     228:      	ldr	x21, [sp, #0x70]
     22c:      	mov	w8, #0x10               // =16
     230:      	mov	w9, #0x4                // =4
     234:      	add	x10, sp, #0xa8
     238:      	add	x0, sp, #0xa8
     23c:      	mov	w1, #0x10               // =16
     240:      	blr	x9
     244:      	tbnz	w0, #0x1f, 0x32c <generic_retkprobe_event+0x32c>
     248:      	ldr	x8, [sp, #0xb0]
     24c:      	str	x29, [sp, #0x48]
     250:      	cmp	x8, x21
     254:      	csel	x23, x8, x21, lo
     258:      	cmp	x21, #0x0
     25c:      	csel	x29, x8, x23, eq
     260:      	cmp	x29, #0xffe
     264:      	b.ls	0x5d8 <generic_retkprobe_event+0x5d8>
     268:      	ldr	x29, [sp, #0x48]
     26c:      	mov	w8, #-0x3               // =-3
     270:      	b	0x330 <generic_retkprobe_event+0x330>
     274:      	mov	x8, xzr
     278:      	add	x21, x8, #0x8
     27c:      	ldr	w8, [x29, #0x60]
     280:      	cmp	w8, #0xb
     284:      	b.ne	0x16c <generic_retkprobe_event+0x16c>
     288:      	adrp	x0, 0x0 <generic_retkprobe_event>
     28c:      	mov	w8, #0x3                // =3
     290:      	add	x9, sp, #0x70
     294:      	ldr	x0, [x0]
     298:      	add	x1, sp, #0x70
     29c:      	blr	x8
     2a0:      	ldr	w8, [sp, #0x58]
     2a4:      	and	x24, x21, #0x1fff
     2a8:      	cmp	w8, #0x3
     2ac:      	b.ne	0x1bc <generic_retkprobe_event+0x1bc>
     2b0:      	b	0x214 <generic_retkprobe_event+0x214>
     2b4:      	mov	w24, #-0x2              // =-2
     2b8:      	str	w24, [x23]
     2bc:      	add	x24, x25, x21
     2c0:      	b	0x33c <generic_retkprobe_event+0x33c>
     2c4:      	stp	x29, x19, [sp, #0x48]
     2c8:      	add	x9, sp, #0xf0
     2cc:      	add	x8, x0, #0x9c
     2d0:      	add	x19, sp, #0xf0
     2d4:      	cmp	w23, #0x17
     2d8:      	stp	x8, x0, [sp, #0x28]
     2dc:      	str	x25, [sp, #0xa8]
     2e0:      	str	xzr, [x9, #0x8]
     2e4:      	b.le	0x5c0 <generic_retkprobe_event+0x5c0>
     2e8:      	cmp	w23, #0x18
     2ec:      	b.eq	0x670 <generic_retkprobe_event+0x670>
     2f0:      	cmp	w23, #0x25
     2f4:      	b.eq	0x6b8 <generic_retkprobe_event+0x6b8>
     2f8:      	cmp	w23, #0x2a
     2fc:      	b.ne	0xc3c <generic_retkprobe_event+0xc3c>
     300:      	add	x8, sp, #0x80
     304:      	stp	xzr, x25, [sp, #0x80]
     308:      	b	0x6e4 <generic_retkprobe_event+0x6e4>
     30c:      	mov	x24, x22
     310:      	str	x29, [sp, #0x48]
     314:      	mov	x29, xzr
     318:      	add	x8, x24, x25
     31c:      	stp	w29, w29, [x8]
     320:      	add	x8, x29, #0x8
     324:      	ldr	x29, [sp, #0x48]
     328:      	b	0x338 <generic_retkprobe_event+0x338>
     32c:      	mov	w8, #-0x2               // =-2
     330:      	str	w8, [x22, x25]
     334:      	mov	w8, #0x4                // =4
     338:      	add	x24, x8, x25
     33c:      	mov	w8, #0x23               // =35
     340:      	blr	x8
     344:      	str	x0, [sp, #0xa8]
     348:      	add	x8, x0, #0x8d4
     34c:      	mov	w9, #0x4                // =4
     350:      	mov	w10, #0x71              // =113
     354:      	add	x11, sp, #0x80
     358:      	add	x0, sp, #0x80
     35c:      	mov	w1, #0x4                // =4
     360:      	ldr	x8, [sp, #0xa8]
     364:      	add	x2, x8, #0x8d4
     368:      	blr	x10
     36c:      	ldr	w8, [sp, #0x80]
     370:      	adrp	x22, 0x0 <generic_retkprobe_event>
     374:      	add	x9, sp, #0xf8
     378:      	add	x1, sp, #0xf8
     37c:      	str	w8, [sp, #0xf8]
     380:      	mov	w8, #0x1                // =1
     384:      	ldr	x22, [x22]
     388:      	mov	x0, x22
     38c:      	blr	x8
     390:      	cbz	x0, 0x3a0 <generic_retkprobe_event+0x3a0>
     394:      	ldr	x8, [x0, #0x8]
     398:      	mov	x23, x0
     39c:      	cbnz	x8, 0x54c <generic_retkprobe_event+0x54c>
     3a0:      	ldr	x8, [sp, #0xa8]
     3a4:      	mov	w9, #0x8                // =8
     3a8:      	mov	w10, #0x71              // =113
     3ac:      	add	x11, sp, #0xa8
     3b0:      	add	x0, sp, #0xa8
     3b4:      	mov	w1, #0x8                // =8
     3b8:      	add	x8, x8, #0x8e0
     3bc:      	ldr	x8, [sp, #0xa8]
     3c0:      	add	x2, x8, #0x8e0
     3c4:      	blr	x10
     3c8:      	ldr	x8, [sp, #0xa8]
     3cc:      	cbz	x8, 0x548 <generic_retkprobe_event+0x548>
     3d0:      	add	x8, x8, #0x8d4
     3d4:      	mov	w9, #0x4                // =4
     3d8:      	mov	w10, #0x71              // =113
     3dc:      	add	x11, sp, #0x80
     3e0:      	ldr	x8, [sp, #0xa8]
     3e4:      	add	x0, sp, #0x80
     3e8:      	mov	w1, #0x4                // =4
     3ec:      	add	x2, x8, #0x8d4
     3f0:      	blr	x10
     3f4:      	ldr	w8, [sp, #0x80]
     3f8:      	add	x9, sp, #0xf8
     3fc:      	add	x1, sp, #0xf8
     400:      	mov	x0, x22
     404:      	str	w8, [sp, #0xf8]
     408:      	mov	w8, #0x1                // =1
     40c:      	blr	x8
     410:      	cbz	x0, 0x420 <generic_retkprobe_event+0x420>
     414:      	ldr	x8, [x0, #0x8]
     418:      	mov	x23, x0
     41c:      	cbnz	x8, 0x54c <generic_retkprobe_event+0x54c>
     420:      	ldr	x8, [sp, #0xa8]
     424:      	mov	w9, #0x8                // =8
     428:      	mov	w10, #0x71              // =113
     42c:      	add	x11, sp, #0xa8
     430:      	add	x0, sp, #0xa8
     434:      	mov	w1, #0x8                // =8
     438:      	add	x8, x8, #0x8e0
     43c:      	ldr	x8, [sp, #0xa8]
     440:      	add	x2, x8, #0x8e0
     444:      	blr	x10
     448:      	ldr	x8, [sp, #0xa8]
     44c:      	cbz	x8, 0x548 <generic_retkprobe_event+0x548>
     450:      	add	x8, x8, #0x8d4
     454:      	mov	w9, #0x4                // =4
     458:      	mov	w10, #0x71              // =113
     45c:      	add	x11, sp, #0x80
     460:      	ldr	x8, [sp, #0xa8]
     464:      	add	x0, sp, #0x80
     468:      	mov	w1, #0x4                // =4
     46c:      	add	x2, x8, #0x8d4
     470:      	blr	x10
     474:      	ldr	w8, [sp, #0x80]
     478:      	add	x9, sp, #0xf8
     47c:      	add	x1, sp, #0xf8
     480:      	mov	x0, x22
     484:      	str	w8, [sp, #0xf8]
     488:      	mov	w8, #0x1                // =1
     48c:      	blr	x8
     490:      	cbz	x0, 0x4a0 <generic_retkprobe_event+0x4a0>
     494:      	ldr	x8, [x0, #0x8]
     498:      	mov	x23, x0
     49c:      	cbnz	x8, 0x54c <generic_retkprobe_event+0x54c>
     4a0:      	ldr	x8, [sp, #0xa8]
     4a4:      	mov	w9, #0x8                // =8
     4a8:      	mov	w10, #0x71              // =113
     4ac:      	add	x11, sp, #0xa8
     4b0:      	add	x0, sp, #0xa8
     4b4:      	mov	w1, #0x8                // =8
     4b8:      	add	x8, x8, #0x8e0
     4bc:      	ldr	x8, [sp, #0xa8]
     4c0:      	add	x2, x8, #0x8e0
     4c4:      	blr	x10
     4c8:      	ldr	x8, [sp, #0xa8]
     4cc:      	cbz	x8, 0x548 <generic_retkprobe_event+0x548>
     4d0:      	add	x8, x8, #0x8d4
     4d4:      	mov	w9, #0x4                // =4
     4d8:      	mov	w10, #0x71              // =113
     4dc:      	add	x11, sp, #0x80
     4e0:      	ldr	x8, [sp, #0xa8]
     4e4:      	add	x0, sp, #0x80
     4e8:      	mov	w1, #0x4                // =4
     4ec:      	add	x2, x8, #0x8d4
     4f0:      	blr	x10
     4f4:      	ldr	w8, [sp, #0x80]
     4f8:      	add	x9, sp, #0xf8
     4fc:      	add	x1, sp, #0xf8
     500:      	mov	x0, x22
     504:      	str	w8, [sp, #0xf8]
     508:      	mov	w8, #0x1                // =1
     50c:      	blr	x8
     510:      	cbz	x0, 0x520 <generic_retkprobe_event+0x520>
     514:      	ldr	x8, [x0, #0x8]
     518:      	mov	x23, x0
     51c:      	cbnz	x8, 0x54c <generic_retkprobe_event+0x54c>
     520:      	ldr	x8, [sp, #0xa8]
     524:      	mov	w9, #0x8                // =8
     528:      	mov	w10, #0x71              // =113
     52c:      	add	x11, sp, #0xa8
     530:      	add	x0, sp, #0xa8
     534:      	mov	w1, #0x8                // =8
     538:      	add	x8, x8, #0x8e0
     53c:      	ldr	x8, [sp, #0xa8]
     540:      	add	x2, x8, #0x8e0
     544:      	blr	x10
     548:      	mov	x23, xzr
     54c:      	mov	w8, #0x10d              // =269
     550:      	stp	w8, w24, [x20]
     554:      	mov	w8, #0x7d               // =125
     558:      	blr	x8
     55c:      	str	x0, [x20, #0x8]
     560:      	cbz	x23, 0x574 <generic_retkprobe_event+0x574>
     564:      	ldr	w8, [x23]
     568:      	str	w8, [x20, #0x10]
     56c:      	ldr	x8, [x23, #0x8]
     570:      	str	x8, [x20, #0x18]
     574:      	str	wzr, [x20, #0x14]
     578:      	adrp	x1, 0x0 <generic_retkprobe_event>
     57c:      	mov	w9, #0xc                // =12
     580:      	mov	x0, x19
     584:      	ldr	w8, [x29]
     588:      	str	w24, [x20, #0x4]
     58c:      	mov	w2, #0x3                // =3
     590:      	str	x8, [x20, #0x60]
     594:      	mov	w8, #0x3                // =3
     598:      	ldr	x1, [x1]
     59c:      	blr	x9
     5a0:      	mov	w0, #0x1                // =1
     5a4:      	ldp	x20, x19, [sp, #0x150]
     5a8:      	ldr	x29, [sp, #0x110]
     5ac:      	ldp	x22, x21, [sp, #0x140]
     5b0:      	ldp	x24, x23, [sp, #0x130]
     5b4:      	ldp	x30, x25, [sp, #0x120]
     5b8:      	add	sp, sp, #0x160
     5bc:      	ret
     5c0:      	cmp	w23, #0xf
     5c4:      	b.eq	0xbac <generic_retkprobe_event+0xbac>
     5c8:      	cmp	w23, #0x10
     5cc:      	b.ne	0xc3c <generic_retkprobe_event+0xc3c>
     5d0:      	add	x21, sp, #0x108
     5d4:      	b	0x698 <generic_retkprobe_event+0x698>
     5d8:      	mov	x8, x22
     5dc:      	add	x22, x24, #0xc
     5e0:      	mov	w9, #0x4                // =4
     5e4:      	mov	w1, w29
     5e8:      	mov	x24, x8
     5ec:      	add	x0, x8, x22
     5f0:      	ldr	x8, [sp, #0xa8]
     5f4:      	ldr	x2, [sp, #0xa8]
     5f8:      	blr	x9
     5fc:      	tbnz	w0, #0x1f, 0x660 <generic_retkprobe_event+0x660>
     600:      	cbz	x21, 0x60c <generic_retkprobe_event+0x60c>
     604:      	subs	x21, x21, x23
     608:      	b.eq	0xf24 <generic_retkprobe_event+0xf24>
     60c:      	ldr	x8, [sp, #0x60]
     610:      	cmp	x8, #0x1
     614:      	b.eq	0x318 <generic_retkprobe_event+0x318>
     618:      	ldr	x8, [sp, #0x118]
     61c:      	mov	w9, #0x4                // =4
     620:      	add	x10, sp, #0xa8
     624:      	add	x0, sp, #0xa8
     628:      	mov	w1, #0x10               // =16
     62c:      	add	x2, x8, #0x10
     630:      	mov	w8, #0x10               // =16
     634:      	blr	x9
     638:      	tbnz	w0, #0x1f, 0x1094 <generic_retkprobe_event+0x1094>
     63c:      	ldr	x8, [sp, #0xb0]
     640:      	cmp	x8, x21
     644:      	csel	x23, x8, x21, lo
     648:      	cmp	x21, #0x0
     64c:      	csel	x10, x8, x23, eq
     650:      	cmp	x10, #0xffe
     654:      	b.ls	0x1000 <generic_retkprobe_event+0x1000>
     658:      	mov	w8, #-0x3               // =-3
     65c:      	b	0x1098 <generic_retkprobe_event+0x1098>
     660:      	ldr	x29, [sp, #0x48]
     664:      	mov	w8, #-0x2               // =-2
     668:      	mov	x22, x24
     66c:      	b	0x330 <generic_retkprobe_event+0x330>
     670:      	add	x21, sp, #0x108
     674:      	mov	w8, #0x8                // =8
     678:      	mov	w9, #0x4                // =4
     67c:      	ldr	x2, [sp, #0xa8]
     680:      	add	x0, sp, #0x108
     684:      	mov	w1, #0x8                // =8
     688:      	blr	x9
     68c:      	add	x19, sp, #0xf0
     690:      	ldr	x8, [x19, #0x18]
     694:      	str	x8, [sp, #0xa8]
     698:      	mov	w8, #0x8                // =8
     69c:      	mov	w9, #0x4                // =4
     6a0:      	add	x10, sp, #0xa8
     6a4:      	add	x0, sp, #0x108
     6a8:      	add	x2, sp, #0xa8
     6ac:      	mov	w1, #0x8                // =8
     6b0:      	blr	x9
     6b4:      	b	0x6dc <generic_retkprobe_event+0x6dc>
     6b8:      	add	x8, x25, #0x40
     6bc:      	mov	w9, #0x8                // =8
     6c0:      	mov	w10, #0x4               // =4
     6c4:      	str	x8, [sp, #0xa8]
     6c8:      	add	x11, sp, #0x108
     6cc:      	add	x0, sp, #0x108
     6d0:      	mov	w1, #0x8                // =8
     6d4:      	ldr	x2, [sp, #0xa8]
     6d8:      	blr	x10
     6dc:      	ldr	x8, [x19, #0x18]
     6e0:      	add	x8, x8, #0x40
     6e4:      	str	x8, [sp, #0x38]
     6e8:      	str	wzr, [sp, #0x94]
     6ec:      	adrp	x0, 0x0 <generic_retkprobe_event>
     6f0:      	mov	w8, #0x1                // =1
     6f4:      	add	x9, sp, #0x94
     6f8:      	ldr	x0, [x0]
     6fc:      	add	x1, sp, #0x94
     700:      	blr	x8
     704:      	ldr	x19, [sp, #0x50]
     708:      	cbz	x0, 0xdf4 <generic_retkprobe_event+0xdf4>
     70c:      	add	x8, x0, #0x1, lsl #12   // =0x1000
     710:      	str	x22, [sp, #0x18]
     714:      	mov	x23, x0
     718:      	str	x8, [sp, #0x40]
     71c:      	mov	w8, #0x23               // =35
     720:      	blr	x8
     724:      	add	x2, x0, #0xb30
     728:      	mov	w24, #0x8               // =8
     72c:      	add	x8, sp, #0x98
     730:      	mov	w9, #0x4                // =4
     734:      	add	x0, sp, #0x98
     738:      	mov	w1, #0x8                // =8
     73c:      	mov	w25, #0x4               // =4
     740:      	blr	x9
     744:      	ldr	x29, [sp, #0x98]
     748:      	mov	w9, #0x4                // =4
     74c:      	add	x0, sp, #0xa0
     750:      	mov	w1, #0x8                // =8
     754:      	add	x8, x29, #0x18
     758:      	str	x8, [sp, #0x10]
     75c:      	ldr	x8, [sp, #0x38]
     760:      	add	x2, x8, #0x8
     764:      	add	x8, sp, #0xa0
     768:      	str	x2, [sp, #0x20]
     76c:      	blr	x9
     770:      	ldr	x21, [sp, #0xa0]
     774:      	add	x22, sp, #0xa8
     778:      	add	x0, sp, #0xa8
     77c:      	mov	w1, #0x8                // =8
     780:      	add	x2, x21, #0x10
     784:      	blr	x25
     788:      	ldr	x8, [sp, #0xa8]
     78c:      	cbz	x8, 0x79c <generic_retkprobe_event+0x79c>
     790:      	ldr	x9, [sp, #0x40]
     794:      	mov	w8, #0x1000             // =4096
     798:      	b	0x7e4 <generic_retkprobe_event+0x7e4>
     79c:      	add	x2, x21, #0x18
     7a0:      	mov	w8, #0x8                // =8
     7a4:      	mov	w9, #0x4                // =4
     7a8:      	add	x10, sp, #0xa8
     7ac:      	add	x0, sp, #0xa8
     7b0:      	mov	w1, #0x8                // =8
     7b4:      	blr	x9
     7b8:      	ldr	x8, [sp, #0xa8]
     7bc:      	cmp	x8, x21
     7c0:      	b.eq	0x790 <generic_retkprobe_event+0x790>
     7c4:      	mov	w8, #0x2964             // =10596
     7c8:      	add	x9, x23, #0xff6
     7cc:      	strh	w8, [x23, #0xffe]
     7d0:      	adrp	x8, 0x0 <generic_retkprobe_event>
     7d4:      	add	x8, x8, #0x0
     7d8:      	ldr	x8, [x8]
     7dc:      	str	x8, [x9]
     7e0:      	mov	w8, #0xff6              // =4086
     7e4:      	stp	xzr, xzr, [sp, #0xa8]
     7e8:      	add	x2, x29, #0x20
     7ec:      	mov	w21, #0x8               // =8
     7f0:      	add	x0, sp, #0xa8
     7f4:      	mov	w1, #0x8                // =8
     7f8:      	add	x25, x22, #0x8
     7fc:      	stp	x23, xzr, [sp, #0xb8]
     800:      	add	x24, x22, #0x18
     804:      	add	x23, x22, #0x20
     808:      	stp	xzr, xzr, [sp, #0xc8]
     80c:      	mov	w29, #0x4               // =4
     810:      	str	x9, [sp, #0x40]
     814:      	str	x9, [sp, #0xd8]
     818:      	str	w8, [sp, #0xe0]
     81c:      	mov	w8, #0x4                // =4
     820:      	strb	wzr, [sp, #0xe4]
     824:      	blr	x8
     828:      	ldr	x2, [sp, #0x10]
     82c:      	mov	w8, #0x4                // =4
     830:      	mov	x0, x25
     834:      	mov	w1, #0x8                // =8
     838:      	blr	x8
     83c:      	ldr	x2, [sp, #0x20]
     840:      	mov	w8, #0x4                // =4
     844:      	mov	x0, x24
     848:      	mov	w1, #0x8                // =8
     84c:      	blr	x8
     850:      	ldr	x2, [sp, #0x38]
     854:      	mov	x0, x23
     858:      	mov	w1, #0x8                // =8
     85c:      	blr	x29
     860:      	ldr	x8, [sp, #0xc8]
     864:      	sub	x8, x8, #0x20
     868:      	str	x8, [sp, #0xd0]
     86c:      	adrp	x8, 0x0 <generic_retkprobe_event>
     870:      	ldr	x8, [x8]
     874:      	ldrb	w8, [x8]
     878:      	cbz	w8, 0xa14 <generic_retkprobe_event+0xa14>
     87c:      	mov	w23, #0x80              // =128
     880:      	mov	w25, #0x8               // =8
     884:      	ldp	x29, x2, [sp, #0xc0]
     888:      	ldp	x8, x9, [sp, #0xa8]
     88c:      	cmp	x29, x8
     890:      	ccmp	x2, x9, #0x0, eq
     894:      	b.eq	0xcd8 <generic_retkprobe_event+0xcd8>
     898:      	ldr	x21, [sp, #0xd0]
     89c:      	mov	w8, #0x4                // =4
     8a0:      	add	x9, sp, #0xe8
     8a4:      	add	x0, sp, #0xe8
     8a8:      	mov	w1, #0x8                // =8
     8ac:      	blr	x8
     8b0:      	ldr	x8, [sp, #0xe8]
     8b4:      	add	x19, sp, #0xf0
     8b8:      	cmp	x29, x8
     8bc:      	b.eq	0x9b8 <generic_retkprobe_event+0x9b8>
     8c0:      	add	x22, x29, #0x18
     8c4:      	mov	w8, #0x4                // =4
     8c8:      	add	x9, sp, #0x108
     8cc:      	add	x0, sp, #0x108
     8d0:      	mov	w1, #0x8                // =8
     8d4:      	mov	x2, x22
     8d8:      	blr	x8
     8dc:      	ldr	x8, [x19, #0x18]
     8e0:      	cmp	x8, x29
     8e4:      	b.eq	0x9b8 <generic_retkprobe_event+0x9b8>
     8e8:      	mov	w8, #0x4                // =4
     8ec:      	add	x9, sp, #0xf0
     8f0:      	add	x0, sp, #0xf0
     8f4:      	mov	w1, #0x8                // =8
     8f8:      	mov	x2, x22
     8fc:      	blr	x8
     900:      	add	x2, x29, #0x20
     904:      	mov	w8, #0x4                // =4
     908:      	mov	w9, #0x10               // =16
     90c:      	add	x10, sp, #0xf8
     910:      	add	x0, sp, #0xf8
     914:      	mov	w1, #0x10               // =16
     918:      	blr	x8
     91c:      	ldr	w21, [sp, #0xfc]
     920:      	ldr	x8, [sp, #0xb8]
     924:      	add	x29, sp, #0xf0
     928:      	ldr	x10, [sp, #0xd8]
     92c:      	sub	x12, x10, x8
     930:      	ldr	w22, [sp, #0xe0]
     934:      	subs	w10, w21, w22
     938:      	ldr	x9, [x19, #0x10]
     93c:      	ldr	x19, [sp, #0x50]
     940:      	csel	w10, wzr, w10, lo
     944:      	cmp	w22, w21
     948:      	csel	w11, w22, w21, lo
     94c:      	cinc	w13, w11, hi
     950:      	sub	w14, w22, w13
     954:      	subs	x12, x12, x13
     958:      	str	w14, [sp, #0xe0]
     95c:      	b.lo	0xcf0 <generic_retkprobe_event+0xcf0>
     960:      	cmp	x12, #0xfff
     964:      	b.hi	0xcf0 <generic_retkprobe_event+0xcf0>
     968:      	cmp	w22, w21
     96c:      	b.ls	0x978 <generic_retkprobe_event+0x978>
     970:      	mov	w13, #0x2f              // =47
     974:      	strb	w13, [x8, x12]
     978:      	add	x29, x8, x12
     97c:      	cmp	w22, w21
     980:      	add	x2, x9, x10
     984:      	and	w1, w11, #0xff
     988:      	mov	w8, #0x4                // =4
     98c:      	cinc	x0, x29, hi
     990:      	blr	x8
     994:      	cmp	w22, w21
     998:      	str	x29, [sp, #0xd8]
     99c:      	add	x29, sp, #0xf0
     9a0:      	b.ls	0xcf0 <generic_retkprobe_event+0xcf0>
     9a4:      	ldr	x8, [x29]
     9a8:      	str	x8, [sp, #0xc0]
     9ac:      	subs	w23, w23, #0x1
     9b0:      	b.ne	0x884 <generic_retkprobe_event+0x884>
     9b4:      	b	0xcf0 <generic_retkprobe_event+0xcf0>
     9b8:      	add	x2, x21, #0x10
     9bc:      	mov	w8, #0x4                // =4
     9c0:      	add	x9, sp, #0x108
     9c4:      	add	x0, sp, #0x108
     9c8:      	mov	w1, #0x8                // =8
     9cc:      	blr	x8
     9d0:      	ldr	x8, [sp, #0xd0]
     9d4:      	ldr	x9, [x19, #0x18]
     9d8:      	add	x29, sp, #0xf0
     9dc:      	cmp	x8, x9
     9e0:      	b.eq	0xce4 <generic_retkprobe_event+0xce4>
     9e4:      	add	x2, x21, #0x18
     9e8:      	mov	w8, #0x4                // =4
     9ec:      	mov	x0, x24
     9f0:      	mov	w1, #0x8                // =8
     9f4:      	blr	x8
     9f8:      	ldr	x8, [x29, #0x18]
     9fc:      	ldr	x19, [sp, #0x50]
     a00:      	add	x9, x8, #0x20
     a04:      	stp	x9, x8, [sp, #0xc8]
     a08:      	subs	w23, w23, #0x1
     a0c:      	b.ne	0x884 <generic_retkprobe_event+0x884>
     a10:      	b	0xcf0 <generic_retkprobe_event+0xcf0>
     a14:      	mov	w23, #0x80              // =128
     a18:      	mov	w25, #0x8               // =8
     a1c:      	ldp	x29, x2, [sp, #0xc0]
     a20:      	ldp	x8, x9, [sp, #0xa8]
     a24:      	cmp	x29, x8
     a28:      	ccmp	x2, x9, #0x0, eq
     a2c:      	b.eq	0xcd8 <generic_retkprobe_event+0xcd8>
     a30:      	ldr	x21, [sp, #0xd0]
     a34:      	mov	w8, #0x4                // =4
     a38:      	add	x9, sp, #0xe8
     a3c:      	add	x0, sp, #0xe8
     a40:      	mov	w1, #0x8                // =8
     a44:      	blr	x8
     a48:      	ldr	x8, [sp, #0xe8]
     a4c:      	add	x19, sp, #0xf0
     a50:      	cmp	x29, x8
     a54:      	b.eq	0xb50 <generic_retkprobe_event+0xb50>
     a58:      	add	x22, x29, #0x18
     a5c:      	mov	w8, #0x4                // =4
     a60:      	add	x9, sp, #0x108
     a64:      	add	x0, sp, #0x108
     a68:      	mov	w1, #0x8                // =8
     a6c:      	mov	x2, x22
     a70:      	blr	x8
     a74:      	ldr	x8, [x19, #0x18]
     a78:      	cmp	x8, x29
     a7c:      	b.eq	0xb50 <generic_retkprobe_event+0xb50>
     a80:      	mov	w8, #0x4                // =4
     a84:      	add	x9, sp, #0xf0
     a88:      	add	x0, sp, #0xf0
     a8c:      	mov	w1, #0x8                // =8
     a90:      	mov	x2, x22
     a94:      	blr	x8
     a98:      	add	x2, x29, #0x20
     a9c:      	mov	w8, #0x4                // =4
     aa0:      	mov	w9, #0x10               // =16
     aa4:      	add	x10, sp, #0xf8
     aa8:      	add	x0, sp, #0xf8
     aac:      	mov	w1, #0x10               // =16
     ab0:      	blr	x8
     ab4:      	ldr	w21, [sp, #0xfc]
     ab8:      	ldr	x8, [sp, #0xb8]
     abc:      	add	x29, sp, #0xf0
     ac0:      	ldr	x10, [sp, #0xd8]
     ac4:      	sub	x12, x10, x8
     ac8:      	ldr	w22, [sp, #0xe0]
     acc:      	subs	w10, w21, w22
     ad0:      	ldr	x9, [x19, #0x10]
     ad4:      	ldr	x19, [sp, #0x50]
     ad8:      	csel	w10, wzr, w10, lo
     adc:      	cmp	w22, w21
     ae0:      	csel	w11, w22, w21, lo
     ae4:      	cinc	w13, w11, hi
     ae8:      	sub	w14, w22, w13
     aec:      	subs	x12, x12, x13
     af0:      	str	w14, [sp, #0xe0]
     af4:      	b.lo	0xcf0 <generic_retkprobe_event+0xcf0>
     af8:      	cmp	x12, #0xfff
     afc:      	b.hi	0xcf0 <generic_retkprobe_event+0xcf0>
     b00:      	cmp	w22, w21
     b04:      	b.ls	0xb10 <generic_retkprobe_event+0xb10>
     b08:      	mov	w13, #0x2f              // =47
     b0c:      	strb	w13, [x8, x12]
     b10:      	add	x29, x8, x12
     b14:      	cmp	w22, w21
     b18:      	add	x2, x9, x10
     b1c:      	and	w1, w11, #0xff
     b20:      	mov	w8, #0x4                // =4
     b24:      	cinc	x0, x29, hi
     b28:      	blr	x8
     b2c:      	cmp	w22, w21
     b30:      	str	x29, [sp, #0xd8]
     b34:      	add	x29, sp, #0xf0
     b38:      	b.ls	0xcf0 <generic_retkprobe_event+0xcf0>
     b3c:      	ldr	x8, [x29]
     b40:      	str	x8, [sp, #0xc0]
     b44:      	subs	w23, w23, #0x1
     b48:      	b.ne	0xa1c <generic_retkprobe_event+0xa1c>
     b4c:      	b	0xcf0 <generic_retkprobe_event+0xcf0>
     b50:      	add	x2, x21, #0x10
     b54:      	mov	w8, #0x4                // =4
     b58:      	add	x9, sp, #0x108
     b5c:      	add	x0, sp, #0x108
     b60:      	mov	w1, #0x8                // =8
     b64:      	blr	x8
     b68:      	ldr	x8, [sp, #0xd0]
     b6c:      	ldr	x9, [x19, #0x18]
     b70:      	add	x29, sp, #0xf0
     b74:      	cmp	x8, x9
     b78:      	b.eq	0xce4 <generic_retkprobe_event+0xce4>
     b7c:      	add	x2, x21, #0x18
     b80:      	mov	w8, #0x4                // =4
     b84:      	mov	x0, x24
     b88:      	mov	w1, #0x8                // =8
     b8c:      	blr	x8
     b90:      	ldr	x8, [x29, #0x18]
     b94:      	ldr	x19, [sp, #0x50]
     b98:      	add	x9, x8, #0x20
     b9c:      	stp	x9, x8, [sp, #0xc8]
     ba0:      	subs	w23, w23, #0x1
     ba4:      	b.ne	0xa1c <generic_retkprobe_event+0xa1c>
     ba8:      	b	0xcf0 <generic_retkprobe_event+0xcf0>
     bac:      	mov	w8, #0x8                // =8
     bb0:      	mov	w9, #0x4                // =4
     bb4:      	add	x10, sp, #0xf8
     bb8:      	add	x11, sp, #0xa8
     bbc:      	add	x0, sp, #0xf8
     bc0:      	add	x2, sp, #0xa8
     bc4:      	mov	w1, #0x8                // =8
     bc8:      	blr	x9
     bcc:      	ldr	x8, [x19, #0x8]
     bd0:      	str	x8, [sp, #0x38]
     bd4:      	cbnz	x8, 0x6e8 <generic_retkprobe_event+0x6e8>
     bd8:      	str	wzr, [sp, #0x80]
     bdc:      	mov	w8, #0x1                // =1
     be0:      	add	x9, sp, #0x80
     be4:      	add	x1, sp, #0x80
     be8:      	mov	x0, x24
     bec:      	blr	x8
     bf0:      	ldr	x19, [sp, #0x50]
     bf4:      	mov	x29, xzr
     bf8:      	cbz	x0, 0xdd4 <generic_retkprobe_event+0xdd4>
     bfc:      	cmp	w23, #0x19
     c00:      	b.gt	0xfd8 <generic_retkprobe_event+0xfd8>
     c04:      	cmp	w23, #0x12
     c08:      	b.le	0x1160 <generic_retkprobe_event+0x1160>
     c0c:      	cmp	w23, #0x14
     c10:      	b.le	0x13a0 <generic_retkprobe_event+0x13a0>
     c14:      	cmp	w23, #0x15
     c18:      	b.eq	0x1a4c <generic_retkprobe_event+0x1a4c>
     c1c:      	cmp	w23, #0x16
     c20:      	b.eq	0x19ec <generic_retkprobe_event+0x19ec>
     c24:      	cmp	w23, #0x17
     c28:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
     c2c:      	ldr	x8, [sp, #0x30]
     c30:      	mov	w29, #0x8               // =8
     c34:      	stp	w25, wzr, [x8, #0x9c]
     c38:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
     c3c:      	cmp	w23, #0x2c
     c40:      	b.hi	0xbd8 <generic_retkprobe_event+0xbd8>
     c44:      	mov	x9, #0x7cf2             // =31986
     c48:      	mov	w8, #0x1                // =1
     c4c:      	movk	x9, #0xf202, lsl #16
     c50:      	lsl	x8, x8, x23
     c54:      	movk	x9, #0x11c1, lsl #32
     c58:      	tst	x8, x9
     c5c:      	b.eq	0xbd8 <generic_retkprobe_event+0xbd8>
     c60:      	add	x8, sp, #0xf0
     c64:      	str	wzr, [sp, #0xf0]
     c68:      	add	x9, sp, #0xf0
     c6c:      	add	x1, sp, #0xf0
     c70:      	str	x25, [x8, #0x18]
     c74:      	mov	w8, #0x1                // =1
     c78:      	mov	x0, x24
     c7c:      	blr	x8
     c80:      	ldr	x19, [sp, #0x50]
     c84:      	cbz	x0, 0x136c <generic_retkprobe_event+0x136c>
     c88:      	add	x25, sp, #0xf0
     c8c:      	mov	x29, xzr
     c90:      	cmp	w23, #0x10
     c94:      	b.le	0xe18 <generic_retkprobe_event+0xe18>
     c98:      	cmp	w23, #0x1e
     c9c:      	b.le	0xf2c <generic_retkprobe_event+0xf2c>
     ca0:      	cmp	w23, #0x26
     ca4:      	b.gt	0x10a4 <generic_retkprobe_event+0x10a4>
     ca8:      	ldr	x0, [sp, #0x28]
     cac:      	sub	w8, w23, #0x1f
     cb0:      	cmp	w8, #0x2
     cb4:      	b.hs	0x1444 <generic_retkprobe_event+0x1444>
     cb8:      	mov	w8, #0x1                // =1
     cbc:      	add	x9, sp, #0x108
     cc0:      	mov	w10, #0x4               // =4
     cc4:      	add	x2, sp, #0x108
     cc8:      	mov	w1, #0x1                // =1
     ccc:      	mov	w29, #0x4               // =4
     cd0:      	blr	x10
     cd4:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
     cd8:      	mov	w8, #0x1                // =1
     cdc:      	add	x29, sp, #0xf0
     ce0:      	b	0xcec <generic_retkprobe_event+0xcec>
     ce4:      	ldr	x19, [sp, #0x50]
     ce8:      	mov	w8, #0x1                // =1
     cec:      	strb	w8, [sp, #0xe4]
     cf0:      	ldr	x8, [sp, #0xd8]
     cf4:      	ldr	x2, [sp, #0x40]
     cf8:      	cmp	x8, x2
     cfc:      	b.eq	0xd30 <generic_retkprobe_event+0xd30>
     d00:      	ldrb	w9, [sp, #0xe4]
     d04:      	mov	w11, #0x1000            // =4096
     d08:      	cmp	w9, #0x0
     d0c:      	ldr	w9, [sp, #0xe0]
     d10:      	cset	w10, eq
     d14:      	sub	w11, w11, w9
     d18:      	cmp	w9, #0x0
     d1c:      	csel	w9, w11, w9, gt
     d20:      	cbz	x8, 0xdf0 <generic_retkprobe_event+0xdf0>
     d24:      	lsl	w23, w10, #1
     d28:      	mov	x2, x8
     d2c:      	b	0xd38 <generic_retkprobe_event+0xd38>
     d30:      	mov	w23, wzr
     d34:      	mov	w9, wzr
     d38:      	ldr	x21, [sp, #0x30]
     d3c:      	and	w22, w9, #0xfff
     d40:      	mov	w8, #0x4                // =4
     d44:      	mov	w24, #0x4               // =4
     d48:      	mov	w1, w22
     d4c:      	add	x0, x21, #0xa0
     d50:      	blr	x8
     d54:      	str	w22, [x21, #0x9c]
     d58:      	ldr	x2, [sp, #0x20]
     d5c:      	mov	w21, #0x8               // =8
     d60:      	add	x8, sp, #0xa8
     d64:      	mov	w9, #0x4                // =4
     d68:      	add	x0, sp, #0xa8
     d6c:      	mov	w1, #0x8                // =8
     d70:      	blr	x9
     d74:      	ldr	x8, [sp, #0xa8]
     d78:      	add	x9, sp, #0xf8
     d7c:      	mov	w10, #0x4               // =4
     d80:      	add	x0, sp, #0xf8
     d84:      	mov	w1, #0x8                // =8
     d88:      	add	x8, x8, #0x30
     d8c:      	ldr	x8, [sp, #0xa8]
     d90:      	add	x2, x8, #0x30
     d94:      	blr	x10
     d98:      	ldr	x8, [x29, #0x8]
     d9c:      	mov	w9, #0x2                // =2
     da0:      	add	x10, sp, #0x108
     da4:      	add	x0, sp, #0x108
     da8:      	ldr	x2, [x29, #0x8]
     dac:      	mov	w1, #0x2                // =2
     db0:      	blr	x24
     db4:      	ldr	x8, [sp, #0x28]
     db8:      	add	w29, w22, #0xa
     dbc:      	mov	w21, #0x5ea0            // =24224
     dc0:      	add	x8, x8, x22
     dc4:      	ldr	x22, [sp, #0x18]
     dc8:      	str	w23, [x8, #0x4]
     dcc:      	ldrh	w9, [sp, #0x108]
     dd0:      	strh	w9, [x8, #0x8]
     dd4:      	tbz	w29, #0x1f, 0xdf8 <generic_retkprobe_event+0xdf8>
     dd8:      	ldr	x9, [sp, #0x30]
     ddc:      	mov	w8, #-0x1               // =-1
     de0:      	str	w8, [x9, x21]
     de4:      	str	w8, [x9, #0x98]
     de8:      	mov	w8, #0x4                // =4
     dec:      	b	0xe00 <generic_retkprobe_event+0xe00>
     df0:      	ldr	x22, [sp, #0x18]
     df4:      	mov	x29, xzr
     df8:      	and	x8, x29, #0x7fffffff
     dfc:      	add	x8, x8, #0x4
     e00:      	ldr	x29, [sp, #0x48]
     e04:      	add	x21, x8, #0x8
     e08:      	ldr	w8, [x29, #0x60]
     e0c:      	cmp	w8, #0xb
     e10:      	b.ne	0x16c <generic_retkprobe_event+0x16c>
     e14:      	b	0x288 <generic_retkprobe_event+0x288>
     e18:      	cmp	w23, #0x9
     e1c:      	b.gt	0xf54 <generic_retkprobe_event+0xf54>
     e20:      	cmp	w23, #0x4
     e24:      	b.le	0x11a8 <generic_retkprobe_event+0x11a8>
     e28:      	cmp	w23, #0x5
     e2c:      	b.eq	0x15f0 <generic_retkprobe_event+0x15f0>
     e30:      	cmp	w23, #0x6
     e34:      	b.eq	0xfbc <generic_retkprobe_event+0xfbc>
     e38:      	cmp	w23, #0x7
     e3c:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
     e40:      	add	x29, sp, #0xf0
     e44:      	str	x22, [sp, #0x18]
     e48:      	ldr	x25, [sp, #0x30]
     e4c:      	mov	x24, x0
     e50:      	mov	w21, #0x2               // =2
     e54:      	mov	w8, #0x4                // =4
     e58:      	ldr	x22, [x29, #0x18]
     e5c:      	mov	w1, #0x2                // =2
     e60:      	mov	w23, #0x4               // =4
     e64:      	stur	x22, [x25, #0xc4]
     e68:      	add	x0, x25, #0xc2
     e6c:      	add	x2, x22, #0x10
     e70:      	blr	x8
     e74:      	add	x0, x25, #0xd6
     e78:      	add	x2, x22, #0x12
     e7c:      	mov	w8, #0x1                // =1
     e80:      	mov	w9, #0x4                // =4
     e84:      	mov	w1, #0x1                // =1
     e88:      	blr	x9
     e8c:      	add	x0, x25, #0xd4
     e90:      	add	x2, x22, #0x21e
     e94:      	mov	w8, #0x4                // =4
     e98:      	mov	w1, #0x2                // =2
     e9c:      	blr	x8
     ea0:      	add	x0, x25, #0xc0
     ea4:      	add	x2, x22, #0x21c
     ea8:      	mov	w8, #0x4                // =4
     eac:      	mov	w1, #0x2                // =2
     eb0:      	blr	x8
     eb4:      	add	x0, x25, #0xcc
     eb8:      	add	x2, x22, #0x214
     ebc:      	mov	w8, #0x4                // =4
     ec0:      	mov	w1, #0x4                // =4
     ec4:      	blr	x8
     ec8:      	add	x0, x25, #0xd0
     ecc:      	add	x2, x22, #0x210
     ed0:      	mov	w1, #0x4                // =4
     ed4:      	blr	x23
     ed8:      	ldrh	w8, [x25, #0xc2]
     edc:      	ldr	x0, [sp, #0x28]
     ee0:      	add	x23, x25, #0xac
     ee4:      	cmp	w8, #0xa
     ee8:      	stp	xzr, xzr, [x0]
     eec:      	stp	xzr, xzr, [x0, #0x10]
     ef0:      	b.eq	0x1d1c <generic_retkprobe_event+0x1d1c>
     ef4:      	cmp	w8, #0x2
     ef8:      	b.ne	0x1d44 <generic_retkprobe_event+0x1d44>
     efc:      	add	x2, x22, #0x4
     f00:      	mov	w8, #0x4                // =4
     f04:      	mov	w1, #0x4                // =4
     f08:      	mov	w21, #0x4               // =4
     f0c:      	blr	x8
     f10:      	mov	x0, x23
     f14:      	mov	w1, #0x4                // =4
     f18:      	mov	x2, x22
     f1c:      	blr	x21
     f20:      	b	0x1d44 <generic_retkprobe_event+0x1d44>
     f24:      	mov	x29, x23
     f28:      	b	0x318 <generic_retkprobe_event+0x318>
     f2c:      	cmp	w23, #0x1c
     f30:      	b.gt	0x1184 <generic_retkprobe_event+0x1184>
     f34:      	cmp	w23, #0x11
     f38:      	b.eq	0x1470 <generic_retkprobe_event+0x1470>
     f3c:      	cmp	w23, #0x19
     f40:      	b.eq	0x152c <generic_retkprobe_event+0x152c>
     f44:      	ldr	x0, [sp, #0x28]
     f48:      	cmp	w23, #0x1c
     f4c:      	b.eq	0x11bc <generic_retkprobe_event+0x11bc>
     f50:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
     f54:      	ldr	x0, [sp, #0x28]
     f58:      	sub	w8, w23, #0xa
     f5c:      	cmp	w8, #0x2
     f60:      	b.lo	0x11bc <generic_retkprobe_event+0x11bc>
     f64:      	sub	w8, w23, #0xc
     f68:      	cmp	w8, #0x2
     f6c:      	b.lo	0x11d4 <generic_retkprobe_event+0x11d4>
     f70:      	cmp	w23, #0xe
     f74:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
     f78:      	mov	w21, #0x8               // =8
     f7c:      	add	x8, sp, #0xa8
     f80:      	add	x23, sp, #0x108
     f84:      	mov	w9, #0x4                // =4
     f88:      	add	x0, sp, #0xa8
     f8c:      	add	x2, sp, #0x108
     f90:      	mov	w1, #0x8                // =8
     f94:      	mov	x24, x22
     f98:      	mov	w22, #0x4               // =4
     f9c:      	blr	x9
     fa0:      	ldr	x8, [sp, #0xa8]
     fa4:      	add	x0, sp, #0x108
     fa8:      	mov	w1, #0x8                // =8
     fac:      	mov	w21, #0x5ea0            // =24224
     fb0:      	ldr	x2, [sp, #0xa8]
     fb4:      	blr	x22
     fb8:      	mov	x22, x24
     fbc:      	ldr	x8, [sp, #0x30]
     fc0:      	ldr	x2, [x25, #0x18]
     fc4:      	mov	w9, #0x2d               // =45
     fc8:      	mov	w1, #0x1001             // =4097
     fcc:      	add	x0, x8, #0xa0
     fd0:      	mov	w8, #0x1001             // =4097
     fd4:      	b	0x1764 <generic_retkprobe_event+0x1764>
     fd8:      	cmp	w23, #0x20
     fdc:      	b.le	0x1304 <generic_retkprobe_event+0x1304>
     fe0:      	sub	w8, w23, #0x21
     fe4:      	cmp	w8, #0x4
     fe8:      	b.hs	0x11f0 <generic_retkprobe_event+0x11f0>
     fec:      	ldr	x0, [sp, #0x28]
     ff0:      	mov	w29, #0x8               // =8
     ff4:      	mov	w8, #0x4                // =4
     ff8:      	mov	w1, #0x8                // =8
     ffc:      	b	0x1394 <generic_retkprobe_event+0x1394>
    1000:      	add	x8, x29, x22
    1004:      	mov	w9, #0x4                // =4
    1008:      	mov	x22, x10
    100c:      	str	x8, [sp, #0x58]
    1010:      	add	x0, x24, x8
    1014:      	ldr	x8, [sp, #0xa8]
    1018:      	mov	w1, w22
    101c:      	ldr	x2, [sp, #0xa8]
    1020:      	blr	x9
    1024:      	tbnz	w0, #0x1f, 0x1094 <generic_retkprobe_event+0x1094>
    1028:      	add	x29, x22, x29
    102c:      	cbz	x21, 0x1038 <generic_retkprobe_event+0x1038>
    1030:      	subs	x21, x21, x23
    1034:      	b.eq	0x318 <generic_retkprobe_event+0x318>
    1038:      	ldr	x8, [sp, #0x60]
    103c:      	cmp	x8, #0x3
    1040:      	b.lo	0x318 <generic_retkprobe_event+0x318>
    1044:      	ldr	x8, [sp, #0x118]
    1048:      	str	x19, [sp, #0x50]
    104c:      	mov	w9, #0x4                // =4
    1050:      	add	x10, sp, #0xa8
    1054:      	add	x0, sp, #0xa8
    1058:      	mov	w1, #0x10               // =16
    105c:      	add	x2, x8, #0x20
    1060:      	mov	w8, #0x10               // =16
    1064:      	blr	x9
    1068:      	tbnz	w0, #0x1f, 0x20bc <generic_retkprobe_event+0x20bc>
    106c:      	ldr	x8, [sp, #0xb0]
    1070:      	cmp	x8, x21
    1074:      	csel	x23, x8, x21, lo
    1078:      	cmp	x21, #0x0
    107c:      	csel	x8, x8, x23, eq
    1080:      	cmp	x8, #0xffe
    1084:      	str	x8, [sp, #0x40]
    1088:      	b.ls	0x1e4c <generic_retkprobe_event+0x1e4c>
    108c:      	mov	w8, #-0x3               // =-3
    1090:      	b	0x20c0 <generic_retkprobe_event+0x20c0>
    1094:      	mov	w8, #-0x2               // =-2
    1098:      	str	w8, [x24, x25]
    109c:      	mov	w8, #0x4                // =4
    10a0:      	b	0x324 <generic_retkprobe_event+0x324>
    10a4:      	ldr	x0, [sp, #0x28]
    10a8:      	cmp	w23, #0x27
    10ac:      	b.eq	0x1748 <generic_retkprobe_event+0x1748>
    10b0:      	cmp	w23, #0x28
    10b4:      	b.eq	0x1784 <generic_retkprobe_event+0x1784>
    10b8:      	cmp	w23, #0x2c
    10bc:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
    10c0:      	mov	x24, x22
    10c4:      	ldr	x22, [x25, #0x18]
    10c8:      	strb	wzr, [sp, #0xa8]
    10cc:      	mov	w8, #0x2                // =2
    10d0:      	mov	w9, #0x4                // =4
    10d4:      	mov	w1, #0x2                // =2
    10d8:      	mov	x2, x22
    10dc:      	stp	xzr, xzr, [x0]
    10e0:      	stp	xzr, xzr, [x0, #0x10]
    10e4:      	stp	xzr, xzr, [x0, #0x20]
    10e8:      	stp	xzr, xzr, [x0, #0x30]
    10ec:      	stp	xzr, xzr, [x0, #0x40]
    10f0:      	stp	xzr, xzr, [x0, #0x50]
    10f4:      	stp	xzr, xzr, [x0, #0x60]
    10f8:      	blr	x9
    10fc:      	tbnz	x0, #0x3f, 0x20ec <generic_retkprobe_event+0x20ec>
    1100:      	add	x23, x22, #0x2
    1104:      	mov	w8, #0x1                // =1
    1108:      	mov	w9, #0x4                // =4
    110c:      	add	x10, sp, #0xa8
    1110:      	add	x0, sp, #0xa8
    1114:      	mov	w1, #0x1                // =1
    1118:      	mov	x2, x23
    111c:      	blr	x9
    1120:      	tbnz	x0, #0x3f, 0x20ec <generic_retkprobe_event+0x20ec>
    1124:      	ldrb	w8, [sp, #0xa8]
    1128:      	ldr	x10, [sp, #0x30]
    112c:      	cmp	w8, #0x0
    1130:      	add	x0, x10, #0xa0
    1134:      	cset	w9, eq
    1138:      	strb	w9, [x10, #0x9e]
    113c:      	cbz	w8, 0x20cc <generic_retkprobe_event+0x20cc>
    1140:      	mov	w8, #0x6c               // =108
    1144:      	mov	w9, #0x2d               // =45
    1148:      	mov	w1, #0x6c               // =108
    114c:      	mov	x2, x23
    1150:      	blr	x9
    1154:      	tbnz	w0, #0x1f, 0x20ec <generic_retkprobe_event+0x20ec>
    1158:      	sub	w21, w0, #0x1
    115c:      	b	0x20e4 <generic_retkprobe_event+0x20e4>
    1160:      	cmp	w23, #0x7
    1164:      	b.gt	0x1374 <generic_retkprobe_event+0x1374>
    1168:      	cmp	w23, #0x2
    116c:      	b.eq	0x17fc <generic_retkprobe_event+0x17fc>
    1170:      	cmp	w23, #0x3
    1174:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
    1178:      	stur	xzr, [x0, #0x9c]
    117c:      	mov	w29, #0x8               // =8
    1180:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    1184:      	ldr	x0, [sp, #0x28]
    1188:      	mov	w8, #0x2                // =2
    118c:      	add	x9, sp, #0x108
    1190:      	mov	w10, #0x4               // =4
    1194:      	add	x2, sp, #0x108
    1198:      	mov	w1, #0x2                // =2
    119c:      	mov	w29, #0x4               // =4
    11a0:      	blr	x10
    11a4:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    11a8:      	ldr	x0, [sp, #0x28]
    11ac:      	cmp	w23, #0x1
    11b0:      	b.eq	0x11d4 <generic_retkprobe_event+0x11d4>
    11b4:      	cmp	w23, #0x4
    11b8:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
    11bc:      	mov	w29, #0x8               // =8
    11c0:      	mov	w8, #0x4                // =4
    11c4:      	add	x9, sp, #0x108
    11c8:      	add	x2, sp, #0x108
    11cc:      	mov	w1, #0x8                // =8
    11d0:      	b	0x1398 <generic_retkprobe_event+0x1398>
    11d4:      	add	x8, sp, #0x108
    11d8:      	mov	w9, #0x4                // =4
    11dc:      	add	x2, sp, #0x108
    11e0:      	mov	w1, #0x4                // =4
    11e4:      	mov	w29, #0x4               // =4
    11e8:      	blr	x9
    11ec:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    11f0:      	cmp	w23, #0x2b
    11f4:      	b.eq	0x1b0c <generic_retkprobe_event+0x1b0c>
    11f8:      	cmp	w23, #0x29
    11fc:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
    1200:      	str	x22, [sp, #0x18]
    1204:      	add	x2, x25, #0x18
    1208:      	mov	w8, #0x8                // =8
    120c:      	mov	w9, #0x4                // =4
    1210:      	add	x10, sp, #0xa8
    1214:      	mov	x24, x0
    1218:      	add	x0, sp, #0xa8
    121c:      	mov	w1, #0x8                // =8
    1220:      	blr	x9
    1224:      	ldr	x22, [sp, #0xa8]
    1228:      	cbz	x22, 0x216c <generic_retkprobe_event+0x216c>
    122c:      	ldr	x25, [sp, #0x30]
    1230:      	add	x2, x22, #0x10
    1234:      	mov	w21, #0x2               // =2
    1238:      	mov	w8, #0x4                // =4
    123c:      	stur	x22, [x25, #0xc4]
    1240:      	add	x0, x25, #0xc2
    1244:      	mov	w1, #0x2                // =2
    1248:      	mov	w23, #0x4               // =4
    124c:      	blr	x8
    1250:      	add	x0, x25, #0xd6
    1254:      	add	x2, x22, #0x12
    1258:      	mov	w8, #0x1                // =1
    125c:      	mov	w9, #0x4                // =4
    1260:      	mov	w1, #0x1                // =1
    1264:      	blr	x9
    1268:      	add	x0, x25, #0xd4
    126c:      	add	x2, x22, #0x21e
    1270:      	mov	w8, #0x4                // =4
    1274:      	mov	w1, #0x2                // =2
    1278:      	blr	x8
    127c:      	add	x0, x25, #0xc0
    1280:      	add	x2, x22, #0x21c
    1284:      	mov	w8, #0x4                // =4
    1288:      	mov	w1, #0x2                // =2
    128c:      	blr	x8
    1290:      	add	x0, x25, #0xcc
    1294:      	add	x2, x22, #0x214
    1298:      	mov	w8, #0x4                // =4
    129c:      	mov	w1, #0x4                // =4
    12a0:      	blr	x8
    12a4:      	add	x0, x25, #0xd0
    12a8:      	add	x2, x22, #0x210
    12ac:      	mov	w1, #0x4                // =4
    12b0:      	blr	x23
    12b4:      	ldr	x8, [sp, #0x28]
    12b8:      	add	x23, x25, #0xac
    12bc:      	stp	xzr, xzr, [x8]
    12c0:      	stp	xzr, xzr, [x8, #0x10]
    12c4:      	ldrh	w8, [x25, #0xc2]
    12c8:      	cmp	w8, #0xa
    12cc:      	b.eq	0x20fc <generic_retkprobe_event+0x20fc>
    12d0:      	cmp	w8, #0x2
    12d4:      	b.ne	0x2128 <generic_retkprobe_event+0x2128>
    12d8:      	ldr	x0, [sp, #0x28]
    12dc:      	add	x2, x22, #0x4
    12e0:      	mov	w8, #0x4                // =4
    12e4:      	mov	w1, #0x4                // =4
    12e8:      	mov	w21, #0x4               // =4
    12ec:      	blr	x8
    12f0:      	mov	x0, x23
    12f4:      	mov	w1, #0x4                // =4
    12f8:      	mov	x2, x22
    12fc:      	blr	x21
    1300:      	b	0x2128 <generic_retkprobe_event+0x2128>
    1304:      	cmp	w23, #0x1a
    1308:      	b.eq	0x1b9c <generic_retkprobe_event+0x1b9c>
    130c:      	cmp	w23, #0x1b
    1310:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
    1314:      	ldp	x9, x8, [sp, #0x28]
    1318:      	add	x2, x25, #0x18
    131c:      	mov	w1, #0x3f               // =63
    1320:      	add	x0, x8, #0xac
    1324:      	stp	xzr, xzr, [x9, #0x40]
    1328:      	stp	xzr, xzr, [x9, #0x30]
    132c:      	stp	xzr, xzr, [x9, #0x20]
    1330:      	mov	w8, #0x3f               // =63
    1334:      	stp	xzr, xzr, [x9, #0x10]
    1338:      	stp	xzr, xzr, [x9]
    133c:      	mov	w9, #0x2d               // =45
    1340:      	blr	x9
    1344:      	tbnz	x0, #0x3f, 0x136c <generic_retkprobe_event+0x136c>
    1348:      	ldr	x8, [sp, #0x30]
    134c:      	add	x2, x25, #0x360
    1350:      	mov	w9, #0x4                // =4
    1354:      	mov	w1, #0x8                // =8
    1358:      	add	x0, x8, #0xa4
    135c:      	mov	w8, #0x8                // =8
    1360:      	blr	x9
    1364:      	mov	w29, #0x50              // =80
    1368:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    136c:      	mov	x29, xzr
    1370:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    1374:      	cmp	w23, #0x8
    1378:      	b.eq	0x186c <generic_retkprobe_event+0x186c>
    137c:      	cmp	w23, #0x12
    1380:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
    1384:      	mov	x29, xzr
    1388:      	mov	w8, #0x4                // =4
    138c:      	ldr	x0, [sp, #0x28]
    1390:      	mov	w1, wzr
    1394:      	mov	x2, x25
    1398:      	blr	x8
    139c:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    13a0:      	cmp	w23, #0x13
    13a4:      	b.eq	0x1acc <generic_retkprobe_event+0x1acc>
    13a8:      	cmp	w23, #0x14
    13ac:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
    13b0:      	str	xzr, [sp, #0xa8]
    13b4:      	add	x2, x25, #0x110
    13b8:      	mov	w24, #0x8               // =8
    13bc:      	add	x8, sp, #0xa8
    13c0:      	mov	w9, #0x4                // =4
    13c4:      	add	x0, sp, #0xa8
    13c8:      	mov	w1, #0x8                // =8
    13cc:      	mov	x21, x22
    13d0:      	add	x22, x25, #0xd8
    13d4:      	mov	w23, #0x4               // =4
    13d8:      	blr	x9
    13dc:      	ldr	x8, [sp, #0xa8]
    13e0:      	mov	w9, #0x80               // =128
    13e4:      	mov	w10, #0x2d              // =45
    13e8:      	ldr	x0, [sp, #0x28]
    13ec:      	mov	w1, #0x80               // =128
    13f0:      	ldr	x2, [sp, #0xa8]
    13f4:      	blr	x10
    13f8:      	ldr	x29, [sp, #0x30]
    13fc:      	mov	w8, #0x4                // =4
    1400:      	mov	w1, #0x4                // =4
    1404:      	mov	x2, x22
    1408:      	add	x0, x29, #0x12c
    140c:      	mov	x22, x21
    1410:      	mov	w21, #0x5ea0            // =24224
    1414:      	blr	x8
    1418:      	add	x0, x29, #0x11c
    141c:      	add	x2, x25, #0xe0
    1420:      	mov	w8, #0x4                // =4
    1424:      	mov	w1, #0x8                // =8
    1428:      	blr	x8
    142c:      	add	x0, x29, #0x124
    1430:      	add	x2, x25, #0x118
    1434:      	mov	w1, #0x8                // =8
    1438:      	blr	x23
    143c:      	mov	w29, #0x98              // =152
    1440:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    1444:      	cmp	w23, #0x26
    1448:      	b.ne	0xdd4 <generic_retkprobe_event+0xdd4>
    144c:      	ldr	x8, [x25, #0x18]
    1450:      	ldr	x9, [sp, #0x30]
    1454:      	add	x2, x19, w8, uxth
    1458:      	ubfx	w8, w8, #16, #12
    145c:      	add	x0, x9, #0xa0
    1460:      	add	w1, w8, #0x1
    1464:      	mov	w8, #0x2d               // =45
    1468:      	blr	x8
    146c:      	b	0x1768 <generic_retkprobe_event+0x1768>
    1470:      	stp	xzr, xzr, [sp, #0xa8]
    1474:      	mov	w8, #0xe                // =14
    1478:      	mov	x24, x22
    147c:      	blr	x8
    1480:      	lsr	x8, x0, #32
    1484:      	add	x9, sp, #0xf8
    1488:      	add	x10, sp, #0x108
    148c:      	str	x8, [sp, #0xa8]
    1490:      	mov	w8, #0x4                // =4
    1494:      	add	x0, sp, #0xf8
    1498:      	add	x2, sp, #0x108
    149c:      	mov	w1, #0x4                // =4
    14a0:      	blr	x8
    14a4:      	ldr	w8, [sp, #0xf8]
    14a8:      	adrp	x0, 0x1000 <generic_retkprobe_event+0x1000>
    14ac:      	add	x9, sp, #0xa8
    14b0:      	add	x1, sp, #0xa8
    14b4:      	str	w8, [sp, #0xb0]
    14b8:      	mov	w8, #0x1                // =1
    14bc:      	ldr	x0, [x0]
    14c0:      	blr	x8
    14c4:      	cbz	x0, 0x1c8c <generic_retkprobe_event+0x1c8c>
    14c8:      	ldr	x25, [sp, #0x28]
    14cc:      	ldr	w21, [x0]
    14d0:      	add	x8, sp, #0xf8
    14d4:      	mov	w9, #0x4                // =4
    14d8:      	add	x2, sp, #0xf8
    14dc:      	mov	x22, x0
    14e0:      	mov	w1, #0x4                // =4
    14e4:      	mov	w23, #0x4               // =4
    14e8:      	mov	x0, x25
    14ec:      	blr	x9
    14f0:      	ldr	x8, [sp, #0x30]
    14f4:      	and	x21, x21, #0xfff
    14f8:      	mov	x2, x22
    14fc:      	add	x1, x21, #0x4
    1500:      	add	x0, x8, #0xa0
    1504:      	mov	w8, #0x4                // =4
    1508:      	blr	x8
    150c:      	add	w21, w21, #0x8
    1510:      	mov	w1, #0x4                // =4
    1514:      	add	x8, x21, x22
    1518:      	add	x0, x25, x21
    151c:      	sub	x2, x8, #0x4
    1520:      	blr	x23
    1524:      	add	x29, x21, #0x4
    1528:      	b	0x20f0 <generic_retkprobe_event+0x20f0>
    152c:      	add	x29, sp, #0xf0
    1530:      	mov	x25, x22
    1534:      	mov	w8, #0x1                // =1
    1538:      	ldr	x22, [x29, #0x18]
    153c:      	mov	w9, #0x4                // =4
    1540:      	add	x10, sp, #0xe8
    1544:      	mov	x23, x0
    1548:      	add	x0, sp, #0xe8
    154c:      	mov	w1, #0x1                // =1
    1550:      	mov	x2, x22
    1554:      	blr	x9
    1558:      	ldrb	w8, [sp, #0xe8]
    155c:      	cmp	w8, #0x1
    1560:      	b.ne	0x1c7c <generic_retkprobe_event+0x1c7c>
    1564:      	add	x2, x22, #0x10
    1568:      	mov	w21, #0x8               // =8
    156c:      	add	x8, sp, #0xa8
    1570:      	mov	w9, #0x4                // =4
    1574:      	add	x0, sp, #0xa8
    1578:      	mov	w1, #0x8                // =8
    157c:      	mov	w24, #0x4               // =4
    1580:      	blr	x9
    1584:      	ldr	x2, [sp, #0xa8]
    1588:      	add	x8, sp, #0xf8
    158c:      	mov	w9, #0x4                // =4
    1590:      	add	x0, sp, #0xf8
    1594:      	mov	w1, #0x8                // =8
    1598:      	blr	x9
    159c:      	ldr	x8, [sp, #0xa8]
    15a0:      	mov	w9, #0x4                // =4
    15a4:      	add	x0, sp, #0x80
    15a8:      	mov	w1, #0x8                // =8
    15ac:      	add	x2, x8, #0x8
    15b0:      	add	x8, sp, #0x80
    15b4:      	blr	x9
    15b8:      	ldr	x21, [sp, #0x80]
    15bc:      	ldr	x2, [x29, #0x8]
    15c0:      	mov	w8, #0xfff              // =4095
    15c4:      	add	x0, x23, #0xa4
    15c8:      	cmp	x21, #0xfff
    15cc:      	csel	x22, x21, x8, lo
    15d0:      	mov	w1, w22
    15d4:      	blr	x24
    15d8:      	tbnz	w0, #0x1f, 0x1dd8 <generic_retkprobe_event+0x1dd8>
    15dc:      	stp	w21, w22, [x23, #0x9c]
    15e0:      	add	x29, x22, #0x8
    15e4:      	mov	x22, x25
    15e8:      	mov	w21, #0x5ea0            // =24224
    15ec:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    15f0:      	add	x8, sp, #0xf0
    15f4:      	ldr	x21, [sp, #0x30]
    15f8:      	str	x22, [sp, #0x18]
    15fc:      	mov	w1, #0x4                // =4
    1600:      	mov	w23, #0x4               // =4
    1604:      	add	x0, x21, #0xc4
    1608:      	ldr	x24, [x8, #0x18]
    160c:      	mov	w8, #0x4                // =4
    1610:      	add	x2, x24, #0x98
    1614:      	blr	x8
    1618:      	add	x0, x21, #0xc8
    161c:      	add	x2, x24, #0x70
    1620:      	mov	w8, #0x4                // =4
    1624:      	mov	w1, #0x4                // =4
    1628:      	blr	x8
    162c:      	add	x0, x21, #0xcc
    1630:      	add	x2, x24, #0x90
    1634:      	mov	w8, #0x4                // =4
    1638:      	mov	w1, #0x4                // =4
    163c:      	blr	x8
    1640:      	add	x0, x21, #0xd0
    1644:      	add	x2, x24, #0xa8
    1648:      	mov	w8, #0x4                // =4
    164c:      	mov	w1, #0x4                // =4
    1650:      	blr	x8
    1654:      	str	xzr, [sp, #0xa8]
    1658:      	add	x2, x24, #0xc8
    165c:      	mov	w8, #0x8                // =8
    1660:      	add	x9, sp, #0xa8
    1664:      	mov	w10, #0x4               // =4
    1668:      	add	x0, sp, #0xa8
    166c:      	mov	w1, #0x8                // =8
    1670:      	blr	x10
    1674:      	add	x2, x24, #0xb8
    1678:      	mov	w8, #0x2                // =2
    167c:      	add	x9, sp, #0xe8
    1680:      	mov	w10, #0x4               // =4
    1684:      	add	x0, sp, #0xe8
    1688:      	mov	w1, #0x2                // =2
    168c:      	blr	x10
    1690:      	ldr	x8, [sp, #0xa8]
    1694:      	ldrh	w9, [sp, #0xe8]
    1698:      	add	x0, sp, #0x94
    169c:      	mov	w1, #0x1                // =1
    16a0:      	add	x22, x8, x9
    16a4:      	mov	w8, #0x1                // =1
    16a8:      	add	x9, sp, #0x94
    16ac:      	mov	x2, x22
    16b0:      	blr	x23
    16b4:      	ldrb	w8, [sp, #0x94]
    16b8:      	lsr	w8, w8, #4
    16bc:      	cmp	w8, #0x6
    16c0:      	b.eq	0x1c94 <generic_retkprobe_event+0x1c94>
    16c4:      	cmp	w8, #0x4
    16c8:      	b.ne	0x28d8 <generic_retkprobe_event+0x28d8>
    16cc:      	add	x2, x22, #0x9
    16d0:      	mov	w8, #0x1                // =1
    16d4:      	add	x9, sp, #0x98
    16d8:      	mov	w10, #0x4               // =4
    16dc:      	add	x0, sp, #0x98
    16e0:      	mov	w1, #0x1                // =1
    16e4:      	mov	w25, #0x4               // =4
    16e8:      	blr	x10
    16ec:      	ldrb	w8, [sp, #0x98]
    16f0:      	ldp	x0, x9, [sp, #0x28]
    16f4:      	mov	w21, #0x2               // =2
    16f8:      	add	x2, x22, #0xc
    16fc:      	mov	w1, #0x4                // =4
    1700:      	add	x23, x9, #0xac
    1704:      	strh	w8, [x9, #0xc0]
    1708:      	strh	w21, [x9, #0xc2]
    170c:      	stp	xzr, xzr, [x0]
    1710:      	mov	w8, #0x4                // =4
    1714:      	stp	xzr, xzr, [x0, #0x10]
    1718:      	blr	x8
    171c:      	add	x2, x22, #0x10
    1720:      	mov	w8, #0x4                // =4
    1724:      	mov	x0, x23
    1728:      	mov	w1, #0x4                // =4
    172c:      	blr	x8
    1730:      	add	x2, x24, #0xb6
    1734:      	add	x8, sp, #0xa0
    1738:      	add	x0, sp, #0xa0
    173c:      	mov	w1, #0x2                // =2
    1740:      	blr	x25
    1744:      	b	0x279c <generic_retkprobe_event+0x279c>
    1748:      	ldr	x8, [x25, #0x18]
    174c:      	mov	w9, #0x2d               // =45
    1750:      	mov	w1, #0x11               // =17
    1754:      	add	x2, x8, #0x118
    1758:      	ldr	x8, [sp, #0x30]
    175c:      	add	x0, x8, #0xa0
    1760:      	mov	w8, #0x11               // =17
    1764:      	blr	x9
    1768:      	mov	x29, x0
    176c:      	tbnz	x0, #0x3f, 0xdd4 <generic_retkprobe_event+0xdd4>
    1770:      	ldr	x9, [sp, #0x28]
    1774:      	sub	w8, w29, #0x1
    1778:      	add	x29, x29, #0x3
    177c:      	str	w8, [x9]
    1780:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    1784:      	mov	x23, x22
    1788:      	ldr	x22, [x25, #0x18]
    178c:      	stp	xzr, xzr, [x0, #0x8]
    1790:      	mov	w8, #0x2                // =2
    1794:      	mov	w9, #0x4                // =4
    1798:      	mov	w1, #0x2                // =2
    179c:      	str	xzr, [x0]
    17a0:      	mov	x24, x0
    17a4:      	mov	x2, x22
    17a8:      	blr	x9
    17ac:      	tbnz	x0, #0x3f, 0x1e40 <generic_retkprobe_event+0x1e40>
    17b0:      	ldrh	w8, [x24]
    17b4:      	cmp	w8, #0xa
    17b8:      	b.eq	0x1df0 <generic_retkprobe_event+0x1df0>
    17bc:      	cmp	w8, #0x2
    17c0:      	b.ne	0x1e24 <generic_retkprobe_event+0x1e24>
    17c4:      	add	x2, x22, #0x4
    17c8:      	add	x8, sp, #0xa8
    17cc:      	mov	w9, #0x4                // =4
    17d0:      	add	x0, sp, #0xa8
    17d4:      	mov	w1, #0x4                // =4
    17d8:      	mov	w21, #0x4               // =4
    17dc:      	blr	x9
    17e0:      	ldr	w8, [sp, #0xa8]
    17e4:      	ldr	x9, [sp, #0x30]
    17e8:      	add	x2, x22, #0x2
    17ec:      	add	x0, x9, #0x9e
    17f0:      	stur	x8, [x9, #0xa4]
    17f4:      	mov	w8, #0x2                // =2
    17f8:      	b	0x1e1c <generic_retkprobe_event+0x1e1c>
    17fc:      	add	x19, sp, #0xf0
    1800:      	str	x22, [sp, #0x18]
    1804:      	str	xzr, [sp, #0xa8]
    1808:      	mov	w8, #0x8                // =8
    180c:      	add	x9, sp, #0xf8
    1810:      	add	x10, sp, #0xa8
    1814:      	str	xzr, [x19, #0x8]
    1818:      	mov	w11, #0x4               // =4
    181c:      	mov	x24, x0
    1820:      	add	x0, sp, #0xf8
    1824:      	add	x2, sp, #0xa8
    1828:      	mov	w1, #0x8                // =8
    182c:      	mov	w29, #0x4               // =4
    1830:      	blr	x11
    1834:      	ldr	x21, [x19, #0x8]
    1838:      	mov	w8, #0xfff              // =4095
    183c:      	add	x0, x24, #0xa4
    1840:      	mov	x2, x25
    1844:      	mov	x23, x24
    1848:      	cmp	x21, #0xfff
    184c:      	csel	x22, x21, x8, lo
    1850:      	mov	w8, #0x4                // =4
    1854:      	mov	w1, w22
    1858:      	blr	x8
    185c:      	tbnz	w0, #0x1f, 0x1dc8 <generic_retkprobe_event+0x1dc8>
    1860:      	add	x29, x22, #0x8
    1864:      	str	w22, [x23, #0xa0]
    1868:      	b	0x1dcc <generic_retkprobe_event+0x1dcc>
    186c:      	ldp	x0, x29, [sp, #0x28]
    1870:      	add	x2, x25, #0x8
    1874:      	mov	w8, #0x4                // =4
    1878:      	mov	w1, #0x4                // =4
    187c:      	mov	w23, #0x4               // =4
    1880:      	str	x22, [sp, #0x18]
    1884:      	add	x24, x29, #0xc4
    1888:      	add	x22, x29, #0xdc
    188c:      	blr	x8
    1890:      	add	x0, x29, #0xa0
    1894:      	add	x2, x25, #0xc
    1898:      	mov	w8, #0x4                // =4
    189c:      	mov	w1, #0x4                // =4
    18a0:      	blr	x8
    18a4:      	add	x0, x29, #0xac
    18a8:      	add	x2, x25, #0x18
    18ac:      	mov	w8, #0x4                // =4
    18b0:      	mov	w1, #0x4                // =4
    18b4:      	blr	x8
    18b8:      	add	x0, x29, #0xb0
    18bc:      	add	x2, x25, #0x1c
    18c0:      	mov	w8, #0x4                // =4
    18c4:      	mov	w1, #0x4                // =4
    18c8:      	blr	x8
    18cc:      	add	x0, x29, #0xa4
    18d0:      	add	x2, x25, #0x10
    18d4:      	mov	w8, #0x4                // =4
    18d8:      	mov	w1, #0x4                // =4
    18dc:      	blr	x8
    18e0:      	add	x0, x29, #0xa8
    18e4:      	add	x2, x25, #0x14
    18e8:      	mov	w8, #0x4                // =4
    18ec:      	mov	w1, #0x4                // =4
    18f0:      	blr	x8
    18f4:      	add	x0, x29, #0xb4
    18f8:      	add	x2, x25, #0x20
    18fc:      	mov	w8, #0x4                // =4
    1900:      	mov	w1, #0x4                // =4
    1904:      	blr	x8
    1908:      	add	x0, x29, #0xb8
    190c:      	add	x2, x25, #0x24
    1910:      	mov	w8, #0x4                // =4
    1914:      	mov	w1, #0x4                // =4
    1918:      	blr	x8
    191c:      	str	wzr, [x29, #0xc0]
    1920:      	add	x0, x29, #0xbc
    1924:      	add	x2, x25, #0x28
    1928:      	mov	w8, #0x4                // =4
    192c:      	mov	w1, #0x4                // =4
    1930:      	blr	x8
    1934:      	add	x0, x29, #0xcc
    1938:      	add	x2, x25, #0x40
    193c:      	mov	w21, #0x8               // =8
    1940:      	mov	w8, #0x4                // =4
    1944:      	mov	w1, #0x8                // =8
    1948:      	blr	x8
    194c:      	add	x0, x29, #0xd4
    1950:      	add	x2, x25, #0x30
    1954:      	mov	w8, #0x4                // =4
    1958:      	mov	w1, #0x8                // =8
    195c:      	blr	x8
    1960:      	add	x2, x25, #0x38
    1964:      	mov	w8, #0x4                // =4
    1968:      	mov	x0, x24
    196c:      	mov	w1, #0x8                // =8
    1970:      	blr	x8
    1974:      	add	x2, x25, #0x90
    1978:      	add	x8, sp, #0xa8
    197c:      	mov	w9, #0x4                // =4
    1980:      	add	x0, sp, #0xa8
    1984:      	mov	w1, #0x8                // =8
    1988:      	blr	x9
    198c:      	ldr	x21, [sp, #0xa8]
    1990:      	mov	w8, #0x4                // =4
    1994:      	mov	x0, x22
    1998:      	mov	w1, #0x4                // =4
    199c:      	add	x2, x21, #0xc8
    19a0:      	ldr	x22, [sp, #0x18]
    19a4:      	blr	x8
    19a8:      	add	x0, x29, #0xe0
    19ac:      	add	x2, x21, #0xcc
    19b0:      	mov	w8, #0x4                // =4
    19b4:      	mov	w1, #0x4                // =4
    19b8:      	blr	x8
    19bc:      	add	x0, x29, #0xe4
    19c0:      	add	x2, x21, #0xd0
    19c4:      	mov	w8, #0x4                // =4
    19c8:      	mov	w1, #0x4                // =4
    19cc:      	blr	x8
    19d0:      	add	x0, x29, #0xe8
    19d4:      	add	x2, x21, #0x158
    19d8:      	mov	w1, #0x4                // =4
    19dc:      	mov	w21, #0x5ea0            // =24224
    19e0:      	blr	x23
    19e4:      	mov	w29, #0x50              // =80
    19e8:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    19ec:      	ldr	x0, [sp, #0x28]
    19f0:      	add	x2, x25, #0xc8
    19f4:      	mov	w8, #0x4                // =4
    19f8:      	mov	w1, #0x4                // =4
    19fc:      	mov	w21, #0x4               // =4
    1a00:      	blr	x8
    1a04:      	ldr	x23, [sp, #0x30]
    1a08:      	add	x2, x25, #0xcc
    1a0c:      	mov	w8, #0x4                // =4
    1a10:      	mov	w1, #0x4                // =4
    1a14:      	add	x0, x23, #0xa0
    1a18:      	blr	x8
    1a1c:      	add	x0, x23, #0xa4
    1a20:      	add	x2, x25, #0xd0
    1a24:      	mov	w8, #0x4                // =4
    1a28:      	mov	w1, #0x4                // =4
    1a2c:      	blr	x8
    1a30:      	add	x0, x23, #0xa8
    1a34:      	add	x2, x25, #0x158
    1a38:      	mov	w1, #0x4                // =4
    1a3c:      	blr	x21
    1a40:      	mov	w21, #0x5ea0            // =24224
    1a44:      	mov	w29, #0x10              // =16
    1a48:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    1a4c:      	ldr	x0, [sp, #0x28]
    1a50:      	add	x2, x25, #0x38
    1a54:      	mov	w8, #0x4                // =4
    1a58:      	mov	w1, #0x4                // =4
    1a5c:      	mov	x21, x22
    1a60:      	mov	w22, #0x4               // =4
    1a64:      	blr	x8
    1a68:      	ldr	x23, [sp, #0x30]
    1a6c:      	add	x2, x25, #0x3c
    1a70:      	mov	w8, #0x4                // =4
    1a74:      	mov	w1, #0x4                // =4
    1a78:      	add	x0, x23, #0xa0
    1a7c:      	blr	x8
    1a80:      	add	x0, x23, #0xa4
    1a84:      	add	x2, x25, #0x40
    1a88:      	mov	w8, #0x4                // =4
    1a8c:      	mov	w1, #0x4                // =4
    1a90:      	blr	x8
    1a94:      	add	x0, x23, #0xa8
    1a98:      	add	x2, x25, #0x44
    1a9c:      	mov	w8, #0x4                // =4
    1aa0:      	mov	w1, #0x4                // =4
    1aa4:      	blr	x8
    1aa8:      	add	x0, x23, #0xac
    1aac:      	add	x2, x25, #0x80
    1ab0:      	mov	w8, #0x10               // =16
    1ab4:      	mov	w1, #0x10               // =16
    1ab8:      	blr	x22
    1abc:      	mov	x22, x21
    1ac0:      	mov	w21, #0x5ea0            // =24224
    1ac4:      	mov	w29, #0x20              // =32
    1ac8:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    1acc:      	ldr	x0, [sp, #0x28]
    1ad0:      	mov	w8, #0x4                // =4
    1ad4:      	mov	w1, #0x4                // =4
    1ad8:      	mov	x2, x25
    1adc:      	mov	w21, #0x4               // =4
    1ae0:      	blr	x8
    1ae4:      	ldr	x23, [sp, #0x30]
    1ae8:      	add	x2, x25, #0x4
    1aec:      	mov	w8, #0x4                // =4
    1af0:      	mov	w1, #0x4                // =4
    1af4:      	add	x0, x23, #0xa0
    1af8:      	blr	x8
    1afc:      	add	x0, x23, #0xa4
    1b00:      	add	x2, x25, #0x30
    1b04:      	mov	w8, #0x10               // =16
    1b08:      	b	0x1b88 <generic_retkprobe_event+0x1b88>
    1b0c:      	add	x2, x25, #0x4
    1b10:      	add	x8, sp, #0xa8
    1b14:      	mov	w9, #0x4                // =4
    1b18:      	add	x0, sp, #0xa8
    1b1c:      	mov	w1, #0x4                // =4
    1b20:      	mov	w21, #0x4               // =4
    1b24:      	blr	x9
    1b28:      	ldr	w8, [sp, #0xa8]
    1b2c:      	ldr	x23, [sp, #0x30]
    1b30:      	add	x2, x25, #0xc
    1b34:      	add	x0, sp, #0xa8
    1b38:      	mov	w1, #0x4                // =4
    1b3c:      	str	w8, [x23, #0x9c]
    1b40:      	add	x8, sp, #0xa8
    1b44:      	blr	x21
    1b48:      	ldr	w8, [sp, #0xa8]
    1b4c:      	add	x2, x25, #0x50
    1b50:      	add	x9, sp, #0xa8
    1b54:      	mov	w10, #0x2d              // =45
    1b58:      	str	w8, [x23, #0xa0]
    1b5c:      	mov	w8, #0x8                // =8
    1b60:      	add	x0, sp, #0xa8
    1b64:      	mov	w1, #0x8                // =8
    1b68:      	mov	w21, #0x2d              // =45
    1b6c:      	blr	x10
    1b70:      	ldr	x8, [sp, #0xa8]
    1b74:      	add	x0, x23, #0xa4
    1b78:      	mov	w9, #0x10               // =16
    1b7c:      	add	x8, x8, #0x3f8
    1b80:      	ldr	x8, [sp, #0xa8]
    1b84:      	add	x2, x8, #0x3f8
    1b88:      	mov	w1, #0x10               // =16
    1b8c:      	blr	x21
    1b90:      	mov	w21, #0x5ea0            // =24224
    1b94:      	mov	w29, #0x18              // =24
    1b98:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    1b9c:      	ldr	x11, [sp, #0x28]
    1ba0:      	mov	w8, #0x8                // =8
    1ba4:      	mov	w9, #0x4                // =4
    1ba8:      	add	x10, sp, #0xa8
    1bac:      	stp	xzr, xzr, [x11, #0x40]
    1bb0:      	add	x0, sp, #0xa8
    1bb4:      	stp	xzr, xzr, [x11, #0x30]
    1bb8:      	stp	xzr, xzr, [x11, #0x20]
    1bbc:      	mov	w1, #0x8                // =8
    1bc0:      	mov	x2, x25
    1bc4:      	stp	xzr, xzr, [x11, #0x10]
    1bc8:      	stp	xzr, xzr, [x11]
    1bcc:      	blr	x9
    1bd0:      	mov	x29, xzr
    1bd4:      	cbnz	x0, 0xdd4 <generic_retkprobe_event+0xdd4>
    1bd8:      	ldr	x8, [sp, #0x30]
    1bdc:      	mov	w9, #0x3f               // =63
    1be0:      	mov	w10, #0x2d              // =45
    1be4:      	mov	w1, #0x3f               // =63
    1be8:      	mov	x23, x22
    1bec:      	add	x0, x8, #0xac
    1bf0:      	ldr	x8, [sp, #0xa8]
    1bf4:      	ldr	x2, [sp, #0xa8]
    1bf8:      	blr	x10
    1bfc:      	tbnz	x0, #0x3f, 0x21b8 <generic_retkprobe_event+0x21b8>
    1c00:      	add	x2, x25, #0x8
    1c04:      	mov	w21, #0x8               // =8
    1c08:      	add	x8, sp, #0xf8
    1c0c:      	mov	w9, #0x4                // =4
    1c10:      	add	x0, sp, #0xf8
    1c14:      	mov	w1, #0x8                // =8
    1c18:      	mov	w22, #0x4               // =4
    1c1c:      	blr	x9
    1c20:      	ldr	x8, [sp, #0x30]
    1c24:      	add	x10, sp, #0xf0
    1c28:      	mov	w9, #0x4                // =4
    1c2c:      	mov	w1, #0x8                // =8
    1c30:      	add	x0, x8, #0xa4
    1c34:      	ldr	x8, [x10, #0x8]
    1c38:      	add	x8, x8, #0x360
    1c3c:      	ldr	x8, [x10, #0x8]
    1c40:      	add	x2, x8, #0x360
    1c44:      	blr	x9
    1c48:      	add	x2, x25, #0x58
    1c4c:      	add	x8, sp, #0xf8
    1c50:      	add	x0, sp, #0xf8
    1c54:      	mov	w1, #0x4                // =4
    1c58:      	blr	x22
    1c5c:      	cbnz	x0, 0x1c74 <generic_retkprobe_event+0x1c74>
    1c60:      	ldr	w8, [sp, #0xf8]
    1c64:      	ldr	x9, [sp, #0x28]
    1c68:      	cmp	w8, #0x0
    1c6c:      	cset	w8, ne
    1c70:      	str	w8, [x9]
    1c74:      	mov	w29, #0x50              // =80
    1c78:      	b	0x21bc <generic_retkprobe_event+0x21bc>
    1c7c:      	stur	xzr, [x23, #0x9c]
    1c80:      	mov	w29, #0x8               // =8
    1c84:      	mov	x22, x25
    1c88:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    1c8c:      	mov	x29, #-0x1              // =-1
    1c90:      	b	0x20f0 <generic_retkprobe_event+0x20f0>
    1c94:      	str	wzr, [sp, #0xf8]
    1c98:      	adrp	x0, 0x1000 <generic_retkprobe_event+0x1000>
    1c9c:      	ldr	x23, [sp, #0xa8]
    1ca0:      	mov	w8, #0x1                // =1
    1ca4:      	add	x9, sp, #0xf8
    1ca8:      	add	x1, sp, #0xf8
    1cac:      	ldrh	w21, [sp, #0xe8]
    1cb0:      	ldr	x0, [x0]
    1cb4:      	add	x22, x23, x21
    1cb8:      	blr	x8
    1cbc:      	cbz	x0, 0x275c <generic_retkprobe_event+0x275c>
    1cc0:      	mov	w8, #0xff               // =255
    1cc4:      	strh	w21, [x0]
    1cc8:      	strb	wzr, [x0, #0x7]
    1ccc:      	add	x29, x0, #0x6
    1cd0:      	add	x2, x22, #0x6
    1cd4:      	mov	w9, #0x4                // =4
    1cd8:      	strb	w8, [x0, #0x5]
    1cdc:      	mov	w8, #0x1                // =1
    1ce0:      	mov	x25, x0
    1ce4:      	mov	x0, x29
    1ce8:      	mov	w1, #0x1                // =1
    1cec:      	blr	x9
    1cf0:      	tbnz	x0, #0x3f, 0x275c <generic_retkprobe_event+0x275c>
    1cf4:      	ldrb	w8, [x25, #0x5]
    1cf8:      	cmp	w8, #0x32
    1cfc:      	b.gt	0x21cc <generic_retkprobe_event+0x21cc>
    1d00:      	cbz	w8, 0x21ec <generic_retkprobe_event+0x21ec>
    1d04:      	cmp	w8, #0x2b
    1d08:      	b.eq	0x21ec <generic_retkprobe_event+0x21ec>
    1d0c:      	cmp	w8, #0x2c
    1d10:      	b.ne	0x22b8 <generic_retkprobe_event+0x22b8>
    1d14:      	mov	w8, #0x8                // =8
    1d18:      	b	0x2204 <generic_retkprobe_event+0x2204>
    1d1c:      	add	x2, x22, #0x48
    1d20:      	mov	w21, #0x10              // =16
    1d24:      	mov	w8, #0x4                // =4
    1d28:      	mov	w1, #0x10               // =16
    1d2c:      	mov	w25, #0x4               // =4
    1d30:      	blr	x8
    1d34:      	add	x2, x22, #0x38
    1d38:      	mov	x0, x23
    1d3c:      	mov	w1, #0x10               // =16
    1d40:      	blr	x25
    1d44:      	ldr	x25, [sp, #0x30]
    1d48:      	add	x2, x22, #0xe
    1d4c:      	mov	w21, #0x2               // =2
    1d50:      	mov	w8, #0x4                // =4
    1d54:      	mov	w1, #0x2                // =2
    1d58:      	add	x23, x22, #0xc
    1d5c:      	mov	w22, #0x4               // =4
    1d60:      	add	x0, x25, #0xbc
    1d64:      	blr	x8
    1d68:      	add	x0, x25, #0xbe
    1d6c:      	mov	w1, #0x2                // =2
    1d70:      	mov	x2, x23
    1d74:      	blr	x22
    1d78:      	ldrh	w8, [x25, #0xbe]
    1d7c:      	adrp	x0, 0x1000 <generic_retkprobe_event+0x1000>
    1d80:      	add	x9, sp, #0xa8
    1d84:      	add	x1, sp, #0xa8
    1d88:      	rev	w8, w8
    1d8c:      	lsr	w8, w8, #16
    1d90:      	strh	w8, [x25, #0xbe]
    1d94:      	ldr	x8, [x29, #0x18]
    1d98:      	str	x8, [sp, #0xa8]
    1d9c:      	mov	w8, #0x1                // =1
    1da0:      	ldr	x0, [x0]
    1da4:      	blr	x8
    1da8:      	cbz	x0, 0x28d8 <generic_retkprobe_event+0x28d8>
    1dac:      	ldr	w8, [x0]
    1db0:      	str	w8, [x24, #0x10]
    1db4:      	ldr	x8, [x0, #0x8]
    1db8:      	str	x8, [x24, #0x18]
    1dbc:      	ldr	w8, [x0, #0x4]
    1dc0:      	str	w8, [x24, #0x7c]
    1dc4:      	b	0x28d8 <generic_retkprobe_event+0x28d8>
    1dc8:      	mov	w21, #-0x2              // =-2
    1dcc:      	ldr	x22, [sp, #0x18]
    1dd0:      	str	w21, [x23, #0x9c]
    1dd4:      	b	0x21c0 <generic_retkprobe_event+0x21c0>
    1dd8:      	mov	w8, #-0x2               // =-2
    1ddc:      	mov	w29, #0x4               // =4
    1de0:      	mov	x22, x25
    1de4:      	str	w8, [x23, #0x9c]
    1de8:      	mov	w21, #0x5ea0            // =24224
    1dec:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    1df0:      	ldr	x24, [sp, #0x30]
    1df4:      	add	x2, x22, #0x8
    1df8:      	mov	w8, #0x10               // =16
    1dfc:      	mov	w9, #0x4                // =4
    1e00:      	mov	w1, #0x10               // =16
    1e04:      	mov	w21, #0x4               // =4
    1e08:      	add	x0, x24, #0xa4
    1e0c:      	blr	x9
    1e10:      	add	x0, x24, #0x9e
    1e14:      	add	x2, x22, #0x2
    1e18:      	mov	w8, #0x2                // =2
    1e1c:      	mov	w1, #0x2                // =2
    1e20:      	blr	x21
    1e24:      	ldr	x9, [sp, #0x30]
    1e28:      	ldr	x19, [sp, #0x50]
    1e2c:      	mov	w21, #0x5ea0            // =24224
    1e30:      	ldrh	w8, [x9, #0x9e]
    1e34:      	rev	w8, w8
    1e38:      	lsr	w8, w8, #16
    1e3c:      	strh	w8, [x9, #0x9e]
    1e40:      	mov	w29, #0x18              // =24
    1e44:      	mov	x22, x23
    1e48:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    1e4c:      	ldr	x8, [sp, #0x58]
    1e50:      	mov	w9, #0x4                // =4
    1e54:      	ldr	x1, [sp, #0x40]
    1e58:      	add	x22, x22, x8
    1e5c:      	and	x8, x22, #0x3fff
    1e60:      	add	x0, x24, x8
    1e64:      	ldr	x8, [sp, #0xa8]
    1e68:      	ldr	x2, [sp, #0xa8]
    1e6c:      	blr	x9
    1e70:      	tbnz	w0, #0x1f, 0x20bc <generic_retkprobe_event+0x20bc>
    1e74:      	ldr	x8, [sp, #0x40]
    1e78:      	add	x29, x8, x29
    1e7c:      	cbz	x21, 0x1e88 <generic_retkprobe_event+0x1e88>
    1e80:      	subs	x21, x21, x23
    1e84:      	b.eq	0x20b4 <generic_retkprobe_event+0x20b4>
    1e88:      	ldr	x8, [sp, #0x60]
    1e8c:      	ldr	x19, [sp, #0x50]
    1e90:      	cmp	x8, #0x3
    1e94:      	b.eq	0x318 <generic_retkprobe_event+0x318>
    1e98:      	ldr	x8, [sp, #0x118]
    1e9c:      	mov	w9, #0x4                // =4
    1ea0:      	add	x10, sp, #0xa8
    1ea4:      	add	x0, sp, #0xa8
    1ea8:      	mov	w1, #0x10               // =16
    1eac:      	add	x2, x8, #0x30
    1eb0:      	mov	w8, #0x10               // =16
    1eb4:      	blr	x9
    1eb8:      	tbnz	w0, #0x1f, 0x20bc <generic_retkprobe_event+0x20bc>
    1ebc:      	ldr	x8, [sp, #0xb0]
    1ec0:      	cmp	x8, x21
    1ec4:      	csel	x23, x8, x21, lo
    1ec8:      	cmp	x21, #0x0
    1ecc:      	csel	x8, x8, x23, eq
    1ed0:      	cmp	x8, #0xffe
    1ed4:      	str	x8, [sp, #0x58]
    1ed8:      	b.hi	0x108c <generic_retkprobe_event+0x108c>
    1edc:      	ldr	x8, [sp, #0x40]
    1ee0:      	mov	w9, #0x4                // =4
    1ee4:      	ldr	x1, [sp, #0x58]
    1ee8:      	add	x22, x8, x22
    1eec:      	and	x8, x22, #0x3fff
    1ef0:      	add	x0, x24, x8
    1ef4:      	ldr	x8, [sp, #0xa8]
    1ef8:      	ldr	x2, [sp, #0xa8]
    1efc:      	blr	x9
    1f00:      	tbnz	w0, #0x1f, 0x20bc <generic_retkprobe_event+0x20bc>
    1f04:      	ldr	x8, [sp, #0x58]
    1f08:      	add	x29, x8, x29
    1f0c:      	cbz	x21, 0x1f18 <generic_retkprobe_event+0x1f18>
    1f10:      	subs	x21, x21, x23
    1f14:      	b.eq	0x20b4 <generic_retkprobe_event+0x20b4>
    1f18:      	ldr	x8, [sp, #0x60]
    1f1c:      	ldr	x19, [sp, #0x50]
    1f20:      	cmp	x8, #0x5
    1f24:      	b.lo	0x318 <generic_retkprobe_event+0x318>
    1f28:      	ldr	x8, [sp, #0x118]
    1f2c:      	mov	w9, #0x4                // =4
    1f30:      	add	x10, sp, #0xa8
    1f34:      	add	x0, sp, #0xa8
    1f38:      	mov	w1, #0x10               // =16
    1f3c:      	add	x2, x8, #0x40
    1f40:      	mov	w8, #0x10               // =16
    1f44:      	blr	x9
    1f48:      	tbnz	w0, #0x1f, 0x20bc <generic_retkprobe_event+0x20bc>
    1f4c:      	ldr	x8, [sp, #0xb0]
    1f50:      	cmp	x8, x21
    1f54:      	csel	x23, x8, x21, lo
    1f58:      	cmp	x21, #0x0
    1f5c:      	csel	x8, x8, x23, eq
    1f60:      	cmp	x8, #0xffe
    1f64:      	str	x8, [sp, #0x40]
    1f68:      	b.hi	0x108c <generic_retkprobe_event+0x108c>
    1f6c:      	ldr	x8, [sp, #0x58]
    1f70:      	mov	w9, #0x4                // =4
    1f74:      	ldr	x1, [sp, #0x40]
    1f78:      	add	x22, x8, x22
    1f7c:      	and	x8, x22, #0x3fff
    1f80:      	add	x0, x24, x8
    1f84:      	ldr	x8, [sp, #0xa8]
    1f88:      	ldr	x2, [sp, #0xa8]
    1f8c:      	blr	x9
    1f90:      	tbnz	w0, #0x1f, 0x20bc <generic_retkprobe_event+0x20bc>
    1f94:      	ldr	x8, [sp, #0x40]
    1f98:      	add	x29, x8, x29
    1f9c:      	cbz	x21, 0x1fa8 <generic_retkprobe_event+0x1fa8>
    1fa0:      	subs	x21, x21, x23
    1fa4:      	b.eq	0x20b4 <generic_retkprobe_event+0x20b4>
    1fa8:      	ldr	x8, [sp, #0x60]
    1fac:      	ldr	x19, [sp, #0x50]
    1fb0:      	cmp	x8, #0x5
    1fb4:      	b.eq	0x318 <generic_retkprobe_event+0x318>
    1fb8:      	ldr	x8, [sp, #0x118]
    1fbc:      	mov	w9, #0x4                // =4
    1fc0:      	add	x10, sp, #0xa8
    1fc4:      	add	x0, sp, #0xa8
    1fc8:      	mov	w1, #0x10               // =16
    1fcc:      	add	x2, x8, #0x50
    1fd0:      	mov	w8, #0x10               // =16
    1fd4:      	blr	x9
    1fd8:      	tbnz	w0, #0x1f, 0x20bc <generic_retkprobe_event+0x20bc>
    1fdc:      	ldr	x8, [sp, #0xb0]
    1fe0:      	cmp	x8, x21
    1fe4:      	csel	x23, x8, x21, lo
    1fe8:      	cmp	x21, #0x0
    1fec:      	csel	x8, x8, x23, eq
    1ff0:      	cmp	x8, #0xffe
    1ff4:      	str	x8, [sp, #0x58]
    1ff8:      	b.hi	0x108c <generic_retkprobe_event+0x108c>
    1ffc:      	ldr	x8, [sp, #0x40]
    2000:      	mov	w9, #0x4                // =4
    2004:      	ldr	x1, [sp, #0x58]
    2008:      	add	x22, x8, x22
    200c:      	and	x8, x22, #0x3fff
    2010:      	add	x0, x24, x8
    2014:      	ldr	x8, [sp, #0xa8]
    2018:      	ldr	x2, [sp, #0xa8]
    201c:      	blr	x9
    2020:      	tbnz	w0, #0x1f, 0x20bc <generic_retkprobe_event+0x20bc>
    2024:      	ldr	x8, [sp, #0x58]
    2028:      	add	x29, x8, x29
    202c:      	cbz	x21, 0x2038 <generic_retkprobe_event+0x2038>
    2030:      	subs	x21, x21, x23
    2034:      	b.eq	0x20b4 <generic_retkprobe_event+0x20b4>
    2038:      	ldr	x8, [sp, #0x60]
    203c:      	ldr	x19, [sp, #0x50]
    2040:      	cmp	x8, #0x7
    2044:      	b.lo	0x318 <generic_retkprobe_event+0x318>
    2048:      	ldr	x8, [sp, #0x118]
    204c:      	mov	w9, #0x4                // =4
    2050:      	add	x10, sp, #0xa8
    2054:      	add	x0, sp, #0xa8
    2058:      	mov	w1, #0x10               // =16
    205c:      	add	x2, x8, #0x60
    2060:      	mov	w8, #0x10               // =16
    2064:      	blr	x9
    2068:      	tbnz	w0, #0x1f, 0x20bc <generic_retkprobe_event+0x20bc>
    206c:      	ldr	x8, [sp, #0xb0]
    2070:      	cmp	x8, x21
    2074:      	csel	x9, x8, x21, lo
    2078:      	cmp	x21, #0x0
    207c:      	csel	x21, x8, x9, eq
    2080:      	cmp	x21, #0xffe
    2084:      	b.hi	0x108c <generic_retkprobe_event+0x108c>
    2088:      	ldr	x8, [sp, #0x58]
    208c:      	mov	w9, #0x4                // =4
    2090:      	mov	w1, w21
    2094:      	add	x8, x8, x22
    2098:      	and	x8, x8, #0x3fff
    209c:      	add	x0, x24, x8
    20a0:      	ldr	x8, [sp, #0xa8]
    20a4:      	ldr	x2, [sp, #0xa8]
    20a8:      	blr	x9
    20ac:      	tbnz	w0, #0x1f, 0x20bc <generic_retkprobe_event+0x20bc>
    20b0:      	add	x29, x21, x29
    20b4:      	ldr	x19, [sp, #0x50]
    20b8:      	b	0x318 <generic_retkprobe_event+0x318>
    20bc:      	mov	w8, #-0x2               // =-2
    20c0:      	ldp	x29, x19, [sp, #0x48]
    20c4:      	str	w8, [x24, x25]
    20c8:      	b	0x334 <generic_retkprobe_event+0x334>
    20cc:      	add	x2, x22, #0x3
    20d0:      	mov	w21, #0x6b              // =107
    20d4:      	mov	w8, #0x71               // =113
    20d8:      	mov	w1, #0x6b               // =107
    20dc:      	blr	x8
    20e0:      	tbnz	w0, #0x1f, 0x20ec <generic_retkprobe_event+0x20ec>
    20e4:      	ldr	x8, [sp, #0x30]
    20e8:      	strb	w21, [x8, #0x9f]
    20ec:      	mov	w29, #0x70              // =112
    20f0:      	mov	x22, x24
    20f4:      	mov	w21, #0x5ea0            // =24224
    20f8:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    20fc:      	ldr	x0, [sp, #0x28]
    2100:      	add	x2, x22, #0x48
    2104:      	mov	w21, #0x10              // =16
    2108:      	mov	w8, #0x4                // =4
    210c:      	mov	w1, #0x10               // =16
    2110:      	mov	w25, #0x4               // =4
    2114:      	blr	x8
    2118:      	add	x2, x22, #0x38
    211c:      	mov	x0, x23
    2120:      	mov	w1, #0x10               // =16
    2124:      	blr	x25
    2128:      	ldr	x25, [sp, #0x30]
    212c:      	add	x2, x22, #0xe
    2130:      	mov	w21, #0x2               // =2
    2134:      	mov	w8, #0x4                // =4
    2138:      	mov	w1, #0x2                // =2
    213c:      	add	x23, x22, #0xc
    2140:      	mov	w22, #0x4               // =4
    2144:      	add	x0, x25, #0xbc
    2148:      	blr	x8
    214c:      	add	x0, x25, #0xbe
    2150:      	mov	w1, #0x2                // =2
    2154:      	mov	x2, x23
    2158:      	blr	x22
    215c:      	ldrh	w8, [x25, #0xbe]
    2160:      	rev	w8, w8
    2164:      	lsr	w8, w8, #16
    2168:      	strh	w8, [x25, #0xbe]
    216c:      	ldr	x8, [sp, #0x30]
    2170:      	adrp	x0, 0x2000 <generic_retkprobe_event+0x2000>
    2174:      	add	x9, sp, #0xa8
    2178:      	add	x1, sp, #0xa8
    217c:      	ldur	x8, [x8, #0xc4]
    2180:      	str	x8, [sp, #0xa8]
    2184:      	mov	w8, #0x1                // =1
    2188:      	ldr	x0, [x0]
    218c:      	blr	x8
    2190:      	cbz	x0, 0x21ac <generic_retkprobe_event+0x21ac>
    2194:      	ldr	w8, [x0]
    2198:      	str	w8, [x24, #0x10]
    219c:      	ldr	x8, [x0, #0x8]
    21a0:      	str	x8, [x24, #0x18]
    21a4:      	ldr	w8, [x0, #0x4]
    21a8:      	str	w8, [x24, #0x7c]
    21ac:      	ldr	x22, [sp, #0x18]
    21b0:      	mov	w29, #0x40              // =64
    21b4:      	b	0x21c0 <generic_retkprobe_event+0x21c0>
    21b8:      	mov	x29, xzr
    21bc:      	mov	x22, x23
    21c0:      	ldr	x19, [sp, #0x50]
    21c4:      	mov	w21, #0x5ea0            // =24224
    21c8:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    21cc:      	cmp	w8, #0x33
    21d0:      	b.eq	0x21f8 <generic_retkprobe_event+0x21f8>
    21d4:      	cmp	w8, #0x3c
    21d8:      	b.eq	0x21ec <generic_retkprobe_event+0x21ec>
    21dc:      	cmp	w8, #0xff
    21e0:      	b.ne	0x22b8 <generic_retkprobe_event+0x22b8>
    21e4:      	mov	w8, #0x28               // =40
    21e8:      	b	0x2204 <generic_retkprobe_event+0x2204>
    21ec:      	ldrb	w8, [x25, #0x7]
    21f0:      	lsl	w8, w8, #3
    21f4:      	b	0x2200 <generic_retkprobe_event+0x2200>
    21f8:      	ldrb	w8, [x25, #0x7]
    21fc:      	lsl	w8, w8, #2
    2200:      	add	w8, w8, #0x8
    2204:      	strh	w8, [x25, #0x2]
    2208:      	ldrh	w9, [x25]
    220c:      	add	w9, w9, w8
    2210:      	ldrb	w8, [x25, #0x6]
    2214:      	strh	w9, [x25]
    2218:      	cmp	w8, #0x3c
    221c:      	b.hi	0x22d4 <generic_retkprobe_event+0x22d4>
    2220:      	mov	x19, #0x1               // =1
    2224:      	mov	w10, #0x1               // =1
    2228:      	movk	x19, #0x1800, lsl #32
    222c:      	lsl	x10, x10, x8
    2230:      	movk	x19, #0x1008, lsl #48
    2234:      	tst	x10, x19
    2238:      	b.eq	0x22d4 <generic_retkprobe_event+0x22d4>
    223c:      	strb	w8, [x25, #0x5]
    2240:      	add	x8, x23, w9, uxth
    2244:      	mov	w9, #0x2                // =2
    2248:      	mov	w10, #0x4               // =4
    224c:      	mov	x0, x29
    2250:      	mov	w1, #0x2                // =2
    2254:      	ldrh	w8, [x25]
    2258:      	add	x2, x23, x8
    225c:      	blr	x10
    2260:      	tbnz	x0, #0x3f, 0x275c <generic_retkprobe_event+0x275c>
    2264:      	ldrb	w8, [x25, #0x5]
    2268:      	cmp	w8, #0x32
    226c:      	b.gt	0x228c <generic_retkprobe_event+0x228c>
    2270:      	cbz	w8, 0x22ac <generic_retkprobe_event+0x22ac>
    2274:      	cmp	w8, #0x2b
    2278:      	b.eq	0x22ac <generic_retkprobe_event+0x22ac>
    227c:      	cmp	w8, #0x2c
    2280:      	b.ne	0x2390 <generic_retkprobe_event+0x2390>
    2284:      	mov	w8, #0x8                // =8
    2288:      	b	0x22e8 <generic_retkprobe_event+0x22e8>
    228c:      	cmp	w8, #0x33
    2290:      	b.eq	0x22dc <generic_retkprobe_event+0x22dc>
    2294:      	cmp	w8, #0x3c
    2298:      	b.eq	0x22ac <generic_retkprobe_event+0x22ac>
    229c:      	cmp	w8, #0xff
    22a0:      	b.ne	0x2390 <generic_retkprobe_event+0x2390>
    22a4:      	mov	w8, #0x28               // =40
    22a8:      	b	0x22e8 <generic_retkprobe_event+0x22e8>
    22ac:      	ldrb	w8, [x25, #0x7]
    22b0:      	lsl	w8, w8, #3
    22b4:      	b	0x22e4 <generic_retkprobe_event+0x22e4>
    22b8:      	ldrh	w8, [x25, #0x2]
    22bc:      	ldrh	w9, [x25]
    22c0:      	add	w9, w9, w8
    22c4:      	ldrb	w8, [x25, #0x6]
    22c8:      	strh	w9, [x25]
    22cc:      	cmp	w8, #0x3c
    22d0:      	b.ls	0x2220 <generic_retkprobe_event+0x2220>
    22d4:      	strh	w9, [sp, #0xa0]
    22d8:      	b	0x2760 <generic_retkprobe_event+0x2760>
    22dc:      	ldrb	w8, [x25, #0x7]
    22e0:      	lsl	w8, w8, #2
    22e4:      	add	w8, w8, #0x8
    22e8:      	strh	w8, [x25, #0x2]
    22ec:      	ldrh	w9, [x25]
    22f0:      	add	w9, w9, w8
    22f4:      	ldrb	w8, [x25, #0x6]
    22f8:      	strh	w9, [x25]
    22fc:      	cmp	w8, #0x3c
    2300:      	b.hi	0x2904 <generic_retkprobe_event+0x2904>
    2304:      	mov	w10, #0x1               // =1
    2308:      	lsl	x10, x10, x8
    230c:      	tst	x10, x19
    2310:      	b.eq	0x2904 <generic_retkprobe_event+0x2904>
    2314:      	strb	w8, [x25, #0x5]
    2318:      	add	x8, x23, w9, uxth
    231c:      	mov	w9, #0x2                // =2
    2320:      	mov	w10, #0x4               // =4
    2324:      	mov	x0, x29
    2328:      	mov	w1, #0x2                // =2
    232c:      	ldrh	w8, [x25]
    2330:      	add	x2, x23, x8
    2334:      	blr	x10
    2338:      	tbnz	x0, #0x3f, 0x275c <generic_retkprobe_event+0x275c>
    233c:      	ldrb	w8, [x25, #0x5]
    2340:      	cmp	w8, #0x32
    2344:      	b.gt	0x2364 <generic_retkprobe_event+0x2364>
    2348:      	cbz	w8, 0x2384 <generic_retkprobe_event+0x2384>
    234c:      	cmp	w8, #0x2b
    2350:      	b.eq	0x2384 <generic_retkprobe_event+0x2384>
    2354:      	cmp	w8, #0x2c
    2358:      	b.ne	0x2464 <generic_retkprobe_event+0x2464>
    235c:      	mov	w8, #0x8                // =8
    2360:      	b	0x23bc <generic_retkprobe_event+0x23bc>
    2364:      	cmp	w8, #0x33
    2368:      	b.eq	0x23b0 <generic_retkprobe_event+0x23b0>
    236c:      	cmp	w8, #0x3c
    2370:      	b.eq	0x2384 <generic_retkprobe_event+0x2384>
    2374:      	cmp	w8, #0xff
    2378:      	b.ne	0x2464 <generic_retkprobe_event+0x2464>
    237c:      	mov	w8, #0x28               // =40
    2380:      	b	0x23bc <generic_retkprobe_event+0x23bc>
    2384:      	ldrb	w8, [x25, #0x7]
    2388:      	lsl	w8, w8, #3
    238c:      	b	0x23b8 <generic_retkprobe_event+0x23b8>
    2390:      	ldrh	w8, [x25, #0x2]
    2394:      	ldrh	w9, [x25]
    2398:      	add	w9, w9, w8
    239c:      	ldrb	w8, [x25, #0x6]
    23a0:      	strh	w9, [x25]
    23a4:      	cmp	w8, #0x3c
    23a8:      	b.ls	0x2304 <generic_retkprobe_event+0x2304>
    23ac:      	b	0x2904 <generic_retkprobe_event+0x2904>
    23b0:      	ldrb	w8, [x25, #0x7]
    23b4:      	lsl	w8, w8, #2
    23b8:      	add	w8, w8, #0x8
    23bc:      	strh	w8, [x25, #0x2]
    23c0:      	ldrh	w9, [x25]
    23c4:      	add	w9, w9, w8
    23c8:      	ldrb	w8, [x25, #0x6]
    23cc:      	strh	w9, [x25]
    23d0:      	cmp	w8, #0x3c
    23d4:      	b.hi	0x2904 <generic_retkprobe_event+0x2904>
    23d8:      	mov	w10, #0x1               // =1
    23dc:      	lsl	x10, x10, x8
    23e0:      	tst	x10, x19
    23e4:      	b.eq	0x2904 <generic_retkprobe_event+0x2904>
    23e8:      	strb	w8, [x25, #0x5]
    23ec:      	add	x8, x23, w9, uxth
    23f0:      	mov	w9, #0x2                // =2
    23f4:      	mov	w10, #0x4               // =4
    23f8:      	mov	x0, x29
    23fc:      	mov	w1, #0x2                // =2
    2400:      	ldrh	w8, [x25]
    2404:      	add	x2, x23, x8
    2408:      	blr	x10
    240c:      	tbnz	x0, #0x3f, 0x275c <generic_retkprobe_event+0x275c>
    2410:      	ldrb	w8, [x25, #0x5]
    2414:      	cmp	w8, #0x32
    2418:      	b.gt	0x2438 <generic_retkprobe_event+0x2438>
    241c:      	cbz	w8, 0x2458 <generic_retkprobe_event+0x2458>
    2420:      	cmp	w8, #0x2b
    2424:      	b.eq	0x2458 <generic_retkprobe_event+0x2458>
    2428:      	cmp	w8, #0x2c
    242c:      	b.ne	0x2538 <generic_retkprobe_event+0x2538>
    2430:      	mov	w8, #0x8                // =8
    2434:      	b	0x2490 <generic_retkprobe_event+0x2490>
    2438:      	cmp	w8, #0x33
    243c:      	b.eq	0x2484 <generic_retkprobe_event+0x2484>
    2440:      	cmp	w8, #0x3c
    2444:      	b.eq	0x2458 <generic_retkprobe_event+0x2458>
    2448:      	cmp	w8, #0xff
    244c:      	b.ne	0x2538 <generic_retkprobe_event+0x2538>
    2450:      	mov	w8, #0x28               // =40
    2454:      	b	0x2490 <generic_retkprobe_event+0x2490>
    2458:      	ldrb	w8, [x25, #0x7]
    245c:      	lsl	w8, w8, #3
    2460:      	b	0x248c <generic_retkprobe_event+0x248c>
    2464:      	ldrh	w8, [x25, #0x2]
    2468:      	ldrh	w9, [x25]
    246c:      	add	w9, w9, w8
    2470:      	ldrb	w8, [x25, #0x6]
    2474:      	strh	w9, [x25]
    2478:      	cmp	w8, #0x3c
    247c:      	b.ls	0x23d8 <generic_retkprobe_event+0x23d8>
    2480:      	b	0x2904 <generic_retkprobe_event+0x2904>
    2484:      	ldrb	w8, [x25, #0x7]
    2488:      	lsl	w8, w8, #2
    248c:      	add	w8, w8, #0x8
    2490:      	strh	w8, [x25, #0x2]
    2494:      	ldrh	w9, [x25]
    2498:      	add	w9, w9, w8
    249c:      	ldrb	w8, [x25, #0x6]
    24a0:      	strh	w9, [x25]
    24a4:      	cmp	w8, #0x3c
    24a8:      	b.hi	0x2904 <generic_retkprobe_event+0x2904>
    24ac:      	mov	w10, #0x1               // =1
    24b0:      	lsl	x10, x10, x8
    24b4:      	tst	x10, x19
    24b8:      	b.eq	0x2904 <generic_retkprobe_event+0x2904>
    24bc:      	strb	w8, [x25, #0x5]
    24c0:      	add	x8, x23, w9, uxth
    24c4:      	mov	w9, #0x2                // =2
    24c8:      	mov	w10, #0x4               // =4
    24cc:      	mov	x0, x29
    24d0:      	mov	w1, #0x2                // =2
    24d4:      	ldrh	w8, [x25]
    24d8:      	add	x2, x23, x8
    24dc:      	blr	x10
    24e0:      	tbnz	x0, #0x3f, 0x275c <generic_retkprobe_event+0x275c>
    24e4:      	ldrb	w8, [x25, #0x5]
    24e8:      	cmp	w8, #0x32
    24ec:      	b.gt	0x250c <generic_retkprobe_event+0x250c>
    24f0:      	cbz	w8, 0x252c <generic_retkprobe_event+0x252c>
    24f4:      	cmp	w8, #0x2b
    24f8:      	b.eq	0x252c <generic_retkprobe_event+0x252c>
    24fc:      	cmp	w8, #0x2c
    2500:      	b.ne	0x260c <generic_retkprobe_event+0x260c>
    2504:      	mov	w8, #0x8                // =8
    2508:      	b	0x2564 <generic_retkprobe_event+0x2564>
    250c:      	cmp	w8, #0x33
    2510:      	b.eq	0x2558 <generic_retkprobe_event+0x2558>
    2514:      	cmp	w8, #0x3c
    2518:      	b.eq	0x252c <generic_retkprobe_event+0x252c>
    251c:      	cmp	w8, #0xff
    2520:      	b.ne	0x260c <generic_retkprobe_event+0x260c>
    2524:      	mov	w8, #0x28               // =40
    2528:      	b	0x2564 <generic_retkprobe_event+0x2564>
    252c:      	ldrb	w8, [x25, #0x7]
    2530:      	lsl	w8, w8, #3
    2534:      	b	0x2560 <generic_retkprobe_event+0x2560>
    2538:      	ldrh	w8, [x25, #0x2]
    253c:      	ldrh	w9, [x25]
    2540:      	add	w9, w9, w8
    2544:      	ldrb	w8, [x25, #0x6]
    2548:      	strh	w9, [x25]
    254c:      	cmp	w8, #0x3c
    2550:      	b.ls	0x24ac <generic_retkprobe_event+0x24ac>
    2554:      	b	0x2904 <generic_retkprobe_event+0x2904>
    2558:      	ldrb	w8, [x25, #0x7]
    255c:      	lsl	w8, w8, #2
    2560:      	add	w8, w8, #0x8
    2564:      	strh	w8, [x25, #0x2]
    2568:      	ldrh	w9, [x25]
    256c:      	add	w9, w9, w8
    2570:      	ldrb	w8, [x25, #0x6]
    2574:      	strh	w9, [x25]
    2578:      	cmp	w8, #0x3c
    257c:      	b.hi	0x2904 <generic_retkprobe_event+0x2904>
    2580:      	mov	w10, #0x1               // =1
    2584:      	lsl	x10, x10, x8
    2588:      	tst	x10, x19
    258c:      	b.eq	0x2904 <generic_retkprobe_event+0x2904>
    2590:      	strb	w8, [x25, #0x5]
    2594:      	add	x8, x23, w9, uxth
    2598:      	mov	w9, #0x2                // =2
    259c:      	mov	w10, #0x4               // =4
    25a0:      	mov	x0, x29
    25a4:      	mov	w1, #0x2                // =2
    25a8:      	ldrh	w8, [x25]
    25ac:      	add	x2, x23, x8
    25b0:      	blr	x10
    25b4:      	tbnz	x0, #0x3f, 0x275c <generic_retkprobe_event+0x275c>
    25b8:      	ldrb	w8, [x25, #0x5]
    25bc:      	cmp	w8, #0x32
    25c0:      	b.gt	0x25e0 <generic_retkprobe_event+0x25e0>
    25c4:      	cbz	w8, 0x2600 <generic_retkprobe_event+0x2600>
    25c8:      	cmp	w8, #0x2b
    25cc:      	b.eq	0x2600 <generic_retkprobe_event+0x2600>
    25d0:      	cmp	w8, #0x2c
    25d4:      	b.ne	0x26e0 <generic_retkprobe_event+0x26e0>
    25d8:      	mov	w8, #0x8                // =8
    25dc:      	b	0x2638 <generic_retkprobe_event+0x2638>
    25e0:      	cmp	w8, #0x33
    25e4:      	b.eq	0x262c <generic_retkprobe_event+0x262c>
    25e8:      	cmp	w8, #0x3c
    25ec:      	b.eq	0x2600 <generic_retkprobe_event+0x2600>
    25f0:      	cmp	w8, #0xff
    25f4:      	b.ne	0x26e0 <generic_retkprobe_event+0x26e0>
    25f8:      	mov	w8, #0x28               // =40
    25fc:      	b	0x2638 <generic_retkprobe_event+0x2638>
    2600:      	ldrb	w8, [x25, #0x7]
    2604:      	lsl	w8, w8, #3
    2608:      	b	0x2634 <generic_retkprobe_event+0x2634>
    260c:      	ldrh	w8, [x25, #0x2]
    2610:      	ldrh	w9, [x25]
    2614:      	add	w9, w9, w8
    2618:      	ldrb	w8, [x25, #0x6]
    261c:      	strh	w9, [x25]
    2620:      	cmp	w8, #0x3c
    2624:      	b.ls	0x2580 <generic_retkprobe_event+0x2580>
    2628:      	b	0x2904 <generic_retkprobe_event+0x2904>
    262c:      	ldrb	w8, [x25, #0x7]
    2630:      	lsl	w8, w8, #2
    2634:      	add	w8, w8, #0x8
    2638:      	strh	w8, [x25, #0x2]
    263c:      	ldrh	w9, [x25]
    2640:      	add	w9, w9, w8
    2644:      	ldrb	w8, [x25, #0x6]
    2648:      	strh	w9, [x25]
    264c:      	cmp	w8, #0x3c
    2650:      	b.hi	0x2904 <generic_retkprobe_event+0x2904>
    2654:      	mov	w10, #0x1               // =1
    2658:      	lsl	x10, x10, x8
    265c:      	tst	x10, x19
    2660:      	b.eq	0x2904 <generic_retkprobe_event+0x2904>
    2664:      	strb	w8, [x25, #0x5]
    2668:      	add	x8, x23, w9, uxth
    266c:      	mov	w9, #0x2                // =2
    2670:      	mov	w10, #0x4               // =4
    2674:      	mov	x0, x29
    2678:      	mov	w1, #0x2                // =2
    267c:      	ldrh	w8, [x25]
    2680:      	add	x2, x23, x8
    2684:      	blr	x10
    2688:      	tbnz	x0, #0x3f, 0x275c <generic_retkprobe_event+0x275c>
    268c:      	ldrb	w8, [x25, #0x5]
    2690:      	cmp	w8, #0x32
    2694:      	b.gt	0x26b4 <generic_retkprobe_event+0x26b4>
    2698:      	cbz	w8, 0x26d4 <generic_retkprobe_event+0x26d4>
    269c:      	cmp	w8, #0x2b
    26a0:      	b.eq	0x26d4 <generic_retkprobe_event+0x26d4>
    26a4:      	cmp	w8, #0x2c
    26a8:      	b.ne	0x28e8 <generic_retkprobe_event+0x28e8>
    26ac:      	mov	w8, #0x8                // =8
    26b0:      	b	0x270c <generic_retkprobe_event+0x270c>
    26b4:      	cmp	w8, #0x33
    26b8:      	b.eq	0x2700 <generic_retkprobe_event+0x2700>
    26bc:      	cmp	w8, #0x3c
    26c0:      	b.eq	0x26d4 <generic_retkprobe_event+0x26d4>
    26c4:      	cmp	w8, #0xff
    26c8:      	b.ne	0x28e8 <generic_retkprobe_event+0x28e8>
    26cc:      	mov	w8, #0x28               // =40
    26d0:      	b	0x270c <generic_retkprobe_event+0x270c>
    26d4:      	ldrb	w8, [x25, #0x7]
    26d8:      	lsl	w8, w8, #3
    26dc:      	b	0x2708 <generic_retkprobe_event+0x2708>
    26e0:      	ldrh	w8, [x25, #0x2]
    26e4:      	ldrh	w9, [x25]
    26e8:      	add	w9, w9, w8
    26ec:      	ldrb	w8, [x25, #0x6]
    26f0:      	strh	w9, [x25]
    26f4:      	cmp	w8, #0x3c
    26f8:      	b.ls	0x2654 <generic_retkprobe_event+0x2654>
    26fc:      	b	0x2904 <generic_retkprobe_event+0x2904>
    2700:      	ldrb	w8, [x25, #0x7]
    2704:      	lsl	w8, w8, #2
    2708:      	add	w8, w8, #0x8
    270c:      	strh	w8, [x25, #0x2]
    2710:      	ldrh	w9, [x25]
    2714:      	add	w9, w9, w8
    2718:      	ldrb	w8, [x25, #0x6]
    271c:      	strh	w9, [x25]
    2720:      	cmp	w8, #0x3c
    2724:      	b.hi	0x2904 <generic_retkprobe_event+0x2904>
    2728:      	mov	w10, #0x1               // =1
    272c:      	lsl	x10, x10, x8
    2730:      	tst	x10, x19
    2734:      	b.eq	0x2904 <generic_retkprobe_event+0x2904>
    2738:      	strb	w8, [x25, #0x5]
    273c:      	add	x8, x23, w9, uxth
    2740:      	mov	w9, #0x2                // =2
    2744:      	mov	w10, #0x4               // =4
    2748:      	mov	x0, x29
    274c:      	mov	w1, #0x2                // =2
    2750:      	ldrh	w8, [x25]
    2754:      	add	x2, x23, x8
    2758:      	blr	x10
    275c:      	mov	w8, wzr
    2760:      	ldp	x0, x25, [sp, #0x28]
    2764:      	add	x2, x22, #0x8
    2768:      	mov	w21, #0x10              // =16
    276c:      	mov	w1, #0x10               // =16
    2770:      	mov	w23, #0x4               // =4
    2774:      	strb	w8, [sp, #0x98]
    2778:      	strh	w8, [x25, #0xc0]
    277c:      	mov	w8, #0xa                // =10
    2780:      	strh	w8, [x25, #0xc2]
    2784:      	mov	w8, #0x4                // =4
    2788:      	blr	x8
    278c:      	add	x0, x25, #0xac
    2790:      	add	x2, x22, #0x18
    2794:      	mov	w1, #0x10               // =16
    2798:      	blr	x23
    279c:      	ldrb	w8, [sp, #0x98]
    27a0:      	cmp	w8, #0x11
    27a4:      	b.eq	0x27e8 <generic_retkprobe_event+0x27e8>
    27a8:      	cmp	w8, #0x6
    27ac:      	b.ne	0x2828 <generic_retkprobe_event+0x2828>
    27b0:      	ldr	x8, [sp, #0xa8]
    27b4:      	ldrh	w9, [sp, #0xa0]
    27b8:      	mov	w21, #0x2               // =2
    27bc:      	mov	w1, #0x2                // =2
    27c0:      	mov	w23, #0x4               // =4
    27c4:      	add	x22, x8, x9
    27c8:      	ldr	x25, [sp, #0x30]
    27cc:      	add	x0, x25, #0xbc
    27d0:      	mov	w8, #0x4                // =4
    27d4:      	mov	x2, x22
    27d8:      	blr	x8
    27dc:      	add	x0, x25, #0xbe
    27e0:      	add	x2, x22, #0x2
    27e4:      	b	0x281c <generic_retkprobe_event+0x281c>
    27e8:      	ldr	x8, [sp, #0xa8]
    27ec:      	ldrh	w9, [sp, #0xa0]
    27f0:      	mov	w21, #0x2               // =2
    27f4:      	mov	w1, #0x2                // =2
    27f8:      	mov	w23, #0x4               // =4
    27fc:      	add	x22, x8, x9
    2800:      	ldr	x25, [sp, #0x30]
    2804:      	add	x0, x25, #0xbc
    2808:      	mov	w8, #0x4                // =4
    280c:      	mov	x2, x22
    2810:      	blr	x8
    2814:      	add	x0, x25, #0xbe
    2818:      	add	x2, x22, #0x2
    281c:      	mov	w1, #0x2                // =2
    2820:      	blr	x23
    2824:      	b	0x2830 <generic_retkprobe_event+0x2830>
    2828:      	ldr	x25, [sp, #0x30]
    282c:      	str	wzr, [x25, #0xbc]
    2830:      	ldrh	w8, [x25, #0xbc]
    2834:      	add	x2, x24, #0xe0
    2838:      	mov	w9, #0x4                // =4
    283c:      	add	x10, sp, #0xf8
    2840:      	add	x0, sp, #0xf8
    2844:      	mov	w1, #0x8                // =8
    2848:      	rev	w8, w8
    284c:      	lsr	w8, w8, #16
    2850:      	strh	w8, [x25, #0xbc]
    2854:      	ldrh	w8, [x25, #0xbe]
    2858:      	rev	w8, w8
    285c:      	lsr	w8, w8, #16
    2860:      	strh	w8, [x25, #0xbe]
    2864:      	mov	w8, #0x8                // =8
    2868:      	blr	x9
    286c:      	add	x19, sp, #0xf0
    2870:      	ldr	x8, [x19, #0x8]
    2874:      	cbz	x8, 0x28d4 <generic_retkprobe_event+0x28d4>
    2878:      	add	x8, x8, #0x5
    287c:      	mov	w9, #0x8                // =8
    2880:      	add	x10, sp, #0x80
    2884:      	mov	w11, #0x4               // =4
    2888:      	ldr	x8, [x19, #0x8]
    288c:      	add	x0, sp, #0x80
    2890:      	mov	w1, #0x8                // =8
    2894:      	mov	w21, #0x4               // =4
    2898:      	add	x2, x8, #0x5
    289c:      	blr	x11
    28a0:      	ldr	x8, [x19, #0x8]
    28a4:      	ldr	x9, [sp, #0x80]
    28a8:      	mov	w1, #0x4                // =4
    28ac:      	add	x22, x8, x9, lsl #3
    28b0:      	ldr	x23, [sp, #0x30]
    28b4:      	add	x0, x23, #0xd4
    28b8:      	mov	w8, #0x4                // =4
    28bc:      	add	x2, x22, #0x44
    28c0:      	blr	x8
    28c4:      	add	x0, x23, #0xd8
    28c8:      	add	x2, x22, #0x45
    28cc:      	mov	w1, #0x4                // =4
    28d0:      	blr	x21
    28d4:      	ldr	x19, [sp, #0x50]
    28d8:      	ldr	x22, [sp, #0x18]
    28dc:      	mov	w29, #0x40              // =64
    28e0:      	mov	w21, #0x5ea0            // =24224
    28e4:      	b	0xdd4 <generic_retkprobe_event+0xdd4>
    28e8:      	ldrh	w8, [x25, #0x2]
    28ec:      	ldrh	w9, [x25]
    28f0:      	add	w9, w9, w8
    28f4:      	ldrb	w8, [x25, #0x6]
    28f8:      	strh	w9, [x25]
    28fc:      	cmp	w8, #0x3c
    2900:      	b.ls	0x2728 <generic_retkprobe_event+0x2728>
    2904:      	strh	w9, [sp, #0xa0]
    2908:      	b	0x2760 <generic_retkprobe_event+0x2760>
