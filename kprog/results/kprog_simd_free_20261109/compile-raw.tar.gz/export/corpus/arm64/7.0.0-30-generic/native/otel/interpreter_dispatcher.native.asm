
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/otel/interpreter_dispatcher.native.o:	file format elf64-littleaarch64

Disassembly of section perf_event/unwind_stop:

0000000000000000 <perf_unwind_stop>:
       0:      	sub	sp, sp, #0xe0
       4:      	str	x29, [sp, #0x90]
       8:      	stp	x30, x25, [sp, #0xa0]
       c:      	stp	x24, x23, [sp, #0xb0]
      10:      	stp	x22, x21, [sp, #0xc0]
      14:      	stp	x20, x19, [sp, #0xd0]
      18:      	str	wzr, [sp, #0x40]
      1c:      	adrp	x25, 0x0 <perf_unwind_stop>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x40
      28:      	ldr	x25, [x25]
      2c:      	mov	x24, x0
      30:      	add	x1, sp, #0x40
      34:      	mov	x0, x25
      38:      	blr	x8
      3c:      	cbz	x0, 0xf0 <perf_unwind_stop+0xf0>
      40:      	ldr	w8, [x0]
      44:      	mov	x20, x0
      48:      	adrp	x0, 0x0 <perf_unwind_stop>
      4c:      	add	x9, sp, #0x3c
      50:      	str	w8, [sp, #0x3c]
      54:      	mov	w8, #0x1                // =1
      58:      	add	x1, sp, #0x3c
      5c:      	ldr	x0, [x0]
      60:      	blr	x8
      64:      	adrp	x29, 0x0 <perf_unwind_stop>
      68:      	adrp	x21, 0x0 <perf_unwind_stop>
      6c:      	adrp	x22, 0x0 <perf_unwind_stop>
      70:      	ldr	x29, [x29]
      74:      	ldr	x21, [x21]
      78:      	ldr	x22, [x22]
      7c:      	cbz	x0, 0x478 <perf_unwind_stop+0x478>
      80:      	ldr	w8, [x29]
      84:      	mov	x23, x0
      88:      	cbnz	w8, 0x584 <perf_unwind_stop+0x584>
      8c:      	mov	w8, #0x23               // =35
      90:      	blr	x8
      94:      	ldr	x8, [x22]
      98:      	mov	w9, #0x71               // =113
      9c:      	add	x10, sp, #0x98
      a0:      	mov	w1, #0x8                // =8
      a4:      	add	x2, x0, x8
      a8:      	mov	w8, #0x8                // =8
      ac:      	add	x0, sp, #0x98
      b0:      	blr	x9
      b4:      	ldr	w8, [x29]
      b8:      	cbz	x0, 0xf8 <perf_unwind_stop+0xf8>
      bc:      	cbnz	w8, 0xcd0 <perf_unwind_stop+0xcd0>
      c0:      	mov	w8, #0x4                // =4
      c4:      	add	x9, sp, #0x10
      c8:      	add	x1, sp, #0x10
      cc:      	str	w8, [sp, #0x10]
      d0:      	mov	w8, #0x1                // =1
      d4:      	mov	x0, x21
      d8:      	blr	x8
      dc:      	cbz	x0, 0x1a8 <perf_unwind_stop+0x1a8>
      e0:      	ldr	x8, [x0]
      e4:      	add	x8, x8, #0x1
      e8:      	str	x8, [x0]
      ec:      	b	0x1b0 <perf_unwind_stop+0x1b0>
      f0:      	mov	w0, #-0x1               // =-1
      f4:      	b	0x1048 <perf_unwind_stop+0x1048>
      f8:      	cbnz	w8, 0xdd8 <perf_unwind_stop+0xdd8>
      fc:      	ldr	x8, [sp, #0x98]
     100:      	ldr	x9, [x23]
     104:      	mov	w10, #0x70              // =112
     108:      	add	x11, sp, #0x88
     10c:      	add	x0, sp, #0x88
     110:      	mov	w1, #0x8                // =8
     114:      	add	x8, x9, x8
     118:      	mov	w9, #0x8                // =8
     11c:      	ldr	x8, [sp, #0x98]
     120:      	ldr	x9, [x23]
     124:      	add	x2, x9, x8
     128:      	blr	x10
     12c:      	cbz	x0, 0x284 <perf_unwind_stop+0x284>
     130:      	mov	w8, #0x57               // =87
     134:      	add	x9, sp, #0x10
     138:      	add	x1, sp, #0x10
     13c:      	str	w8, [sp, #0x10]
     140:      	mov	w8, #0x1                // =1
     144:      	mov	x0, x21
     148:      	blr	x8
     14c:      	cbz	x0, 0x318 <perf_unwind_stop+0x318>
     150:      	ldr	x8, [x0]
     154:      	add	x8, x8, #0x1
     158:      	str	x8, [x0]
     15c:      	ldr	w8, [x29]
     160:      	cbz	w8, 0x478 <perf_unwind_stop+0x478>
     164:      	adrp	x8, 0x0 <perf_unwind_stop>
     168:      	add	x8, x8, #0x0
     16c:      	add	x0, sp, #0x40
     170:      	ldp	x9, x10, [x8, #0x10]
     174:      	mov	w1, #0x2f               // =47
     178:      	stp	x9, x10, [sp, #0x50]
     17c:      	ldr	x9, [x8, #0x20]
     180:      	add	x10, sp, #0x40
     184:      	str	x9, [sp, #0x60]
     188:      	ldur	x9, [x8, #0x27]
     18c:      	stur	x9, [sp, #0x67]
     190:      	ldp	x9, x8, [x8]
     194:      	stp	x9, x8, [sp, #0x40]
     198:      	mov	w8, #0x2f               // =47
     19c:      	mov	w9, #0x6                // =6
     1a0:      	blr	x9
     1a4:      	b	0x478 <perf_unwind_stop+0x478>
     1a8:      	ldr	w8, [x29]
     1ac:      	cbnz	w8, 0x1064 <perf_unwind_stop+0x1064>
     1b0:      	mov	w8, #0x56               // =86
     1b4:      	add	x9, sp, #0x10
     1b8:      	add	x1, sp, #0x10
     1bc:      	str	w8, [sp, #0x10]
     1c0:      	mov	w8, #0x1                // =1
     1c4:      	mov	x0, x21
     1c8:      	blr	x8
     1cc:      	cbz	x0, 0x22c <perf_unwind_stop+0x22c>
     1d0:      	ldr	x8, [x0]
     1d4:      	add	x8, x8, #0x1
     1d8:      	str	x8, [x0]
     1dc:      	ldr	w8, [x29]
     1e0:      	cbz	w8, 0x478 <perf_unwind_stop+0x478>
     1e4:      	mov	w8, #0x6e6f             // =28271
     1e8:      	add	x0, sp, #0x40
     1ec:      	mov	w1, #0x2c               // =44
     1f0:      	movk	w8, #0xa, lsl #16
     1f4:      	str	w8, [sp, #0x68]
     1f8:      	adrp	x8, 0x0 <perf_unwind_stop>
     1fc:      	add	x8, x8, #0x0
     200:      	ldp	x9, x10, [x8, #0x10]
     204:      	stp	x9, x10, [sp, #0x50]
     208:      	ldr	x9, [x8, #0x20]
     20c:      	add	x10, sp, #0x40
     210:      	str	x9, [sp, #0x60]
     214:      	ldp	x8, x9, [x8]
     218:      	stp	x8, x9, [sp, #0x40]
     21c:      	mov	w8, #0x2c               // =44
     220:      	mov	w9, #0x6                // =6
     224:      	blr	x9
     228:      	b	0x478 <perf_unwind_stop+0x478>
     22c:      	ldr	w8, [x29]
     230:      	cbz	w8, 0x478 <perf_unwind_stop+0x478>
     234:      	adrp	x8, 0x0 <perf_unwind_stop>
     238:      	add	x8, x8, #0x0
     23c:      	add	x0, sp, #0x40
     240:      	ldp	x9, x10, [x8, #0x10]
     244:      	mov	w1, #0x2e               // =46
     248:      	stp	x9, x10, [sp, #0x50]
     24c:      	ldr	x9, [x8, #0x20]
     250:      	add	x10, sp, #0x40
     254:      	str	x9, [sp, #0x60]
     258:      	ldur	x9, [x8, #0x26]
     25c:      	stur	x9, [sp, #0x66]
     260:      	ldp	x9, x8, [x8]
     264:      	stp	x9, x8, [sp, #0x40]
     268:      	mov	w8, #0x2e               // =46
     26c:      	mov	w9, #0x6                // =6
     270:      	ldr	w2, [sp, #0x10]
     274:      	blr	x9
     278:      	ldr	w8, [x29]
     27c:      	cbz	w8, 0x478 <perf_unwind_stop+0x478>
     280:      	b	0x1e4 <perf_unwind_stop+0x1e4>
     284:      	ldr	x8, [sp, #0x88]
     288:      	mov	w9, #0x25               // =37
     28c:      	mov	w10, #0x70              // =112
     290:      	add	x11, sp, #0x10
     294:      	ldr	x2, [sp, #0x88]
     298:      	add	x0, sp, #0x10
     29c:      	mov	w1, #0x25               // =37
     2a0:      	blr	x10
     2a4:      	cbz	x0, 0x370 <perf_unwind_stop+0x370>
     2a8:      	mov	w8, #0x58               // =88
     2ac:      	add	x9, sp, #0x84
     2b0:      	add	x1, sp, #0x84
     2b4:      	str	w8, [sp, #0x84]
     2b8:      	mov	w8, #0x1                // =1
     2bc:      	mov	x0, x21
     2c0:      	blr	x8
     2c4:      	cbz	x0, 0x418 <perf_unwind_stop+0x418>
     2c8:      	ldr	x8, [x0]
     2cc:      	add	x8, x8, #0x1
     2d0:      	str	x8, [x0]
     2d4:      	ldr	w8, [x29]
     2d8:      	cbz	w8, 0x478 <perf_unwind_stop+0x478>
     2dc:      	adrp	x8, 0x0 <perf_unwind_stop>
     2e0:      	add	x8, x8, #0x0
     2e4:      	add	x0, sp, #0x40
     2e8:      	ldp	x9, x10, [x8, #0x10]
     2ec:      	mov	w1, #0x27               // =39
     2f0:      	stp	x9, x10, [sp, #0x50]
     2f4:      	ldur	x9, [x8, #0x1f]
     2f8:      	add	x10, sp, #0x40
     2fc:      	stur	x9, [sp, #0x5f]
     300:      	ldp	x8, x9, [x8]
     304:      	stp	x8, x9, [sp, #0x40]
     308:      	mov	w8, #0x27               // =39
     30c:      	mov	w9, #0x6                // =6
     310:      	blr	x9
     314:      	b	0x478 <perf_unwind_stop+0x478>
     318:      	ldr	w8, [x29]
     31c:      	cbz	w8, 0x478 <perf_unwind_stop+0x478>
     320:      	adrp	x8, 0x0 <perf_unwind_stop>
     324:      	add	x8, x8, #0x0
     328:      	add	x0, sp, #0x40
     32c:      	ldp	x9, x10, [x8, #0x10]
     330:      	mov	w1, #0x2e               // =46
     334:      	stp	x9, x10, [sp, #0x50]
     338:      	ldr	x9, [x8, #0x20]
     33c:      	add	x10, sp, #0x40
     340:      	str	x9, [sp, #0x60]
     344:      	ldur	x9, [x8, #0x26]
     348:      	stur	x9, [sp, #0x66]
     34c:      	ldp	x9, x8, [x8]
     350:      	stp	x9, x8, [sp, #0x40]
     354:      	mov	w8, #0x2e               // =46
     358:      	mov	w9, #0x6                // =6
     35c:      	ldr	w2, [sp, #0x10]
     360:      	blr	x9
     364:      	ldr	w8, [x29]
     368:      	cbz	w8, 0x478 <perf_unwind_stop+0x478>
     36c:      	b	0x164 <perf_unwind_stop+0x164>
     370:      	ldrb	w8, [sp, #0x13]
     374:      	cbz	w8, 0x394 <perf_unwind_stop+0x394>
     378:      	ldrb	w8, [sp, #0x12]
     37c:      	cbz	w8, 0x394 <perf_unwind_stop+0x394>
     380:      	ldur	x10, [sp, #0x1d]
     384:      	ldur	x8, [sp, #0x15]
     388:      	ldur	x9, [sp, #0x2d]
     38c:      	str	x9, [x20, #0x20]
     390:      	stp	x8, x10, [x20, #0x28]
     394:      	mov	w8, #0x59               // =89
     398:      	add	x9, sp, #0x84
     39c:      	add	x1, sp, #0x84
     3a0:      	str	w8, [sp, #0x84]
     3a4:      	mov	w8, #0x1                // =1
     3a8:      	mov	x0, x21
     3ac:      	blr	x8
     3b0:      	cbz	x0, 0x470 <perf_unwind_stop+0x470>
     3b4:      	ldr	x8, [x0]
     3b8:      	add	x8, x8, #0x1
     3bc:      	str	x8, [x0]
     3c0:      	ldr	w8, [x29]
     3c4:      	cbz	w8, 0x478 <perf_unwind_stop+0x478>
     3c8:      	mov	w8, #0x5832             // =22578
     3cc:      	add	x0, sp, #0x40
     3d0:      	mov	w1, #0x2c               // =44
     3d4:      	movk	w8, #0xa, lsl #16
     3d8:      	str	w8, [sp, #0x68]
     3dc:      	adrp	x8, 0x0 <perf_unwind_stop>
     3e0:      	add	x8, x8, #0x0
     3e4:      	ldp	x9, x10, [x8, #0x10]
     3e8:      	stp	x9, x10, [sp, #0x50]
     3ec:      	ldr	x9, [x8, #0x20]
     3f0:      	add	x10, sp, #0x40
     3f4:      	str	x9, [sp, #0x60]
     3f8:      	ldp	x8, x9, [x8]
     3fc:      	stp	x8, x9, [sp, #0x40]
     400:      	mov	w8, #0x2c               // =44
     404:      	mov	w9, #0x6                // =6
     408:      	ldr	x2, [x20, #0x20]
     40c:      	ldrb	w3, [sp, #0x14]
     410:      	blr	x9
     414:      	b	0x478 <perf_unwind_stop+0x478>
     418:      	ldr	w8, [x29]
     41c:      	cbz	w8, 0x478 <perf_unwind_stop+0x478>
     420:      	adrp	x8, 0x0 <perf_unwind_stop>
     424:      	add	x8, x8, #0x0
     428:      	add	x0, sp, #0x40
     42c:      	ldp	x9, x10, [x8, #0x10]
     430:      	mov	w1, #0x2e               // =46
     434:      	stp	x9, x10, [sp, #0x50]
     438:      	ldr	x9, [x8, #0x20]
     43c:      	add	x10, sp, #0x40
     440:      	str	x9, [sp, #0x60]
     444:      	ldur	x9, [x8, #0x26]
     448:      	stur	x9, [sp, #0x66]
     44c:      	ldp	x9, x8, [x8]
     450:      	stp	x9, x8, [sp, #0x40]
     454:      	mov	w8, #0x2e               // =46
     458:      	mov	w9, #0x6                // =6
     45c:      	ldr	w2, [sp, #0x84]
     460:      	blr	x9
     464:      	ldr	w8, [x29]
     468:      	cbz	w8, 0x478 <perf_unwind_stop+0x478>
     46c:      	b	0x2dc <perf_unwind_stop+0x2dc>
     470:      	ldr	w8, [x29]
     474:      	cbnz	w8, 0x13c0 <perf_unwind_stop+0x13c0>
     478:      	ldr	w8, [x20, #0x2c0]
     47c:      	cbnz	w8, 0x4e0 <perf_unwind_stop+0x4e0>
     480:      	ldr	w8, [x20, #0x2bc]
     484:      	tbz	w8, #0x1f, 0x4e0 <perf_unwind_stop+0x4e0>
     488:      	ldr	w8, [x29]
     48c:      	cbnz	w8, 0x10f8 <perf_unwind_stop+0x10f8>
     490:      	mov	w8, #0x28               // =40
     494:      	add	x9, sp, #0x10
     498:      	add	x1, sp, #0x10
     49c:      	str	w8, [sp, #0x10]
     4a0:      	mov	w8, #0x1                // =1
     4a4:      	mov	x0, x21
     4a8:      	blr	x8
     4ac:      	cbz	x0, 0x4c8 <perf_unwind_stop+0x4c8>
     4b0:      	ldr	x8, [x0]
     4b4:      	add	x8, x8, #0x1
     4b8:      	str	x8, [x0]
     4bc:      	ldr	w8, [x20, #0xf1c]
     4c0:      	cbnz	w8, 0x4e0 <perf_unwind_stop+0x4e0>
     4c4:      	b	0x4d8 <perf_unwind_stop+0x4d8>
     4c8:      	ldr	w8, [x29]
     4cc:      	cbnz	w8, 0x1250 <perf_unwind_stop+0x1250>
     4d0:      	ldr	w8, [x20, #0xf1c]
     4d4:      	cbnz	w8, 0x4e0 <perf_unwind_stop+0x4e0>
     4d8:      	mov	w8, #0x3                // =3
     4dc:      	str	w8, [x20, #0xf1c]
     4e0:      	ldr	w8, [x20, #0xf1c]
     4e4:      	cbz	w8, 0x648 <perf_unwind_stop+0x648>
     4e8:      	ldr	w9, [x29]
     4ec:      	cbnz	w9, 0x5c8 <perf_unwind_stop+0x5c8>
     4f0:      	ldr	w9, [x20, #0x2c0]
     4f4:      	cmp	w9, #0x80
     4f8:      	b.lo	0x618 <perf_unwind_stop+0x618>
     4fc:      	ldr	w8, [x29]
     500:      	cbnz	w8, 0xd48 <perf_unwind_stop+0xd48>
     504:      	mov	w8, #0x2                // =2
     508:      	add	x9, sp, #0x10
     50c:      	add	x1, sp, #0x10
     510:      	str	w8, [sp, #0x10]
     514:      	mov	w8, #0x1                // =1
     518:      	mov	x0, x21
     51c:      	blr	x8
     520:      	cbz	x0, 0x534 <perf_unwind_stop+0x534>
     524:      	ldr	x8, [x0]
     528:      	add	x8, x8, #0x1
     52c:      	str	x8, [x0]
     530:      	b	0x648 <perf_unwind_stop+0x648>
     534:      	ldr	w8, [x29]
     538:      	cbz	w8, 0x648 <perf_unwind_stop+0x648>
     53c:      	adrp	x8, 0x0 <perf_unwind_stop>
     540:      	add	x8, x8, #0x0
     544:      	add	x0, sp, #0x40
     548:      	ldp	x9, x10, [x8, #0x10]
     54c:      	mov	w1, #0x2e               // =46
     550:      	stp	x9, x10, [sp, #0x50]
     554:      	ldr	x9, [x8, #0x20]
     558:      	add	x10, sp, #0x40
     55c:      	str	x9, [sp, #0x60]
     560:      	ldur	x9, [x8, #0x26]
     564:      	stur	x9, [sp, #0x66]
     568:      	ldp	x9, x8, [x8]
     56c:      	stp	x9, x8, [sp, #0x40]
     570:      	mov	w8, #0x2e               // =46
     574:      	mov	w9, #0x6                // =6
     578:      	ldr	w2, [sp, #0x10]
     57c:      	blr	x9
     580:      	b	0x648 <perf_unwind_stop+0x648>
     584:      	adrp	x8, 0x0 <perf_unwind_stop>
     588:      	add	x8, x8, #0x0
     58c:      	add	x0, sp, #0x40
     590:      	ldp	x9, x10, [x8, #0x20]
     594:      	mov	w1, #0x38               // =56
     598:      	stp	x9, x10, [sp, #0x60]
     59c:      	ldr	x9, [x8, #0x30]
     5a0:      	str	x9, [sp, #0x70]
     5a4:      	ldp	x9, x10, [x8]
     5a8:      	stp	x9, x10, [sp, #0x40]
     5ac:      	ldp	x8, x9, [x8, #0x10]
     5b0:      	add	x10, sp, #0x40
     5b4:      	stp	x8, x9, [sp, #0x50]
     5b8:      	mov	w8, #0x38               // =56
     5bc:      	mov	w9, #0x6                // =6
     5c0:      	blr	x9
     5c4:      	b	0x8c <perf_unwind_stop+0x8c>
     5c8:      	adrp	x8, 0x0 <perf_unwind_stop>
     5cc:      	add	x8, x8, #0x0
     5d0:      	strb	wzr, [sp, #0x70]
     5d4:      	add	x0, sp, #0x40
     5d8:      	ldp	x9, x10, [x8, #0x10]
     5dc:      	mov	w1, #0x31               // =49
     5e0:      	stp	x9, x10, [sp, #0x50]
     5e4:      	ldp	x9, x10, [x8, #0x20]
     5e8:      	stp	x9, x10, [sp, #0x60]
     5ec:      	ldp	x9, x8, [x8]
     5f0:      	add	x10, sp, #0x40
     5f4:      	stp	x9, x8, [sp, #0x40]
     5f8:      	mov	w8, #0x31               // =49
     5fc:      	mov	w9, #0x6                // =6
     600:      	ldr	w2, [x20, #0xf1c]
     604:      	blr	x9
     608:      	ldr	w8, [x20, #0xf1c]
     60c:      	ldr	w9, [x20, #0x2c0]
     610:      	cmp	w9, #0x80
     614:      	b.hs	0x4fc <perf_unwind_stop+0x4fc>
     618:      	add	w10, w9, #0x1
     61c:      	mov	w8, w8
     620:      	str	w10, [x20, #0x2c0]
     624:      	mov	w10, #0x18              // =24
     628:      	umaddl	x9, w9, w10, x20
     62c:      	mov	w10, #0xff              // =255
     630:      	str	x8, [x9, #0x2d8]
     634:      	add	x8, x9, #0x2d0
     638:      	str	xzr, [x9, #0x2d0]
     63c:      	strb	w10, [x9, #0x2e0]
     640:      	str	wzr, [x9, #0x2e4]
     644:      	stur	wzr, [x8, #0x11]
     648:      	ldr	w8, [x20, #0xf18]
     64c:      	cmn	w8, #0x1
     650:      	b.eq	0xa40 <perf_unwind_stop+0xa40>
     654:      	cmp	w8, #0xc
     658:      	b.ne	0x9fc <perf_unwind_stop+0x9fc>
     65c:      	ldp	w8, w9, [x20]
     660:      	mov	w10, #0x1375            // =4981
     664:      	adrp	x23, 0x0 <perf_unwind_stop>
     668:      	add	x1, sp, #0x84
     66c:      	ldrb	w29, [x20, x10]
     670:      	mov	x22, x24
     674:      	orr	x9, x9, x8, lsl #32
     678:      	cmp	w29, #0x2
     67c:      	str	x9, [sp, #0x98]
     680:      	str	w8, [sp, #0x3c]
     684:      	str	w8, [sp, #0x84]
     688:      	mov	w8, #0x1                // =1
     68c:      	add	x9, sp, #0x84
     690:      	ldr	x23, [x23]
     694:      	cset	w19, eq
     698:      	mov	x0, x23
     69c:      	blr	x8
     6a0:      	mov	w8, #0x5                // =5
     6a4:      	mov	x24, x0
     6a8:      	blr	x8
     6ac:      	cbz	w29, 0x80c <perf_unwind_stop+0x80c>
     6b0:      	lsl	w19, w19, #4
     6b4:      	cbz	x24, 0x740 <perf_unwind_stop+0x740>
     6b8:      	ldr	x8, [x24]
     6bc:      	mov	w11, #0xe100            // =57600
     6c0:      	movk	w11, #0x5f5, lsl #16
     6c4:      	and	x9, x8, #0xffffffffffffffe0
     6c8:      	and	x10, x8, #0xf
     6cc:      	sub	x9, x0, x9
     6d0:      	lsl	x10, x11, x10
     6d4:      	cmp	x9, x10
     6d8:      	b.hs	0x6fc <perf_unwind_stop+0x6fc>
     6dc:      	adrp	x29, 0x0 <perf_unwind_stop>
     6e0:      	mov	x24, x22
     6e4:      	ldr	x29, [x29]
     6e8:      	ldr	w8, [x29]
     6ec:      	cbnz	w8, 0x1218 <perf_unwind_stop+0x1218>
     6f0:      	adrp	x22, 0x0 <perf_unwind_stop>
     6f4:      	ldr	x22, [x22]
     6f8:      	b	0x9fc <perf_unwind_stop+0x9fc>
     6fc:      	and	w11, w8, #0x10
     700:      	orr	w19, w11, w19
     704:      	mov	x11, #0xf200            // =61952
     708:      	movk	x11, #0x2a05, lsl #16
     70c:      	movk	x11, #0x1, lsl #32
     710:      	add	x10, x10, x11
     714:      	cmp	x9, x10
     718:      	b.hs	0x73c <perf_unwind_stop+0x73c>
     71c:      	cmp	w19, #0x0
     720:      	mov	w9, #0x4                // =4
     724:      	mov	w10, #0x8               // =8
     728:      	and	w8, w8, #0xf
     72c:      	csel	w9, w10, w9, eq
     730:      	cmp	w9, w8
     734:      	cinc	w24, w8, hi
     738:      	b	0x740 <perf_unwind_stop+0x740>
     73c:      	mov	w24, wzr
     740:      	adrp	x8, 0x0 <perf_unwind_stop>
     744:      	ldr	x8, [x8]
     748:      	ldr	w8, [x8]
     74c:      	cbnz	w8, 0x10ac <perf_unwind_stop+0x10ac>
     750:      	and	x8, x0, #0xffffffffffffffe0
     754:      	and	x10, x24, #0xff
     758:      	mov	w9, w19
     75c:      	mov	x3, xzr
     760:      	add	x1, sp, #0x84
     764:      	add	x2, sp, #0x10
     768:      	mov	x0, x23
     76c:      	orr	x8, x8, x10
     770:      	add	x10, sp, #0x10
     774:      	orr	x8, x8, x9
     778:      	str	x8, [sp, #0x10]
     77c:      	mov	w8, #0x2                // =2
     780:      	add	x9, sp, #0x84
     784:      	blr	x8
     788:      	cbz	w0, 0x80c <perf_unwind_stop+0x80c>
     78c:      	adrp	x29, 0x0 <perf_unwind_stop>
     790:      	mov	x24, x22
     794:      	ldr	x29, [x29]
     798:      	ldr	w8, [x29]
     79c:      	cbnz	w8, 0x11d4 <perf_unwind_stop+0x11d4>
     7a0:      	mov	w8, #0x3d               // =61
     7a4:      	add	x9, sp, #0x88
     7a8:      	add	x1, sp, #0x88
     7ac:      	str	w8, [sp, #0x88]
     7b0:      	mov	w8, #0x1                // =1
     7b4:      	mov	x0, x21
     7b8:      	blr	x8
     7bc:      	adrp	x22, 0x0 <perf_unwind_stop>
     7c0:      	ldr	x22, [x22]
     7c4:      	cbnz	x0, 0x9f0 <perf_unwind_stop+0x9f0>
     7c8:      	ldr	w8, [x29]
     7cc:      	cbz	w8, 0x9fc <perf_unwind_stop+0x9fc>
     7d0:      	adrp	x8, 0x0 <perf_unwind_stop>
     7d4:      	add	x8, x8, #0x0
     7d8:      	ldp	x9, x10, [x8, #0x10]
     7dc:      	stp	x9, x10, [sp, #0x50]
     7e0:      	ldr	x9, [x8, #0x20]
     7e4:      	add	x10, sp, #0x40
     7e8:      	str	x9, [sp, #0x60]
     7ec:      	ldur	x9, [x8, #0x26]
     7f0:      	stur	x9, [sp, #0x66]
     7f4:      	ldp	x9, x8, [x8]
     7f8:      	stp	x9, x8, [sp, #0x40]
     7fc:      	mov	w8, #0x2e               // =46
     800:      	mov	w9, #0x6                // =6
     804:      	ldr	w2, [sp, #0x88]
     808:      	b	0xcc0 <perf_unwind_stop+0xcc0>
     80c:      	mov	w8, #0x1                // =1
     810:      	adrp	x0, 0x0 <perf_unwind_stop>
     814:      	mov	x3, xzr
     818:      	strb	w8, [sp, #0x38]
     81c:      	mov	w8, #0x2                // =2
     820:      	add	x9, sp, #0x98
     824:      	add	x10, sp, #0x38
     828:      	ldr	x0, [x0]
     82c:      	add	x1, sp, #0x98
     830:      	add	x2, sp, #0x38
     834:      	mov	x24, x22
     838:      	blr	x8
     83c:      	adrp	x22, 0x0 <perf_unwind_stop>
     840:      	ldr	x22, [x22]
     844:      	cbz	w0, 0x8b8 <perf_unwind_stop+0x8b8>
     848:      	adrp	x29, 0x0 <perf_unwind_stop>
     84c:      	ldr	x29, [x29]
     850:      	ldr	w8, [x29]
     854:      	cbnz	w8, 0x1140 <perf_unwind_stop+0x1140>
     858:      	mov	w8, #0x3e               // =62
     85c:      	add	x9, sp, #0x10
     860:      	add	x1, sp, #0x10
     864:      	str	w8, [sp, #0x10]
     868:      	mov	w8, #0x1                // =1
     86c:      	mov	x0, x21
     870:      	blr	x8
     874:      	cbnz	x0, 0x9f0 <perf_unwind_stop+0x9f0>
     878:      	ldr	w8, [x29]
     87c:      	cbz	w8, 0x9fc <perf_unwind_stop+0x9fc>
     880:      	adrp	x8, 0x0 <perf_unwind_stop>
     884:      	add	x8, x8, #0x0
     888:      	ldp	x9, x10, [x8, #0x10]
     88c:      	stp	x9, x10, [sp, #0x50]
     890:      	ldr	x9, [x8, #0x20]
     894:      	add	x10, sp, #0x40
     898:      	str	x9, [sp, #0x60]
     89c:      	ldur	x9, [x8, #0x26]
     8a0:      	stur	x9, [sp, #0x66]
     8a4:      	ldp	x9, x8, [x8]
     8a8:      	stp	x9, x8, [sp, #0x40]
     8ac:      	mov	w8, #0x2e               // =46
     8b0:      	mov	w9, #0x6                // =6
     8b4:      	b	0xcbc <perf_unwind_stop+0xcbc>
     8b8:      	cbnz	w29, 0x8d0 <perf_unwind_stop+0x8d0>
     8bc:      	mov	w8, #0x3                // =3
     8c0:      	add	x9, sp, #0x3c
     8c4:      	add	x1, sp, #0x3c
     8c8:      	mov	x0, x23
     8cc:      	blr	x8
     8d0:      	mov	w8, #0x1                // =1
     8d4:      	adrp	x0, 0x0 <perf_unwind_stop>
     8d8:      	mov	w9, #0x2                // =2
     8dc:      	str	w8, [sp, #0x88]
     8e0:      	strb	w8, [sp, #0x84]
     8e4:      	add	x10, sp, #0x88
     8e8:      	add	x11, sp, #0x84
     8ec:      	add	x1, sp, #0x88
     8f0:      	ldr	x0, [x0]
     8f4:      	add	x2, sp, #0x84
     8f8:      	mov	w3, #0x1                // =1
     8fc:      	blr	x9
     900:      	tbnz	w0, #0x1f, 0x93c <perf_unwind_stop+0x93c>
     904:      	mov	w8, #0x42               // =66
     908:      	add	x9, sp, #0x10
     90c:      	add	x1, sp, #0x10
     910:      	str	w8, [sp, #0x10]
     914:      	mov	w8, #0x1                // =1
     918:      	mov	x0, x21
     91c:      	blr	x8
     920:      	adrp	x29, 0x0 <perf_unwind_stop>
     924:      	ldr	x29, [x29]
     928:      	cbz	x0, 0x988 <perf_unwind_stop+0x988>
     92c:      	ldr	x8, [x0]
     930:      	add	x8, x8, #0x1
     934:      	str	x8, [x0]
     938:      	b	0x990 <perf_unwind_stop+0x990>
     93c:      	adrp	x29, 0x0 <perf_unwind_stop>
     940:      	ldr	x29, [x29]
     944:      	ldr	w8, [x29]
     948:      	cbz	w8, 0x9d0 <perf_unwind_stop+0x9d0>
     94c:      	adrp	x8, 0x0 <perf_unwind_stop>
     950:      	add	x8, x8, #0x0
     954:      	strb	wzr, [sp, #0x58]
     958:      	add	x0, sp, #0x40
     95c:      	ldp	x9, x10, [x8]
     960:      	ldr	x8, [x8, #0x10]
     964:      	mov	w1, #0x19               // =25
     968:      	mov	w2, #0x1                // =1
     96c:      	str	x8, [sp, #0x50]
     970:      	stp	x9, x10, [sp, #0x40]
     974:      	mov	w8, #0x19               // =25
     978:      	mov	w9, #0x6                // =6
     97c:      	add	x10, sp, #0x40
     980:      	blr	x9
     984:      	b	0x9d0 <perf_unwind_stop+0x9d0>
     988:      	ldr	w8, [x29]
     98c:      	cbnz	w8, 0x1378 <perf_unwind_stop+0x1378>
     990:      	mov	w8, #0x1                // =1
     994:      	adrp	x1, 0x0 <perf_unwind_stop>
     998:      	mov	w9, #0x4                // =4
     99c:      	str	w8, [sp, #0x10]
     9a0:      	mov	w8, #-0x1               // =-1
     9a4:      	mov	w10, #0x19              // =25
     9a8:      	add	x11, sp, #0x10
     9ac:      	ldr	x1, [x1]
     9b0:      	add	x3, sp, #0x10
     9b4:      	mov	x0, x24
     9b8:      	mov	w2, #-0x1               // =-1
     9bc:      	mov	w4, #0x4                // =4
     9c0:      	blr	x10
     9c4:      	tbz	w0, #0x1f, 0x9d0 <perf_unwind_stop+0x9d0>
     9c8:      	ldr	w8, [x29]
     9cc:      	cbnz	w8, 0x132c <perf_unwind_stop+0x132c>
     9d0:      	mov	w8, #0x41               // =65
     9d4:      	add	x9, sp, #0x10
     9d8:      	add	x1, sp, #0x10
     9dc:      	str	w8, [sp, #0x10]
     9e0:      	mov	w8, #0x1                // =1
     9e4:      	mov	x0, x21
     9e8:      	blr	x8
     9ec:      	cbz	x0, 0xc80 <perf_unwind_stop+0xc80>
     9f0:      	ldr	x8, [x0]
     9f4:      	add	x8, x8, #0x1
     9f8:      	str	x8, [x0]
     9fc:      	ldr	w8, [x20, #0xf18]
     a00:      	add	x9, sp, #0x10
     a04:      	add	x1, sp, #0x10
     a08:      	mov	x0, x21
     a0c:      	str	w8, [sp, #0x10]
     a10:      	mov	w8, #0x1                // =1
     a14:      	blr	x8
     a18:      	cbz	x0, 0xa38 <perf_unwind_stop+0xa38>
     a1c:      	ldr	x8, [x0]
     a20:      	add	x8, x8, #0x1
     a24:      	str	x8, [x0]
     a28:      	ldr	w8, [x20, #0x2c0]
     a2c:      	cmp	w8, #0x1
     a30:      	b.eq	0xa4c <perf_unwind_stop+0xa4c>
     a34:      	b	0xa54 <perf_unwind_stop+0xa54>
     a38:      	ldr	w8, [x29]
     a3c:      	cbnz	w8, 0xd84 <perf_unwind_stop+0xd84>
     a40:      	ldr	w8, [x20, #0x2c0]
     a44:      	cmp	w8, #0x1
     a48:      	b.ne	0xa54 <perf_unwind_stop+0xa54>
     a4c:      	ldr	w8, [x20, #0x2bc]
     a50:      	tbnz	w8, #0x1f, 0xc0c <perf_unwind_stop+0xc0c>
     a54:      	ldr	w8, [x20]
     a58:      	adrp	x0, 0x0 <perf_unwind_stop>
     a5c:      	add	x9, sp, #0x84
     a60:      	add	x1, sp, #0x84
     a64:      	str	w8, [sp, #0x84]
     a68:      	mov	w8, #0x1                // =1
     a6c:      	ldr	x0, [x0]
     a70:      	blr	x8
     a74:      	cbz	x0, 0xb30 <perf_unwind_stop+0xb30>
     a78:      	str	xzr, [sp, #0x10]
     a7c:      	str	xzr, [sp, #0x98]
     a80:      	mov	w8, #0x23               // =35
     a84:      	mov	x23, x0
     a88:      	blr	x8
     a8c:      	ldr	x8, [x22]
     a90:      	mov	w9, #0x71               // =113
     a94:      	add	x10, sp, #0x98
     a98:      	mov	w1, #0x8                // =8
     a9c:      	add	x2, x0, x8
     aa0:      	mov	w8, #0x8                // =8
     aa4:      	add	x0, sp, #0x98
     aa8:      	blr	x9
     aac:      	ldr	w8, [x29]
     ab0:      	cbz	x0, 0xb80 <perf_unwind_stop+0xb80>
     ab4:      	cbnz	w8, 0xd0c <perf_unwind_stop+0xd0c>
     ab8:      	mov	w8, #0x4                // =4
     abc:      	add	x9, sp, #0x88
     ac0:      	add	x1, sp, #0x88
     ac4:      	str	w8, [sp, #0x88]
     ac8:      	mov	w8, #0x1                // =1
     acc:      	mov	x0, x21
     ad0:      	blr	x8
     ad4:      	cbz	x0, 0xc28 <perf_unwind_stop+0xc28>
     ad8:      	ldr	x8, [x0]
     adc:      	add	x8, x8, #0x1
     ae0:      	str	x8, [x0]
     ae4:      	ldr	w8, [x29]
     ae8:      	cbz	w8, 0x1004 <perf_unwind_stop+0x1004>
     aec:      	adrp	x8, 0x0 <perf_unwind_stop>
     af0:      	add	x8, x8, #0x0
     af4:      	add	x0, sp, #0x40
     af8:      	ldp	x9, x10, [x8, #0x10]
     afc:      	mov	w1, #0x2e               // =46
     b00:      	stp	x9, x10, [sp, #0x50]
     b04:      	ldr	x9, [x8, #0x20]
     b08:      	add	x10, sp, #0x40
     b0c:      	str	x9, [sp, #0x60]
     b10:      	ldur	x9, [x8, #0x26]
     b14:      	stur	x9, [sp, #0x66]
     b18:      	ldp	x9, x8, [x8]
     b1c:      	stp	x9, x8, [sp, #0x40]
     b20:      	mov	w8, #0x2e               // =46
     b24:      	mov	w9, #0x6                // =6
     b28:      	blr	x9
     b2c:      	b	0x1004 <perf_unwind_stop+0x1004>
     b30:      	ldr	w8, [x29]
     b34:      	cbz	w8, 0x1004 <perf_unwind_stop+0x1004>
     b38:      	mov	w8, #0xa                // =10
     b3c:      	add	x0, sp, #0x40
     b40:      	mov	w1, #0x32               // =50
     b44:      	strh	w8, [sp, #0x70]
     b48:      	adrp	x8, 0x0 <perf_unwind_stop>
     b4c:      	add	x8, x8, #0x0
     b50:      	ldp	x9, x10, [x8, #0x10]
     b54:      	stp	x9, x10, [sp, #0x50]
     b58:      	ldp	x9, x10, [x8, #0x20]
     b5c:      	stp	x9, x10, [sp, #0x60]
     b60:      	ldp	x9, x8, [x8]
     b64:      	add	x10, sp, #0x40
     b68:      	stp	x9, x8, [sp, #0x40]
     b6c:      	mov	w8, #0x32               // =50
     b70:      	mov	w9, #0x6                // =6
     b74:      	ldr	w2, [sp, #0x84]
     b78:      	blr	x9
     b7c:      	b	0x1004 <perf_unwind_stop+0x1004>
     b80:      	cbnz	w8, 0xe20 <perf_unwind_stop+0xe20>
     b84:      	ldrsw	x8, [x23, #0x18]
     b88:      	cbz	w8, 0xe70 <perf_unwind_stop+0xe70>
     b8c:      	ldr	x9, [sp, #0x98]
     b90:      	mov	w10, #0x70              // =112
     b94:      	add	x11, sp, #0x10
     b98:      	add	x0, sp, #0x10
     b9c:      	mov	w1, #0x8                // =8
     ba0:      	add	x8, x9, x8
     ba4:      	mov	w9, #0x8                // =8
     ba8:      	ldr	x8, [sp, #0x98]
     bac:      	ldrsw	x9, [x23, #0x18]
     bb0:      	add	x2, x9, x8
     bb4:      	blr	x10
     bb8:      	ldr	w8, [x29]
     bbc:      	cbz	x0, 0xe80 <perf_unwind_stop+0xe80>
     bc0:      	cbz	w8, 0x1004 <perf_unwind_stop+0x1004>
     bc4:      	mov	w8, #0xa                // =10
     bc8:      	add	x0, sp, #0x40
     bcc:      	mov	w1, #0x2a               // =42
     bd0:      	strh	w8, [sp, #0x68]
     bd4:      	adrp	x8, 0x0 <perf_unwind_stop>
     bd8:      	add	x8, x8, #0x0
     bdc:      	ldp	x9, x10, [x8, #0x10]
     be0:      	stp	x9, x10, [sp, #0x50]
     be4:      	ldr	x9, [x8, #0x20]
     be8:      	add	x10, sp, #0x40
     bec:      	str	x9, [sp, #0x60]
     bf0:      	ldp	x8, x9, [x8]
     bf4:      	stp	x8, x9, [sp, #0x40]
     bf8:      	mov	w8, #0x2a               // =42
     bfc:      	mov	w9, #0x6                // =6
     c00:      	ldr	x2, [sp, #0x98]
     c04:      	blr	x9
     c08:      	b	0x1004 <perf_unwind_stop+0x1004>
     c0c:      	ldr	w8, [x20, #0xf1c]
     c10:      	cbz	w8, 0xa54 <perf_unwind_stop+0xa54>
     c14:      	adrp	x8, 0x0 <perf_unwind_stop>
     c18:      	ldr	x8, [x8]
     c1c:      	ldrb	w8, [x8]
     c20:      	cbnz	w8, 0x1044 <perf_unwind_stop+0x1044>
     c24:      	b	0xa54 <perf_unwind_stop+0xa54>
     c28:      	ldr	w8, [x29]
     c2c:      	cbz	w8, 0x1004 <perf_unwind_stop+0x1004>
     c30:      	adrp	x8, 0x0 <perf_unwind_stop>
     c34:      	add	x8, x8, #0x0
     c38:      	add	x0, sp, #0x40
     c3c:      	ldp	x9, x10, [x8, #0x10]
     c40:      	mov	w1, #0x2e               // =46
     c44:      	stp	x9, x10, [sp, #0x50]
     c48:      	ldr	x9, [x8, #0x20]
     c4c:      	add	x10, sp, #0x40
     c50:      	str	x9, [sp, #0x60]
     c54:      	ldur	x9, [x8, #0x26]
     c58:      	stur	x9, [sp, #0x66]
     c5c:      	ldp	x9, x8, [x8]
     c60:      	stp	x9, x8, [sp, #0x40]
     c64:      	mov	w8, #0x2e               // =46
     c68:      	mov	w9, #0x6                // =6
     c6c:      	ldr	w2, [sp, #0x88]
     c70:      	blr	x9
     c74:      	ldr	w8, [x29]
     c78:      	cbz	w8, 0x1004 <perf_unwind_stop+0x1004>
     c7c:      	b	0xaec <perf_unwind_stop+0xaec>
     c80:      	ldr	w8, [x29]
     c84:      	cbz	w8, 0x9fc <perf_unwind_stop+0x9fc>
     c88:      	adrp	x8, 0x0 <perf_unwind_stop>
     c8c:      	add	x8, x8, #0x0
     c90:      	ldp	x9, x10, [x8, #0x10]
     c94:      	stp	x9, x10, [sp, #0x50]
     c98:      	ldr	x9, [x8, #0x20]
     c9c:      	add	x10, sp, #0x40
     ca0:      	str	x9, [sp, #0x60]
     ca4:      	ldur	x9, [x8, #0x26]
     ca8:      	stur	x9, [sp, #0x66]
     cac:      	ldp	x9, x8, [x8]
     cb0:      	stp	x9, x8, [sp, #0x40]
     cb4:      	mov	w8, #0x2e               // =46
     cb8:      	mov	w9, #0x6                // =6
     cbc:      	ldr	w2, [sp, #0x10]
     cc0:      	add	x0, sp, #0x40
     cc4:      	mov	w1, #0x2e               // =46
     cc8:      	blr	x9
     ccc:      	b	0x9fc <perf_unwind_stop+0x9fc>
     cd0:      	adrp	x8, 0x0 <perf_unwind_stop>
     cd4:      	add	x8, x8, #0x0
     cd8:      	add	x0, sp, #0x40
     cdc:      	ldp	x9, x10, [x8]
     ce0:      	mov	w1, #0x1d               // =29
     ce4:      	stp	x9, x10, [sp, #0x40]
     ce8:      	ldr	x9, [x8, #0x10]
     cec:      	ldur	x8, [x8, #0x15]
     cf0:      	add	x10, sp, #0x40
     cf4:      	str	x9, [sp, #0x50]
     cf8:      	stur	x8, [sp, #0x55]
     cfc:      	mov	w8, #0x1d               // =29
     d00:      	mov	w9, #0x6                // =6
     d04:      	blr	x9
     d08:      	b	0xc0 <perf_unwind_stop+0xc0>
     d0c:      	adrp	x8, 0x0 <perf_unwind_stop>
     d10:      	add	x8, x8, #0x0
     d14:      	add	x0, sp, #0x40
     d18:      	ldp	x9, x10, [x8]
     d1c:      	mov	w1, #0x1d               // =29
     d20:      	stp	x9, x10, [sp, #0x40]
     d24:      	ldr	x9, [x8, #0x10]
     d28:      	ldur	x8, [x8, #0x15]
     d2c:      	add	x10, sp, #0x40
     d30:      	str	x9, [sp, #0x50]
     d34:      	stur	x8, [sp, #0x55]
     d38:      	mov	w8, #0x1d               // =29
     d3c:      	mov	w9, #0x6                // =6
     d40:      	blr	x9
     d44:      	b	0xab8 <perf_unwind_stop+0xab8>
     d48:      	adrp	x8, 0x0 <perf_unwind_stop>
     d4c:      	add	x8, x8, #0x0
     d50:      	add	x0, sp, #0x40
     d54:      	ldp	x9, x10, [x8, #0x10]
     d58:      	mov	w1, #0x25               // =37
     d5c:      	stp	x9, x10, [sp, #0x50]
     d60:      	ldur	x9, [x8, #0x1d]
     d64:      	add	x10, sp, #0x40
     d68:      	stur	x9, [sp, #0x5d]
     d6c:      	ldp	x8, x9, [x8]
     d70:      	stp	x8, x9, [sp, #0x40]
     d74:      	mov	w8, #0x25               // =37
     d78:      	mov	w9, #0x6                // =6
     d7c:      	blr	x9
     d80:      	b	0x504 <perf_unwind_stop+0x504>
     d84:      	adrp	x8, 0x0 <perf_unwind_stop>
     d88:      	add	x8, x8, #0x0
     d8c:      	add	x0, sp, #0x40
     d90:      	ldp	x9, x10, [x8, #0x10]
     d94:      	mov	w1, #0x2e               // =46
     d98:      	stp	x9, x10, [sp, #0x50]
     d9c:      	ldr	x9, [x8, #0x20]
     da0:      	add	x10, sp, #0x40
     da4:      	str	x9, [sp, #0x60]
     da8:      	ldur	x9, [x8, #0x26]
     dac:      	stur	x9, [sp, #0x66]
     db0:      	ldp	x9, x8, [x8]
     db4:      	stp	x9, x8, [sp, #0x40]
     db8:      	mov	w8, #0x2e               // =46
     dbc:      	mov	w9, #0x6                // =6
     dc0:      	ldr	w2, [sp, #0x10]
     dc4:      	blr	x9
     dc8:      	ldr	w8, [x20, #0x2c0]
     dcc:      	cmp	w8, #0x1
     dd0:      	b.eq	0xa4c <perf_unwind_stop+0xa4c>
     dd4:      	b	0xa54 <perf_unwind_stop+0xa54>
     dd8:      	mov	w8, #0xa                // =10
     ddc:      	add	x0, sp, #0x40
     de0:      	mov	w1, #0x22               // =34
     de4:      	strh	w8, [sp, #0x60]
     de8:      	adrp	x8, 0x0 <perf_unwind_stop>
     dec:      	add	x8, x8, #0x0
     df0:      	ldp	x9, x10, [x8]
     df4:      	stp	x9, x10, [sp, #0x40]
     df8:      	ldp	x9, x8, [x8, #0x10]
     dfc:      	add	x10, sp, #0x40
     e00:      	stp	x9, x8, [sp, #0x50]
     e04:      	mov	w8, #0x22               // =34
     e08:      	mov	w9, #0x6                // =6
     e0c:      	ldr	x8, [sp, #0x98]
     e10:      	ldr	x10, [x23]
     e14:      	add	x2, x10, x8
     e18:      	blr	x9
     e1c:      	b	0xfc <perf_unwind_stop+0xfc>
     e20:      	mov	w8, #0xa                // =10
     e24:      	add	x0, sp, #0x40
     e28:      	mov	w1, #0x2a               // =42
     e2c:      	strh	w8, [sp, #0x68]
     e30:      	adrp	x8, 0x0 <perf_unwind_stop>
     e34:      	add	x8, x8, #0x0
     e38:      	ldp	x9, x10, [x8, #0x10]
     e3c:      	stp	x9, x10, [sp, #0x50]
     e40:      	ldr	x9, [x8, #0x20]
     e44:      	add	x10, sp, #0x40
     e48:      	str	x9, [sp, #0x60]
     e4c:      	ldp	x8, x9, [x8]
     e50:      	stp	x8, x9, [sp, #0x40]
     e54:      	mov	w8, #0x2a               // =42
     e58:      	mov	w9, #0x6                // =6
     e5c:      	ldr	x2, [sp, #0x98]
     e60:      	ldr	w3, [x23, #0x18]
     e64:      	blr	x9
     e68:      	ldrsw	x8, [x23, #0x18]
     e6c:      	cbnz	w8, 0xb8c <perf_unwind_stop+0xb8c>
     e70:      	ldr	x9, [x20, #0xef8]
     e74:      	str	x9, [sp, #0x10]
     e78:      	cbz	x9, 0xb8c <perf_unwind_stop+0xb8c>
     e7c:      	ldr	w8, [x29]
     e80:      	cbnz	w8, 0x1190 <perf_unwind_stop+0x1190>
     e84:      	ldr	x8, [sp, #0x10]
     e88:      	ldr	w9, [x23]
     e8c:      	mov	w10, #0x70              // =112
     e90:      	add	x11, sp, #0x88
     e94:      	add	x0, sp, #0x88
     e98:      	mov	w1, #0x8                // =8
     e9c:      	add	x8, x8, x9
     ea0:      	mov	w9, #0x8                // =8
     ea4:      	ldr	x8, [sp, #0x10]
     ea8:      	ldr	w9, [x23]
     eac:      	add	x2, x8, x9
     eb0:      	blr	x10
     eb4:      	ldr	w8, [x29]
     eb8:      	cbz	x0, 0xef4 <perf_unwind_stop+0xef4>
     ebc:      	cbz	w8, 0x1004 <perf_unwind_stop+0x1004>
     ec0:      	adrp	x8, 0x0 <perf_unwind_stop>
     ec4:      	add	x8, x8, #0x0
     ec8:      	add	x0, sp, #0x40
     ecc:      	ldp	x9, x10, [x8]
     ed0:      	ldur	x8, [x8, #0xf]
     ed4:      	mov	w1, #0x17               // =23
     ed8:      	stp	x9, x10, [sp, #0x40]
     edc:      	stur	x8, [sp, #0x4f]
     ee0:      	mov	w8, #0x17               // =23
     ee4:      	mov	w9, #0x6                // =6
     ee8:      	add	x10, sp, #0x40
     eec:      	blr	x9
     ef0:      	b	0x1004 <perf_unwind_stop+0x1004>
     ef4:      	cbnz	w8, 0x12a0 <perf_unwind_stop+0x12a0>
     ef8:      	ldr	x8, [sp, #0x88]
     efc:      	cbz	x8, 0x1004 <perf_unwind_stop+0x1004>
     f00:      	str	x8, [x20, #0xf68]
     f04:      	ldr	w8, [x29]
     f08:      	cbnz	w8, 0x12e0 <perf_unwind_stop+0x12e0>
     f0c:      	mov	w8, #0x60               // =96
     f10:      	add	x9, sp, #0x10
     f14:      	add	x1, sp, #0x10
     f18:      	str	w8, [sp, #0x10]
     f1c:      	mov	w8, #0x1                // =1
     f20:      	mov	x0, x21
     f24:      	blr	x8
     f28:      	cbz	x0, 0xf3c <perf_unwind_stop+0xf3c>
     f2c:      	ldr	x8, [x0]
     f30:      	add	x8, x8, #0x1
     f34:      	str	x8, [x0]
     f38:      	b	0xf44 <perf_unwind_stop+0xf44>
     f3c:      	ldr	w8, [x29]
     f40:      	cbnz	w8, 0x1410 <perf_unwind_stop+0x1410>
     f44:      	str	wzr, [sp, #0x40]
     f48:      	mov	w8, #0x1                // =1
     f4c:      	add	x9, sp, #0x40
     f50:      	add	x1, sp, #0x40
     f54:      	mov	x0, x25
     f58:      	blr	x8
     f5c:      	cbz	x0, 0xfac <perf_unwind_stop+0xfac>
     f60:      	mov	w22, #0x1374            // =4980
     f64:      	ldrb	w8, [x0, x22]
     f68:      	cmp	w8, #0x1d
     f6c:      	b.lo	0xfc8 <perf_unwind_stop+0xfc8>
     f70:      	mov	w8, #0x5                // =5
     f74:      	add	x9, sp, #0x10
     f78:      	mov	x19, x0
     f7c:      	str	w8, [x0, #0xf1c]
     f80:      	mov	w8, #0x44               // =68
     f84:      	add	x1, sp, #0x10
     f88:      	mov	x0, x21
     f8c:      	str	w8, [sp, #0x10]
     f90:      	mov	w8, #0x1                // =1
     f94:      	blr	x8
     f98:      	cbz	x0, 0xfd0 <perf_unwind_stop+0xfd0>
     f9c:      	ldr	x8, [x0]
     fa0:      	add	x8, x8, #0x1
     fa4:      	str	x8, [x0]
     fa8:      	b	0xfd8 <perf_unwind_stop+0xfd8>
     fac:      	adrp	x1, 0x0 <perf_unwind_stop>
     fb0:      	mov	x8, xzr
     fb4:      	mov	w9, #0xc                // =12
     fb8:      	ldr	x1, [x1]
     fbc:      	mov	x0, x24
     fc0:      	mov	w2, wzr
     fc4:      	b	0x1000 <perf_unwind_stop+0x1000>
     fc8:      	mov	w2, #0x9                // =9
     fcc:      	b	0xfe4 <perf_unwind_stop+0xfe4>
     fd0:      	ldr	w8, [x29]
     fd4:      	cbnz	w8, 0x1458 <perf_unwind_stop+0x1458>
     fd8:      	ldrb	w8, [x19, x22]
     fdc:      	mov	w2, wzr
     fe0:      	mov	x0, x19
     fe4:      	add	w8, w8, #0x1
     fe8:      	adrp	x1, 0x0 <perf_unwind_stop>
     fec:      	mov	w9, #0xc                // =12
     ff0:      	strb	w8, [x0, x22]
     ff4:      	mov	w8, w2
     ff8:      	mov	x0, x24
     ffc:      	ldr	x1, [x1]
    1000:      	blr	x9
    1004:      	ldr	w8, [x20, #0x2c0]
    1008:      	mov	w9, #0x80               // =128
    100c:      	mov	x10, #0xed0             // =3792
    1010:      	sub	w8, w9, w8
    1014:      	mov	x9, #-0x18              // =-24
    1018:      	madd	x4, x8, x9, x10
    101c:      	cmp	x4, #0xed0
    1020:      	b.hi	0x1044 <perf_unwind_stop+0x1044>
    1024:      	adrp	x1, 0x1000 <perf_unwind_stop+0x1000>
    1028:      	mov	w8, #-0x1               // =-1
    102c:      	mov	w9, #0x19               // =25
    1030:      	ldr	x1, [x1]
    1034:      	mov	x0, x24
    1038:      	mov	w2, #-0x1               // =-1
    103c:      	mov	x3, x20
    1040:      	blr	x9
    1044:      	mov	w0, wzr
    1048:      	ldp	x20, x19, [sp, #0xd0]
    104c:      	ldr	x29, [sp, #0x90]
    1050:      	ldp	x22, x21, [sp, #0xc0]
    1054:      	ldp	x24, x23, [sp, #0xb0]
    1058:      	ldp	x30, x25, [sp, #0xa0]
    105c:      	add	sp, sp, #0xe0
    1060:      	ret
    1064:      	adrp	x8, 0x1000 <perf_unwind_stop+0x1000>
    1068:      	add	x8, x8, #0x0
    106c:      	add	x0, sp, #0x40
    1070:      	ldp	x9, x10, [x8, #0x10]
    1074:      	mov	w1, #0x2e               // =46
    1078:      	stp	x9, x10, [sp, #0x50]
    107c:      	ldr	x9, [x8, #0x20]
    1080:      	add	x10, sp, #0x40
    1084:      	str	x9, [sp, #0x60]
    1088:      	ldur	x9, [x8, #0x26]
    108c:      	stur	x9, [sp, #0x66]
    1090:      	ldp	x9, x8, [x8]
    1094:      	stp	x9, x8, [sp, #0x40]
    1098:      	mov	w8, #0x2e               // =46
    109c:      	mov	w9, #0x6                // =6
    10a0:      	ldr	w2, [sp, #0x10]
    10a4:      	blr	x9
    10a8:      	b	0x1b0 <perf_unwind_stop+0x1b0>
    10ac:      	adrp	x8, 0x1000 <perf_unwind_stop+0x1000>
    10b0:      	add	x8, x8, #0x0
    10b4:      	and	w3, w24, #0xff
    10b8:      	ldp	x9, x10, [x8]
    10bc:      	mov	w1, #0x1f               // =31
    10c0:      	stp	x9, x10, [sp, #0x40]
    10c4:      	ldr	x9, [x8, #0x10]
    10c8:      	ldur	x8, [x8, #0x17]
    10cc:      	add	x10, sp, #0x40
    10d0:      	str	x9, [sp, #0x50]
    10d4:      	stur	x8, [sp, #0x57]
    10d8:      	mov	w8, #0x1f               // =31
    10dc:      	mov	w9, #0x6                // =6
    10e0:      	str	x0, [sp, #0x8]
    10e4:      	add	x0, sp, #0x40
    10e8:      	ldr	w2, [sp, #0x84]
    10ec:      	blr	x9
    10f0:      	ldr	x0, [sp, #0x8]
    10f4:      	b	0x750 <perf_unwind_stop+0x750>
    10f8:      	mov	w8, #0x7974             // =31092
    10fc:      	add	x0, sp, #0x40
    1100:      	mov	w1, #0x2b               // =43
    1104:      	movk	w8, #0xa, lsl #16
    1108:      	stur	w8, [sp, #0x67]
    110c:      	adrp	x8, 0x1000 <perf_unwind_stop+0x1000>
    1110:      	add	x8, x8, #0x0
    1114:      	ldp	x9, x10, [x8, #0x10]
    1118:      	stp	x9, x10, [sp, #0x50]
    111c:      	ldr	x9, [x8, #0x20]
    1120:      	add	x10, sp, #0x40
    1124:      	str	x9, [sp, #0x60]
    1128:      	ldp	x8, x9, [x8]
    112c:      	stp	x8, x9, [sp, #0x40]
    1130:      	mov	w8, #0x2b               // =43
    1134:      	mov	w9, #0x6                // =6
    1138:      	blr	x9
    113c:      	b	0x490 <perf_unwind_stop+0x490>
    1140:      	adrp	x8, 0x1000 <perf_unwind_stop+0x1000>
    1144:      	add	x8, x8, #0x0
    1148:      	ldr	w3, [sp, #0x98]
    114c:      	mov	w4, w0
    1150:      	ldp	x9, x10, [x8, #0x20]
    1154:      	add	x0, sp, #0x40
    1158:      	mov	w1, #0x35               // =53
    115c:      	stp	x9, x10, [sp, #0x60]
    1160:      	ldur	x9, [x8, #0x2d]
    1164:      	stur	x9, [sp, #0x6d]
    1168:      	ldp	x9, x10, [x8]
    116c:      	stp	x9, x10, [sp, #0x40]
    1170:      	ldp	x8, x9, [x8, #0x10]
    1174:      	add	x10, sp, #0x40
    1178:      	stp	x8, x9, [sp, #0x50]
    117c:      	mov	w8, #0x35               // =53
    1180:      	mov	w9, #0x6                // =6
    1184:      	ldr	w2, [sp, #0x3c]
    1188:      	blr	x9
    118c:      	b	0x858 <perf_unwind_stop+0x858>
    1190:      	adrp	x8, 0x1000 <perf_unwind_stop+0x1000>
    1194:      	add	x8, x8, #0x0
    1198:      	add	x0, sp, #0x40
    119c:      	ldp	x9, x10, [x8, #0x10]
    11a0:      	mov	w1, #0x28               // =40
    11a4:      	stp	x9, x10, [sp, #0x50]
    11a8:      	ldr	x9, [x8, #0x20]
    11ac:      	add	x10, sp, #0x40
    11b0:      	str	x9, [sp, #0x60]
    11b4:      	ldp	x8, x9, [x8]
    11b8:      	stp	x8, x9, [sp, #0x40]
    11bc:      	mov	w8, #0x28               // =40
    11c0:      	mov	w9, #0x6                // =6
    11c4:      	ldr	x2, [sp, #0x10]
    11c8:      	ldr	w3, [x23]
    11cc:      	blr	x9
    11d0:      	b	0xe84 <perf_unwind_stop+0xe84>
    11d4:      	adrp	x8, 0x1000 <perf_unwind_stop+0x1000>
    11d8:      	add	x8, x8, #0x0
    11dc:      	mov	w3, w0
    11e0:      	ldp	x9, x10, [x8]
    11e4:      	add	x0, sp, #0x40
    11e8:      	mov	w1, #0x1d               // =29
    11ec:      	stp	x9, x10, [sp, #0x40]
    11f0:      	ldr	x9, [x8, #0x10]
    11f4:      	ldur	x8, [x8, #0x15]
    11f8:      	add	x10, sp, #0x40
    11fc:      	str	x9, [sp, #0x50]
    1200:      	stur	x8, [sp, #0x55]
    1204:      	mov	w8, #0x1d               // =29
    1208:      	mov	w9, #0x6                // =6
    120c:      	ldr	w2, [sp, #0x84]
    1210:      	blr	x9
    1214:      	b	0x7a0 <perf_unwind_stop+0x7a0>
    1218:      	adrp	x8, 0x1000 <perf_unwind_stop+0x1000>
    121c:      	add	x8, x8, #0x0
    1220:      	add	x0, sp, #0x40
    1224:      	ldp	x9, x10, [x8]
    1228:      	mov	w1, #0x20               // =32
    122c:      	stp	x9, x10, [sp, #0x40]
    1230:      	ldp	x9, x8, [x8, #0x10]
    1234:      	add	x10, sp, #0x40
    1238:      	stp	x9, x8, [sp, #0x50]
    123c:      	mov	w8, #0x20               // =32
    1240:      	mov	w9, #0x6                // =6
    1244:      	ldr	w2, [sp, #0x84]
    1248:      	blr	x9
    124c:      	b	0x6f0 <perf_unwind_stop+0x6f0>
    1250:      	adrp	x8, 0x1000 <perf_unwind_stop+0x1000>
    1254:      	add	x8, x8, #0x0
    1258:      	add	x0, sp, #0x40
    125c:      	ldp	x9, x10, [x8, #0x10]
    1260:      	mov	w1, #0x2e               // =46
    1264:      	stp	x9, x10, [sp, #0x50]
    1268:      	ldr	x9, [x8, #0x20]
    126c:      	add	x10, sp, #0x40
    1270:      	str	x9, [sp, #0x60]
    1274:      	ldur	x9, [x8, #0x26]
    1278:      	stur	x9, [sp, #0x66]
    127c:      	ldp	x9, x8, [x8]
    1280:      	stp	x9, x8, [sp, #0x40]
    1284:      	mov	w8, #0x2e               // =46
    1288:      	mov	w9, #0x6                // =6
    128c:      	ldr	w2, [sp, #0x10]
    1290:      	blr	x9
    1294:      	ldr	w8, [x20, #0xf1c]
    1298:      	cbnz	w8, 0x4e0 <perf_unwind_stop+0x4e0>
    129c:      	b	0x4d8 <perf_unwind_stop+0x4d8>
    12a0:      	adrp	x8, 0x1000 <perf_unwind_stop+0x1000>
    12a4:      	add	x8, x8, #0x0
    12a8:      	add	x0, sp, #0x40
    12ac:      	ldp	x9, x10, [x8]
    12b0:      	ldur	x8, [x8, #0xe]
    12b4:      	mov	w1, #0x16               // =22
    12b8:      	stp	x9, x10, [sp, #0x40]
    12bc:      	stur	x8, [sp, #0x4e]
    12c0:      	mov	w8, #0x16               // =22
    12c4:      	mov	w9, #0x6                // =6
    12c8:      	add	x10, sp, #0x40
    12cc:      	ldr	x2, [sp, #0x88]
    12d0:      	blr	x9
    12d4:      	ldr	x8, [sp, #0x88]
    12d8:      	cbnz	x8, 0xf00 <perf_unwind_stop+0xf00>
    12dc:      	b	0x1004 <perf_unwind_stop+0x1004>
    12e0:      	adrp	x8, 0x1000 <perf_unwind_stop+0x1000>
    12e4:      	add	x8, x8, #0x0
    12e8:      	add	x0, sp, #0x40
    12ec:      	ldp	x9, x10, [x8, #0x20]
    12f0:      	mov	w1, #0x3d               // =61
    12f4:      	stp	x9, x10, [sp, #0x60]
    12f8:      	ldr	x9, [x8, #0x30]
    12fc:      	str	x9, [sp, #0x70]
    1300:      	ldur	x9, [x8, #0x35]
    1304:      	stur	x9, [sp, #0x75]
    1308:      	ldp	x9, x10, [x8]
    130c:      	stp	x9, x10, [sp, #0x40]
    1310:      	add	x10, sp, #0x40
    1314:      	ldp	x9, x8, [x8, #0x10]
    1318:      	stp	x9, x8, [sp, #0x50]
    131c:      	mov	w8, #0x3d               // =61
    1320:      	mov	w9, #0x6                // =6
    1324:      	blr	x9
    1328:      	b	0xf0c <perf_unwind_stop+0xf0c>
    132c:      	adrp	x8, 0x1000 <perf_unwind_stop+0x1000>
    1330:      	add	x8, x8, #0x0
    1334:      	mov	w3, w0
    1338:      	ldp	x9, x10, [x8, #0x20]
    133c:      	add	x0, sp, #0x40
    1340:      	mov	w1, #0x36               // =54
    1344:      	mov	w2, #0x1                // =1
    1348:      	stp	x9, x10, [sp, #0x60]
    134c:      	ldur	x9, [x8, #0x2e]
    1350:      	stur	x9, [sp, #0x6e]
    1354:      	ldp	x9, x10, [x8]
    1358:      	stp	x9, x10, [sp, #0x40]
    135c:      	ldp	x8, x9, [x8, #0x10]
    1360:      	add	x10, sp, #0x40
    1364:      	stp	x8, x9, [sp, #0x50]
    1368:      	mov	w8, #0x36               // =54
    136c:      	mov	w9, #0x6                // =6
    1370:      	blr	x9
    1374:      	b	0x9d0 <perf_unwind_stop+0x9d0>
    1378:      	adrp	x8, 0x1000 <perf_unwind_stop+0x1000>
    137c:      	add	x8, x8, #0x0
    1380:      	add	x0, sp, #0x40
    1384:      	ldp	x9, x10, [x8, #0x10]
    1388:      	mov	w1, #0x2e               // =46
    138c:      	stp	x9, x10, [sp, #0x50]
    1390:      	ldr	x9, [x8, #0x20]
    1394:      	add	x10, sp, #0x40
    1398:      	str	x9, [sp, #0x60]
    139c:      	ldur	x9, [x8, #0x26]
    13a0:      	stur	x9, [sp, #0x66]
    13a4:      	ldp	x9, x8, [x8]
    13a8:      	stp	x9, x8, [sp, #0x40]
    13ac:      	mov	w8, #0x2e               // =46
    13b0:      	mov	w9, #0x6                // =6
    13b4:      	ldr	w2, [sp, #0x10]
    13b8:      	blr	x9
    13bc:      	b	0x990 <perf_unwind_stop+0x990>
    13c0:      	adrp	x8, 0x1000 <perf_unwind_stop+0x1000>
    13c4:      	add	x8, x8, #0x0
    13c8:      	add	x0, sp, #0x40
    13cc:      	ldp	x9, x10, [x8, #0x10]
    13d0:      	mov	w1, #0x2e               // =46
    13d4:      	stp	x9, x10, [sp, #0x50]
    13d8:      	ldr	x9, [x8, #0x20]
    13dc:      	add	x10, sp, #0x40
    13e0:      	str	x9, [sp, #0x60]
    13e4:      	ldur	x9, [x8, #0x26]
    13e8:      	stur	x9, [sp, #0x66]
    13ec:      	ldp	x9, x8, [x8]
    13f0:      	stp	x9, x8, [sp, #0x40]
    13f4:      	mov	w8, #0x2e               // =46
    13f8:      	mov	w9, #0x6                // =6
    13fc:      	ldr	w2, [sp, #0x84]
    1400:      	blr	x9
    1404:      	ldr	w8, [x29]
    1408:      	cbz	w8, 0x478 <perf_unwind_stop+0x478>
    140c:      	b	0x3c8 <perf_unwind_stop+0x3c8>
    1410:      	adrp	x8, 0x1000 <perf_unwind_stop+0x1000>
    1414:      	add	x8, x8, #0x0
    1418:      	add	x0, sp, #0x40
    141c:      	ldp	x9, x10, [x8, #0x10]
    1420:      	mov	w1, #0x2e               // =46
    1424:      	stp	x9, x10, [sp, #0x50]
    1428:      	ldr	x9, [x8, #0x20]
    142c:      	add	x10, sp, #0x40
    1430:      	str	x9, [sp, #0x60]
    1434:      	ldur	x9, [x8, #0x26]
    1438:      	stur	x9, [sp, #0x66]
    143c:      	ldp	x9, x8, [x8]
    1440:      	stp	x9, x8, [sp, #0x40]
    1444:      	mov	w8, #0x2e               // =46
    1448:      	mov	w9, #0x6                // =6
    144c:      	ldr	w2, [sp, #0x10]
    1450:      	blr	x9
    1454:      	b	0xf44 <perf_unwind_stop+0xf44>
    1458:      	adrp	x8, 0x1000 <perf_unwind_stop+0x1000>
    145c:      	add	x8, x8, #0x0
    1460:      	add	x0, sp, #0x40
    1464:      	ldp	x9, x10, [x8, #0x10]
    1468:      	mov	w1, #0x2e               // =46
    146c:      	stp	x9, x10, [sp, #0x50]
    1470:      	ldr	x9, [x8, #0x20]
    1474:      	add	x10, sp, #0x40
    1478:      	str	x9, [sp, #0x60]
    147c:      	ldur	x9, [x8, #0x26]
    1480:      	stur	x9, [sp, #0x66]
    1484:      	ldp	x9, x8, [x8]
    1488:      	stp	x9, x8, [sp, #0x40]
    148c:      	mov	w8, #0x2e               // =46
    1490:      	mov	w9, #0x6                // =6
    1494:      	ldr	w2, [sp, #0x10]
    1498:      	blr	x9
    149c:      	b	0xfd8 <perf_unwind_stop+0xfd8>

Disassembly of section kprobe/unwind_stop:

0000000000000000 <kprobe_unwind_stop>:
       0:      	sub	sp, sp, #0xe0
       4:      	str	x29, [sp, #0x90]
       8:      	stp	x30, x25, [sp, #0xa0]
       c:      	stp	x24, x23, [sp, #0xb0]
      10:      	stp	x22, x21, [sp, #0xc0]
      14:      	stp	x20, x19, [sp, #0xd0]
      18:      	str	wzr, [sp, #0x40]
      1c:      	adrp	x25, 0x0 <kprobe_unwind_stop>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x40
      28:      	ldr	x25, [x25]
      2c:      	mov	x24, x0
      30:      	add	x1, sp, #0x40
      34:      	mov	x0, x25
      38:      	blr	x8
      3c:      	cbz	x0, 0xf0 <kprobe_unwind_stop+0xf0>
      40:      	ldr	w8, [x0]
      44:      	mov	x20, x0
      48:      	adrp	x0, 0x0 <kprobe_unwind_stop>
      4c:      	add	x9, sp, #0x3c
      50:      	str	w8, [sp, #0x3c]
      54:      	mov	w8, #0x1                // =1
      58:      	add	x1, sp, #0x3c
      5c:      	ldr	x0, [x0]
      60:      	blr	x8
      64:      	adrp	x29, 0x0 <kprobe_unwind_stop>
      68:      	adrp	x21, 0x0 <kprobe_unwind_stop>
      6c:      	adrp	x22, 0x0 <kprobe_unwind_stop>
      70:      	ldr	x29, [x29]
      74:      	ldr	x21, [x21]
      78:      	ldr	x22, [x22]
      7c:      	cbz	x0, 0x478 <kprobe_unwind_stop+0x478>
      80:      	ldr	w8, [x29]
      84:      	mov	x23, x0
      88:      	cbnz	w8, 0x584 <kprobe_unwind_stop+0x584>
      8c:      	mov	w8, #0x23               // =35
      90:      	blr	x8
      94:      	ldr	x8, [x22]
      98:      	mov	w9, #0x71               // =113
      9c:      	add	x10, sp, #0x98
      a0:      	mov	w1, #0x8                // =8
      a4:      	add	x2, x0, x8
      a8:      	mov	w8, #0x8                // =8
      ac:      	add	x0, sp, #0x98
      b0:      	blr	x9
      b4:      	ldr	w8, [x29]
      b8:      	cbz	x0, 0xf8 <kprobe_unwind_stop+0xf8>
      bc:      	cbnz	w8, 0xcd0 <kprobe_unwind_stop+0xcd0>
      c0:      	mov	w8, #0x4                // =4
      c4:      	add	x9, sp, #0x10
      c8:      	add	x1, sp, #0x10
      cc:      	str	w8, [sp, #0x10]
      d0:      	mov	w8, #0x1                // =1
      d4:      	mov	x0, x21
      d8:      	blr	x8
      dc:      	cbz	x0, 0x1a8 <kprobe_unwind_stop+0x1a8>
      e0:      	ldr	x8, [x0]
      e4:      	add	x8, x8, #0x1
      e8:      	str	x8, [x0]
      ec:      	b	0x1b0 <kprobe_unwind_stop+0x1b0>
      f0:      	mov	w0, #-0x1               // =-1
      f4:      	b	0x1048 <kprobe_unwind_stop+0x1048>
      f8:      	cbnz	w8, 0xdd8 <kprobe_unwind_stop+0xdd8>
      fc:      	ldr	x8, [sp, #0x98]
     100:      	ldr	x9, [x23]
     104:      	mov	w10, #0x70              // =112
     108:      	add	x11, sp, #0x88
     10c:      	add	x0, sp, #0x88
     110:      	mov	w1, #0x8                // =8
     114:      	add	x8, x9, x8
     118:      	mov	w9, #0x8                // =8
     11c:      	ldr	x8, [sp, #0x98]
     120:      	ldr	x9, [x23]
     124:      	add	x2, x9, x8
     128:      	blr	x10
     12c:      	cbz	x0, 0x284 <kprobe_unwind_stop+0x284>
     130:      	mov	w8, #0x57               // =87
     134:      	add	x9, sp, #0x10
     138:      	add	x1, sp, #0x10
     13c:      	str	w8, [sp, #0x10]
     140:      	mov	w8, #0x1                // =1
     144:      	mov	x0, x21
     148:      	blr	x8
     14c:      	cbz	x0, 0x318 <kprobe_unwind_stop+0x318>
     150:      	ldr	x8, [x0]
     154:      	add	x8, x8, #0x1
     158:      	str	x8, [x0]
     15c:      	ldr	w8, [x29]
     160:      	cbz	w8, 0x478 <kprobe_unwind_stop+0x478>
     164:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     168:      	add	x8, x8, #0x0
     16c:      	add	x0, sp, #0x40
     170:      	ldp	x9, x10, [x8, #0x10]
     174:      	mov	w1, #0x2f               // =47
     178:      	stp	x9, x10, [sp, #0x50]
     17c:      	ldr	x9, [x8, #0x20]
     180:      	add	x10, sp, #0x40
     184:      	str	x9, [sp, #0x60]
     188:      	ldur	x9, [x8, #0x27]
     18c:      	stur	x9, [sp, #0x67]
     190:      	ldp	x9, x8, [x8]
     194:      	stp	x9, x8, [sp, #0x40]
     198:      	mov	w8, #0x2f               // =47
     19c:      	mov	w9, #0x6                // =6
     1a0:      	blr	x9
     1a4:      	b	0x478 <kprobe_unwind_stop+0x478>
     1a8:      	ldr	w8, [x29]
     1ac:      	cbnz	w8, 0x1064 <kprobe_unwind_stop+0x1064>
     1b0:      	mov	w8, #0x56               // =86
     1b4:      	add	x9, sp, #0x10
     1b8:      	add	x1, sp, #0x10
     1bc:      	str	w8, [sp, #0x10]
     1c0:      	mov	w8, #0x1                // =1
     1c4:      	mov	x0, x21
     1c8:      	blr	x8
     1cc:      	cbz	x0, 0x22c <kprobe_unwind_stop+0x22c>
     1d0:      	ldr	x8, [x0]
     1d4:      	add	x8, x8, #0x1
     1d8:      	str	x8, [x0]
     1dc:      	ldr	w8, [x29]
     1e0:      	cbz	w8, 0x478 <kprobe_unwind_stop+0x478>
     1e4:      	mov	w8, #0x6e6f             // =28271
     1e8:      	add	x0, sp, #0x40
     1ec:      	mov	w1, #0x2c               // =44
     1f0:      	movk	w8, #0xa, lsl #16
     1f4:      	str	w8, [sp, #0x68]
     1f8:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     1fc:      	add	x8, x8, #0x0
     200:      	ldp	x9, x10, [x8, #0x10]
     204:      	stp	x9, x10, [sp, #0x50]
     208:      	ldr	x9, [x8, #0x20]
     20c:      	add	x10, sp, #0x40
     210:      	str	x9, [sp, #0x60]
     214:      	ldp	x8, x9, [x8]
     218:      	stp	x8, x9, [sp, #0x40]
     21c:      	mov	w8, #0x2c               // =44
     220:      	mov	w9, #0x6                // =6
     224:      	blr	x9
     228:      	b	0x478 <kprobe_unwind_stop+0x478>
     22c:      	ldr	w8, [x29]
     230:      	cbz	w8, 0x478 <kprobe_unwind_stop+0x478>
     234:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     238:      	add	x8, x8, #0x0
     23c:      	add	x0, sp, #0x40
     240:      	ldp	x9, x10, [x8, #0x10]
     244:      	mov	w1, #0x2e               // =46
     248:      	stp	x9, x10, [sp, #0x50]
     24c:      	ldr	x9, [x8, #0x20]
     250:      	add	x10, sp, #0x40
     254:      	str	x9, [sp, #0x60]
     258:      	ldur	x9, [x8, #0x26]
     25c:      	stur	x9, [sp, #0x66]
     260:      	ldp	x9, x8, [x8]
     264:      	stp	x9, x8, [sp, #0x40]
     268:      	mov	w8, #0x2e               // =46
     26c:      	mov	w9, #0x6                // =6
     270:      	ldr	w2, [sp, #0x10]
     274:      	blr	x9
     278:      	ldr	w8, [x29]
     27c:      	cbz	w8, 0x478 <kprobe_unwind_stop+0x478>
     280:      	b	0x1e4 <kprobe_unwind_stop+0x1e4>
     284:      	ldr	x8, [sp, #0x88]
     288:      	mov	w9, #0x25               // =37
     28c:      	mov	w10, #0x70              // =112
     290:      	add	x11, sp, #0x10
     294:      	ldr	x2, [sp, #0x88]
     298:      	add	x0, sp, #0x10
     29c:      	mov	w1, #0x25               // =37
     2a0:      	blr	x10
     2a4:      	cbz	x0, 0x370 <kprobe_unwind_stop+0x370>
     2a8:      	mov	w8, #0x58               // =88
     2ac:      	add	x9, sp, #0x84
     2b0:      	add	x1, sp, #0x84
     2b4:      	str	w8, [sp, #0x84]
     2b8:      	mov	w8, #0x1                // =1
     2bc:      	mov	x0, x21
     2c0:      	blr	x8
     2c4:      	cbz	x0, 0x418 <kprobe_unwind_stop+0x418>
     2c8:      	ldr	x8, [x0]
     2cc:      	add	x8, x8, #0x1
     2d0:      	str	x8, [x0]
     2d4:      	ldr	w8, [x29]
     2d8:      	cbz	w8, 0x478 <kprobe_unwind_stop+0x478>
     2dc:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     2e0:      	add	x8, x8, #0x0
     2e4:      	add	x0, sp, #0x40
     2e8:      	ldp	x9, x10, [x8, #0x10]
     2ec:      	mov	w1, #0x27               // =39
     2f0:      	stp	x9, x10, [sp, #0x50]
     2f4:      	ldur	x9, [x8, #0x1f]
     2f8:      	add	x10, sp, #0x40
     2fc:      	stur	x9, [sp, #0x5f]
     300:      	ldp	x8, x9, [x8]
     304:      	stp	x8, x9, [sp, #0x40]
     308:      	mov	w8, #0x27               // =39
     30c:      	mov	w9, #0x6                // =6
     310:      	blr	x9
     314:      	b	0x478 <kprobe_unwind_stop+0x478>
     318:      	ldr	w8, [x29]
     31c:      	cbz	w8, 0x478 <kprobe_unwind_stop+0x478>
     320:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     324:      	add	x8, x8, #0x0
     328:      	add	x0, sp, #0x40
     32c:      	ldp	x9, x10, [x8, #0x10]
     330:      	mov	w1, #0x2e               // =46
     334:      	stp	x9, x10, [sp, #0x50]
     338:      	ldr	x9, [x8, #0x20]
     33c:      	add	x10, sp, #0x40
     340:      	str	x9, [sp, #0x60]
     344:      	ldur	x9, [x8, #0x26]
     348:      	stur	x9, [sp, #0x66]
     34c:      	ldp	x9, x8, [x8]
     350:      	stp	x9, x8, [sp, #0x40]
     354:      	mov	w8, #0x2e               // =46
     358:      	mov	w9, #0x6                // =6
     35c:      	ldr	w2, [sp, #0x10]
     360:      	blr	x9
     364:      	ldr	w8, [x29]
     368:      	cbz	w8, 0x478 <kprobe_unwind_stop+0x478>
     36c:      	b	0x164 <kprobe_unwind_stop+0x164>
     370:      	ldrb	w8, [sp, #0x13]
     374:      	cbz	w8, 0x394 <kprobe_unwind_stop+0x394>
     378:      	ldrb	w8, [sp, #0x12]
     37c:      	cbz	w8, 0x394 <kprobe_unwind_stop+0x394>
     380:      	ldur	x10, [sp, #0x1d]
     384:      	ldur	x8, [sp, #0x15]
     388:      	ldur	x9, [sp, #0x2d]
     38c:      	str	x9, [x20, #0x20]
     390:      	stp	x8, x10, [x20, #0x28]
     394:      	mov	w8, #0x59               // =89
     398:      	add	x9, sp, #0x84
     39c:      	add	x1, sp, #0x84
     3a0:      	str	w8, [sp, #0x84]
     3a4:      	mov	w8, #0x1                // =1
     3a8:      	mov	x0, x21
     3ac:      	blr	x8
     3b0:      	cbz	x0, 0x470 <kprobe_unwind_stop+0x470>
     3b4:      	ldr	x8, [x0]
     3b8:      	add	x8, x8, #0x1
     3bc:      	str	x8, [x0]
     3c0:      	ldr	w8, [x29]
     3c4:      	cbz	w8, 0x478 <kprobe_unwind_stop+0x478>
     3c8:      	mov	w8, #0x5832             // =22578
     3cc:      	add	x0, sp, #0x40
     3d0:      	mov	w1, #0x2c               // =44
     3d4:      	movk	w8, #0xa, lsl #16
     3d8:      	str	w8, [sp, #0x68]
     3dc:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     3e0:      	add	x8, x8, #0x0
     3e4:      	ldp	x9, x10, [x8, #0x10]
     3e8:      	stp	x9, x10, [sp, #0x50]
     3ec:      	ldr	x9, [x8, #0x20]
     3f0:      	add	x10, sp, #0x40
     3f4:      	str	x9, [sp, #0x60]
     3f8:      	ldp	x8, x9, [x8]
     3fc:      	stp	x8, x9, [sp, #0x40]
     400:      	mov	w8, #0x2c               // =44
     404:      	mov	w9, #0x6                // =6
     408:      	ldr	x2, [x20, #0x20]
     40c:      	ldrb	w3, [sp, #0x14]
     410:      	blr	x9
     414:      	b	0x478 <kprobe_unwind_stop+0x478>
     418:      	ldr	w8, [x29]
     41c:      	cbz	w8, 0x478 <kprobe_unwind_stop+0x478>
     420:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     424:      	add	x8, x8, #0x0
     428:      	add	x0, sp, #0x40
     42c:      	ldp	x9, x10, [x8, #0x10]
     430:      	mov	w1, #0x2e               // =46
     434:      	stp	x9, x10, [sp, #0x50]
     438:      	ldr	x9, [x8, #0x20]
     43c:      	add	x10, sp, #0x40
     440:      	str	x9, [sp, #0x60]
     444:      	ldur	x9, [x8, #0x26]
     448:      	stur	x9, [sp, #0x66]
     44c:      	ldp	x9, x8, [x8]
     450:      	stp	x9, x8, [sp, #0x40]
     454:      	mov	w8, #0x2e               // =46
     458:      	mov	w9, #0x6                // =6
     45c:      	ldr	w2, [sp, #0x84]
     460:      	blr	x9
     464:      	ldr	w8, [x29]
     468:      	cbz	w8, 0x478 <kprobe_unwind_stop+0x478>
     46c:      	b	0x2dc <kprobe_unwind_stop+0x2dc>
     470:      	ldr	w8, [x29]
     474:      	cbnz	w8, 0x13c0 <kprobe_unwind_stop+0x13c0>
     478:      	ldr	w8, [x20, #0x2c0]
     47c:      	cbnz	w8, 0x4e0 <kprobe_unwind_stop+0x4e0>
     480:      	ldr	w8, [x20, #0x2bc]
     484:      	tbz	w8, #0x1f, 0x4e0 <kprobe_unwind_stop+0x4e0>
     488:      	ldr	w8, [x29]
     48c:      	cbnz	w8, 0x10f8 <kprobe_unwind_stop+0x10f8>
     490:      	mov	w8, #0x28               // =40
     494:      	add	x9, sp, #0x10
     498:      	add	x1, sp, #0x10
     49c:      	str	w8, [sp, #0x10]
     4a0:      	mov	w8, #0x1                // =1
     4a4:      	mov	x0, x21
     4a8:      	blr	x8
     4ac:      	cbz	x0, 0x4c8 <kprobe_unwind_stop+0x4c8>
     4b0:      	ldr	x8, [x0]
     4b4:      	add	x8, x8, #0x1
     4b8:      	str	x8, [x0]
     4bc:      	ldr	w8, [x20, #0xf1c]
     4c0:      	cbnz	w8, 0x4e0 <kprobe_unwind_stop+0x4e0>
     4c4:      	b	0x4d8 <kprobe_unwind_stop+0x4d8>
     4c8:      	ldr	w8, [x29]
     4cc:      	cbnz	w8, 0x1250 <kprobe_unwind_stop+0x1250>
     4d0:      	ldr	w8, [x20, #0xf1c]
     4d4:      	cbnz	w8, 0x4e0 <kprobe_unwind_stop+0x4e0>
     4d8:      	mov	w8, #0x3                // =3
     4dc:      	str	w8, [x20, #0xf1c]
     4e0:      	ldr	w8, [x20, #0xf1c]
     4e4:      	cbz	w8, 0x648 <kprobe_unwind_stop+0x648>
     4e8:      	ldr	w9, [x29]
     4ec:      	cbnz	w9, 0x5c8 <kprobe_unwind_stop+0x5c8>
     4f0:      	ldr	w9, [x20, #0x2c0]
     4f4:      	cmp	w9, #0x80
     4f8:      	b.lo	0x618 <kprobe_unwind_stop+0x618>
     4fc:      	ldr	w8, [x29]
     500:      	cbnz	w8, 0xd48 <kprobe_unwind_stop+0xd48>
     504:      	mov	w8, #0x2                // =2
     508:      	add	x9, sp, #0x10
     50c:      	add	x1, sp, #0x10
     510:      	str	w8, [sp, #0x10]
     514:      	mov	w8, #0x1                // =1
     518:      	mov	x0, x21
     51c:      	blr	x8
     520:      	cbz	x0, 0x534 <kprobe_unwind_stop+0x534>
     524:      	ldr	x8, [x0]
     528:      	add	x8, x8, #0x1
     52c:      	str	x8, [x0]
     530:      	b	0x648 <kprobe_unwind_stop+0x648>
     534:      	ldr	w8, [x29]
     538:      	cbz	w8, 0x648 <kprobe_unwind_stop+0x648>
     53c:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     540:      	add	x8, x8, #0x0
     544:      	add	x0, sp, #0x40
     548:      	ldp	x9, x10, [x8, #0x10]
     54c:      	mov	w1, #0x2e               // =46
     550:      	stp	x9, x10, [sp, #0x50]
     554:      	ldr	x9, [x8, #0x20]
     558:      	add	x10, sp, #0x40
     55c:      	str	x9, [sp, #0x60]
     560:      	ldur	x9, [x8, #0x26]
     564:      	stur	x9, [sp, #0x66]
     568:      	ldp	x9, x8, [x8]
     56c:      	stp	x9, x8, [sp, #0x40]
     570:      	mov	w8, #0x2e               // =46
     574:      	mov	w9, #0x6                // =6
     578:      	ldr	w2, [sp, #0x10]
     57c:      	blr	x9
     580:      	b	0x648 <kprobe_unwind_stop+0x648>
     584:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     588:      	add	x8, x8, #0x0
     58c:      	add	x0, sp, #0x40
     590:      	ldp	x9, x10, [x8, #0x20]
     594:      	mov	w1, #0x38               // =56
     598:      	stp	x9, x10, [sp, #0x60]
     59c:      	ldr	x9, [x8, #0x30]
     5a0:      	str	x9, [sp, #0x70]
     5a4:      	ldp	x9, x10, [x8]
     5a8:      	stp	x9, x10, [sp, #0x40]
     5ac:      	ldp	x8, x9, [x8, #0x10]
     5b0:      	add	x10, sp, #0x40
     5b4:      	stp	x8, x9, [sp, #0x50]
     5b8:      	mov	w8, #0x38               // =56
     5bc:      	mov	w9, #0x6                // =6
     5c0:      	blr	x9
     5c4:      	b	0x8c <kprobe_unwind_stop+0x8c>
     5c8:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     5cc:      	add	x8, x8, #0x0
     5d0:      	strb	wzr, [sp, #0x70]
     5d4:      	add	x0, sp, #0x40
     5d8:      	ldp	x9, x10, [x8, #0x10]
     5dc:      	mov	w1, #0x31               // =49
     5e0:      	stp	x9, x10, [sp, #0x50]
     5e4:      	ldp	x9, x10, [x8, #0x20]
     5e8:      	stp	x9, x10, [sp, #0x60]
     5ec:      	ldp	x9, x8, [x8]
     5f0:      	add	x10, sp, #0x40
     5f4:      	stp	x9, x8, [sp, #0x40]
     5f8:      	mov	w8, #0x31               // =49
     5fc:      	mov	w9, #0x6                // =6
     600:      	ldr	w2, [x20, #0xf1c]
     604:      	blr	x9
     608:      	ldr	w8, [x20, #0xf1c]
     60c:      	ldr	w9, [x20, #0x2c0]
     610:      	cmp	w9, #0x80
     614:      	b.hs	0x4fc <kprobe_unwind_stop+0x4fc>
     618:      	add	w10, w9, #0x1
     61c:      	mov	w8, w8
     620:      	str	w10, [x20, #0x2c0]
     624:      	mov	w10, #0x18              // =24
     628:      	umaddl	x9, w9, w10, x20
     62c:      	mov	w10, #0xff              // =255
     630:      	str	x8, [x9, #0x2d8]
     634:      	add	x8, x9, #0x2d0
     638:      	str	xzr, [x9, #0x2d0]
     63c:      	strb	w10, [x9, #0x2e0]
     640:      	str	wzr, [x9, #0x2e4]
     644:      	stur	wzr, [x8, #0x11]
     648:      	ldr	w8, [x20, #0xf18]
     64c:      	cmn	w8, #0x1
     650:      	b.eq	0xa40 <kprobe_unwind_stop+0xa40>
     654:      	cmp	w8, #0xc
     658:      	b.ne	0x9fc <kprobe_unwind_stop+0x9fc>
     65c:      	ldp	w8, w9, [x20]
     660:      	mov	w10, #0x1375            // =4981
     664:      	adrp	x23, 0x0 <kprobe_unwind_stop>
     668:      	add	x1, sp, #0x84
     66c:      	ldrb	w29, [x20, x10]
     670:      	mov	x22, x24
     674:      	orr	x9, x9, x8, lsl #32
     678:      	cmp	w29, #0x2
     67c:      	str	x9, [sp, #0x98]
     680:      	str	w8, [sp, #0x3c]
     684:      	str	w8, [sp, #0x84]
     688:      	mov	w8, #0x1                // =1
     68c:      	add	x9, sp, #0x84
     690:      	ldr	x23, [x23]
     694:      	cset	w19, eq
     698:      	mov	x0, x23
     69c:      	blr	x8
     6a0:      	mov	w8, #0x5                // =5
     6a4:      	mov	x24, x0
     6a8:      	blr	x8
     6ac:      	cbz	w29, 0x80c <kprobe_unwind_stop+0x80c>
     6b0:      	lsl	w19, w19, #4
     6b4:      	cbz	x24, 0x740 <kprobe_unwind_stop+0x740>
     6b8:      	ldr	x8, [x24]
     6bc:      	mov	w11, #0xe100            // =57600
     6c0:      	movk	w11, #0x5f5, lsl #16
     6c4:      	and	x9, x8, #0xffffffffffffffe0
     6c8:      	and	x10, x8, #0xf
     6cc:      	sub	x9, x0, x9
     6d0:      	lsl	x10, x11, x10
     6d4:      	cmp	x9, x10
     6d8:      	b.hs	0x6fc <kprobe_unwind_stop+0x6fc>
     6dc:      	adrp	x29, 0x0 <kprobe_unwind_stop>
     6e0:      	mov	x24, x22
     6e4:      	ldr	x29, [x29]
     6e8:      	ldr	w8, [x29]
     6ec:      	cbnz	w8, 0x1218 <kprobe_unwind_stop+0x1218>
     6f0:      	adrp	x22, 0x0 <kprobe_unwind_stop>
     6f4:      	ldr	x22, [x22]
     6f8:      	b	0x9fc <kprobe_unwind_stop+0x9fc>
     6fc:      	and	w11, w8, #0x10
     700:      	orr	w19, w11, w19
     704:      	mov	x11, #0xf200            // =61952
     708:      	movk	x11, #0x2a05, lsl #16
     70c:      	movk	x11, #0x1, lsl #32
     710:      	add	x10, x10, x11
     714:      	cmp	x9, x10
     718:      	b.hs	0x73c <kprobe_unwind_stop+0x73c>
     71c:      	cmp	w19, #0x0
     720:      	mov	w9, #0x4                // =4
     724:      	mov	w10, #0x8               // =8
     728:      	and	w8, w8, #0xf
     72c:      	csel	w9, w10, w9, eq
     730:      	cmp	w9, w8
     734:      	cinc	w24, w8, hi
     738:      	b	0x740 <kprobe_unwind_stop+0x740>
     73c:      	mov	w24, wzr
     740:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     744:      	ldr	x8, [x8]
     748:      	ldr	w8, [x8]
     74c:      	cbnz	w8, 0x10ac <kprobe_unwind_stop+0x10ac>
     750:      	and	x8, x0, #0xffffffffffffffe0
     754:      	and	x10, x24, #0xff
     758:      	mov	w9, w19
     75c:      	mov	x3, xzr
     760:      	add	x1, sp, #0x84
     764:      	add	x2, sp, #0x10
     768:      	mov	x0, x23
     76c:      	orr	x8, x8, x10
     770:      	add	x10, sp, #0x10
     774:      	orr	x8, x8, x9
     778:      	str	x8, [sp, #0x10]
     77c:      	mov	w8, #0x2                // =2
     780:      	add	x9, sp, #0x84
     784:      	blr	x8
     788:      	cbz	w0, 0x80c <kprobe_unwind_stop+0x80c>
     78c:      	adrp	x29, 0x0 <kprobe_unwind_stop>
     790:      	mov	x24, x22
     794:      	ldr	x29, [x29]
     798:      	ldr	w8, [x29]
     79c:      	cbnz	w8, 0x11d4 <kprobe_unwind_stop+0x11d4>
     7a0:      	mov	w8, #0x3d               // =61
     7a4:      	add	x9, sp, #0x88
     7a8:      	add	x1, sp, #0x88
     7ac:      	str	w8, [sp, #0x88]
     7b0:      	mov	w8, #0x1                // =1
     7b4:      	mov	x0, x21
     7b8:      	blr	x8
     7bc:      	adrp	x22, 0x0 <kprobe_unwind_stop>
     7c0:      	ldr	x22, [x22]
     7c4:      	cbnz	x0, 0x9f0 <kprobe_unwind_stop+0x9f0>
     7c8:      	ldr	w8, [x29]
     7cc:      	cbz	w8, 0x9fc <kprobe_unwind_stop+0x9fc>
     7d0:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     7d4:      	add	x8, x8, #0x0
     7d8:      	ldp	x9, x10, [x8, #0x10]
     7dc:      	stp	x9, x10, [sp, #0x50]
     7e0:      	ldr	x9, [x8, #0x20]
     7e4:      	add	x10, sp, #0x40
     7e8:      	str	x9, [sp, #0x60]
     7ec:      	ldur	x9, [x8, #0x26]
     7f0:      	stur	x9, [sp, #0x66]
     7f4:      	ldp	x9, x8, [x8]
     7f8:      	stp	x9, x8, [sp, #0x40]
     7fc:      	mov	w8, #0x2e               // =46
     800:      	mov	w9, #0x6                // =6
     804:      	ldr	w2, [sp, #0x88]
     808:      	b	0xcc0 <kprobe_unwind_stop+0xcc0>
     80c:      	mov	w8, #0x1                // =1
     810:      	adrp	x0, 0x0 <kprobe_unwind_stop>
     814:      	mov	x3, xzr
     818:      	strb	w8, [sp, #0x38]
     81c:      	mov	w8, #0x2                // =2
     820:      	add	x9, sp, #0x98
     824:      	add	x10, sp, #0x38
     828:      	ldr	x0, [x0]
     82c:      	add	x1, sp, #0x98
     830:      	add	x2, sp, #0x38
     834:      	mov	x24, x22
     838:      	blr	x8
     83c:      	adrp	x22, 0x0 <kprobe_unwind_stop>
     840:      	ldr	x22, [x22]
     844:      	cbz	w0, 0x8b8 <kprobe_unwind_stop+0x8b8>
     848:      	adrp	x29, 0x0 <kprobe_unwind_stop>
     84c:      	ldr	x29, [x29]
     850:      	ldr	w8, [x29]
     854:      	cbnz	w8, 0x1140 <kprobe_unwind_stop+0x1140>
     858:      	mov	w8, #0x3e               // =62
     85c:      	add	x9, sp, #0x10
     860:      	add	x1, sp, #0x10
     864:      	str	w8, [sp, #0x10]
     868:      	mov	w8, #0x1                // =1
     86c:      	mov	x0, x21
     870:      	blr	x8
     874:      	cbnz	x0, 0x9f0 <kprobe_unwind_stop+0x9f0>
     878:      	ldr	w8, [x29]
     87c:      	cbz	w8, 0x9fc <kprobe_unwind_stop+0x9fc>
     880:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     884:      	add	x8, x8, #0x0
     888:      	ldp	x9, x10, [x8, #0x10]
     88c:      	stp	x9, x10, [sp, #0x50]
     890:      	ldr	x9, [x8, #0x20]
     894:      	add	x10, sp, #0x40
     898:      	str	x9, [sp, #0x60]
     89c:      	ldur	x9, [x8, #0x26]
     8a0:      	stur	x9, [sp, #0x66]
     8a4:      	ldp	x9, x8, [x8]
     8a8:      	stp	x9, x8, [sp, #0x40]
     8ac:      	mov	w8, #0x2e               // =46
     8b0:      	mov	w9, #0x6                // =6
     8b4:      	b	0xcbc <kprobe_unwind_stop+0xcbc>
     8b8:      	cbnz	w29, 0x8d0 <kprobe_unwind_stop+0x8d0>
     8bc:      	mov	w8, #0x3                // =3
     8c0:      	add	x9, sp, #0x3c
     8c4:      	add	x1, sp, #0x3c
     8c8:      	mov	x0, x23
     8cc:      	blr	x8
     8d0:      	mov	w8, #0x1                // =1
     8d4:      	adrp	x0, 0x0 <kprobe_unwind_stop>
     8d8:      	mov	w9, #0x2                // =2
     8dc:      	str	w8, [sp, #0x88]
     8e0:      	strb	w8, [sp, #0x84]
     8e4:      	add	x10, sp, #0x88
     8e8:      	add	x11, sp, #0x84
     8ec:      	add	x1, sp, #0x88
     8f0:      	ldr	x0, [x0]
     8f4:      	add	x2, sp, #0x84
     8f8:      	mov	w3, #0x1                // =1
     8fc:      	blr	x9
     900:      	tbnz	w0, #0x1f, 0x93c <kprobe_unwind_stop+0x93c>
     904:      	mov	w8, #0x42               // =66
     908:      	add	x9, sp, #0x10
     90c:      	add	x1, sp, #0x10
     910:      	str	w8, [sp, #0x10]
     914:      	mov	w8, #0x1                // =1
     918:      	mov	x0, x21
     91c:      	blr	x8
     920:      	adrp	x29, 0x0 <kprobe_unwind_stop>
     924:      	ldr	x29, [x29]
     928:      	cbz	x0, 0x988 <kprobe_unwind_stop+0x988>
     92c:      	ldr	x8, [x0]
     930:      	add	x8, x8, #0x1
     934:      	str	x8, [x0]
     938:      	b	0x990 <kprobe_unwind_stop+0x990>
     93c:      	adrp	x29, 0x0 <kprobe_unwind_stop>
     940:      	ldr	x29, [x29]
     944:      	ldr	w8, [x29]
     948:      	cbz	w8, 0x9d0 <kprobe_unwind_stop+0x9d0>
     94c:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     950:      	add	x8, x8, #0x0
     954:      	strb	wzr, [sp, #0x58]
     958:      	add	x0, sp, #0x40
     95c:      	ldp	x9, x10, [x8]
     960:      	ldr	x8, [x8, #0x10]
     964:      	mov	w1, #0x19               // =25
     968:      	mov	w2, #0x1                // =1
     96c:      	str	x8, [sp, #0x50]
     970:      	stp	x9, x10, [sp, #0x40]
     974:      	mov	w8, #0x19               // =25
     978:      	mov	w9, #0x6                // =6
     97c:      	add	x10, sp, #0x40
     980:      	blr	x9
     984:      	b	0x9d0 <kprobe_unwind_stop+0x9d0>
     988:      	ldr	w8, [x29]
     98c:      	cbnz	w8, 0x1378 <kprobe_unwind_stop+0x1378>
     990:      	mov	w8, #0x1                // =1
     994:      	adrp	x1, 0x0 <kprobe_unwind_stop>
     998:      	mov	w9, #0x4                // =4
     99c:      	str	w8, [sp, #0x10]
     9a0:      	mov	w8, #-0x1               // =-1
     9a4:      	mov	w10, #0x19              // =25
     9a8:      	add	x11, sp, #0x10
     9ac:      	ldr	x1, [x1]
     9b0:      	add	x3, sp, #0x10
     9b4:      	mov	x0, x24
     9b8:      	mov	w2, #-0x1               // =-1
     9bc:      	mov	w4, #0x4                // =4
     9c0:      	blr	x10
     9c4:      	tbz	w0, #0x1f, 0x9d0 <kprobe_unwind_stop+0x9d0>
     9c8:      	ldr	w8, [x29]
     9cc:      	cbnz	w8, 0x132c <kprobe_unwind_stop+0x132c>
     9d0:      	mov	w8, #0x41               // =65
     9d4:      	add	x9, sp, #0x10
     9d8:      	add	x1, sp, #0x10
     9dc:      	str	w8, [sp, #0x10]
     9e0:      	mov	w8, #0x1                // =1
     9e4:      	mov	x0, x21
     9e8:      	blr	x8
     9ec:      	cbz	x0, 0xc80 <kprobe_unwind_stop+0xc80>
     9f0:      	ldr	x8, [x0]
     9f4:      	add	x8, x8, #0x1
     9f8:      	str	x8, [x0]
     9fc:      	ldr	w8, [x20, #0xf18]
     a00:      	add	x9, sp, #0x10
     a04:      	add	x1, sp, #0x10
     a08:      	mov	x0, x21
     a0c:      	str	w8, [sp, #0x10]
     a10:      	mov	w8, #0x1                // =1
     a14:      	blr	x8
     a18:      	cbz	x0, 0xa38 <kprobe_unwind_stop+0xa38>
     a1c:      	ldr	x8, [x0]
     a20:      	add	x8, x8, #0x1
     a24:      	str	x8, [x0]
     a28:      	ldr	w8, [x20, #0x2c0]
     a2c:      	cmp	w8, #0x1
     a30:      	b.eq	0xa4c <kprobe_unwind_stop+0xa4c>
     a34:      	b	0xa54 <kprobe_unwind_stop+0xa54>
     a38:      	ldr	w8, [x29]
     a3c:      	cbnz	w8, 0xd84 <kprobe_unwind_stop+0xd84>
     a40:      	ldr	w8, [x20, #0x2c0]
     a44:      	cmp	w8, #0x1
     a48:      	b.ne	0xa54 <kprobe_unwind_stop+0xa54>
     a4c:      	ldr	w8, [x20, #0x2bc]
     a50:      	tbnz	w8, #0x1f, 0xc0c <kprobe_unwind_stop+0xc0c>
     a54:      	ldr	w8, [x20]
     a58:      	adrp	x0, 0x0 <kprobe_unwind_stop>
     a5c:      	add	x9, sp, #0x84
     a60:      	add	x1, sp, #0x84
     a64:      	str	w8, [sp, #0x84]
     a68:      	mov	w8, #0x1                // =1
     a6c:      	ldr	x0, [x0]
     a70:      	blr	x8
     a74:      	cbz	x0, 0xb30 <kprobe_unwind_stop+0xb30>
     a78:      	str	xzr, [sp, #0x10]
     a7c:      	str	xzr, [sp, #0x98]
     a80:      	mov	w8, #0x23               // =35
     a84:      	mov	x23, x0
     a88:      	blr	x8
     a8c:      	ldr	x8, [x22]
     a90:      	mov	w9, #0x71               // =113
     a94:      	add	x10, sp, #0x98
     a98:      	mov	w1, #0x8                // =8
     a9c:      	add	x2, x0, x8
     aa0:      	mov	w8, #0x8                // =8
     aa4:      	add	x0, sp, #0x98
     aa8:      	blr	x9
     aac:      	ldr	w8, [x29]
     ab0:      	cbz	x0, 0xb80 <kprobe_unwind_stop+0xb80>
     ab4:      	cbnz	w8, 0xd0c <kprobe_unwind_stop+0xd0c>
     ab8:      	mov	w8, #0x4                // =4
     abc:      	add	x9, sp, #0x88
     ac0:      	add	x1, sp, #0x88
     ac4:      	str	w8, [sp, #0x88]
     ac8:      	mov	w8, #0x1                // =1
     acc:      	mov	x0, x21
     ad0:      	blr	x8
     ad4:      	cbz	x0, 0xc28 <kprobe_unwind_stop+0xc28>
     ad8:      	ldr	x8, [x0]
     adc:      	add	x8, x8, #0x1
     ae0:      	str	x8, [x0]
     ae4:      	ldr	w8, [x29]
     ae8:      	cbz	w8, 0x1004 <kprobe_unwind_stop+0x1004>
     aec:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     af0:      	add	x8, x8, #0x0
     af4:      	add	x0, sp, #0x40
     af8:      	ldp	x9, x10, [x8, #0x10]
     afc:      	mov	w1, #0x2e               // =46
     b00:      	stp	x9, x10, [sp, #0x50]
     b04:      	ldr	x9, [x8, #0x20]
     b08:      	add	x10, sp, #0x40
     b0c:      	str	x9, [sp, #0x60]
     b10:      	ldur	x9, [x8, #0x26]
     b14:      	stur	x9, [sp, #0x66]
     b18:      	ldp	x9, x8, [x8]
     b1c:      	stp	x9, x8, [sp, #0x40]
     b20:      	mov	w8, #0x2e               // =46
     b24:      	mov	w9, #0x6                // =6
     b28:      	blr	x9
     b2c:      	b	0x1004 <kprobe_unwind_stop+0x1004>
     b30:      	ldr	w8, [x29]
     b34:      	cbz	w8, 0x1004 <kprobe_unwind_stop+0x1004>
     b38:      	mov	w8, #0xa                // =10
     b3c:      	add	x0, sp, #0x40
     b40:      	mov	w1, #0x32               // =50
     b44:      	strh	w8, [sp, #0x70]
     b48:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     b4c:      	add	x8, x8, #0x0
     b50:      	ldp	x9, x10, [x8, #0x10]
     b54:      	stp	x9, x10, [sp, #0x50]
     b58:      	ldp	x9, x10, [x8, #0x20]
     b5c:      	stp	x9, x10, [sp, #0x60]
     b60:      	ldp	x9, x8, [x8]
     b64:      	add	x10, sp, #0x40
     b68:      	stp	x9, x8, [sp, #0x40]
     b6c:      	mov	w8, #0x32               // =50
     b70:      	mov	w9, #0x6                // =6
     b74:      	ldr	w2, [sp, #0x84]
     b78:      	blr	x9
     b7c:      	b	0x1004 <kprobe_unwind_stop+0x1004>
     b80:      	cbnz	w8, 0xe20 <kprobe_unwind_stop+0xe20>
     b84:      	ldrsw	x8, [x23, #0x18]
     b88:      	cbz	w8, 0xe70 <kprobe_unwind_stop+0xe70>
     b8c:      	ldr	x9, [sp, #0x98]
     b90:      	mov	w10, #0x70              // =112
     b94:      	add	x11, sp, #0x10
     b98:      	add	x0, sp, #0x10
     b9c:      	mov	w1, #0x8                // =8
     ba0:      	add	x8, x9, x8
     ba4:      	mov	w9, #0x8                // =8
     ba8:      	ldr	x8, [sp, #0x98]
     bac:      	ldrsw	x9, [x23, #0x18]
     bb0:      	add	x2, x9, x8
     bb4:      	blr	x10
     bb8:      	ldr	w8, [x29]
     bbc:      	cbz	x0, 0xe80 <kprobe_unwind_stop+0xe80>
     bc0:      	cbz	w8, 0x1004 <kprobe_unwind_stop+0x1004>
     bc4:      	mov	w8, #0xa                // =10
     bc8:      	add	x0, sp, #0x40
     bcc:      	mov	w1, #0x2a               // =42
     bd0:      	strh	w8, [sp, #0x68]
     bd4:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     bd8:      	add	x8, x8, #0x0
     bdc:      	ldp	x9, x10, [x8, #0x10]
     be0:      	stp	x9, x10, [sp, #0x50]
     be4:      	ldr	x9, [x8, #0x20]
     be8:      	add	x10, sp, #0x40
     bec:      	str	x9, [sp, #0x60]
     bf0:      	ldp	x8, x9, [x8]
     bf4:      	stp	x8, x9, [sp, #0x40]
     bf8:      	mov	w8, #0x2a               // =42
     bfc:      	mov	w9, #0x6                // =6
     c00:      	ldr	x2, [sp, #0x98]
     c04:      	blr	x9
     c08:      	b	0x1004 <kprobe_unwind_stop+0x1004>
     c0c:      	ldr	w8, [x20, #0xf1c]
     c10:      	cbz	w8, 0xa54 <kprobe_unwind_stop+0xa54>
     c14:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     c18:      	ldr	x8, [x8]
     c1c:      	ldrb	w8, [x8]
     c20:      	cbnz	w8, 0x1044 <kprobe_unwind_stop+0x1044>
     c24:      	b	0xa54 <kprobe_unwind_stop+0xa54>
     c28:      	ldr	w8, [x29]
     c2c:      	cbz	w8, 0x1004 <kprobe_unwind_stop+0x1004>
     c30:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     c34:      	add	x8, x8, #0x0
     c38:      	add	x0, sp, #0x40
     c3c:      	ldp	x9, x10, [x8, #0x10]
     c40:      	mov	w1, #0x2e               // =46
     c44:      	stp	x9, x10, [sp, #0x50]
     c48:      	ldr	x9, [x8, #0x20]
     c4c:      	add	x10, sp, #0x40
     c50:      	str	x9, [sp, #0x60]
     c54:      	ldur	x9, [x8, #0x26]
     c58:      	stur	x9, [sp, #0x66]
     c5c:      	ldp	x9, x8, [x8]
     c60:      	stp	x9, x8, [sp, #0x40]
     c64:      	mov	w8, #0x2e               // =46
     c68:      	mov	w9, #0x6                // =6
     c6c:      	ldr	w2, [sp, #0x88]
     c70:      	blr	x9
     c74:      	ldr	w8, [x29]
     c78:      	cbz	w8, 0x1004 <kprobe_unwind_stop+0x1004>
     c7c:      	b	0xaec <kprobe_unwind_stop+0xaec>
     c80:      	ldr	w8, [x29]
     c84:      	cbz	w8, 0x9fc <kprobe_unwind_stop+0x9fc>
     c88:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     c8c:      	add	x8, x8, #0x0
     c90:      	ldp	x9, x10, [x8, #0x10]
     c94:      	stp	x9, x10, [sp, #0x50]
     c98:      	ldr	x9, [x8, #0x20]
     c9c:      	add	x10, sp, #0x40
     ca0:      	str	x9, [sp, #0x60]
     ca4:      	ldur	x9, [x8, #0x26]
     ca8:      	stur	x9, [sp, #0x66]
     cac:      	ldp	x9, x8, [x8]
     cb0:      	stp	x9, x8, [sp, #0x40]
     cb4:      	mov	w8, #0x2e               // =46
     cb8:      	mov	w9, #0x6                // =6
     cbc:      	ldr	w2, [sp, #0x10]
     cc0:      	add	x0, sp, #0x40
     cc4:      	mov	w1, #0x2e               // =46
     cc8:      	blr	x9
     ccc:      	b	0x9fc <kprobe_unwind_stop+0x9fc>
     cd0:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     cd4:      	add	x8, x8, #0x0
     cd8:      	add	x0, sp, #0x40
     cdc:      	ldp	x9, x10, [x8]
     ce0:      	mov	w1, #0x1d               // =29
     ce4:      	stp	x9, x10, [sp, #0x40]
     ce8:      	ldr	x9, [x8, #0x10]
     cec:      	ldur	x8, [x8, #0x15]
     cf0:      	add	x10, sp, #0x40
     cf4:      	str	x9, [sp, #0x50]
     cf8:      	stur	x8, [sp, #0x55]
     cfc:      	mov	w8, #0x1d               // =29
     d00:      	mov	w9, #0x6                // =6
     d04:      	blr	x9
     d08:      	b	0xc0 <kprobe_unwind_stop+0xc0>
     d0c:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     d10:      	add	x8, x8, #0x0
     d14:      	add	x0, sp, #0x40
     d18:      	ldp	x9, x10, [x8]
     d1c:      	mov	w1, #0x1d               // =29
     d20:      	stp	x9, x10, [sp, #0x40]
     d24:      	ldr	x9, [x8, #0x10]
     d28:      	ldur	x8, [x8, #0x15]
     d2c:      	add	x10, sp, #0x40
     d30:      	str	x9, [sp, #0x50]
     d34:      	stur	x8, [sp, #0x55]
     d38:      	mov	w8, #0x1d               // =29
     d3c:      	mov	w9, #0x6                // =6
     d40:      	blr	x9
     d44:      	b	0xab8 <kprobe_unwind_stop+0xab8>
     d48:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     d4c:      	add	x8, x8, #0x0
     d50:      	add	x0, sp, #0x40
     d54:      	ldp	x9, x10, [x8, #0x10]
     d58:      	mov	w1, #0x25               // =37
     d5c:      	stp	x9, x10, [sp, #0x50]
     d60:      	ldur	x9, [x8, #0x1d]
     d64:      	add	x10, sp, #0x40
     d68:      	stur	x9, [sp, #0x5d]
     d6c:      	ldp	x8, x9, [x8]
     d70:      	stp	x8, x9, [sp, #0x40]
     d74:      	mov	w8, #0x25               // =37
     d78:      	mov	w9, #0x6                // =6
     d7c:      	blr	x9
     d80:      	b	0x504 <kprobe_unwind_stop+0x504>
     d84:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     d88:      	add	x8, x8, #0x0
     d8c:      	add	x0, sp, #0x40
     d90:      	ldp	x9, x10, [x8, #0x10]
     d94:      	mov	w1, #0x2e               // =46
     d98:      	stp	x9, x10, [sp, #0x50]
     d9c:      	ldr	x9, [x8, #0x20]
     da0:      	add	x10, sp, #0x40
     da4:      	str	x9, [sp, #0x60]
     da8:      	ldur	x9, [x8, #0x26]
     dac:      	stur	x9, [sp, #0x66]
     db0:      	ldp	x9, x8, [x8]
     db4:      	stp	x9, x8, [sp, #0x40]
     db8:      	mov	w8, #0x2e               // =46
     dbc:      	mov	w9, #0x6                // =6
     dc0:      	ldr	w2, [sp, #0x10]
     dc4:      	blr	x9
     dc8:      	ldr	w8, [x20, #0x2c0]
     dcc:      	cmp	w8, #0x1
     dd0:      	b.eq	0xa4c <kprobe_unwind_stop+0xa4c>
     dd4:      	b	0xa54 <kprobe_unwind_stop+0xa54>
     dd8:      	mov	w8, #0xa                // =10
     ddc:      	add	x0, sp, #0x40
     de0:      	mov	w1, #0x22               // =34
     de4:      	strh	w8, [sp, #0x60]
     de8:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     dec:      	add	x8, x8, #0x0
     df0:      	ldp	x9, x10, [x8]
     df4:      	stp	x9, x10, [sp, #0x40]
     df8:      	ldp	x9, x8, [x8, #0x10]
     dfc:      	add	x10, sp, #0x40
     e00:      	stp	x9, x8, [sp, #0x50]
     e04:      	mov	w8, #0x22               // =34
     e08:      	mov	w9, #0x6                // =6
     e0c:      	ldr	x8, [sp, #0x98]
     e10:      	ldr	x10, [x23]
     e14:      	add	x2, x10, x8
     e18:      	blr	x9
     e1c:      	b	0xfc <kprobe_unwind_stop+0xfc>
     e20:      	mov	w8, #0xa                // =10
     e24:      	add	x0, sp, #0x40
     e28:      	mov	w1, #0x2a               // =42
     e2c:      	strh	w8, [sp, #0x68]
     e30:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     e34:      	add	x8, x8, #0x0
     e38:      	ldp	x9, x10, [x8, #0x10]
     e3c:      	stp	x9, x10, [sp, #0x50]
     e40:      	ldr	x9, [x8, #0x20]
     e44:      	add	x10, sp, #0x40
     e48:      	str	x9, [sp, #0x60]
     e4c:      	ldp	x8, x9, [x8]
     e50:      	stp	x8, x9, [sp, #0x40]
     e54:      	mov	w8, #0x2a               // =42
     e58:      	mov	w9, #0x6                // =6
     e5c:      	ldr	x2, [sp, #0x98]
     e60:      	ldr	w3, [x23, #0x18]
     e64:      	blr	x9
     e68:      	ldrsw	x8, [x23, #0x18]
     e6c:      	cbnz	w8, 0xb8c <kprobe_unwind_stop+0xb8c>
     e70:      	ldr	x9, [x20, #0xef8]
     e74:      	str	x9, [sp, #0x10]
     e78:      	cbz	x9, 0xb8c <kprobe_unwind_stop+0xb8c>
     e7c:      	ldr	w8, [x29]
     e80:      	cbnz	w8, 0x1190 <kprobe_unwind_stop+0x1190>
     e84:      	ldr	x8, [sp, #0x10]
     e88:      	ldr	w9, [x23]
     e8c:      	mov	w10, #0x70              // =112
     e90:      	add	x11, sp, #0x88
     e94:      	add	x0, sp, #0x88
     e98:      	mov	w1, #0x8                // =8
     e9c:      	add	x8, x8, x9
     ea0:      	mov	w9, #0x8                // =8
     ea4:      	ldr	x8, [sp, #0x10]
     ea8:      	ldr	w9, [x23]
     eac:      	add	x2, x8, x9
     eb0:      	blr	x10
     eb4:      	ldr	w8, [x29]
     eb8:      	cbz	x0, 0xef4 <kprobe_unwind_stop+0xef4>
     ebc:      	cbz	w8, 0x1004 <kprobe_unwind_stop+0x1004>
     ec0:      	adrp	x8, 0x0 <kprobe_unwind_stop>
     ec4:      	add	x8, x8, #0x0
     ec8:      	add	x0, sp, #0x40
     ecc:      	ldp	x9, x10, [x8]
     ed0:      	ldur	x8, [x8, #0xf]
     ed4:      	mov	w1, #0x17               // =23
     ed8:      	stp	x9, x10, [sp, #0x40]
     edc:      	stur	x8, [sp, #0x4f]
     ee0:      	mov	w8, #0x17               // =23
     ee4:      	mov	w9, #0x6                // =6
     ee8:      	add	x10, sp, #0x40
     eec:      	blr	x9
     ef0:      	b	0x1004 <kprobe_unwind_stop+0x1004>
     ef4:      	cbnz	w8, 0x12a0 <kprobe_unwind_stop+0x12a0>
     ef8:      	ldr	x8, [sp, #0x88]
     efc:      	cbz	x8, 0x1004 <kprobe_unwind_stop+0x1004>
     f00:      	str	x8, [x20, #0xf68]
     f04:      	ldr	w8, [x29]
     f08:      	cbnz	w8, 0x12e0 <kprobe_unwind_stop+0x12e0>
     f0c:      	mov	w8, #0x60               // =96
     f10:      	add	x9, sp, #0x10
     f14:      	add	x1, sp, #0x10
     f18:      	str	w8, [sp, #0x10]
     f1c:      	mov	w8, #0x1                // =1
     f20:      	mov	x0, x21
     f24:      	blr	x8
     f28:      	cbz	x0, 0xf3c <kprobe_unwind_stop+0xf3c>
     f2c:      	ldr	x8, [x0]
     f30:      	add	x8, x8, #0x1
     f34:      	str	x8, [x0]
     f38:      	b	0xf44 <kprobe_unwind_stop+0xf44>
     f3c:      	ldr	w8, [x29]
     f40:      	cbnz	w8, 0x1410 <kprobe_unwind_stop+0x1410>
     f44:      	str	wzr, [sp, #0x40]
     f48:      	mov	w8, #0x1                // =1
     f4c:      	add	x9, sp, #0x40
     f50:      	add	x1, sp, #0x40
     f54:      	mov	x0, x25
     f58:      	blr	x8
     f5c:      	cbz	x0, 0xfac <kprobe_unwind_stop+0xfac>
     f60:      	mov	w22, #0x1374            // =4980
     f64:      	ldrb	w8, [x0, x22]
     f68:      	cmp	w8, #0x1d
     f6c:      	b.lo	0xfc8 <kprobe_unwind_stop+0xfc8>
     f70:      	mov	w8, #0x5                // =5
     f74:      	add	x9, sp, #0x10
     f78:      	mov	x19, x0
     f7c:      	str	w8, [x0, #0xf1c]
     f80:      	mov	w8, #0x44               // =68
     f84:      	add	x1, sp, #0x10
     f88:      	mov	x0, x21
     f8c:      	str	w8, [sp, #0x10]
     f90:      	mov	w8, #0x1                // =1
     f94:      	blr	x8
     f98:      	cbz	x0, 0xfd0 <kprobe_unwind_stop+0xfd0>
     f9c:      	ldr	x8, [x0]
     fa0:      	add	x8, x8, #0x1
     fa4:      	str	x8, [x0]
     fa8:      	b	0xfd8 <kprobe_unwind_stop+0xfd8>
     fac:      	adrp	x1, 0x0 <kprobe_unwind_stop>
     fb0:      	mov	x8, xzr
     fb4:      	mov	w9, #0xc                // =12
     fb8:      	ldr	x1, [x1]
     fbc:      	mov	x0, x24
     fc0:      	mov	w2, wzr
     fc4:      	b	0x1000 <kprobe_unwind_stop+0x1000>
     fc8:      	mov	w2, #0x9                // =9
     fcc:      	b	0xfe4 <kprobe_unwind_stop+0xfe4>
     fd0:      	ldr	w8, [x29]
     fd4:      	cbnz	w8, 0x1458 <kprobe_unwind_stop+0x1458>
     fd8:      	ldrb	w8, [x19, x22]
     fdc:      	mov	w2, wzr
     fe0:      	mov	x0, x19
     fe4:      	add	w8, w8, #0x1
     fe8:      	adrp	x1, 0x0 <kprobe_unwind_stop>
     fec:      	mov	w9, #0xc                // =12
     ff0:      	strb	w8, [x0, x22]
     ff4:      	mov	w8, w2
     ff8:      	mov	x0, x24
     ffc:      	ldr	x1, [x1]
    1000:      	blr	x9
    1004:      	ldr	w8, [x20, #0x2c0]
    1008:      	mov	w9, #0x80               // =128
    100c:      	mov	x10, #0xed0             // =3792
    1010:      	sub	w8, w9, w8
    1014:      	mov	x9, #-0x18              // =-24
    1018:      	madd	x4, x8, x9, x10
    101c:      	cmp	x4, #0xed0
    1020:      	b.hi	0x1044 <kprobe_unwind_stop+0x1044>
    1024:      	adrp	x1, 0x1000 <kprobe_unwind_stop+0x1000>
    1028:      	mov	w8, #-0x1               // =-1
    102c:      	mov	w9, #0x19               // =25
    1030:      	ldr	x1, [x1]
    1034:      	mov	x0, x24
    1038:      	mov	w2, #-0x1               // =-1
    103c:      	mov	x3, x20
    1040:      	blr	x9
    1044:      	mov	w0, wzr
    1048:      	ldp	x20, x19, [sp, #0xd0]
    104c:      	ldr	x29, [sp, #0x90]
    1050:      	ldp	x22, x21, [sp, #0xc0]
    1054:      	ldp	x24, x23, [sp, #0xb0]
    1058:      	ldp	x30, x25, [sp, #0xa0]
    105c:      	add	sp, sp, #0xe0
    1060:      	ret
    1064:      	adrp	x8, 0x1000 <kprobe_unwind_stop+0x1000>
    1068:      	add	x8, x8, #0x0
    106c:      	add	x0, sp, #0x40
    1070:      	ldp	x9, x10, [x8, #0x10]
    1074:      	mov	w1, #0x2e               // =46
    1078:      	stp	x9, x10, [sp, #0x50]
    107c:      	ldr	x9, [x8, #0x20]
    1080:      	add	x10, sp, #0x40
    1084:      	str	x9, [sp, #0x60]
    1088:      	ldur	x9, [x8, #0x26]
    108c:      	stur	x9, [sp, #0x66]
    1090:      	ldp	x9, x8, [x8]
    1094:      	stp	x9, x8, [sp, #0x40]
    1098:      	mov	w8, #0x2e               // =46
    109c:      	mov	w9, #0x6                // =6
    10a0:      	ldr	w2, [sp, #0x10]
    10a4:      	blr	x9
    10a8:      	b	0x1b0 <kprobe_unwind_stop+0x1b0>
    10ac:      	adrp	x8, 0x1000 <kprobe_unwind_stop+0x1000>
    10b0:      	add	x8, x8, #0x0
    10b4:      	and	w3, w24, #0xff
    10b8:      	ldp	x9, x10, [x8]
    10bc:      	mov	w1, #0x1f               // =31
    10c0:      	stp	x9, x10, [sp, #0x40]
    10c4:      	ldr	x9, [x8, #0x10]
    10c8:      	ldur	x8, [x8, #0x17]
    10cc:      	add	x10, sp, #0x40
    10d0:      	str	x9, [sp, #0x50]
    10d4:      	stur	x8, [sp, #0x57]
    10d8:      	mov	w8, #0x1f               // =31
    10dc:      	mov	w9, #0x6                // =6
    10e0:      	str	x0, [sp, #0x8]
    10e4:      	add	x0, sp, #0x40
    10e8:      	ldr	w2, [sp, #0x84]
    10ec:      	blr	x9
    10f0:      	ldr	x0, [sp, #0x8]
    10f4:      	b	0x750 <kprobe_unwind_stop+0x750>
    10f8:      	mov	w8, #0x7974             // =31092
    10fc:      	add	x0, sp, #0x40
    1100:      	mov	w1, #0x2b               // =43
    1104:      	movk	w8, #0xa, lsl #16
    1108:      	stur	w8, [sp, #0x67]
    110c:      	adrp	x8, 0x1000 <kprobe_unwind_stop+0x1000>
    1110:      	add	x8, x8, #0x0
    1114:      	ldp	x9, x10, [x8, #0x10]
    1118:      	stp	x9, x10, [sp, #0x50]
    111c:      	ldr	x9, [x8, #0x20]
    1120:      	add	x10, sp, #0x40
    1124:      	str	x9, [sp, #0x60]
    1128:      	ldp	x8, x9, [x8]
    112c:      	stp	x8, x9, [sp, #0x40]
    1130:      	mov	w8, #0x2b               // =43
    1134:      	mov	w9, #0x6                // =6
    1138:      	blr	x9
    113c:      	b	0x490 <kprobe_unwind_stop+0x490>
    1140:      	adrp	x8, 0x1000 <kprobe_unwind_stop+0x1000>
    1144:      	add	x8, x8, #0x0
    1148:      	ldr	w3, [sp, #0x98]
    114c:      	mov	w4, w0
    1150:      	ldp	x9, x10, [x8, #0x20]
    1154:      	add	x0, sp, #0x40
    1158:      	mov	w1, #0x35               // =53
    115c:      	stp	x9, x10, [sp, #0x60]
    1160:      	ldur	x9, [x8, #0x2d]
    1164:      	stur	x9, [sp, #0x6d]
    1168:      	ldp	x9, x10, [x8]
    116c:      	stp	x9, x10, [sp, #0x40]
    1170:      	ldp	x8, x9, [x8, #0x10]
    1174:      	add	x10, sp, #0x40
    1178:      	stp	x8, x9, [sp, #0x50]
    117c:      	mov	w8, #0x35               // =53
    1180:      	mov	w9, #0x6                // =6
    1184:      	ldr	w2, [sp, #0x3c]
    1188:      	blr	x9
    118c:      	b	0x858 <kprobe_unwind_stop+0x858>
    1190:      	adrp	x8, 0x1000 <kprobe_unwind_stop+0x1000>
    1194:      	add	x8, x8, #0x0
    1198:      	add	x0, sp, #0x40
    119c:      	ldp	x9, x10, [x8, #0x10]
    11a0:      	mov	w1, #0x28               // =40
    11a4:      	stp	x9, x10, [sp, #0x50]
    11a8:      	ldr	x9, [x8, #0x20]
    11ac:      	add	x10, sp, #0x40
    11b0:      	str	x9, [sp, #0x60]
    11b4:      	ldp	x8, x9, [x8]
    11b8:      	stp	x8, x9, [sp, #0x40]
    11bc:      	mov	w8, #0x28               // =40
    11c0:      	mov	w9, #0x6                // =6
    11c4:      	ldr	x2, [sp, #0x10]
    11c8:      	ldr	w3, [x23]
    11cc:      	blr	x9
    11d0:      	b	0xe84 <kprobe_unwind_stop+0xe84>
    11d4:      	adrp	x8, 0x1000 <kprobe_unwind_stop+0x1000>
    11d8:      	add	x8, x8, #0x0
    11dc:      	mov	w3, w0
    11e0:      	ldp	x9, x10, [x8]
    11e4:      	add	x0, sp, #0x40
    11e8:      	mov	w1, #0x1d               // =29
    11ec:      	stp	x9, x10, [sp, #0x40]
    11f0:      	ldr	x9, [x8, #0x10]
    11f4:      	ldur	x8, [x8, #0x15]
    11f8:      	add	x10, sp, #0x40
    11fc:      	str	x9, [sp, #0x50]
    1200:      	stur	x8, [sp, #0x55]
    1204:      	mov	w8, #0x1d               // =29
    1208:      	mov	w9, #0x6                // =6
    120c:      	ldr	w2, [sp, #0x84]
    1210:      	blr	x9
    1214:      	b	0x7a0 <kprobe_unwind_stop+0x7a0>
    1218:      	adrp	x8, 0x1000 <kprobe_unwind_stop+0x1000>
    121c:      	add	x8, x8, #0x0
    1220:      	add	x0, sp, #0x40
    1224:      	ldp	x9, x10, [x8]
    1228:      	mov	w1, #0x20               // =32
    122c:      	stp	x9, x10, [sp, #0x40]
    1230:      	ldp	x9, x8, [x8, #0x10]
    1234:      	add	x10, sp, #0x40
    1238:      	stp	x9, x8, [sp, #0x50]
    123c:      	mov	w8, #0x20               // =32
    1240:      	mov	w9, #0x6                // =6
    1244:      	ldr	w2, [sp, #0x84]
    1248:      	blr	x9
    124c:      	b	0x6f0 <kprobe_unwind_stop+0x6f0>
    1250:      	adrp	x8, 0x1000 <kprobe_unwind_stop+0x1000>
    1254:      	add	x8, x8, #0x0
    1258:      	add	x0, sp, #0x40
    125c:      	ldp	x9, x10, [x8, #0x10]
    1260:      	mov	w1, #0x2e               // =46
    1264:      	stp	x9, x10, [sp, #0x50]
    1268:      	ldr	x9, [x8, #0x20]
    126c:      	add	x10, sp, #0x40
    1270:      	str	x9, [sp, #0x60]
    1274:      	ldur	x9, [x8, #0x26]
    1278:      	stur	x9, [sp, #0x66]
    127c:      	ldp	x9, x8, [x8]
    1280:      	stp	x9, x8, [sp, #0x40]
    1284:      	mov	w8, #0x2e               // =46
    1288:      	mov	w9, #0x6                // =6
    128c:      	ldr	w2, [sp, #0x10]
    1290:      	blr	x9
    1294:      	ldr	w8, [x20, #0xf1c]
    1298:      	cbnz	w8, 0x4e0 <kprobe_unwind_stop+0x4e0>
    129c:      	b	0x4d8 <kprobe_unwind_stop+0x4d8>
    12a0:      	adrp	x8, 0x1000 <kprobe_unwind_stop+0x1000>
    12a4:      	add	x8, x8, #0x0
    12a8:      	add	x0, sp, #0x40
    12ac:      	ldp	x9, x10, [x8]
    12b0:      	ldur	x8, [x8, #0xe]
    12b4:      	mov	w1, #0x16               // =22
    12b8:      	stp	x9, x10, [sp, #0x40]
    12bc:      	stur	x8, [sp, #0x4e]
    12c0:      	mov	w8, #0x16               // =22
    12c4:      	mov	w9, #0x6                // =6
    12c8:      	add	x10, sp, #0x40
    12cc:      	ldr	x2, [sp, #0x88]
    12d0:      	blr	x9
    12d4:      	ldr	x8, [sp, #0x88]
    12d8:      	cbnz	x8, 0xf00 <kprobe_unwind_stop+0xf00>
    12dc:      	b	0x1004 <kprobe_unwind_stop+0x1004>
    12e0:      	adrp	x8, 0x1000 <kprobe_unwind_stop+0x1000>
    12e4:      	add	x8, x8, #0x0
    12e8:      	add	x0, sp, #0x40
    12ec:      	ldp	x9, x10, [x8, #0x20]
    12f0:      	mov	w1, #0x3d               // =61
    12f4:      	stp	x9, x10, [sp, #0x60]
    12f8:      	ldr	x9, [x8, #0x30]
    12fc:      	str	x9, [sp, #0x70]
    1300:      	ldur	x9, [x8, #0x35]
    1304:      	stur	x9, [sp, #0x75]
    1308:      	ldp	x9, x10, [x8]
    130c:      	stp	x9, x10, [sp, #0x40]
    1310:      	add	x10, sp, #0x40
    1314:      	ldp	x9, x8, [x8, #0x10]
    1318:      	stp	x9, x8, [sp, #0x50]
    131c:      	mov	w8, #0x3d               // =61
    1320:      	mov	w9, #0x6                // =6
    1324:      	blr	x9
    1328:      	b	0xf0c <kprobe_unwind_stop+0xf0c>
    132c:      	adrp	x8, 0x1000 <kprobe_unwind_stop+0x1000>
    1330:      	add	x8, x8, #0x0
    1334:      	mov	w3, w0
    1338:      	ldp	x9, x10, [x8, #0x20]
    133c:      	add	x0, sp, #0x40
    1340:      	mov	w1, #0x36               // =54
    1344:      	mov	w2, #0x1                // =1
    1348:      	stp	x9, x10, [sp, #0x60]
    134c:      	ldur	x9, [x8, #0x2e]
    1350:      	stur	x9, [sp, #0x6e]
    1354:      	ldp	x9, x10, [x8]
    1358:      	stp	x9, x10, [sp, #0x40]
    135c:      	ldp	x8, x9, [x8, #0x10]
    1360:      	add	x10, sp, #0x40
    1364:      	stp	x8, x9, [sp, #0x50]
    1368:      	mov	w8, #0x36               // =54
    136c:      	mov	w9, #0x6                // =6
    1370:      	blr	x9
    1374:      	b	0x9d0 <kprobe_unwind_stop+0x9d0>
    1378:      	adrp	x8, 0x1000 <kprobe_unwind_stop+0x1000>
    137c:      	add	x8, x8, #0x0
    1380:      	add	x0, sp, #0x40
    1384:      	ldp	x9, x10, [x8, #0x10]
    1388:      	mov	w1, #0x2e               // =46
    138c:      	stp	x9, x10, [sp, #0x50]
    1390:      	ldr	x9, [x8, #0x20]
    1394:      	add	x10, sp, #0x40
    1398:      	str	x9, [sp, #0x60]
    139c:      	ldur	x9, [x8, #0x26]
    13a0:      	stur	x9, [sp, #0x66]
    13a4:      	ldp	x9, x8, [x8]
    13a8:      	stp	x9, x8, [sp, #0x40]
    13ac:      	mov	w8, #0x2e               // =46
    13b0:      	mov	w9, #0x6                // =6
    13b4:      	ldr	w2, [sp, #0x10]
    13b8:      	blr	x9
    13bc:      	b	0x990 <kprobe_unwind_stop+0x990>
    13c0:      	adrp	x8, 0x1000 <kprobe_unwind_stop+0x1000>
    13c4:      	add	x8, x8, #0x0
    13c8:      	add	x0, sp, #0x40
    13cc:      	ldp	x9, x10, [x8, #0x10]
    13d0:      	mov	w1, #0x2e               // =46
    13d4:      	stp	x9, x10, [sp, #0x50]
    13d8:      	ldr	x9, [x8, #0x20]
    13dc:      	add	x10, sp, #0x40
    13e0:      	str	x9, [sp, #0x60]
    13e4:      	ldur	x9, [x8, #0x26]
    13e8:      	stur	x9, [sp, #0x66]
    13ec:      	ldp	x9, x8, [x8]
    13f0:      	stp	x9, x8, [sp, #0x40]
    13f4:      	mov	w8, #0x2e               // =46
    13f8:      	mov	w9, #0x6                // =6
    13fc:      	ldr	w2, [sp, #0x84]
    1400:      	blr	x9
    1404:      	ldr	w8, [x29]
    1408:      	cbz	w8, 0x478 <kprobe_unwind_stop+0x478>
    140c:      	b	0x3c8 <kprobe_unwind_stop+0x3c8>
    1410:      	adrp	x8, 0x1000 <kprobe_unwind_stop+0x1000>
    1414:      	add	x8, x8, #0x0
    1418:      	add	x0, sp, #0x40
    141c:      	ldp	x9, x10, [x8, #0x10]
    1420:      	mov	w1, #0x2e               // =46
    1424:      	stp	x9, x10, [sp, #0x50]
    1428:      	ldr	x9, [x8, #0x20]
    142c:      	add	x10, sp, #0x40
    1430:      	str	x9, [sp, #0x60]
    1434:      	ldur	x9, [x8, #0x26]
    1438:      	stur	x9, [sp, #0x66]
    143c:      	ldp	x9, x8, [x8]
    1440:      	stp	x9, x8, [sp, #0x40]
    1444:      	mov	w8, #0x2e               // =46
    1448:      	mov	w9, #0x6                // =6
    144c:      	ldr	w2, [sp, #0x10]
    1450:      	blr	x9
    1454:      	b	0xf44 <kprobe_unwind_stop+0xf44>
    1458:      	adrp	x8, 0x1000 <kprobe_unwind_stop+0x1000>
    145c:      	add	x8, x8, #0x0
    1460:      	add	x0, sp, #0x40
    1464:      	ldp	x9, x10, [x8, #0x10]
    1468:      	mov	w1, #0x2e               // =46
    146c:      	stp	x9, x10, [sp, #0x50]
    1470:      	ldr	x9, [x8, #0x20]
    1474:      	add	x10, sp, #0x40
    1478:      	str	x9, [sp, #0x60]
    147c:      	ldur	x9, [x8, #0x26]
    1480:      	stur	x9, [sp, #0x66]
    1484:      	ldp	x9, x8, [x8]
    1488:      	stp	x9, x8, [sp, #0x40]
    148c:      	mov	w8, #0x2e               // =46
    1490:      	mov	w9, #0x6                // =6
    1494:      	ldr	w2, [sp, #0x10]
    1498:      	blr	x9
    149c:      	b	0xfd8 <kprobe_unwind_stop+0xfd8>
