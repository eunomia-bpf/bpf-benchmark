
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/bcc/opensnoop.native.o:	file format elf64-littleaarch64

Disassembly of section tracepoint/syscalls/sys_enter_open:

0000000000000000 <tracepoint__syscalls__sys_enter_open>:
       0:      	sub	sp, sp, #0x30
       4:      	str	x30, [sp, #0x10]
       8:      	stp	x20, x19, [sp, #0x20]
       c:      	mov	x19, x0
      10:      	bl	0x10 <tracepoint__syscalls__sys_enter_open+0x10>
      14:      	str	w0, [sp, #0x1c]
      18:      	adrp	x8, 0x0 <tracepoint__syscalls__sys_enter_open>
      1c:      	ldr	x8, [x8]
      20:      	ldr	w9, [x8]
      24:      	cbz	w9, 0x38 <tracepoint__syscalls__sys_enter_open+0x38>
      28:      	ldr	w8, [x8]
      2c:      	lsr	x9, x0, #32
      30:      	cmp	w8, w9
      34:      	b.ne	0x9c <tracepoint__syscalls__sys_enter_open+0x9c>
      38:      	adrp	x8, 0x0 <tracepoint__syscalls__sys_enter_open>
      3c:      	ldr	x8, [x8]
      40:      	ldr	w9, [x8]
      44:      	cbz	w9, 0x54 <tracepoint__syscalls__sys_enter_open+0x54>
      48:      	ldr	w8, [x8]
      4c:      	cmp	w8, w0
      50:      	b.ne	0x9c <tracepoint__syscalls__sys_enter_open+0x9c>
      54:      	adrp	x20, 0x0 <tracepoint__syscalls__sys_enter_open>
      58:      	ldr	x20, [x20]
      5c:      	ldr	w8, [x20]
      60:      	cmn	w8, #0x1
      64:      	b.eq	0x78 <tracepoint__syscalls__sys_enter_open+0x78>
      68:      	bl	0x68 <tracepoint__syscalls__sys_enter_open+0x68>
      6c:      	ldr	w8, [x20]
      70:      	cmp	w8, w0
      74:      	b.ne	0x9c <tracepoint__syscalls__sys_enter_open+0x9c>
      78:      	ldp	x8, x9, [x19, #0x10]
      7c:      	adrp	x0, 0x0 <tracepoint__syscalls__sys_enter_open>
      80:      	add	x1, sp, #0x1c
      84:      	mov	x2, sp
      88:      	mov	x3, xzr
      8c:      	stp	x8, xzr, [sp]
      90:      	str	w9, [sp, #0x8]
      94:      	ldr	x0, [x0]
      98:      	bl	0x98 <tracepoint__syscalls__sys_enter_open+0x98>
      9c:      	ldp	x20, x19, [sp, #0x20]
      a0:      	mov	w0, wzr
      a4:      	ldr	x30, [sp, #0x10]
      a8:      	add	sp, sp, #0x30
      ac:      	ret

Disassembly of section tracepoint/syscalls/sys_enter_openat:

0000000000000000 <tracepoint__syscalls__sys_enter_openat>:
       0:      	sub	sp, sp, #0x30
       4:      	str	x30, [sp, #0x10]
       8:      	stp	x20, x19, [sp, #0x20]
       c:      	mov	x19, x0
      10:      	bl	0x10 <tracepoint__syscalls__sys_enter_openat+0x10>
      14:      	str	w0, [sp, #0x1c]
      18:      	adrp	x8, 0x0 <tracepoint__syscalls__sys_enter_openat>
      1c:      	ldr	x8, [x8]
      20:      	ldr	w9, [x8]
      24:      	cbz	w9, 0x38 <tracepoint__syscalls__sys_enter_openat+0x38>
      28:      	ldr	w8, [x8]
      2c:      	lsr	x9, x0, #32
      30:      	cmp	w8, w9
      34:      	b.ne	0x9c <tracepoint__syscalls__sys_enter_openat+0x9c>
      38:      	adrp	x8, 0x0 <tracepoint__syscalls__sys_enter_openat>
      3c:      	ldr	x8, [x8]
      40:      	ldr	w9, [x8]
      44:      	cbz	w9, 0x54 <tracepoint__syscalls__sys_enter_openat+0x54>
      48:      	ldr	w8, [x8]
      4c:      	cmp	w8, w0
      50:      	b.ne	0x9c <tracepoint__syscalls__sys_enter_openat+0x9c>
      54:      	adrp	x20, 0x0 <tracepoint__syscalls__sys_enter_openat>
      58:      	ldr	x20, [x20]
      5c:      	ldr	w8, [x20]
      60:      	cmn	w8, #0x1
      64:      	b.eq	0x78 <tracepoint__syscalls__sys_enter_openat+0x78>
      68:      	bl	0x68 <tracepoint__syscalls__sys_enter_openat+0x68>
      6c:      	ldr	w8, [x20]
      70:      	cmp	w8, w0
      74:      	b.ne	0x9c <tracepoint__syscalls__sys_enter_openat+0x9c>
      78:      	ldp	x8, x9, [x19, #0x18]
      7c:      	adrp	x0, 0x0 <tracepoint__syscalls__sys_enter_openat>
      80:      	add	x1, sp, #0x1c
      84:      	mov	x2, sp
      88:      	mov	x3, xzr
      8c:      	stp	x8, xzr, [sp]
      90:      	str	w9, [sp, #0x8]
      94:      	ldr	x0, [x0]
      98:      	bl	0x98 <tracepoint__syscalls__sys_enter_openat+0x98>
      9c:      	ldp	x20, x19, [sp, #0x20]
      a0:      	mov	w0, wzr
      a4:      	ldr	x30, [sp, #0x10]
      a8:      	add	sp, sp, #0x30
      ac:      	ret

Disassembly of section tracepoint/syscalls/sys_exit_open:

0000000000000000 <tracepoint__syscalls__sys_exit_open>:
       0:      	sub	sp, sp, #0x190
       4:      	stp	x29, x30, [sp, #0x160]
       8:      	stp	x22, x21, [sp, #0x170]
       c:      	stp	x20, x19, [sp, #0x180]
      10:      	mov	x19, x0
      14:      	add	x0, sp, #0x28
      18:      	mov	w1, wzr
      1c:      	mov	w2, #0x138              // =312
      20:      	bl	0x20 <tracepoint__syscalls__sys_exit_open+0x20>
      24:      	bl	0x24 <tracepoint__syscalls__sys_exit_open+0x24>
      28:      	str	w0, [sp, #0xc]
      2c:      	adrp	x0, 0x0 <tracepoint__syscalls__sys_exit_open>
      30:      	add	x1, sp, #0xc
      34:      	ldr	x0, [x0]
      38:      	bl	0x38 <tracepoint__syscalls__sys_exit_open+0x38>
      3c:      	cbz	x0, 0xe0 <tracepoint__syscalls__sys_exit_open+0xe0>
      40:      	adrp	x8, 0x0 <tracepoint__syscalls__sys_exit_open>
      44:      	ldr	w20, [x19, #0x10]
      48:      	ldr	x8, [x8]
      4c:      	ldrb	w8, [x8]
      50:      	cbz	w8, 0x58 <tracepoint__syscalls__sys_exit_open+0x58>
      54:      	tbz	w20, #0x1f, 0xd0 <tracepoint__syscalls__sys_exit_open+0xd0>
      58:      	mov	x21, x0
      5c:      	bl	0x5c <tracepoint__syscalls__sys_exit_open+0x5c>
      60:      	lsr	x8, x0, #32
      64:      	str	w8, [sp, #0x30]
      68:      	bl	0x68 <tracepoint__syscalls__sys_exit_open+0x68>
      6c:      	add	x22, sp, #0x28
      70:      	str	w0, [sp, #0x34]
      74:      	mov	w1, #0x10               // =16
      78:      	add	x0, x22, #0x28
      7c:      	bl	0x7c <tracepoint__syscalls__sys_exit_open+0x7c>
      80:      	ldr	x2, [x21]
      84:      	add	x0, x22, #0x38
      88:      	mov	w1, #0xff               // =255
      8c:      	bl	0x8c <tracepoint__syscalls__sys_exit_open+0x8c>
      90:      	ldr	w8, [x21, #0x8]
      94:      	add	x1, sp, #0x10
      98:      	mov	x0, x19
      9c:      	mov	w2, #0x18               // =24
      a0:      	stp	w20, w8, [sp, #0x38]
      a4:      	mov	w3, #0x100              // =256
      a8:      	bl	0xa8 <tracepoint__syscalls__sys_exit_open+0xa8>
      ac:      	ldp	x8, x9, [sp, #0x18]
      b0:      	adrp	x1, 0x0 <tracepoint__syscalls__sys_exit_open>
      b4:      	add	x3, sp, #0x28
      b8:      	mov	x0, x19
      bc:      	mov	w2, #-0x1               // =-1
      c0:      	mov	w4, #0x138              // =312
      c4:      	stp	x8, x9, [sp, #0x40]
      c8:      	ldr	x1, [x1]
      cc:      	bl	0xcc <tracepoint__syscalls__sys_exit_open+0xcc>
      d0:      	adrp	x0, 0x0 <tracepoint__syscalls__sys_exit_open>
      d4:      	add	x1, sp, #0xc
      d8:      	ldr	x0, [x0]
      dc:      	bl	0xdc <tracepoint__syscalls__sys_exit_open+0xdc>
      e0:      	ldp	x20, x19, [sp, #0x180]
      e4:      	mov	w0, wzr
      e8:      	ldp	x22, x21, [sp, #0x170]
      ec:      	ldp	x29, x30, [sp, #0x160]
      f0:      	add	sp, sp, #0x190
      f4:      	ret

Disassembly of section tracepoint/syscalls/sys_exit_openat:

0000000000000000 <tracepoint__syscalls__sys_exit_openat>:
       0:      	sub	sp, sp, #0x190
       4:      	stp	x29, x30, [sp, #0x160]
       8:      	stp	x22, x21, [sp, #0x170]
       c:      	stp	x20, x19, [sp, #0x180]
      10:      	mov	x19, x0
      14:      	add	x0, sp, #0x28
      18:      	mov	w1, wzr
      1c:      	mov	w2, #0x138              // =312
      20:      	bl	0x20 <tracepoint__syscalls__sys_exit_openat+0x20>
      24:      	bl	0x24 <tracepoint__syscalls__sys_exit_openat+0x24>
      28:      	str	w0, [sp, #0xc]
      2c:      	adrp	x0, 0x0 <tracepoint__syscalls__sys_exit_openat>
      30:      	add	x1, sp, #0xc
      34:      	ldr	x0, [x0]
      38:      	bl	0x38 <tracepoint__syscalls__sys_exit_openat+0x38>
      3c:      	cbz	x0, 0xe0 <tracepoint__syscalls__sys_exit_openat+0xe0>
      40:      	adrp	x8, 0x0 <tracepoint__syscalls__sys_exit_openat>
      44:      	ldr	w20, [x19, #0x10]
      48:      	ldr	x8, [x8]
      4c:      	ldrb	w8, [x8]
      50:      	cbz	w8, 0x58 <tracepoint__syscalls__sys_exit_openat+0x58>
      54:      	tbz	w20, #0x1f, 0xd0 <tracepoint__syscalls__sys_exit_openat+0xd0>
      58:      	mov	x21, x0
      5c:      	bl	0x5c <tracepoint__syscalls__sys_exit_openat+0x5c>
      60:      	lsr	x8, x0, #32
      64:      	str	w8, [sp, #0x30]
      68:      	bl	0x68 <tracepoint__syscalls__sys_exit_openat+0x68>
      6c:      	add	x22, sp, #0x28
      70:      	str	w0, [sp, #0x34]
      74:      	mov	w1, #0x10               // =16
      78:      	add	x0, x22, #0x28
      7c:      	bl	0x7c <tracepoint__syscalls__sys_exit_openat+0x7c>
      80:      	ldr	x2, [x21]
      84:      	add	x0, x22, #0x38
      88:      	mov	w1, #0xff               // =255
      8c:      	bl	0x8c <tracepoint__syscalls__sys_exit_openat+0x8c>
      90:      	ldr	w8, [x21, #0x8]
      94:      	add	x1, sp, #0x10
      98:      	mov	x0, x19
      9c:      	mov	w2, #0x18               // =24
      a0:      	stp	w20, w8, [sp, #0x38]
      a4:      	mov	w3, #0x100              // =256
      a8:      	bl	0xa8 <tracepoint__syscalls__sys_exit_openat+0xa8>
      ac:      	ldp	x8, x9, [sp, #0x18]
      b0:      	adrp	x1, 0x0 <tracepoint__syscalls__sys_exit_openat>
      b4:      	add	x3, sp, #0x28
      b8:      	mov	x0, x19
      bc:      	mov	w2, #-0x1               // =-1
      c0:      	mov	w4, #0x138              // =312
      c4:      	stp	x8, x9, [sp, #0x40]
      c8:      	ldr	x1, [x1]
      cc:      	bl	0xcc <tracepoint__syscalls__sys_exit_openat+0xcc>
      d0:      	adrp	x0, 0x0 <tracepoint__syscalls__sys_exit_openat>
      d4:      	add	x1, sp, #0xc
      d8:      	ldr	x0, [x0]
      dc:      	bl	0xdc <tracepoint__syscalls__sys_exit_openat+0xdc>
      e0:      	ldp	x20, x19, [sp, #0x180]
      e4:      	mov	w0, wzr
      e8:      	ldp	x22, x21, [sp, #0x170]
      ec:      	ldp	x29, x30, [sp, #0x160]
      f0:      	add	sp, sp, #0x190
      f4:      	ret
