
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_retuprobe_v53.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	cbz	x2, 0x8c <native_bpf_strncasestr+0x8c>
       4:      	mov	x8, x0
       8:      	mov	x0, xzr
       c:      	mov	x9, x2
      10:      	b	0x34 <native_bpf_strncasestr+0x34>
      14:      	nop
      18:      	nop
      1c:      	nop
      20:      	add	x0, x0, #0x1
      24:      	sub	x9, x9, #0x1
      28:      	add	x8, x8, #0x1
      2c:      	cmp	x0, x2
      30:      	b.eq	0x8c <native_bpf_strncasestr+0x8c>
      34:      	mov	x10, xzr
      38:      	nop
      3c:      	nop
      40:      	cmp	x9, x10
      44:      	b.eq	0x20 <native_bpf_strncasestr+0x20>
      48:      	ldrb	w11, [x1, x10]
      4c:      	cbz	w11, 0x90 <native_bpf_strncasestr+0x90>
      50:      	ldrb	w12, [x8, x10]
      54:      	sub	w13, w12, #0x41
      58:      	orr	w14, w12, #0x20
      5c:      	cmp	w13, #0x1a
      60:      	sub	w13, w11, #0x41
      64:      	csel	w12, w14, w12, lo
      68:      	orr	w14, w11, #0x20
      6c:      	cmp	w13, #0x1a
      70:      	csel	w11, w14, w11, lo
      74:      	cmp	w12, w11
      78:      	b.ne	0x20 <native_bpf_strncasestr+0x20>
      7c:      	cmp	x10, #0x63
      80:      	add	x10, x10, #0x1
      84:      	b.lo	0x40 <native_bpf_strncasestr+0x40>
      88:      	b	0x20 <native_bpf_strncasestr+0x20>
      8c:      	mov	w0, #-0x1               // =-1
      90:      	ret

Disassembly of section uprobe:

0000000000000000 <generic_retuprobe_filter_arg>:
       0:      	sub	sp, sp, #0xf0
       4:      	str	x29, [sp, #0xa0]
       8:      	stp	x30, x25, [sp, #0xb0]
       c:      	stp	x24, x23, [sp, #0xc0]
      10:      	stp	x22, x21, [sp, #0xd0]
      14:      	stp	x20, x19, [sp, #0xe0]
      18:      	mov	x21, x0
      1c:      	str	wzr, [sp, #0xa8]
      20:      	adrp	x0, 0x0 <generic_retuprobe_filter_arg>
      24:      	mov	w8, #0x1                // =1
      28:      	ldr	x0, [x0]
      2c:      	add	x9, sp, #0xa8
      30:      	add	x1, sp, #0xa8
      34:      	blr	x8
      38:      	cbz	x0, 0x2d54 <generic_retuprobe_filter_arg+0x2d54>
      3c:      	mov	w8, #0x5ec1             // =24257
      40:      	mov	x20, x0
      44:      	add	x19, x0, x8
      48:      	mov	w8, #0x5ef8             // =24312
      4c:      	add	x1, x0, x8
      50:      	adrp	x0, 0x0 <generic_retuprobe_filter_arg>
      54:      	ldur	w22, [x19, #0x3f]
      58:      	mov	w8, #0x1                // =1
      5c:      	ldr	x0, [x0]
      60:      	blr	x8
      64:      	cbz	x0, 0x2d38 <generic_retuprobe_filter_arg+0x2d38>
      68:      	ldrb	w8, [x19, #0x1f]
      6c:      	cbz	w8, 0x2d38 <generic_retuprobe_filter_arg+0x2d38>
      70:      	and	x8, x22, #0x7
      74:      	mov	w10, #0x5ec1            // =24257
      78:      	str	x22, [sp, #0x58]
      7c:      	add	x9, x20, x8
      80:      	ldrb	w9, [x9, x10]
      84:      	cbz	w9, 0xc4 <generic_retuprobe_filter_arg+0xc4>
      88:      	lsl	w8, w8, #2
      8c:      	add	x8, x8, #0x4
      90:      	ldr	w9, [x8, x0]
      94:      	add	x8, x8, x9
      98:      	add	x12, x8, #0x4
      9c:      	and	x8, x12, #0x3ff
      a0:      	add	x16, x0, x8
      a4:      	str	x8, [sp, #0x40]
      a8:      	ldr	w8, [x16]
      ac:      	cmp	w8, #0x19
      b0:      	b.hs	0x110 <generic_retuprobe_filter_arg+0x110>
      b4:      	ldr	x8, [sp, #0x40]
      b8:      	cmp	w8, #0x1
      bc:      	b.eq	0x2d38 <generic_retuprobe_filter_arg+0x2d38>
      c0:      	cbnz	w8, 0x2d14 <generic_retuprobe_filter_arg+0x2d14>
      c4:      	ldr	x8, [sp, #0x58]
      c8:      	cmp	w8, #0x1
      cc:      	b.gt	0xe8 <generic_retuprobe_filter_arg+0xe8>
      d0:      	cmn	w8, #0x1
      d4:      	b.eq	0x2d74 <generic_retuprobe_filter_arg+0x2d74>
      d8:      	cbz	w8, 0x2d84 <generic_retuprobe_filter_arg+0x2d84>
      dc:      	cmp	w8, #0x1
      e0:      	b.eq	0x2d94 <generic_retuprobe_filter_arg+0x2d94>
      e4:      	b	0x100 <generic_retuprobe_filter_arg+0x100>
      e8:      	cmp	w8, #0x2
      ec:      	b.eq	0x2da4 <generic_retuprobe_filter_arg+0x2da4>
      f0:      	cmp	w8, #0x3
      f4:      	b.eq	0x2db4 <generic_retuprobe_filter_arg+0x2db4>
      f8:      	cmp	w8, #0x4
      fc:      	b.eq	0x2dc4 <generic_retuprobe_filter_arg+0x2dc4>
     100:      	cmp	w8, #0x4
     104:      	b.gt	0x2df0 <generic_retuprobe_filter_arg+0x2df0>
     108:      	add	w8, w8, #0x1
     10c:      	b	0x2dd0 <generic_retuprobe_filter_arg+0x2dd0>
     110:      	mov	x25, xzr
     114:      	mov	w17, #0x1               // =1
     118:      	stp	x19, x0, [sp, #0x30]
     11c:      	stp	x12, x16, [sp, #0x48]
     120:      	b	0x14c <generic_retuprobe_filter_arg+0x14c>
     124:      	orr	w8, w8, #0x2
     128:      	cmp	w8, #0x6
     12c:      	b.ne	0xc4 <generic_retuprobe_filter_arg+0xc4>
     130:      	nop
     134:      	nop
     138:      	nop
     13c:      	nop
     140:      	add	x25, x25, #0x1
     144:      	cmp	x25, #0x5
     148:      	b.eq	0xb4 <generic_retuprobe_filter_arg+0xb4>
     14c:      	add	x8, x16, x25, lsl #2
     150:      	ldr	w8, [x8, #0x4]
     154:      	tst	w8, #0x3ff
     158:      	b.eq	0xb4 <generic_retuprobe_filter_arg+0xb4>
     15c:      	add	w8, w12, w8
     160:      	and	x8, x8, #0x3ff
     164:      	add	x29, x0, x8
     168:      	ldr	w8, [x29, #0x4]
     16c:      	cmp	w8, #0x23
     170:      	b.eq	0xc4 <generic_retuprobe_filter_arg+0xc4>
     174:      	ldr	w9, [x29]
     178:      	cmp	w9, #0x4
     17c:      	b.hi	0xc4 <generic_retuprobe_filter_arg+0xc4>
     180:      	add	x10, x20, x9, lsl #2
     184:      	mov	w11, #0x5ea0            // =24224
     188:      	ldr	w10, [x10, x11]
     18c:      	cbnz	w10, 0xc4 <generic_retuprobe_filter_arg+0xc4>
     190:      	add	x9, x20, x9, lsl #3
     194:      	ldr	x9, [x9, #0x5e78]
     198:      	and	x9, x9, #0x7ff
     19c:      	add	x9, x20, x9
     1a0:      	add	x22, x9, #0x90
     1a4:      	ldr	w9, [x29, #0xc]
     1a8:      	cmp	w9, #0x10
     1ac:      	b.le	0x1fc <generic_retuprobe_filter_arg+0x1fc>
     1b0:      	sub	w10, w9, #0x1c
     1b4:      	cmp	w10, #0x9
     1b8:      	b.lo	0x368 <generic_retuprobe_filter_arg+0x368>
     1bc:      	cmp	w9, #0x2a
     1c0:      	b.hi	0x1ec <generic_retuprobe_filter_arg+0x1ec>
     1c4:      	lsl	x10, x17, x9
     1c8:      	tst	x10, #0xc000000000
     1cc:      	b.ne	0x224 <generic_retuprobe_filter_arg+0x224>
     1d0:      	lsl	x10, x17, x9
     1d4:      	tst	x10, #0x30000000000
     1d8:      	b.ne	0x610 <generic_retuprobe_filter_arg+0x610>
     1dc:      	lsl	x10, x17, x9
     1e0:      	mov	x11, #0x42000000000     // =4535485464576
     1e4:      	tst	x10, x11
     1e8:      	b.ne	0x26c <generic_retuprobe_filter_arg+0x26c>
     1ec:      	cmp	w9, #0x11
     1f0:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
     1f4:      	add	x22, x22, #0x4
     1f8:      	b	0x26c <generic_retuprobe_filter_arg+0x26c>
     1fc:      	cmp	w9, #0x6
     200:      	b.gt	0x254 <generic_retuprobe_filter_arg+0x254>
     204:      	cmp	w9, #0x3
     208:      	b.le	0x324 <generic_retuprobe_filter_arg+0x324>
     20c:      	cmp	w9, #0x4
     210:      	b.eq	0x368 <generic_retuprobe_filter_arg+0x368>
     214:      	cmp	w9, #0x5
     218:      	b.eq	0x610 <generic_retuprobe_filter_arg+0x610>
     21c:      	cmp	w9, #0x6
     220:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
     224:      	ldr	w24, [x22], #0x4
     228:      	mov	x23, xzr
     22c:      	cmp	w8, #0x19
     230:      	b.gt	0x4c4 <generic_retuprobe_filter_arg+0x4c4>
     234:      	sub	w9, w8, #0x3
     238:      	cmp	w9, #0x2
     23c:      	b.lo	0xbd0 <generic_retuprobe_filter_arg+0xbd0>
     240:      	cmp	w8, #0x8
     244:      	b.eq	0xb38 <generic_retuprobe_filter_arg+0xb38>
     248:      	cmp	w8, #0x9
     24c:      	b.eq	0x4dc <generic_retuprobe_filter_arg+0x4dc>
     250:      	b	0x2140 <generic_retuprobe_filter_arg+0x2140>
     254:      	sub	w10, w9, #0xa
     258:      	cmp	w10, #0x4
     25c:      	b.lo	0x368 <generic_retuprobe_filter_arg+0x368>
     260:      	sub	w10, w9, #0xf
     264:      	cmp	w10, #0x2
     268:      	b.hs	0x608 <generic_retuprobe_filter_arg+0x608>
     26c:      	ldr	w24, [x22]
     270:      	and	w9, w8, #0xfffffffe
     274:      	cmp	w9, #0x24
     278:      	b.eq	0x280 <generic_retuprobe_filter_arg+0x280>
     27c:      	cbz	w24, 0xc4 <generic_retuprobe_filter_arg+0xc4>
     280:      	cmp	w8, #0x25
     284:      	b.hi	0x5a8 <generic_retuprobe_filter_arg+0x5a8>
     288:      	mov	w10, #0x100             // =256
     28c:      	lsl	x9, x17, x8
     290:      	movk	w10, #0x400, lsl #16
     294:      	tst	x9, x10
     298:      	b.ne	0x868 <generic_retuprobe_filter_arg+0x868>
     29c:      	mov	w10, #0x200             // =512
     2a0:      	lsl	x9, x17, x8
     2a4:      	movk	w10, #0x800, lsl #16
     2a8:      	tst	x9, x10
     2ac:      	b.ne	0x798 <generic_retuprobe_filter_arg+0x798>
     2b0:      	lsl	x9, x17, x8
     2b4:      	tst	x9, #0x3000000000
     2b8:      	b.eq	0x5a8 <generic_retuprobe_filter_arg+0x5a8>
     2bc:      	cmp	w24, #0x1fe
     2c0:      	strh	wzr, [sp, #0x60]
     2c4:      	b.hi	0x5c0 <generic_retuprobe_filter_arg+0x5c0>
     2c8:      	add	x8, x22, #0x4
     2cc:      	mov	w10, #0x4               // =4
     2d0:      	add	x11, sp, #0x60
     2d4:      	mov	w12, #0x2               // =2
     2d8:      	add	x0, sp, #0x60
     2dc:      	mov	w1, #0x2                // =2
     2e0:      	add	x9, x8, x24
     2e4:      	add	x9, x9, #0x4
     2e8:      	ldr	w9, [x22]
     2ec:      	add	x8, x8, x9
     2f0:      	add	x2, x8, #0x4
     2f4:      	blr	x10
     2f8:      	ldr	w9, [x29, #0x10]
     2fc:      	cbz	w9, 0x2808 <generic_retuprobe_filter_arg+0x2808>
     300:      	ldrh	w8, [sp, #0x60]
     304:      	ldr	x0, [sp, #0x38]
     308:      	mov	w17, #0x1               // =1
     30c:      	and	w8, w8, #0xf000
     310:      	ldp	x12, x16, [sp, #0x48]
     314:      	cmp	w9, w8
     318:      	b.ne	0x18f8 <generic_retuprobe_filter_arg+0x18f8>
     31c:      	mov	w23, #0x1               // =1
     320:      	b	0x2818 <generic_retuprobe_filter_arg+0x2818>
     324:      	cmp	w9, #0x1
     328:      	b.eq	0x368 <generic_retuprobe_filter_arg+0x368>
     32c:      	cmp	w9, #0x2
     330:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
     334:      	add	x24, x22, #0x8
     338:      	ldr	w22, [x22, #0x4]
     33c:      	mov	x23, xzr
     340:      	cmp	w8, #0x19
     344:      	b.gt	0xc34 <generic_retuprobe_filter_arg+0xc34>
     348:      	sub	w9, w8, #0x3
     34c:      	cmp	w9, #0x2
     350:      	b.lo	0x1388 <generic_retuprobe_filter_arg+0x1388>
     354:      	cmp	w8, #0x8
     358:      	b.eq	0x12fc <generic_retuprobe_filter_arg+0x12fc>
     35c:      	cmp	w8, #0x9
     360:      	b.eq	0xc4c <generic_retuprobe_filter_arg+0xc4c>
     364:      	b	0x2c64 <generic_retuprobe_filter_arg+0x2c64>
     368:      	cmp	w9, #0xb
     36c:      	b.le	0x3dc <generic_retuprobe_filter_arg+0x3dc>
     370:      	cmp	w9, #0x24
     374:      	b.hi	0x424 <generic_retuprobe_filter_arg+0x424>
     378:      	lsl	x10, x17, x9
     37c:      	tst	x10, #0x1e00000000
     380:      	b.ne	0x3fc <generic_retuprobe_filter_arg+0x3fc>
     384:      	lsl	x10, x17, x9
     388:      	tst	x10, #0x60000000
     38c:      	b.ne	0x5c8 <generic_retuprobe_filter_arg+0x5c8>
     390:      	lsl	x10, x17, x9
     394:      	tst	x10, #0x180000000
     398:      	b.eq	0x424 <generic_retuprobe_filter_arg+0x424>
     39c:      	cmp	w8, #0x20
     3a0:      	b.hi	0xc4 <generic_retuprobe_filter_arg+0xc4>
     3a4:      	lsl	x9, x17, x8
     3a8:      	mov	w10, #0x101e            // =4126
     3ac:      	tst	x9, x10
     3b0:      	b.eq	0xd30 <generic_retuprobe_filter_arg+0xd30>
     3b4:      	ldr	w9, [x29, #0x10]
     3b8:      	cmp	w8, #0x2
     3bc:      	b.le	0x1228 <generic_retuprobe_filter_arg+0x1228>
     3c0:      	sub	w10, w8, #0x3
     3c4:      	cmp	w10, #0x2
     3c8:      	b.hs	0x17b4 <generic_retuprobe_filter_arg+0x17b4>
     3cc:      	ldrb	w10, [x22]
     3d0:      	cmp	w9, w10
     3d4:      	b.ne	0x1b44 <generic_retuprobe_filter_arg+0x1b44>
     3d8:      	b	0x2bdc <generic_retuprobe_filter_arg+0x2bdc>
     3dc:      	sub	w10, w9, #0xa
     3e0:      	cmp	w10, #0x2
     3e4:      	b.lo	0x6a0 <generic_retuprobe_filter_arg+0x6a0>
     3e8:      	cmp	w9, #0x1
     3ec:      	b.eq	0x430 <generic_retuprobe_filter_arg+0x430>
     3f0:      	cmp	w9, #0x4
     3f4:      	b.eq	0x430 <generic_retuprobe_filter_arg+0x430>
     3f8:      	b	0x140 <generic_retuprobe_filter_arg+0x140>
     3fc:      	cmp	w8, #0x9
     400:      	b.le	0x650 <generic_retuprobe_filter_arg+0x650>
     404:      	cmp	w8, #0x1d
     408:      	b.gt	0x9f4 <generic_retuprobe_filter_arg+0x9f4>
     40c:      	sub	w10, w8, #0xa
     410:      	cmp	w10, #0x2
     414:      	b.lo	0x72c <generic_retuprobe_filter_arg+0x72c>
     418:      	cmp	w8, #0xc
     41c:      	b.eq	0x6b8 <generic_retuprobe_filter_arg+0x6b8>
     420:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
     424:      	sub	w10, w9, #0xc
     428:      	cmp	w10, #0x2
     42c:      	b.hs	0x698 <generic_retuprobe_filter_arg+0x698>
     430:      	cmp	w8, #0x20
     434:      	b.hi	0xc4 <generic_retuprobe_filter_arg+0xc4>
     438:      	lsl	x10, x17, x8
     43c:      	mov	w11, #0x101e            // =4126
     440:      	tst	x10, x11
     444:      	b.eq	0x470 <generic_retuprobe_filter_arg+0x470>
     448:      	ldr	w10, [x29, #0x10]
     44c:      	cmp	w8, #0x2
     450:      	b.le	0x660 <generic_retuprobe_filter_arg+0x660>
     454:      	sub	w11, w8, #0x3
     458:      	cmp	w11, #0x2
     45c:      	b.hs	0xd18 <generic_retuprobe_filter_arg+0xd18>
     460:      	ldr	w11, [x22]
     464:      	cmp	w11, w10
     468:      	b.ne	0x1d88 <generic_retuprobe_filter_arg+0x1d88>
     46c:      	b	0x2bdc <generic_retuprobe_filter_arg+0x2bdc>
     470:      	lsl	x10, x17, x8
     474:      	tst	x10, #0xc00
     478:      	b.ne	0x900 <generic_retuprobe_filter_arg+0x900>
     47c:      	lsl	x10, x17, x8
     480:      	tst	x10, #0x180000000
     484:      	b.eq	0xc4 <generic_retuprobe_filter_arg+0xc4>
     488:      	cmp	w8, #0x1f
     48c:      	b.ne	0xe9c <generic_retuprobe_filter_arg+0xe9c>
     490:      	ldp	w11, w10, [x29, #0x10]
     494:      	cmp	w9, #0xc
     498:      	b.hi	0x1bd8 <generic_retuprobe_filter_arg+0x1bd8>
     49c:      	lsl	w8, w17, w9
     4a0:      	mov	w13, #0x1402            // =5122
     4a4:      	tst	w8, w13
     4a8:      	b.eq	0x1bd8 <generic_retuprobe_filter_arg+0x1bd8>
     4ac:      	ldr	w8, [x22]
     4b0:      	cmp	w11, w8
     4b4:      	b.gt	0x1bec <generic_retuprobe_filter_arg+0x1bec>
     4b8:      	cmp	w8, w10
     4bc:      	b.le	0x140 <generic_retuprobe_filter_arg+0x140>
     4c0:      	b	0x1bec <generic_retuprobe_filter_arg+0x1bec>
     4c4:      	cmp	w8, #0x20
     4c8:      	b.gt	0xa34 <generic_retuprobe_filter_arg+0xa34>
     4cc:      	cmp	w8, #0x1a
     4d0:      	b.eq	0xb38 <generic_retuprobe_filter_arg+0xb38>
     4d4:      	cmp	w8, #0x1b
     4d8:      	b.ne	0x2140 <generic_retuprobe_filter_arg+0x2140>
     4dc:      	ldr	w8, [x29, #0x10]
     4e0:      	str	wzr, [sp, #0x88]
     4e4:      	adrp	x0, 0x0 <generic_retuprobe_filter_arg>
     4e8:      	add	x9, sp, #0x60
     4ec:      	add	x1, sp, #0x60
     4f0:      	str	w8, [sp, #0x60]
     4f4:      	mov	w8, #0x1                // =1
     4f8:      	ldr	x0, [x0]
     4fc:      	blr	x8
     500:      	mov	x23, xzr
     504:      	cbz	w24, 0x1410 <generic_retuprobe_filter_arg+0x1410>
     508:      	cbz	x0, 0x1410 <generic_retuprobe_filter_arg+0x1410>
     50c:      	mov	x19, x0
     510:      	adrp	x0, 0x0 <generic_retuprobe_filter_arg>
     514:      	mov	w8, #0x1                // =1
     518:      	ldr	x0, [x0]
     51c:      	add	x9, sp, #0x88
     520:      	add	x1, sp, #0x88
     524:      	blr	x8
     528:      	cbz	x0, 0x1408 <generic_retuprobe_filter_arg+0x1408>
     52c:      	cmp	w24, #0x7f
     530:      	mov	w9, #0x7f               // =127
     534:      	mov	w11, #0x1               // =1
     538:      	mov	x1, x0
     53c:      	mov	x8, xzr
     540:      	sub	w12, w24, #0x2
     544:      	sub	w13, w24, #0x1
     548:      	csel	w9, w24, w9, lo
     54c:      	sub	x11, x11, x24
     550:      	lsl	w10, w9, #3
     554:      	mov	x9, x0
     558:      	str	w10, [x9], #0x5
     55c:      	neg	x10, x24
     560:      	add	w14, w13, w8
     564:      	cmp	x11, x8
     568:      	and	x14, x14, #0xfff
     56c:      	ldrb	w14, [x22, x14]
     570:      	sturb	w14, [x9, #-0x1]
     574:      	b.eq	0x59c <generic_retuprobe_filter_arg+0x59c>
     578:      	cmn	x8, #0x7e
     57c:      	b.eq	0x59c <generic_retuprobe_filter_arg+0x59c>
     580:      	add	w14, w12, w8
     584:      	sub	x8, x8, #0x2
     588:      	and	x14, x14, #0xfff
     58c:      	cmp	x10, x8
     590:      	ldrb	w14, [x22, x14]
     594:      	strb	w14, [x9], #0x2
     598:      	b.ne	0x560 <generic_retuprobe_filter_arg+0x560>
     59c:      	mov	w8, #0x1                // =1
     5a0:      	mov	x0, x19
     5a4:      	b	0xbc0 <generic_retuprobe_filter_arg+0xbc0>
     5a8:      	sub	w8, w8, #0x3
     5ac:      	cmp	w8, #0x2
     5b0:      	b.hs	0x5c0 <generic_retuprobe_filter_arg+0x5c0>
     5b4:      	cmp	w24, #0x1fe
     5b8:      	str	wzr, [sp, #0x88]
     5bc:      	b.ls	0xe38 <generic_retuprobe_filter_arg+0xe38>
     5c0:      	mov	x23, xzr
     5c4:      	b	0x2818 <generic_retuprobe_filter_arg+0x2818>
     5c8:      	cmp	w8, #0x20
     5cc:      	b.hi	0xc4 <generic_retuprobe_filter_arg+0xc4>
     5d0:      	lsl	x9, x17, x8
     5d4:      	mov	w10, #0x101e            // =4126
     5d8:      	tst	x9, x10
     5dc:      	b.eq	0xd5c <generic_retuprobe_filter_arg+0xd5c>
     5e0:      	ldr	w9, [x29, #0x10]
     5e4:      	cmp	w8, #0x2
     5e8:      	b.le	0x1248 <generic_retuprobe_filter_arg+0x1248>
     5ec:      	sub	w10, w8, #0x3
     5f0:      	cmp	w10, #0x2
     5f4:      	b.hs	0x17cc <generic_retuprobe_filter_arg+0x17cc>
     5f8:      	ldrh	w10, [x22]
     5fc:      	cmp	w9, w10
     600:      	b.ne	0x1b84 <generic_retuprobe_filter_arg+0x1b84>
     604:      	b	0x2bdc <generic_retuprobe_filter_arg+0x2bdc>
     608:      	cmp	w9, #0x7
     60c:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
     610:      	mov	x23, xzr
     614:      	cmp	w9, #0x27
     618:      	stp	xzr, xzr, [sp, #0x78]
     61c:      	str	xzr, [sp, #0x60]
     620:      	stp	xzr, xzr, [sp, #0x68]
     624:      	b.gt	0x638 <generic_retuprobe_filter_arg+0x638>
     628:      	cmp	w9, #0x5
     62c:      	b.eq	0x950 <generic_retuprobe_filter_arg+0x950>
     630:      	cmp	w9, #0x7
     634:      	b	0x644 <generic_retuprobe_filter_arg+0x644>
     638:      	cmp	w9, #0x28
     63c:      	b.eq	0x958 <generic_retuprobe_filter_arg+0x958>
     640:      	cmp	w9, #0x29
     644:      	mov	x10, x22
     648:      	b.eq	0x980 <generic_retuprobe_filter_arg+0x980>
     64c:      	b	0x2c94 <generic_retuprobe_filter_arg+0x2c94>
     650:      	sub	w10, w8, #0x1
     654:      	cmp	w10, #0x4
     658:      	b.lo	0x6b8 <generic_retuprobe_filter_arg+0x6b8>
     65c:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
     660:      	cmp	w8, #0x1
     664:      	b.eq	0x1004 <generic_retuprobe_filter_arg+0x1004>
     668:      	cmp	w8, #0x2
     66c:      	b.ne	0x1d88 <generic_retuprobe_filter_arg+0x1d88>
     670:      	cmp	w9, #0xc
     674:      	b.hi	0x1d7c <generic_retuprobe_filter_arg+0x1d7c>
     678:      	lsl	w11, w17, w9
     67c:      	mov	w13, #0x1402            // =5122
     680:      	tst	w11, w13
     684:      	b.eq	0x1d7c <generic_retuprobe_filter_arg+0x1d7c>
     688:      	ldr	w11, [x22]
     68c:      	cmp	w11, w10
     690:      	b.lt	0x140 <generic_retuprobe_filter_arg+0x140>
     694:      	b	0x1d88 <generic_retuprobe_filter_arg+0x1d88>
     698:      	cmp	w9, #0x1c
     69c:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
     6a0:      	cmp	w8, #0x20
     6a4:      	b.hi	0xc4 <generic_retuprobe_filter_arg+0xc4>
     6a8:      	lsl	x10, x17, x8
     6ac:      	mov	w11, #0x101e            // =4126
     6b0:      	tst	x10, x11
     6b4:      	b.eq	0x6e0 <generic_retuprobe_filter_arg+0x6e0>
     6b8:      	ldr	x10, [x29, #0x10]
     6bc:      	cmp	w8, #0x2
     6c0:      	b.le	0x6fc <generic_retuprobe_filter_arg+0x6fc>
     6c4:      	sub	w11, w8, #0x3
     6c8:      	cmp	w11, #0x2
     6cc:      	b.hs	0x938 <generic_retuprobe_filter_arg+0x938>
     6d0:      	ldr	x11, [x22]
     6d4:      	cmp	x11, x10
     6d8:      	b.ne	0x1728 <generic_retuprobe_filter_arg+0x1728>
     6dc:      	b	0x2bdc <generic_retuprobe_filter_arg+0x2bdc>
     6e0:      	lsl	x10, x17, x8
     6e4:      	tst	x10, #0xc00
     6e8:      	b.ne	0x72c <generic_retuprobe_filter_arg+0x72c>
     6ec:      	lsl	x10, x17, x8
     6f0:      	tst	x10, #0x180000000
     6f4:      	b.ne	0xa00 <generic_retuprobe_filter_arg+0xa00>
     6f8:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
     6fc:      	cmp	w8, #0x1
     700:      	b.eq	0xe00 <generic_retuprobe_filter_arg+0xe00>
     704:      	cmp	w8, #0x2
     708:      	b.ne	0x1728 <generic_retuprobe_filter_arg+0x1728>
     70c:      	cmp	w9, #0xc
     710:      	b.eq	0x71c <generic_retuprobe_filter_arg+0x71c>
     714:      	cmp	w9, #0xa
     718:      	b.ne	0x171c <generic_retuprobe_filter_arg+0x171c>
     71c:      	ldr	x11, [x22]
     720:      	cmp	x11, x10
     724:      	b.lt	0x140 <generic_retuprobe_filter_arg+0x140>
     728:      	b	0x1728 <generic_retuprobe_filter_arg+0x1728>
     72c:      	ldrb	w8, [x29, #0x10]
     730:      	adrp	x0, 0x0 <generic_retuprobe_filter_arg>
     734:      	add	x9, sp, #0x88
     738:      	add	x1, sp, #0x88
     73c:      	str	w8, [sp, #0x88]
     740:      	mov	w8, #0x1                // =1
     744:      	ldr	x0, [x0]
     748:      	blr	x8
     74c:      	cbz	x0, 0xe20 <generic_retuprobe_filter_arg+0xe20>
     750:      	ldr	x8, [x22]
     754:      	add	x9, sp, #0x60
     758:      	add	x1, sp, #0x60
     75c:      	str	x8, [sp, #0x60]
     760:      	mov	w8, #0x1                // =1
     764:      	blr	x8
     768:      	ldr	w8, [x29, #0x4]
     76c:      	cmp	w8, #0xb
     770:      	b.eq	0x12dc <generic_retuprobe_filter_arg+0x12dc>
     774:      	ldp	x12, x16, [sp, #0x48]
     778:      	cmp	w8, #0xa
     77c:      	mov	w17, #0x1               // =1
     780:      	b.eq	0x1590 <generic_retuprobe_filter_arg+0x1590>
     784:      	ldr	x0, [sp, #0x38]
     788:      	mov	w23, wzr
     78c:      	mov	w8, wzr
     790:      	cbnz	x23, 0x140 <generic_retuprobe_filter_arg+0x140>
     794:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
     798:      	ldr	w8, [x29, #0x10]
     79c:      	str	wzr, [sp, #0x88]
     7a0:      	adrp	x0, 0x0 <generic_retuprobe_filter_arg>
     7a4:      	add	x9, sp, #0x60
     7a8:      	add	x1, sp, #0x60
     7ac:      	str	w8, [sp, #0x60]
     7b0:      	mov	w8, #0x1                // =1
     7b4:      	ldr	x0, [x0]
     7b8:      	blr	x8
     7bc:      	mov	x23, xzr
     7c0:      	cbz	w24, 0x280c <generic_retuprobe_filter_arg+0x280c>
     7c4:      	cbz	x0, 0x280c <generic_retuprobe_filter_arg+0x280c>
     7c8:      	mov	x19, x0
     7cc:      	adrp	x0, 0x0 <generic_retuprobe_filter_arg>
     7d0:      	mov	w8, #0x1                // =1
     7d4:      	ldr	x0, [x0]
     7d8:      	add	x9, sp, #0x88
     7dc:      	add	x1, sp, #0x88
     7e0:      	blr	x8
     7e4:      	cbz	x0, 0x1948 <generic_retuprobe_filter_arg+0x1948>
     7e8:      	cmp	w24, #0x7f
     7ec:      	mov	w10, #0x7f              // =127
     7f0:      	mov	w12, #0x1               // =1
     7f4:      	mov	x1, x0
     7f8:      	mov	x8, xzr
     7fc:      	add	x9, x22, #0x4
     800:      	sub	w13, w24, #0x2
     804:      	sub	w14, w24, #0x1
     808:      	csel	w10, w24, w10, lo
     80c:      	sub	x12, x12, x24
     810:      	lsl	w11, w10, #3
     814:      	mov	x10, x0
     818:      	str	w11, [x10], #0x5
     81c:      	neg	x11, x24
     820:      	add	w15, w14, w8
     824:      	cmp	x12, x8
     828:      	and	x15, x15, #0xfff
     82c:      	ldrb	w15, [x9, x15]
     830:      	sturb	w15, [x10, #-0x1]
     834:      	b.eq	0x85c <generic_retuprobe_filter_arg+0x85c>
     838:      	cmn	x8, #0x7e
     83c:      	b.eq	0x85c <generic_retuprobe_filter_arg+0x85c>
     840:      	add	w15, w13, w8
     844:      	sub	x8, x8, #0x2
     848:      	and	x15, x15, #0xfff
     84c:      	cmp	x11, x8
     850:      	ldrb	w15, [x9, x15]
     854:      	strb	w15, [x10], #0x2
     858:      	b.ne	0x820 <generic_retuprobe_filter_arg+0x820>
     85c:      	mov	w8, #0x1                // =1
     860:      	mov	x0, x19
     864:      	b	0x8f0 <generic_retuprobe_filter_arg+0x8f0>
     868:      	ldr	w8, [x29, #0x10]
     86c:      	str	wzr, [sp, #0x88]
     870:      	adrp	x0, 0x0 <generic_retuprobe_filter_arg>
     874:      	add	x9, sp, #0x60
     878:      	add	x1, sp, #0x60
     87c:      	str	w8, [sp, #0x60]
     880:      	mov	w8, #0x1                // =1
     884:      	ldr	x0, [x0]
     888:      	blr	x8
     88c:      	mov	x23, xzr
     890:      	cbz	w24, 0x280c <generic_retuprobe_filter_arg+0x280c>
     894:      	cbz	x0, 0x280c <generic_retuprobe_filter_arg+0x280c>
     898:      	mov	x19, x0
     89c:      	adrp	x0, 0x0 <generic_retuprobe_filter_arg>
     8a0:      	mov	w8, #0x1                // =1
     8a4:      	ldr	x0, [x0]
     8a8:      	add	x9, sp, #0x88
     8ac:      	add	x1, sp, #0x88
     8b0:      	blr	x8
     8b4:      	cbz	x0, 0x1948 <generic_retuprobe_filter_arg+0x1948>
     8b8:      	cmp	w24, #0xff
     8bc:      	mov	w8, #0xff               // =255
     8c0:      	add	x2, x22, #0x4
     8c4:      	mov	x22, x0
     8c8:      	csel	w1, w24, w8, lo
     8cc:      	mov	x8, x0
     8d0:      	lsl	w9, w1, #3
     8d4:      	str	w9, [x8], #0x4
     8d8:      	mov	w9, #0x4                // =4
     8dc:      	mov	x0, x8
     8e0:      	blr	x9
     8e4:      	mov	w8, #0x1                // =1
     8e8:      	mov	x0, x19
     8ec:      	mov	x1, x22
     8f0:      	blr	x8
     8f4:      	cmp	x0, #0x0
     8f8:      	cset	w23, ne
     8fc:      	b	0x194c <generic_retuprobe_filter_arg+0x194c>
     900:      	ldrb	w8, [x29, #0x10]
     904:      	adrp	x0, 0x0 <generic_retuprobe_filter_arg>
     908:      	add	x9, sp, #0x88
     90c:      	add	x1, sp, #0x88
     910:      	str	w8, [sp, #0x88]
     914:      	mov	w8, #0x1                // =1
     918:      	ldr	x0, [x0]
     91c:      	blr	x8
     920:      	cbz	x0, 0x16cc <generic_retuprobe_filter_arg+0x16cc>
     924:      	ldr	w8, [x22]
     928:      	add	x9, sp, #0x60
     92c:      	str	x8, [sp, #0x60]
     930:      	mov	w8, #0x1                // =1
     934:      	b	0x12d4 <generic_retuprobe_filter_arg+0x12d4>
     938:      	cmp	w8, #0xc
     93c:      	b.ne	0x1728 <generic_retuprobe_filter_arg+0x1728>
     940:      	ldr	x11, [x22]
     944:      	tst	x11, x10
     948:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
     94c:      	b	0x1728 <generic_retuprobe_filter_arg+0x1728>
     950:      	mov	x10, xzr
     954:      	b	0x980 <generic_retuprobe_filter_arg+0x980>
     958:      	ldrh	w11, [x22]
     95c:      	mov	x10, xzr
     960:      	strh	w11, [sp, #0x86]
     964:      	ldrh	w11, [x22, #0x2]
     968:      	strh	w11, [sp, #0x80]
     96c:      	ldr	x11, [x22, #0x8]
     970:      	str	x11, [sp, #0x60]
     974:      	ldr	x11, [x22, #0x10]
     978:      	add	x22, sp, #0x60
     97c:      	str	x11, [sp, #0x68]
     980:      	mov	x23, xzr
     984:      	cmp	w8, #0x13
     988:      	b.le	0x9b0 <generic_retuprobe_filter_arg+0x9b0>
     98c:      	cmp	w8, #0x17
     990:      	b.gt	0x9d8 <generic_retuprobe_filter_arg+0x9d8>
     994:      	sub	w9, w8, #0x14
     998:      	cmp	w9, #0x2
     99c:      	b.lo	0xef4 <generic_retuprobe_filter_arg+0xef4>
     9a0:      	sub	w9, w8, #0x16
     9a4:      	cmp	w9, #0x2
     9a8:      	b.lo	0xedc <generic_retuprobe_filter_arg+0xedc>
     9ac:      	b	0x2c94 <generic_retuprobe_filter_arg+0x2c94>
     9b0:      	cmp	w8, #0xf
     9b4:      	b.le	0xc18 <generic_retuprobe_filter_arg+0xc18>
     9b8:      	cmp	w8, #0x11
     9bc:      	b.gt	0xecc <generic_retuprobe_filter_arg+0xecc>
     9c0:      	cmp	w8, #0x10
     9c4:      	b.eq	0xedc <generic_retuprobe_filter_arg+0xedc>
     9c8:      	cmp	w8, #0x11
     9cc:      	b.ne	0x2c94 <generic_retuprobe_filter_arg+0x2c94>
     9d0:      	ldrh	w23, [x22, #0x24]
     9d4:      	b	0x1650 <generic_retuprobe_filter_arg+0x1650>
     9d8:      	cmp	w8, #0x1b
     9dc:      	b.gt	0xf0c <generic_retuprobe_filter_arg+0xf0c>
     9e0:      	cmp	w8, #0x18
     9e4:      	b.eq	0xf40 <generic_retuprobe_filter_arg+0xf40>
     9e8:      	cmp	w8, #0x19
     9ec:      	b.eq	0xf30 <generic_retuprobe_filter_arg+0xf30>
     9f0:      	b	0x2c94 <generic_retuprobe_filter_arg+0x2c94>
     9f4:      	sub	w10, w8, #0x1f
     9f8:      	cmp	w10, #0x2
     9fc:      	b.hs	0x139c <generic_retuprobe_filter_arg+0x139c>
     a00:      	cmp	w8, #0x1f
     a04:      	b.ne	0xbf0 <generic_retuprobe_filter_arg+0xbf0>
     a08:      	ldp	x11, x10, [x29, #0x10]
     a0c:      	cmp	w9, #0xa
     a10:      	b.eq	0xa1c <generic_retuprobe_filter_arg+0xa1c>
     a14:      	cmp	w9, #0xc
     a18:      	b.ne	0x15c0 <generic_retuprobe_filter_arg+0x15c0>
     a1c:      	ldr	x8, [x22]
     a20:      	cmp	x11, x8
     a24:      	b.gt	0x15d4 <generic_retuprobe_filter_arg+0x15d4>
     a28:      	cmp	x8, x10
     a2c:      	b.le	0x140 <generic_retuprobe_filter_arg+0x140>
     a30:      	b	0x15d4 <generic_retuprobe_filter_arg+0x15d4>
     a34:      	cmp	w8, #0x21
     a38:      	b.eq	0x102c <generic_retuprobe_filter_arg+0x102c>
     a3c:      	cmp	w8, #0x22
     a40:      	b.ne	0x2140 <generic_retuprobe_filter_arg+0x2140>
     a44:      	mov	x19, x21
     a48:      	mov	x23, xzr
     a4c:      	mov	w21, wzr
     a50:      	add	x8, x29, #0x10
     a54:      	str	x8, [sp, #0x28]
     a58:      	ldr	x8, [sp, #0x28]
     a5c:      	adrp	x0, 0x0 <generic_retuprobe_filter_arg>
     a60:      	add	x9, sp, #0x60
     a64:      	add	x1, sp, #0x60
     a68:      	ldr	w8, [x8, x23, lsl #2]
     a6c:      	str	w8, [sp, #0x60]
     a70:      	mov	w8, #0x1                // =1
     a74:      	ldr	x0, [x0]
     a78:      	blr	x8
     a7c:      	cbz	x0, 0x1e5c <generic_retuprobe_filter_arg+0x1e5c>
     a80:      	ldr	x16, [sp, #0x50]
     a84:      	mov	w17, #0x1               // =1
     a88:      	cbz	w24, 0xb10 <generic_retuprobe_filter_arg+0xb10>
     a8c:      	mov	x8, xzr
     a90:      	mov	x9, x22
     a94:      	mov	x10, x24
     a98:      	b	0xab0 <generic_retuprobe_filter_arg+0xab0>
     a9c:      	add	x8, x8, #0x1
     aa0:      	sub	x10, x10, #0x1
     aa4:      	add	x9, x9, #0x1
     aa8:      	cmp	x8, x24
     aac:      	b.eq	0xb10 <generic_retuprobe_filter_arg+0xb10>
     ab0:      	mov	x11, xzr
     ab4:      	nop
     ab8:      	nop
     abc:      	nop
     ac0:      	cmp	x10, x11
     ac4:      	b.eq	0xa9c <generic_retuprobe_filter_arg+0xa9c>
     ac8:      	ldrb	w12, [x0, x11]
     acc:      	cbz	w12, 0xb0c <generic_retuprobe_filter_arg+0xb0c>
     ad0:      	ldrb	w13, [x9, x11]
     ad4:      	sub	w14, w13, #0x41
     ad8:      	orr	w15, w13, #0x20
     adc:      	cmp	w14, #0x1a
     ae0:      	sub	w14, w12, #0x41
     ae4:      	csel	w13, w15, w13, lo
     ae8:      	orr	w15, w12, #0x20
     aec:      	cmp	w14, #0x1a
     af0:      	csel	w12, w15, w12, lo
     af4:      	cmp	x11, #0x62
     af8:      	b.hi	0xa9c <generic_retuprobe_filter_arg+0xa9c>
     afc:      	add	x11, x11, #0x1
     b00:      	cmp	w13, w12
     b04:      	b.eq	0xac0 <generic_retuprobe_filter_arg+0xac0>
     b08:      	b	0xa9c <generic_retuprobe_filter_arg+0xa9c>
     b0c:      	tbz	w8, #0x1f, 0x2130 <generic_retuprobe_filter_arg+0x2130>
     b10:      	ldr	w9, [x29, #0x8]
     b14:      	add	w8, w21, #0xc
     b18:      	cmp	w8, w9
     b1c:      	b.hs	0xb30 <generic_retuprobe_filter_arg+0xb30>
     b20:      	add	x23, x23, #0x1
     b24:      	add	w21, w21, #0x4
     b28:      	cmp	x23, #0x64
     b2c:      	b.ne	0xa58 <generic_retuprobe_filter_arg+0xa58>
     b30:      	mov	x23, xzr
     b34:      	b	0x2134 <generic_retuprobe_filter_arg+0x2134>
     b38:      	ldr	w8, [x29, #0x10]
     b3c:      	str	wzr, [sp, #0x88]
     b40:      	adrp	x0, 0x0 <generic_retuprobe_filter_arg>
     b44:      	add	x9, sp, #0x60
     b48:      	add	x1, sp, #0x60
     b4c:      	str	w8, [sp, #0x60]
     b50:      	mov	w8, #0x1                // =1
     b54:      	ldr	x0, [x0]
     b58:      	blr	x8
     b5c:      	mov	x23, xzr
     b60:      	cbz	w24, 0x1410 <generic_retuprobe_filter_arg+0x1410>
     b64:      	cbz	x0, 0x1410 <generic_retuprobe_filter_arg+0x1410>
     b68:      	mov	x19, x0
     b6c:      	adrp	x0, 0x0 <generic_retuprobe_filter_arg>
     b70:      	mov	w8, #0x1                // =1
     b74:      	ldr	x0, [x0]
     b78:      	add	x9, sp, #0x88
     b7c:      	add	x1, sp, #0x88
     b80:      	blr	x8
     b84:      	cbz	x0, 0x1408 <generic_retuprobe_filter_arg+0x1408>
     b88:      	cmp	w24, #0xff
     b8c:      	mov	w8, #0xff               // =255
     b90:      	mov	x2, x22
     b94:      	csel	w1, w24, w8, lo
     b98:      	mov	x8, x0
     b9c:      	mov	x24, x0
     ba0:      	lsl	w9, w1, #3
     ba4:      	str	w9, [x8], #0x4
     ba8:      	mov	w9, #0x4                // =4
     bac:      	mov	x0, x8
     bb0:      	blr	x9
     bb4:      	mov	w8, #0x1                // =1
     bb8:      	mov	x0, x19
     bbc:      	mov	x1, x24
     bc0:      	blr	x8
     bc4:      	cmp	x0, #0x0
     bc8:      	cset	w23, ne
     bcc:      	b	0x140c <generic_retuprobe_filter_arg+0x140c>
     bd0:      	cmp	w24, #0x1fe
     bd4:      	str	wzr, [sp, #0x88]
     bd8:      	b.ls	0x10fc <generic_retuprobe_filter_arg+0x10fc>
     bdc:      	mov	x23, xzr
     be0:      	ldr	w8, [x29, #0x4]
     be4:      	cmp	w8, #0x25
     be8:      	b.ls	0x214c <generic_retuprobe_filter_arg+0x214c>
     bec:      	b	0x2c94 <generic_retuprobe_filter_arg+0x2c94>
     bf0:      	ldp	x11, x8, [x29, #0x10]
     bf4:      	cmp	w9, #0xc
     bf8:      	b.eq	0xc04 <generic_retuprobe_filter_arg+0xc04>
     bfc:      	cmp	w9, #0xa
     c00:      	b.ne	0x160c <generic_retuprobe_filter_arg+0x160c>
     c04:      	ldr	x10, [x22]
     c08:      	cmp	x11, x10
     c0c:      	ccmp	x10, x8, #0x0, le
     c10:      	cset	w8, le
     c14:      	b	0x161c <generic_retuprobe_filter_arg+0x161c>
     c18:      	cmp	w8, #0xd
     c1c:      	b.eq	0xf40 <generic_retuprobe_filter_arg+0xf40>
     c20:      	cmp	w8, #0xe
     c24:      	b.eq	0xf30 <generic_retuprobe_filter_arg+0xf30>
     c28:      	cmp	w8, #0xf
     c2c:      	b.eq	0xef4 <generic_retuprobe_filter_arg+0xef4>
     c30:      	b	0x2c94 <generic_retuprobe_filter_arg+0x2c94>
     c34:      	cmp	w8, #0x20
     c38:      	b.gt	0x11ac <generic_retuprobe_filter_arg+0x11ac>
     c3c:      	cmp	w8, #0x1a
     c40:      	b.eq	0x12fc <generic_retuprobe_filter_arg+0x12fc>
     c44:      	cmp	w8, #0x1b
     c48:      	b.ne	0x2c64 <generic_retuprobe_filter_arg+0x2c64>
     c4c:      	ldr	w8, [x29, #0x10]
     c50:      	str	wzr, [sp, #0x88]
     c54:      	adrp	x0, 0x0 <generic_retuprobe_filter_arg>
     c58:      	add	x9, sp, #0x60
     c5c:      	add	x1, sp, #0x60
     c60:      	mov	w19, #0x1               // =1
     c64:      	str	w8, [sp, #0x60]
     c68:      	mov	w8, #0x1                // =1
     c6c:      	ldr	x0, [x0]
     c70:      	blr	x8
     c74:      	mov	x23, xzr
     c78:      	cbz	w22, 0x2c58 <generic_retuprobe_filter_arg+0x2c58>
     c7c:      	cbz	x0, 0x2c58 <generic_retuprobe_filter_arg+0x2c58>
     c80:      	mov	x23, x0
     c84:      	adrp	x0, 0x0 <generic_retuprobe_filter_arg>
     c88:      	mov	w8, #0x1                // =1
     c8c:      	ldr	x0, [x0]
     c90:      	add	x9, sp, #0x88
     c94:      	add	x1, sp, #0x88
     c98:      	blr	x8
     c9c:      	cbz	x0, 0x2c54 <generic_retuprobe_filter_arg+0x2c54>
     ca0:      	cmp	w22, #0x7f
     ca4:      	mov	w9, #0x7f               // =127
     ca8:      	mov	x1, x0
     cac:      	mov	x8, xzr
     cb0:      	sub	x11, x19, x22
     cb4:      	sub	w12, w22, #0x2
     cb8:      	sub	w13, w22, #0x1
     cbc:      	csel	w9, w22, w9, lo
     cc0:      	lsl	w10, w9, #3
     cc4:      	mov	x9, x0
     cc8:      	str	w10, [x9], #0x5
     ccc:      	neg	x10, x22
     cd0:      	add	w14, w13, w8
     cd4:      	cmp	x11, x8
     cd8:      	and	x14, x14, #0xfff
     cdc:      	ldrb	w14, [x24, x14]
     ce0:      	sturb	w14, [x9, #-0x1]
     ce4:      	b.eq	0xd0c <generic_retuprobe_filter_arg+0xd0c>
     ce8:      	cmn	x8, #0x7e
     cec:      	b.eq	0xd0c <generic_retuprobe_filter_arg+0xd0c>
     cf0:      	add	w14, w12, w8
     cf4:      	sub	x8, x8, #0x2
     cf8:      	and	x14, x14, #0xfff
     cfc:      	cmp	x10, x8
     d00:      	ldrb	w14, [x24, x14]
     d04:      	strb	w14, [x9], #0x2
     d08:      	b.ne	0xcd0 <generic_retuprobe_filter_arg+0xcd0>
     d0c:      	mov	w8, #0x1                // =1
     d10:      	mov	x0, x23
     d14:      	b	0x2c44 <generic_retuprobe_filter_arg+0x2c44>
     d18:      	cmp	w8, #0xc
     d1c:      	b.ne	0x1d88 <generic_retuprobe_filter_arg+0x1d88>
     d20:      	ldr	w11, [x22]
     d24:      	tst	w11, w10
     d28:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
     d2c:      	b	0x1d88 <generic_retuprobe_filter_arg+0x1d88>
     d30:      	lsl	x9, x17, x8
     d34:      	tst	x9, #0xc00
     d38:      	b.ne	0x1268 <generic_retuprobe_filter_arg+0x1268>
     d3c:      	lsl	x9, x17, x8
     d40:      	tst	x9, #0x180000000
     d44:      	b.eq	0xc4 <generic_retuprobe_filter_arg+0xc4>
     d48:      	cmp	w8, #0x1f
     d4c:      	b.ne	0x1954 <generic_retuprobe_filter_arg+0x1954>
     d50:      	ldr	w9, [x29, #0x10]
     d54:      	ldrb	w8, [x22]
     d58:      	b	0xd84 <generic_retuprobe_filter_arg+0xd84>
     d5c:      	lsl	x9, x17, x8
     d60:      	tst	x9, #0xc00
     d64:      	b.ne	0x12a0 <generic_retuprobe_filter_arg+0x12a0>
     d68:      	lsl	x9, x17, x8
     d6c:      	tst	x9, #0x180000000
     d70:      	b.eq	0xc4 <generic_retuprobe_filter_arg+0xc4>
     d74:      	cmp	w8, #0x1f
     d78:      	b.ne	0x1978 <generic_retuprobe_filter_arg+0x1978>
     d7c:      	ldr	w9, [x29, #0x10]
     d80:      	ldrh	w8, [x22]
     d84:      	cmp	w9, w8
     d88:      	b.hi	0xd98 <generic_retuprobe_filter_arg+0xd98>
     d8c:      	ldr	w9, [x29, #0x14]
     d90:      	cmp	w9, w8
     d94:      	b.hs	0x140 <generic_retuprobe_filter_arg+0x140>
     d98:      	ldr	w9, [x29, #0x8]
     d9c:      	cmp	w9, #0x11
     da0:      	b.lo	0xc4 <generic_retuprobe_filter_arg+0xc4>
     da4:      	ldr	w10, [x29, #0x18]
     da8:      	cmp	w10, w8
     dac:      	b.hi	0xdbc <generic_retuprobe_filter_arg+0xdbc>
     db0:      	ldr	w10, [x29, #0x1c]
     db4:      	cmp	w10, w8
     db8:      	b.hs	0x140 <generic_retuprobe_filter_arg+0x140>
     dbc:      	cmp	w9, #0x19
     dc0:      	b.lo	0xc4 <generic_retuprobe_filter_arg+0xc4>
     dc4:      	ldr	w10, [x29, #0x20]
     dc8:      	cmp	w10, w8
     dcc:      	b.hi	0xddc <generic_retuprobe_filter_arg+0xddc>
     dd0:      	ldr	w10, [x29, #0x24]
     dd4:      	cmp	w10, w8
     dd8:      	b.hs	0x140 <generic_retuprobe_filter_arg+0x140>
     ddc:      	cmp	w9, #0x21
     de0:      	b.lo	0xc4 <generic_retuprobe_filter_arg+0xc4>
     de4:      	ldr	w9, [x29, #0x28]
     de8:      	cmp	w9, w8
     dec:      	b.hi	0xc4 <generic_retuprobe_filter_arg+0xc4>
     df0:      	ldr	w9, [x29, #0x2c]
     df4:      	cmp	w9, w8
     df8:      	b.hs	0x140 <generic_retuprobe_filter_arg+0x140>
     dfc:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
     e00:      	cmp	w9, #0xc
     e04:      	b.eq	0xe10 <generic_retuprobe_filter_arg+0xe10>
     e08:      	cmp	w9, #0xa
     e0c:      	b.ne	0x170c <generic_retuprobe_filter_arg+0x170c>
     e10:      	ldr	x11, [x22]
     e14:      	cmp	x11, x10
     e18:      	b.gt	0x140 <generic_retuprobe_filter_arg+0x140>
     e1c:      	b	0x1728 <generic_retuprobe_filter_arg+0x1728>
     e20:      	ldr	x0, [sp, #0x38]
     e24:      	ldp	x12, x16, [sp, #0x48]
     e28:      	mov	w17, #0x1               // =1
     e2c:      	mov	x23, xzr
     e30:      	cbnz	xzr, 0x140 <generic_retuprobe_filter_arg+0x140>
     e34:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
     e38:      	and	w8, w24, #0xffff
     e3c:      	cmp	w8, #0x90
     e40:      	b.hi	0x142c <generic_retuprobe_filter_arg+0x142c>
     e44:      	and	w8, w24, #0xff
     e48:      	mov	w9, #0xab               // =171
     e4c:      	tst	w24, #0xffff
     e50:      	mul	w8, w8, w9
     e54:      	mov	w9, #0x18               // =24
     e58:      	lsr	w8, w8, #12
     e5c:      	msub	w8, w8, w9, w24
     e60:      	b.eq	0xe70 <generic_retuprobe_filter_arg+0xe70>
     e64:      	tst	w8, #0xff
     e68:      	mov	w11, w24
     e6c:      	b.eq	0xe84 <generic_retuprobe_filter_arg+0xe84>
     e70:      	sub	w8, w24, w8, uxtb
     e74:      	and	w9, w8, #0xffff
     e78:      	add	w11, w8, #0x18
     e7c:      	cmp	w9, #0x78
     e80:      	b.hi	0x1440 <generic_retuprobe_filter_arg+0x1440>
     e84:      	and	w8, w11, #0xff
     e88:      	mov	w9, #0xab               // =171
     e8c:      	mul	w8, w8, w9
     e90:      	lsr	w8, w8, #12
     e94:      	sub	w10, w8, #0x1
     e98:      	b	0x1450 <generic_retuprobe_filter_arg+0x1450>
     e9c:      	ldp	w11, w8, [x29, #0x10]
     ea0:      	cmp	w9, #0xc
     ea4:      	b.hi	0x1c2c <generic_retuprobe_filter_arg+0x1c2c>
     ea8:      	lsl	w10, w17, w9
     eac:      	mov	w12, #0x1402            // =5122
     eb0:      	tst	w10, w12
     eb4:      	b.eq	0x1c2c <generic_retuprobe_filter_arg+0x1c2c>
     eb8:      	ldr	w10, [x22]
     ebc:      	cmp	w11, w10
     ec0:      	ccmp	w10, w8, #0x0, le
     ec4:      	cset	w8, le
     ec8:      	b	0x1c3c <generic_retuprobe_filter_arg+0x1c3c>
     ecc:      	cmp	w8, #0x12
     ed0:      	b.eq	0xef4 <generic_retuprobe_filter_arg+0xef4>
     ed4:      	cmp	w8, #0x13
     ed8:      	b.ne	0x2c94 <generic_retuprobe_filter_arg+0x2c94>
     edc:      	ldrh	w24, [x22, #0x22]
     ee0:      	mov	x19, x21
     ee4:      	mov	w11, wzr
     ee8:      	mov	w13, wzr
     eec:      	mov	x21, xzr
     ef0:      	b	0xf50 <generic_retuprobe_filter_arg+0xf50>
     ef4:      	ldrh	w24, [x22, #0x20]
     ef8:      	mov	x19, x21
     efc:      	mov	w11, wzr
     f00:      	mov	w13, wzr
     f04:      	mov	x21, xzr
     f08:      	b	0xf50 <generic_retuprobe_filter_arg+0xf50>
     f0c:      	cmp	w8, #0x1c
     f10:      	b.eq	0x164c <generic_retuprobe_filter_arg+0x164c>
     f14:      	cmp	w8, #0x1d
     f18:      	b.ne	0x2c94 <generic_retuprobe_filter_arg+0x2c94>
     f1c:      	cmp	w9, #0x7
     f20:      	b.ne	0x1cf8 <generic_retuprobe_filter_arg+0x1cf8>
     f24:      	cbnz	x10, 0x1d08 <generic_retuprobe_filter_arg+0x1d08>
     f28:      	mov	x19, xzr
     f2c:      	b	0x1d1c <generic_retuprobe_filter_arg+0x1d1c>
     f30:      	mov	x19, x21
     f34:      	ldp	w11, w13, [x22, #0x10]
     f38:      	ldr	x21, [x22, #0x18]
     f3c:      	b	0xf4c <generic_retuprobe_filter_arg+0xf4c>
     f40:      	mov	x19, x21
     f44:      	ldp	w11, w13, [x22]
     f48:      	ldr	x21, [x22, #0x8]
     f4c:      	mov	x24, xzr
     f50:      	mov	x23, xzr
     f54:      	cmp	w8, #0x11
     f58:      	b.gt	0xf88 <generic_retuprobe_filter_arg+0xf88>
     f5c:      	sub	w9, w8, #0xd
     f60:      	cmp	w9, #0x2
     f64:      	b.lo	0xfb4 <generic_retuprobe_filter_arg+0xfb4>
     f68:      	mov	x21, x19
     f6c:      	ldr	x19, [sp, #0x30]
     f70:      	sub	w9, w8, #0xf
     f74:      	cmp	w9, #0x2
     f78:      	b.lo	0x1174 <generic_retuprobe_filter_arg+0x1174>
     f7c:      	cmp	w8, #0x11
     f80:      	b.eq	0x1650 <generic_retuprobe_filter_arg+0x1650>
     f84:      	b	0x2c94 <generic_retuprobe_filter_arg+0x2c94>
     f88:      	cmp	w8, #0x19
     f8c:      	b.hi	0x1160 <generic_retuprobe_filter_arg+0x1160>
     f90:      	lsl	w9, w17, w8
     f94:      	mov	w10, #0x500000          // =5242880
     f98:      	tst	w9, w10
     f9c:      	b.ne	0x13e4 <generic_retuprobe_filter_arg+0x13e4>
     fa0:      	mov	w10, #0xa00000          // =10485760
     fa4:      	tst	w9, w10
     fa8:      	b.ne	0x13f0 <generic_retuprobe_filter_arg+0x13f0>
     fac:      	tst	w9, #0x3000000
     fb0:      	b.eq	0x1160 <generic_retuprobe_filter_arg+0x1160>
     fb4:      	ldrh	w8, [x22, #0x26]
     fb8:      	cmp	w8, #0xa
     fbc:      	b.eq	0x1518 <generic_retuprobe_filter_arg+0x1518>
     fc0:      	cmp	w8, #0x2
     fc4:      	b.ne	0x15a8 <generic_retuprobe_filter_arg+0x15a8>
     fc8:      	ldr	w8, [x29, #0x10]
     fcc:      	adrp	x0, 0x0 <generic_retuprobe_filter_arg>
     fd0:      	add	x9, sp, #0xac
     fd4:      	add	x1, sp, #0xac
     fd8:      	str	w8, [sp, #0xac]
     fdc:      	mov	w8, #0x1                // =1
     fe0:      	mov	w22, w11
     fe4:      	ldr	x0, [x0]
     fe8:      	blr	x8
     fec:      	mov	x21, x19
     ff0:      	cbz	x0, 0x1e6c <generic_retuprobe_filter_arg+0x1e6c>
     ff4:      	mov	w8, #0x20               // =32
     ff8:      	add	x1, sp, #0x88
     ffc:      	stp	w8, w22, [sp, #0x88]
    1000:      	b	0x1560 <generic_retuprobe_filter_arg+0x1560>
    1004:      	cmp	w9, #0xc
    1008:      	b.hi	0x1d6c <generic_retuprobe_filter_arg+0x1d6c>
    100c:      	lsl	w11, w17, w9
    1010:      	mov	w13, #0x1402            // =5122
    1014:      	tst	w11, w13
    1018:      	b.eq	0x1d6c <generic_retuprobe_filter_arg+0x1d6c>
    101c:      	ldr	w11, [x22]
    1020:      	cmp	w11, w10
    1024:      	b.gt	0x140 <generic_retuprobe_filter_arg+0x140>
    1028:      	b	0x1d88 <generic_retuprobe_filter_arg+0x1d88>
    102c:      	str	x21, [sp, #0x28]
    1030:      	mov	x21, xzr
    1034:      	mov	w23, wzr
    1038:      	add	x19, x29, #0x10
    103c:      	ldr	w8, [x19, x21, lsl #2]
    1040:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    1044:      	add	x9, sp, #0x60
    1048:      	add	x1, sp, #0x60
    104c:      	str	w8, [sp, #0x60]
    1050:      	mov	w8, #0x1                // =1
    1054:      	ldr	x0, [x0]
    1058:      	blr	x8
    105c:      	cbz	x0, 0x1e48 <generic_retuprobe_filter_arg+0x1e48>
    1060:      	ldr	x16, [sp, #0x50]
    1064:      	mov	w17, #0x1               // =1
    1068:      	cbz	w24, 0x10d0 <generic_retuprobe_filter_arg+0x10d0>
    106c:      	mov	x8, xzr
    1070:      	mov	x9, x22
    1074:      	mov	x10, x24
    1078:      	b	0x1090 <generic_retuprobe_filter_arg+0x1090>
    107c:      	add	x8, x8, #0x1
    1080:      	sub	x10, x10, #0x1
    1084:      	add	x9, x9, #0x1
    1088:      	cmp	x8, x24
    108c:      	b.eq	0x10d0 <generic_retuprobe_filter_arg+0x10d0>
    1090:      	mov	x11, xzr
    1094:      	nop
    1098:      	nop
    109c:      	nop
    10a0:      	cmp	x10, x11
    10a4:      	b.eq	0x107c <generic_retuprobe_filter_arg+0x107c>
    10a8:      	ldrb	w12, [x0, x11]
    10ac:      	cbz	w12, 0x10cc <generic_retuprobe_filter_arg+0x10cc>
    10b0:      	cmp	x11, #0x62
    10b4:      	b.hi	0x107c <generic_retuprobe_filter_arg+0x107c>
    10b8:      	ldrb	w13, [x9, x11]
    10bc:      	add	x11, x11, #0x1
    10c0:      	cmp	w13, w12
    10c4:      	b.eq	0x10a0 <generic_retuprobe_filter_arg+0x10a0>
    10c8:      	b	0x107c <generic_retuprobe_filter_arg+0x107c>
    10cc:      	tbz	w8, #0x1f, 0x2124 <generic_retuprobe_filter_arg+0x2124>
    10d0:      	ldr	w9, [x29, #0x8]
    10d4:      	add	w8, w23, #0xc
    10d8:      	cmp	w8, w9
    10dc:      	b.hs	0x10f0 <generic_retuprobe_filter_arg+0x10f0>
    10e0:      	add	x21, x21, #0x1
    10e4:      	add	w23, w23, #0x4
    10e8:      	cmp	x21, #0x64
    10ec:      	b.ne	0x103c <generic_retuprobe_filter_arg+0x103c>
    10f0:      	ldr	x21, [sp, #0x28]
    10f4:      	mov	x23, xzr
    10f8:      	b	0x2138 <generic_retuprobe_filter_arg+0x2138>
    10fc:      	and	w8, w24, #0xffff
    1100:      	cmp	w8, #0x90
    1104:      	b.hi	0x17e4 <generic_retuprobe_filter_arg+0x17e4>
    1108:      	and	w8, w24, #0xff
    110c:      	mov	w9, #0xab               // =171
    1110:      	tst	w24, #0xffff
    1114:      	mul	w8, w8, w9
    1118:      	mov	w9, #0x18               // =24
    111c:      	lsr	w8, w8, #12
    1120:      	msub	w8, w8, w9, w24
    1124:      	b.eq	0x1134 <generic_retuprobe_filter_arg+0x1134>
    1128:      	tst	w8, #0xff
    112c:      	mov	w11, w24
    1130:      	b.eq	0x1148 <generic_retuprobe_filter_arg+0x1148>
    1134:      	sub	w8, w24, w8, uxtb
    1138:      	and	w9, w8, #0xffff
    113c:      	add	w11, w8, #0x18
    1140:      	cmp	w9, #0x78
    1144:      	b.hi	0x17f8 <generic_retuprobe_filter_arg+0x17f8>
    1148:      	and	w8, w11, #0xff
    114c:      	mov	w9, #0xab               // =171
    1150:      	mul	w8, w8, w9
    1154:      	lsr	w8, w8, #12
    1158:      	sub	w10, w8, #0x1
    115c:      	b	0x1808 <generic_retuprobe_filter_arg+0x1808>
    1160:      	mov	x21, x19
    1164:      	ldr	x19, [sp, #0x30]
    1168:      	sub	w8, w8, #0x12
    116c:      	cmp	w8, #0x2
    1170:      	b.hs	0x2c94 <generic_retuprobe_filter_arg+0x2c94>
    1174:      	ldrb	w8, [x29, #0x10]
    1178:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    117c:      	add	x9, sp, #0xac
    1180:      	add	x1, sp, #0xac
    1184:      	str	w8, [sp, #0xac]
    1188:      	mov	w8, #0x1                // =1
    118c:      	ldr	x0, [x0]
    1190:      	blr	x8
    1194:      	cbz	x0, 0x16cc <generic_retuprobe_filter_arg+0x16cc>
    1198:      	str	x24, [sp, #0x88]
    119c:      	mov	w8, #0x1                // =1
    11a0:      	add	x9, sp, #0x88
    11a4:      	add	x1, sp, #0x88
    11a8:      	b	0x1684 <generic_retuprobe_filter_arg+0x1684>
    11ac:      	cmp	w8, #0x21
    11b0:      	b.eq	0x19e8 <generic_retuprobe_filter_arg+0x19e8>
    11b4:      	cmp	w8, #0x22
    11b8:      	b.ne	0x2c64 <generic_retuprobe_filter_arg+0x2c64>
    11bc:      	mov	w19, #0x10              // =16
    11c0:      	ldr	w8, [x29, x19]
    11c4:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    11c8:      	add	x9, sp, #0x60
    11cc:      	add	x1, sp, #0x60
    11d0:      	str	w8, [sp, #0x60]
    11d4:      	mov	w8, #0x1                // =1
    11d8:      	ldr	x0, [x0]
    11dc:      	blr	x8
    11e0:      	cbz	x0, 0x242c <generic_retuprobe_filter_arg+0x242c>
    11e4:      	mov	x1, x0
    11e8:      	mov	x0, x24
    11ec:      	mov	x2, x22
    11f0:      	bl	0x11f0 <generic_retuprobe_filter_arg+0x11f0>
    11f4:      	tbz	w0, #0x1f, 0x2434 <generic_retuprobe_filter_arg+0x2434>
    11f8:      	ldr	w8, [x29, #0x8]
    11fc:      	ldp	x12, x16, [sp, #0x48]
    1200:      	add	x19, x19, #0x4
    1204:      	mov	w17, #0x1               // =1
    1208:      	mov	x23, xzr
    120c:      	sub	w9, w19, #0x8
    1210:      	cmp	w9, w8
    1214:      	b.hs	0x24c0 <generic_retuprobe_filter_arg+0x24c0>
    1218:      	ldr	x0, [sp, #0x38]
    121c:      	cmp	x19, #0x1a0
    1220:      	b.ne	0x11c0 <generic_retuprobe_filter_arg+0x11c0>
    1224:      	b	0x2c64 <generic_retuprobe_filter_arg+0x2c64>
    1228:      	cmp	w8, #0x1
    122c:      	b.eq	0x1b38 <generic_retuprobe_filter_arg+0x1b38>
    1230:      	cmp	w8, #0x2
    1234:      	b.ne	0x1b44 <generic_retuprobe_filter_arg+0x1b44>
    1238:      	ldrb	w10, [x22]
    123c:      	cmp	w9, w10
    1240:      	b.hi	0x140 <generic_retuprobe_filter_arg+0x140>
    1244:      	b	0x1b44 <generic_retuprobe_filter_arg+0x1b44>
    1248:      	cmp	w8, #0x1
    124c:      	b.eq	0x1b78 <generic_retuprobe_filter_arg+0x1b78>
    1250:      	cmp	w8, #0x2
    1254:      	b.ne	0x1b84 <generic_retuprobe_filter_arg+0x1b84>
    1258:      	ldrh	w10, [x22]
    125c:      	cmp	w9, w10
    1260:      	b.hi	0x140 <generic_retuprobe_filter_arg+0x140>
    1264:      	b	0x1b84 <generic_retuprobe_filter_arg+0x1b84>
    1268:      	ldrb	w8, [x29, #0x10]
    126c:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    1270:      	add	x9, sp, #0x88
    1274:      	add	x1, sp, #0x88
    1278:      	str	w8, [sp, #0x88]
    127c:      	mov	w8, #0x1                // =1
    1280:      	ldr	x0, [x0]
    1284:      	blr	x8
    1288:      	cbz	x0, 0x16cc <generic_retuprobe_filter_arg+0x16cc>
    128c:      	ldrb	w8, [x22]
    1290:      	add	x9, sp, #0x60
    1294:      	str	x8, [sp, #0x60]
    1298:      	mov	w8, #0x1                // =1
    129c:      	b	0x12d4 <generic_retuprobe_filter_arg+0x12d4>
    12a0:      	ldrb	w8, [x29, #0x10]
    12a4:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    12a8:      	add	x9, sp, #0x88
    12ac:      	add	x1, sp, #0x88
    12b0:      	str	w8, [sp, #0x88]
    12b4:      	mov	w8, #0x1                // =1
    12b8:      	ldr	x0, [x0]
    12bc:      	blr	x8
    12c0:      	cbz	x0, 0x16cc <generic_retuprobe_filter_arg+0x16cc>
    12c4:      	ldrh	w8, [x22]
    12c8:      	add	x9, sp, #0x60
    12cc:      	str	x8, [sp, #0x60]
    12d0:      	mov	w8, #0x1                // =1
    12d4:      	add	x1, sp, #0x60
    12d8:      	b	0x1684 <generic_retuprobe_filter_arg+0x1684>
    12dc:      	cmp	x0, #0x0
    12e0:      	ldr	x0, [sp, #0x38]
    12e4:      	ldp	x12, x16, [sp, #0x48]
    12e8:      	mov	w17, #0x1               // =1
    12ec:      	cset	w8, eq
    12f0:      	mov	w23, w8
    12f4:      	cbnz	x23, 0x140 <generic_retuprobe_filter_arg+0x140>
    12f8:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    12fc:      	ldr	w8, [x29, #0x10]
    1300:      	str	wzr, [sp, #0x88]
    1304:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    1308:      	add	x9, sp, #0x60
    130c:      	add	x1, sp, #0x60
    1310:      	str	w8, [sp, #0x60]
    1314:      	mov	w8, #0x1                // =1
    1318:      	ldr	x0, [x0]
    131c:      	blr	x8
    1320:      	mov	x23, xzr
    1324:      	cbz	w22, 0x2c58 <generic_retuprobe_filter_arg+0x2c58>
    1328:      	cbz	x0, 0x2c58 <generic_retuprobe_filter_arg+0x2c58>
    132c:      	mov	x19, x0
    1330:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    1334:      	mov	w8, #0x1                // =1
    1338:      	ldr	x0, [x0]
    133c:      	add	x9, sp, #0x88
    1340:      	add	x1, sp, #0x88
    1344:      	blr	x8
    1348:      	cbz	x0, 0x2c54 <generic_retuprobe_filter_arg+0x2c54>
    134c:      	cmp	w22, #0xff
    1350:      	mov	w8, #0xff               // =255
    1354:      	mov	x2, x24
    1358:      	csel	w1, w22, w8, lo
    135c:      	mov	x8, x0
    1360:      	mov	x22, x0
    1364:      	lsl	w9, w1, #3
    1368:      	str	w9, [x8], #0x4
    136c:      	mov	w9, #0x4                // =4
    1370:      	mov	x0, x8
    1374:      	blr	x9
    1378:      	mov	w8, #0x1                // =1
    137c:      	mov	x0, x19
    1380:      	mov	x1, x22
    1384:      	b	0x2c44 <generic_retuprobe_filter_arg+0x2c44>
    1388:      	cmp	w22, #0x1fe
    138c:      	str	wzr, [sp, #0x88]
    1390:      	b.ls	0x1ab8 <generic_retuprobe_filter_arg+0x1ab8>
    1394:      	mov	x23, xzr
    1398:      	b	0x2c64 <generic_retuprobe_filter_arg+0x2c64>
    139c:      	cmp	w8, #0x1e
    13a0:      	b.ne	0xc4 <generic_retuprobe_filter_arg+0xc4>
    13a4:      	ldr	w8, [x29, #0x10]
    13a8:      	mov	w10, #0x5ea0            // =24224
    13ac:      	and	x8, x8, #0x7
    13b0:      	add	x9, x20, x8, lsl #2
    13b4:      	ldr	w9, [x9, x10]
    13b8:      	cbnz	w9, 0xc4 <generic_retuprobe_filter_arg+0xc4>
    13bc:      	add	x8, x20, x8, lsl #3
    13c0:      	ldr	x9, [x22]
    13c4:      	ldr	x8, [x8, #0x5e78]
    13c8:      	and	x8, x8, #0x7ff
    13cc:      	add	x8, x20, x8
    13d0:      	ldr	x8, [x8, #0x90]
    13d4:      	bics	xzr, x8, x9
    13d8:      	cset	w23, ne
    13dc:      	cbnz	x23, 0x140 <generic_retuprobe_filter_arg+0x140>
    13e0:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    13e4:      	cmp	x24, #0x400
    13e8:      	cset	w23, lo
    13ec:      	b	0x13f8 <generic_retuprobe_filter_arg+0x13f8>
    13f0:      	cmp	x24, #0x3ff
    13f4:      	cset	w23, hi
    13f8:      	mov	x21, x19
    13fc:      	ldr	x19, [sp, #0x30]
    1400:      	cbnz	x23, 0x140 <generic_retuprobe_filter_arg+0x140>
    1404:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    1408:      	mov	x23, xzr
    140c:      	ldr	x19, [sp, #0x30]
    1410:      	ldr	x0, [sp, #0x38]
    1414:      	ldp	x12, x16, [sp, #0x48]
    1418:      	mov	w17, #0x1               // =1
    141c:      	ldr	w8, [x29, #0x4]
    1420:      	cmp	w8, #0x25
    1424:      	b.ls	0x214c <generic_retuprobe_filter_arg+0x214c>
    1428:      	b	0x2c94 <generic_retuprobe_filter_arg+0x2c94>
    142c:      	and	w8, w24, #0xffff
    1430:      	mov	w9, #0x1fe              // =510
    1434:      	cmp	w8, #0x100
    1438:      	mov	w8, #0x100              // =256
    143c:      	csel	w11, w9, w8, hi
    1440:      	and	w8, w11, #0xffff
    1444:      	cmp	w8, #0x100
    1448:      	mov	w8, #0x6                // =6
    144c:      	cinc	w10, w8, ne
    1450:      	add	x8, x29, #0x10
    1454:      	and	w9, w10, #0xf
    1458:      	ldr	w8, [x8, w9, uxtw #2]
    145c:      	cmn	w8, #0x1
    1460:      	b.eq	0x2808 <generic_retuprobe_filter_arg+0x2808>
    1464:      	str	w11, [sp, #0x10]
    1468:      	stp	w8, w10, [sp, #0x1c]
    146c:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    1470:      	mov	w8, #0x1                // =1
    1474:      	add	x23, sp, #0x88
    1478:      	add	x1, sp, #0x88
    147c:      	ldr	x0, [x0]
    1480:      	blr	x8
    1484:      	str	x0, [sp, #0x28]
    1488:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    148c:      	mov	w8, #0x1                // =1
    1490:      	add	x1, sp, #0x88
    1494:      	ldr	x0, [x0]
    1498:      	blr	x8
    149c:      	ldr	x10, [sp, #0x28]
    14a0:      	mov	x23, xzr
    14a4:      	cbz	x10, 0x280c <generic_retuprobe_filter_arg+0x280c>
    14a8:      	mov	x9, x0
    14ac:      	ldr	x0, [sp, #0x38]
    14b0:      	ldp	x12, x16, [sp, #0x48]
    14b4:      	mov	w17, #0x1               // =1
    14b8:      	cbz	x9, 0x2818 <generic_retuprobe_filter_arg+0x2818>
    14bc:      	ldr	w23, [sp, #0x20]
    14c0:      	mov	x8, x10
    14c4:      	add	x2, x22, #0x4
    14c8:      	mov	x22, x10
    14cc:      	str	x9, [sp, #0x8]
    14d0:      	mov	x0, x8
    14d4:      	cmp	w23, #0x5
    14d8:      	b.gt	0x1ee0 <generic_retuprobe_filter_arg+0x1ee0>
    14dc:      	strb	w24, [x0], #0x1
    14e0:      	mov	w8, #0x4                // =4
    14e4:      	mov	w1, w24
    14e8:      	blr	x8
    14ec:      	ldr	w8, [sp, #0x10]
    14f0:      	and	w8, w8, #0xffff
    14f4:      	cmp	w8, w24
    14f8:      	b.ls	0x1f1c <generic_retuprobe_filter_arg+0x1f1c>
    14fc:      	add	x9, x22, x24
    1500:      	sub	w8, w8, w24
    1504:      	ldr	x2, [sp, #0x8]
    1508:      	add	x0, x9, #0x1
    150c:      	and	w1, w8, #0xfff
    1510:      	mov	w8, #0x4                // =4
    1514:      	b	0x1f18 <generic_retuprobe_filter_arg+0x1f18>
    1518:      	ldr	w8, [x29, #0x14]
    151c:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    1520:      	add	x9, sp, #0xac
    1524:      	add	x1, sp, #0xac
    1528:      	str	w8, [sp, #0xac]
    152c:      	mov	w8, #0x1                // =1
    1530:      	mov	w23, w13
    1534:      	mov	w22, w11
    1538:      	ldr	x0, [x0]
    153c:      	blr	x8
    1540:      	cbz	x0, 0x1e74 <generic_retuprobe_filter_arg+0x1e74>
    1544:      	mov	w8, #0x80               // =128
    1548:      	stp	w23, w21, [sp, #0x90]
    154c:      	add	x1, sp, #0x88
    1550:      	stp	w8, w22, [sp, #0x88]
    1554:      	lsr	x8, x21, #32
    1558:      	mov	x21, x19
    155c:      	str	w8, [sp, #0x98]
    1560:      	ldr	x19, [sp, #0x30]
    1564:      	mov	w8, #0x1                // =1
    1568:      	blr	x8
    156c:      	ldr	w8, [x29, #0x4]
    1570:      	sub	w9, w8, #0x18
    1574:      	cmp	w9, #0x2
    1578:      	b.lo	0x1bb8 <generic_retuprobe_filter_arg+0x1bb8>
    157c:      	ldp	x12, x16, [sp, #0x48]
    1580:      	sub	w8, w8, #0xd
    1584:      	mov	w17, #0x1               // =1
    1588:      	cmp	w8, #0x1
    158c:      	b.hi	0x207c <generic_retuprobe_filter_arg+0x207c>
    1590:      	cmp	x0, #0x0
    1594:      	ldr	x0, [sp, #0x38]
    1598:      	cset	w8, ne
    159c:      	mov	w23, w8
    15a0:      	cbnz	x23, 0x140 <generic_retuprobe_filter_arg+0x140>
    15a4:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    15a8:      	mov	x21, x19
    15ac:      	ldr	x19, [sp, #0x30]
    15b0:      	mov	w8, wzr
    15b4:      	mov	w23, wzr
    15b8:      	cbnz	x23, 0x140 <generic_retuprobe_filter_arg+0x140>
    15bc:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    15c0:      	ldr	x8, [x22]
    15c4:      	cmp	x11, x8
    15c8:      	b.hi	0x15d4 <generic_retuprobe_filter_arg+0x15d4>
    15cc:      	cmp	x8, x10
    15d0:      	b.ls	0x140 <generic_retuprobe_filter_arg+0x140>
    15d4:      	ldr	w10, [x29, #0x8]
    15d8:      	cmp	w10, #0x19
    15dc:      	b.lo	0xc4 <generic_retuprobe_filter_arg+0xc4>
    15e0:      	ldp	x12, x11, [x29, #0x20]
    15e4:      	cmp	w9, #0xc
    15e8:      	b.eq	0x15f4 <generic_retuprobe_filter_arg+0x15f4>
    15ec:      	cmp	w9, #0xa
    15f0:      	b.ne	0x1cb0 <generic_retuprobe_filter_arg+0x1cb0>
    15f4:      	cmp	x12, x8
    15f8:      	ldr	x12, [sp, #0x48]
    15fc:      	b.gt	0x1cc4 <generic_retuprobe_filter_arg+0x1cc4>
    1600:      	cmp	x8, x11
    1604:      	b.le	0x140 <generic_retuprobe_filter_arg+0x140>
    1608:      	b	0x1cc4 <generic_retuprobe_filter_arg+0x1cc4>
    160c:      	ldr	x10, [x22]
    1610:      	cmp	x11, x10
    1614:      	ccmp	x10, x8, #0x2, ls
    1618:      	cset	w8, ls
    161c:      	ldr	w11, [x29, #0x8]
    1620:      	cmp	w11, #0x19
    1624:      	b.lo	0x2858 <generic_retuprobe_filter_arg+0x2858>
    1628:      	ldp	x13, x12, [x29, #0x20]
    162c:      	cmp	w9, #0xc
    1630:      	b.eq	0x163c <generic_retuprobe_filter_arg+0x163c>
    1634:      	cmp	w9, #0xa
    1638:      	b.ne	0x1c74 <generic_retuprobe_filter_arg+0x1c74>
    163c:      	cmp	x13, x10
    1640:      	ccmp	x10, x12, #0x0, le
    1644:      	cset	w12, le
    1648:      	b	0x1c80 <generic_retuprobe_filter_arg+0x1c80>
    164c:      	ldrh	w23, [x22, #0x26]
    1650:      	ldrb	w8, [x29, #0x10]
    1654:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    1658:      	add	x9, sp, #0xac
    165c:      	add	x1, sp, #0xac
    1660:      	str	w8, [sp, #0xac]
    1664:      	mov	w8, #0x1                // =1
    1668:      	ldr	x0, [x0]
    166c:      	blr	x8
    1670:      	cbz	x0, 0x16cc <generic_retuprobe_filter_arg+0x16cc>
    1674:      	str	x23, [sp, #0x88]
    1678:      	mov	w8, #0x1                // =1
    167c:      	add	x9, sp, #0x88
    1680:      	add	x1, sp, #0x88
    1684:      	blr	x8
    1688:      	ldr	w9, [x29, #0x4]
    168c:      	mov	w8, wzr
    1690:      	cmp	w9, #0x1d
    1694:      	b.hi	0x2cac <generic_retuprobe_filter_arg+0x2cac>
    1698:      	mov	w17, #0x1               // =1
    169c:      	mov	w10, #0x8400            // =33792
    16a0:      	lsl	w9, w17, w9
    16a4:      	movk	w10, #0x3003, lsl #16
    16a8:      	tst	w9, w10
    16ac:      	ldp	x12, x16, [sp, #0x48]
    16b0:      	b.eq	0x16e4 <generic_retuprobe_filter_arg+0x16e4>
    16b4:      	cmp	x0, #0x0
    16b8:      	cset	w8, ne
    16bc:      	ldr	x0, [sp, #0x38]
    16c0:      	mov	w23, w8
    16c4:      	cbnz	x23, 0x140 <generic_retuprobe_filter_arg+0x140>
    16c8:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    16cc:      	mov	x23, xzr
    16d0:      	ldp	x12, x16, [sp, #0x48]
    16d4:      	mov	w17, #0x1               // =1
    16d8:      	ldr	x0, [sp, #0x38]
    16dc:      	cbnz	xzr, 0x140 <generic_retuprobe_filter_arg+0x140>
    16e0:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    16e4:      	mov	w10, #0x800             // =2048
    16e8:      	movk	w10, #0xc, lsl #16
    16ec:      	tst	w9, w10
    16f0:      	b.eq	0x16fc <generic_retuprobe_filter_arg+0x16fc>
    16f4:      	cmp	x0, #0x0
    16f8:      	cset	w8, eq
    16fc:      	ldr	x0, [sp, #0x38]
    1700:      	mov	w23, w8
    1704:      	cbnz	x23, 0x140 <generic_retuprobe_filter_arg+0x140>
    1708:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    170c:      	ldr	x11, [x22]
    1710:      	cmp	x11, x10
    1714:      	b.hi	0x140 <generic_retuprobe_filter_arg+0x140>
    1718:      	b	0x1728 <generic_retuprobe_filter_arg+0x1728>
    171c:      	ldr	x11, [x22]
    1720:      	cmp	x11, x10
    1724:      	b.lo	0x140 <generic_retuprobe_filter_arg+0x140>
    1728:      	ldr	w10, [x29, #0x8]
    172c:      	cmp	w10, #0x11
    1730:      	b.lo	0x124 <generic_retuprobe_filter_arg+0x124>
    1734:      	ldr	x11, [x29, #0x18]
    1738:      	cmp	w8, #0x2
    173c:      	b.le	0x1760 <generic_retuprobe_filter_arg+0x1760>
    1740:      	sub	w12, w8, #0x3
    1744:      	cmp	w12, #0x2
    1748:      	b.hs	0x1794 <generic_retuprobe_filter_arg+0x1794>
    174c:      	ldr	x12, [x22]
    1750:      	cmp	x12, x11
    1754:      	ldr	x12, [sp, #0x48]
    1758:      	b.ne	0x22f8 <generic_retuprobe_filter_arg+0x22f8>
    175c:      	b	0x2bdc <generic_retuprobe_filter_arg+0x2bdc>
    1760:      	cmp	w8, #0x1
    1764:      	b.eq	0x18d4 <generic_retuprobe_filter_arg+0x18d4>
    1768:      	cmp	w8, #0x2
    176c:      	b.ne	0x22f8 <generic_retuprobe_filter_arg+0x22f8>
    1770:      	cmp	w9, #0xc
    1774:      	b.eq	0x1780 <generic_retuprobe_filter_arg+0x1780>
    1778:      	cmp	w9, #0xa
    177c:      	b.ne	0x22e8 <generic_retuprobe_filter_arg+0x22e8>
    1780:      	ldr	x12, [x22]
    1784:      	cmp	x12, x11
    1788:      	ldr	x12, [sp, #0x48]
    178c:      	b.lt	0x140 <generic_retuprobe_filter_arg+0x140>
    1790:      	b	0x22f8 <generic_retuprobe_filter_arg+0x22f8>
    1794:      	ldr	x12, [sp, #0x48]
    1798:      	cmp	w8, #0xc
    179c:      	b.ne	0x22f8 <generic_retuprobe_filter_arg+0x22f8>
    17a0:      	ldr	x12, [x22]
    17a4:      	tst	x12, x11
    17a8:      	ldr	x12, [sp, #0x48]
    17ac:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
    17b0:      	b	0x22f8 <generic_retuprobe_filter_arg+0x22f8>
    17b4:      	cmp	w8, #0xc
    17b8:      	b.ne	0x1b44 <generic_retuprobe_filter_arg+0x1b44>
    17bc:      	ldrb	w10, [x22]
    17c0:      	tst	w9, w10
    17c4:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
    17c8:      	b	0x1b44 <generic_retuprobe_filter_arg+0x1b44>
    17cc:      	cmp	w8, #0xc
    17d0:      	b.ne	0x1b84 <generic_retuprobe_filter_arg+0x1b84>
    17d4:      	ldrh	w10, [x22]
    17d8:      	tst	w9, w10
    17dc:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
    17e0:      	b	0x1b84 <generic_retuprobe_filter_arg+0x1b84>
    17e4:      	and	w8, w24, #0xffff
    17e8:      	mov	w9, #0x1fe              // =510
    17ec:      	cmp	w8, #0x100
    17f0:      	mov	w8, #0x100              // =256
    17f4:      	csel	w11, w9, w8, hi
    17f8:      	and	w8, w11, #0xffff
    17fc:      	cmp	w8, #0x100
    1800:      	mov	w8, #0x6                // =6
    1804:      	cinc	w10, w8, ne
    1808:      	add	x8, x29, #0x10
    180c:      	and	w9, w10, #0xf
    1810:      	ldr	w8, [x8, w9, uxtw #2]
    1814:      	cmn	w8, #0x1
    1818:      	b.eq	0x1b1c <generic_retuprobe_filter_arg+0x1b1c>
    181c:      	str	w11, [sp, #0x10]
    1820:      	str	w8, [sp, #0x1c]
    1824:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    1828:      	mov	w8, #0x1                // =1
    182c:      	add	x23, sp, #0x88
    1830:      	add	x1, sp, #0x88
    1834:      	str	w10, [sp, #0x28]
    1838:      	ldr	x0, [x0]
    183c:      	blr	x8
    1840:      	str	x0, [sp, #0x20]
    1844:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    1848:      	mov	w8, #0x1                // =1
    184c:      	add	x1, sp, #0x88
    1850:      	ldr	x0, [x0]
    1854:      	blr	x8
    1858:      	ldr	x10, [sp, #0x20]
    185c:      	mov	x23, xzr
    1860:      	cbz	x10, 0x1410 <generic_retuprobe_filter_arg+0x1410>
    1864:      	mov	x9, x0
    1868:      	ldr	x0, [sp, #0x38]
    186c:      	ldp	x12, x16, [sp, #0x48]
    1870:      	mov	w17, #0x1               // =1
    1874:      	cbz	x9, 0x2140 <generic_retuprobe_filter_arg+0x2140>
    1878:      	mov	x23, x9
    187c:      	ldr	w9, [sp, #0x28]
    1880:      	mov	x8, x10
    1884:      	cmp	w9, #0x5
    1888:      	b.gt	0x21cc <generic_retuprobe_filter_arg+0x21cc>
    188c:      	mov	x0, x8
    1890:      	mov	x9, x8
    1894:      	mov	w8, #0x4                // =4
    1898:      	mov	w1, w24
    189c:      	mov	x2, x22
    18a0:      	strb	w24, [x0], #0x1
    18a4:      	mov	x22, x9
    18a8:      	blr	x8
    18ac:      	ldr	w8, [sp, #0x10]
    18b0:      	and	w8, w8, #0xffff
    18b4:      	cmp	w8, w24
    18b8:      	b.ls	0x2218 <generic_retuprobe_filter_arg+0x2218>
    18bc:      	add	x9, x22, x24
    18c0:      	sub	w8, w8, w24
    18c4:      	add	x0, x9, #0x1
    18c8:      	and	w1, w8, #0xfff
    18cc:      	mov	w8, #0x4                // =4
    18d0:      	b	0x2210 <generic_retuprobe_filter_arg+0x2210>
    18d4:      	cmp	w9, #0xc
    18d8:      	b.eq	0x18e4 <generic_retuprobe_filter_arg+0x18e4>
    18dc:      	cmp	w9, #0xa
    18e0:      	b.ne	0x22d4 <generic_retuprobe_filter_arg+0x22d4>
    18e4:      	ldr	x12, [x22]
    18e8:      	cmp	x12, x11
    18ec:      	ldr	x12, [sp, #0x48]
    18f0:      	b.gt	0x140 <generic_retuprobe_filter_arg+0x140>
    18f4:      	b	0x22f8 <generic_retuprobe_filter_arg+0x22f8>
    18f8:      	ldr	w9, [x29, #0x8]
    18fc:      	cmp	w9, #0xd
    1900:      	b.lo	0x5c0 <generic_retuprobe_filter_arg+0x5c0>
    1904:      	ldr	w10, [x29, #0x14]
    1908:      	cbz	w10, 0x5c0 <generic_retuprobe_filter_arg+0x5c0>
    190c:      	cmp	w10, w8
    1910:      	b.eq	0x31c <generic_retuprobe_filter_arg+0x31c>
    1914:      	cmp	w9, #0x11
    1918:      	b.lo	0x5c0 <generic_retuprobe_filter_arg+0x5c0>
    191c:      	ldr	w10, [x29, #0x18]
    1920:      	cbz	w10, 0x5c0 <generic_retuprobe_filter_arg+0x5c0>
    1924:      	cmp	w10, w8
    1928:      	b.eq	0x31c <generic_retuprobe_filter_arg+0x31c>
    192c:      	cmp	w9, #0x15
    1930:      	b.lo	0x1948 <generic_retuprobe_filter_arg+0x1948>
    1934:      	ldr	w9, [x29, #0x1c]
    1938:      	cbz	w9, 0x1948 <generic_retuprobe_filter_arg+0x1948>
    193c:      	cmp	w9, w8
    1940:      	cset	w23, eq
    1944:      	b	0x194c <generic_retuprobe_filter_arg+0x194c>
    1948:      	mov	x23, xzr
    194c:      	ldr	x19, [sp, #0x30]
    1950:      	b	0x280c <generic_retuprobe_filter_arg+0x280c>
    1954:      	ldp	w8, w11, [x29, #0x10]
    1958:      	ldrb	w9, [x22]
    195c:      	cmp	w8, w9
    1960:      	ldr	w10, [x29, #0x8]
    1964:      	ccmp	w11, w9, #0x0, ls
    1968:      	cset	w8, hs
    196c:      	cmp	w10, #0x11
    1970:      	b.hs	0x1998 <generic_retuprobe_filter_arg+0x1998>
    1974:      	b	0x19e0 <generic_retuprobe_filter_arg+0x19e0>
    1978:      	ldp	w8, w11, [x29, #0x10]
    197c:      	ldrh	w9, [x22]
    1980:      	cmp	w8, w9
    1984:      	ldr	w10, [x29, #0x8]
    1988:      	ccmp	w11, w9, #0x0, ls
    198c:      	cset	w8, hs
    1990:      	cmp	w10, #0x11
    1994:      	b.lo	0x19e0 <generic_retuprobe_filter_arg+0x19e0>
    1998:      	ldp	w11, w12, [x29, #0x18]
    199c:      	cmp	w11, w9
    19a0:      	ccmp	w12, w9, #0x0, ls
    19a4:      	ldr	x12, [sp, #0x48]
    19a8:      	csinc	w8, w8, wzr, lo
    19ac:      	cmp	w10, #0x19
    19b0:      	b.lo	0x19e0 <generic_retuprobe_filter_arg+0x19e0>
    19b4:      	ldp	w11, w12, [x29, #0x20]
    19b8:      	cmp	w11, w9
    19bc:      	ccmp	w12, w9, #0x0, ls
    19c0:      	ldr	x12, [sp, #0x48]
    19c4:      	csinc	w8, w8, wzr, lo
    19c8:      	cmp	w10, #0x21
    19cc:      	b.lo	0x19e0 <generic_retuprobe_filter_arg+0x19e0>
    19d0:      	ldp	w10, w11, [x29, #0x28]
    19d4:      	cmp	w10, w9
    19d8:      	ccmp	w11, w9, #0x0, ls
    19dc:      	csinc	w8, w8, wzr, lo
    19e0:      	tbz	w8, #0x0, 0x140 <generic_retuprobe_filter_arg+0x140>
    19e4:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    19e8:      	str	x21, [sp, #0x28]
    19ec:      	mov	x21, xzr
    19f0:      	mov	w23, wzr
    19f4:      	add	x19, x29, #0x10
    19f8:      	ldr	w8, [x19, x21, lsl #2]
    19fc:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    1a00:      	add	x9, sp, #0x60
    1a04:      	add	x1, sp, #0x60
    1a08:      	str	w8, [sp, #0x60]
    1a0c:      	mov	w8, #0x1                // =1
    1a10:      	ldr	x0, [x0]
    1a14:      	blr	x8
    1a18:      	cbz	x0, 0x23d4 <generic_retuprobe_filter_arg+0x23d4>
    1a1c:      	ldr	x16, [sp, #0x50]
    1a20:      	mov	w17, #0x1               // =1
    1a24:      	cbz	w22, 0x1a90 <generic_retuprobe_filter_arg+0x1a90>
    1a28:      	mov	x8, xzr
    1a2c:      	mov	x9, x24
    1a30:      	mov	x10, x22
    1a34:      	b	0x1a4c <generic_retuprobe_filter_arg+0x1a4c>
    1a38:      	add	x8, x8, #0x1
    1a3c:      	sub	x10, x10, #0x1
    1a40:      	add	x9, x9, #0x1
    1a44:      	cmp	x8, x22
    1a48:      	b.eq	0x1a90 <generic_retuprobe_filter_arg+0x1a90>
    1a4c:      	mov	x11, xzr
    1a50:      	nop
    1a54:      	nop
    1a58:      	nop
    1a5c:      	nop
    1a60:      	cmp	x10, x11
    1a64:      	b.eq	0x1a38 <generic_retuprobe_filter_arg+0x1a38>
    1a68:      	ldrb	w12, [x0, x11]
    1a6c:      	cbz	w12, 0x1a8c <generic_retuprobe_filter_arg+0x1a8c>
    1a70:      	cmp	x11, #0x62
    1a74:      	b.hi	0x1a38 <generic_retuprobe_filter_arg+0x1a38>
    1a78:      	ldrb	w13, [x9, x11]
    1a7c:      	add	x11, x11, #0x1
    1a80:      	cmp	w13, w12
    1a84:      	b.eq	0x1a60 <generic_retuprobe_filter_arg+0x1a60>
    1a88:      	b	0x1a38 <generic_retuprobe_filter_arg+0x1a38>
    1a8c:      	tbz	w8, #0x1f, 0x26e0 <generic_retuprobe_filter_arg+0x26e0>
    1a90:      	ldr	w9, [x29, #0x8]
    1a94:      	add	w8, w23, #0xc
    1a98:      	cmp	w8, w9
    1a9c:      	b.hs	0x1ab0 <generic_retuprobe_filter_arg+0x1ab0>
    1aa0:      	add	x21, x21, #0x1
    1aa4:      	add	w23, w23, #0x4
    1aa8:      	cmp	x21, #0x64
    1aac:      	b.ne	0x19f8 <generic_retuprobe_filter_arg+0x19f8>
    1ab0:      	mov	x23, xzr
    1ab4:      	b	0x26e4 <generic_retuprobe_filter_arg+0x26e4>
    1ab8:      	and	w8, w22, #0xffff
    1abc:      	cmp	w8, #0x90
    1ac0:      	b.hi	0x1f98 <generic_retuprobe_filter_arg+0x1f98>
    1ac4:      	and	w8, w22, #0xff
    1ac8:      	mov	w9, #0xab               // =171
    1acc:      	tst	w22, #0xffff
    1ad0:      	mul	w8, w8, w9
    1ad4:      	mov	w9, #0x18               // =24
    1ad8:      	lsr	w8, w8, #12
    1adc:      	msub	w8, w8, w9, w22
    1ae0:      	b.eq	0x1af0 <generic_retuprobe_filter_arg+0x1af0>
    1ae4:      	tst	w8, #0xff
    1ae8:      	mov	w11, w22
    1aec:      	b.eq	0x1b04 <generic_retuprobe_filter_arg+0x1b04>
    1af0:      	sub	w8, w22, w8, uxtb
    1af4:      	and	w9, w8, #0xffff
    1af8:      	add	w11, w8, #0x18
    1afc:      	cmp	w9, #0x78
    1b00:      	b.hi	0x1fac <generic_retuprobe_filter_arg+0x1fac>
    1b04:      	and	w8, w11, #0xff
    1b08:      	mov	w9, #0xab               // =171
    1b0c:      	mul	w8, w8, w9
    1b10:      	lsr	w8, w8, #12
    1b14:      	sub	w10, w8, #0x1
    1b18:      	b	0x1fbc <generic_retuprobe_filter_arg+0x1fbc>
    1b1c:      	ldr	x0, [sp, #0x38]
    1b20:      	ldp	x12, x16, [sp, #0x48]
    1b24:      	mov	x23, xzr
    1b28:      	ldr	w8, [x29, #0x4]
    1b2c:      	cmp	w8, #0x25
    1b30:      	b.ls	0x214c <generic_retuprobe_filter_arg+0x214c>
    1b34:      	b	0x2c94 <generic_retuprobe_filter_arg+0x2c94>
    1b38:      	ldrb	w10, [x22]
    1b3c:      	cmp	w9, w10
    1b40:      	b.lo	0x140 <generic_retuprobe_filter_arg+0x140>
    1b44:      	ldr	w9, [x29, #0x8]
    1b48:      	cmp	w9, #0xd
    1b4c:      	b.lo	0x124 <generic_retuprobe_filter_arg+0x124>
    1b50:      	ldr	w10, [x29, #0x14]
    1b54:      	cmp	w8, #0x2
    1b58:      	b.le	0x1ea0 <generic_retuprobe_filter_arg+0x1ea0>
    1b5c:      	sub	w11, w8, #0x3
    1b60:      	cmp	w11, #0x2
    1b64:      	b.hs	0x2380 <generic_retuprobe_filter_arg+0x2380>
    1b68:      	ldrb	w11, [x22]
    1b6c:      	cmp	w10, w11
    1b70:      	b.ne	0x2454 <generic_retuprobe_filter_arg+0x2454>
    1b74:      	b	0x2bdc <generic_retuprobe_filter_arg+0x2bdc>
    1b78:      	ldrh	w10, [x22]
    1b7c:      	cmp	w9, w10
    1b80:      	b.lo	0x140 <generic_retuprobe_filter_arg+0x140>
    1b84:      	ldr	w9, [x29, #0x8]
    1b88:      	cmp	w9, #0xd
    1b8c:      	b.lo	0x124 <generic_retuprobe_filter_arg+0x124>
    1b90:      	ldr	w10, [x29, #0x14]
    1b94:      	cmp	w8, #0x2
    1b98:      	b.le	0x1ec0 <generic_retuprobe_filter_arg+0x1ec0>
    1b9c:      	sub	w11, w8, #0x3
    1ba0:      	cmp	w11, #0x2
    1ba4:      	b.hs	0x2398 <generic_retuprobe_filter_arg+0x2398>
    1ba8:      	ldrh	w11, [x22]
    1bac:      	cmp	w10, w11
    1bb0:      	b.ne	0x2490 <generic_retuprobe_filter_arg+0x2490>
    1bb4:      	b	0x2bdc <generic_retuprobe_filter_arg+0x2bdc>
    1bb8:      	cmp	x0, #0x0
    1bbc:      	cset	w8, eq
    1bc0:      	ldr	x0, [sp, #0x38]
    1bc4:      	ldp	x12, x16, [sp, #0x48]
    1bc8:      	mov	w17, #0x1               // =1
    1bcc:      	mov	w23, w8
    1bd0:      	cbnz	x23, 0x140 <generic_retuprobe_filter_arg+0x140>
    1bd4:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    1bd8:      	ldr	w8, [x22]
    1bdc:      	cmp	w11, w8
    1be0:      	b.hi	0x1bec <generic_retuprobe_filter_arg+0x1bec>
    1be4:      	cmp	w8, w10
    1be8:      	b.ls	0x140 <generic_retuprobe_filter_arg+0x140>
    1bec:      	ldr	w10, [x29, #0x8]
    1bf0:      	cmp	w10, #0x11
    1bf4:      	b.lo	0xc4 <generic_retuprobe_filter_arg+0xc4>
    1bf8:      	ldp	w12, w11, [x29, #0x18]
    1bfc:      	cmp	w9, #0xc
    1c00:      	b.hi	0x20d4 <generic_retuprobe_filter_arg+0x20d4>
    1c04:      	lsl	w13, w17, w9
    1c08:      	mov	w14, #0x1402            // =5122
    1c0c:      	tst	w13, w14
    1c10:      	b.eq	0x20d4 <generic_retuprobe_filter_arg+0x20d4>
    1c14:      	cmp	w12, w8
    1c18:      	ldr	x12, [sp, #0x48]
    1c1c:      	b.gt	0x20e8 <generic_retuprobe_filter_arg+0x20e8>
    1c20:      	cmp	w8, w11
    1c24:      	b.le	0x140 <generic_retuprobe_filter_arg+0x140>
    1c28:      	b	0x20e8 <generic_retuprobe_filter_arg+0x20e8>
    1c2c:      	ldr	w10, [x22]
    1c30:      	cmp	w11, w10
    1c34:      	ccmp	w10, w8, #0x2, ls
    1c38:      	cset	w8, ls
    1c3c:      	ldr	w11, [x29, #0x8]
    1c40:      	cmp	w11, #0x11
    1c44:      	b.lo	0x2858 <generic_retuprobe_filter_arg+0x2858>
    1c48:      	ldp	w13, w12, [x29, #0x18]
    1c4c:      	cmp	w9, #0xc
    1c50:      	b.hi	0x2090 <generic_retuprobe_filter_arg+0x2090>
    1c54:      	lsl	w14, w17, w9
    1c58:      	mov	w15, #0x1402            // =5122
    1c5c:      	tst	w14, w15
    1c60:      	b.eq	0x2090 <generic_retuprobe_filter_arg+0x2090>
    1c64:      	cmp	w13, w10
    1c68:      	ccmp	w10, w12, #0x0, le
    1c6c:      	cset	w12, le
    1c70:      	b	0x209c <generic_retuprobe_filter_arg+0x209c>
    1c74:      	cmp	x13, x10
    1c78:      	ccmp	x10, x12, #0x2, ls
    1c7c:      	cset	w12, ls
    1c80:      	orr	w8, w8, w12
    1c84:      	cmp	w11, #0x29
    1c88:      	b.lo	0x2858 <generic_retuprobe_filter_arg+0x2858>
    1c8c:      	ldp	x13, x12, [x29, #0x30]
    1c90:      	cmp	w9, #0xc
    1c94:      	b.eq	0x1ca0 <generic_retuprobe_filter_arg+0x1ca0>
    1c98:      	cmp	w9, #0xa
    1c9c:      	b.ne	0x2168 <generic_retuprobe_filter_arg+0x2168>
    1ca0:      	cmp	x13, x10
    1ca4:      	ccmp	x10, x12, #0x0, le
    1ca8:      	cset	w12, le
    1cac:      	b	0x2174 <generic_retuprobe_filter_arg+0x2174>
    1cb0:      	cmp	x12, x8
    1cb4:      	ldr	x12, [sp, #0x48]
    1cb8:      	b.hi	0x1cc4 <generic_retuprobe_filter_arg+0x1cc4>
    1cbc:      	cmp	x8, x11
    1cc0:      	b.ls	0x140 <generic_retuprobe_filter_arg+0x140>
    1cc4:      	cmp	w10, #0x29
    1cc8:      	b.lo	0xc4 <generic_retuprobe_filter_arg+0xc4>
    1ccc:      	ldp	x12, x11, [x29, #0x30]
    1cd0:      	cmp	w9, #0xc
    1cd4:      	b.eq	0x1ce0 <generic_retuprobe_filter_arg+0x1ce0>
    1cd8:      	cmp	w9, #0xa
    1cdc:      	b.ne	0x2290 <generic_retuprobe_filter_arg+0x2290>
    1ce0:      	cmp	x12, x8
    1ce4:      	ldr	x12, [sp, #0x48]
    1ce8:      	b.gt	0x22a4 <generic_retuprobe_filter_arg+0x22a4>
    1cec:      	cmp	x8, x11
    1cf0:      	b.le	0x140 <generic_retuprobe_filter_arg+0x140>
    1cf4:      	b	0x22a4 <generic_retuprobe_filter_arg+0x22a4>
    1cf8:      	mov	x19, xzr
    1cfc:      	cmp	w9, #0x29
    1d00:      	b.ne	0x1d0c <generic_retuprobe_filter_arg+0x1d0c>
    1d04:      	cbz	x10, 0x1d0c <generic_retuprobe_filter_arg+0x1d0c>
    1d08:      	ldrb	w19, [x10, #0x3a]
    1d0c:      	cmp	w9, #0x29
    1d10:      	b.eq	0x1d1c <generic_retuprobe_filter_arg+0x1d1c>
    1d14:      	cmp	w9, #0x7
    1d18:      	b.ne	0x21bc <generic_retuprobe_filter_arg+0x21bc>
    1d1c:      	ldrb	w8, [x29, #0x10]
    1d20:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    1d24:      	add	x9, sp, #0xac
    1d28:      	add	x1, sp, #0xac
    1d2c:      	str	w8, [sp, #0xac]
    1d30:      	mov	w8, #0x1                // =1
    1d34:      	ldr	x0, [x0]
    1d38:      	blr	x8
    1d3c:      	cbz	x0, 0x21a4 <generic_retuprobe_filter_arg+0x21a4>
    1d40:      	str	x19, [sp, #0x88]
    1d44:      	mov	w8, #0x1                // =1
    1d48:      	add	x9, sp, #0x88
    1d4c:      	add	x1, sp, #0x88
    1d50:      	blr	x8
    1d54:      	ldr	w9, [x29, #0x4]
    1d58:      	mov	w8, wzr
    1d5c:      	cmp	w9, #0x1d
    1d60:      	b.hi	0x2ca8 <generic_retuprobe_filter_arg+0x2ca8>
    1d64:      	ldr	x19, [sp, #0x30]
    1d68:      	b	0x1698 <generic_retuprobe_filter_arg+0x1698>
    1d6c:      	ldr	w11, [x22]
    1d70:      	cmp	w11, w10
    1d74:      	b.hi	0x140 <generic_retuprobe_filter_arg+0x140>
    1d78:      	b	0x1d88 <generic_retuprobe_filter_arg+0x1d88>
    1d7c:      	ldr	w11, [x22]
    1d80:      	cmp	w11, w10
    1d84:      	b.lo	0x140 <generic_retuprobe_filter_arg+0x140>
    1d88:      	ldr	w10, [x29, #0x8]
    1d8c:      	cmp	w10, #0xd
    1d90:      	b.lo	0x124 <generic_retuprobe_filter_arg+0x124>
    1d94:      	ldr	w11, [x29, #0x14]
    1d98:      	cmp	w8, #0x2
    1d9c:      	b.le	0x1dc0 <generic_retuprobe_filter_arg+0x1dc0>
    1da0:      	sub	w12, w8, #0x3
    1da4:      	cmp	w12, #0x2
    1da8:      	b.hs	0x1dfc <generic_retuprobe_filter_arg+0x1dfc>
    1dac:      	ldr	w12, [x22]
    1db0:      	cmp	w12, w11
    1db4:      	ldr	x12, [sp, #0x48]
    1db8:      	b.ne	0x257c <generic_retuprobe_filter_arg+0x257c>
    1dbc:      	b	0x2bdc <generic_retuprobe_filter_arg+0x2bdc>
    1dc0:      	cmp	w8, #0x1
    1dc4:      	b.eq	0x1e1c <generic_retuprobe_filter_arg+0x1e1c>
    1dc8:      	cmp	w8, #0x2
    1dcc:      	b.ne	0x257c <generic_retuprobe_filter_arg+0x257c>
    1dd0:      	cmp	w9, #0xc
    1dd4:      	b.hi	0x256c <generic_retuprobe_filter_arg+0x256c>
    1dd8:      	lsl	w12, w17, w9
    1ddc:      	mov	w13, #0x1402            // =5122
    1de0:      	tst	w12, w13
    1de4:      	b.eq	0x256c <generic_retuprobe_filter_arg+0x256c>
    1de8:      	ldr	w12, [x22]
    1dec:      	cmp	w12, w11
    1df0:      	ldr	x12, [sp, #0x48]
    1df4:      	b.lt	0x140 <generic_retuprobe_filter_arg+0x140>
    1df8:      	b	0x257c <generic_retuprobe_filter_arg+0x257c>
    1dfc:      	ldr	x12, [sp, #0x48]
    1e00:      	cmp	w8, #0xc
    1e04:      	b.ne	0x257c <generic_retuprobe_filter_arg+0x257c>
    1e08:      	ldr	w12, [x22]
    1e0c:      	tst	w12, w11
    1e10:      	ldr	x12, [sp, #0x48]
    1e14:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
    1e18:      	b	0x257c <generic_retuprobe_filter_arg+0x257c>
    1e1c:      	cmp	w9, #0xc
    1e20:      	b.hi	0x2558 <generic_retuprobe_filter_arg+0x2558>
    1e24:      	lsl	w12, w17, w9
    1e28:      	mov	w13, #0x1402            // =5122
    1e2c:      	tst	w12, w13
    1e30:      	b.eq	0x2558 <generic_retuprobe_filter_arg+0x2558>
    1e34:      	ldr	w12, [x22]
    1e38:      	cmp	w12, w11
    1e3c:      	ldr	x12, [sp, #0x48]
    1e40:      	b.gt	0x140 <generic_retuprobe_filter_arg+0x140>
    1e44:      	b	0x257c <generic_retuprobe_filter_arg+0x257c>
    1e48:      	ldr	x16, [sp, #0x50]
    1e4c:      	ldr	x21, [sp, #0x28]
    1e50:      	mov	x23, xzr
    1e54:      	mov	w17, #0x1               // =1
    1e58:      	b	0x2138 <generic_retuprobe_filter_arg+0x2138>
    1e5c:      	ldr	x16, [sp, #0x50]
    1e60:      	mov	x23, xzr
    1e64:      	mov	w17, #0x1               // =1
    1e68:      	b	0x2134 <generic_retuprobe_filter_arg+0x2134>
    1e6c:      	ldr	w8, [x29, #0x4]
    1e70:      	b	0x1e7c <generic_retuprobe_filter_arg+0x1e7c>
    1e74:      	ldr	w8, [x29, #0x4]
    1e78:      	mov	x21, x19
    1e7c:      	ldp	x19, x0, [sp, #0x30]
    1e80:      	and	w8, w8, #0xfffffffe
    1e84:      	cmp	w8, #0x18
    1e88:      	cset	w8, eq
    1e8c:      	ldp	x12, x16, [sp, #0x48]
    1e90:      	mov	w17, #0x1               // =1
    1e94:      	mov	w23, w8
    1e98:      	cbnz	x23, 0x140 <generic_retuprobe_filter_arg+0x140>
    1e9c:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    1ea0:      	cmp	w8, #0x1
    1ea4:      	b.eq	0x2448 <generic_retuprobe_filter_arg+0x2448>
    1ea8:      	cmp	w8, #0x2
    1eac:      	b.ne	0x2454 <generic_retuprobe_filter_arg+0x2454>
    1eb0:      	ldrb	w11, [x22]
    1eb4:      	cmp	w10, w11
    1eb8:      	b.hi	0x140 <generic_retuprobe_filter_arg+0x140>
    1ebc:      	b	0x2454 <generic_retuprobe_filter_arg+0x2454>
    1ec0:      	cmp	w8, #0x1
    1ec4:      	b.eq	0x2484 <generic_retuprobe_filter_arg+0x2484>
    1ec8:      	cmp	w8, #0x2
    1ecc:      	b.ne	0x2490 <generic_retuprobe_filter_arg+0x2490>
    1ed0:      	ldrh	w11, [x22]
    1ed4:      	cmp	w10, w11
    1ed8:      	b.hi	0x140 <generic_retuprobe_filter_arg+0x140>
    1edc:      	b	0x2490 <generic_retuprobe_filter_arg+0x2490>
    1ee0:      	strh	w24, [x0], #0x2
    1ee4:      	mov	w8, #0x4                // =4
    1ee8:      	mov	w1, w24
    1eec:      	blr	x8
    1ef0:      	ldr	w8, [sp, #0x10]
    1ef4:      	and	w8, w8, #0xffff
    1ef8:      	cmp	w8, w24
    1efc:      	b.ls	0x1f1c <generic_retuprobe_filter_arg+0x1f1c>
    1f00:      	add	x9, x22, x24
    1f04:      	sub	w8, w8, w24
    1f08:      	ldr	x2, [sp, #0x8]
    1f0c:      	add	x0, x9, #0x2
    1f10:      	and	w1, w8, #0xfff
    1f14:      	mov	w8, #0x4                // =4
    1f18:      	blr	x8
    1f1c:      	ldr	w8, [sp, #0x1c]
    1f20:      	cmp	w23, #0x3
    1f24:      	str	w8, [sp, #0x60]
    1f28:      	b.gt	0x1f60 <generic_retuprobe_filter_arg+0x1f60>
    1f2c:      	ldr	x0, [sp, #0x38]
    1f30:      	ldp	x12, x16, [sp, #0x48]
    1f34:      	cmp	w23, #0x1
    1f38:      	mov	w17, #0x1               // =1
    1f3c:      	b.gt	0x23e4 <generic_retuprobe_filter_arg+0x23e4>
    1f40:      	cbz	w23, 0x2798 <generic_retuprobe_filter_arg+0x2798>
    1f44:      	cmp	w23, #0x1
    1f48:      	b.ne	0x5c0 <generic_retuprobe_filter_arg+0x5c0>
    1f4c:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    1f50:      	mov	w8, #0x1                // =1
    1f54:      	add	x9, sp, #0x60
    1f58:      	ldr	x0, [x0]
    1f5c:      	b	0x27e4 <generic_retuprobe_filter_arg+0x27e4>
    1f60:      	ldr	x0, [sp, #0x38]
    1f64:      	ldp	x12, x16, [sp, #0x48]
    1f68:      	cmp	w23, #0x5
    1f6c:      	mov	w17, #0x1               // =1
    1f70:      	b.gt	0x2408 <generic_retuprobe_filter_arg+0x2408>
    1f74:      	cmp	w23, #0x4
    1f78:      	b.eq	0x27ac <generic_retuprobe_filter_arg+0x27ac>
    1f7c:      	cmp	w23, #0x5
    1f80:      	b.ne	0x5c0 <generic_retuprobe_filter_arg+0x5c0>
    1f84:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    1f88:      	mov	w8, #0x1                // =1
    1f8c:      	add	x9, sp, #0x60
    1f90:      	ldr	x0, [x0]
    1f94:      	b	0x27e4 <generic_retuprobe_filter_arg+0x27e4>
    1f98:      	and	w8, w22, #0xffff
    1f9c:      	mov	w9, #0x1fe              // =510
    1fa0:      	cmp	w8, #0x100
    1fa4:      	mov	w8, #0x100              // =256
    1fa8:      	csel	w11, w9, w8, hi
    1fac:      	and	w8, w11, #0xffff
    1fb0:      	cmp	w8, #0x100
    1fb4:      	mov	w8, #0x6                // =6
    1fb8:      	cinc	w10, w8, ne
    1fbc:      	add	x8, x29, #0x10
    1fc0:      	and	w9, w10, #0xf
    1fc4:      	ldr	w8, [x8, w9, uxtw #2]
    1fc8:      	cmn	w8, #0x1
    1fcc:      	b.eq	0x2c54 <generic_retuprobe_filter_arg+0x2c54>
    1fd0:      	stp	w11, w8, [sp, #0x1c]
    1fd4:      	str	w10, [sp, #0x28]
    1fd8:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    1fdc:      	mov	w8, #0x1                // =1
    1fe0:      	add	x19, sp, #0x88
    1fe4:      	add	x1, sp, #0x88
    1fe8:      	ldr	x0, [x0]
    1fec:      	blr	x8
    1ff0:      	mov	x9, x0
    1ff4:      	adrp	x0, 0x1000 <generic_retuprobe_filter_arg+0x1000>
    1ff8:      	mov	w8, #0x1                // =1
    1ffc:      	ldr	x0, [x0]
    2000:      	add	x1, sp, #0x88
    2004:      	mov	x19, x9
    2008:      	blr	x8
    200c:      	mov	x23, xzr
    2010:      	cbz	x19, 0x2c58 <generic_retuprobe_filter_arg+0x2c58>
    2014:      	mov	x8, x0
    2018:      	ldr	x0, [sp, #0x38]
    201c:      	ldp	x12, x16, [sp, #0x48]
    2020:      	mov	w17, #0x1               // =1
    2024:      	cbz	x8, 0x2c64 <generic_retuprobe_filter_arg+0x2c64>
    2028:      	ldr	w23, [sp, #0x28]
    202c:      	mov	x0, x19
    2030:      	str	x8, [sp, #0x10]
    2034:      	cmp	w23, #0x5
    2038:      	b.gt	0x26f4 <generic_retuprobe_filter_arg+0x26f4>
    203c:      	strb	w22, [x0], #0x1
    2040:      	mov	w8, #0x4                // =4
    2044:      	mov	w1, w22
    2048:      	mov	x2, x24
    204c:      	blr	x8
    2050:      	ldr	w8, [sp, #0x1c]
    2054:      	and	w8, w8, #0xffff
    2058:      	cmp	w8, w22
    205c:      	b.ls	0x2734 <generic_retuprobe_filter_arg+0x2734>
    2060:      	add	x9, x19, x22
    2064:      	sub	w8, w8, w22
    2068:      	ldr	x2, [sp, #0x10]
    206c:      	add	x0, x9, #0x1
    2070:      	and	w1, w8, #0xfff
    2074:      	mov	w8, #0x4                // =4
    2078:      	b	0x2730 <generic_retuprobe_filter_arg+0x2730>
    207c:      	ldr	x0, [sp, #0x38]
    2080:      	mov	w8, wzr
    2084:      	mov	w23, wzr
    2088:      	cbnz	x23, 0x140 <generic_retuprobe_filter_arg+0x140>
    208c:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    2090:      	cmp	w13, w10
    2094:      	ccmp	w10, w12, #0x2, ls
    2098:      	cset	w12, ls
    209c:      	orr	w8, w8, w12
    20a0:      	cmp	w11, #0x19
    20a4:      	b.lo	0x2858 <generic_retuprobe_filter_arg+0x2858>
    20a8:      	ldp	w13, w12, [x29, #0x20]
    20ac:      	cmp	w9, #0xc
    20b0:      	b.hi	0x24c8 <generic_retuprobe_filter_arg+0x24c8>
    20b4:      	lsl	w14, w17, w9
    20b8:      	mov	w15, #0x1402            // =5122
    20bc:      	tst	w14, w15
    20c0:      	b.eq	0x24c8 <generic_retuprobe_filter_arg+0x24c8>
    20c4:      	cmp	w13, w10
    20c8:      	ccmp	w10, w12, #0x0, le
    20cc:      	cset	w12, le
    20d0:      	b	0x24d4 <generic_retuprobe_filter_arg+0x24d4>
    20d4:      	cmp	w12, w8
    20d8:      	ldr	x12, [sp, #0x48]
    20dc:      	b.hi	0x20e8 <generic_retuprobe_filter_arg+0x20e8>
    20e0:      	cmp	w8, w11
    20e4:      	b.ls	0x140 <generic_retuprobe_filter_arg+0x140>
    20e8:      	cmp	w10, #0x19
    20ec:      	b.lo	0xc4 <generic_retuprobe_filter_arg+0xc4>
    20f0:      	ldp	w12, w11, [x29, #0x20]
    20f4:      	cmp	w9, #0xc
    20f8:      	b.hi	0x250c <generic_retuprobe_filter_arg+0x250c>
    20fc:      	lsl	w13, w17, w9
    2100:      	mov	w14, #0x1402            // =5122
    2104:      	tst	w13, w14
    2108:      	b.eq	0x250c <generic_retuprobe_filter_arg+0x250c>
    210c:      	cmp	w12, w8
    2110:      	ldr	x12, [sp, #0x48]
    2114:      	b.gt	0x2520 <generic_retuprobe_filter_arg+0x2520>
    2118:      	cmp	w8, w11
    211c:      	b.le	0x140 <generic_retuprobe_filter_arg+0x140>
    2120:      	b	0x2520 <generic_retuprobe_filter_arg+0x2520>
    2124:      	ldr	x21, [sp, #0x28]
    2128:      	mov	w23, #0x1               // =1
    212c:      	b	0x2138 <generic_retuprobe_filter_arg+0x2138>
    2130:      	mov	w23, #0x1               // =1
    2134:      	mov	x21, x19
    2138:      	ldp	x19, x0, [sp, #0x30]
    213c:      	ldr	x12, [sp, #0x48]
    2140:      	ldr	w8, [x29, #0x4]
    2144:      	cmp	w8, #0x25
    2148:      	b.hi	0x2c94 <generic_retuprobe_filter_arg+0x2c94>
    214c:      	mov	x9, #0x50               // =80
    2150:      	lsl	x8, x17, x8
    2154:      	movk	x9, #0xc00, lsl #16
    2158:      	movk	x9, #0x20, lsl #32
    215c:      	tst	x8, x9
    2160:      	b.ne	0x2c8c <generic_retuprobe_filter_arg+0x2c8c>
    2164:      	b	0x2c94 <generic_retuprobe_filter_arg+0x2c94>
    2168:      	cmp	x13, x10
    216c:      	ccmp	x10, x12, #0x2, ls
    2170:      	cset	w12, ls
    2174:      	orr	w8, w8, w12
    2178:      	cmp	w11, #0x39
    217c:      	b.lo	0x2858 <generic_retuprobe_filter_arg+0x2858>
    2180:      	ldp	x12, x11, [x29, #0x40]
    2184:      	cmp	w9, #0xc
    2188:      	b.eq	0x2194 <generic_retuprobe_filter_arg+0x2194>
    218c:      	cmp	w9, #0xa
    2190:      	b.ne	0x2638 <generic_retuprobe_filter_arg+0x2638>
    2194:      	cmp	x12, x10
    2198:      	ccmp	x10, x11, #0x0, le
    219c:      	cset	w9, le
    21a0:      	b	0x2854 <generic_retuprobe_filter_arg+0x2854>
    21a4:      	ldp	x19, x0, [sp, #0x30]
    21a8:      	mov	x23, xzr
    21ac:      	ldp	x12, x16, [sp, #0x48]
    21b0:      	mov	w17, #0x1               // =1
    21b4:      	cbnz	xzr, 0x140 <generic_retuprobe_filter_arg+0x140>
    21b8:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    21bc:      	ldr	x19, [sp, #0x30]
    21c0:      	mov	x23, xzr
    21c4:      	cbnz	xzr, 0x140 <generic_retuprobe_filter_arg+0x140>
    21c8:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    21cc:      	mov	x0, x8
    21d0:      	mov	x9, x8
    21d4:      	mov	w8, #0x4                // =4
    21d8:      	mov	w1, w24
    21dc:      	mov	x2, x22
    21e0:      	strh	w24, [x0], #0x2
    21e4:      	mov	x22, x9
    21e8:      	blr	x8
    21ec:      	ldr	w8, [sp, #0x10]
    21f0:      	and	w8, w8, #0xffff
    21f4:      	cmp	w8, w24
    21f8:      	b.ls	0x2218 <generic_retuprobe_filter_arg+0x2218>
    21fc:      	add	x9, x22, x24
    2200:      	sub	w8, w8, w24
    2204:      	add	x0, x9, #0x2
    2208:      	and	w1, w8, #0xfff
    220c:      	mov	w8, #0x4                // =4
    2210:      	mov	x2, x23
    2214:      	blr	x8
    2218:      	ldr	w8, [sp, #0x1c]
    221c:      	str	w8, [sp, #0x60]
    2220:      	ldr	w8, [sp, #0x28]
    2224:      	cmp	w8, #0x3
    2228:      	b.gt	0x225c <generic_retuprobe_filter_arg+0x225c>
    222c:      	ldp	x12, x16, [sp, #0x48]
    2230:      	cmp	w8, #0x1
    2234:      	mov	w17, #0x1               // =1
    2238:      	b.gt	0x2644 <generic_retuprobe_filter_arg+0x2644>
    223c:      	cbz	w8, 0x296c <generic_retuprobe_filter_arg+0x296c>
    2240:      	cmp	w8, #0x1
    2244:      	b.ne	0x29e4 <generic_retuprobe_filter_arg+0x29e4>
    2248:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    224c:      	mov	w8, #0x1                // =1
    2250:      	add	x9, sp, #0x60
    2254:      	ldr	x0, [x0]
    2258:      	b	0x29b8 <generic_retuprobe_filter_arg+0x29b8>
    225c:      	ldp	x12, x16, [sp, #0x48]
    2260:      	cmp	w8, #0x5
    2264:      	mov	w17, #0x1               // =1
    2268:      	b.gt	0x2668 <generic_retuprobe_filter_arg+0x2668>
    226c:      	cmp	w8, #0x4
    2270:      	b.eq	0x2980 <generic_retuprobe_filter_arg+0x2980>
    2274:      	cmp	w8, #0x5
    2278:      	b.ne	0x29e4 <generic_retuprobe_filter_arg+0x29e4>
    227c:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2280:      	mov	w8, #0x1                // =1
    2284:      	add	x9, sp, #0x60
    2288:      	ldr	x0, [x0]
    228c:      	b	0x29b8 <generic_retuprobe_filter_arg+0x29b8>
    2290:      	cmp	x12, x8
    2294:      	ldr	x12, [sp, #0x48]
    2298:      	b.hi	0x22a4 <generic_retuprobe_filter_arg+0x22a4>
    229c:      	cmp	x8, x11
    22a0:      	b.ls	0x140 <generic_retuprobe_filter_arg+0x140>
    22a4:      	cmp	w10, #0x39
    22a8:      	b.lo	0xc4 <generic_retuprobe_filter_arg+0xc4>
    22ac:      	ldp	x11, x10, [x29, #0x40]
    22b0:      	cmp	w9, #0xc
    22b4:      	b.eq	0x22c0 <generic_retuprobe_filter_arg+0x22c0>
    22b8:      	cmp	w9, #0xa
    22bc:      	b.ne	0x268c <generic_retuprobe_filter_arg+0x268c>
    22c0:      	cmp	x11, x8
    22c4:      	b.gt	0xc4 <generic_retuprobe_filter_arg+0xc4>
    22c8:      	cmp	x8, x10
    22cc:      	b.le	0x140 <generic_retuprobe_filter_arg+0x140>
    22d0:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    22d4:      	ldr	x12, [x22]
    22d8:      	cmp	x12, x11
    22dc:      	ldr	x12, [sp, #0x48]
    22e0:      	b.hi	0x140 <generic_retuprobe_filter_arg+0x140>
    22e4:      	b	0x22f8 <generic_retuprobe_filter_arg+0x22f8>
    22e8:      	ldr	x12, [x22]
    22ec:      	cmp	x12, x11
    22f0:      	ldr	x12, [sp, #0x48]
    22f4:      	b.lo	0x140 <generic_retuprobe_filter_arg+0x140>
    22f8:      	cmp	w10, #0x19
    22fc:      	b.lo	0x124 <generic_retuprobe_filter_arg+0x124>
    2300:      	ldr	x11, [x29, #0x20]
    2304:      	cmp	w8, #0x2
    2308:      	b.le	0x232c <generic_retuprobe_filter_arg+0x232c>
    230c:      	sub	w12, w8, #0x3
    2310:      	cmp	w12, #0x2
    2314:      	b.hs	0x2360 <generic_retuprobe_filter_arg+0x2360>
    2318:      	ldr	x12, [x22]
    231c:      	cmp	x12, x11
    2320:      	ldr	x12, [sp, #0x48]
    2324:      	b.ne	0x2888 <generic_retuprobe_filter_arg+0x2888>
    2328:      	b	0x2bdc <generic_retuprobe_filter_arg+0x2bdc>
    232c:      	cmp	w8, #0x1
    2330:      	b.eq	0x23b0 <generic_retuprobe_filter_arg+0x23b0>
    2334:      	cmp	w8, #0x2
    2338:      	b.ne	0x2888 <generic_retuprobe_filter_arg+0x2888>
    233c:      	cmp	w9, #0xc
    2340:      	b.eq	0x234c <generic_retuprobe_filter_arg+0x234c>
    2344:      	cmp	w9, #0xa
    2348:      	b.ne	0x2878 <generic_retuprobe_filter_arg+0x2878>
    234c:      	ldr	x12, [x22]
    2350:      	cmp	x12, x11
    2354:      	ldr	x12, [sp, #0x48]
    2358:      	b.lt	0x140 <generic_retuprobe_filter_arg+0x140>
    235c:      	b	0x2888 <generic_retuprobe_filter_arg+0x2888>
    2360:      	ldr	x12, [sp, #0x48]
    2364:      	cmp	w8, #0xc
    2368:      	b.ne	0x2888 <generic_retuprobe_filter_arg+0x2888>
    236c:      	ldr	x12, [x22]
    2370:      	tst	x12, x11
    2374:      	ldr	x12, [sp, #0x48]
    2378:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
    237c:      	b	0x2888 <generic_retuprobe_filter_arg+0x2888>
    2380:      	cmp	w8, #0xc
    2384:      	b.ne	0x2454 <generic_retuprobe_filter_arg+0x2454>
    2388:      	ldrb	w11, [x22]
    238c:      	tst	w10, w11
    2390:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
    2394:      	b	0x2454 <generic_retuprobe_filter_arg+0x2454>
    2398:      	cmp	w8, #0xc
    239c:      	b.ne	0x2490 <generic_retuprobe_filter_arg+0x2490>
    23a0:      	ldrh	w11, [x22]
    23a4:      	tst	w10, w11
    23a8:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
    23ac:      	b	0x2490 <generic_retuprobe_filter_arg+0x2490>
    23b0:      	cmp	w9, #0xc
    23b4:      	b.eq	0x23c0 <generic_retuprobe_filter_arg+0x23c0>
    23b8:      	cmp	w9, #0xa
    23bc:      	b.ne	0x2864 <generic_retuprobe_filter_arg+0x2864>
    23c0:      	ldr	x12, [x22]
    23c4:      	cmp	x12, x11
    23c8:      	ldr	x12, [sp, #0x48]
    23cc:      	b.gt	0x140 <generic_retuprobe_filter_arg+0x140>
    23d0:      	b	0x2888 <generic_retuprobe_filter_arg+0x2888>
    23d4:      	ldr	x16, [sp, #0x50]
    23d8:      	mov	x23, xzr
    23dc:      	mov	w17, #0x1               // =1
    23e0:      	b	0x26e4 <generic_retuprobe_filter_arg+0x26e4>
    23e4:      	cmp	w23, #0x2
    23e8:      	b.eq	0x27c0 <generic_retuprobe_filter_arg+0x27c0>
    23ec:      	cmp	w23, #0x3
    23f0:      	b.ne	0x5c0 <generic_retuprobe_filter_arg+0x5c0>
    23f4:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    23f8:      	mov	w8, #0x1                // =1
    23fc:      	add	x9, sp, #0x60
    2400:      	ldr	x0, [x0]
    2404:      	b	0x27e4 <generic_retuprobe_filter_arg+0x27e4>
    2408:      	cmp	w23, #0x6
    240c:      	b.eq	0x27d4 <generic_retuprobe_filter_arg+0x27d4>
    2410:      	cmp	w23, #0x7
    2414:      	b.ne	0x5c0 <generic_retuprobe_filter_arg+0x5c0>
    2418:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    241c:      	mov	w8, #0x1                // =1
    2420:      	add	x9, sp, #0x60
    2424:      	ldr	x0, [x0]
    2428:      	b	0x27e4 <generic_retuprobe_filter_arg+0x27e4>
    242c:      	mov	x23, xzr
    2430:      	b	0x2438 <generic_retuprobe_filter_arg+0x2438>
    2434:      	mov	w23, #0x1               // =1
    2438:      	ldp	x12, x16, [sp, #0x48]
    243c:      	mov	w17, #0x1               // =1
    2440:      	ldr	x0, [sp, #0x38]
    2444:      	b	0x2c64 <generic_retuprobe_filter_arg+0x2c64>
    2448:      	ldrb	w11, [x22]
    244c:      	cmp	w10, w11
    2450:      	b.lo	0x140 <generic_retuprobe_filter_arg+0x140>
    2454:      	cmp	w9, #0x11
    2458:      	b.lo	0x124 <generic_retuprobe_filter_arg+0x124>
    245c:      	ldr	w10, [x29, #0x18]
    2460:      	cmp	w8, #0x2
    2464:      	b.le	0x26a0 <generic_retuprobe_filter_arg+0x26a0>
    2468:      	sub	w11, w8, #0x3
    246c:      	cmp	w11, #0x2
    2470:      	b.hs	0x2908 <generic_retuprobe_filter_arg+0x2908>
    2474:      	ldrb	w11, [x22]
    2478:      	cmp	w10, w11
    247c:      	b.ne	0x2a50 <generic_retuprobe_filter_arg+0x2a50>
    2480:      	b	0x2bdc <generic_retuprobe_filter_arg+0x2bdc>
    2484:      	ldrh	w11, [x22]
    2488:      	cmp	w10, w11
    248c:      	b.lo	0x140 <generic_retuprobe_filter_arg+0x140>
    2490:      	cmp	w9, #0x11
    2494:      	b.lo	0x124 <generic_retuprobe_filter_arg+0x124>
    2498:      	ldr	w10, [x29, #0x18]
    249c:      	cmp	w8, #0x2
    24a0:      	b.le	0x26c0 <generic_retuprobe_filter_arg+0x26c0>
    24a4:      	sub	w11, w8, #0x3
    24a8:      	cmp	w11, #0x2
    24ac:      	b.hs	0x2920 <generic_retuprobe_filter_arg+0x2920>
    24b0:      	ldrh	w11, [x22]
    24b4:      	cmp	w10, w11
    24b8:      	b.ne	0x2a94 <generic_retuprobe_filter_arg+0x2a94>
    24bc:      	b	0x2bdc <generic_retuprobe_filter_arg+0x2bdc>
    24c0:      	ldr	x0, [sp, #0x38]
    24c4:      	b	0x2c64 <generic_retuprobe_filter_arg+0x2c64>
    24c8:      	cmp	w13, w10
    24cc:      	ccmp	w10, w12, #0x2, ls
    24d0:      	cset	w12, ls
    24d4:      	orr	w8, w8, w12
    24d8:      	cmp	w11, #0x21
    24dc:      	b.lo	0x2858 <generic_retuprobe_filter_arg+0x2858>
    24e0:      	ldp	w12, w11, [x29, #0x28]
    24e4:      	cmp	w9, #0xc
    24e8:      	b.hi	0x2848 <generic_retuprobe_filter_arg+0x2848>
    24ec:      	lsl	w9, w17, w9
    24f0:      	mov	w13, #0x1402            // =5122
    24f4:      	tst	w9, w13
    24f8:      	b.eq	0x2848 <generic_retuprobe_filter_arg+0x2848>
    24fc:      	cmp	w12, w10
    2500:      	ccmp	w10, w11, #0x0, le
    2504:      	cset	w9, le
    2508:      	b	0x2854 <generic_retuprobe_filter_arg+0x2854>
    250c:      	cmp	w12, w8
    2510:      	ldr	x12, [sp, #0x48]
    2514:      	b.hi	0x2520 <generic_retuprobe_filter_arg+0x2520>
    2518:      	cmp	w8, w11
    251c:      	b.ls	0x140 <generic_retuprobe_filter_arg+0x140>
    2520:      	cmp	w10, #0x21
    2524:      	b.lo	0xc4 <generic_retuprobe_filter_arg+0xc4>
    2528:      	ldp	w11, w10, [x29, #0x28]
    252c:      	cmp	w9, #0xc
    2530:      	b.hi	0x2938 <generic_retuprobe_filter_arg+0x2938>
    2534:      	lsl	w9, w17, w9
    2538:      	mov	w13, #0x1402            // =5122
    253c:      	tst	w9, w13
    2540:      	b.eq	0x2938 <generic_retuprobe_filter_arg+0x2938>
    2544:      	cmp	w11, w8
    2548:      	b.gt	0xc4 <generic_retuprobe_filter_arg+0xc4>
    254c:      	cmp	w8, w10
    2550:      	b.le	0x140 <generic_retuprobe_filter_arg+0x140>
    2554:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    2558:      	ldr	w12, [x22]
    255c:      	cmp	w12, w11
    2560:      	ldr	x12, [sp, #0x48]
    2564:      	b.hi	0x140 <generic_retuprobe_filter_arg+0x140>
    2568:      	b	0x257c <generic_retuprobe_filter_arg+0x257c>
    256c:      	ldr	w12, [x22]
    2570:      	cmp	w12, w11
    2574:      	ldr	x12, [sp, #0x48]
    2578:      	b.lo	0x140 <generic_retuprobe_filter_arg+0x140>
    257c:      	cmp	w10, #0x11
    2580:      	b.lo	0x124 <generic_retuprobe_filter_arg+0x124>
    2584:      	ldr	w11, [x29, #0x18]
    2588:      	cmp	w8, #0x2
    258c:      	b.le	0x25b0 <generic_retuprobe_filter_arg+0x25b0>
    2590:      	sub	w12, w8, #0x3
    2594:      	cmp	w12, #0x2
    2598:      	b.hs	0x25ec <generic_retuprobe_filter_arg+0x25ec>
    259c:      	ldr	w12, [x22]
    25a0:      	cmp	w12, w11
    25a4:      	ldr	x12, [sp, #0x48]
    25a8:      	b.ne	0x2af0 <generic_retuprobe_filter_arg+0x2af0>
    25ac:      	b	0x2bdc <generic_retuprobe_filter_arg+0x2bdc>
    25b0:      	cmp	w8, #0x1
    25b4:      	b.eq	0x260c <generic_retuprobe_filter_arg+0x260c>
    25b8:      	cmp	w8, #0x2
    25bc:      	b.ne	0x2af0 <generic_retuprobe_filter_arg+0x2af0>
    25c0:      	cmp	w9, #0xc
    25c4:      	b.hi	0x2ae0 <generic_retuprobe_filter_arg+0x2ae0>
    25c8:      	lsl	w12, w17, w9
    25cc:      	mov	w13, #0x1402            // =5122
    25d0:      	tst	w12, w13
    25d4:      	b.eq	0x2ae0 <generic_retuprobe_filter_arg+0x2ae0>
    25d8:      	ldr	w12, [x22]
    25dc:      	cmp	w12, w11
    25e0:      	ldr	x12, [sp, #0x48]
    25e4:      	b.lt	0x140 <generic_retuprobe_filter_arg+0x140>
    25e8:      	b	0x2af0 <generic_retuprobe_filter_arg+0x2af0>
    25ec:      	ldr	x12, [sp, #0x48]
    25f0:      	cmp	w8, #0xc
    25f4:      	b.ne	0x2af0 <generic_retuprobe_filter_arg+0x2af0>
    25f8:      	ldr	w12, [x22]
    25fc:      	tst	w12, w11
    2600:      	ldr	x12, [sp, #0x48]
    2604:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
    2608:      	b	0x2af0 <generic_retuprobe_filter_arg+0x2af0>
    260c:      	cmp	w9, #0xc
    2610:      	b.hi	0x2acc <generic_retuprobe_filter_arg+0x2acc>
    2614:      	lsl	w12, w17, w9
    2618:      	mov	w13, #0x1402            // =5122
    261c:      	tst	w12, w13
    2620:      	b.eq	0x2acc <generic_retuprobe_filter_arg+0x2acc>
    2624:      	ldr	w12, [x22]
    2628:      	cmp	w12, w11
    262c:      	ldr	x12, [sp, #0x48]
    2630:      	b.gt	0x140 <generic_retuprobe_filter_arg+0x140>
    2634:      	b	0x2af0 <generic_retuprobe_filter_arg+0x2af0>
    2638:      	cmp	x12, x10
    263c:      	ccmp	x10, x11, #0x2, ls
    2640:      	b	0x2850 <generic_retuprobe_filter_arg+0x2850>
    2644:      	cmp	w8, #0x2
    2648:      	b.eq	0x2994 <generic_retuprobe_filter_arg+0x2994>
    264c:      	cmp	w8, #0x3
    2650:      	b.ne	0x29e4 <generic_retuprobe_filter_arg+0x29e4>
    2654:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2658:      	mov	w8, #0x1                // =1
    265c:      	add	x9, sp, #0x60
    2660:      	ldr	x0, [x0]
    2664:      	b	0x29b8 <generic_retuprobe_filter_arg+0x29b8>
    2668:      	cmp	w8, #0x6
    266c:      	b.eq	0x29a8 <generic_retuprobe_filter_arg+0x29a8>
    2670:      	cmp	w8, #0x7
    2674:      	b.ne	0x29e4 <generic_retuprobe_filter_arg+0x29e4>
    2678:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    267c:      	mov	w8, #0x1                // =1
    2680:      	add	x9, sp, #0x60
    2684:      	ldr	x0, [x0]
    2688:      	b	0x29b8 <generic_retuprobe_filter_arg+0x29b8>
    268c:      	cmp	x11, x8
    2690:      	b.hi	0xc4 <generic_retuprobe_filter_arg+0xc4>
    2694:      	cmp	x8, x10
    2698:      	b.ls	0x140 <generic_retuprobe_filter_arg+0x140>
    269c:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    26a0:      	cmp	w8, #0x1
    26a4:      	b.eq	0x2a44 <generic_retuprobe_filter_arg+0x2a44>
    26a8:      	cmp	w8, #0x2
    26ac:      	b.ne	0x2a50 <generic_retuprobe_filter_arg+0x2a50>
    26b0:      	ldrb	w11, [x22]
    26b4:      	cmp	w10, w11
    26b8:      	b.hi	0x140 <generic_retuprobe_filter_arg+0x140>
    26bc:      	b	0x2a50 <generic_retuprobe_filter_arg+0x2a50>
    26c0:      	cmp	w8, #0x1
    26c4:      	b.eq	0x2a88 <generic_retuprobe_filter_arg+0x2a88>
    26c8:      	cmp	w8, #0x2
    26cc:      	b.ne	0x2a94 <generic_retuprobe_filter_arg+0x2a94>
    26d0:      	ldrh	w11, [x22]
    26d4:      	cmp	w10, w11
    26d8:      	b.hi	0x140 <generic_retuprobe_filter_arg+0x140>
    26dc:      	b	0x2a94 <generic_retuprobe_filter_arg+0x2a94>
    26e0:      	mov	w23, #0x1               // =1
    26e4:      	ldr	x21, [sp, #0x28]
    26e8:      	ldr	x0, [sp, #0x38]
    26ec:      	ldr	x12, [sp, #0x48]
    26f0:      	b	0x2c64 <generic_retuprobe_filter_arg+0x2c64>
    26f4:      	strh	w22, [x0], #0x2
    26f8:      	mov	w8, #0x4                // =4
    26fc:      	mov	w1, w22
    2700:      	mov	x2, x24
    2704:      	blr	x8
    2708:      	ldr	w8, [sp, #0x1c]
    270c:      	and	w8, w8, #0xffff
    2710:      	cmp	w8, w22
    2714:      	b.ls	0x2734 <generic_retuprobe_filter_arg+0x2734>
    2718:      	add	x9, x19, x22
    271c:      	sub	w8, w8, w22
    2720:      	ldr	x2, [sp, #0x10]
    2724:      	add	x0, x9, #0x2
    2728:      	and	w1, w8, #0xfff
    272c:      	mov	w8, #0x4                // =4
    2730:      	blr	x8
    2734:      	ldr	w8, [sp, #0x20]
    2738:      	cmp	w23, #0x3
    273c:      	str	w8, [sp, #0x60]
    2740:      	b.gt	0x276c <generic_retuprobe_filter_arg+0x276c>
    2744:      	cmp	w23, #0x1
    2748:      	b.gt	0x29fc <generic_retuprobe_filter_arg+0x29fc>
    274c:      	cbz	w23, 0x2be4 <generic_retuprobe_filter_arg+0x2be4>
    2750:      	cmp	w23, #0x1
    2754:      	b.ne	0x2c54 <generic_retuprobe_filter_arg+0x2c54>
    2758:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    275c:      	mov	w8, #0x1                // =1
    2760:      	add	x9, sp, #0x60
    2764:      	ldr	x0, [x0]
    2768:      	b	0x2c30 <generic_retuprobe_filter_arg+0x2c30>
    276c:      	cmp	w23, #0x5
    2770:      	b.gt	0x2a20 <generic_retuprobe_filter_arg+0x2a20>
    2774:      	cmp	w23, #0x4
    2778:      	b.eq	0x2bf8 <generic_retuprobe_filter_arg+0x2bf8>
    277c:      	cmp	w23, #0x5
    2780:      	b.ne	0x2c54 <generic_retuprobe_filter_arg+0x2c54>
    2784:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2788:      	mov	w8, #0x1                // =1
    278c:      	add	x9, sp, #0x60
    2790:      	ldr	x0, [x0]
    2794:      	b	0x2c30 <generic_retuprobe_filter_arg+0x2c30>
    2798:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    279c:      	mov	w8, #0x1                // =1
    27a0:      	add	x9, sp, #0x60
    27a4:      	ldr	x0, [x0]
    27a8:      	b	0x27e4 <generic_retuprobe_filter_arg+0x27e4>
    27ac:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    27b0:      	mov	w8, #0x1                // =1
    27b4:      	add	x9, sp, #0x60
    27b8:      	ldr	x0, [x0]
    27bc:      	b	0x27e4 <generic_retuprobe_filter_arg+0x27e4>
    27c0:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    27c4:      	mov	w8, #0x1                // =1
    27c8:      	add	x9, sp, #0x60
    27cc:      	ldr	x0, [x0]
    27d0:      	b	0x27e4 <generic_retuprobe_filter_arg+0x27e4>
    27d4:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    27d8:      	mov	w8, #0x1                // =1
    27dc:      	add	x9, sp, #0x60
    27e0:      	ldr	x0, [x0]
    27e4:      	add	x1, sp, #0x60
    27e8:      	blr	x8
    27ec:      	cbz	x0, 0x2808 <generic_retuprobe_filter_arg+0x2808>
    27f0:      	mov	w8, #0x1                // =1
    27f4:      	mov	x1, x22
    27f8:      	blr	x8
    27fc:      	cmp	x0, #0x0
    2800:      	cset	w23, ne
    2804:      	b	0x280c <generic_retuprobe_filter_arg+0x280c>
    2808:      	mov	x23, xzr
    280c:      	ldr	x0, [sp, #0x38]
    2810:      	ldp	x12, x16, [sp, #0x48]
    2814:      	mov	w17, #0x1               // =1
    2818:      	ldr	w8, [x29, #0x4]
    281c:      	cmp	w8, #0x25
    2820:      	b.hi	0x2c94 <generic_retuprobe_filter_arg+0x2c94>
    2824:      	mov	x9, #0x50               // =80
    2828:      	lsl	x8, x17, x8
    282c:      	movk	x9, #0xc00, lsl #16
    2830:      	movk	x9, #0x20, lsl #32
    2834:      	tst	x8, x9
    2838:      	b.eq	0x2c94 <generic_retuprobe_filter_arg+0x2c94>
    283c:      	eor	x23, x23, #0x1
    2840:      	cbnz	x23, 0x140 <generic_retuprobe_filter_arg+0x140>
    2844:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    2848:      	cmp	w12, w10
    284c:      	ccmp	w10, w11, #0x2, ls
    2850:      	cset	w9, ls
    2854:      	orr	w8, w8, w9
    2858:      	ldr	x12, [sp, #0x48]
    285c:      	tbz	w8, #0x0, 0x140 <generic_retuprobe_filter_arg+0x140>
    2860:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    2864:      	ldr	x12, [x22]
    2868:      	cmp	x12, x11
    286c:      	ldr	x12, [sp, #0x48]
    2870:      	b.hi	0x140 <generic_retuprobe_filter_arg+0x140>
    2874:      	b	0x2888 <generic_retuprobe_filter_arg+0x2888>
    2878:      	ldr	x12, [x22]
    287c:      	cmp	x12, x11
    2880:      	ldr	x12, [sp, #0x48]
    2884:      	b.lo	0x140 <generic_retuprobe_filter_arg+0x140>
    2888:      	cmp	w10, #0x21
    288c:      	b.lo	0x124 <generic_retuprobe_filter_arg+0x124>
    2890:      	ldr	x10, [x29, #0x28]
    2894:      	cmp	w8, #0x2
    2898:      	b.le	0x28c8 <generic_retuprobe_filter_arg+0x28c8>
    289c:      	sub	w9, w8, #0x3
    28a0:      	cmp	w9, #0x2
    28a4:      	b.lo	0x28f8 <generic_retuprobe_filter_arg+0x28f8>
    28a8:      	cmp	w8, #0x6
    28ac:      	b.eq	0x140 <generic_retuprobe_filter_arg+0x140>
    28b0:      	cmp	w8, #0xc
    28b4:      	b.ne	0xc4 <generic_retuprobe_filter_arg+0xc4>
    28b8:      	ldr	x9, [x22]
    28bc:      	tst	x9, x10
    28c0:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
    28c4:      	b	0x124 <generic_retuprobe_filter_arg+0x124>
    28c8:      	cmp	w8, #0x1
    28cc:      	b.eq	0x294c <generic_retuprobe_filter_arg+0x294c>
    28d0:      	cmp	w8, #0x2
    28d4:      	b.ne	0xc4 <generic_retuprobe_filter_arg+0xc4>
    28d8:      	cmp	w9, #0xc
    28dc:      	b.eq	0x28e8 <generic_retuprobe_filter_arg+0x28e8>
    28e0:      	cmp	w9, #0xa
    28e4:      	b.ne	0x2cc4 <generic_retuprobe_filter_arg+0x2cc4>
    28e8:      	ldr	x9, [x22]
    28ec:      	cmp	x9, x10
    28f0:      	b.ge	0x124 <generic_retuprobe_filter_arg+0x124>
    28f4:      	b	0x140 <generic_retuprobe_filter_arg+0x140>
    28f8:      	ldr	x9, [x22]
    28fc:      	cmp	x9, x10
    2900:      	b.eq	0x2bdc <generic_retuprobe_filter_arg+0x2bdc>
    2904:      	b	0x124 <generic_retuprobe_filter_arg+0x124>
    2908:      	cmp	w8, #0xc
    290c:      	b.ne	0x2a50 <generic_retuprobe_filter_arg+0x2a50>
    2910:      	ldrb	w11, [x22]
    2914:      	tst	w10, w11
    2918:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
    291c:      	b	0x2a50 <generic_retuprobe_filter_arg+0x2a50>
    2920:      	cmp	w8, #0xc
    2924:      	b.ne	0x2a94 <generic_retuprobe_filter_arg+0x2a94>
    2928:      	ldrh	w11, [x22]
    292c:      	tst	w10, w11
    2930:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
    2934:      	b	0x2a94 <generic_retuprobe_filter_arg+0x2a94>
    2938:      	cmp	w11, w8
    293c:      	b.hi	0xc4 <generic_retuprobe_filter_arg+0xc4>
    2940:      	cmp	w8, w10
    2944:      	b.ls	0x140 <generic_retuprobe_filter_arg+0x140>
    2948:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    294c:      	cmp	w9, #0xc
    2950:      	b.eq	0x295c <generic_retuprobe_filter_arg+0x295c>
    2954:      	cmp	w9, #0xa
    2958:      	b.ne	0x2cd4 <generic_retuprobe_filter_arg+0x2cd4>
    295c:      	ldr	x9, [x22]
    2960:      	cmp	x9, x10
    2964:      	b.le	0x124 <generic_retuprobe_filter_arg+0x124>
    2968:      	b	0x140 <generic_retuprobe_filter_arg+0x140>
    296c:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2970:      	mov	w8, #0x1                // =1
    2974:      	add	x9, sp, #0x60
    2978:      	ldr	x0, [x0]
    297c:      	b	0x29b8 <generic_retuprobe_filter_arg+0x29b8>
    2980:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2984:      	mov	w8, #0x1                // =1
    2988:      	add	x9, sp, #0x60
    298c:      	ldr	x0, [x0]
    2990:      	b	0x29b8 <generic_retuprobe_filter_arg+0x29b8>
    2994:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2998:      	mov	w8, #0x1                // =1
    299c:      	add	x9, sp, #0x60
    29a0:      	ldr	x0, [x0]
    29a4:      	b	0x29b8 <generic_retuprobe_filter_arg+0x29b8>
    29a8:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    29ac:      	mov	w8, #0x1                // =1
    29b0:      	add	x9, sp, #0x60
    29b4:      	ldr	x0, [x0]
    29b8:      	add	x1, sp, #0x60
    29bc:      	blr	x8
    29c0:      	cbz	x0, 0x29dc <generic_retuprobe_filter_arg+0x29dc>
    29c4:      	mov	w8, #0x1                // =1
    29c8:      	mov	x1, x22
    29cc:      	blr	x8
    29d0:      	cmp	x0, #0x0
    29d4:      	cset	w23, ne
    29d8:      	b	0x1410 <generic_retuprobe_filter_arg+0x1410>
    29dc:      	mov	x23, xzr
    29e0:      	b	0x1410 <generic_retuprobe_filter_arg+0x1410>
    29e4:      	ldr	x0, [sp, #0x38]
    29e8:      	mov	x23, xzr
    29ec:      	ldr	w8, [x29, #0x4]
    29f0:      	cmp	w8, #0x25
    29f4:      	b.ls	0x214c <generic_retuprobe_filter_arg+0x214c>
    29f8:      	b	0x2c94 <generic_retuprobe_filter_arg+0x2c94>
    29fc:      	cmp	w23, #0x2
    2a00:      	b.eq	0x2c0c <generic_retuprobe_filter_arg+0x2c0c>
    2a04:      	cmp	w23, #0x3
    2a08:      	b.ne	0x2c54 <generic_retuprobe_filter_arg+0x2c54>
    2a0c:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2a10:      	mov	w8, #0x1                // =1
    2a14:      	add	x9, sp, #0x60
    2a18:      	ldr	x0, [x0]
    2a1c:      	b	0x2c30 <generic_retuprobe_filter_arg+0x2c30>
    2a20:      	cmp	w23, #0x6
    2a24:      	b.eq	0x2c20 <generic_retuprobe_filter_arg+0x2c20>
    2a28:      	cmp	w23, #0x7
    2a2c:      	b.ne	0x2c54 <generic_retuprobe_filter_arg+0x2c54>
    2a30:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2a34:      	mov	w8, #0x1                // =1
    2a38:      	add	x9, sp, #0x60
    2a3c:      	ldr	x0, [x0]
    2a40:      	b	0x2c30 <generic_retuprobe_filter_arg+0x2c30>
    2a44:      	ldrb	w11, [x22]
    2a48:      	cmp	w10, w11
    2a4c:      	b.lo	0x140 <generic_retuprobe_filter_arg+0x140>
    2a50:      	cmp	w9, #0x15
    2a54:      	b.lo	0x124 <generic_retuprobe_filter_arg+0x124>
    2a58:      	ldr	w9, [x29, #0x1c]
    2a5c:      	cmp	w8, #0x2
    2a60:      	b.le	0x2b98 <generic_retuprobe_filter_arg+0x2b98>
    2a64:      	sub	w10, w8, #0x3
    2a68:      	cmp	w10, #0x2
    2a6c:      	b.lo	0x2bc8 <generic_retuprobe_filter_arg+0x2bc8>
    2a70:      	cmp	w8, #0x6
    2a74:      	b.eq	0x140 <generic_retuprobe_filter_arg+0x140>
    2a78:      	cmp	w8, #0xc
    2a7c:      	b.ne	0xc4 <generic_retuprobe_filter_arg+0xc4>
    2a80:      	ldrb	w10, [x22]
    2a84:      	b	0x2b24 <generic_retuprobe_filter_arg+0x2b24>
    2a88:      	ldrh	w11, [x22]
    2a8c:      	cmp	w10, w11
    2a90:      	b.lo	0x140 <generic_retuprobe_filter_arg+0x140>
    2a94:      	cmp	w9, #0x15
    2a98:      	b.lo	0x124 <generic_retuprobe_filter_arg+0x124>
    2a9c:      	ldr	w9, [x29, #0x1c]
    2aa0:      	cmp	w8, #0x2
    2aa4:      	b.le	0x2bb0 <generic_retuprobe_filter_arg+0x2bb0>
    2aa8:      	sub	w10, w8, #0x3
    2aac:      	cmp	w10, #0x2
    2ab0:      	b.lo	0x2bd0 <generic_retuprobe_filter_arg+0x2bd0>
    2ab4:      	cmp	w8, #0x6
    2ab8:      	b.eq	0x140 <generic_retuprobe_filter_arg+0x140>
    2abc:      	cmp	w8, #0xc
    2ac0:      	b.ne	0xc4 <generic_retuprobe_filter_arg+0xc4>
    2ac4:      	ldrh	w10, [x22]
    2ac8:      	b	0x2b24 <generic_retuprobe_filter_arg+0x2b24>
    2acc:      	ldr	w12, [x22]
    2ad0:      	cmp	w12, w11
    2ad4:      	ldr	x12, [sp, #0x48]
    2ad8:      	b.hi	0x140 <generic_retuprobe_filter_arg+0x140>
    2adc:      	b	0x2af0 <generic_retuprobe_filter_arg+0x2af0>
    2ae0:      	ldr	w12, [x22]
    2ae4:      	cmp	w12, w11
    2ae8:      	ldr	x12, [sp, #0x48]
    2aec:      	b.lo	0x140 <generic_retuprobe_filter_arg+0x140>
    2af0:      	cmp	w10, #0x15
    2af4:      	b.lo	0x124 <generic_retuprobe_filter_arg+0x124>
    2af8:      	ldr	w10, [x29, #0x1c]
    2afc:      	cmp	w8, #0x2
    2b00:      	b.le	0x2b30 <generic_retuprobe_filter_arg+0x2b30>
    2b04:      	sub	w9, w8, #0x3
    2b08:      	cmp	w9, #0x2
    2b0c:      	b.lo	0x2b68 <generic_retuprobe_filter_arg+0x2b68>
    2b10:      	cmp	w8, #0x6
    2b14:      	b.eq	0x140 <generic_retuprobe_filter_arg+0x140>
    2b18:      	cmp	w8, #0xc
    2b1c:      	b.ne	0xc4 <generic_retuprobe_filter_arg+0xc4>
    2b20:      	ldr	w9, [x22]
    2b24:      	tst	w9, w10
    2b28:      	b.ne	0x140 <generic_retuprobe_filter_arg+0x140>
    2b2c:      	b	0x124 <generic_retuprobe_filter_arg+0x124>
    2b30:      	cmp	w8, #0x1
    2b34:      	b.eq	0x2b70 <generic_retuprobe_filter_arg+0x2b70>
    2b38:      	cmp	w8, #0x2
    2b3c:      	b.ne	0xc4 <generic_retuprobe_filter_arg+0xc4>
    2b40:      	cmp	w9, #0xc
    2b44:      	b.hi	0x2cf4 <generic_retuprobe_filter_arg+0x2cf4>
    2b48:      	lsl	w9, w17, w9
    2b4c:      	mov	w11, #0x1402            // =5122
    2b50:      	tst	w9, w11
    2b54:      	b.eq	0x2cf4 <generic_retuprobe_filter_arg+0x2cf4>
    2b58:      	ldr	w9, [x22]
    2b5c:      	cmp	w9, w10
    2b60:      	b.ge	0x124 <generic_retuprobe_filter_arg+0x124>
    2b64:      	b	0x140 <generic_retuprobe_filter_arg+0x140>
    2b68:      	ldr	w9, [x22]
    2b6c:      	b	0x2bd4 <generic_retuprobe_filter_arg+0x2bd4>
    2b70:      	cmp	w9, #0xc
    2b74:      	b.hi	0x2d04 <generic_retuprobe_filter_arg+0x2d04>
    2b78:      	lsl	w9, w17, w9
    2b7c:      	mov	w11, #0x1402            // =5122
    2b80:      	tst	w9, w11
    2b84:      	b.eq	0x2d04 <generic_retuprobe_filter_arg+0x2d04>
    2b88:      	ldr	w9, [x22]
    2b8c:      	cmp	w9, w10
    2b90:      	b.le	0x124 <generic_retuprobe_filter_arg+0x124>
    2b94:      	b	0x140 <generic_retuprobe_filter_arg+0x140>
    2b98:      	cmp	w8, #0x1
    2b9c:      	b.eq	0x2ce4 <generic_retuprobe_filter_arg+0x2ce4>
    2ba0:      	cmp	w8, #0x2
    2ba4:      	b.ne	0xc4 <generic_retuprobe_filter_arg+0xc4>
    2ba8:      	ldrb	w10, [x22]
    2bac:      	b	0x2d08 <generic_retuprobe_filter_arg+0x2d08>
    2bb0:      	cmp	w8, #0x1
    2bb4:      	b.eq	0x2cec <generic_retuprobe_filter_arg+0x2cec>
    2bb8:      	cmp	w8, #0x2
    2bbc:      	b.ne	0xc4 <generic_retuprobe_filter_arg+0xc4>
    2bc0:      	ldrh	w10, [x22]
    2bc4:      	b	0x2d08 <generic_retuprobe_filter_arg+0x2d08>
    2bc8:      	ldrb	w10, [x22]
    2bcc:      	b	0x2bd4 <generic_retuprobe_filter_arg+0x2bd4>
    2bd0:      	ldrh	w10, [x22]
    2bd4:      	cmp	w9, w10
    2bd8:      	b.ne	0x124 <generic_retuprobe_filter_arg+0x124>
    2bdc:      	cmp	w8, #0x3
    2be0:      	b	0x2c90 <generic_retuprobe_filter_arg+0x2c90>
    2be4:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2be8:      	mov	w8, #0x1                // =1
    2bec:      	add	x9, sp, #0x60
    2bf0:      	ldr	x0, [x0]
    2bf4:      	b	0x2c30 <generic_retuprobe_filter_arg+0x2c30>
    2bf8:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2bfc:      	mov	w8, #0x1                // =1
    2c00:      	add	x9, sp, #0x60
    2c04:      	ldr	x0, [x0]
    2c08:      	b	0x2c30 <generic_retuprobe_filter_arg+0x2c30>
    2c0c:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2c10:      	mov	w8, #0x1                // =1
    2c14:      	add	x9, sp, #0x60
    2c18:      	ldr	x0, [x0]
    2c1c:      	b	0x2c30 <generic_retuprobe_filter_arg+0x2c30>
    2c20:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2c24:      	mov	w8, #0x1                // =1
    2c28:      	add	x9, sp, #0x60
    2c2c:      	ldr	x0, [x0]
    2c30:      	add	x1, sp, #0x60
    2c34:      	blr	x8
    2c38:      	cbz	x0, 0x2c54 <generic_retuprobe_filter_arg+0x2c54>
    2c3c:      	mov	w8, #0x1                // =1
    2c40:      	mov	x1, x19
    2c44:      	blr	x8
    2c48:      	cmp	x0, #0x0
    2c4c:      	cset	w23, ne
    2c50:      	b	0x2c58 <generic_retuprobe_filter_arg+0x2c58>
    2c54:      	mov	x23, xzr
    2c58:      	ldr	x0, [sp, #0x38]
    2c5c:      	ldp	x12, x16, [sp, #0x48]
    2c60:      	mov	w17, #0x1               // =1
    2c64:      	ldr	w8, [x29, #0x4]
    2c68:      	cmp	w8, #0x25
    2c6c:      	b.hi	0x2c9c <generic_retuprobe_filter_arg+0x2c9c>
    2c70:      	mov	x9, #0x50               // =80
    2c74:      	ldr	x19, [sp, #0x30]
    2c78:      	lsl	x8, x17, x8
    2c7c:      	movk	x9, #0xc00, lsl #16
    2c80:      	movk	x9, #0x20, lsl #32
    2c84:      	tst	x8, x9
    2c88:      	b.eq	0x2c94 <generic_retuprobe_filter_arg+0x2c94>
    2c8c:      	cmp	x23, #0x0
    2c90:      	cset	w23, eq
    2c94:      	cbnz	x23, 0x140 <generic_retuprobe_filter_arg+0x140>
    2c98:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    2c9c:      	ldr	x19, [sp, #0x30]
    2ca0:      	cbnz	x23, 0x140 <generic_retuprobe_filter_arg+0x140>
    2ca4:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    2ca8:      	ldr	x19, [sp, #0x30]
    2cac:      	ldp	x12, x16, [sp, #0x48]
    2cb0:      	mov	w17, #0x1               // =1
    2cb4:      	ldr	x0, [sp, #0x38]
    2cb8:      	mov	w23, w8
    2cbc:      	cbnz	x23, 0x140 <generic_retuprobe_filter_arg+0x140>
    2cc0:      	b	0xc4 <generic_retuprobe_filter_arg+0xc4>
    2cc4:      	ldr	x9, [x22]
    2cc8:      	cmp	x9, x10
    2ccc:      	b.hs	0x124 <generic_retuprobe_filter_arg+0x124>
    2cd0:      	b	0x140 <generic_retuprobe_filter_arg+0x140>
    2cd4:      	ldr	x9, [x22]
    2cd8:      	cmp	x9, x10
    2cdc:      	b.ls	0x124 <generic_retuprobe_filter_arg+0x124>
    2ce0:      	b	0x140 <generic_retuprobe_filter_arg+0x140>
    2ce4:      	ldrb	w10, [x22]
    2ce8:      	b	0x2cf8 <generic_retuprobe_filter_arg+0x2cf8>
    2cec:      	ldrh	w10, [x22]
    2cf0:      	b	0x2cf8 <generic_retuprobe_filter_arg+0x2cf8>
    2cf4:      	ldr	w9, [x22]
    2cf8:      	cmp	w9, w10
    2cfc:      	b.hs	0x124 <generic_retuprobe_filter_arg+0x124>
    2d00:      	b	0x140 <generic_retuprobe_filter_arg+0x140>
    2d04:      	ldr	w9, [x22]
    2d08:      	cmp	w9, w10
    2d0c:      	b.ls	0x124 <generic_retuprobe_filter_arg+0x124>
    2d10:      	b	0x140 <generic_retuprobe_filter_arg+0x140>
    2d14:      	ldr	x8, [sp, #0x40]
    2d18:      	adrp	x1, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2d1c:      	mov	w9, #0xc                // =12
    2d20:      	mov	x0, x21
    2d24:      	stur	w8, [x19, #0x43]
    2d28:      	mov	w8, #0x4                // =4
    2d2c:      	mov	w2, #0x4                // =4
    2d30:      	ldr	x1, [x1]
    2d34:      	blr	x9
    2d38:      	adrp	x1, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2d3c:      	mov	w8, #0x5                // =5
    2d40:      	mov	w9, #0xc                // =12
    2d44:      	ldr	x1, [x1]
    2d48:      	mov	x0, x21
    2d4c:      	mov	w2, #0x5                // =5
    2d50:      	blr	x9
    2d54:      	ldp	x20, x19, [sp, #0xe0]
    2d58:      	mov	w0, wzr
    2d5c:      	ldr	x29, [sp, #0xa0]
    2d60:      	ldp	x22, x21, [sp, #0xd0]
    2d64:      	ldp	x24, x23, [sp, #0xc0]
    2d68:      	ldp	x30, x25, [sp, #0xb0]
    2d6c:      	add	sp, sp, #0xf0
    2d70:      	ret
    2d74:      	ldrb	w8, [x19]
    2d78:      	cbz	w8, 0x2d84 <generic_retuprobe_filter_arg+0x2d84>
    2d7c:      	mov	w8, wzr
    2d80:      	b	0x2dd0 <generic_retuprobe_filter_arg+0x2dd0>
    2d84:      	ldrb	w8, [x19, #0x1]
    2d88:      	cbz	w8, 0x2d94 <generic_retuprobe_filter_arg+0x2d94>
    2d8c:      	mov	w8, #0x1                // =1
    2d90:      	b	0x2dd0 <generic_retuprobe_filter_arg+0x2dd0>
    2d94:      	ldrb	w8, [x19, #0x2]
    2d98:      	cbz	w8, 0x2da4 <generic_retuprobe_filter_arg+0x2da4>
    2d9c:      	mov	w8, #0x2                // =2
    2da0:      	b	0x2dd0 <generic_retuprobe_filter_arg+0x2dd0>
    2da4:      	ldrb	w8, [x19, #0x3]
    2da8:      	cbz	w8, 0x2db4 <generic_retuprobe_filter_arg+0x2db4>
    2dac:      	mov	w8, #0x3                // =3
    2db0:      	b	0x2dd0 <generic_retuprobe_filter_arg+0x2dd0>
    2db4:      	ldrb	w8, [x19, #0x4]
    2db8:      	cbz	w8, 0x2dc4 <generic_retuprobe_filter_arg+0x2dc4>
    2dbc:      	mov	w8, #0x4                // =4
    2dc0:      	b	0x2dd0 <generic_retuprobe_filter_arg+0x2dd0>
    2dc4:      	ldrb	w8, [x19, #0x5]
    2dc8:      	cbz	w8, 0x2df0 <generic_retuprobe_filter_arg+0x2df0>
    2dcc:      	mov	w8, #0x5                // =5
    2dd0:      	stur	w8, [x19, #0x3f]
    2dd4:      	adrp	x1, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2dd8:      	mov	w8, #0x3                // =3
    2ddc:      	mov	w9, #0xc                // =12
    2de0:      	ldr	x1, [x1]
    2de4:      	mov	x0, x21
    2de8:      	mov	w2, #0x3                // =3
    2dec:      	blr	x9
    2df0:      	ldr	x19, [x20, #0x60]
    2df4:      	mov	w8, #0xe                // =14
    2df8:      	blr	x8
    2dfc:      	stp	x19, x0, [sp, #0x60]
    2e00:      	adrp	x19, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2e04:      	mov	w8, #0x1                // =1
    2e08:      	add	x9, sp, #0x60
    2e0c:      	add	x1, sp, #0x60
    2e10:      	ldr	x19, [x19]
    2e14:      	mov	x0, x19
    2e18:      	blr	x8
    2e1c:      	cbz	x0, 0x2d54 <generic_retuprobe_filter_arg+0x2d54>
    2e20:      	mov	w8, #0x3                // =3
    2e24:      	add	x9, sp, #0x60
    2e28:      	add	x1, sp, #0x60
    2e2c:      	mov	x0, x19
    2e30:      	blr	x8
    2e34:      	b	0x2d54 <generic_retuprobe_filter_arg+0x2d54>
    2e38:      	nop
    2e3c:      	nop

0000000000002e40 <generic_retuprobe_actions>:
    2e40:      	sub	sp, sp, #0xe0
    2e44:      	str	x29, [sp, #0x90]
    2e48:      	stp	x30, x25, [sp, #0xa0]
    2e4c:      	stp	x24, x23, [sp, #0xb0]
    2e50:      	stp	x22, x21, [sp, #0xc0]
    2e54:      	stp	x20, x19, [sp, #0xd0]
    2e58:      	str	x0, [sp, #0x50]
    2e5c:      	str	wzr, [sp, #0x5c]
    2e60:      	adrp	x29, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2e64:      	mov	w8, #0x1                // =1
    2e68:      	add	x9, sp, #0x5c
    2e6c:      	add	x1, sp, #0x5c
    2e70:      	ldr	x29, [x29]
    2e74:      	mov	x0, x29
    2e78:      	blr	x8
    2e7c:      	cbz	x0, 0x38f8 <generic_retuprobe_actions+0xab8>
    2e80:      	mov	w8, #0x5f04             // =24324
    2e84:      	ldr	w19, [x0, x8]
    2e88:      	cmp	w19, #0x2
    2e8c:      	b.lt	0x38f8 <generic_retuprobe_actions+0xab8>
    2e90:      	mov	w8, #0x5ef8             // =24312
    2e94:      	add	x1, x0, x8
    2e98:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2e9c:      	mov	w8, #0x1                // =1
    2ea0:      	ldr	x0, [x0]
    2ea4:      	blr	x8
    2ea8:      	cbz	x0, 0x38f8 <generic_retuprobe_actions+0xab8>
    2eac:      	and	x8, x19, #0x7ff
    2eb0:      	add	x9, sp, #0x60
    2eb4:      	add	x1, sp, #0x60
    2eb8:      	ldr	w8, [x0, x8]
    2ebc:      	str	wzr, [sp, #0x60]
    2ec0:      	add	w8, w8, w19
    2ec4:      	and	w8, w8, #0x7ff
    2ec8:      	add	x21, x0, x8
    2ecc:      	adrp	x0, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2ed0:      	mov	w8, #0x1                // =1
    2ed4:      	ldr	x0, [x0]
    2ed8:      	blr	x8
    2edc:      	cbz	x0, 0x2f24 <generic_retuprobe_actions+0xe4>
    2ee0:      	ldrb	w8, [x0]
    2ee4:      	mov	w11, #0x6               // =6
    2ee8:      	mov	w14, #0x7               // =7
    2eec:      	mov	w10, #0x8               // =8
    2ef0:      	mov	w12, #0x5               // =5
    2ef4:      	mov	w13, #0x9               // =9
    2ef8:      	ands	w8, w8, #0xff
    2efc:      	cset	w9, eq
    2f00:      	cmp	w8, #0x0
    2f04:      	str	w9, [sp, #0x48]
    2f08:      	mov	w9, #0x4                // =4
    2f0c:      	csel	x8, x11, x14, eq
    2f10:      	csel	x11, x10, x13, eq
    2f14:      	str	x8, [sp, #0x30]
    2f18:      	csel	x8, x9, x12, eq
    2f1c:      	stp	x11, x8, [sp, #0x38]
    2f20:      	b	0x2f44 <generic_retuprobe_actions+0x104>
    2f24:      	mov	w8, #0x1                // =1
    2f28:      	str	w8, [sp, #0x48]
    2f2c:      	mov	w8, #0x4                // =4
    2f30:      	str	x8, [sp, #0x40]
    2f34:      	mov	w8, #0x8                // =8
    2f38:      	str	x8, [sp, #0x38]
    2f3c:      	mov	w8, #0x6                // =6
    2f40:      	str	x8, [sp, #0x30]
    2f44:      	adrp	x25, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2f48:      	mov	w23, wzr
    2f4c:      	mov	w24, wzr
    2f50:      	ldr	x25, [x25]
    2f54:      	add	x20, sp, #0x64
    2f58:      	mov	w8, #0x1                // =1
    2f5c:      	str	w8, [sp, #0x4c]
    2f60:      	b	0x2f74 <generic_retuprobe_actions+0x134>
    2f64:      	mov	w24, wzr
    2f68:      	add	w23, w23, #0x1
    2f6c:      	cmp	w23, #0x3
    2f70:      	b.eq	0x38d4 <generic_retuprobe_actions+0xa94>
    2f74:      	ldr	w9, [x21]
    2f78:      	lsl	w8, w24, #2
    2f7c:      	add	w8, w8, #0x4
    2f80:      	cmp	w8, w9
    2f84:      	b.hs	0x38d4 <generic_retuprobe_actions+0xa94>
    2f88:      	add	x8, x21, w24, uxtw #2
    2f8c:      	add	x1, sp, #0x64
    2f90:      	mov	x0, x29
    2f94:      	ldrsw	x19, [x8, #0x4]
    2f98:      	str	wzr, [sp, #0x64]
    2f9c:      	mov	w8, #0x1                // =1
    2fa0:      	blr	x8
    2fa4:      	cbz	x0, 0x2f64 <generic_retuprobe_actions+0x124>
    2fa8:      	mov	x22, x0
    2fac:      	cmp	w19, #0x7
    2fb0:      	b.gt	0x2fe0 <generic_retuprobe_actions+0x1a0>
    2fb4:      	cmp	w19, #0x3
    2fb8:      	b.gt	0x3030 <generic_retuprobe_actions+0x1f0>
    2fbc:      	cmp	w19, #0x1
    2fc0:      	b.gt	0x30b0 <generic_retuprobe_actions+0x270>
    2fc4:      	cbz	w19, 0x3214 <generic_retuprobe_actions+0x3d4>
    2fc8:      	cmp	w19, #0x1
    2fcc:      	b.eq	0x30c0 <generic_retuprobe_actions+0x280>
    2fd0:      	adrp	x25, 0x2000 <generic_retuprobe_filter_arg+0x2000>
    2fd4:      	b	0x3318 <generic_retuprobe_actions+0x4d8>
    2fd8:      	nop
    2fdc:      	nop
    2fe0:      	cmp	w19, #0xb
    2fe4:      	b.gt	0x3088 <generic_retuprobe_actions+0x248>
    2fe8:      	sub	w8, w19, #0xa
    2fec:      	cmp	w8, #0x2
    2ff0:      	b.lo	0x3124 <generic_retuprobe_actions+0x2e4>
    2ff4:      	cmp	w19, #0x8
    2ff8:      	b.eq	0x316c <generic_retuprobe_actions+0x32c>
    2ffc:      	cmp	w19, #0x9
    3000:      	b.ne	0x331c <generic_retuprobe_actions+0x4dc>
    3004:      	add	w24, w24, #0x1
    3008:      	add	x8, x21, w24, uxtw #2
    300c:      	ldr	w0, [x8, #0x4]
    3010:      	ldr	w8, [sp, #0x48]
    3014:      	add	x25, sp, #0x68
    3018:      	cbz	w8, 0x32bc <generic_retuprobe_actions+0x47c>
    301c:      	sxtw	x8, w0
    3020:      	mov	w9, #0x6d               // =109
    3024:      	blr	x9
    3028:      	mov	w20, #0x2               // =2
    302c:      	b	0x32d0 <generic_retuprobe_actions+0x490>
    3030:      	sub	w8, w19, #0x6
    3034:      	cmp	w8, #0x2
    3038:      	b.lo	0x3158 <generic_retuprobe_actions+0x318>
    303c:      	cmp	w19, #0x4
    3040:      	b.eq	0x3174 <generic_retuprobe_actions+0x334>
    3044:      	cmp	w19, #0x5
    3048:      	b.ne	0x331c <generic_retuprobe_actions+0x4dc>
    304c:      	add	w8, w24, #0x1
    3050:      	add	x9, x21, #0x4
    3054:      	add	w24, w24, #0x2
    3058:      	ldr	w8, [x9, w8, uxtw #2]
    305c:      	ldr	w20, [x9, w24, uxtw #2]
    3060:      	stp	xzr, xzr, [sp, #0x68]
    3064:      	and	x8, x8, #0x7
    3068:      	cmp	w8, #0x4
    306c:      	b.hi	0x3080 <generic_retuprobe_actions+0x240>
    3070:      	add	x9, x22, x8, lsl #2
    3074:      	mov	w10, #0x5ea0            // =24224
    3078:      	ldr	w9, [x9, x10]
    307c:      	cbz	w9, 0x34f8 <generic_retuprobe_actions+0x6b8>
    3080:      	add	x20, sp, #0x64
    3084:      	b	0x331c <generic_retuprobe_actions+0x4dc>
    3088:      	cmp	w19, #0xc
    308c:      	b.eq	0x32c4 <generic_retuprobe_actions+0x484>
    3090:      	cmp	w19, #0xd
    3094:      	b.eq	0x3184 <generic_retuprobe_actions+0x344>
    3098:      	cmp	w19, #0xe
    309c:      	b.ne	0x331c <generic_retuprobe_actions+0x4dc>
    30a0:      	ldr	x20, [sp, #0x38]
    30a4:      	add	x25, sp, #0x68
    30a8:      	add	w24, w24, #0x2
    30ac:      	b	0x32d0 <generic_retuprobe_actions+0x490>
    30b0:      	cmp	w19, #0x2
    30b4:      	b.eq	0x32ac <generic_retuprobe_actions+0x46c>
    30b8:      	cmp	w19, #0x3
    30bc:      	b.ne	0x2fd0 <generic_retuprobe_actions+0x190>
    30c0:      	add	w8, w24, #0x1
    30c4:      	add	x9, x21, #0x4
    30c8:      	add	w24, w24, #0x2
    30cc:      	ldr	w20, [x9, w24, uxtw #2]
    30d0:      	mov	x25, x21
    30d4:      	ldr	w21, [x9, w8, uxtw #2]
    30d8:      	str	wzr, [sp, #0x78]
    30dc:      	stp	xzr, xzr, [sp, #0x68]
    30e0:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    30e4:      	mov	w8, #0x1                // =1
    30e8:      	add	x9, sp, #0x78
    30ec:      	add	x1, sp, #0x78
    30f0:      	ldr	x0, [x0]
    30f4:      	blr	x8
    30f8:      	cbz	x0, 0x310c <generic_retuprobe_actions+0x2cc>
    30fc:      	and	x8, x21, #0x7
    3100:      	cmp	w8, #0x4
    3104:      	b.ls	0x3334 <generic_retuprobe_actions+0x4f4>
    3108:      	mov	w0, wzr
    310c:      	mov	x21, x25
    3110:      	adrp	x25, 0x3000 <generic_retuprobe_actions+0x1c0>
    3114:      	add	x20, sp, #0x64
    3118:      	ldr	x25, [x25]
    311c:      	cbnz	w0, 0x2f64 <generic_retuprobe_actions+0x124>
    3120:      	b	0x331c <generic_retuprobe_actions+0x4dc>
    3124:      	add	w24, w24, #0x1
    3128:      	add	x8, x21, w24, uxtw #2
    312c:      	ldr	w8, [x8, #0x4]
    3130:      	and	x8, x8, #0x7
    3134:      	cmp	w8, #0x4
    3138:      	b.hi	0x314c <generic_retuprobe_actions+0x30c>
    313c:      	add	x9, x22, x8, lsl #2
    3140:      	mov	w10, #0x5ea0            // =24224
    3144:      	ldr	w9, [x9, x10]
    3148:      	cbz	w9, 0x3350 <generic_retuprobe_actions+0x510>
    314c:      	mov	w0, wzr
    3150:      	cbnz	w0, 0x2f64 <generic_retuprobe_actions+0x124>
    3154:      	b	0x331c <generic_retuprobe_actions+0x4dc>
    3158:      	add	w24, w24, #0x1
    315c:      	add	x8, x21, w24, uxtw #2
    3160:      	ldr	w8, [x8, #0x4]
    3164:      	str	w8, [x22, #0x78]
    3168:      	b	0x331c <generic_retuprobe_actions+0x4dc>
    316c:      	str	wzr, [sp, #0x4c]
    3170:      	b	0x331c <generic_retuprobe_actions+0x4dc>
    3174:      	ldr	x20, [sp, #0x40]
    3178:      	add	x25, sp, #0x68
    317c:      	add	w24, w24, #0x1
    3180:      	b	0x32d0 <generic_retuprobe_actions+0x490>
    3184:      	mov	w8, #0xe                // =14
    3188:      	blr	x8
    318c:      	str	x0, [sp, #0x88]
    3190:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    3194:      	mov	w8, #0x1                // =1
    3198:      	add	x9, sp, #0x88
    319c:      	ldr	x0, [x0]
    31a0:      	add	x1, sp, #0x88
    31a4:      	blr	x8
    31a8:      	cbz	x0, 0x331c <generic_retuprobe_actions+0x4dc>
    31ac:      	ldur	x8, [x0, #0x4]
    31b0:      	mov	x20, x21
    31b4:      	add	x21, sp, #0x78
    31b8:      	add	x1, sp, #0x78
    31bc:      	str	x8, [sp, #0x78]
    31c0:      	mov	w8, #0x2                // =2
    31c4:      	mov	x0, x25
    31c8:      	str	w8, [sp, #0x80]
    31cc:      	mov	w8, #0x1                // =1
    31d0:      	blr	x8
    31d4:      	mov	w9, #0x1                // =1
    31d8:      	str	w9, [sp, #0x98]
    31dc:      	cbz	x0, 0x3488 <generic_retuprobe_actions+0x648>
    31e0:      	ldaxr	w8, [x0]
    31e4:      	add	w8, w8, #0x1
    31e8:      	stlxr	w9, w8, [x0]
    31ec:      	cbnz	w9, 0x31e0 <generic_retuprobe_actions+0x3a0>
    31f0:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    31f4:      	mov	w8, #0x3                // =3
    31f8:      	add	x9, sp, #0x88
    31fc:      	ldr	x0, [x0]
    3200:      	add	x1, sp, #0x88
    3204:      	blr	x8
    3208:      	mov	x21, x20
    320c:      	add	x20, sp, #0x64
    3210:      	b	0x331c <generic_retuprobe_actions+0x4dc>
    3214:      	add	w8, w24, #0x1
    3218:      	add	x9, x21, #0x4
    321c:      	ldr	w25, [x9, w8, uxtw #2]
    3220:      	add	w8, w24, #0x2
    3224:      	ldr	w20, [x9, w8, uxtw #2]
    3228:      	mov	w8, #0x7d               // =125
    322c:      	blr	x8
    3230:      	str	x0, [sp, #0x68]
    3234:      	str	wzr, [sp, #0x88]
    3238:      	str	x25, [sp, #0x18]
    323c:      	cbz	w25, 0x37dc <generic_retuprobe_actions+0x99c>
    3240:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    3244:      	mov	w8, #0x1                // =1
    3248:      	add	x9, sp, #0x88
    324c:      	ldr	x0, [x0]
    3250:      	add	x1, sp, #0x88
    3254:      	blr	x8
    3258:      	cbz	x0, 0x37dc <generic_retuprobe_actions+0x99c>
    325c:      	mov	x25, x0
    3260:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    3264:      	mov	w8, #0x1                // =1
    3268:      	ldr	x0, [x0]
    326c:      	add	x9, sp, #0x88
    3270:      	add	x1, sp, #0x88
    3274:      	blr	x8
    3278:      	ldr	x8, [x22, #0x60]
    327c:      	mov	x2, x0
    3280:      	cmp	w20, #0x2
    3284:      	str	x8, [x25]
    3288:      	ldr	x8, [x22, #0x70]
    328c:      	str	x8, [x25, #0x8]
    3290:      	b.eq	0x35fc <generic_retuprobe_actions+0x7bc>
    3294:      	cmp	w20, #0x1
    3298:      	b.eq	0x35f0 <generic_retuprobe_actions+0x7b0>
    329c:      	cbnz	w20, 0x37dc <generic_retuprobe_actions+0x99c>
    32a0:      	ldr	w8, [x22, #0x7c]
    32a4:      	str	x21, [sp, #0x8]
    32a8:      	b	0x3604 <generic_retuprobe_actions+0x7c4>
    32ac:      	mov	w0, #0x9                // =9
    32b0:      	ldr	w8, [sp, #0x48]
    32b4:      	add	x25, sp, #0x68
    32b8:      	cbnz	w8, 0x301c <generic_retuprobe_actions+0x1dc>
    32bc:      	mov	w20, #0x3               // =3
    32c0:      	b	0x32d0 <generic_retuprobe_actions+0x490>
    32c4:      	ldr	x20, [sp, #0x30]
    32c8:      	add	x25, sp, #0x68
    32cc:      	add	w24, w24, #0x3
    32d0:      	str	wzr, [sp, #0x68]
    32d4:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    32d8:      	mov	w8, #0x1                // =1
    32dc:      	add	x1, sp, #0x68
    32e0:      	ldr	x0, [x0]
    32e4:      	blr	x8
    32e8:      	cbz	x0, 0x3310 <generic_retuprobe_actions+0x4d0>
    32ec:      	add	x8, x0, x20, lsl #3
    32f0:      	nop
    32f4:      	nop
    32f8:      	nop
    32fc:      	nop
    3300:      	ldaxr	x9, [x8]
    3304:      	add	x9, x9, #0x1
    3308:      	stlxr	w10, x9, [x8]
    330c:      	cbnz	w10, 0x3300 <generic_retuprobe_actions+0x4c0>
    3310:      	adrp	x25, 0x3000 <generic_retuprobe_actions+0x1c0>
    3314:      	add	x20, sp, #0x64
    3318:      	ldr	x25, [x25]
    331c:      	add	w24, w24, #0x1
    3320:      	str	x19, [x22, #0x70]
    3324:      	add	w23, w23, #0x1
    3328:      	cmp	w23, #0x3
    332c:      	b.ne	0x2f74 <generic_retuprobe_actions+0x134>
    3330:      	b	0x38d4 <generic_retuprobe_actions+0xa94>
    3334:      	add	x9, x22, x8, lsl #2
    3338:      	mov	w10, #0x5ea0            // =24224
    333c:      	ldr	w9, [x9, x10]
    3340:      	cbz	w9, 0x33e8 <generic_retuprobe_actions+0x5a8>
    3344:      	mov	x21, x25
    3348:      	mov	w0, wzr
    334c:      	b	0x3110 <generic_retuprobe_actions+0x2d0>
    3350:      	add	x8, x22, x8, lsl #3
    3354:      	ldr	x8, [x8, #0x5e78]
    3358:      	and	x8, x8, #0x7ff
    335c:      	add	x8, x22, x8
    3360:      	ldr	x8, [x8, #0xb8]
    3364:      	str	x8, [sp, #0x78]
    3368:      	cbz	x8, 0x314c <generic_retuprobe_actions+0x30c>
    336c:      	cmp	w19, #0xa
    3370:      	b.ne	0x35d0 <generic_retuprobe_actions+0x790>
    3374:      	mov	w8, #0xe                // =14
    3378:      	add	x25, sp, #0x68
    337c:      	mov	x20, x21
    3380:      	blr	x8
    3384:      	lsr	x8, x0, #32
    3388:      	mov	x21, x0
    338c:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    3390:      	str	w8, [sp, #0x68]
    3394:      	mov	w8, #0x1                // =1
    3398:      	add	x1, sp, #0x68
    339c:      	ldr	x0, [x0]
    33a0:      	blr	x8
    33a4:      	cbz	x0, 0x33dc <generic_retuprobe_actions+0x59c>
    33a8:      	ldr	w8, [x0]
    33ac:      	mov	x3, xzr
    33b0:      	add	x9, sp, #0x78
    33b4:      	add	x1, sp, #0x78
    33b8:      	stp	w8, w21, [sp, #0x68]
    33bc:      	ldr	x8, [x0, #0x8]
    33c0:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    33c4:      	add	x2, sp, #0x68
    33c8:      	str	x8, [sp, #0x70]
    33cc:      	mov	w8, #0x2                // =2
    33d0:      	ldr	x0, [x0]
    33d4:      	blr	x8
    33d8:      	mov	w0, wzr
    33dc:      	adrp	x25, 0x3000 <generic_retuprobe_actions+0x1c0>
    33e0:      	mov	x21, x20
    33e4:      	b	0x3114 <generic_retuprobe_actions+0x2d4>
    33e8:      	add	x8, x22, x8, lsl #3
    33ec:      	mov	x21, x0
    33f0:      	ldr	x8, [x8, #0x5e78]
    33f4:      	str	wzr, [sp, #0x74]
    33f8:      	and	x8, x8, #0x7ff
    33fc:      	add	x8, x22, x8
    3400:      	ldr	w8, [x8, #0x90]
    3404:      	str	w8, [sp, #0x70]
    3408:      	mov	w8, #0xe                // =14
    340c:      	blr	x8
    3410:      	lsr	x8, x0, #32
    3414:      	cmp	w19, #0x1
    3418:      	str	x8, [sp, #0x68]
    341c:      	b.ne	0x35b4 <generic_retuprobe_actions+0x774>
    3420:      	and	x8, x20, #0x7
    3424:      	cmp	w8, #0x4
    3428:      	b.hi	0x3108 <generic_retuprobe_actions+0x2c8>
    342c:      	add	x9, x22, x8, lsl #2
    3430:      	mov	w10, #0x5ea0            // =24224
    3434:      	add	x20, sp, #0x68
    3438:      	ldr	w9, [x9, x10]
    343c:      	cbnz	w9, 0x3108 <generic_retuprobe_actions+0x2c8>
    3440:      	add	x8, x22, x8, lsl #3
    3444:      	mov	x0, x21
    3448:      	ldr	x8, [x8, #0x5e78]
    344c:      	and	x8, x8, #0x7ff
    3450:      	add	x2, x22, x8
    3454:      	ldr	w8, [x2, #0x90]!
    3458:      	and	x8, x8, #0xfff
    345c:      	add	x1, x8, #0x8
    3460:      	mov	w8, #0x4                // =4
    3464:      	blr	x8
    3468:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    346c:      	mov	x3, xzr
    3470:      	mov	w8, #0x2                // =2
    3474:      	ldr	x0, [x0]
    3478:      	add	x1, sp, #0x68
    347c:      	mov	x2, x21
    3480:      	blr	x8
    3484:      	b	0x3108 <generic_retuprobe_actions+0x2c8>
    3488:      	mov	w8, #0x2                // =2
    348c:      	add	x10, sp, #0x98
    3490:      	add	x1, sp, #0x78
    3494:      	add	x2, sp, #0x98
    3498:      	mov	x0, x25
    349c:      	mov	w3, #0x1                // =1
    34a0:      	blr	x8
    34a4:      	cbz	x0, 0x31f0 <generic_retuprobe_actions+0x3b0>
    34a8:      	mov	x21, x0
    34ac:      	adrp	x25, 0x3000 <generic_retuprobe_actions+0x1c0>
    34b0:      	add	x9, sp, #0x68
    34b4:      	add	x1, sp, #0x68
    34b8:      	neg	w8, w21
    34bc:      	strh	w8, [sp, #0x68]
    34c0:      	mov	w8, #0x3                // =3
    34c4:      	strh	w8, [sp, #0x6a]
    34c8:      	mov	x8, #0x3b               // =59
    34cc:      	movk	x8, #0x2, lsl #32
    34d0:      	stur	x8, [sp, #0x6c]
    34d4:      	mov	w8, #0x1                // =1
    34d8:      	ldr	x25, [x25]
    34dc:      	mov	x0, x25
    34e0:      	blr	x8
    34e4:      	cbz	x0, 0x3860 <generic_retuprobe_actions+0xa20>
    34e8:      	ldr	w8, [x0]
    34ec:      	add	w8, w8, #0x1
    34f0:      	str	w8, [x0]
    34f4:      	b	0x3888 <generic_retuprobe_actions+0xa48>
    34f8:      	add	x8, x22, x8, lsl #3
    34fc:      	ldr	x8, [x8, #0x5e78]
    3500:      	and	x8, x8, #0x7ff
    3504:      	add	x8, x22, x8
    3508:      	ldr	w8, [x8, #0x90]
    350c:      	str	w8, [sp, #0x70]
    3510:      	mov	w8, #0xe                // =14
    3514:      	blr	x8
    3518:      	lsr	x8, x0, #32
    351c:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    3520:      	add	x9, sp, #0x68
    3524:      	str	x8, [sp, #0x68]
    3528:      	mov	w8, #0x1                // =1
    352c:      	add	x1, sp, #0x68
    3530:      	ldr	x0, [x0]
    3534:      	blr	x8
    3538:      	cbz	x0, 0x3080 <generic_retuprobe_actions+0x240>
    353c:      	and	x8, x20, #0x7
    3540:      	cmp	w8, #0x4
    3544:      	b.hi	0x3080 <generic_retuprobe_actions+0x240>
    3548:      	add	x9, x22, x8, lsl #2
    354c:      	mov	w10, #0x5ea0            // =24224
    3550:      	ldr	w9, [x9, x10]
    3554:      	cbnz	w9, 0x3080 <generic_retuprobe_actions+0x240>
    3558:      	add	x8, x22, x8, lsl #3
    355c:      	mov	x20, x21
    3560:      	mov	x21, x0
    3564:      	ldr	x8, [x8, #0x5e78]
    3568:      	str	wzr, [sp, #0x74]
    356c:      	and	x8, x8, #0x7ff
    3570:      	add	x8, x22, x8
    3574:      	ldr	w8, [x8, #0x90]
    3578:      	str	w8, [sp, #0x70]
    357c:      	mov	w8, #0xe                // =14
    3580:      	blr	x8
    3584:      	lsr	x8, x0, #32
    3588:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    358c:      	mov	x3, xzr
    3590:      	str	x8, [sp, #0x68]
    3594:      	mov	w8, #0x2                // =2
    3598:      	add	x9, sp, #0x68
    359c:      	add	x1, sp, #0x68
    35a0:      	ldr	x0, [x0]
    35a4:      	mov	x2, x21
    35a8:      	mov	x21, x20
    35ac:      	blr	x8
    35b0:      	b	0x3080 <generic_retuprobe_actions+0x240>
    35b4:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    35b8:      	mov	w8, #0x3                // =3
    35bc:      	add	x9, sp, #0x68
    35c0:      	ldr	x0, [x0]
    35c4:      	add	x1, sp, #0x68
    35c8:      	blr	x8
    35cc:      	b	0x310c <generic_retuprobe_actions+0x2cc>
    35d0:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    35d4:      	mov	w8, #0x3                // =3
    35d8:      	add	x9, sp, #0x78
    35dc:      	ldr	x0, [x0]
    35e0:      	add	x1, sp, #0x78
    35e4:      	blr	x8
    35e8:      	cbnz	w0, 0x2f64 <generic_retuprobe_actions+0x124>
    35ec:      	b	0x331c <generic_retuprobe_actions+0x4dc>
    35f0:      	ldr	w8, [x22, #0x10]
    35f4:      	str	x21, [sp, #0x8]
    35f8:      	b	0x3604 <generic_retuprobe_actions+0x7c4>
    35fc:      	str	x21, [sp, #0x8]
    3600:      	mov	x8, xzr
    3604:      	str	x8, [x25, #0x10]
    3608:      	str	x25, [sp, #0x10]
    360c:      	add	x0, x25, #0x18
    3610:      	mov	w8, #0x4                // =4
    3614:      	mov	w9, #0xc8               // =200
    3618:      	mov	w1, #0xc8               // =200
    361c:      	str	x0, [sp, #0x20]
    3620:      	blr	x8
    3624:      	str	wzr, [sp, #0x2c]
    3628:      	adrp	x25, 0x3000 <generic_retuprobe_actions+0x1c0>
    362c:      	mov	w8, #0x5e78             // =24184
    3630:      	mov	x21, xzr
    3634:      	ldr	x25, [x25]
    3638:      	add	x20, x22, x8
    363c:      	b	0x3650 <generic_retuprobe_actions+0x810>
    3640:      	add	x21, x21, #0x4
    3644:      	add	x20, x20, #0x8
    3648:      	cmp	x21, #0x14
    364c:      	b.eq	0x3778 <generic_retuprobe_actions+0x938>
    3650:      	str	wzr, [sp, #0x78]
    3654:      	mov	w8, #0x1                // =1
    3658:      	add	x9, sp, #0x78
    365c:      	add	x1, sp, #0x78
    3660:      	mov	x0, x29
    3664:      	blr	x8
    3668:      	cbz	x0, 0x3778 <generic_retuprobe_actions+0x938>
    366c:      	mov	w8, #0x5ef8             // =24312
    3670:      	add	x1, x0, x8
    3674:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    3678:      	mov	w8, #0x1                // =1
    367c:      	ldr	x0, [x0]
    3680:      	blr	x8
    3684:      	cbz	x0, 0x3778 <generic_retuprobe_actions+0x938>
    3688:      	add	x8, x0, x21
    368c:      	ldr	w8, [x8, #0x40]
    3690:      	cmn	w8, #0x1
    3694:      	b.eq	0x3778 <generic_retuprobe_actions+0x938>
    3698:      	ldr	x8, [x20]
    369c:      	ldr	w9, [x22, #0x4]
    36a0:      	cmp	x8, x9
    36a4:      	b.ge	0x3778 <generic_retuprobe_actions+0x938>
    36a8:      	cmp	x21, #0x10
    36ac:      	b.eq	0x370c <generic_retuprobe_actions+0x8cc>
    36b0:      	str	wzr, [sp, #0x78]
    36b4:      	mov	w8, #0x1                // =1
    36b8:      	add	x9, sp, #0x78
    36bc:      	add	x1, sp, #0x78
    36c0:      	mov	x0, x29
    36c4:      	blr	x8
    36c8:      	cbz	x0, 0x3708 <generic_retuprobe_actions+0x8c8>
    36cc:      	mov	w8, #0x5ef8             // =24312
    36d0:      	add	x1, x0, x8
    36d4:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    36d8:      	mov	w8, #0x1                // =1
    36dc:      	ldr	x0, [x0]
    36e0:      	blr	x8
    36e4:      	cbz	x0, 0x3708 <generic_retuprobe_actions+0x8c8>
    36e8:      	add	x8, x0, x21
    36ec:      	ldr	w9, [x8, #0x44]
    36f0:      	ldr	x8, [x20]
    36f4:      	cmn	w9, #0x1
    36f8:      	b.eq	0x370c <generic_retuprobe_actions+0x8cc>
    36fc:      	ldr	w9, [x20, #0x8]
    3700:      	sub	w9, w9, w8
    3704:      	b	0x3718 <generic_retuprobe_actions+0x8d8>
    3708:      	ldr	x8, [x20]
    370c:      	ldr	w9, [x22, #0x4]
    3710:      	sub	w9, w9, w8
    3714:      	add	w9, w9, #0x4
    3718:      	cmp	w9, #0x1
    371c:      	b.lt	0x3640 <generic_retuprobe_actions+0x800>
    3720:      	mov	w10, #0x3ffc            // =16380
    3724:      	cmp	w9, #0x28
    3728:      	add	w8, w8, w10
    372c:      	mov	w10, #0x28              // =40
    3730:      	csel	w29, w9, w10, lt
    3734:      	ldr	w9, [sp, #0x2c]
    3738:      	and	x8, x8, #0x3fff
    373c:      	add	x8, x22, x8
    3740:      	mov	w1, w29
    3744:      	add	x2, x8, #0x90
    3748:      	mov	w8, #0x4                // =4
    374c:      	and	w25, w9, #0xff
    3750:      	ldr	x9, [sp, #0x20]
    3754:      	add	x0, x9, x25
    3758:      	blr	x8
    375c:      	add	w8, w29, w25
    3760:      	adrp	x25, 0x3000 <generic_retuprobe_actions+0x1c0>
    3764:      	adrp	x29, 0x3000 <generic_retuprobe_actions+0x1c0>
    3768:      	str	w8, [sp, #0x2c]
    376c:      	ldr	x25, [x25]
    3770:      	ldr	x29, [x29]
    3774:      	b	0x3640 <generic_retuprobe_actions+0x800>
    3778:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    377c:      	mov	w8, #0x1                // =1
    3780:      	ldr	x0, [x0]
    3784:      	ldr	x1, [sp, #0x10]
    3788:      	blr	x8
    378c:      	ldr	x21, [sp, #0x8]
    3790:      	cbz	x0, 0x37bc <generic_retuprobe_actions+0x97c>
    3794:      	ldr	x9, [sp, #0x68]
    3798:      	ldr	x11, [sp, #0x18]
    379c:      	mov	x10, #-0x4240           // =-16960
    37a0:      	movk	x10, #0xfff0, lsl #16
    37a4:      	ldr	x8, [x0]
    37a8:      	madd	x9, x11, x10, x9
    37ac:      	cmp	x8, x9
    37b0:      	b.ls	0x37bc <generic_retuprobe_actions+0x97c>
    37b4:      	str	wzr, [sp, #0x4c]
    37b8:      	b	0x37e4 <generic_retuprobe_actions+0x9a4>
    37bc:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    37c0:      	mov	x3, xzr
    37c4:      	mov	w8, #0x2                // =2
    37c8:      	ldr	x0, [x0]
    37cc:      	ldr	x1, [sp, #0x10]
    37d0:      	add	x9, sp, #0x68
    37d4:      	add	x2, sp, #0x68
    37d8:      	blr	x8
    37dc:      	adrp	x25, 0x3000 <generic_retuprobe_actions+0x1c0>
    37e0:      	ldr	x25, [x25]
    37e4:      	add	w8, w24, #0x3
    37e8:      	add	x20, sp, #0x64
    37ec:      	add	x8, x21, w8, uxtw #2
    37f0:      	ldr	w8, [x8, #0x4]
    37f4:      	cbz	w8, 0x3820 <generic_retuprobe_actions+0x9e0>
    37f8:      	ldrb	w8, [x22, #0x1]
    37fc:      	adrp	x1, 0x3000 <generic_retuprobe_actions+0x1c0>
    3800:      	ldr	x0, [sp, #0x50]
    3804:      	mov	x2, xzr
    3808:      	orr	w8, w8, #0x2
    380c:      	strb	w8, [x22, #0x1]
    3810:      	mov	w8, #0x1b               // =27
    3814:      	ldr	x1, [x1]
    3818:      	blr	x8
    381c:      	str	x0, [x22, #0x80]
    3820:      	add	w24, w24, #0x4
    3824:      	add	x8, x21, w24, uxtw #2
    3828:      	ldr	w8, [x8, #0x4]
    382c:      	cbz	w8, 0x331c <generic_retuprobe_actions+0x4dc>
    3830:      	ldrb	w8, [x22, #0x1]
    3834:      	adrp	x1, 0x3000 <generic_retuprobe_actions+0x1c0>
    3838:      	ldr	x0, [sp, #0x50]
    383c:      	mov	w9, #0x100              // =256
    3840:      	mov	w2, #0x100              // =256
    3844:      	orr	w8, w8, #0x4
    3848:      	strb	w8, [x22, #0x1]
    384c:      	mov	w8, #0x1b               // =27
    3850:      	ldr	x1, [x1]
    3854:      	blr	x8
    3858:      	str	x0, [x22, #0x88]
    385c:      	b	0x331c <generic_retuprobe_actions+0x4dc>
    3860:      	mov	w8, #0x1                // =1
    3864:      	mov	x3, xzr
    3868:      	add	x9, sp, #0x9c
    386c:      	str	w8, [sp, #0x9c]
    3870:      	mov	w8, #0x2                // =2
    3874:      	add	x10, sp, #0x68
    3878:      	add	x1, sp, #0x68
    387c:      	add	x2, sp, #0x9c
    3880:      	mov	x0, x25
    3884:      	blr	x8
    3888:      	adrp	x25, 0x3000 <generic_retuprobe_actions+0x1c0>
    388c:      	ldr	x25, [x25]
    3890:      	cbz	w21, 0x31f0 <generic_retuprobe_actions+0x3b0>
    3894:      	mov	w8, #0x1                // =1
    3898:      	add	x9, sp, #0x78
    389c:      	add	x1, sp, #0x78
    38a0:      	mov	x0, x25
    38a4:      	blr	x8
    38a8:      	cbz	x0, 0x31f0 <generic_retuprobe_actions+0x3b0>
    38ac:      	ldr	w8, [sp, #0x98]
    38b0:      	nop
    38b4:      	nop
    38b8:      	nop
    38bc:      	nop
    38c0:      	ldaxr	w9, [x0]
    38c4:      	add	w9, w9, w8
    38c8:      	stlxr	w10, w9, [x0]
    38cc:      	cbnz	w10, 0x38c0 <generic_retuprobe_actions+0xa80>
    38d0:      	b	0x31f0 <generic_retuprobe_actions+0x3b0>
    38d4:      	ldr	w8, [sp, #0x4c]
    38d8:      	cbz	w8, 0x38f8 <generic_retuprobe_actions+0xab8>
    38dc:      	adrp	x1, 0x3000 <generic_retuprobe_actions+0x1c0>
    38e0:      	mov	w8, #0x5                // =5
    38e4:      	mov	w9, #0xc                // =12
    38e8:      	ldr	x1, [x1]
    38ec:      	ldr	x0, [sp, #0x50]
    38f0:      	mov	w2, #0x5                // =5
    38f4:      	blr	x9
    38f8:      	ldp	x20, x19, [sp, #0xd0]
    38fc:      	mov	w0, wzr
    3900:      	ldr	x29, [sp, #0x90]
    3904:      	ldp	x22, x21, [sp, #0xc0]
    3908:      	ldp	x24, x23, [sp, #0xb0]
    390c:      	ldp	x30, x25, [sp, #0xa0]
    3910:      	add	sp, sp, #0xe0
    3914:      	ret
    3918:      	nop
    391c:      	nop

0000000000003920 <generic_retuprobe_output>:
    3920:      	sub	sp, sp, #0x20
    3924:      	stp	x30, x19, [sp, #0x10]
    3928:      	mov	x19, x0
    392c:      	str	wzr, [sp, #0x4]
    3930:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    3934:      	mov	w8, #0x1                // =1
    3938:      	ldr	x0, [x0]
    393c:      	add	x9, sp, #0x4
    3940:      	add	x1, sp, #0x4
    3944:      	blr	x8
    3948:      	cbz	x0, 0x3a70 <generic_retuprobe_output+0x150>
    394c:      	ldr	w8, [x0, #0x4]
    3950:      	mov	w9, #0x2328             // =9000
    3954:      	adrp	x1, 0x3000 <generic_retuprobe_actions+0x1c0>
    3958:      	mov	x3, x0
    395c:      	ldr	x1, [x1]
    3960:      	mov	w2, #-0x1               // =-1
    3964:      	add	w8, w8, #0x90
    3968:      	and	w8, w8, #0x7fff
    396c:      	cmp	w8, w9
    3970:      	csel	w4, w8, w9, lo
    3974:      	mov	w8, #-0x1               // =-1
    3978:      	mov	w9, #0x19               // =25
    397c:      	mov	x0, x19
    3980:      	blr	x9
    3984:      	tbnz	x0, #0x3f, 0x39c0 <generic_retuprobe_output+0xa0>
    3988:      	str	wzr, [sp, #0xc]
    398c:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    3990:      	mov	w8, #0x1                // =1
    3994:      	add	x9, sp, #0xc
    3998:      	ldr	x0, [x0]
    399c:      	add	x1, sp, #0xc
    39a0:      	blr	x8
    39a4:      	cbz	x0, 0x3a70 <generic_retuprobe_output+0x150>
    39a8:      	add	x8, x0, #0x8
    39ac:      	ldaxr	x9, [x8]
    39b0:      	add	x9, x9, #0x1
    39b4:      	stlxr	w10, x9, [x8]
    39b8:      	cbnz	w10, 0x39ac <generic_retuprobe_output+0x8c>
    39bc:      	b	0x3a70 <generic_retuprobe_output+0x150>
    39c0:      	mov	x19, x0
    39c4:      	str	wzr, [sp, #0x8]
    39c8:      	adrp	x0, 0x3000 <generic_retuprobe_actions+0x1c0>
    39cc:      	mov	w8, #0x1                // =1
    39d0:      	ldr	x0, [x0]
    39d4:      	add	x9, sp, #0x8
    39d8:      	add	x1, sp, #0x8
    39dc:      	blr	x8
    39e0:      	cbz	x0, 0x3a70 <generic_retuprobe_output+0x150>
    39e4:      	mov	x8, x19
    39e8:      	cmn	x19, #0xc
    39ec:      	b.gt	0x3a10 <generic_retuprobe_output+0xf0>
    39f0:      	cmn	x8, #0x1c
    39f4:      	b.eq	0x3a30 <generic_retuprobe_output+0x110>
    39f8:      	cmn	x8, #0x16
    39fc:      	b.eq	0x3a48 <generic_retuprobe_output+0x128>
    3a00:      	cmn	x8, #0x10
    3a04:      	b.ne	0x3a40 <generic_retuprobe_output+0x120>
    3a08:      	add	x8, x0, #0x360
    3a0c:      	b	0x3a60 <generic_retuprobe_output+0x140>
    3a10:      	cmn	x8, #0xb
    3a14:      	b.eq	0x3a38 <generic_retuprobe_output+0x118>
    3a18:      	cmn	x8, #0x7
    3a1c:      	b.eq	0x3a50 <generic_retuprobe_output+0x130>
    3a20:      	cmn	x8, #0x2
    3a24:      	b.ne	0x3a40 <generic_retuprobe_output+0x120>
    3a28:      	add	x8, x0, #0x350
    3a2c:      	b	0x3a60 <generic_retuprobe_output+0x140>
    3a30:      	add	x8, x0, #0x370
    3a34:      	b	0x3a60 <generic_retuprobe_output+0x140>
    3a38:      	add	x8, x0, #0x378
    3a3c:      	b	0x3a60 <generic_retuprobe_output+0x140>
    3a40:      	add	x8, x0, #0x348
    3a44:      	b	0x3a60 <generic_retuprobe_output+0x140>
    3a48:      	add	x8, x0, #0x368
    3a4c:      	b	0x3a60 <generic_retuprobe_output+0x140>
    3a50:      	add	x8, x0, #0x358
    3a54:      	nop
    3a58:      	nop
    3a5c:      	nop
    3a60:      	ldaxr	x9, [x8]
    3a64:      	add	x9, x9, #0x1
    3a68:      	stlxr	w10, x9, [x8]
    3a6c:      	cbnz	w10, 0x3a60 <generic_retuprobe_output+0x140>
    3a70:      	ldp	x30, x19, [sp, #0x10]
    3a74:      	mov	w0, wzr
    3a78:      	add	sp, sp, #0x20
    3a7c:      	ret

Disassembly of section uprobe/generic_retuprobe:

0000000000000000 <generic_retuprobe_event>:
       0:      	sub	sp, sp, #0x150
       4:      	str	x29, [sp, #0x100]
       8:      	stp	x30, x25, [sp, #0x110]
       c:      	stp	x24, x23, [sp, #0x120]
      10:      	stp	x22, x21, [sp, #0x130]
      14:      	stp	x20, x19, [sp, #0x140]
      18:      	str	wzr, [sp, #0x70]
      1c:      	adrp	x24, 0x0 <generic_retuprobe_event>
      20:      	ldr	x21, [x0]
      24:      	mov	w8, #0x1                // =1
      28:      	add	x9, sp, #0x70
      2c:      	mov	x19, x0
      30:      	ldr	x24, [x24]
      34:      	add	x1, sp, #0x70
      38:      	mov	x0, x24
      3c:      	blr	x8
      40:      	cbz	x0, 0x51c <generic_retuprobe_event+0x51c>
      44:      	mov	w8, #0x5ea0             // =24224
      48:      	mov	x20, x0
      4c:      	add	x25, x0, x8
      50:      	adrp	x0, 0x0 <generic_retuprobe_event>
      54:      	mov	w8, #0x1                // =1
      58:      	mov	x1, x25
      5c:      	str	wzr, [x1, #0x58]!
      60:      	ldr	x0, [x0]
      64:      	blr	x8
      68:      	cbz	x0, 0x51c <generic_retuprobe_event+0x51c>
      6c:      	ldr	w8, [x0]
      70:      	str	x21, [sp, #0x68]
      74:      	mov	x29, x0
      78:      	str	x8, [x20, #0x60]
      7c:      	mov	w8, #0xe                // =14
      80:      	blr	x8
      84:      	cmn	x0, #0x16
      88:      	b.ne	0xac <generic_retuprobe_event+0xac>
      8c:      	add	x2, x19, #0xe8
      90:      	mov	w8, #0x8                // =8
      94:      	mov	w9, #0x4                // =4
      98:      	add	x10, sp, #0xa0
      9c:      	add	x0, sp, #0xa0
      a0:      	mov	w1, #0x8                // =8
      a4:      	blr	x9
      a8:      	ldr	x0, [sp, #0xa0]
      ac:      	str	x0, [x20, #0x68]
      b0:      	mov	w8, #0xe                // =14
      b4:      	blr	x8
      b8:      	ldp	x8, x9, [x20, #0x60]
      bc:      	adrp	x22, 0x0 <generic_retuprobe_event>
      c0:      	add	x1, sp, #0xa0
      c4:      	str	w0, [x20, #0x7c]
      c8:      	stp	x8, x9, [sp, #0xa0]
      cc:      	mov	w8, #0x1                // =1
      d0:      	add	x9, sp, #0xa0
      d4:      	ldr	x22, [x22]
      d8:      	mov	x0, x22
      dc:      	blr	x8
      e0:      	cbz	x0, 0x51c <generic_retuprobe_event+0x51c>
      e4:      	ldp	x21, x9, [x0]
      e8:      	add	x1, sp, #0xa0
      ec:      	ldr	x8, [x0, #0x10]
      f0:      	mov	x0, x22
      f4:      	stp	x8, x9, [sp, #0x58]
      f8:      	mov	w8, #0x3                // =3
      fc:      	add	x9, sp, #0xa0
     100:      	blr	x8
     104:      	mov	x22, x20
     108:      	str	x21, [x22, #0x90]!
     10c:      	ldp	w21, w23, [x29, #0x58]
     110:      	cbz	w23, 0x1bc <generic_retuprobe_event+0x1bc>
     114:      	str	wzr, [x25]
     118:      	str	wzr, [sp, #0x74]
     11c:      	mov	w8, #0x1                // =1
     120:      	add	x9, sp, #0x74
     124:      	add	x1, sp, #0x74
     128:      	mov	x0, x24
     12c:      	blr	x8
     130:      	cbz	x0, 0x218 <generic_retuprobe_event+0x218>
     134:      	mov	w8, #0x5ea0             // =24224
     138:      	mov	w9, #0xc                // =12
     13c:      	ldr	w8, [x0, x8]
     140:      	str	x9, [x0, #0x5e78]
     144:      	str	w8, [x0, #0x98]
     148:      	cbz	w8, 0x244 <generic_retuprobe_event+0x244>
     14c:      	mov	x25, x29
     150:      	mov	w8, #0x4                // =4
     154:      	add	w8, w8, #0x8
     158:      	and	x29, x8, #0x1fff
     15c:      	cmp	w21, #0x3
     160:      	b.ne	0x1cc <generic_retuprobe_event+0x1cc>
     164:      	ldr	x8, [sp, #0x58]
     168:      	add	x23, x29, #0x4
     16c:      	str	wzr, [x22, x29]
     170:      	cbz	x8, 0x28c <generic_retuprobe_event+0x28c>
     174:      	ldr	x2, [sp, #0x60]
     178:      	mov	w8, #0x10               // =16
     17c:      	mov	w9, #0x4                // =4
     180:      	add	x10, sp, #0xa0
     184:      	add	x0, sp, #0xa0
     188:      	mov	w1, #0x10               // =16
     18c:      	blr	x9
     190:      	tbnz	w0, #0x1f, 0x2a4 <generic_retuprobe_event+0x2a4>
     194:      	ldr	x8, [sp, #0xa8]
     198:      	ldr	x9, [sp, #0x68]
     19c:      	cmp	x8, x9
     1a0:      	csel	x21, x8, x9, lo
     1a4:      	cmp	x9, #0x0
     1a8:      	csel	x24, x8, x21, eq
     1ac:      	cmp	x24, #0xffe
     1b0:      	b.ls	0x550 <generic_retuprobe_event+0x550>
     1b4:      	mov	w8, #-0x3               // =-3
     1b8:      	b	0x2a8 <generic_retuprobe_event+0x2a8>
     1bc:      	mov	x25, x29
     1c0:      	mov	w29, #0x8               // =8
     1c4:      	cmp	w21, #0x3
     1c8:      	b.eq	0x164 <generic_retuprobe_event+0x164>
     1cc:      	cmp	w21, #0x2
     1d0:      	b.ne	0x2b4 <generic_retuprobe_event+0x2b4>
     1d4:      	ldp	x2, x9, [sp, #0x60]
     1d8:      	add	x21, x29, #0x4
     1dc:      	mov	w8, #0xfff              // =4095
     1e0:      	mov	w24, #0x4               // =4
     1e4:      	add	x23, x22, x21
     1e8:      	str	wzr, [x22, x29]
     1ec:      	add	x0, x23, #0x8
     1f0:      	cmp	x9, #0xfff
     1f4:      	csel	x22, x9, x8, lo
     1f8:      	mov	w8, #0x4                // =4
     1fc:      	mov	w1, w22
     200:      	blr	x8
     204:      	tbnz	w0, #0x1f, 0x234 <generic_retuprobe_event+0x234>
     208:      	ldr	x8, [sp, #0x68]
     20c:      	add	x24, x22, #0x8
     210:      	str	w22, [x23, #0x4]
     214:      	b	0x238 <generic_retuprobe_event+0x238>
     218:      	mov	x25, x29
     21c:      	mov	x8, xzr
     220:      	add	w8, w8, #0x8
     224:      	and	x29, x8, #0x1fff
     228:      	cmp	w21, #0x3
     22c:      	b.ne	0x1cc <generic_retuprobe_event+0x1cc>
     230:      	b	0x164 <generic_retuprobe_event+0x164>
     234:      	mov	w8, #-0x2               // =-2
     238:      	str	w8, [x23]
     23c:      	add	x29, x24, x21
     240:      	b	0x2b4 <generic_retuprobe_event+0x2b4>
     244:      	ldr	x8, [sp, #0x68]
     248:      	add	x25, x0, #0x9c
     24c:      	cmp	w23, #0x17
     250:      	str	xzr, [sp, #0xf0]
     254:      	str	x0, [sp, #0x48]
     258:      	str	w21, [sp, #0x50]
     25c:      	str	x8, [sp, #0xa0]
     260:      	b.le	0x538 <generic_retuprobe_event+0x538>
     264:      	cmp	w23, #0x18
     268:      	b.eq	0x59c <generic_retuprobe_event+0x59c>
     26c:      	cmp	w23, #0x25
     270:      	b.eq	0x5e4 <generic_retuprobe_event+0x5e4>
     274:      	cmp	w23, #0x2a
     278:      	b.ne	0xaa8 <generic_retuprobe_event+0xaa8>
     27c:      	ldr	x8, [sp, #0x68]
     280:      	add	x21, sp, #0x78
     284:      	stp	xzr, x8, [sp, #0x78]
     288:      	b	0x614 <generic_retuprobe_event+0x614>
     28c:      	mov	x29, x22
     290:      	mov	x24, xzr
     294:      	add	x8, x29, x23
     298:      	stp	w24, w24, [x8]
     29c:      	add	x8, x24, #0x8
     2a0:      	b	0x2b0 <generic_retuprobe_event+0x2b0>
     2a4:      	mov	w8, #-0x2               // =-2
     2a8:      	str	w8, [x22, x23]
     2ac:      	mov	w8, #0x4                // =4
     2b0:      	add	x29, x8, x23
     2b4:      	mov	w8, #0x23               // =35
     2b8:      	blr	x8
     2bc:      	str	x0, [sp, #0xa0]
     2c0:      	add	x8, x0, #0x8d4
     2c4:      	mov	w9, #0x4                // =4
     2c8:      	mov	w10, #0x71              // =113
     2cc:      	add	x11, sp, #0x78
     2d0:      	add	x0, sp, #0x78
     2d4:      	mov	w1, #0x4                // =4
     2d8:      	ldr	x8, [sp, #0xa0]
     2dc:      	add	x2, x8, #0x8d4
     2e0:      	blr	x10
     2e4:      	ldr	w8, [sp, #0x78]
     2e8:      	adrp	x22, 0x0 <generic_retuprobe_event>
     2ec:      	add	x9, sp, #0xf0
     2f0:      	add	x1, sp, #0xf0
     2f4:      	str	w8, [sp, #0xf0]
     2f8:      	mov	w8, #0x1                // =1
     2fc:      	ldr	x22, [x22]
     300:      	mov	x0, x22
     304:      	blr	x8
     308:      	cbz	x0, 0x318 <generic_retuprobe_event+0x318>
     30c:      	ldr	x8, [x0, #0x8]
     310:      	mov	x23, x0
     314:      	cbnz	x8, 0x4c4 <generic_retuprobe_event+0x4c4>
     318:      	ldr	x8, [sp, #0xa0]
     31c:      	mov	w9, #0x8                // =8
     320:      	mov	w10, #0x71              // =113
     324:      	add	x11, sp, #0xa0
     328:      	add	x0, sp, #0xa0
     32c:      	mov	w1, #0x8                // =8
     330:      	add	x8, x8, #0x8e0
     334:      	ldr	x8, [sp, #0xa0]
     338:      	add	x2, x8, #0x8e0
     33c:      	blr	x10
     340:      	ldr	x8, [sp, #0xa0]
     344:      	cbz	x8, 0x4c0 <generic_retuprobe_event+0x4c0>
     348:      	add	x8, x8, #0x8d4
     34c:      	mov	w9, #0x4                // =4
     350:      	mov	w10, #0x71              // =113
     354:      	add	x11, sp, #0x78
     358:      	ldr	x8, [sp, #0xa0]
     35c:      	add	x0, sp, #0x78
     360:      	mov	w1, #0x4                // =4
     364:      	add	x2, x8, #0x8d4
     368:      	blr	x10
     36c:      	ldr	w8, [sp, #0x78]
     370:      	add	x9, sp, #0xf0
     374:      	add	x1, sp, #0xf0
     378:      	mov	x0, x22
     37c:      	str	w8, [sp, #0xf0]
     380:      	mov	w8, #0x1                // =1
     384:      	blr	x8
     388:      	cbz	x0, 0x398 <generic_retuprobe_event+0x398>
     38c:      	ldr	x8, [x0, #0x8]
     390:      	mov	x23, x0
     394:      	cbnz	x8, 0x4c4 <generic_retuprobe_event+0x4c4>
     398:      	ldr	x8, [sp, #0xa0]
     39c:      	mov	w9, #0x8                // =8
     3a0:      	mov	w10, #0x71              // =113
     3a4:      	add	x11, sp, #0xa0
     3a8:      	add	x0, sp, #0xa0
     3ac:      	mov	w1, #0x8                // =8
     3b0:      	add	x8, x8, #0x8e0
     3b4:      	ldr	x8, [sp, #0xa0]
     3b8:      	add	x2, x8, #0x8e0
     3bc:      	blr	x10
     3c0:      	ldr	x8, [sp, #0xa0]
     3c4:      	cbz	x8, 0x4c0 <generic_retuprobe_event+0x4c0>
     3c8:      	add	x8, x8, #0x8d4
     3cc:      	mov	w9, #0x4                // =4
     3d0:      	mov	w10, #0x71              // =113
     3d4:      	add	x11, sp, #0x78
     3d8:      	ldr	x8, [sp, #0xa0]
     3dc:      	add	x0, sp, #0x78
     3e0:      	mov	w1, #0x4                // =4
     3e4:      	add	x2, x8, #0x8d4
     3e8:      	blr	x10
     3ec:      	ldr	w8, [sp, #0x78]
     3f0:      	add	x9, sp, #0xf0
     3f4:      	add	x1, sp, #0xf0
     3f8:      	mov	x0, x22
     3fc:      	str	w8, [sp, #0xf0]
     400:      	mov	w8, #0x1                // =1
     404:      	blr	x8
     408:      	cbz	x0, 0x418 <generic_retuprobe_event+0x418>
     40c:      	ldr	x8, [x0, #0x8]
     410:      	mov	x23, x0
     414:      	cbnz	x8, 0x4c4 <generic_retuprobe_event+0x4c4>
     418:      	ldr	x8, [sp, #0xa0]
     41c:      	mov	w9, #0x8                // =8
     420:      	mov	w10, #0x71              // =113
     424:      	add	x11, sp, #0xa0
     428:      	add	x0, sp, #0xa0
     42c:      	mov	w1, #0x8                // =8
     430:      	add	x8, x8, #0x8e0
     434:      	ldr	x8, [sp, #0xa0]
     438:      	add	x2, x8, #0x8e0
     43c:      	blr	x10
     440:      	ldr	x8, [sp, #0xa0]
     444:      	cbz	x8, 0x4c0 <generic_retuprobe_event+0x4c0>
     448:      	add	x8, x8, #0x8d4
     44c:      	mov	w9, #0x4                // =4
     450:      	mov	w10, #0x71              // =113
     454:      	add	x11, sp, #0x78
     458:      	ldr	x8, [sp, #0xa0]
     45c:      	add	x0, sp, #0x78
     460:      	mov	w1, #0x4                // =4
     464:      	add	x2, x8, #0x8d4
     468:      	blr	x10
     46c:      	ldr	w8, [sp, #0x78]
     470:      	add	x9, sp, #0xf0
     474:      	add	x1, sp, #0xf0
     478:      	mov	x0, x22
     47c:      	str	w8, [sp, #0xf0]
     480:      	mov	w8, #0x1                // =1
     484:      	blr	x8
     488:      	cbz	x0, 0x498 <generic_retuprobe_event+0x498>
     48c:      	ldr	x8, [x0, #0x8]
     490:      	mov	x23, x0
     494:      	cbnz	x8, 0x4c4 <generic_retuprobe_event+0x4c4>
     498:      	ldr	x8, [sp, #0xa0]
     49c:      	mov	w9, #0x8                // =8
     4a0:      	mov	w10, #0x71              // =113
     4a4:      	add	x11, sp, #0xa0
     4a8:      	add	x0, sp, #0xa0
     4ac:      	mov	w1, #0x8                // =8
     4b0:      	add	x8, x8, #0x8e0
     4b4:      	ldr	x8, [sp, #0xa0]
     4b8:      	add	x2, x8, #0x8e0
     4bc:      	blr	x10
     4c0:      	mov	x23, xzr
     4c4:      	mov	w8, #0x10f              // =271
     4c8:      	stp	w8, w29, [x20]
     4cc:      	mov	w8, #0x7d               // =125
     4d0:      	blr	x8
     4d4:      	str	x0, [x20, #0x8]
     4d8:      	cbz	x23, 0x4ec <generic_retuprobe_event+0x4ec>
     4dc:      	ldr	w8, [x23]
     4e0:      	str	w8, [x20, #0x10]
     4e4:      	ldr	x8, [x23, #0x8]
     4e8:      	str	x8, [x20, #0x18]
     4ec:      	str	wzr, [x20, #0x14]
     4f0:      	adrp	x1, 0x0 <generic_retuprobe_event>
     4f4:      	mov	w9, #0xc                // =12
     4f8:      	mov	x0, x19
     4fc:      	ldr	w8, [x25]
     500:      	str	w29, [x20, #0x4]
     504:      	mov	w2, #0x3                // =3
     508:      	str	x8, [x20, #0x60]
     50c:      	mov	w8, #0x3                // =3
     510:      	ldr	x1, [x1]
     514:      	blr	x9
     518:      	mov	w0, #0x1                // =1
     51c:      	ldp	x20, x19, [sp, #0x140]
     520:      	ldr	x29, [sp, #0x100]
     524:      	ldp	x22, x21, [sp, #0x130]
     528:      	ldp	x24, x23, [sp, #0x120]
     52c:      	ldp	x30, x25, [sp, #0x110]
     530:      	add	sp, sp, #0x150
     534:      	ret
     538:      	cmp	w23, #0xf
     53c:      	b.eq	0xa18 <generic_retuprobe_event+0xa18>
     540:      	cmp	w23, #0x10
     544:      	b.ne	0xaa8 <generic_retuprobe_event+0xaa8>
     548:      	add	x21, sp, #0x108
     54c:      	b	0x5c4 <generic_retuprobe_event+0x5c4>
     550:      	mov	x8, x22
     554:      	add	x22, x29, #0xc
     558:      	mov	w9, #0x4                // =4
     55c:      	mov	w1, w24
     560:      	mov	x29, x8
     564:      	add	x0, x8, x22
     568:      	ldr	x8, [sp, #0xa0]
     56c:      	ldr	x2, [sp, #0xa0]
     570:      	blr	x9
     574:      	tbnz	w0, #0x1f, 0x590 <generic_retuprobe_event+0x590>
     578:      	ldr	x8, [sp, #0x68]
     57c:      	cbz	x8, 0xc1c <generic_retuprobe_event+0xc1c>
     580:      	subs	x9, x8, x21
     584:      	b.ne	0xc20 <generic_retuprobe_event+0xc20>
     588:      	mov	x24, x21
     58c:      	b	0x294 <generic_retuprobe_event+0x294>
     590:      	mov	w8, #-0x2               // =-2
     594:      	mov	x22, x29
     598:      	b	0x2a8 <generic_retuprobe_event+0x2a8>
     59c:      	add	x21, sp, #0x108
     5a0:      	mov	w8, #0x8                // =8
     5a4:      	mov	w9, #0x4                // =4
     5a8:      	ldr	x10, [sp, #0x68]
     5ac:      	ldr	x2, [sp, #0xa0]
     5b0:      	add	x0, sp, #0x108
     5b4:      	mov	w1, #0x8                // =8
     5b8:      	blr	x9
     5bc:      	ldr	x8, [sp, #0x108]
     5c0:      	str	x8, [sp, #0xa0]
     5c4:      	mov	w8, #0x8                // =8
     5c8:      	mov	w9, #0x4                // =4
     5cc:      	add	x10, sp, #0xa0
     5d0:      	add	x0, sp, #0x108
     5d4:      	add	x2, sp, #0xa0
     5d8:      	mov	w1, #0x8                // =8
     5dc:      	blr	x9
     5e0:      	b	0x60c <generic_retuprobe_event+0x60c>
     5e4:      	ldr	x8, [sp, #0x68]
     5e8:      	mov	w9, #0x8                // =8
     5ec:      	mov	w10, #0x4               // =4
     5f0:      	add	x11, sp, #0x108
     5f4:      	add	x0, sp, #0x108
     5f8:      	mov	w1, #0x8                // =8
     5fc:      	add	x8, x8, #0x40
     600:      	str	x8, [sp, #0xa0]
     604:      	ldr	x2, [sp, #0xa0]
     608:      	blr	x10
     60c:      	ldr	x8, [sp, #0x108]
     610:      	add	x21, x8, #0x40
     614:      	str	x25, [sp, #0x28]
     618:      	str	wzr, [sp, #0x8c]
     61c:      	adrp	x0, 0x0 <generic_retuprobe_event>
     620:      	mov	w8, #0x1                // =1
     624:      	add	x9, sp, #0x8c
     628:      	add	x1, sp, #0x8c
     62c:      	ldr	x0, [x0]
     630:      	blr	x8
     634:      	cbz	x0, 0x6c8 <generic_retuprobe_event+0x6c8>
     638:      	add	x8, x0, #0x1, lsl #12   // =0x1000
     63c:      	str	x22, [sp, #0x20]
     640:      	str	x29, [sp, #0x30]
     644:      	mov	x25, x0
     648:      	str	x8, [sp, #0x40]
     64c:      	mov	w8, #0x23               // =35
     650:      	blr	x8
     654:      	add	x2, x0, #0xb30
     658:      	mov	w23, #0x8               // =8
     65c:      	add	x8, sp, #0x90
     660:      	mov	w9, #0x4                // =4
     664:      	add	x0, sp, #0x90
     668:      	mov	w1, #0x8                // =8
     66c:      	mov	w24, #0x4               // =4
     670:      	blr	x9
     674:      	ldr	x29, [sp, #0x90]
     678:      	add	x2, x21, #0x8
     67c:      	mov	w9, #0x4                // =4
     680:      	add	x0, sp, #0x98
     684:      	mov	w1, #0x8                // =8
     688:      	add	x8, x29, #0x18
     68c:      	stp	x8, x21, [sp, #0x10]
     690:      	add	x8, sp, #0x98
     694:      	str	x2, [sp, #0x38]
     698:      	blr	x9
     69c:      	ldr	x21, [sp, #0x98]
     6a0:      	add	x22, sp, #0xa0
     6a4:      	add	x0, sp, #0xa0
     6a8:      	mov	w1, #0x8                // =8
     6ac:      	add	x2, x21, #0x10
     6b0:      	blr	x24
     6b4:      	ldr	x8, [sp, #0xa0]
     6b8:      	cbz	x8, 0x6d0 <generic_retuprobe_event+0x6d0>
     6bc:      	ldr	x9, [sp, #0x40]
     6c0:      	mov	w8, #0x1000             // =4096
     6c4:      	b	0x718 <generic_retuprobe_event+0x718>
     6c8:      	mov	x21, xzr
     6cc:      	b	0x25cc <generic_retuprobe_event+0x25cc>
     6d0:      	add	x2, x21, #0x18
     6d4:      	mov	w8, #0x8                // =8
     6d8:      	mov	w9, #0x4                // =4
     6dc:      	add	x10, sp, #0xa0
     6e0:      	add	x0, sp, #0xa0
     6e4:      	mov	w1, #0x8                // =8
     6e8:      	blr	x9
     6ec:      	ldr	x8, [sp, #0xa0]
     6f0:      	cmp	x8, x21
     6f4:      	b.eq	0x6bc <generic_retuprobe_event+0x6bc>
     6f8:      	mov	w8, #0x2964             // =10596
     6fc:      	add	x9, x25, #0xff6
     700:      	strh	w8, [x25, #0xffe]
     704:      	adrp	x8, 0x0 <generic_retuprobe_event>
     708:      	add	x8, x8, #0x0
     70c:      	ldr	x8, [x8]
     710:      	str	x8, [x9]
     714:      	mov	w8, #0xff6              // =4086
     718:      	stp	xzr, xzr, [sp, #0xa0]
     71c:      	add	x2, x29, #0x20
     720:      	mov	w29, #0x8               // =8
     724:      	add	x0, sp, #0xa0
     728:      	mov	w1, #0x8                // =8
     72c:      	add	x23, x22, #0x8
     730:      	stp	x25, xzr, [sp, #0xb0]
     734:      	add	x24, x22, #0x18
     738:      	add	x25, x22, #0x20
     73c:      	stp	xzr, xzr, [sp, #0xc0]
     740:      	mov	w21, #0x4               // =4
     744:      	str	x9, [sp, #0x40]
     748:      	str	x9, [sp, #0xd0]
     74c:      	str	w8, [sp, #0xd8]
     750:      	mov	w8, #0x4                // =4
     754:      	strb	wzr, [sp, #0xdc]
     758:      	blr	x8
     75c:      	ldr	x2, [sp, #0x10]
     760:      	mov	w8, #0x4                // =4
     764:      	mov	x0, x23
     768:      	mov	w1, #0x8                // =8
     76c:      	blr	x8
     770:      	ldr	x2, [sp, #0x38]
     774:      	mov	w8, #0x4                // =4
     778:      	mov	x0, x24
     77c:      	mov	w1, #0x8                // =8
     780:      	blr	x8
     784:      	ldr	x2, [sp, #0x18]
     788:      	mov	x0, x25
     78c:      	mov	w1, #0x8                // =8
     790:      	blr	x21
     794:      	ldr	x8, [sp, #0xc0]
     798:      	mov	w23, #0x80              // =128
     79c:      	sub	x8, x8, #0x20
     7a0:      	str	x8, [sp, #0xc8]
     7a4:      	ldp	x21, x2, [sp, #0xb8]
     7a8:      	ldp	x8, x9, [sp, #0xa0]
     7ac:      	cmp	x21, x8
     7b0:      	ccmp	x2, x9, #0x0, eq
     7b4:      	b.eq	0x91c <generic_retuprobe_event+0x91c>
     7b8:      	ldr	x25, [sp, #0xc8]
     7bc:      	mov	w8, #0x4                // =4
     7c0:      	add	x9, sp, #0xe0
     7c4:      	add	x0, sp, #0xe0
     7c8:      	mov	w1, #0x8                // =8
     7cc:      	blr	x8
     7d0:      	ldr	x8, [sp, #0xe0]
     7d4:      	cmp	x21, x8
     7d8:      	b.eq	0x8c8 <generic_retuprobe_event+0x8c8>
     7dc:      	add	x22, x21, #0x18
     7e0:      	mov	w8, #0x4                // =4
     7e4:      	add	x9, sp, #0x108
     7e8:      	add	x0, sp, #0x108
     7ec:      	mov	w1, #0x8                // =8
     7f0:      	mov	x2, x22
     7f4:      	blr	x8
     7f8:      	ldr	x8, [sp, #0x108]
     7fc:      	cmp	x8, x21
     800:      	b.eq	0x8c8 <generic_retuprobe_event+0x8c8>
     804:      	mov	w8, #0x4                // =4
     808:      	add	x9, sp, #0xe8
     80c:      	add	x0, sp, #0xe8
     810:      	mov	w1, #0x8                // =8
     814:      	mov	x2, x22
     818:      	blr	x8
     81c:      	add	x2, x21, #0x20
     820:      	mov	w8, #0x4                // =4
     824:      	mov	w9, #0x10               // =16
     828:      	add	x10, sp, #0xf0
     82c:      	add	x0, sp, #0xf0
     830:      	mov	w1, #0x10               // =16
     834:      	blr	x8
     838:      	ldr	w21, [sp, #0xf4]
     83c:      	ldr	x8, [sp, #0xb0]
     840:      	ldr	x10, [sp, #0xd0]
     844:      	sub	x12, x10, x8
     848:      	ldr	w22, [sp, #0xd8]
     84c:      	subs	w10, w21, w22
     850:      	ldr	x9, [sp, #0xf8]
     854:      	csel	w10, wzr, w10, lo
     858:      	cmp	w22, w21
     85c:      	csel	w11, w22, w21, lo
     860:      	cinc	w13, w11, hi
     864:      	sub	w14, w22, w13
     868:      	subs	x12, x12, x13
     86c:      	str	w14, [sp, #0xd8]
     870:      	b.lo	0x924 <generic_retuprobe_event+0x924>
     874:      	cmp	x12, #0xfff
     878:      	b.hi	0x924 <generic_retuprobe_event+0x924>
     87c:      	cmp	w22, w21
     880:      	b.ls	0x88c <generic_retuprobe_event+0x88c>
     884:      	mov	w13, #0x2f              // =47
     888:      	strb	w13, [x8, x12]
     88c:      	add	x25, x8, x12
     890:      	cmp	w22, w21
     894:      	add	x2, x9, x10
     898:      	and	w1, w11, #0xff
     89c:      	mov	w8, #0x4                // =4
     8a0:      	cinc	x0, x25, hi
     8a4:      	blr	x8
     8a8:      	cmp	w22, w21
     8ac:      	str	x25, [sp, #0xd0]
     8b0:      	b.ls	0x924 <generic_retuprobe_event+0x924>
     8b4:      	ldr	x8, [sp, #0xe8]
     8b8:      	str	x8, [sp, #0xb8]
     8bc:      	subs	w23, w23, #0x1
     8c0:      	b.ne	0x7a4 <generic_retuprobe_event+0x7a4>
     8c4:      	b	0x924 <generic_retuprobe_event+0x924>
     8c8:      	add	x2, x25, #0x10
     8cc:      	mov	w8, #0x4                // =4
     8d0:      	add	x9, sp, #0x108
     8d4:      	add	x0, sp, #0x108
     8d8:      	mov	w1, #0x8                // =8
     8dc:      	blr	x8
     8e0:      	ldr	x8, [sp, #0xc8]
     8e4:      	ldr	x9, [sp, #0x108]
     8e8:      	cmp	x8, x9
     8ec:      	b.eq	0x91c <generic_retuprobe_event+0x91c>
     8f0:      	add	x2, x25, #0x18
     8f4:      	mov	w8, #0x4                // =4
     8f8:      	mov	x0, x24
     8fc:      	mov	w1, #0x8                // =8
     900:      	blr	x8
     904:      	ldr	x8, [sp, #0x108]
     908:      	add	x9, x8, #0x20
     90c:      	stp	x9, x8, [sp, #0xc0]
     910:      	subs	w23, w23, #0x1
     914:      	b.ne	0x7a4 <generic_retuprobe_event+0x7a4>
     918:      	b	0x924 <generic_retuprobe_event+0x924>
     91c:      	mov	w8, #0x1                // =1
     920:      	strb	w8, [sp, #0xdc]
     924:      	ldr	x9, [sp, #0xd0]
     928:      	ldr	x2, [sp, #0x40]
     92c:      	cmp	x9, x2
     930:      	b.eq	0x96c <generic_retuprobe_event+0x96c>
     934:      	ldrb	w8, [sp, #0xdc]
     938:      	mov	w10, #0x1000            // =4096
     93c:      	ldp	x25, x29, [sp, #0x28]
     940:      	cmp	w8, #0x0
     944:      	ldr	w8, [sp, #0xd8]
     948:      	cset	w11, eq
     94c:      	sub	w10, w10, w8
     950:      	cmp	w8, #0x0
     954:      	csel	w10, w10, w8, gt
     958:      	ldr	x8, [sp, #0x48]
     95c:      	cbz	x9, 0xc10 <generic_retuprobe_event+0xc10>
     960:      	lsl	w23, w11, #1
     964:      	mov	x2, x9
     968:      	b	0x97c <generic_retuprobe_event+0x97c>
     96c:      	ldr	x8, [sp, #0x48]
     970:      	ldp	x25, x29, [sp, #0x28]
     974:      	mov	w23, wzr
     978:      	mov	w10, wzr
     97c:      	add	x0, x8, #0xa0
     980:      	and	w22, w10, #0xfff
     984:      	mov	w9, #0x4                // =4
     988:      	mov	w21, #0x4               // =4
     98c:      	mov	x24, x8
     990:      	mov	w1, w22
     994:      	blr	x9
     998:      	str	w22, [x24, #0x9c]
     99c:      	ldr	x2, [sp, #0x38]
     9a0:      	mov	w24, #0x8               // =8
     9a4:      	add	x8, sp, #0xa0
     9a8:      	mov	w9, #0x4                // =4
     9ac:      	add	x0, sp, #0xa0
     9b0:      	mov	w1, #0x8                // =8
     9b4:      	blr	x9
     9b8:      	ldr	x8, [sp, #0xa0]
     9bc:      	add	x9, sp, #0xf0
     9c0:      	mov	w10, #0x4               // =4
     9c4:      	add	x0, sp, #0xf0
     9c8:      	mov	w1, #0x8                // =8
     9cc:      	add	x8, x8, #0x30
     9d0:      	ldr	x8, [sp, #0xa0]
     9d4:      	add	x2, x8, #0x30
     9d8:      	blr	x10
     9dc:      	ldr	x8, [sp, #0xf0]
     9e0:      	mov	w9, #0x2                // =2
     9e4:      	add	x10, sp, #0x108
     9e8:      	add	x0, sp, #0x108
     9ec:      	ldr	x2, [sp, #0xf0]
     9f0:      	mov	w1, #0x2                // =2
     9f4:      	blr	x21
     9f8:      	add	x8, x25, x22
     9fc:      	add	w21, w22, #0xa
     a00:      	ldr	x22, [sp, #0x20]
     a04:      	str	w23, [x8, #0x4]
     a08:      	ldrh	w9, [sp, #0x108]
     a0c:      	strh	w9, [x8, #0x8]
     a10:      	mov	w10, #0x5ea0            // =24224
     a14:      	b	0x25c8 <generic_retuprobe_event+0x25c8>
     a18:      	mov	w8, #0x8                // =8
     a1c:      	mov	w9, #0x4                // =4
     a20:      	add	x10, sp, #0xf0
     a24:      	add	x11, sp, #0xa0
     a28:      	add	x0, sp, #0xf0
     a2c:      	add	x2, sp, #0xa0
     a30:      	mov	w1, #0x8                // =8
     a34:      	blr	x9
     a38:      	ldr	x21, [sp, #0xf0]
     a3c:      	cbnz	x21, 0x614 <generic_retuprobe_event+0x614>
     a40:      	str	wzr, [sp, #0x78]
     a44:      	mov	w8, #0x1                // =1
     a48:      	add	x9, sp, #0x78
     a4c:      	add	x1, sp, #0x78
     a50:      	mov	x0, x24
     a54:      	blr	x8
     a58:      	cbz	x0, 0x135c <generic_retuprobe_event+0x135c>
     a5c:      	mov	x21, xzr
     a60:      	cmp	w23, #0x19
     a64:      	b.gt	0xd60 <generic_retuprobe_event+0xd60>
     a68:      	cmp	w23, #0x12
     a6c:      	b.le	0x109c <generic_retuprobe_event+0x109c>
     a70:      	cmp	w23, #0x14
     a74:      	b.le	0x13c4 <generic_retuprobe_event+0x13c4>
     a78:      	cmp	w23, #0x15
     a7c:      	b.eq	0x19d8 <generic_retuprobe_event+0x19d8>
     a80:      	cmp	w23, #0x16
     a84:      	b.eq	0x1970 <generic_retuprobe_event+0x1970>
     a88:      	cmp	w23, #0x17
     a8c:      	mov	w10, #0x5ea0            // =24224
     a90:      	b.ne	0x25c8 <generic_retuprobe_event+0x25c8>
     a94:      	ldr	x8, [sp, #0x48]
     a98:      	ldr	x9, [sp, #0x68]
     a9c:      	mov	w21, #0x8               // =8
     aa0:      	stp	w9, wzr, [x8, #0x9c]
     aa4:      	b	0x25c8 <generic_retuprobe_event+0x25c8>
     aa8:      	cmp	w23, #0x28
     aac:      	b.hi	0xa40 <generic_retuprobe_event+0xa40>
     ab0:      	mov	x9, #0x7cf2             // =31986
     ab4:      	mov	w8, #0x1                // =1
     ab8:      	movk	x9, #0xf202, lsl #16
     abc:      	lsl	x8, x8, x23
     ac0:      	movk	x9, #0x1c1, lsl #32
     ac4:      	tst	x8, x9
     ac8:      	b.eq	0xa40 <generic_retuprobe_event+0xa40>
     acc:      	ldr	x8, [sp, #0x68]
     ad0:      	str	wzr, [sp, #0xe8]
     ad4:      	add	x9, sp, #0xe8
     ad8:      	add	x1, sp, #0xe8
     adc:      	mov	x0, x24
     ae0:      	str	x8, [sp, #0x108]
     ae4:      	mov	w8, #0x1                // =1
     ae8:      	blr	x8
     aec:      	mov	x21, xzr
     af0:      	str	x29, [sp, #0x30]
     af4:      	cbz	x0, 0x25c0 <generic_retuprobe_event+0x25c0>
     af8:      	cmp	w23, #0x10
     afc:      	b.gt	0xc7c <generic_retuprobe_event+0xc7c>
     b00:      	cmp	w23, #0x9
     b04:      	mov	w10, #0x5ea0            // =24224
     b08:      	b.gt	0xcac <generic_retuprobe_event+0xcac>
     b0c:      	cmp	w23, #0x4
     b10:      	b.le	0x10c4 <generic_retuprobe_event+0x10c4>
     b14:      	cmp	w23, #0x5
     b18:      	b.eq	0x1534 <generic_retuprobe_event+0x1534>
     b1c:      	cmp	w23, #0x6
     b20:      	b.eq	0xd0c <generic_retuprobe_event+0xd0c>
     b24:      	cmp	w23, #0x7
     b28:      	mov	w10, #0x5ea0            // =24224
     b2c:      	b.ne	0x25c4 <generic_retuprobe_event+0x25c4>
     b30:      	str	x22, [sp, #0x20]
     b34:      	ldr	x22, [sp, #0x108]
     b38:      	mov	x29, x0
     b3c:      	mov	w21, #0x2               // =2
     b40:      	mov	w8, #0x4                // =4
     b44:      	mov	w1, #0x2                // =2
     b48:      	ldr	x23, [sp, #0x48]
     b4c:      	mov	w24, #0x4               // =4
     b50:      	stur	x22, [x23, #0xc4]
     b54:      	add	x0, x23, #0xc2
     b58:      	add	x2, x22, #0x10
     b5c:      	blr	x8
     b60:      	add	x0, x23, #0xd6
     b64:      	add	x2, x22, #0x12
     b68:      	mov	w8, #0x1                // =1
     b6c:      	mov	w9, #0x4                // =4
     b70:      	mov	w1, #0x1                // =1
     b74:      	blr	x9
     b78:      	add	x0, x23, #0xd4
     b7c:      	add	x2, x22, #0x21e
     b80:      	mov	w8, #0x4                // =4
     b84:      	mov	w1, #0x2                // =2
     b88:      	blr	x8
     b8c:      	add	x0, x23, #0xc0
     b90:      	add	x2, x22, #0x21c
     b94:      	mov	w8, #0x4                // =4
     b98:      	mov	w1, #0x2                // =2
     b9c:      	blr	x8
     ba0:      	add	x0, x23, #0xcc
     ba4:      	add	x2, x22, #0x214
     ba8:      	mov	w8, #0x4                // =4
     bac:      	mov	w1, #0x4                // =4
     bb0:      	blr	x8
     bb4:      	add	x0, x23, #0xd0
     bb8:      	add	x2, x22, #0x210
     bbc:      	mov	w1, #0x4                // =4
     bc0:      	blr	x24
     bc4:      	ldrh	w8, [x23, #0xc2]
     bc8:      	add	x24, x23, #0xac
     bcc:      	mov	x0, x25
     bd0:      	stp	xzr, xzr, [x25]
     bd4:      	cmp	w8, #0xa
     bd8:      	stp	xzr, xzr, [x25, #0x10]
     bdc:      	b.eq	0x1cbc <generic_retuprobe_event+0x1cbc>
     be0:      	cmp	w8, #0x2
     be4:      	b.ne	0x1ce4 <generic_retuprobe_event+0x1ce4>
     be8:      	add	x2, x22, #0x4
     bec:      	mov	w8, #0x4                // =4
     bf0:      	mov	w1, #0x4                // =4
     bf4:      	mov	w21, #0x4               // =4
     bf8:      	blr	x8
     bfc:      	mov	x0, x24
     c00:      	mov	w1, #0x4                // =4
     c04:      	mov	x2, x22
     c08:      	blr	x21
     c0c:      	b	0x1ce4 <generic_retuprobe_event+0x1ce4>
     c10:      	ldr	x22, [sp, #0x20]
     c14:      	mov	x21, xzr
     c18:      	b	0x25cc <generic_retuprobe_event+0x25cc>
     c1c:      	mov	x9, xzr
     c20:      	ldr	x8, [sp, #0x58]
     c24:      	cmp	x8, #0x1
     c28:      	b.eq	0x294 <generic_retuprobe_event+0x294>
     c2c:      	ldr	x8, [sp, #0x60]
     c30:      	mov	x21, x9
     c34:      	mov	w9, #0x4                // =4
     c38:      	add	x10, sp, #0xa0
     c3c:      	add	x0, sp, #0xa0
     c40:      	mov	w1, #0x10               // =16
     c44:      	add	x2, x8, #0x10
     c48:      	mov	w8, #0x10               // =16
     c4c:      	blr	x9
     c50:      	tbnz	w0, #0x1f, 0x1090 <generic_retuprobe_event+0x1090>
     c54:      	ldr	x8, [sp, #0xa8]
     c58:      	mov	x9, x21
     c5c:      	cmp	x8, x21
     c60:      	csel	x11, x8, x21, lo
     c64:      	cmp	x21, #0x0
     c68:      	csel	x10, x8, x11, eq
     c6c:      	cmp	x10, #0xffe
     c70:      	b.ls	0xd8c <generic_retuprobe_event+0xd8c>
     c74:      	mov	w8, #-0x3               // =-3
     c78:      	b	0x1094 <generic_retuprobe_event+0x1094>
     c7c:      	cmp	w23, #0x1e
     c80:      	b.gt	0xd28 <generic_retuprobe_event+0xd28>
     c84:      	cmp	w23, #0x1c
     c88:      	b.gt	0x1114 <generic_retuprobe_event+0x1114>
     c8c:      	cmp	w23, #0x11
     c90:      	b.eq	0x168c <generic_retuprobe_event+0x168c>
     c94:      	cmp	w23, #0x19
     c98:      	b.eq	0x1478 <generic_retuprobe_event+0x1478>
     c9c:      	cmp	w23, #0x1c
     ca0:      	mov	w10, #0x5ea0            // =24224
     ca4:      	b.eq	0x10d4 <generic_retuprobe_event+0x10d4>
     ca8:      	b	0x25c4 <generic_retuprobe_event+0x25c4>
     cac:      	sub	w8, w23, #0xa
     cb0:      	cmp	w8, #0x2
     cb4:      	b.lo	0x10d4 <generic_retuprobe_event+0x10d4>
     cb8:      	sub	w8, w23, #0xc
     cbc:      	cmp	w8, #0x2
     cc0:      	b.lo	0x10f4 <generic_retuprobe_event+0x10f4>
     cc4:      	cmp	w23, #0xe
     cc8:      	b.ne	0x25c4 <generic_retuprobe_event+0x25c4>
     ccc:      	mov	w21, #0x8               // =8
     cd0:      	add	x8, sp, #0xa0
     cd4:      	add	x23, sp, #0x108
     cd8:      	mov	w9, #0x4                // =4
     cdc:      	add	x0, sp, #0xa0
     ce0:      	add	x2, sp, #0x108
     ce4:      	mov	w1, #0x8                // =8
     ce8:      	mov	x24, x22
     cec:      	mov	w22, #0x4               // =4
     cf0:      	blr	x9
     cf4:      	ldr	x8, [sp, #0xa0]
     cf8:      	add	x0, sp, #0x108
     cfc:      	mov	w1, #0x8                // =8
     d00:      	ldr	x2, [sp, #0xa0]
     d04:      	blr	x22
     d08:      	mov	x22, x24
     d0c:      	ldr	x8, [sp, #0x48]
     d10:      	ldr	x2, [sp, #0x108]
     d14:      	mov	w9, #0x2d               // =45
     d18:      	mov	w1, #0x1ff              // =511
     d1c:      	add	x0, x8, #0xa0
     d20:      	mov	w8, #0x1ff              // =511
     d24:      	b	0x1760 <generic_retuprobe_event+0x1760>
     d28:      	cmp	w23, #0x26
     d2c:      	b.gt	0x1138 <generic_retuprobe_event+0x1138>
     d30:      	sub	w8, w23, #0x1f
     d34:      	cmp	w8, #0x2
     d38:      	b.hs	0x1364 <generic_retuprobe_event+0x1364>
     d3c:      	mov	w8, #0x1                // =1
     d40:      	add	x9, sp, #0x108
     d44:      	mov	w10, #0x4               // =4
     d48:      	add	x2, sp, #0x108
     d4c:      	mov	x0, x25
     d50:      	mov	w1, #0x1                // =1
     d54:      	mov	w21, #0x4               // =4
     d58:      	blr	x10
     d5c:      	b	0x25c0 <generic_retuprobe_event+0x25c0>
     d60:      	cmp	w23, #0x20
     d64:      	b.le	0x12e8 <generic_retuprobe_event+0x12e8>
     d68:      	sub	w8, w23, #0x21
     d6c:      	cmp	w8, #0x4
     d70:      	b.hs	0x11cc <generic_retuprobe_event+0x11cc>
     d74:      	ldr	x2, [sp, #0x68]
     d78:      	mov	w21, #0x8               // =8
     d7c:      	mov	w8, #0x4                // =4
     d80:      	mov	x0, x25
     d84:      	mov	w1, #0x8                // =8
     d88:      	b	0x13bc <generic_retuprobe_event+0x13bc>
     d8c:      	add	x8, x24, x22
     d90:      	str	x11, [sp, #0x68]
     d94:      	mov	w9, #0x4                // =4
     d98:      	mov	x22, x10
     d9c:      	str	x8, [sp, #0x50]
     da0:      	add	x0, x29, x8
     da4:      	ldr	x8, [sp, #0xa0]
     da8:      	mov	w1, w22
     dac:      	ldr	x2, [sp, #0xa0]
     db0:      	blr	x9
     db4:      	tbnz	w0, #0x1f, 0x1090 <generic_retuprobe_event+0x1090>
     db8:      	add	x24, x22, x24
     dbc:      	cbz	x21, 0xdcc <generic_retuprobe_event+0xdcc>
     dc0:      	ldr	x8, [sp, #0x68]
     dc4:      	subs	x21, x21, x8
     dc8:      	b.eq	0x294 <generic_retuprobe_event+0x294>
     dcc:      	ldr	x8, [sp, #0x58]
     dd0:      	cmp	x8, #0x3
     dd4:      	b.lo	0x294 <generic_retuprobe_event+0x294>
     dd8:      	ldr	x8, [sp, #0x60]
     ddc:      	mov	w9, #0x4                // =4
     de0:      	add	x10, sp, #0xa0
     de4:      	add	x0, sp, #0xa0
     de8:      	mov	w1, #0x10               // =16
     dec:      	add	x2, x8, #0x20
     df0:      	mov	w8, #0x10               // =16
     df4:      	blr	x9
     df8:      	tbnz	w0, #0x1f, 0x1090 <generic_retuprobe_event+0x1090>
     dfc:      	ldr	x8, [sp, #0xa8]
     e00:      	cmp	x8, x21
     e04:      	csel	x9, x8, x21, lo
     e08:      	cmp	x21, #0x0
     e0c:      	csel	x8, x8, x9, eq
     e10:      	str	x9, [sp, #0x48]
     e14:      	cmp	x8, #0xffe
     e18:      	str	x8, [sp, #0x68]
     e1c:      	b.hi	0xc74 <generic_retuprobe_event+0xc74>
     e20:      	ldr	x8, [sp, #0x50]
     e24:      	mov	w9, #0x4                // =4
     e28:      	ldr	x1, [sp, #0x68]
     e2c:      	add	x22, x22, x8
     e30:      	and	x8, x22, #0x3fff
     e34:      	add	x0, x29, x8
     e38:      	ldr	x8, [sp, #0xa0]
     e3c:      	ldr	x2, [sp, #0xa0]
     e40:      	blr	x9
     e44:      	tbnz	w0, #0x1f, 0x1090 <generic_retuprobe_event+0x1090>
     e48:      	ldr	x8, [sp, #0x68]
     e4c:      	add	x24, x8, x24
     e50:      	cbz	x21, 0xe60 <generic_retuprobe_event+0xe60>
     e54:      	ldr	x8, [sp, #0x48]
     e58:      	subs	x21, x21, x8
     e5c:      	b.eq	0x294 <generic_retuprobe_event+0x294>
     e60:      	ldr	x8, [sp, #0x58]
     e64:      	cmp	x8, #0x3
     e68:      	b.eq	0x294 <generic_retuprobe_event+0x294>
     e6c:      	ldr	x8, [sp, #0x60]
     e70:      	mov	w9, #0x4                // =4
     e74:      	add	x10, sp, #0xa0
     e78:      	add	x0, sp, #0xa0
     e7c:      	mov	w1, #0x10               // =16
     e80:      	add	x2, x8, #0x30
     e84:      	mov	w8, #0x10               // =16
     e88:      	blr	x9
     e8c:      	tbnz	w0, #0x1f, 0x1090 <generic_retuprobe_event+0x1090>
     e90:      	ldr	x8, [sp, #0xa8]
     e94:      	cmp	x8, x21
     e98:      	csel	x9, x8, x21, lo
     e9c:      	cmp	x21, #0x0
     ea0:      	csel	x8, x8, x9, eq
     ea4:      	cmp	x8, #0xffe
     ea8:      	stp	x9, x8, [sp, #0x48]
     eac:      	b.hi	0xc74 <generic_retuprobe_event+0xc74>
     eb0:      	ldr	x8, [sp, #0x68]
     eb4:      	mov	w9, #0x4                // =4
     eb8:      	ldr	x1, [sp, #0x50]
     ebc:      	add	x22, x8, x22
     ec0:      	and	x8, x22, #0x3fff
     ec4:      	add	x0, x29, x8
     ec8:      	ldr	x8, [sp, #0xa0]
     ecc:      	ldr	x2, [sp, #0xa0]
     ed0:      	blr	x9
     ed4:      	tbnz	w0, #0x1f, 0x1090 <generic_retuprobe_event+0x1090>
     ed8:      	ldr	x8, [sp, #0x50]
     edc:      	add	x24, x8, x24
     ee0:      	cbz	x21, 0xef0 <generic_retuprobe_event+0xef0>
     ee4:      	ldr	x8, [sp, #0x48]
     ee8:      	subs	x21, x21, x8
     eec:      	b.eq	0x294 <generic_retuprobe_event+0x294>
     ef0:      	ldr	x8, [sp, #0x58]
     ef4:      	cmp	x8, #0x5
     ef8:      	b.lo	0x294 <generic_retuprobe_event+0x294>
     efc:      	ldr	x8, [sp, #0x60]
     f00:      	mov	w9, #0x4                // =4
     f04:      	add	x10, sp, #0xa0
     f08:      	add	x0, sp, #0xa0
     f0c:      	mov	w1, #0x10               // =16
     f10:      	add	x2, x8, #0x40
     f14:      	mov	w8, #0x10               // =16
     f18:      	blr	x9
     f1c:      	tbnz	w0, #0x1f, 0x1090 <generic_retuprobe_event+0x1090>
     f20:      	ldr	x8, [sp, #0xa8]
     f24:      	cmp	x8, x21
     f28:      	csel	x9, x8, x21, lo
     f2c:      	cmp	x21, #0x0
     f30:      	csel	x8, x8, x9, eq
     f34:      	str	x9, [sp, #0x48]
     f38:      	cmp	x8, #0xffe
     f3c:      	str	x8, [sp, #0x68]
     f40:      	b.hi	0xc74 <generic_retuprobe_event+0xc74>
     f44:      	ldr	x8, [sp, #0x50]
     f48:      	mov	w9, #0x4                // =4
     f4c:      	ldr	x1, [sp, #0x68]
     f50:      	add	x22, x8, x22
     f54:      	and	x8, x22, #0x3fff
     f58:      	add	x0, x29, x8
     f5c:      	ldr	x8, [sp, #0xa0]
     f60:      	ldr	x2, [sp, #0xa0]
     f64:      	blr	x9
     f68:      	tbnz	w0, #0x1f, 0x1090 <generic_retuprobe_event+0x1090>
     f6c:      	ldr	x8, [sp, #0x68]
     f70:      	add	x24, x8, x24
     f74:      	cbz	x21, 0xf84 <generic_retuprobe_event+0xf84>
     f78:      	ldr	x8, [sp, #0x48]
     f7c:      	subs	x21, x21, x8
     f80:      	b.eq	0x294 <generic_retuprobe_event+0x294>
     f84:      	ldr	x8, [sp, #0x58]
     f88:      	cmp	x8, #0x5
     f8c:      	b.eq	0x294 <generic_retuprobe_event+0x294>
     f90:      	ldr	x8, [sp, #0x60]
     f94:      	mov	w9, #0x4                // =4
     f98:      	add	x10, sp, #0xa0
     f9c:      	add	x0, sp, #0xa0
     fa0:      	mov	w1, #0x10               // =16
     fa4:      	add	x2, x8, #0x50
     fa8:      	mov	w8, #0x10               // =16
     fac:      	blr	x9
     fb0:      	tbnz	w0, #0x1f, 0x1090 <generic_retuprobe_event+0x1090>
     fb4:      	ldr	x8, [sp, #0xa8]
     fb8:      	cmp	x8, x21
     fbc:      	csel	x9, x8, x21, lo
     fc0:      	cmp	x21, #0x0
     fc4:      	csel	x8, x8, x9, eq
     fc8:      	cmp	x8, #0xffe
     fcc:      	stp	x9, x8, [sp, #0x48]
     fd0:      	b.hi	0xc74 <generic_retuprobe_event+0xc74>
     fd4:      	ldr	x8, [sp, #0x68]
     fd8:      	mov	w9, #0x4                // =4
     fdc:      	ldr	x1, [sp, #0x50]
     fe0:      	add	x22, x8, x22
     fe4:      	and	x8, x22, #0x3fff
     fe8:      	add	x0, x29, x8
     fec:      	ldr	x8, [sp, #0xa0]
     ff0:      	ldr	x2, [sp, #0xa0]
     ff4:      	blr	x9
     ff8:      	tbnz	w0, #0x1f, 0x1090 <generic_retuprobe_event+0x1090>
     ffc:      	ldr	x8, [sp, #0x50]
    1000:      	add	x24, x8, x24
    1004:      	cbz	x21, 0x1014 <generic_retuprobe_event+0x1014>
    1008:      	ldr	x8, [sp, #0x48]
    100c:      	subs	x21, x21, x8
    1010:      	b.eq	0x294 <generic_retuprobe_event+0x294>
    1014:      	ldr	x8, [sp, #0x58]
    1018:      	cmp	x8, #0x7
    101c:      	b.lo	0x294 <generic_retuprobe_event+0x294>
    1020:      	ldr	x8, [sp, #0x60]
    1024:      	mov	w9, #0x4                // =4
    1028:      	add	x10, sp, #0xa0
    102c:      	add	x0, sp, #0xa0
    1030:      	mov	w1, #0x10               // =16
    1034:      	add	x2, x8, #0x60
    1038:      	mov	w8, #0x10               // =16
    103c:      	blr	x9
    1040:      	tbnz	w0, #0x1f, 0x1090 <generic_retuprobe_event+0x1090>
    1044:      	ldr	x8, [sp, #0xa8]
    1048:      	cmp	x8, x21
    104c:      	csel	x9, x8, x21, lo
    1050:      	cmp	x21, #0x0
    1054:      	csel	x21, x8, x9, eq
    1058:      	cmp	x21, #0xffe
    105c:      	b.hi	0xc74 <generic_retuprobe_event+0xc74>
    1060:      	ldr	x8, [sp, #0x50]
    1064:      	mov	w9, #0x4                // =4
    1068:      	mov	w1, w21
    106c:      	add	x8, x8, x22
    1070:      	and	x8, x8, #0x3fff
    1074:      	add	x0, x29, x8
    1078:      	ldr	x8, [sp, #0xa0]
    107c:      	ldr	x2, [sp, #0xa0]
    1080:      	blr	x9
    1084:      	tbnz	w0, #0x1f, 0x1090 <generic_retuprobe_event+0x1090>
    1088:      	add	x24, x21, x24
    108c:      	b	0x294 <generic_retuprobe_event+0x294>
    1090:      	mov	w8, #-0x2               // =-2
    1094:      	str	w8, [x29, x23]
    1098:      	b	0x2ac <generic_retuprobe_event+0x2ac>
    109c:      	cmp	w23, #0x7
    10a0:      	b.gt	0x1394 <generic_retuprobe_event+0x1394>
    10a4:      	cmp	w23, #0x2
    10a8:      	b.eq	0x177c <generic_retuprobe_event+0x177c>
    10ac:      	cmp	w23, #0x3
    10b0:      	mov	w10, #0x5ea0            // =24224
    10b4:      	b.ne	0x25c8 <generic_retuprobe_event+0x25c8>
    10b8:      	stur	xzr, [x0, #0x9c]
    10bc:      	mov	w21, #0x8               // =8
    10c0:      	b	0x25c8 <generic_retuprobe_event+0x25c8>
    10c4:      	cmp	w23, #0x1
    10c8:      	b.eq	0x10f4 <generic_retuprobe_event+0x10f4>
    10cc:      	cmp	w23, #0x4
    10d0:      	b.ne	0x25c4 <generic_retuprobe_event+0x25c4>
    10d4:      	mov	w21, #0x8               // =8
    10d8:      	mov	w8, #0x4                // =4
    10dc:      	add	x9, sp, #0x108
    10e0:      	add	x2, sp, #0x108
    10e4:      	mov	x0, x25
    10e8:      	mov	w1, #0x8                // =8
    10ec:      	blr	x8
    10f0:      	b	0x25c0 <generic_retuprobe_event+0x25c0>
    10f4:      	add	x8, sp, #0x108
    10f8:      	mov	w9, #0x4                // =4
    10fc:      	add	x2, sp, #0x108
    1100:      	mov	x0, x25
    1104:      	mov	w1, #0x4                // =4
    1108:      	mov	w21, #0x4               // =4
    110c:      	blr	x9
    1110:      	b	0x25c0 <generic_retuprobe_event+0x25c0>
    1114:      	mov	w8, #0x2                // =2
    1118:      	add	x9, sp, #0x108
    111c:      	mov	w10, #0x4               // =4
    1120:      	add	x2, sp, #0x108
    1124:      	mov	x0, x25
    1128:      	mov	w1, #0x2                // =2
    112c:      	mov	w21, #0x4               // =4
    1130:      	blr	x10
    1134:      	b	0x25c0 <generic_retuprobe_event+0x25c0>
    1138:      	cmp	w23, #0x27
    113c:      	b.eq	0x1744 <generic_retuprobe_event+0x1744>
    1140:      	cmp	w23, #0x28
    1144:      	mov	w10, #0x5ea0            // =24224
    1148:      	b.ne	0x25c4 <generic_retuprobe_event+0x25c4>
    114c:      	mov	x24, x22
    1150:      	ldr	x22, [sp, #0x108]
    1154:      	stp	xzr, xzr, [x25, #0x8]
    1158:      	mov	w8, #0x2                // =2
    115c:      	mov	w9, #0x4                // =4
    1160:      	mov	x0, x25
    1164:      	str	xzr, [x25]
    1168:      	mov	w1, #0x2                // =2
    116c:      	mov	x2, x22
    1170:      	blr	x9
    1174:      	tbnz	x0, #0x3f, 0x1dd4 <generic_retuprobe_event+0x1dd4>
    1178:      	ldrh	w8, [x25]
    117c:      	cmp	w8, #0xa
    1180:      	b.eq	0x1d8c <generic_retuprobe_event+0x1d8c>
    1184:      	cmp	w8, #0x2
    1188:      	b.ne	0x1dc0 <generic_retuprobe_event+0x1dc0>
    118c:      	add	x2, x22, #0x4
    1190:      	add	x8, sp, #0xa0
    1194:      	mov	w9, #0x4                // =4
    1198:      	add	x0, sp, #0xa0
    119c:      	mov	w1, #0x4                // =4
    11a0:      	mov	w21, #0x4               // =4
    11a4:      	blr	x9
    11a8:      	ldr	w8, [sp, #0xa0]
    11ac:      	ldr	x9, [sp, #0x48]
    11b0:      	add	x2, x22, #0x2
    11b4:      	mov	w1, #0x2                // =2
    11b8:      	add	x0, x9, #0x9e
    11bc:      	stur	x8, [x9, #0xa4]
    11c0:      	mov	w8, #0x2                // =2
    11c4:      	blr	x21
    11c8:      	b	0x1dc0 <generic_retuprobe_event+0x1dc0>
    11cc:      	cmp	w23, #0x2b
    11d0:      	b.eq	0x1aa4 <generic_retuprobe_event+0x1aa4>
    11d4:      	cmp	w23, #0x29
    11d8:      	mov	w10, #0x5ea0            // =24224
    11dc:      	b.ne	0x25c8 <generic_retuprobe_event+0x25c8>
    11e0:      	ldr	x8, [sp, #0x68]
    11e4:      	str	x22, [sp, #0x20]
    11e8:      	mov	w9, #0x4                // =4
    11ec:      	add	x10, sp, #0xa0
    11f0:      	mov	w1, #0x8                // =8
    11f4:      	add	x2, x8, #0x18
    11f8:      	mov	w8, #0x8                // =8
    11fc:      	str	x0, [sp, #0x40]
    1200:      	add	x0, sp, #0xa0
    1204:      	blr	x9
    1208:      	ldr	x22, [sp, #0xa0]
    120c:      	cbz	x22, 0x1e50 <generic_retuprobe_event+0x1e50>
    1210:      	ldr	x23, [sp, #0x48]
    1214:      	add	x2, x22, #0x10
    1218:      	mov	w21, #0x2               // =2
    121c:      	mov	w8, #0x4                // =4
    1220:      	stur	x22, [x23, #0xc4]
    1224:      	add	x0, x23, #0xc2
    1228:      	mov	w1, #0x2                // =2
    122c:      	mov	w24, #0x4               // =4
    1230:      	blr	x8
    1234:      	add	x0, x23, #0xd6
    1238:      	add	x2, x22, #0x12
    123c:      	mov	w8, #0x1                // =1
    1240:      	mov	w9, #0x4                // =4
    1244:      	mov	w1, #0x1                // =1
    1248:      	blr	x9
    124c:      	add	x0, x23, #0xd4
    1250:      	add	x2, x22, #0x21e
    1254:      	mov	w8, #0x4                // =4
    1258:      	mov	w1, #0x2                // =2
    125c:      	blr	x8
    1260:      	add	x0, x23, #0xc0
    1264:      	add	x2, x22, #0x21c
    1268:      	mov	w8, #0x4                // =4
    126c:      	mov	w1, #0x2                // =2
    1270:      	blr	x8
    1274:      	add	x0, x23, #0xcc
    1278:      	add	x2, x22, #0x214
    127c:      	mov	w8, #0x4                // =4
    1280:      	mov	w1, #0x4                // =4
    1284:      	blr	x8
    1288:      	add	x0, x23, #0xd0
    128c:      	add	x2, x22, #0x210
    1290:      	mov	w1, #0x4                // =4
    1294:      	blr	x24
    1298:      	mov	x8, x25
    129c:      	ldrh	w8, [x23, #0xc2]
    12a0:      	add	x24, x23, #0xac
    12a4:      	stp	xzr, xzr, [x25]
    12a8:      	cmp	w8, #0xa
    12ac:      	stp	xzr, xzr, [x25, #0x10]
    12b0:      	b.eq	0x1de0 <generic_retuprobe_event+0x1de0>
    12b4:      	cmp	w8, #0x2
    12b8:      	b.ne	0x1e0c <generic_retuprobe_event+0x1e0c>
    12bc:      	add	x2, x22, #0x4
    12c0:      	mov	w8, #0x4                // =4
    12c4:      	mov	x0, x25
    12c8:      	mov	w1, #0x4                // =4
    12cc:      	mov	w21, #0x4               // =4
    12d0:      	blr	x8
    12d4:      	mov	x0, x24
    12d8:      	mov	w1, #0x4                // =4
    12dc:      	mov	x2, x22
    12e0:      	blr	x21
    12e4:      	b	0x1e0c <generic_retuprobe_event+0x1e0c>
    12e8:      	cmp	w23, #0x1a
    12ec:      	b.eq	0x1b3c <generic_retuprobe_event+0x1b3c>
    12f0:      	cmp	w23, #0x1b
    12f4:      	mov	w10, #0x5ea0            // =24224
    12f8:      	b.ne	0x25c8 <generic_retuprobe_event+0x25c8>
    12fc:      	ldr	x8, [sp, #0x48]
    1300:      	stp	xzr, xzr, [x25, #0x40]
    1304:      	mov	w9, #0x2d               // =45
    1308:      	mov	w1, #0x3f               // =63
    130c:      	add	x0, x8, #0xac
    1310:      	ldr	x8, [sp, #0x68]
    1314:      	stp	xzr, xzr, [x25, #0x30]
    1318:      	stp	xzr, xzr, [x25, #0x20]
    131c:      	add	x2, x8, #0x18
    1320:      	mov	w8, #0x3f               // =63
    1324:      	stp	xzr, xzr, [x25, #0x10]
    1328:      	stp	xzr, xzr, [x25]
    132c:      	blr	x9
    1330:      	tbnz	x0, #0x3f, 0x135c <generic_retuprobe_event+0x135c>
    1334:      	ldr	x8, [sp, #0x48]
    1338:      	mov	w9, #0x4                // =4
    133c:      	mov	w1, #0x8                // =8
    1340:      	add	x0, x8, #0xa4
    1344:      	ldr	x8, [sp, #0x68]
    1348:      	add	x2, x8, #0x360
    134c:      	mov	w8, #0x8                // =8
    1350:      	blr	x9
    1354:      	mov	w21, #0x50              // =80
    1358:      	b	0xa10 <generic_retuprobe_event+0xa10>
    135c:      	mov	x21, xzr
    1360:      	b	0xa10 <generic_retuprobe_event+0xa10>
    1364:      	cmp	w23, #0x26
    1368:      	mov	w10, #0x5ea0            // =24224
    136c:      	b.ne	0x25c4 <generic_retuprobe_event+0x25c4>
    1370:      	ldr	x8, [sp, #0x108]
    1374:      	add	x2, x19, w8, uxth
    1378:      	ubfx	w9, w8, #16, #12
    137c:      	ldr	x8, [sp, #0x48]
    1380:      	add	w1, w9, #0x1
    1384:      	add	x0, x8, #0xa0
    1388:      	mov	w8, #0x2d               // =45
    138c:      	blr	x8
    1390:      	b	0x1764 <generic_retuprobe_event+0x1764>
    1394:      	cmp	w23, #0x8
    1398:      	b.eq	0x17e8 <generic_retuprobe_event+0x17e8>
    139c:      	cmp	w23, #0x12
    13a0:      	mov	w10, #0x5ea0            // =24224
    13a4:      	b.ne	0x25c8 <generic_retuprobe_event+0x25c8>
    13a8:      	mov	x21, xzr
    13ac:      	mov	w8, #0x4                // =4
    13b0:      	ldr	x2, [sp, #0x68]
    13b4:      	mov	x0, x25
    13b8:      	mov	w1, wzr
    13bc:      	blr	x8
    13c0:      	b	0xa10 <generic_retuprobe_event+0xa10>
    13c4:      	cmp	w23, #0x13
    13c8:      	b.eq	0x1a58 <generic_retuprobe_event+0x1a58>
    13cc:      	cmp	w23, #0x14
    13d0:      	mov	w10, #0x5ea0            // =24224
    13d4:      	b.ne	0x25c8 <generic_retuprobe_event+0x25c8>
    13d8:      	ldr	x24, [sp, #0x68]
    13dc:      	str	xzr, [sp, #0xa0]
    13e0:      	mov	w10, #0x8               // =8
    13e4:      	add	x8, sp, #0xa0
    13e8:      	mov	w9, #0x4                // =4
    13ec:      	add	x0, sp, #0xa0
    13f0:      	mov	w1, #0x8                // =8
    13f4:      	mov	x21, x25
    13f8:      	mov	x25, x22
    13fc:      	mov	w23, #0x4               // =4
    1400:      	add	x2, x24, #0x110
    1404:      	add	x22, x24, #0xd8
    1408:      	blr	x9
    140c:      	ldr	x8, [sp, #0xa0]
    1410:      	mov	w9, #0x80               // =128
    1414:      	mov	w10, #0x2d              // =45
    1418:      	mov	x0, x21
    141c:      	ldr	x2, [sp, #0xa0]
    1420:      	mov	w1, #0x80               // =128
    1424:      	blr	x10
    1428:      	ldr	x21, [sp, #0x48]
    142c:      	mov	w8, #0x4                // =4
    1430:      	mov	w1, #0x4                // =4
    1434:      	mov	x2, x22
    1438:      	add	x0, x21, #0x12c
    143c:      	mov	x22, x25
    1440:      	blr	x8
    1444:      	add	x0, x21, #0x11c
    1448:      	add	x2, x24, #0xe0
    144c:      	mov	w8, #0x4                // =4
    1450:      	mov	w25, #0x8               // =8
    1454:      	mov	w1, #0x8                // =8
    1458:      	blr	x8
    145c:      	add	x0, x21, #0x124
    1460:      	add	x2, x24, #0x118
    1464:      	mov	w1, #0x8                // =8
    1468:      	blr	x23
    146c:      	mov	w10, #0x5ea0            // =24224
    1470:      	mov	w21, #0x98              // =152
    1474:      	b	0x25c8 <generic_retuprobe_event+0x25c8>
    1478:      	mov	x25, x22
    147c:      	ldr	x22, [sp, #0x108]
    1480:      	mov	w8, #0x1                // =1
    1484:      	mov	w9, #0x4                // =4
    1488:      	add	x10, sp, #0xe0
    148c:      	mov	x23, x0
    1490:      	add	x0, sp, #0xe0
    1494:      	mov	w1, #0x1                // =1
    1498:      	mov	x2, x22
    149c:      	blr	x9
    14a0:      	ldrb	w8, [sp, #0xe0]
    14a4:      	cmp	w8, #0x1
    14a8:      	b.ne	0x1c1c <generic_retuprobe_event+0x1c1c>
    14ac:      	add	x2, x22, #0x10
    14b0:      	mov	w22, #0x8               // =8
    14b4:      	add	x8, sp, #0xa0
    14b8:      	mov	w9, #0x4                // =4
    14bc:      	add	x0, sp, #0xa0
    14c0:      	mov	w1, #0x8                // =8
    14c4:      	mov	w21, #0x4               // =4
    14c8:      	blr	x9
    14cc:      	ldr	x2, [sp, #0xa0]
    14d0:      	add	x8, sp, #0xf0
    14d4:      	mov	w9, #0x4                // =4
    14d8:      	add	x0, sp, #0xf0
    14dc:      	mov	w1, #0x8                // =8
    14e0:      	blr	x9
    14e4:      	ldr	x8, [sp, #0xa0]
    14e8:      	mov	w9, #0x4                // =4
    14ec:      	add	x0, sp, #0x78
    14f0:      	mov	w1, #0x8                // =8
    14f4:      	add	x2, x8, #0x8
    14f8:      	add	x8, sp, #0x78
    14fc:      	blr	x9
    1500:      	ldr	x24, [sp, #0x78]
    1504:      	ldr	x2, [sp, #0xf0]
    1508:      	mov	w8, #0xfff              // =4095
    150c:      	add	x0, x23, #0xa4
    1510:      	cmp	x24, #0xfff
    1514:      	csel	x22, x24, x8, lo
    1518:      	mov	w1, w22
    151c:      	blr	x21
    1520:      	tbnz	w0, #0x1f, 0x1d78 <generic_retuprobe_event+0x1d78>
    1524:      	stp	w24, w22, [x23, #0x9c]
    1528:      	add	x21, x22, #0x8
    152c:      	mov	x22, x25
    1530:      	b	0x25c0 <generic_retuprobe_event+0x25c0>
    1534:      	ldr	x24, [sp, #0x108]
    1538:      	ldr	x21, [sp, #0x48]
    153c:      	mov	w8, #0x4                // =4
    1540:      	mov	w1, #0x4                // =4
    1544:      	mov	w23, #0x4               // =4
    1548:      	add	x0, x21, #0xc4
    154c:      	add	x2, x24, #0x98
    1550:      	stp	x22, x25, [sp, #0x20]
    1554:      	blr	x8
    1558:      	add	x0, x21, #0xc8
    155c:      	add	x2, x24, #0x70
    1560:      	mov	w8, #0x4                // =4
    1564:      	mov	w1, #0x4                // =4
    1568:      	blr	x8
    156c:      	add	x0, x21, #0xcc
    1570:      	add	x2, x24, #0x90
    1574:      	mov	w8, #0x4                // =4
    1578:      	mov	w1, #0x4                // =4
    157c:      	blr	x8
    1580:      	add	x0, x21, #0xd0
    1584:      	add	x2, x24, #0xa8
    1588:      	mov	w8, #0x4                // =4
    158c:      	mov	w1, #0x4                // =4
    1590:      	blr	x8
    1594:      	str	xzr, [sp, #0xa0]
    1598:      	add	x2, x24, #0xc8
    159c:      	mov	w8, #0x8                // =8
    15a0:      	add	x9, sp, #0xa0
    15a4:      	mov	w10, #0x4               // =4
    15a8:      	add	x0, sp, #0xa0
    15ac:      	mov	w1, #0x8                // =8
    15b0:      	blr	x10
    15b4:      	add	x2, x24, #0xb8
    15b8:      	mov	w8, #0x2                // =2
    15bc:      	add	x9, sp, #0xe0
    15c0:      	mov	w10, #0x4               // =4
    15c4:      	add	x0, sp, #0xe0
    15c8:      	mov	w1, #0x2                // =2
    15cc:      	blr	x10
    15d0:      	ldr	x8, [sp, #0xa0]
    15d4:      	ldrh	w9, [sp, #0xe0]
    15d8:      	add	x0, sp, #0x8c
    15dc:      	mov	w1, #0x1                // =1
    15e0:      	add	x22, x8, x9
    15e4:      	mov	w8, #0x1                // =1
    15e8:      	add	x9, sp, #0x8c
    15ec:      	mov	x2, x22
    15f0:      	blr	x23
    15f4:      	ldrb	w8, [sp, #0x8c]
    15f8:      	lsr	w8, w8, #4
    15fc:      	cmp	w8, #0x6
    1600:      	b.eq	0x1c34 <generic_retuprobe_event+0x1c34>
    1604:      	cmp	w8, #0x4
    1608:      	b.ne	0x25b8 <generic_retuprobe_event+0x25b8>
    160c:      	add	x2, x22, #0x9
    1610:      	mov	w8, #0x1                // =1
    1614:      	add	x9, sp, #0x90
    1618:      	mov	w10, #0x4               // =4
    161c:      	add	x0, sp, #0x90
    1620:      	mov	w1, #0x1                // =1
    1624:      	mov	w21, #0x4               // =4
    1628:      	blr	x10
    162c:      	ldrb	w8, [sp, #0x90]
    1630:      	ldr	x9, [sp, #0x48]
    1634:      	mov	w25, #0x2               // =2
    1638:      	add	x2, x22, #0xc
    163c:      	mov	w1, #0x4                // =4
    1640:      	add	x23, x9, #0xac
    1644:      	ldr	x0, [sp, #0x28]
    1648:      	strh	w8, [x9, #0xc0]
    164c:      	strh	w25, [x9, #0xc2]
    1650:      	stp	xzr, xzr, [x0]
    1654:      	mov	w8, #0x4                // =4
    1658:      	stp	xzr, xzr, [x0, #0x10]
    165c:      	blr	x8
    1660:      	add	x2, x22, #0x10
    1664:      	mov	w8, #0x4                // =4
    1668:      	mov	x0, x23
    166c:      	mov	w1, #0x4                // =4
    1670:      	blr	x8
    1674:      	add	x2, x24, #0xb6
    1678:      	add	x8, sp, #0x98
    167c:      	add	x0, sp, #0x98
    1680:      	mov	w1, #0x2                // =2
    1684:      	blr	x21
    1688:      	b	0x2480 <generic_retuprobe_event+0x2480>
    168c:      	stp	xzr, xzr, [sp, #0xa0]
    1690:      	mov	w8, #0xe                // =14
    1694:      	mov	x24, x22
    1698:      	blr	x8
    169c:      	lsr	x8, x0, #32
    16a0:      	add	x9, sp, #0xf0
    16a4:      	add	x10, sp, #0x108
    16a8:      	str	x8, [sp, #0xa0]
    16ac:      	mov	w8, #0x4                // =4
    16b0:      	add	x0, sp, #0xf0
    16b4:      	add	x2, sp, #0x108
    16b8:      	mov	w1, #0x4                // =4
    16bc:      	blr	x8
    16c0:      	ldr	w8, [sp, #0xf0]
    16c4:      	adrp	x0, 0x1000 <generic_retuprobe_event+0x1000>
    16c8:      	add	x9, sp, #0xa0
    16cc:      	add	x1, sp, #0xa0
    16d0:      	str	w8, [sp, #0xa8]
    16d4:      	mov	w8, #0x1                // =1
    16d8:      	ldr	x0, [x0]
    16dc:      	blr	x8
    16e0:      	cbz	x0, 0x1c2c <generic_retuprobe_event+0x1c2c>
    16e4:      	ldr	w21, [x0]
    16e8:      	add	x8, sp, #0xf0
    16ec:      	mov	w9, #0x4                // =4
    16f0:      	add	x2, sp, #0xf0
    16f4:      	mov	x22, x0
    16f8:      	mov	x0, x25
    16fc:      	mov	w1, #0x4                // =4
    1700:      	mov	w23, #0x4               // =4
    1704:      	blr	x9
    1708:      	ldr	x8, [sp, #0x48]
    170c:      	and	x21, x21, #0xfff
    1710:      	mov	x2, x22
    1714:      	add	x1, x21, #0x4
    1718:      	add	x0, x8, #0xa0
    171c:      	mov	w8, #0x4                // =4
    1720:      	blr	x8
    1724:      	add	w21, w21, #0x8
    1728:      	mov	w1, #0x4                // =4
    172c:      	add	x8, x21, x22
    1730:      	add	x0, x25, x21
    1734:      	sub	x2, x8, #0x4
    1738:      	blr	x23
    173c:      	add	x21, x21, #0x4
    1740:      	b	0x1dd8 <generic_retuprobe_event+0x1dd8>
    1744:      	ldr	x8, [sp, #0x108]
    1748:      	mov	w9, #0x2d               // =45
    174c:      	mov	w1, #0x11               // =17
    1750:      	add	x2, x8, #0x118
    1754:      	ldr	x8, [sp, #0x48]
    1758:      	add	x0, x8, #0xa0
    175c:      	mov	w8, #0x11               // =17
    1760:      	blr	x9
    1764:      	mov	x21, x0
    1768:      	tbnz	x0, #0x3f, 0x25c0 <generic_retuprobe_event+0x25c0>
    176c:      	sub	w8, w21, #0x1
    1770:      	add	x21, x21, #0x3
    1774:      	str	w8, [x25]
    1778:      	b	0x25c0 <generic_retuprobe_event+0x25c0>
    177c:      	str	x22, [sp, #0x20]
    1780:      	str	xzr, [sp, #0xf0]
    1784:      	mov	w8, #0x8                // =8
    1788:      	add	x9, sp, #0xf0
    178c:      	add	x10, sp, #0xa0
    1790:      	mov	w11, #0x4               // =4
    1794:      	str	xzr, [sp, #0xa0]
    1798:      	mov	x24, x0
    179c:      	add	x0, sp, #0xf0
    17a0:      	add	x2, sp, #0xa0
    17a4:      	mov	w1, #0x8                // =8
    17a8:      	mov	w21, #0x4               // =4
    17ac:      	blr	x11
    17b0:      	ldr	x25, [sp, #0xf0]
    17b4:      	mov	w8, #0xfff              // =4095
    17b8:      	ldr	x2, [sp, #0x68]
    17bc:      	add	x0, x24, #0xa4
    17c0:      	mov	x23, x24
    17c4:      	cmp	x25, #0xfff
    17c8:      	csel	x22, x25, x8, lo
    17cc:      	mov	w8, #0x4                // =4
    17d0:      	mov	w1, w22
    17d4:      	blr	x8
    17d8:      	tbnz	w0, #0x1f, 0x1d68 <generic_retuprobe_event+0x1d68>
    17dc:      	add	x21, x22, #0x8
    17e0:      	str	w22, [x23, #0xa0]
    17e4:      	b	0x1d6c <generic_retuprobe_event+0x1d6c>
    17e8:      	mov	x0, x25
    17ec:      	ldr	x25, [sp, #0x48]
    17f0:      	str	x22, [sp, #0x20]
    17f4:      	mov	w1, #0x4                // =4
    17f8:      	mov	w23, #0x4               // =4
    17fc:      	add	x8, x25, #0xdc
    1800:      	ldr	x22, [sp, #0x68]
    1804:      	add	x2, x22, #0x8
    1808:      	add	x24, x25, #0xc4
    180c:      	str	x8, [sp, #0x40]
    1810:      	mov	w8, #0x4                // =4
    1814:      	blr	x8
    1818:      	add	x0, x25, #0xa0
    181c:      	add	x2, x22, #0xc
    1820:      	mov	w8, #0x4                // =4
    1824:      	mov	w1, #0x4                // =4
    1828:      	blr	x8
    182c:      	add	x0, x25, #0xac
    1830:      	add	x2, x22, #0x18
    1834:      	mov	w8, #0x4                // =4
    1838:      	mov	w1, #0x4                // =4
    183c:      	blr	x8
    1840:      	add	x0, x25, #0xb0
    1844:      	add	x2, x22, #0x1c
    1848:      	mov	w8, #0x4                // =4
    184c:      	mov	w1, #0x4                // =4
    1850:      	blr	x8
    1854:      	add	x0, x25, #0xa4
    1858:      	add	x2, x22, #0x10
    185c:      	mov	w8, #0x4                // =4
    1860:      	mov	w1, #0x4                // =4
    1864:      	blr	x8
    1868:      	add	x0, x25, #0xa8
    186c:      	add	x2, x22, #0x14
    1870:      	mov	w8, #0x4                // =4
    1874:      	mov	w1, #0x4                // =4
    1878:      	blr	x8
    187c:      	add	x0, x25, #0xb4
    1880:      	add	x2, x22, #0x20
    1884:      	mov	w8, #0x4                // =4
    1888:      	mov	w1, #0x4                // =4
    188c:      	blr	x8
    1890:      	add	x0, x25, #0xb8
    1894:      	add	x2, x22, #0x24
    1898:      	mov	w8, #0x4                // =4
    189c:      	mov	w1, #0x4                // =4
    18a0:      	blr	x8
    18a4:      	str	wzr, [x25, #0xc0]
    18a8:      	add	x0, x25, #0xbc
    18ac:      	add	x2, x22, #0x28
    18b0:      	mov	w8, #0x4                // =4
    18b4:      	mov	w1, #0x4                // =4
    18b8:      	blr	x8
    18bc:      	add	x0, x25, #0xcc
    18c0:      	add	x2, x22, #0x40
    18c4:      	mov	w21, #0x8               // =8
    18c8:      	mov	w8, #0x4                // =4
    18cc:      	mov	w1, #0x8                // =8
    18d0:      	blr	x8
    18d4:      	add	x0, x25, #0xd4
    18d8:      	add	x2, x22, #0x30
    18dc:      	mov	w8, #0x4                // =4
    18e0:      	mov	w1, #0x8                // =8
    18e4:      	blr	x8
    18e8:      	add	x2, x22, #0x38
    18ec:      	mov	w8, #0x4                // =4
    18f0:      	mov	x0, x24
    18f4:      	mov	w1, #0x8                // =8
    18f8:      	blr	x8
    18fc:      	add	x2, x22, #0x90
    1900:      	add	x8, sp, #0xa0
    1904:      	mov	w9, #0x4                // =4
    1908:      	add	x0, sp, #0xa0
    190c:      	mov	w1, #0x8                // =8
    1910:      	blr	x9
    1914:      	ldr	x21, [sp, #0xa0]
    1918:      	mov	w8, #0x4                // =4
    191c:      	ldr	x0, [sp, #0x40]
    1920:      	mov	w1, #0x4                // =4
    1924:      	add	x2, x21, #0xc8
    1928:      	ldr	x22, [sp, #0x20]
    192c:      	blr	x8
    1930:      	add	x0, x25, #0xe0
    1934:      	add	x2, x21, #0xcc
    1938:      	mov	w8, #0x4                // =4
    193c:      	mov	w1, #0x4                // =4
    1940:      	blr	x8
    1944:      	add	x0, x25, #0xe4
    1948:      	add	x2, x21, #0xd0
    194c:      	mov	w8, #0x4                // =4
    1950:      	mov	w1, #0x4                // =4
    1954:      	blr	x8
    1958:      	add	x0, x25, #0xe8
    195c:      	add	x2, x21, #0x158
    1960:      	mov	w1, #0x4                // =4
    1964:      	blr	x23
    1968:      	mov	w21, #0x50              // =80
    196c:      	b	0xa10 <generic_retuprobe_event+0xa10>
    1970:      	ldr	x24, [sp, #0x68]
    1974:      	mov	w8, #0x4                // =4
    1978:      	mov	x0, x25
    197c:      	mov	w1, #0x4                // =4
    1980:      	mov	w21, #0x4               // =4
    1984:      	add	x2, x24, #0xc8
    1988:      	blr	x8
    198c:      	mov	x23, x22
    1990:      	ldr	x22, [sp, #0x48]
    1994:      	add	x2, x24, #0xcc
    1998:      	mov	w8, #0x4                // =4
    199c:      	mov	w1, #0x4                // =4
    19a0:      	add	x0, x22, #0xa0
    19a4:      	blr	x8
    19a8:      	add	x0, x22, #0xa4
    19ac:      	add	x2, x24, #0xd0
    19b0:      	mov	w8, #0x4                // =4
    19b4:      	mov	w1, #0x4                // =4
    19b8:      	blr	x8
    19bc:      	add	x0, x22, #0xa8
    19c0:      	add	x2, x24, #0x158
    19c4:      	mov	w1, #0x4                // =4
    19c8:      	mov	x22, x23
    19cc:      	blr	x21
    19d0:      	mov	w21, #0x10              // =16
    19d4:      	b	0xa10 <generic_retuprobe_event+0xa10>
    19d8:      	ldr	x24, [sp, #0x68]
    19dc:      	mov	w8, #0x4                // =4
    19e0:      	mov	x0, x25
    19e4:      	mov	w1, #0x4                // =4
    19e8:      	mov	x23, x22
    19ec:      	mov	w22, #0x4               // =4
    19f0:      	add	x2, x24, #0x38
    19f4:      	blr	x8
    19f8:      	ldr	x21, [sp, #0x48]
    19fc:      	add	x2, x24, #0x3c
    1a00:      	mov	w8, #0x4                // =4
    1a04:      	mov	w1, #0x4                // =4
    1a08:      	add	x0, x21, #0xa0
    1a0c:      	blr	x8
    1a10:      	add	x0, x21, #0xa4
    1a14:      	add	x2, x24, #0x40
    1a18:      	mov	w8, #0x4                // =4
    1a1c:      	mov	w1, #0x4                // =4
    1a20:      	blr	x8
    1a24:      	add	x0, x21, #0xa8
    1a28:      	add	x2, x24, #0x44
    1a2c:      	mov	w8, #0x4                // =4
    1a30:      	mov	w1, #0x4                // =4
    1a34:      	blr	x8
    1a38:      	add	x0, x21, #0xac
    1a3c:      	add	x2, x24, #0x80
    1a40:      	mov	w8, #0x10               // =16
    1a44:      	mov	w1, #0x10               // =16
    1a48:      	blr	x22
    1a4c:      	mov	x22, x23
    1a50:      	mov	w21, #0x20              // =32
    1a54:      	b	0xa10 <generic_retuprobe_event+0xa10>
    1a58:      	ldr	x24, [sp, #0x68]
    1a5c:      	mov	w8, #0x4                // =4
    1a60:      	mov	x0, x25
    1a64:      	mov	w1, #0x4                // =4
    1a68:      	mov	w21, #0x4               // =4
    1a6c:      	mov	x2, x24
    1a70:      	blr	x8
    1a74:      	mov	x23, x22
    1a78:      	ldr	x22, [sp, #0x48]
    1a7c:      	add	x2, x24, #0x4
    1a80:      	mov	w8, #0x4                // =4
    1a84:      	mov	w1, #0x4                // =4
    1a88:      	add	x0, x22, #0xa0
    1a8c:      	blr	x8
    1a90:      	add	x0, x22, #0xa4
    1a94:      	add	x2, x24, #0x30
    1a98:      	mov	w8, #0x10               // =16
    1a9c:      	mov	x22, x23
    1aa0:      	b	0x1b2c <generic_retuprobe_event+0x1b2c>
    1aa4:      	ldr	x24, [sp, #0x68]
    1aa8:      	add	x8, sp, #0xa0
    1aac:      	mov	w9, #0x4                // =4
    1ab0:      	add	x0, sp, #0xa0
    1ab4:      	mov	w1, #0x4                // =4
    1ab8:      	mov	w21, #0x4               // =4
    1abc:      	add	x2, x24, #0x4
    1ac0:      	blr	x9
    1ac4:      	ldr	w8, [sp, #0xa0]
    1ac8:      	mov	x23, x22
    1acc:      	ldr	x22, [sp, #0x48]
    1ad0:      	add	x2, x24, #0xc
    1ad4:      	add	x0, sp, #0xa0
    1ad8:      	mov	w1, #0x4                // =4
    1adc:      	str	w8, [x22, #0x9c]
    1ae0:      	add	x8, sp, #0xa0
    1ae4:      	blr	x21
    1ae8:      	ldr	w8, [sp, #0xa0]
    1aec:      	add	x2, x24, #0x50
    1af0:      	add	x9, sp, #0xa0
    1af4:      	mov	w10, #0x2d              // =45
    1af8:      	str	w8, [x22, #0xa0]
    1afc:      	mov	w8, #0x8                // =8
    1b00:      	add	x0, sp, #0xa0
    1b04:      	mov	w1, #0x8                // =8
    1b08:      	mov	w21, #0x2d              // =45
    1b0c:      	blr	x10
    1b10:      	ldr	x8, [sp, #0xa0]
    1b14:      	add	x0, x22, #0xa4
    1b18:      	mov	w9, #0x10               // =16
    1b1c:      	mov	x22, x23
    1b20:      	add	x8, x8, #0x3f8
    1b24:      	ldr	x8, [sp, #0xa0]
    1b28:      	add	x2, x8, #0x3f8
    1b2c:      	mov	w1, #0x10               // =16
    1b30:      	blr	x21
    1b34:      	mov	w21, #0x18              // =24
    1b38:      	b	0xa10 <generic_retuprobe_event+0xa10>
    1b3c:      	stp	xzr, xzr, [x25, #0x40]
    1b40:      	mov	w8, #0x8                // =8
    1b44:      	mov	w9, #0x4                // =4
    1b48:      	add	x10, sp, #0xa0
    1b4c:      	add	x0, sp, #0xa0
    1b50:      	ldr	x2, [sp, #0x68]
    1b54:      	stp	xzr, xzr, [x25, #0x30]
    1b58:      	mov	w1, #0x8                // =8
    1b5c:      	mov	x23, x25
    1b60:      	stp	xzr, xzr, [x25, #0x20]
    1b64:      	stp	xzr, xzr, [x25, #0x10]
    1b68:      	stp	xzr, xzr, [x25]
    1b6c:      	blr	x9
    1b70:      	mov	x21, xzr
    1b74:      	cbnz	x0, 0xa10 <generic_retuprobe_event+0xa10>
    1b78:      	ldr	x8, [sp, #0x48]
    1b7c:      	mov	w9, #0x3f               // =63
    1b80:      	mov	w10, #0x2d              // =45
    1b84:      	mov	w1, #0x3f               // =63
    1b88:      	mov	x25, x22
    1b8c:      	add	x0, x8, #0xac
    1b90:      	ldr	x8, [sp, #0xa0]
    1b94:      	ldr	x2, [sp, #0xa0]
    1b98:      	blr	x10
    1b9c:      	tbnz	x0, #0x3f, 0x1ea0 <generic_retuprobe_event+0x1ea0>
    1ba0:      	ldr	x24, [sp, #0x68]
    1ba4:      	mov	w21, #0x8               // =8
    1ba8:      	add	x8, sp, #0xf0
    1bac:      	mov	w9, #0x4                // =4
    1bb0:      	add	x0, sp, #0xf0
    1bb4:      	mov	w1, #0x8                // =8
    1bb8:      	mov	w22, #0x4               // =4
    1bbc:      	add	x2, x24, #0x8
    1bc0:      	blr	x9
    1bc4:      	ldr	x8, [sp, #0x48]
    1bc8:      	mov	w9, #0x4                // =4
    1bcc:      	mov	w1, #0x8                // =8
    1bd0:      	add	x0, x8, #0xa4
    1bd4:      	ldr	x8, [sp, #0xf0]
    1bd8:      	add	x8, x8, #0x360
    1bdc:      	ldr	x8, [sp, #0xf0]
    1be0:      	add	x2, x8, #0x360
    1be4:      	blr	x9
    1be8:      	add	x2, x24, #0x58
    1bec:      	add	x8, sp, #0xf0
    1bf0:      	add	x0, sp, #0xf0
    1bf4:      	mov	w1, #0x4                // =4
    1bf8:      	blr	x22
    1bfc:      	cbnz	x0, 0x1c10 <generic_retuprobe_event+0x1c10>
    1c00:      	ldr	w8, [sp, #0xf0]
    1c04:      	cmp	w8, #0x0
    1c08:      	cset	w8, ne
    1c0c:      	str	w8, [x23]
    1c10:      	mov	w21, #0x50              // =80
    1c14:      	mov	x22, x25
    1c18:      	b	0xa10 <generic_retuprobe_event+0xa10>
    1c1c:      	stur	xzr, [x23, #0x9c]
    1c20:      	mov	w21, #0x8               // =8
    1c24:      	mov	x22, x25
    1c28:      	b	0x25c0 <generic_retuprobe_event+0x25c0>
    1c2c:      	mov	x21, #-0x1              // =-1
    1c30:      	b	0x1dd8 <generic_retuprobe_event+0x1dd8>
    1c34:      	str	wzr, [sp, #0xf0]
    1c38:      	adrp	x0, 0x1000 <generic_retuprobe_event+0x1000>
    1c3c:      	ldr	x23, [sp, #0xa0]
    1c40:      	mov	w8, #0x1                // =1
    1c44:      	add	x9, sp, #0xf0
    1c48:      	add	x1, sp, #0xf0
    1c4c:      	ldrh	w21, [sp, #0xe0]
    1c50:      	ldr	x0, [x0]
    1c54:      	add	x22, x23, x21
    1c58:      	blr	x8
    1c5c:      	cbz	x0, 0x243c <generic_retuprobe_event+0x243c>
    1c60:      	mov	w8, #0xff               // =255
    1c64:      	strh	w21, [x0]
    1c68:      	strb	wzr, [x0, #0x7]
    1c6c:      	add	x29, x0, #0x6
    1c70:      	add	x2, x22, #0x6
    1c74:      	mov	w9, #0x4                // =4
    1c78:      	strb	w8, [x0, #0x5]
    1c7c:      	mov	w8, #0x1                // =1
    1c80:      	mov	x25, x0
    1c84:      	mov	x0, x29
    1c88:      	mov	w1, #0x1                // =1
    1c8c:      	blr	x9
    1c90:      	tbnz	x0, #0x3f, 0x243c <generic_retuprobe_event+0x243c>
    1c94:      	ldrb	w8, [x25, #0x5]
    1c98:      	cmp	w8, #0x32
    1c9c:      	b.gt	0x1eac <generic_retuprobe_event+0x1eac>
    1ca0:      	cbz	w8, 0x1ecc <generic_retuprobe_event+0x1ecc>
    1ca4:      	cmp	w8, #0x2b
    1ca8:      	b.eq	0x1ecc <generic_retuprobe_event+0x1ecc>
    1cac:      	cmp	w8, #0x2c
    1cb0:      	b.ne	0x1f98 <generic_retuprobe_event+0x1f98>
    1cb4:      	mov	w8, #0x8                // =8
    1cb8:      	b	0x1ee4 <generic_retuprobe_event+0x1ee4>
    1cbc:      	add	x2, x22, #0x48
    1cc0:      	mov	w21, #0x10              // =16
    1cc4:      	mov	w8, #0x4                // =4
    1cc8:      	mov	w1, #0x10               // =16
    1ccc:      	mov	w23, #0x4               // =4
    1cd0:      	blr	x8
    1cd4:      	add	x2, x22, #0x38
    1cd8:      	mov	x0, x24
    1cdc:      	mov	w1, #0x10               // =16
    1ce0:      	blr	x23
    1ce4:      	ldr	x21, [sp, #0x48]
    1ce8:      	add	x23, x22, #0xc
    1cec:      	add	x2, x22, #0xe
    1cf0:      	mov	w22, #0x2               // =2
    1cf4:      	mov	w8, #0x4                // =4
    1cf8:      	mov	w1, #0x2                // =2
    1cfc:      	mov	w24, #0x4               // =4
    1d00:      	add	x0, x21, #0xbc
    1d04:      	blr	x8
    1d08:      	add	x0, x21, #0xbe
    1d0c:      	mov	w1, #0x2                // =2
    1d10:      	mov	x2, x23
    1d14:      	blr	x24
    1d18:      	ldrh	w8, [x21, #0xbe]
    1d1c:      	adrp	x0, 0x1000 <generic_retuprobe_event+0x1000>
    1d20:      	add	x9, sp, #0xa0
    1d24:      	add	x1, sp, #0xa0
    1d28:      	rev	w8, w8
    1d2c:      	lsr	w8, w8, #16
    1d30:      	strh	w8, [x21, #0xbe]
    1d34:      	ldr	x8, [sp, #0x108]
    1d38:      	str	x8, [sp, #0xa0]
    1d3c:      	mov	w8, #0x1                // =1
    1d40:      	ldr	x0, [x0]
    1d44:      	blr	x8
    1d48:      	cbz	x0, 0x25b8 <generic_retuprobe_event+0x25b8>
    1d4c:      	ldr	w8, [x0]
    1d50:      	str	w8, [x29, #0x10]
    1d54:      	ldr	x8, [x0, #0x8]
    1d58:      	str	x8, [x29, #0x18]
    1d5c:      	ldr	w8, [x0, #0x4]
    1d60:      	str	w8, [x29, #0x7c]
    1d64:      	b	0x25b8 <generic_retuprobe_event+0x25b8>
    1d68:      	mov	w25, #-0x2              // =-2
    1d6c:      	ldr	x22, [sp, #0x20]
    1d70:      	str	w25, [x23, #0x9c]
    1d74:      	b	0xa10 <generic_retuprobe_event+0xa10>
    1d78:      	mov	w8, #-0x2               // =-2
    1d7c:      	mov	w21, #0x4               // =4
    1d80:      	mov	x22, x25
    1d84:      	str	w8, [x23, #0x9c]
    1d88:      	b	0x25c0 <generic_retuprobe_event+0x25c0>
    1d8c:      	ldr	x21, [sp, #0x48]
    1d90:      	add	x2, x22, #0x8
    1d94:      	mov	w8, #0x10               // =16
    1d98:      	mov	w9, #0x4                // =4
    1d9c:      	mov	w1, #0x10               // =16
    1da0:      	mov	w23, #0x4               // =4
    1da4:      	add	x0, x21, #0xa4
    1da8:      	blr	x9
    1dac:      	add	x0, x21, #0x9e
    1db0:      	add	x2, x22, #0x2
    1db4:      	mov	w8, #0x2                // =2
    1db8:      	mov	w1, #0x2                // =2
    1dbc:      	blr	x23
    1dc0:      	ldr	x8, [sp, #0x48]
    1dc4:      	ldrh	w9, [x8, #0x9e]
    1dc8:      	rev	w9, w9
    1dcc:      	lsr	w9, w9, #16
    1dd0:      	strh	w9, [x8, #0x9e]
    1dd4:      	mov	w21, #0x18              // =24
    1dd8:      	mov	x22, x24
    1ddc:      	b	0x25c0 <generic_retuprobe_event+0x25c0>
    1de0:      	add	x2, x22, #0x48
    1de4:      	mov	w21, #0x10              // =16
    1de8:      	mov	w8, #0x4                // =4
    1dec:      	mov	x0, x25
    1df0:      	mov	w1, #0x10               // =16
    1df4:      	mov	w23, #0x4               // =4
    1df8:      	blr	x8
    1dfc:      	add	x2, x22, #0x38
    1e00:      	mov	x0, x24
    1e04:      	mov	w1, #0x10               // =16
    1e08:      	blr	x23
    1e0c:      	ldr	x21, [sp, #0x48]
    1e10:      	add	x23, x22, #0xc
    1e14:      	add	x2, x22, #0xe
    1e18:      	mov	w22, #0x2               // =2
    1e1c:      	mov	w8, #0x4                // =4
    1e20:      	mov	w1, #0x2                // =2
    1e24:      	mov	w24, #0x4               // =4
    1e28:      	add	x0, x21, #0xbc
    1e2c:      	blr	x8
    1e30:      	add	x0, x21, #0xbe
    1e34:      	mov	w1, #0x2                // =2
    1e38:      	mov	x2, x23
    1e3c:      	blr	x24
    1e40:      	ldrh	w8, [x21, #0xbe]
    1e44:      	rev	w8, w8
    1e48:      	lsr	w8, w8, #16
    1e4c:      	strh	w8, [x21, #0xbe]
    1e50:      	ldr	x8, [sp, #0x48]
    1e54:      	adrp	x0, 0x1000 <generic_retuprobe_event+0x1000>
    1e58:      	add	x9, sp, #0xa0
    1e5c:      	add	x1, sp, #0xa0
    1e60:      	ldur	x8, [x8, #0xc4]
    1e64:      	str	x8, [sp, #0xa0]
    1e68:      	mov	w8, #0x1                // =1
    1e6c:      	ldr	x0, [x0]
    1e70:      	blr	x8
    1e74:      	cbz	x0, 0x1e94 <generic_retuprobe_event+0x1e94>
    1e78:      	ldr	w8, [x0]
    1e7c:      	ldr	x25, [sp, #0x40]
    1e80:      	str	w8, [x25, #0x10]
    1e84:      	ldr	x8, [x0, #0x8]
    1e88:      	str	x8, [x25, #0x18]
    1e8c:      	ldr	w8, [x0, #0x4]
    1e90:      	str	w8, [x25, #0x7c]
    1e94:      	ldr	x22, [sp, #0x20]
    1e98:      	mov	w21, #0x40              // =64
    1e9c:      	b	0xa10 <generic_retuprobe_event+0xa10>
    1ea0:      	mov	x21, xzr
    1ea4:      	mov	x22, x25
    1ea8:      	b	0xa10 <generic_retuprobe_event+0xa10>
    1eac:      	cmp	w8, #0x33
    1eb0:      	b.eq	0x1ed8 <generic_retuprobe_event+0x1ed8>
    1eb4:      	cmp	w8, #0x3c
    1eb8:      	b.eq	0x1ecc <generic_retuprobe_event+0x1ecc>
    1ebc:      	cmp	w8, #0xff
    1ec0:      	b.ne	0x1f98 <generic_retuprobe_event+0x1f98>
    1ec4:      	mov	w8, #0x28               // =40
    1ec8:      	b	0x1ee4 <generic_retuprobe_event+0x1ee4>
    1ecc:      	ldrb	w8, [x25, #0x7]
    1ed0:      	lsl	w8, w8, #3
    1ed4:      	b	0x1ee0 <generic_retuprobe_event+0x1ee0>
    1ed8:      	ldrb	w8, [x25, #0x7]
    1edc:      	lsl	w8, w8, #2
    1ee0:      	add	w8, w8, #0x8
    1ee4:      	strh	w8, [x25, #0x2]
    1ee8:      	ldrh	w9, [x25]
    1eec:      	add	w9, w9, w8
    1ef0:      	ldrb	w8, [x25, #0x6]
    1ef4:      	strh	w9, [x25]
    1ef8:      	cmp	w8, #0x3c
    1efc:      	b.hi	0x1fb4 <generic_retuprobe_event+0x1fb4>
    1f00:      	mov	x21, #0x1               // =1
    1f04:      	mov	w10, #0x1               // =1
    1f08:      	movk	x21, #0x1800, lsl #32
    1f0c:      	lsl	x10, x10, x8
    1f10:      	movk	x21, #0x1008, lsl #48
    1f14:      	tst	x10, x21
    1f18:      	b.eq	0x1fb4 <generic_retuprobe_event+0x1fb4>
    1f1c:      	strb	w8, [x25, #0x5]
    1f20:      	add	x8, x23, w9, uxth
    1f24:      	mov	w9, #0x2                // =2
    1f28:      	mov	w10, #0x4               // =4
    1f2c:      	mov	x0, x29
    1f30:      	mov	w1, #0x2                // =2
    1f34:      	ldrh	w8, [x25]
    1f38:      	add	x2, x23, x8
    1f3c:      	blr	x10
    1f40:      	tbnz	x0, #0x3f, 0x243c <generic_retuprobe_event+0x243c>
    1f44:      	ldrb	w8, [x25, #0x5]
    1f48:      	cmp	w8, #0x32
    1f4c:      	b.gt	0x1f6c <generic_retuprobe_event+0x1f6c>
    1f50:      	cbz	w8, 0x1f8c <generic_retuprobe_event+0x1f8c>
    1f54:      	cmp	w8, #0x2b
    1f58:      	b.eq	0x1f8c <generic_retuprobe_event+0x1f8c>
    1f5c:      	cmp	w8, #0x2c
    1f60:      	b.ne	0x2070 <generic_retuprobe_event+0x2070>
    1f64:      	mov	w8, #0x8                // =8
    1f68:      	b	0x1fc8 <generic_retuprobe_event+0x1fc8>
    1f6c:      	cmp	w8, #0x33
    1f70:      	b.eq	0x1fbc <generic_retuprobe_event+0x1fbc>
    1f74:      	cmp	w8, #0x3c
    1f78:      	b.eq	0x1f8c <generic_retuprobe_event+0x1f8c>
    1f7c:      	cmp	w8, #0xff
    1f80:      	b.ne	0x2070 <generic_retuprobe_event+0x2070>
    1f84:      	mov	w8, #0x28               // =40
    1f88:      	b	0x1fc8 <generic_retuprobe_event+0x1fc8>
    1f8c:      	ldrb	w8, [x25, #0x7]
    1f90:      	lsl	w8, w8, #3
    1f94:      	b	0x1fc4 <generic_retuprobe_event+0x1fc4>
    1f98:      	ldrh	w8, [x25, #0x2]
    1f9c:      	ldrh	w9, [x25]
    1fa0:      	add	w9, w9, w8
    1fa4:      	ldrb	w8, [x25, #0x6]
    1fa8:      	strh	w9, [x25]
    1fac:      	cmp	w8, #0x3c
    1fb0:      	b.ls	0x1f00 <generic_retuprobe_event+0x1f00>
    1fb4:      	strh	w9, [sp, #0x98]
    1fb8:      	b	0x2440 <generic_retuprobe_event+0x2440>
    1fbc:      	ldrb	w8, [x25, #0x7]
    1fc0:      	lsl	w8, w8, #2
    1fc4:      	add	w8, w8, #0x8
    1fc8:      	strh	w8, [x25, #0x2]
    1fcc:      	ldrh	w9, [x25]
    1fd0:      	add	w9, w9, w8
    1fd4:      	ldrb	w8, [x25, #0x6]
    1fd8:      	strh	w9, [x25]
    1fdc:      	cmp	w8, #0x3c
    1fe0:      	b.hi	0x263c <generic_retuprobe_event+0x263c>
    1fe4:      	mov	w10, #0x1               // =1
    1fe8:      	lsl	x10, x10, x8
    1fec:      	tst	x10, x21
    1ff0:      	b.eq	0x263c <generic_retuprobe_event+0x263c>
    1ff4:      	strb	w8, [x25, #0x5]
    1ff8:      	add	x8, x23, w9, uxth
    1ffc:      	mov	w9, #0x2                // =2
    2000:      	mov	w10, #0x4               // =4
    2004:      	mov	x0, x29
    2008:      	mov	w1, #0x2                // =2
    200c:      	ldrh	w8, [x25]
    2010:      	add	x2, x23, x8
    2014:      	blr	x10
    2018:      	tbnz	x0, #0x3f, 0x243c <generic_retuprobe_event+0x243c>
    201c:      	ldrb	w8, [x25, #0x5]
    2020:      	cmp	w8, #0x32
    2024:      	b.gt	0x2044 <generic_retuprobe_event+0x2044>
    2028:      	cbz	w8, 0x2064 <generic_retuprobe_event+0x2064>
    202c:      	cmp	w8, #0x2b
    2030:      	b.eq	0x2064 <generic_retuprobe_event+0x2064>
    2034:      	cmp	w8, #0x2c
    2038:      	b.ne	0x2144 <generic_retuprobe_event+0x2144>
    203c:      	mov	w8, #0x8                // =8
    2040:      	b	0x209c <generic_retuprobe_event+0x209c>
    2044:      	cmp	w8, #0x33
    2048:      	b.eq	0x2090 <generic_retuprobe_event+0x2090>
    204c:      	cmp	w8, #0x3c
    2050:      	b.eq	0x2064 <generic_retuprobe_event+0x2064>
    2054:      	cmp	w8, #0xff
    2058:      	b.ne	0x2144 <generic_retuprobe_event+0x2144>
    205c:      	mov	w8, #0x28               // =40
    2060:      	b	0x209c <generic_retuprobe_event+0x209c>
    2064:      	ldrb	w8, [x25, #0x7]
    2068:      	lsl	w8, w8, #3
    206c:      	b	0x2098 <generic_retuprobe_event+0x2098>
    2070:      	ldrh	w8, [x25, #0x2]
    2074:      	ldrh	w9, [x25]
    2078:      	add	w9, w9, w8
    207c:      	ldrb	w8, [x25, #0x6]
    2080:      	strh	w9, [x25]
    2084:      	cmp	w8, #0x3c
    2088:      	b.ls	0x1fe4 <generic_retuprobe_event+0x1fe4>
    208c:      	b	0x263c <generic_retuprobe_event+0x263c>
    2090:      	ldrb	w8, [x25, #0x7]
    2094:      	lsl	w8, w8, #2
    2098:      	add	w8, w8, #0x8
    209c:      	strh	w8, [x25, #0x2]
    20a0:      	ldrh	w9, [x25]
    20a4:      	add	w9, w9, w8
    20a8:      	ldrb	w8, [x25, #0x6]
    20ac:      	strh	w9, [x25]
    20b0:      	cmp	w8, #0x3c
    20b4:      	b.hi	0x263c <generic_retuprobe_event+0x263c>
    20b8:      	mov	w10, #0x1               // =1
    20bc:      	lsl	x10, x10, x8
    20c0:      	tst	x10, x21
    20c4:      	b.eq	0x263c <generic_retuprobe_event+0x263c>
    20c8:      	strb	w8, [x25, #0x5]
    20cc:      	add	x8, x23, w9, uxth
    20d0:      	mov	w9, #0x2                // =2
    20d4:      	mov	w10, #0x4               // =4
    20d8:      	mov	x0, x29
    20dc:      	mov	w1, #0x2                // =2
    20e0:      	ldrh	w8, [x25]
    20e4:      	add	x2, x23, x8
    20e8:      	blr	x10
    20ec:      	tbnz	x0, #0x3f, 0x243c <generic_retuprobe_event+0x243c>
    20f0:      	ldrb	w8, [x25, #0x5]
    20f4:      	cmp	w8, #0x32
    20f8:      	b.gt	0x2118 <generic_retuprobe_event+0x2118>
    20fc:      	cbz	w8, 0x2138 <generic_retuprobe_event+0x2138>
    2100:      	cmp	w8, #0x2b
    2104:      	b.eq	0x2138 <generic_retuprobe_event+0x2138>
    2108:      	cmp	w8, #0x2c
    210c:      	b.ne	0x2218 <generic_retuprobe_event+0x2218>
    2110:      	mov	w8, #0x8                // =8
    2114:      	b	0x2170 <generic_retuprobe_event+0x2170>
    2118:      	cmp	w8, #0x33
    211c:      	b.eq	0x2164 <generic_retuprobe_event+0x2164>
    2120:      	cmp	w8, #0x3c
    2124:      	b.eq	0x2138 <generic_retuprobe_event+0x2138>
    2128:      	cmp	w8, #0xff
    212c:      	b.ne	0x2218 <generic_retuprobe_event+0x2218>
    2130:      	mov	w8, #0x28               // =40
    2134:      	b	0x2170 <generic_retuprobe_event+0x2170>
    2138:      	ldrb	w8, [x25, #0x7]
    213c:      	lsl	w8, w8, #3
    2140:      	b	0x216c <generic_retuprobe_event+0x216c>
    2144:      	ldrh	w8, [x25, #0x2]
    2148:      	ldrh	w9, [x25]
    214c:      	add	w9, w9, w8
    2150:      	ldrb	w8, [x25, #0x6]
    2154:      	strh	w9, [x25]
    2158:      	cmp	w8, #0x3c
    215c:      	b.ls	0x20b8 <generic_retuprobe_event+0x20b8>
    2160:      	b	0x263c <generic_retuprobe_event+0x263c>
    2164:      	ldrb	w8, [x25, #0x7]
    2168:      	lsl	w8, w8, #2
    216c:      	add	w8, w8, #0x8
    2170:      	strh	w8, [x25, #0x2]
    2174:      	ldrh	w9, [x25]
    2178:      	add	w9, w9, w8
    217c:      	ldrb	w8, [x25, #0x6]
    2180:      	strh	w9, [x25]
    2184:      	cmp	w8, #0x3c
    2188:      	b.hi	0x263c <generic_retuprobe_event+0x263c>
    218c:      	mov	w10, #0x1               // =1
    2190:      	lsl	x10, x10, x8
    2194:      	tst	x10, x21
    2198:      	b.eq	0x263c <generic_retuprobe_event+0x263c>
    219c:      	strb	w8, [x25, #0x5]
    21a0:      	add	x8, x23, w9, uxth
    21a4:      	mov	w9, #0x2                // =2
    21a8:      	mov	w10, #0x4               // =4
    21ac:      	mov	x0, x29
    21b0:      	mov	w1, #0x2                // =2
    21b4:      	ldrh	w8, [x25]
    21b8:      	add	x2, x23, x8
    21bc:      	blr	x10
    21c0:      	tbnz	x0, #0x3f, 0x243c <generic_retuprobe_event+0x243c>
    21c4:      	ldrb	w8, [x25, #0x5]
    21c8:      	cmp	w8, #0x32
    21cc:      	b.gt	0x21ec <generic_retuprobe_event+0x21ec>
    21d0:      	cbz	w8, 0x220c <generic_retuprobe_event+0x220c>
    21d4:      	cmp	w8, #0x2b
    21d8:      	b.eq	0x220c <generic_retuprobe_event+0x220c>
    21dc:      	cmp	w8, #0x2c
    21e0:      	b.ne	0x22ec <generic_retuprobe_event+0x22ec>
    21e4:      	mov	w8, #0x8                // =8
    21e8:      	b	0x2244 <generic_retuprobe_event+0x2244>
    21ec:      	cmp	w8, #0x33
    21f0:      	b.eq	0x2238 <generic_retuprobe_event+0x2238>
    21f4:      	cmp	w8, #0x3c
    21f8:      	b.eq	0x220c <generic_retuprobe_event+0x220c>
    21fc:      	cmp	w8, #0xff
    2200:      	b.ne	0x22ec <generic_retuprobe_event+0x22ec>
    2204:      	mov	w8, #0x28               // =40
    2208:      	b	0x2244 <generic_retuprobe_event+0x2244>
    220c:      	ldrb	w8, [x25, #0x7]
    2210:      	lsl	w8, w8, #3
    2214:      	b	0x2240 <generic_retuprobe_event+0x2240>
    2218:      	ldrh	w8, [x25, #0x2]
    221c:      	ldrh	w9, [x25]
    2220:      	add	w9, w9, w8
    2224:      	ldrb	w8, [x25, #0x6]
    2228:      	strh	w9, [x25]
    222c:      	cmp	w8, #0x3c
    2230:      	b.ls	0x218c <generic_retuprobe_event+0x218c>
    2234:      	b	0x263c <generic_retuprobe_event+0x263c>
    2238:      	ldrb	w8, [x25, #0x7]
    223c:      	lsl	w8, w8, #2
    2240:      	add	w8, w8, #0x8
    2244:      	strh	w8, [x25, #0x2]
    2248:      	ldrh	w9, [x25]
    224c:      	add	w9, w9, w8
    2250:      	ldrb	w8, [x25, #0x6]
    2254:      	strh	w9, [x25]
    2258:      	cmp	w8, #0x3c
    225c:      	b.hi	0x263c <generic_retuprobe_event+0x263c>
    2260:      	mov	w10, #0x1               // =1
    2264:      	lsl	x10, x10, x8
    2268:      	tst	x10, x21
    226c:      	b.eq	0x263c <generic_retuprobe_event+0x263c>
    2270:      	strb	w8, [x25, #0x5]
    2274:      	add	x8, x23, w9, uxth
    2278:      	mov	w9, #0x2                // =2
    227c:      	mov	w10, #0x4               // =4
    2280:      	mov	x0, x29
    2284:      	mov	w1, #0x2                // =2
    2288:      	ldrh	w8, [x25]
    228c:      	add	x2, x23, x8
    2290:      	blr	x10
    2294:      	tbnz	x0, #0x3f, 0x243c <generic_retuprobe_event+0x243c>
    2298:      	ldrb	w8, [x25, #0x5]
    229c:      	cmp	w8, #0x32
    22a0:      	b.gt	0x22c0 <generic_retuprobe_event+0x22c0>
    22a4:      	cbz	w8, 0x22e0 <generic_retuprobe_event+0x22e0>
    22a8:      	cmp	w8, #0x2b
    22ac:      	b.eq	0x22e0 <generic_retuprobe_event+0x22e0>
    22b0:      	cmp	w8, #0x2c
    22b4:      	b.ne	0x23c0 <generic_retuprobe_event+0x23c0>
    22b8:      	mov	w8, #0x8                // =8
    22bc:      	b	0x2318 <generic_retuprobe_event+0x2318>
    22c0:      	cmp	w8, #0x33
    22c4:      	b.eq	0x230c <generic_retuprobe_event+0x230c>
    22c8:      	cmp	w8, #0x3c
    22cc:      	b.eq	0x22e0 <generic_retuprobe_event+0x22e0>
    22d0:      	cmp	w8, #0xff
    22d4:      	b.ne	0x23c0 <generic_retuprobe_event+0x23c0>
    22d8:      	mov	w8, #0x28               // =40
    22dc:      	b	0x2318 <generic_retuprobe_event+0x2318>
    22e0:      	ldrb	w8, [x25, #0x7]
    22e4:      	lsl	w8, w8, #3
    22e8:      	b	0x2314 <generic_retuprobe_event+0x2314>
    22ec:      	ldrh	w8, [x25, #0x2]
    22f0:      	ldrh	w9, [x25]
    22f4:      	add	w9, w9, w8
    22f8:      	ldrb	w8, [x25, #0x6]
    22fc:      	strh	w9, [x25]
    2300:      	cmp	w8, #0x3c
    2304:      	b.ls	0x2260 <generic_retuprobe_event+0x2260>
    2308:      	b	0x263c <generic_retuprobe_event+0x263c>
    230c:      	ldrb	w8, [x25, #0x7]
    2310:      	lsl	w8, w8, #2
    2314:      	add	w8, w8, #0x8
    2318:      	strh	w8, [x25, #0x2]
    231c:      	ldrh	w9, [x25]
    2320:      	add	w9, w9, w8
    2324:      	ldrb	w8, [x25, #0x6]
    2328:      	strh	w9, [x25]
    232c:      	cmp	w8, #0x3c
    2330:      	b.hi	0x263c <generic_retuprobe_event+0x263c>
    2334:      	mov	w10, #0x1               // =1
    2338:      	lsl	x10, x10, x8
    233c:      	tst	x10, x21
    2340:      	b.eq	0x263c <generic_retuprobe_event+0x263c>
    2344:      	strb	w8, [x25, #0x5]
    2348:      	add	x8, x23, w9, uxth
    234c:      	mov	w9, #0x2                // =2
    2350:      	mov	w10, #0x4               // =4
    2354:      	mov	x0, x29
    2358:      	mov	w1, #0x2                // =2
    235c:      	ldrh	w8, [x25]
    2360:      	add	x2, x23, x8
    2364:      	blr	x10
    2368:      	tbnz	x0, #0x3f, 0x243c <generic_retuprobe_event+0x243c>
    236c:      	ldrb	w8, [x25, #0x5]
    2370:      	cmp	w8, #0x32
    2374:      	b.gt	0x2394 <generic_retuprobe_event+0x2394>
    2378:      	cbz	w8, 0x23b4 <generic_retuprobe_event+0x23b4>
    237c:      	cmp	w8, #0x2b
    2380:      	b.eq	0x23b4 <generic_retuprobe_event+0x23b4>
    2384:      	cmp	w8, #0x2c
    2388:      	b.ne	0x2620 <generic_retuprobe_event+0x2620>
    238c:      	mov	w8, #0x8                // =8
    2390:      	b	0x23ec <generic_retuprobe_event+0x23ec>
    2394:      	cmp	w8, #0x33
    2398:      	b.eq	0x23e0 <generic_retuprobe_event+0x23e0>
    239c:      	cmp	w8, #0x3c
    23a0:      	b.eq	0x23b4 <generic_retuprobe_event+0x23b4>
    23a4:      	cmp	w8, #0xff
    23a8:      	b.ne	0x2620 <generic_retuprobe_event+0x2620>
    23ac:      	mov	w8, #0x28               // =40
    23b0:      	b	0x23ec <generic_retuprobe_event+0x23ec>
    23b4:      	ldrb	w8, [x25, #0x7]
    23b8:      	lsl	w8, w8, #3
    23bc:      	b	0x23e8 <generic_retuprobe_event+0x23e8>
    23c0:      	ldrh	w8, [x25, #0x2]
    23c4:      	ldrh	w9, [x25]
    23c8:      	add	w9, w9, w8
    23cc:      	ldrb	w8, [x25, #0x6]
    23d0:      	strh	w9, [x25]
    23d4:      	cmp	w8, #0x3c
    23d8:      	b.ls	0x2334 <generic_retuprobe_event+0x2334>
    23dc:      	b	0x263c <generic_retuprobe_event+0x263c>
    23e0:      	ldrb	w8, [x25, #0x7]
    23e4:      	lsl	w8, w8, #2
    23e8:      	add	w8, w8, #0x8
    23ec:      	strh	w8, [x25, #0x2]
    23f0:      	ldrh	w9, [x25]
    23f4:      	add	w9, w9, w8
    23f8:      	ldrb	w8, [x25, #0x6]
    23fc:      	strh	w9, [x25]
    2400:      	cmp	w8, #0x3c
    2404:      	b.hi	0x263c <generic_retuprobe_event+0x263c>
    2408:      	mov	w10, #0x1               // =1
    240c:      	lsl	x10, x10, x8
    2410:      	tst	x10, x21
    2414:      	b.eq	0x263c <generic_retuprobe_event+0x263c>
    2418:      	strb	w8, [x25, #0x5]
    241c:      	add	x8, x23, w9, uxth
    2420:      	mov	w9, #0x2                // =2
    2424:      	mov	w10, #0x4               // =4
    2428:      	mov	x0, x29
    242c:      	mov	w1, #0x2                // =2
    2430:      	ldrh	w8, [x25]
    2434:      	add	x2, x23, x8
    2438:      	blr	x10
    243c:      	mov	w8, wzr
    2440:      	ldr	x21, [sp, #0x48]
    2444:      	strb	w8, [sp, #0x90]
    2448:      	add	x2, x22, #0x8
    244c:      	mov	w23, #0x10              // =16
    2450:      	mov	w1, #0x10               // =16
    2454:      	mov	w25, #0x4               // =4
    2458:      	ldr	x0, [sp, #0x28]
    245c:      	strh	w8, [x21, #0xc0]
    2460:      	mov	w8, #0xa                // =10
    2464:      	strh	w8, [x21, #0xc2]
    2468:      	mov	w8, #0x4                // =4
    246c:      	blr	x8
    2470:      	add	x0, x21, #0xac
    2474:      	add	x2, x22, #0x18
    2478:      	mov	w1, #0x10               // =16
    247c:      	blr	x25
    2480:      	ldrb	w8, [sp, #0x90]
    2484:      	cmp	w8, #0x11
    2488:      	b.eq	0x24cc <generic_retuprobe_event+0x24cc>
    248c:      	cmp	w8, #0x6
    2490:      	b.ne	0x250c <generic_retuprobe_event+0x250c>
    2494:      	ldr	x8, [sp, #0xa0]
    2498:      	ldrh	w9, [sp, #0x98]
    249c:      	mov	w23, #0x2               // =2
    24a0:      	mov	w1, #0x2                // =2
    24a4:      	mov	w25, #0x4               // =4
    24a8:      	add	x22, x8, x9
    24ac:      	ldr	x21, [sp, #0x48]
    24b0:      	add	x0, x21, #0xbc
    24b4:      	mov	w8, #0x4                // =4
    24b8:      	mov	x2, x22
    24bc:      	blr	x8
    24c0:      	add	x0, x21, #0xbe
    24c4:      	add	x2, x22, #0x2
    24c8:      	b	0x2500 <generic_retuprobe_event+0x2500>
    24cc:      	ldr	x8, [sp, #0xa0]
    24d0:      	ldrh	w9, [sp, #0x98]
    24d4:      	mov	w23, #0x2               // =2
    24d8:      	mov	w1, #0x2                // =2
    24dc:      	mov	w25, #0x4               // =4
    24e0:      	add	x22, x8, x9
    24e4:      	ldr	x21, [sp, #0x48]
    24e8:      	add	x0, x21, #0xbc
    24ec:      	mov	w8, #0x4                // =4
    24f0:      	mov	x2, x22
    24f4:      	blr	x8
    24f8:      	add	x0, x21, #0xbe
    24fc:      	add	x2, x22, #0x2
    2500:      	mov	w1, #0x2                // =2
    2504:      	blr	x25
    2508:      	b	0x2514 <generic_retuprobe_event+0x2514>
    250c:      	ldr	x8, [sp, #0x48]
    2510:      	str	wzr, [x8, #0xbc]
    2514:      	ldr	x8, [sp, #0x48]
    2518:      	add	x2, x24, #0xe0
    251c:      	add	x10, sp, #0xf0
    2520:      	add	x0, sp, #0xf0
    2524:      	ldrh	w9, [x8, #0xbc]
    2528:      	mov	w1, #0x8                // =8
    252c:      	rev	w9, w9
    2530:      	lsr	w9, w9, #16
    2534:      	strh	w9, [x8, #0xbc]
    2538:      	ldrh	w9, [x8, #0xbe]
    253c:      	rev	w9, w9
    2540:      	lsr	w9, w9, #16
    2544:      	strh	w9, [x8, #0xbe]
    2548:      	mov	w8, #0x8                // =8
    254c:      	mov	w9, #0x4                // =4
    2550:      	blr	x9
    2554:      	ldr	x8, [sp, #0xf0]
    2558:      	cbz	x8, 0x25b8 <generic_retuprobe_event+0x25b8>
    255c:      	add	x8, x8, #0x5
    2560:      	mov	w9, #0x8                // =8
    2564:      	add	x10, sp, #0x78
    2568:      	mov	w11, #0x4               // =4
    256c:      	ldr	x8, [sp, #0xf0]
    2570:      	add	x0, sp, #0x78
    2574:      	mov	w1, #0x8                // =8
    2578:      	mov	w21, #0x4               // =4
    257c:      	add	x2, x8, #0x5
    2580:      	blr	x11
    2584:      	ldr	x8, [sp, #0xf0]
    2588:      	ldr	x9, [sp, #0x78]
    258c:      	mov	w1, #0x4                // =4
    2590:      	add	x22, x8, x9, lsl #3
    2594:      	ldr	x23, [sp, #0x48]
    2598:      	add	x0, x23, #0xd4
    259c:      	mov	w8, #0x4                // =4
    25a0:      	add	x2, x22, #0x44
    25a4:      	blr	x8
    25a8:      	add	x0, x23, #0xd8
    25ac:      	add	x2, x22, #0x45
    25b0:      	mov	w1, #0x4                // =4
    25b4:      	blr	x21
    25b8:      	ldr	x22, [sp, #0x20]
    25bc:      	mov	w21, #0x40              // =64
    25c0:      	mov	w10, #0x5ea0            // =24224
    25c4:      	ldr	x29, [sp, #0x30]
    25c8:      	tbnz	w21, #0x1f, 0x25f0 <generic_retuprobe_event+0x25f0>
    25cc:      	and	x8, x21, #0x7fffffff
    25d0:      	mov	x25, x29
    25d4:      	add	x8, x8, #0x4
    25d8:      	ldr	w21, [sp, #0x50]
    25dc:      	add	w8, w8, #0x8
    25e0:      	and	x29, x8, #0x1fff
    25e4:      	cmp	w21, #0x3
    25e8:      	b.ne	0x1cc <generic_retuprobe_event+0x1cc>
    25ec:      	b	0x164 <generic_retuprobe_event+0x164>
    25f0:      	ldr	x9, [sp, #0x48]
    25f4:      	mov	w8, #-0x1               // =-1
    25f8:      	mov	x25, x29
    25fc:      	str	w8, [x9, x10]
    2600:      	str	w8, [x9, #0x98]
    2604:      	mov	w8, #0x4                // =4
    2608:      	ldr	w21, [sp, #0x50]
    260c:      	add	w8, w8, #0x8
    2610:      	and	x29, x8, #0x1fff
    2614:      	cmp	w21, #0x3
    2618:      	b.ne	0x1cc <generic_retuprobe_event+0x1cc>
    261c:      	b	0x164 <generic_retuprobe_event+0x164>
    2620:      	ldrh	w8, [x25, #0x2]
    2624:      	ldrh	w9, [x25]
    2628:      	add	w9, w9, w8
    262c:      	ldrb	w8, [x25, #0x6]
    2630:      	strh	w9, [x25]
    2634:      	cmp	w8, #0x3c
    2638:      	b.ls	0x2408 <generic_retuprobe_event+0x2408>
    263c:      	strh	w9, [sp, #0x98]
    2640:      	b	0x2440 <generic_retuprobe_event+0x2440>
