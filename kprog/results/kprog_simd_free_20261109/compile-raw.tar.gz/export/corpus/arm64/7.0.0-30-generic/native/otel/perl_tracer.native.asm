
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/otel/perl_tracer.native.o:	file format elf64-littleaarch64

Disassembly of section perf_event/unwind_perl:

0000000000000000 <perf_unwind_perl>:
       0:      	sub	sp, sp, #0x100
       4:      	str	x29, [sp, #0xb0]
       8:      	stp	x30, x25, [sp, #0xc0]
       c:      	stp	x24, x23, [sp, #0xd0]
      10:      	stp	x22, x21, [sp, #0xe0]
      14:      	stp	x20, x19, [sp, #0xf0]
      18:      	str	wzr, [sp, #0x30]
      1c:      	adrp	x20, 0x0 <perf_unwind_perl>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x30
      28:      	ldr	x20, [x20]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0x30
      34:      	mov	x0, x20
      38:      	blr	x8
      3c:      	cbz	x0, 0x58e0 <perf_unwind_perl+0x58e0>
      40:      	ldr	w8, [x0]
      44:      	adrp	x23, 0x0 <perf_unwind_perl>
      48:      	mov	x21, x0
      4c:      	str	w8, [sp, #0x2c]
      50:      	ldr	x23, [x23]
      54:      	ldr	w8, [x23]
      58:      	cbnz	w8, 0x49c <perf_unwind_perl+0x49c>
      5c:      	adrp	x0, 0x0 <perf_unwind_perl>
      60:      	mov	w8, #0x1                // =1
      64:      	add	x9, sp, #0x2c
      68:      	ldr	x0, [x0]
      6c:      	add	x1, sp, #0x2c
      70:      	blr	x8
      74:      	ldr	w8, [x23]
      78:      	cbz	x0, 0xb4 <perf_unwind_perl+0xb4>
      7c:      	mov	x22, x0
      80:      	cbnz	w8, 0x4d0 <perf_unwind_perl+0x4d0>
      84:      	ldr	x8, [x21, #0xf28]
      88:      	add	x29, x21, #0xf28
      8c:      	cbz	x8, 0x518 <perf_unwind_perl+0x518>
      90:      	str	x8, [sp, #0x68]
      94:      	ldr	x9, [x21, #0xf38]
      98:      	ldr	x25, [x21, #0xf40]
      9c:      	add	x24, x21, #0xf30
      a0:      	cmp	x25, x9
      a4:      	str	x29, [sp, #0x20]
      a8:      	b.hs	0xc0 <perf_unwind_perl+0xc0>
      ac:      	mov	w29, #0x3               // =3
      b0:      	b	0x563c <perf_unwind_perl+0x563c>
      b4:      	cbnz	w8, 0xa14 <perf_unwind_perl+0xa14>
      b8:      	mov	w0, wzr
      bc:      	b	0x58e4 <perf_unwind_perl+0x58e4>
      c0:      	ldrb	w8, [x22, #0x19]
      c4:      	str	x9, [sp, #0x18]
      c8:      	mov	w9, #0x1                // =1
      cc:      	mov	w10, #0x70              // =112
      d0:      	add	x11, sp, #0x7c
      d4:      	add	x0, sp, #0x7c
      d8:      	mov	w1, #0x1                // =1
      dc:      	add	x8, x25, x8
      e0:      	ldrb	w8, [x22, #0x19]
      e4:      	add	x2, x25, x8
      e8:      	blr	x10
      ec:      	cbz	x0, 0x12c <perf_unwind_perl+0x12c>
      f0:      	ldr	w8, [x23]
      f4:      	cbnz	w8, 0xa58 <perf_unwind_perl+0xa58>
      f8:      	mov	w8, #0x13               // =19
      fc:      	adrp	x0, 0x0 <perf_unwind_perl>
     100:      	add	x9, sp, #0xa8
     104:      	str	w8, [sp, #0xa8]
     108:      	mov	w8, #0x1                // =1
     10c:      	add	x1, sp, #0xa8
     110:      	ldr	x0, [x0]
     114:      	blr	x8
     118:      	cbz	x0, 0x22c <perf_unwind_perl+0x22c>
     11c:      	ldr	x8, [x0]
     120:      	add	x8, x8, #0x1
     124:      	str	x8, [x0]
     128:      	b	0xc40 <perf_unwind_perl+0xc40>
     12c:      	ldr	w8, [x23]
     130:      	cbnz	w8, 0xbf0 <perf_unwind_perl+0xbf0>
     134:      	ldrb	w8, [sp, #0x7c]
     138:      	and	w9, w8, #0xf
     13c:      	sub	w10, w9, #0x9
     140:      	cmp	w10, #0x2
     144:      	b.hs	0xc38 <perf_unwind_perl+0xc38>
     148:      	sxtb	w8, w8
     14c:      	tbnz	w8, #0x1f, 0xc40 <perf_unwind_perl+0xc40>
     150:      	ldrb	w8, [x22, #0x1b]
     154:      	mov	w9, #0x8                // =8
     158:      	mov	w10, #0x70              // =112
     15c:      	add	x11, sp, #0x30
     160:      	add	x0, sp, #0x30
     164:      	mov	w1, #0x8                // =8
     168:      	add	x8, x25, x8
     16c:      	ldrb	w8, [x22, #0x1b]
     170:      	add	x2, x25, x8
     174:      	blr	x10
     178:      	cbnz	x0, 0xf0 <perf_unwind_perl+0xf0>
     17c:      	ldr	x8, [sp, #0x30]
     180:      	mov	w9, #0x8                // =8
     184:      	mov	w10, #0x70              // =112
     188:      	add	x11, sp, #0x70
     18c:      	add	x0, sp, #0x70
     190:      	mov	w1, #0x8                // =8
     194:      	cmp	x8, #0x0
     198:      	mov	w8, #0x3                // =3
     19c:      	csinc	w29, w8, wzr, ne
     1a0:      	ldrb	w8, [x22, #0x1c]
     1a4:      	add	x8, x25, x8
     1a8:      	ldrb	w8, [x22, #0x1c]
     1ac:      	add	x2, x25, x8
     1b0:      	blr	x10
     1b4:      	cbnz	x0, 0xf0 <perf_unwind_perl+0xf0>
     1b8:      	str	x24, [sp, #0x10]
     1bc:      	ldr	x24, [sp, #0x70]
     1c0:      	mov	w9, #0x4                // =4
     1c4:      	mov	w10, #0x70              // =112
     1c8:      	add	x11, sp, #0xb8
     1cc:      	add	x0, sp, #0xb8
     1d0:      	ldrb	w8, [x22, #0x1e]
     1d4:      	mov	w1, #0x4                // =4
     1d8:      	add	x8, x24, x8
     1dc:      	ldrb	w8, [x22, #0x1e]
     1e0:      	add	x2, x24, x8
     1e4:      	blr	x10
     1e8:      	cbz	x0, 0x27c <perf_unwind_perl+0x27c>
     1ec:      	ldr	w8, [x23]
     1f0:      	cbnz	w8, 0x1eac <perf_unwind_perl+0x1eac>
     1f4:      	mov	w8, #0x14               // =20
     1f8:      	adrp	x0, 0x0 <perf_unwind_perl>
     1fc:      	add	x9, sp, #0xbc
     200:      	str	w8, [sp, #0xbc]
     204:      	mov	w8, #0x1                // =1
     208:      	add	x1, sp, #0xbc
     20c:      	ldr	x0, [x0]
     210:      	blr	x8
     214:      	ldr	x24, [sp, #0x10]
     218:      	cbz	x0, 0x404 <perf_unwind_perl+0x404>
     21c:      	ldr	x8, [x0]
     220:      	add	x8, x8, #0x1
     224:      	str	x8, [x0]
     228:      	b	0xf0 <perf_unwind_perl+0xf0>
     22c:      	ldr	w8, [x23]
     230:      	cbz	w8, 0xc40 <perf_unwind_perl+0xc40>
     234:      	adrp	x8, 0x0 <perf_unwind_perl>
     238:      	add	x8, x8, #0x0
     23c:      	add	x0, sp, #0x30
     240:      	ldp	x9, x10, [x8, #0x10]
     244:      	mov	w1, #0x2e               // =46
     248:      	stp	x9, x10, [sp, #0x40]
     24c:      	ldr	x9, [x8, #0x20]
     250:      	add	x10, sp, #0x30
     254:      	str	x9, [sp, #0x50]
     258:      	ldur	x9, [x8, #0x26]
     25c:      	stur	x9, [sp, #0x56]
     260:      	ldp	x9, x8, [x8]
     264:      	stp	x9, x8, [sp, #0x30]
     268:      	mov	w8, #0x2e               // =46
     26c:      	mov	w9, #0x6                // =6
     270:      	ldr	w2, [sp, #0xa8]
     274:      	blr	x9
     278:      	b	0xc40 <perf_unwind_perl+0xc40>
     27c:      	ldr	w8, [sp, #0xb8]
     280:      	and	w8, w8, #0x1f
     284:      	cmp	w8, #0xd
     288:      	b.ne	0x450 <perf_unwind_perl+0x450>
     28c:      	ldrb	w8, [x22, #0x1f]
     290:      	mov	w9, #0x8                // =8
     294:      	mov	w10, #0x70              // =112
     298:      	add	x11, sp, #0xa8
     29c:      	add	x0, sp, #0xa8
     2a0:      	mov	w1, #0x8                // =8
     2a4:      	add	x8, x24, x8
     2a8:      	ldrb	w8, [x22, #0x1f]
     2ac:      	add	x2, x24, x8
     2b0:      	blr	x10
     2b4:      	cbnz	x0, 0x1ec <perf_unwind_perl+0x1ec>
     2b8:      	ldr	x8, [sp, #0xa8]
     2bc:      	ldrb	w9, [x22, #0x21]
     2c0:      	mov	w10, #0x70              // =112
     2c4:      	add	x11, sp, #0xa4
     2c8:      	add	x0, sp, #0xa4
     2cc:      	mov	w1, #0x4                // =4
     2d0:      	add	x8, x8, x9
     2d4:      	mov	w9, #0x4                // =4
     2d8:      	ldr	x8, [sp, #0xa8]
     2dc:      	ldrb	w9, [x22, #0x21]
     2e0:      	add	x2, x8, x9
     2e4:      	blr	x10
     2e8:      	cbnz	x0, 0x1ec <perf_unwind_perl+0x1ec>
     2ec:      	ldrb	w8, [sp, #0xa5]
     2f0:      	tbnz	w8, #0x7, 0xb64 <perf_unwind_perl+0xb64>
     2f4:      	ldr	x8, [sp, #0xa8]
     2f8:      	ldrb	w9, [x22, #0x22]
     2fc:      	mov	w10, #0x70              // =112
     300:      	add	x11, sp, #0x98
     304:      	add	x0, sp, #0x98
     308:      	mov	w1, #0x8                // =8
     30c:      	add	x8, x8, x9
     310:      	mov	w9, #0x8                // =8
     314:      	ldr	x8, [sp, #0xa8]
     318:      	ldrb	w9, [x22, #0x22]
     31c:      	add	x2, x8, x9
     320:      	blr	x10
     324:      	cbnz	x0, 0x1ec <perf_unwind_perl+0x1ec>
     328:      	ldr	x8, [sp, #0x98]
     32c:      	cbz	x8, 0x1ec <perf_unwind_perl+0x1ec>
     330:      	ldr	w9, [x23]
     334:      	cbnz	w9, 0x3538 <perf_unwind_perl+0x3538>
     338:      	ldrb	w9, [x22, #0x1e]
     33c:      	mov	w10, #0x70              // =112
     340:      	add	x11, sp, #0x94
     344:      	add	x0, sp, #0x94
     348:      	mov	w1, #0x4                // =4
     34c:      	add	x8, x8, x9
     350:      	mov	w9, #0x4                // =4
     354:      	ldr	x8, [sp, #0x98]
     358:      	ldrb	w9, [x22, #0x1e]
     35c:      	add	x2, x8, x9
     360:      	blr	x10
     364:      	cbnz	x0, 0x1ec <perf_unwind_perl+0x1ec>
     368:      	ldr	w8, [sp, #0x94]
     36c:      	mov	w9, #0x801f             // =32799
     370:      	and	w8, w8, w9
     374:      	mov	w9, #0x8009             // =32777
     378:      	cmp	w8, w9
     37c:      	b.ne	0x18ac <perf_unwind_perl+0x18ac>
     380:      	ldr	x8, [sp, #0x98]
     384:      	ldrb	w9, [x22, #0x20]
     388:      	mov	w10, #0x70              // =112
     38c:      	add	x11, sp, #0x88
     390:      	add	x0, sp, #0x88
     394:      	mov	w1, #0x8                // =8
     398:      	add	x8, x8, x9
     39c:      	mov	w9, #0x8                // =8
     3a0:      	ldr	x8, [sp, #0x98]
     3a4:      	ldrb	w9, [x22, #0x20]
     3a8:      	add	x2, x8, x9
     3ac:      	blr	x10
     3b0:      	cbnz	x0, 0x1ec <perf_unwind_perl+0x1ec>
     3b4:      	ldr	x8, [sp, #0x88]
     3b8:      	ldrb	w9, [x22, #0x23]
     3bc:      	mov	w10, #0x70              // =112
     3c0:      	add	x11, sp, #0x80
     3c4:      	add	x0, sp, #0x80
     3c8:      	mov	w1, #0x8                // =8
     3cc:      	add	x8, x8, x9
     3d0:      	mov	w9, #0x8                // =8
     3d4:      	ldr	x8, [sp, #0x88]
     3d8:      	ldrb	w9, [x22, #0x23]
     3dc:      	add	x2, x8, x9
     3e0:      	blr	x10
     3e4:      	cbnz	x0, 0x1ec <perf_unwind_perl+0x1ec>
     3e8:      	ldr	x8, [sp, #0x80]
     3ec:      	str	x8, [sp, #0x8]
     3f0:      	cbz	x8, 0x2654 <perf_unwind_perl+0x2654>
     3f4:      	ldr	w8, [x23]
     3f8:      	cbnz	w8, 0x4c34 <perf_unwind_perl+0x4c34>
     3fc:      	ldr	x24, [sp, #0x10]
     400:      	b	0x2668 <perf_unwind_perl+0x2668>
     404:      	ldr	w8, [x23]
     408:      	cbz	w8, 0xf0 <perf_unwind_perl+0xf0>
     40c:      	adrp	x8, 0x0 <perf_unwind_perl>
     410:      	add	x8, x8, #0x0
     414:      	add	x0, sp, #0x30
     418:      	ldp	x9, x10, [x8, #0x10]
     41c:      	mov	w1, #0x2e               // =46
     420:      	stp	x9, x10, [sp, #0x40]
     424:      	ldr	x9, [x8, #0x20]
     428:      	add	x10, sp, #0x30
     42c:      	str	x9, [sp, #0x50]
     430:      	ldur	x9, [x8, #0x26]
     434:      	stur	x9, [sp, #0x56]
     438:      	ldp	x9, x8, [x8]
     43c:      	stp	x9, x8, [sp, #0x30]
     440:      	mov	w8, #0x2e               // =46
     444:      	mov	w9, #0x6                // =6
     448:      	ldr	w2, [sp, #0xbc]
     44c:      	b	0x494 <perf_unwind_perl+0x494>
     450:      	ldr	w8, [x23]
     454:      	ldr	x24, [sp, #0x10]
     458:      	cbz	w8, 0xf0 <perf_unwind_perl+0xf0>
     45c:      	adrp	x8, 0x0 <perf_unwind_perl>
     460:      	add	x8, x8, #0x0
     464:      	add	x0, sp, #0x30
     468:      	ldp	x9, x10, [x8]
     46c:      	mov	w1, #0x1e               // =30
     470:      	stp	x9, x10, [sp, #0x30]
     474:      	ldr	x9, [x8, #0x10]
     478:      	ldur	x8, [x8, #0x16]
     47c:      	add	x10, sp, #0x30
     480:      	str	x9, [sp, #0x40]
     484:      	stur	x8, [sp, #0x46]
     488:      	mov	w8, #0x1e               // =30
     48c:      	mov	w9, #0x6                // =6
     490:      	ldr	w2, [sp, #0xb8]
     494:      	blr	x9
     498:      	b	0xf0 <perf_unwind_perl+0xf0>
     49c:      	adrp	x8, 0x0 <perf_unwind_perl>
     4a0:      	add	x8, x8, #0x0
     4a4:      	add	x10, sp, #0x30
     4a8:      	ldr	x9, [x8]
     4ac:      	ldur	x8, [x8, #0x7]
     4b0:      	add	x0, sp, #0x30
     4b4:      	mov	w1, #0xf                // =15
     4b8:      	str	x9, [sp, #0x30]
     4bc:      	stur	x8, [sp, #0x37]
     4c0:      	mov	w8, #0xf                // =15
     4c4:      	mov	w9, #0x6                // =6
     4c8:      	blr	x9
     4cc:      	b	0x5c <perf_unwind_perl+0x5c>
     4d0:      	adrp	x8, 0x0 <perf_unwind_perl>
     4d4:      	add	x8, x8, #0x0
     4d8:      	add	x0, sp, #0x30
     4dc:      	ldp	x9, x10, [x8]
     4e0:      	mov	w1, #0x1e               // =30
     4e4:      	stp	x9, x10, [sp, #0x30]
     4e8:      	ldr	x9, [x8, #0x10]
     4ec:      	ldur	x8, [x8, #0x16]
     4f0:      	add	x10, sp, #0x30
     4f4:      	str	x9, [sp, #0x40]
     4f8:      	stur	x8, [sp, #0x46]
     4fc:      	mov	w8, #0x1e               // =30
     500:      	mov	w9, #0x6                // =6
     504:      	ldr	w2, [x22, #0x8]
     508:      	blr	x9
     50c:      	ldr	x8, [x21, #0xf28]
     510:      	add	x29, x21, #0xf28
     514:      	cbnz	x8, 0x90 <perf_unwind_perl+0x90>
     518:      	mov	w8, #0xf                // =15
     51c:      	adrp	x24, 0x0 <perf_unwind_perl>
     520:      	add	x9, sp, #0xa8
     524:      	str	w8, [sp, #0xa8]
     528:      	mov	w8, #0x1                // =1
     52c:      	add	x1, sp, #0xa8
     530:      	ldr	x24, [x24]
     534:      	mov	x0, x24
     538:      	blr	x8
     53c:      	cbz	x0, 0x630 <perf_unwind_perl+0x630>
     540:      	ldr	x8, [x0]
     544:      	add	x8, x8, #0x1
     548:      	str	x8, [x0]
     54c:      	ldrb	w8, [x22, #0x14]
     550:      	cbnz	w8, 0x640 <perf_unwind_perl+0x640>
     554:      	ldr	x8, [x22]
     558:      	str	x8, [sp, #0x98]
     55c:      	ldr	w8, [x23]
     560:      	cbnz	w8, 0xaa0 <perf_unwind_perl+0xaa0>
     564:      	ldr	x8, [sp, #0x98]
     568:      	ldrh	w9, [x22, #0x12]
     56c:      	mov	w10, #0x70              // =112
     570:      	mov	x0, x29
     574:      	mov	w1, #0x8                // =8
     578:      	add	x8, x8, x9
     57c:      	mov	w9, #0x8                // =8
     580:      	ldr	x8, [sp, #0x98]
     584:      	ldrh	w9, [x22, #0x12]
     588:      	add	x2, x8, x9
     58c:      	blr	x10
     590:      	cbnz	x0, 0x5c8 <perf_unwind_perl+0x5c8>
     594:      	ldr	x8, [sp, #0x98]
     598:      	ldrh	w9, [x22, #0x10]
     59c:      	add	x25, x21, #0xf30
     5a0:      	mov	w10, #0x70              // =112
     5a4:      	mov	w1, #0x8                // =8
     5a8:      	mov	x0, x25
     5ac:      	add	x8, x8, x9
     5b0:      	mov	w9, #0x8                // =8
     5b4:      	ldr	x8, [sp, #0x98]
     5b8:      	ldrh	w9, [x22, #0x10]
     5bc:      	add	x2, x8, x9
     5c0:      	blr	x10
     5c4:      	cbz	x0, 0x854 <perf_unwind_perl+0x854>
     5c8:      	ldr	w8, [x23]
     5cc:      	cbnz	w8, 0xbb4 <perf_unwind_perl+0xbb4>
     5d0:      	mov	w8, #0x12               // =18
     5d4:      	add	x9, sp, #0xa8
     5d8:      	add	x1, sp, #0xa8
     5dc:      	str	w8, [sp, #0xa8]
     5e0:      	mov	w8, #0x1                // =1
     5e4:      	mov	x0, x24
     5e8:      	blr	x8
     5ec:      	cbnz	x0, 0x924 <perf_unwind_perl+0x924>
     5f0:      	ldr	w8, [x23]
     5f4:      	cbz	w8, 0x93c <perf_unwind_perl+0x93c>
     5f8:      	adrp	x8, 0x0 <perf_unwind_perl>
     5fc:      	add	x8, x8, #0x0
     600:      	ldp	x9, x10, [x8, #0x10]
     604:      	stp	x9, x10, [sp, #0x40]
     608:      	ldr	x9, [x8, #0x20]
     60c:      	add	x10, sp, #0x30
     610:      	str	x9, [sp, #0x50]
     614:      	ldur	x9, [x8, #0x26]
     618:      	stur	x9, [sp, #0x56]
     61c:      	ldp	x9, x8, [x8]
     620:      	stp	x9, x8, [sp, #0x30]
     624:      	mov	w8, #0x2e               // =46
     628:      	mov	w9, #0x6                // =6
     62c:      	b	0x1184 <perf_unwind_perl+0x1184>
     630:      	ldr	w8, [x23]
     634:      	cbnz	w8, 0xb14 <perf_unwind_perl+0xb14>
     638:      	ldrb	w8, [x22, #0x14]
     63c:      	cbz	w8, 0x554 <perf_unwind_perl+0x554>
     640:      	mov	w8, #0x23               // =35
     644:      	blr	x8
     648:      	adrp	x8, 0x0 <perf_unwind_perl>
     64c:      	mov	w9, #0x71               // =113
     650:      	add	x10, sp, #0x88
     654:      	ldr	x8, [x8]
     658:      	mov	w1, #0x8                // =8
     65c:      	ldr	x8, [x8]
     660:      	add	x2, x0, x8
     664:      	mov	w8, #0x8                // =8
     668:      	add	x0, sp, #0x88
     66c:      	blr	x9
     670:      	cbz	x0, 0x6e4 <perf_unwind_perl+0x6e4>
     674:      	ldr	w8, [x23]
     678:      	cbnz	w8, 0xad8 <perf_unwind_perl+0xad8>
     67c:      	mov	w8, #0x4                // =4
     680:      	add	x9, sp, #0xa8
     684:      	add	x1, sp, #0xa8
     688:      	str	w8, [sp, #0xa8]
     68c:      	mov	w8, #0x1                // =1
     690:      	mov	x0, x24
     694:      	blr	x8
     698:      	cbz	x0, 0x750 <perf_unwind_perl+0x750>
     69c:      	ldr	x8, [x0]
     6a0:      	add	x8, x8, #0x1
     6a4:      	str	x8, [x0]
     6a8:      	ldr	w8, [x23]
     6ac:      	cbz	w8, 0x904 <perf_unwind_perl+0x904>
     6b0:      	adrp	x8, 0x0 <perf_unwind_perl>
     6b4:      	add	x8, x8, #0x0
     6b8:      	add	x0, sp, #0x30
     6bc:      	ldp	x9, x10, [x8]
     6c0:      	mov	w1, #0x20               // =32
     6c4:      	stp	x9, x10, [sp, #0x30]
     6c8:      	ldp	x9, x8, [x8, #0x10]
     6cc:      	add	x10, sp, #0x30
     6d0:      	stp	x9, x8, [sp, #0x40]
     6d4:      	mov	w8, #0x20               // =32
     6d8:      	mov	w9, #0x6                // =6
     6dc:      	blr	x9
     6e0:      	b	0x904 <perf_unwind_perl+0x904>
     6e4:      	ldr	x8, [x22]
     6e8:      	mov	w9, #0x4                // =4
     6ec:      	mov	w10, #0x70              // =112
     6f0:      	add	x11, sp, #0x28
     6f4:      	ldr	x2, [x22]
     6f8:      	add	x0, sp, #0x28
     6fc:      	mov	w1, #0x4                // =4
     700:      	blr	x10
     704:      	cbz	x0, 0x7a8 <perf_unwind_perl+0x7a8>
     708:      	ldr	w8, [x23]
     70c:      	cbz	w8, 0x904 <perf_unwind_perl+0x904>
     710:      	mov	w8, #0xa                // =10
     714:      	add	x0, sp, #0x30
     718:      	mov	w1, #0x22               // =34
     71c:      	strh	w8, [sp, #0x50]
     720:      	adrp	x8, 0x0 <perf_unwind_perl>
     724:      	add	x8, x8, #0x0
     728:      	ldp	x9, x10, [x8]
     72c:      	stp	x9, x10, [sp, #0x30]
     730:      	ldp	x9, x8, [x8, #0x10]
     734:      	add	x10, sp, #0x30
     738:      	stp	x9, x8, [sp, #0x40]
     73c:      	mov	w8, #0x22               // =34
     740:      	mov	w9, #0x6                // =6
     744:      	ldr	x2, [x22]
     748:      	blr	x9
     74c:      	b	0x904 <perf_unwind_perl+0x904>
     750:      	ldr	w8, [x23]
     754:      	cbz	w8, 0x904 <perf_unwind_perl+0x904>
     758:      	adrp	x8, 0x0 <perf_unwind_perl>
     75c:      	add	x8, x8, #0x0
     760:      	add	x0, sp, #0x30
     764:      	ldp	x9, x10, [x8, #0x10]
     768:      	mov	w1, #0x2e               // =46
     76c:      	stp	x9, x10, [sp, #0x40]
     770:      	ldr	x9, [x8, #0x20]
     774:      	add	x10, sp, #0x30
     778:      	str	x9, [sp, #0x50]
     77c:      	ldur	x9, [x8, #0x26]
     780:      	stur	x9, [sp, #0x56]
     784:      	ldp	x9, x8, [x8]
     788:      	stp	x9, x8, [sp, #0x30]
     78c:      	mov	w8, #0x2e               // =46
     790:      	mov	w9, #0x6                // =6
     794:      	ldr	w2, [sp, #0xa8]
     798:      	blr	x9
     79c:      	ldr	w8, [x23]
     7a0:      	cbz	w8, 0x904 <perf_unwind_perl+0x904>
     7a4:      	b	0x6b0 <perf_unwind_perl+0x6b0>
     7a8:      	ldr	x8, [sp, #0x88]
     7ac:      	ldrsh	x9, [x22, #0xc]
     7b0:      	add	x8, x8, x9
     7b4:      	ldrsw	x25, [sp, #0x28]
     7b8:      	ldrb	w9, [x22, #0xf]
     7bc:      	str	x8, [sp, #0xa8]
     7c0:      	cbz	w9, 0x7e8 <perf_unwind_perl+0x7e8>
     7c4:      	mov	w9, #0x8                // =8
     7c8:      	mov	w10, #0x70              // =112
     7cc:      	add	x11, sp, #0xa8
     7d0:      	ldr	x2, [sp, #0xa8]
     7d4:      	add	x0, sp, #0xa8
     7d8:      	mov	w1, #0x8                // =8
     7dc:      	blr	x10
     7e0:      	cbnz	x0, 0x81c <perf_unwind_perl+0x81c>
     7e4:      	ldr	x8, [sp, #0xa8]
     7e8:      	ldrb	w9, [x22, #0xe]
     7ec:      	smaddl	x8, w25, w9, x8
     7f0:      	ldr	w9, [x23]
     7f4:      	str	x8, [sp, #0xa8]
     7f8:      	cbnz	w9, 0x17d4 <perf_unwind_perl+0x17d4>
     7fc:      	mov	w9, #0x8                // =8
     800:      	mov	w10, #0x70              // =112
     804:      	add	x11, sp, #0x98
     808:      	ldr	x2, [sp, #0xa8]
     80c:      	add	x0, sp, #0x98
     810:      	mov	w1, #0x8                // =8
     814:      	blr	x10
     818:      	cbz	x0, 0x944 <perf_unwind_perl+0x944>
     81c:      	ldr	w8, [x23]
     820:      	cbnz	w8, 0x1754 <perf_unwind_perl+0x1754>
     824:      	mov	w8, #0x3                // =3
     828:      	add	x9, sp, #0x80
     82c:      	add	x1, sp, #0x80
     830:      	str	w8, [sp, #0x80]
     834:      	mov	w8, #0x1                // =1
     838:      	mov	x0, x24
     83c:      	blr	x8
     840:      	cbz	x0, 0x8fc <perf_unwind_perl+0x8fc>
     844:      	ldr	x8, [x0]
     848:      	add	x8, x8, #0x1
     84c:      	str	x8, [x0]
     850:      	b	0x904 <perf_unwind_perl+0x904>
     854:      	ldr	w8, [x23]
     858:      	cbnz	w8, 0x1794 <perf_unwind_perl+0x1794>
     85c:      	ldr	x25, [x29]
     860:      	ldrb	w8, [x22, #0x15]
     864:      	mov	w9, #0x8                // =8
     868:      	mov	w10, #0x70              // =112
     86c:      	add	x11, sp, #0xa8
     870:      	add	x0, sp, #0xa8
     874:      	mov	w1, #0x8                // =8
     878:      	add	x8, x25, x8
     87c:      	ldrb	w8, [x22, #0x15]
     880:      	add	x2, x25, x8
     884:      	blr	x10
     888:      	cbnz	x0, 0x8b8 <perf_unwind_perl+0x8b8>
     88c:      	ldrb	w8, [x22, #0x17]
     890:      	mov	w9, #0x4                // =4
     894:      	mov	w10, #0x70              // =112
     898:      	add	x11, sp, #0x80
     89c:      	add	x0, sp, #0x80
     8a0:      	mov	w1, #0x4                // =4
     8a4:      	add	x8, x25, x8
     8a8:      	ldrb	w8, [x22, #0x17]
     8ac:      	add	x2, x25, x8
     8b0:      	blr	x10
     8b4:      	cbz	x0, 0x9e4 <perf_unwind_perl+0x9e4>
     8b8:      	ldr	w8, [x23]
     8bc:      	cbnz	w8, 0x1820 <perf_unwind_perl+0x1820>
     8c0:      	ldr	w8, [x21, #0x1370]
     8c4:      	add	x9, sp, #0x88
     8c8:      	add	x1, sp, #0x88
     8cc:      	mov	x0, x24
     8d0:      	orr	w8, w8, #0x8
     8d4:      	str	w8, [x21, #0x1370]
     8d8:      	mov	w8, #0x12               // =18
     8dc:      	str	w8, [sp, #0x88]
     8e0:      	mov	w8, #0x1                // =1
     8e4:      	blr	x8
     8e8:      	cbz	x0, 0x994 <perf_unwind_perl+0x994>
     8ec:      	ldr	x8, [x0]
     8f0:      	add	x8, x8, #0x1
     8f4:      	str	x8, [x0]
     8f8:      	b	0xa04 <perf_unwind_perl+0xa04>
     8fc:      	ldr	w8, [x23]
     900:      	cbnz	w8, 0x18f4 <perf_unwind_perl+0x18f4>
     904:      	mov	w8, #0x11               // =17
     908:      	add	x9, sp, #0xa8
     90c:      	add	x1, sp, #0xa8
     910:      	str	w8, [sp, #0xa8]
     914:      	mov	w8, #0x1                // =1
     918:      	mov	x0, x24
     91c:      	blr	x8
     920:      	cbz	x0, 0x934 <perf_unwind_perl+0x934>
     924:      	ldr	x8, [x0]
     928:      	add	x8, x8, #0x1
     92c:      	str	x8, [x0]
     930:      	b	0x93c <perf_unwind_perl+0x93c>
     934:      	ldr	w8, [x23]
     938:      	cbnz	w8, 0x1150 <perf_unwind_perl+0x1150>
     93c:      	mov	w29, #0x1               // =1
     940:      	b	0x5820 <perf_unwind_perl+0x5820>
     944:      	ldr	w8, [x23]
     948:      	cbz	w8, 0x55c <perf_unwind_perl+0x55c>
     94c:      	mov	w8, #0x6425             // =25637
     950:      	add	x0, sp, #0x30
     954:      	mov	w1, #0x1c               // =28
     958:      	movk	w8, #0xa, lsl #16
     95c:      	str	w8, [sp, #0x48]
     960:      	adrp	x8, 0x0 <perf_unwind_perl>
     964:      	add	x8, x8, #0x0
     968:      	ldp	x9, x10, [x8]
     96c:      	ldr	x8, [x8, #0x10]
     970:      	stp	x9, x10, [sp, #0x30]
     974:      	str	x8, [sp, #0x40]
     978:      	mov	w8, #0x1c               // =28
     97c:      	mov	w9, #0x6                // =6
     980:      	add	x10, sp, #0x30
     984:      	ldr	x2, [sp, #0x88]
     988:      	ldr	w3, [sp, #0x28]
     98c:      	blr	x9
     990:      	b	0x55c <perf_unwind_perl+0x55c>
     994:      	ldr	w8, [x23]
     998:      	cbz	w8, 0xa04 <perf_unwind_perl+0xa04>
     99c:      	adrp	x8, 0x0 <perf_unwind_perl>
     9a0:      	add	x8, x8, #0x0
     9a4:      	add	x0, sp, #0x30
     9a8:      	ldp	x9, x10, [x8, #0x10]
     9ac:      	mov	w1, #0x2e               // =46
     9b0:      	stp	x9, x10, [sp, #0x40]
     9b4:      	ldr	x9, [x8, #0x20]
     9b8:      	add	x10, sp, #0x30
     9bc:      	str	x9, [sp, #0x50]
     9c0:      	ldur	x9, [x8, #0x26]
     9c4:      	stur	x9, [sp, #0x56]
     9c8:      	ldp	x9, x8, [x8]
     9cc:      	stp	x9, x8, [sp, #0x30]
     9d0:      	mov	w8, #0x2e               // =46
     9d4:      	mov	w9, #0x6                // =6
     9d8:      	ldr	w2, [sp, #0x88]
     9dc:      	blr	x9
     9e0:      	b	0xa04 <perf_unwind_perl+0xa04>
     9e4:      	ldr	w8, [x23]
     9e8:      	cbnz	w8, 0x1f84 <perf_unwind_perl+0x1f84>
     9ec:      	ldr	x8, [sp, #0xa8]
     9f0:      	ldrsw	x9, [sp, #0x80]
     9f4:      	str	x8, [x21, #0xf38]
     9f8:      	ldrb	w10, [x22, #0x1d]
     9fc:      	smaddl	x8, w9, w10, x8
     a00:      	str	x8, [x21, #0xf40]
     a04:      	ldr	x8, [x29]
     a08:      	str	x8, [sp, #0x68]
     a0c:      	cbnz	x8, 0x94 <perf_unwind_perl+0x94>
     a10:      	b	0x93c <perf_unwind_perl+0x93c>
     a14:      	adrp	x8, 0x0 <perf_unwind_perl>
     a18:      	add	x8, x8, #0x0
     a1c:      	strb	wzr, [sp, #0x58]
     a20:      	add	x0, sp, #0x30
     a24:      	ldp	x9, x10, [x8, #0x10]
     a28:      	mov	w1, #0x29               // =41
     a2c:      	stp	x9, x10, [sp, #0x40]
     a30:      	ldr	x9, [x8, #0x20]
     a34:      	add	x10, sp, #0x30
     a38:      	str	x9, [sp, #0x50]
     a3c:      	ldp	x8, x9, [x8]
     a40:      	stp	x8, x9, [sp, #0x30]
     a44:      	mov	w8, #0x29               // =41
     a48:      	mov	w9, #0x6                // =6
     a4c:      	blr	x9
     a50:      	mov	w0, wzr
     a54:      	b	0x58e4 <perf_unwind_perl+0x58e4>
     a58:      	mov	w8, #0xa                // =10
     a5c:      	add	x0, sp, #0x30
     a60:      	mov	w1, #0x2a               // =42
     a64:      	strh	w8, [sp, #0x58]
     a68:      	adrp	x8, 0x0 <perf_unwind_perl>
     a6c:      	add	x8, x8, #0x0
     a70:      	mov	x2, x25
     a74:      	ldp	x9, x10, [x8, #0x10]
     a78:      	stp	x9, x10, [sp, #0x40]
     a7c:      	ldr	x9, [x8, #0x20]
     a80:      	add	x10, sp, #0x30
     a84:      	str	x9, [sp, #0x50]
     a88:      	ldp	x8, x9, [x8]
     a8c:      	stp	x8, x9, [sp, #0x30]
     a90:      	mov	w8, #0x2a               // =42
     a94:      	mov	w9, #0x6                // =6
     a98:      	blr	x9
     a9c:      	b	0xf8 <perf_unwind_perl+0xf8>
     aa0:      	adrp	x8, 0x0 <perf_unwind_perl>
     aa4:      	add	x8, x8, #0x0
     aa8:      	add	x0, sp, #0x30
     aac:      	ldp	x9, x10, [x8]
     ab0:      	ldur	x8, [x8, #0xf]
     ab4:      	mov	w1, #0x17               // =23
     ab8:      	stp	x9, x10, [sp, #0x30]
     abc:      	stur	x8, [sp, #0x3f]
     ac0:      	mov	w8, #0x17               // =23
     ac4:      	mov	w9, #0x6                // =6
     ac8:      	add	x10, sp, #0x30
     acc:      	ldr	x2, [sp, #0x98]
     ad0:      	blr	x9
     ad4:      	b	0x564 <perf_unwind_perl+0x564>
     ad8:      	adrp	x8, 0x0 <perf_unwind_perl>
     adc:      	add	x8, x8, #0x0
     ae0:      	add	x0, sp, #0x30
     ae4:      	ldp	x9, x10, [x8]
     ae8:      	mov	w1, #0x1d               // =29
     aec:      	stp	x9, x10, [sp, #0x30]
     af0:      	ldr	x9, [x8, #0x10]
     af4:      	ldur	x8, [x8, #0x15]
     af8:      	add	x10, sp, #0x30
     afc:      	str	x9, [sp, #0x40]
     b00:      	stur	x8, [sp, #0x45]
     b04:      	mov	w8, #0x1d               // =29
     b08:      	mov	w9, #0x6                // =6
     b0c:      	blr	x9
     b10:      	b	0x67c <perf_unwind_perl+0x67c>
     b14:      	adrp	x8, 0x0 <perf_unwind_perl>
     b18:      	add	x8, x8, #0x0
     b1c:      	add	x0, sp, #0x30
     b20:      	ldp	x9, x10, [x8, #0x10]
     b24:      	mov	w1, #0x2e               // =46
     b28:      	stp	x9, x10, [sp, #0x40]
     b2c:      	ldr	x9, [x8, #0x20]
     b30:      	add	x10, sp, #0x30
     b34:      	str	x9, [sp, #0x50]
     b38:      	ldur	x9, [x8, #0x26]
     b3c:      	stur	x9, [sp, #0x56]
     b40:      	ldp	x9, x8, [x8]
     b44:      	stp	x9, x8, [sp, #0x30]
     b48:      	mov	w8, #0x2e               // =46
     b4c:      	mov	w9, #0x6                // =6
     b50:      	ldr	w2, [sp, #0xa8]
     b54:      	blr	x9
     b58:      	ldrb	w8, [x22, #0x14]
     b5c:      	cbnz	w8, 0x640 <perf_unwind_perl+0x640>
     b60:      	b	0x554 <perf_unwind_perl+0x554>
     b64:      	ldr	w8, [x23]
     b68:      	ldr	x24, [sp, #0x10]
     b6c:      	cbz	w8, 0xf0 <perf_unwind_perl+0xf0>
     b70:      	adrp	x8, 0x0 <perf_unwind_perl>
     b74:      	add	x8, x8, #0x0
     b78:      	add	x0, sp, #0x30
     b7c:      	ldp	x9, x10, [x8, #0x10]
     b80:      	mov	w1, #0x26               // =38
     b84:      	stp	x9, x10, [sp, #0x40]
     b88:      	ldur	x9, [x8, #0x1e]
     b8c:      	add	x10, sp, #0x30
     b90:      	stur	x9, [sp, #0x4e]
     b94:      	ldp	x8, x9, [x8]
     b98:      	stp	x8, x9, [sp, #0x30]
     b9c:      	mov	w8, #0x26               // =38
     ba0:      	mov	w9, #0x6                // =6
     ba4:      	ldr	w2, [sp, #0xb8]
     ba8:      	ldr	w3, [sp, #0xa4]
     bac:      	blr	x9
     bb0:      	b	0xf0 <perf_unwind_perl+0xf0>
     bb4:      	mov	w8, #0xa                // =10
     bb8:      	add	x0, sp, #0x30
     bbc:      	mov	w1, #0x22               // =34
     bc0:      	strh	w8, [sp, #0x50]
     bc4:      	adrp	x8, 0x0 <perf_unwind_perl>
     bc8:      	add	x8, x8, #0x0
     bcc:      	ldp	x9, x10, [x8]
     bd0:      	stp	x9, x10, [sp, #0x30]
     bd4:      	ldp	x9, x8, [x8, #0x10]
     bd8:      	add	x10, sp, #0x30
     bdc:      	stp	x9, x8, [sp, #0x40]
     be0:      	mov	w8, #0x22               // =34
     be4:      	mov	w9, #0x6                // =6
     be8:      	blr	x9
     bec:      	b	0x5d0 <perf_unwind_perl+0x5d0>
     bf0:      	mov	w8, #0xa                // =10
     bf4:      	add	x10, sp, #0x30
     bf8:      	add	x0, sp, #0x30
     bfc:      	strh	w8, [sp, #0x40]
     c00:      	adrp	x8, 0x0 <perf_unwind_perl>
     c04:      	add	x8, x8, #0x0
     c08:      	mov	w1, #0x12               // =18
     c0c:      	ldp	x9, x8, [x8]
     c10:      	stp	x9, x8, [sp, #0x30]
     c14:      	mov	w8, #0x12               // =18
     c18:      	mov	w9, #0x6                // =6
     c1c:      	ldrb	w2, [sp, #0x7c]
     c20:      	blr	x9
     c24:      	ldrb	w8, [sp, #0x7c]
     c28:      	and	w9, w8, #0xf
     c2c:      	sub	w10, w9, #0x9
     c30:      	cmp	w10, #0x2
     c34:      	b.lo	0x148 <perf_unwind_perl+0x148>
     c38:      	cmp	w9, #0xc
     c3c:      	b.ne	0xd18 <perf_unwind_perl+0xd18>
     c40:      	mov	w29, #0x3               // =3
     c44:      	ldrb	w8, [x22, #0x1d]
     c48:      	ldr	x9, [x21, #0xf40]
     c4c:      	adrp	x0, 0x0 <perf_unwind_perl>
     c50:      	add	x1, sp, #0xa8
     c54:      	sub	x8, x9, x8
     c58:      	add	x9, sp, #0xa8
     c5c:      	str	x8, [x21, #0xf40]
     c60:      	mov	w8, #0x10               // =16
     c64:      	str	w8, [sp, #0xa8]
     c68:      	mov	w8, #0x1                // =1
     c6c:      	ldr	x0, [x0]
     c70:      	blr	x8
     c74:      	cbz	x0, 0xc8c <perf_unwind_perl+0xc8c>
     c78:      	ldr	x8, [x0]
     c7c:      	add	x8, x8, #0x1
     c80:      	str	x8, [x0]
     c84:      	ldr	x9, [sp, #0x18]
     c88:      	b	0xc98 <perf_unwind_perl+0xc98>
     c8c:      	ldr	w8, [x23]
     c90:      	ldr	x9, [sp, #0x18]
     c94:      	cbnz	w8, 0x1108 <perf_unwind_perl+0x1108>
     c98:      	cmp	w29, #0x3
     c9c:      	b.ne	0x563c <perf_unwind_perl+0x563c>
     ca0:      	ldr	x25, [x21, #0xf40]
     ca4:      	cmp	x25, x9
     ca8:      	b.lo	0xac <perf_unwind_perl+0xac>
     cac:      	ldrb	w8, [x22, #0x19]
     cb0:      	mov	w9, #0x1                // =1
     cb4:      	mov	w10, #0x70              // =112
     cb8:      	add	x11, sp, #0x7c
     cbc:      	add	x0, sp, #0x7c
     cc0:      	mov	w1, #0x1                // =1
     cc4:      	add	x8, x25, x8
     cc8:      	ldrb	w8, [x22, #0x19]
     ccc:      	add	x2, x25, x8
     cd0:      	blr	x10
     cd4:      	cbz	x0, 0xd94 <perf_unwind_perl+0xd94>
     cd8:      	ldr	w8, [x23]
     cdc:      	cbnz	w8, 0x119c <perf_unwind_perl+0x119c>
     ce0:      	mov	w8, #0x13               // =19
     ce4:      	adrp	x0, 0x0 <perf_unwind_perl>
     ce8:      	add	x9, sp, #0xa8
     cec:      	str	w8, [sp, #0xa8]
     cf0:      	mov	w8, #0x1                // =1
     cf4:      	add	x1, sp, #0xa8
     cf8:      	ldr	x0, [x0]
     cfc:      	blr	x8
     d00:      	cbz	x0, 0xe94 <perf_unwind_perl+0xe94>
     d04:      	ldr	x8, [x0]
     d08:      	mov	w29, #0x3               // =3
     d0c:      	add	x8, x8, #0x1
     d10:      	str	x8, [x0]
     d14:      	b	0x1288 <perf_unwind_perl+0x1288>
     d18:      	ldr	x8, [x24]
     d1c:      	mov	w29, #0x3               // =3
     d20:      	cbnz	x8, 0xc44 <perf_unwind_perl+0xc44>
     d24:      	ldrb	w8, [x22, #0x1a]
     d28:      	mov	w9, #0x8                // =8
     d2c:      	mov	w10, #0x70              // =112
     d30:      	mov	x0, x24
     d34:      	mov	w1, #0x8                // =8
     d38:      	add	x8, x25, x8
     d3c:      	ldrb	w8, [x22, #0x1a]
     d40:      	add	x2, x25, x8
     d44:      	blr	x10
     d48:      	cbnz	x0, 0xf0 <perf_unwind_perl+0xf0>
     d4c:      	ldr	w8, [x23]
     d50:      	cbz	w8, 0xc44 <perf_unwind_perl+0xc44>
     d54:      	adrp	x8, 0x0 <perf_unwind_perl>
     d58:      	add	x8, x8, #0x0
     d5c:      	add	x0, sp, #0x30
     d60:      	ldp	x9, x10, [x8]
     d64:      	mov	w1, #0x1e               // =30
     d68:      	stp	x9, x10, [sp, #0x30]
     d6c:      	ldr	x9, [x8, #0x10]
     d70:      	ldur	x8, [x8, #0x16]
     d74:      	add	x10, sp, #0x30
     d78:      	str	x9, [sp, #0x40]
     d7c:      	stur	x8, [sp, #0x46]
     d80:      	mov	w8, #0x1e               // =30
     d84:      	mov	w9, #0x6                // =6
     d88:      	ldr	x2, [x24]
     d8c:      	blr	x9
     d90:      	b	0xc44 <perf_unwind_perl+0xc44>
     d94:      	ldr	w8, [x23]
     d98:      	cbnz	w8, 0x1234 <perf_unwind_perl+0x1234>
     d9c:      	ldrb	w8, [sp, #0x7c]
     da0:      	and	w9, w8, #0xf
     da4:      	sub	w10, w9, #0x9
     da8:      	cmp	w10, #0x2
     dac:      	b.hs	0x127c <perf_unwind_perl+0x127c>
     db0:      	sxtb	w8, w8
     db4:      	tbnz	w8, #0x1f, 0x1284 <perf_unwind_perl+0x1284>
     db8:      	ldrb	w8, [x22, #0x1b]
     dbc:      	mov	w9, #0x8                // =8
     dc0:      	mov	w10, #0x70              // =112
     dc4:      	add	x11, sp, #0x30
     dc8:      	add	x0, sp, #0x30
     dcc:      	mov	w1, #0x8                // =8
     dd0:      	add	x8, x25, x8
     dd4:      	ldrb	w8, [x22, #0x1b]
     dd8:      	add	x2, x25, x8
     ddc:      	blr	x10
     de0:      	cbnz	x0, 0xcd8 <perf_unwind_perl+0xcd8>
     de4:      	ldr	x8, [sp, #0x30]
     de8:      	mov	w9, #0x8                // =8
     dec:      	mov	w10, #0x70              // =112
     df0:      	add	x11, sp, #0x70
     df4:      	add	x0, sp, #0x70
     df8:      	mov	w1, #0x8                // =8
     dfc:      	cmp	x8, #0x0
     e00:      	mov	w8, #0x3                // =3
     e04:      	csinc	w29, w8, wzr, ne
     e08:      	ldrb	w8, [x22, #0x1c]
     e0c:      	add	x8, x25, x8
     e10:      	ldrb	w8, [x22, #0x1c]
     e14:      	add	x2, x25, x8
     e18:      	blr	x10
     e1c:      	cbnz	x0, 0xcd8 <perf_unwind_perl+0xcd8>
     e20:      	str	x24, [sp, #0x10]
     e24:      	ldr	x24, [sp, #0x70]
     e28:      	mov	w9, #0x4                // =4
     e2c:      	mov	w10, #0x70              // =112
     e30:      	add	x11, sp, #0xb8
     e34:      	add	x0, sp, #0xb8
     e38:      	ldrb	w8, [x22, #0x1e]
     e3c:      	mov	w1, #0x4                // =4
     e40:      	add	x8, x24, x8
     e44:      	ldrb	w8, [x22, #0x1e]
     e48:      	add	x2, x24, x8
     e4c:      	blr	x10
     e50:      	cbz	x0, 0xee4 <perf_unwind_perl+0xee4>
     e54:      	ldr	w8, [x23]
     e58:      	cbnz	w8, 0x257c <perf_unwind_perl+0x257c>
     e5c:      	mov	w8, #0x14               // =20
     e60:      	adrp	x0, 0x0 <perf_unwind_perl>
     e64:      	add	x9, sp, #0xbc
     e68:      	str	w8, [sp, #0xbc]
     e6c:      	mov	w8, #0x1                // =1
     e70:      	add	x1, sp, #0xbc
     e74:      	ldr	x0, [x0]
     e78:      	blr	x8
     e7c:      	ldr	x24, [sp, #0x10]
     e80:      	cbz	x0, 0x106c <perf_unwind_perl+0x106c>
     e84:      	ldr	x8, [x0]
     e88:      	add	x8, x8, #0x1
     e8c:      	str	x8, [x0]
     e90:      	b	0xcd8 <perf_unwind_perl+0xcd8>
     e94:      	ldr	w8, [x23]
     e98:      	cbz	w8, 0x1284 <perf_unwind_perl+0x1284>
     e9c:      	adrp	x8, 0x0 <perf_unwind_perl>
     ea0:      	add	x8, x8, #0x0
     ea4:      	add	x0, sp, #0x30
     ea8:      	ldp	x9, x10, [x8, #0x10]
     eac:      	mov	w1, #0x2e               // =46
     eb0:      	stp	x9, x10, [sp, #0x40]
     eb4:      	ldr	x9, [x8, #0x20]
     eb8:      	add	x10, sp, #0x30
     ebc:      	str	x9, [sp, #0x50]
     ec0:      	ldur	x9, [x8, #0x26]
     ec4:      	stur	x9, [sp, #0x56]
     ec8:      	ldp	x9, x8, [x8]
     ecc:      	stp	x9, x8, [sp, #0x30]
     ed0:      	mov	w8, #0x2e               // =46
     ed4:      	mov	w9, #0x6                // =6
     ed8:      	ldr	w2, [sp, #0xa8]
     edc:      	blr	x9
     ee0:      	b	0x1284 <perf_unwind_perl+0x1284>
     ee4:      	ldr	w8, [sp, #0xb8]
     ee8:      	and	w8, w8, #0x1f
     eec:      	cmp	w8, #0xd
     ef0:      	b.ne	0x10bc <perf_unwind_perl+0x10bc>
     ef4:      	ldrb	w8, [x22, #0x1f]
     ef8:      	mov	w9, #0x8                // =8
     efc:      	mov	w10, #0x70              // =112
     f00:      	add	x11, sp, #0xa8
     f04:      	add	x0, sp, #0xa8
     f08:      	mov	w1, #0x8                // =8
     f0c:      	add	x8, x24, x8
     f10:      	ldrb	w8, [x22, #0x1f]
     f14:      	add	x2, x24, x8
     f18:      	blr	x10
     f1c:      	cbnz	x0, 0xe54 <perf_unwind_perl+0xe54>
     f20:      	ldr	x8, [sp, #0xa8]
     f24:      	ldrb	w9, [x22, #0x21]
     f28:      	mov	w10, #0x70              // =112
     f2c:      	add	x11, sp, #0xa4
     f30:      	add	x0, sp, #0xa4
     f34:      	mov	w1, #0x4                // =4
     f38:      	add	x8, x8, x9
     f3c:      	mov	w9, #0x4                // =4
     f40:      	ldr	x8, [sp, #0xa8]
     f44:      	ldrb	w9, [x22, #0x21]
     f48:      	add	x2, x8, x9
     f4c:      	blr	x10
     f50:      	cbnz	x0, 0xe54 <perf_unwind_perl+0xe54>
     f54:      	ldrb	w8, [sp, #0xa5]
     f58:      	tbnz	w8, #0x7, 0x11e4 <perf_unwind_perl+0x11e4>
     f5c:      	ldr	x8, [sp, #0xa8]
     f60:      	ldrb	w9, [x22, #0x22]
     f64:      	mov	w10, #0x70              // =112
     f68:      	add	x11, sp, #0x98
     f6c:      	add	x0, sp, #0x98
     f70:      	mov	w1, #0x8                // =8
     f74:      	add	x8, x8, x9
     f78:      	mov	w9, #0x8                // =8
     f7c:      	ldr	x8, [sp, #0xa8]
     f80:      	ldrb	w9, [x22, #0x22]
     f84:      	add	x2, x8, x9
     f88:      	blr	x10
     f8c:      	cbnz	x0, 0xe54 <perf_unwind_perl+0xe54>
     f90:      	ldr	x8, [sp, #0x98]
     f94:      	cbz	x8, 0xe54 <perf_unwind_perl+0xe54>
     f98:      	ldr	w9, [x23]
     f9c:      	cbnz	w9, 0x3ce0 <perf_unwind_perl+0x3ce0>
     fa0:      	ldrb	w9, [x22, #0x1e]
     fa4:      	mov	w10, #0x70              // =112
     fa8:      	add	x11, sp, #0x94
     fac:      	add	x0, sp, #0x94
     fb0:      	mov	w1, #0x4                // =4
     fb4:      	add	x8, x8, x9
     fb8:      	mov	w9, #0x4                // =4
     fbc:      	ldr	x8, [sp, #0x98]
     fc0:      	ldrb	w9, [x22, #0x1e]
     fc4:      	add	x2, x8, x9
     fc8:      	blr	x10
     fcc:      	cbnz	x0, 0xe54 <perf_unwind_perl+0xe54>
     fd0:      	ldr	w8, [sp, #0x94]
     fd4:      	mov	w9, #0x801f             // =32799
     fd8:      	and	w8, w8, w9
     fdc:      	mov	w9, #0x8009             // =32777
     fe0:      	cmp	w8, w9
     fe4:      	b.ne	0x1f38 <perf_unwind_perl+0x1f38>
     fe8:      	ldr	x8, [sp, #0x98]
     fec:      	ldrb	w9, [x22, #0x20]
     ff0:      	mov	w10, #0x70              // =112
     ff4:      	add	x11, sp, #0x88
     ff8:      	add	x0, sp, #0x88
     ffc:      	mov	w1, #0x8                // =8
    1000:      	add	x8, x8, x9
    1004:      	mov	w9, #0x8                // =8
    1008:      	ldr	x8, [sp, #0x98]
    100c:      	ldrb	w9, [x22, #0x20]
    1010:      	add	x2, x8, x9
    1014:      	blr	x10
    1018:      	cbnz	x0, 0xe54 <perf_unwind_perl+0xe54>
    101c:      	ldr	x8, [sp, #0x88]
    1020:      	ldrb	w9, [x22, #0x23]
    1024:      	mov	w10, #0x70              // =112
    1028:      	add	x11, sp, #0x80
    102c:      	add	x0, sp, #0x80
    1030:      	mov	w1, #0x8                // =8
    1034:      	add	x8, x8, x9
    1038:      	mov	w9, #0x8                // =8
    103c:      	ldr	x8, [sp, #0x88]
    1040:      	ldrb	w9, [x22, #0x23]
    1044:      	add	x2, x8, x9
    1048:      	blr	x10
    104c:      	cbnz	x0, 0xe54 <perf_unwind_perl+0xe54>
    1050:      	ldr	x8, [sp, #0x80]
    1054:      	str	x8, [sp, #0x8]
    1058:      	cbz	x8, 0x2d58 <perf_unwind_perl+0x2d58>
    105c:      	ldr	w8, [x23]
    1060:      	cbnz	w8, 0x54c0 <perf_unwind_perl+0x54c0>
    1064:      	ldr	x24, [sp, #0x10]
    1068:      	b	0x2d6c <perf_unwind_perl+0x2d6c>
    106c:      	ldr	w8, [x23]
    1070:      	cbz	w8, 0xcd8 <perf_unwind_perl+0xcd8>
    1074:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    1078:      	add	x8, x8, #0x0
    107c:      	add	x0, sp, #0x30
    1080:      	ldp	x9, x10, [x8, #0x10]
    1084:      	mov	w1, #0x2e               // =46
    1088:      	stp	x9, x10, [sp, #0x40]
    108c:      	ldr	x9, [x8, #0x20]
    1090:      	add	x10, sp, #0x30
    1094:      	str	x9, [sp, #0x50]
    1098:      	ldur	x9, [x8, #0x26]
    109c:      	stur	x9, [sp, #0x56]
    10a0:      	ldp	x9, x8, [x8]
    10a4:      	stp	x9, x8, [sp, #0x30]
    10a8:      	mov	w8, #0x2e               // =46
    10ac:      	mov	w9, #0x6                // =6
    10b0:      	ldr	w2, [sp, #0xbc]
    10b4:      	blr	x9
    10b8:      	b	0xcd8 <perf_unwind_perl+0xcd8>
    10bc:      	ldr	w8, [x23]
    10c0:      	ldr	x24, [sp, #0x10]
    10c4:      	cbz	w8, 0xcd8 <perf_unwind_perl+0xcd8>
    10c8:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    10cc:      	add	x8, x8, #0x0
    10d0:      	add	x0, sp, #0x30
    10d4:      	ldp	x9, x10, [x8]
    10d8:      	mov	w1, #0x1e               // =30
    10dc:      	stp	x9, x10, [sp, #0x30]
    10e0:      	ldr	x9, [x8, #0x10]
    10e4:      	ldur	x8, [x8, #0x16]
    10e8:      	add	x10, sp, #0x30
    10ec:      	str	x9, [sp, #0x40]
    10f0:      	stur	x8, [sp, #0x46]
    10f4:      	mov	w8, #0x1e               // =30
    10f8:      	mov	w9, #0x6                // =6
    10fc:      	ldr	w2, [sp, #0xb8]
    1100:      	blr	x9
    1104:      	b	0xcd8 <perf_unwind_perl+0xcd8>
    1108:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    110c:      	add	x8, x8, #0x0
    1110:      	add	x0, sp, #0x30
    1114:      	ldp	x9, x10, [x8, #0x10]
    1118:      	mov	w1, #0x2e               // =46
    111c:      	stp	x9, x10, [sp, #0x40]
    1120:      	ldr	x9, [x8, #0x20]
    1124:      	add	x10, sp, #0x30
    1128:      	str	x9, [sp, #0x50]
    112c:      	ldur	x9, [x8, #0x26]
    1130:      	stur	x9, [sp, #0x56]
    1134:      	ldp	x9, x8, [x8]
    1138:      	stp	x9, x8, [sp, #0x30]
    113c:      	mov	w8, #0x2e               // =46
    1140:      	mov	w9, #0x6                // =6
    1144:      	ldr	w2, [sp, #0xa8]
    1148:      	blr	x9
    114c:      	b	0xc84 <perf_unwind_perl+0xc84>
    1150:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    1154:      	add	x8, x8, #0x0
    1158:      	ldp	x9, x10, [x8, #0x10]
    115c:      	stp	x9, x10, [sp, #0x40]
    1160:      	ldr	x9, [x8, #0x20]
    1164:      	add	x10, sp, #0x30
    1168:      	str	x9, [sp, #0x50]
    116c:      	ldur	x9, [x8, #0x26]
    1170:      	stur	x9, [sp, #0x56]
    1174:      	ldp	x9, x8, [x8]
    1178:      	stp	x9, x8, [sp, #0x30]
    117c:      	mov	w8, #0x2e               // =46
    1180:      	mov	w9, #0x6                // =6
    1184:      	ldr	w2, [sp, #0xa8]
    1188:      	add	x0, sp, #0x30
    118c:      	mov	w1, #0x2e               // =46
    1190:      	blr	x9
    1194:      	mov	w29, #0x1               // =1
    1198:      	b	0x5820 <perf_unwind_perl+0x5820>
    119c:      	mov	w8, #0xa                // =10
    11a0:      	add	x0, sp, #0x30
    11a4:      	mov	w1, #0x2a               // =42
    11a8:      	strh	w8, [sp, #0x58]
    11ac:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    11b0:      	add	x8, x8, #0x0
    11b4:      	mov	x2, x25
    11b8:      	ldp	x9, x10, [x8, #0x10]
    11bc:      	stp	x9, x10, [sp, #0x40]
    11c0:      	ldr	x9, [x8, #0x20]
    11c4:      	add	x10, sp, #0x30
    11c8:      	str	x9, [sp, #0x50]
    11cc:      	ldp	x8, x9, [x8]
    11d0:      	stp	x8, x9, [sp, #0x30]
    11d4:      	mov	w8, #0x2a               // =42
    11d8:      	mov	w9, #0x6                // =6
    11dc:      	blr	x9
    11e0:      	b	0xce0 <perf_unwind_perl+0xce0>
    11e4:      	ldr	w8, [x23]
    11e8:      	ldr	x24, [sp, #0x10]
    11ec:      	cbz	w8, 0xcd8 <perf_unwind_perl+0xcd8>
    11f0:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    11f4:      	add	x8, x8, #0x0
    11f8:      	add	x0, sp, #0x30
    11fc:      	ldp	x9, x10, [x8, #0x10]
    1200:      	mov	w1, #0x26               // =38
    1204:      	stp	x9, x10, [sp, #0x40]
    1208:      	ldur	x9, [x8, #0x1e]
    120c:      	add	x10, sp, #0x30
    1210:      	stur	x9, [sp, #0x4e]
    1214:      	ldp	x8, x9, [x8]
    1218:      	stp	x8, x9, [sp, #0x30]
    121c:      	mov	w8, #0x26               // =38
    1220:      	mov	w9, #0x6                // =6
    1224:      	ldr	w2, [sp, #0xb8]
    1228:      	ldr	w3, [sp, #0xa4]
    122c:      	blr	x9
    1230:      	b	0xcd8 <perf_unwind_perl+0xcd8>
    1234:      	mov	w8, #0xa                // =10
    1238:      	add	x10, sp, #0x30
    123c:      	add	x0, sp, #0x30
    1240:      	strh	w8, [sp, #0x40]
    1244:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    1248:      	add	x8, x8, #0x0
    124c:      	mov	w1, #0x12               // =18
    1250:      	ldp	x9, x8, [x8]
    1254:      	stp	x9, x8, [sp, #0x30]
    1258:      	mov	w8, #0x12               // =18
    125c:      	mov	w9, #0x6                // =6
    1260:      	ldrb	w2, [sp, #0x7c]
    1264:      	blr	x9
    1268:      	ldrb	w8, [sp, #0x7c]
    126c:      	and	w9, w8, #0xf
    1270:      	sub	w10, w9, #0x9
    1274:      	cmp	w10, #0x2
    1278:      	b.lo	0xdb0 <perf_unwind_perl+0xdb0>
    127c:      	cmp	w9, #0xc
    1280:      	b.ne	0x135c <perf_unwind_perl+0x135c>
    1284:      	mov	w29, #0x3               // =3
    1288:      	ldrb	w8, [x22, #0x1d]
    128c:      	ldr	x9, [x21, #0xf40]
    1290:      	adrp	x0, 0x1000 <perf_unwind_perl+0x1000>
    1294:      	add	x1, sp, #0xa8
    1298:      	sub	x8, x9, x8
    129c:      	add	x9, sp, #0xa8
    12a0:      	str	x8, [x21, #0xf40]
    12a4:      	mov	w8, #0x10               // =16
    12a8:      	str	w8, [sp, #0xa8]
    12ac:      	mov	w8, #0x1                // =1
    12b0:      	ldr	x0, [x0]
    12b4:      	blr	x8
    12b8:      	cbz	x0, 0x12d0 <perf_unwind_perl+0x12d0>
    12bc:      	ldr	x8, [x0]
    12c0:      	add	x8, x8, #0x1
    12c4:      	str	x8, [x0]
    12c8:      	ldr	x9, [sp, #0x18]
    12cc:      	b	0x12dc <perf_unwind_perl+0x12dc>
    12d0:      	ldr	w8, [x23]
    12d4:      	ldr	x9, [sp, #0x18]
    12d8:      	cbnz	w8, 0x170c <perf_unwind_perl+0x170c>
    12dc:      	cmp	w29, #0x3
    12e0:      	b.ne	0x563c <perf_unwind_perl+0x563c>
    12e4:      	ldr	x25, [x21, #0xf40]
    12e8:      	cmp	x25, x9
    12ec:      	b.lo	0xac <perf_unwind_perl+0xac>
    12f0:      	ldrb	w8, [x22, #0x19]
    12f4:      	mov	w9, #0x1                // =1
    12f8:      	mov	w10, #0x70              // =112
    12fc:      	add	x11, sp, #0x7c
    1300:      	add	x0, sp, #0x7c
    1304:      	mov	w1, #0x1                // =1
    1308:      	add	x8, x25, x8
    130c:      	ldrb	w8, [x22, #0x19]
    1310:      	add	x2, x25, x8
    1314:      	blr	x10
    1318:      	cbz	x0, 0x13d8 <perf_unwind_perl+0x13d8>
    131c:      	ldr	w8, [x23]
    1320:      	cbnz	w8, 0x1864 <perf_unwind_perl+0x1864>
    1324:      	mov	w8, #0x13               // =19
    1328:      	adrp	x0, 0x1000 <perf_unwind_perl+0x1000>
    132c:      	add	x9, sp, #0xa8
    1330:      	str	w8, [sp, #0xa8]
    1334:      	mov	w8, #0x1                // =1
    1338:      	add	x1, sp, #0xa8
    133c:      	ldr	x0, [x0]
    1340:      	blr	x8
    1344:      	cbz	x0, 0x14d8 <perf_unwind_perl+0x14d8>
    1348:      	ldr	x8, [x0]
    134c:      	mov	w29, #0x3               // =3
    1350:      	add	x8, x8, #0x1
    1354:      	str	x8, [x0]
    1358:      	b	0x19e0 <perf_unwind_perl+0x19e0>
    135c:      	ldr	x8, [x24]
    1360:      	mov	w29, #0x3               // =3
    1364:      	cbnz	x8, 0x1288 <perf_unwind_perl+0x1288>
    1368:      	ldrb	w8, [x22, #0x1a]
    136c:      	mov	w9, #0x8                // =8
    1370:      	mov	w10, #0x70              // =112
    1374:      	mov	x0, x24
    1378:      	mov	w1, #0x8                // =8
    137c:      	add	x8, x25, x8
    1380:      	ldrb	w8, [x22, #0x1a]
    1384:      	add	x2, x25, x8
    1388:      	blr	x10
    138c:      	cbnz	x0, 0xcd8 <perf_unwind_perl+0xcd8>
    1390:      	ldr	w8, [x23]
    1394:      	cbz	w8, 0x1288 <perf_unwind_perl+0x1288>
    1398:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    139c:      	add	x8, x8, #0x0
    13a0:      	add	x0, sp, #0x30
    13a4:      	ldp	x9, x10, [x8]
    13a8:      	mov	w1, #0x1e               // =30
    13ac:      	stp	x9, x10, [sp, #0x30]
    13b0:      	ldr	x9, [x8, #0x10]
    13b4:      	ldur	x8, [x8, #0x16]
    13b8:      	add	x10, sp, #0x30
    13bc:      	str	x9, [sp, #0x40]
    13c0:      	stur	x8, [sp, #0x46]
    13c4:      	mov	w8, #0x1e               // =30
    13c8:      	mov	w9, #0x6                // =6
    13cc:      	ldr	x2, [x24]
    13d0:      	blr	x9
    13d4:      	b	0x1288 <perf_unwind_perl+0x1288>
    13d8:      	ldr	w8, [x23]
    13dc:      	cbnz	w8, 0x198c <perf_unwind_perl+0x198c>
    13e0:      	ldrb	w8, [sp, #0x7c]
    13e4:      	and	w9, w8, #0xf
    13e8:      	sub	w10, w9, #0x9
    13ec:      	cmp	w10, #0x2
    13f0:      	b.hs	0x19d4 <perf_unwind_perl+0x19d4>
    13f4:      	sxtb	w8, w8
    13f8:      	tbnz	w8, #0x1f, 0x19dc <perf_unwind_perl+0x19dc>
    13fc:      	ldrb	w8, [x22, #0x1b]
    1400:      	mov	w9, #0x8                // =8
    1404:      	mov	w10, #0x70              // =112
    1408:      	add	x11, sp, #0x30
    140c:      	add	x0, sp, #0x30
    1410:      	mov	w1, #0x8                // =8
    1414:      	add	x8, x25, x8
    1418:      	ldrb	w8, [x22, #0x1b]
    141c:      	add	x2, x25, x8
    1420:      	blr	x10
    1424:      	cbnz	x0, 0x131c <perf_unwind_perl+0x131c>
    1428:      	ldr	x8, [sp, #0x30]
    142c:      	mov	w9, #0x8                // =8
    1430:      	mov	w10, #0x70              // =112
    1434:      	add	x11, sp, #0x70
    1438:      	add	x0, sp, #0x70
    143c:      	mov	w1, #0x8                // =8
    1440:      	cmp	x8, #0x0
    1444:      	mov	w8, #0x3                // =3
    1448:      	csinc	w29, w8, wzr, ne
    144c:      	ldrb	w8, [x22, #0x1c]
    1450:      	add	x8, x25, x8
    1454:      	ldrb	w8, [x22, #0x1c]
    1458:      	add	x2, x25, x8
    145c:      	blr	x10
    1460:      	cbnz	x0, 0x131c <perf_unwind_perl+0x131c>
    1464:      	str	x24, [sp, #0x10]
    1468:      	ldr	x24, [sp, #0x70]
    146c:      	mov	w9, #0x4                // =4
    1470:      	mov	w10, #0x70              // =112
    1474:      	add	x11, sp, #0xb8
    1478:      	add	x0, sp, #0xb8
    147c:      	ldrb	w8, [x22, #0x1e]
    1480:      	mov	w1, #0x4                // =4
    1484:      	add	x8, x24, x8
    1488:      	ldrb	w8, [x22, #0x1e]
    148c:      	add	x2, x24, x8
    1490:      	blr	x10
    1494:      	cbz	x0, 0x1528 <perf_unwind_perl+0x1528>
    1498:      	ldr	w8, [x23]
    149c:      	cbnz	w8, 0x2c88 <perf_unwind_perl+0x2c88>
    14a0:      	mov	w8, #0x14               // =20
    14a4:      	adrp	x0, 0x1000 <perf_unwind_perl+0x1000>
    14a8:      	add	x9, sp, #0xbc
    14ac:      	str	w8, [sp, #0xbc]
    14b0:      	mov	w8, #0x1                // =1
    14b4:      	add	x1, sp, #0xbc
    14b8:      	ldr	x0, [x0]
    14bc:      	blr	x8
    14c0:      	cbz	x0, 0x16b0 <perf_unwind_perl+0x16b0>
    14c4:      	ldr	x8, [x0]
    14c8:      	ldr	x24, [sp, #0x10]
    14cc:      	add	x8, x8, #0x1
    14d0:      	str	x8, [x0]
    14d4:      	b	0x131c <perf_unwind_perl+0x131c>
    14d8:      	ldr	w8, [x23]
    14dc:      	cbz	w8, 0x19dc <perf_unwind_perl+0x19dc>
    14e0:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    14e4:      	add	x8, x8, #0x0
    14e8:      	add	x0, sp, #0x30
    14ec:      	ldp	x9, x10, [x8, #0x10]
    14f0:      	mov	w1, #0x2e               // =46
    14f4:      	stp	x9, x10, [sp, #0x40]
    14f8:      	ldr	x9, [x8, #0x20]
    14fc:      	add	x10, sp, #0x30
    1500:      	str	x9, [sp, #0x50]
    1504:      	ldur	x9, [x8, #0x26]
    1508:      	stur	x9, [sp, #0x56]
    150c:      	ldp	x9, x8, [x8]
    1510:      	stp	x9, x8, [sp, #0x30]
    1514:      	mov	w8, #0x2e               // =46
    1518:      	mov	w9, #0x6                // =6
    151c:      	ldr	w2, [sp, #0xa8]
    1520:      	blr	x9
    1524:      	b	0x19dc <perf_unwind_perl+0x19dc>
    1528:      	ldr	w8, [sp, #0xb8]
    152c:      	and	w8, w8, #0x1f
    1530:      	cmp	w8, #0xd
    1534:      	b.ne	0x16c0 <perf_unwind_perl+0x16c0>
    1538:      	ldrb	w8, [x22, #0x1f]
    153c:      	mov	w9, #0x8                // =8
    1540:      	mov	w10, #0x70              // =112
    1544:      	add	x11, sp, #0xa8
    1548:      	add	x0, sp, #0xa8
    154c:      	mov	w1, #0x8                // =8
    1550:      	add	x8, x24, x8
    1554:      	ldrb	w8, [x22, #0x1f]
    1558:      	add	x2, x24, x8
    155c:      	blr	x10
    1560:      	cbnz	x0, 0x1498 <perf_unwind_perl+0x1498>
    1564:      	ldr	x8, [sp, #0xa8]
    1568:      	ldrb	w9, [x22, #0x21]
    156c:      	mov	w10, #0x70              // =112
    1570:      	add	x11, sp, #0xa4
    1574:      	add	x0, sp, #0xa4
    1578:      	mov	w1, #0x4                // =4
    157c:      	add	x8, x8, x9
    1580:      	mov	w9, #0x4                // =4
    1584:      	ldr	x8, [sp, #0xa8]
    1588:      	ldrb	w9, [x22, #0x21]
    158c:      	add	x2, x8, x9
    1590:      	blr	x10
    1594:      	cbnz	x0, 0x1498 <perf_unwind_perl+0x1498>
    1598:      	ldrb	w8, [sp, #0xa5]
    159c:      	tbnz	w8, #0x7, 0x193c <perf_unwind_perl+0x193c>
    15a0:      	ldr	x8, [sp, #0xa8]
    15a4:      	ldrb	w9, [x22, #0x22]
    15a8:      	mov	w10, #0x70              // =112
    15ac:      	add	x11, sp, #0x98
    15b0:      	add	x0, sp, #0x98
    15b4:      	mov	w1, #0x8                // =8
    15b8:      	add	x8, x8, x9
    15bc:      	mov	w9, #0x8                // =8
    15c0:      	ldr	x8, [sp, #0xa8]
    15c4:      	ldrb	w9, [x22, #0x22]
    15c8:      	add	x2, x8, x9
    15cc:      	blr	x10
    15d0:      	cbnz	x0, 0x1498 <perf_unwind_perl+0x1498>
    15d4:      	ldr	x8, [sp, #0x98]
    15d8:      	cbz	x8, 0x1498 <perf_unwind_perl+0x1498>
    15dc:      	ldr	w9, [x23]
    15e0:      	cbnz	w9, 0x4448 <perf_unwind_perl+0x4448>
    15e4:      	ldrb	w9, [x22, #0x1e]
    15e8:      	mov	w10, #0x70              // =112
    15ec:      	add	x11, sp, #0x94
    15f0:      	add	x0, sp, #0x94
    15f4:      	mov	w1, #0x4                // =4
    15f8:      	add	x8, x8, x9
    15fc:      	mov	w9, #0x4                // =4
    1600:      	ldr	x8, [sp, #0x98]
    1604:      	ldrb	w9, [x22, #0x1e]
    1608:      	add	x2, x8, x9
    160c:      	blr	x10
    1610:      	cbnz	x0, 0x1498 <perf_unwind_perl+0x1498>
    1614:      	ldr	w8, [sp, #0x94]
    1618:      	mov	w9, #0x801f             // =32799
    161c:      	and	w8, w8, w9
    1620:      	mov	w9, #0x8009             // =32777
    1624:      	cmp	w8, w9
    1628:      	b.ne	0x2608 <perf_unwind_perl+0x2608>
    162c:      	ldr	x8, [sp, #0x98]
    1630:      	ldrb	w9, [x22, #0x20]
    1634:      	mov	w10, #0x70              // =112
    1638:      	add	x11, sp, #0x88
    163c:      	add	x0, sp, #0x88
    1640:      	mov	w1, #0x8                // =8
    1644:      	add	x8, x8, x9
    1648:      	mov	w9, #0x8                // =8
    164c:      	ldr	x8, [sp, #0x98]
    1650:      	ldrb	w9, [x22, #0x20]
    1654:      	add	x2, x8, x9
    1658:      	blr	x10
    165c:      	cbnz	x0, 0x1498 <perf_unwind_perl+0x1498>
    1660:      	ldr	x8, [sp, #0x88]
    1664:      	ldrb	w9, [x22, #0x23]
    1668:      	mov	w10, #0x70              // =112
    166c:      	add	x11, sp, #0x80
    1670:      	add	x0, sp, #0x80
    1674:      	mov	w1, #0x8                // =8
    1678:      	add	x8, x8, x9
    167c:      	mov	w9, #0x8                // =8
    1680:      	ldr	x8, [sp, #0x88]
    1684:      	ldrb	w9, [x22, #0x23]
    1688:      	add	x2, x8, x9
    168c:      	blr	x10
    1690:      	cbnz	x0, 0x1498 <perf_unwind_perl+0x1498>
    1694:      	ldr	x8, [sp, #0x80]
    1698:      	str	x8, [sp, #0x8]
    169c:      	cbz	x8, 0x34d4 <perf_unwind_perl+0x34d4>
    16a0:      	ldr	w8, [x23]
    16a4:      	cbnz	w8, 0x62b4 <perf_unwind_perl+0x62b4>
    16a8:      	ldr	x24, [sp, #0x10]
    16ac:      	b	0x34e8 <perf_unwind_perl+0x34e8>
    16b0:      	ldr	w8, [x23]
    16b4:      	cbnz	w8, 0x33bc <perf_unwind_perl+0x33bc>
    16b8:      	ldr	x24, [sp, #0x10]
    16bc:      	b	0x131c <perf_unwind_perl+0x131c>
    16c0:      	ldr	w8, [x23]
    16c4:      	ldr	x24, [sp, #0x10]
    16c8:      	cbz	w8, 0x131c <perf_unwind_perl+0x131c>
    16cc:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    16d0:      	add	x8, x8, #0x0
    16d4:      	add	x0, sp, #0x30
    16d8:      	ldp	x9, x10, [x8]
    16dc:      	mov	w1, #0x1e               // =30
    16e0:      	stp	x9, x10, [sp, #0x30]
    16e4:      	ldr	x9, [x8, #0x10]
    16e8:      	ldur	x8, [x8, #0x16]
    16ec:      	add	x10, sp, #0x30
    16f0:      	str	x9, [sp, #0x40]
    16f4:      	stur	x8, [sp, #0x46]
    16f8:      	mov	w8, #0x1e               // =30
    16fc:      	mov	w9, #0x6                // =6
    1700:      	ldr	w2, [sp, #0xb8]
    1704:      	blr	x9
    1708:      	b	0x131c <perf_unwind_perl+0x131c>
    170c:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    1710:      	add	x8, x8, #0x0
    1714:      	add	x0, sp, #0x30
    1718:      	ldp	x9, x10, [x8, #0x10]
    171c:      	mov	w1, #0x2e               // =46
    1720:      	stp	x9, x10, [sp, #0x40]
    1724:      	ldr	x9, [x8, #0x20]
    1728:      	add	x10, sp, #0x30
    172c:      	str	x9, [sp, #0x50]
    1730:      	ldur	x9, [x8, #0x26]
    1734:      	stur	x9, [sp, #0x56]
    1738:      	ldp	x9, x8, [x8]
    173c:      	stp	x9, x8, [sp, #0x30]
    1740:      	mov	w8, #0x2e               // =46
    1744:      	mov	w9, #0x6                // =6
    1748:      	ldr	w2, [sp, #0xa8]
    174c:      	blr	x9
    1750:      	b	0x12c8 <perf_unwind_perl+0x12c8>
    1754:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    1758:      	add	x8, x8, #0x0
    175c:      	add	x0, sp, #0x30
    1760:      	ldp	x9, x10, [x8]
    1764:      	mov	w1, #0x1f               // =31
    1768:      	stp	x9, x10, [sp, #0x30]
    176c:      	ldr	x9, [x8, #0x10]
    1770:      	ldur	x8, [x8, #0x17]
    1774:      	add	x10, sp, #0x30
    1778:      	str	x9, [sp, #0x40]
    177c:      	stur	x8, [sp, #0x47]
    1780:      	mov	w8, #0x1f               // =31
    1784:      	mov	w9, #0x6                // =6
    1788:      	ldr	x2, [sp, #0xa8]
    178c:      	blr	x9
    1790:      	b	0x824 <perf_unwind_perl+0x824>
    1794:      	mov	w8, #0xa                // =10
    1798:      	add	x0, sp, #0x30
    179c:      	mov	w1, #0x22               // =34
    17a0:      	strh	w8, [sp, #0x50]
    17a4:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    17a8:      	add	x8, x8, #0x0
    17ac:      	ldp	x9, x10, [x8]
    17b0:      	stp	x9, x10, [sp, #0x30]
    17b4:      	ldp	x9, x8, [x8, #0x10]
    17b8:      	add	x10, sp, #0x30
    17bc:      	stp	x9, x8, [sp, #0x40]
    17c0:      	mov	w8, #0x22               // =34
    17c4:      	mov	w9, #0x6                // =6
    17c8:      	ldr	x2, [x25]
    17cc:      	blr	x9
    17d0:      	b	0x85c <perf_unwind_perl+0x85c>
    17d4:      	mov	w8, #0x786c             // =30828
    17d8:      	add	x0, sp, #0x30
    17dc:      	mov	w1, #0x23               // =35
    17e0:      	mov	w2, w25
    17e4:      	movk	w8, #0xa, lsl #16
    17e8:      	stur	w8, [sp, #0x4f]
    17ec:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    17f0:      	add	x8, x8, #0x0
    17f4:      	ldp	x9, x10, [x8]
    17f8:      	stp	x9, x10, [sp, #0x30]
    17fc:      	ldp	x9, x8, [x8, #0x10]
    1800:      	add	x10, sp, #0x30
    1804:      	stp	x9, x8, [sp, #0x40]
    1808:      	mov	w8, #0x23               // =35
    180c:      	mov	w9, #0x6                // =6
    1810:      	ldr	x3, [sp, #0xa8]
    1814:      	blr	x9
    1818:      	ldr	x8, [sp, #0xa8]
    181c:      	b	0x7fc <perf_unwind_perl+0x7fc>
    1820:      	mov	w8, #0x786c             // =30828
    1824:      	add	x0, sp, #0x30
    1828:      	mov	w1, #0x23               // =35
    182c:      	mov	x2, x25
    1830:      	movk	w8, #0xa, lsl #16
    1834:      	stur	w8, [sp, #0x4f]
    1838:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    183c:      	add	x8, x8, #0x0
    1840:      	ldp	x9, x10, [x8]
    1844:      	stp	x9, x10, [sp, #0x30]
    1848:      	ldp	x9, x8, [x8, #0x10]
    184c:      	add	x10, sp, #0x30
    1850:      	stp	x9, x8, [sp, #0x40]
    1854:      	mov	w8, #0x23               // =35
    1858:      	mov	w9, #0x6                // =6
    185c:      	blr	x9
    1860:      	b	0x8c0 <perf_unwind_perl+0x8c0>
    1864:      	mov	w8, #0xa                // =10
    1868:      	add	x0, sp, #0x30
    186c:      	mov	w1, #0x2a               // =42
    1870:      	strh	w8, [sp, #0x58]
    1874:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    1878:      	add	x8, x8, #0x0
    187c:      	mov	x2, x25
    1880:      	ldp	x9, x10, [x8, #0x10]
    1884:      	stp	x9, x10, [sp, #0x40]
    1888:      	ldr	x9, [x8, #0x20]
    188c:      	add	x10, sp, #0x30
    1890:      	str	x9, [sp, #0x50]
    1894:      	ldp	x8, x9, [x8]
    1898:      	stp	x8, x9, [sp, #0x30]
    189c:      	mov	w8, #0x2a               // =42
    18a0:      	mov	w9, #0x6                // =6
    18a4:      	blr	x9
    18a8:      	b	0x1324 <perf_unwind_perl+0x1324>
    18ac:      	ldr	w8, [x23]
    18b0:      	ldr	x24, [sp, #0x10]
    18b4:      	cbz	w8, 0xf0 <perf_unwind_perl+0xf0>
    18b8:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    18bc:      	add	x8, x8, #0x0
    18c0:      	add	x0, sp, #0x30
    18c4:      	ldp	x9, x10, [x8, #0x10]
    18c8:      	mov	w1, #0x26               // =38
    18cc:      	stp	x9, x10, [sp, #0x40]
    18d0:      	ldur	x9, [x8, #0x1e]
    18d4:      	add	x10, sp, #0x30
    18d8:      	stur	x9, [sp, #0x4e]
    18dc:      	ldp	x8, x9, [x8]
    18e0:      	stp	x8, x9, [sp, #0x30]
    18e4:      	mov	w8, #0x26               // =38
    18e8:      	mov	w9, #0x6                // =6
    18ec:      	ldr	w2, [sp, #0x94]
    18f0:      	b	0x494 <perf_unwind_perl+0x494>
    18f4:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    18f8:      	add	x8, x8, #0x0
    18fc:      	add	x0, sp, #0x30
    1900:      	ldp	x9, x10, [x8, #0x10]
    1904:      	mov	w1, #0x2e               // =46
    1908:      	stp	x9, x10, [sp, #0x40]
    190c:      	ldr	x9, [x8, #0x20]
    1910:      	add	x10, sp, #0x30
    1914:      	str	x9, [sp, #0x50]
    1918:      	ldur	x9, [x8, #0x26]
    191c:      	stur	x9, [sp, #0x56]
    1920:      	ldp	x9, x8, [x8]
    1924:      	stp	x9, x8, [sp, #0x30]
    1928:      	mov	w8, #0x2e               // =46
    192c:      	mov	w9, #0x6                // =6
    1930:      	ldr	w2, [sp, #0x80]
    1934:      	blr	x9
    1938:      	b	0x904 <perf_unwind_perl+0x904>
    193c:      	ldr	w8, [x23]
    1940:      	ldr	x24, [sp, #0x10]
    1944:      	cbz	w8, 0x131c <perf_unwind_perl+0x131c>
    1948:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    194c:      	add	x8, x8, #0x0
    1950:      	add	x0, sp, #0x30
    1954:      	ldp	x9, x10, [x8, #0x10]
    1958:      	mov	w1, #0x26               // =38
    195c:      	stp	x9, x10, [sp, #0x40]
    1960:      	ldur	x9, [x8, #0x1e]
    1964:      	add	x10, sp, #0x30
    1968:      	stur	x9, [sp, #0x4e]
    196c:      	ldp	x8, x9, [x8]
    1970:      	stp	x8, x9, [sp, #0x30]
    1974:      	mov	w8, #0x26               // =38
    1978:      	mov	w9, #0x6                // =6
    197c:      	ldr	w2, [sp, #0xb8]
    1980:      	ldr	w3, [sp, #0xa4]
    1984:      	blr	x9
    1988:      	b	0x131c <perf_unwind_perl+0x131c>
    198c:      	mov	w8, #0xa                // =10
    1990:      	add	x10, sp, #0x30
    1994:      	add	x0, sp, #0x30
    1998:      	strh	w8, [sp, #0x40]
    199c:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    19a0:      	add	x8, x8, #0x0
    19a4:      	mov	w1, #0x12               // =18
    19a8:      	ldp	x9, x8, [x8]
    19ac:      	stp	x9, x8, [sp, #0x30]
    19b0:      	mov	w8, #0x12               // =18
    19b4:      	mov	w9, #0x6                // =6
    19b8:      	ldrb	w2, [sp, #0x7c]
    19bc:      	blr	x9
    19c0:      	ldrb	w8, [sp, #0x7c]
    19c4:      	and	w9, w8, #0xf
    19c8:      	sub	w10, w9, #0x9
    19cc:      	cmp	w10, #0x2
    19d0:      	b.lo	0x13f4 <perf_unwind_perl+0x13f4>
    19d4:      	cmp	w9, #0xc
    19d8:      	b.ne	0x1ab4 <perf_unwind_perl+0x1ab4>
    19dc:      	mov	w29, #0x3               // =3
    19e0:      	ldrb	w8, [x22, #0x1d]
    19e4:      	ldr	x9, [x21, #0xf40]
    19e8:      	adrp	x0, 0x1000 <perf_unwind_perl+0x1000>
    19ec:      	add	x1, sp, #0xa8
    19f0:      	sub	x8, x9, x8
    19f4:      	add	x9, sp, #0xa8
    19f8:      	str	x8, [x21, #0xf40]
    19fc:      	mov	w8, #0x10               // =16
    1a00:      	str	w8, [sp, #0xa8]
    1a04:      	mov	w8, #0x1                // =1
    1a08:      	ldr	x0, [x0]
    1a0c:      	blr	x8
    1a10:      	cbz	x0, 0x1a28 <perf_unwind_perl+0x1a28>
    1a14:      	ldr	x8, [x0]
    1a18:      	add	x8, x8, #0x1
    1a1c:      	str	x8, [x0]
    1a20:      	ldr	x9, [sp, #0x18]
    1a24:      	b	0x1a34 <perf_unwind_perl+0x1a34>
    1a28:      	ldr	w8, [x23]
    1a2c:      	ldr	x9, [sp, #0x18]
    1a30:      	cbnz	w8, 0x1e64 <perf_unwind_perl+0x1e64>
    1a34:      	cmp	w29, #0x3
    1a38:      	b.ne	0x563c <perf_unwind_perl+0x563c>
    1a3c:      	ldr	x25, [x21, #0xf40]
    1a40:      	cmp	x25, x9
    1a44:      	b.lo	0xac <perf_unwind_perl+0xac>
    1a48:      	ldrb	w8, [x22, #0x19]
    1a4c:      	mov	w9, #0x1                // =1
    1a50:      	mov	w10, #0x70              // =112
    1a54:      	add	x11, sp, #0x7c
    1a58:      	add	x0, sp, #0x7c
    1a5c:      	mov	w1, #0x1                // =1
    1a60:      	add	x8, x25, x8
    1a64:      	ldrb	w8, [x22, #0x19]
    1a68:      	add	x2, x25, x8
    1a6c:      	blr	x10
    1a70:      	cbz	x0, 0x1b30 <perf_unwind_perl+0x1b30>
    1a74:      	ldr	w8, [x23]
    1a78:      	cbnz	w8, 0x1ef0 <perf_unwind_perl+0x1ef0>
    1a7c:      	mov	w8, #0x13               // =19
    1a80:      	adrp	x0, 0x1000 <perf_unwind_perl+0x1000>
    1a84:      	add	x9, sp, #0xa8
    1a88:      	str	w8, [sp, #0xa8]
    1a8c:      	mov	w8, #0x1                // =1
    1a90:      	add	x1, sp, #0xa8
    1a94:      	ldr	x0, [x0]
    1a98:      	blr	x8
    1a9c:      	cbz	x0, 0x1c30 <perf_unwind_perl+0x1c30>
    1aa0:      	ldr	x8, [x0]
    1aa4:      	mov	w29, #0x3               // =3
    1aa8:      	add	x8, x8, #0x1
    1aac:      	str	x8, [x0]
    1ab0:      	b	0x206c <perf_unwind_perl+0x206c>
    1ab4:      	ldr	x8, [x24]
    1ab8:      	mov	w29, #0x3               // =3
    1abc:      	cbnz	x8, 0x19e0 <perf_unwind_perl+0x19e0>
    1ac0:      	ldrb	w8, [x22, #0x1a]
    1ac4:      	mov	w9, #0x8                // =8
    1ac8:      	mov	w10, #0x70              // =112
    1acc:      	mov	x0, x24
    1ad0:      	mov	w1, #0x8                // =8
    1ad4:      	add	x8, x25, x8
    1ad8:      	ldrb	w8, [x22, #0x1a]
    1adc:      	add	x2, x25, x8
    1ae0:      	blr	x10
    1ae4:      	cbnz	x0, 0x131c <perf_unwind_perl+0x131c>
    1ae8:      	ldr	w8, [x23]
    1aec:      	cbz	w8, 0x19e0 <perf_unwind_perl+0x19e0>
    1af0:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    1af4:      	add	x8, x8, #0x0
    1af8:      	add	x0, sp, #0x30
    1afc:      	ldp	x9, x10, [x8]
    1b00:      	mov	w1, #0x1e               // =30
    1b04:      	stp	x9, x10, [sp, #0x30]
    1b08:      	ldr	x9, [x8, #0x10]
    1b0c:      	ldur	x8, [x8, #0x16]
    1b10:      	add	x10, sp, #0x30
    1b14:      	str	x9, [sp, #0x40]
    1b18:      	stur	x8, [sp, #0x46]
    1b1c:      	mov	w8, #0x1e               // =30
    1b20:      	mov	w9, #0x6                // =6
    1b24:      	ldr	x2, [x24]
    1b28:      	blr	x9
    1b2c:      	b	0x19e0 <perf_unwind_perl+0x19e0>
    1b30:      	ldr	w8, [x23]
    1b34:      	cbnz	w8, 0x2018 <perf_unwind_perl+0x2018>
    1b38:      	ldrb	w8, [sp, #0x7c]
    1b3c:      	and	w9, w8, #0xf
    1b40:      	sub	w10, w9, #0x9
    1b44:      	cmp	w10, #0x2
    1b48:      	b.hs	0x2060 <perf_unwind_perl+0x2060>
    1b4c:      	sxtb	w8, w8
    1b50:      	tbnz	w8, #0x1f, 0x2068 <perf_unwind_perl+0x2068>
    1b54:      	ldrb	w8, [x22, #0x1b]
    1b58:      	mov	w9, #0x8                // =8
    1b5c:      	mov	w10, #0x70              // =112
    1b60:      	add	x11, sp, #0x30
    1b64:      	add	x0, sp, #0x30
    1b68:      	mov	w1, #0x8                // =8
    1b6c:      	add	x8, x25, x8
    1b70:      	ldrb	w8, [x22, #0x1b]
    1b74:      	add	x2, x25, x8
    1b78:      	blr	x10
    1b7c:      	cbnz	x0, 0x1a74 <perf_unwind_perl+0x1a74>
    1b80:      	ldr	x8, [sp, #0x30]
    1b84:      	mov	w9, #0x8                // =8
    1b88:      	mov	w10, #0x70              // =112
    1b8c:      	add	x11, sp, #0x70
    1b90:      	add	x0, sp, #0x70
    1b94:      	mov	w1, #0x8                // =8
    1b98:      	cmp	x8, #0x0
    1b9c:      	mov	w8, #0x3                // =3
    1ba0:      	csinc	w29, w8, wzr, ne
    1ba4:      	ldrb	w8, [x22, #0x1c]
    1ba8:      	add	x8, x25, x8
    1bac:      	ldrb	w8, [x22, #0x1c]
    1bb0:      	add	x2, x25, x8
    1bb4:      	blr	x10
    1bb8:      	cbnz	x0, 0x1a74 <perf_unwind_perl+0x1a74>
    1bbc:      	str	x24, [sp, #0x10]
    1bc0:      	ldr	x24, [sp, #0x70]
    1bc4:      	mov	w9, #0x4                // =4
    1bc8:      	mov	w10, #0x70              // =112
    1bcc:      	add	x11, sp, #0xb8
    1bd0:      	add	x0, sp, #0xb8
    1bd4:      	ldrb	w8, [x22, #0x1e]
    1bd8:      	mov	w1, #0x4                // =4
    1bdc:      	add	x8, x24, x8
    1be0:      	ldrb	w8, [x22, #0x1e]
    1be4:      	add	x2, x24, x8
    1be8:      	blr	x10
    1bec:      	cbz	x0, 0x1c80 <perf_unwind_perl+0x1c80>
    1bf0:      	ldr	w8, [x23]
    1bf4:      	cbnz	w8, 0x3404 <perf_unwind_perl+0x3404>
    1bf8:      	mov	w8, #0x14               // =20
    1bfc:      	adrp	x0, 0x1000 <perf_unwind_perl+0x1000>
    1c00:      	add	x9, sp, #0xbc
    1c04:      	str	w8, [sp, #0xbc]
    1c08:      	mov	w8, #0x1                // =1
    1c0c:      	add	x1, sp, #0xbc
    1c10:      	ldr	x0, [x0]
    1c14:      	blr	x8
    1c18:      	cbz	x0, 0x1e08 <perf_unwind_perl+0x1e08>
    1c1c:      	ldr	x8, [x0]
    1c20:      	ldr	x24, [sp, #0x10]
    1c24:      	add	x8, x8, #0x1
    1c28:      	str	x8, [x0]
    1c2c:      	b	0x1a74 <perf_unwind_perl+0x1a74>
    1c30:      	ldr	w8, [x23]
    1c34:      	cbz	w8, 0x2068 <perf_unwind_perl+0x2068>
    1c38:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    1c3c:      	add	x8, x8, #0x0
    1c40:      	add	x0, sp, #0x30
    1c44:      	ldp	x9, x10, [x8, #0x10]
    1c48:      	mov	w1, #0x2e               // =46
    1c4c:      	stp	x9, x10, [sp, #0x40]
    1c50:      	ldr	x9, [x8, #0x20]
    1c54:      	add	x10, sp, #0x30
    1c58:      	str	x9, [sp, #0x50]
    1c5c:      	ldur	x9, [x8, #0x26]
    1c60:      	stur	x9, [sp, #0x56]
    1c64:      	ldp	x9, x8, [x8]
    1c68:      	stp	x9, x8, [sp, #0x30]
    1c6c:      	mov	w8, #0x2e               // =46
    1c70:      	mov	w9, #0x6                // =6
    1c74:      	ldr	w2, [sp, #0xa8]
    1c78:      	blr	x9
    1c7c:      	b	0x2068 <perf_unwind_perl+0x2068>
    1c80:      	ldr	w8, [sp, #0xb8]
    1c84:      	and	w8, w8, #0x1f
    1c88:      	cmp	w8, #0xd
    1c8c:      	b.ne	0x1e54 <perf_unwind_perl+0x1e54>
    1c90:      	ldrb	w8, [x22, #0x1f]
    1c94:      	mov	w9, #0x8                // =8
    1c98:      	mov	w10, #0x70              // =112
    1c9c:      	add	x11, sp, #0xa8
    1ca0:      	add	x0, sp, #0xa8
    1ca4:      	mov	w1, #0x8                // =8
    1ca8:      	add	x8, x24, x8
    1cac:      	ldrb	w8, [x22, #0x1f]
    1cb0:      	add	x2, x24, x8
    1cb4:      	blr	x10
    1cb8:      	cbnz	x0, 0x1bf0 <perf_unwind_perl+0x1bf0>
    1cbc:      	ldr	x8, [sp, #0xa8]
    1cc0:      	ldrb	w9, [x22, #0x21]
    1cc4:      	mov	w10, #0x70              // =112
    1cc8:      	add	x11, sp, #0xa4
    1ccc:      	add	x0, sp, #0xa4
    1cd0:      	mov	w1, #0x4                // =4
    1cd4:      	add	x8, x8, x9
    1cd8:      	mov	w9, #0x4                // =4
    1cdc:      	ldr	x8, [sp, #0xa8]
    1ce0:      	ldrb	w9, [x22, #0x21]
    1ce4:      	add	x2, x8, x9
    1ce8:      	blr	x10
    1cec:      	cbnz	x0, 0x1bf0 <perf_unwind_perl+0x1bf0>
    1cf0:      	ldrb	w8, [sp, #0xa5]
    1cf4:      	tbnz	w8, #0x7, 0x1fc8 <perf_unwind_perl+0x1fc8>
    1cf8:      	ldr	x8, [sp, #0xa8]
    1cfc:      	ldrb	w9, [x22, #0x22]
    1d00:      	mov	w10, #0x70              // =112
    1d04:      	add	x11, sp, #0x98
    1d08:      	add	x0, sp, #0x98
    1d0c:      	mov	w1, #0x8                // =8
    1d10:      	add	x8, x8, x9
    1d14:      	mov	w9, #0x8                // =8
    1d18:      	ldr	x8, [sp, #0xa8]
    1d1c:      	ldrb	w9, [x22, #0x22]
    1d20:      	add	x2, x8, x9
    1d24:      	blr	x10
    1d28:      	cbnz	x0, 0x1bf0 <perf_unwind_perl+0x1bf0>
    1d2c:      	ldr	x8, [sp, #0x98]
    1d30:      	cbz	x8, 0x1bf0 <perf_unwind_perl+0x1bf0>
    1d34:      	ldr	w9, [x23]
    1d38:      	cbnz	w9, 0x4c84 <perf_unwind_perl+0x4c84>
    1d3c:      	ldrb	w9, [x22, #0x1e]
    1d40:      	mov	w10, #0x70              // =112
    1d44:      	add	x11, sp, #0x94
    1d48:      	add	x0, sp, #0x94
    1d4c:      	mov	w1, #0x4                // =4
    1d50:      	add	x8, x8, x9
    1d54:      	mov	w9, #0x4                // =4
    1d58:      	ldr	x8, [sp, #0x98]
    1d5c:      	ldrb	w9, [x22, #0x1e]
    1d60:      	add	x2, x8, x9
    1d64:      	blr	x10
    1d68:      	cbnz	x0, 0x1bf0 <perf_unwind_perl+0x1bf0>
    1d6c:      	ldr	w8, [sp, #0x94]
    1d70:      	mov	w9, #0x801f             // =32799
    1d74:      	and	w8, w8, w9
    1d78:      	mov	w9, #0x8009             // =32777
    1d7c:      	cmp	w8, w9
    1d80:      	b.ne	0x2d14 <perf_unwind_perl+0x2d14>
    1d84:      	ldr	x8, [sp, #0x98]
    1d88:      	ldrb	w9, [x22, #0x20]
    1d8c:      	mov	w10, #0x70              // =112
    1d90:      	add	x11, sp, #0x88
    1d94:      	add	x0, sp, #0x88
    1d98:      	mov	w1, #0x8                // =8
    1d9c:      	add	x8, x8, x9
    1da0:      	mov	w9, #0x8                // =8
    1da4:      	ldr	x8, [sp, #0x98]
    1da8:      	ldrb	w9, [x22, #0x20]
    1dac:      	add	x2, x8, x9
    1db0:      	blr	x10
    1db4:      	cbnz	x0, 0x1bf0 <perf_unwind_perl+0x1bf0>
    1db8:      	ldr	x8, [sp, #0x88]
    1dbc:      	ldrb	w9, [x22, #0x23]
    1dc0:      	mov	w10, #0x70              // =112
    1dc4:      	add	x11, sp, #0x80
    1dc8:      	add	x0, sp, #0x80
    1dcc:      	mov	w1, #0x8                // =8
    1dd0:      	add	x8, x8, x9
    1dd4:      	mov	w9, #0x8                // =8
    1dd8:      	ldr	x8, [sp, #0x88]
    1ddc:      	ldrb	w9, [x22, #0x23]
    1de0:      	add	x2, x8, x9
    1de4:      	blr	x10
    1de8:      	cbnz	x0, 0x1bf0 <perf_unwind_perl+0x1bf0>
    1dec:      	ldr	x8, [sp, #0x80]
    1df0:      	str	x8, [sp, #0x8]
    1df4:      	cbz	x8, 0x3c7c <perf_unwind_perl+0x3c7c>
    1df8:      	ldr	w8, [x23]
    1dfc:      	cbnz	w8, 0x663c <perf_unwind_perl+0x663c>
    1e00:      	ldr	x24, [sp, #0x10]
    1e04:      	b	0x3c90 <perf_unwind_perl+0x3c90>
    1e08:      	ldr	w8, [x23]
    1e0c:      	cbz	w8, 0x1e5c <perf_unwind_perl+0x1e5c>
    1e10:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    1e14:      	add	x8, x8, #0x0
    1e18:      	add	x0, sp, #0x30
    1e1c:      	ldp	x9, x10, [x8, #0x10]
    1e20:      	mov	w1, #0x2e               // =46
    1e24:      	stp	x9, x10, [sp, #0x40]
    1e28:      	ldr	x9, [x8, #0x20]
    1e2c:      	add	x10, sp, #0x30
    1e30:      	str	x9, [sp, #0x50]
    1e34:      	ldur	x9, [x8, #0x26]
    1e38:      	stur	x9, [sp, #0x56]
    1e3c:      	ldp	x9, x8, [x8]
    1e40:      	stp	x9, x8, [sp, #0x30]
    1e44:      	mov	w8, #0x2e               // =46
    1e48:      	mov	w9, #0x6                // =6
    1e4c:      	ldr	w2, [sp, #0xbc]
    1e50:      	b	0x3be4 <perf_unwind_perl+0x3be4>
    1e54:      	ldr	w8, [x23]
    1e58:      	cbnz	w8, 0x3bac <perf_unwind_perl+0x3bac>
    1e5c:      	ldr	x24, [sp, #0x10]
    1e60:      	b	0x1a74 <perf_unwind_perl+0x1a74>
    1e64:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    1e68:      	add	x8, x8, #0x0
    1e6c:      	add	x0, sp, #0x30
    1e70:      	ldp	x9, x10, [x8, #0x10]
    1e74:      	mov	w1, #0x2e               // =46
    1e78:      	stp	x9, x10, [sp, #0x40]
    1e7c:      	ldr	x9, [x8, #0x20]
    1e80:      	add	x10, sp, #0x30
    1e84:      	str	x9, [sp, #0x50]
    1e88:      	ldur	x9, [x8, #0x26]
    1e8c:      	stur	x9, [sp, #0x56]
    1e90:      	ldp	x9, x8, [x8]
    1e94:      	stp	x9, x8, [sp, #0x30]
    1e98:      	mov	w8, #0x2e               // =46
    1e9c:      	mov	w9, #0x6                // =6
    1ea0:      	ldr	w2, [sp, #0xa8]
    1ea4:      	blr	x9
    1ea8:      	b	0x1a20 <perf_unwind_perl+0x1a20>
    1eac:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    1eb0:      	add	x8, x8, #0x0
    1eb4:      	add	x0, sp, #0x30
    1eb8:      	ldp	x9, x10, [x8, #0x10]
    1ebc:      	mov	w1, #0x2d               // =45
    1ec0:      	stp	x9, x10, [sp, #0x40]
    1ec4:      	ldr	x9, [x8, #0x20]
    1ec8:      	add	x10, sp, #0x30
    1ecc:      	str	x9, [sp, #0x50]
    1ed0:      	ldur	x9, [x8, #0x25]
    1ed4:      	stur	x9, [sp, #0x55]
    1ed8:      	ldp	x9, x8, [x8]
    1edc:      	stp	x9, x8, [sp, #0x30]
    1ee0:      	mov	w8, #0x2d               // =45
    1ee4:      	mov	w9, #0x6                // =6
    1ee8:      	blr	x9
    1eec:      	b	0x1f4 <perf_unwind_perl+0x1f4>
    1ef0:      	mov	w8, #0xa                // =10
    1ef4:      	add	x0, sp, #0x30
    1ef8:      	mov	w1, #0x2a               // =42
    1efc:      	strh	w8, [sp, #0x58]
    1f00:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    1f04:      	add	x8, x8, #0x0
    1f08:      	mov	x2, x25
    1f0c:      	ldp	x9, x10, [x8, #0x10]
    1f10:      	stp	x9, x10, [sp, #0x40]
    1f14:      	ldr	x9, [x8, #0x20]
    1f18:      	add	x10, sp, #0x30
    1f1c:      	str	x9, [sp, #0x50]
    1f20:      	ldp	x8, x9, [x8]
    1f24:      	stp	x8, x9, [sp, #0x30]
    1f28:      	mov	w8, #0x2a               // =42
    1f2c:      	mov	w9, #0x6                // =6
    1f30:      	blr	x9
    1f34:      	b	0x1a7c <perf_unwind_perl+0x1a7c>
    1f38:      	ldr	w8, [x23]
    1f3c:      	ldr	x24, [sp, #0x10]
    1f40:      	cbz	w8, 0xcd8 <perf_unwind_perl+0xcd8>
    1f44:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    1f48:      	add	x8, x8, #0x0
    1f4c:      	add	x0, sp, #0x30
    1f50:      	ldp	x9, x10, [x8, #0x10]
    1f54:      	mov	w1, #0x26               // =38
    1f58:      	stp	x9, x10, [sp, #0x40]
    1f5c:      	ldur	x9, [x8, #0x1e]
    1f60:      	add	x10, sp, #0x30
    1f64:      	stur	x9, [sp, #0x4e]
    1f68:      	ldp	x8, x9, [x8]
    1f6c:      	stp	x8, x9, [sp, #0x30]
    1f70:      	mov	w8, #0x26               // =38
    1f74:      	mov	w9, #0x6                // =6
    1f78:      	ldr	w2, [sp, #0x94]
    1f7c:      	blr	x9
    1f80:      	b	0xcd8 <perf_unwind_perl+0xcd8>
    1f84:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    1f88:      	add	x8, x8, #0x0
    1f8c:      	add	x0, sp, #0x30
    1f90:      	ldp	x9, x10, [x8, #0x10]
    1f94:      	mov	w1, #0x26               // =38
    1f98:      	stp	x9, x10, [sp, #0x40]
    1f9c:      	ldur	x9, [x8, #0x1e]
    1fa0:      	add	x10, sp, #0x30
    1fa4:      	stur	x9, [sp, #0x4e]
    1fa8:      	ldp	x8, x9, [x8]
    1fac:      	stp	x8, x9, [sp, #0x30]
    1fb0:      	mov	w8, #0x26               // =38
    1fb4:      	mov	w9, #0x6                // =6
    1fb8:      	ldr	x2, [sp, #0xa8]
    1fbc:      	ldr	w3, [sp, #0x80]
    1fc0:      	blr	x9
    1fc4:      	b	0x9ec <perf_unwind_perl+0x9ec>
    1fc8:      	ldr	w8, [x23]
    1fcc:      	cbz	w8, 0x1e5c <perf_unwind_perl+0x1e5c>
    1fd0:      	adrp	x8, 0x1000 <perf_unwind_perl+0x1000>
    1fd4:      	add	x8, x8, #0x0
    1fd8:      	add	x0, sp, #0x30
    1fdc:      	ldp	x9, x10, [x8, #0x10]
    1fe0:      	mov	w1, #0x26               // =38
    1fe4:      	stp	x9, x10, [sp, #0x40]
    1fe8:      	ldur	x9, [x8, #0x1e]
    1fec:      	add	x10, sp, #0x30
    1ff0:      	stur	x9, [sp, #0x4e]
    1ff4:      	ldp	x8, x9, [x8]
    1ff8:      	stp	x8, x9, [sp, #0x30]
    1ffc:      	mov	w8, #0x26               // =38
    2000:      	mov	w9, #0x6                // =6
    2004:      	ldr	w2, [sp, #0xb8]
    2008:      	ldr	w3, [sp, #0xa4]
    200c:      	blr	x9
    2010:      	ldr	x24, [sp, #0x10]
    2014:      	b	0x1a74 <perf_unwind_perl+0x1a74>
    2018:      	mov	w8, #0xa                // =10
    201c:      	add	x10, sp, #0x30
    2020:      	add	x0, sp, #0x30
    2024:      	strh	w8, [sp, #0x40]
    2028:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    202c:      	add	x8, x8, #0x0
    2030:      	mov	w1, #0x12               // =18
    2034:      	ldp	x9, x8, [x8]
    2038:      	stp	x9, x8, [sp, #0x30]
    203c:      	mov	w8, #0x12               // =18
    2040:      	mov	w9, #0x6                // =6
    2044:      	ldrb	w2, [sp, #0x7c]
    2048:      	blr	x9
    204c:      	ldrb	w8, [sp, #0x7c]
    2050:      	and	w9, w8, #0xf
    2054:      	sub	w10, w9, #0x9
    2058:      	cmp	w10, #0x2
    205c:      	b.lo	0x1b4c <perf_unwind_perl+0x1b4c>
    2060:      	cmp	w9, #0xc
    2064:      	b.ne	0x2140 <perf_unwind_perl+0x2140>
    2068:      	mov	w29, #0x3               // =3
    206c:      	ldrb	w8, [x22, #0x1d]
    2070:      	ldr	x9, [x21, #0xf40]
    2074:      	adrp	x0, 0x2000 <perf_unwind_perl+0x2000>
    2078:      	add	x1, sp, #0xa8
    207c:      	sub	x8, x9, x8
    2080:      	add	x9, sp, #0xa8
    2084:      	str	x8, [x21, #0xf40]
    2088:      	mov	w8, #0x10               // =16
    208c:      	str	w8, [sp, #0xa8]
    2090:      	mov	w8, #0x1                // =1
    2094:      	ldr	x0, [x0]
    2098:      	blr	x8
    209c:      	cbz	x0, 0x20b4 <perf_unwind_perl+0x20b4>
    20a0:      	ldr	x8, [x0]
    20a4:      	add	x8, x8, #0x1
    20a8:      	str	x8, [x0]
    20ac:      	ldr	x9, [sp, #0x18]
    20b0:      	b	0x20c0 <perf_unwind_perl+0x20c0>
    20b4:      	ldr	w8, [x23]
    20b8:      	ldr	x9, [sp, #0x18]
    20bc:      	cbnz	w8, 0x2534 <perf_unwind_perl+0x2534>
    20c0:      	cmp	w29, #0x3
    20c4:      	b.ne	0x563c <perf_unwind_perl+0x563c>
    20c8:      	ldr	x25, [x21, #0xf40]
    20cc:      	cmp	x25, x9
    20d0:      	b.lo	0xac <perf_unwind_perl+0xac>
    20d4:      	ldrb	w8, [x22, #0x19]
    20d8:      	mov	w9, #0x1                // =1
    20dc:      	mov	w10, #0x70              // =112
    20e0:      	add	x11, sp, #0x7c
    20e4:      	add	x0, sp, #0x7c
    20e8:      	mov	w1, #0x1                // =1
    20ec:      	add	x8, x25, x8
    20f0:      	ldrb	w8, [x22, #0x19]
    20f4:      	add	x2, x25, x8
    20f8:      	blr	x10
    20fc:      	cbz	x0, 0x21bc <perf_unwind_perl+0x21bc>
    2100:      	ldr	w8, [x23]
    2104:      	cbnz	w8, 0x25c0 <perf_unwind_perl+0x25c0>
    2108:      	mov	w8, #0x13               // =19
    210c:      	adrp	x0, 0x2000 <perf_unwind_perl+0x2000>
    2110:      	add	x9, sp, #0xa8
    2114:      	str	w8, [sp, #0xa8]
    2118:      	mov	w8, #0x1                // =1
    211c:      	add	x1, sp, #0xa8
    2120:      	ldr	x0, [x0]
    2124:      	blr	x8
    2128:      	cbz	x0, 0x2218 <perf_unwind_perl+0x2218>
    212c:      	ldr	x8, [x0]
    2130:      	mov	w29, #0x3               // =3
    2134:      	add	x8, x8, #0x1
    2138:      	str	x8, [x0]
    213c:      	b	0x2760 <perf_unwind_perl+0x2760>
    2140:      	ldr	x8, [x24]
    2144:      	mov	w29, #0x3               // =3
    2148:      	cbnz	x8, 0x206c <perf_unwind_perl+0x206c>
    214c:      	ldrb	w8, [x22, #0x1a]
    2150:      	mov	w9, #0x8                // =8
    2154:      	mov	w10, #0x70              // =112
    2158:      	mov	x0, x24
    215c:      	mov	w1, #0x8                // =8
    2160:      	add	x8, x25, x8
    2164:      	ldrb	w8, [x22, #0x1a]
    2168:      	add	x2, x25, x8
    216c:      	blr	x10
    2170:      	cbnz	x0, 0x1a74 <perf_unwind_perl+0x1a74>
    2174:      	ldr	w8, [x23]
    2178:      	cbz	w8, 0x206c <perf_unwind_perl+0x206c>
    217c:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    2180:      	add	x8, x8, #0x0
    2184:      	add	x0, sp, #0x30
    2188:      	ldp	x9, x10, [x8]
    218c:      	mov	w1, #0x1e               // =30
    2190:      	stp	x9, x10, [sp, #0x30]
    2194:      	ldr	x9, [x8, #0x10]
    2198:      	ldur	x8, [x8, #0x16]
    219c:      	add	x10, sp, #0x30
    21a0:      	str	x9, [sp, #0x40]
    21a4:      	stur	x8, [sp, #0x46]
    21a8:      	mov	w8, #0x1e               // =30
    21ac:      	mov	w9, #0x6                // =6
    21b0:      	ldr	x2, [x24]
    21b4:      	blr	x9
    21b8:      	b	0x206c <perf_unwind_perl+0x206c>
    21bc:      	ldr	w8, [x23]
    21c0:      	cbnz	w8, 0x270c <perf_unwind_perl+0x270c>
    21c4:      	ldrb	w8, [sp, #0x7c]
    21c8:      	and	w9, w8, #0xf
    21cc:      	sub	w10, w9, #0x9
    21d0:      	cmp	w10, #0x2
    21d4:      	b.hs	0x2754 <perf_unwind_perl+0x2754>
    21d8:      	sxtb	w8, w8
    21dc:      	tbnz	w8, #0x1f, 0x275c <perf_unwind_perl+0x275c>
    21e0:      	ldrb	w8, [x22, #0x1b]
    21e4:      	str	x24, [sp, #0x10]
    21e8:      	mov	w9, #0x8                // =8
    21ec:      	mov	w10, #0x70              // =112
    21f0:      	add	x11, sp, #0x30
    21f4:      	add	x0, sp, #0x30
    21f8:      	mov	w1, #0x8                // =8
    21fc:      	add	x8, x25, x8
    2200:      	ldrb	w8, [x22, #0x1b]
    2204:      	add	x2, x25, x8
    2208:      	blr	x10
    220c:      	cbz	x0, 0x2268 <perf_unwind_perl+0x2268>
    2210:      	ldr	x24, [sp, #0x10]
    2214:      	b	0x2100 <perf_unwind_perl+0x2100>
    2218:      	ldr	w8, [x23]
    221c:      	cbz	w8, 0x275c <perf_unwind_perl+0x275c>
    2220:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    2224:      	add	x8, x8, #0x0
    2228:      	add	x0, sp, #0x30
    222c:      	ldp	x9, x10, [x8, #0x10]
    2230:      	mov	w1, #0x2e               // =46
    2234:      	stp	x9, x10, [sp, #0x40]
    2238:      	ldr	x9, [x8, #0x20]
    223c:      	add	x10, sp, #0x30
    2240:      	str	x9, [sp, #0x50]
    2244:      	ldur	x9, [x8, #0x26]
    2248:      	stur	x9, [sp, #0x56]
    224c:      	ldp	x9, x8, [x8]
    2250:      	stp	x9, x8, [sp, #0x30]
    2254:      	mov	w8, #0x2e               // =46
    2258:      	mov	w9, #0x6                // =6
    225c:      	ldr	w2, [sp, #0xa8]
    2260:      	blr	x9
    2264:      	b	0x275c <perf_unwind_perl+0x275c>
    2268:      	ldr	x8, [sp, #0x30]
    226c:      	mov	w9, #0x8                // =8
    2270:      	mov	w10, #0x70              // =112
    2274:      	add	x11, sp, #0x70
    2278:      	add	x0, sp, #0x70
    227c:      	mov	w1, #0x8                // =8
    2280:      	cmp	x8, #0x0
    2284:      	mov	w8, #0x3                // =3
    2288:      	csinc	w29, w8, wzr, ne
    228c:      	ldrb	w8, [x22, #0x1c]
    2290:      	add	x8, x25, x8
    2294:      	ldrb	w8, [x22, #0x1c]
    2298:      	add	x2, x25, x8
    229c:      	blr	x10
    22a0:      	ldr	x24, [sp, #0x10]
    22a4:      	cbnz	x0, 0x2100 <perf_unwind_perl+0x2100>
    22a8:      	ldr	x24, [sp, #0x70]
    22ac:      	ldrb	w8, [x22, #0x1e]
    22b0:      	mov	w9, #0x4                // =4
    22b4:      	mov	w10, #0x70              // =112
    22b8:      	add	x11, sp, #0xb8
    22bc:      	add	x0, sp, #0xb8
    22c0:      	mov	w1, #0x4                // =4
    22c4:      	add	x8, x24, x8
    22c8:      	ldrb	w8, [x22, #0x1e]
    22cc:      	add	x2, x24, x8
    22d0:      	blr	x10
    22d4:      	cbz	x0, 0x2318 <perf_unwind_perl+0x2318>
    22d8:      	ldr	w8, [x23]
    22dc:      	cbnz	w8, 0x3b68 <perf_unwind_perl+0x3b68>
    22e0:      	mov	w8, #0x14               // =20
    22e4:      	adrp	x0, 0x2000 <perf_unwind_perl+0x2000>
    22e8:      	add	x9, sp, #0xbc
    22ec:      	str	w8, [sp, #0xbc]
    22f0:      	mov	w8, #0x1                // =1
    22f4:      	add	x1, sp, #0xbc
    22f8:      	ldr	x0, [x0]
    22fc:      	blr	x8
    2300:      	cbz	x0, 0x24a0 <perf_unwind_perl+0x24a0>
    2304:      	ldr	x8, [x0]
    2308:      	ldr	x24, [sp, #0x10]
    230c:      	add	x8, x8, #0x1
    2310:      	str	x8, [x0]
    2314:      	b	0x2100 <perf_unwind_perl+0x2100>
    2318:      	ldr	w8, [sp, #0xb8]
    231c:      	and	w8, w8, #0x1f
    2320:      	cmp	w8, #0xd
    2324:      	b.ne	0x24ec <perf_unwind_perl+0x24ec>
    2328:      	ldrb	w8, [x22, #0x1f]
    232c:      	mov	w9, #0x8                // =8
    2330:      	mov	w10, #0x70              // =112
    2334:      	add	x11, sp, #0xa8
    2338:      	add	x0, sp, #0xa8
    233c:      	mov	w1, #0x8                // =8
    2340:      	add	x8, x24, x8
    2344:      	ldrb	w8, [x22, #0x1f]
    2348:      	add	x2, x24, x8
    234c:      	blr	x10
    2350:      	cbnz	x0, 0x22d8 <perf_unwind_perl+0x22d8>
    2354:      	ldr	x8, [sp, #0xa8]
    2358:      	ldrb	w9, [x22, #0x21]
    235c:      	mov	w10, #0x70              // =112
    2360:      	add	x11, sp, #0xa4
    2364:      	add	x0, sp, #0xa4
    2368:      	mov	w1, #0x4                // =4
    236c:      	add	x8, x8, x9
    2370:      	mov	w9, #0x4                // =4
    2374:      	ldr	x8, [sp, #0xa8]
    2378:      	ldrb	w9, [x22, #0x21]
    237c:      	add	x2, x8, x9
    2380:      	blr	x10
    2384:      	cbnz	x0, 0x22d8 <perf_unwind_perl+0x22d8>
    2388:      	ldrb	w8, [sp, #0xa5]
    238c:      	tbnz	w8, #0x7, 0x26bc <perf_unwind_perl+0x26bc>
    2390:      	ldr	x8, [sp, #0xa8]
    2394:      	ldrb	w9, [x22, #0x22]
    2398:      	mov	w10, #0x70              // =112
    239c:      	add	x11, sp, #0x98
    23a0:      	add	x0, sp, #0x98
    23a4:      	mov	w1, #0x8                // =8
    23a8:      	add	x8, x8, x9
    23ac:      	mov	w9, #0x8                // =8
    23b0:      	ldr	x8, [sp, #0xa8]
    23b4:      	ldrb	w9, [x22, #0x22]
    23b8:      	add	x2, x8, x9
    23bc:      	blr	x10
    23c0:      	cbnz	x0, 0x22d8 <perf_unwind_perl+0x22d8>
    23c4:      	ldr	x8, [sp, #0x98]
    23c8:      	cbz	x8, 0x22d8 <perf_unwind_perl+0x22d8>
    23cc:      	ldr	w9, [x23]
    23d0:      	cbnz	w9, 0x5510 <perf_unwind_perl+0x5510>
    23d4:      	ldrb	w9, [x22, #0x1e]
    23d8:      	mov	w10, #0x70              // =112
    23dc:      	add	x11, sp, #0x94
    23e0:      	add	x0, sp, #0x94
    23e4:      	mov	w1, #0x4                // =4
    23e8:      	add	x8, x8, x9
    23ec:      	mov	w9, #0x4                // =4
    23f0:      	ldr	x8, [sp, #0x98]
    23f4:      	ldrb	w9, [x22, #0x1e]
    23f8:      	add	x2, x8, x9
    23fc:      	blr	x10
    2400:      	cbnz	x0, 0x22d8 <perf_unwind_perl+0x22d8>
    2404:      	ldr	w8, [sp, #0x94]
    2408:      	mov	w9, #0x801f             // =32799
    240c:      	and	w8, w8, w9
    2410:      	mov	w9, #0x8009             // =32777
    2414:      	cmp	w8, w9
    2418:      	b.ne	0x3490 <perf_unwind_perl+0x3490>
    241c:      	ldr	x8, [sp, #0x98]
    2420:      	ldrb	w9, [x22, #0x20]
    2424:      	mov	w10, #0x70              // =112
    2428:      	add	x11, sp, #0x88
    242c:      	add	x0, sp, #0x88
    2430:      	mov	w1, #0x8                // =8
    2434:      	add	x8, x8, x9
    2438:      	mov	w9, #0x8                // =8
    243c:      	ldr	x8, [sp, #0x98]
    2440:      	ldrb	w9, [x22, #0x20]
    2444:      	add	x2, x8, x9
    2448:      	blr	x10
    244c:      	cbnz	x0, 0x22d8 <perf_unwind_perl+0x22d8>
    2450:      	ldr	x8, [sp, #0x88]
    2454:      	ldrb	w9, [x22, #0x23]
    2458:      	mov	w10, #0x70              // =112
    245c:      	add	x11, sp, #0x80
    2460:      	add	x0, sp, #0x80
    2464:      	mov	w1, #0x8                // =8
    2468:      	add	x8, x8, x9
    246c:      	mov	w9, #0x8                // =8
    2470:      	ldr	x8, [sp, #0x88]
    2474:      	ldrb	w9, [x22, #0x23]
    2478:      	add	x2, x8, x9
    247c:      	blr	x10
    2480:      	cbnz	x0, 0x22d8 <perf_unwind_perl+0x22d8>
    2484:      	ldr	x8, [sp, #0x80]
    2488:      	str	x8, [sp, #0x8]
    248c:      	cbz	x8, 0x43e4 <perf_unwind_perl+0x43e4>
    2490:      	ldr	w8, [x23]
    2494:      	cbnz	w8, 0x680c <perf_unwind_perl+0x680c>
    2498:      	ldr	x24, [sp, #0x10]
    249c:      	b	0x43f8 <perf_unwind_perl+0x43f8>
    24a0:      	ldr	w8, [x23]
    24a4:      	cbz	w8, 0x2210 <perf_unwind_perl+0x2210>
    24a8:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    24ac:      	add	x8, x8, #0x0
    24b0:      	add	x0, sp, #0x30
    24b4:      	ldp	x9, x10, [x8, #0x10]
    24b8:      	mov	w1, #0x2e               // =46
    24bc:      	stp	x9, x10, [sp, #0x40]
    24c0:      	ldr	x9, [x8, #0x20]
    24c4:      	add	x10, sp, #0x30
    24c8:      	str	x9, [sp, #0x50]
    24cc:      	ldur	x9, [x8, #0x26]
    24d0:      	stur	x9, [sp, #0x56]
    24d4:      	ldp	x9, x8, [x8]
    24d8:      	stp	x9, x8, [sp, #0x30]
    24dc:      	mov	w8, #0x2e               // =46
    24e0:      	mov	w9, #0x6                // =6
    24e4:      	ldr	w2, [sp, #0xbc]
    24e8:      	b	0x252c <perf_unwind_perl+0x252c>
    24ec:      	ldr	w8, [x23]
    24f0:      	cbz	w8, 0x2210 <perf_unwind_perl+0x2210>
    24f4:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    24f8:      	add	x8, x8, #0x0
    24fc:      	add	x0, sp, #0x30
    2500:      	ldp	x9, x10, [x8]
    2504:      	mov	w1, #0x1e               // =30
    2508:      	stp	x9, x10, [sp, #0x30]
    250c:      	ldr	x9, [x8, #0x10]
    2510:      	ldur	x8, [x8, #0x16]
    2514:      	add	x10, sp, #0x30
    2518:      	str	x9, [sp, #0x40]
    251c:      	stur	x8, [sp, #0x46]
    2520:      	mov	w8, #0x1e               // =30
    2524:      	mov	w9, #0x6                // =6
    2528:      	ldr	w2, [sp, #0xb8]
    252c:      	blr	x9
    2530:      	b	0x2210 <perf_unwind_perl+0x2210>
    2534:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    2538:      	add	x8, x8, #0x0
    253c:      	add	x0, sp, #0x30
    2540:      	ldp	x9, x10, [x8, #0x10]
    2544:      	mov	w1, #0x2e               // =46
    2548:      	stp	x9, x10, [sp, #0x40]
    254c:      	ldr	x9, [x8, #0x20]
    2550:      	add	x10, sp, #0x30
    2554:      	str	x9, [sp, #0x50]
    2558:      	ldur	x9, [x8, #0x26]
    255c:      	stur	x9, [sp, #0x56]
    2560:      	ldp	x9, x8, [x8]
    2564:      	stp	x9, x8, [sp, #0x30]
    2568:      	mov	w8, #0x2e               // =46
    256c:      	mov	w9, #0x6                // =6
    2570:      	ldr	w2, [sp, #0xa8]
    2574:      	blr	x9
    2578:      	b	0x20ac <perf_unwind_perl+0x20ac>
    257c:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    2580:      	add	x8, x8, #0x0
    2584:      	add	x0, sp, #0x30
    2588:      	ldp	x9, x10, [x8, #0x10]
    258c:      	mov	w1, #0x2d               // =45
    2590:      	stp	x9, x10, [sp, #0x40]
    2594:      	ldr	x9, [x8, #0x20]
    2598:      	add	x10, sp, #0x30
    259c:      	str	x9, [sp, #0x50]
    25a0:      	ldur	x9, [x8, #0x25]
    25a4:      	stur	x9, [sp, #0x55]
    25a8:      	ldp	x9, x8, [x8]
    25ac:      	stp	x9, x8, [sp, #0x30]
    25b0:      	mov	w8, #0x2d               // =45
    25b4:      	mov	w9, #0x6                // =6
    25b8:      	blr	x9
    25bc:      	b	0xe5c <perf_unwind_perl+0xe5c>
    25c0:      	mov	w8, #0xa                // =10
    25c4:      	add	x0, sp, #0x30
    25c8:      	mov	w1, #0x2a               // =42
    25cc:      	strh	w8, [sp, #0x58]
    25d0:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    25d4:      	add	x8, x8, #0x0
    25d8:      	mov	x2, x25
    25dc:      	ldp	x9, x10, [x8, #0x10]
    25e0:      	stp	x9, x10, [sp, #0x40]
    25e4:      	ldr	x9, [x8, #0x20]
    25e8:      	add	x10, sp, #0x30
    25ec:      	str	x9, [sp, #0x50]
    25f0:      	ldp	x8, x9, [x8]
    25f4:      	stp	x8, x9, [sp, #0x30]
    25f8:      	mov	w8, #0x2a               // =42
    25fc:      	mov	w9, #0x6                // =6
    2600:      	blr	x9
    2604:      	b	0x2108 <perf_unwind_perl+0x2108>
    2608:      	ldr	w8, [x23]
    260c:      	ldr	x24, [sp, #0x10]
    2610:      	cbz	w8, 0x131c <perf_unwind_perl+0x131c>
    2614:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    2618:      	add	x8, x8, #0x0
    261c:      	add	x0, sp, #0x30
    2620:      	ldp	x9, x10, [x8, #0x10]
    2624:      	mov	w1, #0x26               // =38
    2628:      	stp	x9, x10, [sp, #0x40]
    262c:      	ldur	x9, [x8, #0x1e]
    2630:      	add	x10, sp, #0x30
    2634:      	stur	x9, [sp, #0x4e]
    2638:      	ldp	x8, x9, [x8]
    263c:      	stp	x8, x9, [sp, #0x30]
    2640:      	mov	w8, #0x26               // =38
    2644:      	mov	w9, #0x6                // =6
    2648:      	ldr	w2, [sp, #0x94]
    264c:      	blr	x9
    2650:      	b	0x131c <perf_unwind_perl+0x131c>
    2654:      	add	x8, sp, #0x98
    2658:      	ldr	x8, [x8]
    265c:      	ldr	x24, [sp, #0x10]
    2660:      	str	x8, [sp, #0x8]
    2664:      	cbz	x8, 0xf0 <perf_unwind_perl+0xf0>
    2668:      	ldr	x24, [x24]
    266c:      	ldr	w8, [x23]
    2670:      	cbnz	w8, 0x4b4c <perf_unwind_perl+0x4b4c>
    2674:      	ldr	w8, [x21, #0x2c0]
    2678:      	cmp	w8, #0x7f
    267c:      	b.lo	0x4b98 <perf_unwind_perl+0x4b98>
    2680:      	ldr	w8, [x23]
    2684:      	cbnz	w8, 0x4d10 <perf_unwind_perl+0x4d10>
    2688:      	mov	w8, #0x2                // =2
    268c:      	adrp	x0, 0x2000 <perf_unwind_perl+0x2000>
    2690:      	add	x9, sp, #0xa8
    2694:      	str	w8, [sp, #0xa8]
    2698:      	mov	w8, #0x1                // =1
    269c:      	add	x1, sp, #0xa8
    26a0:      	ldr	x0, [x0]
    26a4:      	blr	x8
    26a8:      	cbz	x0, 0x2c64 <perf_unwind_perl+0x2c64>
    26ac:      	ldr	x8, [x0]
    26b0:      	add	x8, x8, #0x1
    26b4:      	str	x8, [x0]
    26b8:      	b	0x2c6c <perf_unwind_perl+0x2c6c>
    26bc:      	ldr	w8, [x23]
    26c0:      	cbz	w8, 0x2210 <perf_unwind_perl+0x2210>
    26c4:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    26c8:      	add	x8, x8, #0x0
    26cc:      	add	x0, sp, #0x30
    26d0:      	ldp	x9, x10, [x8, #0x10]
    26d4:      	mov	w1, #0x26               // =38
    26d8:      	stp	x9, x10, [sp, #0x40]
    26dc:      	ldur	x9, [x8, #0x1e]
    26e0:      	add	x10, sp, #0x30
    26e4:      	stur	x9, [sp, #0x4e]
    26e8:      	ldp	x8, x9, [x8]
    26ec:      	stp	x8, x9, [sp, #0x30]
    26f0:      	mov	w8, #0x26               // =38
    26f4:      	mov	w9, #0x6                // =6
    26f8:      	ldr	w2, [sp, #0xb8]
    26fc:      	ldr	w3, [sp, #0xa4]
    2700:      	blr	x9
    2704:      	ldr	x24, [sp, #0x10]
    2708:      	b	0x2100 <perf_unwind_perl+0x2100>
    270c:      	mov	w8, #0xa                // =10
    2710:      	add	x10, sp, #0x30
    2714:      	add	x0, sp, #0x30
    2718:      	strh	w8, [sp, #0x40]
    271c:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    2720:      	add	x8, x8, #0x0
    2724:      	mov	w1, #0x12               // =18
    2728:      	ldp	x9, x8, [x8]
    272c:      	stp	x9, x8, [sp, #0x30]
    2730:      	mov	w8, #0x12               // =18
    2734:      	mov	w9, #0x6                // =6
    2738:      	ldrb	w2, [sp, #0x7c]
    273c:      	blr	x9
    2740:      	ldrb	w8, [sp, #0x7c]
    2744:      	and	w9, w8, #0xf
    2748:      	sub	w10, w9, #0x9
    274c:      	cmp	w10, #0x2
    2750:      	b.lo	0x21d8 <perf_unwind_perl+0x21d8>
    2754:      	cmp	w9, #0xc
    2758:      	b.ne	0x2838 <perf_unwind_perl+0x2838>
    275c:      	mov	w29, #0x3               // =3
    2760:      	ldrb	w8, [x22, #0x1d]
    2764:      	ldr	x9, [x21, #0xf40]
    2768:      	adrp	x0, 0x2000 <perf_unwind_perl+0x2000>
    276c:      	add	x1, sp, #0xa8
    2770:      	sub	x8, x9, x8
    2774:      	add	x9, sp, #0xa8
    2778:      	str	x8, [x21, #0xf40]
    277c:      	mov	w8, #0x10               // =16
    2780:      	str	w8, [sp, #0xa8]
    2784:      	mov	w8, #0x1                // =1
    2788:      	ldr	x0, [x0]
    278c:      	blr	x8
    2790:      	cbz	x0, 0x27a8 <perf_unwind_perl+0x27a8>
    2794:      	ldr	x8, [x0]
    2798:      	add	x8, x8, #0x1
    279c:      	str	x8, [x0]
    27a0:      	ldr	x9, [sp, #0x18]
    27a4:      	b	0x27b4 <perf_unwind_perl+0x27b4>
    27a8:      	ldr	w8, [x23]
    27ac:      	ldr	x9, [sp, #0x18]
    27b0:      	cbnz	w8, 0x2c1c <perf_unwind_perl+0x2c1c>
    27b4:      	cmp	w29, #0x3
    27b8:      	b.ne	0x563c <perf_unwind_perl+0x563c>
    27bc:      	ldr	x25, [x21, #0xf40]
    27c0:      	cmp	x25, x9
    27c4:      	b.lo	0xac <perf_unwind_perl+0xac>
    27c8:      	ldrb	w8, [x22, #0x19]
    27cc:      	mov	w9, #0x1                // =1
    27d0:      	mov	w10, #0x70              // =112
    27d4:      	add	x11, sp, #0x7c
    27d8:      	add	x0, sp, #0x7c
    27dc:      	mov	w1, #0x1                // =1
    27e0:      	add	x8, x25, x8
    27e4:      	ldrb	w8, [x22, #0x19]
    27e8:      	add	x2, x25, x8
    27ec:      	blr	x10
    27f0:      	str	x24, [sp, #0x10]
    27f4:      	cbz	x0, 0x28b4 <perf_unwind_perl+0x28b4>
    27f8:      	ldr	w8, [x23]
    27fc:      	cbnz	w8, 0x2ccc <perf_unwind_perl+0x2ccc>
    2800:      	mov	w8, #0x13               // =19
    2804:      	adrp	x0, 0x2000 <perf_unwind_perl+0x2000>
    2808:      	add	x9, sp, #0xa8
    280c:      	str	w8, [sp, #0xa8]
    2810:      	mov	w8, #0x1                // =1
    2814:      	add	x1, sp, #0xa8
    2818:      	ldr	x0, [x0]
    281c:      	blr	x8
    2820:      	cbz	x0, 0x29ac <perf_unwind_perl+0x29ac>
    2824:      	ldr	x8, [x0]
    2828:      	mov	w29, #0x3               // =3
    282c:      	add	x8, x8, #0x1
    2830:      	str	x8, [x0]
    2834:      	b	0x2e5c <perf_unwind_perl+0x2e5c>
    2838:      	ldr	x8, [x24]
    283c:      	mov	w29, #0x3               // =3
    2840:      	cbnz	x8, 0x2760 <perf_unwind_perl+0x2760>
    2844:      	ldrb	w8, [x22, #0x1a]
    2848:      	mov	w9, #0x8                // =8
    284c:      	mov	w10, #0x70              // =112
    2850:      	mov	x0, x24
    2854:      	mov	w1, #0x8                // =8
    2858:      	add	x8, x25, x8
    285c:      	ldrb	w8, [x22, #0x1a]
    2860:      	add	x2, x25, x8
    2864:      	blr	x10
    2868:      	cbnz	x0, 0x2100 <perf_unwind_perl+0x2100>
    286c:      	ldr	w8, [x23]
    2870:      	cbz	w8, 0x2760 <perf_unwind_perl+0x2760>
    2874:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    2878:      	add	x8, x8, #0x0
    287c:      	add	x0, sp, #0x30
    2880:      	ldp	x9, x10, [x8]
    2884:      	mov	w1, #0x1e               // =30
    2888:      	stp	x9, x10, [sp, #0x30]
    288c:      	ldr	x9, [x8, #0x10]
    2890:      	ldur	x8, [x8, #0x16]
    2894:      	add	x10, sp, #0x30
    2898:      	str	x9, [sp, #0x40]
    289c:      	stur	x8, [sp, #0x46]
    28a0:      	mov	w8, #0x1e               // =30
    28a4:      	mov	w9, #0x6                // =6
    28a8:      	ldr	x2, [x24]
    28ac:      	blr	x9
    28b0:      	b	0x2760 <perf_unwind_perl+0x2760>
    28b4:      	ldr	w8, [x23]
    28b8:      	cbnz	w8, 0x2e08 <perf_unwind_perl+0x2e08>
    28bc:      	ldrb	w8, [sp, #0x7c]
    28c0:      	and	w9, w8, #0xf
    28c4:      	sub	w10, w9, #0x9
    28c8:      	cmp	w10, #0x2
    28cc:      	b.hs	0x2e50 <perf_unwind_perl+0x2e50>
    28d0:      	sxtb	w8, w8
    28d4:      	tbnz	w8, #0x1f, 0x2e58 <perf_unwind_perl+0x2e58>
    28d8:      	ldrb	w8, [x22, #0x1b]
    28dc:      	mov	w9, #0x8                // =8
    28e0:      	mov	w10, #0x70              // =112
    28e4:      	add	x11, sp, #0x30
    28e8:      	add	x0, sp, #0x30
    28ec:      	mov	w1, #0x8                // =8
    28f0:      	add	x8, x25, x8
    28f4:      	ldrb	w8, [x22, #0x1b]
    28f8:      	add	x2, x25, x8
    28fc:      	blr	x10
    2900:      	cbnz	x0, 0x27f8 <perf_unwind_perl+0x27f8>
    2904:      	ldr	x8, [sp, #0x30]
    2908:      	mov	w9, #0x8                // =8
    290c:      	mov	w10, #0x70              // =112
    2910:      	add	x11, sp, #0x70
    2914:      	add	x0, sp, #0x70
    2918:      	mov	w1, #0x8                // =8
    291c:      	cmp	x8, #0x0
    2920:      	mov	w8, #0x3                // =3
    2924:      	csinc	w29, w8, wzr, ne
    2928:      	ldrb	w8, [x22, #0x1c]
    292c:      	add	x8, x25, x8
    2930:      	ldrb	w8, [x22, #0x1c]
    2934:      	add	x2, x25, x8
    2938:      	blr	x10
    293c:      	cbnz	x0, 0x27f8 <perf_unwind_perl+0x27f8>
    2940:      	ldr	x24, [sp, #0x70]
    2944:      	ldrb	w8, [x22, #0x1e]
    2948:      	mov	w9, #0x4                // =4
    294c:      	mov	w10, #0x70              // =112
    2950:      	add	x11, sp, #0xb8
    2954:      	add	x0, sp, #0xb8
    2958:      	mov	w1, #0x4                // =4
    295c:      	add	x8, x24, x8
    2960:      	ldrb	w8, [x22, #0x1e]
    2964:      	add	x2, x24, x8
    2968:      	blr	x10
    296c:      	cbz	x0, 0x29fc <perf_unwind_perl+0x29fc>
    2970:      	ldr	w8, [x23]
    2974:      	cbnz	w8, 0x4310 <perf_unwind_perl+0x4310>
    2978:      	mov	w8, #0x14               // =20
    297c:      	adrp	x0, 0x2000 <perf_unwind_perl+0x2000>
    2980:      	add	x9, sp, #0xbc
    2984:      	str	w8, [sp, #0xbc]
    2988:      	mov	w8, #0x1                // =1
    298c:      	add	x1, sp, #0xbc
    2990:      	ldr	x0, [x0]
    2994:      	blr	x8
    2998:      	cbz	x0, 0x2b84 <perf_unwind_perl+0x2b84>
    299c:      	ldr	x8, [x0]
    29a0:      	add	x8, x8, #0x1
    29a4:      	str	x8, [x0]
    29a8:      	b	0x27f8 <perf_unwind_perl+0x27f8>
    29ac:      	ldr	w8, [x23]
    29b0:      	cbz	w8, 0x2e58 <perf_unwind_perl+0x2e58>
    29b4:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    29b8:      	add	x8, x8, #0x0
    29bc:      	add	x0, sp, #0x30
    29c0:      	ldp	x9, x10, [x8, #0x10]
    29c4:      	mov	w1, #0x2e               // =46
    29c8:      	stp	x9, x10, [sp, #0x40]
    29cc:      	ldr	x9, [x8, #0x20]
    29d0:      	add	x10, sp, #0x30
    29d4:      	str	x9, [sp, #0x50]
    29d8:      	ldur	x9, [x8, #0x26]
    29dc:      	stur	x9, [sp, #0x56]
    29e0:      	ldp	x9, x8, [x8]
    29e4:      	stp	x9, x8, [sp, #0x30]
    29e8:      	mov	w8, #0x2e               // =46
    29ec:      	mov	w9, #0x6                // =6
    29f0:      	ldr	w2, [sp, #0xa8]
    29f4:      	blr	x9
    29f8:      	b	0x2e58 <perf_unwind_perl+0x2e58>
    29fc:      	ldr	w8, [sp, #0xb8]
    2a00:      	and	w8, w8, #0x1f
    2a04:      	cmp	w8, #0xd
    2a08:      	b.ne	0x2bd4 <perf_unwind_perl+0x2bd4>
    2a0c:      	ldrb	w8, [x22, #0x1f]
    2a10:      	mov	w9, #0x8                // =8
    2a14:      	mov	w10, #0x70              // =112
    2a18:      	add	x11, sp, #0xa8
    2a1c:      	add	x0, sp, #0xa8
    2a20:      	mov	w1, #0x8                // =8
    2a24:      	add	x8, x24, x8
    2a28:      	ldrb	w8, [x22, #0x1f]
    2a2c:      	add	x2, x24, x8
    2a30:      	blr	x10
    2a34:      	cbnz	x0, 0x2970 <perf_unwind_perl+0x2970>
    2a38:      	ldr	x8, [sp, #0xa8]
    2a3c:      	ldrb	w9, [x22, #0x21]
    2a40:      	mov	w10, #0x70              // =112
    2a44:      	add	x11, sp, #0xa4
    2a48:      	add	x0, sp, #0xa4
    2a4c:      	mov	w1, #0x4                // =4
    2a50:      	add	x8, x8, x9
    2a54:      	mov	w9, #0x4                // =4
    2a58:      	ldr	x8, [sp, #0xa8]
    2a5c:      	ldrb	w9, [x22, #0x21]
    2a60:      	add	x2, x8, x9
    2a64:      	blr	x10
    2a68:      	cbnz	x0, 0x2970 <perf_unwind_perl+0x2970>
    2a6c:      	ldrb	w8, [sp, #0xa5]
    2a70:      	tbnz	w8, #0x7, 0x2dbc <perf_unwind_perl+0x2dbc>
    2a74:      	ldr	x8, [sp, #0xa8]
    2a78:      	ldrb	w9, [x22, #0x22]
    2a7c:      	mov	w10, #0x70              // =112
    2a80:      	add	x11, sp, #0x98
    2a84:      	add	x0, sp, #0x98
    2a88:      	mov	w1, #0x8                // =8
    2a8c:      	add	x8, x8, x9
    2a90:      	mov	w9, #0x8                // =8
    2a94:      	ldr	x8, [sp, #0xa8]
    2a98:      	ldrb	w9, [x22, #0x22]
    2a9c:      	add	x2, x8, x9
    2aa0:      	blr	x10
    2aa4:      	cbnz	x0, 0x2970 <perf_unwind_perl+0x2970>
    2aa8:      	ldr	x8, [sp, #0x98]
    2aac:      	cbz	x8, 0x2970 <perf_unwind_perl+0x2970>
    2ab0:      	ldr	w9, [x23]
    2ab4:      	cbnz	w9, 0x6304 <perf_unwind_perl+0x6304>
    2ab8:      	ldrb	w9, [x22, #0x1e]
    2abc:      	mov	w10, #0x70              // =112
    2ac0:      	add	x11, sp, #0x94
    2ac4:      	add	x0, sp, #0x94
    2ac8:      	mov	w1, #0x4                // =4
    2acc:      	add	x8, x8, x9
    2ad0:      	mov	w9, #0x4                // =4
    2ad4:      	ldr	x8, [sp, #0x98]
    2ad8:      	ldrb	w9, [x22, #0x1e]
    2adc:      	add	x2, x8, x9
    2ae0:      	blr	x10
    2ae4:      	cbnz	x0, 0x2970 <perf_unwind_perl+0x2970>
    2ae8:      	ldr	w8, [sp, #0x94]
    2aec:      	mov	w9, #0x801f             // =32799
    2af0:      	and	w8, w8, w9
    2af4:      	mov	w9, #0x8009             // =32777
    2af8:      	cmp	w8, w9
    2afc:      	b.ne	0x3c34 <perf_unwind_perl+0x3c34>
    2b00:      	ldr	x8, [sp, #0x98]
    2b04:      	ldrb	w9, [x22, #0x20]
    2b08:      	mov	w10, #0x70              // =112
    2b0c:      	add	x11, sp, #0x88
    2b10:      	add	x0, sp, #0x88
    2b14:      	mov	w1, #0x8                // =8
    2b18:      	add	x8, x8, x9
    2b1c:      	mov	w9, #0x8                // =8
    2b20:      	ldr	x8, [sp, #0x98]
    2b24:      	ldrb	w9, [x22, #0x20]
    2b28:      	add	x2, x8, x9
    2b2c:      	blr	x10
    2b30:      	cbnz	x0, 0x2970 <perf_unwind_perl+0x2970>
    2b34:      	ldr	x8, [sp, #0x88]
    2b38:      	ldrb	w9, [x22, #0x23]
    2b3c:      	mov	w10, #0x70              // =112
    2b40:      	add	x11, sp, #0x80
    2b44:      	add	x0, sp, #0x80
    2b48:      	mov	w1, #0x8                // =8
    2b4c:      	add	x8, x8, x9
    2b50:      	mov	w9, #0x8                // =8
    2b54:      	ldr	x8, [sp, #0x88]
    2b58:      	ldrb	w9, [x22, #0x23]
    2b5c:      	add	x2, x8, x9
    2b60:      	blr	x10
    2b64:      	cbnz	x0, 0x2970 <perf_unwind_perl+0x2970>
    2b68:      	ldr	x8, [sp, #0x80]
    2b6c:      	str	x8, [sp, #0x8]
    2b70:      	cbz	x8, 0x4bd0 <perf_unwind_perl+0x4bd0>
    2b74:      	ldr	w8, [x23]
    2b78:      	cbnz	w8, 0x6994 <perf_unwind_perl+0x6994>
    2b7c:      	ldr	x24, [sp, #0x10]
    2b80:      	b	0x4be4 <perf_unwind_perl+0x4be4>
    2b84:      	ldr	w8, [x23]
    2b88:      	cbz	w8, 0x27f8 <perf_unwind_perl+0x27f8>
    2b8c:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    2b90:      	add	x8, x8, #0x0
    2b94:      	add	x0, sp, #0x30
    2b98:      	ldp	x9, x10, [x8, #0x10]
    2b9c:      	mov	w1, #0x2e               // =46
    2ba0:      	stp	x9, x10, [sp, #0x40]
    2ba4:      	ldr	x9, [x8, #0x20]
    2ba8:      	add	x10, sp, #0x30
    2bac:      	str	x9, [sp, #0x50]
    2bb0:      	ldur	x9, [x8, #0x26]
    2bb4:      	stur	x9, [sp, #0x56]
    2bb8:      	ldp	x9, x8, [x8]
    2bbc:      	stp	x9, x8, [sp, #0x30]
    2bc0:      	mov	w8, #0x2e               // =46
    2bc4:      	mov	w9, #0x6                // =6
    2bc8:      	ldr	w2, [sp, #0xbc]
    2bcc:      	blr	x9
    2bd0:      	b	0x27f8 <perf_unwind_perl+0x27f8>
    2bd4:      	ldr	w8, [x23]
    2bd8:      	cbz	w8, 0x27f8 <perf_unwind_perl+0x27f8>
    2bdc:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    2be0:      	add	x8, x8, #0x0
    2be4:      	add	x0, sp, #0x30
    2be8:      	ldp	x9, x10, [x8]
    2bec:      	mov	w1, #0x1e               // =30
    2bf0:      	stp	x9, x10, [sp, #0x30]
    2bf4:      	ldr	x9, [x8, #0x10]
    2bf8:      	ldur	x8, [x8, #0x16]
    2bfc:      	add	x10, sp, #0x30
    2c00:      	str	x9, [sp, #0x40]
    2c04:      	stur	x8, [sp, #0x46]
    2c08:      	mov	w8, #0x1e               // =30
    2c0c:      	mov	w9, #0x6                // =6
    2c10:      	ldr	w2, [sp, #0xb8]
    2c14:      	blr	x9
    2c18:      	b	0x27f8 <perf_unwind_perl+0x27f8>
    2c1c:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    2c20:      	add	x8, x8, #0x0
    2c24:      	add	x0, sp, #0x30
    2c28:      	ldp	x9, x10, [x8, #0x10]
    2c2c:      	mov	w1, #0x2e               // =46
    2c30:      	stp	x9, x10, [sp, #0x40]
    2c34:      	ldr	x9, [x8, #0x20]
    2c38:      	add	x10, sp, #0x30
    2c3c:      	str	x9, [sp, #0x50]
    2c40:      	ldur	x9, [x8, #0x26]
    2c44:      	stur	x9, [sp, #0x56]
    2c48:      	ldp	x9, x8, [x8]
    2c4c:      	stp	x9, x8, [sp, #0x30]
    2c50:      	mov	w8, #0x2e               // =46
    2c54:      	mov	w9, #0x6                // =6
    2c58:      	ldr	w2, [sp, #0xa8]
    2c5c:      	blr	x9
    2c60:      	b	0x27a0 <perf_unwind_perl+0x27a0>
    2c64:      	ldr	w8, [x23]
    2c68:      	cbnz	w8, 0x53c4 <perf_unwind_perl+0x53c4>
    2c6c:      	ldrb	w8, [x22, #0x1d]
    2c70:      	ldr	x9, [x21, #0xf40]
    2c74:      	mov	w29, wzr
    2c78:      	sub	x8, x9, x8
    2c7c:      	ldp	x24, x9, [sp, #0x10]
    2c80:      	str	x8, [x21, #0xf40]
    2c84:      	b	0x5640 <perf_unwind_perl+0x5640>
    2c88:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    2c8c:      	add	x8, x8, #0x0
    2c90:      	add	x0, sp, #0x30
    2c94:      	ldp	x9, x10, [x8, #0x10]
    2c98:      	mov	w1, #0x2d               // =45
    2c9c:      	stp	x9, x10, [sp, #0x40]
    2ca0:      	ldr	x9, [x8, #0x20]
    2ca4:      	add	x10, sp, #0x30
    2ca8:      	str	x9, [sp, #0x50]
    2cac:      	ldur	x9, [x8, #0x25]
    2cb0:      	stur	x9, [sp, #0x55]
    2cb4:      	ldp	x9, x8, [x8]
    2cb8:      	stp	x9, x8, [sp, #0x30]
    2cbc:      	mov	w8, #0x2d               // =45
    2cc0:      	mov	w9, #0x6                // =6
    2cc4:      	blr	x9
    2cc8:      	b	0x14a0 <perf_unwind_perl+0x14a0>
    2ccc:      	mov	w8, #0xa                // =10
    2cd0:      	add	x0, sp, #0x30
    2cd4:      	mov	w1, #0x2a               // =42
    2cd8:      	strh	w8, [sp, #0x58]
    2cdc:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    2ce0:      	add	x8, x8, #0x0
    2ce4:      	mov	x2, x25
    2ce8:      	ldp	x9, x10, [x8, #0x10]
    2cec:      	stp	x9, x10, [sp, #0x40]
    2cf0:      	ldr	x9, [x8, #0x20]
    2cf4:      	add	x10, sp, #0x30
    2cf8:      	str	x9, [sp, #0x50]
    2cfc:      	ldp	x8, x9, [x8]
    2d00:      	stp	x8, x9, [sp, #0x30]
    2d04:      	mov	w8, #0x2a               // =42
    2d08:      	mov	w9, #0x6                // =6
    2d0c:      	blr	x9
    2d10:      	b	0x2800 <perf_unwind_perl+0x2800>
    2d14:      	ldr	w8, [x23]
    2d18:      	cbz	w8, 0x1e5c <perf_unwind_perl+0x1e5c>
    2d1c:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    2d20:      	add	x8, x8, #0x0
    2d24:      	add	x0, sp, #0x30
    2d28:      	ldp	x9, x10, [x8, #0x10]
    2d2c:      	mov	w1, #0x26               // =38
    2d30:      	stp	x9, x10, [sp, #0x40]
    2d34:      	ldur	x9, [x8, #0x1e]
    2d38:      	add	x10, sp, #0x30
    2d3c:      	stur	x9, [sp, #0x4e]
    2d40:      	ldp	x8, x9, [x8]
    2d44:      	stp	x8, x9, [sp, #0x30]
    2d48:      	mov	w8, #0x26               // =38
    2d4c:      	mov	w9, #0x6                // =6
    2d50:      	ldr	w2, [sp, #0x94]
    2d54:      	b	0x3be4 <perf_unwind_perl+0x3be4>
    2d58:      	add	x8, sp, #0x98
    2d5c:      	ldr	x8, [x8]
    2d60:      	ldr	x24, [sp, #0x10]
    2d64:      	str	x8, [sp, #0x8]
    2d68:      	cbz	x8, 0xcd8 <perf_unwind_perl+0xcd8>
    2d6c:      	ldr	x24, [x24]
    2d70:      	ldr	w8, [x23]
    2d74:      	cbnz	w8, 0x540c <perf_unwind_perl+0x540c>
    2d78:      	ldr	w8, [x21, #0x2c0]
    2d7c:      	cmp	w8, #0x7e
    2d80:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    2d84:      	add	w9, w8, #0x1
    2d88:      	mov	w10, #0x7               // =7
    2d8c:      	str	w9, [x21, #0x2c0]
    2d90:      	mov	w9, #0x18               // =24
    2d94:      	umaddl	x8, w8, w9, x21
    2d98:      	str	x24, [x8, #0x2d8]
    2d9c:      	ldp	x9, x24, [sp, #0x8]
    2da0:      	strb	w10, [x8, #0x2e0]
    2da4:      	str	wzr, [x8, #0x2e4]
    2da8:      	str	x9, [x8, #0x2d0]
    2dac:      	add	x9, x8, #0x2d0
    2db0:      	str	xzr, [x21, #0xf30]
    2db4:      	stur	wzr, [x9, #0x11]
    2db8:      	b	0x1368 <perf_unwind_perl+0x1368>
    2dbc:      	ldr	w8, [x23]
    2dc0:      	cbz	w8, 0x27f8 <perf_unwind_perl+0x27f8>
    2dc4:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    2dc8:      	add	x8, x8, #0x0
    2dcc:      	add	x0, sp, #0x30
    2dd0:      	ldp	x9, x10, [x8, #0x10]
    2dd4:      	mov	w1, #0x26               // =38
    2dd8:      	stp	x9, x10, [sp, #0x40]
    2ddc:      	ldur	x9, [x8, #0x1e]
    2de0:      	add	x10, sp, #0x30
    2de4:      	stur	x9, [sp, #0x4e]
    2de8:      	ldp	x8, x9, [x8]
    2dec:      	stp	x8, x9, [sp, #0x30]
    2df0:      	mov	w8, #0x26               // =38
    2df4:      	mov	w9, #0x6                // =6
    2df8:      	ldr	w2, [sp, #0xb8]
    2dfc:      	ldr	w3, [sp, #0xa4]
    2e00:      	blr	x9
    2e04:      	b	0x27f8 <perf_unwind_perl+0x27f8>
    2e08:      	mov	w8, #0xa                // =10
    2e0c:      	add	x10, sp, #0x30
    2e10:      	add	x0, sp, #0x30
    2e14:      	strh	w8, [sp, #0x40]
    2e18:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    2e1c:      	add	x8, x8, #0x0
    2e20:      	mov	w1, #0x12               // =18
    2e24:      	ldp	x9, x8, [x8]
    2e28:      	stp	x9, x8, [sp, #0x30]
    2e2c:      	mov	w8, #0x12               // =18
    2e30:      	mov	w9, #0x6                // =6
    2e34:      	ldrb	w2, [sp, #0x7c]
    2e38:      	blr	x9
    2e3c:      	ldrb	w8, [sp, #0x7c]
    2e40:      	and	w9, w8, #0xf
    2e44:      	sub	w10, w9, #0x9
    2e48:      	cmp	w10, #0x2
    2e4c:      	b.lo	0x28d0 <perf_unwind_perl+0x28d0>
    2e50:      	cmp	w9, #0xc
    2e54:      	b.ne	0x2f44 <perf_unwind_perl+0x2f44>
    2e58:      	mov	w29, #0x3               // =3
    2e5c:      	ldrb	w8, [x22, #0x1d]
    2e60:      	ldr	x9, [x21, #0xf40]
    2e64:      	adrp	x0, 0x2000 <perf_unwind_perl+0x2000>
    2e68:      	add	x1, sp, #0xa8
    2e6c:      	sub	x8, x9, x8
    2e70:      	add	x9, sp, #0xa8
    2e74:      	str	x8, [x21, #0xf40]
    2e78:      	mov	w8, #0x10               // =16
    2e7c:      	str	w8, [sp, #0xa8]
    2e80:      	mov	w8, #0x1                // =1
    2e84:      	ldr	x0, [x0]
    2e88:      	blr	x8
    2e8c:      	cbz	x0, 0x2eac <perf_unwind_perl+0x2eac>
    2e90:      	ldr	x8, [x0]
    2e94:      	add	x8, x8, #0x1
    2e98:      	str	x8, [x0]
    2e9c:      	ldp	x24, x9, [sp, #0x10]
    2ea0:      	cmp	w29, #0x3
    2ea4:      	b.eq	0x2ec0 <perf_unwind_perl+0x2ec0>
    2ea8:      	b	0x563c <perf_unwind_perl+0x563c>
    2eac:      	ldr	w8, [x23]
    2eb0:      	cbnz	w8, 0x3368 <perf_unwind_perl+0x3368>
    2eb4:      	ldp	x24, x9, [sp, #0x10]
    2eb8:      	cmp	w29, #0x3
    2ebc:      	b.ne	0x563c <perf_unwind_perl+0x563c>
    2ec0:      	ldr	x25, [x21, #0xf40]
    2ec4:      	cmp	x25, x9
    2ec8:      	b.hs	0x2ed8 <perf_unwind_perl+0x2ed8>
    2ecc:      	mov	w29, #0x3               // =3
    2ed0:      	ldp	x24, x9, [sp, #0x10]
    2ed4:      	b	0x563c <perf_unwind_perl+0x563c>
    2ed8:      	ldrb	w8, [x22, #0x19]
    2edc:      	mov	w9, #0x1                // =1
    2ee0:      	mov	w10, #0x70              // =112
    2ee4:      	add	x11, sp, #0x7c
    2ee8:      	add	x0, sp, #0x7c
    2eec:      	mov	w1, #0x1                // =1
    2ef0:      	add	x8, x25, x8
    2ef4:      	ldrb	w8, [x22, #0x19]
    2ef8:      	add	x2, x25, x8
    2efc:      	blr	x10
    2f00:      	cbz	x0, 0x2fcc <perf_unwind_perl+0x2fcc>
    2f04:      	ldr	w8, [x23]
    2f08:      	cbnz	w8, 0x3448 <perf_unwind_perl+0x3448>
    2f0c:      	mov	w8, #0x13               // =19
    2f10:      	adrp	x0, 0x2000 <perf_unwind_perl+0x2000>
    2f14:      	add	x9, sp, #0xa8
    2f18:      	str	w8, [sp, #0xa8]
    2f1c:      	mov	w8, #0x1                // =1
    2f20:      	add	x1, sp, #0xa8
    2f24:      	ldr	x0, [x0]
    2f28:      	blr	x8
    2f2c:      	cbz	x0, 0x30c4 <perf_unwind_perl+0x30c4>
    2f30:      	ldr	x8, [x0]
    2f34:      	mov	w29, #0x3               // =3
    2f38:      	add	x8, x8, #0x1
    2f3c:      	str	x8, [x0]
    2f40:      	b	0x3618 <perf_unwind_perl+0x3618>
    2f44:      	ldr	x8, [sp, #0x10]
    2f48:      	mov	w29, #0x3               // =3
    2f4c:      	ldr	x8, [x8]
    2f50:      	cbnz	x8, 0x2e5c <perf_unwind_perl+0x2e5c>
    2f54:      	ldrb	w8, [x22, #0x1a]
    2f58:      	mov	w9, #0x8                // =8
    2f5c:      	mov	w10, #0x70              // =112
    2f60:      	ldr	x24, [sp, #0x10]
    2f64:      	mov	w1, #0x8                // =8
    2f68:      	add	x8, x25, x8
    2f6c:      	mov	x0, x24
    2f70:      	ldrb	w8, [x22, #0x1a]
    2f74:      	add	x2, x25, x8
    2f78:      	blr	x10
    2f7c:      	cbnz	x0, 0x27f8 <perf_unwind_perl+0x27f8>
    2f80:      	ldr	w8, [x23]
    2f84:      	cbz	w8, 0x2e5c <perf_unwind_perl+0x2e5c>
    2f88:      	adrp	x8, 0x2000 <perf_unwind_perl+0x2000>
    2f8c:      	add	x8, x8, #0x0
    2f90:      	add	x0, sp, #0x30
    2f94:      	ldp	x9, x10, [x8]
    2f98:      	mov	w1, #0x1e               // =30
    2f9c:      	stp	x9, x10, [sp, #0x30]
    2fa0:      	ldr	x9, [x8, #0x10]
    2fa4:      	ldur	x8, [x8, #0x16]
    2fa8:      	add	x10, sp, #0x30
    2fac:      	str	x9, [sp, #0x40]
    2fb0:      	stur	x8, [sp, #0x46]
    2fb4:      	mov	w8, #0x1e               // =30
    2fb8:      	mov	w9, #0x6                // =6
    2fbc:      	ldr	x8, [sp, #0x10]
    2fc0:      	ldr	x2, [x8]
    2fc4:      	blr	x9
    2fc8:      	b	0x2e5c <perf_unwind_perl+0x2e5c>
    2fcc:      	ldr	w8, [x23]
    2fd0:      	cbnz	w8, 0x35c4 <perf_unwind_perl+0x35c4>
    2fd4:      	ldrb	w8, [sp, #0x7c]
    2fd8:      	and	w9, w8, #0xf
    2fdc:      	sub	w10, w9, #0x9
    2fe0:      	cmp	w10, #0x2
    2fe4:      	b.hs	0x360c <perf_unwind_perl+0x360c>
    2fe8:      	sxtb	w8, w8
    2fec:      	tbnz	w8, #0x1f, 0x3614 <perf_unwind_perl+0x3614>
    2ff0:      	ldrb	w8, [x22, #0x1b]
    2ff4:      	mov	w9, #0x8                // =8
    2ff8:      	mov	w10, #0x70              // =112
    2ffc:      	add	x11, sp, #0x30
    3000:      	add	x0, sp, #0x30
    3004:      	mov	w1, #0x8                // =8
    3008:      	add	x8, x25, x8
    300c:      	ldrb	w8, [x22, #0x1b]
    3010:      	add	x2, x25, x8
    3014:      	blr	x10
    3018:      	cbnz	x0, 0x2f04 <perf_unwind_perl+0x2f04>
    301c:      	ldr	x8, [sp, #0x30]
    3020:      	mov	w9, #0x8                // =8
    3024:      	mov	w10, #0x70              // =112
    3028:      	add	x11, sp, #0x70
    302c:      	add	x0, sp, #0x70
    3030:      	mov	w1, #0x8                // =8
    3034:      	cmp	x8, #0x0
    3038:      	mov	w8, #0x3                // =3
    303c:      	csinc	w29, w8, wzr, ne
    3040:      	ldrb	w8, [x22, #0x1c]
    3044:      	add	x8, x25, x8
    3048:      	ldrb	w8, [x22, #0x1c]
    304c:      	add	x2, x25, x8
    3050:      	blr	x10
    3054:      	cbnz	x0, 0x2f04 <perf_unwind_perl+0x2f04>
    3058:      	ldr	x24, [sp, #0x70]
    305c:      	ldrb	w8, [x22, #0x1e]
    3060:      	mov	w9, #0x4                // =4
    3064:      	mov	w10, #0x70              // =112
    3068:      	add	x11, sp, #0xb8
    306c:      	add	x0, sp, #0xb8
    3070:      	mov	w1, #0x4                // =4
    3074:      	add	x8, x24, x8
    3078:      	ldrb	w8, [x22, #0x1e]
    307c:      	add	x2, x24, x8
    3080:      	blr	x10
    3084:      	cbz	x0, 0x3114 <perf_unwind_perl+0x3114>
    3088:      	ldr	w8, [x23]
    308c:      	cbnz	w8, 0x4a78 <perf_unwind_perl+0x4a78>
    3090:      	mov	w8, #0x14               // =20
    3094:      	adrp	x0, 0x3000 <perf_unwind_perl+0x3000>
    3098:      	add	x9, sp, #0xbc
    309c:      	str	w8, [sp, #0xbc]
    30a0:      	mov	w8, #0x1                // =1
    30a4:      	add	x1, sp, #0xbc
    30a8:      	ldr	x0, [x0]
    30ac:      	blr	x8
    30b0:      	cbz	x0, 0x32d0 <perf_unwind_perl+0x32d0>
    30b4:      	ldr	x8, [x0]
    30b8:      	add	x8, x8, #0x1
    30bc:      	str	x8, [x0]
    30c0:      	b	0x2f04 <perf_unwind_perl+0x2f04>
    30c4:      	ldr	w8, [x23]
    30c8:      	cbz	w8, 0x3614 <perf_unwind_perl+0x3614>
    30cc:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    30d0:      	add	x8, x8, #0x0
    30d4:      	add	x0, sp, #0x30
    30d8:      	ldp	x9, x10, [x8, #0x10]
    30dc:      	mov	w1, #0x2e               // =46
    30e0:      	stp	x9, x10, [sp, #0x40]
    30e4:      	ldr	x9, [x8, #0x20]
    30e8:      	add	x10, sp, #0x30
    30ec:      	str	x9, [sp, #0x50]
    30f0:      	ldur	x9, [x8, #0x26]
    30f4:      	stur	x9, [sp, #0x56]
    30f8:      	ldp	x9, x8, [x8]
    30fc:      	stp	x9, x8, [sp, #0x30]
    3100:      	mov	w8, #0x2e               // =46
    3104:      	mov	w9, #0x6                // =6
    3108:      	ldr	w2, [sp, #0xa8]
    310c:      	blr	x9
    3110:      	b	0x3614 <perf_unwind_perl+0x3614>
    3114:      	ldr	w8, [sp, #0xb8]
    3118:      	and	w8, w8, #0x1f
    311c:      	cmp	w8, #0xd
    3120:      	b.ne	0x3320 <perf_unwind_perl+0x3320>
    3124:      	ldrb	w8, [x22, #0x1f]
    3128:      	mov	w9, #0x8                // =8
    312c:      	mov	w10, #0x70              // =112
    3130:      	add	x11, sp, #0xa8
    3134:      	add	x0, sp, #0xa8
    3138:      	mov	w1, #0x8                // =8
    313c:      	add	x8, x24, x8
    3140:      	ldrb	w8, [x22, #0x1f]
    3144:      	add	x2, x24, x8
    3148:      	blr	x10
    314c:      	cbnz	x0, 0x3088 <perf_unwind_perl+0x3088>
    3150:      	ldr	x8, [sp, #0xa8]
    3154:      	ldrb	w9, [x22, #0x21]
    3158:      	mov	w10, #0x70              // =112
    315c:      	add	x11, sp, #0xa4
    3160:      	add	x0, sp, #0xa4
    3164:      	mov	w1, #0x4                // =4
    3168:      	add	x8, x8, x9
    316c:      	mov	w9, #0x4                // =4
    3170:      	ldr	x8, [sp, #0xa8]
    3174:      	ldrb	w9, [x22, #0x21]
    3178:      	add	x2, x8, x9
    317c:      	blr	x10
    3180:      	cbnz	x0, 0x3088 <perf_unwind_perl+0x3088>
    3184:      	ldrb	w8, [sp, #0xa5]
    3188:      	tbnz	w8, #0x7, 0x3578 <perf_unwind_perl+0x3578>
    318c:      	ldr	x8, [sp, #0xa8]
    3190:      	ldrb	w9, [x22, #0x22]
    3194:      	mov	w10, #0x70              // =112
    3198:      	add	x11, sp, #0x98
    319c:      	add	x0, sp, #0x98
    31a0:      	mov	w1, #0x8                // =8
    31a4:      	add	x8, x8, x9
    31a8:      	mov	w9, #0x8                // =8
    31ac:      	ldr	x8, [sp, #0xa8]
    31b0:      	ldrb	w9, [x22, #0x22]
    31b4:      	add	x2, x8, x9
    31b8:      	blr	x10
    31bc:      	cbnz	x0, 0x3088 <perf_unwind_perl+0x3088>
    31c0:      	ldr	x8, [sp, #0x98]
    31c4:      	cbz	x8, 0x3088 <perf_unwind_perl+0x3088>
    31c8:      	ldr	w9, [x23]
    31cc:      	cbnz	w9, 0x668c <perf_unwind_perl+0x668c>
    31d0:      	ldrb	w9, [x22, #0x1e]
    31d4:      	mov	w10, #0x70              // =112
    31d8:      	add	x11, sp, #0x94
    31dc:      	add	x0, sp, #0x94
    31e0:      	mov	w1, #0x4                // =4
    31e4:      	add	x8, x8, x9
    31e8:      	mov	w9, #0x4                // =4
    31ec:      	ldr	x8, [sp, #0x98]
    31f0:      	ldrb	w9, [x22, #0x1e]
    31f4:      	add	x2, x8, x9
    31f8:      	blr	x10
    31fc:      	cbnz	x0, 0x3088 <perf_unwind_perl+0x3088>
    3200:      	ldr	w8, [sp, #0x94]
    3204:      	mov	w9, #0x801f             // =32799
    3208:      	and	w8, w8, w9
    320c:      	mov	w9, #0x8009             // =32777
    3210:      	cmp	w8, w9
    3214:      	b.ne	0x439c <perf_unwind_perl+0x439c>
    3218:      	ldr	x8, [sp, #0x98]
    321c:      	ldrb	w9, [x22, #0x20]
    3220:      	mov	w10, #0x70              // =112
    3224:      	add	x11, sp, #0x88
    3228:      	add	x0, sp, #0x88
    322c:      	mov	w1, #0x8                // =8
    3230:      	add	x8, x8, x9
    3234:      	mov	w9, #0x8                // =8
    3238:      	ldr	x8, [sp, #0x98]
    323c:      	ldrb	w9, [x22, #0x20]
    3240:      	add	x2, x8, x9
    3244:      	blr	x10
    3248:      	cbnz	x0, 0x3088 <perf_unwind_perl+0x3088>
    324c:      	ldr	x8, [sp, #0x88]
    3250:      	ldrb	w9, [x22, #0x23]
    3254:      	mov	w10, #0x70              // =112
    3258:      	add	x11, sp, #0x80
    325c:      	add	x0, sp, #0x80
    3260:      	mov	w1, #0x8                // =8
    3264:      	add	x8, x8, x9
    3268:      	mov	w9, #0x8                // =8
    326c:      	ldr	x8, [sp, #0x88]
    3270:      	ldrb	w9, [x22, #0x23]
    3274:      	add	x2, x8, x9
    3278:      	blr	x10
    327c:      	cbnz	x0, 0x3088 <perf_unwind_perl+0x3088>
    3280:      	ldr	x24, [sp, #0x80]
    3284:      	cbz	x24, 0x545c <perf_unwind_perl+0x545c>
    3288:      	ldr	w8, [x23]
    328c:      	cbz	w8, 0x5468 <perf_unwind_perl+0x5468>
    3290:      	mov	w8, #0x786c             // =30828
    3294:      	add	x10, sp, #0x30
    3298:      	add	x0, sp, #0x30
    329c:      	mov	w1, #0x14               // =20
    32a0:      	movk	w8, #0xa, lsl #16
    32a4:      	str	w8, [sp, #0x40]
    32a8:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    32ac:      	add	x8, x8, #0x0
    32b0:      	ldp	x9, x8, [x8]
    32b4:      	stp	x9, x8, [sp, #0x30]
    32b8:      	mov	w8, #0x14               // =20
    32bc:      	mov	w9, #0x6                // =6
    32c0:      	ldr	x2, [sp, #0x80]
    32c4:      	blr	x9
    32c8:      	add	x8, sp, #0x80
    32cc:      	b	0x5460 <perf_unwind_perl+0x5460>
    32d0:      	ldr	w8, [x23]
    32d4:      	cbz	w8, 0x2f04 <perf_unwind_perl+0x2f04>
    32d8:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    32dc:      	add	x8, x8, #0x0
    32e0:      	add	x0, sp, #0x30
    32e4:      	ldp	x9, x10, [x8, #0x10]
    32e8:      	mov	w1, #0x2e               // =46
    32ec:      	stp	x9, x10, [sp, #0x40]
    32f0:      	ldr	x9, [x8, #0x20]
    32f4:      	add	x10, sp, #0x30
    32f8:      	str	x9, [sp, #0x50]
    32fc:      	ldur	x9, [x8, #0x26]
    3300:      	stur	x9, [sp, #0x56]
    3304:      	ldp	x9, x8, [x8]
    3308:      	stp	x9, x8, [sp, #0x30]
    330c:      	mov	w8, #0x2e               // =46
    3310:      	mov	w9, #0x6                // =6
    3314:      	ldr	w2, [sp, #0xbc]
    3318:      	blr	x9
    331c:      	b	0x2f04 <perf_unwind_perl+0x2f04>
    3320:      	ldr	w8, [x23]
    3324:      	cbz	w8, 0x2f04 <perf_unwind_perl+0x2f04>
    3328:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    332c:      	add	x8, x8, #0x0
    3330:      	add	x0, sp, #0x30
    3334:      	ldp	x9, x10, [x8]
    3338:      	mov	w1, #0x1e               // =30
    333c:      	stp	x9, x10, [sp, #0x30]
    3340:      	ldr	x9, [x8, #0x10]
    3344:      	ldur	x8, [x8, #0x16]
    3348:      	add	x10, sp, #0x30
    334c:      	str	x9, [sp, #0x40]
    3350:      	stur	x8, [sp, #0x46]
    3354:      	mov	w8, #0x1e               // =30
    3358:      	mov	w9, #0x6                // =6
    335c:      	ldr	w2, [sp, #0xb8]
    3360:      	blr	x9
    3364:      	b	0x2f04 <perf_unwind_perl+0x2f04>
    3368:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    336c:      	add	x8, x8, #0x0
    3370:      	add	x0, sp, #0x30
    3374:      	ldp	x9, x10, [x8, #0x10]
    3378:      	mov	w1, #0x2e               // =46
    337c:      	stp	x9, x10, [sp, #0x40]
    3380:      	ldr	x9, [x8, #0x20]
    3384:      	add	x10, sp, #0x30
    3388:      	str	x9, [sp, #0x50]
    338c:      	ldur	x9, [x8, #0x26]
    3390:      	stur	x9, [sp, #0x56]
    3394:      	ldp	x9, x8, [x8]
    3398:      	stp	x9, x8, [sp, #0x30]
    339c:      	mov	w8, #0x2e               // =46
    33a0:      	mov	w9, #0x6                // =6
    33a4:      	ldr	w2, [sp, #0xa8]
    33a8:      	blr	x9
    33ac:      	ldp	x24, x9, [sp, #0x10]
    33b0:      	cmp	w29, #0x3
    33b4:      	b.eq	0x2ec0 <perf_unwind_perl+0x2ec0>
    33b8:      	b	0x563c <perf_unwind_perl+0x563c>
    33bc:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    33c0:      	add	x8, x8, #0x0
    33c4:      	add	x0, sp, #0x30
    33c8:      	ldp	x9, x10, [x8, #0x10]
    33cc:      	mov	w1, #0x2e               // =46
    33d0:      	stp	x9, x10, [sp, #0x40]
    33d4:      	ldr	x9, [x8, #0x20]
    33d8:      	add	x10, sp, #0x30
    33dc:      	str	x9, [sp, #0x50]
    33e0:      	ldur	x9, [x8, #0x26]
    33e4:      	stur	x9, [sp, #0x56]
    33e8:      	ldp	x9, x8, [x8]
    33ec:      	stp	x9, x8, [sp, #0x30]
    33f0:      	mov	w8, #0x2e               // =46
    33f4:      	mov	w9, #0x6                // =6
    33f8:      	ldr	w2, [sp, #0xbc]
    33fc:      	blr	x9
    3400:      	b	0x16b8 <perf_unwind_perl+0x16b8>
    3404:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    3408:      	add	x8, x8, #0x0
    340c:      	add	x0, sp, #0x30
    3410:      	ldp	x9, x10, [x8, #0x10]
    3414:      	mov	w1, #0x2d               // =45
    3418:      	stp	x9, x10, [sp, #0x40]
    341c:      	ldr	x9, [x8, #0x20]
    3420:      	add	x10, sp, #0x30
    3424:      	str	x9, [sp, #0x50]
    3428:      	ldur	x9, [x8, #0x25]
    342c:      	stur	x9, [sp, #0x55]
    3430:      	ldp	x9, x8, [x8]
    3434:      	stp	x9, x8, [sp, #0x30]
    3438:      	mov	w8, #0x2d               // =45
    343c:      	mov	w9, #0x6                // =6
    3440:      	blr	x9
    3444:      	b	0x1bf8 <perf_unwind_perl+0x1bf8>
    3448:      	mov	w8, #0xa                // =10
    344c:      	add	x0, sp, #0x30
    3450:      	mov	w1, #0x2a               // =42
    3454:      	strh	w8, [sp, #0x58]
    3458:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    345c:      	add	x8, x8, #0x0
    3460:      	mov	x2, x25
    3464:      	ldp	x9, x10, [x8, #0x10]
    3468:      	stp	x9, x10, [sp, #0x40]
    346c:      	ldr	x9, [x8, #0x20]
    3470:      	add	x10, sp, #0x30
    3474:      	str	x9, [sp, #0x50]
    3478:      	ldp	x8, x9, [x8]
    347c:      	stp	x8, x9, [sp, #0x30]
    3480:      	mov	w8, #0x2a               // =42
    3484:      	mov	w9, #0x6                // =6
    3488:      	blr	x9
    348c:      	b	0x2f0c <perf_unwind_perl+0x2f0c>
    3490:      	ldr	w8, [x23]
    3494:      	cbz	w8, 0x2210 <perf_unwind_perl+0x2210>
    3498:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    349c:      	add	x8, x8, #0x0
    34a0:      	add	x0, sp, #0x30
    34a4:      	ldp	x9, x10, [x8, #0x10]
    34a8:      	mov	w1, #0x26               // =38
    34ac:      	stp	x9, x10, [sp, #0x40]
    34b0:      	ldur	x9, [x8, #0x1e]
    34b4:      	add	x10, sp, #0x30
    34b8:      	stur	x9, [sp, #0x4e]
    34bc:      	ldp	x8, x9, [x8]
    34c0:      	stp	x8, x9, [sp, #0x30]
    34c4:      	mov	w8, #0x26               // =38
    34c8:      	mov	w9, #0x6                // =6
    34cc:      	ldr	w2, [sp, #0x94]
    34d0:      	b	0x252c <perf_unwind_perl+0x252c>
    34d4:      	add	x8, sp, #0x98
    34d8:      	ldr	x8, [x8]
    34dc:      	ldr	x24, [sp, #0x10]
    34e0:      	str	x8, [sp, #0x8]
    34e4:      	cbz	x8, 0x131c <perf_unwind_perl+0x131c>
    34e8:      	ldr	x24, [x24]
    34ec:      	ldr	w8, [x23]
    34f0:      	cbnz	w8, 0x6200 <perf_unwind_perl+0x6200>
    34f4:      	ldr	w8, [x21, #0x2c0]
    34f8:      	cmp	w8, #0x7e
    34fc:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    3500:      	add	w9, w8, #0x1
    3504:      	mov	w10, #0x7               // =7
    3508:      	str	w9, [x21, #0x2c0]
    350c:      	mov	w9, #0x18               // =24
    3510:      	umaddl	x8, w8, w9, x21
    3514:      	str	x24, [x8, #0x2d8]
    3518:      	ldp	x9, x24, [sp, #0x8]
    351c:      	strb	w10, [x8, #0x2e0]
    3520:      	str	wzr, [x8, #0x2e4]
    3524:      	str	x9, [x8, #0x2d0]
    3528:      	add	x9, x8, #0x2d0
    352c:      	str	xzr, [x21, #0xf30]
    3530:      	stur	wzr, [x9, #0x11]
    3534:      	b	0x1ac0 <perf_unwind_perl+0x1ac0>
    3538:      	mov	w8, #0x786c             // =30828
    353c:      	add	x10, sp, #0x30
    3540:      	add	x0, sp, #0x30
    3544:      	mov	w1, #0x13               // =19
    3548:      	movk	w8, #0xa, lsl #16
    354c:      	stur	w8, [sp, #0x3f]
    3550:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    3554:      	add	x8, x8, #0x0
    3558:      	ldp	x9, x8, [x8]
    355c:      	stp	x9, x8, [sp, #0x30]
    3560:      	mov	w8, #0x13               // =19
    3564:      	mov	w9, #0x6                // =6
    3568:      	ldr	x2, [sp, #0x98]
    356c:      	blr	x9
    3570:      	ldr	x8, [sp, #0x98]
    3574:      	b	0x338 <perf_unwind_perl+0x338>
    3578:      	ldr	w8, [x23]
    357c:      	cbz	w8, 0x2f04 <perf_unwind_perl+0x2f04>
    3580:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    3584:      	add	x8, x8, #0x0
    3588:      	add	x0, sp, #0x30
    358c:      	ldp	x9, x10, [x8, #0x10]
    3590:      	mov	w1, #0x26               // =38
    3594:      	stp	x9, x10, [sp, #0x40]
    3598:      	ldur	x9, [x8, #0x1e]
    359c:      	add	x10, sp, #0x30
    35a0:      	stur	x9, [sp, #0x4e]
    35a4:      	ldp	x8, x9, [x8]
    35a8:      	stp	x8, x9, [sp, #0x30]
    35ac:      	mov	w8, #0x26               // =38
    35b0:      	mov	w9, #0x6                // =6
    35b4:      	ldr	w2, [sp, #0xb8]
    35b8:      	ldr	w3, [sp, #0xa4]
    35bc:      	blr	x9
    35c0:      	b	0x2f04 <perf_unwind_perl+0x2f04>
    35c4:      	mov	w8, #0xa                // =10
    35c8:      	add	x10, sp, #0x30
    35cc:      	add	x0, sp, #0x30
    35d0:      	strh	w8, [sp, #0x40]
    35d4:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    35d8:      	add	x8, x8, #0x0
    35dc:      	mov	w1, #0x12               // =18
    35e0:      	ldp	x9, x8, [x8]
    35e4:      	stp	x9, x8, [sp, #0x30]
    35e8:      	mov	w8, #0x12               // =18
    35ec:      	mov	w9, #0x6                // =6
    35f0:      	ldrb	w2, [sp, #0x7c]
    35f4:      	blr	x9
    35f8:      	ldrb	w8, [sp, #0x7c]
    35fc:      	and	w9, w8, #0xf
    3600:      	sub	w10, w9, #0x9
    3604:      	cmp	w10, #0x2
    3608:      	b.lo	0x2fe8 <perf_unwind_perl+0x2fe8>
    360c:      	cmp	w9, #0xc
    3610:      	b.ne	0x36f4 <perf_unwind_perl+0x36f4>
    3614:      	mov	w29, #0x3               // =3
    3618:      	ldrb	w8, [x22, #0x1d]
    361c:      	ldr	x9, [x21, #0xf40]
    3620:      	adrp	x0, 0x3000 <perf_unwind_perl+0x3000>
    3624:      	add	x1, sp, #0xa8
    3628:      	sub	x8, x9, x8
    362c:      	add	x9, sp, #0xa8
    3630:      	str	x8, [x21, #0xf40]
    3634:      	mov	w8, #0x10               // =16
    3638:      	str	w8, [sp, #0xa8]
    363c:      	mov	w8, #0x1                // =1
    3640:      	ldr	x0, [x0]
    3644:      	blr	x8
    3648:      	cbz	x0, 0x3668 <perf_unwind_perl+0x3668>
    364c:      	ldr	x8, [x0]
    3650:      	add	x8, x8, #0x1
    3654:      	str	x8, [x0]
    3658:      	ldp	x24, x9, [sp, #0x10]
    365c:      	cmp	w29, #0x3
    3660:      	b.eq	0x367c <perf_unwind_perl+0x367c>
    3664:      	b	0x563c <perf_unwind_perl+0x563c>
    3668:      	ldr	w8, [x23]
    366c:      	cbnz	w8, 0x3b14 <perf_unwind_perl+0x3b14>
    3670:      	ldp	x24, x9, [sp, #0x10]
    3674:      	cmp	w29, #0x3
    3678:      	b.ne	0x563c <perf_unwind_perl+0x563c>
    367c:      	ldr	x25, [x21, #0xf40]
    3680:      	cmp	x25, x9
    3684:      	b.lo	0x2ecc <perf_unwind_perl+0x2ecc>
    3688:      	ldrb	w8, [x22, #0x19]
    368c:      	mov	w9, #0x1                // =1
    3690:      	mov	w10, #0x70              // =112
    3694:      	add	x11, sp, #0x7c
    3698:      	add	x0, sp, #0x7c
    369c:      	mov	w1, #0x1                // =1
    36a0:      	add	x8, x25, x8
    36a4:      	ldrb	w8, [x22, #0x19]
    36a8:      	add	x2, x25, x8
    36ac:      	blr	x10
    36b0:      	cbz	x0, 0x3778 <perf_unwind_perl+0x3778>
    36b4:      	ldr	w8, [x23]
    36b8:      	cbnz	w8, 0x3bec <perf_unwind_perl+0x3bec>
    36bc:      	mov	w8, #0x13               // =19
    36c0:      	adrp	x0, 0x3000 <perf_unwind_perl+0x3000>
    36c4:      	add	x9, sp, #0xa8
    36c8:      	str	w8, [sp, #0xa8]
    36cc:      	mov	w8, #0x1                // =1
    36d0:      	add	x1, sp, #0xa8
    36d4:      	ldr	x0, [x0]
    36d8:      	blr	x8
    36dc:      	cbz	x0, 0x3870 <perf_unwind_perl+0x3870>
    36e0:      	ldr	x8, [x0]
    36e4:      	mov	w29, #0x3               // =3
    36e8:      	add	x8, x8, #0x1
    36ec:      	str	x8, [x0]
    36f0:      	b	0x3dc0 <perf_unwind_perl+0x3dc0>
    36f4:      	ldr	x8, [sp, #0x10]
    36f8:      	mov	w29, #0x3               // =3
    36fc:      	ldr	x8, [x8]
    3700:      	cbnz	x8, 0x3618 <perf_unwind_perl+0x3618>
    3704:      	ldrb	w8, [x22, #0x1a]
    3708:      	mov	w9, #0x8                // =8
    370c:      	mov	w10, #0x70              // =112
    3710:      	ldr	x0, [sp, #0x10]
    3714:      	mov	w1, #0x8                // =8
    3718:      	add	x8, x25, x8
    371c:      	ldrb	w8, [x22, #0x1a]
    3720:      	add	x2, x25, x8
    3724:      	blr	x10
    3728:      	cbnz	x0, 0x2f04 <perf_unwind_perl+0x2f04>
    372c:      	ldr	w8, [x23]
    3730:      	cbz	w8, 0x3618 <perf_unwind_perl+0x3618>
    3734:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    3738:      	add	x8, x8, #0x0
    373c:      	add	x0, sp, #0x30
    3740:      	ldp	x9, x10, [x8]
    3744:      	mov	w1, #0x1e               // =30
    3748:      	stp	x9, x10, [sp, #0x30]
    374c:      	ldr	x9, [x8, #0x10]
    3750:      	ldur	x8, [x8, #0x16]
    3754:      	add	x10, sp, #0x30
    3758:      	str	x9, [sp, #0x40]
    375c:      	stur	x8, [sp, #0x46]
    3760:      	mov	w8, #0x1e               // =30
    3764:      	mov	w9, #0x6                // =6
    3768:      	ldr	x8, [sp, #0x10]
    376c:      	ldr	x2, [x8]
    3770:      	blr	x9
    3774:      	b	0x3618 <perf_unwind_perl+0x3618>
    3778:      	ldr	w8, [x23]
    377c:      	cbnz	w8, 0x3d6c <perf_unwind_perl+0x3d6c>
    3780:      	ldrb	w8, [sp, #0x7c]
    3784:      	and	w9, w8, #0xf
    3788:      	sub	w10, w9, #0x9
    378c:      	cmp	w10, #0x2
    3790:      	b.hs	0x3db4 <perf_unwind_perl+0x3db4>
    3794:      	sxtb	w8, w8
    3798:      	tbnz	w8, #0x1f, 0x3dbc <perf_unwind_perl+0x3dbc>
    379c:      	ldrb	w8, [x22, #0x1b]
    37a0:      	mov	w9, #0x8                // =8
    37a4:      	mov	w10, #0x70              // =112
    37a8:      	add	x11, sp, #0x30
    37ac:      	add	x0, sp, #0x30
    37b0:      	mov	w1, #0x8                // =8
    37b4:      	add	x8, x25, x8
    37b8:      	ldrb	w8, [x22, #0x1b]
    37bc:      	add	x2, x25, x8
    37c0:      	blr	x10
    37c4:      	cbnz	x0, 0x36b4 <perf_unwind_perl+0x36b4>
    37c8:      	ldr	x8, [sp, #0x30]
    37cc:      	mov	w9, #0x8                // =8
    37d0:      	mov	w10, #0x70              // =112
    37d4:      	add	x11, sp, #0x70
    37d8:      	add	x0, sp, #0x70
    37dc:      	mov	w1, #0x8                // =8
    37e0:      	cmp	x8, #0x0
    37e4:      	mov	w8, #0x3                // =3
    37e8:      	csinc	w29, w8, wzr, ne
    37ec:      	ldrb	w8, [x22, #0x1c]
    37f0:      	add	x8, x25, x8
    37f4:      	ldrb	w8, [x22, #0x1c]
    37f8:      	add	x2, x25, x8
    37fc:      	blr	x10
    3800:      	cbnz	x0, 0x36b4 <perf_unwind_perl+0x36b4>
    3804:      	ldr	x24, [sp, #0x70]
    3808:      	ldrb	w8, [x22, #0x1e]
    380c:      	mov	w9, #0x4                // =4
    3810:      	mov	w10, #0x70              // =112
    3814:      	add	x11, sp, #0xb8
    3818:      	add	x0, sp, #0xb8
    381c:      	mov	w1, #0x4                // =4
    3820:      	add	x8, x24, x8
    3824:      	ldrb	w8, [x22, #0x1e]
    3828:      	add	x2, x24, x8
    382c:      	blr	x10
    3830:      	cbz	x0, 0x38c0 <perf_unwind_perl+0x38c0>
    3834:      	ldr	w8, [x23]
    3838:      	cbnz	w8, 0x52f0 <perf_unwind_perl+0x52f0>
    383c:      	mov	w8, #0x14               // =20
    3840:      	adrp	x0, 0x3000 <perf_unwind_perl+0x3000>
    3844:      	add	x9, sp, #0xbc
    3848:      	str	w8, [sp, #0xbc]
    384c:      	mov	w8, #0x1                // =1
    3850:      	add	x1, sp, #0xbc
    3854:      	ldr	x0, [x0]
    3858:      	blr	x8
    385c:      	cbz	x0, 0x3a7c <perf_unwind_perl+0x3a7c>
    3860:      	ldr	x8, [x0]
    3864:      	add	x8, x8, #0x1
    3868:      	str	x8, [x0]
    386c:      	b	0x36b4 <perf_unwind_perl+0x36b4>
    3870:      	ldr	w8, [x23]
    3874:      	cbz	w8, 0x3dbc <perf_unwind_perl+0x3dbc>
    3878:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    387c:      	add	x8, x8, #0x0
    3880:      	add	x0, sp, #0x30
    3884:      	ldp	x9, x10, [x8, #0x10]
    3888:      	mov	w1, #0x2e               // =46
    388c:      	stp	x9, x10, [sp, #0x40]
    3890:      	ldr	x9, [x8, #0x20]
    3894:      	add	x10, sp, #0x30
    3898:      	str	x9, [sp, #0x50]
    389c:      	ldur	x9, [x8, #0x26]
    38a0:      	stur	x9, [sp, #0x56]
    38a4:      	ldp	x9, x8, [x8]
    38a8:      	stp	x9, x8, [sp, #0x30]
    38ac:      	mov	w8, #0x2e               // =46
    38b0:      	mov	w9, #0x6                // =6
    38b4:      	ldr	w2, [sp, #0xa8]
    38b8:      	blr	x9
    38bc:      	b	0x3dbc <perf_unwind_perl+0x3dbc>
    38c0:      	ldr	w8, [sp, #0xb8]
    38c4:      	and	w8, w8, #0x1f
    38c8:      	cmp	w8, #0xd
    38cc:      	b.ne	0x3acc <perf_unwind_perl+0x3acc>
    38d0:      	ldrb	w8, [x22, #0x1f]
    38d4:      	mov	w9, #0x8                // =8
    38d8:      	mov	w10, #0x70              // =112
    38dc:      	add	x11, sp, #0xa8
    38e0:      	add	x0, sp, #0xa8
    38e4:      	mov	w1, #0x8                // =8
    38e8:      	add	x8, x24, x8
    38ec:      	ldrb	w8, [x22, #0x1f]
    38f0:      	add	x2, x24, x8
    38f4:      	blr	x10
    38f8:      	cbnz	x0, 0x3834 <perf_unwind_perl+0x3834>
    38fc:      	ldr	x8, [sp, #0xa8]
    3900:      	ldrb	w9, [x22, #0x21]
    3904:      	mov	w10, #0x70              // =112
    3908:      	add	x11, sp, #0xa4
    390c:      	add	x0, sp, #0xa4
    3910:      	mov	w1, #0x4                // =4
    3914:      	add	x8, x8, x9
    3918:      	mov	w9, #0x4                // =4
    391c:      	ldr	x8, [sp, #0xa8]
    3920:      	ldrb	w9, [x22, #0x21]
    3924:      	add	x2, x8, x9
    3928:      	blr	x10
    392c:      	cbnz	x0, 0x3834 <perf_unwind_perl+0x3834>
    3930:      	ldrb	w8, [sp, #0xa5]
    3934:      	tbnz	w8, #0x7, 0x3d20 <perf_unwind_perl+0x3d20>
    3938:      	ldr	x8, [sp, #0xa8]
    393c:      	ldrb	w9, [x22, #0x22]
    3940:      	mov	w10, #0x70              // =112
    3944:      	add	x11, sp, #0x98
    3948:      	add	x0, sp, #0x98
    394c:      	mov	w1, #0x8                // =8
    3950:      	add	x8, x8, x9
    3954:      	mov	w9, #0x8                // =8
    3958:      	ldr	x8, [sp, #0xa8]
    395c:      	ldrb	w9, [x22, #0x22]
    3960:      	add	x2, x8, x9
    3964:      	blr	x10
    3968:      	cbnz	x0, 0x3834 <perf_unwind_perl+0x3834>
    396c:      	ldr	x8, [sp, #0x98]
    3970:      	cbz	x8, 0x3834 <perf_unwind_perl+0x3834>
    3974:      	ldr	w9, [x23]
    3978:      	cbnz	w9, 0x685c <perf_unwind_perl+0x685c>
    397c:      	ldrb	w9, [x22, #0x1e]
    3980:      	mov	w10, #0x70              // =112
    3984:      	add	x11, sp, #0x94
    3988:      	add	x0, sp, #0x94
    398c:      	mov	w1, #0x4                // =4
    3990:      	add	x8, x8, x9
    3994:      	mov	w9, #0x4                // =4
    3998:      	ldr	x8, [sp, #0x98]
    399c:      	ldrb	w9, [x22, #0x1e]
    39a0:      	add	x2, x8, x9
    39a4:      	blr	x10
    39a8:      	cbnz	x0, 0x3834 <perf_unwind_perl+0x3834>
    39ac:      	ldr	w8, [sp, #0x94]
    39b0:      	mov	w9, #0x801f             // =32799
    39b4:      	and	w8, w8, w9
    39b8:      	mov	w9, #0x8009             // =32777
    39bc:      	cmp	w8, w9
    39c0:      	b.ne	0x4b04 <perf_unwind_perl+0x4b04>
    39c4:      	ldr	x8, [sp, #0x98]
    39c8:      	ldrb	w9, [x22, #0x20]
    39cc:      	mov	w10, #0x70              // =112
    39d0:      	add	x11, sp, #0x88
    39d4:      	add	x0, sp, #0x88
    39d8:      	mov	w1, #0x8                // =8
    39dc:      	add	x8, x8, x9
    39e0:      	mov	w9, #0x8                // =8
    39e4:      	ldr	x8, [sp, #0x98]
    39e8:      	ldrb	w9, [x22, #0x20]
    39ec:      	add	x2, x8, x9
    39f0:      	blr	x10
    39f4:      	cbnz	x0, 0x3834 <perf_unwind_perl+0x3834>
    39f8:      	ldr	x8, [sp, #0x88]
    39fc:      	ldrb	w9, [x22, #0x23]
    3a00:      	mov	w10, #0x70              // =112
    3a04:      	add	x11, sp, #0x80
    3a08:      	add	x0, sp, #0x80
    3a0c:      	mov	w1, #0x8                // =8
    3a10:      	add	x8, x8, x9
    3a14:      	mov	w9, #0x8                // =8
    3a18:      	ldr	x8, [sp, #0x88]
    3a1c:      	ldrb	w9, [x22, #0x23]
    3a20:      	add	x2, x8, x9
    3a24:      	blr	x10
    3a28:      	cbnz	x0, 0x3834 <perf_unwind_perl+0x3834>
    3a2c:      	ldr	x24, [sp, #0x80]
    3a30:      	cbz	x24, 0x6250 <perf_unwind_perl+0x6250>
    3a34:      	ldr	w8, [x23]
    3a38:      	cbz	w8, 0x625c <perf_unwind_perl+0x625c>
    3a3c:      	mov	w8, #0x786c             // =30828
    3a40:      	add	x10, sp, #0x30
    3a44:      	add	x0, sp, #0x30
    3a48:      	mov	w1, #0x14               // =20
    3a4c:      	movk	w8, #0xa, lsl #16
    3a50:      	str	w8, [sp, #0x40]
    3a54:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    3a58:      	add	x8, x8, #0x0
    3a5c:      	ldp	x9, x8, [x8]
    3a60:      	stp	x9, x8, [sp, #0x30]
    3a64:      	mov	w8, #0x14               // =20
    3a68:      	mov	w9, #0x6                // =6
    3a6c:      	ldr	x2, [sp, #0x80]
    3a70:      	blr	x9
    3a74:      	add	x8, sp, #0x80
    3a78:      	b	0x6254 <perf_unwind_perl+0x6254>
    3a7c:      	ldr	w8, [x23]
    3a80:      	cbz	w8, 0x36b4 <perf_unwind_perl+0x36b4>
    3a84:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    3a88:      	add	x8, x8, #0x0
    3a8c:      	add	x0, sp, #0x30
    3a90:      	ldp	x9, x10, [x8, #0x10]
    3a94:      	mov	w1, #0x2e               // =46
    3a98:      	stp	x9, x10, [sp, #0x40]
    3a9c:      	ldr	x9, [x8, #0x20]
    3aa0:      	add	x10, sp, #0x30
    3aa4:      	str	x9, [sp, #0x50]
    3aa8:      	ldur	x9, [x8, #0x26]
    3aac:      	stur	x9, [sp, #0x56]
    3ab0:      	ldp	x9, x8, [x8]
    3ab4:      	stp	x9, x8, [sp, #0x30]
    3ab8:      	mov	w8, #0x2e               // =46
    3abc:      	mov	w9, #0x6                // =6
    3ac0:      	ldr	w2, [sp, #0xbc]
    3ac4:      	blr	x9
    3ac8:      	b	0x36b4 <perf_unwind_perl+0x36b4>
    3acc:      	ldr	w8, [x23]
    3ad0:      	cbz	w8, 0x36b4 <perf_unwind_perl+0x36b4>
    3ad4:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    3ad8:      	add	x8, x8, #0x0
    3adc:      	add	x0, sp, #0x30
    3ae0:      	ldp	x9, x10, [x8]
    3ae4:      	mov	w1, #0x1e               // =30
    3ae8:      	stp	x9, x10, [sp, #0x30]
    3aec:      	ldr	x9, [x8, #0x10]
    3af0:      	ldur	x8, [x8, #0x16]
    3af4:      	add	x10, sp, #0x30
    3af8:      	str	x9, [sp, #0x40]
    3afc:      	stur	x8, [sp, #0x46]
    3b00:      	mov	w8, #0x1e               // =30
    3b04:      	mov	w9, #0x6                // =6
    3b08:      	ldr	w2, [sp, #0xb8]
    3b0c:      	blr	x9
    3b10:      	b	0x36b4 <perf_unwind_perl+0x36b4>
    3b14:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    3b18:      	add	x8, x8, #0x0
    3b1c:      	add	x0, sp, #0x30
    3b20:      	ldp	x9, x10, [x8, #0x10]
    3b24:      	mov	w1, #0x2e               // =46
    3b28:      	stp	x9, x10, [sp, #0x40]
    3b2c:      	ldr	x9, [x8, #0x20]
    3b30:      	add	x10, sp, #0x30
    3b34:      	str	x9, [sp, #0x50]
    3b38:      	ldur	x9, [x8, #0x26]
    3b3c:      	stur	x9, [sp, #0x56]
    3b40:      	ldp	x9, x8, [x8]
    3b44:      	stp	x9, x8, [sp, #0x30]
    3b48:      	mov	w8, #0x2e               // =46
    3b4c:      	mov	w9, #0x6                // =6
    3b50:      	ldr	w2, [sp, #0xa8]
    3b54:      	blr	x9
    3b58:      	ldp	x24, x9, [sp, #0x10]
    3b5c:      	cmp	w29, #0x3
    3b60:      	b.eq	0x367c <perf_unwind_perl+0x367c>
    3b64:      	b	0x563c <perf_unwind_perl+0x563c>
    3b68:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    3b6c:      	add	x8, x8, #0x0
    3b70:      	add	x0, sp, #0x30
    3b74:      	ldp	x9, x10, [x8, #0x10]
    3b78:      	mov	w1, #0x2d               // =45
    3b7c:      	stp	x9, x10, [sp, #0x40]
    3b80:      	ldr	x9, [x8, #0x20]
    3b84:      	add	x10, sp, #0x30
    3b88:      	str	x9, [sp, #0x50]
    3b8c:      	ldur	x9, [x8, #0x25]
    3b90:      	stur	x9, [sp, #0x55]
    3b94:      	ldp	x9, x8, [x8]
    3b98:      	stp	x9, x8, [sp, #0x30]
    3b9c:      	mov	w8, #0x2d               // =45
    3ba0:      	mov	w9, #0x6                // =6
    3ba4:      	blr	x9
    3ba8:      	b	0x22e0 <perf_unwind_perl+0x22e0>
    3bac:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    3bb0:      	add	x8, x8, #0x0
    3bb4:      	add	x0, sp, #0x30
    3bb8:      	ldp	x9, x10, [x8]
    3bbc:      	mov	w1, #0x1e               // =30
    3bc0:      	stp	x9, x10, [sp, #0x30]
    3bc4:      	ldr	x9, [x8, #0x10]
    3bc8:      	ldur	x8, [x8, #0x16]
    3bcc:      	add	x10, sp, #0x30
    3bd0:      	str	x9, [sp, #0x40]
    3bd4:      	stur	x8, [sp, #0x46]
    3bd8:      	mov	w8, #0x1e               // =30
    3bdc:      	mov	w9, #0x6                // =6
    3be0:      	ldr	w2, [sp, #0xb8]
    3be4:      	blr	x9
    3be8:      	b	0x1e5c <perf_unwind_perl+0x1e5c>
    3bec:      	mov	w8, #0xa                // =10
    3bf0:      	add	x0, sp, #0x30
    3bf4:      	mov	w1, #0x2a               // =42
    3bf8:      	strh	w8, [sp, #0x58]
    3bfc:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    3c00:      	add	x8, x8, #0x0
    3c04:      	mov	x2, x25
    3c08:      	ldp	x9, x10, [x8, #0x10]
    3c0c:      	stp	x9, x10, [sp, #0x40]
    3c10:      	ldr	x9, [x8, #0x20]
    3c14:      	add	x10, sp, #0x30
    3c18:      	str	x9, [sp, #0x50]
    3c1c:      	ldp	x8, x9, [x8]
    3c20:      	stp	x8, x9, [sp, #0x30]
    3c24:      	mov	w8, #0x2a               // =42
    3c28:      	mov	w9, #0x6                // =6
    3c2c:      	blr	x9
    3c30:      	b	0x36bc <perf_unwind_perl+0x36bc>
    3c34:      	ldr	w8, [x23]
    3c38:      	cbz	w8, 0x27f8 <perf_unwind_perl+0x27f8>
    3c3c:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    3c40:      	add	x8, x8, #0x0
    3c44:      	add	x0, sp, #0x30
    3c48:      	ldp	x9, x10, [x8, #0x10]
    3c4c:      	mov	w1, #0x26               // =38
    3c50:      	stp	x9, x10, [sp, #0x40]
    3c54:      	ldur	x9, [x8, #0x1e]
    3c58:      	add	x10, sp, #0x30
    3c5c:      	stur	x9, [sp, #0x4e]
    3c60:      	ldp	x8, x9, [x8]
    3c64:      	stp	x8, x9, [sp, #0x30]
    3c68:      	mov	w8, #0x26               // =38
    3c6c:      	mov	w9, #0x6                // =6
    3c70:      	ldr	w2, [sp, #0x94]
    3c74:      	blr	x9
    3c78:      	b	0x27f8 <perf_unwind_perl+0x27f8>
    3c7c:      	add	x8, sp, #0x98
    3c80:      	ldr	x8, [x8]
    3c84:      	ldr	x24, [sp, #0x10]
    3c88:      	str	x8, [sp, #0x8]
    3c8c:      	cbz	x8, 0x1a74 <perf_unwind_perl+0x1a74>
    3c90:      	ldr	x24, [x24]
    3c94:      	ldr	w8, [x23]
    3c98:      	cbnz	w8, 0x6588 <perf_unwind_perl+0x6588>
    3c9c:      	ldr	w8, [x21, #0x2c0]
    3ca0:      	cmp	w8, #0x7e
    3ca4:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    3ca8:      	add	w9, w8, #0x1
    3cac:      	mov	w10, #0x7               // =7
    3cb0:      	str	w9, [x21, #0x2c0]
    3cb4:      	mov	w9, #0x18               // =24
    3cb8:      	umaddl	x8, w8, w9, x21
    3cbc:      	str	x24, [x8, #0x2d8]
    3cc0:      	ldp	x9, x24, [sp, #0x8]
    3cc4:      	strb	w10, [x8, #0x2e0]
    3cc8:      	str	wzr, [x8, #0x2e4]
    3ccc:      	str	x9, [x8, #0x2d0]
    3cd0:      	add	x9, x8, #0x2d0
    3cd4:      	str	xzr, [x21, #0xf30]
    3cd8:      	stur	wzr, [x9, #0x11]
    3cdc:      	b	0x214c <perf_unwind_perl+0x214c>
    3ce0:      	mov	w8, #0x786c             // =30828
    3ce4:      	add	x10, sp, #0x30
    3ce8:      	add	x0, sp, #0x30
    3cec:      	mov	w1, #0x13               // =19
    3cf0:      	movk	w8, #0xa, lsl #16
    3cf4:      	stur	w8, [sp, #0x3f]
    3cf8:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    3cfc:      	add	x8, x8, #0x0
    3d00:      	ldp	x9, x8, [x8]
    3d04:      	stp	x9, x8, [sp, #0x30]
    3d08:      	mov	w8, #0x13               // =19
    3d0c:      	mov	w9, #0x6                // =6
    3d10:      	ldr	x2, [sp, #0x98]
    3d14:      	blr	x9
    3d18:      	ldr	x8, [sp, #0x98]
    3d1c:      	b	0xfa0 <perf_unwind_perl+0xfa0>
    3d20:      	ldr	w8, [x23]
    3d24:      	cbz	w8, 0x36b4 <perf_unwind_perl+0x36b4>
    3d28:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    3d2c:      	add	x8, x8, #0x0
    3d30:      	add	x0, sp, #0x30
    3d34:      	ldp	x9, x10, [x8, #0x10]
    3d38:      	mov	w1, #0x26               // =38
    3d3c:      	stp	x9, x10, [sp, #0x40]
    3d40:      	ldur	x9, [x8, #0x1e]
    3d44:      	add	x10, sp, #0x30
    3d48:      	stur	x9, [sp, #0x4e]
    3d4c:      	ldp	x8, x9, [x8]
    3d50:      	stp	x8, x9, [sp, #0x30]
    3d54:      	mov	w8, #0x26               // =38
    3d58:      	mov	w9, #0x6                // =6
    3d5c:      	ldr	w2, [sp, #0xb8]
    3d60:      	ldr	w3, [sp, #0xa4]
    3d64:      	blr	x9
    3d68:      	b	0x36b4 <perf_unwind_perl+0x36b4>
    3d6c:      	mov	w8, #0xa                // =10
    3d70:      	add	x10, sp, #0x30
    3d74:      	add	x0, sp, #0x30
    3d78:      	strh	w8, [sp, #0x40]
    3d7c:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    3d80:      	add	x8, x8, #0x0
    3d84:      	mov	w1, #0x12               // =18
    3d88:      	ldp	x9, x8, [x8]
    3d8c:      	stp	x9, x8, [sp, #0x30]
    3d90:      	mov	w8, #0x12               // =18
    3d94:      	mov	w9, #0x6                // =6
    3d98:      	ldrb	w2, [sp, #0x7c]
    3d9c:      	blr	x9
    3da0:      	ldrb	w8, [sp, #0x7c]
    3da4:      	and	w9, w8, #0xf
    3da8:      	sub	w10, w9, #0x9
    3dac:      	cmp	w10, #0x2
    3db0:      	b.lo	0x3794 <perf_unwind_perl+0x3794>
    3db4:      	cmp	w9, #0xc
    3db8:      	b.ne	0x3e9c <perf_unwind_perl+0x3e9c>
    3dbc:      	mov	w29, #0x3               // =3
    3dc0:      	ldrb	w8, [x22, #0x1d]
    3dc4:      	ldr	x9, [x21, #0xf40]
    3dc8:      	adrp	x0, 0x3000 <perf_unwind_perl+0x3000>
    3dcc:      	add	x1, sp, #0xa8
    3dd0:      	sub	x8, x9, x8
    3dd4:      	add	x9, sp, #0xa8
    3dd8:      	str	x8, [x21, #0xf40]
    3ddc:      	mov	w8, #0x10               // =16
    3de0:      	str	w8, [sp, #0xa8]
    3de4:      	mov	w8, #0x1                // =1
    3de8:      	ldr	x0, [x0]
    3dec:      	blr	x8
    3df0:      	cbz	x0, 0x3e10 <perf_unwind_perl+0x3e10>
    3df4:      	ldr	x8, [x0]
    3df8:      	add	x8, x8, #0x1
    3dfc:      	str	x8, [x0]
    3e00:      	ldp	x24, x9, [sp, #0x10]
    3e04:      	cmp	w29, #0x3
    3e08:      	b.eq	0x3e24 <perf_unwind_perl+0x3e24>
    3e0c:      	b	0x563c <perf_unwind_perl+0x563c>
    3e10:      	ldr	w8, [x23]
    3e14:      	cbnz	w8, 0x42bc <perf_unwind_perl+0x42bc>
    3e18:      	ldp	x24, x9, [sp, #0x10]
    3e1c:      	cmp	w29, #0x3
    3e20:      	b.ne	0x563c <perf_unwind_perl+0x563c>
    3e24:      	ldr	x25, [x21, #0xf40]
    3e28:      	cmp	x25, x9
    3e2c:      	b.lo	0x2ecc <perf_unwind_perl+0x2ecc>
    3e30:      	ldrb	w8, [x22, #0x19]
    3e34:      	mov	w9, #0x1                // =1
    3e38:      	mov	w10, #0x70              // =112
    3e3c:      	add	x11, sp, #0x7c
    3e40:      	add	x0, sp, #0x7c
    3e44:      	mov	w1, #0x1                // =1
    3e48:      	add	x8, x25, x8
    3e4c:      	ldrb	w8, [x22, #0x19]
    3e50:      	add	x2, x25, x8
    3e54:      	blr	x10
    3e58:      	cbz	x0, 0x3f20 <perf_unwind_perl+0x3f20>
    3e5c:      	ldr	w8, [x23]
    3e60:      	cbnz	w8, 0x4354 <perf_unwind_perl+0x4354>
    3e64:      	mov	w8, #0x13               // =19
    3e68:      	adrp	x0, 0x3000 <perf_unwind_perl+0x3000>
    3e6c:      	add	x9, sp, #0xa8
    3e70:      	str	w8, [sp, #0xa8]
    3e74:      	mov	w8, #0x1                // =1
    3e78:      	add	x1, sp, #0xa8
    3e7c:      	ldr	x0, [x0]
    3e80:      	blr	x8
    3e84:      	cbz	x0, 0x4018 <perf_unwind_perl+0x4018>
    3e88:      	ldr	x8, [x0]
    3e8c:      	mov	w29, #0x3               // =3
    3e90:      	add	x8, x8, #0x1
    3e94:      	str	x8, [x0]
    3e98:      	b	0x4528 <perf_unwind_perl+0x4528>
    3e9c:      	ldr	x8, [sp, #0x10]
    3ea0:      	mov	w29, #0x3               // =3
    3ea4:      	ldr	x8, [x8]
    3ea8:      	cbnz	x8, 0x3dc0 <perf_unwind_perl+0x3dc0>
    3eac:      	ldrb	w8, [x22, #0x1a]
    3eb0:      	mov	w9, #0x8                // =8
    3eb4:      	mov	w10, #0x70              // =112
    3eb8:      	ldr	x0, [sp, #0x10]
    3ebc:      	mov	w1, #0x8                // =8
    3ec0:      	add	x8, x25, x8
    3ec4:      	ldrb	w8, [x22, #0x1a]
    3ec8:      	add	x2, x25, x8
    3ecc:      	blr	x10
    3ed0:      	cbnz	x0, 0x36b4 <perf_unwind_perl+0x36b4>
    3ed4:      	ldr	w8, [x23]
    3ed8:      	cbz	w8, 0x3dc0 <perf_unwind_perl+0x3dc0>
    3edc:      	adrp	x8, 0x3000 <perf_unwind_perl+0x3000>
    3ee0:      	add	x8, x8, #0x0
    3ee4:      	add	x0, sp, #0x30
    3ee8:      	ldp	x9, x10, [x8]
    3eec:      	mov	w1, #0x1e               // =30
    3ef0:      	stp	x9, x10, [sp, #0x30]
    3ef4:      	ldr	x9, [x8, #0x10]
    3ef8:      	ldur	x8, [x8, #0x16]
    3efc:      	add	x10, sp, #0x30
    3f00:      	str	x9, [sp, #0x40]
    3f04:      	stur	x8, [sp, #0x46]
    3f08:      	mov	w8, #0x1e               // =30
    3f0c:      	mov	w9, #0x6                // =6
    3f10:      	ldr	x8, [sp, #0x10]
    3f14:      	ldr	x2, [x8]
    3f18:      	blr	x9
    3f1c:      	b	0x3dc0 <perf_unwind_perl+0x3dc0>
    3f20:      	ldr	w8, [x23]
    3f24:      	cbnz	w8, 0x44d4 <perf_unwind_perl+0x44d4>
    3f28:      	ldrb	w8, [sp, #0x7c]
    3f2c:      	and	w9, w8, #0xf
    3f30:      	sub	w10, w9, #0x9
    3f34:      	cmp	w10, #0x2
    3f38:      	b.hs	0x451c <perf_unwind_perl+0x451c>
    3f3c:      	sxtb	w8, w8
    3f40:      	tbnz	w8, #0x1f, 0x4524 <perf_unwind_perl+0x4524>
    3f44:      	ldrb	w8, [x22, #0x1b]
    3f48:      	mov	w9, #0x8                // =8
    3f4c:      	mov	w10, #0x70              // =112
    3f50:      	add	x11, sp, #0x30
    3f54:      	add	x0, sp, #0x30
    3f58:      	mov	w1, #0x8                // =8
    3f5c:      	add	x8, x25, x8
    3f60:      	ldrb	w8, [x22, #0x1b]
    3f64:      	add	x2, x25, x8
    3f68:      	blr	x10
    3f6c:      	cbnz	x0, 0x3e5c <perf_unwind_perl+0x3e5c>
    3f70:      	ldr	x8, [sp, #0x30]
    3f74:      	mov	w9, #0x8                // =8
    3f78:      	mov	w10, #0x70              // =112
    3f7c:      	add	x11, sp, #0x70
    3f80:      	add	x0, sp, #0x70
    3f84:      	mov	w1, #0x8                // =8
    3f88:      	cmp	x8, #0x0
    3f8c:      	mov	w8, #0x3                // =3
    3f90:      	csinc	w29, w8, wzr, ne
    3f94:      	ldrb	w8, [x22, #0x1c]
    3f98:      	add	x8, x25, x8
    3f9c:      	ldrb	w8, [x22, #0x1c]
    3fa0:      	add	x2, x25, x8
    3fa4:      	blr	x10
    3fa8:      	cbnz	x0, 0x3e5c <perf_unwind_perl+0x3e5c>
    3fac:      	ldr	x24, [sp, #0x70]
    3fb0:      	ldrb	w8, [x22, #0x1e]
    3fb4:      	mov	w9, #0x4                // =4
    3fb8:      	mov	w10, #0x70              // =112
    3fbc:      	add	x11, sp, #0xb8
    3fc0:      	add	x0, sp, #0xb8
    3fc4:      	mov	w1, #0x4                // =4
    3fc8:      	add	x8, x24, x8
    3fcc:      	ldrb	w8, [x22, #0x1e]
    3fd0:      	add	x2, x24, x8
    3fd4:      	blr	x10
    3fd8:      	cbz	x0, 0x4068 <perf_unwind_perl+0x4068>
    3fdc:      	ldr	w8, [x23]
    3fe0:      	cbnz	w8, 0x612c <perf_unwind_perl+0x612c>
    3fe4:      	mov	w8, #0x14               // =20
    3fe8:      	adrp	x0, 0x3000 <perf_unwind_perl+0x3000>
    3fec:      	add	x9, sp, #0xbc
    3ff0:      	str	w8, [sp, #0xbc]
    3ff4:      	mov	w8, #0x1                // =1
    3ff8:      	add	x1, sp, #0xbc
    3ffc:      	ldr	x0, [x0]
    4000:      	blr	x8
    4004:      	cbz	x0, 0x4224 <perf_unwind_perl+0x4224>
    4008:      	ldr	x8, [x0]
    400c:      	add	x8, x8, #0x1
    4010:      	str	x8, [x0]
    4014:      	b	0x3e5c <perf_unwind_perl+0x3e5c>
    4018:      	ldr	w8, [x23]
    401c:      	cbz	w8, 0x4524 <perf_unwind_perl+0x4524>
    4020:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4024:      	add	x8, x8, #0x0
    4028:      	add	x0, sp, #0x30
    402c:      	ldp	x9, x10, [x8, #0x10]
    4030:      	mov	w1, #0x2e               // =46
    4034:      	stp	x9, x10, [sp, #0x40]
    4038:      	ldr	x9, [x8, #0x20]
    403c:      	add	x10, sp, #0x30
    4040:      	str	x9, [sp, #0x50]
    4044:      	ldur	x9, [x8, #0x26]
    4048:      	stur	x9, [sp, #0x56]
    404c:      	ldp	x9, x8, [x8]
    4050:      	stp	x9, x8, [sp, #0x30]
    4054:      	mov	w8, #0x2e               // =46
    4058:      	mov	w9, #0x6                // =6
    405c:      	ldr	w2, [sp, #0xa8]
    4060:      	blr	x9
    4064:      	b	0x4524 <perf_unwind_perl+0x4524>
    4068:      	ldr	w8, [sp, #0xb8]
    406c:      	and	w8, w8, #0x1f
    4070:      	cmp	w8, #0xd
    4074:      	b.ne	0x4274 <perf_unwind_perl+0x4274>
    4078:      	ldrb	w8, [x22, #0x1f]
    407c:      	mov	w9, #0x8                // =8
    4080:      	mov	w10, #0x70              // =112
    4084:      	add	x11, sp, #0xa8
    4088:      	add	x0, sp, #0xa8
    408c:      	mov	w1, #0x8                // =8
    4090:      	add	x8, x24, x8
    4094:      	ldrb	w8, [x22, #0x1f]
    4098:      	add	x2, x24, x8
    409c:      	blr	x10
    40a0:      	cbnz	x0, 0x3fdc <perf_unwind_perl+0x3fdc>
    40a4:      	ldr	x8, [sp, #0xa8]
    40a8:      	ldrb	w9, [x22, #0x21]
    40ac:      	mov	w10, #0x70              // =112
    40b0:      	add	x11, sp, #0xa4
    40b4:      	add	x0, sp, #0xa4
    40b8:      	mov	w1, #0x4                // =4
    40bc:      	add	x8, x8, x9
    40c0:      	mov	w9, #0x4                // =4
    40c4:      	ldr	x8, [sp, #0xa8]
    40c8:      	ldrb	w9, [x22, #0x21]
    40cc:      	add	x2, x8, x9
    40d0:      	blr	x10
    40d4:      	cbnz	x0, 0x3fdc <perf_unwind_perl+0x3fdc>
    40d8:      	ldrb	w8, [sp, #0xa5]
    40dc:      	tbnz	w8, #0x7, 0x4488 <perf_unwind_perl+0x4488>
    40e0:      	ldr	x8, [sp, #0xa8]
    40e4:      	ldrb	w9, [x22, #0x22]
    40e8:      	mov	w10, #0x70              // =112
    40ec:      	add	x11, sp, #0x98
    40f0:      	add	x0, sp, #0x98
    40f4:      	mov	w1, #0x8                // =8
    40f8:      	add	x8, x8, x9
    40fc:      	mov	w9, #0x8                // =8
    4100:      	ldr	x8, [sp, #0xa8]
    4104:      	ldrb	w9, [x22, #0x22]
    4108:      	add	x2, x8, x9
    410c:      	blr	x10
    4110:      	cbnz	x0, 0x3fdc <perf_unwind_perl+0x3fdc>
    4114:      	ldr	x8, [sp, #0x98]
    4118:      	cbz	x8, 0x3fdc <perf_unwind_perl+0x3fdc>
    411c:      	ldr	w9, [x23]
    4120:      	cbnz	w9, 0x69e4 <perf_unwind_perl+0x69e4>
    4124:      	ldrb	w9, [x22, #0x1e]
    4128:      	mov	w10, #0x70              // =112
    412c:      	add	x11, sp, #0x94
    4130:      	add	x0, sp, #0x94
    4134:      	mov	w1, #0x4                // =4
    4138:      	add	x8, x8, x9
    413c:      	mov	w9, #0x4                // =4
    4140:      	ldr	x8, [sp, #0x98]
    4144:      	ldrb	w9, [x22, #0x1e]
    4148:      	add	x2, x8, x9
    414c:      	blr	x10
    4150:      	cbnz	x0, 0x3fdc <perf_unwind_perl+0x3fdc>
    4154:      	ldr	w8, [sp, #0x94]
    4158:      	mov	w9, #0x801f             // =32799
    415c:      	and	w8, w8, w9
    4160:      	mov	w9, #0x8009             // =32777
    4164:      	cmp	w8, w9
    4168:      	b.ne	0x537c <perf_unwind_perl+0x537c>
    416c:      	ldr	x8, [sp, #0x98]
    4170:      	ldrb	w9, [x22, #0x20]
    4174:      	mov	w10, #0x70              // =112
    4178:      	add	x11, sp, #0x88
    417c:      	add	x0, sp, #0x88
    4180:      	mov	w1, #0x8                // =8
    4184:      	add	x8, x8, x9
    4188:      	mov	w9, #0x8                // =8
    418c:      	ldr	x8, [sp, #0x98]
    4190:      	ldrb	w9, [x22, #0x20]
    4194:      	add	x2, x8, x9
    4198:      	blr	x10
    419c:      	cbnz	x0, 0x3fdc <perf_unwind_perl+0x3fdc>
    41a0:      	ldr	x8, [sp, #0x88]
    41a4:      	ldrb	w9, [x22, #0x23]
    41a8:      	mov	w10, #0x70              // =112
    41ac:      	add	x11, sp, #0x80
    41b0:      	add	x0, sp, #0x80
    41b4:      	mov	w1, #0x8                // =8
    41b8:      	add	x8, x8, x9
    41bc:      	mov	w9, #0x8                // =8
    41c0:      	ldr	x8, [sp, #0x88]
    41c4:      	ldrb	w9, [x22, #0x23]
    41c8:      	add	x2, x8, x9
    41cc:      	blr	x10
    41d0:      	cbnz	x0, 0x3fdc <perf_unwind_perl+0x3fdc>
    41d4:      	ldr	x24, [sp, #0x80]
    41d8:      	cbz	x24, 0x65d8 <perf_unwind_perl+0x65d8>
    41dc:      	ldr	w8, [x23]
    41e0:      	cbz	w8, 0x65e4 <perf_unwind_perl+0x65e4>
    41e4:      	mov	w8, #0x786c             // =30828
    41e8:      	add	x10, sp, #0x30
    41ec:      	add	x0, sp, #0x30
    41f0:      	mov	w1, #0x14               // =20
    41f4:      	movk	w8, #0xa, lsl #16
    41f8:      	str	w8, [sp, #0x40]
    41fc:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4200:      	add	x8, x8, #0x0
    4204:      	ldp	x9, x8, [x8]
    4208:      	stp	x9, x8, [sp, #0x30]
    420c:      	mov	w8, #0x14               // =20
    4210:      	mov	w9, #0x6                // =6
    4214:      	ldr	x2, [sp, #0x80]
    4218:      	blr	x9
    421c:      	add	x8, sp, #0x80
    4220:      	b	0x65dc <perf_unwind_perl+0x65dc>
    4224:      	ldr	w8, [x23]
    4228:      	cbz	w8, 0x3e5c <perf_unwind_perl+0x3e5c>
    422c:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4230:      	add	x8, x8, #0x0
    4234:      	add	x0, sp, #0x30
    4238:      	ldp	x9, x10, [x8, #0x10]
    423c:      	mov	w1, #0x2e               // =46
    4240:      	stp	x9, x10, [sp, #0x40]
    4244:      	ldr	x9, [x8, #0x20]
    4248:      	add	x10, sp, #0x30
    424c:      	str	x9, [sp, #0x50]
    4250:      	ldur	x9, [x8, #0x26]
    4254:      	stur	x9, [sp, #0x56]
    4258:      	ldp	x9, x8, [x8]
    425c:      	stp	x9, x8, [sp, #0x30]
    4260:      	mov	w8, #0x2e               // =46
    4264:      	mov	w9, #0x6                // =6
    4268:      	ldr	w2, [sp, #0xbc]
    426c:      	blr	x9
    4270:      	b	0x3e5c <perf_unwind_perl+0x3e5c>
    4274:      	ldr	w8, [x23]
    4278:      	cbz	w8, 0x3e5c <perf_unwind_perl+0x3e5c>
    427c:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4280:      	add	x8, x8, #0x0
    4284:      	add	x0, sp, #0x30
    4288:      	ldp	x9, x10, [x8]
    428c:      	mov	w1, #0x1e               // =30
    4290:      	stp	x9, x10, [sp, #0x30]
    4294:      	ldr	x9, [x8, #0x10]
    4298:      	ldur	x8, [x8, #0x16]
    429c:      	add	x10, sp, #0x30
    42a0:      	str	x9, [sp, #0x40]
    42a4:      	stur	x8, [sp, #0x46]
    42a8:      	mov	w8, #0x1e               // =30
    42ac:      	mov	w9, #0x6                // =6
    42b0:      	ldr	w2, [sp, #0xb8]
    42b4:      	blr	x9
    42b8:      	b	0x3e5c <perf_unwind_perl+0x3e5c>
    42bc:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    42c0:      	add	x8, x8, #0x0
    42c4:      	add	x0, sp, #0x30
    42c8:      	ldp	x9, x10, [x8, #0x10]
    42cc:      	mov	w1, #0x2e               // =46
    42d0:      	stp	x9, x10, [sp, #0x40]
    42d4:      	ldr	x9, [x8, #0x20]
    42d8:      	add	x10, sp, #0x30
    42dc:      	str	x9, [sp, #0x50]
    42e0:      	ldur	x9, [x8, #0x26]
    42e4:      	stur	x9, [sp, #0x56]
    42e8:      	ldp	x9, x8, [x8]
    42ec:      	stp	x9, x8, [sp, #0x30]
    42f0:      	mov	w8, #0x2e               // =46
    42f4:      	mov	w9, #0x6                // =6
    42f8:      	ldr	w2, [sp, #0xa8]
    42fc:      	blr	x9
    4300:      	ldp	x24, x9, [sp, #0x10]
    4304:      	cmp	w29, #0x3
    4308:      	b.eq	0x3e24 <perf_unwind_perl+0x3e24>
    430c:      	b	0x563c <perf_unwind_perl+0x563c>
    4310:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4314:      	add	x8, x8, #0x0
    4318:      	add	x0, sp, #0x30
    431c:      	ldp	x9, x10, [x8, #0x10]
    4320:      	mov	w1, #0x2d               // =45
    4324:      	stp	x9, x10, [sp, #0x40]
    4328:      	ldr	x9, [x8, #0x20]
    432c:      	add	x10, sp, #0x30
    4330:      	str	x9, [sp, #0x50]
    4334:      	ldur	x9, [x8, #0x25]
    4338:      	stur	x9, [sp, #0x55]
    433c:      	ldp	x9, x8, [x8]
    4340:      	stp	x9, x8, [sp, #0x30]
    4344:      	mov	w8, #0x2d               // =45
    4348:      	mov	w9, #0x6                // =6
    434c:      	blr	x9
    4350:      	b	0x2978 <perf_unwind_perl+0x2978>
    4354:      	mov	w8, #0xa                // =10
    4358:      	add	x0, sp, #0x30
    435c:      	mov	w1, #0x2a               // =42
    4360:      	strh	w8, [sp, #0x58]
    4364:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4368:      	add	x8, x8, #0x0
    436c:      	mov	x2, x25
    4370:      	ldp	x9, x10, [x8, #0x10]
    4374:      	stp	x9, x10, [sp, #0x40]
    4378:      	ldr	x9, [x8, #0x20]
    437c:      	add	x10, sp, #0x30
    4380:      	str	x9, [sp, #0x50]
    4384:      	ldp	x8, x9, [x8]
    4388:      	stp	x8, x9, [sp, #0x30]
    438c:      	mov	w8, #0x2a               // =42
    4390:      	mov	w9, #0x6                // =6
    4394:      	blr	x9
    4398:      	b	0x3e64 <perf_unwind_perl+0x3e64>
    439c:      	ldr	w8, [x23]
    43a0:      	cbz	w8, 0x2f04 <perf_unwind_perl+0x2f04>
    43a4:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    43a8:      	add	x8, x8, #0x0
    43ac:      	add	x0, sp, #0x30
    43b0:      	ldp	x9, x10, [x8, #0x10]
    43b4:      	mov	w1, #0x26               // =38
    43b8:      	stp	x9, x10, [sp, #0x40]
    43bc:      	ldur	x9, [x8, #0x1e]
    43c0:      	add	x10, sp, #0x30
    43c4:      	stur	x9, [sp, #0x4e]
    43c8:      	ldp	x8, x9, [x8]
    43cc:      	stp	x8, x9, [sp, #0x30]
    43d0:      	mov	w8, #0x26               // =38
    43d4:      	mov	w9, #0x6                // =6
    43d8:      	ldr	w2, [sp, #0x94]
    43dc:      	blr	x9
    43e0:      	b	0x2f04 <perf_unwind_perl+0x2f04>
    43e4:      	add	x8, sp, #0x98
    43e8:      	ldr	x8, [x8]
    43ec:      	ldr	x24, [sp, #0x10]
    43f0:      	str	x8, [sp, #0x8]
    43f4:      	cbz	x8, 0x2100 <perf_unwind_perl+0x2100>
    43f8:      	ldr	x24, [x24]
    43fc:      	ldr	w8, [x23]
    4400:      	cbnz	w8, 0x6758 <perf_unwind_perl+0x6758>
    4404:      	ldr	w8, [x21, #0x2c0]
    4408:      	cmp	w8, #0x7e
    440c:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    4410:      	add	w9, w8, #0x1
    4414:      	mov	w10, #0x7               // =7
    4418:      	str	w9, [x21, #0x2c0]
    441c:      	mov	w9, #0x18               // =24
    4420:      	umaddl	x8, w8, w9, x21
    4424:      	str	x24, [x8, #0x2d8]
    4428:      	ldp	x9, x24, [sp, #0x8]
    442c:      	strb	w10, [x8, #0x2e0]
    4430:      	str	wzr, [x8, #0x2e4]
    4434:      	str	x9, [x8, #0x2d0]
    4438:      	add	x9, x8, #0x2d0
    443c:      	str	xzr, [x21, #0xf30]
    4440:      	stur	wzr, [x9, #0x11]
    4444:      	b	0x2844 <perf_unwind_perl+0x2844>
    4448:      	mov	w8, #0x786c             // =30828
    444c:      	add	x10, sp, #0x30
    4450:      	add	x0, sp, #0x30
    4454:      	mov	w1, #0x13               // =19
    4458:      	movk	w8, #0xa, lsl #16
    445c:      	stur	w8, [sp, #0x3f]
    4460:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4464:      	add	x8, x8, #0x0
    4468:      	ldp	x9, x8, [x8]
    446c:      	stp	x9, x8, [sp, #0x30]
    4470:      	mov	w8, #0x13               // =19
    4474:      	mov	w9, #0x6                // =6
    4478:      	ldr	x2, [sp, #0x98]
    447c:      	blr	x9
    4480:      	ldr	x8, [sp, #0x98]
    4484:      	b	0x15e4 <perf_unwind_perl+0x15e4>
    4488:      	ldr	w8, [x23]
    448c:      	cbz	w8, 0x3e5c <perf_unwind_perl+0x3e5c>
    4490:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4494:      	add	x8, x8, #0x0
    4498:      	add	x0, sp, #0x30
    449c:      	ldp	x9, x10, [x8, #0x10]
    44a0:      	mov	w1, #0x26               // =38
    44a4:      	stp	x9, x10, [sp, #0x40]
    44a8:      	ldur	x9, [x8, #0x1e]
    44ac:      	add	x10, sp, #0x30
    44b0:      	stur	x9, [sp, #0x4e]
    44b4:      	ldp	x8, x9, [x8]
    44b8:      	stp	x8, x9, [sp, #0x30]
    44bc:      	mov	w8, #0x26               // =38
    44c0:      	mov	w9, #0x6                // =6
    44c4:      	ldr	w2, [sp, #0xb8]
    44c8:      	ldr	w3, [sp, #0xa4]
    44cc:      	blr	x9
    44d0:      	b	0x3e5c <perf_unwind_perl+0x3e5c>
    44d4:      	mov	w8, #0xa                // =10
    44d8:      	add	x10, sp, #0x30
    44dc:      	add	x0, sp, #0x30
    44e0:      	strh	w8, [sp, #0x40]
    44e4:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    44e8:      	add	x8, x8, #0x0
    44ec:      	mov	w1, #0x12               // =18
    44f0:      	ldp	x9, x8, [x8]
    44f4:      	stp	x9, x8, [sp, #0x30]
    44f8:      	mov	w8, #0x12               // =18
    44fc:      	mov	w9, #0x6                // =6
    4500:      	ldrb	w2, [sp, #0x7c]
    4504:      	blr	x9
    4508:      	ldrb	w8, [sp, #0x7c]
    450c:      	and	w9, w8, #0xf
    4510:      	sub	w10, w9, #0x9
    4514:      	cmp	w10, #0x2
    4518:      	b.lo	0x3f3c <perf_unwind_perl+0x3f3c>
    451c:      	cmp	w9, #0xc
    4520:      	b.ne	0x4604 <perf_unwind_perl+0x4604>
    4524:      	mov	w29, #0x3               // =3
    4528:      	ldrb	w8, [x22, #0x1d]
    452c:      	ldr	x9, [x21, #0xf40]
    4530:      	adrp	x0, 0x4000 <perf_unwind_perl+0x4000>
    4534:      	add	x1, sp, #0xa8
    4538:      	sub	x8, x9, x8
    453c:      	add	x9, sp, #0xa8
    4540:      	str	x8, [x21, #0xf40]
    4544:      	mov	w8, #0x10               // =16
    4548:      	str	w8, [sp, #0xa8]
    454c:      	mov	w8, #0x1                // =1
    4550:      	ldr	x0, [x0]
    4554:      	blr	x8
    4558:      	cbz	x0, 0x4578 <perf_unwind_perl+0x4578>
    455c:      	ldr	x8, [x0]
    4560:      	add	x8, x8, #0x1
    4564:      	str	x8, [x0]
    4568:      	ldp	x24, x9, [sp, #0x10]
    456c:      	cmp	w29, #0x3
    4570:      	b.eq	0x458c <perf_unwind_perl+0x458c>
    4574:      	b	0x563c <perf_unwind_perl+0x563c>
    4578:      	ldr	w8, [x23]
    457c:      	cbnz	w8, 0x4a24 <perf_unwind_perl+0x4a24>
    4580:      	ldp	x24, x9, [sp, #0x10]
    4584:      	cmp	w29, #0x3
    4588:      	b.ne	0x563c <perf_unwind_perl+0x563c>
    458c:      	ldr	x25, [x21, #0xf40]
    4590:      	cmp	x25, x9
    4594:      	b.lo	0x2ecc <perf_unwind_perl+0x2ecc>
    4598:      	ldrb	w8, [x22, #0x19]
    459c:      	mov	w9, #0x1                // =1
    45a0:      	mov	w10, #0x70              // =112
    45a4:      	add	x11, sp, #0x7c
    45a8:      	add	x0, sp, #0x7c
    45ac:      	mov	w1, #0x1                // =1
    45b0:      	add	x8, x25, x8
    45b4:      	ldrb	w8, [x22, #0x19]
    45b8:      	add	x2, x25, x8
    45bc:      	blr	x10
    45c0:      	cbz	x0, 0x4688 <perf_unwind_perl+0x4688>
    45c4:      	ldr	w8, [x23]
    45c8:      	cbnz	w8, 0x4abc <perf_unwind_perl+0x4abc>
    45cc:      	mov	w8, #0x13               // =19
    45d0:      	adrp	x0, 0x4000 <perf_unwind_perl+0x4000>
    45d4:      	add	x9, sp, #0xa8
    45d8:      	str	w8, [sp, #0xa8]
    45dc:      	mov	w8, #0x1                // =1
    45e0:      	add	x1, sp, #0xa8
    45e4:      	ldr	x0, [x0]
    45e8:      	blr	x8
    45ec:      	cbz	x0, 0x4780 <perf_unwind_perl+0x4780>
    45f0:      	ldr	x8, [x0]
    45f4:      	mov	w29, #0x3               // =3
    45f8:      	add	x8, x8, #0x1
    45fc:      	str	x8, [x0]
    4600:      	b	0x4da0 <perf_unwind_perl+0x4da0>
    4604:      	ldr	x8, [sp, #0x10]
    4608:      	mov	w29, #0x3               // =3
    460c:      	ldr	x8, [x8]
    4610:      	cbnz	x8, 0x4528 <perf_unwind_perl+0x4528>
    4614:      	ldrb	w8, [x22, #0x1a]
    4618:      	mov	w9, #0x8                // =8
    461c:      	mov	w10, #0x70              // =112
    4620:      	ldr	x0, [sp, #0x10]
    4624:      	mov	w1, #0x8                // =8
    4628:      	add	x8, x25, x8
    462c:      	ldrb	w8, [x22, #0x1a]
    4630:      	add	x2, x25, x8
    4634:      	blr	x10
    4638:      	cbnz	x0, 0x3e5c <perf_unwind_perl+0x3e5c>
    463c:      	ldr	w8, [x23]
    4640:      	cbz	w8, 0x4528 <perf_unwind_perl+0x4528>
    4644:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4648:      	add	x8, x8, #0x0
    464c:      	add	x0, sp, #0x30
    4650:      	ldp	x9, x10, [x8]
    4654:      	mov	w1, #0x1e               // =30
    4658:      	stp	x9, x10, [sp, #0x30]
    465c:      	ldr	x9, [x8, #0x10]
    4660:      	ldur	x8, [x8, #0x16]
    4664:      	add	x10, sp, #0x30
    4668:      	str	x9, [sp, #0x40]
    466c:      	stur	x8, [sp, #0x46]
    4670:      	mov	w8, #0x1e               // =30
    4674:      	mov	w9, #0x6                // =6
    4678:      	ldr	x8, [sp, #0x10]
    467c:      	ldr	x2, [x8]
    4680:      	blr	x9
    4684:      	b	0x4528 <perf_unwind_perl+0x4528>
    4688:      	ldr	w8, [x23]
    468c:      	cbnz	w8, 0x4d4c <perf_unwind_perl+0x4d4c>
    4690:      	ldrb	w8, [sp, #0x7c]
    4694:      	and	w9, w8, #0xf
    4698:      	sub	w10, w9, #0x9
    469c:      	cmp	w10, #0x2
    46a0:      	b.hs	0x4d94 <perf_unwind_perl+0x4d94>
    46a4:      	sxtb	w8, w8
    46a8:      	tbnz	w8, #0x1f, 0x4d9c <perf_unwind_perl+0x4d9c>
    46ac:      	ldrb	w8, [x22, #0x1b]
    46b0:      	mov	w9, #0x8                // =8
    46b4:      	mov	w10, #0x70              // =112
    46b8:      	add	x11, sp, #0x30
    46bc:      	add	x0, sp, #0x30
    46c0:      	mov	w1, #0x8                // =8
    46c4:      	add	x8, x25, x8
    46c8:      	ldrb	w8, [x22, #0x1b]
    46cc:      	add	x2, x25, x8
    46d0:      	blr	x10
    46d4:      	cbnz	x0, 0x45c4 <perf_unwind_perl+0x45c4>
    46d8:      	ldr	x8, [sp, #0x30]
    46dc:      	mov	w9, #0x8                // =8
    46e0:      	mov	w10, #0x70              // =112
    46e4:      	add	x11, sp, #0x70
    46e8:      	add	x0, sp, #0x70
    46ec:      	mov	w1, #0x8                // =8
    46f0:      	cmp	x8, #0x0
    46f4:      	mov	w8, #0x3                // =3
    46f8:      	csinc	w29, w8, wzr, ne
    46fc:      	ldrb	w8, [x22, #0x1c]
    4700:      	add	x8, x25, x8
    4704:      	ldrb	w8, [x22, #0x1c]
    4708:      	add	x2, x25, x8
    470c:      	blr	x10
    4710:      	cbnz	x0, 0x45c4 <perf_unwind_perl+0x45c4>
    4714:      	ldr	x24, [sp, #0x70]
    4718:      	ldrb	w8, [x22, #0x1e]
    471c:      	mov	w9, #0x4                // =4
    4720:      	mov	w10, #0x70              // =112
    4724:      	add	x11, sp, #0xb8
    4728:      	add	x0, sp, #0xb8
    472c:      	mov	w1, #0x4                // =4
    4730:      	add	x8, x24, x8
    4734:      	ldrb	w8, [x22, #0x1e]
    4738:      	add	x2, x24, x8
    473c:      	blr	x10
    4740:      	cbz	x0, 0x47d0 <perf_unwind_perl+0x47d0>
    4744:      	ldr	w8, [x23]
    4748:      	cbnz	w8, 0x64fc <perf_unwind_perl+0x64fc>
    474c:      	mov	w8, #0x14               // =20
    4750:      	adrp	x0, 0x4000 <perf_unwind_perl+0x4000>
    4754:      	add	x9, sp, #0xbc
    4758:      	str	w8, [sp, #0xbc]
    475c:      	mov	w8, #0x1                // =1
    4760:      	add	x1, sp, #0xbc
    4764:      	ldr	x0, [x0]
    4768:      	blr	x8
    476c:      	cbz	x0, 0x498c <perf_unwind_perl+0x498c>
    4770:      	ldr	x8, [x0]
    4774:      	add	x8, x8, #0x1
    4778:      	str	x8, [x0]
    477c:      	b	0x45c4 <perf_unwind_perl+0x45c4>
    4780:      	ldr	w8, [x23]
    4784:      	cbz	w8, 0x4d9c <perf_unwind_perl+0x4d9c>
    4788:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    478c:      	add	x8, x8, #0x0
    4790:      	add	x0, sp, #0x30
    4794:      	ldp	x9, x10, [x8, #0x10]
    4798:      	mov	w1, #0x2e               // =46
    479c:      	stp	x9, x10, [sp, #0x40]
    47a0:      	ldr	x9, [x8, #0x20]
    47a4:      	add	x10, sp, #0x30
    47a8:      	str	x9, [sp, #0x50]
    47ac:      	ldur	x9, [x8, #0x26]
    47b0:      	stur	x9, [sp, #0x56]
    47b4:      	ldp	x9, x8, [x8]
    47b8:      	stp	x9, x8, [sp, #0x30]
    47bc:      	mov	w8, #0x2e               // =46
    47c0:      	mov	w9, #0x6                // =6
    47c4:      	ldr	w2, [sp, #0xa8]
    47c8:      	blr	x9
    47cc:      	b	0x4d9c <perf_unwind_perl+0x4d9c>
    47d0:      	ldr	w8, [sp, #0xb8]
    47d4:      	and	w8, w8, #0x1f
    47d8:      	cmp	w8, #0xd
    47dc:      	b.ne	0x49dc <perf_unwind_perl+0x49dc>
    47e0:      	ldrb	w8, [x22, #0x1f]
    47e4:      	mov	w9, #0x8                // =8
    47e8:      	mov	w10, #0x70              // =112
    47ec:      	add	x11, sp, #0xa8
    47f0:      	add	x0, sp, #0xa8
    47f4:      	mov	w1, #0x8                // =8
    47f8:      	add	x8, x24, x8
    47fc:      	ldrb	w8, [x22, #0x1f]
    4800:      	add	x2, x24, x8
    4804:      	blr	x10
    4808:      	cbnz	x0, 0x4744 <perf_unwind_perl+0x4744>
    480c:      	ldr	x8, [sp, #0xa8]
    4810:      	ldrb	w9, [x22, #0x21]
    4814:      	mov	w10, #0x70              // =112
    4818:      	add	x11, sp, #0xa4
    481c:      	add	x0, sp, #0xa4
    4820:      	mov	w1, #0x4                // =4
    4824:      	add	x8, x8, x9
    4828:      	mov	w9, #0x4                // =4
    482c:      	ldr	x8, [sp, #0xa8]
    4830:      	ldrb	w9, [x22, #0x21]
    4834:      	add	x2, x8, x9
    4838:      	blr	x10
    483c:      	cbnz	x0, 0x4744 <perf_unwind_perl+0x4744>
    4840:      	ldrb	w8, [sp, #0xa5]
    4844:      	tbnz	w8, #0x7, 0x4cc4 <perf_unwind_perl+0x4cc4>
    4848:      	ldr	x8, [sp, #0xa8]
    484c:      	ldrb	w9, [x22, #0x22]
    4850:      	mov	w10, #0x70              // =112
    4854:      	add	x11, sp, #0x98
    4858:      	add	x0, sp, #0x98
    485c:      	mov	w1, #0x8                // =8
    4860:      	add	x8, x8, x9
    4864:      	mov	w9, #0x8                // =8
    4868:      	ldr	x8, [sp, #0xa8]
    486c:      	ldrb	w9, [x22, #0x22]
    4870:      	add	x2, x8, x9
    4874:      	blr	x10
    4878:      	cbnz	x0, 0x4744 <perf_unwind_perl+0x4744>
    487c:      	ldr	x8, [sp, #0x98]
    4880:      	cbz	x8, 0x4744 <perf_unwind_perl+0x4744>
    4884:      	ldr	w9, [x23]
    4888:      	cbnz	w9, 0x6ad8 <perf_unwind_perl+0x6ad8>
    488c:      	ldrb	w9, [x22, #0x1e]
    4890:      	mov	w10, #0x70              // =112
    4894:      	add	x11, sp, #0x94
    4898:      	add	x0, sp, #0x94
    489c:      	mov	w1, #0x4                // =4
    48a0:      	add	x8, x8, x9
    48a4:      	mov	w9, #0x4                // =4
    48a8:      	ldr	x8, [sp, #0x98]
    48ac:      	ldrb	w9, [x22, #0x1e]
    48b0:      	add	x2, x8, x9
    48b4:      	blr	x10
    48b8:      	cbnz	x0, 0x4744 <perf_unwind_perl+0x4744>
    48bc:      	ldr	w8, [sp, #0x94]
    48c0:      	mov	w9, #0x801f             // =32799
    48c4:      	and	w8, w8, w9
    48c8:      	mov	w9, #0x8009             // =32777
    48cc:      	cmp	w8, w9
    48d0:      	b.ne	0x61b8 <perf_unwind_perl+0x61b8>
    48d4:      	ldr	x8, [sp, #0x98]
    48d8:      	ldrb	w9, [x22, #0x20]
    48dc:      	mov	w10, #0x70              // =112
    48e0:      	add	x11, sp, #0x88
    48e4:      	add	x0, sp, #0x88
    48e8:      	mov	w1, #0x8                // =8
    48ec:      	add	x8, x8, x9
    48f0:      	mov	w9, #0x8                // =8
    48f4:      	ldr	x8, [sp, #0x98]
    48f8:      	ldrb	w9, [x22, #0x20]
    48fc:      	add	x2, x8, x9
    4900:      	blr	x10
    4904:      	cbnz	x0, 0x4744 <perf_unwind_perl+0x4744>
    4908:      	ldr	x8, [sp, #0x88]
    490c:      	ldrb	w9, [x22, #0x23]
    4910:      	mov	w10, #0x70              // =112
    4914:      	add	x11, sp, #0x80
    4918:      	add	x0, sp, #0x80
    491c:      	mov	w1, #0x8                // =8
    4920:      	add	x8, x8, x9
    4924:      	mov	w9, #0x8                // =8
    4928:      	ldr	x8, [sp, #0x88]
    492c:      	ldrb	w9, [x22, #0x23]
    4930:      	add	x2, x8, x9
    4934:      	blr	x10
    4938:      	cbnz	x0, 0x4744 <perf_unwind_perl+0x4744>
    493c:      	ldr	x24, [sp, #0x80]
    4940:      	cbz	x24, 0x67a8 <perf_unwind_perl+0x67a8>
    4944:      	ldr	w8, [x23]
    4948:      	cbz	w8, 0x67b4 <perf_unwind_perl+0x67b4>
    494c:      	mov	w8, #0x786c             // =30828
    4950:      	add	x10, sp, #0x30
    4954:      	add	x0, sp, #0x30
    4958:      	mov	w1, #0x14               // =20
    495c:      	movk	w8, #0xa, lsl #16
    4960:      	str	w8, [sp, #0x40]
    4964:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4968:      	add	x8, x8, #0x0
    496c:      	ldp	x9, x8, [x8]
    4970:      	stp	x9, x8, [sp, #0x30]
    4974:      	mov	w8, #0x14               // =20
    4978:      	mov	w9, #0x6                // =6
    497c:      	ldr	x2, [sp, #0x80]
    4980:      	blr	x9
    4984:      	add	x8, sp, #0x80
    4988:      	b	0x67ac <perf_unwind_perl+0x67ac>
    498c:      	ldr	w8, [x23]
    4990:      	cbz	w8, 0x45c4 <perf_unwind_perl+0x45c4>
    4994:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4998:      	add	x8, x8, #0x0
    499c:      	add	x0, sp, #0x30
    49a0:      	ldp	x9, x10, [x8, #0x10]
    49a4:      	mov	w1, #0x2e               // =46
    49a8:      	stp	x9, x10, [sp, #0x40]
    49ac:      	ldr	x9, [x8, #0x20]
    49b0:      	add	x10, sp, #0x30
    49b4:      	str	x9, [sp, #0x50]
    49b8:      	ldur	x9, [x8, #0x26]
    49bc:      	stur	x9, [sp, #0x56]
    49c0:      	ldp	x9, x8, [x8]
    49c4:      	stp	x9, x8, [sp, #0x30]
    49c8:      	mov	w8, #0x2e               // =46
    49cc:      	mov	w9, #0x6                // =6
    49d0:      	ldr	w2, [sp, #0xbc]
    49d4:      	blr	x9
    49d8:      	b	0x45c4 <perf_unwind_perl+0x45c4>
    49dc:      	ldr	w8, [x23]
    49e0:      	cbz	w8, 0x45c4 <perf_unwind_perl+0x45c4>
    49e4:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    49e8:      	add	x8, x8, #0x0
    49ec:      	add	x0, sp, #0x30
    49f0:      	ldp	x9, x10, [x8]
    49f4:      	mov	w1, #0x1e               // =30
    49f8:      	stp	x9, x10, [sp, #0x30]
    49fc:      	ldr	x9, [x8, #0x10]
    4a00:      	ldur	x8, [x8, #0x16]
    4a04:      	add	x10, sp, #0x30
    4a08:      	str	x9, [sp, #0x40]
    4a0c:      	stur	x8, [sp, #0x46]
    4a10:      	mov	w8, #0x1e               // =30
    4a14:      	mov	w9, #0x6                // =6
    4a18:      	ldr	w2, [sp, #0xb8]
    4a1c:      	blr	x9
    4a20:      	b	0x45c4 <perf_unwind_perl+0x45c4>
    4a24:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4a28:      	add	x8, x8, #0x0
    4a2c:      	add	x0, sp, #0x30
    4a30:      	ldp	x9, x10, [x8, #0x10]
    4a34:      	mov	w1, #0x2e               // =46
    4a38:      	stp	x9, x10, [sp, #0x40]
    4a3c:      	ldr	x9, [x8, #0x20]
    4a40:      	add	x10, sp, #0x30
    4a44:      	str	x9, [sp, #0x50]
    4a48:      	ldur	x9, [x8, #0x26]
    4a4c:      	stur	x9, [sp, #0x56]
    4a50:      	ldp	x9, x8, [x8]
    4a54:      	stp	x9, x8, [sp, #0x30]
    4a58:      	mov	w8, #0x2e               // =46
    4a5c:      	mov	w9, #0x6                // =6
    4a60:      	ldr	w2, [sp, #0xa8]
    4a64:      	blr	x9
    4a68:      	ldp	x24, x9, [sp, #0x10]
    4a6c:      	cmp	w29, #0x3
    4a70:      	b.eq	0x458c <perf_unwind_perl+0x458c>
    4a74:      	b	0x563c <perf_unwind_perl+0x563c>
    4a78:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4a7c:      	add	x8, x8, #0x0
    4a80:      	add	x0, sp, #0x30
    4a84:      	ldp	x9, x10, [x8, #0x10]
    4a88:      	mov	w1, #0x2d               // =45
    4a8c:      	stp	x9, x10, [sp, #0x40]
    4a90:      	ldr	x9, [x8, #0x20]
    4a94:      	add	x10, sp, #0x30
    4a98:      	str	x9, [sp, #0x50]
    4a9c:      	ldur	x9, [x8, #0x25]
    4aa0:      	stur	x9, [sp, #0x55]
    4aa4:      	ldp	x9, x8, [x8]
    4aa8:      	stp	x9, x8, [sp, #0x30]
    4aac:      	mov	w8, #0x2d               // =45
    4ab0:      	mov	w9, #0x6                // =6
    4ab4:      	blr	x9
    4ab8:      	b	0x3090 <perf_unwind_perl+0x3090>
    4abc:      	mov	w8, #0xa                // =10
    4ac0:      	add	x0, sp, #0x30
    4ac4:      	mov	w1, #0x2a               // =42
    4ac8:      	strh	w8, [sp, #0x58]
    4acc:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4ad0:      	add	x8, x8, #0x0
    4ad4:      	mov	x2, x25
    4ad8:      	ldp	x9, x10, [x8, #0x10]
    4adc:      	stp	x9, x10, [sp, #0x40]
    4ae0:      	ldr	x9, [x8, #0x20]
    4ae4:      	add	x10, sp, #0x30
    4ae8:      	str	x9, [sp, #0x50]
    4aec:      	ldp	x8, x9, [x8]
    4af0:      	stp	x8, x9, [sp, #0x30]
    4af4:      	mov	w8, #0x2a               // =42
    4af8:      	mov	w9, #0x6                // =6
    4afc:      	blr	x9
    4b00:      	b	0x45cc <perf_unwind_perl+0x45cc>
    4b04:      	ldr	w8, [x23]
    4b08:      	cbz	w8, 0x36b4 <perf_unwind_perl+0x36b4>
    4b0c:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4b10:      	add	x8, x8, #0x0
    4b14:      	add	x0, sp, #0x30
    4b18:      	ldp	x9, x10, [x8, #0x10]
    4b1c:      	mov	w1, #0x26               // =38
    4b20:      	stp	x9, x10, [sp, #0x40]
    4b24:      	ldur	x9, [x8, #0x1e]
    4b28:      	add	x10, sp, #0x30
    4b2c:      	stur	x9, [sp, #0x4e]
    4b30:      	ldp	x8, x9, [x8]
    4b34:      	stp	x8, x9, [sp, #0x30]
    4b38:      	mov	w8, #0x26               // =38
    4b3c:      	mov	w9, #0x6                // =6
    4b40:      	ldr	w2, [sp, #0x94]
    4b44:      	blr	x9
    4b48:      	b	0x36b4 <perf_unwind_perl+0x36b4>
    4b4c:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4b50:      	add	x8, x8, #0x0
    4b54:      	add	x0, sp, #0x30
    4b58:      	ldp	x9, x10, [x8, #0x10]
    4b5c:      	mov	w1, #0x28               // =40
    4b60:      	mov	x3, x24
    4b64:      	stp	x9, x10, [sp, #0x40]
    4b68:      	ldr	x9, [x8, #0x20]
    4b6c:      	add	x10, sp, #0x30
    4b70:      	str	x9, [sp, #0x50]
    4b74:      	ldp	x8, x9, [x8]
    4b78:      	stp	x8, x9, [sp, #0x30]
    4b7c:      	mov	w8, #0x28               // =40
    4b80:      	mov	w9, #0x6                // =6
    4b84:      	ldr	x2, [sp, #0x8]
    4b88:      	blr	x9
    4b8c:      	ldr	w8, [x21, #0x2c0]
    4b90:      	cmp	w8, #0x7f
    4b94:      	b.hs	0x2680 <perf_unwind_perl+0x2680>
    4b98:      	add	w9, w8, #0x1
    4b9c:      	mov	w10, #0x7               // =7
    4ba0:      	str	w9, [x21, #0x2c0]
    4ba4:      	mov	w9, #0x18               // =24
    4ba8:      	umaddl	x8, w8, w9, x21
    4bac:      	str	x24, [x8, #0x2d8]
    4bb0:      	ldp	x9, x24, [sp, #0x8]
    4bb4:      	strb	w10, [x8, #0x2e0]
    4bb8:      	str	wzr, [x8, #0x2e4]
    4bbc:      	str	x9, [x8, #0x2d0]
    4bc0:      	add	x9, x8, #0x2d0
    4bc4:      	str	xzr, [x21, #0xf30]
    4bc8:      	stur	wzr, [x9, #0x11]
    4bcc:      	b	0xd24 <perf_unwind_perl+0xd24>
    4bd0:      	add	x8, sp, #0x98
    4bd4:      	ldr	x8, [x8]
    4bd8:      	ldr	x24, [sp, #0x10]
    4bdc:      	str	x8, [sp, #0x8]
    4be0:      	cbz	x8, 0x27f8 <perf_unwind_perl+0x27f8>
    4be4:      	ldr	x24, [x24]
    4be8:      	ldr	w8, [x23]
    4bec:      	cbnz	w8, 0x68e0 <perf_unwind_perl+0x68e0>
    4bf0:      	ldr	w8, [x21, #0x2c0]
    4bf4:      	cmp	w8, #0x7e
    4bf8:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    4bfc:      	add	w9, w8, #0x1
    4c00:      	mov	w10, #0x7               // =7
    4c04:      	str	w9, [x21, #0x2c0]
    4c08:      	mov	w9, #0x18               // =24
    4c0c:      	umaddl	x8, w8, w9, x21
    4c10:      	ldr	x9, [sp, #0x8]
    4c14:      	str	x24, [x8, #0x2d8]
    4c18:      	strb	w10, [x8, #0x2e0]
    4c1c:      	str	wzr, [x8, #0x2e4]
    4c20:      	str	x9, [x8, #0x2d0]
    4c24:      	add	x9, x8, #0x2d0
    4c28:      	str	xzr, [x21, #0xf30]
    4c2c:      	stur	wzr, [x9, #0x11]
    4c30:      	b	0x2f54 <perf_unwind_perl+0x2f54>
    4c34:      	mov	w8, #0x786c             // =30828
    4c38:      	add	x10, sp, #0x30
    4c3c:      	add	x0, sp, #0x30
    4c40:      	mov	w1, #0x14               // =20
    4c44:      	movk	w8, #0xa, lsl #16
    4c48:      	str	w8, [sp, #0x40]
    4c4c:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4c50:      	add	x8, x8, #0x0
    4c54:      	ldp	x9, x8, [x8]
    4c58:      	stp	x9, x8, [sp, #0x30]
    4c5c:      	mov	w8, #0x14               // =20
    4c60:      	mov	w9, #0x6                // =6
    4c64:      	ldr	x2, [sp, #0x80]
    4c68:      	blr	x9
    4c6c:      	add	x8, sp, #0x80
    4c70:      	ldr	x8, [x8]
    4c74:      	ldr	x24, [sp, #0x10]
    4c78:      	str	x8, [sp, #0x8]
    4c7c:      	cbnz	x8, 0x2668 <perf_unwind_perl+0x2668>
    4c80:      	b	0xf0 <perf_unwind_perl+0xf0>
    4c84:      	mov	w8, #0x786c             // =30828
    4c88:      	add	x10, sp, #0x30
    4c8c:      	add	x0, sp, #0x30
    4c90:      	mov	w1, #0x13               // =19
    4c94:      	movk	w8, #0xa, lsl #16
    4c98:      	stur	w8, [sp, #0x3f]
    4c9c:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4ca0:      	add	x8, x8, #0x0
    4ca4:      	ldp	x9, x8, [x8]
    4ca8:      	stp	x9, x8, [sp, #0x30]
    4cac:      	mov	w8, #0x13               // =19
    4cb0:      	mov	w9, #0x6                // =6
    4cb4:      	ldr	x2, [sp, #0x98]
    4cb8:      	blr	x9
    4cbc:      	ldr	x8, [sp, #0x98]
    4cc0:      	b	0x1d3c <perf_unwind_perl+0x1d3c>
    4cc4:      	ldr	w8, [x23]
    4cc8:      	cbz	w8, 0x45c4 <perf_unwind_perl+0x45c4>
    4ccc:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4cd0:      	add	x8, x8, #0x0
    4cd4:      	add	x0, sp, #0x30
    4cd8:      	ldp	x9, x10, [x8, #0x10]
    4cdc:      	mov	w1, #0x26               // =38
    4ce0:      	stp	x9, x10, [sp, #0x40]
    4ce4:      	ldur	x9, [x8, #0x1e]
    4ce8:      	add	x10, sp, #0x30
    4cec:      	stur	x9, [sp, #0x4e]
    4cf0:      	ldp	x8, x9, [x8]
    4cf4:      	stp	x8, x9, [sp, #0x30]
    4cf8:      	mov	w8, #0x26               // =38
    4cfc:      	mov	w9, #0x6                // =6
    4d00:      	ldr	w2, [sp, #0xb8]
    4d04:      	ldr	w3, [sp, #0xa4]
    4d08:      	blr	x9
    4d0c:      	b	0x45c4 <perf_unwind_perl+0x45c4>
    4d10:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4d14:      	add	x8, x8, #0x0
    4d18:      	add	x0, sp, #0x30
    4d1c:      	ldp	x9, x10, [x8, #0x10]
    4d20:      	mov	w1, #0x25               // =37
    4d24:      	stp	x9, x10, [sp, #0x40]
    4d28:      	ldur	x9, [x8, #0x1d]
    4d2c:      	add	x10, sp, #0x30
    4d30:      	stur	x9, [sp, #0x4d]
    4d34:      	ldp	x8, x9, [x8]
    4d38:      	stp	x8, x9, [sp, #0x30]
    4d3c:      	mov	w8, #0x25               // =37
    4d40:      	mov	w9, #0x6                // =6
    4d44:      	blr	x9
    4d48:      	b	0x2688 <perf_unwind_perl+0x2688>
    4d4c:      	mov	w8, #0xa                // =10
    4d50:      	add	x10, sp, #0x30
    4d54:      	add	x0, sp, #0x30
    4d58:      	strh	w8, [sp, #0x40]
    4d5c:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4d60:      	add	x8, x8, #0x0
    4d64:      	mov	w1, #0x12               // =18
    4d68:      	ldp	x9, x8, [x8]
    4d6c:      	stp	x9, x8, [sp, #0x30]
    4d70:      	mov	w8, #0x12               // =18
    4d74:      	mov	w9, #0x6                // =6
    4d78:      	ldrb	w2, [sp, #0x7c]
    4d7c:      	blr	x9
    4d80:      	ldrb	w8, [sp, #0x7c]
    4d84:      	and	w9, w8, #0xf
    4d88:      	sub	w10, w9, #0x9
    4d8c:      	cmp	w10, #0x2
    4d90:      	b.lo	0x46a4 <perf_unwind_perl+0x46a4>
    4d94:      	cmp	w9, #0xc
    4d98:      	b.ne	0x4e7c <perf_unwind_perl+0x4e7c>
    4d9c:      	mov	w29, #0x3               // =3
    4da0:      	ldrb	w8, [x22, #0x1d]
    4da4:      	ldr	x9, [x21, #0xf40]
    4da8:      	adrp	x0, 0x4000 <perf_unwind_perl+0x4000>
    4dac:      	add	x1, sp, #0xa8
    4db0:      	sub	x8, x9, x8
    4db4:      	add	x9, sp, #0xa8
    4db8:      	str	x8, [x21, #0xf40]
    4dbc:      	mov	w8, #0x10               // =16
    4dc0:      	str	w8, [sp, #0xa8]
    4dc4:      	mov	w8, #0x1                // =1
    4dc8:      	ldr	x0, [x0]
    4dcc:      	blr	x8
    4dd0:      	cbz	x0, 0x4df0 <perf_unwind_perl+0x4df0>
    4dd4:      	ldr	x8, [x0]
    4dd8:      	add	x8, x8, #0x1
    4ddc:      	str	x8, [x0]
    4de0:      	ldp	x24, x9, [sp, #0x10]
    4de4:      	cmp	w29, #0x3
    4de8:      	b.eq	0x4e04 <perf_unwind_perl+0x4e04>
    4dec:      	b	0x563c <perf_unwind_perl+0x563c>
    4df0:      	ldr	w8, [x23]
    4df4:      	cbnz	w8, 0x529c <perf_unwind_perl+0x529c>
    4df8:      	ldp	x24, x9, [sp, #0x10]
    4dfc:      	cmp	w29, #0x3
    4e00:      	b.ne	0x563c <perf_unwind_perl+0x563c>
    4e04:      	ldr	x25, [x21, #0xf40]
    4e08:      	cmp	x25, x9
    4e0c:      	b.lo	0x2ecc <perf_unwind_perl+0x2ecc>
    4e10:      	ldrb	w8, [x22, #0x19]
    4e14:      	mov	w9, #0x1                // =1
    4e18:      	mov	w10, #0x70              // =112
    4e1c:      	add	x11, sp, #0x7c
    4e20:      	add	x0, sp, #0x7c
    4e24:      	mov	w1, #0x1                // =1
    4e28:      	add	x8, x25, x8
    4e2c:      	ldrb	w8, [x22, #0x19]
    4e30:      	add	x2, x25, x8
    4e34:      	blr	x10
    4e38:      	cbz	x0, 0x4f00 <perf_unwind_perl+0x4f00>
    4e3c:      	ldr	w8, [x23]
    4e40:      	cbnz	w8, 0x5334 <perf_unwind_perl+0x5334>
    4e44:      	mov	w8, #0x13               // =19
    4e48:      	adrp	x0, 0x4000 <perf_unwind_perl+0x4000>
    4e4c:      	add	x9, sp, #0xa8
    4e50:      	str	w8, [sp, #0xa8]
    4e54:      	mov	w8, #0x1                // =1
    4e58:      	add	x1, sp, #0xa8
    4e5c:      	ldr	x0, [x0]
    4e60:      	blr	x8
    4e64:      	cbz	x0, 0x4ff8 <perf_unwind_perl+0x4ff8>
    4e68:      	ldr	x8, [x0]
    4e6c:      	mov	w29, #0x3               // =3
    4e70:      	add	x8, x8, #0x1
    4e74:      	str	x8, [x0]
    4e78:      	b	0x55f0 <perf_unwind_perl+0x55f0>
    4e7c:      	ldr	x8, [sp, #0x10]
    4e80:      	mov	w29, #0x3               // =3
    4e84:      	ldr	x8, [x8]
    4e88:      	cbnz	x8, 0x4da0 <perf_unwind_perl+0x4da0>
    4e8c:      	ldrb	w8, [x22, #0x1a]
    4e90:      	mov	w9, #0x8                // =8
    4e94:      	mov	w10, #0x70              // =112
    4e98:      	ldr	x0, [sp, #0x10]
    4e9c:      	mov	w1, #0x8                // =8
    4ea0:      	add	x8, x25, x8
    4ea4:      	ldrb	w8, [x22, #0x1a]
    4ea8:      	add	x2, x25, x8
    4eac:      	blr	x10
    4eb0:      	cbnz	x0, 0x45c4 <perf_unwind_perl+0x45c4>
    4eb4:      	ldr	w8, [x23]
    4eb8:      	cbz	w8, 0x4da0 <perf_unwind_perl+0x4da0>
    4ebc:      	adrp	x8, 0x4000 <perf_unwind_perl+0x4000>
    4ec0:      	add	x8, x8, #0x0
    4ec4:      	add	x0, sp, #0x30
    4ec8:      	ldp	x9, x10, [x8]
    4ecc:      	mov	w1, #0x1e               // =30
    4ed0:      	stp	x9, x10, [sp, #0x30]
    4ed4:      	ldr	x9, [x8, #0x10]
    4ed8:      	ldur	x8, [x8, #0x16]
    4edc:      	add	x10, sp, #0x30
    4ee0:      	str	x9, [sp, #0x40]
    4ee4:      	stur	x8, [sp, #0x46]
    4ee8:      	mov	w8, #0x1e               // =30
    4eec:      	mov	w9, #0x6                // =6
    4ef0:      	ldr	x8, [sp, #0x10]
    4ef4:      	ldr	x2, [x8]
    4ef8:      	blr	x9
    4efc:      	b	0x4da0 <perf_unwind_perl+0x4da0>
    4f00:      	ldr	w8, [x23]
    4f04:      	cbnz	w8, 0x559c <perf_unwind_perl+0x559c>
    4f08:      	ldrb	w8, [sp, #0x7c]
    4f0c:      	and	w9, w8, #0xf
    4f10:      	sub	w10, w9, #0x9
    4f14:      	cmp	w10, #0x2
    4f18:      	b.hs	0x55e4 <perf_unwind_perl+0x55e4>
    4f1c:      	sxtb	w8, w8
    4f20:      	tbnz	w8, #0x1f, 0x55ec <perf_unwind_perl+0x55ec>
    4f24:      	ldrb	w8, [x22, #0x1b]
    4f28:      	mov	w9, #0x8                // =8
    4f2c:      	mov	w10, #0x70              // =112
    4f30:      	add	x11, sp, #0x30
    4f34:      	add	x0, sp, #0x30
    4f38:      	mov	w1, #0x8                // =8
    4f3c:      	add	x8, x25, x8
    4f40:      	ldrb	w8, [x22, #0x1b]
    4f44:      	add	x2, x25, x8
    4f48:      	blr	x10
    4f4c:      	cbnz	x0, 0x4e3c <perf_unwind_perl+0x4e3c>
    4f50:      	ldr	x8, [sp, #0x30]
    4f54:      	mov	w9, #0x8                // =8
    4f58:      	mov	w10, #0x70              // =112
    4f5c:      	add	x11, sp, #0x70
    4f60:      	add	x0, sp, #0x70
    4f64:      	mov	w1, #0x8                // =8
    4f68:      	cmp	x8, #0x0
    4f6c:      	mov	w8, #0x3                // =3
    4f70:      	csinc	w29, w8, wzr, ne
    4f74:      	ldrb	w8, [x22, #0x1c]
    4f78:      	add	x8, x25, x8
    4f7c:      	ldrb	w8, [x22, #0x1c]
    4f80:      	add	x2, x25, x8
    4f84:      	blr	x10
    4f88:      	cbnz	x0, 0x4e3c <perf_unwind_perl+0x4e3c>
    4f8c:      	ldr	x24, [sp, #0x70]
    4f90:      	ldrb	w8, [x22, #0x1e]
    4f94:      	mov	w9, #0x4                // =4
    4f98:      	mov	w10, #0x70              // =112
    4f9c:      	add	x11, sp, #0xb8
    4fa0:      	add	x0, sp, #0xb8
    4fa4:      	mov	w1, #0x4                // =4
    4fa8:      	add	x8, x24, x8
    4fac:      	ldrb	w8, [x22, #0x1e]
    4fb0:      	add	x2, x24, x8
    4fb4:      	blr	x10
    4fb8:      	cbz	x0, 0x5048 <perf_unwind_perl+0x5048>
    4fbc:      	ldr	w8, [x23]
    4fc0:      	cbnz	w8, 0x66cc <perf_unwind_perl+0x66cc>
    4fc4:      	mov	w8, #0x14               // =20
    4fc8:      	adrp	x0, 0x4000 <perf_unwind_perl+0x4000>
    4fcc:      	add	x9, sp, #0xbc
    4fd0:      	str	w8, [sp, #0xbc]
    4fd4:      	mov	w8, #0x1                // =1
    4fd8:      	add	x1, sp, #0xbc
    4fdc:      	ldr	x0, [x0]
    4fe0:      	blr	x8
    4fe4:      	cbz	x0, 0x5204 <perf_unwind_perl+0x5204>
    4fe8:      	ldr	x8, [x0]
    4fec:      	add	x8, x8, #0x1
    4ff0:      	str	x8, [x0]
    4ff4:      	b	0x4e3c <perf_unwind_perl+0x4e3c>
    4ff8:      	ldr	w8, [x23]
    4ffc:      	cbz	w8, 0x55ec <perf_unwind_perl+0x55ec>
    5000:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    5004:      	add	x8, x8, #0x0
    5008:      	add	x0, sp, #0x30
    500c:      	ldp	x9, x10, [x8, #0x10]
    5010:      	mov	w1, #0x2e               // =46
    5014:      	stp	x9, x10, [sp, #0x40]
    5018:      	ldr	x9, [x8, #0x20]
    501c:      	add	x10, sp, #0x30
    5020:      	str	x9, [sp, #0x50]
    5024:      	ldur	x9, [x8, #0x26]
    5028:      	stur	x9, [sp, #0x56]
    502c:      	ldp	x9, x8, [x8]
    5030:      	stp	x9, x8, [sp, #0x30]
    5034:      	mov	w8, #0x2e               // =46
    5038:      	mov	w9, #0x6                // =6
    503c:      	ldr	w2, [sp, #0xa8]
    5040:      	blr	x9
    5044:      	b	0x55ec <perf_unwind_perl+0x55ec>
    5048:      	ldr	w8, [sp, #0xb8]
    504c:      	and	w8, w8, #0x1f
    5050:      	cmp	w8, #0xd
    5054:      	b.ne	0x5254 <perf_unwind_perl+0x5254>
    5058:      	ldrb	w8, [x22, #0x1f]
    505c:      	mov	w9, #0x8                // =8
    5060:      	mov	w10, #0x70              // =112
    5064:      	add	x11, sp, #0xa8
    5068:      	add	x0, sp, #0xa8
    506c:      	mov	w1, #0x8                // =8
    5070:      	add	x8, x24, x8
    5074:      	ldrb	w8, [x22, #0x1f]
    5078:      	add	x2, x24, x8
    507c:      	blr	x10
    5080:      	cbnz	x0, 0x4fbc <perf_unwind_perl+0x4fbc>
    5084:      	ldr	x8, [sp, #0xa8]
    5088:      	ldrb	w9, [x22, #0x21]
    508c:      	mov	w10, #0x70              // =112
    5090:      	add	x11, sp, #0xa4
    5094:      	add	x0, sp, #0xa4
    5098:      	mov	w1, #0x4                // =4
    509c:      	add	x8, x8, x9
    50a0:      	mov	w9, #0x4                // =4
    50a4:      	ldr	x8, [sp, #0xa8]
    50a8:      	ldrb	w9, [x22, #0x21]
    50ac:      	add	x2, x8, x9
    50b0:      	blr	x10
    50b4:      	cbnz	x0, 0x4fbc <perf_unwind_perl+0x4fbc>
    50b8:      	ldrb	w8, [sp, #0xa5]
    50bc:      	tbnz	w8, #0x7, 0x5550 <perf_unwind_perl+0x5550>
    50c0:      	ldr	x8, [sp, #0xa8]
    50c4:      	ldrb	w9, [x22, #0x22]
    50c8:      	mov	w10, #0x70              // =112
    50cc:      	add	x11, sp, #0x98
    50d0:      	add	x0, sp, #0x98
    50d4:      	mov	w1, #0x8                // =8
    50d8:      	add	x8, x8, x9
    50dc:      	mov	w9, #0x8                // =8
    50e0:      	ldr	x8, [sp, #0xa8]
    50e4:      	ldrb	w9, [x22, #0x22]
    50e8:      	add	x2, x8, x9
    50ec:      	blr	x10
    50f0:      	cbnz	x0, 0x4fbc <perf_unwind_perl+0x4fbc>
    50f4:      	ldr	x8, [sp, #0x98]
    50f8:      	cbz	x8, 0x4fbc <perf_unwind_perl+0x4fbc>
    50fc:      	ldr	w9, [x23]
    5100:      	cbnz	w9, 0x6b68 <perf_unwind_perl+0x6b68>
    5104:      	ldrb	w9, [x22, #0x1e]
    5108:      	mov	w10, #0x70              // =112
    510c:      	add	x11, sp, #0x94
    5110:      	add	x0, sp, #0x94
    5114:      	mov	w1, #0x4                // =4
    5118:      	add	x8, x8, x9
    511c:      	mov	w9, #0x4                // =4
    5120:      	ldr	x8, [sp, #0x98]
    5124:      	ldrb	w9, [x22, #0x1e]
    5128:      	add	x2, x8, x9
    512c:      	blr	x10
    5130:      	cbnz	x0, 0x4fbc <perf_unwind_perl+0x4fbc>
    5134:      	ldr	w8, [sp, #0x94]
    5138:      	mov	w9, #0x801f             // =32799
    513c:      	and	w8, w8, w9
    5140:      	mov	w9, #0x8009             // =32777
    5144:      	cmp	w8, w9
    5148:      	b.ne	0x6540 <perf_unwind_perl+0x6540>
    514c:      	ldr	x8, [sp, #0x98]
    5150:      	ldrb	w9, [x22, #0x20]
    5154:      	mov	w10, #0x70              // =112
    5158:      	add	x11, sp, #0x88
    515c:      	add	x0, sp, #0x88
    5160:      	mov	w1, #0x8                // =8
    5164:      	add	x8, x8, x9
    5168:      	mov	w9, #0x8                // =8
    516c:      	ldr	x8, [sp, #0x98]
    5170:      	ldrb	w9, [x22, #0x20]
    5174:      	add	x2, x8, x9
    5178:      	blr	x10
    517c:      	cbnz	x0, 0x4fbc <perf_unwind_perl+0x4fbc>
    5180:      	ldr	x8, [sp, #0x88]
    5184:      	ldrb	w9, [x22, #0x23]
    5188:      	mov	w10, #0x70              // =112
    518c:      	add	x11, sp, #0x80
    5190:      	add	x0, sp, #0x80
    5194:      	mov	w1, #0x8                // =8
    5198:      	add	x8, x8, x9
    519c:      	mov	w9, #0x8                // =8
    51a0:      	ldr	x8, [sp, #0x88]
    51a4:      	ldrb	w9, [x22, #0x23]
    51a8:      	add	x2, x8, x9
    51ac:      	blr	x10
    51b0:      	cbnz	x0, 0x4fbc <perf_unwind_perl+0x4fbc>
    51b4:      	ldr	x24, [sp, #0x80]
    51b8:      	cbz	x24, 0x6930 <perf_unwind_perl+0x6930>
    51bc:      	ldr	w8, [x23]
    51c0:      	cbz	w8, 0x693c <perf_unwind_perl+0x693c>
    51c4:      	mov	w8, #0x786c             // =30828
    51c8:      	add	x10, sp, #0x30
    51cc:      	add	x0, sp, #0x30
    51d0:      	mov	w1, #0x14               // =20
    51d4:      	movk	w8, #0xa, lsl #16
    51d8:      	str	w8, [sp, #0x40]
    51dc:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    51e0:      	add	x8, x8, #0x0
    51e4:      	ldp	x9, x8, [x8]
    51e8:      	stp	x9, x8, [sp, #0x30]
    51ec:      	mov	w8, #0x14               // =20
    51f0:      	mov	w9, #0x6                // =6
    51f4:      	ldr	x2, [sp, #0x80]
    51f8:      	blr	x9
    51fc:      	add	x8, sp, #0x80
    5200:      	b	0x6934 <perf_unwind_perl+0x6934>
    5204:      	ldr	w8, [x23]
    5208:      	cbz	w8, 0x4e3c <perf_unwind_perl+0x4e3c>
    520c:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    5210:      	add	x8, x8, #0x0
    5214:      	add	x0, sp, #0x30
    5218:      	ldp	x9, x10, [x8, #0x10]
    521c:      	mov	w1, #0x2e               // =46
    5220:      	stp	x9, x10, [sp, #0x40]
    5224:      	ldr	x9, [x8, #0x20]
    5228:      	add	x10, sp, #0x30
    522c:      	str	x9, [sp, #0x50]
    5230:      	ldur	x9, [x8, #0x26]
    5234:      	stur	x9, [sp, #0x56]
    5238:      	ldp	x9, x8, [x8]
    523c:      	stp	x9, x8, [sp, #0x30]
    5240:      	mov	w8, #0x2e               // =46
    5244:      	mov	w9, #0x6                // =6
    5248:      	ldr	w2, [sp, #0xbc]
    524c:      	blr	x9
    5250:      	b	0x4e3c <perf_unwind_perl+0x4e3c>
    5254:      	ldr	w8, [x23]
    5258:      	cbz	w8, 0x4e3c <perf_unwind_perl+0x4e3c>
    525c:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    5260:      	add	x8, x8, #0x0
    5264:      	add	x0, sp, #0x30
    5268:      	ldp	x9, x10, [x8]
    526c:      	mov	w1, #0x1e               // =30
    5270:      	stp	x9, x10, [sp, #0x30]
    5274:      	ldr	x9, [x8, #0x10]
    5278:      	ldur	x8, [x8, #0x16]
    527c:      	add	x10, sp, #0x30
    5280:      	str	x9, [sp, #0x40]
    5284:      	stur	x8, [sp, #0x46]
    5288:      	mov	w8, #0x1e               // =30
    528c:      	mov	w9, #0x6                // =6
    5290:      	ldr	w2, [sp, #0xb8]
    5294:      	blr	x9
    5298:      	b	0x4e3c <perf_unwind_perl+0x4e3c>
    529c:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    52a0:      	add	x8, x8, #0x0
    52a4:      	add	x0, sp, #0x30
    52a8:      	ldp	x9, x10, [x8, #0x10]
    52ac:      	mov	w1, #0x2e               // =46
    52b0:      	stp	x9, x10, [sp, #0x40]
    52b4:      	ldr	x9, [x8, #0x20]
    52b8:      	add	x10, sp, #0x30
    52bc:      	str	x9, [sp, #0x50]
    52c0:      	ldur	x9, [x8, #0x26]
    52c4:      	stur	x9, [sp, #0x56]
    52c8:      	ldp	x9, x8, [x8]
    52cc:      	stp	x9, x8, [sp, #0x30]
    52d0:      	mov	w8, #0x2e               // =46
    52d4:      	mov	w9, #0x6                // =6
    52d8:      	ldr	w2, [sp, #0xa8]
    52dc:      	blr	x9
    52e0:      	ldp	x24, x9, [sp, #0x10]
    52e4:      	cmp	w29, #0x3
    52e8:      	b.eq	0x4e04 <perf_unwind_perl+0x4e04>
    52ec:      	b	0x563c <perf_unwind_perl+0x563c>
    52f0:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    52f4:      	add	x8, x8, #0x0
    52f8:      	add	x0, sp, #0x30
    52fc:      	ldp	x9, x10, [x8, #0x10]
    5300:      	mov	w1, #0x2d               // =45
    5304:      	stp	x9, x10, [sp, #0x40]
    5308:      	ldr	x9, [x8, #0x20]
    530c:      	add	x10, sp, #0x30
    5310:      	str	x9, [sp, #0x50]
    5314:      	ldur	x9, [x8, #0x25]
    5318:      	stur	x9, [sp, #0x55]
    531c:      	ldp	x9, x8, [x8]
    5320:      	stp	x9, x8, [sp, #0x30]
    5324:      	mov	w8, #0x2d               // =45
    5328:      	mov	w9, #0x6                // =6
    532c:      	blr	x9
    5330:      	b	0x383c <perf_unwind_perl+0x383c>
    5334:      	mov	w8, #0xa                // =10
    5338:      	add	x0, sp, #0x30
    533c:      	mov	w1, #0x2a               // =42
    5340:      	strh	w8, [sp, #0x58]
    5344:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    5348:      	add	x8, x8, #0x0
    534c:      	mov	x2, x25
    5350:      	ldp	x9, x10, [x8, #0x10]
    5354:      	stp	x9, x10, [sp, #0x40]
    5358:      	ldr	x9, [x8, #0x20]
    535c:      	add	x10, sp, #0x30
    5360:      	str	x9, [sp, #0x50]
    5364:      	ldp	x8, x9, [x8]
    5368:      	stp	x8, x9, [sp, #0x30]
    536c:      	mov	w8, #0x2a               // =42
    5370:      	mov	w9, #0x6                // =6
    5374:      	blr	x9
    5378:      	b	0x4e44 <perf_unwind_perl+0x4e44>
    537c:      	ldr	w8, [x23]
    5380:      	cbz	w8, 0x3e5c <perf_unwind_perl+0x3e5c>
    5384:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    5388:      	add	x8, x8, #0x0
    538c:      	add	x0, sp, #0x30
    5390:      	ldp	x9, x10, [x8, #0x10]
    5394:      	mov	w1, #0x26               // =38
    5398:      	stp	x9, x10, [sp, #0x40]
    539c:      	ldur	x9, [x8, #0x1e]
    53a0:      	add	x10, sp, #0x30
    53a4:      	stur	x9, [sp, #0x4e]
    53a8:      	ldp	x8, x9, [x8]
    53ac:      	stp	x8, x9, [sp, #0x30]
    53b0:      	mov	w8, #0x26               // =38
    53b4:      	mov	w9, #0x6                // =6
    53b8:      	ldr	w2, [sp, #0x94]
    53bc:      	blr	x9
    53c0:      	b	0x3e5c <perf_unwind_perl+0x3e5c>
    53c4:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    53c8:      	add	x8, x8, #0x0
    53cc:      	add	x0, sp, #0x30
    53d0:      	ldp	x9, x10, [x8, #0x10]
    53d4:      	mov	w1, #0x2e               // =46
    53d8:      	stp	x9, x10, [sp, #0x40]
    53dc:      	ldr	x9, [x8, #0x20]
    53e0:      	add	x10, sp, #0x30
    53e4:      	str	x9, [sp, #0x50]
    53e8:      	ldur	x9, [x8, #0x26]
    53ec:      	stur	x9, [sp, #0x56]
    53f0:      	ldp	x9, x8, [x8]
    53f4:      	stp	x9, x8, [sp, #0x30]
    53f8:      	mov	w8, #0x2e               // =46
    53fc:      	mov	w9, #0x6                // =6
    5400:      	ldr	w2, [sp, #0xa8]
    5404:      	blr	x9
    5408:      	b	0x2c6c <perf_unwind_perl+0x2c6c>
    540c:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    5410:      	add	x8, x8, #0x0
    5414:      	add	x0, sp, #0x30
    5418:      	ldp	x9, x10, [x8, #0x10]
    541c:      	mov	w1, #0x28               // =40
    5420:      	mov	x3, x24
    5424:      	stp	x9, x10, [sp, #0x40]
    5428:      	ldr	x9, [x8, #0x20]
    542c:      	add	x10, sp, #0x30
    5430:      	str	x9, [sp, #0x50]
    5434:      	ldp	x8, x9, [x8]
    5438:      	stp	x8, x9, [sp, #0x30]
    543c:      	mov	w8, #0x28               // =40
    5440:      	mov	w9, #0x6                // =6
    5444:      	ldr	x2, [sp, #0x8]
    5448:      	blr	x9
    544c:      	ldr	w8, [x21, #0x2c0]
    5450:      	cmp	w8, #0x7e
    5454:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    5458:      	b	0x2d84 <perf_unwind_perl+0x2d84>
    545c:      	add	x8, sp, #0x98
    5460:      	ldr	x24, [x8]
    5464:      	cbz	x24, 0x2f04 <perf_unwind_perl+0x2f04>
    5468:      	ldr	x8, [sp, #0x10]
    546c:      	ldr	x8, [x8]
    5470:      	str	x8, [sp, #0x8]
    5474:      	ldr	w8, [x23]
    5478:      	cbnz	w8, 0x6a24 <perf_unwind_perl+0x6a24>
    547c:      	ldr	w8, [x21, #0x2c0]
    5480:      	cmp	w8, #0x7e
    5484:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    5488:      	add	w9, w8, #0x1
    548c:      	ldr	x10, [sp, #0x8]
    5490:      	str	w9, [x21, #0x2c0]
    5494:      	mov	w9, #0x18               // =24
    5498:      	umaddl	x8, w8, w9, x21
    549c:      	add	x9, x8, #0x2d0
    54a0:      	str	x10, [x8, #0x2d8]
    54a4:      	mov	w10, #0x7               // =7
    54a8:      	str	x24, [x8, #0x2d0]
    54ac:      	str	wzr, [x8, #0x2e4]
    54b0:      	str	xzr, [x21, #0xf30]
    54b4:      	strb	w10, [x8, #0x2e0]
    54b8:      	stur	wzr, [x9, #0x11]
    54bc:      	b	0x3704 <perf_unwind_perl+0x3704>
    54c0:      	mov	w8, #0x786c             // =30828
    54c4:      	add	x10, sp, #0x30
    54c8:      	add	x0, sp, #0x30
    54cc:      	mov	w1, #0x14               // =20
    54d0:      	movk	w8, #0xa, lsl #16
    54d4:      	str	w8, [sp, #0x40]
    54d8:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    54dc:      	add	x8, x8, #0x0
    54e0:      	ldp	x9, x8, [x8]
    54e4:      	stp	x9, x8, [sp, #0x30]
    54e8:      	mov	w8, #0x14               // =20
    54ec:      	mov	w9, #0x6                // =6
    54f0:      	ldr	x2, [sp, #0x80]
    54f4:      	blr	x9
    54f8:      	add	x8, sp, #0x80
    54fc:      	ldr	x8, [x8]
    5500:      	ldr	x24, [sp, #0x10]
    5504:      	str	x8, [sp, #0x8]
    5508:      	cbnz	x8, 0x2d6c <perf_unwind_perl+0x2d6c>
    550c:      	b	0xcd8 <perf_unwind_perl+0xcd8>
    5510:      	mov	w8, #0x786c             // =30828
    5514:      	add	x10, sp, #0x30
    5518:      	add	x0, sp, #0x30
    551c:      	mov	w1, #0x13               // =19
    5520:      	movk	w8, #0xa, lsl #16
    5524:      	stur	w8, [sp, #0x3f]
    5528:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    552c:      	add	x8, x8, #0x0
    5530:      	ldp	x9, x8, [x8]
    5534:      	stp	x9, x8, [sp, #0x30]
    5538:      	mov	w8, #0x13               // =19
    553c:      	mov	w9, #0x6                // =6
    5540:      	ldr	x2, [sp, #0x98]
    5544:      	blr	x9
    5548:      	ldr	x8, [sp, #0x98]
    554c:      	b	0x23d4 <perf_unwind_perl+0x23d4>
    5550:      	ldr	w8, [x23]
    5554:      	cbz	w8, 0x4e3c <perf_unwind_perl+0x4e3c>
    5558:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    555c:      	add	x8, x8, #0x0
    5560:      	add	x0, sp, #0x30
    5564:      	ldp	x9, x10, [x8, #0x10]
    5568:      	mov	w1, #0x26               // =38
    556c:      	stp	x9, x10, [sp, #0x40]
    5570:      	ldur	x9, [x8, #0x1e]
    5574:      	add	x10, sp, #0x30
    5578:      	stur	x9, [sp, #0x4e]
    557c:      	ldp	x8, x9, [x8]
    5580:      	stp	x8, x9, [sp, #0x30]
    5584:      	mov	w8, #0x26               // =38
    5588:      	mov	w9, #0x6                // =6
    558c:      	ldr	w2, [sp, #0xb8]
    5590:      	ldr	w3, [sp, #0xa4]
    5594:      	blr	x9
    5598:      	b	0x4e3c <perf_unwind_perl+0x4e3c>
    559c:      	mov	w8, #0xa                // =10
    55a0:      	add	x10, sp, #0x30
    55a4:      	add	x0, sp, #0x30
    55a8:      	strh	w8, [sp, #0x40]
    55ac:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    55b0:      	add	x8, x8, #0x0
    55b4:      	mov	w1, #0x12               // =18
    55b8:      	ldp	x9, x8, [x8]
    55bc:      	stp	x9, x8, [sp, #0x30]
    55c0:      	mov	w8, #0x12               // =18
    55c4:      	mov	w9, #0x6                // =6
    55c8:      	ldrb	w2, [sp, #0x7c]
    55cc:      	blr	x9
    55d0:      	ldrb	w8, [sp, #0x7c]
    55d4:      	and	w9, w8, #0xf
    55d8:      	sub	w10, w9, #0x9
    55dc:      	cmp	w10, #0x2
    55e0:      	b.lo	0x4f1c <perf_unwind_perl+0x4f1c>
    55e4:      	cmp	w9, #0xc
    55e8:      	b.ne	0x5cb8 <perf_unwind_perl+0x5cb8>
    55ec:      	mov	w29, #0x3               // =3
    55f0:      	ldrb	w8, [x22, #0x1d]
    55f4:      	ldr	x9, [x21, #0xf40]
    55f8:      	adrp	x0, 0x5000 <perf_unwind_perl+0x5000>
    55fc:      	add	x1, sp, #0xa8
    5600:      	sub	x8, x9, x8
    5604:      	add	x9, sp, #0xa8
    5608:      	str	x8, [x21, #0xf40]
    560c:      	mov	w8, #0x10               // =16
    5610:      	str	w8, [sp, #0xa8]
    5614:      	mov	w8, #0x1                // =1
    5618:      	ldr	x0, [x0]
    561c:      	blr	x8
    5620:      	cbz	x0, 0x5c2c <perf_unwind_perl+0x5c2c>
    5624:      	ldr	x8, [x0]
    5628:      	add	x8, x8, #0x1
    562c:      	str	x8, [x0]
    5630:      	ldp	x24, x9, [sp, #0x10]
    5634:      	cmp	w29, #0x3
    5638:      	b.eq	0x5c40 <perf_unwind_perl+0x5c40>
    563c:      	ldr	x8, [x21, #0xf40]
    5640:      	cmp	x8, x9
    5644:      	b.hs	0x5818 <perf_unwind_perl+0x5818>
    5648:      	ldr	x24, [x24]
    564c:      	ldr	x25, [sp, #0x20]
    5650:      	cbz	x24, 0x56d4 <perf_unwind_perl+0x56d4>
    5654:      	ldr	w8, [x23]
    5658:      	cbnz	w8, 0x59d4 <perf_unwind_perl+0x59d4>
    565c:      	ldr	w8, [x21, #0x2c0]
    5660:      	cmp	w8, #0x7f
    5664:      	b.lo	0x56a4 <perf_unwind_perl+0x56a4>
    5668:      	ldr	w8, [x23]
    566c:      	cbnz	w8, 0x5ad8 <perf_unwind_perl+0x5ad8>
    5670:      	mov	w8, #0x2                // =2
    5674:      	adrp	x0, 0x5000 <perf_unwind_perl+0x5000>
    5678:      	add	x9, sp, #0xa8
    567c:      	str	w8, [sp, #0xa8]
    5680:      	mov	w8, #0x1                // =1
    5684:      	add	x1, sp, #0xa8
    5688:      	ldr	x0, [x0]
    568c:      	blr	x8
    5690:      	cbz	x0, 0x5900 <perf_unwind_perl+0x5900>
    5694:      	ldr	x8, [x0]
    5698:      	add	x8, x8, #0x1
    569c:      	str	x8, [x0]
    56a0:      	b	0x5908 <perf_unwind_perl+0x5908>
    56a4:      	add	w9, w8, #0x1
    56a8:      	mov	w10, #0x7               // =7
    56ac:      	str	w9, [x21, #0x2c0]
    56b0:      	mov	w9, #0x18               // =24
    56b4:      	umaddl	x8, w8, w9, x21
    56b8:      	add	x9, x8, #0x2d0
    56bc:      	str	xzr, [x8, #0x2d0]
    56c0:      	str	x24, [x8, #0x2d8]
    56c4:      	strb	w10, [x8, #0x2e0]
    56c8:      	str	wzr, [x8, #0x2e4]
    56cc:      	str	xzr, [x21, #0xf30]
    56d0:      	stur	wzr, [x9, #0x11]
    56d4:      	ldr	x8, [sp, #0x68]
    56d8:      	ldrb	w9, [x22, #0x18]
    56dc:      	mov	w10, #0x70              // =112
    56e0:      	add	x11, sp, #0x80
    56e4:      	add	x0, sp, #0x80
    56e8:      	mov	w1, #0x4                // =4
    56ec:      	str	wzr, [sp, #0x80]
    56f0:      	add	x8, x8, x9
    56f4:      	mov	w9, #0x4                // =4
    56f8:      	ldr	x8, [sp, #0x68]
    56fc:      	ldrb	w9, [x22, #0x18]
    5700:      	add	x2, x8, x9
    5704:      	blr	x10
    5708:      	cbnz	x0, 0x5800 <perf_unwind_perl+0x5800>
    570c:      	ldr	w8, [sp, #0x80]
    5710:      	cmp	w8, #0x1
    5714:      	b.eq	0x5800 <perf_unwind_perl+0x5800>
    5718:      	ldr	x8, [sp, #0x68]
    571c:      	ldrb	w9, [x22, #0x16]
    5720:      	mov	w10, #0x70              // =112
    5724:      	add	x11, sp, #0x68
    5728:      	add	x0, sp, #0x68
    572c:      	mov	w1, #0x8                // =8
    5730:      	add	x8, x8, x9
    5734:      	mov	w9, #0x8                // =8
    5738:      	ldr	x8, [sp, #0x68]
    573c:      	ldrb	w9, [x22, #0x16]
    5740:      	add	x2, x8, x9
    5744:      	blr	x10
    5748:      	cbnz	x0, 0x5800 <perf_unwind_perl+0x5800>
    574c:      	ldr	x24, [sp, #0x68]
    5750:      	cbz	x24, 0x5800 <perf_unwind_perl+0x5800>
    5754:      	ldr	w8, [x23]
    5758:      	cbnz	w8, 0x5b14 <perf_unwind_perl+0x5b14>
    575c:      	str	x24, [x25]
    5760:      	mov	w9, #0x8                // =8
    5764:      	mov	w10, #0x70              // =112
    5768:      	add	x11, sp, #0xa8
    576c:      	ldrb	w8, [x22, #0x15]
    5770:      	add	x0, sp, #0xa8
    5774:      	mov	w1, #0x8                // =8
    5778:      	add	x8, x24, x8
    577c:      	ldrb	w8, [x22, #0x15]
    5780:      	add	x2, x24, x8
    5784:      	blr	x10
    5788:      	cbnz	x0, 0x57b8 <perf_unwind_perl+0x57b8>
    578c:      	ldrb	w8, [x22, #0x17]
    5790:      	mov	w9, #0x4                // =4
    5794:      	mov	w10, #0x70              // =112
    5798:      	add	x11, sp, #0x88
    579c:      	add	x0, sp, #0x88
    57a0:      	mov	w1, #0x4                // =4
    57a4:      	add	x8, x24, x8
    57a8:      	ldrb	w8, [x22, #0x17]
    57ac:      	add	x2, x24, x8
    57b0:      	blr	x10
    57b4:      	cbz	x0, 0x5960 <perf_unwind_perl+0x5960>
    57b8:      	ldr	w8, [x23]
    57bc:      	cbnz	w8, 0x5b58 <perf_unwind_perl+0x5b58>
    57c0:      	ldr	w8, [x21, #0x1370]
    57c4:      	adrp	x0, 0x5000 <perf_unwind_perl+0x5000>
    57c8:      	add	x9, sp, #0x98
    57cc:      	add	x1, sp, #0x98
    57d0:      	orr	w8, w8, #0x8
    57d4:      	str	w8, [x21, #0x1370]
    57d8:      	mov	w8, #0x12               // =18
    57dc:      	str	w8, [sp, #0x98]
    57e0:      	mov	w8, #0x1                // =1
    57e4:      	ldr	x0, [x0]
    57e8:      	blr	x8
    57ec:      	cbz	x0, 0x5910 <perf_unwind_perl+0x5910>
    57f0:      	ldr	x8, [x0]
    57f4:      	add	x8, x8, #0x1
    57f8:      	str	x8, [x0]
    57fc:      	b	0x5814 <perf_unwind_perl+0x5814>
    5800:      	ldr	w8, [x23]
    5804:      	cbnz	w8, 0x5a5c <perf_unwind_perl+0x5a5c>
    5808:      	ldr	w8, [x21, #0x1370]
    580c:      	orr	w8, w8, #0x8
    5810:      	str	w8, [x21, #0x1370]
    5814:      	mov	w29, #0x1               // =1
    5818:      	ldr	w8, [x23]
    581c:      	cbnz	w8, 0x5984 <perf_unwind_perl+0x5984>
    5820:      	str	wzr, [sp, #0x30]
    5824:      	mov	w8, #0x1                // =1
    5828:      	add	x9, sp, #0x30
    582c:      	add	x1, sp, #0x30
    5830:      	mov	x0, x20
    5834:      	blr	x8
    5838:      	cbz	x0, 0x588c <perf_unwind_perl+0x588c>
    583c:      	mov	w20, #0x1374            // =4980
    5840:      	ldrb	w8, [x0, x20]
    5844:      	cmp	w8, #0x1d
    5848:      	b.lo	0x58bc <perf_unwind_perl+0x58bc>
    584c:      	mov	w8, #0x5                // =5
    5850:      	mov	x21, x0
    5854:      	add	x9, sp, #0xa8
    5858:      	str	w8, [x0, #0xf1c]
    585c:      	mov	w8, #0x44               // =68
    5860:      	adrp	x0, 0x5000 <perf_unwind_perl+0x5000>
    5864:      	add	x1, sp, #0xa8
    5868:      	str	w8, [sp, #0xa8]
    586c:      	mov	w8, #0x1                // =1
    5870:      	ldr	x0, [x0]
    5874:      	blr	x8
    5878:      	cbz	x0, 0x58a8 <perf_unwind_perl+0x58a8>
    587c:      	ldr	x8, [x0]
    5880:      	add	x8, x8, #0x1
    5884:      	str	x8, [x0]
    5888:      	b	0x58b0 <perf_unwind_perl+0x58b0>
    588c:      	adrp	x1, 0x5000 <perf_unwind_perl+0x5000>
    5890:      	mov	x8, xzr
    5894:      	mov	w9, #0xc                // =12
    5898:      	ldr	x1, [x1]
    589c:      	mov	x0, x19
    58a0:      	mov	w2, wzr
    58a4:      	b	0x58dc <perf_unwind_perl+0x58dc>
    58a8:      	ldr	w8, [x23]
    58ac:      	cbnz	w8, 0x5a90 <perf_unwind_perl+0x5a90>
    58b0:      	ldrb	w8, [x21, x20]
    58b4:      	mov	w29, wzr
    58b8:      	mov	x0, x21
    58bc:      	add	w8, w8, #0x1
    58c0:      	adrp	x1, 0x5000 <perf_unwind_perl+0x5000>
    58c4:      	mov	w9, #0xc                // =12
    58c8:      	strb	w8, [x0, x20]
    58cc:      	mov	w8, w29
    58d0:      	mov	x0, x19
    58d4:      	mov	w2, w29
    58d8:      	ldr	x1, [x1]
    58dc:      	blr	x9
    58e0:      	mov	w0, #-0x1               // =-1
    58e4:      	ldp	x20, x19, [sp, #0xf0]
    58e8:      	ldr	x29, [sp, #0xb0]
    58ec:      	ldp	x22, x21, [sp, #0xe0]
    58f0:      	ldp	x24, x23, [sp, #0xd0]
    58f4:      	ldp	x30, x25, [sp, #0xc0]
    58f8:      	add	sp, sp, #0x100
    58fc:      	ret
    5900:      	ldr	w8, [x23]
    5904:      	cbnz	w8, 0x5b9c <perf_unwind_perl+0x5b9c>
    5908:      	mov	w29, wzr
    590c:      	b	0x5820 <perf_unwind_perl+0x5820>
    5910:      	ldr	w8, [x23]
    5914:      	cbz	w8, 0x5814 <perf_unwind_perl+0x5814>
    5918:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    591c:      	add	x8, x8, #0x0
    5920:      	add	x0, sp, #0x30
    5924:      	ldp	x9, x10, [x8, #0x10]
    5928:      	mov	w1, #0x2e               // =46
    592c:      	stp	x9, x10, [sp, #0x40]
    5930:      	ldr	x9, [x8, #0x20]
    5934:      	add	x10, sp, #0x30
    5938:      	str	x9, [sp, #0x50]
    593c:      	ldur	x9, [x8, #0x26]
    5940:      	stur	x9, [sp, #0x56]
    5944:      	ldp	x9, x8, [x8]
    5948:      	stp	x9, x8, [sp, #0x30]
    594c:      	mov	w8, #0x2e               // =46
    5950:      	mov	w9, #0x6                // =6
    5954:      	ldr	w2, [sp, #0x98]
    5958:      	blr	x9
    595c:      	b	0x5814 <perf_unwind_perl+0x5814>
    5960:      	ldr	w8, [x23]
    5964:      	cbnz	w8, 0x5be8 <perf_unwind_perl+0x5be8>
    5968:      	ldr	x8, [sp, #0xa8]
    596c:      	ldrsw	x9, [sp, #0x88]
    5970:      	str	x8, [x21, #0xf38]
    5974:      	ldrb	w10, [x22, #0x1d]
    5978:      	smaddl	x8, w9, w10, x8
    597c:      	str	x8, [x21, #0xf40]
    5980:      	b	0x5814 <perf_unwind_perl+0x5814>
    5984:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    5988:      	add	x8, x8, #0x0
    598c:      	add	x0, sp, #0x30
    5990:      	ldp	x9, x10, [x8, #0x20]
    5994:      	mov	w1, #0x35               // =53
    5998:      	stp	x9, x10, [sp, #0x50]
    599c:      	ldur	x9, [x8, #0x2d]
    59a0:      	stur	x9, [sp, #0x5d]
    59a4:      	ldp	x9, x10, [x8]
    59a8:      	stp	x9, x10, [sp, #0x30]
    59ac:      	ldp	x8, x9, [x8, #0x10]
    59b0:      	add	x10, sp, #0x30
    59b4:      	stp	x8, x9, [sp, #0x40]
    59b8:      	mov	w8, #0x35               // =53
    59bc:      	mov	w9, #0x6                // =6
    59c0:      	ldr	x2, [sp, #0x68]
    59c4:      	ldr	x3, [x21, #0xf38]
    59c8:      	ldr	x4, [x21, #0xf40]
    59cc:      	blr	x9
    59d0:      	b	0x5820 <perf_unwind_perl+0x5820>
    59d4:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    59d8:      	add	x8, x8, #0x0
    59dc:      	add	x0, sp, #0x30
    59e0:      	ldp	x9, x10, [x8, #0x10]
    59e4:      	mov	w1, #0x28               // =40
    59e8:      	mov	x2, x24
    59ec:      	stp	x9, x10, [sp, #0x40]
    59f0:      	ldr	x9, [x8, #0x20]
    59f4:      	add	x10, sp, #0x30
    59f8:      	str	x9, [sp, #0x50]
    59fc:      	ldp	x8, x9, [x8]
    5a00:      	stp	x8, x9, [sp, #0x30]
    5a04:      	mov	w8, #0x28               // =40
    5a08:      	mov	w9, #0x6                // =6
    5a0c:      	blr	x9
    5a10:      	ldr	w8, [x23]
    5a14:      	cbz	w8, 0x565c <perf_unwind_perl+0x565c>
    5a18:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    5a1c:      	add	x8, x8, #0x0
    5a20:      	add	x0, sp, #0x30
    5a24:      	ldp	x9, x10, [x8, #0x10]
    5a28:      	mov	w1, #0x28               // =40
    5a2c:      	mov	x2, xzr
    5a30:      	mov	x3, x24
    5a34:      	stp	x9, x10, [sp, #0x40]
    5a38:      	ldr	x9, [x8, #0x20]
    5a3c:      	add	x10, sp, #0x30
    5a40:      	str	x9, [sp, #0x50]
    5a44:      	ldp	x8, x9, [x8]
    5a48:      	stp	x8, x9, [sp, #0x30]
    5a4c:      	mov	w8, #0x28               // =40
    5a50:      	mov	w9, #0x6                // =6
    5a54:      	blr	x9
    5a58:      	b	0x565c <perf_unwind_perl+0x565c>
    5a5c:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    5a60:      	add	x8, x8, #0x0
    5a64:      	add	x0, sp, #0x30
    5a68:      	ldp	x9, x10, [x8]
    5a6c:      	ldur	x8, [x8, #0xe]
    5a70:      	mov	w1, #0x16               // =22
    5a74:      	stp	x9, x10, [sp, #0x30]
    5a78:      	stur	x8, [sp, #0x3e]
    5a7c:      	mov	w8, #0x16               // =22
    5a80:      	mov	w9, #0x6                // =6
    5a84:      	add	x10, sp, #0x30
    5a88:      	blr	x9
    5a8c:      	b	0x5808 <perf_unwind_perl+0x5808>
    5a90:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    5a94:      	add	x8, x8, #0x0
    5a98:      	add	x0, sp, #0x30
    5a9c:      	ldp	x9, x10, [x8, #0x10]
    5aa0:      	mov	w1, #0x2e               // =46
    5aa4:      	stp	x9, x10, [sp, #0x40]
    5aa8:      	ldr	x9, [x8, #0x20]
    5aac:      	add	x10, sp, #0x30
    5ab0:      	str	x9, [sp, #0x50]
    5ab4:      	ldur	x9, [x8, #0x26]
    5ab8:      	stur	x9, [sp, #0x56]
    5abc:      	ldp	x9, x8, [x8]
    5ac0:      	stp	x9, x8, [sp, #0x30]
    5ac4:      	mov	w8, #0x2e               // =46
    5ac8:      	mov	w9, #0x6                // =6
    5acc:      	ldr	w2, [sp, #0xa8]
    5ad0:      	blr	x9
    5ad4:      	b	0x58b0 <perf_unwind_perl+0x58b0>
    5ad8:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    5adc:      	add	x8, x8, #0x0
    5ae0:      	add	x0, sp, #0x30
    5ae4:      	ldp	x9, x10, [x8, #0x10]
    5ae8:      	mov	w1, #0x25               // =37
    5aec:      	stp	x9, x10, [sp, #0x40]
    5af0:      	ldur	x9, [x8, #0x1d]
    5af4:      	add	x10, sp, #0x30
    5af8:      	stur	x9, [sp, #0x4d]
    5afc:      	ldp	x8, x9, [x8]
    5b00:      	stp	x8, x9, [sp, #0x30]
    5b04:      	mov	w8, #0x25               // =37
    5b08:      	mov	w9, #0x6                // =6
    5b0c:      	blr	x9
    5b10:      	b	0x5670 <perf_unwind_perl+0x5670>
    5b14:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    5b18:      	add	x8, x8, #0x0
    5b1c:      	add	x0, sp, #0x30
    5b20:      	ldp	x9, x10, [x8]
    5b24:      	mov	w1, #0x1e               // =30
    5b28:      	stp	x9, x10, [sp, #0x30]
    5b2c:      	ldr	x9, [x8, #0x10]
    5b30:      	ldur	x8, [x8, #0x16]
    5b34:      	add	x10, sp, #0x30
    5b38:      	str	x9, [sp, #0x40]
    5b3c:      	stur	x8, [sp, #0x46]
    5b40:      	mov	w8, #0x1e               // =30
    5b44:      	mov	w9, #0x6                // =6
    5b48:      	ldr	w2, [sp, #0x80]
    5b4c:      	blr	x9
    5b50:      	ldr	x24, [sp, #0x68]
    5b54:      	b	0x575c <perf_unwind_perl+0x575c>
    5b58:      	mov	w8, #0x786c             // =30828
    5b5c:      	add	x0, sp, #0x30
    5b60:      	mov	w1, #0x23               // =35
    5b64:      	mov	x2, x24
    5b68:      	movk	w8, #0xa, lsl #16
    5b6c:      	stur	w8, [sp, #0x4f]
    5b70:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    5b74:      	add	x8, x8, #0x0
    5b78:      	ldp	x9, x10, [x8]
    5b7c:      	stp	x9, x10, [sp, #0x30]
    5b80:      	ldp	x9, x8, [x8, #0x10]
    5b84:      	add	x10, sp, #0x30
    5b88:      	stp	x9, x8, [sp, #0x40]
    5b8c:      	mov	w8, #0x23               // =35
    5b90:      	mov	w9, #0x6                // =6
    5b94:      	blr	x9
    5b98:      	b	0x57c0 <perf_unwind_perl+0x57c0>
    5b9c:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    5ba0:      	add	x8, x8, #0x0
    5ba4:      	add	x0, sp, #0x30
    5ba8:      	ldp	x9, x10, [x8, #0x10]
    5bac:      	mov	w1, #0x2e               // =46
    5bb0:      	stp	x9, x10, [sp, #0x40]
    5bb4:      	ldr	x9, [x8, #0x20]
    5bb8:      	add	x10, sp, #0x30
    5bbc:      	str	x9, [sp, #0x50]
    5bc0:      	ldur	x9, [x8, #0x26]
    5bc4:      	stur	x9, [sp, #0x56]
    5bc8:      	ldp	x9, x8, [x8]
    5bcc:      	stp	x9, x8, [sp, #0x30]
    5bd0:      	mov	w8, #0x2e               // =46
    5bd4:      	mov	w9, #0x6                // =6
    5bd8:      	ldr	w2, [sp, #0xa8]
    5bdc:      	blr	x9
    5be0:      	mov	w29, wzr
    5be4:      	b	0x5820 <perf_unwind_perl+0x5820>
    5be8:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    5bec:      	add	x8, x8, #0x0
    5bf0:      	add	x0, sp, #0x30
    5bf4:      	ldp	x9, x10, [x8, #0x10]
    5bf8:      	mov	w1, #0x26               // =38
    5bfc:      	stp	x9, x10, [sp, #0x40]
    5c00:      	ldur	x9, [x8, #0x1e]
    5c04:      	add	x10, sp, #0x30
    5c08:      	stur	x9, [sp, #0x4e]
    5c0c:      	ldp	x8, x9, [x8]
    5c10:      	stp	x8, x9, [sp, #0x30]
    5c14:      	mov	w8, #0x26               // =38
    5c18:      	mov	w9, #0x6                // =6
    5c1c:      	ldr	x2, [sp, #0xa8]
    5c20:      	ldr	w3, [sp, #0x88]
    5c24:      	blr	x9
    5c28:      	b	0x5968 <perf_unwind_perl+0x5968>
    5c2c:      	ldr	w8, [x23]
    5c30:      	cbnz	w8, 0x60d8 <perf_unwind_perl+0x60d8>
    5c34:      	ldp	x24, x9, [sp, #0x10]
    5c38:      	cmp	w29, #0x3
    5c3c:      	b.ne	0x563c <perf_unwind_perl+0x563c>
    5c40:      	ldr	x25, [x21, #0xf40]
    5c44:      	cmp	x25, x9
    5c48:      	b.lo	0x2ecc <perf_unwind_perl+0x2ecc>
    5c4c:      	ldrb	w8, [x22, #0x19]
    5c50:      	mov	w9, #0x1                // =1
    5c54:      	mov	w10, #0x70              // =112
    5c58:      	add	x11, sp, #0x7c
    5c5c:      	add	x0, sp, #0x7c
    5c60:      	mov	w1, #0x1                // =1
    5c64:      	add	x8, x25, x8
    5c68:      	ldrb	w8, [x22, #0x19]
    5c6c:      	add	x2, x25, x8
    5c70:      	blr	x10
    5c74:      	cbz	x0, 0x5d3c <perf_unwind_perl+0x5d3c>
    5c78:      	ldr	w8, [x23]
    5c7c:      	cbnz	w8, 0x6170 <perf_unwind_perl+0x6170>
    5c80:      	mov	w8, #0x13               // =19
    5c84:      	adrp	x0, 0x5000 <perf_unwind_perl+0x5000>
    5c88:      	add	x9, sp, #0xa8
    5c8c:      	str	w8, [sp, #0xa8]
    5c90:      	mov	w8, #0x1                // =1
    5c94:      	add	x1, sp, #0xa8
    5c98:      	ldr	x0, [x0]
    5c9c:      	blr	x8
    5ca0:      	cbz	x0, 0x5e34 <perf_unwind_perl+0x5e34>
    5ca4:      	ldr	x8, [x0]
    5ca8:      	mov	w29, #0x3               // =3
    5cac:      	add	x8, x8, #0x1
    5cb0:      	str	x8, [x0]
    5cb4:      	b	0x63e4 <perf_unwind_perl+0x63e4>
    5cb8:      	ldr	x8, [sp, #0x10]
    5cbc:      	mov	w29, #0x3               // =3
    5cc0:      	ldr	x8, [x8]
    5cc4:      	cbnz	x8, 0x55f0 <perf_unwind_perl+0x55f0>
    5cc8:      	ldrb	w8, [x22, #0x1a]
    5ccc:      	mov	w9, #0x8                // =8
    5cd0:      	mov	w10, #0x70              // =112
    5cd4:      	ldr	x0, [sp, #0x10]
    5cd8:      	mov	w1, #0x8                // =8
    5cdc:      	add	x8, x25, x8
    5ce0:      	ldrb	w8, [x22, #0x1a]
    5ce4:      	add	x2, x25, x8
    5ce8:      	blr	x10
    5cec:      	cbnz	x0, 0x4e3c <perf_unwind_perl+0x4e3c>
    5cf0:      	ldr	w8, [x23]
    5cf4:      	cbz	w8, 0x55f0 <perf_unwind_perl+0x55f0>
    5cf8:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    5cfc:      	add	x8, x8, #0x0
    5d00:      	add	x0, sp, #0x30
    5d04:      	ldp	x9, x10, [x8]
    5d08:      	mov	w1, #0x1e               // =30
    5d0c:      	stp	x9, x10, [sp, #0x30]
    5d10:      	ldr	x9, [x8, #0x10]
    5d14:      	ldur	x8, [x8, #0x16]
    5d18:      	add	x10, sp, #0x30
    5d1c:      	str	x9, [sp, #0x40]
    5d20:      	stur	x8, [sp, #0x46]
    5d24:      	mov	w8, #0x1e               // =30
    5d28:      	mov	w9, #0x6                // =6
    5d2c:      	ldr	x8, [sp, #0x10]
    5d30:      	ldr	x2, [x8]
    5d34:      	blr	x9
    5d38:      	b	0x55f0 <perf_unwind_perl+0x55f0>
    5d3c:      	ldr	w8, [x23]
    5d40:      	cbnz	w8, 0x6390 <perf_unwind_perl+0x6390>
    5d44:      	ldrb	w8, [sp, #0x7c]
    5d48:      	and	w9, w8, #0xf
    5d4c:      	sub	w10, w9, #0x9
    5d50:      	cmp	w10, #0x2
    5d54:      	b.hs	0x63d8 <perf_unwind_perl+0x63d8>
    5d58:      	sxtb	w8, w8
    5d5c:      	tbnz	w8, #0x1f, 0x63e0 <perf_unwind_perl+0x63e0>
    5d60:      	ldrb	w8, [x22, #0x1b]
    5d64:      	mov	w9, #0x8                // =8
    5d68:      	mov	w10, #0x70              // =112
    5d6c:      	add	x11, sp, #0x30
    5d70:      	add	x0, sp, #0x30
    5d74:      	mov	w1, #0x8                // =8
    5d78:      	add	x8, x25, x8
    5d7c:      	ldrb	w8, [x22, #0x1b]
    5d80:      	add	x2, x25, x8
    5d84:      	blr	x10
    5d88:      	cbnz	x0, 0x5c78 <perf_unwind_perl+0x5c78>
    5d8c:      	ldr	x8, [sp, #0x30]
    5d90:      	mov	w9, #0x8                // =8
    5d94:      	mov	w10, #0x70              // =112
    5d98:      	add	x11, sp, #0x70
    5d9c:      	add	x0, sp, #0x70
    5da0:      	mov	w1, #0x8                // =8
    5da4:      	cmp	x8, #0x0
    5da8:      	mov	w8, #0x3                // =3
    5dac:      	csinc	w29, w8, wzr, ne
    5db0:      	ldrb	w8, [x22, #0x1c]
    5db4:      	add	x8, x25, x8
    5db8:      	ldrb	w8, [x22, #0x1c]
    5dbc:      	add	x2, x25, x8
    5dc0:      	blr	x10
    5dc4:      	cbnz	x0, 0x5c78 <perf_unwind_perl+0x5c78>
    5dc8:      	ldr	x24, [sp, #0x70]
    5dcc:      	ldrb	w8, [x22, #0x1e]
    5dd0:      	mov	w9, #0x4                // =4
    5dd4:      	mov	w10, #0x70              // =112
    5dd8:      	add	x11, sp, #0xb8
    5ddc:      	add	x0, sp, #0xb8
    5de0:      	mov	w1, #0x4                // =4
    5de4:      	add	x8, x24, x8
    5de8:      	ldrb	w8, [x22, #0x1e]
    5dec:      	add	x2, x24, x8
    5df0:      	blr	x10
    5df4:      	cbz	x0, 0x5e84 <perf_unwind_perl+0x5e84>
    5df8:      	ldr	w8, [x23]
    5dfc:      	cbnz	w8, 0x689c <perf_unwind_perl+0x689c>
    5e00:      	mov	w8, #0x14               // =20
    5e04:      	adrp	x0, 0x5000 <perf_unwind_perl+0x5000>
    5e08:      	add	x9, sp, #0xbc
    5e0c:      	str	w8, [sp, #0xbc]
    5e10:      	mov	w8, #0x1                // =1
    5e14:      	add	x1, sp, #0xbc
    5e18:      	ldr	x0, [x0]
    5e1c:      	blr	x8
    5e20:      	cbz	x0, 0x6040 <perf_unwind_perl+0x6040>
    5e24:      	ldr	x8, [x0]
    5e28:      	add	x8, x8, #0x1
    5e2c:      	str	x8, [x0]
    5e30:      	b	0x5c78 <perf_unwind_perl+0x5c78>
    5e34:      	ldr	w8, [x23]
    5e38:      	cbz	w8, 0x63e0 <perf_unwind_perl+0x63e0>
    5e3c:      	adrp	x8, 0x5000 <perf_unwind_perl+0x5000>
    5e40:      	add	x8, x8, #0x0
    5e44:      	add	x0, sp, #0x30
    5e48:      	ldp	x9, x10, [x8, #0x10]
    5e4c:      	mov	w1, #0x2e               // =46
    5e50:      	stp	x9, x10, [sp, #0x40]
    5e54:      	ldr	x9, [x8, #0x20]
    5e58:      	add	x10, sp, #0x30
    5e5c:      	str	x9, [sp, #0x50]
    5e60:      	ldur	x9, [x8, #0x26]
    5e64:      	stur	x9, [sp, #0x56]
    5e68:      	ldp	x9, x8, [x8]
    5e6c:      	stp	x9, x8, [sp, #0x30]
    5e70:      	mov	w8, #0x2e               // =46
    5e74:      	mov	w9, #0x6                // =6
    5e78:      	ldr	w2, [sp, #0xa8]
    5e7c:      	blr	x9
    5e80:      	b	0x63e0 <perf_unwind_perl+0x63e0>
    5e84:      	ldr	w8, [sp, #0xb8]
    5e88:      	and	w8, w8, #0x1f
    5e8c:      	cmp	w8, #0xd
    5e90:      	b.ne	0x6090 <perf_unwind_perl+0x6090>
    5e94:      	ldrb	w8, [x22, #0x1f]
    5e98:      	mov	w9, #0x8                // =8
    5e9c:      	mov	w10, #0x70              // =112
    5ea0:      	add	x11, sp, #0xa8
    5ea4:      	add	x0, sp, #0xa8
    5ea8:      	mov	w1, #0x8                // =8
    5eac:      	add	x8, x24, x8
    5eb0:      	ldrb	w8, [x22, #0x1f]
    5eb4:      	add	x2, x24, x8
    5eb8:      	blr	x10
    5ebc:      	cbnz	x0, 0x5df8 <perf_unwind_perl+0x5df8>
    5ec0:      	ldr	x8, [sp, #0xa8]
    5ec4:      	ldrb	w9, [x22, #0x21]
    5ec8:      	mov	w10, #0x70              // =112
    5ecc:      	add	x11, sp, #0xa4
    5ed0:      	add	x0, sp, #0xa4
    5ed4:      	mov	w1, #0x4                // =4
    5ed8:      	add	x8, x8, x9
    5edc:      	mov	w9, #0x4                // =4
    5ee0:      	ldr	x8, [sp, #0xa8]
    5ee4:      	ldrb	w9, [x22, #0x21]
    5ee8:      	add	x2, x8, x9
    5eec:      	blr	x10
    5ef0:      	cbnz	x0, 0x5df8 <perf_unwind_perl+0x5df8>
    5ef4:      	ldrb	w8, [sp, #0xa5]
    5ef8:      	tbnz	w8, #0x7, 0x6344 <perf_unwind_perl+0x6344>
    5efc:      	ldr	x8, [sp, #0xa8]
    5f00:      	ldrb	w9, [x22, #0x22]
    5f04:      	mov	w10, #0x70              // =112
    5f08:      	add	x11, sp, #0x98
    5f0c:      	add	x0, sp, #0x98
    5f10:      	mov	w1, #0x8                // =8
    5f14:      	add	x8, x8, x9
    5f18:      	mov	w9, #0x8                // =8
    5f1c:      	ldr	x8, [sp, #0xa8]
    5f20:      	ldrb	w9, [x22, #0x22]
    5f24:      	add	x2, x8, x9
    5f28:      	blr	x10
    5f2c:      	cbnz	x0, 0x5df8 <perf_unwind_perl+0x5df8>
    5f30:      	ldr	x8, [sp, #0x98]
    5f34:      	cbz	x8, 0x5df8 <perf_unwind_perl+0x5df8>
    5f38:      	ldr	w9, [x23]
    5f3c:      	cbnz	w9, 0x6bf8 <perf_unwind_perl+0x6bf8>
    5f40:      	ldrb	w9, [x22, #0x1e]
    5f44:      	mov	w10, #0x70              // =112
    5f48:      	add	x11, sp, #0x94
    5f4c:      	add	x0, sp, #0x94
    5f50:      	mov	w1, #0x4                // =4
    5f54:      	add	x8, x8, x9
    5f58:      	mov	w9, #0x4                // =4
    5f5c:      	ldr	x8, [sp, #0x98]
    5f60:      	ldrb	w9, [x22, #0x1e]
    5f64:      	add	x2, x8, x9
    5f68:      	blr	x10
    5f6c:      	cbnz	x0, 0x5df8 <perf_unwind_perl+0x5df8>
    5f70:      	ldr	w8, [sp, #0x94]
    5f74:      	mov	w9, #0x801f             // =32799
    5f78:      	and	w8, w8, w9
    5f7c:      	mov	w9, #0x8009             // =32777
    5f80:      	cmp	w8, w9
    5f84:      	b.ne	0x6710 <perf_unwind_perl+0x6710>
    5f88:      	ldr	x8, [sp, #0x98]
    5f8c:      	ldrb	w9, [x22, #0x20]
    5f90:      	mov	w10, #0x70              // =112
    5f94:      	add	x11, sp, #0x88
    5f98:      	add	x0, sp, #0x88
    5f9c:      	mov	w1, #0x8                // =8
    5fa0:      	add	x8, x8, x9
    5fa4:      	mov	w9, #0x8                // =8
    5fa8:      	ldr	x8, [sp, #0x98]
    5fac:      	ldrb	w9, [x22, #0x20]
    5fb0:      	add	x2, x8, x9
    5fb4:      	blr	x10
    5fb8:      	cbnz	x0, 0x5df8 <perf_unwind_perl+0x5df8>
    5fbc:      	ldr	x8, [sp, #0x88]
    5fc0:      	ldrb	w9, [x22, #0x23]
    5fc4:      	mov	w10, #0x70              // =112
    5fc8:      	add	x11, sp, #0x80
    5fcc:      	add	x0, sp, #0x80
    5fd0:      	mov	w1, #0x8                // =8
    5fd4:      	add	x8, x8, x9
    5fd8:      	mov	w9, #0x8                // =8
    5fdc:      	ldr	x8, [sp, #0x88]
    5fe0:      	ldrb	w9, [x22, #0x23]
    5fe4:      	add	x2, x8, x9
    5fe8:      	blr	x10
    5fec:      	cbnz	x0, 0x5df8 <perf_unwind_perl+0x5df8>
    5ff0:      	ldr	x24, [sp, #0x80]
    5ff4:      	cbz	x24, 0x6a74 <perf_unwind_perl+0x6a74>
    5ff8:      	ldr	w8, [x23]
    5ffc:      	cbz	w8, 0x6a80 <perf_unwind_perl+0x6a80>
    6000:      	mov	w8, #0x786c             // =30828
    6004:      	add	x10, sp, #0x30
    6008:      	add	x0, sp, #0x30
    600c:      	mov	w1, #0x14               // =20
    6010:      	movk	w8, #0xa, lsl #16
    6014:      	str	w8, [sp, #0x40]
    6018:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    601c:      	add	x8, x8, #0x0
    6020:      	ldp	x9, x8, [x8]
    6024:      	stp	x9, x8, [sp, #0x30]
    6028:      	mov	w8, #0x14               // =20
    602c:      	mov	w9, #0x6                // =6
    6030:      	ldr	x2, [sp, #0x80]
    6034:      	blr	x9
    6038:      	add	x8, sp, #0x80
    603c:      	b	0x6a78 <perf_unwind_perl+0x6a78>
    6040:      	ldr	w8, [x23]
    6044:      	cbz	w8, 0x5c78 <perf_unwind_perl+0x5c78>
    6048:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    604c:      	add	x8, x8, #0x0
    6050:      	add	x0, sp, #0x30
    6054:      	ldp	x9, x10, [x8, #0x10]
    6058:      	mov	w1, #0x2e               // =46
    605c:      	stp	x9, x10, [sp, #0x40]
    6060:      	ldr	x9, [x8, #0x20]
    6064:      	add	x10, sp, #0x30
    6068:      	str	x9, [sp, #0x50]
    606c:      	ldur	x9, [x8, #0x26]
    6070:      	stur	x9, [sp, #0x56]
    6074:      	ldp	x9, x8, [x8]
    6078:      	stp	x9, x8, [sp, #0x30]
    607c:      	mov	w8, #0x2e               // =46
    6080:      	mov	w9, #0x6                // =6
    6084:      	ldr	w2, [sp, #0xbc]
    6088:      	blr	x9
    608c:      	b	0x5c78 <perf_unwind_perl+0x5c78>
    6090:      	ldr	w8, [x23]
    6094:      	cbz	w8, 0x5c78 <perf_unwind_perl+0x5c78>
    6098:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    609c:      	add	x8, x8, #0x0
    60a0:      	add	x0, sp, #0x30
    60a4:      	ldp	x9, x10, [x8]
    60a8:      	mov	w1, #0x1e               // =30
    60ac:      	stp	x9, x10, [sp, #0x30]
    60b0:      	ldr	x9, [x8, #0x10]
    60b4:      	ldur	x8, [x8, #0x16]
    60b8:      	add	x10, sp, #0x30
    60bc:      	str	x9, [sp, #0x40]
    60c0:      	stur	x8, [sp, #0x46]
    60c4:      	mov	w8, #0x1e               // =30
    60c8:      	mov	w9, #0x6                // =6
    60cc:      	ldr	w2, [sp, #0xb8]
    60d0:      	blr	x9
    60d4:      	b	0x5c78 <perf_unwind_perl+0x5c78>
    60d8:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    60dc:      	add	x8, x8, #0x0
    60e0:      	add	x0, sp, #0x30
    60e4:      	ldp	x9, x10, [x8, #0x10]
    60e8:      	mov	w1, #0x2e               // =46
    60ec:      	stp	x9, x10, [sp, #0x40]
    60f0:      	ldr	x9, [x8, #0x20]
    60f4:      	add	x10, sp, #0x30
    60f8:      	str	x9, [sp, #0x50]
    60fc:      	ldur	x9, [x8, #0x26]
    6100:      	stur	x9, [sp, #0x56]
    6104:      	ldp	x9, x8, [x8]
    6108:      	stp	x9, x8, [sp, #0x30]
    610c:      	mov	w8, #0x2e               // =46
    6110:      	mov	w9, #0x6                // =6
    6114:      	ldr	w2, [sp, #0xa8]
    6118:      	blr	x9
    611c:      	ldp	x24, x9, [sp, #0x10]
    6120:      	cmp	w29, #0x3
    6124:      	b.eq	0x5c40 <perf_unwind_perl+0x5c40>
    6128:      	b	0x563c <perf_unwind_perl+0x563c>
    612c:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6130:      	add	x8, x8, #0x0
    6134:      	add	x0, sp, #0x30
    6138:      	ldp	x9, x10, [x8, #0x10]
    613c:      	mov	w1, #0x2d               // =45
    6140:      	stp	x9, x10, [sp, #0x40]
    6144:      	ldr	x9, [x8, #0x20]
    6148:      	add	x10, sp, #0x30
    614c:      	str	x9, [sp, #0x50]
    6150:      	ldur	x9, [x8, #0x25]
    6154:      	stur	x9, [sp, #0x55]
    6158:      	ldp	x9, x8, [x8]
    615c:      	stp	x9, x8, [sp, #0x30]
    6160:      	mov	w8, #0x2d               // =45
    6164:      	mov	w9, #0x6                // =6
    6168:      	blr	x9
    616c:      	b	0x3fe4 <perf_unwind_perl+0x3fe4>
    6170:      	mov	w8, #0xa                // =10
    6174:      	add	x0, sp, #0x30
    6178:      	mov	w1, #0x2a               // =42
    617c:      	strh	w8, [sp, #0x58]
    6180:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6184:      	add	x8, x8, #0x0
    6188:      	mov	x2, x25
    618c:      	ldp	x9, x10, [x8, #0x10]
    6190:      	stp	x9, x10, [sp, #0x40]
    6194:      	ldr	x9, [x8, #0x20]
    6198:      	add	x10, sp, #0x30
    619c:      	str	x9, [sp, #0x50]
    61a0:      	ldp	x8, x9, [x8]
    61a4:      	stp	x8, x9, [sp, #0x30]
    61a8:      	mov	w8, #0x2a               // =42
    61ac:      	mov	w9, #0x6                // =6
    61b0:      	blr	x9
    61b4:      	b	0x5c80 <perf_unwind_perl+0x5c80>
    61b8:      	ldr	w8, [x23]
    61bc:      	cbz	w8, 0x45c4 <perf_unwind_perl+0x45c4>
    61c0:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    61c4:      	add	x8, x8, #0x0
    61c8:      	add	x0, sp, #0x30
    61cc:      	ldp	x9, x10, [x8, #0x10]
    61d0:      	mov	w1, #0x26               // =38
    61d4:      	stp	x9, x10, [sp, #0x40]
    61d8:      	ldur	x9, [x8, #0x1e]
    61dc:      	add	x10, sp, #0x30
    61e0:      	stur	x9, [sp, #0x4e]
    61e4:      	ldp	x8, x9, [x8]
    61e8:      	stp	x8, x9, [sp, #0x30]
    61ec:      	mov	w8, #0x26               // =38
    61f0:      	mov	w9, #0x6                // =6
    61f4:      	ldr	w2, [sp, #0x94]
    61f8:      	blr	x9
    61fc:      	b	0x45c4 <perf_unwind_perl+0x45c4>
    6200:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6204:      	add	x8, x8, #0x0
    6208:      	add	x0, sp, #0x30
    620c:      	ldp	x9, x10, [x8, #0x10]
    6210:      	mov	w1, #0x28               // =40
    6214:      	mov	x3, x24
    6218:      	stp	x9, x10, [sp, #0x40]
    621c:      	ldr	x9, [x8, #0x20]
    6220:      	add	x10, sp, #0x30
    6224:      	str	x9, [sp, #0x50]
    6228:      	ldp	x8, x9, [x8]
    622c:      	stp	x8, x9, [sp, #0x30]
    6230:      	mov	w8, #0x28               // =40
    6234:      	mov	w9, #0x6                // =6
    6238:      	ldr	x2, [sp, #0x8]
    623c:      	blr	x9
    6240:      	ldr	w8, [x21, #0x2c0]
    6244:      	cmp	w8, #0x7e
    6248:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    624c:      	b	0x3500 <perf_unwind_perl+0x3500>
    6250:      	add	x8, sp, #0x98
    6254:      	ldr	x24, [x8]
    6258:      	cbz	x24, 0x36b4 <perf_unwind_perl+0x36b4>
    625c:      	ldr	x8, [sp, #0x10]
    6260:      	ldr	x8, [x8]
    6264:      	str	x8, [sp, #0x8]
    6268:      	ldr	w8, [x23]
    626c:      	cbnz	w8, 0x6b18 <perf_unwind_perl+0x6b18>
    6270:      	ldr	w8, [x21, #0x2c0]
    6274:      	cmp	w8, #0x7e
    6278:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    627c:      	add	w9, w8, #0x1
    6280:      	ldr	x10, [sp, #0x8]
    6284:      	str	w9, [x21, #0x2c0]
    6288:      	mov	w9, #0x18               // =24
    628c:      	umaddl	x8, w8, w9, x21
    6290:      	add	x9, x8, #0x2d0
    6294:      	str	x10, [x8, #0x2d8]
    6298:      	mov	w10, #0x7               // =7
    629c:      	str	x24, [x8, #0x2d0]
    62a0:      	str	wzr, [x8, #0x2e4]
    62a4:      	str	xzr, [x21, #0xf30]
    62a8:      	strb	w10, [x8, #0x2e0]
    62ac:      	stur	wzr, [x9, #0x11]
    62b0:      	b	0x3eac <perf_unwind_perl+0x3eac>
    62b4:      	mov	w8, #0x786c             // =30828
    62b8:      	add	x10, sp, #0x30
    62bc:      	add	x0, sp, #0x30
    62c0:      	mov	w1, #0x14               // =20
    62c4:      	movk	w8, #0xa, lsl #16
    62c8:      	str	w8, [sp, #0x40]
    62cc:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    62d0:      	add	x8, x8, #0x0
    62d4:      	ldp	x9, x8, [x8]
    62d8:      	stp	x9, x8, [sp, #0x30]
    62dc:      	mov	w8, #0x14               // =20
    62e0:      	mov	w9, #0x6                // =6
    62e4:      	ldr	x2, [sp, #0x80]
    62e8:      	blr	x9
    62ec:      	add	x8, sp, #0x80
    62f0:      	ldr	x8, [x8]
    62f4:      	ldr	x24, [sp, #0x10]
    62f8:      	str	x8, [sp, #0x8]
    62fc:      	cbnz	x8, 0x34e8 <perf_unwind_perl+0x34e8>
    6300:      	b	0x131c <perf_unwind_perl+0x131c>
    6304:      	mov	w8, #0x786c             // =30828
    6308:      	add	x10, sp, #0x30
    630c:      	add	x0, sp, #0x30
    6310:      	mov	w1, #0x13               // =19
    6314:      	movk	w8, #0xa, lsl #16
    6318:      	stur	w8, [sp, #0x3f]
    631c:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6320:      	add	x8, x8, #0x0
    6324:      	ldp	x9, x8, [x8]
    6328:      	stp	x9, x8, [sp, #0x30]
    632c:      	mov	w8, #0x13               // =19
    6330:      	mov	w9, #0x6                // =6
    6334:      	ldr	x2, [sp, #0x98]
    6338:      	blr	x9
    633c:      	ldr	x8, [sp, #0x98]
    6340:      	b	0x2ab8 <perf_unwind_perl+0x2ab8>
    6344:      	ldr	w8, [x23]
    6348:      	cbz	w8, 0x5c78 <perf_unwind_perl+0x5c78>
    634c:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6350:      	add	x8, x8, #0x0
    6354:      	add	x0, sp, #0x30
    6358:      	ldp	x9, x10, [x8, #0x10]
    635c:      	mov	w1, #0x26               // =38
    6360:      	stp	x9, x10, [sp, #0x40]
    6364:      	ldur	x9, [x8, #0x1e]
    6368:      	add	x10, sp, #0x30
    636c:      	stur	x9, [sp, #0x4e]
    6370:      	ldp	x8, x9, [x8]
    6374:      	stp	x8, x9, [sp, #0x30]
    6378:      	mov	w8, #0x26               // =38
    637c:      	mov	w9, #0x6                // =6
    6380:      	ldr	w2, [sp, #0xb8]
    6384:      	ldr	w3, [sp, #0xa4]
    6388:      	blr	x9
    638c:      	b	0x5c78 <perf_unwind_perl+0x5c78>
    6390:      	mov	w8, #0xa                // =10
    6394:      	add	x10, sp, #0x30
    6398:      	add	x0, sp, #0x30
    639c:      	strh	w8, [sp, #0x40]
    63a0:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    63a4:      	add	x8, x8, #0x0
    63a8:      	mov	w1, #0x12               // =18
    63ac:      	ldp	x9, x8, [x8]
    63b0:      	stp	x9, x8, [sp, #0x30]
    63b4:      	mov	w8, #0x12               // =18
    63b8:      	mov	w9, #0x6                // =6
    63bc:      	ldrb	w2, [sp, #0x7c]
    63c0:      	blr	x9
    63c4:      	ldrb	w8, [sp, #0x7c]
    63c8:      	and	w9, w8, #0xf
    63cc:      	sub	w10, w9, #0x9
    63d0:      	cmp	w10, #0x2
    63d4:      	b.lo	0x5d58 <perf_unwind_perl+0x5d58>
    63d8:      	cmp	w9, #0xc
    63dc:      	b.ne	0x6478 <perf_unwind_perl+0x6478>
    63e0:      	mov	w29, #0x3               // =3
    63e4:      	ldrb	w8, [x22, #0x1d]
    63e8:      	ldr	x9, [x21, #0xf40]
    63ec:      	adrp	x0, 0x6000 <perf_unwind_perl+0x6000>
    63f0:      	add	x1, sp, #0xa8
    63f4:      	sub	x8, x9, x8
    63f8:      	add	x9, sp, #0xa8
    63fc:      	str	x8, [x21, #0xf40]
    6400:      	mov	w8, #0x10               // =16
    6404:      	str	w8, [sp, #0xa8]
    6408:      	mov	w8, #0x1                // =1
    640c:      	ldr	x0, [x0]
    6410:      	blr	x8
    6414:      	cbz	x0, 0x6428 <perf_unwind_perl+0x6428>
    6418:      	ldr	x8, [x0]
    641c:      	add	x8, x8, #0x1
    6420:      	str	x8, [x0]
    6424:      	b	0x2ed0 <perf_unwind_perl+0x2ed0>
    6428:      	ldr	w8, [x23]
    642c:      	cbz	w8, 0x2ed0 <perf_unwind_perl+0x2ed0>
    6430:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6434:      	add	x8, x8, #0x0
    6438:      	add	x0, sp, #0x30
    643c:      	ldp	x9, x10, [x8, #0x10]
    6440:      	mov	w1, #0x2e               // =46
    6444:      	stp	x9, x10, [sp, #0x40]
    6448:      	ldr	x9, [x8, #0x20]
    644c:      	add	x10, sp, #0x30
    6450:      	str	x9, [sp, #0x50]
    6454:      	ldur	x9, [x8, #0x26]
    6458:      	stur	x9, [sp, #0x56]
    645c:      	ldp	x9, x8, [x8]
    6460:      	stp	x9, x8, [sp, #0x30]
    6464:      	mov	w8, #0x2e               // =46
    6468:      	mov	w9, #0x6                // =6
    646c:      	ldr	w2, [sp, #0xa8]
    6470:      	blr	x9
    6474:      	b	0x2ed0 <perf_unwind_perl+0x2ed0>
    6478:      	ldr	x8, [sp, #0x10]
    647c:      	mov	w29, #0x3               // =3
    6480:      	ldr	x8, [x8]
    6484:      	cbnz	x8, 0x63e4 <perf_unwind_perl+0x63e4>
    6488:      	ldrb	w8, [x22, #0x1a]
    648c:      	mov	w9, #0x8                // =8
    6490:      	mov	w10, #0x70              // =112
    6494:      	ldr	x0, [sp, #0x10]
    6498:      	mov	w1, #0x8                // =8
    649c:      	add	x8, x25, x8
    64a0:      	ldrb	w8, [x22, #0x1a]
    64a4:      	add	x2, x25, x8
    64a8:      	blr	x10
    64ac:      	cbnz	x0, 0x5c78 <perf_unwind_perl+0x5c78>
    64b0:      	ldr	w8, [x23]
    64b4:      	cbz	w8, 0x63e4 <perf_unwind_perl+0x63e4>
    64b8:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    64bc:      	add	x8, x8, #0x0
    64c0:      	add	x0, sp, #0x30
    64c4:      	ldp	x9, x10, [x8]
    64c8:      	mov	w1, #0x1e               // =30
    64cc:      	stp	x9, x10, [sp, #0x30]
    64d0:      	ldr	x9, [x8, #0x10]
    64d4:      	ldur	x8, [x8, #0x16]
    64d8:      	add	x10, sp, #0x30
    64dc:      	str	x9, [sp, #0x40]
    64e0:      	stur	x8, [sp, #0x46]
    64e4:      	mov	w8, #0x1e               // =30
    64e8:      	mov	w9, #0x6                // =6
    64ec:      	ldr	x8, [sp, #0x10]
    64f0:      	ldr	x2, [x8]
    64f4:      	blr	x9
    64f8:      	b	0x63e4 <perf_unwind_perl+0x63e4>
    64fc:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6500:      	add	x8, x8, #0x0
    6504:      	add	x0, sp, #0x30
    6508:      	ldp	x9, x10, [x8, #0x10]
    650c:      	mov	w1, #0x2d               // =45
    6510:      	stp	x9, x10, [sp, #0x40]
    6514:      	ldr	x9, [x8, #0x20]
    6518:      	add	x10, sp, #0x30
    651c:      	str	x9, [sp, #0x50]
    6520:      	ldur	x9, [x8, #0x25]
    6524:      	stur	x9, [sp, #0x55]
    6528:      	ldp	x9, x8, [x8]
    652c:      	stp	x9, x8, [sp, #0x30]
    6530:      	mov	w8, #0x2d               // =45
    6534:      	mov	w9, #0x6                // =6
    6538:      	blr	x9
    653c:      	b	0x474c <perf_unwind_perl+0x474c>
    6540:      	ldr	w8, [x23]
    6544:      	cbz	w8, 0x4e3c <perf_unwind_perl+0x4e3c>
    6548:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    654c:      	add	x8, x8, #0x0
    6550:      	add	x0, sp, #0x30
    6554:      	ldp	x9, x10, [x8, #0x10]
    6558:      	mov	w1, #0x26               // =38
    655c:      	stp	x9, x10, [sp, #0x40]
    6560:      	ldur	x9, [x8, #0x1e]
    6564:      	add	x10, sp, #0x30
    6568:      	stur	x9, [sp, #0x4e]
    656c:      	ldp	x8, x9, [x8]
    6570:      	stp	x8, x9, [sp, #0x30]
    6574:      	mov	w8, #0x26               // =38
    6578:      	mov	w9, #0x6                // =6
    657c:      	ldr	w2, [sp, #0x94]
    6580:      	blr	x9
    6584:      	b	0x4e3c <perf_unwind_perl+0x4e3c>
    6588:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    658c:      	add	x8, x8, #0x0
    6590:      	add	x0, sp, #0x30
    6594:      	ldp	x9, x10, [x8, #0x10]
    6598:      	mov	w1, #0x28               // =40
    659c:      	mov	x3, x24
    65a0:      	stp	x9, x10, [sp, #0x40]
    65a4:      	ldr	x9, [x8, #0x20]
    65a8:      	add	x10, sp, #0x30
    65ac:      	str	x9, [sp, #0x50]
    65b0:      	ldp	x8, x9, [x8]
    65b4:      	stp	x8, x9, [sp, #0x30]
    65b8:      	mov	w8, #0x28               // =40
    65bc:      	mov	w9, #0x6                // =6
    65c0:      	ldr	x2, [sp, #0x8]
    65c4:      	blr	x9
    65c8:      	ldr	w8, [x21, #0x2c0]
    65cc:      	cmp	w8, #0x7e
    65d0:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    65d4:      	b	0x3ca8 <perf_unwind_perl+0x3ca8>
    65d8:      	add	x8, sp, #0x98
    65dc:      	ldr	x24, [x8]
    65e0:      	cbz	x24, 0x3e5c <perf_unwind_perl+0x3e5c>
    65e4:      	ldr	x8, [sp, #0x10]
    65e8:      	ldr	x8, [x8]
    65ec:      	str	x8, [sp, #0x8]
    65f0:      	ldr	w8, [x23]
    65f4:      	cbnz	w8, 0x6ba8 <perf_unwind_perl+0x6ba8>
    65f8:      	ldr	w8, [x21, #0x2c0]
    65fc:      	cmp	w8, #0x7e
    6600:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    6604:      	add	w9, w8, #0x1
    6608:      	ldr	x10, [sp, #0x8]
    660c:      	str	w9, [x21, #0x2c0]
    6610:      	mov	w9, #0x18               // =24
    6614:      	umaddl	x8, w8, w9, x21
    6618:      	add	x9, x8, #0x2d0
    661c:      	str	x10, [x8, #0x2d8]
    6620:      	mov	w10, #0x7               // =7
    6624:      	str	x24, [x8, #0x2d0]
    6628:      	str	wzr, [x8, #0x2e4]
    662c:      	str	xzr, [x21, #0xf30]
    6630:      	strb	w10, [x8, #0x2e0]
    6634:      	stur	wzr, [x9, #0x11]
    6638:      	b	0x4614 <perf_unwind_perl+0x4614>
    663c:      	mov	w8, #0x786c             // =30828
    6640:      	add	x10, sp, #0x30
    6644:      	add	x0, sp, #0x30
    6648:      	mov	w1, #0x14               // =20
    664c:      	movk	w8, #0xa, lsl #16
    6650:      	str	w8, [sp, #0x40]
    6654:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6658:      	add	x8, x8, #0x0
    665c:      	ldp	x9, x8, [x8]
    6660:      	stp	x9, x8, [sp, #0x30]
    6664:      	mov	w8, #0x14               // =20
    6668:      	mov	w9, #0x6                // =6
    666c:      	ldr	x2, [sp, #0x80]
    6670:      	blr	x9
    6674:      	add	x8, sp, #0x80
    6678:      	ldr	x8, [x8]
    667c:      	ldr	x24, [sp, #0x10]
    6680:      	str	x8, [sp, #0x8]
    6684:      	cbnz	x8, 0x3c90 <perf_unwind_perl+0x3c90>
    6688:      	b	0x1a74 <perf_unwind_perl+0x1a74>
    668c:      	mov	w8, #0x786c             // =30828
    6690:      	add	x10, sp, #0x30
    6694:      	add	x0, sp, #0x30
    6698:      	mov	w1, #0x13               // =19
    669c:      	movk	w8, #0xa, lsl #16
    66a0:      	stur	w8, [sp, #0x3f]
    66a4:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    66a8:      	add	x8, x8, #0x0
    66ac:      	ldp	x9, x8, [x8]
    66b0:      	stp	x9, x8, [sp, #0x30]
    66b4:      	mov	w8, #0x13               // =19
    66b8:      	mov	w9, #0x6                // =6
    66bc:      	ldr	x2, [sp, #0x98]
    66c0:      	blr	x9
    66c4:      	ldr	x8, [sp, #0x98]
    66c8:      	b	0x31d0 <perf_unwind_perl+0x31d0>
    66cc:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    66d0:      	add	x8, x8, #0x0
    66d4:      	add	x0, sp, #0x30
    66d8:      	ldp	x9, x10, [x8, #0x10]
    66dc:      	mov	w1, #0x2d               // =45
    66e0:      	stp	x9, x10, [sp, #0x40]
    66e4:      	ldr	x9, [x8, #0x20]
    66e8:      	add	x10, sp, #0x30
    66ec:      	str	x9, [sp, #0x50]
    66f0:      	ldur	x9, [x8, #0x25]
    66f4:      	stur	x9, [sp, #0x55]
    66f8:      	ldp	x9, x8, [x8]
    66fc:      	stp	x9, x8, [sp, #0x30]
    6700:      	mov	w8, #0x2d               // =45
    6704:      	mov	w9, #0x6                // =6
    6708:      	blr	x9
    670c:      	b	0x4fc4 <perf_unwind_perl+0x4fc4>
    6710:      	ldr	w8, [x23]
    6714:      	cbz	w8, 0x5c78 <perf_unwind_perl+0x5c78>
    6718:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    671c:      	add	x8, x8, #0x0
    6720:      	add	x0, sp, #0x30
    6724:      	ldp	x9, x10, [x8, #0x10]
    6728:      	mov	w1, #0x26               // =38
    672c:      	stp	x9, x10, [sp, #0x40]
    6730:      	ldur	x9, [x8, #0x1e]
    6734:      	add	x10, sp, #0x30
    6738:      	stur	x9, [sp, #0x4e]
    673c:      	ldp	x8, x9, [x8]
    6740:      	stp	x8, x9, [sp, #0x30]
    6744:      	mov	w8, #0x26               // =38
    6748:      	mov	w9, #0x6                // =6
    674c:      	ldr	w2, [sp, #0x94]
    6750:      	blr	x9
    6754:      	b	0x5c78 <perf_unwind_perl+0x5c78>
    6758:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    675c:      	add	x8, x8, #0x0
    6760:      	add	x0, sp, #0x30
    6764:      	ldp	x9, x10, [x8, #0x10]
    6768:      	mov	w1, #0x28               // =40
    676c:      	mov	x3, x24
    6770:      	stp	x9, x10, [sp, #0x40]
    6774:      	ldr	x9, [x8, #0x20]
    6778:      	add	x10, sp, #0x30
    677c:      	str	x9, [sp, #0x50]
    6780:      	ldp	x8, x9, [x8]
    6784:      	stp	x8, x9, [sp, #0x30]
    6788:      	mov	w8, #0x28               // =40
    678c:      	mov	w9, #0x6                // =6
    6790:      	ldr	x2, [sp, #0x8]
    6794:      	blr	x9
    6798:      	ldr	w8, [x21, #0x2c0]
    679c:      	cmp	w8, #0x7e
    67a0:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    67a4:      	b	0x4410 <perf_unwind_perl+0x4410>
    67a8:      	add	x8, sp, #0x98
    67ac:      	ldr	x24, [x8]
    67b0:      	cbz	x24, 0x45c4 <perf_unwind_perl+0x45c4>
    67b4:      	ldr	x8, [sp, #0x10]
    67b8:      	ldr	x8, [x8]
    67bc:      	str	x8, [sp, #0x8]
    67c0:      	ldr	w8, [x23]
    67c4:      	cbnz	w8, 0x6c38 <perf_unwind_perl+0x6c38>
    67c8:      	ldr	w8, [x21, #0x2c0]
    67cc:      	cmp	w8, #0x7e
    67d0:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    67d4:      	add	w9, w8, #0x1
    67d8:      	ldr	x10, [sp, #0x8]
    67dc:      	str	w9, [x21, #0x2c0]
    67e0:      	mov	w9, #0x18               // =24
    67e4:      	umaddl	x8, w8, w9, x21
    67e8:      	add	x9, x8, #0x2d0
    67ec:      	str	x10, [x8, #0x2d8]
    67f0:      	mov	w10, #0x7               // =7
    67f4:      	str	x24, [x8, #0x2d0]
    67f8:      	str	wzr, [x8, #0x2e4]
    67fc:      	str	xzr, [x21, #0xf30]
    6800:      	strb	w10, [x8, #0x2e0]
    6804:      	stur	wzr, [x9, #0x11]
    6808:      	b	0x4e8c <perf_unwind_perl+0x4e8c>
    680c:      	mov	w8, #0x786c             // =30828
    6810:      	add	x10, sp, #0x30
    6814:      	add	x0, sp, #0x30
    6818:      	mov	w1, #0x14               // =20
    681c:      	movk	w8, #0xa, lsl #16
    6820:      	str	w8, [sp, #0x40]
    6824:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6828:      	add	x8, x8, #0x0
    682c:      	ldp	x9, x8, [x8]
    6830:      	stp	x9, x8, [sp, #0x30]
    6834:      	mov	w8, #0x14               // =20
    6838:      	mov	w9, #0x6                // =6
    683c:      	ldr	x2, [sp, #0x80]
    6840:      	blr	x9
    6844:      	add	x8, sp, #0x80
    6848:      	ldr	x8, [x8]
    684c:      	ldr	x24, [sp, #0x10]
    6850:      	str	x8, [sp, #0x8]
    6854:      	cbnz	x8, 0x43f8 <perf_unwind_perl+0x43f8>
    6858:      	b	0x2100 <perf_unwind_perl+0x2100>
    685c:      	mov	w8, #0x786c             // =30828
    6860:      	add	x10, sp, #0x30
    6864:      	add	x0, sp, #0x30
    6868:      	mov	w1, #0x13               // =19
    686c:      	movk	w8, #0xa, lsl #16
    6870:      	stur	w8, [sp, #0x3f]
    6874:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6878:      	add	x8, x8, #0x0
    687c:      	ldp	x9, x8, [x8]
    6880:      	stp	x9, x8, [sp, #0x30]
    6884:      	mov	w8, #0x13               // =19
    6888:      	mov	w9, #0x6                // =6
    688c:      	ldr	x2, [sp, #0x98]
    6890:      	blr	x9
    6894:      	ldr	x8, [sp, #0x98]
    6898:      	b	0x397c <perf_unwind_perl+0x397c>
    689c:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    68a0:      	add	x8, x8, #0x0
    68a4:      	add	x0, sp, #0x30
    68a8:      	ldp	x9, x10, [x8, #0x10]
    68ac:      	mov	w1, #0x2d               // =45
    68b0:      	stp	x9, x10, [sp, #0x40]
    68b4:      	ldr	x9, [x8, #0x20]
    68b8:      	add	x10, sp, #0x30
    68bc:      	str	x9, [sp, #0x50]
    68c0:      	ldur	x9, [x8, #0x25]
    68c4:      	stur	x9, [sp, #0x55]
    68c8:      	ldp	x9, x8, [x8]
    68cc:      	stp	x9, x8, [sp, #0x30]
    68d0:      	mov	w8, #0x2d               // =45
    68d4:      	mov	w9, #0x6                // =6
    68d8:      	blr	x9
    68dc:      	b	0x5e00 <perf_unwind_perl+0x5e00>
    68e0:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    68e4:      	add	x8, x8, #0x0
    68e8:      	add	x0, sp, #0x30
    68ec:      	ldp	x9, x10, [x8, #0x10]
    68f0:      	mov	w1, #0x28               // =40
    68f4:      	mov	x3, x24
    68f8:      	stp	x9, x10, [sp, #0x40]
    68fc:      	ldr	x9, [x8, #0x20]
    6900:      	add	x10, sp, #0x30
    6904:      	str	x9, [sp, #0x50]
    6908:      	ldp	x8, x9, [x8]
    690c:      	stp	x8, x9, [sp, #0x30]
    6910:      	mov	w8, #0x28               // =40
    6914:      	mov	w9, #0x6                // =6
    6918:      	ldr	x2, [sp, #0x8]
    691c:      	blr	x9
    6920:      	ldr	w8, [x21, #0x2c0]
    6924:      	cmp	w8, #0x7e
    6928:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    692c:      	b	0x4bfc <perf_unwind_perl+0x4bfc>
    6930:      	add	x8, sp, #0x98
    6934:      	ldr	x24, [x8]
    6938:      	cbz	x24, 0x4e3c <perf_unwind_perl+0x4e3c>
    693c:      	ldr	x8, [sp, #0x10]
    6940:      	ldr	x8, [x8]
    6944:      	str	x8, [sp, #0x8]
    6948:      	ldr	w8, [x23]
    694c:      	cbnz	w8, 0x6c88 <perf_unwind_perl+0x6c88>
    6950:      	ldr	w8, [x21, #0x2c0]
    6954:      	cmp	w8, #0x7e
    6958:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    695c:      	add	w9, w8, #0x1
    6960:      	ldr	x10, [sp, #0x8]
    6964:      	str	w9, [x21, #0x2c0]
    6968:      	mov	w9, #0x18               // =24
    696c:      	umaddl	x8, w8, w9, x21
    6970:      	add	x9, x8, #0x2d0
    6974:      	str	x10, [x8, #0x2d8]
    6978:      	mov	w10, #0x7               // =7
    697c:      	str	x24, [x8, #0x2d0]
    6980:      	str	wzr, [x8, #0x2e4]
    6984:      	str	xzr, [x21, #0xf30]
    6988:      	strb	w10, [x8, #0x2e0]
    698c:      	stur	wzr, [x9, #0x11]
    6990:      	b	0x5cc8 <perf_unwind_perl+0x5cc8>
    6994:      	mov	w8, #0x786c             // =30828
    6998:      	add	x10, sp, #0x30
    699c:      	add	x0, sp, #0x30
    69a0:      	mov	w1, #0x14               // =20
    69a4:      	movk	w8, #0xa, lsl #16
    69a8:      	str	w8, [sp, #0x40]
    69ac:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    69b0:      	add	x8, x8, #0x0
    69b4:      	ldp	x9, x8, [x8]
    69b8:      	stp	x9, x8, [sp, #0x30]
    69bc:      	mov	w8, #0x14               // =20
    69c0:      	mov	w9, #0x6                // =6
    69c4:      	ldr	x2, [sp, #0x80]
    69c8:      	blr	x9
    69cc:      	add	x8, sp, #0x80
    69d0:      	ldr	x8, [x8]
    69d4:      	ldr	x24, [sp, #0x10]
    69d8:      	str	x8, [sp, #0x8]
    69dc:      	cbnz	x8, 0x4be4 <perf_unwind_perl+0x4be4>
    69e0:      	b	0x27f8 <perf_unwind_perl+0x27f8>
    69e4:      	mov	w8, #0x786c             // =30828
    69e8:      	add	x10, sp, #0x30
    69ec:      	add	x0, sp, #0x30
    69f0:      	mov	w1, #0x13               // =19
    69f4:      	movk	w8, #0xa, lsl #16
    69f8:      	stur	w8, [sp, #0x3f]
    69fc:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6a00:      	add	x8, x8, #0x0
    6a04:      	ldp	x9, x8, [x8]
    6a08:      	stp	x9, x8, [sp, #0x30]
    6a0c:      	mov	w8, #0x13               // =19
    6a10:      	mov	w9, #0x6                // =6
    6a14:      	ldr	x2, [sp, #0x98]
    6a18:      	blr	x9
    6a1c:      	ldr	x8, [sp, #0x98]
    6a20:      	b	0x4124 <perf_unwind_perl+0x4124>
    6a24:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6a28:      	add	x8, x8, #0x0
    6a2c:      	add	x0, sp, #0x30
    6a30:      	ldp	x9, x10, [x8, #0x10]
    6a34:      	mov	w1, #0x28               // =40
    6a38:      	mov	x2, x24
    6a3c:      	stp	x9, x10, [sp, #0x40]
    6a40:      	ldr	x9, [x8, #0x20]
    6a44:      	add	x10, sp, #0x30
    6a48:      	str	x9, [sp, #0x50]
    6a4c:      	ldp	x8, x9, [x8]
    6a50:      	stp	x8, x9, [sp, #0x30]
    6a54:      	mov	w8, #0x28               // =40
    6a58:      	mov	w9, #0x6                // =6
    6a5c:      	ldr	x3, [sp, #0x8]
    6a60:      	blr	x9
    6a64:      	ldr	w8, [x21, #0x2c0]
    6a68:      	cmp	w8, #0x7e
    6a6c:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    6a70:      	b	0x5488 <perf_unwind_perl+0x5488>
    6a74:      	add	x8, sp, #0x98
    6a78:      	ldr	x24, [x8]
    6a7c:      	cbz	x24, 0x5c78 <perf_unwind_perl+0x5c78>
    6a80:      	ldr	x8, [sp, #0x10]
    6a84:      	ldr	x8, [x8]
    6a88:      	str	x8, [sp, #0x8]
    6a8c:      	ldr	w8, [x23]
    6a90:      	cbnz	w8, 0x6cd8 <perf_unwind_perl+0x6cd8>
    6a94:      	ldr	w8, [x21, #0x2c0]
    6a98:      	cmp	w8, #0x7e
    6a9c:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    6aa0:      	add	w9, w8, #0x1
    6aa4:      	ldr	x10, [sp, #0x8]
    6aa8:      	str	w9, [x21, #0x2c0]
    6aac:      	mov	w9, #0x18               // =24
    6ab0:      	umaddl	x8, w8, w9, x21
    6ab4:      	add	x9, x8, #0x2d0
    6ab8:      	str	x10, [x8, #0x2d8]
    6abc:      	mov	w10, #0x7               // =7
    6ac0:      	str	x24, [x8, #0x2d0]
    6ac4:      	str	wzr, [x8, #0x2e4]
    6ac8:      	str	xzr, [x21, #0xf30]
    6acc:      	strb	w10, [x8, #0x2e0]
    6ad0:      	stur	wzr, [x9, #0x11]
    6ad4:      	b	0x6488 <perf_unwind_perl+0x6488>
    6ad8:      	mov	w8, #0x786c             // =30828
    6adc:      	add	x10, sp, #0x30
    6ae0:      	add	x0, sp, #0x30
    6ae4:      	mov	w1, #0x13               // =19
    6ae8:      	movk	w8, #0xa, lsl #16
    6aec:      	stur	w8, [sp, #0x3f]
    6af0:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6af4:      	add	x8, x8, #0x0
    6af8:      	ldp	x9, x8, [x8]
    6afc:      	stp	x9, x8, [sp, #0x30]
    6b00:      	mov	w8, #0x13               // =19
    6b04:      	mov	w9, #0x6                // =6
    6b08:      	ldr	x2, [sp, #0x98]
    6b0c:      	blr	x9
    6b10:      	ldr	x8, [sp, #0x98]
    6b14:      	b	0x488c <perf_unwind_perl+0x488c>
    6b18:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6b1c:      	add	x8, x8, #0x0
    6b20:      	add	x0, sp, #0x30
    6b24:      	ldp	x9, x10, [x8, #0x10]
    6b28:      	mov	w1, #0x28               // =40
    6b2c:      	mov	x2, x24
    6b30:      	stp	x9, x10, [sp, #0x40]
    6b34:      	ldr	x9, [x8, #0x20]
    6b38:      	add	x10, sp, #0x30
    6b3c:      	str	x9, [sp, #0x50]
    6b40:      	ldp	x8, x9, [x8]
    6b44:      	stp	x8, x9, [sp, #0x30]
    6b48:      	mov	w8, #0x28               // =40
    6b4c:      	mov	w9, #0x6                // =6
    6b50:      	ldr	x3, [sp, #0x8]
    6b54:      	blr	x9
    6b58:      	ldr	w8, [x21, #0x2c0]
    6b5c:      	cmp	w8, #0x7e
    6b60:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    6b64:      	b	0x627c <perf_unwind_perl+0x627c>
    6b68:      	mov	w8, #0x786c             // =30828
    6b6c:      	add	x10, sp, #0x30
    6b70:      	add	x0, sp, #0x30
    6b74:      	mov	w1, #0x13               // =19
    6b78:      	movk	w8, #0xa, lsl #16
    6b7c:      	stur	w8, [sp, #0x3f]
    6b80:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6b84:      	add	x8, x8, #0x0
    6b88:      	ldp	x9, x8, [x8]
    6b8c:      	stp	x9, x8, [sp, #0x30]
    6b90:      	mov	w8, #0x13               // =19
    6b94:      	mov	w9, #0x6                // =6
    6b98:      	ldr	x2, [sp, #0x98]
    6b9c:      	blr	x9
    6ba0:      	ldr	x8, [sp, #0x98]
    6ba4:      	b	0x5104 <perf_unwind_perl+0x5104>
    6ba8:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6bac:      	add	x8, x8, #0x0
    6bb0:      	add	x0, sp, #0x30
    6bb4:      	ldp	x9, x10, [x8, #0x10]
    6bb8:      	mov	w1, #0x28               // =40
    6bbc:      	mov	x2, x24
    6bc0:      	stp	x9, x10, [sp, #0x40]
    6bc4:      	ldr	x9, [x8, #0x20]
    6bc8:      	add	x10, sp, #0x30
    6bcc:      	str	x9, [sp, #0x50]
    6bd0:      	ldp	x8, x9, [x8]
    6bd4:      	stp	x8, x9, [sp, #0x30]
    6bd8:      	mov	w8, #0x28               // =40
    6bdc:      	mov	w9, #0x6                // =6
    6be0:      	ldr	x3, [sp, #0x8]
    6be4:      	blr	x9
    6be8:      	ldr	w8, [x21, #0x2c0]
    6bec:      	cmp	w8, #0x7e
    6bf0:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    6bf4:      	b	0x6604 <perf_unwind_perl+0x6604>
    6bf8:      	mov	w8, #0x786c             // =30828
    6bfc:      	add	x10, sp, #0x30
    6c00:      	add	x0, sp, #0x30
    6c04:      	mov	w1, #0x13               // =19
    6c08:      	movk	w8, #0xa, lsl #16
    6c0c:      	stur	w8, [sp, #0x3f]
    6c10:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6c14:      	add	x8, x8, #0x0
    6c18:      	ldp	x9, x8, [x8]
    6c1c:      	stp	x9, x8, [sp, #0x30]
    6c20:      	mov	w8, #0x13               // =19
    6c24:      	mov	w9, #0x6                // =6
    6c28:      	ldr	x2, [sp, #0x98]
    6c2c:      	blr	x9
    6c30:      	ldr	x8, [sp, #0x98]
    6c34:      	b	0x5f40 <perf_unwind_perl+0x5f40>
    6c38:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6c3c:      	add	x8, x8, #0x0
    6c40:      	add	x0, sp, #0x30
    6c44:      	ldp	x9, x10, [x8, #0x10]
    6c48:      	mov	w1, #0x28               // =40
    6c4c:      	mov	x2, x24
    6c50:      	stp	x9, x10, [sp, #0x40]
    6c54:      	ldr	x9, [x8, #0x20]
    6c58:      	add	x10, sp, #0x30
    6c5c:      	str	x9, [sp, #0x50]
    6c60:      	ldp	x8, x9, [x8]
    6c64:      	stp	x8, x9, [sp, #0x30]
    6c68:      	mov	w8, #0x28               // =40
    6c6c:      	mov	w9, #0x6                // =6
    6c70:      	ldr	x3, [sp, #0x8]
    6c74:      	blr	x9
    6c78:      	ldr	w8, [x21, #0x2c0]
    6c7c:      	cmp	w8, #0x7e
    6c80:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    6c84:      	b	0x67d4 <perf_unwind_perl+0x67d4>
    6c88:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6c8c:      	add	x8, x8, #0x0
    6c90:      	add	x0, sp, #0x30
    6c94:      	ldp	x9, x10, [x8, #0x10]
    6c98:      	mov	w1, #0x28               // =40
    6c9c:      	mov	x2, x24
    6ca0:      	stp	x9, x10, [sp, #0x40]
    6ca4:      	ldr	x9, [x8, #0x20]
    6ca8:      	add	x10, sp, #0x30
    6cac:      	str	x9, [sp, #0x50]
    6cb0:      	ldp	x8, x9, [x8]
    6cb4:      	stp	x8, x9, [sp, #0x30]
    6cb8:      	mov	w8, #0x28               // =40
    6cbc:      	mov	w9, #0x6                // =6
    6cc0:      	ldr	x3, [sp, #0x8]
    6cc4:      	blr	x9
    6cc8:      	ldr	w8, [x21, #0x2c0]
    6ccc:      	cmp	w8, #0x7e
    6cd0:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    6cd4:      	b	0x695c <perf_unwind_perl+0x695c>
    6cd8:      	adrp	x8, 0x6000 <perf_unwind_perl+0x6000>
    6cdc:      	add	x8, x8, #0x0
    6ce0:      	add	x0, sp, #0x30
    6ce4:      	ldp	x9, x10, [x8, #0x10]
    6ce8:      	mov	w1, #0x28               // =40
    6cec:      	mov	x2, x24
    6cf0:      	stp	x9, x10, [sp, #0x40]
    6cf4:      	ldr	x9, [x8, #0x20]
    6cf8:      	add	x10, sp, #0x30
    6cfc:      	str	x9, [sp, #0x50]
    6d00:      	ldp	x8, x9, [x8]
    6d04:      	stp	x8, x9, [sp, #0x30]
    6d08:      	mov	w8, #0x28               // =40
    6d0c:      	mov	w9, #0x6                // =6
    6d10:      	ldr	x3, [sp, #0x8]
    6d14:      	blr	x9
    6d18:      	ldr	w8, [x21, #0x2c0]
    6d1c:      	cmp	w8, #0x7e
    6d20:      	b.hi	0x2680 <perf_unwind_perl+0x2680>
    6d24:      	b	0x6aa0 <perf_unwind_perl+0x6aa0>

Disassembly of section kprobe/unwind_perl:

0000000000000000 <kprobe_unwind_perl>:
       0:      	sub	sp, sp, #0x100
       4:      	str	x29, [sp, #0xb0]
       8:      	stp	x30, x25, [sp, #0xc0]
       c:      	stp	x24, x23, [sp, #0xd0]
      10:      	stp	x22, x21, [sp, #0xe0]
      14:      	stp	x20, x19, [sp, #0xf0]
      18:      	str	wzr, [sp, #0x30]
      1c:      	adrp	x20, 0x0 <kprobe_unwind_perl>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x30
      28:      	ldr	x20, [x20]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0x30
      34:      	mov	x0, x20
      38:      	blr	x8
      3c:      	cbz	x0, 0x58e0 <kprobe_unwind_perl+0x58e0>
      40:      	ldr	w8, [x0]
      44:      	adrp	x23, 0x0 <kprobe_unwind_perl>
      48:      	mov	x21, x0
      4c:      	str	w8, [sp, #0x2c]
      50:      	ldr	x23, [x23]
      54:      	ldr	w8, [x23]
      58:      	cbnz	w8, 0x49c <kprobe_unwind_perl+0x49c>
      5c:      	adrp	x0, 0x0 <kprobe_unwind_perl>
      60:      	mov	w8, #0x1                // =1
      64:      	add	x9, sp, #0x2c
      68:      	ldr	x0, [x0]
      6c:      	add	x1, sp, #0x2c
      70:      	blr	x8
      74:      	ldr	w8, [x23]
      78:      	cbz	x0, 0xb4 <kprobe_unwind_perl+0xb4>
      7c:      	mov	x22, x0
      80:      	cbnz	w8, 0x4d0 <kprobe_unwind_perl+0x4d0>
      84:      	ldr	x8, [x21, #0xf28]
      88:      	add	x29, x21, #0xf28
      8c:      	cbz	x8, 0x518 <kprobe_unwind_perl+0x518>
      90:      	str	x8, [sp, #0x68]
      94:      	ldr	x9, [x21, #0xf38]
      98:      	ldr	x25, [x21, #0xf40]
      9c:      	add	x24, x21, #0xf30
      a0:      	cmp	x25, x9
      a4:      	str	x29, [sp, #0x20]
      a8:      	b.hs	0xc0 <kprobe_unwind_perl+0xc0>
      ac:      	mov	w29, #0x3               // =3
      b0:      	b	0x563c <kprobe_unwind_perl+0x563c>
      b4:      	cbnz	w8, 0xa14 <kprobe_unwind_perl+0xa14>
      b8:      	mov	w0, wzr
      bc:      	b	0x58e4 <kprobe_unwind_perl+0x58e4>
      c0:      	ldrb	w8, [x22, #0x19]
      c4:      	str	x9, [sp, #0x18]
      c8:      	mov	w9, #0x1                // =1
      cc:      	mov	w10, #0x70              // =112
      d0:      	add	x11, sp, #0x7c
      d4:      	add	x0, sp, #0x7c
      d8:      	mov	w1, #0x1                // =1
      dc:      	add	x8, x25, x8
      e0:      	ldrb	w8, [x22, #0x19]
      e4:      	add	x2, x25, x8
      e8:      	blr	x10
      ec:      	cbz	x0, 0x12c <kprobe_unwind_perl+0x12c>
      f0:      	ldr	w8, [x23]
      f4:      	cbnz	w8, 0xa58 <kprobe_unwind_perl+0xa58>
      f8:      	mov	w8, #0x13               // =19
      fc:      	adrp	x0, 0x0 <kprobe_unwind_perl>
     100:      	add	x9, sp, #0xa8
     104:      	str	w8, [sp, #0xa8]
     108:      	mov	w8, #0x1                // =1
     10c:      	add	x1, sp, #0xa8
     110:      	ldr	x0, [x0]
     114:      	blr	x8
     118:      	cbz	x0, 0x22c <kprobe_unwind_perl+0x22c>
     11c:      	ldr	x8, [x0]
     120:      	add	x8, x8, #0x1
     124:      	str	x8, [x0]
     128:      	b	0xc40 <kprobe_unwind_perl+0xc40>
     12c:      	ldr	w8, [x23]
     130:      	cbnz	w8, 0xbf0 <kprobe_unwind_perl+0xbf0>
     134:      	ldrb	w8, [sp, #0x7c]
     138:      	and	w9, w8, #0xf
     13c:      	sub	w10, w9, #0x9
     140:      	cmp	w10, #0x2
     144:      	b.hs	0xc38 <kprobe_unwind_perl+0xc38>
     148:      	sxtb	w8, w8
     14c:      	tbnz	w8, #0x1f, 0xc40 <kprobe_unwind_perl+0xc40>
     150:      	ldrb	w8, [x22, #0x1b]
     154:      	mov	w9, #0x8                // =8
     158:      	mov	w10, #0x70              // =112
     15c:      	add	x11, sp, #0x30
     160:      	add	x0, sp, #0x30
     164:      	mov	w1, #0x8                // =8
     168:      	add	x8, x25, x8
     16c:      	ldrb	w8, [x22, #0x1b]
     170:      	add	x2, x25, x8
     174:      	blr	x10
     178:      	cbnz	x0, 0xf0 <kprobe_unwind_perl+0xf0>
     17c:      	ldr	x8, [sp, #0x30]
     180:      	mov	w9, #0x8                // =8
     184:      	mov	w10, #0x70              // =112
     188:      	add	x11, sp, #0x70
     18c:      	add	x0, sp, #0x70
     190:      	mov	w1, #0x8                // =8
     194:      	cmp	x8, #0x0
     198:      	mov	w8, #0x3                // =3
     19c:      	csinc	w29, w8, wzr, ne
     1a0:      	ldrb	w8, [x22, #0x1c]
     1a4:      	add	x8, x25, x8
     1a8:      	ldrb	w8, [x22, #0x1c]
     1ac:      	add	x2, x25, x8
     1b0:      	blr	x10
     1b4:      	cbnz	x0, 0xf0 <kprobe_unwind_perl+0xf0>
     1b8:      	str	x24, [sp, #0x10]
     1bc:      	ldr	x24, [sp, #0x70]
     1c0:      	mov	w9, #0x4                // =4
     1c4:      	mov	w10, #0x70              // =112
     1c8:      	add	x11, sp, #0xb8
     1cc:      	add	x0, sp, #0xb8
     1d0:      	ldrb	w8, [x22, #0x1e]
     1d4:      	mov	w1, #0x4                // =4
     1d8:      	add	x8, x24, x8
     1dc:      	ldrb	w8, [x22, #0x1e]
     1e0:      	add	x2, x24, x8
     1e4:      	blr	x10
     1e8:      	cbz	x0, 0x27c <kprobe_unwind_perl+0x27c>
     1ec:      	ldr	w8, [x23]
     1f0:      	cbnz	w8, 0x1eac <kprobe_unwind_perl+0x1eac>
     1f4:      	mov	w8, #0x14               // =20
     1f8:      	adrp	x0, 0x0 <kprobe_unwind_perl>
     1fc:      	add	x9, sp, #0xbc
     200:      	str	w8, [sp, #0xbc]
     204:      	mov	w8, #0x1                // =1
     208:      	add	x1, sp, #0xbc
     20c:      	ldr	x0, [x0]
     210:      	blr	x8
     214:      	ldr	x24, [sp, #0x10]
     218:      	cbz	x0, 0x404 <kprobe_unwind_perl+0x404>
     21c:      	ldr	x8, [x0]
     220:      	add	x8, x8, #0x1
     224:      	str	x8, [x0]
     228:      	b	0xf0 <kprobe_unwind_perl+0xf0>
     22c:      	ldr	w8, [x23]
     230:      	cbz	w8, 0xc40 <kprobe_unwind_perl+0xc40>
     234:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     238:      	add	x8, x8, #0x0
     23c:      	add	x0, sp, #0x30
     240:      	ldp	x9, x10, [x8, #0x10]
     244:      	mov	w1, #0x2e               // =46
     248:      	stp	x9, x10, [sp, #0x40]
     24c:      	ldr	x9, [x8, #0x20]
     250:      	add	x10, sp, #0x30
     254:      	str	x9, [sp, #0x50]
     258:      	ldur	x9, [x8, #0x26]
     25c:      	stur	x9, [sp, #0x56]
     260:      	ldp	x9, x8, [x8]
     264:      	stp	x9, x8, [sp, #0x30]
     268:      	mov	w8, #0x2e               // =46
     26c:      	mov	w9, #0x6                // =6
     270:      	ldr	w2, [sp, #0xa8]
     274:      	blr	x9
     278:      	b	0xc40 <kprobe_unwind_perl+0xc40>
     27c:      	ldr	w8, [sp, #0xb8]
     280:      	and	w8, w8, #0x1f
     284:      	cmp	w8, #0xd
     288:      	b.ne	0x450 <kprobe_unwind_perl+0x450>
     28c:      	ldrb	w8, [x22, #0x1f]
     290:      	mov	w9, #0x8                // =8
     294:      	mov	w10, #0x70              // =112
     298:      	add	x11, sp, #0xa8
     29c:      	add	x0, sp, #0xa8
     2a0:      	mov	w1, #0x8                // =8
     2a4:      	add	x8, x24, x8
     2a8:      	ldrb	w8, [x22, #0x1f]
     2ac:      	add	x2, x24, x8
     2b0:      	blr	x10
     2b4:      	cbnz	x0, 0x1ec <kprobe_unwind_perl+0x1ec>
     2b8:      	ldr	x8, [sp, #0xa8]
     2bc:      	ldrb	w9, [x22, #0x21]
     2c0:      	mov	w10, #0x70              // =112
     2c4:      	add	x11, sp, #0xa4
     2c8:      	add	x0, sp, #0xa4
     2cc:      	mov	w1, #0x4                // =4
     2d0:      	add	x8, x8, x9
     2d4:      	mov	w9, #0x4                // =4
     2d8:      	ldr	x8, [sp, #0xa8]
     2dc:      	ldrb	w9, [x22, #0x21]
     2e0:      	add	x2, x8, x9
     2e4:      	blr	x10
     2e8:      	cbnz	x0, 0x1ec <kprobe_unwind_perl+0x1ec>
     2ec:      	ldrb	w8, [sp, #0xa5]
     2f0:      	tbnz	w8, #0x7, 0xb64 <kprobe_unwind_perl+0xb64>
     2f4:      	ldr	x8, [sp, #0xa8]
     2f8:      	ldrb	w9, [x22, #0x22]
     2fc:      	mov	w10, #0x70              // =112
     300:      	add	x11, sp, #0x98
     304:      	add	x0, sp, #0x98
     308:      	mov	w1, #0x8                // =8
     30c:      	add	x8, x8, x9
     310:      	mov	w9, #0x8                // =8
     314:      	ldr	x8, [sp, #0xa8]
     318:      	ldrb	w9, [x22, #0x22]
     31c:      	add	x2, x8, x9
     320:      	blr	x10
     324:      	cbnz	x0, 0x1ec <kprobe_unwind_perl+0x1ec>
     328:      	ldr	x8, [sp, #0x98]
     32c:      	cbz	x8, 0x1ec <kprobe_unwind_perl+0x1ec>
     330:      	ldr	w9, [x23]
     334:      	cbnz	w9, 0x3538 <kprobe_unwind_perl+0x3538>
     338:      	ldrb	w9, [x22, #0x1e]
     33c:      	mov	w10, #0x70              // =112
     340:      	add	x11, sp, #0x94
     344:      	add	x0, sp, #0x94
     348:      	mov	w1, #0x4                // =4
     34c:      	add	x8, x8, x9
     350:      	mov	w9, #0x4                // =4
     354:      	ldr	x8, [sp, #0x98]
     358:      	ldrb	w9, [x22, #0x1e]
     35c:      	add	x2, x8, x9
     360:      	blr	x10
     364:      	cbnz	x0, 0x1ec <kprobe_unwind_perl+0x1ec>
     368:      	ldr	w8, [sp, #0x94]
     36c:      	mov	w9, #0x801f             // =32799
     370:      	and	w8, w8, w9
     374:      	mov	w9, #0x8009             // =32777
     378:      	cmp	w8, w9
     37c:      	b.ne	0x18ac <kprobe_unwind_perl+0x18ac>
     380:      	ldr	x8, [sp, #0x98]
     384:      	ldrb	w9, [x22, #0x20]
     388:      	mov	w10, #0x70              // =112
     38c:      	add	x11, sp, #0x88
     390:      	add	x0, sp, #0x88
     394:      	mov	w1, #0x8                // =8
     398:      	add	x8, x8, x9
     39c:      	mov	w9, #0x8                // =8
     3a0:      	ldr	x8, [sp, #0x98]
     3a4:      	ldrb	w9, [x22, #0x20]
     3a8:      	add	x2, x8, x9
     3ac:      	blr	x10
     3b0:      	cbnz	x0, 0x1ec <kprobe_unwind_perl+0x1ec>
     3b4:      	ldr	x8, [sp, #0x88]
     3b8:      	ldrb	w9, [x22, #0x23]
     3bc:      	mov	w10, #0x70              // =112
     3c0:      	add	x11, sp, #0x80
     3c4:      	add	x0, sp, #0x80
     3c8:      	mov	w1, #0x8                // =8
     3cc:      	add	x8, x8, x9
     3d0:      	mov	w9, #0x8                // =8
     3d4:      	ldr	x8, [sp, #0x88]
     3d8:      	ldrb	w9, [x22, #0x23]
     3dc:      	add	x2, x8, x9
     3e0:      	blr	x10
     3e4:      	cbnz	x0, 0x1ec <kprobe_unwind_perl+0x1ec>
     3e8:      	ldr	x8, [sp, #0x80]
     3ec:      	str	x8, [sp, #0x8]
     3f0:      	cbz	x8, 0x2654 <kprobe_unwind_perl+0x2654>
     3f4:      	ldr	w8, [x23]
     3f8:      	cbnz	w8, 0x4c34 <kprobe_unwind_perl+0x4c34>
     3fc:      	ldr	x24, [sp, #0x10]
     400:      	b	0x2668 <kprobe_unwind_perl+0x2668>
     404:      	ldr	w8, [x23]
     408:      	cbz	w8, 0xf0 <kprobe_unwind_perl+0xf0>
     40c:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     410:      	add	x8, x8, #0x0
     414:      	add	x0, sp, #0x30
     418:      	ldp	x9, x10, [x8, #0x10]
     41c:      	mov	w1, #0x2e               // =46
     420:      	stp	x9, x10, [sp, #0x40]
     424:      	ldr	x9, [x8, #0x20]
     428:      	add	x10, sp, #0x30
     42c:      	str	x9, [sp, #0x50]
     430:      	ldur	x9, [x8, #0x26]
     434:      	stur	x9, [sp, #0x56]
     438:      	ldp	x9, x8, [x8]
     43c:      	stp	x9, x8, [sp, #0x30]
     440:      	mov	w8, #0x2e               // =46
     444:      	mov	w9, #0x6                // =6
     448:      	ldr	w2, [sp, #0xbc]
     44c:      	b	0x494 <kprobe_unwind_perl+0x494>
     450:      	ldr	w8, [x23]
     454:      	ldr	x24, [sp, #0x10]
     458:      	cbz	w8, 0xf0 <kprobe_unwind_perl+0xf0>
     45c:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     460:      	add	x8, x8, #0x0
     464:      	add	x0, sp, #0x30
     468:      	ldp	x9, x10, [x8]
     46c:      	mov	w1, #0x1e               // =30
     470:      	stp	x9, x10, [sp, #0x30]
     474:      	ldr	x9, [x8, #0x10]
     478:      	ldur	x8, [x8, #0x16]
     47c:      	add	x10, sp, #0x30
     480:      	str	x9, [sp, #0x40]
     484:      	stur	x8, [sp, #0x46]
     488:      	mov	w8, #0x1e               // =30
     48c:      	mov	w9, #0x6                // =6
     490:      	ldr	w2, [sp, #0xb8]
     494:      	blr	x9
     498:      	b	0xf0 <kprobe_unwind_perl+0xf0>
     49c:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     4a0:      	add	x8, x8, #0x0
     4a4:      	add	x10, sp, #0x30
     4a8:      	ldr	x9, [x8]
     4ac:      	ldur	x8, [x8, #0x7]
     4b0:      	add	x0, sp, #0x30
     4b4:      	mov	w1, #0xf                // =15
     4b8:      	str	x9, [sp, #0x30]
     4bc:      	stur	x8, [sp, #0x37]
     4c0:      	mov	w8, #0xf                // =15
     4c4:      	mov	w9, #0x6                // =6
     4c8:      	blr	x9
     4cc:      	b	0x5c <kprobe_unwind_perl+0x5c>
     4d0:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     4d4:      	add	x8, x8, #0x0
     4d8:      	add	x0, sp, #0x30
     4dc:      	ldp	x9, x10, [x8]
     4e0:      	mov	w1, #0x1e               // =30
     4e4:      	stp	x9, x10, [sp, #0x30]
     4e8:      	ldr	x9, [x8, #0x10]
     4ec:      	ldur	x8, [x8, #0x16]
     4f0:      	add	x10, sp, #0x30
     4f4:      	str	x9, [sp, #0x40]
     4f8:      	stur	x8, [sp, #0x46]
     4fc:      	mov	w8, #0x1e               // =30
     500:      	mov	w9, #0x6                // =6
     504:      	ldr	w2, [x22, #0x8]
     508:      	blr	x9
     50c:      	ldr	x8, [x21, #0xf28]
     510:      	add	x29, x21, #0xf28
     514:      	cbnz	x8, 0x90 <kprobe_unwind_perl+0x90>
     518:      	mov	w8, #0xf                // =15
     51c:      	adrp	x24, 0x0 <kprobe_unwind_perl>
     520:      	add	x9, sp, #0xa8
     524:      	str	w8, [sp, #0xa8]
     528:      	mov	w8, #0x1                // =1
     52c:      	add	x1, sp, #0xa8
     530:      	ldr	x24, [x24]
     534:      	mov	x0, x24
     538:      	blr	x8
     53c:      	cbz	x0, 0x630 <kprobe_unwind_perl+0x630>
     540:      	ldr	x8, [x0]
     544:      	add	x8, x8, #0x1
     548:      	str	x8, [x0]
     54c:      	ldrb	w8, [x22, #0x14]
     550:      	cbnz	w8, 0x640 <kprobe_unwind_perl+0x640>
     554:      	ldr	x8, [x22]
     558:      	str	x8, [sp, #0x98]
     55c:      	ldr	w8, [x23]
     560:      	cbnz	w8, 0xaa0 <kprobe_unwind_perl+0xaa0>
     564:      	ldr	x8, [sp, #0x98]
     568:      	ldrh	w9, [x22, #0x12]
     56c:      	mov	w10, #0x70              // =112
     570:      	mov	x0, x29
     574:      	mov	w1, #0x8                // =8
     578:      	add	x8, x8, x9
     57c:      	mov	w9, #0x8                // =8
     580:      	ldr	x8, [sp, #0x98]
     584:      	ldrh	w9, [x22, #0x12]
     588:      	add	x2, x8, x9
     58c:      	blr	x10
     590:      	cbnz	x0, 0x5c8 <kprobe_unwind_perl+0x5c8>
     594:      	ldr	x8, [sp, #0x98]
     598:      	ldrh	w9, [x22, #0x10]
     59c:      	add	x25, x21, #0xf30
     5a0:      	mov	w10, #0x70              // =112
     5a4:      	mov	w1, #0x8                // =8
     5a8:      	mov	x0, x25
     5ac:      	add	x8, x8, x9
     5b0:      	mov	w9, #0x8                // =8
     5b4:      	ldr	x8, [sp, #0x98]
     5b8:      	ldrh	w9, [x22, #0x10]
     5bc:      	add	x2, x8, x9
     5c0:      	blr	x10
     5c4:      	cbz	x0, 0x854 <kprobe_unwind_perl+0x854>
     5c8:      	ldr	w8, [x23]
     5cc:      	cbnz	w8, 0xbb4 <kprobe_unwind_perl+0xbb4>
     5d0:      	mov	w8, #0x12               // =18
     5d4:      	add	x9, sp, #0xa8
     5d8:      	add	x1, sp, #0xa8
     5dc:      	str	w8, [sp, #0xa8]
     5e0:      	mov	w8, #0x1                // =1
     5e4:      	mov	x0, x24
     5e8:      	blr	x8
     5ec:      	cbnz	x0, 0x924 <kprobe_unwind_perl+0x924>
     5f0:      	ldr	w8, [x23]
     5f4:      	cbz	w8, 0x93c <kprobe_unwind_perl+0x93c>
     5f8:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     5fc:      	add	x8, x8, #0x0
     600:      	ldp	x9, x10, [x8, #0x10]
     604:      	stp	x9, x10, [sp, #0x40]
     608:      	ldr	x9, [x8, #0x20]
     60c:      	add	x10, sp, #0x30
     610:      	str	x9, [sp, #0x50]
     614:      	ldur	x9, [x8, #0x26]
     618:      	stur	x9, [sp, #0x56]
     61c:      	ldp	x9, x8, [x8]
     620:      	stp	x9, x8, [sp, #0x30]
     624:      	mov	w8, #0x2e               // =46
     628:      	mov	w9, #0x6                // =6
     62c:      	b	0x1184 <kprobe_unwind_perl+0x1184>
     630:      	ldr	w8, [x23]
     634:      	cbnz	w8, 0xb14 <kprobe_unwind_perl+0xb14>
     638:      	ldrb	w8, [x22, #0x14]
     63c:      	cbz	w8, 0x554 <kprobe_unwind_perl+0x554>
     640:      	mov	w8, #0x23               // =35
     644:      	blr	x8
     648:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     64c:      	mov	w9, #0x71               // =113
     650:      	add	x10, sp, #0x88
     654:      	ldr	x8, [x8]
     658:      	mov	w1, #0x8                // =8
     65c:      	ldr	x8, [x8]
     660:      	add	x2, x0, x8
     664:      	mov	w8, #0x8                // =8
     668:      	add	x0, sp, #0x88
     66c:      	blr	x9
     670:      	cbz	x0, 0x6e4 <kprobe_unwind_perl+0x6e4>
     674:      	ldr	w8, [x23]
     678:      	cbnz	w8, 0xad8 <kprobe_unwind_perl+0xad8>
     67c:      	mov	w8, #0x4                // =4
     680:      	add	x9, sp, #0xa8
     684:      	add	x1, sp, #0xa8
     688:      	str	w8, [sp, #0xa8]
     68c:      	mov	w8, #0x1                // =1
     690:      	mov	x0, x24
     694:      	blr	x8
     698:      	cbz	x0, 0x750 <kprobe_unwind_perl+0x750>
     69c:      	ldr	x8, [x0]
     6a0:      	add	x8, x8, #0x1
     6a4:      	str	x8, [x0]
     6a8:      	ldr	w8, [x23]
     6ac:      	cbz	w8, 0x904 <kprobe_unwind_perl+0x904>
     6b0:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     6b4:      	add	x8, x8, #0x0
     6b8:      	add	x0, sp, #0x30
     6bc:      	ldp	x9, x10, [x8]
     6c0:      	mov	w1, #0x20               // =32
     6c4:      	stp	x9, x10, [sp, #0x30]
     6c8:      	ldp	x9, x8, [x8, #0x10]
     6cc:      	add	x10, sp, #0x30
     6d0:      	stp	x9, x8, [sp, #0x40]
     6d4:      	mov	w8, #0x20               // =32
     6d8:      	mov	w9, #0x6                // =6
     6dc:      	blr	x9
     6e0:      	b	0x904 <kprobe_unwind_perl+0x904>
     6e4:      	ldr	x8, [x22]
     6e8:      	mov	w9, #0x4                // =4
     6ec:      	mov	w10, #0x70              // =112
     6f0:      	add	x11, sp, #0x28
     6f4:      	ldr	x2, [x22]
     6f8:      	add	x0, sp, #0x28
     6fc:      	mov	w1, #0x4                // =4
     700:      	blr	x10
     704:      	cbz	x0, 0x7a8 <kprobe_unwind_perl+0x7a8>
     708:      	ldr	w8, [x23]
     70c:      	cbz	w8, 0x904 <kprobe_unwind_perl+0x904>
     710:      	mov	w8, #0xa                // =10
     714:      	add	x0, sp, #0x30
     718:      	mov	w1, #0x22               // =34
     71c:      	strh	w8, [sp, #0x50]
     720:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     724:      	add	x8, x8, #0x0
     728:      	ldp	x9, x10, [x8]
     72c:      	stp	x9, x10, [sp, #0x30]
     730:      	ldp	x9, x8, [x8, #0x10]
     734:      	add	x10, sp, #0x30
     738:      	stp	x9, x8, [sp, #0x40]
     73c:      	mov	w8, #0x22               // =34
     740:      	mov	w9, #0x6                // =6
     744:      	ldr	x2, [x22]
     748:      	blr	x9
     74c:      	b	0x904 <kprobe_unwind_perl+0x904>
     750:      	ldr	w8, [x23]
     754:      	cbz	w8, 0x904 <kprobe_unwind_perl+0x904>
     758:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     75c:      	add	x8, x8, #0x0
     760:      	add	x0, sp, #0x30
     764:      	ldp	x9, x10, [x8, #0x10]
     768:      	mov	w1, #0x2e               // =46
     76c:      	stp	x9, x10, [sp, #0x40]
     770:      	ldr	x9, [x8, #0x20]
     774:      	add	x10, sp, #0x30
     778:      	str	x9, [sp, #0x50]
     77c:      	ldur	x9, [x8, #0x26]
     780:      	stur	x9, [sp, #0x56]
     784:      	ldp	x9, x8, [x8]
     788:      	stp	x9, x8, [sp, #0x30]
     78c:      	mov	w8, #0x2e               // =46
     790:      	mov	w9, #0x6                // =6
     794:      	ldr	w2, [sp, #0xa8]
     798:      	blr	x9
     79c:      	ldr	w8, [x23]
     7a0:      	cbz	w8, 0x904 <kprobe_unwind_perl+0x904>
     7a4:      	b	0x6b0 <kprobe_unwind_perl+0x6b0>
     7a8:      	ldr	x8, [sp, #0x88]
     7ac:      	ldrsh	x9, [x22, #0xc]
     7b0:      	add	x8, x8, x9
     7b4:      	ldrsw	x25, [sp, #0x28]
     7b8:      	ldrb	w9, [x22, #0xf]
     7bc:      	str	x8, [sp, #0xa8]
     7c0:      	cbz	w9, 0x7e8 <kprobe_unwind_perl+0x7e8>
     7c4:      	mov	w9, #0x8                // =8
     7c8:      	mov	w10, #0x70              // =112
     7cc:      	add	x11, sp, #0xa8
     7d0:      	ldr	x2, [sp, #0xa8]
     7d4:      	add	x0, sp, #0xa8
     7d8:      	mov	w1, #0x8                // =8
     7dc:      	blr	x10
     7e0:      	cbnz	x0, 0x81c <kprobe_unwind_perl+0x81c>
     7e4:      	ldr	x8, [sp, #0xa8]
     7e8:      	ldrb	w9, [x22, #0xe]
     7ec:      	smaddl	x8, w25, w9, x8
     7f0:      	ldr	w9, [x23]
     7f4:      	str	x8, [sp, #0xa8]
     7f8:      	cbnz	w9, 0x17d4 <kprobe_unwind_perl+0x17d4>
     7fc:      	mov	w9, #0x8                // =8
     800:      	mov	w10, #0x70              // =112
     804:      	add	x11, sp, #0x98
     808:      	ldr	x2, [sp, #0xa8]
     80c:      	add	x0, sp, #0x98
     810:      	mov	w1, #0x8                // =8
     814:      	blr	x10
     818:      	cbz	x0, 0x944 <kprobe_unwind_perl+0x944>
     81c:      	ldr	w8, [x23]
     820:      	cbnz	w8, 0x1754 <kprobe_unwind_perl+0x1754>
     824:      	mov	w8, #0x3                // =3
     828:      	add	x9, sp, #0x80
     82c:      	add	x1, sp, #0x80
     830:      	str	w8, [sp, #0x80]
     834:      	mov	w8, #0x1                // =1
     838:      	mov	x0, x24
     83c:      	blr	x8
     840:      	cbz	x0, 0x8fc <kprobe_unwind_perl+0x8fc>
     844:      	ldr	x8, [x0]
     848:      	add	x8, x8, #0x1
     84c:      	str	x8, [x0]
     850:      	b	0x904 <kprobe_unwind_perl+0x904>
     854:      	ldr	w8, [x23]
     858:      	cbnz	w8, 0x1794 <kprobe_unwind_perl+0x1794>
     85c:      	ldr	x25, [x29]
     860:      	ldrb	w8, [x22, #0x15]
     864:      	mov	w9, #0x8                // =8
     868:      	mov	w10, #0x70              // =112
     86c:      	add	x11, sp, #0xa8
     870:      	add	x0, sp, #0xa8
     874:      	mov	w1, #0x8                // =8
     878:      	add	x8, x25, x8
     87c:      	ldrb	w8, [x22, #0x15]
     880:      	add	x2, x25, x8
     884:      	blr	x10
     888:      	cbnz	x0, 0x8b8 <kprobe_unwind_perl+0x8b8>
     88c:      	ldrb	w8, [x22, #0x17]
     890:      	mov	w9, #0x4                // =4
     894:      	mov	w10, #0x70              // =112
     898:      	add	x11, sp, #0x80
     89c:      	add	x0, sp, #0x80
     8a0:      	mov	w1, #0x4                // =4
     8a4:      	add	x8, x25, x8
     8a8:      	ldrb	w8, [x22, #0x17]
     8ac:      	add	x2, x25, x8
     8b0:      	blr	x10
     8b4:      	cbz	x0, 0x9e4 <kprobe_unwind_perl+0x9e4>
     8b8:      	ldr	w8, [x23]
     8bc:      	cbnz	w8, 0x1820 <kprobe_unwind_perl+0x1820>
     8c0:      	ldr	w8, [x21, #0x1370]
     8c4:      	add	x9, sp, #0x88
     8c8:      	add	x1, sp, #0x88
     8cc:      	mov	x0, x24
     8d0:      	orr	w8, w8, #0x8
     8d4:      	str	w8, [x21, #0x1370]
     8d8:      	mov	w8, #0x12               // =18
     8dc:      	str	w8, [sp, #0x88]
     8e0:      	mov	w8, #0x1                // =1
     8e4:      	blr	x8
     8e8:      	cbz	x0, 0x994 <kprobe_unwind_perl+0x994>
     8ec:      	ldr	x8, [x0]
     8f0:      	add	x8, x8, #0x1
     8f4:      	str	x8, [x0]
     8f8:      	b	0xa04 <kprobe_unwind_perl+0xa04>
     8fc:      	ldr	w8, [x23]
     900:      	cbnz	w8, 0x18f4 <kprobe_unwind_perl+0x18f4>
     904:      	mov	w8, #0x11               // =17
     908:      	add	x9, sp, #0xa8
     90c:      	add	x1, sp, #0xa8
     910:      	str	w8, [sp, #0xa8]
     914:      	mov	w8, #0x1                // =1
     918:      	mov	x0, x24
     91c:      	blr	x8
     920:      	cbz	x0, 0x934 <kprobe_unwind_perl+0x934>
     924:      	ldr	x8, [x0]
     928:      	add	x8, x8, #0x1
     92c:      	str	x8, [x0]
     930:      	b	0x93c <kprobe_unwind_perl+0x93c>
     934:      	ldr	w8, [x23]
     938:      	cbnz	w8, 0x1150 <kprobe_unwind_perl+0x1150>
     93c:      	mov	w29, #0x1               // =1
     940:      	b	0x5820 <kprobe_unwind_perl+0x5820>
     944:      	ldr	w8, [x23]
     948:      	cbz	w8, 0x55c <kprobe_unwind_perl+0x55c>
     94c:      	mov	w8, #0x6425             // =25637
     950:      	add	x0, sp, #0x30
     954:      	mov	w1, #0x1c               // =28
     958:      	movk	w8, #0xa, lsl #16
     95c:      	str	w8, [sp, #0x48]
     960:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     964:      	add	x8, x8, #0x0
     968:      	ldp	x9, x10, [x8]
     96c:      	ldr	x8, [x8, #0x10]
     970:      	stp	x9, x10, [sp, #0x30]
     974:      	str	x8, [sp, #0x40]
     978:      	mov	w8, #0x1c               // =28
     97c:      	mov	w9, #0x6                // =6
     980:      	add	x10, sp, #0x30
     984:      	ldr	x2, [sp, #0x88]
     988:      	ldr	w3, [sp, #0x28]
     98c:      	blr	x9
     990:      	b	0x55c <kprobe_unwind_perl+0x55c>
     994:      	ldr	w8, [x23]
     998:      	cbz	w8, 0xa04 <kprobe_unwind_perl+0xa04>
     99c:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     9a0:      	add	x8, x8, #0x0
     9a4:      	add	x0, sp, #0x30
     9a8:      	ldp	x9, x10, [x8, #0x10]
     9ac:      	mov	w1, #0x2e               // =46
     9b0:      	stp	x9, x10, [sp, #0x40]
     9b4:      	ldr	x9, [x8, #0x20]
     9b8:      	add	x10, sp, #0x30
     9bc:      	str	x9, [sp, #0x50]
     9c0:      	ldur	x9, [x8, #0x26]
     9c4:      	stur	x9, [sp, #0x56]
     9c8:      	ldp	x9, x8, [x8]
     9cc:      	stp	x9, x8, [sp, #0x30]
     9d0:      	mov	w8, #0x2e               // =46
     9d4:      	mov	w9, #0x6                // =6
     9d8:      	ldr	w2, [sp, #0x88]
     9dc:      	blr	x9
     9e0:      	b	0xa04 <kprobe_unwind_perl+0xa04>
     9e4:      	ldr	w8, [x23]
     9e8:      	cbnz	w8, 0x1f84 <kprobe_unwind_perl+0x1f84>
     9ec:      	ldr	x8, [sp, #0xa8]
     9f0:      	ldrsw	x9, [sp, #0x80]
     9f4:      	str	x8, [x21, #0xf38]
     9f8:      	ldrb	w10, [x22, #0x1d]
     9fc:      	smaddl	x8, w9, w10, x8
     a00:      	str	x8, [x21, #0xf40]
     a04:      	ldr	x8, [x29]
     a08:      	str	x8, [sp, #0x68]
     a0c:      	cbnz	x8, 0x94 <kprobe_unwind_perl+0x94>
     a10:      	b	0x93c <kprobe_unwind_perl+0x93c>
     a14:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     a18:      	add	x8, x8, #0x0
     a1c:      	strb	wzr, [sp, #0x58]
     a20:      	add	x0, sp, #0x30
     a24:      	ldp	x9, x10, [x8, #0x10]
     a28:      	mov	w1, #0x29               // =41
     a2c:      	stp	x9, x10, [sp, #0x40]
     a30:      	ldr	x9, [x8, #0x20]
     a34:      	add	x10, sp, #0x30
     a38:      	str	x9, [sp, #0x50]
     a3c:      	ldp	x8, x9, [x8]
     a40:      	stp	x8, x9, [sp, #0x30]
     a44:      	mov	w8, #0x29               // =41
     a48:      	mov	w9, #0x6                // =6
     a4c:      	blr	x9
     a50:      	mov	w0, wzr
     a54:      	b	0x58e4 <kprobe_unwind_perl+0x58e4>
     a58:      	mov	w8, #0xa                // =10
     a5c:      	add	x0, sp, #0x30
     a60:      	mov	w1, #0x2a               // =42
     a64:      	strh	w8, [sp, #0x58]
     a68:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     a6c:      	add	x8, x8, #0x0
     a70:      	mov	x2, x25
     a74:      	ldp	x9, x10, [x8, #0x10]
     a78:      	stp	x9, x10, [sp, #0x40]
     a7c:      	ldr	x9, [x8, #0x20]
     a80:      	add	x10, sp, #0x30
     a84:      	str	x9, [sp, #0x50]
     a88:      	ldp	x8, x9, [x8]
     a8c:      	stp	x8, x9, [sp, #0x30]
     a90:      	mov	w8, #0x2a               // =42
     a94:      	mov	w9, #0x6                // =6
     a98:      	blr	x9
     a9c:      	b	0xf8 <kprobe_unwind_perl+0xf8>
     aa0:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     aa4:      	add	x8, x8, #0x0
     aa8:      	add	x0, sp, #0x30
     aac:      	ldp	x9, x10, [x8]
     ab0:      	ldur	x8, [x8, #0xf]
     ab4:      	mov	w1, #0x17               // =23
     ab8:      	stp	x9, x10, [sp, #0x30]
     abc:      	stur	x8, [sp, #0x3f]
     ac0:      	mov	w8, #0x17               // =23
     ac4:      	mov	w9, #0x6                // =6
     ac8:      	add	x10, sp, #0x30
     acc:      	ldr	x2, [sp, #0x98]
     ad0:      	blr	x9
     ad4:      	b	0x564 <kprobe_unwind_perl+0x564>
     ad8:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     adc:      	add	x8, x8, #0x0
     ae0:      	add	x0, sp, #0x30
     ae4:      	ldp	x9, x10, [x8]
     ae8:      	mov	w1, #0x1d               // =29
     aec:      	stp	x9, x10, [sp, #0x30]
     af0:      	ldr	x9, [x8, #0x10]
     af4:      	ldur	x8, [x8, #0x15]
     af8:      	add	x10, sp, #0x30
     afc:      	str	x9, [sp, #0x40]
     b00:      	stur	x8, [sp, #0x45]
     b04:      	mov	w8, #0x1d               // =29
     b08:      	mov	w9, #0x6                // =6
     b0c:      	blr	x9
     b10:      	b	0x67c <kprobe_unwind_perl+0x67c>
     b14:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     b18:      	add	x8, x8, #0x0
     b1c:      	add	x0, sp, #0x30
     b20:      	ldp	x9, x10, [x8, #0x10]
     b24:      	mov	w1, #0x2e               // =46
     b28:      	stp	x9, x10, [sp, #0x40]
     b2c:      	ldr	x9, [x8, #0x20]
     b30:      	add	x10, sp, #0x30
     b34:      	str	x9, [sp, #0x50]
     b38:      	ldur	x9, [x8, #0x26]
     b3c:      	stur	x9, [sp, #0x56]
     b40:      	ldp	x9, x8, [x8]
     b44:      	stp	x9, x8, [sp, #0x30]
     b48:      	mov	w8, #0x2e               // =46
     b4c:      	mov	w9, #0x6                // =6
     b50:      	ldr	w2, [sp, #0xa8]
     b54:      	blr	x9
     b58:      	ldrb	w8, [x22, #0x14]
     b5c:      	cbnz	w8, 0x640 <kprobe_unwind_perl+0x640>
     b60:      	b	0x554 <kprobe_unwind_perl+0x554>
     b64:      	ldr	w8, [x23]
     b68:      	ldr	x24, [sp, #0x10]
     b6c:      	cbz	w8, 0xf0 <kprobe_unwind_perl+0xf0>
     b70:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     b74:      	add	x8, x8, #0x0
     b78:      	add	x0, sp, #0x30
     b7c:      	ldp	x9, x10, [x8, #0x10]
     b80:      	mov	w1, #0x26               // =38
     b84:      	stp	x9, x10, [sp, #0x40]
     b88:      	ldur	x9, [x8, #0x1e]
     b8c:      	add	x10, sp, #0x30
     b90:      	stur	x9, [sp, #0x4e]
     b94:      	ldp	x8, x9, [x8]
     b98:      	stp	x8, x9, [sp, #0x30]
     b9c:      	mov	w8, #0x26               // =38
     ba0:      	mov	w9, #0x6                // =6
     ba4:      	ldr	w2, [sp, #0xb8]
     ba8:      	ldr	w3, [sp, #0xa4]
     bac:      	blr	x9
     bb0:      	b	0xf0 <kprobe_unwind_perl+0xf0>
     bb4:      	mov	w8, #0xa                // =10
     bb8:      	add	x0, sp, #0x30
     bbc:      	mov	w1, #0x22               // =34
     bc0:      	strh	w8, [sp, #0x50]
     bc4:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     bc8:      	add	x8, x8, #0x0
     bcc:      	ldp	x9, x10, [x8]
     bd0:      	stp	x9, x10, [sp, #0x30]
     bd4:      	ldp	x9, x8, [x8, #0x10]
     bd8:      	add	x10, sp, #0x30
     bdc:      	stp	x9, x8, [sp, #0x40]
     be0:      	mov	w8, #0x22               // =34
     be4:      	mov	w9, #0x6                // =6
     be8:      	blr	x9
     bec:      	b	0x5d0 <kprobe_unwind_perl+0x5d0>
     bf0:      	mov	w8, #0xa                // =10
     bf4:      	add	x10, sp, #0x30
     bf8:      	add	x0, sp, #0x30
     bfc:      	strh	w8, [sp, #0x40]
     c00:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     c04:      	add	x8, x8, #0x0
     c08:      	mov	w1, #0x12               // =18
     c0c:      	ldp	x9, x8, [x8]
     c10:      	stp	x9, x8, [sp, #0x30]
     c14:      	mov	w8, #0x12               // =18
     c18:      	mov	w9, #0x6                // =6
     c1c:      	ldrb	w2, [sp, #0x7c]
     c20:      	blr	x9
     c24:      	ldrb	w8, [sp, #0x7c]
     c28:      	and	w9, w8, #0xf
     c2c:      	sub	w10, w9, #0x9
     c30:      	cmp	w10, #0x2
     c34:      	b.lo	0x148 <kprobe_unwind_perl+0x148>
     c38:      	cmp	w9, #0xc
     c3c:      	b.ne	0xd18 <kprobe_unwind_perl+0xd18>
     c40:      	mov	w29, #0x3               // =3
     c44:      	ldrb	w8, [x22, #0x1d]
     c48:      	ldr	x9, [x21, #0xf40]
     c4c:      	adrp	x0, 0x0 <kprobe_unwind_perl>
     c50:      	add	x1, sp, #0xa8
     c54:      	sub	x8, x9, x8
     c58:      	add	x9, sp, #0xa8
     c5c:      	str	x8, [x21, #0xf40]
     c60:      	mov	w8, #0x10               // =16
     c64:      	str	w8, [sp, #0xa8]
     c68:      	mov	w8, #0x1                // =1
     c6c:      	ldr	x0, [x0]
     c70:      	blr	x8
     c74:      	cbz	x0, 0xc8c <kprobe_unwind_perl+0xc8c>
     c78:      	ldr	x8, [x0]
     c7c:      	add	x8, x8, #0x1
     c80:      	str	x8, [x0]
     c84:      	ldr	x9, [sp, #0x18]
     c88:      	b	0xc98 <kprobe_unwind_perl+0xc98>
     c8c:      	ldr	w8, [x23]
     c90:      	ldr	x9, [sp, #0x18]
     c94:      	cbnz	w8, 0x1108 <kprobe_unwind_perl+0x1108>
     c98:      	cmp	w29, #0x3
     c9c:      	b.ne	0x563c <kprobe_unwind_perl+0x563c>
     ca0:      	ldr	x25, [x21, #0xf40]
     ca4:      	cmp	x25, x9
     ca8:      	b.lo	0xac <kprobe_unwind_perl+0xac>
     cac:      	ldrb	w8, [x22, #0x19]
     cb0:      	mov	w9, #0x1                // =1
     cb4:      	mov	w10, #0x70              // =112
     cb8:      	add	x11, sp, #0x7c
     cbc:      	add	x0, sp, #0x7c
     cc0:      	mov	w1, #0x1                // =1
     cc4:      	add	x8, x25, x8
     cc8:      	ldrb	w8, [x22, #0x19]
     ccc:      	add	x2, x25, x8
     cd0:      	blr	x10
     cd4:      	cbz	x0, 0xd94 <kprobe_unwind_perl+0xd94>
     cd8:      	ldr	w8, [x23]
     cdc:      	cbnz	w8, 0x119c <kprobe_unwind_perl+0x119c>
     ce0:      	mov	w8, #0x13               // =19
     ce4:      	adrp	x0, 0x0 <kprobe_unwind_perl>
     ce8:      	add	x9, sp, #0xa8
     cec:      	str	w8, [sp, #0xa8]
     cf0:      	mov	w8, #0x1                // =1
     cf4:      	add	x1, sp, #0xa8
     cf8:      	ldr	x0, [x0]
     cfc:      	blr	x8
     d00:      	cbz	x0, 0xe94 <kprobe_unwind_perl+0xe94>
     d04:      	ldr	x8, [x0]
     d08:      	mov	w29, #0x3               // =3
     d0c:      	add	x8, x8, #0x1
     d10:      	str	x8, [x0]
     d14:      	b	0x1288 <kprobe_unwind_perl+0x1288>
     d18:      	ldr	x8, [x24]
     d1c:      	mov	w29, #0x3               // =3
     d20:      	cbnz	x8, 0xc44 <kprobe_unwind_perl+0xc44>
     d24:      	ldrb	w8, [x22, #0x1a]
     d28:      	mov	w9, #0x8                // =8
     d2c:      	mov	w10, #0x70              // =112
     d30:      	mov	x0, x24
     d34:      	mov	w1, #0x8                // =8
     d38:      	add	x8, x25, x8
     d3c:      	ldrb	w8, [x22, #0x1a]
     d40:      	add	x2, x25, x8
     d44:      	blr	x10
     d48:      	cbnz	x0, 0xf0 <kprobe_unwind_perl+0xf0>
     d4c:      	ldr	w8, [x23]
     d50:      	cbz	w8, 0xc44 <kprobe_unwind_perl+0xc44>
     d54:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     d58:      	add	x8, x8, #0x0
     d5c:      	add	x0, sp, #0x30
     d60:      	ldp	x9, x10, [x8]
     d64:      	mov	w1, #0x1e               // =30
     d68:      	stp	x9, x10, [sp, #0x30]
     d6c:      	ldr	x9, [x8, #0x10]
     d70:      	ldur	x8, [x8, #0x16]
     d74:      	add	x10, sp, #0x30
     d78:      	str	x9, [sp, #0x40]
     d7c:      	stur	x8, [sp, #0x46]
     d80:      	mov	w8, #0x1e               // =30
     d84:      	mov	w9, #0x6                // =6
     d88:      	ldr	x2, [x24]
     d8c:      	blr	x9
     d90:      	b	0xc44 <kprobe_unwind_perl+0xc44>
     d94:      	ldr	w8, [x23]
     d98:      	cbnz	w8, 0x1234 <kprobe_unwind_perl+0x1234>
     d9c:      	ldrb	w8, [sp, #0x7c]
     da0:      	and	w9, w8, #0xf
     da4:      	sub	w10, w9, #0x9
     da8:      	cmp	w10, #0x2
     dac:      	b.hs	0x127c <kprobe_unwind_perl+0x127c>
     db0:      	sxtb	w8, w8
     db4:      	tbnz	w8, #0x1f, 0x1284 <kprobe_unwind_perl+0x1284>
     db8:      	ldrb	w8, [x22, #0x1b]
     dbc:      	mov	w9, #0x8                // =8
     dc0:      	mov	w10, #0x70              // =112
     dc4:      	add	x11, sp, #0x30
     dc8:      	add	x0, sp, #0x30
     dcc:      	mov	w1, #0x8                // =8
     dd0:      	add	x8, x25, x8
     dd4:      	ldrb	w8, [x22, #0x1b]
     dd8:      	add	x2, x25, x8
     ddc:      	blr	x10
     de0:      	cbnz	x0, 0xcd8 <kprobe_unwind_perl+0xcd8>
     de4:      	ldr	x8, [sp, #0x30]
     de8:      	mov	w9, #0x8                // =8
     dec:      	mov	w10, #0x70              // =112
     df0:      	add	x11, sp, #0x70
     df4:      	add	x0, sp, #0x70
     df8:      	mov	w1, #0x8                // =8
     dfc:      	cmp	x8, #0x0
     e00:      	mov	w8, #0x3                // =3
     e04:      	csinc	w29, w8, wzr, ne
     e08:      	ldrb	w8, [x22, #0x1c]
     e0c:      	add	x8, x25, x8
     e10:      	ldrb	w8, [x22, #0x1c]
     e14:      	add	x2, x25, x8
     e18:      	blr	x10
     e1c:      	cbnz	x0, 0xcd8 <kprobe_unwind_perl+0xcd8>
     e20:      	str	x24, [sp, #0x10]
     e24:      	ldr	x24, [sp, #0x70]
     e28:      	mov	w9, #0x4                // =4
     e2c:      	mov	w10, #0x70              // =112
     e30:      	add	x11, sp, #0xb8
     e34:      	add	x0, sp, #0xb8
     e38:      	ldrb	w8, [x22, #0x1e]
     e3c:      	mov	w1, #0x4                // =4
     e40:      	add	x8, x24, x8
     e44:      	ldrb	w8, [x22, #0x1e]
     e48:      	add	x2, x24, x8
     e4c:      	blr	x10
     e50:      	cbz	x0, 0xee4 <kprobe_unwind_perl+0xee4>
     e54:      	ldr	w8, [x23]
     e58:      	cbnz	w8, 0x257c <kprobe_unwind_perl+0x257c>
     e5c:      	mov	w8, #0x14               // =20
     e60:      	adrp	x0, 0x0 <kprobe_unwind_perl>
     e64:      	add	x9, sp, #0xbc
     e68:      	str	w8, [sp, #0xbc]
     e6c:      	mov	w8, #0x1                // =1
     e70:      	add	x1, sp, #0xbc
     e74:      	ldr	x0, [x0]
     e78:      	blr	x8
     e7c:      	ldr	x24, [sp, #0x10]
     e80:      	cbz	x0, 0x106c <kprobe_unwind_perl+0x106c>
     e84:      	ldr	x8, [x0]
     e88:      	add	x8, x8, #0x1
     e8c:      	str	x8, [x0]
     e90:      	b	0xcd8 <kprobe_unwind_perl+0xcd8>
     e94:      	ldr	w8, [x23]
     e98:      	cbz	w8, 0x1284 <kprobe_unwind_perl+0x1284>
     e9c:      	adrp	x8, 0x0 <kprobe_unwind_perl>
     ea0:      	add	x8, x8, #0x0
     ea4:      	add	x0, sp, #0x30
     ea8:      	ldp	x9, x10, [x8, #0x10]
     eac:      	mov	w1, #0x2e               // =46
     eb0:      	stp	x9, x10, [sp, #0x40]
     eb4:      	ldr	x9, [x8, #0x20]
     eb8:      	add	x10, sp, #0x30
     ebc:      	str	x9, [sp, #0x50]
     ec0:      	ldur	x9, [x8, #0x26]
     ec4:      	stur	x9, [sp, #0x56]
     ec8:      	ldp	x9, x8, [x8]
     ecc:      	stp	x9, x8, [sp, #0x30]
     ed0:      	mov	w8, #0x2e               // =46
     ed4:      	mov	w9, #0x6                // =6
     ed8:      	ldr	w2, [sp, #0xa8]
     edc:      	blr	x9
     ee0:      	b	0x1284 <kprobe_unwind_perl+0x1284>
     ee4:      	ldr	w8, [sp, #0xb8]
     ee8:      	and	w8, w8, #0x1f
     eec:      	cmp	w8, #0xd
     ef0:      	b.ne	0x10bc <kprobe_unwind_perl+0x10bc>
     ef4:      	ldrb	w8, [x22, #0x1f]
     ef8:      	mov	w9, #0x8                // =8
     efc:      	mov	w10, #0x70              // =112
     f00:      	add	x11, sp, #0xa8
     f04:      	add	x0, sp, #0xa8
     f08:      	mov	w1, #0x8                // =8
     f0c:      	add	x8, x24, x8
     f10:      	ldrb	w8, [x22, #0x1f]
     f14:      	add	x2, x24, x8
     f18:      	blr	x10
     f1c:      	cbnz	x0, 0xe54 <kprobe_unwind_perl+0xe54>
     f20:      	ldr	x8, [sp, #0xa8]
     f24:      	ldrb	w9, [x22, #0x21]
     f28:      	mov	w10, #0x70              // =112
     f2c:      	add	x11, sp, #0xa4
     f30:      	add	x0, sp, #0xa4
     f34:      	mov	w1, #0x4                // =4
     f38:      	add	x8, x8, x9
     f3c:      	mov	w9, #0x4                // =4
     f40:      	ldr	x8, [sp, #0xa8]
     f44:      	ldrb	w9, [x22, #0x21]
     f48:      	add	x2, x8, x9
     f4c:      	blr	x10
     f50:      	cbnz	x0, 0xe54 <kprobe_unwind_perl+0xe54>
     f54:      	ldrb	w8, [sp, #0xa5]
     f58:      	tbnz	w8, #0x7, 0x11e4 <kprobe_unwind_perl+0x11e4>
     f5c:      	ldr	x8, [sp, #0xa8]
     f60:      	ldrb	w9, [x22, #0x22]
     f64:      	mov	w10, #0x70              // =112
     f68:      	add	x11, sp, #0x98
     f6c:      	add	x0, sp, #0x98
     f70:      	mov	w1, #0x8                // =8
     f74:      	add	x8, x8, x9
     f78:      	mov	w9, #0x8                // =8
     f7c:      	ldr	x8, [sp, #0xa8]
     f80:      	ldrb	w9, [x22, #0x22]
     f84:      	add	x2, x8, x9
     f88:      	blr	x10
     f8c:      	cbnz	x0, 0xe54 <kprobe_unwind_perl+0xe54>
     f90:      	ldr	x8, [sp, #0x98]
     f94:      	cbz	x8, 0xe54 <kprobe_unwind_perl+0xe54>
     f98:      	ldr	w9, [x23]
     f9c:      	cbnz	w9, 0x3ce0 <kprobe_unwind_perl+0x3ce0>
     fa0:      	ldrb	w9, [x22, #0x1e]
     fa4:      	mov	w10, #0x70              // =112
     fa8:      	add	x11, sp, #0x94
     fac:      	add	x0, sp, #0x94
     fb0:      	mov	w1, #0x4                // =4
     fb4:      	add	x8, x8, x9
     fb8:      	mov	w9, #0x4                // =4
     fbc:      	ldr	x8, [sp, #0x98]
     fc0:      	ldrb	w9, [x22, #0x1e]
     fc4:      	add	x2, x8, x9
     fc8:      	blr	x10
     fcc:      	cbnz	x0, 0xe54 <kprobe_unwind_perl+0xe54>
     fd0:      	ldr	w8, [sp, #0x94]
     fd4:      	mov	w9, #0x801f             // =32799
     fd8:      	and	w8, w8, w9
     fdc:      	mov	w9, #0x8009             // =32777
     fe0:      	cmp	w8, w9
     fe4:      	b.ne	0x1f38 <kprobe_unwind_perl+0x1f38>
     fe8:      	ldr	x8, [sp, #0x98]
     fec:      	ldrb	w9, [x22, #0x20]
     ff0:      	mov	w10, #0x70              // =112
     ff4:      	add	x11, sp, #0x88
     ff8:      	add	x0, sp, #0x88
     ffc:      	mov	w1, #0x8                // =8
    1000:      	add	x8, x8, x9
    1004:      	mov	w9, #0x8                // =8
    1008:      	ldr	x8, [sp, #0x98]
    100c:      	ldrb	w9, [x22, #0x20]
    1010:      	add	x2, x8, x9
    1014:      	blr	x10
    1018:      	cbnz	x0, 0xe54 <kprobe_unwind_perl+0xe54>
    101c:      	ldr	x8, [sp, #0x88]
    1020:      	ldrb	w9, [x22, #0x23]
    1024:      	mov	w10, #0x70              // =112
    1028:      	add	x11, sp, #0x80
    102c:      	add	x0, sp, #0x80
    1030:      	mov	w1, #0x8                // =8
    1034:      	add	x8, x8, x9
    1038:      	mov	w9, #0x8                // =8
    103c:      	ldr	x8, [sp, #0x88]
    1040:      	ldrb	w9, [x22, #0x23]
    1044:      	add	x2, x8, x9
    1048:      	blr	x10
    104c:      	cbnz	x0, 0xe54 <kprobe_unwind_perl+0xe54>
    1050:      	ldr	x8, [sp, #0x80]
    1054:      	str	x8, [sp, #0x8]
    1058:      	cbz	x8, 0x2d58 <kprobe_unwind_perl+0x2d58>
    105c:      	ldr	w8, [x23]
    1060:      	cbnz	w8, 0x54c0 <kprobe_unwind_perl+0x54c0>
    1064:      	ldr	x24, [sp, #0x10]
    1068:      	b	0x2d6c <kprobe_unwind_perl+0x2d6c>
    106c:      	ldr	w8, [x23]
    1070:      	cbz	w8, 0xcd8 <kprobe_unwind_perl+0xcd8>
    1074:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    1078:      	add	x8, x8, #0x0
    107c:      	add	x0, sp, #0x30
    1080:      	ldp	x9, x10, [x8, #0x10]
    1084:      	mov	w1, #0x2e               // =46
    1088:      	stp	x9, x10, [sp, #0x40]
    108c:      	ldr	x9, [x8, #0x20]
    1090:      	add	x10, sp, #0x30
    1094:      	str	x9, [sp, #0x50]
    1098:      	ldur	x9, [x8, #0x26]
    109c:      	stur	x9, [sp, #0x56]
    10a0:      	ldp	x9, x8, [x8]
    10a4:      	stp	x9, x8, [sp, #0x30]
    10a8:      	mov	w8, #0x2e               // =46
    10ac:      	mov	w9, #0x6                // =6
    10b0:      	ldr	w2, [sp, #0xbc]
    10b4:      	blr	x9
    10b8:      	b	0xcd8 <kprobe_unwind_perl+0xcd8>
    10bc:      	ldr	w8, [x23]
    10c0:      	ldr	x24, [sp, #0x10]
    10c4:      	cbz	w8, 0xcd8 <kprobe_unwind_perl+0xcd8>
    10c8:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    10cc:      	add	x8, x8, #0x0
    10d0:      	add	x0, sp, #0x30
    10d4:      	ldp	x9, x10, [x8]
    10d8:      	mov	w1, #0x1e               // =30
    10dc:      	stp	x9, x10, [sp, #0x30]
    10e0:      	ldr	x9, [x8, #0x10]
    10e4:      	ldur	x8, [x8, #0x16]
    10e8:      	add	x10, sp, #0x30
    10ec:      	str	x9, [sp, #0x40]
    10f0:      	stur	x8, [sp, #0x46]
    10f4:      	mov	w8, #0x1e               // =30
    10f8:      	mov	w9, #0x6                // =6
    10fc:      	ldr	w2, [sp, #0xb8]
    1100:      	blr	x9
    1104:      	b	0xcd8 <kprobe_unwind_perl+0xcd8>
    1108:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    110c:      	add	x8, x8, #0x0
    1110:      	add	x0, sp, #0x30
    1114:      	ldp	x9, x10, [x8, #0x10]
    1118:      	mov	w1, #0x2e               // =46
    111c:      	stp	x9, x10, [sp, #0x40]
    1120:      	ldr	x9, [x8, #0x20]
    1124:      	add	x10, sp, #0x30
    1128:      	str	x9, [sp, #0x50]
    112c:      	ldur	x9, [x8, #0x26]
    1130:      	stur	x9, [sp, #0x56]
    1134:      	ldp	x9, x8, [x8]
    1138:      	stp	x9, x8, [sp, #0x30]
    113c:      	mov	w8, #0x2e               // =46
    1140:      	mov	w9, #0x6                // =6
    1144:      	ldr	w2, [sp, #0xa8]
    1148:      	blr	x9
    114c:      	b	0xc84 <kprobe_unwind_perl+0xc84>
    1150:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    1154:      	add	x8, x8, #0x0
    1158:      	ldp	x9, x10, [x8, #0x10]
    115c:      	stp	x9, x10, [sp, #0x40]
    1160:      	ldr	x9, [x8, #0x20]
    1164:      	add	x10, sp, #0x30
    1168:      	str	x9, [sp, #0x50]
    116c:      	ldur	x9, [x8, #0x26]
    1170:      	stur	x9, [sp, #0x56]
    1174:      	ldp	x9, x8, [x8]
    1178:      	stp	x9, x8, [sp, #0x30]
    117c:      	mov	w8, #0x2e               // =46
    1180:      	mov	w9, #0x6                // =6
    1184:      	ldr	w2, [sp, #0xa8]
    1188:      	add	x0, sp, #0x30
    118c:      	mov	w1, #0x2e               // =46
    1190:      	blr	x9
    1194:      	mov	w29, #0x1               // =1
    1198:      	b	0x5820 <kprobe_unwind_perl+0x5820>
    119c:      	mov	w8, #0xa                // =10
    11a0:      	add	x0, sp, #0x30
    11a4:      	mov	w1, #0x2a               // =42
    11a8:      	strh	w8, [sp, #0x58]
    11ac:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    11b0:      	add	x8, x8, #0x0
    11b4:      	mov	x2, x25
    11b8:      	ldp	x9, x10, [x8, #0x10]
    11bc:      	stp	x9, x10, [sp, #0x40]
    11c0:      	ldr	x9, [x8, #0x20]
    11c4:      	add	x10, sp, #0x30
    11c8:      	str	x9, [sp, #0x50]
    11cc:      	ldp	x8, x9, [x8]
    11d0:      	stp	x8, x9, [sp, #0x30]
    11d4:      	mov	w8, #0x2a               // =42
    11d8:      	mov	w9, #0x6                // =6
    11dc:      	blr	x9
    11e0:      	b	0xce0 <kprobe_unwind_perl+0xce0>
    11e4:      	ldr	w8, [x23]
    11e8:      	ldr	x24, [sp, #0x10]
    11ec:      	cbz	w8, 0xcd8 <kprobe_unwind_perl+0xcd8>
    11f0:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    11f4:      	add	x8, x8, #0x0
    11f8:      	add	x0, sp, #0x30
    11fc:      	ldp	x9, x10, [x8, #0x10]
    1200:      	mov	w1, #0x26               // =38
    1204:      	stp	x9, x10, [sp, #0x40]
    1208:      	ldur	x9, [x8, #0x1e]
    120c:      	add	x10, sp, #0x30
    1210:      	stur	x9, [sp, #0x4e]
    1214:      	ldp	x8, x9, [x8]
    1218:      	stp	x8, x9, [sp, #0x30]
    121c:      	mov	w8, #0x26               // =38
    1220:      	mov	w9, #0x6                // =6
    1224:      	ldr	w2, [sp, #0xb8]
    1228:      	ldr	w3, [sp, #0xa4]
    122c:      	blr	x9
    1230:      	b	0xcd8 <kprobe_unwind_perl+0xcd8>
    1234:      	mov	w8, #0xa                // =10
    1238:      	add	x10, sp, #0x30
    123c:      	add	x0, sp, #0x30
    1240:      	strh	w8, [sp, #0x40]
    1244:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    1248:      	add	x8, x8, #0x0
    124c:      	mov	w1, #0x12               // =18
    1250:      	ldp	x9, x8, [x8]
    1254:      	stp	x9, x8, [sp, #0x30]
    1258:      	mov	w8, #0x12               // =18
    125c:      	mov	w9, #0x6                // =6
    1260:      	ldrb	w2, [sp, #0x7c]
    1264:      	blr	x9
    1268:      	ldrb	w8, [sp, #0x7c]
    126c:      	and	w9, w8, #0xf
    1270:      	sub	w10, w9, #0x9
    1274:      	cmp	w10, #0x2
    1278:      	b.lo	0xdb0 <kprobe_unwind_perl+0xdb0>
    127c:      	cmp	w9, #0xc
    1280:      	b.ne	0x135c <kprobe_unwind_perl+0x135c>
    1284:      	mov	w29, #0x3               // =3
    1288:      	ldrb	w8, [x22, #0x1d]
    128c:      	ldr	x9, [x21, #0xf40]
    1290:      	adrp	x0, 0x1000 <kprobe_unwind_perl+0x1000>
    1294:      	add	x1, sp, #0xa8
    1298:      	sub	x8, x9, x8
    129c:      	add	x9, sp, #0xa8
    12a0:      	str	x8, [x21, #0xf40]
    12a4:      	mov	w8, #0x10               // =16
    12a8:      	str	w8, [sp, #0xa8]
    12ac:      	mov	w8, #0x1                // =1
    12b0:      	ldr	x0, [x0]
    12b4:      	blr	x8
    12b8:      	cbz	x0, 0x12d0 <kprobe_unwind_perl+0x12d0>
    12bc:      	ldr	x8, [x0]
    12c0:      	add	x8, x8, #0x1
    12c4:      	str	x8, [x0]
    12c8:      	ldr	x9, [sp, #0x18]
    12cc:      	b	0x12dc <kprobe_unwind_perl+0x12dc>
    12d0:      	ldr	w8, [x23]
    12d4:      	ldr	x9, [sp, #0x18]
    12d8:      	cbnz	w8, 0x170c <kprobe_unwind_perl+0x170c>
    12dc:      	cmp	w29, #0x3
    12e0:      	b.ne	0x563c <kprobe_unwind_perl+0x563c>
    12e4:      	ldr	x25, [x21, #0xf40]
    12e8:      	cmp	x25, x9
    12ec:      	b.lo	0xac <kprobe_unwind_perl+0xac>
    12f0:      	ldrb	w8, [x22, #0x19]
    12f4:      	mov	w9, #0x1                // =1
    12f8:      	mov	w10, #0x70              // =112
    12fc:      	add	x11, sp, #0x7c
    1300:      	add	x0, sp, #0x7c
    1304:      	mov	w1, #0x1                // =1
    1308:      	add	x8, x25, x8
    130c:      	ldrb	w8, [x22, #0x19]
    1310:      	add	x2, x25, x8
    1314:      	blr	x10
    1318:      	cbz	x0, 0x13d8 <kprobe_unwind_perl+0x13d8>
    131c:      	ldr	w8, [x23]
    1320:      	cbnz	w8, 0x1864 <kprobe_unwind_perl+0x1864>
    1324:      	mov	w8, #0x13               // =19
    1328:      	adrp	x0, 0x1000 <kprobe_unwind_perl+0x1000>
    132c:      	add	x9, sp, #0xa8
    1330:      	str	w8, [sp, #0xa8]
    1334:      	mov	w8, #0x1                // =1
    1338:      	add	x1, sp, #0xa8
    133c:      	ldr	x0, [x0]
    1340:      	blr	x8
    1344:      	cbz	x0, 0x14d8 <kprobe_unwind_perl+0x14d8>
    1348:      	ldr	x8, [x0]
    134c:      	mov	w29, #0x3               // =3
    1350:      	add	x8, x8, #0x1
    1354:      	str	x8, [x0]
    1358:      	b	0x19e0 <kprobe_unwind_perl+0x19e0>
    135c:      	ldr	x8, [x24]
    1360:      	mov	w29, #0x3               // =3
    1364:      	cbnz	x8, 0x1288 <kprobe_unwind_perl+0x1288>
    1368:      	ldrb	w8, [x22, #0x1a]
    136c:      	mov	w9, #0x8                // =8
    1370:      	mov	w10, #0x70              // =112
    1374:      	mov	x0, x24
    1378:      	mov	w1, #0x8                // =8
    137c:      	add	x8, x25, x8
    1380:      	ldrb	w8, [x22, #0x1a]
    1384:      	add	x2, x25, x8
    1388:      	blr	x10
    138c:      	cbnz	x0, 0xcd8 <kprobe_unwind_perl+0xcd8>
    1390:      	ldr	w8, [x23]
    1394:      	cbz	w8, 0x1288 <kprobe_unwind_perl+0x1288>
    1398:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    139c:      	add	x8, x8, #0x0
    13a0:      	add	x0, sp, #0x30
    13a4:      	ldp	x9, x10, [x8]
    13a8:      	mov	w1, #0x1e               // =30
    13ac:      	stp	x9, x10, [sp, #0x30]
    13b0:      	ldr	x9, [x8, #0x10]
    13b4:      	ldur	x8, [x8, #0x16]
    13b8:      	add	x10, sp, #0x30
    13bc:      	str	x9, [sp, #0x40]
    13c0:      	stur	x8, [sp, #0x46]
    13c4:      	mov	w8, #0x1e               // =30
    13c8:      	mov	w9, #0x6                // =6
    13cc:      	ldr	x2, [x24]
    13d0:      	blr	x9
    13d4:      	b	0x1288 <kprobe_unwind_perl+0x1288>
    13d8:      	ldr	w8, [x23]
    13dc:      	cbnz	w8, 0x198c <kprobe_unwind_perl+0x198c>
    13e0:      	ldrb	w8, [sp, #0x7c]
    13e4:      	and	w9, w8, #0xf
    13e8:      	sub	w10, w9, #0x9
    13ec:      	cmp	w10, #0x2
    13f0:      	b.hs	0x19d4 <kprobe_unwind_perl+0x19d4>
    13f4:      	sxtb	w8, w8
    13f8:      	tbnz	w8, #0x1f, 0x19dc <kprobe_unwind_perl+0x19dc>
    13fc:      	ldrb	w8, [x22, #0x1b]
    1400:      	mov	w9, #0x8                // =8
    1404:      	mov	w10, #0x70              // =112
    1408:      	add	x11, sp, #0x30
    140c:      	add	x0, sp, #0x30
    1410:      	mov	w1, #0x8                // =8
    1414:      	add	x8, x25, x8
    1418:      	ldrb	w8, [x22, #0x1b]
    141c:      	add	x2, x25, x8
    1420:      	blr	x10
    1424:      	cbnz	x0, 0x131c <kprobe_unwind_perl+0x131c>
    1428:      	ldr	x8, [sp, #0x30]
    142c:      	mov	w9, #0x8                // =8
    1430:      	mov	w10, #0x70              // =112
    1434:      	add	x11, sp, #0x70
    1438:      	add	x0, sp, #0x70
    143c:      	mov	w1, #0x8                // =8
    1440:      	cmp	x8, #0x0
    1444:      	mov	w8, #0x3                // =3
    1448:      	csinc	w29, w8, wzr, ne
    144c:      	ldrb	w8, [x22, #0x1c]
    1450:      	add	x8, x25, x8
    1454:      	ldrb	w8, [x22, #0x1c]
    1458:      	add	x2, x25, x8
    145c:      	blr	x10
    1460:      	cbnz	x0, 0x131c <kprobe_unwind_perl+0x131c>
    1464:      	str	x24, [sp, #0x10]
    1468:      	ldr	x24, [sp, #0x70]
    146c:      	mov	w9, #0x4                // =4
    1470:      	mov	w10, #0x70              // =112
    1474:      	add	x11, sp, #0xb8
    1478:      	add	x0, sp, #0xb8
    147c:      	ldrb	w8, [x22, #0x1e]
    1480:      	mov	w1, #0x4                // =4
    1484:      	add	x8, x24, x8
    1488:      	ldrb	w8, [x22, #0x1e]
    148c:      	add	x2, x24, x8
    1490:      	blr	x10
    1494:      	cbz	x0, 0x1528 <kprobe_unwind_perl+0x1528>
    1498:      	ldr	w8, [x23]
    149c:      	cbnz	w8, 0x2c88 <kprobe_unwind_perl+0x2c88>
    14a0:      	mov	w8, #0x14               // =20
    14a4:      	adrp	x0, 0x1000 <kprobe_unwind_perl+0x1000>
    14a8:      	add	x9, sp, #0xbc
    14ac:      	str	w8, [sp, #0xbc]
    14b0:      	mov	w8, #0x1                // =1
    14b4:      	add	x1, sp, #0xbc
    14b8:      	ldr	x0, [x0]
    14bc:      	blr	x8
    14c0:      	cbz	x0, 0x16b0 <kprobe_unwind_perl+0x16b0>
    14c4:      	ldr	x8, [x0]
    14c8:      	ldr	x24, [sp, #0x10]
    14cc:      	add	x8, x8, #0x1
    14d0:      	str	x8, [x0]
    14d4:      	b	0x131c <kprobe_unwind_perl+0x131c>
    14d8:      	ldr	w8, [x23]
    14dc:      	cbz	w8, 0x19dc <kprobe_unwind_perl+0x19dc>
    14e0:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    14e4:      	add	x8, x8, #0x0
    14e8:      	add	x0, sp, #0x30
    14ec:      	ldp	x9, x10, [x8, #0x10]
    14f0:      	mov	w1, #0x2e               // =46
    14f4:      	stp	x9, x10, [sp, #0x40]
    14f8:      	ldr	x9, [x8, #0x20]
    14fc:      	add	x10, sp, #0x30
    1500:      	str	x9, [sp, #0x50]
    1504:      	ldur	x9, [x8, #0x26]
    1508:      	stur	x9, [sp, #0x56]
    150c:      	ldp	x9, x8, [x8]
    1510:      	stp	x9, x8, [sp, #0x30]
    1514:      	mov	w8, #0x2e               // =46
    1518:      	mov	w9, #0x6                // =6
    151c:      	ldr	w2, [sp, #0xa8]
    1520:      	blr	x9
    1524:      	b	0x19dc <kprobe_unwind_perl+0x19dc>
    1528:      	ldr	w8, [sp, #0xb8]
    152c:      	and	w8, w8, #0x1f
    1530:      	cmp	w8, #0xd
    1534:      	b.ne	0x16c0 <kprobe_unwind_perl+0x16c0>
    1538:      	ldrb	w8, [x22, #0x1f]
    153c:      	mov	w9, #0x8                // =8
    1540:      	mov	w10, #0x70              // =112
    1544:      	add	x11, sp, #0xa8
    1548:      	add	x0, sp, #0xa8
    154c:      	mov	w1, #0x8                // =8
    1550:      	add	x8, x24, x8
    1554:      	ldrb	w8, [x22, #0x1f]
    1558:      	add	x2, x24, x8
    155c:      	blr	x10
    1560:      	cbnz	x0, 0x1498 <kprobe_unwind_perl+0x1498>
    1564:      	ldr	x8, [sp, #0xa8]
    1568:      	ldrb	w9, [x22, #0x21]
    156c:      	mov	w10, #0x70              // =112
    1570:      	add	x11, sp, #0xa4
    1574:      	add	x0, sp, #0xa4
    1578:      	mov	w1, #0x4                // =4
    157c:      	add	x8, x8, x9
    1580:      	mov	w9, #0x4                // =4
    1584:      	ldr	x8, [sp, #0xa8]
    1588:      	ldrb	w9, [x22, #0x21]
    158c:      	add	x2, x8, x9
    1590:      	blr	x10
    1594:      	cbnz	x0, 0x1498 <kprobe_unwind_perl+0x1498>
    1598:      	ldrb	w8, [sp, #0xa5]
    159c:      	tbnz	w8, #0x7, 0x193c <kprobe_unwind_perl+0x193c>
    15a0:      	ldr	x8, [sp, #0xa8]
    15a4:      	ldrb	w9, [x22, #0x22]
    15a8:      	mov	w10, #0x70              // =112
    15ac:      	add	x11, sp, #0x98
    15b0:      	add	x0, sp, #0x98
    15b4:      	mov	w1, #0x8                // =8
    15b8:      	add	x8, x8, x9
    15bc:      	mov	w9, #0x8                // =8
    15c0:      	ldr	x8, [sp, #0xa8]
    15c4:      	ldrb	w9, [x22, #0x22]
    15c8:      	add	x2, x8, x9
    15cc:      	blr	x10
    15d0:      	cbnz	x0, 0x1498 <kprobe_unwind_perl+0x1498>
    15d4:      	ldr	x8, [sp, #0x98]
    15d8:      	cbz	x8, 0x1498 <kprobe_unwind_perl+0x1498>
    15dc:      	ldr	w9, [x23]
    15e0:      	cbnz	w9, 0x4448 <kprobe_unwind_perl+0x4448>
    15e4:      	ldrb	w9, [x22, #0x1e]
    15e8:      	mov	w10, #0x70              // =112
    15ec:      	add	x11, sp, #0x94
    15f0:      	add	x0, sp, #0x94
    15f4:      	mov	w1, #0x4                // =4
    15f8:      	add	x8, x8, x9
    15fc:      	mov	w9, #0x4                // =4
    1600:      	ldr	x8, [sp, #0x98]
    1604:      	ldrb	w9, [x22, #0x1e]
    1608:      	add	x2, x8, x9
    160c:      	blr	x10
    1610:      	cbnz	x0, 0x1498 <kprobe_unwind_perl+0x1498>
    1614:      	ldr	w8, [sp, #0x94]
    1618:      	mov	w9, #0x801f             // =32799
    161c:      	and	w8, w8, w9
    1620:      	mov	w9, #0x8009             // =32777
    1624:      	cmp	w8, w9
    1628:      	b.ne	0x2608 <kprobe_unwind_perl+0x2608>
    162c:      	ldr	x8, [sp, #0x98]
    1630:      	ldrb	w9, [x22, #0x20]
    1634:      	mov	w10, #0x70              // =112
    1638:      	add	x11, sp, #0x88
    163c:      	add	x0, sp, #0x88
    1640:      	mov	w1, #0x8                // =8
    1644:      	add	x8, x8, x9
    1648:      	mov	w9, #0x8                // =8
    164c:      	ldr	x8, [sp, #0x98]
    1650:      	ldrb	w9, [x22, #0x20]
    1654:      	add	x2, x8, x9
    1658:      	blr	x10
    165c:      	cbnz	x0, 0x1498 <kprobe_unwind_perl+0x1498>
    1660:      	ldr	x8, [sp, #0x88]
    1664:      	ldrb	w9, [x22, #0x23]
    1668:      	mov	w10, #0x70              // =112
    166c:      	add	x11, sp, #0x80
    1670:      	add	x0, sp, #0x80
    1674:      	mov	w1, #0x8                // =8
    1678:      	add	x8, x8, x9
    167c:      	mov	w9, #0x8                // =8
    1680:      	ldr	x8, [sp, #0x88]
    1684:      	ldrb	w9, [x22, #0x23]
    1688:      	add	x2, x8, x9
    168c:      	blr	x10
    1690:      	cbnz	x0, 0x1498 <kprobe_unwind_perl+0x1498>
    1694:      	ldr	x8, [sp, #0x80]
    1698:      	str	x8, [sp, #0x8]
    169c:      	cbz	x8, 0x34d4 <kprobe_unwind_perl+0x34d4>
    16a0:      	ldr	w8, [x23]
    16a4:      	cbnz	w8, 0x62b4 <kprobe_unwind_perl+0x62b4>
    16a8:      	ldr	x24, [sp, #0x10]
    16ac:      	b	0x34e8 <kprobe_unwind_perl+0x34e8>
    16b0:      	ldr	w8, [x23]
    16b4:      	cbnz	w8, 0x33bc <kprobe_unwind_perl+0x33bc>
    16b8:      	ldr	x24, [sp, #0x10]
    16bc:      	b	0x131c <kprobe_unwind_perl+0x131c>
    16c0:      	ldr	w8, [x23]
    16c4:      	ldr	x24, [sp, #0x10]
    16c8:      	cbz	w8, 0x131c <kprobe_unwind_perl+0x131c>
    16cc:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    16d0:      	add	x8, x8, #0x0
    16d4:      	add	x0, sp, #0x30
    16d8:      	ldp	x9, x10, [x8]
    16dc:      	mov	w1, #0x1e               // =30
    16e0:      	stp	x9, x10, [sp, #0x30]
    16e4:      	ldr	x9, [x8, #0x10]
    16e8:      	ldur	x8, [x8, #0x16]
    16ec:      	add	x10, sp, #0x30
    16f0:      	str	x9, [sp, #0x40]
    16f4:      	stur	x8, [sp, #0x46]
    16f8:      	mov	w8, #0x1e               // =30
    16fc:      	mov	w9, #0x6                // =6
    1700:      	ldr	w2, [sp, #0xb8]
    1704:      	blr	x9
    1708:      	b	0x131c <kprobe_unwind_perl+0x131c>
    170c:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    1710:      	add	x8, x8, #0x0
    1714:      	add	x0, sp, #0x30
    1718:      	ldp	x9, x10, [x8, #0x10]
    171c:      	mov	w1, #0x2e               // =46
    1720:      	stp	x9, x10, [sp, #0x40]
    1724:      	ldr	x9, [x8, #0x20]
    1728:      	add	x10, sp, #0x30
    172c:      	str	x9, [sp, #0x50]
    1730:      	ldur	x9, [x8, #0x26]
    1734:      	stur	x9, [sp, #0x56]
    1738:      	ldp	x9, x8, [x8]
    173c:      	stp	x9, x8, [sp, #0x30]
    1740:      	mov	w8, #0x2e               // =46
    1744:      	mov	w9, #0x6                // =6
    1748:      	ldr	w2, [sp, #0xa8]
    174c:      	blr	x9
    1750:      	b	0x12c8 <kprobe_unwind_perl+0x12c8>
    1754:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    1758:      	add	x8, x8, #0x0
    175c:      	add	x0, sp, #0x30
    1760:      	ldp	x9, x10, [x8]
    1764:      	mov	w1, #0x1f               // =31
    1768:      	stp	x9, x10, [sp, #0x30]
    176c:      	ldr	x9, [x8, #0x10]
    1770:      	ldur	x8, [x8, #0x17]
    1774:      	add	x10, sp, #0x30
    1778:      	str	x9, [sp, #0x40]
    177c:      	stur	x8, [sp, #0x47]
    1780:      	mov	w8, #0x1f               // =31
    1784:      	mov	w9, #0x6                // =6
    1788:      	ldr	x2, [sp, #0xa8]
    178c:      	blr	x9
    1790:      	b	0x824 <kprobe_unwind_perl+0x824>
    1794:      	mov	w8, #0xa                // =10
    1798:      	add	x0, sp, #0x30
    179c:      	mov	w1, #0x22               // =34
    17a0:      	strh	w8, [sp, #0x50]
    17a4:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    17a8:      	add	x8, x8, #0x0
    17ac:      	ldp	x9, x10, [x8]
    17b0:      	stp	x9, x10, [sp, #0x30]
    17b4:      	ldp	x9, x8, [x8, #0x10]
    17b8:      	add	x10, sp, #0x30
    17bc:      	stp	x9, x8, [sp, #0x40]
    17c0:      	mov	w8, #0x22               // =34
    17c4:      	mov	w9, #0x6                // =6
    17c8:      	ldr	x2, [x25]
    17cc:      	blr	x9
    17d0:      	b	0x85c <kprobe_unwind_perl+0x85c>
    17d4:      	mov	w8, #0x786c             // =30828
    17d8:      	add	x0, sp, #0x30
    17dc:      	mov	w1, #0x23               // =35
    17e0:      	mov	w2, w25
    17e4:      	movk	w8, #0xa, lsl #16
    17e8:      	stur	w8, [sp, #0x4f]
    17ec:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    17f0:      	add	x8, x8, #0x0
    17f4:      	ldp	x9, x10, [x8]
    17f8:      	stp	x9, x10, [sp, #0x30]
    17fc:      	ldp	x9, x8, [x8, #0x10]
    1800:      	add	x10, sp, #0x30
    1804:      	stp	x9, x8, [sp, #0x40]
    1808:      	mov	w8, #0x23               // =35
    180c:      	mov	w9, #0x6                // =6
    1810:      	ldr	x3, [sp, #0xa8]
    1814:      	blr	x9
    1818:      	ldr	x8, [sp, #0xa8]
    181c:      	b	0x7fc <kprobe_unwind_perl+0x7fc>
    1820:      	mov	w8, #0x786c             // =30828
    1824:      	add	x0, sp, #0x30
    1828:      	mov	w1, #0x23               // =35
    182c:      	mov	x2, x25
    1830:      	movk	w8, #0xa, lsl #16
    1834:      	stur	w8, [sp, #0x4f]
    1838:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    183c:      	add	x8, x8, #0x0
    1840:      	ldp	x9, x10, [x8]
    1844:      	stp	x9, x10, [sp, #0x30]
    1848:      	ldp	x9, x8, [x8, #0x10]
    184c:      	add	x10, sp, #0x30
    1850:      	stp	x9, x8, [sp, #0x40]
    1854:      	mov	w8, #0x23               // =35
    1858:      	mov	w9, #0x6                // =6
    185c:      	blr	x9
    1860:      	b	0x8c0 <kprobe_unwind_perl+0x8c0>
    1864:      	mov	w8, #0xa                // =10
    1868:      	add	x0, sp, #0x30
    186c:      	mov	w1, #0x2a               // =42
    1870:      	strh	w8, [sp, #0x58]
    1874:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    1878:      	add	x8, x8, #0x0
    187c:      	mov	x2, x25
    1880:      	ldp	x9, x10, [x8, #0x10]
    1884:      	stp	x9, x10, [sp, #0x40]
    1888:      	ldr	x9, [x8, #0x20]
    188c:      	add	x10, sp, #0x30
    1890:      	str	x9, [sp, #0x50]
    1894:      	ldp	x8, x9, [x8]
    1898:      	stp	x8, x9, [sp, #0x30]
    189c:      	mov	w8, #0x2a               // =42
    18a0:      	mov	w9, #0x6                // =6
    18a4:      	blr	x9
    18a8:      	b	0x1324 <kprobe_unwind_perl+0x1324>
    18ac:      	ldr	w8, [x23]
    18b0:      	ldr	x24, [sp, #0x10]
    18b4:      	cbz	w8, 0xf0 <kprobe_unwind_perl+0xf0>
    18b8:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    18bc:      	add	x8, x8, #0x0
    18c0:      	add	x0, sp, #0x30
    18c4:      	ldp	x9, x10, [x8, #0x10]
    18c8:      	mov	w1, #0x26               // =38
    18cc:      	stp	x9, x10, [sp, #0x40]
    18d0:      	ldur	x9, [x8, #0x1e]
    18d4:      	add	x10, sp, #0x30
    18d8:      	stur	x9, [sp, #0x4e]
    18dc:      	ldp	x8, x9, [x8]
    18e0:      	stp	x8, x9, [sp, #0x30]
    18e4:      	mov	w8, #0x26               // =38
    18e8:      	mov	w9, #0x6                // =6
    18ec:      	ldr	w2, [sp, #0x94]
    18f0:      	b	0x494 <kprobe_unwind_perl+0x494>
    18f4:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    18f8:      	add	x8, x8, #0x0
    18fc:      	add	x0, sp, #0x30
    1900:      	ldp	x9, x10, [x8, #0x10]
    1904:      	mov	w1, #0x2e               // =46
    1908:      	stp	x9, x10, [sp, #0x40]
    190c:      	ldr	x9, [x8, #0x20]
    1910:      	add	x10, sp, #0x30
    1914:      	str	x9, [sp, #0x50]
    1918:      	ldur	x9, [x8, #0x26]
    191c:      	stur	x9, [sp, #0x56]
    1920:      	ldp	x9, x8, [x8]
    1924:      	stp	x9, x8, [sp, #0x30]
    1928:      	mov	w8, #0x2e               // =46
    192c:      	mov	w9, #0x6                // =6
    1930:      	ldr	w2, [sp, #0x80]
    1934:      	blr	x9
    1938:      	b	0x904 <kprobe_unwind_perl+0x904>
    193c:      	ldr	w8, [x23]
    1940:      	ldr	x24, [sp, #0x10]
    1944:      	cbz	w8, 0x131c <kprobe_unwind_perl+0x131c>
    1948:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    194c:      	add	x8, x8, #0x0
    1950:      	add	x0, sp, #0x30
    1954:      	ldp	x9, x10, [x8, #0x10]
    1958:      	mov	w1, #0x26               // =38
    195c:      	stp	x9, x10, [sp, #0x40]
    1960:      	ldur	x9, [x8, #0x1e]
    1964:      	add	x10, sp, #0x30
    1968:      	stur	x9, [sp, #0x4e]
    196c:      	ldp	x8, x9, [x8]
    1970:      	stp	x8, x9, [sp, #0x30]
    1974:      	mov	w8, #0x26               // =38
    1978:      	mov	w9, #0x6                // =6
    197c:      	ldr	w2, [sp, #0xb8]
    1980:      	ldr	w3, [sp, #0xa4]
    1984:      	blr	x9
    1988:      	b	0x131c <kprobe_unwind_perl+0x131c>
    198c:      	mov	w8, #0xa                // =10
    1990:      	add	x10, sp, #0x30
    1994:      	add	x0, sp, #0x30
    1998:      	strh	w8, [sp, #0x40]
    199c:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    19a0:      	add	x8, x8, #0x0
    19a4:      	mov	w1, #0x12               // =18
    19a8:      	ldp	x9, x8, [x8]
    19ac:      	stp	x9, x8, [sp, #0x30]
    19b0:      	mov	w8, #0x12               // =18
    19b4:      	mov	w9, #0x6                // =6
    19b8:      	ldrb	w2, [sp, #0x7c]
    19bc:      	blr	x9
    19c0:      	ldrb	w8, [sp, #0x7c]
    19c4:      	and	w9, w8, #0xf
    19c8:      	sub	w10, w9, #0x9
    19cc:      	cmp	w10, #0x2
    19d0:      	b.lo	0x13f4 <kprobe_unwind_perl+0x13f4>
    19d4:      	cmp	w9, #0xc
    19d8:      	b.ne	0x1ab4 <kprobe_unwind_perl+0x1ab4>
    19dc:      	mov	w29, #0x3               // =3
    19e0:      	ldrb	w8, [x22, #0x1d]
    19e4:      	ldr	x9, [x21, #0xf40]
    19e8:      	adrp	x0, 0x1000 <kprobe_unwind_perl+0x1000>
    19ec:      	add	x1, sp, #0xa8
    19f0:      	sub	x8, x9, x8
    19f4:      	add	x9, sp, #0xa8
    19f8:      	str	x8, [x21, #0xf40]
    19fc:      	mov	w8, #0x10               // =16
    1a00:      	str	w8, [sp, #0xa8]
    1a04:      	mov	w8, #0x1                // =1
    1a08:      	ldr	x0, [x0]
    1a0c:      	blr	x8
    1a10:      	cbz	x0, 0x1a28 <kprobe_unwind_perl+0x1a28>
    1a14:      	ldr	x8, [x0]
    1a18:      	add	x8, x8, #0x1
    1a1c:      	str	x8, [x0]
    1a20:      	ldr	x9, [sp, #0x18]
    1a24:      	b	0x1a34 <kprobe_unwind_perl+0x1a34>
    1a28:      	ldr	w8, [x23]
    1a2c:      	ldr	x9, [sp, #0x18]
    1a30:      	cbnz	w8, 0x1e64 <kprobe_unwind_perl+0x1e64>
    1a34:      	cmp	w29, #0x3
    1a38:      	b.ne	0x563c <kprobe_unwind_perl+0x563c>
    1a3c:      	ldr	x25, [x21, #0xf40]
    1a40:      	cmp	x25, x9
    1a44:      	b.lo	0xac <kprobe_unwind_perl+0xac>
    1a48:      	ldrb	w8, [x22, #0x19]
    1a4c:      	mov	w9, #0x1                // =1
    1a50:      	mov	w10, #0x70              // =112
    1a54:      	add	x11, sp, #0x7c
    1a58:      	add	x0, sp, #0x7c
    1a5c:      	mov	w1, #0x1                // =1
    1a60:      	add	x8, x25, x8
    1a64:      	ldrb	w8, [x22, #0x19]
    1a68:      	add	x2, x25, x8
    1a6c:      	blr	x10
    1a70:      	cbz	x0, 0x1b30 <kprobe_unwind_perl+0x1b30>
    1a74:      	ldr	w8, [x23]
    1a78:      	cbnz	w8, 0x1ef0 <kprobe_unwind_perl+0x1ef0>
    1a7c:      	mov	w8, #0x13               // =19
    1a80:      	adrp	x0, 0x1000 <kprobe_unwind_perl+0x1000>
    1a84:      	add	x9, sp, #0xa8
    1a88:      	str	w8, [sp, #0xa8]
    1a8c:      	mov	w8, #0x1                // =1
    1a90:      	add	x1, sp, #0xa8
    1a94:      	ldr	x0, [x0]
    1a98:      	blr	x8
    1a9c:      	cbz	x0, 0x1c30 <kprobe_unwind_perl+0x1c30>
    1aa0:      	ldr	x8, [x0]
    1aa4:      	mov	w29, #0x3               // =3
    1aa8:      	add	x8, x8, #0x1
    1aac:      	str	x8, [x0]
    1ab0:      	b	0x206c <kprobe_unwind_perl+0x206c>
    1ab4:      	ldr	x8, [x24]
    1ab8:      	mov	w29, #0x3               // =3
    1abc:      	cbnz	x8, 0x19e0 <kprobe_unwind_perl+0x19e0>
    1ac0:      	ldrb	w8, [x22, #0x1a]
    1ac4:      	mov	w9, #0x8                // =8
    1ac8:      	mov	w10, #0x70              // =112
    1acc:      	mov	x0, x24
    1ad0:      	mov	w1, #0x8                // =8
    1ad4:      	add	x8, x25, x8
    1ad8:      	ldrb	w8, [x22, #0x1a]
    1adc:      	add	x2, x25, x8
    1ae0:      	blr	x10
    1ae4:      	cbnz	x0, 0x131c <kprobe_unwind_perl+0x131c>
    1ae8:      	ldr	w8, [x23]
    1aec:      	cbz	w8, 0x19e0 <kprobe_unwind_perl+0x19e0>
    1af0:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    1af4:      	add	x8, x8, #0x0
    1af8:      	add	x0, sp, #0x30
    1afc:      	ldp	x9, x10, [x8]
    1b00:      	mov	w1, #0x1e               // =30
    1b04:      	stp	x9, x10, [sp, #0x30]
    1b08:      	ldr	x9, [x8, #0x10]
    1b0c:      	ldur	x8, [x8, #0x16]
    1b10:      	add	x10, sp, #0x30
    1b14:      	str	x9, [sp, #0x40]
    1b18:      	stur	x8, [sp, #0x46]
    1b1c:      	mov	w8, #0x1e               // =30
    1b20:      	mov	w9, #0x6                // =6
    1b24:      	ldr	x2, [x24]
    1b28:      	blr	x9
    1b2c:      	b	0x19e0 <kprobe_unwind_perl+0x19e0>
    1b30:      	ldr	w8, [x23]
    1b34:      	cbnz	w8, 0x2018 <kprobe_unwind_perl+0x2018>
    1b38:      	ldrb	w8, [sp, #0x7c]
    1b3c:      	and	w9, w8, #0xf
    1b40:      	sub	w10, w9, #0x9
    1b44:      	cmp	w10, #0x2
    1b48:      	b.hs	0x2060 <kprobe_unwind_perl+0x2060>
    1b4c:      	sxtb	w8, w8
    1b50:      	tbnz	w8, #0x1f, 0x2068 <kprobe_unwind_perl+0x2068>
    1b54:      	ldrb	w8, [x22, #0x1b]
    1b58:      	mov	w9, #0x8                // =8
    1b5c:      	mov	w10, #0x70              // =112
    1b60:      	add	x11, sp, #0x30
    1b64:      	add	x0, sp, #0x30
    1b68:      	mov	w1, #0x8                // =8
    1b6c:      	add	x8, x25, x8
    1b70:      	ldrb	w8, [x22, #0x1b]
    1b74:      	add	x2, x25, x8
    1b78:      	blr	x10
    1b7c:      	cbnz	x0, 0x1a74 <kprobe_unwind_perl+0x1a74>
    1b80:      	ldr	x8, [sp, #0x30]
    1b84:      	mov	w9, #0x8                // =8
    1b88:      	mov	w10, #0x70              // =112
    1b8c:      	add	x11, sp, #0x70
    1b90:      	add	x0, sp, #0x70
    1b94:      	mov	w1, #0x8                // =8
    1b98:      	cmp	x8, #0x0
    1b9c:      	mov	w8, #0x3                // =3
    1ba0:      	csinc	w29, w8, wzr, ne
    1ba4:      	ldrb	w8, [x22, #0x1c]
    1ba8:      	add	x8, x25, x8
    1bac:      	ldrb	w8, [x22, #0x1c]
    1bb0:      	add	x2, x25, x8
    1bb4:      	blr	x10
    1bb8:      	cbnz	x0, 0x1a74 <kprobe_unwind_perl+0x1a74>
    1bbc:      	str	x24, [sp, #0x10]
    1bc0:      	ldr	x24, [sp, #0x70]
    1bc4:      	mov	w9, #0x4                // =4
    1bc8:      	mov	w10, #0x70              // =112
    1bcc:      	add	x11, sp, #0xb8
    1bd0:      	add	x0, sp, #0xb8
    1bd4:      	ldrb	w8, [x22, #0x1e]
    1bd8:      	mov	w1, #0x4                // =4
    1bdc:      	add	x8, x24, x8
    1be0:      	ldrb	w8, [x22, #0x1e]
    1be4:      	add	x2, x24, x8
    1be8:      	blr	x10
    1bec:      	cbz	x0, 0x1c80 <kprobe_unwind_perl+0x1c80>
    1bf0:      	ldr	w8, [x23]
    1bf4:      	cbnz	w8, 0x3404 <kprobe_unwind_perl+0x3404>
    1bf8:      	mov	w8, #0x14               // =20
    1bfc:      	adrp	x0, 0x1000 <kprobe_unwind_perl+0x1000>
    1c00:      	add	x9, sp, #0xbc
    1c04:      	str	w8, [sp, #0xbc]
    1c08:      	mov	w8, #0x1                // =1
    1c0c:      	add	x1, sp, #0xbc
    1c10:      	ldr	x0, [x0]
    1c14:      	blr	x8
    1c18:      	cbz	x0, 0x1e08 <kprobe_unwind_perl+0x1e08>
    1c1c:      	ldr	x8, [x0]
    1c20:      	ldr	x24, [sp, #0x10]
    1c24:      	add	x8, x8, #0x1
    1c28:      	str	x8, [x0]
    1c2c:      	b	0x1a74 <kprobe_unwind_perl+0x1a74>
    1c30:      	ldr	w8, [x23]
    1c34:      	cbz	w8, 0x2068 <kprobe_unwind_perl+0x2068>
    1c38:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    1c3c:      	add	x8, x8, #0x0
    1c40:      	add	x0, sp, #0x30
    1c44:      	ldp	x9, x10, [x8, #0x10]
    1c48:      	mov	w1, #0x2e               // =46
    1c4c:      	stp	x9, x10, [sp, #0x40]
    1c50:      	ldr	x9, [x8, #0x20]
    1c54:      	add	x10, sp, #0x30
    1c58:      	str	x9, [sp, #0x50]
    1c5c:      	ldur	x9, [x8, #0x26]
    1c60:      	stur	x9, [sp, #0x56]
    1c64:      	ldp	x9, x8, [x8]
    1c68:      	stp	x9, x8, [sp, #0x30]
    1c6c:      	mov	w8, #0x2e               // =46
    1c70:      	mov	w9, #0x6                // =6
    1c74:      	ldr	w2, [sp, #0xa8]
    1c78:      	blr	x9
    1c7c:      	b	0x2068 <kprobe_unwind_perl+0x2068>
    1c80:      	ldr	w8, [sp, #0xb8]
    1c84:      	and	w8, w8, #0x1f
    1c88:      	cmp	w8, #0xd
    1c8c:      	b.ne	0x1e54 <kprobe_unwind_perl+0x1e54>
    1c90:      	ldrb	w8, [x22, #0x1f]
    1c94:      	mov	w9, #0x8                // =8
    1c98:      	mov	w10, #0x70              // =112
    1c9c:      	add	x11, sp, #0xa8
    1ca0:      	add	x0, sp, #0xa8
    1ca4:      	mov	w1, #0x8                // =8
    1ca8:      	add	x8, x24, x8
    1cac:      	ldrb	w8, [x22, #0x1f]
    1cb0:      	add	x2, x24, x8
    1cb4:      	blr	x10
    1cb8:      	cbnz	x0, 0x1bf0 <kprobe_unwind_perl+0x1bf0>
    1cbc:      	ldr	x8, [sp, #0xa8]
    1cc0:      	ldrb	w9, [x22, #0x21]
    1cc4:      	mov	w10, #0x70              // =112
    1cc8:      	add	x11, sp, #0xa4
    1ccc:      	add	x0, sp, #0xa4
    1cd0:      	mov	w1, #0x4                // =4
    1cd4:      	add	x8, x8, x9
    1cd8:      	mov	w9, #0x4                // =4
    1cdc:      	ldr	x8, [sp, #0xa8]
    1ce0:      	ldrb	w9, [x22, #0x21]
    1ce4:      	add	x2, x8, x9
    1ce8:      	blr	x10
    1cec:      	cbnz	x0, 0x1bf0 <kprobe_unwind_perl+0x1bf0>
    1cf0:      	ldrb	w8, [sp, #0xa5]
    1cf4:      	tbnz	w8, #0x7, 0x1fc8 <kprobe_unwind_perl+0x1fc8>
    1cf8:      	ldr	x8, [sp, #0xa8]
    1cfc:      	ldrb	w9, [x22, #0x22]
    1d00:      	mov	w10, #0x70              // =112
    1d04:      	add	x11, sp, #0x98
    1d08:      	add	x0, sp, #0x98
    1d0c:      	mov	w1, #0x8                // =8
    1d10:      	add	x8, x8, x9
    1d14:      	mov	w9, #0x8                // =8
    1d18:      	ldr	x8, [sp, #0xa8]
    1d1c:      	ldrb	w9, [x22, #0x22]
    1d20:      	add	x2, x8, x9
    1d24:      	blr	x10
    1d28:      	cbnz	x0, 0x1bf0 <kprobe_unwind_perl+0x1bf0>
    1d2c:      	ldr	x8, [sp, #0x98]
    1d30:      	cbz	x8, 0x1bf0 <kprobe_unwind_perl+0x1bf0>
    1d34:      	ldr	w9, [x23]
    1d38:      	cbnz	w9, 0x4c84 <kprobe_unwind_perl+0x4c84>
    1d3c:      	ldrb	w9, [x22, #0x1e]
    1d40:      	mov	w10, #0x70              // =112
    1d44:      	add	x11, sp, #0x94
    1d48:      	add	x0, sp, #0x94
    1d4c:      	mov	w1, #0x4                // =4
    1d50:      	add	x8, x8, x9
    1d54:      	mov	w9, #0x4                // =4
    1d58:      	ldr	x8, [sp, #0x98]
    1d5c:      	ldrb	w9, [x22, #0x1e]
    1d60:      	add	x2, x8, x9
    1d64:      	blr	x10
    1d68:      	cbnz	x0, 0x1bf0 <kprobe_unwind_perl+0x1bf0>
    1d6c:      	ldr	w8, [sp, #0x94]
    1d70:      	mov	w9, #0x801f             // =32799
    1d74:      	and	w8, w8, w9
    1d78:      	mov	w9, #0x8009             // =32777
    1d7c:      	cmp	w8, w9
    1d80:      	b.ne	0x2d14 <kprobe_unwind_perl+0x2d14>
    1d84:      	ldr	x8, [sp, #0x98]
    1d88:      	ldrb	w9, [x22, #0x20]
    1d8c:      	mov	w10, #0x70              // =112
    1d90:      	add	x11, sp, #0x88
    1d94:      	add	x0, sp, #0x88
    1d98:      	mov	w1, #0x8                // =8
    1d9c:      	add	x8, x8, x9
    1da0:      	mov	w9, #0x8                // =8
    1da4:      	ldr	x8, [sp, #0x98]
    1da8:      	ldrb	w9, [x22, #0x20]
    1dac:      	add	x2, x8, x9
    1db0:      	blr	x10
    1db4:      	cbnz	x0, 0x1bf0 <kprobe_unwind_perl+0x1bf0>
    1db8:      	ldr	x8, [sp, #0x88]
    1dbc:      	ldrb	w9, [x22, #0x23]
    1dc0:      	mov	w10, #0x70              // =112
    1dc4:      	add	x11, sp, #0x80
    1dc8:      	add	x0, sp, #0x80
    1dcc:      	mov	w1, #0x8                // =8
    1dd0:      	add	x8, x8, x9
    1dd4:      	mov	w9, #0x8                // =8
    1dd8:      	ldr	x8, [sp, #0x88]
    1ddc:      	ldrb	w9, [x22, #0x23]
    1de0:      	add	x2, x8, x9
    1de4:      	blr	x10
    1de8:      	cbnz	x0, 0x1bf0 <kprobe_unwind_perl+0x1bf0>
    1dec:      	ldr	x8, [sp, #0x80]
    1df0:      	str	x8, [sp, #0x8]
    1df4:      	cbz	x8, 0x3c7c <kprobe_unwind_perl+0x3c7c>
    1df8:      	ldr	w8, [x23]
    1dfc:      	cbnz	w8, 0x663c <kprobe_unwind_perl+0x663c>
    1e00:      	ldr	x24, [sp, #0x10]
    1e04:      	b	0x3c90 <kprobe_unwind_perl+0x3c90>
    1e08:      	ldr	w8, [x23]
    1e0c:      	cbz	w8, 0x1e5c <kprobe_unwind_perl+0x1e5c>
    1e10:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    1e14:      	add	x8, x8, #0x0
    1e18:      	add	x0, sp, #0x30
    1e1c:      	ldp	x9, x10, [x8, #0x10]
    1e20:      	mov	w1, #0x2e               // =46
    1e24:      	stp	x9, x10, [sp, #0x40]
    1e28:      	ldr	x9, [x8, #0x20]
    1e2c:      	add	x10, sp, #0x30
    1e30:      	str	x9, [sp, #0x50]
    1e34:      	ldur	x9, [x8, #0x26]
    1e38:      	stur	x9, [sp, #0x56]
    1e3c:      	ldp	x9, x8, [x8]
    1e40:      	stp	x9, x8, [sp, #0x30]
    1e44:      	mov	w8, #0x2e               // =46
    1e48:      	mov	w9, #0x6                // =6
    1e4c:      	ldr	w2, [sp, #0xbc]
    1e50:      	b	0x3be4 <kprobe_unwind_perl+0x3be4>
    1e54:      	ldr	w8, [x23]
    1e58:      	cbnz	w8, 0x3bac <kprobe_unwind_perl+0x3bac>
    1e5c:      	ldr	x24, [sp, #0x10]
    1e60:      	b	0x1a74 <kprobe_unwind_perl+0x1a74>
    1e64:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    1e68:      	add	x8, x8, #0x0
    1e6c:      	add	x0, sp, #0x30
    1e70:      	ldp	x9, x10, [x8, #0x10]
    1e74:      	mov	w1, #0x2e               // =46
    1e78:      	stp	x9, x10, [sp, #0x40]
    1e7c:      	ldr	x9, [x8, #0x20]
    1e80:      	add	x10, sp, #0x30
    1e84:      	str	x9, [sp, #0x50]
    1e88:      	ldur	x9, [x8, #0x26]
    1e8c:      	stur	x9, [sp, #0x56]
    1e90:      	ldp	x9, x8, [x8]
    1e94:      	stp	x9, x8, [sp, #0x30]
    1e98:      	mov	w8, #0x2e               // =46
    1e9c:      	mov	w9, #0x6                // =6
    1ea0:      	ldr	w2, [sp, #0xa8]
    1ea4:      	blr	x9
    1ea8:      	b	0x1a20 <kprobe_unwind_perl+0x1a20>
    1eac:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    1eb0:      	add	x8, x8, #0x0
    1eb4:      	add	x0, sp, #0x30
    1eb8:      	ldp	x9, x10, [x8, #0x10]
    1ebc:      	mov	w1, #0x2d               // =45
    1ec0:      	stp	x9, x10, [sp, #0x40]
    1ec4:      	ldr	x9, [x8, #0x20]
    1ec8:      	add	x10, sp, #0x30
    1ecc:      	str	x9, [sp, #0x50]
    1ed0:      	ldur	x9, [x8, #0x25]
    1ed4:      	stur	x9, [sp, #0x55]
    1ed8:      	ldp	x9, x8, [x8]
    1edc:      	stp	x9, x8, [sp, #0x30]
    1ee0:      	mov	w8, #0x2d               // =45
    1ee4:      	mov	w9, #0x6                // =6
    1ee8:      	blr	x9
    1eec:      	b	0x1f4 <kprobe_unwind_perl+0x1f4>
    1ef0:      	mov	w8, #0xa                // =10
    1ef4:      	add	x0, sp, #0x30
    1ef8:      	mov	w1, #0x2a               // =42
    1efc:      	strh	w8, [sp, #0x58]
    1f00:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    1f04:      	add	x8, x8, #0x0
    1f08:      	mov	x2, x25
    1f0c:      	ldp	x9, x10, [x8, #0x10]
    1f10:      	stp	x9, x10, [sp, #0x40]
    1f14:      	ldr	x9, [x8, #0x20]
    1f18:      	add	x10, sp, #0x30
    1f1c:      	str	x9, [sp, #0x50]
    1f20:      	ldp	x8, x9, [x8]
    1f24:      	stp	x8, x9, [sp, #0x30]
    1f28:      	mov	w8, #0x2a               // =42
    1f2c:      	mov	w9, #0x6                // =6
    1f30:      	blr	x9
    1f34:      	b	0x1a7c <kprobe_unwind_perl+0x1a7c>
    1f38:      	ldr	w8, [x23]
    1f3c:      	ldr	x24, [sp, #0x10]
    1f40:      	cbz	w8, 0xcd8 <kprobe_unwind_perl+0xcd8>
    1f44:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    1f48:      	add	x8, x8, #0x0
    1f4c:      	add	x0, sp, #0x30
    1f50:      	ldp	x9, x10, [x8, #0x10]
    1f54:      	mov	w1, #0x26               // =38
    1f58:      	stp	x9, x10, [sp, #0x40]
    1f5c:      	ldur	x9, [x8, #0x1e]
    1f60:      	add	x10, sp, #0x30
    1f64:      	stur	x9, [sp, #0x4e]
    1f68:      	ldp	x8, x9, [x8]
    1f6c:      	stp	x8, x9, [sp, #0x30]
    1f70:      	mov	w8, #0x26               // =38
    1f74:      	mov	w9, #0x6                // =6
    1f78:      	ldr	w2, [sp, #0x94]
    1f7c:      	blr	x9
    1f80:      	b	0xcd8 <kprobe_unwind_perl+0xcd8>
    1f84:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    1f88:      	add	x8, x8, #0x0
    1f8c:      	add	x0, sp, #0x30
    1f90:      	ldp	x9, x10, [x8, #0x10]
    1f94:      	mov	w1, #0x26               // =38
    1f98:      	stp	x9, x10, [sp, #0x40]
    1f9c:      	ldur	x9, [x8, #0x1e]
    1fa0:      	add	x10, sp, #0x30
    1fa4:      	stur	x9, [sp, #0x4e]
    1fa8:      	ldp	x8, x9, [x8]
    1fac:      	stp	x8, x9, [sp, #0x30]
    1fb0:      	mov	w8, #0x26               // =38
    1fb4:      	mov	w9, #0x6                // =6
    1fb8:      	ldr	x2, [sp, #0xa8]
    1fbc:      	ldr	w3, [sp, #0x80]
    1fc0:      	blr	x9
    1fc4:      	b	0x9ec <kprobe_unwind_perl+0x9ec>
    1fc8:      	ldr	w8, [x23]
    1fcc:      	cbz	w8, 0x1e5c <kprobe_unwind_perl+0x1e5c>
    1fd0:      	adrp	x8, 0x1000 <kprobe_unwind_perl+0x1000>
    1fd4:      	add	x8, x8, #0x0
    1fd8:      	add	x0, sp, #0x30
    1fdc:      	ldp	x9, x10, [x8, #0x10]
    1fe0:      	mov	w1, #0x26               // =38
    1fe4:      	stp	x9, x10, [sp, #0x40]
    1fe8:      	ldur	x9, [x8, #0x1e]
    1fec:      	add	x10, sp, #0x30
    1ff0:      	stur	x9, [sp, #0x4e]
    1ff4:      	ldp	x8, x9, [x8]
    1ff8:      	stp	x8, x9, [sp, #0x30]
    1ffc:      	mov	w8, #0x26               // =38
    2000:      	mov	w9, #0x6                // =6
    2004:      	ldr	w2, [sp, #0xb8]
    2008:      	ldr	w3, [sp, #0xa4]
    200c:      	blr	x9
    2010:      	ldr	x24, [sp, #0x10]
    2014:      	b	0x1a74 <kprobe_unwind_perl+0x1a74>
    2018:      	mov	w8, #0xa                // =10
    201c:      	add	x10, sp, #0x30
    2020:      	add	x0, sp, #0x30
    2024:      	strh	w8, [sp, #0x40]
    2028:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    202c:      	add	x8, x8, #0x0
    2030:      	mov	w1, #0x12               // =18
    2034:      	ldp	x9, x8, [x8]
    2038:      	stp	x9, x8, [sp, #0x30]
    203c:      	mov	w8, #0x12               // =18
    2040:      	mov	w9, #0x6                // =6
    2044:      	ldrb	w2, [sp, #0x7c]
    2048:      	blr	x9
    204c:      	ldrb	w8, [sp, #0x7c]
    2050:      	and	w9, w8, #0xf
    2054:      	sub	w10, w9, #0x9
    2058:      	cmp	w10, #0x2
    205c:      	b.lo	0x1b4c <kprobe_unwind_perl+0x1b4c>
    2060:      	cmp	w9, #0xc
    2064:      	b.ne	0x2140 <kprobe_unwind_perl+0x2140>
    2068:      	mov	w29, #0x3               // =3
    206c:      	ldrb	w8, [x22, #0x1d]
    2070:      	ldr	x9, [x21, #0xf40]
    2074:      	adrp	x0, 0x2000 <kprobe_unwind_perl+0x2000>
    2078:      	add	x1, sp, #0xa8
    207c:      	sub	x8, x9, x8
    2080:      	add	x9, sp, #0xa8
    2084:      	str	x8, [x21, #0xf40]
    2088:      	mov	w8, #0x10               // =16
    208c:      	str	w8, [sp, #0xa8]
    2090:      	mov	w8, #0x1                // =1
    2094:      	ldr	x0, [x0]
    2098:      	blr	x8
    209c:      	cbz	x0, 0x20b4 <kprobe_unwind_perl+0x20b4>
    20a0:      	ldr	x8, [x0]
    20a4:      	add	x8, x8, #0x1
    20a8:      	str	x8, [x0]
    20ac:      	ldr	x9, [sp, #0x18]
    20b0:      	b	0x20c0 <kprobe_unwind_perl+0x20c0>
    20b4:      	ldr	w8, [x23]
    20b8:      	ldr	x9, [sp, #0x18]
    20bc:      	cbnz	w8, 0x2534 <kprobe_unwind_perl+0x2534>
    20c0:      	cmp	w29, #0x3
    20c4:      	b.ne	0x563c <kprobe_unwind_perl+0x563c>
    20c8:      	ldr	x25, [x21, #0xf40]
    20cc:      	cmp	x25, x9
    20d0:      	b.lo	0xac <kprobe_unwind_perl+0xac>
    20d4:      	ldrb	w8, [x22, #0x19]
    20d8:      	mov	w9, #0x1                // =1
    20dc:      	mov	w10, #0x70              // =112
    20e0:      	add	x11, sp, #0x7c
    20e4:      	add	x0, sp, #0x7c
    20e8:      	mov	w1, #0x1                // =1
    20ec:      	add	x8, x25, x8
    20f0:      	ldrb	w8, [x22, #0x19]
    20f4:      	add	x2, x25, x8
    20f8:      	blr	x10
    20fc:      	cbz	x0, 0x21bc <kprobe_unwind_perl+0x21bc>
    2100:      	ldr	w8, [x23]
    2104:      	cbnz	w8, 0x25c0 <kprobe_unwind_perl+0x25c0>
    2108:      	mov	w8, #0x13               // =19
    210c:      	adrp	x0, 0x2000 <kprobe_unwind_perl+0x2000>
    2110:      	add	x9, sp, #0xa8
    2114:      	str	w8, [sp, #0xa8]
    2118:      	mov	w8, #0x1                // =1
    211c:      	add	x1, sp, #0xa8
    2120:      	ldr	x0, [x0]
    2124:      	blr	x8
    2128:      	cbz	x0, 0x2218 <kprobe_unwind_perl+0x2218>
    212c:      	ldr	x8, [x0]
    2130:      	mov	w29, #0x3               // =3
    2134:      	add	x8, x8, #0x1
    2138:      	str	x8, [x0]
    213c:      	b	0x2760 <kprobe_unwind_perl+0x2760>
    2140:      	ldr	x8, [x24]
    2144:      	mov	w29, #0x3               // =3
    2148:      	cbnz	x8, 0x206c <kprobe_unwind_perl+0x206c>
    214c:      	ldrb	w8, [x22, #0x1a]
    2150:      	mov	w9, #0x8                // =8
    2154:      	mov	w10, #0x70              // =112
    2158:      	mov	x0, x24
    215c:      	mov	w1, #0x8                // =8
    2160:      	add	x8, x25, x8
    2164:      	ldrb	w8, [x22, #0x1a]
    2168:      	add	x2, x25, x8
    216c:      	blr	x10
    2170:      	cbnz	x0, 0x1a74 <kprobe_unwind_perl+0x1a74>
    2174:      	ldr	w8, [x23]
    2178:      	cbz	w8, 0x206c <kprobe_unwind_perl+0x206c>
    217c:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    2180:      	add	x8, x8, #0x0
    2184:      	add	x0, sp, #0x30
    2188:      	ldp	x9, x10, [x8]
    218c:      	mov	w1, #0x1e               // =30
    2190:      	stp	x9, x10, [sp, #0x30]
    2194:      	ldr	x9, [x8, #0x10]
    2198:      	ldur	x8, [x8, #0x16]
    219c:      	add	x10, sp, #0x30
    21a0:      	str	x9, [sp, #0x40]
    21a4:      	stur	x8, [sp, #0x46]
    21a8:      	mov	w8, #0x1e               // =30
    21ac:      	mov	w9, #0x6                // =6
    21b0:      	ldr	x2, [x24]
    21b4:      	blr	x9
    21b8:      	b	0x206c <kprobe_unwind_perl+0x206c>
    21bc:      	ldr	w8, [x23]
    21c0:      	cbnz	w8, 0x270c <kprobe_unwind_perl+0x270c>
    21c4:      	ldrb	w8, [sp, #0x7c]
    21c8:      	and	w9, w8, #0xf
    21cc:      	sub	w10, w9, #0x9
    21d0:      	cmp	w10, #0x2
    21d4:      	b.hs	0x2754 <kprobe_unwind_perl+0x2754>
    21d8:      	sxtb	w8, w8
    21dc:      	tbnz	w8, #0x1f, 0x275c <kprobe_unwind_perl+0x275c>
    21e0:      	ldrb	w8, [x22, #0x1b]
    21e4:      	str	x24, [sp, #0x10]
    21e8:      	mov	w9, #0x8                // =8
    21ec:      	mov	w10, #0x70              // =112
    21f0:      	add	x11, sp, #0x30
    21f4:      	add	x0, sp, #0x30
    21f8:      	mov	w1, #0x8                // =8
    21fc:      	add	x8, x25, x8
    2200:      	ldrb	w8, [x22, #0x1b]
    2204:      	add	x2, x25, x8
    2208:      	blr	x10
    220c:      	cbz	x0, 0x2268 <kprobe_unwind_perl+0x2268>
    2210:      	ldr	x24, [sp, #0x10]
    2214:      	b	0x2100 <kprobe_unwind_perl+0x2100>
    2218:      	ldr	w8, [x23]
    221c:      	cbz	w8, 0x275c <kprobe_unwind_perl+0x275c>
    2220:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    2224:      	add	x8, x8, #0x0
    2228:      	add	x0, sp, #0x30
    222c:      	ldp	x9, x10, [x8, #0x10]
    2230:      	mov	w1, #0x2e               // =46
    2234:      	stp	x9, x10, [sp, #0x40]
    2238:      	ldr	x9, [x8, #0x20]
    223c:      	add	x10, sp, #0x30
    2240:      	str	x9, [sp, #0x50]
    2244:      	ldur	x9, [x8, #0x26]
    2248:      	stur	x9, [sp, #0x56]
    224c:      	ldp	x9, x8, [x8]
    2250:      	stp	x9, x8, [sp, #0x30]
    2254:      	mov	w8, #0x2e               // =46
    2258:      	mov	w9, #0x6                // =6
    225c:      	ldr	w2, [sp, #0xa8]
    2260:      	blr	x9
    2264:      	b	0x275c <kprobe_unwind_perl+0x275c>
    2268:      	ldr	x8, [sp, #0x30]
    226c:      	mov	w9, #0x8                // =8
    2270:      	mov	w10, #0x70              // =112
    2274:      	add	x11, sp, #0x70
    2278:      	add	x0, sp, #0x70
    227c:      	mov	w1, #0x8                // =8
    2280:      	cmp	x8, #0x0
    2284:      	mov	w8, #0x3                // =3
    2288:      	csinc	w29, w8, wzr, ne
    228c:      	ldrb	w8, [x22, #0x1c]
    2290:      	add	x8, x25, x8
    2294:      	ldrb	w8, [x22, #0x1c]
    2298:      	add	x2, x25, x8
    229c:      	blr	x10
    22a0:      	ldr	x24, [sp, #0x10]
    22a4:      	cbnz	x0, 0x2100 <kprobe_unwind_perl+0x2100>
    22a8:      	ldr	x24, [sp, #0x70]
    22ac:      	ldrb	w8, [x22, #0x1e]
    22b0:      	mov	w9, #0x4                // =4
    22b4:      	mov	w10, #0x70              // =112
    22b8:      	add	x11, sp, #0xb8
    22bc:      	add	x0, sp, #0xb8
    22c0:      	mov	w1, #0x4                // =4
    22c4:      	add	x8, x24, x8
    22c8:      	ldrb	w8, [x22, #0x1e]
    22cc:      	add	x2, x24, x8
    22d0:      	blr	x10
    22d4:      	cbz	x0, 0x2318 <kprobe_unwind_perl+0x2318>
    22d8:      	ldr	w8, [x23]
    22dc:      	cbnz	w8, 0x3b68 <kprobe_unwind_perl+0x3b68>
    22e0:      	mov	w8, #0x14               // =20
    22e4:      	adrp	x0, 0x2000 <kprobe_unwind_perl+0x2000>
    22e8:      	add	x9, sp, #0xbc
    22ec:      	str	w8, [sp, #0xbc]
    22f0:      	mov	w8, #0x1                // =1
    22f4:      	add	x1, sp, #0xbc
    22f8:      	ldr	x0, [x0]
    22fc:      	blr	x8
    2300:      	cbz	x0, 0x24a0 <kprobe_unwind_perl+0x24a0>
    2304:      	ldr	x8, [x0]
    2308:      	ldr	x24, [sp, #0x10]
    230c:      	add	x8, x8, #0x1
    2310:      	str	x8, [x0]
    2314:      	b	0x2100 <kprobe_unwind_perl+0x2100>
    2318:      	ldr	w8, [sp, #0xb8]
    231c:      	and	w8, w8, #0x1f
    2320:      	cmp	w8, #0xd
    2324:      	b.ne	0x24ec <kprobe_unwind_perl+0x24ec>
    2328:      	ldrb	w8, [x22, #0x1f]
    232c:      	mov	w9, #0x8                // =8
    2330:      	mov	w10, #0x70              // =112
    2334:      	add	x11, sp, #0xa8
    2338:      	add	x0, sp, #0xa8
    233c:      	mov	w1, #0x8                // =8
    2340:      	add	x8, x24, x8
    2344:      	ldrb	w8, [x22, #0x1f]
    2348:      	add	x2, x24, x8
    234c:      	blr	x10
    2350:      	cbnz	x0, 0x22d8 <kprobe_unwind_perl+0x22d8>
    2354:      	ldr	x8, [sp, #0xa8]
    2358:      	ldrb	w9, [x22, #0x21]
    235c:      	mov	w10, #0x70              // =112
    2360:      	add	x11, sp, #0xa4
    2364:      	add	x0, sp, #0xa4
    2368:      	mov	w1, #0x4                // =4
    236c:      	add	x8, x8, x9
    2370:      	mov	w9, #0x4                // =4
    2374:      	ldr	x8, [sp, #0xa8]
    2378:      	ldrb	w9, [x22, #0x21]
    237c:      	add	x2, x8, x9
    2380:      	blr	x10
    2384:      	cbnz	x0, 0x22d8 <kprobe_unwind_perl+0x22d8>
    2388:      	ldrb	w8, [sp, #0xa5]
    238c:      	tbnz	w8, #0x7, 0x26bc <kprobe_unwind_perl+0x26bc>
    2390:      	ldr	x8, [sp, #0xa8]
    2394:      	ldrb	w9, [x22, #0x22]
    2398:      	mov	w10, #0x70              // =112
    239c:      	add	x11, sp, #0x98
    23a0:      	add	x0, sp, #0x98
    23a4:      	mov	w1, #0x8                // =8
    23a8:      	add	x8, x8, x9
    23ac:      	mov	w9, #0x8                // =8
    23b0:      	ldr	x8, [sp, #0xa8]
    23b4:      	ldrb	w9, [x22, #0x22]
    23b8:      	add	x2, x8, x9
    23bc:      	blr	x10
    23c0:      	cbnz	x0, 0x22d8 <kprobe_unwind_perl+0x22d8>
    23c4:      	ldr	x8, [sp, #0x98]
    23c8:      	cbz	x8, 0x22d8 <kprobe_unwind_perl+0x22d8>
    23cc:      	ldr	w9, [x23]
    23d0:      	cbnz	w9, 0x5510 <kprobe_unwind_perl+0x5510>
    23d4:      	ldrb	w9, [x22, #0x1e]
    23d8:      	mov	w10, #0x70              // =112
    23dc:      	add	x11, sp, #0x94
    23e0:      	add	x0, sp, #0x94
    23e4:      	mov	w1, #0x4                // =4
    23e8:      	add	x8, x8, x9
    23ec:      	mov	w9, #0x4                // =4
    23f0:      	ldr	x8, [sp, #0x98]
    23f4:      	ldrb	w9, [x22, #0x1e]
    23f8:      	add	x2, x8, x9
    23fc:      	blr	x10
    2400:      	cbnz	x0, 0x22d8 <kprobe_unwind_perl+0x22d8>
    2404:      	ldr	w8, [sp, #0x94]
    2408:      	mov	w9, #0x801f             // =32799
    240c:      	and	w8, w8, w9
    2410:      	mov	w9, #0x8009             // =32777
    2414:      	cmp	w8, w9
    2418:      	b.ne	0x3490 <kprobe_unwind_perl+0x3490>
    241c:      	ldr	x8, [sp, #0x98]
    2420:      	ldrb	w9, [x22, #0x20]
    2424:      	mov	w10, #0x70              // =112
    2428:      	add	x11, sp, #0x88
    242c:      	add	x0, sp, #0x88
    2430:      	mov	w1, #0x8                // =8
    2434:      	add	x8, x8, x9
    2438:      	mov	w9, #0x8                // =8
    243c:      	ldr	x8, [sp, #0x98]
    2440:      	ldrb	w9, [x22, #0x20]
    2444:      	add	x2, x8, x9
    2448:      	blr	x10
    244c:      	cbnz	x0, 0x22d8 <kprobe_unwind_perl+0x22d8>
    2450:      	ldr	x8, [sp, #0x88]
    2454:      	ldrb	w9, [x22, #0x23]
    2458:      	mov	w10, #0x70              // =112
    245c:      	add	x11, sp, #0x80
    2460:      	add	x0, sp, #0x80
    2464:      	mov	w1, #0x8                // =8
    2468:      	add	x8, x8, x9
    246c:      	mov	w9, #0x8                // =8
    2470:      	ldr	x8, [sp, #0x88]
    2474:      	ldrb	w9, [x22, #0x23]
    2478:      	add	x2, x8, x9
    247c:      	blr	x10
    2480:      	cbnz	x0, 0x22d8 <kprobe_unwind_perl+0x22d8>
    2484:      	ldr	x8, [sp, #0x80]
    2488:      	str	x8, [sp, #0x8]
    248c:      	cbz	x8, 0x43e4 <kprobe_unwind_perl+0x43e4>
    2490:      	ldr	w8, [x23]
    2494:      	cbnz	w8, 0x680c <kprobe_unwind_perl+0x680c>
    2498:      	ldr	x24, [sp, #0x10]
    249c:      	b	0x43f8 <kprobe_unwind_perl+0x43f8>
    24a0:      	ldr	w8, [x23]
    24a4:      	cbz	w8, 0x2210 <kprobe_unwind_perl+0x2210>
    24a8:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    24ac:      	add	x8, x8, #0x0
    24b0:      	add	x0, sp, #0x30
    24b4:      	ldp	x9, x10, [x8, #0x10]
    24b8:      	mov	w1, #0x2e               // =46
    24bc:      	stp	x9, x10, [sp, #0x40]
    24c0:      	ldr	x9, [x8, #0x20]
    24c4:      	add	x10, sp, #0x30
    24c8:      	str	x9, [sp, #0x50]
    24cc:      	ldur	x9, [x8, #0x26]
    24d0:      	stur	x9, [sp, #0x56]
    24d4:      	ldp	x9, x8, [x8]
    24d8:      	stp	x9, x8, [sp, #0x30]
    24dc:      	mov	w8, #0x2e               // =46
    24e0:      	mov	w9, #0x6                // =6
    24e4:      	ldr	w2, [sp, #0xbc]
    24e8:      	b	0x252c <kprobe_unwind_perl+0x252c>
    24ec:      	ldr	w8, [x23]
    24f0:      	cbz	w8, 0x2210 <kprobe_unwind_perl+0x2210>
    24f4:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    24f8:      	add	x8, x8, #0x0
    24fc:      	add	x0, sp, #0x30
    2500:      	ldp	x9, x10, [x8]
    2504:      	mov	w1, #0x1e               // =30
    2508:      	stp	x9, x10, [sp, #0x30]
    250c:      	ldr	x9, [x8, #0x10]
    2510:      	ldur	x8, [x8, #0x16]
    2514:      	add	x10, sp, #0x30
    2518:      	str	x9, [sp, #0x40]
    251c:      	stur	x8, [sp, #0x46]
    2520:      	mov	w8, #0x1e               // =30
    2524:      	mov	w9, #0x6                // =6
    2528:      	ldr	w2, [sp, #0xb8]
    252c:      	blr	x9
    2530:      	b	0x2210 <kprobe_unwind_perl+0x2210>
    2534:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    2538:      	add	x8, x8, #0x0
    253c:      	add	x0, sp, #0x30
    2540:      	ldp	x9, x10, [x8, #0x10]
    2544:      	mov	w1, #0x2e               // =46
    2548:      	stp	x9, x10, [sp, #0x40]
    254c:      	ldr	x9, [x8, #0x20]
    2550:      	add	x10, sp, #0x30
    2554:      	str	x9, [sp, #0x50]
    2558:      	ldur	x9, [x8, #0x26]
    255c:      	stur	x9, [sp, #0x56]
    2560:      	ldp	x9, x8, [x8]
    2564:      	stp	x9, x8, [sp, #0x30]
    2568:      	mov	w8, #0x2e               // =46
    256c:      	mov	w9, #0x6                // =6
    2570:      	ldr	w2, [sp, #0xa8]
    2574:      	blr	x9
    2578:      	b	0x20ac <kprobe_unwind_perl+0x20ac>
    257c:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    2580:      	add	x8, x8, #0x0
    2584:      	add	x0, sp, #0x30
    2588:      	ldp	x9, x10, [x8, #0x10]
    258c:      	mov	w1, #0x2d               // =45
    2590:      	stp	x9, x10, [sp, #0x40]
    2594:      	ldr	x9, [x8, #0x20]
    2598:      	add	x10, sp, #0x30
    259c:      	str	x9, [sp, #0x50]
    25a0:      	ldur	x9, [x8, #0x25]
    25a4:      	stur	x9, [sp, #0x55]
    25a8:      	ldp	x9, x8, [x8]
    25ac:      	stp	x9, x8, [sp, #0x30]
    25b0:      	mov	w8, #0x2d               // =45
    25b4:      	mov	w9, #0x6                // =6
    25b8:      	blr	x9
    25bc:      	b	0xe5c <kprobe_unwind_perl+0xe5c>
    25c0:      	mov	w8, #0xa                // =10
    25c4:      	add	x0, sp, #0x30
    25c8:      	mov	w1, #0x2a               // =42
    25cc:      	strh	w8, [sp, #0x58]
    25d0:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    25d4:      	add	x8, x8, #0x0
    25d8:      	mov	x2, x25
    25dc:      	ldp	x9, x10, [x8, #0x10]
    25e0:      	stp	x9, x10, [sp, #0x40]
    25e4:      	ldr	x9, [x8, #0x20]
    25e8:      	add	x10, sp, #0x30
    25ec:      	str	x9, [sp, #0x50]
    25f0:      	ldp	x8, x9, [x8]
    25f4:      	stp	x8, x9, [sp, #0x30]
    25f8:      	mov	w8, #0x2a               // =42
    25fc:      	mov	w9, #0x6                // =6
    2600:      	blr	x9
    2604:      	b	0x2108 <kprobe_unwind_perl+0x2108>
    2608:      	ldr	w8, [x23]
    260c:      	ldr	x24, [sp, #0x10]
    2610:      	cbz	w8, 0x131c <kprobe_unwind_perl+0x131c>
    2614:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    2618:      	add	x8, x8, #0x0
    261c:      	add	x0, sp, #0x30
    2620:      	ldp	x9, x10, [x8, #0x10]
    2624:      	mov	w1, #0x26               // =38
    2628:      	stp	x9, x10, [sp, #0x40]
    262c:      	ldur	x9, [x8, #0x1e]
    2630:      	add	x10, sp, #0x30
    2634:      	stur	x9, [sp, #0x4e]
    2638:      	ldp	x8, x9, [x8]
    263c:      	stp	x8, x9, [sp, #0x30]
    2640:      	mov	w8, #0x26               // =38
    2644:      	mov	w9, #0x6                // =6
    2648:      	ldr	w2, [sp, #0x94]
    264c:      	blr	x9
    2650:      	b	0x131c <kprobe_unwind_perl+0x131c>
    2654:      	add	x8, sp, #0x98
    2658:      	ldr	x8, [x8]
    265c:      	ldr	x24, [sp, #0x10]
    2660:      	str	x8, [sp, #0x8]
    2664:      	cbz	x8, 0xf0 <kprobe_unwind_perl+0xf0>
    2668:      	ldr	x24, [x24]
    266c:      	ldr	w8, [x23]
    2670:      	cbnz	w8, 0x4b4c <kprobe_unwind_perl+0x4b4c>
    2674:      	ldr	w8, [x21, #0x2c0]
    2678:      	cmp	w8, #0x7f
    267c:      	b.lo	0x4b98 <kprobe_unwind_perl+0x4b98>
    2680:      	ldr	w8, [x23]
    2684:      	cbnz	w8, 0x4d10 <kprobe_unwind_perl+0x4d10>
    2688:      	mov	w8, #0x2                // =2
    268c:      	adrp	x0, 0x2000 <kprobe_unwind_perl+0x2000>
    2690:      	add	x9, sp, #0xa8
    2694:      	str	w8, [sp, #0xa8]
    2698:      	mov	w8, #0x1                // =1
    269c:      	add	x1, sp, #0xa8
    26a0:      	ldr	x0, [x0]
    26a4:      	blr	x8
    26a8:      	cbz	x0, 0x2c64 <kprobe_unwind_perl+0x2c64>
    26ac:      	ldr	x8, [x0]
    26b0:      	add	x8, x8, #0x1
    26b4:      	str	x8, [x0]
    26b8:      	b	0x2c6c <kprobe_unwind_perl+0x2c6c>
    26bc:      	ldr	w8, [x23]
    26c0:      	cbz	w8, 0x2210 <kprobe_unwind_perl+0x2210>
    26c4:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    26c8:      	add	x8, x8, #0x0
    26cc:      	add	x0, sp, #0x30
    26d0:      	ldp	x9, x10, [x8, #0x10]
    26d4:      	mov	w1, #0x26               // =38
    26d8:      	stp	x9, x10, [sp, #0x40]
    26dc:      	ldur	x9, [x8, #0x1e]
    26e0:      	add	x10, sp, #0x30
    26e4:      	stur	x9, [sp, #0x4e]
    26e8:      	ldp	x8, x9, [x8]
    26ec:      	stp	x8, x9, [sp, #0x30]
    26f0:      	mov	w8, #0x26               // =38
    26f4:      	mov	w9, #0x6                // =6
    26f8:      	ldr	w2, [sp, #0xb8]
    26fc:      	ldr	w3, [sp, #0xa4]
    2700:      	blr	x9
    2704:      	ldr	x24, [sp, #0x10]
    2708:      	b	0x2100 <kprobe_unwind_perl+0x2100>
    270c:      	mov	w8, #0xa                // =10
    2710:      	add	x10, sp, #0x30
    2714:      	add	x0, sp, #0x30
    2718:      	strh	w8, [sp, #0x40]
    271c:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    2720:      	add	x8, x8, #0x0
    2724:      	mov	w1, #0x12               // =18
    2728:      	ldp	x9, x8, [x8]
    272c:      	stp	x9, x8, [sp, #0x30]
    2730:      	mov	w8, #0x12               // =18
    2734:      	mov	w9, #0x6                // =6
    2738:      	ldrb	w2, [sp, #0x7c]
    273c:      	blr	x9
    2740:      	ldrb	w8, [sp, #0x7c]
    2744:      	and	w9, w8, #0xf
    2748:      	sub	w10, w9, #0x9
    274c:      	cmp	w10, #0x2
    2750:      	b.lo	0x21d8 <kprobe_unwind_perl+0x21d8>
    2754:      	cmp	w9, #0xc
    2758:      	b.ne	0x2838 <kprobe_unwind_perl+0x2838>
    275c:      	mov	w29, #0x3               // =3
    2760:      	ldrb	w8, [x22, #0x1d]
    2764:      	ldr	x9, [x21, #0xf40]
    2768:      	adrp	x0, 0x2000 <kprobe_unwind_perl+0x2000>
    276c:      	add	x1, sp, #0xa8
    2770:      	sub	x8, x9, x8
    2774:      	add	x9, sp, #0xa8
    2778:      	str	x8, [x21, #0xf40]
    277c:      	mov	w8, #0x10               // =16
    2780:      	str	w8, [sp, #0xa8]
    2784:      	mov	w8, #0x1                // =1
    2788:      	ldr	x0, [x0]
    278c:      	blr	x8
    2790:      	cbz	x0, 0x27a8 <kprobe_unwind_perl+0x27a8>
    2794:      	ldr	x8, [x0]
    2798:      	add	x8, x8, #0x1
    279c:      	str	x8, [x0]
    27a0:      	ldr	x9, [sp, #0x18]
    27a4:      	b	0x27b4 <kprobe_unwind_perl+0x27b4>
    27a8:      	ldr	w8, [x23]
    27ac:      	ldr	x9, [sp, #0x18]
    27b0:      	cbnz	w8, 0x2c1c <kprobe_unwind_perl+0x2c1c>
    27b4:      	cmp	w29, #0x3
    27b8:      	b.ne	0x563c <kprobe_unwind_perl+0x563c>
    27bc:      	ldr	x25, [x21, #0xf40]
    27c0:      	cmp	x25, x9
    27c4:      	b.lo	0xac <kprobe_unwind_perl+0xac>
    27c8:      	ldrb	w8, [x22, #0x19]
    27cc:      	mov	w9, #0x1                // =1
    27d0:      	mov	w10, #0x70              // =112
    27d4:      	add	x11, sp, #0x7c
    27d8:      	add	x0, sp, #0x7c
    27dc:      	mov	w1, #0x1                // =1
    27e0:      	add	x8, x25, x8
    27e4:      	ldrb	w8, [x22, #0x19]
    27e8:      	add	x2, x25, x8
    27ec:      	blr	x10
    27f0:      	str	x24, [sp, #0x10]
    27f4:      	cbz	x0, 0x28b4 <kprobe_unwind_perl+0x28b4>
    27f8:      	ldr	w8, [x23]
    27fc:      	cbnz	w8, 0x2ccc <kprobe_unwind_perl+0x2ccc>
    2800:      	mov	w8, #0x13               // =19
    2804:      	adrp	x0, 0x2000 <kprobe_unwind_perl+0x2000>
    2808:      	add	x9, sp, #0xa8
    280c:      	str	w8, [sp, #0xa8]
    2810:      	mov	w8, #0x1                // =1
    2814:      	add	x1, sp, #0xa8
    2818:      	ldr	x0, [x0]
    281c:      	blr	x8
    2820:      	cbz	x0, 0x29ac <kprobe_unwind_perl+0x29ac>
    2824:      	ldr	x8, [x0]
    2828:      	mov	w29, #0x3               // =3
    282c:      	add	x8, x8, #0x1
    2830:      	str	x8, [x0]
    2834:      	b	0x2e5c <kprobe_unwind_perl+0x2e5c>
    2838:      	ldr	x8, [x24]
    283c:      	mov	w29, #0x3               // =3
    2840:      	cbnz	x8, 0x2760 <kprobe_unwind_perl+0x2760>
    2844:      	ldrb	w8, [x22, #0x1a]
    2848:      	mov	w9, #0x8                // =8
    284c:      	mov	w10, #0x70              // =112
    2850:      	mov	x0, x24
    2854:      	mov	w1, #0x8                // =8
    2858:      	add	x8, x25, x8
    285c:      	ldrb	w8, [x22, #0x1a]
    2860:      	add	x2, x25, x8
    2864:      	blr	x10
    2868:      	cbnz	x0, 0x2100 <kprobe_unwind_perl+0x2100>
    286c:      	ldr	w8, [x23]
    2870:      	cbz	w8, 0x2760 <kprobe_unwind_perl+0x2760>
    2874:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    2878:      	add	x8, x8, #0x0
    287c:      	add	x0, sp, #0x30
    2880:      	ldp	x9, x10, [x8]
    2884:      	mov	w1, #0x1e               // =30
    2888:      	stp	x9, x10, [sp, #0x30]
    288c:      	ldr	x9, [x8, #0x10]
    2890:      	ldur	x8, [x8, #0x16]
    2894:      	add	x10, sp, #0x30
    2898:      	str	x9, [sp, #0x40]
    289c:      	stur	x8, [sp, #0x46]
    28a0:      	mov	w8, #0x1e               // =30
    28a4:      	mov	w9, #0x6                // =6
    28a8:      	ldr	x2, [x24]
    28ac:      	blr	x9
    28b0:      	b	0x2760 <kprobe_unwind_perl+0x2760>
    28b4:      	ldr	w8, [x23]
    28b8:      	cbnz	w8, 0x2e08 <kprobe_unwind_perl+0x2e08>
    28bc:      	ldrb	w8, [sp, #0x7c]
    28c0:      	and	w9, w8, #0xf
    28c4:      	sub	w10, w9, #0x9
    28c8:      	cmp	w10, #0x2
    28cc:      	b.hs	0x2e50 <kprobe_unwind_perl+0x2e50>
    28d0:      	sxtb	w8, w8
    28d4:      	tbnz	w8, #0x1f, 0x2e58 <kprobe_unwind_perl+0x2e58>
    28d8:      	ldrb	w8, [x22, #0x1b]
    28dc:      	mov	w9, #0x8                // =8
    28e0:      	mov	w10, #0x70              // =112
    28e4:      	add	x11, sp, #0x30
    28e8:      	add	x0, sp, #0x30
    28ec:      	mov	w1, #0x8                // =8
    28f0:      	add	x8, x25, x8
    28f4:      	ldrb	w8, [x22, #0x1b]
    28f8:      	add	x2, x25, x8
    28fc:      	blr	x10
    2900:      	cbnz	x0, 0x27f8 <kprobe_unwind_perl+0x27f8>
    2904:      	ldr	x8, [sp, #0x30]
    2908:      	mov	w9, #0x8                // =8
    290c:      	mov	w10, #0x70              // =112
    2910:      	add	x11, sp, #0x70
    2914:      	add	x0, sp, #0x70
    2918:      	mov	w1, #0x8                // =8
    291c:      	cmp	x8, #0x0
    2920:      	mov	w8, #0x3                // =3
    2924:      	csinc	w29, w8, wzr, ne
    2928:      	ldrb	w8, [x22, #0x1c]
    292c:      	add	x8, x25, x8
    2930:      	ldrb	w8, [x22, #0x1c]
    2934:      	add	x2, x25, x8
    2938:      	blr	x10
    293c:      	cbnz	x0, 0x27f8 <kprobe_unwind_perl+0x27f8>
    2940:      	ldr	x24, [sp, #0x70]
    2944:      	ldrb	w8, [x22, #0x1e]
    2948:      	mov	w9, #0x4                // =4
    294c:      	mov	w10, #0x70              // =112
    2950:      	add	x11, sp, #0xb8
    2954:      	add	x0, sp, #0xb8
    2958:      	mov	w1, #0x4                // =4
    295c:      	add	x8, x24, x8
    2960:      	ldrb	w8, [x22, #0x1e]
    2964:      	add	x2, x24, x8
    2968:      	blr	x10
    296c:      	cbz	x0, 0x29fc <kprobe_unwind_perl+0x29fc>
    2970:      	ldr	w8, [x23]
    2974:      	cbnz	w8, 0x4310 <kprobe_unwind_perl+0x4310>
    2978:      	mov	w8, #0x14               // =20
    297c:      	adrp	x0, 0x2000 <kprobe_unwind_perl+0x2000>
    2980:      	add	x9, sp, #0xbc
    2984:      	str	w8, [sp, #0xbc]
    2988:      	mov	w8, #0x1                // =1
    298c:      	add	x1, sp, #0xbc
    2990:      	ldr	x0, [x0]
    2994:      	blr	x8
    2998:      	cbz	x0, 0x2b84 <kprobe_unwind_perl+0x2b84>
    299c:      	ldr	x8, [x0]
    29a0:      	add	x8, x8, #0x1
    29a4:      	str	x8, [x0]
    29a8:      	b	0x27f8 <kprobe_unwind_perl+0x27f8>
    29ac:      	ldr	w8, [x23]
    29b0:      	cbz	w8, 0x2e58 <kprobe_unwind_perl+0x2e58>
    29b4:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    29b8:      	add	x8, x8, #0x0
    29bc:      	add	x0, sp, #0x30
    29c0:      	ldp	x9, x10, [x8, #0x10]
    29c4:      	mov	w1, #0x2e               // =46
    29c8:      	stp	x9, x10, [sp, #0x40]
    29cc:      	ldr	x9, [x8, #0x20]
    29d0:      	add	x10, sp, #0x30
    29d4:      	str	x9, [sp, #0x50]
    29d8:      	ldur	x9, [x8, #0x26]
    29dc:      	stur	x9, [sp, #0x56]
    29e0:      	ldp	x9, x8, [x8]
    29e4:      	stp	x9, x8, [sp, #0x30]
    29e8:      	mov	w8, #0x2e               // =46
    29ec:      	mov	w9, #0x6                // =6
    29f0:      	ldr	w2, [sp, #0xa8]
    29f4:      	blr	x9
    29f8:      	b	0x2e58 <kprobe_unwind_perl+0x2e58>
    29fc:      	ldr	w8, [sp, #0xb8]
    2a00:      	and	w8, w8, #0x1f
    2a04:      	cmp	w8, #0xd
    2a08:      	b.ne	0x2bd4 <kprobe_unwind_perl+0x2bd4>
    2a0c:      	ldrb	w8, [x22, #0x1f]
    2a10:      	mov	w9, #0x8                // =8
    2a14:      	mov	w10, #0x70              // =112
    2a18:      	add	x11, sp, #0xa8
    2a1c:      	add	x0, sp, #0xa8
    2a20:      	mov	w1, #0x8                // =8
    2a24:      	add	x8, x24, x8
    2a28:      	ldrb	w8, [x22, #0x1f]
    2a2c:      	add	x2, x24, x8
    2a30:      	blr	x10
    2a34:      	cbnz	x0, 0x2970 <kprobe_unwind_perl+0x2970>
    2a38:      	ldr	x8, [sp, #0xa8]
    2a3c:      	ldrb	w9, [x22, #0x21]
    2a40:      	mov	w10, #0x70              // =112
    2a44:      	add	x11, sp, #0xa4
    2a48:      	add	x0, sp, #0xa4
    2a4c:      	mov	w1, #0x4                // =4
    2a50:      	add	x8, x8, x9
    2a54:      	mov	w9, #0x4                // =4
    2a58:      	ldr	x8, [sp, #0xa8]
    2a5c:      	ldrb	w9, [x22, #0x21]
    2a60:      	add	x2, x8, x9
    2a64:      	blr	x10
    2a68:      	cbnz	x0, 0x2970 <kprobe_unwind_perl+0x2970>
    2a6c:      	ldrb	w8, [sp, #0xa5]
    2a70:      	tbnz	w8, #0x7, 0x2dbc <kprobe_unwind_perl+0x2dbc>
    2a74:      	ldr	x8, [sp, #0xa8]
    2a78:      	ldrb	w9, [x22, #0x22]
    2a7c:      	mov	w10, #0x70              // =112
    2a80:      	add	x11, sp, #0x98
    2a84:      	add	x0, sp, #0x98
    2a88:      	mov	w1, #0x8                // =8
    2a8c:      	add	x8, x8, x9
    2a90:      	mov	w9, #0x8                // =8
    2a94:      	ldr	x8, [sp, #0xa8]
    2a98:      	ldrb	w9, [x22, #0x22]
    2a9c:      	add	x2, x8, x9
    2aa0:      	blr	x10
    2aa4:      	cbnz	x0, 0x2970 <kprobe_unwind_perl+0x2970>
    2aa8:      	ldr	x8, [sp, #0x98]
    2aac:      	cbz	x8, 0x2970 <kprobe_unwind_perl+0x2970>
    2ab0:      	ldr	w9, [x23]
    2ab4:      	cbnz	w9, 0x6304 <kprobe_unwind_perl+0x6304>
    2ab8:      	ldrb	w9, [x22, #0x1e]
    2abc:      	mov	w10, #0x70              // =112
    2ac0:      	add	x11, sp, #0x94
    2ac4:      	add	x0, sp, #0x94
    2ac8:      	mov	w1, #0x4                // =4
    2acc:      	add	x8, x8, x9
    2ad0:      	mov	w9, #0x4                // =4
    2ad4:      	ldr	x8, [sp, #0x98]
    2ad8:      	ldrb	w9, [x22, #0x1e]
    2adc:      	add	x2, x8, x9
    2ae0:      	blr	x10
    2ae4:      	cbnz	x0, 0x2970 <kprobe_unwind_perl+0x2970>
    2ae8:      	ldr	w8, [sp, #0x94]
    2aec:      	mov	w9, #0x801f             // =32799
    2af0:      	and	w8, w8, w9
    2af4:      	mov	w9, #0x8009             // =32777
    2af8:      	cmp	w8, w9
    2afc:      	b.ne	0x3c34 <kprobe_unwind_perl+0x3c34>
    2b00:      	ldr	x8, [sp, #0x98]
    2b04:      	ldrb	w9, [x22, #0x20]
    2b08:      	mov	w10, #0x70              // =112
    2b0c:      	add	x11, sp, #0x88
    2b10:      	add	x0, sp, #0x88
    2b14:      	mov	w1, #0x8                // =8
    2b18:      	add	x8, x8, x9
    2b1c:      	mov	w9, #0x8                // =8
    2b20:      	ldr	x8, [sp, #0x98]
    2b24:      	ldrb	w9, [x22, #0x20]
    2b28:      	add	x2, x8, x9
    2b2c:      	blr	x10
    2b30:      	cbnz	x0, 0x2970 <kprobe_unwind_perl+0x2970>
    2b34:      	ldr	x8, [sp, #0x88]
    2b38:      	ldrb	w9, [x22, #0x23]
    2b3c:      	mov	w10, #0x70              // =112
    2b40:      	add	x11, sp, #0x80
    2b44:      	add	x0, sp, #0x80
    2b48:      	mov	w1, #0x8                // =8
    2b4c:      	add	x8, x8, x9
    2b50:      	mov	w9, #0x8                // =8
    2b54:      	ldr	x8, [sp, #0x88]
    2b58:      	ldrb	w9, [x22, #0x23]
    2b5c:      	add	x2, x8, x9
    2b60:      	blr	x10
    2b64:      	cbnz	x0, 0x2970 <kprobe_unwind_perl+0x2970>
    2b68:      	ldr	x8, [sp, #0x80]
    2b6c:      	str	x8, [sp, #0x8]
    2b70:      	cbz	x8, 0x4bd0 <kprobe_unwind_perl+0x4bd0>
    2b74:      	ldr	w8, [x23]
    2b78:      	cbnz	w8, 0x6994 <kprobe_unwind_perl+0x6994>
    2b7c:      	ldr	x24, [sp, #0x10]
    2b80:      	b	0x4be4 <kprobe_unwind_perl+0x4be4>
    2b84:      	ldr	w8, [x23]
    2b88:      	cbz	w8, 0x27f8 <kprobe_unwind_perl+0x27f8>
    2b8c:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    2b90:      	add	x8, x8, #0x0
    2b94:      	add	x0, sp, #0x30
    2b98:      	ldp	x9, x10, [x8, #0x10]
    2b9c:      	mov	w1, #0x2e               // =46
    2ba0:      	stp	x9, x10, [sp, #0x40]
    2ba4:      	ldr	x9, [x8, #0x20]
    2ba8:      	add	x10, sp, #0x30
    2bac:      	str	x9, [sp, #0x50]
    2bb0:      	ldur	x9, [x8, #0x26]
    2bb4:      	stur	x9, [sp, #0x56]
    2bb8:      	ldp	x9, x8, [x8]
    2bbc:      	stp	x9, x8, [sp, #0x30]
    2bc0:      	mov	w8, #0x2e               // =46
    2bc4:      	mov	w9, #0x6                // =6
    2bc8:      	ldr	w2, [sp, #0xbc]
    2bcc:      	blr	x9
    2bd0:      	b	0x27f8 <kprobe_unwind_perl+0x27f8>
    2bd4:      	ldr	w8, [x23]
    2bd8:      	cbz	w8, 0x27f8 <kprobe_unwind_perl+0x27f8>
    2bdc:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    2be0:      	add	x8, x8, #0x0
    2be4:      	add	x0, sp, #0x30
    2be8:      	ldp	x9, x10, [x8]
    2bec:      	mov	w1, #0x1e               // =30
    2bf0:      	stp	x9, x10, [sp, #0x30]
    2bf4:      	ldr	x9, [x8, #0x10]
    2bf8:      	ldur	x8, [x8, #0x16]
    2bfc:      	add	x10, sp, #0x30
    2c00:      	str	x9, [sp, #0x40]
    2c04:      	stur	x8, [sp, #0x46]
    2c08:      	mov	w8, #0x1e               // =30
    2c0c:      	mov	w9, #0x6                // =6
    2c10:      	ldr	w2, [sp, #0xb8]
    2c14:      	blr	x9
    2c18:      	b	0x27f8 <kprobe_unwind_perl+0x27f8>
    2c1c:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    2c20:      	add	x8, x8, #0x0
    2c24:      	add	x0, sp, #0x30
    2c28:      	ldp	x9, x10, [x8, #0x10]
    2c2c:      	mov	w1, #0x2e               // =46
    2c30:      	stp	x9, x10, [sp, #0x40]
    2c34:      	ldr	x9, [x8, #0x20]
    2c38:      	add	x10, sp, #0x30
    2c3c:      	str	x9, [sp, #0x50]
    2c40:      	ldur	x9, [x8, #0x26]
    2c44:      	stur	x9, [sp, #0x56]
    2c48:      	ldp	x9, x8, [x8]
    2c4c:      	stp	x9, x8, [sp, #0x30]
    2c50:      	mov	w8, #0x2e               // =46
    2c54:      	mov	w9, #0x6                // =6
    2c58:      	ldr	w2, [sp, #0xa8]
    2c5c:      	blr	x9
    2c60:      	b	0x27a0 <kprobe_unwind_perl+0x27a0>
    2c64:      	ldr	w8, [x23]
    2c68:      	cbnz	w8, 0x53c4 <kprobe_unwind_perl+0x53c4>
    2c6c:      	ldrb	w8, [x22, #0x1d]
    2c70:      	ldr	x9, [x21, #0xf40]
    2c74:      	mov	w29, wzr
    2c78:      	sub	x8, x9, x8
    2c7c:      	ldp	x24, x9, [sp, #0x10]
    2c80:      	str	x8, [x21, #0xf40]
    2c84:      	b	0x5640 <kprobe_unwind_perl+0x5640>
    2c88:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    2c8c:      	add	x8, x8, #0x0
    2c90:      	add	x0, sp, #0x30
    2c94:      	ldp	x9, x10, [x8, #0x10]
    2c98:      	mov	w1, #0x2d               // =45
    2c9c:      	stp	x9, x10, [sp, #0x40]
    2ca0:      	ldr	x9, [x8, #0x20]
    2ca4:      	add	x10, sp, #0x30
    2ca8:      	str	x9, [sp, #0x50]
    2cac:      	ldur	x9, [x8, #0x25]
    2cb0:      	stur	x9, [sp, #0x55]
    2cb4:      	ldp	x9, x8, [x8]
    2cb8:      	stp	x9, x8, [sp, #0x30]
    2cbc:      	mov	w8, #0x2d               // =45
    2cc0:      	mov	w9, #0x6                // =6
    2cc4:      	blr	x9
    2cc8:      	b	0x14a0 <kprobe_unwind_perl+0x14a0>
    2ccc:      	mov	w8, #0xa                // =10
    2cd0:      	add	x0, sp, #0x30
    2cd4:      	mov	w1, #0x2a               // =42
    2cd8:      	strh	w8, [sp, #0x58]
    2cdc:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    2ce0:      	add	x8, x8, #0x0
    2ce4:      	mov	x2, x25
    2ce8:      	ldp	x9, x10, [x8, #0x10]
    2cec:      	stp	x9, x10, [sp, #0x40]
    2cf0:      	ldr	x9, [x8, #0x20]
    2cf4:      	add	x10, sp, #0x30
    2cf8:      	str	x9, [sp, #0x50]
    2cfc:      	ldp	x8, x9, [x8]
    2d00:      	stp	x8, x9, [sp, #0x30]
    2d04:      	mov	w8, #0x2a               // =42
    2d08:      	mov	w9, #0x6                // =6
    2d0c:      	blr	x9
    2d10:      	b	0x2800 <kprobe_unwind_perl+0x2800>
    2d14:      	ldr	w8, [x23]
    2d18:      	cbz	w8, 0x1e5c <kprobe_unwind_perl+0x1e5c>
    2d1c:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    2d20:      	add	x8, x8, #0x0
    2d24:      	add	x0, sp, #0x30
    2d28:      	ldp	x9, x10, [x8, #0x10]
    2d2c:      	mov	w1, #0x26               // =38
    2d30:      	stp	x9, x10, [sp, #0x40]
    2d34:      	ldur	x9, [x8, #0x1e]
    2d38:      	add	x10, sp, #0x30
    2d3c:      	stur	x9, [sp, #0x4e]
    2d40:      	ldp	x8, x9, [x8]
    2d44:      	stp	x8, x9, [sp, #0x30]
    2d48:      	mov	w8, #0x26               // =38
    2d4c:      	mov	w9, #0x6                // =6
    2d50:      	ldr	w2, [sp, #0x94]
    2d54:      	b	0x3be4 <kprobe_unwind_perl+0x3be4>
    2d58:      	add	x8, sp, #0x98
    2d5c:      	ldr	x8, [x8]
    2d60:      	ldr	x24, [sp, #0x10]
    2d64:      	str	x8, [sp, #0x8]
    2d68:      	cbz	x8, 0xcd8 <kprobe_unwind_perl+0xcd8>
    2d6c:      	ldr	x24, [x24]
    2d70:      	ldr	w8, [x23]
    2d74:      	cbnz	w8, 0x540c <kprobe_unwind_perl+0x540c>
    2d78:      	ldr	w8, [x21, #0x2c0]
    2d7c:      	cmp	w8, #0x7e
    2d80:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    2d84:      	add	w9, w8, #0x1
    2d88:      	mov	w10, #0x7               // =7
    2d8c:      	str	w9, [x21, #0x2c0]
    2d90:      	mov	w9, #0x18               // =24
    2d94:      	umaddl	x8, w8, w9, x21
    2d98:      	str	x24, [x8, #0x2d8]
    2d9c:      	ldp	x9, x24, [sp, #0x8]
    2da0:      	strb	w10, [x8, #0x2e0]
    2da4:      	str	wzr, [x8, #0x2e4]
    2da8:      	str	x9, [x8, #0x2d0]
    2dac:      	add	x9, x8, #0x2d0
    2db0:      	str	xzr, [x21, #0xf30]
    2db4:      	stur	wzr, [x9, #0x11]
    2db8:      	b	0x1368 <kprobe_unwind_perl+0x1368>
    2dbc:      	ldr	w8, [x23]
    2dc0:      	cbz	w8, 0x27f8 <kprobe_unwind_perl+0x27f8>
    2dc4:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    2dc8:      	add	x8, x8, #0x0
    2dcc:      	add	x0, sp, #0x30
    2dd0:      	ldp	x9, x10, [x8, #0x10]
    2dd4:      	mov	w1, #0x26               // =38
    2dd8:      	stp	x9, x10, [sp, #0x40]
    2ddc:      	ldur	x9, [x8, #0x1e]
    2de0:      	add	x10, sp, #0x30
    2de4:      	stur	x9, [sp, #0x4e]
    2de8:      	ldp	x8, x9, [x8]
    2dec:      	stp	x8, x9, [sp, #0x30]
    2df0:      	mov	w8, #0x26               // =38
    2df4:      	mov	w9, #0x6                // =6
    2df8:      	ldr	w2, [sp, #0xb8]
    2dfc:      	ldr	w3, [sp, #0xa4]
    2e00:      	blr	x9
    2e04:      	b	0x27f8 <kprobe_unwind_perl+0x27f8>
    2e08:      	mov	w8, #0xa                // =10
    2e0c:      	add	x10, sp, #0x30
    2e10:      	add	x0, sp, #0x30
    2e14:      	strh	w8, [sp, #0x40]
    2e18:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    2e1c:      	add	x8, x8, #0x0
    2e20:      	mov	w1, #0x12               // =18
    2e24:      	ldp	x9, x8, [x8]
    2e28:      	stp	x9, x8, [sp, #0x30]
    2e2c:      	mov	w8, #0x12               // =18
    2e30:      	mov	w9, #0x6                // =6
    2e34:      	ldrb	w2, [sp, #0x7c]
    2e38:      	blr	x9
    2e3c:      	ldrb	w8, [sp, #0x7c]
    2e40:      	and	w9, w8, #0xf
    2e44:      	sub	w10, w9, #0x9
    2e48:      	cmp	w10, #0x2
    2e4c:      	b.lo	0x28d0 <kprobe_unwind_perl+0x28d0>
    2e50:      	cmp	w9, #0xc
    2e54:      	b.ne	0x2f44 <kprobe_unwind_perl+0x2f44>
    2e58:      	mov	w29, #0x3               // =3
    2e5c:      	ldrb	w8, [x22, #0x1d]
    2e60:      	ldr	x9, [x21, #0xf40]
    2e64:      	adrp	x0, 0x2000 <kprobe_unwind_perl+0x2000>
    2e68:      	add	x1, sp, #0xa8
    2e6c:      	sub	x8, x9, x8
    2e70:      	add	x9, sp, #0xa8
    2e74:      	str	x8, [x21, #0xf40]
    2e78:      	mov	w8, #0x10               // =16
    2e7c:      	str	w8, [sp, #0xa8]
    2e80:      	mov	w8, #0x1                // =1
    2e84:      	ldr	x0, [x0]
    2e88:      	blr	x8
    2e8c:      	cbz	x0, 0x2eac <kprobe_unwind_perl+0x2eac>
    2e90:      	ldr	x8, [x0]
    2e94:      	add	x8, x8, #0x1
    2e98:      	str	x8, [x0]
    2e9c:      	ldp	x24, x9, [sp, #0x10]
    2ea0:      	cmp	w29, #0x3
    2ea4:      	b.eq	0x2ec0 <kprobe_unwind_perl+0x2ec0>
    2ea8:      	b	0x563c <kprobe_unwind_perl+0x563c>
    2eac:      	ldr	w8, [x23]
    2eb0:      	cbnz	w8, 0x3368 <kprobe_unwind_perl+0x3368>
    2eb4:      	ldp	x24, x9, [sp, #0x10]
    2eb8:      	cmp	w29, #0x3
    2ebc:      	b.ne	0x563c <kprobe_unwind_perl+0x563c>
    2ec0:      	ldr	x25, [x21, #0xf40]
    2ec4:      	cmp	x25, x9
    2ec8:      	b.hs	0x2ed8 <kprobe_unwind_perl+0x2ed8>
    2ecc:      	mov	w29, #0x3               // =3
    2ed0:      	ldp	x24, x9, [sp, #0x10]
    2ed4:      	b	0x563c <kprobe_unwind_perl+0x563c>
    2ed8:      	ldrb	w8, [x22, #0x19]
    2edc:      	mov	w9, #0x1                // =1
    2ee0:      	mov	w10, #0x70              // =112
    2ee4:      	add	x11, sp, #0x7c
    2ee8:      	add	x0, sp, #0x7c
    2eec:      	mov	w1, #0x1                // =1
    2ef0:      	add	x8, x25, x8
    2ef4:      	ldrb	w8, [x22, #0x19]
    2ef8:      	add	x2, x25, x8
    2efc:      	blr	x10
    2f00:      	cbz	x0, 0x2fcc <kprobe_unwind_perl+0x2fcc>
    2f04:      	ldr	w8, [x23]
    2f08:      	cbnz	w8, 0x3448 <kprobe_unwind_perl+0x3448>
    2f0c:      	mov	w8, #0x13               // =19
    2f10:      	adrp	x0, 0x2000 <kprobe_unwind_perl+0x2000>
    2f14:      	add	x9, sp, #0xa8
    2f18:      	str	w8, [sp, #0xa8]
    2f1c:      	mov	w8, #0x1                // =1
    2f20:      	add	x1, sp, #0xa8
    2f24:      	ldr	x0, [x0]
    2f28:      	blr	x8
    2f2c:      	cbz	x0, 0x30c4 <kprobe_unwind_perl+0x30c4>
    2f30:      	ldr	x8, [x0]
    2f34:      	mov	w29, #0x3               // =3
    2f38:      	add	x8, x8, #0x1
    2f3c:      	str	x8, [x0]
    2f40:      	b	0x3618 <kprobe_unwind_perl+0x3618>
    2f44:      	ldr	x8, [sp, #0x10]
    2f48:      	mov	w29, #0x3               // =3
    2f4c:      	ldr	x8, [x8]
    2f50:      	cbnz	x8, 0x2e5c <kprobe_unwind_perl+0x2e5c>
    2f54:      	ldrb	w8, [x22, #0x1a]
    2f58:      	mov	w9, #0x8                // =8
    2f5c:      	mov	w10, #0x70              // =112
    2f60:      	ldr	x24, [sp, #0x10]
    2f64:      	mov	w1, #0x8                // =8
    2f68:      	add	x8, x25, x8
    2f6c:      	mov	x0, x24
    2f70:      	ldrb	w8, [x22, #0x1a]
    2f74:      	add	x2, x25, x8
    2f78:      	blr	x10
    2f7c:      	cbnz	x0, 0x27f8 <kprobe_unwind_perl+0x27f8>
    2f80:      	ldr	w8, [x23]
    2f84:      	cbz	w8, 0x2e5c <kprobe_unwind_perl+0x2e5c>
    2f88:      	adrp	x8, 0x2000 <kprobe_unwind_perl+0x2000>
    2f8c:      	add	x8, x8, #0x0
    2f90:      	add	x0, sp, #0x30
    2f94:      	ldp	x9, x10, [x8]
    2f98:      	mov	w1, #0x1e               // =30
    2f9c:      	stp	x9, x10, [sp, #0x30]
    2fa0:      	ldr	x9, [x8, #0x10]
    2fa4:      	ldur	x8, [x8, #0x16]
    2fa8:      	add	x10, sp, #0x30
    2fac:      	str	x9, [sp, #0x40]
    2fb0:      	stur	x8, [sp, #0x46]
    2fb4:      	mov	w8, #0x1e               // =30
    2fb8:      	mov	w9, #0x6                // =6
    2fbc:      	ldr	x8, [sp, #0x10]
    2fc0:      	ldr	x2, [x8]
    2fc4:      	blr	x9
    2fc8:      	b	0x2e5c <kprobe_unwind_perl+0x2e5c>
    2fcc:      	ldr	w8, [x23]
    2fd0:      	cbnz	w8, 0x35c4 <kprobe_unwind_perl+0x35c4>
    2fd4:      	ldrb	w8, [sp, #0x7c]
    2fd8:      	and	w9, w8, #0xf
    2fdc:      	sub	w10, w9, #0x9
    2fe0:      	cmp	w10, #0x2
    2fe4:      	b.hs	0x360c <kprobe_unwind_perl+0x360c>
    2fe8:      	sxtb	w8, w8
    2fec:      	tbnz	w8, #0x1f, 0x3614 <kprobe_unwind_perl+0x3614>
    2ff0:      	ldrb	w8, [x22, #0x1b]
    2ff4:      	mov	w9, #0x8                // =8
    2ff8:      	mov	w10, #0x70              // =112
    2ffc:      	add	x11, sp, #0x30
    3000:      	add	x0, sp, #0x30
    3004:      	mov	w1, #0x8                // =8
    3008:      	add	x8, x25, x8
    300c:      	ldrb	w8, [x22, #0x1b]
    3010:      	add	x2, x25, x8
    3014:      	blr	x10
    3018:      	cbnz	x0, 0x2f04 <kprobe_unwind_perl+0x2f04>
    301c:      	ldr	x8, [sp, #0x30]
    3020:      	mov	w9, #0x8                // =8
    3024:      	mov	w10, #0x70              // =112
    3028:      	add	x11, sp, #0x70
    302c:      	add	x0, sp, #0x70
    3030:      	mov	w1, #0x8                // =8
    3034:      	cmp	x8, #0x0
    3038:      	mov	w8, #0x3                // =3
    303c:      	csinc	w29, w8, wzr, ne
    3040:      	ldrb	w8, [x22, #0x1c]
    3044:      	add	x8, x25, x8
    3048:      	ldrb	w8, [x22, #0x1c]
    304c:      	add	x2, x25, x8
    3050:      	blr	x10
    3054:      	cbnz	x0, 0x2f04 <kprobe_unwind_perl+0x2f04>
    3058:      	ldr	x24, [sp, #0x70]
    305c:      	ldrb	w8, [x22, #0x1e]
    3060:      	mov	w9, #0x4                // =4
    3064:      	mov	w10, #0x70              // =112
    3068:      	add	x11, sp, #0xb8
    306c:      	add	x0, sp, #0xb8
    3070:      	mov	w1, #0x4                // =4
    3074:      	add	x8, x24, x8
    3078:      	ldrb	w8, [x22, #0x1e]
    307c:      	add	x2, x24, x8
    3080:      	blr	x10
    3084:      	cbz	x0, 0x3114 <kprobe_unwind_perl+0x3114>
    3088:      	ldr	w8, [x23]
    308c:      	cbnz	w8, 0x4a78 <kprobe_unwind_perl+0x4a78>
    3090:      	mov	w8, #0x14               // =20
    3094:      	adrp	x0, 0x3000 <kprobe_unwind_perl+0x3000>
    3098:      	add	x9, sp, #0xbc
    309c:      	str	w8, [sp, #0xbc]
    30a0:      	mov	w8, #0x1                // =1
    30a4:      	add	x1, sp, #0xbc
    30a8:      	ldr	x0, [x0]
    30ac:      	blr	x8
    30b0:      	cbz	x0, 0x32d0 <kprobe_unwind_perl+0x32d0>
    30b4:      	ldr	x8, [x0]
    30b8:      	add	x8, x8, #0x1
    30bc:      	str	x8, [x0]
    30c0:      	b	0x2f04 <kprobe_unwind_perl+0x2f04>
    30c4:      	ldr	w8, [x23]
    30c8:      	cbz	w8, 0x3614 <kprobe_unwind_perl+0x3614>
    30cc:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    30d0:      	add	x8, x8, #0x0
    30d4:      	add	x0, sp, #0x30
    30d8:      	ldp	x9, x10, [x8, #0x10]
    30dc:      	mov	w1, #0x2e               // =46
    30e0:      	stp	x9, x10, [sp, #0x40]
    30e4:      	ldr	x9, [x8, #0x20]
    30e8:      	add	x10, sp, #0x30
    30ec:      	str	x9, [sp, #0x50]
    30f0:      	ldur	x9, [x8, #0x26]
    30f4:      	stur	x9, [sp, #0x56]
    30f8:      	ldp	x9, x8, [x8]
    30fc:      	stp	x9, x8, [sp, #0x30]
    3100:      	mov	w8, #0x2e               // =46
    3104:      	mov	w9, #0x6                // =6
    3108:      	ldr	w2, [sp, #0xa8]
    310c:      	blr	x9
    3110:      	b	0x3614 <kprobe_unwind_perl+0x3614>
    3114:      	ldr	w8, [sp, #0xb8]
    3118:      	and	w8, w8, #0x1f
    311c:      	cmp	w8, #0xd
    3120:      	b.ne	0x3320 <kprobe_unwind_perl+0x3320>
    3124:      	ldrb	w8, [x22, #0x1f]
    3128:      	mov	w9, #0x8                // =8
    312c:      	mov	w10, #0x70              // =112
    3130:      	add	x11, sp, #0xa8
    3134:      	add	x0, sp, #0xa8
    3138:      	mov	w1, #0x8                // =8
    313c:      	add	x8, x24, x8
    3140:      	ldrb	w8, [x22, #0x1f]
    3144:      	add	x2, x24, x8
    3148:      	blr	x10
    314c:      	cbnz	x0, 0x3088 <kprobe_unwind_perl+0x3088>
    3150:      	ldr	x8, [sp, #0xa8]
    3154:      	ldrb	w9, [x22, #0x21]
    3158:      	mov	w10, #0x70              // =112
    315c:      	add	x11, sp, #0xa4
    3160:      	add	x0, sp, #0xa4
    3164:      	mov	w1, #0x4                // =4
    3168:      	add	x8, x8, x9
    316c:      	mov	w9, #0x4                // =4
    3170:      	ldr	x8, [sp, #0xa8]
    3174:      	ldrb	w9, [x22, #0x21]
    3178:      	add	x2, x8, x9
    317c:      	blr	x10
    3180:      	cbnz	x0, 0x3088 <kprobe_unwind_perl+0x3088>
    3184:      	ldrb	w8, [sp, #0xa5]
    3188:      	tbnz	w8, #0x7, 0x3578 <kprobe_unwind_perl+0x3578>
    318c:      	ldr	x8, [sp, #0xa8]
    3190:      	ldrb	w9, [x22, #0x22]
    3194:      	mov	w10, #0x70              // =112
    3198:      	add	x11, sp, #0x98
    319c:      	add	x0, sp, #0x98
    31a0:      	mov	w1, #0x8                // =8
    31a4:      	add	x8, x8, x9
    31a8:      	mov	w9, #0x8                // =8
    31ac:      	ldr	x8, [sp, #0xa8]
    31b0:      	ldrb	w9, [x22, #0x22]
    31b4:      	add	x2, x8, x9
    31b8:      	blr	x10
    31bc:      	cbnz	x0, 0x3088 <kprobe_unwind_perl+0x3088>
    31c0:      	ldr	x8, [sp, #0x98]
    31c4:      	cbz	x8, 0x3088 <kprobe_unwind_perl+0x3088>
    31c8:      	ldr	w9, [x23]
    31cc:      	cbnz	w9, 0x668c <kprobe_unwind_perl+0x668c>
    31d0:      	ldrb	w9, [x22, #0x1e]
    31d4:      	mov	w10, #0x70              // =112
    31d8:      	add	x11, sp, #0x94
    31dc:      	add	x0, sp, #0x94
    31e0:      	mov	w1, #0x4                // =4
    31e4:      	add	x8, x8, x9
    31e8:      	mov	w9, #0x4                // =4
    31ec:      	ldr	x8, [sp, #0x98]
    31f0:      	ldrb	w9, [x22, #0x1e]
    31f4:      	add	x2, x8, x9
    31f8:      	blr	x10
    31fc:      	cbnz	x0, 0x3088 <kprobe_unwind_perl+0x3088>
    3200:      	ldr	w8, [sp, #0x94]
    3204:      	mov	w9, #0x801f             // =32799
    3208:      	and	w8, w8, w9
    320c:      	mov	w9, #0x8009             // =32777
    3210:      	cmp	w8, w9
    3214:      	b.ne	0x439c <kprobe_unwind_perl+0x439c>
    3218:      	ldr	x8, [sp, #0x98]
    321c:      	ldrb	w9, [x22, #0x20]
    3220:      	mov	w10, #0x70              // =112
    3224:      	add	x11, sp, #0x88
    3228:      	add	x0, sp, #0x88
    322c:      	mov	w1, #0x8                // =8
    3230:      	add	x8, x8, x9
    3234:      	mov	w9, #0x8                // =8
    3238:      	ldr	x8, [sp, #0x98]
    323c:      	ldrb	w9, [x22, #0x20]
    3240:      	add	x2, x8, x9
    3244:      	blr	x10
    3248:      	cbnz	x0, 0x3088 <kprobe_unwind_perl+0x3088>
    324c:      	ldr	x8, [sp, #0x88]
    3250:      	ldrb	w9, [x22, #0x23]
    3254:      	mov	w10, #0x70              // =112
    3258:      	add	x11, sp, #0x80
    325c:      	add	x0, sp, #0x80
    3260:      	mov	w1, #0x8                // =8
    3264:      	add	x8, x8, x9
    3268:      	mov	w9, #0x8                // =8
    326c:      	ldr	x8, [sp, #0x88]
    3270:      	ldrb	w9, [x22, #0x23]
    3274:      	add	x2, x8, x9
    3278:      	blr	x10
    327c:      	cbnz	x0, 0x3088 <kprobe_unwind_perl+0x3088>
    3280:      	ldr	x24, [sp, #0x80]
    3284:      	cbz	x24, 0x545c <kprobe_unwind_perl+0x545c>
    3288:      	ldr	w8, [x23]
    328c:      	cbz	w8, 0x5468 <kprobe_unwind_perl+0x5468>
    3290:      	mov	w8, #0x786c             // =30828
    3294:      	add	x10, sp, #0x30
    3298:      	add	x0, sp, #0x30
    329c:      	mov	w1, #0x14               // =20
    32a0:      	movk	w8, #0xa, lsl #16
    32a4:      	str	w8, [sp, #0x40]
    32a8:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    32ac:      	add	x8, x8, #0x0
    32b0:      	ldp	x9, x8, [x8]
    32b4:      	stp	x9, x8, [sp, #0x30]
    32b8:      	mov	w8, #0x14               // =20
    32bc:      	mov	w9, #0x6                // =6
    32c0:      	ldr	x2, [sp, #0x80]
    32c4:      	blr	x9
    32c8:      	add	x8, sp, #0x80
    32cc:      	b	0x5460 <kprobe_unwind_perl+0x5460>
    32d0:      	ldr	w8, [x23]
    32d4:      	cbz	w8, 0x2f04 <kprobe_unwind_perl+0x2f04>
    32d8:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    32dc:      	add	x8, x8, #0x0
    32e0:      	add	x0, sp, #0x30
    32e4:      	ldp	x9, x10, [x8, #0x10]
    32e8:      	mov	w1, #0x2e               // =46
    32ec:      	stp	x9, x10, [sp, #0x40]
    32f0:      	ldr	x9, [x8, #0x20]
    32f4:      	add	x10, sp, #0x30
    32f8:      	str	x9, [sp, #0x50]
    32fc:      	ldur	x9, [x8, #0x26]
    3300:      	stur	x9, [sp, #0x56]
    3304:      	ldp	x9, x8, [x8]
    3308:      	stp	x9, x8, [sp, #0x30]
    330c:      	mov	w8, #0x2e               // =46
    3310:      	mov	w9, #0x6                // =6
    3314:      	ldr	w2, [sp, #0xbc]
    3318:      	blr	x9
    331c:      	b	0x2f04 <kprobe_unwind_perl+0x2f04>
    3320:      	ldr	w8, [x23]
    3324:      	cbz	w8, 0x2f04 <kprobe_unwind_perl+0x2f04>
    3328:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    332c:      	add	x8, x8, #0x0
    3330:      	add	x0, sp, #0x30
    3334:      	ldp	x9, x10, [x8]
    3338:      	mov	w1, #0x1e               // =30
    333c:      	stp	x9, x10, [sp, #0x30]
    3340:      	ldr	x9, [x8, #0x10]
    3344:      	ldur	x8, [x8, #0x16]
    3348:      	add	x10, sp, #0x30
    334c:      	str	x9, [sp, #0x40]
    3350:      	stur	x8, [sp, #0x46]
    3354:      	mov	w8, #0x1e               // =30
    3358:      	mov	w9, #0x6                // =6
    335c:      	ldr	w2, [sp, #0xb8]
    3360:      	blr	x9
    3364:      	b	0x2f04 <kprobe_unwind_perl+0x2f04>
    3368:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    336c:      	add	x8, x8, #0x0
    3370:      	add	x0, sp, #0x30
    3374:      	ldp	x9, x10, [x8, #0x10]
    3378:      	mov	w1, #0x2e               // =46
    337c:      	stp	x9, x10, [sp, #0x40]
    3380:      	ldr	x9, [x8, #0x20]
    3384:      	add	x10, sp, #0x30
    3388:      	str	x9, [sp, #0x50]
    338c:      	ldur	x9, [x8, #0x26]
    3390:      	stur	x9, [sp, #0x56]
    3394:      	ldp	x9, x8, [x8]
    3398:      	stp	x9, x8, [sp, #0x30]
    339c:      	mov	w8, #0x2e               // =46
    33a0:      	mov	w9, #0x6                // =6
    33a4:      	ldr	w2, [sp, #0xa8]
    33a8:      	blr	x9
    33ac:      	ldp	x24, x9, [sp, #0x10]
    33b0:      	cmp	w29, #0x3
    33b4:      	b.eq	0x2ec0 <kprobe_unwind_perl+0x2ec0>
    33b8:      	b	0x563c <kprobe_unwind_perl+0x563c>
    33bc:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    33c0:      	add	x8, x8, #0x0
    33c4:      	add	x0, sp, #0x30
    33c8:      	ldp	x9, x10, [x8, #0x10]
    33cc:      	mov	w1, #0x2e               // =46
    33d0:      	stp	x9, x10, [sp, #0x40]
    33d4:      	ldr	x9, [x8, #0x20]
    33d8:      	add	x10, sp, #0x30
    33dc:      	str	x9, [sp, #0x50]
    33e0:      	ldur	x9, [x8, #0x26]
    33e4:      	stur	x9, [sp, #0x56]
    33e8:      	ldp	x9, x8, [x8]
    33ec:      	stp	x9, x8, [sp, #0x30]
    33f0:      	mov	w8, #0x2e               // =46
    33f4:      	mov	w9, #0x6                // =6
    33f8:      	ldr	w2, [sp, #0xbc]
    33fc:      	blr	x9
    3400:      	b	0x16b8 <kprobe_unwind_perl+0x16b8>
    3404:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    3408:      	add	x8, x8, #0x0
    340c:      	add	x0, sp, #0x30
    3410:      	ldp	x9, x10, [x8, #0x10]
    3414:      	mov	w1, #0x2d               // =45
    3418:      	stp	x9, x10, [sp, #0x40]
    341c:      	ldr	x9, [x8, #0x20]
    3420:      	add	x10, sp, #0x30
    3424:      	str	x9, [sp, #0x50]
    3428:      	ldur	x9, [x8, #0x25]
    342c:      	stur	x9, [sp, #0x55]
    3430:      	ldp	x9, x8, [x8]
    3434:      	stp	x9, x8, [sp, #0x30]
    3438:      	mov	w8, #0x2d               // =45
    343c:      	mov	w9, #0x6                // =6
    3440:      	blr	x9
    3444:      	b	0x1bf8 <kprobe_unwind_perl+0x1bf8>
    3448:      	mov	w8, #0xa                // =10
    344c:      	add	x0, sp, #0x30
    3450:      	mov	w1, #0x2a               // =42
    3454:      	strh	w8, [sp, #0x58]
    3458:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    345c:      	add	x8, x8, #0x0
    3460:      	mov	x2, x25
    3464:      	ldp	x9, x10, [x8, #0x10]
    3468:      	stp	x9, x10, [sp, #0x40]
    346c:      	ldr	x9, [x8, #0x20]
    3470:      	add	x10, sp, #0x30
    3474:      	str	x9, [sp, #0x50]
    3478:      	ldp	x8, x9, [x8]
    347c:      	stp	x8, x9, [sp, #0x30]
    3480:      	mov	w8, #0x2a               // =42
    3484:      	mov	w9, #0x6                // =6
    3488:      	blr	x9
    348c:      	b	0x2f0c <kprobe_unwind_perl+0x2f0c>
    3490:      	ldr	w8, [x23]
    3494:      	cbz	w8, 0x2210 <kprobe_unwind_perl+0x2210>
    3498:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    349c:      	add	x8, x8, #0x0
    34a0:      	add	x0, sp, #0x30
    34a4:      	ldp	x9, x10, [x8, #0x10]
    34a8:      	mov	w1, #0x26               // =38
    34ac:      	stp	x9, x10, [sp, #0x40]
    34b0:      	ldur	x9, [x8, #0x1e]
    34b4:      	add	x10, sp, #0x30
    34b8:      	stur	x9, [sp, #0x4e]
    34bc:      	ldp	x8, x9, [x8]
    34c0:      	stp	x8, x9, [sp, #0x30]
    34c4:      	mov	w8, #0x26               // =38
    34c8:      	mov	w9, #0x6                // =6
    34cc:      	ldr	w2, [sp, #0x94]
    34d0:      	b	0x252c <kprobe_unwind_perl+0x252c>
    34d4:      	add	x8, sp, #0x98
    34d8:      	ldr	x8, [x8]
    34dc:      	ldr	x24, [sp, #0x10]
    34e0:      	str	x8, [sp, #0x8]
    34e4:      	cbz	x8, 0x131c <kprobe_unwind_perl+0x131c>
    34e8:      	ldr	x24, [x24]
    34ec:      	ldr	w8, [x23]
    34f0:      	cbnz	w8, 0x6200 <kprobe_unwind_perl+0x6200>
    34f4:      	ldr	w8, [x21, #0x2c0]
    34f8:      	cmp	w8, #0x7e
    34fc:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    3500:      	add	w9, w8, #0x1
    3504:      	mov	w10, #0x7               // =7
    3508:      	str	w9, [x21, #0x2c0]
    350c:      	mov	w9, #0x18               // =24
    3510:      	umaddl	x8, w8, w9, x21
    3514:      	str	x24, [x8, #0x2d8]
    3518:      	ldp	x9, x24, [sp, #0x8]
    351c:      	strb	w10, [x8, #0x2e0]
    3520:      	str	wzr, [x8, #0x2e4]
    3524:      	str	x9, [x8, #0x2d0]
    3528:      	add	x9, x8, #0x2d0
    352c:      	str	xzr, [x21, #0xf30]
    3530:      	stur	wzr, [x9, #0x11]
    3534:      	b	0x1ac0 <kprobe_unwind_perl+0x1ac0>
    3538:      	mov	w8, #0x786c             // =30828
    353c:      	add	x10, sp, #0x30
    3540:      	add	x0, sp, #0x30
    3544:      	mov	w1, #0x13               // =19
    3548:      	movk	w8, #0xa, lsl #16
    354c:      	stur	w8, [sp, #0x3f]
    3550:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    3554:      	add	x8, x8, #0x0
    3558:      	ldp	x9, x8, [x8]
    355c:      	stp	x9, x8, [sp, #0x30]
    3560:      	mov	w8, #0x13               // =19
    3564:      	mov	w9, #0x6                // =6
    3568:      	ldr	x2, [sp, #0x98]
    356c:      	blr	x9
    3570:      	ldr	x8, [sp, #0x98]
    3574:      	b	0x338 <kprobe_unwind_perl+0x338>
    3578:      	ldr	w8, [x23]
    357c:      	cbz	w8, 0x2f04 <kprobe_unwind_perl+0x2f04>
    3580:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    3584:      	add	x8, x8, #0x0
    3588:      	add	x0, sp, #0x30
    358c:      	ldp	x9, x10, [x8, #0x10]
    3590:      	mov	w1, #0x26               // =38
    3594:      	stp	x9, x10, [sp, #0x40]
    3598:      	ldur	x9, [x8, #0x1e]
    359c:      	add	x10, sp, #0x30
    35a0:      	stur	x9, [sp, #0x4e]
    35a4:      	ldp	x8, x9, [x8]
    35a8:      	stp	x8, x9, [sp, #0x30]
    35ac:      	mov	w8, #0x26               // =38
    35b0:      	mov	w9, #0x6                // =6
    35b4:      	ldr	w2, [sp, #0xb8]
    35b8:      	ldr	w3, [sp, #0xa4]
    35bc:      	blr	x9
    35c0:      	b	0x2f04 <kprobe_unwind_perl+0x2f04>
    35c4:      	mov	w8, #0xa                // =10
    35c8:      	add	x10, sp, #0x30
    35cc:      	add	x0, sp, #0x30
    35d0:      	strh	w8, [sp, #0x40]
    35d4:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    35d8:      	add	x8, x8, #0x0
    35dc:      	mov	w1, #0x12               // =18
    35e0:      	ldp	x9, x8, [x8]
    35e4:      	stp	x9, x8, [sp, #0x30]
    35e8:      	mov	w8, #0x12               // =18
    35ec:      	mov	w9, #0x6                // =6
    35f0:      	ldrb	w2, [sp, #0x7c]
    35f4:      	blr	x9
    35f8:      	ldrb	w8, [sp, #0x7c]
    35fc:      	and	w9, w8, #0xf
    3600:      	sub	w10, w9, #0x9
    3604:      	cmp	w10, #0x2
    3608:      	b.lo	0x2fe8 <kprobe_unwind_perl+0x2fe8>
    360c:      	cmp	w9, #0xc
    3610:      	b.ne	0x36f4 <kprobe_unwind_perl+0x36f4>
    3614:      	mov	w29, #0x3               // =3
    3618:      	ldrb	w8, [x22, #0x1d]
    361c:      	ldr	x9, [x21, #0xf40]
    3620:      	adrp	x0, 0x3000 <kprobe_unwind_perl+0x3000>
    3624:      	add	x1, sp, #0xa8
    3628:      	sub	x8, x9, x8
    362c:      	add	x9, sp, #0xa8
    3630:      	str	x8, [x21, #0xf40]
    3634:      	mov	w8, #0x10               // =16
    3638:      	str	w8, [sp, #0xa8]
    363c:      	mov	w8, #0x1                // =1
    3640:      	ldr	x0, [x0]
    3644:      	blr	x8
    3648:      	cbz	x0, 0x3668 <kprobe_unwind_perl+0x3668>
    364c:      	ldr	x8, [x0]
    3650:      	add	x8, x8, #0x1
    3654:      	str	x8, [x0]
    3658:      	ldp	x24, x9, [sp, #0x10]
    365c:      	cmp	w29, #0x3
    3660:      	b.eq	0x367c <kprobe_unwind_perl+0x367c>
    3664:      	b	0x563c <kprobe_unwind_perl+0x563c>
    3668:      	ldr	w8, [x23]
    366c:      	cbnz	w8, 0x3b14 <kprobe_unwind_perl+0x3b14>
    3670:      	ldp	x24, x9, [sp, #0x10]
    3674:      	cmp	w29, #0x3
    3678:      	b.ne	0x563c <kprobe_unwind_perl+0x563c>
    367c:      	ldr	x25, [x21, #0xf40]
    3680:      	cmp	x25, x9
    3684:      	b.lo	0x2ecc <kprobe_unwind_perl+0x2ecc>
    3688:      	ldrb	w8, [x22, #0x19]
    368c:      	mov	w9, #0x1                // =1
    3690:      	mov	w10, #0x70              // =112
    3694:      	add	x11, sp, #0x7c
    3698:      	add	x0, sp, #0x7c
    369c:      	mov	w1, #0x1                // =1
    36a0:      	add	x8, x25, x8
    36a4:      	ldrb	w8, [x22, #0x19]
    36a8:      	add	x2, x25, x8
    36ac:      	blr	x10
    36b0:      	cbz	x0, 0x3778 <kprobe_unwind_perl+0x3778>
    36b4:      	ldr	w8, [x23]
    36b8:      	cbnz	w8, 0x3bec <kprobe_unwind_perl+0x3bec>
    36bc:      	mov	w8, #0x13               // =19
    36c0:      	adrp	x0, 0x3000 <kprobe_unwind_perl+0x3000>
    36c4:      	add	x9, sp, #0xa8
    36c8:      	str	w8, [sp, #0xa8]
    36cc:      	mov	w8, #0x1                // =1
    36d0:      	add	x1, sp, #0xa8
    36d4:      	ldr	x0, [x0]
    36d8:      	blr	x8
    36dc:      	cbz	x0, 0x3870 <kprobe_unwind_perl+0x3870>
    36e0:      	ldr	x8, [x0]
    36e4:      	mov	w29, #0x3               // =3
    36e8:      	add	x8, x8, #0x1
    36ec:      	str	x8, [x0]
    36f0:      	b	0x3dc0 <kprobe_unwind_perl+0x3dc0>
    36f4:      	ldr	x8, [sp, #0x10]
    36f8:      	mov	w29, #0x3               // =3
    36fc:      	ldr	x8, [x8]
    3700:      	cbnz	x8, 0x3618 <kprobe_unwind_perl+0x3618>
    3704:      	ldrb	w8, [x22, #0x1a]
    3708:      	mov	w9, #0x8                // =8
    370c:      	mov	w10, #0x70              // =112
    3710:      	ldr	x0, [sp, #0x10]
    3714:      	mov	w1, #0x8                // =8
    3718:      	add	x8, x25, x8
    371c:      	ldrb	w8, [x22, #0x1a]
    3720:      	add	x2, x25, x8
    3724:      	blr	x10
    3728:      	cbnz	x0, 0x2f04 <kprobe_unwind_perl+0x2f04>
    372c:      	ldr	w8, [x23]
    3730:      	cbz	w8, 0x3618 <kprobe_unwind_perl+0x3618>
    3734:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    3738:      	add	x8, x8, #0x0
    373c:      	add	x0, sp, #0x30
    3740:      	ldp	x9, x10, [x8]
    3744:      	mov	w1, #0x1e               // =30
    3748:      	stp	x9, x10, [sp, #0x30]
    374c:      	ldr	x9, [x8, #0x10]
    3750:      	ldur	x8, [x8, #0x16]
    3754:      	add	x10, sp, #0x30
    3758:      	str	x9, [sp, #0x40]
    375c:      	stur	x8, [sp, #0x46]
    3760:      	mov	w8, #0x1e               // =30
    3764:      	mov	w9, #0x6                // =6
    3768:      	ldr	x8, [sp, #0x10]
    376c:      	ldr	x2, [x8]
    3770:      	blr	x9
    3774:      	b	0x3618 <kprobe_unwind_perl+0x3618>
    3778:      	ldr	w8, [x23]
    377c:      	cbnz	w8, 0x3d6c <kprobe_unwind_perl+0x3d6c>
    3780:      	ldrb	w8, [sp, #0x7c]
    3784:      	and	w9, w8, #0xf
    3788:      	sub	w10, w9, #0x9
    378c:      	cmp	w10, #0x2
    3790:      	b.hs	0x3db4 <kprobe_unwind_perl+0x3db4>
    3794:      	sxtb	w8, w8
    3798:      	tbnz	w8, #0x1f, 0x3dbc <kprobe_unwind_perl+0x3dbc>
    379c:      	ldrb	w8, [x22, #0x1b]
    37a0:      	mov	w9, #0x8                // =8
    37a4:      	mov	w10, #0x70              // =112
    37a8:      	add	x11, sp, #0x30
    37ac:      	add	x0, sp, #0x30
    37b0:      	mov	w1, #0x8                // =8
    37b4:      	add	x8, x25, x8
    37b8:      	ldrb	w8, [x22, #0x1b]
    37bc:      	add	x2, x25, x8
    37c0:      	blr	x10
    37c4:      	cbnz	x0, 0x36b4 <kprobe_unwind_perl+0x36b4>
    37c8:      	ldr	x8, [sp, #0x30]
    37cc:      	mov	w9, #0x8                // =8
    37d0:      	mov	w10, #0x70              // =112
    37d4:      	add	x11, sp, #0x70
    37d8:      	add	x0, sp, #0x70
    37dc:      	mov	w1, #0x8                // =8
    37e0:      	cmp	x8, #0x0
    37e4:      	mov	w8, #0x3                // =3
    37e8:      	csinc	w29, w8, wzr, ne
    37ec:      	ldrb	w8, [x22, #0x1c]
    37f0:      	add	x8, x25, x8
    37f4:      	ldrb	w8, [x22, #0x1c]
    37f8:      	add	x2, x25, x8
    37fc:      	blr	x10
    3800:      	cbnz	x0, 0x36b4 <kprobe_unwind_perl+0x36b4>
    3804:      	ldr	x24, [sp, #0x70]
    3808:      	ldrb	w8, [x22, #0x1e]
    380c:      	mov	w9, #0x4                // =4
    3810:      	mov	w10, #0x70              // =112
    3814:      	add	x11, sp, #0xb8
    3818:      	add	x0, sp, #0xb8
    381c:      	mov	w1, #0x4                // =4
    3820:      	add	x8, x24, x8
    3824:      	ldrb	w8, [x22, #0x1e]
    3828:      	add	x2, x24, x8
    382c:      	blr	x10
    3830:      	cbz	x0, 0x38c0 <kprobe_unwind_perl+0x38c0>
    3834:      	ldr	w8, [x23]
    3838:      	cbnz	w8, 0x52f0 <kprobe_unwind_perl+0x52f0>
    383c:      	mov	w8, #0x14               // =20
    3840:      	adrp	x0, 0x3000 <kprobe_unwind_perl+0x3000>
    3844:      	add	x9, sp, #0xbc
    3848:      	str	w8, [sp, #0xbc]
    384c:      	mov	w8, #0x1                // =1
    3850:      	add	x1, sp, #0xbc
    3854:      	ldr	x0, [x0]
    3858:      	blr	x8
    385c:      	cbz	x0, 0x3a7c <kprobe_unwind_perl+0x3a7c>
    3860:      	ldr	x8, [x0]
    3864:      	add	x8, x8, #0x1
    3868:      	str	x8, [x0]
    386c:      	b	0x36b4 <kprobe_unwind_perl+0x36b4>
    3870:      	ldr	w8, [x23]
    3874:      	cbz	w8, 0x3dbc <kprobe_unwind_perl+0x3dbc>
    3878:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    387c:      	add	x8, x8, #0x0
    3880:      	add	x0, sp, #0x30
    3884:      	ldp	x9, x10, [x8, #0x10]
    3888:      	mov	w1, #0x2e               // =46
    388c:      	stp	x9, x10, [sp, #0x40]
    3890:      	ldr	x9, [x8, #0x20]
    3894:      	add	x10, sp, #0x30
    3898:      	str	x9, [sp, #0x50]
    389c:      	ldur	x9, [x8, #0x26]
    38a0:      	stur	x9, [sp, #0x56]
    38a4:      	ldp	x9, x8, [x8]
    38a8:      	stp	x9, x8, [sp, #0x30]
    38ac:      	mov	w8, #0x2e               // =46
    38b0:      	mov	w9, #0x6                // =6
    38b4:      	ldr	w2, [sp, #0xa8]
    38b8:      	blr	x9
    38bc:      	b	0x3dbc <kprobe_unwind_perl+0x3dbc>
    38c0:      	ldr	w8, [sp, #0xb8]
    38c4:      	and	w8, w8, #0x1f
    38c8:      	cmp	w8, #0xd
    38cc:      	b.ne	0x3acc <kprobe_unwind_perl+0x3acc>
    38d0:      	ldrb	w8, [x22, #0x1f]
    38d4:      	mov	w9, #0x8                // =8
    38d8:      	mov	w10, #0x70              // =112
    38dc:      	add	x11, sp, #0xa8
    38e0:      	add	x0, sp, #0xa8
    38e4:      	mov	w1, #0x8                // =8
    38e8:      	add	x8, x24, x8
    38ec:      	ldrb	w8, [x22, #0x1f]
    38f0:      	add	x2, x24, x8
    38f4:      	blr	x10
    38f8:      	cbnz	x0, 0x3834 <kprobe_unwind_perl+0x3834>
    38fc:      	ldr	x8, [sp, #0xa8]
    3900:      	ldrb	w9, [x22, #0x21]
    3904:      	mov	w10, #0x70              // =112
    3908:      	add	x11, sp, #0xa4
    390c:      	add	x0, sp, #0xa4
    3910:      	mov	w1, #0x4                // =4
    3914:      	add	x8, x8, x9
    3918:      	mov	w9, #0x4                // =4
    391c:      	ldr	x8, [sp, #0xa8]
    3920:      	ldrb	w9, [x22, #0x21]
    3924:      	add	x2, x8, x9
    3928:      	blr	x10
    392c:      	cbnz	x0, 0x3834 <kprobe_unwind_perl+0x3834>
    3930:      	ldrb	w8, [sp, #0xa5]
    3934:      	tbnz	w8, #0x7, 0x3d20 <kprobe_unwind_perl+0x3d20>
    3938:      	ldr	x8, [sp, #0xa8]
    393c:      	ldrb	w9, [x22, #0x22]
    3940:      	mov	w10, #0x70              // =112
    3944:      	add	x11, sp, #0x98
    3948:      	add	x0, sp, #0x98
    394c:      	mov	w1, #0x8                // =8
    3950:      	add	x8, x8, x9
    3954:      	mov	w9, #0x8                // =8
    3958:      	ldr	x8, [sp, #0xa8]
    395c:      	ldrb	w9, [x22, #0x22]
    3960:      	add	x2, x8, x9
    3964:      	blr	x10
    3968:      	cbnz	x0, 0x3834 <kprobe_unwind_perl+0x3834>
    396c:      	ldr	x8, [sp, #0x98]
    3970:      	cbz	x8, 0x3834 <kprobe_unwind_perl+0x3834>
    3974:      	ldr	w9, [x23]
    3978:      	cbnz	w9, 0x685c <kprobe_unwind_perl+0x685c>
    397c:      	ldrb	w9, [x22, #0x1e]
    3980:      	mov	w10, #0x70              // =112
    3984:      	add	x11, sp, #0x94
    3988:      	add	x0, sp, #0x94
    398c:      	mov	w1, #0x4                // =4
    3990:      	add	x8, x8, x9
    3994:      	mov	w9, #0x4                // =4
    3998:      	ldr	x8, [sp, #0x98]
    399c:      	ldrb	w9, [x22, #0x1e]
    39a0:      	add	x2, x8, x9
    39a4:      	blr	x10
    39a8:      	cbnz	x0, 0x3834 <kprobe_unwind_perl+0x3834>
    39ac:      	ldr	w8, [sp, #0x94]
    39b0:      	mov	w9, #0x801f             // =32799
    39b4:      	and	w8, w8, w9
    39b8:      	mov	w9, #0x8009             // =32777
    39bc:      	cmp	w8, w9
    39c0:      	b.ne	0x4b04 <kprobe_unwind_perl+0x4b04>
    39c4:      	ldr	x8, [sp, #0x98]
    39c8:      	ldrb	w9, [x22, #0x20]
    39cc:      	mov	w10, #0x70              // =112
    39d0:      	add	x11, sp, #0x88
    39d4:      	add	x0, sp, #0x88
    39d8:      	mov	w1, #0x8                // =8
    39dc:      	add	x8, x8, x9
    39e0:      	mov	w9, #0x8                // =8
    39e4:      	ldr	x8, [sp, #0x98]
    39e8:      	ldrb	w9, [x22, #0x20]
    39ec:      	add	x2, x8, x9
    39f0:      	blr	x10
    39f4:      	cbnz	x0, 0x3834 <kprobe_unwind_perl+0x3834>
    39f8:      	ldr	x8, [sp, #0x88]
    39fc:      	ldrb	w9, [x22, #0x23]
    3a00:      	mov	w10, #0x70              // =112
    3a04:      	add	x11, sp, #0x80
    3a08:      	add	x0, sp, #0x80
    3a0c:      	mov	w1, #0x8                // =8
    3a10:      	add	x8, x8, x9
    3a14:      	mov	w9, #0x8                // =8
    3a18:      	ldr	x8, [sp, #0x88]
    3a1c:      	ldrb	w9, [x22, #0x23]
    3a20:      	add	x2, x8, x9
    3a24:      	blr	x10
    3a28:      	cbnz	x0, 0x3834 <kprobe_unwind_perl+0x3834>
    3a2c:      	ldr	x24, [sp, #0x80]
    3a30:      	cbz	x24, 0x6250 <kprobe_unwind_perl+0x6250>
    3a34:      	ldr	w8, [x23]
    3a38:      	cbz	w8, 0x625c <kprobe_unwind_perl+0x625c>
    3a3c:      	mov	w8, #0x786c             // =30828
    3a40:      	add	x10, sp, #0x30
    3a44:      	add	x0, sp, #0x30
    3a48:      	mov	w1, #0x14               // =20
    3a4c:      	movk	w8, #0xa, lsl #16
    3a50:      	str	w8, [sp, #0x40]
    3a54:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    3a58:      	add	x8, x8, #0x0
    3a5c:      	ldp	x9, x8, [x8]
    3a60:      	stp	x9, x8, [sp, #0x30]
    3a64:      	mov	w8, #0x14               // =20
    3a68:      	mov	w9, #0x6                // =6
    3a6c:      	ldr	x2, [sp, #0x80]
    3a70:      	blr	x9
    3a74:      	add	x8, sp, #0x80
    3a78:      	b	0x6254 <kprobe_unwind_perl+0x6254>
    3a7c:      	ldr	w8, [x23]
    3a80:      	cbz	w8, 0x36b4 <kprobe_unwind_perl+0x36b4>
    3a84:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    3a88:      	add	x8, x8, #0x0
    3a8c:      	add	x0, sp, #0x30
    3a90:      	ldp	x9, x10, [x8, #0x10]
    3a94:      	mov	w1, #0x2e               // =46
    3a98:      	stp	x9, x10, [sp, #0x40]
    3a9c:      	ldr	x9, [x8, #0x20]
    3aa0:      	add	x10, sp, #0x30
    3aa4:      	str	x9, [sp, #0x50]
    3aa8:      	ldur	x9, [x8, #0x26]
    3aac:      	stur	x9, [sp, #0x56]
    3ab0:      	ldp	x9, x8, [x8]
    3ab4:      	stp	x9, x8, [sp, #0x30]
    3ab8:      	mov	w8, #0x2e               // =46
    3abc:      	mov	w9, #0x6                // =6
    3ac0:      	ldr	w2, [sp, #0xbc]
    3ac4:      	blr	x9
    3ac8:      	b	0x36b4 <kprobe_unwind_perl+0x36b4>
    3acc:      	ldr	w8, [x23]
    3ad0:      	cbz	w8, 0x36b4 <kprobe_unwind_perl+0x36b4>
    3ad4:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    3ad8:      	add	x8, x8, #0x0
    3adc:      	add	x0, sp, #0x30
    3ae0:      	ldp	x9, x10, [x8]
    3ae4:      	mov	w1, #0x1e               // =30
    3ae8:      	stp	x9, x10, [sp, #0x30]
    3aec:      	ldr	x9, [x8, #0x10]
    3af0:      	ldur	x8, [x8, #0x16]
    3af4:      	add	x10, sp, #0x30
    3af8:      	str	x9, [sp, #0x40]
    3afc:      	stur	x8, [sp, #0x46]
    3b00:      	mov	w8, #0x1e               // =30
    3b04:      	mov	w9, #0x6                // =6
    3b08:      	ldr	w2, [sp, #0xb8]
    3b0c:      	blr	x9
    3b10:      	b	0x36b4 <kprobe_unwind_perl+0x36b4>
    3b14:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    3b18:      	add	x8, x8, #0x0
    3b1c:      	add	x0, sp, #0x30
    3b20:      	ldp	x9, x10, [x8, #0x10]
    3b24:      	mov	w1, #0x2e               // =46
    3b28:      	stp	x9, x10, [sp, #0x40]
    3b2c:      	ldr	x9, [x8, #0x20]
    3b30:      	add	x10, sp, #0x30
    3b34:      	str	x9, [sp, #0x50]
    3b38:      	ldur	x9, [x8, #0x26]
    3b3c:      	stur	x9, [sp, #0x56]
    3b40:      	ldp	x9, x8, [x8]
    3b44:      	stp	x9, x8, [sp, #0x30]
    3b48:      	mov	w8, #0x2e               // =46
    3b4c:      	mov	w9, #0x6                // =6
    3b50:      	ldr	w2, [sp, #0xa8]
    3b54:      	blr	x9
    3b58:      	ldp	x24, x9, [sp, #0x10]
    3b5c:      	cmp	w29, #0x3
    3b60:      	b.eq	0x367c <kprobe_unwind_perl+0x367c>
    3b64:      	b	0x563c <kprobe_unwind_perl+0x563c>
    3b68:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    3b6c:      	add	x8, x8, #0x0
    3b70:      	add	x0, sp, #0x30
    3b74:      	ldp	x9, x10, [x8, #0x10]
    3b78:      	mov	w1, #0x2d               // =45
    3b7c:      	stp	x9, x10, [sp, #0x40]
    3b80:      	ldr	x9, [x8, #0x20]
    3b84:      	add	x10, sp, #0x30
    3b88:      	str	x9, [sp, #0x50]
    3b8c:      	ldur	x9, [x8, #0x25]
    3b90:      	stur	x9, [sp, #0x55]
    3b94:      	ldp	x9, x8, [x8]
    3b98:      	stp	x9, x8, [sp, #0x30]
    3b9c:      	mov	w8, #0x2d               // =45
    3ba0:      	mov	w9, #0x6                // =6
    3ba4:      	blr	x9
    3ba8:      	b	0x22e0 <kprobe_unwind_perl+0x22e0>
    3bac:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    3bb0:      	add	x8, x8, #0x0
    3bb4:      	add	x0, sp, #0x30
    3bb8:      	ldp	x9, x10, [x8]
    3bbc:      	mov	w1, #0x1e               // =30
    3bc0:      	stp	x9, x10, [sp, #0x30]
    3bc4:      	ldr	x9, [x8, #0x10]
    3bc8:      	ldur	x8, [x8, #0x16]
    3bcc:      	add	x10, sp, #0x30
    3bd0:      	str	x9, [sp, #0x40]
    3bd4:      	stur	x8, [sp, #0x46]
    3bd8:      	mov	w8, #0x1e               // =30
    3bdc:      	mov	w9, #0x6                // =6
    3be0:      	ldr	w2, [sp, #0xb8]
    3be4:      	blr	x9
    3be8:      	b	0x1e5c <kprobe_unwind_perl+0x1e5c>
    3bec:      	mov	w8, #0xa                // =10
    3bf0:      	add	x0, sp, #0x30
    3bf4:      	mov	w1, #0x2a               // =42
    3bf8:      	strh	w8, [sp, #0x58]
    3bfc:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    3c00:      	add	x8, x8, #0x0
    3c04:      	mov	x2, x25
    3c08:      	ldp	x9, x10, [x8, #0x10]
    3c0c:      	stp	x9, x10, [sp, #0x40]
    3c10:      	ldr	x9, [x8, #0x20]
    3c14:      	add	x10, sp, #0x30
    3c18:      	str	x9, [sp, #0x50]
    3c1c:      	ldp	x8, x9, [x8]
    3c20:      	stp	x8, x9, [sp, #0x30]
    3c24:      	mov	w8, #0x2a               // =42
    3c28:      	mov	w9, #0x6                // =6
    3c2c:      	blr	x9
    3c30:      	b	0x36bc <kprobe_unwind_perl+0x36bc>
    3c34:      	ldr	w8, [x23]
    3c38:      	cbz	w8, 0x27f8 <kprobe_unwind_perl+0x27f8>
    3c3c:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    3c40:      	add	x8, x8, #0x0
    3c44:      	add	x0, sp, #0x30
    3c48:      	ldp	x9, x10, [x8, #0x10]
    3c4c:      	mov	w1, #0x26               // =38
    3c50:      	stp	x9, x10, [sp, #0x40]
    3c54:      	ldur	x9, [x8, #0x1e]
    3c58:      	add	x10, sp, #0x30
    3c5c:      	stur	x9, [sp, #0x4e]
    3c60:      	ldp	x8, x9, [x8]
    3c64:      	stp	x8, x9, [sp, #0x30]
    3c68:      	mov	w8, #0x26               // =38
    3c6c:      	mov	w9, #0x6                // =6
    3c70:      	ldr	w2, [sp, #0x94]
    3c74:      	blr	x9
    3c78:      	b	0x27f8 <kprobe_unwind_perl+0x27f8>
    3c7c:      	add	x8, sp, #0x98
    3c80:      	ldr	x8, [x8]
    3c84:      	ldr	x24, [sp, #0x10]
    3c88:      	str	x8, [sp, #0x8]
    3c8c:      	cbz	x8, 0x1a74 <kprobe_unwind_perl+0x1a74>
    3c90:      	ldr	x24, [x24]
    3c94:      	ldr	w8, [x23]
    3c98:      	cbnz	w8, 0x6588 <kprobe_unwind_perl+0x6588>
    3c9c:      	ldr	w8, [x21, #0x2c0]
    3ca0:      	cmp	w8, #0x7e
    3ca4:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    3ca8:      	add	w9, w8, #0x1
    3cac:      	mov	w10, #0x7               // =7
    3cb0:      	str	w9, [x21, #0x2c0]
    3cb4:      	mov	w9, #0x18               // =24
    3cb8:      	umaddl	x8, w8, w9, x21
    3cbc:      	str	x24, [x8, #0x2d8]
    3cc0:      	ldp	x9, x24, [sp, #0x8]
    3cc4:      	strb	w10, [x8, #0x2e0]
    3cc8:      	str	wzr, [x8, #0x2e4]
    3ccc:      	str	x9, [x8, #0x2d0]
    3cd0:      	add	x9, x8, #0x2d0
    3cd4:      	str	xzr, [x21, #0xf30]
    3cd8:      	stur	wzr, [x9, #0x11]
    3cdc:      	b	0x214c <kprobe_unwind_perl+0x214c>
    3ce0:      	mov	w8, #0x786c             // =30828
    3ce4:      	add	x10, sp, #0x30
    3ce8:      	add	x0, sp, #0x30
    3cec:      	mov	w1, #0x13               // =19
    3cf0:      	movk	w8, #0xa, lsl #16
    3cf4:      	stur	w8, [sp, #0x3f]
    3cf8:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    3cfc:      	add	x8, x8, #0x0
    3d00:      	ldp	x9, x8, [x8]
    3d04:      	stp	x9, x8, [sp, #0x30]
    3d08:      	mov	w8, #0x13               // =19
    3d0c:      	mov	w9, #0x6                // =6
    3d10:      	ldr	x2, [sp, #0x98]
    3d14:      	blr	x9
    3d18:      	ldr	x8, [sp, #0x98]
    3d1c:      	b	0xfa0 <kprobe_unwind_perl+0xfa0>
    3d20:      	ldr	w8, [x23]
    3d24:      	cbz	w8, 0x36b4 <kprobe_unwind_perl+0x36b4>
    3d28:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    3d2c:      	add	x8, x8, #0x0
    3d30:      	add	x0, sp, #0x30
    3d34:      	ldp	x9, x10, [x8, #0x10]
    3d38:      	mov	w1, #0x26               // =38
    3d3c:      	stp	x9, x10, [sp, #0x40]
    3d40:      	ldur	x9, [x8, #0x1e]
    3d44:      	add	x10, sp, #0x30
    3d48:      	stur	x9, [sp, #0x4e]
    3d4c:      	ldp	x8, x9, [x8]
    3d50:      	stp	x8, x9, [sp, #0x30]
    3d54:      	mov	w8, #0x26               // =38
    3d58:      	mov	w9, #0x6                // =6
    3d5c:      	ldr	w2, [sp, #0xb8]
    3d60:      	ldr	w3, [sp, #0xa4]
    3d64:      	blr	x9
    3d68:      	b	0x36b4 <kprobe_unwind_perl+0x36b4>
    3d6c:      	mov	w8, #0xa                // =10
    3d70:      	add	x10, sp, #0x30
    3d74:      	add	x0, sp, #0x30
    3d78:      	strh	w8, [sp, #0x40]
    3d7c:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    3d80:      	add	x8, x8, #0x0
    3d84:      	mov	w1, #0x12               // =18
    3d88:      	ldp	x9, x8, [x8]
    3d8c:      	stp	x9, x8, [sp, #0x30]
    3d90:      	mov	w8, #0x12               // =18
    3d94:      	mov	w9, #0x6                // =6
    3d98:      	ldrb	w2, [sp, #0x7c]
    3d9c:      	blr	x9
    3da0:      	ldrb	w8, [sp, #0x7c]
    3da4:      	and	w9, w8, #0xf
    3da8:      	sub	w10, w9, #0x9
    3dac:      	cmp	w10, #0x2
    3db0:      	b.lo	0x3794 <kprobe_unwind_perl+0x3794>
    3db4:      	cmp	w9, #0xc
    3db8:      	b.ne	0x3e9c <kprobe_unwind_perl+0x3e9c>
    3dbc:      	mov	w29, #0x3               // =3
    3dc0:      	ldrb	w8, [x22, #0x1d]
    3dc4:      	ldr	x9, [x21, #0xf40]
    3dc8:      	adrp	x0, 0x3000 <kprobe_unwind_perl+0x3000>
    3dcc:      	add	x1, sp, #0xa8
    3dd0:      	sub	x8, x9, x8
    3dd4:      	add	x9, sp, #0xa8
    3dd8:      	str	x8, [x21, #0xf40]
    3ddc:      	mov	w8, #0x10               // =16
    3de0:      	str	w8, [sp, #0xa8]
    3de4:      	mov	w8, #0x1                // =1
    3de8:      	ldr	x0, [x0]
    3dec:      	blr	x8
    3df0:      	cbz	x0, 0x3e10 <kprobe_unwind_perl+0x3e10>
    3df4:      	ldr	x8, [x0]
    3df8:      	add	x8, x8, #0x1
    3dfc:      	str	x8, [x0]
    3e00:      	ldp	x24, x9, [sp, #0x10]
    3e04:      	cmp	w29, #0x3
    3e08:      	b.eq	0x3e24 <kprobe_unwind_perl+0x3e24>
    3e0c:      	b	0x563c <kprobe_unwind_perl+0x563c>
    3e10:      	ldr	w8, [x23]
    3e14:      	cbnz	w8, 0x42bc <kprobe_unwind_perl+0x42bc>
    3e18:      	ldp	x24, x9, [sp, #0x10]
    3e1c:      	cmp	w29, #0x3
    3e20:      	b.ne	0x563c <kprobe_unwind_perl+0x563c>
    3e24:      	ldr	x25, [x21, #0xf40]
    3e28:      	cmp	x25, x9
    3e2c:      	b.lo	0x2ecc <kprobe_unwind_perl+0x2ecc>
    3e30:      	ldrb	w8, [x22, #0x19]
    3e34:      	mov	w9, #0x1                // =1
    3e38:      	mov	w10, #0x70              // =112
    3e3c:      	add	x11, sp, #0x7c
    3e40:      	add	x0, sp, #0x7c
    3e44:      	mov	w1, #0x1                // =1
    3e48:      	add	x8, x25, x8
    3e4c:      	ldrb	w8, [x22, #0x19]
    3e50:      	add	x2, x25, x8
    3e54:      	blr	x10
    3e58:      	cbz	x0, 0x3f20 <kprobe_unwind_perl+0x3f20>
    3e5c:      	ldr	w8, [x23]
    3e60:      	cbnz	w8, 0x4354 <kprobe_unwind_perl+0x4354>
    3e64:      	mov	w8, #0x13               // =19
    3e68:      	adrp	x0, 0x3000 <kprobe_unwind_perl+0x3000>
    3e6c:      	add	x9, sp, #0xa8
    3e70:      	str	w8, [sp, #0xa8]
    3e74:      	mov	w8, #0x1                // =1
    3e78:      	add	x1, sp, #0xa8
    3e7c:      	ldr	x0, [x0]
    3e80:      	blr	x8
    3e84:      	cbz	x0, 0x4018 <kprobe_unwind_perl+0x4018>
    3e88:      	ldr	x8, [x0]
    3e8c:      	mov	w29, #0x3               // =3
    3e90:      	add	x8, x8, #0x1
    3e94:      	str	x8, [x0]
    3e98:      	b	0x4528 <kprobe_unwind_perl+0x4528>
    3e9c:      	ldr	x8, [sp, #0x10]
    3ea0:      	mov	w29, #0x3               // =3
    3ea4:      	ldr	x8, [x8]
    3ea8:      	cbnz	x8, 0x3dc0 <kprobe_unwind_perl+0x3dc0>
    3eac:      	ldrb	w8, [x22, #0x1a]
    3eb0:      	mov	w9, #0x8                // =8
    3eb4:      	mov	w10, #0x70              // =112
    3eb8:      	ldr	x0, [sp, #0x10]
    3ebc:      	mov	w1, #0x8                // =8
    3ec0:      	add	x8, x25, x8
    3ec4:      	ldrb	w8, [x22, #0x1a]
    3ec8:      	add	x2, x25, x8
    3ecc:      	blr	x10
    3ed0:      	cbnz	x0, 0x36b4 <kprobe_unwind_perl+0x36b4>
    3ed4:      	ldr	w8, [x23]
    3ed8:      	cbz	w8, 0x3dc0 <kprobe_unwind_perl+0x3dc0>
    3edc:      	adrp	x8, 0x3000 <kprobe_unwind_perl+0x3000>
    3ee0:      	add	x8, x8, #0x0
    3ee4:      	add	x0, sp, #0x30
    3ee8:      	ldp	x9, x10, [x8]
    3eec:      	mov	w1, #0x1e               // =30
    3ef0:      	stp	x9, x10, [sp, #0x30]
    3ef4:      	ldr	x9, [x8, #0x10]
    3ef8:      	ldur	x8, [x8, #0x16]
    3efc:      	add	x10, sp, #0x30
    3f00:      	str	x9, [sp, #0x40]
    3f04:      	stur	x8, [sp, #0x46]
    3f08:      	mov	w8, #0x1e               // =30
    3f0c:      	mov	w9, #0x6                // =6
    3f10:      	ldr	x8, [sp, #0x10]
    3f14:      	ldr	x2, [x8]
    3f18:      	blr	x9
    3f1c:      	b	0x3dc0 <kprobe_unwind_perl+0x3dc0>
    3f20:      	ldr	w8, [x23]
    3f24:      	cbnz	w8, 0x44d4 <kprobe_unwind_perl+0x44d4>
    3f28:      	ldrb	w8, [sp, #0x7c]
    3f2c:      	and	w9, w8, #0xf
    3f30:      	sub	w10, w9, #0x9
    3f34:      	cmp	w10, #0x2
    3f38:      	b.hs	0x451c <kprobe_unwind_perl+0x451c>
    3f3c:      	sxtb	w8, w8
    3f40:      	tbnz	w8, #0x1f, 0x4524 <kprobe_unwind_perl+0x4524>
    3f44:      	ldrb	w8, [x22, #0x1b]
    3f48:      	mov	w9, #0x8                // =8
    3f4c:      	mov	w10, #0x70              // =112
    3f50:      	add	x11, sp, #0x30
    3f54:      	add	x0, sp, #0x30
    3f58:      	mov	w1, #0x8                // =8
    3f5c:      	add	x8, x25, x8
    3f60:      	ldrb	w8, [x22, #0x1b]
    3f64:      	add	x2, x25, x8
    3f68:      	blr	x10
    3f6c:      	cbnz	x0, 0x3e5c <kprobe_unwind_perl+0x3e5c>
    3f70:      	ldr	x8, [sp, #0x30]
    3f74:      	mov	w9, #0x8                // =8
    3f78:      	mov	w10, #0x70              // =112
    3f7c:      	add	x11, sp, #0x70
    3f80:      	add	x0, sp, #0x70
    3f84:      	mov	w1, #0x8                // =8
    3f88:      	cmp	x8, #0x0
    3f8c:      	mov	w8, #0x3                // =3
    3f90:      	csinc	w29, w8, wzr, ne
    3f94:      	ldrb	w8, [x22, #0x1c]
    3f98:      	add	x8, x25, x8
    3f9c:      	ldrb	w8, [x22, #0x1c]
    3fa0:      	add	x2, x25, x8
    3fa4:      	blr	x10
    3fa8:      	cbnz	x0, 0x3e5c <kprobe_unwind_perl+0x3e5c>
    3fac:      	ldr	x24, [sp, #0x70]
    3fb0:      	ldrb	w8, [x22, #0x1e]
    3fb4:      	mov	w9, #0x4                // =4
    3fb8:      	mov	w10, #0x70              // =112
    3fbc:      	add	x11, sp, #0xb8
    3fc0:      	add	x0, sp, #0xb8
    3fc4:      	mov	w1, #0x4                // =4
    3fc8:      	add	x8, x24, x8
    3fcc:      	ldrb	w8, [x22, #0x1e]
    3fd0:      	add	x2, x24, x8
    3fd4:      	blr	x10
    3fd8:      	cbz	x0, 0x4068 <kprobe_unwind_perl+0x4068>
    3fdc:      	ldr	w8, [x23]
    3fe0:      	cbnz	w8, 0x612c <kprobe_unwind_perl+0x612c>
    3fe4:      	mov	w8, #0x14               // =20
    3fe8:      	adrp	x0, 0x3000 <kprobe_unwind_perl+0x3000>
    3fec:      	add	x9, sp, #0xbc
    3ff0:      	str	w8, [sp, #0xbc]
    3ff4:      	mov	w8, #0x1                // =1
    3ff8:      	add	x1, sp, #0xbc
    3ffc:      	ldr	x0, [x0]
    4000:      	blr	x8
    4004:      	cbz	x0, 0x4224 <kprobe_unwind_perl+0x4224>
    4008:      	ldr	x8, [x0]
    400c:      	add	x8, x8, #0x1
    4010:      	str	x8, [x0]
    4014:      	b	0x3e5c <kprobe_unwind_perl+0x3e5c>
    4018:      	ldr	w8, [x23]
    401c:      	cbz	w8, 0x4524 <kprobe_unwind_perl+0x4524>
    4020:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4024:      	add	x8, x8, #0x0
    4028:      	add	x0, sp, #0x30
    402c:      	ldp	x9, x10, [x8, #0x10]
    4030:      	mov	w1, #0x2e               // =46
    4034:      	stp	x9, x10, [sp, #0x40]
    4038:      	ldr	x9, [x8, #0x20]
    403c:      	add	x10, sp, #0x30
    4040:      	str	x9, [sp, #0x50]
    4044:      	ldur	x9, [x8, #0x26]
    4048:      	stur	x9, [sp, #0x56]
    404c:      	ldp	x9, x8, [x8]
    4050:      	stp	x9, x8, [sp, #0x30]
    4054:      	mov	w8, #0x2e               // =46
    4058:      	mov	w9, #0x6                // =6
    405c:      	ldr	w2, [sp, #0xa8]
    4060:      	blr	x9
    4064:      	b	0x4524 <kprobe_unwind_perl+0x4524>
    4068:      	ldr	w8, [sp, #0xb8]
    406c:      	and	w8, w8, #0x1f
    4070:      	cmp	w8, #0xd
    4074:      	b.ne	0x4274 <kprobe_unwind_perl+0x4274>
    4078:      	ldrb	w8, [x22, #0x1f]
    407c:      	mov	w9, #0x8                // =8
    4080:      	mov	w10, #0x70              // =112
    4084:      	add	x11, sp, #0xa8
    4088:      	add	x0, sp, #0xa8
    408c:      	mov	w1, #0x8                // =8
    4090:      	add	x8, x24, x8
    4094:      	ldrb	w8, [x22, #0x1f]
    4098:      	add	x2, x24, x8
    409c:      	blr	x10
    40a0:      	cbnz	x0, 0x3fdc <kprobe_unwind_perl+0x3fdc>
    40a4:      	ldr	x8, [sp, #0xa8]
    40a8:      	ldrb	w9, [x22, #0x21]
    40ac:      	mov	w10, #0x70              // =112
    40b0:      	add	x11, sp, #0xa4
    40b4:      	add	x0, sp, #0xa4
    40b8:      	mov	w1, #0x4                // =4
    40bc:      	add	x8, x8, x9
    40c0:      	mov	w9, #0x4                // =4
    40c4:      	ldr	x8, [sp, #0xa8]
    40c8:      	ldrb	w9, [x22, #0x21]
    40cc:      	add	x2, x8, x9
    40d0:      	blr	x10
    40d4:      	cbnz	x0, 0x3fdc <kprobe_unwind_perl+0x3fdc>
    40d8:      	ldrb	w8, [sp, #0xa5]
    40dc:      	tbnz	w8, #0x7, 0x4488 <kprobe_unwind_perl+0x4488>
    40e0:      	ldr	x8, [sp, #0xa8]
    40e4:      	ldrb	w9, [x22, #0x22]
    40e8:      	mov	w10, #0x70              // =112
    40ec:      	add	x11, sp, #0x98
    40f0:      	add	x0, sp, #0x98
    40f4:      	mov	w1, #0x8                // =8
    40f8:      	add	x8, x8, x9
    40fc:      	mov	w9, #0x8                // =8
    4100:      	ldr	x8, [sp, #0xa8]
    4104:      	ldrb	w9, [x22, #0x22]
    4108:      	add	x2, x8, x9
    410c:      	blr	x10
    4110:      	cbnz	x0, 0x3fdc <kprobe_unwind_perl+0x3fdc>
    4114:      	ldr	x8, [sp, #0x98]
    4118:      	cbz	x8, 0x3fdc <kprobe_unwind_perl+0x3fdc>
    411c:      	ldr	w9, [x23]
    4120:      	cbnz	w9, 0x69e4 <kprobe_unwind_perl+0x69e4>
    4124:      	ldrb	w9, [x22, #0x1e]
    4128:      	mov	w10, #0x70              // =112
    412c:      	add	x11, sp, #0x94
    4130:      	add	x0, sp, #0x94
    4134:      	mov	w1, #0x4                // =4
    4138:      	add	x8, x8, x9
    413c:      	mov	w9, #0x4                // =4
    4140:      	ldr	x8, [sp, #0x98]
    4144:      	ldrb	w9, [x22, #0x1e]
    4148:      	add	x2, x8, x9
    414c:      	blr	x10
    4150:      	cbnz	x0, 0x3fdc <kprobe_unwind_perl+0x3fdc>
    4154:      	ldr	w8, [sp, #0x94]
    4158:      	mov	w9, #0x801f             // =32799
    415c:      	and	w8, w8, w9
    4160:      	mov	w9, #0x8009             // =32777
    4164:      	cmp	w8, w9
    4168:      	b.ne	0x537c <kprobe_unwind_perl+0x537c>
    416c:      	ldr	x8, [sp, #0x98]
    4170:      	ldrb	w9, [x22, #0x20]
    4174:      	mov	w10, #0x70              // =112
    4178:      	add	x11, sp, #0x88
    417c:      	add	x0, sp, #0x88
    4180:      	mov	w1, #0x8                // =8
    4184:      	add	x8, x8, x9
    4188:      	mov	w9, #0x8                // =8
    418c:      	ldr	x8, [sp, #0x98]
    4190:      	ldrb	w9, [x22, #0x20]
    4194:      	add	x2, x8, x9
    4198:      	blr	x10
    419c:      	cbnz	x0, 0x3fdc <kprobe_unwind_perl+0x3fdc>
    41a0:      	ldr	x8, [sp, #0x88]
    41a4:      	ldrb	w9, [x22, #0x23]
    41a8:      	mov	w10, #0x70              // =112
    41ac:      	add	x11, sp, #0x80
    41b0:      	add	x0, sp, #0x80
    41b4:      	mov	w1, #0x8                // =8
    41b8:      	add	x8, x8, x9
    41bc:      	mov	w9, #0x8                // =8
    41c0:      	ldr	x8, [sp, #0x88]
    41c4:      	ldrb	w9, [x22, #0x23]
    41c8:      	add	x2, x8, x9
    41cc:      	blr	x10
    41d0:      	cbnz	x0, 0x3fdc <kprobe_unwind_perl+0x3fdc>
    41d4:      	ldr	x24, [sp, #0x80]
    41d8:      	cbz	x24, 0x65d8 <kprobe_unwind_perl+0x65d8>
    41dc:      	ldr	w8, [x23]
    41e0:      	cbz	w8, 0x65e4 <kprobe_unwind_perl+0x65e4>
    41e4:      	mov	w8, #0x786c             // =30828
    41e8:      	add	x10, sp, #0x30
    41ec:      	add	x0, sp, #0x30
    41f0:      	mov	w1, #0x14               // =20
    41f4:      	movk	w8, #0xa, lsl #16
    41f8:      	str	w8, [sp, #0x40]
    41fc:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4200:      	add	x8, x8, #0x0
    4204:      	ldp	x9, x8, [x8]
    4208:      	stp	x9, x8, [sp, #0x30]
    420c:      	mov	w8, #0x14               // =20
    4210:      	mov	w9, #0x6                // =6
    4214:      	ldr	x2, [sp, #0x80]
    4218:      	blr	x9
    421c:      	add	x8, sp, #0x80
    4220:      	b	0x65dc <kprobe_unwind_perl+0x65dc>
    4224:      	ldr	w8, [x23]
    4228:      	cbz	w8, 0x3e5c <kprobe_unwind_perl+0x3e5c>
    422c:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4230:      	add	x8, x8, #0x0
    4234:      	add	x0, sp, #0x30
    4238:      	ldp	x9, x10, [x8, #0x10]
    423c:      	mov	w1, #0x2e               // =46
    4240:      	stp	x9, x10, [sp, #0x40]
    4244:      	ldr	x9, [x8, #0x20]
    4248:      	add	x10, sp, #0x30
    424c:      	str	x9, [sp, #0x50]
    4250:      	ldur	x9, [x8, #0x26]
    4254:      	stur	x9, [sp, #0x56]
    4258:      	ldp	x9, x8, [x8]
    425c:      	stp	x9, x8, [sp, #0x30]
    4260:      	mov	w8, #0x2e               // =46
    4264:      	mov	w9, #0x6                // =6
    4268:      	ldr	w2, [sp, #0xbc]
    426c:      	blr	x9
    4270:      	b	0x3e5c <kprobe_unwind_perl+0x3e5c>
    4274:      	ldr	w8, [x23]
    4278:      	cbz	w8, 0x3e5c <kprobe_unwind_perl+0x3e5c>
    427c:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4280:      	add	x8, x8, #0x0
    4284:      	add	x0, sp, #0x30
    4288:      	ldp	x9, x10, [x8]
    428c:      	mov	w1, #0x1e               // =30
    4290:      	stp	x9, x10, [sp, #0x30]
    4294:      	ldr	x9, [x8, #0x10]
    4298:      	ldur	x8, [x8, #0x16]
    429c:      	add	x10, sp, #0x30
    42a0:      	str	x9, [sp, #0x40]
    42a4:      	stur	x8, [sp, #0x46]
    42a8:      	mov	w8, #0x1e               // =30
    42ac:      	mov	w9, #0x6                // =6
    42b0:      	ldr	w2, [sp, #0xb8]
    42b4:      	blr	x9
    42b8:      	b	0x3e5c <kprobe_unwind_perl+0x3e5c>
    42bc:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    42c0:      	add	x8, x8, #0x0
    42c4:      	add	x0, sp, #0x30
    42c8:      	ldp	x9, x10, [x8, #0x10]
    42cc:      	mov	w1, #0x2e               // =46
    42d0:      	stp	x9, x10, [sp, #0x40]
    42d4:      	ldr	x9, [x8, #0x20]
    42d8:      	add	x10, sp, #0x30
    42dc:      	str	x9, [sp, #0x50]
    42e0:      	ldur	x9, [x8, #0x26]
    42e4:      	stur	x9, [sp, #0x56]
    42e8:      	ldp	x9, x8, [x8]
    42ec:      	stp	x9, x8, [sp, #0x30]
    42f0:      	mov	w8, #0x2e               // =46
    42f4:      	mov	w9, #0x6                // =6
    42f8:      	ldr	w2, [sp, #0xa8]
    42fc:      	blr	x9
    4300:      	ldp	x24, x9, [sp, #0x10]
    4304:      	cmp	w29, #0x3
    4308:      	b.eq	0x3e24 <kprobe_unwind_perl+0x3e24>
    430c:      	b	0x563c <kprobe_unwind_perl+0x563c>
    4310:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4314:      	add	x8, x8, #0x0
    4318:      	add	x0, sp, #0x30
    431c:      	ldp	x9, x10, [x8, #0x10]
    4320:      	mov	w1, #0x2d               // =45
    4324:      	stp	x9, x10, [sp, #0x40]
    4328:      	ldr	x9, [x8, #0x20]
    432c:      	add	x10, sp, #0x30
    4330:      	str	x9, [sp, #0x50]
    4334:      	ldur	x9, [x8, #0x25]
    4338:      	stur	x9, [sp, #0x55]
    433c:      	ldp	x9, x8, [x8]
    4340:      	stp	x9, x8, [sp, #0x30]
    4344:      	mov	w8, #0x2d               // =45
    4348:      	mov	w9, #0x6                // =6
    434c:      	blr	x9
    4350:      	b	0x2978 <kprobe_unwind_perl+0x2978>
    4354:      	mov	w8, #0xa                // =10
    4358:      	add	x0, sp, #0x30
    435c:      	mov	w1, #0x2a               // =42
    4360:      	strh	w8, [sp, #0x58]
    4364:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4368:      	add	x8, x8, #0x0
    436c:      	mov	x2, x25
    4370:      	ldp	x9, x10, [x8, #0x10]
    4374:      	stp	x9, x10, [sp, #0x40]
    4378:      	ldr	x9, [x8, #0x20]
    437c:      	add	x10, sp, #0x30
    4380:      	str	x9, [sp, #0x50]
    4384:      	ldp	x8, x9, [x8]
    4388:      	stp	x8, x9, [sp, #0x30]
    438c:      	mov	w8, #0x2a               // =42
    4390:      	mov	w9, #0x6                // =6
    4394:      	blr	x9
    4398:      	b	0x3e64 <kprobe_unwind_perl+0x3e64>
    439c:      	ldr	w8, [x23]
    43a0:      	cbz	w8, 0x2f04 <kprobe_unwind_perl+0x2f04>
    43a4:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    43a8:      	add	x8, x8, #0x0
    43ac:      	add	x0, sp, #0x30
    43b0:      	ldp	x9, x10, [x8, #0x10]
    43b4:      	mov	w1, #0x26               // =38
    43b8:      	stp	x9, x10, [sp, #0x40]
    43bc:      	ldur	x9, [x8, #0x1e]
    43c0:      	add	x10, sp, #0x30
    43c4:      	stur	x9, [sp, #0x4e]
    43c8:      	ldp	x8, x9, [x8]
    43cc:      	stp	x8, x9, [sp, #0x30]
    43d0:      	mov	w8, #0x26               // =38
    43d4:      	mov	w9, #0x6                // =6
    43d8:      	ldr	w2, [sp, #0x94]
    43dc:      	blr	x9
    43e0:      	b	0x2f04 <kprobe_unwind_perl+0x2f04>
    43e4:      	add	x8, sp, #0x98
    43e8:      	ldr	x8, [x8]
    43ec:      	ldr	x24, [sp, #0x10]
    43f0:      	str	x8, [sp, #0x8]
    43f4:      	cbz	x8, 0x2100 <kprobe_unwind_perl+0x2100>
    43f8:      	ldr	x24, [x24]
    43fc:      	ldr	w8, [x23]
    4400:      	cbnz	w8, 0x6758 <kprobe_unwind_perl+0x6758>
    4404:      	ldr	w8, [x21, #0x2c0]
    4408:      	cmp	w8, #0x7e
    440c:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    4410:      	add	w9, w8, #0x1
    4414:      	mov	w10, #0x7               // =7
    4418:      	str	w9, [x21, #0x2c0]
    441c:      	mov	w9, #0x18               // =24
    4420:      	umaddl	x8, w8, w9, x21
    4424:      	str	x24, [x8, #0x2d8]
    4428:      	ldp	x9, x24, [sp, #0x8]
    442c:      	strb	w10, [x8, #0x2e0]
    4430:      	str	wzr, [x8, #0x2e4]
    4434:      	str	x9, [x8, #0x2d0]
    4438:      	add	x9, x8, #0x2d0
    443c:      	str	xzr, [x21, #0xf30]
    4440:      	stur	wzr, [x9, #0x11]
    4444:      	b	0x2844 <kprobe_unwind_perl+0x2844>
    4448:      	mov	w8, #0x786c             // =30828
    444c:      	add	x10, sp, #0x30
    4450:      	add	x0, sp, #0x30
    4454:      	mov	w1, #0x13               // =19
    4458:      	movk	w8, #0xa, lsl #16
    445c:      	stur	w8, [sp, #0x3f]
    4460:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4464:      	add	x8, x8, #0x0
    4468:      	ldp	x9, x8, [x8]
    446c:      	stp	x9, x8, [sp, #0x30]
    4470:      	mov	w8, #0x13               // =19
    4474:      	mov	w9, #0x6                // =6
    4478:      	ldr	x2, [sp, #0x98]
    447c:      	blr	x9
    4480:      	ldr	x8, [sp, #0x98]
    4484:      	b	0x15e4 <kprobe_unwind_perl+0x15e4>
    4488:      	ldr	w8, [x23]
    448c:      	cbz	w8, 0x3e5c <kprobe_unwind_perl+0x3e5c>
    4490:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4494:      	add	x8, x8, #0x0
    4498:      	add	x0, sp, #0x30
    449c:      	ldp	x9, x10, [x8, #0x10]
    44a0:      	mov	w1, #0x26               // =38
    44a4:      	stp	x9, x10, [sp, #0x40]
    44a8:      	ldur	x9, [x8, #0x1e]
    44ac:      	add	x10, sp, #0x30
    44b0:      	stur	x9, [sp, #0x4e]
    44b4:      	ldp	x8, x9, [x8]
    44b8:      	stp	x8, x9, [sp, #0x30]
    44bc:      	mov	w8, #0x26               // =38
    44c0:      	mov	w9, #0x6                // =6
    44c4:      	ldr	w2, [sp, #0xb8]
    44c8:      	ldr	w3, [sp, #0xa4]
    44cc:      	blr	x9
    44d0:      	b	0x3e5c <kprobe_unwind_perl+0x3e5c>
    44d4:      	mov	w8, #0xa                // =10
    44d8:      	add	x10, sp, #0x30
    44dc:      	add	x0, sp, #0x30
    44e0:      	strh	w8, [sp, #0x40]
    44e4:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    44e8:      	add	x8, x8, #0x0
    44ec:      	mov	w1, #0x12               // =18
    44f0:      	ldp	x9, x8, [x8]
    44f4:      	stp	x9, x8, [sp, #0x30]
    44f8:      	mov	w8, #0x12               // =18
    44fc:      	mov	w9, #0x6                // =6
    4500:      	ldrb	w2, [sp, #0x7c]
    4504:      	blr	x9
    4508:      	ldrb	w8, [sp, #0x7c]
    450c:      	and	w9, w8, #0xf
    4510:      	sub	w10, w9, #0x9
    4514:      	cmp	w10, #0x2
    4518:      	b.lo	0x3f3c <kprobe_unwind_perl+0x3f3c>
    451c:      	cmp	w9, #0xc
    4520:      	b.ne	0x4604 <kprobe_unwind_perl+0x4604>
    4524:      	mov	w29, #0x3               // =3
    4528:      	ldrb	w8, [x22, #0x1d]
    452c:      	ldr	x9, [x21, #0xf40]
    4530:      	adrp	x0, 0x4000 <kprobe_unwind_perl+0x4000>
    4534:      	add	x1, sp, #0xa8
    4538:      	sub	x8, x9, x8
    453c:      	add	x9, sp, #0xa8
    4540:      	str	x8, [x21, #0xf40]
    4544:      	mov	w8, #0x10               // =16
    4548:      	str	w8, [sp, #0xa8]
    454c:      	mov	w8, #0x1                // =1
    4550:      	ldr	x0, [x0]
    4554:      	blr	x8
    4558:      	cbz	x0, 0x4578 <kprobe_unwind_perl+0x4578>
    455c:      	ldr	x8, [x0]
    4560:      	add	x8, x8, #0x1
    4564:      	str	x8, [x0]
    4568:      	ldp	x24, x9, [sp, #0x10]
    456c:      	cmp	w29, #0x3
    4570:      	b.eq	0x458c <kprobe_unwind_perl+0x458c>
    4574:      	b	0x563c <kprobe_unwind_perl+0x563c>
    4578:      	ldr	w8, [x23]
    457c:      	cbnz	w8, 0x4a24 <kprobe_unwind_perl+0x4a24>
    4580:      	ldp	x24, x9, [sp, #0x10]
    4584:      	cmp	w29, #0x3
    4588:      	b.ne	0x563c <kprobe_unwind_perl+0x563c>
    458c:      	ldr	x25, [x21, #0xf40]
    4590:      	cmp	x25, x9
    4594:      	b.lo	0x2ecc <kprobe_unwind_perl+0x2ecc>
    4598:      	ldrb	w8, [x22, #0x19]
    459c:      	mov	w9, #0x1                // =1
    45a0:      	mov	w10, #0x70              // =112
    45a4:      	add	x11, sp, #0x7c
    45a8:      	add	x0, sp, #0x7c
    45ac:      	mov	w1, #0x1                // =1
    45b0:      	add	x8, x25, x8
    45b4:      	ldrb	w8, [x22, #0x19]
    45b8:      	add	x2, x25, x8
    45bc:      	blr	x10
    45c0:      	cbz	x0, 0x4688 <kprobe_unwind_perl+0x4688>
    45c4:      	ldr	w8, [x23]
    45c8:      	cbnz	w8, 0x4abc <kprobe_unwind_perl+0x4abc>
    45cc:      	mov	w8, #0x13               // =19
    45d0:      	adrp	x0, 0x4000 <kprobe_unwind_perl+0x4000>
    45d4:      	add	x9, sp, #0xa8
    45d8:      	str	w8, [sp, #0xa8]
    45dc:      	mov	w8, #0x1                // =1
    45e0:      	add	x1, sp, #0xa8
    45e4:      	ldr	x0, [x0]
    45e8:      	blr	x8
    45ec:      	cbz	x0, 0x4780 <kprobe_unwind_perl+0x4780>
    45f0:      	ldr	x8, [x0]
    45f4:      	mov	w29, #0x3               // =3
    45f8:      	add	x8, x8, #0x1
    45fc:      	str	x8, [x0]
    4600:      	b	0x4da0 <kprobe_unwind_perl+0x4da0>
    4604:      	ldr	x8, [sp, #0x10]
    4608:      	mov	w29, #0x3               // =3
    460c:      	ldr	x8, [x8]
    4610:      	cbnz	x8, 0x4528 <kprobe_unwind_perl+0x4528>
    4614:      	ldrb	w8, [x22, #0x1a]
    4618:      	mov	w9, #0x8                // =8
    461c:      	mov	w10, #0x70              // =112
    4620:      	ldr	x0, [sp, #0x10]
    4624:      	mov	w1, #0x8                // =8
    4628:      	add	x8, x25, x8
    462c:      	ldrb	w8, [x22, #0x1a]
    4630:      	add	x2, x25, x8
    4634:      	blr	x10
    4638:      	cbnz	x0, 0x3e5c <kprobe_unwind_perl+0x3e5c>
    463c:      	ldr	w8, [x23]
    4640:      	cbz	w8, 0x4528 <kprobe_unwind_perl+0x4528>
    4644:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4648:      	add	x8, x8, #0x0
    464c:      	add	x0, sp, #0x30
    4650:      	ldp	x9, x10, [x8]
    4654:      	mov	w1, #0x1e               // =30
    4658:      	stp	x9, x10, [sp, #0x30]
    465c:      	ldr	x9, [x8, #0x10]
    4660:      	ldur	x8, [x8, #0x16]
    4664:      	add	x10, sp, #0x30
    4668:      	str	x9, [sp, #0x40]
    466c:      	stur	x8, [sp, #0x46]
    4670:      	mov	w8, #0x1e               // =30
    4674:      	mov	w9, #0x6                // =6
    4678:      	ldr	x8, [sp, #0x10]
    467c:      	ldr	x2, [x8]
    4680:      	blr	x9
    4684:      	b	0x4528 <kprobe_unwind_perl+0x4528>
    4688:      	ldr	w8, [x23]
    468c:      	cbnz	w8, 0x4d4c <kprobe_unwind_perl+0x4d4c>
    4690:      	ldrb	w8, [sp, #0x7c]
    4694:      	and	w9, w8, #0xf
    4698:      	sub	w10, w9, #0x9
    469c:      	cmp	w10, #0x2
    46a0:      	b.hs	0x4d94 <kprobe_unwind_perl+0x4d94>
    46a4:      	sxtb	w8, w8
    46a8:      	tbnz	w8, #0x1f, 0x4d9c <kprobe_unwind_perl+0x4d9c>
    46ac:      	ldrb	w8, [x22, #0x1b]
    46b0:      	mov	w9, #0x8                // =8
    46b4:      	mov	w10, #0x70              // =112
    46b8:      	add	x11, sp, #0x30
    46bc:      	add	x0, sp, #0x30
    46c0:      	mov	w1, #0x8                // =8
    46c4:      	add	x8, x25, x8
    46c8:      	ldrb	w8, [x22, #0x1b]
    46cc:      	add	x2, x25, x8
    46d0:      	blr	x10
    46d4:      	cbnz	x0, 0x45c4 <kprobe_unwind_perl+0x45c4>
    46d8:      	ldr	x8, [sp, #0x30]
    46dc:      	mov	w9, #0x8                // =8
    46e0:      	mov	w10, #0x70              // =112
    46e4:      	add	x11, sp, #0x70
    46e8:      	add	x0, sp, #0x70
    46ec:      	mov	w1, #0x8                // =8
    46f0:      	cmp	x8, #0x0
    46f4:      	mov	w8, #0x3                // =3
    46f8:      	csinc	w29, w8, wzr, ne
    46fc:      	ldrb	w8, [x22, #0x1c]
    4700:      	add	x8, x25, x8
    4704:      	ldrb	w8, [x22, #0x1c]
    4708:      	add	x2, x25, x8
    470c:      	blr	x10
    4710:      	cbnz	x0, 0x45c4 <kprobe_unwind_perl+0x45c4>
    4714:      	ldr	x24, [sp, #0x70]
    4718:      	ldrb	w8, [x22, #0x1e]
    471c:      	mov	w9, #0x4                // =4
    4720:      	mov	w10, #0x70              // =112
    4724:      	add	x11, sp, #0xb8
    4728:      	add	x0, sp, #0xb8
    472c:      	mov	w1, #0x4                // =4
    4730:      	add	x8, x24, x8
    4734:      	ldrb	w8, [x22, #0x1e]
    4738:      	add	x2, x24, x8
    473c:      	blr	x10
    4740:      	cbz	x0, 0x47d0 <kprobe_unwind_perl+0x47d0>
    4744:      	ldr	w8, [x23]
    4748:      	cbnz	w8, 0x64fc <kprobe_unwind_perl+0x64fc>
    474c:      	mov	w8, #0x14               // =20
    4750:      	adrp	x0, 0x4000 <kprobe_unwind_perl+0x4000>
    4754:      	add	x9, sp, #0xbc
    4758:      	str	w8, [sp, #0xbc]
    475c:      	mov	w8, #0x1                // =1
    4760:      	add	x1, sp, #0xbc
    4764:      	ldr	x0, [x0]
    4768:      	blr	x8
    476c:      	cbz	x0, 0x498c <kprobe_unwind_perl+0x498c>
    4770:      	ldr	x8, [x0]
    4774:      	add	x8, x8, #0x1
    4778:      	str	x8, [x0]
    477c:      	b	0x45c4 <kprobe_unwind_perl+0x45c4>
    4780:      	ldr	w8, [x23]
    4784:      	cbz	w8, 0x4d9c <kprobe_unwind_perl+0x4d9c>
    4788:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    478c:      	add	x8, x8, #0x0
    4790:      	add	x0, sp, #0x30
    4794:      	ldp	x9, x10, [x8, #0x10]
    4798:      	mov	w1, #0x2e               // =46
    479c:      	stp	x9, x10, [sp, #0x40]
    47a0:      	ldr	x9, [x8, #0x20]
    47a4:      	add	x10, sp, #0x30
    47a8:      	str	x9, [sp, #0x50]
    47ac:      	ldur	x9, [x8, #0x26]
    47b0:      	stur	x9, [sp, #0x56]
    47b4:      	ldp	x9, x8, [x8]
    47b8:      	stp	x9, x8, [sp, #0x30]
    47bc:      	mov	w8, #0x2e               // =46
    47c0:      	mov	w9, #0x6                // =6
    47c4:      	ldr	w2, [sp, #0xa8]
    47c8:      	blr	x9
    47cc:      	b	0x4d9c <kprobe_unwind_perl+0x4d9c>
    47d0:      	ldr	w8, [sp, #0xb8]
    47d4:      	and	w8, w8, #0x1f
    47d8:      	cmp	w8, #0xd
    47dc:      	b.ne	0x49dc <kprobe_unwind_perl+0x49dc>
    47e0:      	ldrb	w8, [x22, #0x1f]
    47e4:      	mov	w9, #0x8                // =8
    47e8:      	mov	w10, #0x70              // =112
    47ec:      	add	x11, sp, #0xa8
    47f0:      	add	x0, sp, #0xa8
    47f4:      	mov	w1, #0x8                // =8
    47f8:      	add	x8, x24, x8
    47fc:      	ldrb	w8, [x22, #0x1f]
    4800:      	add	x2, x24, x8
    4804:      	blr	x10
    4808:      	cbnz	x0, 0x4744 <kprobe_unwind_perl+0x4744>
    480c:      	ldr	x8, [sp, #0xa8]
    4810:      	ldrb	w9, [x22, #0x21]
    4814:      	mov	w10, #0x70              // =112
    4818:      	add	x11, sp, #0xa4
    481c:      	add	x0, sp, #0xa4
    4820:      	mov	w1, #0x4                // =4
    4824:      	add	x8, x8, x9
    4828:      	mov	w9, #0x4                // =4
    482c:      	ldr	x8, [sp, #0xa8]
    4830:      	ldrb	w9, [x22, #0x21]
    4834:      	add	x2, x8, x9
    4838:      	blr	x10
    483c:      	cbnz	x0, 0x4744 <kprobe_unwind_perl+0x4744>
    4840:      	ldrb	w8, [sp, #0xa5]
    4844:      	tbnz	w8, #0x7, 0x4cc4 <kprobe_unwind_perl+0x4cc4>
    4848:      	ldr	x8, [sp, #0xa8]
    484c:      	ldrb	w9, [x22, #0x22]
    4850:      	mov	w10, #0x70              // =112
    4854:      	add	x11, sp, #0x98
    4858:      	add	x0, sp, #0x98
    485c:      	mov	w1, #0x8                // =8
    4860:      	add	x8, x8, x9
    4864:      	mov	w9, #0x8                // =8
    4868:      	ldr	x8, [sp, #0xa8]
    486c:      	ldrb	w9, [x22, #0x22]
    4870:      	add	x2, x8, x9
    4874:      	blr	x10
    4878:      	cbnz	x0, 0x4744 <kprobe_unwind_perl+0x4744>
    487c:      	ldr	x8, [sp, #0x98]
    4880:      	cbz	x8, 0x4744 <kprobe_unwind_perl+0x4744>
    4884:      	ldr	w9, [x23]
    4888:      	cbnz	w9, 0x6ad8 <kprobe_unwind_perl+0x6ad8>
    488c:      	ldrb	w9, [x22, #0x1e]
    4890:      	mov	w10, #0x70              // =112
    4894:      	add	x11, sp, #0x94
    4898:      	add	x0, sp, #0x94
    489c:      	mov	w1, #0x4                // =4
    48a0:      	add	x8, x8, x9
    48a4:      	mov	w9, #0x4                // =4
    48a8:      	ldr	x8, [sp, #0x98]
    48ac:      	ldrb	w9, [x22, #0x1e]
    48b0:      	add	x2, x8, x9
    48b4:      	blr	x10
    48b8:      	cbnz	x0, 0x4744 <kprobe_unwind_perl+0x4744>
    48bc:      	ldr	w8, [sp, #0x94]
    48c0:      	mov	w9, #0x801f             // =32799
    48c4:      	and	w8, w8, w9
    48c8:      	mov	w9, #0x8009             // =32777
    48cc:      	cmp	w8, w9
    48d0:      	b.ne	0x61b8 <kprobe_unwind_perl+0x61b8>
    48d4:      	ldr	x8, [sp, #0x98]
    48d8:      	ldrb	w9, [x22, #0x20]
    48dc:      	mov	w10, #0x70              // =112
    48e0:      	add	x11, sp, #0x88
    48e4:      	add	x0, sp, #0x88
    48e8:      	mov	w1, #0x8                // =8
    48ec:      	add	x8, x8, x9
    48f0:      	mov	w9, #0x8                // =8
    48f4:      	ldr	x8, [sp, #0x98]
    48f8:      	ldrb	w9, [x22, #0x20]
    48fc:      	add	x2, x8, x9
    4900:      	blr	x10
    4904:      	cbnz	x0, 0x4744 <kprobe_unwind_perl+0x4744>
    4908:      	ldr	x8, [sp, #0x88]
    490c:      	ldrb	w9, [x22, #0x23]
    4910:      	mov	w10, #0x70              // =112
    4914:      	add	x11, sp, #0x80
    4918:      	add	x0, sp, #0x80
    491c:      	mov	w1, #0x8                // =8
    4920:      	add	x8, x8, x9
    4924:      	mov	w9, #0x8                // =8
    4928:      	ldr	x8, [sp, #0x88]
    492c:      	ldrb	w9, [x22, #0x23]
    4930:      	add	x2, x8, x9
    4934:      	blr	x10
    4938:      	cbnz	x0, 0x4744 <kprobe_unwind_perl+0x4744>
    493c:      	ldr	x24, [sp, #0x80]
    4940:      	cbz	x24, 0x67a8 <kprobe_unwind_perl+0x67a8>
    4944:      	ldr	w8, [x23]
    4948:      	cbz	w8, 0x67b4 <kprobe_unwind_perl+0x67b4>
    494c:      	mov	w8, #0x786c             // =30828
    4950:      	add	x10, sp, #0x30
    4954:      	add	x0, sp, #0x30
    4958:      	mov	w1, #0x14               // =20
    495c:      	movk	w8, #0xa, lsl #16
    4960:      	str	w8, [sp, #0x40]
    4964:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4968:      	add	x8, x8, #0x0
    496c:      	ldp	x9, x8, [x8]
    4970:      	stp	x9, x8, [sp, #0x30]
    4974:      	mov	w8, #0x14               // =20
    4978:      	mov	w9, #0x6                // =6
    497c:      	ldr	x2, [sp, #0x80]
    4980:      	blr	x9
    4984:      	add	x8, sp, #0x80
    4988:      	b	0x67ac <kprobe_unwind_perl+0x67ac>
    498c:      	ldr	w8, [x23]
    4990:      	cbz	w8, 0x45c4 <kprobe_unwind_perl+0x45c4>
    4994:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4998:      	add	x8, x8, #0x0
    499c:      	add	x0, sp, #0x30
    49a0:      	ldp	x9, x10, [x8, #0x10]
    49a4:      	mov	w1, #0x2e               // =46
    49a8:      	stp	x9, x10, [sp, #0x40]
    49ac:      	ldr	x9, [x8, #0x20]
    49b0:      	add	x10, sp, #0x30
    49b4:      	str	x9, [sp, #0x50]
    49b8:      	ldur	x9, [x8, #0x26]
    49bc:      	stur	x9, [sp, #0x56]
    49c0:      	ldp	x9, x8, [x8]
    49c4:      	stp	x9, x8, [sp, #0x30]
    49c8:      	mov	w8, #0x2e               // =46
    49cc:      	mov	w9, #0x6                // =6
    49d0:      	ldr	w2, [sp, #0xbc]
    49d4:      	blr	x9
    49d8:      	b	0x45c4 <kprobe_unwind_perl+0x45c4>
    49dc:      	ldr	w8, [x23]
    49e0:      	cbz	w8, 0x45c4 <kprobe_unwind_perl+0x45c4>
    49e4:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    49e8:      	add	x8, x8, #0x0
    49ec:      	add	x0, sp, #0x30
    49f0:      	ldp	x9, x10, [x8]
    49f4:      	mov	w1, #0x1e               // =30
    49f8:      	stp	x9, x10, [sp, #0x30]
    49fc:      	ldr	x9, [x8, #0x10]
    4a00:      	ldur	x8, [x8, #0x16]
    4a04:      	add	x10, sp, #0x30
    4a08:      	str	x9, [sp, #0x40]
    4a0c:      	stur	x8, [sp, #0x46]
    4a10:      	mov	w8, #0x1e               // =30
    4a14:      	mov	w9, #0x6                // =6
    4a18:      	ldr	w2, [sp, #0xb8]
    4a1c:      	blr	x9
    4a20:      	b	0x45c4 <kprobe_unwind_perl+0x45c4>
    4a24:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4a28:      	add	x8, x8, #0x0
    4a2c:      	add	x0, sp, #0x30
    4a30:      	ldp	x9, x10, [x8, #0x10]
    4a34:      	mov	w1, #0x2e               // =46
    4a38:      	stp	x9, x10, [sp, #0x40]
    4a3c:      	ldr	x9, [x8, #0x20]
    4a40:      	add	x10, sp, #0x30
    4a44:      	str	x9, [sp, #0x50]
    4a48:      	ldur	x9, [x8, #0x26]
    4a4c:      	stur	x9, [sp, #0x56]
    4a50:      	ldp	x9, x8, [x8]
    4a54:      	stp	x9, x8, [sp, #0x30]
    4a58:      	mov	w8, #0x2e               // =46
    4a5c:      	mov	w9, #0x6                // =6
    4a60:      	ldr	w2, [sp, #0xa8]
    4a64:      	blr	x9
    4a68:      	ldp	x24, x9, [sp, #0x10]
    4a6c:      	cmp	w29, #0x3
    4a70:      	b.eq	0x458c <kprobe_unwind_perl+0x458c>
    4a74:      	b	0x563c <kprobe_unwind_perl+0x563c>
    4a78:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4a7c:      	add	x8, x8, #0x0
    4a80:      	add	x0, sp, #0x30
    4a84:      	ldp	x9, x10, [x8, #0x10]
    4a88:      	mov	w1, #0x2d               // =45
    4a8c:      	stp	x9, x10, [sp, #0x40]
    4a90:      	ldr	x9, [x8, #0x20]
    4a94:      	add	x10, sp, #0x30
    4a98:      	str	x9, [sp, #0x50]
    4a9c:      	ldur	x9, [x8, #0x25]
    4aa0:      	stur	x9, [sp, #0x55]
    4aa4:      	ldp	x9, x8, [x8]
    4aa8:      	stp	x9, x8, [sp, #0x30]
    4aac:      	mov	w8, #0x2d               // =45
    4ab0:      	mov	w9, #0x6                // =6
    4ab4:      	blr	x9
    4ab8:      	b	0x3090 <kprobe_unwind_perl+0x3090>
    4abc:      	mov	w8, #0xa                // =10
    4ac0:      	add	x0, sp, #0x30
    4ac4:      	mov	w1, #0x2a               // =42
    4ac8:      	strh	w8, [sp, #0x58]
    4acc:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4ad0:      	add	x8, x8, #0x0
    4ad4:      	mov	x2, x25
    4ad8:      	ldp	x9, x10, [x8, #0x10]
    4adc:      	stp	x9, x10, [sp, #0x40]
    4ae0:      	ldr	x9, [x8, #0x20]
    4ae4:      	add	x10, sp, #0x30
    4ae8:      	str	x9, [sp, #0x50]
    4aec:      	ldp	x8, x9, [x8]
    4af0:      	stp	x8, x9, [sp, #0x30]
    4af4:      	mov	w8, #0x2a               // =42
    4af8:      	mov	w9, #0x6                // =6
    4afc:      	blr	x9
    4b00:      	b	0x45cc <kprobe_unwind_perl+0x45cc>
    4b04:      	ldr	w8, [x23]
    4b08:      	cbz	w8, 0x36b4 <kprobe_unwind_perl+0x36b4>
    4b0c:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4b10:      	add	x8, x8, #0x0
    4b14:      	add	x0, sp, #0x30
    4b18:      	ldp	x9, x10, [x8, #0x10]
    4b1c:      	mov	w1, #0x26               // =38
    4b20:      	stp	x9, x10, [sp, #0x40]
    4b24:      	ldur	x9, [x8, #0x1e]
    4b28:      	add	x10, sp, #0x30
    4b2c:      	stur	x9, [sp, #0x4e]
    4b30:      	ldp	x8, x9, [x8]
    4b34:      	stp	x8, x9, [sp, #0x30]
    4b38:      	mov	w8, #0x26               // =38
    4b3c:      	mov	w9, #0x6                // =6
    4b40:      	ldr	w2, [sp, #0x94]
    4b44:      	blr	x9
    4b48:      	b	0x36b4 <kprobe_unwind_perl+0x36b4>
    4b4c:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4b50:      	add	x8, x8, #0x0
    4b54:      	add	x0, sp, #0x30
    4b58:      	ldp	x9, x10, [x8, #0x10]
    4b5c:      	mov	w1, #0x28               // =40
    4b60:      	mov	x3, x24
    4b64:      	stp	x9, x10, [sp, #0x40]
    4b68:      	ldr	x9, [x8, #0x20]
    4b6c:      	add	x10, sp, #0x30
    4b70:      	str	x9, [sp, #0x50]
    4b74:      	ldp	x8, x9, [x8]
    4b78:      	stp	x8, x9, [sp, #0x30]
    4b7c:      	mov	w8, #0x28               // =40
    4b80:      	mov	w9, #0x6                // =6
    4b84:      	ldr	x2, [sp, #0x8]
    4b88:      	blr	x9
    4b8c:      	ldr	w8, [x21, #0x2c0]
    4b90:      	cmp	w8, #0x7f
    4b94:      	b.hs	0x2680 <kprobe_unwind_perl+0x2680>
    4b98:      	add	w9, w8, #0x1
    4b9c:      	mov	w10, #0x7               // =7
    4ba0:      	str	w9, [x21, #0x2c0]
    4ba4:      	mov	w9, #0x18               // =24
    4ba8:      	umaddl	x8, w8, w9, x21
    4bac:      	str	x24, [x8, #0x2d8]
    4bb0:      	ldp	x9, x24, [sp, #0x8]
    4bb4:      	strb	w10, [x8, #0x2e0]
    4bb8:      	str	wzr, [x8, #0x2e4]
    4bbc:      	str	x9, [x8, #0x2d0]
    4bc0:      	add	x9, x8, #0x2d0
    4bc4:      	str	xzr, [x21, #0xf30]
    4bc8:      	stur	wzr, [x9, #0x11]
    4bcc:      	b	0xd24 <kprobe_unwind_perl+0xd24>
    4bd0:      	add	x8, sp, #0x98
    4bd4:      	ldr	x8, [x8]
    4bd8:      	ldr	x24, [sp, #0x10]
    4bdc:      	str	x8, [sp, #0x8]
    4be0:      	cbz	x8, 0x27f8 <kprobe_unwind_perl+0x27f8>
    4be4:      	ldr	x24, [x24]
    4be8:      	ldr	w8, [x23]
    4bec:      	cbnz	w8, 0x68e0 <kprobe_unwind_perl+0x68e0>
    4bf0:      	ldr	w8, [x21, #0x2c0]
    4bf4:      	cmp	w8, #0x7e
    4bf8:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    4bfc:      	add	w9, w8, #0x1
    4c00:      	mov	w10, #0x7               // =7
    4c04:      	str	w9, [x21, #0x2c0]
    4c08:      	mov	w9, #0x18               // =24
    4c0c:      	umaddl	x8, w8, w9, x21
    4c10:      	ldr	x9, [sp, #0x8]
    4c14:      	str	x24, [x8, #0x2d8]
    4c18:      	strb	w10, [x8, #0x2e0]
    4c1c:      	str	wzr, [x8, #0x2e4]
    4c20:      	str	x9, [x8, #0x2d0]
    4c24:      	add	x9, x8, #0x2d0
    4c28:      	str	xzr, [x21, #0xf30]
    4c2c:      	stur	wzr, [x9, #0x11]
    4c30:      	b	0x2f54 <kprobe_unwind_perl+0x2f54>
    4c34:      	mov	w8, #0x786c             // =30828
    4c38:      	add	x10, sp, #0x30
    4c3c:      	add	x0, sp, #0x30
    4c40:      	mov	w1, #0x14               // =20
    4c44:      	movk	w8, #0xa, lsl #16
    4c48:      	str	w8, [sp, #0x40]
    4c4c:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4c50:      	add	x8, x8, #0x0
    4c54:      	ldp	x9, x8, [x8]
    4c58:      	stp	x9, x8, [sp, #0x30]
    4c5c:      	mov	w8, #0x14               // =20
    4c60:      	mov	w9, #0x6                // =6
    4c64:      	ldr	x2, [sp, #0x80]
    4c68:      	blr	x9
    4c6c:      	add	x8, sp, #0x80
    4c70:      	ldr	x8, [x8]
    4c74:      	ldr	x24, [sp, #0x10]
    4c78:      	str	x8, [sp, #0x8]
    4c7c:      	cbnz	x8, 0x2668 <kprobe_unwind_perl+0x2668>
    4c80:      	b	0xf0 <kprobe_unwind_perl+0xf0>
    4c84:      	mov	w8, #0x786c             // =30828
    4c88:      	add	x10, sp, #0x30
    4c8c:      	add	x0, sp, #0x30
    4c90:      	mov	w1, #0x13               // =19
    4c94:      	movk	w8, #0xa, lsl #16
    4c98:      	stur	w8, [sp, #0x3f]
    4c9c:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4ca0:      	add	x8, x8, #0x0
    4ca4:      	ldp	x9, x8, [x8]
    4ca8:      	stp	x9, x8, [sp, #0x30]
    4cac:      	mov	w8, #0x13               // =19
    4cb0:      	mov	w9, #0x6                // =6
    4cb4:      	ldr	x2, [sp, #0x98]
    4cb8:      	blr	x9
    4cbc:      	ldr	x8, [sp, #0x98]
    4cc0:      	b	0x1d3c <kprobe_unwind_perl+0x1d3c>
    4cc4:      	ldr	w8, [x23]
    4cc8:      	cbz	w8, 0x45c4 <kprobe_unwind_perl+0x45c4>
    4ccc:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4cd0:      	add	x8, x8, #0x0
    4cd4:      	add	x0, sp, #0x30
    4cd8:      	ldp	x9, x10, [x8, #0x10]
    4cdc:      	mov	w1, #0x26               // =38
    4ce0:      	stp	x9, x10, [sp, #0x40]
    4ce4:      	ldur	x9, [x8, #0x1e]
    4ce8:      	add	x10, sp, #0x30
    4cec:      	stur	x9, [sp, #0x4e]
    4cf0:      	ldp	x8, x9, [x8]
    4cf4:      	stp	x8, x9, [sp, #0x30]
    4cf8:      	mov	w8, #0x26               // =38
    4cfc:      	mov	w9, #0x6                // =6
    4d00:      	ldr	w2, [sp, #0xb8]
    4d04:      	ldr	w3, [sp, #0xa4]
    4d08:      	blr	x9
    4d0c:      	b	0x45c4 <kprobe_unwind_perl+0x45c4>
    4d10:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4d14:      	add	x8, x8, #0x0
    4d18:      	add	x0, sp, #0x30
    4d1c:      	ldp	x9, x10, [x8, #0x10]
    4d20:      	mov	w1, #0x25               // =37
    4d24:      	stp	x9, x10, [sp, #0x40]
    4d28:      	ldur	x9, [x8, #0x1d]
    4d2c:      	add	x10, sp, #0x30
    4d30:      	stur	x9, [sp, #0x4d]
    4d34:      	ldp	x8, x9, [x8]
    4d38:      	stp	x8, x9, [sp, #0x30]
    4d3c:      	mov	w8, #0x25               // =37
    4d40:      	mov	w9, #0x6                // =6
    4d44:      	blr	x9
    4d48:      	b	0x2688 <kprobe_unwind_perl+0x2688>
    4d4c:      	mov	w8, #0xa                // =10
    4d50:      	add	x10, sp, #0x30
    4d54:      	add	x0, sp, #0x30
    4d58:      	strh	w8, [sp, #0x40]
    4d5c:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4d60:      	add	x8, x8, #0x0
    4d64:      	mov	w1, #0x12               // =18
    4d68:      	ldp	x9, x8, [x8]
    4d6c:      	stp	x9, x8, [sp, #0x30]
    4d70:      	mov	w8, #0x12               // =18
    4d74:      	mov	w9, #0x6                // =6
    4d78:      	ldrb	w2, [sp, #0x7c]
    4d7c:      	blr	x9
    4d80:      	ldrb	w8, [sp, #0x7c]
    4d84:      	and	w9, w8, #0xf
    4d88:      	sub	w10, w9, #0x9
    4d8c:      	cmp	w10, #0x2
    4d90:      	b.lo	0x46a4 <kprobe_unwind_perl+0x46a4>
    4d94:      	cmp	w9, #0xc
    4d98:      	b.ne	0x4e7c <kprobe_unwind_perl+0x4e7c>
    4d9c:      	mov	w29, #0x3               // =3
    4da0:      	ldrb	w8, [x22, #0x1d]
    4da4:      	ldr	x9, [x21, #0xf40]
    4da8:      	adrp	x0, 0x4000 <kprobe_unwind_perl+0x4000>
    4dac:      	add	x1, sp, #0xa8
    4db0:      	sub	x8, x9, x8
    4db4:      	add	x9, sp, #0xa8
    4db8:      	str	x8, [x21, #0xf40]
    4dbc:      	mov	w8, #0x10               // =16
    4dc0:      	str	w8, [sp, #0xa8]
    4dc4:      	mov	w8, #0x1                // =1
    4dc8:      	ldr	x0, [x0]
    4dcc:      	blr	x8
    4dd0:      	cbz	x0, 0x4df0 <kprobe_unwind_perl+0x4df0>
    4dd4:      	ldr	x8, [x0]
    4dd8:      	add	x8, x8, #0x1
    4ddc:      	str	x8, [x0]
    4de0:      	ldp	x24, x9, [sp, #0x10]
    4de4:      	cmp	w29, #0x3
    4de8:      	b.eq	0x4e04 <kprobe_unwind_perl+0x4e04>
    4dec:      	b	0x563c <kprobe_unwind_perl+0x563c>
    4df0:      	ldr	w8, [x23]
    4df4:      	cbnz	w8, 0x529c <kprobe_unwind_perl+0x529c>
    4df8:      	ldp	x24, x9, [sp, #0x10]
    4dfc:      	cmp	w29, #0x3
    4e00:      	b.ne	0x563c <kprobe_unwind_perl+0x563c>
    4e04:      	ldr	x25, [x21, #0xf40]
    4e08:      	cmp	x25, x9
    4e0c:      	b.lo	0x2ecc <kprobe_unwind_perl+0x2ecc>
    4e10:      	ldrb	w8, [x22, #0x19]
    4e14:      	mov	w9, #0x1                // =1
    4e18:      	mov	w10, #0x70              // =112
    4e1c:      	add	x11, sp, #0x7c
    4e20:      	add	x0, sp, #0x7c
    4e24:      	mov	w1, #0x1                // =1
    4e28:      	add	x8, x25, x8
    4e2c:      	ldrb	w8, [x22, #0x19]
    4e30:      	add	x2, x25, x8
    4e34:      	blr	x10
    4e38:      	cbz	x0, 0x4f00 <kprobe_unwind_perl+0x4f00>
    4e3c:      	ldr	w8, [x23]
    4e40:      	cbnz	w8, 0x5334 <kprobe_unwind_perl+0x5334>
    4e44:      	mov	w8, #0x13               // =19
    4e48:      	adrp	x0, 0x4000 <kprobe_unwind_perl+0x4000>
    4e4c:      	add	x9, sp, #0xa8
    4e50:      	str	w8, [sp, #0xa8]
    4e54:      	mov	w8, #0x1                // =1
    4e58:      	add	x1, sp, #0xa8
    4e5c:      	ldr	x0, [x0]
    4e60:      	blr	x8
    4e64:      	cbz	x0, 0x4ff8 <kprobe_unwind_perl+0x4ff8>
    4e68:      	ldr	x8, [x0]
    4e6c:      	mov	w29, #0x3               // =3
    4e70:      	add	x8, x8, #0x1
    4e74:      	str	x8, [x0]
    4e78:      	b	0x55f0 <kprobe_unwind_perl+0x55f0>
    4e7c:      	ldr	x8, [sp, #0x10]
    4e80:      	mov	w29, #0x3               // =3
    4e84:      	ldr	x8, [x8]
    4e88:      	cbnz	x8, 0x4da0 <kprobe_unwind_perl+0x4da0>
    4e8c:      	ldrb	w8, [x22, #0x1a]
    4e90:      	mov	w9, #0x8                // =8
    4e94:      	mov	w10, #0x70              // =112
    4e98:      	ldr	x0, [sp, #0x10]
    4e9c:      	mov	w1, #0x8                // =8
    4ea0:      	add	x8, x25, x8
    4ea4:      	ldrb	w8, [x22, #0x1a]
    4ea8:      	add	x2, x25, x8
    4eac:      	blr	x10
    4eb0:      	cbnz	x0, 0x45c4 <kprobe_unwind_perl+0x45c4>
    4eb4:      	ldr	w8, [x23]
    4eb8:      	cbz	w8, 0x4da0 <kprobe_unwind_perl+0x4da0>
    4ebc:      	adrp	x8, 0x4000 <kprobe_unwind_perl+0x4000>
    4ec0:      	add	x8, x8, #0x0
    4ec4:      	add	x0, sp, #0x30
    4ec8:      	ldp	x9, x10, [x8]
    4ecc:      	mov	w1, #0x1e               // =30
    4ed0:      	stp	x9, x10, [sp, #0x30]
    4ed4:      	ldr	x9, [x8, #0x10]
    4ed8:      	ldur	x8, [x8, #0x16]
    4edc:      	add	x10, sp, #0x30
    4ee0:      	str	x9, [sp, #0x40]
    4ee4:      	stur	x8, [sp, #0x46]
    4ee8:      	mov	w8, #0x1e               // =30
    4eec:      	mov	w9, #0x6                // =6
    4ef0:      	ldr	x8, [sp, #0x10]
    4ef4:      	ldr	x2, [x8]
    4ef8:      	blr	x9
    4efc:      	b	0x4da0 <kprobe_unwind_perl+0x4da0>
    4f00:      	ldr	w8, [x23]
    4f04:      	cbnz	w8, 0x559c <kprobe_unwind_perl+0x559c>
    4f08:      	ldrb	w8, [sp, #0x7c]
    4f0c:      	and	w9, w8, #0xf
    4f10:      	sub	w10, w9, #0x9
    4f14:      	cmp	w10, #0x2
    4f18:      	b.hs	0x55e4 <kprobe_unwind_perl+0x55e4>
    4f1c:      	sxtb	w8, w8
    4f20:      	tbnz	w8, #0x1f, 0x55ec <kprobe_unwind_perl+0x55ec>
    4f24:      	ldrb	w8, [x22, #0x1b]
    4f28:      	mov	w9, #0x8                // =8
    4f2c:      	mov	w10, #0x70              // =112
    4f30:      	add	x11, sp, #0x30
    4f34:      	add	x0, sp, #0x30
    4f38:      	mov	w1, #0x8                // =8
    4f3c:      	add	x8, x25, x8
    4f40:      	ldrb	w8, [x22, #0x1b]
    4f44:      	add	x2, x25, x8
    4f48:      	blr	x10
    4f4c:      	cbnz	x0, 0x4e3c <kprobe_unwind_perl+0x4e3c>
    4f50:      	ldr	x8, [sp, #0x30]
    4f54:      	mov	w9, #0x8                // =8
    4f58:      	mov	w10, #0x70              // =112
    4f5c:      	add	x11, sp, #0x70
    4f60:      	add	x0, sp, #0x70
    4f64:      	mov	w1, #0x8                // =8
    4f68:      	cmp	x8, #0x0
    4f6c:      	mov	w8, #0x3                // =3
    4f70:      	csinc	w29, w8, wzr, ne
    4f74:      	ldrb	w8, [x22, #0x1c]
    4f78:      	add	x8, x25, x8
    4f7c:      	ldrb	w8, [x22, #0x1c]
    4f80:      	add	x2, x25, x8
    4f84:      	blr	x10
    4f88:      	cbnz	x0, 0x4e3c <kprobe_unwind_perl+0x4e3c>
    4f8c:      	ldr	x24, [sp, #0x70]
    4f90:      	ldrb	w8, [x22, #0x1e]
    4f94:      	mov	w9, #0x4                // =4
    4f98:      	mov	w10, #0x70              // =112
    4f9c:      	add	x11, sp, #0xb8
    4fa0:      	add	x0, sp, #0xb8
    4fa4:      	mov	w1, #0x4                // =4
    4fa8:      	add	x8, x24, x8
    4fac:      	ldrb	w8, [x22, #0x1e]
    4fb0:      	add	x2, x24, x8
    4fb4:      	blr	x10
    4fb8:      	cbz	x0, 0x5048 <kprobe_unwind_perl+0x5048>
    4fbc:      	ldr	w8, [x23]
    4fc0:      	cbnz	w8, 0x66cc <kprobe_unwind_perl+0x66cc>
    4fc4:      	mov	w8, #0x14               // =20
    4fc8:      	adrp	x0, 0x4000 <kprobe_unwind_perl+0x4000>
    4fcc:      	add	x9, sp, #0xbc
    4fd0:      	str	w8, [sp, #0xbc]
    4fd4:      	mov	w8, #0x1                // =1
    4fd8:      	add	x1, sp, #0xbc
    4fdc:      	ldr	x0, [x0]
    4fe0:      	blr	x8
    4fe4:      	cbz	x0, 0x5204 <kprobe_unwind_perl+0x5204>
    4fe8:      	ldr	x8, [x0]
    4fec:      	add	x8, x8, #0x1
    4ff0:      	str	x8, [x0]
    4ff4:      	b	0x4e3c <kprobe_unwind_perl+0x4e3c>
    4ff8:      	ldr	w8, [x23]
    4ffc:      	cbz	w8, 0x55ec <kprobe_unwind_perl+0x55ec>
    5000:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    5004:      	add	x8, x8, #0x0
    5008:      	add	x0, sp, #0x30
    500c:      	ldp	x9, x10, [x8, #0x10]
    5010:      	mov	w1, #0x2e               // =46
    5014:      	stp	x9, x10, [sp, #0x40]
    5018:      	ldr	x9, [x8, #0x20]
    501c:      	add	x10, sp, #0x30
    5020:      	str	x9, [sp, #0x50]
    5024:      	ldur	x9, [x8, #0x26]
    5028:      	stur	x9, [sp, #0x56]
    502c:      	ldp	x9, x8, [x8]
    5030:      	stp	x9, x8, [sp, #0x30]
    5034:      	mov	w8, #0x2e               // =46
    5038:      	mov	w9, #0x6                // =6
    503c:      	ldr	w2, [sp, #0xa8]
    5040:      	blr	x9
    5044:      	b	0x55ec <kprobe_unwind_perl+0x55ec>
    5048:      	ldr	w8, [sp, #0xb8]
    504c:      	and	w8, w8, #0x1f
    5050:      	cmp	w8, #0xd
    5054:      	b.ne	0x5254 <kprobe_unwind_perl+0x5254>
    5058:      	ldrb	w8, [x22, #0x1f]
    505c:      	mov	w9, #0x8                // =8
    5060:      	mov	w10, #0x70              // =112
    5064:      	add	x11, sp, #0xa8
    5068:      	add	x0, sp, #0xa8
    506c:      	mov	w1, #0x8                // =8
    5070:      	add	x8, x24, x8
    5074:      	ldrb	w8, [x22, #0x1f]
    5078:      	add	x2, x24, x8
    507c:      	blr	x10
    5080:      	cbnz	x0, 0x4fbc <kprobe_unwind_perl+0x4fbc>
    5084:      	ldr	x8, [sp, #0xa8]
    5088:      	ldrb	w9, [x22, #0x21]
    508c:      	mov	w10, #0x70              // =112
    5090:      	add	x11, sp, #0xa4
    5094:      	add	x0, sp, #0xa4
    5098:      	mov	w1, #0x4                // =4
    509c:      	add	x8, x8, x9
    50a0:      	mov	w9, #0x4                // =4
    50a4:      	ldr	x8, [sp, #0xa8]
    50a8:      	ldrb	w9, [x22, #0x21]
    50ac:      	add	x2, x8, x9
    50b0:      	blr	x10
    50b4:      	cbnz	x0, 0x4fbc <kprobe_unwind_perl+0x4fbc>
    50b8:      	ldrb	w8, [sp, #0xa5]
    50bc:      	tbnz	w8, #0x7, 0x5550 <kprobe_unwind_perl+0x5550>
    50c0:      	ldr	x8, [sp, #0xa8]
    50c4:      	ldrb	w9, [x22, #0x22]
    50c8:      	mov	w10, #0x70              // =112
    50cc:      	add	x11, sp, #0x98
    50d0:      	add	x0, sp, #0x98
    50d4:      	mov	w1, #0x8                // =8
    50d8:      	add	x8, x8, x9
    50dc:      	mov	w9, #0x8                // =8
    50e0:      	ldr	x8, [sp, #0xa8]
    50e4:      	ldrb	w9, [x22, #0x22]
    50e8:      	add	x2, x8, x9
    50ec:      	blr	x10
    50f0:      	cbnz	x0, 0x4fbc <kprobe_unwind_perl+0x4fbc>
    50f4:      	ldr	x8, [sp, #0x98]
    50f8:      	cbz	x8, 0x4fbc <kprobe_unwind_perl+0x4fbc>
    50fc:      	ldr	w9, [x23]
    5100:      	cbnz	w9, 0x6b68 <kprobe_unwind_perl+0x6b68>
    5104:      	ldrb	w9, [x22, #0x1e]
    5108:      	mov	w10, #0x70              // =112
    510c:      	add	x11, sp, #0x94
    5110:      	add	x0, sp, #0x94
    5114:      	mov	w1, #0x4                // =4
    5118:      	add	x8, x8, x9
    511c:      	mov	w9, #0x4                // =4
    5120:      	ldr	x8, [sp, #0x98]
    5124:      	ldrb	w9, [x22, #0x1e]
    5128:      	add	x2, x8, x9
    512c:      	blr	x10
    5130:      	cbnz	x0, 0x4fbc <kprobe_unwind_perl+0x4fbc>
    5134:      	ldr	w8, [sp, #0x94]
    5138:      	mov	w9, #0x801f             // =32799
    513c:      	and	w8, w8, w9
    5140:      	mov	w9, #0x8009             // =32777
    5144:      	cmp	w8, w9
    5148:      	b.ne	0x6540 <kprobe_unwind_perl+0x6540>
    514c:      	ldr	x8, [sp, #0x98]
    5150:      	ldrb	w9, [x22, #0x20]
    5154:      	mov	w10, #0x70              // =112
    5158:      	add	x11, sp, #0x88
    515c:      	add	x0, sp, #0x88
    5160:      	mov	w1, #0x8                // =8
    5164:      	add	x8, x8, x9
    5168:      	mov	w9, #0x8                // =8
    516c:      	ldr	x8, [sp, #0x98]
    5170:      	ldrb	w9, [x22, #0x20]
    5174:      	add	x2, x8, x9
    5178:      	blr	x10
    517c:      	cbnz	x0, 0x4fbc <kprobe_unwind_perl+0x4fbc>
    5180:      	ldr	x8, [sp, #0x88]
    5184:      	ldrb	w9, [x22, #0x23]
    5188:      	mov	w10, #0x70              // =112
    518c:      	add	x11, sp, #0x80
    5190:      	add	x0, sp, #0x80
    5194:      	mov	w1, #0x8                // =8
    5198:      	add	x8, x8, x9
    519c:      	mov	w9, #0x8                // =8
    51a0:      	ldr	x8, [sp, #0x88]
    51a4:      	ldrb	w9, [x22, #0x23]
    51a8:      	add	x2, x8, x9
    51ac:      	blr	x10
    51b0:      	cbnz	x0, 0x4fbc <kprobe_unwind_perl+0x4fbc>
    51b4:      	ldr	x24, [sp, #0x80]
    51b8:      	cbz	x24, 0x6930 <kprobe_unwind_perl+0x6930>
    51bc:      	ldr	w8, [x23]
    51c0:      	cbz	w8, 0x693c <kprobe_unwind_perl+0x693c>
    51c4:      	mov	w8, #0x786c             // =30828
    51c8:      	add	x10, sp, #0x30
    51cc:      	add	x0, sp, #0x30
    51d0:      	mov	w1, #0x14               // =20
    51d4:      	movk	w8, #0xa, lsl #16
    51d8:      	str	w8, [sp, #0x40]
    51dc:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    51e0:      	add	x8, x8, #0x0
    51e4:      	ldp	x9, x8, [x8]
    51e8:      	stp	x9, x8, [sp, #0x30]
    51ec:      	mov	w8, #0x14               // =20
    51f0:      	mov	w9, #0x6                // =6
    51f4:      	ldr	x2, [sp, #0x80]
    51f8:      	blr	x9
    51fc:      	add	x8, sp, #0x80
    5200:      	b	0x6934 <kprobe_unwind_perl+0x6934>
    5204:      	ldr	w8, [x23]
    5208:      	cbz	w8, 0x4e3c <kprobe_unwind_perl+0x4e3c>
    520c:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    5210:      	add	x8, x8, #0x0
    5214:      	add	x0, sp, #0x30
    5218:      	ldp	x9, x10, [x8, #0x10]
    521c:      	mov	w1, #0x2e               // =46
    5220:      	stp	x9, x10, [sp, #0x40]
    5224:      	ldr	x9, [x8, #0x20]
    5228:      	add	x10, sp, #0x30
    522c:      	str	x9, [sp, #0x50]
    5230:      	ldur	x9, [x8, #0x26]
    5234:      	stur	x9, [sp, #0x56]
    5238:      	ldp	x9, x8, [x8]
    523c:      	stp	x9, x8, [sp, #0x30]
    5240:      	mov	w8, #0x2e               // =46
    5244:      	mov	w9, #0x6                // =6
    5248:      	ldr	w2, [sp, #0xbc]
    524c:      	blr	x9
    5250:      	b	0x4e3c <kprobe_unwind_perl+0x4e3c>
    5254:      	ldr	w8, [x23]
    5258:      	cbz	w8, 0x4e3c <kprobe_unwind_perl+0x4e3c>
    525c:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    5260:      	add	x8, x8, #0x0
    5264:      	add	x0, sp, #0x30
    5268:      	ldp	x9, x10, [x8]
    526c:      	mov	w1, #0x1e               // =30
    5270:      	stp	x9, x10, [sp, #0x30]
    5274:      	ldr	x9, [x8, #0x10]
    5278:      	ldur	x8, [x8, #0x16]
    527c:      	add	x10, sp, #0x30
    5280:      	str	x9, [sp, #0x40]
    5284:      	stur	x8, [sp, #0x46]
    5288:      	mov	w8, #0x1e               // =30
    528c:      	mov	w9, #0x6                // =6
    5290:      	ldr	w2, [sp, #0xb8]
    5294:      	blr	x9
    5298:      	b	0x4e3c <kprobe_unwind_perl+0x4e3c>
    529c:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    52a0:      	add	x8, x8, #0x0
    52a4:      	add	x0, sp, #0x30
    52a8:      	ldp	x9, x10, [x8, #0x10]
    52ac:      	mov	w1, #0x2e               // =46
    52b0:      	stp	x9, x10, [sp, #0x40]
    52b4:      	ldr	x9, [x8, #0x20]
    52b8:      	add	x10, sp, #0x30
    52bc:      	str	x9, [sp, #0x50]
    52c0:      	ldur	x9, [x8, #0x26]
    52c4:      	stur	x9, [sp, #0x56]
    52c8:      	ldp	x9, x8, [x8]
    52cc:      	stp	x9, x8, [sp, #0x30]
    52d0:      	mov	w8, #0x2e               // =46
    52d4:      	mov	w9, #0x6                // =6
    52d8:      	ldr	w2, [sp, #0xa8]
    52dc:      	blr	x9
    52e0:      	ldp	x24, x9, [sp, #0x10]
    52e4:      	cmp	w29, #0x3
    52e8:      	b.eq	0x4e04 <kprobe_unwind_perl+0x4e04>
    52ec:      	b	0x563c <kprobe_unwind_perl+0x563c>
    52f0:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    52f4:      	add	x8, x8, #0x0
    52f8:      	add	x0, sp, #0x30
    52fc:      	ldp	x9, x10, [x8, #0x10]
    5300:      	mov	w1, #0x2d               // =45
    5304:      	stp	x9, x10, [sp, #0x40]
    5308:      	ldr	x9, [x8, #0x20]
    530c:      	add	x10, sp, #0x30
    5310:      	str	x9, [sp, #0x50]
    5314:      	ldur	x9, [x8, #0x25]
    5318:      	stur	x9, [sp, #0x55]
    531c:      	ldp	x9, x8, [x8]
    5320:      	stp	x9, x8, [sp, #0x30]
    5324:      	mov	w8, #0x2d               // =45
    5328:      	mov	w9, #0x6                // =6
    532c:      	blr	x9
    5330:      	b	0x383c <kprobe_unwind_perl+0x383c>
    5334:      	mov	w8, #0xa                // =10
    5338:      	add	x0, sp, #0x30
    533c:      	mov	w1, #0x2a               // =42
    5340:      	strh	w8, [sp, #0x58]
    5344:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    5348:      	add	x8, x8, #0x0
    534c:      	mov	x2, x25
    5350:      	ldp	x9, x10, [x8, #0x10]
    5354:      	stp	x9, x10, [sp, #0x40]
    5358:      	ldr	x9, [x8, #0x20]
    535c:      	add	x10, sp, #0x30
    5360:      	str	x9, [sp, #0x50]
    5364:      	ldp	x8, x9, [x8]
    5368:      	stp	x8, x9, [sp, #0x30]
    536c:      	mov	w8, #0x2a               // =42
    5370:      	mov	w9, #0x6                // =6
    5374:      	blr	x9
    5378:      	b	0x4e44 <kprobe_unwind_perl+0x4e44>
    537c:      	ldr	w8, [x23]
    5380:      	cbz	w8, 0x3e5c <kprobe_unwind_perl+0x3e5c>
    5384:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    5388:      	add	x8, x8, #0x0
    538c:      	add	x0, sp, #0x30
    5390:      	ldp	x9, x10, [x8, #0x10]
    5394:      	mov	w1, #0x26               // =38
    5398:      	stp	x9, x10, [sp, #0x40]
    539c:      	ldur	x9, [x8, #0x1e]
    53a0:      	add	x10, sp, #0x30
    53a4:      	stur	x9, [sp, #0x4e]
    53a8:      	ldp	x8, x9, [x8]
    53ac:      	stp	x8, x9, [sp, #0x30]
    53b0:      	mov	w8, #0x26               // =38
    53b4:      	mov	w9, #0x6                // =6
    53b8:      	ldr	w2, [sp, #0x94]
    53bc:      	blr	x9
    53c0:      	b	0x3e5c <kprobe_unwind_perl+0x3e5c>
    53c4:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    53c8:      	add	x8, x8, #0x0
    53cc:      	add	x0, sp, #0x30
    53d0:      	ldp	x9, x10, [x8, #0x10]
    53d4:      	mov	w1, #0x2e               // =46
    53d8:      	stp	x9, x10, [sp, #0x40]
    53dc:      	ldr	x9, [x8, #0x20]
    53e0:      	add	x10, sp, #0x30
    53e4:      	str	x9, [sp, #0x50]
    53e8:      	ldur	x9, [x8, #0x26]
    53ec:      	stur	x9, [sp, #0x56]
    53f0:      	ldp	x9, x8, [x8]
    53f4:      	stp	x9, x8, [sp, #0x30]
    53f8:      	mov	w8, #0x2e               // =46
    53fc:      	mov	w9, #0x6                // =6
    5400:      	ldr	w2, [sp, #0xa8]
    5404:      	blr	x9
    5408:      	b	0x2c6c <kprobe_unwind_perl+0x2c6c>
    540c:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    5410:      	add	x8, x8, #0x0
    5414:      	add	x0, sp, #0x30
    5418:      	ldp	x9, x10, [x8, #0x10]
    541c:      	mov	w1, #0x28               // =40
    5420:      	mov	x3, x24
    5424:      	stp	x9, x10, [sp, #0x40]
    5428:      	ldr	x9, [x8, #0x20]
    542c:      	add	x10, sp, #0x30
    5430:      	str	x9, [sp, #0x50]
    5434:      	ldp	x8, x9, [x8]
    5438:      	stp	x8, x9, [sp, #0x30]
    543c:      	mov	w8, #0x28               // =40
    5440:      	mov	w9, #0x6                // =6
    5444:      	ldr	x2, [sp, #0x8]
    5448:      	blr	x9
    544c:      	ldr	w8, [x21, #0x2c0]
    5450:      	cmp	w8, #0x7e
    5454:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    5458:      	b	0x2d84 <kprobe_unwind_perl+0x2d84>
    545c:      	add	x8, sp, #0x98
    5460:      	ldr	x24, [x8]
    5464:      	cbz	x24, 0x2f04 <kprobe_unwind_perl+0x2f04>
    5468:      	ldr	x8, [sp, #0x10]
    546c:      	ldr	x8, [x8]
    5470:      	str	x8, [sp, #0x8]
    5474:      	ldr	w8, [x23]
    5478:      	cbnz	w8, 0x6a24 <kprobe_unwind_perl+0x6a24>
    547c:      	ldr	w8, [x21, #0x2c0]
    5480:      	cmp	w8, #0x7e
    5484:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    5488:      	add	w9, w8, #0x1
    548c:      	ldr	x10, [sp, #0x8]
    5490:      	str	w9, [x21, #0x2c0]
    5494:      	mov	w9, #0x18               // =24
    5498:      	umaddl	x8, w8, w9, x21
    549c:      	add	x9, x8, #0x2d0
    54a0:      	str	x10, [x8, #0x2d8]
    54a4:      	mov	w10, #0x7               // =7
    54a8:      	str	x24, [x8, #0x2d0]
    54ac:      	str	wzr, [x8, #0x2e4]
    54b0:      	str	xzr, [x21, #0xf30]
    54b4:      	strb	w10, [x8, #0x2e0]
    54b8:      	stur	wzr, [x9, #0x11]
    54bc:      	b	0x3704 <kprobe_unwind_perl+0x3704>
    54c0:      	mov	w8, #0x786c             // =30828
    54c4:      	add	x10, sp, #0x30
    54c8:      	add	x0, sp, #0x30
    54cc:      	mov	w1, #0x14               // =20
    54d0:      	movk	w8, #0xa, lsl #16
    54d4:      	str	w8, [sp, #0x40]
    54d8:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    54dc:      	add	x8, x8, #0x0
    54e0:      	ldp	x9, x8, [x8]
    54e4:      	stp	x9, x8, [sp, #0x30]
    54e8:      	mov	w8, #0x14               // =20
    54ec:      	mov	w9, #0x6                // =6
    54f0:      	ldr	x2, [sp, #0x80]
    54f4:      	blr	x9
    54f8:      	add	x8, sp, #0x80
    54fc:      	ldr	x8, [x8]
    5500:      	ldr	x24, [sp, #0x10]
    5504:      	str	x8, [sp, #0x8]
    5508:      	cbnz	x8, 0x2d6c <kprobe_unwind_perl+0x2d6c>
    550c:      	b	0xcd8 <kprobe_unwind_perl+0xcd8>
    5510:      	mov	w8, #0x786c             // =30828
    5514:      	add	x10, sp, #0x30
    5518:      	add	x0, sp, #0x30
    551c:      	mov	w1, #0x13               // =19
    5520:      	movk	w8, #0xa, lsl #16
    5524:      	stur	w8, [sp, #0x3f]
    5528:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    552c:      	add	x8, x8, #0x0
    5530:      	ldp	x9, x8, [x8]
    5534:      	stp	x9, x8, [sp, #0x30]
    5538:      	mov	w8, #0x13               // =19
    553c:      	mov	w9, #0x6                // =6
    5540:      	ldr	x2, [sp, #0x98]
    5544:      	blr	x9
    5548:      	ldr	x8, [sp, #0x98]
    554c:      	b	0x23d4 <kprobe_unwind_perl+0x23d4>
    5550:      	ldr	w8, [x23]
    5554:      	cbz	w8, 0x4e3c <kprobe_unwind_perl+0x4e3c>
    5558:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    555c:      	add	x8, x8, #0x0
    5560:      	add	x0, sp, #0x30
    5564:      	ldp	x9, x10, [x8, #0x10]
    5568:      	mov	w1, #0x26               // =38
    556c:      	stp	x9, x10, [sp, #0x40]
    5570:      	ldur	x9, [x8, #0x1e]
    5574:      	add	x10, sp, #0x30
    5578:      	stur	x9, [sp, #0x4e]
    557c:      	ldp	x8, x9, [x8]
    5580:      	stp	x8, x9, [sp, #0x30]
    5584:      	mov	w8, #0x26               // =38
    5588:      	mov	w9, #0x6                // =6
    558c:      	ldr	w2, [sp, #0xb8]
    5590:      	ldr	w3, [sp, #0xa4]
    5594:      	blr	x9
    5598:      	b	0x4e3c <kprobe_unwind_perl+0x4e3c>
    559c:      	mov	w8, #0xa                // =10
    55a0:      	add	x10, sp, #0x30
    55a4:      	add	x0, sp, #0x30
    55a8:      	strh	w8, [sp, #0x40]
    55ac:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    55b0:      	add	x8, x8, #0x0
    55b4:      	mov	w1, #0x12               // =18
    55b8:      	ldp	x9, x8, [x8]
    55bc:      	stp	x9, x8, [sp, #0x30]
    55c0:      	mov	w8, #0x12               // =18
    55c4:      	mov	w9, #0x6                // =6
    55c8:      	ldrb	w2, [sp, #0x7c]
    55cc:      	blr	x9
    55d0:      	ldrb	w8, [sp, #0x7c]
    55d4:      	and	w9, w8, #0xf
    55d8:      	sub	w10, w9, #0x9
    55dc:      	cmp	w10, #0x2
    55e0:      	b.lo	0x4f1c <kprobe_unwind_perl+0x4f1c>
    55e4:      	cmp	w9, #0xc
    55e8:      	b.ne	0x5cb8 <kprobe_unwind_perl+0x5cb8>
    55ec:      	mov	w29, #0x3               // =3
    55f0:      	ldrb	w8, [x22, #0x1d]
    55f4:      	ldr	x9, [x21, #0xf40]
    55f8:      	adrp	x0, 0x5000 <kprobe_unwind_perl+0x5000>
    55fc:      	add	x1, sp, #0xa8
    5600:      	sub	x8, x9, x8
    5604:      	add	x9, sp, #0xa8
    5608:      	str	x8, [x21, #0xf40]
    560c:      	mov	w8, #0x10               // =16
    5610:      	str	w8, [sp, #0xa8]
    5614:      	mov	w8, #0x1                // =1
    5618:      	ldr	x0, [x0]
    561c:      	blr	x8
    5620:      	cbz	x0, 0x5c2c <kprobe_unwind_perl+0x5c2c>
    5624:      	ldr	x8, [x0]
    5628:      	add	x8, x8, #0x1
    562c:      	str	x8, [x0]
    5630:      	ldp	x24, x9, [sp, #0x10]
    5634:      	cmp	w29, #0x3
    5638:      	b.eq	0x5c40 <kprobe_unwind_perl+0x5c40>
    563c:      	ldr	x8, [x21, #0xf40]
    5640:      	cmp	x8, x9
    5644:      	b.hs	0x5818 <kprobe_unwind_perl+0x5818>
    5648:      	ldr	x24, [x24]
    564c:      	ldr	x25, [sp, #0x20]
    5650:      	cbz	x24, 0x56d4 <kprobe_unwind_perl+0x56d4>
    5654:      	ldr	w8, [x23]
    5658:      	cbnz	w8, 0x59d4 <kprobe_unwind_perl+0x59d4>
    565c:      	ldr	w8, [x21, #0x2c0]
    5660:      	cmp	w8, #0x7f
    5664:      	b.lo	0x56a4 <kprobe_unwind_perl+0x56a4>
    5668:      	ldr	w8, [x23]
    566c:      	cbnz	w8, 0x5ad8 <kprobe_unwind_perl+0x5ad8>
    5670:      	mov	w8, #0x2                // =2
    5674:      	adrp	x0, 0x5000 <kprobe_unwind_perl+0x5000>
    5678:      	add	x9, sp, #0xa8
    567c:      	str	w8, [sp, #0xa8]
    5680:      	mov	w8, #0x1                // =1
    5684:      	add	x1, sp, #0xa8
    5688:      	ldr	x0, [x0]
    568c:      	blr	x8
    5690:      	cbz	x0, 0x5900 <kprobe_unwind_perl+0x5900>
    5694:      	ldr	x8, [x0]
    5698:      	add	x8, x8, #0x1
    569c:      	str	x8, [x0]
    56a0:      	b	0x5908 <kprobe_unwind_perl+0x5908>
    56a4:      	add	w9, w8, #0x1
    56a8:      	mov	w10, #0x7               // =7
    56ac:      	str	w9, [x21, #0x2c0]
    56b0:      	mov	w9, #0x18               // =24
    56b4:      	umaddl	x8, w8, w9, x21
    56b8:      	add	x9, x8, #0x2d0
    56bc:      	str	xzr, [x8, #0x2d0]
    56c0:      	str	x24, [x8, #0x2d8]
    56c4:      	strb	w10, [x8, #0x2e0]
    56c8:      	str	wzr, [x8, #0x2e4]
    56cc:      	str	xzr, [x21, #0xf30]
    56d0:      	stur	wzr, [x9, #0x11]
    56d4:      	ldr	x8, [sp, #0x68]
    56d8:      	ldrb	w9, [x22, #0x18]
    56dc:      	mov	w10, #0x70              // =112
    56e0:      	add	x11, sp, #0x80
    56e4:      	add	x0, sp, #0x80
    56e8:      	mov	w1, #0x4                // =4
    56ec:      	str	wzr, [sp, #0x80]
    56f0:      	add	x8, x8, x9
    56f4:      	mov	w9, #0x4                // =4
    56f8:      	ldr	x8, [sp, #0x68]
    56fc:      	ldrb	w9, [x22, #0x18]
    5700:      	add	x2, x8, x9
    5704:      	blr	x10
    5708:      	cbnz	x0, 0x5800 <kprobe_unwind_perl+0x5800>
    570c:      	ldr	w8, [sp, #0x80]
    5710:      	cmp	w8, #0x1
    5714:      	b.eq	0x5800 <kprobe_unwind_perl+0x5800>
    5718:      	ldr	x8, [sp, #0x68]
    571c:      	ldrb	w9, [x22, #0x16]
    5720:      	mov	w10, #0x70              // =112
    5724:      	add	x11, sp, #0x68
    5728:      	add	x0, sp, #0x68
    572c:      	mov	w1, #0x8                // =8
    5730:      	add	x8, x8, x9
    5734:      	mov	w9, #0x8                // =8
    5738:      	ldr	x8, [sp, #0x68]
    573c:      	ldrb	w9, [x22, #0x16]
    5740:      	add	x2, x8, x9
    5744:      	blr	x10
    5748:      	cbnz	x0, 0x5800 <kprobe_unwind_perl+0x5800>
    574c:      	ldr	x24, [sp, #0x68]
    5750:      	cbz	x24, 0x5800 <kprobe_unwind_perl+0x5800>
    5754:      	ldr	w8, [x23]
    5758:      	cbnz	w8, 0x5b14 <kprobe_unwind_perl+0x5b14>
    575c:      	str	x24, [x25]
    5760:      	mov	w9, #0x8                // =8
    5764:      	mov	w10, #0x70              // =112
    5768:      	add	x11, sp, #0xa8
    576c:      	ldrb	w8, [x22, #0x15]
    5770:      	add	x0, sp, #0xa8
    5774:      	mov	w1, #0x8                // =8
    5778:      	add	x8, x24, x8
    577c:      	ldrb	w8, [x22, #0x15]
    5780:      	add	x2, x24, x8
    5784:      	blr	x10
    5788:      	cbnz	x0, 0x57b8 <kprobe_unwind_perl+0x57b8>
    578c:      	ldrb	w8, [x22, #0x17]
    5790:      	mov	w9, #0x4                // =4
    5794:      	mov	w10, #0x70              // =112
    5798:      	add	x11, sp, #0x88
    579c:      	add	x0, sp, #0x88
    57a0:      	mov	w1, #0x4                // =4
    57a4:      	add	x8, x24, x8
    57a8:      	ldrb	w8, [x22, #0x17]
    57ac:      	add	x2, x24, x8
    57b0:      	blr	x10
    57b4:      	cbz	x0, 0x5960 <kprobe_unwind_perl+0x5960>
    57b8:      	ldr	w8, [x23]
    57bc:      	cbnz	w8, 0x5b58 <kprobe_unwind_perl+0x5b58>
    57c0:      	ldr	w8, [x21, #0x1370]
    57c4:      	adrp	x0, 0x5000 <kprobe_unwind_perl+0x5000>
    57c8:      	add	x9, sp, #0x98
    57cc:      	add	x1, sp, #0x98
    57d0:      	orr	w8, w8, #0x8
    57d4:      	str	w8, [x21, #0x1370]
    57d8:      	mov	w8, #0x12               // =18
    57dc:      	str	w8, [sp, #0x98]
    57e0:      	mov	w8, #0x1                // =1
    57e4:      	ldr	x0, [x0]
    57e8:      	blr	x8
    57ec:      	cbz	x0, 0x5910 <kprobe_unwind_perl+0x5910>
    57f0:      	ldr	x8, [x0]
    57f4:      	add	x8, x8, #0x1
    57f8:      	str	x8, [x0]
    57fc:      	b	0x5814 <kprobe_unwind_perl+0x5814>
    5800:      	ldr	w8, [x23]
    5804:      	cbnz	w8, 0x5a5c <kprobe_unwind_perl+0x5a5c>
    5808:      	ldr	w8, [x21, #0x1370]
    580c:      	orr	w8, w8, #0x8
    5810:      	str	w8, [x21, #0x1370]
    5814:      	mov	w29, #0x1               // =1
    5818:      	ldr	w8, [x23]
    581c:      	cbnz	w8, 0x5984 <kprobe_unwind_perl+0x5984>
    5820:      	str	wzr, [sp, #0x30]
    5824:      	mov	w8, #0x1                // =1
    5828:      	add	x9, sp, #0x30
    582c:      	add	x1, sp, #0x30
    5830:      	mov	x0, x20
    5834:      	blr	x8
    5838:      	cbz	x0, 0x588c <kprobe_unwind_perl+0x588c>
    583c:      	mov	w20, #0x1374            // =4980
    5840:      	ldrb	w8, [x0, x20]
    5844:      	cmp	w8, #0x1d
    5848:      	b.lo	0x58bc <kprobe_unwind_perl+0x58bc>
    584c:      	mov	w8, #0x5                // =5
    5850:      	mov	x21, x0
    5854:      	add	x9, sp, #0xa8
    5858:      	str	w8, [x0, #0xf1c]
    585c:      	mov	w8, #0x44               // =68
    5860:      	adrp	x0, 0x5000 <kprobe_unwind_perl+0x5000>
    5864:      	add	x1, sp, #0xa8
    5868:      	str	w8, [sp, #0xa8]
    586c:      	mov	w8, #0x1                // =1
    5870:      	ldr	x0, [x0]
    5874:      	blr	x8
    5878:      	cbz	x0, 0x58a8 <kprobe_unwind_perl+0x58a8>
    587c:      	ldr	x8, [x0]
    5880:      	add	x8, x8, #0x1
    5884:      	str	x8, [x0]
    5888:      	b	0x58b0 <kprobe_unwind_perl+0x58b0>
    588c:      	adrp	x1, 0x5000 <kprobe_unwind_perl+0x5000>
    5890:      	mov	x8, xzr
    5894:      	mov	w9, #0xc                // =12
    5898:      	ldr	x1, [x1]
    589c:      	mov	x0, x19
    58a0:      	mov	w2, wzr
    58a4:      	b	0x58dc <kprobe_unwind_perl+0x58dc>
    58a8:      	ldr	w8, [x23]
    58ac:      	cbnz	w8, 0x5a90 <kprobe_unwind_perl+0x5a90>
    58b0:      	ldrb	w8, [x21, x20]
    58b4:      	mov	w29, wzr
    58b8:      	mov	x0, x21
    58bc:      	add	w8, w8, #0x1
    58c0:      	adrp	x1, 0x5000 <kprobe_unwind_perl+0x5000>
    58c4:      	mov	w9, #0xc                // =12
    58c8:      	strb	w8, [x0, x20]
    58cc:      	mov	w8, w29
    58d0:      	mov	x0, x19
    58d4:      	mov	w2, w29
    58d8:      	ldr	x1, [x1]
    58dc:      	blr	x9
    58e0:      	mov	w0, #-0x1               // =-1
    58e4:      	ldp	x20, x19, [sp, #0xf0]
    58e8:      	ldr	x29, [sp, #0xb0]
    58ec:      	ldp	x22, x21, [sp, #0xe0]
    58f0:      	ldp	x24, x23, [sp, #0xd0]
    58f4:      	ldp	x30, x25, [sp, #0xc0]
    58f8:      	add	sp, sp, #0x100
    58fc:      	ret
    5900:      	ldr	w8, [x23]
    5904:      	cbnz	w8, 0x5b9c <kprobe_unwind_perl+0x5b9c>
    5908:      	mov	w29, wzr
    590c:      	b	0x5820 <kprobe_unwind_perl+0x5820>
    5910:      	ldr	w8, [x23]
    5914:      	cbz	w8, 0x5814 <kprobe_unwind_perl+0x5814>
    5918:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    591c:      	add	x8, x8, #0x0
    5920:      	add	x0, sp, #0x30
    5924:      	ldp	x9, x10, [x8, #0x10]
    5928:      	mov	w1, #0x2e               // =46
    592c:      	stp	x9, x10, [sp, #0x40]
    5930:      	ldr	x9, [x8, #0x20]
    5934:      	add	x10, sp, #0x30
    5938:      	str	x9, [sp, #0x50]
    593c:      	ldur	x9, [x8, #0x26]
    5940:      	stur	x9, [sp, #0x56]
    5944:      	ldp	x9, x8, [x8]
    5948:      	stp	x9, x8, [sp, #0x30]
    594c:      	mov	w8, #0x2e               // =46
    5950:      	mov	w9, #0x6                // =6
    5954:      	ldr	w2, [sp, #0x98]
    5958:      	blr	x9
    595c:      	b	0x5814 <kprobe_unwind_perl+0x5814>
    5960:      	ldr	w8, [x23]
    5964:      	cbnz	w8, 0x5be8 <kprobe_unwind_perl+0x5be8>
    5968:      	ldr	x8, [sp, #0xa8]
    596c:      	ldrsw	x9, [sp, #0x88]
    5970:      	str	x8, [x21, #0xf38]
    5974:      	ldrb	w10, [x22, #0x1d]
    5978:      	smaddl	x8, w9, w10, x8
    597c:      	str	x8, [x21, #0xf40]
    5980:      	b	0x5814 <kprobe_unwind_perl+0x5814>
    5984:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    5988:      	add	x8, x8, #0x0
    598c:      	add	x0, sp, #0x30
    5990:      	ldp	x9, x10, [x8, #0x20]
    5994:      	mov	w1, #0x35               // =53
    5998:      	stp	x9, x10, [sp, #0x50]
    599c:      	ldur	x9, [x8, #0x2d]
    59a0:      	stur	x9, [sp, #0x5d]
    59a4:      	ldp	x9, x10, [x8]
    59a8:      	stp	x9, x10, [sp, #0x30]
    59ac:      	ldp	x8, x9, [x8, #0x10]
    59b0:      	add	x10, sp, #0x30
    59b4:      	stp	x8, x9, [sp, #0x40]
    59b8:      	mov	w8, #0x35               // =53
    59bc:      	mov	w9, #0x6                // =6
    59c0:      	ldr	x2, [sp, #0x68]
    59c4:      	ldr	x3, [x21, #0xf38]
    59c8:      	ldr	x4, [x21, #0xf40]
    59cc:      	blr	x9
    59d0:      	b	0x5820 <kprobe_unwind_perl+0x5820>
    59d4:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    59d8:      	add	x8, x8, #0x0
    59dc:      	add	x0, sp, #0x30
    59e0:      	ldp	x9, x10, [x8, #0x10]
    59e4:      	mov	w1, #0x28               // =40
    59e8:      	mov	x2, x24
    59ec:      	stp	x9, x10, [sp, #0x40]
    59f0:      	ldr	x9, [x8, #0x20]
    59f4:      	add	x10, sp, #0x30
    59f8:      	str	x9, [sp, #0x50]
    59fc:      	ldp	x8, x9, [x8]
    5a00:      	stp	x8, x9, [sp, #0x30]
    5a04:      	mov	w8, #0x28               // =40
    5a08:      	mov	w9, #0x6                // =6
    5a0c:      	blr	x9
    5a10:      	ldr	w8, [x23]
    5a14:      	cbz	w8, 0x565c <kprobe_unwind_perl+0x565c>
    5a18:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    5a1c:      	add	x8, x8, #0x0
    5a20:      	add	x0, sp, #0x30
    5a24:      	ldp	x9, x10, [x8, #0x10]
    5a28:      	mov	w1, #0x28               // =40
    5a2c:      	mov	x2, xzr
    5a30:      	mov	x3, x24
    5a34:      	stp	x9, x10, [sp, #0x40]
    5a38:      	ldr	x9, [x8, #0x20]
    5a3c:      	add	x10, sp, #0x30
    5a40:      	str	x9, [sp, #0x50]
    5a44:      	ldp	x8, x9, [x8]
    5a48:      	stp	x8, x9, [sp, #0x30]
    5a4c:      	mov	w8, #0x28               // =40
    5a50:      	mov	w9, #0x6                // =6
    5a54:      	blr	x9
    5a58:      	b	0x565c <kprobe_unwind_perl+0x565c>
    5a5c:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    5a60:      	add	x8, x8, #0x0
    5a64:      	add	x0, sp, #0x30
    5a68:      	ldp	x9, x10, [x8]
    5a6c:      	ldur	x8, [x8, #0xe]
    5a70:      	mov	w1, #0x16               // =22
    5a74:      	stp	x9, x10, [sp, #0x30]
    5a78:      	stur	x8, [sp, #0x3e]
    5a7c:      	mov	w8, #0x16               // =22
    5a80:      	mov	w9, #0x6                // =6
    5a84:      	add	x10, sp, #0x30
    5a88:      	blr	x9
    5a8c:      	b	0x5808 <kprobe_unwind_perl+0x5808>
    5a90:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    5a94:      	add	x8, x8, #0x0
    5a98:      	add	x0, sp, #0x30
    5a9c:      	ldp	x9, x10, [x8, #0x10]
    5aa0:      	mov	w1, #0x2e               // =46
    5aa4:      	stp	x9, x10, [sp, #0x40]
    5aa8:      	ldr	x9, [x8, #0x20]
    5aac:      	add	x10, sp, #0x30
    5ab0:      	str	x9, [sp, #0x50]
    5ab4:      	ldur	x9, [x8, #0x26]
    5ab8:      	stur	x9, [sp, #0x56]
    5abc:      	ldp	x9, x8, [x8]
    5ac0:      	stp	x9, x8, [sp, #0x30]
    5ac4:      	mov	w8, #0x2e               // =46
    5ac8:      	mov	w9, #0x6                // =6
    5acc:      	ldr	w2, [sp, #0xa8]
    5ad0:      	blr	x9
    5ad4:      	b	0x58b0 <kprobe_unwind_perl+0x58b0>
    5ad8:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    5adc:      	add	x8, x8, #0x0
    5ae0:      	add	x0, sp, #0x30
    5ae4:      	ldp	x9, x10, [x8, #0x10]
    5ae8:      	mov	w1, #0x25               // =37
    5aec:      	stp	x9, x10, [sp, #0x40]
    5af0:      	ldur	x9, [x8, #0x1d]
    5af4:      	add	x10, sp, #0x30
    5af8:      	stur	x9, [sp, #0x4d]
    5afc:      	ldp	x8, x9, [x8]
    5b00:      	stp	x8, x9, [sp, #0x30]
    5b04:      	mov	w8, #0x25               // =37
    5b08:      	mov	w9, #0x6                // =6
    5b0c:      	blr	x9
    5b10:      	b	0x5670 <kprobe_unwind_perl+0x5670>
    5b14:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    5b18:      	add	x8, x8, #0x0
    5b1c:      	add	x0, sp, #0x30
    5b20:      	ldp	x9, x10, [x8]
    5b24:      	mov	w1, #0x1e               // =30
    5b28:      	stp	x9, x10, [sp, #0x30]
    5b2c:      	ldr	x9, [x8, #0x10]
    5b30:      	ldur	x8, [x8, #0x16]
    5b34:      	add	x10, sp, #0x30
    5b38:      	str	x9, [sp, #0x40]
    5b3c:      	stur	x8, [sp, #0x46]
    5b40:      	mov	w8, #0x1e               // =30
    5b44:      	mov	w9, #0x6                // =6
    5b48:      	ldr	w2, [sp, #0x80]
    5b4c:      	blr	x9
    5b50:      	ldr	x24, [sp, #0x68]
    5b54:      	b	0x575c <kprobe_unwind_perl+0x575c>
    5b58:      	mov	w8, #0x786c             // =30828
    5b5c:      	add	x0, sp, #0x30
    5b60:      	mov	w1, #0x23               // =35
    5b64:      	mov	x2, x24
    5b68:      	movk	w8, #0xa, lsl #16
    5b6c:      	stur	w8, [sp, #0x4f]
    5b70:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    5b74:      	add	x8, x8, #0x0
    5b78:      	ldp	x9, x10, [x8]
    5b7c:      	stp	x9, x10, [sp, #0x30]
    5b80:      	ldp	x9, x8, [x8, #0x10]
    5b84:      	add	x10, sp, #0x30
    5b88:      	stp	x9, x8, [sp, #0x40]
    5b8c:      	mov	w8, #0x23               // =35
    5b90:      	mov	w9, #0x6                // =6
    5b94:      	blr	x9
    5b98:      	b	0x57c0 <kprobe_unwind_perl+0x57c0>
    5b9c:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    5ba0:      	add	x8, x8, #0x0
    5ba4:      	add	x0, sp, #0x30
    5ba8:      	ldp	x9, x10, [x8, #0x10]
    5bac:      	mov	w1, #0x2e               // =46
    5bb0:      	stp	x9, x10, [sp, #0x40]
    5bb4:      	ldr	x9, [x8, #0x20]
    5bb8:      	add	x10, sp, #0x30
    5bbc:      	str	x9, [sp, #0x50]
    5bc0:      	ldur	x9, [x8, #0x26]
    5bc4:      	stur	x9, [sp, #0x56]
    5bc8:      	ldp	x9, x8, [x8]
    5bcc:      	stp	x9, x8, [sp, #0x30]
    5bd0:      	mov	w8, #0x2e               // =46
    5bd4:      	mov	w9, #0x6                // =6
    5bd8:      	ldr	w2, [sp, #0xa8]
    5bdc:      	blr	x9
    5be0:      	mov	w29, wzr
    5be4:      	b	0x5820 <kprobe_unwind_perl+0x5820>
    5be8:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    5bec:      	add	x8, x8, #0x0
    5bf0:      	add	x0, sp, #0x30
    5bf4:      	ldp	x9, x10, [x8, #0x10]
    5bf8:      	mov	w1, #0x26               // =38
    5bfc:      	stp	x9, x10, [sp, #0x40]
    5c00:      	ldur	x9, [x8, #0x1e]
    5c04:      	add	x10, sp, #0x30
    5c08:      	stur	x9, [sp, #0x4e]
    5c0c:      	ldp	x8, x9, [x8]
    5c10:      	stp	x8, x9, [sp, #0x30]
    5c14:      	mov	w8, #0x26               // =38
    5c18:      	mov	w9, #0x6                // =6
    5c1c:      	ldr	x2, [sp, #0xa8]
    5c20:      	ldr	w3, [sp, #0x88]
    5c24:      	blr	x9
    5c28:      	b	0x5968 <kprobe_unwind_perl+0x5968>
    5c2c:      	ldr	w8, [x23]
    5c30:      	cbnz	w8, 0x60d8 <kprobe_unwind_perl+0x60d8>
    5c34:      	ldp	x24, x9, [sp, #0x10]
    5c38:      	cmp	w29, #0x3
    5c3c:      	b.ne	0x563c <kprobe_unwind_perl+0x563c>
    5c40:      	ldr	x25, [x21, #0xf40]
    5c44:      	cmp	x25, x9
    5c48:      	b.lo	0x2ecc <kprobe_unwind_perl+0x2ecc>
    5c4c:      	ldrb	w8, [x22, #0x19]
    5c50:      	mov	w9, #0x1                // =1
    5c54:      	mov	w10, #0x70              // =112
    5c58:      	add	x11, sp, #0x7c
    5c5c:      	add	x0, sp, #0x7c
    5c60:      	mov	w1, #0x1                // =1
    5c64:      	add	x8, x25, x8
    5c68:      	ldrb	w8, [x22, #0x19]
    5c6c:      	add	x2, x25, x8
    5c70:      	blr	x10
    5c74:      	cbz	x0, 0x5d3c <kprobe_unwind_perl+0x5d3c>
    5c78:      	ldr	w8, [x23]
    5c7c:      	cbnz	w8, 0x6170 <kprobe_unwind_perl+0x6170>
    5c80:      	mov	w8, #0x13               // =19
    5c84:      	adrp	x0, 0x5000 <kprobe_unwind_perl+0x5000>
    5c88:      	add	x9, sp, #0xa8
    5c8c:      	str	w8, [sp, #0xa8]
    5c90:      	mov	w8, #0x1                // =1
    5c94:      	add	x1, sp, #0xa8
    5c98:      	ldr	x0, [x0]
    5c9c:      	blr	x8
    5ca0:      	cbz	x0, 0x5e34 <kprobe_unwind_perl+0x5e34>
    5ca4:      	ldr	x8, [x0]
    5ca8:      	mov	w29, #0x3               // =3
    5cac:      	add	x8, x8, #0x1
    5cb0:      	str	x8, [x0]
    5cb4:      	b	0x63e4 <kprobe_unwind_perl+0x63e4>
    5cb8:      	ldr	x8, [sp, #0x10]
    5cbc:      	mov	w29, #0x3               // =3
    5cc0:      	ldr	x8, [x8]
    5cc4:      	cbnz	x8, 0x55f0 <kprobe_unwind_perl+0x55f0>
    5cc8:      	ldrb	w8, [x22, #0x1a]
    5ccc:      	mov	w9, #0x8                // =8
    5cd0:      	mov	w10, #0x70              // =112
    5cd4:      	ldr	x0, [sp, #0x10]
    5cd8:      	mov	w1, #0x8                // =8
    5cdc:      	add	x8, x25, x8
    5ce0:      	ldrb	w8, [x22, #0x1a]
    5ce4:      	add	x2, x25, x8
    5ce8:      	blr	x10
    5cec:      	cbnz	x0, 0x4e3c <kprobe_unwind_perl+0x4e3c>
    5cf0:      	ldr	w8, [x23]
    5cf4:      	cbz	w8, 0x55f0 <kprobe_unwind_perl+0x55f0>
    5cf8:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    5cfc:      	add	x8, x8, #0x0
    5d00:      	add	x0, sp, #0x30
    5d04:      	ldp	x9, x10, [x8]
    5d08:      	mov	w1, #0x1e               // =30
    5d0c:      	stp	x9, x10, [sp, #0x30]
    5d10:      	ldr	x9, [x8, #0x10]
    5d14:      	ldur	x8, [x8, #0x16]
    5d18:      	add	x10, sp, #0x30
    5d1c:      	str	x9, [sp, #0x40]
    5d20:      	stur	x8, [sp, #0x46]
    5d24:      	mov	w8, #0x1e               // =30
    5d28:      	mov	w9, #0x6                // =6
    5d2c:      	ldr	x8, [sp, #0x10]
    5d30:      	ldr	x2, [x8]
    5d34:      	blr	x9
    5d38:      	b	0x55f0 <kprobe_unwind_perl+0x55f0>
    5d3c:      	ldr	w8, [x23]
    5d40:      	cbnz	w8, 0x6390 <kprobe_unwind_perl+0x6390>
    5d44:      	ldrb	w8, [sp, #0x7c]
    5d48:      	and	w9, w8, #0xf
    5d4c:      	sub	w10, w9, #0x9
    5d50:      	cmp	w10, #0x2
    5d54:      	b.hs	0x63d8 <kprobe_unwind_perl+0x63d8>
    5d58:      	sxtb	w8, w8
    5d5c:      	tbnz	w8, #0x1f, 0x63e0 <kprobe_unwind_perl+0x63e0>
    5d60:      	ldrb	w8, [x22, #0x1b]
    5d64:      	mov	w9, #0x8                // =8
    5d68:      	mov	w10, #0x70              // =112
    5d6c:      	add	x11, sp, #0x30
    5d70:      	add	x0, sp, #0x30
    5d74:      	mov	w1, #0x8                // =8
    5d78:      	add	x8, x25, x8
    5d7c:      	ldrb	w8, [x22, #0x1b]
    5d80:      	add	x2, x25, x8
    5d84:      	blr	x10
    5d88:      	cbnz	x0, 0x5c78 <kprobe_unwind_perl+0x5c78>
    5d8c:      	ldr	x8, [sp, #0x30]
    5d90:      	mov	w9, #0x8                // =8
    5d94:      	mov	w10, #0x70              // =112
    5d98:      	add	x11, sp, #0x70
    5d9c:      	add	x0, sp, #0x70
    5da0:      	mov	w1, #0x8                // =8
    5da4:      	cmp	x8, #0x0
    5da8:      	mov	w8, #0x3                // =3
    5dac:      	csinc	w29, w8, wzr, ne
    5db0:      	ldrb	w8, [x22, #0x1c]
    5db4:      	add	x8, x25, x8
    5db8:      	ldrb	w8, [x22, #0x1c]
    5dbc:      	add	x2, x25, x8
    5dc0:      	blr	x10
    5dc4:      	cbnz	x0, 0x5c78 <kprobe_unwind_perl+0x5c78>
    5dc8:      	ldr	x24, [sp, #0x70]
    5dcc:      	ldrb	w8, [x22, #0x1e]
    5dd0:      	mov	w9, #0x4                // =4
    5dd4:      	mov	w10, #0x70              // =112
    5dd8:      	add	x11, sp, #0xb8
    5ddc:      	add	x0, sp, #0xb8
    5de0:      	mov	w1, #0x4                // =4
    5de4:      	add	x8, x24, x8
    5de8:      	ldrb	w8, [x22, #0x1e]
    5dec:      	add	x2, x24, x8
    5df0:      	blr	x10
    5df4:      	cbz	x0, 0x5e84 <kprobe_unwind_perl+0x5e84>
    5df8:      	ldr	w8, [x23]
    5dfc:      	cbnz	w8, 0x689c <kprobe_unwind_perl+0x689c>
    5e00:      	mov	w8, #0x14               // =20
    5e04:      	adrp	x0, 0x5000 <kprobe_unwind_perl+0x5000>
    5e08:      	add	x9, sp, #0xbc
    5e0c:      	str	w8, [sp, #0xbc]
    5e10:      	mov	w8, #0x1                // =1
    5e14:      	add	x1, sp, #0xbc
    5e18:      	ldr	x0, [x0]
    5e1c:      	blr	x8
    5e20:      	cbz	x0, 0x6040 <kprobe_unwind_perl+0x6040>
    5e24:      	ldr	x8, [x0]
    5e28:      	add	x8, x8, #0x1
    5e2c:      	str	x8, [x0]
    5e30:      	b	0x5c78 <kprobe_unwind_perl+0x5c78>
    5e34:      	ldr	w8, [x23]
    5e38:      	cbz	w8, 0x63e0 <kprobe_unwind_perl+0x63e0>
    5e3c:      	adrp	x8, 0x5000 <kprobe_unwind_perl+0x5000>
    5e40:      	add	x8, x8, #0x0
    5e44:      	add	x0, sp, #0x30
    5e48:      	ldp	x9, x10, [x8, #0x10]
    5e4c:      	mov	w1, #0x2e               // =46
    5e50:      	stp	x9, x10, [sp, #0x40]
    5e54:      	ldr	x9, [x8, #0x20]
    5e58:      	add	x10, sp, #0x30
    5e5c:      	str	x9, [sp, #0x50]
    5e60:      	ldur	x9, [x8, #0x26]
    5e64:      	stur	x9, [sp, #0x56]
    5e68:      	ldp	x9, x8, [x8]
    5e6c:      	stp	x9, x8, [sp, #0x30]
    5e70:      	mov	w8, #0x2e               // =46
    5e74:      	mov	w9, #0x6                // =6
    5e78:      	ldr	w2, [sp, #0xa8]
    5e7c:      	blr	x9
    5e80:      	b	0x63e0 <kprobe_unwind_perl+0x63e0>
    5e84:      	ldr	w8, [sp, #0xb8]
    5e88:      	and	w8, w8, #0x1f
    5e8c:      	cmp	w8, #0xd
    5e90:      	b.ne	0x6090 <kprobe_unwind_perl+0x6090>
    5e94:      	ldrb	w8, [x22, #0x1f]
    5e98:      	mov	w9, #0x8                // =8
    5e9c:      	mov	w10, #0x70              // =112
    5ea0:      	add	x11, sp, #0xa8
    5ea4:      	add	x0, sp, #0xa8
    5ea8:      	mov	w1, #0x8                // =8
    5eac:      	add	x8, x24, x8
    5eb0:      	ldrb	w8, [x22, #0x1f]
    5eb4:      	add	x2, x24, x8
    5eb8:      	blr	x10
    5ebc:      	cbnz	x0, 0x5df8 <kprobe_unwind_perl+0x5df8>
    5ec0:      	ldr	x8, [sp, #0xa8]
    5ec4:      	ldrb	w9, [x22, #0x21]
    5ec8:      	mov	w10, #0x70              // =112
    5ecc:      	add	x11, sp, #0xa4
    5ed0:      	add	x0, sp, #0xa4
    5ed4:      	mov	w1, #0x4                // =4
    5ed8:      	add	x8, x8, x9
    5edc:      	mov	w9, #0x4                // =4
    5ee0:      	ldr	x8, [sp, #0xa8]
    5ee4:      	ldrb	w9, [x22, #0x21]
    5ee8:      	add	x2, x8, x9
    5eec:      	blr	x10
    5ef0:      	cbnz	x0, 0x5df8 <kprobe_unwind_perl+0x5df8>
    5ef4:      	ldrb	w8, [sp, #0xa5]
    5ef8:      	tbnz	w8, #0x7, 0x6344 <kprobe_unwind_perl+0x6344>
    5efc:      	ldr	x8, [sp, #0xa8]
    5f00:      	ldrb	w9, [x22, #0x22]
    5f04:      	mov	w10, #0x70              // =112
    5f08:      	add	x11, sp, #0x98
    5f0c:      	add	x0, sp, #0x98
    5f10:      	mov	w1, #0x8                // =8
    5f14:      	add	x8, x8, x9
    5f18:      	mov	w9, #0x8                // =8
    5f1c:      	ldr	x8, [sp, #0xa8]
    5f20:      	ldrb	w9, [x22, #0x22]
    5f24:      	add	x2, x8, x9
    5f28:      	blr	x10
    5f2c:      	cbnz	x0, 0x5df8 <kprobe_unwind_perl+0x5df8>
    5f30:      	ldr	x8, [sp, #0x98]
    5f34:      	cbz	x8, 0x5df8 <kprobe_unwind_perl+0x5df8>
    5f38:      	ldr	w9, [x23]
    5f3c:      	cbnz	w9, 0x6bf8 <kprobe_unwind_perl+0x6bf8>
    5f40:      	ldrb	w9, [x22, #0x1e]
    5f44:      	mov	w10, #0x70              // =112
    5f48:      	add	x11, sp, #0x94
    5f4c:      	add	x0, sp, #0x94
    5f50:      	mov	w1, #0x4                // =4
    5f54:      	add	x8, x8, x9
    5f58:      	mov	w9, #0x4                // =4
    5f5c:      	ldr	x8, [sp, #0x98]
    5f60:      	ldrb	w9, [x22, #0x1e]
    5f64:      	add	x2, x8, x9
    5f68:      	blr	x10
    5f6c:      	cbnz	x0, 0x5df8 <kprobe_unwind_perl+0x5df8>
    5f70:      	ldr	w8, [sp, #0x94]
    5f74:      	mov	w9, #0x801f             // =32799
    5f78:      	and	w8, w8, w9
    5f7c:      	mov	w9, #0x8009             // =32777
    5f80:      	cmp	w8, w9
    5f84:      	b.ne	0x6710 <kprobe_unwind_perl+0x6710>
    5f88:      	ldr	x8, [sp, #0x98]
    5f8c:      	ldrb	w9, [x22, #0x20]
    5f90:      	mov	w10, #0x70              // =112
    5f94:      	add	x11, sp, #0x88
    5f98:      	add	x0, sp, #0x88
    5f9c:      	mov	w1, #0x8                // =8
    5fa0:      	add	x8, x8, x9
    5fa4:      	mov	w9, #0x8                // =8
    5fa8:      	ldr	x8, [sp, #0x98]
    5fac:      	ldrb	w9, [x22, #0x20]
    5fb0:      	add	x2, x8, x9
    5fb4:      	blr	x10
    5fb8:      	cbnz	x0, 0x5df8 <kprobe_unwind_perl+0x5df8>
    5fbc:      	ldr	x8, [sp, #0x88]
    5fc0:      	ldrb	w9, [x22, #0x23]
    5fc4:      	mov	w10, #0x70              // =112
    5fc8:      	add	x11, sp, #0x80
    5fcc:      	add	x0, sp, #0x80
    5fd0:      	mov	w1, #0x8                // =8
    5fd4:      	add	x8, x8, x9
    5fd8:      	mov	w9, #0x8                // =8
    5fdc:      	ldr	x8, [sp, #0x88]
    5fe0:      	ldrb	w9, [x22, #0x23]
    5fe4:      	add	x2, x8, x9
    5fe8:      	blr	x10
    5fec:      	cbnz	x0, 0x5df8 <kprobe_unwind_perl+0x5df8>
    5ff0:      	ldr	x24, [sp, #0x80]
    5ff4:      	cbz	x24, 0x6a74 <kprobe_unwind_perl+0x6a74>
    5ff8:      	ldr	w8, [x23]
    5ffc:      	cbz	w8, 0x6a80 <kprobe_unwind_perl+0x6a80>
    6000:      	mov	w8, #0x786c             // =30828
    6004:      	add	x10, sp, #0x30
    6008:      	add	x0, sp, #0x30
    600c:      	mov	w1, #0x14               // =20
    6010:      	movk	w8, #0xa, lsl #16
    6014:      	str	w8, [sp, #0x40]
    6018:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    601c:      	add	x8, x8, #0x0
    6020:      	ldp	x9, x8, [x8]
    6024:      	stp	x9, x8, [sp, #0x30]
    6028:      	mov	w8, #0x14               // =20
    602c:      	mov	w9, #0x6                // =6
    6030:      	ldr	x2, [sp, #0x80]
    6034:      	blr	x9
    6038:      	add	x8, sp, #0x80
    603c:      	b	0x6a78 <kprobe_unwind_perl+0x6a78>
    6040:      	ldr	w8, [x23]
    6044:      	cbz	w8, 0x5c78 <kprobe_unwind_perl+0x5c78>
    6048:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    604c:      	add	x8, x8, #0x0
    6050:      	add	x0, sp, #0x30
    6054:      	ldp	x9, x10, [x8, #0x10]
    6058:      	mov	w1, #0x2e               // =46
    605c:      	stp	x9, x10, [sp, #0x40]
    6060:      	ldr	x9, [x8, #0x20]
    6064:      	add	x10, sp, #0x30
    6068:      	str	x9, [sp, #0x50]
    606c:      	ldur	x9, [x8, #0x26]
    6070:      	stur	x9, [sp, #0x56]
    6074:      	ldp	x9, x8, [x8]
    6078:      	stp	x9, x8, [sp, #0x30]
    607c:      	mov	w8, #0x2e               // =46
    6080:      	mov	w9, #0x6                // =6
    6084:      	ldr	w2, [sp, #0xbc]
    6088:      	blr	x9
    608c:      	b	0x5c78 <kprobe_unwind_perl+0x5c78>
    6090:      	ldr	w8, [x23]
    6094:      	cbz	w8, 0x5c78 <kprobe_unwind_perl+0x5c78>
    6098:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    609c:      	add	x8, x8, #0x0
    60a0:      	add	x0, sp, #0x30
    60a4:      	ldp	x9, x10, [x8]
    60a8:      	mov	w1, #0x1e               // =30
    60ac:      	stp	x9, x10, [sp, #0x30]
    60b0:      	ldr	x9, [x8, #0x10]
    60b4:      	ldur	x8, [x8, #0x16]
    60b8:      	add	x10, sp, #0x30
    60bc:      	str	x9, [sp, #0x40]
    60c0:      	stur	x8, [sp, #0x46]
    60c4:      	mov	w8, #0x1e               // =30
    60c8:      	mov	w9, #0x6                // =6
    60cc:      	ldr	w2, [sp, #0xb8]
    60d0:      	blr	x9
    60d4:      	b	0x5c78 <kprobe_unwind_perl+0x5c78>
    60d8:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    60dc:      	add	x8, x8, #0x0
    60e0:      	add	x0, sp, #0x30
    60e4:      	ldp	x9, x10, [x8, #0x10]
    60e8:      	mov	w1, #0x2e               // =46
    60ec:      	stp	x9, x10, [sp, #0x40]
    60f0:      	ldr	x9, [x8, #0x20]
    60f4:      	add	x10, sp, #0x30
    60f8:      	str	x9, [sp, #0x50]
    60fc:      	ldur	x9, [x8, #0x26]
    6100:      	stur	x9, [sp, #0x56]
    6104:      	ldp	x9, x8, [x8]
    6108:      	stp	x9, x8, [sp, #0x30]
    610c:      	mov	w8, #0x2e               // =46
    6110:      	mov	w9, #0x6                // =6
    6114:      	ldr	w2, [sp, #0xa8]
    6118:      	blr	x9
    611c:      	ldp	x24, x9, [sp, #0x10]
    6120:      	cmp	w29, #0x3
    6124:      	b.eq	0x5c40 <kprobe_unwind_perl+0x5c40>
    6128:      	b	0x563c <kprobe_unwind_perl+0x563c>
    612c:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6130:      	add	x8, x8, #0x0
    6134:      	add	x0, sp, #0x30
    6138:      	ldp	x9, x10, [x8, #0x10]
    613c:      	mov	w1, #0x2d               // =45
    6140:      	stp	x9, x10, [sp, #0x40]
    6144:      	ldr	x9, [x8, #0x20]
    6148:      	add	x10, sp, #0x30
    614c:      	str	x9, [sp, #0x50]
    6150:      	ldur	x9, [x8, #0x25]
    6154:      	stur	x9, [sp, #0x55]
    6158:      	ldp	x9, x8, [x8]
    615c:      	stp	x9, x8, [sp, #0x30]
    6160:      	mov	w8, #0x2d               // =45
    6164:      	mov	w9, #0x6                // =6
    6168:      	blr	x9
    616c:      	b	0x3fe4 <kprobe_unwind_perl+0x3fe4>
    6170:      	mov	w8, #0xa                // =10
    6174:      	add	x0, sp, #0x30
    6178:      	mov	w1, #0x2a               // =42
    617c:      	strh	w8, [sp, #0x58]
    6180:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6184:      	add	x8, x8, #0x0
    6188:      	mov	x2, x25
    618c:      	ldp	x9, x10, [x8, #0x10]
    6190:      	stp	x9, x10, [sp, #0x40]
    6194:      	ldr	x9, [x8, #0x20]
    6198:      	add	x10, sp, #0x30
    619c:      	str	x9, [sp, #0x50]
    61a0:      	ldp	x8, x9, [x8]
    61a4:      	stp	x8, x9, [sp, #0x30]
    61a8:      	mov	w8, #0x2a               // =42
    61ac:      	mov	w9, #0x6                // =6
    61b0:      	blr	x9
    61b4:      	b	0x5c80 <kprobe_unwind_perl+0x5c80>
    61b8:      	ldr	w8, [x23]
    61bc:      	cbz	w8, 0x45c4 <kprobe_unwind_perl+0x45c4>
    61c0:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    61c4:      	add	x8, x8, #0x0
    61c8:      	add	x0, sp, #0x30
    61cc:      	ldp	x9, x10, [x8, #0x10]
    61d0:      	mov	w1, #0x26               // =38
    61d4:      	stp	x9, x10, [sp, #0x40]
    61d8:      	ldur	x9, [x8, #0x1e]
    61dc:      	add	x10, sp, #0x30
    61e0:      	stur	x9, [sp, #0x4e]
    61e4:      	ldp	x8, x9, [x8]
    61e8:      	stp	x8, x9, [sp, #0x30]
    61ec:      	mov	w8, #0x26               // =38
    61f0:      	mov	w9, #0x6                // =6
    61f4:      	ldr	w2, [sp, #0x94]
    61f8:      	blr	x9
    61fc:      	b	0x45c4 <kprobe_unwind_perl+0x45c4>
    6200:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6204:      	add	x8, x8, #0x0
    6208:      	add	x0, sp, #0x30
    620c:      	ldp	x9, x10, [x8, #0x10]
    6210:      	mov	w1, #0x28               // =40
    6214:      	mov	x3, x24
    6218:      	stp	x9, x10, [sp, #0x40]
    621c:      	ldr	x9, [x8, #0x20]
    6220:      	add	x10, sp, #0x30
    6224:      	str	x9, [sp, #0x50]
    6228:      	ldp	x8, x9, [x8]
    622c:      	stp	x8, x9, [sp, #0x30]
    6230:      	mov	w8, #0x28               // =40
    6234:      	mov	w9, #0x6                // =6
    6238:      	ldr	x2, [sp, #0x8]
    623c:      	blr	x9
    6240:      	ldr	w8, [x21, #0x2c0]
    6244:      	cmp	w8, #0x7e
    6248:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    624c:      	b	0x3500 <kprobe_unwind_perl+0x3500>
    6250:      	add	x8, sp, #0x98
    6254:      	ldr	x24, [x8]
    6258:      	cbz	x24, 0x36b4 <kprobe_unwind_perl+0x36b4>
    625c:      	ldr	x8, [sp, #0x10]
    6260:      	ldr	x8, [x8]
    6264:      	str	x8, [sp, #0x8]
    6268:      	ldr	w8, [x23]
    626c:      	cbnz	w8, 0x6b18 <kprobe_unwind_perl+0x6b18>
    6270:      	ldr	w8, [x21, #0x2c0]
    6274:      	cmp	w8, #0x7e
    6278:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    627c:      	add	w9, w8, #0x1
    6280:      	ldr	x10, [sp, #0x8]
    6284:      	str	w9, [x21, #0x2c0]
    6288:      	mov	w9, #0x18               // =24
    628c:      	umaddl	x8, w8, w9, x21
    6290:      	add	x9, x8, #0x2d0
    6294:      	str	x10, [x8, #0x2d8]
    6298:      	mov	w10, #0x7               // =7
    629c:      	str	x24, [x8, #0x2d0]
    62a0:      	str	wzr, [x8, #0x2e4]
    62a4:      	str	xzr, [x21, #0xf30]
    62a8:      	strb	w10, [x8, #0x2e0]
    62ac:      	stur	wzr, [x9, #0x11]
    62b0:      	b	0x3eac <kprobe_unwind_perl+0x3eac>
    62b4:      	mov	w8, #0x786c             // =30828
    62b8:      	add	x10, sp, #0x30
    62bc:      	add	x0, sp, #0x30
    62c0:      	mov	w1, #0x14               // =20
    62c4:      	movk	w8, #0xa, lsl #16
    62c8:      	str	w8, [sp, #0x40]
    62cc:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    62d0:      	add	x8, x8, #0x0
    62d4:      	ldp	x9, x8, [x8]
    62d8:      	stp	x9, x8, [sp, #0x30]
    62dc:      	mov	w8, #0x14               // =20
    62e0:      	mov	w9, #0x6                // =6
    62e4:      	ldr	x2, [sp, #0x80]
    62e8:      	blr	x9
    62ec:      	add	x8, sp, #0x80
    62f0:      	ldr	x8, [x8]
    62f4:      	ldr	x24, [sp, #0x10]
    62f8:      	str	x8, [sp, #0x8]
    62fc:      	cbnz	x8, 0x34e8 <kprobe_unwind_perl+0x34e8>
    6300:      	b	0x131c <kprobe_unwind_perl+0x131c>
    6304:      	mov	w8, #0x786c             // =30828
    6308:      	add	x10, sp, #0x30
    630c:      	add	x0, sp, #0x30
    6310:      	mov	w1, #0x13               // =19
    6314:      	movk	w8, #0xa, lsl #16
    6318:      	stur	w8, [sp, #0x3f]
    631c:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6320:      	add	x8, x8, #0x0
    6324:      	ldp	x9, x8, [x8]
    6328:      	stp	x9, x8, [sp, #0x30]
    632c:      	mov	w8, #0x13               // =19
    6330:      	mov	w9, #0x6                // =6
    6334:      	ldr	x2, [sp, #0x98]
    6338:      	blr	x9
    633c:      	ldr	x8, [sp, #0x98]
    6340:      	b	0x2ab8 <kprobe_unwind_perl+0x2ab8>
    6344:      	ldr	w8, [x23]
    6348:      	cbz	w8, 0x5c78 <kprobe_unwind_perl+0x5c78>
    634c:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6350:      	add	x8, x8, #0x0
    6354:      	add	x0, sp, #0x30
    6358:      	ldp	x9, x10, [x8, #0x10]
    635c:      	mov	w1, #0x26               // =38
    6360:      	stp	x9, x10, [sp, #0x40]
    6364:      	ldur	x9, [x8, #0x1e]
    6368:      	add	x10, sp, #0x30
    636c:      	stur	x9, [sp, #0x4e]
    6370:      	ldp	x8, x9, [x8]
    6374:      	stp	x8, x9, [sp, #0x30]
    6378:      	mov	w8, #0x26               // =38
    637c:      	mov	w9, #0x6                // =6
    6380:      	ldr	w2, [sp, #0xb8]
    6384:      	ldr	w3, [sp, #0xa4]
    6388:      	blr	x9
    638c:      	b	0x5c78 <kprobe_unwind_perl+0x5c78>
    6390:      	mov	w8, #0xa                // =10
    6394:      	add	x10, sp, #0x30
    6398:      	add	x0, sp, #0x30
    639c:      	strh	w8, [sp, #0x40]
    63a0:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    63a4:      	add	x8, x8, #0x0
    63a8:      	mov	w1, #0x12               // =18
    63ac:      	ldp	x9, x8, [x8]
    63b0:      	stp	x9, x8, [sp, #0x30]
    63b4:      	mov	w8, #0x12               // =18
    63b8:      	mov	w9, #0x6                // =6
    63bc:      	ldrb	w2, [sp, #0x7c]
    63c0:      	blr	x9
    63c4:      	ldrb	w8, [sp, #0x7c]
    63c8:      	and	w9, w8, #0xf
    63cc:      	sub	w10, w9, #0x9
    63d0:      	cmp	w10, #0x2
    63d4:      	b.lo	0x5d58 <kprobe_unwind_perl+0x5d58>
    63d8:      	cmp	w9, #0xc
    63dc:      	b.ne	0x6478 <kprobe_unwind_perl+0x6478>
    63e0:      	mov	w29, #0x3               // =3
    63e4:      	ldrb	w8, [x22, #0x1d]
    63e8:      	ldr	x9, [x21, #0xf40]
    63ec:      	adrp	x0, 0x6000 <kprobe_unwind_perl+0x6000>
    63f0:      	add	x1, sp, #0xa8
    63f4:      	sub	x8, x9, x8
    63f8:      	add	x9, sp, #0xa8
    63fc:      	str	x8, [x21, #0xf40]
    6400:      	mov	w8, #0x10               // =16
    6404:      	str	w8, [sp, #0xa8]
    6408:      	mov	w8, #0x1                // =1
    640c:      	ldr	x0, [x0]
    6410:      	blr	x8
    6414:      	cbz	x0, 0x6428 <kprobe_unwind_perl+0x6428>
    6418:      	ldr	x8, [x0]
    641c:      	add	x8, x8, #0x1
    6420:      	str	x8, [x0]
    6424:      	b	0x2ed0 <kprobe_unwind_perl+0x2ed0>
    6428:      	ldr	w8, [x23]
    642c:      	cbz	w8, 0x2ed0 <kprobe_unwind_perl+0x2ed0>
    6430:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6434:      	add	x8, x8, #0x0
    6438:      	add	x0, sp, #0x30
    643c:      	ldp	x9, x10, [x8, #0x10]
    6440:      	mov	w1, #0x2e               // =46
    6444:      	stp	x9, x10, [sp, #0x40]
    6448:      	ldr	x9, [x8, #0x20]
    644c:      	add	x10, sp, #0x30
    6450:      	str	x9, [sp, #0x50]
    6454:      	ldur	x9, [x8, #0x26]
    6458:      	stur	x9, [sp, #0x56]
    645c:      	ldp	x9, x8, [x8]
    6460:      	stp	x9, x8, [sp, #0x30]
    6464:      	mov	w8, #0x2e               // =46
    6468:      	mov	w9, #0x6                // =6
    646c:      	ldr	w2, [sp, #0xa8]
    6470:      	blr	x9
    6474:      	b	0x2ed0 <kprobe_unwind_perl+0x2ed0>
    6478:      	ldr	x8, [sp, #0x10]
    647c:      	mov	w29, #0x3               // =3
    6480:      	ldr	x8, [x8]
    6484:      	cbnz	x8, 0x63e4 <kprobe_unwind_perl+0x63e4>
    6488:      	ldrb	w8, [x22, #0x1a]
    648c:      	mov	w9, #0x8                // =8
    6490:      	mov	w10, #0x70              // =112
    6494:      	ldr	x0, [sp, #0x10]
    6498:      	mov	w1, #0x8                // =8
    649c:      	add	x8, x25, x8
    64a0:      	ldrb	w8, [x22, #0x1a]
    64a4:      	add	x2, x25, x8
    64a8:      	blr	x10
    64ac:      	cbnz	x0, 0x5c78 <kprobe_unwind_perl+0x5c78>
    64b0:      	ldr	w8, [x23]
    64b4:      	cbz	w8, 0x63e4 <kprobe_unwind_perl+0x63e4>
    64b8:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    64bc:      	add	x8, x8, #0x0
    64c0:      	add	x0, sp, #0x30
    64c4:      	ldp	x9, x10, [x8]
    64c8:      	mov	w1, #0x1e               // =30
    64cc:      	stp	x9, x10, [sp, #0x30]
    64d0:      	ldr	x9, [x8, #0x10]
    64d4:      	ldur	x8, [x8, #0x16]
    64d8:      	add	x10, sp, #0x30
    64dc:      	str	x9, [sp, #0x40]
    64e0:      	stur	x8, [sp, #0x46]
    64e4:      	mov	w8, #0x1e               // =30
    64e8:      	mov	w9, #0x6                // =6
    64ec:      	ldr	x8, [sp, #0x10]
    64f0:      	ldr	x2, [x8]
    64f4:      	blr	x9
    64f8:      	b	0x63e4 <kprobe_unwind_perl+0x63e4>
    64fc:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6500:      	add	x8, x8, #0x0
    6504:      	add	x0, sp, #0x30
    6508:      	ldp	x9, x10, [x8, #0x10]
    650c:      	mov	w1, #0x2d               // =45
    6510:      	stp	x9, x10, [sp, #0x40]
    6514:      	ldr	x9, [x8, #0x20]
    6518:      	add	x10, sp, #0x30
    651c:      	str	x9, [sp, #0x50]
    6520:      	ldur	x9, [x8, #0x25]
    6524:      	stur	x9, [sp, #0x55]
    6528:      	ldp	x9, x8, [x8]
    652c:      	stp	x9, x8, [sp, #0x30]
    6530:      	mov	w8, #0x2d               // =45
    6534:      	mov	w9, #0x6                // =6
    6538:      	blr	x9
    653c:      	b	0x474c <kprobe_unwind_perl+0x474c>
    6540:      	ldr	w8, [x23]
    6544:      	cbz	w8, 0x4e3c <kprobe_unwind_perl+0x4e3c>
    6548:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    654c:      	add	x8, x8, #0x0
    6550:      	add	x0, sp, #0x30
    6554:      	ldp	x9, x10, [x8, #0x10]
    6558:      	mov	w1, #0x26               // =38
    655c:      	stp	x9, x10, [sp, #0x40]
    6560:      	ldur	x9, [x8, #0x1e]
    6564:      	add	x10, sp, #0x30
    6568:      	stur	x9, [sp, #0x4e]
    656c:      	ldp	x8, x9, [x8]
    6570:      	stp	x8, x9, [sp, #0x30]
    6574:      	mov	w8, #0x26               // =38
    6578:      	mov	w9, #0x6                // =6
    657c:      	ldr	w2, [sp, #0x94]
    6580:      	blr	x9
    6584:      	b	0x4e3c <kprobe_unwind_perl+0x4e3c>
    6588:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    658c:      	add	x8, x8, #0x0
    6590:      	add	x0, sp, #0x30
    6594:      	ldp	x9, x10, [x8, #0x10]
    6598:      	mov	w1, #0x28               // =40
    659c:      	mov	x3, x24
    65a0:      	stp	x9, x10, [sp, #0x40]
    65a4:      	ldr	x9, [x8, #0x20]
    65a8:      	add	x10, sp, #0x30
    65ac:      	str	x9, [sp, #0x50]
    65b0:      	ldp	x8, x9, [x8]
    65b4:      	stp	x8, x9, [sp, #0x30]
    65b8:      	mov	w8, #0x28               // =40
    65bc:      	mov	w9, #0x6                // =6
    65c0:      	ldr	x2, [sp, #0x8]
    65c4:      	blr	x9
    65c8:      	ldr	w8, [x21, #0x2c0]
    65cc:      	cmp	w8, #0x7e
    65d0:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    65d4:      	b	0x3ca8 <kprobe_unwind_perl+0x3ca8>
    65d8:      	add	x8, sp, #0x98
    65dc:      	ldr	x24, [x8]
    65e0:      	cbz	x24, 0x3e5c <kprobe_unwind_perl+0x3e5c>
    65e4:      	ldr	x8, [sp, #0x10]
    65e8:      	ldr	x8, [x8]
    65ec:      	str	x8, [sp, #0x8]
    65f0:      	ldr	w8, [x23]
    65f4:      	cbnz	w8, 0x6ba8 <kprobe_unwind_perl+0x6ba8>
    65f8:      	ldr	w8, [x21, #0x2c0]
    65fc:      	cmp	w8, #0x7e
    6600:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    6604:      	add	w9, w8, #0x1
    6608:      	ldr	x10, [sp, #0x8]
    660c:      	str	w9, [x21, #0x2c0]
    6610:      	mov	w9, #0x18               // =24
    6614:      	umaddl	x8, w8, w9, x21
    6618:      	add	x9, x8, #0x2d0
    661c:      	str	x10, [x8, #0x2d8]
    6620:      	mov	w10, #0x7               // =7
    6624:      	str	x24, [x8, #0x2d0]
    6628:      	str	wzr, [x8, #0x2e4]
    662c:      	str	xzr, [x21, #0xf30]
    6630:      	strb	w10, [x8, #0x2e0]
    6634:      	stur	wzr, [x9, #0x11]
    6638:      	b	0x4614 <kprobe_unwind_perl+0x4614>
    663c:      	mov	w8, #0x786c             // =30828
    6640:      	add	x10, sp, #0x30
    6644:      	add	x0, sp, #0x30
    6648:      	mov	w1, #0x14               // =20
    664c:      	movk	w8, #0xa, lsl #16
    6650:      	str	w8, [sp, #0x40]
    6654:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6658:      	add	x8, x8, #0x0
    665c:      	ldp	x9, x8, [x8]
    6660:      	stp	x9, x8, [sp, #0x30]
    6664:      	mov	w8, #0x14               // =20
    6668:      	mov	w9, #0x6                // =6
    666c:      	ldr	x2, [sp, #0x80]
    6670:      	blr	x9
    6674:      	add	x8, sp, #0x80
    6678:      	ldr	x8, [x8]
    667c:      	ldr	x24, [sp, #0x10]
    6680:      	str	x8, [sp, #0x8]
    6684:      	cbnz	x8, 0x3c90 <kprobe_unwind_perl+0x3c90>
    6688:      	b	0x1a74 <kprobe_unwind_perl+0x1a74>
    668c:      	mov	w8, #0x786c             // =30828
    6690:      	add	x10, sp, #0x30
    6694:      	add	x0, sp, #0x30
    6698:      	mov	w1, #0x13               // =19
    669c:      	movk	w8, #0xa, lsl #16
    66a0:      	stur	w8, [sp, #0x3f]
    66a4:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    66a8:      	add	x8, x8, #0x0
    66ac:      	ldp	x9, x8, [x8]
    66b0:      	stp	x9, x8, [sp, #0x30]
    66b4:      	mov	w8, #0x13               // =19
    66b8:      	mov	w9, #0x6                // =6
    66bc:      	ldr	x2, [sp, #0x98]
    66c0:      	blr	x9
    66c4:      	ldr	x8, [sp, #0x98]
    66c8:      	b	0x31d0 <kprobe_unwind_perl+0x31d0>
    66cc:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    66d0:      	add	x8, x8, #0x0
    66d4:      	add	x0, sp, #0x30
    66d8:      	ldp	x9, x10, [x8, #0x10]
    66dc:      	mov	w1, #0x2d               // =45
    66e0:      	stp	x9, x10, [sp, #0x40]
    66e4:      	ldr	x9, [x8, #0x20]
    66e8:      	add	x10, sp, #0x30
    66ec:      	str	x9, [sp, #0x50]
    66f0:      	ldur	x9, [x8, #0x25]
    66f4:      	stur	x9, [sp, #0x55]
    66f8:      	ldp	x9, x8, [x8]
    66fc:      	stp	x9, x8, [sp, #0x30]
    6700:      	mov	w8, #0x2d               // =45
    6704:      	mov	w9, #0x6                // =6
    6708:      	blr	x9
    670c:      	b	0x4fc4 <kprobe_unwind_perl+0x4fc4>
    6710:      	ldr	w8, [x23]
    6714:      	cbz	w8, 0x5c78 <kprobe_unwind_perl+0x5c78>
    6718:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    671c:      	add	x8, x8, #0x0
    6720:      	add	x0, sp, #0x30
    6724:      	ldp	x9, x10, [x8, #0x10]
    6728:      	mov	w1, #0x26               // =38
    672c:      	stp	x9, x10, [sp, #0x40]
    6730:      	ldur	x9, [x8, #0x1e]
    6734:      	add	x10, sp, #0x30
    6738:      	stur	x9, [sp, #0x4e]
    673c:      	ldp	x8, x9, [x8]
    6740:      	stp	x8, x9, [sp, #0x30]
    6744:      	mov	w8, #0x26               // =38
    6748:      	mov	w9, #0x6                // =6
    674c:      	ldr	w2, [sp, #0x94]
    6750:      	blr	x9
    6754:      	b	0x5c78 <kprobe_unwind_perl+0x5c78>
    6758:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    675c:      	add	x8, x8, #0x0
    6760:      	add	x0, sp, #0x30
    6764:      	ldp	x9, x10, [x8, #0x10]
    6768:      	mov	w1, #0x28               // =40
    676c:      	mov	x3, x24
    6770:      	stp	x9, x10, [sp, #0x40]
    6774:      	ldr	x9, [x8, #0x20]
    6778:      	add	x10, sp, #0x30
    677c:      	str	x9, [sp, #0x50]
    6780:      	ldp	x8, x9, [x8]
    6784:      	stp	x8, x9, [sp, #0x30]
    6788:      	mov	w8, #0x28               // =40
    678c:      	mov	w9, #0x6                // =6
    6790:      	ldr	x2, [sp, #0x8]
    6794:      	blr	x9
    6798:      	ldr	w8, [x21, #0x2c0]
    679c:      	cmp	w8, #0x7e
    67a0:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    67a4:      	b	0x4410 <kprobe_unwind_perl+0x4410>
    67a8:      	add	x8, sp, #0x98
    67ac:      	ldr	x24, [x8]
    67b0:      	cbz	x24, 0x45c4 <kprobe_unwind_perl+0x45c4>
    67b4:      	ldr	x8, [sp, #0x10]
    67b8:      	ldr	x8, [x8]
    67bc:      	str	x8, [sp, #0x8]
    67c0:      	ldr	w8, [x23]
    67c4:      	cbnz	w8, 0x6c38 <kprobe_unwind_perl+0x6c38>
    67c8:      	ldr	w8, [x21, #0x2c0]
    67cc:      	cmp	w8, #0x7e
    67d0:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    67d4:      	add	w9, w8, #0x1
    67d8:      	ldr	x10, [sp, #0x8]
    67dc:      	str	w9, [x21, #0x2c0]
    67e0:      	mov	w9, #0x18               // =24
    67e4:      	umaddl	x8, w8, w9, x21
    67e8:      	add	x9, x8, #0x2d0
    67ec:      	str	x10, [x8, #0x2d8]
    67f0:      	mov	w10, #0x7               // =7
    67f4:      	str	x24, [x8, #0x2d0]
    67f8:      	str	wzr, [x8, #0x2e4]
    67fc:      	str	xzr, [x21, #0xf30]
    6800:      	strb	w10, [x8, #0x2e0]
    6804:      	stur	wzr, [x9, #0x11]
    6808:      	b	0x4e8c <kprobe_unwind_perl+0x4e8c>
    680c:      	mov	w8, #0x786c             // =30828
    6810:      	add	x10, sp, #0x30
    6814:      	add	x0, sp, #0x30
    6818:      	mov	w1, #0x14               // =20
    681c:      	movk	w8, #0xa, lsl #16
    6820:      	str	w8, [sp, #0x40]
    6824:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6828:      	add	x8, x8, #0x0
    682c:      	ldp	x9, x8, [x8]
    6830:      	stp	x9, x8, [sp, #0x30]
    6834:      	mov	w8, #0x14               // =20
    6838:      	mov	w9, #0x6                // =6
    683c:      	ldr	x2, [sp, #0x80]
    6840:      	blr	x9
    6844:      	add	x8, sp, #0x80
    6848:      	ldr	x8, [x8]
    684c:      	ldr	x24, [sp, #0x10]
    6850:      	str	x8, [sp, #0x8]
    6854:      	cbnz	x8, 0x43f8 <kprobe_unwind_perl+0x43f8>
    6858:      	b	0x2100 <kprobe_unwind_perl+0x2100>
    685c:      	mov	w8, #0x786c             // =30828
    6860:      	add	x10, sp, #0x30
    6864:      	add	x0, sp, #0x30
    6868:      	mov	w1, #0x13               // =19
    686c:      	movk	w8, #0xa, lsl #16
    6870:      	stur	w8, [sp, #0x3f]
    6874:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6878:      	add	x8, x8, #0x0
    687c:      	ldp	x9, x8, [x8]
    6880:      	stp	x9, x8, [sp, #0x30]
    6884:      	mov	w8, #0x13               // =19
    6888:      	mov	w9, #0x6                // =6
    688c:      	ldr	x2, [sp, #0x98]
    6890:      	blr	x9
    6894:      	ldr	x8, [sp, #0x98]
    6898:      	b	0x397c <kprobe_unwind_perl+0x397c>
    689c:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    68a0:      	add	x8, x8, #0x0
    68a4:      	add	x0, sp, #0x30
    68a8:      	ldp	x9, x10, [x8, #0x10]
    68ac:      	mov	w1, #0x2d               // =45
    68b0:      	stp	x9, x10, [sp, #0x40]
    68b4:      	ldr	x9, [x8, #0x20]
    68b8:      	add	x10, sp, #0x30
    68bc:      	str	x9, [sp, #0x50]
    68c0:      	ldur	x9, [x8, #0x25]
    68c4:      	stur	x9, [sp, #0x55]
    68c8:      	ldp	x9, x8, [x8]
    68cc:      	stp	x9, x8, [sp, #0x30]
    68d0:      	mov	w8, #0x2d               // =45
    68d4:      	mov	w9, #0x6                // =6
    68d8:      	blr	x9
    68dc:      	b	0x5e00 <kprobe_unwind_perl+0x5e00>
    68e0:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    68e4:      	add	x8, x8, #0x0
    68e8:      	add	x0, sp, #0x30
    68ec:      	ldp	x9, x10, [x8, #0x10]
    68f0:      	mov	w1, #0x28               // =40
    68f4:      	mov	x3, x24
    68f8:      	stp	x9, x10, [sp, #0x40]
    68fc:      	ldr	x9, [x8, #0x20]
    6900:      	add	x10, sp, #0x30
    6904:      	str	x9, [sp, #0x50]
    6908:      	ldp	x8, x9, [x8]
    690c:      	stp	x8, x9, [sp, #0x30]
    6910:      	mov	w8, #0x28               // =40
    6914:      	mov	w9, #0x6                // =6
    6918:      	ldr	x2, [sp, #0x8]
    691c:      	blr	x9
    6920:      	ldr	w8, [x21, #0x2c0]
    6924:      	cmp	w8, #0x7e
    6928:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    692c:      	b	0x4bfc <kprobe_unwind_perl+0x4bfc>
    6930:      	add	x8, sp, #0x98
    6934:      	ldr	x24, [x8]
    6938:      	cbz	x24, 0x4e3c <kprobe_unwind_perl+0x4e3c>
    693c:      	ldr	x8, [sp, #0x10]
    6940:      	ldr	x8, [x8]
    6944:      	str	x8, [sp, #0x8]
    6948:      	ldr	w8, [x23]
    694c:      	cbnz	w8, 0x6c88 <kprobe_unwind_perl+0x6c88>
    6950:      	ldr	w8, [x21, #0x2c0]
    6954:      	cmp	w8, #0x7e
    6958:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    695c:      	add	w9, w8, #0x1
    6960:      	ldr	x10, [sp, #0x8]
    6964:      	str	w9, [x21, #0x2c0]
    6968:      	mov	w9, #0x18               // =24
    696c:      	umaddl	x8, w8, w9, x21
    6970:      	add	x9, x8, #0x2d0
    6974:      	str	x10, [x8, #0x2d8]
    6978:      	mov	w10, #0x7               // =7
    697c:      	str	x24, [x8, #0x2d0]
    6980:      	str	wzr, [x8, #0x2e4]
    6984:      	str	xzr, [x21, #0xf30]
    6988:      	strb	w10, [x8, #0x2e0]
    698c:      	stur	wzr, [x9, #0x11]
    6990:      	b	0x5cc8 <kprobe_unwind_perl+0x5cc8>
    6994:      	mov	w8, #0x786c             // =30828
    6998:      	add	x10, sp, #0x30
    699c:      	add	x0, sp, #0x30
    69a0:      	mov	w1, #0x14               // =20
    69a4:      	movk	w8, #0xa, lsl #16
    69a8:      	str	w8, [sp, #0x40]
    69ac:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    69b0:      	add	x8, x8, #0x0
    69b4:      	ldp	x9, x8, [x8]
    69b8:      	stp	x9, x8, [sp, #0x30]
    69bc:      	mov	w8, #0x14               // =20
    69c0:      	mov	w9, #0x6                // =6
    69c4:      	ldr	x2, [sp, #0x80]
    69c8:      	blr	x9
    69cc:      	add	x8, sp, #0x80
    69d0:      	ldr	x8, [x8]
    69d4:      	ldr	x24, [sp, #0x10]
    69d8:      	str	x8, [sp, #0x8]
    69dc:      	cbnz	x8, 0x4be4 <kprobe_unwind_perl+0x4be4>
    69e0:      	b	0x27f8 <kprobe_unwind_perl+0x27f8>
    69e4:      	mov	w8, #0x786c             // =30828
    69e8:      	add	x10, sp, #0x30
    69ec:      	add	x0, sp, #0x30
    69f0:      	mov	w1, #0x13               // =19
    69f4:      	movk	w8, #0xa, lsl #16
    69f8:      	stur	w8, [sp, #0x3f]
    69fc:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6a00:      	add	x8, x8, #0x0
    6a04:      	ldp	x9, x8, [x8]
    6a08:      	stp	x9, x8, [sp, #0x30]
    6a0c:      	mov	w8, #0x13               // =19
    6a10:      	mov	w9, #0x6                // =6
    6a14:      	ldr	x2, [sp, #0x98]
    6a18:      	blr	x9
    6a1c:      	ldr	x8, [sp, #0x98]
    6a20:      	b	0x4124 <kprobe_unwind_perl+0x4124>
    6a24:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6a28:      	add	x8, x8, #0x0
    6a2c:      	add	x0, sp, #0x30
    6a30:      	ldp	x9, x10, [x8, #0x10]
    6a34:      	mov	w1, #0x28               // =40
    6a38:      	mov	x2, x24
    6a3c:      	stp	x9, x10, [sp, #0x40]
    6a40:      	ldr	x9, [x8, #0x20]
    6a44:      	add	x10, sp, #0x30
    6a48:      	str	x9, [sp, #0x50]
    6a4c:      	ldp	x8, x9, [x8]
    6a50:      	stp	x8, x9, [sp, #0x30]
    6a54:      	mov	w8, #0x28               // =40
    6a58:      	mov	w9, #0x6                // =6
    6a5c:      	ldr	x3, [sp, #0x8]
    6a60:      	blr	x9
    6a64:      	ldr	w8, [x21, #0x2c0]
    6a68:      	cmp	w8, #0x7e
    6a6c:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    6a70:      	b	0x5488 <kprobe_unwind_perl+0x5488>
    6a74:      	add	x8, sp, #0x98
    6a78:      	ldr	x24, [x8]
    6a7c:      	cbz	x24, 0x5c78 <kprobe_unwind_perl+0x5c78>
    6a80:      	ldr	x8, [sp, #0x10]
    6a84:      	ldr	x8, [x8]
    6a88:      	str	x8, [sp, #0x8]
    6a8c:      	ldr	w8, [x23]
    6a90:      	cbnz	w8, 0x6cd8 <kprobe_unwind_perl+0x6cd8>
    6a94:      	ldr	w8, [x21, #0x2c0]
    6a98:      	cmp	w8, #0x7e
    6a9c:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    6aa0:      	add	w9, w8, #0x1
    6aa4:      	ldr	x10, [sp, #0x8]
    6aa8:      	str	w9, [x21, #0x2c0]
    6aac:      	mov	w9, #0x18               // =24
    6ab0:      	umaddl	x8, w8, w9, x21
    6ab4:      	add	x9, x8, #0x2d0
    6ab8:      	str	x10, [x8, #0x2d8]
    6abc:      	mov	w10, #0x7               // =7
    6ac0:      	str	x24, [x8, #0x2d0]
    6ac4:      	str	wzr, [x8, #0x2e4]
    6ac8:      	str	xzr, [x21, #0xf30]
    6acc:      	strb	w10, [x8, #0x2e0]
    6ad0:      	stur	wzr, [x9, #0x11]
    6ad4:      	b	0x6488 <kprobe_unwind_perl+0x6488>
    6ad8:      	mov	w8, #0x786c             // =30828
    6adc:      	add	x10, sp, #0x30
    6ae0:      	add	x0, sp, #0x30
    6ae4:      	mov	w1, #0x13               // =19
    6ae8:      	movk	w8, #0xa, lsl #16
    6aec:      	stur	w8, [sp, #0x3f]
    6af0:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6af4:      	add	x8, x8, #0x0
    6af8:      	ldp	x9, x8, [x8]
    6afc:      	stp	x9, x8, [sp, #0x30]
    6b00:      	mov	w8, #0x13               // =19
    6b04:      	mov	w9, #0x6                // =6
    6b08:      	ldr	x2, [sp, #0x98]
    6b0c:      	blr	x9
    6b10:      	ldr	x8, [sp, #0x98]
    6b14:      	b	0x488c <kprobe_unwind_perl+0x488c>
    6b18:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6b1c:      	add	x8, x8, #0x0
    6b20:      	add	x0, sp, #0x30
    6b24:      	ldp	x9, x10, [x8, #0x10]
    6b28:      	mov	w1, #0x28               // =40
    6b2c:      	mov	x2, x24
    6b30:      	stp	x9, x10, [sp, #0x40]
    6b34:      	ldr	x9, [x8, #0x20]
    6b38:      	add	x10, sp, #0x30
    6b3c:      	str	x9, [sp, #0x50]
    6b40:      	ldp	x8, x9, [x8]
    6b44:      	stp	x8, x9, [sp, #0x30]
    6b48:      	mov	w8, #0x28               // =40
    6b4c:      	mov	w9, #0x6                // =6
    6b50:      	ldr	x3, [sp, #0x8]
    6b54:      	blr	x9
    6b58:      	ldr	w8, [x21, #0x2c0]
    6b5c:      	cmp	w8, #0x7e
    6b60:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    6b64:      	b	0x627c <kprobe_unwind_perl+0x627c>
    6b68:      	mov	w8, #0x786c             // =30828
    6b6c:      	add	x10, sp, #0x30
    6b70:      	add	x0, sp, #0x30
    6b74:      	mov	w1, #0x13               // =19
    6b78:      	movk	w8, #0xa, lsl #16
    6b7c:      	stur	w8, [sp, #0x3f]
    6b80:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6b84:      	add	x8, x8, #0x0
    6b88:      	ldp	x9, x8, [x8]
    6b8c:      	stp	x9, x8, [sp, #0x30]
    6b90:      	mov	w8, #0x13               // =19
    6b94:      	mov	w9, #0x6                // =6
    6b98:      	ldr	x2, [sp, #0x98]
    6b9c:      	blr	x9
    6ba0:      	ldr	x8, [sp, #0x98]
    6ba4:      	b	0x5104 <kprobe_unwind_perl+0x5104>
    6ba8:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6bac:      	add	x8, x8, #0x0
    6bb0:      	add	x0, sp, #0x30
    6bb4:      	ldp	x9, x10, [x8, #0x10]
    6bb8:      	mov	w1, #0x28               // =40
    6bbc:      	mov	x2, x24
    6bc0:      	stp	x9, x10, [sp, #0x40]
    6bc4:      	ldr	x9, [x8, #0x20]
    6bc8:      	add	x10, sp, #0x30
    6bcc:      	str	x9, [sp, #0x50]
    6bd0:      	ldp	x8, x9, [x8]
    6bd4:      	stp	x8, x9, [sp, #0x30]
    6bd8:      	mov	w8, #0x28               // =40
    6bdc:      	mov	w9, #0x6                // =6
    6be0:      	ldr	x3, [sp, #0x8]
    6be4:      	blr	x9
    6be8:      	ldr	w8, [x21, #0x2c0]
    6bec:      	cmp	w8, #0x7e
    6bf0:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    6bf4:      	b	0x6604 <kprobe_unwind_perl+0x6604>
    6bf8:      	mov	w8, #0x786c             // =30828
    6bfc:      	add	x10, sp, #0x30
    6c00:      	add	x0, sp, #0x30
    6c04:      	mov	w1, #0x13               // =19
    6c08:      	movk	w8, #0xa, lsl #16
    6c0c:      	stur	w8, [sp, #0x3f]
    6c10:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6c14:      	add	x8, x8, #0x0
    6c18:      	ldp	x9, x8, [x8]
    6c1c:      	stp	x9, x8, [sp, #0x30]
    6c20:      	mov	w8, #0x13               // =19
    6c24:      	mov	w9, #0x6                // =6
    6c28:      	ldr	x2, [sp, #0x98]
    6c2c:      	blr	x9
    6c30:      	ldr	x8, [sp, #0x98]
    6c34:      	b	0x5f40 <kprobe_unwind_perl+0x5f40>
    6c38:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6c3c:      	add	x8, x8, #0x0
    6c40:      	add	x0, sp, #0x30
    6c44:      	ldp	x9, x10, [x8, #0x10]
    6c48:      	mov	w1, #0x28               // =40
    6c4c:      	mov	x2, x24
    6c50:      	stp	x9, x10, [sp, #0x40]
    6c54:      	ldr	x9, [x8, #0x20]
    6c58:      	add	x10, sp, #0x30
    6c5c:      	str	x9, [sp, #0x50]
    6c60:      	ldp	x8, x9, [x8]
    6c64:      	stp	x8, x9, [sp, #0x30]
    6c68:      	mov	w8, #0x28               // =40
    6c6c:      	mov	w9, #0x6                // =6
    6c70:      	ldr	x3, [sp, #0x8]
    6c74:      	blr	x9
    6c78:      	ldr	w8, [x21, #0x2c0]
    6c7c:      	cmp	w8, #0x7e
    6c80:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    6c84:      	b	0x67d4 <kprobe_unwind_perl+0x67d4>
    6c88:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6c8c:      	add	x8, x8, #0x0
    6c90:      	add	x0, sp, #0x30
    6c94:      	ldp	x9, x10, [x8, #0x10]
    6c98:      	mov	w1, #0x28               // =40
    6c9c:      	mov	x2, x24
    6ca0:      	stp	x9, x10, [sp, #0x40]
    6ca4:      	ldr	x9, [x8, #0x20]
    6ca8:      	add	x10, sp, #0x30
    6cac:      	str	x9, [sp, #0x50]
    6cb0:      	ldp	x8, x9, [x8]
    6cb4:      	stp	x8, x9, [sp, #0x30]
    6cb8:      	mov	w8, #0x28               // =40
    6cbc:      	mov	w9, #0x6                // =6
    6cc0:      	ldr	x3, [sp, #0x8]
    6cc4:      	blr	x9
    6cc8:      	ldr	w8, [x21, #0x2c0]
    6ccc:      	cmp	w8, #0x7e
    6cd0:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    6cd4:      	b	0x695c <kprobe_unwind_perl+0x695c>
    6cd8:      	adrp	x8, 0x6000 <kprobe_unwind_perl+0x6000>
    6cdc:      	add	x8, x8, #0x0
    6ce0:      	add	x0, sp, #0x30
    6ce4:      	ldp	x9, x10, [x8, #0x10]
    6ce8:      	mov	w1, #0x28               // =40
    6cec:      	mov	x2, x24
    6cf0:      	stp	x9, x10, [sp, #0x40]
    6cf4:      	ldr	x9, [x8, #0x20]
    6cf8:      	add	x10, sp, #0x30
    6cfc:      	str	x9, [sp, #0x50]
    6d00:      	ldp	x8, x9, [x8]
    6d04:      	stp	x8, x9, [sp, #0x30]
    6d08:      	mov	w8, #0x28               // =40
    6d0c:      	mov	w9, #0x6                // =6
    6d10:      	ldr	x3, [sp, #0x8]
    6d14:      	blr	x9
    6d18:      	ldr	w8, [x21, #0x2c0]
    6d1c:      	cmp	w8, #0x7e
    6d20:      	b.hi	0x2680 <kprobe_unwind_perl+0x2680>
    6d24:      	b	0x6aa0 <kprobe_unwind_perl+0x6aa0>
