
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/otel/custom_trace.native.o:	file format elf64-littleaarch64

Disassembly of section uprobe/custom__generic:

0000000000000000 <custom__generic>:
       0:      	str	x29, [sp, #-0x50]!
       4:      	stp	x30, x25, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	sub	sp, sp, #0x1b0
      18:      	mov	w8, #0xe                // =14
      1c:      	mov	x19, x0
      20:      	blr	x8
      24:      	mov	x23, x0
      28:      	lsr	x22, x0, #32
      2c:      	cmp	w23, #0x0
      30:      	ccmp	w22, #0x0, #0x4, ne
      34:      	b.ne	0x40 <custom__generic+0x40>
      38:      	mov	w0, wzr
      3c:      	b	0x510 <custom__generic+0x510>
      40:      	mov	w8, #0x5                // =5
      44:      	blr	x8
      48:      	mov	x24, x0
      4c:      	str	wzr, [sp, #0x14]
      50:      	adrp	x0, 0x0 <custom__generic>
      54:      	mov	w8, #0x1                // =1
      58:      	ldr	x0, [x0]
      5c:      	add	x9, sp, #0x14
      60:      	add	x1, sp, #0x14
      64:      	blr	x8
      68:      	cbz	x0, 0x74 <custom__generic+0x74>
      6c:      	ldr	x29, [x0]
      70:      	b	0x78 <custom__generic+0x78>
      74:      	mov	x29, xzr
      78:      	str	wzr, [sp, #0x18]
      7c:      	adrp	x20, 0x0 <custom__generic>
      80:      	mov	w8, #0x1                // =1
      84:      	add	x9, sp, #0x18
      88:      	ldr	x20, [x20]
      8c:      	add	x1, sp, #0x18
      90:      	mov	x0, x20
      94:      	blr	x8
      98:      	cbz	x0, 0xac <custom__generic+0xac>
      9c:      	mov	w8, #0x1374             // =4980
      a0:      	ldrb	w9, [x0, x8]
      a4:      	add	w9, w9, #0x1
      a8:      	strb	w9, [x0, x8]
      ac:      	adrp	x25, 0x0 <custom__generic>
      b0:      	ldr	x25, [x25]
      b4:      	ldr	w8, [x25]
      b8:      	cbnz	w8, 0x300 <custom__generic+0x300>
      bc:      	str	wzr, [sp, #0x18]
      c0:      	mov	w8, #0x1                // =1
      c4:      	add	x9, sp, #0x18
      c8:      	add	x1, sp, #0x18
      cc:      	mov	x0, x20
      d0:      	blr	x8
      d4:      	cbz	x0, 0x50c <custom__generic+0x50c>
      d8:      	mov	w8, #-0x1               // =-1
      dc:      	mov	w9, #0x100              // =256
      e0:      	mov	x21, x0
      e4:      	strh	wzr, [x0, #0xf20]
      e8:      	str	xzr, [x0, #0xed0]
      ec:      	mov	w1, wzr
      f0:      	str	xzr, [x0, #0xed8]
      f4:      	str	xzr, [x0, #0xee0]
      f8:      	mov	w2, #0x29c              // =668
      fc:      	str	xzr, [x0, #0xee8]
     100:      	str	xzr, [x0, #0xef0]
     104:      	str	xzr, [x0, #0xef8]
     108:      	str	x8, [x0, #0xf18]
     10c:      	str	wzr, [x0, #0x1370]
     110:      	strh	w9, [x0, #0x1374]
     114:      	add	x9, x0, #0x2bc
     118:      	str	xzr, [x0, #0xf28]
     11c:      	str	xzr, [x0, #0xf30]
     120:      	str	xzr, [x0, #0xf48]
     124:      	str	xzr, [x0, #0xf50]
     128:      	str	xzr, [x0, #0xf58]
     12c:      	str	xzr, [x0, #0xf60]
     130:      	str	xzr, [x0, #0xf68]
     134:      	add	x0, x0, #0x20
     138:      	str	x8, [x9]
     13c:      	bl	0x13c <custom__generic+0x13c>
     140:      	mov	w8, #0x4                // =4
     144:      	stp	w22, w23, [x21]
     148:      	str	x24, [x21, #0x8]
     14c:      	add	x0, x21, #0x10
     150:      	mov	w1, #0x10               // =16
     154:      	str	w8, [x21, #0x2c4]
     158:      	str	x29, [x21, #0x2c8]
     15c:      	mov	w8, #0x10               // =16
     160:      	blr	x8
     164:      	tbz	w0, #0x1f, 0x1a4 <custom__generic+0x1a4>
     168:      	mov	w8, #0x34               // =52
     16c:      	adrp	x0, 0x0 <custom__generic>
     170:      	add	x9, sp, #0x168
     174:      	str	w8, [sp, #0x168]
     178:      	mov	w8, #0x1                // =1
     17c:      	add	x1, sp, #0x168
     180:      	ldr	x0, [x0]
     184:      	blr	x8
     188:      	cbz	x0, 0x19c <custom__generic+0x19c>
     18c:      	ldr	x8, [x0]
     190:      	add	x8, x8, #0x1
     194:      	str	x8, [x0]
     198:      	b	0x1a4 <custom__generic+0x1a4>
     19c:      	ldr	w8, [x25]
     1a0:      	cbnz	w8, 0x9e8 <custom__generic+0x9e8>
     1a4:      	adrp	x1, 0x0 <custom__generic>
     1a8:      	mov	w8, #0x400              // =1024
     1ac:      	mov	w9, #0x1b               // =27
     1b0:      	ldr	x1, [x1]
     1b4:      	mov	x0, x19
     1b8:      	mov	w2, #0x400              // =1024
     1bc:      	blr	x9
     1c0:      	ldr	w8, [x25]
     1c4:      	str	w0, [x21, #0x2bc]
     1c8:      	cbnz	w8, 0x334 <custom__generic+0x334>
     1cc:      	ldr	x8, [x19, #0x108]
     1d0:      	add	x29, sp, #0x168
     1d4:      	tst	x8, #0xf
     1d8:      	b.eq	0x378 <custom__generic+0x378>
     1dc:      	mov	w8, #0x23               // =35
     1e0:      	add	x24, sp, #0x18
     1e4:      	blr	x8
     1e8:      	adrp	x8, 0x0 <custom__generic>
     1ec:      	mov	w9, #0x71               // =113
     1f0:      	add	x10, sp, #0x18
     1f4:      	ldr	x8, [x8]
     1f8:      	mov	w1, #0x8                // =8
     1fc:      	ldr	w8, [x8]
     200:      	add	x2, x0, x8
     204:      	mov	w8, #0x8                // =8
     208:      	add	x0, sp, #0x18
     20c:      	blr	x9
     210:      	cbnz	x0, 0x248 <custom__generic+0x248>
     214:      	adrp	x9, 0x0 <custom__generic>
     218:      	ldr	x8, [sp, #0x18]
     21c:      	ldr	x9, [x9]
     220:      	ldr	w9, [x9]
     224:      	add	x2, x8, x9
     228:      	cbz	x2, 0x248 <custom__generic+0x248>
     22c:      	mov	w8, #0x150              // =336
     230:      	mov	w9, #0x71               // =113
     234:      	add	x10, sp, #0x18
     238:      	add	x0, sp, #0x18
     23c:      	mov	w1, #0x150              // =336
     240:      	blr	x9
     244:      	cbz	x0, 0x290 <custom__generic+0x290>
     248:      	mov	w8, #0x52               // =82
     24c:      	adrp	x0, 0x0 <custom__generic>
     250:      	add	x9, sp, #0x1a0
     254:      	str	w8, [sp, #0x1a0]
     258:      	mov	w8, #0x1                // =1
     25c:      	add	x1, sp, #0x1a0
     260:      	ldr	x0, [x0]
     264:      	blr	x8
     268:      	cbz	x0, 0x27c <custom__generic+0x27c>
     26c:      	ldr	x8, [x0]
     270:      	add	x8, x8, #0x1
     274:      	str	x8, [x0]
     278:      	b	0x284 <custom__generic+0x284>
     27c:      	ldr	w8, [x25]
     280:      	cbnz	w8, 0x9a0 <custom__generic+0x9a0>
     284:      	mov	w22, wzr
     288:      	mov	w8, #0xfa9              // =4009
     28c:      	b	0x43c <custom__generic+0x43c>
     290:      	ldr	x8, [x24, #0x108]
     294:      	tst	x8, #0xf
     298:      	b.eq	0x2a8 <custom__generic+0x2a8>
     29c:      	mov	w22, wzr
     2a0:      	mov	w8, wzr
     2a4:      	b	0x43c <custom__generic+0x43c>
     2a8:      	tbnz	w8, #0x4, 0x434 <custom__generic+0x434>
     2ac:      	ldp	x9, x8, [x24, #0xf0]
     2b0:      	str	x8, [x21, #0xed8]
     2b4:      	ldp	x10, x8, [x24, #0xe0]
     2b8:      	str	x8, [x21, #0xee0]
     2bc:      	ldr	x8, [x24, #0xb0]
     2c0:      	str	x10, [x21, #0xef8]
     2c4:      	str	x8, [x21, #0xef0]
     2c8:      	adrp	x8, 0x0 <custom__generic>
     2cc:      	ldr	x8, [x8]
     2d0:      	ldr	x10, [x24, #0x100]
     2d4:      	strb	wzr, [x21, #0xf21]
     2d8:      	ldr	x8, [x8]
     2dc:      	and	x10, x8, x10
     2e0:      	and	x8, x9, x8
     2e4:      	str	x8, [x21, #0xee8]
     2e8:      	ldr	w8, [sp, #0x130]
     2ec:      	str	x10, [x21, #0xed0]
     2f0:      	cmn	w8, #0x1
     2f4:      	cset	w8, ne
     2f8:      	strb	w8, [x21, #0xf20]
     2fc:      	b	0x3c4 <custom__generic+0x3c4>
     300:      	adrp	x8, 0x0 <custom__generic>
     304:      	add	x8, x8, #0x0
     308:      	add	x0, sp, #0x18
     30c:      	ldp	x9, x10, [x8]
     310:      	ldur	x8, [x8, #0xe]
     314:      	mov	w1, #0x16               // =22
     318:      	stp	x9, x10, [sp, #0x18]
     31c:      	stur	x8, [sp, #0x26]
     320:      	mov	w8, #0x16               // =22
     324:      	mov	w9, #0x6                // =6
     328:      	add	x10, sp, #0x18
     32c:      	blr	x9
     330:      	b	0xbc <custom__generic+0xbc>
     334:      	adrp	x8, 0x0 <custom__generic>
     338:      	add	x8, x8, #0x0
     33c:      	add	x0, sp, #0x18
     340:      	ldp	x9, x10, [x8]
     344:      	ldur	x8, [x8, #0xe]
     348:      	mov	w1, #0x16               // =22
     34c:      	stp	x9, x10, [sp, #0x18]
     350:      	stur	x8, [sp, #0x26]
     354:      	mov	w8, #0x16               // =22
     358:      	mov	w9, #0x6                // =6
     35c:      	add	x10, sp, #0x18
     360:      	ldr	w2, [x21, #0x2bc]
     364:      	blr	x9
     368:      	ldr	x8, [x19, #0x108]
     36c:      	add	x29, sp, #0x168
     370:      	tst	x8, #0xf
     374:      	b.ne	0x1dc <custom__generic+0x1dc>
     378:      	tbnz	w8, #0x4, 0x434 <custom__generic+0x434>
     37c:      	adrp	x8, 0x0 <custom__generic>
     380:      	ldr	x8, [x8]
     384:      	ldr	x9, [x19, #0x100]
     388:      	ldr	x8, [x8]
     38c:      	and	x9, x8, x9
     390:      	str	x9, [x21, #0xed0]
     394:      	ldr	x9, [x19, #0xf8]
     398:      	str	x9, [x21, #0xed8]
     39c:      	ldr	x9, [x19, #0xe8]
     3a0:      	str	x9, [x21, #0xee0]
     3a4:      	ldr	x9, [x19, #0xf0]
     3a8:      	and	x8, x9, x8
     3ac:      	str	x8, [x21, #0xee8]
     3b0:      	ldr	x8, [x19, #0xb0]
     3b4:      	str	x8, [x21, #0xef0]
     3b8:      	ldr	x8, [x19, #0xe0]
     3bc:      	strh	wzr, [x21, #0xf20]
     3c0:      	str	x8, [x21, #0xef8]
     3c4:      	ldr	w8, [x25]
     3c8:      	cbnz	w8, 0x958 <custom__generic+0x958>
     3cc:      	mov	w8, #0x60               // =96
     3d0:      	rev	w9, w22
     3d4:      	str	xzr, [sp, #0x20]
     3d8:      	adrp	x24, 0x0 <custom__generic>
     3dc:      	stp	w8, w9, [sp, #0x18]
     3e0:      	mov	w8, #0x1                // =1
     3e4:      	add	x9, sp, #0x18
     3e8:      	add	x1, sp, #0x18
     3ec:      	ldr	x24, [x24]
     3f0:      	mov	x0, x24
     3f4:      	blr	x8
     3f8:      	cbz	x0, 0x52c <custom__generic+0x52c>
     3fc:      	add	x8, x21, #0xed0
     400:      	ldr	x23, [x8]
     404:      	ldr	w8, [x25]
     408:      	cbz	x23, 0x5c8 <custom__generic+0x5c8>
     40c:      	cbnz	w8, 0xa78 <custom__generic+0xa78>
     410:      	lsr	x8, x23, #56
     414:      	cbz	x8, 0xac4 <custom__generic+0xac4>
     418:      	ldr	w8, [x25]
     41c:      	cbnz	w8, 0xc80 <custom__generic+0xc80>
     420:      	mov	w8, #0xb                // =11
     424:      	mov	w22, wzr
     428:      	str	w8, [x21, #0xf18]
     42c:      	mov	w8, #0xfab              // =4011
     430:      	b	0x43c <custom__generic+0x43c>
     434:      	mov	w22, wzr
     438:      	mov	w8, #0xfb0              // =4016
     43c:      	str	w8, [x21, #0xf1c]
     440:      	str	wzr, [sp, #0x18]
     444:      	mov	w8, #0x1                // =1
     448:      	add	x9, sp, #0x18
     44c:      	add	x1, sp, #0x18
     450:      	mov	x0, x20
     454:      	blr	x8
     458:      	cbz	x0, 0x4b0 <custom__generic+0x4b0>
     45c:      	mov	w20, #0x1374            // =4980
     460:      	mov	w2, w22
     464:      	ldrb	w8, [x0, x20]
     468:      	cmp	w8, #0x1d
     46c:      	b.lo	0x4dc <custom__generic+0x4dc>
     470:      	mov	w8, #0x5                // =5
     474:      	mov	x21, x0
     478:      	add	x9, sp, #0x168
     47c:      	str	w8, [x0, #0xf1c]
     480:      	mov	w8, #0x44               // =68
     484:      	adrp	x0, 0x0 <custom__generic>
     488:      	add	x1, sp, #0x168
     48c:      	str	w8, [sp, #0x168]
     490:      	mov	w8, #0x1                // =1
     494:      	ldr	x0, [x0]
     498:      	blr	x8
     49c:      	cbz	x0, 0x4c8 <custom__generic+0x4c8>
     4a0:      	ldr	x8, [x0]
     4a4:      	add	x8, x8, #0x1
     4a8:      	str	x8, [x0]
     4ac:      	b	0x4d0 <custom__generic+0x4d0>
     4b0:      	adrp	x10, 0x0 <custom__generic>
     4b4:      	mov	x9, xzr
     4b8:      	mov	w8, #0xc                // =12
     4bc:      	ldr	x10, [x10]
     4c0:      	mov	w2, wzr
     4c4:      	b	0x4f4 <custom__generic+0x4f4>
     4c8:      	ldr	w8, [x25]
     4cc:      	cbnz	w8, 0xa30 <custom__generic+0xa30>
     4d0:      	ldrb	w8, [x21, x20]
     4d4:      	mov	w2, wzr
     4d8:      	mov	x0, x21
     4dc:      	add	w8, w8, #0x1
     4e0:      	adrp	x10, 0x0 <custom__generic>
     4e4:      	mov	w9, w2
     4e8:      	strb	w8, [x0, x20]
     4ec:      	mov	w8, #0xc                // =12
     4f0:      	ldr	x10, [x10]
     4f4:      	adrp	x1, 0x0 <custom__generic>
     4f8:      	mov	x0, x19
     4fc:      	ldr	x1, [x1]
     500:      	blr	x8
     504:      	ldr	w8, [x25]
     508:      	cbnz	w8, 0x90c <custom__generic+0x90c>
     50c:      	mov	w0, #-0x1               // =-1
     510:      	add	sp, sp, #0x1b0
     514:      	ldp	x20, x19, [sp, #0x40]
     518:      	ldp	x22, x21, [sp, #0x30]
     51c:      	ldp	x24, x23, [sp, #0x20]
     520:      	ldp	x30, x25, [sp, #0x10]
     524:      	ldr	x29, [sp], #0x50
     528:      	ret
     52c:      	str	x23, [x29, #0x38]
     530:      	str	w22, [sp, #0x1a8]
     534:      	adrp	x20, 0x0 <custom__generic>
     538:      	mov	w8, #0x1                // =1
     53c:      	add	x9, sp, #0x1a8
     540:      	add	x1, sp, #0x1a8
     544:      	ldr	x20, [x20]
     548:      	mov	x0, x20
     54c:      	blr	x8
     550:      	mov	w8, #0x5                // =5
     554:      	mov	x21, x0
     558:      	blr	x8
     55c:      	cbz	x21, 0x61c <custom__generic+0x61c>
     560:      	ldr	x8, [x21]
     564:      	mov	w11, #0xe100            // =57600
     568:      	movk	w11, #0x5f5, lsl #16
     56c:      	and	x9, x8, #0xffffffffffffffe0
     570:      	and	x10, x8, #0xf
     574:      	sub	x9, x0, x9
     578:      	lsl	x10, x11, x10
     57c:      	cmp	x9, x10
     580:      	b.hs	0x5e0 <custom__generic+0x5e0>
     584:      	ldr	w8, [x25]
     588:      	cbz	w8, 0x38 <custom__generic+0x38>
     58c:      	adrp	x8, 0x0 <custom__generic>
     590:      	add	x8, x8, #0x0
     594:      	add	x0, sp, #0x18
     598:      	ldp	x9, x10, [x8]
     59c:      	mov	w1, #0x20               // =32
     5a0:      	stp	x9, x10, [sp, #0x18]
     5a4:      	ldp	x9, x8, [x8, #0x10]
     5a8:      	add	x10, sp, #0x18
     5ac:      	stp	x9, x8, [sp, #0x28]
     5b0:      	mov	w8, #0x20               // =32
     5b4:      	mov	w9, #0x6                // =6
     5b8:      	ldr	w2, [sp, #0x1a8]
     5bc:      	blr	x9
     5c0:      	mov	w0, wzr
     5c4:      	b	0x510 <custom__generic+0x510>
     5c8:      	cbnz	w8, 0xc40 <custom__generic+0xc40>
     5cc:      	mov	w8, #0x1                // =1
     5d0:      	mov	w22, wzr
     5d4:      	str	w8, [x21, #0xf18]
     5d8:      	mov	w8, #0xfad              // =4013
     5dc:      	b	0x43c <custom__generic+0x43c>
     5e0:      	mov	x11, #0xf200            // =61952
     5e4:      	and	w21, w8, #0x10
     5e8:      	movk	x11, #0x2a05, lsl #16
     5ec:      	movk	x11, #0x1, lsl #32
     5f0:      	add	x10, x10, x11
     5f4:      	cmp	x9, x10
     5f8:      	b.hs	0x61c <custom__generic+0x61c>
     5fc:      	cmp	w21, #0x0
     600:      	mov	w9, #0x4                // =4
     604:      	mov	w10, #0x8               // =8
     608:      	and	w8, w8, #0xf
     60c:      	csel	w9, w10, w9, eq
     610:      	cmp	w9, w8
     614:      	cinc	w23, w8, hi
     618:      	b	0x620 <custom__generic+0x620>
     61c:      	mov	w23, wzr
     620:      	ldr	w8, [x25]
     624:      	cbnz	w8, 0xbf4 <custom__generic+0xbf4>
     628:      	mov	w9, w21
     62c:      	and	x10, x23, #0xff
     630:      	and	x8, x0, #0xffffffffffffffe0
     634:      	mov	x3, xzr
     638:      	add	x1, sp, #0x1a8
     63c:      	add	x2, sp, #0x168
     640:      	mov	x0, x20
     644:      	orr	x9, x9, x10
     648:      	add	x10, sp, #0x168
     64c:      	orr	x8, x8, x9
     650:      	str	x8, [x29]
     654:      	mov	w8, #0x2                // =2
     658:      	add	x9, sp, #0x1a8
     65c:      	blr	x8
     660:      	cbz	w0, 0x6d4 <custom__generic+0x6d4>
     664:      	ldr	w8, [x25]
     668:      	cbnz	w8, 0xcc0 <custom__generic+0xcc0>
     66c:      	mov	w8, #0x3d               // =61
     670:      	adrp	x0, 0x0 <custom__generic>
     674:      	add	x9, sp, #0x1ac
     678:      	str	w8, [sp, #0x1ac]
     67c:      	mov	w8, #0x1                // =1
     680:      	add	x1, sp, #0x1ac
     684:      	ldr	x0, [x0]
     688:      	blr	x8
     68c:      	cbnz	x0, 0x730 <custom__generic+0x730>
     690:      	ldr	w8, [x25]
     694:      	cbz	w8, 0x38 <custom__generic+0x38>
     698:      	adrp	x8, 0x0 <custom__generic>
     69c:      	add	x8, x8, #0x0
     6a0:      	ldp	x9, x10, [x8, #0x10]
     6a4:      	stp	x9, x10, [sp, #0x28]
     6a8:      	ldr	x9, [x8, #0x20]
     6ac:      	add	x10, sp, #0x18
     6b0:      	str	x9, [sp, #0x38]
     6b4:      	ldur	x9, [x8, #0x26]
     6b8:      	stur	x9, [sp, #0x3e]
     6bc:      	ldp	x9, x8, [x8]
     6c0:      	stp	x9, x8, [sp, #0x18]
     6c4:      	mov	w8, #0x2e               // =46
     6c8:      	mov	w9, #0x6                // =6
     6cc:      	ldr	w2, [sp, #0x1ac]
     6d0:      	b	0x7e4 <custom__generic+0x7e4>
     6d4:      	mov	w20, #0x1               // =1
     6d8:      	adrp	x0, 0x0 <custom__generic>
     6dc:      	mov	x3, xzr
     6e0:      	strb	w20, [sp, #0x19c]
     6e4:      	mov	w8, #0x2                // =2
     6e8:      	add	x9, sp, #0x1a0
     6ec:      	add	x10, sp, #0x19c
     6f0:      	ldr	x0, [x0]
     6f4:      	add	x1, sp, #0x1a0
     6f8:      	add	x2, sp, #0x19c
     6fc:      	blr	x8
     700:      	cbz	w0, 0x740 <custom__generic+0x740>
     704:      	ldr	w8, [x25]
     708:      	cbnz	w8, 0xde4 <custom__generic+0xde4>
     70c:      	mov	w8, #0x3e               // =62
     710:      	adrp	x0, 0x0 <custom__generic>
     714:      	add	x9, sp, #0x168
     718:      	str	w8, [sp, #0x168]
     71c:      	mov	w8, #0x1                // =1
     720:      	add	x1, sp, #0x168
     724:      	ldr	x0, [x0]
     728:      	blr	x8
     72c:      	cbz	x0, 0x7a4 <custom__generic+0x7a4>
     730:      	ldr	x8, [x0]
     734:      	add	x8, x8, #0x1
     738:      	str	x8, [x0]
     73c:      	b	0x38 <custom__generic+0x38>
     740:      	str	w20, [sp, #0x1ac]
     744:      	strb	w20, [sp, #0x1a8]
     748:      	adrp	x0, 0x0 <custom__generic>
     74c:      	mov	w8, #0x2                // =2
     750:      	add	x9, sp, #0x1ac
     754:      	add	x10, sp, #0x1a8
     758:      	ldr	x0, [x0]
     75c:      	add	x1, sp, #0x1ac
     760:      	add	x2, sp, #0x1a8
     764:      	mov	w3, #0x1                // =1
     768:      	blr	x8
     76c:      	tbnz	w0, #0x1f, 0x7f8 <custom__generic+0x7f8>
     770:      	mov	w8, #0x42               // =66
     774:      	adrp	x0, 0x0 <custom__generic>
     778:      	add	x9, sp, #0x168
     77c:      	str	w8, [sp, #0x168]
     780:      	mov	w8, #0x1                // =1
     784:      	add	x1, sp, #0x168
     788:      	ldr	x0, [x0]
     78c:      	blr	x8
     790:      	cbz	x0, 0x83c <custom__generic+0x83c>
     794:      	ldr	x8, [x0]
     798:      	add	x8, x8, #0x1
     79c:      	str	x8, [x0]
     7a0:      	b	0x844 <custom__generic+0x844>
     7a4:      	ldr	w8, [x25]
     7a8:      	cbz	w8, 0x38 <custom__generic+0x38>
     7ac:      	adrp	x8, 0x0 <custom__generic>
     7b0:      	add	x8, x8, #0x0
     7b4:      	ldp	x9, x10, [x8, #0x10]
     7b8:      	stp	x9, x10, [sp, #0x28]
     7bc:      	ldr	x9, [x8, #0x20]
     7c0:      	add	x10, sp, #0x18
     7c4:      	str	x9, [sp, #0x38]
     7c8:      	ldur	x9, [x8, #0x26]
     7cc:      	stur	x9, [sp, #0x3e]
     7d0:      	ldp	x9, x8, [x8]
     7d4:      	stp	x9, x8, [sp, #0x18]
     7d8:      	mov	w8, #0x2e               // =46
     7dc:      	mov	w9, #0x6                // =6
     7e0:      	ldr	w2, [sp, #0x168]
     7e4:      	add	x0, sp, #0x18
     7e8:      	mov	w1, #0x2e               // =46
     7ec:      	blr	x9
     7f0:      	mov	w0, wzr
     7f4:      	b	0x510 <custom__generic+0x510>
     7f8:      	ldr	w8, [x25]
     7fc:      	cbz	w8, 0x884 <custom__generic+0x884>
     800:      	adrp	x8, 0x0 <custom__generic>
     804:      	add	x8, x8, #0x0
     808:      	strb	wzr, [sp, #0x30]
     80c:      	add	x0, sp, #0x18
     810:      	ldp	x9, x10, [x8]
     814:      	ldr	x8, [x8, #0x10]
     818:      	mov	w1, #0x19               // =25
     81c:      	mov	w2, #0x1                // =1
     820:      	str	x8, [sp, #0x28]
     824:      	stp	x9, x10, [sp, #0x18]
     828:      	mov	w8, #0x19               // =25
     82c:      	mov	w9, #0x6                // =6
     830:      	add	x10, sp, #0x18
     834:      	blr	x9
     838:      	b	0x884 <custom__generic+0x884>
     83c:      	ldr	w8, [x25]
     840:      	cbnz	w8, 0xecc <custom__generic+0xecc>
     844:      	mov	w8, #0x1                // =1
     848:      	adrp	x1, 0x0 <custom__generic>
     84c:      	mov	w9, #0x4                // =4
     850:      	str	w8, [sp, #0x168]
     854:      	mov	w8, #-0x1               // =-1
     858:      	mov	w10, #0x19              // =25
     85c:      	add	x11, sp, #0x168
     860:      	ldr	x1, [x1]
     864:      	add	x3, sp, #0x168
     868:      	mov	x0, x19
     86c:      	mov	w2, #-0x1               // =-1
     870:      	mov	w4, #0x4                // =4
     874:      	blr	x10
     878:      	tbz	w0, #0x1f, 0x884 <custom__generic+0x884>
     87c:      	ldr	w8, [x25]
     880:      	cbnz	w8, 0xe80 <custom__generic+0xe80>
     884:      	mov	w8, #0x3f               // =63
     888:      	adrp	x0, 0x0 <custom__generic>
     88c:      	add	x9, sp, #0x168
     890:      	str	w8, [sp, #0x168]
     894:      	mov	w8, #0x1                // =1
     898:      	add	x1, sp, #0x168
     89c:      	ldr	x0, [x0]
     8a0:      	blr	x8
     8a4:      	cbz	x0, 0x8bc <custom__generic+0x8bc>
     8a8:      	ldr	x8, [x0]
     8ac:      	add	x8, x8, #0x1
     8b0:      	str	x8, [x0]
     8b4:      	mov	w0, wzr
     8b8:      	b	0x510 <custom__generic+0x510>
     8bc:      	ldr	w8, [x25]
     8c0:      	cbz	w8, 0x38 <custom__generic+0x38>
     8c4:      	adrp	x8, 0x0 <custom__generic>
     8c8:      	add	x8, x8, #0x0
     8cc:      	add	x0, sp, #0x18
     8d0:      	ldp	x9, x10, [x8, #0x10]
     8d4:      	mov	w1, #0x2e               // =46
     8d8:      	stp	x9, x10, [sp, #0x28]
     8dc:      	ldr	x9, [x8, #0x20]
     8e0:      	add	x10, sp, #0x18
     8e4:      	str	x9, [sp, #0x38]
     8e8:      	ldur	x9, [x8, #0x26]
     8ec:      	stur	x9, [sp, #0x3e]
     8f0:      	ldp	x9, x8, [x8]
     8f4:      	stp	x9, x8, [sp, #0x18]
     8f8:      	mov	w8, #0x2e               // =46
     8fc:      	mov	w9, #0x6                // =6
     900:      	ldr	w2, [sp, #0x168]
     904:      	blr	x9
     908:      	b	0x38 <custom__generic+0x38>
     90c:      	mov	w8, #0x7972             // =31090
     910:      	add	x0, sp, #0x18
     914:      	mov	w1, #0x34               // =52
     918:      	mov	w2, w22
     91c:      	movk	w8, #0xa, lsl #16
     920:      	str	w8, [sp, #0x48]
     924:      	adrp	x8, 0x0 <custom__generic>
     928:      	add	x8, x8, #0x0
     92c:      	ldp	x9, x10, [x8, #0x10]
     930:      	stp	x9, x10, [sp, #0x28]
     934:      	ldp	x9, x10, [x8, #0x20]
     938:      	stp	x9, x10, [sp, #0x38]
     93c:      	ldp	x9, x8, [x8]
     940:      	add	x10, sp, #0x18
     944:      	stp	x9, x8, [sp, #0x18]
     948:      	mov	w8, #0x34               // =52
     94c:      	mov	w9, #0x6                // =6
     950:      	blr	x9
     954:      	b	0x50c <custom__generic+0x50c>
     958:      	adrp	x8, 0x0 <custom__generic>
     95c:      	add	x8, x8, #0x0
     960:      	add	x0, sp, #0x18
     964:      	ldp	x9, x10, [x8, #0x10]
     968:      	mov	w1, #0x27               // =39
     96c:      	stp	x9, x10, [sp, #0x28]
     970:      	ldur	x9, [x8, #0x1f]
     974:      	add	x10, sp, #0x18
     978:      	stur	x9, [sp, #0x37]
     97c:      	ldp	x8, x9, [x8]
     980:      	stp	x8, x9, [sp, #0x18]
     984:      	mov	w8, #0x27               // =39
     988:      	mov	w9, #0x6                // =6
     98c:      	ldr	x2, [x21, #0xed0]
     990:      	ldr	x3, [x21, #0xed8]
     994:      	ldr	x4, [x21, #0xee0]
     998:      	blr	x9
     99c:      	b	0x3cc <custom__generic+0x3cc>
     9a0:      	adrp	x8, 0x0 <custom__generic>
     9a4:      	add	x8, x8, #0x0
     9a8:      	add	x0, sp, #0x168
     9ac:      	ldp	x9, x10, [x8, #0x10]
     9b0:      	mov	w1, #0x2e               // =46
     9b4:      	stp	x9, x10, [x24, #0x160]
     9b8:      	ldr	x9, [x8, #0x20]
     9bc:      	add	x10, sp, #0x168
     9c0:      	str	x9, [x24, #0x170]
     9c4:      	ldur	x9, [x8, #0x26]
     9c8:      	stur	x9, [x29, #0x26]
     9cc:      	ldp	x9, x8, [x8]
     9d0:      	stp	x9, x8, [x29]
     9d4:      	mov	w8, #0x2e               // =46
     9d8:      	mov	w9, #0x6                // =6
     9dc:      	ldr	w2, [sp, #0x1a0]
     9e0:      	blr	x9
     9e4:      	b	0x284 <custom__generic+0x284>
     9e8:      	adrp	x8, 0x0 <custom__generic>
     9ec:      	add	x8, x8, #0x0
     9f0:      	add	x0, sp, #0x18
     9f4:      	ldp	x9, x10, [x8, #0x10]
     9f8:      	mov	w1, #0x2e               // =46
     9fc:      	stp	x9, x10, [sp, #0x28]
     a00:      	ldr	x9, [x8, #0x20]
     a04:      	add	x10, sp, #0x18
     a08:      	str	x9, [sp, #0x38]
     a0c:      	ldur	x9, [x8, #0x26]
     a10:      	stur	x9, [sp, #0x3e]
     a14:      	ldp	x9, x8, [x8]
     a18:      	stp	x9, x8, [sp, #0x18]
     a1c:      	mov	w8, #0x2e               // =46
     a20:      	mov	w9, #0x6                // =6
     a24:      	ldr	w2, [sp, #0x168]
     a28:      	blr	x9
     a2c:      	b	0x1a4 <custom__generic+0x1a4>
     a30:      	adrp	x8, 0x0 <custom__generic>
     a34:      	add	x8, x8, #0x0
     a38:      	add	x0, sp, #0x18
     a3c:      	ldp	x9, x10, [x8, #0x10]
     a40:      	mov	w1, #0x2e               // =46
     a44:      	stp	x9, x10, [sp, #0x28]
     a48:      	ldr	x9, [x8, #0x20]
     a4c:      	add	x10, sp, #0x18
     a50:      	str	x9, [sp, #0x38]
     a54:      	ldur	x9, [x8, #0x26]
     a58:      	stur	x9, [sp, #0x3e]
     a5c:      	ldp	x9, x8, [x8]
     a60:      	stp	x9, x8, [sp, #0x18]
     a64:      	mov	w8, #0x2e               // =46
     a68:      	mov	w9, #0x6                // =6
     a6c:      	ldr	w2, [sp, #0x168]
     a70:      	blr	x9
     a74:      	b	0x4d0 <custom__generic+0x4d0>
     a78:      	adrp	x8, 0x0 <custom__generic>
     a7c:      	add	x8, x8, #0x0
     a80:      	strb	wzr, [sp, #0x48]
     a84:      	add	x0, sp, #0x18
     a88:      	ldp	x9, x10, [x8, #0x10]
     a8c:      	mov	w1, #0x31               // =49
     a90:      	stp	x9, x10, [sp, #0x28]
     a94:      	ldp	x9, x10, [x8, #0x20]
     a98:      	stp	x9, x10, [sp, #0x38]
     a9c:      	ldp	x9, x8, [x8]
     aa0:      	add	x10, sp, #0x18
     aa4:      	stp	x9, x8, [sp, #0x18]
     aa8:      	mov	w8, #0x31               // =49
     aac:      	mov	w9, #0x6                // =6
     ab0:      	ldr	w2, [x21, #0x2c0]
     ab4:      	blr	x9
     ab8:      	ldr	x23, [x21, #0xed0]
     abc:      	lsr	x8, x23, #56
     ac0:      	cbnz	x8, 0x418 <custom__generic+0x418>
     ac4:      	cmp	x23, #0xfff
     ac8:      	b.hi	0xae8 <custom__generic+0xae8>
     acc:      	ldr	w8, [x25]
     ad0:      	cbnz	w8, 0xd04 <custom__generic+0xd04>
     ad4:      	mov	w8, #0x31               // =49
     ad8:      	mov	w22, wzr
     adc:      	str	w8, [x21, #0xf18]
     ae0:      	mov	w8, #0xfae              // =4014
     ae4:      	b	0x43c <custom__generic+0x43c>
     ae8:      	ldr	w8, [x21]
     aec:      	mov	w9, #0x60               // =96
     af0:      	add	x1, sp, #0x168
     af4:      	mov	x0, x24
     af8:      	str	w9, [sp, #0x168]
     afc:      	add	x9, sp, #0x168
     b00:      	rev	w8, w8
     b04:      	str	w8, [sp, #0x16c]
     b08:      	rev	x8, x23
     b0c:      	str	x8, [x29, #0x8]
     b10:      	mov	w8, #0x1                // =1
     b14:      	blr	x8
     b18:      	cbz	x0, 0xbd0 <custom__generic+0xbd0>
     b1c:      	ldr	x8, [x0, #0x8]
     b20:      	and	x9, x8, #0xffffffffffffff
     b24:      	lsr	x22, x8, #56
     b28:      	str	x9, [x21, #0xf10]
     b2c:      	ldr	x8, [x0]
     b30:      	str	x8, [x21, #0xf00]
     b34:      	sub	x8, x23, x9
     b38:      	str	x8, [x21, #0xf08]
     b3c:      	ldr	w8, [x25]
     b40:      	cbnz	w8, 0xd44 <custom__generic+0xd44>
     b44:      	cmp	w22, #0x1
     b48:      	b.ne	0x2a0 <custom__generic+0x2a0>
     b4c:      	ldr	x8, [x21, #0xf00]
     b50:      	adrp	x0, 0x0 <custom__generic>
     b54:      	ldr	x22, [x21, #0xf08]
     b58:      	mov	w9, #0x1                // =1
     b5c:      	add	x1, sp, #0x168
     b60:      	mov	w23, #0x1               // =1
     b64:      	str	x8, [x29]
     b68:      	add	x8, sp, #0x168
     b6c:      	ldr	x0, [x0]
     b70:      	blr	x9
     b74:      	cbz	x0, 0xbec <custom__generic+0xbec>
     b78:      	ldr	x8, [x0]
     b7c:      	cmp	x8, x22
     b80:      	b.hi	0xb90 <custom__generic+0xb90>
     b84:      	ldr	x8, [x0, #0x8]
     b88:      	cmp	x8, x22
     b8c:      	b.hs	0xba8 <custom__generic+0xba8>
     b90:      	ldr	x8, [x0, #0x10]
     b94:      	cmp	x8, x22
     b98:      	b.hi	0xbc8 <custom__generic+0xbc8>
     b9c:      	ldr	x8, [x0, #0x18]
     ba0:      	cmp	x8, x22
     ba4:      	b.lo	0xbc8 <custom__generic+0xbc8>
     ba8:      	ldr	w8, [x25]
     bac:      	cbnz	w8, 0xf14 <custom__generic+0xf14>
     bb0:      	ldrh	w8, [x0, #0x20]
     bb4:      	ldr	w9, [x21, #0x1370]
     bb8:      	lsr	w8, w9, w8
     bbc:      	tbz	w8, #0x0, 0xf68 <custom__generic+0xf68>
     bc0:      	ldr	w8, [x25]
     bc4:      	cbnz	w8, 0xfb4 <custom__generic+0xfb4>
     bc8:      	mov	w22, #0x1               // =1
     bcc:      	b	0x2a0 <custom__generic+0x2a0>
     bd0:      	ldr	w8, [x25]
     bd4:      	cbnz	w8, 0xe34 <custom__generic+0xe34>
     bd8:      	mov	w8, #0xc                // =12
     bdc:      	mov	w22, wzr
     be0:      	str	w8, [x21, #0xf18]
     be4:      	mov	w8, #0xfac              // =4012
     be8:      	b	0x43c <custom__generic+0x43c>
     bec:      	mov	w22, w23
     bf0:      	b	0x2a0 <custom__generic+0x2a0>
     bf4:      	adrp	x8, 0x0 <custom__generic>
     bf8:      	add	x8, x8, #0x0
     bfc:      	mov	x24, x0
     c00:      	ldp	x9, x10, [x8]
     c04:      	add	x0, sp, #0x18
     c08:      	and	w3, w23, #0xff
     c0c:      	mov	w1, #0x1f               // =31
     c10:      	stp	x9, x10, [sp, #0x18]
     c14:      	ldr	x9, [x8, #0x10]
     c18:      	ldur	x8, [x8, #0x17]
     c1c:      	add	x10, sp, #0x18
     c20:      	str	x9, [sp, #0x28]
     c24:      	stur	x8, [sp, #0x2f]
     c28:      	mov	w8, #0x1f               // =31
     c2c:      	mov	w9, #0x6                // =6
     c30:      	ldr	w2, [sp, #0x1a8]
     c34:      	blr	x9
     c38:      	mov	x0, x24
     c3c:      	b	0x628 <custom__generic+0x628>
     c40:      	adrp	x8, 0x0 <custom__generic>
     c44:      	add	x8, x8, #0x0
     c48:      	strb	wzr, [sp, #0x48]
     c4c:      	add	x0, sp, #0x18
     c50:      	ldp	x9, x10, [x8, #0x10]
     c54:      	mov	w1, #0x31               // =49
     c58:      	stp	x9, x10, [sp, #0x28]
     c5c:      	ldp	x9, x10, [x8, #0x20]
     c60:      	stp	x9, x10, [sp, #0x38]
     c64:      	ldp	x9, x8, [x8]
     c68:      	add	x10, sp, #0x18
     c6c:      	stp	x9, x8, [sp, #0x18]
     c70:      	mov	w8, #0x31               // =49
     c74:      	mov	w9, #0x6                // =6
     c78:      	blr	x9
     c7c:      	b	0x5cc <custom__generic+0x5cc>
     c80:      	mov	w8, #0xa                // =10
     c84:      	add	x0, sp, #0x18
     c88:      	mov	w1, #0x22               // =34
     c8c:      	strh	w8, [sp, #0x38]
     c90:      	adrp	x8, 0x0 <custom__generic>
     c94:      	add	x8, x8, #0x0
     c98:      	mov	x2, x23
     c9c:      	ldp	x9, x10, [x8]
     ca0:      	stp	x9, x10, [sp, #0x18]
     ca4:      	ldp	x9, x8, [x8, #0x10]
     ca8:      	add	x10, sp, #0x18
     cac:      	stp	x9, x8, [sp, #0x28]
     cb0:      	mov	w8, #0x22               // =34
     cb4:      	mov	w9, #0x6                // =6
     cb8:      	blr	x9
     cbc:      	b	0x420 <custom__generic+0x420>
     cc0:      	adrp	x8, 0x0 <custom__generic>
     cc4:      	add	x8, x8, #0x0
     cc8:      	mov	w3, w0
     ccc:      	ldp	x9, x10, [x8]
     cd0:      	add	x0, sp, #0x18
     cd4:      	mov	w1, #0x1d               // =29
     cd8:      	stp	x9, x10, [sp, #0x18]
     cdc:      	ldr	x9, [x8, #0x10]
     ce0:      	ldur	x8, [x8, #0x15]
     ce4:      	add	x10, sp, #0x18
     ce8:      	str	x9, [sp, #0x28]
     cec:      	stur	x8, [sp, #0x2d]
     cf0:      	mov	w8, #0x1d               // =29
     cf4:      	mov	w9, #0x6                // =6
     cf8:      	ldr	w2, [sp, #0x1a8]
     cfc:      	blr	x9
     d00:      	b	0x66c <custom__generic+0x66c>
     d04:      	adrp	x8, 0x0 <custom__generic>
     d08:      	add	x8, x8, #0x0
     d0c:      	add	x0, sp, #0x18
     d10:      	ldp	x9, x10, [x8]
     d14:      	mov	w1, #0x1e               // =30
     d18:      	mov	x2, x23
     d1c:      	stp	x9, x10, [sp, #0x18]
     d20:      	ldr	x9, [x8, #0x10]
     d24:      	ldur	x8, [x8, #0x16]
     d28:      	add	x10, sp, #0x18
     d2c:      	str	x9, [sp, #0x28]
     d30:      	stur	x8, [sp, #0x2e]
     d34:      	mov	w8, #0x1e               // =30
     d38:      	mov	w9, #0x6                // =6
     d3c:      	blr	x9
     d40:      	b	0xad4 <custom__generic+0xad4>
     d44:      	mov	w8, #0xa                // =10
     d48:      	add	x0, sp, #0x18
     d4c:      	mov	w1, #0x32               // =50
     d50:      	strh	w8, [sp, #0x48]
     d54:      	adrp	x8, 0x0 <custom__generic>
     d58:      	add	x8, x8, #0x0
     d5c:      	mov	x2, x23
     d60:      	ldp	x9, x10, [x8, #0x10]
     d64:      	mov	w4, w22
     d68:      	stp	x9, x10, [sp, #0x28]
     d6c:      	ldp	x9, x10, [x8, #0x20]
     d70:      	stp	x9, x10, [sp, #0x38]
     d74:      	ldp	x9, x8, [x8]
     d78:      	add	x10, sp, #0x18
     d7c:      	stp	x9, x8, [sp, #0x18]
     d80:      	mov	w8, #0x32               // =50
     d84:      	mov	w9, #0x6                // =6
     d88:      	ldr	x3, [x21, #0xf00]
     d8c:      	blr	x9
     d90:      	ldr	w8, [x25]
     d94:      	cbz	w8, 0xb44 <custom__generic+0xb44>
     d98:      	adrp	x8, 0x0 <custom__generic>
     d9c:      	add	x8, x8, #0x0
     da0:      	add	x0, sp, #0x18
     da4:      	ldp	x9, x10, [x8, #0x10]
     da8:      	mov	w1, #0x2f               // =47
     dac:      	stp	x9, x10, [sp, #0x28]
     db0:      	ldr	x9, [x8, #0x20]
     db4:      	add	x10, sp, #0x18
     db8:      	str	x9, [sp, #0x38]
     dbc:      	ldur	x9, [x8, #0x27]
     dc0:      	stur	x9, [sp, #0x3f]
     dc4:      	ldp	x9, x8, [x8]
     dc8:      	stp	x9, x8, [sp, #0x18]
     dcc:      	mov	w8, #0x2f               // =47
     dd0:      	mov	w9, #0x6                // =6
     dd4:      	ldr	x2, [x21, #0xf10]
     dd8:      	ldr	x3, [x21, #0xf08]
     ddc:      	blr	x9
     de0:      	b	0xb44 <custom__generic+0xb44>
     de4:      	adrp	x8, 0x0 <custom__generic>
     de8:      	add	x8, x8, #0x0
     dec:      	ldr	w3, [sp, #0x1a0]
     df0:      	mov	w4, w0
     df4:      	ldp	x9, x10, [x8, #0x20]
     df8:      	add	x0, sp, #0x18
     dfc:      	mov	w1, #0x35               // =53
     e00:      	mov	w2, w22
     e04:      	stp	x9, x10, [sp, #0x38]
     e08:      	ldur	x9, [x8, #0x2d]
     e0c:      	stur	x9, [sp, #0x45]
     e10:      	ldp	x9, x10, [x8]
     e14:      	stp	x9, x10, [sp, #0x18]
     e18:      	ldp	x8, x9, [x8, #0x10]
     e1c:      	add	x10, sp, #0x18
     e20:      	stp	x8, x9, [sp, #0x28]
     e24:      	mov	w8, #0x35               // =53
     e28:      	mov	w9, #0x6                // =6
     e2c:      	blr	x9
     e30:      	b	0x70c <custom__generic+0x70c>
     e34:      	adrp	x8, 0x0 <custom__generic>
     e38:      	add	x8, x8, #0x0
     e3c:      	strb	wzr, [sp, #0x50]
     e40:      	add	x0, sp, #0x18
     e44:      	ldp	x9, x10, [x8, #0x20]
     e48:      	mov	w1, #0x39               // =57
     e4c:      	mov	x2, x23
     e50:      	stp	x9, x10, [sp, #0x38]
     e54:      	ldr	x9, [x8, #0x30]
     e58:      	str	x9, [sp, #0x48]
     e5c:      	ldp	x9, x10, [x8]
     e60:      	stp	x9, x10, [sp, #0x18]
     e64:      	ldp	x8, x9, [x8, #0x10]
     e68:      	add	x10, sp, #0x18
     e6c:      	stp	x8, x9, [sp, #0x28]
     e70:      	mov	w8, #0x39               // =57
     e74:      	mov	w9, #0x6                // =6
     e78:      	blr	x9
     e7c:      	b	0xbd8 <custom__generic+0xbd8>
     e80:      	adrp	x8, 0x0 <custom__generic>
     e84:      	add	x8, x8, #0x0
     e88:      	mov	w3, w0
     e8c:      	ldp	x9, x10, [x8, #0x20]
     e90:      	add	x0, sp, #0x18
     e94:      	mov	w1, #0x36               // =54
     e98:      	mov	w2, #0x1                // =1
     e9c:      	stp	x9, x10, [sp, #0x38]
     ea0:      	ldur	x9, [x8, #0x2e]
     ea4:      	stur	x9, [sp, #0x46]
     ea8:      	ldp	x9, x10, [x8]
     eac:      	stp	x9, x10, [sp, #0x18]
     eb0:      	ldp	x8, x9, [x8, #0x10]
     eb4:      	add	x10, sp, #0x18
     eb8:      	stp	x8, x9, [sp, #0x28]
     ebc:      	mov	w8, #0x36               // =54
     ec0:      	mov	w9, #0x6                // =6
     ec4:      	blr	x9
     ec8:      	b	0x884 <custom__generic+0x884>
     ecc:      	adrp	x8, 0x0 <custom__generic>
     ed0:      	add	x8, x8, #0x0
     ed4:      	add	x0, sp, #0x18
     ed8:      	ldp	x9, x10, [x8, #0x10]
     edc:      	mov	w1, #0x2e               // =46
     ee0:      	stp	x9, x10, [sp, #0x28]
     ee4:      	ldr	x9, [x8, #0x20]
     ee8:      	add	x10, sp, #0x18
     eec:      	str	x9, [sp, #0x38]
     ef0:      	ldur	x9, [x8, #0x26]
     ef4:      	stur	x9, [sp, #0x3e]
     ef8:      	ldp	x9, x8, [x8]
     efc:      	stp	x9, x8, [sp, #0x18]
     f00:      	mov	w8, #0x2e               // =46
     f04:      	mov	w9, #0x6                // =6
     f08:      	ldr	w2, [sp, #0x168]
     f0c:      	blr	x9
     f10:      	b	0x844 <custom__generic+0x844>
     f14:      	adrp	x8, 0x0 <custom__generic>
     f18:      	add	x8, x8, #0x0
     f1c:      	mov	x22, x0
     f20:      	ldp	x9, x10, [x8]
     f24:      	mov	w1, #0x1e               // =30
     f28:      	stp	x9, x10, [sp, #0x18]
     f2c:      	ldr	x9, [x8, #0x10]
     f30:      	ldur	x8, [x8, #0x16]
     f34:      	add	x10, sp, #0x18
     f38:      	str	x9, [sp, #0x28]
     f3c:      	stur	x8, [sp, #0x2e]
     f40:      	mov	w8, #0x1e               // =30
     f44:      	mov	w9, #0x6                // =6
     f48:      	ldrh	w2, [x0, #0x20]
     f4c:      	add	x0, sp, #0x18
     f50:      	blr	x9
     f54:      	mov	x0, x22
     f58:      	ldrh	w8, [x22, #0x20]
     f5c:      	ldr	w9, [x21, #0x1370]
     f60:      	lsr	w8, w9, w8
     f64:      	tbnz	w8, #0x0, 0xbc0 <custom__generic+0xbc0>
     f68:      	mov	x22, x0
     f6c:      	str	wzr, [sp, #0x1a0]
     f70:      	adrp	x0, 0x0 <custom__generic>
     f74:      	mov	w8, #0x1                // =1
     f78:      	ldr	x0, [x0]
     f7c:      	add	x9, sp, #0x1a0
     f80:      	add	x1, sp, #0x1a0
     f84:      	blr	x8
     f88:      	cbz	x0, 0xfa0 <custom__generic+0xfa0>
     f8c:      	ldr	x8, [x0]
     f90:      	add	x8, x8, #0x1
     f94:      	str	x8, [x0]
     f98:      	mov	x8, x22
     f9c:      	b	0xfac <custom__generic+0xfac>
     fa0:      	ldr	w9, [x25]
     fa4:      	mov	x8, x22
     fa8:      	cbnz	w9, 0xff4 <custom__generic+0xff4>
     fac:      	ldrh	w22, [x8, #0x20]
     fb0:      	b	0x2a0 <custom__generic+0x2a0>
     fb4:      	mov	w8, #0x656e             // =25966
     fb8:      	add	x0, sp, #0x18
     fbc:      	mov	w1, #0x1b               // =27
     fc0:      	movk	w8, #0xa, lsl #16
     fc4:      	stur	w8, [sp, #0x2f]
     fc8:      	adrp	x8, 0x0 <custom__generic>
     fcc:      	add	x8, x8, #0x0
     fd0:      	ldp	x9, x10, [x8]
     fd4:      	ldr	x8, [x8, #0x10]
     fd8:      	stp	x9, x10, [sp, #0x18]
     fdc:      	str	x8, [sp, #0x28]
     fe0:      	mov	w8, #0x1b               // =27
     fe4:      	mov	w9, #0x6                // =6
     fe8:      	add	x10, sp, #0x18
     fec:      	blr	x9
     ff0:      	b	0xbc8 <custom__generic+0xbc8>
     ff4:      	adrp	x8, 0x0 <custom__generic>
     ff8:      	add	x8, x8, #0x0
     ffc:      	add	x0, sp, #0x18
    1000:      	ldp	x9, x10, [x8, #0x10]
    1004:      	mov	w1, #0x2e               // =46
    1008:      	stp	x9, x10, [sp, #0x28]
    100c:      	ldr	x9, [x8, #0x20]
    1010:      	add	x10, sp, #0x18
    1014:      	str	x9, [sp, #0x38]
    1018:      	ldur	x9, [x8, #0x26]
    101c:      	stur	x9, [sp, #0x3e]
    1020:      	ldp	x9, x8, [x8]
    1024:      	stp	x9, x8, [sp, #0x18]
    1028:      	mov	w8, #0x2e               // =46
    102c:      	mov	w9, #0x6                // =6
    1030:      	ldr	w2, [sp, #0x1a0]
    1034:      	blr	x9
    1038:      	b	0xf98 <custom__generic+0xf98>
