
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/cilium/bpf_xdp.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <__check_cluster_id_bits>:
       0:      	adrp	x8, 0x0 <__check_cluster_id_bits>
       4:      	ldr	x8, [x8]
       8:      	ldr	wzr, [x8]
       c:      	ret

0000000000000010 <__check_device_mtu>:
      10:      	adrp	x8, 0x0 <__check_cluster_id_bits>
      14:      	ldr	x8, [x8]
      18:      	ldrh	wzr, [x8]
      1c:      	ret

Disassembly of section xdp/tail:

0000000000000000 <tail_drop_notify>:
       0:      	sub	sp, sp, #0xa0
       4:      	str	x29, [sp, #0x50]
       8:      	stp	x30, x25, [sp, #0x60]
       c:      	stp	x24, x23, [sp, #0x70]
      10:      	stp	x22, x21, [sp, #0x80]
      14:      	stp	x20, x19, [sp, #0x90]
      18:      	str	wzr, [sp, #0x10]
      1c:      	mov	x19, x0
      20:      	mov	w8, #0x1                // =1
      24:      	adrp	x0, 0x0 <tail_drop_notify>
      28:      	add	x1, sp, #0x10
      2c:      	ldr	x0, [x0]
      30:      	blr	x8
      34:      	cbz	x0, 0x80 <tail_drop_notify+0x80>
      38:      	ldr	w9, [x0, #0x8]
      3c:      	adrp	x8, 0x0 <tail_drop_notify>
      40:      	ldr	x8, [x8]
      44:      	ldrb	w8, [x8]
      48:      	str	w9, [sp, #0x58]
      4c:      	cbz	w8, 0x98 <tail_drop_notify+0x98>
      50:      	str	wzr, [sp, #0x10]
      54:      	mov	w8, #0x1                // =1
      58:      	adrp	x0, 0x0 <tail_drop_notify>
      5c:      	add	x1, sp, #0x10
      60:      	ldr	x0, [x0]
      64:      	blr	x8
      68:      	cbz	x0, 0x74 <tail_drop_notify+0x74>
      6c:      	ldr	x8, [x0]
      70:      	b	0x78 <tail_drop_notify+0x78>
      74:      	mov	x8, xzr
      78:      	str	x8, [sp, #0x8]
      7c:      	b	0x9c <tail_drop_notify+0x9c>
      80:      	mov	w9, wzr
      84:      	adrp	x8, 0x0 <tail_drop_notify>
      88:      	ldr	x8, [x8]
      8c:      	ldrb	w8, [x8]
      90:      	str	wzr, [sp, #0x58]
      94:      	cbnz	w8, 0x50 <tail_drop_notify+0x50>
      98:      	str	xzr, [sp, #0x8]
      9c:      	str	wzr, [sp, #0x10]
      a0:      	ldp	x29, x25, [x19]
      a4:      	mov	w8, #0x1                // =1
      a8:      	adrp	x0, 0x0 <tail_drop_notify>
      ac:      	add	x1, sp, #0x10
      b0:      	ldr	x0, [x0]
      b4:      	blr	x8
      b8:      	cbz	x0, 0x34c <tail_drop_notify+0x34c>
      bc:      	ldr	w24, [x0, #0x10]
      c0:      	mov	w20, #0x2               // =2
      c4:      	adrp	x8, 0x0 <tail_drop_notify>
      c8:      	str	x20, [sp, #0x40]
      cc:      	ldr	x8, [x8]
      d0:      	ldr	w9, [x8]
      d4:      	cbz	w9, 0x1f4 <tail_drop_notify+0x1f4>
      d8:      	adrp	x9, 0x0 <tail_drop_notify>
      dc:      	ldr	x9, [x9]
      e0:      	ldr	w23, [x9]
      e4:      	ldr	w22, [x8]
      e8:      	mov	w8, #0x5                // =5
      ec:      	blr	x8
      f0:      	str	w20, [sp, #0x5c]
      f4:      	mov	x21, x0
      f8:      	mov	w8, #0x1                // =1
      fc:      	adrp	x0, 0x0 <tail_drop_notify>
     100:      	add	x1, sp, #0x5c
     104:      	ldr	x0, [x0]
     108:      	blr	x8
     10c:      	mov	x20, x0
     110:      	cbnz	x0, 0x13c <tail_drop_notify+0x13c>
     114:      	str	xzr, [sp, #0x48]
     118:      	mov	w8, #0x2                // =2
     11c:      	adrp	x0, 0x0 <tail_drop_notify>
     120:      	add	x1, sp, #0x5c
     124:      	add	x2, sp, #0x48
     128:      	mov	w3, wzr
     12c:      	add	x20, sp, #0x48
     130:      	ldr	x0, [x0]
     134:      	blr	x8
     138:      	tbnz	w0, #0x1f, 0x31c <tail_drop_notify+0x31c>
     13c:      	mov	w8, #0x1                // =1
     140:      	adrp	x0, 0x0 <tail_drop_notify>
     144:      	add	x1, sp, #0x40
     148:      	ldr	x0, [x0]
     14c:      	blr	x8
     150:      	cbz	x0, 0x1b8 <tail_drop_notify+0x1b8>
     154:      	ldr	x8, [x0]
     158:      	mov	w9, #0xca00             // =51712
     15c:      	movk	w9, #0x3b9a, lsl #16
     160:      	sub	x10, x21, x8
     164:      	cmp	x10, x9
     168:      	b.ls	0x1e4 <tail_drop_notify+0x1e4>
     16c:      	mov	x11, #0x5a53            // =23123
     170:      	lsr	x8, x10, #9
     174:      	neg	x10, x10
     178:      	movk	x11, #0xa09b, lsl #16
     17c:      	movk	x11, #0xb82f, lsl #32
     180:      	movk	x11, #0x44, lsl #48
     184:      	umulh	x8, x8, x11
     188:      	lsr	x11, x8, #11
     18c:      	ldr	x8, [x0, #0x8]
     190:      	madd	x9, x11, x9, x10
     194:      	madd	x8, x11, x22, x8
     198:      	add	x9, x21, x9
     19c:      	cmp	x8, x23
     1a0:      	stp	x9, x8, [x0]
     1a4:      	b.ls	0x1b0 <tail_drop_notify+0x1b0>
     1a8:      	mov	x8, x23
     1ac:      	str	x23, [x0, #0x8]
     1b0:      	cbnz	x8, 0x1ec <tail_drop_notify+0x1ec>
     1b4:      	b	0x33c <tail_drop_notify+0x33c>
     1b8:      	sub	x8, x22, #0x1
     1bc:      	adrp	x0, 0x0 <tail_drop_notify>
     1c0:      	add	x1, sp, #0x40
     1c4:      	stp	x21, x8, [sp, #0x10]
     1c8:      	mov	w8, #0x2                // =2
     1cc:      	add	x2, sp, #0x10
     1d0:      	mov	w3, wzr
     1d4:      	ldr	x0, [x0]
     1d8:      	blr	x8
     1dc:      	tbz	w0, #0x1f, 0x1f4 <tail_drop_notify+0x1f4>
     1e0:      	b	0x33c <tail_drop_notify+0x33c>
     1e4:      	ldr	x8, [x0, #0x8]
     1e8:      	cbz	x8, 0x33c <tail_drop_notify+0x33c>
     1ec:      	sub	x8, x8, #0x1
     1f0:      	str	x8, [x0, #0x8]
     1f4:      	ldp	x9, x8, [x19]
     1f8:      	add	x10, x9, #0xe
     1fc:      	cmp	x10, x8
     200:      	b.ls	0x20c <tail_drop_notify+0x20c>
     204:      	mov	w20, wzr
     208:      	b	0x21c <tail_drop_notify+0x21c>
     20c:      	ldrh	w10, [x9, #0xc]
     210:      	mov	w11, #0xdd86            // =56710
     214:      	cmp	w11, w10, uxth
     218:      	cset	w20, eq
     21c:      	adrp	x10, 0x0 <tail_drop_notify>
     220:      	sub	x8, x8, x9
     224:      	adrp	x0, 0x0 <tail_drop_notify>
     228:      	ldr	x10, [x10]
     22c:      	add	x1, sp, #0x10
     230:      	sub	x25, x25, x29
     234:      	ldr	w10, [x10]
     238:      	cmp	x8, x10
     23c:      	str	wzr, [sp, #0x10]
     240:      	csel	x21, x8, x10, lo
     244:      	mov	w8, #0x1                // =1
     248:      	ldr	x0, [x0]
     24c:      	blr	x8
     250:      	cbz	x0, 0x36c <tail_drop_notify+0x36c>
     254:      	ldr	w22, [x0]
     258:      	str	wzr, [sp, #0x10]
     25c:      	mov	w8, #0x1                // =1
     260:      	adrp	x0, 0x0 <tail_drop_notify>
     264:      	add	x1, sp, #0x10
     268:      	ldr	x0, [x0]
     26c:      	blr	x8
     270:      	cbz	x0, 0x374 <tail_drop_notify+0x374>
     274:      	ldr	w23, [x0, #0x4]
     278:      	str	wzr, [sp, #0x10]
     27c:      	mov	w8, #0x1                // =1
     280:      	adrp	x0, 0x0 <tail_drop_notify>
     284:      	add	x1, sp, #0x10
     288:      	mov	w29, #0x1               // =1
     28c:      	ldr	x0, [x0]
     290:      	blr	x8
     294:      	cbz	x0, 0x37c <tail_drop_notify+0x37c>
     298:      	ldr	w8, [x0, #0xc]
     29c:      	ldr	w12, [sp, #0x58]
     2a0:      	ldr	x13, [sp, #0x8]
     2a4:      	lsr	w9, w24, #8
     2a8:      	lsr	w10, w24, #16
     2ac:      	adrp	x1, 0x0 <tail_drop_notify>
     2b0:      	add	x3, sp, #0x10
     2b4:      	strb	w29, [sp, #0x10]
     2b8:      	strh	wzr, [sp, #0x12]
     2bc:      	mov	x0, x19
     2c0:      	mov	w4, #0x30               // =48
     2c4:      	lsr	w11, w12, #8
     2c8:      	strb	w12, [sp, #0x11]
     2cc:      	mov	w12, #0x3               // =3
     2d0:      	stp	wzr, w25, [sp, #0x14]
     2d4:      	strh	w21, [sp, #0x1c]
     2d8:      	stp	w22, w23, [sp, #0x20]
     2dc:      	str	w8, [sp, #0x28]
     2e0:      	strh	w10, [sp, #0x2c]
     2e4:      	mov	w8, #0x19               // =25
     2e8:      	strb	w9, [sp, #0x2e]
     2ec:      	mov	w9, #-0x1               // =-1
     2f0:      	orr	x2, x9, x21, lsl #32
     2f4:      	strb	w20, [sp, #0x34]
     2f8:      	sturh	wzr, [sp, #0x35]
     2fc:      	strb	wzr, [sp, #0x37]
     300:      	str	x13, [sp, #0x38]
     304:      	strh	w12, [sp, #0x1e]
     308:      	ldr	w12, [x19, #0xc]
     30c:      	strb	w11, [sp, #0x2f]
     310:      	str	w12, [sp, #0x30]
     314:      	ldr	x1, [x1]
     318:      	blr	x8
     31c:      	and	w0, w24, #0xff
     320:      	ldp	x20, x19, [sp, #0x90]
     324:      	ldr	x29, [sp, #0x50]
     328:      	ldp	x22, x21, [sp, #0x80]
     32c:      	ldp	x24, x23, [sp, #0x70]
     330:      	ldp	x30, x25, [sp, #0x60]
     334:      	add	sp, sp, #0xa0
     338:      	ret
     33c:      	ldr	x8, [x20]
     340:      	add	x8, x8, #0x1
     344:      	str	x8, [x20]
     348:      	b	0x31c <tail_drop_notify+0x31c>
     34c:      	mov	w24, wzr
     350:      	mov	w20, #0x2               // =2
     354:      	adrp	x8, 0x0 <tail_drop_notify>
     358:      	str	x20, [sp, #0x40]
     35c:      	ldr	x8, [x8]
     360:      	ldr	w9, [x8]
     364:      	cbnz	w9, 0xd8 <tail_drop_notify+0xd8>
     368:      	b	0x1f4 <tail_drop_notify+0x1f4>
     36c:      	mov	w22, wzr
     370:      	b	0x258 <tail_drop_notify+0x258>
     374:      	mov	w23, wzr
     378:      	b	0x278 <tail_drop_notify+0x278>
     37c:      	mov	w8, wzr
     380:      	b	0x29c <tail_drop_notify+0x29c>

Disassembly of section xdp/entry:

0000000000000000 <cil_xdp_entry>:
       0:      	str	x30, [sp, #-0x20]!
       4:      	stp	x20, x19, [sp, #0x10]
       8:      	adrp	x8, 0x0 <cil_xdp_entry>
       c:      	mov	x19, x0
      10:      	ldr	x8, [x8]
      14:      	ldrb	w9, [x8]
      18:      	cbz	w9, 0x64 <cil_xdp_entry+0x64>
      1c:      	ldrb	w10, [x8]
      20:      	ldp	x9, x8, [x19]
      24:      	add	x12, x9, #0xe
      28:      	cmp	x12, x8
      2c:      	b.hi	0x44 <cil_xdp_entry+0x44>
      30:      	ldrh	w13, [x9, #0xc]
      34:      	add	x11, x9, #0x22
      38:      	cmp	w13, #0x8
      3c:      	ccmp	x11, x8, #0x2, eq
      40:      	b.ls	0xe8 <cil_xdp_entry+0xe8>
      44:      	str	wzr, [sp, #0xc]
      48:      	mov	w8, #0x1                // =1
      4c:      	adrp	x0, 0x0 <cil_xdp_entry>
      50:      	add	x1, sp, #0xc
      54:      	ldr	x0, [x0]
      58:      	blr	x8
      5c:      	cbz	x0, 0x64 <cil_xdp_entry+0x64>
      60:      	str	xzr, [x0]
      64:      	ldp	x8, x9, [x19]
      68:      	add	x10, x8, #0xe
      6c:      	cmp	x10, x9
      70:      	b.hi	0xd8 <cil_xdp_entry+0xd8>
      74:      	ldrh	w8, [x8, #0xc]
      78:      	cmp	w8, #0x6
      7c:      	b.lo	0xd8 <cil_xdp_entry+0xd8>
      80:      	str	wzr, [sp, #0xc]
      84:      	mov	w8, #0x1                // =1
      88:      	adrp	x0, 0x0 <cil_xdp_entry>
      8c:      	add	x1, sp, #0xc
      90:      	ldr	x0, [x0]
      94:      	blr	x8
      98:      	cbz	x0, 0xa0 <cil_xdp_entry+0xa0>
      9c:      	str	wzr, [x0, #0x18]
      a0:      	str	wzr, [sp, #0xc]
      a4:      	mov	w8, #0x1                // =1
      a8:      	adrp	x0, 0x0 <cil_xdp_entry>
      ac:      	add	x1, sp, #0xc
      b0:      	ldr	x0, [x0]
      b4:      	blr	x8
      b8:      	cbz	x0, 0xd8 <cil_xdp_entry+0xd8>
      bc:      	ldr	w20, [x0, #0x18]
      c0:      	cbz	w20, 0xd8 <cil_xdp_entry+0xd8>
      c4:      	mov	w8, #0x36               // =54
      c8:      	mov	x0, x19
      cc:      	mov	w1, #-0x4               // =-4
      d0:      	blr	x8
      d4:      	cbz	w0, 0x1bc <cil_xdp_entry+0x1bc>
      d8:      	ldp	x20, x19, [sp, #0x10]
      dc:      	mov	w0, #0x2                // =2
      e0:      	ldr	x30, [sp], #0x20
      e4:      	ret
      e8:      	ldrb	w12, [x12]
      ec:      	and	w12, w12, #0xf
      f0:      	cmp	w12, #0x6
      f4:      	b.hs	0x120 <cil_xdp_entry+0x120>
      f8:      	mov	x20, xzr
      fc:      	str	wzr, [sp, #0xc]
     100:      	mov	w8, #0x1                // =1
     104:      	adrp	x0, 0x0 <cil_xdp_entry>
     108:      	add	x1, sp, #0xc
     10c:      	ldr	x0, [x0]
     110:      	blr	x8
     114:      	cbz	x0, 0x64 <cil_xdp_entry+0x64>
     118:      	str	x20, [x0]
     11c:      	b	0x64 <cil_xdp_entry+0x64>
     120:      	add	x13, x9, #0x23
     124:      	cmp	x13, x8
     128:      	b.hi	0x44 <cil_xdp_entry+0x44>
     12c:      	ldrb	w20, [x11]
     130:      	cbz	w20, 0xfc <cil_xdp_entry+0xfc>
     134:      	cmp	w20, #0x1
     138:      	b.ne	0x1e4 <cil_xdp_entry+0x1e4>
     13c:      	mov	w11, #0x23              // =35
     140:      	lsl	w12, w12, #2
     144:      	add	w12, w12, #0x22
     148:      	cmp	w11, w12
     14c:      	b.hs	0xf8 <cil_xdp_entry+0xf8>
     150:      	add	x13, x9, w11, uxtw
     154:      	add	x14, x13, #0x1
     158:      	cmp	x14, x8
     15c:      	b.hi	0x44 <cil_xdp_entry+0x44>
     160:      	ldrb	w20, [x13]
     164:      	cbz	w20, 0xfc <cil_xdp_entry+0xfc>
     168:      	cmp	w20, #0x1
     16c:      	b.ne	0x250 <cil_xdp_entry+0x250>
     170:      	mov	w11, w11
     174:      	add	x11, x11, w20, uxtw
     178:      	cmp	w11, w12
     17c:      	b.hs	0xf8 <cil_xdp_entry+0xf8>
     180:      	add	x12, x9, w11, uxtw
     184:      	add	x13, x12, #0x1
     188:      	cmp	x13, x8
     18c:      	b.hi	0x44 <cil_xdp_entry+0x44>
     190:      	ldrb	w13, [x12]
     194:      	cmp	w13, #0x2
     198:      	b.lo	0xf8 <cil_xdp_entry+0xf8>
     19c:      	add	x12, x9, x11
     1a0:      	add	x14, x12, #0x2
     1a4:      	cmp	x14, x8
     1a8:      	b.hi	0x44 <cil_xdp_entry+0x44>
     1ac:      	cmp	w13, w10
     1b0:      	b.ne	0xf8 <cil_xdp_entry+0xf8>
     1b4:      	ldrb	w13, [x12, #0x1]
     1b8:      	b	0x200 <cil_xdp_entry+0x200>
     1bc:      	ldr	x8, [x19, #0x10]
     1c0:      	ldr	x9, [x19]
     1c4:      	add	x10, x8, #0x4
     1c8:      	cmp	x10, x9
     1cc:      	b.hi	0xd8 <cil_xdp_entry+0xd8>
     1d0:      	str	w20, [x8]
     1d4:      	ldp	x20, x19, [sp, #0x10]
     1d8:      	mov	w0, #0x2                // =2
     1dc:      	ldr	x30, [sp], #0x20
     1e0:      	ret
     1e4:      	add	x11, x9, #0x24
     1e8:      	cmp	x11, x8
     1ec:      	b.hi	0x44 <cil_xdp_entry+0x44>
     1f0:      	ldrb	w13, [x9, #0x23]
     1f4:      	cmp	w20, w10
     1f8:      	b.ne	0x238 <cil_xdp_entry+0x238>
     1fc:      	mov	w11, #0x22              // =34
     200:      	cmp	w13, #0xa
     204:      	b.eq	0x29c <cil_xdp_entry+0x29c>
     208:      	cmp	w13, #0x6
     20c:      	b.eq	0x280 <cil_xdp_entry+0x280>
     210:      	cmp	w13, #0x4
     214:      	b.ne	0x44 <cil_xdp_entry+0x44>
     218:      	add	x9, x9, w11, uxtw
     21c:      	add	x10, x9, #0x4
     220:      	cmp	x10, x8
     224:      	b.hi	0x44 <cil_xdp_entry+0x44>
     228:      	ldrh	w8, [x9, #0x2]
     22c:      	rev	w8, w8
     230:      	lsr	w20, w8, #16
     234:      	b	0xfc <cil_xdp_entry+0xfc>
     238:      	add	w11, w13, #0x22
     23c:      	lsl	w12, w12, #2
     240:      	add	w12, w12, #0x22
     244:      	cmp	w11, w12
     248:      	b.hs	0xf8 <cil_xdp_entry+0xf8>
     24c:      	b	0x150 <cil_xdp_entry+0x150>
     250:      	add	x14, x13, #0x2
     254:      	cmp	x14, x8
     258:      	b.hi	0x44 <cil_xdp_entry+0x44>
     25c:      	ldrb	w13, [x13, #0x1]
     260:      	cmp	w20, w10
     264:      	b.eq	0x200 <cil_xdp_entry+0x200>
     268:      	mov	w20, w13
     26c:      	mov	w11, w11
     270:      	add	x11, x11, w20, uxtw
     274:      	cmp	w11, w12
     278:      	b.hs	0xf8 <cil_xdp_entry+0xf8>
     27c:      	b	0x180 <cil_xdp_entry+0x180>
     280:      	add	x9, x9, w11, uxtw
     284:      	add	x10, x9, #0x6
     288:      	cmp	x10, x8
     28c:      	b.hi	0x44 <cil_xdp_entry+0x44>
     290:      	ldur	w8, [x9, #0x2]
     294:      	rev	w20, w8
     298:      	b	0xfc <cil_xdp_entry+0xfc>
     29c:      	add	x9, x9, w11, uxtw
     2a0:      	add	x10, x9, #0xa
     2a4:      	cmp	x10, x8
     2a8:      	b.hi	0x44 <cil_xdp_entry+0x44>
     2ac:      	ldur	x8, [x9, #0x2]
     2b0:      	rev	x20, x8
     2b4:      	b	0xfc <cil_xdp_entry+0xfc>
