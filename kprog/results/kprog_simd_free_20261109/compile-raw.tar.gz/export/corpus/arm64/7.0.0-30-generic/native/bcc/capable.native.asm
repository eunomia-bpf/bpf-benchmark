
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/bcc/capable.native.o:	file format elf64-littleaarch64

Disassembly of section kprobe/cap_capable:

0000000000000000 <kprobe__cap_capable_entry>:
       0:      	sub	sp, sp, #0x30
       4:      	str	x30, [sp, #0x10]
       8:      	stp	x20, x19, [sp, #0x20]
       c:      	adrp	x8, 0x0 <kprobe__cap_capable_entry>
      10:      	ldr	w19, [x0, #0x10]
      14:      	ldr	w20, [x0, #0x18]
      18:      	ldr	x8, [x8]
      1c:      	ldrb	w8, [x8]
      20:      	cbz	w8, 0x38 <kprobe__cap_capable_entry+0x38>
      24:      	adrp	x0, 0x0 <kprobe__cap_capable_entry>
      28:      	mov	w1, wzr
      2c:      	ldr	x0, [x0]
      30:      	bl	0x30 <kprobe__cap_capable_entry+0x30>
      34:      	cbz	x0, 0x94 <kprobe__cap_capable_entry+0x94>
      38:      	bl	0x38 <kprobe__cap_capable_entry+0x38>
      3c:      	str	x0, [sp, #0x18]
      40:      	adrp	x9, 0x0 <kprobe__cap_capable_entry>
      44:      	lsr	x8, x0, #32
      48:      	ldr	x9, [x9]
      4c:      	ldr	w9, [x9]
      50:      	cmp	w9, w8
      54:      	b.eq	0x94 <kprobe__cap_capable_entry+0x94>
      58:      	adrp	x9, 0x0 <kprobe__cap_capable_entry>
      5c:      	ldr	x9, [x9]
      60:      	ldr	w10, [x9]
      64:      	cmn	w10, #0x1
      68:      	b.eq	0x78 <kprobe__cap_capable_entry+0x78>
      6c:      	ldr	w9, [x9]
      70:      	cmp	w9, w8
      74:      	b.ne	0x94 <kprobe__cap_capable_entry+0x94>
      78:      	stp	w19, w20, [sp, #0x8]
      7c:      	adrp	x0, 0x0 <kprobe__cap_capable_entry>
      80:      	add	x1, sp, #0x18
      84:      	add	x2, sp, #0x8
      88:      	ldr	x0, [x0]
      8c:      	mov	x3, xzr
      90:      	bl	0x90 <kprobe__cap_capable_entry+0x90>
      94:      	ldp	x20, x19, [sp, #0x20]
      98:      	mov	w0, wzr
      9c:      	ldr	x30, [sp, #0x10]
      a0:      	add	sp, sp, #0x30
      a4:      	ret

Disassembly of section kretprobe/cap_capable:

0000000000000000 <kprobe__cap_capable_exit>:
       0:      	sub	sp, sp, #0x70
       4:      	str	x30, [sp, #0x50]
       8:      	stp	x20, x19, [sp, #0x60]
       c:      	mov	x19, x0
      10:      	bl	0x10 <kprobe__cap_capable_exit+0x10>
      14:      	str	x0, [sp, #0x58]
      18:      	adrp	x0, 0x0 <kprobe__cap_capable_exit>
      1c:      	add	x1, sp, #0x58
      20:      	ldr	x0, [x0]
      24:      	bl	0x24 <kprobe__cap_capable_exit+0x24>
      28:      	cbz	x0, 0x130 <kprobe__cap_capable_exit+0x130>
      2c:      	mov	x20, x0
      30:      	adrp	x0, 0x0 <kprobe__cap_capable_exit>
      34:      	add	x1, sp, #0x58
      38:      	ldr	x0, [x0]
      3c:      	bl	0x3c <kprobe__cap_capable_exit+0x3c>
      40:      	ldr	x8, [sp, #0x58]
      44:      	str	wzr, [sp, #0x3c]
      48:      	lsr	x9, x8, #32
      4c:      	stur	xzr, [sp, #0x34]
      50:      	stur	xzr, [sp, #0x2c]
      54:      	stur	xzr, [sp, #0x24]
      58:      	str	w8, [sp, #0x1c]
      5c:      	str	w9, [sp, #0x14]
      60:      	ldr	w8, [x20]
      64:      	str	w8, [sp, #0x18]
      68:      	bl	0x68 <kprobe__cap_capable_exit+0x68>
      6c:      	add	x8, sp, #0x14
      70:      	str	w0, [sp, #0x20]
      74:      	mov	w1, #0x10               // =16
      78:      	add	x0, x8, #0x1c
      7c:      	bl	0x7c <kprobe__cap_capable_exit+0x7c>
      80:      	ldr	x8, [x19]
      84:      	mov	w10, #0x100             // =256
      88:      	movk	w10, #0x5, lsl #16
      8c:      	str	w8, [sp, #0x2c]
      90:      	adrp	x8, 0x0 <kprobe__cap_capable_exit>
      94:      	ldr	x8, [x8]
      98:      	ldr	w9, [x8]
      9c:      	ldr	w8, [x20, #0x4]
      a0:      	cmp	w9, w10
      a4:      	b.lt	0xe4 <kprobe__cap_capable_exit+0xe4>
      a8:      	mov	w10, #0x1               // =1
      ac:      	ubfx	w9, w8, #2, #1
      b0:      	bic	w8, w10, w8, lsr #1
      b4:      	stp	w8, w9, [sp, #0x24]
      b8:      	adrp	x8, 0x0 <kprobe__cap_capable_exit>
      bc:      	ldr	x8, [x8]
      c0:      	ldr	w9, [x8]
      c4:      	cbnz	w9, 0xfc <kprobe__cap_capable_exit+0xfc>
      c8:      	adrp	x20, 0x0 <kprobe__cap_capable_exit>
      cc:      	adrp	x8, 0x0 <kprobe__cap_capable_exit>
      d0:      	ldr	x20, [x20]
      d4:      	ldrb	w9, [x20]
      d8:      	ldr	x8, [x8]
      dc:      	cbnz	w9, 0x19c <kprobe__cap_capable_exit+0x19c>
      e0:      	b	0x194 <kprobe__cap_capable_exit+0x194>
      e4:      	mov	w9, #-0x1               // =-1
      e8:      	stp	w8, w9, [sp, #0x24]
      ec:      	adrp	x8, 0x0 <kprobe__cap_capable_exit>
      f0:      	ldr	x8, [x8]
      f4:      	ldr	w9, [x8]
      f8:      	cbz	w9, 0xc8 <kprobe__cap_capable_exit+0xc8>
      fc:      	ldr	w9, [x20]
     100:      	str	xzr, [sp, #0x48]
     104:      	stp	w9, wzr, [sp, #0x40]
     108:      	ldr	w8, [x8]
     10c:      	cmp	w8, #0x2
     110:      	b.ne	0x144 <kprobe__cap_capable_exit+0x144>
     114:      	bl	0x114 <kprobe__cap_capable_exit+0x114>
     118:      	str	x0, [sp, #0x48]
     11c:      	adrp	x0, 0x0 <kprobe__cap_capable_exit>
     120:      	add	x1, sp, #0x40
     124:      	ldr	x0, [x0]
     128:      	bl	0x128 <kprobe__cap_capable_exit+0x128>
     12c:      	cbz	x0, 0x160 <kprobe__cap_capable_exit+0x160>
     130:      	ldp	x20, x19, [sp, #0x60]
     134:      	mov	w0, wzr
     138:      	ldr	x30, [sp, #0x50]
     13c:      	add	sp, sp, #0x70
     140:      	ret
     144:      	ldr	x8, [sp, #0x58]
     148:      	str	w8, [sp, #0x44]
     14c:      	adrp	x0, 0x0 <kprobe__cap_capable_exit>
     150:      	add	x1, sp, #0x40
     154:      	ldr	x0, [x0]
     158:      	bl	0x158 <kprobe__cap_capable_exit+0x158>
     15c:      	cbnz	x0, 0x130 <kprobe__cap_capable_exit+0x130>
     160:      	str	xzr, [sp, #0x8]
     164:      	adrp	x0, 0x0 <kprobe__cap_capable_exit>
     168:      	add	x1, sp, #0x40
     16c:      	add	x2, sp, #0x8
     170:      	ldr	x0, [x0]
     174:      	mov	x3, xzr
     178:      	bl	0x178 <kprobe__cap_capable_exit+0x178>
     17c:      	adrp	x20, 0x0 <kprobe__cap_capable_exit>
     180:      	adrp	x8, 0x0 <kprobe__cap_capable_exit>
     184:      	ldr	x20, [x20]
     188:      	ldrb	w9, [x20]
     18c:      	ldr	x8, [x8]
     190:      	cbnz	w9, 0x19c <kprobe__cap_capable_exit+0x19c>
     194:      	ldrb	w9, [x8]
     198:      	cbz	w9, 0x208 <kprobe__cap_capable_exit+0x208>
     19c:      	ldr	x9, [sp, #0x58]
     1a0:      	lsr	x10, x9, #32
     1a4:      	stp	w10, w9, [sp, #0x40]
     1a8:      	mov	x9, #-0x1               // =-1
     1ac:      	str	x9, [sp, #0x48]
     1b0:      	ldrb	w8, [x8]
     1b4:      	cbz	w8, 0x1d0 <kprobe__cap_capable_exit+0x1d0>
     1b8:      	adrp	x1, 0x0 <kprobe__cap_capable_exit>
     1bc:      	mov	x0, x19
     1c0:      	mov	w2, #0x100              // =256
     1c4:      	ldr	x1, [x1]
     1c8:      	bl	0x1c8 <kprobe__cap_capable_exit+0x1c8>
     1cc:      	str	w0, [sp, #0x48]
     1d0:      	ldrb	w8, [x20]
     1d4:      	cbz	w8, 0x1f0 <kprobe__cap_capable_exit+0x1f0>
     1d8:      	adrp	x1, 0x0 <kprobe__cap_capable_exit>
     1dc:      	mov	x0, x19
     1e0:      	mov	x2, xzr
     1e4:      	ldr	x1, [x1]
     1e8:      	bl	0x1e8 <kprobe__cap_capable_exit+0x1e8>
     1ec:      	str	w0, [sp, #0x4c]
     1f0:      	adrp	x0, 0x0 <kprobe__cap_capable_exit>
     1f4:      	add	x1, sp, #0x40
     1f8:      	add	x2, sp, #0x14
     1fc:      	ldr	x0, [x0]
     200:      	mov	w3, #0x1                // =1
     204:      	bl	0x204 <kprobe__cap_capable_exit+0x204>
     208:      	adrp	x1, 0x0 <kprobe__cap_capable_exit>
     20c:      	add	x3, sp, #0x14
     210:      	mov	x0, x19
     214:      	ldr	x1, [x1]
     218:      	mov	w2, #-0x1               // =-1
     21c:      	mov	w4, #0x2c               // =44
     220:      	bl	0x220 <kprobe__cap_capable_exit+0x220>
     224:      	ldp	x20, x19, [sp, #0x60]
     228:      	mov	w0, wzr
     22c:      	ldr	x30, [sp, #0x50]
     230:      	add	sp, sp, #0x70
     234:      	ret
