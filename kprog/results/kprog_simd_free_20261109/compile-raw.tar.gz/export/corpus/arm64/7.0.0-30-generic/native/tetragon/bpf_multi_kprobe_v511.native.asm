
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_multi_kprobe_v511.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	cbz	x2, 0x8c <native_bpf_strncasestr+0x8c>
       4:      	mov	x8, x0
       8:      	mov	x0, xzr
       c:      	mov	x9, x2
      10:      	b	0x34 <native_bpf_strncasestr+0x34>
      14:      	nop
      18:      	nop
      1c:      	nop
      20:      	add	x0, x0, #0x1
      24:      	sub	x9, x9, #0x1
      28:      	add	x8, x8, #0x1
      2c:      	cmp	x0, x2
      30:      	b.eq	0x8c <native_bpf_strncasestr+0x8c>
      34:      	mov	x10, xzr
      38:      	nop
      3c:      	nop
      40:      	cmp	x9, x10
      44:      	b.eq	0x20 <native_bpf_strncasestr+0x20>
      48:      	ldrb	w11, [x1, x10]
      4c:      	cbz	w11, 0x90 <native_bpf_strncasestr+0x90>
      50:      	ldrb	w12, [x8, x10]
      54:      	sub	w13, w12, #0x41
      58:      	orr	w14, w12, #0x20
      5c:      	cmp	w13, #0x1a
      60:      	sub	w13, w11, #0x41
      64:      	csel	w12, w14, w12, lo
      68:      	orr	w14, w11, #0x20
      6c:      	cmp	w13, #0x1a
      70:      	csel	w11, w14, w11, lo
      74:      	cmp	w12, w11
      78:      	b.ne	0x20 <native_bpf_strncasestr+0x20>
      7c:      	cmp	x10, #0x63
      80:      	add	x10, x10, #0x1
      84:      	b.lo	0x40 <native_bpf_strncasestr+0x40>
      88:      	b	0x20 <native_bpf_strncasestr+0x20>
      8c:      	mov	w0, #-0x1               // =-1
      90:      	ret

Disassembly of section kprobe.multi:

0000000000000000 <generic_kprobe_setup_event>:
       0:      	sub	sp, sp, #0x80
       4:      	stp	x30, x25, [sp, #0x40]
       8:      	stp	x24, x23, [sp, #0x50]
       c:      	stp	x22, x21, [sp, #0x60]
      10:      	stp	x20, x19, [sp, #0x70]
      14:      	str	wzr, [sp, #0x4]
      18:      	adrp	x20, 0x0 <generic_kprobe_setup_event>
      1c:      	mov	w8, #0x1                // =1
      20:      	add	x9, sp, #0x4
      24:      	ldr	x20, [x20]
      28:      	mov	x19, x0
      2c:      	add	x1, sp, #0x4
      30:      	mov	x0, x20
      34:      	blr	x8
      38:      	cbz	x0, 0x344 <generic_kprobe_setup_event+0x344>
      3c:      	adrp	x21, 0x0 <generic_kprobe_setup_event>
      40:      	mov	w8, #0x5ef8             // =24312
      44:      	mov	x22, x0
      48:      	ldr	x21, [x21]
      4c:      	add	x1, x0, x8
      50:      	mov	w8, #0x1                // =1
      54:      	mov	x0, x21
      58:      	blr	x8
      5c:      	cbz	x0, 0x344 <generic_kprobe_setup_event+0x344>
      60:      	ldr	w8, [x0, #0x54]
      64:      	mov	x23, x0
      68:      	cbz	w8, 0x104 <generic_kprobe_setup_event+0x104>
      6c:      	cbz	x19, 0x344 <generic_kprobe_setup_event+0x344>
      70:      	add	x2, x19, #0x110
      74:      	mov	w25, #0x8               // =8
      78:      	add	x8, sp, #0x18
      7c:      	mov	w9, #0x4                // =4
      80:      	add	x0, sp, #0x18
      84:      	mov	w1, #0x8                // =8
      88:      	mov	w24, #0x4               // =4
      8c:      	blr	x9
      90:      	ldr	x8, [sp, #0x18]
      94:      	add	x2, x19, #0x8
      98:      	mov	w9, #0x4                // =4
      9c:      	add	x0, sp, #0x18
      a0:      	str	x8, [x22, #0x5e50]
      a4:      	add	x8, sp, #0x18
      a8:      	mov	w1, #0x8                // =8
      ac:      	blr	x9
      b0:      	ldr	x8, [sp, #0x18]
      b4:      	add	x2, x19, #0x10
      b8:      	mov	w9, #0x4                // =4
      bc:      	add	x0, sp, #0x18
      c0:      	str	x8, [x22, #0x5e58]
      c4:      	add	x8, sp, #0x18
      c8:      	mov	w1, #0x8                // =8
      cc:      	blr	x9
      d0:      	ldr	x8, [sp, #0x18]
      d4:      	add	x2, x19, #0x18
      d8:      	mov	w9, #0x4                // =4
      dc:      	add	x0, sp, #0x18
      e0:      	str	x8, [x22, #0x5e60]
      e4:      	add	x8, sp, #0x18
      e8:      	mov	w1, #0x8                // =8
      ec:      	blr	x9
      f0:      	ldr	x8, [sp, #0x18]
      f4:      	add	x2, x19, #0x20
      f8:      	str	x8, [x22, #0x5e68]
      fc:      	add	x8, sp, #0x18
     100:      	b	0x194 <generic_kprobe_setup_event+0x194>
     104:      	mov	w25, #0x8               // =8
     108:      	add	x8, sp, #0x18
     10c:      	mov	w9, #0x4                // =4
     110:      	add	x0, sp, #0x18
     114:      	mov	w1, #0x8                // =8
     118:      	mov	x2, x19
     11c:      	mov	w24, #0x4               // =4
     120:      	blr	x9
     124:      	ldr	x8, [sp, #0x18]
     128:      	add	x2, x19, #0x8
     12c:      	mov	w9, #0x4                // =4
     130:      	add	x0, sp, #0x18
     134:      	str	x8, [x22, #0x5e50]
     138:      	add	x8, sp, #0x18
     13c:      	mov	w1, #0x8                // =8
     140:      	blr	x9
     144:      	ldr	x8, [sp, #0x18]
     148:      	add	x2, x19, #0x10
     14c:      	mov	w9, #0x4                // =4
     150:      	add	x0, sp, #0x18
     154:      	str	x8, [x22, #0x5e58]
     158:      	add	x8, sp, #0x18
     15c:      	mov	w1, #0x8                // =8
     160:      	blr	x9
     164:      	ldr	x8, [sp, #0x18]
     168:      	add	x2, x19, #0x18
     16c:      	mov	w9, #0x4                // =4
     170:      	add	x0, sp, #0x18
     174:      	str	x8, [x22, #0x5e60]
     178:      	add	x8, sp, #0x18
     17c:      	mov	w1, #0x8                // =8
     180:      	blr	x9
     184:      	ldr	x8, [sp, #0x18]
     188:      	add	x2, x19, #0x20
     18c:      	str	x8, [x22, #0x5e68]
     190:      	add	x8, sp, #0x18
     194:      	add	x0, sp, #0x18
     198:      	mov	w1, #0x8                // =8
     19c:      	blr	x24
     1a0:      	ldr	x8, [sp, #0x18]
     1a4:      	strh	wzr, [x22, #0x2]
     1a8:      	str	wzr, [x22, #0x4]
     1ac:      	str	x8, [x22, #0x5e70]
     1b0:      	mov	w8, #0xd                // =13
     1b4:      	strb	w8, [x22]
     1b8:      	mov	w8, #0x7d               // =125
     1bc:      	blr	x8
     1c0:      	str	x0, [x22, #0x8]
     1c4:      	str	xzr, [x22, #0x70]
     1c8:      	mov	w8, #0xe                // =14
     1cc:      	mov	w24, #0xe               // =14
     1d0:      	str	wzr, [x22, #0x14]
     1d4:      	blr	x8
     1d8:      	str	w0, [x22, #0x7c]
     1dc:      	blr	x24
     1e0:      	cmn	x0, #0x16
     1e4:      	b.ne	0x208 <generic_kprobe_setup_event+0x208>
     1e8:      	add	x2, x19, #0xe8
     1ec:      	mov	w8, #0x8                // =8
     1f0:      	mov	w9, #0x4                // =4
     1f4:      	add	x10, sp, #0x18
     1f8:      	add	x0, sp, #0x18
     1fc:      	mov	w1, #0x8                // =8
     200:      	blr	x9
     204:      	ldr	x0, [sp, #0x18]
     208:      	str	x0, [x22, #0x68]
     20c:      	ldr	w8, [x23, #0x5c]
     210:      	cmp	w8, #0x1
     214:      	b.lt	0x2cc <generic_kprobe_setup_event+0x2cc>
     218:      	ldr	x8, [x22, #0x60]
     21c:      	ldr	x9, [x22, #0x8]
     220:      	mov	w10, #0x1               // =1
     224:      	mov	x3, xzr
     228:      	add	x1, sp, #0x8
     22c:      	add	x2, sp, #0x18
     230:      	str	xzr, [sp, #0x28]
     234:      	stp	x9, x10, [sp, #0x18]
     238:      	stp	x8, x0, [sp, #0x8]
     23c:      	adrp	x0, 0x0 <generic_kprobe_setup_event>
     240:      	mov	w8, #0x2                // =2
     244:      	add	x9, sp, #0x8
     248:      	add	x10, sp, #0x18
     24c:      	ldr	x0, [x0]
     250:      	blr	x8
     254:      	cbz	x0, 0x2cc <generic_kprobe_setup_event+0x2cc>
     258:      	neg	w8, w0
     25c:      	adrp	x22, 0x0 <generic_kprobe_setup_event>
     260:      	mov	w9, #0x1                // =1
     264:      	strh	w8, [sp, #0x34]
     268:      	mov	w8, #0x5                // =5
     26c:      	add	x1, sp, #0x34
     270:      	mov	w23, #0x1               // =1
     274:      	strh	w8, [sp, #0x36]
     278:      	mov	x8, #0x46               // =70
     27c:      	movk	x8, #0x2, lsl #32
     280:      	stur	x8, [sp, #0x38]
     284:      	add	x8, sp, #0x34
     288:      	ldr	x22, [x22]
     28c:      	mov	x0, x22
     290:      	blr	x9
     294:      	cbz	x0, 0x2a8 <generic_kprobe_setup_event+0x2a8>
     298:      	ldr	w8, [x0]
     29c:      	add	w8, w8, #0x1
     2a0:      	str	w8, [x0]
     2a4:      	b	0x2cc <generic_kprobe_setup_event+0x2cc>
     2a8:      	str	w23, [sp, #0x30]
     2ac:      	mov	x3, xzr
     2b0:      	mov	w8, #0x2                // =2
     2b4:      	add	x9, sp, #0x34
     2b8:      	add	x10, sp, #0x30
     2bc:      	add	x1, sp, #0x34
     2c0:      	add	x2, sp, #0x30
     2c4:      	mov	x0, x22
     2c8:      	blr	x8
     2cc:      	str	wzr, [sp, #0x18]
     2d0:      	mov	w8, #0x1                // =1
     2d4:      	add	x9, sp, #0x18
     2d8:      	add	x1, sp, #0x18
     2dc:      	mov	x0, x20
     2e0:      	blr	x8
     2e4:      	adrp	x20, 0x0 <generic_kprobe_setup_event>
     2e8:      	ldr	x20, [x20]
     2ec:      	cbz	x0, 0x314 <generic_kprobe_setup_event+0x314>
     2f0:      	mov	w8, #0x5ef8             // =24312
     2f4:      	add	x1, x0, x8
     2f8:      	mov	w8, #0x1                // =1
     2fc:      	mov	x0, x21
     300:      	blr	x8
     304:      	cbz	x0, 0x314 <generic_kprobe_setup_event+0x314>
     308:      	ldr	w8, [x0, #0x40]
     30c:      	cmn	w8, #0x1
     310:      	b.ne	0x32c <generic_kprobe_setup_event+0x32c>
     314:      	mov	w8, #0x3                // =3
     318:      	mov	w9, #0xc                // =12
     31c:      	mov	x0, x19
     320:      	mov	x1, x20
     324:      	mov	w2, #0x3                // =3
     328:      	blr	x9
     32c:      	mov	w8, #0x1                // =1
     330:      	mov	w9, #0xc                // =12
     334:      	mov	x0, x19
     338:      	mov	x1, x20
     33c:      	mov	w2, #0x1                // =1
     340:      	blr	x9
     344:      	ldp	x20, x19, [sp, #0x70]
     348:      	mov	w0, wzr
     34c:      	ldp	x22, x21, [sp, #0x60]
     350:      	ldp	x24, x23, [sp, #0x50]
     354:      	ldp	x30, x25, [sp, #0x40]
     358:      	add	sp, sp, #0x80
     35c:      	ret

0000000000000360 <generic_kprobe_process_event>:
     360:      	sub	sp, sp, #0x160
     364:      	str	x29, [sp, #0x110]
     368:      	stp	x30, x25, [sp, #0x120]
     36c:      	stp	x24, x23, [sp, #0x130]
     370:      	stp	x22, x21, [sp, #0x140]
     374:      	stp	x20, x19, [sp, #0x150]
     378:      	str	wzr, [sp, #0x6c]
     37c:      	adrp	x22, 0x0 <generic_kprobe_setup_event>
     380:      	mov	w8, #0x1                // =1
     384:      	add	x9, sp, #0x6c
     388:      	ldr	x22, [x22]
     38c:      	mov	x19, x0
     390:      	add	x1, sp, #0x6c
     394:      	mov	x0, x22
     398:      	blr	x8
     39c:      	cbz	x0, 0x1d5c <generic_kprobe_process_event+0x19fc>
     3a0:      	ldr	w25, [x0, #0x4]
     3a4:      	mov	w29, #0x5efc            // =24316
     3a8:      	adrp	x24, 0x0 <generic_kprobe_setup_event>
     3ac:      	mov	x20, x0
     3b0:      	ldr	w21, [x0, x29]
     3b4:      	ldr	x24, [x24]
     3b8:      	lsr	w8, w25, #3
     3bc:      	cmp	w8, #0x464
     3c0:      	b.hi	0x1cc8 <generic_kprobe_process_event+0x1968>
     3c4:      	str	wzr, [sp, #0x78]
     3c8:      	mov	w8, #0x1                // =1
     3cc:      	add	x9, sp, #0x78
     3d0:      	add	x1, sp, #0x78
     3d4:      	mov	x0, x22
     3d8:      	blr	x8
     3dc:      	cbz	x0, 0x1cc8 <generic_kprobe_process_event+0x1968>
     3e0:      	mov	w8, #0x5ef8             // =24312
     3e4:      	mov	x23, x0
     3e8:      	add	x1, x0, x8
     3ec:      	adrp	x0, 0x0 <generic_kprobe_setup_event>
     3f0:      	mov	w8, #0x1                // =1
     3f4:      	ldr	x0, [x0]
     3f8:      	blr	x8
     3fc:      	cmp	w21, #0x4
     400:      	ccmp	x0, #0x0, #0x4, le
     404:      	b.eq	0x1cc8 <generic_kprobe_process_event+0x1968>
     408:      	str	x21, [sp, #0x60]
     40c:      	and	x21, x21, #0x7
     410:      	str	x25, [sp, #0x118]
     414:      	add	x8, x0, x21, lsl #2
     418:      	add	x14, x23, x21, lsl #2
     41c:      	ldrsw	x12, [x8, #0x18]
     420:      	ldr	w11, [x8, #0x4]
     424:      	mov	w8, #0x5ea0             // =24224
     428:      	str	wzr, [x14, x8]
     42c:      	and	x13, x12, #0xffffffff
     430:      	str	x11, [sp, #0x58]
     434:      	tbnz	w12, #0x8, 0x45c <generic_kprobe_process_event+0xfc>
     438:      	str	x14, [sp, #0x50]
     43c:      	tbnz	w12, #0x7, 0x464 <generic_kprobe_process_event+0x104>
     440:      	tbnz	w13, #0x6, 0x4ec <generic_kprobe_process_event+0x18c>
     444:      	add	x8, x0, x21, lsl #2
     448:      	ldr	w8, [x8, #0x40]
     44c:      	and	x8, x8, #0x7
     450:      	add	x8, x23, x8, lsl #3
     454:      	ldr	x8, [x8, #0x5e50]
     458:      	b	0x7c4 <generic_kprobe_process_event+0x464>
     45c:      	str	xzr, [sp, #0x70]
     460:      	b	0xf18 <generic_kprobe_process_event+0xbb8>
     464:      	add	x8, x0, x21, lsl #2
     468:      	mov	w10, #0x40              // =64
     46c:      	ldrb	w9, [x8, #0x2c2]
     470:      	sub	w15, w10, w9, lsl #3
     474:      	ldr	w10, [x0, #0x54]
     478:      	ldrh	w9, [x8, #0x2c0]
     47c:      	cbz	w10, 0x528 <generic_kprobe_process_event+0x1c8>
     480:      	cbz	x19, 0x570 <generic_kprobe_process_event+0x210>
     484:      	add	x2, x19, x9
     488:      	mov	w8, #0x8                // =8
     48c:      	mov	w9, #0x4                // =4
     490:      	add	x10, sp, #0xa8
     494:      	str	x20, [sp, #0x40]
     498:      	mov	x25, x24
     49c:      	mov	x24, x0
     4a0:      	add	x0, sp, #0xa8
     4a4:      	mov	w1, #0x8                // =8
     4a8:      	mov	x29, x12
     4ac:      	mov	x23, x13
     4b0:      	mov	x20, x21
     4b4:      	mov	x21, x15
     4b8:      	blr	x9
     4bc:      	ldr	x8, [sp, #0xa8]
     4c0:      	ldr	x11, [sp, #0x58]
     4c4:      	mov	x0, x24
     4c8:      	mov	x24, x25
     4cc:      	mov	x13, x23
     4d0:      	mov	x12, x29
     4d4:      	ldr	x25, [sp, #0x118]
     4d8:      	lsl	x8, x8, x21
     4dc:      	asr	x8, x8, x21
     4e0:      	mov	x21, x20
     4e4:      	ldr	x20, [sp, #0x40]
     4e8:      	b	0x7c4 <generic_kprobe_process_event+0x464>
     4ec:      	mov	w8, #0x23               // =35
     4f0:      	mov	x23, x0
     4f4:      	mov	x29, x12
     4f8:      	mov	x22, x21
     4fc:      	mov	x21, x13
     500:      	blr	x8
     504:      	mov	x13, x21
     508:      	mov	x21, x22
     50c:      	adrp	x22, 0x0 <generic_kprobe_setup_event>
     510:      	ldr	x22, [x22]
     514:      	ldr	x11, [sp, #0x58]
     518:      	mov	x12, x29
     51c:      	mov	x8, x0
     520:      	mov	x0, x23
     524:      	b	0x7c4 <generic_kprobe_process_event+0x464>
     528:      	ror	w9, w9, #0x3
     52c:      	mov	x8, xzr
     530:      	cmp	w9, #0xf
     534:      	b.le	0x578 <generic_kprobe_process_event+0x218>
     538:      	cmp	w9, #0x17
     53c:      	b.le	0x5cc <generic_kprobe_process_event+0x26c>
     540:      	cmp	w9, #0x1b
     544:      	b.le	0x5f4 <generic_kprobe_process_event+0x294>
     548:      	cmp	w9, #0x1d
     54c:      	b.le	0x68c <generic_kprobe_process_event+0x32c>
     550:      	cmp	w9, #0x1e
     554:      	b.eq	0x7b4 <generic_kprobe_process_event+0x454>
     558:      	cmp	w9, #0x20
     55c:      	b.eq	0x74c <generic_kprobe_process_event+0x3ec>
     560:      	cmp	w9, #0x1f
     564:      	b.ne	0x7c4 <generic_kprobe_process_event+0x464>
     568:      	ldr	x8, [x19, #0xf8]
     56c:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     570:      	mov	x8, xzr
     574:      	b	0x7c4 <generic_kprobe_process_event+0x464>
     578:      	cmp	w9, #0x7
     57c:      	b.gt	0x5a4 <generic_kprobe_process_event+0x244>
     580:      	cmp	w9, #0x3
     584:      	b.gt	0x614 <generic_kprobe_process_event+0x2b4>
     588:      	cmp	w9, #0x1
     58c:      	b.gt	0x6a4 <generic_kprobe_process_event+0x344>
     590:      	cbz	w9, 0x754 <generic_kprobe_process_event+0x3f4>
     594:      	cmp	w9, #0x1
     598:      	b.ne	0x7c4 <generic_kprobe_process_event+0x464>
     59c:      	ldr	x8, [x19, #0x8]
     5a0:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     5a4:      	cmp	w9, #0xb
     5a8:      	b.gt	0x634 <generic_kprobe_process_event+0x2d4>
     5ac:      	cmp	w9, #0x9
     5b0:      	b.gt	0x6bc <generic_kprobe_process_event+0x35c>
     5b4:      	cmp	w9, #0x8
     5b8:      	b.eq	0x75c <generic_kprobe_process_event+0x3fc>
     5bc:      	cmp	w9, #0x9
     5c0:      	b.ne	0x7c4 <generic_kprobe_process_event+0x464>
     5c4:      	ldr	x8, [x19, #0x48]
     5c8:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     5cc:      	cmp	w9, #0x13
     5d0:      	b.gt	0x654 <generic_kprobe_process_event+0x2f4>
     5d4:      	cmp	w9, #0x11
     5d8:      	b.gt	0x704 <generic_kprobe_process_event+0x3a4>
     5dc:      	cmp	w9, #0x10
     5e0:      	b.eq	0x794 <generic_kprobe_process_event+0x434>
     5e4:      	cmp	w9, #0x11
     5e8:      	b.ne	0x7c4 <generic_kprobe_process_event+0x464>
     5ec:      	ldr	x8, [x19, #0x88]
     5f0:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     5f4:      	cmp	w9, #0x19
     5f8:      	b.gt	0x674 <generic_kprobe_process_event+0x314>
     5fc:      	cmp	w9, #0x18
     600:      	b.eq	0x734 <generic_kprobe_process_event+0x3d4>
     604:      	cmp	w9, #0x19
     608:      	b.ne	0x7c4 <generic_kprobe_process_event+0x464>
     60c:      	ldr	x8, [x19, #0xc8]
     610:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     614:      	cmp	w9, #0x5
     618:      	b.gt	0x6d4 <generic_kprobe_process_event+0x374>
     61c:      	cmp	w9, #0x4
     620:      	b.eq	0x764 <generic_kprobe_process_event+0x404>
     624:      	cmp	w9, #0x5
     628:      	b.ne	0x7c4 <generic_kprobe_process_event+0x464>
     62c:      	ldr	x8, [x19, #0x28]
     630:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     634:      	cmp	w9, #0xd
     638:      	b.gt	0x6ec <generic_kprobe_process_event+0x38c>
     63c:      	cmp	w9, #0xc
     640:      	b.eq	0x76c <generic_kprobe_process_event+0x40c>
     644:      	cmp	w9, #0xd
     648:      	b.ne	0x7c4 <generic_kprobe_process_event+0x464>
     64c:      	ldr	x8, [x19, #0x68]
     650:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     654:      	cmp	w9, #0x15
     658:      	b.gt	0x71c <generic_kprobe_process_event+0x3bc>
     65c:      	cmp	w9, #0x14
     660:      	b.eq	0x79c <generic_kprobe_process_event+0x43c>
     664:      	cmp	w9, #0x15
     668:      	b.ne	0x7c4 <generic_kprobe_process_event+0x464>
     66c:      	ldr	x8, [x19, #0xa8]
     670:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     674:      	cmp	w9, #0x1a
     678:      	b.eq	0x73c <generic_kprobe_process_event+0x3dc>
     67c:      	cmp	w9, #0x1b
     680:      	b.ne	0x7c4 <generic_kprobe_process_event+0x464>
     684:      	ldr	x8, [x19, #0xd8]
     688:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     68c:      	cmp	w9, #0x1c
     690:      	b.eq	0x744 <generic_kprobe_process_event+0x3e4>
     694:      	cmp	w9, #0x1d
     698:      	b.ne	0x7c4 <generic_kprobe_process_event+0x464>
     69c:      	ldr	x8, [x19, #0xe8]
     6a0:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     6a4:      	cmp	w9, #0x2
     6a8:      	b.eq	0x774 <generic_kprobe_process_event+0x414>
     6ac:      	cmp	w9, #0x3
     6b0:      	b.ne	0x7c4 <generic_kprobe_process_event+0x464>
     6b4:      	ldr	x8, [x19, #0x18]
     6b8:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     6bc:      	cmp	w9, #0xa
     6c0:      	b.eq	0x77c <generic_kprobe_process_event+0x41c>
     6c4:      	cmp	w9, #0xb
     6c8:      	b.ne	0x7c4 <generic_kprobe_process_event+0x464>
     6cc:      	ldr	x8, [x19, #0x58]
     6d0:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     6d4:      	cmp	w9, #0x6
     6d8:      	b.eq	0x784 <generic_kprobe_process_event+0x424>
     6dc:      	cmp	w9, #0x7
     6e0:      	b.ne	0x7c4 <generic_kprobe_process_event+0x464>
     6e4:      	ldr	x8, [x19, #0x38]
     6e8:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     6ec:      	cmp	w9, #0xe
     6f0:      	b.eq	0x78c <generic_kprobe_process_event+0x42c>
     6f4:      	cmp	w9, #0xf
     6f8:      	b.ne	0x7c4 <generic_kprobe_process_event+0x464>
     6fc:      	ldr	x8, [x19, #0x78]
     700:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     704:      	cmp	w9, #0x12
     708:      	b.eq	0x7a4 <generic_kprobe_process_event+0x444>
     70c:      	cmp	w9, #0x13
     710:      	b.ne	0x7c4 <generic_kprobe_process_event+0x464>
     714:      	ldr	x8, [x19, #0x98]
     718:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     71c:      	cmp	w9, #0x16
     720:      	b.eq	0x7ac <generic_kprobe_process_event+0x44c>
     724:      	cmp	w9, #0x17
     728:      	b.ne	0x7c4 <generic_kprobe_process_event+0x464>
     72c:      	ldr	x8, [x19, #0xb8]
     730:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     734:      	ldr	x8, [x19, #0xc0]
     738:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     73c:      	ldr	x8, [x19, #0xd0]
     740:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     744:      	ldr	x8, [x19, #0xe0]
     748:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     74c:      	ldr	x8, [x19, #0x100]
     750:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     754:      	ldr	x8, [x19]
     758:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     75c:      	ldr	x8, [x19, #0x40]
     760:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     764:      	ldr	x8, [x19, #0x20]
     768:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     76c:      	ldr	x8, [x19, #0x60]
     770:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     774:      	ldr	x8, [x19, #0x10]
     778:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     77c:      	ldr	x8, [x19, #0x50]
     780:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     784:      	ldr	x8, [x19, #0x30]
     788:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     78c:      	ldr	x8, [x19, #0x70]
     790:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     794:      	ldr	x8, [x19, #0x80]
     798:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     79c:      	ldr	x8, [x19, #0xa0]
     7a0:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     7a4:      	ldr	x8, [x19, #0x90]
     7a8:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     7ac:      	ldr	x8, [x19, #0xb0]
     7b0:      	b	0x7b8 <generic_kprobe_process_event+0x458>
     7b4:      	ldr	x8, [x19, #0xf0]
     7b8:      	mov	x9, #-0x1               // =-1
     7bc:      	lsr	x9, x9, x15
     7c0:      	and	x8, x8, x9
     7c4:      	cmp	w21, #0x4
     7c8:      	str	x8, [sp, #0x70]
     7cc:      	b.hi	0xf18 <generic_kprobe_process_event+0xbb8>
     7d0:      	mov	w9, #0x50               // =80
     7d4:      	umaddl	x14, w21, w9, x0
     7d8:      	ldrh	w9, [x14, #0x76]
     7dc:      	cbz	w9, 0xf18 <generic_kprobe_process_event+0xbb8>
     7e0:      	adrp	x9, 0x0 <generic_kprobe_setup_event>
     7e4:      	ldr	x9, [x9]
     7e8:      	ldrb	w10, [x9]
     7ec:      	ldur	w9, [x14, #0x70]
     7f0:      	str	x14, [sp, #0x48]
     7f4:      	add	x8, x8, x9
     7f8:      	str	x8, [sp, #0x70]
     7fc:      	ldurh	w9, [x14, #0x74]
     800:      	cbz	w10, 0xb68 <generic_kprobe_process_event+0x808>
     804:      	cbz	w9, 0x840 <generic_kprobe_process_event+0x4e0>
     808:      	mov	w9, #0x8                // =8
     80c:      	mov	w10, #0x4               // =4
     810:      	add	x11, sp, #0x70
     814:      	ldr	x2, [sp, #0x70]
     818:      	add	x0, sp, #0x70
     81c:      	mov	w1, #0x8                // =8
     820:      	mov	x29, x12
     824:      	mov	x23, x13
     828:      	blr	x10
     82c:      	ldr	x14, [sp, #0x48]
     830:      	ldr	x11, [sp, #0x58]
     834:      	mov	x13, x23
     838:      	mov	x12, x29
     83c:      	tbnz	w0, #0x1f, 0xef4 <generic_kprobe_process_event+0xb94>
     840:      	ldurh	w8, [x14, #0x7e]
     844:      	cbz	w8, 0xf18 <generic_kprobe_process_event+0xbb8>
     848:      	ldr	x8, [sp, #0x70]
     84c:      	ldur	w9, [x14, #0x78]
     850:      	add	x8, x8, x9
     854:      	str	x8, [sp, #0x70]
     858:      	ldurh	w9, [x14, #0x7c]
     85c:      	cbz	w9, 0x898 <generic_kprobe_process_event+0x538>
     860:      	mov	w9, #0x8                // =8
     864:      	mov	w10, #0x4               // =4
     868:      	add	x11, sp, #0x70
     86c:      	ldr	x2, [sp, #0x70]
     870:      	add	x0, sp, #0x70
     874:      	mov	w1, #0x8                // =8
     878:      	mov	x29, x12
     87c:      	mov	x23, x13
     880:      	blr	x10
     884:      	ldr	x14, [sp, #0x48]
     888:      	ldr	x11, [sp, #0x58]
     88c:      	mov	x13, x23
     890:      	mov	x12, x29
     894:      	tbnz	w0, #0x1f, 0xefc <generic_kprobe_process_event+0xb9c>
     898:      	ldurh	w8, [x14, #0x86]
     89c:      	cbz	w8, 0xf18 <generic_kprobe_process_event+0xbb8>
     8a0:      	ldr	x8, [sp, #0x70]
     8a4:      	ldur	w9, [x14, #0x80]
     8a8:      	add	x8, x8, x9
     8ac:      	str	x8, [sp, #0x70]
     8b0:      	ldurh	w9, [x14, #0x84]
     8b4:      	cbz	w9, 0x8f0 <generic_kprobe_process_event+0x590>
     8b8:      	mov	w9, #0x8                // =8
     8bc:      	mov	w10, #0x4               // =4
     8c0:      	add	x11, sp, #0x70
     8c4:      	ldr	x2, [sp, #0x70]
     8c8:      	add	x0, sp, #0x70
     8cc:      	mov	w1, #0x8                // =8
     8d0:      	mov	x29, x12
     8d4:      	mov	x23, x13
     8d8:      	blr	x10
     8dc:      	ldr	x14, [sp, #0x48]
     8e0:      	ldr	x11, [sp, #0x58]
     8e4:      	mov	x13, x23
     8e8:      	mov	x12, x29
     8ec:      	tbnz	w0, #0x1f, 0xf04 <generic_kprobe_process_event+0xba4>
     8f0:      	ldurh	w8, [x14, #0x8e]
     8f4:      	cbz	w8, 0xf18 <generic_kprobe_process_event+0xbb8>
     8f8:      	ldr	x8, [sp, #0x70]
     8fc:      	ldur	w9, [x14, #0x88]
     900:      	add	x8, x8, x9
     904:      	str	x8, [sp, #0x70]
     908:      	ldurh	w9, [x14, #0x8c]
     90c:      	cbz	w9, 0x94c <generic_kprobe_process_event+0x5ec>
     910:      	mov	w9, #0x8                // =8
     914:      	add	x10, sp, #0x70
     918:      	mov	w11, #0x4               // =4
     91c:      	ldr	x2, [sp, #0x70]
     920:      	add	x0, sp, #0x70
     924:      	mov	w1, #0x8                // =8
     928:      	mov	w25, #0x4               // =4
     92c:      	mov	x29, x12
     930:      	mov	x23, x13
     934:      	blr	x11
     938:      	ldr	x14, [sp, #0x48]
     93c:      	ldr	x11, [sp, #0x58]
     940:      	mov	x13, x23
     944:      	mov	x12, x29
     948:      	tbnz	w0, #0x1f, 0xf08 <generic_kprobe_process_event+0xba8>
     94c:      	ldurh	w8, [x14, #0x96]
     950:      	ldr	x25, [sp, #0x118]
     954:      	cbz	w8, 0xf18 <generic_kprobe_process_event+0xbb8>
     958:      	ldr	x8, [sp, #0x70]
     95c:      	ldur	w9, [x14, #0x90]
     960:      	add	x8, x8, x9
     964:      	str	x8, [sp, #0x70]
     968:      	ldurh	w9, [x14, #0x94]
     96c:      	cbz	w9, 0x9a8 <generic_kprobe_process_event+0x648>
     970:      	mov	w9, #0x8                // =8
     974:      	mov	w10, #0x4               // =4
     978:      	add	x11, sp, #0x70
     97c:      	ldr	x2, [sp, #0x70]
     980:      	add	x0, sp, #0x70
     984:      	mov	w1, #0x8                // =8
     988:      	mov	x29, x12
     98c:      	mov	x23, x13
     990:      	blr	x10
     994:      	ldr	x14, [sp, #0x48]
     998:      	ldr	x11, [sp, #0x58]
     99c:      	mov	x13, x23
     9a0:      	mov	x12, x29
     9a4:      	tbnz	w0, #0x1f, 0x1d7c <generic_kprobe_process_event+0x1a1c>
     9a8:      	ldurh	w8, [x14, #0x9e]
     9ac:      	cbz	w8, 0xf18 <generic_kprobe_process_event+0xbb8>
     9b0:      	ldr	x8, [sp, #0x70]
     9b4:      	ldur	w9, [x14, #0x98]
     9b8:      	mov	x29, x12
     9bc:      	add	x8, x8, x9
     9c0:      	str	x13, [sp, #0x38]
     9c4:      	str	x8, [sp, #0x70]
     9c8:      	ldurh	w9, [x14, #0x9c]
     9cc:      	cbz	w9, 0x9f0 <generic_kprobe_process_event+0x690>
     9d0:      	mov	w9, #0x8                // =8
     9d4:      	mov	w10, #0x4               // =4
     9d8:      	add	x11, sp, #0x70
     9dc:      	ldr	x2, [sp, #0x70]
     9e0:      	add	x0, sp, #0x70
     9e4:      	mov	w1, #0x8                // =8
     9e8:      	blr	x10
     9ec:      	tbnz	w0, #0x1f, 0x1fd8 <generic_kprobe_process_event+0x1c78>
     9f0:      	ldr	x10, [sp, #0x48]
     9f4:      	ldr	x11, [sp, #0x58]
     9f8:      	mov	x12, x29
     9fc:      	ldr	x13, [sp, #0x38]
     a00:      	ldurh	w8, [x10, #0xa6]
     a04:      	cbz	w8, 0xf18 <generic_kprobe_process_event+0xbb8>
     a08:      	ldr	x8, [sp, #0x70]
     a0c:      	ldur	w9, [x10, #0xa0]
     a10:      	mov	x23, x21
     a14:      	add	x8, x8, x9
     a18:      	str	x20, [sp, #0x40]
     a1c:      	str	x19, [sp, #0x10]
     a20:      	str	x8, [sp, #0x70]
     a24:      	ldurh	w9, [x10, #0xa4]
     a28:      	cbz	w9, 0xa4c <generic_kprobe_process_event+0x6ec>
     a2c:      	mov	w9, #0x8                // =8
     a30:      	mov	w10, #0x4               // =4
     a34:      	add	x11, sp, #0x70
     a38:      	ldr	x2, [sp, #0x70]
     a3c:      	add	x0, sp, #0x70
     a40:      	mov	w1, #0x8                // =8
     a44:      	blr	x10
     a48:      	tbnz	w0, #0x1f, 0x2178 <generic_kprobe_process_event+0x1e18>
     a4c:      	ldp	x20, x10, [sp, #0x40]
     a50:      	adrp	x24, 0x0 <generic_kprobe_setup_event>
     a54:      	adrp	x22, 0x0 <generic_kprobe_setup_event>
     a58:      	mov	x12, x29
     a5c:      	mov	x21, x23
     a60:      	ldurh	w8, [x10, #0xae]
     a64:      	ldr	x24, [x24]
     a68:      	ldr	x25, [sp, #0x118]
     a6c:      	ldr	x11, [sp, #0x58]
     a70:      	ldr	x13, [sp, #0x38]
     a74:      	ldr	x22, [x22]
     a78:      	ldr	x19, [sp, #0x10]
     a7c:      	cbz	w8, 0xf18 <generic_kprobe_process_event+0xbb8>
     a80:      	ldr	x8, [sp, #0x70]
     a84:      	ldur	w9, [x10, #0xa8]
     a88:      	add	x8, x8, x9
     a8c:      	str	x8, [sp, #0x70]
     a90:      	ldurh	w9, [x10, #0xac]
     a94:      	cbz	w9, 0xac8 <generic_kprobe_process_event+0x768>
     a98:      	mov	w25, #0x8               // =8
     a9c:      	mov	w9, #0x4                // =4
     aa0:      	add	x10, sp, #0x70
     aa4:      	ldr	x2, [sp, #0x70]
     aa8:      	add	x0, sp, #0x70
     aac:      	mov	w1, #0x8                // =8
     ab0:      	blr	x9
     ab4:      	ldr	x10, [sp, #0x48]
     ab8:      	ldr	x13, [sp, #0x38]
     abc:      	mov	x12, x29
     ac0:      	ldr	x11, [sp, #0x58]
     ac4:      	tbnz	w0, #0x1f, 0xf08 <generic_kprobe_process_event+0xba8>
     ac8:      	ldurh	w8, [x10, #0xb6]
     acc:      	ldr	x25, [sp, #0x118]
     ad0:      	cbz	w8, 0xf18 <generic_kprobe_process_event+0xbb8>
     ad4:      	ldr	x8, [sp, #0x70]
     ad8:      	ldur	w9, [x10, #0xb0]
     adc:      	add	x8, x8, x9
     ae0:      	str	x8, [sp, #0x70]
     ae4:      	ldurh	w9, [x10, #0xb4]
     ae8:      	cbz	w9, 0xb0c <generic_kprobe_process_event+0x7ac>
     aec:      	mov	w9, #0x8                // =8
     af0:      	mov	w10, #0x4               // =4
     af4:      	add	x11, sp, #0x70
     af8:      	ldr	x2, [sp, #0x70]
     afc:      	add	x0, sp, #0x70
     b00:      	mov	w1, #0x8                // =8
     b04:      	blr	x10
     b08:      	tbnz	w0, #0x1f, 0x2ed0 <generic_kprobe_process_event+0x2b70>
     b0c:      	ldp	x20, x10, [sp, #0x40]
     b10:      	adrp	x24, 0x0 <generic_kprobe_setup_event>
     b14:      	adrp	x22, 0x0 <generic_kprobe_setup_event>
     b18:      	mov	x12, x29
     b1c:      	mov	x21, x23
     b20:      	ldurh	w8, [x10, #0xbe]
     b24:      	ldr	x24, [x24]
     b28:      	ldr	x25, [sp, #0x118]
     b2c:      	ldr	x11, [sp, #0x58]
     b30:      	ldr	x13, [sp, #0x38]
     b34:      	ldr	x22, [x22]
     b38:      	ldr	x19, [sp, #0x10]
     b3c:      	cbz	w8, 0xf18 <generic_kprobe_process_event+0xbb8>
     b40:      	ldr	x8, [sp, #0x70]
     b44:      	ldur	w9, [x10, #0xb8]
     b48:      	add	x8, x8, x9
     b4c:      	str	x8, [sp, #0x70]
     b50:      	ldurh	w9, [x10, #0xbc]
     b54:      	cbz	w9, 0xf18 <generic_kprobe_process_event+0xbb8>
     b58:      	mov	w9, #0x8                // =8
     b5c:      	mov	w10, #0x4               // =4
     b60:      	add	x11, sp, #0x70
     b64:      	b	0xecc <generic_kprobe_process_event+0xb6c>
     b68:      	cbz	w9, 0xba4 <generic_kprobe_process_event+0x844>
     b6c:      	mov	w9, #0x8                // =8
     b70:      	mov	w10, #0x4               // =4
     b74:      	add	x11, sp, #0x70
     b78:      	ldr	x2, [sp, #0x70]
     b7c:      	add	x0, sp, #0x70
     b80:      	mov	w1, #0x8                // =8
     b84:      	mov	x29, x12
     b88:      	mov	x23, x13
     b8c:      	blr	x10
     b90:      	ldr	x14, [sp, #0x48]
     b94:      	ldr	x11, [sp, #0x58]
     b98:      	mov	x13, x23
     b9c:      	mov	x12, x29
     ba0:      	tbnz	w0, #0x1f, 0xef4 <generic_kprobe_process_event+0xb94>
     ba4:      	ldurh	w8, [x14, #0x7e]
     ba8:      	cbz	w8, 0xf18 <generic_kprobe_process_event+0xbb8>
     bac:      	ldr	x8, [sp, #0x70]
     bb0:      	ldur	w9, [x14, #0x78]
     bb4:      	add	x8, x8, x9
     bb8:      	str	x8, [sp, #0x70]
     bbc:      	ldurh	w9, [x14, #0x7c]
     bc0:      	cbz	w9, 0xbfc <generic_kprobe_process_event+0x89c>
     bc4:      	mov	w9, #0x8                // =8
     bc8:      	mov	w10, #0x4               // =4
     bcc:      	add	x11, sp, #0x70
     bd0:      	ldr	x2, [sp, #0x70]
     bd4:      	add	x0, sp, #0x70
     bd8:      	mov	w1, #0x8                // =8
     bdc:      	mov	x29, x12
     be0:      	mov	x23, x13
     be4:      	blr	x10
     be8:      	ldr	x14, [sp, #0x48]
     bec:      	ldr	x11, [sp, #0x58]
     bf0:      	mov	x13, x23
     bf4:      	mov	x12, x29
     bf8:      	tbnz	w0, #0x1f, 0xefc <generic_kprobe_process_event+0xb9c>
     bfc:      	ldurh	w8, [x14, #0x86]
     c00:      	cbz	w8, 0xf18 <generic_kprobe_process_event+0xbb8>
     c04:      	ldr	x8, [sp, #0x70]
     c08:      	ldur	w9, [x14, #0x80]
     c0c:      	add	x8, x8, x9
     c10:      	str	x8, [sp, #0x70]
     c14:      	ldurh	w9, [x14, #0x84]
     c18:      	cbz	w9, 0xc54 <generic_kprobe_process_event+0x8f4>
     c1c:      	mov	w9, #0x8                // =8
     c20:      	mov	w10, #0x4               // =4
     c24:      	add	x11, sp, #0x70
     c28:      	ldr	x2, [sp, #0x70]
     c2c:      	add	x0, sp, #0x70
     c30:      	mov	w1, #0x8                // =8
     c34:      	mov	x29, x12
     c38:      	mov	x23, x13
     c3c:      	blr	x10
     c40:      	ldr	x14, [sp, #0x48]
     c44:      	ldr	x11, [sp, #0x58]
     c48:      	mov	x13, x23
     c4c:      	mov	x12, x29
     c50:      	tbnz	w0, #0x1f, 0xf04 <generic_kprobe_process_event+0xba4>
     c54:      	ldurh	w8, [x14, #0x8e]
     c58:      	cbz	w8, 0xf18 <generic_kprobe_process_event+0xbb8>
     c5c:      	ldr	x8, [sp, #0x70]
     c60:      	ldur	w9, [x14, #0x88]
     c64:      	add	x8, x8, x9
     c68:      	str	x8, [sp, #0x70]
     c6c:      	ldurh	w9, [x14, #0x8c]
     c70:      	cbz	w9, 0xcb0 <generic_kprobe_process_event+0x950>
     c74:      	mov	w9, #0x8                // =8
     c78:      	add	x10, sp, #0x70
     c7c:      	mov	w11, #0x4               // =4
     c80:      	ldr	x2, [sp, #0x70]
     c84:      	add	x0, sp, #0x70
     c88:      	mov	w1, #0x8                // =8
     c8c:      	mov	w25, #0x4               // =4
     c90:      	mov	x29, x12
     c94:      	mov	x23, x13
     c98:      	blr	x11
     c9c:      	ldr	x14, [sp, #0x48]
     ca0:      	ldr	x11, [sp, #0x58]
     ca4:      	mov	x13, x23
     ca8:      	mov	x12, x29
     cac:      	tbnz	w0, #0x1f, 0xf08 <generic_kprobe_process_event+0xba8>
     cb0:      	ldurh	w8, [x14, #0x96]
     cb4:      	ldr	x25, [sp, #0x118]
     cb8:      	cbz	w8, 0xf18 <generic_kprobe_process_event+0xbb8>
     cbc:      	ldr	x8, [sp, #0x70]
     cc0:      	ldur	w9, [x14, #0x90]
     cc4:      	add	x8, x8, x9
     cc8:      	str	x8, [sp, #0x70]
     ccc:      	ldurh	w9, [x14, #0x94]
     cd0:      	cbz	w9, 0xd08 <generic_kprobe_process_event+0x9a8>
     cd4:      	mov	w9, #0x8                // =8
     cd8:      	mov	w10, #0x4               // =4
     cdc:      	add	x11, sp, #0x70
     ce0:      	ldr	x2, [sp, #0x70]
     ce4:      	add	x0, sp, #0x70
     ce8:      	mov	w1, #0x8                // =8
     cec:      	mov	x29, x12
     cf0:      	mov	x23, x13
     cf4:      	blr	x10
     cf8:      	ldr	x11, [sp, #0x58]
     cfc:      	mov	x13, x23
     d00:      	mov	x12, x29
     d04:      	tbnz	w0, #0x1f, 0x1d7c <generic_kprobe_process_event+0x1a1c>
     d08:      	ldr	x10, [sp, #0x48]
     d0c:      	ldurh	w8, [x10, #0x9e]
     d10:      	cbz	w8, 0xf18 <generic_kprobe_process_event+0xbb8>
     d14:      	ldr	x8, [sp, #0x70]
     d18:      	ldur	w9, [x10, #0x98]
     d1c:      	mov	x29, x12
     d20:      	add	x8, x8, x9
     d24:      	str	x13, [sp, #0x38]
     d28:      	str	x8, [sp, #0x70]
     d2c:      	ldurh	w9, [x10, #0x9c]
     d30:      	cbz	w9, 0xd54 <generic_kprobe_process_event+0x9f4>
     d34:      	mov	w9, #0x8                // =8
     d38:      	mov	w10, #0x4               // =4
     d3c:      	add	x11, sp, #0x70
     d40:      	ldr	x2, [sp, #0x70]
     d44:      	add	x0, sp, #0x70
     d48:      	mov	w1, #0x8                // =8
     d4c:      	blr	x10
     d50:      	tbnz	w0, #0x1f, 0x1fd8 <generic_kprobe_process_event+0x1c78>
     d54:      	ldr	x10, [sp, #0x48]
     d58:      	ldr	x25, [sp, #0x118]
     d5c:      	mov	x12, x29
     d60:      	ldr	x11, [sp, #0x58]
     d64:      	ldr	x13, [sp, #0x38]
     d68:      	ldurh	w8, [x10, #0xa6]
     d6c:      	cbz	w8, 0xf18 <generic_kprobe_process_event+0xbb8>
     d70:      	ldr	x8, [sp, #0x70]
     d74:      	ldur	w9, [x10, #0xa0]
     d78:      	mov	x23, x21
     d7c:      	add	x8, x8, x9
     d80:      	str	x20, [sp, #0x40]
     d84:      	str	x19, [sp, #0x10]
     d88:      	str	x8, [sp, #0x70]
     d8c:      	ldurh	w9, [x10, #0xa4]
     d90:      	cbz	w9, 0xdb4 <generic_kprobe_process_event+0xa54>
     d94:      	mov	w9, #0x8                // =8
     d98:      	mov	w10, #0x4               // =4
     d9c:      	add	x11, sp, #0x70
     da0:      	ldr	x2, [sp, #0x70]
     da4:      	add	x0, sp, #0x70
     da8:      	mov	w1, #0x8                // =8
     dac:      	blr	x10
     db0:      	tbnz	w0, #0x1f, 0x2178 <generic_kprobe_process_event+0x1e18>
     db4:      	ldp	x20, x10, [sp, #0x40]
     db8:      	adrp	x24, 0x0 <generic_kprobe_setup_event>
     dbc:      	adrp	x22, 0x0 <generic_kprobe_setup_event>
     dc0:      	mov	x12, x29
     dc4:      	mov	x21, x23
     dc8:      	ldurh	w8, [x10, #0xae]
     dcc:      	ldr	x24, [x24]
     dd0:      	ldr	x25, [sp, #0x118]
     dd4:      	ldr	x11, [sp, #0x58]
     dd8:      	ldr	x13, [sp, #0x38]
     ddc:      	ldr	x22, [x22]
     de0:      	ldr	x19, [sp, #0x10]
     de4:      	cbz	w8, 0xf18 <generic_kprobe_process_event+0xbb8>
     de8:      	ldr	x8, [sp, #0x70]
     dec:      	ldur	w9, [x10, #0xa8]
     df0:      	add	x8, x8, x9
     df4:      	str	x8, [sp, #0x70]
     df8:      	ldurh	w9, [x10, #0xac]
     dfc:      	cbz	w9, 0xe30 <generic_kprobe_process_event+0xad0>
     e00:      	mov	w25, #0x8               // =8
     e04:      	mov	w9, #0x4                // =4
     e08:      	add	x10, sp, #0x70
     e0c:      	ldr	x2, [sp, #0x70]
     e10:      	add	x0, sp, #0x70
     e14:      	mov	w1, #0x8                // =8
     e18:      	blr	x9
     e1c:      	ldr	x10, [sp, #0x48]
     e20:      	ldr	x13, [sp, #0x38]
     e24:      	mov	x12, x29
     e28:      	ldr	x11, [sp, #0x58]
     e2c:      	tbnz	w0, #0x1f, 0xf08 <generic_kprobe_process_event+0xba8>
     e30:      	ldurh	w8, [x10, #0xb6]
     e34:      	ldr	x25, [sp, #0x118]
     e38:      	cbz	w8, 0xf18 <generic_kprobe_process_event+0xbb8>
     e3c:      	ldr	x8, [sp, #0x70]
     e40:      	ldur	w9, [x10, #0xb0]
     e44:      	add	x8, x8, x9
     e48:      	str	x8, [sp, #0x70]
     e4c:      	ldurh	w9, [x10, #0xb4]
     e50:      	cbz	w9, 0xe74 <generic_kprobe_process_event+0xb14>
     e54:      	mov	w9, #0x8                // =8
     e58:      	mov	w10, #0x4               // =4
     e5c:      	add	x11, sp, #0x70
     e60:      	ldr	x2, [sp, #0x70]
     e64:      	add	x0, sp, #0x70
     e68:      	mov	w1, #0x8                // =8
     e6c:      	blr	x10
     e70:      	tbnz	w0, #0x1f, 0x2ed0 <generic_kprobe_process_event+0x2b70>
     e74:      	ldp	x20, x10, [sp, #0x40]
     e78:      	adrp	x24, 0x0 <generic_kprobe_setup_event>
     e7c:      	adrp	x22, 0x0 <generic_kprobe_setup_event>
     e80:      	mov	x12, x29
     e84:      	mov	x21, x23
     e88:      	ldurh	w8, [x10, #0xbe]
     e8c:      	ldr	x24, [x24]
     e90:      	ldr	x25, [sp, #0x118]
     e94:      	ldr	x11, [sp, #0x58]
     e98:      	ldr	x13, [sp, #0x38]
     e9c:      	ldr	x22, [x22]
     ea0:      	ldr	x19, [sp, #0x10]
     ea4:      	cbz	w8, 0xf18 <generic_kprobe_process_event+0xbb8>
     ea8:      	ldr	x8, [sp, #0x70]
     eac:      	ldur	w9, [x10, #0xb8]
     eb0:      	add	x8, x8, x9
     eb4:      	str	x8, [sp, #0x70]
     eb8:      	ldurh	w9, [x10, #0xbc]
     ebc:      	cbz	w9, 0xf18 <generic_kprobe_process_event+0xbb8>
     ec0:      	mov	w9, #0x8                // =8
     ec4:      	mov	w10, #0x4               // =4
     ec8:      	add	x11, sp, #0x70
     ecc:      	ldr	x2, [sp, #0x70]
     ed0:      	add	x0, sp, #0x70
     ed4:      	mov	w1, #0x8                // =8
     ed8:      	blr	x10
     edc:      	ldr	x13, [sp, #0x38]
     ee0:      	ldr	x11, [sp, #0x58]
     ee4:      	mov	x12, x29
     ee8:      	tbz	w0, #0x1f, 0xf18 <generic_kprobe_process_event+0xbb8>
     eec:      	mov	w25, #0xa               // =10
     ef0:      	b	0xf08 <generic_kprobe_process_event+0xba8>
     ef4:      	mov	w25, #0x1               // =1
     ef8:      	b	0xf08 <generic_kprobe_process_event+0xba8>
     efc:      	mov	w25, #0x2               // =2
     f00:      	b	0xf08 <generic_kprobe_process_event+0xba8>
     f04:      	mov	w25, #0x3               // =3
     f08:      	ldr	x8, [sp, #0x50]
     f0c:      	mov	w9, #0x5ea0             // =24224
     f10:      	str	w25, [x8, x9]
     f14:      	ldr	x25, [sp, #0x118]
     f18:      	mov	x9, #0x8000             // =32768
     f1c:      	mov	w8, #0x1                // =1
     f20:      	cmp	w11, #0x2a
     f24:      	movk	x9, #0x101, lsl #16
     f28:      	lsl	x8, x8, x11
     f2c:      	movk	x9, #0x420, lsl #32
     f30:      	and	x8, x8, x9
     f34:      	ccmp	x8, #0x0, #0x4, ls
     f38:      	b.eq	0x101c <generic_kprobe_process_event+0xcbc>
     f3c:      	str	wzr, [sp, #0xf8]
     f40:      	ldr	x25, [sp, #0x70]
     f44:      	mov	w8, #0x1                // =1
     f48:      	add	x9, sp, #0xf8
     f4c:      	add	x1, sp, #0xf8
     f50:      	mov	x0, x22
     f54:      	blr	x8
     f58:      	cbz	x0, 0xfc4 <generic_kprobe_process_event+0xc64>
     f5c:      	mov	w8, #0x6420             // =25632
     f60:      	mov	x29, x24
     f64:      	mov	x23, x0
     f68:      	add	x24, x0, x8
     f6c:      	ldr	w8, [x24]
     f70:      	cbz	w8, 0xfcc <generic_kprobe_process_event+0xc6c>
     f74:      	str	wzr, [x24]
     f78:      	adrp	x0, 0x0 <generic_kprobe_setup_event>
     f7c:      	mov	w8, #0x1                // =1
     f80:      	add	x9, sp, #0xf8
     f84:      	ldr	x0, [x0]
     f88:      	add	x1, sp, #0xf8
     f8c:      	blr	x8
     f90:      	cbz	x0, 0x1070 <generic_kprobe_process_event+0xd10>
     f94:      	add	x8, x23, x21, lsl #2
     f98:      	mov	w9, #0x5ea0             // =24224
     f9c:      	ldr	x25, [sp, #0x118]
     fa0:      	add	x11, x23, x21, lsl #3
     fa4:      	ldr	w10, [x8, x9]
     fa8:      	add	x8, x23, #0x90
     fac:      	add	x9, x25, #0x4
     fb0:      	str	w10, [x8, x25]
     fb4:      	str	x9, [x11, #0x5e78]
     fb8:      	cbz	w10, 0x10dc <generic_kprobe_process_event+0xd7c>
     fbc:      	mov	w8, #0x4                // =4
     fc0:      	b	0x118c <generic_kprobe_process_event+0xe2c>
     fc4:      	mov	x8, xzr
     fc8:      	b	0x1078 <generic_kprobe_process_event+0xd18>
     fcc:      	add	x8, sp, #0xf0
     fd0:      	str	x25, [sp, #0xa8]
     fd4:      	str	xzr, [x8, #0x10]
     fd8:      	ldr	x8, [sp, #0x58]
     fdc:      	cmp	w8, #0x17
     fe0:      	b.le	0x10b4 <generic_kprobe_process_event+0xd54>
     fe4:      	ldr	x21, [sp, #0x60]
     fe8:      	cmp	w8, #0x18
     fec:      	mov	x24, x29
     ff0:      	b.eq	0x11ec <generic_kprobe_process_event+0xe8c>
     ff4:      	cmp	w8, #0x25
     ff8:      	mov	w29, #0x5efc            // =24316
     ffc:      	b.eq	0x123c <generic_kprobe_process_event+0xedc>
    1000:      	cmp	w8, #0x2a
    1004:      	b.ne	0x12c4 <generic_kprobe_process_event+0xf64>
    1008:      	mov	w8, #0x6430             // =25648
    100c:      	str	xzr, [x23, #0x6430]
    1010:      	str	x25, [x23, #0x6438]
    1014:      	add	x8, x23, x8
    1018:      	b	0x1268 <generic_kprobe_process_event+0xf08>
    101c:      	ldr	x8, [sp, #0x70]
    1020:      	cmp	w11, #0x15
    1024:      	str	x13, [sp, #0x38]
    1028:      	str	x8, [sp, #0x50]
    102c:      	b.gt	0x1088 <generic_kprobe_process_event+0xd28>
    1030:      	mov	w23, #0x1000            // =4096
    1034:      	cmp	w11, #0x9
    1038:      	b.le	0x1198 <generic_kprobe_process_event+0xe38>
    103c:      	cmp	w11, #0x10
    1040:      	mov	w29, #0x5efc            // =24316
    1044:      	b.le	0x12d0 <generic_kprobe_process_event+0xf70>
    1048:      	cmp	w11, #0x12
    104c:      	b.le	0x1368 <generic_kprobe_process_event+0x1008>
    1050:      	cmp	w11, #0x13
    1054:      	b.eq	0x1360 <generic_kprobe_process_event+0x1000>
    1058:      	cmp	w11, #0x14
    105c:      	b.eq	0x13a0 <generic_kprobe_process_event+0x1040>
    1060:      	cmp	w11, #0x15
    1064:      	b.ne	0x13b0 <generic_kprobe_process_event+0x1050>
    1068:      	mov	w23, #0x20              // =32
    106c:      	b	0x13b4 <generic_kprobe_process_event+0x1054>
    1070:      	mov	x8, xzr
    1074:      	mov	x24, x29
    1078:      	ldr	x21, [sp, #0x60]
    107c:      	ldr	x25, [sp, #0x118]
    1080:      	mov	w29, #0x5efc            // =24316
    1084:      	b	0x1cc4 <generic_kprobe_process_event+0x1964>
    1088:      	cmp	w11, #0x20
    108c:      	b.le	0x11c4 <generic_kprobe_process_event+0xe64>
    1090:      	cmp	w11, #0x27
    1094:      	mov	w29, #0x5efc            // =24316
    1098:      	b.gt	0x12f4 <generic_kprobe_process_event+0xf94>
    109c:      	sub	w8, w11, #0x21
    10a0:      	cmp	w8, #0x4
    10a4:      	b.lo	0x12ec <generic_kprobe_process_event+0xf8c>
    10a8:      	cmp	w11, #0x27
    10ac:      	b.eq	0x1340 <generic_kprobe_process_event+0xfe0>
    10b0:      	b	0x13b0 <generic_kprobe_process_event+0x1050>
    10b4:      	ldr	x21, [sp, #0x60]
    10b8:      	add	x25, sp, #0xf0
    10bc:      	cmp	w8, #0xf
    10c0:      	mov	x24, x29
    10c4:      	b.eq	0x1290 <generic_kprobe_process_event+0xf30>
    10c8:      	cmp	w8, #0x10
    10cc:      	mov	w29, #0x5efc            // =24316
    10d0:      	b.ne	0x12c4 <generic_kprobe_process_event+0xf64>
    10d4:      	add	x21, sp, #0x80
    10d8:      	b	0x1214 <generic_kprobe_process_event+0xeb4>
    10dc:      	add	x21, x8, x9
    10e0:      	ldr	w8, [x24, #0x4]
    10e4:      	ldr	x25, [x23, #0x6440]
    10e8:      	mov	w24, #0x4               // =4
    10ec:      	and	x9, x8, #0xfff
    10f0:      	add	x2, x0, x9
    10f4:      	mov	w9, #0xfff              // =4095
    10f8:      	add	x0, x21, #0x4
    10fc:      	sub	w8, w9, w8
    1100:      	and	w23, w8, #0xfff
    1104:      	mov	w8, #0x4                // =4
    1108:      	mov	w1, w23
    110c:      	blr	x8
    1110:      	str	w23, [x21]
    1114:      	add	x2, x25, #0x8
    1118:      	mov	w25, #0x8               // =8
    111c:      	add	x8, sp, #0xa8
    1120:      	mov	w9, #0x4                // =4
    1124:      	add	x0, sp, #0xa8
    1128:      	mov	w1, #0x8                // =8
    112c:      	blr	x9
    1130:      	ldr	x8, [sp, #0xa8]
    1134:      	add	x9, sp, #0x100
    1138:      	mov	w10, #0x4               // =4
    113c:      	add	x0, sp, #0x100
    1140:      	mov	w1, #0x8                // =8
    1144:      	add	x8, x8, #0x30
    1148:      	ldr	x8, [sp, #0xa8]
    114c:      	ldr	x25, [sp, #0x118]
    1150:      	add	x2, x8, #0x30
    1154:      	blr	x10
    1158:      	add	x11, sp, #0xf0
    115c:      	mov	w9, #0x2                // =2
    1160:      	add	x10, sp, #0x80
    1164:      	ldr	x8, [x11, #0x10]
    1168:      	add	x0, sp, #0x80
    116c:      	mov	w1, #0x2                // =2
    1170:      	ldr	x2, [x11, #0x10]
    1174:      	blr	x24
    1178:      	add	x8, x21, x23
    117c:      	str	wzr, [x8, #0x4]
    1180:      	ldrh	w9, [sp, #0x80]
    1184:      	strh	w9, [x8, #0x8]
    1188:      	add	w8, w23, #0xe
    118c:      	mov	x24, x29
    1190:      	mov	w29, #0x5efc            // =24316
    1194:      	b	0x1cc0 <generic_kprobe_process_event+0x1960>
    1198:      	cmp	w11, #0x4
    119c:      	mov	w29, #0x5efc            // =24316
    11a0:      	b.gt	0x1310 <generic_kprobe_process_event+0xfb0>
    11a4:      	sub	w8, w11, #0x2
    11a8:      	cmp	w8, #0x2
    11ac:      	b.lo	0x1338 <generic_kprobe_process_event+0xfd8>
    11b0:      	cmp	w11, #0x1
    11b4:      	b.eq	0x1338 <generic_kprobe_process_event+0xfd8>
    11b8:      	cmp	w11, #0x4
    11bc:      	b.eq	0x12ec <generic_kprobe_process_event+0xf8c>
    11c0:      	b	0x13b0 <generic_kprobe_process_event+0x1050>
    11c4:      	cmp	w11, #0x1a
    11c8:      	mov	w29, #0x5efc            // =24316
    11cc:      	b.gt	0x132c <generic_kprobe_process_event+0xfcc>
    11d0:      	cmp	w11, #0x16
    11d4:      	b.eq	0x1340 <generic_kprobe_process_event+0xfe0>
    11d8:      	cmp	w11, #0x17
    11dc:      	b.eq	0x12ec <generic_kprobe_process_event+0xf8c>
    11e0:      	cmp	w11, #0x1a
    11e4:      	b.eq	0x1390 <generic_kprobe_process_event+0x1030>
    11e8:      	b	0x13b0 <generic_kprobe_process_event+0x1050>
    11ec:      	add	x21, sp, #0x80
    11f0:      	mov	w8, #0x8                // =8
    11f4:      	mov	w9, #0x4                // =4
    11f8:      	ldr	x2, [sp, #0xa8]
    11fc:      	add	x0, sp, #0x80
    1200:      	mov	w1, #0x8                // =8
    1204:      	blr	x9
    1208:      	ldr	x8, [sp, #0x80]
    120c:      	mov	w29, #0x5efc            // =24316
    1210:      	str	x8, [sp, #0xa8]
    1214:      	mov	w8, #0x8                // =8
    1218:      	mov	w9, #0x4                // =4
    121c:      	add	x10, sp, #0xa8
    1220:      	add	x0, sp, #0x80
    1224:      	add	x2, sp, #0xa8
    1228:      	mov	w1, #0x8                // =8
    122c:      	blr	x9
    1230:      	ldr	x8, [sp, #0x80]
    1234:      	ldr	x21, [sp, #0x60]
    1238:      	b	0x1264 <generic_kprobe_process_event+0xf04>
    123c:      	add	x8, x25, #0x40
    1240:      	mov	w9, #0x8                // =8
    1244:      	mov	w10, #0x4               // =4
    1248:      	str	x8, [sp, #0xa8]
    124c:      	add	x11, sp, #0x80
    1250:      	add	x0, sp, #0x80
    1254:      	mov	w1, #0x8                // =8
    1258:      	ldr	x2, [sp, #0xa8]
    125c:      	blr	x10
    1260:      	ldr	x8, [sp, #0x80]
    1264:      	add	x8, x8, #0x40
    1268:      	ldr	x25, [sp, #0x118]
    126c:      	str	x8, [x23, #0x6440]
    1270:      	mov	w8, #0x6                // =6
    1274:      	mov	w9, #0xc                // =12
    1278:      	mov	x0, x19
    127c:      	mov	x1, x24
    1280:      	mov	w2, #0x6                // =6
    1284:      	blr	x9
    1288:      	mov	x8, xzr
    128c:      	b	0x1cc4 <generic_kprobe_process_event+0x1964>
    1290:      	mov	w8, #0x8                // =8
    1294:      	mov	w9, #0x4                // =4
    1298:      	add	x10, sp, #0x100
    129c:      	add	x11, sp, #0xa8
    12a0:      	add	x0, sp, #0x100
    12a4:      	add	x2, sp, #0xa8
    12a8:      	mov	w1, #0x8                // =8
    12ac:      	blr	x9
    12b0:      	ldr	x8, [x25, #0x10]
    12b4:      	ldr	x25, [sp, #0x118]
    12b8:      	mov	w29, #0x5efc            // =24316
    12bc:      	cbnz	x8, 0x126c <generic_kprobe_process_event+0xf0c>
    12c0:      	b	0x1cc4 <generic_kprobe_process_event+0x1964>
    12c4:      	ldr	x25, [sp, #0x118]
    12c8:      	mov	x8, xzr
    12cc:      	b	0x1cc4 <generic_kprobe_process_event+0x1964>
    12d0:      	sub	w8, w11, #0xa
    12d4:      	cmp	w8, #0x2
    12d8:      	b.lo	0x12ec <generic_kprobe_process_event+0xf8c>
    12dc:      	sub	w8, w11, #0xc
    12e0:      	cmp	w8, #0x2
    12e4:      	b.lo	0x1338 <generic_kprobe_process_event+0xfd8>
    12e8:      	b	0x13b0 <generic_kprobe_process_event+0x1050>
    12ec:      	mov	w23, #0x8               // =8
    12f0:      	b	0x13b4 <generic_kprobe_process_event+0x1054>
    12f4:      	cmp	w11, #0x2a
    12f8:      	b.gt	0x1348 <generic_kprobe_process_event+0xfe8>
    12fc:      	cmp	w11, #0x28
    1300:      	b.eq	0x1360 <generic_kprobe_process_event+0x1000>
    1304:      	cmp	w11, #0x29
    1308:      	b.eq	0x1398 <generic_kprobe_process_event+0x1038>
    130c:      	b	0x13b0 <generic_kprobe_process_event+0x1050>
    1310:      	cmp	w11, #0x6
    1314:      	b.gt	0x1380 <generic_kprobe_process_event+0x1020>
    1318:      	cmp	w11, #0x5
    131c:      	b.eq	0x1398 <generic_kprobe_process_event+0x1038>
    1320:      	cmp	w11, #0x6
    1324:      	b.eq	0x13b4 <generic_kprobe_process_event+0x1054>
    1328:      	b	0x13b0 <generic_kprobe_process_event+0x1050>
    132c:      	sub	w8, w11, #0x1d
    1330:      	cmp	w8, #0x4
    1334:      	b.hs	0x13a8 <generic_kprobe_process_event+0x1048>
    1338:      	mov	w23, #0x4               // =4
    133c:      	b	0x13b4 <generic_kprobe_process_event+0x1054>
    1340:      	mov	w23, #0x10              // =16
    1344:      	b	0x13b4 <generic_kprobe_process_event+0x1054>
    1348:      	cmp	w11, #0x2b
    134c:      	b.eq	0x1360 <generic_kprobe_process_event+0x1000>
    1350:      	cmp	w11, #0x2c
    1354:      	b.ne	0x13b0 <generic_kprobe_process_event+0x1050>
    1358:      	mov	w23, #0x70              // =112
    135c:      	b	0x13b4 <generic_kprobe_process_event+0x1054>
    1360:      	mov	w23, #0x18              // =24
    1364:      	b	0x13b4 <generic_kprobe_process_event+0x1054>
    1368:      	cmp	w11, #0x11
    136c:      	b.eq	0x13b4 <generic_kprobe_process_event+0x1054>
    1370:      	cmp	w11, #0x12
    1374:      	mov	x23, x12
    1378:      	b.eq	0x13b4 <generic_kprobe_process_event+0x1054>
    137c:      	b	0x13b0 <generic_kprobe_process_event+0x1050>
    1380:      	cmp	w11, #0x7
    1384:      	b.eq	0x1398 <generic_kprobe_process_event+0x1038>
    1388:      	cmp	w11, #0x8
    138c:      	b.ne	0x13b0 <generic_kprobe_process_event+0x1050>
    1390:      	mov	w23, #0x50              // =80
    1394:      	b	0x13b4 <generic_kprobe_process_event+0x1054>
    1398:      	mov	w23, #0x40              // =64
    139c:      	b	0x13b4 <generic_kprobe_process_event+0x1054>
    13a0:      	mov	w23, #0x98              // =152
    13a4:      	b	0x13b4 <generic_kprobe_process_event+0x1054>
    13a8:      	cmp	w11, #0x1b
    13ac:      	b.eq	0x1390 <generic_kprobe_process_event+0x1030>
    13b0:      	mov	x23, xzr
    13b4:      	str	x12, [sp, #0x48]
    13b8:      	str	wzr, [sp, #0x7c]
    13bc:      	mov	w8, #0x1                // =1
    13c0:      	add	x9, sp, #0x7c
    13c4:      	add	x1, sp, #0x7c
    13c8:      	mov	x0, x22
    13cc:      	blr	x8
    13d0:      	mov	x8, xzr
    13d4:      	cbz	x0, 0x1cc0 <generic_kprobe_process_event+0x1960>
    13d8:      	mov	w9, #0x3ffb             // =16379
    13dc:      	sub	x9, x9, x23
    13e0:      	cmp	x9, x25
    13e4:      	b.ls	0x1cc0 <generic_kprobe_process_event+0x1960>
    13e8:      	add	x10, x0, x21, lsl #2
    13ec:      	mov	w8, #0x5ea0             // =24224
    13f0:      	add	x11, x0, #0x90
    13f4:      	ldr	w8, [x10, x8]
    13f8:      	add	x23, x25, #0x4
    13fc:      	add	x9, x0, x21, lsl #3
    1400:      	str	w8, [x11, x25]
    1404:      	str	x23, [x9, #0x5e78]
    1408:      	cbz	w8, 0x1414 <generic_kprobe_process_event+0x10b4>
    140c:      	mov	w8, #0x4                // =4
    1410:      	b	0x1cc0 <generic_kprobe_process_event+0x1960>
    1414:      	ldp	x21, x9, [sp, #0x50]
    1418:      	add	x8, x11, x23
    141c:      	cmp	w9, #0x17
    1420:      	stp	x8, x11, [sp, #0x18]
    1424:      	add	x8, sp, #0xf0
    1428:      	str	x21, [sp, #0xa8]
    142c:      	str	xzr, [x8, #0x10]
    1430:      	str	x10, [sp, #0x28]
    1434:      	b.le	0x145c <generic_kprobe_process_event+0x10fc>
    1438:      	cmp	w9, #0x18
    143c:      	b.eq	0x1478 <generic_kprobe_process_event+0x1118>
    1440:      	cmp	w9, #0x25
    1444:      	b.eq	0x14c8 <generic_kprobe_process_event+0x1168>
    1448:      	cmp	w9, #0x2a
    144c:      	b.ne	0x1adc <generic_kprobe_process_event+0x177c>
    1450:      	add	x8, sp, #0x80
    1454:      	stp	xzr, x21, [sp, #0x80]
    1458:      	b	0x14f8 <generic_kprobe_process_event+0x1198>
    145c:      	cmp	w9, #0xf
    1460:      	b.eq	0x1a10 <generic_kprobe_process_event+0x16b0>
    1464:      	cmp	w9, #0x10
    1468:      	b.ne	0x1adc <generic_kprobe_process_event+0x177c>
    146c:      	add	x21, sp, #0xf8
    1470:      	add	x23, sp, #0xf0
    1474:      	b	0x14a4 <generic_kprobe_process_event+0x1144>
    1478:      	mov	x10, x21
    147c:      	add	x21, sp, #0xf8
    1480:      	mov	w8, #0x8                // =8
    1484:      	mov	w9, #0x4                // =4
    1488:      	ldr	x2, [sp, #0xa8]
    148c:      	add	x0, sp, #0xf8
    1490:      	mov	w1, #0x8                // =8
    1494:      	blr	x9
    1498:      	add	x23, sp, #0xf0
    149c:      	ldr	x8, [x23, #0x8]
    14a0:      	str	x8, [sp, #0xa8]
    14a4:      	mov	w8, #0x8                // =8
    14a8:      	mov	w9, #0x4                // =4
    14ac:      	add	x10, sp, #0xa8
    14b0:      	add	x0, sp, #0xf8
    14b4:      	add	x2, sp, #0xa8
    14b8:      	mov	w1, #0x8                // =8
    14bc:      	blr	x9
    14c0:      	ldr	x8, [x23, #0x8]
    14c4:      	b	0x14f4 <generic_kprobe_process_event+0x1194>
    14c8:      	add	x8, x21, #0x40
    14cc:      	mov	w9, #0x8                // =8
    14d0:      	mov	w10, #0x4               // =4
    14d4:      	str	x8, [sp, #0xa8]
    14d8:      	add	x11, sp, #0xf8
    14dc:      	add	x0, sp, #0xf8
    14e0:      	mov	w1, #0x8                // =8
    14e4:      	ldr	x2, [sp, #0xa8]
    14e8:      	blr	x10
    14ec:      	add	x8, sp, #0xf0
    14f0:      	ldr	x8, [x8, #0x8]
    14f4:      	add	x8, x8, #0x40
    14f8:      	str	x8, [sp, #0x30]
    14fc:      	str	wzr, [sp, #0x94]
    1500:      	adrp	x0, 0x1000 <generic_kprobe_process_event+0xca0>
    1504:      	mov	w8, #0x1                // =1
    1508:      	add	x9, sp, #0x94
    150c:      	ldr	x0, [x0]
    1510:      	add	x1, sp, #0x94
    1514:      	blr	x8
    1518:      	cbz	x0, 0x15ac <generic_kprobe_process_event+0x124c>
    151c:      	add	x8, x0, #0x1, lsl #12   // =0x1000
    1520:      	mov	x24, x0
    1524:      	str	x8, [sp, #0x50]
    1528:      	mov	w8, #0x23               // =35
    152c:      	blr	x8
    1530:      	add	x2, x0, #0xb30
    1534:      	mov	w25, #0x8               // =8
    1538:      	add	x8, sp, #0x98
    153c:      	mov	w9, #0x4                // =4
    1540:      	add	x0, sp, #0x98
    1544:      	mov	w1, #0x8                // =8
    1548:      	mov	w21, #0x4               // =4
    154c:      	blr	x9
    1550:      	ldr	x8, [sp, #0x98]
    1554:      	mov	w9, #0x4                // =4
    1558:      	add	x0, sp, #0xa0
    155c:      	mov	w1, #0x8                // =8
    1560:      	str	x8, [sp, #0x38]
    1564:      	add	x8, x8, #0x18
    1568:      	str	x8, [sp, #0x58]
    156c:      	ldr	x8, [sp, #0x30]
    1570:      	add	x2, x8, #0x8
    1574:      	add	x8, sp, #0xa0
    1578:      	str	x2, [sp, #0x48]
    157c:      	blr	x9
    1580:      	ldr	x23, [sp, #0xa0]
    1584:      	add	x8, sp, #0xa8
    1588:      	add	x0, sp, #0xa8
    158c:      	mov	w1, #0x8                // =8
    1590:      	add	x2, x23, #0x10
    1594:      	blr	x21
    1598:      	ldr	x8, [sp, #0xa8]
    159c:      	cbz	x8, 0x15bc <generic_kprobe_process_event+0x125c>
    15a0:      	ldr	x9, [sp, #0x50]
    15a4:      	mov	w8, #0x1000             // =4096
    15a8:      	b	0x1604 <generic_kprobe_process_event+0x12a4>
    15ac:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    15b0:      	mov	x21, xzr
    15b4:      	ldr	x24, [x24]
    15b8:      	b	0x1cb8 <generic_kprobe_process_event+0x1958>
    15bc:      	add	x2, x23, #0x18
    15c0:      	mov	w8, #0x8                // =8
    15c4:      	mov	w9, #0x4                // =4
    15c8:      	add	x10, sp, #0xa8
    15cc:      	add	x0, sp, #0xa8
    15d0:      	mov	w1, #0x8                // =8
    15d4:      	blr	x9
    15d8:      	ldr	x8, [sp, #0xa8]
    15dc:      	cmp	x8, x23
    15e0:      	b.eq	0x15a0 <generic_kprobe_process_event+0x1240>
    15e4:      	mov	w8, #0x2964             // =10596
    15e8:      	add	x9, x24, #0xff6
    15ec:      	strh	w8, [x24, #0xffe]
    15f0:      	adrp	x8, 0x1000 <generic_kprobe_process_event+0xca0>
    15f4:      	add	x8, x8, #0x0
    15f8:      	ldr	x8, [x8]
    15fc:      	str	x8, [x9]
    1600:      	mov	w8, #0xff6              // =4086
    1604:      	ldr	x10, [sp, #0x38]
    1608:      	stp	xzr, xzr, [sp, #0xa8]
    160c:      	add	x11, sp, #0xa8
    1610:      	add	x0, sp, #0xa8
    1614:      	mov	w1, #0x8                // =8
    1618:      	mov	w25, #0x4               // =4
    161c:      	stp	x24, xzr, [sp, #0xb8]
    1620:      	add	x23, x11, #0x8
    1624:      	add	x21, x11, #0x18
    1628:      	add	x24, x11, #0x20
    162c:      	add	x2, x10, #0x20
    1630:      	stp	xzr, xzr, [sp, #0xc8]
    1634:      	str	x9, [sp, #0x50]
    1638:      	str	x9, [sp, #0xd8]
    163c:      	mov	w9, #0x8                // =8
    1640:      	str	w8, [sp, #0xe0]
    1644:      	mov	w8, #0x4                // =4
    1648:      	strb	wzr, [sp, #0xe4]
    164c:      	blr	x8
    1650:      	ldr	x2, [sp, #0x58]
    1654:      	mov	w8, #0x4                // =4
    1658:      	mov	w9, #0x8                // =8
    165c:      	mov	x0, x23
    1660:      	mov	w1, #0x8                // =8
    1664:      	blr	x8
    1668:      	ldr	x2, [sp, #0x48]
    166c:      	mov	w8, #0x4                // =4
    1670:      	mov	w9, #0x8                // =8
    1674:      	mov	x0, x21
    1678:      	str	x21, [sp, #0x58]
    167c:      	mov	w1, #0x8                // =8
    1680:      	mov	w23, #0x8               // =8
    1684:      	blr	x8
    1688:      	ldr	x2, [sp, #0x30]
    168c:      	mov	x0, x24
    1690:      	mov	w1, #0x8                // =8
    1694:      	blr	x25
    1698:      	ldr	x8, [sp, #0xc8]
    169c:      	sub	x8, x8, #0x20
    16a0:      	str	x8, [sp, #0xd0]
    16a4:      	adrp	x8, 0x1000 <generic_kprobe_process_event+0xca0>
    16a8:      	ldr	x8, [x8]
    16ac:      	ldrb	w8, [x8]
    16b0:      	cbz	w8, 0x185c <generic_kprobe_process_event+0x14fc>
    16b4:      	mov	w21, #0x80              // =128
    16b8:      	mov	w23, #0x8               // =8
    16bc:      	b	0x16d0 <generic_kprobe_process_event+0x1370>
    16c0:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    16c4:      	subs	w21, w21, #0x1
    16c8:      	ldr	x24, [x24]
    16cc:      	b.eq	0x1ba0 <generic_kprobe_process_event+0x1840>
    16d0:      	ldp	x25, x2, [sp, #0xc0]
    16d4:      	ldp	x8, x9, [sp, #0xa8]
    16d8:      	cmp	x25, x8
    16dc:      	ccmp	x2, x9, #0x0, eq
    16e0:      	b.eq	0x1b80 <generic_kprobe_process_event+0x1820>
    16e4:      	ldr	x24, [sp, #0xd0]
    16e8:      	mov	w8, #0x4                // =4
    16ec:      	add	x9, sp, #0xe8
    16f0:      	add	x0, sp, #0xe8
    16f4:      	mov	w1, #0x8                // =8
    16f8:      	blr	x8
    16fc:      	ldr	x8, [sp, #0xe8]
    1700:      	mov	w10, #0x8               // =8
    1704:      	cmp	x25, x8
    1708:      	b.eq	0x1804 <generic_kprobe_process_event+0x14a4>
    170c:      	add	x23, x25, #0x18
    1710:      	mov	w8, #0x4                // =4
    1714:      	add	x9, sp, #0xf8
    1718:      	add	x0, sp, #0xf8
    171c:      	mov	w1, #0x8                // =8
    1720:      	mov	x2, x23
    1724:      	blr	x8
    1728:      	add	x8, sp, #0xf0
    172c:      	mov	w10, #0x8               // =8
    1730:      	ldr	x8, [x8, #0x8]
    1734:      	cmp	x8, x25
    1738:      	b.eq	0x1804 <generic_kprobe_process_event+0x14a4>
    173c:      	mov	w8, #0x4                // =4
    1740:      	add	x9, sp, #0xf0
    1744:      	add	x0, sp, #0xf0
    1748:      	mov	w1, #0x8                // =8
    174c:      	mov	x2, x23
    1750:      	blr	x8
    1754:      	add	x2, x25, #0x20
    1758:      	mov	w8, #0x4                // =4
    175c:      	mov	w9, #0x10               // =16
    1760:      	add	x10, sp, #0x100
    1764:      	add	x0, sp, #0x100
    1768:      	mov	w1, #0x10               // =16
    176c:      	blr	x8
    1770:      	add	x8, sp, #0xf0
    1774:      	ldr	w23, [sp, #0x104]
    1778:      	ldr	x10, [sp, #0xd8]
    177c:      	ldr	w24, [sp, #0xe0]
    1780:      	ldr	x9, [x8, #0x18]
    1784:      	ldr	x8, [sp, #0xb8]
    1788:      	sub	x12, x10, x8
    178c:      	subs	w10, w23, w24
    1790:      	csel	w10, wzr, w10, lo
    1794:      	cmp	w24, w23
    1798:      	csel	w11, w24, w23, lo
    179c:      	cinc	w13, w11, hi
    17a0:      	sub	w14, w24, w13
    17a4:      	subs	x12, x12, x13
    17a8:      	str	w14, [sp, #0xe0]
    17ac:      	b.lo	0x1b88 <generic_kprobe_process_event+0x1828>
    17b0:      	cmp	x12, #0xfff
    17b4:      	b.hi	0x1b88 <generic_kprobe_process_event+0x1828>
    17b8:      	cmp	w24, w23
    17bc:      	b.ls	0x17c8 <generic_kprobe_process_event+0x1468>
    17c0:      	mov	w13, #0x2f              // =47
    17c4:      	strb	w13, [x8, x12]
    17c8:      	add	x25, x8, x12
    17cc:      	cmp	w24, w23
    17d0:      	add	x2, x9, x10
    17d4:      	and	w1, w11, #0xff
    17d8:      	mov	w8, #0x4                // =4
    17dc:      	cinc	x0, x25, hi
    17e0:      	blr	x8
    17e4:      	cmp	w24, w23
    17e8:      	str	x25, [sp, #0xd8]
    17ec:      	b.ls	0x1b88 <generic_kprobe_process_event+0x1828>
    17f0:      	add	x8, sp, #0xf0
    17f4:      	mov	w23, #0x8               // =8
    17f8:      	ldr	x8, [x8]
    17fc:      	str	x8, [sp, #0xc0]
    1800:      	b	0x16c0 <generic_kprobe_process_event+0x1360>
    1804:      	add	x2, x24, #0x10
    1808:      	mov	w8, #0x4                // =4
    180c:      	add	x9, sp, #0xf8
    1810:      	add	x0, sp, #0xf8
    1814:      	mov	w1, #0x8                // =8
    1818:      	blr	x8
    181c:      	add	x9, sp, #0xf0
    1820:      	ldr	x8, [sp, #0xd0]
    1824:      	mov	w23, #0x8               // =8
    1828:      	ldr	x9, [x9, #0x8]
    182c:      	cmp	x8, x9
    1830:      	b.eq	0x1b90 <generic_kprobe_process_event+0x1830>
    1834:      	ldr	x0, [sp, #0x58]
    1838:      	add	x2, x24, #0x18
    183c:      	mov	w8, #0x4                // =4
    1840:      	mov	w1, #0x8                // =8
    1844:      	blr	x8
    1848:      	add	x8, sp, #0xf0
    184c:      	ldr	x8, [x8, #0x8]
    1850:      	add	x9, x8, #0x20
    1854:      	stp	x9, x8, [sp, #0xc8]
    1858:      	b	0x16c0 <generic_kprobe_process_event+0x1360>
    185c:      	mov	w21, #0x80              // =128
    1860:      	mov	w23, #0x8               // =8
    1864:      	ldp	x25, x2, [sp, #0xc0]
    1868:      	ldp	x8, x9, [sp, #0xa8]
    186c:      	cmp	x25, x8
    1870:      	ccmp	x2, x9, #0x0, eq
    1874:      	b.eq	0x1b80 <generic_kprobe_process_event+0x1820>
    1878:      	ldr	x24, [sp, #0xd0]
    187c:      	mov	w8, #0x4                // =4
    1880:      	add	x9, sp, #0xe8
    1884:      	add	x0, sp, #0xe8
    1888:      	mov	w1, #0x8                // =8
    188c:      	blr	x8
    1890:      	ldr	x8, [sp, #0xe8]
    1894:      	mov	w10, #0x8               // =8
    1898:      	cmp	x25, x8
    189c:      	b.eq	0x19a8 <generic_kprobe_process_event+0x1648>
    18a0:      	add	x23, x25, #0x18
    18a4:      	mov	w8, #0x4                // =4
    18a8:      	add	x9, sp, #0xf8
    18ac:      	add	x0, sp, #0xf8
    18b0:      	mov	w1, #0x8                // =8
    18b4:      	mov	x2, x23
    18b8:      	blr	x8
    18bc:      	add	x8, sp, #0xf0
    18c0:      	mov	w10, #0x8               // =8
    18c4:      	ldr	x8, [x8, #0x8]
    18c8:      	cmp	x8, x25
    18cc:      	b.eq	0x19a8 <generic_kprobe_process_event+0x1648>
    18d0:      	mov	w8, #0x4                // =4
    18d4:      	add	x9, sp, #0xf0
    18d8:      	add	x0, sp, #0xf0
    18dc:      	mov	w1, #0x8                // =8
    18e0:      	mov	x2, x23
    18e4:      	blr	x8
    18e8:      	add	x2, x25, #0x20
    18ec:      	mov	w8, #0x4                // =4
    18f0:      	mov	w9, #0x10               // =16
    18f4:      	add	x10, sp, #0x100
    18f8:      	add	x0, sp, #0x100
    18fc:      	mov	w1, #0x10               // =16
    1900:      	blr	x8
    1904:      	add	x8, sp, #0xf0
    1908:      	ldr	w23, [sp, #0x104]
    190c:      	ldr	x10, [sp, #0xd8]
    1910:      	ldr	w24, [sp, #0xe0]
    1914:      	ldr	x9, [x8, #0x18]
    1918:      	ldr	x8, [sp, #0xb8]
    191c:      	sub	x12, x10, x8
    1920:      	subs	w10, w23, w24
    1924:      	csel	w10, wzr, w10, lo
    1928:      	cmp	w24, w23
    192c:      	csel	w11, w24, w23, lo
    1930:      	cinc	w13, w11, hi
    1934:      	sub	w14, w24, w13
    1938:      	subs	x12, x12, x13
    193c:      	str	w14, [sp, #0xe0]
    1940:      	b.lo	0x1b88 <generic_kprobe_process_event+0x1828>
    1944:      	cmp	x12, #0xfff
    1948:      	b.hi	0x1b88 <generic_kprobe_process_event+0x1828>
    194c:      	cmp	w24, w23
    1950:      	b.ls	0x195c <generic_kprobe_process_event+0x15fc>
    1954:      	mov	w13, #0x2f              // =47
    1958:      	strb	w13, [x8, x12]
    195c:      	add	x25, x8, x12
    1960:      	cmp	w24, w23
    1964:      	add	x2, x9, x10
    1968:      	and	w1, w11, #0xff
    196c:      	mov	w8, #0x4                // =4
    1970:      	cinc	x0, x25, hi
    1974:      	blr	x8
    1978:      	cmp	w24, w23
    197c:      	str	x25, [sp, #0xd8]
    1980:      	b.ls	0x1b88 <generic_kprobe_process_event+0x1828>
    1984:      	add	x8, sp, #0xf0
    1988:      	mov	w23, #0x8               // =8
    198c:      	ldr	x8, [x8]
    1990:      	str	x8, [sp, #0xc0]
    1994:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    1998:      	subs	w21, w21, #0x1
    199c:      	ldr	x24, [x24]
    19a0:      	b.ne	0x1864 <generic_kprobe_process_event+0x1504>
    19a4:      	b	0x1ba0 <generic_kprobe_process_event+0x1840>
    19a8:      	add	x2, x24, #0x10
    19ac:      	mov	w8, #0x4                // =4
    19b0:      	add	x9, sp, #0xf8
    19b4:      	add	x0, sp, #0xf8
    19b8:      	mov	w1, #0x8                // =8
    19bc:      	blr	x8
    19c0:      	add	x9, sp, #0xf0
    19c4:      	ldr	x8, [sp, #0xd0]
    19c8:      	mov	w23, #0x8               // =8
    19cc:      	ldr	x9, [x9, #0x8]
    19d0:      	cmp	x8, x9
    19d4:      	b.eq	0x1b90 <generic_kprobe_process_event+0x1830>
    19d8:      	ldr	x0, [sp, #0x58]
    19dc:      	add	x2, x24, #0x18
    19e0:      	mov	w8, #0x4                // =4
    19e4:      	mov	w1, #0x8                // =8
    19e8:      	blr	x8
    19ec:      	add	x8, sp, #0xf0
    19f0:      	ldr	x8, [x8, #0x8]
    19f4:      	add	x9, x8, #0x20
    19f8:      	stp	x9, x8, [sp, #0xc8]
    19fc:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    1a00:      	subs	w21, w21, #0x1
    1a04:      	ldr	x24, [x24]
    1a08:      	b.ne	0x1864 <generic_kprobe_process_event+0x1504>
    1a0c:      	b	0x1ba0 <generic_kprobe_process_event+0x1840>
    1a10:      	mov	w8, #0x8                // =8
    1a14:      	mov	w9, #0x4                // =4
    1a18:      	add	x10, sp, #0x100
    1a1c:      	add	x11, sp, #0xa8
    1a20:      	add	x0, sp, #0x100
    1a24:      	add	x2, sp, #0xa8
    1a28:      	mov	w1, #0x8                // =8
    1a2c:      	blr	x9
    1a30:      	add	x8, sp, #0xf0
    1a34:      	ldr	x8, [x8, #0x10]
    1a38:      	str	x8, [sp, #0x30]
    1a3c:      	cbnz	x8, 0x14fc <generic_kprobe_process_event+0x119c>
    1a40:      	str	wzr, [sp, #0xa0]
    1a44:      	mov	w8, #0x1                // =1
    1a48:      	add	x9, sp, #0xa0
    1a4c:      	add	x1, sp, #0xa0
    1a50:      	mov	x0, x22
    1a54:      	mov	x25, x21
    1a58:      	blr	x8
    1a5c:      	mov	x21, xzr
    1a60:      	cbz	x0, 0x1c8c <generic_kprobe_process_event+0x192c>
    1a64:      	ldr	x8, [sp, #0x58]
    1a68:      	str	x0, [sp, #0x30]
    1a6c:      	cmp	w8, #0x19
    1a70:      	str	x19, [sp, #0x10]
    1a74:      	str	x20, [sp, #0x40]
    1a78:      	b.gt	0x1fec <generic_kprobe_process_event+0x1c8c>
    1a7c:      	cmp	w8, #0x12
    1a80:      	b.le	0x2100 <generic_kprobe_process_event+0x1da0>
    1a84:      	cmp	w8, #0x14
    1a88:      	b.le	0x2454 <generic_kprobe_process_event+0x20f4>
    1a8c:      	ldr	x8, [sp, #0x58]
    1a90:      	cmp	w8, #0x15
    1a94:      	b.eq	0x2ca0 <generic_kprobe_process_event+0x2940>
    1a98:      	ldr	x8, [sp, #0x58]
    1a9c:      	cmp	w8, #0x16
    1aa0:      	b.eq	0x2c44 <generic_kprobe_process_event+0x28e4>
    1aa4:      	ldr	x8, [sp, #0x58]
    1aa8:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    1aac:      	adrp	x22, 0x1000 <generic_kprobe_process_event+0xca0>
    1ab0:      	mov	w29, #0x5efc            // =24316
    1ab4:      	ldr	x24, [x24]
    1ab8:      	ldr	x22, [x22]
    1abc:      	ldr	x19, [sp, #0x10]
    1ac0:      	cmp	w8, #0x17
    1ac4:      	ldr	x20, [sp, #0x40]
    1ac8:      	b.ne	0x1c8c <generic_kprobe_process_event+0x192c>
    1acc:      	ldr	x8, [sp, #0x18]
    1ad0:      	mov	w21, #0x8               // =8
    1ad4:      	stp	w25, wzr, [x8]
    1ad8:      	b	0x1c8c <generic_kprobe_process_event+0x192c>
    1adc:      	cmp	w9, #0x2c
    1ae0:      	b.hi	0x1a40 <generic_kprobe_process_event+0x16e0>
    1ae4:      	mov	w8, #0x1                // =1
    1ae8:      	lsl	x8, x8, x9
    1aec:      	mov	x9, #0x7cf2             // =31986
    1af0:      	movk	x9, #0xf202, lsl #16
    1af4:      	movk	x9, #0x11c1, lsl #32
    1af8:      	tst	x8, x9
    1afc:      	b.eq	0x1a40 <generic_kprobe_process_event+0x16e0>
    1b00:      	add	x8, sp, #0xf0
    1b04:      	str	wzr, [sp, #0xa0]
    1b08:      	add	x9, sp, #0xa0
    1b0c:      	add	x1, sp, #0xa0
    1b10:      	str	x21, [x8]
    1b14:      	mov	w8, #0x1                // =1
    1b18:      	mov	x0, x22
    1b1c:      	blr	x8
    1b20:      	mov	x21, xzr
    1b24:      	cbz	x0, 0x1c8c <generic_kprobe_process_event+0x192c>
    1b28:      	ldr	x8, [sp, #0x58]
    1b2c:      	cmp	w8, #0x10
    1b30:      	b.le	0x1d84 <generic_kprobe_process_event+0x1a24>
    1b34:      	cmp	w8, #0x1e
    1b38:      	b.le	0x1ec4 <generic_kprobe_process_event+0x1b64>
    1b3c:      	mov	x25, x24
    1b40:      	cmp	w8, #0x26
    1b44:      	str	x20, [sp, #0x40]
    1b48:      	str	x19, [sp, #0x10]
    1b4c:      	b.gt	0x201c <generic_kprobe_process_event+0x1cbc>
    1b50:      	sub	w8, w8, #0x1f
    1b54:      	cmp	w8, #0x2
    1b58:      	b.hs	0x2520 <generic_kprobe_process_event+0x21c0>
    1b5c:      	ldr	x0, [sp, #0x18]
    1b60:      	mov	w8, #0x1                // =1
    1b64:      	add	x9, sp, #0xf0
    1b68:      	mov	w10, #0x4               // =4
    1b6c:      	add	x2, sp, #0xf0
    1b70:      	mov	w1, #0x1                // =1
    1b74:      	mov	w21, #0x4               // =4
    1b78:      	blr	x10
    1b7c:      	b	0x317c <generic_kprobe_process_event+0x2e1c>
    1b80:      	mov	w8, #0x1                // =1
    1b84:      	strb	w8, [sp, #0xe4]
    1b88:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    1b8c:      	b	0x1b9c <generic_kprobe_process_event+0x183c>
    1b90:      	mov	w8, #0x1                // =1
    1b94:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    1b98:      	strb	w8, [sp, #0xe4]
    1b9c:      	ldr	x24, [x24]
    1ba0:      	ldr	x8, [sp, #0xd8]
    1ba4:      	ldr	x2, [sp, #0x50]
    1ba8:      	cmp	x8, x2
    1bac:      	b.eq	0x1be4 <generic_kprobe_process_event+0x1884>
    1bb0:      	ldrb	w9, [sp, #0xe4]
    1bb4:      	mov	w11, #0x1000            // =4096
    1bb8:      	cmp	w9, #0x0
    1bbc:      	ldr	w9, [sp, #0xe0]
    1bc0:      	cset	w10, eq
    1bc4:      	sub	w11, w11, w9
    1bc8:      	cmp	w9, #0x0
    1bcc:      	csel	w9, w11, w9, gt
    1bd0:      	cbz	x8, 0x1cb0 <generic_kprobe_process_event+0x1950>
    1bd4:      	lsl	w10, w10, #1
    1bd8:      	mov	x2, x8
    1bdc:      	str	w10, [sp, #0x58]
    1be0:      	b	0x1bec <generic_kprobe_process_event+0x188c>
    1be4:      	mov	w9, wzr
    1be8:      	str	wzr, [sp, #0x58]
    1bec:      	ldr	x21, [sp, #0x18]
    1bf0:      	and	w23, w9, #0xfff
    1bf4:      	mov	w8, #0x4                // =4
    1bf8:      	mov	w24, #0x4               // =4
    1bfc:      	mov	w1, w23
    1c00:      	add	x0, x21, #0x4
    1c04:      	blr	x8
    1c08:      	str	w23, [x21]
    1c0c:      	ldr	x2, [sp, #0x48]
    1c10:      	mov	w25, #0x8               // =8
    1c14:      	add	x8, sp, #0xa8
    1c18:      	mov	w9, #0x4                // =4
    1c1c:      	add	x0, sp, #0xa8
    1c20:      	mov	w1, #0x8                // =8
    1c24:      	blr	x9
    1c28:      	ldr	x8, [sp, #0xa8]
    1c2c:      	add	x9, sp, #0x100
    1c30:      	mov	w10, #0x4               // =4
    1c34:      	add	x0, sp, #0x100
    1c38:      	mov	w1, #0x8                // =8
    1c3c:      	add	x8, x8, #0x30
    1c40:      	ldr	x8, [sp, #0xa8]
    1c44:      	add	x2, x8, #0x30
    1c48:      	blr	x10
    1c4c:      	add	x11, sp, #0xf0
    1c50:      	mov	w9, #0x2                // =2
    1c54:      	add	x10, sp, #0xf8
    1c58:      	ldr	x8, [x11, #0x10]
    1c5c:      	add	x0, sp, #0xf8
    1c60:      	mov	w1, #0x2                // =2
    1c64:      	ldr	x2, [x11, #0x10]
    1c68:      	blr	x24
    1c6c:      	ldr	w9, [sp, #0x58]
    1c70:      	add	x8, x21, x23
    1c74:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    1c78:      	add	w21, w23, #0xa
    1c7c:      	str	w9, [x8, #0x4]
    1c80:      	ldrh	w9, [sp, #0xf8]
    1c84:      	strh	w9, [x8, #0x8]
    1c88:      	ldr	x24, [x24]
    1c8c:      	ldp	x11, x9, [sp, #0x20]
    1c90:      	mov	w10, #0x5ea0            // =24224
    1c94:      	ldr	x25, [sp, #0x118]
    1c98:      	tbz	w21, #0x1f, 0x1cb8 <generic_kprobe_process_event+0x1958>
    1c9c:      	mov	w8, #-0x1               // =-1
    1ca0:      	str	w8, [x9, x10]
    1ca4:      	str	w8, [x11, x25]
    1ca8:      	mov	w8, #0x4                // =4
    1cac:      	b	0x1cc0 <generic_kprobe_process_event+0x1960>
    1cb0:      	ldr	x25, [sp, #0x118]
    1cb4:      	mov	x21, xzr
    1cb8:      	and	x8, x21, #0x7fffffff
    1cbc:      	add	x8, x8, #0x4
    1cc0:      	ldr	x21, [sp, #0x60]
    1cc4:      	add	w25, w25, w8
    1cc8:      	cmp	w21, #0x3
    1ccc:      	str	w25, [x20, #0x4]
    1cd0:      	b.gt	0x1d40 <generic_kprobe_process_event+0x19e0>
    1cd4:      	str	wzr, [sp, #0xa8]
    1cd8:      	mov	w8, #0x1                // =1
    1cdc:      	add	x9, sp, #0xa8
    1ce0:      	add	x1, sp, #0xa8
    1ce4:      	mov	x0, x22
    1ce8:      	blr	x8
    1cec:      	cbz	x0, 0x1d40 <generic_kprobe_process_event+0x19e0>
    1cf0:      	mov	w8, #0x5ef8             // =24312
    1cf4:      	add	x1, x0, x8
    1cf8:      	adrp	x0, 0x1000 <generic_kprobe_process_event+0xca0>
    1cfc:      	mov	w8, #0x1                // =1
    1d00:      	ldr	x0, [x0]
    1d04:      	blr	x8
    1d08:      	cbz	x0, 0x1d40 <generic_kprobe_process_event+0x19e0>
    1d0c:      	add	w8, w21, #0x1
    1d10:      	and	w9, w8, #0x7
    1d14:      	add	x9, x0, w9, uxtw #2
    1d18:      	ldr	w9, [x9, #0x40]
    1d1c:      	cmn	w9, #0x1
    1d20:      	b.eq	0x1d40 <generic_kprobe_process_event+0x19e0>
    1d24:      	str	w8, [x20, x29]
    1d28:      	mov	w8, #0x1                // =1
    1d2c:      	mov	w9, #0xc                // =12
    1d30:      	mov	x0, x19
    1d34:      	mov	x1, x24
    1d38:      	mov	w2, #0x1                // =1
    1d3c:      	blr	x9
    1d40:      	str	wzr, [x20, x29]
    1d44:      	mov	w8, #0x3                // =3
    1d48:      	mov	w9, #0xc                // =12
    1d4c:      	mov	x0, x19
    1d50:      	mov	x1, x24
    1d54:      	mov	w2, #0x3                // =3
    1d58:      	blr	x9
    1d5c:      	ldp	x20, x19, [sp, #0x150]
    1d60:      	mov	w0, wzr
    1d64:      	ldr	x29, [sp, #0x110]
    1d68:      	ldp	x22, x21, [sp, #0x140]
    1d6c:      	ldp	x24, x23, [sp, #0x130]
    1d70:      	ldp	x30, x25, [sp, #0x120]
    1d74:      	add	sp, sp, #0x160
    1d78:      	ret
    1d7c:      	mov	w25, #0x5               // =5
    1d80:      	b	0xf08 <generic_kprobe_process_event+0xba8>
    1d84:      	cmp	w8, #0x9
    1d88:      	b.gt	0x1f0c <generic_kprobe_process_event+0x1bac>
    1d8c:      	cmp	w8, #0x4
    1d90:      	str	x20, [sp, #0x40]
    1d94:      	str	x19, [sp, #0x10]
    1d98:      	str	x0, [sp, #0x50]
    1d9c:      	b.le	0x21c8 <generic_kprobe_process_event+0x1e68>
    1da0:      	cmp	w8, #0x5
    1da4:      	b.eq	0x2850 <generic_kprobe_process_event+0x24f0>
    1da8:      	ldr	x8, [sp, #0x58]
    1dac:      	cmp	w8, #0x6
    1db0:      	b.eq	0x1f98 <generic_kprobe_process_event+0x1c38>
    1db4:      	ldr	x8, [sp, #0x58]
    1db8:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    1dbc:      	adrp	x22, 0x1000 <generic_kprobe_process_event+0xca0>
    1dc0:      	mov	w29, #0x5efc            // =24316
    1dc4:      	ldr	x24, [x24]
    1dc8:      	ldp	x11, x9, [sp, #0x20]
    1dcc:      	mov	w10, #0x5ea0            // =24224
    1dd0:      	cmp	w8, #0x7
    1dd4:      	ldr	x22, [x22]
    1dd8:      	ldr	x19, [sp, #0x10]
    1ddc:      	ldr	x20, [sp, #0x40]
    1de0:      	b.ne	0x1c94 <generic_kprobe_process_event+0x1934>
    1de4:      	add	x8, sp, #0xf0
    1de8:      	ldr	x25, [sp, #0x18]
    1dec:      	mov	w24, #0x2               // =2
    1df0:      	mov	w1, #0x2                // =2
    1df4:      	ldr	x23, [x8]
    1df8:      	mov	w8, #0x4                // =4
    1dfc:      	mov	w21, #0x4               // =4
    1e00:      	add	x0, x25, #0x26
    1e04:      	str	x23, [x25, #0x28]
    1e08:      	add	x2, x23, #0x10
    1e0c:      	blr	x8
    1e10:      	add	x0, x25, #0x3a
    1e14:      	add	x2, x23, #0x12
    1e18:      	mov	w8, #0x1                // =1
    1e1c:      	mov	w9, #0x4                // =4
    1e20:      	mov	w1, #0x1                // =1
    1e24:      	blr	x9
    1e28:      	add	x0, x25, #0x38
    1e2c:      	add	x2, x23, #0x21e
    1e30:      	mov	w8, #0x4                // =4
    1e34:      	mov	w1, #0x2                // =2
    1e38:      	blr	x8
    1e3c:      	add	x0, x25, #0x24
    1e40:      	add	x2, x23, #0x21c
    1e44:      	mov	w8, #0x4                // =4
    1e48:      	mov	w1, #0x2                // =2
    1e4c:      	blr	x8
    1e50:      	add	x0, x25, #0x30
    1e54:      	add	x2, x23, #0x214
    1e58:      	mov	w8, #0x4                // =4
    1e5c:      	mov	w1, #0x4                // =4
    1e60:      	blr	x8
    1e64:      	add	x0, x25, #0x34
    1e68:      	add	x2, x23, #0x210
    1e6c:      	mov	w1, #0x4                // =4
    1e70:      	blr	x21
    1e74:      	ldrh	w8, [x25, #0x26]
    1e78:      	mov	x24, x25
    1e7c:      	stp	xzr, xzr, [x25]
    1e80:      	cmp	w8, #0xa
    1e84:      	str	xzr, [x25, #0x18]
    1e88:      	str	xzr, [x24, #0x10]!
    1e8c:      	b.eq	0x2f68 <generic_kprobe_process_event+0x2c08>
    1e90:      	cmp	w8, #0x2
    1e94:      	b.ne	0x2f94 <generic_kprobe_process_event+0x2c34>
    1e98:      	ldr	x0, [sp, #0x18]
    1e9c:      	add	x2, x23, #0x4
    1ea0:      	mov	w8, #0x4                // =4
    1ea4:      	mov	w1, #0x4                // =4
    1ea8:      	mov	w21, #0x4               // =4
    1eac:      	blr	x8
    1eb0:      	mov	x0, x24
    1eb4:      	mov	w1, #0x4                // =4
    1eb8:      	mov	x2, x23
    1ebc:      	blr	x21
    1ec0:      	b	0x2f94 <generic_kprobe_process_event+0x2c34>
    1ec4:      	mov	x25, x24
    1ec8:      	cmp	w8, #0x1c
    1ecc:      	str	x0, [sp, #0x50]
    1ed0:      	b.gt	0x21a4 <generic_kprobe_process_event+0x1e44>
    1ed4:      	ldr	x8, [sp, #0x58]
    1ed8:      	cmp	w8, #0x11
    1edc:      	b.eq	0x2574 <generic_kprobe_process_event+0x2214>
    1ee0:      	ldr	x8, [sp, #0x58]
    1ee4:      	cmp	w8, #0x19
    1ee8:      	b.eq	0x2628 <generic_kprobe_process_event+0x22c8>
    1eec:      	ldr	x8, [sp, #0x58]
    1ef0:      	ldp	x11, x9, [sp, #0x20]
    1ef4:      	mov	x24, x25
    1ef8:      	mov	w29, #0x5efc            // =24316
    1efc:      	mov	w10, #0x5ea0            // =24224
    1f00:      	cmp	w8, #0x1c
    1f04:      	b.eq	0x2200 <generic_kprobe_process_event+0x1ea0>
    1f08:      	b	0x1c94 <generic_kprobe_process_event+0x1934>
    1f0c:      	sub	w8, w8, #0xa
    1f10:      	cmp	w8, #0x2
    1f14:      	b.lo	0x2200 <generic_kprobe_process_event+0x1ea0>
    1f18:      	ldr	x8, [sp, #0x58]
    1f1c:      	str	x20, [sp, #0x40]
    1f20:      	sub	w8, w8, #0xc
    1f24:      	str	x19, [sp, #0x10]
    1f28:      	cmp	w8, #0x2
    1f2c:      	b.lo	0x2220 <generic_kprobe_process_event+0x1ec0>
    1f30:      	ldr	x8, [sp, #0x58]
    1f34:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    1f38:      	adrp	x22, 0x1000 <generic_kprobe_process_event+0xca0>
    1f3c:      	mov	w29, #0x5efc            // =24316
    1f40:      	ldr	x24, [x24]
    1f44:      	ldp	x11, x9, [sp, #0x20]
    1f48:      	mov	w10, #0x5ea0            // =24224
    1f4c:      	cmp	w8, #0xe
    1f50:      	ldr	x22, [x22]
    1f54:      	ldr	x19, [sp, #0x10]
    1f58:      	ldr	x20, [sp, #0x40]
    1f5c:      	b.ne	0x1c94 <generic_kprobe_process_event+0x1934>
    1f60:      	mov	w21, #0x8               // =8
    1f64:      	add	x8, sp, #0xa8
    1f68:      	add	x24, sp, #0xf0
    1f6c:      	mov	w9, #0x4                // =4
    1f70:      	add	x0, sp, #0xa8
    1f74:      	add	x2, sp, #0xf0
    1f78:      	mov	w1, #0x8                // =8
    1f7c:      	mov	w23, #0x4               // =4
    1f80:      	blr	x9
    1f84:      	ldr	x8, [sp, #0xa8]
    1f88:      	add	x0, sp, #0xf0
    1f8c:      	mov	w1, #0x8                // =8
    1f90:      	ldr	x2, [sp, #0xa8]
    1f94:      	blr	x23
    1f98:      	add	x8, sp, #0xf0
    1f9c:      	mov	w9, #0x2d               // =45
    1fa0:      	mov	w1, #0x1001             // =4097
    1fa4:      	ldr	x2, [x8]
    1fa8:      	ldr	x8, [sp, #0x18]
    1fac:      	add	x0, x8, #0x4
    1fb0:      	mov	w8, #0x1001             // =4097
    1fb4:      	blr	x9
    1fb8:      	mov	x21, x0
    1fbc:      	tbnz	x0, #0x3f, 0x2a68 <generic_kprobe_process_event+0x2708>
    1fc0:      	ldr	x9, [sp, #0x18]
    1fc4:      	sub	w8, w21, #0x1
    1fc8:      	adrp	x24, 0x1000 <generic_kprobe_process_event+0xca0>
    1fcc:      	add	x21, x21, #0x3
    1fd0:      	str	w8, [x9]
    1fd4:      	b	0x4208 <generic_kprobe_process_event+0x3ea8>
    1fd8:      	ldr	x11, [sp, #0x58]
    1fdc:      	ldr	x13, [sp, #0x38]
    1fe0:      	mov	w25, #0x6               // =6
    1fe4:      	mov	x12, x29
    1fe8:      	b	0xf08 <generic_kprobe_process_event+0xba8>
    1fec:      	cmp	w8, #0x20
    1ff0:      	b.le	0x2374 <generic_kprobe_process_event+0x2014>
    1ff4:      	sub	w8, w8, #0x21
    1ff8:      	cmp	w8, #0x4
    1ffc:      	b.hs	0x2244 <generic_kprobe_process_event+0x1ee4>
    2000:      	ldr	x0, [sp, #0x18]
    2004:      	mov	w21, #0x8               // =8
    2008:      	mov	w8, #0x4                // =4
    200c:      	mov	w1, #0x8                // =8
    2010:      	mov	x2, x25
    2014:      	blr	x8
    2018:      	b	0x391c <generic_kprobe_process_event+0x35bc>
    201c:      	cmp	w8, #0x27
    2020:      	b.eq	0x29ac <generic_kprobe_process_event+0x264c>
    2024:      	ldr	x8, [sp, #0x58]
    2028:      	cmp	w8, #0x28
    202c:      	b.eq	0x29ec <generic_kprobe_process_event+0x268c>
    2030:      	ldr	x8, [sp, #0x58]
    2034:      	adrp	x22, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2038:      	ldp	x11, x9, [sp, #0x20]
    203c:      	mov	x24, x25
    2040:      	mov	w29, #0x5efc            // =24316
    2044:      	mov	w10, #0x5ea0            // =24224
    2048:      	cmp	w8, #0x2c
    204c:      	ldr	x22, [x22]
    2050:      	ldr	x19, [sp, #0x10]
    2054:      	ldr	x20, [sp, #0x40]
    2058:      	b.ne	0x1c94 <generic_kprobe_process_event+0x1934>
    205c:      	ldr	x0, [sp, #0x18]
    2060:      	add	x8, sp, #0xf0
    2064:      	strb	wzr, [sp, #0xa8]
    2068:      	mov	w9, #0x4                // =4
    206c:      	mov	w1, #0x2                // =2
    2070:      	ldr	x23, [x8]
    2074:      	mov	w8, #0x2                // =2
    2078:      	stp	xzr, xzr, [x0]
    207c:      	stp	xzr, xzr, [x0, #0x10]
    2080:      	mov	x2, x23
    2084:      	stp	xzr, xzr, [x0, #0x20]
    2088:      	stp	xzr, xzr, [x0, #0x30]
    208c:      	stp	xzr, xzr, [x0, #0x40]
    2090:      	stp	xzr, xzr, [x0, #0x50]
    2094:      	stp	xzr, xzr, [x0, #0x60]
    2098:      	blr	x9
    209c:      	tbnz	x0, #0x3f, 0x3178 <generic_kprobe_process_event+0x2e18>
    20a0:      	add	x24, x23, #0x2
    20a4:      	mov	w8, #0x1                // =1
    20a8:      	mov	w9, #0x4                // =4
    20ac:      	add	x10, sp, #0xa8
    20b0:      	add	x0, sp, #0xa8
    20b4:      	mov	w1, #0x1                // =1
    20b8:      	mov	x2, x24
    20bc:      	blr	x9
    20c0:      	tbnz	x0, #0x3f, 0x3178 <generic_kprobe_process_event+0x2e18>
    20c4:      	ldrb	w8, [sp, #0xa8]
    20c8:      	ldr	x10, [sp, #0x18]
    20cc:      	cmp	w8, #0x0
    20d0:      	add	x0, x10, #0x4
    20d4:      	cset	w9, eq
    20d8:      	strb	w9, [x10, #0x2]
    20dc:      	cbz	w8, 0x3158 <generic_kprobe_process_event+0x2df8>
    20e0:      	mov	w8, #0x6c               // =108
    20e4:      	mov	w9, #0x2d               // =45
    20e8:      	mov	w1, #0x6c               // =108
    20ec:      	mov	x2, x24
    20f0:      	blr	x9
    20f4:      	tbnz	w0, #0x1f, 0x3178 <generic_kprobe_process_event+0x2e18>
    20f8:      	sub	w21, w0, #0x1
    20fc:      	b	0x3170 <generic_kprobe_process_event+0x2e10>
    2100:      	cmp	w8, #0x7
    2104:      	b.gt	0x2400 <generic_kprobe_process_event+0x20a0>
    2108:      	ldr	x8, [sp, #0x58]
    210c:      	cmp	w8, #0x2
    2110:      	b.eq	0x2a70 <generic_kprobe_process_event+0x2710>
    2114:      	ldr	x8, [sp, #0x58]
    2118:      	adrp	x24, 0x2000 <generic_kprobe_process_event+0x1ca0>
    211c:      	adrp	x22, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2120:      	mov	w29, #0x5efc            // =24316
    2124:      	ldr	x24, [x24]
    2128:      	ldr	x22, [x22]
    212c:      	ldr	x19, [sp, #0x10]
    2130:      	cmp	w8, #0x3
    2134:      	ldr	x20, [sp, #0x40]
    2138:      	b.ne	0x1c8c <generic_kprobe_process_event+0x192c>
    213c:      	ldr	x8, [sp, #0x30]
    2140:      	add	x24, x8, #0x90
    2144:      	ldr	x8, [sp, #0x48]
    2148:      	add	x19, x24, x23
    214c:      	and	w8, w8, #0xf
    2150:      	cmp	w8, #0x2
    2154:      	b.le	0x30f0 <generic_kprobe_process_event+0x2d90>
    2158:      	cmp	w8, #0x3
    215c:      	b.eq	0x32c4 <generic_kprobe_process_event+0x2f64>
    2160:      	cmp	w8, #0x4
    2164:      	b.eq	0x32cc <generic_kprobe_process_event+0x2f6c>
    2168:      	cmp	w8, #0x5
    216c:      	b.ne	0x3324 <generic_kprobe_process_event+0x2fc4>
    2170:      	mov	w9, #0x5e70             // =24176
    2174:      	b	0x32d8 <generic_kprobe_process_event+0x2f78>
    2178:      	mov	w25, #0x7               // =7
    217c:      	adrp	x24, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2180:      	adrp	x22, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2184:      	mov	x12, x29
    2188:      	ldr	x24, [x24]
    218c:      	ldr	x11, [sp, #0x58]
    2190:      	ldp	x13, x20, [sp, #0x38]
    2194:      	mov	x21, x23
    2198:      	ldr	x22, [x22]
    219c:      	ldr	x19, [sp, #0x10]
    21a0:      	b	0xf08 <generic_kprobe_process_event+0xba8>
    21a4:      	ldr	x0, [sp, #0x18]
    21a8:      	mov	w8, #0x2                // =2
    21ac:      	add	x9, sp, #0xf0
    21b0:      	mov	w10, #0x4               // =4
    21b4:      	add	x2, sp, #0xf0
    21b8:      	mov	w1, #0x2                // =2
    21bc:      	mov	w21, #0x4               // =4
    21c0:      	blr	x10
    21c4:      	b	0x3d2c <generic_kprobe_process_event+0x39cc>
    21c8:      	cmp	w8, #0x1
    21cc:      	b.eq	0x2220 <generic_kprobe_process_event+0x1ec0>
    21d0:      	ldr	x8, [sp, #0x58]
    21d4:      	adrp	x24, 0x2000 <generic_kprobe_process_event+0x1ca0>
    21d8:      	adrp	x22, 0x2000 <generic_kprobe_process_event+0x1ca0>
    21dc:      	mov	w29, #0x5efc            // =24316
    21e0:      	ldr	x24, [x24]
    21e4:      	ldp	x11, x9, [sp, #0x20]
    21e8:      	mov	w10, #0x5ea0            // =24224
    21ec:      	cmp	w8, #0x4
    21f0:      	ldr	x22, [x22]
    21f4:      	ldr	x19, [sp, #0x10]
    21f8:      	ldr	x20, [sp, #0x40]
    21fc:      	b.ne	0x1c94 <generic_kprobe_process_event+0x1934>
    2200:      	ldr	x0, [sp, #0x18]
    2204:      	mov	w21, #0x8               // =8
    2208:      	mov	w8, #0x4                // =4
    220c:      	add	x9, sp, #0xf0
    2210:      	add	x2, sp, #0xf0
    2214:      	mov	w1, #0x8                // =8
    2218:      	blr	x8
    221c:      	b	0x1c8c <generic_kprobe_process_event+0x192c>
    2220:      	ldr	x0, [sp, #0x18]
    2224:      	add	x8, sp, #0xf0
    2228:      	mov	w9, #0x4                // =4
    222c:      	add	x2, sp, #0xf0
    2230:      	mov	w1, #0x4                // =4
    2234:      	mov	w21, #0x4               // =4
    2238:      	blr	x9
    223c:      	adrp	x24, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2240:      	b	0x4208 <generic_kprobe_process_event+0x3ea8>
    2244:      	ldr	x8, [sp, #0x58]
    2248:      	cmp	w8, #0x2b
    224c:      	b.eq	0x2d54 <generic_kprobe_process_event+0x29f4>
    2250:      	ldr	x8, [sp, #0x58]
    2254:      	adrp	x24, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2258:      	adrp	x22, 0x2000 <generic_kprobe_process_event+0x1ca0>
    225c:      	mov	w29, #0x5efc            // =24316
    2260:      	ldr	x24, [x24]
    2264:      	ldr	x22, [x22]
    2268:      	ldr	x19, [sp, #0x10]
    226c:      	cmp	w8, #0x29
    2270:      	ldr	x20, [sp, #0x40]
    2274:      	b.ne	0x1c8c <generic_kprobe_process_event+0x192c>
    2278:      	add	x2, x25, #0x18
    227c:      	mov	w8, #0x8                // =8
    2280:      	mov	w9, #0x4                // =4
    2284:      	add	x10, sp, #0xa8
    2288:      	add	x0, sp, #0xa8
    228c:      	mov	w1, #0x8                // =8
    2290:      	blr	x9
    2294:      	ldr	x23, [sp, #0xa8]
    2298:      	cbz	x23, 0x3278 <generic_kprobe_process_event+0x2f18>
    229c:      	ldr	x29, [sp, #0x18]
    22a0:      	add	x2, x23, #0x10
    22a4:      	mov	w24, #0x2               // =2
    22a8:      	mov	w8, #0x4                // =4
    22ac:      	str	x23, [x29, #0x28]
    22b0:      	add	x0, x29, #0x26
    22b4:      	mov	w1, #0x2                // =2
    22b8:      	mov	w21, #0x4               // =4
    22bc:      	blr	x8
    22c0:      	add	x0, x29, #0x3a
    22c4:      	add	x2, x23, #0x12
    22c8:      	mov	w8, #0x1                // =1
    22cc:      	mov	w9, #0x4                // =4
    22d0:      	mov	w1, #0x1                // =1
    22d4:      	blr	x9
    22d8:      	add	x0, x29, #0x38
    22dc:      	add	x2, x23, #0x21e
    22e0:      	mov	w8, #0x4                // =4
    22e4:      	mov	w1, #0x2                // =2
    22e8:      	blr	x8
    22ec:      	add	x0, x29, #0x24
    22f0:      	add	x2, x23, #0x21c
    22f4:      	mov	w8, #0x4                // =4
    22f8:      	mov	w1, #0x2                // =2
    22fc:      	blr	x8
    2300:      	add	x0, x29, #0x30
    2304:      	add	x2, x23, #0x214
    2308:      	mov	w8, #0x4                // =4
    230c:      	mov	w1, #0x4                // =4
    2310:      	blr	x8
    2314:      	add	x0, x29, #0x34
    2318:      	add	x2, x23, #0x210
    231c:      	mov	w1, #0x4                // =4
    2320:      	blr	x21
    2324:      	ldrh	w8, [x29, #0x26]
    2328:      	mov	x24, x29
    232c:      	stp	xzr, xzr, [x29]
    2330:      	cmp	w8, #0xa
    2334:      	str	xzr, [x29, #0x18]
    2338:      	str	xzr, [x24, #0x10]!
    233c:      	b.eq	0x3208 <generic_kprobe_process_event+0x2ea8>
    2340:      	cmp	w8, #0x2
    2344:      	b.ne	0x3234 <generic_kprobe_process_event+0x2ed4>
    2348:      	ldr	x0, [sp, #0x18]
    234c:      	add	x2, x23, #0x4
    2350:      	mov	w8, #0x4                // =4
    2354:      	mov	w1, #0x4                // =4
    2358:      	mov	w21, #0x4               // =4
    235c:      	blr	x8
    2360:      	mov	x0, x24
    2364:      	mov	w1, #0x4                // =4
    2368:      	mov	x2, x23
    236c:      	blr	x21
    2370:      	b	0x3234 <generic_kprobe_process_event+0x2ed4>
    2374:      	cmp	w8, #0x1a
    2378:      	b.eq	0x2de0 <generic_kprobe_process_event+0x2a80>
    237c:      	ldr	x8, [sp, #0x58]
    2380:      	adrp	x24, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2384:      	adrp	x22, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2388:      	mov	w29, #0x5efc            // =24316
    238c:      	ldr	x24, [x24]
    2390:      	ldr	x22, [x22]
    2394:      	ldr	x19, [sp, #0x10]
    2398:      	cmp	w8, #0x1b
    239c:      	ldr	x20, [sp, #0x40]
    23a0:      	b.ne	0x1c8c <generic_kprobe_process_event+0x192c>
    23a4:      	ldr	x10, [sp, #0x18]
    23a8:      	add	x2, x25, #0x18
    23ac:      	mov	w8, #0x3f               // =63
    23b0:      	mov	w9, #0x2d               // =45
    23b4:      	stp	xzr, xzr, [x10, #0x40]
    23b8:      	mov	x0, x10
    23bc:      	stp	xzr, xzr, [x10, #0x30]
    23c0:      	stp	xzr, xzr, [x10, #0x20]
    23c4:      	str	xzr, [x10, #0x18]
    23c8:      	stp	xzr, xzr, [x10]
    23cc:      	mov	w1, #0x3f               // =63
    23d0:      	str	xzr, [x0, #0x10]!
    23d4:      	blr	x9
    23d8:      	tbnz	x0, #0x3f, 0x3020 <generic_kprobe_process_event+0x2cc0>
    23dc:      	ldr	x8, [sp, #0x18]
    23e0:      	add	x2, x25, #0x360
    23e4:      	mov	w9, #0x4                // =4
    23e8:      	mov	w1, #0x8                // =8
    23ec:      	add	x0, x8, #0x8
    23f0:      	mov	w8, #0x8                // =8
    23f4:      	blr	x9
    23f8:      	mov	w21, #0x50              // =80
    23fc:      	b	0x391c <generic_kprobe_process_event+0x35bc>
    2400:      	ldr	x8, [sp, #0x58]
    2404:      	cmp	w8, #0x8
    2408:      	b.eq	0x2acc <generic_kprobe_process_event+0x276c>
    240c:      	ldr	x8, [sp, #0x58]
    2410:      	adrp	x24, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2414:      	adrp	x22, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2418:      	mov	w29, #0x5efc            // =24316
    241c:      	ldr	x24, [x24]
    2420:      	ldr	x22, [x22]
    2424:      	ldr	x19, [sp, #0x10]
    2428:      	cmp	w8, #0x12
    242c:      	ldr	x20, [sp, #0x40]
    2430:      	b.ne	0x1c8c <generic_kprobe_process_event+0x192c>
    2434:      	ldr	x8, [sp, #0x38]
    2438:      	ldr	x0, [sp, #0x18]
    243c:      	mov	x2, x25
    2440:      	and	x21, x8, #0x3ff
    2444:      	mov	w8, #0x4                // =4
    2448:      	mov	w1, w21
    244c:      	blr	x8
    2450:      	b	0x1c8c <generic_kprobe_process_event+0x192c>
    2454:      	ldr	x8, [sp, #0x58]
    2458:      	cmp	w8, #0x13
    245c:      	b.eq	0x2d14 <generic_kprobe_process_event+0x29b4>
    2460:      	ldr	x8, [sp, #0x58]
    2464:      	adrp	x24, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2468:      	adrp	x22, 0x2000 <generic_kprobe_process_event+0x1ca0>
    246c:      	mov	w29, #0x5efc            // =24316
    2470:      	ldr	x24, [x24]
    2474:      	ldr	x22, [x22]
    2478:      	ldr	x19, [sp, #0x10]
    247c:      	cmp	w8, #0x14
    2480:      	ldr	x20, [sp, #0x40]
    2484:      	b.ne	0x1c8c <generic_kprobe_process_event+0x192c>
    2488:      	str	xzr, [sp, #0xa8]
    248c:      	add	x2, x25, #0x110
    2490:      	mov	w10, #0x8               // =8
    2494:      	add	x8, sp, #0xa8
    2498:      	mov	w9, #0x4                // =4
    249c:      	add	x0, sp, #0xa8
    24a0:      	mov	w1, #0x8                // =8
    24a4:      	mov	x24, x25
    24a8:      	add	x23, x25, #0xd8
    24ac:      	mov	w21, #0x4               // =4
    24b0:      	blr	x9
    24b4:      	ldr	x8, [sp, #0xa8]
    24b8:      	mov	w9, #0x80               // =128
    24bc:      	mov	w10, #0x2d              // =45
    24c0:      	ldr	x25, [sp, #0x18]
    24c4:      	mov	w1, #0x80               // =128
    24c8:      	mov	x0, x25
    24cc:      	ldr	x2, [sp, #0xa8]
    24d0:      	blr	x10
    24d4:      	add	x0, x25, #0x90
    24d8:      	mov	w8, #0x4                // =4
    24dc:      	mov	w1, #0x4                // =4
    24e0:      	mov	x2, x23
    24e4:      	blr	x8
    24e8:      	add	x0, x25, #0x80
    24ec:      	add	x2, x24, #0xe0
    24f0:      	mov	w8, #0x4                // =4
    24f4:      	mov	w23, #0x8               // =8
    24f8:      	mov	w1, #0x8                // =8
    24fc:      	blr	x8
    2500:      	add	x0, x25, #0x88
    2504:      	add	x2, x24, #0x118
    2508:      	adrp	x24, 0x2000 <generic_kprobe_process_event+0x1ca0>
    250c:      	ldr	x24, [x24]
    2510:      	mov	w1, #0x8                // =8
    2514:      	blr	x21
    2518:      	mov	w21, #0x98              // =152
    251c:      	b	0x1c8c <generic_kprobe_process_event+0x192c>
    2520:      	ldr	x8, [sp, #0x58]
    2524:      	adrp	x22, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2528:      	ldp	x11, x9, [sp, #0x20]
    252c:      	mov	x24, x25
    2530:      	mov	w29, #0x5efc            // =24316
    2534:      	mov	w10, #0x5ea0            // =24224
    2538:      	cmp	w8, #0x26
    253c:      	ldr	x22, [x22]
    2540:      	ldr	x19, [sp, #0x10]
    2544:      	ldr	x20, [sp, #0x40]
    2548:      	b.ne	0x1c94 <generic_kprobe_process_event+0x1934>
    254c:      	add	x8, sp, #0xf0
    2550:      	ldr	x9, [sp, #0x18]
    2554:      	ldr	x8, [x8]
    2558:      	add	x0, x9, #0x4
    255c:      	add	x2, x19, w8, uxth
    2560:      	ubfx	w8, w8, #16, #12
    2564:      	add	w1, w8, #0x1
    2568:      	mov	w8, #0x2d               // =45
    256c:      	blr	x8
    2570:      	b	0x29d0 <generic_kprobe_process_event+0x2670>
    2574:      	str	xzr, [sp, #0xb0]
    2578:      	mov	w8, #0xe                // =14
    257c:      	blr	x8
    2580:      	lsr	x8, x0, #32
    2584:      	add	x9, sp, #0x100
    2588:      	add	x10, sp, #0xf0
    258c:      	str	x8, [sp, #0xa8]
    2590:      	mov	w8, #0x4                // =4
    2594:      	add	x0, sp, #0x100
    2598:      	add	x2, sp, #0xf0
    259c:      	mov	w1, #0x4                // =4
    25a0:      	blr	x8
    25a4:      	ldr	w8, [sp, #0x100]
    25a8:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    25ac:      	add	x9, sp, #0xa8
    25b0:      	add	x1, sp, #0xa8
    25b4:      	str	w8, [sp, #0xb0]
    25b8:      	mov	w8, #0x1                // =1
    25bc:      	ldr	x0, [x0]
    25c0:      	blr	x8
    25c4:      	cbz	x0, 0x2ed8 <generic_kprobe_process_event+0x2b78>
    25c8:      	ldr	x29, [sp, #0x18]
    25cc:      	ldr	w21, [x0]
    25d0:      	add	x8, sp, #0x100
    25d4:      	mov	w9, #0x4                // =4
    25d8:      	mov	x23, x0
    25dc:      	add	x2, sp, #0x100
    25e0:      	mov	w1, #0x4                // =4
    25e4:      	mov	w24, #0x4               // =4
    25e8:      	mov	x0, x29
    25ec:      	blr	x9
    25f0:      	and	x21, x21, #0xfff
    25f4:      	add	x0, x29, #0x4
    25f8:      	mov	w8, #0x4                // =4
    25fc:      	mov	x2, x23
    2600:      	add	x1, x21, #0x4
    2604:      	blr	x8
    2608:      	add	w21, w21, #0x8
    260c:      	mov	w1, #0x4                // =4
    2610:      	add	x8, x21, x23
    2614:      	add	x0, x29, x21
    2618:      	sub	x2, x8, #0x4
    261c:      	blr	x24
    2620:      	add	x21, x21, #0x4
    2624:      	b	0x3d2c <generic_kprobe_process_event+0x39cc>
    2628:      	add	x8, sp, #0xf0
    262c:      	mov	w9, #0x4                // =4
    2630:      	add	x10, sp, #0x98
    2634:      	ldr	x21, [x8]
    2638:      	mov	w8, #0x1                // =1
    263c:      	add	x0, sp, #0x98
    2640:      	mov	w1, #0x1                // =1
    2644:      	mov	x2, x21
    2648:      	blr	x9
    264c:      	ldrb	w8, [sp, #0x98]
    2650:      	cmp	w8, #0x1
    2654:      	b.ne	0x2ebc <generic_kprobe_process_event+0x2b5c>
    2658:      	add	x2, x21, #0x10
    265c:      	mov	w21, #0x8               // =8
    2660:      	add	x8, sp, #0x100
    2664:      	mov	w9, #0x4                // =4
    2668:      	add	x0, sp, #0x100
    266c:      	mov	w1, #0x8                // =8
    2670:      	mov	w24, #0x4               // =4
    2674:      	blr	x9
    2678:      	add	x29, sp, #0xf0
    267c:      	add	x8, sp, #0x80
    2680:      	mov	w9, #0x4                // =4
    2684:      	ldr	x2, [x29, #0x10]
    2688:      	add	x0, sp, #0x80
    268c:      	mov	w1, #0x8                // =8
    2690:      	blr	x9
    2694:      	ldr	x8, [x29, #0x10]
    2698:      	add	x0, sp, #0xf8
    269c:      	mov	w1, #0x8                // =8
    26a0:      	add	x2, x8, #0x8
    26a4:      	add	x8, sp, #0xf8
    26a8:      	blr	x24
    26ac:      	ldr	x8, [sp, #0x80]
    26b0:      	ldr	x10, [x29, #0x8]
    26b4:      	str	x8, [sp, #0x38]
    26b8:      	ldr	x8, [sp, #0x50]
    26bc:      	add	x8, x8, #0x90
    26c0:      	add	x9, x8, x23
    26c4:      	stp	x9, x10, [sp, #0x50]
    26c8:      	ldr	x9, [sp, #0x48]
    26cc:      	tbz	w9, #0x5, 0x31a0 <generic_kprobe_process_event+0x2e40>
    26d0:      	ldr	x9, [sp, #0x58]
    26d4:      	cmp	x9, #0x1, lsl #12       // =0x1000
    26d8:      	b.lo	0x3184 <generic_kprobe_process_event+0x2e24>
    26dc:      	ldr	x9, [sp, #0x50]
    26e0:      	mov	w8, #0x1                // =1
    26e4:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    26e8:      	add	x1, sp, #0xe8
    26ec:      	str	w8, [x9]
    26f0:      	str	wzr, [sp, #0xe8]
    26f4:      	add	x9, sp, #0xe8
    26f8:      	ldr	x0, [x0]
    26fc:      	blr	x8
    2700:      	str	x0, [sp, #0x48]
    2704:      	cbz	x0, 0x3494 <generic_kprobe_process_event+0x3134>
    2708:      	ldr	x24, [sp, #0x48]
    270c:      	mov	w8, #0x18               // =24
    2710:      	str	w8, [x24]
    2714:      	mov	w8, #0xe                // =14
    2718:      	blr	x8
    271c:      	str	x0, [x24, #0x10]!
    2720:      	cmn	x0, #0x16
    2724:      	b.ne	0x274c <generic_kprobe_process_event+0x23ec>
    2728:      	add	x2, x19, #0xe8
    272c:      	mov	w8, #0x8                // =8
    2730:      	mov	w9, #0x4                // =4
    2734:      	add	x10, sp, #0xa8
    2738:      	add	x0, sp, #0xa8
    273c:      	mov	w1, #0x8                // =8
    2740:      	blr	x9
    2744:      	ldr	x8, [sp, #0xa8]
    2748:      	str	x8, [x24]
    274c:      	mov	w8, #0x7d               // =125
    2750:      	blr	x8
    2754:      	ldp	x8, x10, [sp, #0x48]
    2758:      	mov	x21, xzr
    275c:      	mov	w23, #0xa               // =10
    2760:      	str	x0, [x8, #0x18]
    2764:      	add	x8, x8, #0x20
    2768:      	str	x8, [sp, #0x30]
    276c:      	ldp	x8, x9, [x24]
    2770:      	stur	x8, [x10, #0x14]
    2774:      	stur	x9, [x10, #0x1c]
    2778:      	ldr	x8, [sp, #0x58]
    277c:      	subs	x8, x8, x21
    2780:      	b.mi	0x393c <generic_kprobe_process_event+0x35dc>
    2784:      	ldp	x0, x9, [sp, #0x30]
    2788:      	add	x2, x21, x9
    278c:      	mov	w9, #0x7fe0             // =32736
    2790:      	cmp	x8, x9
    2794:      	csel	x24, x8, x9, lo
    2798:      	mov	w8, #0x4                // =4
    279c:      	mov	w1, w24
    27a0:      	blr	x8
    27a4:      	tbnz	w0, #0x1f, 0x2828 <generic_kprobe_process_event+0x24c8>
    27a8:      	ldr	x8, [sp, #0x48]
    27ac:      	add	w9, w24, #0x20
    27b0:      	str	wzr, [sp, #0xa8]
    27b4:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    27b8:      	add	x1, sp, #0xa8
    27bc:      	mov	x29, x9
    27c0:      	str	w9, [x8, #0x4]
    27c4:      	mov	w8, #0x1                // =1
    27c8:      	add	x9, sp, #0xa8
    27cc:      	ldr	x0, [x0]
    27d0:      	blr	x8
    27d4:      	cbz	x0, 0x2808 <generic_kprobe_process_event+0x24a8>
    27d8:      	ldrb	w8, [x0, #0x28]
    27dc:      	cbz	w8, 0x2808 <generic_kprobe_process_event+0x24a8>
    27e0:      	adrp	x1, 0x2000 <generic_kprobe_process_event+0x1ca0>
    27e4:      	ldr	x3, [sp, #0x48]
    27e8:      	mov	w8, #0x19               // =25
    27ec:      	mov	w9, #-0x1               // =-1
    27f0:      	ldr	x1, [x1]
    27f4:      	mov	x0, x19
    27f8:      	mov	w2, #-0x1               // =-1
    27fc:      	mov	x4, x29
    2800:      	blr	x8
    2804:      	b	0x2824 <generic_kprobe_process_event+0x24c4>
    2808:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    280c:      	ldr	x1, [sp, #0x48]
    2810:      	mov	x3, xzr
    2814:      	mov	w8, #0x82               // =130
    2818:      	ldr	x0, [x0]
    281c:      	mov	x2, x29
    2820:      	blr	x8
    2824:      	tbz	w0, #0x1f, 0x282c <generic_kprobe_process_event+0x24cc>
    2828:      	sxtw	x24, w0
    282c:      	tbnz	w24, #0x1f, 0x3944 <generic_kprobe_process_event+0x35e4>
    2830:      	and	x8, x24, #0x7fffffff
    2834:      	add	x21, x8, x21
    2838:      	ldr	x8, [sp, #0x58]
    283c:      	cmp	x21, x8
    2840:      	b.eq	0x3990 <generic_kprobe_process_event+0x3630>
    2844:      	subs	w23, w23, #0x1
    2848:      	b.ne	0x2778 <generic_kprobe_process_event+0x2418>
    284c:      	b	0x3cf4 <generic_kprobe_process_event+0x3994>
    2850:      	add	x8, sp, #0xf0
    2854:      	ldr	x21, [sp, #0x18]
    2858:      	mov	w1, #0x4                // =4
    285c:      	mov	w24, #0x4               // =4
    2860:      	ldr	x19, [x8]
    2864:      	mov	w8, #0x4                // =4
    2868:      	add	x0, x21, #0x28
    286c:      	add	x2, x19, #0x98
    2870:      	blr	x8
    2874:      	add	x0, x21, #0x2c
    2878:      	add	x2, x19, #0x70
    287c:      	mov	w8, #0x4                // =4
    2880:      	mov	w1, #0x4                // =4
    2884:      	blr	x8
    2888:      	add	x0, x21, #0x30
    288c:      	add	x2, x19, #0x90
    2890:      	mov	w8, #0x4                // =4
    2894:      	mov	w1, #0x4                // =4
    2898:      	blr	x8
    289c:      	add	x0, x21, #0x34
    28a0:      	add	x2, x19, #0xa8
    28a4:      	mov	w8, #0x4                // =4
    28a8:      	mov	w1, #0x4                // =4
    28ac:      	blr	x8
    28b0:      	str	xzr, [sp, #0xa8]
    28b4:      	add	x2, x19, #0xc8
    28b8:      	mov	w8, #0x8                // =8
    28bc:      	add	x9, sp, #0xa8
    28c0:      	mov	w10, #0x4               // =4
    28c4:      	add	x0, sp, #0xa8
    28c8:      	mov	w1, #0x8                // =8
    28cc:      	blr	x10
    28d0:      	add	x2, x19, #0xb8
    28d4:      	mov	w8, #0x2                // =2
    28d8:      	add	x9, sp, #0xf8
    28dc:      	mov	w10, #0x4               // =4
    28e0:      	add	x0, sp, #0xf8
    28e4:      	mov	w1, #0x2                // =2
    28e8:      	blr	x10
    28ec:      	ldr	x8, [sp, #0xa8]
    28f0:      	ldrh	w9, [sp, #0xf8]
    28f4:      	add	x0, sp, #0x94
    28f8:      	mov	w1, #0x1                // =1
    28fc:      	add	x23, x8, x9
    2900:      	mov	w8, #0x1                // =1
    2904:      	add	x9, sp, #0x94
    2908:      	mov	x2, x23
    290c:      	blr	x24
    2910:      	ldrb	w8, [sp, #0x94]
    2914:      	lsr	w8, w8, #4
    2918:      	cmp	w8, #0x6
    291c:      	b.eq	0x2ee0 <generic_kprobe_process_event+0x2b80>
    2920:      	cmp	w8, #0x4
    2924:      	b.ne	0x4200 <generic_kprobe_process_event+0x3ea0>
    2928:      	add	x2, x23, #0x9
    292c:      	mov	w8, #0x1                // =1
    2930:      	add	x9, sp, #0x98
    2934:      	mov	w10, #0x4               // =4
    2938:      	add	x0, sp, #0x98
    293c:      	mov	w1, #0x1                // =1
    2940:      	mov	w25, #0x4               // =4
    2944:      	blr	x10
    2948:      	ldr	x0, [sp, #0x18]
    294c:      	ldrb	w8, [sp, #0x98]
    2950:      	mov	w21, #0x2               // =2
    2954:      	add	x2, x23, #0xc
    2958:      	mov	w1, #0x4                // =4
    295c:      	mov	x24, x0
    2960:      	strh	w8, [x0, #0x24]
    2964:      	strh	w21, [x0, #0x26]
    2968:      	stp	xzr, xzr, [x0]
    296c:      	str	xzr, [x0, #0x18]
    2970:      	mov	w8, #0x4                // =4
    2974:      	str	xzr, [x24, #0x10]!
    2978:      	blr	x8
    297c:      	add	x2, x23, #0x10
    2980:      	mov	w8, #0x4                // =4
    2984:      	mov	x0, x24
    2988:      	mov	w1, #0x4                // =4
    298c:      	blr	x8
    2990:      	add	x2, x19, #0xb6
    2994:      	add	x8, sp, #0xe8
    2998:      	add	x0, sp, #0xe8
    299c:      	mov	w1, #0x2                // =2
    29a0:      	blr	x25
    29a4:      	ldrb	w23, [sp, #0x98]
    29a8:      	b	0x40c4 <generic_kprobe_process_event+0x3d64>
    29ac:      	add	x8, sp, #0xf0
    29b0:      	mov	w9, #0x2d               // =45
    29b4:      	mov	w1, #0x11               // =17
    29b8:      	ldr	x8, [x8]
    29bc:      	add	x2, x8, #0x118
    29c0:      	ldr	x8, [sp, #0x18]
    29c4:      	add	x0, x8, #0x4
    29c8:      	mov	w8, #0x11               // =17
    29cc:      	blr	x9
    29d0:      	mov	x21, x0
    29d4:      	tbnz	x0, #0x3f, 0x317c <generic_kprobe_process_event+0x2e1c>
    29d8:      	ldr	x9, [sp, #0x18]
    29dc:      	sub	w8, w21, #0x1
    29e0:      	add	x21, x21, #0x3
    29e4:      	str	w8, [x9]
    29e8:      	b	0x317c <generic_kprobe_process_event+0x2e1c>
    29ec:      	ldr	x0, [sp, #0x18]
    29f0:      	add	x8, sp, #0xf0
    29f4:      	mov	w9, #0x4                // =4
    29f8:      	mov	w1, #0x2                // =2
    29fc:      	ldr	x23, [x8]
    2a00:      	mov	w8, #0x2                // =2
    2a04:      	str	xzr, [x0]
    2a08:      	stp	xzr, xzr, [x0, #0x8]
    2a0c:      	mov	x2, x23
    2a10:      	blr	x9
    2a14:      	tbnz	x0, #0x3f, 0x3150 <generic_kprobe_process_event+0x2df0>
    2a18:      	ldr	x8, [sp, #0x18]
    2a1c:      	ldrh	w8, [x8]
    2a20:      	cmp	w8, #0xa
    2a24:      	b.eq	0x3108 <generic_kprobe_process_event+0x2da8>
    2a28:      	cmp	w8, #0x2
    2a2c:      	b.ne	0x313c <generic_kprobe_process_event+0x2ddc>
    2a30:      	add	x2, x23, #0x4
    2a34:      	add	x8, sp, #0xa8
    2a38:      	mov	w9, #0x4                // =4
    2a3c:      	add	x0, sp, #0xa8
    2a40:      	mov	w1, #0x4                // =4
    2a44:      	mov	w21, #0x4               // =4
    2a48:      	blr	x9
    2a4c:      	ldr	w8, [sp, #0xa8]
    2a50:      	ldr	x9, [sp, #0x18]
    2a54:      	add	x2, x23, #0x2
    2a58:      	add	x0, x9, #0x2
    2a5c:      	str	x8, [x9, #0x8]
    2a60:      	mov	w8, #0x2                // =2
    2a64:      	b	0x3134 <generic_kprobe_process_event+0x2dd4>
    2a68:      	adrp	x24, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2a6c:      	b	0x4208 <generic_kprobe_process_event+0x3ea8>
    2a70:      	ldr	x8, [sp, #0x30]
    2a74:      	add	x21, x8, #0x90
    2a78:      	add	x8, x21, x23
    2a7c:      	str	x8, [sp, #0x58]
    2a80:      	add	x8, sp, #0xf0
    2a84:      	str	xzr, [x8]
    2a88:      	ldr	x8, [sp, #0x48]
    2a8c:      	tbnz	w8, #0x4, 0x3028 <generic_kprobe_process_event+0x2cc8>
    2a90:      	ldr	x9, [sp, #0x48]
    2a94:      	mov	x8, xzr
    2a98:      	and	x23, x9, #0xffffffff
    2a9c:      	ldr	x9, [sp, #0x38]
    2aa0:      	and	w9, w9, #0xf
    2aa4:      	cmp	w9, #0x2
    2aa8:      	b.le	0x31f0 <generic_kprobe_process_event+0x2e90>
    2aac:      	cmp	w9, #0x3
    2ab0:      	b.eq	0x349c <generic_kprobe_process_event+0x313c>
    2ab4:      	cmp	w9, #0x4
    2ab8:      	b.eq	0x34a4 <generic_kprobe_process_event+0x3144>
    2abc:      	cmp	w9, #0x5
    2ac0:      	b.ne	0x34bc <generic_kprobe_process_event+0x315c>
    2ac4:      	mov	w9, #0x5e70             // =24176
    2ac8:      	b	0x34b0 <generic_kprobe_process_event+0x3150>
    2acc:      	ldr	x29, [sp, #0x18]
    2ad0:      	add	x2, x25, #0x8
    2ad4:      	mov	w8, #0x4                // =4
    2ad8:      	mov	w1, #0x4                // =4
    2adc:      	mov	w21, #0x4               // =4
    2ae0:      	mov	x0, x29
    2ae4:      	add	x23, x29, #0x28
    2ae8:      	add	x19, x29, #0x40
    2aec:      	blr	x8
    2af0:      	add	x0, x29, #0x4
    2af4:      	add	x2, x25, #0xc
    2af8:      	mov	w8, #0x4                // =4
    2afc:      	mov	w1, #0x4                // =4
    2b00:      	blr	x8
    2b04:      	add	x0, x29, #0x10
    2b08:      	add	x2, x25, #0x18
    2b0c:      	mov	w8, #0x4                // =4
    2b10:      	mov	w1, #0x4                // =4
    2b14:      	blr	x8
    2b18:      	add	x0, x29, #0x14
    2b1c:      	add	x2, x25, #0x1c
    2b20:      	mov	w8, #0x4                // =4
    2b24:      	mov	w1, #0x4                // =4
    2b28:      	blr	x8
    2b2c:      	add	x0, x29, #0x8
    2b30:      	add	x2, x25, #0x10
    2b34:      	mov	w8, #0x4                // =4
    2b38:      	mov	w1, #0x4                // =4
    2b3c:      	blr	x8
    2b40:      	add	x0, x29, #0xc
    2b44:      	add	x2, x25, #0x14
    2b48:      	mov	w8, #0x4                // =4
    2b4c:      	mov	w1, #0x4                // =4
    2b50:      	blr	x8
    2b54:      	add	x0, x29, #0x18
    2b58:      	add	x2, x25, #0x20
    2b5c:      	mov	w8, #0x4                // =4
    2b60:      	mov	w1, #0x4                // =4
    2b64:      	blr	x8
    2b68:      	add	x0, x29, #0x1c
    2b6c:      	add	x2, x25, #0x24
    2b70:      	mov	w8, #0x4                // =4
    2b74:      	mov	w1, #0x4                // =4
    2b78:      	blr	x8
    2b7c:      	str	wzr, [x29, #0x24]
    2b80:      	add	x0, x29, #0x20
    2b84:      	add	x2, x25, #0x28
    2b88:      	mov	w8, #0x4                // =4
    2b8c:      	mov	w1, #0x4                // =4
    2b90:      	blr	x8
    2b94:      	add	x0, x29, #0x30
    2b98:      	add	x2, x25, #0x40
    2b9c:      	mov	w24, #0x8               // =8
    2ba0:      	mov	w8, #0x4                // =4
    2ba4:      	mov	w1, #0x8                // =8
    2ba8:      	blr	x8
    2bac:      	add	x0, x29, #0x38
    2bb0:      	add	x2, x25, #0x30
    2bb4:      	mov	w8, #0x4                // =4
    2bb8:      	mov	w1, #0x8                // =8
    2bbc:      	blr	x8
    2bc0:      	add	x2, x25, #0x38
    2bc4:      	mov	w8, #0x4                // =4
    2bc8:      	mov	x0, x23
    2bcc:      	mov	w1, #0x8                // =8
    2bd0:      	blr	x8
    2bd4:      	add	x2, x25, #0x90
    2bd8:      	add	x8, sp, #0xa8
    2bdc:      	mov	w9, #0x4                // =4
    2be0:      	add	x0, sp, #0xa8
    2be4:      	mov	w1, #0x8                // =8
    2be8:      	blr	x9
    2bec:      	ldr	x23, [sp, #0xa8]
    2bf0:      	mov	w8, #0x4                // =4
    2bf4:      	mov	x0, x19
    2bf8:      	mov	w1, #0x4                // =4
    2bfc:      	add	x2, x23, #0xc8
    2c00:      	blr	x8
    2c04:      	add	x0, x29, #0x44
    2c08:      	add	x2, x23, #0xcc
    2c0c:      	mov	w8, #0x4                // =4
    2c10:      	mov	w1, #0x4                // =4
    2c14:      	blr	x8
    2c18:      	add	x0, x29, #0x48
    2c1c:      	add	x2, x23, #0xd0
    2c20:      	mov	w8, #0x4                // =4
    2c24:      	mov	w1, #0x4                // =4
    2c28:      	blr	x8
    2c2c:      	add	x0, x29, #0x4c
    2c30:      	add	x2, x23, #0x158
    2c34:      	mov	w1, #0x4                // =4
    2c38:      	blr	x21
    2c3c:      	mov	w21, #0x50              // =80
    2c40:      	b	0x391c <generic_kprobe_process_event+0x35bc>
    2c44:      	ldr	x23, [sp, #0x18]
    2c48:      	add	x2, x25, #0xc8
    2c4c:      	mov	w8, #0x4                // =4
    2c50:      	mov	w1, #0x4                // =4
    2c54:      	mov	w21, #0x4               // =4
    2c58:      	mov	x0, x23
    2c5c:      	blr	x8
    2c60:      	add	x0, x23, #0x4
    2c64:      	add	x2, x25, #0xcc
    2c68:      	mov	w8, #0x4                // =4
    2c6c:      	mov	w1, #0x4                // =4
    2c70:      	blr	x8
    2c74:      	add	x0, x23, #0x8
    2c78:      	add	x2, x25, #0xd0
    2c7c:      	mov	w8, #0x4                // =4
    2c80:      	mov	w1, #0x4                // =4
    2c84:      	blr	x8
    2c88:      	add	x0, x23, #0xc
    2c8c:      	add	x2, x25, #0x158
    2c90:      	mov	w1, #0x4                // =4
    2c94:      	blr	x21
    2c98:      	mov	w21, #0x10              // =16
    2c9c:      	b	0x391c <generic_kprobe_process_event+0x35bc>
    2ca0:      	ldr	x23, [sp, #0x18]
    2ca4:      	add	x2, x25, #0x38
    2ca8:      	mov	w8, #0x4                // =4
    2cac:      	mov	w1, #0x4                // =4
    2cb0:      	mov	w21, #0x4               // =4
    2cb4:      	mov	x0, x23
    2cb8:      	blr	x8
    2cbc:      	add	x0, x23, #0x4
    2cc0:      	add	x2, x25, #0x3c
    2cc4:      	mov	w8, #0x4                // =4
    2cc8:      	mov	w1, #0x4                // =4
    2ccc:      	blr	x8
    2cd0:      	add	x0, x23, #0x8
    2cd4:      	add	x2, x25, #0x40
    2cd8:      	mov	w8, #0x4                // =4
    2cdc:      	mov	w1, #0x4                // =4
    2ce0:      	blr	x8
    2ce4:      	add	x0, x23, #0xc
    2ce8:      	add	x2, x25, #0x44
    2cec:      	mov	w8, #0x4                // =4
    2cf0:      	mov	w1, #0x4                // =4
    2cf4:      	blr	x8
    2cf8:      	add	x0, x23, #0x10
    2cfc:      	add	x2, x25, #0x80
    2d00:      	mov	w8, #0x10               // =16
    2d04:      	mov	w1, #0x10               // =16
    2d08:      	blr	x21
    2d0c:      	mov	w21, #0x20              // =32
    2d10:      	b	0x391c <generic_kprobe_process_event+0x35bc>
    2d14:      	ldr	x23, [sp, #0x18]
    2d18:      	mov	w8, #0x4                // =4
    2d1c:      	mov	w1, #0x4                // =4
    2d20:      	mov	x2, x25
    2d24:      	mov	w21, #0x4               // =4
    2d28:      	mov	x0, x23
    2d2c:      	blr	x8
    2d30:      	add	x0, x23, #0x4
    2d34:      	add	x2, x25, #0x4
    2d38:      	mov	w8, #0x4                // =4
    2d3c:      	mov	w1, #0x4                // =4
    2d40:      	blr	x8
    2d44:      	add	x0, x23, #0x8
    2d48:      	add	x2, x25, #0x30
    2d4c:      	mov	w8, #0x10               // =16
    2d50:      	b	0x2dd0 <generic_kprobe_process_event+0x2a70>
    2d54:      	add	x2, x25, #0x4
    2d58:      	add	x8, sp, #0xa8
    2d5c:      	mov	w9, #0x4                // =4
    2d60:      	add	x0, sp, #0xa8
    2d64:      	mov	w1, #0x4                // =4
    2d68:      	mov	w21, #0x4               // =4
    2d6c:      	blr	x9
    2d70:      	ldr	w8, [sp, #0xa8]
    2d74:      	ldr	x23, [sp, #0x18]
    2d78:      	add	x2, x25, #0xc
    2d7c:      	add	x0, sp, #0xa8
    2d80:      	mov	w1, #0x4                // =4
    2d84:      	str	w8, [x23]
    2d88:      	add	x8, sp, #0xa8
    2d8c:      	blr	x21
    2d90:      	ldr	w8, [sp, #0xa8]
    2d94:      	add	x2, x25, #0x50
    2d98:      	add	x9, sp, #0xa8
    2d9c:      	mov	w10, #0x2d              // =45
    2da0:      	str	w8, [x23, #0x4]
    2da4:      	mov	w8, #0x8                // =8
    2da8:      	add	x0, sp, #0xa8
    2dac:      	mov	w1, #0x8                // =8
    2db0:      	mov	w21, #0x2d              // =45
    2db4:      	blr	x10
    2db8:      	ldr	x8, [sp, #0xa8]
    2dbc:      	add	x0, x23, #0x8
    2dc0:      	mov	w9, #0x10               // =16
    2dc4:      	add	x8, x8, #0x3f8
    2dc8:      	ldr	x8, [sp, #0xa8]
    2dcc:      	add	x2, x8, #0x3f8
    2dd0:      	mov	w1, #0x10               // =16
    2dd4:      	blr	x21
    2dd8:      	mov	w21, #0x18              // =24
    2ddc:      	b	0x391c <generic_kprobe_process_event+0x35bc>
    2de0:      	ldr	x11, [sp, #0x18]
    2de4:      	mov	w8, #0x8                // =8
    2de8:      	mov	w9, #0x4                // =4
    2dec:      	add	x10, sp, #0xa8
    2df0:      	stp	xzr, xzr, [x11, #0x40]
    2df4:      	mov	x2, x25
    2df8:      	stp	xzr, xzr, [x11, #0x30]
    2dfc:      	stp	xzr, xzr, [x11, #0x20]
    2e00:      	add	x0, sp, #0xa8
    2e04:      	mov	w1, #0x8                // =8
    2e08:      	stp	xzr, xzr, [x11, #0x10]
    2e0c:      	stp	xzr, xzr, [x11]
    2e10:      	blr	x9
    2e14:      	mov	x21, xzr
    2e18:      	cbnz	x0, 0x391c <generic_kprobe_process_event+0x35bc>
    2e1c:      	ldr	x8, [sp, #0x18]
    2e20:      	mov	w9, #0x3f               // =63
    2e24:      	mov	w10, #0x2d              // =45
    2e28:      	mov	w1, #0x3f               // =63
    2e2c:      	add	x0, x8, #0x10
    2e30:      	ldr	x8, [sp, #0xa8]
    2e34:      	ldr	x2, [sp, #0xa8]
    2e38:      	blr	x10
    2e3c:      	tbnz	x0, #0x3f, 0x3020 <generic_kprobe_process_event+0x2cc0>
    2e40:      	add	x2, x25, #0x8
    2e44:      	mov	w21, #0x8               // =8
    2e48:      	add	x8, sp, #0x100
    2e4c:      	mov	w9, #0x4                // =4
    2e50:      	add	x0, sp, #0x100
    2e54:      	mov	w1, #0x8                // =8
    2e58:      	mov	w23, #0x4               // =4
    2e5c:      	blr	x9
    2e60:      	ldr	x8, [sp, #0x18]
    2e64:      	add	x10, sp, #0xf0
    2e68:      	mov	w9, #0x4                // =4
    2e6c:      	mov	w1, #0x8                // =8
    2e70:      	add	x0, x8, #0x8
    2e74:      	ldr	x8, [x10, #0x10]
    2e78:      	add	x8, x8, #0x360
    2e7c:      	ldr	x8, [x10, #0x10]
    2e80:      	add	x2, x8, #0x360
    2e84:      	blr	x9
    2e88:      	add	x2, x25, #0x58
    2e8c:      	add	x8, sp, #0x100
    2e90:      	add	x0, sp, #0x100
    2e94:      	mov	w1, #0x4                // =4
    2e98:      	blr	x23
    2e9c:      	cbnz	x0, 0x2eb4 <generic_kprobe_process_event+0x2b54>
    2ea0:      	ldr	w8, [sp, #0x100]
    2ea4:      	ldr	x9, [sp, #0x18]
    2ea8:      	cmp	w8, #0x0
    2eac:      	cset	w8, ne
    2eb0:      	str	w8, [x9]
    2eb4:      	mov	w21, #0x50              // =80
    2eb8:      	b	0x391c <generic_kprobe_process_event+0x35bc>
    2ebc:      	ldr	x8, [sp, #0x50]
    2ec0:      	mov	w21, #0x8               // =8
    2ec4:      	add	x8, x8, x23
    2ec8:      	str	xzr, [x8, #0x90]
    2ecc:      	b	0x3d2c <generic_kprobe_process_event+0x39cc>
    2ed0:      	mov	w25, #0x9               // =9
    2ed4:      	b	0x217c <generic_kprobe_process_event+0x1e1c>
    2ed8:      	mov	x21, #-0x1              // =-1
    2edc:      	b	0x3d2c <generic_kprobe_process_event+0x39cc>
    2ee0:      	str	wzr, [sp, #0x100]
    2ee4:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2ee8:      	ldr	x21, [sp, #0xa8]
    2eec:      	mov	w8, #0x1                // =1
    2ef0:      	add	x9, sp, #0x100
    2ef4:      	add	x1, sp, #0x100
    2ef8:      	ldrh	w23, [sp, #0xf8]
    2efc:      	ldr	x0, [x0]
    2f00:      	add	x22, x21, x23
    2f04:      	blr	x8
    2f08:      	cbz	x0, 0x4080 <generic_kprobe_process_event+0x3d20>
    2f0c:      	mov	w8, #0xff               // =255
    2f10:      	strh	w23, [x0]
    2f14:      	strb	wzr, [x0, #0x7]
    2f18:      	add	x25, x0, #0x6
    2f1c:      	add	x2, x22, #0x6
    2f20:      	mov	w9, #0x4                // =4
    2f24:      	strb	w8, [x0, #0x5]
    2f28:      	mov	w8, #0x1                // =1
    2f2c:      	mov	x24, x0
    2f30:      	mov	x0, x25
    2f34:      	mov	w1, #0x1                // =1
    2f38:      	blr	x9
    2f3c:      	tbnz	x0, #0x3f, 0x4080 <generic_kprobe_process_event+0x3d20>
    2f40:      	ldrb	w8, [x24, #0x5]
    2f44:      	cmp	w8, #0x32
    2f48:      	b.gt	0x3410 <generic_kprobe_process_event+0x30b0>
    2f4c:      	cbz	w8, 0x3488 <generic_kprobe_process_event+0x3128>
    2f50:      	cmp	w8, #0x2b
    2f54:      	b.eq	0x3488 <generic_kprobe_process_event+0x3128>
    2f58:      	cmp	w8, #0x2c
    2f5c:      	b.ne	0x3a58 <generic_kprobe_process_event+0x36f8>
    2f60:      	mov	w8, #0x8                // =8
    2f64:      	b	0x39a4 <generic_kprobe_process_event+0x3644>
    2f68:      	ldr	x0, [sp, #0x18]
    2f6c:      	add	x2, x23, #0x48
    2f70:      	mov	w21, #0x10              // =16
    2f74:      	mov	w8, #0x4                // =4
    2f78:      	mov	w1, #0x10               // =16
    2f7c:      	mov	w25, #0x4               // =4
    2f80:      	blr	x8
    2f84:      	add	x2, x23, #0x38
    2f88:      	mov	x0, x24
    2f8c:      	mov	w1, #0x10               // =16
    2f90:      	blr	x25
    2f94:      	ldr	x25, [sp, #0x18]
    2f98:      	add	x2, x23, #0xe
    2f9c:      	mov	w21, #0x2               // =2
    2fa0:      	mov	w8, #0x4                // =4
    2fa4:      	mov	w1, #0x2                // =2
    2fa8:      	add	x24, x23, #0xc
    2fac:      	mov	w23, #0x4               // =4
    2fb0:      	add	x0, x25, #0x20
    2fb4:      	blr	x8
    2fb8:      	add	x0, x25, #0x22
    2fbc:      	mov	w1, #0x2                // =2
    2fc0:      	mov	x2, x24
    2fc4:      	blr	x23
    2fc8:      	ldrh	w8, [x25, #0x22]
    2fcc:      	adrp	x0, 0x2000 <generic_kprobe_process_event+0x1ca0>
    2fd0:      	add	x9, sp, #0xa8
    2fd4:      	add	x1, sp, #0xa8
    2fd8:      	rev	w8, w8
    2fdc:      	lsr	w8, w8, #16
    2fe0:      	strh	w8, [x25, #0x22]
    2fe4:      	add	x8, sp, #0xf0
    2fe8:      	ldr	x8, [x8]
    2fec:      	str	x8, [sp, #0xa8]
    2ff0:      	mov	w8, #0x1                // =1
    2ff4:      	ldr	x0, [x0]
    2ff8:      	blr	x8
    2ffc:      	cbz	x0, 0x4200 <generic_kprobe_process_event+0x3ea0>
    3000:      	ldr	w8, [x0]
    3004:      	ldr	x9, [sp, #0x50]
    3008:      	str	w8, [x9, #0x10]
    300c:      	ldr	x8, [x0, #0x8]
    3010:      	str	x8, [x9, #0x18]
    3014:      	ldr	w8, [x0, #0x4]
    3018:      	str	w8, [x9, #0x7c]
    301c:      	b	0x4200 <generic_kprobe_process_event+0x3ea0>
    3020:      	mov	x21, xzr
    3024:      	b	0x391c <generic_kprobe_process_event+0x35bc>
    3028:      	mov	w8, #0xe                // =14
    302c:      	blr	x8
    3030:      	cmn	x0, #0x16
    3034:      	b.ne	0x305c <generic_kprobe_process_event+0x2cfc>
    3038:      	ldr	x8, [sp, #0x10]
    303c:      	mov	w9, #0x4                // =4
    3040:      	add	x10, sp, #0xa8
    3044:      	add	x0, sp, #0xa8
    3048:      	mov	w1, #0x8                // =8
    304c:      	add	x2, x8, #0xe8
    3050:      	mov	w8, #0x8                // =8
    3054:      	blr	x9
    3058:      	ldr	x0, [sp, #0xa8]
    305c:      	ldr	x8, [sp, #0x30]
    3060:      	mov	x3, xzr
    3064:      	add	x10, sp, #0xa8
    3068:      	add	x1, sp, #0x100
    306c:      	ldr	x9, [x8, #0x60]
    3070:      	ldr	x8, [x8, #0x8]
    3074:      	str	xzr, [sp, #0xb8]
    3078:      	add	x2, sp, #0xa8
    307c:      	stp	x8, x25, [sp, #0xa8]
    3080:      	add	x8, sp, #0xf0
    3084:      	stp	x9, x0, [x8, #0x10]
    3088:      	adrp	x0, 0x3000 <generic_kprobe_process_event+0x2ca0>
    308c:      	mov	w8, #0x2                // =2
    3090:      	add	x9, sp, #0x100
    3094:      	ldr	x0, [x0]
    3098:      	blr	x8
    309c:      	cbz	x0, 0x3454 <generic_kprobe_process_event+0x30f4>
    30a0:      	neg	w8, w0
    30a4:      	adrp	x23, 0x3000 <generic_kprobe_process_event+0x2ca0>
    30a8:      	mov	w9, #0x1                // =1
    30ac:      	strh	w8, [sp, #0x80]
    30b0:      	mov	w8, #0x5                // =5
    30b4:      	add	x1, sp, #0x80
    30b8:      	mov	w21, #0x1               // =1
    30bc:      	strh	w8, [sp, #0x82]
    30c0:      	mov	x8, #0x46               // =70
    30c4:      	movk	x8, #0x2, lsl #32
    30c8:      	stur	x8, [sp, #0x84]
    30cc:      	add	x8, sp, #0x80
    30d0:      	ldr	x23, [x23]
    30d4:      	mov	x0, x23
    30d8:      	blr	x9
    30dc:      	cbz	x0, 0x3430 <generic_kprobe_process_event+0x30d0>
    30e0:      	ldr	w8, [x0]
    30e4:      	add	w8, w8, #0x1
    30e8:      	str	w8, [x0]
    30ec:      	b	0x3454 <generic_kprobe_process_event+0x30f4>
    30f0:      	cmp	w8, #0x1
    30f4:      	b.eq	0x32d4 <generic_kprobe_process_event+0x2f74>
    30f8:      	cmp	w8, #0x2
    30fc:      	b.ne	0x3324 <generic_kprobe_process_event+0x2fc4>
    3100:      	mov	w9, #0x5e58             // =24152
    3104:      	b	0x32d8 <generic_kprobe_process_event+0x2f78>
    3108:      	ldr	x24, [sp, #0x18]
    310c:      	add	x2, x23, #0x8
    3110:      	mov	w8, #0x10               // =16
    3114:      	mov	w9, #0x4                // =4
    3118:      	mov	w1, #0x10               // =16
    311c:      	mov	w21, #0x4               // =4
    3120:      	add	x0, x24, #0x8
    3124:      	blr	x9
    3128:      	add	x0, x24, #0x2
    312c:      	add	x2, x23, #0x2
    3130:      	mov	w8, #0x2                // =2
    3134:      	mov	w1, #0x2                // =2
    3138:      	blr	x21
    313c:      	ldr	x9, [sp, #0x18]
    3140:      	ldrh	w8, [x9, #0x2]
    3144:      	rev	w8, w8
    3148:      	lsr	w8, w8, #16
    314c:      	strh	w8, [x9, #0x2]
    3150:      	mov	w21, #0x18              // =24
    3154:      	b	0x317c <generic_kprobe_process_event+0x2e1c>
    3158:      	add	x2, x23, #0x3
    315c:      	mov	w21, #0x6b              // =107
    3160:      	mov	w8, #0x71               // =113
    3164:      	mov	w1, #0x6b               // =107
    3168:      	blr	x8
    316c:      	tbnz	w0, #0x1f, 0x3178 <generic_kprobe_process_event+0x2e18>
    3170:      	ldr	x8, [sp, #0x18]
    3174:      	strb	w21, [x8, #0x3]
    3178:      	mov	w21, #0x70              // =112
    317c:      	mov	x24, x25
    3180:      	b	0x420c <generic_kprobe_process_event+0x3eac>
    3184:      	ldr	x9, [sp, #0x50]
    3188:      	mov	w21, #0xc               // =12
    318c:      	str	wzr, [x9]
    3190:      	ldr	x9, [sp, #0x118]
    3194:      	add	x8, x8, x9
    3198:      	add	x8, x8, #0x8
    319c:      	str	x8, [sp, #0x50]
    31a0:      	ldr	x9, [sp, #0x58]
    31a4:      	mov	w8, #0xfff              // =4095
    31a8:      	ldr	x2, [sp, #0x38]
    31ac:      	cmp	x9, #0xfff
    31b0:      	csel	x23, x9, x8, lo
    31b4:      	ldr	x8, [sp, #0x50]
    31b8:      	mov	w1, w23
    31bc:      	add	x0, x8, #0x8
    31c0:      	mov	w8, #0x4                // =4
    31c4:      	blr	x8
    31c8:      	tbnz	w0, #0x1f, 0x31dc <generic_kprobe_process_event+0x2e7c>
    31cc:      	ldp	x8, x9, [sp, #0x50]
    31d0:      	add	x21, x21, x23
    31d4:      	stp	w9, w23, [x8]
    31d8:      	b	0x3d2c <generic_kprobe_process_event+0x39cc>
    31dc:      	ldr	x9, [sp, #0x50]
    31e0:      	mov	w8, #-0x2               // =-2
    31e4:      	mov	w21, #0x4               // =4
    31e8:      	str	w8, [x9]
    31ec:      	b	0x3d2c <generic_kprobe_process_event+0x39cc>
    31f0:      	cmp	w9, #0x1
    31f4:      	b.eq	0x34ac <generic_kprobe_process_event+0x314c>
    31f8:      	cmp	w9, #0x2
    31fc:      	b.ne	0x34bc <generic_kprobe_process_event+0x315c>
    3200:      	mov	w9, #0x5e58             // =24152
    3204:      	b	0x34b0 <generic_kprobe_process_event+0x3150>
    3208:      	ldr	x0, [sp, #0x18]
    320c:      	add	x2, x23, #0x48
    3210:      	mov	w21, #0x10              // =16
    3214:      	mov	w8, #0x4                // =4
    3218:      	mov	w1, #0x10               // =16
    321c:      	mov	w29, #0x4               // =4
    3220:      	blr	x8
    3224:      	add	x2, x23, #0x38
    3228:      	mov	x0, x24
    322c:      	mov	w1, #0x10               // =16
    3230:      	blr	x29
    3234:      	ldr	x29, [sp, #0x18]
    3238:      	add	x2, x23, #0xe
    323c:      	mov	w21, #0x2               // =2
    3240:      	mov	w8, #0x4                // =4
    3244:      	mov	w1, #0x2                // =2
    3248:      	add	x24, x23, #0xc
    324c:      	mov	w23, #0x4               // =4
    3250:      	add	x0, x29, #0x20
    3254:      	blr	x8
    3258:      	add	x0, x29, #0x22
    325c:      	mov	w1, #0x2                // =2
    3260:      	mov	x2, x24
    3264:      	blr	x23
    3268:      	ldrh	w8, [x29, #0x22]
    326c:      	rev	w8, w8
    3270:      	lsr	w8, w8, #16
    3274:      	strh	w8, [x29, #0x22]
    3278:      	ldr	x8, [sp, #0x18]
    327c:      	adrp	x0, 0x3000 <generic_kprobe_process_event+0x2ca0>
    3280:      	add	x9, sp, #0xa8
    3284:      	add	x1, sp, #0xa8
    3288:      	ldr	x8, [x8, #0x28]
    328c:      	str	x8, [sp, #0xa8]
    3290:      	mov	w8, #0x1                // =1
    3294:      	ldr	x0, [x0]
    3298:      	blr	x8
    329c:      	cbz	x0, 0x32bc <generic_kprobe_process_event+0x2f5c>
    32a0:      	ldr	w8, [x0]
    32a4:      	ldr	x9, [sp, #0x30]
    32a8:      	str	w8, [x9, #0x10]
    32ac:      	ldr	x8, [x0, #0x8]
    32b0:      	str	x8, [x9, #0x18]
    32b4:      	ldr	w8, [x0, #0x4]
    32b8:      	str	w8, [x9, #0x7c]
    32bc:      	mov	w21, #0x40              // =64
    32c0:      	b	0x391c <generic_kprobe_process_event+0x35bc>
    32c4:      	mov	w9, #0x5e60             // =24160
    32c8:      	b	0x32d8 <generic_kprobe_process_event+0x2f78>
    32cc:      	mov	w9, #0x5e68             // =24168
    32d0:      	b	0x32d8 <generic_kprobe_process_event+0x2f78>
    32d4:      	mov	w9, #0x5e50             // =24144
    32d8:      	ldr	x8, [sp, #0x30]
    32dc:      	add	x8, x8, x9
    32e0:      	ldr	x23, [x8]
    32e4:      	ldr	x8, [sp, #0x38]
    32e8:      	tbnz	w8, #0x4, 0x3334 <generic_kprobe_process_event+0x2fd4>
    32ec:      	cbz	x23, 0x3400 <generic_kprobe_process_event+0x30a0>
    32f0:      	mov	w8, #0x10               // =16
    32f4:      	mov	w9, #0x4                // =4
    32f8:      	add	x10, sp, #0xa8
    32fc:      	mov	x2, x25
    3300:      	add	x0, sp, #0xa8
    3304:      	mov	w1, #0x10               // =16
    3308:      	blr	x9
    330c:      	tbnz	w0, #0x1f, 0x3910 <generic_kprobe_process_event+0x35b0>
    3310:      	ldr	x20, [sp, #0xb0]
    3314:      	cmp	x20, #0xffe
    3318:      	b.ls	0x36c4 <generic_kprobe_process_event+0x3364>
    331c:      	mov	w8, #-0x3               // =-3
    3320:      	b	0x3914 <generic_kprobe_process_event+0x35b4>
    3324:      	ldr	x8, [sp, #0x38]
    3328:      	mov	x23, xzr
    332c:      	mov	x20, xzr
    3330:      	tbz	w8, #0x4, 0x3404 <generic_kprobe_process_event+0x30a4>
    3334:      	mov	w8, #0xe                // =14
    3338:      	blr	x8
    333c:      	cmn	x0, #0x16
    3340:      	b.ne	0x3368 <generic_kprobe_process_event+0x3008>
    3344:      	ldr	x8, [sp, #0x10]
    3348:      	mov	w9, #0x4                // =4
    334c:      	add	x10, sp, #0xa8
    3350:      	add	x0, sp, #0xa8
    3354:      	mov	w1, #0x8                // =8
    3358:      	add	x2, x8, #0xe8
    335c:      	mov	w8, #0x8                // =8
    3360:      	blr	x9
    3364:      	ldr	x0, [sp, #0xa8]
    3368:      	ldr	x8, [sp, #0x30]
    336c:      	mov	x3, xzr
    3370:      	add	x10, sp, #0xa8
    3374:      	add	x1, sp, #0x100
    3378:      	ldr	x9, [x8, #0x60]
    337c:      	ldr	x8, [x8, #0x8]
    3380:      	str	x23, [sp, #0xb8]
    3384:      	add	x2, sp, #0xa8
    3388:      	stp	x8, x25, [sp, #0xa8]
    338c:      	add	x8, sp, #0xf0
    3390:      	stp	x9, x0, [x8, #0x10]
    3394:      	adrp	x0, 0x3000 <generic_kprobe_process_event+0x2ca0>
    3398:      	mov	w8, #0x2                // =2
    339c:      	add	x9, sp, #0x100
    33a0:      	ldr	x0, [x0]
    33a4:      	blr	x8
    33a8:      	cbz	x0, 0x3480 <generic_kprobe_process_event+0x3120>
    33ac:      	neg	w8, w0
    33b0:      	adrp	x23, 0x3000 <generic_kprobe_process_event+0x2ca0>
    33b4:      	mov	w9, #0x1                // =1
    33b8:      	strh	w8, [sp, #0x80]
    33bc:      	mov	w8, #0x5                // =5
    33c0:      	add	x1, sp, #0x80
    33c4:      	mov	w21, #0x1               // =1
    33c8:      	strh	w8, [sp, #0x82]
    33cc:      	mov	x8, #0x57               // =87
    33d0:      	movk	x8, #0x2, lsl #32
    33d4:      	stur	x8, [sp, #0x84]
    33d8:      	add	x8, sp, #0x80
    33dc:      	ldr	x23, [x23]
    33e0:      	mov	x0, x23
    33e4:      	blr	x9
    33e8:      	cbz	x0, 0x345c <generic_kprobe_process_event+0x30fc>
    33ec:      	ldr	w8, [x0]
    33f0:      	add	w8, w8, #0x1
    33f4:      	str	w8, [x0]
    33f8:      	mov	w8, #-0x4               // =-4
    33fc:      	b	0x3914 <generic_kprobe_process_event+0x35b4>
    3400:      	mov	x20, xzr
    3404:      	stp	w20, w20, [x19]
    3408:      	add	x21, x20, #0x8
    340c:      	b	0x391c <generic_kprobe_process_event+0x35bc>
    3410:      	cmp	w8, #0x33
    3414:      	b.eq	0x3998 <generic_kprobe_process_event+0x3638>
    3418:      	cmp	w8, #0x3c
    341c:      	b.eq	0x3488 <generic_kprobe_process_event+0x3128>
    3420:      	cmp	w8, #0xff
    3424:      	b.ne	0x3a58 <generic_kprobe_process_event+0x36f8>
    3428:      	mov	w8, #0x28               // =40
    342c:      	b	0x39a4 <generic_kprobe_process_event+0x3644>
    3430:      	str	w21, [sp, #0xe8]
    3434:      	mov	x3, xzr
    3438:      	mov	w8, #0x2                // =2
    343c:      	add	x9, sp, #0x80
    3440:      	add	x10, sp, #0xe8
    3444:      	add	x1, sp, #0x80
    3448:      	add	x2, sp, #0xe8
    344c:      	mov	x0, x23
    3450:      	blr	x8
    3454:      	mov	w8, #-0x4               // =-4
    3458:      	b	0x36b4 <generic_kprobe_process_event+0x3354>
    345c:      	str	w21, [sp, #0xf8]
    3460:      	mov	x3, xzr
    3464:      	mov	w8, #0x2                // =2
    3468:      	add	x9, sp, #0x80
    346c:      	add	x10, sp, #0xf8
    3470:      	add	x1, sp, #0x80
    3474:      	add	x2, sp, #0xf8
    3478:      	mov	x0, x23
    347c:      	blr	x8
    3480:      	mov	w8, #-0x4               // =-4
    3484:      	b	0x3914 <generic_kprobe_process_event+0x35b4>
    3488:      	ldrb	w8, [x24, #0x7]
    348c:      	lsl	w8, w8, #3
    3490:      	b	0x39a0 <generic_kprobe_process_event+0x3640>
    3494:      	mov	w21, #0x4               // =4
    3498:      	b	0x3d2c <generic_kprobe_process_event+0x39cc>
    349c:      	mov	w9, #0x5e60             // =24160
    34a0:      	b	0x34b0 <generic_kprobe_process_event+0x3150>
    34a4:      	mov	w9, #0x5e68             // =24168
    34a8:      	b	0x34b0 <generic_kprobe_process_event+0x3150>
    34ac:      	mov	w9, #0x5e50             // =24144
    34b0:      	ldr	x8, [sp, #0x30]
    34b4:      	add	x8, x8, x9
    34b8:      	ldr	x8, [x8]
    34bc:      	add	x29, sp, #0xf0
    34c0:      	mov	w24, #0x8               // =8
    34c4:      	add	x9, sp, #0xf0
    34c8:      	str	x8, [x29, #0x8]
    34cc:      	mov	w8, #0x4                // =4
    34d0:      	add	x10, sp, #0xf8
    34d4:      	add	x0, sp, #0xf0
    34d8:      	add	x2, sp, #0xf8
    34dc:      	mov	w1, #0x8                // =8
    34e0:      	blr	x8
    34e4:      	ldr	x22, [x29]
    34e8:      	tbz	w23, #0x5, 0x3678 <generic_kprobe_process_event+0x3318>
    34ec:      	cmp	x22, #0x1, lsl #12      // =0x1000
    34f0:      	b.lo	0x365c <generic_kprobe_process_event+0x32fc>
    34f4:      	ldr	x9, [sp, #0x58]
    34f8:      	mov	w8, #0x1                // =1
    34fc:      	adrp	x0, 0x3000 <generic_kprobe_process_event+0x2ca0>
    3500:      	add	x1, sp, #0x100
    3504:      	str	w8, [x9]
    3508:      	str	wzr, [sp, #0x100]
    350c:      	add	x9, sp, #0x100
    3510:      	ldr	x0, [x0]
    3514:      	blr	x8
    3518:      	cbz	x0, 0x3918 <generic_kprobe_process_event+0x35b8>
    351c:      	mov	w8, #0x18               // =24
    3520:      	mov	x20, x0
    3524:      	str	w8, [x0]
    3528:      	mov	w8, #0xe                // =14
    352c:      	blr	x8
    3530:      	mov	x23, x20
    3534:      	cmn	x0, #0x16
    3538:      	str	x0, [x23, #0x10]!
    353c:      	b.ne	0x3568 <generic_kprobe_process_event+0x3208>
    3540:      	ldr	x8, [sp, #0x10]
    3544:      	mov	w9, #0x4                // =4
    3548:      	add	x10, sp, #0xa8
    354c:      	add	x0, sp, #0xa8
    3550:      	mov	w1, #0x8                // =8
    3554:      	add	x2, x8, #0xe8
    3558:      	mov	w8, #0x8                // =8
    355c:      	blr	x9
    3560:      	ldr	x8, [sp, #0xa8]
    3564:      	str	x8, [x23]
    3568:      	mov	w8, #0x7d               // =125
    356c:      	blr	x8
    3570:      	str	x0, [x20, #0x18]
    3574:      	ldr	x10, [sp, #0x58]
    3578:      	mov	x24, xzr
    357c:      	add	x29, x20, #0x20
    3580:      	mov	w21, #0xa               // =10
    3584:      	ldp	x8, x9, [x23]
    3588:      	stur	x8, [x10, #0x14]
    358c:      	stur	x9, [x10, #0x1c]
    3590:      	subs	x8, x22, x24
    3594:      	b.mi	0x3a9c <generic_kprobe_process_event+0x373c>
    3598:      	mov	w9, #0x7fe0             // =32736
    359c:      	add	x2, x24, x25
    35a0:      	mov	x0, x29
    35a4:      	cmp	x8, x9
    35a8:      	csel	x23, x8, x9, lo
    35ac:      	mov	w8, #0x4                // =4
    35b0:      	mov	w1, w23
    35b4:      	blr	x8
    35b8:      	tbnz	w0, #0x1f, 0x3638 <generic_kprobe_process_event+0x32d8>
    35bc:      	add	w8, w23, #0x20
    35c0:      	str	wzr, [sp, #0xa8]
    35c4:      	adrp	x0, 0x3000 <generic_kprobe_process_event+0x2ca0>
    35c8:      	add	x9, sp, #0xa8
    35cc:      	str	w8, [x20, #0x4]
    35d0:      	mov	x19, x8
    35d4:      	mov	w8, #0x1                // =1
    35d8:      	add	x1, sp, #0xa8
    35dc:      	ldr	x0, [x0]
    35e0:      	blr	x8
    35e4:      	cbz	x0, 0x3618 <generic_kprobe_process_event+0x32b8>
    35e8:      	ldrb	w8, [x0, #0x28]
    35ec:      	cbz	w8, 0x3618 <generic_kprobe_process_event+0x32b8>
    35f0:      	adrp	x1, 0x3000 <generic_kprobe_process_event+0x2ca0>
    35f4:      	ldr	x0, [sp, #0x10]
    35f8:      	mov	w8, #0x19               // =25
    35fc:      	mov	w9, #-0x1               // =-1
    3600:      	ldr	x1, [x1]
    3604:      	mov	w2, #-0x1               // =-1
    3608:      	mov	x3, x20
    360c:      	mov	x4, x19
    3610:      	blr	x8
    3614:      	b	0x3634 <generic_kprobe_process_event+0x32d4>
    3618:      	adrp	x0, 0x3000 <generic_kprobe_process_event+0x2ca0>
    361c:      	mov	x3, xzr
    3620:      	mov	w8, #0x82               // =130
    3624:      	ldr	x0, [x0]
    3628:      	mov	x1, x20
    362c:      	mov	x2, x19
    3630:      	blr	x8
    3634:      	tbz	w0, #0x1f, 0x363c <generic_kprobe_process_event+0x32dc>
    3638:      	sxtw	x23, w0
    363c:      	tbnz	w23, #0x1f, 0x3aa4 <generic_kprobe_process_event+0x3744>
    3640:      	and	x8, x23, #0x7fffffff
    3644:      	add	x24, x8, x24
    3648:      	cmp	x24, x22
    364c:      	b.eq	0x3af0 <generic_kprobe_process_event+0x3790>
    3650:      	subs	w21, w21, #0x1
    3654:      	b.ne	0x3590 <generic_kprobe_process_event+0x3230>
    3658:      	b	0x3e40 <generic_kprobe_process_event+0x3ae0>
    365c:      	ldr	x8, [sp, #0x58]
    3660:      	mov	w24, #0xc               // =12
    3664:      	str	wzr, [x8]
    3668:      	ldr	x8, [sp, #0x118]
    366c:      	add	x8, x21, x8
    3670:      	add	x8, x8, #0x8
    3674:      	str	x8, [sp, #0x58]
    3678:      	cmp	x22, #0xfff
    367c:      	mov	w8, #0xfff              // =4095
    3680:      	mov	x2, x25
    3684:      	csel	x23, x22, x8, lo
    3688:      	ldr	x8, [sp, #0x58]
    368c:      	mov	w1, w23
    3690:      	add	x0, x8, #0x8
    3694:      	mov	w8, #0x4                // =4
    3698:      	blr	x8
    369c:      	tbnz	w0, #0x1f, 0x36b0 <generic_kprobe_process_event+0x3350>
    36a0:      	ldr	x8, [sp, #0x58]
    36a4:      	add	x21, x24, x23
    36a8:      	stp	w22, w23, [x8]
    36ac:      	b	0x391c <generic_kprobe_process_event+0x35bc>
    36b0:      	mov	w8, #-0x2               // =-2
    36b4:      	ldr	x9, [sp, #0x58]
    36b8:      	mov	w21, #0x4               // =4
    36bc:      	str	w8, [x9]
    36c0:      	b	0x391c <generic_kprobe_process_event+0x35bc>
    36c4:      	ldr	x8, [sp, #0x118]
    36c8:      	mov	w9, #0x4                // =4
    36cc:      	mov	w1, w20
    36d0:      	add	x21, x8, #0xc
    36d4:      	ldr	x8, [sp, #0xa8]
    36d8:      	add	x0, x24, x21
    36dc:      	ldr	x2, [sp, #0xa8]
    36e0:      	blr	x9
    36e4:      	tbnz	w0, #0x1f, 0x3910 <generic_kprobe_process_event+0x35b0>
    36e8:      	cmp	x23, #0x1
    36ec:      	b.eq	0x3404 <generic_kprobe_process_event+0x30a4>
    36f0:      	add	x2, x25, #0x10
    36f4:      	mov	w8, #0x10               // =16
    36f8:      	mov	w9, #0x4                // =4
    36fc:      	add	x10, sp, #0xa8
    3700:      	add	x0, sp, #0xa8
    3704:      	mov	w1, #0x10               // =16
    3708:      	blr	x9
    370c:      	tbnz	w0, #0x1f, 0x3910 <generic_kprobe_process_event+0x35b0>
    3710:      	ldr	x29, [sp, #0xb0]
    3714:      	cmp	x29, #0xffe
    3718:      	b.hi	0x331c <generic_kprobe_process_event+0x2fbc>
    371c:      	add	x21, x20, x21
    3720:      	ldr	x8, [sp, #0xa8]
    3724:      	mov	w9, #0x4                // =4
    3728:      	mov	w1, w29
    372c:      	add	x0, x24, x21
    3730:      	ldr	x2, [sp, #0xa8]
    3734:      	blr	x9
    3738:      	tbnz	w0, #0x1f, 0x3910 <generic_kprobe_process_event+0x35b0>
    373c:      	add	x20, x29, x20
    3740:      	cmp	x23, #0x3
    3744:      	b.lo	0x3404 <generic_kprobe_process_event+0x30a4>
    3748:      	add	x2, x25, #0x20
    374c:      	mov	w8, #0x10               // =16
    3750:      	mov	w9, #0x4                // =4
    3754:      	add	x10, sp, #0xa8
    3758:      	add	x0, sp, #0xa8
    375c:      	mov	w1, #0x10               // =16
    3760:      	blr	x9
    3764:      	tbnz	w0, #0x1f, 0x3910 <generic_kprobe_process_event+0x35b0>
    3768:      	ldr	x22, [sp, #0xb0]
    376c:      	cmp	x22, #0xffe
    3770:      	b.hi	0x331c <generic_kprobe_process_event+0x2fbc>
    3774:      	add	x21, x29, x21
    3778:      	mov	w9, #0x4                // =4
    377c:      	mov	w1, w22
    3780:      	and	x8, x21, #0x3fff
    3784:      	add	x0, x24, x8
    3788:      	ldr	x8, [sp, #0xa8]
    378c:      	ldr	x2, [sp, #0xa8]
    3790:      	blr	x9
    3794:      	tbnz	w0, #0x1f, 0x3910 <generic_kprobe_process_event+0x35b0>
    3798:      	add	x20, x22, x20
    379c:      	cmp	x23, #0x3
    37a0:      	b.eq	0x3404 <generic_kprobe_process_event+0x30a4>
    37a4:      	add	x2, x25, #0x30
    37a8:      	mov	w8, #0x10               // =16
    37ac:      	mov	w9, #0x4                // =4
    37b0:      	add	x10, sp, #0xa8
    37b4:      	add	x0, sp, #0xa8
    37b8:      	mov	w1, #0x10               // =16
    37bc:      	blr	x9
    37c0:      	tbnz	w0, #0x1f, 0x3910 <generic_kprobe_process_event+0x35b0>
    37c4:      	ldr	x29, [sp, #0xb0]
    37c8:      	cmp	x29, #0xffe
    37cc:      	b.hi	0x331c <generic_kprobe_process_event+0x2fbc>
    37d0:      	add	x21, x22, x21
    37d4:      	mov	w9, #0x4                // =4
    37d8:      	mov	w1, w29
    37dc:      	and	x8, x21, #0x3fff
    37e0:      	add	x0, x24, x8
    37e4:      	ldr	x8, [sp, #0xa8]
    37e8:      	ldr	x2, [sp, #0xa8]
    37ec:      	blr	x9
    37f0:      	tbnz	w0, #0x1f, 0x3910 <generic_kprobe_process_event+0x35b0>
    37f4:      	add	x20, x29, x20
    37f8:      	cmp	x23, #0x5
    37fc:      	b.lo	0x3404 <generic_kprobe_process_event+0x30a4>
    3800:      	add	x2, x25, #0x40
    3804:      	mov	w8, #0x10               // =16
    3808:      	mov	w9, #0x4                // =4
    380c:      	add	x10, sp, #0xa8
    3810:      	add	x0, sp, #0xa8
    3814:      	mov	w1, #0x10               // =16
    3818:      	blr	x9
    381c:      	tbnz	w0, #0x1f, 0x3910 <generic_kprobe_process_event+0x35b0>
    3820:      	ldr	x22, [sp, #0xb0]
    3824:      	cmp	x22, #0xffe
    3828:      	b.hi	0x331c <generic_kprobe_process_event+0x2fbc>
    382c:      	add	x21, x29, x21
    3830:      	mov	w9, #0x4                // =4
    3834:      	mov	w1, w22
    3838:      	and	x8, x21, #0x3fff
    383c:      	add	x0, x24, x8
    3840:      	ldr	x8, [sp, #0xa8]
    3844:      	ldr	x2, [sp, #0xa8]
    3848:      	blr	x9
    384c:      	tbnz	w0, #0x1f, 0x3910 <generic_kprobe_process_event+0x35b0>
    3850:      	add	x20, x22, x20
    3854:      	cmp	x23, #0x5
    3858:      	b.eq	0x3404 <generic_kprobe_process_event+0x30a4>
    385c:      	add	x2, x25, #0x50
    3860:      	mov	w8, #0x10               // =16
    3864:      	mov	w9, #0x4                // =4
    3868:      	add	x10, sp, #0xa8
    386c:      	add	x0, sp, #0xa8
    3870:      	mov	w1, #0x10               // =16
    3874:      	blr	x9
    3878:      	tbnz	w0, #0x1f, 0x3910 <generic_kprobe_process_event+0x35b0>
    387c:      	ldr	x29, [sp, #0xb0]
    3880:      	cmp	x29, #0xffe
    3884:      	b.hi	0x331c <generic_kprobe_process_event+0x2fbc>
    3888:      	add	x21, x22, x21
    388c:      	mov	w9, #0x4                // =4
    3890:      	mov	w1, w29
    3894:      	and	x8, x21, #0x3fff
    3898:      	add	x0, x24, x8
    389c:      	ldr	x8, [sp, #0xa8]
    38a0:      	ldr	x2, [sp, #0xa8]
    38a4:      	blr	x9
    38a8:      	tbnz	w0, #0x1f, 0x3910 <generic_kprobe_process_event+0x35b0>
    38ac:      	add	x20, x29, x20
    38b0:      	cmp	x23, #0x7
    38b4:      	b.lo	0x3404 <generic_kprobe_process_event+0x30a4>
    38b8:      	add	x2, x25, #0x60
    38bc:      	mov	w8, #0x10               // =16
    38c0:      	mov	w9, #0x4                // =4
    38c4:      	add	x10, sp, #0xa8
    38c8:      	add	x0, sp, #0xa8
    38cc:      	mov	w1, #0x10               // =16
    38d0:      	blr	x9
    38d4:      	tbnz	w0, #0x1f, 0x3910 <generic_kprobe_process_event+0x35b0>
    38d8:      	ldr	x22, [sp, #0xb0]
    38dc:      	cmp	x22, #0xffe
    38e0:      	b.hi	0x331c <generic_kprobe_process_event+0x2fbc>
    38e4:      	add	x8, x29, x21
    38e8:      	mov	w9, #0x4                // =4
    38ec:      	mov	w1, w22
    38f0:      	and	x8, x8, #0x3fff
    38f4:      	add	x0, x24, x8
    38f8:      	ldr	x8, [sp, #0xa8]
    38fc:      	ldr	x2, [sp, #0xa8]
    3900:      	blr	x9
    3904:      	tbnz	w0, #0x1f, 0x3910 <generic_kprobe_process_event+0x35b0>
    3908:      	add	x20, x22, x20
    390c:      	b	0x3404 <generic_kprobe_process_event+0x30a4>
    3910:      	mov	w8, #-0x2               // =-2
    3914:      	str	w8, [x19]
    3918:      	mov	w21, #0x4               // =4
    391c:      	adrp	x24, 0x3000 <generic_kprobe_process_event+0x2ca0>
    3920:      	adrp	x22, 0x3000 <generic_kprobe_process_event+0x2ca0>
    3924:      	mov	w29, #0x5efc            // =24316
    3928:      	ldr	x24, [x24]
    392c:      	ldr	x22, [x22]
    3930:      	ldr	x19, [sp, #0x10]
    3934:      	ldr	x20, [sp, #0x40]
    3938:      	b	0x1c8c <generic_kprobe_process_event+0x192c>
    393c:      	mov	x21, #-0x1              // =-1
    3940:      	b	0x3948 <generic_kprobe_process_event+0x35e8>
    3944:      	mov	x21, x24
    3948:      	str	wzr, [sp, #0xa8]
    394c:      	adrp	x0, 0x3000 <generic_kprobe_process_event+0x2ca0>
    3950:      	mov	w8, #0x1                // =1
    3954:      	add	x9, sp, #0xa8
    3958:      	ldr	x0, [x0]
    395c:      	add	x1, sp, #0xa8
    3960:      	blr	x8
    3964:      	cbz	x0, 0x3cf4 <generic_kprobe_process_event+0x3994>
    3968:      	cmn	x21, #0xc
    396c:      	b.gt	0x3a7c <generic_kprobe_process_event+0x371c>
    3970:      	cmn	x21, #0x1c
    3974:      	b.eq	0x3cc0 <generic_kprobe_process_event+0x3960>
    3978:      	cmn	x21, #0x16
    397c:      	b.eq	0x3cd8 <generic_kprobe_process_event+0x3978>
    3980:      	cmn	x21, #0x10
    3984:      	b.ne	0x3cd0 <generic_kprobe_process_event+0x3970>
    3988:      	add	x8, x0, #0x558
    398c:      	b	0x3ce4 <generic_kprobe_process_event+0x3984>
    3990:      	ldr	x21, [sp, #0x58]
    3994:      	b	0x3cf4 <generic_kprobe_process_event+0x3994>
    3998:      	ldrb	w8, [x24, #0x7]
    399c:      	lsl	w8, w8, #2
    39a0:      	add	w8, w8, #0x8
    39a4:      	strh	w8, [x24, #0x2]
    39a8:      	ldrh	w9, [x24]
    39ac:      	ldrb	w23, [x24, #0x6]
    39b0:      	add	w8, w9, w8
    39b4:      	cmp	w23, #0x3c
    39b8:      	strh	w8, [x24]
    39bc:      	b.hi	0x3a74 <generic_kprobe_process_event+0x3714>
    39c0:      	mov	x29, #0x1               // =1
    39c4:      	mov	w9, #0x1                // =1
    39c8:      	movk	x29, #0x1800, lsl #32
    39cc:      	lsl	x9, x9, x23
    39d0:      	movk	x29, #0x1008, lsl #48
    39d4:      	tst	x9, x29
    39d8:      	b.eq	0x3a74 <generic_kprobe_process_event+0x3714>
    39dc:      	strb	w23, [x24, #0x5]
    39e0:      	add	x8, x21, w8, uxth
    39e4:      	mov	w9, #0x2                // =2
    39e8:      	mov	w10, #0x4               // =4
    39ec:      	mov	x0, x25
    39f0:      	mov	w1, #0x2                // =2
    39f4:      	ldrh	w8, [x24]
    39f8:      	add	x2, x21, x8
    39fc:      	blr	x10
    3a00:      	tbnz	x0, #0x3f, 0x4080 <generic_kprobe_process_event+0x3d20>
    3a04:      	ldrb	w8, [x24, #0x5]
    3a08:      	cmp	w8, #0x32
    3a0c:      	b.gt	0x3a2c <generic_kprobe_process_event+0x36cc>
    3a10:      	cbz	w8, 0x3a4c <generic_kprobe_process_event+0x36ec>
    3a14:      	cmp	w8, #0x2b
    3a18:      	b.eq	0x3a4c <generic_kprobe_process_event+0x36ec>
    3a1c:      	cmp	w8, #0x2c
    3a20:      	b.ne	0x3bac <generic_kprobe_process_event+0x384c>
    3a24:      	mov	w8, #0x8                // =8
    3a28:      	b	0x3b04 <generic_kprobe_process_event+0x37a4>
    3a2c:      	cmp	w8, #0x33
    3a30:      	b.eq	0x3af8 <generic_kprobe_process_event+0x3798>
    3a34:      	cmp	w8, #0x3c
    3a38:      	b.eq	0x3a4c <generic_kprobe_process_event+0x36ec>
    3a3c:      	cmp	w8, #0xff
    3a40:      	b.ne	0x3bac <generic_kprobe_process_event+0x384c>
    3a44:      	mov	w8, #0x28               // =40
    3a48:      	b	0x3b04 <generic_kprobe_process_event+0x37a4>
    3a4c:      	ldrb	w8, [x24, #0x7]
    3a50:      	lsl	w8, w8, #3
    3a54:      	b	0x3b00 <generic_kprobe_process_event+0x37a0>
    3a58:      	ldrh	w8, [x24, #0x2]
    3a5c:      	ldrh	w9, [x24]
    3a60:      	ldrb	w23, [x24, #0x6]
    3a64:      	add	w8, w9, w8
    3a68:      	cmp	w23, #0x3c
    3a6c:      	strh	w8, [x24]
    3a70:      	b.ls	0x39c0 <generic_kprobe_process_event+0x3660>
    3a74:      	strh	w8, [sp, #0xe8]
    3a78:      	b	0x4084 <generic_kprobe_process_event+0x3d24>
    3a7c:      	cmn	x21, #0xb
    3a80:      	b.eq	0x3cc8 <generic_kprobe_process_event+0x3968>
    3a84:      	cmn	x21, #0x7
    3a88:      	b.eq	0x3ce0 <generic_kprobe_process_event+0x3980>
    3a8c:      	cmn	x21, #0x2
    3a90:      	b.ne	0x3cd0 <generic_kprobe_process_event+0x3970>
    3a94:      	add	x8, x0, #0x548
    3a98:      	b	0x3ce4 <generic_kprobe_process_event+0x3984>
    3a9c:      	mov	x24, #-0x1              // =-1
    3aa0:      	b	0x3aa8 <generic_kprobe_process_event+0x3748>
    3aa4:      	mov	x24, x23
    3aa8:      	str	wzr, [sp, #0xa8]
    3aac:      	adrp	x0, 0x3000 <generic_kprobe_process_event+0x2ca0>
    3ab0:      	mov	w8, #0x1                // =1
    3ab4:      	add	x9, sp, #0xa8
    3ab8:      	ldr	x0, [x0]
    3abc:      	add	x1, sp, #0xa8
    3ac0:      	blr	x8
    3ac4:      	cbz	x0, 0x3e40 <generic_kprobe_process_event+0x3ae0>
    3ac8:      	cmn	x24, #0xc
    3acc:      	b.gt	0x3bcc <generic_kprobe_process_event+0x386c>
    3ad0:      	cmn	x24, #0x1c
    3ad4:      	b.eq	0x3e0c <generic_kprobe_process_event+0x3aac>
    3ad8:      	cmn	x24, #0x16
    3adc:      	b.eq	0x3e24 <generic_kprobe_process_event+0x3ac4>
    3ae0:      	cmn	x24, #0x10
    3ae4:      	b.ne	0x3e1c <generic_kprobe_process_event+0x3abc>
    3ae8:      	add	x8, x0, #0x558
    3aec:      	b	0x3e30 <generic_kprobe_process_event+0x3ad0>
    3af0:      	mov	x24, x22
    3af4:      	b	0x3e40 <generic_kprobe_process_event+0x3ae0>
    3af8:      	ldrb	w8, [x24, #0x7]
    3afc:      	lsl	w8, w8, #2
    3b00:      	add	w8, w8, #0x8
    3b04:      	strh	w8, [x24, #0x2]
    3b08:      	ldrh	w9, [x24]
    3b0c:      	ldrb	w23, [x24, #0x6]
    3b10:      	add	w8, w9, w8
    3b14:      	cmp	w23, #0x3c
    3b18:      	strh	w8, [x24]
    3b1c:      	b.hi	0x4248 <generic_kprobe_process_event+0x3ee8>
    3b20:      	mov	w9, #0x1                // =1
    3b24:      	lsl	x9, x9, x23
    3b28:      	tst	x9, x29
    3b2c:      	b.eq	0x4248 <generic_kprobe_process_event+0x3ee8>
    3b30:      	strb	w23, [x24, #0x5]
    3b34:      	add	x8, x21, w8, uxth
    3b38:      	mov	w9, #0x2                // =2
    3b3c:      	mov	w10, #0x4               // =4
    3b40:      	mov	x0, x25
    3b44:      	mov	w1, #0x2                // =2
    3b48:      	ldrh	w8, [x24]
    3b4c:      	add	x2, x21, x8
    3b50:      	blr	x10
    3b54:      	tbnz	x0, #0x3f, 0x4080 <generic_kprobe_process_event+0x3d20>
    3b58:      	ldrb	w8, [x24, #0x5]
    3b5c:      	cmp	w8, #0x32
    3b60:      	b.gt	0x3b80 <generic_kprobe_process_event+0x3820>
    3b64:      	cbz	w8, 0x3ba0 <generic_kprobe_process_event+0x3840>
    3b68:      	cmp	w8, #0x2b
    3b6c:      	b.eq	0x3ba0 <generic_kprobe_process_event+0x3840>
    3b70:      	cmp	w8, #0x2c
    3b74:      	b.ne	0x3ca0 <generic_kprobe_process_event+0x3940>
    3b78:      	mov	w8, #0x8                // =8
    3b7c:      	b	0x3bf8 <generic_kprobe_process_event+0x3898>
    3b80:      	cmp	w8, #0x33
    3b84:      	b.eq	0x3bec <generic_kprobe_process_event+0x388c>
    3b88:      	cmp	w8, #0x3c
    3b8c:      	b.eq	0x3ba0 <generic_kprobe_process_event+0x3840>
    3b90:      	cmp	w8, #0xff
    3b94:      	b.ne	0x3ca0 <generic_kprobe_process_event+0x3940>
    3b98:      	mov	w8, #0x28               // =40
    3b9c:      	b	0x3bf8 <generic_kprobe_process_event+0x3898>
    3ba0:      	ldrb	w8, [x24, #0x7]
    3ba4:      	lsl	w8, w8, #3
    3ba8:      	b	0x3bf4 <generic_kprobe_process_event+0x3894>
    3bac:      	ldrh	w8, [x24, #0x2]
    3bb0:      	ldrh	w9, [x24]
    3bb4:      	ldrb	w23, [x24, #0x6]
    3bb8:      	add	w8, w9, w8
    3bbc:      	cmp	w23, #0x3c
    3bc0:      	strh	w8, [x24]
    3bc4:      	b.ls	0x3b20 <generic_kprobe_process_event+0x37c0>
    3bc8:      	b	0x4248 <generic_kprobe_process_event+0x3ee8>
    3bcc:      	cmn	x24, #0xb
    3bd0:      	b.eq	0x3e14 <generic_kprobe_process_event+0x3ab4>
    3bd4:      	cmn	x24, #0x7
    3bd8:      	b.eq	0x3e2c <generic_kprobe_process_event+0x3acc>
    3bdc:      	cmn	x24, #0x2
    3be0:      	b.ne	0x3e1c <generic_kprobe_process_event+0x3abc>
    3be4:      	add	x8, x0, #0x548
    3be8:      	b	0x3e30 <generic_kprobe_process_event+0x3ad0>
    3bec:      	ldrb	w8, [x24, #0x7]
    3bf0:      	lsl	w8, w8, #2
    3bf4:      	add	w8, w8, #0x8
    3bf8:      	strh	w8, [x24, #0x2]
    3bfc:      	ldrh	w9, [x24]
    3c00:      	ldrb	w23, [x24, #0x6]
    3c04:      	add	w8, w9, w8
    3c08:      	cmp	w23, #0x3c
    3c0c:      	strh	w8, [x24]
    3c10:      	b.hi	0x4248 <generic_kprobe_process_event+0x3ee8>
    3c14:      	mov	w9, #0x1                // =1
    3c18:      	lsl	x9, x9, x23
    3c1c:      	tst	x9, x29
    3c20:      	b.eq	0x4248 <generic_kprobe_process_event+0x3ee8>
    3c24:      	strb	w23, [x24, #0x5]
    3c28:      	add	x8, x21, w8, uxth
    3c2c:      	mov	w9, #0x2                // =2
    3c30:      	mov	w10, #0x4               // =4
    3c34:      	mov	x0, x25
    3c38:      	mov	w1, #0x2                // =2
    3c3c:      	ldrh	w8, [x24]
    3c40:      	add	x2, x21, x8
    3c44:      	blr	x10
    3c48:      	tbnz	x0, #0x3f, 0x4080 <generic_kprobe_process_event+0x3d20>
    3c4c:      	ldrb	w8, [x24, #0x5]
    3c50:      	cmp	w8, #0x32
    3c54:      	b.gt	0x3c74 <generic_kprobe_process_event+0x3914>
    3c58:      	cbz	w8, 0x3c94 <generic_kprobe_process_event+0x3934>
    3c5c:      	cmp	w8, #0x2b
    3c60:      	b.eq	0x3c94 <generic_kprobe_process_event+0x3934>
    3c64:      	cmp	w8, #0x2c
    3c68:      	b.ne	0x3dec <generic_kprobe_process_event+0x3a8c>
    3c6c:      	mov	w8, #0x8                // =8
    3c70:      	b	0x3d44 <generic_kprobe_process_event+0x39e4>
    3c74:      	cmp	w8, #0x33
    3c78:      	b.eq	0x3d38 <generic_kprobe_process_event+0x39d8>
    3c7c:      	cmp	w8, #0x3c
    3c80:      	b.eq	0x3c94 <generic_kprobe_process_event+0x3934>
    3c84:      	cmp	w8, #0xff
    3c88:      	b.ne	0x3dec <generic_kprobe_process_event+0x3a8c>
    3c8c:      	mov	w8, #0x28               // =40
    3c90:      	b	0x3d44 <generic_kprobe_process_event+0x39e4>
    3c94:      	ldrb	w8, [x24, #0x7]
    3c98:      	lsl	w8, w8, #3
    3c9c:      	b	0x3d40 <generic_kprobe_process_event+0x39e0>
    3ca0:      	ldrh	w8, [x24, #0x2]
    3ca4:      	ldrh	w9, [x24]
    3ca8:      	ldrb	w23, [x24, #0x6]
    3cac:      	add	w8, w9, w8
    3cb0:      	cmp	w23, #0x3c
    3cb4:      	strh	w8, [x24]
    3cb8:      	b.ls	0x3c14 <generic_kprobe_process_event+0x38b4>
    3cbc:      	b	0x4248 <generic_kprobe_process_event+0x3ee8>
    3cc0:      	add	x8, x0, #0x568
    3cc4:      	b	0x3ce4 <generic_kprobe_process_event+0x3984>
    3cc8:      	add	x8, x0, #0x570
    3ccc:      	b	0x3ce4 <generic_kprobe_process_event+0x3984>
    3cd0:      	add	x8, x0, #0x540
    3cd4:      	b	0x3ce4 <generic_kprobe_process_event+0x3984>
    3cd8:      	add	x8, x0, #0x560
    3cdc:      	b	0x3ce4 <generic_kprobe_process_event+0x3984>
    3ce0:      	add	x8, x0, #0x550
    3ce4:      	ldaxr	x9, [x8]
    3ce8:      	add	x9, x9, #0x1
    3cec:      	stlxr	w10, x9, [x8]
    3cf0:      	cbnz	w10, 0x3ce4 <generic_kprobe_process_event+0x3984>
    3cf4:      	tbnz	w21, #0x1f, 0x3d10 <generic_kprobe_process_event+0x39b0>
    3cf8:      	ldp	x8, x29, [sp, #0x50]
    3cfc:      	cmn	x29, #0x1
    3d00:      	stur	xzr, [x8, #0x4]
    3d04:      	sub	w8, w29, w21
    3d08:      	csel	w8, wzr, w8, eq
    3d0c:      	b	0x3d20 <generic_kprobe_process_event+0x39c0>
    3d10:      	ldr	x9, [sp, #0x50]
    3d14:      	mov	w8, wzr
    3d18:      	stp	w21, wzr, [x9, #0x4]
    3d1c:      	mov	w21, wzr
    3d20:      	ldr	x9, [sp, #0x50]
    3d24:      	stp	w8, w21, [x9, #0xc]
    3d28:      	mov	w21, #0x24              // =36
    3d2c:      	mov	x24, x25
    3d30:      	mov	w29, #0x5efc            // =24316
    3d34:      	b	0x1c8c <generic_kprobe_process_event+0x192c>
    3d38:      	ldrb	w8, [x24, #0x7]
    3d3c:      	lsl	w8, w8, #2
    3d40:      	add	w8, w8, #0x8
    3d44:      	strh	w8, [x24, #0x2]
    3d48:      	ldrh	w9, [x24]
    3d4c:      	ldrb	w23, [x24, #0x6]
    3d50:      	add	w8, w9, w8
    3d54:      	cmp	w23, #0x3c
    3d58:      	strh	w8, [x24]
    3d5c:      	b.hi	0x4248 <generic_kprobe_process_event+0x3ee8>
    3d60:      	mov	w9, #0x1                // =1
    3d64:      	lsl	x9, x9, x23
    3d68:      	tst	x9, x29
    3d6c:      	b.eq	0x4248 <generic_kprobe_process_event+0x3ee8>
    3d70:      	strb	w23, [x24, #0x5]
    3d74:      	add	x8, x21, w8, uxth
    3d78:      	mov	w9, #0x2                // =2
    3d7c:      	mov	w10, #0x4               // =4
    3d80:      	mov	x0, x25
    3d84:      	mov	w1, #0x2                // =2
    3d88:      	ldrh	w8, [x24]
    3d8c:      	add	x2, x21, x8
    3d90:      	blr	x10
    3d94:      	tbnz	x0, #0x3f, 0x4080 <generic_kprobe_process_event+0x3d20>
    3d98:      	ldrb	w8, [x24, #0x5]
    3d9c:      	cmp	w8, #0x32
    3da0:      	b.gt	0x3dc0 <generic_kprobe_process_event+0x3a60>
    3da4:      	cbz	w8, 0x3de0 <generic_kprobe_process_event+0x3a80>
    3da8:      	cmp	w8, #0x2b
    3dac:      	b.eq	0x3de0 <generic_kprobe_process_event+0x3a80>
    3db0:      	cmp	w8, #0x2c
    3db4:      	b.ne	0x3f30 <generic_kprobe_process_event+0x3bd0>
    3db8:      	mov	w8, #0x8                // =8
    3dbc:      	b	0x3e88 <generic_kprobe_process_event+0x3b28>
    3dc0:      	cmp	w8, #0x33
    3dc4:      	b.eq	0x3e7c <generic_kprobe_process_event+0x3b1c>
    3dc8:      	cmp	w8, #0x3c
    3dcc:      	b.eq	0x3de0 <generic_kprobe_process_event+0x3a80>
    3dd0:      	cmp	w8, #0xff
    3dd4:      	b.ne	0x3f30 <generic_kprobe_process_event+0x3bd0>
    3dd8:      	mov	w8, #0x28               // =40
    3ddc:      	b	0x3e88 <generic_kprobe_process_event+0x3b28>
    3de0:      	ldrb	w8, [x24, #0x7]
    3de4:      	lsl	w8, w8, #3
    3de8:      	b	0x3e84 <generic_kprobe_process_event+0x3b24>
    3dec:      	ldrh	w8, [x24, #0x2]
    3df0:      	ldrh	w9, [x24]
    3df4:      	ldrb	w23, [x24, #0x6]
    3df8:      	add	w8, w9, w8
    3dfc:      	cmp	w23, #0x3c
    3e00:      	strh	w8, [x24]
    3e04:      	b.ls	0x3d60 <generic_kprobe_process_event+0x3a00>
    3e08:      	b	0x4248 <generic_kprobe_process_event+0x3ee8>
    3e0c:      	add	x8, x0, #0x568
    3e10:      	b	0x3e30 <generic_kprobe_process_event+0x3ad0>
    3e14:      	add	x8, x0, #0x570
    3e18:      	b	0x3e30 <generic_kprobe_process_event+0x3ad0>
    3e1c:      	add	x8, x0, #0x540
    3e20:      	b	0x3e30 <generic_kprobe_process_event+0x3ad0>
    3e24:      	add	x8, x0, #0x560
    3e28:      	b	0x3e30 <generic_kprobe_process_event+0x3ad0>
    3e2c:      	add	x8, x0, #0x550
    3e30:      	ldaxr	x9, [x8]
    3e34:      	add	x9, x9, #0x1
    3e38:      	stlxr	w10, x9, [x8]
    3e3c:      	cbnz	w10, 0x3e30 <generic_kprobe_process_event+0x3ad0>
    3e40:      	tbnz	w24, #0x1f, 0x3e5c <generic_kprobe_process_event+0x3afc>
    3e44:      	ldr	x8, [sp, #0x58]
    3e48:      	cmn	x22, #0x1
    3e4c:      	stur	xzr, [x8, #0x4]
    3e50:      	sub	w8, w22, w24
    3e54:      	csel	w8, wzr, w8, eq
    3e58:      	b	0x3e6c <generic_kprobe_process_event+0x3b0c>
    3e5c:      	ldr	x9, [sp, #0x58]
    3e60:      	mov	w8, wzr
    3e64:      	stp	w24, wzr, [x9, #0x4]
    3e68:      	mov	w24, wzr
    3e6c:      	ldr	x9, [sp, #0x58]
    3e70:      	mov	w21, #0x24              // =36
    3e74:      	stp	w8, w24, [x9, #0xc]
    3e78:      	b	0x391c <generic_kprobe_process_event+0x35bc>
    3e7c:      	ldrb	w8, [x24, #0x7]
    3e80:      	lsl	w8, w8, #2
    3e84:      	add	w8, w8, #0x8
    3e88:      	strh	w8, [x24, #0x2]
    3e8c:      	ldrh	w9, [x24]
    3e90:      	ldrb	w23, [x24, #0x6]
    3e94:      	add	w8, w9, w8
    3e98:      	cmp	w23, #0x3c
    3e9c:      	strh	w8, [x24]
    3ea0:      	b.hi	0x4248 <generic_kprobe_process_event+0x3ee8>
    3ea4:      	mov	w9, #0x1                // =1
    3ea8:      	lsl	x9, x9, x23
    3eac:      	tst	x9, x29
    3eb0:      	b.eq	0x4248 <generic_kprobe_process_event+0x3ee8>
    3eb4:      	strb	w23, [x24, #0x5]
    3eb8:      	add	x8, x21, w8, uxth
    3ebc:      	mov	w9, #0x2                // =2
    3ec0:      	mov	w10, #0x4               // =4
    3ec4:      	mov	x0, x25
    3ec8:      	mov	w1, #0x2                // =2
    3ecc:      	ldrh	w8, [x24]
    3ed0:      	add	x2, x21, x8
    3ed4:      	blr	x10
    3ed8:      	tbnz	x0, #0x3f, 0x4080 <generic_kprobe_process_event+0x3d20>
    3edc:      	ldrb	w8, [x24, #0x5]
    3ee0:      	cmp	w8, #0x32
    3ee4:      	b.gt	0x3f04 <generic_kprobe_process_event+0x3ba4>
    3ee8:      	cbz	w8, 0x3f24 <generic_kprobe_process_event+0x3bc4>
    3eec:      	cmp	w8, #0x2b
    3ef0:      	b.eq	0x3f24 <generic_kprobe_process_event+0x3bc4>
    3ef4:      	cmp	w8, #0x2c
    3ef8:      	b.ne	0x4004 <generic_kprobe_process_event+0x3ca4>
    3efc:      	mov	w8, #0x8                // =8
    3f00:      	b	0x3f5c <generic_kprobe_process_event+0x3bfc>
    3f04:      	cmp	w8, #0x33
    3f08:      	b.eq	0x3f50 <generic_kprobe_process_event+0x3bf0>
    3f0c:      	cmp	w8, #0x3c
    3f10:      	b.eq	0x3f24 <generic_kprobe_process_event+0x3bc4>
    3f14:      	cmp	w8, #0xff
    3f18:      	b.ne	0x4004 <generic_kprobe_process_event+0x3ca4>
    3f1c:      	mov	w8, #0x28               // =40
    3f20:      	b	0x3f5c <generic_kprobe_process_event+0x3bfc>
    3f24:      	ldrb	w8, [x24, #0x7]
    3f28:      	lsl	w8, w8, #3
    3f2c:      	b	0x3f58 <generic_kprobe_process_event+0x3bf8>
    3f30:      	ldrh	w8, [x24, #0x2]
    3f34:      	ldrh	w9, [x24]
    3f38:      	ldrb	w23, [x24, #0x6]
    3f3c:      	add	w8, w9, w8
    3f40:      	cmp	w23, #0x3c
    3f44:      	strh	w8, [x24]
    3f48:      	b.ls	0x3ea4 <generic_kprobe_process_event+0x3b44>
    3f4c:      	b	0x4248 <generic_kprobe_process_event+0x3ee8>
    3f50:      	ldrb	w8, [x24, #0x7]
    3f54:      	lsl	w8, w8, #2
    3f58:      	add	w8, w8, #0x8
    3f5c:      	strh	w8, [x24, #0x2]
    3f60:      	ldrh	w9, [x24]
    3f64:      	ldrb	w23, [x24, #0x6]
    3f68:      	add	w8, w9, w8
    3f6c:      	cmp	w23, #0x3c
    3f70:      	strh	w8, [x24]
    3f74:      	b.hi	0x4248 <generic_kprobe_process_event+0x3ee8>
    3f78:      	mov	w9, #0x1                // =1
    3f7c:      	lsl	x9, x9, x23
    3f80:      	tst	x9, x29
    3f84:      	b.eq	0x4248 <generic_kprobe_process_event+0x3ee8>
    3f88:      	strb	w23, [x24, #0x5]
    3f8c:      	add	x8, x21, w8, uxth
    3f90:      	mov	w9, #0x2                // =2
    3f94:      	mov	w10, #0x4               // =4
    3f98:      	mov	x0, x25
    3f9c:      	mov	w1, #0x2                // =2
    3fa0:      	ldrh	w8, [x24]
    3fa4:      	add	x2, x21, x8
    3fa8:      	blr	x10
    3fac:      	tbnz	x0, #0x3f, 0x4080 <generic_kprobe_process_event+0x3d20>
    3fb0:      	ldrb	w8, [x24, #0x5]
    3fb4:      	cmp	w8, #0x32
    3fb8:      	b.gt	0x3fd8 <generic_kprobe_process_event+0x3c78>
    3fbc:      	cbz	w8, 0x3ff8 <generic_kprobe_process_event+0x3c98>
    3fc0:      	cmp	w8, #0x2b
    3fc4:      	b.eq	0x3ff8 <generic_kprobe_process_event+0x3c98>
    3fc8:      	cmp	w8, #0x2c
    3fcc:      	b.ne	0x422c <generic_kprobe_process_event+0x3ecc>
    3fd0:      	mov	w8, #0x8                // =8
    3fd4:      	b	0x4030 <generic_kprobe_process_event+0x3cd0>
    3fd8:      	cmp	w8, #0x33
    3fdc:      	b.eq	0x4024 <generic_kprobe_process_event+0x3cc4>
    3fe0:      	cmp	w8, #0x3c
    3fe4:      	b.eq	0x3ff8 <generic_kprobe_process_event+0x3c98>
    3fe8:      	cmp	w8, #0xff
    3fec:      	b.ne	0x422c <generic_kprobe_process_event+0x3ecc>
    3ff0:      	mov	w8, #0x28               // =40
    3ff4:      	b	0x4030 <generic_kprobe_process_event+0x3cd0>
    3ff8:      	ldrb	w8, [x24, #0x7]
    3ffc:      	lsl	w8, w8, #3
    4000:      	b	0x402c <generic_kprobe_process_event+0x3ccc>
    4004:      	ldrh	w8, [x24, #0x2]
    4008:      	ldrh	w9, [x24]
    400c:      	ldrb	w23, [x24, #0x6]
    4010:      	add	w8, w9, w8
    4014:      	cmp	w23, #0x3c
    4018:      	strh	w8, [x24]
    401c:      	b.ls	0x3f78 <generic_kprobe_process_event+0x3c18>
    4020:      	b	0x4248 <generic_kprobe_process_event+0x3ee8>
    4024:      	ldrb	w8, [x24, #0x7]
    4028:      	lsl	w8, w8, #2
    402c:      	add	w8, w8, #0x8
    4030:      	strh	w8, [x24, #0x2]
    4034:      	ldrh	w9, [x24]
    4038:      	ldrb	w23, [x24, #0x6]
    403c:      	add	w8, w9, w8
    4040:      	cmp	w23, #0x3c
    4044:      	strh	w8, [x24]
    4048:      	b.hi	0x4248 <generic_kprobe_process_event+0x3ee8>
    404c:      	mov	w9, #0x1                // =1
    4050:      	lsl	x9, x9, x23
    4054:      	tst	x9, x29
    4058:      	b.eq	0x4248 <generic_kprobe_process_event+0x3ee8>
    405c:      	strb	w23, [x24, #0x5]
    4060:      	add	x8, x21, w8, uxth
    4064:      	mov	w9, #0x2                // =2
    4068:      	mov	w10, #0x4               // =4
    406c:      	mov	x0, x25
    4070:      	mov	w1, #0x2                // =2
    4074:      	ldrh	w8, [x24]
    4078:      	add	x2, x21, x8
    407c:      	blr	x10
    4080:      	mov	w23, wzr
    4084:      	ldr	x25, [sp, #0x18]
    4088:      	mov	w8, #0xa                // =10
    408c:      	strb	w23, [sp, #0x98]
    4090:      	add	x2, x22, #0x8
    4094:      	mov	w21, #0x10              // =16
    4098:      	mov	w1, #0x10               // =16
    409c:      	mov	w24, #0x4               // =4
    40a0:      	strh	w23, [x25, #0x24]
    40a4:      	strh	w8, [x25, #0x26]
    40a8:      	mov	w8, #0x4                // =4
    40ac:      	mov	x0, x25
    40b0:      	blr	x8
    40b4:      	add	x0, x25, #0x10
    40b8:      	add	x2, x22, #0x18
    40bc:      	mov	w1, #0x10               // =16
    40c0:      	blr	x24
    40c4:      	cmp	w23, #0x11
    40c8:      	b.eq	0x410c <generic_kprobe_process_event+0x3dac>
    40cc:      	cmp	w23, #0x6
    40d0:      	b.ne	0x414c <generic_kprobe_process_event+0x3dec>
    40d4:      	ldr	x8, [sp, #0xa8]
    40d8:      	ldrh	w9, [sp, #0xe8]
    40dc:      	mov	w21, #0x2               // =2
    40e0:      	mov	w1, #0x2                // =2
    40e4:      	mov	w24, #0x4               // =4
    40e8:      	add	x23, x8, x9
    40ec:      	ldr	x25, [sp, #0x18]
    40f0:      	add	x0, x25, #0x20
    40f4:      	mov	w8, #0x4                // =4
    40f8:      	mov	x2, x23
    40fc:      	blr	x8
    4100:      	add	x0, x25, #0x22
    4104:      	add	x2, x23, #0x2
    4108:      	b	0x4140 <generic_kprobe_process_event+0x3de0>
    410c:      	ldr	x8, [sp, #0xa8]
    4110:      	ldrh	w9, [sp, #0xe8]
    4114:      	mov	w21, #0x2               // =2
    4118:      	mov	w1, #0x2                // =2
    411c:      	mov	w24, #0x4               // =4
    4120:      	add	x23, x8, x9
    4124:      	ldr	x25, [sp, #0x18]
    4128:      	add	x0, x25, #0x20
    412c:      	mov	w8, #0x4                // =4
    4130:      	mov	x2, x23
    4134:      	blr	x8
    4138:      	add	x0, x25, #0x22
    413c:      	add	x2, x23, #0x2
    4140:      	mov	w1, #0x2                // =2
    4144:      	blr	x24
    4148:      	b	0x4154 <generic_kprobe_process_event+0x3df4>
    414c:      	ldr	x8, [sp, #0x18]
    4150:      	str	wzr, [x8, #0x20]
    4154:      	ldr	x9, [sp, #0x18]
    4158:      	add	x2, x19, #0xe0
    415c:      	add	x10, sp, #0x100
    4160:      	add	x0, sp, #0x100
    4164:      	ldrh	w8, [x9, #0x20]
    4168:      	mov	w1, #0x8                // =8
    416c:      	rev	w8, w8
    4170:      	lsr	w8, w8, #16
    4174:      	strh	w8, [x9, #0x20]
    4178:      	ldrh	w8, [x9, #0x22]
    417c:      	rev	w8, w8
    4180:      	lsr	w8, w8, #16
    4184:      	strh	w8, [x9, #0x22]
    4188:      	mov	w8, #0x8                // =8
    418c:      	mov	w9, #0x4                // =4
    4190:      	blr	x9
    4194:      	add	x8, sp, #0xf0
    4198:      	ldr	x8, [x8, #0x10]
    419c:      	cbz	x8, 0x4200 <generic_kprobe_process_event+0x3ea0>
    41a0:      	add	x8, x8, #0x5
    41a4:      	mov	w9, #0x8                // =8
    41a8:      	add	x10, sp, #0x80
    41ac:      	mov	w11, #0x4               // =4
    41b0:      	add	x23, sp, #0xf0
    41b4:      	ldr	x8, [x23, #0x10]
    41b8:      	add	x0, sp, #0x80
    41bc:      	mov	w1, #0x8                // =8
    41c0:      	mov	w21, #0x4               // =4
    41c4:      	add	x2, x8, #0x5
    41c8:      	blr	x11
    41cc:      	ldr	x8, [x23, #0x10]
    41d0:      	ldr	x9, [sp, #0x80]
    41d4:      	mov	w1, #0x4                // =4
    41d8:      	add	x23, x8, x9, lsl #3
    41dc:      	ldr	x24, [sp, #0x18]
    41e0:      	add	x0, x24, #0x38
    41e4:      	mov	w8, #0x4                // =4
    41e8:      	add	x2, x23, #0x44
    41ec:      	blr	x8
    41f0:      	add	x0, x24, #0x3c
    41f4:      	add	x2, x23, #0x45
    41f8:      	mov	w1, #0x4                // =4
    41fc:      	blr	x21
    4200:      	adrp	x24, 0x4000 <generic_kprobe_process_event+0x3ca0>
    4204:      	mov	w21, #0x40              // =64
    4208:      	ldr	x24, [x24]
    420c:      	adrp	x22, 0x4000 <generic_kprobe_process_event+0x3ca0>
    4210:      	ldp	x11, x9, [sp, #0x20]
    4214:      	mov	w29, #0x5efc            // =24316
    4218:      	mov	w10, #0x5ea0            // =24224
    421c:      	ldr	x22, [x22]
    4220:      	ldr	x19, [sp, #0x10]
    4224:      	ldr	x20, [sp, #0x40]
    4228:      	b	0x1c94 <generic_kprobe_process_event+0x1934>
    422c:      	ldrh	w8, [x24, #0x2]
    4230:      	ldrh	w9, [x24]
    4234:      	ldrb	w23, [x24, #0x6]
    4238:      	add	w8, w9, w8
    423c:      	cmp	w23, #0x3c
    4240:      	strh	w8, [x24]
    4244:      	b.ls	0x404c <generic_kprobe_process_event+0x3cec>
    4248:      	strh	w8, [sp, #0xe8]
    424c:      	b	0x4084 <generic_kprobe_process_event+0x3d24>

0000000000004250 <generic_kprobe_process_filter>:
    4250:      	sub	sp, sp, #0x130
    4254:      	str	x29, [sp, #0xe0]
    4258:      	stp	x30, x25, [sp, #0xf0]
    425c:      	stp	x24, x23, [sp, #0x100]
    4260:      	stp	x22, x21, [sp, #0x110]
    4264:      	stp	x20, x19, [sp, #0x120]
    4268:      	mov	x20, x0
    426c:      	str	wzr, [sp, #0x54]
    4270:      	adrp	x0, 0x4000 <generic_kprobe_process_event+0x3ca0>
    4274:      	mov	w8, #0x1                // =1
    4278:      	ldr	x0, [x0]
    427c:      	add	x9, sp, #0x54
    4280:      	add	x1, sp, #0x54
    4284:      	blr	x8
    4288:      	cbz	x0, 0x658c <generic_kprobe_process_filter+0x233c>
    428c:      	mov	w8, #0x5ec0             // =24256
    4290:      	mov	x22, x0
    4294:      	add	x29, x0, x8
    4298:      	mov	w8, #0x23               // =35
    429c:      	blr	x8
    42a0:      	str	x0, [sp, #0x58]
    42a4:      	add	x8, x0, #0x8d4
    42a8:      	mov	w9, #0x4                // =4
    42ac:      	mov	w10, #0x71              // =113
    42b0:      	add	x11, sp, #0xd8
    42b4:      	add	x0, sp, #0xd8
    42b8:      	mov	w1, #0x4                // =4
    42bc:      	ldr	x8, [sp, #0x58]
    42c0:      	add	x2, x8, #0x8d4
    42c4:      	blr	x10
    42c8:      	ldr	w8, [sp, #0xd8]
    42cc:      	adrp	x19, 0x4000 <generic_kprobe_process_event+0x3ca0>
    42d0:      	add	x9, sp, #0xc8
    42d4:      	add	x1, sp, #0xc8
    42d8:      	str	w8, [sp, #0xc8]
    42dc:      	mov	w8, #0x1                // =1
    42e0:      	ldr	x19, [x19]
    42e4:      	mov	x0, x19
    42e8:      	blr	x8
    42ec:      	cbz	x0, 0x42fc <generic_kprobe_process_filter+0xac>
    42f0:      	ldr	x8, [x0, #0x8]
    42f4:      	mov	x24, x0
    42f8:      	cbnz	x8, 0x50ec <generic_kprobe_process_filter+0xe9c>
    42fc:      	ldr	x8, [sp, #0x58]
    4300:      	mov	w9, #0x8                // =8
    4304:      	mov	w10, #0x71              // =113
    4308:      	add	x11, sp, #0x58
    430c:      	add	x0, sp, #0x58
    4310:      	mov	w1, #0x8                // =8
    4314:      	add	x8, x8, #0x8e0
    4318:      	ldr	x8, [sp, #0x58]
    431c:      	add	x2, x8, #0x8e0
    4320:      	blr	x10
    4324:      	ldr	x8, [sp, #0x58]
    4328:      	cbz	x8, 0x44a4 <generic_kprobe_process_filter+0x254>
    432c:      	add	x8, x8, #0x8d4
    4330:      	mov	w9, #0x4                // =4
    4334:      	mov	w10, #0x71              // =113
    4338:      	add	x11, sp, #0xd8
    433c:      	ldr	x8, [sp, #0x58]
    4340:      	add	x0, sp, #0xd8
    4344:      	mov	w1, #0x4                // =4
    4348:      	add	x2, x8, #0x8d4
    434c:      	blr	x10
    4350:      	ldr	w8, [sp, #0xd8]
    4354:      	add	x9, sp, #0xc8
    4358:      	add	x1, sp, #0xc8
    435c:      	mov	x0, x19
    4360:      	str	w8, [sp, #0xc8]
    4364:      	mov	w8, #0x1                // =1
    4368:      	blr	x8
    436c:      	cbz	x0, 0x437c <generic_kprobe_process_filter+0x12c>
    4370:      	ldr	x8, [x0, #0x8]
    4374:      	mov	x24, x0
    4378:      	cbnz	x8, 0x50ec <generic_kprobe_process_filter+0xe9c>
    437c:      	ldr	x8, [sp, #0x58]
    4380:      	mov	w9, #0x8                // =8
    4384:      	mov	w10, #0x71              // =113
    4388:      	add	x11, sp, #0x58
    438c:      	add	x0, sp, #0x58
    4390:      	mov	w1, #0x8                // =8
    4394:      	add	x8, x8, #0x8e0
    4398:      	ldr	x8, [sp, #0x58]
    439c:      	add	x2, x8, #0x8e0
    43a0:      	blr	x10
    43a4:      	ldr	x8, [sp, #0x58]
    43a8:      	cbz	x8, 0x44a4 <generic_kprobe_process_filter+0x254>
    43ac:      	add	x8, x8, #0x8d4
    43b0:      	mov	w9, #0x4                // =4
    43b4:      	mov	w10, #0x71              // =113
    43b8:      	add	x11, sp, #0xd8
    43bc:      	ldr	x8, [sp, #0x58]
    43c0:      	add	x0, sp, #0xd8
    43c4:      	mov	w1, #0x4                // =4
    43c8:      	add	x2, x8, #0x8d4
    43cc:      	blr	x10
    43d0:      	ldr	w8, [sp, #0xd8]
    43d4:      	add	x9, sp, #0xc8
    43d8:      	add	x1, sp, #0xc8
    43dc:      	mov	x0, x19
    43e0:      	str	w8, [sp, #0xc8]
    43e4:      	mov	w8, #0x1                // =1
    43e8:      	blr	x8
    43ec:      	cbz	x0, 0x43fc <generic_kprobe_process_filter+0x1ac>
    43f0:      	ldr	x8, [x0, #0x8]
    43f4:      	mov	x24, x0
    43f8:      	cbnz	x8, 0x50ec <generic_kprobe_process_filter+0xe9c>
    43fc:      	ldr	x8, [sp, #0x58]
    4400:      	mov	w9, #0x8                // =8
    4404:      	mov	w10, #0x71              // =113
    4408:      	add	x11, sp, #0x58
    440c:      	add	x0, sp, #0x58
    4410:      	mov	w1, #0x8                // =8
    4414:      	add	x8, x8, #0x8e0
    4418:      	ldr	x8, [sp, #0x58]
    441c:      	add	x2, x8, #0x8e0
    4420:      	blr	x10
    4424:      	ldr	x8, [sp, #0x58]
    4428:      	cbz	x8, 0x44a4 <generic_kprobe_process_filter+0x254>
    442c:      	add	x8, x8, #0x8d4
    4430:      	mov	w9, #0x4                // =4
    4434:      	mov	w10, #0x71              // =113
    4438:      	add	x11, sp, #0xd8
    443c:      	ldr	x8, [sp, #0x58]
    4440:      	add	x0, sp, #0xd8
    4444:      	mov	w1, #0x4                // =4
    4448:      	add	x2, x8, #0x8d4
    444c:      	blr	x10
    4450:      	ldr	w8, [sp, #0xd8]
    4454:      	add	x9, sp, #0xc8
    4458:      	add	x1, sp, #0xc8
    445c:      	mov	x0, x19
    4460:      	str	w8, [sp, #0xc8]
    4464:      	mov	w8, #0x1                // =1
    4468:      	blr	x8
    446c:      	cbz	x0, 0x447c <generic_kprobe_process_filter+0x22c>
    4470:      	ldr	x8, [x0, #0x8]
    4474:      	mov	x24, x0
    4478:      	cbnz	x8, 0x50ec <generic_kprobe_process_filter+0xe9c>
    447c:      	ldr	x8, [sp, #0x58]
    4480:      	mov	w9, #0x8                // =8
    4484:      	mov	w10, #0x71              // =113
    4488:      	add	x11, sp, #0x58
    448c:      	add	x0, sp, #0x58
    4490:      	mov	w1, #0x8                // =8
    4494:      	add	x8, x8, #0x8e0
    4498:      	ldr	x8, [sp, #0x58]
    449c:      	add	x2, x8, #0x8e0
    44a0:      	blr	x10
    44a4:      	str	x20, [sp, #0x38]
    44a8:      	mov	w8, #0x23               // =35
    44ac:      	blr	x8
    44b0:      	add	x2, x0, #0x8d4
    44b4:      	mov	w8, #0x4                // =4
    44b8:      	add	x9, sp, #0x58
    44bc:      	mov	x24, x0
    44c0:      	add	x0, sp, #0x58
    44c4:      	mov	w1, #0x4                // =4
    44c8:      	blr	x8
    44cc:      	ldr	w8, [sp, #0x58]
    44d0:      	mov	x19, x29
    44d4:      	str	w8, [x19, #0x50]!
    44d8:      	mov	w8, #0x7d               // =125
    44dc:      	blr	x8
    44e0:      	str	x0, [x22, #0x5f18]
    44e4:      	str	wzr, [x19, #0x10]
    44e8:      	add	x2, x24, #0x60
    44ec:      	mov	w8, #0x8                // =8
    44f0:      	mov	w9, #0x71               // =113
    44f4:      	add	x10, sp, #0xc8
    44f8:      	str	xzr, [x22, #0x5f28]
    44fc:      	str	x19, [sp, #0x48]
    4500:      	add	x0, sp, #0xc8
    4504:      	mov	w1, #0x8                // =8
    4508:      	str	wzr, [x19, #0x20]
    450c:      	blr	x9
    4510:      	ldr	x8, [sp, #0xc8]
    4514:      	cbz	x8, 0x4584 <generic_kprobe_process_filter+0x334>
    4518:      	add	x8, x8, #0x4
    451c:      	mov	w9, #0x4                // =4
    4520:      	mov	w10, #0x71              // =113
    4524:      	add	x11, sp, #0xd8
    4528:      	ldr	x8, [sp, #0xc8]
    452c:      	add	x0, sp, #0xd8
    4530:      	mov	w1, #0x4                // =4
    4534:      	add	x2, x8, #0x4
    4538:      	blr	x10
    453c:      	ldr	w8, [sp, #0xd8]
    4540:      	cbz	w8, 0x4584 <generic_kprobe_process_filter+0x334>
    4544:      	ldr	x9, [sp, #0xc8]
    4548:      	lsl	w8, w8, #4
    454c:      	mov	w10, #0x71              // =113
    4550:      	add	x11, sp, #0x58
    4554:      	add	x0, sp, #0x58
    4558:      	mov	w1, #0x10               // =16
    455c:      	add	x8, x9, x8
    4560:      	mov	w9, #0x10               // =16
    4564:      	add	x8, x8, #0x80
    4568:      	ldr	w9, [sp, #0xd8]
    456c:      	ldr	x8, [sp, #0xc8]
    4570:      	lsl	w9, w9, #4
    4574:      	add	x8, x8, x9
    4578:      	add	x2, x8, #0x80
    457c:      	blr	x10
    4580:      	ldr	w8, [sp, #0x58]
    4584:      	str	w8, [x29, #0x74]
    4588:      	mov	w8, #0x5f60             // =24416
    458c:      	str	x22, [sp, #0xe8]
    4590:      	add	x23, x24, #0xae0
    4594:      	mov	w19, #0x8               // =8
    4598:      	add	x25, x22, x8
    459c:      	add	x8, sp, #0x58
    45a0:      	mov	w9, #0x4                // =4
    45a4:      	add	x0, sp, #0x58
    45a8:      	mov	w1, #0x8                // =8
    45ac:      	mov	x2, x23
    45b0:      	mov	w21, #0x4               // =4
    45b4:      	blr	x9
    45b8:      	ldr	x20, [sp, #0x58]
    45bc:      	ldr	x9, [sp, #0xe8]
    45c0:      	mov	w8, #0x5f68             // =24424
    45c4:      	mov	w1, #0x8                // =8
    45c8:      	add	x0, x9, x8
    45cc:      	add	x2, x20, #0x40
    45d0:      	mov	w8, #0x4                // =4
    45d4:      	blr	x8
    45d8:      	ldr	x9, [sp, #0xe8]
    45dc:      	mov	w8, #0x5f70             // =24432
    45e0:      	add	x2, x20, #0x30
    45e4:      	mov	w1, #0x8                // =8
    45e8:      	add	x0, x9, x8
    45ec:      	mov	w8, #0x4                // =4
    45f0:      	blr	x8
    45f4:      	add	x2, x20, #0x38
    45f8:      	mov	w8, #0x4                // =4
    45fc:      	mov	x0, x25
    4600:      	mov	w1, #0x8                // =8
    4604:      	blr	x8
    4608:      	ldr	x9, [sp, #0xe8]
    460c:      	mov	w8, #0x5f38             // =24376
    4610:      	add	x2, x24, #0xb50
    4614:      	add	x0, sp, #0xd8
    4618:      	mov	w1, #0x8                // =8
    461c:      	add	x25, x9, x8
    4620:      	add	x8, sp, #0xd8
    4624:      	mov	w9, #0x4                // =4
    4628:      	blr	x9
    462c:      	add	x12, sp, #0xd8
    4630:      	mov	w9, #0x48               // =72
    4634:      	add	x10, sp, #0x58
    4638:      	ldr	x8, [x12]
    463c:      	mov	w11, #0x4               // =4
    4640:      	add	x0, sp, #0x58
    4644:      	mov	w1, #0x48               // =72
    4648:      	ldr	x2, [x12]
    464c:      	blr	x11
    4650:      	ldr	x8, [sp, #0x60]
    4654:      	mov	w9, #0x4                // =4
    4658:      	mov	x0, x25
    465c:      	mov	w1, #0x4                // =4
    4660:      	add	x8, x8, #0x218
    4664:      	ldr	x8, [sp, #0x60]
    4668:      	ldr	x22, [sp, #0xe8]
    466c:      	add	x2, x8, #0x218
    4670:      	blr	x9
    4674:      	mov	w8, #0x5f3c             // =24380
    4678:      	mov	w9, #0x4                // =4
    467c:      	mov	w1, #0x4                // =4
    4680:      	add	x0, x22, x8
    4684:      	ldr	x8, [sp, #0x68]
    4688:      	add	x8, x8, #0x4d8
    468c:      	ldr	x8, [sp, #0x68]
    4690:      	add	x2, x8, #0x4d8
    4694:      	blr	x9
    4698:      	mov	w8, #0x5f40             // =24384
    469c:      	mov	w9, #0x4                // =4
    46a0:      	mov	w1, #0x4                // =4
    46a4:      	add	x0, x22, x8
    46a8:      	ldr	x8, [sp, #0x70]
    46ac:      	add	x8, x8, #0x58
    46b0:      	ldr	x8, [sp, #0x70]
    46b4:      	add	x2, x8, #0x58
    46b8:      	blr	x9
    46bc:      	str	xzr, [sp, #0xc0]
    46c0:      	add	x2, x24, #0x938
    46c4:      	add	x8, sp, #0xc0
    46c8:      	add	x0, sp, #0xc0
    46cc:      	mov	w1, #0x8                // =8
    46d0:      	blr	x21
    46d4:      	ldr	x8, [sp, #0xc0]
    46d8:      	cbz	x8, 0x4760 <generic_kprobe_process_filter+0x510>
    46dc:      	str	wzr, [sp, #0xb8]
    46e0:      	add	x8, x8, #0x4
    46e4:      	add	x9, sp, #0xb8
    46e8:      	mov	w10, #0x4               // =4
    46ec:      	add	x0, sp, #0xb8
    46f0:      	mov	w1, #0x4                // =4
    46f4:      	mov	w19, #0x4               // =4
    46f8:      	ldr	x8, [sp, #0xc0]
    46fc:      	add	x2, x8, #0x4
    4700:      	blr	x10
    4704:      	ldr	x8, [sp, #0xc0]
    4708:      	ldrsw	x9, [sp, #0xb8]
    470c:      	add	x10, sp, #0xc8
    4710:      	mov	w11, #0x4               // =4
    4714:      	add	x0, sp, #0xc8
    4718:      	mov	w1, #0x10               // =16
    471c:      	add	x8, x8, x9, lsl #4
    4720:      	mov	w9, #0x10               // =16
    4724:      	add	x8, x8, #0x80
    4728:      	ldr	x8, [sp, #0xc0]
    472c:      	ldrsw	x9, [sp, #0xb8]
    4730:      	add	x8, x8, x9, lsl #4
    4734:      	add	x2, x8, #0x80
    4738:      	blr	x11
    473c:      	mov	w8, #0x5f44             // =24388
    4740:      	mov	w1, #0x4                // =4
    4744:      	add	x0, x22, x8
    4748:      	ldr	x8, [sp, #0xd0]
    474c:      	add	x8, x8, #0x158
    4750:      	ldr	x8, [sp, #0xd0]
    4754:      	add	x2, x8, #0x158
    4758:      	blr	x19
    475c:      	b	0x4764 <generic_kprobe_process_filter+0x514>
    4760:      	str	wzr, [x29, #0x84]
    4764:      	mov	w8, #0x5f48             // =24392
    4768:      	mov	w9, #0x4                // =4
    476c:      	mov	w1, #0x4                // =4
    4770:      	mov	w19, #0x4               // =4
    4774:      	add	x0, x22, x8
    4778:      	ldr	x8, [sp, #0x78]
    477c:      	add	x8, x8, #0x158
    4780:      	ldr	x8, [sp, #0x78]
    4784:      	add	x2, x8, #0x158
    4788:      	blr	x9
    478c:      	mov	w8, #0x5f4c             // =24396
    4790:      	mov	w9, #0x4                // =4
    4794:      	mov	w1, #0x4                // =4
    4798:      	add	x0, x22, x8
    479c:      	ldr	x8, [sp, #0x80]
    47a0:      	add	x8, x8, #0x118
    47a4:      	ldr	x8, [sp, #0x80]
    47a8:      	add	x2, x8, #0x118
    47ac:      	blr	x9
    47b0:      	mov	w8, #0x5f50             // =24400
    47b4:      	mov	w9, #0x4                // =4
    47b8:      	mov	w1, #0x4                // =4
    47bc:      	add	x0, x22, x8
    47c0:      	ldr	x8, [sp, #0x88]
    47c4:      	add	x8, x8, #0x98
    47c8:      	ldr	x8, [sp, #0x88]
    47cc:      	add	x2, x8, #0x98
    47d0:      	blr	x9
    47d4:      	mov	w8, #0x5f54             // =24404
    47d8:      	mov	w9, #0x4                // =4
    47dc:      	mov	w1, #0x4                // =4
    47e0:      	add	x0, x22, x8
    47e4:      	ldr	x8, [sp, #0x90]
    47e8:      	add	x8, x8, #0x98
    47ec:      	ldr	x8, [sp, #0x90]
    47f0:      	add	x2, x8, #0x98
    47f4:      	blr	x9
    47f8:      	mov	w8, #0x5f58             // =24408
    47fc:      	mov	w9, #0x4                // =4
    4800:      	mov	w1, #0x4                // =4
    4804:      	add	x0, x22, x8
    4808:      	ldr	x8, [sp, #0x98]
    480c:      	add	x8, x8, #0x58
    4810:      	ldr	x8, [sp, #0x98]
    4814:      	add	x2, x8, #0x58
    4818:      	blr	x9
    481c:      	stp	xzr, xzr, [sp, #0xc0]
    4820:      	mov	w20, #0x8               // =8
    4824:      	add	x8, sp, #0xc8
    4828:      	mov	w9, #0x4                // =4
    482c:      	add	x0, sp, #0xc8
    4830:      	mov	w1, #0x8                // =8
    4834:      	mov	x2, x23
    4838:      	blr	x9
    483c:      	ldr	x8, [sp, #0xc8]
    4840:      	add	x9, sp, #0xc0
    4844:      	mov	w10, #0x4               // =4
    4848:      	add	x0, sp, #0xc0
    484c:      	mov	w1, #0x8                // =8
    4850:      	add	x8, x8, #0x90
    4854:      	ldr	x8, [sp, #0xc8]
    4858:      	add	x2, x8, #0x90
    485c:      	blr	x10
    4860:      	mov	w8, #0x5f5c             // =24412
    4864:      	mov	w1, #0x4                // =4
    4868:      	add	x0, x22, x8
    486c:      	ldr	x8, [sp, #0xc0]
    4870:      	add	x8, x8, #0x158
    4874:      	ldr	x8, [sp, #0xc0]
    4878:      	add	x2, x8, #0x158
    487c:      	blr	x19
    4880:      	ldr	w8, [x29, #0x74]
    4884:      	cmp	w8, #0x1
    4888:      	b.ne	0x4898 <generic_kprobe_process_filter+0x648>
    488c:      	ldr	w8, [x29, #0x70]
    4890:      	orr	w8, w8, #0x2000000
    4894:      	str	w8, [x29, #0x70]
    4898:      	add	x0, x29, #0xb8
    489c:      	mov	w1, wzr
    48a0:      	mov	w2, #0x308              // =776
    48a4:      	bl	0x48a4 <generic_kprobe_process_filter+0x654>
    48a8:      	mov	w8, #0x6290             // =25232
    48ac:      	add	x2, x24, #0x858
    48b0:      	mov	w19, #0x8               // =8
    48b4:      	mov	w9, #0x4                // =4
    48b8:      	add	x0, sp, #0xc8
    48bc:      	mov	w1, #0x8                // =8
    48c0:      	mov	w20, #0x4               // =4
    48c4:      	add	x21, x22, x8
    48c8:      	add	x8, sp, #0xc8
    48cc:      	blr	x9
    48d0:      	ldr	x8, [sp, #0xc8]
    48d4:      	add	x9, sp, #0x58
    48d8:      	add	x0, sp, #0x58
    48dc:      	mov	w1, #0x8                // =8
    48e0:      	add	x8, x8, #0x528
    48e4:      	ldr	x8, [sp, #0xc8]
    48e8:      	add	x2, x8, #0x528
    48ec:      	blr	x20
    48f0:      	str	wzr, [sp, #0xa4]
    48f4:      	adrp	x0, 0x4000 <generic_kprobe_process_event+0x3ca0>
    48f8:      	ldr	x19, [sp, #0x58]
    48fc:      	mov	w8, #0x1                // =1
    4900:      	add	x9, sp, #0xa4
    4904:      	add	x1, sp, #0xa4
    4908:      	ldr	x0, [x0]
    490c:      	blr	x8
    4910:      	cbz	x0, 0x4f34 <generic_kprobe_process_filter+0xce4>
    4914:      	mov	w8, #0x1000             // =4096
    4918:      	str	x21, [sp, #0x30]
    491c:      	str	x29, [sp, #0x40]
    4920:      	mov	x24, x0
    4924:      	add	x20, x0, #0x1, lsl #12  // =0x1000
    4928:      	str	w8, [x29, #0x550]
    492c:      	mov	w8, #0x23               // =35
    4930:      	blr	x8
    4934:      	add	x2, x0, #0xb30
    4938:      	mov	w23, #0x8               // =8
    493c:      	add	x8, sp, #0xa8
    4940:      	mov	w9, #0x4                // =4
    4944:      	add	x0, sp, #0xa8
    4948:      	mov	w1, #0x8                // =8
    494c:      	mov	w29, #0x4               // =4
    4950:      	blr	x9
    4954:      	ldr	x22, [sp, #0xa8]
    4958:      	add	x25, x19, #0x48
    495c:      	add	x8, sp, #0xb0
    4960:      	mov	w9, #0x4                // =4
    4964:      	add	x0, sp, #0xb0
    4968:      	mov	w1, #0x8                // =8
    496c:      	mov	x2, x25
    4970:      	blr	x9
    4974:      	ldr	x21, [sp, #0xb0]
    4978:      	add	x8, sp, #0x58
    497c:      	add	x0, sp, #0x58
    4980:      	mov	w1, #0x8                // =8
    4984:      	add	x2, x21, #0x10
    4988:      	blr	x29
    498c:      	ldr	x8, [sp, #0x58]
    4990:      	cbz	x8, 0x4bd0 <generic_kprobe_process_filter+0x980>
    4994:      	ldr	x8, [sp, #0x40]
    4998:      	stp	xzr, xzr, [sp, #0x58]
    499c:      	add	x21, x22, #0x18
    49a0:      	add	x9, sp, #0x58
    49a4:      	add	x2, x22, #0x20
    49a8:      	mov	w22, #0x8               // =8
    49ac:      	stp	x24, xzr, [sp, #0x68]
    49b0:      	add	x0, sp, #0x58
    49b4:      	mov	w1, #0x8                // =8
    49b8:      	add	x29, x19, #0x40
    49bc:      	add	x19, x9, #0x8
    49c0:      	add	x24, x9, #0x18
    49c4:      	stp	xzr, xzr, [sp, #0x78]
    49c8:      	add	x23, x9, #0x20
    49cc:      	str	x20, [sp, #0x88]
    49d0:      	str	x20, [sp, #0x28]
    49d4:      	mov	w20, #0x4               // =4
    49d8:      	ldr	w8, [x8, #0x550]
    49dc:      	strb	wzr, [sp, #0x94]
    49e0:      	str	w8, [sp, #0x90]
    49e4:      	mov	w8, #0x4                // =4
    49e8:      	blr	x8
    49ec:      	mov	w8, #0x4                // =4
    49f0:      	mov	x0, x19
    49f4:      	mov	w1, #0x8                // =8
    49f8:      	mov	x2, x21
    49fc:      	blr	x8
    4a00:      	mov	w8, #0x4                // =4
    4a04:      	mov	x0, x24
    4a08:      	mov	w1, #0x8                // =8
    4a0c:      	mov	x2, x25
    4a10:      	blr	x8
    4a14:      	mov	x0, x23
    4a18:      	mov	w1, #0x8                // =8
    4a1c:      	mov	x2, x29
    4a20:      	blr	x20
    4a24:      	ldr	x8, [sp, #0x78]
    4a28:      	sub	x8, x8, #0x20
    4a2c:      	str	x8, [sp, #0x80]
    4a30:      	adrp	x8, 0x4000 <generic_kprobe_process_event+0x3ca0>
    4a34:      	ldr	x8, [x8]
    4a38:      	ldrb	w8, [x8]
    4a3c:      	cbz	w8, 0x4c24 <generic_kprobe_process_filter+0x9d4>
    4a40:      	mov	w19, #0x80              // =128
    4a44:      	mov	w21, #0x8               // =8
    4a48:      	add	x23, sp, #0xb8
    4a4c:      	add	x29, sp, #0xd8
    4a50:      	b	0x4ab0 <generic_kprobe_process_filter+0x860>
    4a54:      	nop
    4a58:      	nop
    4a5c:      	nop
    4a60:      	add	x2, x22, #0x10
    4a64:      	mov	w8, #0x4                // =4
    4a68:      	add	x0, sp, #0xd8
    4a6c:      	mov	w1, #0x8                // =8
    4a70:      	blr	x8
    4a74:      	add	x20, sp, #0xd8
    4a78:      	ldr	x8, [sp, #0x80]
    4a7c:      	ldr	x9, [x20]
    4a80:      	cmp	x8, x9
    4a84:      	b.eq	0x4db0 <generic_kprobe_process_filter+0xb60>
    4a88:      	add	x2, x22, #0x18
    4a8c:      	mov	w8, #0x4                // =4
    4a90:      	mov	x0, x24
    4a94:      	mov	w1, #0x8                // =8
    4a98:      	blr	x8
    4a9c:      	ldr	x8, [x20]
    4aa0:      	add	x9, x8, #0x20
    4aa4:      	stp	x9, x8, [sp, #0x78]
    4aa8:      	subs	w19, w19, #0x1
    4aac:      	b.eq	0x4db8 <generic_kprobe_process_filter+0xb68>
    4ab0:      	ldp	x20, x2, [sp, #0x70]
    4ab4:      	ldp	x8, x9, [sp, #0x58]
    4ab8:      	cmp	x20, x8
    4abc:      	ccmp	x2, x9, #0x0, eq
    4ac0:      	b.eq	0x4db0 <generic_kprobe_process_filter+0xb60>
    4ac4:      	ldr	x22, [sp, #0x80]
    4ac8:      	mov	w8, #0x4                // =4
    4acc:      	add	x0, sp, #0xb8
    4ad0:      	mov	w1, #0x8                // =8
    4ad4:      	blr	x8
    4ad8:      	ldr	x8, [sp, #0xb8]
    4adc:      	cmp	x20, x8
    4ae0:      	b.eq	0x4a60 <generic_kprobe_process_filter+0x810>
    4ae4:      	add	x25, x20, #0x18
    4ae8:      	mov	w8, #0x4                // =4
    4aec:      	add	x0, sp, #0xd8
    4af0:      	mov	w1, #0x8                // =8
    4af4:      	mov	x2, x25
    4af8:      	blr	x8
    4afc:      	add	x8, sp, #0xd8
    4b00:      	ldr	x8, [x8]
    4b04:      	cmp	x8, x20
    4b08:      	b.eq	0x4a60 <generic_kprobe_process_filter+0x810>
    4b0c:      	mov	w8, #0x4                // =4
    4b10:      	add	x9, sp, #0xc0
    4b14:      	add	x0, sp, #0xc0
    4b18:      	mov	w1, #0x8                // =8
    4b1c:      	mov	x2, x25
    4b20:      	blr	x8
    4b24:      	add	x2, x20, #0x20
    4b28:      	mov	w8, #0x4                // =4
    4b2c:      	mov	w9, #0x10               // =16
    4b30:      	add	x10, sp, #0xc8
    4b34:      	add	x0, sp, #0xc8
    4b38:      	mov	w1, #0x10               // =16
    4b3c:      	blr	x8
    4b40:      	ldr	w20, [sp, #0xcc]
    4b44:      	ldr	x8, [sp, #0x68]
    4b48:      	ldr	x10, [sp, #0x88]
    4b4c:      	sub	x12, x10, x8
    4b50:      	ldr	w22, [sp, #0x90]
    4b54:      	subs	w10, w20, w22
    4b58:      	ldr	x9, [sp, #0xd0]
    4b5c:      	csel	w10, wzr, w10, lo
    4b60:      	cmp	w22, w20
    4b64:      	csel	w11, w22, w20, lo
    4b68:      	cinc	w13, w11, hi
    4b6c:      	sub	w14, w22, w13
    4b70:      	subs	x12, x12, x13
    4b74:      	str	w14, [sp, #0x90]
    4b78:      	b.lo	0x4db8 <generic_kprobe_process_filter+0xb68>
    4b7c:      	cmp	x12, #0xfff
    4b80:      	b.hi	0x4db8 <generic_kprobe_process_filter+0xb68>
    4b84:      	cmp	w22, w20
    4b88:      	b.ls	0x4b94 <generic_kprobe_process_filter+0x944>
    4b8c:      	mov	w13, #0x2f              // =47
    4b90:      	strb	w13, [x8, x12]
    4b94:      	add	x25, x8, x12
    4b98:      	cmp	w22, w20
    4b9c:      	add	x2, x9, x10
    4ba0:      	and	w1, w11, #0xff
    4ba4:      	mov	w8, #0x4                // =4
    4ba8:      	cinc	x0, x25, hi
    4bac:      	blr	x8
    4bb0:      	cmp	w22, w20
    4bb4:      	str	x25, [sp, #0x88]
    4bb8:      	b.ls	0x4db8 <generic_kprobe_process_filter+0xb68>
    4bbc:      	ldr	x8, [sp, #0xc0]
    4bc0:      	str	x8, [sp, #0x70]
    4bc4:      	subs	w19, w19, #0x1
    4bc8:      	b.ne	0x4ab0 <generic_kprobe_process_filter+0x860>
    4bcc:      	b	0x4db8 <generic_kprobe_process_filter+0xb68>
    4bd0:      	add	x2, x21, #0x18
    4bd4:      	mov	w8, #0x8                // =8
    4bd8:      	mov	w9, #0x4                // =4
    4bdc:      	add	x10, sp, #0x58
    4be0:      	add	x0, sp, #0x58
    4be4:      	mov	w1, #0x8                // =8
    4be8:      	blr	x9
    4bec:      	ldr	x8, [sp, #0x58]
    4bf0:      	cmp	x8, x21
    4bf4:      	b.eq	0x4994 <generic_kprobe_process_filter+0x744>
    4bf8:      	ldr	x29, [sp, #0x40]
    4bfc:      	ldr	w9, [x29, #0x550]
    4c00:      	sub	w8, w9, #0xa
    4c04:      	cmp	w9, #0x9
    4c08:      	str	w8, [x29, #0x550]
    4c0c:      	b.gt	0x52e0 <generic_kprobe_process_filter+0x1090>
    4c10:      	ldr	x21, [sp, #0x30]
    4c14:      	mov	w9, #-0x24              // =-36
    4c18:      	mov	x24, x20
    4c1c:      	str	w9, [x29, #0x554]
    4c20:      	b	0x4e1c <generic_kprobe_process_filter+0xbcc>
    4c24:      	mov	w19, #0x80              // =128
    4c28:      	mov	w21, #0x8               // =8
    4c2c:      	add	x23, sp, #0xb8
    4c30:      	add	x29, sp, #0xd8
    4c34:      	b	0x4c90 <generic_kprobe_process_filter+0xa40>
    4c38:      	nop
    4c3c:      	nop
    4c40:      	add	x2, x22, #0x10
    4c44:      	mov	w8, #0x4                // =4
    4c48:      	add	x0, sp, #0xd8
    4c4c:      	mov	w1, #0x8                // =8
    4c50:      	blr	x8
    4c54:      	add	x20, sp, #0xd8
    4c58:      	ldr	x8, [sp, #0x80]
    4c5c:      	ldr	x9, [x20]
    4c60:      	cmp	x8, x9
    4c64:      	b.eq	0x4db0 <generic_kprobe_process_filter+0xb60>
    4c68:      	add	x2, x22, #0x18
    4c6c:      	mov	w8, #0x4                // =4
    4c70:      	mov	x0, x24
    4c74:      	mov	w1, #0x8                // =8
    4c78:      	blr	x8
    4c7c:      	ldr	x8, [x20]
    4c80:      	add	x9, x8, #0x20
    4c84:      	stp	x9, x8, [sp, #0x78]
    4c88:      	subs	w19, w19, #0x1
    4c8c:      	b.eq	0x4db8 <generic_kprobe_process_filter+0xb68>
    4c90:      	ldp	x20, x2, [sp, #0x70]
    4c94:      	ldp	x8, x9, [sp, #0x58]
    4c98:      	cmp	x20, x8
    4c9c:      	ccmp	x2, x9, #0x0, eq
    4ca0:      	b.eq	0x4db0 <generic_kprobe_process_filter+0xb60>
    4ca4:      	ldr	x22, [sp, #0x80]
    4ca8:      	mov	w8, #0x4                // =4
    4cac:      	add	x0, sp, #0xb8
    4cb0:      	mov	w1, #0x8                // =8
    4cb4:      	blr	x8
    4cb8:      	ldr	x8, [sp, #0xb8]
    4cbc:      	cmp	x20, x8
    4cc0:      	b.eq	0x4c40 <generic_kprobe_process_filter+0x9f0>
    4cc4:      	add	x25, x20, #0x18
    4cc8:      	mov	w8, #0x4                // =4
    4ccc:      	add	x0, sp, #0xd8
    4cd0:      	mov	w1, #0x8                // =8
    4cd4:      	mov	x2, x25
    4cd8:      	blr	x8
    4cdc:      	add	x8, sp, #0xd8
    4ce0:      	ldr	x8, [x8]
    4ce4:      	cmp	x8, x20
    4ce8:      	b.eq	0x4c40 <generic_kprobe_process_filter+0x9f0>
    4cec:      	mov	w8, #0x4                // =4
    4cf0:      	add	x9, sp, #0xc0
    4cf4:      	add	x0, sp, #0xc0
    4cf8:      	mov	w1, #0x8                // =8
    4cfc:      	mov	x2, x25
    4d00:      	blr	x8
    4d04:      	add	x2, x20, #0x20
    4d08:      	mov	w8, #0x4                // =4
    4d0c:      	mov	w9, #0x10               // =16
    4d10:      	add	x10, sp, #0xc8
    4d14:      	add	x0, sp, #0xc8
    4d18:      	mov	w1, #0x10               // =16
    4d1c:      	blr	x8
    4d20:      	ldr	w20, [sp, #0xcc]
    4d24:      	ldr	x8, [sp, #0x68]
    4d28:      	ldr	x10, [sp, #0x88]
    4d2c:      	sub	x12, x10, x8
    4d30:      	ldr	w22, [sp, #0x90]
    4d34:      	subs	w10, w20, w22
    4d38:      	ldr	x9, [sp, #0xd0]
    4d3c:      	csel	w10, wzr, w10, lo
    4d40:      	cmp	w22, w20
    4d44:      	csel	w11, w22, w20, lo
    4d48:      	cinc	w13, w11, hi
    4d4c:      	sub	w14, w22, w13
    4d50:      	subs	x12, x12, x13
    4d54:      	str	w14, [sp, #0x90]
    4d58:      	b.lo	0x4db8 <generic_kprobe_process_filter+0xb68>
    4d5c:      	cmp	x12, #0xfff
    4d60:      	b.hi	0x4db8 <generic_kprobe_process_filter+0xb68>
    4d64:      	cmp	w22, w20
    4d68:      	b.ls	0x4d74 <generic_kprobe_process_filter+0xb24>
    4d6c:      	mov	w13, #0x2f              // =47
    4d70:      	strb	w13, [x8, x12]
    4d74:      	add	x25, x8, x12
    4d78:      	cmp	w22, w20
    4d7c:      	add	x2, x9, x10
    4d80:      	and	w1, w11, #0xff
    4d84:      	mov	w8, #0x4                // =4
    4d88:      	cinc	x0, x25, hi
    4d8c:      	blr	x8
    4d90:      	cmp	w22, w20
    4d94:      	str	x25, [sp, #0x88]
    4d98:      	b.ls	0x4db8 <generic_kprobe_process_filter+0xb68>
    4d9c:      	ldr	x8, [sp, #0xc0]
    4da0:      	str	x8, [sp, #0x70]
    4da4:      	subs	w19, w19, #0x1
    4da8:      	b.ne	0x4c90 <generic_kprobe_process_filter+0xa40>
    4dac:      	b	0x4db8 <generic_kprobe_process_filter+0xb68>
    4db0:      	mov	w8, #0x1                // =1
    4db4:      	strb	w8, [sp, #0x94]
    4db8:      	ldr	x24, [sp, #0x88]
    4dbc:      	ldr	x9, [sp, #0x28]
    4dc0:      	cmp	x24, x9
    4dc4:      	b.eq	0x4e08 <generic_kprobe_process_filter+0xbb8>
    4dc8:      	ldrb	w8, [sp, #0x94]
    4dcc:      	ldr	x29, [sp, #0x40]
    4dd0:      	cmp	w8, #0x0
    4dd4:      	ldr	x21, [sp, #0x30]
    4dd8:      	cset	w8, eq
    4ddc:      	lsl	w9, w8, #1
    4de0:      	ldr	w8, [sp, #0x90]
    4de4:      	cmp	w8, #0x1
    4de8:      	str	w8, [x29, #0x550]
    4dec:      	str	w9, [x29, #0x554]
    4df0:      	b.lt	0x4e00 <generic_kprobe_process_filter+0xbb0>
    4df4:      	mov	w9, #0x1000             // =4096
    4df8:      	sub	w8, w9, w8
    4dfc:      	str	w8, [x29, #0x550]
    4e00:      	cbnz	x24, 0x4e1c <generic_kprobe_process_filter+0xbcc>
    4e04:      	b	0x4f34 <generic_kprobe_process_filter+0xce4>
    4e08:      	ldr	x29, [sp, #0x40]
    4e0c:      	ldr	x21, [sp, #0x30]
    4e10:      	mov	w8, wzr
    4e14:      	mov	x24, x9
    4e18:      	str	xzr, [x29, #0x550]
    4e1c:      	subs	w9, w8, #0x7f
    4e20:      	mov	w10, #0x7f              // =127
    4e24:      	mov	x11, x29
    4e28:      	mov	x0, x21
    4e2c:      	mov	x2, x24
    4e30:      	csel	w29, w8, w10, lo
    4e34:      	csel	w19, wzr, w9, lo
    4e38:      	cmp	w8, #0xff
    4e3c:      	mov	w9, #0xff               // =255
    4e40:      	csel	w8, w8, w9, lo
    4e44:      	and	w1, w8, #0xff
    4e48:      	str	w1, [x11, #0x550]
    4e4c:      	mov	w8, #0x4                // =4
    4e50:      	blr	x8
    4e54:      	adrp	x25, 0x4000 <generic_kprobe_process_event+0x3ca0>
    4e58:      	ldr	x25, [x25]
    4e5c:      	cbz	x0, 0x4ecc <generic_kprobe_process_filter+0xc7c>
    4e60:      	neg	w8, w0
    4e64:      	mov	w9, #0x1                // =1
    4e68:      	add	x1, sp, #0x58
    4e6c:      	strh	w8, [sp, #0x58]
    4e70:      	mov	w8, #0x8                // =8
    4e74:      	mov	x0, x25
    4e78:      	mov	w20, #0x1               // =1
    4e7c:      	strh	w8, [sp, #0x5a]
    4e80:      	mov	x8, #0x2de              // =734
    4e84:      	movk	x8, #0x4, lsl #32
    4e88:      	stur	x8, [sp, #0x5c]
    4e8c:      	add	x8, sp, #0x58
    4e90:      	blr	x9
    4e94:      	cbz	x0, 0x4ea8 <generic_kprobe_process_filter+0xc58>
    4e98:      	ldr	w8, [x0]
    4e9c:      	add	w8, w8, #0x1
    4ea0:      	str	w8, [x0]
    4ea4:      	b	0x4ecc <generic_kprobe_process_filter+0xc7c>
    4ea8:      	str	w20, [sp, #0xc8]
    4eac:      	mov	x3, xzr
    4eb0:      	mov	w8, #0x2                // =2
    4eb4:      	add	x9, sp, #0x58
    4eb8:      	add	x10, sp, #0xc8
    4ebc:      	add	x1, sp, #0x58
    4ec0:      	add	x2, sp, #0xc8
    4ec4:      	mov	x0, x25
    4ec8:      	blr	x8
    4ecc:      	ldr	x9, [sp, #0xe8]
    4ed0:      	mov	w8, #0x6390             // =25488
    4ed4:      	add	x2, x24, x19
    4ed8:      	mov	w1, w29
    4edc:      	add	x0, x9, x8
    4ee0:      	mov	w8, #0x4                // =4
    4ee4:      	blr	x8
    4ee8:      	ldr	x29, [sp, #0x40]
    4eec:      	cbz	x0, 0x4f34 <generic_kprobe_process_filter+0xce4>
    4ef0:      	neg	w8, w0
    4ef4:      	mov	w9, #0x1                // =1
    4ef8:      	add	x1, sp, #0x58
    4efc:      	strh	w8, [sp, #0x58]
    4f00:      	mov	w8, #0x8                // =8
    4f04:      	mov	x0, x25
    4f08:      	mov	w19, #0x1               // =1
    4f0c:      	strh	w8, [sp, #0x5a]
    4f10:      	mov	x8, #0x2e0              // =736
    4f14:      	movk	x8, #0x4, lsl #32
    4f18:      	stur	x8, [sp, #0x5c]
    4f1c:      	add	x8, sp, #0x58
    4f20:      	blr	x9
    4f24:      	cbz	x0, 0x4f5c <generic_kprobe_process_filter+0xd0c>
    4f28:      	ldr	w8, [x0]
    4f2c:      	add	w8, w8, #0x1
    4f30:      	str	w8, [x0]
    4f34:      	ldr	w8, [x29, #0x550]
    4f38:      	sub	w9, w8, #0x101
    4f3c:      	cmn	w9, #0x101
    4f40:      	b.hi	0x4f90 <generic_kprobe_process_filter+0xd40>
    4f44:      	ldr	x20, [sp, #0x38]
    4f48:      	ldr	x22, [sp, #0xe8]
    4f4c:      	mov	w8, #-0x1               // =-1
    4f50:      	ldr	x24, [sp, #0x48]
    4f54:      	stur	w8, [x29, #0xb8]
    4f58:      	b	0x50e0 <generic_kprobe_process_filter+0xe90>
    4f5c:      	str	w19, [sp, #0xc8]
    4f60:      	mov	x3, xzr
    4f64:      	mov	w8, #0x2                // =2
    4f68:      	add	x9, sp, #0x58
    4f6c:      	add	x10, sp, #0xc8
    4f70:      	add	x1, sp, #0x58
    4f74:      	add	x2, sp, #0xc8
    4f78:      	mov	x0, x25
    4f7c:      	blr	x8
    4f80:      	ldr	w8, [x29, #0x550]
    4f84:      	sub	w9, w8, #0x101
    4f88:      	cmn	w9, #0x101
    4f8c:      	b.ls	0x4f44 <generic_kprobe_process_filter+0xcf4>
    4f90:      	ldr	x22, [sp, #0xe8]
    4f94:      	and	x24, x8, #0xff
    4f98:      	mov	w8, #0x5f80             // =24448
    4f9c:      	mov	x2, x21
    4fa0:      	mov	w1, w24
    4fa4:      	add	x0, x22, x8
    4fa8:      	mov	w8, #0x4                // =4
    4fac:      	blr	x8
    4fb0:      	mov	x23, x0
    4fb4:      	cbz	x0, 0x5030 <generic_kprobe_process_filter+0xde0>
    4fb8:      	neg	w8, w23
    4fbc:      	adrp	x25, 0x4000 <generic_kprobe_process_event+0x3ca0>
    4fc0:      	mov	w9, #0x1                // =1
    4fc4:      	strh	w8, [sp, #0x58]
    4fc8:      	mov	w8, #0xf                // =15
    4fcc:      	add	x1, sp, #0x58
    4fd0:      	mov	w19, #0x1               // =1
    4fd4:      	strh	w8, [sp, #0x5a]
    4fd8:      	mov	x8, #0x164              // =356
    4fdc:      	movk	x8, #0x4, lsl #32
    4fe0:      	stur	x8, [sp, #0x5c]
    4fe4:      	add	x8, sp, #0x58
    4fe8:      	ldr	x25, [x25]
    4fec:      	mov	x0, x25
    4ff0:      	blr	x9
    4ff4:      	cbz	x0, 0x5008 <generic_kprobe_process_filter+0xdb8>
    4ff8:      	ldr	w8, [x0]
    4ffc:      	add	w8, w8, #0x1
    5000:      	str	w8, [x0]
    5004:      	b	0x502c <generic_kprobe_process_filter+0xddc>
    5008:      	str	w19, [sp, #0xc8]
    500c:      	mov	x3, xzr
    5010:      	mov	w8, #0x2                // =2
    5014:      	add	x9, sp, #0x58
    5018:      	add	x10, sp, #0xc8
    501c:      	add	x1, sp, #0x58
    5020:      	add	x2, sp, #0xc8
    5024:      	mov	x0, x25
    5028:      	blr	x8
    502c:      	ldr	x22, [sp, #0xe8]
    5030:      	cmp	w23, #0x0
    5034:      	csel	w8, w24, w23, eq
    5038:      	cmp	w24, #0x7f
    503c:      	stur	w8, [x29, #0xb8]
    5040:      	mov	w8, #0x7f               // =127
    5044:      	csel	w1, w24, w8, lo
    5048:      	mov	w8, #0x6080             // =24704
    504c:      	add	x0, x22, x8
    5050:      	mov	w8, #0x6390             // =25488
    5054:      	add	x2, x22, x8
    5058:      	mov	w8, #0x4                // =4
    505c:      	blr	x8
    5060:      	ldr	x20, [sp, #0x38]
    5064:      	ldr	x24, [sp, #0x48]
    5068:      	cbz	x0, 0x50e0 <generic_kprobe_process_filter+0xe90>
    506c:      	neg	w8, w0
    5070:      	adrp	x23, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5074:      	mov	w9, #0x1                // =1
    5078:      	strh	w8, [sp, #0x58]
    507c:      	mov	w8, #0xf                // =15
    5080:      	add	x1, sp, #0x58
    5084:      	mov	w19, #0x1               // =1
    5088:      	strh	w8, [sp, #0x5a]
    508c:      	mov	x8, #0x16a              // =362
    5090:      	movk	x8, #0x4, lsl #32
    5094:      	stur	x8, [sp, #0x5c]
    5098:      	add	x8, sp, #0x58
    509c:      	ldr	x23, [x23]
    50a0:      	mov	x0, x23
    50a4:      	blr	x9
    50a8:      	cbz	x0, 0x50bc <generic_kprobe_process_filter+0xe6c>
    50ac:      	ldr	w8, [x0]
    50b0:      	add	w8, w8, #0x1
    50b4:      	str	w8, [x0]
    50b8:      	b	0x50e0 <generic_kprobe_process_filter+0xe90>
    50bc:      	str	w19, [sp, #0xc8]
    50c0:      	mov	x3, xzr
    50c4:      	mov	w8, #0x2                // =2
    50c8:      	add	x9, sp, #0x58
    50cc:      	add	x10, sp, #0xc8
    50d0:      	add	x1, sp, #0x58
    50d4:      	add	x2, sp, #0xc8
    50d8:      	mov	x0, x23
    50dc:      	blr	x8
    50e0:      	ldrb	w8, [x22, #0x1]
    50e4:      	orr	w8, w8, #0x10
    50e8:      	strb	w8, [x22, #0x1]
    50ec:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    50f0:      	mov	w8, #0x5ef8             // =24312
    50f4:      	ldr	x0, [x0]
    50f8:      	add	x1, x22, x8
    50fc:      	mov	w8, #0x1                // =1
    5100:      	blr	x8
    5104:      	cbz	x0, 0x658c <generic_kprobe_process_filter+0x233c>
    5108:      	ldr	x21, [x22, #0x5eb8]
    510c:      	cmp	x21, #0x6
    5110:      	b.hs	0x52a8 <generic_kprobe_process_filter+0x1058>
    5114:      	ldrsw	x8, [x0]
    5118:      	mov	x23, x0
    511c:      	cbz	w8, 0x52c4 <generic_kprobe_process_filter+0x1074>
    5120:      	cmp	x21, x8
    5124:      	b.hs	0x52a8 <generic_kprobe_process_filter+0x1058>
    5128:      	str	x8, [sp, #0x28]
    512c:      	stp	x29, x24, [sp, #0x40]
    5130:      	adrp	x24, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5134:      	mov	w8, #0x1                // =1
    5138:      	add	x9, sp, #0xd8
    513c:      	str	x22, [sp, #0xe8]
    5140:      	add	x1, sp, #0xd8
    5144:      	str	x20, [sp, #0x38]
    5148:      	str	w21, [sp, #0xd8]
    514c:      	str	wzr, [sp, #0xc0]
    5150:      	ldr	x24, [x24]
    5154:      	mov	x0, x24
    5158:      	blr	x8
    515c:      	cbz	x0, 0x5574 <generic_kprobe_process_filter+0x1324>
    5160:      	ldr	w8, [x0]
    5164:      	mov	x25, x0
    5168:      	cbz	w8, 0x5574 <generic_kprobe_process_filter+0x1324>
    516c:      	ldr	x9, [sp, #0x48]
    5170:      	ldr	w9, [x9, #0x68]
    5174:      	tbnz	w9, #0x1f, 0x6534 <generic_kprobe_process_filter+0x22e4>
    5178:      	cmp	w8, #0x1b
    517c:      	b.hi	0x6534 <generic_kprobe_process_filter+0x22e4>
    5180:      	mov	w9, #0x1                // =1
    5184:      	lsl	w9, w9, w8
    5188:      	tst	w9, #0x60
    518c:      	b.ne	0x5384 <generic_kprobe_process_filter+0x1134>
    5190:      	mov	w10, #0x100             // =256
    5194:      	movk	w10, #0x400, lsl #16
    5198:      	tst	w9, w10
    519c:      	b.ne	0x5300 <generic_kprobe_process_filter+0x10b0>
    51a0:      	mov	w9, #0x1                // =1
    51a4:      	lsl	w8, w9, w8
    51a8:      	mov	w9, #0x200              // =512
    51ac:      	movk	w9, #0x800, lsl #16
    51b0:      	tst	w8, w9
    51b4:      	b.eq	0x6534 <generic_kprobe_process_filter+0x22e4>
    51b8:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    51bc:      	add	x1, x25, #0x4
    51c0:      	mov	w8, #0x1                // =1
    51c4:      	ldr	x0, [x0]
    51c8:      	blr	x8
    51cc:      	cbz	x0, 0x6534 <generic_kprobe_process_filter+0x22e4>
    51d0:      	ldr	x8, [sp, #0x48]
    51d4:      	mov	x20, x0
    51d8:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    51dc:      	mov	w9, #0x7f               // =127
    51e0:      	ldr	w8, [x8, #0x68]
    51e4:      	ldr	x0, [x0]
    51e8:      	add	x1, sp, #0xc0
    51ec:      	cmp	w8, #0x7f
    51f0:      	csel	w19, w8, w9, lt
    51f4:      	mov	w8, #0x1                // =1
    51f8:      	add	x9, sp, #0xc0
    51fc:      	blr	x8
    5200:      	cbz	x0, 0x6534 <generic_kprobe_process_filter+0x22e4>
    5204:      	sxtw	x1, w19
    5208:      	mov	x29, x0
    520c:      	lsl	w8, w1, #3
    5210:      	str	w8, [x0]
    5214:      	ldr	x8, [sp, #0x48]
    5218:      	ldr	w8, [x8, #0x6c]
    521c:      	cbnz	w8, 0x527c <generic_kprobe_process_filter+0x102c>
    5220:      	ldr	x11, [sp, #0x48]
    5224:      	and	w13, w1, #0x7f
    5228:      	mov	x8, xzr
    522c:      	ldr	w12, [x11, #0x68]
    5230:      	add	x9, x11, #0x1f0
    5234:      	add	x10, x11, #0x170
    5238:      	sub	w11, w12, w1
    523c:      	add	w12, w12, w13
    5240:      	add	w11, w11, w13
    5244:      	mvn	w13, w1
    5248:      	add	w12, w13, w12
    524c:      	cmp	x8, #0x7f
    5250:      	b.eq	0x5270 <generic_kprobe_process_filter+0x1020>
    5254:      	and	x13, x12, #0x7f
    5258:      	sub	w12, w12, #0x1
    525c:      	ldrb	w13, [x10, x13]
    5260:      	strb	w13, [x9, x8]
    5264:      	add	x8, x8, #0x1
    5268:      	cmp	x11, x8
    526c:      	b.ne	0x524c <generic_kprobe_process_filter+0xffc>
    5270:      	ldr	x9, [sp, #0x48]
    5274:      	mov	w8, #0x1                // =1
    5278:      	str	w8, [x9, #0x6c]
    527c:      	cmp	w1, #0x7f
    5280:      	b.hi	0x529c <generic_kprobe_process_filter+0x104c>
    5284:      	ldr	x8, [sp, #0x48]
    5288:      	add	x0, x29, #0x4
    528c:      	add	x2, x8, #0x1f0
    5290:      	mov	w8, #0x4                // =4
    5294:      	blr	x8
    5298:      	tbnz	x0, #0x3f, 0x6534 <generic_kprobe_process_filter+0x22e4>
    529c:      	mov	w8, #0x1                // =1
    52a0:      	mov	x0, x20
    52a4:      	b	0x537c <generic_kprobe_process_filter+0x112c>
    52a8:      	ldr	w8, [x24]
    52ac:      	str	w8, [x22, #0x10]
    52b0:      	ldr	x8, [x24, #0x8]
    52b4:      	str	x8, [x22, #0x18]
    52b8:      	ldrb	w8, [x29]
    52bc:      	cbnz	w8, 0x6570 <generic_kprobe_process_filter+0x2320>
    52c0:      	b	0x658c <generic_kprobe_process_filter+0x233c>
    52c4:      	mov	w8, #0x1                // =1
    52c8:      	strb	w8, [x29]
    52cc:      	ldr	w8, [x24]
    52d0:      	str	w8, [x22, #0x10]
    52d4:      	ldr	x8, [x24, #0x8]
    52d8:      	str	x8, [x22, #0x18]
    52dc:      	b	0x6570 <generic_kprobe_process_filter+0x2320>
    52e0:      	mov	w8, #0x2964             // =10596
    52e4:      	add	x20, x24, #0xff6
    52e8:      	strh	w8, [x24, #0xffe]
    52ec:      	adrp	x8, 0x5000 <generic_kprobe_process_filter+0xdb0>
    52f0:      	add	x8, x8, #0x0
    52f4:      	ldr	x8, [x8]
    52f8:      	str	x8, [x20]
    52fc:      	b	0x4994 <generic_kprobe_process_filter+0x744>
    5300:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5304:      	add	x1, x25, #0x4
    5308:      	mov	w8, #0x1                // =1
    530c:      	ldr	x0, [x0]
    5310:      	blr	x8
    5314:      	cbz	x0, 0x6534 <generic_kprobe_process_filter+0x22e4>
    5318:      	mov	x19, x0
    531c:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5320:      	mov	w8, #0x1                // =1
    5324:      	ldr	x0, [x0]
    5328:      	add	x9, sp, #0xc0
    532c:      	add	x1, sp, #0xc0
    5330:      	blr	x8
    5334:      	cbz	x0, 0x6534 <generic_kprobe_process_filter+0x22e4>
    5338:      	mov	w1, wzr
    533c:      	mov	w2, #0x104              // =260
    5340:      	mov	x29, x0
    5344:      	bl	0x5344 <generic_kprobe_process_filter+0x10f4>
    5348:      	ldr	x10, [sp, #0x48]
    534c:      	mov	x0, x29
    5350:      	ldr	w8, [x10, #0x68]
    5354:      	add	x2, x10, #0x70
    5358:      	lsl	w9, w8, #3
    535c:      	and	x8, x8, #0xff
    5360:      	str	w9, [x0], #0x4
    5364:      	mov	w9, #0x4                // =4
    5368:      	ldrb	w1, [x10, #0x68]
    536c:      	blr	x9
    5370:      	tbnz	x0, #0x3f, 0x6534 <generic_kprobe_process_filter+0x22e4>
    5374:      	mov	w8, #0x1                // =1
    5378:      	mov	x0, x19
    537c:      	mov	x1, x29
    5380:      	b	0x553c <generic_kprobe_process_filter+0x12ec>
    5384:      	str	wzr, [sp, #0xc8]
    5388:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    538c:      	mov	w8, #0x1                // =1
    5390:      	add	x9, sp, #0xc8
    5394:      	ldr	x0, [x0]
    5398:      	add	x1, sp, #0xc8
    539c:      	blr	x8
    53a0:      	cbz	x0, 0x54e8 <generic_kprobe_process_filter+0x1298>
    53a4:      	ldr	x9, [sp, #0x48]
    53a8:      	ldr	x8, [x0]
    53ac:      	ldr	x9, [x9, #0x378]
    53b0:      	cmp	x8, x9
    53b4:      	b.eq	0x54e8 <generic_kprobe_process_filter+0x1298>
    53b8:      	str	x0, [sp, #0x30]
    53bc:      	adrp	x8, 0x5000 <generic_kprobe_process_filter+0xdb0>
    53c0:      	ldr	x8, [x8]
    53c4:      	ldrb	w8, [x8]
    53c8:      	cbz	w8, 0x5454 <generic_kprobe_process_filter+0x1204>
    53cc:      	adrp	x19, 0x5000 <generic_kprobe_process_filter+0xdb0>
    53d0:      	mov	w20, #0x869f            // =34463
    53d4:      	mov	x22, xzr
    53d8:      	ldr	x19, [x19]
    53dc:      	movk	w20, #0x1, lsl #16
    53e0:      	b	0x53f8 <generic_kprobe_process_filter+0x11a8>
    53e4:      	cmp	x29, x22
    53e8:      	mov	x22, x29
    53ec:      	ccmp	w20, #0x0, #0x4, ne
    53f0:      	sub	w20, w20, #0x1
    53f4:      	b.eq	0x54d8 <generic_kprobe_process_filter+0x1288>
    53f8:      	ldr	x8, [sp, #0x48]
    53fc:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5400:      	add	x9, sp, #0x58
    5404:      	add	x1, sp, #0x58
    5408:      	ldr	w8, [x8, #0x10]
    540c:      	str	w8, [sp, #0x58]
    5410:      	mov	w8, #0x1                // =1
    5414:      	ldr	x0, [x0]
    5418:      	blr	x8
    541c:      	cbz	x0, 0x54d8 <generic_kprobe_process_filter+0x1288>
    5420:      	add	x1, x0, #0x70
    5424:      	mov	w8, #0x1                // =1
    5428:      	mov	x29, x0
    542c:      	mov	x0, x19
    5430:      	blr	x8
    5434:      	cbz	x0, 0x53e4 <generic_kprobe_process_filter+0x1194>
    5438:      	ldr	x8, [x0]
    543c:      	cbz	x8, 0x53e4 <generic_kprobe_process_filter+0x1194>
    5440:      	ldr	x10, [sp, #0x48]
    5444:      	ldr	x9, [x10, #0x370]
    5448:      	orr	x8, x9, x8
    544c:      	str	x8, [x10, #0x370]
    5450:      	b	0x53e4 <generic_kprobe_process_filter+0x1194>
    5454:      	adrp	x19, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5458:      	mov	x22, xzr
    545c:      	mov	w20, #0x3ff             // =1023
    5460:      	ldr	x19, [x19]
    5464:      	b	0x547c <generic_kprobe_process_filter+0x122c>
    5468:      	cmp	x29, x22
    546c:      	mov	x22, x29
    5470:      	ccmp	w20, #0x0, #0x4, ne
    5474:      	sub	w20, w20, #0x1
    5478:      	b.eq	0x54d8 <generic_kprobe_process_filter+0x1288>
    547c:      	ldr	x8, [sp, #0x48]
    5480:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5484:      	add	x9, sp, #0x58
    5488:      	add	x1, sp, #0x58
    548c:      	ldr	w8, [x8, #0x10]
    5490:      	str	w8, [sp, #0x58]
    5494:      	mov	w8, #0x1                // =1
    5498:      	ldr	x0, [x0]
    549c:      	blr	x8
    54a0:      	cbz	x0, 0x54d8 <generic_kprobe_process_filter+0x1288>
    54a4:      	add	x1, x0, #0x70
    54a8:      	mov	w8, #0x1                // =1
    54ac:      	mov	x29, x0
    54b0:      	mov	x0, x19
    54b4:      	blr	x8
    54b8:      	cbz	x0, 0x5468 <generic_kprobe_process_filter+0x1218>
    54bc:      	ldr	x8, [x0]
    54c0:      	cbz	x8, 0x5468 <generic_kprobe_process_filter+0x1218>
    54c4:      	ldr	x10, [sp, #0x48]
    54c8:      	ldr	x9, [x10, #0x370]
    54cc:      	orr	x8, x9, x8
    54d0:      	str	x8, [x10, #0x370]
    54d4:      	b	0x5468 <generic_kprobe_process_filter+0x1218>
    54d8:      	ldr	x8, [sp, #0x30]
    54dc:      	ldr	x9, [sp, #0x48]
    54e0:      	ldr	x8, [x8]
    54e4:      	str	x8, [x9, #0x378]
    54e8:      	ldr	w8, [x25, #0x8]
    54ec:      	cmn	w8, #0x1
    54f0:      	b.eq	0x5514 <generic_kprobe_process_filter+0x12c4>
    54f4:      	ldr	x9, [sp, #0x48]
    54f8:      	ldr	x9, [x9, #0x370]
    54fc:      	lsr	x8, x9, x8
    5500:      	tbz	w8, #0x0, 0x5514 <generic_kprobe_process_filter+0x12c4>
    5504:      	mov	x0, #0xffee             // =65518
    5508:      	movk	x0, #0xadc0, lsl #16
    550c:      	movk	x0, #0xb, lsl #32
    5510:      	b	0x5540 <generic_kprobe_process_filter+0x12f0>
    5514:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5518:      	mov	w8, #0x1                // =1
    551c:      	add	x9, sp, #0xd8
    5520:      	ldr	x0, [x0]
    5524:      	add	x1, sp, #0xd8
    5528:      	blr	x8
    552c:      	cbz	x0, 0x6534 <generic_kprobe_process_filter+0x22e4>
    5530:      	ldr	x8, [sp, #0x48]
    5534:      	add	x1, x8, #0x70
    5538:      	mov	w8, #0x1                // =1
    553c:      	blr	x8
    5540:      	ldr	w8, [x25]
    5544:      	cmp	w8, #0x25
    5548:      	b.hi	0x5570 <generic_kprobe_process_filter+0x1320>
    554c:      	mov	w9, #0x1                // =1
    5550:      	lsl	x8, x9, x8
    5554:      	mov	x9, #0x50               // =80
    5558:      	movk	x9, #0xc00, lsl #16
    555c:      	movk	x9, #0x20, lsl #32
    5560:      	tst	x8, x9
    5564:      	b.eq	0x5570 <generic_kprobe_process_filter+0x1320>
    5568:      	cbnz	x0, 0x6534 <generic_kprobe_process_filter+0x22e4>
    556c:      	b	0x5574 <generic_kprobe_process_filter+0x1324>
    5570:      	cbz	x0, 0x6534 <generic_kprobe_process_filter+0x22e4>
    5574:      	adrp	x8, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5578:      	ldr	x8, [x8]
    557c:      	ldrb	w8, [x8]
    5580:      	cbz	w8, 0x594c <generic_kprobe_process_filter+0x16fc>
    5584:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5588:      	mov	w8, #0x1                // =1
    558c:      	ldr	x0, [x0]
    5590:      	ldr	x1, [sp, #0x48]
    5594:      	blr	x8
    5598:      	cbz	x0, 0x594c <generic_kprobe_process_filter+0x16fc>
    559c:      	add	w8, w21, #0x5
    55a0:      	str	wzr, [sp, #0xc0]
    55a4:      	add	x9, sp, #0xd8
    55a8:      	mov	x25, x0
    55ac:      	str	w8, [sp, #0xd8]
    55b0:      	mov	w8, #0x1                // =1
    55b4:      	add	x1, sp, #0xd8
    55b8:      	mov	x0, x24
    55bc:      	blr	x8
    55c0:      	cbz	x0, 0x594c <generic_kprobe_process_filter+0x16fc>
    55c4:      	ldr	w8, [x0]
    55c8:      	mov	x24, x0
    55cc:      	cbz	w8, 0x594c <generic_kprobe_process_filter+0x16fc>
    55d0:      	ldr	w9, [x25]
    55d4:      	tbnz	w9, #0x1f, 0x6534 <generic_kprobe_process_filter+0x22e4>
    55d8:      	cmp	w8, #0x1b
    55dc:      	b.hi	0x6534 <generic_kprobe_process_filter+0x22e4>
    55e0:      	mov	w9, #0x1                // =1
    55e4:      	lsl	w9, w9, w8
    55e8:      	tst	w9, #0x60
    55ec:      	b.ne	0x5774 <generic_kprobe_process_filter+0x1524>
    55f0:      	mov	w10, #0x100             // =256
    55f4:      	movk	w10, #0x400, lsl #16
    55f8:      	tst	w9, w10
    55fc:      	b.ne	0x56f4 <generic_kprobe_process_filter+0x14a4>
    5600:      	mov	w9, #0x1                // =1
    5604:      	lsl	w8, w9, w8
    5608:      	mov	w9, #0x200              // =512
    560c:      	movk	w9, #0x800, lsl #16
    5610:      	tst	w8, w9
    5614:      	b.eq	0x6534 <generic_kprobe_process_filter+0x22e4>
    5618:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    561c:      	add	x1, x24, #0x4
    5620:      	mov	w8, #0x1                // =1
    5624:      	ldr	x0, [x0]
    5628:      	blr	x8
    562c:      	cbz	x0, 0x6534 <generic_kprobe_process_filter+0x22e4>
    5630:      	ldr	w8, [x25]
    5634:      	mov	x20, x0
    5638:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    563c:      	mov	w9, #0x7f               // =127
    5640:      	ldr	x0, [x0]
    5644:      	add	x1, sp, #0xc0
    5648:      	cmp	w8, #0x7f
    564c:      	csel	w19, w8, w9, lt
    5650:      	mov	w8, #0x1                // =1
    5654:      	add	x9, sp, #0xc0
    5658:      	blr	x8
    565c:      	cbz	x0, 0x6534 <generic_kprobe_process_filter+0x22e4>
    5660:      	sxtw	x1, w19
    5664:      	mov	x29, x0
    5668:      	lsl	w8, w1, #3
    566c:      	str	w8, [x0]
    5670:      	ldr	w8, [x25, #0x4]
    5674:      	cbnz	w8, 0x56cc <generic_kprobe_process_filter+0x147c>
    5678:      	ldr	w12, [x25]
    567c:      	and	w13, w1, #0x7f
    5680:      	mov	x8, xzr
    5684:      	add	x9, x25, #0x188
    5688:      	add	x10, x25, #0x108
    568c:      	sub	w11, w12, w1
    5690:      	add	w12, w12, w13
    5694:      	add	w11, w11, w13
    5698:      	mvn	w13, w1
    569c:      	add	w12, w13, w12
    56a0:      	cmp	x8, #0x7f
    56a4:      	b.eq	0x56c4 <generic_kprobe_process_filter+0x1474>
    56a8:      	and	x13, x12, #0x7f
    56ac:      	sub	w12, w12, #0x1
    56b0:      	ldrb	w13, [x10, x13]
    56b4:      	strb	w13, [x9, x8]
    56b8:      	add	x8, x8, #0x1
    56bc:      	cmp	x11, x8
    56c0:      	b.ne	0x56a0 <generic_kprobe_process_filter+0x1450>
    56c4:      	mov	w8, #0x1                // =1
    56c8:      	str	w8, [x25, #0x4]
    56cc:      	cmp	w1, #0x7f
    56d0:      	b.hi	0x56e8 <generic_kprobe_process_filter+0x1498>
    56d4:      	add	x0, x29, #0x4
    56d8:      	add	x2, x25, #0x188
    56dc:      	mov	w8, #0x4                // =4
    56e0:      	blr	x8
    56e4:      	tbnz	x0, #0x3f, 0x6534 <generic_kprobe_process_filter+0x22e4>
    56e8:      	mov	w8, #0x1                // =1
    56ec:      	mov	x0, x20
    56f0:      	b	0x576c <generic_kprobe_process_filter+0x151c>
    56f4:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    56f8:      	add	x1, x24, #0x4
    56fc:      	mov	w8, #0x1                // =1
    5700:      	ldr	x0, [x0]
    5704:      	blr	x8
    5708:      	cbz	x0, 0x6534 <generic_kprobe_process_filter+0x22e4>
    570c:      	mov	x19, x0
    5710:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5714:      	mov	w8, #0x1                // =1
    5718:      	ldr	x0, [x0]
    571c:      	add	x9, sp, #0xc0
    5720:      	add	x1, sp, #0xc0
    5724:      	blr	x8
    5728:      	cbz	x0, 0x6534 <generic_kprobe_process_filter+0x22e4>
    572c:      	mov	w1, wzr
    5730:      	mov	w2, #0x104              // =260
    5734:      	mov	x29, x0
    5738:      	bl	0x5738 <generic_kprobe_process_filter+0x14e8>
    573c:      	ldr	w8, [x25]
    5740:      	mov	x0, x29
    5744:      	add	x2, x25, #0x8
    5748:      	lsl	w9, w8, #3
    574c:      	and	x8, x8, #0xff
    5750:      	str	w9, [x0], #0x4
    5754:      	mov	w9, #0x4                // =4
    5758:      	ldrb	w1, [x25]
    575c:      	blr	x9
    5760:      	tbnz	x0, #0x3f, 0x6534 <generic_kprobe_process_filter+0x22e4>
    5764:      	mov	w8, #0x1                // =1
    5768:      	mov	x0, x19
    576c:      	mov	x1, x29
    5770:      	b	0x5914 <generic_kprobe_process_filter+0x16c4>
    5774:      	str	wzr, [sp, #0xc8]
    5778:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    577c:      	mov	w8, #0x1                // =1
    5780:      	add	x9, sp, #0xc8
    5784:      	ldr	x0, [x0]
    5788:      	add	x1, sp, #0xc8
    578c:      	blr	x8
    5790:      	cbz	x0, 0x58c8 <generic_kprobe_process_filter+0x1678>
    5794:      	ldr	x8, [x0]
    5798:      	ldr	x9, [x25, #0x310]
    579c:      	cmp	x8, x9
    57a0:      	b.eq	0x58c8 <generic_kprobe_process_filter+0x1678>
    57a4:      	str	x0, [sp, #0x30]
    57a8:      	adrp	x8, 0x5000 <generic_kprobe_process_filter+0xdb0>
    57ac:      	ldr	x8, [x8]
    57b0:      	ldrb	w8, [x8]
    57b4:      	cbz	w8, 0x583c <generic_kprobe_process_filter+0x15ec>
    57b8:      	adrp	x19, 0x5000 <generic_kprobe_process_filter+0xdb0>
    57bc:      	mov	w20, #0x869f            // =34463
    57c0:      	mov	x22, xzr
    57c4:      	ldr	x19, [x19]
    57c8:      	movk	w20, #0x1, lsl #16
    57cc:      	b	0x57e4 <generic_kprobe_process_filter+0x1594>
    57d0:      	cmp	x29, x22
    57d4:      	mov	x22, x29
    57d8:      	ccmp	w20, #0x0, #0x4, ne
    57dc:      	sub	w20, w20, #0x1
    57e0:      	b.eq	0x58bc <generic_kprobe_process_filter+0x166c>
    57e4:      	ldr	x8, [sp, #0x48]
    57e8:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    57ec:      	add	x9, sp, #0x58
    57f0:      	add	x1, sp, #0x58
    57f4:      	ldr	w8, [x8, #0x10]
    57f8:      	str	w8, [sp, #0x58]
    57fc:      	mov	w8, #0x1                // =1
    5800:      	ldr	x0, [x0]
    5804:      	blr	x8
    5808:      	cbz	x0, 0x58bc <generic_kprobe_process_filter+0x166c>
    580c:      	add	x1, x0, #0x70
    5810:      	mov	w8, #0x1                // =1
    5814:      	mov	x29, x0
    5818:      	mov	x0, x19
    581c:      	blr	x8
    5820:      	cbz	x0, 0x57d0 <generic_kprobe_process_filter+0x1580>
    5824:      	ldr	x8, [x0]
    5828:      	cbz	x8, 0x57d0 <generic_kprobe_process_filter+0x1580>
    582c:      	ldr	x9, [x25, #0x308]
    5830:      	orr	x8, x9, x8
    5834:      	str	x8, [x25, #0x308]
    5838:      	b	0x57d0 <generic_kprobe_process_filter+0x1580>
    583c:      	adrp	x19, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5840:      	mov	x22, xzr
    5844:      	mov	w20, #0x3ff             // =1023
    5848:      	ldr	x19, [x19]
    584c:      	b	0x5864 <generic_kprobe_process_filter+0x1614>
    5850:      	cmp	x29, x22
    5854:      	mov	x22, x29
    5858:      	ccmp	w20, #0x0, #0x4, ne
    585c:      	sub	w20, w20, #0x1
    5860:      	b.eq	0x58bc <generic_kprobe_process_filter+0x166c>
    5864:      	ldr	x8, [sp, #0x48]
    5868:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    586c:      	add	x9, sp, #0x58
    5870:      	add	x1, sp, #0x58
    5874:      	ldr	w8, [x8, #0x10]
    5878:      	str	w8, [sp, #0x58]
    587c:      	mov	w8, #0x1                // =1
    5880:      	ldr	x0, [x0]
    5884:      	blr	x8
    5888:      	cbz	x0, 0x58bc <generic_kprobe_process_filter+0x166c>
    588c:      	add	x1, x0, #0x70
    5890:      	mov	w8, #0x1                // =1
    5894:      	mov	x29, x0
    5898:      	mov	x0, x19
    589c:      	blr	x8
    58a0:      	cbz	x0, 0x5850 <generic_kprobe_process_filter+0x1600>
    58a4:      	ldr	x8, [x0]
    58a8:      	cbz	x8, 0x5850 <generic_kprobe_process_filter+0x1600>
    58ac:      	ldr	x9, [x25, #0x308]
    58b0:      	orr	x8, x9, x8
    58b4:      	str	x8, [x25, #0x308]
    58b8:      	b	0x5850 <generic_kprobe_process_filter+0x1600>
    58bc:      	ldr	x8, [sp, #0x30]
    58c0:      	ldr	x8, [x8]
    58c4:      	str	x8, [x25, #0x310]
    58c8:      	ldr	w8, [x24, #0x8]
    58cc:      	cmn	w8, #0x1
    58d0:      	b.eq	0x58f0 <generic_kprobe_process_filter+0x16a0>
    58d4:      	ldr	x9, [x25, #0x308]
    58d8:      	lsr	x8, x9, x8
    58dc:      	tbz	w8, #0x0, 0x58f0 <generic_kprobe_process_filter+0x16a0>
    58e0:      	mov	x0, #0xffee             // =65518
    58e4:      	movk	x0, #0xadc0, lsl #16
    58e8:      	movk	x0, #0xb, lsl #32
    58ec:      	b	0x5918 <generic_kprobe_process_filter+0x16c8>
    58f0:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    58f4:      	mov	w8, #0x1                // =1
    58f8:      	add	x9, sp, #0xd8
    58fc:      	ldr	x0, [x0]
    5900:      	add	x1, sp, #0xd8
    5904:      	blr	x8
    5908:      	cbz	x0, 0x6534 <generic_kprobe_process_filter+0x22e4>
    590c:      	add	x1, x25, #0x8
    5910:      	mov	w8, #0x1                // =1
    5914:      	blr	x8
    5918:      	ldr	w8, [x24]
    591c:      	cmp	w8, #0x25
    5920:      	b.hi	0x5948 <generic_kprobe_process_filter+0x16f8>
    5924:      	mov	w9, #0x1                // =1
    5928:      	lsl	x8, x9, x8
    592c:      	mov	x9, #0x50               // =80
    5930:      	movk	x9, #0xc00, lsl #16
    5934:      	movk	x9, #0x20, lsl #32
    5938:      	tst	x8, x9
    593c:      	b.eq	0x5948 <generic_kprobe_process_filter+0x16f8>
    5940:      	cbnz	x0, 0x6534 <generic_kprobe_process_filter+0x22e4>
    5944:      	b	0x594c <generic_kprobe_process_filter+0x16fc>
    5948:      	cbz	x0, 0x6534 <generic_kprobe_process_filter+0x22e4>
    594c:      	lsl	w8, w21, #2
    5950:      	add	x9, x8, #0x4
    5954:      	ldr	w8, [x9, x23]
    5958:      	add	w9, w8, w9
    595c:      	and	w11, w9, #0x3ff
    5960:      	add	w9, w9, #0x4
    5964:      	and	x9, x9, #0x3ff
    5968:      	add	x10, x11, #0x8
    596c:      	ldr	w9, [x9, x23]
    5970:      	cmp	w9, #0x5
    5974:      	b.lo	0x5a04 <generic_kprobe_process_filter+0x17b4>
    5978:      	add	x9, x10, x23
    597c:      	ldr	w10, [x9, #0x8]
    5980:      	ldp	w12, w22, [x9]
    5984:      	stp	x9, x11, [sp, #0x8]
    5988:      	mov	w9, #0x4                // =4
    598c:      	cmp	w10, #0x4
    5990:      	stp	xzr, xzr, [sp, #0x58]
    5994:      	csel	w9, w10, w9, lo
    5998:      	cmp	w12, #0x6
    599c:      	b.ne	0x59a8 <generic_kprobe_process_filter+0x1758>
    59a0:      	mov	x11, #0x100000001       // =4294967297
    59a4:      	stp	x11, x11, [sp, #0x58]
    59a8:      	cbz	w10, 0x5e0c <generic_kprobe_process_filter+0x1bbc>
    59ac:      	ldr	x10, [sp, #0x48]
    59b0:      	add	w8, w8, w21, lsl #2
    59b4:      	tst	x22, #0x1
    59b8:      	add	x25, sp, #0x58
    59bc:      	str	w12, [sp, #0x30]
    59c0:      	add	w8, w8, #0x4
    59c4:      	and	x8, x8, #0x3ff
    59c8:      	add	x21, x8, #0x14
    59cc:      	sub	x8, x9, #0x1
    59d0:      	mov	w9, #0x3                // =3
    59d4:      	add	x11, x10, #0x24
    59d8:      	str	x11, [sp, #0x20]
    59dc:      	csel	x11, x10, x11, eq
    59e0:      	cmp	x8, #0x3
    59e4:      	add	x10, x10, #0x10
    59e8:      	csel	x8, x8, x9, lo
    59ec:      	and	x9, x21, #0x7fc
    59f0:      	mov	x20, x11
    59f4:      	str	x10, [sp, #0x18]
    59f8:      	add	x19, x23, x9
    59fc:      	add	x24, x8, #0x1
    5a00:      	b	0x5a3c <generic_kprobe_process_filter+0x17ec>
    5a04:      	mov	w9, #0x1                // =1
    5a08:      	mov	w8, w10
    5a0c:      	b	0x5e54 <generic_kprobe_process_filter+0x1c04>
    5a10:      	mov	w8, #0x1                // =1
    5a14:      	ldr	w12, [sp, #0x30]
    5a18:      	mov	x11, x20
    5a1c:      	cmp	w12, #0x6
    5a20:      	eor	w8, w8, #0x1
    5a24:      	csinc	w9, w8, wzr, eq
    5a28:      	str	w9, [x25], #0x4
    5a2c:      	add	x21, x21, #0x4
    5a30:      	add	x19, x19, #0x4
    5a34:      	subs	x24, x24, #0x1
    5a38:      	b.eq	0x5e0c <generic_kprobe_process_filter+0x1bbc>
    5a3c:      	cmp	x21, #0x3e8
    5a40:      	b.ls	0x5c64 <generic_kprobe_process_filter+0x1a14>
    5a44:      	mov	x29, xzr
    5a48:      	tbz	w22, #0x1, 0x5c6c <generic_kprobe_process_filter+0x1a1c>
    5a4c:      	tbnz	w22, #0x0, 0x5c98 <generic_kprobe_process_filter+0x1a48>
    5a50:      	ldr	x10, [sp, #0x48]
    5a54:      	mov	w8, #0x1                // =1
    5a58:      	ldr	w9, [x10]
    5a5c:      	cmp	x29, x9
    5a60:      	b.eq	0x5a1c <generic_kprobe_process_filter+0x17cc>
    5a64:      	ldr	w9, [x10, #0x10]
    5a68:      	cmp	x29, x9
    5a6c:      	b.eq	0x5a1c <generic_kprobe_process_filter+0x17cc>
    5a70:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5a74:      	mov	w8, #0x1                // =1
    5a78:      	ldr	x0, [x0]
    5a7c:      	ldr	x1, [sp, #0x18]
    5a80:      	blr	x8
    5a84:      	cbz	x0, 0x5df0 <generic_kprobe_process_filter+0x1ba0>
    5a88:      	ldr	w9, [x0]
    5a8c:      	mov	x1, x0
    5a90:      	mov	w8, #0x1                // =1
    5a94:      	cmp	x29, x9
    5a98:      	b.eq	0x5a14 <generic_kprobe_process_filter+0x17c4>
    5a9c:      	ldr	w9, [x1, #0x10]!
    5aa0:      	ldr	w12, [sp, #0x30]
    5aa4:      	mov	x11, x20
    5aa8:      	cmp	x29, x9
    5aac:      	b.eq	0x5a1c <generic_kprobe_process_filter+0x17cc>
    5ab0:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5ab4:      	mov	w8, #0x1                // =1
    5ab8:      	ldr	x0, [x0]
    5abc:      	blr	x8
    5ac0:      	cbz	x0, 0x5df0 <generic_kprobe_process_filter+0x1ba0>
    5ac4:      	ldr	w9, [x0]
    5ac8:      	mov	x1, x0
    5acc:      	mov	w8, #0x1                // =1
    5ad0:      	cmp	x29, x9
    5ad4:      	b.eq	0x5a14 <generic_kprobe_process_filter+0x17c4>
    5ad8:      	ldr	w9, [x1, #0x10]!
    5adc:      	ldr	w12, [sp, #0x30]
    5ae0:      	mov	x11, x20
    5ae4:      	cmp	x29, x9
    5ae8:      	b.eq	0x5a1c <generic_kprobe_process_filter+0x17cc>
    5aec:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5af0:      	mov	w8, #0x1                // =1
    5af4:      	ldr	x0, [x0]
    5af8:      	blr	x8
    5afc:      	cbz	x0, 0x5df0 <generic_kprobe_process_filter+0x1ba0>
    5b00:      	ldr	w9, [x0]
    5b04:      	mov	x1, x0
    5b08:      	mov	w8, #0x1                // =1
    5b0c:      	cmp	x29, x9
    5b10:      	b.eq	0x5a14 <generic_kprobe_process_filter+0x17c4>
    5b14:      	ldr	w9, [x1, #0x10]!
    5b18:      	ldr	w12, [sp, #0x30]
    5b1c:      	mov	x11, x20
    5b20:      	cmp	x29, x9
    5b24:      	b.eq	0x5a1c <generic_kprobe_process_filter+0x17cc>
    5b28:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5b2c:      	mov	w8, #0x1                // =1
    5b30:      	ldr	x0, [x0]
    5b34:      	blr	x8
    5b38:      	cbz	x0, 0x5df0 <generic_kprobe_process_filter+0x1ba0>
    5b3c:      	ldr	w9, [x0]
    5b40:      	mov	x1, x0
    5b44:      	mov	w8, #0x1                // =1
    5b48:      	cmp	x29, x9
    5b4c:      	b.eq	0x5a14 <generic_kprobe_process_filter+0x17c4>
    5b50:      	ldr	w9, [x1, #0x10]!
    5b54:      	ldr	w12, [sp, #0x30]
    5b58:      	mov	x11, x20
    5b5c:      	cmp	x29, x9
    5b60:      	b.eq	0x5a1c <generic_kprobe_process_filter+0x17cc>
    5b64:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5b68:      	mov	w8, #0x1                // =1
    5b6c:      	ldr	x0, [x0]
    5b70:      	blr	x8
    5b74:      	cbz	x0, 0x5df0 <generic_kprobe_process_filter+0x1ba0>
    5b78:      	ldr	w9, [x0]
    5b7c:      	mov	x1, x0
    5b80:      	mov	w8, #0x1                // =1
    5b84:      	cmp	x29, x9
    5b88:      	b.eq	0x5a14 <generic_kprobe_process_filter+0x17c4>
    5b8c:      	ldr	w9, [x1, #0x10]!
    5b90:      	ldr	w12, [sp, #0x30]
    5b94:      	mov	x11, x20
    5b98:      	cmp	x29, x9
    5b9c:      	b.eq	0x5a1c <generic_kprobe_process_filter+0x17cc>
    5ba0:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5ba4:      	mov	w8, #0x1                // =1
    5ba8:      	ldr	x0, [x0]
    5bac:      	blr	x8
    5bb0:      	cbz	x0, 0x5df0 <generic_kprobe_process_filter+0x1ba0>
    5bb4:      	ldr	w9, [x0]
    5bb8:      	mov	x1, x0
    5bbc:      	mov	w8, #0x1                // =1
    5bc0:      	cmp	x29, x9
    5bc4:      	b.eq	0x5a14 <generic_kprobe_process_filter+0x17c4>
    5bc8:      	ldr	w9, [x1, #0x10]!
    5bcc:      	ldr	w12, [sp, #0x30]
    5bd0:      	mov	x11, x20
    5bd4:      	cmp	x29, x9
    5bd8:      	b.eq	0x5a1c <generic_kprobe_process_filter+0x17cc>
    5bdc:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5be0:      	mov	w8, #0x1                // =1
    5be4:      	ldr	x0, [x0]
    5be8:      	blr	x8
    5bec:      	cbz	x0, 0x5df0 <generic_kprobe_process_filter+0x1ba0>
    5bf0:      	ldr	w9, [x0]
    5bf4:      	mov	x1, x0
    5bf8:      	mov	w8, #0x1                // =1
    5bfc:      	cmp	x29, x9
    5c00:      	b.eq	0x5a14 <generic_kprobe_process_filter+0x17c4>
    5c04:      	ldr	w9, [x1, #0x10]!
    5c08:      	ldr	w12, [sp, #0x30]
    5c0c:      	mov	x11, x20
    5c10:      	cmp	x29, x9
    5c14:      	b.eq	0x5a1c <generic_kprobe_process_filter+0x17cc>
    5c18:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5c1c:      	mov	w8, #0x1                // =1
    5c20:      	ldr	x0, [x0]
    5c24:      	blr	x8
    5c28:      	cbz	x0, 0x5df0 <generic_kprobe_process_filter+0x1ba0>
    5c2c:      	ldr	w9, [x0]
    5c30:      	mov	x1, x0
    5c34:      	mov	w8, #0x1                // =1
    5c38:      	cmp	x29, x9
    5c3c:      	b.eq	0x5a14 <generic_kprobe_process_filter+0x17c4>
    5c40:      	ldr	w9, [x1, #0x10]!
    5c44:      	ldr	w12, [sp, #0x30]
    5c48:      	mov	x11, x20
    5c4c:      	cmp	x29, x9
    5c50:      	b.eq	0x5a1c <generic_kprobe_process_filter+0x17cc>
    5c54:      	adrp	x9, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5c58:      	mov	w8, #0x1                // =1
    5c5c:      	ldr	x9, [x9]
    5c60:      	b	0x5de4 <generic_kprobe_process_filter+0x1b94>
    5c64:      	ldr	w29, [x19]
    5c68:      	tbnz	w22, #0x1, 0x5a4c <generic_kprobe_process_filter+0x17fc>
    5c6c:      	ldr	w8, [x11]
    5c70:      	cmp	w12, #0x5
    5c74:      	b.ne	0x5c88 <generic_kprobe_process_filter+0x1a38>
    5c78:      	cmp	x29, x8
    5c7c:      	b.eq	0x5c88 <generic_kprobe_process_filter+0x1a38>
    5c80:      	mov	w9, wzr
    5c84:      	b	0x5a28 <generic_kprobe_process_filter+0x17d8>
    5c88:      	cmp	w12, #0x6
    5c8c:      	ccmp	x29, x8, #0x0, eq
    5c90:      	cset	w9, ne
    5c94:      	b	0x5a28 <generic_kprobe_process_filter+0x17d8>
    5c98:      	ldr	x8, [sp, #0x20]
    5c9c:      	ldr	w9, [x8]
    5ca0:      	cbz	w9, 0x5a28 <generic_kprobe_process_filter+0x17d8>
    5ca4:      	mov	w8, #0x1                // =1
    5ca8:      	cbz	x29, 0x5a1c <generic_kprobe_process_filter+0x17cc>
    5cac:      	cmp	x29, x9
    5cb0:      	b.eq	0x5a1c <generic_kprobe_process_filter+0x17cc>
    5cb4:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5cb8:      	mov	w8, #0x1                // =1
    5cbc:      	ldr	x0, [x0]
    5cc0:      	ldr	x1, [sp, #0x18]
    5cc4:      	blr	x8
    5cc8:      	cbz	x0, 0x5df0 <generic_kprobe_process_filter+0x1ba0>
    5ccc:      	ldr	w8, [x0, #0x24]
    5cd0:      	cmp	x29, x8
    5cd4:      	b.eq	0x5a10 <generic_kprobe_process_filter+0x17c0>
    5cd8:      	add	x1, x0, #0x10
    5cdc:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5ce0:      	mov	w8, #0x1                // =1
    5ce4:      	ldr	x0, [x0]
    5ce8:      	blr	x8
    5cec:      	cbz	x0, 0x5df0 <generic_kprobe_process_filter+0x1ba0>
    5cf0:      	ldr	w8, [x0, #0x24]
    5cf4:      	cmp	x29, x8
    5cf8:      	b.eq	0x5a10 <generic_kprobe_process_filter+0x17c0>
    5cfc:      	add	x1, x0, #0x10
    5d00:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5d04:      	mov	w8, #0x1                // =1
    5d08:      	ldr	x0, [x0]
    5d0c:      	blr	x8
    5d10:      	cbz	x0, 0x5df0 <generic_kprobe_process_filter+0x1ba0>
    5d14:      	ldr	w8, [x0, #0x24]
    5d18:      	cmp	x29, x8
    5d1c:      	b.eq	0x5a10 <generic_kprobe_process_filter+0x17c0>
    5d20:      	add	x1, x0, #0x10
    5d24:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5d28:      	mov	w8, #0x1                // =1
    5d2c:      	ldr	x0, [x0]
    5d30:      	blr	x8
    5d34:      	cbz	x0, 0x5df0 <generic_kprobe_process_filter+0x1ba0>
    5d38:      	ldr	w8, [x0, #0x24]
    5d3c:      	cmp	x29, x8
    5d40:      	b.eq	0x5a10 <generic_kprobe_process_filter+0x17c0>
    5d44:      	add	x1, x0, #0x10
    5d48:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5d4c:      	mov	w8, #0x1                // =1
    5d50:      	ldr	x0, [x0]
    5d54:      	blr	x8
    5d58:      	cbz	x0, 0x5df0 <generic_kprobe_process_filter+0x1ba0>
    5d5c:      	ldr	w8, [x0, #0x24]
    5d60:      	cmp	x29, x8
    5d64:      	b.eq	0x5a10 <generic_kprobe_process_filter+0x17c0>
    5d68:      	add	x1, x0, #0x10
    5d6c:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5d70:      	mov	w8, #0x1                // =1
    5d74:      	ldr	x0, [x0]
    5d78:      	blr	x8
    5d7c:      	cbz	x0, 0x5df0 <generic_kprobe_process_filter+0x1ba0>
    5d80:      	ldr	w8, [x0, #0x24]
    5d84:      	cmp	x29, x8
    5d88:      	b.eq	0x5a10 <generic_kprobe_process_filter+0x17c0>
    5d8c:      	add	x1, x0, #0x10
    5d90:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5d94:      	mov	w8, #0x1                // =1
    5d98:      	ldr	x0, [x0]
    5d9c:      	blr	x8
    5da0:      	cbz	x0, 0x5df0 <generic_kprobe_process_filter+0x1ba0>
    5da4:      	ldr	w8, [x0, #0x24]
    5da8:      	cmp	x29, x8
    5dac:      	b.eq	0x5a10 <generic_kprobe_process_filter+0x17c0>
    5db0:      	add	x1, x0, #0x10
    5db4:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5db8:      	mov	w8, #0x1                // =1
    5dbc:      	ldr	x0, [x0]
    5dc0:      	blr	x8
    5dc4:      	cbz	x0, 0x5df0 <generic_kprobe_process_filter+0x1ba0>
    5dc8:      	ldr	w8, [x0, #0x24]
    5dcc:      	cmp	x29, x8
    5dd0:      	b.eq	0x5a10 <generic_kprobe_process_filter+0x17c0>
    5dd4:      	adrp	x9, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5dd8:      	add	x1, x0, #0x10
    5ddc:      	mov	w8, #0x1                // =1
    5de0:      	ldr	x9, [x9]
    5de4:      	adrp	x0, 0x5000 <generic_kprobe_process_filter+0xdb0>
    5de8:      	ldr	x0, [x0]
    5dec:      	blr	x8
    5df0:      	ldr	w12, [sp, #0x30]
    5df4:      	mov	w8, wzr
    5df8:      	mov	w9, wzr
    5dfc:      	mov	x11, x20
    5e00:      	cmp	w12, #0x5
    5e04:      	b.ne	0x5a1c <generic_kprobe_process_filter+0x17cc>
    5e08:      	b	0x5a28 <generic_kprobe_process_filter+0x17d8>
    5e0c:      	ldp	w8, w9, [sp, #0x58]
    5e10:      	ldp	w10, w11, [sp, #0x60]
    5e14:      	cmp	w12, #0x6
    5e18:      	b.ne	0x5e2c <generic_kprobe_process_filter+0x1bdc>
    5e1c:      	and	w8, w9, w8
    5e20:      	and	w9, w10, w11
    5e24:      	and	w9, w8, w9
    5e28:      	b	0x5e38 <generic_kprobe_process_filter+0x1be8>
    5e2c:      	orr	w8, w9, w8
    5e30:      	orr	w9, w10, w11
    5e34:      	orr	w9, w8, w9
    5e38:      	ldr	x8, [sp, #0x10]
    5e3c:      	cbz	w9, 0x6534 <generic_kprobe_process_filter+0x22e4>
    5e40:      	ldr	x10, [sp, #0x8]
    5e44:      	add	w8, w8, #0x14
    5e48:      	ldr	w10, [x10, #0x8]
    5e4c:      	ubfiz	w10, w10, #2, #3
    5e50:      	add	w8, w10, w8
    5e54:      	and	x10, x8, #0x3ff
    5e58:      	add	w8, w8, #0x4
    5e5c:      	mov	w19, #0xa               // =10
    5e60:      	ldr	w10, [x10, x23]
    5e64:      	mov	w20, #0x4               // =4
    5e68:      	mov	x25, #0x100000001       // =4294967297
    5e6c:      	sub	w22, w10, #0x4
    5e70:      	ldr	x10, [sp, #0xe8]
    5e74:      	add	x10, x10, #0x20
    5e78:      	str	x10, [sp, #0x30]
    5e7c:      	b	0x5e88 <generic_kprobe_process_filter+0x1c38>
    5e80:      	subs	x19, x19, #0x1
    5e84:      	b.eq	0x6054 <generic_kprobe_process_filter+0x1e04>
    5e88:      	cbz	w22, 0x5e80 <generic_kprobe_process_filter+0x1c30>
    5e8c:      	and	x9, x8, #0x3ff
    5e90:      	add	x10, x9, x23
    5e94:      	ldr	w29, [x10, #0x8]
    5e98:      	ldp	w9, w24, [x10]
    5e9c:      	stp	xzr, xzr, [sp, #0x58]
    5ea0:      	cmp	w29, #0x4
    5ea4:      	csel	w10, w29, w20, lo
    5ea8:      	cmp	w24, #0x6
    5eac:      	b.ne	0x5eb4 <generic_kprobe_process_filter+0x1c64>
    5eb0:      	stp	x25, x25, [sp, #0x58]
    5eb4:      	add	w21, w8, #0xc
    5eb8:      	cbz	w29, 0x600c <generic_kprobe_process_filter+0x1dbc>
    5ebc:      	and	x9, x9, #0xf
    5ec0:      	cmp	w9, #0xa
    5ec4:      	b.lo	0x5ef0 <generic_kprobe_process_filter+0x1ca0>
    5ec8:      	sub	x8, x10, #0x1
    5ecc:      	mov	w9, #0x3                // =3
    5ed0:      	add	x0, sp, #0x58
    5ed4:      	mov	w1, wzr
    5ed8:      	cmp	x8, #0x3
    5edc:      	csel	x8, x8, x9, lo
    5ee0:      	lsl	x8, x8, #2
    5ee4:      	add	x2, x8, #0x4
    5ee8:      	bl	0x5ee8 <generic_kprobe_process_filter+0x1c98>
    5eec:      	b	0x600c <generic_kprobe_process_filter+0x1dbc>
    5ef0:      	cmp	w21, #0x3e8
    5ef4:      	b.ls	0x5f00 <generic_kprobe_process_filter+0x1cb0>
    5ef8:      	mov	w11, wzr
    5efc:      	b	0x5f08 <generic_kprobe_process_filter+0x1cb8>
    5f00:      	and	w11, w21, #0xfffffffc
    5f04:      	ldr	w11, [x23, w11, uxtw]
    5f08:      	ldr	x12, [sp, #0x30]
    5f0c:      	cmp	w24, #0x5
    5f10:      	sub	x10, x10, #0x1
    5f14:      	ldr	w9, [x12, x9, lsl #2]
    5f18:      	cset	w12, ne
    5f1c:      	cmp	w24, #0x6
    5f20:      	cset	w13, ne
    5f24:      	cmp	w11, w9
    5f28:      	csinc	w11, w12, wzr, ne
    5f2c:      	csinc	w12, w13, wzr, eq
    5f30:      	and	w11, w11, w12
    5f34:      	str	w11, [sp, #0x58]
    5f38:      	cbz	x10, 0x600c <generic_kprobe_process_filter+0x1dbc>
    5f3c:      	add	w11, w8, #0x10
    5f40:      	cmp	w11, #0x3e8
    5f44:      	b.ls	0x5f50 <generic_kprobe_process_filter+0x1d00>
    5f48:      	mov	w11, wzr
    5f4c:      	b	0x5f58 <generic_kprobe_process_filter+0x1d08>
    5f50:      	and	w11, w11, #0xfffffffc
    5f54:      	ldr	w11, [x23, w11, uxtw]
    5f58:      	cmp	w24, #0x5
    5f5c:      	cset	w12, ne
    5f60:      	cmp	w24, #0x6
    5f64:      	cset	w13, ne
    5f68:      	cmp	w11, w9
    5f6c:      	csinc	w11, w12, wzr, ne
    5f70:      	csinc	w12, w13, wzr, eq
    5f74:      	cmp	x10, #0x1
    5f78:      	and	w11, w11, w12
    5f7c:      	str	w11, [sp, #0x5c]
    5f80:      	b.eq	0x600c <generic_kprobe_process_filter+0x1dbc>
    5f84:      	add	w11, w8, #0x14
    5f88:      	cmp	w11, #0x3e8
    5f8c:      	b.ls	0x5f98 <generic_kprobe_process_filter+0x1d48>
    5f90:      	mov	w11, wzr
    5f94:      	b	0x5fa0 <generic_kprobe_process_filter+0x1d50>
    5f98:      	and	w11, w11, #0xfffffffc
    5f9c:      	ldr	w11, [x23, w11, uxtw]
    5fa0:      	cmp	w24, #0x5
    5fa4:      	cset	w12, ne
    5fa8:      	cmp	w24, #0x6
    5fac:      	cset	w13, ne
    5fb0:      	cmp	w11, w9
    5fb4:      	csinc	w11, w12, wzr, ne
    5fb8:      	csinc	w12, w13, wzr, eq
    5fbc:      	cmp	x10, #0x2
    5fc0:      	and	w11, w11, w12
    5fc4:      	str	w11, [sp, #0x60]
    5fc8:      	b.eq	0x600c <generic_kprobe_process_filter+0x1dbc>
    5fcc:      	add	w8, w8, #0x18
    5fd0:      	cmp	w8, #0x3e8
    5fd4:      	b.ls	0x5fe0 <generic_kprobe_process_filter+0x1d90>
    5fd8:      	mov	w8, wzr
    5fdc:      	b	0x5fe8 <generic_kprobe_process_filter+0x1d98>
    5fe0:      	and	w8, w8, #0xfffffffc
    5fe4:      	ldr	w8, [x23, w8, uxtw]
    5fe8:      	cmp	w24, #0x5
    5fec:      	cset	w10, ne
    5ff0:      	cmp	w24, #0x6
    5ff4:      	cset	w11, ne
    5ff8:      	cmp	w8, w9
    5ffc:      	csinc	w8, w10, wzr, ne
    6000:      	csinc	w9, w11, wzr, eq
    6004:      	and	w8, w8, w9
    6008:      	str	w8, [sp, #0x64]
    600c:      	ldp	w8, w9, [sp, #0x58]
    6010:      	ldp	w10, w11, [sp, #0x60]
    6014:      	cmp	w24, #0x6
    6018:      	b.ne	0x602c <generic_kprobe_process_filter+0x1ddc>
    601c:      	and	w8, w9, w8
    6020:      	and	w9, w10, w11
    6024:      	and	w9, w8, w9
    6028:      	b	0x6038 <generic_kprobe_process_filter+0x1de8>
    602c:      	orr	w8, w9, w8
    6030:      	orr	w9, w10, w11
    6034:      	orr	w9, w8, w9
    6038:      	cbz	w9, 0x6534 <generic_kprobe_process_filter+0x22e4>
    603c:      	lsl	w8, w29, #2
    6040:      	sub	w10, w22, w29, lsl #2
    6044:      	and	w8, w8, #0x1c
    6048:      	sub	w22, w10, #0xc
    604c:      	add	w8, w8, w21
    6050:      	b	0x5e80 <generic_kprobe_process_filter+0x1c30>
    6054:      	mov	w10, w8
    6058:      	add	w19, w8, #0x4
    605c:      	and	x10, x10, #0x3ff
    6060:      	ldr	w10, [x10, x23]
    6064:      	cmp	w10, #0x4
    6068:      	b.ne	0x6100 <generic_kprobe_process_filter+0x1eb0>
    606c:      	cbz	w9, 0x6534 <generic_kprobe_process_filter+0x22e4>
    6070:      	mov	w8, w19
    6074:      	and	x8, x8, #0x3ff
    6078:      	ldr	w9, [x8, x23]
    607c:      	add	w8, w19, #0x4
    6080:      	cmp	w9, #0x4
    6084:      	mov	w9, w8
    6088:      	b.eq	0x6430 <generic_kprobe_process_filter+0x21e0>
    608c:      	and	x8, x8, #0x3ff
    6090:      	add	x8, x8, x23
    6094:      	ldp	w20, w22, [x8]
    6098:      	mov	w8, #0xe                // =14
    609c:      	blr	x8
    60a0:      	lsr	x8, x0, #32
    60a4:      	adrp	x0, 0x6000 <generic_kprobe_process_filter+0x1db0>
    60a8:      	add	x9, sp, #0x58
    60ac:      	str	w8, [sp, #0x58]
    60b0:      	mov	w8, #0x1                // =1
    60b4:      	add	x1, sp, #0x58
    60b8:      	ldr	x0, [x0]
    60bc:      	blr	x8
    60c0:      	cbz	x0, 0x6534 <generic_kprobe_process_filter+0x22e4>
    60c4:      	cmp	w20, #0x5
    60c8:      	b.eq	0x617c <generic_kprobe_process_filter+0x1f2c>
    60cc:      	cmp	w20, #0x6
    60d0:      	b.ne	0x6534 <generic_kprobe_process_filter+0x22e4>
    60d4:      	ldr	x11, [sp, #0xe8]
    60d8:      	mov	w8, #0x5ee8             // =24296
    60dc:      	add	x8, x11, x8
    60e0:      	tbnz	w22, #0x0, 0x61b0 <generic_kprobe_process_filter+0x1f60>
    60e4:      	ldr	w9, [x0, #0x28]
    60e8:      	cbz	w9, 0x61a8 <generic_kprobe_process_filter+0x1f58>
    60ec:      	ldr	x10, [sp, #0x30]
    60f0:      	ldr	w10, [x10]
    60f4:      	cmp	w9, w10
    60f8:      	b.eq	0x61b0 <generic_kprobe_process_filter+0x1f60>
    60fc:      	b	0x6424 <generic_kprobe_process_filter+0x21d4>
    6100:      	and	x9, x19, #0x3ff
    6104:      	add	w19, w8, #0x18
    6108:      	add	x9, x9, x23
    610c:      	ldp	w8, w10, [x9]
    6110:      	ldr	w12, [x9, #0x8]
    6114:      	ldur	x11, [x9, #0xc]
    6118:      	cbz	w12, 0x613c <generic_kprobe_process_filter+0x1eec>
    611c:      	ldr	x14, [sp, #0xe8]
    6120:      	mov	w9, wzr
    6124:      	cmp	w8, #0x2
    6128:      	b.hi	0x606c <generic_kprobe_process_filter+0x1e1c>
    612c:      	ldr	w13, [x14, #0x44]
    6130:      	cmp	w13, w12
    6134:      	b.ne	0x6150 <generic_kprobe_process_filter+0x1f00>
    6138:      	b	0x606c <generic_kprobe_process_filter+0x1e1c>
    613c:      	ldr	x14, [sp, #0xe8]
    6140:      	cmp	w8, #0x2
    6144:      	b.ls	0x6150 <generic_kprobe_process_filter+0x1f00>
    6148:      	mov	w9, wzr
    614c:      	b	0x606c <generic_kprobe_process_filter+0x1e1c>
    6150:      	add	x9, x14, #0x48
    6154:      	cmp	w10, #0x5
    6158:      	ldr	x8, [x9, x8, lsl #3]
    615c:      	and	x8, x8, x11
    6160:      	b.ne	0x6170 <generic_kprobe_process_filter+0x1f20>
    6164:      	cmp	x8, #0x0
    6168:      	cset	w9, ne
    616c:      	b	0x606c <generic_kprobe_process_filter+0x1e1c>
    6170:      	cmp	x8, #0x0
    6174:      	cset	w9, eq
    6178:      	b	0x606c <generic_kprobe_process_filter+0x1e1c>
    617c:      	ldr	x11, [sp, #0xe8]
    6180:      	mov	w8, #0x5ee8             // =24296
    6184:      	add	x8, x11, x8
    6188:      	tbz	w22, #0x0, 0x61d4 <generic_kprobe_process_filter+0x1f84>
    618c:      	ldr	w9, [x0, #0x28]
    6190:      	cbz	w9, 0x61cc <generic_kprobe_process_filter+0x1f7c>
    6194:      	ldr	x10, [sp, #0x30]
    6198:      	ldr	w10, [x10]
    619c:      	cmp	w9, w10
    61a0:      	b.eq	0x61d4 <generic_kprobe_process_filter+0x1f84>
    61a4:      	b	0x6424 <generic_kprobe_process_filter+0x21d4>
    61a8:      	mov	w9, #0x1                // =1
    61ac:      	str	x9, [x8]
    61b0:      	tbnz	w22, #0x1, 0x61f8 <generic_kprobe_process_filter+0x1fa8>
    61b4:      	ldr	w9, [x0, #0x2c]
    61b8:      	cbz	w9, 0x61f0 <generic_kprobe_process_filter+0x1fa0>
    61bc:      	ldr	w10, [x11, #0x24]
    61c0:      	cmp	w9, w10
    61c4:      	b.eq	0x61f8 <generic_kprobe_process_filter+0x1fa8>
    61c8:      	b	0x6424 <generic_kprobe_process_filter+0x21d4>
    61cc:      	mov	w9, #0x1                // =1
    61d0:      	str	x9, [x8]
    61d4:      	tbz	w22, #0x1, 0x621c <generic_kprobe_process_filter+0x1fcc>
    61d8:      	ldr	w9, [x0, #0x2c]
    61dc:      	cbz	w9, 0x6214 <generic_kprobe_process_filter+0x1fc4>
    61e0:      	ldr	w10, [x11, #0x24]
    61e4:      	cmp	w9, w10
    61e8:      	b.eq	0x621c <generic_kprobe_process_filter+0x1fcc>
    61ec:      	b	0x6424 <generic_kprobe_process_filter+0x21d4>
    61f0:      	mov	w9, #0x1                // =1
    61f4:      	str	x9, [x8]
    61f8:      	tbnz	w22, #0x2, 0x6240 <generic_kprobe_process_filter+0x1ff0>
    61fc:      	ldr	w9, [x0, #0x30]
    6200:      	cbz	w9, 0x6238 <generic_kprobe_process_filter+0x1fe8>
    6204:      	ldr	w10, [x11, #0x28]
    6208:      	cmp	w9, w10
    620c:      	b.eq	0x6240 <generic_kprobe_process_filter+0x1ff0>
    6210:      	b	0x6424 <generic_kprobe_process_filter+0x21d4>
    6214:      	mov	w9, #0x1                // =1
    6218:      	str	x9, [x8]
    621c:      	tbz	w22, #0x2, 0x6264 <generic_kprobe_process_filter+0x2014>
    6220:      	ldr	w9, [x0, #0x30]
    6224:      	cbz	w9, 0x625c <generic_kprobe_process_filter+0x200c>
    6228:      	ldr	w10, [x11, #0x28]
    622c:      	cmp	w9, w10
    6230:      	b.eq	0x6264 <generic_kprobe_process_filter+0x2014>
    6234:      	b	0x6424 <generic_kprobe_process_filter+0x21d4>
    6238:      	mov	w9, #0x1                // =1
    623c:      	str	x9, [x8]
    6240:      	tbnz	w22, #0x3, 0x6288 <generic_kprobe_process_filter+0x2038>
    6244:      	ldr	w9, [x0, #0x34]
    6248:      	cbz	w9, 0x6280 <generic_kprobe_process_filter+0x2030>
    624c:      	ldr	w10, [x11, #0x2c]
    6250:      	cmp	w9, w10
    6254:      	b.eq	0x6288 <generic_kprobe_process_filter+0x2038>
    6258:      	b	0x6424 <generic_kprobe_process_filter+0x21d4>
    625c:      	mov	w9, #0x1                // =1
    6260:      	str	x9, [x8]
    6264:      	tbz	w22, #0x3, 0x62ac <generic_kprobe_process_filter+0x205c>
    6268:      	ldr	w9, [x0, #0x34]
    626c:      	cbz	w9, 0x62a4 <generic_kprobe_process_filter+0x2054>
    6270:      	ldr	w10, [x11, #0x2c]
    6274:      	cmp	w9, w10
    6278:      	b.eq	0x62ac <generic_kprobe_process_filter+0x205c>
    627c:      	b	0x6424 <generic_kprobe_process_filter+0x21d4>
    6280:      	mov	w9, #0x1                // =1
    6284:      	str	x9, [x8]
    6288:      	tbnz	w22, #0x4, 0x62d0 <generic_kprobe_process_filter+0x2080>
    628c:      	ldr	w9, [x0, #0x38]
    6290:      	cbz	w9, 0x62c8 <generic_kprobe_process_filter+0x2078>
    6294:      	ldr	w10, [x11, #0x30]
    6298:      	cmp	w9, w10
    629c:      	b.eq	0x62d0 <generic_kprobe_process_filter+0x2080>
    62a0:      	b	0x6424 <generic_kprobe_process_filter+0x21d4>
    62a4:      	mov	w9, #0x1                // =1
    62a8:      	str	x9, [x8]
    62ac:      	tbz	w22, #0x4, 0x62f4 <generic_kprobe_process_filter+0x20a4>
    62b0:      	ldr	w9, [x0, #0x38]
    62b4:      	cbz	w9, 0x62ec <generic_kprobe_process_filter+0x209c>
    62b8:      	ldr	w10, [x11, #0x30]
    62bc:      	cmp	w9, w10
    62c0:      	b.eq	0x62f4 <generic_kprobe_process_filter+0x20a4>
    62c4:      	b	0x6424 <generic_kprobe_process_filter+0x21d4>
    62c8:      	mov	w9, #0x1                // =1
    62cc:      	str	x9, [x8]
    62d0:      	tbnz	w22, #0x5, 0x6318 <generic_kprobe_process_filter+0x20c8>
    62d4:      	ldr	w9, [x0, #0x3c]
    62d8:      	cbz	w9, 0x6310 <generic_kprobe_process_filter+0x20c0>
    62dc:      	ldr	w10, [x11, #0x34]
    62e0:      	cmp	w9, w10
    62e4:      	b.eq	0x6318 <generic_kprobe_process_filter+0x20c8>
    62e8:      	b	0x6424 <generic_kprobe_process_filter+0x21d4>
    62ec:      	mov	w9, #0x1                // =1
    62f0:      	str	x9, [x8]
    62f4:      	tbz	w22, #0x5, 0x633c <generic_kprobe_process_filter+0x20ec>
    62f8:      	ldr	w9, [x0, #0x3c]
    62fc:      	cbz	w9, 0x6334 <generic_kprobe_process_filter+0x20e4>
    6300:      	ldr	w10, [x11, #0x34]
    6304:      	cmp	w9, w10
    6308:      	b.eq	0x633c <generic_kprobe_process_filter+0x20ec>
    630c:      	b	0x6424 <generic_kprobe_process_filter+0x21d4>
    6310:      	mov	w9, #0x1                // =1
    6314:      	str	x9, [x8]
    6318:      	tbnz	w22, #0x6, 0x6360 <generic_kprobe_process_filter+0x2110>
    631c:      	ldr	w9, [x0, #0x40]
    6320:      	cbz	w9, 0x6358 <generic_kprobe_process_filter+0x2108>
    6324:      	ldr	w10, [x11, #0x38]
    6328:      	cmp	w9, w10
    632c:      	b.eq	0x6360 <generic_kprobe_process_filter+0x2110>
    6330:      	b	0x6424 <generic_kprobe_process_filter+0x21d4>
    6334:      	mov	w9, #0x1                // =1
    6338:      	str	x9, [x8]
    633c:      	tbz	w22, #0x6, 0x6384 <generic_kprobe_process_filter+0x2134>
    6340:      	ldr	w9, [x0, #0x40]
    6344:      	cbz	w9, 0x637c <generic_kprobe_process_filter+0x212c>
    6348:      	ldr	w10, [x11, #0x38]
    634c:      	cmp	w9, w10
    6350:      	b.eq	0x6384 <generic_kprobe_process_filter+0x2134>
    6354:      	b	0x6424 <generic_kprobe_process_filter+0x21d4>
    6358:      	mov	w9, #0x1                // =1
    635c:      	str	x9, [x8]
    6360:      	tbnz	w22, #0x7, 0x63a8 <generic_kprobe_process_filter+0x2158>
    6364:      	ldr	w9, [x0, #0x44]
    6368:      	cbz	w9, 0x63a0 <generic_kprobe_process_filter+0x2150>
    636c:      	ldr	w10, [x11, #0x3c]
    6370:      	cmp	w9, w10
    6374:      	b.eq	0x63a8 <generic_kprobe_process_filter+0x2158>
    6378:      	b	0x6424 <generic_kprobe_process_filter+0x21d4>
    637c:      	mov	w9, #0x1                // =1
    6380:      	str	x9, [x8]
    6384:      	tbz	w22, #0x7, 0x63d0 <generic_kprobe_process_filter+0x2180>
    6388:      	ldr	w9, [x0, #0x44]
    638c:      	cbz	w9, 0x63c8 <generic_kprobe_process_filter+0x2178>
    6390:      	ldr	w10, [x11, #0x3c]
    6394:      	cmp	w9, w10
    6398:      	b.eq	0x63d0 <generic_kprobe_process_filter+0x2180>
    639c:      	b	0x6424 <generic_kprobe_process_filter+0x21d4>
    63a0:      	mov	w9, #0x1                // =1
    63a4:      	str	x9, [x8]
    63a8:      	tbnz	w22, #0x8, 0x63f8 <generic_kprobe_process_filter+0x21a8>
    63ac:      	ldr	w9, [x0, #0x48]
    63b0:      	cbz	w9, 0x63f0 <generic_kprobe_process_filter+0x21a0>
    63b4:      	ldr	x10, [sp, #0xe8]
    63b8:      	ldr	w10, [x10, #0x40]
    63bc:      	cmp	w9, w10
    63c0:      	b.eq	0x63f8 <generic_kprobe_process_filter+0x21a8>
    63c4:      	b	0x6424 <generic_kprobe_process_filter+0x21d4>
    63c8:      	mov	w9, #0x1                // =1
    63cc:      	str	x9, [x8]
    63d0:      	tbz	w22, #0x8, 0x6408 <generic_kprobe_process_filter+0x21b8>
    63d4:      	ldr	w9, [x0, #0x48]
    63d8:      	cbz	w9, 0x6400 <generic_kprobe_process_filter+0x21b0>
    63dc:      	ldr	x10, [sp, #0xe8]
    63e0:      	ldr	w10, [x10, #0x40]
    63e4:      	cmp	w9, w10
    63e8:      	b.eq	0x6408 <generic_kprobe_process_filter+0x21b8>
    63ec:      	b	0x6424 <generic_kprobe_process_filter+0x21d4>
    63f0:      	mov	w9, #0x1                // =1
    63f4:      	str	x9, [x8]
    63f8:      	tbz	w22, #0x9, 0x640c <generic_kprobe_process_filter+0x21bc>
    63fc:      	b	0x6534 <generic_kprobe_process_filter+0x22e4>
    6400:      	mov	w9, #0x1                // =1
    6404:      	str	x9, [x8]
    6408:      	tbz	w22, #0x9, 0x6534 <generic_kprobe_process_filter+0x22e4>
    640c:      	ldr	w9, [x0, #0x4c]
    6410:      	cbz	w9, 0x652c <generic_kprobe_process_filter+0x22dc>
    6414:      	ldr	x10, [sp, #0xe8]
    6418:      	ldr	w10, [x10, #0x44]
    641c:      	cmp	w9, w10
    6420:      	b.eq	0x6534 <generic_kprobe_process_filter+0x22e4>
    6424:      	add	w9, w19, #0xc
    6428:      	mov	w10, #0x1               // =1
    642c:      	str	x10, [x8]
    6430:      	and	x8, x9, #0x3ff
    6434:      	adrp	x24, 0x6000 <generic_kprobe_process_filter+0x1db0>
    6438:      	ldr	w8, [x8, x23]
    643c:      	ldr	x24, [x24]
    6440:      	cmp	w8, #0x4
    6444:      	b.ne	0x6478 <generic_kprobe_process_filter+0x2228>
    6448:      	ldr	x9, [sp, #0xe8]
    644c:      	mov	w8, #0x5eb8             // =24248
    6450:      	add	x8, x9, x8
    6454:      	ldr	x9, [x9, #0x5eb8]
    6458:      	and	x9, x9, #0x1f
    645c:      	add	x8, x8, x9
    6460:      	mov	w9, #0x1                // =1
    6464:      	strb	w9, [x8, #0x9]
    6468:      	ldr	x8, [sp, #0x40]
    646c:      	strb	w9, [x8, #0x20]
    6470:      	strb	w9, [x8]
    6474:      	b	0x6534 <generic_kprobe_process_filter+0x22e4>
    6478:      	add	w8, w9, #0x4
    647c:      	and	x8, x8, #0x3ff
    6480:      	add	x8, x8, x23
    6484:      	ldp	w21, w19, [x8]
    6488:      	ldr	w22, [x8, #0x8]
    648c:      	ldur	x20, [x8, #0xc]
    6490:      	mov	w8, #0xe                // =14
    6494:      	blr	x8
    6498:      	lsr	x8, x0, #32
    649c:      	add	x9, sp, #0x58
    64a0:      	add	x1, sp, #0x58
    64a4:      	str	w8, [sp, #0x58]
    64a8:      	mov	w8, #0x1                // =1
    64ac:      	mov	x0, x24
    64b0:      	blr	x8
    64b4:      	cbz	x0, 0x6534 <generic_kprobe_process_filter+0x22e4>
    64b8:      	cmp	w21, #0x2
    64bc:      	cbz	w22, 0x64d8 <generic_kprobe_process_filter+0x2288>
    64c0:      	b.hi	0x6534 <generic_kprobe_process_filter+0x22e4>
    64c4:      	ldr	x8, [sp, #0xe8]
    64c8:      	ldr	w8, [x8, #0x44]
    64cc:      	cmp	w8, w22
    64d0:      	b.ne	0x64dc <generic_kprobe_process_filter+0x228c>
    64d4:      	b	0x6534 <generic_kprobe_process_filter+0x22e4>
    64d8:      	b.hi	0x6534 <generic_kprobe_process_filter+0x22e4>
    64dc:      	ldr	x8, [sp, #0xe8]
    64e0:      	lsl	x10, x21, #3
    64e4:      	add	x9, x8, #0x48
    64e8:      	add	x8, x0, x21, lsl #3
    64ec:      	ldr	x8, [x8, #0x50]
    64f0:      	ldr	x9, [x9, x10]
    64f4:      	eor	x10, x9, x8
    64f8:      	tst	x10, x20
    64fc:      	b.eq	0x650c <generic_kprobe_process_filter+0x22bc>
    6500:      	cmp	w19, #0x5
    6504:      	b.eq	0x651c <generic_kprobe_process_filter+0x22cc>
    6508:      	b	0x6534 <generic_kprobe_process_filter+0x22e4>
    650c:      	cmp	x8, x9
    6510:      	b.eq	0x6534 <generic_kprobe_process_filter+0x22e4>
    6514:      	cmp	w19, #0x6
    6518:      	b.ne	0x6534 <generic_kprobe_process_filter+0x22e4>
    651c:      	ldr	x9, [sp, #0xe8]
    6520:      	mov	w8, #0x1                // =1
    6524:      	str	x8, [x9, #0x5ef0]
    6528:      	b	0x6448 <generic_kprobe_process_filter+0x21f8>
    652c:      	mov	w9, #0x1                // =1
    6530:      	str	x9, [x8]
    6534:      	ldr	x9, [sp, #0xe8]
    6538:      	ldr	x10, [sp, #0x28]
    653c:      	ldr	x8, [x9, #0x5eb8]
    6540:      	add	x8, x8, #0x1
    6544:      	cmp	x8, x10
    6548:      	str	x8, [x9, #0x5eb8]
    654c:      	b.ls	0x65ac <generic_kprobe_process_filter+0x235c>
    6550:      	ldr	x10, [sp, #0x48]
    6554:      	ldr	w8, [x10]
    6558:      	str	w8, [x9, #0x10]
    655c:      	ldr	x8, [x10, #0x8]
    6560:      	str	x8, [x9, #0x18]
    6564:      	ldp	x20, x8, [sp, #0x38]
    6568:      	ldrb	w8, [x8]
    656c:      	cbz	w8, 0x658c <generic_kprobe_process_filter+0x233c>
    6570:      	adrp	x1, 0x6000 <generic_kprobe_process_filter+0x1db0>
    6574:      	mov	x8, xzr
    6578:      	mov	w9, #0xc                // =12
    657c:      	ldr	x1, [x1]
    6580:      	mov	x0, x20
    6584:      	mov	w2, wzr
    6588:      	blr	x9
    658c:      	ldp	x20, x19, [sp, #0x120]
    6590:      	mov	w0, wzr
    6594:      	ldr	x29, [sp, #0xe0]
    6598:      	ldp	x22, x21, [sp, #0x110]
    659c:      	ldp	x24, x23, [sp, #0x100]
    65a0:      	ldp	x30, x25, [sp, #0xf0]
    65a4:      	add	sp, sp, #0x130
    65a8:      	ret
    65ac:      	adrp	x1, 0x6000 <generic_kprobe_process_filter+0x1db0>
    65b0:      	mov	w8, #0x2                // =2
    65b4:      	mov	w9, #0xc                // =12
    65b8:      	ldr	x1, [x1]
    65bc:      	ldr	x0, [sp, #0x38]
    65c0:      	mov	w2, #0x2                // =2
    65c4:      	b	0x6588 <generic_kprobe_process_filter+0x2338>
    65c8:      	nop
    65cc:      	nop

00000000000065d0 <generic_kprobe_filter_arg>:
    65d0:      	sub	sp, sp, #0xf0
    65d4:      	str	x29, [sp, #0xa0]
    65d8:      	stp	x30, x25, [sp, #0xb0]
    65dc:      	stp	x24, x23, [sp, #0xc0]
    65e0:      	stp	x22, x21, [sp, #0xd0]
    65e4:      	stp	x20, x19, [sp, #0xe0]
    65e8:      	mov	x19, x0
    65ec:      	str	wzr, [sp, #0xa8]
    65f0:      	adrp	x0, 0x6000 <generic_kprobe_process_filter+0x1db0>
    65f4:      	mov	w8, #0x1                // =1
    65f8:      	ldr	x0, [x0]
    65fc:      	add	x9, sp, #0xa8
    6600:      	add	x1, sp, #0xa8
    6604:      	blr	x8
    6608:      	cbz	x0, 0x6778 <generic_kprobe_filter_arg+0x1a8>
    660c:      	mov	w8, #0x5ec1             // =24257
    6610:      	mov	x20, x0
    6614:      	add	x22, x0, x8
    6618:      	mov	w8, #0x5ef8             // =24312
    661c:      	add	x1, x0, x8
    6620:      	adrp	x0, 0x6000 <generic_kprobe_process_filter+0x1db0>
    6624:      	ldur	w23, [x22, #0x3f]
    6628:      	mov	w8, #0x1                // =1
    662c:      	ldr	x0, [x0]
    6630:      	blr	x8
    6634:      	cbz	x0, 0x675c <generic_kprobe_filter_arg+0x18c>
    6638:      	ldrb	w8, [x22, #0x1f]
    663c:      	cbz	w8, 0x675c <generic_kprobe_filter_arg+0x18c>
    6640:      	and	x8, x23, #0x7
    6644:      	mov	w10, #0x5ec1            // =24257
    6648:      	stp	x23, x22, [sp, #0x50]
    664c:      	add	x9, x20, x8
    6650:      	ldrb	w9, [x9, x10]
    6654:      	cbz	w9, 0x66cc <generic_kprobe_filter_arg+0xfc>
    6658:      	lsl	w8, w8, #2
    665c:      	mov	x21, x0
    6660:      	add	x8, x8, #0x4
    6664:      	ldr	w9, [x8, x0]
    6668:      	add	x8, x8, x9
    666c:      	add	x8, x8, #0x4
    6670:      	and	x9, x8, #0x3ff
    6674:      	ldr	w9, [x9, x0]
    6678:      	add	x8, x8, x9
    667c:      	and	x9, x8, #0x3ff
    6680:      	ldr	w9, [x9, x0]
    6684:      	add	x8, x8, x9
    6688:      	and	x9, x8, #0x3ff
    668c:      	ldr	w9, [x9, x0]
    6690:      	add	x8, x8, x9
    6694:      	and	x9, x8, #0x3ff
    6698:      	ldr	w9, [x9, x0]
    669c:      	add	x8, x8, x9
    66a0:      	and	x9, x8, #0x3ff
    66a4:      	ldr	w9, [x9, x0]
    66a8:      	add	x16, x8, x9
    66ac:      	and	x15, x16, #0x3ff
    66b0:      	add	x17, x0, x15
    66b4:      	ldr	w8, [x17]
    66b8:      	cmp	w8, #0x19
    66bc:      	b.hs	0x6720 <generic_kprobe_filter_arg+0x150>
    66c0:      	cmp	w15, #0x1
    66c4:      	b.eq	0x675c <generic_kprobe_filter_arg+0x18c>
    66c8:      	cbnz	w15, 0x6738 <generic_kprobe_filter_arg+0x168>
    66cc:      	ldr	x8, [sp, #0x50]
    66d0:      	cmp	w8, #0x1
    66d4:      	b.gt	0x66f4 <generic_kprobe_filter_arg+0x124>
    66d8:      	ldr	x9, [sp, #0x58]
    66dc:      	cmn	w8, #0x1
    66e0:      	b.eq	0x6798 <generic_kprobe_filter_arg+0x1c8>
    66e4:      	cbz	w8, 0x67a8 <generic_kprobe_filter_arg+0x1d8>
    66e8:      	cmp	w8, #0x1
    66ec:      	b.eq	0x67b8 <generic_kprobe_filter_arg+0x1e8>
    66f0:      	b	0x6710 <generic_kprobe_filter_arg+0x140>
    66f4:      	ldr	x9, [sp, #0x58]
    66f8:      	cmp	w8, #0x2
    66fc:      	b.eq	0x67c8 <generic_kprobe_filter_arg+0x1f8>
    6700:      	cmp	w8, #0x3
    6704:      	b.eq	0x67d8 <generic_kprobe_filter_arg+0x208>
    6708:      	cmp	w8, #0x4
    670c:      	b.eq	0x67e8 <generic_kprobe_filter_arg+0x218>
    6710:      	cmp	w8, #0x4
    6714:      	b.gt	0x6814 <generic_kprobe_filter_arg+0x244>
    6718:      	add	w8, w8, #0x1
    671c:      	b	0x67f4 <generic_kprobe_filter_arg+0x224>
    6720:      	mov	x24, xzr
    6724:      	mov	w2, #0x5ea0             // =24224
    6728:      	mov	w12, #0x1               // =1
    672c:      	stp	x19, x17, [sp, #0x30]
    6730:      	stp	x16, x15, [sp, #0x40]
    6734:      	b	0x6874 <generic_kprobe_filter_arg+0x2a4>
    6738:      	ldr	x8, [sp, #0x58]
    673c:      	adrp	x1, 0x6000 <generic_kprobe_process_filter+0x1db0>
    6740:      	mov	w9, #0xc                // =12
    6744:      	mov	x0, x19
    6748:      	stur	w15, [x8, #0x43]
    674c:      	mov	w8, #0x4                // =4
    6750:      	mov	w2, #0x4                // =4
    6754:      	ldr	x1, [x1]
    6758:      	blr	x9
    675c:      	adrp	x1, 0x6000 <generic_kprobe_process_filter+0x1db0>
    6760:      	mov	w8, #0x5                // =5
    6764:      	mov	w9, #0xc                // =12
    6768:      	ldr	x1, [x1]
    676c:      	mov	x0, x19
    6770:      	mov	w2, #0x5                // =5
    6774:      	blr	x9
    6778:      	ldp	x20, x19, [sp, #0xe0]
    677c:      	mov	w0, wzr
    6780:      	ldr	x29, [sp, #0xa0]
    6784:      	ldp	x22, x21, [sp, #0xd0]
    6788:      	ldp	x24, x23, [sp, #0xc0]
    678c:      	ldp	x30, x25, [sp, #0xb0]
    6790:      	add	sp, sp, #0xf0
    6794:      	ret
    6798:      	ldrb	w8, [x9]
    679c:      	cbz	w8, 0x67a8 <generic_kprobe_filter_arg+0x1d8>
    67a0:      	mov	w8, wzr
    67a4:      	b	0x67f4 <generic_kprobe_filter_arg+0x224>
    67a8:      	ldrb	w8, [x9, #0x1]
    67ac:      	cbz	w8, 0x67b8 <generic_kprobe_filter_arg+0x1e8>
    67b0:      	mov	w8, #0x1                // =1
    67b4:      	b	0x67f4 <generic_kprobe_filter_arg+0x224>
    67b8:      	ldrb	w8, [x9, #0x2]
    67bc:      	cbz	w8, 0x67c8 <generic_kprobe_filter_arg+0x1f8>
    67c0:      	mov	w8, #0x2                // =2
    67c4:      	b	0x67f4 <generic_kprobe_filter_arg+0x224>
    67c8:      	ldrb	w8, [x9, #0x3]
    67cc:      	cbz	w8, 0x67d8 <generic_kprobe_filter_arg+0x208>
    67d0:      	mov	w8, #0x3                // =3
    67d4:      	b	0x67f4 <generic_kprobe_filter_arg+0x224>
    67d8:      	ldrb	w8, [x9, #0x4]
    67dc:      	cbz	w8, 0x67e8 <generic_kprobe_filter_arg+0x218>
    67e0:      	mov	w8, #0x4                // =4
    67e4:      	b	0x67f4 <generic_kprobe_filter_arg+0x224>
    67e8:      	ldrb	w8, [x9, #0x5]
    67ec:      	cbz	w8, 0x6814 <generic_kprobe_filter_arg+0x244>
    67f0:      	mov	w8, #0x5                // =5
    67f4:      	stur	w8, [x9, #0x3f]
    67f8:      	adrp	x1, 0x6000 <generic_kprobe_process_filter+0x1db0>
    67fc:      	mov	w8, #0x3                // =3
    6800:      	mov	w9, #0xc                // =12
    6804:      	ldr	x1, [x1]
    6808:      	mov	x0, x19
    680c:      	mov	w2, #0x3                // =3
    6810:      	blr	x9
    6814:      	ldr	x19, [x20, #0x60]
    6818:      	mov	w8, #0xe                // =14
    681c:      	blr	x8
    6820:      	stp	x19, x0, [sp, #0x60]
    6824:      	adrp	x19, 0x6000 <generic_kprobe_process_filter+0x1db0>
    6828:      	mov	w8, #0x1                // =1
    682c:      	add	x9, sp, #0x60
    6830:      	add	x1, sp, #0x60
    6834:      	ldr	x19, [x19]
    6838:      	mov	x0, x19
    683c:      	blr	x8
    6840:      	cbz	x0, 0x6778 <generic_kprobe_filter_arg+0x1a8>
    6844:      	mov	w8, #0x3                // =3
    6848:      	add	x9, sp, #0x60
    684c:      	add	x1, sp, #0x60
    6850:      	mov	x0, x19
    6854:      	blr	x8
    6858:      	b	0x6778 <generic_kprobe_filter_arg+0x1a8>
    685c:      	cmp	w8, #0x3
    6860:      	cset	w22, eq
    6864:      	cbz	x22, 0x66cc <generic_kprobe_filter_arg+0xfc>
    6868:      	add	x24, x24, #0x1
    686c:      	cmp	x24, #0x5
    6870:      	b.eq	0x66c0 <generic_kprobe_filter_arg+0xf0>
    6874:      	add	x8, x17, x24, lsl #2
    6878:      	ldr	w8, [x8, #0x4]
    687c:      	tst	w8, #0x3ff
    6880:      	b.eq	0x66c0 <generic_kprobe_filter_arg+0xf0>
    6884:      	add	w8, w16, w8
    6888:      	and	x8, x8, #0x3ff
    688c:      	add	x23, x21, x8
    6890:      	ldr	w8, [x23, #0x4]
    6894:      	cmp	w8, #0x23
    6898:      	b.eq	0x66cc <generic_kprobe_filter_arg+0xfc>
    689c:      	ldr	w9, [x23]
    68a0:      	cmp	w9, #0x4
    68a4:      	b.hi	0x66cc <generic_kprobe_filter_arg+0xfc>
    68a8:      	add	x10, x20, x9, lsl #2
    68ac:      	ldr	w10, [x10, x2]
    68b0:      	cbnz	w10, 0x66cc <generic_kprobe_filter_arg+0xfc>
    68b4:      	add	x9, x20, x9, lsl #3
    68b8:      	ldr	x9, [x9, #0x5e78]
    68bc:      	and	x9, x9, #0x7ff
    68c0:      	add	x9, x20, x9
    68c4:      	add	x25, x9, #0x90
    68c8:      	ldr	w9, [x23, #0xc]
    68cc:      	cmp	w9, #0x1b
    68d0:      	b.le	0x68f4 <generic_kprobe_filter_arg+0x324>
    68d4:      	cmp	w9, #0x25
    68d8:      	b.gt	0x6924 <generic_kprobe_filter_arg+0x354>
    68dc:      	sub	w10, w9, #0x1c
    68e0:      	cmp	w10, #0x9
    68e4:      	b.lo	0x6968 <generic_kprobe_filter_arg+0x398>
    68e8:      	cmp	w9, #0x25
    68ec:      	b.eq	0x6b1c <generic_kprobe_filter_arg+0x54c>
    68f0:      	b	0x6868 <generic_kprobe_filter_arg+0x298>
    68f4:      	cmp	w9, #0x9
    68f8:      	b.le	0x6948 <generic_kprobe_filter_arg+0x378>
    68fc:      	sub	w10, w9, #0xa
    6900:      	cmp	w10, #0x4
    6904:      	b.lo	0x6968 <generic_kprobe_filter_arg+0x398>
    6908:      	sub	w10, w9, #0xf
    690c:      	cmp	w10, #0x2
    6910:      	b.lo	0x6b1c <generic_kprobe_filter_arg+0x54c>
    6914:      	cmp	w9, #0x11
    6918:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    691c:      	add	x25, x25, #0x4
    6920:      	b	0x6b1c <generic_kprobe_filter_arg+0x54c>
    6924:      	cmp	w9, #0x29
    6928:      	b.gt	0x6a94 <generic_kprobe_filter_arg+0x4c4>
    692c:      	sub	w10, w9, #0x26
    6930:      	cmp	w10, #0x2
    6934:      	b.lo	0x6a3c <generic_kprobe_filter_arg+0x46c>
    6938:      	sub	w10, w9, #0x28
    693c:      	cmp	w10, #0x2
    6940:      	b.lo	0x6a14 <generic_kprobe_filter_arg+0x444>
    6944:      	b	0x6868 <generic_kprobe_filter_arg+0x298>
    6948:      	cmp	w9, #0x4
    694c:      	b.gt	0x69fc <generic_kprobe_filter_arg+0x42c>
    6950:      	cmp	w9, #0x1
    6954:      	b.eq	0x6968 <generic_kprobe_filter_arg+0x398>
    6958:      	cmp	w9, #0x2
    695c:      	b.eq	0x6f4c <generic_kprobe_filter_arg+0x97c>
    6960:      	cmp	w9, #0x4
    6964:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    6968:      	cmp	w9, #0xb
    696c:      	b.le	0x69dc <generic_kprobe_filter_arg+0x40c>
    6970:      	cmp	w9, #0x24
    6974:      	b.hi	0x6bd8 <generic_kprobe_filter_arg+0x608>
    6978:      	lsl	x10, x12, x9
    697c:      	tst	x10, #0x1e00000000
    6980:      	b.ne	0x6a6c <generic_kprobe_filter_arg+0x49c>
    6984:      	lsl	x10, x12, x9
    6988:      	tst	x10, #0x60000000
    698c:      	b.ne	0x6d94 <generic_kprobe_filter_arg+0x7c4>
    6990:      	lsl	x10, x12, x9
    6994:      	tst	x10, #0x180000000
    6998:      	b.eq	0x6bd8 <generic_kprobe_filter_arg+0x608>
    699c:      	cmp	w8, #0x20
    69a0:      	b.hi	0x66cc <generic_kprobe_filter_arg+0xfc>
    69a4:      	lsl	x9, x12, x8
    69a8:      	mov	w10, #0x101e            // =4126
    69ac:      	tst	x9, x10
    69b0:      	b.eq	0x73d4 <generic_kprobe_filter_arg+0xe04>
    69b4:      	ldr	w9, [x23, #0x10]
    69b8:      	cmp	w8, #0x2
    69bc:      	b.le	0x7970 <generic_kprobe_filter_arg+0x13a0>
    69c0:      	sub	w10, w8, #0x3
    69c4:      	cmp	w10, #0x2
    69c8:      	b.hs	0x7f24 <generic_kprobe_filter_arg+0x1954>
    69cc:      	ldrb	w10, [x25]
    69d0:      	cmp	w9, w10
    69d4:      	b.eq	0x685c <generic_kprobe_filter_arg+0x28c>
    69d8:      	b	0x80ac <generic_kprobe_filter_arg+0x1adc>
    69dc:      	sub	w10, w9, #0xa
    69e0:      	cmp	w10, #0x2
    69e4:      	b.lo	0x6fc0 <generic_kprobe_filter_arg+0x9f0>
    69e8:      	cmp	w9, #0x1
    69ec:      	b.eq	0x6be4 <generic_kprobe_filter_arg+0x614>
    69f0:      	cmp	w9, #0x4
    69f4:      	b.eq	0x6be4 <generic_kprobe_filter_arg+0x614>
    69f8:      	b	0x6868 <generic_kprobe_filter_arg+0x298>
    69fc:      	cmp	w9, #0x5
    6a00:      	b.eq	0x6a14 <generic_kprobe_filter_arg+0x444>
    6a04:      	cmp	w9, #0x6
    6a08:      	b.eq	0x6a3c <generic_kprobe_filter_arg+0x46c>
    6a0c:      	cmp	w9, #0x7
    6a10:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    6a14:      	mov	x22, xzr
    6a18:      	cmp	w9, #0x27
    6a1c:      	stp	xzr, xzr, [sp, #0x78]
    6a20:      	str	xzr, [sp, #0x60]
    6a24:      	stp	xzr, xzr, [sp, #0x68]
    6a28:      	b.gt	0x6c24 <generic_kprobe_filter_arg+0x654>
    6a2c:      	cmp	w9, #0x5
    6a30:      	b.eq	0x70e0 <generic_kprobe_filter_arg+0xb10>
    6a34:      	cmp	w9, #0x7
    6a38:      	b	0x6c30 <generic_kprobe_filter_arg+0x660>
    6a3c:      	ldr	w29, [x25], #0x4
    6a40:      	mov	x22, xzr
    6a44:      	cmp	w8, #0x19
    6a48:      	b.gt	0x6c90 <generic_kprobe_filter_arg+0x6c0>
    6a4c:      	sub	w9, w8, #0x3
    6a50:      	cmp	w9, #0x2
    6a54:      	b.lo	0x7364 <generic_kprobe_filter_arg+0xd94>
    6a58:      	cmp	w8, #0x8
    6a5c:      	b.eq	0x72cc <generic_kprobe_filter_arg+0xcfc>
    6a60:      	cmp	w8, #0x9
    6a64:      	b.eq	0x6ca8 <generic_kprobe_filter_arg+0x6d8>
    6a68:      	b	0x7890 <generic_kprobe_filter_arg+0x12c0>
    6a6c:      	cmp	w8, #0x9
    6a70:      	b.le	0x6f3c <generic_kprobe_filter_arg+0x96c>
    6a74:      	cmp	w8, #0x1d
    6a78:      	b.gt	0x728c <generic_kprobe_filter_arg+0xcbc>
    6a7c:      	sub	w10, w8, #0xa
    6a80:      	cmp	w10, #0x2
    6a84:      	b.lo	0x704c <generic_kprobe_filter_arg+0xa7c>
    6a88:      	cmp	w8, #0xc
    6a8c:      	b.eq	0x6fd8 <generic_kprobe_filter_arg+0xa08>
    6a90:      	b	0x66cc <generic_kprobe_filter_arg+0xfc>
    6a94:      	cmp	w9, #0x2a
    6a98:      	b.eq	0x6b1c <generic_kprobe_filter_arg+0x54c>
    6a9c:      	cmp	w9, #0x2c
    6aa0:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    6aa4:      	ldrb	w29, [x25, #0x3]
    6aa8:      	add	x10, x25, #0x4
    6aac:      	cmp	w8, #0x19
    6ab0:      	b.gt	0x7660 <generic_kprobe_filter_arg+0x1090>
    6ab4:      	sub	w9, w8, #0x3
    6ab8:      	cmp	w9, #0x2
    6abc:      	b.hs	0x7bc4 <generic_kprobe_filter_arg+0x15f4>
    6ac0:      	cmp	w29, #0x90
    6ac4:      	str	wzr, [sp, #0x88]
    6ac8:      	b.hi	0x7c60 <generic_kprobe_filter_arg+0x1690>
    6acc:      	mov	w8, #0xaaab             // =43691
    6ad0:      	mov	w9, #0x18               // =24
    6ad4:      	movk	w8, #0xaaa, lsl #16
    6ad8:      	umull	x8, w29, w8
    6adc:      	lsr	x8, x8, #32
    6ae0:      	msub	w8, w8, w9, w29
    6ae4:      	cbz	w29, 0x6af0 <generic_kprobe_filter_arg+0x520>
    6ae8:      	mov	w13, w29
    6aec:      	cbz	w8, 0x6b04 <generic_kprobe_filter_arg+0x534>
    6af0:      	sub	w8, w29, w8, uxtb
    6af4:      	add	w9, w8, #0x18
    6af8:      	cmp	w8, #0x78
    6afc:      	and	w13, w9, #0xffff
    6b00:      	b.hi	0x7c64 <generic_kprobe_filter_arg+0x1694>
    6b04:      	and	w8, w13, #0xff
    6b08:      	mov	w9, #0xab               // =171
    6b0c:      	mul	w8, w8, w9
    6b10:      	lsr	w8, w8, #12
    6b14:      	sub	w11, w8, #0x1
    6b18:      	b	0x8658 <generic_kprobe_filter_arg+0x2088>
    6b1c:      	ldr	w29, [x25]
    6b20:      	and	w9, w8, #0xfffffffe
    6b24:      	cmp	w9, #0x24
    6b28:      	b.eq	0x6b30 <generic_kprobe_filter_arg+0x560>
    6b2c:      	cbz	w29, 0x66cc <generic_kprobe_filter_arg+0xfc>
    6b30:      	cmp	w8, #0x25
    6b34:      	b.hi	0x6d74 <generic_kprobe_filter_arg+0x7a4>
    6b38:      	mov	w10, #0x100             // =256
    6b3c:      	lsl	x9, x12, x8
    6b40:      	movk	w10, #0x400, lsl #16
    6b44:      	tst	x9, x10
    6b48:      	b.ne	0x6ea4 <generic_kprobe_filter_arg+0x8d4>
    6b4c:      	mov	w10, #0x200             // =512
    6b50:      	lsl	x9, x12, x8
    6b54:      	movk	w10, #0x800, lsl #16
    6b58:      	tst	x9, x10
    6b5c:      	b.ne	0x6dd4 <generic_kprobe_filter_arg+0x804>
    6b60:      	lsl	x9, x12, x8
    6b64:      	tst	x9, #0x3000000000
    6b68:      	b.eq	0x6d74 <generic_kprobe_filter_arg+0x7a4>
    6b6c:      	cmp	w29, #0x1, lsl #12      // =0x1000
    6b70:      	strh	wzr, [sp, #0x60]
    6b74:      	b.hi	0x6d8c <generic_kprobe_filter_arg+0x7bc>
    6b78:      	add	x8, x25, #0x4
    6b7c:      	mov	w10, #0x4               // =4
    6b80:      	add	x11, sp, #0x60
    6b84:      	mov	w12, #0x2               // =2
    6b88:      	add	x0, sp, #0x60
    6b8c:      	mov	w1, #0x2                // =2
    6b90:      	add	x9, x8, x29
    6b94:      	add	x9, x9, #0x4
    6b98:      	ldr	w9, [x25]
    6b9c:      	add	x8, x8, x9
    6ba0:      	add	x2, x8, #0x4
    6ba4:      	blr	x10
    6ba8:      	ldr	w9, [x23, #0x10]
    6bac:      	cbz	w9, 0x93b0 <generic_kprobe_filter_arg+0x2de0>
    6bb0:      	ldrh	w8, [sp, #0x60]
    6bb4:      	ldp	x16, x15, [sp, #0x40]
    6bb8:      	mov	w2, #0x5ea0             // =24224
    6bbc:      	mov	w12, #0x1               // =1
    6bc0:      	and	w8, w8, #0xf000
    6bc4:      	ldr	x17, [sp, #0x38]
    6bc8:      	cmp	w9, w8
    6bcc:      	b.ne	0x7f54 <generic_kprobe_filter_arg+0x1984>
    6bd0:      	mov	w22, #0x1               // =1
    6bd4:      	b	0x93c4 <generic_kprobe_filter_arg+0x2df4>
    6bd8:      	sub	w10, w9, #0xc
    6bdc:      	cmp	w10, #0x2
    6be0:      	b.hs	0x6fb8 <generic_kprobe_filter_arg+0x9e8>
    6be4:      	cmp	w8, #0x20
    6be8:      	b.hi	0x66cc <generic_kprobe_filter_arg+0xfc>
    6bec:      	lsl	x10, x12, x8
    6bf0:      	mov	w11, #0x101e            // =4126
    6bf4:      	tst	x10, x11
    6bf8:      	b.eq	0x6c3c <generic_kprobe_filter_arg+0x66c>
    6bfc:      	ldr	w10, [x23, #0x10]
    6c00:      	cmp	w8, #0x2
    6c04:      	b.le	0x6f80 <generic_kprobe_filter_arg+0x9b0>
    6c08:      	sub	w11, w8, #0x3
    6c0c:      	cmp	w11, #0x2
    6c10:      	b.hs	0x73bc <generic_kprobe_filter_arg+0xdec>
    6c14:      	ldr	w11, [x25]
    6c18:      	cmp	w11, w10
    6c1c:      	b.eq	0x685c <generic_kprobe_filter_arg+0x28c>
    6c20:      	b	0x8480 <generic_kprobe_filter_arg+0x1eb0>
    6c24:      	cmp	w9, #0x28
    6c28:      	b.eq	0x70e8 <generic_kprobe_filter_arg+0xb18>
    6c2c:      	cmp	w9, #0x29
    6c30:      	mov	x10, x25
    6c34:      	b.eq	0x7110 <generic_kprobe_filter_arg+0xb40>
    6c38:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    6c3c:      	lsl	x10, x12, x8
    6c40:      	tst	x10, #0xc00
    6c44:      	b.ne	0x70a8 <generic_kprobe_filter_arg+0xad8>
    6c48:      	lsl	x10, x12, x8
    6c4c:      	tst	x10, #0x180000000
    6c50:      	b.eq	0x66cc <generic_kprobe_filter_arg+0xfc>
    6c54:      	cmp	w8, #0x1f
    6c58:      	b.ne	0x7630 <generic_kprobe_filter_arg+0x1060>
    6c5c:      	ldp	w11, w10, [x23, #0x10]
    6c60:      	cmp	w9, #0xc
    6c64:      	b.hi	0x8120 <generic_kprobe_filter_arg+0x1b50>
    6c68:      	lsl	w8, w12, w9
    6c6c:      	mov	w13, #0x1402            // =5122
    6c70:      	tst	w8, w13
    6c74:      	b.eq	0x8120 <generic_kprobe_filter_arg+0x1b50>
    6c78:      	ldr	w8, [x25]
    6c7c:      	cmp	w11, w8
    6c80:      	b.gt	0x8134 <generic_kprobe_filter_arg+0x1b64>
    6c84:      	cmp	w8, w10
    6c88:      	b.le	0x6868 <generic_kprobe_filter_arg+0x298>
    6c8c:      	b	0x8134 <generic_kprobe_filter_arg+0x1b64>
    6c90:      	cmp	w8, #0x20
    6c94:      	b.gt	0x7184 <generic_kprobe_filter_arg+0xbb4>
    6c98:      	cmp	w8, #0x1a
    6c9c:      	b.eq	0x72cc <generic_kprobe_filter_arg+0xcfc>
    6ca0:      	cmp	w8, #0x1b
    6ca4:      	b.ne	0x7890 <generic_kprobe_filter_arg+0x12c0>
    6ca8:      	ldr	w8, [x23, #0x10]
    6cac:      	str	wzr, [sp, #0x88]
    6cb0:      	adrp	x0, 0x6000 <generic_kprobe_process_filter+0x1db0>
    6cb4:      	add	x9, sp, #0x60
    6cb8:      	add	x1, sp, #0x60
    6cbc:      	str	w8, [sp, #0x60]
    6cc0:      	mov	w8, #0x1                // =1
    6cc4:      	ldr	x0, [x0]
    6cc8:      	blr	x8
    6ccc:      	mov	x22, xzr
    6cd0:      	cbz	w29, 0x7880 <generic_kprobe_filter_arg+0x12b0>
    6cd4:      	cbz	x0, 0x7880 <generic_kprobe_filter_arg+0x12b0>
    6cd8:      	mov	x19, x0
    6cdc:      	adrp	x0, 0x6000 <generic_kprobe_process_filter+0x1db0>
    6ce0:      	mov	w8, #0x1                // =1
    6ce4:      	ldr	x0, [x0]
    6ce8:      	add	x9, sp, #0x88
    6cec:      	add	x1, sp, #0x88
    6cf0:      	blr	x8
    6cf4:      	cbz	x0, 0x7878 <generic_kprobe_filter_arg+0x12a8>
    6cf8:      	cmp	w29, #0x7f
    6cfc:      	mov	w9, #0x7f               // =127
    6d00:      	mov	w11, #0x1               // =1
    6d04:      	mov	x1, x0
    6d08:      	mov	x8, xzr
    6d0c:      	sub	w12, w29, #0x2
    6d10:      	sub	w13, w29, #0x1
    6d14:      	csel	w9, w29, w9, lo
    6d18:      	sub	x11, x11, x29
    6d1c:      	lsl	w10, w9, #3
    6d20:      	mov	x9, x0
    6d24:      	str	w10, [x9], #0x5
    6d28:      	neg	x10, x29
    6d2c:      	add	w14, w13, w8
    6d30:      	cmp	x11, x8
    6d34:      	and	x14, x14, #0xfff
    6d38:      	ldrb	w14, [x25, x14]
    6d3c:      	sturb	w14, [x9, #-0x1]
    6d40:      	b.eq	0x6d68 <generic_kprobe_filter_arg+0x798>
    6d44:      	cmn	x8, #0x7e
    6d48:      	b.eq	0x6d68 <generic_kprobe_filter_arg+0x798>
    6d4c:      	add	w14, w12, w8
    6d50:      	sub	x8, x8, #0x2
    6d54:      	and	x14, x14, #0xfff
    6d58:      	cmp	x10, x8
    6d5c:      	ldrb	w14, [x25, x14]
    6d60:      	strb	w14, [x9], #0x2
    6d64:      	b.ne	0x6d2c <generic_kprobe_filter_arg+0x75c>
    6d68:      	mov	w8, #0x1                // =1
    6d6c:      	mov	x0, x19
    6d70:      	b	0x7354 <generic_kprobe_filter_arg+0xd84>
    6d74:      	sub	w8, w8, #0x3
    6d78:      	cmp	w8, #0x2
    6d7c:      	b.hs	0x6d8c <generic_kprobe_filter_arg+0x7bc>
    6d80:      	cmp	w29, #0x1, lsl #12      // =0x1000
    6d84:      	str	wzr, [sp, #0x88]
    6d88:      	b.ls	0x74c4 <generic_kprobe_filter_arg+0xef4>
    6d8c:      	mov	x22, xzr
    6d90:      	b	0x93c4 <generic_kprobe_filter_arg+0x2df4>
    6d94:      	cmp	w8, #0x20
    6d98:      	b.hi	0x66cc <generic_kprobe_filter_arg+0xfc>
    6d9c:      	lsl	x9, x12, x8
    6da0:      	mov	w10, #0x101e            // =4126
    6da4:      	tst	x9, x10
    6da8:      	b.eq	0x7400 <generic_kprobe_filter_arg+0xe30>
    6dac:      	ldr	w9, [x23, #0x10]
    6db0:      	cmp	w8, #0x2
    6db4:      	b.le	0x7990 <generic_kprobe_filter_arg+0x13c0>
    6db8:      	sub	w10, w8, #0x3
    6dbc:      	cmp	w10, #0x2
    6dc0:      	b.hs	0x7f3c <generic_kprobe_filter_arg+0x196c>
    6dc4:      	ldrh	w10, [x25]
    6dc8:      	cmp	w9, w10
    6dcc:      	b.eq	0x685c <generic_kprobe_filter_arg+0x28c>
    6dd0:      	b	0x80ec <generic_kprobe_filter_arg+0x1b1c>
    6dd4:      	ldr	w8, [x23, #0x10]
    6dd8:      	str	wzr, [sp, #0x88]
    6ddc:      	adrp	x0, 0x6000 <generic_kprobe_process_filter+0x1db0>
    6de0:      	add	x9, sp, #0x60
    6de4:      	add	x1, sp, #0x60
    6de8:      	str	w8, [sp, #0x60]
    6dec:      	mov	w8, #0x1                // =1
    6df0:      	ldr	x0, [x0]
    6df4:      	blr	x8
    6df8:      	mov	x22, xzr
    6dfc:      	cbz	w29, 0x93b4 <generic_kprobe_filter_arg+0x2de4>
    6e00:      	cbz	x0, 0x93b4 <generic_kprobe_filter_arg+0x2de4>
    6e04:      	mov	x19, x0
    6e08:      	adrp	x0, 0x6000 <generic_kprobe_process_filter+0x1db0>
    6e0c:      	mov	w8, #0x1                // =1
    6e10:      	ldr	x0, [x0]
    6e14:      	add	x9, sp, #0x88
    6e18:      	add	x1, sp, #0x88
    6e1c:      	blr	x8
    6e20:      	cbz	x0, 0x7fa4 <generic_kprobe_filter_arg+0x19d4>
    6e24:      	cmp	w29, #0x7f
    6e28:      	mov	w10, #0x7f              // =127
    6e2c:      	mov	w12, #0x1               // =1
    6e30:      	mov	x1, x0
    6e34:      	mov	x8, xzr
    6e38:      	add	x9, x25, #0x4
    6e3c:      	sub	w13, w29, #0x2
    6e40:      	sub	w14, w29, #0x1
    6e44:      	csel	w10, w29, w10, lo
    6e48:      	sub	x12, x12, x29
    6e4c:      	lsl	w11, w10, #3
    6e50:      	mov	x10, x0
    6e54:      	str	w11, [x10], #0x5
    6e58:      	neg	x11, x29
    6e5c:      	add	w15, w14, w8
    6e60:      	cmp	x12, x8
    6e64:      	and	x15, x15, #0xfff
    6e68:      	ldrb	w15, [x9, x15]
    6e6c:      	sturb	w15, [x10, #-0x1]
    6e70:      	b.eq	0x6e98 <generic_kprobe_filter_arg+0x8c8>
    6e74:      	cmn	x8, #0x7e
    6e78:      	b.eq	0x6e98 <generic_kprobe_filter_arg+0x8c8>
    6e7c:      	add	w15, w13, w8
    6e80:      	sub	x8, x8, #0x2
    6e84:      	and	x15, x15, #0xfff
    6e88:      	cmp	x11, x8
    6e8c:      	ldrb	w15, [x9, x15]
    6e90:      	strb	w15, [x10], #0x2
    6e94:      	b.ne	0x6e5c <generic_kprobe_filter_arg+0x88c>
    6e98:      	mov	w8, #0x1                // =1
    6e9c:      	mov	x0, x19
    6ea0:      	b	0x6f2c <generic_kprobe_filter_arg+0x95c>
    6ea4:      	ldr	w8, [x23, #0x10]
    6ea8:      	str	wzr, [sp, #0x88]
    6eac:      	adrp	x0, 0x6000 <generic_kprobe_process_filter+0x1db0>
    6eb0:      	add	x9, sp, #0x60
    6eb4:      	add	x1, sp, #0x60
    6eb8:      	str	w8, [sp, #0x60]
    6ebc:      	mov	w8, #0x1                // =1
    6ec0:      	ldr	x0, [x0]
    6ec4:      	blr	x8
    6ec8:      	mov	x22, xzr
    6ecc:      	cbz	w29, 0x93b4 <generic_kprobe_filter_arg+0x2de4>
    6ed0:      	cbz	x0, 0x93b4 <generic_kprobe_filter_arg+0x2de4>
    6ed4:      	mov	x19, x0
    6ed8:      	adrp	x0, 0x6000 <generic_kprobe_process_filter+0x1db0>
    6edc:      	mov	w8, #0x1                // =1
    6ee0:      	ldr	x0, [x0]
    6ee4:      	add	x9, sp, #0x88
    6ee8:      	add	x1, sp, #0x88
    6eec:      	blr	x8
    6ef0:      	cbz	x0, 0x7fa4 <generic_kprobe_filter_arg+0x19d4>
    6ef4:      	cmp	w29, #0xff
    6ef8:      	mov	w8, #0xff               // =255
    6efc:      	add	x2, x25, #0x4
    6f00:      	mov	x22, x0
    6f04:      	csel	w1, w29, w8, lo
    6f08:      	mov	x8, x0
    6f0c:      	lsl	w9, w1, #3
    6f10:      	str	w9, [x8], #0x4
    6f14:      	mov	w9, #0x4                // =4
    6f18:      	mov	x0, x8
    6f1c:      	blr	x9
    6f20:      	mov	w8, #0x1                // =1
    6f24:      	mov	x0, x19
    6f28:      	mov	x1, x22
    6f2c:      	blr	x8
    6f30:      	cmp	x0, #0x0
    6f34:      	cset	w22, ne
    6f38:      	b	0x7fa8 <generic_kprobe_filter_arg+0x19d8>
    6f3c:      	sub	w10, w8, #0x1
    6f40:      	cmp	w10, #0x4
    6f44:      	b.lo	0x6fd8 <generic_kprobe_filter_arg+0xa08>
    6f48:      	b	0x66cc <generic_kprobe_filter_arg+0xfc>
    6f4c:      	add	x29, x25, #0x8
    6f50:      	ldr	w25, [x25, #0x4]
    6f54:      	mov	x22, xzr
    6f58:      	cmp	w8, #0x19
    6f5c:      	b.gt	0x7534 <generic_kprobe_filter_arg+0xf64>
    6f60:      	sub	w9, w8, #0x3
    6f64:      	cmp	w9, #0x2
    6f68:      	b.lo	0x7d50 <generic_kprobe_filter_arg+0x1780>
    6f6c:      	cmp	w8, #0x8
    6f70:      	b.eq	0x7cc4 <generic_kprobe_filter_arg+0x16f4>
    6f74:      	cmp	w8, #0x9
    6f78:      	b.eq	0x754c <generic_kprobe_filter_arg+0xf7c>
    6f7c:      	b	0x9954 <generic_kprobe_filter_arg+0x3384>
    6f80:      	cmp	w8, #0x1
    6f84:      	b.eq	0x779c <generic_kprobe_filter_arg+0x11cc>
    6f88:      	cmp	w8, #0x2
    6f8c:      	b.ne	0x8480 <generic_kprobe_filter_arg+0x1eb0>
    6f90:      	cmp	w9, #0xc
    6f94:      	b.hi	0x8474 <generic_kprobe_filter_arg+0x1ea4>
    6f98:      	lsl	w11, w12, w9
    6f9c:      	mov	w13, #0x1402            // =5122
    6fa0:      	tst	w11, w13
    6fa4:      	b.eq	0x8474 <generic_kprobe_filter_arg+0x1ea4>
    6fa8:      	ldr	w11, [x25]
    6fac:      	cmp	w11, w10
    6fb0:      	b.lt	0x6868 <generic_kprobe_filter_arg+0x298>
    6fb4:      	b	0x8480 <generic_kprobe_filter_arg+0x1eb0>
    6fb8:      	cmp	w9, #0x1c
    6fbc:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    6fc0:      	cmp	w8, #0x20
    6fc4:      	b.hi	0x66cc <generic_kprobe_filter_arg+0xfc>
    6fc8:      	lsl	x10, x12, x8
    6fcc:      	mov	w11, #0x101e            // =4126
    6fd0:      	tst	x10, x11
    6fd4:      	b.eq	0x7000 <generic_kprobe_filter_arg+0xa30>
    6fd8:      	ldr	x10, [x23, #0x10]
    6fdc:      	cmp	w8, #0x2
    6fe0:      	b.le	0x701c <generic_kprobe_filter_arg+0xa4c>
    6fe4:      	sub	w11, w8, #0x3
    6fe8:      	cmp	w11, #0x2
    6fec:      	b.hs	0x7274 <generic_kprobe_filter_arg+0xca4>
    6ff0:      	ldr	x11, [x25]
    6ff4:      	cmp	x11, x10
    6ff8:      	b.eq	0x685c <generic_kprobe_filter_arg+0x28c>
    6ffc:      	b	0x7e98 <generic_kprobe_filter_arg+0x18c8>
    7000:      	lsl	x10, x12, x8
    7004:      	tst	x10, #0xc00
    7008:      	b.ne	0x704c <generic_kprobe_filter_arg+0xa7c>
    700c:      	lsl	x10, x12, x8
    7010:      	tst	x10, #0x180000000
    7014:      	b.ne	0x7298 <generic_kprobe_filter_arg+0xcc8>
    7018:      	b	0x66cc <generic_kprobe_filter_arg+0xfc>
    701c:      	cmp	w8, #0x1
    7020:      	b.eq	0x74a4 <generic_kprobe_filter_arg+0xed4>
    7024:      	cmp	w8, #0x2
    7028:      	b.ne	0x7e98 <generic_kprobe_filter_arg+0x18c8>
    702c:      	cmp	w9, #0xc
    7030:      	b.eq	0x703c <generic_kprobe_filter_arg+0xa6c>
    7034:      	cmp	w9, #0xa
    7038:      	b.ne	0x7e8c <generic_kprobe_filter_arg+0x18bc>
    703c:      	ldr	x11, [x25]
    7040:      	cmp	x11, x10
    7044:      	b.lt	0x6868 <generic_kprobe_filter_arg+0x298>
    7048:      	b	0x7e98 <generic_kprobe_filter_arg+0x18c8>
    704c:      	ldrb	w8, [x23, #0x10]
    7050:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    7054:      	add	x9, sp, #0x88
    7058:      	add	x1, sp, #0x88
    705c:      	str	w8, [sp, #0x88]
    7060:      	mov	w8, #0x1                // =1
    7064:      	ldr	x0, [x0]
    7068:      	blr	x8
    706c:      	cbz	x0, 0x7618 <generic_kprobe_filter_arg+0x1048>
    7070:      	ldr	x8, [x25]
    7074:      	add	x9, sp, #0x60
    7078:      	add	x1, sp, #0x60
    707c:      	str	x8, [sp, #0x60]
    7080:      	mov	w8, #0x1                // =1
    7084:      	blr	x8
    7088:      	ldr	w8, [x23, #0x4]
    708c:      	cmp	w8, #0xb
    7090:      	b.eq	0x7a44 <generic_kprobe_filter_arg+0x1474>
    7094:      	cmp	w8, #0xa
    7098:      	mov	w12, #0x1               // =1
    709c:      	b.eq	0x7ae4 <generic_kprobe_filter_arg+0x1514>
    70a0:      	mov	w8, wzr
    70a4:      	b	0x7aec <generic_kprobe_filter_arg+0x151c>
    70a8:      	ldrb	w8, [x23, #0x10]
    70ac:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    70b0:      	add	x9, sp, #0x88
    70b4:      	add	x1, sp, #0x88
    70b8:      	str	w8, [sp, #0x88]
    70bc:      	mov	w8, #0x1                // =1
    70c0:      	ldr	x0, [x0]
    70c4:      	blr	x8
    70c8:      	cbz	x0, 0x7e60 <generic_kprobe_filter_arg+0x1890>
    70cc:      	ldr	w8, [x25]
    70d0:      	add	x9, sp, #0x60
    70d4:      	str	x8, [sp, #0x60]
    70d8:      	mov	w8, #0x1                // =1
    70dc:      	b	0x7a1c <generic_kprobe_filter_arg+0x144c>
    70e0:      	mov	x10, xzr
    70e4:      	b	0x7110 <generic_kprobe_filter_arg+0xb40>
    70e8:      	ldrh	w11, [x25]
    70ec:      	mov	x10, xzr
    70f0:      	strh	w11, [sp, #0x86]
    70f4:      	ldrh	w11, [x25, #0x2]
    70f8:      	strh	w11, [sp, #0x80]
    70fc:      	ldr	x11, [x25, #0x8]
    7100:      	str	x11, [sp, #0x60]
    7104:      	ldr	x11, [x25, #0x10]
    7108:      	add	x25, sp, #0x60
    710c:      	str	x11, [sp, #0x68]
    7110:      	mov	x22, xzr
    7114:      	cmp	w8, #0x13
    7118:      	b.le	0x7140 <generic_kprobe_filter_arg+0xb70>
    711c:      	cmp	w8, #0x17
    7120:      	b.gt	0x7168 <generic_kprobe_filter_arg+0xb98>
    7124:      	sub	w9, w8, #0x14
    7128:      	cmp	w9, #0x2
    712c:      	b.lo	0x769c <generic_kprobe_filter_arg+0x10cc>
    7130:      	sub	w9, w8, #0x16
    7134:      	cmp	w9, #0x2
    7138:      	b.lo	0x7688 <generic_kprobe_filter_arg+0x10b8>
    713c:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    7140:      	cmp	w8, #0xf
    7144:      	b.le	0x7378 <generic_kprobe_filter_arg+0xda8>
    7148:      	cmp	w8, #0x11
    714c:      	b.gt	0x7678 <generic_kprobe_filter_arg+0x10a8>
    7150:      	cmp	w8, #0x10
    7154:      	b.eq	0x7688 <generic_kprobe_filter_arg+0x10b8>
    7158:      	cmp	w8, #0x11
    715c:      	b.ne	0x6864 <generic_kprobe_filter_arg+0x294>
    7160:      	ldrh	w22, [x25, #0x24]
    7164:      	b	0x7df4 <generic_kprobe_filter_arg+0x1824>
    7168:      	cmp	w8, #0x1b
    716c:      	b.gt	0x76b0 <generic_kprobe_filter_arg+0x10e0>
    7170:      	cmp	w8, #0x18
    7174:      	b.eq	0x76e0 <generic_kprobe_filter_arg+0x1110>
    7178:      	cmp	w8, #0x19
    717c:      	b.eq	0x76d4 <generic_kprobe_filter_arg+0x1104>
    7180:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    7184:      	cmp	w8, #0x21
    7188:      	b.eq	0x77c4 <generic_kprobe_filter_arg+0x11f4>
    718c:      	cmp	w8, #0x22
    7190:      	b.ne	0x7890 <generic_kprobe_filter_arg+0x12c0>
    7194:      	mov	x22, xzr
    7198:      	mov	w19, wzr
    719c:      	add	x8, x23, #0x10
    71a0:      	str	x8, [sp, #0x28]
    71a4:      	ldr	x8, [sp, #0x28]
    71a8:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    71ac:      	add	x9, sp, #0x60
    71b0:      	add	x1, sp, #0x60
    71b4:      	ldr	w8, [x8, x22, lsl #2]
    71b8:      	str	w8, [sp, #0x60]
    71bc:      	mov	w8, #0x1                // =1
    71c0:      	ldr	x0, [x0]
    71c4:      	blr	x8
    71c8:      	cbz	x0, 0x7878 <generic_kprobe_filter_arg+0x12a8>
    71cc:      	cbz	w29, 0x7250 <generic_kprobe_filter_arg+0xc80>
    71d0:      	mov	x8, xzr
    71d4:      	mov	x9, x25
    71d8:      	mov	x10, x29
    71dc:      	b	0x71f4 <generic_kprobe_filter_arg+0xc24>
    71e0:      	add	x8, x8, #0x1
    71e4:      	sub	x10, x10, #0x1
    71e8:      	add	x9, x9, #0x1
    71ec:      	cmp	x8, x29
    71f0:      	b.eq	0x7250 <generic_kprobe_filter_arg+0xc80>
    71f4:      	mov	x11, xzr
    71f8:      	nop
    71fc:      	nop
    7200:      	cmp	x10, x11
    7204:      	b.eq	0x71e0 <generic_kprobe_filter_arg+0xc10>
    7208:      	ldrb	w12, [x0, x11]
    720c:      	cbz	w12, 0x724c <generic_kprobe_filter_arg+0xc7c>
    7210:      	ldrb	w13, [x9, x11]
    7214:      	sub	w14, w13, #0x41
    7218:      	orr	w15, w13, #0x20
    721c:      	cmp	w14, #0x1a
    7220:      	sub	w14, w12, #0x41
    7224:      	csel	w13, w15, w13, lo
    7228:      	orr	w15, w12, #0x20
    722c:      	cmp	w14, #0x1a
    7230:      	csel	w12, w15, w12, lo
    7234:      	cmp	x11, #0x62
    7238:      	b.hi	0x71e0 <generic_kprobe_filter_arg+0xc10>
    723c:      	add	x11, x11, #0x1
    7240:      	cmp	w13, w12
    7244:      	b.eq	0x7200 <generic_kprobe_filter_arg+0xc30>
    7248:      	b	0x71e0 <generic_kprobe_filter_arg+0xc10>
    724c:      	tbz	w8, #0x1f, 0x8098 <generic_kprobe_filter_arg+0x1ac8>
    7250:      	ldr	w9, [x23, #0x8]
    7254:      	add	w8, w19, #0xc
    7258:      	cmp	w8, w9
    725c:      	b.hs	0x7878 <generic_kprobe_filter_arg+0x12a8>
    7260:      	add	x22, x22, #0x1
    7264:      	add	w19, w19, #0x4
    7268:      	cmp	x22, #0x64
    726c:      	b.ne	0x71a4 <generic_kprobe_filter_arg+0xbd4>
    7270:      	b	0x7878 <generic_kprobe_filter_arg+0x12a8>
    7274:      	cmp	w8, #0xc
    7278:      	b.ne	0x7e98 <generic_kprobe_filter_arg+0x18c8>
    727c:      	ldr	x11, [x25]
    7280:      	tst	x11, x10
    7284:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    7288:      	b	0x7e98 <generic_kprobe_filter_arg+0x18c8>
    728c:      	sub	w10, w8, #0x1f
    7290:      	cmp	w10, #0x2
    7294:      	b.hs	0x7b10 <generic_kprobe_filter_arg+0x1540>
    7298:      	cmp	w8, #0x1f
    729c:      	b.ne	0x7394 <generic_kprobe_filter_arg+0xdc4>
    72a0:      	ldp	x11, x10, [x23, #0x10]
    72a4:      	cmp	w9, #0xa
    72a8:      	b.eq	0x72b4 <generic_kprobe_filter_arg+0xce4>
    72ac:      	cmp	w9, #0xc
    72b0:      	b.ne	0x7d64 <generic_kprobe_filter_arg+0x1794>
    72b4:      	ldr	x8, [x25]
    72b8:      	cmp	x11, x8
    72bc:      	b.gt	0x7d78 <generic_kprobe_filter_arg+0x17a8>
    72c0:      	cmp	x8, x10
    72c4:      	b.le	0x6868 <generic_kprobe_filter_arg+0x298>
    72c8:      	b	0x7d78 <generic_kprobe_filter_arg+0x17a8>
    72cc:      	ldr	w8, [x23, #0x10]
    72d0:      	str	wzr, [sp, #0x88]
    72d4:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    72d8:      	add	x9, sp, #0x60
    72dc:      	add	x1, sp, #0x60
    72e0:      	str	w8, [sp, #0x60]
    72e4:      	mov	w8, #0x1                // =1
    72e8:      	ldr	x0, [x0]
    72ec:      	blr	x8
    72f0:      	mov	x22, xzr
    72f4:      	cbz	w29, 0x7880 <generic_kprobe_filter_arg+0x12b0>
    72f8:      	cbz	x0, 0x7880 <generic_kprobe_filter_arg+0x12b0>
    72fc:      	mov	x19, x0
    7300:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    7304:      	mov	w8, #0x1                // =1
    7308:      	ldr	x0, [x0]
    730c:      	add	x9, sp, #0x88
    7310:      	add	x1, sp, #0x88
    7314:      	blr	x8
    7318:      	cbz	x0, 0x7878 <generic_kprobe_filter_arg+0x12a8>
    731c:      	cmp	w29, #0xff
    7320:      	mov	w8, #0xff               // =255
    7324:      	mov	x22, x0
    7328:      	mov	x2, x25
    732c:      	csel	w1, w29, w8, lo
    7330:      	mov	x8, x0
    7334:      	lsl	w9, w1, #3
    7338:      	str	w9, [x8], #0x4
    733c:      	mov	w9, #0x4                // =4
    7340:      	mov	x0, x8
    7344:      	blr	x9
    7348:      	mov	w8, #0x1                // =1
    734c:      	mov	x0, x19
    7350:      	mov	x1, x22
    7354:      	blr	x8
    7358:      	cmp	x0, #0x0
    735c:      	cset	w22, ne
    7360:      	b	0x787c <generic_kprobe_filter_arg+0x12ac>
    7364:      	cmp	w29, #0x1, lsl #12      // =0x1000
    7368:      	str	wzr, [sp, #0x88]
    736c:      	b.ls	0x78b8 <generic_kprobe_filter_arg+0x12e8>
    7370:      	mov	x22, xzr
    7374:      	b	0x7890 <generic_kprobe_filter_arg+0x12c0>
    7378:      	cmp	w8, #0xd
    737c:      	b.eq	0x76e0 <generic_kprobe_filter_arg+0x1110>
    7380:      	cmp	w8, #0xe
    7384:      	b.eq	0x76d4 <generic_kprobe_filter_arg+0x1104>
    7388:      	cmp	w8, #0xf
    738c:      	b.eq	0x769c <generic_kprobe_filter_arg+0x10cc>
    7390:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    7394:      	ldp	x11, x8, [x23, #0x10]
    7398:      	cmp	w9, #0xc
    739c:      	b.eq	0x73a8 <generic_kprobe_filter_arg+0xdd8>
    73a0:      	cmp	w9, #0xa
    73a4:      	b.ne	0x7db0 <generic_kprobe_filter_arg+0x17e0>
    73a8:      	ldr	x10, [x25]
    73ac:      	cmp	x11, x10
    73b0:      	ccmp	x10, x8, #0x0, le
    73b4:      	cset	w8, le
    73b8:      	b	0x7dc0 <generic_kprobe_filter_arg+0x17f0>
    73bc:      	cmp	w8, #0xc
    73c0:      	b.ne	0x8480 <generic_kprobe_filter_arg+0x1eb0>
    73c4:      	ldr	w11, [x25]
    73c8:      	tst	w11, w10
    73cc:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    73d0:      	b	0x8480 <generic_kprobe_filter_arg+0x1eb0>
    73d4:      	lsl	x9, x12, x8
    73d8:      	tst	x9, #0xc00
    73dc:      	b.ne	0x79b0 <generic_kprobe_filter_arg+0x13e0>
    73e0:      	lsl	x9, x12, x8
    73e4:      	tst	x9, #0x180000000
    73e8:      	b.eq	0x66cc <generic_kprobe_filter_arg+0xfc>
    73ec:      	cmp	w8, #0x1f
    73f0:      	b.ne	0x7fd4 <generic_kprobe_filter_arg+0x1a04>
    73f4:      	ldr	w9, [x23, #0x10]
    73f8:      	ldrb	w8, [x25]
    73fc:      	b	0x7428 <generic_kprobe_filter_arg+0xe58>
    7400:      	lsl	x9, x12, x8
    7404:      	tst	x9, #0xc00
    7408:      	b.ne	0x79e8 <generic_kprobe_filter_arg+0x1418>
    740c:      	lsl	x9, x12, x8
    7410:      	tst	x9, #0x180000000
    7414:      	b.eq	0x66cc <generic_kprobe_filter_arg+0xfc>
    7418:      	cmp	w8, #0x1f
    741c:      	b.ne	0x7ff8 <generic_kprobe_filter_arg+0x1a28>
    7420:      	ldr	w9, [x23, #0x10]
    7424:      	ldrh	w8, [x25]
    7428:      	cmp	w9, w8
    742c:      	b.hi	0x743c <generic_kprobe_filter_arg+0xe6c>
    7430:      	ldr	w9, [x23, #0x14]
    7434:      	cmp	w9, w8
    7438:      	b.hs	0x6868 <generic_kprobe_filter_arg+0x298>
    743c:      	ldr	w9, [x23, #0x8]
    7440:      	cmp	w9, #0x11
    7444:      	b.lo	0x66cc <generic_kprobe_filter_arg+0xfc>
    7448:      	ldr	w10, [x23, #0x18]
    744c:      	cmp	w10, w8
    7450:      	b.hi	0x7460 <generic_kprobe_filter_arg+0xe90>
    7454:      	ldr	w10, [x23, #0x1c]
    7458:      	cmp	w10, w8
    745c:      	b.hs	0x6868 <generic_kprobe_filter_arg+0x298>
    7460:      	cmp	w9, #0x19
    7464:      	b.lo	0x66cc <generic_kprobe_filter_arg+0xfc>
    7468:      	ldr	w10, [x23, #0x20]
    746c:      	cmp	w10, w8
    7470:      	b.hi	0x7480 <generic_kprobe_filter_arg+0xeb0>
    7474:      	ldr	w10, [x23, #0x24]
    7478:      	cmp	w10, w8
    747c:      	b.hs	0x6868 <generic_kprobe_filter_arg+0x298>
    7480:      	cmp	w9, #0x21
    7484:      	b.lo	0x66cc <generic_kprobe_filter_arg+0xfc>
    7488:      	ldr	w9, [x23, #0x28]
    748c:      	cmp	w9, w8
    7490:      	b.hi	0x66cc <generic_kprobe_filter_arg+0xfc>
    7494:      	ldr	w9, [x23, #0x2c]
    7498:      	cmp	w9, w8
    749c:      	b.hs	0x6868 <generic_kprobe_filter_arg+0x298>
    74a0:      	b	0x66cc <generic_kprobe_filter_arg+0xfc>
    74a4:      	cmp	w9, #0xc
    74a8:      	b.eq	0x74b4 <generic_kprobe_filter_arg+0xee4>
    74ac:      	cmp	w9, #0xa
    74b0:      	b.ne	0x7e7c <generic_kprobe_filter_arg+0x18ac>
    74b4:      	ldr	x11, [x25]
    74b8:      	cmp	x11, x10
    74bc:      	b.gt	0x6868 <generic_kprobe_filter_arg+0x298>
    74c0:      	b	0x7e98 <generic_kprobe_filter_arg+0x18c8>
    74c4:      	and	w8, w29, #0xffff
    74c8:      	cmp	w8, #0x90
    74cc:      	b.hi	0x7a64 <generic_kprobe_filter_arg+0x1494>
    74d0:      	and	w8, w29, #0xff
    74d4:      	mov	w9, #0xab               // =171
    74d8:      	tst	w29, #0xffff
    74dc:      	mul	w8, w8, w9
    74e0:      	mov	w9, #0x18               // =24
    74e4:      	lsr	w8, w8, #12
    74e8:      	msub	w8, w8, w9, w29
    74ec:      	b.eq	0x7500 <generic_kprobe_filter_arg+0xf30>
    74f0:      	tst	w8, #0xff
    74f4:      	mov	w9, w29
    74f8:      	mov	w11, w29
    74fc:      	b.eq	0x751c <generic_kprobe_filter_arg+0xf4c>
    7500:      	sub	w8, w29, w8, uxtb
    7504:      	and	w9, w8, #0xffff
    7508:      	add	w8, w8, #0x18
    750c:      	and	w11, w8, #0xffff
    7510:      	cmp	w9, #0x78
    7514:      	b.hi	0x8a20 <generic_kprobe_filter_arg+0x2450>
    7518:      	mov	w9, w11
    751c:      	and	w8, w9, #0xff
    7520:      	mov	w9, #0xab               // =171
    7524:      	mul	w8, w8, w9
    7528:      	lsr	w8, w8, #12
    752c:      	sub	w10, w8, #0x1
    7530:      	b	0x8a70 <generic_kprobe_filter_arg+0x24a0>
    7534:      	cmp	w8, #0x20
    7538:      	b.gt	0x7b50 <generic_kprobe_filter_arg+0x1580>
    753c:      	cmp	w8, #0x1a
    7540:      	b.eq	0x7cc4 <generic_kprobe_filter_arg+0x16f4>
    7544:      	cmp	w8, #0x1b
    7548:      	b.ne	0x9954 <generic_kprobe_filter_arg+0x3384>
    754c:      	ldr	w8, [x23, #0x10]
    7550:      	str	wzr, [sp, #0x88]
    7554:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    7558:      	add	x9, sp, #0x60
    755c:      	add	x1, sp, #0x60
    7560:      	mov	w19, #0x1               // =1
    7564:      	str	w8, [sp, #0x60]
    7568:      	mov	w8, #0x1                // =1
    756c:      	ldr	x0, [x0]
    7570:      	blr	x8
    7574:      	mov	x22, xzr
    7578:      	cbz	w25, 0x9950 <generic_kprobe_filter_arg+0x3380>
    757c:      	cbz	x0, 0x9950 <generic_kprobe_filter_arg+0x3380>
    7580:      	mov	x22, x0
    7584:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    7588:      	mov	w8, #0x1                // =1
    758c:      	ldr	x0, [x0]
    7590:      	add	x9, sp, #0x88
    7594:      	add	x1, sp, #0x88
    7598:      	blr	x8
    759c:      	cbz	x0, 0x994c <generic_kprobe_filter_arg+0x337c>
    75a0:      	cmp	w25, #0x7f
    75a4:      	mov	w9, #0x7f               // =127
    75a8:      	mov	x1, x0
    75ac:      	mov	x8, xzr
    75b0:      	sub	x11, x19, x25
    75b4:      	sub	w12, w25, #0x2
    75b8:      	sub	w13, w25, #0x1
    75bc:      	csel	w9, w25, w9, lo
    75c0:      	lsl	w10, w9, #3
    75c4:      	mov	x9, x0
    75c8:      	str	w10, [x9], #0x5
    75cc:      	neg	x10, x25
    75d0:      	add	w14, w13, w8
    75d4:      	cmp	x11, x8
    75d8:      	and	x14, x14, #0xfff
    75dc:      	ldrb	w14, [x29, x14]
    75e0:      	sturb	w14, [x9, #-0x1]
    75e4:      	b.eq	0x760c <generic_kprobe_filter_arg+0x103c>
    75e8:      	cmn	x8, #0x7e
    75ec:      	b.eq	0x760c <generic_kprobe_filter_arg+0x103c>
    75f0:      	add	w14, w12, w8
    75f4:      	sub	x8, x8, #0x2
    75f8:      	and	x14, x14, #0xfff
    75fc:      	cmp	x10, x8
    7600:      	ldrb	w14, [x29, x14]
    7604:      	strb	w14, [x9], #0x2
    7608:      	b.ne	0x75d0 <generic_kprobe_filter_arg+0x1000>
    760c:      	mov	w8, #0x1                // =1
    7610:      	mov	x0, x22
    7614:      	b	0x993c <generic_kprobe_filter_arg+0x336c>
    7618:      	mov	x22, xzr
    761c:      	ldp	x16, x15, [sp, #0x40]
    7620:      	mov	w2, #0x5ea0             // =24224
    7624:      	mov	w12, #0x1               // =1
    7628:      	ldr	x17, [sp, #0x38]
    762c:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    7630:      	ldp	w11, w8, [x23, #0x10]
    7634:      	cmp	w9, #0xc
    7638:      	b.hi	0x8178 <generic_kprobe_filter_arg+0x1ba8>
    763c:      	lsl	w10, w12, w9
    7640:      	mov	w13, #0x1402            // =5122
    7644:      	tst	w10, w13
    7648:      	b.eq	0x8178 <generic_kprobe_filter_arg+0x1ba8>
    764c:      	ldr	w10, [x25]
    7650:      	cmp	w11, w10
    7654:      	ccmp	w10, w8, #0x0, le
    7658:      	cset	w8, le
    765c:      	b	0x8188 <generic_kprobe_filter_arg+0x1bb8>
    7660:      	cmp	w8, #0x1c
    7664:      	b.eq	0x7c88 <generic_kprobe_filter_arg+0x16b8>
    7668:      	mov	x25, x10
    766c:      	cmp	w8, #0x1a
    7670:      	b.eq	0x7bd0 <generic_kprobe_filter_arg+0x1600>
    7674:      	b	0x66cc <generic_kprobe_filter_arg+0xfc>
    7678:      	cmp	w8, #0x12
    767c:      	b.eq	0x769c <generic_kprobe_filter_arg+0x10cc>
    7680:      	cmp	w8, #0x13
    7684:      	b.ne	0x6864 <generic_kprobe_filter_arg+0x294>
    7688:      	ldrh	w29, [x25, #0x22]
    768c:      	mov	w11, wzr
    7690:      	mov	w13, wzr
    7694:      	mov	x19, xzr
    7698:      	b	0x76ec <generic_kprobe_filter_arg+0x111c>
    769c:      	ldrh	w29, [x25, #0x20]
    76a0:      	mov	w11, wzr
    76a4:      	mov	w13, wzr
    76a8:      	mov	x19, xzr
    76ac:      	b	0x76ec <generic_kprobe_filter_arg+0x111c>
    76b0:      	cmp	w8, #0x1c
    76b4:      	b.eq	0x7df0 <generic_kprobe_filter_arg+0x1820>
    76b8:      	cmp	w8, #0x1d
    76bc:      	b.ne	0x6864 <generic_kprobe_filter_arg+0x294>
    76c0:      	cmp	w9, #0x7
    76c4:      	b.ne	0x8324 <generic_kprobe_filter_arg+0x1d54>
    76c8:      	cbnz	x10, 0x8334 <generic_kprobe_filter_arg+0x1d64>
    76cc:      	mov	x19, xzr
    76d0:      	b	0x8348 <generic_kprobe_filter_arg+0x1d78>
    76d4:      	ldp	w11, w13, [x25, #0x10]
    76d8:      	ldr	x19, [x25, #0x18]
    76dc:      	b	0x76e8 <generic_kprobe_filter_arg+0x1118>
    76e0:      	ldp	w11, w13, [x25]
    76e4:      	ldr	x19, [x25, #0x8]
    76e8:      	mov	x29, xzr
    76ec:      	mov	x22, xzr
    76f0:      	cmp	w8, #0x11
    76f4:      	b.gt	0x7720 <generic_kprobe_filter_arg+0x1150>
    76f8:      	sub	w9, w8, #0xd
    76fc:      	cmp	w9, #0x2
    7700:      	b.lo	0x774c <generic_kprobe_filter_arg+0x117c>
    7704:      	ldr	x19, [sp, #0x30]
    7708:      	sub	w9, w8, #0xf
    770c:      	cmp	w9, #0x2
    7710:      	b.lo	0x7938 <generic_kprobe_filter_arg+0x1368>
    7714:      	cmp	w8, #0x11
    7718:      	b.eq	0x7df4 <generic_kprobe_filter_arg+0x1824>
    771c:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    7720:      	cmp	w8, #0x19
    7724:      	b.hi	0x7928 <generic_kprobe_filter_arg+0x1358>
    7728:      	lsl	w9, w12, w8
    772c:      	mov	w10, #0x500000          // =5242880
    7730:      	tst	w9, w10
    7734:      	b.ne	0x7a24 <generic_kprobe_filter_arg+0x1454>
    7738:      	mov	w10, #0xa00000          // =10485760
    773c:      	tst	w9, w10
    7740:      	b.ne	0x7a34 <generic_kprobe_filter_arg+0x1464>
    7744:      	tst	w9, #0x3000000
    7748:      	b.eq	0x7928 <generic_kprobe_filter_arg+0x1358>
    774c:      	ldrh	w8, [x25, #0x26]
    7750:      	cmp	w8, #0xa
    7754:      	b.eq	0x7a74 <generic_kprobe_filter_arg+0x14a4>
    7758:      	cmp	w8, #0x2
    775c:      	b.ne	0x7b00 <generic_kprobe_filter_arg+0x1530>
    7760:      	ldr	w8, [x23, #0x10]
    7764:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    7768:      	add	x9, sp, #0xac
    776c:      	add	x1, sp, #0xac
    7770:      	str	w8, [sp, #0xac]
    7774:      	mov	w8, #0x1                // =1
    7778:      	mov	w22, w11
    777c:      	ldr	x0, [x0]
    7780:      	blr	x8
    7784:      	ldr	x19, [sp, #0x30]
    7788:      	cbz	x0, 0x8430 <generic_kprobe_filter_arg+0x1e60>
    778c:      	mov	w8, #0x20               // =32
    7790:      	add	x1, sp, #0x88
    7794:      	stp	w8, w22, [sp, #0x88]
    7798:      	b	0x7abc <generic_kprobe_filter_arg+0x14ec>
    779c:      	cmp	w9, #0xc
    77a0:      	b.hi	0x8464 <generic_kprobe_filter_arg+0x1e94>
    77a4:      	lsl	w11, w12, w9
    77a8:      	mov	w13, #0x1402            // =5122
    77ac:      	tst	w11, w13
    77b0:      	b.eq	0x8464 <generic_kprobe_filter_arg+0x1e94>
    77b4:      	ldr	w11, [x25]
    77b8:      	cmp	w11, w10
    77bc:      	b.gt	0x6868 <generic_kprobe_filter_arg+0x298>
    77c0:      	b	0x8480 <generic_kprobe_filter_arg+0x1eb0>
    77c4:      	mov	x19, xzr
    77c8:      	mov	w22, wzr
    77cc:      	add	x8, x23, #0x10
    77d0:      	str	x8, [sp, #0x28]
    77d4:      	ldr	x8, [sp, #0x28]
    77d8:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    77dc:      	add	x9, sp, #0x60
    77e0:      	add	x1, sp, #0x60
    77e4:      	ldr	w8, [x8, x19, lsl #2]
    77e8:      	str	w8, [sp, #0x60]
    77ec:      	mov	w8, #0x1                // =1
    77f0:      	ldr	x0, [x0]
    77f4:      	blr	x8
    77f8:      	cbz	x0, 0x7878 <generic_kprobe_filter_arg+0x12a8>
    77fc:      	cbz	w29, 0x7858 <generic_kprobe_filter_arg+0x1288>
    7800:      	mov	x8, xzr
    7804:      	mov	x9, x25
    7808:      	mov	x10, x29
    780c:      	b	0x7824 <generic_kprobe_filter_arg+0x1254>
    7810:      	add	x8, x8, #0x1
    7814:      	sub	x10, x10, #0x1
    7818:      	add	x9, x9, #0x1
    781c:      	cmp	x8, x29
    7820:      	b.eq	0x7858 <generic_kprobe_filter_arg+0x1288>
    7824:      	mov	x11, xzr
    7828:      	cmp	x10, x11
    782c:      	b.eq	0x7810 <generic_kprobe_filter_arg+0x1240>
    7830:      	ldrb	w12, [x0, x11]
    7834:      	cbz	w12, 0x7854 <generic_kprobe_filter_arg+0x1284>
    7838:      	cmp	x11, #0x62
    783c:      	b.hi	0x7810 <generic_kprobe_filter_arg+0x1240>
    7840:      	ldrb	w13, [x9, x11]
    7844:      	add	x11, x11, #0x1
    7848:      	cmp	w13, w12
    784c:      	b.eq	0x7828 <generic_kprobe_filter_arg+0x1258>
    7850:      	b	0x7810 <generic_kprobe_filter_arg+0x1240>
    7854:      	tbz	w8, #0x1f, 0x8098 <generic_kprobe_filter_arg+0x1ac8>
    7858:      	ldr	w9, [x23, #0x8]
    785c:      	add	w8, w22, #0xc
    7860:      	cmp	w8, w9
    7864:      	b.hs	0x7878 <generic_kprobe_filter_arg+0x12a8>
    7868:      	add	x19, x19, #0x1
    786c:      	add	w22, w22, #0x4
    7870:      	cmp	x19, #0x64
    7874:      	b.ne	0x77d4 <generic_kprobe_filter_arg+0x1204>
    7878:      	mov	x22, xzr
    787c:      	ldr	x19, [sp, #0x30]
    7880:      	ldp	x16, x15, [sp, #0x40]
    7884:      	mov	w2, #0x5ea0             // =24224
    7888:      	ldr	x17, [sp, #0x38]
    788c:      	mov	w12, #0x1               // =1
    7890:      	ldr	w8, [x23, #0x4]
    7894:      	cmp	w8, #0x25
    7898:      	b.hi	0x6864 <generic_kprobe_filter_arg+0x294>
    789c:      	mov	x9, #0x50               // =80
    78a0:      	lsl	x8, x12, x8
    78a4:      	movk	x9, #0xc00, lsl #16
    78a8:      	movk	x9, #0x20, lsl #32
    78ac:      	tst	x8, x9
    78b0:      	b.ne	0x9988 <generic_kprobe_filter_arg+0x33b8>
    78b4:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    78b8:      	and	w8, w29, #0xffff
    78bc:      	cmp	w8, #0x90
    78c0:      	b.hi	0x7e6c <generic_kprobe_filter_arg+0x189c>
    78c4:      	and	w8, w29, #0xff
    78c8:      	mov	w9, #0xab               // =171
    78cc:      	tst	w29, #0xffff
    78d0:      	mul	w8, w8, w9
    78d4:      	mov	w9, #0x18               // =24
    78d8:      	lsr	w8, w8, #12
    78dc:      	msub	w8, w8, w9, w29
    78e0:      	b.eq	0x78f4 <generic_kprobe_filter_arg+0x1324>
    78e4:      	tst	w8, #0xff
    78e8:      	mov	w9, w29
    78ec:      	mov	w11, w29
    78f0:      	b.eq	0x7910 <generic_kprobe_filter_arg+0x1340>
    78f4:      	sub	w8, w29, w8, uxtb
    78f8:      	and	w9, w8, #0xffff
    78fc:      	add	w8, w8, #0x18
    7900:      	and	w11, w8, #0xffff
    7904:      	cmp	w9, #0x78
    7908:      	b.hi	0x8eec <generic_kprobe_filter_arg+0x291c>
    790c:      	mov	w9, w11
    7910:      	and	w8, w9, #0xff
    7914:      	mov	w9, #0xab               // =171
    7918:      	mul	w8, w8, w9
    791c:      	lsr	w8, w8, #12
    7920:      	sub	w10, w8, #0x1
    7924:      	b	0x8f3c <generic_kprobe_filter_arg+0x296c>
    7928:      	ldr	x19, [sp, #0x30]
    792c:      	sub	w8, w8, #0x12
    7930:      	cmp	w8, #0x2
    7934:      	b.hs	0x6864 <generic_kprobe_filter_arg+0x294>
    7938:      	ldrb	w8, [x23, #0x10]
    793c:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    7940:      	add	x9, sp, #0xac
    7944:      	add	x1, sp, #0xac
    7948:      	str	w8, [sp, #0xac]
    794c:      	mov	w8, #0x1                // =1
    7950:      	ldr	x0, [x0]
    7954:      	blr	x8
    7958:      	cbz	x0, 0x7e60 <generic_kprobe_filter_arg+0x1890>
    795c:      	str	x29, [sp, #0x88]
    7960:      	mov	w8, #0x1                // =1
    7964:      	add	x9, sp, #0x88
    7968:      	add	x1, sp, #0x88
    796c:      	b	0x7e28 <generic_kprobe_filter_arg+0x1858>
    7970:      	cmp	w8, #0x1
    7974:      	b.eq	0x80a0 <generic_kprobe_filter_arg+0x1ad0>
    7978:      	cmp	w8, #0x2
    797c:      	b.ne	0x80ac <generic_kprobe_filter_arg+0x1adc>
    7980:      	ldrb	w10, [x25]
    7984:      	cmp	w9, w10
    7988:      	b.hi	0x6868 <generic_kprobe_filter_arg+0x298>
    798c:      	b	0x80ac <generic_kprobe_filter_arg+0x1adc>
    7990:      	cmp	w8, #0x1
    7994:      	b.eq	0x80e0 <generic_kprobe_filter_arg+0x1b10>
    7998:      	cmp	w8, #0x2
    799c:      	b.ne	0x80ec <generic_kprobe_filter_arg+0x1b1c>
    79a0:      	ldrh	w10, [x25]
    79a4:      	cmp	w9, w10
    79a8:      	b.hi	0x6868 <generic_kprobe_filter_arg+0x298>
    79ac:      	b	0x80ec <generic_kprobe_filter_arg+0x1b1c>
    79b0:      	ldrb	w8, [x23, #0x10]
    79b4:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    79b8:      	add	x9, sp, #0x88
    79bc:      	add	x1, sp, #0x88
    79c0:      	str	w8, [sp, #0x88]
    79c4:      	mov	w8, #0x1                // =1
    79c8:      	ldr	x0, [x0]
    79cc:      	blr	x8
    79d0:      	cbz	x0, 0x7e60 <generic_kprobe_filter_arg+0x1890>
    79d4:      	ldrb	w8, [x25]
    79d8:      	add	x9, sp, #0x60
    79dc:      	str	x8, [sp, #0x60]
    79e0:      	mov	w8, #0x1                // =1
    79e4:      	b	0x7a1c <generic_kprobe_filter_arg+0x144c>
    79e8:      	ldrb	w8, [x23, #0x10]
    79ec:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    79f0:      	add	x9, sp, #0x88
    79f4:      	add	x1, sp, #0x88
    79f8:      	str	w8, [sp, #0x88]
    79fc:      	mov	w8, #0x1                // =1
    7a00:      	ldr	x0, [x0]
    7a04:      	blr	x8
    7a08:      	cbz	x0, 0x7e60 <generic_kprobe_filter_arg+0x1890>
    7a0c:      	ldrh	w8, [x25]
    7a10:      	add	x9, sp, #0x60
    7a14:      	str	x8, [sp, #0x60]
    7a18:      	mov	w8, #0x1                // =1
    7a1c:      	add	x1, sp, #0x60
    7a20:      	b	0x7e28 <generic_kprobe_filter_arg+0x1858>
    7a24:      	ldr	x19, [sp, #0x30]
    7a28:      	cmp	x29, #0x400
    7a2c:      	cset	w22, lo
    7a30:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    7a34:      	ldr	x19, [sp, #0x30]
    7a38:      	cmp	x29, #0x3ff
    7a3c:      	cset	w22, hi
    7a40:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    7a44:      	ldp	x16, x15, [sp, #0x40]
    7a48:      	cmp	x0, #0x0
    7a4c:      	mov	w2, #0x5ea0             // =24224
    7a50:      	mov	w12, #0x1               // =1
    7a54:      	cset	w8, eq
    7a58:      	ldr	x17, [sp, #0x38]
    7a5c:      	mov	w22, w8
    7a60:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    7a64:      	cmp	w8, #0x101
    7a68:      	b.hs	0x807c <generic_kprobe_filter_arg+0x1aac>
    7a6c:      	mov	w11, #0x100             // =256
    7a70:      	b	0x8a20 <generic_kprobe_filter_arg+0x2450>
    7a74:      	ldr	w8, [x23, #0x14]
    7a78:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    7a7c:      	add	x9, sp, #0xac
    7a80:      	add	x1, sp, #0xac
    7a84:      	str	w8, [sp, #0xac]
    7a88:      	mov	w8, #0x1                // =1
    7a8c:      	mov	w25, w13
    7a90:      	mov	w22, w11
    7a94:      	ldr	x0, [x0]
    7a98:      	blr	x8
    7a9c:      	cbz	x0, 0x8438 <generic_kprobe_filter_arg+0x1e68>
    7aa0:      	mov	w8, #0x80               // =128
    7aa4:      	stp	w25, w19, [sp, #0x90]
    7aa8:      	add	x1, sp, #0x88
    7aac:      	stp	w8, w22, [sp, #0x88]
    7ab0:      	lsr	x8, x19, #32
    7ab4:      	ldr	x19, [sp, #0x30]
    7ab8:      	str	w8, [sp, #0x98]
    7abc:      	mov	w8, #0x1                // =1
    7ac0:      	blr	x8
    7ac4:      	ldr	w8, [x23, #0x4]
    7ac8:      	sub	w9, w8, #0x18
    7acc:      	cmp	w9, #0x2
    7ad0:      	b.lo	0x8090 <generic_kprobe_filter_arg+0x1ac0>
    7ad4:      	sub	w8, w8, #0xd
    7ad8:      	mov	w12, #0x1               // =1
    7adc:      	cmp	w8, #0x1
    7ae0:      	b.hi	0x70a0 <generic_kprobe_filter_arg+0xad0>
    7ae4:      	cmp	x0, #0x0
    7ae8:      	cset	w8, ne
    7aec:      	ldp	x16, x15, [sp, #0x40]
    7af0:      	mov	w2, #0x5ea0             // =24224
    7af4:      	mov	w22, w8
    7af8:      	ldr	x17, [sp, #0x38]
    7afc:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    7b00:      	ldr	x19, [sp, #0x30]
    7b04:      	mov	w8, wzr
    7b08:      	mov	w22, wzr
    7b0c:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    7b10:      	cmp	w8, #0x1e
    7b14:      	b.ne	0x66cc <generic_kprobe_filter_arg+0xfc>
    7b18:      	ldr	w8, [x23, #0x10]
    7b1c:      	and	x8, x8, #0x7
    7b20:      	add	x9, x20, x8, lsl #2
    7b24:      	ldr	w9, [x9, x2]
    7b28:      	cbnz	w9, 0x66cc <generic_kprobe_filter_arg+0xfc>
    7b2c:      	add	x8, x20, x8, lsl #3
    7b30:      	ldr	x9, [x25]
    7b34:      	ldr	x8, [x8, #0x5e78]
    7b38:      	and	x8, x8, #0x7ff
    7b3c:      	add	x8, x20, x8
    7b40:      	ldr	x8, [x8, #0x90]
    7b44:      	bics	xzr, x8, x9
    7b48:      	cset	w22, ne
    7b4c:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    7b50:      	cmp	w8, #0x21
    7b54:      	b.eq	0x81c4 <generic_kprobe_filter_arg+0x1bf4>
    7b58:      	cmp	w8, #0x22
    7b5c:      	b.ne	0x9954 <generic_kprobe_filter_arg+0x3384>
    7b60:      	mov	w19, #0x10              // =16
    7b64:      	ldr	w8, [x23, x19]
    7b68:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    7b6c:      	add	x9, sp, #0x60
    7b70:      	add	x1, sp, #0x60
    7b74:      	str	w8, [sp, #0x60]
    7b78:      	mov	w8, #0x1                // =1
    7b7c:      	ldr	x0, [x0]
    7b80:      	blr	x8
    7b84:      	cbz	x0, 0x994c <generic_kprobe_filter_arg+0x337c>
    7b88:      	mov	x1, x0
    7b8c:      	mov	x0, x29
    7b90:      	mov	x2, x25
    7b94:      	bl	0x7b94 <generic_kprobe_filter_arg+0x15c4>
    7b98:      	tbz	w0, #0x1f, 0x89a4 <generic_kprobe_filter_arg+0x23d4>
    7b9c:      	ldr	w8, [x23, #0x8]
    7ba0:      	add	x19, x19, #0x4
    7ba4:      	mov	w12, #0x1               // =1
    7ba8:      	mov	x22, xzr
    7bac:      	sub	w9, w19, #0x8
    7bb0:      	cmp	w9, w8
    7bb4:      	b.hs	0x9954 <generic_kprobe_filter_arg+0x3384>
    7bb8:      	cmp	x19, #0x1a0
    7bbc:      	b.ne	0x7b64 <generic_kprobe_filter_arg+0x1594>
    7bc0:      	b	0x9954 <generic_kprobe_filter_arg+0x3384>
    7bc4:      	mov	x25, x10
    7bc8:      	cmp	w8, #0x8
    7bcc:      	b.ne	0x66cc <generic_kprobe_filter_arg+0xfc>
    7bd0:      	ldr	w8, [x23, #0x10]
    7bd4:      	str	wzr, [sp, #0x88]
    7bd8:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    7bdc:      	add	x9, sp, #0x60
    7be0:      	add	x1, sp, #0x60
    7be4:      	str	w8, [sp, #0x60]
    7be8:      	mov	w8, #0x1                // =1
    7bec:      	ldr	x0, [x0]
    7bf0:      	blr	x8
    7bf4:      	mov	x22, xzr
    7bf8:      	cbz	w29, 0x8564 <generic_kprobe_filter_arg+0x1f94>
    7bfc:      	cbz	x0, 0x8564 <generic_kprobe_filter_arg+0x1f94>
    7c00:      	mov	x19, x0
    7c04:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    7c08:      	mov	w8, #0x1                // =1
    7c0c:      	ldr	x0, [x0]
    7c10:      	add	x9, sp, #0x88
    7c14:      	add	x1, sp, #0x88
    7c18:      	blr	x8
    7c1c:      	cbz	x0, 0x855c <generic_kprobe_filter_arg+0x1f8c>
    7c20:      	lsl	w9, w29, #3
    7c24:      	mov	x8, x0
    7c28:      	mov	x2, x25
    7c2c:      	mov	w1, w29
    7c30:      	str	w9, [x8], #0x4
    7c34:      	mov	w9, #0x4                // =4
    7c38:      	mov	x25, x0
    7c3c:      	mov	x0, x8
    7c40:      	blr	x9
    7c44:      	mov	w8, #0x1                // =1
    7c48:      	mov	x0, x19
    7c4c:      	mov	x1, x25
    7c50:      	blr	x8
    7c54:      	cmp	x0, #0x0
    7c58:      	cset	w22, ne
    7c5c:      	b	0x8560 <generic_kprobe_filter_arg+0x1f90>
    7c60:      	mov	w13, #0x100             // =256
    7c64:      	sub	w8, w13, #0x100
    7c68:      	ror	w8, w8, #0x8
    7c6c:      	cmp	w8, #0x2
    7c70:      	b.gt	0x8064 <generic_kprobe_filter_arg+0x1a94>
    7c74:      	cbz	w8, 0x864c <generic_kprobe_filter_arg+0x207c>
    7c78:      	cmp	w8, #0x1
    7c7c:      	b.ne	0x8644 <generic_kprobe_filter_arg+0x2074>
    7c80:      	mov	w11, #0x7               // =7
    7c84:      	b	0x8658 <generic_kprobe_filter_arg+0x2088>
    7c88:      	ldrb	w8, [x23, #0x10]
    7c8c:      	ldrh	w19, [x25]
    7c90:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    7c94:      	add	x9, sp, #0x88
    7c98:      	add	x1, sp, #0x88
    7c9c:      	str	w8, [sp, #0x88]
    7ca0:      	mov	w8, #0x1                // =1
    7ca4:      	ldr	x0, [x0]
    7ca8:      	blr	x8
    7cac:      	cbz	x0, 0x83d8 <generic_kprobe_filter_arg+0x1e08>
    7cb0:      	str	x19, [sp, #0x60]
    7cb4:      	mov	w8, #0x1                // =1
    7cb8:      	add	x9, sp, #0x60
    7cbc:      	add	x1, sp, #0x60
    7cc0:      	b	0x837c <generic_kprobe_filter_arg+0x1dac>
    7cc4:      	ldr	w8, [x23, #0x10]
    7cc8:      	str	wzr, [sp, #0x88]
    7ccc:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    7cd0:      	add	x9, sp, #0x60
    7cd4:      	add	x1, sp, #0x60
    7cd8:      	str	w8, [sp, #0x60]
    7cdc:      	mov	w8, #0x1                // =1
    7ce0:      	ldr	x0, [x0]
    7ce4:      	blr	x8
    7ce8:      	mov	x22, xzr
    7cec:      	cbz	w25, 0x9950 <generic_kprobe_filter_arg+0x3380>
    7cf0:      	cbz	x0, 0x9950 <generic_kprobe_filter_arg+0x3380>
    7cf4:      	mov	x19, x0
    7cf8:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    7cfc:      	mov	w8, #0x1                // =1
    7d00:      	ldr	x0, [x0]
    7d04:      	add	x9, sp, #0x88
    7d08:      	add	x1, sp, #0x88
    7d0c:      	blr	x8
    7d10:      	cbz	x0, 0x994c <generic_kprobe_filter_arg+0x337c>
    7d14:      	cmp	w25, #0xff
    7d18:      	mov	w8, #0xff               // =255
    7d1c:      	mov	x22, x0
    7d20:      	mov	x2, x29
    7d24:      	csel	w1, w25, w8, lo
    7d28:      	mov	x8, x0
    7d2c:      	lsl	w9, w1, #3
    7d30:      	str	w9, [x8], #0x4
    7d34:      	mov	w9, #0x4                // =4
    7d38:      	mov	x0, x8
    7d3c:      	blr	x9
    7d40:      	mov	w8, #0x1                // =1
    7d44:      	mov	x0, x19
    7d48:      	mov	x1, x22
    7d4c:      	b	0x993c <generic_kprobe_filter_arg+0x336c>
    7d50:      	cmp	w25, #0x1, lsl #12      // =0x1000
    7d54:      	str	wzr, [sp, #0x88]
    7d58:      	b.ls	0x8278 <generic_kprobe_filter_arg+0x1ca8>
    7d5c:      	mov	x22, xzr
    7d60:      	b	0x9954 <generic_kprobe_filter_arg+0x3384>
    7d64:      	ldr	x8, [x25]
    7d68:      	cmp	x11, x8
    7d6c:      	b.hi	0x7d78 <generic_kprobe_filter_arg+0x17a8>
    7d70:      	cmp	x8, x10
    7d74:      	b.ls	0x6868 <generic_kprobe_filter_arg+0x298>
    7d78:      	ldr	w10, [x23, #0x8]
    7d7c:      	cmp	w10, #0x19
    7d80:      	b.lo	0x66cc <generic_kprobe_filter_arg+0xfc>
    7d84:      	ldp	x12, x11, [x23, #0x20]
    7d88:      	cmp	w9, #0xc
    7d8c:      	b.eq	0x7d98 <generic_kprobe_filter_arg+0x17c8>
    7d90:      	cmp	w9, #0xa
    7d94:      	b.ne	0x83e8 <generic_kprobe_filter_arg+0x1e18>
    7d98:      	cmp	x12, x8
    7d9c:      	mov	w12, #0x1               // =1
    7da0:      	b.gt	0x83fc <generic_kprobe_filter_arg+0x1e2c>
    7da4:      	cmp	x8, x11
    7da8:      	b.le	0x6868 <generic_kprobe_filter_arg+0x298>
    7dac:      	b	0x83fc <generic_kprobe_filter_arg+0x1e2c>
    7db0:      	ldr	x10, [x25]
    7db4:      	cmp	x11, x10
    7db8:      	ccmp	x10, x8, #0x2, ls
    7dbc:      	cset	w8, ls
    7dc0:      	ldr	w11, [x23, #0x8]
    7dc4:      	cmp	w11, #0x19
    7dc8:      	b.lo	0x8e58 <generic_kprobe_filter_arg+0x2888>
    7dcc:      	ldp	x13, x12, [x23, #0x20]
    7dd0:      	cmp	w9, #0xc
    7dd4:      	b.eq	0x7de0 <generic_kprobe_filter_arg+0x1810>
    7dd8:      	cmp	w9, #0xa
    7ddc:      	b.ne	0x82e8 <generic_kprobe_filter_arg+0x1d18>
    7de0:      	cmp	x13, x10
    7de4:      	ccmp	x10, x12, #0x0, le
    7de8:      	cset	w12, le
    7dec:      	b	0x82f4 <generic_kprobe_filter_arg+0x1d24>
    7df0:      	ldrh	w22, [x25, #0x26]
    7df4:      	ldrb	w8, [x23, #0x10]
    7df8:      	adrp	x0, 0x7000 <generic_kprobe_filter_arg+0xa30>
    7dfc:      	add	x9, sp, #0xac
    7e00:      	add	x1, sp, #0xac
    7e04:      	str	w8, [sp, #0xac]
    7e08:      	mov	w8, #0x1                // =1
    7e0c:      	ldr	x0, [x0]
    7e10:      	blr	x8
    7e14:      	cbz	x0, 0x7e60 <generic_kprobe_filter_arg+0x1890>
    7e18:      	str	x22, [sp, #0x88]
    7e1c:      	mov	w8, #0x1                // =1
    7e20:      	add	x9, sp, #0x88
    7e24:      	add	x1, sp, #0x88
    7e28:      	blr	x8
    7e2c:      	ldr	w9, [x23, #0x4]
    7e30:      	mov	w8, wzr
    7e34:      	mov	w12, #0x1               // =1
    7e38:      	cmp	w9, #0x1d
    7e3c:      	b.hi	0x83c4 <generic_kprobe_filter_arg+0x1df4>
    7e40:      	mov	w10, #0x8400            // =33792
    7e44:      	lsl	w9, w12, w9
    7e48:      	movk	w10, #0x3003, lsl #16
    7e4c:      	tst	w9, w10
    7e50:      	b.eq	0x83ac <generic_kprobe_filter_arg+0x1ddc>
    7e54:      	cmp	x0, #0x0
    7e58:      	cset	w8, ne
    7e5c:      	b	0x83c4 <generic_kprobe_filter_arg+0x1df4>
    7e60:      	mov	x22, xzr
    7e64:      	mov	w12, #0x1               // =1
    7e68:      	b	0x83c8 <generic_kprobe_filter_arg+0x1df8>
    7e6c:      	cmp	w8, #0x101
    7e70:      	b.hs	0x8548 <generic_kprobe_filter_arg+0x1f78>
    7e74:      	mov	w11, #0x100             // =256
    7e78:      	b	0x8eec <generic_kprobe_filter_arg+0x291c>
    7e7c:      	ldr	x11, [x25]
    7e80:      	cmp	x11, x10
    7e84:      	b.hi	0x6868 <generic_kprobe_filter_arg+0x298>
    7e88:      	b	0x7e98 <generic_kprobe_filter_arg+0x18c8>
    7e8c:      	ldr	x11, [x25]
    7e90:      	cmp	x11, x10
    7e94:      	b.lo	0x6868 <generic_kprobe_filter_arg+0x298>
    7e98:      	ldr	w10, [x23, #0x8]
    7e9c:      	cmp	w10, #0x11
    7ea0:      	b.lo	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    7ea4:      	ldr	x11, [x23, #0x18]
    7ea8:      	cmp	w8, #0x2
    7eac:      	b.le	0x7ed0 <generic_kprobe_filter_arg+0x1900>
    7eb0:      	sub	w12, w8, #0x3
    7eb4:      	cmp	w12, #0x2
    7eb8:      	b.hs	0x7f04 <generic_kprobe_filter_arg+0x1934>
    7ebc:      	ldr	x12, [x25]
    7ec0:      	cmp	x12, x11
    7ec4:      	mov	w12, #0x1               // =1
    7ec8:      	b.eq	0x685c <generic_kprobe_filter_arg+0x28c>
    7ecc:      	b	0x88ec <generic_kprobe_filter_arg+0x231c>
    7ed0:      	cmp	w8, #0x1
    7ed4:      	b.eq	0x7fb0 <generic_kprobe_filter_arg+0x19e0>
    7ed8:      	cmp	w8, #0x2
    7edc:      	b.ne	0x88ec <generic_kprobe_filter_arg+0x231c>
    7ee0:      	cmp	w9, #0xc
    7ee4:      	b.eq	0x7ef0 <generic_kprobe_filter_arg+0x1920>
    7ee8:      	cmp	w9, #0xa
    7eec:      	b.ne	0x88dc <generic_kprobe_filter_arg+0x230c>
    7ef0:      	ldr	x12, [x25]
    7ef4:      	cmp	x12, x11
    7ef8:      	mov	w12, #0x1               // =1
    7efc:      	b.lt	0x6868 <generic_kprobe_filter_arg+0x298>
    7f00:      	b	0x88ec <generic_kprobe_filter_arg+0x231c>
    7f04:      	cmp	w8, #0xc
    7f08:      	mov	w12, #0x1               // =1
    7f0c:      	b.ne	0x88ec <generic_kprobe_filter_arg+0x231c>
    7f10:      	ldr	x12, [x25]
    7f14:      	tst	x12, x11
    7f18:      	mov	w12, #0x1               // =1
    7f1c:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    7f20:      	b	0x88ec <generic_kprobe_filter_arg+0x231c>
    7f24:      	cmp	w8, #0xc
    7f28:      	b.ne	0x80ac <generic_kprobe_filter_arg+0x1adc>
    7f2c:      	ldrb	w10, [x25]
    7f30:      	tst	w9, w10
    7f34:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    7f38:      	b	0x80ac <generic_kprobe_filter_arg+0x1adc>
    7f3c:      	cmp	w8, #0xc
    7f40:      	b.ne	0x80ec <generic_kprobe_filter_arg+0x1b1c>
    7f44:      	ldrh	w10, [x25]
    7f48:      	tst	w9, w10
    7f4c:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    7f50:      	b	0x80ec <generic_kprobe_filter_arg+0x1b1c>
    7f54:      	ldr	w9, [x23, #0x8]
    7f58:      	cmp	w9, #0xd
    7f5c:      	b.lo	0x6d8c <generic_kprobe_filter_arg+0x7bc>
    7f60:      	ldr	w10, [x23, #0x14]
    7f64:      	cbz	w10, 0x6d8c <generic_kprobe_filter_arg+0x7bc>
    7f68:      	cmp	w10, w8
    7f6c:      	b.eq	0x6bd0 <generic_kprobe_filter_arg+0x600>
    7f70:      	cmp	w9, #0x11
    7f74:      	b.lo	0x6d8c <generic_kprobe_filter_arg+0x7bc>
    7f78:      	ldr	w10, [x23, #0x18]
    7f7c:      	cbz	w10, 0x6d8c <generic_kprobe_filter_arg+0x7bc>
    7f80:      	cmp	w10, w8
    7f84:      	b.eq	0x6bd0 <generic_kprobe_filter_arg+0x600>
    7f88:      	cmp	w9, #0x15
    7f8c:      	b.lo	0x7fa4 <generic_kprobe_filter_arg+0x19d4>
    7f90:      	ldr	w9, [x23, #0x1c]
    7f94:      	cbz	w9, 0x7fa4 <generic_kprobe_filter_arg+0x19d4>
    7f98:      	cmp	w9, w8
    7f9c:      	cset	w22, eq
    7fa0:      	b	0x7fa8 <generic_kprobe_filter_arg+0x19d8>
    7fa4:      	mov	x22, xzr
    7fa8:      	ldr	x19, [sp, #0x30]
    7fac:      	b	0x93b4 <generic_kprobe_filter_arg+0x2de4>
    7fb0:      	cmp	w9, #0xc
    7fb4:      	b.eq	0x7fc0 <generic_kprobe_filter_arg+0x19f0>
    7fb8:      	cmp	w9, #0xa
    7fbc:      	b.ne	0x88c8 <generic_kprobe_filter_arg+0x22f8>
    7fc0:      	ldr	x12, [x25]
    7fc4:      	cmp	x12, x11
    7fc8:      	mov	w12, #0x1               // =1
    7fcc:      	b.gt	0x6868 <generic_kprobe_filter_arg+0x298>
    7fd0:      	b	0x88ec <generic_kprobe_filter_arg+0x231c>
    7fd4:      	ldp	w8, w11, [x23, #0x10]
    7fd8:      	ldrb	w9, [x25]
    7fdc:      	cmp	w8, w9
    7fe0:      	ldr	w10, [x23, #0x8]
    7fe4:      	ccmp	w11, w9, #0x0, ls
    7fe8:      	cset	w8, hs
    7fec:      	cmp	w10, #0x11
    7ff0:      	b.lo	0x912c <generic_kprobe_filter_arg+0x2b5c>
    7ff4:      	b	0x8018 <generic_kprobe_filter_arg+0x1a48>
    7ff8:      	ldp	w8, w11, [x23, #0x10]
    7ffc:      	ldrh	w9, [x25]
    8000:      	cmp	w8, w9
    8004:      	ldr	w10, [x23, #0x8]
    8008:      	ccmp	w11, w9, #0x0, ls
    800c:      	cset	w8, hs
    8010:      	cmp	w10, #0x11
    8014:      	b.lo	0x912c <generic_kprobe_filter_arg+0x2b5c>
    8018:      	ldp	w11, w12, [x23, #0x18]
    801c:      	cmp	w11, w9
    8020:      	ccmp	w12, w9, #0x0, ls
    8024:      	mov	w12, #0x1               // =1
    8028:      	csinc	w8, w8, wzr, lo
    802c:      	cmp	w10, #0x19
    8030:      	b.lo	0x912c <generic_kprobe_filter_arg+0x2b5c>
    8034:      	ldp	w11, w12, [x23, #0x20]
    8038:      	cmp	w11, w9
    803c:      	ccmp	w12, w9, #0x0, ls
    8040:      	mov	w12, #0x1               // =1
    8044:      	csinc	w8, w8, wzr, lo
    8048:      	cmp	w10, #0x21
    804c:      	b.lo	0x912c <generic_kprobe_filter_arg+0x2b5c>
    8050:      	ldp	w10, w11, [x23, #0x28]
    8054:      	cmp	w10, w9
    8058:      	ccmp	w11, w9, #0x0, ls
    805c:      	csinc	w8, w8, wzr, lo
    8060:      	b	0x912c <generic_kprobe_filter_arg+0x2b5c>
    8064:      	cmp	w8, #0x3
    8068:      	b.eq	0x8654 <generic_kprobe_filter_arg+0x2084>
    806c:      	cmp	w8, #0x7
    8070:      	b.ne	0x8644 <generic_kprobe_filter_arg+0x2074>
    8074:      	mov	w11, #0x9               // =9
    8078:      	b	0x8658 <generic_kprobe_filter_arg+0x2088>
    807c:      	and	w8, w29, #0xffff
    8080:      	cmp	w8, #0x201
    8084:      	b.hs	0x85dc <generic_kprobe_filter_arg+0x200c>
    8088:      	mov	w11, #0x200             // =512
    808c:      	b	0x8a20 <generic_kprobe_filter_arg+0x2450>
    8090:      	cmp	x0, #0x0
    8094:      	b	0x8448 <generic_kprobe_filter_arg+0x1e78>
    8098:      	mov	w22, #0x1               // =1
    809c:      	b	0x787c <generic_kprobe_filter_arg+0x12ac>
    80a0:      	ldrb	w10, [x25]
    80a4:      	cmp	w9, w10
    80a8:      	b.lo	0x6868 <generic_kprobe_filter_arg+0x298>
    80ac:      	ldr	w9, [x23, #0x8]
    80b0:      	cmp	w9, #0xd
    80b4:      	b.lo	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    80b8:      	ldr	w10, [x23, #0x14]
    80bc:      	cmp	w8, #0x2
    80c0:      	b.le	0x859c <generic_kprobe_filter_arg+0x1fcc>
    80c4:      	sub	w11, w8, #0x3
    80c8:      	cmp	w11, #0x2
    80cc:      	b.hs	0x8974 <generic_kprobe_filter_arg+0x23a4>
    80d0:      	ldrb	w11, [x25]
    80d4:      	cmp	w10, w11
    80d8:      	b.eq	0x685c <generic_kprobe_filter_arg+0x28c>
    80dc:      	b	0x8c28 <generic_kprobe_filter_arg+0x2658>
    80e0:      	ldrh	w10, [x25]
    80e4:      	cmp	w9, w10
    80e8:      	b.lo	0x6868 <generic_kprobe_filter_arg+0x298>
    80ec:      	ldr	w9, [x23, #0x8]
    80f0:      	cmp	w9, #0xd
    80f4:      	b.lo	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    80f8:      	ldr	w10, [x23, #0x14]
    80fc:      	cmp	w8, #0x2
    8100:      	b.le	0x85bc <generic_kprobe_filter_arg+0x1fec>
    8104:      	sub	w11, w8, #0x3
    8108:      	cmp	w11, #0x2
    810c:      	b.hs	0x898c <generic_kprobe_filter_arg+0x23bc>
    8110:      	ldrh	w11, [x25]
    8114:      	cmp	w10, w11
    8118:      	b.eq	0x685c <generic_kprobe_filter_arg+0x28c>
    811c:      	b	0x8c64 <generic_kprobe_filter_arg+0x2694>
    8120:      	ldr	w8, [x25]
    8124:      	cmp	w11, w8
    8128:      	b.hi	0x8134 <generic_kprobe_filter_arg+0x1b64>
    812c:      	cmp	w8, w10
    8130:      	b.ls	0x6868 <generic_kprobe_filter_arg+0x298>
    8134:      	ldr	w10, [x23, #0x8]
    8138:      	cmp	w10, #0x11
    813c:      	b.lo	0x66cc <generic_kprobe_filter_arg+0xfc>
    8140:      	ldp	w12, w11, [x23, #0x18]
    8144:      	mov	w13, #0x1               // =1
    8148:      	cmp	w9, #0xc
    814c:      	b.hi	0x87e4 <generic_kprobe_filter_arg+0x2214>
    8150:      	lsl	w13, w13, w9
    8154:      	mov	w14, #0x1402            // =5122
    8158:      	tst	w13, w14
    815c:      	b.eq	0x87e4 <generic_kprobe_filter_arg+0x2214>
    8160:      	cmp	w12, w8
    8164:      	mov	w12, #0x1               // =1
    8168:      	b.gt	0x87f8 <generic_kprobe_filter_arg+0x2228>
    816c:      	cmp	w8, w11
    8170:      	b.le	0x6868 <generic_kprobe_filter_arg+0x298>
    8174:      	b	0x87f8 <generic_kprobe_filter_arg+0x2228>
    8178:      	ldr	w10, [x25]
    817c:      	cmp	w11, w10
    8180:      	ccmp	w10, w8, #0x2, ls
    8184:      	cset	w8, ls
    8188:      	ldr	w11, [x23, #0x8]
    818c:      	cmp	w11, #0x11
    8190:      	b.lo	0x912c <generic_kprobe_filter_arg+0x2b5c>
    8194:      	ldp	w13, w12, [x23, #0x18]
    8198:      	mov	w14, #0x1               // =1
    819c:      	cmp	w9, #0xc
    81a0:      	b.hi	0x85ec <generic_kprobe_filter_arg+0x201c>
    81a4:      	lsl	w14, w14, w9
    81a8:      	mov	w1, #0x1402             // =5122
    81ac:      	tst	w14, w1
    81b0:      	b.eq	0x85ec <generic_kprobe_filter_arg+0x201c>
    81b4:      	cmp	w13, w10
    81b8:      	ccmp	w10, w12, #0x0, le
    81bc:      	cset	w12, le
    81c0:      	b	0x85f8 <generic_kprobe_filter_arg+0x2028>
    81c4:      	str	x29, [sp, #0x28]
    81c8:      	mov	x19, xzr
    81cc:      	mov	w22, wzr
    81d0:      	add	x29, x23, #0x10
    81d4:      	ldr	w8, [x29, x19, lsl #2]
    81d8:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x1a30>
    81dc:      	add	x9, sp, #0x60
    81e0:      	add	x1, sp, #0x60
    81e4:      	str	w8, [sp, #0x60]
    81e8:      	mov	w8, #0x1                // =1
    81ec:      	ldr	x0, [x0]
    81f0:      	blr	x8
    81f4:      	cbz	x0, 0x994c <generic_kprobe_filter_arg+0x337c>
    81f8:      	cbz	w25, 0x8254 <generic_kprobe_filter_arg+0x1c84>
    81fc:      	ldr	x9, [sp, #0x28]
    8200:      	mov	x8, xzr
    8204:      	mov	x10, x25
    8208:      	b	0x8220 <generic_kprobe_filter_arg+0x1c50>
    820c:      	add	x8, x8, #0x1
    8210:      	sub	x10, x10, #0x1
    8214:      	add	x9, x9, #0x1
    8218:      	cmp	x8, x25
    821c:      	b.eq	0x8254 <generic_kprobe_filter_arg+0x1c84>
    8220:      	mov	x11, xzr
    8224:      	cmp	x10, x11
    8228:      	b.eq	0x820c <generic_kprobe_filter_arg+0x1c3c>
    822c:      	ldrb	w12, [x0, x11]
    8230:      	cbz	w12, 0x8250 <generic_kprobe_filter_arg+0x1c80>
    8234:      	cmp	x11, #0x62
    8238:      	b.hi	0x820c <generic_kprobe_filter_arg+0x1c3c>
    823c:      	ldrb	w13, [x9, x11]
    8240:      	add	x11, x11, #0x1
    8244:      	cmp	w13, w12
    8248:      	b.eq	0x8224 <generic_kprobe_filter_arg+0x1c54>
    824c:      	b	0x820c <generic_kprobe_filter_arg+0x1c3c>
    8250:      	tbz	w8, #0x1f, 0x89a4 <generic_kprobe_filter_arg+0x23d4>
    8254:      	ldr	w9, [x23, #0x8]
    8258:      	add	w8, w22, #0xc
    825c:      	cmp	w8, w9
    8260:      	b.hs	0x994c <generic_kprobe_filter_arg+0x337c>
    8264:      	add	x19, x19, #0x1
    8268:      	add	w22, w22, #0x4
    826c:      	cmp	x19, #0x64
    8270:      	b.ne	0x81d4 <generic_kprobe_filter_arg+0x1c04>
    8274:      	b	0x994c <generic_kprobe_filter_arg+0x337c>
    8278:      	and	w8, w25, #0xffff
    827c:      	cmp	w8, #0x90
    8280:      	b.hi	0x8838 <generic_kprobe_filter_arg+0x2268>
    8284:      	and	w8, w25, #0xff
    8288:      	mov	w9, #0xab               // =171
    828c:      	tst	w25, #0xffff
    8290:      	mul	w8, w8, w9
    8294:      	mov	w9, #0x18               // =24
    8298:      	lsr	w8, w8, #12
    829c:      	msub	w8, w8, w9, w25
    82a0:      	b.eq	0x82b4 <generic_kprobe_filter_arg+0x1ce4>
    82a4:      	tst	w8, #0xff
    82a8:      	mov	w9, w25
    82ac:      	mov	w11, w25
    82b0:      	b.eq	0x82d0 <generic_kprobe_filter_arg+0x1d00>
    82b4:      	sub	w8, w25, w8, uxtb
    82b8:      	and	w9, w8, #0xffff
    82bc:      	add	w8, w8, #0x18
    82c0:      	and	w11, w8, #0xffff
    82c4:      	cmp	w9, #0x78
    82c8:      	b.hi	0x9640 <generic_kprobe_filter_arg+0x3070>
    82cc:      	mov	w9, w11
    82d0:      	and	w8, w9, #0xff
    82d4:      	mov	w9, #0xab               // =171
    82d8:      	mul	w8, w8, w9
    82dc:      	lsr	w8, w8, #12
    82e0:      	sub	w10, w8, #0x1
    82e4:      	b	0x9690 <generic_kprobe_filter_arg+0x30c0>
    82e8:      	cmp	x13, x10
    82ec:      	ccmp	x10, x12, #0x2, ls
    82f0:      	cset	w12, ls
    82f4:      	orr	w8, w8, w12
    82f8:      	cmp	w11, #0x29
    82fc:      	b.lo	0x8e58 <generic_kprobe_filter_arg+0x2888>
    8300:      	ldp	x13, x12, [x23, #0x30]
    8304:      	cmp	w9, #0xc
    8308:      	b.eq	0x8314 <generic_kprobe_filter_arg+0x1d44>
    830c:      	cmp	w9, #0xa
    8310:      	b.ne	0x8848 <generic_kprobe_filter_arg+0x2278>
    8314:      	cmp	x13, x10
    8318:      	ccmp	x10, x12, #0x0, le
    831c:      	cset	w12, le
    8320:      	b	0x8854 <generic_kprobe_filter_arg+0x2284>
    8324:      	mov	x19, xzr
    8328:      	cmp	w9, #0x29
    832c:      	b.ne	0x8338 <generic_kprobe_filter_arg+0x1d68>
    8330:      	cbz	x10, 0x8338 <generic_kprobe_filter_arg+0x1d68>
    8334:      	ldrb	w19, [x10, #0x3a]
    8338:      	cmp	w9, #0x29
    833c:      	b.eq	0x8348 <generic_kprobe_filter_arg+0x1d78>
    8340:      	cmp	w9, #0x7
    8344:      	b.ne	0x8638 <generic_kprobe_filter_arg+0x2068>
    8348:      	ldrb	w8, [x23, #0x10]
    834c:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x1a30>
    8350:      	add	x9, sp, #0xac
    8354:      	add	x1, sp, #0xac
    8358:      	str	w8, [sp, #0xac]
    835c:      	mov	w8, #0x1                // =1
    8360:      	ldr	x0, [x0]
    8364:      	blr	x8
    8368:      	cbz	x0, 0x83d8 <generic_kprobe_filter_arg+0x1e08>
    836c:      	str	x19, [sp, #0x88]
    8370:      	mov	w8, #0x1                // =1
    8374:      	add	x9, sp, #0x88
    8378:      	add	x1, sp, #0x88
    837c:      	blr	x8
    8380:      	ldr	w9, [x23, #0x4]
    8384:      	mov	w8, wzr
    8388:      	cmp	w9, #0x1d
    838c:      	b.hi	0x92f8 <generic_kprobe_filter_arg+0x2d28>
    8390:      	ldr	x19, [sp, #0x30]
    8394:      	mov	w12, #0x1               // =1
    8398:      	mov	w10, #0x8400            // =33792
    839c:      	lsl	w9, w12, w9
    83a0:      	movk	w10, #0x3003, lsl #16
    83a4:      	tst	w9, w10
    83a8:      	b.ne	0x7e54 <generic_kprobe_filter_arg+0x1884>
    83ac:      	mov	w10, #0x800             // =2048
    83b0:      	movk	w10, #0xc, lsl #16
    83b4:      	tst	w9, w10
    83b8:      	b.eq	0x83c4 <generic_kprobe_filter_arg+0x1df4>
    83bc:      	cmp	x0, #0x0
    83c0:      	cset	w8, eq
    83c4:      	mov	w22, w8
    83c8:      	ldp	x16, x15, [sp, #0x40]
    83cc:      	mov	w2, #0x5ea0             // =24224
    83d0:      	ldr	x17, [sp, #0x38]
    83d4:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    83d8:      	ldr	x19, [sp, #0x30]
    83dc:      	mov	x22, xzr
    83e0:      	mov	w12, #0x1               // =1
    83e4:      	b	0x83c8 <generic_kprobe_filter_arg+0x1df8>
    83e8:      	cmp	x12, x8
    83ec:      	mov	w12, #0x1               // =1
    83f0:      	b.hi	0x83fc <generic_kprobe_filter_arg+0x1e2c>
    83f4:      	cmp	x8, x11
    83f8:      	b.ls	0x6868 <generic_kprobe_filter_arg+0x298>
    83fc:      	cmp	w10, #0x29
    8400:      	b.lo	0x66cc <generic_kprobe_filter_arg+0xfc>
    8404:      	ldp	x12, x11, [x23, #0x30]
    8408:      	cmp	w9, #0xc
    840c:      	b.eq	0x8418 <generic_kprobe_filter_arg+0x1e48>
    8410:      	cmp	w9, #0xa
    8414:      	b.ne	0x8884 <generic_kprobe_filter_arg+0x22b4>
    8418:      	cmp	x12, x8
    841c:      	mov	w12, #0x1               // =1
    8420:      	b.gt	0x8898 <generic_kprobe_filter_arg+0x22c8>
    8424:      	cmp	x8, x11
    8428:      	b.le	0x6868 <generic_kprobe_filter_arg+0x298>
    842c:      	b	0x8898 <generic_kprobe_filter_arg+0x22c8>
    8430:      	ldr	w8, [x23, #0x4]
    8434:      	b	0x8440 <generic_kprobe_filter_arg+0x1e70>
    8438:      	ldr	w8, [x23, #0x4]
    843c:      	ldr	x19, [sp, #0x30]
    8440:      	and	w8, w8, #0xfffffffe
    8444:      	cmp	w8, #0x18
    8448:      	cset	w8, eq
    844c:      	ldp	x16, x15, [sp, #0x40]
    8450:      	mov	w2, #0x5ea0             // =24224
    8454:      	mov	w12, #0x1               // =1
    8458:      	mov	w22, w8
    845c:      	ldr	x17, [sp, #0x38]
    8460:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    8464:      	ldr	w11, [x25]
    8468:      	cmp	w11, w10
    846c:      	b.hi	0x6868 <generic_kprobe_filter_arg+0x298>
    8470:      	b	0x8480 <generic_kprobe_filter_arg+0x1eb0>
    8474:      	ldr	w11, [x25]
    8478:      	cmp	w11, w10
    847c:      	b.lo	0x6868 <generic_kprobe_filter_arg+0x298>
    8480:      	ldr	w10, [x23, #0x8]
    8484:      	cmp	w10, #0xd
    8488:      	b.lo	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    848c:      	ldr	w11, [x23, #0x14]
    8490:      	cmp	w8, #0x2
    8494:      	b.le	0x84b8 <generic_kprobe_filter_arg+0x1ee8>
    8498:      	sub	w12, w8, #0x3
    849c:      	cmp	w12, #0x2
    84a0:      	b.hs	0x84f8 <generic_kprobe_filter_arg+0x1f28>
    84a4:      	ldr	w12, [x25]
    84a8:      	cmp	w12, w11
    84ac:      	mov	w12, #0x1               // =1
    84b0:      	b.eq	0x685c <generic_kprobe_filter_arg+0x28c>
    84b4:      	b	0x8d84 <generic_kprobe_filter_arg+0x27b4>
    84b8:      	cmp	w8, #0x1
    84bc:      	b.eq	0x8518 <generic_kprobe_filter_arg+0x1f48>
    84c0:      	cmp	w8, #0x2
    84c4:      	b.ne	0x8d84 <generic_kprobe_filter_arg+0x27b4>
    84c8:      	mov	w12, #0x1               // =1
    84cc:      	cmp	w9, #0xc
    84d0:      	b.hi	0x8d74 <generic_kprobe_filter_arg+0x27a4>
    84d4:      	lsl	w12, w12, w9
    84d8:      	mov	w13, #0x1402            // =5122
    84dc:      	tst	w12, w13
    84e0:      	b.eq	0x8d74 <generic_kprobe_filter_arg+0x27a4>
    84e4:      	ldr	w12, [x25]
    84e8:      	cmp	w12, w11
    84ec:      	mov	w12, #0x1               // =1
    84f0:      	b.lt	0x6868 <generic_kprobe_filter_arg+0x298>
    84f4:      	b	0x8d84 <generic_kprobe_filter_arg+0x27b4>
    84f8:      	cmp	w8, #0xc
    84fc:      	mov	w12, #0x1               // =1
    8500:      	b.ne	0x8d84 <generic_kprobe_filter_arg+0x27b4>
    8504:      	ldr	w12, [x25]
    8508:      	tst	w12, w11
    850c:      	mov	w12, #0x1               // =1
    8510:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    8514:      	b	0x8d84 <generic_kprobe_filter_arg+0x27b4>
    8518:      	mov	w12, #0x1               // =1
    851c:      	cmp	w9, #0xc
    8520:      	b.hi	0x8d60 <generic_kprobe_filter_arg+0x2790>
    8524:      	lsl	w12, w12, w9
    8528:      	mov	w13, #0x1402            // =5122
    852c:      	tst	w12, w13
    8530:      	b.eq	0x8d60 <generic_kprobe_filter_arg+0x2790>
    8534:      	ldr	w12, [x25]
    8538:      	cmp	w12, w11
    853c:      	mov	w12, #0x1               // =1
    8540:      	b.gt	0x6868 <generic_kprobe_filter_arg+0x298>
    8544:      	b	0x8d84 <generic_kprobe_filter_arg+0x27b4>
    8548:      	and	w8, w29, #0xffff
    854c:      	cmp	w8, #0x201
    8550:      	b.hs	0x89ac <generic_kprobe_filter_arg+0x23dc>
    8554:      	mov	w11, #0x200             // =512
    8558:      	b	0x8eec <generic_kprobe_filter_arg+0x291c>
    855c:      	mov	x22, xzr
    8560:      	ldr	x19, [sp, #0x30]
    8564:      	ldr	w8, [x23, #0x4]
    8568:      	cmp	w8, #0x25
    856c:      	b.hi	0x761c <generic_kprobe_filter_arg+0x104c>
    8570:      	mov	x9, #0x50               // =80
    8574:      	ldp	x16, x15, [sp, #0x40]
    8578:      	mov	w12, #0x1               // =1
    857c:      	mov	w2, #0x5ea0             // =24224
    8580:      	movk	x9, #0xc00, lsl #16
    8584:      	ldr	x17, [sp, #0x38]
    8588:      	lsl	x8, x12, x8
    858c:      	movk	x9, #0x20, lsl #32
    8590:      	tst	x8, x9
    8594:      	b.ne	0x93e8 <generic_kprobe_filter_arg+0x2e18>
    8598:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    859c:      	cmp	w8, #0x1
    85a0:      	b.eq	0x8c1c <generic_kprobe_filter_arg+0x264c>
    85a4:      	cmp	w8, #0x2
    85a8:      	b.ne	0x8c28 <generic_kprobe_filter_arg+0x2658>
    85ac:      	ldrb	w11, [x25]
    85b0:      	cmp	w10, w11
    85b4:      	b.hi	0x6868 <generic_kprobe_filter_arg+0x298>
    85b8:      	b	0x8c28 <generic_kprobe_filter_arg+0x2658>
    85bc:      	cmp	w8, #0x1
    85c0:      	b.eq	0x8c58 <generic_kprobe_filter_arg+0x2688>
    85c4:      	cmp	w8, #0x2
    85c8:      	b.ne	0x8c64 <generic_kprobe_filter_arg+0x2694>
    85cc:      	ldrh	w11, [x25]
    85d0:      	cmp	w10, w11
    85d4:      	b.hi	0x6868 <generic_kprobe_filter_arg+0x298>
    85d8:      	b	0x8c64 <generic_kprobe_filter_arg+0x2694>
    85dc:      	cmp	w8, #0x401
    85e0:      	b.hs	0x8a0c <generic_kprobe_filter_arg+0x243c>
    85e4:      	mov	w11, #0x400             // =1024
    85e8:      	b	0x8a20 <generic_kprobe_filter_arg+0x2450>
    85ec:      	cmp	w13, w10
    85f0:      	ccmp	w10, w12, #0x2, ls
    85f4:      	cset	w12, ls
    85f8:      	orr	w8, w8, w12
    85fc:      	cmp	w11, #0x19
    8600:      	mov	w12, #0x1               // =1
    8604:      	b.lo	0x912c <generic_kprobe_filter_arg+0x2b5c>
    8608:      	ldp	w13, w12, [x23, #0x20]
    860c:      	mov	w14, #0x1               // =1
    8610:      	cmp	w9, #0xc
    8614:      	b.hi	0x8cb4 <generic_kprobe_filter_arg+0x26e4>
    8618:      	lsl	w14, w14, w9
    861c:      	mov	w1, #0x1402             // =5122
    8620:      	tst	w14, w1
    8624:      	b.eq	0x8cb4 <generic_kprobe_filter_arg+0x26e4>
    8628:      	cmp	w13, w10
    862c:      	ccmp	w10, w12, #0x0, le
    8630:      	cset	w12, le
    8634:      	b	0x8cc0 <generic_kprobe_filter_arg+0x26f0>
    8638:      	ldr	x19, [sp, #0x30]
    863c:      	mov	x22, xzr
    8640:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    8644:      	mov	w11, #0xa               // =10
    8648:      	b	0x8658 <generic_kprobe_filter_arg+0x2088>
    864c:      	mov	w11, #0x6               // =6
    8650:      	b	0x8658 <generic_kprobe_filter_arg+0x2088>
    8654:      	mov	w11, #0x8               // =8
    8658:      	add	x8, x23, #0x10
    865c:      	and	w9, w11, #0xf
    8660:      	ldr	w8, [x8, w9, uxtw #2]
    8664:      	cmn	w8, #0x1
    8668:      	b.eq	0x8718 <generic_kprobe_filter_arg+0x2148>
    866c:      	str	w8, [sp, #0x10]
    8670:      	stp	w13, w11, [sp, #0x1c]
    8674:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x1a30>
    8678:      	mov	w8, #0x1                // =1
    867c:      	add	x22, sp, #0x88
    8680:      	add	x1, sp, #0x88
    8684:      	str	x10, [sp, #0x28]
    8688:      	ldr	x0, [x0]
    868c:      	blr	x8
    8690:      	mov	x25, x0
    8694:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x1a30>
    8698:      	mov	w8, #0x1                // =1
    869c:      	ldr	x0, [x0]
    86a0:      	add	x1, sp, #0x88
    86a4:      	blr	x8
    86a8:      	mov	x22, xzr
    86ac:      	cbz	x25, 0x93b4 <generic_kprobe_filter_arg+0x2de4>
    86b0:      	ldp	x16, x15, [sp, #0x40]
    86b4:      	mov	w2, #0x5ea0             // =24224
    86b8:      	mov	w12, #0x1               // =1
    86bc:      	ldr	x17, [sp, #0x38]
    86c0:      	cbz	x0, 0x93c4 <generic_kprobe_filter_arg+0x2df4>
    86c4:      	mov	x8, x25
    86c8:      	ldr	w25, [sp, #0x20]
    86cc:      	mov	x22, x0
    86d0:      	mov	x0, x8
    86d4:      	str	x8, [sp, #0x8]
    86d8:      	cmp	w25, #0x5
    86dc:      	b.gt	0x872c <generic_kprobe_filter_arg+0x215c>
    86e0:      	strb	w29, [x0], #0x1
    86e4:      	ldr	x2, [sp, #0x28]
    86e8:      	mov	w8, #0x4                // =4
    86ec:      	mov	w1, w29
    86f0:      	blr	x8
    86f4:      	ldr	w8, [sp, #0x1c]
    86f8:      	subs	w8, w8, w29
    86fc:      	b.ls	0x8768 <generic_kprobe_filter_arg+0x2198>
    8700:      	ldr	x9, [sp, #0x8]
    8704:      	and	w1, w8, #0xfff
    8708:      	mov	w8, #0x4                // =4
    870c:      	add	x9, x9, x29
    8710:      	add	x0, x9, #0x1
    8714:      	b	0x8760 <generic_kprobe_filter_arg+0x2190>
    8718:      	mov	x22, xzr
    871c:      	ldr	w8, [x23, #0x4]
    8720:      	cmp	w8, #0x25
    8724:      	b.ls	0x93d0 <generic_kprobe_filter_arg+0x2e00>
    8728:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    872c:      	strh	w29, [x0], #0x2
    8730:      	ldr	x2, [sp, #0x28]
    8734:      	mov	w8, #0x4                // =4
    8738:      	mov	w1, w29
    873c:      	blr	x8
    8740:      	ldr	w8, [sp, #0x1c]
    8744:      	subs	w8, w8, w29
    8748:      	b.ls	0x8768 <generic_kprobe_filter_arg+0x2198>
    874c:      	ldr	x9, [sp, #0x8]
    8750:      	and	w1, w8, #0xfff
    8754:      	mov	w8, #0x4                // =4
    8758:      	add	x9, x9, x29
    875c:      	add	x0, x9, #0x2
    8760:      	mov	x2, x22
    8764:      	blr	x8
    8768:      	ldr	w8, [sp, #0x10]
    876c:      	cmp	w25, #0x4
    8770:      	mov	w12, #0x1               // =1
    8774:      	str	w8, [sp, #0x60]
    8778:      	b.le	0x87b0 <generic_kprobe_filter_arg+0x21e0>
    877c:      	cmp	w25, #0x7
    8780:      	b.gt	0x89e0 <generic_kprobe_filter_arg+0x2410>
    8784:      	cmp	w25, #0x5
    8788:      	b.eq	0x9368 <generic_kprobe_filter_arg+0x2d98>
    878c:      	cmp	w25, #0x6
    8790:      	b.eq	0x932c <generic_kprobe_filter_arg+0x2d5c>
    8794:      	cmp	w25, #0x7
    8798:      	b.ne	0x93f0 <generic_kprobe_filter_arg+0x2e20>
    879c:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x1a30>
    87a0:      	mov	w8, #0x1                // =1
    87a4:      	add	x9, sp, #0x60
    87a8:      	ldr	x0, [x0]
    87ac:      	b	0x938c <generic_kprobe_filter_arg+0x2dbc>
    87b0:      	cmp	w25, #0x1
    87b4:      	b.le	0x8e64 <generic_kprobe_filter_arg+0x2894>
    87b8:      	cmp	w25, #0x2
    87bc:      	b.eq	0x9354 <generic_kprobe_filter_arg+0x2d84>
    87c0:      	cmp	w25, #0x3
    87c4:      	b.eq	0x9318 <generic_kprobe_filter_arg+0x2d48>
    87c8:      	cmp	w25, #0x4
    87cc:      	b.ne	0x93f0 <generic_kprobe_filter_arg+0x2e20>
    87d0:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x1a30>
    87d4:      	mov	w8, #0x1                // =1
    87d8:      	add	x9, sp, #0x60
    87dc:      	ldr	x0, [x0]
    87e0:      	b	0x938c <generic_kprobe_filter_arg+0x2dbc>
    87e4:      	cmp	w12, w8
    87e8:      	mov	w12, #0x1               // =1
    87ec:      	b.hi	0x87f8 <generic_kprobe_filter_arg+0x2228>
    87f0:      	cmp	w8, w11
    87f4:      	b.ls	0x6868 <generic_kprobe_filter_arg+0x298>
    87f8:      	cmp	w10, #0x19
    87fc:      	b.lo	0x66cc <generic_kprobe_filter_arg+0xfc>
    8800:      	ldp	w12, w11, [x23, #0x20]
    8804:      	mov	w13, #0x1               // =1
    8808:      	cmp	w9, #0xc
    880c:      	b.hi	0x8d14 <generic_kprobe_filter_arg+0x2744>
    8810:      	lsl	w13, w13, w9
    8814:      	mov	w14, #0x1402            // =5122
    8818:      	tst	w13, w14
    881c:      	b.eq	0x8d14 <generic_kprobe_filter_arg+0x2744>
    8820:      	cmp	w12, w8
    8824:      	mov	w12, #0x1               // =1
    8828:      	b.gt	0x8d28 <generic_kprobe_filter_arg+0x2758>
    882c:      	cmp	w8, w11
    8830:      	b.le	0x6868 <generic_kprobe_filter_arg+0x298>
    8834:      	b	0x8d28 <generic_kprobe_filter_arg+0x2758>
    8838:      	cmp	w8, #0x101
    883c:      	b.hs	0x8d00 <generic_kprobe_filter_arg+0x2730>
    8840:      	mov	w11, #0x100             // =256
    8844:      	b	0x9640 <generic_kprobe_filter_arg+0x3070>
    8848:      	cmp	x13, x10
    884c:      	ccmp	x10, x12, #0x2, ls
    8850:      	cset	w12, ls
    8854:      	orr	w8, w8, w12
    8858:      	cmp	w11, #0x39
    885c:      	b.lo	0x8e58 <generic_kprobe_filter_arg+0x2888>
    8860:      	ldp	x12, x11, [x23, #0x40]
    8864:      	cmp	w9, #0xc
    8868:      	b.eq	0x8874 <generic_kprobe_filter_arg+0x22a4>
    886c:      	cmp	w9, #0xa
    8870:      	b.ne	0x8e48 <generic_kprobe_filter_arg+0x2878>
    8874:      	cmp	x12, x10
    8878:      	ccmp	x10, x11, #0x0, le
    887c:      	cset	w9, le
    8880:      	b	0x8e54 <generic_kprobe_filter_arg+0x2884>
    8884:      	cmp	x12, x8
    8888:      	mov	w12, #0x1               // =1
    888c:      	b.hi	0x8898 <generic_kprobe_filter_arg+0x22c8>
    8890:      	cmp	x8, x11
    8894:      	b.ls	0x6868 <generic_kprobe_filter_arg+0x298>
    8898:      	cmp	w10, #0x39
    889c:      	b.lo	0x66cc <generic_kprobe_filter_arg+0xfc>
    88a0:      	ldp	x11, x10, [x23, #0x40]
    88a4:      	cmp	w9, #0xc
    88a8:      	b.eq	0x88b4 <generic_kprobe_filter_arg+0x22e4>
    88ac:      	cmp	w9, #0xa
    88b0:      	b.ne	0x8e84 <generic_kprobe_filter_arg+0x28b4>
    88b4:      	cmp	x11, x8
    88b8:      	b.gt	0x66cc <generic_kprobe_filter_arg+0xfc>
    88bc:      	cmp	x8, x10
    88c0:      	b.le	0x6868 <generic_kprobe_filter_arg+0x298>
    88c4:      	b	0x66cc <generic_kprobe_filter_arg+0xfc>
    88c8:      	ldr	x12, [x25]
    88cc:      	cmp	x12, x11
    88d0:      	mov	w12, #0x1               // =1
    88d4:      	b.hi	0x6868 <generic_kprobe_filter_arg+0x298>
    88d8:      	b	0x88ec <generic_kprobe_filter_arg+0x231c>
    88dc:      	ldr	x12, [x25]
    88e0:      	cmp	x12, x11
    88e4:      	mov	w12, #0x1               // =1
    88e8:      	b.lo	0x6868 <generic_kprobe_filter_arg+0x298>
    88ec:      	cmp	w10, #0x19
    88f0:      	b.lo	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    88f4:      	ldr	x11, [x23, #0x20]
    88f8:      	cmp	w8, #0x2
    88fc:      	b.le	0x8920 <generic_kprobe_filter_arg+0x2350>
    8900:      	sub	w12, w8, #0x3
    8904:      	cmp	w12, #0x2
    8908:      	b.hs	0x8954 <generic_kprobe_filter_arg+0x2384>
    890c:      	ldr	x12, [x25]
    8910:      	cmp	x12, x11
    8914:      	mov	w12, #0x1               // =1
    8918:      	b.eq	0x685c <generic_kprobe_filter_arg+0x28c>
    891c:      	b	0x9158 <generic_kprobe_filter_arg+0x2b88>
    8920:      	cmp	w8, #0x1
    8924:      	b.eq	0x89bc <generic_kprobe_filter_arg+0x23ec>
    8928:      	cmp	w8, #0x2
    892c:      	b.ne	0x9158 <generic_kprobe_filter_arg+0x2b88>
    8930:      	cmp	w9, #0xc
    8934:      	b.eq	0x8940 <generic_kprobe_filter_arg+0x2370>
    8938:      	cmp	w9, #0xa
    893c:      	b.ne	0x9148 <generic_kprobe_filter_arg+0x2b78>
    8940:      	ldr	x12, [x25]
    8944:      	cmp	x12, x11
    8948:      	mov	w12, #0x1               // =1
    894c:      	b.lt	0x6868 <generic_kprobe_filter_arg+0x298>
    8950:      	b	0x9158 <generic_kprobe_filter_arg+0x2b88>
    8954:      	cmp	w8, #0xc
    8958:      	mov	w12, #0x1               // =1
    895c:      	b.ne	0x9158 <generic_kprobe_filter_arg+0x2b88>
    8960:      	ldr	x12, [x25]
    8964:      	tst	x12, x11
    8968:      	mov	w12, #0x1               // =1
    896c:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    8970:      	b	0x9158 <generic_kprobe_filter_arg+0x2b88>
    8974:      	cmp	w8, #0xc
    8978:      	b.ne	0x8c28 <generic_kprobe_filter_arg+0x2658>
    897c:      	ldrb	w11, [x25]
    8980:      	tst	w10, w11
    8984:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    8988:      	b	0x8c28 <generic_kprobe_filter_arg+0x2658>
    898c:      	cmp	w8, #0xc
    8990:      	b.ne	0x8c64 <generic_kprobe_filter_arg+0x2694>
    8994:      	ldrh	w11, [x25]
    8998:      	tst	w10, w11
    899c:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    89a0:      	b	0x8c64 <generic_kprobe_filter_arg+0x2694>
    89a4:      	mov	w22, #0x1               // =1
    89a8:      	b	0x9950 <generic_kprobe_filter_arg+0x3380>
    89ac:      	cmp	w8, #0x401
    89b0:      	b.hs	0x8ed8 <generic_kprobe_filter_arg+0x2908>
    89b4:      	mov	w11, #0x400             // =1024
    89b8:      	b	0x8eec <generic_kprobe_filter_arg+0x291c>
    89bc:      	cmp	w9, #0xc
    89c0:      	b.eq	0x89cc <generic_kprobe_filter_arg+0x23fc>
    89c4:      	cmp	w9, #0xa
    89c8:      	b.ne	0x9134 <generic_kprobe_filter_arg+0x2b64>
    89cc:      	ldr	x12, [x25]
    89d0:      	cmp	x12, x11
    89d4:      	mov	w12, #0x1               // =1
    89d8:      	b.gt	0x6868 <generic_kprobe_filter_arg+0x298>
    89dc:      	b	0x9158 <generic_kprobe_filter_arg+0x2b88>
    89e0:      	cmp	w25, #0x8
    89e4:      	b.eq	0x937c <generic_kprobe_filter_arg+0x2dac>
    89e8:      	cmp	w25, #0x9
    89ec:      	b.eq	0x9340 <generic_kprobe_filter_arg+0x2d70>
    89f0:      	cmp	w25, #0xa
    89f4:      	b.ne	0x93f0 <generic_kprobe_filter_arg+0x2e20>
    89f8:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x1a30>
    89fc:      	mov	w8, #0x1                // =1
    8a00:      	add	x9, sp, #0x60
    8a04:      	ldr	x0, [x0]
    8a08:      	b	0x938c <generic_kprobe_filter_arg+0x2dbc>
    8a0c:      	and	w8, w29, #0xffff
    8a10:      	mov	w9, #0x1000             // =4096
    8a14:      	cmp	w8, #0x800
    8a18:      	mov	w8, #0x800              // =2048
    8a1c:      	csel	w11, w9, w8, hi
    8a20:      	sub	w8, w11, #0x100
    8a24:      	ror	w8, w8, #0x8
    8a28:      	cmp	w8, #0x2
    8a2c:      	b.gt	0x8a44 <generic_kprobe_filter_arg+0x2474>
    8a30:      	cbz	w8, 0x8a64 <generic_kprobe_filter_arg+0x2494>
    8a34:      	cmp	w8, #0x1
    8a38:      	b.ne	0x8a5c <generic_kprobe_filter_arg+0x248c>
    8a3c:      	mov	w10, #0x7               // =7
    8a40:      	b	0x8a70 <generic_kprobe_filter_arg+0x24a0>
    8a44:      	cmp	w8, #0x3
    8a48:      	b.eq	0x8a6c <generic_kprobe_filter_arg+0x249c>
    8a4c:      	cmp	w8, #0x7
    8a50:      	b.ne	0x8a5c <generic_kprobe_filter_arg+0x248c>
    8a54:      	mov	w10, #0x9               // =9
    8a58:      	b	0x8a70 <generic_kprobe_filter_arg+0x24a0>
    8a5c:      	mov	w10, #0xa               // =10
    8a60:      	b	0x8a70 <generic_kprobe_filter_arg+0x24a0>
    8a64:      	mov	w10, #0x6               // =6
    8a68:      	b	0x8a70 <generic_kprobe_filter_arg+0x24a0>
    8a6c:      	mov	w10, #0x8               // =8
    8a70:      	add	x8, x23, #0x10
    8a74:      	and	w9, w10, #0xf
    8a78:      	ldr	w8, [x8, w9, uxtw #2]
    8a7c:      	cmn	w8, #0x1
    8a80:      	b.eq	0x93b0 <generic_kprobe_filter_arg+0x2de0>
    8a84:      	str	w8, [sp, #0x10]
    8a88:      	str	w11, [sp, #0x1c]
    8a8c:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x1a30>
    8a90:      	mov	w8, #0x1                // =1
    8a94:      	add	x22, sp, #0x88
    8a98:      	add	x1, sp, #0x88
    8a9c:      	str	w10, [sp, #0x28]
    8aa0:      	ldr	x0, [x0]
    8aa4:      	blr	x8
    8aa8:      	str	x0, [sp, #0x20]
    8aac:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x1a30>
    8ab0:      	mov	w8, #0x1                // =1
    8ab4:      	add	x1, sp, #0x88
    8ab8:      	ldr	x0, [x0]
    8abc:      	blr	x8
    8ac0:      	ldr	x9, [sp, #0x20]
    8ac4:      	mov	x22, xzr
    8ac8:      	cbz	x9, 0x93b4 <generic_kprobe_filter_arg+0x2de4>
    8acc:      	ldp	x16, x15, [sp, #0x40]
    8ad0:      	mov	w2, #0x5ea0             // =24224
    8ad4:      	mov	w12, #0x1               // =1
    8ad8:      	ldr	x17, [sp, #0x38]
    8adc:      	cbz	x0, 0x93c4 <generic_kprobe_filter_arg+0x2df4>
    8ae0:      	mov	x8, x9
    8ae4:      	ldr	w9, [sp, #0x28]
    8ae8:      	mov	x22, x0
    8aec:      	add	x2, x25, #0x4
    8af0:      	mov	x25, x8
    8af4:      	mov	x0, x8
    8af8:      	cmp	w9, #0x5
    8afc:      	b.gt	0x8b30 <generic_kprobe_filter_arg+0x2560>
    8b00:      	strb	w29, [x0], #0x1
    8b04:      	mov	w8, #0x4                // =4
    8b08:      	mov	w1, w29
    8b0c:      	blr	x8
    8b10:      	ldr	w8, [sp, #0x1c]
    8b14:      	subs	w8, w8, w29
    8b18:      	b.ls	0x8b64 <generic_kprobe_filter_arg+0x2594>
    8b1c:      	add	x9, x25, x29
    8b20:      	and	w1, w8, #0xfff
    8b24:      	mov	w8, #0x4                // =4
    8b28:      	add	x0, x9, #0x1
    8b2c:      	b	0x8b5c <generic_kprobe_filter_arg+0x258c>
    8b30:      	strh	w29, [x0], #0x2
    8b34:      	mov	w8, #0x4                // =4
    8b38:      	mov	w1, w29
    8b3c:      	blr	x8
    8b40:      	ldr	w8, [sp, #0x1c]
    8b44:      	subs	w8, w8, w29
    8b48:      	b.ls	0x8b64 <generic_kprobe_filter_arg+0x2594>
    8b4c:      	add	x9, x25, x29
    8b50:      	and	w1, w8, #0xfff
    8b54:      	mov	w8, #0x4                // =4
    8b58:      	add	x0, x9, #0x2
    8b5c:      	mov	x2, x22
    8b60:      	blr	x8
    8b64:      	ldr	w8, [sp, #0x10]
    8b68:      	ldp	x16, x15, [sp, #0x40]
    8b6c:      	mov	w2, #0x5ea0             // =24224
    8b70:      	mov	w12, #0x1               // =1
    8b74:      	ldr	x17, [sp, #0x38]
    8b78:      	str	w8, [sp, #0x60]
    8b7c:      	ldr	w8, [sp, #0x28]
    8b80:      	cmp	w8, #0x4
    8b84:      	b.le	0x8bbc <generic_kprobe_filter_arg+0x25ec>
    8b88:      	cmp	w8, #0x7
    8b8c:      	b.gt	0x8bf0 <generic_kprobe_filter_arg+0x2620>
    8b90:      	cmp	w8, #0x5
    8b94:      	b.eq	0x926c <generic_kprobe_filter_arg+0x2c9c>
    8b98:      	cmp	w8, #0x6
    8b9c:      	b.eq	0x9230 <generic_kprobe_filter_arg+0x2c60>
    8ba0:      	cmp	w8, #0x7
    8ba4:      	b.ne	0x6d8c <generic_kprobe_filter_arg+0x7bc>
    8ba8:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x1a30>
    8bac:      	mov	w8, #0x1                // =1
    8bb0:      	add	x9, sp, #0x60
    8bb4:      	ldr	x0, [x0]
    8bb8:      	b	0x9290 <generic_kprobe_filter_arg+0x2cc0>
    8bbc:      	cmp	w8, #0x1
    8bc0:      	b.le	0x8c94 <generic_kprobe_filter_arg+0x26c4>
    8bc4:      	cmp	w8, #0x2
    8bc8:      	b.eq	0x9258 <generic_kprobe_filter_arg+0x2c88>
    8bcc:      	cmp	w8, #0x3
    8bd0:      	b.eq	0x921c <generic_kprobe_filter_arg+0x2c4c>
    8bd4:      	cmp	w8, #0x4
    8bd8:      	b.ne	0x6d8c <generic_kprobe_filter_arg+0x7bc>
    8bdc:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x1a30>
    8be0:      	mov	w8, #0x1                // =1
    8be4:      	add	x9, sp, #0x60
    8be8:      	ldr	x0, [x0]
    8bec:      	b	0x9290 <generic_kprobe_filter_arg+0x2cc0>
    8bf0:      	cmp	w8, #0x8
    8bf4:      	b.eq	0x9280 <generic_kprobe_filter_arg+0x2cb0>
    8bf8:      	cmp	w8, #0x9
    8bfc:      	b.eq	0x9244 <generic_kprobe_filter_arg+0x2c74>
    8c00:      	cmp	w8, #0xa
    8c04:      	b.ne	0x6d8c <generic_kprobe_filter_arg+0x7bc>
    8c08:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x1a30>
    8c0c:      	mov	w8, #0x1                // =1
    8c10:      	add	x9, sp, #0x60
    8c14:      	ldr	x0, [x0]
    8c18:      	b	0x9290 <generic_kprobe_filter_arg+0x2cc0>
    8c1c:      	ldrb	w11, [x25]
    8c20:      	cmp	w10, w11
    8c24:      	b.lo	0x6868 <generic_kprobe_filter_arg+0x298>
    8c28:      	cmp	w9, #0x11
    8c2c:      	b.lo	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    8c30:      	ldr	w10, [x23, #0x18]
    8c34:      	cmp	w8, #0x2
    8c38:      	b.le	0x8e98 <generic_kprobe_filter_arg+0x28c8>
    8c3c:      	sub	w11, w8, #0x3
    8c40:      	cmp	w11, #0x2
    8c44:      	b.hs	0x91d8 <generic_kprobe_filter_arg+0x2c08>
    8c48:      	ldrb	w11, [x25]
    8c4c:      	cmp	w10, w11
    8c50:      	b.eq	0x685c <generic_kprobe_filter_arg+0x28c>
    8c54:      	b	0x94e4 <generic_kprobe_filter_arg+0x2f14>
    8c58:      	ldrh	w11, [x25]
    8c5c:      	cmp	w10, w11
    8c60:      	b.lo	0x6868 <generic_kprobe_filter_arg+0x298>
    8c64:      	cmp	w9, #0x11
    8c68:      	b.lo	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    8c6c:      	ldr	w10, [x23, #0x18]
    8c70:      	cmp	w8, #0x2
    8c74:      	b.le	0x8eb8 <generic_kprobe_filter_arg+0x28e8>
    8c78:      	sub	w11, w8, #0x3
    8c7c:      	cmp	w11, #0x2
    8c80:      	b.hs	0x91f0 <generic_kprobe_filter_arg+0x2c20>
    8c84:      	ldrh	w11, [x25]
    8c88:      	cmp	w10, w11
    8c8c:      	b.eq	0x685c <generic_kprobe_filter_arg+0x28c>
    8c90:      	b	0x9528 <generic_kprobe_filter_arg+0x2f58>
    8c94:      	cbz	w8, 0x9208 <generic_kprobe_filter_arg+0x2c38>
    8c98:      	cmp	w8, #0x1
    8c9c:      	b.ne	0x6d8c <generic_kprobe_filter_arg+0x7bc>
    8ca0:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x1a30>
    8ca4:      	mov	w8, #0x1                // =1
    8ca8:      	add	x9, sp, #0x60
    8cac:      	ldr	x0, [x0]
    8cb0:      	b	0x9290 <generic_kprobe_filter_arg+0x2cc0>
    8cb4:      	cmp	w13, w10
    8cb8:      	ccmp	w10, w12, #0x2, ls
    8cbc:      	cset	w12, ls
    8cc0:      	orr	w8, w8, w12
    8cc4:      	cmp	w11, #0x21
    8cc8:      	mov	w12, #0x1               // =1
    8ccc:      	b.lo	0x912c <generic_kprobe_filter_arg+0x2b5c>
    8cd0:      	ldp	w12, w11, [x23, #0x28]
    8cd4:      	mov	w13, #0x1               // =1
    8cd8:      	cmp	w9, #0xc
    8cdc:      	b.hi	0x9118 <generic_kprobe_filter_arg+0x2b48>
    8ce0:      	lsl	w9, w13, w9
    8ce4:      	mov	w13, #0x1402            // =5122
    8ce8:      	tst	w9, w13
    8cec:      	b.eq	0x9118 <generic_kprobe_filter_arg+0x2b48>
    8cf0:      	cmp	w12, w10
    8cf4:      	ccmp	w10, w11, #0x0, le
    8cf8:      	cset	w9, le
    8cfc:      	b	0x9124 <generic_kprobe_filter_arg+0x2b54>
    8d00:      	and	w8, w25, #0xffff
    8d04:      	cmp	w8, #0x201
    8d08:      	b.hs	0x92b4 <generic_kprobe_filter_arg+0x2ce4>
    8d0c:      	mov	w11, #0x200             // =512
    8d10:      	b	0x9640 <generic_kprobe_filter_arg+0x3070>
    8d14:      	cmp	w12, w8
    8d18:      	mov	w12, #0x1               // =1
    8d1c:      	b.hi	0x8d28 <generic_kprobe_filter_arg+0x2758>
    8d20:      	cmp	w8, w11
    8d24:      	b.ls	0x6868 <generic_kprobe_filter_arg+0x298>
    8d28:      	cmp	w10, #0x21
    8d2c:      	b.lo	0x66cc <generic_kprobe_filter_arg+0xfc>
    8d30:      	ldp	w11, w10, [x23, #0x28]
    8d34:      	cmp	w9, #0xc
    8d38:      	b.hi	0x92c4 <generic_kprobe_filter_arg+0x2cf4>
    8d3c:      	lsl	w9, w12, w9
    8d40:      	mov	w13, #0x1402            // =5122
    8d44:      	tst	w9, w13
    8d48:      	b.eq	0x92c4 <generic_kprobe_filter_arg+0x2cf4>
    8d4c:      	cmp	w11, w8
    8d50:      	b.gt	0x66cc <generic_kprobe_filter_arg+0xfc>
    8d54:      	cmp	w8, w10
    8d58:      	b.le	0x6868 <generic_kprobe_filter_arg+0x298>
    8d5c:      	b	0x66cc <generic_kprobe_filter_arg+0xfc>
    8d60:      	ldr	w12, [x25]
    8d64:      	cmp	w12, w11
    8d68:      	mov	w12, #0x1               // =1
    8d6c:      	b.hi	0x6868 <generic_kprobe_filter_arg+0x298>
    8d70:      	b	0x8d84 <generic_kprobe_filter_arg+0x27b4>
    8d74:      	ldr	w12, [x25]
    8d78:      	cmp	w12, w11
    8d7c:      	mov	w12, #0x1               // =1
    8d80:      	b.lo	0x6868 <generic_kprobe_filter_arg+0x298>
    8d84:      	cmp	w10, #0x11
    8d88:      	b.lo	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    8d8c:      	ldr	w11, [x23, #0x18]
    8d90:      	cmp	w8, #0x2
    8d94:      	b.le	0x8db8 <generic_kprobe_filter_arg+0x27e8>
    8d98:      	sub	w12, w8, #0x3
    8d9c:      	cmp	w12, #0x2
    8da0:      	b.hs	0x8df8 <generic_kprobe_filter_arg+0x2828>
    8da4:      	ldr	w12, [x25]
    8da8:      	cmp	w12, w11
    8dac:      	mov	w12, #0x1               // =1
    8db0:      	b.eq	0x685c <generic_kprobe_filter_arg+0x28c>
    8db4:      	b	0x9584 <generic_kprobe_filter_arg+0x2fb4>
    8db8:      	cmp	w8, #0x1
    8dbc:      	b.eq	0x8e18 <generic_kprobe_filter_arg+0x2848>
    8dc0:      	cmp	w8, #0x2
    8dc4:      	b.ne	0x9584 <generic_kprobe_filter_arg+0x2fb4>
    8dc8:      	mov	w12, #0x1               // =1
    8dcc:      	cmp	w9, #0xc
    8dd0:      	b.hi	0x9574 <generic_kprobe_filter_arg+0x2fa4>
    8dd4:      	lsl	w12, w12, w9
    8dd8:      	mov	w13, #0x1402            // =5122
    8ddc:      	tst	w12, w13
    8de0:      	b.eq	0x9574 <generic_kprobe_filter_arg+0x2fa4>
    8de4:      	ldr	w12, [x25]
    8de8:      	cmp	w12, w11
    8dec:      	mov	w12, #0x1               // =1
    8df0:      	b.lt	0x6868 <generic_kprobe_filter_arg+0x298>
    8df4:      	b	0x9584 <generic_kprobe_filter_arg+0x2fb4>
    8df8:      	cmp	w8, #0xc
    8dfc:      	mov	w12, #0x1               // =1
    8e00:      	b.ne	0x9584 <generic_kprobe_filter_arg+0x2fb4>
    8e04:      	ldr	w12, [x25]
    8e08:      	tst	w12, w11
    8e0c:      	mov	w12, #0x1               // =1
    8e10:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    8e14:      	b	0x9584 <generic_kprobe_filter_arg+0x2fb4>
    8e18:      	mov	w12, #0x1               // =1
    8e1c:      	cmp	w9, #0xc
    8e20:      	b.hi	0x9560 <generic_kprobe_filter_arg+0x2f90>
    8e24:      	lsl	w12, w12, w9
    8e28:      	mov	w13, #0x1402            // =5122
    8e2c:      	tst	w12, w13
    8e30:      	b.eq	0x9560 <generic_kprobe_filter_arg+0x2f90>
    8e34:      	ldr	w12, [x25]
    8e38:      	cmp	w12, w11
    8e3c:      	mov	w12, #0x1               // =1
    8e40:      	b.gt	0x6868 <generic_kprobe_filter_arg+0x298>
    8e44:      	b	0x9584 <generic_kprobe_filter_arg+0x2fb4>
    8e48:      	cmp	x12, x10
    8e4c:      	ccmp	x10, x11, #0x2, ls
    8e50:      	cset	w9, ls
    8e54:      	orr	w8, w8, w9
    8e58:      	mov	w12, #0x1               // =1
    8e5c:      	tbz	w8, #0x0, 0x6868 <generic_kprobe_filter_arg+0x298>
    8e60:      	b	0x66cc <generic_kprobe_filter_arg+0xfc>
    8e64:      	cbz	w25, 0x9304 <generic_kprobe_filter_arg+0x2d34>
    8e68:      	cmp	w25, #0x1
    8e6c:      	b.ne	0x93f0 <generic_kprobe_filter_arg+0x2e20>
    8e70:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x1a30>
    8e74:      	mov	w8, #0x1                // =1
    8e78:      	add	x9, sp, #0x60
    8e7c:      	ldr	x0, [x0]
    8e80:      	b	0x938c <generic_kprobe_filter_arg+0x2dbc>
    8e84:      	cmp	x11, x8
    8e88:      	b.hi	0x66cc <generic_kprobe_filter_arg+0xfc>
    8e8c:      	cmp	x8, x10
    8e90:      	b.ls	0x6868 <generic_kprobe_filter_arg+0x298>
    8e94:      	b	0x66cc <generic_kprobe_filter_arg+0xfc>
    8e98:      	cmp	w8, #0x1
    8e9c:      	b.eq	0x94d8 <generic_kprobe_filter_arg+0x2f08>
    8ea0:      	cmp	w8, #0x2
    8ea4:      	b.ne	0x94e4 <generic_kprobe_filter_arg+0x2f14>
    8ea8:      	ldrb	w11, [x25]
    8eac:      	cmp	w10, w11
    8eb0:      	b.hi	0x6868 <generic_kprobe_filter_arg+0x298>
    8eb4:      	b	0x94e4 <generic_kprobe_filter_arg+0x2f14>
    8eb8:      	cmp	w8, #0x1
    8ebc:      	b.eq	0x951c <generic_kprobe_filter_arg+0x2f4c>
    8ec0:      	cmp	w8, #0x2
    8ec4:      	b.ne	0x9528 <generic_kprobe_filter_arg+0x2f58>
    8ec8:      	ldrh	w11, [x25]
    8ecc:      	cmp	w10, w11
    8ed0:      	b.hi	0x6868 <generic_kprobe_filter_arg+0x298>
    8ed4:      	b	0x9528 <generic_kprobe_filter_arg+0x2f58>
    8ed8:      	and	w8, w29, #0xffff
    8edc:      	mov	w9, #0x1000             // =4096
    8ee0:      	cmp	w8, #0x800
    8ee4:      	mov	w8, #0x800              // =2048
    8ee8:      	csel	w11, w9, w8, hi
    8eec:      	sub	w8, w11, #0x100
    8ef0:      	ror	w8, w8, #0x8
    8ef4:      	cmp	w8, #0x2
    8ef8:      	b.gt	0x8f10 <generic_kprobe_filter_arg+0x2940>
    8efc:      	cbz	w8, 0x8f30 <generic_kprobe_filter_arg+0x2960>
    8f00:      	cmp	w8, #0x1
    8f04:      	b.ne	0x8f28 <generic_kprobe_filter_arg+0x2958>
    8f08:      	mov	w10, #0x7               // =7
    8f0c:      	b	0x8f3c <generic_kprobe_filter_arg+0x296c>
    8f10:      	cmp	w8, #0x3
    8f14:      	b.eq	0x8f38 <generic_kprobe_filter_arg+0x2968>
    8f18:      	cmp	w8, #0x7
    8f1c:      	b.ne	0x8f28 <generic_kprobe_filter_arg+0x2958>
    8f20:      	mov	w10, #0x9               // =9
    8f24:      	b	0x8f3c <generic_kprobe_filter_arg+0x296c>
    8f28:      	mov	w10, #0xa               // =10
    8f2c:      	b	0x8f3c <generic_kprobe_filter_arg+0x296c>
    8f30:      	mov	w10, #0x6               // =6
    8f34:      	b	0x8f3c <generic_kprobe_filter_arg+0x296c>
    8f38:      	mov	w10, #0x8               // =8
    8f3c:      	add	x8, x23, #0x10
    8f40:      	and	w9, w10, #0xf
    8f44:      	ldr	w8, [x8, w9, uxtw #2]
    8f48:      	cmn	w8, #0x1
    8f4c:      	b.eq	0x9000 <generic_kprobe_filter_arg+0x2a30>
    8f50:      	str	w8, [sp, #0x1c]
    8f54:      	str	w11, [sp, #0x10]
    8f58:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x1a30>
    8f5c:      	mov	w8, #0x1                // =1
    8f60:      	add	x22, sp, #0x88
    8f64:      	add	x1, sp, #0x88
    8f68:      	str	w10, [sp, #0x28]
    8f6c:      	ldr	x0, [x0]
    8f70:      	blr	x8
    8f74:      	str	x0, [sp, #0x20]
    8f78:      	adrp	x0, 0x8000 <generic_kprobe_filter_arg+0x1a30>
    8f7c:      	mov	w8, #0x1                // =1
    8f80:      	add	x1, sp, #0x88
    8f84:      	ldr	x0, [x0]
    8f88:      	blr	x8
    8f8c:      	ldr	x9, [sp, #0x20]
    8f90:      	mov	x22, xzr
    8f94:      	cbz	x9, 0x7880 <generic_kprobe_filter_arg+0x12b0>
    8f98:      	ldp	x16, x15, [sp, #0x40]
    8f9c:      	mov	w2, #0x5ea0             // =24224
    8fa0:      	mov	w12, #0x1               // =1
    8fa4:      	ldr	x17, [sp, #0x38]
    8fa8:      	cbz	x0, 0x7890 <generic_kprobe_filter_arg+0x12c0>
    8fac:      	mov	x8, x9
    8fb0:      	ldr	w9, [sp, #0x28]
    8fb4:      	mov	x22, x0
    8fb8:      	cmp	w9, #0x5
    8fbc:      	b.gt	0x9008 <generic_kprobe_filter_arg+0x2a38>
    8fc0:      	mov	x0, x8
    8fc4:      	mov	x9, x8
    8fc8:      	mov	w8, #0x4                // =4
    8fcc:      	mov	w1, w29
    8fd0:      	mov	x2, x25
    8fd4:      	strb	w29, [x0], #0x1
    8fd8:      	mov	x25, x9
    8fdc:      	blr	x8
    8fe0:      	ldr	w8, [sp, #0x10]
    8fe4:      	subs	w8, w8, w29
    8fe8:      	b.ls	0x904c <generic_kprobe_filter_arg+0x2a7c>
    8fec:      	add	x9, x25, x29
    8ff0:      	and	w1, w8, #0xfff
    8ff4:      	mov	w8, #0x4                // =4
    8ff8:      	add	x0, x9, #0x1
    8ffc:      	b	0x9044 <generic_kprobe_filter_arg+0x2a74>
    9000:      	mov	x22, xzr
    9004:      	b	0x788c <generic_kprobe_filter_arg+0x12bc>
    9008:      	mov	x0, x8
    900c:      	mov	x9, x8
    9010:      	mov	w8, #0x4                // =4
    9014:      	mov	w1, w29
    9018:      	mov	x2, x25
    901c:      	strh	w29, [x0], #0x2
    9020:      	mov	x25, x9
    9024:      	blr	x8
    9028:      	ldr	w8, [sp, #0x10]
    902c:      	subs	w8, w8, w29
    9030:      	b.ls	0x904c <generic_kprobe_filter_arg+0x2a7c>
    9034:      	add	x9, x25, x29
    9038:      	and	w1, w8, #0xfff
    903c:      	mov	w8, #0x4                // =4
    9040:      	add	x0, x9, #0x2
    9044:      	mov	x2, x22
    9048:      	blr	x8
    904c:      	ldr	w8, [sp, #0x1c]
    9050:      	mov	w12, #0x1               // =1
    9054:      	str	w8, [sp, #0x60]
    9058:      	ldr	w8, [sp, #0x28]
    905c:      	cmp	w8, #0x4
    9060:      	b.le	0x9098 <generic_kprobe_filter_arg+0x2ac8>
    9064:      	cmp	w8, #0x7
    9068:      	b.gt	0x90cc <generic_kprobe_filter_arg+0x2afc>
    906c:      	cmp	w8, #0x5
    9070:      	b.eq	0x9474 <generic_kprobe_filter_arg+0x2ea4>
    9074:      	cmp	w8, #0x6
    9078:      	b.eq	0x9438 <generic_kprobe_filter_arg+0x2e68>
    907c:      	cmp	w8, #0x7
    9080:      	b.ne	0x94c4 <generic_kprobe_filter_arg+0x2ef4>
    9084:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9088:      	mov	w8, #0x1                // =1
    908c:      	add	x9, sp, #0x60
    9090:      	ldr	x0, [x0]
    9094:      	b	0x9498 <generic_kprobe_filter_arg+0x2ec8>
    9098:      	cmp	w8, #0x1
    909c:      	b.le	0x90f8 <generic_kprobe_filter_arg+0x2b28>
    90a0:      	cmp	w8, #0x2
    90a4:      	b.eq	0x9460 <generic_kprobe_filter_arg+0x2e90>
    90a8:      	cmp	w8, #0x3
    90ac:      	b.eq	0x9424 <generic_kprobe_filter_arg+0x2e54>
    90b0:      	cmp	w8, #0x4
    90b4:      	b.ne	0x94c4 <generic_kprobe_filter_arg+0x2ef4>
    90b8:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    90bc:      	mov	w8, #0x1                // =1
    90c0:      	add	x9, sp, #0x60
    90c4:      	ldr	x0, [x0]
    90c8:      	b	0x9498 <generic_kprobe_filter_arg+0x2ec8>
    90cc:      	cmp	w8, #0x8
    90d0:      	b.eq	0x9488 <generic_kprobe_filter_arg+0x2eb8>
    90d4:      	cmp	w8, #0x9
    90d8:      	b.eq	0x944c <generic_kprobe_filter_arg+0x2e7c>
    90dc:      	cmp	w8, #0xa
    90e0:      	b.ne	0x94c4 <generic_kprobe_filter_arg+0x2ef4>
    90e4:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    90e8:      	mov	w8, #0x1                // =1
    90ec:      	add	x9, sp, #0x60
    90f0:      	ldr	x0, [x0]
    90f4:      	b	0x9498 <generic_kprobe_filter_arg+0x2ec8>
    90f8:      	cbz	w8, 0x9410 <generic_kprobe_filter_arg+0x2e40>
    90fc:      	cmp	w8, #0x1
    9100:      	b.ne	0x94c4 <generic_kprobe_filter_arg+0x2ef4>
    9104:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9108:      	mov	w8, #0x1                // =1
    910c:      	add	x9, sp, #0x60
    9110:      	ldr	x0, [x0]
    9114:      	b	0x9498 <generic_kprobe_filter_arg+0x2ec8>
    9118:      	cmp	w12, w10
    911c:      	ccmp	w10, w11, #0x2, ls
    9120:      	cset	w9, ls
    9124:      	orr	w8, w8, w9
    9128:      	mov	w12, #0x1               // =1
    912c:      	tbz	w8, #0x0, 0x6868 <generic_kprobe_filter_arg+0x298>
    9130:      	b	0x66cc <generic_kprobe_filter_arg+0xfc>
    9134:      	ldr	x12, [x25]
    9138:      	cmp	x12, x11
    913c:      	mov	w12, #0x1               // =1
    9140:      	b.hi	0x6868 <generic_kprobe_filter_arg+0x298>
    9144:      	b	0x9158 <generic_kprobe_filter_arg+0x2b88>
    9148:      	ldr	x12, [x25]
    914c:      	cmp	x12, x11
    9150:      	mov	w12, #0x1               // =1
    9154:      	b.lo	0x6868 <generic_kprobe_filter_arg+0x298>
    9158:      	cmp	w10, #0x21
    915c:      	b.lo	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    9160:      	ldr	x10, [x23, #0x28]
    9164:      	cmp	w8, #0x2
    9168:      	b.le	0x9198 <generic_kprobe_filter_arg+0x2bc8>
    916c:      	sub	w9, w8, #0x3
    9170:      	cmp	w9, #0x2
    9174:      	b.lo	0x91c8 <generic_kprobe_filter_arg+0x2bf8>
    9178:      	cmp	w8, #0x6
    917c:      	b.eq	0x6868 <generic_kprobe_filter_arg+0x298>
    9180:      	cmp	w8, #0xc
    9184:      	b.ne	0x66cc <generic_kprobe_filter_arg+0xfc>
    9188:      	ldr	x9, [x25]
    918c:      	tst	x9, x10
    9190:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    9194:      	b	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    9198:      	cmp	w8, #0x1
    919c:      	b.eq	0x92d8 <generic_kprobe_filter_arg+0x2d08>
    91a0:      	cmp	w8, #0x2
    91a4:      	b.ne	0x66cc <generic_kprobe_filter_arg+0xfc>
    91a8:      	cmp	w9, #0xc
    91ac:      	b.eq	0x91b8 <generic_kprobe_filter_arg+0x2be8>
    91b0:      	cmp	w9, #0xa
    91b4:      	b.ne	0x9880 <generic_kprobe_filter_arg+0x32b0>
    91b8:      	ldr	x9, [x25]
    91bc:      	cmp	x9, x10
    91c0:      	b.lt	0x6868 <generic_kprobe_filter_arg+0x298>
    91c4:      	b	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    91c8:      	ldr	x9, [x25]
    91cc:      	cmp	x9, x10
    91d0:      	b.ne	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    91d4:      	b	0x685c <generic_kprobe_filter_arg+0x28c>
    91d8:      	cmp	w8, #0xc
    91dc:      	b.ne	0x94e4 <generic_kprobe_filter_arg+0x2f14>
    91e0:      	ldrb	w11, [x25]
    91e4:      	tst	w10, w11
    91e8:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    91ec:      	b	0x94e4 <generic_kprobe_filter_arg+0x2f14>
    91f0:      	cmp	w8, #0xc
    91f4:      	b.ne	0x9528 <generic_kprobe_filter_arg+0x2f58>
    91f8:      	ldrh	w11, [x25]
    91fc:      	tst	w10, w11
    9200:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    9204:      	b	0x9528 <generic_kprobe_filter_arg+0x2f58>
    9208:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    920c:      	mov	w8, #0x1                // =1
    9210:      	add	x9, sp, #0x60
    9214:      	ldr	x0, [x0]
    9218:      	b	0x9290 <generic_kprobe_filter_arg+0x2cc0>
    921c:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9220:      	mov	w8, #0x1                // =1
    9224:      	add	x9, sp, #0x60
    9228:      	ldr	x0, [x0]
    922c:      	b	0x9290 <generic_kprobe_filter_arg+0x2cc0>
    9230:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9234:      	mov	w8, #0x1                // =1
    9238:      	add	x9, sp, #0x60
    923c:      	ldr	x0, [x0]
    9240:      	b	0x9290 <generic_kprobe_filter_arg+0x2cc0>
    9244:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9248:      	mov	w8, #0x1                // =1
    924c:      	add	x9, sp, #0x60
    9250:      	ldr	x0, [x0]
    9254:      	b	0x9290 <generic_kprobe_filter_arg+0x2cc0>
    9258:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    925c:      	mov	w8, #0x1                // =1
    9260:      	add	x9, sp, #0x60
    9264:      	ldr	x0, [x0]
    9268:      	b	0x9290 <generic_kprobe_filter_arg+0x2cc0>
    926c:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9270:      	mov	w8, #0x1                // =1
    9274:      	add	x9, sp, #0x60
    9278:      	ldr	x0, [x0]
    927c:      	b	0x9290 <generic_kprobe_filter_arg+0x2cc0>
    9280:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9284:      	mov	w8, #0x1                // =1
    9288:      	add	x9, sp, #0x60
    928c:      	ldr	x0, [x0]
    9290:      	add	x1, sp, #0x60
    9294:      	blr	x8
    9298:      	cbz	x0, 0x93b0 <generic_kprobe_filter_arg+0x2de0>
    929c:      	mov	w8, #0x1                // =1
    92a0:      	mov	x1, x25
    92a4:      	blr	x8
    92a8:      	cmp	x0, #0x0
    92ac:      	cset	w22, ne
    92b0:      	b	0x93b4 <generic_kprobe_filter_arg+0x2de4>
    92b4:      	cmp	w8, #0x401
    92b8:      	b.hs	0x962c <generic_kprobe_filter_arg+0x305c>
    92bc:      	mov	w11, #0x400             // =1024
    92c0:      	b	0x9640 <generic_kprobe_filter_arg+0x3070>
    92c4:      	cmp	w11, w8
    92c8:      	b.hi	0x66cc <generic_kprobe_filter_arg+0xfc>
    92cc:      	cmp	w8, w10
    92d0:      	b.ls	0x6868 <generic_kprobe_filter_arg+0x298>
    92d4:      	b	0x66cc <generic_kprobe_filter_arg+0xfc>
    92d8:      	cmp	w9, #0xc
    92dc:      	b.eq	0x92e8 <generic_kprobe_filter_arg+0x2d18>
    92e0:      	cmp	w9, #0xa
    92e4:      	b.ne	0x9890 <generic_kprobe_filter_arg+0x32c0>
    92e8:      	ldr	x9, [x25]
    92ec:      	cmp	x9, x10
    92f0:      	b.gt	0x6868 <generic_kprobe_filter_arg+0x298>
    92f4:      	b	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    92f8:      	ldr	x19, [sp, #0x30]
    92fc:      	mov	w12, #0x1               // =1
    9300:      	b	0x83c4 <generic_kprobe_filter_arg+0x1df4>
    9304:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9308:      	mov	w8, #0x1                // =1
    930c:      	add	x9, sp, #0x60
    9310:      	ldr	x0, [x0]
    9314:      	b	0x938c <generic_kprobe_filter_arg+0x2dbc>
    9318:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    931c:      	mov	w8, #0x1                // =1
    9320:      	add	x9, sp, #0x60
    9324:      	ldr	x0, [x0]
    9328:      	b	0x938c <generic_kprobe_filter_arg+0x2dbc>
    932c:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9330:      	mov	w8, #0x1                // =1
    9334:      	add	x9, sp, #0x60
    9338:      	ldr	x0, [x0]
    933c:      	b	0x938c <generic_kprobe_filter_arg+0x2dbc>
    9340:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9344:      	mov	w8, #0x1                // =1
    9348:      	add	x9, sp, #0x60
    934c:      	ldr	x0, [x0]
    9350:      	b	0x938c <generic_kprobe_filter_arg+0x2dbc>
    9354:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9358:      	mov	w8, #0x1                // =1
    935c:      	add	x9, sp, #0x60
    9360:      	ldr	x0, [x0]
    9364:      	b	0x938c <generic_kprobe_filter_arg+0x2dbc>
    9368:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    936c:      	mov	w8, #0x1                // =1
    9370:      	add	x9, sp, #0x60
    9374:      	ldr	x0, [x0]
    9378:      	b	0x938c <generic_kprobe_filter_arg+0x2dbc>
    937c:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9380:      	mov	w8, #0x1                // =1
    9384:      	add	x9, sp, #0x60
    9388:      	ldr	x0, [x0]
    938c:      	add	x1, sp, #0x60
    9390:      	blr	x8
    9394:      	cbz	x0, 0x93b0 <generic_kprobe_filter_arg+0x2de0>
    9398:      	ldr	x1, [sp, #0x8]
    939c:      	mov	w8, #0x1                // =1
    93a0:      	blr	x8
    93a4:      	cmp	x0, #0x0
    93a8:      	cset	w22, ne
    93ac:      	b	0x93b4 <generic_kprobe_filter_arg+0x2de4>
    93b0:      	mov	x22, xzr
    93b4:      	ldp	x16, x15, [sp, #0x40]
    93b8:      	mov	w2, #0x5ea0             // =24224
    93bc:      	mov	w12, #0x1               // =1
    93c0:      	ldr	x17, [sp, #0x38]
    93c4:      	ldr	w8, [x23, #0x4]
    93c8:      	cmp	w8, #0x25
    93cc:      	b.hi	0x6864 <generic_kprobe_filter_arg+0x294>
    93d0:      	mov	x9, #0x50               // =80
    93d4:      	lsl	x8, x12, x8
    93d8:      	movk	x9, #0xc00, lsl #16
    93dc:      	movk	x9, #0x20, lsl #32
    93e0:      	tst	x8, x9
    93e4:      	b.eq	0x6864 <generic_kprobe_filter_arg+0x294>
    93e8:      	eor	x22, x22, #0x1
    93ec:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    93f0:      	ldp	x16, x15, [sp, #0x40]
    93f4:      	mov	x22, xzr
    93f8:      	mov	w2, #0x5ea0             // =24224
    93fc:      	ldr	x17, [sp, #0x38]
    9400:      	ldr	w8, [x23, #0x4]
    9404:      	cmp	w8, #0x25
    9408:      	b.ls	0x93d0 <generic_kprobe_filter_arg+0x2e00>
    940c:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    9410:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9414:      	mov	w8, #0x1                // =1
    9418:      	add	x9, sp, #0x60
    941c:      	ldr	x0, [x0]
    9420:      	b	0x9498 <generic_kprobe_filter_arg+0x2ec8>
    9424:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9428:      	mov	w8, #0x1                // =1
    942c:      	add	x9, sp, #0x60
    9430:      	ldr	x0, [x0]
    9434:      	b	0x9498 <generic_kprobe_filter_arg+0x2ec8>
    9438:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    943c:      	mov	w8, #0x1                // =1
    9440:      	add	x9, sp, #0x60
    9444:      	ldr	x0, [x0]
    9448:      	b	0x9498 <generic_kprobe_filter_arg+0x2ec8>
    944c:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9450:      	mov	w8, #0x1                // =1
    9454:      	add	x9, sp, #0x60
    9458:      	ldr	x0, [x0]
    945c:      	b	0x9498 <generic_kprobe_filter_arg+0x2ec8>
    9460:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9464:      	mov	w8, #0x1                // =1
    9468:      	add	x9, sp, #0x60
    946c:      	ldr	x0, [x0]
    9470:      	b	0x9498 <generic_kprobe_filter_arg+0x2ec8>
    9474:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9478:      	mov	w8, #0x1                // =1
    947c:      	add	x9, sp, #0x60
    9480:      	ldr	x0, [x0]
    9484:      	b	0x9498 <generic_kprobe_filter_arg+0x2ec8>
    9488:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    948c:      	mov	w8, #0x1                // =1
    9490:      	add	x9, sp, #0x60
    9494:      	ldr	x0, [x0]
    9498:      	add	x1, sp, #0x60
    949c:      	blr	x8
    94a0:      	cbz	x0, 0x94bc <generic_kprobe_filter_arg+0x2eec>
    94a4:      	mov	w8, #0x1                // =1
    94a8:      	mov	x1, x25
    94ac:      	blr	x8
    94b0:      	cmp	x0, #0x0
    94b4:      	cset	w22, ne
    94b8:      	b	0x7880 <generic_kprobe_filter_arg+0x12b0>
    94bc:      	mov	x22, xzr
    94c0:      	b	0x7880 <generic_kprobe_filter_arg+0x12b0>
    94c4:      	ldp	x16, x15, [sp, #0x40]
    94c8:      	mov	x22, xzr
    94cc:      	mov	w2, #0x5ea0             // =24224
    94d0:      	ldr	x17, [sp, #0x38]
    94d4:      	b	0x7890 <generic_kprobe_filter_arg+0x12c0>
    94d8:      	ldrb	w11, [x25]
    94dc:      	cmp	w10, w11
    94e0:      	b.lo	0x6868 <generic_kprobe_filter_arg+0x298>
    94e4:      	cmp	w9, #0x15
    94e8:      	b.lo	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    94ec:      	ldr	w9, [x23, #0x1c]
    94f0:      	cmp	w8, #0x2
    94f4:      	b.le	0x9838 <generic_kprobe_filter_arg+0x3268>
    94f8:      	sub	w10, w8, #0x3
    94fc:      	cmp	w10, #0x2
    9500:      	b.lo	0x9868 <generic_kprobe_filter_arg+0x3298>
    9504:      	cmp	w8, #0x6
    9508:      	b.eq	0x6868 <generic_kprobe_filter_arg+0x298>
    950c:      	cmp	w8, #0xc
    9510:      	b.ne	0x66cc <generic_kprobe_filter_arg+0xfc>
    9514:      	ldrb	w10, [x25]
    9518:      	b	0x95b8 <generic_kprobe_filter_arg+0x2fe8>
    951c:      	ldrh	w11, [x25]
    9520:      	cmp	w10, w11
    9524:      	b.lo	0x6868 <generic_kprobe_filter_arg+0x298>
    9528:      	cmp	w9, #0x15
    952c:      	b.lo	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    9530:      	ldr	w9, [x23, #0x1c]
    9534:      	cmp	w8, #0x2
    9538:      	b.le	0x9850 <generic_kprobe_filter_arg+0x3280>
    953c:      	sub	w10, w8, #0x3
    9540:      	cmp	w10, #0x2
    9544:      	b.lo	0x9870 <generic_kprobe_filter_arg+0x32a0>
    9548:      	cmp	w8, #0x6
    954c:      	b.eq	0x6868 <generic_kprobe_filter_arg+0x298>
    9550:      	cmp	w8, #0xc
    9554:      	b.ne	0x66cc <generic_kprobe_filter_arg+0xfc>
    9558:      	ldrh	w10, [x25]
    955c:      	b	0x95b8 <generic_kprobe_filter_arg+0x2fe8>
    9560:      	ldr	w12, [x25]
    9564:      	cmp	w12, w11
    9568:      	mov	w12, #0x1               // =1
    956c:      	b.hi	0x6868 <generic_kprobe_filter_arg+0x298>
    9570:      	b	0x9584 <generic_kprobe_filter_arg+0x2fb4>
    9574:      	ldr	w12, [x25]
    9578:      	cmp	w12, w11
    957c:      	mov	w12, #0x1               // =1
    9580:      	b.lo	0x6868 <generic_kprobe_filter_arg+0x298>
    9584:      	cmp	w10, #0x15
    9588:      	b.lo	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    958c:      	ldr	w10, [x23, #0x1c]
    9590:      	cmp	w8, #0x2
    9594:      	b.le	0x95c4 <generic_kprobe_filter_arg+0x2ff4>
    9598:      	sub	w9, w8, #0x3
    959c:      	cmp	w9, #0x2
    95a0:      	b.lo	0x95fc <generic_kprobe_filter_arg+0x302c>
    95a4:      	cmp	w8, #0x6
    95a8:      	b.eq	0x6868 <generic_kprobe_filter_arg+0x298>
    95ac:      	cmp	w8, #0xc
    95b0:      	b.ne	0x66cc <generic_kprobe_filter_arg+0xfc>
    95b4:      	ldr	w9, [x25]
    95b8:      	tst	w9, w10
    95bc:      	b.ne	0x6868 <generic_kprobe_filter_arg+0x298>
    95c0:      	b	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    95c4:      	cmp	w8, #0x1
    95c8:      	b.eq	0x9604 <generic_kprobe_filter_arg+0x3034>
    95cc:      	cmp	w8, #0x2
    95d0:      	b.ne	0x66cc <generic_kprobe_filter_arg+0xfc>
    95d4:      	cmp	w9, #0xc
    95d8:      	b.hi	0x99a8 <generic_kprobe_filter_arg+0x33d8>
    95dc:      	lsl	w9, w12, w9
    95e0:      	mov	w11, #0x1402            // =5122
    95e4:      	tst	w9, w11
    95e8:      	b.eq	0x99a8 <generic_kprobe_filter_arg+0x33d8>
    95ec:      	ldr	w9, [x25]
    95f0:      	cmp	w9, w10
    95f4:      	b.lt	0x6868 <generic_kprobe_filter_arg+0x298>
    95f8:      	b	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    95fc:      	ldr	w9, [x25]
    9600:      	b	0x9874 <generic_kprobe_filter_arg+0x32a4>
    9604:      	cmp	w9, #0xc
    9608:      	b.hi	0x99b8 <generic_kprobe_filter_arg+0x33e8>
    960c:      	lsl	w9, w12, w9
    9610:      	mov	w11, #0x1402            // =5122
    9614:      	tst	w9, w11
    9618:      	b.eq	0x99b8 <generic_kprobe_filter_arg+0x33e8>
    961c:      	ldr	w9, [x25]
    9620:      	cmp	w9, w10
    9624:      	b.gt	0x6868 <generic_kprobe_filter_arg+0x298>
    9628:      	b	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    962c:      	and	w8, w25, #0xffff
    9630:      	mov	w9, #0x1000             // =4096
    9634:      	cmp	w8, #0x800
    9638:      	mov	w8, #0x800              // =2048
    963c:      	csel	w11, w9, w8, hi
    9640:      	sub	w8, w11, #0x100
    9644:      	ror	w8, w8, #0x8
    9648:      	cmp	w8, #0x2
    964c:      	b.gt	0x9664 <generic_kprobe_filter_arg+0x3094>
    9650:      	cbz	w8, 0x9684 <generic_kprobe_filter_arg+0x30b4>
    9654:      	cmp	w8, #0x1
    9658:      	b.ne	0x967c <generic_kprobe_filter_arg+0x30ac>
    965c:      	mov	w10, #0x7               // =7
    9660:      	b	0x9690 <generic_kprobe_filter_arg+0x30c0>
    9664:      	cmp	w8, #0x3
    9668:      	b.eq	0x968c <generic_kprobe_filter_arg+0x30bc>
    966c:      	cmp	w8, #0x7
    9670:      	b.ne	0x967c <generic_kprobe_filter_arg+0x30ac>
    9674:      	mov	w10, #0x9               // =9
    9678:      	b	0x9690 <generic_kprobe_filter_arg+0x30c0>
    967c:      	mov	w10, #0xa               // =10
    9680:      	b	0x9690 <generic_kprobe_filter_arg+0x30c0>
    9684:      	mov	w10, #0x6               // =6
    9688:      	b	0x9690 <generic_kprobe_filter_arg+0x30c0>
    968c:      	mov	w10, #0x8               // =8
    9690:      	add	x8, x23, #0x10
    9694:      	and	w9, w10, #0xf
    9698:      	ldr	w8, [x8, w9, uxtw #2]
    969c:      	cmn	w8, #0x1
    96a0:      	b.eq	0x994c <generic_kprobe_filter_arg+0x337c>
    96a4:      	stp	w8, w11, [sp, #0x1c]
    96a8:      	str	w10, [sp, #0x28]
    96ac:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    96b0:      	mov	w8, #0x1                // =1
    96b4:      	add	x19, sp, #0x88
    96b8:      	add	x1, sp, #0x88
    96bc:      	ldr	x0, [x0]
    96c0:      	blr	x8
    96c4:      	mov	x9, x0
    96c8:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    96cc:      	mov	w8, #0x1                // =1
    96d0:      	ldr	x0, [x0]
    96d4:      	add	x1, sp, #0x88
    96d8:      	mov	x19, x9
    96dc:      	blr	x8
    96e0:      	mov	x22, xzr
    96e4:      	cbz	x19, 0x9950 <generic_kprobe_filter_arg+0x3380>
    96e8:      	mov	w12, #0x1               // =1
    96ec:      	cbz	x0, 0x9954 <generic_kprobe_filter_arg+0x3384>
    96f0:      	ldr	w22, [sp, #0x28]
    96f4:      	str	x0, [sp, #0x10]
    96f8:      	mov	x0, x19
    96fc:      	cmp	w22, #0x5
    9700:      	b.gt	0x973c <generic_kprobe_filter_arg+0x316c>
    9704:      	strb	w25, [x0], #0x1
    9708:      	mov	w8, #0x4                // =4
    970c:      	mov	w1, w25
    9710:      	mov	x2, x29
    9714:      	blr	x8
    9718:      	ldr	w8, [sp, #0x20]
    971c:      	subs	w8, w8, w25
    9720:      	b.ls	0x9774 <generic_kprobe_filter_arg+0x31a4>
    9724:      	add	x9, x19, x25
    9728:      	and	w1, w8, #0xfff
    972c:      	mov	w8, #0x4                // =4
    9730:      	ldr	x2, [sp, #0x10]
    9734:      	add	x0, x9, #0x1
    9738:      	b	0x9770 <generic_kprobe_filter_arg+0x31a0>
    973c:      	strh	w25, [x0], #0x2
    9740:      	mov	w8, #0x4                // =4
    9744:      	mov	w1, w25
    9748:      	mov	x2, x29
    974c:      	blr	x8
    9750:      	ldr	w8, [sp, #0x20]
    9754:      	subs	w8, w8, w25
    9758:      	b.ls	0x9774 <generic_kprobe_filter_arg+0x31a4>
    975c:      	add	x9, x19, x25
    9760:      	ldr	x2, [sp, #0x10]
    9764:      	and	w1, w8, #0xfff
    9768:      	mov	w8, #0x4                // =4
    976c:      	add	x0, x9, #0x2
    9770:      	blr	x8
    9774:      	ldr	w8, [sp, #0x1c]
    9778:      	cmp	w22, #0x4
    977c:      	str	w8, [sp, #0x60]
    9780:      	b.le	0x97b8 <generic_kprobe_filter_arg+0x31e8>
    9784:      	cmp	w22, #0x7
    9788:      	b.gt	0x97ec <generic_kprobe_filter_arg+0x321c>
    978c:      	cmp	w22, #0x5
    9790:      	b.eq	0x9904 <generic_kprobe_filter_arg+0x3334>
    9794:      	cmp	w22, #0x6
    9798:      	b.eq	0x98c8 <generic_kprobe_filter_arg+0x32f8>
    979c:      	cmp	w22, #0x7
    97a0:      	b.ne	0x994c <generic_kprobe_filter_arg+0x337c>
    97a4:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    97a8:      	mov	w8, #0x1                // =1
    97ac:      	add	x9, sp, #0x60
    97b0:      	ldr	x0, [x0]
    97b4:      	b	0x9928 <generic_kprobe_filter_arg+0x3358>
    97b8:      	cmp	w22, #0x1
    97bc:      	b.le	0x9818 <generic_kprobe_filter_arg+0x3248>
    97c0:      	cmp	w22, #0x2
    97c4:      	b.eq	0x98f0 <generic_kprobe_filter_arg+0x3320>
    97c8:      	cmp	w22, #0x3
    97cc:      	b.eq	0x98b4 <generic_kprobe_filter_arg+0x32e4>
    97d0:      	cmp	w22, #0x4
    97d4:      	b.ne	0x994c <generic_kprobe_filter_arg+0x337c>
    97d8:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    97dc:      	mov	w8, #0x1                // =1
    97e0:      	add	x9, sp, #0x60
    97e4:      	ldr	x0, [x0]
    97e8:      	b	0x9928 <generic_kprobe_filter_arg+0x3358>
    97ec:      	cmp	w22, #0x8
    97f0:      	b.eq	0x9918 <generic_kprobe_filter_arg+0x3348>
    97f4:      	cmp	w22, #0x9
    97f8:      	b.eq	0x98dc <generic_kprobe_filter_arg+0x330c>
    97fc:      	cmp	w22, #0xa
    9800:      	b.ne	0x994c <generic_kprobe_filter_arg+0x337c>
    9804:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9808:      	mov	w8, #0x1                // =1
    980c:      	add	x9, sp, #0x60
    9810:      	ldr	x0, [x0]
    9814:      	b	0x9928 <generic_kprobe_filter_arg+0x3358>
    9818:      	cbz	w22, 0x98a0 <generic_kprobe_filter_arg+0x32d0>
    981c:      	cmp	w22, #0x1
    9820:      	b.ne	0x994c <generic_kprobe_filter_arg+0x337c>
    9824:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9828:      	mov	w8, #0x1                // =1
    982c:      	add	x9, sp, #0x60
    9830:      	ldr	x0, [x0]
    9834:      	b	0x9928 <generic_kprobe_filter_arg+0x3358>
    9838:      	cmp	w8, #0x1
    983c:      	b.eq	0x9998 <generic_kprobe_filter_arg+0x33c8>
    9840:      	cmp	w8, #0x2
    9844:      	b.ne	0x66cc <generic_kprobe_filter_arg+0xfc>
    9848:      	ldrb	w10, [x25]
    984c:      	b	0x99bc <generic_kprobe_filter_arg+0x33ec>
    9850:      	cmp	w8, #0x1
    9854:      	b.eq	0x99a0 <generic_kprobe_filter_arg+0x33d0>
    9858:      	cmp	w8, #0x2
    985c:      	b.ne	0x66cc <generic_kprobe_filter_arg+0xfc>
    9860:      	ldrh	w10, [x25]
    9864:      	b	0x99bc <generic_kprobe_filter_arg+0x33ec>
    9868:      	ldrb	w10, [x25]
    986c:      	b	0x9874 <generic_kprobe_filter_arg+0x32a4>
    9870:      	ldrh	w10, [x25]
    9874:      	cmp	w9, w10
    9878:      	b.eq	0x685c <generic_kprobe_filter_arg+0x28c>
    987c:      	b	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    9880:      	ldr	x9, [x25]
    9884:      	cmp	x9, x10
    9888:      	b.lo	0x6868 <generic_kprobe_filter_arg+0x298>
    988c:      	b	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    9890:      	ldr	x9, [x25]
    9894:      	cmp	x9, x10
    9898:      	b.hi	0x6868 <generic_kprobe_filter_arg+0x298>
    989c:      	b	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    98a0:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    98a4:      	mov	w8, #0x1                // =1
    98a8:      	add	x9, sp, #0x60
    98ac:      	ldr	x0, [x0]
    98b0:      	b	0x9928 <generic_kprobe_filter_arg+0x3358>
    98b4:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    98b8:      	mov	w8, #0x1                // =1
    98bc:      	add	x9, sp, #0x60
    98c0:      	ldr	x0, [x0]
    98c4:      	b	0x9928 <generic_kprobe_filter_arg+0x3358>
    98c8:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    98cc:      	mov	w8, #0x1                // =1
    98d0:      	add	x9, sp, #0x60
    98d4:      	ldr	x0, [x0]
    98d8:      	b	0x9928 <generic_kprobe_filter_arg+0x3358>
    98dc:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    98e0:      	mov	w8, #0x1                // =1
    98e4:      	add	x9, sp, #0x60
    98e8:      	ldr	x0, [x0]
    98ec:      	b	0x9928 <generic_kprobe_filter_arg+0x3358>
    98f0:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    98f4:      	mov	w8, #0x1                // =1
    98f8:      	add	x9, sp, #0x60
    98fc:      	ldr	x0, [x0]
    9900:      	b	0x9928 <generic_kprobe_filter_arg+0x3358>
    9904:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9908:      	mov	w8, #0x1                // =1
    990c:      	add	x9, sp, #0x60
    9910:      	ldr	x0, [x0]
    9914:      	b	0x9928 <generic_kprobe_filter_arg+0x3358>
    9918:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    991c:      	mov	w8, #0x1                // =1
    9920:      	add	x9, sp, #0x60
    9924:      	ldr	x0, [x0]
    9928:      	add	x1, sp, #0x60
    992c:      	blr	x8
    9930:      	cbz	x0, 0x994c <generic_kprobe_filter_arg+0x337c>
    9934:      	mov	w8, #0x1                // =1
    9938:      	mov	x1, x19
    993c:      	blr	x8
    9940:      	cmp	x0, #0x0
    9944:      	cset	w22, ne
    9948:      	b	0x9950 <generic_kprobe_filter_arg+0x3380>
    994c:      	mov	x22, xzr
    9950:      	mov	w12, #0x1               // =1
    9954:      	ldr	w8, [x23, #0x4]
    9958:      	ldp	x16, x15, [sp, #0x40]
    995c:      	mov	w2, #0x5ea0             // =24224
    9960:      	cmp	w8, #0x25
    9964:      	ldr	x17, [sp, #0x38]
    9968:      	b.hi	0x9990 <generic_kprobe_filter_arg+0x33c0>
    996c:      	mov	x9, #0x50               // =80
    9970:      	ldr	x19, [sp, #0x30]
    9974:      	lsl	x8, x12, x8
    9978:      	movk	x9, #0xc00, lsl #16
    997c:      	movk	x9, #0x20, lsl #32
    9980:      	tst	x8, x9
    9984:      	b.eq	0x6864 <generic_kprobe_filter_arg+0x294>
    9988:      	cmp	x22, #0x0
    998c:      	b	0x6860 <generic_kprobe_filter_arg+0x290>
    9990:      	ldr	x19, [sp, #0x30]
    9994:      	b	0x6864 <generic_kprobe_filter_arg+0x294>
    9998:      	ldrb	w10, [x25]
    999c:      	b	0x99ac <generic_kprobe_filter_arg+0x33dc>
    99a0:      	ldrh	w10, [x25]
    99a4:      	b	0x99ac <generic_kprobe_filter_arg+0x33dc>
    99a8:      	ldr	w9, [x25]
    99ac:      	cmp	w9, w10
    99b0:      	b.lo	0x6868 <generic_kprobe_filter_arg+0x298>
    99b4:      	b	0x99c4 <generic_kprobe_filter_arg+0x33f4>
    99b8:      	ldr	w9, [x25]
    99bc:      	cmp	w9, w10
    99c0:      	b.hi	0x6868 <generic_kprobe_filter_arg+0x298>
    99c4:      	orr	w8, w8, #0x2
    99c8:      	cmp	w8, #0x6
    99cc:      	b.eq	0x6868 <generic_kprobe_filter_arg+0x298>
    99d0:      	b	0x66cc <generic_kprobe_filter_arg+0xfc>
    99d4:      	nop
    99d8:      	nop
    99dc:      	nop

00000000000099e0 <generic_kprobe_actions>:
    99e0:      	sub	sp, sp, #0xe0
    99e4:      	str	x29, [sp, #0x90]
    99e8:      	stp	x30, x25, [sp, #0xa0]
    99ec:      	stp	x24, x23, [sp, #0xb0]
    99f0:      	stp	x22, x21, [sp, #0xc0]
    99f4:      	stp	x20, x19, [sp, #0xd0]
    99f8:      	str	wzr, [sp, #0x4c]
    99fc:      	adrp	x24, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9a00:      	mov	w8, #0x1                // =1
    9a04:      	add	x9, sp, #0x4c
    9a08:      	ldr	x24, [x24]
    9a0c:      	mov	x25, x0
    9a10:      	add	x1, sp, #0x4c
    9a14:      	mov	x0, x24
    9a18:      	blr	x8
    9a1c:      	cbz	x0, 0xa80c <generic_kprobe_actions+0xe2c>
    9a20:      	mov	w8, #0x5f04             // =24324
    9a24:      	ldr	w19, [x0, x8]
    9a28:      	cmp	w19, #0x2
    9a2c:      	b.lt	0xa80c <generic_kprobe_actions+0xe2c>
    9a30:      	mov	w8, #0x5ef8             // =24312
    9a34:      	add	x1, x0, x8
    9a38:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9a3c:      	mov	w8, #0x1                // =1
    9a40:      	ldr	x0, [x0]
    9a44:      	blr	x8
    9a48:      	cbz	x0, 0xa80c <generic_kprobe_actions+0xe2c>
    9a4c:      	and	x8, x19, #0x7ff
    9a50:      	mov	w9, #0x1                // =1
    9a54:      	add	x1, sp, #0x50
    9a58:      	ldr	w8, [x0, x8]
    9a5c:      	str	wzr, [sp, #0x50]
    9a60:      	add	w8, w8, w19
    9a64:      	and	w8, w8, #0x7ff
    9a68:      	add	x20, x0, x8
    9a6c:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9a70:      	add	x8, sp, #0x50
    9a74:      	ldr	x0, [x0]
    9a78:      	blr	x9
    9a7c:      	cbz	x0, 0x9aa0 <generic_kprobe_actions+0xc0>
    9a80:      	ldrb	w8, [x0]
    9a84:      	tst	w8, #0xff
    9a88:      	cset	w8, eq
    9a8c:      	str	w8, [sp, #0x3c]
    9a90:      	mov	w8, #0x8                // =8
    9a94:      	cinc	x8, x8, ne
    9a98:      	str	x8, [sp, #0x20]
    9a9c:      	b	0x9ab0 <generic_kprobe_actions+0xd0>
    9aa0:      	mov	w8, #0x8                // =8
    9aa4:      	str	x8, [sp, #0x20]
    9aa8:      	mov	w8, #0x1                // =1
    9aac:      	str	w8, [sp, #0x3c]
    9ab0:      	mov	w22, wzr
    9ab4:      	mov	w29, wzr
    9ab8:      	add	x23, sp, #0x54
    9abc:      	str	x20, [sp, #0x40]
    9ac0:      	str	x25, [sp, #0x30]
    9ac4:      	mov	w8, #0x1                // =1
    9ac8:      	str	w8, [sp, #0x2c]
    9acc:      	b	0x9b4c <generic_kprobe_actions+0x16c>
    9ad0:      	mov	w0, wzr
    9ad4:      	cbz	w0, 0xa37c <generic_kprobe_actions+0x99c>
    9ad8:      	nop
    9adc:      	nop
    9ae0:      	mov	w29, wzr
    9ae4:      	add	w22, w22, #0x1
    9ae8:      	cmp	w22, #0x3
    9aec:      	b.ne	0x9b4c <generic_kprobe_actions+0x16c>
    9af0:      	b	0xa7e8 <generic_kprobe_actions+0xe08>
    9af4:      	add	x8, x21, x8, lsl #3
    9af8:      	mov	x0, x23
    9afc:      	ldr	x8, [x8, #0x5e78]
    9b00:      	and	x8, x8, #0x7ff
    9b04:      	add	x2, x21, x8
    9b08:      	ldr	w8, [x2, #0x90]!
    9b0c:      	and	x8, x8, #0xfff
    9b10:      	add	x1, x8, #0x8
    9b14:      	mov	w8, #0x4                // =4
    9b18:      	blr	x8
    9b1c:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9b20:      	mov	x3, xzr
    9b24:      	mov	w8, #0x2                // =2
    9b28:      	ldr	x0, [x0]
    9b2c:      	add	x9, sp, #0x58
    9b30:      	add	x1, sp, #0x58
    9b34:      	mov	x2, x23
    9b38:      	blr	x8
    9b3c:      	mov	w0, wzr
    9b40:      	add	x23, sp, #0x54
    9b44:      	cbnz	w0, 0x9ae0 <generic_kprobe_actions+0x100>
    9b48:      	b	0xa37c <generic_kprobe_actions+0x99c>
    9b4c:      	ldr	w9, [x20]
    9b50:      	lsl	w8, w29, #2
    9b54:      	add	w8, w8, #0x4
    9b58:      	cmp	w8, w9
    9b5c:      	b.hs	0xa7e8 <generic_kprobe_actions+0xe08>
    9b60:      	add	x8, x20, w29, uxtw #2
    9b64:      	add	x1, sp, #0x54
    9b68:      	mov	x0, x24
    9b6c:      	ldrsw	x19, [x8, #0x4]
    9b70:      	str	wzr, [sp, #0x54]
    9b74:      	mov	w8, #0x1                // =1
    9b78:      	blr	x8
    9b7c:      	cbz	x0, 0x9ae0 <generic_kprobe_actions+0x100>
    9b80:      	mov	x21, x0
    9b84:      	cmp	w19, #0x7
    9b88:      	b.gt	0x9bac <generic_kprobe_actions+0x1cc>
    9b8c:      	cmp	w19, #0x3
    9b90:      	b.gt	0x9c00 <generic_kprobe_actions+0x220>
    9b94:      	cmp	w19, #0x1
    9b98:      	b.gt	0x9c80 <generic_kprobe_actions+0x2a0>
    9b9c:      	cbz	w19, 0x9ef4 <generic_kprobe_actions+0x514>
    9ba0:      	cmp	w19, #0x1
    9ba4:      	b.eq	0x9c90 <generic_kprobe_actions+0x2b0>
    9ba8:      	b	0xa37c <generic_kprobe_actions+0x99c>
    9bac:      	cmp	w19, #0xb
    9bb0:      	b.gt	0x9c58 <generic_kprobe_actions+0x278>
    9bb4:      	sub	w8, w19, #0xa
    9bb8:      	cmp	w8, #0x2
    9bbc:      	b.lo	0x9ce8 <generic_kprobe_actions+0x308>
    9bc0:      	cmp	w19, #0x8
    9bc4:      	b.eq	0x9dc0 <generic_kprobe_actions+0x3e0>
    9bc8:      	cmp	w19, #0x9
    9bcc:      	b.ne	0xa37c <generic_kprobe_actions+0x99c>
    9bd0:      	add	w29, w29, #0x1
    9bd4:      	add	x8, x20, w29, uxtw #2
    9bd8:      	ldr	w0, [x8, #0x4]
    9bdc:      	ldr	w8, [sp, #0x3c]
    9be0:      	cbz	w8, 0x9f98 <generic_kprobe_actions+0x5b8>
    9be4:      	sxtw	x8, w0
    9be8:      	mov	w9, #0x6d               // =109
    9bec:      	blr	x9
    9bf0:      	mov	w20, #0x2               // =2
    9bf4:      	mov	w23, w29
    9bf8:      	add	x29, sp, #0x58
    9bfc:      	b	0xa340 <generic_kprobe_actions+0x960>
    9c00:      	sub	w8, w19, #0x6
    9c04:      	cmp	w8, #0x2
    9c08:      	b.lo	0x9dac <generic_kprobe_actions+0x3cc>
    9c0c:      	cmp	w19, #0x4
    9c10:      	b.eq	0x9dc8 <generic_kprobe_actions+0x3e8>
    9c14:      	cmp	w19, #0x5
    9c18:      	b.ne	0xa37c <generic_kprobe_actions+0x99c>
    9c1c:      	add	w8, w29, #0x1
    9c20:      	add	x9, x20, #0x4
    9c24:      	add	w29, w29, #0x2
    9c28:      	ldr	w8, [x9, w8, uxtw #2]
    9c2c:      	ldr	w20, [x9, w29, uxtw #2]
    9c30:      	stp	xzr, xzr, [sp, #0x58]
    9c34:      	and	x8, x8, #0x7
    9c38:      	cmp	w8, #0x4
    9c3c:      	b.hi	0x9c50 <generic_kprobe_actions+0x270>
    9c40:      	add	x9, x21, x8, lsl #2
    9c44:      	mov	w10, #0x5ea0            // =24224
    9c48:      	ldr	w9, [x9, x10]
    9c4c:      	cbz	w9, 0xa1d4 <generic_kprobe_actions+0x7f4>
    9c50:      	ldr	x20, [sp, #0x40]
    9c54:      	b	0xa37c <generic_kprobe_actions+0x99c>
    9c58:      	cmp	w19, #0xc
    9c5c:      	b.eq	0x9fa8 <generic_kprobe_actions+0x5c8>
    9c60:      	cmp	w19, #0xd
    9c64:      	b.eq	0x9e54 <generic_kprobe_actions+0x474>
    9c68:      	cmp	w19, #0xe
    9c6c:      	b.ne	0xa37c <generic_kprobe_actions+0x99c>
    9c70:      	ldr	x20, [sp, #0x20]
    9c74:      	add	w23, w29, #0x2
    9c78:      	add	x29, sp, #0x58
    9c7c:      	b	0xa340 <generic_kprobe_actions+0x960>
    9c80:      	cmp	w19, #0x2
    9c84:      	b.eq	0x9f8c <generic_kprobe_actions+0x5ac>
    9c88:      	cmp	w19, #0x3
    9c8c:      	b.ne	0xa37c <generic_kprobe_actions+0x99c>
    9c90:      	add	w8, w29, #0x1
    9c94:      	add	x9, x20, #0x4
    9c98:      	add	w29, w29, #0x2
    9c9c:      	ldr	w23, [x9, w8, uxtw #2]
    9ca0:      	ldr	w20, [x9, w29, uxtw #2]
    9ca4:      	stp	xzr, xzr, [sp, #0x58]
    9ca8:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9cac:      	mov	w8, #0x1                // =1
    9cb0:      	add	x9, sp, #0x78
    9cb4:      	add	x1, sp, #0x78
    9cb8:      	str	wzr, [sp, #0x78]
    9cbc:      	ldr	x0, [x0]
    9cc0:      	blr	x8
    9cc4:      	cbz	x0, 0x9cd8 <generic_kprobe_actions+0x2f8>
    9cc8:      	and	x8, x23, #0x7
    9ccc:      	cmp	w8, #0x4
    9cd0:      	b.ls	0xa098 <generic_kprobe_actions+0x6b8>
    9cd4:      	mov	w0, wzr
    9cd8:      	ldr	x20, [sp, #0x40]
    9cdc:      	add	x23, sp, #0x54
    9ce0:      	cbnz	w0, 0x9ae0 <generic_kprobe_actions+0x100>
    9ce4:      	b	0xa37c <generic_kprobe_actions+0x99c>
    9ce8:      	add	w29, w29, #0x1
    9cec:      	add	x8, x20, w29, uxtw #2
    9cf0:      	ldr	w8, [x8, #0x4]
    9cf4:      	and	x8, x8, #0x7
    9cf8:      	cmp	w8, #0x4
    9cfc:      	b.hi	0x9ad0 <generic_kprobe_actions+0xf0>
    9d00:      	add	x9, x21, x8, lsl #2
    9d04:      	mov	w10, #0x5ea0            // =24224
    9d08:      	ldr	w9, [x9, x10]
    9d0c:      	cbnz	w9, 0x9ad0 <generic_kprobe_actions+0xf0>
    9d10:      	add	x8, x21, x8, lsl #3
    9d14:      	ldr	x8, [x8, #0x5e78]
    9d18:      	and	x8, x8, #0x7ff
    9d1c:      	add	x8, x21, x8
    9d20:      	ldr	x8, [x8, #0xb8]
    9d24:      	str	x8, [sp, #0x78]
    9d28:      	cbz	x8, 0x9ad0 <generic_kprobe_actions+0xf0>
    9d2c:      	cmp	w19, #0xa
    9d30:      	b.ne	0xa3bc <generic_kprobe_actions+0x9dc>
    9d34:      	mov	w8, #0xe                // =14
    9d38:      	blr	x8
    9d3c:      	lsr	x8, x0, #32
    9d40:      	mov	x24, x0
    9d44:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9d48:      	str	w8, [sp, #0x58]
    9d4c:      	mov	w8, #0x1                // =1
    9d50:      	add	x9, sp, #0x58
    9d54:      	add	x1, sp, #0x58
    9d58:      	ldr	x0, [x0]
    9d5c:      	blr	x8
    9d60:      	cbz	x0, 0x9d9c <generic_kprobe_actions+0x3bc>
    9d64:      	ldr	w8, [x0]
    9d68:      	mov	x3, xzr
    9d6c:      	add	x9, sp, #0x78
    9d70:      	add	x10, sp, #0x58
    9d74:      	stp	w8, w24, [sp, #0x58]
    9d78:      	ldr	x8, [x0, #0x8]
    9d7c:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9d80:      	add	x1, sp, #0x78
    9d84:      	add	x2, sp, #0x58
    9d88:      	str	x8, [sp, #0x60]
    9d8c:      	mov	w8, #0x2                // =2
    9d90:      	ldr	x0, [x0]
    9d94:      	blr	x8
    9d98:      	mov	w0, wzr
    9d9c:      	adrp	x24, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9da0:      	ldr	x24, [x24]
    9da4:      	cbnz	w0, 0x9ae0 <generic_kprobe_actions+0x100>
    9da8:      	b	0xa37c <generic_kprobe_actions+0x99c>
    9dac:      	add	w29, w29, #0x1
    9db0:      	add	x8, x20, w29, uxtw #2
    9db4:      	ldr	w8, [x8, #0x4]
    9db8:      	str	w8, [x21, #0x78]
    9dbc:      	b	0xa37c <generic_kprobe_actions+0x99c>
    9dc0:      	str	wzr, [sp, #0x2c]
    9dc4:      	b	0xa37c <generic_kprobe_actions+0x99c>
    9dc8:      	ldr	w8, [sp, #0x3c]
    9dcc:      	add	w23, w29, #0x1
    9dd0:      	cbz	w8, 0xa0bc <generic_kprobe_actions+0x6dc>
    9dd4:      	add	x8, x20, w23, uxtw #2
    9dd8:      	ldr	w8, [x8, #0x4]
    9ddc:      	str	w8, [sp, #0x88]
    9de0:      	mov	w8, #0xe                // =14
    9de4:      	blr	x8
    9de8:      	str	x0, [sp, #0x78]
    9dec:      	adrp	x25, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9df0:      	mov	w8, #0x1                // =1
    9df4:      	add	x20, sp, #0x78
    9df8:      	ldr	x25, [x25]
    9dfc:      	add	x1, sp, #0x78
    9e00:      	mov	x0, x25
    9e04:      	blr	x8
    9e08:      	add	x29, sp, #0x58
    9e0c:      	cbz	x0, 0xa1b0 <generic_kprobe_actions+0x7d0>
    9e10:      	mov	w8, #0x11               // =17
    9e14:      	adrp	x20, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9e18:      	mov	x24, x0
    9e1c:      	add	x1, sp, #0x58
    9e20:      	movk	w8, #0xe, lsl #16
    9e24:      	str	w8, [sp, #0x58]
    9e28:      	mov	w8, #0x35c              // =860
    9e2c:      	stur	x8, [sp, #0x5c]
    9e30:      	mov	w8, #0x1                // =1
    9e34:      	ldr	x20, [x20]
    9e38:      	mov	x0, x20
    9e3c:      	blr	x8
    9e40:      	cbz	x0, 0xa304 <generic_kprobe_actions+0x924>
    9e44:      	ldr	w8, [x0]
    9e48:      	add	w8, w8, #0x1
    9e4c:      	str	w8, [x0]
    9e50:      	b	0xa328 <generic_kprobe_actions+0x948>
    9e54:      	mov	w8, #0xe                // =14
    9e58:      	blr	x8
    9e5c:      	str	x0, [sp, #0x68]
    9e60:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9e64:      	mov	w8, #0x1                // =1
    9e68:      	add	x9, sp, #0x68
    9e6c:      	ldr	x0, [x0]
    9e70:      	add	x1, sp, #0x68
    9e74:      	blr	x8
    9e78:      	cbz	x0, 0xa37c <generic_kprobe_actions+0x99c>
    9e7c:      	ldur	x8, [x0, #0x4]
    9e80:      	mov	x24, x25
    9e84:      	adrp	x25, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9e88:      	add	x9, sp, #0x78
    9e8c:      	str	x8, [sp, #0x78]
    9e90:      	mov	w8, #0x2                // =2
    9e94:      	add	x1, sp, #0x78
    9e98:      	str	w8, [sp, #0x80]
    9e9c:      	mov	w8, #0x1                // =1
    9ea0:      	ldr	x25, [x25]
    9ea4:      	mov	x0, x25
    9ea8:      	blr	x8
    9eac:      	mov	w9, #0x1                // =1
    9eb0:      	str	w9, [sp, #0x9c]
    9eb4:      	cbz	x0, 0xa13c <generic_kprobe_actions+0x75c>
    9eb8:      	mov	x25, x24
    9ebc:      	nop
    9ec0:      	ldaxr	w8, [x0]
    9ec4:      	add	w8, w8, #0x1
    9ec8:      	stlxr	w9, w8, [x0]
    9ecc:      	cbnz	w9, 0x9ec0 <generic_kprobe_actions+0x4e0>
    9ed0:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9ed4:      	mov	w8, #0x3                // =3
    9ed8:      	add	x9, sp, #0x68
    9edc:      	ldr	x0, [x0]
    9ee0:      	add	x1, sp, #0x68
    9ee4:      	blr	x8
    9ee8:      	adrp	x24, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9eec:      	ldr	x24, [x24]
    9ef0:      	b	0xa37c <generic_kprobe_actions+0x99c>
    9ef4:      	add	w8, w29, #0x1
    9ef8:      	add	x9, x20, #0x4
    9efc:      	ldr	w25, [x9, w8, uxtw #2]
    9f00:      	add	w8, w29, #0x2
    9f04:      	ldr	w20, [x9, w8, uxtw #2]
    9f08:      	mov	w8, #0x7d               // =125
    9f0c:      	blr	x8
    9f10:      	str	x0, [sp, #0x58]
    9f14:      	str	wzr, [sp, #0x68]
    9f18:      	str	x25, [sp, #0x8]
    9f1c:      	cbz	w25, 0xa648 <generic_kprobe_actions+0xc68>
    9f20:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9f24:      	mov	w8, #0x1                // =1
    9f28:      	add	x9, sp, #0x68
    9f2c:      	ldr	x0, [x0]
    9f30:      	add	x1, sp, #0x68
    9f34:      	blr	x8
    9f38:      	cbz	x0, 0xa648 <generic_kprobe_actions+0xc68>
    9f3c:      	mov	x25, x0
    9f40:      	adrp	x0, 0x9000 <generic_kprobe_filter_arg+0x2a30>
    9f44:      	mov	w8, #0x1                // =1
    9f48:      	ldr	x0, [x0]
    9f4c:      	add	x9, sp, #0x68
    9f50:      	add	x1, sp, #0x68
    9f54:      	blr	x8
    9f58:      	ldr	x8, [x21, #0x60]
    9f5c:      	mov	x2, x0
    9f60:      	cmp	w20, #0x2
    9f64:      	str	x25, [sp]
    9f68:      	str	x8, [x25]
    9f6c:      	ldr	x8, [x21, #0x70]
    9f70:      	str	x8, [x25, #0x8]
    9f74:      	b.eq	0xa458 <generic_kprobe_actions+0xa78>
    9f78:      	cmp	w20, #0x1
    9f7c:      	b.eq	0xa450 <generic_kprobe_actions+0xa70>
    9f80:      	cbnz	w20, 0xa648 <generic_kprobe_actions+0xc68>
    9f84:      	ldr	w8, [x21, #0x7c]
    9f88:      	b	0xa45c <generic_kprobe_actions+0xa7c>
    9f8c:      	mov	w0, #0x9                // =9
    9f90:      	ldr	w8, [sp, #0x3c]
    9f94:      	cbnz	w8, 0x9be4 <generic_kprobe_actions+0x204>
    9f98:      	mov	w20, #0x3               // =3
    9f9c:      	mov	w23, w29
    9fa0:      	add	x29, sp, #0x58
    9fa4:      	b	0xa340 <generic_kprobe_actions+0x960>
    9fa8:      	ldr	w8, [sp, #0x3c]
    9fac:      	add	w23, w29, #0x3
    9fb0:      	cbz	w8, 0xa0c8 <generic_kprobe_actions+0x6e8>
    9fb4:      	add	x8, x20, #0x4
    9fb8:      	ldr	w9, [x8, w23, uxtw #2]
    9fbc:      	cmp	w9, #0x4
    9fc0:      	b.hi	0x9fd4 <generic_kprobe_actions+0x5f4>
    9fc4:      	add	x10, x21, x9, lsl #2
    9fc8:      	mov	w11, #0x5ea0            // =24224
    9fcc:      	ldr	w10, [x10, x11]
    9fd0:      	cbz	w10, 0xa6e4 <generic_kprobe_actions+0xd04>
    9fd4:      	mov	x9, xzr
    9fd8:      	add	w10, w29, #0x2
    9fdc:      	ldr	w20, [x8, w10, uxtw #2]
    9fe0:      	add	w10, w29, #0x1
    9fe4:      	ldr	w24, [x8, w10, uxtw #2]
    9fe8:      	ldr	w8, [x21, #0x60]
    9fec:      	orr	x25, x8, x9, lsl #32
    9ff0:      	mov	w8, #0xe                // =14
    9ff4:      	blr	x8
    9ff8:      	str	x0, [sp, #0x88]
    9ffc:      	strh	w24, [sp, #0x78]
    a000:      	mov	w8, #0x1                // =1
    a004:      	add	x1, sp, #0x88
    a008:      	strh	w20, [sp, #0x7a]
    a00c:      	stur	x25, [sp, #0x7c]
    a010:      	adrp	x25, 0xa000 <generic_kprobe_actions+0x620>
    a014:      	ldr	x25, [x25]
    a018:      	add	x20, sp, #0x88
    a01c:      	mov	x0, x25
    a020:      	blr	x8
    a024:      	cbz	x0, 0xa28c <generic_kprobe_actions+0x8ac>
    a028:      	ldur	x8, [x0, #0x4]
    a02c:      	mov	w20, #0x1               // =1
    a030:      	adrp	x29, 0xa000 <generic_kprobe_actions+0x620>
    a034:      	add	x9, sp, #0x68
    a038:      	str	w20, [sp, #0x70]
    a03c:      	mov	x24, x0
    a040:      	add	x1, sp, #0x68
    a044:      	str	x8, [sp, #0x68]
    a048:      	mov	w8, #0x1                // =1
    a04c:      	ldr	x29, [x29]
    a050:      	mov	x0, x29
    a054:      	blr	x8
    a058:      	ldr	x25, [sp, #0x30]
    a05c:      	str	w20, [sp, #0x98]
    a060:      	cbz	x0, 0xa3dc <generic_kprobe_actions+0x9fc>
    a064:      	ldaxr	w8, [x0]
    a068:      	add	w8, w8, #0x1
    a06c:      	stlxr	w9, w8, [x0]
    a070:      	cbnz	w9, 0xa064 <generic_kprobe_actions+0x684>
    a074:      	ldr	x8, [sp, #0x78]
    a078:      	ldr	w9, [sp, #0x80]
    a07c:      	add	x29, sp, #0x58
    a080:      	str	w9, [x24, #0x8]
    a084:      	str	x8, [x24]
    a088:      	adrp	x24, 0xa000 <generic_kprobe_actions+0x620>
    a08c:      	ldr	x24, [x24]
    a090:      	mov	w20, #0x6               // =6
    a094:      	b	0xa340 <generic_kprobe_actions+0x960>
    a098:      	add	x9, x21, x8, lsl #2
    a09c:      	mov	w10, #0x5ea0            // =24224
    a0a0:      	add	x23, sp, #0x54
    a0a4:      	ldr	w9, [x9, x10]
    a0a8:      	cbz	w9, 0xa0d4 <generic_kprobe_actions+0x6f4>
    a0ac:      	ldr	x20, [sp, #0x40]
    a0b0:      	mov	w0, wzr
    a0b4:      	cbnz	w0, 0x9ae0 <generic_kprobe_actions+0x100>
    a0b8:      	b	0xa37c <generic_kprobe_actions+0x99c>
    a0bc:      	mov	w20, #0x5               // =5
    a0c0:      	add	x29, sp, #0x58
    a0c4:      	b	0xa340 <generic_kprobe_actions+0x960>
    a0c8:      	mov	w20, #0x7               // =7
    a0cc:      	add	x29, sp, #0x58
    a0d0:      	b	0xa340 <generic_kprobe_actions+0x960>
    a0d4:      	add	x8, x21, x8, lsl #3
    a0d8:      	mov	x23, x0
    a0dc:      	ldr	x8, [x8, #0x5e78]
    a0e0:      	str	wzr, [sp, #0x64]
    a0e4:      	and	x8, x8, #0x7ff
    a0e8:      	add	x8, x21, x8
    a0ec:      	ldr	w8, [x8, #0x90]
    a0f0:      	str	w8, [sp, #0x60]
    a0f4:      	mov	w8, #0xe                // =14
    a0f8:      	blr	x8
    a0fc:      	lsr	x8, x0, #32
    a100:      	cmp	w19, #0x1
    a104:      	str	x8, [sp, #0x58]
    a108:      	b.ne	0xa394 <generic_kprobe_actions+0x9b4>
    a10c:      	and	x8, x20, #0x7
    a110:      	cmp	w8, #0x4
    a114:      	b.hi	0x9cd4 <generic_kprobe_actions+0x2f4>
    a118:      	add	x9, x21, x8, lsl #2
    a11c:      	mov	w10, #0x5ea0            // =24224
    a120:      	ldr	x20, [sp, #0x40]
    a124:      	ldr	w9, [x9, x10]
    a128:      	cbz	w9, 0x9af4 <generic_kprobe_actions+0x114>
    a12c:      	mov	w0, wzr
    a130:      	add	x23, sp, #0x54
    a134:      	cbnz	w0, 0x9ae0 <generic_kprobe_actions+0x100>
    a138:      	b	0xa37c <generic_kprobe_actions+0x99c>
    a13c:      	mov	w8, #0x2                // =2
    a140:      	add	x10, sp, #0x9c
    a144:      	add	x11, sp, #0x78
    a148:      	add	x1, sp, #0x78
    a14c:      	add	x2, sp, #0x9c
    a150:      	mov	x0, x25
    a154:      	mov	w3, #0x1                // =1
    a158:      	blr	x8
    a15c:      	mov	x25, x24
    a160:      	cbz	x0, 0x9ed0 <generic_kprobe_actions+0x4f0>
    a164:      	mov	x24, x0
    a168:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    a16c:      	add	x10, sp, #0x58
    a170:      	add	x1, sp, #0x58
    a174:      	neg	w8, w24
    a178:      	strh	w8, [sp, #0x58]
    a17c:      	mov	w8, #0x3                // =3
    a180:      	strh	w8, [sp, #0x5a]
    a184:      	mov	x8, #0x3b               // =59
    a188:      	movk	x8, #0x2, lsl #32
    a18c:      	stur	x8, [sp, #0x5c]
    a190:      	mov	w8, #0x1                // =1
    a194:      	ldr	x0, [x0]
    a198:      	blr	x8
    a19c:      	cbz	x0, 0xa6fc <generic_kprobe_actions+0xd1c>
    a1a0:      	ldr	w8, [x0]
    a1a4:      	add	w8, w8, #0x1
    a1a8:      	str	w8, [x0]
    a1ac:      	b	0xa728 <generic_kprobe_actions+0xd48>
    a1b0:      	mov	x3, xzr
    a1b4:      	mov	w8, #0x2                // =2
    a1b8:      	add	x9, sp, #0x88
    a1bc:      	add	x1, sp, #0x78
    a1c0:      	add	x2, sp, #0x88
    a1c4:      	mov	x0, x25
    a1c8:      	blr	x8
    a1cc:      	ldr	x25, [sp, #0x30]
    a1d0:      	b	0xa334 <generic_kprobe_actions+0x954>
    a1d4:      	add	x8, x21, x8, lsl #3
    a1d8:      	ldr	x8, [x8, #0x5e78]
    a1dc:      	and	x8, x8, #0x7ff
    a1e0:      	add	x8, x21, x8
    a1e4:      	ldr	w8, [x8, #0x90]
    a1e8:      	str	w8, [sp, #0x60]
    a1ec:      	mov	w8, #0xe                // =14
    a1f0:      	blr	x8
    a1f4:      	lsr	x8, x0, #32
    a1f8:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    a1fc:      	add	x9, sp, #0x58
    a200:      	str	x8, [sp, #0x58]
    a204:      	mov	w8, #0x1                // =1
    a208:      	add	x1, sp, #0x58
    a20c:      	ldr	x0, [x0]
    a210:      	blr	x8
    a214:      	cbz	x0, 0x9c50 <generic_kprobe_actions+0x270>
    a218:      	and	x8, x20, #0x7
    a21c:      	cmp	w8, #0x4
    a220:      	b.hi	0x9c50 <generic_kprobe_actions+0x270>
    a224:      	add	x9, x21, x8, lsl #2
    a228:      	mov	w10, #0x5ea0            // =24224
    a22c:      	ldr	w9, [x9, x10]
    a230:      	cbnz	w9, 0x9c50 <generic_kprobe_actions+0x270>
    a234:      	add	x8, x21, x8, lsl #3
    a238:      	mov	x23, x0
    a23c:      	ldr	x8, [x8, #0x5e78]
    a240:      	str	wzr, [sp, #0x64]
    a244:      	and	x8, x8, #0x7ff
    a248:      	add	x8, x21, x8
    a24c:      	ldr	w8, [x8, #0x90]
    a250:      	str	w8, [sp, #0x60]
    a254:      	mov	w8, #0xe                // =14
    a258:      	blr	x8
    a25c:      	lsr	x8, x0, #32
    a260:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    a264:      	mov	x3, xzr
    a268:      	str	x8, [sp, #0x58]
    a26c:      	mov	w8, #0x2                // =2
    a270:      	add	x9, sp, #0x58
    a274:      	add	x1, sp, #0x58
    a278:      	ldr	x0, [x0]
    a27c:      	mov	x2, x23
    a280:      	add	x23, sp, #0x54
    a284:      	blr	x8
    a288:      	b	0x9c50 <generic_kprobe_actions+0x270>
    a28c:      	mov	x3, xzr
    a290:      	mov	w8, #0x2                // =2
    a294:      	add	x9, sp, #0x78
    a298:      	add	x1, sp, #0x88
    a29c:      	add	x2, sp, #0x78
    a2a0:      	mov	x0, x25
    a2a4:      	blr	x8
    a2a8:      	adrp	x24, 0xa000 <generic_kprobe_actions+0x620>
    a2ac:      	ldr	x25, [sp, #0x30]
    a2b0:      	add	x29, sp, #0x58
    a2b4:      	ldr	x24, [x24]
    a2b8:      	cbz	x0, 0xa090 <generic_kprobe_actions+0x6b0>
    a2bc:      	neg	w8, w0
    a2c0:      	adrp	x20, 0xa000 <generic_kprobe_actions+0x620>
    a2c4:      	add	x1, sp, #0x58
    a2c8:      	strh	w8, [sp, #0x58]
    a2cc:      	mov	w8, #0x3                // =3
    a2d0:      	strh	w8, [sp, #0x5a]
    a2d4:      	mov	x8, #0x6b               // =107
    a2d8:      	movk	x8, #0x2, lsl #32
    a2dc:      	stur	x8, [sp, #0x5c]
    a2e0:      	mov	w8, #0x1                // =1
    a2e4:      	ldr	x20, [x20]
    a2e8:      	mov	x0, x20
    a2ec:      	blr	x8
    a2f0:      	cbz	x0, 0xa760 <generic_kprobe_actions+0xd80>
    a2f4:      	ldr	w8, [x0]
    a2f8:      	add	w8, w8, #0x1
    a2fc:      	str	w8, [x0]
    a300:      	b	0xa090 <generic_kprobe_actions+0x6b0>
    a304:      	mov	w8, #0x1                // =1
    a308:      	mov	x3, xzr
    a30c:      	add	x9, sp, #0x68
    a310:      	str	w8, [sp, #0x68]
    a314:      	mov	w8, #0x2                // =2
    a318:      	add	x1, sp, #0x58
    a31c:      	add	x2, sp, #0x68
    a320:      	mov	x0, x20
    a324:      	blr	x8
    a328:      	ldr	w8, [sp, #0x88]
    a32c:      	ldr	x25, [sp, #0x30]
    a330:      	str	w8, [x24]
    a334:      	adrp	x24, 0xa000 <generic_kprobe_actions+0x620>
    a338:      	mov	w20, #0x4               // =4
    a33c:      	ldr	x24, [x24]
    a340:      	str	wzr, [sp, #0x58]
    a344:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    a348:      	mov	w8, #0x1                // =1
    a34c:      	add	x1, sp, #0x58
    a350:      	ldr	x0, [x0]
    a354:      	blr	x8
    a358:      	cbz	x0, 0xa370 <generic_kprobe_actions+0x990>
    a35c:      	add	x8, x0, x20, lsl #3
    a360:      	ldaxr	x9, [x8]
    a364:      	add	x9, x9, #0x1
    a368:      	stlxr	w10, x9, [x8]
    a36c:      	cbnz	w10, 0xa360 <generic_kprobe_actions+0x980>
    a370:      	ldr	x20, [sp, #0x40]
    a374:      	mov	w29, w23
    a378:      	add	x23, sp, #0x54
    a37c:      	add	w29, w29, #0x1
    a380:      	str	x19, [x21, #0x70]
    a384:      	add	w22, w22, #0x1
    a388:      	cmp	w22, #0x3
    a38c:      	b.ne	0x9b4c <generic_kprobe_actions+0x16c>
    a390:      	b	0xa7e8 <generic_kprobe_actions+0xe08>
    a394:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    a398:      	mov	w8, #0x3                // =3
    a39c:      	add	x9, sp, #0x58
    a3a0:      	ldr	x0, [x0]
    a3a4:      	add	x1, sp, #0x58
    a3a8:      	blr	x8
    a3ac:      	ldr	x20, [sp, #0x40]
    a3b0:      	add	x23, sp, #0x54
    a3b4:      	cbnz	w0, 0x9ae0 <generic_kprobe_actions+0x100>
    a3b8:      	b	0xa37c <generic_kprobe_actions+0x99c>
    a3bc:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    a3c0:      	mov	w8, #0x3                // =3
    a3c4:      	add	x9, sp, #0x78
    a3c8:      	ldr	x0, [x0]
    a3cc:      	add	x1, sp, #0x78
    a3d0:      	blr	x8
    a3d4:      	cbnz	w0, 0x9ae0 <generic_kprobe_actions+0x100>
    a3d8:      	b	0xa37c <generic_kprobe_actions+0x99c>
    a3dc:      	mov	w8, #0x2                // =2
    a3e0:      	add	x9, sp, #0x98
    a3e4:      	add	x10, sp, #0x68
    a3e8:      	add	x1, sp, #0x68
    a3ec:      	add	x2, sp, #0x98
    a3f0:      	mov	x0, x29
    a3f4:      	mov	w3, #0x1                // =1
    a3f8:      	blr	x8
    a3fc:      	cbz	x0, 0xa074 <generic_kprobe_actions+0x694>
    a400:      	mov	x29, x0
    a404:      	adrp	x20, 0xa000 <generic_kprobe_actions+0x620>
    a408:      	add	x9, sp, #0x58
    a40c:      	add	x1, sp, #0x58
    a410:      	neg	w8, w29
    a414:      	strh	w8, [sp, #0x58]
    a418:      	mov	w8, #0x3                // =3
    a41c:      	strh	w8, [sp, #0x5a]
    a420:      	mov	x8, #0x3b               // =59
    a424:      	movk	x8, #0x2, lsl #32
    a428:      	stur	x8, [sp, #0x5c]
    a42c:      	mov	w8, #0x1                // =1
    a430:      	ldr	x20, [x20]
    a434:      	mov	x0, x20
    a438:      	blr	x8
    a43c:      	cbz	x0, 0xa788 <generic_kprobe_actions+0xda8>
    a440:      	ldr	w8, [x0]
    a444:      	add	w8, w8, #0x1
    a448:      	str	w8, [x0]
    a44c:      	b	0xa7b0 <generic_kprobe_actions+0xdd0>
    a450:      	ldr	w8, [x21, #0x10]
    a454:      	b	0xa45c <generic_kprobe_actions+0xa7c>
    a458:      	mov	x8, xzr
    a45c:      	ldr	x9, [sp]
    a460:      	ldr	x25, [sp, #0x30]
    a464:      	mov	w1, #0xc8               // =200
    a468:      	add	x0, x9, #0x18
    a46c:      	str	x8, [x9, #0x10]
    a470:      	mov	w8, #0x4                // =4
    a474:      	mov	w9, #0xc8               // =200
    a478:      	str	x0, [sp, #0x10]
    a47c:      	blr	x8
    a480:      	mov	w8, #0x5e78             // =24184
    a484:      	mov	x24, xzr
    a488:      	str	wzr, [sp, #0x1c]
    a48c:      	add	x20, x21, x8
    a490:      	b	0xa4b0 <generic_kprobe_actions+0xad0>
    a494:      	nop
    a498:      	nop
    a49c:      	nop
    a4a0:      	add	x24, x24, #0x4
    a4a4:      	add	x20, x20, #0x8
    a4a8:      	cmp	x24, #0x14
    a4ac:      	b.eq	0xa5d8 <generic_kprobe_actions+0xbf8>
    a4b0:      	str	wzr, [sp, #0x78]
    a4b4:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    a4b8:      	mov	w8, #0x1                // =1
    a4bc:      	add	x9, sp, #0x78
    a4c0:      	ldr	x0, [x0]
    a4c4:      	add	x1, sp, #0x78
    a4c8:      	blr	x8
    a4cc:      	cbz	x0, 0xa5d8 <generic_kprobe_actions+0xbf8>
    a4d0:      	mov	w8, #0x5ef8             // =24312
    a4d4:      	add	x1, x0, x8
    a4d8:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    a4dc:      	mov	w8, #0x1                // =1
    a4e0:      	ldr	x0, [x0]
    a4e4:      	blr	x8
    a4e8:      	cbz	x0, 0xa5d8 <generic_kprobe_actions+0xbf8>
    a4ec:      	add	x8, x0, x24
    a4f0:      	ldr	w8, [x8, #0x40]
    a4f4:      	cmn	w8, #0x1
    a4f8:      	b.eq	0xa5d8 <generic_kprobe_actions+0xbf8>
    a4fc:      	ldr	x8, [x20]
    a500:      	ldr	w9, [x21, #0x4]
    a504:      	cmp	x8, x9
    a508:      	b.ge	0xa5d8 <generic_kprobe_actions+0xbf8>
    a50c:      	cmp	x24, #0x10
    a510:      	b.eq	0xa574 <generic_kprobe_actions+0xb94>
    a514:      	str	wzr, [sp, #0x78]
    a518:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    a51c:      	mov	w8, #0x1                // =1
    a520:      	add	x9, sp, #0x78
    a524:      	ldr	x0, [x0]
    a528:      	add	x1, sp, #0x78
    a52c:      	blr	x8
    a530:      	cbz	x0, 0xa570 <generic_kprobe_actions+0xb90>
    a534:      	mov	w8, #0x5ef8             // =24312
    a538:      	add	x1, x0, x8
    a53c:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    a540:      	mov	w8, #0x1                // =1
    a544:      	ldr	x0, [x0]
    a548:      	blr	x8
    a54c:      	cbz	x0, 0xa570 <generic_kprobe_actions+0xb90>
    a550:      	add	x8, x0, x24
    a554:      	ldr	w9, [x8, #0x44]
    a558:      	ldr	x8, [x20]
    a55c:      	cmn	w9, #0x1
    a560:      	b.eq	0xa574 <generic_kprobe_actions+0xb94>
    a564:      	ldr	w9, [x20, #0x8]
    a568:      	sub	w9, w9, w8
    a56c:      	b	0xa580 <generic_kprobe_actions+0xba0>
    a570:      	ldr	x8, [x20]
    a574:      	ldr	w9, [x21, #0x4]
    a578:      	sub	w9, w9, w8
    a57c:      	add	w9, w9, #0x4
    a580:      	cmp	w9, #0x1
    a584:      	b.lt	0xa4a0 <generic_kprobe_actions+0xac0>
    a588:      	mov	w10, #0x3ffc            // =16380
    a58c:      	cmp	w9, #0x28
    a590:      	add	w8, w8, w10
    a594:      	mov	w10, #0x28              // =40
    a598:      	csel	w23, w9, w10, lt
    a59c:      	ldr	w9, [sp, #0x1c]
    a5a0:      	and	x8, x8, #0x3fff
    a5a4:      	add	x8, x21, x8
    a5a8:      	mov	w1, w23
    a5ac:      	add	x2, x8, #0x90
    a5b0:      	mov	w8, #0x4                // =4
    a5b4:      	and	w25, w9, #0xff
    a5b8:      	ldr	x9, [sp, #0x10]
    a5bc:      	add	x0, x9, x25
    a5c0:      	blr	x8
    a5c4:      	add	w8, w23, w25
    a5c8:      	ldr	x25, [sp, #0x30]
    a5cc:      	add	x23, sp, #0x54
    a5d0:      	str	w8, [sp, #0x1c]
    a5d4:      	b	0xa4a0 <generic_kprobe_actions+0xac0>
    a5d8:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    a5dc:      	mov	w8, #0x1                // =1
    a5e0:      	ldr	x0, [x0]
    a5e4:      	ldr	x1, [sp]
    a5e8:      	blr	x8
    a5ec:      	cbz	x0, 0xa620 <generic_kprobe_actions+0xc40>
    a5f0:      	ldr	x9, [sp, #0x58]
    a5f4:      	ldr	x11, [sp, #0x8]
    a5f8:      	mov	x10, #-0x4240           // =-16960
    a5fc:      	movk	x10, #0xfff0, lsl #16
    a600:      	ldr	x8, [x0]
    a604:      	madd	x9, x11, x10, x9
    a608:      	cmp	x8, x9
    a60c:      	b.ls	0xa620 <generic_kprobe_actions+0xc40>
    a610:      	str	wzr, [sp, #0x2c]
    a614:      	adrp	x24, 0xa000 <generic_kprobe_actions+0x620>
    a618:      	ldr	x24, [x24]
    a61c:      	b	0xa64c <generic_kprobe_actions+0xc6c>
    a620:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    a624:      	mov	x3, xzr
    a628:      	mov	w8, #0x2                // =2
    a62c:      	ldr	x0, [x0]
    a630:      	ldr	x1, [sp]
    a634:      	add	x9, sp, #0x58
    a638:      	add	x2, sp, #0x58
    a63c:      	blr	x8
    a640:      	adrp	x24, 0xa000 <generic_kprobe_actions+0x620>
    a644:      	ldr	x24, [x24]
    a648:      	ldr	x25, [sp, #0x30]
    a64c:      	ldr	x20, [sp, #0x40]
    a650:      	add	w8, w29, #0x3
    a654:      	add	x8, x20, w8, uxtw #2
    a658:      	ldr	w8, [x8, #0x4]
    a65c:      	cbz	w8, 0xa688 <generic_kprobe_actions+0xca8>
    a660:      	ldrb	w8, [x21, #0x1]
    a664:      	adrp	x1, 0xa000 <generic_kprobe_actions+0x620>
    a668:      	mov	x2, xzr
    a66c:      	mov	x0, x25
    a670:      	orr	w8, w8, #0x2
    a674:      	strb	w8, [x21, #0x1]
    a678:      	mov	w8, #0x1b               // =27
    a67c:      	ldr	x1, [x1]
    a680:      	blr	x8
    a684:      	str	x0, [x21, #0x80]
    a688:      	add	w8, w29, #0x4
    a68c:      	add	x8, x20, w8, uxtw #2
    a690:      	ldr	w8, [x8, #0x4]
    a694:      	cbz	w8, 0xa6c4 <generic_kprobe_actions+0xce4>
    a698:      	ldrb	w8, [x21, #0x1]
    a69c:      	adrp	x1, 0xa000 <generic_kprobe_actions+0x620>
    a6a0:      	mov	w9, #0x100              // =256
    a6a4:      	mov	x0, x25
    a6a8:      	mov	w2, #0x100              // =256
    a6ac:      	orr	w8, w8, #0x4
    a6b0:      	strb	w8, [x21, #0x1]
    a6b4:      	mov	w8, #0x1b               // =27
    a6b8:      	ldr	x1, [x1]
    a6bc:      	blr	x8
    a6c0:      	str	x0, [x21, #0x88]
    a6c4:      	add	w29, w29, #0x5
    a6c8:      	add	x8, x20, w29, uxtw #2
    a6cc:      	ldr	w8, [x8, #0x4]
    a6d0:      	cbz	w8, 0xa37c <generic_kprobe_actions+0x99c>
    a6d4:      	ldrb	w8, [x21, #0x1]
    a6d8:      	orr	w8, w8, #0x8
    a6dc:      	strb	w8, [x21, #0x1]
    a6e0:      	b	0xa37c <generic_kprobe_actions+0x99c>
    a6e4:      	add	x9, x21, x9, lsl #3
    a6e8:      	ldr	x9, [x9, #0x5e78]
    a6ec:      	and	x9, x9, #0x7ff
    a6f0:      	add	x9, x21, x9
    a6f4:      	ldr	x9, [x9, #0x90]
    a6f8:      	b	0x9fd8 <generic_kprobe_actions+0x5f8>
    a6fc:      	mov	w8, #0x1                // =1
    a700:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    a704:      	mov	x3, xzr
    a708:      	str	w8, [sp, #0x88]
    a70c:      	mov	w8, #0x2                // =2
    a710:      	add	x9, sp, #0x88
    a714:      	add	x10, sp, #0x58
    a718:      	ldr	x0, [x0]
    a71c:      	add	x1, sp, #0x58
    a720:      	add	x2, sp, #0x88
    a724:      	blr	x8
    a728:      	cbz	w24, 0x9ed0 <generic_kprobe_actions+0x4f0>
    a72c:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    a730:      	mov	w8, #0x1                // =1
    a734:      	add	x9, sp, #0x78
    a738:      	ldr	x0, [x0]
    a73c:      	add	x1, sp, #0x78
    a740:      	blr	x8
    a744:      	cbz	x0, 0x9ed0 <generic_kprobe_actions+0x4f0>
    a748:      	ldr	w8, [sp, #0x9c]
    a74c:      	ldaxr	w9, [x0]
    a750:      	add	w9, w9, w8
    a754:      	stlxr	w10, w9, [x0]
    a758:      	cbnz	w10, 0xa74c <generic_kprobe_actions+0xd6c>
    a75c:      	b	0x9ed0 <generic_kprobe_actions+0x4f0>
    a760:      	mov	w8, #0x1                // =1
    a764:      	mov	x3, xzr
    a768:      	add	x9, sp, #0x68
    a76c:      	str	w8, [sp, #0x68]
    a770:      	mov	w8, #0x2                // =2
    a774:      	add	x1, sp, #0x58
    a778:      	add	x2, sp, #0x68
    a77c:      	mov	x0, x20
    a780:      	blr	x8
    a784:      	b	0xa090 <generic_kprobe_actions+0x6b0>
    a788:      	mov	w8, #0x1                // =1
    a78c:      	mov	x3, xzr
    a790:      	add	x9, sp, #0x9c
    a794:      	str	w8, [sp, #0x9c]
    a798:      	mov	w8, #0x2                // =2
    a79c:      	add	x10, sp, #0x58
    a7a0:      	add	x1, sp, #0x58
    a7a4:      	add	x2, sp, #0x9c
    a7a8:      	mov	x0, x20
    a7ac:      	blr	x8
    a7b0:      	cbz	w29, 0xa074 <generic_kprobe_actions+0x694>
    a7b4:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    a7b8:      	mov	w8, #0x1                // =1
    a7bc:      	add	x9, sp, #0x68
    a7c0:      	ldr	x0, [x0]
    a7c4:      	add	x1, sp, #0x68
    a7c8:      	blr	x8
    a7cc:      	cbz	x0, 0xa074 <generic_kprobe_actions+0x694>
    a7d0:      	ldr	w8, [sp, #0x98]
    a7d4:      	ldaxr	w9, [x0]
    a7d8:      	add	w9, w9, w8
    a7dc:      	stlxr	w10, w9, [x0]
    a7e0:      	cbnz	w10, 0xa7d4 <generic_kprobe_actions+0xdf4>
    a7e4:      	b	0xa074 <generic_kprobe_actions+0x694>
    a7e8:      	ldr	w8, [sp, #0x2c]
    a7ec:      	cbz	w8, 0xa80c <generic_kprobe_actions+0xe2c>
    a7f0:      	adrp	x1, 0xa000 <generic_kprobe_actions+0x620>
    a7f4:      	mov	w8, #0x5                // =5
    a7f8:      	mov	w9, #0xc                // =12
    a7fc:      	ldr	x1, [x1]
    a800:      	mov	x0, x25
    a804:      	mov	w2, #0x5                // =5
    a808:      	blr	x9
    a80c:      	ldp	x20, x19, [sp, #0xd0]
    a810:      	mov	w0, wzr
    a814:      	ldr	x29, [sp, #0x90]
    a818:      	ldp	x22, x21, [sp, #0xc0]
    a81c:      	ldp	x24, x23, [sp, #0xb0]
    a820:      	ldp	x30, x25, [sp, #0xa0]
    a824:      	add	sp, sp, #0xe0
    a828:      	ret
    a82c:      	nop

000000000000a830 <generic_kprobe_output>:
    a830:      	sub	sp, sp, #0xc0
    a834:      	str	x29, [sp, #0x70]
    a838:      	stp	x30, x25, [sp, #0x80]
    a83c:      	stp	x24, x23, [sp, #0x90]
    a840:      	stp	x22, x21, [sp, #0xa0]
    a844:      	stp	x20, x19, [sp, #0xb0]
    a848:      	mov	x20, x0
    a84c:      	str	wzr, [sp, #0x4]
    a850:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    a854:      	mov	w8, #0x1                // =1
    a858:      	ldr	x0, [x0]
    a85c:      	add	x9, sp, #0x4
    a860:      	add	x1, sp, #0x4
    a864:      	blr	x8
    a868:      	cbz	x0, 0xae10 <generic_kprobe_output+0x5e0>
    a86c:      	adrp	x21, 0xa000 <generic_kprobe_actions+0x620>
    a870:      	ldr	x8, [x0, #0x5ee8]
    a874:      	mov	x19, x0
    a878:      	ldr	x21, [x21]
    a87c:      	cbz	x8, 0xab08 <generic_kprobe_output+0x2d8>
    a880:      	mov	w8, #0xe                // =14
    a884:      	blr	x8
    a888:      	mov	w8, #0x23               // =35
    a88c:      	lsr	x22, x0, #32
    a890:      	blr	x8
    a894:      	str	w22, [sp, #0x28]
    a898:      	mov	w8, #0x1                // =1
    a89c:      	add	x9, sp, #0x28
    a8a0:      	mov	x23, x0
    a8a4:      	add	x1, sp, #0x28
    a8a8:      	mov	x0, x21
    a8ac:      	blr	x8
    a8b0:      	cbz	x0, 0xab08 <generic_kprobe_output+0x2d8>
    a8b4:      	add	x2, x23, #0xb50
    a8b8:      	mov	w29, #0x8               // =8
    a8bc:      	add	x8, sp, #0x78
    a8c0:      	mov	w9, #0x4                // =4
    a8c4:      	mov	x22, x0
    a8c8:      	add	x24, x0, #0x28
    a8cc:      	add	x0, sp, #0x78
    a8d0:      	mov	w1, #0x8                // =8
    a8d4:      	mov	w25, #0x4               // =4
    a8d8:      	blr	x9
    a8dc:      	ldr	x8, [sp, #0x78]
    a8e0:      	mov	w9, #0x48               // =72
    a8e4:      	add	x10, sp, #0x28
    a8e8:      	mov	w11, #0x4               // =4
    a8ec:      	ldr	x2, [sp, #0x78]
    a8f0:      	add	x0, sp, #0x28
    a8f4:      	mov	w1, #0x48               // =72
    a8f8:      	blr	x11
    a8fc:      	ldr	x8, [sp, #0x30]
    a900:      	mov	w9, #0x4                // =4
    a904:      	mov	x0, x24
    a908:      	mov	w1, #0x4                // =4
    a90c:      	add	x8, x8, #0x218
    a910:      	ldr	x8, [sp, #0x30]
    a914:      	add	x2, x8, #0x218
    a918:      	blr	x9
    a91c:      	ldr	x8, [sp, #0x38]
    a920:      	add	x0, x22, #0x2c
    a924:      	mov	w9, #0x4                // =4
    a928:      	mov	w1, #0x4                // =4
    a92c:      	add	x8, x8, #0x4d8
    a930:      	ldr	x8, [sp, #0x38]
    a934:      	add	x2, x8, #0x4d8
    a938:      	blr	x9
    a93c:      	ldr	x8, [sp, #0x40]
    a940:      	add	x0, x22, #0x30
    a944:      	mov	w9, #0x4                // =4
    a948:      	mov	w1, #0x4                // =4
    a94c:      	add	x8, x8, #0x58
    a950:      	ldr	x8, [sp, #0x40]
    a954:      	add	x2, x8, #0x58
    a958:      	blr	x9
    a95c:      	str	xzr, [sp, #0x20]
    a960:      	add	x2, x23, #0x938
    a964:      	add	x8, sp, #0x20
    a968:      	add	x0, sp, #0x20
    a96c:      	mov	w1, #0x8                // =8
    a970:      	blr	x25
    a974:      	ldr	x8, [sp, #0x20]
    a978:      	cbz	x8, 0xa9fc <generic_kprobe_output+0x1cc>
    a97c:      	str	wzr, [sp, #0x1c]
    a980:      	add	x8, x8, #0x4
    a984:      	add	x9, sp, #0x1c
    a988:      	mov	w10, #0x4               // =4
    a98c:      	add	x0, sp, #0x1c
    a990:      	mov	w1, #0x4                // =4
    a994:      	mov	w24, #0x4               // =4
    a998:      	ldr	x8, [sp, #0x20]
    a99c:      	add	x2, x8, #0x4
    a9a0:      	blr	x10
    a9a4:      	ldr	x8, [sp, #0x20]
    a9a8:      	ldrsw	x9, [sp, #0x1c]
    a9ac:      	add	x10, sp, #0x8
    a9b0:      	mov	w11, #0x4               // =4
    a9b4:      	add	x0, sp, #0x8
    a9b8:      	mov	w1, #0x10               // =16
    a9bc:      	add	x8, x8, x9, lsl #4
    a9c0:      	mov	w9, #0x10               // =16
    a9c4:      	add	x8, x8, #0x80
    a9c8:      	ldr	x8, [sp, #0x20]
    a9cc:      	ldrsw	x9, [sp, #0x1c]
    a9d0:      	add	x8, x8, x9, lsl #4
    a9d4:      	add	x2, x8, #0x80
    a9d8:      	blr	x11
    a9dc:      	ldr	x8, [sp, #0x10]
    a9e0:      	add	x0, x22, #0x34
    a9e4:      	mov	w1, #0x4                // =4
    a9e8:      	add	x8, x8, #0x158
    a9ec:      	ldr	x8, [sp, #0x10]
    a9f0:      	add	x2, x8, #0x158
    a9f4:      	blr	x24
    a9f8:      	b	0xaa00 <generic_kprobe_output+0x1d0>
    a9fc:      	str	wzr, [x22, #0x34]
    aa00:      	ldr	x8, [sp, #0x48]
    aa04:      	add	x0, x22, #0x38
    aa08:      	mov	w9, #0x4                // =4
    aa0c:      	mov	w1, #0x4                // =4
    aa10:      	mov	w24, #0x4               // =4
    aa14:      	add	x8, x8, #0x158
    aa18:      	ldr	x8, [sp, #0x48]
    aa1c:      	add	x2, x8, #0x158
    aa20:      	blr	x9
    aa24:      	ldr	x8, [sp, #0x50]
    aa28:      	add	x0, x22, #0x3c
    aa2c:      	mov	w9, #0x4                // =4
    aa30:      	mov	w1, #0x4                // =4
    aa34:      	add	x8, x8, #0x118
    aa38:      	ldr	x8, [sp, #0x50]
    aa3c:      	add	x2, x8, #0x118
    aa40:      	blr	x9
    aa44:      	ldr	x8, [sp, #0x58]
    aa48:      	add	x0, x22, #0x40
    aa4c:      	mov	w9, #0x4                // =4
    aa50:      	mov	w1, #0x4                // =4
    aa54:      	add	x8, x8, #0x98
    aa58:      	ldr	x8, [sp, #0x58]
    aa5c:      	add	x2, x8, #0x98
    aa60:      	blr	x9
    aa64:      	ldr	x8, [sp, #0x60]
    aa68:      	add	x0, x22, #0x44
    aa6c:      	mov	w9, #0x4                // =4
    aa70:      	mov	w1, #0x4                // =4
    aa74:      	add	x8, x8, #0x98
    aa78:      	ldr	x8, [sp, #0x60]
    aa7c:      	add	x2, x8, #0x98
    aa80:      	blr	x9
    aa84:      	ldr	x8, [sp, #0x68]
    aa88:      	add	x0, x22, #0x48
    aa8c:      	mov	w9, #0x4                // =4
    aa90:      	mov	w1, #0x4                // =4
    aa94:      	add	x8, x8, #0x58
    aa98:      	ldr	x8, [sp, #0x68]
    aa9c:      	add	x2, x8, #0x58
    aaa0:      	blr	x9
    aaa4:      	str	xzr, [sp, #0x8]
    aaa8:      	str	xzr, [sp, #0x20]
    aaac:      	add	x2, x23, #0xae0
    aab0:      	mov	w23, #0x8               // =8
    aab4:      	add	x8, sp, #0x8
    aab8:      	mov	w9, #0x4                // =4
    aabc:      	add	x0, sp, #0x8
    aac0:      	mov	w1, #0x8                // =8
    aac4:      	blr	x9
    aac8:      	ldr	x8, [sp, #0x8]
    aacc:      	add	x9, sp, #0x20
    aad0:      	mov	w10, #0x4               // =4
    aad4:      	add	x0, sp, #0x20
    aad8:      	mov	w1, #0x8                // =8
    aadc:      	add	x8, x8, #0x90
    aae0:      	ldr	x8, [sp, #0x8]
    aae4:      	add	x2, x8, #0x90
    aae8:      	blr	x10
    aaec:      	ldr	x8, [sp, #0x20]
    aaf0:      	add	x0, x22, #0x4c
    aaf4:      	mov	w1, #0x4                // =4
    aaf8:      	add	x8, x8, #0x158
    aafc:      	ldr	x8, [sp, #0x20]
    ab00:      	add	x2, x8, #0x158
    ab04:      	blr	x24
    ab08:      	ldr	x8, [x19, #0x5ef0]
    ab0c:      	cbz	x8, 0xaba8 <generic_kprobe_output+0x378>
    ab10:      	mov	w8, #0xe                // =14
    ab14:      	blr	x8
    ab18:      	mov	w8, #0x23               // =35
    ab1c:      	lsr	x23, x0, #32
    ab20:      	blr	x8
    ab24:      	str	w23, [sp, #0x28]
    ab28:      	mov	w8, #0x1                // =1
    ab2c:      	add	x9, sp, #0x28
    ab30:      	mov	x22, x0
    ab34:      	add	x1, sp, #0x28
    ab38:      	mov	x0, x21
    ab3c:      	blr	x8
    ab40:      	cbz	x0, 0xaba8 <generic_kprobe_output+0x378>
    ab44:      	add	x2, x22, #0xae0
    ab48:      	mov	w22, #0x8               // =8
    ab4c:      	add	x8, sp, #0x28
    ab50:      	mov	w9, #0x4                // =4
    ab54:      	add	x21, x0, #0x50
    ab58:      	mov	x24, x0
    ab5c:      	add	x0, sp, #0x28
    ab60:      	mov	w1, #0x8                // =8
    ab64:      	mov	w23, #0x4               // =4
    ab68:      	blr	x9
    ab6c:      	ldr	x25, [sp, #0x28]
    ab70:      	add	x0, x24, #0x58
    ab74:      	mov	w8, #0x4                // =4
    ab78:      	mov	w1, #0x8                // =8
    ab7c:      	add	x2, x25, #0x40
    ab80:      	blr	x8
    ab84:      	add	x0, x24, #0x60
    ab88:      	add	x2, x25, #0x30
    ab8c:      	mov	w8, #0x4                // =4
    ab90:      	mov	w1, #0x8                // =8
    ab94:      	blr	x8
    ab98:      	add	x2, x25, #0x38
    ab9c:      	mov	x0, x21
    aba0:      	mov	w1, #0x8                // =8
    aba4:      	blr	x23
    aba8:      	ldr	w8, [x19, #0x4]
    abac:      	mov	w9, #0x2328             // =9000
    abb0:      	str	wzr, [sp, #0x8]
    abb4:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    abb8:      	add	x1, sp, #0x8
    abbc:      	add	w8, w8, #0x90
    abc0:      	ldr	x0, [x0]
    abc4:      	and	w8, w8, #0x7fff
    abc8:      	cmp	w8, w9
    abcc:      	csel	w21, w8, w9, lo
    abd0:      	mov	w8, #0x1                // =1
    abd4:      	add	x9, sp, #0x8
    abd8:      	blr	x8
    abdc:      	cbz	x0, 0xac54 <generic_kprobe_output+0x424>
    abe0:      	ldrb	w8, [x0, #0x28]
    abe4:      	cbz	w8, 0xac54 <generic_kprobe_output+0x424>
    abe8:      	adrp	x1, 0xa000 <generic_kprobe_actions+0x620>
    abec:      	mov	w8, #-0x1               // =-1
    abf0:      	mov	w9, #0x19               // =25
    abf4:      	ldr	x1, [x1]
    abf8:      	mov	x0, x20
    abfc:      	mov	w2, #-0x1               // =-1
    ac00:      	mov	x3, x19
    ac04:      	mov	x4, x21
    ac08:      	blr	x9
    ac0c:      	tbnz	x0, #0x3f, 0xad04 <generic_kprobe_output+0x4d4>
    ac10:      	str	wzr, [sp, #0x28]
    ac14:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    ac18:      	mov	w8, #0x1                // =1
    ac1c:      	add	x9, sp, #0x28
    ac20:      	ldr	x0, [x0]
    ac24:      	add	x1, sp, #0x28
    ac28:      	blr	x8
    ac2c:      	cbz	x0, 0xae10 <generic_kprobe_output+0x5e0>
    ac30:      	add	x8, x0, #0x8
    ac34:      	nop
    ac38:      	nop
    ac3c:      	nop
    ac40:      	ldaxr	x9, [x8]
    ac44:      	add	x9, x9, #0x1
    ac48:      	stlxr	w10, x9, [x8]
    ac4c:      	cbnz	w10, 0xac40 <generic_kprobe_output+0x410>
    ac50:      	b	0xae10 <generic_kprobe_output+0x5e0>
    ac54:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    ac58:      	mov	x3, xzr
    ac5c:      	mov	w8, #0x82               // =130
    ac60:      	ldr	x0, [x0]
    ac64:      	mov	x1, x19
    ac68:      	mov	x2, x21
    ac6c:      	blr	x8
    ac70:      	tbnz	x0, #0x3f, 0xacb4 <generic_kprobe_output+0x484>
    ac74:      	str	wzr, [sp, #0x28]
    ac78:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    ac7c:      	mov	w8, #0x1                // =1
    ac80:      	add	x9, sp, #0x28
    ac84:      	ldr	x0, [x0]
    ac88:      	add	x1, sp, #0x28
    ac8c:      	blr	x8
    ac90:      	cbz	x0, 0xae10 <generic_kprobe_output+0x5e0>
    ac94:      	add	x8, x0, #0x8
    ac98:      	nop
    ac9c:      	nop
    aca0:      	ldaxr	x9, [x8]
    aca4:      	add	x9, x9, #0x1
    aca8:      	stlxr	w10, x9, [x8]
    acac:      	cbnz	w10, 0xaca0 <generic_kprobe_output+0x470>
    acb0:      	b	0xae10 <generic_kprobe_output+0x5e0>
    acb4:      	mov	x19, x0
    acb8:      	str	wzr, [sp, #0x28]
    acbc:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    acc0:      	mov	w8, #0x1                // =1
    acc4:      	ldr	x0, [x0]
    acc8:      	add	x9, sp, #0x28
    accc:      	add	x1, sp, #0x28
    acd0:      	blr	x8
    acd4:      	cbz	x0, 0xae10 <generic_kprobe_output+0x5e0>
    acd8:      	mov	x8, x19
    acdc:      	cmn	x19, #0xc
    ace0:      	b.gt	0xad54 <generic_kprobe_output+0x524>
    ace4:      	cmn	x8, #0x1c
    ace8:      	b.eq	0xad94 <generic_kprobe_output+0x564>
    acec:      	cmn	x8, #0x16
    acf0:      	b.eq	0xadac <generic_kprobe_output+0x57c>
    acf4:      	cmn	x8, #0x10
    acf8:      	b.ne	0xada4 <generic_kprobe_output+0x574>
    acfc:      	add	x8, x0, #0x2f0
    ad00:      	b	0xadc0 <generic_kprobe_output+0x590>
    ad04:      	mov	x19, x0
    ad08:      	str	wzr, [sp, #0x28]
    ad0c:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    ad10:      	mov	w8, #0x1                // =1
    ad14:      	ldr	x0, [x0]
    ad18:      	add	x9, sp, #0x28
    ad1c:      	add	x1, sp, #0x28
    ad20:      	blr	x8
    ad24:      	cbz	x0, 0xae10 <generic_kprobe_output+0x5e0>
    ad28:      	mov	x8, x19
    ad2c:      	cmn	x19, #0xc
    ad30:      	b.gt	0xad74 <generic_kprobe_output+0x544>
    ad34:      	cmn	x8, #0x1c
    ad38:      	b.eq	0xadd4 <generic_kprobe_output+0x5a4>
    ad3c:      	cmn	x8, #0x16
    ad40:      	b.eq	0xadec <generic_kprobe_output+0x5bc>
    ad44:      	cmn	x8, #0x10
    ad48:      	b.ne	0xade4 <generic_kprobe_output+0x5b4>
    ad4c:      	add	x8, x0, #0x2f0
    ad50:      	b	0xae00 <generic_kprobe_output+0x5d0>
    ad54:      	cmn	x8, #0xb
    ad58:      	b.eq	0xad9c <generic_kprobe_output+0x56c>
    ad5c:      	cmn	x8, #0x7
    ad60:      	b.eq	0xadb4 <generic_kprobe_output+0x584>
    ad64:      	cmn	x8, #0x2
    ad68:      	b.ne	0xada4 <generic_kprobe_output+0x574>
    ad6c:      	add	x8, x0, #0x2e0
    ad70:      	b	0xadc0 <generic_kprobe_output+0x590>
    ad74:      	cmn	x8, #0xb
    ad78:      	b.eq	0xaddc <generic_kprobe_output+0x5ac>
    ad7c:      	cmn	x8, #0x7
    ad80:      	b.eq	0xadf4 <generic_kprobe_output+0x5c4>
    ad84:      	cmn	x8, #0x2
    ad88:      	b.ne	0xade4 <generic_kprobe_output+0x5b4>
    ad8c:      	add	x8, x0, #0x2e0
    ad90:      	b	0xae00 <generic_kprobe_output+0x5d0>
    ad94:      	add	x8, x0, #0x300
    ad98:      	b	0xadc0 <generic_kprobe_output+0x590>
    ad9c:      	add	x8, x0, #0x308
    ada0:      	b	0xadc0 <generic_kprobe_output+0x590>
    ada4:      	add	x8, x0, #0x2d8
    ada8:      	b	0xadc0 <generic_kprobe_output+0x590>
    adac:      	add	x8, x0, #0x2f8
    adb0:      	b	0xadc0 <generic_kprobe_output+0x590>
    adb4:      	add	x8, x0, #0x2e8
    adb8:      	nop
    adbc:      	nop
    adc0:      	ldaxr	x9, [x8]
    adc4:      	add	x9, x9, #0x1
    adc8:      	stlxr	w10, x9, [x8]
    adcc:      	cbnz	w10, 0xadc0 <generic_kprobe_output+0x590>
    add0:      	b	0xae10 <generic_kprobe_output+0x5e0>
    add4:      	add	x8, x0, #0x300
    add8:      	b	0xae00 <generic_kprobe_output+0x5d0>
    addc:      	add	x8, x0, #0x308
    ade0:      	b	0xae00 <generic_kprobe_output+0x5d0>
    ade4:      	add	x8, x0, #0x2d8
    ade8:      	b	0xae00 <generic_kprobe_output+0x5d0>
    adec:      	add	x8, x0, #0x2f8
    adf0:      	b	0xae00 <generic_kprobe_output+0x5d0>
    adf4:      	add	x8, x0, #0x2e8
    adf8:      	nop
    adfc:      	nop
    ae00:      	ldaxr	x9, [x8]
    ae04:      	add	x9, x9, #0x1
    ae08:      	stlxr	w10, x9, [x8]
    ae0c:      	cbnz	w10, 0xae00 <generic_kprobe_output+0x5d0>
    ae10:      	ldp	x20, x19, [sp, #0xb0]
    ae14:      	mov	w0, wzr
    ae18:      	ldr	x29, [sp, #0x70]
    ae1c:      	ldp	x22, x21, [sp, #0xa0]
    ae20:      	ldp	x24, x23, [sp, #0x90]
    ae24:      	ldp	x30, x25, [sp, #0x80]
    ae28:      	add	sp, sp, #0xc0
    ae2c:      	ret

000000000000ae30 <generic_kprobe_path>:
    ae30:      	sub	sp, sp, #0xe0
    ae34:      	str	x29, [sp, #0x90]
    ae38:      	stp	x30, x25, [sp, #0xa0]
    ae3c:      	stp	x24, x23, [sp, #0xb0]
    ae40:      	stp	x22, x21, [sp, #0xc0]
    ae44:      	stp	x20, x19, [sp, #0xd0]
    ae48:      	mov	x19, x0
    ae4c:      	str	wzr, [sp, #0x28]
    ae50:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    ae54:      	mov	w8, #0x1                // =1
    ae58:      	ldr	x0, [x0]
    ae5c:      	add	x9, sp, #0x28
    ae60:      	add	x1, sp, #0x28
    ae64:      	blr	x8
    ae68:      	cbz	x0, 0x16ccc <generic_kprobe_path+0xbe9c>
    ae6c:      	mov	w8, #0x6420             // =25632
    ae70:      	add	x25, x0, x8
    ae74:      	ldr	w8, [x25]
    ae78:      	cmp	w8, #0x1
    ae7c:      	b.eq	0xaf28 <generic_kprobe_path+0xf8>
    ae80:      	cbnz	w8, 0x16ccc <generic_kprobe_path+0xbe9c>
    ae84:      	mov	x20, x0
    ae88:      	ldr	x22, [x0, #0x6440]
    ae8c:      	str	wzr, [sp, #0x70]
    ae90:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    ae94:      	mov	w8, #0x1                // =1
    ae98:      	add	x9, sp, #0x70
    ae9c:      	ldr	x0, [x0]
    aea0:      	add	x1, sp, #0x70
    aea4:      	blr	x8
    aea8:      	cbz	x0, 0x16ccc <generic_kprobe_path+0xbe9c>
    aeac:      	str	x19, [sp, #0x20]
    aeb0:      	add	x2, x22, #0x8
    aeb4:      	mov	w8, #0x8                // =8
    aeb8:      	mov	w9, #0x4                // =4
    aebc:      	add	x10, sp, #0x80
    aec0:      	mov	x21, x0
    aec4:      	add	x29, x0, #0xfff
    aec8:      	add	x0, sp, #0x80
    aecc:      	mov	w1, #0x8                // =8
    aed0:      	blr	x9
    aed4:      	adrp	x22, 0xa000 <generic_kprobe_actions+0x620>
    aed8:      	ldr	x22, [x22]
    aedc:      	cbz	x0, 0x16958 <generic_kprobe_path+0xbb28>
    aee0:      	neg	w8, w0
    aee4:      	mov	w9, #0x1                // =1
    aee8:      	add	x1, sp, #0x30
    aeec:      	strh	w8, [sp, #0x30]
    aef0:      	mov	w8, #0x6                // =6
    aef4:      	mov	x0, x22
    aef8:      	mov	w23, #0x1               // =1
    aefc:      	strh	w8, [sp, #0x32]
    af00:      	mov	x8, #0x2c               // =44
    af04:      	movk	x8, #0x4, lsl #32
    af08:      	stur	x8, [sp, #0x34]
    af0c:      	add	x8, sp, #0x30
    af10:      	blr	x9
    af14:      	cbz	x0, 0x16934 <generic_kprobe_path+0xbb04>
    af18:      	ldr	w8, [x0]
    af1c:      	add	w8, w8, #0x1
    af20:      	str	w8, [x0]
    af24:      	b	0x16958 <generic_kprobe_path+0xbb28>
    af28:      	ldr	x8, [x0, #0x6448]
    af2c:      	ldr	x9, [x0, #0x6450]
    af30:      	mov	x20, x0
    af34:      	add	x1, sp, #0x2c
    af38:      	str	xzr, [sp, #0x60]
    af3c:      	str	wzr, [sp, #0x68]
    af40:      	strb	wzr, [sp, #0x6c]
    af44:      	str	wzr, [sp, #0x2c]
    af48:      	stp	x8, x9, [sp, #0x30]
    af4c:      	ldr	x8, [x0, #0x6458]
    af50:      	ldr	x9, [x0, #0x6468]
    af54:      	stp	xzr, x8, [sp, #0x40]
    af58:      	ldr	x8, [x0, #0x6460]
    af5c:      	adrp	x0, 0xa000 <generic_kprobe_actions+0x620>
    af60:      	stp	x8, x9, [sp, #0x50]
    af64:      	mov	w8, #0x1                // =1
    af68:      	add	x9, sp, #0x2c
    af6c:      	ldr	x0, [x0]
    af70:      	blr	x8
    af74:      	cbz	x0, 0x16ccc <generic_kprobe_path+0xbe9c>
    af78:      	str	x0, [sp, #0x40]
    af7c:      	add	x10, sp, #0x30
    af80:      	stp	x20, x19, [sp, #0x18]
    af84:      	mov	w20, #0x200             // =512
    af88:      	mov	w29, #0x8               // =8
    af8c:      	ldr	w8, [x25, #0x4]
    af90:      	add	x22, x10, #0x18
    af94:      	add	x19, sp, #0x70
    af98:      	and	x9, x8, #0xfff
    af9c:      	str	x0, [sp, #0x10]
    afa0:      	str	w8, [sp, #0x68]
    afa4:      	add	x9, x0, x9
    afa8:      	str	x9, [sp, #0x60]
    afac:      	ldp	x21, x2, [sp, #0x48]
    afb0:      	ldp	x8, x9, [sp, #0x30]
    afb4:      	cmp	x21, x8
    afb8:      	ccmp	x2, x9, #0x0, eq
    afbc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    afc0:      	ldr	x24, [sp, #0x58]
    afc4:      	mov	w8, #0x4                // =4
    afc8:      	add	x0, sp, #0x70
    afcc:      	mov	w1, #0x8                // =8
    afd0:      	blr	x8
    afd4:      	ldr	x8, [sp, #0x70]
    afd8:      	cmp	x21, x8
    afdc:      	b.eq	0xb0d8 <generic_kprobe_path+0x2a8>
    afe0:      	add	x23, x21, #0x18
    afe4:      	mov	w8, #0x4                // =4
    afe8:      	add	x9, sp, #0x98
    afec:      	add	x0, sp, #0x98
    aff0:      	mov	w1, #0x8                // =8
    aff4:      	mov	x2, x23
    aff8:      	blr	x8
    affc:      	ldr	x8, [sp, #0x98]
    b000:      	cmp	x8, x21
    b004:      	b.eq	0xb0d8 <generic_kprobe_path+0x2a8>
    b008:      	mov	w8, #0x4                // =4
    b00c:      	add	x9, sp, #0x78
    b010:      	add	x0, sp, #0x78
    b014:      	mov	w1, #0x8                // =8
    b018:      	mov	x2, x23
    b01c:      	blr	x8
    b020:      	add	x2, x21, #0x20
    b024:      	mov	w8, #0x4                // =4
    b028:      	mov	w9, #0x10               // =16
    b02c:      	add	x10, sp, #0x80
    b030:      	add	x0, sp, #0x80
    b034:      	mov	w1, #0x10               // =16
    b038:      	blr	x8
    b03c:      	ldr	w21, [sp, #0x84]
    b040:      	ldr	x8, [sp, #0x40]
    b044:      	ldr	x10, [sp, #0x60]
    b048:      	sub	x12, x10, x8
    b04c:      	ldr	w23, [sp, #0x68]
    b050:      	subs	w10, w21, w23
    b054:      	ldr	x9, [sp, #0x88]
    b058:      	csel	w10, wzr, w10, lo
    b05c:      	cmp	w23, w21
    b060:      	csel	w11, w23, w21, lo
    b064:      	cinc	w13, w11, hi
    b068:      	sub	w14, w23, w13
    b06c:      	subs	x12, x12, x13
    b070:      	str	w14, [sp, #0x68]
    b074:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    b078:      	cmp	x12, #0xfff
    b07c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    b080:      	cmp	w23, w21
    b084:      	b.ls	0xb090 <generic_kprobe_path+0x260>
    b088:      	mov	w13, #0x2f              // =47
    b08c:      	strb	w13, [x8, x12]
    b090:      	add	x19, x8, x12
    b094:      	cmp	w23, w21
    b098:      	add	x2, x9, x10
    b09c:      	and	w1, w11, #0xff
    b0a0:      	mov	w8, #0x4                // =4
    b0a4:      	cinc	x0, x19, hi
    b0a8:      	blr	x8
    b0ac:      	cmp	w23, w21
    b0b0:      	str	x19, [sp, #0x60]
    b0b4:      	add	x19, sp, #0x70
    b0b8:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    b0bc:      	ldr	x21, [sp, #0x78]
    b0c0:      	ldp	x2, x24, [sp, #0x50]
    b0c4:      	str	x21, [sp, #0x48]
    b0c8:      	ldr	x8, [sp, #0x30]
    b0cc:      	cmp	x21, x8
    b0d0:      	b.eq	0xb130 <generic_kprobe_path+0x300>
    b0d4:      	b	0xb13c <generic_kprobe_path+0x30c>
    b0d8:      	add	x2, x24, #0x10
    b0dc:      	mov	w8, #0x4                // =4
    b0e0:      	add	x9, sp, #0x98
    b0e4:      	add	x0, sp, #0x98
    b0e8:      	mov	w1, #0x8                // =8
    b0ec:      	blr	x8
    b0f0:      	ldr	x8, [sp, #0x58]
    b0f4:      	ldr	x9, [sp, #0x98]
    b0f8:      	cmp	x8, x9
    b0fc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    b100:      	add	x2, x24, #0x18
    b104:      	mov	w8, #0x4                // =4
    b108:      	mov	x0, x22
    b10c:      	mov	w1, #0x8                // =8
    b110:      	blr	x8
    b114:      	ldr	x24, [sp, #0x98]
    b118:      	ldr	x21, [sp, #0x48]
    b11c:      	add	x2, x24, #0x20
    b120:      	stp	x2, x24, [sp, #0x50]
    b124:      	ldr	x8, [sp, #0x30]
    b128:      	cmp	x21, x8
    b12c:      	b.ne	0xb13c <generic_kprobe_path+0x30c>
    b130:      	ldr	x8, [sp, #0x38]
    b134:      	cmp	x2, x8
    b138:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    b13c:      	mov	w8, #0x4                // =4
    b140:      	add	x0, sp, #0x70
    b144:      	mov	w1, #0x8                // =8
    b148:      	blr	x8
    b14c:      	ldr	x8, [sp, #0x70]
    b150:      	cmp	x21, x8
    b154:      	b.eq	0xb250 <generic_kprobe_path+0x420>
    b158:      	add	x23, x21, #0x18
    b15c:      	mov	w8, #0x4                // =4
    b160:      	add	x9, sp, #0x98
    b164:      	add	x0, sp, #0x98
    b168:      	mov	w1, #0x8                // =8
    b16c:      	mov	x2, x23
    b170:      	blr	x8
    b174:      	ldr	x8, [sp, #0x98]
    b178:      	cmp	x8, x21
    b17c:      	b.eq	0xb250 <generic_kprobe_path+0x420>
    b180:      	mov	w8, #0x4                // =4
    b184:      	add	x9, sp, #0x78
    b188:      	add	x0, sp, #0x78
    b18c:      	mov	w1, #0x8                // =8
    b190:      	mov	x2, x23
    b194:      	blr	x8
    b198:      	add	x2, x21, #0x20
    b19c:      	mov	w8, #0x4                // =4
    b1a0:      	mov	w9, #0x10               // =16
    b1a4:      	add	x10, sp, #0x80
    b1a8:      	add	x0, sp, #0x80
    b1ac:      	mov	w1, #0x10               // =16
    b1b0:      	blr	x8
    b1b4:      	ldr	w21, [sp, #0x84]
    b1b8:      	ldr	x8, [sp, #0x40]
    b1bc:      	ldr	x10, [sp, #0x60]
    b1c0:      	sub	x12, x10, x8
    b1c4:      	ldr	w23, [sp, #0x68]
    b1c8:      	subs	w10, w21, w23
    b1cc:      	ldr	x9, [sp, #0x88]
    b1d0:      	csel	w10, wzr, w10, lo
    b1d4:      	cmp	w23, w21
    b1d8:      	csel	w11, w23, w21, lo
    b1dc:      	cinc	w13, w11, hi
    b1e0:      	sub	w14, w23, w13
    b1e4:      	subs	x12, x12, x13
    b1e8:      	str	w14, [sp, #0x68]
    b1ec:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    b1f0:      	cmp	x12, #0xfff
    b1f4:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    b1f8:      	cmp	w23, w21
    b1fc:      	b.ls	0xb208 <generic_kprobe_path+0x3d8>
    b200:      	mov	w13, #0x2f              // =47
    b204:      	strb	w13, [x8, x12]
    b208:      	add	x19, x8, x12
    b20c:      	cmp	w23, w21
    b210:      	add	x2, x9, x10
    b214:      	and	w1, w11, #0xff
    b218:      	mov	w8, #0x4                // =4
    b21c:      	cinc	x0, x19, hi
    b220:      	blr	x8
    b224:      	cmp	w23, w21
    b228:      	str	x19, [sp, #0x60]
    b22c:      	add	x19, sp, #0x70
    b230:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    b234:      	ldr	x21, [sp, #0x78]
    b238:      	ldp	x2, x24, [sp, #0x50]
    b23c:      	str	x21, [sp, #0x48]
    b240:      	ldr	x8, [sp, #0x30]
    b244:      	cmp	x21, x8
    b248:      	b.eq	0xb2a8 <generic_kprobe_path+0x478>
    b24c:      	b	0xb2b4 <generic_kprobe_path+0x484>
    b250:      	add	x2, x24, #0x10
    b254:      	mov	w8, #0x4                // =4
    b258:      	add	x9, sp, #0x98
    b25c:      	add	x0, sp, #0x98
    b260:      	mov	w1, #0x8                // =8
    b264:      	blr	x8
    b268:      	ldr	x8, [sp, #0x58]
    b26c:      	ldr	x9, [sp, #0x98]
    b270:      	cmp	x8, x9
    b274:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    b278:      	add	x2, x24, #0x18
    b27c:      	mov	w8, #0x4                // =4
    b280:      	mov	x0, x22
    b284:      	mov	w1, #0x8                // =8
    b288:      	blr	x8
    b28c:      	ldr	x24, [sp, #0x98]
    b290:      	ldr	x21, [sp, #0x48]
    b294:      	add	x2, x24, #0x20
    b298:      	stp	x2, x24, [sp, #0x50]
    b29c:      	ldr	x8, [sp, #0x30]
    b2a0:      	cmp	x21, x8
    b2a4:      	b.ne	0xb2b4 <generic_kprobe_path+0x484>
    b2a8:      	ldr	x8, [sp, #0x38]
    b2ac:      	cmp	x2, x8
    b2b0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    b2b4:      	mov	w8, #0x4                // =4
    b2b8:      	add	x0, sp, #0x70
    b2bc:      	mov	w1, #0x8                // =8
    b2c0:      	blr	x8
    b2c4:      	ldr	x8, [sp, #0x70]
    b2c8:      	cmp	x21, x8
    b2cc:      	b.eq	0xb3c8 <generic_kprobe_path+0x598>
    b2d0:      	add	x23, x21, #0x18
    b2d4:      	mov	w8, #0x4                // =4
    b2d8:      	add	x9, sp, #0x98
    b2dc:      	add	x0, sp, #0x98
    b2e0:      	mov	w1, #0x8                // =8
    b2e4:      	mov	x2, x23
    b2e8:      	blr	x8
    b2ec:      	ldr	x8, [sp, #0x98]
    b2f0:      	cmp	x8, x21
    b2f4:      	b.eq	0xb3c8 <generic_kprobe_path+0x598>
    b2f8:      	mov	w8, #0x4                // =4
    b2fc:      	add	x9, sp, #0x78
    b300:      	add	x0, sp, #0x78
    b304:      	mov	w1, #0x8                // =8
    b308:      	mov	x2, x23
    b30c:      	blr	x8
    b310:      	add	x2, x21, #0x20
    b314:      	mov	w8, #0x4                // =4
    b318:      	mov	w9, #0x10               // =16
    b31c:      	add	x10, sp, #0x80
    b320:      	add	x0, sp, #0x80
    b324:      	mov	w1, #0x10               // =16
    b328:      	blr	x8
    b32c:      	ldr	w21, [sp, #0x84]
    b330:      	ldr	x8, [sp, #0x40]
    b334:      	ldr	x10, [sp, #0x60]
    b338:      	sub	x12, x10, x8
    b33c:      	ldr	w23, [sp, #0x68]
    b340:      	subs	w10, w21, w23
    b344:      	ldr	x9, [sp, #0x88]
    b348:      	csel	w10, wzr, w10, lo
    b34c:      	cmp	w23, w21
    b350:      	csel	w11, w23, w21, lo
    b354:      	cinc	w13, w11, hi
    b358:      	sub	w14, w23, w13
    b35c:      	subs	x12, x12, x13
    b360:      	str	w14, [sp, #0x68]
    b364:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    b368:      	cmp	x12, #0xfff
    b36c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    b370:      	cmp	w23, w21
    b374:      	b.ls	0xb380 <generic_kprobe_path+0x550>
    b378:      	mov	w13, #0x2f              // =47
    b37c:      	strb	w13, [x8, x12]
    b380:      	add	x19, x8, x12
    b384:      	cmp	w23, w21
    b388:      	add	x2, x9, x10
    b38c:      	and	w1, w11, #0xff
    b390:      	mov	w8, #0x4                // =4
    b394:      	cinc	x0, x19, hi
    b398:      	blr	x8
    b39c:      	cmp	w23, w21
    b3a0:      	str	x19, [sp, #0x60]
    b3a4:      	add	x19, sp, #0x70
    b3a8:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    b3ac:      	ldr	x21, [sp, #0x78]
    b3b0:      	ldp	x2, x24, [sp, #0x50]
    b3b4:      	str	x21, [sp, #0x48]
    b3b8:      	ldr	x8, [sp, #0x30]
    b3bc:      	cmp	x21, x8
    b3c0:      	b.eq	0xb420 <generic_kprobe_path+0x5f0>
    b3c4:      	b	0xb42c <generic_kprobe_path+0x5fc>
    b3c8:      	add	x2, x24, #0x10
    b3cc:      	mov	w8, #0x4                // =4
    b3d0:      	add	x9, sp, #0x98
    b3d4:      	add	x0, sp, #0x98
    b3d8:      	mov	w1, #0x8                // =8
    b3dc:      	blr	x8
    b3e0:      	ldr	x8, [sp, #0x58]
    b3e4:      	ldr	x9, [sp, #0x98]
    b3e8:      	cmp	x8, x9
    b3ec:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    b3f0:      	add	x2, x24, #0x18
    b3f4:      	mov	w8, #0x4                // =4
    b3f8:      	mov	x0, x22
    b3fc:      	mov	w1, #0x8                // =8
    b400:      	blr	x8
    b404:      	ldr	x24, [sp, #0x98]
    b408:      	ldr	x21, [sp, #0x48]
    b40c:      	add	x2, x24, #0x20
    b410:      	stp	x2, x24, [sp, #0x50]
    b414:      	ldr	x8, [sp, #0x30]
    b418:      	cmp	x21, x8
    b41c:      	b.ne	0xb42c <generic_kprobe_path+0x5fc>
    b420:      	ldr	x8, [sp, #0x38]
    b424:      	cmp	x2, x8
    b428:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    b42c:      	mov	w8, #0x4                // =4
    b430:      	add	x0, sp, #0x70
    b434:      	mov	w1, #0x8                // =8
    b438:      	blr	x8
    b43c:      	ldr	x8, [sp, #0x70]
    b440:      	cmp	x21, x8
    b444:      	b.eq	0xb540 <generic_kprobe_path+0x710>
    b448:      	add	x23, x21, #0x18
    b44c:      	mov	w8, #0x4                // =4
    b450:      	add	x9, sp, #0x98
    b454:      	add	x0, sp, #0x98
    b458:      	mov	w1, #0x8                // =8
    b45c:      	mov	x2, x23
    b460:      	blr	x8
    b464:      	ldr	x8, [sp, #0x98]
    b468:      	cmp	x8, x21
    b46c:      	b.eq	0xb540 <generic_kprobe_path+0x710>
    b470:      	mov	w8, #0x4                // =4
    b474:      	add	x9, sp, #0x78
    b478:      	add	x0, sp, #0x78
    b47c:      	mov	w1, #0x8                // =8
    b480:      	mov	x2, x23
    b484:      	blr	x8
    b488:      	add	x2, x21, #0x20
    b48c:      	mov	w8, #0x4                // =4
    b490:      	mov	w9, #0x10               // =16
    b494:      	add	x10, sp, #0x80
    b498:      	add	x0, sp, #0x80
    b49c:      	mov	w1, #0x10               // =16
    b4a0:      	blr	x8
    b4a4:      	ldr	w21, [sp, #0x84]
    b4a8:      	ldr	x8, [sp, #0x40]
    b4ac:      	ldr	x10, [sp, #0x60]
    b4b0:      	sub	x12, x10, x8
    b4b4:      	ldr	w23, [sp, #0x68]
    b4b8:      	subs	w10, w21, w23
    b4bc:      	ldr	x9, [sp, #0x88]
    b4c0:      	csel	w10, wzr, w10, lo
    b4c4:      	cmp	w23, w21
    b4c8:      	csel	w11, w23, w21, lo
    b4cc:      	cinc	w13, w11, hi
    b4d0:      	sub	w14, w23, w13
    b4d4:      	subs	x12, x12, x13
    b4d8:      	str	w14, [sp, #0x68]
    b4dc:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    b4e0:      	cmp	x12, #0xfff
    b4e4:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    b4e8:      	cmp	w23, w21
    b4ec:      	b.ls	0xb4f8 <generic_kprobe_path+0x6c8>
    b4f0:      	mov	w13, #0x2f              // =47
    b4f4:      	strb	w13, [x8, x12]
    b4f8:      	add	x19, x8, x12
    b4fc:      	cmp	w23, w21
    b500:      	add	x2, x9, x10
    b504:      	and	w1, w11, #0xff
    b508:      	mov	w8, #0x4                // =4
    b50c:      	cinc	x0, x19, hi
    b510:      	blr	x8
    b514:      	cmp	w23, w21
    b518:      	str	x19, [sp, #0x60]
    b51c:      	add	x19, sp, #0x70
    b520:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    b524:      	ldr	x21, [sp, #0x78]
    b528:      	ldp	x2, x24, [sp, #0x50]
    b52c:      	str	x21, [sp, #0x48]
    b530:      	ldr	x8, [sp, #0x30]
    b534:      	cmp	x21, x8
    b538:      	b.eq	0xb598 <generic_kprobe_path+0x768>
    b53c:      	b	0xb5a4 <generic_kprobe_path+0x774>
    b540:      	add	x2, x24, #0x10
    b544:      	mov	w8, #0x4                // =4
    b548:      	add	x9, sp, #0x98
    b54c:      	add	x0, sp, #0x98
    b550:      	mov	w1, #0x8                // =8
    b554:      	blr	x8
    b558:      	ldr	x8, [sp, #0x58]
    b55c:      	ldr	x9, [sp, #0x98]
    b560:      	cmp	x8, x9
    b564:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    b568:      	add	x2, x24, #0x18
    b56c:      	mov	w8, #0x4                // =4
    b570:      	mov	x0, x22
    b574:      	mov	w1, #0x8                // =8
    b578:      	blr	x8
    b57c:      	ldr	x24, [sp, #0x98]
    b580:      	ldr	x21, [sp, #0x48]
    b584:      	add	x2, x24, #0x20
    b588:      	stp	x2, x24, [sp, #0x50]
    b58c:      	ldr	x8, [sp, #0x30]
    b590:      	cmp	x21, x8
    b594:      	b.ne	0xb5a4 <generic_kprobe_path+0x774>
    b598:      	ldr	x8, [sp, #0x38]
    b59c:      	cmp	x2, x8
    b5a0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    b5a4:      	mov	w8, #0x4                // =4
    b5a8:      	add	x0, sp, #0x70
    b5ac:      	mov	w1, #0x8                // =8
    b5b0:      	blr	x8
    b5b4:      	ldr	x8, [sp, #0x70]
    b5b8:      	cmp	x21, x8
    b5bc:      	b.eq	0xb6b8 <generic_kprobe_path+0x888>
    b5c0:      	add	x23, x21, #0x18
    b5c4:      	mov	w8, #0x4                // =4
    b5c8:      	add	x9, sp, #0x98
    b5cc:      	add	x0, sp, #0x98
    b5d0:      	mov	w1, #0x8                // =8
    b5d4:      	mov	x2, x23
    b5d8:      	blr	x8
    b5dc:      	ldr	x8, [sp, #0x98]
    b5e0:      	cmp	x8, x21
    b5e4:      	b.eq	0xb6b8 <generic_kprobe_path+0x888>
    b5e8:      	mov	w8, #0x4                // =4
    b5ec:      	add	x9, sp, #0x78
    b5f0:      	add	x0, sp, #0x78
    b5f4:      	mov	w1, #0x8                // =8
    b5f8:      	mov	x2, x23
    b5fc:      	blr	x8
    b600:      	add	x2, x21, #0x20
    b604:      	mov	w8, #0x4                // =4
    b608:      	mov	w9, #0x10               // =16
    b60c:      	add	x10, sp, #0x80
    b610:      	add	x0, sp, #0x80
    b614:      	mov	w1, #0x10               // =16
    b618:      	blr	x8
    b61c:      	ldr	w21, [sp, #0x84]
    b620:      	ldr	x8, [sp, #0x40]
    b624:      	ldr	x10, [sp, #0x60]
    b628:      	sub	x12, x10, x8
    b62c:      	ldr	w23, [sp, #0x68]
    b630:      	subs	w10, w21, w23
    b634:      	ldr	x9, [sp, #0x88]
    b638:      	csel	w10, wzr, w10, lo
    b63c:      	cmp	w23, w21
    b640:      	csel	w11, w23, w21, lo
    b644:      	cinc	w13, w11, hi
    b648:      	sub	w14, w23, w13
    b64c:      	subs	x12, x12, x13
    b650:      	str	w14, [sp, #0x68]
    b654:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    b658:      	cmp	x12, #0xfff
    b65c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    b660:      	cmp	w23, w21
    b664:      	b.ls	0xb670 <generic_kprobe_path+0x840>
    b668:      	mov	w13, #0x2f              // =47
    b66c:      	strb	w13, [x8, x12]
    b670:      	add	x19, x8, x12
    b674:      	cmp	w23, w21
    b678:      	add	x2, x9, x10
    b67c:      	and	w1, w11, #0xff
    b680:      	mov	w8, #0x4                // =4
    b684:      	cinc	x0, x19, hi
    b688:      	blr	x8
    b68c:      	cmp	w23, w21
    b690:      	str	x19, [sp, #0x60]
    b694:      	add	x19, sp, #0x70
    b698:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    b69c:      	ldr	x21, [sp, #0x78]
    b6a0:      	ldp	x2, x24, [sp, #0x50]
    b6a4:      	str	x21, [sp, #0x48]
    b6a8:      	ldr	x8, [sp, #0x30]
    b6ac:      	cmp	x21, x8
    b6b0:      	b.eq	0xb710 <generic_kprobe_path+0x8e0>
    b6b4:      	b	0xb71c <generic_kprobe_path+0x8ec>
    b6b8:      	add	x2, x24, #0x10
    b6bc:      	mov	w8, #0x4                // =4
    b6c0:      	add	x9, sp, #0x98
    b6c4:      	add	x0, sp, #0x98
    b6c8:      	mov	w1, #0x8                // =8
    b6cc:      	blr	x8
    b6d0:      	ldr	x8, [sp, #0x58]
    b6d4:      	ldr	x9, [sp, #0x98]
    b6d8:      	cmp	x8, x9
    b6dc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    b6e0:      	add	x2, x24, #0x18
    b6e4:      	mov	w8, #0x4                // =4
    b6e8:      	mov	x0, x22
    b6ec:      	mov	w1, #0x8                // =8
    b6f0:      	blr	x8
    b6f4:      	ldr	x24, [sp, #0x98]
    b6f8:      	ldr	x21, [sp, #0x48]
    b6fc:      	add	x2, x24, #0x20
    b700:      	stp	x2, x24, [sp, #0x50]
    b704:      	ldr	x8, [sp, #0x30]
    b708:      	cmp	x21, x8
    b70c:      	b.ne	0xb71c <generic_kprobe_path+0x8ec>
    b710:      	ldr	x8, [sp, #0x38]
    b714:      	cmp	x2, x8
    b718:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    b71c:      	mov	w8, #0x4                // =4
    b720:      	add	x0, sp, #0x70
    b724:      	mov	w1, #0x8                // =8
    b728:      	blr	x8
    b72c:      	ldr	x8, [sp, #0x70]
    b730:      	cmp	x21, x8
    b734:      	b.eq	0xb830 <generic_kprobe_path+0xa00>
    b738:      	add	x23, x21, #0x18
    b73c:      	mov	w8, #0x4                // =4
    b740:      	add	x9, sp, #0x98
    b744:      	add	x0, sp, #0x98
    b748:      	mov	w1, #0x8                // =8
    b74c:      	mov	x2, x23
    b750:      	blr	x8
    b754:      	ldr	x8, [sp, #0x98]
    b758:      	cmp	x8, x21
    b75c:      	b.eq	0xb830 <generic_kprobe_path+0xa00>
    b760:      	mov	w8, #0x4                // =4
    b764:      	add	x9, sp, #0x78
    b768:      	add	x0, sp, #0x78
    b76c:      	mov	w1, #0x8                // =8
    b770:      	mov	x2, x23
    b774:      	blr	x8
    b778:      	add	x2, x21, #0x20
    b77c:      	mov	w8, #0x4                // =4
    b780:      	mov	w9, #0x10               // =16
    b784:      	add	x10, sp, #0x80
    b788:      	add	x0, sp, #0x80
    b78c:      	mov	w1, #0x10               // =16
    b790:      	blr	x8
    b794:      	ldr	w21, [sp, #0x84]
    b798:      	ldr	x8, [sp, #0x40]
    b79c:      	ldr	x10, [sp, #0x60]
    b7a0:      	sub	x12, x10, x8
    b7a4:      	ldr	w23, [sp, #0x68]
    b7a8:      	subs	w10, w21, w23
    b7ac:      	ldr	x9, [sp, #0x88]
    b7b0:      	csel	w10, wzr, w10, lo
    b7b4:      	cmp	w23, w21
    b7b8:      	csel	w11, w23, w21, lo
    b7bc:      	cinc	w13, w11, hi
    b7c0:      	sub	w14, w23, w13
    b7c4:      	subs	x12, x12, x13
    b7c8:      	str	w14, [sp, #0x68]
    b7cc:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    b7d0:      	cmp	x12, #0xfff
    b7d4:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    b7d8:      	cmp	w23, w21
    b7dc:      	b.ls	0xb7e8 <generic_kprobe_path+0x9b8>
    b7e0:      	mov	w13, #0x2f              // =47
    b7e4:      	strb	w13, [x8, x12]
    b7e8:      	add	x19, x8, x12
    b7ec:      	cmp	w23, w21
    b7f0:      	add	x2, x9, x10
    b7f4:      	and	w1, w11, #0xff
    b7f8:      	mov	w8, #0x4                // =4
    b7fc:      	cinc	x0, x19, hi
    b800:      	blr	x8
    b804:      	cmp	w23, w21
    b808:      	str	x19, [sp, #0x60]
    b80c:      	add	x19, sp, #0x70
    b810:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    b814:      	ldr	x21, [sp, #0x78]
    b818:      	ldp	x2, x24, [sp, #0x50]
    b81c:      	str	x21, [sp, #0x48]
    b820:      	ldr	x8, [sp, #0x30]
    b824:      	cmp	x21, x8
    b828:      	b.eq	0xb888 <generic_kprobe_path+0xa58>
    b82c:      	b	0xb894 <generic_kprobe_path+0xa64>
    b830:      	add	x2, x24, #0x10
    b834:      	mov	w8, #0x4                // =4
    b838:      	add	x9, sp, #0x98
    b83c:      	add	x0, sp, #0x98
    b840:      	mov	w1, #0x8                // =8
    b844:      	blr	x8
    b848:      	ldr	x8, [sp, #0x58]
    b84c:      	ldr	x9, [sp, #0x98]
    b850:      	cmp	x8, x9
    b854:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    b858:      	add	x2, x24, #0x18
    b85c:      	mov	w8, #0x4                // =4
    b860:      	mov	x0, x22
    b864:      	mov	w1, #0x8                // =8
    b868:      	blr	x8
    b86c:      	ldr	x24, [sp, #0x98]
    b870:      	ldr	x21, [sp, #0x48]
    b874:      	add	x2, x24, #0x20
    b878:      	stp	x2, x24, [sp, #0x50]
    b87c:      	ldr	x8, [sp, #0x30]
    b880:      	cmp	x21, x8
    b884:      	b.ne	0xb894 <generic_kprobe_path+0xa64>
    b888:      	ldr	x8, [sp, #0x38]
    b88c:      	cmp	x2, x8
    b890:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    b894:      	mov	w8, #0x4                // =4
    b898:      	add	x0, sp, #0x70
    b89c:      	mov	w1, #0x8                // =8
    b8a0:      	blr	x8
    b8a4:      	ldr	x8, [sp, #0x70]
    b8a8:      	cmp	x21, x8
    b8ac:      	b.eq	0xb9a8 <generic_kprobe_path+0xb78>
    b8b0:      	add	x23, x21, #0x18
    b8b4:      	mov	w8, #0x4                // =4
    b8b8:      	add	x9, sp, #0x98
    b8bc:      	add	x0, sp, #0x98
    b8c0:      	mov	w1, #0x8                // =8
    b8c4:      	mov	x2, x23
    b8c8:      	blr	x8
    b8cc:      	ldr	x8, [sp, #0x98]
    b8d0:      	cmp	x8, x21
    b8d4:      	b.eq	0xb9a8 <generic_kprobe_path+0xb78>
    b8d8:      	mov	w8, #0x4                // =4
    b8dc:      	add	x9, sp, #0x78
    b8e0:      	add	x0, sp, #0x78
    b8e4:      	mov	w1, #0x8                // =8
    b8e8:      	mov	x2, x23
    b8ec:      	blr	x8
    b8f0:      	add	x2, x21, #0x20
    b8f4:      	mov	w8, #0x4                // =4
    b8f8:      	mov	w9, #0x10               // =16
    b8fc:      	add	x10, sp, #0x80
    b900:      	add	x0, sp, #0x80
    b904:      	mov	w1, #0x10               // =16
    b908:      	blr	x8
    b90c:      	ldr	w21, [sp, #0x84]
    b910:      	ldr	x8, [sp, #0x40]
    b914:      	ldr	x10, [sp, #0x60]
    b918:      	sub	x12, x10, x8
    b91c:      	ldr	w23, [sp, #0x68]
    b920:      	subs	w10, w21, w23
    b924:      	ldr	x9, [sp, #0x88]
    b928:      	csel	w10, wzr, w10, lo
    b92c:      	cmp	w23, w21
    b930:      	csel	w11, w23, w21, lo
    b934:      	cinc	w13, w11, hi
    b938:      	sub	w14, w23, w13
    b93c:      	subs	x12, x12, x13
    b940:      	str	w14, [sp, #0x68]
    b944:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    b948:      	cmp	x12, #0xfff
    b94c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    b950:      	cmp	w23, w21
    b954:      	b.ls	0xb960 <generic_kprobe_path+0xb30>
    b958:      	mov	w13, #0x2f              // =47
    b95c:      	strb	w13, [x8, x12]
    b960:      	add	x19, x8, x12
    b964:      	cmp	w23, w21
    b968:      	add	x2, x9, x10
    b96c:      	and	w1, w11, #0xff
    b970:      	mov	w8, #0x4                // =4
    b974:      	cinc	x0, x19, hi
    b978:      	blr	x8
    b97c:      	cmp	w23, w21
    b980:      	str	x19, [sp, #0x60]
    b984:      	add	x19, sp, #0x70
    b988:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    b98c:      	ldr	x21, [sp, #0x78]
    b990:      	ldp	x2, x24, [sp, #0x50]
    b994:      	str	x21, [sp, #0x48]
    b998:      	ldr	x8, [sp, #0x30]
    b99c:      	cmp	x21, x8
    b9a0:      	b.eq	0xba00 <generic_kprobe_path+0xbd0>
    b9a4:      	b	0xba0c <generic_kprobe_path+0xbdc>
    b9a8:      	add	x2, x24, #0x10
    b9ac:      	mov	w8, #0x4                // =4
    b9b0:      	add	x9, sp, #0x98
    b9b4:      	add	x0, sp, #0x98
    b9b8:      	mov	w1, #0x8                // =8
    b9bc:      	blr	x8
    b9c0:      	ldr	x8, [sp, #0x58]
    b9c4:      	ldr	x9, [sp, #0x98]
    b9c8:      	cmp	x8, x9
    b9cc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    b9d0:      	add	x2, x24, #0x18
    b9d4:      	mov	w8, #0x4                // =4
    b9d8:      	mov	x0, x22
    b9dc:      	mov	w1, #0x8                // =8
    b9e0:      	blr	x8
    b9e4:      	ldr	x24, [sp, #0x98]
    b9e8:      	ldr	x21, [sp, #0x48]
    b9ec:      	add	x2, x24, #0x20
    b9f0:      	stp	x2, x24, [sp, #0x50]
    b9f4:      	ldr	x8, [sp, #0x30]
    b9f8:      	cmp	x21, x8
    b9fc:      	b.ne	0xba0c <generic_kprobe_path+0xbdc>
    ba00:      	ldr	x8, [sp, #0x38]
    ba04:      	cmp	x2, x8
    ba08:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    ba0c:      	mov	w8, #0x4                // =4
    ba10:      	add	x0, sp, #0x70
    ba14:      	mov	w1, #0x8                // =8
    ba18:      	blr	x8
    ba1c:      	ldr	x8, [sp, #0x70]
    ba20:      	cmp	x21, x8
    ba24:      	b.eq	0xbb20 <generic_kprobe_path+0xcf0>
    ba28:      	add	x23, x21, #0x18
    ba2c:      	mov	w8, #0x4                // =4
    ba30:      	add	x9, sp, #0x98
    ba34:      	add	x0, sp, #0x98
    ba38:      	mov	w1, #0x8                // =8
    ba3c:      	mov	x2, x23
    ba40:      	blr	x8
    ba44:      	ldr	x8, [sp, #0x98]
    ba48:      	cmp	x8, x21
    ba4c:      	b.eq	0xbb20 <generic_kprobe_path+0xcf0>
    ba50:      	mov	w8, #0x4                // =4
    ba54:      	add	x9, sp, #0x78
    ba58:      	add	x0, sp, #0x78
    ba5c:      	mov	w1, #0x8                // =8
    ba60:      	mov	x2, x23
    ba64:      	blr	x8
    ba68:      	add	x2, x21, #0x20
    ba6c:      	mov	w8, #0x4                // =4
    ba70:      	mov	w9, #0x10               // =16
    ba74:      	add	x10, sp, #0x80
    ba78:      	add	x0, sp, #0x80
    ba7c:      	mov	w1, #0x10               // =16
    ba80:      	blr	x8
    ba84:      	ldr	w21, [sp, #0x84]
    ba88:      	ldr	x8, [sp, #0x40]
    ba8c:      	ldr	x10, [sp, #0x60]
    ba90:      	sub	x12, x10, x8
    ba94:      	ldr	w23, [sp, #0x68]
    ba98:      	subs	w10, w21, w23
    ba9c:      	ldr	x9, [sp, #0x88]
    baa0:      	csel	w10, wzr, w10, lo
    baa4:      	cmp	w23, w21
    baa8:      	csel	w11, w23, w21, lo
    baac:      	cinc	w13, w11, hi
    bab0:      	sub	w14, w23, w13
    bab4:      	subs	x12, x12, x13
    bab8:      	str	w14, [sp, #0x68]
    babc:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    bac0:      	cmp	x12, #0xfff
    bac4:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    bac8:      	cmp	w23, w21
    bacc:      	b.ls	0xbad8 <generic_kprobe_path+0xca8>
    bad0:      	mov	w13, #0x2f              // =47
    bad4:      	strb	w13, [x8, x12]
    bad8:      	add	x19, x8, x12
    badc:      	cmp	w23, w21
    bae0:      	add	x2, x9, x10
    bae4:      	and	w1, w11, #0xff
    bae8:      	mov	w8, #0x4                // =4
    baec:      	cinc	x0, x19, hi
    baf0:      	blr	x8
    baf4:      	cmp	w23, w21
    baf8:      	str	x19, [sp, #0x60]
    bafc:      	add	x19, sp, #0x70
    bb00:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    bb04:      	ldr	x21, [sp, #0x78]
    bb08:      	ldp	x2, x24, [sp, #0x50]
    bb0c:      	str	x21, [sp, #0x48]
    bb10:      	ldr	x8, [sp, #0x30]
    bb14:      	cmp	x21, x8
    bb18:      	b.eq	0xbb78 <generic_kprobe_path+0xd48>
    bb1c:      	b	0xbb84 <generic_kprobe_path+0xd54>
    bb20:      	add	x2, x24, #0x10
    bb24:      	mov	w8, #0x4                // =4
    bb28:      	add	x9, sp, #0x98
    bb2c:      	add	x0, sp, #0x98
    bb30:      	mov	w1, #0x8                // =8
    bb34:      	blr	x8
    bb38:      	ldr	x8, [sp, #0x58]
    bb3c:      	ldr	x9, [sp, #0x98]
    bb40:      	cmp	x8, x9
    bb44:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    bb48:      	add	x2, x24, #0x18
    bb4c:      	mov	w8, #0x4                // =4
    bb50:      	mov	x0, x22
    bb54:      	mov	w1, #0x8                // =8
    bb58:      	blr	x8
    bb5c:      	ldr	x24, [sp, #0x98]
    bb60:      	ldr	x21, [sp, #0x48]
    bb64:      	add	x2, x24, #0x20
    bb68:      	stp	x2, x24, [sp, #0x50]
    bb6c:      	ldr	x8, [sp, #0x30]
    bb70:      	cmp	x21, x8
    bb74:      	b.ne	0xbb84 <generic_kprobe_path+0xd54>
    bb78:      	ldr	x8, [sp, #0x38]
    bb7c:      	cmp	x2, x8
    bb80:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    bb84:      	mov	w8, #0x4                // =4
    bb88:      	add	x0, sp, #0x70
    bb8c:      	mov	w1, #0x8                // =8
    bb90:      	blr	x8
    bb94:      	ldr	x8, [sp, #0x70]
    bb98:      	cmp	x21, x8
    bb9c:      	b.eq	0xbc98 <generic_kprobe_path+0xe68>
    bba0:      	add	x23, x21, #0x18
    bba4:      	mov	w8, #0x4                // =4
    bba8:      	add	x9, sp, #0x98
    bbac:      	add	x0, sp, #0x98
    bbb0:      	mov	w1, #0x8                // =8
    bbb4:      	mov	x2, x23
    bbb8:      	blr	x8
    bbbc:      	ldr	x8, [sp, #0x98]
    bbc0:      	cmp	x8, x21
    bbc4:      	b.eq	0xbc98 <generic_kprobe_path+0xe68>
    bbc8:      	mov	w8, #0x4                // =4
    bbcc:      	add	x9, sp, #0x78
    bbd0:      	add	x0, sp, #0x78
    bbd4:      	mov	w1, #0x8                // =8
    bbd8:      	mov	x2, x23
    bbdc:      	blr	x8
    bbe0:      	add	x2, x21, #0x20
    bbe4:      	mov	w8, #0x4                // =4
    bbe8:      	mov	w9, #0x10               // =16
    bbec:      	add	x10, sp, #0x80
    bbf0:      	add	x0, sp, #0x80
    bbf4:      	mov	w1, #0x10               // =16
    bbf8:      	blr	x8
    bbfc:      	ldr	w21, [sp, #0x84]
    bc00:      	ldr	x8, [sp, #0x40]
    bc04:      	ldr	x10, [sp, #0x60]
    bc08:      	sub	x12, x10, x8
    bc0c:      	ldr	w23, [sp, #0x68]
    bc10:      	subs	w10, w21, w23
    bc14:      	ldr	x9, [sp, #0x88]
    bc18:      	csel	w10, wzr, w10, lo
    bc1c:      	cmp	w23, w21
    bc20:      	csel	w11, w23, w21, lo
    bc24:      	cinc	w13, w11, hi
    bc28:      	sub	w14, w23, w13
    bc2c:      	subs	x12, x12, x13
    bc30:      	str	w14, [sp, #0x68]
    bc34:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    bc38:      	cmp	x12, #0xfff
    bc3c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    bc40:      	cmp	w23, w21
    bc44:      	b.ls	0xbc50 <generic_kprobe_path+0xe20>
    bc48:      	mov	w13, #0x2f              // =47
    bc4c:      	strb	w13, [x8, x12]
    bc50:      	add	x19, x8, x12
    bc54:      	cmp	w23, w21
    bc58:      	add	x2, x9, x10
    bc5c:      	and	w1, w11, #0xff
    bc60:      	mov	w8, #0x4                // =4
    bc64:      	cinc	x0, x19, hi
    bc68:      	blr	x8
    bc6c:      	cmp	w23, w21
    bc70:      	str	x19, [sp, #0x60]
    bc74:      	add	x19, sp, #0x70
    bc78:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    bc7c:      	ldr	x21, [sp, #0x78]
    bc80:      	ldp	x2, x24, [sp, #0x50]
    bc84:      	str	x21, [sp, #0x48]
    bc88:      	ldr	x8, [sp, #0x30]
    bc8c:      	cmp	x21, x8
    bc90:      	b.eq	0xbcf0 <generic_kprobe_path+0xec0>
    bc94:      	b	0xbcfc <generic_kprobe_path+0xecc>
    bc98:      	add	x2, x24, #0x10
    bc9c:      	mov	w8, #0x4                // =4
    bca0:      	add	x9, sp, #0x98
    bca4:      	add	x0, sp, #0x98
    bca8:      	mov	w1, #0x8                // =8
    bcac:      	blr	x8
    bcb0:      	ldr	x8, [sp, #0x58]
    bcb4:      	ldr	x9, [sp, #0x98]
    bcb8:      	cmp	x8, x9
    bcbc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    bcc0:      	add	x2, x24, #0x18
    bcc4:      	mov	w8, #0x4                // =4
    bcc8:      	mov	x0, x22
    bccc:      	mov	w1, #0x8                // =8
    bcd0:      	blr	x8
    bcd4:      	ldr	x24, [sp, #0x98]
    bcd8:      	ldr	x21, [sp, #0x48]
    bcdc:      	add	x2, x24, #0x20
    bce0:      	stp	x2, x24, [sp, #0x50]
    bce4:      	ldr	x8, [sp, #0x30]
    bce8:      	cmp	x21, x8
    bcec:      	b.ne	0xbcfc <generic_kprobe_path+0xecc>
    bcf0:      	ldr	x8, [sp, #0x38]
    bcf4:      	cmp	x2, x8
    bcf8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    bcfc:      	mov	w8, #0x4                // =4
    bd00:      	add	x0, sp, #0x70
    bd04:      	mov	w1, #0x8                // =8
    bd08:      	blr	x8
    bd0c:      	ldr	x8, [sp, #0x70]
    bd10:      	cmp	x21, x8
    bd14:      	b.eq	0xbe04 <generic_kprobe_path+0xfd4>
    bd18:      	add	x23, x21, #0x18
    bd1c:      	mov	w8, #0x4                // =4
    bd20:      	add	x9, sp, #0x98
    bd24:      	add	x0, sp, #0x98
    bd28:      	mov	w1, #0x8                // =8
    bd2c:      	mov	x2, x23
    bd30:      	blr	x8
    bd34:      	ldr	x8, [sp, #0x98]
    bd38:      	cmp	x8, x21
    bd3c:      	b.eq	0xbe04 <generic_kprobe_path+0xfd4>
    bd40:      	mov	w8, #0x4                // =4
    bd44:      	add	x9, sp, #0x78
    bd48:      	add	x0, sp, #0x78
    bd4c:      	mov	w1, #0x8                // =8
    bd50:      	mov	x2, x23
    bd54:      	blr	x8
    bd58:      	add	x2, x21, #0x20
    bd5c:      	mov	w8, #0x4                // =4
    bd60:      	mov	w9, #0x10               // =16
    bd64:      	add	x10, sp, #0x80
    bd68:      	add	x0, sp, #0x80
    bd6c:      	mov	w1, #0x10               // =16
    bd70:      	blr	x8
    bd74:      	ldr	w21, [sp, #0x84]
    bd78:      	ldr	x8, [sp, #0x40]
    bd7c:      	ldr	x10, [sp, #0x60]
    bd80:      	sub	x12, x10, x8
    bd84:      	ldr	w23, [sp, #0x68]
    bd88:      	subs	w10, w21, w23
    bd8c:      	ldr	x9, [sp, #0x88]
    bd90:      	csel	w10, wzr, w10, lo
    bd94:      	cmp	w23, w21
    bd98:      	csel	w11, w23, w21, lo
    bd9c:      	cinc	w13, w11, hi
    bda0:      	sub	w14, w23, w13
    bda4:      	subs	x12, x12, x13
    bda8:      	str	w14, [sp, #0x68]
    bdac:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    bdb0:      	cmp	x12, #0xfff
    bdb4:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    bdb8:      	cmp	w23, w21
    bdbc:      	b.ls	0xbdc8 <generic_kprobe_path+0xf98>
    bdc0:      	mov	w13, #0x2f              // =47
    bdc4:      	strb	w13, [x8, x12]
    bdc8:      	add	x19, x8, x12
    bdcc:      	cmp	w23, w21
    bdd0:      	add	x2, x9, x10
    bdd4:      	and	w1, w11, #0xff
    bdd8:      	mov	w8, #0x4                // =4
    bddc:      	cinc	x0, x19, hi
    bde0:      	blr	x8
    bde4:      	cmp	w23, w21
    bde8:      	str	x19, [sp, #0x60]
    bdec:      	add	x19, sp, #0x70
    bdf0:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    bdf4:      	ldr	x21, [sp, #0x78]
    bdf8:      	ldp	x2, x24, [sp, #0x50]
    bdfc:      	str	x21, [sp, #0x48]
    be00:      	b	0xbe50 <generic_kprobe_path+0x1020>
    be04:      	add	x2, x24, #0x10
    be08:      	mov	w8, #0x4                // =4
    be0c:      	add	x9, sp, #0x98
    be10:      	add	x0, sp, #0x98
    be14:      	mov	w1, #0x8                // =8
    be18:      	blr	x8
    be1c:      	ldr	x8, [sp, #0x58]
    be20:      	ldr	x9, [sp, #0x98]
    be24:      	cmp	x8, x9
    be28:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    be2c:      	add	x2, x24, #0x18
    be30:      	mov	w8, #0x4                // =4
    be34:      	mov	x0, x22
    be38:      	mov	w1, #0x8                // =8
    be3c:      	blr	x8
    be40:      	ldr	x24, [sp, #0x98]
    be44:      	ldr	x21, [sp, #0x48]
    be48:      	add	x2, x24, #0x20
    be4c:      	stp	x2, x24, [sp, #0x50]
    be50:      	ldr	x8, [sp, #0x30]
    be54:      	cmp	x21, x8
    be58:      	b.ne	0xbe68 <generic_kprobe_path+0x1038>
    be5c:      	ldr	x8, [sp, #0x38]
    be60:      	cmp	x2, x8
    be64:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    be68:      	mov	w8, #0x4                // =4
    be6c:      	add	x0, sp, #0x70
    be70:      	mov	w1, #0x8                // =8
    be74:      	blr	x8
    be78:      	ldr	x8, [sp, #0x70]
    be7c:      	cmp	x21, x8
    be80:      	b.eq	0xbf70 <generic_kprobe_path+0x1140>
    be84:      	add	x23, x21, #0x18
    be88:      	mov	w8, #0x4                // =4
    be8c:      	add	x9, sp, #0x98
    be90:      	add	x0, sp, #0x98
    be94:      	mov	w1, #0x8                // =8
    be98:      	mov	x2, x23
    be9c:      	blr	x8
    bea0:      	ldr	x8, [sp, #0x98]
    bea4:      	cmp	x8, x21
    bea8:      	b.eq	0xbf70 <generic_kprobe_path+0x1140>
    beac:      	mov	w8, #0x4                // =4
    beb0:      	add	x9, sp, #0x78
    beb4:      	add	x0, sp, #0x78
    beb8:      	mov	w1, #0x8                // =8
    bebc:      	mov	x2, x23
    bec0:      	blr	x8
    bec4:      	add	x2, x21, #0x20
    bec8:      	mov	w8, #0x4                // =4
    becc:      	mov	w9, #0x10               // =16
    bed0:      	add	x10, sp, #0x80
    bed4:      	add	x0, sp, #0x80
    bed8:      	mov	w1, #0x10               // =16
    bedc:      	blr	x8
    bee0:      	ldr	w21, [sp, #0x84]
    bee4:      	ldr	x8, [sp, #0x40]
    bee8:      	ldr	x10, [sp, #0x60]
    beec:      	sub	x12, x10, x8
    bef0:      	ldr	w23, [sp, #0x68]
    bef4:      	subs	w10, w21, w23
    bef8:      	ldr	x9, [sp, #0x88]
    befc:      	csel	w10, wzr, w10, lo
    bf00:      	cmp	w23, w21
    bf04:      	csel	w11, w23, w21, lo
    bf08:      	cinc	w13, w11, hi
    bf0c:      	sub	w14, w23, w13
    bf10:      	subs	x12, x12, x13
    bf14:      	str	w14, [sp, #0x68]
    bf18:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    bf1c:      	cmp	x12, #0xfff
    bf20:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    bf24:      	cmp	w23, w21
    bf28:      	b.ls	0xbf34 <generic_kprobe_path+0x1104>
    bf2c:      	mov	w13, #0x2f              // =47
    bf30:      	strb	w13, [x8, x12]
    bf34:      	add	x19, x8, x12
    bf38:      	cmp	w23, w21
    bf3c:      	add	x2, x9, x10
    bf40:      	and	w1, w11, #0xff
    bf44:      	mov	w8, #0x4                // =4
    bf48:      	cinc	x0, x19, hi
    bf4c:      	blr	x8
    bf50:      	cmp	w23, w21
    bf54:      	str	x19, [sp, #0x60]
    bf58:      	add	x19, sp, #0x70
    bf5c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    bf60:      	ldr	x21, [sp, #0x78]
    bf64:      	ldp	x2, x24, [sp, #0x50]
    bf68:      	str	x21, [sp, #0x48]
    bf6c:      	b	0xbfbc <generic_kprobe_path+0x118c>
    bf70:      	add	x2, x24, #0x10
    bf74:      	mov	w8, #0x4                // =4
    bf78:      	add	x9, sp, #0x98
    bf7c:      	add	x0, sp, #0x98
    bf80:      	mov	w1, #0x8                // =8
    bf84:      	blr	x8
    bf88:      	ldr	x8, [sp, #0x58]
    bf8c:      	ldr	x9, [sp, #0x98]
    bf90:      	cmp	x8, x9
    bf94:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    bf98:      	add	x2, x24, #0x18
    bf9c:      	mov	w8, #0x4                // =4
    bfa0:      	mov	x0, x22
    bfa4:      	mov	w1, #0x8                // =8
    bfa8:      	blr	x8
    bfac:      	ldr	x24, [sp, #0x98]
    bfb0:      	ldr	x21, [sp, #0x48]
    bfb4:      	add	x2, x24, #0x20
    bfb8:      	stp	x2, x24, [sp, #0x50]
    bfbc:      	ldr	x8, [sp, #0x30]
    bfc0:      	cmp	x21, x8
    bfc4:      	b.ne	0xbfd4 <generic_kprobe_path+0x11a4>
    bfc8:      	ldr	x8, [sp, #0x38]
    bfcc:      	cmp	x2, x8
    bfd0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    bfd4:      	mov	w8, #0x4                // =4
    bfd8:      	add	x0, sp, #0x70
    bfdc:      	mov	w1, #0x8                // =8
    bfe0:      	blr	x8
    bfe4:      	ldr	x8, [sp, #0x70]
    bfe8:      	cmp	x21, x8
    bfec:      	b.eq	0xc0dc <generic_kprobe_path+0x12ac>
    bff0:      	add	x23, x21, #0x18
    bff4:      	mov	w8, #0x4                // =4
    bff8:      	add	x9, sp, #0x98
    bffc:      	add	x0, sp, #0x98
    c000:      	mov	w1, #0x8                // =8
    c004:      	mov	x2, x23
    c008:      	blr	x8
    c00c:      	ldr	x8, [sp, #0x98]
    c010:      	cmp	x8, x21
    c014:      	b.eq	0xc0dc <generic_kprobe_path+0x12ac>
    c018:      	mov	w8, #0x4                // =4
    c01c:      	add	x9, sp, #0x78
    c020:      	add	x0, sp, #0x78
    c024:      	mov	w1, #0x8                // =8
    c028:      	mov	x2, x23
    c02c:      	blr	x8
    c030:      	add	x2, x21, #0x20
    c034:      	mov	w8, #0x4                // =4
    c038:      	mov	w9, #0x10               // =16
    c03c:      	add	x10, sp, #0x80
    c040:      	add	x0, sp, #0x80
    c044:      	mov	w1, #0x10               // =16
    c048:      	blr	x8
    c04c:      	ldr	w21, [sp, #0x84]
    c050:      	ldr	x8, [sp, #0x40]
    c054:      	ldr	x10, [sp, #0x60]
    c058:      	sub	x12, x10, x8
    c05c:      	ldr	w23, [sp, #0x68]
    c060:      	subs	w10, w21, w23
    c064:      	ldr	x9, [sp, #0x88]
    c068:      	csel	w10, wzr, w10, lo
    c06c:      	cmp	w23, w21
    c070:      	csel	w11, w23, w21, lo
    c074:      	cinc	w13, w11, hi
    c078:      	sub	w14, w23, w13
    c07c:      	subs	x12, x12, x13
    c080:      	str	w14, [sp, #0x68]
    c084:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    c088:      	cmp	x12, #0xfff
    c08c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    c090:      	cmp	w23, w21
    c094:      	b.ls	0xc0a0 <generic_kprobe_path+0x1270>
    c098:      	mov	w13, #0x2f              // =47
    c09c:      	strb	w13, [x8, x12]
    c0a0:      	add	x19, x8, x12
    c0a4:      	cmp	w23, w21
    c0a8:      	add	x2, x9, x10
    c0ac:      	and	w1, w11, #0xff
    c0b0:      	mov	w8, #0x4                // =4
    c0b4:      	cinc	x0, x19, hi
    c0b8:      	blr	x8
    c0bc:      	cmp	w23, w21
    c0c0:      	str	x19, [sp, #0x60]
    c0c4:      	add	x19, sp, #0x70
    c0c8:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    c0cc:      	ldr	x21, [sp, #0x78]
    c0d0:      	ldp	x2, x24, [sp, #0x50]
    c0d4:      	str	x21, [sp, #0x48]
    c0d8:      	b	0xc128 <generic_kprobe_path+0x12f8>
    c0dc:      	add	x2, x24, #0x10
    c0e0:      	mov	w8, #0x4                // =4
    c0e4:      	add	x9, sp, #0x98
    c0e8:      	add	x0, sp, #0x98
    c0ec:      	mov	w1, #0x8                // =8
    c0f0:      	blr	x8
    c0f4:      	ldr	x8, [sp, #0x58]
    c0f8:      	ldr	x9, [sp, #0x98]
    c0fc:      	cmp	x8, x9
    c100:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    c104:      	add	x2, x24, #0x18
    c108:      	mov	w8, #0x4                // =4
    c10c:      	mov	x0, x22
    c110:      	mov	w1, #0x8                // =8
    c114:      	blr	x8
    c118:      	ldr	x24, [sp, #0x98]
    c11c:      	ldr	x21, [sp, #0x48]
    c120:      	add	x2, x24, #0x20
    c124:      	stp	x2, x24, [sp, #0x50]
    c128:      	ldr	x8, [sp, #0x30]
    c12c:      	cmp	x21, x8
    c130:      	b.ne	0xc140 <generic_kprobe_path+0x1310>
    c134:      	ldr	x8, [sp, #0x38]
    c138:      	cmp	x2, x8
    c13c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    c140:      	mov	w8, #0x4                // =4
    c144:      	add	x0, sp, #0x70
    c148:      	mov	w1, #0x8                // =8
    c14c:      	blr	x8
    c150:      	ldr	x8, [sp, #0x70]
    c154:      	cmp	x21, x8
    c158:      	b.eq	0xc248 <generic_kprobe_path+0x1418>
    c15c:      	add	x23, x21, #0x18
    c160:      	mov	w8, #0x4                // =4
    c164:      	add	x9, sp, #0x98
    c168:      	add	x0, sp, #0x98
    c16c:      	mov	w1, #0x8                // =8
    c170:      	mov	x2, x23
    c174:      	blr	x8
    c178:      	ldr	x8, [sp, #0x98]
    c17c:      	cmp	x8, x21
    c180:      	b.eq	0xc248 <generic_kprobe_path+0x1418>
    c184:      	mov	w8, #0x4                // =4
    c188:      	add	x9, sp, #0x78
    c18c:      	add	x0, sp, #0x78
    c190:      	mov	w1, #0x8                // =8
    c194:      	mov	x2, x23
    c198:      	blr	x8
    c19c:      	add	x2, x21, #0x20
    c1a0:      	mov	w8, #0x4                // =4
    c1a4:      	mov	w9, #0x10               // =16
    c1a8:      	add	x10, sp, #0x80
    c1ac:      	add	x0, sp, #0x80
    c1b0:      	mov	w1, #0x10               // =16
    c1b4:      	blr	x8
    c1b8:      	ldr	w21, [sp, #0x84]
    c1bc:      	ldr	x8, [sp, #0x40]
    c1c0:      	ldr	x10, [sp, #0x60]
    c1c4:      	sub	x12, x10, x8
    c1c8:      	ldr	w23, [sp, #0x68]
    c1cc:      	subs	w10, w21, w23
    c1d0:      	ldr	x9, [sp, #0x88]
    c1d4:      	csel	w10, wzr, w10, lo
    c1d8:      	cmp	w23, w21
    c1dc:      	csel	w11, w23, w21, lo
    c1e0:      	cinc	w13, w11, hi
    c1e4:      	sub	w14, w23, w13
    c1e8:      	subs	x12, x12, x13
    c1ec:      	str	w14, [sp, #0x68]
    c1f0:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    c1f4:      	cmp	x12, #0xfff
    c1f8:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    c1fc:      	cmp	w23, w21
    c200:      	b.ls	0xc20c <generic_kprobe_path+0x13dc>
    c204:      	mov	w13, #0x2f              // =47
    c208:      	strb	w13, [x8, x12]
    c20c:      	add	x19, x8, x12
    c210:      	cmp	w23, w21
    c214:      	add	x2, x9, x10
    c218:      	and	w1, w11, #0xff
    c21c:      	mov	w8, #0x4                // =4
    c220:      	cinc	x0, x19, hi
    c224:      	blr	x8
    c228:      	cmp	w23, w21
    c22c:      	str	x19, [sp, #0x60]
    c230:      	add	x19, sp, #0x70
    c234:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    c238:      	ldr	x21, [sp, #0x78]
    c23c:      	ldp	x2, x24, [sp, #0x50]
    c240:      	str	x21, [sp, #0x48]
    c244:      	b	0xc294 <generic_kprobe_path+0x1464>
    c248:      	add	x2, x24, #0x10
    c24c:      	mov	w8, #0x4                // =4
    c250:      	add	x9, sp, #0x98
    c254:      	add	x0, sp, #0x98
    c258:      	mov	w1, #0x8                // =8
    c25c:      	blr	x8
    c260:      	ldr	x8, [sp, #0x58]
    c264:      	ldr	x9, [sp, #0x98]
    c268:      	cmp	x8, x9
    c26c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    c270:      	add	x2, x24, #0x18
    c274:      	mov	w8, #0x4                // =4
    c278:      	mov	x0, x22
    c27c:      	mov	w1, #0x8                // =8
    c280:      	blr	x8
    c284:      	ldr	x24, [sp, #0x98]
    c288:      	ldr	x21, [sp, #0x48]
    c28c:      	add	x2, x24, #0x20
    c290:      	stp	x2, x24, [sp, #0x50]
    c294:      	ldr	x8, [sp, #0x30]
    c298:      	cmp	x21, x8
    c29c:      	b.ne	0xc2ac <generic_kprobe_path+0x147c>
    c2a0:      	ldr	x8, [sp, #0x38]
    c2a4:      	cmp	x2, x8
    c2a8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    c2ac:      	mov	w8, #0x4                // =4
    c2b0:      	add	x0, sp, #0x70
    c2b4:      	mov	w1, #0x8                // =8
    c2b8:      	blr	x8
    c2bc:      	ldr	x8, [sp, #0x70]
    c2c0:      	cmp	x21, x8
    c2c4:      	b.eq	0xc3b4 <generic_kprobe_path+0x1584>
    c2c8:      	add	x23, x21, #0x18
    c2cc:      	mov	w8, #0x4                // =4
    c2d0:      	add	x9, sp, #0x98
    c2d4:      	add	x0, sp, #0x98
    c2d8:      	mov	w1, #0x8                // =8
    c2dc:      	mov	x2, x23
    c2e0:      	blr	x8
    c2e4:      	ldr	x8, [sp, #0x98]
    c2e8:      	cmp	x8, x21
    c2ec:      	b.eq	0xc3b4 <generic_kprobe_path+0x1584>
    c2f0:      	mov	w8, #0x4                // =4
    c2f4:      	add	x9, sp, #0x78
    c2f8:      	add	x0, sp, #0x78
    c2fc:      	mov	w1, #0x8                // =8
    c300:      	mov	x2, x23
    c304:      	blr	x8
    c308:      	add	x2, x21, #0x20
    c30c:      	mov	w8, #0x4                // =4
    c310:      	mov	w9, #0x10               // =16
    c314:      	add	x10, sp, #0x80
    c318:      	add	x0, sp, #0x80
    c31c:      	mov	w1, #0x10               // =16
    c320:      	blr	x8
    c324:      	ldr	w21, [sp, #0x84]
    c328:      	ldr	x8, [sp, #0x40]
    c32c:      	ldr	x10, [sp, #0x60]
    c330:      	sub	x12, x10, x8
    c334:      	ldr	w23, [sp, #0x68]
    c338:      	subs	w10, w21, w23
    c33c:      	ldr	x9, [sp, #0x88]
    c340:      	csel	w10, wzr, w10, lo
    c344:      	cmp	w23, w21
    c348:      	csel	w11, w23, w21, lo
    c34c:      	cinc	w13, w11, hi
    c350:      	sub	w14, w23, w13
    c354:      	subs	x12, x12, x13
    c358:      	str	w14, [sp, #0x68]
    c35c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    c360:      	cmp	x12, #0xfff
    c364:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    c368:      	cmp	w23, w21
    c36c:      	b.ls	0xc378 <generic_kprobe_path+0x1548>
    c370:      	mov	w13, #0x2f              // =47
    c374:      	strb	w13, [x8, x12]
    c378:      	add	x19, x8, x12
    c37c:      	cmp	w23, w21
    c380:      	add	x2, x9, x10
    c384:      	and	w1, w11, #0xff
    c388:      	mov	w8, #0x4                // =4
    c38c:      	cinc	x0, x19, hi
    c390:      	blr	x8
    c394:      	cmp	w23, w21
    c398:      	str	x19, [sp, #0x60]
    c39c:      	add	x19, sp, #0x70
    c3a0:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    c3a4:      	ldr	x21, [sp, #0x78]
    c3a8:      	ldp	x2, x24, [sp, #0x50]
    c3ac:      	str	x21, [sp, #0x48]
    c3b0:      	b	0xc400 <generic_kprobe_path+0x15d0>
    c3b4:      	add	x2, x24, #0x10
    c3b8:      	mov	w8, #0x4                // =4
    c3bc:      	add	x9, sp, #0x98
    c3c0:      	add	x0, sp, #0x98
    c3c4:      	mov	w1, #0x8                // =8
    c3c8:      	blr	x8
    c3cc:      	ldr	x8, [sp, #0x58]
    c3d0:      	ldr	x9, [sp, #0x98]
    c3d4:      	cmp	x8, x9
    c3d8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    c3dc:      	add	x2, x24, #0x18
    c3e0:      	mov	w8, #0x4                // =4
    c3e4:      	mov	x0, x22
    c3e8:      	mov	w1, #0x8                // =8
    c3ec:      	blr	x8
    c3f0:      	ldr	x24, [sp, #0x98]
    c3f4:      	ldr	x21, [sp, #0x48]
    c3f8:      	add	x2, x24, #0x20
    c3fc:      	stp	x2, x24, [sp, #0x50]
    c400:      	ldr	x8, [sp, #0x30]
    c404:      	cmp	x21, x8
    c408:      	b.ne	0xc418 <generic_kprobe_path+0x15e8>
    c40c:      	ldr	x8, [sp, #0x38]
    c410:      	cmp	x2, x8
    c414:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    c418:      	mov	w8, #0x4                // =4
    c41c:      	add	x0, sp, #0x70
    c420:      	mov	w1, #0x8                // =8
    c424:      	blr	x8
    c428:      	ldr	x8, [sp, #0x70]
    c42c:      	cmp	x21, x8
    c430:      	b.eq	0xc520 <generic_kprobe_path+0x16f0>
    c434:      	add	x23, x21, #0x18
    c438:      	mov	w8, #0x4                // =4
    c43c:      	add	x9, sp, #0x98
    c440:      	add	x0, sp, #0x98
    c444:      	mov	w1, #0x8                // =8
    c448:      	mov	x2, x23
    c44c:      	blr	x8
    c450:      	ldr	x8, [sp, #0x98]
    c454:      	cmp	x8, x21
    c458:      	b.eq	0xc520 <generic_kprobe_path+0x16f0>
    c45c:      	mov	w8, #0x4                // =4
    c460:      	add	x9, sp, #0x78
    c464:      	add	x0, sp, #0x78
    c468:      	mov	w1, #0x8                // =8
    c46c:      	mov	x2, x23
    c470:      	blr	x8
    c474:      	add	x2, x21, #0x20
    c478:      	mov	w8, #0x4                // =4
    c47c:      	mov	w9, #0x10               // =16
    c480:      	add	x10, sp, #0x80
    c484:      	add	x0, sp, #0x80
    c488:      	mov	w1, #0x10               // =16
    c48c:      	blr	x8
    c490:      	ldr	w21, [sp, #0x84]
    c494:      	ldr	x8, [sp, #0x40]
    c498:      	ldr	x10, [sp, #0x60]
    c49c:      	sub	x12, x10, x8
    c4a0:      	ldr	w23, [sp, #0x68]
    c4a4:      	subs	w10, w21, w23
    c4a8:      	ldr	x9, [sp, #0x88]
    c4ac:      	csel	w10, wzr, w10, lo
    c4b0:      	cmp	w23, w21
    c4b4:      	csel	w11, w23, w21, lo
    c4b8:      	cinc	w13, w11, hi
    c4bc:      	sub	w14, w23, w13
    c4c0:      	subs	x12, x12, x13
    c4c4:      	str	w14, [sp, #0x68]
    c4c8:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    c4cc:      	cmp	x12, #0xfff
    c4d0:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    c4d4:      	cmp	w23, w21
    c4d8:      	b.ls	0xc4e4 <generic_kprobe_path+0x16b4>
    c4dc:      	mov	w13, #0x2f              // =47
    c4e0:      	strb	w13, [x8, x12]
    c4e4:      	add	x19, x8, x12
    c4e8:      	cmp	w23, w21
    c4ec:      	add	x2, x9, x10
    c4f0:      	and	w1, w11, #0xff
    c4f4:      	mov	w8, #0x4                // =4
    c4f8:      	cinc	x0, x19, hi
    c4fc:      	blr	x8
    c500:      	cmp	w23, w21
    c504:      	str	x19, [sp, #0x60]
    c508:      	add	x19, sp, #0x70
    c50c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    c510:      	ldr	x21, [sp, #0x78]
    c514:      	ldp	x2, x24, [sp, #0x50]
    c518:      	str	x21, [sp, #0x48]
    c51c:      	b	0xc56c <generic_kprobe_path+0x173c>
    c520:      	add	x2, x24, #0x10
    c524:      	mov	w8, #0x4                // =4
    c528:      	add	x9, sp, #0x98
    c52c:      	add	x0, sp, #0x98
    c530:      	mov	w1, #0x8                // =8
    c534:      	blr	x8
    c538:      	ldr	x8, [sp, #0x58]
    c53c:      	ldr	x9, [sp, #0x98]
    c540:      	cmp	x8, x9
    c544:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    c548:      	add	x2, x24, #0x18
    c54c:      	mov	w8, #0x4                // =4
    c550:      	mov	x0, x22
    c554:      	mov	w1, #0x8                // =8
    c558:      	blr	x8
    c55c:      	ldr	x24, [sp, #0x98]
    c560:      	ldr	x21, [sp, #0x48]
    c564:      	add	x2, x24, #0x20
    c568:      	stp	x2, x24, [sp, #0x50]
    c56c:      	ldr	x8, [sp, #0x30]
    c570:      	cmp	x21, x8
    c574:      	b.ne	0xc584 <generic_kprobe_path+0x1754>
    c578:      	ldr	x8, [sp, #0x38]
    c57c:      	cmp	x2, x8
    c580:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    c584:      	mov	w8, #0x4                // =4
    c588:      	add	x0, sp, #0x70
    c58c:      	mov	w1, #0x8                // =8
    c590:      	blr	x8
    c594:      	ldr	x8, [sp, #0x70]
    c598:      	cmp	x21, x8
    c59c:      	b.eq	0xc68c <generic_kprobe_path+0x185c>
    c5a0:      	add	x23, x21, #0x18
    c5a4:      	mov	w8, #0x4                // =4
    c5a8:      	add	x9, sp, #0x98
    c5ac:      	add	x0, sp, #0x98
    c5b0:      	mov	w1, #0x8                // =8
    c5b4:      	mov	x2, x23
    c5b8:      	blr	x8
    c5bc:      	ldr	x8, [sp, #0x98]
    c5c0:      	cmp	x8, x21
    c5c4:      	b.eq	0xc68c <generic_kprobe_path+0x185c>
    c5c8:      	mov	w8, #0x4                // =4
    c5cc:      	add	x9, sp, #0x78
    c5d0:      	add	x0, sp, #0x78
    c5d4:      	mov	w1, #0x8                // =8
    c5d8:      	mov	x2, x23
    c5dc:      	blr	x8
    c5e0:      	add	x2, x21, #0x20
    c5e4:      	mov	w8, #0x4                // =4
    c5e8:      	mov	w9, #0x10               // =16
    c5ec:      	add	x10, sp, #0x80
    c5f0:      	add	x0, sp, #0x80
    c5f4:      	mov	w1, #0x10               // =16
    c5f8:      	blr	x8
    c5fc:      	ldr	w21, [sp, #0x84]
    c600:      	ldr	x8, [sp, #0x40]
    c604:      	ldr	x10, [sp, #0x60]
    c608:      	sub	x12, x10, x8
    c60c:      	ldr	w23, [sp, #0x68]
    c610:      	subs	w10, w21, w23
    c614:      	ldr	x9, [sp, #0x88]
    c618:      	csel	w10, wzr, w10, lo
    c61c:      	cmp	w23, w21
    c620:      	csel	w11, w23, w21, lo
    c624:      	cinc	w13, w11, hi
    c628:      	sub	w14, w23, w13
    c62c:      	subs	x12, x12, x13
    c630:      	str	w14, [sp, #0x68]
    c634:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    c638:      	cmp	x12, #0xfff
    c63c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    c640:      	cmp	w23, w21
    c644:      	b.ls	0xc650 <generic_kprobe_path+0x1820>
    c648:      	mov	w13, #0x2f              // =47
    c64c:      	strb	w13, [x8, x12]
    c650:      	add	x19, x8, x12
    c654:      	cmp	w23, w21
    c658:      	add	x2, x9, x10
    c65c:      	and	w1, w11, #0xff
    c660:      	mov	w8, #0x4                // =4
    c664:      	cinc	x0, x19, hi
    c668:      	blr	x8
    c66c:      	cmp	w23, w21
    c670:      	str	x19, [sp, #0x60]
    c674:      	add	x19, sp, #0x70
    c678:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    c67c:      	ldr	x21, [sp, #0x78]
    c680:      	ldp	x2, x24, [sp, #0x50]
    c684:      	str	x21, [sp, #0x48]
    c688:      	b	0xc6d8 <generic_kprobe_path+0x18a8>
    c68c:      	add	x2, x24, #0x10
    c690:      	mov	w8, #0x4                // =4
    c694:      	add	x9, sp, #0x98
    c698:      	add	x0, sp, #0x98
    c69c:      	mov	w1, #0x8                // =8
    c6a0:      	blr	x8
    c6a4:      	ldr	x8, [sp, #0x58]
    c6a8:      	ldr	x9, [sp, #0x98]
    c6ac:      	cmp	x8, x9
    c6b0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    c6b4:      	add	x2, x24, #0x18
    c6b8:      	mov	w8, #0x4                // =4
    c6bc:      	mov	x0, x22
    c6c0:      	mov	w1, #0x8                // =8
    c6c4:      	blr	x8
    c6c8:      	ldr	x24, [sp, #0x98]
    c6cc:      	ldr	x21, [sp, #0x48]
    c6d0:      	add	x2, x24, #0x20
    c6d4:      	stp	x2, x24, [sp, #0x50]
    c6d8:      	ldr	x8, [sp, #0x30]
    c6dc:      	cmp	x21, x8
    c6e0:      	b.ne	0xc6f0 <generic_kprobe_path+0x18c0>
    c6e4:      	ldr	x8, [sp, #0x38]
    c6e8:      	cmp	x2, x8
    c6ec:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    c6f0:      	mov	w8, #0x4                // =4
    c6f4:      	add	x0, sp, #0x70
    c6f8:      	mov	w1, #0x8                // =8
    c6fc:      	blr	x8
    c700:      	ldr	x8, [sp, #0x70]
    c704:      	cmp	x21, x8
    c708:      	b.eq	0xc7f8 <generic_kprobe_path+0x19c8>
    c70c:      	add	x23, x21, #0x18
    c710:      	mov	w8, #0x4                // =4
    c714:      	add	x9, sp, #0x98
    c718:      	add	x0, sp, #0x98
    c71c:      	mov	w1, #0x8                // =8
    c720:      	mov	x2, x23
    c724:      	blr	x8
    c728:      	ldr	x8, [sp, #0x98]
    c72c:      	cmp	x8, x21
    c730:      	b.eq	0xc7f8 <generic_kprobe_path+0x19c8>
    c734:      	mov	w8, #0x4                // =4
    c738:      	add	x9, sp, #0x78
    c73c:      	add	x0, sp, #0x78
    c740:      	mov	w1, #0x8                // =8
    c744:      	mov	x2, x23
    c748:      	blr	x8
    c74c:      	add	x2, x21, #0x20
    c750:      	mov	w8, #0x4                // =4
    c754:      	mov	w9, #0x10               // =16
    c758:      	add	x10, sp, #0x80
    c75c:      	add	x0, sp, #0x80
    c760:      	mov	w1, #0x10               // =16
    c764:      	blr	x8
    c768:      	ldr	w21, [sp, #0x84]
    c76c:      	ldr	x8, [sp, #0x40]
    c770:      	ldr	x10, [sp, #0x60]
    c774:      	sub	x12, x10, x8
    c778:      	ldr	w23, [sp, #0x68]
    c77c:      	subs	w10, w21, w23
    c780:      	ldr	x9, [sp, #0x88]
    c784:      	csel	w10, wzr, w10, lo
    c788:      	cmp	w23, w21
    c78c:      	csel	w11, w23, w21, lo
    c790:      	cinc	w13, w11, hi
    c794:      	sub	w14, w23, w13
    c798:      	subs	x12, x12, x13
    c79c:      	str	w14, [sp, #0x68]
    c7a0:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    c7a4:      	cmp	x12, #0xfff
    c7a8:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    c7ac:      	cmp	w23, w21
    c7b0:      	b.ls	0xc7bc <generic_kprobe_path+0x198c>
    c7b4:      	mov	w13, #0x2f              // =47
    c7b8:      	strb	w13, [x8, x12]
    c7bc:      	add	x19, x8, x12
    c7c0:      	cmp	w23, w21
    c7c4:      	add	x2, x9, x10
    c7c8:      	and	w1, w11, #0xff
    c7cc:      	mov	w8, #0x4                // =4
    c7d0:      	cinc	x0, x19, hi
    c7d4:      	blr	x8
    c7d8:      	cmp	w23, w21
    c7dc:      	str	x19, [sp, #0x60]
    c7e0:      	add	x19, sp, #0x70
    c7e4:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    c7e8:      	ldr	x21, [sp, #0x78]
    c7ec:      	ldp	x2, x24, [sp, #0x50]
    c7f0:      	str	x21, [sp, #0x48]
    c7f4:      	b	0xc844 <generic_kprobe_path+0x1a14>
    c7f8:      	add	x2, x24, #0x10
    c7fc:      	mov	w8, #0x4                // =4
    c800:      	add	x9, sp, #0x98
    c804:      	add	x0, sp, #0x98
    c808:      	mov	w1, #0x8                // =8
    c80c:      	blr	x8
    c810:      	ldr	x8, [sp, #0x58]
    c814:      	ldr	x9, [sp, #0x98]
    c818:      	cmp	x8, x9
    c81c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    c820:      	add	x2, x24, #0x18
    c824:      	mov	w8, #0x4                // =4
    c828:      	mov	x0, x22
    c82c:      	mov	w1, #0x8                // =8
    c830:      	blr	x8
    c834:      	ldr	x24, [sp, #0x98]
    c838:      	ldr	x21, [sp, #0x48]
    c83c:      	add	x2, x24, #0x20
    c840:      	stp	x2, x24, [sp, #0x50]
    c844:      	ldr	x8, [sp, #0x30]
    c848:      	cmp	x21, x8
    c84c:      	b.ne	0xc85c <generic_kprobe_path+0x1a2c>
    c850:      	ldr	x8, [sp, #0x38]
    c854:      	cmp	x2, x8
    c858:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    c85c:      	mov	w8, #0x4                // =4
    c860:      	add	x0, sp, #0x70
    c864:      	mov	w1, #0x8                // =8
    c868:      	blr	x8
    c86c:      	ldr	x8, [sp, #0x70]
    c870:      	cmp	x21, x8
    c874:      	b.eq	0xc964 <generic_kprobe_path+0x1b34>
    c878:      	add	x23, x21, #0x18
    c87c:      	mov	w8, #0x4                // =4
    c880:      	add	x9, sp, #0x98
    c884:      	add	x0, sp, #0x98
    c888:      	mov	w1, #0x8                // =8
    c88c:      	mov	x2, x23
    c890:      	blr	x8
    c894:      	ldr	x8, [sp, #0x98]
    c898:      	cmp	x8, x21
    c89c:      	b.eq	0xc964 <generic_kprobe_path+0x1b34>
    c8a0:      	mov	w8, #0x4                // =4
    c8a4:      	add	x9, sp, #0x78
    c8a8:      	add	x0, sp, #0x78
    c8ac:      	mov	w1, #0x8                // =8
    c8b0:      	mov	x2, x23
    c8b4:      	blr	x8
    c8b8:      	add	x2, x21, #0x20
    c8bc:      	mov	w8, #0x4                // =4
    c8c0:      	mov	w9, #0x10               // =16
    c8c4:      	add	x10, sp, #0x80
    c8c8:      	add	x0, sp, #0x80
    c8cc:      	mov	w1, #0x10               // =16
    c8d0:      	blr	x8
    c8d4:      	ldr	w21, [sp, #0x84]
    c8d8:      	ldr	x8, [sp, #0x40]
    c8dc:      	ldr	x10, [sp, #0x60]
    c8e0:      	sub	x12, x10, x8
    c8e4:      	ldr	w23, [sp, #0x68]
    c8e8:      	subs	w10, w21, w23
    c8ec:      	ldr	x9, [sp, #0x88]
    c8f0:      	csel	w10, wzr, w10, lo
    c8f4:      	cmp	w23, w21
    c8f8:      	csel	w11, w23, w21, lo
    c8fc:      	cinc	w13, w11, hi
    c900:      	sub	w14, w23, w13
    c904:      	subs	x12, x12, x13
    c908:      	str	w14, [sp, #0x68]
    c90c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    c910:      	cmp	x12, #0xfff
    c914:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    c918:      	cmp	w23, w21
    c91c:      	b.ls	0xc928 <generic_kprobe_path+0x1af8>
    c920:      	mov	w13, #0x2f              // =47
    c924:      	strb	w13, [x8, x12]
    c928:      	add	x19, x8, x12
    c92c:      	cmp	w23, w21
    c930:      	add	x2, x9, x10
    c934:      	and	w1, w11, #0xff
    c938:      	mov	w8, #0x4                // =4
    c93c:      	cinc	x0, x19, hi
    c940:      	blr	x8
    c944:      	cmp	w23, w21
    c948:      	str	x19, [sp, #0x60]
    c94c:      	add	x19, sp, #0x70
    c950:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    c954:      	ldr	x21, [sp, #0x78]
    c958:      	ldp	x2, x24, [sp, #0x50]
    c95c:      	str	x21, [sp, #0x48]
    c960:      	b	0xc9b0 <generic_kprobe_path+0x1b80>
    c964:      	add	x2, x24, #0x10
    c968:      	mov	w8, #0x4                // =4
    c96c:      	add	x9, sp, #0x98
    c970:      	add	x0, sp, #0x98
    c974:      	mov	w1, #0x8                // =8
    c978:      	blr	x8
    c97c:      	ldr	x8, [sp, #0x58]
    c980:      	ldr	x9, [sp, #0x98]
    c984:      	cmp	x8, x9
    c988:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    c98c:      	add	x2, x24, #0x18
    c990:      	mov	w8, #0x4                // =4
    c994:      	mov	x0, x22
    c998:      	mov	w1, #0x8                // =8
    c99c:      	blr	x8
    c9a0:      	ldr	x24, [sp, #0x98]
    c9a4:      	ldr	x21, [sp, #0x48]
    c9a8:      	add	x2, x24, #0x20
    c9ac:      	stp	x2, x24, [sp, #0x50]
    c9b0:      	ldr	x8, [sp, #0x30]
    c9b4:      	cmp	x21, x8
    c9b8:      	b.ne	0xc9c8 <generic_kprobe_path+0x1b98>
    c9bc:      	ldr	x8, [sp, #0x38]
    c9c0:      	cmp	x2, x8
    c9c4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    c9c8:      	mov	w8, #0x4                // =4
    c9cc:      	add	x0, sp, #0x70
    c9d0:      	mov	w1, #0x8                // =8
    c9d4:      	blr	x8
    c9d8:      	ldr	x8, [sp, #0x70]
    c9dc:      	cmp	x21, x8
    c9e0:      	b.eq	0xcad0 <generic_kprobe_path+0x1ca0>
    c9e4:      	add	x23, x21, #0x18
    c9e8:      	mov	w8, #0x4                // =4
    c9ec:      	add	x9, sp, #0x98
    c9f0:      	add	x0, sp, #0x98
    c9f4:      	mov	w1, #0x8                // =8
    c9f8:      	mov	x2, x23
    c9fc:      	blr	x8
    ca00:      	ldr	x8, [sp, #0x98]
    ca04:      	cmp	x8, x21
    ca08:      	b.eq	0xcad0 <generic_kprobe_path+0x1ca0>
    ca0c:      	mov	w8, #0x4                // =4
    ca10:      	add	x9, sp, #0x78
    ca14:      	add	x0, sp, #0x78
    ca18:      	mov	w1, #0x8                // =8
    ca1c:      	mov	x2, x23
    ca20:      	blr	x8
    ca24:      	add	x2, x21, #0x20
    ca28:      	mov	w8, #0x4                // =4
    ca2c:      	mov	w9, #0x10               // =16
    ca30:      	add	x10, sp, #0x80
    ca34:      	add	x0, sp, #0x80
    ca38:      	mov	w1, #0x10               // =16
    ca3c:      	blr	x8
    ca40:      	ldr	w21, [sp, #0x84]
    ca44:      	ldr	x8, [sp, #0x40]
    ca48:      	ldr	x10, [sp, #0x60]
    ca4c:      	sub	x12, x10, x8
    ca50:      	ldr	w23, [sp, #0x68]
    ca54:      	subs	w10, w21, w23
    ca58:      	ldr	x9, [sp, #0x88]
    ca5c:      	csel	w10, wzr, w10, lo
    ca60:      	cmp	w23, w21
    ca64:      	csel	w11, w23, w21, lo
    ca68:      	cinc	w13, w11, hi
    ca6c:      	sub	w14, w23, w13
    ca70:      	subs	x12, x12, x13
    ca74:      	str	w14, [sp, #0x68]
    ca78:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    ca7c:      	cmp	x12, #0xfff
    ca80:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    ca84:      	cmp	w23, w21
    ca88:      	b.ls	0xca94 <generic_kprobe_path+0x1c64>
    ca8c:      	mov	w13, #0x2f              // =47
    ca90:      	strb	w13, [x8, x12]
    ca94:      	add	x19, x8, x12
    ca98:      	cmp	w23, w21
    ca9c:      	add	x2, x9, x10
    caa0:      	and	w1, w11, #0xff
    caa4:      	mov	w8, #0x4                // =4
    caa8:      	cinc	x0, x19, hi
    caac:      	blr	x8
    cab0:      	cmp	w23, w21
    cab4:      	str	x19, [sp, #0x60]
    cab8:      	add	x19, sp, #0x70
    cabc:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    cac0:      	ldr	x21, [sp, #0x78]
    cac4:      	ldp	x2, x24, [sp, #0x50]
    cac8:      	str	x21, [sp, #0x48]
    cacc:      	b	0xcb1c <generic_kprobe_path+0x1cec>
    cad0:      	add	x2, x24, #0x10
    cad4:      	mov	w8, #0x4                // =4
    cad8:      	add	x9, sp, #0x98
    cadc:      	add	x0, sp, #0x98
    cae0:      	mov	w1, #0x8                // =8
    cae4:      	blr	x8
    cae8:      	ldr	x8, [sp, #0x58]
    caec:      	ldr	x9, [sp, #0x98]
    caf0:      	cmp	x8, x9
    caf4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    caf8:      	add	x2, x24, #0x18
    cafc:      	mov	w8, #0x4                // =4
    cb00:      	mov	x0, x22
    cb04:      	mov	w1, #0x8                // =8
    cb08:      	blr	x8
    cb0c:      	ldr	x24, [sp, #0x98]
    cb10:      	ldr	x21, [sp, #0x48]
    cb14:      	add	x2, x24, #0x20
    cb18:      	stp	x2, x24, [sp, #0x50]
    cb1c:      	ldr	x8, [sp, #0x30]
    cb20:      	cmp	x21, x8
    cb24:      	b.ne	0xcb34 <generic_kprobe_path+0x1d04>
    cb28:      	ldr	x8, [sp, #0x38]
    cb2c:      	cmp	x2, x8
    cb30:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    cb34:      	mov	w8, #0x4                // =4
    cb38:      	add	x0, sp, #0x70
    cb3c:      	mov	w1, #0x8                // =8
    cb40:      	blr	x8
    cb44:      	ldr	x8, [sp, #0x70]
    cb48:      	cmp	x21, x8
    cb4c:      	b.eq	0xcc3c <generic_kprobe_path+0x1e0c>
    cb50:      	add	x23, x21, #0x18
    cb54:      	mov	w8, #0x4                // =4
    cb58:      	add	x9, sp, #0x98
    cb5c:      	add	x0, sp, #0x98
    cb60:      	mov	w1, #0x8                // =8
    cb64:      	mov	x2, x23
    cb68:      	blr	x8
    cb6c:      	ldr	x8, [sp, #0x98]
    cb70:      	cmp	x8, x21
    cb74:      	b.eq	0xcc3c <generic_kprobe_path+0x1e0c>
    cb78:      	mov	w8, #0x4                // =4
    cb7c:      	add	x9, sp, #0x78
    cb80:      	add	x0, sp, #0x78
    cb84:      	mov	w1, #0x8                // =8
    cb88:      	mov	x2, x23
    cb8c:      	blr	x8
    cb90:      	add	x2, x21, #0x20
    cb94:      	mov	w8, #0x4                // =4
    cb98:      	mov	w9, #0x10               // =16
    cb9c:      	add	x10, sp, #0x80
    cba0:      	add	x0, sp, #0x80
    cba4:      	mov	w1, #0x10               // =16
    cba8:      	blr	x8
    cbac:      	ldr	w21, [sp, #0x84]
    cbb0:      	ldr	x8, [sp, #0x40]
    cbb4:      	ldr	x10, [sp, #0x60]
    cbb8:      	sub	x12, x10, x8
    cbbc:      	ldr	w23, [sp, #0x68]
    cbc0:      	subs	w10, w21, w23
    cbc4:      	ldr	x9, [sp, #0x88]
    cbc8:      	csel	w10, wzr, w10, lo
    cbcc:      	cmp	w23, w21
    cbd0:      	csel	w11, w23, w21, lo
    cbd4:      	cinc	w13, w11, hi
    cbd8:      	sub	w14, w23, w13
    cbdc:      	subs	x12, x12, x13
    cbe0:      	str	w14, [sp, #0x68]
    cbe4:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    cbe8:      	cmp	x12, #0xfff
    cbec:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    cbf0:      	cmp	w23, w21
    cbf4:      	b.ls	0xcc00 <generic_kprobe_path+0x1dd0>
    cbf8:      	mov	w13, #0x2f              // =47
    cbfc:      	strb	w13, [x8, x12]
    cc00:      	add	x19, x8, x12
    cc04:      	cmp	w23, w21
    cc08:      	add	x2, x9, x10
    cc0c:      	and	w1, w11, #0xff
    cc10:      	mov	w8, #0x4                // =4
    cc14:      	cinc	x0, x19, hi
    cc18:      	blr	x8
    cc1c:      	cmp	w23, w21
    cc20:      	str	x19, [sp, #0x60]
    cc24:      	add	x19, sp, #0x70
    cc28:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    cc2c:      	ldr	x21, [sp, #0x78]
    cc30:      	ldp	x2, x24, [sp, #0x50]
    cc34:      	str	x21, [sp, #0x48]
    cc38:      	b	0xcc88 <generic_kprobe_path+0x1e58>
    cc3c:      	add	x2, x24, #0x10
    cc40:      	mov	w8, #0x4                // =4
    cc44:      	add	x9, sp, #0x98
    cc48:      	add	x0, sp, #0x98
    cc4c:      	mov	w1, #0x8                // =8
    cc50:      	blr	x8
    cc54:      	ldr	x8, [sp, #0x58]
    cc58:      	ldr	x9, [sp, #0x98]
    cc5c:      	cmp	x8, x9
    cc60:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    cc64:      	add	x2, x24, #0x18
    cc68:      	mov	w8, #0x4                // =4
    cc6c:      	mov	x0, x22
    cc70:      	mov	w1, #0x8                // =8
    cc74:      	blr	x8
    cc78:      	ldr	x24, [sp, #0x98]
    cc7c:      	ldr	x21, [sp, #0x48]
    cc80:      	add	x2, x24, #0x20
    cc84:      	stp	x2, x24, [sp, #0x50]
    cc88:      	ldr	x8, [sp, #0x30]
    cc8c:      	cmp	x21, x8
    cc90:      	b.ne	0xcca0 <generic_kprobe_path+0x1e70>
    cc94:      	ldr	x8, [sp, #0x38]
    cc98:      	cmp	x2, x8
    cc9c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    cca0:      	mov	w8, #0x4                // =4
    cca4:      	add	x0, sp, #0x70
    cca8:      	mov	w1, #0x8                // =8
    ccac:      	blr	x8
    ccb0:      	ldr	x8, [sp, #0x70]
    ccb4:      	cmp	x21, x8
    ccb8:      	b.eq	0xcda8 <generic_kprobe_path+0x1f78>
    ccbc:      	add	x23, x21, #0x18
    ccc0:      	mov	w8, #0x4                // =4
    ccc4:      	add	x9, sp, #0x98
    ccc8:      	add	x0, sp, #0x98
    cccc:      	mov	w1, #0x8                // =8
    ccd0:      	mov	x2, x23
    ccd4:      	blr	x8
    ccd8:      	ldr	x8, [sp, #0x98]
    ccdc:      	cmp	x8, x21
    cce0:      	b.eq	0xcda8 <generic_kprobe_path+0x1f78>
    cce4:      	mov	w8, #0x4                // =4
    cce8:      	add	x9, sp, #0x78
    ccec:      	add	x0, sp, #0x78
    ccf0:      	mov	w1, #0x8                // =8
    ccf4:      	mov	x2, x23
    ccf8:      	blr	x8
    ccfc:      	add	x2, x21, #0x20
    cd00:      	mov	w8, #0x4                // =4
    cd04:      	mov	w9, #0x10               // =16
    cd08:      	add	x10, sp, #0x80
    cd0c:      	add	x0, sp, #0x80
    cd10:      	mov	w1, #0x10               // =16
    cd14:      	blr	x8
    cd18:      	ldr	w21, [sp, #0x84]
    cd1c:      	ldr	x8, [sp, #0x40]
    cd20:      	ldr	x10, [sp, #0x60]
    cd24:      	sub	x12, x10, x8
    cd28:      	ldr	w23, [sp, #0x68]
    cd2c:      	subs	w10, w21, w23
    cd30:      	ldr	x9, [sp, #0x88]
    cd34:      	csel	w10, wzr, w10, lo
    cd38:      	cmp	w23, w21
    cd3c:      	csel	w11, w23, w21, lo
    cd40:      	cinc	w13, w11, hi
    cd44:      	sub	w14, w23, w13
    cd48:      	subs	x12, x12, x13
    cd4c:      	str	w14, [sp, #0x68]
    cd50:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    cd54:      	cmp	x12, #0xfff
    cd58:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    cd5c:      	cmp	w23, w21
    cd60:      	b.ls	0xcd6c <generic_kprobe_path+0x1f3c>
    cd64:      	mov	w13, #0x2f              // =47
    cd68:      	strb	w13, [x8, x12]
    cd6c:      	add	x19, x8, x12
    cd70:      	cmp	w23, w21
    cd74:      	add	x2, x9, x10
    cd78:      	and	w1, w11, #0xff
    cd7c:      	mov	w8, #0x4                // =4
    cd80:      	cinc	x0, x19, hi
    cd84:      	blr	x8
    cd88:      	cmp	w23, w21
    cd8c:      	str	x19, [sp, #0x60]
    cd90:      	add	x19, sp, #0x70
    cd94:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    cd98:      	ldr	x21, [sp, #0x78]
    cd9c:      	ldp	x2, x24, [sp, #0x50]
    cda0:      	str	x21, [sp, #0x48]
    cda4:      	b	0xcdf4 <generic_kprobe_path+0x1fc4>
    cda8:      	add	x2, x24, #0x10
    cdac:      	mov	w8, #0x4                // =4
    cdb0:      	add	x9, sp, #0x98
    cdb4:      	add	x0, sp, #0x98
    cdb8:      	mov	w1, #0x8                // =8
    cdbc:      	blr	x8
    cdc0:      	ldr	x8, [sp, #0x58]
    cdc4:      	ldr	x9, [sp, #0x98]
    cdc8:      	cmp	x8, x9
    cdcc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    cdd0:      	add	x2, x24, #0x18
    cdd4:      	mov	w8, #0x4                // =4
    cdd8:      	mov	x0, x22
    cddc:      	mov	w1, #0x8                // =8
    cde0:      	blr	x8
    cde4:      	ldr	x24, [sp, #0x98]
    cde8:      	ldr	x21, [sp, #0x48]
    cdec:      	add	x2, x24, #0x20
    cdf0:      	stp	x2, x24, [sp, #0x50]
    cdf4:      	ldr	x8, [sp, #0x30]
    cdf8:      	cmp	x21, x8
    cdfc:      	b.ne	0xce0c <generic_kprobe_path+0x1fdc>
    ce00:      	ldr	x8, [sp, #0x38]
    ce04:      	cmp	x2, x8
    ce08:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    ce0c:      	mov	w8, #0x4                // =4
    ce10:      	add	x0, sp, #0x70
    ce14:      	mov	w1, #0x8                // =8
    ce18:      	blr	x8
    ce1c:      	ldr	x8, [sp, #0x70]
    ce20:      	cmp	x21, x8
    ce24:      	b.eq	0xcf14 <generic_kprobe_path+0x20e4>
    ce28:      	add	x23, x21, #0x18
    ce2c:      	mov	w8, #0x4                // =4
    ce30:      	add	x9, sp, #0x98
    ce34:      	add	x0, sp, #0x98
    ce38:      	mov	w1, #0x8                // =8
    ce3c:      	mov	x2, x23
    ce40:      	blr	x8
    ce44:      	ldr	x8, [sp, #0x98]
    ce48:      	cmp	x8, x21
    ce4c:      	b.eq	0xcf14 <generic_kprobe_path+0x20e4>
    ce50:      	mov	w8, #0x4                // =4
    ce54:      	add	x9, sp, #0x78
    ce58:      	add	x0, sp, #0x78
    ce5c:      	mov	w1, #0x8                // =8
    ce60:      	mov	x2, x23
    ce64:      	blr	x8
    ce68:      	add	x2, x21, #0x20
    ce6c:      	mov	w8, #0x4                // =4
    ce70:      	mov	w9, #0x10               // =16
    ce74:      	add	x10, sp, #0x80
    ce78:      	add	x0, sp, #0x80
    ce7c:      	mov	w1, #0x10               // =16
    ce80:      	blr	x8
    ce84:      	ldr	w21, [sp, #0x84]
    ce88:      	ldr	x8, [sp, #0x40]
    ce8c:      	ldr	x10, [sp, #0x60]
    ce90:      	sub	x12, x10, x8
    ce94:      	ldr	w23, [sp, #0x68]
    ce98:      	subs	w10, w21, w23
    ce9c:      	ldr	x9, [sp, #0x88]
    cea0:      	csel	w10, wzr, w10, lo
    cea4:      	cmp	w23, w21
    cea8:      	csel	w11, w23, w21, lo
    ceac:      	cinc	w13, w11, hi
    ceb0:      	sub	w14, w23, w13
    ceb4:      	subs	x12, x12, x13
    ceb8:      	str	w14, [sp, #0x68]
    cebc:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    cec0:      	cmp	x12, #0xfff
    cec4:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    cec8:      	cmp	w23, w21
    cecc:      	b.ls	0xced8 <generic_kprobe_path+0x20a8>
    ced0:      	mov	w13, #0x2f              // =47
    ced4:      	strb	w13, [x8, x12]
    ced8:      	add	x19, x8, x12
    cedc:      	cmp	w23, w21
    cee0:      	add	x2, x9, x10
    cee4:      	and	w1, w11, #0xff
    cee8:      	mov	w8, #0x4                // =4
    ceec:      	cinc	x0, x19, hi
    cef0:      	blr	x8
    cef4:      	cmp	w23, w21
    cef8:      	str	x19, [sp, #0x60]
    cefc:      	add	x19, sp, #0x70
    cf00:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    cf04:      	ldr	x21, [sp, #0x78]
    cf08:      	ldp	x2, x24, [sp, #0x50]
    cf0c:      	str	x21, [sp, #0x48]
    cf10:      	b	0xcf60 <generic_kprobe_path+0x2130>
    cf14:      	add	x2, x24, #0x10
    cf18:      	mov	w8, #0x4                // =4
    cf1c:      	add	x9, sp, #0x98
    cf20:      	add	x0, sp, #0x98
    cf24:      	mov	w1, #0x8                // =8
    cf28:      	blr	x8
    cf2c:      	ldr	x8, [sp, #0x58]
    cf30:      	ldr	x9, [sp, #0x98]
    cf34:      	cmp	x8, x9
    cf38:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    cf3c:      	add	x2, x24, #0x18
    cf40:      	mov	w8, #0x4                // =4
    cf44:      	mov	x0, x22
    cf48:      	mov	w1, #0x8                // =8
    cf4c:      	blr	x8
    cf50:      	ldr	x24, [sp, #0x98]
    cf54:      	ldr	x21, [sp, #0x48]
    cf58:      	add	x2, x24, #0x20
    cf5c:      	stp	x2, x24, [sp, #0x50]
    cf60:      	ldr	x8, [sp, #0x30]
    cf64:      	cmp	x21, x8
    cf68:      	b.ne	0xcf78 <generic_kprobe_path+0x2148>
    cf6c:      	ldr	x8, [sp, #0x38]
    cf70:      	cmp	x2, x8
    cf74:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    cf78:      	mov	w8, #0x4                // =4
    cf7c:      	add	x0, sp, #0x70
    cf80:      	mov	w1, #0x8                // =8
    cf84:      	blr	x8
    cf88:      	ldr	x8, [sp, #0x70]
    cf8c:      	cmp	x21, x8
    cf90:      	b.eq	0xd080 <generic_kprobe_path+0x2250>
    cf94:      	add	x23, x21, #0x18
    cf98:      	mov	w8, #0x4                // =4
    cf9c:      	add	x9, sp, #0x98
    cfa0:      	add	x0, sp, #0x98
    cfa4:      	mov	w1, #0x8                // =8
    cfa8:      	mov	x2, x23
    cfac:      	blr	x8
    cfb0:      	ldr	x8, [sp, #0x98]
    cfb4:      	cmp	x8, x21
    cfb8:      	b.eq	0xd080 <generic_kprobe_path+0x2250>
    cfbc:      	mov	w8, #0x4                // =4
    cfc0:      	add	x9, sp, #0x78
    cfc4:      	add	x0, sp, #0x78
    cfc8:      	mov	w1, #0x8                // =8
    cfcc:      	mov	x2, x23
    cfd0:      	blr	x8
    cfd4:      	add	x2, x21, #0x20
    cfd8:      	mov	w8, #0x4                // =4
    cfdc:      	mov	w9, #0x10               // =16
    cfe0:      	add	x10, sp, #0x80
    cfe4:      	add	x0, sp, #0x80
    cfe8:      	mov	w1, #0x10               // =16
    cfec:      	blr	x8
    cff0:      	ldr	w21, [sp, #0x84]
    cff4:      	ldr	x8, [sp, #0x40]
    cff8:      	ldr	x10, [sp, #0x60]
    cffc:      	sub	x12, x10, x8
    d000:      	ldr	w23, [sp, #0x68]
    d004:      	subs	w10, w21, w23
    d008:      	ldr	x9, [sp, #0x88]
    d00c:      	csel	w10, wzr, w10, lo
    d010:      	cmp	w23, w21
    d014:      	csel	w11, w23, w21, lo
    d018:      	cinc	w13, w11, hi
    d01c:      	sub	w14, w23, w13
    d020:      	subs	x12, x12, x13
    d024:      	str	w14, [sp, #0x68]
    d028:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    d02c:      	cmp	x12, #0xfff
    d030:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    d034:      	cmp	w23, w21
    d038:      	b.ls	0xd044 <generic_kprobe_path+0x2214>
    d03c:      	mov	w13, #0x2f              // =47
    d040:      	strb	w13, [x8, x12]
    d044:      	add	x19, x8, x12
    d048:      	cmp	w23, w21
    d04c:      	add	x2, x9, x10
    d050:      	and	w1, w11, #0xff
    d054:      	mov	w8, #0x4                // =4
    d058:      	cinc	x0, x19, hi
    d05c:      	blr	x8
    d060:      	cmp	w23, w21
    d064:      	str	x19, [sp, #0x60]
    d068:      	add	x19, sp, #0x70
    d06c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    d070:      	ldr	x21, [sp, #0x78]
    d074:      	ldp	x2, x24, [sp, #0x50]
    d078:      	str	x21, [sp, #0x48]
    d07c:      	b	0xd0cc <generic_kprobe_path+0x229c>
    d080:      	add	x2, x24, #0x10
    d084:      	mov	w8, #0x4                // =4
    d088:      	add	x9, sp, #0x98
    d08c:      	add	x0, sp, #0x98
    d090:      	mov	w1, #0x8                // =8
    d094:      	blr	x8
    d098:      	ldr	x8, [sp, #0x58]
    d09c:      	ldr	x9, [sp, #0x98]
    d0a0:      	cmp	x8, x9
    d0a4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    d0a8:      	add	x2, x24, #0x18
    d0ac:      	mov	w8, #0x4                // =4
    d0b0:      	mov	x0, x22
    d0b4:      	mov	w1, #0x8                // =8
    d0b8:      	blr	x8
    d0bc:      	ldr	x24, [sp, #0x98]
    d0c0:      	ldr	x21, [sp, #0x48]
    d0c4:      	add	x2, x24, #0x20
    d0c8:      	stp	x2, x24, [sp, #0x50]
    d0cc:      	ldr	x8, [sp, #0x30]
    d0d0:      	cmp	x21, x8
    d0d4:      	b.ne	0xd0e4 <generic_kprobe_path+0x22b4>
    d0d8:      	ldr	x8, [sp, #0x38]
    d0dc:      	cmp	x2, x8
    d0e0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    d0e4:      	mov	w8, #0x4                // =4
    d0e8:      	add	x0, sp, #0x70
    d0ec:      	mov	w1, #0x8                // =8
    d0f0:      	blr	x8
    d0f4:      	ldr	x8, [sp, #0x70]
    d0f8:      	cmp	x21, x8
    d0fc:      	b.eq	0xd1ec <generic_kprobe_path+0x23bc>
    d100:      	add	x23, x21, #0x18
    d104:      	mov	w8, #0x4                // =4
    d108:      	add	x9, sp, #0x98
    d10c:      	add	x0, sp, #0x98
    d110:      	mov	w1, #0x8                // =8
    d114:      	mov	x2, x23
    d118:      	blr	x8
    d11c:      	ldr	x8, [sp, #0x98]
    d120:      	cmp	x8, x21
    d124:      	b.eq	0xd1ec <generic_kprobe_path+0x23bc>
    d128:      	mov	w8, #0x4                // =4
    d12c:      	add	x9, sp, #0x78
    d130:      	add	x0, sp, #0x78
    d134:      	mov	w1, #0x8                // =8
    d138:      	mov	x2, x23
    d13c:      	blr	x8
    d140:      	add	x2, x21, #0x20
    d144:      	mov	w8, #0x4                // =4
    d148:      	mov	w9, #0x10               // =16
    d14c:      	add	x10, sp, #0x80
    d150:      	add	x0, sp, #0x80
    d154:      	mov	w1, #0x10               // =16
    d158:      	blr	x8
    d15c:      	ldr	w21, [sp, #0x84]
    d160:      	ldr	x8, [sp, #0x40]
    d164:      	ldr	x10, [sp, #0x60]
    d168:      	sub	x12, x10, x8
    d16c:      	ldr	w23, [sp, #0x68]
    d170:      	subs	w10, w21, w23
    d174:      	ldr	x9, [sp, #0x88]
    d178:      	csel	w10, wzr, w10, lo
    d17c:      	cmp	w23, w21
    d180:      	csel	w11, w23, w21, lo
    d184:      	cinc	w13, w11, hi
    d188:      	sub	w14, w23, w13
    d18c:      	subs	x12, x12, x13
    d190:      	str	w14, [sp, #0x68]
    d194:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    d198:      	cmp	x12, #0xfff
    d19c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    d1a0:      	cmp	w23, w21
    d1a4:      	b.ls	0xd1b0 <generic_kprobe_path+0x2380>
    d1a8:      	mov	w13, #0x2f              // =47
    d1ac:      	strb	w13, [x8, x12]
    d1b0:      	add	x19, x8, x12
    d1b4:      	cmp	w23, w21
    d1b8:      	add	x2, x9, x10
    d1bc:      	and	w1, w11, #0xff
    d1c0:      	mov	w8, #0x4                // =4
    d1c4:      	cinc	x0, x19, hi
    d1c8:      	blr	x8
    d1cc:      	cmp	w23, w21
    d1d0:      	str	x19, [sp, #0x60]
    d1d4:      	add	x19, sp, #0x70
    d1d8:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    d1dc:      	ldr	x21, [sp, #0x78]
    d1e0:      	ldp	x2, x24, [sp, #0x50]
    d1e4:      	str	x21, [sp, #0x48]
    d1e8:      	b	0xd238 <generic_kprobe_path+0x2408>
    d1ec:      	add	x2, x24, #0x10
    d1f0:      	mov	w8, #0x4                // =4
    d1f4:      	add	x9, sp, #0x98
    d1f8:      	add	x0, sp, #0x98
    d1fc:      	mov	w1, #0x8                // =8
    d200:      	blr	x8
    d204:      	ldr	x8, [sp, #0x58]
    d208:      	ldr	x9, [sp, #0x98]
    d20c:      	cmp	x8, x9
    d210:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    d214:      	add	x2, x24, #0x18
    d218:      	mov	w8, #0x4                // =4
    d21c:      	mov	x0, x22
    d220:      	mov	w1, #0x8                // =8
    d224:      	blr	x8
    d228:      	ldr	x24, [sp, #0x98]
    d22c:      	ldr	x21, [sp, #0x48]
    d230:      	add	x2, x24, #0x20
    d234:      	stp	x2, x24, [sp, #0x50]
    d238:      	ldr	x8, [sp, #0x30]
    d23c:      	cmp	x21, x8
    d240:      	b.ne	0xd250 <generic_kprobe_path+0x2420>
    d244:      	ldr	x8, [sp, #0x38]
    d248:      	cmp	x2, x8
    d24c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    d250:      	mov	w8, #0x4                // =4
    d254:      	add	x0, sp, #0x70
    d258:      	mov	w1, #0x8                // =8
    d25c:      	blr	x8
    d260:      	ldr	x8, [sp, #0x70]
    d264:      	cmp	x21, x8
    d268:      	b.eq	0xd358 <generic_kprobe_path+0x2528>
    d26c:      	add	x23, x21, #0x18
    d270:      	mov	w8, #0x4                // =4
    d274:      	add	x9, sp, #0x98
    d278:      	add	x0, sp, #0x98
    d27c:      	mov	w1, #0x8                // =8
    d280:      	mov	x2, x23
    d284:      	blr	x8
    d288:      	ldr	x8, [sp, #0x98]
    d28c:      	cmp	x8, x21
    d290:      	b.eq	0xd358 <generic_kprobe_path+0x2528>
    d294:      	mov	w8, #0x4                // =4
    d298:      	add	x9, sp, #0x78
    d29c:      	add	x0, sp, #0x78
    d2a0:      	mov	w1, #0x8                // =8
    d2a4:      	mov	x2, x23
    d2a8:      	blr	x8
    d2ac:      	add	x2, x21, #0x20
    d2b0:      	mov	w8, #0x4                // =4
    d2b4:      	mov	w9, #0x10               // =16
    d2b8:      	add	x10, sp, #0x80
    d2bc:      	add	x0, sp, #0x80
    d2c0:      	mov	w1, #0x10               // =16
    d2c4:      	blr	x8
    d2c8:      	ldr	w21, [sp, #0x84]
    d2cc:      	ldr	x8, [sp, #0x40]
    d2d0:      	ldr	x10, [sp, #0x60]
    d2d4:      	sub	x12, x10, x8
    d2d8:      	ldr	w23, [sp, #0x68]
    d2dc:      	subs	w10, w21, w23
    d2e0:      	ldr	x9, [sp, #0x88]
    d2e4:      	csel	w10, wzr, w10, lo
    d2e8:      	cmp	w23, w21
    d2ec:      	csel	w11, w23, w21, lo
    d2f0:      	cinc	w13, w11, hi
    d2f4:      	sub	w14, w23, w13
    d2f8:      	subs	x12, x12, x13
    d2fc:      	str	w14, [sp, #0x68]
    d300:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    d304:      	cmp	x12, #0xfff
    d308:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    d30c:      	cmp	w23, w21
    d310:      	b.ls	0xd31c <generic_kprobe_path+0x24ec>
    d314:      	mov	w13, #0x2f              // =47
    d318:      	strb	w13, [x8, x12]
    d31c:      	add	x19, x8, x12
    d320:      	cmp	w23, w21
    d324:      	add	x2, x9, x10
    d328:      	and	w1, w11, #0xff
    d32c:      	mov	w8, #0x4                // =4
    d330:      	cinc	x0, x19, hi
    d334:      	blr	x8
    d338:      	cmp	w23, w21
    d33c:      	str	x19, [sp, #0x60]
    d340:      	add	x19, sp, #0x70
    d344:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    d348:      	ldr	x21, [sp, #0x78]
    d34c:      	ldp	x2, x24, [sp, #0x50]
    d350:      	str	x21, [sp, #0x48]
    d354:      	b	0xd3a4 <generic_kprobe_path+0x2574>
    d358:      	add	x2, x24, #0x10
    d35c:      	mov	w8, #0x4                // =4
    d360:      	add	x9, sp, #0x98
    d364:      	add	x0, sp, #0x98
    d368:      	mov	w1, #0x8                // =8
    d36c:      	blr	x8
    d370:      	ldr	x8, [sp, #0x58]
    d374:      	ldr	x9, [sp, #0x98]
    d378:      	cmp	x8, x9
    d37c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    d380:      	add	x2, x24, #0x18
    d384:      	mov	w8, #0x4                // =4
    d388:      	mov	x0, x22
    d38c:      	mov	w1, #0x8                // =8
    d390:      	blr	x8
    d394:      	ldr	x24, [sp, #0x98]
    d398:      	ldr	x21, [sp, #0x48]
    d39c:      	add	x2, x24, #0x20
    d3a0:      	stp	x2, x24, [sp, #0x50]
    d3a4:      	ldr	x8, [sp, #0x30]
    d3a8:      	cmp	x21, x8
    d3ac:      	b.ne	0xd3bc <generic_kprobe_path+0x258c>
    d3b0:      	ldr	x8, [sp, #0x38]
    d3b4:      	cmp	x2, x8
    d3b8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    d3bc:      	mov	w8, #0x4                // =4
    d3c0:      	add	x0, sp, #0x70
    d3c4:      	mov	w1, #0x8                // =8
    d3c8:      	blr	x8
    d3cc:      	ldr	x8, [sp, #0x70]
    d3d0:      	cmp	x21, x8
    d3d4:      	b.eq	0xd4c4 <generic_kprobe_path+0x2694>
    d3d8:      	add	x23, x21, #0x18
    d3dc:      	mov	w8, #0x4                // =4
    d3e0:      	add	x9, sp, #0x98
    d3e4:      	add	x0, sp, #0x98
    d3e8:      	mov	w1, #0x8                // =8
    d3ec:      	mov	x2, x23
    d3f0:      	blr	x8
    d3f4:      	ldr	x8, [sp, #0x98]
    d3f8:      	cmp	x8, x21
    d3fc:      	b.eq	0xd4c4 <generic_kprobe_path+0x2694>
    d400:      	mov	w8, #0x4                // =4
    d404:      	add	x9, sp, #0x78
    d408:      	add	x0, sp, #0x78
    d40c:      	mov	w1, #0x8                // =8
    d410:      	mov	x2, x23
    d414:      	blr	x8
    d418:      	add	x2, x21, #0x20
    d41c:      	mov	w8, #0x4                // =4
    d420:      	mov	w9, #0x10               // =16
    d424:      	add	x10, sp, #0x80
    d428:      	add	x0, sp, #0x80
    d42c:      	mov	w1, #0x10               // =16
    d430:      	blr	x8
    d434:      	ldr	w21, [sp, #0x84]
    d438:      	ldr	x8, [sp, #0x40]
    d43c:      	ldr	x10, [sp, #0x60]
    d440:      	sub	x12, x10, x8
    d444:      	ldr	w23, [sp, #0x68]
    d448:      	subs	w10, w21, w23
    d44c:      	ldr	x9, [sp, #0x88]
    d450:      	csel	w10, wzr, w10, lo
    d454:      	cmp	w23, w21
    d458:      	csel	w11, w23, w21, lo
    d45c:      	cinc	w13, w11, hi
    d460:      	sub	w14, w23, w13
    d464:      	subs	x12, x12, x13
    d468:      	str	w14, [sp, #0x68]
    d46c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    d470:      	cmp	x12, #0xfff
    d474:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    d478:      	cmp	w23, w21
    d47c:      	b.ls	0xd488 <generic_kprobe_path+0x2658>
    d480:      	mov	w13, #0x2f              // =47
    d484:      	strb	w13, [x8, x12]
    d488:      	add	x19, x8, x12
    d48c:      	cmp	w23, w21
    d490:      	add	x2, x9, x10
    d494:      	and	w1, w11, #0xff
    d498:      	mov	w8, #0x4                // =4
    d49c:      	cinc	x0, x19, hi
    d4a0:      	blr	x8
    d4a4:      	cmp	w23, w21
    d4a8:      	str	x19, [sp, #0x60]
    d4ac:      	add	x19, sp, #0x70
    d4b0:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    d4b4:      	ldr	x21, [sp, #0x78]
    d4b8:      	ldp	x2, x24, [sp, #0x50]
    d4bc:      	str	x21, [sp, #0x48]
    d4c0:      	b	0xd510 <generic_kprobe_path+0x26e0>
    d4c4:      	add	x2, x24, #0x10
    d4c8:      	mov	w8, #0x4                // =4
    d4cc:      	add	x9, sp, #0x98
    d4d0:      	add	x0, sp, #0x98
    d4d4:      	mov	w1, #0x8                // =8
    d4d8:      	blr	x8
    d4dc:      	ldr	x8, [sp, #0x58]
    d4e0:      	ldr	x9, [sp, #0x98]
    d4e4:      	cmp	x8, x9
    d4e8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    d4ec:      	add	x2, x24, #0x18
    d4f0:      	mov	w8, #0x4                // =4
    d4f4:      	mov	x0, x22
    d4f8:      	mov	w1, #0x8                // =8
    d4fc:      	blr	x8
    d500:      	ldr	x24, [sp, #0x98]
    d504:      	ldr	x21, [sp, #0x48]
    d508:      	add	x2, x24, #0x20
    d50c:      	stp	x2, x24, [sp, #0x50]
    d510:      	ldr	x8, [sp, #0x30]
    d514:      	cmp	x21, x8
    d518:      	b.ne	0xd528 <generic_kprobe_path+0x26f8>
    d51c:      	ldr	x8, [sp, #0x38]
    d520:      	cmp	x2, x8
    d524:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    d528:      	mov	w8, #0x4                // =4
    d52c:      	add	x0, sp, #0x70
    d530:      	mov	w1, #0x8                // =8
    d534:      	blr	x8
    d538:      	ldr	x8, [sp, #0x70]
    d53c:      	cmp	x21, x8
    d540:      	b.eq	0xd630 <generic_kprobe_path+0x2800>
    d544:      	add	x23, x21, #0x18
    d548:      	mov	w8, #0x4                // =4
    d54c:      	add	x9, sp, #0x98
    d550:      	add	x0, sp, #0x98
    d554:      	mov	w1, #0x8                // =8
    d558:      	mov	x2, x23
    d55c:      	blr	x8
    d560:      	ldr	x8, [sp, #0x98]
    d564:      	cmp	x8, x21
    d568:      	b.eq	0xd630 <generic_kprobe_path+0x2800>
    d56c:      	mov	w8, #0x4                // =4
    d570:      	add	x9, sp, #0x78
    d574:      	add	x0, sp, #0x78
    d578:      	mov	w1, #0x8                // =8
    d57c:      	mov	x2, x23
    d580:      	blr	x8
    d584:      	add	x2, x21, #0x20
    d588:      	mov	w8, #0x4                // =4
    d58c:      	mov	w9, #0x10               // =16
    d590:      	add	x10, sp, #0x80
    d594:      	add	x0, sp, #0x80
    d598:      	mov	w1, #0x10               // =16
    d59c:      	blr	x8
    d5a0:      	ldr	w21, [sp, #0x84]
    d5a4:      	ldr	x8, [sp, #0x40]
    d5a8:      	ldr	x10, [sp, #0x60]
    d5ac:      	sub	x12, x10, x8
    d5b0:      	ldr	w23, [sp, #0x68]
    d5b4:      	subs	w10, w21, w23
    d5b8:      	ldr	x9, [sp, #0x88]
    d5bc:      	csel	w10, wzr, w10, lo
    d5c0:      	cmp	w23, w21
    d5c4:      	csel	w11, w23, w21, lo
    d5c8:      	cinc	w13, w11, hi
    d5cc:      	sub	w14, w23, w13
    d5d0:      	subs	x12, x12, x13
    d5d4:      	str	w14, [sp, #0x68]
    d5d8:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    d5dc:      	cmp	x12, #0xfff
    d5e0:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    d5e4:      	cmp	w23, w21
    d5e8:      	b.ls	0xd5f4 <generic_kprobe_path+0x27c4>
    d5ec:      	mov	w13, #0x2f              // =47
    d5f0:      	strb	w13, [x8, x12]
    d5f4:      	add	x19, x8, x12
    d5f8:      	cmp	w23, w21
    d5fc:      	add	x2, x9, x10
    d600:      	and	w1, w11, #0xff
    d604:      	mov	w8, #0x4                // =4
    d608:      	cinc	x0, x19, hi
    d60c:      	blr	x8
    d610:      	cmp	w23, w21
    d614:      	str	x19, [sp, #0x60]
    d618:      	add	x19, sp, #0x70
    d61c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    d620:      	ldr	x21, [sp, #0x78]
    d624:      	ldp	x2, x24, [sp, #0x50]
    d628:      	str	x21, [sp, #0x48]
    d62c:      	b	0xd67c <generic_kprobe_path+0x284c>
    d630:      	add	x2, x24, #0x10
    d634:      	mov	w8, #0x4                // =4
    d638:      	add	x9, sp, #0x98
    d63c:      	add	x0, sp, #0x98
    d640:      	mov	w1, #0x8                // =8
    d644:      	blr	x8
    d648:      	ldr	x8, [sp, #0x58]
    d64c:      	ldr	x9, [sp, #0x98]
    d650:      	cmp	x8, x9
    d654:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    d658:      	add	x2, x24, #0x18
    d65c:      	mov	w8, #0x4                // =4
    d660:      	mov	x0, x22
    d664:      	mov	w1, #0x8                // =8
    d668:      	blr	x8
    d66c:      	ldr	x24, [sp, #0x98]
    d670:      	ldr	x21, [sp, #0x48]
    d674:      	add	x2, x24, #0x20
    d678:      	stp	x2, x24, [sp, #0x50]
    d67c:      	ldr	x8, [sp, #0x30]
    d680:      	cmp	x21, x8
    d684:      	b.ne	0xd694 <generic_kprobe_path+0x2864>
    d688:      	ldr	x8, [sp, #0x38]
    d68c:      	cmp	x2, x8
    d690:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    d694:      	mov	w8, #0x4                // =4
    d698:      	add	x0, sp, #0x70
    d69c:      	mov	w1, #0x8                // =8
    d6a0:      	blr	x8
    d6a4:      	ldr	x8, [sp, #0x70]
    d6a8:      	cmp	x21, x8
    d6ac:      	b.eq	0xd79c <generic_kprobe_path+0x296c>
    d6b0:      	add	x23, x21, #0x18
    d6b4:      	mov	w8, #0x4                // =4
    d6b8:      	add	x9, sp, #0x98
    d6bc:      	add	x0, sp, #0x98
    d6c0:      	mov	w1, #0x8                // =8
    d6c4:      	mov	x2, x23
    d6c8:      	blr	x8
    d6cc:      	ldr	x8, [sp, #0x98]
    d6d0:      	cmp	x8, x21
    d6d4:      	b.eq	0xd79c <generic_kprobe_path+0x296c>
    d6d8:      	mov	w8, #0x4                // =4
    d6dc:      	add	x9, sp, #0x78
    d6e0:      	add	x0, sp, #0x78
    d6e4:      	mov	w1, #0x8                // =8
    d6e8:      	mov	x2, x23
    d6ec:      	blr	x8
    d6f0:      	add	x2, x21, #0x20
    d6f4:      	mov	w8, #0x4                // =4
    d6f8:      	mov	w9, #0x10               // =16
    d6fc:      	add	x10, sp, #0x80
    d700:      	add	x0, sp, #0x80
    d704:      	mov	w1, #0x10               // =16
    d708:      	blr	x8
    d70c:      	ldr	w21, [sp, #0x84]
    d710:      	ldr	x8, [sp, #0x40]
    d714:      	ldr	x10, [sp, #0x60]
    d718:      	sub	x12, x10, x8
    d71c:      	ldr	w23, [sp, #0x68]
    d720:      	subs	w10, w21, w23
    d724:      	ldr	x9, [sp, #0x88]
    d728:      	csel	w10, wzr, w10, lo
    d72c:      	cmp	w23, w21
    d730:      	csel	w11, w23, w21, lo
    d734:      	cinc	w13, w11, hi
    d738:      	sub	w14, w23, w13
    d73c:      	subs	x12, x12, x13
    d740:      	str	w14, [sp, #0x68]
    d744:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    d748:      	cmp	x12, #0xfff
    d74c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    d750:      	cmp	w23, w21
    d754:      	b.ls	0xd760 <generic_kprobe_path+0x2930>
    d758:      	mov	w13, #0x2f              // =47
    d75c:      	strb	w13, [x8, x12]
    d760:      	add	x19, x8, x12
    d764:      	cmp	w23, w21
    d768:      	add	x2, x9, x10
    d76c:      	and	w1, w11, #0xff
    d770:      	mov	w8, #0x4                // =4
    d774:      	cinc	x0, x19, hi
    d778:      	blr	x8
    d77c:      	cmp	w23, w21
    d780:      	str	x19, [sp, #0x60]
    d784:      	add	x19, sp, #0x70
    d788:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    d78c:      	ldr	x21, [sp, #0x78]
    d790:      	ldp	x2, x24, [sp, #0x50]
    d794:      	str	x21, [sp, #0x48]
    d798:      	b	0xd7e8 <generic_kprobe_path+0x29b8>
    d79c:      	add	x2, x24, #0x10
    d7a0:      	mov	w8, #0x4                // =4
    d7a4:      	add	x9, sp, #0x98
    d7a8:      	add	x0, sp, #0x98
    d7ac:      	mov	w1, #0x8                // =8
    d7b0:      	blr	x8
    d7b4:      	ldr	x8, [sp, #0x58]
    d7b8:      	ldr	x9, [sp, #0x98]
    d7bc:      	cmp	x8, x9
    d7c0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    d7c4:      	add	x2, x24, #0x18
    d7c8:      	mov	w8, #0x4                // =4
    d7cc:      	mov	x0, x22
    d7d0:      	mov	w1, #0x8                // =8
    d7d4:      	blr	x8
    d7d8:      	ldr	x24, [sp, #0x98]
    d7dc:      	ldr	x21, [sp, #0x48]
    d7e0:      	add	x2, x24, #0x20
    d7e4:      	stp	x2, x24, [sp, #0x50]
    d7e8:      	ldr	x8, [sp, #0x30]
    d7ec:      	cmp	x21, x8
    d7f0:      	b.ne	0xd800 <generic_kprobe_path+0x29d0>
    d7f4:      	ldr	x8, [sp, #0x38]
    d7f8:      	cmp	x2, x8
    d7fc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    d800:      	mov	w8, #0x4                // =4
    d804:      	add	x0, sp, #0x70
    d808:      	mov	w1, #0x8                // =8
    d80c:      	blr	x8
    d810:      	ldr	x8, [sp, #0x70]
    d814:      	cmp	x21, x8
    d818:      	b.eq	0xd908 <generic_kprobe_path+0x2ad8>
    d81c:      	add	x23, x21, #0x18
    d820:      	mov	w8, #0x4                // =4
    d824:      	add	x9, sp, #0x98
    d828:      	add	x0, sp, #0x98
    d82c:      	mov	w1, #0x8                // =8
    d830:      	mov	x2, x23
    d834:      	blr	x8
    d838:      	ldr	x8, [sp, #0x98]
    d83c:      	cmp	x8, x21
    d840:      	b.eq	0xd908 <generic_kprobe_path+0x2ad8>
    d844:      	mov	w8, #0x4                // =4
    d848:      	add	x9, sp, #0x78
    d84c:      	add	x0, sp, #0x78
    d850:      	mov	w1, #0x8                // =8
    d854:      	mov	x2, x23
    d858:      	blr	x8
    d85c:      	add	x2, x21, #0x20
    d860:      	mov	w8, #0x4                // =4
    d864:      	mov	w9, #0x10               // =16
    d868:      	add	x10, sp, #0x80
    d86c:      	add	x0, sp, #0x80
    d870:      	mov	w1, #0x10               // =16
    d874:      	blr	x8
    d878:      	ldr	w21, [sp, #0x84]
    d87c:      	ldr	x8, [sp, #0x40]
    d880:      	ldr	x10, [sp, #0x60]
    d884:      	sub	x12, x10, x8
    d888:      	ldr	w23, [sp, #0x68]
    d88c:      	subs	w10, w21, w23
    d890:      	ldr	x9, [sp, #0x88]
    d894:      	csel	w10, wzr, w10, lo
    d898:      	cmp	w23, w21
    d89c:      	csel	w11, w23, w21, lo
    d8a0:      	cinc	w13, w11, hi
    d8a4:      	sub	w14, w23, w13
    d8a8:      	subs	x12, x12, x13
    d8ac:      	str	w14, [sp, #0x68]
    d8b0:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    d8b4:      	cmp	x12, #0xfff
    d8b8:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    d8bc:      	cmp	w23, w21
    d8c0:      	b.ls	0xd8cc <generic_kprobe_path+0x2a9c>
    d8c4:      	mov	w13, #0x2f              // =47
    d8c8:      	strb	w13, [x8, x12]
    d8cc:      	add	x19, x8, x12
    d8d0:      	cmp	w23, w21
    d8d4:      	add	x2, x9, x10
    d8d8:      	and	w1, w11, #0xff
    d8dc:      	mov	w8, #0x4                // =4
    d8e0:      	cinc	x0, x19, hi
    d8e4:      	blr	x8
    d8e8:      	cmp	w23, w21
    d8ec:      	str	x19, [sp, #0x60]
    d8f0:      	add	x19, sp, #0x70
    d8f4:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    d8f8:      	ldr	x21, [sp, #0x78]
    d8fc:      	ldp	x2, x24, [sp, #0x50]
    d900:      	str	x21, [sp, #0x48]
    d904:      	b	0xd954 <generic_kprobe_path+0x2b24>
    d908:      	add	x2, x24, #0x10
    d90c:      	mov	w8, #0x4                // =4
    d910:      	add	x9, sp, #0x98
    d914:      	add	x0, sp, #0x98
    d918:      	mov	w1, #0x8                // =8
    d91c:      	blr	x8
    d920:      	ldr	x8, [sp, #0x58]
    d924:      	ldr	x9, [sp, #0x98]
    d928:      	cmp	x8, x9
    d92c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    d930:      	add	x2, x24, #0x18
    d934:      	mov	w8, #0x4                // =4
    d938:      	mov	x0, x22
    d93c:      	mov	w1, #0x8                // =8
    d940:      	blr	x8
    d944:      	ldr	x24, [sp, #0x98]
    d948:      	ldr	x21, [sp, #0x48]
    d94c:      	add	x2, x24, #0x20
    d950:      	stp	x2, x24, [sp, #0x50]
    d954:      	ldr	x8, [sp, #0x30]
    d958:      	cmp	x21, x8
    d95c:      	b.ne	0xd96c <generic_kprobe_path+0x2b3c>
    d960:      	ldr	x8, [sp, #0x38]
    d964:      	cmp	x2, x8
    d968:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    d96c:      	mov	w8, #0x4                // =4
    d970:      	add	x0, sp, #0x70
    d974:      	mov	w1, #0x8                // =8
    d978:      	blr	x8
    d97c:      	ldr	x8, [sp, #0x70]
    d980:      	cmp	x21, x8
    d984:      	b.eq	0xda74 <generic_kprobe_path+0x2c44>
    d988:      	add	x23, x21, #0x18
    d98c:      	mov	w8, #0x4                // =4
    d990:      	add	x9, sp, #0x98
    d994:      	add	x0, sp, #0x98
    d998:      	mov	w1, #0x8                // =8
    d99c:      	mov	x2, x23
    d9a0:      	blr	x8
    d9a4:      	ldr	x8, [sp, #0x98]
    d9a8:      	cmp	x8, x21
    d9ac:      	b.eq	0xda74 <generic_kprobe_path+0x2c44>
    d9b0:      	mov	w8, #0x4                // =4
    d9b4:      	add	x9, sp, #0x78
    d9b8:      	add	x0, sp, #0x78
    d9bc:      	mov	w1, #0x8                // =8
    d9c0:      	mov	x2, x23
    d9c4:      	blr	x8
    d9c8:      	add	x2, x21, #0x20
    d9cc:      	mov	w8, #0x4                // =4
    d9d0:      	mov	w9, #0x10               // =16
    d9d4:      	add	x10, sp, #0x80
    d9d8:      	add	x0, sp, #0x80
    d9dc:      	mov	w1, #0x10               // =16
    d9e0:      	blr	x8
    d9e4:      	ldr	w21, [sp, #0x84]
    d9e8:      	ldr	x8, [sp, #0x40]
    d9ec:      	ldr	x10, [sp, #0x60]
    d9f0:      	sub	x12, x10, x8
    d9f4:      	ldr	w23, [sp, #0x68]
    d9f8:      	subs	w10, w21, w23
    d9fc:      	ldr	x9, [sp, #0x88]
    da00:      	csel	w10, wzr, w10, lo
    da04:      	cmp	w23, w21
    da08:      	csel	w11, w23, w21, lo
    da0c:      	cinc	w13, w11, hi
    da10:      	sub	w14, w23, w13
    da14:      	subs	x12, x12, x13
    da18:      	str	w14, [sp, #0x68]
    da1c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    da20:      	cmp	x12, #0xfff
    da24:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    da28:      	cmp	w23, w21
    da2c:      	b.ls	0xda38 <generic_kprobe_path+0x2c08>
    da30:      	mov	w13, #0x2f              // =47
    da34:      	strb	w13, [x8, x12]
    da38:      	add	x19, x8, x12
    da3c:      	cmp	w23, w21
    da40:      	add	x2, x9, x10
    da44:      	and	w1, w11, #0xff
    da48:      	mov	w8, #0x4                // =4
    da4c:      	cinc	x0, x19, hi
    da50:      	blr	x8
    da54:      	cmp	w23, w21
    da58:      	str	x19, [sp, #0x60]
    da5c:      	add	x19, sp, #0x70
    da60:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    da64:      	ldr	x21, [sp, #0x78]
    da68:      	ldp	x2, x24, [sp, #0x50]
    da6c:      	str	x21, [sp, #0x48]
    da70:      	b	0xdac0 <generic_kprobe_path+0x2c90>
    da74:      	add	x2, x24, #0x10
    da78:      	mov	w8, #0x4                // =4
    da7c:      	add	x9, sp, #0x98
    da80:      	add	x0, sp, #0x98
    da84:      	mov	w1, #0x8                // =8
    da88:      	blr	x8
    da8c:      	ldr	x8, [sp, #0x58]
    da90:      	ldr	x9, [sp, #0x98]
    da94:      	cmp	x8, x9
    da98:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    da9c:      	add	x2, x24, #0x18
    daa0:      	mov	w8, #0x4                // =4
    daa4:      	mov	x0, x22
    daa8:      	mov	w1, #0x8                // =8
    daac:      	blr	x8
    dab0:      	ldr	x24, [sp, #0x98]
    dab4:      	ldr	x21, [sp, #0x48]
    dab8:      	add	x2, x24, #0x20
    dabc:      	stp	x2, x24, [sp, #0x50]
    dac0:      	ldr	x8, [sp, #0x30]
    dac4:      	cmp	x21, x8
    dac8:      	b.ne	0xdad8 <generic_kprobe_path+0x2ca8>
    dacc:      	ldr	x8, [sp, #0x38]
    dad0:      	cmp	x2, x8
    dad4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    dad8:      	mov	w8, #0x4                // =4
    dadc:      	add	x0, sp, #0x70
    dae0:      	mov	w1, #0x8                // =8
    dae4:      	blr	x8
    dae8:      	ldr	x8, [sp, #0x70]
    daec:      	cmp	x21, x8
    daf0:      	b.eq	0xdbe0 <generic_kprobe_path+0x2db0>
    daf4:      	add	x23, x21, #0x18
    daf8:      	mov	w8, #0x4                // =4
    dafc:      	add	x9, sp, #0x98
    db00:      	add	x0, sp, #0x98
    db04:      	mov	w1, #0x8                // =8
    db08:      	mov	x2, x23
    db0c:      	blr	x8
    db10:      	ldr	x8, [sp, #0x98]
    db14:      	cmp	x8, x21
    db18:      	b.eq	0xdbe0 <generic_kprobe_path+0x2db0>
    db1c:      	mov	w8, #0x4                // =4
    db20:      	add	x9, sp, #0x78
    db24:      	add	x0, sp, #0x78
    db28:      	mov	w1, #0x8                // =8
    db2c:      	mov	x2, x23
    db30:      	blr	x8
    db34:      	add	x2, x21, #0x20
    db38:      	mov	w8, #0x4                // =4
    db3c:      	mov	w9, #0x10               // =16
    db40:      	add	x10, sp, #0x80
    db44:      	add	x0, sp, #0x80
    db48:      	mov	w1, #0x10               // =16
    db4c:      	blr	x8
    db50:      	ldr	w21, [sp, #0x84]
    db54:      	ldr	x8, [sp, #0x40]
    db58:      	ldr	x10, [sp, #0x60]
    db5c:      	sub	x12, x10, x8
    db60:      	ldr	w23, [sp, #0x68]
    db64:      	subs	w10, w21, w23
    db68:      	ldr	x9, [sp, #0x88]
    db6c:      	csel	w10, wzr, w10, lo
    db70:      	cmp	w23, w21
    db74:      	csel	w11, w23, w21, lo
    db78:      	cinc	w13, w11, hi
    db7c:      	sub	w14, w23, w13
    db80:      	subs	x12, x12, x13
    db84:      	str	w14, [sp, #0x68]
    db88:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    db8c:      	cmp	x12, #0xfff
    db90:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    db94:      	cmp	w23, w21
    db98:      	b.ls	0xdba4 <generic_kprobe_path+0x2d74>
    db9c:      	mov	w13, #0x2f              // =47
    dba0:      	strb	w13, [x8, x12]
    dba4:      	add	x19, x8, x12
    dba8:      	cmp	w23, w21
    dbac:      	add	x2, x9, x10
    dbb0:      	and	w1, w11, #0xff
    dbb4:      	mov	w8, #0x4                // =4
    dbb8:      	cinc	x0, x19, hi
    dbbc:      	blr	x8
    dbc0:      	cmp	w23, w21
    dbc4:      	str	x19, [sp, #0x60]
    dbc8:      	add	x19, sp, #0x70
    dbcc:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    dbd0:      	ldr	x21, [sp, #0x78]
    dbd4:      	ldp	x2, x24, [sp, #0x50]
    dbd8:      	str	x21, [sp, #0x48]
    dbdc:      	b	0xdc2c <generic_kprobe_path+0x2dfc>
    dbe0:      	add	x2, x24, #0x10
    dbe4:      	mov	w8, #0x4                // =4
    dbe8:      	add	x9, sp, #0x98
    dbec:      	add	x0, sp, #0x98
    dbf0:      	mov	w1, #0x8                // =8
    dbf4:      	blr	x8
    dbf8:      	ldr	x8, [sp, #0x58]
    dbfc:      	ldr	x9, [sp, #0x98]
    dc00:      	cmp	x8, x9
    dc04:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    dc08:      	add	x2, x24, #0x18
    dc0c:      	mov	w8, #0x4                // =4
    dc10:      	mov	x0, x22
    dc14:      	mov	w1, #0x8                // =8
    dc18:      	blr	x8
    dc1c:      	ldr	x24, [sp, #0x98]
    dc20:      	ldr	x21, [sp, #0x48]
    dc24:      	add	x2, x24, #0x20
    dc28:      	stp	x2, x24, [sp, #0x50]
    dc2c:      	ldr	x8, [sp, #0x30]
    dc30:      	cmp	x21, x8
    dc34:      	b.ne	0xdc44 <generic_kprobe_path+0x2e14>
    dc38:      	ldr	x8, [sp, #0x38]
    dc3c:      	cmp	x2, x8
    dc40:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    dc44:      	mov	w8, #0x4                // =4
    dc48:      	add	x0, sp, #0x70
    dc4c:      	mov	w1, #0x8                // =8
    dc50:      	blr	x8
    dc54:      	ldr	x8, [sp, #0x70]
    dc58:      	cmp	x21, x8
    dc5c:      	b.eq	0xdd4c <generic_kprobe_path+0x2f1c>
    dc60:      	add	x23, x21, #0x18
    dc64:      	mov	w8, #0x4                // =4
    dc68:      	add	x9, sp, #0x98
    dc6c:      	add	x0, sp, #0x98
    dc70:      	mov	w1, #0x8                // =8
    dc74:      	mov	x2, x23
    dc78:      	blr	x8
    dc7c:      	ldr	x8, [sp, #0x98]
    dc80:      	cmp	x8, x21
    dc84:      	b.eq	0xdd4c <generic_kprobe_path+0x2f1c>
    dc88:      	mov	w8, #0x4                // =4
    dc8c:      	add	x9, sp, #0x78
    dc90:      	add	x0, sp, #0x78
    dc94:      	mov	w1, #0x8                // =8
    dc98:      	mov	x2, x23
    dc9c:      	blr	x8
    dca0:      	add	x2, x21, #0x20
    dca4:      	mov	w8, #0x4                // =4
    dca8:      	mov	w9, #0x10               // =16
    dcac:      	add	x10, sp, #0x80
    dcb0:      	add	x0, sp, #0x80
    dcb4:      	mov	w1, #0x10               // =16
    dcb8:      	blr	x8
    dcbc:      	ldr	w21, [sp, #0x84]
    dcc0:      	ldr	x8, [sp, #0x40]
    dcc4:      	ldr	x10, [sp, #0x60]
    dcc8:      	sub	x12, x10, x8
    dccc:      	ldr	w23, [sp, #0x68]
    dcd0:      	subs	w10, w21, w23
    dcd4:      	ldr	x9, [sp, #0x88]
    dcd8:      	csel	w10, wzr, w10, lo
    dcdc:      	cmp	w23, w21
    dce0:      	csel	w11, w23, w21, lo
    dce4:      	cinc	w13, w11, hi
    dce8:      	sub	w14, w23, w13
    dcec:      	subs	x12, x12, x13
    dcf0:      	str	w14, [sp, #0x68]
    dcf4:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    dcf8:      	cmp	x12, #0xfff
    dcfc:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    dd00:      	cmp	w23, w21
    dd04:      	b.ls	0xdd10 <generic_kprobe_path+0x2ee0>
    dd08:      	mov	w13, #0x2f              // =47
    dd0c:      	strb	w13, [x8, x12]
    dd10:      	add	x19, x8, x12
    dd14:      	cmp	w23, w21
    dd18:      	add	x2, x9, x10
    dd1c:      	and	w1, w11, #0xff
    dd20:      	mov	w8, #0x4                // =4
    dd24:      	cinc	x0, x19, hi
    dd28:      	blr	x8
    dd2c:      	cmp	w23, w21
    dd30:      	str	x19, [sp, #0x60]
    dd34:      	add	x19, sp, #0x70
    dd38:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    dd3c:      	ldr	x21, [sp, #0x78]
    dd40:      	ldp	x2, x24, [sp, #0x50]
    dd44:      	str	x21, [sp, #0x48]
    dd48:      	b	0xdd98 <generic_kprobe_path+0x2f68>
    dd4c:      	add	x2, x24, #0x10
    dd50:      	mov	w8, #0x4                // =4
    dd54:      	add	x9, sp, #0x98
    dd58:      	add	x0, sp, #0x98
    dd5c:      	mov	w1, #0x8                // =8
    dd60:      	blr	x8
    dd64:      	ldr	x8, [sp, #0x58]
    dd68:      	ldr	x9, [sp, #0x98]
    dd6c:      	cmp	x8, x9
    dd70:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    dd74:      	add	x2, x24, #0x18
    dd78:      	mov	w8, #0x4                // =4
    dd7c:      	mov	x0, x22
    dd80:      	mov	w1, #0x8                // =8
    dd84:      	blr	x8
    dd88:      	ldr	x24, [sp, #0x98]
    dd8c:      	ldr	x21, [sp, #0x48]
    dd90:      	add	x2, x24, #0x20
    dd94:      	stp	x2, x24, [sp, #0x50]
    dd98:      	ldr	x8, [sp, #0x30]
    dd9c:      	cmp	x21, x8
    dda0:      	b.ne	0xddb0 <generic_kprobe_path+0x2f80>
    dda4:      	ldr	x8, [sp, #0x38]
    dda8:      	cmp	x2, x8
    ddac:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    ddb0:      	mov	w8, #0x4                // =4
    ddb4:      	add	x0, sp, #0x70
    ddb8:      	mov	w1, #0x8                // =8
    ddbc:      	blr	x8
    ddc0:      	ldr	x8, [sp, #0x70]
    ddc4:      	cmp	x21, x8
    ddc8:      	b.eq	0xdeb8 <generic_kprobe_path+0x3088>
    ddcc:      	add	x23, x21, #0x18
    ddd0:      	mov	w8, #0x4                // =4
    ddd4:      	add	x9, sp, #0x98
    ddd8:      	add	x0, sp, #0x98
    dddc:      	mov	w1, #0x8                // =8
    dde0:      	mov	x2, x23
    dde4:      	blr	x8
    dde8:      	ldr	x8, [sp, #0x98]
    ddec:      	cmp	x8, x21
    ddf0:      	b.eq	0xdeb8 <generic_kprobe_path+0x3088>
    ddf4:      	mov	w8, #0x4                // =4
    ddf8:      	add	x9, sp, #0x78
    ddfc:      	add	x0, sp, #0x78
    de00:      	mov	w1, #0x8                // =8
    de04:      	mov	x2, x23
    de08:      	blr	x8
    de0c:      	add	x2, x21, #0x20
    de10:      	mov	w8, #0x4                // =4
    de14:      	mov	w9, #0x10               // =16
    de18:      	add	x10, sp, #0x80
    de1c:      	add	x0, sp, #0x80
    de20:      	mov	w1, #0x10               // =16
    de24:      	blr	x8
    de28:      	ldr	w21, [sp, #0x84]
    de2c:      	ldr	x8, [sp, #0x40]
    de30:      	ldr	x10, [sp, #0x60]
    de34:      	sub	x12, x10, x8
    de38:      	ldr	w23, [sp, #0x68]
    de3c:      	subs	w10, w21, w23
    de40:      	ldr	x9, [sp, #0x88]
    de44:      	csel	w10, wzr, w10, lo
    de48:      	cmp	w23, w21
    de4c:      	csel	w11, w23, w21, lo
    de50:      	cinc	w13, w11, hi
    de54:      	sub	w14, w23, w13
    de58:      	subs	x12, x12, x13
    de5c:      	str	w14, [sp, #0x68]
    de60:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    de64:      	cmp	x12, #0xfff
    de68:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    de6c:      	cmp	w23, w21
    de70:      	b.ls	0xde7c <generic_kprobe_path+0x304c>
    de74:      	mov	w13, #0x2f              // =47
    de78:      	strb	w13, [x8, x12]
    de7c:      	add	x19, x8, x12
    de80:      	cmp	w23, w21
    de84:      	add	x2, x9, x10
    de88:      	and	w1, w11, #0xff
    de8c:      	mov	w8, #0x4                // =4
    de90:      	cinc	x0, x19, hi
    de94:      	blr	x8
    de98:      	cmp	w23, w21
    de9c:      	str	x19, [sp, #0x60]
    dea0:      	add	x19, sp, #0x70
    dea4:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    dea8:      	ldr	x21, [sp, #0x78]
    deac:      	ldp	x2, x24, [sp, #0x50]
    deb0:      	str	x21, [sp, #0x48]
    deb4:      	b	0xdf04 <generic_kprobe_path+0x30d4>
    deb8:      	add	x2, x24, #0x10
    debc:      	mov	w8, #0x4                // =4
    dec0:      	add	x9, sp, #0x98
    dec4:      	add	x0, sp, #0x98
    dec8:      	mov	w1, #0x8                // =8
    decc:      	blr	x8
    ded0:      	ldr	x8, [sp, #0x58]
    ded4:      	ldr	x9, [sp, #0x98]
    ded8:      	cmp	x8, x9
    dedc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    dee0:      	add	x2, x24, #0x18
    dee4:      	mov	w8, #0x4                // =4
    dee8:      	mov	x0, x22
    deec:      	mov	w1, #0x8                // =8
    def0:      	blr	x8
    def4:      	ldr	x24, [sp, #0x98]
    def8:      	ldr	x21, [sp, #0x48]
    defc:      	add	x2, x24, #0x20
    df00:      	stp	x2, x24, [sp, #0x50]
    df04:      	ldr	x8, [sp, #0x30]
    df08:      	cmp	x21, x8
    df0c:      	b.ne	0xdf1c <generic_kprobe_path+0x30ec>
    df10:      	ldr	x8, [sp, #0x38]
    df14:      	cmp	x2, x8
    df18:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    df1c:      	mov	w8, #0x4                // =4
    df20:      	add	x0, sp, #0x70
    df24:      	mov	w1, #0x8                // =8
    df28:      	blr	x8
    df2c:      	ldr	x8, [sp, #0x70]
    df30:      	cmp	x21, x8
    df34:      	b.eq	0xe024 <generic_kprobe_path+0x31f4>
    df38:      	add	x23, x21, #0x18
    df3c:      	mov	w8, #0x4                // =4
    df40:      	add	x9, sp, #0x98
    df44:      	add	x0, sp, #0x98
    df48:      	mov	w1, #0x8                // =8
    df4c:      	mov	x2, x23
    df50:      	blr	x8
    df54:      	ldr	x8, [sp, #0x98]
    df58:      	cmp	x8, x21
    df5c:      	b.eq	0xe024 <generic_kprobe_path+0x31f4>
    df60:      	mov	w8, #0x4                // =4
    df64:      	add	x9, sp, #0x78
    df68:      	add	x0, sp, #0x78
    df6c:      	mov	w1, #0x8                // =8
    df70:      	mov	x2, x23
    df74:      	blr	x8
    df78:      	add	x2, x21, #0x20
    df7c:      	mov	w8, #0x4                // =4
    df80:      	mov	w9, #0x10               // =16
    df84:      	add	x10, sp, #0x80
    df88:      	add	x0, sp, #0x80
    df8c:      	mov	w1, #0x10               // =16
    df90:      	blr	x8
    df94:      	ldr	w21, [sp, #0x84]
    df98:      	ldr	x8, [sp, #0x40]
    df9c:      	ldr	x10, [sp, #0x60]
    dfa0:      	sub	x12, x10, x8
    dfa4:      	ldr	w23, [sp, #0x68]
    dfa8:      	subs	w10, w21, w23
    dfac:      	ldr	x9, [sp, #0x88]
    dfb0:      	csel	w10, wzr, w10, lo
    dfb4:      	cmp	w23, w21
    dfb8:      	csel	w11, w23, w21, lo
    dfbc:      	cinc	w13, w11, hi
    dfc0:      	sub	w14, w23, w13
    dfc4:      	subs	x12, x12, x13
    dfc8:      	str	w14, [sp, #0x68]
    dfcc:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    dfd0:      	cmp	x12, #0xfff
    dfd4:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    dfd8:      	cmp	w23, w21
    dfdc:      	b.ls	0xdfe8 <generic_kprobe_path+0x31b8>
    dfe0:      	mov	w13, #0x2f              // =47
    dfe4:      	strb	w13, [x8, x12]
    dfe8:      	add	x19, x8, x12
    dfec:      	cmp	w23, w21
    dff0:      	add	x2, x9, x10
    dff4:      	and	w1, w11, #0xff
    dff8:      	mov	w8, #0x4                // =4
    dffc:      	cinc	x0, x19, hi
    e000:      	blr	x8
    e004:      	cmp	w23, w21
    e008:      	str	x19, [sp, #0x60]
    e00c:      	add	x19, sp, #0x70
    e010:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    e014:      	ldr	x21, [sp, #0x78]
    e018:      	ldp	x2, x24, [sp, #0x50]
    e01c:      	str	x21, [sp, #0x48]
    e020:      	b	0xe070 <generic_kprobe_path+0x3240>
    e024:      	add	x2, x24, #0x10
    e028:      	mov	w8, #0x4                // =4
    e02c:      	add	x9, sp, #0x98
    e030:      	add	x0, sp, #0x98
    e034:      	mov	w1, #0x8                // =8
    e038:      	blr	x8
    e03c:      	ldr	x8, [sp, #0x58]
    e040:      	ldr	x9, [sp, #0x98]
    e044:      	cmp	x8, x9
    e048:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    e04c:      	add	x2, x24, #0x18
    e050:      	mov	w8, #0x4                // =4
    e054:      	mov	x0, x22
    e058:      	mov	w1, #0x8                // =8
    e05c:      	blr	x8
    e060:      	ldr	x24, [sp, #0x98]
    e064:      	ldr	x21, [sp, #0x48]
    e068:      	add	x2, x24, #0x20
    e06c:      	stp	x2, x24, [sp, #0x50]
    e070:      	ldr	x8, [sp, #0x30]
    e074:      	cmp	x21, x8
    e078:      	b.ne	0xe088 <generic_kprobe_path+0x3258>
    e07c:      	ldr	x8, [sp, #0x38]
    e080:      	cmp	x2, x8
    e084:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    e088:      	mov	w8, #0x4                // =4
    e08c:      	add	x0, sp, #0x70
    e090:      	mov	w1, #0x8                // =8
    e094:      	blr	x8
    e098:      	ldr	x8, [sp, #0x70]
    e09c:      	cmp	x21, x8
    e0a0:      	b.eq	0xe190 <generic_kprobe_path+0x3360>
    e0a4:      	add	x23, x21, #0x18
    e0a8:      	mov	w8, #0x4                // =4
    e0ac:      	add	x9, sp, #0x98
    e0b0:      	add	x0, sp, #0x98
    e0b4:      	mov	w1, #0x8                // =8
    e0b8:      	mov	x2, x23
    e0bc:      	blr	x8
    e0c0:      	ldr	x8, [sp, #0x98]
    e0c4:      	cmp	x8, x21
    e0c8:      	b.eq	0xe190 <generic_kprobe_path+0x3360>
    e0cc:      	mov	w8, #0x4                // =4
    e0d0:      	add	x9, sp, #0x78
    e0d4:      	add	x0, sp, #0x78
    e0d8:      	mov	w1, #0x8                // =8
    e0dc:      	mov	x2, x23
    e0e0:      	blr	x8
    e0e4:      	add	x2, x21, #0x20
    e0e8:      	mov	w8, #0x4                // =4
    e0ec:      	mov	w9, #0x10               // =16
    e0f0:      	add	x10, sp, #0x80
    e0f4:      	add	x0, sp, #0x80
    e0f8:      	mov	w1, #0x10               // =16
    e0fc:      	blr	x8
    e100:      	ldr	w21, [sp, #0x84]
    e104:      	ldr	x8, [sp, #0x40]
    e108:      	ldr	x10, [sp, #0x60]
    e10c:      	sub	x12, x10, x8
    e110:      	ldr	w23, [sp, #0x68]
    e114:      	subs	w10, w21, w23
    e118:      	ldr	x9, [sp, #0x88]
    e11c:      	csel	w10, wzr, w10, lo
    e120:      	cmp	w23, w21
    e124:      	csel	w11, w23, w21, lo
    e128:      	cinc	w13, w11, hi
    e12c:      	sub	w14, w23, w13
    e130:      	subs	x12, x12, x13
    e134:      	str	w14, [sp, #0x68]
    e138:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    e13c:      	cmp	x12, #0xfff
    e140:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    e144:      	cmp	w23, w21
    e148:      	b.ls	0xe154 <generic_kprobe_path+0x3324>
    e14c:      	mov	w13, #0x2f              // =47
    e150:      	strb	w13, [x8, x12]
    e154:      	add	x19, x8, x12
    e158:      	cmp	w23, w21
    e15c:      	add	x2, x9, x10
    e160:      	and	w1, w11, #0xff
    e164:      	mov	w8, #0x4                // =4
    e168:      	cinc	x0, x19, hi
    e16c:      	blr	x8
    e170:      	cmp	w23, w21
    e174:      	str	x19, [sp, #0x60]
    e178:      	add	x19, sp, #0x70
    e17c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    e180:      	ldr	x21, [sp, #0x78]
    e184:      	ldp	x2, x24, [sp, #0x50]
    e188:      	str	x21, [sp, #0x48]
    e18c:      	b	0xe1dc <generic_kprobe_path+0x33ac>
    e190:      	add	x2, x24, #0x10
    e194:      	mov	w8, #0x4                // =4
    e198:      	add	x9, sp, #0x98
    e19c:      	add	x0, sp, #0x98
    e1a0:      	mov	w1, #0x8                // =8
    e1a4:      	blr	x8
    e1a8:      	ldr	x8, [sp, #0x58]
    e1ac:      	ldr	x9, [sp, #0x98]
    e1b0:      	cmp	x8, x9
    e1b4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    e1b8:      	add	x2, x24, #0x18
    e1bc:      	mov	w8, #0x4                // =4
    e1c0:      	mov	x0, x22
    e1c4:      	mov	w1, #0x8                // =8
    e1c8:      	blr	x8
    e1cc:      	ldr	x24, [sp, #0x98]
    e1d0:      	ldr	x21, [sp, #0x48]
    e1d4:      	add	x2, x24, #0x20
    e1d8:      	stp	x2, x24, [sp, #0x50]
    e1dc:      	ldr	x8, [sp, #0x30]
    e1e0:      	cmp	x21, x8
    e1e4:      	b.ne	0xe1f4 <generic_kprobe_path+0x33c4>
    e1e8:      	ldr	x8, [sp, #0x38]
    e1ec:      	cmp	x2, x8
    e1f0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    e1f4:      	mov	w8, #0x4                // =4
    e1f8:      	add	x0, sp, #0x70
    e1fc:      	mov	w1, #0x8                // =8
    e200:      	blr	x8
    e204:      	ldr	x8, [sp, #0x70]
    e208:      	cmp	x21, x8
    e20c:      	b.eq	0xe2fc <generic_kprobe_path+0x34cc>
    e210:      	add	x23, x21, #0x18
    e214:      	mov	w8, #0x4                // =4
    e218:      	add	x9, sp, #0x98
    e21c:      	add	x0, sp, #0x98
    e220:      	mov	w1, #0x8                // =8
    e224:      	mov	x2, x23
    e228:      	blr	x8
    e22c:      	ldr	x8, [sp, #0x98]
    e230:      	cmp	x8, x21
    e234:      	b.eq	0xe2fc <generic_kprobe_path+0x34cc>
    e238:      	mov	w8, #0x4                // =4
    e23c:      	add	x9, sp, #0x78
    e240:      	add	x0, sp, #0x78
    e244:      	mov	w1, #0x8                // =8
    e248:      	mov	x2, x23
    e24c:      	blr	x8
    e250:      	add	x2, x21, #0x20
    e254:      	mov	w8, #0x4                // =4
    e258:      	mov	w9, #0x10               // =16
    e25c:      	add	x10, sp, #0x80
    e260:      	add	x0, sp, #0x80
    e264:      	mov	w1, #0x10               // =16
    e268:      	blr	x8
    e26c:      	ldr	w21, [sp, #0x84]
    e270:      	ldr	x8, [sp, #0x40]
    e274:      	ldr	x10, [sp, #0x60]
    e278:      	sub	x12, x10, x8
    e27c:      	ldr	w23, [sp, #0x68]
    e280:      	subs	w10, w21, w23
    e284:      	ldr	x9, [sp, #0x88]
    e288:      	csel	w10, wzr, w10, lo
    e28c:      	cmp	w23, w21
    e290:      	csel	w11, w23, w21, lo
    e294:      	cinc	w13, w11, hi
    e298:      	sub	w14, w23, w13
    e29c:      	subs	x12, x12, x13
    e2a0:      	str	w14, [sp, #0x68]
    e2a4:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    e2a8:      	cmp	x12, #0xfff
    e2ac:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    e2b0:      	cmp	w23, w21
    e2b4:      	b.ls	0xe2c0 <generic_kprobe_path+0x3490>
    e2b8:      	mov	w13, #0x2f              // =47
    e2bc:      	strb	w13, [x8, x12]
    e2c0:      	add	x19, x8, x12
    e2c4:      	cmp	w23, w21
    e2c8:      	add	x2, x9, x10
    e2cc:      	and	w1, w11, #0xff
    e2d0:      	mov	w8, #0x4                // =4
    e2d4:      	cinc	x0, x19, hi
    e2d8:      	blr	x8
    e2dc:      	cmp	w23, w21
    e2e0:      	str	x19, [sp, #0x60]
    e2e4:      	add	x19, sp, #0x70
    e2e8:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    e2ec:      	ldr	x21, [sp, #0x78]
    e2f0:      	ldp	x2, x24, [sp, #0x50]
    e2f4:      	str	x21, [sp, #0x48]
    e2f8:      	b	0xe348 <generic_kprobe_path+0x3518>
    e2fc:      	add	x2, x24, #0x10
    e300:      	mov	w8, #0x4                // =4
    e304:      	add	x9, sp, #0x98
    e308:      	add	x0, sp, #0x98
    e30c:      	mov	w1, #0x8                // =8
    e310:      	blr	x8
    e314:      	ldr	x8, [sp, #0x58]
    e318:      	ldr	x9, [sp, #0x98]
    e31c:      	cmp	x8, x9
    e320:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    e324:      	add	x2, x24, #0x18
    e328:      	mov	w8, #0x4                // =4
    e32c:      	mov	x0, x22
    e330:      	mov	w1, #0x8                // =8
    e334:      	blr	x8
    e338:      	ldr	x24, [sp, #0x98]
    e33c:      	ldr	x21, [sp, #0x48]
    e340:      	add	x2, x24, #0x20
    e344:      	stp	x2, x24, [sp, #0x50]
    e348:      	ldr	x8, [sp, #0x30]
    e34c:      	cmp	x21, x8
    e350:      	b.ne	0xe360 <generic_kprobe_path+0x3530>
    e354:      	ldr	x8, [sp, #0x38]
    e358:      	cmp	x2, x8
    e35c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    e360:      	mov	w8, #0x4                // =4
    e364:      	add	x0, sp, #0x70
    e368:      	mov	w1, #0x8                // =8
    e36c:      	blr	x8
    e370:      	ldr	x8, [sp, #0x70]
    e374:      	cmp	x21, x8
    e378:      	b.eq	0xe468 <generic_kprobe_path+0x3638>
    e37c:      	add	x23, x21, #0x18
    e380:      	mov	w8, #0x4                // =4
    e384:      	add	x9, sp, #0x98
    e388:      	add	x0, sp, #0x98
    e38c:      	mov	w1, #0x8                // =8
    e390:      	mov	x2, x23
    e394:      	blr	x8
    e398:      	ldr	x8, [sp, #0x98]
    e39c:      	cmp	x8, x21
    e3a0:      	b.eq	0xe468 <generic_kprobe_path+0x3638>
    e3a4:      	mov	w8, #0x4                // =4
    e3a8:      	add	x9, sp, #0x78
    e3ac:      	add	x0, sp, #0x78
    e3b0:      	mov	w1, #0x8                // =8
    e3b4:      	mov	x2, x23
    e3b8:      	blr	x8
    e3bc:      	add	x2, x21, #0x20
    e3c0:      	mov	w8, #0x4                // =4
    e3c4:      	mov	w9, #0x10               // =16
    e3c8:      	add	x10, sp, #0x80
    e3cc:      	add	x0, sp, #0x80
    e3d0:      	mov	w1, #0x10               // =16
    e3d4:      	blr	x8
    e3d8:      	ldr	w21, [sp, #0x84]
    e3dc:      	ldr	x8, [sp, #0x40]
    e3e0:      	ldr	x10, [sp, #0x60]
    e3e4:      	sub	x12, x10, x8
    e3e8:      	ldr	w23, [sp, #0x68]
    e3ec:      	subs	w10, w21, w23
    e3f0:      	ldr	x9, [sp, #0x88]
    e3f4:      	csel	w10, wzr, w10, lo
    e3f8:      	cmp	w23, w21
    e3fc:      	csel	w11, w23, w21, lo
    e400:      	cinc	w13, w11, hi
    e404:      	sub	w14, w23, w13
    e408:      	subs	x12, x12, x13
    e40c:      	str	w14, [sp, #0x68]
    e410:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    e414:      	cmp	x12, #0xfff
    e418:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    e41c:      	cmp	w23, w21
    e420:      	b.ls	0xe42c <generic_kprobe_path+0x35fc>
    e424:      	mov	w13, #0x2f              // =47
    e428:      	strb	w13, [x8, x12]
    e42c:      	add	x19, x8, x12
    e430:      	cmp	w23, w21
    e434:      	add	x2, x9, x10
    e438:      	and	w1, w11, #0xff
    e43c:      	mov	w8, #0x4                // =4
    e440:      	cinc	x0, x19, hi
    e444:      	blr	x8
    e448:      	cmp	w23, w21
    e44c:      	str	x19, [sp, #0x60]
    e450:      	add	x19, sp, #0x70
    e454:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    e458:      	ldr	x21, [sp, #0x78]
    e45c:      	ldp	x2, x24, [sp, #0x50]
    e460:      	str	x21, [sp, #0x48]
    e464:      	b	0xe4b4 <generic_kprobe_path+0x3684>
    e468:      	add	x2, x24, #0x10
    e46c:      	mov	w8, #0x4                // =4
    e470:      	add	x9, sp, #0x98
    e474:      	add	x0, sp, #0x98
    e478:      	mov	w1, #0x8                // =8
    e47c:      	blr	x8
    e480:      	ldr	x8, [sp, #0x58]
    e484:      	ldr	x9, [sp, #0x98]
    e488:      	cmp	x8, x9
    e48c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    e490:      	add	x2, x24, #0x18
    e494:      	mov	w8, #0x4                // =4
    e498:      	mov	x0, x22
    e49c:      	mov	w1, #0x8                // =8
    e4a0:      	blr	x8
    e4a4:      	ldr	x24, [sp, #0x98]
    e4a8:      	ldr	x21, [sp, #0x48]
    e4ac:      	add	x2, x24, #0x20
    e4b0:      	stp	x2, x24, [sp, #0x50]
    e4b4:      	ldr	x8, [sp, #0x30]
    e4b8:      	cmp	x21, x8
    e4bc:      	b.ne	0xe4cc <generic_kprobe_path+0x369c>
    e4c0:      	ldr	x8, [sp, #0x38]
    e4c4:      	cmp	x2, x8
    e4c8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    e4cc:      	mov	w8, #0x4                // =4
    e4d0:      	add	x0, sp, #0x70
    e4d4:      	mov	w1, #0x8                // =8
    e4d8:      	blr	x8
    e4dc:      	ldr	x8, [sp, #0x70]
    e4e0:      	cmp	x21, x8
    e4e4:      	b.eq	0xe5d4 <generic_kprobe_path+0x37a4>
    e4e8:      	add	x23, x21, #0x18
    e4ec:      	mov	w8, #0x4                // =4
    e4f0:      	add	x9, sp, #0x98
    e4f4:      	add	x0, sp, #0x98
    e4f8:      	mov	w1, #0x8                // =8
    e4fc:      	mov	x2, x23
    e500:      	blr	x8
    e504:      	ldr	x8, [sp, #0x98]
    e508:      	cmp	x8, x21
    e50c:      	b.eq	0xe5d4 <generic_kprobe_path+0x37a4>
    e510:      	mov	w8, #0x4                // =4
    e514:      	add	x9, sp, #0x78
    e518:      	add	x0, sp, #0x78
    e51c:      	mov	w1, #0x8                // =8
    e520:      	mov	x2, x23
    e524:      	blr	x8
    e528:      	add	x2, x21, #0x20
    e52c:      	mov	w8, #0x4                // =4
    e530:      	mov	w9, #0x10               // =16
    e534:      	add	x10, sp, #0x80
    e538:      	add	x0, sp, #0x80
    e53c:      	mov	w1, #0x10               // =16
    e540:      	blr	x8
    e544:      	ldr	w21, [sp, #0x84]
    e548:      	ldr	x8, [sp, #0x40]
    e54c:      	ldr	x10, [sp, #0x60]
    e550:      	sub	x12, x10, x8
    e554:      	ldr	w23, [sp, #0x68]
    e558:      	subs	w10, w21, w23
    e55c:      	ldr	x9, [sp, #0x88]
    e560:      	csel	w10, wzr, w10, lo
    e564:      	cmp	w23, w21
    e568:      	csel	w11, w23, w21, lo
    e56c:      	cinc	w13, w11, hi
    e570:      	sub	w14, w23, w13
    e574:      	subs	x12, x12, x13
    e578:      	str	w14, [sp, #0x68]
    e57c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    e580:      	cmp	x12, #0xfff
    e584:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    e588:      	cmp	w23, w21
    e58c:      	b.ls	0xe598 <generic_kprobe_path+0x3768>
    e590:      	mov	w13, #0x2f              // =47
    e594:      	strb	w13, [x8, x12]
    e598:      	add	x19, x8, x12
    e59c:      	cmp	w23, w21
    e5a0:      	add	x2, x9, x10
    e5a4:      	and	w1, w11, #0xff
    e5a8:      	mov	w8, #0x4                // =4
    e5ac:      	cinc	x0, x19, hi
    e5b0:      	blr	x8
    e5b4:      	cmp	w23, w21
    e5b8:      	str	x19, [sp, #0x60]
    e5bc:      	add	x19, sp, #0x70
    e5c0:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    e5c4:      	ldr	x21, [sp, #0x78]
    e5c8:      	ldp	x2, x24, [sp, #0x50]
    e5cc:      	str	x21, [sp, #0x48]
    e5d0:      	b	0xe620 <generic_kprobe_path+0x37f0>
    e5d4:      	add	x2, x24, #0x10
    e5d8:      	mov	w8, #0x4                // =4
    e5dc:      	add	x9, sp, #0x98
    e5e0:      	add	x0, sp, #0x98
    e5e4:      	mov	w1, #0x8                // =8
    e5e8:      	blr	x8
    e5ec:      	ldr	x8, [sp, #0x58]
    e5f0:      	ldr	x9, [sp, #0x98]
    e5f4:      	cmp	x8, x9
    e5f8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    e5fc:      	add	x2, x24, #0x18
    e600:      	mov	w8, #0x4                // =4
    e604:      	mov	x0, x22
    e608:      	mov	w1, #0x8                // =8
    e60c:      	blr	x8
    e610:      	ldr	x24, [sp, #0x98]
    e614:      	ldr	x21, [sp, #0x48]
    e618:      	add	x2, x24, #0x20
    e61c:      	stp	x2, x24, [sp, #0x50]
    e620:      	ldr	x8, [sp, #0x30]
    e624:      	cmp	x21, x8
    e628:      	b.ne	0xe638 <generic_kprobe_path+0x3808>
    e62c:      	ldr	x8, [sp, #0x38]
    e630:      	cmp	x2, x8
    e634:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    e638:      	mov	w8, #0x4                // =4
    e63c:      	add	x0, sp, #0x70
    e640:      	mov	w1, #0x8                // =8
    e644:      	blr	x8
    e648:      	ldr	x8, [sp, #0x70]
    e64c:      	cmp	x21, x8
    e650:      	b.eq	0xe740 <generic_kprobe_path+0x3910>
    e654:      	add	x23, x21, #0x18
    e658:      	mov	w8, #0x4                // =4
    e65c:      	add	x9, sp, #0x98
    e660:      	add	x0, sp, #0x98
    e664:      	mov	w1, #0x8                // =8
    e668:      	mov	x2, x23
    e66c:      	blr	x8
    e670:      	ldr	x8, [sp, #0x98]
    e674:      	cmp	x8, x21
    e678:      	b.eq	0xe740 <generic_kprobe_path+0x3910>
    e67c:      	mov	w8, #0x4                // =4
    e680:      	add	x9, sp, #0x78
    e684:      	add	x0, sp, #0x78
    e688:      	mov	w1, #0x8                // =8
    e68c:      	mov	x2, x23
    e690:      	blr	x8
    e694:      	add	x2, x21, #0x20
    e698:      	mov	w8, #0x4                // =4
    e69c:      	mov	w9, #0x10               // =16
    e6a0:      	add	x10, sp, #0x80
    e6a4:      	add	x0, sp, #0x80
    e6a8:      	mov	w1, #0x10               // =16
    e6ac:      	blr	x8
    e6b0:      	ldr	w21, [sp, #0x84]
    e6b4:      	ldr	x8, [sp, #0x40]
    e6b8:      	ldr	x10, [sp, #0x60]
    e6bc:      	sub	x12, x10, x8
    e6c0:      	ldr	w23, [sp, #0x68]
    e6c4:      	subs	w10, w21, w23
    e6c8:      	ldr	x9, [sp, #0x88]
    e6cc:      	csel	w10, wzr, w10, lo
    e6d0:      	cmp	w23, w21
    e6d4:      	csel	w11, w23, w21, lo
    e6d8:      	cinc	w13, w11, hi
    e6dc:      	sub	w14, w23, w13
    e6e0:      	subs	x12, x12, x13
    e6e4:      	str	w14, [sp, #0x68]
    e6e8:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    e6ec:      	cmp	x12, #0xfff
    e6f0:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    e6f4:      	cmp	w23, w21
    e6f8:      	b.ls	0xe704 <generic_kprobe_path+0x38d4>
    e6fc:      	mov	w13, #0x2f              // =47
    e700:      	strb	w13, [x8, x12]
    e704:      	add	x19, x8, x12
    e708:      	cmp	w23, w21
    e70c:      	add	x2, x9, x10
    e710:      	and	w1, w11, #0xff
    e714:      	mov	w8, #0x4                // =4
    e718:      	cinc	x0, x19, hi
    e71c:      	blr	x8
    e720:      	cmp	w23, w21
    e724:      	str	x19, [sp, #0x60]
    e728:      	add	x19, sp, #0x70
    e72c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    e730:      	ldr	x21, [sp, #0x78]
    e734:      	ldp	x2, x24, [sp, #0x50]
    e738:      	str	x21, [sp, #0x48]
    e73c:      	b	0xe78c <generic_kprobe_path+0x395c>
    e740:      	add	x2, x24, #0x10
    e744:      	mov	w8, #0x4                // =4
    e748:      	add	x9, sp, #0x98
    e74c:      	add	x0, sp, #0x98
    e750:      	mov	w1, #0x8                // =8
    e754:      	blr	x8
    e758:      	ldr	x8, [sp, #0x58]
    e75c:      	ldr	x9, [sp, #0x98]
    e760:      	cmp	x8, x9
    e764:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    e768:      	add	x2, x24, #0x18
    e76c:      	mov	w8, #0x4                // =4
    e770:      	mov	x0, x22
    e774:      	mov	w1, #0x8                // =8
    e778:      	blr	x8
    e77c:      	ldr	x24, [sp, #0x98]
    e780:      	ldr	x21, [sp, #0x48]
    e784:      	add	x2, x24, #0x20
    e788:      	stp	x2, x24, [sp, #0x50]
    e78c:      	ldr	x8, [sp, #0x30]
    e790:      	cmp	x21, x8
    e794:      	b.ne	0xe7a4 <generic_kprobe_path+0x3974>
    e798:      	ldr	x8, [sp, #0x38]
    e79c:      	cmp	x2, x8
    e7a0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    e7a4:      	mov	w8, #0x4                // =4
    e7a8:      	add	x0, sp, #0x70
    e7ac:      	mov	w1, #0x8                // =8
    e7b0:      	blr	x8
    e7b4:      	ldr	x8, [sp, #0x70]
    e7b8:      	cmp	x21, x8
    e7bc:      	b.eq	0xe8ac <generic_kprobe_path+0x3a7c>
    e7c0:      	add	x23, x21, #0x18
    e7c4:      	mov	w8, #0x4                // =4
    e7c8:      	add	x9, sp, #0x98
    e7cc:      	add	x0, sp, #0x98
    e7d0:      	mov	w1, #0x8                // =8
    e7d4:      	mov	x2, x23
    e7d8:      	blr	x8
    e7dc:      	ldr	x8, [sp, #0x98]
    e7e0:      	cmp	x8, x21
    e7e4:      	b.eq	0xe8ac <generic_kprobe_path+0x3a7c>
    e7e8:      	mov	w8, #0x4                // =4
    e7ec:      	add	x9, sp, #0x78
    e7f0:      	add	x0, sp, #0x78
    e7f4:      	mov	w1, #0x8                // =8
    e7f8:      	mov	x2, x23
    e7fc:      	blr	x8
    e800:      	add	x2, x21, #0x20
    e804:      	mov	w8, #0x4                // =4
    e808:      	mov	w9, #0x10               // =16
    e80c:      	add	x10, sp, #0x80
    e810:      	add	x0, sp, #0x80
    e814:      	mov	w1, #0x10               // =16
    e818:      	blr	x8
    e81c:      	ldr	w21, [sp, #0x84]
    e820:      	ldr	x8, [sp, #0x40]
    e824:      	ldr	x10, [sp, #0x60]
    e828:      	sub	x12, x10, x8
    e82c:      	ldr	w23, [sp, #0x68]
    e830:      	subs	w10, w21, w23
    e834:      	ldr	x9, [sp, #0x88]
    e838:      	csel	w10, wzr, w10, lo
    e83c:      	cmp	w23, w21
    e840:      	csel	w11, w23, w21, lo
    e844:      	cinc	w13, w11, hi
    e848:      	sub	w14, w23, w13
    e84c:      	subs	x12, x12, x13
    e850:      	str	w14, [sp, #0x68]
    e854:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    e858:      	cmp	x12, #0xfff
    e85c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    e860:      	cmp	w23, w21
    e864:      	b.ls	0xe870 <generic_kprobe_path+0x3a40>
    e868:      	mov	w13, #0x2f              // =47
    e86c:      	strb	w13, [x8, x12]
    e870:      	add	x19, x8, x12
    e874:      	cmp	w23, w21
    e878:      	add	x2, x9, x10
    e87c:      	and	w1, w11, #0xff
    e880:      	mov	w8, #0x4                // =4
    e884:      	cinc	x0, x19, hi
    e888:      	blr	x8
    e88c:      	cmp	w23, w21
    e890:      	str	x19, [sp, #0x60]
    e894:      	add	x19, sp, #0x70
    e898:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    e89c:      	ldr	x21, [sp, #0x78]
    e8a0:      	ldp	x2, x24, [sp, #0x50]
    e8a4:      	str	x21, [sp, #0x48]
    e8a8:      	b	0xe8f8 <generic_kprobe_path+0x3ac8>
    e8ac:      	add	x2, x24, #0x10
    e8b0:      	mov	w8, #0x4                // =4
    e8b4:      	add	x9, sp, #0x98
    e8b8:      	add	x0, sp, #0x98
    e8bc:      	mov	w1, #0x8                // =8
    e8c0:      	blr	x8
    e8c4:      	ldr	x8, [sp, #0x58]
    e8c8:      	ldr	x9, [sp, #0x98]
    e8cc:      	cmp	x8, x9
    e8d0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    e8d4:      	add	x2, x24, #0x18
    e8d8:      	mov	w8, #0x4                // =4
    e8dc:      	mov	x0, x22
    e8e0:      	mov	w1, #0x8                // =8
    e8e4:      	blr	x8
    e8e8:      	ldr	x24, [sp, #0x98]
    e8ec:      	ldr	x21, [sp, #0x48]
    e8f0:      	add	x2, x24, #0x20
    e8f4:      	stp	x2, x24, [sp, #0x50]
    e8f8:      	ldr	x8, [sp, #0x30]
    e8fc:      	cmp	x21, x8
    e900:      	b.ne	0xe910 <generic_kprobe_path+0x3ae0>
    e904:      	ldr	x8, [sp, #0x38]
    e908:      	cmp	x2, x8
    e90c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    e910:      	mov	w8, #0x4                // =4
    e914:      	add	x0, sp, #0x70
    e918:      	mov	w1, #0x8                // =8
    e91c:      	blr	x8
    e920:      	ldr	x8, [sp, #0x70]
    e924:      	cmp	x21, x8
    e928:      	b.eq	0xea18 <generic_kprobe_path+0x3be8>
    e92c:      	add	x23, x21, #0x18
    e930:      	mov	w8, #0x4                // =4
    e934:      	add	x9, sp, #0x98
    e938:      	add	x0, sp, #0x98
    e93c:      	mov	w1, #0x8                // =8
    e940:      	mov	x2, x23
    e944:      	blr	x8
    e948:      	ldr	x8, [sp, #0x98]
    e94c:      	cmp	x8, x21
    e950:      	b.eq	0xea18 <generic_kprobe_path+0x3be8>
    e954:      	mov	w8, #0x4                // =4
    e958:      	add	x9, sp, #0x78
    e95c:      	add	x0, sp, #0x78
    e960:      	mov	w1, #0x8                // =8
    e964:      	mov	x2, x23
    e968:      	blr	x8
    e96c:      	add	x2, x21, #0x20
    e970:      	mov	w8, #0x4                // =4
    e974:      	mov	w9, #0x10               // =16
    e978:      	add	x10, sp, #0x80
    e97c:      	add	x0, sp, #0x80
    e980:      	mov	w1, #0x10               // =16
    e984:      	blr	x8
    e988:      	ldr	w21, [sp, #0x84]
    e98c:      	ldr	x8, [sp, #0x40]
    e990:      	ldr	x10, [sp, #0x60]
    e994:      	sub	x12, x10, x8
    e998:      	ldr	w23, [sp, #0x68]
    e99c:      	subs	w10, w21, w23
    e9a0:      	ldr	x9, [sp, #0x88]
    e9a4:      	csel	w10, wzr, w10, lo
    e9a8:      	cmp	w23, w21
    e9ac:      	csel	w11, w23, w21, lo
    e9b0:      	cinc	w13, w11, hi
    e9b4:      	sub	w14, w23, w13
    e9b8:      	subs	x12, x12, x13
    e9bc:      	str	w14, [sp, #0x68]
    e9c0:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    e9c4:      	cmp	x12, #0xfff
    e9c8:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    e9cc:      	cmp	w23, w21
    e9d0:      	b.ls	0xe9dc <generic_kprobe_path+0x3bac>
    e9d4:      	mov	w13, #0x2f              // =47
    e9d8:      	strb	w13, [x8, x12]
    e9dc:      	add	x19, x8, x12
    e9e0:      	cmp	w23, w21
    e9e4:      	add	x2, x9, x10
    e9e8:      	and	w1, w11, #0xff
    e9ec:      	mov	w8, #0x4                // =4
    e9f0:      	cinc	x0, x19, hi
    e9f4:      	blr	x8
    e9f8:      	cmp	w23, w21
    e9fc:      	str	x19, [sp, #0x60]
    ea00:      	add	x19, sp, #0x70
    ea04:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    ea08:      	ldr	x21, [sp, #0x78]
    ea0c:      	ldp	x2, x24, [sp, #0x50]
    ea10:      	str	x21, [sp, #0x48]
    ea14:      	b	0xea64 <generic_kprobe_path+0x3c34>
    ea18:      	add	x2, x24, #0x10
    ea1c:      	mov	w8, #0x4                // =4
    ea20:      	add	x9, sp, #0x98
    ea24:      	add	x0, sp, #0x98
    ea28:      	mov	w1, #0x8                // =8
    ea2c:      	blr	x8
    ea30:      	ldr	x8, [sp, #0x58]
    ea34:      	ldr	x9, [sp, #0x98]
    ea38:      	cmp	x8, x9
    ea3c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    ea40:      	add	x2, x24, #0x18
    ea44:      	mov	w8, #0x4                // =4
    ea48:      	mov	x0, x22
    ea4c:      	mov	w1, #0x8                // =8
    ea50:      	blr	x8
    ea54:      	ldr	x24, [sp, #0x98]
    ea58:      	ldr	x21, [sp, #0x48]
    ea5c:      	add	x2, x24, #0x20
    ea60:      	stp	x2, x24, [sp, #0x50]
    ea64:      	ldr	x8, [sp, #0x30]
    ea68:      	cmp	x21, x8
    ea6c:      	b.ne	0xea7c <generic_kprobe_path+0x3c4c>
    ea70:      	ldr	x8, [sp, #0x38]
    ea74:      	cmp	x2, x8
    ea78:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    ea7c:      	mov	w8, #0x4                // =4
    ea80:      	add	x0, sp, #0x70
    ea84:      	mov	w1, #0x8                // =8
    ea88:      	blr	x8
    ea8c:      	ldr	x8, [sp, #0x70]
    ea90:      	cmp	x21, x8
    ea94:      	b.eq	0xeb84 <generic_kprobe_path+0x3d54>
    ea98:      	add	x23, x21, #0x18
    ea9c:      	mov	w8, #0x4                // =4
    eaa0:      	add	x9, sp, #0x98
    eaa4:      	add	x0, sp, #0x98
    eaa8:      	mov	w1, #0x8                // =8
    eaac:      	mov	x2, x23
    eab0:      	blr	x8
    eab4:      	ldr	x8, [sp, #0x98]
    eab8:      	cmp	x8, x21
    eabc:      	b.eq	0xeb84 <generic_kprobe_path+0x3d54>
    eac0:      	mov	w8, #0x4                // =4
    eac4:      	add	x9, sp, #0x78
    eac8:      	add	x0, sp, #0x78
    eacc:      	mov	w1, #0x8                // =8
    ead0:      	mov	x2, x23
    ead4:      	blr	x8
    ead8:      	add	x2, x21, #0x20
    eadc:      	mov	w8, #0x4                // =4
    eae0:      	mov	w9, #0x10               // =16
    eae4:      	add	x10, sp, #0x80
    eae8:      	add	x0, sp, #0x80
    eaec:      	mov	w1, #0x10               // =16
    eaf0:      	blr	x8
    eaf4:      	ldr	w21, [sp, #0x84]
    eaf8:      	ldr	x8, [sp, #0x40]
    eafc:      	ldr	x10, [sp, #0x60]
    eb00:      	sub	x12, x10, x8
    eb04:      	ldr	w23, [sp, #0x68]
    eb08:      	subs	w10, w21, w23
    eb0c:      	ldr	x9, [sp, #0x88]
    eb10:      	csel	w10, wzr, w10, lo
    eb14:      	cmp	w23, w21
    eb18:      	csel	w11, w23, w21, lo
    eb1c:      	cinc	w13, w11, hi
    eb20:      	sub	w14, w23, w13
    eb24:      	subs	x12, x12, x13
    eb28:      	str	w14, [sp, #0x68]
    eb2c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    eb30:      	cmp	x12, #0xfff
    eb34:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    eb38:      	cmp	w23, w21
    eb3c:      	b.ls	0xeb48 <generic_kprobe_path+0x3d18>
    eb40:      	mov	w13, #0x2f              // =47
    eb44:      	strb	w13, [x8, x12]
    eb48:      	add	x19, x8, x12
    eb4c:      	cmp	w23, w21
    eb50:      	add	x2, x9, x10
    eb54:      	and	w1, w11, #0xff
    eb58:      	mov	w8, #0x4                // =4
    eb5c:      	cinc	x0, x19, hi
    eb60:      	blr	x8
    eb64:      	cmp	w23, w21
    eb68:      	str	x19, [sp, #0x60]
    eb6c:      	add	x19, sp, #0x70
    eb70:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    eb74:      	ldr	x21, [sp, #0x78]
    eb78:      	ldp	x2, x24, [sp, #0x50]
    eb7c:      	str	x21, [sp, #0x48]
    eb80:      	b	0xebd0 <generic_kprobe_path+0x3da0>
    eb84:      	add	x2, x24, #0x10
    eb88:      	mov	w8, #0x4                // =4
    eb8c:      	add	x9, sp, #0x98
    eb90:      	add	x0, sp, #0x98
    eb94:      	mov	w1, #0x8                // =8
    eb98:      	blr	x8
    eb9c:      	ldr	x8, [sp, #0x58]
    eba0:      	ldr	x9, [sp, #0x98]
    eba4:      	cmp	x8, x9
    eba8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    ebac:      	add	x2, x24, #0x18
    ebb0:      	mov	w8, #0x4                // =4
    ebb4:      	mov	x0, x22
    ebb8:      	mov	w1, #0x8                // =8
    ebbc:      	blr	x8
    ebc0:      	ldr	x24, [sp, #0x98]
    ebc4:      	ldr	x21, [sp, #0x48]
    ebc8:      	add	x2, x24, #0x20
    ebcc:      	stp	x2, x24, [sp, #0x50]
    ebd0:      	ldr	x8, [sp, #0x30]
    ebd4:      	cmp	x21, x8
    ebd8:      	b.ne	0xebe8 <generic_kprobe_path+0x3db8>
    ebdc:      	ldr	x8, [sp, #0x38]
    ebe0:      	cmp	x2, x8
    ebe4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    ebe8:      	mov	w8, #0x4                // =4
    ebec:      	add	x0, sp, #0x70
    ebf0:      	mov	w1, #0x8                // =8
    ebf4:      	blr	x8
    ebf8:      	ldr	x8, [sp, #0x70]
    ebfc:      	cmp	x21, x8
    ec00:      	b.eq	0xecf0 <generic_kprobe_path+0x3ec0>
    ec04:      	add	x23, x21, #0x18
    ec08:      	mov	w8, #0x4                // =4
    ec0c:      	add	x9, sp, #0x98
    ec10:      	add	x0, sp, #0x98
    ec14:      	mov	w1, #0x8                // =8
    ec18:      	mov	x2, x23
    ec1c:      	blr	x8
    ec20:      	ldr	x8, [sp, #0x98]
    ec24:      	cmp	x8, x21
    ec28:      	b.eq	0xecf0 <generic_kprobe_path+0x3ec0>
    ec2c:      	mov	w8, #0x4                // =4
    ec30:      	add	x9, sp, #0x78
    ec34:      	add	x0, sp, #0x78
    ec38:      	mov	w1, #0x8                // =8
    ec3c:      	mov	x2, x23
    ec40:      	blr	x8
    ec44:      	add	x2, x21, #0x20
    ec48:      	mov	w8, #0x4                // =4
    ec4c:      	mov	w9, #0x10               // =16
    ec50:      	add	x10, sp, #0x80
    ec54:      	add	x0, sp, #0x80
    ec58:      	mov	w1, #0x10               // =16
    ec5c:      	blr	x8
    ec60:      	ldr	w21, [sp, #0x84]
    ec64:      	ldr	x8, [sp, #0x40]
    ec68:      	ldr	x10, [sp, #0x60]
    ec6c:      	sub	x12, x10, x8
    ec70:      	ldr	w23, [sp, #0x68]
    ec74:      	subs	w10, w21, w23
    ec78:      	ldr	x9, [sp, #0x88]
    ec7c:      	csel	w10, wzr, w10, lo
    ec80:      	cmp	w23, w21
    ec84:      	csel	w11, w23, w21, lo
    ec88:      	cinc	w13, w11, hi
    ec8c:      	sub	w14, w23, w13
    ec90:      	subs	x12, x12, x13
    ec94:      	str	w14, [sp, #0x68]
    ec98:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    ec9c:      	cmp	x12, #0xfff
    eca0:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    eca4:      	cmp	w23, w21
    eca8:      	b.ls	0xecb4 <generic_kprobe_path+0x3e84>
    ecac:      	mov	w13, #0x2f              // =47
    ecb0:      	strb	w13, [x8, x12]
    ecb4:      	add	x19, x8, x12
    ecb8:      	cmp	w23, w21
    ecbc:      	add	x2, x9, x10
    ecc0:      	and	w1, w11, #0xff
    ecc4:      	mov	w8, #0x4                // =4
    ecc8:      	cinc	x0, x19, hi
    eccc:      	blr	x8
    ecd0:      	cmp	w23, w21
    ecd4:      	str	x19, [sp, #0x60]
    ecd8:      	add	x19, sp, #0x70
    ecdc:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    ece0:      	ldr	x21, [sp, #0x78]
    ece4:      	ldp	x2, x24, [sp, #0x50]
    ece8:      	str	x21, [sp, #0x48]
    ecec:      	b	0xed3c <generic_kprobe_path+0x3f0c>
    ecf0:      	add	x2, x24, #0x10
    ecf4:      	mov	w8, #0x4                // =4
    ecf8:      	add	x9, sp, #0x98
    ecfc:      	add	x0, sp, #0x98
    ed00:      	mov	w1, #0x8                // =8
    ed04:      	blr	x8
    ed08:      	ldr	x8, [sp, #0x58]
    ed0c:      	ldr	x9, [sp, #0x98]
    ed10:      	cmp	x8, x9
    ed14:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    ed18:      	add	x2, x24, #0x18
    ed1c:      	mov	w8, #0x4                // =4
    ed20:      	mov	x0, x22
    ed24:      	mov	w1, #0x8                // =8
    ed28:      	blr	x8
    ed2c:      	ldr	x24, [sp, #0x98]
    ed30:      	ldr	x21, [sp, #0x48]
    ed34:      	add	x2, x24, #0x20
    ed38:      	stp	x2, x24, [sp, #0x50]
    ed3c:      	ldr	x8, [sp, #0x30]
    ed40:      	cmp	x21, x8
    ed44:      	b.ne	0xed54 <generic_kprobe_path+0x3f24>
    ed48:      	ldr	x8, [sp, #0x38]
    ed4c:      	cmp	x2, x8
    ed50:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    ed54:      	mov	w8, #0x4                // =4
    ed58:      	add	x0, sp, #0x70
    ed5c:      	mov	w1, #0x8                // =8
    ed60:      	blr	x8
    ed64:      	ldr	x8, [sp, #0x70]
    ed68:      	cmp	x21, x8
    ed6c:      	b.eq	0xee5c <generic_kprobe_path+0x402c>
    ed70:      	add	x23, x21, #0x18
    ed74:      	mov	w8, #0x4                // =4
    ed78:      	add	x9, sp, #0x98
    ed7c:      	add	x0, sp, #0x98
    ed80:      	mov	w1, #0x8                // =8
    ed84:      	mov	x2, x23
    ed88:      	blr	x8
    ed8c:      	ldr	x8, [sp, #0x98]
    ed90:      	cmp	x8, x21
    ed94:      	b.eq	0xee5c <generic_kprobe_path+0x402c>
    ed98:      	mov	w8, #0x4                // =4
    ed9c:      	add	x9, sp, #0x78
    eda0:      	add	x0, sp, #0x78
    eda4:      	mov	w1, #0x8                // =8
    eda8:      	mov	x2, x23
    edac:      	blr	x8
    edb0:      	add	x2, x21, #0x20
    edb4:      	mov	w8, #0x4                // =4
    edb8:      	mov	w9, #0x10               // =16
    edbc:      	add	x10, sp, #0x80
    edc0:      	add	x0, sp, #0x80
    edc4:      	mov	w1, #0x10               // =16
    edc8:      	blr	x8
    edcc:      	ldr	w21, [sp, #0x84]
    edd0:      	ldr	x8, [sp, #0x40]
    edd4:      	ldr	x10, [sp, #0x60]
    edd8:      	sub	x12, x10, x8
    eddc:      	ldr	w23, [sp, #0x68]
    ede0:      	subs	w10, w21, w23
    ede4:      	ldr	x9, [sp, #0x88]
    ede8:      	csel	w10, wzr, w10, lo
    edec:      	cmp	w23, w21
    edf0:      	csel	w11, w23, w21, lo
    edf4:      	cinc	w13, w11, hi
    edf8:      	sub	w14, w23, w13
    edfc:      	subs	x12, x12, x13
    ee00:      	str	w14, [sp, #0x68]
    ee04:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    ee08:      	cmp	x12, #0xfff
    ee0c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    ee10:      	cmp	w23, w21
    ee14:      	b.ls	0xee20 <generic_kprobe_path+0x3ff0>
    ee18:      	mov	w13, #0x2f              // =47
    ee1c:      	strb	w13, [x8, x12]
    ee20:      	add	x19, x8, x12
    ee24:      	cmp	w23, w21
    ee28:      	add	x2, x9, x10
    ee2c:      	and	w1, w11, #0xff
    ee30:      	mov	w8, #0x4                // =4
    ee34:      	cinc	x0, x19, hi
    ee38:      	blr	x8
    ee3c:      	cmp	w23, w21
    ee40:      	str	x19, [sp, #0x60]
    ee44:      	add	x19, sp, #0x70
    ee48:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    ee4c:      	ldr	x21, [sp, #0x78]
    ee50:      	ldp	x2, x24, [sp, #0x50]
    ee54:      	str	x21, [sp, #0x48]
    ee58:      	b	0xeea8 <generic_kprobe_path+0x4078>
    ee5c:      	add	x2, x24, #0x10
    ee60:      	mov	w8, #0x4                // =4
    ee64:      	add	x9, sp, #0x98
    ee68:      	add	x0, sp, #0x98
    ee6c:      	mov	w1, #0x8                // =8
    ee70:      	blr	x8
    ee74:      	ldr	x8, [sp, #0x58]
    ee78:      	ldr	x9, [sp, #0x98]
    ee7c:      	cmp	x8, x9
    ee80:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    ee84:      	add	x2, x24, #0x18
    ee88:      	mov	w8, #0x4                // =4
    ee8c:      	mov	x0, x22
    ee90:      	mov	w1, #0x8                // =8
    ee94:      	blr	x8
    ee98:      	ldr	x24, [sp, #0x98]
    ee9c:      	ldr	x21, [sp, #0x48]
    eea0:      	add	x2, x24, #0x20
    eea4:      	stp	x2, x24, [sp, #0x50]
    eea8:      	ldr	x8, [sp, #0x30]
    eeac:      	cmp	x21, x8
    eeb0:      	b.ne	0xeec0 <generic_kprobe_path+0x4090>
    eeb4:      	ldr	x8, [sp, #0x38]
    eeb8:      	cmp	x2, x8
    eebc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    eec0:      	mov	w8, #0x4                // =4
    eec4:      	add	x0, sp, #0x70
    eec8:      	mov	w1, #0x8                // =8
    eecc:      	blr	x8
    eed0:      	ldr	x8, [sp, #0x70]
    eed4:      	cmp	x21, x8
    eed8:      	b.eq	0xefc8 <generic_kprobe_path+0x4198>
    eedc:      	add	x23, x21, #0x18
    eee0:      	mov	w8, #0x4                // =4
    eee4:      	add	x9, sp, #0x98
    eee8:      	add	x0, sp, #0x98
    eeec:      	mov	w1, #0x8                // =8
    eef0:      	mov	x2, x23
    eef4:      	blr	x8
    eef8:      	ldr	x8, [sp, #0x98]
    eefc:      	cmp	x8, x21
    ef00:      	b.eq	0xefc8 <generic_kprobe_path+0x4198>
    ef04:      	mov	w8, #0x4                // =4
    ef08:      	add	x9, sp, #0x78
    ef0c:      	add	x0, sp, #0x78
    ef10:      	mov	w1, #0x8                // =8
    ef14:      	mov	x2, x23
    ef18:      	blr	x8
    ef1c:      	add	x2, x21, #0x20
    ef20:      	mov	w8, #0x4                // =4
    ef24:      	mov	w9, #0x10               // =16
    ef28:      	add	x10, sp, #0x80
    ef2c:      	add	x0, sp, #0x80
    ef30:      	mov	w1, #0x10               // =16
    ef34:      	blr	x8
    ef38:      	ldr	w21, [sp, #0x84]
    ef3c:      	ldr	x8, [sp, #0x40]
    ef40:      	ldr	x10, [sp, #0x60]
    ef44:      	sub	x12, x10, x8
    ef48:      	ldr	w23, [sp, #0x68]
    ef4c:      	subs	w10, w21, w23
    ef50:      	ldr	x9, [sp, #0x88]
    ef54:      	csel	w10, wzr, w10, lo
    ef58:      	cmp	w23, w21
    ef5c:      	csel	w11, w23, w21, lo
    ef60:      	cinc	w13, w11, hi
    ef64:      	sub	w14, w23, w13
    ef68:      	subs	x12, x12, x13
    ef6c:      	str	w14, [sp, #0x68]
    ef70:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    ef74:      	cmp	x12, #0xfff
    ef78:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    ef7c:      	cmp	w23, w21
    ef80:      	b.ls	0xef8c <generic_kprobe_path+0x415c>
    ef84:      	mov	w13, #0x2f              // =47
    ef88:      	strb	w13, [x8, x12]
    ef8c:      	add	x19, x8, x12
    ef90:      	cmp	w23, w21
    ef94:      	add	x2, x9, x10
    ef98:      	and	w1, w11, #0xff
    ef9c:      	mov	w8, #0x4                // =4
    efa0:      	cinc	x0, x19, hi
    efa4:      	blr	x8
    efa8:      	cmp	w23, w21
    efac:      	str	x19, [sp, #0x60]
    efb0:      	add	x19, sp, #0x70
    efb4:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    efb8:      	ldr	x21, [sp, #0x78]
    efbc:      	ldp	x2, x24, [sp, #0x50]
    efc0:      	str	x21, [sp, #0x48]
    efc4:      	b	0xf014 <generic_kprobe_path+0x41e4>
    efc8:      	add	x2, x24, #0x10
    efcc:      	mov	w8, #0x4                // =4
    efd0:      	add	x9, sp, #0x98
    efd4:      	add	x0, sp, #0x98
    efd8:      	mov	w1, #0x8                // =8
    efdc:      	blr	x8
    efe0:      	ldr	x8, [sp, #0x58]
    efe4:      	ldr	x9, [sp, #0x98]
    efe8:      	cmp	x8, x9
    efec:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    eff0:      	add	x2, x24, #0x18
    eff4:      	mov	w8, #0x4                // =4
    eff8:      	mov	x0, x22
    effc:      	mov	w1, #0x8                // =8
    f000:      	blr	x8
    f004:      	ldr	x24, [sp, #0x98]
    f008:      	ldr	x21, [sp, #0x48]
    f00c:      	add	x2, x24, #0x20
    f010:      	stp	x2, x24, [sp, #0x50]
    f014:      	ldr	x8, [sp, #0x30]
    f018:      	cmp	x21, x8
    f01c:      	b.ne	0xf02c <generic_kprobe_path+0x41fc>
    f020:      	ldr	x8, [sp, #0x38]
    f024:      	cmp	x2, x8
    f028:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    f02c:      	mov	w8, #0x4                // =4
    f030:      	add	x0, sp, #0x70
    f034:      	mov	w1, #0x8                // =8
    f038:      	blr	x8
    f03c:      	ldr	x8, [sp, #0x70]
    f040:      	cmp	x21, x8
    f044:      	b.eq	0xf134 <generic_kprobe_path+0x4304>
    f048:      	add	x23, x21, #0x18
    f04c:      	mov	w8, #0x4                // =4
    f050:      	add	x9, sp, #0x98
    f054:      	add	x0, sp, #0x98
    f058:      	mov	w1, #0x8                // =8
    f05c:      	mov	x2, x23
    f060:      	blr	x8
    f064:      	ldr	x8, [sp, #0x98]
    f068:      	cmp	x8, x21
    f06c:      	b.eq	0xf134 <generic_kprobe_path+0x4304>
    f070:      	mov	w8, #0x4                // =4
    f074:      	add	x9, sp, #0x78
    f078:      	add	x0, sp, #0x78
    f07c:      	mov	w1, #0x8                // =8
    f080:      	mov	x2, x23
    f084:      	blr	x8
    f088:      	add	x2, x21, #0x20
    f08c:      	mov	w8, #0x4                // =4
    f090:      	mov	w9, #0x10               // =16
    f094:      	add	x10, sp, #0x80
    f098:      	add	x0, sp, #0x80
    f09c:      	mov	w1, #0x10               // =16
    f0a0:      	blr	x8
    f0a4:      	ldr	w21, [sp, #0x84]
    f0a8:      	ldr	x8, [sp, #0x40]
    f0ac:      	ldr	x10, [sp, #0x60]
    f0b0:      	sub	x12, x10, x8
    f0b4:      	ldr	w23, [sp, #0x68]
    f0b8:      	subs	w10, w21, w23
    f0bc:      	ldr	x9, [sp, #0x88]
    f0c0:      	csel	w10, wzr, w10, lo
    f0c4:      	cmp	w23, w21
    f0c8:      	csel	w11, w23, w21, lo
    f0cc:      	cinc	w13, w11, hi
    f0d0:      	sub	w14, w23, w13
    f0d4:      	subs	x12, x12, x13
    f0d8:      	str	w14, [sp, #0x68]
    f0dc:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    f0e0:      	cmp	x12, #0xfff
    f0e4:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    f0e8:      	cmp	w23, w21
    f0ec:      	b.ls	0xf0f8 <generic_kprobe_path+0x42c8>
    f0f0:      	mov	w13, #0x2f              // =47
    f0f4:      	strb	w13, [x8, x12]
    f0f8:      	add	x19, x8, x12
    f0fc:      	cmp	w23, w21
    f100:      	add	x2, x9, x10
    f104:      	and	w1, w11, #0xff
    f108:      	mov	w8, #0x4                // =4
    f10c:      	cinc	x0, x19, hi
    f110:      	blr	x8
    f114:      	cmp	w23, w21
    f118:      	str	x19, [sp, #0x60]
    f11c:      	add	x19, sp, #0x70
    f120:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    f124:      	ldr	x21, [sp, #0x78]
    f128:      	ldp	x2, x24, [sp, #0x50]
    f12c:      	str	x21, [sp, #0x48]
    f130:      	b	0xf180 <generic_kprobe_path+0x4350>
    f134:      	add	x2, x24, #0x10
    f138:      	mov	w8, #0x4                // =4
    f13c:      	add	x9, sp, #0x98
    f140:      	add	x0, sp, #0x98
    f144:      	mov	w1, #0x8                // =8
    f148:      	blr	x8
    f14c:      	ldr	x8, [sp, #0x58]
    f150:      	ldr	x9, [sp, #0x98]
    f154:      	cmp	x8, x9
    f158:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    f15c:      	add	x2, x24, #0x18
    f160:      	mov	w8, #0x4                // =4
    f164:      	mov	x0, x22
    f168:      	mov	w1, #0x8                // =8
    f16c:      	blr	x8
    f170:      	ldr	x24, [sp, #0x98]
    f174:      	ldr	x21, [sp, #0x48]
    f178:      	add	x2, x24, #0x20
    f17c:      	stp	x2, x24, [sp, #0x50]
    f180:      	ldr	x8, [sp, #0x30]
    f184:      	cmp	x21, x8
    f188:      	b.ne	0xf198 <generic_kprobe_path+0x4368>
    f18c:      	ldr	x8, [sp, #0x38]
    f190:      	cmp	x2, x8
    f194:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    f198:      	mov	w8, #0x4                // =4
    f19c:      	add	x0, sp, #0x70
    f1a0:      	mov	w1, #0x8                // =8
    f1a4:      	blr	x8
    f1a8:      	ldr	x8, [sp, #0x70]
    f1ac:      	cmp	x21, x8
    f1b0:      	b.eq	0xf2a0 <generic_kprobe_path+0x4470>
    f1b4:      	add	x23, x21, #0x18
    f1b8:      	mov	w8, #0x4                // =4
    f1bc:      	add	x9, sp, #0x98
    f1c0:      	add	x0, sp, #0x98
    f1c4:      	mov	w1, #0x8                // =8
    f1c8:      	mov	x2, x23
    f1cc:      	blr	x8
    f1d0:      	ldr	x8, [sp, #0x98]
    f1d4:      	cmp	x8, x21
    f1d8:      	b.eq	0xf2a0 <generic_kprobe_path+0x4470>
    f1dc:      	mov	w8, #0x4                // =4
    f1e0:      	add	x9, sp, #0x78
    f1e4:      	add	x0, sp, #0x78
    f1e8:      	mov	w1, #0x8                // =8
    f1ec:      	mov	x2, x23
    f1f0:      	blr	x8
    f1f4:      	add	x2, x21, #0x20
    f1f8:      	mov	w8, #0x4                // =4
    f1fc:      	mov	w9, #0x10               // =16
    f200:      	add	x10, sp, #0x80
    f204:      	add	x0, sp, #0x80
    f208:      	mov	w1, #0x10               // =16
    f20c:      	blr	x8
    f210:      	ldr	w21, [sp, #0x84]
    f214:      	ldr	x8, [sp, #0x40]
    f218:      	ldr	x10, [sp, #0x60]
    f21c:      	sub	x12, x10, x8
    f220:      	ldr	w23, [sp, #0x68]
    f224:      	subs	w10, w21, w23
    f228:      	ldr	x9, [sp, #0x88]
    f22c:      	csel	w10, wzr, w10, lo
    f230:      	cmp	w23, w21
    f234:      	csel	w11, w23, w21, lo
    f238:      	cinc	w13, w11, hi
    f23c:      	sub	w14, w23, w13
    f240:      	subs	x12, x12, x13
    f244:      	str	w14, [sp, #0x68]
    f248:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    f24c:      	cmp	x12, #0xfff
    f250:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    f254:      	cmp	w23, w21
    f258:      	b.ls	0xf264 <generic_kprobe_path+0x4434>
    f25c:      	mov	w13, #0x2f              // =47
    f260:      	strb	w13, [x8, x12]
    f264:      	add	x19, x8, x12
    f268:      	cmp	w23, w21
    f26c:      	add	x2, x9, x10
    f270:      	and	w1, w11, #0xff
    f274:      	mov	w8, #0x4                // =4
    f278:      	cinc	x0, x19, hi
    f27c:      	blr	x8
    f280:      	cmp	w23, w21
    f284:      	str	x19, [sp, #0x60]
    f288:      	add	x19, sp, #0x70
    f28c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    f290:      	ldr	x21, [sp, #0x78]
    f294:      	ldp	x2, x24, [sp, #0x50]
    f298:      	str	x21, [sp, #0x48]
    f29c:      	b	0xf2ec <generic_kprobe_path+0x44bc>
    f2a0:      	add	x2, x24, #0x10
    f2a4:      	mov	w8, #0x4                // =4
    f2a8:      	add	x9, sp, #0x98
    f2ac:      	add	x0, sp, #0x98
    f2b0:      	mov	w1, #0x8                // =8
    f2b4:      	blr	x8
    f2b8:      	ldr	x8, [sp, #0x58]
    f2bc:      	ldr	x9, [sp, #0x98]
    f2c0:      	cmp	x8, x9
    f2c4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    f2c8:      	add	x2, x24, #0x18
    f2cc:      	mov	w8, #0x4                // =4
    f2d0:      	mov	x0, x22
    f2d4:      	mov	w1, #0x8                // =8
    f2d8:      	blr	x8
    f2dc:      	ldr	x24, [sp, #0x98]
    f2e0:      	ldr	x21, [sp, #0x48]
    f2e4:      	add	x2, x24, #0x20
    f2e8:      	stp	x2, x24, [sp, #0x50]
    f2ec:      	ldr	x8, [sp, #0x30]
    f2f0:      	cmp	x21, x8
    f2f4:      	b.ne	0xf304 <generic_kprobe_path+0x44d4>
    f2f8:      	ldr	x8, [sp, #0x38]
    f2fc:      	cmp	x2, x8
    f300:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    f304:      	mov	w8, #0x4                // =4
    f308:      	add	x0, sp, #0x70
    f30c:      	mov	w1, #0x8                // =8
    f310:      	blr	x8
    f314:      	ldr	x8, [sp, #0x70]
    f318:      	cmp	x21, x8
    f31c:      	b.eq	0xf40c <generic_kprobe_path+0x45dc>
    f320:      	add	x23, x21, #0x18
    f324:      	mov	w8, #0x4                // =4
    f328:      	add	x9, sp, #0x98
    f32c:      	add	x0, sp, #0x98
    f330:      	mov	w1, #0x8                // =8
    f334:      	mov	x2, x23
    f338:      	blr	x8
    f33c:      	ldr	x8, [sp, #0x98]
    f340:      	cmp	x8, x21
    f344:      	b.eq	0xf40c <generic_kprobe_path+0x45dc>
    f348:      	mov	w8, #0x4                // =4
    f34c:      	add	x9, sp, #0x78
    f350:      	add	x0, sp, #0x78
    f354:      	mov	w1, #0x8                // =8
    f358:      	mov	x2, x23
    f35c:      	blr	x8
    f360:      	add	x2, x21, #0x20
    f364:      	mov	w8, #0x4                // =4
    f368:      	mov	w9, #0x10               // =16
    f36c:      	add	x10, sp, #0x80
    f370:      	add	x0, sp, #0x80
    f374:      	mov	w1, #0x10               // =16
    f378:      	blr	x8
    f37c:      	ldr	w21, [sp, #0x84]
    f380:      	ldr	x8, [sp, #0x40]
    f384:      	ldr	x10, [sp, #0x60]
    f388:      	sub	x12, x10, x8
    f38c:      	ldr	w23, [sp, #0x68]
    f390:      	subs	w10, w21, w23
    f394:      	ldr	x9, [sp, #0x88]
    f398:      	csel	w10, wzr, w10, lo
    f39c:      	cmp	w23, w21
    f3a0:      	csel	w11, w23, w21, lo
    f3a4:      	cinc	w13, w11, hi
    f3a8:      	sub	w14, w23, w13
    f3ac:      	subs	x12, x12, x13
    f3b0:      	str	w14, [sp, #0x68]
    f3b4:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    f3b8:      	cmp	x12, #0xfff
    f3bc:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    f3c0:      	cmp	w23, w21
    f3c4:      	b.ls	0xf3d0 <generic_kprobe_path+0x45a0>
    f3c8:      	mov	w13, #0x2f              // =47
    f3cc:      	strb	w13, [x8, x12]
    f3d0:      	add	x19, x8, x12
    f3d4:      	cmp	w23, w21
    f3d8:      	add	x2, x9, x10
    f3dc:      	and	w1, w11, #0xff
    f3e0:      	mov	w8, #0x4                // =4
    f3e4:      	cinc	x0, x19, hi
    f3e8:      	blr	x8
    f3ec:      	cmp	w23, w21
    f3f0:      	str	x19, [sp, #0x60]
    f3f4:      	add	x19, sp, #0x70
    f3f8:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    f3fc:      	ldr	x21, [sp, #0x78]
    f400:      	ldp	x2, x24, [sp, #0x50]
    f404:      	str	x21, [sp, #0x48]
    f408:      	b	0xf458 <generic_kprobe_path+0x4628>
    f40c:      	add	x2, x24, #0x10
    f410:      	mov	w8, #0x4                // =4
    f414:      	add	x9, sp, #0x98
    f418:      	add	x0, sp, #0x98
    f41c:      	mov	w1, #0x8                // =8
    f420:      	blr	x8
    f424:      	ldr	x8, [sp, #0x58]
    f428:      	ldr	x9, [sp, #0x98]
    f42c:      	cmp	x8, x9
    f430:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    f434:      	add	x2, x24, #0x18
    f438:      	mov	w8, #0x4                // =4
    f43c:      	mov	x0, x22
    f440:      	mov	w1, #0x8                // =8
    f444:      	blr	x8
    f448:      	ldr	x24, [sp, #0x98]
    f44c:      	ldr	x21, [sp, #0x48]
    f450:      	add	x2, x24, #0x20
    f454:      	stp	x2, x24, [sp, #0x50]
    f458:      	ldr	x8, [sp, #0x30]
    f45c:      	cmp	x21, x8
    f460:      	b.ne	0xf470 <generic_kprobe_path+0x4640>
    f464:      	ldr	x8, [sp, #0x38]
    f468:      	cmp	x2, x8
    f46c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    f470:      	mov	w8, #0x4                // =4
    f474:      	add	x0, sp, #0x70
    f478:      	mov	w1, #0x8                // =8
    f47c:      	blr	x8
    f480:      	ldr	x8, [sp, #0x70]
    f484:      	cmp	x21, x8
    f488:      	b.eq	0xf578 <generic_kprobe_path+0x4748>
    f48c:      	add	x23, x21, #0x18
    f490:      	mov	w8, #0x4                // =4
    f494:      	add	x9, sp, #0x98
    f498:      	add	x0, sp, #0x98
    f49c:      	mov	w1, #0x8                // =8
    f4a0:      	mov	x2, x23
    f4a4:      	blr	x8
    f4a8:      	ldr	x8, [sp, #0x98]
    f4ac:      	cmp	x8, x21
    f4b0:      	b.eq	0xf578 <generic_kprobe_path+0x4748>
    f4b4:      	mov	w8, #0x4                // =4
    f4b8:      	add	x9, sp, #0x78
    f4bc:      	add	x0, sp, #0x78
    f4c0:      	mov	w1, #0x8                // =8
    f4c4:      	mov	x2, x23
    f4c8:      	blr	x8
    f4cc:      	add	x2, x21, #0x20
    f4d0:      	mov	w8, #0x4                // =4
    f4d4:      	mov	w9, #0x10               // =16
    f4d8:      	add	x10, sp, #0x80
    f4dc:      	add	x0, sp, #0x80
    f4e0:      	mov	w1, #0x10               // =16
    f4e4:      	blr	x8
    f4e8:      	ldr	w21, [sp, #0x84]
    f4ec:      	ldr	x8, [sp, #0x40]
    f4f0:      	ldr	x10, [sp, #0x60]
    f4f4:      	sub	x12, x10, x8
    f4f8:      	ldr	w23, [sp, #0x68]
    f4fc:      	subs	w10, w21, w23
    f500:      	ldr	x9, [sp, #0x88]
    f504:      	csel	w10, wzr, w10, lo
    f508:      	cmp	w23, w21
    f50c:      	csel	w11, w23, w21, lo
    f510:      	cinc	w13, w11, hi
    f514:      	sub	w14, w23, w13
    f518:      	subs	x12, x12, x13
    f51c:      	str	w14, [sp, #0x68]
    f520:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    f524:      	cmp	x12, #0xfff
    f528:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    f52c:      	cmp	w23, w21
    f530:      	b.ls	0xf53c <generic_kprobe_path+0x470c>
    f534:      	mov	w13, #0x2f              // =47
    f538:      	strb	w13, [x8, x12]
    f53c:      	add	x19, x8, x12
    f540:      	cmp	w23, w21
    f544:      	add	x2, x9, x10
    f548:      	and	w1, w11, #0xff
    f54c:      	mov	w8, #0x4                // =4
    f550:      	cinc	x0, x19, hi
    f554:      	blr	x8
    f558:      	cmp	w23, w21
    f55c:      	str	x19, [sp, #0x60]
    f560:      	add	x19, sp, #0x70
    f564:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    f568:      	ldr	x21, [sp, #0x78]
    f56c:      	ldp	x2, x24, [sp, #0x50]
    f570:      	str	x21, [sp, #0x48]
    f574:      	b	0xf5c4 <generic_kprobe_path+0x4794>
    f578:      	add	x2, x24, #0x10
    f57c:      	mov	w8, #0x4                // =4
    f580:      	add	x9, sp, #0x98
    f584:      	add	x0, sp, #0x98
    f588:      	mov	w1, #0x8                // =8
    f58c:      	blr	x8
    f590:      	ldr	x8, [sp, #0x58]
    f594:      	ldr	x9, [sp, #0x98]
    f598:      	cmp	x8, x9
    f59c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    f5a0:      	add	x2, x24, #0x18
    f5a4:      	mov	w8, #0x4                // =4
    f5a8:      	mov	x0, x22
    f5ac:      	mov	w1, #0x8                // =8
    f5b0:      	blr	x8
    f5b4:      	ldr	x24, [sp, #0x98]
    f5b8:      	ldr	x21, [sp, #0x48]
    f5bc:      	add	x2, x24, #0x20
    f5c0:      	stp	x2, x24, [sp, #0x50]
    f5c4:      	ldr	x8, [sp, #0x30]
    f5c8:      	cmp	x21, x8
    f5cc:      	b.ne	0xf5dc <generic_kprobe_path+0x47ac>
    f5d0:      	ldr	x8, [sp, #0x38]
    f5d4:      	cmp	x2, x8
    f5d8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    f5dc:      	mov	w8, #0x4                // =4
    f5e0:      	add	x0, sp, #0x70
    f5e4:      	mov	w1, #0x8                // =8
    f5e8:      	blr	x8
    f5ec:      	ldr	x8, [sp, #0x70]
    f5f0:      	cmp	x21, x8
    f5f4:      	b.eq	0xf6e4 <generic_kprobe_path+0x48b4>
    f5f8:      	add	x23, x21, #0x18
    f5fc:      	mov	w8, #0x4                // =4
    f600:      	add	x9, sp, #0x98
    f604:      	add	x0, sp, #0x98
    f608:      	mov	w1, #0x8                // =8
    f60c:      	mov	x2, x23
    f610:      	blr	x8
    f614:      	ldr	x8, [sp, #0x98]
    f618:      	cmp	x8, x21
    f61c:      	b.eq	0xf6e4 <generic_kprobe_path+0x48b4>
    f620:      	mov	w8, #0x4                // =4
    f624:      	add	x9, sp, #0x78
    f628:      	add	x0, sp, #0x78
    f62c:      	mov	w1, #0x8                // =8
    f630:      	mov	x2, x23
    f634:      	blr	x8
    f638:      	add	x2, x21, #0x20
    f63c:      	mov	w8, #0x4                // =4
    f640:      	mov	w9, #0x10               // =16
    f644:      	add	x10, sp, #0x80
    f648:      	add	x0, sp, #0x80
    f64c:      	mov	w1, #0x10               // =16
    f650:      	blr	x8
    f654:      	ldr	w21, [sp, #0x84]
    f658:      	ldr	x8, [sp, #0x40]
    f65c:      	ldr	x10, [sp, #0x60]
    f660:      	sub	x12, x10, x8
    f664:      	ldr	w23, [sp, #0x68]
    f668:      	subs	w10, w21, w23
    f66c:      	ldr	x9, [sp, #0x88]
    f670:      	csel	w10, wzr, w10, lo
    f674:      	cmp	w23, w21
    f678:      	csel	w11, w23, w21, lo
    f67c:      	cinc	w13, w11, hi
    f680:      	sub	w14, w23, w13
    f684:      	subs	x12, x12, x13
    f688:      	str	w14, [sp, #0x68]
    f68c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    f690:      	cmp	x12, #0xfff
    f694:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    f698:      	cmp	w23, w21
    f69c:      	b.ls	0xf6a8 <generic_kprobe_path+0x4878>
    f6a0:      	mov	w13, #0x2f              // =47
    f6a4:      	strb	w13, [x8, x12]
    f6a8:      	add	x19, x8, x12
    f6ac:      	cmp	w23, w21
    f6b0:      	add	x2, x9, x10
    f6b4:      	and	w1, w11, #0xff
    f6b8:      	mov	w8, #0x4                // =4
    f6bc:      	cinc	x0, x19, hi
    f6c0:      	blr	x8
    f6c4:      	cmp	w23, w21
    f6c8:      	str	x19, [sp, #0x60]
    f6cc:      	add	x19, sp, #0x70
    f6d0:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    f6d4:      	ldr	x21, [sp, #0x78]
    f6d8:      	ldp	x2, x24, [sp, #0x50]
    f6dc:      	str	x21, [sp, #0x48]
    f6e0:      	b	0xf730 <generic_kprobe_path+0x4900>
    f6e4:      	add	x2, x24, #0x10
    f6e8:      	mov	w8, #0x4                // =4
    f6ec:      	add	x9, sp, #0x98
    f6f0:      	add	x0, sp, #0x98
    f6f4:      	mov	w1, #0x8                // =8
    f6f8:      	blr	x8
    f6fc:      	ldr	x8, [sp, #0x58]
    f700:      	ldr	x9, [sp, #0x98]
    f704:      	cmp	x8, x9
    f708:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    f70c:      	add	x2, x24, #0x18
    f710:      	mov	w8, #0x4                // =4
    f714:      	mov	x0, x22
    f718:      	mov	w1, #0x8                // =8
    f71c:      	blr	x8
    f720:      	ldr	x24, [sp, #0x98]
    f724:      	ldr	x21, [sp, #0x48]
    f728:      	add	x2, x24, #0x20
    f72c:      	stp	x2, x24, [sp, #0x50]
    f730:      	ldr	x8, [sp, #0x30]
    f734:      	cmp	x21, x8
    f738:      	b.ne	0xf748 <generic_kprobe_path+0x4918>
    f73c:      	ldr	x8, [sp, #0x38]
    f740:      	cmp	x2, x8
    f744:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    f748:      	mov	w8, #0x4                // =4
    f74c:      	add	x0, sp, #0x70
    f750:      	mov	w1, #0x8                // =8
    f754:      	blr	x8
    f758:      	ldr	x8, [sp, #0x70]
    f75c:      	cmp	x21, x8
    f760:      	b.eq	0xf850 <generic_kprobe_path+0x4a20>
    f764:      	add	x23, x21, #0x18
    f768:      	mov	w8, #0x4                // =4
    f76c:      	add	x9, sp, #0x98
    f770:      	add	x0, sp, #0x98
    f774:      	mov	w1, #0x8                // =8
    f778:      	mov	x2, x23
    f77c:      	blr	x8
    f780:      	ldr	x8, [sp, #0x98]
    f784:      	cmp	x8, x21
    f788:      	b.eq	0xf850 <generic_kprobe_path+0x4a20>
    f78c:      	mov	w8, #0x4                // =4
    f790:      	add	x9, sp, #0x78
    f794:      	add	x0, sp, #0x78
    f798:      	mov	w1, #0x8                // =8
    f79c:      	mov	x2, x23
    f7a0:      	blr	x8
    f7a4:      	add	x2, x21, #0x20
    f7a8:      	mov	w8, #0x4                // =4
    f7ac:      	mov	w9, #0x10               // =16
    f7b0:      	add	x10, sp, #0x80
    f7b4:      	add	x0, sp, #0x80
    f7b8:      	mov	w1, #0x10               // =16
    f7bc:      	blr	x8
    f7c0:      	ldr	w21, [sp, #0x84]
    f7c4:      	ldr	x8, [sp, #0x40]
    f7c8:      	ldr	x10, [sp, #0x60]
    f7cc:      	sub	x12, x10, x8
    f7d0:      	ldr	w23, [sp, #0x68]
    f7d4:      	subs	w10, w21, w23
    f7d8:      	ldr	x9, [sp, #0x88]
    f7dc:      	csel	w10, wzr, w10, lo
    f7e0:      	cmp	w23, w21
    f7e4:      	csel	w11, w23, w21, lo
    f7e8:      	cinc	w13, w11, hi
    f7ec:      	sub	w14, w23, w13
    f7f0:      	subs	x12, x12, x13
    f7f4:      	str	w14, [sp, #0x68]
    f7f8:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    f7fc:      	cmp	x12, #0xfff
    f800:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    f804:      	cmp	w23, w21
    f808:      	b.ls	0xf814 <generic_kprobe_path+0x49e4>
    f80c:      	mov	w13, #0x2f              // =47
    f810:      	strb	w13, [x8, x12]
    f814:      	add	x19, x8, x12
    f818:      	cmp	w23, w21
    f81c:      	add	x2, x9, x10
    f820:      	and	w1, w11, #0xff
    f824:      	mov	w8, #0x4                // =4
    f828:      	cinc	x0, x19, hi
    f82c:      	blr	x8
    f830:      	cmp	w23, w21
    f834:      	str	x19, [sp, #0x60]
    f838:      	add	x19, sp, #0x70
    f83c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    f840:      	ldr	x21, [sp, #0x78]
    f844:      	ldp	x2, x24, [sp, #0x50]
    f848:      	str	x21, [sp, #0x48]
    f84c:      	b	0xf89c <generic_kprobe_path+0x4a6c>
    f850:      	add	x2, x24, #0x10
    f854:      	mov	w8, #0x4                // =4
    f858:      	add	x9, sp, #0x98
    f85c:      	add	x0, sp, #0x98
    f860:      	mov	w1, #0x8                // =8
    f864:      	blr	x8
    f868:      	ldr	x8, [sp, #0x58]
    f86c:      	ldr	x9, [sp, #0x98]
    f870:      	cmp	x8, x9
    f874:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    f878:      	add	x2, x24, #0x18
    f87c:      	mov	w8, #0x4                // =4
    f880:      	mov	x0, x22
    f884:      	mov	w1, #0x8                // =8
    f888:      	blr	x8
    f88c:      	ldr	x24, [sp, #0x98]
    f890:      	ldr	x21, [sp, #0x48]
    f894:      	add	x2, x24, #0x20
    f898:      	stp	x2, x24, [sp, #0x50]
    f89c:      	ldr	x8, [sp, #0x30]
    f8a0:      	cmp	x21, x8
    f8a4:      	b.ne	0xf8b4 <generic_kprobe_path+0x4a84>
    f8a8:      	ldr	x8, [sp, #0x38]
    f8ac:      	cmp	x2, x8
    f8b0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    f8b4:      	mov	w8, #0x4                // =4
    f8b8:      	add	x0, sp, #0x70
    f8bc:      	mov	w1, #0x8                // =8
    f8c0:      	blr	x8
    f8c4:      	ldr	x8, [sp, #0x70]
    f8c8:      	cmp	x21, x8
    f8cc:      	b.eq	0xf9bc <generic_kprobe_path+0x4b8c>
    f8d0:      	add	x23, x21, #0x18
    f8d4:      	mov	w8, #0x4                // =4
    f8d8:      	add	x9, sp, #0x98
    f8dc:      	add	x0, sp, #0x98
    f8e0:      	mov	w1, #0x8                // =8
    f8e4:      	mov	x2, x23
    f8e8:      	blr	x8
    f8ec:      	ldr	x8, [sp, #0x98]
    f8f0:      	cmp	x8, x21
    f8f4:      	b.eq	0xf9bc <generic_kprobe_path+0x4b8c>
    f8f8:      	mov	w8, #0x4                // =4
    f8fc:      	add	x9, sp, #0x78
    f900:      	add	x0, sp, #0x78
    f904:      	mov	w1, #0x8                // =8
    f908:      	mov	x2, x23
    f90c:      	blr	x8
    f910:      	add	x2, x21, #0x20
    f914:      	mov	w8, #0x4                // =4
    f918:      	mov	w9, #0x10               // =16
    f91c:      	add	x10, sp, #0x80
    f920:      	add	x0, sp, #0x80
    f924:      	mov	w1, #0x10               // =16
    f928:      	blr	x8
    f92c:      	ldr	w21, [sp, #0x84]
    f930:      	ldr	x8, [sp, #0x40]
    f934:      	ldr	x10, [sp, #0x60]
    f938:      	sub	x12, x10, x8
    f93c:      	ldr	w23, [sp, #0x68]
    f940:      	subs	w10, w21, w23
    f944:      	ldr	x9, [sp, #0x88]
    f948:      	csel	w10, wzr, w10, lo
    f94c:      	cmp	w23, w21
    f950:      	csel	w11, w23, w21, lo
    f954:      	cinc	w13, w11, hi
    f958:      	sub	w14, w23, w13
    f95c:      	subs	x12, x12, x13
    f960:      	str	w14, [sp, #0x68]
    f964:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    f968:      	cmp	x12, #0xfff
    f96c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    f970:      	cmp	w23, w21
    f974:      	b.ls	0xf980 <generic_kprobe_path+0x4b50>
    f978:      	mov	w13, #0x2f              // =47
    f97c:      	strb	w13, [x8, x12]
    f980:      	add	x19, x8, x12
    f984:      	cmp	w23, w21
    f988:      	add	x2, x9, x10
    f98c:      	and	w1, w11, #0xff
    f990:      	mov	w8, #0x4                // =4
    f994:      	cinc	x0, x19, hi
    f998:      	blr	x8
    f99c:      	cmp	w23, w21
    f9a0:      	str	x19, [sp, #0x60]
    f9a4:      	add	x19, sp, #0x70
    f9a8:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    f9ac:      	ldr	x21, [sp, #0x78]
    f9b0:      	ldp	x2, x24, [sp, #0x50]
    f9b4:      	str	x21, [sp, #0x48]
    f9b8:      	b	0xfa08 <generic_kprobe_path+0x4bd8>
    f9bc:      	add	x2, x24, #0x10
    f9c0:      	mov	w8, #0x4                // =4
    f9c4:      	add	x9, sp, #0x98
    f9c8:      	add	x0, sp, #0x98
    f9cc:      	mov	w1, #0x8                // =8
    f9d0:      	blr	x8
    f9d4:      	ldr	x8, [sp, #0x58]
    f9d8:      	ldr	x9, [sp, #0x98]
    f9dc:      	cmp	x8, x9
    f9e0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    f9e4:      	add	x2, x24, #0x18
    f9e8:      	mov	w8, #0x4                // =4
    f9ec:      	mov	x0, x22
    f9f0:      	mov	w1, #0x8                // =8
    f9f4:      	blr	x8
    f9f8:      	ldr	x24, [sp, #0x98]
    f9fc:      	ldr	x21, [sp, #0x48]
    fa00:      	add	x2, x24, #0x20
    fa04:      	stp	x2, x24, [sp, #0x50]
    fa08:      	ldr	x8, [sp, #0x30]
    fa0c:      	cmp	x21, x8
    fa10:      	b.ne	0xfa20 <generic_kprobe_path+0x4bf0>
    fa14:      	ldr	x8, [sp, #0x38]
    fa18:      	cmp	x2, x8
    fa1c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    fa20:      	mov	w8, #0x4                // =4
    fa24:      	add	x0, sp, #0x70
    fa28:      	mov	w1, #0x8                // =8
    fa2c:      	blr	x8
    fa30:      	ldr	x8, [sp, #0x70]
    fa34:      	cmp	x21, x8
    fa38:      	b.eq	0xfb28 <generic_kprobe_path+0x4cf8>
    fa3c:      	add	x23, x21, #0x18
    fa40:      	mov	w8, #0x4                // =4
    fa44:      	add	x9, sp, #0x98
    fa48:      	add	x0, sp, #0x98
    fa4c:      	mov	w1, #0x8                // =8
    fa50:      	mov	x2, x23
    fa54:      	blr	x8
    fa58:      	ldr	x8, [sp, #0x98]
    fa5c:      	cmp	x8, x21
    fa60:      	b.eq	0xfb28 <generic_kprobe_path+0x4cf8>
    fa64:      	mov	w8, #0x4                // =4
    fa68:      	add	x9, sp, #0x78
    fa6c:      	add	x0, sp, #0x78
    fa70:      	mov	w1, #0x8                // =8
    fa74:      	mov	x2, x23
    fa78:      	blr	x8
    fa7c:      	add	x2, x21, #0x20
    fa80:      	mov	w8, #0x4                // =4
    fa84:      	mov	w9, #0x10               // =16
    fa88:      	add	x10, sp, #0x80
    fa8c:      	add	x0, sp, #0x80
    fa90:      	mov	w1, #0x10               // =16
    fa94:      	blr	x8
    fa98:      	ldr	w21, [sp, #0x84]
    fa9c:      	ldr	x8, [sp, #0x40]
    faa0:      	ldr	x10, [sp, #0x60]
    faa4:      	sub	x12, x10, x8
    faa8:      	ldr	w23, [sp, #0x68]
    faac:      	subs	w10, w21, w23
    fab0:      	ldr	x9, [sp, #0x88]
    fab4:      	csel	w10, wzr, w10, lo
    fab8:      	cmp	w23, w21
    fabc:      	csel	w11, w23, w21, lo
    fac0:      	cinc	w13, w11, hi
    fac4:      	sub	w14, w23, w13
    fac8:      	subs	x12, x12, x13
    facc:      	str	w14, [sp, #0x68]
    fad0:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    fad4:      	cmp	x12, #0xfff
    fad8:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    fadc:      	cmp	w23, w21
    fae0:      	b.ls	0xfaec <generic_kprobe_path+0x4cbc>
    fae4:      	mov	w13, #0x2f              // =47
    fae8:      	strb	w13, [x8, x12]
    faec:      	add	x19, x8, x12
    faf0:      	cmp	w23, w21
    faf4:      	add	x2, x9, x10
    faf8:      	and	w1, w11, #0xff
    fafc:      	mov	w8, #0x4                // =4
    fb00:      	cinc	x0, x19, hi
    fb04:      	blr	x8
    fb08:      	cmp	w23, w21
    fb0c:      	str	x19, [sp, #0x60]
    fb10:      	add	x19, sp, #0x70
    fb14:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    fb18:      	ldr	x21, [sp, #0x78]
    fb1c:      	ldp	x2, x24, [sp, #0x50]
    fb20:      	str	x21, [sp, #0x48]
    fb24:      	b	0xfb74 <generic_kprobe_path+0x4d44>
    fb28:      	add	x2, x24, #0x10
    fb2c:      	mov	w8, #0x4                // =4
    fb30:      	add	x9, sp, #0x98
    fb34:      	add	x0, sp, #0x98
    fb38:      	mov	w1, #0x8                // =8
    fb3c:      	blr	x8
    fb40:      	ldr	x8, [sp, #0x58]
    fb44:      	ldr	x9, [sp, #0x98]
    fb48:      	cmp	x8, x9
    fb4c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    fb50:      	add	x2, x24, #0x18
    fb54:      	mov	w8, #0x4                // =4
    fb58:      	mov	x0, x22
    fb5c:      	mov	w1, #0x8                // =8
    fb60:      	blr	x8
    fb64:      	ldr	x24, [sp, #0x98]
    fb68:      	ldr	x21, [sp, #0x48]
    fb6c:      	add	x2, x24, #0x20
    fb70:      	stp	x2, x24, [sp, #0x50]
    fb74:      	ldr	x8, [sp, #0x30]
    fb78:      	cmp	x21, x8
    fb7c:      	b.ne	0xfb8c <generic_kprobe_path+0x4d5c>
    fb80:      	ldr	x8, [sp, #0x38]
    fb84:      	cmp	x2, x8
    fb88:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    fb8c:      	mov	w8, #0x4                // =4
    fb90:      	add	x0, sp, #0x70
    fb94:      	mov	w1, #0x8                // =8
    fb98:      	blr	x8
    fb9c:      	ldr	x8, [sp, #0x70]
    fba0:      	cmp	x21, x8
    fba4:      	b.eq	0xfc94 <generic_kprobe_path+0x4e64>
    fba8:      	add	x23, x21, #0x18
    fbac:      	mov	w8, #0x4                // =4
    fbb0:      	add	x9, sp, #0x98
    fbb4:      	add	x0, sp, #0x98
    fbb8:      	mov	w1, #0x8                // =8
    fbbc:      	mov	x2, x23
    fbc0:      	blr	x8
    fbc4:      	ldr	x8, [sp, #0x98]
    fbc8:      	cmp	x8, x21
    fbcc:      	b.eq	0xfc94 <generic_kprobe_path+0x4e64>
    fbd0:      	mov	w8, #0x4                // =4
    fbd4:      	add	x9, sp, #0x78
    fbd8:      	add	x0, sp, #0x78
    fbdc:      	mov	w1, #0x8                // =8
    fbe0:      	mov	x2, x23
    fbe4:      	blr	x8
    fbe8:      	add	x2, x21, #0x20
    fbec:      	mov	w8, #0x4                // =4
    fbf0:      	mov	w9, #0x10               // =16
    fbf4:      	add	x10, sp, #0x80
    fbf8:      	add	x0, sp, #0x80
    fbfc:      	mov	w1, #0x10               // =16
    fc00:      	blr	x8
    fc04:      	ldr	w21, [sp, #0x84]
    fc08:      	ldr	x8, [sp, #0x40]
    fc0c:      	ldr	x10, [sp, #0x60]
    fc10:      	sub	x12, x10, x8
    fc14:      	ldr	w23, [sp, #0x68]
    fc18:      	subs	w10, w21, w23
    fc1c:      	ldr	x9, [sp, #0x88]
    fc20:      	csel	w10, wzr, w10, lo
    fc24:      	cmp	w23, w21
    fc28:      	csel	w11, w23, w21, lo
    fc2c:      	cinc	w13, w11, hi
    fc30:      	sub	w14, w23, w13
    fc34:      	subs	x12, x12, x13
    fc38:      	str	w14, [sp, #0x68]
    fc3c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    fc40:      	cmp	x12, #0xfff
    fc44:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    fc48:      	cmp	w23, w21
    fc4c:      	b.ls	0xfc58 <generic_kprobe_path+0x4e28>
    fc50:      	mov	w13, #0x2f              // =47
    fc54:      	strb	w13, [x8, x12]
    fc58:      	add	x19, x8, x12
    fc5c:      	cmp	w23, w21
    fc60:      	add	x2, x9, x10
    fc64:      	and	w1, w11, #0xff
    fc68:      	mov	w8, #0x4                // =4
    fc6c:      	cinc	x0, x19, hi
    fc70:      	blr	x8
    fc74:      	cmp	w23, w21
    fc78:      	str	x19, [sp, #0x60]
    fc7c:      	add	x19, sp, #0x70
    fc80:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    fc84:      	ldr	x21, [sp, #0x78]
    fc88:      	ldp	x2, x24, [sp, #0x50]
    fc8c:      	str	x21, [sp, #0x48]
    fc90:      	b	0xfce0 <generic_kprobe_path+0x4eb0>
    fc94:      	add	x2, x24, #0x10
    fc98:      	mov	w8, #0x4                // =4
    fc9c:      	add	x9, sp, #0x98
    fca0:      	add	x0, sp, #0x98
    fca4:      	mov	w1, #0x8                // =8
    fca8:      	blr	x8
    fcac:      	ldr	x8, [sp, #0x58]
    fcb0:      	ldr	x9, [sp, #0x98]
    fcb4:      	cmp	x8, x9
    fcb8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    fcbc:      	add	x2, x24, #0x18
    fcc0:      	mov	w8, #0x4                // =4
    fcc4:      	mov	x0, x22
    fcc8:      	mov	w1, #0x8                // =8
    fccc:      	blr	x8
    fcd0:      	ldr	x24, [sp, #0x98]
    fcd4:      	ldr	x21, [sp, #0x48]
    fcd8:      	add	x2, x24, #0x20
    fcdc:      	stp	x2, x24, [sp, #0x50]
    fce0:      	ldr	x8, [sp, #0x30]
    fce4:      	cmp	x21, x8
    fce8:      	b.ne	0xfcf8 <generic_kprobe_path+0x4ec8>
    fcec:      	ldr	x8, [sp, #0x38]
    fcf0:      	cmp	x2, x8
    fcf4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    fcf8:      	mov	w8, #0x4                // =4
    fcfc:      	add	x0, sp, #0x70
    fd00:      	mov	w1, #0x8                // =8
    fd04:      	blr	x8
    fd08:      	ldr	x8, [sp, #0x70]
    fd0c:      	cmp	x21, x8
    fd10:      	b.eq	0xfe00 <generic_kprobe_path+0x4fd0>
    fd14:      	add	x23, x21, #0x18
    fd18:      	mov	w8, #0x4                // =4
    fd1c:      	add	x9, sp, #0x98
    fd20:      	add	x0, sp, #0x98
    fd24:      	mov	w1, #0x8                // =8
    fd28:      	mov	x2, x23
    fd2c:      	blr	x8
    fd30:      	ldr	x8, [sp, #0x98]
    fd34:      	cmp	x8, x21
    fd38:      	b.eq	0xfe00 <generic_kprobe_path+0x4fd0>
    fd3c:      	mov	w8, #0x4                // =4
    fd40:      	add	x9, sp, #0x78
    fd44:      	add	x0, sp, #0x78
    fd48:      	mov	w1, #0x8                // =8
    fd4c:      	mov	x2, x23
    fd50:      	blr	x8
    fd54:      	add	x2, x21, #0x20
    fd58:      	mov	w8, #0x4                // =4
    fd5c:      	mov	w9, #0x10               // =16
    fd60:      	add	x10, sp, #0x80
    fd64:      	add	x0, sp, #0x80
    fd68:      	mov	w1, #0x10               // =16
    fd6c:      	blr	x8
    fd70:      	ldr	w21, [sp, #0x84]
    fd74:      	ldr	x8, [sp, #0x40]
    fd78:      	ldr	x10, [sp, #0x60]
    fd7c:      	sub	x12, x10, x8
    fd80:      	ldr	w23, [sp, #0x68]
    fd84:      	subs	w10, w21, w23
    fd88:      	ldr	x9, [sp, #0x88]
    fd8c:      	csel	w10, wzr, w10, lo
    fd90:      	cmp	w23, w21
    fd94:      	csel	w11, w23, w21, lo
    fd98:      	cinc	w13, w11, hi
    fd9c:      	sub	w14, w23, w13
    fda0:      	subs	x12, x12, x13
    fda4:      	str	w14, [sp, #0x68]
    fda8:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    fdac:      	cmp	x12, #0xfff
    fdb0:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    fdb4:      	cmp	w23, w21
    fdb8:      	b.ls	0xfdc4 <generic_kprobe_path+0x4f94>
    fdbc:      	mov	w13, #0x2f              // =47
    fdc0:      	strb	w13, [x8, x12]
    fdc4:      	add	x19, x8, x12
    fdc8:      	cmp	w23, w21
    fdcc:      	add	x2, x9, x10
    fdd0:      	and	w1, w11, #0xff
    fdd4:      	mov	w8, #0x4                // =4
    fdd8:      	cinc	x0, x19, hi
    fddc:      	blr	x8
    fde0:      	cmp	w23, w21
    fde4:      	str	x19, [sp, #0x60]
    fde8:      	add	x19, sp, #0x70
    fdec:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    fdf0:      	ldr	x21, [sp, #0x78]
    fdf4:      	ldp	x2, x24, [sp, #0x50]
    fdf8:      	str	x21, [sp, #0x48]
    fdfc:      	b	0xfe4c <generic_kprobe_path+0x501c>
    fe00:      	add	x2, x24, #0x10
    fe04:      	mov	w8, #0x4                // =4
    fe08:      	add	x9, sp, #0x98
    fe0c:      	add	x0, sp, #0x98
    fe10:      	mov	w1, #0x8                // =8
    fe14:      	blr	x8
    fe18:      	ldr	x8, [sp, #0x58]
    fe1c:      	ldr	x9, [sp, #0x98]
    fe20:      	cmp	x8, x9
    fe24:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    fe28:      	add	x2, x24, #0x18
    fe2c:      	mov	w8, #0x4                // =4
    fe30:      	mov	x0, x22
    fe34:      	mov	w1, #0x8                // =8
    fe38:      	blr	x8
    fe3c:      	ldr	x24, [sp, #0x98]
    fe40:      	ldr	x21, [sp, #0x48]
    fe44:      	add	x2, x24, #0x20
    fe48:      	stp	x2, x24, [sp, #0x50]
    fe4c:      	ldr	x8, [sp, #0x30]
    fe50:      	cmp	x21, x8
    fe54:      	b.ne	0xfe64 <generic_kprobe_path+0x5034>
    fe58:      	ldr	x8, [sp, #0x38]
    fe5c:      	cmp	x2, x8
    fe60:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    fe64:      	mov	w8, #0x4                // =4
    fe68:      	add	x0, sp, #0x70
    fe6c:      	mov	w1, #0x8                // =8
    fe70:      	blr	x8
    fe74:      	ldr	x8, [sp, #0x70]
    fe78:      	cmp	x21, x8
    fe7c:      	b.eq	0xff6c <generic_kprobe_path+0x513c>
    fe80:      	add	x23, x21, #0x18
    fe84:      	mov	w8, #0x4                // =4
    fe88:      	add	x9, sp, #0x98
    fe8c:      	add	x0, sp, #0x98
    fe90:      	mov	w1, #0x8                // =8
    fe94:      	mov	x2, x23
    fe98:      	blr	x8
    fe9c:      	ldr	x8, [sp, #0x98]
    fea0:      	cmp	x8, x21
    fea4:      	b.eq	0xff6c <generic_kprobe_path+0x513c>
    fea8:      	mov	w8, #0x4                // =4
    feac:      	add	x9, sp, #0x78
    feb0:      	add	x0, sp, #0x78
    feb4:      	mov	w1, #0x8                // =8
    feb8:      	mov	x2, x23
    febc:      	blr	x8
    fec0:      	add	x2, x21, #0x20
    fec4:      	mov	w8, #0x4                // =4
    fec8:      	mov	w9, #0x10               // =16
    fecc:      	add	x10, sp, #0x80
    fed0:      	add	x0, sp, #0x80
    fed4:      	mov	w1, #0x10               // =16
    fed8:      	blr	x8
    fedc:      	ldr	w21, [sp, #0x84]
    fee0:      	ldr	x8, [sp, #0x40]
    fee4:      	ldr	x10, [sp, #0x60]
    fee8:      	sub	x12, x10, x8
    feec:      	ldr	w23, [sp, #0x68]
    fef0:      	subs	w10, w21, w23
    fef4:      	ldr	x9, [sp, #0x88]
    fef8:      	csel	w10, wzr, w10, lo
    fefc:      	cmp	w23, w21
    ff00:      	csel	w11, w23, w21, lo
    ff04:      	cinc	w13, w11, hi
    ff08:      	sub	w14, w23, w13
    ff0c:      	subs	x12, x12, x13
    ff10:      	str	w14, [sp, #0x68]
    ff14:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
    ff18:      	cmp	x12, #0xfff
    ff1c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
    ff20:      	cmp	w23, w21
    ff24:      	b.ls	0xff30 <generic_kprobe_path+0x5100>
    ff28:      	mov	w13, #0x2f              // =47
    ff2c:      	strb	w13, [x8, x12]
    ff30:      	add	x19, x8, x12
    ff34:      	cmp	w23, w21
    ff38:      	add	x2, x9, x10
    ff3c:      	and	w1, w11, #0xff
    ff40:      	mov	w8, #0x4                // =4
    ff44:      	cinc	x0, x19, hi
    ff48:      	blr	x8
    ff4c:      	cmp	w23, w21
    ff50:      	str	x19, [sp, #0x60]
    ff54:      	add	x19, sp, #0x70
    ff58:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
    ff5c:      	ldr	x21, [sp, #0x78]
    ff60:      	ldp	x2, x24, [sp, #0x50]
    ff64:      	str	x21, [sp, #0x48]
    ff68:      	b	0xffb8 <generic_kprobe_path+0x5188>
    ff6c:      	add	x2, x24, #0x10
    ff70:      	mov	w8, #0x4                // =4
    ff74:      	add	x9, sp, #0x98
    ff78:      	add	x0, sp, #0x98
    ff7c:      	mov	w1, #0x8                // =8
    ff80:      	blr	x8
    ff84:      	ldr	x8, [sp, #0x58]
    ff88:      	ldr	x9, [sp, #0x98]
    ff8c:      	cmp	x8, x9
    ff90:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    ff94:      	add	x2, x24, #0x18
    ff98:      	mov	w8, #0x4                // =4
    ff9c:      	mov	x0, x22
    ffa0:      	mov	w1, #0x8                // =8
    ffa4:      	blr	x8
    ffa8:      	ldr	x24, [sp, #0x98]
    ffac:      	ldr	x21, [sp, #0x48]
    ffb0:      	add	x2, x24, #0x20
    ffb4:      	stp	x2, x24, [sp, #0x50]
    ffb8:      	ldr	x8, [sp, #0x30]
    ffbc:      	cmp	x21, x8
    ffc0:      	b.ne	0xffd0 <generic_kprobe_path+0x51a0>
    ffc4:      	ldr	x8, [sp, #0x38]
    ffc8:      	cmp	x2, x8
    ffcc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
    ffd0:      	mov	w8, #0x4                // =4
    ffd4:      	add	x0, sp, #0x70
    ffd8:      	mov	w1, #0x8                // =8
    ffdc:      	blr	x8
    ffe0:      	ldr	x8, [sp, #0x70]
    ffe4:      	cmp	x21, x8
    ffe8:      	b.eq	0x100d8 <generic_kprobe_path+0x52a8>
    ffec:      	add	x23, x21, #0x18
    fff0:      	mov	w8, #0x4                // =4
    fff4:      	add	x9, sp, #0x98
    fff8:      	add	x0, sp, #0x98
    fffc:      	mov	w1, #0x8                // =8
   10000:      	mov	x2, x23
   10004:      	blr	x8
   10008:      	ldr	x8, [sp, #0x98]
   1000c:      	cmp	x8, x21
   10010:      	b.eq	0x100d8 <generic_kprobe_path+0x52a8>
   10014:      	mov	w8, #0x4                // =4
   10018:      	add	x9, sp, #0x78
   1001c:      	add	x0, sp, #0x78
   10020:      	mov	w1, #0x8                // =8
   10024:      	mov	x2, x23
   10028:      	blr	x8
   1002c:      	add	x2, x21, #0x20
   10030:      	mov	w8, #0x4                // =4
   10034:      	mov	w9, #0x10               // =16
   10038:      	add	x10, sp, #0x80
   1003c:      	add	x0, sp, #0x80
   10040:      	mov	w1, #0x10               // =16
   10044:      	blr	x8
   10048:      	ldr	w21, [sp, #0x84]
   1004c:      	ldr	x8, [sp, #0x40]
   10050:      	ldr	x10, [sp, #0x60]
   10054:      	sub	x12, x10, x8
   10058:      	ldr	w23, [sp, #0x68]
   1005c:      	subs	w10, w21, w23
   10060:      	ldr	x9, [sp, #0x88]
   10064:      	csel	w10, wzr, w10, lo
   10068:      	cmp	w23, w21
   1006c:      	csel	w11, w23, w21, lo
   10070:      	cinc	w13, w11, hi
   10074:      	sub	w14, w23, w13
   10078:      	subs	x12, x12, x13
   1007c:      	str	w14, [sp, #0x68]
   10080:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   10084:      	cmp	x12, #0xfff
   10088:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   1008c:      	cmp	w23, w21
   10090:      	b.ls	0x1009c <generic_kprobe_path+0x526c>
   10094:      	mov	w13, #0x2f              // =47
   10098:      	strb	w13, [x8, x12]
   1009c:      	add	x19, x8, x12
   100a0:      	cmp	w23, w21
   100a4:      	add	x2, x9, x10
   100a8:      	and	w1, w11, #0xff
   100ac:      	mov	w8, #0x4                // =4
   100b0:      	cinc	x0, x19, hi
   100b4:      	blr	x8
   100b8:      	cmp	w23, w21
   100bc:      	str	x19, [sp, #0x60]
   100c0:      	add	x19, sp, #0x70
   100c4:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   100c8:      	ldr	x21, [sp, #0x78]
   100cc:      	ldp	x2, x24, [sp, #0x50]
   100d0:      	str	x21, [sp, #0x48]
   100d4:      	b	0x10124 <generic_kprobe_path+0x52f4>
   100d8:      	add	x2, x24, #0x10
   100dc:      	mov	w8, #0x4                // =4
   100e0:      	add	x9, sp, #0x98
   100e4:      	add	x0, sp, #0x98
   100e8:      	mov	w1, #0x8                // =8
   100ec:      	blr	x8
   100f0:      	ldr	x8, [sp, #0x58]
   100f4:      	ldr	x9, [sp, #0x98]
   100f8:      	cmp	x8, x9
   100fc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   10100:      	add	x2, x24, #0x18
   10104:      	mov	w8, #0x4                // =4
   10108:      	mov	x0, x22
   1010c:      	mov	w1, #0x8                // =8
   10110:      	blr	x8
   10114:      	ldr	x24, [sp, #0x98]
   10118:      	ldr	x21, [sp, #0x48]
   1011c:      	add	x2, x24, #0x20
   10120:      	stp	x2, x24, [sp, #0x50]
   10124:      	ldr	x8, [sp, #0x30]
   10128:      	cmp	x21, x8
   1012c:      	b.ne	0x1013c <generic_kprobe_path+0x530c>
   10130:      	ldr	x8, [sp, #0x38]
   10134:      	cmp	x2, x8
   10138:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1013c:      	mov	w8, #0x4                // =4
   10140:      	add	x0, sp, #0x70
   10144:      	mov	w1, #0x8                // =8
   10148:      	blr	x8
   1014c:      	ldr	x8, [sp, #0x70]
   10150:      	cmp	x21, x8
   10154:      	b.eq	0x10244 <generic_kprobe_path+0x5414>
   10158:      	add	x23, x21, #0x18
   1015c:      	mov	w8, #0x4                // =4
   10160:      	add	x9, sp, #0x98
   10164:      	add	x0, sp, #0x98
   10168:      	mov	w1, #0x8                // =8
   1016c:      	mov	x2, x23
   10170:      	blr	x8
   10174:      	ldr	x8, [sp, #0x98]
   10178:      	cmp	x8, x21
   1017c:      	b.eq	0x10244 <generic_kprobe_path+0x5414>
   10180:      	mov	w8, #0x4                // =4
   10184:      	add	x9, sp, #0x78
   10188:      	add	x0, sp, #0x78
   1018c:      	mov	w1, #0x8                // =8
   10190:      	mov	x2, x23
   10194:      	blr	x8
   10198:      	add	x2, x21, #0x20
   1019c:      	mov	w8, #0x4                // =4
   101a0:      	mov	w9, #0x10               // =16
   101a4:      	add	x10, sp, #0x80
   101a8:      	add	x0, sp, #0x80
   101ac:      	mov	w1, #0x10               // =16
   101b0:      	blr	x8
   101b4:      	ldr	w21, [sp, #0x84]
   101b8:      	ldr	x8, [sp, #0x40]
   101bc:      	ldr	x10, [sp, #0x60]
   101c0:      	sub	x12, x10, x8
   101c4:      	ldr	w23, [sp, #0x68]
   101c8:      	subs	w10, w21, w23
   101cc:      	ldr	x9, [sp, #0x88]
   101d0:      	csel	w10, wzr, w10, lo
   101d4:      	cmp	w23, w21
   101d8:      	csel	w11, w23, w21, lo
   101dc:      	cinc	w13, w11, hi
   101e0:      	sub	w14, w23, w13
   101e4:      	subs	x12, x12, x13
   101e8:      	str	w14, [sp, #0x68]
   101ec:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   101f0:      	cmp	x12, #0xfff
   101f4:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   101f8:      	cmp	w23, w21
   101fc:      	b.ls	0x10208 <generic_kprobe_path+0x53d8>
   10200:      	mov	w13, #0x2f              // =47
   10204:      	strb	w13, [x8, x12]
   10208:      	add	x19, x8, x12
   1020c:      	cmp	w23, w21
   10210:      	add	x2, x9, x10
   10214:      	and	w1, w11, #0xff
   10218:      	mov	w8, #0x4                // =4
   1021c:      	cinc	x0, x19, hi
   10220:      	blr	x8
   10224:      	cmp	w23, w21
   10228:      	str	x19, [sp, #0x60]
   1022c:      	add	x19, sp, #0x70
   10230:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   10234:      	ldr	x21, [sp, #0x78]
   10238:      	ldp	x2, x24, [sp, #0x50]
   1023c:      	str	x21, [sp, #0x48]
   10240:      	b	0x10290 <generic_kprobe_path+0x5460>
   10244:      	add	x2, x24, #0x10
   10248:      	mov	w8, #0x4                // =4
   1024c:      	add	x9, sp, #0x98
   10250:      	add	x0, sp, #0x98
   10254:      	mov	w1, #0x8                // =8
   10258:      	blr	x8
   1025c:      	ldr	x8, [sp, #0x58]
   10260:      	ldr	x9, [sp, #0x98]
   10264:      	cmp	x8, x9
   10268:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1026c:      	add	x2, x24, #0x18
   10270:      	mov	w8, #0x4                // =4
   10274:      	mov	x0, x22
   10278:      	mov	w1, #0x8                // =8
   1027c:      	blr	x8
   10280:      	ldr	x24, [sp, #0x98]
   10284:      	ldr	x21, [sp, #0x48]
   10288:      	add	x2, x24, #0x20
   1028c:      	stp	x2, x24, [sp, #0x50]
   10290:      	ldr	x8, [sp, #0x30]
   10294:      	cmp	x21, x8
   10298:      	b.ne	0x102a8 <generic_kprobe_path+0x5478>
   1029c:      	ldr	x8, [sp, #0x38]
   102a0:      	cmp	x2, x8
   102a4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   102a8:      	mov	w8, #0x4                // =4
   102ac:      	add	x0, sp, #0x70
   102b0:      	mov	w1, #0x8                // =8
   102b4:      	blr	x8
   102b8:      	ldr	x8, [sp, #0x70]
   102bc:      	cmp	x21, x8
   102c0:      	b.eq	0x103b0 <generic_kprobe_path+0x5580>
   102c4:      	add	x23, x21, #0x18
   102c8:      	mov	w8, #0x4                // =4
   102cc:      	add	x9, sp, #0x98
   102d0:      	add	x0, sp, #0x98
   102d4:      	mov	w1, #0x8                // =8
   102d8:      	mov	x2, x23
   102dc:      	blr	x8
   102e0:      	ldr	x8, [sp, #0x98]
   102e4:      	cmp	x8, x21
   102e8:      	b.eq	0x103b0 <generic_kprobe_path+0x5580>
   102ec:      	mov	w8, #0x4                // =4
   102f0:      	add	x9, sp, #0x78
   102f4:      	add	x0, sp, #0x78
   102f8:      	mov	w1, #0x8                // =8
   102fc:      	mov	x2, x23
   10300:      	blr	x8
   10304:      	add	x2, x21, #0x20
   10308:      	mov	w8, #0x4                // =4
   1030c:      	mov	w9, #0x10               // =16
   10310:      	add	x10, sp, #0x80
   10314:      	add	x0, sp, #0x80
   10318:      	mov	w1, #0x10               // =16
   1031c:      	blr	x8
   10320:      	ldr	w21, [sp, #0x84]
   10324:      	ldr	x8, [sp, #0x40]
   10328:      	ldr	x10, [sp, #0x60]
   1032c:      	sub	x12, x10, x8
   10330:      	ldr	w23, [sp, #0x68]
   10334:      	subs	w10, w21, w23
   10338:      	ldr	x9, [sp, #0x88]
   1033c:      	csel	w10, wzr, w10, lo
   10340:      	cmp	w23, w21
   10344:      	csel	w11, w23, w21, lo
   10348:      	cinc	w13, w11, hi
   1034c:      	sub	w14, w23, w13
   10350:      	subs	x12, x12, x13
   10354:      	str	w14, [sp, #0x68]
   10358:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   1035c:      	cmp	x12, #0xfff
   10360:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   10364:      	cmp	w23, w21
   10368:      	b.ls	0x10374 <generic_kprobe_path+0x5544>
   1036c:      	mov	w13, #0x2f              // =47
   10370:      	strb	w13, [x8, x12]
   10374:      	add	x19, x8, x12
   10378:      	cmp	w23, w21
   1037c:      	add	x2, x9, x10
   10380:      	and	w1, w11, #0xff
   10384:      	mov	w8, #0x4                // =4
   10388:      	cinc	x0, x19, hi
   1038c:      	blr	x8
   10390:      	cmp	w23, w21
   10394:      	str	x19, [sp, #0x60]
   10398:      	add	x19, sp, #0x70
   1039c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   103a0:      	ldr	x21, [sp, #0x78]
   103a4:      	ldp	x2, x24, [sp, #0x50]
   103a8:      	str	x21, [sp, #0x48]
   103ac:      	b	0x103fc <generic_kprobe_path+0x55cc>
   103b0:      	add	x2, x24, #0x10
   103b4:      	mov	w8, #0x4                // =4
   103b8:      	add	x9, sp, #0x98
   103bc:      	add	x0, sp, #0x98
   103c0:      	mov	w1, #0x8                // =8
   103c4:      	blr	x8
   103c8:      	ldr	x8, [sp, #0x58]
   103cc:      	ldr	x9, [sp, #0x98]
   103d0:      	cmp	x8, x9
   103d4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   103d8:      	add	x2, x24, #0x18
   103dc:      	mov	w8, #0x4                // =4
   103e0:      	mov	x0, x22
   103e4:      	mov	w1, #0x8                // =8
   103e8:      	blr	x8
   103ec:      	ldr	x24, [sp, #0x98]
   103f0:      	ldr	x21, [sp, #0x48]
   103f4:      	add	x2, x24, #0x20
   103f8:      	stp	x2, x24, [sp, #0x50]
   103fc:      	ldr	x8, [sp, #0x30]
   10400:      	cmp	x21, x8
   10404:      	b.ne	0x10414 <generic_kprobe_path+0x55e4>
   10408:      	ldr	x8, [sp, #0x38]
   1040c:      	cmp	x2, x8
   10410:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   10414:      	mov	w8, #0x4                // =4
   10418:      	add	x0, sp, #0x70
   1041c:      	mov	w1, #0x8                // =8
   10420:      	blr	x8
   10424:      	ldr	x8, [sp, #0x70]
   10428:      	cmp	x21, x8
   1042c:      	b.eq	0x1051c <generic_kprobe_path+0x56ec>
   10430:      	add	x23, x21, #0x18
   10434:      	mov	w8, #0x4                // =4
   10438:      	add	x9, sp, #0x98
   1043c:      	add	x0, sp, #0x98
   10440:      	mov	w1, #0x8                // =8
   10444:      	mov	x2, x23
   10448:      	blr	x8
   1044c:      	ldr	x8, [sp, #0x98]
   10450:      	cmp	x8, x21
   10454:      	b.eq	0x1051c <generic_kprobe_path+0x56ec>
   10458:      	mov	w8, #0x4                // =4
   1045c:      	add	x9, sp, #0x78
   10460:      	add	x0, sp, #0x78
   10464:      	mov	w1, #0x8                // =8
   10468:      	mov	x2, x23
   1046c:      	blr	x8
   10470:      	add	x2, x21, #0x20
   10474:      	mov	w8, #0x4                // =4
   10478:      	mov	w9, #0x10               // =16
   1047c:      	add	x10, sp, #0x80
   10480:      	add	x0, sp, #0x80
   10484:      	mov	w1, #0x10               // =16
   10488:      	blr	x8
   1048c:      	ldr	w21, [sp, #0x84]
   10490:      	ldr	x8, [sp, #0x40]
   10494:      	ldr	x10, [sp, #0x60]
   10498:      	sub	x12, x10, x8
   1049c:      	ldr	w23, [sp, #0x68]
   104a0:      	subs	w10, w21, w23
   104a4:      	ldr	x9, [sp, #0x88]
   104a8:      	csel	w10, wzr, w10, lo
   104ac:      	cmp	w23, w21
   104b0:      	csel	w11, w23, w21, lo
   104b4:      	cinc	w13, w11, hi
   104b8:      	sub	w14, w23, w13
   104bc:      	subs	x12, x12, x13
   104c0:      	str	w14, [sp, #0x68]
   104c4:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   104c8:      	cmp	x12, #0xfff
   104cc:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   104d0:      	cmp	w23, w21
   104d4:      	b.ls	0x104e0 <generic_kprobe_path+0x56b0>
   104d8:      	mov	w13, #0x2f              // =47
   104dc:      	strb	w13, [x8, x12]
   104e0:      	add	x19, x8, x12
   104e4:      	cmp	w23, w21
   104e8:      	add	x2, x9, x10
   104ec:      	and	w1, w11, #0xff
   104f0:      	mov	w8, #0x4                // =4
   104f4:      	cinc	x0, x19, hi
   104f8:      	blr	x8
   104fc:      	cmp	w23, w21
   10500:      	str	x19, [sp, #0x60]
   10504:      	add	x19, sp, #0x70
   10508:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   1050c:      	ldr	x21, [sp, #0x78]
   10510:      	ldp	x2, x24, [sp, #0x50]
   10514:      	str	x21, [sp, #0x48]
   10518:      	b	0x10568 <generic_kprobe_path+0x5738>
   1051c:      	add	x2, x24, #0x10
   10520:      	mov	w8, #0x4                // =4
   10524:      	add	x9, sp, #0x98
   10528:      	add	x0, sp, #0x98
   1052c:      	mov	w1, #0x8                // =8
   10530:      	blr	x8
   10534:      	ldr	x8, [sp, #0x58]
   10538:      	ldr	x9, [sp, #0x98]
   1053c:      	cmp	x8, x9
   10540:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   10544:      	add	x2, x24, #0x18
   10548:      	mov	w8, #0x4                // =4
   1054c:      	mov	x0, x22
   10550:      	mov	w1, #0x8                // =8
   10554:      	blr	x8
   10558:      	ldr	x24, [sp, #0x98]
   1055c:      	ldr	x21, [sp, #0x48]
   10560:      	add	x2, x24, #0x20
   10564:      	stp	x2, x24, [sp, #0x50]
   10568:      	ldr	x8, [sp, #0x30]
   1056c:      	cmp	x21, x8
   10570:      	b.ne	0x10580 <generic_kprobe_path+0x5750>
   10574:      	ldr	x8, [sp, #0x38]
   10578:      	cmp	x2, x8
   1057c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   10580:      	mov	w8, #0x4                // =4
   10584:      	add	x0, sp, #0x70
   10588:      	mov	w1, #0x8                // =8
   1058c:      	blr	x8
   10590:      	ldr	x8, [sp, #0x70]
   10594:      	cmp	x21, x8
   10598:      	b.eq	0x10688 <generic_kprobe_path+0x5858>
   1059c:      	add	x23, x21, #0x18
   105a0:      	mov	w8, #0x4                // =4
   105a4:      	add	x9, sp, #0x98
   105a8:      	add	x0, sp, #0x98
   105ac:      	mov	w1, #0x8                // =8
   105b0:      	mov	x2, x23
   105b4:      	blr	x8
   105b8:      	ldr	x8, [sp, #0x98]
   105bc:      	cmp	x8, x21
   105c0:      	b.eq	0x10688 <generic_kprobe_path+0x5858>
   105c4:      	mov	w8, #0x4                // =4
   105c8:      	add	x9, sp, #0x78
   105cc:      	add	x0, sp, #0x78
   105d0:      	mov	w1, #0x8                // =8
   105d4:      	mov	x2, x23
   105d8:      	blr	x8
   105dc:      	add	x2, x21, #0x20
   105e0:      	mov	w8, #0x4                // =4
   105e4:      	mov	w9, #0x10               // =16
   105e8:      	add	x10, sp, #0x80
   105ec:      	add	x0, sp, #0x80
   105f0:      	mov	w1, #0x10               // =16
   105f4:      	blr	x8
   105f8:      	ldr	w21, [sp, #0x84]
   105fc:      	ldr	x8, [sp, #0x40]
   10600:      	ldr	x10, [sp, #0x60]
   10604:      	sub	x12, x10, x8
   10608:      	ldr	w23, [sp, #0x68]
   1060c:      	subs	w10, w21, w23
   10610:      	ldr	x9, [sp, #0x88]
   10614:      	csel	w10, wzr, w10, lo
   10618:      	cmp	w23, w21
   1061c:      	csel	w11, w23, w21, lo
   10620:      	cinc	w13, w11, hi
   10624:      	sub	w14, w23, w13
   10628:      	subs	x12, x12, x13
   1062c:      	str	w14, [sp, #0x68]
   10630:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   10634:      	cmp	x12, #0xfff
   10638:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   1063c:      	cmp	w23, w21
   10640:      	b.ls	0x1064c <generic_kprobe_path+0x581c>
   10644:      	mov	w13, #0x2f              // =47
   10648:      	strb	w13, [x8, x12]
   1064c:      	add	x19, x8, x12
   10650:      	cmp	w23, w21
   10654:      	add	x2, x9, x10
   10658:      	and	w1, w11, #0xff
   1065c:      	mov	w8, #0x4                // =4
   10660:      	cinc	x0, x19, hi
   10664:      	blr	x8
   10668:      	cmp	w23, w21
   1066c:      	str	x19, [sp, #0x60]
   10670:      	add	x19, sp, #0x70
   10674:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   10678:      	ldr	x21, [sp, #0x78]
   1067c:      	ldp	x2, x24, [sp, #0x50]
   10680:      	str	x21, [sp, #0x48]
   10684:      	b	0x106d4 <generic_kprobe_path+0x58a4>
   10688:      	add	x2, x24, #0x10
   1068c:      	mov	w8, #0x4                // =4
   10690:      	add	x9, sp, #0x98
   10694:      	add	x0, sp, #0x98
   10698:      	mov	w1, #0x8                // =8
   1069c:      	blr	x8
   106a0:      	ldr	x8, [sp, #0x58]
   106a4:      	ldr	x9, [sp, #0x98]
   106a8:      	cmp	x8, x9
   106ac:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   106b0:      	add	x2, x24, #0x18
   106b4:      	mov	w8, #0x4                // =4
   106b8:      	mov	x0, x22
   106bc:      	mov	w1, #0x8                // =8
   106c0:      	blr	x8
   106c4:      	ldr	x24, [sp, #0x98]
   106c8:      	ldr	x21, [sp, #0x48]
   106cc:      	add	x2, x24, #0x20
   106d0:      	stp	x2, x24, [sp, #0x50]
   106d4:      	ldr	x8, [sp, #0x30]
   106d8:      	cmp	x21, x8
   106dc:      	b.ne	0x106ec <generic_kprobe_path+0x58bc>
   106e0:      	ldr	x8, [sp, #0x38]
   106e4:      	cmp	x2, x8
   106e8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   106ec:      	mov	w8, #0x4                // =4
   106f0:      	add	x0, sp, #0x70
   106f4:      	mov	w1, #0x8                // =8
   106f8:      	blr	x8
   106fc:      	ldr	x8, [sp, #0x70]
   10700:      	cmp	x21, x8
   10704:      	b.eq	0x107f4 <generic_kprobe_path+0x59c4>
   10708:      	add	x23, x21, #0x18
   1070c:      	mov	w8, #0x4                // =4
   10710:      	add	x9, sp, #0x98
   10714:      	add	x0, sp, #0x98
   10718:      	mov	w1, #0x8                // =8
   1071c:      	mov	x2, x23
   10720:      	blr	x8
   10724:      	ldr	x8, [sp, #0x98]
   10728:      	cmp	x8, x21
   1072c:      	b.eq	0x107f4 <generic_kprobe_path+0x59c4>
   10730:      	mov	w8, #0x4                // =4
   10734:      	add	x9, sp, #0x78
   10738:      	add	x0, sp, #0x78
   1073c:      	mov	w1, #0x8                // =8
   10740:      	mov	x2, x23
   10744:      	blr	x8
   10748:      	add	x2, x21, #0x20
   1074c:      	mov	w8, #0x4                // =4
   10750:      	mov	w9, #0x10               // =16
   10754:      	add	x10, sp, #0x80
   10758:      	add	x0, sp, #0x80
   1075c:      	mov	w1, #0x10               // =16
   10760:      	blr	x8
   10764:      	ldr	w21, [sp, #0x84]
   10768:      	ldr	x8, [sp, #0x40]
   1076c:      	ldr	x10, [sp, #0x60]
   10770:      	sub	x12, x10, x8
   10774:      	ldr	w23, [sp, #0x68]
   10778:      	subs	w10, w21, w23
   1077c:      	ldr	x9, [sp, #0x88]
   10780:      	csel	w10, wzr, w10, lo
   10784:      	cmp	w23, w21
   10788:      	csel	w11, w23, w21, lo
   1078c:      	cinc	w13, w11, hi
   10790:      	sub	w14, w23, w13
   10794:      	subs	x12, x12, x13
   10798:      	str	w14, [sp, #0x68]
   1079c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   107a0:      	cmp	x12, #0xfff
   107a4:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   107a8:      	cmp	w23, w21
   107ac:      	b.ls	0x107b8 <generic_kprobe_path+0x5988>
   107b0:      	mov	w13, #0x2f              // =47
   107b4:      	strb	w13, [x8, x12]
   107b8:      	add	x19, x8, x12
   107bc:      	cmp	w23, w21
   107c0:      	add	x2, x9, x10
   107c4:      	and	w1, w11, #0xff
   107c8:      	mov	w8, #0x4                // =4
   107cc:      	cinc	x0, x19, hi
   107d0:      	blr	x8
   107d4:      	cmp	w23, w21
   107d8:      	str	x19, [sp, #0x60]
   107dc:      	add	x19, sp, #0x70
   107e0:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   107e4:      	ldr	x21, [sp, #0x78]
   107e8:      	ldp	x2, x24, [sp, #0x50]
   107ec:      	str	x21, [sp, #0x48]
   107f0:      	b	0x10840 <generic_kprobe_path+0x5a10>
   107f4:      	add	x2, x24, #0x10
   107f8:      	mov	w8, #0x4                // =4
   107fc:      	add	x9, sp, #0x98
   10800:      	add	x0, sp, #0x98
   10804:      	mov	w1, #0x8                // =8
   10808:      	blr	x8
   1080c:      	ldr	x8, [sp, #0x58]
   10810:      	ldr	x9, [sp, #0x98]
   10814:      	cmp	x8, x9
   10818:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1081c:      	add	x2, x24, #0x18
   10820:      	mov	w8, #0x4                // =4
   10824:      	mov	x0, x22
   10828:      	mov	w1, #0x8                // =8
   1082c:      	blr	x8
   10830:      	ldr	x24, [sp, #0x98]
   10834:      	ldr	x21, [sp, #0x48]
   10838:      	add	x2, x24, #0x20
   1083c:      	stp	x2, x24, [sp, #0x50]
   10840:      	ldr	x8, [sp, #0x30]
   10844:      	cmp	x21, x8
   10848:      	b.ne	0x10858 <generic_kprobe_path+0x5a28>
   1084c:      	ldr	x8, [sp, #0x38]
   10850:      	cmp	x2, x8
   10854:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   10858:      	mov	w8, #0x4                // =4
   1085c:      	add	x0, sp, #0x70
   10860:      	mov	w1, #0x8                // =8
   10864:      	blr	x8
   10868:      	ldr	x8, [sp, #0x70]
   1086c:      	cmp	x21, x8
   10870:      	b.eq	0x10960 <generic_kprobe_path+0x5b30>
   10874:      	add	x23, x21, #0x18
   10878:      	mov	w8, #0x4                // =4
   1087c:      	add	x9, sp, #0x98
   10880:      	add	x0, sp, #0x98
   10884:      	mov	w1, #0x8                // =8
   10888:      	mov	x2, x23
   1088c:      	blr	x8
   10890:      	ldr	x8, [sp, #0x98]
   10894:      	cmp	x8, x21
   10898:      	b.eq	0x10960 <generic_kprobe_path+0x5b30>
   1089c:      	mov	w8, #0x4                // =4
   108a0:      	add	x9, sp, #0x78
   108a4:      	add	x0, sp, #0x78
   108a8:      	mov	w1, #0x8                // =8
   108ac:      	mov	x2, x23
   108b0:      	blr	x8
   108b4:      	add	x2, x21, #0x20
   108b8:      	mov	w8, #0x4                // =4
   108bc:      	mov	w9, #0x10               // =16
   108c0:      	add	x10, sp, #0x80
   108c4:      	add	x0, sp, #0x80
   108c8:      	mov	w1, #0x10               // =16
   108cc:      	blr	x8
   108d0:      	ldr	w21, [sp, #0x84]
   108d4:      	ldr	x8, [sp, #0x40]
   108d8:      	ldr	x10, [sp, #0x60]
   108dc:      	sub	x12, x10, x8
   108e0:      	ldr	w23, [sp, #0x68]
   108e4:      	subs	w10, w21, w23
   108e8:      	ldr	x9, [sp, #0x88]
   108ec:      	csel	w10, wzr, w10, lo
   108f0:      	cmp	w23, w21
   108f4:      	csel	w11, w23, w21, lo
   108f8:      	cinc	w13, w11, hi
   108fc:      	sub	w14, w23, w13
   10900:      	subs	x12, x12, x13
   10904:      	str	w14, [sp, #0x68]
   10908:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   1090c:      	cmp	x12, #0xfff
   10910:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   10914:      	cmp	w23, w21
   10918:      	b.ls	0x10924 <generic_kprobe_path+0x5af4>
   1091c:      	mov	w13, #0x2f              // =47
   10920:      	strb	w13, [x8, x12]
   10924:      	add	x19, x8, x12
   10928:      	cmp	w23, w21
   1092c:      	add	x2, x9, x10
   10930:      	and	w1, w11, #0xff
   10934:      	mov	w8, #0x4                // =4
   10938:      	cinc	x0, x19, hi
   1093c:      	blr	x8
   10940:      	cmp	w23, w21
   10944:      	str	x19, [sp, #0x60]
   10948:      	add	x19, sp, #0x70
   1094c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   10950:      	ldr	x21, [sp, #0x78]
   10954:      	ldp	x2, x24, [sp, #0x50]
   10958:      	str	x21, [sp, #0x48]
   1095c:      	b	0x109ac <generic_kprobe_path+0x5b7c>
   10960:      	add	x2, x24, #0x10
   10964:      	mov	w8, #0x4                // =4
   10968:      	add	x9, sp, #0x98
   1096c:      	add	x0, sp, #0x98
   10970:      	mov	w1, #0x8                // =8
   10974:      	blr	x8
   10978:      	ldr	x8, [sp, #0x58]
   1097c:      	ldr	x9, [sp, #0x98]
   10980:      	cmp	x8, x9
   10984:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   10988:      	add	x2, x24, #0x18
   1098c:      	mov	w8, #0x4                // =4
   10990:      	mov	x0, x22
   10994:      	mov	w1, #0x8                // =8
   10998:      	blr	x8
   1099c:      	ldr	x24, [sp, #0x98]
   109a0:      	ldr	x21, [sp, #0x48]
   109a4:      	add	x2, x24, #0x20
   109a8:      	stp	x2, x24, [sp, #0x50]
   109ac:      	ldr	x8, [sp, #0x30]
   109b0:      	cmp	x21, x8
   109b4:      	b.ne	0x109c4 <generic_kprobe_path+0x5b94>
   109b8:      	ldr	x8, [sp, #0x38]
   109bc:      	cmp	x2, x8
   109c0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   109c4:      	mov	w8, #0x4                // =4
   109c8:      	add	x0, sp, #0x70
   109cc:      	mov	w1, #0x8                // =8
   109d0:      	blr	x8
   109d4:      	ldr	x8, [sp, #0x70]
   109d8:      	cmp	x21, x8
   109dc:      	b.eq	0x10acc <generic_kprobe_path+0x5c9c>
   109e0:      	add	x23, x21, #0x18
   109e4:      	mov	w8, #0x4                // =4
   109e8:      	add	x9, sp, #0x98
   109ec:      	add	x0, sp, #0x98
   109f0:      	mov	w1, #0x8                // =8
   109f4:      	mov	x2, x23
   109f8:      	blr	x8
   109fc:      	ldr	x8, [sp, #0x98]
   10a00:      	cmp	x8, x21
   10a04:      	b.eq	0x10acc <generic_kprobe_path+0x5c9c>
   10a08:      	mov	w8, #0x4                // =4
   10a0c:      	add	x9, sp, #0x78
   10a10:      	add	x0, sp, #0x78
   10a14:      	mov	w1, #0x8                // =8
   10a18:      	mov	x2, x23
   10a1c:      	blr	x8
   10a20:      	add	x2, x21, #0x20
   10a24:      	mov	w8, #0x4                // =4
   10a28:      	mov	w9, #0x10               // =16
   10a2c:      	add	x10, sp, #0x80
   10a30:      	add	x0, sp, #0x80
   10a34:      	mov	w1, #0x10               // =16
   10a38:      	blr	x8
   10a3c:      	ldr	w21, [sp, #0x84]
   10a40:      	ldr	x8, [sp, #0x40]
   10a44:      	ldr	x10, [sp, #0x60]
   10a48:      	sub	x12, x10, x8
   10a4c:      	ldr	w23, [sp, #0x68]
   10a50:      	subs	w10, w21, w23
   10a54:      	ldr	x9, [sp, #0x88]
   10a58:      	csel	w10, wzr, w10, lo
   10a5c:      	cmp	w23, w21
   10a60:      	csel	w11, w23, w21, lo
   10a64:      	cinc	w13, w11, hi
   10a68:      	sub	w14, w23, w13
   10a6c:      	subs	x12, x12, x13
   10a70:      	str	w14, [sp, #0x68]
   10a74:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   10a78:      	cmp	x12, #0xfff
   10a7c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   10a80:      	cmp	w23, w21
   10a84:      	b.ls	0x10a90 <generic_kprobe_path+0x5c60>
   10a88:      	mov	w13, #0x2f              // =47
   10a8c:      	strb	w13, [x8, x12]
   10a90:      	add	x19, x8, x12
   10a94:      	cmp	w23, w21
   10a98:      	add	x2, x9, x10
   10a9c:      	and	w1, w11, #0xff
   10aa0:      	mov	w8, #0x4                // =4
   10aa4:      	cinc	x0, x19, hi
   10aa8:      	blr	x8
   10aac:      	cmp	w23, w21
   10ab0:      	str	x19, [sp, #0x60]
   10ab4:      	add	x19, sp, #0x70
   10ab8:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   10abc:      	ldr	x21, [sp, #0x78]
   10ac0:      	ldp	x2, x24, [sp, #0x50]
   10ac4:      	str	x21, [sp, #0x48]
   10ac8:      	b	0x10b18 <generic_kprobe_path+0x5ce8>
   10acc:      	add	x2, x24, #0x10
   10ad0:      	mov	w8, #0x4                // =4
   10ad4:      	add	x9, sp, #0x98
   10ad8:      	add	x0, sp, #0x98
   10adc:      	mov	w1, #0x8                // =8
   10ae0:      	blr	x8
   10ae4:      	ldr	x8, [sp, #0x58]
   10ae8:      	ldr	x9, [sp, #0x98]
   10aec:      	cmp	x8, x9
   10af0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   10af4:      	add	x2, x24, #0x18
   10af8:      	mov	w8, #0x4                // =4
   10afc:      	mov	x0, x22
   10b00:      	mov	w1, #0x8                // =8
   10b04:      	blr	x8
   10b08:      	ldr	x24, [sp, #0x98]
   10b0c:      	ldr	x21, [sp, #0x48]
   10b10:      	add	x2, x24, #0x20
   10b14:      	stp	x2, x24, [sp, #0x50]
   10b18:      	ldr	x8, [sp, #0x30]
   10b1c:      	cmp	x21, x8
   10b20:      	b.ne	0x10b30 <generic_kprobe_path+0x5d00>
   10b24:      	ldr	x8, [sp, #0x38]
   10b28:      	cmp	x2, x8
   10b2c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   10b30:      	mov	w8, #0x4                // =4
   10b34:      	add	x0, sp, #0x70
   10b38:      	mov	w1, #0x8                // =8
   10b3c:      	blr	x8
   10b40:      	ldr	x8, [sp, #0x70]
   10b44:      	cmp	x21, x8
   10b48:      	b.eq	0x10c38 <generic_kprobe_path+0x5e08>
   10b4c:      	add	x23, x21, #0x18
   10b50:      	mov	w8, #0x4                // =4
   10b54:      	add	x9, sp, #0x98
   10b58:      	add	x0, sp, #0x98
   10b5c:      	mov	w1, #0x8                // =8
   10b60:      	mov	x2, x23
   10b64:      	blr	x8
   10b68:      	ldr	x8, [sp, #0x98]
   10b6c:      	cmp	x8, x21
   10b70:      	b.eq	0x10c38 <generic_kprobe_path+0x5e08>
   10b74:      	mov	w8, #0x4                // =4
   10b78:      	add	x9, sp, #0x78
   10b7c:      	add	x0, sp, #0x78
   10b80:      	mov	w1, #0x8                // =8
   10b84:      	mov	x2, x23
   10b88:      	blr	x8
   10b8c:      	add	x2, x21, #0x20
   10b90:      	mov	w8, #0x4                // =4
   10b94:      	mov	w9, #0x10               // =16
   10b98:      	add	x10, sp, #0x80
   10b9c:      	add	x0, sp, #0x80
   10ba0:      	mov	w1, #0x10               // =16
   10ba4:      	blr	x8
   10ba8:      	ldr	w21, [sp, #0x84]
   10bac:      	ldr	x8, [sp, #0x40]
   10bb0:      	ldr	x10, [sp, #0x60]
   10bb4:      	sub	x12, x10, x8
   10bb8:      	ldr	w23, [sp, #0x68]
   10bbc:      	subs	w10, w21, w23
   10bc0:      	ldr	x9, [sp, #0x88]
   10bc4:      	csel	w10, wzr, w10, lo
   10bc8:      	cmp	w23, w21
   10bcc:      	csel	w11, w23, w21, lo
   10bd0:      	cinc	w13, w11, hi
   10bd4:      	sub	w14, w23, w13
   10bd8:      	subs	x12, x12, x13
   10bdc:      	str	w14, [sp, #0x68]
   10be0:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   10be4:      	cmp	x12, #0xfff
   10be8:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   10bec:      	cmp	w23, w21
   10bf0:      	b.ls	0x10bfc <generic_kprobe_path+0x5dcc>
   10bf4:      	mov	w13, #0x2f              // =47
   10bf8:      	strb	w13, [x8, x12]
   10bfc:      	add	x19, x8, x12
   10c00:      	cmp	w23, w21
   10c04:      	add	x2, x9, x10
   10c08:      	and	w1, w11, #0xff
   10c0c:      	mov	w8, #0x4                // =4
   10c10:      	cinc	x0, x19, hi
   10c14:      	blr	x8
   10c18:      	cmp	w23, w21
   10c1c:      	str	x19, [sp, #0x60]
   10c20:      	add	x19, sp, #0x70
   10c24:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   10c28:      	ldr	x21, [sp, #0x78]
   10c2c:      	ldp	x2, x24, [sp, #0x50]
   10c30:      	str	x21, [sp, #0x48]
   10c34:      	b	0x10c84 <generic_kprobe_path+0x5e54>
   10c38:      	add	x2, x24, #0x10
   10c3c:      	mov	w8, #0x4                // =4
   10c40:      	add	x9, sp, #0x98
   10c44:      	add	x0, sp, #0x98
   10c48:      	mov	w1, #0x8                // =8
   10c4c:      	blr	x8
   10c50:      	ldr	x8, [sp, #0x58]
   10c54:      	ldr	x9, [sp, #0x98]
   10c58:      	cmp	x8, x9
   10c5c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   10c60:      	add	x2, x24, #0x18
   10c64:      	mov	w8, #0x4                // =4
   10c68:      	mov	x0, x22
   10c6c:      	mov	w1, #0x8                // =8
   10c70:      	blr	x8
   10c74:      	ldr	x24, [sp, #0x98]
   10c78:      	ldr	x21, [sp, #0x48]
   10c7c:      	add	x2, x24, #0x20
   10c80:      	stp	x2, x24, [sp, #0x50]
   10c84:      	ldr	x8, [sp, #0x30]
   10c88:      	cmp	x21, x8
   10c8c:      	b.ne	0x10c9c <generic_kprobe_path+0x5e6c>
   10c90:      	ldr	x8, [sp, #0x38]
   10c94:      	cmp	x2, x8
   10c98:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   10c9c:      	mov	w8, #0x4                // =4
   10ca0:      	add	x0, sp, #0x70
   10ca4:      	mov	w1, #0x8                // =8
   10ca8:      	blr	x8
   10cac:      	ldr	x8, [sp, #0x70]
   10cb0:      	cmp	x21, x8
   10cb4:      	b.eq	0x10da4 <generic_kprobe_path+0x5f74>
   10cb8:      	add	x23, x21, #0x18
   10cbc:      	mov	w8, #0x4                // =4
   10cc0:      	add	x9, sp, #0x98
   10cc4:      	add	x0, sp, #0x98
   10cc8:      	mov	w1, #0x8                // =8
   10ccc:      	mov	x2, x23
   10cd0:      	blr	x8
   10cd4:      	ldr	x8, [sp, #0x98]
   10cd8:      	cmp	x8, x21
   10cdc:      	b.eq	0x10da4 <generic_kprobe_path+0x5f74>
   10ce0:      	mov	w8, #0x4                // =4
   10ce4:      	add	x9, sp, #0x78
   10ce8:      	add	x0, sp, #0x78
   10cec:      	mov	w1, #0x8                // =8
   10cf0:      	mov	x2, x23
   10cf4:      	blr	x8
   10cf8:      	add	x2, x21, #0x20
   10cfc:      	mov	w8, #0x4                // =4
   10d00:      	mov	w9, #0x10               // =16
   10d04:      	add	x10, sp, #0x80
   10d08:      	add	x0, sp, #0x80
   10d0c:      	mov	w1, #0x10               // =16
   10d10:      	blr	x8
   10d14:      	ldr	w21, [sp, #0x84]
   10d18:      	ldr	x8, [sp, #0x40]
   10d1c:      	ldr	x10, [sp, #0x60]
   10d20:      	sub	x12, x10, x8
   10d24:      	ldr	w23, [sp, #0x68]
   10d28:      	subs	w10, w21, w23
   10d2c:      	ldr	x9, [sp, #0x88]
   10d30:      	csel	w10, wzr, w10, lo
   10d34:      	cmp	w23, w21
   10d38:      	csel	w11, w23, w21, lo
   10d3c:      	cinc	w13, w11, hi
   10d40:      	sub	w14, w23, w13
   10d44:      	subs	x12, x12, x13
   10d48:      	str	w14, [sp, #0x68]
   10d4c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   10d50:      	cmp	x12, #0xfff
   10d54:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   10d58:      	cmp	w23, w21
   10d5c:      	b.ls	0x10d68 <generic_kprobe_path+0x5f38>
   10d60:      	mov	w13, #0x2f              // =47
   10d64:      	strb	w13, [x8, x12]
   10d68:      	add	x19, x8, x12
   10d6c:      	cmp	w23, w21
   10d70:      	add	x2, x9, x10
   10d74:      	and	w1, w11, #0xff
   10d78:      	mov	w8, #0x4                // =4
   10d7c:      	cinc	x0, x19, hi
   10d80:      	blr	x8
   10d84:      	cmp	w23, w21
   10d88:      	str	x19, [sp, #0x60]
   10d8c:      	add	x19, sp, #0x70
   10d90:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   10d94:      	ldr	x21, [sp, #0x78]
   10d98:      	ldp	x2, x24, [sp, #0x50]
   10d9c:      	str	x21, [sp, #0x48]
   10da0:      	b	0x10df0 <generic_kprobe_path+0x5fc0>
   10da4:      	add	x2, x24, #0x10
   10da8:      	mov	w8, #0x4                // =4
   10dac:      	add	x9, sp, #0x98
   10db0:      	add	x0, sp, #0x98
   10db4:      	mov	w1, #0x8                // =8
   10db8:      	blr	x8
   10dbc:      	ldr	x8, [sp, #0x58]
   10dc0:      	ldr	x9, [sp, #0x98]
   10dc4:      	cmp	x8, x9
   10dc8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   10dcc:      	add	x2, x24, #0x18
   10dd0:      	mov	w8, #0x4                // =4
   10dd4:      	mov	x0, x22
   10dd8:      	mov	w1, #0x8                // =8
   10ddc:      	blr	x8
   10de0:      	ldr	x24, [sp, #0x98]
   10de4:      	ldr	x21, [sp, #0x48]
   10de8:      	add	x2, x24, #0x20
   10dec:      	stp	x2, x24, [sp, #0x50]
   10df0:      	ldr	x8, [sp, #0x30]
   10df4:      	cmp	x21, x8
   10df8:      	b.ne	0x10e08 <generic_kprobe_path+0x5fd8>
   10dfc:      	ldr	x8, [sp, #0x38]
   10e00:      	cmp	x2, x8
   10e04:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   10e08:      	mov	w8, #0x4                // =4
   10e0c:      	add	x0, sp, #0x70
   10e10:      	mov	w1, #0x8                // =8
   10e14:      	blr	x8
   10e18:      	ldr	x8, [sp, #0x70]
   10e1c:      	cmp	x21, x8
   10e20:      	b.eq	0x10f10 <generic_kprobe_path+0x60e0>
   10e24:      	add	x23, x21, #0x18
   10e28:      	mov	w8, #0x4                // =4
   10e2c:      	add	x9, sp, #0x98
   10e30:      	add	x0, sp, #0x98
   10e34:      	mov	w1, #0x8                // =8
   10e38:      	mov	x2, x23
   10e3c:      	blr	x8
   10e40:      	ldr	x8, [sp, #0x98]
   10e44:      	cmp	x8, x21
   10e48:      	b.eq	0x10f10 <generic_kprobe_path+0x60e0>
   10e4c:      	mov	w8, #0x4                // =4
   10e50:      	add	x9, sp, #0x78
   10e54:      	add	x0, sp, #0x78
   10e58:      	mov	w1, #0x8                // =8
   10e5c:      	mov	x2, x23
   10e60:      	blr	x8
   10e64:      	add	x2, x21, #0x20
   10e68:      	mov	w8, #0x4                // =4
   10e6c:      	mov	w9, #0x10               // =16
   10e70:      	add	x10, sp, #0x80
   10e74:      	add	x0, sp, #0x80
   10e78:      	mov	w1, #0x10               // =16
   10e7c:      	blr	x8
   10e80:      	ldr	w21, [sp, #0x84]
   10e84:      	ldr	x8, [sp, #0x40]
   10e88:      	ldr	x10, [sp, #0x60]
   10e8c:      	sub	x12, x10, x8
   10e90:      	ldr	w23, [sp, #0x68]
   10e94:      	subs	w10, w21, w23
   10e98:      	ldr	x9, [sp, #0x88]
   10e9c:      	csel	w10, wzr, w10, lo
   10ea0:      	cmp	w23, w21
   10ea4:      	csel	w11, w23, w21, lo
   10ea8:      	cinc	w13, w11, hi
   10eac:      	sub	w14, w23, w13
   10eb0:      	subs	x12, x12, x13
   10eb4:      	str	w14, [sp, #0x68]
   10eb8:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   10ebc:      	cmp	x12, #0xfff
   10ec0:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   10ec4:      	cmp	w23, w21
   10ec8:      	b.ls	0x10ed4 <generic_kprobe_path+0x60a4>
   10ecc:      	mov	w13, #0x2f              // =47
   10ed0:      	strb	w13, [x8, x12]
   10ed4:      	add	x19, x8, x12
   10ed8:      	cmp	w23, w21
   10edc:      	add	x2, x9, x10
   10ee0:      	and	w1, w11, #0xff
   10ee4:      	mov	w8, #0x4                // =4
   10ee8:      	cinc	x0, x19, hi
   10eec:      	blr	x8
   10ef0:      	cmp	w23, w21
   10ef4:      	str	x19, [sp, #0x60]
   10ef8:      	add	x19, sp, #0x70
   10efc:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   10f00:      	ldr	x21, [sp, #0x78]
   10f04:      	ldp	x2, x24, [sp, #0x50]
   10f08:      	str	x21, [sp, #0x48]
   10f0c:      	b	0x10f5c <generic_kprobe_path+0x612c>
   10f10:      	add	x2, x24, #0x10
   10f14:      	mov	w8, #0x4                // =4
   10f18:      	add	x9, sp, #0x98
   10f1c:      	add	x0, sp, #0x98
   10f20:      	mov	w1, #0x8                // =8
   10f24:      	blr	x8
   10f28:      	ldr	x8, [sp, #0x58]
   10f2c:      	ldr	x9, [sp, #0x98]
   10f30:      	cmp	x8, x9
   10f34:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   10f38:      	add	x2, x24, #0x18
   10f3c:      	mov	w8, #0x4                // =4
   10f40:      	mov	x0, x22
   10f44:      	mov	w1, #0x8                // =8
   10f48:      	blr	x8
   10f4c:      	ldr	x24, [sp, #0x98]
   10f50:      	ldr	x21, [sp, #0x48]
   10f54:      	add	x2, x24, #0x20
   10f58:      	stp	x2, x24, [sp, #0x50]
   10f5c:      	ldr	x8, [sp, #0x30]
   10f60:      	cmp	x21, x8
   10f64:      	b.ne	0x10f74 <generic_kprobe_path+0x6144>
   10f68:      	ldr	x8, [sp, #0x38]
   10f6c:      	cmp	x2, x8
   10f70:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   10f74:      	mov	w8, #0x4                // =4
   10f78:      	add	x0, sp, #0x70
   10f7c:      	mov	w1, #0x8                // =8
   10f80:      	blr	x8
   10f84:      	ldr	x8, [sp, #0x70]
   10f88:      	cmp	x21, x8
   10f8c:      	b.eq	0x1107c <generic_kprobe_path+0x624c>
   10f90:      	add	x23, x21, #0x18
   10f94:      	mov	w8, #0x4                // =4
   10f98:      	add	x9, sp, #0x98
   10f9c:      	add	x0, sp, #0x98
   10fa0:      	mov	w1, #0x8                // =8
   10fa4:      	mov	x2, x23
   10fa8:      	blr	x8
   10fac:      	ldr	x8, [sp, #0x98]
   10fb0:      	cmp	x8, x21
   10fb4:      	b.eq	0x1107c <generic_kprobe_path+0x624c>
   10fb8:      	mov	w8, #0x4                // =4
   10fbc:      	add	x9, sp, #0x78
   10fc0:      	add	x0, sp, #0x78
   10fc4:      	mov	w1, #0x8                // =8
   10fc8:      	mov	x2, x23
   10fcc:      	blr	x8
   10fd0:      	add	x2, x21, #0x20
   10fd4:      	mov	w8, #0x4                // =4
   10fd8:      	mov	w9, #0x10               // =16
   10fdc:      	add	x10, sp, #0x80
   10fe0:      	add	x0, sp, #0x80
   10fe4:      	mov	w1, #0x10               // =16
   10fe8:      	blr	x8
   10fec:      	ldr	w21, [sp, #0x84]
   10ff0:      	ldr	x8, [sp, #0x40]
   10ff4:      	ldr	x10, [sp, #0x60]
   10ff8:      	sub	x12, x10, x8
   10ffc:      	ldr	w23, [sp, #0x68]
   11000:      	subs	w10, w21, w23
   11004:      	ldr	x9, [sp, #0x88]
   11008:      	csel	w10, wzr, w10, lo
   1100c:      	cmp	w23, w21
   11010:      	csel	w11, w23, w21, lo
   11014:      	cinc	w13, w11, hi
   11018:      	sub	w14, w23, w13
   1101c:      	subs	x12, x12, x13
   11020:      	str	w14, [sp, #0x68]
   11024:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   11028:      	cmp	x12, #0xfff
   1102c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   11030:      	cmp	w23, w21
   11034:      	b.ls	0x11040 <generic_kprobe_path+0x6210>
   11038:      	mov	w13, #0x2f              // =47
   1103c:      	strb	w13, [x8, x12]
   11040:      	add	x19, x8, x12
   11044:      	cmp	w23, w21
   11048:      	add	x2, x9, x10
   1104c:      	and	w1, w11, #0xff
   11050:      	mov	w8, #0x4                // =4
   11054:      	cinc	x0, x19, hi
   11058:      	blr	x8
   1105c:      	cmp	w23, w21
   11060:      	str	x19, [sp, #0x60]
   11064:      	add	x19, sp, #0x70
   11068:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   1106c:      	ldr	x21, [sp, #0x78]
   11070:      	ldp	x2, x24, [sp, #0x50]
   11074:      	str	x21, [sp, #0x48]
   11078:      	b	0x110c8 <generic_kprobe_path+0x6298>
   1107c:      	add	x2, x24, #0x10
   11080:      	mov	w8, #0x4                // =4
   11084:      	add	x9, sp, #0x98
   11088:      	add	x0, sp, #0x98
   1108c:      	mov	w1, #0x8                // =8
   11090:      	blr	x8
   11094:      	ldr	x8, [sp, #0x58]
   11098:      	ldr	x9, [sp, #0x98]
   1109c:      	cmp	x8, x9
   110a0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   110a4:      	add	x2, x24, #0x18
   110a8:      	mov	w8, #0x4                // =4
   110ac:      	mov	x0, x22
   110b0:      	mov	w1, #0x8                // =8
   110b4:      	blr	x8
   110b8:      	ldr	x24, [sp, #0x98]
   110bc:      	ldr	x21, [sp, #0x48]
   110c0:      	add	x2, x24, #0x20
   110c4:      	stp	x2, x24, [sp, #0x50]
   110c8:      	ldr	x8, [sp, #0x30]
   110cc:      	cmp	x21, x8
   110d0:      	b.ne	0x110e0 <generic_kprobe_path+0x62b0>
   110d4:      	ldr	x8, [sp, #0x38]
   110d8:      	cmp	x2, x8
   110dc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   110e0:      	mov	w8, #0x4                // =4
   110e4:      	add	x0, sp, #0x70
   110e8:      	mov	w1, #0x8                // =8
   110ec:      	blr	x8
   110f0:      	ldr	x8, [sp, #0x70]
   110f4:      	cmp	x21, x8
   110f8:      	b.eq	0x111e8 <generic_kprobe_path+0x63b8>
   110fc:      	add	x23, x21, #0x18
   11100:      	mov	w8, #0x4                // =4
   11104:      	add	x9, sp, #0x98
   11108:      	add	x0, sp, #0x98
   1110c:      	mov	w1, #0x8                // =8
   11110:      	mov	x2, x23
   11114:      	blr	x8
   11118:      	ldr	x8, [sp, #0x98]
   1111c:      	cmp	x8, x21
   11120:      	b.eq	0x111e8 <generic_kprobe_path+0x63b8>
   11124:      	mov	w8, #0x4                // =4
   11128:      	add	x9, sp, #0x78
   1112c:      	add	x0, sp, #0x78
   11130:      	mov	w1, #0x8                // =8
   11134:      	mov	x2, x23
   11138:      	blr	x8
   1113c:      	add	x2, x21, #0x20
   11140:      	mov	w8, #0x4                // =4
   11144:      	mov	w9, #0x10               // =16
   11148:      	add	x10, sp, #0x80
   1114c:      	add	x0, sp, #0x80
   11150:      	mov	w1, #0x10               // =16
   11154:      	blr	x8
   11158:      	ldr	w21, [sp, #0x84]
   1115c:      	ldr	x8, [sp, #0x40]
   11160:      	ldr	x10, [sp, #0x60]
   11164:      	sub	x12, x10, x8
   11168:      	ldr	w23, [sp, #0x68]
   1116c:      	subs	w10, w21, w23
   11170:      	ldr	x9, [sp, #0x88]
   11174:      	csel	w10, wzr, w10, lo
   11178:      	cmp	w23, w21
   1117c:      	csel	w11, w23, w21, lo
   11180:      	cinc	w13, w11, hi
   11184:      	sub	w14, w23, w13
   11188:      	subs	x12, x12, x13
   1118c:      	str	w14, [sp, #0x68]
   11190:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   11194:      	cmp	x12, #0xfff
   11198:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   1119c:      	cmp	w23, w21
   111a0:      	b.ls	0x111ac <generic_kprobe_path+0x637c>
   111a4:      	mov	w13, #0x2f              // =47
   111a8:      	strb	w13, [x8, x12]
   111ac:      	add	x19, x8, x12
   111b0:      	cmp	w23, w21
   111b4:      	add	x2, x9, x10
   111b8:      	and	w1, w11, #0xff
   111bc:      	mov	w8, #0x4                // =4
   111c0:      	cinc	x0, x19, hi
   111c4:      	blr	x8
   111c8:      	cmp	w23, w21
   111cc:      	str	x19, [sp, #0x60]
   111d0:      	add	x19, sp, #0x70
   111d4:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   111d8:      	ldr	x21, [sp, #0x78]
   111dc:      	ldp	x2, x24, [sp, #0x50]
   111e0:      	str	x21, [sp, #0x48]
   111e4:      	b	0x11234 <generic_kprobe_path+0x6404>
   111e8:      	add	x2, x24, #0x10
   111ec:      	mov	w8, #0x4                // =4
   111f0:      	add	x9, sp, #0x98
   111f4:      	add	x0, sp, #0x98
   111f8:      	mov	w1, #0x8                // =8
   111fc:      	blr	x8
   11200:      	ldr	x8, [sp, #0x58]
   11204:      	ldr	x9, [sp, #0x98]
   11208:      	cmp	x8, x9
   1120c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   11210:      	add	x2, x24, #0x18
   11214:      	mov	w8, #0x4                // =4
   11218:      	mov	x0, x22
   1121c:      	mov	w1, #0x8                // =8
   11220:      	blr	x8
   11224:      	ldr	x24, [sp, #0x98]
   11228:      	ldr	x21, [sp, #0x48]
   1122c:      	add	x2, x24, #0x20
   11230:      	stp	x2, x24, [sp, #0x50]
   11234:      	ldr	x8, [sp, #0x30]
   11238:      	cmp	x21, x8
   1123c:      	b.ne	0x1124c <generic_kprobe_path+0x641c>
   11240:      	ldr	x8, [sp, #0x38]
   11244:      	cmp	x2, x8
   11248:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1124c:      	mov	w8, #0x4                // =4
   11250:      	add	x0, sp, #0x70
   11254:      	mov	w1, #0x8                // =8
   11258:      	blr	x8
   1125c:      	ldr	x8, [sp, #0x70]
   11260:      	cmp	x21, x8
   11264:      	b.eq	0x11354 <generic_kprobe_path+0x6524>
   11268:      	add	x23, x21, #0x18
   1126c:      	mov	w8, #0x4                // =4
   11270:      	add	x9, sp, #0x98
   11274:      	add	x0, sp, #0x98
   11278:      	mov	w1, #0x8                // =8
   1127c:      	mov	x2, x23
   11280:      	blr	x8
   11284:      	ldr	x8, [sp, #0x98]
   11288:      	cmp	x8, x21
   1128c:      	b.eq	0x11354 <generic_kprobe_path+0x6524>
   11290:      	mov	w8, #0x4                // =4
   11294:      	add	x9, sp, #0x78
   11298:      	add	x0, sp, #0x78
   1129c:      	mov	w1, #0x8                // =8
   112a0:      	mov	x2, x23
   112a4:      	blr	x8
   112a8:      	add	x2, x21, #0x20
   112ac:      	mov	w8, #0x4                // =4
   112b0:      	mov	w9, #0x10               // =16
   112b4:      	add	x10, sp, #0x80
   112b8:      	add	x0, sp, #0x80
   112bc:      	mov	w1, #0x10               // =16
   112c0:      	blr	x8
   112c4:      	ldr	w21, [sp, #0x84]
   112c8:      	ldr	x8, [sp, #0x40]
   112cc:      	ldr	x10, [sp, #0x60]
   112d0:      	sub	x12, x10, x8
   112d4:      	ldr	w23, [sp, #0x68]
   112d8:      	subs	w10, w21, w23
   112dc:      	ldr	x9, [sp, #0x88]
   112e0:      	csel	w10, wzr, w10, lo
   112e4:      	cmp	w23, w21
   112e8:      	csel	w11, w23, w21, lo
   112ec:      	cinc	w13, w11, hi
   112f0:      	sub	w14, w23, w13
   112f4:      	subs	x12, x12, x13
   112f8:      	str	w14, [sp, #0x68]
   112fc:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   11300:      	cmp	x12, #0xfff
   11304:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   11308:      	cmp	w23, w21
   1130c:      	b.ls	0x11318 <generic_kprobe_path+0x64e8>
   11310:      	mov	w13, #0x2f              // =47
   11314:      	strb	w13, [x8, x12]
   11318:      	add	x19, x8, x12
   1131c:      	cmp	w23, w21
   11320:      	add	x2, x9, x10
   11324:      	and	w1, w11, #0xff
   11328:      	mov	w8, #0x4                // =4
   1132c:      	cinc	x0, x19, hi
   11330:      	blr	x8
   11334:      	cmp	w23, w21
   11338:      	str	x19, [sp, #0x60]
   1133c:      	add	x19, sp, #0x70
   11340:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   11344:      	ldr	x21, [sp, #0x78]
   11348:      	ldp	x2, x24, [sp, #0x50]
   1134c:      	str	x21, [sp, #0x48]
   11350:      	b	0x113a0 <generic_kprobe_path+0x6570>
   11354:      	add	x2, x24, #0x10
   11358:      	mov	w8, #0x4                // =4
   1135c:      	add	x9, sp, #0x98
   11360:      	add	x0, sp, #0x98
   11364:      	mov	w1, #0x8                // =8
   11368:      	blr	x8
   1136c:      	ldr	x8, [sp, #0x58]
   11370:      	ldr	x9, [sp, #0x98]
   11374:      	cmp	x8, x9
   11378:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1137c:      	add	x2, x24, #0x18
   11380:      	mov	w8, #0x4                // =4
   11384:      	mov	x0, x22
   11388:      	mov	w1, #0x8                // =8
   1138c:      	blr	x8
   11390:      	ldr	x24, [sp, #0x98]
   11394:      	ldr	x21, [sp, #0x48]
   11398:      	add	x2, x24, #0x20
   1139c:      	stp	x2, x24, [sp, #0x50]
   113a0:      	ldr	x8, [sp, #0x30]
   113a4:      	cmp	x21, x8
   113a8:      	b.ne	0x113b8 <generic_kprobe_path+0x6588>
   113ac:      	ldr	x8, [sp, #0x38]
   113b0:      	cmp	x2, x8
   113b4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   113b8:      	mov	w8, #0x4                // =4
   113bc:      	add	x0, sp, #0x70
   113c0:      	mov	w1, #0x8                // =8
   113c4:      	blr	x8
   113c8:      	ldr	x8, [sp, #0x70]
   113cc:      	cmp	x21, x8
   113d0:      	b.eq	0x114c0 <generic_kprobe_path+0x6690>
   113d4:      	add	x23, x21, #0x18
   113d8:      	mov	w8, #0x4                // =4
   113dc:      	add	x9, sp, #0x98
   113e0:      	add	x0, sp, #0x98
   113e4:      	mov	w1, #0x8                // =8
   113e8:      	mov	x2, x23
   113ec:      	blr	x8
   113f0:      	ldr	x8, [sp, #0x98]
   113f4:      	cmp	x8, x21
   113f8:      	b.eq	0x114c0 <generic_kprobe_path+0x6690>
   113fc:      	mov	w8, #0x4                // =4
   11400:      	add	x9, sp, #0x78
   11404:      	add	x0, sp, #0x78
   11408:      	mov	w1, #0x8                // =8
   1140c:      	mov	x2, x23
   11410:      	blr	x8
   11414:      	add	x2, x21, #0x20
   11418:      	mov	w8, #0x4                // =4
   1141c:      	mov	w9, #0x10               // =16
   11420:      	add	x10, sp, #0x80
   11424:      	add	x0, sp, #0x80
   11428:      	mov	w1, #0x10               // =16
   1142c:      	blr	x8
   11430:      	ldr	w21, [sp, #0x84]
   11434:      	ldr	x8, [sp, #0x40]
   11438:      	ldr	x10, [sp, #0x60]
   1143c:      	sub	x12, x10, x8
   11440:      	ldr	w23, [sp, #0x68]
   11444:      	subs	w10, w21, w23
   11448:      	ldr	x9, [sp, #0x88]
   1144c:      	csel	w10, wzr, w10, lo
   11450:      	cmp	w23, w21
   11454:      	csel	w11, w23, w21, lo
   11458:      	cinc	w13, w11, hi
   1145c:      	sub	w14, w23, w13
   11460:      	subs	x12, x12, x13
   11464:      	str	w14, [sp, #0x68]
   11468:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   1146c:      	cmp	x12, #0xfff
   11470:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   11474:      	cmp	w23, w21
   11478:      	b.ls	0x11484 <generic_kprobe_path+0x6654>
   1147c:      	mov	w13, #0x2f              // =47
   11480:      	strb	w13, [x8, x12]
   11484:      	add	x19, x8, x12
   11488:      	cmp	w23, w21
   1148c:      	add	x2, x9, x10
   11490:      	and	w1, w11, #0xff
   11494:      	mov	w8, #0x4                // =4
   11498:      	cinc	x0, x19, hi
   1149c:      	blr	x8
   114a0:      	cmp	w23, w21
   114a4:      	str	x19, [sp, #0x60]
   114a8:      	add	x19, sp, #0x70
   114ac:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   114b0:      	ldr	x21, [sp, #0x78]
   114b4:      	ldp	x2, x24, [sp, #0x50]
   114b8:      	str	x21, [sp, #0x48]
   114bc:      	b	0x1150c <generic_kprobe_path+0x66dc>
   114c0:      	add	x2, x24, #0x10
   114c4:      	mov	w8, #0x4                // =4
   114c8:      	add	x9, sp, #0x98
   114cc:      	add	x0, sp, #0x98
   114d0:      	mov	w1, #0x8                // =8
   114d4:      	blr	x8
   114d8:      	ldr	x8, [sp, #0x58]
   114dc:      	ldr	x9, [sp, #0x98]
   114e0:      	cmp	x8, x9
   114e4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   114e8:      	add	x2, x24, #0x18
   114ec:      	mov	w8, #0x4                // =4
   114f0:      	mov	x0, x22
   114f4:      	mov	w1, #0x8                // =8
   114f8:      	blr	x8
   114fc:      	ldr	x24, [sp, #0x98]
   11500:      	ldr	x21, [sp, #0x48]
   11504:      	add	x2, x24, #0x20
   11508:      	stp	x2, x24, [sp, #0x50]
   1150c:      	ldr	x8, [sp, #0x30]
   11510:      	cmp	x21, x8
   11514:      	b.ne	0x11524 <generic_kprobe_path+0x66f4>
   11518:      	ldr	x8, [sp, #0x38]
   1151c:      	cmp	x2, x8
   11520:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   11524:      	mov	w8, #0x4                // =4
   11528:      	add	x0, sp, #0x70
   1152c:      	mov	w1, #0x8                // =8
   11530:      	blr	x8
   11534:      	ldr	x8, [sp, #0x70]
   11538:      	cmp	x21, x8
   1153c:      	b.eq	0x1162c <generic_kprobe_path+0x67fc>
   11540:      	add	x23, x21, #0x18
   11544:      	mov	w8, #0x4                // =4
   11548:      	add	x9, sp, #0x98
   1154c:      	add	x0, sp, #0x98
   11550:      	mov	w1, #0x8                // =8
   11554:      	mov	x2, x23
   11558:      	blr	x8
   1155c:      	ldr	x8, [sp, #0x98]
   11560:      	cmp	x8, x21
   11564:      	b.eq	0x1162c <generic_kprobe_path+0x67fc>
   11568:      	mov	w8, #0x4                // =4
   1156c:      	add	x9, sp, #0x78
   11570:      	add	x0, sp, #0x78
   11574:      	mov	w1, #0x8                // =8
   11578:      	mov	x2, x23
   1157c:      	blr	x8
   11580:      	add	x2, x21, #0x20
   11584:      	mov	w8, #0x4                // =4
   11588:      	mov	w9, #0x10               // =16
   1158c:      	add	x10, sp, #0x80
   11590:      	add	x0, sp, #0x80
   11594:      	mov	w1, #0x10               // =16
   11598:      	blr	x8
   1159c:      	ldr	w21, [sp, #0x84]
   115a0:      	ldr	x8, [sp, #0x40]
   115a4:      	ldr	x10, [sp, #0x60]
   115a8:      	sub	x12, x10, x8
   115ac:      	ldr	w23, [sp, #0x68]
   115b0:      	subs	w10, w21, w23
   115b4:      	ldr	x9, [sp, #0x88]
   115b8:      	csel	w10, wzr, w10, lo
   115bc:      	cmp	w23, w21
   115c0:      	csel	w11, w23, w21, lo
   115c4:      	cinc	w13, w11, hi
   115c8:      	sub	w14, w23, w13
   115cc:      	subs	x12, x12, x13
   115d0:      	str	w14, [sp, #0x68]
   115d4:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   115d8:      	cmp	x12, #0xfff
   115dc:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   115e0:      	cmp	w23, w21
   115e4:      	b.ls	0x115f0 <generic_kprobe_path+0x67c0>
   115e8:      	mov	w13, #0x2f              // =47
   115ec:      	strb	w13, [x8, x12]
   115f0:      	add	x19, x8, x12
   115f4:      	cmp	w23, w21
   115f8:      	add	x2, x9, x10
   115fc:      	and	w1, w11, #0xff
   11600:      	mov	w8, #0x4                // =4
   11604:      	cinc	x0, x19, hi
   11608:      	blr	x8
   1160c:      	cmp	w23, w21
   11610:      	str	x19, [sp, #0x60]
   11614:      	add	x19, sp, #0x70
   11618:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   1161c:      	ldr	x21, [sp, #0x78]
   11620:      	ldp	x2, x24, [sp, #0x50]
   11624:      	str	x21, [sp, #0x48]
   11628:      	b	0x11678 <generic_kprobe_path+0x6848>
   1162c:      	add	x2, x24, #0x10
   11630:      	mov	w8, #0x4                // =4
   11634:      	add	x9, sp, #0x98
   11638:      	add	x0, sp, #0x98
   1163c:      	mov	w1, #0x8                // =8
   11640:      	blr	x8
   11644:      	ldr	x8, [sp, #0x58]
   11648:      	ldr	x9, [sp, #0x98]
   1164c:      	cmp	x8, x9
   11650:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   11654:      	add	x2, x24, #0x18
   11658:      	mov	w8, #0x4                // =4
   1165c:      	mov	x0, x22
   11660:      	mov	w1, #0x8                // =8
   11664:      	blr	x8
   11668:      	ldr	x24, [sp, #0x98]
   1166c:      	ldr	x21, [sp, #0x48]
   11670:      	add	x2, x24, #0x20
   11674:      	stp	x2, x24, [sp, #0x50]
   11678:      	ldr	x8, [sp, #0x30]
   1167c:      	cmp	x21, x8
   11680:      	b.ne	0x11690 <generic_kprobe_path+0x6860>
   11684:      	ldr	x8, [sp, #0x38]
   11688:      	cmp	x2, x8
   1168c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   11690:      	mov	w8, #0x4                // =4
   11694:      	add	x0, sp, #0x70
   11698:      	mov	w1, #0x8                // =8
   1169c:      	blr	x8
   116a0:      	ldr	x8, [sp, #0x70]
   116a4:      	cmp	x21, x8
   116a8:      	b.eq	0x11798 <generic_kprobe_path+0x6968>
   116ac:      	add	x23, x21, #0x18
   116b0:      	mov	w8, #0x4                // =4
   116b4:      	add	x9, sp, #0x98
   116b8:      	add	x0, sp, #0x98
   116bc:      	mov	w1, #0x8                // =8
   116c0:      	mov	x2, x23
   116c4:      	blr	x8
   116c8:      	ldr	x8, [sp, #0x98]
   116cc:      	cmp	x8, x21
   116d0:      	b.eq	0x11798 <generic_kprobe_path+0x6968>
   116d4:      	mov	w8, #0x4                // =4
   116d8:      	add	x9, sp, #0x78
   116dc:      	add	x0, sp, #0x78
   116e0:      	mov	w1, #0x8                // =8
   116e4:      	mov	x2, x23
   116e8:      	blr	x8
   116ec:      	add	x2, x21, #0x20
   116f0:      	mov	w8, #0x4                // =4
   116f4:      	mov	w9, #0x10               // =16
   116f8:      	add	x10, sp, #0x80
   116fc:      	add	x0, sp, #0x80
   11700:      	mov	w1, #0x10               // =16
   11704:      	blr	x8
   11708:      	ldr	w21, [sp, #0x84]
   1170c:      	ldr	x8, [sp, #0x40]
   11710:      	ldr	x10, [sp, #0x60]
   11714:      	sub	x12, x10, x8
   11718:      	ldr	w23, [sp, #0x68]
   1171c:      	subs	w10, w21, w23
   11720:      	ldr	x9, [sp, #0x88]
   11724:      	csel	w10, wzr, w10, lo
   11728:      	cmp	w23, w21
   1172c:      	csel	w11, w23, w21, lo
   11730:      	cinc	w13, w11, hi
   11734:      	sub	w14, w23, w13
   11738:      	subs	x12, x12, x13
   1173c:      	str	w14, [sp, #0x68]
   11740:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   11744:      	cmp	x12, #0xfff
   11748:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   1174c:      	cmp	w23, w21
   11750:      	b.ls	0x1175c <generic_kprobe_path+0x692c>
   11754:      	mov	w13, #0x2f              // =47
   11758:      	strb	w13, [x8, x12]
   1175c:      	add	x19, x8, x12
   11760:      	cmp	w23, w21
   11764:      	add	x2, x9, x10
   11768:      	and	w1, w11, #0xff
   1176c:      	mov	w8, #0x4                // =4
   11770:      	cinc	x0, x19, hi
   11774:      	blr	x8
   11778:      	cmp	w23, w21
   1177c:      	str	x19, [sp, #0x60]
   11780:      	add	x19, sp, #0x70
   11784:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   11788:      	ldr	x21, [sp, #0x78]
   1178c:      	ldp	x2, x24, [sp, #0x50]
   11790:      	str	x21, [sp, #0x48]
   11794:      	b	0x117e4 <generic_kprobe_path+0x69b4>
   11798:      	add	x2, x24, #0x10
   1179c:      	mov	w8, #0x4                // =4
   117a0:      	add	x9, sp, #0x98
   117a4:      	add	x0, sp, #0x98
   117a8:      	mov	w1, #0x8                // =8
   117ac:      	blr	x8
   117b0:      	ldr	x8, [sp, #0x58]
   117b4:      	ldr	x9, [sp, #0x98]
   117b8:      	cmp	x8, x9
   117bc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   117c0:      	add	x2, x24, #0x18
   117c4:      	mov	w8, #0x4                // =4
   117c8:      	mov	x0, x22
   117cc:      	mov	w1, #0x8                // =8
   117d0:      	blr	x8
   117d4:      	ldr	x24, [sp, #0x98]
   117d8:      	ldr	x21, [sp, #0x48]
   117dc:      	add	x2, x24, #0x20
   117e0:      	stp	x2, x24, [sp, #0x50]
   117e4:      	ldr	x8, [sp, #0x30]
   117e8:      	cmp	x21, x8
   117ec:      	b.ne	0x117fc <generic_kprobe_path+0x69cc>
   117f0:      	ldr	x8, [sp, #0x38]
   117f4:      	cmp	x2, x8
   117f8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   117fc:      	mov	w8, #0x4                // =4
   11800:      	add	x0, sp, #0x70
   11804:      	mov	w1, #0x8                // =8
   11808:      	blr	x8
   1180c:      	ldr	x8, [sp, #0x70]
   11810:      	cmp	x21, x8
   11814:      	b.eq	0x11904 <generic_kprobe_path+0x6ad4>
   11818:      	add	x23, x21, #0x18
   1181c:      	mov	w8, #0x4                // =4
   11820:      	add	x9, sp, #0x98
   11824:      	add	x0, sp, #0x98
   11828:      	mov	w1, #0x8                // =8
   1182c:      	mov	x2, x23
   11830:      	blr	x8
   11834:      	ldr	x8, [sp, #0x98]
   11838:      	cmp	x8, x21
   1183c:      	b.eq	0x11904 <generic_kprobe_path+0x6ad4>
   11840:      	mov	w8, #0x4                // =4
   11844:      	add	x9, sp, #0x78
   11848:      	add	x0, sp, #0x78
   1184c:      	mov	w1, #0x8                // =8
   11850:      	mov	x2, x23
   11854:      	blr	x8
   11858:      	add	x2, x21, #0x20
   1185c:      	mov	w8, #0x4                // =4
   11860:      	mov	w9, #0x10               // =16
   11864:      	add	x10, sp, #0x80
   11868:      	add	x0, sp, #0x80
   1186c:      	mov	w1, #0x10               // =16
   11870:      	blr	x8
   11874:      	ldr	w21, [sp, #0x84]
   11878:      	ldr	x8, [sp, #0x40]
   1187c:      	ldr	x10, [sp, #0x60]
   11880:      	sub	x12, x10, x8
   11884:      	ldr	w23, [sp, #0x68]
   11888:      	subs	w10, w21, w23
   1188c:      	ldr	x9, [sp, #0x88]
   11890:      	csel	w10, wzr, w10, lo
   11894:      	cmp	w23, w21
   11898:      	csel	w11, w23, w21, lo
   1189c:      	cinc	w13, w11, hi
   118a0:      	sub	w14, w23, w13
   118a4:      	subs	x12, x12, x13
   118a8:      	str	w14, [sp, #0x68]
   118ac:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   118b0:      	cmp	x12, #0xfff
   118b4:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   118b8:      	cmp	w23, w21
   118bc:      	b.ls	0x118c8 <generic_kprobe_path+0x6a98>
   118c0:      	mov	w13, #0x2f              // =47
   118c4:      	strb	w13, [x8, x12]
   118c8:      	add	x19, x8, x12
   118cc:      	cmp	w23, w21
   118d0:      	add	x2, x9, x10
   118d4:      	and	w1, w11, #0xff
   118d8:      	mov	w8, #0x4                // =4
   118dc:      	cinc	x0, x19, hi
   118e0:      	blr	x8
   118e4:      	cmp	w23, w21
   118e8:      	str	x19, [sp, #0x60]
   118ec:      	add	x19, sp, #0x70
   118f0:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   118f4:      	ldr	x21, [sp, #0x78]
   118f8:      	ldp	x2, x24, [sp, #0x50]
   118fc:      	str	x21, [sp, #0x48]
   11900:      	b	0x11950 <generic_kprobe_path+0x6b20>
   11904:      	add	x2, x24, #0x10
   11908:      	mov	w8, #0x4                // =4
   1190c:      	add	x9, sp, #0x98
   11910:      	add	x0, sp, #0x98
   11914:      	mov	w1, #0x8                // =8
   11918:      	blr	x8
   1191c:      	ldr	x8, [sp, #0x58]
   11920:      	ldr	x9, [sp, #0x98]
   11924:      	cmp	x8, x9
   11928:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1192c:      	add	x2, x24, #0x18
   11930:      	mov	w8, #0x4                // =4
   11934:      	mov	x0, x22
   11938:      	mov	w1, #0x8                // =8
   1193c:      	blr	x8
   11940:      	ldr	x24, [sp, #0x98]
   11944:      	ldr	x21, [sp, #0x48]
   11948:      	add	x2, x24, #0x20
   1194c:      	stp	x2, x24, [sp, #0x50]
   11950:      	ldr	x8, [sp, #0x30]
   11954:      	cmp	x21, x8
   11958:      	b.ne	0x11968 <generic_kprobe_path+0x6b38>
   1195c:      	ldr	x8, [sp, #0x38]
   11960:      	cmp	x2, x8
   11964:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   11968:      	mov	w8, #0x4                // =4
   1196c:      	add	x0, sp, #0x70
   11970:      	mov	w1, #0x8                // =8
   11974:      	blr	x8
   11978:      	ldr	x8, [sp, #0x70]
   1197c:      	cmp	x21, x8
   11980:      	b.eq	0x11a70 <generic_kprobe_path+0x6c40>
   11984:      	add	x23, x21, #0x18
   11988:      	mov	w8, #0x4                // =4
   1198c:      	add	x9, sp, #0x98
   11990:      	add	x0, sp, #0x98
   11994:      	mov	w1, #0x8                // =8
   11998:      	mov	x2, x23
   1199c:      	blr	x8
   119a0:      	ldr	x8, [sp, #0x98]
   119a4:      	cmp	x8, x21
   119a8:      	b.eq	0x11a70 <generic_kprobe_path+0x6c40>
   119ac:      	mov	w8, #0x4                // =4
   119b0:      	add	x9, sp, #0x78
   119b4:      	add	x0, sp, #0x78
   119b8:      	mov	w1, #0x8                // =8
   119bc:      	mov	x2, x23
   119c0:      	blr	x8
   119c4:      	add	x2, x21, #0x20
   119c8:      	mov	w8, #0x4                // =4
   119cc:      	mov	w9, #0x10               // =16
   119d0:      	add	x10, sp, #0x80
   119d4:      	add	x0, sp, #0x80
   119d8:      	mov	w1, #0x10               // =16
   119dc:      	blr	x8
   119e0:      	ldr	w21, [sp, #0x84]
   119e4:      	ldr	x8, [sp, #0x40]
   119e8:      	ldr	x10, [sp, #0x60]
   119ec:      	sub	x12, x10, x8
   119f0:      	ldr	w23, [sp, #0x68]
   119f4:      	subs	w10, w21, w23
   119f8:      	ldr	x9, [sp, #0x88]
   119fc:      	csel	w10, wzr, w10, lo
   11a00:      	cmp	w23, w21
   11a04:      	csel	w11, w23, w21, lo
   11a08:      	cinc	w13, w11, hi
   11a0c:      	sub	w14, w23, w13
   11a10:      	subs	x12, x12, x13
   11a14:      	str	w14, [sp, #0x68]
   11a18:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   11a1c:      	cmp	x12, #0xfff
   11a20:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   11a24:      	cmp	w23, w21
   11a28:      	b.ls	0x11a34 <generic_kprobe_path+0x6c04>
   11a2c:      	mov	w13, #0x2f              // =47
   11a30:      	strb	w13, [x8, x12]
   11a34:      	add	x19, x8, x12
   11a38:      	cmp	w23, w21
   11a3c:      	add	x2, x9, x10
   11a40:      	and	w1, w11, #0xff
   11a44:      	mov	w8, #0x4                // =4
   11a48:      	cinc	x0, x19, hi
   11a4c:      	blr	x8
   11a50:      	cmp	w23, w21
   11a54:      	str	x19, [sp, #0x60]
   11a58:      	add	x19, sp, #0x70
   11a5c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   11a60:      	ldr	x21, [sp, #0x78]
   11a64:      	ldp	x2, x24, [sp, #0x50]
   11a68:      	str	x21, [sp, #0x48]
   11a6c:      	b	0x11abc <generic_kprobe_path+0x6c8c>
   11a70:      	add	x2, x24, #0x10
   11a74:      	mov	w8, #0x4                // =4
   11a78:      	add	x9, sp, #0x98
   11a7c:      	add	x0, sp, #0x98
   11a80:      	mov	w1, #0x8                // =8
   11a84:      	blr	x8
   11a88:      	ldr	x8, [sp, #0x58]
   11a8c:      	ldr	x9, [sp, #0x98]
   11a90:      	cmp	x8, x9
   11a94:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   11a98:      	add	x2, x24, #0x18
   11a9c:      	mov	w8, #0x4                // =4
   11aa0:      	mov	x0, x22
   11aa4:      	mov	w1, #0x8                // =8
   11aa8:      	blr	x8
   11aac:      	ldr	x24, [sp, #0x98]
   11ab0:      	ldr	x21, [sp, #0x48]
   11ab4:      	add	x2, x24, #0x20
   11ab8:      	stp	x2, x24, [sp, #0x50]
   11abc:      	ldr	x8, [sp, #0x30]
   11ac0:      	cmp	x21, x8
   11ac4:      	b.ne	0x11ad4 <generic_kprobe_path+0x6ca4>
   11ac8:      	ldr	x8, [sp, #0x38]
   11acc:      	cmp	x2, x8
   11ad0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   11ad4:      	mov	w8, #0x4                // =4
   11ad8:      	add	x0, sp, #0x70
   11adc:      	mov	w1, #0x8                // =8
   11ae0:      	blr	x8
   11ae4:      	ldr	x8, [sp, #0x70]
   11ae8:      	cmp	x21, x8
   11aec:      	b.eq	0x11bdc <generic_kprobe_path+0x6dac>
   11af0:      	add	x23, x21, #0x18
   11af4:      	mov	w8, #0x4                // =4
   11af8:      	add	x9, sp, #0x98
   11afc:      	add	x0, sp, #0x98
   11b00:      	mov	w1, #0x8                // =8
   11b04:      	mov	x2, x23
   11b08:      	blr	x8
   11b0c:      	ldr	x8, [sp, #0x98]
   11b10:      	cmp	x8, x21
   11b14:      	b.eq	0x11bdc <generic_kprobe_path+0x6dac>
   11b18:      	mov	w8, #0x4                // =4
   11b1c:      	add	x9, sp, #0x78
   11b20:      	add	x0, sp, #0x78
   11b24:      	mov	w1, #0x8                // =8
   11b28:      	mov	x2, x23
   11b2c:      	blr	x8
   11b30:      	add	x2, x21, #0x20
   11b34:      	mov	w8, #0x4                // =4
   11b38:      	mov	w9, #0x10               // =16
   11b3c:      	add	x10, sp, #0x80
   11b40:      	add	x0, sp, #0x80
   11b44:      	mov	w1, #0x10               // =16
   11b48:      	blr	x8
   11b4c:      	ldr	w21, [sp, #0x84]
   11b50:      	ldr	x8, [sp, #0x40]
   11b54:      	ldr	x10, [sp, #0x60]
   11b58:      	sub	x12, x10, x8
   11b5c:      	ldr	w23, [sp, #0x68]
   11b60:      	subs	w10, w21, w23
   11b64:      	ldr	x9, [sp, #0x88]
   11b68:      	csel	w10, wzr, w10, lo
   11b6c:      	cmp	w23, w21
   11b70:      	csel	w11, w23, w21, lo
   11b74:      	cinc	w13, w11, hi
   11b78:      	sub	w14, w23, w13
   11b7c:      	subs	x12, x12, x13
   11b80:      	str	w14, [sp, #0x68]
   11b84:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   11b88:      	cmp	x12, #0xfff
   11b8c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   11b90:      	cmp	w23, w21
   11b94:      	b.ls	0x11ba0 <generic_kprobe_path+0x6d70>
   11b98:      	mov	w13, #0x2f              // =47
   11b9c:      	strb	w13, [x8, x12]
   11ba0:      	add	x19, x8, x12
   11ba4:      	cmp	w23, w21
   11ba8:      	add	x2, x9, x10
   11bac:      	and	w1, w11, #0xff
   11bb0:      	mov	w8, #0x4                // =4
   11bb4:      	cinc	x0, x19, hi
   11bb8:      	blr	x8
   11bbc:      	cmp	w23, w21
   11bc0:      	str	x19, [sp, #0x60]
   11bc4:      	add	x19, sp, #0x70
   11bc8:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   11bcc:      	ldr	x21, [sp, #0x78]
   11bd0:      	ldp	x2, x24, [sp, #0x50]
   11bd4:      	str	x21, [sp, #0x48]
   11bd8:      	b	0x11c28 <generic_kprobe_path+0x6df8>
   11bdc:      	add	x2, x24, #0x10
   11be0:      	mov	w8, #0x4                // =4
   11be4:      	add	x9, sp, #0x98
   11be8:      	add	x0, sp, #0x98
   11bec:      	mov	w1, #0x8                // =8
   11bf0:      	blr	x8
   11bf4:      	ldr	x8, [sp, #0x58]
   11bf8:      	ldr	x9, [sp, #0x98]
   11bfc:      	cmp	x8, x9
   11c00:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   11c04:      	add	x2, x24, #0x18
   11c08:      	mov	w8, #0x4                // =4
   11c0c:      	mov	x0, x22
   11c10:      	mov	w1, #0x8                // =8
   11c14:      	blr	x8
   11c18:      	ldr	x24, [sp, #0x98]
   11c1c:      	ldr	x21, [sp, #0x48]
   11c20:      	add	x2, x24, #0x20
   11c24:      	stp	x2, x24, [sp, #0x50]
   11c28:      	ldr	x8, [sp, #0x30]
   11c2c:      	cmp	x21, x8
   11c30:      	b.ne	0x11c40 <generic_kprobe_path+0x6e10>
   11c34:      	ldr	x8, [sp, #0x38]
   11c38:      	cmp	x2, x8
   11c3c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   11c40:      	mov	w8, #0x4                // =4
   11c44:      	add	x0, sp, #0x70
   11c48:      	mov	w1, #0x8                // =8
   11c4c:      	blr	x8
   11c50:      	ldr	x8, [sp, #0x70]
   11c54:      	cmp	x21, x8
   11c58:      	b.eq	0x11d48 <generic_kprobe_path+0x6f18>
   11c5c:      	add	x23, x21, #0x18
   11c60:      	mov	w8, #0x4                // =4
   11c64:      	add	x9, sp, #0x98
   11c68:      	add	x0, sp, #0x98
   11c6c:      	mov	w1, #0x8                // =8
   11c70:      	mov	x2, x23
   11c74:      	blr	x8
   11c78:      	ldr	x8, [sp, #0x98]
   11c7c:      	cmp	x8, x21
   11c80:      	b.eq	0x11d48 <generic_kprobe_path+0x6f18>
   11c84:      	mov	w8, #0x4                // =4
   11c88:      	add	x9, sp, #0x78
   11c8c:      	add	x0, sp, #0x78
   11c90:      	mov	w1, #0x8                // =8
   11c94:      	mov	x2, x23
   11c98:      	blr	x8
   11c9c:      	add	x2, x21, #0x20
   11ca0:      	mov	w8, #0x4                // =4
   11ca4:      	mov	w9, #0x10               // =16
   11ca8:      	add	x10, sp, #0x80
   11cac:      	add	x0, sp, #0x80
   11cb0:      	mov	w1, #0x10               // =16
   11cb4:      	blr	x8
   11cb8:      	ldr	w21, [sp, #0x84]
   11cbc:      	ldr	x8, [sp, #0x40]
   11cc0:      	ldr	x10, [sp, #0x60]
   11cc4:      	sub	x12, x10, x8
   11cc8:      	ldr	w23, [sp, #0x68]
   11ccc:      	subs	w10, w21, w23
   11cd0:      	ldr	x9, [sp, #0x88]
   11cd4:      	csel	w10, wzr, w10, lo
   11cd8:      	cmp	w23, w21
   11cdc:      	csel	w11, w23, w21, lo
   11ce0:      	cinc	w13, w11, hi
   11ce4:      	sub	w14, w23, w13
   11ce8:      	subs	x12, x12, x13
   11cec:      	str	w14, [sp, #0x68]
   11cf0:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   11cf4:      	cmp	x12, #0xfff
   11cf8:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   11cfc:      	cmp	w23, w21
   11d00:      	b.ls	0x11d0c <generic_kprobe_path+0x6edc>
   11d04:      	mov	w13, #0x2f              // =47
   11d08:      	strb	w13, [x8, x12]
   11d0c:      	add	x19, x8, x12
   11d10:      	cmp	w23, w21
   11d14:      	add	x2, x9, x10
   11d18:      	and	w1, w11, #0xff
   11d1c:      	mov	w8, #0x4                // =4
   11d20:      	cinc	x0, x19, hi
   11d24:      	blr	x8
   11d28:      	cmp	w23, w21
   11d2c:      	str	x19, [sp, #0x60]
   11d30:      	add	x19, sp, #0x70
   11d34:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   11d38:      	ldr	x21, [sp, #0x78]
   11d3c:      	ldp	x2, x24, [sp, #0x50]
   11d40:      	str	x21, [sp, #0x48]
   11d44:      	b	0x11d94 <generic_kprobe_path+0x6f64>
   11d48:      	add	x2, x24, #0x10
   11d4c:      	mov	w8, #0x4                // =4
   11d50:      	add	x9, sp, #0x98
   11d54:      	add	x0, sp, #0x98
   11d58:      	mov	w1, #0x8                // =8
   11d5c:      	blr	x8
   11d60:      	ldr	x8, [sp, #0x58]
   11d64:      	ldr	x9, [sp, #0x98]
   11d68:      	cmp	x8, x9
   11d6c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   11d70:      	add	x2, x24, #0x18
   11d74:      	mov	w8, #0x4                // =4
   11d78:      	mov	x0, x22
   11d7c:      	mov	w1, #0x8                // =8
   11d80:      	blr	x8
   11d84:      	ldr	x24, [sp, #0x98]
   11d88:      	ldr	x21, [sp, #0x48]
   11d8c:      	add	x2, x24, #0x20
   11d90:      	stp	x2, x24, [sp, #0x50]
   11d94:      	ldr	x8, [sp, #0x30]
   11d98:      	cmp	x21, x8
   11d9c:      	b.ne	0x11dac <generic_kprobe_path+0x6f7c>
   11da0:      	ldr	x8, [sp, #0x38]
   11da4:      	cmp	x2, x8
   11da8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   11dac:      	mov	w8, #0x4                // =4
   11db0:      	add	x0, sp, #0x70
   11db4:      	mov	w1, #0x8                // =8
   11db8:      	blr	x8
   11dbc:      	ldr	x8, [sp, #0x70]
   11dc0:      	cmp	x21, x8
   11dc4:      	b.eq	0x11eb4 <generic_kprobe_path+0x7084>
   11dc8:      	add	x23, x21, #0x18
   11dcc:      	mov	w8, #0x4                // =4
   11dd0:      	add	x9, sp, #0x98
   11dd4:      	add	x0, sp, #0x98
   11dd8:      	mov	w1, #0x8                // =8
   11ddc:      	mov	x2, x23
   11de0:      	blr	x8
   11de4:      	ldr	x8, [sp, #0x98]
   11de8:      	cmp	x8, x21
   11dec:      	b.eq	0x11eb4 <generic_kprobe_path+0x7084>
   11df0:      	mov	w8, #0x4                // =4
   11df4:      	add	x9, sp, #0x78
   11df8:      	add	x0, sp, #0x78
   11dfc:      	mov	w1, #0x8                // =8
   11e00:      	mov	x2, x23
   11e04:      	blr	x8
   11e08:      	add	x2, x21, #0x20
   11e0c:      	mov	w8, #0x4                // =4
   11e10:      	mov	w9, #0x10               // =16
   11e14:      	add	x10, sp, #0x80
   11e18:      	add	x0, sp, #0x80
   11e1c:      	mov	w1, #0x10               // =16
   11e20:      	blr	x8
   11e24:      	ldr	w21, [sp, #0x84]
   11e28:      	ldr	x8, [sp, #0x40]
   11e2c:      	ldr	x10, [sp, #0x60]
   11e30:      	sub	x12, x10, x8
   11e34:      	ldr	w23, [sp, #0x68]
   11e38:      	subs	w10, w21, w23
   11e3c:      	ldr	x9, [sp, #0x88]
   11e40:      	csel	w10, wzr, w10, lo
   11e44:      	cmp	w23, w21
   11e48:      	csel	w11, w23, w21, lo
   11e4c:      	cinc	w13, w11, hi
   11e50:      	sub	w14, w23, w13
   11e54:      	subs	x12, x12, x13
   11e58:      	str	w14, [sp, #0x68]
   11e5c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   11e60:      	cmp	x12, #0xfff
   11e64:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   11e68:      	cmp	w23, w21
   11e6c:      	b.ls	0x11e78 <generic_kprobe_path+0x7048>
   11e70:      	mov	w13, #0x2f              // =47
   11e74:      	strb	w13, [x8, x12]
   11e78:      	add	x19, x8, x12
   11e7c:      	cmp	w23, w21
   11e80:      	add	x2, x9, x10
   11e84:      	and	w1, w11, #0xff
   11e88:      	mov	w8, #0x4                // =4
   11e8c:      	cinc	x0, x19, hi
   11e90:      	blr	x8
   11e94:      	cmp	w23, w21
   11e98:      	str	x19, [sp, #0x60]
   11e9c:      	add	x19, sp, #0x70
   11ea0:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   11ea4:      	ldr	x21, [sp, #0x78]
   11ea8:      	ldp	x2, x24, [sp, #0x50]
   11eac:      	str	x21, [sp, #0x48]
   11eb0:      	b	0x11f00 <generic_kprobe_path+0x70d0>
   11eb4:      	add	x2, x24, #0x10
   11eb8:      	mov	w8, #0x4                // =4
   11ebc:      	add	x9, sp, #0x98
   11ec0:      	add	x0, sp, #0x98
   11ec4:      	mov	w1, #0x8                // =8
   11ec8:      	blr	x8
   11ecc:      	ldr	x8, [sp, #0x58]
   11ed0:      	ldr	x9, [sp, #0x98]
   11ed4:      	cmp	x8, x9
   11ed8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   11edc:      	add	x2, x24, #0x18
   11ee0:      	mov	w8, #0x4                // =4
   11ee4:      	mov	x0, x22
   11ee8:      	mov	w1, #0x8                // =8
   11eec:      	blr	x8
   11ef0:      	ldr	x24, [sp, #0x98]
   11ef4:      	ldr	x21, [sp, #0x48]
   11ef8:      	add	x2, x24, #0x20
   11efc:      	stp	x2, x24, [sp, #0x50]
   11f00:      	ldr	x8, [sp, #0x30]
   11f04:      	cmp	x21, x8
   11f08:      	b.ne	0x11f18 <generic_kprobe_path+0x70e8>
   11f0c:      	ldr	x8, [sp, #0x38]
   11f10:      	cmp	x2, x8
   11f14:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   11f18:      	mov	w8, #0x4                // =4
   11f1c:      	add	x0, sp, #0x70
   11f20:      	mov	w1, #0x8                // =8
   11f24:      	blr	x8
   11f28:      	ldr	x8, [sp, #0x70]
   11f2c:      	cmp	x21, x8
   11f30:      	b.eq	0x12020 <generic_kprobe_path+0x71f0>
   11f34:      	add	x23, x21, #0x18
   11f38:      	mov	w8, #0x4                // =4
   11f3c:      	add	x9, sp, #0x98
   11f40:      	add	x0, sp, #0x98
   11f44:      	mov	w1, #0x8                // =8
   11f48:      	mov	x2, x23
   11f4c:      	blr	x8
   11f50:      	ldr	x8, [sp, #0x98]
   11f54:      	cmp	x8, x21
   11f58:      	b.eq	0x12020 <generic_kprobe_path+0x71f0>
   11f5c:      	mov	w8, #0x4                // =4
   11f60:      	add	x9, sp, #0x78
   11f64:      	add	x0, sp, #0x78
   11f68:      	mov	w1, #0x8                // =8
   11f6c:      	mov	x2, x23
   11f70:      	blr	x8
   11f74:      	add	x2, x21, #0x20
   11f78:      	mov	w8, #0x4                // =4
   11f7c:      	mov	w9, #0x10               // =16
   11f80:      	add	x10, sp, #0x80
   11f84:      	add	x0, sp, #0x80
   11f88:      	mov	w1, #0x10               // =16
   11f8c:      	blr	x8
   11f90:      	ldr	w21, [sp, #0x84]
   11f94:      	ldr	x8, [sp, #0x40]
   11f98:      	ldr	x10, [sp, #0x60]
   11f9c:      	sub	x12, x10, x8
   11fa0:      	ldr	w23, [sp, #0x68]
   11fa4:      	subs	w10, w21, w23
   11fa8:      	ldr	x9, [sp, #0x88]
   11fac:      	csel	w10, wzr, w10, lo
   11fb0:      	cmp	w23, w21
   11fb4:      	csel	w11, w23, w21, lo
   11fb8:      	cinc	w13, w11, hi
   11fbc:      	sub	w14, w23, w13
   11fc0:      	subs	x12, x12, x13
   11fc4:      	str	w14, [sp, #0x68]
   11fc8:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   11fcc:      	cmp	x12, #0xfff
   11fd0:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   11fd4:      	cmp	w23, w21
   11fd8:      	b.ls	0x11fe4 <generic_kprobe_path+0x71b4>
   11fdc:      	mov	w13, #0x2f              // =47
   11fe0:      	strb	w13, [x8, x12]
   11fe4:      	add	x19, x8, x12
   11fe8:      	cmp	w23, w21
   11fec:      	add	x2, x9, x10
   11ff0:      	and	w1, w11, #0xff
   11ff4:      	mov	w8, #0x4                // =4
   11ff8:      	cinc	x0, x19, hi
   11ffc:      	blr	x8
   12000:      	cmp	w23, w21
   12004:      	str	x19, [sp, #0x60]
   12008:      	add	x19, sp, #0x70
   1200c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   12010:      	ldr	x21, [sp, #0x78]
   12014:      	ldp	x2, x24, [sp, #0x50]
   12018:      	str	x21, [sp, #0x48]
   1201c:      	b	0x1206c <generic_kprobe_path+0x723c>
   12020:      	add	x2, x24, #0x10
   12024:      	mov	w8, #0x4                // =4
   12028:      	add	x9, sp, #0x98
   1202c:      	add	x0, sp, #0x98
   12030:      	mov	w1, #0x8                // =8
   12034:      	blr	x8
   12038:      	ldr	x8, [sp, #0x58]
   1203c:      	ldr	x9, [sp, #0x98]
   12040:      	cmp	x8, x9
   12044:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   12048:      	add	x2, x24, #0x18
   1204c:      	mov	w8, #0x4                // =4
   12050:      	mov	x0, x22
   12054:      	mov	w1, #0x8                // =8
   12058:      	blr	x8
   1205c:      	ldr	x24, [sp, #0x98]
   12060:      	ldr	x21, [sp, #0x48]
   12064:      	add	x2, x24, #0x20
   12068:      	stp	x2, x24, [sp, #0x50]
   1206c:      	ldr	x8, [sp, #0x30]
   12070:      	cmp	x21, x8
   12074:      	b.ne	0x12084 <generic_kprobe_path+0x7254>
   12078:      	ldr	x8, [sp, #0x38]
   1207c:      	cmp	x2, x8
   12080:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   12084:      	mov	w8, #0x4                // =4
   12088:      	add	x0, sp, #0x70
   1208c:      	mov	w1, #0x8                // =8
   12090:      	blr	x8
   12094:      	ldr	x8, [sp, #0x70]
   12098:      	cmp	x21, x8
   1209c:      	b.eq	0x1218c <generic_kprobe_path+0x735c>
   120a0:      	add	x23, x21, #0x18
   120a4:      	mov	w8, #0x4                // =4
   120a8:      	add	x9, sp, #0x98
   120ac:      	add	x0, sp, #0x98
   120b0:      	mov	w1, #0x8                // =8
   120b4:      	mov	x2, x23
   120b8:      	blr	x8
   120bc:      	ldr	x8, [sp, #0x98]
   120c0:      	cmp	x8, x21
   120c4:      	b.eq	0x1218c <generic_kprobe_path+0x735c>
   120c8:      	mov	w8, #0x4                // =4
   120cc:      	add	x9, sp, #0x78
   120d0:      	add	x0, sp, #0x78
   120d4:      	mov	w1, #0x8                // =8
   120d8:      	mov	x2, x23
   120dc:      	blr	x8
   120e0:      	add	x2, x21, #0x20
   120e4:      	mov	w8, #0x4                // =4
   120e8:      	mov	w9, #0x10               // =16
   120ec:      	add	x10, sp, #0x80
   120f0:      	add	x0, sp, #0x80
   120f4:      	mov	w1, #0x10               // =16
   120f8:      	blr	x8
   120fc:      	ldr	w21, [sp, #0x84]
   12100:      	ldr	x8, [sp, #0x40]
   12104:      	ldr	x10, [sp, #0x60]
   12108:      	sub	x12, x10, x8
   1210c:      	ldr	w23, [sp, #0x68]
   12110:      	subs	w10, w21, w23
   12114:      	ldr	x9, [sp, #0x88]
   12118:      	csel	w10, wzr, w10, lo
   1211c:      	cmp	w23, w21
   12120:      	csel	w11, w23, w21, lo
   12124:      	cinc	w13, w11, hi
   12128:      	sub	w14, w23, w13
   1212c:      	subs	x12, x12, x13
   12130:      	str	w14, [sp, #0x68]
   12134:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   12138:      	cmp	x12, #0xfff
   1213c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   12140:      	cmp	w23, w21
   12144:      	b.ls	0x12150 <generic_kprobe_path+0x7320>
   12148:      	mov	w13, #0x2f              // =47
   1214c:      	strb	w13, [x8, x12]
   12150:      	add	x19, x8, x12
   12154:      	cmp	w23, w21
   12158:      	add	x2, x9, x10
   1215c:      	and	w1, w11, #0xff
   12160:      	mov	w8, #0x4                // =4
   12164:      	cinc	x0, x19, hi
   12168:      	blr	x8
   1216c:      	cmp	w23, w21
   12170:      	str	x19, [sp, #0x60]
   12174:      	add	x19, sp, #0x70
   12178:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   1217c:      	ldr	x21, [sp, #0x78]
   12180:      	ldp	x2, x24, [sp, #0x50]
   12184:      	str	x21, [sp, #0x48]
   12188:      	b	0x121d8 <generic_kprobe_path+0x73a8>
   1218c:      	add	x2, x24, #0x10
   12190:      	mov	w8, #0x4                // =4
   12194:      	add	x9, sp, #0x98
   12198:      	add	x0, sp, #0x98
   1219c:      	mov	w1, #0x8                // =8
   121a0:      	blr	x8
   121a4:      	ldr	x8, [sp, #0x58]
   121a8:      	ldr	x9, [sp, #0x98]
   121ac:      	cmp	x8, x9
   121b0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   121b4:      	add	x2, x24, #0x18
   121b8:      	mov	w8, #0x4                // =4
   121bc:      	mov	x0, x22
   121c0:      	mov	w1, #0x8                // =8
   121c4:      	blr	x8
   121c8:      	ldr	x24, [sp, #0x98]
   121cc:      	ldr	x21, [sp, #0x48]
   121d0:      	add	x2, x24, #0x20
   121d4:      	stp	x2, x24, [sp, #0x50]
   121d8:      	ldr	x8, [sp, #0x30]
   121dc:      	cmp	x21, x8
   121e0:      	b.ne	0x121f0 <generic_kprobe_path+0x73c0>
   121e4:      	ldr	x8, [sp, #0x38]
   121e8:      	cmp	x2, x8
   121ec:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   121f0:      	mov	w8, #0x4                // =4
   121f4:      	add	x0, sp, #0x70
   121f8:      	mov	w1, #0x8                // =8
   121fc:      	blr	x8
   12200:      	ldr	x8, [sp, #0x70]
   12204:      	cmp	x21, x8
   12208:      	b.eq	0x122f8 <generic_kprobe_path+0x74c8>
   1220c:      	add	x23, x21, #0x18
   12210:      	mov	w8, #0x4                // =4
   12214:      	add	x9, sp, #0x98
   12218:      	add	x0, sp, #0x98
   1221c:      	mov	w1, #0x8                // =8
   12220:      	mov	x2, x23
   12224:      	blr	x8
   12228:      	ldr	x8, [sp, #0x98]
   1222c:      	cmp	x8, x21
   12230:      	b.eq	0x122f8 <generic_kprobe_path+0x74c8>
   12234:      	mov	w8, #0x4                // =4
   12238:      	add	x9, sp, #0x78
   1223c:      	add	x0, sp, #0x78
   12240:      	mov	w1, #0x8                // =8
   12244:      	mov	x2, x23
   12248:      	blr	x8
   1224c:      	add	x2, x21, #0x20
   12250:      	mov	w8, #0x4                // =4
   12254:      	mov	w9, #0x10               // =16
   12258:      	add	x10, sp, #0x80
   1225c:      	add	x0, sp, #0x80
   12260:      	mov	w1, #0x10               // =16
   12264:      	blr	x8
   12268:      	ldr	w21, [sp, #0x84]
   1226c:      	ldr	x8, [sp, #0x40]
   12270:      	ldr	x10, [sp, #0x60]
   12274:      	sub	x12, x10, x8
   12278:      	ldr	w23, [sp, #0x68]
   1227c:      	subs	w10, w21, w23
   12280:      	ldr	x9, [sp, #0x88]
   12284:      	csel	w10, wzr, w10, lo
   12288:      	cmp	w23, w21
   1228c:      	csel	w11, w23, w21, lo
   12290:      	cinc	w13, w11, hi
   12294:      	sub	w14, w23, w13
   12298:      	subs	x12, x12, x13
   1229c:      	str	w14, [sp, #0x68]
   122a0:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   122a4:      	cmp	x12, #0xfff
   122a8:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   122ac:      	cmp	w23, w21
   122b0:      	b.ls	0x122bc <generic_kprobe_path+0x748c>
   122b4:      	mov	w13, #0x2f              // =47
   122b8:      	strb	w13, [x8, x12]
   122bc:      	add	x19, x8, x12
   122c0:      	cmp	w23, w21
   122c4:      	add	x2, x9, x10
   122c8:      	and	w1, w11, #0xff
   122cc:      	mov	w8, #0x4                // =4
   122d0:      	cinc	x0, x19, hi
   122d4:      	blr	x8
   122d8:      	cmp	w23, w21
   122dc:      	str	x19, [sp, #0x60]
   122e0:      	add	x19, sp, #0x70
   122e4:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   122e8:      	ldr	x21, [sp, #0x78]
   122ec:      	ldp	x2, x24, [sp, #0x50]
   122f0:      	str	x21, [sp, #0x48]
   122f4:      	b	0x12344 <generic_kprobe_path+0x7514>
   122f8:      	add	x2, x24, #0x10
   122fc:      	mov	w8, #0x4                // =4
   12300:      	add	x9, sp, #0x98
   12304:      	add	x0, sp, #0x98
   12308:      	mov	w1, #0x8                // =8
   1230c:      	blr	x8
   12310:      	ldr	x8, [sp, #0x58]
   12314:      	ldr	x9, [sp, #0x98]
   12318:      	cmp	x8, x9
   1231c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   12320:      	add	x2, x24, #0x18
   12324:      	mov	w8, #0x4                // =4
   12328:      	mov	x0, x22
   1232c:      	mov	w1, #0x8                // =8
   12330:      	blr	x8
   12334:      	ldr	x24, [sp, #0x98]
   12338:      	ldr	x21, [sp, #0x48]
   1233c:      	add	x2, x24, #0x20
   12340:      	stp	x2, x24, [sp, #0x50]
   12344:      	ldr	x8, [sp, #0x30]
   12348:      	cmp	x21, x8
   1234c:      	b.ne	0x1235c <generic_kprobe_path+0x752c>
   12350:      	ldr	x8, [sp, #0x38]
   12354:      	cmp	x2, x8
   12358:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1235c:      	mov	w8, #0x4                // =4
   12360:      	add	x0, sp, #0x70
   12364:      	mov	w1, #0x8                // =8
   12368:      	blr	x8
   1236c:      	ldr	x8, [sp, #0x70]
   12370:      	cmp	x21, x8
   12374:      	b.eq	0x12464 <generic_kprobe_path+0x7634>
   12378:      	add	x23, x21, #0x18
   1237c:      	mov	w8, #0x4                // =4
   12380:      	add	x9, sp, #0x98
   12384:      	add	x0, sp, #0x98
   12388:      	mov	w1, #0x8                // =8
   1238c:      	mov	x2, x23
   12390:      	blr	x8
   12394:      	ldr	x8, [sp, #0x98]
   12398:      	cmp	x8, x21
   1239c:      	b.eq	0x12464 <generic_kprobe_path+0x7634>
   123a0:      	mov	w8, #0x4                // =4
   123a4:      	add	x9, sp, #0x78
   123a8:      	add	x0, sp, #0x78
   123ac:      	mov	w1, #0x8                // =8
   123b0:      	mov	x2, x23
   123b4:      	blr	x8
   123b8:      	add	x2, x21, #0x20
   123bc:      	mov	w8, #0x4                // =4
   123c0:      	mov	w9, #0x10               // =16
   123c4:      	add	x10, sp, #0x80
   123c8:      	add	x0, sp, #0x80
   123cc:      	mov	w1, #0x10               // =16
   123d0:      	blr	x8
   123d4:      	ldr	w21, [sp, #0x84]
   123d8:      	ldr	x8, [sp, #0x40]
   123dc:      	ldr	x10, [sp, #0x60]
   123e0:      	sub	x12, x10, x8
   123e4:      	ldr	w23, [sp, #0x68]
   123e8:      	subs	w10, w21, w23
   123ec:      	ldr	x9, [sp, #0x88]
   123f0:      	csel	w10, wzr, w10, lo
   123f4:      	cmp	w23, w21
   123f8:      	csel	w11, w23, w21, lo
   123fc:      	cinc	w13, w11, hi
   12400:      	sub	w14, w23, w13
   12404:      	subs	x12, x12, x13
   12408:      	str	w14, [sp, #0x68]
   1240c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   12410:      	cmp	x12, #0xfff
   12414:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   12418:      	cmp	w23, w21
   1241c:      	b.ls	0x12428 <generic_kprobe_path+0x75f8>
   12420:      	mov	w13, #0x2f              // =47
   12424:      	strb	w13, [x8, x12]
   12428:      	add	x19, x8, x12
   1242c:      	cmp	w23, w21
   12430:      	add	x2, x9, x10
   12434:      	and	w1, w11, #0xff
   12438:      	mov	w8, #0x4                // =4
   1243c:      	cinc	x0, x19, hi
   12440:      	blr	x8
   12444:      	cmp	w23, w21
   12448:      	str	x19, [sp, #0x60]
   1244c:      	add	x19, sp, #0x70
   12450:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   12454:      	ldr	x21, [sp, #0x78]
   12458:      	ldp	x2, x24, [sp, #0x50]
   1245c:      	str	x21, [sp, #0x48]
   12460:      	b	0x124b0 <generic_kprobe_path+0x7680>
   12464:      	add	x2, x24, #0x10
   12468:      	mov	w8, #0x4                // =4
   1246c:      	add	x9, sp, #0x98
   12470:      	add	x0, sp, #0x98
   12474:      	mov	w1, #0x8                // =8
   12478:      	blr	x8
   1247c:      	ldr	x8, [sp, #0x58]
   12480:      	ldr	x9, [sp, #0x98]
   12484:      	cmp	x8, x9
   12488:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1248c:      	add	x2, x24, #0x18
   12490:      	mov	w8, #0x4                // =4
   12494:      	mov	x0, x22
   12498:      	mov	w1, #0x8                // =8
   1249c:      	blr	x8
   124a0:      	ldr	x24, [sp, #0x98]
   124a4:      	ldr	x21, [sp, #0x48]
   124a8:      	add	x2, x24, #0x20
   124ac:      	stp	x2, x24, [sp, #0x50]
   124b0:      	ldr	x8, [sp, #0x30]
   124b4:      	cmp	x21, x8
   124b8:      	b.ne	0x124c8 <generic_kprobe_path+0x7698>
   124bc:      	ldr	x8, [sp, #0x38]
   124c0:      	cmp	x2, x8
   124c4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   124c8:      	mov	w8, #0x4                // =4
   124cc:      	add	x0, sp, #0x70
   124d0:      	mov	w1, #0x8                // =8
   124d4:      	blr	x8
   124d8:      	ldr	x8, [sp, #0x70]
   124dc:      	cmp	x21, x8
   124e0:      	b.eq	0x125d0 <generic_kprobe_path+0x77a0>
   124e4:      	add	x23, x21, #0x18
   124e8:      	mov	w8, #0x4                // =4
   124ec:      	add	x9, sp, #0x98
   124f0:      	add	x0, sp, #0x98
   124f4:      	mov	w1, #0x8                // =8
   124f8:      	mov	x2, x23
   124fc:      	blr	x8
   12500:      	ldr	x8, [sp, #0x98]
   12504:      	cmp	x8, x21
   12508:      	b.eq	0x125d0 <generic_kprobe_path+0x77a0>
   1250c:      	mov	w8, #0x4                // =4
   12510:      	add	x9, sp, #0x78
   12514:      	add	x0, sp, #0x78
   12518:      	mov	w1, #0x8                // =8
   1251c:      	mov	x2, x23
   12520:      	blr	x8
   12524:      	add	x2, x21, #0x20
   12528:      	mov	w8, #0x4                // =4
   1252c:      	mov	w9, #0x10               // =16
   12530:      	add	x10, sp, #0x80
   12534:      	add	x0, sp, #0x80
   12538:      	mov	w1, #0x10               // =16
   1253c:      	blr	x8
   12540:      	ldr	w21, [sp, #0x84]
   12544:      	ldr	x8, [sp, #0x40]
   12548:      	ldr	x10, [sp, #0x60]
   1254c:      	sub	x12, x10, x8
   12550:      	ldr	w23, [sp, #0x68]
   12554:      	subs	w10, w21, w23
   12558:      	ldr	x9, [sp, #0x88]
   1255c:      	csel	w10, wzr, w10, lo
   12560:      	cmp	w23, w21
   12564:      	csel	w11, w23, w21, lo
   12568:      	cinc	w13, w11, hi
   1256c:      	sub	w14, w23, w13
   12570:      	subs	x12, x12, x13
   12574:      	str	w14, [sp, #0x68]
   12578:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   1257c:      	cmp	x12, #0xfff
   12580:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   12584:      	cmp	w23, w21
   12588:      	b.ls	0x12594 <generic_kprobe_path+0x7764>
   1258c:      	mov	w13, #0x2f              // =47
   12590:      	strb	w13, [x8, x12]
   12594:      	add	x19, x8, x12
   12598:      	cmp	w23, w21
   1259c:      	add	x2, x9, x10
   125a0:      	and	w1, w11, #0xff
   125a4:      	mov	w8, #0x4                // =4
   125a8:      	cinc	x0, x19, hi
   125ac:      	blr	x8
   125b0:      	cmp	w23, w21
   125b4:      	str	x19, [sp, #0x60]
   125b8:      	add	x19, sp, #0x70
   125bc:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   125c0:      	ldr	x21, [sp, #0x78]
   125c4:      	ldp	x2, x24, [sp, #0x50]
   125c8:      	str	x21, [sp, #0x48]
   125cc:      	b	0x1261c <generic_kprobe_path+0x77ec>
   125d0:      	add	x2, x24, #0x10
   125d4:      	mov	w8, #0x4                // =4
   125d8:      	add	x9, sp, #0x98
   125dc:      	add	x0, sp, #0x98
   125e0:      	mov	w1, #0x8                // =8
   125e4:      	blr	x8
   125e8:      	ldr	x8, [sp, #0x58]
   125ec:      	ldr	x9, [sp, #0x98]
   125f0:      	cmp	x8, x9
   125f4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   125f8:      	add	x2, x24, #0x18
   125fc:      	mov	w8, #0x4                // =4
   12600:      	mov	x0, x22
   12604:      	mov	w1, #0x8                // =8
   12608:      	blr	x8
   1260c:      	ldr	x24, [sp, #0x98]
   12610:      	ldr	x21, [sp, #0x48]
   12614:      	add	x2, x24, #0x20
   12618:      	stp	x2, x24, [sp, #0x50]
   1261c:      	ldr	x8, [sp, #0x30]
   12620:      	cmp	x21, x8
   12624:      	b.ne	0x12634 <generic_kprobe_path+0x7804>
   12628:      	ldr	x8, [sp, #0x38]
   1262c:      	cmp	x2, x8
   12630:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   12634:      	mov	w8, #0x4                // =4
   12638:      	add	x0, sp, #0x70
   1263c:      	mov	w1, #0x8                // =8
   12640:      	blr	x8
   12644:      	ldr	x8, [sp, #0x70]
   12648:      	cmp	x21, x8
   1264c:      	b.eq	0x1273c <generic_kprobe_path+0x790c>
   12650:      	add	x23, x21, #0x18
   12654:      	mov	w8, #0x4                // =4
   12658:      	add	x9, sp, #0x98
   1265c:      	add	x0, sp, #0x98
   12660:      	mov	w1, #0x8                // =8
   12664:      	mov	x2, x23
   12668:      	blr	x8
   1266c:      	ldr	x8, [sp, #0x98]
   12670:      	cmp	x8, x21
   12674:      	b.eq	0x1273c <generic_kprobe_path+0x790c>
   12678:      	mov	w8, #0x4                // =4
   1267c:      	add	x9, sp, #0x78
   12680:      	add	x0, sp, #0x78
   12684:      	mov	w1, #0x8                // =8
   12688:      	mov	x2, x23
   1268c:      	blr	x8
   12690:      	add	x2, x21, #0x20
   12694:      	mov	w8, #0x4                // =4
   12698:      	mov	w9, #0x10               // =16
   1269c:      	add	x10, sp, #0x80
   126a0:      	add	x0, sp, #0x80
   126a4:      	mov	w1, #0x10               // =16
   126a8:      	blr	x8
   126ac:      	ldr	w21, [sp, #0x84]
   126b0:      	ldr	x8, [sp, #0x40]
   126b4:      	ldr	x10, [sp, #0x60]
   126b8:      	sub	x12, x10, x8
   126bc:      	ldr	w23, [sp, #0x68]
   126c0:      	subs	w10, w21, w23
   126c4:      	ldr	x9, [sp, #0x88]
   126c8:      	csel	w10, wzr, w10, lo
   126cc:      	cmp	w23, w21
   126d0:      	csel	w11, w23, w21, lo
   126d4:      	cinc	w13, w11, hi
   126d8:      	sub	w14, w23, w13
   126dc:      	subs	x12, x12, x13
   126e0:      	str	w14, [sp, #0x68]
   126e4:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   126e8:      	cmp	x12, #0xfff
   126ec:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   126f0:      	cmp	w23, w21
   126f4:      	b.ls	0x12700 <generic_kprobe_path+0x78d0>
   126f8:      	mov	w13, #0x2f              // =47
   126fc:      	strb	w13, [x8, x12]
   12700:      	add	x19, x8, x12
   12704:      	cmp	w23, w21
   12708:      	add	x2, x9, x10
   1270c:      	and	w1, w11, #0xff
   12710:      	mov	w8, #0x4                // =4
   12714:      	cinc	x0, x19, hi
   12718:      	blr	x8
   1271c:      	cmp	w23, w21
   12720:      	str	x19, [sp, #0x60]
   12724:      	add	x19, sp, #0x70
   12728:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   1272c:      	ldr	x21, [sp, #0x78]
   12730:      	ldp	x2, x24, [sp, #0x50]
   12734:      	str	x21, [sp, #0x48]
   12738:      	b	0x12788 <generic_kprobe_path+0x7958>
   1273c:      	add	x2, x24, #0x10
   12740:      	mov	w8, #0x4                // =4
   12744:      	add	x9, sp, #0x98
   12748:      	add	x0, sp, #0x98
   1274c:      	mov	w1, #0x8                // =8
   12750:      	blr	x8
   12754:      	ldr	x8, [sp, #0x58]
   12758:      	ldr	x9, [sp, #0x98]
   1275c:      	cmp	x8, x9
   12760:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   12764:      	add	x2, x24, #0x18
   12768:      	mov	w8, #0x4                // =4
   1276c:      	mov	x0, x22
   12770:      	mov	w1, #0x8                // =8
   12774:      	blr	x8
   12778:      	ldr	x24, [sp, #0x98]
   1277c:      	ldr	x21, [sp, #0x48]
   12780:      	add	x2, x24, #0x20
   12784:      	stp	x2, x24, [sp, #0x50]
   12788:      	ldr	x8, [sp, #0x30]
   1278c:      	cmp	x21, x8
   12790:      	b.ne	0x127a0 <generic_kprobe_path+0x7970>
   12794:      	ldr	x8, [sp, #0x38]
   12798:      	cmp	x2, x8
   1279c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   127a0:      	mov	w8, #0x4                // =4
   127a4:      	add	x0, sp, #0x70
   127a8:      	mov	w1, #0x8                // =8
   127ac:      	blr	x8
   127b0:      	ldr	x8, [sp, #0x70]
   127b4:      	cmp	x21, x8
   127b8:      	b.eq	0x128a8 <generic_kprobe_path+0x7a78>
   127bc:      	add	x23, x21, #0x18
   127c0:      	mov	w8, #0x4                // =4
   127c4:      	add	x9, sp, #0x98
   127c8:      	add	x0, sp, #0x98
   127cc:      	mov	w1, #0x8                // =8
   127d0:      	mov	x2, x23
   127d4:      	blr	x8
   127d8:      	ldr	x8, [sp, #0x98]
   127dc:      	cmp	x8, x21
   127e0:      	b.eq	0x128a8 <generic_kprobe_path+0x7a78>
   127e4:      	mov	w8, #0x4                // =4
   127e8:      	add	x9, sp, #0x78
   127ec:      	add	x0, sp, #0x78
   127f0:      	mov	w1, #0x8                // =8
   127f4:      	mov	x2, x23
   127f8:      	blr	x8
   127fc:      	add	x2, x21, #0x20
   12800:      	mov	w8, #0x4                // =4
   12804:      	mov	w9, #0x10               // =16
   12808:      	add	x10, sp, #0x80
   1280c:      	add	x0, sp, #0x80
   12810:      	mov	w1, #0x10               // =16
   12814:      	blr	x8
   12818:      	ldr	w21, [sp, #0x84]
   1281c:      	ldr	x8, [sp, #0x40]
   12820:      	ldr	x10, [sp, #0x60]
   12824:      	sub	x12, x10, x8
   12828:      	ldr	w23, [sp, #0x68]
   1282c:      	subs	w10, w21, w23
   12830:      	ldr	x9, [sp, #0x88]
   12834:      	csel	w10, wzr, w10, lo
   12838:      	cmp	w23, w21
   1283c:      	csel	w11, w23, w21, lo
   12840:      	cinc	w13, w11, hi
   12844:      	sub	w14, w23, w13
   12848:      	subs	x12, x12, x13
   1284c:      	str	w14, [sp, #0x68]
   12850:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   12854:      	cmp	x12, #0xfff
   12858:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   1285c:      	cmp	w23, w21
   12860:      	b.ls	0x1286c <generic_kprobe_path+0x7a3c>
   12864:      	mov	w13, #0x2f              // =47
   12868:      	strb	w13, [x8, x12]
   1286c:      	add	x19, x8, x12
   12870:      	cmp	w23, w21
   12874:      	add	x2, x9, x10
   12878:      	and	w1, w11, #0xff
   1287c:      	mov	w8, #0x4                // =4
   12880:      	cinc	x0, x19, hi
   12884:      	blr	x8
   12888:      	cmp	w23, w21
   1288c:      	str	x19, [sp, #0x60]
   12890:      	add	x19, sp, #0x70
   12894:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   12898:      	ldr	x21, [sp, #0x78]
   1289c:      	ldp	x2, x24, [sp, #0x50]
   128a0:      	str	x21, [sp, #0x48]
   128a4:      	b	0x128f4 <generic_kprobe_path+0x7ac4>
   128a8:      	add	x2, x24, #0x10
   128ac:      	mov	w8, #0x4                // =4
   128b0:      	add	x9, sp, #0x98
   128b4:      	add	x0, sp, #0x98
   128b8:      	mov	w1, #0x8                // =8
   128bc:      	blr	x8
   128c0:      	ldr	x8, [sp, #0x58]
   128c4:      	ldr	x9, [sp, #0x98]
   128c8:      	cmp	x8, x9
   128cc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   128d0:      	add	x2, x24, #0x18
   128d4:      	mov	w8, #0x4                // =4
   128d8:      	mov	x0, x22
   128dc:      	mov	w1, #0x8                // =8
   128e0:      	blr	x8
   128e4:      	ldr	x24, [sp, #0x98]
   128e8:      	ldr	x21, [sp, #0x48]
   128ec:      	add	x2, x24, #0x20
   128f0:      	stp	x2, x24, [sp, #0x50]
   128f4:      	ldr	x8, [sp, #0x30]
   128f8:      	cmp	x21, x8
   128fc:      	b.ne	0x1290c <generic_kprobe_path+0x7adc>
   12900:      	ldr	x8, [sp, #0x38]
   12904:      	cmp	x2, x8
   12908:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1290c:      	mov	w8, #0x4                // =4
   12910:      	add	x0, sp, #0x70
   12914:      	mov	w1, #0x8                // =8
   12918:      	blr	x8
   1291c:      	ldr	x8, [sp, #0x70]
   12920:      	cmp	x21, x8
   12924:      	b.eq	0x12a14 <generic_kprobe_path+0x7be4>
   12928:      	add	x23, x21, #0x18
   1292c:      	mov	w8, #0x4                // =4
   12930:      	add	x9, sp, #0x98
   12934:      	add	x0, sp, #0x98
   12938:      	mov	w1, #0x8                // =8
   1293c:      	mov	x2, x23
   12940:      	blr	x8
   12944:      	ldr	x8, [sp, #0x98]
   12948:      	cmp	x8, x21
   1294c:      	b.eq	0x12a14 <generic_kprobe_path+0x7be4>
   12950:      	mov	w8, #0x4                // =4
   12954:      	add	x9, sp, #0x78
   12958:      	add	x0, sp, #0x78
   1295c:      	mov	w1, #0x8                // =8
   12960:      	mov	x2, x23
   12964:      	blr	x8
   12968:      	add	x2, x21, #0x20
   1296c:      	mov	w8, #0x4                // =4
   12970:      	mov	w9, #0x10               // =16
   12974:      	add	x10, sp, #0x80
   12978:      	add	x0, sp, #0x80
   1297c:      	mov	w1, #0x10               // =16
   12980:      	blr	x8
   12984:      	ldr	w21, [sp, #0x84]
   12988:      	ldr	x8, [sp, #0x40]
   1298c:      	ldr	x10, [sp, #0x60]
   12990:      	sub	x12, x10, x8
   12994:      	ldr	w23, [sp, #0x68]
   12998:      	subs	w10, w21, w23
   1299c:      	ldr	x9, [sp, #0x88]
   129a0:      	csel	w10, wzr, w10, lo
   129a4:      	cmp	w23, w21
   129a8:      	csel	w11, w23, w21, lo
   129ac:      	cinc	w13, w11, hi
   129b0:      	sub	w14, w23, w13
   129b4:      	subs	x12, x12, x13
   129b8:      	str	w14, [sp, #0x68]
   129bc:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   129c0:      	cmp	x12, #0xfff
   129c4:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   129c8:      	cmp	w23, w21
   129cc:      	b.ls	0x129d8 <generic_kprobe_path+0x7ba8>
   129d0:      	mov	w13, #0x2f              // =47
   129d4:      	strb	w13, [x8, x12]
   129d8:      	add	x19, x8, x12
   129dc:      	cmp	w23, w21
   129e0:      	add	x2, x9, x10
   129e4:      	and	w1, w11, #0xff
   129e8:      	mov	w8, #0x4                // =4
   129ec:      	cinc	x0, x19, hi
   129f0:      	blr	x8
   129f4:      	cmp	w23, w21
   129f8:      	str	x19, [sp, #0x60]
   129fc:      	add	x19, sp, #0x70
   12a00:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   12a04:      	ldr	x21, [sp, #0x78]
   12a08:      	ldp	x2, x24, [sp, #0x50]
   12a0c:      	str	x21, [sp, #0x48]
   12a10:      	b	0x12a60 <generic_kprobe_path+0x7c30>
   12a14:      	add	x2, x24, #0x10
   12a18:      	mov	w8, #0x4                // =4
   12a1c:      	add	x9, sp, #0x98
   12a20:      	add	x0, sp, #0x98
   12a24:      	mov	w1, #0x8                // =8
   12a28:      	blr	x8
   12a2c:      	ldr	x8, [sp, #0x58]
   12a30:      	ldr	x9, [sp, #0x98]
   12a34:      	cmp	x8, x9
   12a38:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   12a3c:      	add	x2, x24, #0x18
   12a40:      	mov	w8, #0x4                // =4
   12a44:      	mov	x0, x22
   12a48:      	mov	w1, #0x8                // =8
   12a4c:      	blr	x8
   12a50:      	ldr	x24, [sp, #0x98]
   12a54:      	ldr	x21, [sp, #0x48]
   12a58:      	add	x2, x24, #0x20
   12a5c:      	stp	x2, x24, [sp, #0x50]
   12a60:      	ldr	x8, [sp, #0x30]
   12a64:      	cmp	x21, x8
   12a68:      	b.ne	0x12a78 <generic_kprobe_path+0x7c48>
   12a6c:      	ldr	x8, [sp, #0x38]
   12a70:      	cmp	x2, x8
   12a74:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   12a78:      	mov	w8, #0x4                // =4
   12a7c:      	add	x0, sp, #0x70
   12a80:      	mov	w1, #0x8                // =8
   12a84:      	blr	x8
   12a88:      	ldr	x8, [sp, #0x70]
   12a8c:      	cmp	x21, x8
   12a90:      	b.eq	0x12b80 <generic_kprobe_path+0x7d50>
   12a94:      	add	x23, x21, #0x18
   12a98:      	mov	w8, #0x4                // =4
   12a9c:      	add	x9, sp, #0x98
   12aa0:      	add	x0, sp, #0x98
   12aa4:      	mov	w1, #0x8                // =8
   12aa8:      	mov	x2, x23
   12aac:      	blr	x8
   12ab0:      	ldr	x8, [sp, #0x98]
   12ab4:      	cmp	x8, x21
   12ab8:      	b.eq	0x12b80 <generic_kprobe_path+0x7d50>
   12abc:      	mov	w8, #0x4                // =4
   12ac0:      	add	x9, sp, #0x78
   12ac4:      	add	x0, sp, #0x78
   12ac8:      	mov	w1, #0x8                // =8
   12acc:      	mov	x2, x23
   12ad0:      	blr	x8
   12ad4:      	add	x2, x21, #0x20
   12ad8:      	mov	w8, #0x4                // =4
   12adc:      	mov	w9, #0x10               // =16
   12ae0:      	add	x10, sp, #0x80
   12ae4:      	add	x0, sp, #0x80
   12ae8:      	mov	w1, #0x10               // =16
   12aec:      	blr	x8
   12af0:      	ldr	w21, [sp, #0x84]
   12af4:      	ldr	x8, [sp, #0x40]
   12af8:      	ldr	x10, [sp, #0x60]
   12afc:      	sub	x12, x10, x8
   12b00:      	ldr	w23, [sp, #0x68]
   12b04:      	subs	w10, w21, w23
   12b08:      	ldr	x9, [sp, #0x88]
   12b0c:      	csel	w10, wzr, w10, lo
   12b10:      	cmp	w23, w21
   12b14:      	csel	w11, w23, w21, lo
   12b18:      	cinc	w13, w11, hi
   12b1c:      	sub	w14, w23, w13
   12b20:      	subs	x12, x12, x13
   12b24:      	str	w14, [sp, #0x68]
   12b28:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   12b2c:      	cmp	x12, #0xfff
   12b30:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   12b34:      	cmp	w23, w21
   12b38:      	b.ls	0x12b44 <generic_kprobe_path+0x7d14>
   12b3c:      	mov	w13, #0x2f              // =47
   12b40:      	strb	w13, [x8, x12]
   12b44:      	add	x19, x8, x12
   12b48:      	cmp	w23, w21
   12b4c:      	add	x2, x9, x10
   12b50:      	and	w1, w11, #0xff
   12b54:      	mov	w8, #0x4                // =4
   12b58:      	cinc	x0, x19, hi
   12b5c:      	blr	x8
   12b60:      	cmp	w23, w21
   12b64:      	str	x19, [sp, #0x60]
   12b68:      	add	x19, sp, #0x70
   12b6c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   12b70:      	ldr	x21, [sp, #0x78]
   12b74:      	ldp	x2, x24, [sp, #0x50]
   12b78:      	str	x21, [sp, #0x48]
   12b7c:      	b	0x12bcc <generic_kprobe_path+0x7d9c>
   12b80:      	add	x2, x24, #0x10
   12b84:      	mov	w8, #0x4                // =4
   12b88:      	add	x9, sp, #0x98
   12b8c:      	add	x0, sp, #0x98
   12b90:      	mov	w1, #0x8                // =8
   12b94:      	blr	x8
   12b98:      	ldr	x8, [sp, #0x58]
   12b9c:      	ldr	x9, [sp, #0x98]
   12ba0:      	cmp	x8, x9
   12ba4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   12ba8:      	add	x2, x24, #0x18
   12bac:      	mov	w8, #0x4                // =4
   12bb0:      	mov	x0, x22
   12bb4:      	mov	w1, #0x8                // =8
   12bb8:      	blr	x8
   12bbc:      	ldr	x24, [sp, #0x98]
   12bc0:      	ldr	x21, [sp, #0x48]
   12bc4:      	add	x2, x24, #0x20
   12bc8:      	stp	x2, x24, [sp, #0x50]
   12bcc:      	ldr	x8, [sp, #0x30]
   12bd0:      	cmp	x21, x8
   12bd4:      	b.ne	0x12be4 <generic_kprobe_path+0x7db4>
   12bd8:      	ldr	x8, [sp, #0x38]
   12bdc:      	cmp	x2, x8
   12be0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   12be4:      	str	x25, [sp, #0x8]
   12be8:      	mov	w8, #0x4                // =4
   12bec:      	add	x0, sp, #0x70
   12bf0:      	mov	w1, #0x8                // =8
   12bf4:      	blr	x8
   12bf8:      	ldr	x8, [sp, #0x70]
   12bfc:      	cmp	x21, x8
   12c00:      	b.eq	0x12cf4 <generic_kprobe_path+0x7ec4>
   12c04:      	add	x23, x21, #0x18
   12c08:      	mov	w8, #0x4                // =4
   12c0c:      	add	x9, sp, #0x98
   12c10:      	add	x0, sp, #0x98
   12c14:      	mov	w1, #0x8                // =8
   12c18:      	mov	x2, x23
   12c1c:      	blr	x8
   12c20:      	ldr	x8, [sp, #0x98]
   12c24:      	cmp	x8, x21
   12c28:      	b.eq	0x12cf4 <generic_kprobe_path+0x7ec4>
   12c2c:      	mov	w8, #0x4                // =4
   12c30:      	add	x9, sp, #0x78
   12c34:      	add	x0, sp, #0x78
   12c38:      	mov	w1, #0x8                // =8
   12c3c:      	mov	x2, x23
   12c40:      	blr	x8
   12c44:      	add	x2, x21, #0x20
   12c48:      	mov	w8, #0x4                // =4
   12c4c:      	mov	w9, #0x10               // =16
   12c50:      	add	x10, sp, #0x80
   12c54:      	add	x0, sp, #0x80
   12c58:      	mov	w1, #0x10               // =16
   12c5c:      	blr	x8
   12c60:      	ldr	w21, [sp, #0x84]
   12c64:      	ldr	x8, [sp, #0x40]
   12c68:      	ldr	x10, [sp, #0x60]
   12c6c:      	sub	x12, x10, x8
   12c70:      	ldr	w23, [sp, #0x68]
   12c74:      	subs	w10, w21, w23
   12c78:      	ldr	x9, [sp, #0x88]
   12c7c:      	ldr	x25, [sp, #0x8]
   12c80:      	csel	w10, wzr, w10, lo
   12c84:      	cmp	w23, w21
   12c88:      	csel	w11, w23, w21, lo
   12c8c:      	cinc	w13, w11, hi
   12c90:      	sub	w14, w23, w13
   12c94:      	subs	x12, x12, x13
   12c98:      	str	w14, [sp, #0x68]
   12c9c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   12ca0:      	cmp	x12, #0xfff
   12ca4:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   12ca8:      	cmp	w23, w21
   12cac:      	b.ls	0x12cb8 <generic_kprobe_path+0x7e88>
   12cb0:      	mov	w13, #0x2f              // =47
   12cb4:      	strb	w13, [x8, x12]
   12cb8:      	add	x19, x8, x12
   12cbc:      	cmp	w23, w21
   12cc0:      	add	x2, x9, x10
   12cc4:      	and	w1, w11, #0xff
   12cc8:      	mov	w8, #0x4                // =4
   12ccc:      	cinc	x0, x19, hi
   12cd0:      	blr	x8
   12cd4:      	ldr	x25, [sp, #0x8]
   12cd8:      	cmp	w23, w21
   12cdc:      	str	x19, [sp, #0x60]
   12ce0:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   12ce4:      	ldr	x21, [sp, #0x78]
   12ce8:      	ldp	x2, x24, [sp, #0x50]
   12cec:      	str	x21, [sp, #0x48]
   12cf0:      	b	0x12d44 <generic_kprobe_path+0x7f14>
   12cf4:      	add	x2, x24, #0x10
   12cf8:      	mov	w8, #0x4                // =4
   12cfc:      	add	x9, sp, #0x98
   12d00:      	add	x0, sp, #0x98
   12d04:      	mov	w1, #0x8                // =8
   12d08:      	blr	x8
   12d0c:      	ldr	x8, [sp, #0x58]
   12d10:      	ldr	x9, [sp, #0x98]
   12d14:      	cmp	x8, x9
   12d18:      	ldr	x25, [sp, #0x8]
   12d1c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   12d20:      	add	x2, x24, #0x18
   12d24:      	mov	w8, #0x4                // =4
   12d28:      	mov	x0, x22
   12d2c:      	mov	w1, #0x8                // =8
   12d30:      	blr	x8
   12d34:      	ldr	x24, [sp, #0x98]
   12d38:      	ldr	x21, [sp, #0x48]
   12d3c:      	add	x2, x24, #0x20
   12d40:      	stp	x2, x24, [sp, #0x50]
   12d44:      	ldr	x8, [sp, #0x30]
   12d48:      	ldr	x25, [sp, #0x8]
   12d4c:      	add	x9, sp, #0x70
   12d50:      	cmp	x21, x8
   12d54:      	b.ne	0x12d64 <generic_kprobe_path+0x7f34>
   12d58:      	ldr	x8, [sp, #0x38]
   12d5c:      	cmp	x2, x8
   12d60:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   12d64:      	mov	w8, #0x4                // =4
   12d68:      	add	x0, sp, #0x70
   12d6c:      	mov	w1, #0x8                // =8
   12d70:      	blr	x8
   12d74:      	ldr	x8, [sp, #0x70]
   12d78:      	cmp	x21, x8
   12d7c:      	b.eq	0x12e70 <generic_kprobe_path+0x8040>
   12d80:      	add	x23, x21, #0x18
   12d84:      	mov	w8, #0x4                // =4
   12d88:      	add	x9, sp, #0x98
   12d8c:      	add	x0, sp, #0x98
   12d90:      	mov	w1, #0x8                // =8
   12d94:      	mov	x2, x23
   12d98:      	blr	x8
   12d9c:      	ldr	x8, [sp, #0x98]
   12da0:      	cmp	x8, x21
   12da4:      	b.eq	0x12e70 <generic_kprobe_path+0x8040>
   12da8:      	mov	w8, #0x4                // =4
   12dac:      	add	x9, sp, #0x78
   12db0:      	add	x0, sp, #0x78
   12db4:      	mov	w1, #0x8                // =8
   12db8:      	mov	x2, x23
   12dbc:      	blr	x8
   12dc0:      	add	x2, x21, #0x20
   12dc4:      	mov	w8, #0x4                // =4
   12dc8:      	mov	w9, #0x10               // =16
   12dcc:      	add	x10, sp, #0x80
   12dd0:      	add	x0, sp, #0x80
   12dd4:      	mov	w1, #0x10               // =16
   12dd8:      	blr	x8
   12ddc:      	ldr	w21, [sp, #0x84]
   12de0:      	ldr	x8, [sp, #0x40]
   12de4:      	ldr	x10, [sp, #0x60]
   12de8:      	sub	x12, x10, x8
   12dec:      	ldr	w23, [sp, #0x68]
   12df0:      	subs	w10, w21, w23
   12df4:      	ldr	x9, [sp, #0x88]
   12df8:      	ldr	x25, [sp, #0x8]
   12dfc:      	csel	w10, wzr, w10, lo
   12e00:      	cmp	w23, w21
   12e04:      	csel	w11, w23, w21, lo
   12e08:      	cinc	w13, w11, hi
   12e0c:      	sub	w14, w23, w13
   12e10:      	subs	x12, x12, x13
   12e14:      	str	w14, [sp, #0x68]
   12e18:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   12e1c:      	cmp	x12, #0xfff
   12e20:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   12e24:      	cmp	w23, w21
   12e28:      	b.ls	0x12e34 <generic_kprobe_path+0x8004>
   12e2c:      	mov	w13, #0x2f              // =47
   12e30:      	strb	w13, [x8, x12]
   12e34:      	add	x19, x8, x12
   12e38:      	cmp	w23, w21
   12e3c:      	add	x2, x9, x10
   12e40:      	and	w1, w11, #0xff
   12e44:      	mov	w8, #0x4                // =4
   12e48:      	cinc	x0, x19, hi
   12e4c:      	blr	x8
   12e50:      	ldr	x25, [sp, #0x8]
   12e54:      	cmp	w23, w21
   12e58:      	str	x19, [sp, #0x60]
   12e5c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   12e60:      	ldr	x21, [sp, #0x78]
   12e64:      	ldp	x2, x24, [sp, #0x50]
   12e68:      	str	x21, [sp, #0x48]
   12e6c:      	b	0x12ec0 <generic_kprobe_path+0x8090>
   12e70:      	add	x2, x24, #0x10
   12e74:      	mov	w8, #0x4                // =4
   12e78:      	add	x9, sp, #0x98
   12e7c:      	add	x0, sp, #0x98
   12e80:      	mov	w1, #0x8                // =8
   12e84:      	blr	x8
   12e88:      	ldr	x8, [sp, #0x58]
   12e8c:      	ldr	x9, [sp, #0x98]
   12e90:      	cmp	x8, x9
   12e94:      	ldr	x25, [sp, #0x8]
   12e98:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   12e9c:      	add	x2, x24, #0x18
   12ea0:      	mov	w8, #0x4                // =4
   12ea4:      	mov	x0, x22
   12ea8:      	mov	w1, #0x8                // =8
   12eac:      	blr	x8
   12eb0:      	ldr	x24, [sp, #0x98]
   12eb4:      	ldr	x21, [sp, #0x48]
   12eb8:      	add	x2, x24, #0x20
   12ebc:      	stp	x2, x24, [sp, #0x50]
   12ec0:      	ldr	x8, [sp, #0x30]
   12ec4:      	ldr	x25, [sp, #0x8]
   12ec8:      	add	x9, sp, #0x70
   12ecc:      	cmp	x21, x8
   12ed0:      	b.ne	0x12ee0 <generic_kprobe_path+0x80b0>
   12ed4:      	ldr	x8, [sp, #0x38]
   12ed8:      	cmp	x2, x8
   12edc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   12ee0:      	mov	w8, #0x4                // =4
   12ee4:      	add	x0, sp, #0x70
   12ee8:      	mov	w1, #0x8                // =8
   12eec:      	blr	x8
   12ef0:      	ldr	x8, [sp, #0x70]
   12ef4:      	cmp	x21, x8
   12ef8:      	b.eq	0x12fec <generic_kprobe_path+0x81bc>
   12efc:      	add	x23, x21, #0x18
   12f00:      	mov	w8, #0x4                // =4
   12f04:      	add	x9, sp, #0x98
   12f08:      	add	x0, sp, #0x98
   12f0c:      	mov	w1, #0x8                // =8
   12f10:      	mov	x2, x23
   12f14:      	blr	x8
   12f18:      	ldr	x8, [sp, #0x98]
   12f1c:      	cmp	x8, x21
   12f20:      	b.eq	0x12fec <generic_kprobe_path+0x81bc>
   12f24:      	mov	w8, #0x4                // =4
   12f28:      	add	x9, sp, #0x78
   12f2c:      	add	x0, sp, #0x78
   12f30:      	mov	w1, #0x8                // =8
   12f34:      	mov	x2, x23
   12f38:      	blr	x8
   12f3c:      	add	x2, x21, #0x20
   12f40:      	mov	w8, #0x4                // =4
   12f44:      	mov	w9, #0x10               // =16
   12f48:      	add	x10, sp, #0x80
   12f4c:      	add	x0, sp, #0x80
   12f50:      	mov	w1, #0x10               // =16
   12f54:      	blr	x8
   12f58:      	ldr	w21, [sp, #0x84]
   12f5c:      	ldr	x8, [sp, #0x40]
   12f60:      	ldr	x10, [sp, #0x60]
   12f64:      	sub	x12, x10, x8
   12f68:      	ldr	w23, [sp, #0x68]
   12f6c:      	subs	w10, w21, w23
   12f70:      	ldr	x9, [sp, #0x88]
   12f74:      	ldr	x25, [sp, #0x8]
   12f78:      	csel	w10, wzr, w10, lo
   12f7c:      	cmp	w23, w21
   12f80:      	csel	w11, w23, w21, lo
   12f84:      	cinc	w13, w11, hi
   12f88:      	sub	w14, w23, w13
   12f8c:      	subs	x12, x12, x13
   12f90:      	str	w14, [sp, #0x68]
   12f94:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   12f98:      	cmp	x12, #0xfff
   12f9c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   12fa0:      	cmp	w23, w21
   12fa4:      	b.ls	0x12fb0 <generic_kprobe_path+0x8180>
   12fa8:      	mov	w13, #0x2f              // =47
   12fac:      	strb	w13, [x8, x12]
   12fb0:      	add	x19, x8, x12
   12fb4:      	cmp	w23, w21
   12fb8:      	add	x2, x9, x10
   12fbc:      	and	w1, w11, #0xff
   12fc0:      	mov	w8, #0x4                // =4
   12fc4:      	cinc	x0, x19, hi
   12fc8:      	blr	x8
   12fcc:      	ldr	x25, [sp, #0x8]
   12fd0:      	cmp	w23, w21
   12fd4:      	str	x19, [sp, #0x60]
   12fd8:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   12fdc:      	ldr	x21, [sp, #0x78]
   12fe0:      	ldp	x2, x24, [sp, #0x50]
   12fe4:      	str	x21, [sp, #0x48]
   12fe8:      	b	0x1303c <generic_kprobe_path+0x820c>
   12fec:      	add	x2, x24, #0x10
   12ff0:      	mov	w8, #0x4                // =4
   12ff4:      	add	x9, sp, #0x98
   12ff8:      	add	x0, sp, #0x98
   12ffc:      	mov	w1, #0x8                // =8
   13000:      	blr	x8
   13004:      	ldr	x8, [sp, #0x58]
   13008:      	ldr	x9, [sp, #0x98]
   1300c:      	cmp	x8, x9
   13010:      	ldr	x25, [sp, #0x8]
   13014:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   13018:      	add	x2, x24, #0x18
   1301c:      	mov	w8, #0x4                // =4
   13020:      	mov	x0, x22
   13024:      	mov	w1, #0x8                // =8
   13028:      	blr	x8
   1302c:      	ldr	x24, [sp, #0x98]
   13030:      	ldr	x21, [sp, #0x48]
   13034:      	add	x2, x24, #0x20
   13038:      	stp	x2, x24, [sp, #0x50]
   1303c:      	ldr	x8, [sp, #0x30]
   13040:      	ldr	x25, [sp, #0x8]
   13044:      	add	x9, sp, #0x70
   13048:      	cmp	x21, x8
   1304c:      	b.ne	0x1305c <generic_kprobe_path+0x822c>
   13050:      	ldr	x8, [sp, #0x38]
   13054:      	cmp	x2, x8
   13058:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1305c:      	mov	w8, #0x4                // =4
   13060:      	add	x0, sp, #0x70
   13064:      	mov	w1, #0x8                // =8
   13068:      	blr	x8
   1306c:      	ldr	x8, [sp, #0x70]
   13070:      	cmp	x21, x8
   13074:      	b.eq	0x13168 <generic_kprobe_path+0x8338>
   13078:      	add	x23, x21, #0x18
   1307c:      	mov	w8, #0x4                // =4
   13080:      	add	x9, sp, #0x98
   13084:      	add	x0, sp, #0x98
   13088:      	mov	w1, #0x8                // =8
   1308c:      	mov	x2, x23
   13090:      	blr	x8
   13094:      	ldr	x8, [sp, #0x98]
   13098:      	cmp	x8, x21
   1309c:      	b.eq	0x13168 <generic_kprobe_path+0x8338>
   130a0:      	mov	w8, #0x4                // =4
   130a4:      	add	x9, sp, #0x78
   130a8:      	add	x0, sp, #0x78
   130ac:      	mov	w1, #0x8                // =8
   130b0:      	mov	x2, x23
   130b4:      	blr	x8
   130b8:      	add	x2, x21, #0x20
   130bc:      	mov	w8, #0x4                // =4
   130c0:      	mov	w9, #0x10               // =16
   130c4:      	add	x10, sp, #0x80
   130c8:      	add	x0, sp, #0x80
   130cc:      	mov	w1, #0x10               // =16
   130d0:      	blr	x8
   130d4:      	ldr	w21, [sp, #0x84]
   130d8:      	ldr	x8, [sp, #0x40]
   130dc:      	ldr	x10, [sp, #0x60]
   130e0:      	sub	x12, x10, x8
   130e4:      	ldr	w23, [sp, #0x68]
   130e8:      	subs	w10, w21, w23
   130ec:      	ldr	x9, [sp, #0x88]
   130f0:      	ldr	x25, [sp, #0x8]
   130f4:      	csel	w10, wzr, w10, lo
   130f8:      	cmp	w23, w21
   130fc:      	csel	w11, w23, w21, lo
   13100:      	cinc	w13, w11, hi
   13104:      	sub	w14, w23, w13
   13108:      	subs	x12, x12, x13
   1310c:      	str	w14, [sp, #0x68]
   13110:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   13114:      	cmp	x12, #0xfff
   13118:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   1311c:      	cmp	w23, w21
   13120:      	b.ls	0x1312c <generic_kprobe_path+0x82fc>
   13124:      	mov	w13, #0x2f              // =47
   13128:      	strb	w13, [x8, x12]
   1312c:      	add	x19, x8, x12
   13130:      	cmp	w23, w21
   13134:      	add	x2, x9, x10
   13138:      	and	w1, w11, #0xff
   1313c:      	mov	w8, #0x4                // =4
   13140:      	cinc	x0, x19, hi
   13144:      	blr	x8
   13148:      	ldr	x25, [sp, #0x8]
   1314c:      	cmp	w23, w21
   13150:      	str	x19, [sp, #0x60]
   13154:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   13158:      	ldr	x21, [sp, #0x78]
   1315c:      	ldp	x2, x24, [sp, #0x50]
   13160:      	str	x21, [sp, #0x48]
   13164:      	b	0x131b8 <generic_kprobe_path+0x8388>
   13168:      	add	x2, x24, #0x10
   1316c:      	mov	w8, #0x4                // =4
   13170:      	add	x9, sp, #0x98
   13174:      	add	x0, sp, #0x98
   13178:      	mov	w1, #0x8                // =8
   1317c:      	blr	x8
   13180:      	ldr	x8, [sp, #0x58]
   13184:      	ldr	x9, [sp, #0x98]
   13188:      	cmp	x8, x9
   1318c:      	ldr	x25, [sp, #0x8]
   13190:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   13194:      	add	x2, x24, #0x18
   13198:      	mov	w8, #0x4                // =4
   1319c:      	mov	x0, x22
   131a0:      	mov	w1, #0x8                // =8
   131a4:      	blr	x8
   131a8:      	ldr	x24, [sp, #0x98]
   131ac:      	ldr	x21, [sp, #0x48]
   131b0:      	add	x2, x24, #0x20
   131b4:      	stp	x2, x24, [sp, #0x50]
   131b8:      	ldr	x8, [sp, #0x30]
   131bc:      	ldr	x25, [sp, #0x8]
   131c0:      	add	x9, sp, #0x70
   131c4:      	cmp	x21, x8
   131c8:      	b.ne	0x131d8 <generic_kprobe_path+0x83a8>
   131cc:      	ldr	x8, [sp, #0x38]
   131d0:      	cmp	x2, x8
   131d4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   131d8:      	mov	w8, #0x4                // =4
   131dc:      	add	x0, sp, #0x70
   131e0:      	mov	w1, #0x8                // =8
   131e4:      	blr	x8
   131e8:      	ldr	x8, [sp, #0x70]
   131ec:      	cmp	x21, x8
   131f0:      	b.eq	0x132e4 <generic_kprobe_path+0x84b4>
   131f4:      	add	x23, x21, #0x18
   131f8:      	mov	w8, #0x4                // =4
   131fc:      	add	x9, sp, #0x98
   13200:      	add	x0, sp, #0x98
   13204:      	mov	w1, #0x8                // =8
   13208:      	mov	x2, x23
   1320c:      	blr	x8
   13210:      	ldr	x8, [sp, #0x98]
   13214:      	cmp	x8, x21
   13218:      	b.eq	0x132e4 <generic_kprobe_path+0x84b4>
   1321c:      	mov	w8, #0x4                // =4
   13220:      	add	x9, sp, #0x78
   13224:      	add	x0, sp, #0x78
   13228:      	mov	w1, #0x8                // =8
   1322c:      	mov	x2, x23
   13230:      	blr	x8
   13234:      	add	x2, x21, #0x20
   13238:      	mov	w8, #0x4                // =4
   1323c:      	mov	w9, #0x10               // =16
   13240:      	add	x10, sp, #0x80
   13244:      	add	x0, sp, #0x80
   13248:      	mov	w1, #0x10               // =16
   1324c:      	blr	x8
   13250:      	ldr	w21, [sp, #0x84]
   13254:      	ldr	x8, [sp, #0x40]
   13258:      	ldr	x10, [sp, #0x60]
   1325c:      	sub	x12, x10, x8
   13260:      	ldr	w23, [sp, #0x68]
   13264:      	subs	w10, w21, w23
   13268:      	ldr	x9, [sp, #0x88]
   1326c:      	ldr	x25, [sp, #0x8]
   13270:      	csel	w10, wzr, w10, lo
   13274:      	cmp	w23, w21
   13278:      	csel	w11, w23, w21, lo
   1327c:      	cinc	w13, w11, hi
   13280:      	sub	w14, w23, w13
   13284:      	subs	x12, x12, x13
   13288:      	str	w14, [sp, #0x68]
   1328c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   13290:      	cmp	x12, #0xfff
   13294:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   13298:      	cmp	w23, w21
   1329c:      	b.ls	0x132a8 <generic_kprobe_path+0x8478>
   132a0:      	mov	w13, #0x2f              // =47
   132a4:      	strb	w13, [x8, x12]
   132a8:      	add	x19, x8, x12
   132ac:      	cmp	w23, w21
   132b0:      	add	x2, x9, x10
   132b4:      	and	w1, w11, #0xff
   132b8:      	mov	w8, #0x4                // =4
   132bc:      	cinc	x0, x19, hi
   132c0:      	blr	x8
   132c4:      	ldr	x25, [sp, #0x8]
   132c8:      	cmp	w23, w21
   132cc:      	str	x19, [sp, #0x60]
   132d0:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   132d4:      	ldr	x21, [sp, #0x78]
   132d8:      	ldp	x2, x24, [sp, #0x50]
   132dc:      	str	x21, [sp, #0x48]
   132e0:      	b	0x13334 <generic_kprobe_path+0x8504>
   132e4:      	add	x2, x24, #0x10
   132e8:      	mov	w8, #0x4                // =4
   132ec:      	add	x9, sp, #0x98
   132f0:      	add	x0, sp, #0x98
   132f4:      	mov	w1, #0x8                // =8
   132f8:      	blr	x8
   132fc:      	ldr	x8, [sp, #0x58]
   13300:      	ldr	x9, [sp, #0x98]
   13304:      	cmp	x8, x9
   13308:      	ldr	x25, [sp, #0x8]
   1330c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   13310:      	add	x2, x24, #0x18
   13314:      	mov	w8, #0x4                // =4
   13318:      	mov	x0, x22
   1331c:      	mov	w1, #0x8                // =8
   13320:      	blr	x8
   13324:      	ldr	x24, [sp, #0x98]
   13328:      	ldr	x21, [sp, #0x48]
   1332c:      	add	x2, x24, #0x20
   13330:      	stp	x2, x24, [sp, #0x50]
   13334:      	ldr	x8, [sp, #0x30]
   13338:      	ldr	x25, [sp, #0x8]
   1333c:      	add	x9, sp, #0x70
   13340:      	cmp	x21, x8
   13344:      	b.ne	0x13354 <generic_kprobe_path+0x8524>
   13348:      	ldr	x8, [sp, #0x38]
   1334c:      	cmp	x2, x8
   13350:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   13354:      	mov	w8, #0x4                // =4
   13358:      	add	x0, sp, #0x70
   1335c:      	mov	w1, #0x8                // =8
   13360:      	blr	x8
   13364:      	ldr	x8, [sp, #0x70]
   13368:      	cmp	x21, x8
   1336c:      	b.eq	0x13460 <generic_kprobe_path+0x8630>
   13370:      	add	x23, x21, #0x18
   13374:      	mov	w8, #0x4                // =4
   13378:      	add	x9, sp, #0x98
   1337c:      	add	x0, sp, #0x98
   13380:      	mov	w1, #0x8                // =8
   13384:      	mov	x2, x23
   13388:      	blr	x8
   1338c:      	ldr	x8, [sp, #0x98]
   13390:      	cmp	x8, x21
   13394:      	b.eq	0x13460 <generic_kprobe_path+0x8630>
   13398:      	mov	w8, #0x4                // =4
   1339c:      	add	x9, sp, #0x78
   133a0:      	add	x0, sp, #0x78
   133a4:      	mov	w1, #0x8                // =8
   133a8:      	mov	x2, x23
   133ac:      	blr	x8
   133b0:      	add	x2, x21, #0x20
   133b4:      	mov	w8, #0x4                // =4
   133b8:      	mov	w9, #0x10               // =16
   133bc:      	add	x10, sp, #0x80
   133c0:      	add	x0, sp, #0x80
   133c4:      	mov	w1, #0x10               // =16
   133c8:      	blr	x8
   133cc:      	ldr	w21, [sp, #0x84]
   133d0:      	ldr	x8, [sp, #0x40]
   133d4:      	ldr	x10, [sp, #0x60]
   133d8:      	sub	x12, x10, x8
   133dc:      	ldr	w23, [sp, #0x68]
   133e0:      	subs	w10, w21, w23
   133e4:      	ldr	x9, [sp, #0x88]
   133e8:      	ldr	x25, [sp, #0x8]
   133ec:      	csel	w10, wzr, w10, lo
   133f0:      	cmp	w23, w21
   133f4:      	csel	w11, w23, w21, lo
   133f8:      	cinc	w13, w11, hi
   133fc:      	sub	w14, w23, w13
   13400:      	subs	x12, x12, x13
   13404:      	str	w14, [sp, #0x68]
   13408:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   1340c:      	cmp	x12, #0xfff
   13410:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   13414:      	cmp	w23, w21
   13418:      	b.ls	0x13424 <generic_kprobe_path+0x85f4>
   1341c:      	mov	w13, #0x2f              // =47
   13420:      	strb	w13, [x8, x12]
   13424:      	add	x19, x8, x12
   13428:      	cmp	w23, w21
   1342c:      	add	x2, x9, x10
   13430:      	and	w1, w11, #0xff
   13434:      	mov	w8, #0x4                // =4
   13438:      	cinc	x0, x19, hi
   1343c:      	blr	x8
   13440:      	ldr	x25, [sp, #0x8]
   13444:      	cmp	w23, w21
   13448:      	str	x19, [sp, #0x60]
   1344c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   13450:      	ldr	x21, [sp, #0x78]
   13454:      	ldp	x2, x24, [sp, #0x50]
   13458:      	str	x21, [sp, #0x48]
   1345c:      	b	0x134b0 <generic_kprobe_path+0x8680>
   13460:      	add	x2, x24, #0x10
   13464:      	mov	w8, #0x4                // =4
   13468:      	add	x9, sp, #0x98
   1346c:      	add	x0, sp, #0x98
   13470:      	mov	w1, #0x8                // =8
   13474:      	blr	x8
   13478:      	ldr	x8, [sp, #0x58]
   1347c:      	ldr	x9, [sp, #0x98]
   13480:      	cmp	x8, x9
   13484:      	ldr	x25, [sp, #0x8]
   13488:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1348c:      	add	x2, x24, #0x18
   13490:      	mov	w8, #0x4                // =4
   13494:      	mov	x0, x22
   13498:      	mov	w1, #0x8                // =8
   1349c:      	blr	x8
   134a0:      	ldr	x24, [sp, #0x98]
   134a4:      	ldr	x21, [sp, #0x48]
   134a8:      	add	x2, x24, #0x20
   134ac:      	stp	x2, x24, [sp, #0x50]
   134b0:      	ldr	x8, [sp, #0x30]
   134b4:      	ldr	x25, [sp, #0x8]
   134b8:      	add	x9, sp, #0x70
   134bc:      	cmp	x21, x8
   134c0:      	b.ne	0x134d0 <generic_kprobe_path+0x86a0>
   134c4:      	ldr	x8, [sp, #0x38]
   134c8:      	cmp	x2, x8
   134cc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   134d0:      	mov	w8, #0x4                // =4
   134d4:      	add	x0, sp, #0x70
   134d8:      	mov	w1, #0x8                // =8
   134dc:      	blr	x8
   134e0:      	ldr	x8, [sp, #0x70]
   134e4:      	cmp	x21, x8
   134e8:      	b.eq	0x135dc <generic_kprobe_path+0x87ac>
   134ec:      	add	x23, x21, #0x18
   134f0:      	mov	w8, #0x4                // =4
   134f4:      	add	x9, sp, #0x98
   134f8:      	add	x0, sp, #0x98
   134fc:      	mov	w1, #0x8                // =8
   13500:      	mov	x2, x23
   13504:      	blr	x8
   13508:      	ldr	x8, [sp, #0x98]
   1350c:      	cmp	x8, x21
   13510:      	b.eq	0x135dc <generic_kprobe_path+0x87ac>
   13514:      	mov	w8, #0x4                // =4
   13518:      	add	x9, sp, #0x78
   1351c:      	add	x0, sp, #0x78
   13520:      	mov	w1, #0x8                // =8
   13524:      	mov	x2, x23
   13528:      	blr	x8
   1352c:      	add	x2, x21, #0x20
   13530:      	mov	w8, #0x4                // =4
   13534:      	mov	w9, #0x10               // =16
   13538:      	add	x10, sp, #0x80
   1353c:      	add	x0, sp, #0x80
   13540:      	mov	w1, #0x10               // =16
   13544:      	blr	x8
   13548:      	ldr	w21, [sp, #0x84]
   1354c:      	ldr	x8, [sp, #0x40]
   13550:      	ldr	x10, [sp, #0x60]
   13554:      	sub	x12, x10, x8
   13558:      	ldr	w23, [sp, #0x68]
   1355c:      	subs	w10, w21, w23
   13560:      	ldr	x9, [sp, #0x88]
   13564:      	ldr	x25, [sp, #0x8]
   13568:      	csel	w10, wzr, w10, lo
   1356c:      	cmp	w23, w21
   13570:      	csel	w11, w23, w21, lo
   13574:      	cinc	w13, w11, hi
   13578:      	sub	w14, w23, w13
   1357c:      	subs	x12, x12, x13
   13580:      	str	w14, [sp, #0x68]
   13584:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   13588:      	cmp	x12, #0xfff
   1358c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   13590:      	cmp	w23, w21
   13594:      	b.ls	0x135a0 <generic_kprobe_path+0x8770>
   13598:      	mov	w13, #0x2f              // =47
   1359c:      	strb	w13, [x8, x12]
   135a0:      	add	x19, x8, x12
   135a4:      	cmp	w23, w21
   135a8:      	add	x2, x9, x10
   135ac:      	and	w1, w11, #0xff
   135b0:      	mov	w8, #0x4                // =4
   135b4:      	cinc	x0, x19, hi
   135b8:      	blr	x8
   135bc:      	ldr	x25, [sp, #0x8]
   135c0:      	cmp	w23, w21
   135c4:      	str	x19, [sp, #0x60]
   135c8:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   135cc:      	ldr	x21, [sp, #0x78]
   135d0:      	ldp	x2, x24, [sp, #0x50]
   135d4:      	str	x21, [sp, #0x48]
   135d8:      	b	0x1362c <generic_kprobe_path+0x87fc>
   135dc:      	add	x2, x24, #0x10
   135e0:      	mov	w8, #0x4                // =4
   135e4:      	add	x9, sp, #0x98
   135e8:      	add	x0, sp, #0x98
   135ec:      	mov	w1, #0x8                // =8
   135f0:      	blr	x8
   135f4:      	ldr	x8, [sp, #0x58]
   135f8:      	ldr	x9, [sp, #0x98]
   135fc:      	cmp	x8, x9
   13600:      	ldr	x25, [sp, #0x8]
   13604:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   13608:      	add	x2, x24, #0x18
   1360c:      	mov	w8, #0x4                // =4
   13610:      	mov	x0, x22
   13614:      	mov	w1, #0x8                // =8
   13618:      	blr	x8
   1361c:      	ldr	x24, [sp, #0x98]
   13620:      	ldr	x21, [sp, #0x48]
   13624:      	add	x2, x24, #0x20
   13628:      	stp	x2, x24, [sp, #0x50]
   1362c:      	ldr	x8, [sp, #0x30]
   13630:      	ldr	x25, [sp, #0x8]
   13634:      	add	x9, sp, #0x70
   13638:      	cmp	x21, x8
   1363c:      	b.ne	0x1364c <generic_kprobe_path+0x881c>
   13640:      	ldr	x8, [sp, #0x38]
   13644:      	cmp	x2, x8
   13648:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1364c:      	mov	w8, #0x4                // =4
   13650:      	add	x0, sp, #0x70
   13654:      	mov	w1, #0x8                // =8
   13658:      	blr	x8
   1365c:      	ldr	x8, [sp, #0x70]
   13660:      	cmp	x21, x8
   13664:      	b.eq	0x13758 <generic_kprobe_path+0x8928>
   13668:      	add	x23, x21, #0x18
   1366c:      	mov	w8, #0x4                // =4
   13670:      	add	x9, sp, #0x98
   13674:      	add	x0, sp, #0x98
   13678:      	mov	w1, #0x8                // =8
   1367c:      	mov	x2, x23
   13680:      	blr	x8
   13684:      	ldr	x8, [sp, #0x98]
   13688:      	cmp	x8, x21
   1368c:      	b.eq	0x13758 <generic_kprobe_path+0x8928>
   13690:      	mov	w8, #0x4                // =4
   13694:      	add	x9, sp, #0x78
   13698:      	add	x0, sp, #0x78
   1369c:      	mov	w1, #0x8                // =8
   136a0:      	mov	x2, x23
   136a4:      	blr	x8
   136a8:      	add	x2, x21, #0x20
   136ac:      	mov	w8, #0x4                // =4
   136b0:      	mov	w9, #0x10               // =16
   136b4:      	add	x10, sp, #0x80
   136b8:      	add	x0, sp, #0x80
   136bc:      	mov	w1, #0x10               // =16
   136c0:      	blr	x8
   136c4:      	ldr	w21, [sp, #0x84]
   136c8:      	ldr	x8, [sp, #0x40]
   136cc:      	ldr	x10, [sp, #0x60]
   136d0:      	sub	x12, x10, x8
   136d4:      	ldr	w23, [sp, #0x68]
   136d8:      	subs	w10, w21, w23
   136dc:      	ldr	x9, [sp, #0x88]
   136e0:      	ldr	x25, [sp, #0x8]
   136e4:      	csel	w10, wzr, w10, lo
   136e8:      	cmp	w23, w21
   136ec:      	csel	w11, w23, w21, lo
   136f0:      	cinc	w13, w11, hi
   136f4:      	sub	w14, w23, w13
   136f8:      	subs	x12, x12, x13
   136fc:      	str	w14, [sp, #0x68]
   13700:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   13704:      	cmp	x12, #0xfff
   13708:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   1370c:      	cmp	w23, w21
   13710:      	b.ls	0x1371c <generic_kprobe_path+0x88ec>
   13714:      	mov	w13, #0x2f              // =47
   13718:      	strb	w13, [x8, x12]
   1371c:      	add	x19, x8, x12
   13720:      	cmp	w23, w21
   13724:      	add	x2, x9, x10
   13728:      	and	w1, w11, #0xff
   1372c:      	mov	w8, #0x4                // =4
   13730:      	cinc	x0, x19, hi
   13734:      	blr	x8
   13738:      	ldr	x25, [sp, #0x8]
   1373c:      	cmp	w23, w21
   13740:      	str	x19, [sp, #0x60]
   13744:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   13748:      	ldr	x21, [sp, #0x78]
   1374c:      	ldp	x2, x24, [sp, #0x50]
   13750:      	str	x21, [sp, #0x48]
   13754:      	b	0x137a8 <generic_kprobe_path+0x8978>
   13758:      	add	x2, x24, #0x10
   1375c:      	mov	w8, #0x4                // =4
   13760:      	add	x9, sp, #0x98
   13764:      	add	x0, sp, #0x98
   13768:      	mov	w1, #0x8                // =8
   1376c:      	blr	x8
   13770:      	ldr	x8, [sp, #0x58]
   13774:      	ldr	x9, [sp, #0x98]
   13778:      	cmp	x8, x9
   1377c:      	ldr	x25, [sp, #0x8]
   13780:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   13784:      	add	x2, x24, #0x18
   13788:      	mov	w8, #0x4                // =4
   1378c:      	mov	x0, x22
   13790:      	mov	w1, #0x8                // =8
   13794:      	blr	x8
   13798:      	ldr	x24, [sp, #0x98]
   1379c:      	ldr	x21, [sp, #0x48]
   137a0:      	add	x2, x24, #0x20
   137a4:      	stp	x2, x24, [sp, #0x50]
   137a8:      	ldr	x8, [sp, #0x30]
   137ac:      	ldr	x25, [sp, #0x8]
   137b0:      	add	x9, sp, #0x70
   137b4:      	cmp	x21, x8
   137b8:      	b.ne	0x137c8 <generic_kprobe_path+0x8998>
   137bc:      	ldr	x8, [sp, #0x38]
   137c0:      	cmp	x2, x8
   137c4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   137c8:      	mov	w8, #0x4                // =4
   137cc:      	add	x0, sp, #0x70
   137d0:      	mov	w1, #0x8                // =8
   137d4:      	blr	x8
   137d8:      	ldr	x8, [sp, #0x70]
   137dc:      	cmp	x21, x8
   137e0:      	b.eq	0x138d4 <generic_kprobe_path+0x8aa4>
   137e4:      	add	x23, x21, #0x18
   137e8:      	mov	w8, #0x4                // =4
   137ec:      	add	x9, sp, #0x98
   137f0:      	add	x0, sp, #0x98
   137f4:      	mov	w1, #0x8                // =8
   137f8:      	mov	x2, x23
   137fc:      	blr	x8
   13800:      	ldr	x8, [sp, #0x98]
   13804:      	cmp	x8, x21
   13808:      	b.eq	0x138d4 <generic_kprobe_path+0x8aa4>
   1380c:      	mov	w8, #0x4                // =4
   13810:      	add	x9, sp, #0x78
   13814:      	add	x0, sp, #0x78
   13818:      	mov	w1, #0x8                // =8
   1381c:      	mov	x2, x23
   13820:      	blr	x8
   13824:      	add	x2, x21, #0x20
   13828:      	mov	w8, #0x4                // =4
   1382c:      	mov	w9, #0x10               // =16
   13830:      	add	x10, sp, #0x80
   13834:      	add	x0, sp, #0x80
   13838:      	mov	w1, #0x10               // =16
   1383c:      	blr	x8
   13840:      	ldr	w21, [sp, #0x84]
   13844:      	ldr	x8, [sp, #0x40]
   13848:      	ldr	x10, [sp, #0x60]
   1384c:      	sub	x12, x10, x8
   13850:      	ldr	w23, [sp, #0x68]
   13854:      	subs	w10, w21, w23
   13858:      	ldr	x9, [sp, #0x88]
   1385c:      	ldr	x25, [sp, #0x8]
   13860:      	csel	w10, wzr, w10, lo
   13864:      	cmp	w23, w21
   13868:      	csel	w11, w23, w21, lo
   1386c:      	cinc	w13, w11, hi
   13870:      	sub	w14, w23, w13
   13874:      	subs	x12, x12, x13
   13878:      	str	w14, [sp, #0x68]
   1387c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   13880:      	cmp	x12, #0xfff
   13884:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   13888:      	cmp	w23, w21
   1388c:      	b.ls	0x13898 <generic_kprobe_path+0x8a68>
   13890:      	mov	w13, #0x2f              // =47
   13894:      	strb	w13, [x8, x12]
   13898:      	add	x19, x8, x12
   1389c:      	cmp	w23, w21
   138a0:      	add	x2, x9, x10
   138a4:      	and	w1, w11, #0xff
   138a8:      	mov	w8, #0x4                // =4
   138ac:      	cinc	x0, x19, hi
   138b0:      	blr	x8
   138b4:      	ldr	x25, [sp, #0x8]
   138b8:      	cmp	w23, w21
   138bc:      	str	x19, [sp, #0x60]
   138c0:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   138c4:      	ldr	x21, [sp, #0x78]
   138c8:      	ldp	x2, x24, [sp, #0x50]
   138cc:      	str	x21, [sp, #0x48]
   138d0:      	b	0x13924 <generic_kprobe_path+0x8af4>
   138d4:      	add	x2, x24, #0x10
   138d8:      	mov	w8, #0x4                // =4
   138dc:      	add	x9, sp, #0x98
   138e0:      	add	x0, sp, #0x98
   138e4:      	mov	w1, #0x8                // =8
   138e8:      	blr	x8
   138ec:      	ldr	x8, [sp, #0x58]
   138f0:      	ldr	x9, [sp, #0x98]
   138f4:      	cmp	x8, x9
   138f8:      	ldr	x25, [sp, #0x8]
   138fc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   13900:      	add	x2, x24, #0x18
   13904:      	mov	w8, #0x4                // =4
   13908:      	mov	x0, x22
   1390c:      	mov	w1, #0x8                // =8
   13910:      	blr	x8
   13914:      	ldr	x24, [sp, #0x98]
   13918:      	ldr	x21, [sp, #0x48]
   1391c:      	add	x2, x24, #0x20
   13920:      	stp	x2, x24, [sp, #0x50]
   13924:      	ldr	x8, [sp, #0x30]
   13928:      	ldr	x25, [sp, #0x8]
   1392c:      	add	x9, sp, #0x70
   13930:      	cmp	x21, x8
   13934:      	b.ne	0x13944 <generic_kprobe_path+0x8b14>
   13938:      	ldr	x8, [sp, #0x38]
   1393c:      	cmp	x2, x8
   13940:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   13944:      	mov	w8, #0x4                // =4
   13948:      	add	x0, sp, #0x70
   1394c:      	mov	w1, #0x8                // =8
   13950:      	blr	x8
   13954:      	ldr	x8, [sp, #0x70]
   13958:      	cmp	x21, x8
   1395c:      	b.eq	0x13a50 <generic_kprobe_path+0x8c20>
   13960:      	add	x23, x21, #0x18
   13964:      	mov	w8, #0x4                // =4
   13968:      	add	x9, sp, #0x98
   1396c:      	add	x0, sp, #0x98
   13970:      	mov	w1, #0x8                // =8
   13974:      	mov	x2, x23
   13978:      	blr	x8
   1397c:      	ldr	x8, [sp, #0x98]
   13980:      	cmp	x8, x21
   13984:      	b.eq	0x13a50 <generic_kprobe_path+0x8c20>
   13988:      	mov	w8, #0x4                // =4
   1398c:      	add	x9, sp, #0x78
   13990:      	add	x0, sp, #0x78
   13994:      	mov	w1, #0x8                // =8
   13998:      	mov	x2, x23
   1399c:      	blr	x8
   139a0:      	add	x2, x21, #0x20
   139a4:      	mov	w8, #0x4                // =4
   139a8:      	mov	w9, #0x10               // =16
   139ac:      	add	x10, sp, #0x80
   139b0:      	add	x0, sp, #0x80
   139b4:      	mov	w1, #0x10               // =16
   139b8:      	blr	x8
   139bc:      	ldr	w21, [sp, #0x84]
   139c0:      	ldr	x8, [sp, #0x40]
   139c4:      	ldr	x10, [sp, #0x60]
   139c8:      	sub	x12, x10, x8
   139cc:      	ldr	w23, [sp, #0x68]
   139d0:      	subs	w10, w21, w23
   139d4:      	ldr	x9, [sp, #0x88]
   139d8:      	ldr	x25, [sp, #0x8]
   139dc:      	csel	w10, wzr, w10, lo
   139e0:      	cmp	w23, w21
   139e4:      	csel	w11, w23, w21, lo
   139e8:      	cinc	w13, w11, hi
   139ec:      	sub	w14, w23, w13
   139f0:      	subs	x12, x12, x13
   139f4:      	str	w14, [sp, #0x68]
   139f8:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   139fc:      	cmp	x12, #0xfff
   13a00:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   13a04:      	cmp	w23, w21
   13a08:      	b.ls	0x13a14 <generic_kprobe_path+0x8be4>
   13a0c:      	mov	w13, #0x2f              // =47
   13a10:      	strb	w13, [x8, x12]
   13a14:      	add	x19, x8, x12
   13a18:      	cmp	w23, w21
   13a1c:      	add	x2, x9, x10
   13a20:      	and	w1, w11, #0xff
   13a24:      	mov	w8, #0x4                // =4
   13a28:      	cinc	x0, x19, hi
   13a2c:      	blr	x8
   13a30:      	ldr	x25, [sp, #0x8]
   13a34:      	cmp	w23, w21
   13a38:      	str	x19, [sp, #0x60]
   13a3c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   13a40:      	ldr	x21, [sp, #0x78]
   13a44:      	ldp	x2, x24, [sp, #0x50]
   13a48:      	str	x21, [sp, #0x48]
   13a4c:      	b	0x13aa0 <generic_kprobe_path+0x8c70>
   13a50:      	add	x2, x24, #0x10
   13a54:      	mov	w8, #0x4                // =4
   13a58:      	add	x9, sp, #0x98
   13a5c:      	add	x0, sp, #0x98
   13a60:      	mov	w1, #0x8                // =8
   13a64:      	blr	x8
   13a68:      	ldr	x8, [sp, #0x58]
   13a6c:      	ldr	x9, [sp, #0x98]
   13a70:      	cmp	x8, x9
   13a74:      	ldr	x25, [sp, #0x8]
   13a78:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   13a7c:      	add	x2, x24, #0x18
   13a80:      	mov	w8, #0x4                // =4
   13a84:      	mov	x0, x22
   13a88:      	mov	w1, #0x8                // =8
   13a8c:      	blr	x8
   13a90:      	ldr	x24, [sp, #0x98]
   13a94:      	ldr	x21, [sp, #0x48]
   13a98:      	add	x2, x24, #0x20
   13a9c:      	stp	x2, x24, [sp, #0x50]
   13aa0:      	ldr	x8, [sp, #0x30]
   13aa4:      	ldr	x25, [sp, #0x8]
   13aa8:      	add	x9, sp, #0x70
   13aac:      	cmp	x21, x8
   13ab0:      	b.ne	0x13ac0 <generic_kprobe_path+0x8c90>
   13ab4:      	ldr	x8, [sp, #0x38]
   13ab8:      	cmp	x2, x8
   13abc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   13ac0:      	mov	w8, #0x4                // =4
   13ac4:      	add	x0, sp, #0x70
   13ac8:      	mov	w1, #0x8                // =8
   13acc:      	blr	x8
   13ad0:      	ldr	x8, [sp, #0x70]
   13ad4:      	cmp	x21, x8
   13ad8:      	b.eq	0x13bcc <generic_kprobe_path+0x8d9c>
   13adc:      	add	x23, x21, #0x18
   13ae0:      	mov	w8, #0x4                // =4
   13ae4:      	add	x9, sp, #0x98
   13ae8:      	add	x0, sp, #0x98
   13aec:      	mov	w1, #0x8                // =8
   13af0:      	mov	x2, x23
   13af4:      	blr	x8
   13af8:      	ldr	x8, [sp, #0x98]
   13afc:      	cmp	x8, x21
   13b00:      	b.eq	0x13bcc <generic_kprobe_path+0x8d9c>
   13b04:      	mov	w8, #0x4                // =4
   13b08:      	add	x9, sp, #0x78
   13b0c:      	add	x0, sp, #0x78
   13b10:      	mov	w1, #0x8                // =8
   13b14:      	mov	x2, x23
   13b18:      	blr	x8
   13b1c:      	add	x2, x21, #0x20
   13b20:      	mov	w8, #0x4                // =4
   13b24:      	mov	w9, #0x10               // =16
   13b28:      	add	x10, sp, #0x80
   13b2c:      	add	x0, sp, #0x80
   13b30:      	mov	w1, #0x10               // =16
   13b34:      	blr	x8
   13b38:      	ldr	w21, [sp, #0x84]
   13b3c:      	ldr	x8, [sp, #0x40]
   13b40:      	ldr	x10, [sp, #0x60]
   13b44:      	sub	x12, x10, x8
   13b48:      	ldr	w23, [sp, #0x68]
   13b4c:      	subs	w10, w21, w23
   13b50:      	ldr	x9, [sp, #0x88]
   13b54:      	ldr	x25, [sp, #0x8]
   13b58:      	csel	w10, wzr, w10, lo
   13b5c:      	cmp	w23, w21
   13b60:      	csel	w11, w23, w21, lo
   13b64:      	cinc	w13, w11, hi
   13b68:      	sub	w14, w23, w13
   13b6c:      	subs	x12, x12, x13
   13b70:      	str	w14, [sp, #0x68]
   13b74:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   13b78:      	cmp	x12, #0xfff
   13b7c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   13b80:      	cmp	w23, w21
   13b84:      	b.ls	0x13b90 <generic_kprobe_path+0x8d60>
   13b88:      	mov	w13, #0x2f              // =47
   13b8c:      	strb	w13, [x8, x12]
   13b90:      	add	x19, x8, x12
   13b94:      	cmp	w23, w21
   13b98:      	add	x2, x9, x10
   13b9c:      	and	w1, w11, #0xff
   13ba0:      	mov	w8, #0x4                // =4
   13ba4:      	cinc	x0, x19, hi
   13ba8:      	blr	x8
   13bac:      	ldr	x25, [sp, #0x8]
   13bb0:      	cmp	w23, w21
   13bb4:      	str	x19, [sp, #0x60]
   13bb8:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   13bbc:      	ldr	x21, [sp, #0x78]
   13bc0:      	ldp	x2, x24, [sp, #0x50]
   13bc4:      	str	x21, [sp, #0x48]
   13bc8:      	b	0x13c1c <generic_kprobe_path+0x8dec>
   13bcc:      	add	x2, x24, #0x10
   13bd0:      	mov	w8, #0x4                // =4
   13bd4:      	add	x9, sp, #0x98
   13bd8:      	add	x0, sp, #0x98
   13bdc:      	mov	w1, #0x8                // =8
   13be0:      	blr	x8
   13be4:      	ldr	x8, [sp, #0x58]
   13be8:      	ldr	x9, [sp, #0x98]
   13bec:      	cmp	x8, x9
   13bf0:      	ldr	x25, [sp, #0x8]
   13bf4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   13bf8:      	add	x2, x24, #0x18
   13bfc:      	mov	w8, #0x4                // =4
   13c00:      	mov	x0, x22
   13c04:      	mov	w1, #0x8                // =8
   13c08:      	blr	x8
   13c0c:      	ldr	x24, [sp, #0x98]
   13c10:      	ldr	x21, [sp, #0x48]
   13c14:      	add	x2, x24, #0x20
   13c18:      	stp	x2, x24, [sp, #0x50]
   13c1c:      	ldr	x8, [sp, #0x30]
   13c20:      	ldr	x25, [sp, #0x8]
   13c24:      	add	x9, sp, #0x70
   13c28:      	cmp	x21, x8
   13c2c:      	b.ne	0x13c3c <generic_kprobe_path+0x8e0c>
   13c30:      	ldr	x8, [sp, #0x38]
   13c34:      	cmp	x2, x8
   13c38:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   13c3c:      	mov	w8, #0x4                // =4
   13c40:      	add	x0, sp, #0x70
   13c44:      	mov	w1, #0x8                // =8
   13c48:      	blr	x8
   13c4c:      	ldr	x8, [sp, #0x70]
   13c50:      	cmp	x21, x8
   13c54:      	b.eq	0x13d48 <generic_kprobe_path+0x8f18>
   13c58:      	add	x23, x21, #0x18
   13c5c:      	mov	w8, #0x4                // =4
   13c60:      	add	x9, sp, #0x98
   13c64:      	add	x0, sp, #0x98
   13c68:      	mov	w1, #0x8                // =8
   13c6c:      	mov	x2, x23
   13c70:      	blr	x8
   13c74:      	ldr	x8, [sp, #0x98]
   13c78:      	cmp	x8, x21
   13c7c:      	b.eq	0x13d48 <generic_kprobe_path+0x8f18>
   13c80:      	mov	w8, #0x4                // =4
   13c84:      	add	x9, sp, #0x78
   13c88:      	add	x0, sp, #0x78
   13c8c:      	mov	w1, #0x8                // =8
   13c90:      	mov	x2, x23
   13c94:      	blr	x8
   13c98:      	add	x2, x21, #0x20
   13c9c:      	mov	w8, #0x4                // =4
   13ca0:      	mov	w9, #0x10               // =16
   13ca4:      	add	x10, sp, #0x80
   13ca8:      	add	x0, sp, #0x80
   13cac:      	mov	w1, #0x10               // =16
   13cb0:      	blr	x8
   13cb4:      	ldr	w21, [sp, #0x84]
   13cb8:      	ldr	x8, [sp, #0x40]
   13cbc:      	ldr	x10, [sp, #0x60]
   13cc0:      	sub	x12, x10, x8
   13cc4:      	ldr	w23, [sp, #0x68]
   13cc8:      	subs	w10, w21, w23
   13ccc:      	ldr	x9, [sp, #0x88]
   13cd0:      	ldr	x25, [sp, #0x8]
   13cd4:      	csel	w10, wzr, w10, lo
   13cd8:      	cmp	w23, w21
   13cdc:      	csel	w11, w23, w21, lo
   13ce0:      	cinc	w13, w11, hi
   13ce4:      	sub	w14, w23, w13
   13ce8:      	subs	x12, x12, x13
   13cec:      	str	w14, [sp, #0x68]
   13cf0:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   13cf4:      	cmp	x12, #0xfff
   13cf8:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   13cfc:      	cmp	w23, w21
   13d00:      	b.ls	0x13d0c <generic_kprobe_path+0x8edc>
   13d04:      	mov	w13, #0x2f              // =47
   13d08:      	strb	w13, [x8, x12]
   13d0c:      	add	x19, x8, x12
   13d10:      	cmp	w23, w21
   13d14:      	add	x2, x9, x10
   13d18:      	and	w1, w11, #0xff
   13d1c:      	mov	w8, #0x4                // =4
   13d20:      	cinc	x0, x19, hi
   13d24:      	blr	x8
   13d28:      	ldr	x25, [sp, #0x8]
   13d2c:      	cmp	w23, w21
   13d30:      	str	x19, [sp, #0x60]
   13d34:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   13d38:      	ldr	x21, [sp, #0x78]
   13d3c:      	ldp	x2, x24, [sp, #0x50]
   13d40:      	str	x21, [sp, #0x48]
   13d44:      	b	0x13d98 <generic_kprobe_path+0x8f68>
   13d48:      	add	x2, x24, #0x10
   13d4c:      	mov	w8, #0x4                // =4
   13d50:      	add	x9, sp, #0x98
   13d54:      	add	x0, sp, #0x98
   13d58:      	mov	w1, #0x8                // =8
   13d5c:      	blr	x8
   13d60:      	ldr	x8, [sp, #0x58]
   13d64:      	ldr	x9, [sp, #0x98]
   13d68:      	cmp	x8, x9
   13d6c:      	ldr	x25, [sp, #0x8]
   13d70:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   13d74:      	add	x2, x24, #0x18
   13d78:      	mov	w8, #0x4                // =4
   13d7c:      	mov	x0, x22
   13d80:      	mov	w1, #0x8                // =8
   13d84:      	blr	x8
   13d88:      	ldr	x24, [sp, #0x98]
   13d8c:      	ldr	x21, [sp, #0x48]
   13d90:      	add	x2, x24, #0x20
   13d94:      	stp	x2, x24, [sp, #0x50]
   13d98:      	ldr	x8, [sp, #0x30]
   13d9c:      	ldr	x25, [sp, #0x8]
   13da0:      	add	x9, sp, #0x70
   13da4:      	cmp	x21, x8
   13da8:      	b.ne	0x13db8 <generic_kprobe_path+0x8f88>
   13dac:      	ldr	x8, [sp, #0x38]
   13db0:      	cmp	x2, x8
   13db4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   13db8:      	mov	w8, #0x4                // =4
   13dbc:      	add	x0, sp, #0x70
   13dc0:      	mov	w1, #0x8                // =8
   13dc4:      	blr	x8
   13dc8:      	ldr	x8, [sp, #0x70]
   13dcc:      	cmp	x21, x8
   13dd0:      	b.eq	0x13ec4 <generic_kprobe_path+0x9094>
   13dd4:      	add	x23, x21, #0x18
   13dd8:      	mov	w8, #0x4                // =4
   13ddc:      	add	x9, sp, #0x98
   13de0:      	add	x0, sp, #0x98
   13de4:      	mov	w1, #0x8                // =8
   13de8:      	mov	x2, x23
   13dec:      	blr	x8
   13df0:      	ldr	x8, [sp, #0x98]
   13df4:      	cmp	x8, x21
   13df8:      	b.eq	0x13ec4 <generic_kprobe_path+0x9094>
   13dfc:      	mov	w8, #0x4                // =4
   13e00:      	add	x9, sp, #0x78
   13e04:      	add	x0, sp, #0x78
   13e08:      	mov	w1, #0x8                // =8
   13e0c:      	mov	x2, x23
   13e10:      	blr	x8
   13e14:      	add	x2, x21, #0x20
   13e18:      	mov	w8, #0x4                // =4
   13e1c:      	mov	w9, #0x10               // =16
   13e20:      	add	x10, sp, #0x80
   13e24:      	add	x0, sp, #0x80
   13e28:      	mov	w1, #0x10               // =16
   13e2c:      	blr	x8
   13e30:      	ldr	w21, [sp, #0x84]
   13e34:      	ldr	x8, [sp, #0x40]
   13e38:      	ldr	x10, [sp, #0x60]
   13e3c:      	sub	x12, x10, x8
   13e40:      	ldr	w23, [sp, #0x68]
   13e44:      	subs	w10, w21, w23
   13e48:      	ldr	x9, [sp, #0x88]
   13e4c:      	ldr	x25, [sp, #0x8]
   13e50:      	csel	w10, wzr, w10, lo
   13e54:      	cmp	w23, w21
   13e58:      	csel	w11, w23, w21, lo
   13e5c:      	cinc	w13, w11, hi
   13e60:      	sub	w14, w23, w13
   13e64:      	subs	x12, x12, x13
   13e68:      	str	w14, [sp, #0x68]
   13e6c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   13e70:      	cmp	x12, #0xfff
   13e74:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   13e78:      	cmp	w23, w21
   13e7c:      	b.ls	0x13e88 <generic_kprobe_path+0x9058>
   13e80:      	mov	w13, #0x2f              // =47
   13e84:      	strb	w13, [x8, x12]
   13e88:      	add	x19, x8, x12
   13e8c:      	cmp	w23, w21
   13e90:      	add	x2, x9, x10
   13e94:      	and	w1, w11, #0xff
   13e98:      	mov	w8, #0x4                // =4
   13e9c:      	cinc	x0, x19, hi
   13ea0:      	blr	x8
   13ea4:      	ldr	x25, [sp, #0x8]
   13ea8:      	cmp	w23, w21
   13eac:      	str	x19, [sp, #0x60]
   13eb0:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   13eb4:      	ldr	x21, [sp, #0x78]
   13eb8:      	ldp	x2, x24, [sp, #0x50]
   13ebc:      	str	x21, [sp, #0x48]
   13ec0:      	b	0x13f14 <generic_kprobe_path+0x90e4>
   13ec4:      	add	x2, x24, #0x10
   13ec8:      	mov	w8, #0x4                // =4
   13ecc:      	add	x9, sp, #0x98
   13ed0:      	add	x0, sp, #0x98
   13ed4:      	mov	w1, #0x8                // =8
   13ed8:      	blr	x8
   13edc:      	ldr	x8, [sp, #0x58]
   13ee0:      	ldr	x9, [sp, #0x98]
   13ee4:      	cmp	x8, x9
   13ee8:      	ldr	x25, [sp, #0x8]
   13eec:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   13ef0:      	add	x2, x24, #0x18
   13ef4:      	mov	w8, #0x4                // =4
   13ef8:      	mov	x0, x22
   13efc:      	mov	w1, #0x8                // =8
   13f00:      	blr	x8
   13f04:      	ldr	x24, [sp, #0x98]
   13f08:      	ldr	x21, [sp, #0x48]
   13f0c:      	add	x2, x24, #0x20
   13f10:      	stp	x2, x24, [sp, #0x50]
   13f14:      	ldr	x8, [sp, #0x30]
   13f18:      	ldr	x25, [sp, #0x8]
   13f1c:      	add	x9, sp, #0x70
   13f20:      	cmp	x21, x8
   13f24:      	b.ne	0x13f34 <generic_kprobe_path+0x9104>
   13f28:      	ldr	x8, [sp, #0x38]
   13f2c:      	cmp	x2, x8
   13f30:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   13f34:      	mov	w8, #0x4                // =4
   13f38:      	add	x0, sp, #0x70
   13f3c:      	mov	w1, #0x8                // =8
   13f40:      	blr	x8
   13f44:      	ldr	x8, [sp, #0x70]
   13f48:      	cmp	x21, x8
   13f4c:      	b.eq	0x14040 <generic_kprobe_path+0x9210>
   13f50:      	add	x23, x21, #0x18
   13f54:      	mov	w8, #0x4                // =4
   13f58:      	add	x9, sp, #0x98
   13f5c:      	add	x0, sp, #0x98
   13f60:      	mov	w1, #0x8                // =8
   13f64:      	mov	x2, x23
   13f68:      	blr	x8
   13f6c:      	ldr	x8, [sp, #0x98]
   13f70:      	cmp	x8, x21
   13f74:      	b.eq	0x14040 <generic_kprobe_path+0x9210>
   13f78:      	mov	w8, #0x4                // =4
   13f7c:      	add	x9, sp, #0x78
   13f80:      	add	x0, sp, #0x78
   13f84:      	mov	w1, #0x8                // =8
   13f88:      	mov	x2, x23
   13f8c:      	blr	x8
   13f90:      	add	x2, x21, #0x20
   13f94:      	mov	w8, #0x4                // =4
   13f98:      	mov	w9, #0x10               // =16
   13f9c:      	add	x10, sp, #0x80
   13fa0:      	add	x0, sp, #0x80
   13fa4:      	mov	w1, #0x10               // =16
   13fa8:      	blr	x8
   13fac:      	ldr	w21, [sp, #0x84]
   13fb0:      	ldr	x8, [sp, #0x40]
   13fb4:      	ldr	x10, [sp, #0x60]
   13fb8:      	sub	x12, x10, x8
   13fbc:      	ldr	w23, [sp, #0x68]
   13fc0:      	subs	w10, w21, w23
   13fc4:      	ldr	x9, [sp, #0x88]
   13fc8:      	ldr	x25, [sp, #0x8]
   13fcc:      	csel	w10, wzr, w10, lo
   13fd0:      	cmp	w23, w21
   13fd4:      	csel	w11, w23, w21, lo
   13fd8:      	cinc	w13, w11, hi
   13fdc:      	sub	w14, w23, w13
   13fe0:      	subs	x12, x12, x13
   13fe4:      	str	w14, [sp, #0x68]
   13fe8:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   13fec:      	cmp	x12, #0xfff
   13ff0:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   13ff4:      	cmp	w23, w21
   13ff8:      	b.ls	0x14004 <generic_kprobe_path+0x91d4>
   13ffc:      	mov	w13, #0x2f              // =47
   14000:      	strb	w13, [x8, x12]
   14004:      	add	x19, x8, x12
   14008:      	cmp	w23, w21
   1400c:      	add	x2, x9, x10
   14010:      	and	w1, w11, #0xff
   14014:      	mov	w8, #0x4                // =4
   14018:      	cinc	x0, x19, hi
   1401c:      	blr	x8
   14020:      	ldr	x25, [sp, #0x8]
   14024:      	cmp	w23, w21
   14028:      	str	x19, [sp, #0x60]
   1402c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   14030:      	ldr	x21, [sp, #0x78]
   14034:      	ldp	x2, x24, [sp, #0x50]
   14038:      	str	x21, [sp, #0x48]
   1403c:      	b	0x14090 <generic_kprobe_path+0x9260>
   14040:      	add	x2, x24, #0x10
   14044:      	mov	w8, #0x4                // =4
   14048:      	add	x9, sp, #0x98
   1404c:      	add	x0, sp, #0x98
   14050:      	mov	w1, #0x8                // =8
   14054:      	blr	x8
   14058:      	ldr	x8, [sp, #0x58]
   1405c:      	ldr	x9, [sp, #0x98]
   14060:      	cmp	x8, x9
   14064:      	ldr	x25, [sp, #0x8]
   14068:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1406c:      	add	x2, x24, #0x18
   14070:      	mov	w8, #0x4                // =4
   14074:      	mov	x0, x22
   14078:      	mov	w1, #0x8                // =8
   1407c:      	blr	x8
   14080:      	ldr	x24, [sp, #0x98]
   14084:      	ldr	x21, [sp, #0x48]
   14088:      	add	x2, x24, #0x20
   1408c:      	stp	x2, x24, [sp, #0x50]
   14090:      	ldr	x8, [sp, #0x30]
   14094:      	ldr	x25, [sp, #0x8]
   14098:      	add	x9, sp, #0x70
   1409c:      	cmp	x21, x8
   140a0:      	b.ne	0x140b0 <generic_kprobe_path+0x9280>
   140a4:      	ldr	x8, [sp, #0x38]
   140a8:      	cmp	x2, x8
   140ac:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   140b0:      	mov	w8, #0x4                // =4
   140b4:      	add	x0, sp, #0x70
   140b8:      	mov	w1, #0x8                // =8
   140bc:      	blr	x8
   140c0:      	ldr	x8, [sp, #0x70]
   140c4:      	cmp	x21, x8
   140c8:      	b.eq	0x141bc <generic_kprobe_path+0x938c>
   140cc:      	add	x23, x21, #0x18
   140d0:      	mov	w8, #0x4                // =4
   140d4:      	add	x9, sp, #0x98
   140d8:      	add	x0, sp, #0x98
   140dc:      	mov	w1, #0x8                // =8
   140e0:      	mov	x2, x23
   140e4:      	blr	x8
   140e8:      	ldr	x8, [sp, #0x98]
   140ec:      	cmp	x8, x21
   140f0:      	b.eq	0x141bc <generic_kprobe_path+0x938c>
   140f4:      	mov	w8, #0x4                // =4
   140f8:      	add	x9, sp, #0x78
   140fc:      	add	x0, sp, #0x78
   14100:      	mov	w1, #0x8                // =8
   14104:      	mov	x2, x23
   14108:      	blr	x8
   1410c:      	add	x2, x21, #0x20
   14110:      	mov	w8, #0x4                // =4
   14114:      	mov	w9, #0x10               // =16
   14118:      	add	x10, sp, #0x80
   1411c:      	add	x0, sp, #0x80
   14120:      	mov	w1, #0x10               // =16
   14124:      	blr	x8
   14128:      	ldr	w21, [sp, #0x84]
   1412c:      	ldr	x8, [sp, #0x40]
   14130:      	ldr	x10, [sp, #0x60]
   14134:      	sub	x12, x10, x8
   14138:      	ldr	w23, [sp, #0x68]
   1413c:      	subs	w10, w21, w23
   14140:      	ldr	x9, [sp, #0x88]
   14144:      	ldr	x25, [sp, #0x8]
   14148:      	csel	w10, wzr, w10, lo
   1414c:      	cmp	w23, w21
   14150:      	csel	w11, w23, w21, lo
   14154:      	cinc	w13, w11, hi
   14158:      	sub	w14, w23, w13
   1415c:      	subs	x12, x12, x13
   14160:      	str	w14, [sp, #0x68]
   14164:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   14168:      	cmp	x12, #0xfff
   1416c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   14170:      	cmp	w23, w21
   14174:      	b.ls	0x14180 <generic_kprobe_path+0x9350>
   14178:      	mov	w13, #0x2f              // =47
   1417c:      	strb	w13, [x8, x12]
   14180:      	add	x19, x8, x12
   14184:      	cmp	w23, w21
   14188:      	add	x2, x9, x10
   1418c:      	and	w1, w11, #0xff
   14190:      	mov	w8, #0x4                // =4
   14194:      	cinc	x0, x19, hi
   14198:      	blr	x8
   1419c:      	ldr	x25, [sp, #0x8]
   141a0:      	cmp	w23, w21
   141a4:      	str	x19, [sp, #0x60]
   141a8:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   141ac:      	ldr	x21, [sp, #0x78]
   141b0:      	ldp	x2, x24, [sp, #0x50]
   141b4:      	str	x21, [sp, #0x48]
   141b8:      	b	0x1420c <generic_kprobe_path+0x93dc>
   141bc:      	add	x2, x24, #0x10
   141c0:      	mov	w8, #0x4                // =4
   141c4:      	add	x9, sp, #0x98
   141c8:      	add	x0, sp, #0x98
   141cc:      	mov	w1, #0x8                // =8
   141d0:      	blr	x8
   141d4:      	ldr	x8, [sp, #0x58]
   141d8:      	ldr	x9, [sp, #0x98]
   141dc:      	cmp	x8, x9
   141e0:      	ldr	x25, [sp, #0x8]
   141e4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   141e8:      	add	x2, x24, #0x18
   141ec:      	mov	w8, #0x4                // =4
   141f0:      	mov	x0, x22
   141f4:      	mov	w1, #0x8                // =8
   141f8:      	blr	x8
   141fc:      	ldr	x24, [sp, #0x98]
   14200:      	ldr	x21, [sp, #0x48]
   14204:      	add	x2, x24, #0x20
   14208:      	stp	x2, x24, [sp, #0x50]
   1420c:      	ldr	x8, [sp, #0x30]
   14210:      	ldr	x25, [sp, #0x8]
   14214:      	add	x9, sp, #0x70
   14218:      	cmp	x21, x8
   1421c:      	b.ne	0x1422c <generic_kprobe_path+0x93fc>
   14220:      	ldr	x8, [sp, #0x38]
   14224:      	cmp	x2, x8
   14228:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1422c:      	mov	w8, #0x4                // =4
   14230:      	add	x0, sp, #0x70
   14234:      	mov	w1, #0x8                // =8
   14238:      	blr	x8
   1423c:      	ldr	x8, [sp, #0x70]
   14240:      	cmp	x21, x8
   14244:      	b.eq	0x14338 <generic_kprobe_path+0x9508>
   14248:      	add	x23, x21, #0x18
   1424c:      	mov	w8, #0x4                // =4
   14250:      	add	x9, sp, #0x98
   14254:      	add	x0, sp, #0x98
   14258:      	mov	w1, #0x8                // =8
   1425c:      	mov	x2, x23
   14260:      	blr	x8
   14264:      	ldr	x8, [sp, #0x98]
   14268:      	cmp	x8, x21
   1426c:      	b.eq	0x14338 <generic_kprobe_path+0x9508>
   14270:      	mov	w8, #0x4                // =4
   14274:      	add	x9, sp, #0x78
   14278:      	add	x0, sp, #0x78
   1427c:      	mov	w1, #0x8                // =8
   14280:      	mov	x2, x23
   14284:      	blr	x8
   14288:      	add	x2, x21, #0x20
   1428c:      	mov	w8, #0x4                // =4
   14290:      	mov	w9, #0x10               // =16
   14294:      	add	x10, sp, #0x80
   14298:      	add	x0, sp, #0x80
   1429c:      	mov	w1, #0x10               // =16
   142a0:      	blr	x8
   142a4:      	ldr	w21, [sp, #0x84]
   142a8:      	ldr	x8, [sp, #0x40]
   142ac:      	ldr	x10, [sp, #0x60]
   142b0:      	sub	x12, x10, x8
   142b4:      	ldr	w23, [sp, #0x68]
   142b8:      	subs	w10, w21, w23
   142bc:      	ldr	x9, [sp, #0x88]
   142c0:      	ldr	x25, [sp, #0x8]
   142c4:      	csel	w10, wzr, w10, lo
   142c8:      	cmp	w23, w21
   142cc:      	csel	w11, w23, w21, lo
   142d0:      	cinc	w13, w11, hi
   142d4:      	sub	w14, w23, w13
   142d8:      	subs	x12, x12, x13
   142dc:      	str	w14, [sp, #0x68]
   142e0:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   142e4:      	cmp	x12, #0xfff
   142e8:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   142ec:      	cmp	w23, w21
   142f0:      	b.ls	0x142fc <generic_kprobe_path+0x94cc>
   142f4:      	mov	w13, #0x2f              // =47
   142f8:      	strb	w13, [x8, x12]
   142fc:      	add	x19, x8, x12
   14300:      	cmp	w23, w21
   14304:      	add	x2, x9, x10
   14308:      	and	w1, w11, #0xff
   1430c:      	mov	w8, #0x4                // =4
   14310:      	cinc	x0, x19, hi
   14314:      	blr	x8
   14318:      	ldr	x25, [sp, #0x8]
   1431c:      	cmp	w23, w21
   14320:      	str	x19, [sp, #0x60]
   14324:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   14328:      	ldr	x21, [sp, #0x78]
   1432c:      	ldp	x2, x24, [sp, #0x50]
   14330:      	str	x21, [sp, #0x48]
   14334:      	b	0x14388 <generic_kprobe_path+0x9558>
   14338:      	add	x2, x24, #0x10
   1433c:      	mov	w8, #0x4                // =4
   14340:      	add	x9, sp, #0x98
   14344:      	add	x0, sp, #0x98
   14348:      	mov	w1, #0x8                // =8
   1434c:      	blr	x8
   14350:      	ldr	x8, [sp, #0x58]
   14354:      	ldr	x9, [sp, #0x98]
   14358:      	cmp	x8, x9
   1435c:      	ldr	x25, [sp, #0x8]
   14360:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   14364:      	add	x2, x24, #0x18
   14368:      	mov	w8, #0x4                // =4
   1436c:      	mov	x0, x22
   14370:      	mov	w1, #0x8                // =8
   14374:      	blr	x8
   14378:      	ldr	x24, [sp, #0x98]
   1437c:      	ldr	x21, [sp, #0x48]
   14380:      	add	x2, x24, #0x20
   14384:      	stp	x2, x24, [sp, #0x50]
   14388:      	ldr	x8, [sp, #0x30]
   1438c:      	ldr	x25, [sp, #0x8]
   14390:      	add	x9, sp, #0x70
   14394:      	cmp	x21, x8
   14398:      	b.ne	0x143a8 <generic_kprobe_path+0x9578>
   1439c:      	ldr	x8, [sp, #0x38]
   143a0:      	cmp	x2, x8
   143a4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   143a8:      	mov	w8, #0x4                // =4
   143ac:      	add	x0, sp, #0x70
   143b0:      	mov	w1, #0x8                // =8
   143b4:      	blr	x8
   143b8:      	ldr	x8, [sp, #0x70]
   143bc:      	cmp	x21, x8
   143c0:      	b.eq	0x144b4 <generic_kprobe_path+0x9684>
   143c4:      	add	x23, x21, #0x18
   143c8:      	mov	w8, #0x4                // =4
   143cc:      	add	x9, sp, #0x98
   143d0:      	add	x0, sp, #0x98
   143d4:      	mov	w1, #0x8                // =8
   143d8:      	mov	x2, x23
   143dc:      	blr	x8
   143e0:      	ldr	x8, [sp, #0x98]
   143e4:      	cmp	x8, x21
   143e8:      	b.eq	0x144b4 <generic_kprobe_path+0x9684>
   143ec:      	mov	w8, #0x4                // =4
   143f0:      	add	x9, sp, #0x78
   143f4:      	add	x0, sp, #0x78
   143f8:      	mov	w1, #0x8                // =8
   143fc:      	mov	x2, x23
   14400:      	blr	x8
   14404:      	add	x2, x21, #0x20
   14408:      	mov	w8, #0x4                // =4
   1440c:      	mov	w9, #0x10               // =16
   14410:      	add	x10, sp, #0x80
   14414:      	add	x0, sp, #0x80
   14418:      	mov	w1, #0x10               // =16
   1441c:      	blr	x8
   14420:      	ldr	w21, [sp, #0x84]
   14424:      	ldr	x8, [sp, #0x40]
   14428:      	ldr	x10, [sp, #0x60]
   1442c:      	sub	x12, x10, x8
   14430:      	ldr	w23, [sp, #0x68]
   14434:      	subs	w10, w21, w23
   14438:      	ldr	x9, [sp, #0x88]
   1443c:      	ldr	x25, [sp, #0x8]
   14440:      	csel	w10, wzr, w10, lo
   14444:      	cmp	w23, w21
   14448:      	csel	w11, w23, w21, lo
   1444c:      	cinc	w13, w11, hi
   14450:      	sub	w14, w23, w13
   14454:      	subs	x12, x12, x13
   14458:      	str	w14, [sp, #0x68]
   1445c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   14460:      	cmp	x12, #0xfff
   14464:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   14468:      	cmp	w23, w21
   1446c:      	b.ls	0x14478 <generic_kprobe_path+0x9648>
   14470:      	mov	w13, #0x2f              // =47
   14474:      	strb	w13, [x8, x12]
   14478:      	add	x19, x8, x12
   1447c:      	cmp	w23, w21
   14480:      	add	x2, x9, x10
   14484:      	and	w1, w11, #0xff
   14488:      	mov	w8, #0x4                // =4
   1448c:      	cinc	x0, x19, hi
   14490:      	blr	x8
   14494:      	ldr	x25, [sp, #0x8]
   14498:      	cmp	w23, w21
   1449c:      	str	x19, [sp, #0x60]
   144a0:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   144a4:      	ldr	x21, [sp, #0x78]
   144a8:      	ldp	x2, x24, [sp, #0x50]
   144ac:      	str	x21, [sp, #0x48]
   144b0:      	b	0x14504 <generic_kprobe_path+0x96d4>
   144b4:      	add	x2, x24, #0x10
   144b8:      	mov	w8, #0x4                // =4
   144bc:      	add	x9, sp, #0x98
   144c0:      	add	x0, sp, #0x98
   144c4:      	mov	w1, #0x8                // =8
   144c8:      	blr	x8
   144cc:      	ldr	x8, [sp, #0x58]
   144d0:      	ldr	x9, [sp, #0x98]
   144d4:      	cmp	x8, x9
   144d8:      	ldr	x25, [sp, #0x8]
   144dc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   144e0:      	add	x2, x24, #0x18
   144e4:      	mov	w8, #0x4                // =4
   144e8:      	mov	x0, x22
   144ec:      	mov	w1, #0x8                // =8
   144f0:      	blr	x8
   144f4:      	ldr	x24, [sp, #0x98]
   144f8:      	ldr	x21, [sp, #0x48]
   144fc:      	add	x2, x24, #0x20
   14500:      	stp	x2, x24, [sp, #0x50]
   14504:      	ldr	x8, [sp, #0x30]
   14508:      	ldr	x25, [sp, #0x8]
   1450c:      	add	x9, sp, #0x70
   14510:      	cmp	x21, x8
   14514:      	b.ne	0x14524 <generic_kprobe_path+0x96f4>
   14518:      	ldr	x8, [sp, #0x38]
   1451c:      	cmp	x2, x8
   14520:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   14524:      	mov	w8, #0x4                // =4
   14528:      	add	x0, sp, #0x70
   1452c:      	mov	w1, #0x8                // =8
   14530:      	blr	x8
   14534:      	ldr	x8, [sp, #0x70]
   14538:      	cmp	x21, x8
   1453c:      	b.eq	0x14630 <generic_kprobe_path+0x9800>
   14540:      	add	x23, x21, #0x18
   14544:      	mov	w8, #0x4                // =4
   14548:      	add	x9, sp, #0x98
   1454c:      	add	x0, sp, #0x98
   14550:      	mov	w1, #0x8                // =8
   14554:      	mov	x2, x23
   14558:      	blr	x8
   1455c:      	ldr	x8, [sp, #0x98]
   14560:      	cmp	x8, x21
   14564:      	b.eq	0x14630 <generic_kprobe_path+0x9800>
   14568:      	mov	w8, #0x4                // =4
   1456c:      	add	x9, sp, #0x78
   14570:      	add	x0, sp, #0x78
   14574:      	mov	w1, #0x8                // =8
   14578:      	mov	x2, x23
   1457c:      	blr	x8
   14580:      	add	x2, x21, #0x20
   14584:      	mov	w8, #0x4                // =4
   14588:      	mov	w9, #0x10               // =16
   1458c:      	add	x10, sp, #0x80
   14590:      	add	x0, sp, #0x80
   14594:      	mov	w1, #0x10               // =16
   14598:      	blr	x8
   1459c:      	ldr	w21, [sp, #0x84]
   145a0:      	ldr	x8, [sp, #0x40]
   145a4:      	ldr	x10, [sp, #0x60]
   145a8:      	sub	x12, x10, x8
   145ac:      	ldr	w23, [sp, #0x68]
   145b0:      	subs	w10, w21, w23
   145b4:      	ldr	x9, [sp, #0x88]
   145b8:      	ldr	x25, [sp, #0x8]
   145bc:      	csel	w10, wzr, w10, lo
   145c0:      	cmp	w23, w21
   145c4:      	csel	w11, w23, w21, lo
   145c8:      	cinc	w13, w11, hi
   145cc:      	sub	w14, w23, w13
   145d0:      	subs	x12, x12, x13
   145d4:      	str	w14, [sp, #0x68]
   145d8:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   145dc:      	cmp	x12, #0xfff
   145e0:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   145e4:      	cmp	w23, w21
   145e8:      	b.ls	0x145f4 <generic_kprobe_path+0x97c4>
   145ec:      	mov	w13, #0x2f              // =47
   145f0:      	strb	w13, [x8, x12]
   145f4:      	add	x19, x8, x12
   145f8:      	cmp	w23, w21
   145fc:      	add	x2, x9, x10
   14600:      	and	w1, w11, #0xff
   14604:      	mov	w8, #0x4                // =4
   14608:      	cinc	x0, x19, hi
   1460c:      	blr	x8
   14610:      	ldr	x25, [sp, #0x8]
   14614:      	cmp	w23, w21
   14618:      	str	x19, [sp, #0x60]
   1461c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   14620:      	ldr	x21, [sp, #0x78]
   14624:      	ldp	x2, x24, [sp, #0x50]
   14628:      	str	x21, [sp, #0x48]
   1462c:      	b	0x14680 <generic_kprobe_path+0x9850>
   14630:      	add	x2, x24, #0x10
   14634:      	mov	w8, #0x4                // =4
   14638:      	add	x9, sp, #0x98
   1463c:      	add	x0, sp, #0x98
   14640:      	mov	w1, #0x8                // =8
   14644:      	blr	x8
   14648:      	ldr	x8, [sp, #0x58]
   1464c:      	ldr	x9, [sp, #0x98]
   14650:      	cmp	x8, x9
   14654:      	ldr	x25, [sp, #0x8]
   14658:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1465c:      	add	x2, x24, #0x18
   14660:      	mov	w8, #0x4                // =4
   14664:      	mov	x0, x22
   14668:      	mov	w1, #0x8                // =8
   1466c:      	blr	x8
   14670:      	ldr	x24, [sp, #0x98]
   14674:      	ldr	x21, [sp, #0x48]
   14678:      	add	x2, x24, #0x20
   1467c:      	stp	x2, x24, [sp, #0x50]
   14680:      	ldr	x8, [sp, #0x30]
   14684:      	ldr	x25, [sp, #0x8]
   14688:      	add	x9, sp, #0x70
   1468c:      	cmp	x21, x8
   14690:      	b.ne	0x146a0 <generic_kprobe_path+0x9870>
   14694:      	ldr	x8, [sp, #0x38]
   14698:      	cmp	x2, x8
   1469c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   146a0:      	mov	w8, #0x4                // =4
   146a4:      	add	x0, sp, #0x70
   146a8:      	mov	w1, #0x8                // =8
   146ac:      	blr	x8
   146b0:      	ldr	x8, [sp, #0x70]
   146b4:      	cmp	x21, x8
   146b8:      	b.eq	0x147ac <generic_kprobe_path+0x997c>
   146bc:      	add	x23, x21, #0x18
   146c0:      	mov	w8, #0x4                // =4
   146c4:      	add	x9, sp, #0x98
   146c8:      	add	x0, sp, #0x98
   146cc:      	mov	w1, #0x8                // =8
   146d0:      	mov	x2, x23
   146d4:      	blr	x8
   146d8:      	ldr	x8, [sp, #0x98]
   146dc:      	cmp	x8, x21
   146e0:      	b.eq	0x147ac <generic_kprobe_path+0x997c>
   146e4:      	mov	w8, #0x4                // =4
   146e8:      	add	x9, sp, #0x78
   146ec:      	add	x0, sp, #0x78
   146f0:      	mov	w1, #0x8                // =8
   146f4:      	mov	x2, x23
   146f8:      	blr	x8
   146fc:      	add	x2, x21, #0x20
   14700:      	mov	w8, #0x4                // =4
   14704:      	mov	w9, #0x10               // =16
   14708:      	add	x10, sp, #0x80
   1470c:      	add	x0, sp, #0x80
   14710:      	mov	w1, #0x10               // =16
   14714:      	blr	x8
   14718:      	ldr	w21, [sp, #0x84]
   1471c:      	ldr	x8, [sp, #0x40]
   14720:      	ldr	x10, [sp, #0x60]
   14724:      	sub	x12, x10, x8
   14728:      	ldr	w23, [sp, #0x68]
   1472c:      	subs	w10, w21, w23
   14730:      	ldr	x9, [sp, #0x88]
   14734:      	ldr	x25, [sp, #0x8]
   14738:      	csel	w10, wzr, w10, lo
   1473c:      	cmp	w23, w21
   14740:      	csel	w11, w23, w21, lo
   14744:      	cinc	w13, w11, hi
   14748:      	sub	w14, w23, w13
   1474c:      	subs	x12, x12, x13
   14750:      	str	w14, [sp, #0x68]
   14754:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   14758:      	cmp	x12, #0xfff
   1475c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   14760:      	cmp	w23, w21
   14764:      	b.ls	0x14770 <generic_kprobe_path+0x9940>
   14768:      	mov	w13, #0x2f              // =47
   1476c:      	strb	w13, [x8, x12]
   14770:      	add	x19, x8, x12
   14774:      	cmp	w23, w21
   14778:      	add	x2, x9, x10
   1477c:      	and	w1, w11, #0xff
   14780:      	mov	w8, #0x4                // =4
   14784:      	cinc	x0, x19, hi
   14788:      	blr	x8
   1478c:      	ldr	x25, [sp, #0x8]
   14790:      	cmp	w23, w21
   14794:      	str	x19, [sp, #0x60]
   14798:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   1479c:      	ldr	x21, [sp, #0x78]
   147a0:      	ldp	x2, x24, [sp, #0x50]
   147a4:      	str	x21, [sp, #0x48]
   147a8:      	b	0x147fc <generic_kprobe_path+0x99cc>
   147ac:      	add	x2, x24, #0x10
   147b0:      	mov	w8, #0x4                // =4
   147b4:      	add	x9, sp, #0x98
   147b8:      	add	x0, sp, #0x98
   147bc:      	mov	w1, #0x8                // =8
   147c0:      	blr	x8
   147c4:      	ldr	x8, [sp, #0x58]
   147c8:      	ldr	x9, [sp, #0x98]
   147cc:      	cmp	x8, x9
   147d0:      	ldr	x25, [sp, #0x8]
   147d4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   147d8:      	add	x2, x24, #0x18
   147dc:      	mov	w8, #0x4                // =4
   147e0:      	mov	x0, x22
   147e4:      	mov	w1, #0x8                // =8
   147e8:      	blr	x8
   147ec:      	ldr	x24, [sp, #0x98]
   147f0:      	ldr	x21, [sp, #0x48]
   147f4:      	add	x2, x24, #0x20
   147f8:      	stp	x2, x24, [sp, #0x50]
   147fc:      	ldr	x8, [sp, #0x30]
   14800:      	ldr	x25, [sp, #0x8]
   14804:      	add	x9, sp, #0x70
   14808:      	cmp	x21, x8
   1480c:      	b.ne	0x1481c <generic_kprobe_path+0x99ec>
   14810:      	ldr	x8, [sp, #0x38]
   14814:      	cmp	x2, x8
   14818:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1481c:      	mov	w8, #0x4                // =4
   14820:      	add	x0, sp, #0x70
   14824:      	mov	w1, #0x8                // =8
   14828:      	blr	x8
   1482c:      	ldr	x8, [sp, #0x70]
   14830:      	cmp	x21, x8
   14834:      	b.eq	0x14928 <generic_kprobe_path+0x9af8>
   14838:      	add	x23, x21, #0x18
   1483c:      	mov	w8, #0x4                // =4
   14840:      	add	x9, sp, #0x98
   14844:      	add	x0, sp, #0x98
   14848:      	mov	w1, #0x8                // =8
   1484c:      	mov	x2, x23
   14850:      	blr	x8
   14854:      	ldr	x8, [sp, #0x98]
   14858:      	cmp	x8, x21
   1485c:      	b.eq	0x14928 <generic_kprobe_path+0x9af8>
   14860:      	mov	w8, #0x4                // =4
   14864:      	add	x9, sp, #0x78
   14868:      	add	x0, sp, #0x78
   1486c:      	mov	w1, #0x8                // =8
   14870:      	mov	x2, x23
   14874:      	blr	x8
   14878:      	add	x2, x21, #0x20
   1487c:      	mov	w8, #0x4                // =4
   14880:      	mov	w9, #0x10               // =16
   14884:      	add	x10, sp, #0x80
   14888:      	add	x0, sp, #0x80
   1488c:      	mov	w1, #0x10               // =16
   14890:      	blr	x8
   14894:      	ldr	w21, [sp, #0x84]
   14898:      	ldr	x8, [sp, #0x40]
   1489c:      	ldr	x10, [sp, #0x60]
   148a0:      	sub	x12, x10, x8
   148a4:      	ldr	w23, [sp, #0x68]
   148a8:      	subs	w10, w21, w23
   148ac:      	ldr	x9, [sp, #0x88]
   148b0:      	ldr	x25, [sp, #0x8]
   148b4:      	csel	w10, wzr, w10, lo
   148b8:      	cmp	w23, w21
   148bc:      	csel	w11, w23, w21, lo
   148c0:      	cinc	w13, w11, hi
   148c4:      	sub	w14, w23, w13
   148c8:      	subs	x12, x12, x13
   148cc:      	str	w14, [sp, #0x68]
   148d0:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   148d4:      	cmp	x12, #0xfff
   148d8:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   148dc:      	cmp	w23, w21
   148e0:      	b.ls	0x148ec <generic_kprobe_path+0x9abc>
   148e4:      	mov	w13, #0x2f              // =47
   148e8:      	strb	w13, [x8, x12]
   148ec:      	add	x19, x8, x12
   148f0:      	cmp	w23, w21
   148f4:      	add	x2, x9, x10
   148f8:      	and	w1, w11, #0xff
   148fc:      	mov	w8, #0x4                // =4
   14900:      	cinc	x0, x19, hi
   14904:      	blr	x8
   14908:      	ldr	x25, [sp, #0x8]
   1490c:      	cmp	w23, w21
   14910:      	str	x19, [sp, #0x60]
   14914:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   14918:      	ldr	x21, [sp, #0x78]
   1491c:      	ldp	x2, x24, [sp, #0x50]
   14920:      	str	x21, [sp, #0x48]
   14924:      	b	0x14978 <generic_kprobe_path+0x9b48>
   14928:      	add	x2, x24, #0x10
   1492c:      	mov	w8, #0x4                // =4
   14930:      	add	x9, sp, #0x98
   14934:      	add	x0, sp, #0x98
   14938:      	mov	w1, #0x8                // =8
   1493c:      	blr	x8
   14940:      	ldr	x8, [sp, #0x58]
   14944:      	ldr	x9, [sp, #0x98]
   14948:      	cmp	x8, x9
   1494c:      	ldr	x25, [sp, #0x8]
   14950:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   14954:      	add	x2, x24, #0x18
   14958:      	mov	w8, #0x4                // =4
   1495c:      	mov	x0, x22
   14960:      	mov	w1, #0x8                // =8
   14964:      	blr	x8
   14968:      	ldr	x24, [sp, #0x98]
   1496c:      	ldr	x21, [sp, #0x48]
   14970:      	add	x2, x24, #0x20
   14974:      	stp	x2, x24, [sp, #0x50]
   14978:      	ldr	x8, [sp, #0x30]
   1497c:      	ldr	x25, [sp, #0x8]
   14980:      	add	x9, sp, #0x70
   14984:      	cmp	x21, x8
   14988:      	b.ne	0x14998 <generic_kprobe_path+0x9b68>
   1498c:      	ldr	x8, [sp, #0x38]
   14990:      	cmp	x2, x8
   14994:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   14998:      	mov	w8, #0x4                // =4
   1499c:      	add	x0, sp, #0x70
   149a0:      	mov	w1, #0x8                // =8
   149a4:      	blr	x8
   149a8:      	ldr	x8, [sp, #0x70]
   149ac:      	cmp	x21, x8
   149b0:      	b.eq	0x14aa4 <generic_kprobe_path+0x9c74>
   149b4:      	add	x23, x21, #0x18
   149b8:      	mov	w8, #0x4                // =4
   149bc:      	add	x9, sp, #0x98
   149c0:      	add	x0, sp, #0x98
   149c4:      	mov	w1, #0x8                // =8
   149c8:      	mov	x2, x23
   149cc:      	blr	x8
   149d0:      	ldr	x8, [sp, #0x98]
   149d4:      	cmp	x8, x21
   149d8:      	b.eq	0x14aa4 <generic_kprobe_path+0x9c74>
   149dc:      	mov	w8, #0x4                // =4
   149e0:      	add	x9, sp, #0x78
   149e4:      	add	x0, sp, #0x78
   149e8:      	mov	w1, #0x8                // =8
   149ec:      	mov	x2, x23
   149f0:      	blr	x8
   149f4:      	add	x2, x21, #0x20
   149f8:      	mov	w8, #0x4                // =4
   149fc:      	mov	w9, #0x10               // =16
   14a00:      	add	x10, sp, #0x80
   14a04:      	add	x0, sp, #0x80
   14a08:      	mov	w1, #0x10               // =16
   14a0c:      	blr	x8
   14a10:      	ldr	w21, [sp, #0x84]
   14a14:      	ldr	x8, [sp, #0x40]
   14a18:      	ldr	x10, [sp, #0x60]
   14a1c:      	sub	x12, x10, x8
   14a20:      	ldr	w23, [sp, #0x68]
   14a24:      	subs	w10, w21, w23
   14a28:      	ldr	x9, [sp, #0x88]
   14a2c:      	ldr	x25, [sp, #0x8]
   14a30:      	csel	w10, wzr, w10, lo
   14a34:      	cmp	w23, w21
   14a38:      	csel	w11, w23, w21, lo
   14a3c:      	cinc	w13, w11, hi
   14a40:      	sub	w14, w23, w13
   14a44:      	subs	x12, x12, x13
   14a48:      	str	w14, [sp, #0x68]
   14a4c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   14a50:      	cmp	x12, #0xfff
   14a54:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   14a58:      	cmp	w23, w21
   14a5c:      	b.ls	0x14a68 <generic_kprobe_path+0x9c38>
   14a60:      	mov	w13, #0x2f              // =47
   14a64:      	strb	w13, [x8, x12]
   14a68:      	add	x19, x8, x12
   14a6c:      	cmp	w23, w21
   14a70:      	add	x2, x9, x10
   14a74:      	and	w1, w11, #0xff
   14a78:      	mov	w8, #0x4                // =4
   14a7c:      	cinc	x0, x19, hi
   14a80:      	blr	x8
   14a84:      	ldr	x25, [sp, #0x8]
   14a88:      	cmp	w23, w21
   14a8c:      	str	x19, [sp, #0x60]
   14a90:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   14a94:      	ldr	x21, [sp, #0x78]
   14a98:      	ldp	x2, x24, [sp, #0x50]
   14a9c:      	str	x21, [sp, #0x48]
   14aa0:      	b	0x14af4 <generic_kprobe_path+0x9cc4>
   14aa4:      	add	x2, x24, #0x10
   14aa8:      	mov	w8, #0x4                // =4
   14aac:      	add	x9, sp, #0x98
   14ab0:      	add	x0, sp, #0x98
   14ab4:      	mov	w1, #0x8                // =8
   14ab8:      	blr	x8
   14abc:      	ldr	x8, [sp, #0x58]
   14ac0:      	ldr	x9, [sp, #0x98]
   14ac4:      	cmp	x8, x9
   14ac8:      	ldr	x25, [sp, #0x8]
   14acc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   14ad0:      	add	x2, x24, #0x18
   14ad4:      	mov	w8, #0x4                // =4
   14ad8:      	mov	x0, x22
   14adc:      	mov	w1, #0x8                // =8
   14ae0:      	blr	x8
   14ae4:      	ldr	x24, [sp, #0x98]
   14ae8:      	ldr	x21, [sp, #0x48]
   14aec:      	add	x2, x24, #0x20
   14af0:      	stp	x2, x24, [sp, #0x50]
   14af4:      	ldr	x8, [sp, #0x30]
   14af8:      	ldr	x25, [sp, #0x8]
   14afc:      	add	x9, sp, #0x70
   14b00:      	cmp	x21, x8
   14b04:      	b.ne	0x14b14 <generic_kprobe_path+0x9ce4>
   14b08:      	ldr	x8, [sp, #0x38]
   14b0c:      	cmp	x2, x8
   14b10:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   14b14:      	mov	w8, #0x4                // =4
   14b18:      	add	x0, sp, #0x70
   14b1c:      	mov	w1, #0x8                // =8
   14b20:      	blr	x8
   14b24:      	ldr	x8, [sp, #0x70]
   14b28:      	cmp	x21, x8
   14b2c:      	b.eq	0x14c20 <generic_kprobe_path+0x9df0>
   14b30:      	add	x23, x21, #0x18
   14b34:      	mov	w8, #0x4                // =4
   14b38:      	add	x9, sp, #0x98
   14b3c:      	add	x0, sp, #0x98
   14b40:      	mov	w1, #0x8                // =8
   14b44:      	mov	x2, x23
   14b48:      	blr	x8
   14b4c:      	ldr	x8, [sp, #0x98]
   14b50:      	cmp	x8, x21
   14b54:      	b.eq	0x14c20 <generic_kprobe_path+0x9df0>
   14b58:      	mov	w8, #0x4                // =4
   14b5c:      	add	x9, sp, #0x78
   14b60:      	add	x0, sp, #0x78
   14b64:      	mov	w1, #0x8                // =8
   14b68:      	mov	x2, x23
   14b6c:      	blr	x8
   14b70:      	add	x2, x21, #0x20
   14b74:      	mov	w8, #0x4                // =4
   14b78:      	mov	w9, #0x10               // =16
   14b7c:      	add	x10, sp, #0x80
   14b80:      	add	x0, sp, #0x80
   14b84:      	mov	w1, #0x10               // =16
   14b88:      	blr	x8
   14b8c:      	ldr	w21, [sp, #0x84]
   14b90:      	ldr	x8, [sp, #0x40]
   14b94:      	ldr	x10, [sp, #0x60]
   14b98:      	sub	x12, x10, x8
   14b9c:      	ldr	w23, [sp, #0x68]
   14ba0:      	subs	w10, w21, w23
   14ba4:      	ldr	x9, [sp, #0x88]
   14ba8:      	ldr	x25, [sp, #0x8]
   14bac:      	csel	w10, wzr, w10, lo
   14bb0:      	cmp	w23, w21
   14bb4:      	csel	w11, w23, w21, lo
   14bb8:      	cinc	w13, w11, hi
   14bbc:      	sub	w14, w23, w13
   14bc0:      	subs	x12, x12, x13
   14bc4:      	str	w14, [sp, #0x68]
   14bc8:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   14bcc:      	cmp	x12, #0xfff
   14bd0:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   14bd4:      	cmp	w23, w21
   14bd8:      	b.ls	0x14be4 <generic_kprobe_path+0x9db4>
   14bdc:      	mov	w13, #0x2f              // =47
   14be0:      	strb	w13, [x8, x12]
   14be4:      	add	x19, x8, x12
   14be8:      	cmp	w23, w21
   14bec:      	add	x2, x9, x10
   14bf0:      	and	w1, w11, #0xff
   14bf4:      	mov	w8, #0x4                // =4
   14bf8:      	cinc	x0, x19, hi
   14bfc:      	blr	x8
   14c00:      	ldr	x25, [sp, #0x8]
   14c04:      	cmp	w23, w21
   14c08:      	str	x19, [sp, #0x60]
   14c0c:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   14c10:      	ldr	x21, [sp, #0x78]
   14c14:      	ldp	x2, x24, [sp, #0x50]
   14c18:      	str	x21, [sp, #0x48]
   14c1c:      	b	0x14c70 <generic_kprobe_path+0x9e40>
   14c20:      	add	x2, x24, #0x10
   14c24:      	mov	w8, #0x4                // =4
   14c28:      	add	x9, sp, #0x98
   14c2c:      	add	x0, sp, #0x98
   14c30:      	mov	w1, #0x8                // =8
   14c34:      	blr	x8
   14c38:      	ldr	x8, [sp, #0x58]
   14c3c:      	ldr	x9, [sp, #0x98]
   14c40:      	cmp	x8, x9
   14c44:      	ldr	x25, [sp, #0x8]
   14c48:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   14c4c:      	add	x2, x24, #0x18
   14c50:      	mov	w8, #0x4                // =4
   14c54:      	mov	x0, x22
   14c58:      	mov	w1, #0x8                // =8
   14c5c:      	blr	x8
   14c60:      	ldr	x24, [sp, #0x98]
   14c64:      	ldr	x21, [sp, #0x48]
   14c68:      	add	x2, x24, #0x20
   14c6c:      	stp	x2, x24, [sp, #0x50]
   14c70:      	ldr	x8, [sp, #0x30]
   14c74:      	ldr	x25, [sp, #0x8]
   14c78:      	add	x9, sp, #0x70
   14c7c:      	cmp	x21, x8
   14c80:      	b.ne	0x14c90 <generic_kprobe_path+0x9e60>
   14c84:      	ldr	x8, [sp, #0x38]
   14c88:      	cmp	x2, x8
   14c8c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   14c90:      	mov	w8, #0x4                // =4
   14c94:      	add	x0, sp, #0x70
   14c98:      	mov	w1, #0x8                // =8
   14c9c:      	blr	x8
   14ca0:      	ldr	x8, [sp, #0x70]
   14ca4:      	cmp	x21, x8
   14ca8:      	b.eq	0x14d9c <generic_kprobe_path+0x9f6c>
   14cac:      	add	x23, x21, #0x18
   14cb0:      	mov	w8, #0x4                // =4
   14cb4:      	add	x9, sp, #0x98
   14cb8:      	add	x0, sp, #0x98
   14cbc:      	mov	w1, #0x8                // =8
   14cc0:      	mov	x2, x23
   14cc4:      	blr	x8
   14cc8:      	ldr	x8, [sp, #0x98]
   14ccc:      	cmp	x8, x21
   14cd0:      	b.eq	0x14d9c <generic_kprobe_path+0x9f6c>
   14cd4:      	mov	w8, #0x4                // =4
   14cd8:      	add	x9, sp, #0x78
   14cdc:      	add	x0, sp, #0x78
   14ce0:      	mov	w1, #0x8                // =8
   14ce4:      	mov	x2, x23
   14ce8:      	blr	x8
   14cec:      	add	x2, x21, #0x20
   14cf0:      	mov	w8, #0x4                // =4
   14cf4:      	mov	w9, #0x10               // =16
   14cf8:      	add	x10, sp, #0x80
   14cfc:      	add	x0, sp, #0x80
   14d00:      	mov	w1, #0x10               // =16
   14d04:      	blr	x8
   14d08:      	ldr	w21, [sp, #0x84]
   14d0c:      	ldr	x8, [sp, #0x40]
   14d10:      	ldr	x10, [sp, #0x60]
   14d14:      	sub	x12, x10, x8
   14d18:      	ldr	w23, [sp, #0x68]
   14d1c:      	subs	w10, w21, w23
   14d20:      	ldr	x9, [sp, #0x88]
   14d24:      	ldr	x25, [sp, #0x8]
   14d28:      	csel	w10, wzr, w10, lo
   14d2c:      	cmp	w23, w21
   14d30:      	csel	w11, w23, w21, lo
   14d34:      	cinc	w13, w11, hi
   14d38:      	sub	w14, w23, w13
   14d3c:      	subs	x12, x12, x13
   14d40:      	str	w14, [sp, #0x68]
   14d44:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   14d48:      	cmp	x12, #0xfff
   14d4c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   14d50:      	cmp	w23, w21
   14d54:      	b.ls	0x14d60 <generic_kprobe_path+0x9f30>
   14d58:      	mov	w13, #0x2f              // =47
   14d5c:      	strb	w13, [x8, x12]
   14d60:      	add	x19, x8, x12
   14d64:      	cmp	w23, w21
   14d68:      	add	x2, x9, x10
   14d6c:      	and	w1, w11, #0xff
   14d70:      	mov	w8, #0x4                // =4
   14d74:      	cinc	x0, x19, hi
   14d78:      	blr	x8
   14d7c:      	ldr	x25, [sp, #0x8]
   14d80:      	cmp	w23, w21
   14d84:      	str	x19, [sp, #0x60]
   14d88:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   14d8c:      	ldr	x21, [sp, #0x78]
   14d90:      	ldp	x2, x24, [sp, #0x50]
   14d94:      	str	x21, [sp, #0x48]
   14d98:      	b	0x14dec <generic_kprobe_path+0x9fbc>
   14d9c:      	add	x2, x24, #0x10
   14da0:      	mov	w8, #0x4                // =4
   14da4:      	add	x9, sp, #0x98
   14da8:      	add	x0, sp, #0x98
   14dac:      	mov	w1, #0x8                // =8
   14db0:      	blr	x8
   14db4:      	ldr	x8, [sp, #0x58]
   14db8:      	ldr	x9, [sp, #0x98]
   14dbc:      	cmp	x8, x9
   14dc0:      	ldr	x25, [sp, #0x8]
   14dc4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   14dc8:      	add	x2, x24, #0x18
   14dcc:      	mov	w8, #0x4                // =4
   14dd0:      	mov	x0, x22
   14dd4:      	mov	w1, #0x8                // =8
   14dd8:      	blr	x8
   14ddc:      	ldr	x24, [sp, #0x98]
   14de0:      	ldr	x21, [sp, #0x48]
   14de4:      	add	x2, x24, #0x20
   14de8:      	stp	x2, x24, [sp, #0x50]
   14dec:      	ldr	x8, [sp, #0x30]
   14df0:      	ldr	x25, [sp, #0x8]
   14df4:      	add	x9, sp, #0x70
   14df8:      	cmp	x21, x8
   14dfc:      	b.ne	0x14e0c <generic_kprobe_path+0x9fdc>
   14e00:      	ldr	x8, [sp, #0x38]
   14e04:      	cmp	x2, x8
   14e08:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   14e0c:      	mov	w8, #0x4                // =4
   14e10:      	add	x0, sp, #0x70
   14e14:      	mov	w1, #0x8                // =8
   14e18:      	blr	x8
   14e1c:      	ldr	x8, [sp, #0x70]
   14e20:      	cmp	x21, x8
   14e24:      	b.eq	0x14f18 <generic_kprobe_path+0xa0e8>
   14e28:      	add	x23, x21, #0x18
   14e2c:      	mov	w8, #0x4                // =4
   14e30:      	add	x9, sp, #0x98
   14e34:      	add	x0, sp, #0x98
   14e38:      	mov	w1, #0x8                // =8
   14e3c:      	mov	x2, x23
   14e40:      	blr	x8
   14e44:      	ldr	x8, [sp, #0x98]
   14e48:      	cmp	x8, x21
   14e4c:      	b.eq	0x14f18 <generic_kprobe_path+0xa0e8>
   14e50:      	mov	w8, #0x4                // =4
   14e54:      	add	x9, sp, #0x78
   14e58:      	add	x0, sp, #0x78
   14e5c:      	mov	w1, #0x8                // =8
   14e60:      	mov	x2, x23
   14e64:      	blr	x8
   14e68:      	add	x2, x21, #0x20
   14e6c:      	mov	w8, #0x4                // =4
   14e70:      	mov	w9, #0x10               // =16
   14e74:      	add	x10, sp, #0x80
   14e78:      	add	x0, sp, #0x80
   14e7c:      	mov	w1, #0x10               // =16
   14e80:      	blr	x8
   14e84:      	ldr	w21, [sp, #0x84]
   14e88:      	ldr	x8, [sp, #0x40]
   14e8c:      	ldr	x10, [sp, #0x60]
   14e90:      	sub	x12, x10, x8
   14e94:      	ldr	w23, [sp, #0x68]
   14e98:      	subs	w10, w21, w23
   14e9c:      	ldr	x9, [sp, #0x88]
   14ea0:      	ldr	x25, [sp, #0x8]
   14ea4:      	csel	w10, wzr, w10, lo
   14ea8:      	cmp	w23, w21
   14eac:      	csel	w11, w23, w21, lo
   14eb0:      	cinc	w13, w11, hi
   14eb4:      	sub	w14, w23, w13
   14eb8:      	subs	x12, x12, x13
   14ebc:      	str	w14, [sp, #0x68]
   14ec0:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   14ec4:      	cmp	x12, #0xfff
   14ec8:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   14ecc:      	cmp	w23, w21
   14ed0:      	b.ls	0x14edc <generic_kprobe_path+0xa0ac>
   14ed4:      	mov	w13, #0x2f              // =47
   14ed8:      	strb	w13, [x8, x12]
   14edc:      	add	x19, x8, x12
   14ee0:      	cmp	w23, w21
   14ee4:      	add	x2, x9, x10
   14ee8:      	and	w1, w11, #0xff
   14eec:      	mov	w8, #0x4                // =4
   14ef0:      	cinc	x0, x19, hi
   14ef4:      	blr	x8
   14ef8:      	ldr	x25, [sp, #0x8]
   14efc:      	cmp	w23, w21
   14f00:      	str	x19, [sp, #0x60]
   14f04:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   14f08:      	ldr	x21, [sp, #0x78]
   14f0c:      	ldp	x2, x24, [sp, #0x50]
   14f10:      	str	x21, [sp, #0x48]
   14f14:      	b	0x14f68 <generic_kprobe_path+0xa138>
   14f18:      	add	x2, x24, #0x10
   14f1c:      	mov	w8, #0x4                // =4
   14f20:      	add	x9, sp, #0x98
   14f24:      	add	x0, sp, #0x98
   14f28:      	mov	w1, #0x8                // =8
   14f2c:      	blr	x8
   14f30:      	ldr	x8, [sp, #0x58]
   14f34:      	ldr	x9, [sp, #0x98]
   14f38:      	cmp	x8, x9
   14f3c:      	ldr	x25, [sp, #0x8]
   14f40:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   14f44:      	add	x2, x24, #0x18
   14f48:      	mov	w8, #0x4                // =4
   14f4c:      	mov	x0, x22
   14f50:      	mov	w1, #0x8                // =8
   14f54:      	blr	x8
   14f58:      	ldr	x24, [sp, #0x98]
   14f5c:      	ldr	x21, [sp, #0x48]
   14f60:      	add	x2, x24, #0x20
   14f64:      	stp	x2, x24, [sp, #0x50]
   14f68:      	ldr	x8, [sp, #0x30]
   14f6c:      	ldr	x25, [sp, #0x8]
   14f70:      	add	x9, sp, #0x70
   14f74:      	cmp	x21, x8
   14f78:      	b.ne	0x14f88 <generic_kprobe_path+0xa158>
   14f7c:      	ldr	x8, [sp, #0x38]
   14f80:      	cmp	x2, x8
   14f84:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   14f88:      	mov	w8, #0x4                // =4
   14f8c:      	add	x0, sp, #0x70
   14f90:      	mov	w1, #0x8                // =8
   14f94:      	blr	x8
   14f98:      	ldr	x8, [sp, #0x70]
   14f9c:      	cmp	x21, x8
   14fa0:      	b.eq	0x15094 <generic_kprobe_path+0xa264>
   14fa4:      	add	x23, x21, #0x18
   14fa8:      	mov	w8, #0x4                // =4
   14fac:      	add	x9, sp, #0x98
   14fb0:      	add	x0, sp, #0x98
   14fb4:      	mov	w1, #0x8                // =8
   14fb8:      	mov	x2, x23
   14fbc:      	blr	x8
   14fc0:      	ldr	x8, [sp, #0x98]
   14fc4:      	cmp	x8, x21
   14fc8:      	b.eq	0x15094 <generic_kprobe_path+0xa264>
   14fcc:      	mov	w8, #0x4                // =4
   14fd0:      	add	x9, sp, #0x78
   14fd4:      	add	x0, sp, #0x78
   14fd8:      	mov	w1, #0x8                // =8
   14fdc:      	mov	x2, x23
   14fe0:      	blr	x8
   14fe4:      	add	x2, x21, #0x20
   14fe8:      	mov	w8, #0x4                // =4
   14fec:      	mov	w9, #0x10               // =16
   14ff0:      	add	x10, sp, #0x80
   14ff4:      	add	x0, sp, #0x80
   14ff8:      	mov	w1, #0x10               // =16
   14ffc:      	blr	x8
   15000:      	ldr	w21, [sp, #0x84]
   15004:      	ldr	x8, [sp, #0x40]
   15008:      	ldr	x10, [sp, #0x60]
   1500c:      	sub	x12, x10, x8
   15010:      	ldr	w23, [sp, #0x68]
   15014:      	subs	w10, w21, w23
   15018:      	ldr	x9, [sp, #0x88]
   1501c:      	ldr	x25, [sp, #0x8]
   15020:      	csel	w10, wzr, w10, lo
   15024:      	cmp	w23, w21
   15028:      	csel	w11, w23, w21, lo
   1502c:      	cinc	w13, w11, hi
   15030:      	sub	w14, w23, w13
   15034:      	subs	x12, x12, x13
   15038:      	str	w14, [sp, #0x68]
   1503c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   15040:      	cmp	x12, #0xfff
   15044:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   15048:      	cmp	w23, w21
   1504c:      	b.ls	0x15058 <generic_kprobe_path+0xa228>
   15050:      	mov	w13, #0x2f              // =47
   15054:      	strb	w13, [x8, x12]
   15058:      	add	x19, x8, x12
   1505c:      	cmp	w23, w21
   15060:      	add	x2, x9, x10
   15064:      	and	w1, w11, #0xff
   15068:      	mov	w8, #0x4                // =4
   1506c:      	cinc	x0, x19, hi
   15070:      	blr	x8
   15074:      	ldr	x25, [sp, #0x8]
   15078:      	cmp	w23, w21
   1507c:      	str	x19, [sp, #0x60]
   15080:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   15084:      	ldr	x21, [sp, #0x78]
   15088:      	ldp	x2, x24, [sp, #0x50]
   1508c:      	str	x21, [sp, #0x48]
   15090:      	b	0x150e4 <generic_kprobe_path+0xa2b4>
   15094:      	add	x2, x24, #0x10
   15098:      	mov	w8, #0x4                // =4
   1509c:      	add	x9, sp, #0x98
   150a0:      	add	x0, sp, #0x98
   150a4:      	mov	w1, #0x8                // =8
   150a8:      	blr	x8
   150ac:      	ldr	x8, [sp, #0x58]
   150b0:      	ldr	x9, [sp, #0x98]
   150b4:      	cmp	x8, x9
   150b8:      	ldr	x25, [sp, #0x8]
   150bc:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   150c0:      	add	x2, x24, #0x18
   150c4:      	mov	w8, #0x4                // =4
   150c8:      	mov	x0, x22
   150cc:      	mov	w1, #0x8                // =8
   150d0:      	blr	x8
   150d4:      	ldr	x24, [sp, #0x98]
   150d8:      	ldr	x21, [sp, #0x48]
   150dc:      	add	x2, x24, #0x20
   150e0:      	stp	x2, x24, [sp, #0x50]
   150e4:      	ldr	x8, [sp, #0x30]
   150e8:      	ldr	x25, [sp, #0x8]
   150ec:      	add	x9, sp, #0x70
   150f0:      	cmp	x21, x8
   150f4:      	b.ne	0x15104 <generic_kprobe_path+0xa2d4>
   150f8:      	ldr	x8, [sp, #0x38]
   150fc:      	cmp	x2, x8
   15100:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   15104:      	mov	w8, #0x4                // =4
   15108:      	add	x0, sp, #0x70
   1510c:      	mov	w1, #0x8                // =8
   15110:      	blr	x8
   15114:      	ldr	x8, [sp, #0x70]
   15118:      	cmp	x21, x8
   1511c:      	b.eq	0x15210 <generic_kprobe_path+0xa3e0>
   15120:      	add	x23, x21, #0x18
   15124:      	mov	w8, #0x4                // =4
   15128:      	add	x9, sp, #0x98
   1512c:      	add	x0, sp, #0x98
   15130:      	mov	w1, #0x8                // =8
   15134:      	mov	x2, x23
   15138:      	blr	x8
   1513c:      	ldr	x8, [sp, #0x98]
   15140:      	cmp	x8, x21
   15144:      	b.eq	0x15210 <generic_kprobe_path+0xa3e0>
   15148:      	mov	w8, #0x4                // =4
   1514c:      	add	x9, sp, #0x78
   15150:      	add	x0, sp, #0x78
   15154:      	mov	w1, #0x8                // =8
   15158:      	mov	x2, x23
   1515c:      	blr	x8
   15160:      	add	x2, x21, #0x20
   15164:      	mov	w8, #0x4                // =4
   15168:      	mov	w9, #0x10               // =16
   1516c:      	add	x10, sp, #0x80
   15170:      	add	x0, sp, #0x80
   15174:      	mov	w1, #0x10               // =16
   15178:      	blr	x8
   1517c:      	ldr	w21, [sp, #0x84]
   15180:      	ldr	x8, [sp, #0x40]
   15184:      	ldr	x10, [sp, #0x60]
   15188:      	sub	x12, x10, x8
   1518c:      	ldr	w23, [sp, #0x68]
   15190:      	subs	w10, w21, w23
   15194:      	ldr	x9, [sp, #0x88]
   15198:      	ldr	x25, [sp, #0x8]
   1519c:      	csel	w10, wzr, w10, lo
   151a0:      	cmp	w23, w21
   151a4:      	csel	w11, w23, w21, lo
   151a8:      	cinc	w13, w11, hi
   151ac:      	sub	w14, w23, w13
   151b0:      	subs	x12, x12, x13
   151b4:      	str	w14, [sp, #0x68]
   151b8:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   151bc:      	cmp	x12, #0xfff
   151c0:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   151c4:      	cmp	w23, w21
   151c8:      	b.ls	0x151d4 <generic_kprobe_path+0xa3a4>
   151cc:      	mov	w13, #0x2f              // =47
   151d0:      	strb	w13, [x8, x12]
   151d4:      	add	x19, x8, x12
   151d8:      	cmp	w23, w21
   151dc:      	add	x2, x9, x10
   151e0:      	and	w1, w11, #0xff
   151e4:      	mov	w8, #0x4                // =4
   151e8:      	cinc	x0, x19, hi
   151ec:      	blr	x8
   151f0:      	ldr	x25, [sp, #0x8]
   151f4:      	cmp	w23, w21
   151f8:      	str	x19, [sp, #0x60]
   151fc:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   15200:      	ldr	x21, [sp, #0x78]
   15204:      	ldp	x2, x24, [sp, #0x50]
   15208:      	str	x21, [sp, #0x48]
   1520c:      	b	0x15260 <generic_kprobe_path+0xa430>
   15210:      	add	x2, x24, #0x10
   15214:      	mov	w8, #0x4                // =4
   15218:      	add	x9, sp, #0x98
   1521c:      	add	x0, sp, #0x98
   15220:      	mov	w1, #0x8                // =8
   15224:      	blr	x8
   15228:      	ldr	x8, [sp, #0x58]
   1522c:      	ldr	x9, [sp, #0x98]
   15230:      	cmp	x8, x9
   15234:      	ldr	x25, [sp, #0x8]
   15238:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1523c:      	add	x2, x24, #0x18
   15240:      	mov	w8, #0x4                // =4
   15244:      	mov	x0, x22
   15248:      	mov	w1, #0x8                // =8
   1524c:      	blr	x8
   15250:      	ldr	x24, [sp, #0x98]
   15254:      	ldr	x21, [sp, #0x48]
   15258:      	add	x2, x24, #0x20
   1525c:      	stp	x2, x24, [sp, #0x50]
   15260:      	ldr	x8, [sp, #0x30]
   15264:      	ldr	x25, [sp, #0x8]
   15268:      	add	x9, sp, #0x70
   1526c:      	cmp	x21, x8
   15270:      	b.ne	0x15280 <generic_kprobe_path+0xa450>
   15274:      	ldr	x8, [sp, #0x38]
   15278:      	cmp	x2, x8
   1527c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   15280:      	mov	w8, #0x4                // =4
   15284:      	add	x0, sp, #0x70
   15288:      	mov	w1, #0x8                // =8
   1528c:      	blr	x8
   15290:      	ldr	x8, [sp, #0x70]
   15294:      	cmp	x21, x8
   15298:      	b.eq	0x1538c <generic_kprobe_path+0xa55c>
   1529c:      	add	x23, x21, #0x18
   152a0:      	mov	w8, #0x4                // =4
   152a4:      	add	x9, sp, #0x98
   152a8:      	add	x0, sp, #0x98
   152ac:      	mov	w1, #0x8                // =8
   152b0:      	mov	x2, x23
   152b4:      	blr	x8
   152b8:      	ldr	x8, [sp, #0x98]
   152bc:      	cmp	x8, x21
   152c0:      	b.eq	0x1538c <generic_kprobe_path+0xa55c>
   152c4:      	mov	w8, #0x4                // =4
   152c8:      	add	x9, sp, #0x78
   152cc:      	add	x0, sp, #0x78
   152d0:      	mov	w1, #0x8                // =8
   152d4:      	mov	x2, x23
   152d8:      	blr	x8
   152dc:      	add	x2, x21, #0x20
   152e0:      	mov	w8, #0x4                // =4
   152e4:      	mov	w9, #0x10               // =16
   152e8:      	add	x10, sp, #0x80
   152ec:      	add	x0, sp, #0x80
   152f0:      	mov	w1, #0x10               // =16
   152f4:      	blr	x8
   152f8:      	ldr	w21, [sp, #0x84]
   152fc:      	ldr	x8, [sp, #0x40]
   15300:      	ldr	x10, [sp, #0x60]
   15304:      	sub	x12, x10, x8
   15308:      	ldr	w23, [sp, #0x68]
   1530c:      	subs	w10, w21, w23
   15310:      	ldr	x9, [sp, #0x88]
   15314:      	ldr	x25, [sp, #0x8]
   15318:      	csel	w10, wzr, w10, lo
   1531c:      	cmp	w23, w21
   15320:      	csel	w11, w23, w21, lo
   15324:      	cinc	w13, w11, hi
   15328:      	sub	w14, w23, w13
   1532c:      	subs	x12, x12, x13
   15330:      	str	w14, [sp, #0x68]
   15334:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   15338:      	cmp	x12, #0xfff
   1533c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   15340:      	cmp	w23, w21
   15344:      	b.ls	0x15350 <generic_kprobe_path+0xa520>
   15348:      	mov	w13, #0x2f              // =47
   1534c:      	strb	w13, [x8, x12]
   15350:      	add	x19, x8, x12
   15354:      	cmp	w23, w21
   15358:      	add	x2, x9, x10
   1535c:      	and	w1, w11, #0xff
   15360:      	mov	w8, #0x4                // =4
   15364:      	cinc	x0, x19, hi
   15368:      	blr	x8
   1536c:      	ldr	x25, [sp, #0x8]
   15370:      	cmp	w23, w21
   15374:      	str	x19, [sp, #0x60]
   15378:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   1537c:      	ldr	x21, [sp, #0x78]
   15380:      	ldp	x2, x24, [sp, #0x50]
   15384:      	str	x21, [sp, #0x48]
   15388:      	b	0x153dc <generic_kprobe_path+0xa5ac>
   1538c:      	add	x2, x24, #0x10
   15390:      	mov	w8, #0x4                // =4
   15394:      	add	x9, sp, #0x98
   15398:      	add	x0, sp, #0x98
   1539c:      	mov	w1, #0x8                // =8
   153a0:      	blr	x8
   153a4:      	ldr	x8, [sp, #0x58]
   153a8:      	ldr	x9, [sp, #0x98]
   153ac:      	cmp	x8, x9
   153b0:      	ldr	x25, [sp, #0x8]
   153b4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   153b8:      	add	x2, x24, #0x18
   153bc:      	mov	w8, #0x4                // =4
   153c0:      	mov	x0, x22
   153c4:      	mov	w1, #0x8                // =8
   153c8:      	blr	x8
   153cc:      	ldr	x24, [sp, #0x98]
   153d0:      	ldr	x21, [sp, #0x48]
   153d4:      	add	x2, x24, #0x20
   153d8:      	stp	x2, x24, [sp, #0x50]
   153dc:      	ldr	x8, [sp, #0x30]
   153e0:      	ldr	x25, [sp, #0x8]
   153e4:      	add	x9, sp, #0x70
   153e8:      	cmp	x21, x8
   153ec:      	b.ne	0x153fc <generic_kprobe_path+0xa5cc>
   153f0:      	ldr	x8, [sp, #0x38]
   153f4:      	cmp	x2, x8
   153f8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   153fc:      	mov	w8, #0x4                // =4
   15400:      	add	x0, sp, #0x70
   15404:      	mov	w1, #0x8                // =8
   15408:      	blr	x8
   1540c:      	ldr	x8, [sp, #0x70]
   15410:      	cmp	x21, x8
   15414:      	b.eq	0x15508 <generic_kprobe_path+0xa6d8>
   15418:      	add	x23, x21, #0x18
   1541c:      	mov	w8, #0x4                // =4
   15420:      	add	x9, sp, #0x98
   15424:      	add	x0, sp, #0x98
   15428:      	mov	w1, #0x8                // =8
   1542c:      	mov	x2, x23
   15430:      	blr	x8
   15434:      	ldr	x8, [sp, #0x98]
   15438:      	cmp	x8, x21
   1543c:      	b.eq	0x15508 <generic_kprobe_path+0xa6d8>
   15440:      	mov	w8, #0x4                // =4
   15444:      	add	x9, sp, #0x78
   15448:      	add	x0, sp, #0x78
   1544c:      	mov	w1, #0x8                // =8
   15450:      	mov	x2, x23
   15454:      	blr	x8
   15458:      	add	x2, x21, #0x20
   1545c:      	mov	w8, #0x4                // =4
   15460:      	mov	w9, #0x10               // =16
   15464:      	add	x10, sp, #0x80
   15468:      	add	x0, sp, #0x80
   1546c:      	mov	w1, #0x10               // =16
   15470:      	blr	x8
   15474:      	ldr	w21, [sp, #0x84]
   15478:      	ldr	x8, [sp, #0x40]
   1547c:      	ldr	x10, [sp, #0x60]
   15480:      	sub	x12, x10, x8
   15484:      	ldr	w23, [sp, #0x68]
   15488:      	subs	w10, w21, w23
   1548c:      	ldr	x9, [sp, #0x88]
   15490:      	ldr	x25, [sp, #0x8]
   15494:      	csel	w10, wzr, w10, lo
   15498:      	cmp	w23, w21
   1549c:      	csel	w11, w23, w21, lo
   154a0:      	cinc	w13, w11, hi
   154a4:      	sub	w14, w23, w13
   154a8:      	subs	x12, x12, x13
   154ac:      	str	w14, [sp, #0x68]
   154b0:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   154b4:      	cmp	x12, #0xfff
   154b8:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   154bc:      	cmp	w23, w21
   154c0:      	b.ls	0x154cc <generic_kprobe_path+0xa69c>
   154c4:      	mov	w13, #0x2f              // =47
   154c8:      	strb	w13, [x8, x12]
   154cc:      	add	x19, x8, x12
   154d0:      	cmp	w23, w21
   154d4:      	add	x2, x9, x10
   154d8:      	and	w1, w11, #0xff
   154dc:      	mov	w8, #0x4                // =4
   154e0:      	cinc	x0, x19, hi
   154e4:      	blr	x8
   154e8:      	ldr	x25, [sp, #0x8]
   154ec:      	cmp	w23, w21
   154f0:      	str	x19, [sp, #0x60]
   154f4:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   154f8:      	ldr	x21, [sp, #0x78]
   154fc:      	ldp	x2, x24, [sp, #0x50]
   15500:      	str	x21, [sp, #0x48]
   15504:      	b	0x15558 <generic_kprobe_path+0xa728>
   15508:      	add	x2, x24, #0x10
   1550c:      	mov	w8, #0x4                // =4
   15510:      	add	x9, sp, #0x98
   15514:      	add	x0, sp, #0x98
   15518:      	mov	w1, #0x8                // =8
   1551c:      	blr	x8
   15520:      	ldr	x8, [sp, #0x58]
   15524:      	ldr	x9, [sp, #0x98]
   15528:      	cmp	x8, x9
   1552c:      	ldr	x25, [sp, #0x8]
   15530:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   15534:      	add	x2, x24, #0x18
   15538:      	mov	w8, #0x4                // =4
   1553c:      	mov	x0, x22
   15540:      	mov	w1, #0x8                // =8
   15544:      	blr	x8
   15548:      	ldr	x24, [sp, #0x98]
   1554c:      	ldr	x21, [sp, #0x48]
   15550:      	add	x2, x24, #0x20
   15554:      	stp	x2, x24, [sp, #0x50]
   15558:      	ldr	x8, [sp, #0x30]
   1555c:      	ldr	x25, [sp, #0x8]
   15560:      	add	x9, sp, #0x70
   15564:      	cmp	x21, x8
   15568:      	b.ne	0x15578 <generic_kprobe_path+0xa748>
   1556c:      	ldr	x8, [sp, #0x38]
   15570:      	cmp	x2, x8
   15574:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   15578:      	mov	w8, #0x4                // =4
   1557c:      	add	x0, sp, #0x70
   15580:      	mov	w1, #0x8                // =8
   15584:      	blr	x8
   15588:      	ldr	x8, [sp, #0x70]
   1558c:      	cmp	x21, x8
   15590:      	b.eq	0x15684 <generic_kprobe_path+0xa854>
   15594:      	add	x23, x21, #0x18
   15598:      	mov	w8, #0x4                // =4
   1559c:      	add	x9, sp, #0x98
   155a0:      	add	x0, sp, #0x98
   155a4:      	mov	w1, #0x8                // =8
   155a8:      	mov	x2, x23
   155ac:      	blr	x8
   155b0:      	ldr	x8, [sp, #0x98]
   155b4:      	cmp	x8, x21
   155b8:      	b.eq	0x15684 <generic_kprobe_path+0xa854>
   155bc:      	mov	w8, #0x4                // =4
   155c0:      	add	x9, sp, #0x78
   155c4:      	add	x0, sp, #0x78
   155c8:      	mov	w1, #0x8                // =8
   155cc:      	mov	x2, x23
   155d0:      	blr	x8
   155d4:      	add	x2, x21, #0x20
   155d8:      	mov	w8, #0x4                // =4
   155dc:      	mov	w9, #0x10               // =16
   155e0:      	add	x10, sp, #0x80
   155e4:      	add	x0, sp, #0x80
   155e8:      	mov	w1, #0x10               // =16
   155ec:      	blr	x8
   155f0:      	ldr	w21, [sp, #0x84]
   155f4:      	ldr	x8, [sp, #0x40]
   155f8:      	ldr	x10, [sp, #0x60]
   155fc:      	sub	x12, x10, x8
   15600:      	ldr	w23, [sp, #0x68]
   15604:      	subs	w10, w21, w23
   15608:      	ldr	x9, [sp, #0x88]
   1560c:      	ldr	x25, [sp, #0x8]
   15610:      	csel	w10, wzr, w10, lo
   15614:      	cmp	w23, w21
   15618:      	csel	w11, w23, w21, lo
   1561c:      	cinc	w13, w11, hi
   15620:      	sub	w14, w23, w13
   15624:      	subs	x12, x12, x13
   15628:      	str	w14, [sp, #0x68]
   1562c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   15630:      	cmp	x12, #0xfff
   15634:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   15638:      	cmp	w23, w21
   1563c:      	b.ls	0x15648 <generic_kprobe_path+0xa818>
   15640:      	mov	w13, #0x2f              // =47
   15644:      	strb	w13, [x8, x12]
   15648:      	add	x19, x8, x12
   1564c:      	cmp	w23, w21
   15650:      	add	x2, x9, x10
   15654:      	and	w1, w11, #0xff
   15658:      	mov	w8, #0x4                // =4
   1565c:      	cinc	x0, x19, hi
   15660:      	blr	x8
   15664:      	ldr	x25, [sp, #0x8]
   15668:      	cmp	w23, w21
   1566c:      	str	x19, [sp, #0x60]
   15670:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   15674:      	ldr	x21, [sp, #0x78]
   15678:      	ldp	x2, x24, [sp, #0x50]
   1567c:      	str	x21, [sp, #0x48]
   15680:      	b	0x156d4 <generic_kprobe_path+0xa8a4>
   15684:      	add	x2, x24, #0x10
   15688:      	mov	w8, #0x4                // =4
   1568c:      	add	x9, sp, #0x98
   15690:      	add	x0, sp, #0x98
   15694:      	mov	w1, #0x8                // =8
   15698:      	blr	x8
   1569c:      	ldr	x8, [sp, #0x58]
   156a0:      	ldr	x9, [sp, #0x98]
   156a4:      	cmp	x8, x9
   156a8:      	ldr	x25, [sp, #0x8]
   156ac:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   156b0:      	add	x2, x24, #0x18
   156b4:      	mov	w8, #0x4                // =4
   156b8:      	mov	x0, x22
   156bc:      	mov	w1, #0x8                // =8
   156c0:      	blr	x8
   156c4:      	ldr	x24, [sp, #0x98]
   156c8:      	ldr	x21, [sp, #0x48]
   156cc:      	add	x2, x24, #0x20
   156d0:      	stp	x2, x24, [sp, #0x50]
   156d4:      	ldr	x8, [sp, #0x30]
   156d8:      	ldr	x25, [sp, #0x8]
   156dc:      	add	x9, sp, #0x70
   156e0:      	cmp	x21, x8
   156e4:      	b.ne	0x156f4 <generic_kprobe_path+0xa8c4>
   156e8:      	ldr	x8, [sp, #0x38]
   156ec:      	cmp	x2, x8
   156f0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   156f4:      	mov	w8, #0x4                // =4
   156f8:      	add	x0, sp, #0x70
   156fc:      	mov	w1, #0x8                // =8
   15700:      	blr	x8
   15704:      	ldr	x8, [sp, #0x70]
   15708:      	cmp	x21, x8
   1570c:      	b.eq	0x15800 <generic_kprobe_path+0xa9d0>
   15710:      	add	x23, x21, #0x18
   15714:      	mov	w8, #0x4                // =4
   15718:      	add	x9, sp, #0x98
   1571c:      	add	x0, sp, #0x98
   15720:      	mov	w1, #0x8                // =8
   15724:      	mov	x2, x23
   15728:      	blr	x8
   1572c:      	ldr	x8, [sp, #0x98]
   15730:      	cmp	x8, x21
   15734:      	b.eq	0x15800 <generic_kprobe_path+0xa9d0>
   15738:      	mov	w8, #0x4                // =4
   1573c:      	add	x9, sp, #0x78
   15740:      	add	x0, sp, #0x78
   15744:      	mov	w1, #0x8                // =8
   15748:      	mov	x2, x23
   1574c:      	blr	x8
   15750:      	add	x2, x21, #0x20
   15754:      	mov	w8, #0x4                // =4
   15758:      	mov	w9, #0x10               // =16
   1575c:      	add	x10, sp, #0x80
   15760:      	add	x0, sp, #0x80
   15764:      	mov	w1, #0x10               // =16
   15768:      	blr	x8
   1576c:      	ldr	w21, [sp, #0x84]
   15770:      	ldr	x8, [sp, #0x40]
   15774:      	ldr	x10, [sp, #0x60]
   15778:      	sub	x12, x10, x8
   1577c:      	ldr	w23, [sp, #0x68]
   15780:      	subs	w10, w21, w23
   15784:      	ldr	x9, [sp, #0x88]
   15788:      	ldr	x25, [sp, #0x8]
   1578c:      	csel	w10, wzr, w10, lo
   15790:      	cmp	w23, w21
   15794:      	csel	w11, w23, w21, lo
   15798:      	cinc	w13, w11, hi
   1579c:      	sub	w14, w23, w13
   157a0:      	subs	x12, x12, x13
   157a4:      	str	w14, [sp, #0x68]
   157a8:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   157ac:      	cmp	x12, #0xfff
   157b0:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   157b4:      	cmp	w23, w21
   157b8:      	b.ls	0x157c4 <generic_kprobe_path+0xa994>
   157bc:      	mov	w13, #0x2f              // =47
   157c0:      	strb	w13, [x8, x12]
   157c4:      	add	x19, x8, x12
   157c8:      	cmp	w23, w21
   157cc:      	add	x2, x9, x10
   157d0:      	and	w1, w11, #0xff
   157d4:      	mov	w8, #0x4                // =4
   157d8:      	cinc	x0, x19, hi
   157dc:      	blr	x8
   157e0:      	ldr	x25, [sp, #0x8]
   157e4:      	cmp	w23, w21
   157e8:      	str	x19, [sp, #0x60]
   157ec:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   157f0:      	ldr	x21, [sp, #0x78]
   157f4:      	ldp	x2, x24, [sp, #0x50]
   157f8:      	str	x21, [sp, #0x48]
   157fc:      	b	0x15850 <generic_kprobe_path+0xaa20>
   15800:      	add	x2, x24, #0x10
   15804:      	mov	w8, #0x4                // =4
   15808:      	add	x9, sp, #0x98
   1580c:      	add	x0, sp, #0x98
   15810:      	mov	w1, #0x8                // =8
   15814:      	blr	x8
   15818:      	ldr	x8, [sp, #0x58]
   1581c:      	ldr	x9, [sp, #0x98]
   15820:      	cmp	x8, x9
   15824:      	ldr	x25, [sp, #0x8]
   15828:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1582c:      	add	x2, x24, #0x18
   15830:      	mov	w8, #0x4                // =4
   15834:      	mov	x0, x22
   15838:      	mov	w1, #0x8                // =8
   1583c:      	blr	x8
   15840:      	ldr	x24, [sp, #0x98]
   15844:      	ldr	x21, [sp, #0x48]
   15848:      	add	x2, x24, #0x20
   1584c:      	stp	x2, x24, [sp, #0x50]
   15850:      	ldr	x8, [sp, #0x30]
   15854:      	ldr	x25, [sp, #0x8]
   15858:      	add	x9, sp, #0x70
   1585c:      	cmp	x21, x8
   15860:      	b.ne	0x15870 <generic_kprobe_path+0xaa40>
   15864:      	ldr	x8, [sp, #0x38]
   15868:      	cmp	x2, x8
   1586c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   15870:      	mov	w8, #0x4                // =4
   15874:      	add	x0, sp, #0x70
   15878:      	mov	w1, #0x8                // =8
   1587c:      	blr	x8
   15880:      	ldr	x8, [sp, #0x70]
   15884:      	cmp	x21, x8
   15888:      	b.eq	0x1597c <generic_kprobe_path+0xab4c>
   1588c:      	add	x23, x21, #0x18
   15890:      	mov	w8, #0x4                // =4
   15894:      	add	x9, sp, #0x98
   15898:      	add	x0, sp, #0x98
   1589c:      	mov	w1, #0x8                // =8
   158a0:      	mov	x2, x23
   158a4:      	blr	x8
   158a8:      	ldr	x8, [sp, #0x98]
   158ac:      	cmp	x8, x21
   158b0:      	b.eq	0x1597c <generic_kprobe_path+0xab4c>
   158b4:      	mov	w8, #0x4                // =4
   158b8:      	add	x9, sp, #0x78
   158bc:      	add	x0, sp, #0x78
   158c0:      	mov	w1, #0x8                // =8
   158c4:      	mov	x2, x23
   158c8:      	blr	x8
   158cc:      	add	x2, x21, #0x20
   158d0:      	mov	w8, #0x4                // =4
   158d4:      	mov	w9, #0x10               // =16
   158d8:      	add	x10, sp, #0x80
   158dc:      	add	x0, sp, #0x80
   158e0:      	mov	w1, #0x10               // =16
   158e4:      	blr	x8
   158e8:      	ldr	w21, [sp, #0x84]
   158ec:      	ldr	x8, [sp, #0x40]
   158f0:      	ldr	x10, [sp, #0x60]
   158f4:      	sub	x12, x10, x8
   158f8:      	ldr	w23, [sp, #0x68]
   158fc:      	subs	w10, w21, w23
   15900:      	ldr	x9, [sp, #0x88]
   15904:      	ldr	x25, [sp, #0x8]
   15908:      	csel	w10, wzr, w10, lo
   1590c:      	cmp	w23, w21
   15910:      	csel	w11, w23, w21, lo
   15914:      	cinc	w13, w11, hi
   15918:      	sub	w14, w23, w13
   1591c:      	subs	x12, x12, x13
   15920:      	str	w14, [sp, #0x68]
   15924:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   15928:      	cmp	x12, #0xfff
   1592c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   15930:      	cmp	w23, w21
   15934:      	b.ls	0x15940 <generic_kprobe_path+0xab10>
   15938:      	mov	w13, #0x2f              // =47
   1593c:      	strb	w13, [x8, x12]
   15940:      	add	x19, x8, x12
   15944:      	cmp	w23, w21
   15948:      	add	x2, x9, x10
   1594c:      	and	w1, w11, #0xff
   15950:      	mov	w8, #0x4                // =4
   15954:      	cinc	x0, x19, hi
   15958:      	blr	x8
   1595c:      	ldr	x25, [sp, #0x8]
   15960:      	cmp	w23, w21
   15964:      	str	x19, [sp, #0x60]
   15968:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   1596c:      	ldr	x21, [sp, #0x78]
   15970:      	ldp	x2, x24, [sp, #0x50]
   15974:      	str	x21, [sp, #0x48]
   15978:      	b	0x159cc <generic_kprobe_path+0xab9c>
   1597c:      	add	x2, x24, #0x10
   15980:      	mov	w8, #0x4                // =4
   15984:      	add	x9, sp, #0x98
   15988:      	add	x0, sp, #0x98
   1598c:      	mov	w1, #0x8                // =8
   15990:      	blr	x8
   15994:      	ldr	x8, [sp, #0x58]
   15998:      	ldr	x9, [sp, #0x98]
   1599c:      	cmp	x8, x9
   159a0:      	ldr	x25, [sp, #0x8]
   159a4:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   159a8:      	add	x2, x24, #0x18
   159ac:      	mov	w8, #0x4                // =4
   159b0:      	mov	x0, x22
   159b4:      	mov	w1, #0x8                // =8
   159b8:      	blr	x8
   159bc:      	ldr	x24, [sp, #0x98]
   159c0:      	ldr	x21, [sp, #0x48]
   159c4:      	add	x2, x24, #0x20
   159c8:      	stp	x2, x24, [sp, #0x50]
   159cc:      	ldr	x8, [sp, #0x30]
   159d0:      	ldr	x25, [sp, #0x8]
   159d4:      	add	x9, sp, #0x70
   159d8:      	cmp	x21, x8
   159dc:      	b.ne	0x159ec <generic_kprobe_path+0xabbc>
   159e0:      	ldr	x8, [sp, #0x38]
   159e4:      	cmp	x2, x8
   159e8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   159ec:      	mov	w8, #0x4                // =4
   159f0:      	add	x0, sp, #0x70
   159f4:      	mov	w1, #0x8                // =8
   159f8:      	blr	x8
   159fc:      	ldr	x8, [sp, #0x70]
   15a00:      	cmp	x21, x8
   15a04:      	b.eq	0x15af8 <generic_kprobe_path+0xacc8>
   15a08:      	add	x23, x21, #0x18
   15a0c:      	mov	w8, #0x4                // =4
   15a10:      	add	x9, sp, #0x98
   15a14:      	add	x0, sp, #0x98
   15a18:      	mov	w1, #0x8                // =8
   15a1c:      	mov	x2, x23
   15a20:      	blr	x8
   15a24:      	ldr	x8, [sp, #0x98]
   15a28:      	cmp	x8, x21
   15a2c:      	b.eq	0x15af8 <generic_kprobe_path+0xacc8>
   15a30:      	mov	w8, #0x4                // =4
   15a34:      	add	x9, sp, #0x78
   15a38:      	add	x0, sp, #0x78
   15a3c:      	mov	w1, #0x8                // =8
   15a40:      	mov	x2, x23
   15a44:      	blr	x8
   15a48:      	add	x2, x21, #0x20
   15a4c:      	mov	w8, #0x4                // =4
   15a50:      	mov	w9, #0x10               // =16
   15a54:      	add	x10, sp, #0x80
   15a58:      	add	x0, sp, #0x80
   15a5c:      	mov	w1, #0x10               // =16
   15a60:      	blr	x8
   15a64:      	ldr	w21, [sp, #0x84]
   15a68:      	ldr	x8, [sp, #0x40]
   15a6c:      	ldr	x10, [sp, #0x60]
   15a70:      	sub	x12, x10, x8
   15a74:      	ldr	w23, [sp, #0x68]
   15a78:      	subs	w10, w21, w23
   15a7c:      	ldr	x9, [sp, #0x88]
   15a80:      	ldr	x25, [sp, #0x8]
   15a84:      	csel	w10, wzr, w10, lo
   15a88:      	cmp	w23, w21
   15a8c:      	csel	w11, w23, w21, lo
   15a90:      	cinc	w13, w11, hi
   15a94:      	sub	w14, w23, w13
   15a98:      	subs	x12, x12, x13
   15a9c:      	str	w14, [sp, #0x68]
   15aa0:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   15aa4:      	cmp	x12, #0xfff
   15aa8:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   15aac:      	cmp	w23, w21
   15ab0:      	b.ls	0x15abc <generic_kprobe_path+0xac8c>
   15ab4:      	mov	w13, #0x2f              // =47
   15ab8:      	strb	w13, [x8, x12]
   15abc:      	add	x19, x8, x12
   15ac0:      	cmp	w23, w21
   15ac4:      	add	x2, x9, x10
   15ac8:      	and	w1, w11, #0xff
   15acc:      	mov	w8, #0x4                // =4
   15ad0:      	cinc	x0, x19, hi
   15ad4:      	blr	x8
   15ad8:      	ldr	x25, [sp, #0x8]
   15adc:      	cmp	w23, w21
   15ae0:      	str	x19, [sp, #0x60]
   15ae4:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   15ae8:      	ldr	x21, [sp, #0x78]
   15aec:      	ldp	x2, x24, [sp, #0x50]
   15af0:      	str	x21, [sp, #0x48]
   15af4:      	b	0x15b48 <generic_kprobe_path+0xad18>
   15af8:      	add	x2, x24, #0x10
   15afc:      	mov	w8, #0x4                // =4
   15b00:      	add	x9, sp, #0x98
   15b04:      	add	x0, sp, #0x98
   15b08:      	mov	w1, #0x8                // =8
   15b0c:      	blr	x8
   15b10:      	ldr	x8, [sp, #0x58]
   15b14:      	ldr	x9, [sp, #0x98]
   15b18:      	cmp	x8, x9
   15b1c:      	ldr	x25, [sp, #0x8]
   15b20:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   15b24:      	add	x2, x24, #0x18
   15b28:      	mov	w8, #0x4                // =4
   15b2c:      	mov	x0, x22
   15b30:      	mov	w1, #0x8                // =8
   15b34:      	blr	x8
   15b38:      	ldr	x24, [sp, #0x98]
   15b3c:      	ldr	x21, [sp, #0x48]
   15b40:      	add	x2, x24, #0x20
   15b44:      	stp	x2, x24, [sp, #0x50]
   15b48:      	ldr	x8, [sp, #0x30]
   15b4c:      	ldr	x25, [sp, #0x8]
   15b50:      	add	x9, sp, #0x70
   15b54:      	cmp	x21, x8
   15b58:      	b.ne	0x15b68 <generic_kprobe_path+0xad38>
   15b5c:      	ldr	x8, [sp, #0x38]
   15b60:      	cmp	x2, x8
   15b64:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   15b68:      	mov	w8, #0x4                // =4
   15b6c:      	add	x0, sp, #0x70
   15b70:      	mov	w1, #0x8                // =8
   15b74:      	blr	x8
   15b78:      	ldr	x8, [sp, #0x70]
   15b7c:      	cmp	x21, x8
   15b80:      	b.eq	0x15c74 <generic_kprobe_path+0xae44>
   15b84:      	add	x23, x21, #0x18
   15b88:      	mov	w8, #0x4                // =4
   15b8c:      	add	x9, sp, #0x98
   15b90:      	add	x0, sp, #0x98
   15b94:      	mov	w1, #0x8                // =8
   15b98:      	mov	x2, x23
   15b9c:      	blr	x8
   15ba0:      	ldr	x8, [sp, #0x98]
   15ba4:      	cmp	x8, x21
   15ba8:      	b.eq	0x15c74 <generic_kprobe_path+0xae44>
   15bac:      	mov	w8, #0x4                // =4
   15bb0:      	add	x9, sp, #0x78
   15bb4:      	add	x0, sp, #0x78
   15bb8:      	mov	w1, #0x8                // =8
   15bbc:      	mov	x2, x23
   15bc0:      	blr	x8
   15bc4:      	add	x2, x21, #0x20
   15bc8:      	mov	w8, #0x4                // =4
   15bcc:      	mov	w9, #0x10               // =16
   15bd0:      	add	x10, sp, #0x80
   15bd4:      	add	x0, sp, #0x80
   15bd8:      	mov	w1, #0x10               // =16
   15bdc:      	blr	x8
   15be0:      	ldr	w21, [sp, #0x84]
   15be4:      	ldr	x8, [sp, #0x40]
   15be8:      	ldr	x10, [sp, #0x60]
   15bec:      	sub	x12, x10, x8
   15bf0:      	ldr	w23, [sp, #0x68]
   15bf4:      	subs	w10, w21, w23
   15bf8:      	ldr	x9, [sp, #0x88]
   15bfc:      	ldr	x25, [sp, #0x8]
   15c00:      	csel	w10, wzr, w10, lo
   15c04:      	cmp	w23, w21
   15c08:      	csel	w11, w23, w21, lo
   15c0c:      	cinc	w13, w11, hi
   15c10:      	sub	w14, w23, w13
   15c14:      	subs	x12, x12, x13
   15c18:      	str	w14, [sp, #0x68]
   15c1c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   15c20:      	cmp	x12, #0xfff
   15c24:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   15c28:      	cmp	w23, w21
   15c2c:      	b.ls	0x15c38 <generic_kprobe_path+0xae08>
   15c30:      	mov	w13, #0x2f              // =47
   15c34:      	strb	w13, [x8, x12]
   15c38:      	add	x19, x8, x12
   15c3c:      	cmp	w23, w21
   15c40:      	add	x2, x9, x10
   15c44:      	and	w1, w11, #0xff
   15c48:      	mov	w8, #0x4                // =4
   15c4c:      	cinc	x0, x19, hi
   15c50:      	blr	x8
   15c54:      	ldr	x25, [sp, #0x8]
   15c58:      	cmp	w23, w21
   15c5c:      	str	x19, [sp, #0x60]
   15c60:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   15c64:      	ldr	x21, [sp, #0x78]
   15c68:      	ldp	x2, x24, [sp, #0x50]
   15c6c:      	str	x21, [sp, #0x48]
   15c70:      	b	0x15cc4 <generic_kprobe_path+0xae94>
   15c74:      	add	x2, x24, #0x10
   15c78:      	mov	w8, #0x4                // =4
   15c7c:      	add	x9, sp, #0x98
   15c80:      	add	x0, sp, #0x98
   15c84:      	mov	w1, #0x8                // =8
   15c88:      	blr	x8
   15c8c:      	ldr	x8, [sp, #0x58]
   15c90:      	ldr	x9, [sp, #0x98]
   15c94:      	cmp	x8, x9
   15c98:      	ldr	x25, [sp, #0x8]
   15c9c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   15ca0:      	add	x2, x24, #0x18
   15ca4:      	mov	w8, #0x4                // =4
   15ca8:      	mov	x0, x22
   15cac:      	mov	w1, #0x8                // =8
   15cb0:      	blr	x8
   15cb4:      	ldr	x24, [sp, #0x98]
   15cb8:      	ldr	x21, [sp, #0x48]
   15cbc:      	add	x2, x24, #0x20
   15cc0:      	stp	x2, x24, [sp, #0x50]
   15cc4:      	ldr	x8, [sp, #0x30]
   15cc8:      	ldr	x25, [sp, #0x8]
   15ccc:      	add	x9, sp, #0x70
   15cd0:      	cmp	x21, x8
   15cd4:      	b.ne	0x15ce4 <generic_kprobe_path+0xaeb4>
   15cd8:      	ldr	x8, [sp, #0x38]
   15cdc:      	cmp	x2, x8
   15ce0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   15ce4:      	mov	w8, #0x4                // =4
   15ce8:      	add	x0, sp, #0x70
   15cec:      	mov	w1, #0x8                // =8
   15cf0:      	blr	x8
   15cf4:      	ldr	x8, [sp, #0x70]
   15cf8:      	cmp	x21, x8
   15cfc:      	b.eq	0x15df0 <generic_kprobe_path+0xafc0>
   15d00:      	add	x23, x21, #0x18
   15d04:      	mov	w8, #0x4                // =4
   15d08:      	add	x9, sp, #0x98
   15d0c:      	add	x0, sp, #0x98
   15d10:      	mov	w1, #0x8                // =8
   15d14:      	mov	x2, x23
   15d18:      	blr	x8
   15d1c:      	ldr	x8, [sp, #0x98]
   15d20:      	cmp	x8, x21
   15d24:      	b.eq	0x15df0 <generic_kprobe_path+0xafc0>
   15d28:      	mov	w8, #0x4                // =4
   15d2c:      	add	x9, sp, #0x78
   15d30:      	add	x0, sp, #0x78
   15d34:      	mov	w1, #0x8                // =8
   15d38:      	mov	x2, x23
   15d3c:      	blr	x8
   15d40:      	add	x2, x21, #0x20
   15d44:      	mov	w8, #0x4                // =4
   15d48:      	mov	w9, #0x10               // =16
   15d4c:      	add	x10, sp, #0x80
   15d50:      	add	x0, sp, #0x80
   15d54:      	mov	w1, #0x10               // =16
   15d58:      	blr	x8
   15d5c:      	ldr	w21, [sp, #0x84]
   15d60:      	ldr	x8, [sp, #0x40]
   15d64:      	ldr	x10, [sp, #0x60]
   15d68:      	sub	x12, x10, x8
   15d6c:      	ldr	w23, [sp, #0x68]
   15d70:      	subs	w10, w21, w23
   15d74:      	ldr	x9, [sp, #0x88]
   15d78:      	ldr	x25, [sp, #0x8]
   15d7c:      	csel	w10, wzr, w10, lo
   15d80:      	cmp	w23, w21
   15d84:      	csel	w11, w23, w21, lo
   15d88:      	cinc	w13, w11, hi
   15d8c:      	sub	w14, w23, w13
   15d90:      	subs	x12, x12, x13
   15d94:      	str	w14, [sp, #0x68]
   15d98:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   15d9c:      	cmp	x12, #0xfff
   15da0:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   15da4:      	cmp	w23, w21
   15da8:      	b.ls	0x15db4 <generic_kprobe_path+0xaf84>
   15dac:      	mov	w13, #0x2f              // =47
   15db0:      	strb	w13, [x8, x12]
   15db4:      	add	x19, x8, x12
   15db8:      	cmp	w23, w21
   15dbc:      	add	x2, x9, x10
   15dc0:      	and	w1, w11, #0xff
   15dc4:      	mov	w8, #0x4                // =4
   15dc8:      	cinc	x0, x19, hi
   15dcc:      	blr	x8
   15dd0:      	ldr	x25, [sp, #0x8]
   15dd4:      	cmp	w23, w21
   15dd8:      	str	x19, [sp, #0x60]
   15ddc:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   15de0:      	ldr	x21, [sp, #0x78]
   15de4:      	ldp	x2, x24, [sp, #0x50]
   15de8:      	str	x21, [sp, #0x48]
   15dec:      	b	0x15e40 <generic_kprobe_path+0xb010>
   15df0:      	add	x2, x24, #0x10
   15df4:      	mov	w8, #0x4                // =4
   15df8:      	add	x9, sp, #0x98
   15dfc:      	add	x0, sp, #0x98
   15e00:      	mov	w1, #0x8                // =8
   15e04:      	blr	x8
   15e08:      	ldr	x8, [sp, #0x58]
   15e0c:      	ldr	x9, [sp, #0x98]
   15e10:      	cmp	x8, x9
   15e14:      	ldr	x25, [sp, #0x8]
   15e18:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   15e1c:      	add	x2, x24, #0x18
   15e20:      	mov	w8, #0x4                // =4
   15e24:      	mov	x0, x22
   15e28:      	mov	w1, #0x8                // =8
   15e2c:      	blr	x8
   15e30:      	ldr	x24, [sp, #0x98]
   15e34:      	ldr	x21, [sp, #0x48]
   15e38:      	add	x2, x24, #0x20
   15e3c:      	stp	x2, x24, [sp, #0x50]
   15e40:      	ldr	x8, [sp, #0x30]
   15e44:      	ldr	x25, [sp, #0x8]
   15e48:      	add	x9, sp, #0x70
   15e4c:      	cmp	x21, x8
   15e50:      	b.ne	0x15e60 <generic_kprobe_path+0xb030>
   15e54:      	ldr	x8, [sp, #0x38]
   15e58:      	cmp	x2, x8
   15e5c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   15e60:      	mov	w8, #0x4                // =4
   15e64:      	add	x0, sp, #0x70
   15e68:      	mov	w1, #0x8                // =8
   15e6c:      	blr	x8
   15e70:      	ldr	x8, [sp, #0x70]
   15e74:      	cmp	x21, x8
   15e78:      	b.eq	0x15f6c <generic_kprobe_path+0xb13c>
   15e7c:      	add	x23, x21, #0x18
   15e80:      	mov	w8, #0x4                // =4
   15e84:      	add	x9, sp, #0x98
   15e88:      	add	x0, sp, #0x98
   15e8c:      	mov	w1, #0x8                // =8
   15e90:      	mov	x2, x23
   15e94:      	blr	x8
   15e98:      	ldr	x8, [sp, #0x98]
   15e9c:      	cmp	x8, x21
   15ea0:      	b.eq	0x15f6c <generic_kprobe_path+0xb13c>
   15ea4:      	mov	w8, #0x4                // =4
   15ea8:      	add	x9, sp, #0x78
   15eac:      	add	x0, sp, #0x78
   15eb0:      	mov	w1, #0x8                // =8
   15eb4:      	mov	x2, x23
   15eb8:      	blr	x8
   15ebc:      	add	x2, x21, #0x20
   15ec0:      	mov	w8, #0x4                // =4
   15ec4:      	mov	w9, #0x10               // =16
   15ec8:      	add	x10, sp, #0x80
   15ecc:      	add	x0, sp, #0x80
   15ed0:      	mov	w1, #0x10               // =16
   15ed4:      	blr	x8
   15ed8:      	ldr	w21, [sp, #0x84]
   15edc:      	ldr	x8, [sp, #0x40]
   15ee0:      	ldr	x10, [sp, #0x60]
   15ee4:      	sub	x12, x10, x8
   15ee8:      	ldr	w23, [sp, #0x68]
   15eec:      	subs	w10, w21, w23
   15ef0:      	ldr	x9, [sp, #0x88]
   15ef4:      	ldr	x25, [sp, #0x8]
   15ef8:      	csel	w10, wzr, w10, lo
   15efc:      	cmp	w23, w21
   15f00:      	csel	w11, w23, w21, lo
   15f04:      	cinc	w13, w11, hi
   15f08:      	sub	w14, w23, w13
   15f0c:      	subs	x12, x12, x13
   15f10:      	str	w14, [sp, #0x68]
   15f14:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   15f18:      	cmp	x12, #0xfff
   15f1c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   15f20:      	cmp	w23, w21
   15f24:      	b.ls	0x15f30 <generic_kprobe_path+0xb100>
   15f28:      	mov	w13, #0x2f              // =47
   15f2c:      	strb	w13, [x8, x12]
   15f30:      	add	x19, x8, x12
   15f34:      	cmp	w23, w21
   15f38:      	add	x2, x9, x10
   15f3c:      	and	w1, w11, #0xff
   15f40:      	mov	w8, #0x4                // =4
   15f44:      	cinc	x0, x19, hi
   15f48:      	blr	x8
   15f4c:      	ldr	x25, [sp, #0x8]
   15f50:      	cmp	w23, w21
   15f54:      	str	x19, [sp, #0x60]
   15f58:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   15f5c:      	ldr	x21, [sp, #0x78]
   15f60:      	ldp	x2, x24, [sp, #0x50]
   15f64:      	str	x21, [sp, #0x48]
   15f68:      	b	0x15fbc <generic_kprobe_path+0xb18c>
   15f6c:      	add	x2, x24, #0x10
   15f70:      	mov	w8, #0x4                // =4
   15f74:      	add	x9, sp, #0x98
   15f78:      	add	x0, sp, #0x98
   15f7c:      	mov	w1, #0x8                // =8
   15f80:      	blr	x8
   15f84:      	ldr	x8, [sp, #0x58]
   15f88:      	ldr	x9, [sp, #0x98]
   15f8c:      	cmp	x8, x9
   15f90:      	ldr	x25, [sp, #0x8]
   15f94:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   15f98:      	add	x2, x24, #0x18
   15f9c:      	mov	w8, #0x4                // =4
   15fa0:      	mov	x0, x22
   15fa4:      	mov	w1, #0x8                // =8
   15fa8:      	blr	x8
   15fac:      	ldr	x24, [sp, #0x98]
   15fb0:      	ldr	x21, [sp, #0x48]
   15fb4:      	add	x2, x24, #0x20
   15fb8:      	stp	x2, x24, [sp, #0x50]
   15fbc:      	ldr	x8, [sp, #0x30]
   15fc0:      	ldr	x25, [sp, #0x8]
   15fc4:      	add	x9, sp, #0x70
   15fc8:      	cmp	x21, x8
   15fcc:      	b.ne	0x15fdc <generic_kprobe_path+0xb1ac>
   15fd0:      	ldr	x8, [sp, #0x38]
   15fd4:      	cmp	x2, x8
   15fd8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   15fdc:      	mov	w8, #0x4                // =4
   15fe0:      	add	x0, sp, #0x70
   15fe4:      	mov	w1, #0x8                // =8
   15fe8:      	blr	x8
   15fec:      	ldr	x8, [sp, #0x70]
   15ff0:      	cmp	x21, x8
   15ff4:      	b.eq	0x160e8 <generic_kprobe_path+0xb2b8>
   15ff8:      	add	x23, x21, #0x18
   15ffc:      	mov	w8, #0x4                // =4
   16000:      	add	x9, sp, #0x98
   16004:      	add	x0, sp, #0x98
   16008:      	mov	w1, #0x8                // =8
   1600c:      	mov	x2, x23
   16010:      	blr	x8
   16014:      	ldr	x8, [sp, #0x98]
   16018:      	cmp	x8, x21
   1601c:      	b.eq	0x160e8 <generic_kprobe_path+0xb2b8>
   16020:      	mov	w8, #0x4                // =4
   16024:      	add	x9, sp, #0x78
   16028:      	add	x0, sp, #0x78
   1602c:      	mov	w1, #0x8                // =8
   16030:      	mov	x2, x23
   16034:      	blr	x8
   16038:      	add	x2, x21, #0x20
   1603c:      	mov	w8, #0x4                // =4
   16040:      	mov	w9, #0x10               // =16
   16044:      	add	x10, sp, #0x80
   16048:      	add	x0, sp, #0x80
   1604c:      	mov	w1, #0x10               // =16
   16050:      	blr	x8
   16054:      	ldr	w21, [sp, #0x84]
   16058:      	ldr	x8, [sp, #0x40]
   1605c:      	ldr	x10, [sp, #0x60]
   16060:      	sub	x12, x10, x8
   16064:      	ldr	w23, [sp, #0x68]
   16068:      	subs	w10, w21, w23
   1606c:      	ldr	x9, [sp, #0x88]
   16070:      	ldr	x25, [sp, #0x8]
   16074:      	csel	w10, wzr, w10, lo
   16078:      	cmp	w23, w21
   1607c:      	csel	w11, w23, w21, lo
   16080:      	cinc	w13, w11, hi
   16084:      	sub	w14, w23, w13
   16088:      	subs	x12, x12, x13
   1608c:      	str	w14, [sp, #0x68]
   16090:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   16094:      	cmp	x12, #0xfff
   16098:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   1609c:      	cmp	w23, w21
   160a0:      	b.ls	0x160ac <generic_kprobe_path+0xb27c>
   160a4:      	mov	w13, #0x2f              // =47
   160a8:      	strb	w13, [x8, x12]
   160ac:      	add	x19, x8, x12
   160b0:      	cmp	w23, w21
   160b4:      	add	x2, x9, x10
   160b8:      	and	w1, w11, #0xff
   160bc:      	mov	w8, #0x4                // =4
   160c0:      	cinc	x0, x19, hi
   160c4:      	blr	x8
   160c8:      	ldr	x25, [sp, #0x8]
   160cc:      	cmp	w23, w21
   160d0:      	str	x19, [sp, #0x60]
   160d4:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   160d8:      	ldr	x21, [sp, #0x78]
   160dc:      	ldp	x2, x24, [sp, #0x50]
   160e0:      	str	x21, [sp, #0x48]
   160e4:      	b	0x16138 <generic_kprobe_path+0xb308>
   160e8:      	add	x2, x24, #0x10
   160ec:      	mov	w8, #0x4                // =4
   160f0:      	add	x9, sp, #0x98
   160f4:      	add	x0, sp, #0x98
   160f8:      	mov	w1, #0x8                // =8
   160fc:      	blr	x8
   16100:      	ldr	x8, [sp, #0x58]
   16104:      	ldr	x9, [sp, #0x98]
   16108:      	cmp	x8, x9
   1610c:      	ldr	x25, [sp, #0x8]
   16110:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   16114:      	add	x2, x24, #0x18
   16118:      	mov	w8, #0x4                // =4
   1611c:      	mov	x0, x22
   16120:      	mov	w1, #0x8                // =8
   16124:      	blr	x8
   16128:      	ldr	x24, [sp, #0x98]
   1612c:      	ldr	x21, [sp, #0x48]
   16130:      	add	x2, x24, #0x20
   16134:      	stp	x2, x24, [sp, #0x50]
   16138:      	ldr	x8, [sp, #0x30]
   1613c:      	ldr	x25, [sp, #0x8]
   16140:      	add	x9, sp, #0x70
   16144:      	cmp	x21, x8
   16148:      	b.ne	0x16158 <generic_kprobe_path+0xb328>
   1614c:      	ldr	x8, [sp, #0x38]
   16150:      	cmp	x2, x8
   16154:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   16158:      	mov	w8, #0x4                // =4
   1615c:      	add	x0, sp, #0x70
   16160:      	mov	w1, #0x8                // =8
   16164:      	blr	x8
   16168:      	ldr	x8, [sp, #0x70]
   1616c:      	cmp	x21, x8
   16170:      	b.eq	0x16264 <generic_kprobe_path+0xb434>
   16174:      	add	x23, x21, #0x18
   16178:      	mov	w8, #0x4                // =4
   1617c:      	add	x9, sp, #0x98
   16180:      	add	x0, sp, #0x98
   16184:      	mov	w1, #0x8                // =8
   16188:      	mov	x2, x23
   1618c:      	blr	x8
   16190:      	ldr	x8, [sp, #0x98]
   16194:      	cmp	x8, x21
   16198:      	b.eq	0x16264 <generic_kprobe_path+0xb434>
   1619c:      	mov	w8, #0x4                // =4
   161a0:      	add	x9, sp, #0x78
   161a4:      	add	x0, sp, #0x78
   161a8:      	mov	w1, #0x8                // =8
   161ac:      	mov	x2, x23
   161b0:      	blr	x8
   161b4:      	add	x2, x21, #0x20
   161b8:      	mov	w8, #0x4                // =4
   161bc:      	mov	w9, #0x10               // =16
   161c0:      	add	x10, sp, #0x80
   161c4:      	add	x0, sp, #0x80
   161c8:      	mov	w1, #0x10               // =16
   161cc:      	blr	x8
   161d0:      	ldr	w21, [sp, #0x84]
   161d4:      	ldr	x8, [sp, #0x40]
   161d8:      	ldr	x10, [sp, #0x60]
   161dc:      	sub	x12, x10, x8
   161e0:      	ldr	w23, [sp, #0x68]
   161e4:      	subs	w10, w21, w23
   161e8:      	ldr	x9, [sp, #0x88]
   161ec:      	ldr	x25, [sp, #0x8]
   161f0:      	csel	w10, wzr, w10, lo
   161f4:      	cmp	w23, w21
   161f8:      	csel	w11, w23, w21, lo
   161fc:      	cinc	w13, w11, hi
   16200:      	sub	w14, w23, w13
   16204:      	subs	x12, x12, x13
   16208:      	str	w14, [sp, #0x68]
   1620c:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   16210:      	cmp	x12, #0xfff
   16214:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   16218:      	cmp	w23, w21
   1621c:      	b.ls	0x16228 <generic_kprobe_path+0xb3f8>
   16220:      	mov	w13, #0x2f              // =47
   16224:      	strb	w13, [x8, x12]
   16228:      	add	x19, x8, x12
   1622c:      	cmp	w23, w21
   16230:      	add	x2, x9, x10
   16234:      	and	w1, w11, #0xff
   16238:      	mov	w8, #0x4                // =4
   1623c:      	cinc	x0, x19, hi
   16240:      	blr	x8
   16244:      	ldr	x25, [sp, #0x8]
   16248:      	cmp	w23, w21
   1624c:      	str	x19, [sp, #0x60]
   16250:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   16254:      	ldr	x21, [sp, #0x78]
   16258:      	ldp	x2, x24, [sp, #0x50]
   1625c:      	str	x21, [sp, #0x48]
   16260:      	b	0x162b4 <generic_kprobe_path+0xb484>
   16264:      	add	x2, x24, #0x10
   16268:      	mov	w8, #0x4                // =4
   1626c:      	add	x9, sp, #0x98
   16270:      	add	x0, sp, #0x98
   16274:      	mov	w1, #0x8                // =8
   16278:      	blr	x8
   1627c:      	ldr	x8, [sp, #0x58]
   16280:      	ldr	x9, [sp, #0x98]
   16284:      	cmp	x8, x9
   16288:      	ldr	x25, [sp, #0x8]
   1628c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   16290:      	add	x2, x24, #0x18
   16294:      	mov	w8, #0x4                // =4
   16298:      	mov	x0, x22
   1629c:      	mov	w1, #0x8                // =8
   162a0:      	blr	x8
   162a4:      	ldr	x24, [sp, #0x98]
   162a8:      	ldr	x21, [sp, #0x48]
   162ac:      	add	x2, x24, #0x20
   162b0:      	stp	x2, x24, [sp, #0x50]
   162b4:      	ldr	x8, [sp, #0x30]
   162b8:      	ldr	x25, [sp, #0x8]
   162bc:      	add	x9, sp, #0x70
   162c0:      	cmp	x21, x8
   162c4:      	b.ne	0x162d4 <generic_kprobe_path+0xb4a4>
   162c8:      	ldr	x8, [sp, #0x38]
   162cc:      	cmp	x2, x8
   162d0:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   162d4:      	mov	w8, #0x4                // =4
   162d8:      	add	x0, sp, #0x70
   162dc:      	mov	w1, #0x8                // =8
   162e0:      	blr	x8
   162e4:      	ldr	x8, [sp, #0x70]
   162e8:      	cmp	x21, x8
   162ec:      	b.eq	0x163e0 <generic_kprobe_path+0xb5b0>
   162f0:      	add	x23, x21, #0x18
   162f4:      	mov	w8, #0x4                // =4
   162f8:      	add	x9, sp, #0x98
   162fc:      	add	x0, sp, #0x98
   16300:      	mov	w1, #0x8                // =8
   16304:      	mov	x2, x23
   16308:      	blr	x8
   1630c:      	ldr	x8, [sp, #0x98]
   16310:      	cmp	x8, x21
   16314:      	b.eq	0x163e0 <generic_kprobe_path+0xb5b0>
   16318:      	mov	w8, #0x4                // =4
   1631c:      	add	x9, sp, #0x78
   16320:      	add	x0, sp, #0x78
   16324:      	mov	w1, #0x8                // =8
   16328:      	mov	x2, x23
   1632c:      	blr	x8
   16330:      	add	x2, x21, #0x20
   16334:      	mov	w8, #0x4                // =4
   16338:      	mov	w9, #0x10               // =16
   1633c:      	add	x10, sp, #0x80
   16340:      	add	x0, sp, #0x80
   16344:      	mov	w1, #0x10               // =16
   16348:      	blr	x8
   1634c:      	ldr	w21, [sp, #0x84]
   16350:      	ldr	x8, [sp, #0x40]
   16354:      	ldr	x10, [sp, #0x60]
   16358:      	sub	x12, x10, x8
   1635c:      	ldr	w23, [sp, #0x68]
   16360:      	subs	w10, w21, w23
   16364:      	ldr	x9, [sp, #0x88]
   16368:      	ldr	x25, [sp, #0x8]
   1636c:      	csel	w10, wzr, w10, lo
   16370:      	cmp	w23, w21
   16374:      	csel	w11, w23, w21, lo
   16378:      	cinc	w13, w11, hi
   1637c:      	sub	w14, w23, w13
   16380:      	subs	x12, x12, x13
   16384:      	str	w14, [sp, #0x68]
   16388:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   1638c:      	cmp	x12, #0xfff
   16390:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   16394:      	cmp	w23, w21
   16398:      	b.ls	0x163a4 <generic_kprobe_path+0xb574>
   1639c:      	mov	w13, #0x2f              // =47
   163a0:      	strb	w13, [x8, x12]
   163a4:      	add	x19, x8, x12
   163a8:      	cmp	w23, w21
   163ac:      	add	x2, x9, x10
   163b0:      	and	w1, w11, #0xff
   163b4:      	mov	w8, #0x4                // =4
   163b8:      	cinc	x0, x19, hi
   163bc:      	blr	x8
   163c0:      	ldr	x25, [sp, #0x8]
   163c4:      	cmp	w23, w21
   163c8:      	str	x19, [sp, #0x60]
   163cc:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   163d0:      	ldr	x21, [sp, #0x78]
   163d4:      	ldp	x2, x24, [sp, #0x50]
   163d8:      	str	x21, [sp, #0x48]
   163dc:      	b	0x16430 <generic_kprobe_path+0xb600>
   163e0:      	add	x2, x24, #0x10
   163e4:      	mov	w8, #0x4                // =4
   163e8:      	add	x9, sp, #0x98
   163ec:      	add	x0, sp, #0x98
   163f0:      	mov	w1, #0x8                // =8
   163f4:      	blr	x8
   163f8:      	ldr	x8, [sp, #0x58]
   163fc:      	ldr	x9, [sp, #0x98]
   16400:      	cmp	x8, x9
   16404:      	ldr	x25, [sp, #0x8]
   16408:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1640c:      	add	x2, x24, #0x18
   16410:      	mov	w8, #0x4                // =4
   16414:      	mov	x0, x22
   16418:      	mov	w1, #0x8                // =8
   1641c:      	blr	x8
   16420:      	ldr	x24, [sp, #0x98]
   16424:      	ldr	x21, [sp, #0x48]
   16428:      	add	x2, x24, #0x20
   1642c:      	stp	x2, x24, [sp, #0x50]
   16430:      	ldr	x8, [sp, #0x30]
   16434:      	ldr	x25, [sp, #0x8]
   16438:      	add	x9, sp, #0x70
   1643c:      	cmp	x21, x8
   16440:      	b.ne	0x16450 <generic_kprobe_path+0xb620>
   16444:      	ldr	x8, [sp, #0x38]
   16448:      	cmp	x2, x8
   1644c:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   16450:      	mov	w8, #0x4                // =4
   16454:      	add	x0, sp, #0x70
   16458:      	mov	w1, #0x8                // =8
   1645c:      	blr	x8
   16460:      	ldr	x8, [sp, #0x70]
   16464:      	cmp	x21, x8
   16468:      	b.eq	0x1655c <generic_kprobe_path+0xb72c>
   1646c:      	add	x23, x21, #0x18
   16470:      	mov	w8, #0x4                // =4
   16474:      	add	x9, sp, #0x98
   16478:      	add	x0, sp, #0x98
   1647c:      	mov	w1, #0x8                // =8
   16480:      	mov	x2, x23
   16484:      	blr	x8
   16488:      	ldr	x8, [sp, #0x98]
   1648c:      	cmp	x8, x21
   16490:      	b.eq	0x1655c <generic_kprobe_path+0xb72c>
   16494:      	mov	w8, #0x4                // =4
   16498:      	add	x9, sp, #0x78
   1649c:      	add	x0, sp, #0x78
   164a0:      	mov	w1, #0x8                // =8
   164a4:      	mov	x2, x23
   164a8:      	blr	x8
   164ac:      	add	x2, x21, #0x20
   164b0:      	mov	w8, #0x4                // =4
   164b4:      	mov	w9, #0x10               // =16
   164b8:      	add	x10, sp, #0x80
   164bc:      	add	x0, sp, #0x80
   164c0:      	mov	w1, #0x10               // =16
   164c4:      	blr	x8
   164c8:      	ldr	w21, [sp, #0x84]
   164cc:      	ldr	x8, [sp, #0x40]
   164d0:      	ldr	x10, [sp, #0x60]
   164d4:      	sub	x12, x10, x8
   164d8:      	ldr	w23, [sp, #0x68]
   164dc:      	subs	w10, w21, w23
   164e0:      	ldr	x9, [sp, #0x88]
   164e4:      	ldr	x25, [sp, #0x8]
   164e8:      	csel	w10, wzr, w10, lo
   164ec:      	cmp	w23, w21
   164f0:      	csel	w11, w23, w21, lo
   164f4:      	cinc	w13, w11, hi
   164f8:      	sub	w14, w23, w13
   164fc:      	subs	x12, x12, x13
   16500:      	str	w14, [sp, #0x68]
   16504:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   16508:      	cmp	x12, #0xfff
   1650c:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   16510:      	cmp	w23, w21
   16514:      	b.ls	0x16520 <generic_kprobe_path+0xb6f0>
   16518:      	mov	w13, #0x2f              // =47
   1651c:      	strb	w13, [x8, x12]
   16520:      	add	x19, x8, x12
   16524:      	cmp	w23, w21
   16528:      	add	x2, x9, x10
   1652c:      	and	w1, w11, #0xff
   16530:      	mov	w8, #0x4                // =4
   16534:      	cinc	x0, x19, hi
   16538:      	blr	x8
   1653c:      	ldr	x25, [sp, #0x8]
   16540:      	cmp	w23, w21
   16544:      	str	x19, [sp, #0x60]
   16548:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   1654c:      	ldr	x21, [sp, #0x78]
   16550:      	ldp	x2, x24, [sp, #0x50]
   16554:      	str	x21, [sp, #0x48]
   16558:      	b	0x165ac <generic_kprobe_path+0xb77c>
   1655c:      	add	x2, x24, #0x10
   16560:      	mov	w8, #0x4                // =4
   16564:      	add	x9, sp, #0x98
   16568:      	add	x0, sp, #0x98
   1656c:      	mov	w1, #0x8                // =8
   16570:      	blr	x8
   16574:      	ldr	x8, [sp, #0x58]
   16578:      	ldr	x9, [sp, #0x98]
   1657c:      	cmp	x8, x9
   16580:      	ldr	x25, [sp, #0x8]
   16584:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   16588:      	add	x2, x24, #0x18
   1658c:      	mov	w8, #0x4                // =4
   16590:      	mov	x0, x22
   16594:      	mov	w1, #0x8                // =8
   16598:      	blr	x8
   1659c:      	ldr	x24, [sp, #0x98]
   165a0:      	ldr	x21, [sp, #0x48]
   165a4:      	add	x2, x24, #0x20
   165a8:      	stp	x2, x24, [sp, #0x50]
   165ac:      	ldr	x8, [sp, #0x30]
   165b0:      	ldr	x25, [sp, #0x8]
   165b4:      	add	x9, sp, #0x70
   165b8:      	cmp	x21, x8
   165bc:      	b.ne	0x165cc <generic_kprobe_path+0xb79c>
   165c0:      	ldr	x8, [sp, #0x38]
   165c4:      	cmp	x2, x8
   165c8:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   165cc:      	mov	w8, #0x4                // =4
   165d0:      	add	x0, sp, #0x70
   165d4:      	mov	w1, #0x8                // =8
   165d8:      	blr	x8
   165dc:      	ldr	x8, [sp, #0x70]
   165e0:      	cmp	x21, x8
   165e4:      	b.eq	0x166d8 <generic_kprobe_path+0xb8a8>
   165e8:      	add	x23, x21, #0x18
   165ec:      	mov	w8, #0x4                // =4
   165f0:      	add	x9, sp, #0x98
   165f4:      	add	x0, sp, #0x98
   165f8:      	mov	w1, #0x8                // =8
   165fc:      	mov	x2, x23
   16600:      	blr	x8
   16604:      	ldr	x8, [sp, #0x98]
   16608:      	cmp	x8, x21
   1660c:      	b.eq	0x166d8 <generic_kprobe_path+0xb8a8>
   16610:      	mov	w8, #0x4                // =4
   16614:      	add	x9, sp, #0x78
   16618:      	add	x0, sp, #0x78
   1661c:      	mov	w1, #0x8                // =8
   16620:      	mov	x2, x23
   16624:      	blr	x8
   16628:      	add	x2, x21, #0x20
   1662c:      	mov	w8, #0x4                // =4
   16630:      	mov	w9, #0x10               // =16
   16634:      	add	x10, sp, #0x80
   16638:      	add	x0, sp, #0x80
   1663c:      	mov	w1, #0x10               // =16
   16640:      	blr	x8
   16644:      	ldr	w21, [sp, #0x84]
   16648:      	ldr	x8, [sp, #0x40]
   1664c:      	ldr	x10, [sp, #0x60]
   16650:      	sub	x12, x10, x8
   16654:      	ldr	w23, [sp, #0x68]
   16658:      	subs	w10, w21, w23
   1665c:      	ldr	x9, [sp, #0x88]
   16660:      	ldr	x25, [sp, #0x8]
   16664:      	csel	w10, wzr, w10, lo
   16668:      	cmp	w23, w21
   1666c:      	csel	w11, w23, w21, lo
   16670:      	cinc	w13, w11, hi
   16674:      	sub	w14, w23, w13
   16678:      	subs	x12, x12, x13
   1667c:      	str	w14, [sp, #0x68]
   16680:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   16684:      	cmp	x12, #0xfff
   16688:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   1668c:      	cmp	w23, w21
   16690:      	b.ls	0x1669c <generic_kprobe_path+0xb86c>
   16694:      	mov	w13, #0x2f              // =47
   16698:      	strb	w13, [x8, x12]
   1669c:      	add	x19, x8, x12
   166a0:      	cmp	w23, w21
   166a4:      	add	x2, x9, x10
   166a8:      	and	w1, w11, #0xff
   166ac:      	mov	w8, #0x4                // =4
   166b0:      	cinc	x0, x19, hi
   166b4:      	blr	x8
   166b8:      	ldr	x25, [sp, #0x8]
   166bc:      	cmp	w23, w21
   166c0:      	str	x19, [sp, #0x60]
   166c4:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   166c8:      	ldr	x21, [sp, #0x78]
   166cc:      	ldp	x2, x24, [sp, #0x50]
   166d0:      	str	x21, [sp, #0x48]
   166d4:      	b	0x16728 <generic_kprobe_path+0xb8f8>
   166d8:      	add	x2, x24, #0x10
   166dc:      	mov	w8, #0x4                // =4
   166e0:      	add	x9, sp, #0x98
   166e4:      	add	x0, sp, #0x98
   166e8:      	mov	w1, #0x8                // =8
   166ec:      	blr	x8
   166f0:      	ldr	x8, [sp, #0x58]
   166f4:      	ldr	x9, [sp, #0x98]
   166f8:      	cmp	x8, x9
   166fc:      	ldr	x25, [sp, #0x8]
   16700:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   16704:      	add	x2, x24, #0x18
   16708:      	mov	w8, #0x4                // =4
   1670c:      	mov	x0, x22
   16710:      	mov	w1, #0x8                // =8
   16714:      	blr	x8
   16718:      	ldr	x24, [sp, #0x98]
   1671c:      	ldr	x21, [sp, #0x48]
   16720:      	add	x2, x24, #0x20
   16724:      	stp	x2, x24, [sp, #0x50]
   16728:      	ldr	x8, [sp, #0x30]
   1672c:      	ldr	x25, [sp, #0x8]
   16730:      	add	x9, sp, #0x70
   16734:      	cmp	x21, x8
   16738:      	b.ne	0x16748 <generic_kprobe_path+0xb918>
   1673c:      	ldr	x8, [sp, #0x38]
   16740:      	cmp	x2, x8
   16744:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   16748:      	mov	w8, #0x4                // =4
   1674c:      	add	x0, sp, #0x70
   16750:      	mov	w1, #0x8                // =8
   16754:      	blr	x8
   16758:      	ldr	x8, [sp, #0x70]
   1675c:      	cmp	x21, x8
   16760:      	b.eq	0x16850 <generic_kprobe_path+0xba20>
   16764:      	add	x23, x21, #0x18
   16768:      	mov	w8, #0x4                // =4
   1676c:      	add	x9, sp, #0x98
   16770:      	add	x0, sp, #0x98
   16774:      	mov	w1, #0x8                // =8
   16778:      	mov	x2, x23
   1677c:      	blr	x8
   16780:      	ldr	x8, [sp, #0x98]
   16784:      	cmp	x8, x21
   16788:      	b.eq	0x16850 <generic_kprobe_path+0xba20>
   1678c:      	mov	w8, #0x4                // =4
   16790:      	add	x9, sp, #0x78
   16794:      	add	x0, sp, #0x78
   16798:      	mov	w1, #0x8                // =8
   1679c:      	mov	x2, x23
   167a0:      	blr	x8
   167a4:      	add	x2, x21, #0x20
   167a8:      	mov	w8, #0x4                // =4
   167ac:      	mov	w9, #0x10               // =16
   167b0:      	add	x10, sp, #0x80
   167b4:      	add	x0, sp, #0x80
   167b8:      	mov	w1, #0x10               // =16
   167bc:      	blr	x8
   167c0:      	ldr	w21, [sp, #0x84]
   167c4:      	ldr	x8, [sp, #0x40]
   167c8:      	ldr	x10, [sp, #0x60]
   167cc:      	sub	x12, x10, x8
   167d0:      	ldr	w23, [sp, #0x68]
   167d4:      	subs	w10, w21, w23
   167d8:      	ldr	x9, [sp, #0x88]
   167dc:      	ldr	x25, [sp, #0x8]
   167e0:      	csel	w10, wzr, w10, lo
   167e4:      	cmp	w23, w21
   167e8:      	csel	w11, w23, w21, lo
   167ec:      	cinc	w13, w11, hi
   167f0:      	sub	w14, w23, w13
   167f4:      	subs	x12, x12, x13
   167f8:      	str	w14, [sp, #0x68]
   167fc:      	b.lo	0x168b8 <generic_kprobe_path+0xba88>
   16800:      	cmp	x12, #0xfff
   16804:      	b.hi	0x168b8 <generic_kprobe_path+0xba88>
   16808:      	cmp	w23, w21
   1680c:      	b.ls	0x16818 <generic_kprobe_path+0xb9e8>
   16810:      	mov	w13, #0x2f              // =47
   16814:      	strb	w13, [x8, x12]
   16818:      	add	x19, x8, x12
   1681c:      	cmp	w23, w21
   16820:      	add	x2, x9, x10
   16824:      	and	w1, w11, #0xff
   16828:      	mov	w8, #0x4                // =4
   1682c:      	cinc	x0, x19, hi
   16830:      	blr	x8
   16834:      	ldr	x25, [sp, #0x8]
   16838:      	cmp	w23, w21
   1683c:      	str	x19, [sp, #0x60]
   16840:      	b.ls	0x168b8 <generic_kprobe_path+0xba88>
   16844:      	ldr	x8, [sp, #0x78]
   16848:      	str	x8, [sp, #0x48]
   1684c:      	b	0x1689c <generic_kprobe_path+0xba6c>
   16850:      	add	x2, x24, #0x10
   16854:      	mov	w8, #0x4                // =4
   16858:      	add	x9, sp, #0x98
   1685c:      	add	x0, sp, #0x98
   16860:      	mov	w1, #0x8                // =8
   16864:      	blr	x8
   16868:      	ldr	x8, [sp, #0x58]
   1686c:      	ldr	x9, [sp, #0x98]
   16870:      	cmp	x8, x9
   16874:      	ldr	x25, [sp, #0x8]
   16878:      	b.eq	0x168b0 <generic_kprobe_path+0xba80>
   1687c:      	add	x2, x24, #0x18
   16880:      	mov	w8, #0x4                // =4
   16884:      	mov	x0, x22
   16888:      	mov	w1, #0x8                // =8
   1688c:      	blr	x8
   16890:      	ldr	x8, [sp, #0x98]
   16894:      	add	x9, x8, #0x20
   16898:      	stp	x9, x8, [sp, #0x50]
   1689c:      	ldr	x25, [sp, #0x8]
   168a0:      	subs	w20, w20, #0x80
   168a4:      	add	x19, sp, #0x70
   168a8:      	b.ne	0xafac <generic_kprobe_path+0x17c>
   168ac:      	b	0x168b8 <generic_kprobe_path+0xba88>
   168b0:      	mov	w8, #0x1                // =1
   168b4:      	strb	w8, [sp, #0x6c]
   168b8:      	ldr	w8, [x25, #0x8]
   168bc:      	ldp	x10, x20, [sp, #0x10]
   168c0:      	add	w8, w8, #0x1
   168c4:      	str	w8, [x25, #0x8]
   168c8:      	ldr	w9, [sp, #0x60]
   168cc:      	sub	w9, w9, w10
   168d0:      	str	w9, [x25, #0x4]
   168d4:      	ldrb	w9, [sp, #0x6c]
   168d8:      	cbnz	w9, 0x16910 <generic_kprobe_path+0xbae0>
   168dc:      	cmp	w8, #0x8
   168e0:      	b.eq	0x16910 <generic_kprobe_path+0xbae0>
   168e4:      	ldp	x8, x9, [sp, #0x48]
   168e8:      	mov	w2, #0x6                // =6
   168ec:      	str	x8, [x20, #0x6458]
   168f0:      	ldr	x8, [sp, #0x58]
   168f4:      	str	x9, [x20, #0x6460]
   168f8:      	adrp	x9, 0x16000 <generic_kprobe_path+0xb1d0>
   168fc:      	str	x8, [x20, #0x6468]
   16900:      	mov	w8, #0xc                // =12
   16904:      	ldr	x9, [x9]
   16908:      	ldr	x0, [sp, #0x20]
   1690c:      	b	0x16924 <generic_kprobe_path+0xbaf4>
   16910:      	adrp	x9, 0x16000 <generic_kprobe_path+0xb1d0>
   16914:      	mov	w2, #0x1                // =1
   16918:      	mov	w8, #0xc                // =12
   1691c:      	ldr	x9, [x9]
   16920:      	ldr	x0, [sp, #0x20]
   16924:      	adrp	x1, 0x16000 <generic_kprobe_path+0xb1d0>
   16928:      	ldr	x1, [x1]
   1692c:      	blr	x8
   16930:      	b	0x16ccc <generic_kprobe_path+0xbe9c>
   16934:      	str	w23, [sp, #0x98]
   16938:      	mov	x3, xzr
   1693c:      	mov	w8, #0x2                // =2
   16940:      	add	x9, sp, #0x30
   16944:      	add	x10, sp, #0x98
   16948:      	add	x1, sp, #0x30
   1694c:      	add	x2, sp, #0x98
   16950:      	mov	x0, x22
   16954:      	blr	x8
   16958:      	ldr	x23, [sp, #0x80]
   1695c:      	mov	w8, #0x8                // =8
   16960:      	mov	w9, #0x4                // =4
   16964:      	add	x10, sp, #0x30
   16968:      	add	x0, sp, #0x30
   1696c:      	mov	w1, #0x8                // =8
   16970:      	add	x2, x23, #0x10
   16974:      	blr	x9
   16978:      	ldr	x8, [sp, #0x30]
   1697c:      	cbnz	x8, 0x169c4 <generic_kprobe_path+0xbb94>
   16980:      	add	x2, x23, #0x18
   16984:      	mov	w8, #0x8                // =8
   16988:      	mov	w9, #0x4                // =4
   1698c:      	add	x10, sp, #0x30
   16990:      	add	x0, sp, #0x30
   16994:      	mov	w1, #0x8                // =8
   16998:      	blr	x9
   1699c:      	ldr	x8, [sp, #0x30]
   169a0:      	cmp	x8, x23
   169a4:      	b.eq	0x169c4 <generic_kprobe_path+0xbb94>
   169a8:      	adrp	x8, 0x16000 <generic_kprobe_path+0xb1d0>
   169ac:      	add	x8, x8, #0x0
   169b0:      	add	x29, x21, #0xff5
   169b4:      	ldr	x8, [x8]
   169b8:      	str	x8, [x29]
   169bc:      	mov	w8, #0x2964             // =10596
   169c0:      	strh	w8, [x29, #0x8]
   169c4:      	mov	w8, #0x23               // =35
   169c8:      	blr	x8
   169cc:      	add	x2, x0, #0xb30
   169d0:      	mov	w8, #0x8                // =8
   169d4:      	mov	w9, #0x4                // =4
   169d8:      	add	x10, sp, #0x98
   169dc:      	add	x0, sp, #0x98
   169e0:      	mov	w1, #0x8                // =8
   169e4:      	blr	x9
   169e8:      	cbz	x0, 0x16a58 <generic_kprobe_path+0xbc28>
   169ec:      	neg	w8, w0
   169f0:      	mov	w9, #0x1                // =1
   169f4:      	add	x1, sp, #0x30
   169f8:      	strh	w8, [sp, #0x30]
   169fc:      	mov	w8, #0x6                // =6
   16a00:      	mov	x0, x22
   16a04:      	mov	w23, #0x1               // =1
   16a08:      	strh	w8, [sp, #0x32]
   16a0c:      	mov	x8, #0x33               // =51
   16a10:      	movk	x8, #0x4, lsl #32
   16a14:      	stur	x8, [sp, #0x34]
   16a18:      	add	x8, sp, #0x30
   16a1c:      	blr	x9
   16a20:      	cbz	x0, 0x16a34 <generic_kprobe_path+0xbc04>
   16a24:      	ldr	w8, [x0]
   16a28:      	add	w8, w8, #0x1
   16a2c:      	str	w8, [x0]
   16a30:      	b	0x16a58 <generic_kprobe_path+0xbc28>
   16a34:      	str	w23, [sp, #0x78]
   16a38:      	mov	x3, xzr
   16a3c:      	mov	w8, #0x2                // =2
   16a40:      	add	x9, sp, #0x30
   16a44:      	add	x10, sp, #0x78
   16a48:      	add	x1, sp, #0x30
   16a4c:      	add	x2, sp, #0x78
   16a50:      	mov	x0, x22
   16a54:      	blr	x8
   16a58:      	ldr	x8, [sp, #0x98]
   16a5c:      	mov	w9, #0x6448             // =25672
   16a60:      	ldr	x23, [x20, #0x6440]
   16a64:      	mov	w1, #0x8                // =8
   16a68:      	add	x0, x20, x9
   16a6c:      	mov	w9, #0x4                // =4
   16a70:      	add	x24, x8, #0x18
   16a74:      	add	x2, x8, #0x20
   16a78:      	mov	w8, #0x8                // =8
   16a7c:      	blr	x9
   16a80:      	cbz	x0, 0x16af0 <generic_kprobe_path+0xbcc0>
   16a84:      	neg	w8, w0
   16a88:      	mov	w9, #0x1                // =1
   16a8c:      	add	x1, sp, #0x30
   16a90:      	strh	w8, [sp, #0x30]
   16a94:      	mov	w8, #0x6                // =6
   16a98:      	mov	x0, x22
   16a9c:      	mov	w19, #0x1               // =1
   16aa0:      	strh	w8, [sp, #0x32]
   16aa4:      	mov	x8, #0x38               // =56
   16aa8:      	movk	x8, #0x4, lsl #32
   16aac:      	stur	x8, [sp, #0x34]
   16ab0:      	add	x8, sp, #0x30
   16ab4:      	blr	x9
   16ab8:      	cbz	x0, 0x16acc <generic_kprobe_path+0xbc9c>
   16abc:      	ldr	w8, [x0]
   16ac0:      	add	w8, w8, #0x1
   16ac4:      	str	w8, [x0]
   16ac8:      	b	0x16af0 <generic_kprobe_path+0xbcc0>
   16acc:      	str	w19, [sp, #0x78]
   16ad0:      	mov	x3, xzr
   16ad4:      	mov	w8, #0x2                // =2
   16ad8:      	add	x9, sp, #0x30
   16adc:      	add	x10, sp, #0x78
   16ae0:      	add	x1, sp, #0x30
   16ae4:      	add	x2, sp, #0x78
   16ae8:      	mov	x0, x22
   16aec:      	blr	x8
   16af0:      	mov	w8, #0x6450             // =25680
   16af4:      	mov	w9, #0x4                // =4
   16af8:      	mov	w1, #0x8                // =8
   16afc:      	mov	x2, x24
   16b00:      	add	x0, x20, x8
   16b04:      	mov	w8, #0x8                // =8
   16b08:      	blr	x9
   16b0c:      	cbz	x0, 0x16b7c <generic_kprobe_path+0xbd4c>
   16b10:      	neg	w8, w0
   16b14:      	mov	w9, #0x1                // =1
   16b18:      	add	x1, sp, #0x30
   16b1c:      	strh	w8, [sp, #0x30]
   16b20:      	mov	w8, #0x6                // =6
   16b24:      	mov	x0, x22
   16b28:      	mov	w19, #0x1               // =1
   16b2c:      	strh	w8, [sp, #0x32]
   16b30:      	mov	x8, #0x39               // =57
   16b34:      	movk	x8, #0x4, lsl #32
   16b38:      	stur	x8, [sp, #0x34]
   16b3c:      	add	x8, sp, #0x30
   16b40:      	blr	x9
   16b44:      	cbz	x0, 0x16b58 <generic_kprobe_path+0xbd28>
   16b48:      	ldr	w8, [x0]
   16b4c:      	add	w8, w8, #0x1
   16b50:      	str	w8, [x0]
   16b54:      	b	0x16b7c <generic_kprobe_path+0xbd4c>
   16b58:      	str	w19, [sp, #0x78]
   16b5c:      	mov	x3, xzr
   16b60:      	mov	w8, #0x2                // =2
   16b64:      	add	x9, sp, #0x30
   16b68:      	add	x10, sp, #0x78
   16b6c:      	add	x1, sp, #0x30
   16b70:      	add	x2, sp, #0x78
   16b74:      	mov	x0, x22
   16b78:      	blr	x8
   16b7c:      	mov	w8, #0x6458             // =25688
   16b80:      	add	x2, x23, #0x8
   16b84:      	mov	w9, #0x4                // =4
   16b88:      	mov	w1, #0x8                // =8
   16b8c:      	add	x0, x20, x8
   16b90:      	mov	w8, #0x8                // =8
   16b94:      	blr	x9
   16b98:      	cbz	x0, 0x16c08 <generic_kprobe_path+0xbdd8>
   16b9c:      	neg	w8, w0
   16ba0:      	mov	w9, #0x1                // =1
   16ba4:      	add	x1, sp, #0x30
   16ba8:      	strh	w8, [sp, #0x30]
   16bac:      	mov	w8, #0x6                // =6
   16bb0:      	mov	x0, x22
   16bb4:      	mov	w19, #0x1               // =1
   16bb8:      	strh	w8, [sp, #0x32]
   16bbc:      	mov	x8, #0x3a               // =58
   16bc0:      	movk	x8, #0x4, lsl #32
   16bc4:      	stur	x8, [sp, #0x34]
   16bc8:      	add	x8, sp, #0x30
   16bcc:      	blr	x9
   16bd0:      	cbz	x0, 0x16be4 <generic_kprobe_path+0xbdb4>
   16bd4:      	ldr	w8, [x0]
   16bd8:      	add	w8, w8, #0x1
   16bdc:      	str	w8, [x0]
   16be0:      	b	0x16c08 <generic_kprobe_path+0xbdd8>
   16be4:      	str	w19, [sp, #0x78]
   16be8:      	mov	x3, xzr
   16bec:      	mov	w8, #0x2                // =2
   16bf0:      	add	x9, sp, #0x30
   16bf4:      	add	x10, sp, #0x78
   16bf8:      	add	x1, sp, #0x30
   16bfc:      	add	x2, sp, #0x78
   16c00:      	mov	x0, x22
   16c04:      	blr	x8
   16c08:      	mov	w8, #0x6460             // =25696
   16c0c:      	mov	w9, #0x4                // =4
   16c10:      	mov	w1, #0x8                // =8
   16c14:      	mov	x2, x23
   16c18:      	add	x0, x20, x8
   16c1c:      	mov	w8, #0x8                // =8
   16c20:      	blr	x9
   16c24:      	cbz	x0, 0x16c94 <generic_kprobe_path+0xbe64>
   16c28:      	neg	w8, w0
   16c2c:      	mov	w9, #0x1                // =1
   16c30:      	add	x1, sp, #0x30
   16c34:      	strh	w8, [sp, #0x30]
   16c38:      	mov	w8, #0x6                // =6
   16c3c:      	mov	x0, x22
   16c40:      	mov	w19, #0x1               // =1
   16c44:      	strh	w8, [sp, #0x32]
   16c48:      	mov	x8, #0x3b               // =59
   16c4c:      	movk	x8, #0x4, lsl #32
   16c50:      	stur	x8, [sp, #0x34]
   16c54:      	add	x8, sp, #0x30
   16c58:      	blr	x9
   16c5c:      	cbz	x0, 0x16c70 <generic_kprobe_path+0xbe40>
   16c60:      	ldr	w8, [x0]
   16c64:      	add	w8, w8, #0x1
   16c68:      	str	w8, [x0]
   16c6c:      	b	0x16c94 <generic_kprobe_path+0xbe64>
   16c70:      	str	w19, [sp, #0x78]
   16c74:      	mov	x3, xzr
   16c78:      	mov	w8, #0x2                // =2
   16c7c:      	add	x9, sp, #0x30
   16c80:      	add	x10, sp, #0x78
   16c84:      	add	x1, sp, #0x30
   16c88:      	add	x2, sp, #0x78
   16c8c:      	mov	x0, x22
   16c90:      	blr	x8
   16c94:      	ldr	x8, [x20, #0x6460]
   16c98:      	mov	w9, #0x1                // =1
   16c9c:      	adrp	x1, 0x16000 <generic_kprobe_path+0xb1d0>
   16ca0:      	mov	w2, #0x6                // =6
   16ca4:      	str	w9, [x25]
   16ca8:      	mov	w9, #0xc                // =12
   16cac:      	sub	x8, x8, #0x20
   16cb0:      	str	x8, [x20, #0x6468]
   16cb4:      	sub	w8, w29, w21
   16cb8:      	stp	w8, wzr, [x25, #0x4]
   16cbc:      	mov	w8, #0x6                // =6
   16cc0:      	ldr	x1, [x1]
   16cc4:      	ldr	x0, [sp, #0x20]
   16cc8:      	blr	x9
   16ccc:      	ldp	x20, x19, [sp, #0xd0]
   16cd0:      	mov	w0, wzr
   16cd4:      	ldr	x29, [sp, #0x90]
   16cd8:      	ldp	x22, x21, [sp, #0xc0]
   16cdc:      	ldp	x24, x23, [sp, #0xb0]
   16ce0:      	ldp	x30, x25, [sp, #0xa0]
   16ce4:      	add	sp, sp, #0xe0
   16ce8:      	ret

Disassembly of section kprobe.multi/generic_kprobe:

0000000000000000 <generic_kprobe_event>:
       0:      	sub	sp, sp, #0xd0
       4:      	stp	x30, x25, [sp, #0x90]
       8:      	stp	x24, x23, [sp, #0xa0]
       c:      	stp	x22, x21, [sp, #0xb0]
      10:      	stp	x20, x19, [sp, #0xc0]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0xc]
      1c:      	adrp	x0, 0x0 <generic_kprobe_event>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0xc
      2c:      	add	x1, sp, #0xc
      30:      	blr	x8
      34:      	cbz	x0, 0x54c <generic_kprobe_event+0x54c>
      38:      	mov	w8, #0x5ef8             // =24312
      3c:      	mov	x20, x0
      40:      	add	x21, x0, x8
      44:      	mov	w8, #0xae               // =174
      48:      	mov	x0, x19
      4c:      	blr	x8
      50:      	str	w0, [x21]
      54:      	adrp	x0, 0x0 <generic_kprobe_event>
      58:      	mov	w8, #0x1                // =1
      5c:      	mov	x1, x21
      60:      	ldr	x0, [x0]
      64:      	blr	x8
      68:      	cbz	x0, 0x54c <generic_kprobe_event+0x54c>
      6c:      	ldr	w8, [x0, #0x64]
      70:      	str	w8, [sp, #0x1c]
      74:      	cbz	w8, 0x230 <generic_kprobe_event+0x230>
      78:      	adrp	x22, 0x0 <generic_kprobe_event>
      7c:      	mov	w8, #0x1                // =1
      80:      	add	x9, sp, #0x1c
      84:      	ldr	x22, [x22]
      88:      	mov	x24, x0
      8c:      	add	x1, sp, #0x1c
      90:      	mov	x0, x22
      94:      	blr	x8
      98:      	cbz	x0, 0x54c <generic_kprobe_event+0x54c>
      9c:      	mov	x23, x0
      a0:      	str	wzr, [sp, #0x84]
      a4:      	adrp	x0, 0x0 <generic_kprobe_event>
      a8:      	mov	w8, #0x1                // =1
      ac:      	ldr	x0, [x0]
      b0:      	add	x9, sp, #0x84
      b4:      	add	x1, sp, #0x84
      b8:      	blr	x8
      bc:      	cbz	x0, 0xe8 <generic_kprobe_event+0xe8>
      c0:      	ldr	x8, [x0, #0x20]
      c4:      	mov	w9, #0x7270             // =29296
      c8:      	movk	w9, #0x6367, lsl #16
      cc:      	cmp	x8, x9
      d0:      	b.ne	0xf0 <generic_kprobe_event+0xf0>
      d4:      	mov	w8, #0x50               // =80
      d8:      	blr	x8
      dc:      	str	x0, [sp, #0x30]
      e0:      	cbnz	x0, 0x1e4 <generic_kprobe_event+0x1e4>
      e4:      	b	0x54c <generic_kprobe_event+0x54c>
      e8:      	mov	w25, wzr
      ec:      	b	0xf4 <generic_kprobe_event+0xf4>
      f0:      	ldr	w25, [x0, #0x10]
      f4:      	mov	w8, #0x23               // =35
      f8:      	blr	x8
      fc:      	str	xzr, [sp, #0x88]
     100:      	add	x2, x0, #0xcd0
     104:      	mov	w8, #0x8                // =8
     108:      	mov	w9, #0x71               // =113
     10c:      	add	x10, sp, #0x20
     110:      	add	x0, sp, #0x20
     114:      	mov	w1, #0x8                // =8
     118:      	blr	x9
     11c:      	ldr	x8, [sp, #0x20]
     120:      	cbz	x8, 0x54c <generic_kprobe_event+0x54c>
     124:      	cmp	w25, #0xb
     128:      	b.hi	0x54c <generic_kprobe_event+0x54c>
     12c:      	ubfiz	x9, x25, #3, #32
     130:      	mov	w10, #0x8               // =8
     134:      	mov	w11, #0x71              // =113
     138:      	add	x12, sp, #0x38
     13c:      	add	x0, sp, #0x38
     140:      	mov	w1, #0x8                // =8
     144:      	add	x8, x8, x9
     148:      	ldr	x8, [sp, #0x20]
     14c:      	add	x2, x8, x9
     150:      	blr	x11
     154:      	ldr	x8, [sp, #0x38]
     158:      	cbz	x8, 0x54c <generic_kprobe_event+0x54c>
     15c:      	mov	w9, #0x8                // =8
     160:      	mov	w10, #0x71              // =113
     164:      	add	x11, sp, #0x88
     168:      	ldr	x2, [sp, #0x38]
     16c:      	add	x0, sp, #0x88
     170:      	mov	w1, #0x8                // =8
     174:      	blr	x10
     178:      	ldr	x8, [sp, #0x88]
     17c:      	cbz	x8, 0x54c <generic_kprobe_event+0x54c>
     180:      	str	xzr, [sp, #0x38]
     184:      	add	x2, x8, #0x100
     188:      	mov	w8, #0x8                // =8
     18c:      	mov	w9, #0x71               // =113
     190:      	add	x10, sp, #0x38
     194:      	add	x0, sp, #0x38
     198:      	mov	w1, #0x8                // =8
     19c:      	blr	x9
     1a0:      	ldr	x8, [sp, #0x38]
     1a4:      	str	xzr, [sp, #0x38]
     1a8:      	cbz	x8, 0x1d8 <generic_kprobe_event+0x1d8>
     1ac:      	add	x2, x8, #0x60
     1b0:      	mov	w8, #0x8                // =8
     1b4:      	mov	w9, #0x71               // =113
     1b8:      	add	x10, sp, #0x38
     1bc:      	add	x0, sp, #0x38
     1c0:      	mov	w1, #0x8                // =8
     1c4:      	blr	x9
     1c8:      	ldr	x0, [sp, #0x38]
     1cc:      	str	x0, [sp, #0x30]
     1d0:      	cbnz	x0, 0x1e4 <generic_kprobe_event+0x1e4>
     1d4:      	b	0x54c <generic_kprobe_event+0x54c>
     1d8:      	mov	x0, xzr
     1dc:      	str	xzr, [sp, #0x30]
     1e0:      	cbz	xzr, 0x54c <generic_kprobe_event+0x54c>
     1e4:      	str	x0, [sp, #0x38]
     1e8:      	adrp	x0, 0x0 <generic_kprobe_event>
     1ec:      	mov	w8, #0x1                // =1
     1f0:      	add	x9, sp, #0x38
     1f4:      	ldr	x0, [x0]
     1f8:      	add	x1, sp, #0x38
     1fc:      	blr	x8
     200:      	cbz	x0, 0x210 <generic_kprobe_event+0x210>
     204:      	ldr	x8, [x0]
     208:      	cbz	x8, 0x210 <generic_kprobe_event+0x210>
     20c:      	str	x8, [sp, #0x30]
     210:      	mov	w8, #0x1                // =1
     214:      	add	x9, sp, #0x30
     218:      	add	x1, sp, #0x30
     21c:      	mov	x0, x23
     220:      	blr	x8
     224:      	mov	x8, x0
     228:      	mov	x0, x24
     22c:      	cbz	x8, 0x568 <generic_kprobe_event+0x568>
     230:      	ldr	w9, [x0]
     234:      	mov	w8, #0x6420             // =25632
     238:      	stur	xzr, [x21, #0x4]
     23c:      	str	xzr, [x20, #0x5eb8]
     240:      	str	xzr, [x20, #0x5ec0]
     244:      	str	wzr, [x20, x8]
     248:      	mov	w8, #0x23               // =35
     24c:      	str	xzr, [x20, #0x5ec8]
     250:      	str	xzr, [x20, #0x5ed0]
     254:      	str	xzr, [x20, #0x5ed8]
     258:      	stp	x9, xzr, [x20, #0x60]
     25c:      	mov	w9, #0x5eb8             // =24248
     260:      	add	x9, x20, x9
     264:      	strb	wzr, [x9, #0x28]
     268:      	blr	x8
     26c:      	add	x2, x0, #0xb50
     270:      	mov	w25, #0x8               // =8
     274:      	add	x8, sp, #0x88
     278:      	mov	w9, #0x4                // =4
     27c:      	mov	x22, x0
     280:      	add	x0, sp, #0x88
     284:      	mov	w1, #0x8                // =8
     288:      	add	x23, x20, #0x20
     28c:      	mov	w24, #0x4               // =4
     290:      	blr	x9
     294:      	ldr	x8, [sp, #0x88]
     298:      	mov	w9, #0x48               // =72
     29c:      	add	x10, sp, #0x38
     2a0:      	mov	w11, #0x4               // =4
     2a4:      	ldr	x2, [sp, #0x88]
     2a8:      	add	x0, sp, #0x38
     2ac:      	mov	w1, #0x48               // =72
     2b0:      	blr	x11
     2b4:      	ldr	x8, [sp, #0x40]
     2b8:      	mov	w9, #0x4                // =4
     2bc:      	mov	x0, x23
     2c0:      	mov	w1, #0x4                // =4
     2c4:      	add	x8, x8, #0x218
     2c8:      	ldr	x8, [sp, #0x40]
     2cc:      	add	x2, x8, #0x218
     2d0:      	blr	x9
     2d4:      	ldr	x8, [sp, #0x48]
     2d8:      	add	x0, x20, #0x24
     2dc:      	mov	w9, #0x4                // =4
     2e0:      	mov	w1, #0x4                // =4
     2e4:      	add	x8, x8, #0x4d8
     2e8:      	ldr	x8, [sp, #0x48]
     2ec:      	add	x2, x8, #0x4d8
     2f0:      	blr	x9
     2f4:      	ldr	x8, [sp, #0x50]
     2f8:      	add	x0, x20, #0x28
     2fc:      	mov	w9, #0x4                // =4
     300:      	mov	w1, #0x4                // =4
     304:      	add	x8, x8, #0x58
     308:      	ldr	x8, [sp, #0x50]
     30c:      	add	x2, x8, #0x58
     310:      	blr	x9
     314:      	str	xzr, [sp, #0x30]
     318:      	add	x2, x22, #0x938
     31c:      	add	x8, sp, #0x30
     320:      	add	x0, sp, #0x30
     324:      	mov	w1, #0x8                // =8
     328:      	blr	x24
     32c:      	ldr	x8, [sp, #0x30]
     330:      	cbz	x8, 0x3b4 <generic_kprobe_event+0x3b4>
     334:      	str	wzr, [sp, #0x10]
     338:      	add	x8, x8, #0x4
     33c:      	add	x9, sp, #0x10
     340:      	mov	w10, #0x4               // =4
     344:      	add	x0, sp, #0x10
     348:      	mov	w1, #0x4                // =4
     34c:      	mov	w23, #0x4               // =4
     350:      	ldr	x8, [sp, #0x30]
     354:      	add	x2, x8, #0x4
     358:      	blr	x10
     35c:      	ldr	x8, [sp, #0x30]
     360:      	ldrsw	x9, [sp, #0x10]
     364:      	add	x10, sp, #0x20
     368:      	mov	w11, #0x4               // =4
     36c:      	add	x0, sp, #0x20
     370:      	mov	w1, #0x10               // =16
     374:      	add	x8, x8, x9, lsl #4
     378:      	mov	w9, #0x10               // =16
     37c:      	add	x8, x8, #0x80
     380:      	ldr	x8, [sp, #0x30]
     384:      	ldrsw	x9, [sp, #0x10]
     388:      	add	x8, x8, x9, lsl #4
     38c:      	add	x2, x8, #0x80
     390:      	blr	x11
     394:      	ldr	x8, [sp, #0x28]
     398:      	add	x0, x20, #0x2c
     39c:      	mov	w1, #0x4                // =4
     3a0:      	add	x8, x8, #0x158
     3a4:      	ldr	x8, [sp, #0x28]
     3a8:      	add	x2, x8, #0x158
     3ac:      	blr	x23
     3b0:      	b	0x3b8 <generic_kprobe_event+0x3b8>
     3b4:      	str	wzr, [x20, #0x2c]
     3b8:      	ldr	x8, [sp, #0x58]
     3bc:      	add	x0, x20, #0x30
     3c0:      	mov	w9, #0x4                // =4
     3c4:      	mov	w1, #0x4                // =4
     3c8:      	mov	w24, #0x4               // =4
     3cc:      	add	x8, x8, #0x158
     3d0:      	ldr	x8, [sp, #0x58]
     3d4:      	add	x2, x8, #0x158
     3d8:      	blr	x9
     3dc:      	ldr	x8, [sp, #0x60]
     3e0:      	add	x0, x20, #0x34
     3e4:      	mov	w9, #0x4                // =4
     3e8:      	mov	w1, #0x4                // =4
     3ec:      	add	x8, x8, #0x118
     3f0:      	ldr	x8, [sp, #0x60]
     3f4:      	add	x2, x8, #0x118
     3f8:      	blr	x9
     3fc:      	ldr	x8, [sp, #0x68]
     400:      	add	x0, x20, #0x38
     404:      	mov	w9, #0x4                // =4
     408:      	mov	w1, #0x4                // =4
     40c:      	add	x8, x8, #0x98
     410:      	ldr	x8, [sp, #0x68]
     414:      	add	x2, x8, #0x98
     418:      	blr	x9
     41c:      	ldr	x8, [sp, #0x70]
     420:      	add	x0, x20, #0x3c
     424:      	mov	w9, #0x4                // =4
     428:      	mov	w1, #0x4                // =4
     42c:      	add	x8, x8, #0x98
     430:      	ldr	x8, [sp, #0x70]
     434:      	add	x2, x8, #0x98
     438:      	blr	x9
     43c:      	ldr	x8, [sp, #0x78]
     440:      	add	x0, x20, #0x40
     444:      	mov	w9, #0x4                // =4
     448:      	mov	w1, #0x4                // =4
     44c:      	add	x8, x8, #0x58
     450:      	ldr	x8, [sp, #0x78]
     454:      	add	x2, x8, #0x58
     458:      	blr	x9
     45c:      	str	xzr, [sp, #0x20]
     460:      	str	xzr, [sp, #0x30]
     464:      	add	x22, x22, #0xae0
     468:      	mov	w25, #0x8               // =8
     46c:      	add	x8, sp, #0x20
     470:      	mov	w9, #0x4                // =4
     474:      	add	x0, sp, #0x20
     478:      	mov	w1, #0x8                // =8
     47c:      	mov	x2, x22
     480:      	blr	x9
     484:      	ldr	x8, [sp, #0x20]
     488:      	add	x9, sp, #0x30
     48c:      	mov	w10, #0x4               // =4
     490:      	add	x0, sp, #0x30
     494:      	mov	w1, #0x8                // =8
     498:      	add	x8, x8, #0x90
     49c:      	ldr	x8, [sp, #0x20]
     4a0:      	add	x2, x8, #0x90
     4a4:      	blr	x10
     4a8:      	ldr	x8, [sp, #0x30]
     4ac:      	add	x0, x20, #0x44
     4b0:      	mov	w9, #0x4                // =4
     4b4:      	mov	w1, #0x4                // =4
     4b8:      	add	x8, x8, #0x158
     4bc:      	ldr	x8, [sp, #0x30]
     4c0:      	add	x2, x8, #0x158
     4c4:      	blr	x9
     4c8:      	add	x8, sp, #0x38
     4cc:      	mov	w9, #0x4                // =4
     4d0:      	add	x0, sp, #0x38
     4d4:      	mov	w1, #0x8                // =8
     4d8:      	mov	x2, x22
     4dc:      	add	x23, x20, #0x48
     4e0:      	blr	x9
     4e4:      	ldr	x22, [sp, #0x38]
     4e8:      	add	x0, x20, #0x50
     4ec:      	mov	w8, #0x4                // =4
     4f0:      	mov	w1, #0x8                // =8
     4f4:      	add	x2, x22, #0x40
     4f8:      	blr	x8
     4fc:      	add	x0, x20, #0x58
     500:      	add	x2, x22, #0x30
     504:      	mov	w8, #0x4                // =4
     508:      	mov	w1, #0x8                // =8
     50c:      	blr	x8
     510:      	add	x2, x22, #0x38
     514:      	mov	x0, x23
     518:      	mov	w1, #0x8                // =8
     51c:      	blr	x24
     520:      	strb	wzr, [x21, #0x10]
     524:      	strb	wzr, [x20, #0x1]
     528:      	adrp	x1, 0x0 <generic_kprobe_event>
     52c:      	mov	w8, #0x2                // =2
     530:      	mov	w9, #0xc                // =12
     534:      	mov	x0, x19
     538:      	str	xzr, [x20, #0x5ee8]
     53c:      	str	xzr, [x20, #0x5ef0]
     540:      	ldr	x1, [x1]
     544:      	mov	w2, #0x2                // =2
     548:      	blr	x9
     54c:      	ldp	x20, x19, [sp, #0xc0]
     550:      	mov	w0, wzr
     554:      	ldp	x22, x21, [sp, #0xb0]
     558:      	ldp	x24, x23, [sp, #0xa0]
     55c:      	ldp	x30, x25, [sp, #0x90]
     560:      	add	sp, sp, #0xd0
     564:      	ret
     568:      	mov	x8, #-0x1               // =-1
     56c:      	mov	w9, #0x1                // =1
     570:      	add	x1, sp, #0x10
     574:      	str	x8, [sp, #0x10]
     578:      	add	x8, sp, #0x10
     57c:      	mov	x0, x23
     580:      	mov	w25, #0x1               // =1
     584:      	blr	x9
     588:      	cbz	x0, 0x54c <generic_kprobe_event+0x54c>
     58c:      	str	w25, [sp, #0x1c]
     590:      	add	x8, sp, #0x1c
     594:      	add	x1, sp, #0x1c
     598:      	mov	x0, x22
     59c:      	blr	x25
     5a0:      	cbz	x0, 0x54c <generic_kprobe_event+0x54c>
     5a4:      	mov	w8, #0x1                // =1
     5a8:      	add	x9, sp, #0x30
     5ac:      	add	x1, sp, #0x30
     5b0:      	blr	x8
     5b4:      	mov	x8, x0
     5b8:      	mov	x0, x24
     5bc:      	cbnz	x8, 0x54c <generic_kprobe_event+0x54c>
     5c0:      	b	0x230 <generic_kprobe_event+0x230>

Disassembly of section kprobe.multi/generic_kprobe_override:

0000000000000000 <generic_kprobe_override>:
       0:      	str	x30, [sp, #-0x20]!
       4:      	stp	x20, x19, [sp, #0x10]
       8:      	mov	w8, #0xe                // =14
       c:      	mov	x20, x0
      10:      	blr	x8
      14:      	str	x0, [sp, #0x8]
      18:      	adrp	x19, 0x0 <generic_kprobe_override>
      1c:      	mov	w8, #0x1                // =1
      20:      	add	x9, sp, #0x8
      24:      	ldr	x19, [x19]
      28:      	add	x1, sp, #0x8
      2c:      	mov	x0, x19
      30:      	blr	x8
      34:      	cbz	x0, 0x60 <generic_kprobe_override+0x60>
      38:      	ldrsw	x8, [x0]
      3c:      	mov	w9, #0x3a               // =58
      40:      	ldrsw	x1, [x0]
      44:      	mov	x0, x20
      48:      	blr	x9
      4c:      	mov	w8, #0x3                // =3
      50:      	add	x9, sp, #0x8
      54:      	add	x1, sp, #0x8
      58:      	mov	x0, x19
      5c:      	blr	x8
      60:      	ldp	x20, x19, [sp, #0x10]
      64:      	mov	w0, wzr
      68:      	ldr	x30, [sp], #0x20
      6c:      	ret

Disassembly of section fmod_ret/security_task_prctl:

0000000000000000 <generic_fmodret_override>:
       0:      	str	x30, [sp, #-0x20]!
       4:      	stp	x20, x19, [sp, #0x10]
       8:      	mov	w8, #0xe                // =14
       c:      	blr	x8
      10:      	str	x0, [sp, #0x8]
      14:      	adrp	x19, 0x0 <generic_fmodret_override>
      18:      	mov	w8, #0x1                // =1
      1c:      	add	x9, sp, #0x8
      20:      	ldr	x19, [x19]
      24:      	add	x1, sp, #0x8
      28:      	mov	x0, x19
      2c:      	blr	x8
      30:      	cbz	x0, 0x50 <generic_fmodret_override+0x50>
      34:      	mov	w8, #0x3                // =3
      38:      	add	x9, sp, #0x8
      3c:      	mov	x20, x0
      40:      	add	x1, sp, #0x8
      44:      	mov	x0, x19
      48:      	blr	x8
      4c:      	ldrsw	x0, [x20]
      50:      	ldp	x20, x19, [sp, #0x10]
      54:      	ldr	x30, [sp], #0x20
      58:      	ret
