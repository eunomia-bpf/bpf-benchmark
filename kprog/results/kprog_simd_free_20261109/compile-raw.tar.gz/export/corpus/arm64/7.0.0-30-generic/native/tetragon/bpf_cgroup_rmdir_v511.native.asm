
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_cgroup_rmdir_v511.native.o:	file format elf64-littleaarch64

Disassembly of section raw_tracepoint/cgroup_rmdir:

0000000000000000 <tg_tp_cgrp_rmdir>:
       0:      	sub	sp, sp, #0x70
       4:      	stp	x30, x25, [sp, #0x30]
       8:      	stp	x24, x23, [sp, #0x40]
       c:      	stp	x22, x21, [sp, #0x50]
      10:      	stp	x20, x19, [sp, #0x60]
      14:      	ldr	x21, [x0]
      18:      	str	wzr, [sp, #0x8]
      1c:      	str	xzr, [sp, #0x18]
      20:      	cbz	x21, 0x41c <tg_tp_cgrp_rmdir+0x41c>
      24:      	add	x2, x21, #0x100
      28:      	mov	w8, #0x8                // =8
      2c:      	mov	w9, #0x71               // =113
      30:      	add	x10, sp, #0x18
      34:      	mov	x22, x0
      38:      	add	x0, sp, #0x18
      3c:      	mov	w1, #0x8                // =8
      40:      	blr	x9
      44:      	ldr	x8, [sp, #0x18]
      48:      	str	xzr, [sp, #0x18]
      4c:      	cbz	x8, 0x41c <tg_tp_cgrp_rmdir+0x41c>
      50:      	add	x2, x8, #0x60
      54:      	mov	w8, #0x8                // =8
      58:      	mov	w9, #0x71               // =113
      5c:      	add	x10, sp, #0x18
      60:      	add	x0, sp, #0x18
      64:      	mov	w1, #0x8                // =8
      68:      	blr	x9
      6c:      	ldr	x8, [sp, #0x18]
      70:      	str	x8, [sp]
      74:      	cbz	x8, 0x41c <tg_tp_cgrp_rmdir+0x41c>
      78:      	adrp	x20, 0x0 <tg_tp_cgrp_rmdir>
      7c:      	mov	w8, #0x1                // =1
      80:      	mov	x9, sp
      84:      	ldr	x20, [x20]
      88:      	mov	x1, sp
      8c:      	mov	x0, x20
      90:      	blr	x8
      94:      	adrp	x19, 0x0 <tg_tp_cgrp_rmdir>
      98:      	ldr	x19, [x19]
      9c:      	cbz	x0, 0x310 <tg_tp_cgrp_rmdir+0x310>
      a0:      	mov	w8, #0x3                // =3
      a4:      	mov	x9, sp
      a8:      	mov	x23, x0
      ac:      	mov	x1, sp
      b0:      	mov	x0, x20
      b4:      	blr	x8
      b8:      	mov	w8, #0x1                // =1
      bc:      	add	x9, sp, #0x8
      c0:      	add	x1, sp, #0x8
      c4:      	mov	x0, x19
      c8:      	blr	x8
      cc:      	cbz	x0, 0x41c <tg_tp_cgrp_rmdir+0x41c>
      d0:      	ldr	w8, [x0]
      d4:      	cmp	w8, #0x6
      d8:      	b.ne	0x41c <tg_tp_cgrp_rmdir+0x41c>
      dc:      	str	wzr, [sp, #0xc]
      e0:      	adrp	x0, 0x0 <tg_tp_cgrp_rmdir>
      e4:      	ldr	x24, [sp]
      e8:      	mov	w8, #0x1                // =1
      ec:      	add	x9, sp, #0xc
      f0:      	add	x1, sp, #0xc
      f4:      	ldr	x0, [x0]
      f8:      	blr	x8
      fc:      	cbz	x0, 0x41c <tg_tp_cgrp_rmdir+0x41c>
     100:      	mov	w8, #0x19               // =25
     104:      	mov	x20, x0
     108:      	strb	w8, [x0]
     10c:      	mov	w8, #0x10d8             // =4312
     110:      	str	w8, [x0, #0x4]
     114:      	mov	w8, #0xe                // =14
     118:      	ldr	x21, [x22, #0x8]
     11c:      	blr	x8
     120:      	lsr	x25, x0, #32
     124:      	adrp	x0, 0x0 <tg_tp_cgrp_rmdir>
     128:      	mov	w8, #0x1                // =1
     12c:      	str	w25, [sp, #0x18]
     130:      	add	x9, sp, #0x18
     134:      	add	x1, sp, #0x18
     138:      	ldr	x0, [x0]
     13c:      	blr	x8
     140:      	cbz	x0, 0x164 <tg_tp_cgrp_rmdir+0x164>
     144:      	ldr	x8, [x0, #0x8]
     148:      	str	x8, [x20, #0x8]
     14c:      	ldp	x8, x9, [x0, #0x10]
     150:      	stp	x8, x9, [x20, #0x10]
     154:      	ldr	w8, [x0, #0x20]
     158:      	str	w8, [x20, #0x2c]
     15c:      	ldr	x8, [x0, #0x8]
     160:      	str	x8, [x20, #0x30]
     164:      	mov	w8, #0x2                // =2
     168:      	stp	w8, w25, [x20, #0x20]
     16c:      	mov	w8, #0x23               // =35
     170:      	blr	x8
     174:      	add	x2, x0, #0x60
     178:      	mov	w8, #0x8                // =8
     17c:      	mov	w9, #0x71               // =113
     180:      	add	x10, sp, #0x10
     184:      	add	x0, sp, #0x10
     188:      	mov	w1, #0x8                // =8
     18c:      	blr	x9
     190:      	ldr	x8, [sp, #0x10]
     194:      	cbz	x8, 0x204 <tg_tp_cgrp_rmdir+0x204>
     198:      	add	x8, x8, #0x4
     19c:      	mov	w9, #0x4                // =4
     1a0:      	mov	w10, #0x71              // =113
     1a4:      	add	x11, sp, #0x2c
     1a8:      	ldr	x8, [sp, #0x10]
     1ac:      	add	x0, sp, #0x2c
     1b0:      	mov	w1, #0x4                // =4
     1b4:      	add	x2, x8, #0x4
     1b8:      	blr	x10
     1bc:      	ldr	w8, [sp, #0x2c]
     1c0:      	cbz	w8, 0x204 <tg_tp_cgrp_rmdir+0x204>
     1c4:      	ldr	x9, [sp, #0x10]
     1c8:      	lsl	w8, w8, #4
     1cc:      	mov	w10, #0x71              // =113
     1d0:      	add	x11, sp, #0x18
     1d4:      	add	x0, sp, #0x18
     1d8:      	mov	w1, #0x10               // =16
     1dc:      	add	x8, x9, x8
     1e0:      	mov	w9, #0x10               // =16
     1e4:      	add	x8, x8, #0x80
     1e8:      	ldr	w9, [sp, #0x2c]
     1ec:      	ldr	x8, [sp, #0x10]
     1f0:      	lsl	w9, w9, #4
     1f4:      	add	x8, x8, x9
     1f8:      	add	x2, x8, #0x80
     1fc:      	blr	x10
     200:      	ldr	w8, [sp, #0x18]
     204:      	str	w8, [x20, #0x28]
     208:      	stp	x24, x24, [x20, #0x38]
     20c:      	add	x0, x20, #0xd8
     210:      	mov	w1, #0xfff              // =4095
     214:      	mov	x2, x21
     218:      	ldr	x8, [x23]
     21c:      	str	x8, [x20, #0x48]
     220:      	ldr	w8, [x23, #0x8]
     224:      	str	w8, [x20, #0x50]
     228:      	ldp	x8, x9, [x23, #0x10]
     22c:      	ldp	x10, x11, [x23, #0x20]
     230:      	stp	x10, x11, [x20, #0x68]
     234:      	stp	x8, x9, [x20, #0x58]
     238:      	ldp	x8, x9, [x23, #0x30]
     23c:      	ldp	x10, x11, [x23, #0x40]
     240:      	stp	x10, x11, [x20, #0x88]
     244:      	stp	x8, x9, [x20, #0x78]
     248:      	ldp	x8, x9, [x23, #0x50]
     24c:      	ldp	x10, x11, [x23, #0x60]
     250:      	stp	x10, x11, [x20, #0xa8]
     254:      	stp	x8, x9, [x20, #0x98]
     258:      	ldp	x8, x9, [x23, #0x70]
     25c:      	ldp	x10, x11, [x23, #0x80]
     260:      	stp	x10, x11, [x20, #0xc8]
     264:      	stp	x8, x9, [x20, #0xb8]
     268:      	mov	w8, #0xfff              // =4095
     26c:      	mov	w9, #0x2d               // =45
     270:      	blr	x9
     274:      	str	wzr, [sp, #0x10]
     278:      	mov	w8, #0x1                // =1
     27c:      	add	x9, sp, #0x10
     280:      	add	x1, sp, #0x10
     284:      	mov	x0, x19
     288:      	blr	x8
     28c:      	cbz	x0, 0x438 <tg_tp_cgrp_rmdir+0x438>
     290:      	ldrb	w8, [x0, #0x28]
     294:      	cbz	w8, 0x438 <tg_tp_cgrp_rmdir+0x438>
     298:      	adrp	x1, 0x0 <tg_tp_cgrp_rmdir>
     29c:      	mov	w8, #-0x1               // =-1
     2a0:      	mov	w9, #0x10d8             // =4312
     2a4:      	ldr	x1, [x1]
     2a8:      	mov	w10, #0x19              // =25
     2ac:      	mov	x0, x22
     2b0:      	mov	w2, #-0x1               // =-1
     2b4:      	mov	x3, x20
     2b8:      	mov	w4, #0x10d8             // =4312
     2bc:      	blr	x10
     2c0:      	tbz	x0, #0x3f, 0x41c <tg_tp_cgrp_rmdir+0x41c>
     2c4:      	mov	x19, x0
     2c8:      	str	wzr, [sp, #0x18]
     2cc:      	adrp	x0, 0x0 <tg_tp_cgrp_rmdir>
     2d0:      	mov	w8, #0x1                // =1
     2d4:      	ldr	x0, [x0]
     2d8:      	add	x9, sp, #0x18
     2dc:      	add	x1, sp, #0x18
     2e0:      	blr	x8
     2e4:      	cbz	x0, 0x41c <tg_tp_cgrp_rmdir+0x41c>
     2e8:      	cmn	x19, #0xc
     2ec:      	b.gt	0x4c8 <tg_tp_cgrp_rmdir+0x4c8>
     2f0:      	cmn	x19, #0x1c
     2f4:      	b.eq	0x520 <tg_tp_cgrp_rmdir+0x520>
     2f8:      	cmn	x19, #0x16
     2fc:      	b.eq	0x538 <tg_tp_cgrp_rmdir+0x538>
     300:      	cmn	x19, #0x10
     304:      	b.ne	0x530 <tg_tp_cgrp_rmdir+0x530>
     308:      	add	x8, x0, #0x590
     30c:      	b	0x544 <tg_tp_cgrp_rmdir+0x544>
     310:      	str	wzr, [sp, #0x2c]
     314:      	str	wzr, [sp, #0x18]
     318:      	add	x2, x21, #0xd8
     31c:      	mov	w22, #0x4               // =4
     320:      	mov	w8, #0x71               // =113
     324:      	add	x9, sp, #0x18
     328:      	add	x0, sp, #0x18
     32c:      	mov	w1, #0x4                // =4
     330:      	blr	x8
     334:      	ldr	w20, [sp, #0x18]
     338:      	add	x2, x21, #0x2d0
     33c:      	mov	w8, #0x8                // =8
     340:      	add	x9, sp, #0x18
     344:      	mov	w10, #0x4               // =4
     348:      	add	x0, sp, #0x18
     34c:      	mov	w1, #0x8                // =8
     350:      	blr	x10
     354:      	ldr	x8, [sp, #0x18]
     358:      	add	x9, sp, #0x10
     35c:      	add	x0, sp, #0x10
     360:      	mov	w1, #0x4                // =4
     364:      	add	x8, x8, #0xc
     368:      	ldr	x8, [sp, #0x18]
     36c:      	add	x2, x8, #0xc
     370:      	blr	x22
     374:      	ldr	w21, [sp, #0x10]
     378:      	mov	w8, #0x1                // =1
     37c:      	add	x9, sp, #0x2c
     380:      	add	x1, sp, #0x2c
     384:      	mov	x0, x19
     388:      	blr	x8
     38c:      	cbz	x0, 0x41c <tg_tp_cgrp_rmdir+0x41c>
     390:      	ldr	w8, [x0, #0x14]
     394:      	cbz	w8, 0x41c <tg_tp_cgrp_rmdir+0x41c>
     398:      	ldr	w9, [x0, #0xc]
     39c:      	cmp	w9, w21
     3a0:      	b.ne	0x41c <tg_tp_cgrp_rmdir+0x41c>
     3a4:      	cbz	w20, 0x41c <tg_tp_cgrp_rmdir+0x41c>
     3a8:      	cmp	w20, w8
     3ac:      	b.hi	0x41c <tg_tp_cgrp_rmdir+0x41c>
     3b0:      	mov	w8, #0x2                // =2
     3b4:      	adrp	x19, 0x0 <tg_tp_cgrp_rmdir>
     3b8:      	mov	w9, #0x1                // =1
     3bc:      	add	x1, sp, #0x18
     3c0:      	mov	w20, #0x1               // =1
     3c4:      	movk	w8, #0xd, lsl #16
     3c8:      	str	w8, [sp, #0x18]
     3cc:      	mov	w8, #0x27               // =39
     3d0:      	stur	x8, [sp, #0x1c]
     3d4:      	add	x8, sp, #0x18
     3d8:      	ldr	x19, [x19]
     3dc:      	mov	x0, x19
     3e0:      	blr	x9
     3e4:      	cbz	x0, 0x3f8 <tg_tp_cgrp_rmdir+0x3f8>
     3e8:      	ldr	w8, [x0]
     3ec:      	add	w8, w8, #0x1
     3f0:      	str	w8, [x0]
     3f4:      	b	0x41c <tg_tp_cgrp_rmdir+0x41c>
     3f8:      	str	w20, [sp, #0x10]
     3fc:      	mov	x3, xzr
     400:      	mov	w8, #0x2                // =2
     404:      	add	x9, sp, #0x18
     408:      	add	x10, sp, #0x10
     40c:      	add	x1, sp, #0x18
     410:      	add	x2, sp, #0x10
     414:      	mov	x0, x19
     418:      	blr	x8
     41c:      	ldp	x20, x19, [sp, #0x60]
     420:      	mov	w0, wzr
     424:      	ldp	x22, x21, [sp, #0x50]
     428:      	ldp	x24, x23, [sp, #0x40]
     42c:      	ldp	x30, x25, [sp, #0x30]
     430:      	add	sp, sp, #0x70
     434:      	ret
     438:      	adrp	x0, 0x0 <tg_tp_cgrp_rmdir>
     43c:      	mov	x3, xzr
     440:      	mov	w8, #0x10d8             // =4312
     444:      	ldr	x0, [x0]
     448:      	mov	w9, #0x82               // =130
     44c:      	mov	x1, x20
     450:      	mov	w2, #0x10d8             // =4312
     454:      	blr	x9
     458:      	tbz	x0, #0x3f, 0x41c <tg_tp_cgrp_rmdir+0x41c>
     45c:      	mov	x19, x0
     460:      	str	wzr, [sp, #0x18]
     464:      	adrp	x0, 0x0 <tg_tp_cgrp_rmdir>
     468:      	mov	w8, #0x1                // =1
     46c:      	ldr	x0, [x0]
     470:      	add	x9, sp, #0x18
     474:      	add	x1, sp, #0x18
     478:      	blr	x8
     47c:      	cbz	x0, 0x41c <tg_tp_cgrp_rmdir+0x41c>
     480:      	cmn	x19, #0xc
     484:      	b.gt	0x4a8 <tg_tp_cgrp_rmdir+0x4a8>
     488:      	cmn	x19, #0x1c
     48c:      	b.eq	0x4e8 <tg_tp_cgrp_rmdir+0x4e8>
     490:      	cmn	x19, #0x16
     494:      	b.eq	0x500 <tg_tp_cgrp_rmdir+0x500>
     498:      	cmn	x19, #0x10
     49c:      	b.ne	0x4f8 <tg_tp_cgrp_rmdir+0x4f8>
     4a0:      	add	x8, x0, #0x590
     4a4:      	b	0x50c <tg_tp_cgrp_rmdir+0x50c>
     4a8:      	cmn	x19, #0xb
     4ac:      	b.eq	0x4f0 <tg_tp_cgrp_rmdir+0x4f0>
     4b0:      	cmn	x19, #0x7
     4b4:      	b.eq	0x508 <tg_tp_cgrp_rmdir+0x508>
     4b8:      	cmn	x19, #0x2
     4bc:      	b.ne	0x4f8 <tg_tp_cgrp_rmdir+0x4f8>
     4c0:      	add	x8, x0, #0x580
     4c4:      	b	0x50c <tg_tp_cgrp_rmdir+0x50c>
     4c8:      	cmn	x19, #0xb
     4cc:      	b.eq	0x528 <tg_tp_cgrp_rmdir+0x528>
     4d0:      	cmn	x19, #0x7
     4d4:      	b.eq	0x540 <tg_tp_cgrp_rmdir+0x540>
     4d8:      	cmn	x19, #0x2
     4dc:      	b.ne	0x530 <tg_tp_cgrp_rmdir+0x530>
     4e0:      	add	x8, x0, #0x580
     4e4:      	b	0x544 <tg_tp_cgrp_rmdir+0x544>
     4e8:      	add	x8, x0, #0x5a0
     4ec:      	b	0x50c <tg_tp_cgrp_rmdir+0x50c>
     4f0:      	add	x8, x0, #0x5a8
     4f4:      	b	0x50c <tg_tp_cgrp_rmdir+0x50c>
     4f8:      	add	x8, x0, #0x578
     4fc:      	b	0x50c <tg_tp_cgrp_rmdir+0x50c>
     500:      	add	x8, x0, #0x598
     504:      	b	0x50c <tg_tp_cgrp_rmdir+0x50c>
     508:      	add	x8, x0, #0x588
     50c:      	ldaxr	x9, [x8]
     510:      	add	x9, x9, #0x1
     514:      	stlxr	w10, x9, [x8]
     518:      	cbnz	w10, 0x50c <tg_tp_cgrp_rmdir+0x50c>
     51c:      	b	0x41c <tg_tp_cgrp_rmdir+0x41c>
     520:      	add	x8, x0, #0x5a0
     524:      	b	0x544 <tg_tp_cgrp_rmdir+0x544>
     528:      	add	x8, x0, #0x5a8
     52c:      	b	0x544 <tg_tp_cgrp_rmdir+0x544>
     530:      	add	x8, x0, #0x578
     534:      	b	0x544 <tg_tp_cgrp_rmdir+0x544>
     538:      	add	x8, x0, #0x598
     53c:      	b	0x544 <tg_tp_cgrp_rmdir+0x544>
     540:      	add	x8, x0, #0x588
     544:      	ldaxr	x9, [x8]
     548:      	add	x9, x9, #0x1
     54c:      	stlxr	w10, x9, [x8]
     550:      	cbnz	w10, 0x544 <tg_tp_cgrp_rmdir+0x544>
     554:      	b	0x41c <tg_tp_cgrp_rmdir+0x41c>
