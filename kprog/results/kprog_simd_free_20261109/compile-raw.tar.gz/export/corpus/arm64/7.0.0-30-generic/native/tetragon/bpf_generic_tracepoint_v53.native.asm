
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_tracepoint_v53.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <native_bpf_strncasestr>:
       0:      	cbz	x2, 0x8c <native_bpf_strncasestr+0x8c>
       4:      	mov	x8, x0
       8:      	mov	x0, xzr
       c:      	mov	x9, x2
      10:      	b	0x34 <native_bpf_strncasestr+0x34>
      14:      	nop
      18:      	nop
      1c:      	nop
      20:      	add	x0, x0, #0x1
      24:      	sub	x9, x9, #0x1
      28:      	add	x8, x8, #0x1
      2c:      	cmp	x0, x2
      30:      	b.eq	0x8c <native_bpf_strncasestr+0x8c>
      34:      	mov	x10, xzr
      38:      	nop
      3c:      	nop
      40:      	cmp	x9, x10
      44:      	b.eq	0x20 <native_bpf_strncasestr+0x20>
      48:      	ldrb	w11, [x1, x10]
      4c:      	cbz	w11, 0x90 <native_bpf_strncasestr+0x90>
      50:      	ldrb	w12, [x8, x10]
      54:      	sub	w13, w12, #0x41
      58:      	orr	w14, w12, #0x20
      5c:      	cmp	w13, #0x1a
      60:      	sub	w13, w11, #0x41
      64:      	csel	w12, w14, w12, lo
      68:      	orr	w14, w11, #0x20
      6c:      	cmp	w13, #0x1a
      70:      	csel	w11, w14, w11, lo
      74:      	cmp	w12, w11
      78:      	b.ne	0x20 <native_bpf_strncasestr+0x20>
      7c:      	cmp	x10, #0x63
      80:      	add	x10, x10, #0x1
      84:      	b.lo	0x40 <native_bpf_strncasestr+0x40>
      88:      	b	0x20 <native_bpf_strncasestr+0x20>
      8c:      	mov	w0, #-0x1               // =-1
      90:      	ret

Disassembly of section tracepoint:

0000000000000000 <generic_tracepoint_process_event>:
       0:      	sub	sp, sp, #0x160
       4:      	str	x29, [sp, #0x110]
       8:      	stp	x30, x25, [sp, #0x120]
       c:      	stp	x24, x23, [sp, #0x130]
      10:      	stp	x22, x21, [sp, #0x140]
      14:      	stp	x20, x19, [sp, #0x150]
      18:      	str	wzr, [sp, #0x5c]
      1c:      	adrp	x23, 0x0 <generic_tracepoint_process_event>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x5c
      28:      	ldr	x23, [x23]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0x5c
      34:      	mov	x0, x23
      38:      	blr	x8
      3c:      	cbz	x0, 0xdc0 <generic_tracepoint_process_event+0xdc0>
      40:      	ldr	w24, [x0, #0x4]
      44:      	mov	w21, #0x5efc            // =24316
      48:      	mov	x20, x0
      4c:      	ldr	w29, [x0, x21]
      50:      	lsr	w8, w24, #3
      54:      	cmp	w8, #0x464
      58:      	b.hi	0x5f0 <generic_tracepoint_process_event+0x5f0>
      5c:      	str	wzr, [sp, #0x68]
      60:      	mov	w8, #0x1                // =1
      64:      	add	x9, sp, #0x68
      68:      	add	x1, sp, #0x68
      6c:      	mov	x0, x23
      70:      	blr	x8
      74:      	cbz	x0, 0x5f0 <generic_tracepoint_process_event+0x5f0>
      78:      	mov	w8, #0x5ef8             // =24312
      7c:      	mov	x22, x0
      80:      	add	x1, x0, x8
      84:      	adrp	x0, 0x0 <generic_tracepoint_process_event>
      88:      	mov	w8, #0x1                // =1
      8c:      	ldr	x0, [x0]
      90:      	blr	x8
      94:      	cmp	w29, #0x4
      98:      	ccmp	x0, #0x0, #0x4, le
      9c:      	b.eq	0x5f0 <generic_tracepoint_process_event+0x5f0>
      a0:      	str	x24, [sp, #0x118]
      a4:      	and	x24, x29, #0x7
      a8:      	add	x8, x0, x24, lsl #2
      ac:      	add	x23, x22, x24, lsl #2
      b0:      	ldr	w25, [x8, #0x4]
      b4:      	ldrsw	x9, [x8, #0x18]
      b8:      	mov	w8, #0x5ea0             // =24224
      bc:      	str	wzr, [x23, x8]
      c0:      	add	x8, x22, x24, lsl #3
      c4:      	ldr	x8, [x8, #0x5e50]
      c8:      	str	x9, [sp, #0x48]
      cc:      	str	x8, [sp, #0x60]
      d0:      	tbnz	w9, #0x8, 0x398 <generic_tracepoint_process_event+0x398>
      d4:      	cmp	w24, #0x4
      d8:      	b.hi	0x39c <generic_tracepoint_process_event+0x39c>
      dc:      	mov	w9, #0x50               // =80
      e0:      	umaddl	x22, w24, w9, x0
      e4:      	ldrh	w9, [x22, #0x76]
      e8:      	cbz	w9, 0x39c <generic_tracepoint_process_event+0x39c>
      ec:      	ldur	w9, [x22, #0x70]
      f0:      	add	x8, x8, x9
      f4:      	str	x8, [sp, #0x60]
      f8:      	ldurh	w9, [x22, #0x74]
      fc:      	cbz	w9, 0x124 <generic_tracepoint_process_event+0x124>
     100:      	mov	w9, #0x8                // =8
     104:      	mov	w10, #0x4               // =4
     108:      	add	x11, sp, #0x60
     10c:      	ldr	x2, [sp, #0x60]
     110:      	add	x0, sp, #0x60
     114:      	mov	w1, #0x8                // =8
     118:      	blr	x10
     11c:      	mov	w8, #0x5ea0             // =24224
     120:      	tbnz	w0, #0x1f, 0x47c <generic_tracepoint_process_event+0x47c>
     124:      	ldurh	w8, [x22, #0x7e]
     128:      	cbz	w8, 0x39c <generic_tracepoint_process_event+0x39c>
     12c:      	ldr	x8, [sp, #0x60]
     130:      	ldur	w9, [x22, #0x78]
     134:      	add	x8, x8, x9
     138:      	str	x8, [sp, #0x60]
     13c:      	ldurh	w9, [x22, #0x7c]
     140:      	cbz	w9, 0x168 <generic_tracepoint_process_event+0x168>
     144:      	mov	w9, #0x8                // =8
     148:      	mov	w10, #0x4               // =4
     14c:      	add	x11, sp, #0x60
     150:      	ldr	x2, [sp, #0x60]
     154:      	add	x0, sp, #0x60
     158:      	mov	w1, #0x8                // =8
     15c:      	blr	x10
     160:      	mov	w8, #0x5ea0             // =24224
     164:      	tbnz	w0, #0x1f, 0x48c <generic_tracepoint_process_event+0x48c>
     168:      	ldurh	w8, [x22, #0x86]
     16c:      	cbz	w8, 0x39c <generic_tracepoint_process_event+0x39c>
     170:      	ldr	x8, [sp, #0x60]
     174:      	ldur	w9, [x22, #0x80]
     178:      	add	x8, x8, x9
     17c:      	str	x8, [sp, #0x60]
     180:      	ldurh	w9, [x22, #0x84]
     184:      	cbz	w9, 0x1ac <generic_tracepoint_process_event+0x1ac>
     188:      	mov	w9, #0x8                // =8
     18c:      	mov	w10, #0x4               // =4
     190:      	add	x11, sp, #0x60
     194:      	ldr	x2, [sp, #0x60]
     198:      	add	x0, sp, #0x60
     19c:      	mov	w1, #0x8                // =8
     1a0:      	blr	x10
     1a4:      	mov	w8, #0x5ea0             // =24224
     1a8:      	tbnz	w0, #0x1f, 0x494 <generic_tracepoint_process_event+0x494>
     1ac:      	ldurh	w8, [x22, #0x8e]
     1b0:      	cbz	w8, 0x39c <generic_tracepoint_process_event+0x39c>
     1b4:      	ldr	x8, [sp, #0x60]
     1b8:      	ldur	w9, [x22, #0x88]
     1bc:      	add	x8, x8, x9
     1c0:      	str	x8, [sp, #0x60]
     1c4:      	ldurh	w9, [x22, #0x8c]
     1c8:      	cbz	w9, 0x1f4 <generic_tracepoint_process_event+0x1f4>
     1cc:      	mov	w9, #0x8                // =8
     1d0:      	add	x10, sp, #0x60
     1d4:      	mov	w11, #0x4               // =4
     1d8:      	ldr	x2, [sp, #0x60]
     1dc:      	add	x0, sp, #0x60
     1e0:      	mov	w1, #0x8                // =8
     1e4:      	mov	w21, #0x4               // =4
     1e8:      	blr	x11
     1ec:      	mov	w8, #0x5ea0             // =24224
     1f0:      	tbnz	w0, #0x1f, 0x498 <generic_tracepoint_process_event+0x498>
     1f4:      	ldurh	w8, [x22, #0x96]
     1f8:      	mov	w21, #0x5efc            // =24316
     1fc:      	cbz	w8, 0x39c <generic_tracepoint_process_event+0x39c>
     200:      	ldr	x8, [sp, #0x60]
     204:      	ldur	w9, [x22, #0x90]
     208:      	add	x8, x8, x9
     20c:      	str	x8, [sp, #0x60]
     210:      	ldurh	w9, [x22, #0x94]
     214:      	cbz	w9, 0x23c <generic_tracepoint_process_event+0x23c>
     218:      	mov	w9, #0x8                // =8
     21c:      	mov	w10, #0x4               // =4
     220:      	add	x11, sp, #0x60
     224:      	ldr	x2, [sp, #0x60]
     228:      	add	x0, sp, #0x60
     22c:      	mov	w1, #0x8                // =8
     230:      	blr	x10
     234:      	mov	w8, #0x5ea0             // =24224
     238:      	tbnz	w0, #0x1f, 0x1124 <generic_tracepoint_process_event+0x1124>
     23c:      	ldurh	w8, [x22, #0x9e]
     240:      	cbz	w8, 0x39c <generic_tracepoint_process_event+0x39c>
     244:      	ldr	x8, [sp, #0x60]
     248:      	ldur	w9, [x22, #0x98]
     24c:      	add	x8, x8, x9
     250:      	str	x8, [sp, #0x60]
     254:      	ldurh	w9, [x22, #0x9c]
     258:      	cbz	w9, 0x280 <generic_tracepoint_process_event+0x280>
     25c:      	mov	w9, #0x8                // =8
     260:      	mov	w10, #0x4               // =4
     264:      	add	x11, sp, #0x60
     268:      	ldr	x2, [sp, #0x60]
     26c:      	add	x0, sp, #0x60
     270:      	mov	w1, #0x8                // =8
     274:      	blr	x10
     278:      	mov	w8, #0x5ea0             // =24224
     27c:      	tbnz	w0, #0x1f, 0x1728 <generic_tracepoint_process_event+0x1728>
     280:      	ldurh	w8, [x22, #0xa6]
     284:      	cbz	w8, 0x39c <generic_tracepoint_process_event+0x39c>
     288:      	ldr	x8, [sp, #0x60]
     28c:      	ldur	w9, [x22, #0xa0]
     290:      	add	x8, x8, x9
     294:      	str	x8, [sp, #0x60]
     298:      	ldurh	w9, [x22, #0xa4]
     29c:      	cbz	w9, 0x2c0 <generic_tracepoint_process_event+0x2c0>
     2a0:      	mov	w9, #0x8                // =8
     2a4:      	mov	w10, #0x4               // =4
     2a8:      	add	x11, sp, #0x60
     2ac:      	ldr	x2, [sp, #0x60]
     2b0:      	add	x0, sp, #0x60
     2b4:      	mov	w1, #0x8                // =8
     2b8:      	blr	x10
     2bc:      	tbnz	w0, #0x1f, 0x1ba0 <generic_tracepoint_process_event+0x1ba0>
     2c0:      	ldurh	w8, [x22, #0xae]
     2c4:      	cbz	w8, 0x39c <generic_tracepoint_process_event+0x39c>
     2c8:      	ldr	x8, [sp, #0x60]
     2cc:      	ldur	w9, [x22, #0xa8]
     2d0:      	add	x8, x8, x9
     2d4:      	str	x8, [sp, #0x60]
     2d8:      	ldurh	w9, [x22, #0xac]
     2dc:      	cbz	w9, 0x304 <generic_tracepoint_process_event+0x304>
     2e0:      	mov	w21, #0x8               // =8
     2e4:      	mov	w9, #0x4                // =4
     2e8:      	add	x10, sp, #0x60
     2ec:      	ldr	x2, [sp, #0x60]
     2f0:      	add	x0, sp, #0x60
     2f4:      	mov	w1, #0x8                // =8
     2f8:      	blr	x9
     2fc:      	mov	w8, #0x5ea0             // =24224
     300:      	tbnz	w0, #0x1f, 0x498 <generic_tracepoint_process_event+0x498>
     304:      	ldurh	w8, [x22, #0xb6]
     308:      	mov	w21, #0x5efc            // =24316
     30c:      	cbz	w8, 0x39c <generic_tracepoint_process_event+0x39c>
     310:      	ldr	x8, [sp, #0x60]
     314:      	ldur	w9, [x22, #0xb0]
     318:      	add	x8, x8, x9
     31c:      	str	x8, [sp, #0x60]
     320:      	ldurh	w9, [x22, #0xb4]
     324:      	cbz	w9, 0x348 <generic_tracepoint_process_event+0x348>
     328:      	mov	w9, #0x8                // =8
     32c:      	mov	w10, #0x4               // =4
     330:      	add	x11, sp, #0x60
     334:      	ldr	x2, [sp, #0x60]
     338:      	add	x0, sp, #0x60
     33c:      	mov	w1, #0x8                // =8
     340:      	blr	x10
     344:      	tbnz	w0, #0x1f, 0x20b0 <generic_tracepoint_process_event+0x20b0>
     348:      	ldurh	w8, [x22, #0xbe]
     34c:      	mov	w21, #0x5efc            // =24316
     350:      	cbz	w8, 0x39c <generic_tracepoint_process_event+0x39c>
     354:      	ldr	x8, [sp, #0x60]
     358:      	ldur	w9, [x22, #0xb8]
     35c:      	add	x8, x8, x9
     360:      	str	x8, [sp, #0x60]
     364:      	ldurh	w9, [x22, #0xbc]
     368:      	cbz	w9, 0x39c <generic_tracepoint_process_event+0x39c>
     36c:      	mov	w9, #0x8                // =8
     370:      	mov	w10, #0x4               // =4
     374:      	add	x11, sp, #0x60
     378:      	ldr	x2, [sp, #0x60]
     37c:      	add	x0, sp, #0x60
     380:      	mov	w1, #0x8                // =8
     384:      	blr	x10
     388:      	mov	w8, #0x5ea0             // =24224
     38c:      	tbz	w0, #0x1f, 0x39c <generic_tracepoint_process_event+0x39c>
     390:      	mov	w21, #0xa               // =10
     394:      	b	0x498 <generic_tracepoint_process_event+0x498>
     398:      	str	xzr, [sp, #0x60]
     39c:      	ldr	x8, [sp, #0x60]
     3a0:      	mov	w22, #0x1fe             // =510
     3a4:      	cmp	w25, #0x15
     3a8:      	str	x8, [sp, #0x50]
     3ac:      	b.gt	0x4b4 <generic_tracepoint_process_event+0x4b4>
     3b0:      	adrp	x23, 0x0 <generic_tracepoint_process_event>
     3b4:      	cmp	w25, #0xb
     3b8:      	ldr	x23, [x23]
     3bc:      	b.gt	0x3e8 <generic_tracepoint_process_event+0x3e8>
     3c0:      	cmp	w25, #0x5
     3c4:      	b.gt	0x40c <generic_tracepoint_process_event+0x40c>
     3c8:      	cmp	w25, #0x3
     3cc:      	b.gt	0x468 <generic_tracepoint_process_event+0x468>
     3d0:      	sub	w8, w25, #0x2
     3d4:      	cmp	w8, #0x2
     3d8:      	b.lo	0x540 <generic_tracepoint_process_event+0x540>
     3dc:      	cmp	w25, #0x1
     3e0:      	b.eq	0x540 <generic_tracepoint_process_event+0x540>
     3e4:      	b	0x580 <generic_tracepoint_process_event+0x580>
     3e8:      	cmp	w25, #0x11
     3ec:      	b.gt	0x430 <generic_tracepoint_process_event+0x430>
     3f0:      	sub	w8, w25, #0xf
     3f4:      	cmp	w8, #0x3
     3f8:      	b.lo	0x584 <generic_tracepoint_process_event+0x584>
     3fc:      	sub	w8, w25, #0xc
     400:      	cmp	w8, #0x2
     404:      	b.lo	0x540 <generic_tracepoint_process_event+0x540>
     408:      	b	0x580 <generic_tracepoint_process_event+0x580>
     40c:      	cmp	w25, #0x9
     410:      	b.gt	0x508 <generic_tracepoint_process_event+0x508>
     414:      	cmp	w25, #0x6
     418:      	b.eq	0x584 <generic_tracepoint_process_event+0x584>
     41c:      	cmp	w25, #0x7
     420:      	b.eq	0x548 <generic_tracepoint_process_event+0x548>
     424:      	cmp	w25, #0x8
     428:      	b.eq	0x578 <generic_tracepoint_process_event+0x578>
     42c:      	b	0x580 <generic_tracepoint_process_event+0x580>
     430:      	cmp	w25, #0x13
     434:      	b.gt	0x450 <generic_tracepoint_process_event+0x450>
     438:      	ldr	x22, [sp, #0x48]
     43c:      	cmp	w25, #0x12
     440:      	b.eq	0x584 <generic_tracepoint_process_event+0x584>
     444:      	cmp	w25, #0x13
     448:      	b.eq	0x560 <generic_tracepoint_process_event+0x560>
     44c:      	b	0x580 <generic_tracepoint_process_event+0x580>
     450:      	cmp	w25, #0x14
     454:      	b.eq	0x484 <generic_tracepoint_process_event+0x484>
     458:      	cmp	w25, #0x15
     45c:      	b.ne	0x580 <generic_tracepoint_process_event+0x580>
     460:      	mov	w22, #0x20              // =32
     464:      	b	0x584 <generic_tracepoint_process_event+0x584>
     468:      	cmp	w25, #0x4
     46c:      	b.eq	0x508 <generic_tracepoint_process_event+0x508>
     470:      	cmp	w25, #0x5
     474:      	b.eq	0x548 <generic_tracepoint_process_event+0x548>
     478:      	b	0x580 <generic_tracepoint_process_event+0x580>
     47c:      	mov	w21, #0x1               // =1
     480:      	b	0x498 <generic_tracepoint_process_event+0x498>
     484:      	mov	w22, #0x98              // =152
     488:      	b	0x584 <generic_tracepoint_process_event+0x584>
     48c:      	mov	w21, #0x2               // =2
     490:      	b	0x498 <generic_tracepoint_process_event+0x498>
     494:      	mov	w21, #0x3               // =3
     498:      	str	w21, [x23, x8]
     49c:      	mov	w21, #0x5efc            // =24316
     4a0:      	ldr	x8, [sp, #0x60]
     4a4:      	mov	w22, #0x1fe             // =510
     4a8:      	cmp	w25, #0x15
     4ac:      	str	x8, [sp, #0x50]
     4b0:      	b.le	0x3b0 <generic_tracepoint_process_event+0x3b0>
     4b4:      	adrp	x23, 0x0 <generic_tracepoint_process_event>
     4b8:      	cmp	w25, #0x20
     4bc:      	ldr	x23, [x23]
     4c0:      	b.le	0x4e4 <generic_tracepoint_process_event+0x4e4>
     4c4:      	cmp	w25, #0x26
     4c8:      	b.gt	0x510 <generic_tracepoint_process_event+0x510>
     4cc:      	sub	w8, w25, #0x21
     4d0:      	cmp	w8, #0x4
     4d4:      	b.lo	0x508 <generic_tracepoint_process_event+0x508>
     4d8:      	cmp	w25, #0x25
     4dc:      	b.eq	0x584 <generic_tracepoint_process_event+0x584>
     4e0:      	b	0x580 <generic_tracepoint_process_event+0x580>
     4e4:      	cmp	w25, #0x1a
     4e8:      	b.gt	0x534 <generic_tracepoint_process_event+0x534>
     4ec:      	cmp	w25, #0x16
     4f0:      	b.eq	0x568 <generic_tracepoint_process_event+0x568>
     4f4:      	cmp	w25, #0x17
     4f8:      	b.eq	0x508 <generic_tracepoint_process_event+0x508>
     4fc:      	cmp	w25, #0x1a
     500:      	b.eq	0x578 <generic_tracepoint_process_event+0x578>
     504:      	b	0x580 <generic_tracepoint_process_event+0x580>
     508:      	mov	w22, #0x8               // =8
     50c:      	b	0x584 <generic_tracepoint_process_event+0x584>
     510:      	cmp	w25, #0x28
     514:      	b.le	0x550 <generic_tracepoint_process_event+0x550>
     518:      	cmp	w25, #0x29
     51c:      	b.eq	0x548 <generic_tracepoint_process_event+0x548>
     520:      	cmp	w25, #0x2a
     524:      	b.eq	0x584 <generic_tracepoint_process_event+0x584>
     528:      	cmp	w25, #0x2b
     52c:      	b.eq	0x560 <generic_tracepoint_process_event+0x560>
     530:      	b	0x580 <generic_tracepoint_process_event+0x580>
     534:      	sub	w8, w25, #0x1d
     538:      	cmp	w8, #0x4
     53c:      	b.hs	0x570 <generic_tracepoint_process_event+0x570>
     540:      	mov	w22, #0x4               // =4
     544:      	b	0x584 <generic_tracepoint_process_event+0x584>
     548:      	mov	w22, #0x40              // =64
     54c:      	b	0x584 <generic_tracepoint_process_event+0x584>
     550:      	cmp	w25, #0x27
     554:      	b.eq	0x568 <generic_tracepoint_process_event+0x568>
     558:      	cmp	w25, #0x28
     55c:      	b.ne	0x580 <generic_tracepoint_process_event+0x580>
     560:      	mov	w22, #0x18              // =24
     564:      	b	0x584 <generic_tracepoint_process_event+0x584>
     568:      	mov	w22, #0x10              // =16
     56c:      	b	0x584 <generic_tracepoint_process_event+0x584>
     570:      	cmp	w25, #0x1b
     574:      	b.ne	0x580 <generic_tracepoint_process_event+0x580>
     578:      	mov	w22, #0x50              // =80
     57c:      	b	0x584 <generic_tracepoint_process_event+0x584>
     580:      	mov	x22, xzr
     584:      	str	wzr, [sp, #0x6c]
     588:      	mov	w8, #0x1                // =1
     58c:      	add	x9, sp, #0x6c
     590:      	add	x1, sp, #0x6c
     594:      	mov	x0, x23
     598:      	blr	x8
     59c:      	cbz	x0, 0x5ec <generic_tracepoint_process_event+0x5ec>
     5a0:      	ldr	x9, [sp, #0x118]
     5a4:      	mov	w8, #0x3ffb             // =16379
     5a8:      	sub	x8, x8, x22
     5ac:      	cmp	x8, x9
     5b0:      	b.ls	0x5ec <generic_tracepoint_process_event+0x5ec>
     5b4:      	add	x22, x0, x24, lsl #2
     5b8:      	mov	w8, #0x5ea0             // =24224
     5bc:      	ldr	x9, [sp, #0x118]
     5c0:      	add	x10, x0, #0x90
     5c4:      	ldr	w8, [x22, x8]
     5c8:      	add	x23, x9, #0x4
     5cc:      	str	w8, [x10, x9]
     5d0:      	add	x9, x0, x24, lsl #3
     5d4:      	str	x23, [x9, #0x5e78]
     5d8:      	cbz	w8, 0x674 <generic_tracepoint_process_event+0x674>
     5dc:      	adrp	x23, 0x0 <generic_tracepoint_process_event>
     5e0:      	mov	w8, #0x4                // =4
     5e4:      	ldr	x23, [x23]
     5e8:      	b	0xd88 <generic_tracepoint_process_event+0xd88>
     5ec:      	ldr	x24, [sp, #0x118]
     5f0:      	str	w24, [x20, #0x4]
     5f4:      	adrp	x22, 0x0 <generic_tracepoint_process_event>
     5f8:      	cmp	w29, #0x3
     5fc:      	ldr	x22, [x22]
     600:      	b.gt	0xda4 <generic_tracepoint_process_event+0xda4>
     604:      	str	wzr, [sp, #0x98]
     608:      	mov	w8, #0x1                // =1
     60c:      	add	x9, sp, #0x98
     610:      	add	x1, sp, #0x98
     614:      	mov	x0, x23
     618:      	blr	x8
     61c:      	cbz	x0, 0xda4 <generic_tracepoint_process_event+0xda4>
     620:      	mov	w8, #0x5ef8             // =24312
     624:      	add	x1, x0, x8
     628:      	adrp	x0, 0x0 <generic_tracepoint_process_event>
     62c:      	mov	w8, #0x1                // =1
     630:      	ldr	x0, [x0]
     634:      	blr	x8
     638:      	cbz	x0, 0xda4 <generic_tracepoint_process_event+0xda4>
     63c:      	add	w8, w29, #0x1
     640:      	and	w9, w8, #0x7
     644:      	add	x9, x0, w9, uxtw #2
     648:      	ldr	w9, [x9, #0x40]
     64c:      	cmn	w9, #0x1
     650:      	b.eq	0xda4 <generic_tracepoint_process_event+0xda4>
     654:      	str	w8, [x20, x21]
     658:      	mov	w8, #0x1                // =1
     65c:      	mov	w9, #0xc                // =12
     660:      	mov	x0, x19
     664:      	mov	x1, x22
     668:      	mov	w2, #0x1                // =1
     66c:      	blr	x9
     670:      	b	0xda4 <generic_tracepoint_process_event+0xda4>
     674:      	ldr	x11, [sp, #0x50]
     678:      	add	x9, sp, #0xe0
     67c:      	add	x8, x10, x23
     680:      	cmp	w25, #0x17
     684:      	stp	x8, x10, [sp, #0x30]
     688:      	str	xzr, [x9, #0x10]
     68c:      	str	x11, [sp, #0x98]
     690:      	b.le	0x6bc <generic_tracepoint_process_event+0x6bc>
     694:      	cmp	w25, #0x18
     698:      	b.eq	0x6d8 <generic_tracepoint_process_event+0x6d8>
     69c:      	cmp	w25, #0x25
     6a0:      	b.eq	0x730 <generic_tracepoint_process_event+0x730>
     6a4:      	cmp	w25, #0x2a
     6a8:      	b.ne	0xabc <generic_tracepoint_process_event+0xabc>
     6ac:      	add	x8, sp, #0x70
     6b0:      	stp	xzr, x11, [sp, #0x70]
     6b4:      	str	x8, [sp, #0x40]
     6b8:      	b	0x798 <generic_tracepoint_process_event+0x798>
     6bc:      	cmp	w25, #0xf
     6c0:      	b.eq	0x768 <generic_tracepoint_process_event+0x768>
     6c4:      	cmp	w25, #0x10
     6c8:      	b.ne	0xabc <generic_tracepoint_process_event+0xabc>
     6cc:      	add	x21, sp, #0x100
     6d0:      	add	x23, sp, #0xe0
     6d4:      	b	0x700 <generic_tracepoint_process_event+0x700>
     6d8:      	add	x21, sp, #0x100
     6dc:      	mov	w8, #0x8                // =8
     6e0:      	mov	w9, #0x4                // =4
     6e4:      	ldr	x2, [sp, #0x98]
     6e8:      	add	x0, sp, #0x100
     6ec:      	mov	w1, #0x8                // =8
     6f0:      	blr	x9
     6f4:      	add	x23, sp, #0xe0
     6f8:      	ldr	x8, [x23, #0x20]
     6fc:      	str	x8, [sp, #0x98]
     700:      	mov	w8, #0x8                // =8
     704:      	mov	w9, #0x4                // =4
     708:      	add	x10, sp, #0x98
     70c:      	add	x0, sp, #0x100
     710:      	add	x2, sp, #0x98
     714:      	mov	w1, #0x8                // =8
     718:      	blr	x9
     71c:      	ldr	x8, [x23, #0x20]
     720:      	mov	w21, #0x5efc            // =24316
     724:      	add	x8, x8, #0x40
     728:      	str	x8, [sp, #0x40]
     72c:      	b	0x798 <generic_tracepoint_process_event+0x798>
     730:      	add	x8, x11, #0x40
     734:      	mov	w9, #0x8                // =8
     738:      	mov	w10, #0x4               // =4
     73c:      	str	x8, [sp, #0x98]
     740:      	add	x11, sp, #0x100
     744:      	add	x0, sp, #0x100
     748:      	mov	w1, #0x8                // =8
     74c:      	ldr	x2, [sp, #0x98]
     750:      	blr	x10
     754:      	add	x8, sp, #0xe0
     758:      	ldr	x8, [x8, #0x20]
     75c:      	add	x8, x8, #0x40
     760:      	str	x8, [sp, #0x40]
     764:      	b	0x798 <generic_tracepoint_process_event+0x798>
     768:      	mov	w8, #0x8                // =8
     76c:      	mov	w9, #0x4                // =4
     770:      	add	x10, sp, #0xf0
     774:      	add	x11, sp, #0x98
     778:      	add	x0, sp, #0xf0
     77c:      	add	x2, sp, #0x98
     780:      	mov	w1, #0x8                // =8
     784:      	blr	x9
     788:      	add	x8, sp, #0xe0
     78c:      	ldr	x8, [x8, #0x10]
     790:      	str	x8, [sp, #0x40]
     794:      	cbz	x8, 0xde0 <generic_tracepoint_process_event+0xde0>
     798:      	str	wzr, [sp, #0x84]
     79c:      	adrp	x0, 0x0 <generic_tracepoint_process_event>
     7a0:      	mov	w8, #0x1                // =1
     7a4:      	add	x9, sp, #0x84
     7a8:      	ldr	x0, [x0]
     7ac:      	add	x1, sp, #0x84
     7b0:      	blr	x8
     7b4:      	mov	x24, x0
     7b8:      	cbz	x0, 0xd78 <generic_tracepoint_process_event+0xd78>
     7bc:      	str	x22, [sp, #0x28]
     7c0:      	mov	w8, #0x23               // =35
     7c4:      	add	x25, x24, #0x1, lsl #12 // =0x1000
     7c8:      	blr	x8
     7cc:      	add	x2, x0, #0xb30
     7d0:      	mov	w22, #0x8               // =8
     7d4:      	add	x8, sp, #0x88
     7d8:      	mov	w9, #0x4                // =4
     7dc:      	add	x0, sp, #0x88
     7e0:      	mov	w1, #0x8                // =8
     7e4:      	mov	w23, #0x4               // =4
     7e8:      	blr	x9
     7ec:      	ldr	x8, [sp, #0x88]
     7f0:      	mov	w9, #0x4                // =4
     7f4:      	add	x0, sp, #0x90
     7f8:      	mov	w1, #0x8                // =8
     7fc:      	str	x8, [sp, #0x10]
     800:      	add	x8, x8, #0x18
     804:      	str	x8, [sp, #0x50]
     808:      	ldr	x8, [sp, #0x40]
     80c:      	add	x2, x8, #0x8
     810:      	add	x8, sp, #0x90
     814:      	str	x2, [sp, #0x48]
     818:      	blr	x9
     81c:      	ldr	x21, [sp, #0x90]
     820:      	add	x8, sp, #0x98
     824:      	add	x0, sp, #0x98
     828:      	mov	w1, #0x8                // =8
     82c:      	add	x2, x21, #0x10
     830:      	blr	x23
     834:      	ldr	x8, [sp, #0x98]
     838:      	str	x19, [sp, #0x20]
     83c:      	cbz	x8, 0x848 <generic_tracepoint_process_event+0x848>
     840:      	mov	w8, #0x1000             // =4096
     844:      	b	0x890 <generic_tracepoint_process_event+0x890>
     848:      	add	x2, x21, #0x18
     84c:      	mov	w8, #0x8                // =8
     850:      	mov	w9, #0x4                // =4
     854:      	add	x10, sp, #0x98
     858:      	add	x0, sp, #0x98
     85c:      	mov	w1, #0x8                // =8
     860:      	blr	x9
     864:      	ldr	x8, [sp, #0x98]
     868:      	cmp	x8, x21
     86c:      	b.eq	0x840 <generic_tracepoint_process_event+0x840>
     870:      	mov	w8, #0x2964             // =10596
     874:      	add	x25, x24, #0xff6
     878:      	strh	w8, [x24, #0xffe]
     87c:      	adrp	x8, 0x0 <generic_tracepoint_process_event>
     880:      	add	x8, x8, #0x0
     884:      	ldr	x8, [x8]
     888:      	str	x8, [x25]
     88c:      	mov	w8, #0xff6              // =4086
     890:      	ldr	x9, [sp, #0x10]
     894:      	stp	xzr, xzr, [sp, #0x98]
     898:      	add	x10, sp, #0x98
     89c:      	add	x0, sp, #0x98
     8a0:      	mov	w1, #0x8                // =8
     8a4:      	mov	w21, #0x4               // =4
     8a8:      	stp	x24, xzr, [sp, #0xa8]
     8ac:      	mov	w24, #0x8               // =8
     8b0:      	add	x23, x10, #0x8
     8b4:      	add	x19, x10, #0x18
     8b8:      	add	x22, x10, #0x20
     8bc:      	add	x2, x9, #0x20
     8c0:      	stp	xzr, xzr, [sp, #0xb8]
     8c4:      	str	x25, [sp, #0x18]
     8c8:      	str	x25, [sp, #0xc8]
     8cc:      	str	w8, [sp, #0xd0]
     8d0:      	mov	w8, #0x4                // =4
     8d4:      	strb	wzr, [sp, #0xd4]
     8d8:      	blr	x8
     8dc:      	ldr	x2, [sp, #0x50]
     8e0:      	mov	w8, #0x4                // =4
     8e4:      	mov	x0, x23
     8e8:      	mov	w1, #0x8                // =8
     8ec:      	blr	x8
     8f0:      	ldr	x2, [sp, #0x48]
     8f4:      	mov	w8, #0x4                // =4
     8f8:      	mov	x0, x19
     8fc:      	mov	w1, #0x8                // =8
     900:      	str	x19, [sp, #0x50]
     904:      	blr	x8
     908:      	ldr	x2, [sp, #0x40]
     90c:      	mov	x0, x22
     910:      	mov	w1, #0x8                // =8
     914:      	blr	x21
     918:      	ldr	x8, [sp, #0xb8]
     91c:      	mov	w23, #0x80              // =128
     920:      	add	x22, sp, #0xe0
     924:      	sub	x8, x8, #0x20
     928:      	str	x8, [sp, #0xc0]
     92c:      	mov	x19, x29
     930:      	ldp	x29, x2, [sp, #0xb0]
     934:      	ldp	x8, x9, [sp, #0x98]
     938:      	cmp	x29, x8
     93c:      	ccmp	x2, x9, #0x0, eq
     940:      	b.eq	0xc3c <generic_tracepoint_process_event+0xc3c>
     944:      	ldr	x21, [sp, #0xc0]
     948:      	mov	w8, #0x4                // =4
     94c:      	add	x9, sp, #0xe0
     950:      	add	x0, sp, #0xe0
     954:      	mov	w1, #0x8                // =8
     958:      	blr	x8
     95c:      	ldr	x8, [x22]
     960:      	add	x25, sp, #0xe0
     964:      	cmp	x29, x8
     968:      	b.eq	0xa60 <generic_tracepoint_process_event+0xa60>
     96c:      	add	x22, x29, #0x18
     970:      	mov	w8, #0x4                // =4
     974:      	add	x9, sp, #0x100
     978:      	add	x0, sp, #0x100
     97c:      	mov	w1, #0x8                // =8
     980:      	mov	x2, x22
     984:      	blr	x8
     988:      	ldr	x8, [x25, #0x20]
     98c:      	cmp	x8, x29
     990:      	b.eq	0xa60 <generic_tracepoint_process_event+0xa60>
     994:      	mov	w8, #0x4                // =4
     998:      	add	x9, sp, #0xe8
     99c:      	add	x0, sp, #0xe8
     9a0:      	mov	w1, #0x8                // =8
     9a4:      	mov	x2, x22
     9a8:      	blr	x8
     9ac:      	add	x2, x29, #0x20
     9b0:      	mov	w8, #0x4                // =4
     9b4:      	mov	w9, #0x10               // =16
     9b8:      	add	x10, sp, #0xf0
     9bc:      	add	x0, sp, #0xf0
     9c0:      	mov	w1, #0x10               // =16
     9c4:      	blr	x8
     9c8:      	ldr	w21, [sp, #0xf4]
     9cc:      	ldr	x8, [sp, #0xa8]
     9d0:      	ldr	x10, [sp, #0xc8]
     9d4:      	sub	x12, x10, x8
     9d8:      	ldr	w22, [sp, #0xd0]
     9dc:      	subs	w10, w21, w22
     9e0:      	ldr	x9, [x25, #0x18]
     9e4:      	csel	w10, wzr, w10, lo
     9e8:      	cmp	w22, w21
     9ec:      	csel	w11, w22, w21, lo
     9f0:      	cinc	w13, w11, hi
     9f4:      	sub	w14, w22, w13
     9f8:      	subs	x12, x12, x13
     9fc:      	str	w14, [sp, #0xd0]
     a00:      	b.lo	0xc44 <generic_tracepoint_process_event+0xc44>
     a04:      	cmp	x12, #0xfff
     a08:      	b.hi	0xc44 <generic_tracepoint_process_event+0xc44>
     a0c:      	cmp	w22, w21
     a10:      	b.ls	0xa1c <generic_tracepoint_process_event+0xa1c>
     a14:      	mov	w13, #0x2f              // =47
     a18:      	strb	w13, [x8, x12]
     a1c:      	add	x29, x8, x12
     a20:      	cmp	w22, w21
     a24:      	add	x2, x9, x10
     a28:      	and	w1, w11, #0xff
     a2c:      	mov	w8, #0x4                // =4
     a30:      	cinc	x0, x29, hi
     a34:      	blr	x8
     a38:      	cmp	w22, w21
     a3c:      	str	x29, [sp, #0xc8]
     a40:      	b.ls	0xc44 <generic_tracepoint_process_event+0xc44>
     a44:      	add	x22, sp, #0xe0
     a48:      	ldr	x8, [x22, #0x8]
     a4c:      	str	x8, [sp, #0xb0]
     a50:      	mov	x29, x19
     a54:      	subs	w23, w23, #0x1
     a58:      	b.ne	0x92c <generic_tracepoint_process_event+0x92c>
     a5c:      	b	0xc58 <generic_tracepoint_process_event+0xc58>
     a60:      	add	x2, x21, #0x10
     a64:      	mov	w8, #0x4                // =4
     a68:      	add	x9, sp, #0x100
     a6c:      	add	x0, sp, #0x100
     a70:      	mov	w1, #0x8                // =8
     a74:      	blr	x8
     a78:      	ldr	x8, [sp, #0xc0]
     a7c:      	ldr	x9, [x25, #0x20]
     a80:      	add	x22, sp, #0xe0
     a84:      	cmp	x8, x9
     a88:      	b.eq	0xc4c <generic_tracepoint_process_event+0xc4c>
     a8c:      	ldr	x0, [sp, #0x50]
     a90:      	add	x2, x21, #0x18
     a94:      	mov	w8, #0x4                // =4
     a98:      	mov	w1, #0x8                // =8
     a9c:      	blr	x8
     aa0:      	ldr	x8, [x22, #0x20]
     aa4:      	add	x9, x8, #0x20
     aa8:      	stp	x9, x8, [sp, #0xb8]
     aac:      	mov	x29, x19
     ab0:      	subs	w23, w23, #0x1
     ab4:      	b.ne	0x92c <generic_tracepoint_process_event+0x92c>
     ab8:      	b	0xc58 <generic_tracepoint_process_event+0xc58>
     abc:      	cmp	w25, #0x28
     ac0:      	b.hi	0xde0 <generic_tracepoint_process_event+0xde0>
     ac4:      	mov	x9, #0x7cf2             // =31986
     ac8:      	mov	w8, #0x1                // =1
     acc:      	movk	x9, #0xf202, lsl #16
     ad0:      	lsl	x8, x8, x25
     ad4:      	movk	x9, #0x1c1, lsl #32
     ad8:      	tst	x8, x9
     adc:      	b.eq	0xde0 <generic_tracepoint_process_event+0xde0>
     ae0:      	add	x8, sp, #0xe0
     ae4:      	str	wzr, [sp, #0xe0]
     ae8:      	adrp	x0, 0x0 <generic_tracepoint_process_event>
     aec:      	add	x9, sp, #0xe0
     af0:      	str	x11, [x8, #0x8]
     af4:      	mov	w8, #0x1                // =1
     af8:      	add	x1, sp, #0xe0
     afc:      	ldr	x0, [x0]
     b00:      	blr	x8
     b04:      	mov	x24, xzr
     b08:      	cbz	x0, 0x171c <generic_tracepoint_process_event+0x171c>
     b0c:      	ldr	x10, [sp, #0x38]
     b10:      	cmp	w25, #0x10
     b14:      	b.gt	0xe58 <generic_tracepoint_process_event+0xe58>
     b18:      	cmp	w25, #0x9
     b1c:      	mov	w9, #0x5ea0             // =24224
     b20:      	b.gt	0xe94 <generic_tracepoint_process_event+0xe94>
     b24:      	adrp	x23, 0x0 <generic_tracepoint_process_event>
     b28:      	cmp	w25, #0x4
     b2c:      	ldr	x23, [x23]
     b30:      	b.le	0x1004 <generic_tracepoint_process_event+0x1004>
     b34:      	cmp	w25, #0x5
     b38:      	b.eq	0x14cc <generic_tracepoint_process_event+0x14cc>
     b3c:      	cmp	w25, #0x6
     b40:      	b.eq	0xf08 <generic_tracepoint_process_event+0xf08>
     b44:      	ldr	x10, [sp, #0x38]
     b48:      	cmp	w25, #0x7
     b4c:      	mov	w9, #0x5ea0             // =24224
     b50:      	str	x0, [sp, #0x50]
     b54:      	b.ne	0xd54 <generic_tracepoint_process_event+0xd54>
     b58:      	add	x8, sp, #0xe0
     b5c:      	ldr	x24, [sp, #0x30]
     b60:      	mov	w21, #0x2               // =2
     b64:      	mov	w1, #0x2                // =2
     b68:      	ldr	x23, [x8, #0x8]
     b6c:      	mov	w8, #0x4                // =4
     b70:      	mov	x25, x22
     b74:      	mov	w22, #0x4               // =4
     b78:      	str	x23, [x24, #0x28]
     b7c:      	add	x0, x24, #0x26
     b80:      	add	x2, x23, #0x10
     b84:      	blr	x8
     b88:      	add	x0, x24, #0x3a
     b8c:      	add	x2, x23, #0x12
     b90:      	mov	w8, #0x1                // =1
     b94:      	mov	w9, #0x4                // =4
     b98:      	mov	w1, #0x1                // =1
     b9c:      	blr	x9
     ba0:      	add	x0, x24, #0x38
     ba4:      	add	x2, x23, #0x21e
     ba8:      	mov	w8, #0x4                // =4
     bac:      	mov	w1, #0x2                // =2
     bb0:      	blr	x8
     bb4:      	add	x0, x24, #0x24
     bb8:      	add	x2, x23, #0x21c
     bbc:      	mov	w8, #0x4                // =4
     bc0:      	mov	w1, #0x2                // =2
     bc4:      	blr	x8
     bc8:      	add	x0, x24, #0x30
     bcc:      	add	x2, x23, #0x214
     bd0:      	mov	w8, #0x4                // =4
     bd4:      	mov	w1, #0x4                // =4
     bd8:      	blr	x8
     bdc:      	add	x0, x24, #0x34
     be0:      	add	x2, x23, #0x210
     be4:      	mov	w1, #0x4                // =4
     be8:      	blr	x22
     bec:      	ldrh	w8, [x24, #0x26]
     bf0:      	mov	x22, x24
     bf4:      	stp	xzr, xzr, [x24]
     bf8:      	cmp	w8, #0xa
     bfc:      	str	xzr, [x24, #0x18]
     c00:      	str	xzr, [x22, #0x10]!
     c04:      	b.eq	0x1c3c <generic_tracepoint_process_event+0x1c3c>
     c08:      	cmp	w8, #0x2
     c0c:      	b.ne	0x1c68 <generic_tracepoint_process_event+0x1c68>
     c10:      	ldr	x0, [sp, #0x30]
     c14:      	add	x2, x23, #0x4
     c18:      	mov	w8, #0x4                // =4
     c1c:      	mov	w1, #0x4                // =4
     c20:      	mov	w21, #0x4               // =4
     c24:      	blr	x8
     c28:      	mov	x0, x22
     c2c:      	mov	w1, #0x4                // =4
     c30:      	mov	x2, x23
     c34:      	blr	x21
     c38:      	b	0x1c68 <generic_tracepoint_process_event+0x1c68>
     c3c:      	mov	w8, #0x1                // =1
     c40:      	strb	w8, [sp, #0xd4]
     c44:      	mov	x29, x19
     c48:      	b	0xc58 <generic_tracepoint_process_event+0xc58>
     c4c:      	mov	w8, #0x1                // =1
     c50:      	mov	x29, x19
     c54:      	strb	w8, [sp, #0xd4]
     c58:      	ldr	x8, [sp, #0xc8]
     c5c:      	ldr	x2, [sp, #0x18]
     c60:      	cmp	x8, x2
     c64:      	b.eq	0xc9c <generic_tracepoint_process_event+0xc9c>
     c68:      	ldrb	w9, [sp, #0xd4]
     c6c:      	ldr	x19, [sp, #0x20]
     c70:      	mov	w11, #0x1000            // =4096
     c74:      	cmp	w9, #0x0
     c78:      	ldr	w9, [sp, #0xd0]
     c7c:      	cset	w10, eq
     c80:      	sub	w11, w11, w9
     c84:      	cmp	w9, #0x0
     c88:      	csel	w9, w11, w9, gt
     c8c:      	cbz	x8, 0xd70 <generic_tracepoint_process_event+0xd70>
     c90:      	lsl	w23, w10, #1
     c94:      	mov	x2, x8
     c98:      	b	0xca8 <generic_tracepoint_process_event+0xca8>
     c9c:      	ldr	x19, [sp, #0x20]
     ca0:      	mov	w9, wzr
     ca4:      	mov	w23, wzr
     ca8:      	ldr	x25, [sp, #0x30]
     cac:      	and	w22, w9, #0xfff
     cb0:      	mov	w8, #0x4                // =4
     cb4:      	mov	w24, #0x4               // =4
     cb8:      	mov	w1, w22
     cbc:      	add	x0, x25, #0x4
     cc0:      	blr	x8
     cc4:      	str	w22, [x25]
     cc8:      	ldr	x2, [sp, #0x48]
     ccc:      	mov	w21, #0x8               // =8
     cd0:      	add	x8, sp, #0x98
     cd4:      	mov	w9, #0x4                // =4
     cd8:      	add	x0, sp, #0x98
     cdc:      	mov	w1, #0x8                // =8
     ce0:      	blr	x9
     ce4:      	ldr	x8, [sp, #0x98]
     ce8:      	add	x9, sp, #0xf0
     cec:      	mov	w10, #0x4               // =4
     cf0:      	add	x0, sp, #0xf0
     cf4:      	mov	w1, #0x8                // =8
     cf8:      	add	x8, x8, #0x30
     cfc:      	ldr	x8, [sp, #0x98]
     d00:      	add	x2, x8, #0x30
     d04:      	blr	x10
     d08:      	add	x11, sp, #0xe0
     d0c:      	mov	w9, #0x2                // =2
     d10:      	add	x10, sp, #0x100
     d14:      	ldr	x8, [x11, #0x10]
     d18:      	add	x0, sp, #0x100
     d1c:      	mov	w1, #0x2                // =2
     d20:      	ldr	x2, [x11, #0x10]
     d24:      	blr	x24
     d28:      	add	x8, x25, x22
     d2c:      	add	w24, w22, #0xa
     d30:      	str	w23, [x8, #0x4]
     d34:      	ldrh	w9, [sp, #0x100]
     d38:      	strh	w9, [x8, #0x8]
     d3c:      	mov	w21, #0x5efc            // =24316
     d40:      	adrp	x23, 0x0 <generic_tracepoint_process_event>
     d44:      	ldr	x23, [x23]
     d48:      	ldr	x22, [sp, #0x28]
     d4c:      	ldr	x10, [sp, #0x38]
     d50:      	mov	w9, #0x5ea0             // =24224
     d54:      	tbz	w24, #0x1f, 0xd80 <generic_tracepoint_process_event+0xd80>
     d58:      	ldr	x24, [sp, #0x118]
     d5c:      	mov	w8, #-0x1               // =-1
     d60:      	str	w8, [x22, x9]
     d64:      	str	w8, [x10, x24]
     d68:      	mov	w8, #0x4                // =4
     d6c:      	b	0xd8c <generic_tracepoint_process_event+0xd8c>
     d70:      	mov	x24, xzr
     d74:      	mov	w21, #0x5efc            // =24316
     d78:      	adrp	x23, 0x0 <generic_tracepoint_process_event>
     d7c:      	ldr	x23, [x23]
     d80:      	and	w8, w24, #0x7fffffff
     d84:      	add	w8, w8, #0x4
     d88:      	ldr	x24, [sp, #0x118]
     d8c:      	add	w24, w8, w24
     d90:      	str	w24, [x20, #0x4]
     d94:      	adrp	x22, 0x0 <generic_tracepoint_process_event>
     d98:      	cmp	w29, #0x3
     d9c:      	ldr	x22, [x22]
     da0:      	b.le	0x604 <generic_tracepoint_process_event+0x604>
     da4:      	str	wzr, [x20, x21]
     da8:      	mov	w8, #0x3                // =3
     dac:      	mov	w9, #0xc                // =12
     db0:      	mov	x0, x19
     db4:      	mov	x1, x22
     db8:      	mov	w2, #0x3                // =3
     dbc:      	blr	x9
     dc0:      	ldp	x20, x19, [sp, #0x150]
     dc4:      	mov	w0, wzr
     dc8:      	ldr	x29, [sp, #0x110]
     dcc:      	ldp	x22, x21, [sp, #0x140]
     dd0:      	ldp	x24, x23, [sp, #0x130]
     dd4:      	ldp	x30, x25, [sp, #0x120]
     dd8:      	add	sp, sp, #0x160
     ddc:      	ret
     de0:      	str	wzr, [sp, #0x88]
     de4:      	adrp	x0, 0x0 <generic_tracepoint_process_event>
     de8:      	mov	w8, #0x1                // =1
     dec:      	add	x9, sp, #0x88
     df0:      	ldr	x0, [x0]
     df4:      	add	x1, sp, #0x88
     df8:      	blr	x8
     dfc:      	mov	x24, xzr
     e00:      	str	x22, [sp, #0x28]
     e04:      	cbz	x0, 0x2448 <generic_tracepoint_process_event+0x2448>
     e08:      	cmp	w25, #0x19
     e0c:      	b.gt	0xf6c <generic_tracepoint_process_event+0xf6c>
     e10:      	cmp	w25, #0x12
     e14:      	b.le	0xfa0 <generic_tracepoint_process_event+0xfa0>
     e18:      	cmp	w25, #0x14
     e1c:      	b.le	0x1358 <generic_tracepoint_process_event+0x1358>
     e20:      	cmp	w25, #0x15
     e24:      	b.eq	0x1960 <generic_tracepoint_process_event+0x1960>
     e28:      	cmp	w25, #0x16
     e2c:      	b.eq	0x1900 <generic_tracepoint_process_event+0x1900>
     e30:      	ldr	x10, [sp, #0x38]
     e34:      	cmp	w25, #0x17
     e38:      	mov	w21, #0x5efc            // =24316
     e3c:      	mov	w9, #0x5ea0             // =24224
     e40:      	b.ne	0x2450 <generic_tracepoint_process_event+0x2450>
     e44:      	ldr	x8, [sp, #0x30]
     e48:      	ldr	x11, [sp, #0x50]
     e4c:      	mov	w24, #0x8               // =8
     e50:      	stp	w11, wzr, [x8]
     e54:      	b	0x2450 <generic_tracepoint_process_event+0x2450>
     e58:      	cmp	w25, #0x1e
     e5c:      	b.gt	0xf2c <generic_tracepoint_process_event+0xf2c>
     e60:      	cmp	w25, #0x1c
     e64:      	b.gt	0x1054 <generic_tracepoint_process_event+0x1054>
     e68:      	cmp	w25, #0x11
     e6c:      	b.eq	0x162c <generic_tracepoint_process_event+0x162c>
     e70:      	cmp	w25, #0x19
     e74:      	str	x0, [sp, #0x50]
     e78:      	b.eq	0x140c <generic_tracepoint_process_event+0x140c>
     e7c:      	adrp	x23, 0x0 <generic_tracepoint_process_event>
     e80:      	cmp	w25, #0x1c
     e84:      	mov	w9, #0x5ea0             // =24224
     e88:      	ldr	x23, [x23]
     e8c:      	b.eq	0x1014 <generic_tracepoint_process_event+0x1014>
     e90:      	b	0xd54 <generic_tracepoint_process_event+0xd54>
     e94:      	adrp	x23, 0x0 <generic_tracepoint_process_event>
     e98:      	sub	w8, w25, #0xa
     e9c:      	ldr	x23, [x23]
     ea0:      	cmp	w8, #0x2
     ea4:      	b.lo	0x1014 <generic_tracepoint_process_event+0x1014>
     ea8:      	sub	w8, w25, #0xc
     eac:      	cmp	w8, #0x2
     eb0:      	b.lo	0x1034 <generic_tracepoint_process_event+0x1034>
     eb4:      	cmp	w25, #0xe
     eb8:      	b.ne	0xd54 <generic_tracepoint_process_event+0xd54>
     ebc:      	mov	w21, #0x8               // =8
     ec0:      	add	x8, sp, #0x98
     ec4:      	add	x23, sp, #0xe8
     ec8:      	mov	w9, #0x4                // =4
     ecc:      	add	x0, sp, #0x98
     ed0:      	add	x2, sp, #0xe8
     ed4:      	mov	w1, #0x8                // =8
     ed8:      	mov	x24, x22
     edc:      	mov	w22, #0x4               // =4
     ee0:      	blr	x9
     ee4:      	ldr	x8, [sp, #0x98]
     ee8:      	adrp	x23, 0x0 <generic_tracepoint_process_event>
     eec:      	add	x0, sp, #0xe8
     ef0:      	mov	w1, #0x8                // =8
     ef4:      	ldr	x23, [x23]
     ef8:      	ldr	x2, [sp, #0x98]
     efc:      	mov	w21, #0x5efc            // =24316
     f00:      	blr	x22
     f04:      	mov	x22, x24
     f08:      	ldr	x25, [sp, #0x30]
     f0c:      	add	x8, sp, #0xe0
     f10:      	mov	w9, #0x2d               // =45
     f14:      	mov	w1, #0x1ff              // =511
     f18:      	ldr	x2, [x8, #0x8]
     f1c:      	mov	w8, #0x1ff              // =511
     f20:      	add	x0, x25, #0x4
     f24:      	blr	x9
     f28:      	b	0x1300 <generic_tracepoint_process_event+0x1300>
     f2c:      	cmp	w25, #0x26
     f30:      	b.gt	0x1088 <generic_tracepoint_process_event+0x1088>
     f34:      	adrp	x23, 0x0 <generic_tracepoint_process_event>
     f38:      	sub	w8, w25, #0x1f
     f3c:      	ldr	x23, [x23]
     f40:      	cmp	w8, #0x2
     f44:      	b.hs	0x12d0 <generic_tracepoint_process_event+0x12d0>
     f48:      	ldr	x0, [sp, #0x30]
     f4c:      	mov	w8, #0x1                // =1
     f50:      	add	x9, sp, #0xe8
     f54:      	mov	w10, #0x4               // =4
     f58:      	add	x2, sp, #0xe8
     f5c:      	mov	w1, #0x1                // =1
     f60:      	mov	w24, #0x4               // =4
     f64:      	blr	x10
     f68:      	b	0xd4c <generic_tracepoint_process_event+0xd4c>
     f6c:      	cmp	w25, #0x20
     f70:      	b.le	0x1250 <generic_tracepoint_process_event+0x1250>
     f74:      	ldr	x22, [sp, #0x30]
     f78:      	sub	w8, w25, #0x21
     f7c:      	cmp	w8, #0x4
     f80:      	b.hs	0x112c <generic_tracepoint_process_event+0x112c>
     f84:      	ldr	x2, [sp, #0x50]
     f88:      	mov	w24, #0x8               // =8
     f8c:      	mov	w8, #0x4                // =4
     f90:      	mov	x0, x22
     f94:      	mov	w1, #0x8                // =8
     f98:      	blr	x8
     f9c:      	b	0x2448 <generic_tracepoint_process_event+0x2448>
     fa0:      	ldr	x8, [sp, #0x48]
     fa4:      	cmp	w25, #0x7
     fa8:      	and	x8, x8, #0xffffffff
     fac:      	b.gt	0x1318 <generic_tracepoint_process_event+0x1318>
     fb0:      	cmp	w25, #0x2
     fb4:      	b.eq	0x1730 <generic_tracepoint_process_event+0x1730>
     fb8:      	ldr	x10, [sp, #0x38]
     fbc:      	cmp	w25, #0x3
     fc0:      	mov	w9, #0x5ea0             // =24224
     fc4:      	b.ne	0x2450 <generic_tracepoint_process_event+0x2450>
     fc8:      	add	x24, x0, #0x90
     fcc:      	and	w9, w8, #0xf
     fd0:      	mov	x22, x0
     fd4:      	str	x29, [sp, #0x48]
     fd8:      	add	x29, x24, x23
     fdc:      	cmp	w9, #0x2
     fe0:      	b.le	0x1ddc <generic_tracepoint_process_event+0x1ddc>
     fe4:      	cmp	w9, #0x3
     fe8:      	b.eq	0x1f48 <generic_tracepoint_process_event+0x1f48>
     fec:      	cmp	w9, #0x4
     ff0:      	b.eq	0x1f50 <generic_tracepoint_process_event+0x1f50>
     ff4:      	cmp	w9, #0x5
     ff8:      	b.ne	0x1fa0 <generic_tracepoint_process_event+0x1fa0>
     ffc:      	mov	w9, #0x5e70             // =24176
    1000:      	b	0x1f5c <generic_tracepoint_process_event+0x1f5c>
    1004:      	cmp	w25, #0x1
    1008:      	b.eq	0x1034 <generic_tracepoint_process_event+0x1034>
    100c:      	cmp	w25, #0x4
    1010:      	b.ne	0xd54 <generic_tracepoint_process_event+0xd54>
    1014:      	ldr	x0, [sp, #0x30]
    1018:      	mov	w24, #0x8               // =8
    101c:      	mov	w8, #0x4                // =4
    1020:      	add	x9, sp, #0xe8
    1024:      	add	x2, sp, #0xe8
    1028:      	mov	w1, #0x8                // =8
    102c:      	blr	x8
    1030:      	b	0xd4c <generic_tracepoint_process_event+0xd4c>
    1034:      	ldr	x0, [sp, #0x30]
    1038:      	add	x8, sp, #0xe8
    103c:      	mov	w9, #0x4                // =4
    1040:      	add	x2, sp, #0xe8
    1044:      	mov	w1, #0x4                // =4
    1048:      	mov	w24, #0x4               // =4
    104c:      	blr	x9
    1050:      	b	0xd4c <generic_tracepoint_process_event+0xd4c>
    1054:      	ldr	x0, [sp, #0x30]
    1058:      	mov	w8, #0x2                // =2
    105c:      	add	x9, sp, #0xe8
    1060:      	mov	w10, #0x4               // =4
    1064:      	add	x2, sp, #0xe8
    1068:      	mov	w1, #0x2                // =2
    106c:      	mov	w24, #0x4               // =4
    1070:      	blr	x10
    1074:      	adrp	x23, 0x1000 <generic_tracepoint_process_event+0x1000>
    1078:      	ldr	x10, [sp, #0x38]
    107c:      	mov	w9, #0x5ea0             // =24224
    1080:      	ldr	x23, [x23]
    1084:      	b	0xd54 <generic_tracepoint_process_event+0xd54>
    1088:      	cmp	w25, #0x27
    108c:      	b.eq	0x16e4 <generic_tracepoint_process_event+0x16e4>
    1090:      	adrp	x23, 0x1000 <generic_tracepoint_process_event+0x1000>
    1094:      	cmp	w25, #0x28
    1098:      	mov	w9, #0x5ea0             // =24224
    109c:      	ldr	x23, [x23]
    10a0:      	b.ne	0xd54 <generic_tracepoint_process_event+0xd54>
    10a4:      	ldr	x24, [sp, #0x30]
    10a8:      	add	x8, sp, #0xe0
    10ac:      	mov	x25, x22
    10b0:      	mov	w9, #0x4                // =4
    10b4:      	ldr	x22, [x8, #0x8]
    10b8:      	mov	w8, #0x2                // =2
    10bc:      	mov	w1, #0x2                // =2
    10c0:      	mov	x0, x24
    10c4:      	stp	xzr, xzr, [x24, #0x8]
    10c8:      	str	xzr, [x24]
    10cc:      	mov	x2, x22
    10d0:      	blr	x9
    10d4:      	tbnz	x0, #0x3f, 0x1e48 <generic_tracepoint_process_event+0x1e48>
    10d8:      	ldrh	w8, [x24]
    10dc:      	cmp	w8, #0xa
    10e0:      	b.eq	0x1df4 <generic_tracepoint_process_event+0x1df4>
    10e4:      	cmp	w8, #0x2
    10e8:      	b.ne	0x1e28 <generic_tracepoint_process_event+0x1e28>
    10ec:      	add	x2, x22, #0x4
    10f0:      	add	x8, sp, #0x98
    10f4:      	mov	w9, #0x4                // =4
    10f8:      	add	x0, sp, #0x98
    10fc:      	mov	w1, #0x4                // =4
    1100:      	mov	w21, #0x4               // =4
    1104:      	blr	x9
    1108:      	ldr	w8, [sp, #0x98]
    110c:      	ldr	x9, [sp, #0x30]
    1110:      	add	x2, x22, #0x2
    1114:      	add	x0, x9, #0x2
    1118:      	str	x8, [x9, #0x8]
    111c:      	mov	w8, #0x2                // =2
    1120:      	b	0x1e20 <generic_tracepoint_process_event+0x1e20>
    1124:      	mov	w21, #0x5               // =5
    1128:      	b	0x498 <generic_tracepoint_process_event+0x498>
    112c:      	cmp	w25, #0x2b
    1130:      	str	x0, [sp, #0x48]
    1134:      	b.eq	0x1a1c <generic_tracepoint_process_event+0x1a1c>
    1138:      	ldr	x10, [sp, #0x38]
    113c:      	cmp	w25, #0x29
    1140:      	mov	w21, #0x5efc            // =24316
    1144:      	mov	w9, #0x5ea0             // =24224
    1148:      	b.ne	0x2450 <generic_tracepoint_process_event+0x2450>
    114c:      	ldr	x8, [sp, #0x50]
    1150:      	mov	x25, x10
    1154:      	mov	w9, #0x4                // =4
    1158:      	add	x10, sp, #0x98
    115c:      	add	x0, sp, #0x98
    1160:      	mov	w1, #0x8                // =8
    1164:      	add	x2, x8, #0x18
    1168:      	mov	w8, #0x8                // =8
    116c:      	blr	x9
    1170:      	ldr	x23, [sp, #0x98]
    1174:      	cbz	x23, 0x1ef0 <generic_tracepoint_process_event+0x1ef0>
    1178:      	ldr	x24, [sp, #0x30]
    117c:      	add	x2, x23, #0x10
    1180:      	mov	w21, #0x2               // =2
    1184:      	mov	w8, #0x4                // =4
    1188:      	str	x23, [x24, #0x28]
    118c:      	add	x0, x24, #0x26
    1190:      	mov	w1, #0x2                // =2
    1194:      	mov	w22, #0x4               // =4
    1198:      	blr	x8
    119c:      	add	x0, x24, #0x3a
    11a0:      	add	x2, x23, #0x12
    11a4:      	mov	w8, #0x1                // =1
    11a8:      	mov	w9, #0x4                // =4
    11ac:      	mov	w1, #0x1                // =1
    11b0:      	blr	x9
    11b4:      	add	x0, x24, #0x38
    11b8:      	add	x2, x23, #0x21e
    11bc:      	mov	w8, #0x4                // =4
    11c0:      	mov	w1, #0x2                // =2
    11c4:      	blr	x8
    11c8:      	add	x0, x24, #0x24
    11cc:      	add	x2, x23, #0x21c
    11d0:      	mov	w8, #0x4                // =4
    11d4:      	mov	w1, #0x2                // =2
    11d8:      	blr	x8
    11dc:      	add	x0, x24, #0x30
    11e0:      	add	x2, x23, #0x214
    11e4:      	mov	w8, #0x4                // =4
    11e8:      	mov	w1, #0x4                // =4
    11ec:      	blr	x8
    11f0:      	add	x0, x24, #0x34
    11f4:      	add	x2, x23, #0x210
    11f8:      	mov	w1, #0x4                // =4
    11fc:      	blr	x22
    1200:      	ldrh	w8, [x24, #0x26]
    1204:      	mov	x22, x24
    1208:      	stp	xzr, xzr, [x24]
    120c:      	cmp	w8, #0xa
    1210:      	str	xzr, [x24, #0x18]
    1214:      	str	xzr, [x22, #0x10]!
    1218:      	b.eq	0x1e80 <generic_tracepoint_process_event+0x1e80>
    121c:      	cmp	w8, #0x2
    1220:      	b.ne	0x1eac <generic_tracepoint_process_event+0x1eac>
    1224:      	ldr	x0, [sp, #0x30]
    1228:      	add	x2, x23, #0x4
    122c:      	mov	w8, #0x4                // =4
    1230:      	mov	w1, #0x4                // =4
    1234:      	mov	w21, #0x4               // =4
    1238:      	blr	x8
    123c:      	mov	x0, x22
    1240:      	mov	w1, #0x4                // =4
    1244:      	mov	x2, x23
    1248:      	blr	x21
    124c:      	b	0x1eac <generic_tracepoint_process_event+0x1eac>
    1250:      	cmp	w25, #0x1a
    1254:      	b.eq	0x1aa8 <generic_tracepoint_process_event+0x1aa8>
    1258:      	ldr	x10, [sp, #0x38]
    125c:      	cmp	w25, #0x1b
    1260:      	mov	w9, #0x5ea0             // =24224
    1264:      	b.ne	0x2450 <generic_tracepoint_process_event+0x2450>
    1268:      	mov	x22, x10
    126c:      	ldr	x10, [sp, #0x30]
    1270:      	ldr	x8, [sp, #0x50]
    1274:      	mov	w9, #0x2d               // =45
    1278:      	mov	w1, #0x3f               // =63
    127c:      	mov	x0, x10
    1280:      	str	xzr, [x10, #0x18]
    1284:      	stp	xzr, xzr, [x10, #0x40]
    1288:      	stp	xzr, xzr, [x10, #0x30]
    128c:      	add	x2, x8, #0x18
    1290:      	mov	w8, #0x3f               // =63
    1294:      	stp	xzr, xzr, [x10, #0x20]
    1298:      	stp	xzr, xzr, [x10]
    129c:      	str	xzr, [x0, #0x10]!
    12a0:      	blr	x9
    12a4:      	tbnz	x0, #0x3f, 0x1e54 <generic_tracepoint_process_event+0x1e54>
    12a8:      	ldr	x8, [sp, #0x30]
    12ac:      	mov	w9, #0x4                // =4
    12b0:      	mov	w1, #0x8                // =8
    12b4:      	add	x0, x8, #0x8
    12b8:      	ldr	x8, [sp, #0x50]
    12bc:      	add	x2, x8, #0x360
    12c0:      	mov	w8, #0x8                // =8
    12c4:      	blr	x9
    12c8:      	mov	w24, #0x50              // =80
    12cc:      	b	0x1e58 <generic_tracepoint_process_event+0x1e58>
    12d0:      	cmp	w25, #0x26
    12d4:      	mov	w9, #0x5ea0             // =24224
    12d8:      	b.ne	0xd54 <generic_tracepoint_process_event+0xd54>
    12dc:      	add	x8, sp, #0xe0
    12e0:      	ldr	x25, [sp, #0x30]
    12e4:      	ldr	x8, [x8, #0x8]
    12e8:      	add	x0, x25, #0x4
    12ec:      	add	x2, x19, w8, uxth
    12f0:      	ubfx	w8, w8, #16, #12
    12f4:      	add	w1, w8, #0x1
    12f8:      	mov	w8, #0x2d               // =45
    12fc:      	blr	x8
    1300:      	mov	x24, x0
    1304:      	tbnz	x0, #0x3f, 0xd4c <generic_tracepoint_process_event+0xd4c>
    1308:      	sub	w8, w24, #0x1
    130c:      	add	x24, x24, #0x3
    1310:      	str	w8, [x25]
    1314:      	b	0xd4c <generic_tracepoint_process_event+0xd4c>
    1318:      	cmp	w25, #0x8
    131c:      	b.eq	0x1780 <generic_tracepoint_process_event+0x1780>
    1320:      	ldr	x10, [sp, #0x38]
    1324:      	cmp	w25, #0x12
    1328:      	mov	w21, #0x5efc            // =24316
    132c:      	mov	w9, #0x5ea0             // =24224
    1330:      	b.ne	0x2450 <generic_tracepoint_process_event+0x2450>
    1334:      	ldr	x0, [sp, #0x30]
    1338:      	ldr	x2, [sp, #0x50]
    133c:      	and	x24, x8, #0x3ff
    1340:      	mov	w8, #0x4                // =4
    1344:      	mov	x22, x10
    1348:      	mov	w1, w24
    134c:      	blr	x8
    1350:      	mov	x10, x22
    1354:      	b	0x244c <generic_tracepoint_process_event+0x244c>
    1358:      	cmp	w25, #0x13
    135c:      	b.eq	0x19d8 <generic_tracepoint_process_event+0x19d8>
    1360:      	ldr	x10, [sp, #0x38]
    1364:      	cmp	w25, #0x14
    1368:      	mov	w21, #0x5efc            // =24316
    136c:      	mov	w9, #0x5ea0             // =24224
    1370:      	b.ne	0x2450 <generic_tracepoint_process_event+0x2450>
    1374:      	ldr	x25, [sp, #0x50]
    1378:      	str	xzr, [sp, #0x98]
    137c:      	mov	w11, #0x8               // =8
    1380:      	add	x8, sp, #0x98
    1384:      	mov	w9, #0x4                // =4
    1388:      	add	x0, sp, #0x98
    138c:      	mov	w1, #0x8                // =8
    1390:      	mov	w23, #0x4               // =4
    1394:      	add	x2, x25, #0x110
    1398:      	add	x22, x25, #0xd8
    139c:      	blr	x9
    13a0:      	ldr	x8, [sp, #0x98]
    13a4:      	mov	w9, #0x80               // =128
    13a8:      	mov	w10, #0x2d              // =45
    13ac:      	ldr	x24, [sp, #0x30]
    13b0:      	mov	w1, #0x80               // =128
    13b4:      	mov	x0, x24
    13b8:      	ldr	x2, [sp, #0x98]
    13bc:      	blr	x10
    13c0:      	add	x0, x24, #0x90
    13c4:      	mov	w8, #0x4                // =4
    13c8:      	mov	w1, #0x4                // =4
    13cc:      	mov	x2, x22
    13d0:      	blr	x8
    13d4:      	add	x0, x24, #0x80
    13d8:      	add	x2, x25, #0xe0
    13dc:      	mov	w8, #0x4                // =4
    13e0:      	mov	w22, #0x8               // =8
    13e4:      	mov	w1, #0x8                // =8
    13e8:      	blr	x8
    13ec:      	add	x0, x24, #0x88
    13f0:      	add	x2, x25, #0x118
    13f4:      	mov	w1, #0x8                // =8
    13f8:      	blr	x23
    13fc:      	ldr	x10, [sp, #0x38]
    1400:      	mov	w9, #0x5ea0             // =24224
    1404:      	mov	w24, #0x98              // =152
    1408:      	b	0x2450 <generic_tracepoint_process_event+0x2450>
    140c:      	add	x25, sp, #0xe0
    1410:      	str	x22, [sp, #0x28]
    1414:      	mov	w8, #0x1                // =1
    1418:      	mov	w9, #0x4                // =4
    141c:      	ldr	x22, [x25, #0x8]
    1420:      	add	x10, sp, #0x90
    1424:      	add	x0, sp, #0x90
    1428:      	mov	w1, #0x1                // =1
    142c:      	mov	x2, x22
    1430:      	blr	x9
    1434:      	ldrb	w8, [sp, #0x90]
    1438:      	cmp	w8, #0x1
    143c:      	b.ne	0x1b84 <generic_tracepoint_process_event+0x1b84>
    1440:      	add	x2, x22, #0x10
    1444:      	mov	w21, #0x8               // =8
    1448:      	add	x8, sp, #0x98
    144c:      	mov	w9, #0x4                // =4
    1450:      	add	x0, sp, #0x98
    1454:      	mov	w1, #0x8                // =8
    1458:      	mov	w24, #0x4               // =4
    145c:      	blr	x9
    1460:      	ldr	x2, [sp, #0x98]
    1464:      	add	x8, sp, #0xf0
    1468:      	mov	w9, #0x4                // =4
    146c:      	add	x0, sp, #0xf0
    1470:      	mov	w1, #0x8                // =8
    1474:      	blr	x9
    1478:      	ldr	x8, [sp, #0x98]
    147c:      	mov	w9, #0x4                // =4
    1480:      	add	x0, sp, #0x100
    1484:      	mov	w1, #0x8                // =8
    1488:      	add	x2, x8, #0x8
    148c:      	add	x8, sp, #0x100
    1490:      	blr	x9
    1494:      	ldr	x2, [x25, #0x10]
    1498:      	ldr	x25, [x25, #0x20]
    149c:      	cmp	x25, #0xfff
    14a0:      	ldr	x8, [sp, #0x50]
    14a4:      	add	x21, x8, x23
    14a8:      	mov	w8, #0xfff              // =4095
    14ac:      	csel	x22, x25, x8, lo
    14b0:      	add	x0, x21, #0x98
    14b4:      	mov	w1, w22
    14b8:      	blr	x24
    14bc:      	tbnz	w0, #0x1f, 0x1dcc <generic_tracepoint_process_event+0x1dcc>
    14c0:      	stp	w25, w22, [x21, #0x90]
    14c4:      	add	x24, x22, #0x8
    14c8:      	b	0xd3c <generic_tracepoint_process_event+0xd3c>
    14cc:      	add	x8, sp, #0xe0
    14d0:      	stp	x19, x22, [sp, #0x20]
    14d4:      	mov	w1, #0x4                // =4
    14d8:      	mov	w23, #0x4               // =4
    14dc:      	ldr	x21, [sp, #0x30]
    14e0:      	add	x0, x21, #0x28
    14e4:      	ldr	x19, [x8, #0x8]
    14e8:      	mov	w8, #0x4                // =4
    14ec:      	add	x2, x19, #0x98
    14f0:      	blr	x8
    14f4:      	add	x0, x21, #0x2c
    14f8:      	add	x2, x19, #0x70
    14fc:      	mov	w8, #0x4                // =4
    1500:      	mov	w1, #0x4                // =4
    1504:      	blr	x8
    1508:      	add	x0, x21, #0x30
    150c:      	add	x2, x19, #0x90
    1510:      	mov	w8, #0x4                // =4
    1514:      	mov	w1, #0x4                // =4
    1518:      	blr	x8
    151c:      	add	x0, x21, #0x34
    1520:      	add	x2, x19, #0xa8
    1524:      	mov	w8, #0x4                // =4
    1528:      	mov	w1, #0x4                // =4
    152c:      	blr	x8
    1530:      	str	xzr, [sp, #0x98]
    1534:      	add	x2, x19, #0xc8
    1538:      	mov	w8, #0x8                // =8
    153c:      	add	x9, sp, #0x98
    1540:      	mov	w10, #0x4               // =4
    1544:      	add	x0, sp, #0x98
    1548:      	mov	w1, #0x8                // =8
    154c:      	blr	x10
    1550:      	add	x2, x19, #0xb8
    1554:      	mov	w8, #0x2                // =2
    1558:      	add	x9, sp, #0x90
    155c:      	mov	w10, #0x4               // =4
    1560:      	add	x0, sp, #0x90
    1564:      	mov	w1, #0x2                // =2
    1568:      	blr	x10
    156c:      	ldr	x8, [sp, #0x98]
    1570:      	ldrh	w9, [sp, #0x90]
    1574:      	add	x0, sp, #0xdc
    1578:      	mov	w1, #0x1                // =1
    157c:      	add	x22, x8, x9
    1580:      	mov	w8, #0x1                // =1
    1584:      	add	x9, sp, #0xdc
    1588:      	mov	x2, x22
    158c:      	blr	x23
    1590:      	ldrb	w8, [sp, #0xdc]
    1594:      	lsr	w8, w8, #4
    1598:      	cmp	w8, #0x6
    159c:      	b.eq	0x1bac <generic_tracepoint_process_event+0x1bac>
    15a0:      	cmp	w8, #0x4
    15a4:      	b.ne	0x2b48 <generic_tracepoint_process_event+0x2b48>
    15a8:      	add	x2, x22, #0x9
    15ac:      	mov	w8, #0x1                // =1
    15b0:      	add	x9, sp, #0x84
    15b4:      	mov	w10, #0x4               // =4
    15b8:      	add	x0, sp, #0x84
    15bc:      	mov	w1, #0x1                // =1
    15c0:      	mov	w24, #0x4               // =4
    15c4:      	blr	x10
    15c8:      	ldr	x0, [sp, #0x30]
    15cc:      	ldrb	w8, [sp, #0x84]
    15d0:      	mov	w21, #0x2               // =2
    15d4:      	add	x2, x22, #0xc
    15d8:      	mov	w1, #0x4                // =4
    15dc:      	mov	x23, x0
    15e0:      	strh	w8, [x0, #0x24]
    15e4:      	strh	w21, [x0, #0x26]
    15e8:      	stp	xzr, xzr, [x0]
    15ec:      	str	xzr, [x0, #0x18]
    15f0:      	mov	w8, #0x4                // =4
    15f4:      	str	xzr, [x23, #0x10]!
    15f8:      	blr	x8
    15fc:      	add	x2, x22, #0x10
    1600:      	mov	w8, #0x4                // =4
    1604:      	mov	x0, x23
    1608:      	mov	w1, #0x4                // =4
    160c:      	blr	x8
    1610:      	add	x2, x19, #0xb6
    1614:      	add	x8, sp, #0x88
    1618:      	add	x0, sp, #0x88
    161c:      	mov	w1, #0x2                // =2
    1620:      	blr	x24
    1624:      	ldrb	w22, [sp, #0x84]
    1628:      	b	0x2a0c <generic_tracepoint_process_event+0x2a0c>
    162c:      	str	xzr, [sp, #0xa0]
    1630:      	mov	w8, #0xe                // =14
    1634:      	mov	x25, x22
    1638:      	blr	x8
    163c:      	lsr	x8, x0, #32
    1640:      	add	x9, sp, #0xf0
    1644:      	add	x10, sp, #0xe8
    1648:      	str	x8, [sp, #0x98]
    164c:      	mov	w8, #0x4                // =4
    1650:      	add	x0, sp, #0xf0
    1654:      	add	x2, sp, #0xe8
    1658:      	mov	w1, #0x4                // =4
    165c:      	blr	x8
    1660:      	ldr	w8, [sp, #0xf0]
    1664:      	adrp	x0, 0x1000 <generic_tracepoint_process_event+0x1000>
    1668:      	add	x9, sp, #0x98
    166c:      	add	x1, sp, #0x98
    1670:      	str	w8, [sp, #0xa0]
    1674:      	mov	w8, #0x1                // =1
    1678:      	ldr	x0, [x0]
    167c:      	blr	x8
    1680:      	cbz	x0, 0x1b98 <generic_tracepoint_process_event+0x1b98>
    1684:      	ldr	x24, [sp, #0x30]
    1688:      	ldr	w21, [x0]
    168c:      	add	x8, sp, #0xf0
    1690:      	mov	w9, #0x4                // =4
    1694:      	add	x2, sp, #0xf0
    1698:      	mov	x22, x0
    169c:      	mov	w1, #0x4                // =4
    16a0:      	mov	w23, #0x4               // =4
    16a4:      	mov	x0, x24
    16a8:      	blr	x9
    16ac:      	and	x21, x21, #0xfff
    16b0:      	add	x0, x24, #0x4
    16b4:      	mov	w8, #0x4                // =4
    16b8:      	mov	x2, x22
    16bc:      	add	x1, x21, #0x4
    16c0:      	blr	x8
    16c4:      	add	w21, w21, #0x8
    16c8:      	mov	w1, #0x4                // =4
    16cc:      	add	x8, x21, x22
    16d0:      	add	x0, x24, x21
    16d4:      	sub	x2, x8, #0x4
    16d8:      	blr	x23
    16dc:      	add	x24, x21, #0x4
    16e0:      	b	0x1cf4 <generic_tracepoint_process_event+0x1cf4>
    16e4:      	add	x8, sp, #0xe0
    16e8:      	ldr	x23, [sp, #0x30]
    16ec:      	mov	w9, #0x2d               // =45
    16f0:      	mov	w1, #0x11               // =17
    16f4:      	ldr	x8, [x8, #0x8]
    16f8:      	add	x0, x23, #0x4
    16fc:      	add	x2, x8, #0x118
    1700:      	mov	w8, #0x11               // =17
    1704:      	blr	x9
    1708:      	mov	x24, x0
    170c:      	tbnz	x0, #0x3f, 0x171c <generic_tracepoint_process_event+0x171c>
    1710:      	sub	w8, w24, #0x1
    1714:      	add	x24, x24, #0x3
    1718:      	str	w8, [x23]
    171c:      	adrp	x23, 0x1000 <generic_tracepoint_process_event+0x1000>
    1720:      	ldr	x23, [x23]
    1724:      	b	0xd4c <generic_tracepoint_process_event+0xd4c>
    1728:      	mov	w21, #0x6               // =6
    172c:      	b	0x498 <generic_tracepoint_process_event+0x498>
    1730:      	add	x8, x0, x23
    1734:      	mov	x22, x0
    1738:      	add	x23, x8, #0x90
    173c:      	add	x8, sp, #0xe0
    1740:      	str	xzr, [x8]
    1744:      	ldr	x8, [sp, #0x48]
    1748:      	tbnz	w8, #0x4, 0x1d04 <generic_tracepoint_process_event+0x1d04>
    174c:      	ldr	x9, [sp, #0x48]
    1750:      	mov	x8, xzr
    1754:      	and	w9, w9, #0xf
    1758:      	cmp	w9, #0x2
    175c:      	b.le	0x1e68 <generic_tracepoint_process_event+0x1e68>
    1760:      	cmp	w9, #0x3
    1764:      	b.eq	0x2120 <generic_tracepoint_process_event+0x2120>
    1768:      	cmp	w9, #0x4
    176c:      	b.eq	0x2128 <generic_tracepoint_process_event+0x2128>
    1770:      	cmp	w9, #0x5
    1774:      	b.ne	0x213c <generic_tracepoint_process_event+0x213c>
    1778:      	mov	w8, #0x5e70             // =24176
    177c:      	b	0x2134 <generic_tracepoint_process_event+0x2134>
    1780:      	ldr	x23, [sp, #0x30]
    1784:      	ldr	x24, [sp, #0x50]
    1788:      	mov	w1, #0x4                // =4
    178c:      	mov	w22, #0x4               // =4
    1790:      	add	x8, x23, #0x40
    1794:      	add	x2, x24, #0x8
    1798:      	mov	x0, x23
    179c:      	add	x25, x23, #0x28
    17a0:      	str	x8, [sp, #0x48]
    17a4:      	mov	w8, #0x4                // =4
    17a8:      	blr	x8
    17ac:      	add	x0, x23, #0x4
    17b0:      	add	x2, x24, #0xc
    17b4:      	mov	w8, #0x4                // =4
    17b8:      	mov	w1, #0x4                // =4
    17bc:      	blr	x8
    17c0:      	add	x0, x23, #0x10
    17c4:      	add	x2, x24, #0x18
    17c8:      	mov	w8, #0x4                // =4
    17cc:      	mov	w1, #0x4                // =4
    17d0:      	blr	x8
    17d4:      	add	x0, x23, #0x14
    17d8:      	add	x2, x24, #0x1c
    17dc:      	mov	w8, #0x4                // =4
    17e0:      	mov	w1, #0x4                // =4
    17e4:      	blr	x8
    17e8:      	add	x0, x23, #0x8
    17ec:      	add	x2, x24, #0x10
    17f0:      	mov	w8, #0x4                // =4
    17f4:      	mov	w1, #0x4                // =4
    17f8:      	blr	x8
    17fc:      	add	x0, x23, #0xc
    1800:      	add	x2, x24, #0x14
    1804:      	mov	w8, #0x4                // =4
    1808:      	mov	w1, #0x4                // =4
    180c:      	blr	x8
    1810:      	add	x0, x23, #0x18
    1814:      	add	x2, x24, #0x20
    1818:      	mov	w8, #0x4                // =4
    181c:      	mov	w1, #0x4                // =4
    1820:      	blr	x8
    1824:      	add	x0, x23, #0x1c
    1828:      	add	x2, x24, #0x24
    182c:      	mov	w8, #0x4                // =4
    1830:      	mov	w1, #0x4                // =4
    1834:      	blr	x8
    1838:      	str	wzr, [x23, #0x24]
    183c:      	add	x0, x23, #0x20
    1840:      	add	x2, x24, #0x28
    1844:      	mov	w8, #0x4                // =4
    1848:      	mov	w1, #0x4                // =4
    184c:      	blr	x8
    1850:      	add	x0, x23, #0x30
    1854:      	add	x2, x24, #0x40
    1858:      	mov	w21, #0x8               // =8
    185c:      	mov	w8, #0x4                // =4
    1860:      	mov	w1, #0x8                // =8
    1864:      	blr	x8
    1868:      	add	x0, x23, #0x38
    186c:      	add	x2, x24, #0x30
    1870:      	mov	w8, #0x4                // =4
    1874:      	mov	w1, #0x8                // =8
    1878:      	blr	x8
    187c:      	add	x2, x24, #0x38
    1880:      	mov	w8, #0x4                // =4
    1884:      	mov	x0, x25
    1888:      	mov	w1, #0x8                // =8
    188c:      	blr	x8
    1890:      	add	x2, x24, #0x90
    1894:      	add	x8, sp, #0x98
    1898:      	mov	w9, #0x4                // =4
    189c:      	add	x0, sp, #0x98
    18a0:      	mov	w1, #0x8                // =8
    18a4:      	blr	x9
    18a8:      	ldr	x21, [sp, #0x98]
    18ac:      	ldr	x0, [sp, #0x48]
    18b0:      	mov	w8, #0x4                // =4
    18b4:      	mov	w1, #0x4                // =4
    18b8:      	add	x2, x21, #0xc8
    18bc:      	blr	x8
    18c0:      	add	x0, x23, #0x44
    18c4:      	add	x2, x21, #0xcc
    18c8:      	mov	w8, #0x4                // =4
    18cc:      	mov	w1, #0x4                // =4
    18d0:      	blr	x8
    18d4:      	add	x0, x23, #0x48
    18d8:      	add	x2, x21, #0xd0
    18dc:      	mov	w8, #0x4                // =4
    18e0:      	mov	w1, #0x4                // =4
    18e4:      	blr	x8
    18e8:      	add	x0, x23, #0x4c
    18ec:      	add	x2, x21, #0x158
    18f0:      	mov	w1, #0x4                // =4
    18f4:      	blr	x22
    18f8:      	mov	w24, #0x50              // =80
    18fc:      	b	0x2444 <generic_tracepoint_process_event+0x2444>
    1900:      	ldr	x23, [sp, #0x50]
    1904:      	ldr	x22, [sp, #0x30]
    1908:      	mov	w8, #0x4                // =4
    190c:      	mov	w1, #0x4                // =4
    1910:      	mov	w21, #0x4               // =4
    1914:      	add	x2, x23, #0xc8
    1918:      	mov	x0, x22
    191c:      	blr	x8
    1920:      	add	x0, x22, #0x4
    1924:      	add	x2, x23, #0xcc
    1928:      	mov	w8, #0x4                // =4
    192c:      	mov	w1, #0x4                // =4
    1930:      	blr	x8
    1934:      	add	x0, x22, #0x8
    1938:      	add	x2, x23, #0xd0
    193c:      	mov	w8, #0x4                // =4
    1940:      	mov	w1, #0x4                // =4
    1944:      	blr	x8
    1948:      	add	x0, x22, #0xc
    194c:      	add	x2, x23, #0x158
    1950:      	mov	w1, #0x4                // =4
    1954:      	blr	x21
    1958:      	mov	w24, #0x10              // =16
    195c:      	b	0x2444 <generic_tracepoint_process_event+0x2444>
    1960:      	ldr	x24, [sp, #0x50]
    1964:      	ldr	x23, [sp, #0x30]
    1968:      	mov	w8, #0x4                // =4
    196c:      	mov	w1, #0x4                // =4
    1970:      	mov	w22, #0x4               // =4
    1974:      	add	x2, x24, #0x38
    1978:      	mov	x0, x23
    197c:      	blr	x8
    1980:      	add	x0, x23, #0x4
    1984:      	add	x2, x24, #0x3c
    1988:      	mov	w8, #0x4                // =4
    198c:      	mov	w1, #0x4                // =4
    1990:      	blr	x8
    1994:      	add	x0, x23, #0x8
    1998:      	add	x2, x24, #0x40
    199c:      	mov	w8, #0x4                // =4
    19a0:      	mov	w1, #0x4                // =4
    19a4:      	blr	x8
    19a8:      	add	x0, x23, #0xc
    19ac:      	add	x2, x24, #0x44
    19b0:      	mov	w8, #0x4                // =4
    19b4:      	mov	w1, #0x4                // =4
    19b8:      	blr	x8
    19bc:      	add	x0, x23, #0x10
    19c0:      	add	x2, x24, #0x80
    19c4:      	mov	w8, #0x10               // =16
    19c8:      	mov	w1, #0x10               // =16
    19cc:      	blr	x22
    19d0:      	mov	w24, #0x20              // =32
    19d4:      	b	0x2448 <generic_tracepoint_process_event+0x2448>
    19d8:      	ldr	x22, [sp, #0x30]
    19dc:      	ldr	x23, [sp, #0x50]
    19e0:      	mov	w8, #0x4                // =4
    19e4:      	mov	w1, #0x4                // =4
    19e8:      	mov	w21, #0x4               // =4
    19ec:      	mov	x0, x22
    19f0:      	mov	x2, x23
    19f4:      	blr	x8
    19f8:      	add	x0, x22, #0x4
    19fc:      	add	x2, x23, #0x4
    1a00:      	mov	w8, #0x4                // =4
    1a04:      	mov	w1, #0x4                // =4
    1a08:      	blr	x8
    1a0c:      	add	x0, x22, #0x8
    1a10:      	add	x2, x23, #0x30
    1a14:      	mov	w8, #0x10               // =16
    1a18:      	b	0x1a98 <generic_tracepoint_process_event+0x1a98>
    1a1c:      	ldr	x23, [sp, #0x50]
    1a20:      	add	x8, sp, #0x98
    1a24:      	mov	w9, #0x4                // =4
    1a28:      	add	x0, sp, #0x98
    1a2c:      	mov	w1, #0x4                // =4
    1a30:      	mov	w21, #0x4               // =4
    1a34:      	add	x2, x23, #0x4
    1a38:      	blr	x9
    1a3c:      	ldr	w8, [sp, #0x98]
    1a40:      	add	x2, x23, #0xc
    1a44:      	add	x0, sp, #0x98
    1a48:      	mov	w1, #0x4                // =4
    1a4c:      	str	w8, [x22]
    1a50:      	add	x8, sp, #0x98
    1a54:      	blr	x21
    1a58:      	ldr	w8, [sp, #0x98]
    1a5c:      	add	x2, x23, #0x50
    1a60:      	add	x9, sp, #0x98
    1a64:      	mov	w10, #0x2d              // =45
    1a68:      	str	w8, [x22, #0x4]
    1a6c:      	mov	w8, #0x8                // =8
    1a70:      	add	x0, sp, #0x98
    1a74:      	mov	w1, #0x8                // =8
    1a78:      	mov	w21, #0x2d              // =45
    1a7c:      	blr	x10
    1a80:      	ldr	x8, [sp, #0x98]
    1a84:      	add	x0, x22, #0x8
    1a88:      	mov	w9, #0x10               // =16
    1a8c:      	add	x8, x8, #0x3f8
    1a90:      	ldr	x8, [sp, #0x98]
    1a94:      	add	x2, x8, #0x3f8
    1a98:      	mov	w1, #0x10               // =16
    1a9c:      	blr	x21
    1aa0:      	mov	w24, #0x18              // =24
    1aa4:      	b	0x2444 <generic_tracepoint_process_event+0x2444>
    1aa8:      	ldr	x11, [sp, #0x30]
    1aac:      	ldr	x2, [sp, #0x50]
    1ab0:      	mov	w8, #0x8                // =8
    1ab4:      	mov	w9, #0x4                // =4
    1ab8:      	add	x10, sp, #0x98
    1abc:      	add	x0, sp, #0x98
    1ac0:      	mov	w1, #0x8                // =8
    1ac4:      	stp	xzr, xzr, [x11, #0x40]
    1ac8:      	stp	xzr, xzr, [x11, #0x30]
    1acc:      	stp	xzr, xzr, [x11, #0x20]
    1ad0:      	stp	xzr, xzr, [x11, #0x10]
    1ad4:      	stp	xzr, xzr, [x11]
    1ad8:      	blr	x9
    1adc:      	mov	x24, xzr
    1ae0:      	cbnz	x0, 0x2444 <generic_tracepoint_process_event+0x2444>
    1ae4:      	ldr	x8, [sp, #0x30]
    1ae8:      	mov	w9, #0x3f               // =63
    1aec:      	mov	w10, #0x2d              // =45
    1af0:      	mov	w1, #0x3f               // =63
    1af4:      	add	x0, x8, #0x10
    1af8:      	ldr	x8, [sp, #0x98]
    1afc:      	ldr	x2, [sp, #0x98]
    1b00:      	blr	x10
    1b04:      	tbnz	x0, #0x3f, 0x2088 <generic_tracepoint_process_event+0x2088>
    1b08:      	ldr	x23, [sp, #0x50]
    1b0c:      	mov	w21, #0x8               // =8
    1b10:      	add	x8, sp, #0xf0
    1b14:      	mov	w9, #0x4                // =4
    1b18:      	add	x0, sp, #0xf0
    1b1c:      	mov	w1, #0x8                // =8
    1b20:      	mov	w22, #0x4               // =4
    1b24:      	add	x2, x23, #0x8
    1b28:      	blr	x9
    1b2c:      	ldr	x8, [sp, #0x30]
    1b30:      	add	x10, sp, #0xe0
    1b34:      	mov	w9, #0x4                // =4
    1b38:      	mov	w1, #0x8                // =8
    1b3c:      	add	x0, x8, #0x8
    1b40:      	ldr	x8, [x10, #0x10]
    1b44:      	add	x8, x8, #0x360
    1b48:      	ldr	x8, [x10, #0x10]
    1b4c:      	add	x2, x8, #0x360
    1b50:      	blr	x9
    1b54:      	add	x2, x23, #0x58
    1b58:      	add	x8, sp, #0xf0
    1b5c:      	add	x0, sp, #0xf0
    1b60:      	mov	w1, #0x4                // =4
    1b64:      	blr	x22
    1b68:      	cbnz	x0, 0x18f8 <generic_tracepoint_process_event+0x18f8>
    1b6c:      	ldr	w8, [sp, #0xf0]
    1b70:      	ldr	x9, [sp, #0x30]
    1b74:      	cmp	w8, #0x0
    1b78:      	cset	w8, ne
    1b7c:      	str	w8, [x9]
    1b80:      	b	0x18f8 <generic_tracepoint_process_event+0x18f8>
    1b84:      	ldr	x8, [sp, #0x50]
    1b88:      	mov	w24, #0x8               // =8
    1b8c:      	add	x8, x8, x23
    1b90:      	str	xzr, [x8, #0x90]
    1b94:      	b	0xd3c <generic_tracepoint_process_event+0xd3c>
    1b98:      	mov	x24, #-0x1              // =-1
    1b9c:      	b	0x1cf4 <generic_tracepoint_process_event+0x1cf4>
    1ba0:      	mov	w21, #0x7               // =7
    1ba4:      	mov	w8, #0x5ea0             // =24224
    1ba8:      	b	0x498 <generic_tracepoint_process_event+0x498>
    1bac:      	ldr	x25, [sp, #0x98]
    1bb0:      	ldrh	w21, [sp, #0x90]
    1bb4:      	adrp	x0, 0x1000 <generic_tracepoint_process_event+0x1000>
    1bb8:      	add	x9, sp, #0xf0
    1bbc:      	add	x1, sp, #0xf0
    1bc0:      	add	x8, x25, x21
    1bc4:      	str	wzr, [sp, #0xf0]
    1bc8:      	str	x8, [sp, #0x50]
    1bcc:      	mov	w8, #0x1                // =1
    1bd0:      	ldr	x0, [x0]
    1bd4:      	blr	x8
    1bd8:      	cbz	x0, 0x29c4 <generic_tracepoint_process_event+0x29c4>
    1bdc:      	mov	w8, #0xff               // =255
    1be0:      	strh	w21, [x0]
    1be4:      	strb	wzr, [x0, #0x7]
    1be8:      	add	x24, x0, #0x6
    1bec:      	mov	w9, #0x4                // =4
    1bf0:      	mov	x23, x0
    1bf4:      	strb	w8, [x0, #0x5]
    1bf8:      	ldr	x8, [sp, #0x50]
    1bfc:      	mov	x0, x24
    1c00:      	mov	w1, #0x1                // =1
    1c04:      	add	x2, x8, #0x6
    1c08:      	mov	w8, #0x1                // =1
    1c0c:      	blr	x9
    1c10:      	tbnz	x0, #0x3f, 0x29c4 <generic_tracepoint_process_event+0x29c4>
    1c14:      	ldrb	w8, [x23, #0x5]
    1c18:      	cmp	w8, #0x32
    1c1c:      	b.gt	0x2090 <generic_tracepoint_process_event+0x2090>
    1c20:      	cbz	w8, 0x2114 <generic_tracepoint_process_event+0x2114>
    1c24:      	cmp	w8, #0x2b
    1c28:      	b.eq	0x2114 <generic_tracepoint_process_event+0x2114>
    1c2c:      	cmp	w8, #0x2c
    1c30:      	b.ne	0x2520 <generic_tracepoint_process_event+0x2520>
    1c34:      	mov	w8, #0x8                // =8
    1c38:      	b	0x246c <generic_tracepoint_process_event+0x246c>
    1c3c:      	ldr	x0, [sp, #0x30]
    1c40:      	add	x2, x23, #0x48
    1c44:      	mov	w21, #0x10              // =16
    1c48:      	mov	w8, #0x4                // =4
    1c4c:      	mov	w1, #0x10               // =16
    1c50:      	mov	w24, #0x4               // =4
    1c54:      	blr	x8
    1c58:      	add	x2, x23, #0x38
    1c5c:      	mov	x0, x22
    1c60:      	mov	w1, #0x10               // =16
    1c64:      	blr	x24
    1c68:      	ldr	x24, [sp, #0x30]
    1c6c:      	add	x2, x23, #0xe
    1c70:      	mov	w21, #0x2               // =2
    1c74:      	mov	w8, #0x4                // =4
    1c78:      	mov	w1, #0x2                // =2
    1c7c:      	add	x22, x23, #0xc
    1c80:      	mov	w23, #0x4               // =4
    1c84:      	add	x0, x24, #0x20
    1c88:      	blr	x8
    1c8c:      	add	x0, x24, #0x22
    1c90:      	mov	w1, #0x2                // =2
    1c94:      	mov	x2, x22
    1c98:      	blr	x23
    1c9c:      	ldrh	w8, [x24, #0x22]
    1ca0:      	adrp	x0, 0x1000 <generic_tracepoint_process_event+0x1000>
    1ca4:      	add	x9, sp, #0x98
    1ca8:      	add	x1, sp, #0x98
    1cac:      	rev	w8, w8
    1cb0:      	lsr	w8, w8, #16
    1cb4:      	strh	w8, [x24, #0x22]
    1cb8:      	add	x8, sp, #0xe0
    1cbc:      	ldr	x8, [x8, #0x8]
    1cc0:      	str	x8, [sp, #0x98]
    1cc4:      	mov	w8, #0x1                // =1
    1cc8:      	ldr	x0, [x0]
    1ccc:      	blr	x8
    1cd0:      	cbz	x0, 0x1cf0 <generic_tracepoint_process_event+0x1cf0>
    1cd4:      	ldr	w8, [x0]
    1cd8:      	ldr	x9, [sp, #0x50]
    1cdc:      	str	w8, [x9, #0x10]
    1ce0:      	ldr	x8, [x0, #0x8]
    1ce4:      	str	x8, [x9, #0x18]
    1ce8:      	ldr	w8, [x0, #0x4]
    1cec:      	str	w8, [x9, #0x7c]
    1cf0:      	mov	w24, #0x40              // =64
    1cf4:      	adrp	x23, 0x1000 <generic_tracepoint_process_event+0x1000>
    1cf8:      	mov	w21, #0x5efc            // =24316
    1cfc:      	ldr	x23, [x23]
    1d00:      	b	0x1e4c <generic_tracepoint_process_event+0x1e4c>
    1d04:      	mov	w8, #0xe                // =14
    1d08:      	blr	x8
    1d0c:      	cmn	x0, #0x16
    1d10:      	b.ne	0x1d34 <generic_tracepoint_process_event+0x1d34>
    1d14:      	add	x2, x19, #0xe8
    1d18:      	mov	w8, #0x8                // =8
    1d1c:      	mov	w9, #0x4                // =4
    1d20:      	add	x10, sp, #0x98
    1d24:      	add	x0, sp, #0x98
    1d28:      	mov	w1, #0x8                // =8
    1d2c:      	blr	x9
    1d30:      	ldr	x0, [sp, #0x98]
    1d34:      	ldr	x10, [x22, #0x8]
    1d38:      	ldr	x9, [sp, #0x50]
    1d3c:      	mov	x3, xzr
    1d40:      	add	x1, sp, #0xf0
    1d44:      	add	x2, sp, #0x98
    1d48:      	add	x21, sp, #0xe0
    1d4c:      	ldr	x8, [x22, #0x60]
    1d50:      	str	xzr, [sp, #0xa8]
    1d54:      	stp	x10, x9, [sp, #0x98]
    1d58:      	add	x9, sp, #0xe0
    1d5c:      	add	x10, sp, #0x98
    1d60:      	stp	x8, x0, [x9, #0x10]
    1d64:      	adrp	x0, 0x1000 <generic_tracepoint_process_event+0x1000>
    1d68:      	mov	w8, #0x2                // =2
    1d6c:      	add	x9, sp, #0xf0
    1d70:      	ldr	x0, [x0]
    1d74:      	blr	x8
    1d78:      	cbz	x0, 0x20e0 <generic_tracepoint_process_event+0x20e0>
    1d7c:      	neg	w8, w0
    1d80:      	adrp	x22, 0x1000 <generic_tracepoint_process_event+0x1000>
    1d84:      	mov	w9, #0x1                // =1
    1d88:      	strh	w8, [sp, #0x100]
    1d8c:      	mov	w8, #0x5                // =5
    1d90:      	add	x1, sp, #0x100
    1d94:      	strh	w8, [sp, #0x102]
    1d98:      	mov	x8, #0x46               // =70
    1d9c:      	movk	x8, #0x2, lsl #32
    1da0:      	stur	x8, [x21, #0x24]
    1da4:      	add	x8, sp, #0x100
    1da8:      	mov	w21, #0x1               // =1
    1dac:      	ldr	x22, [x22]
    1db0:      	mov	x0, x22
    1db4:      	blr	x9
    1db8:      	cbz	x0, 0x20bc <generic_tracepoint_process_event+0x20bc>
    1dbc:      	ldr	w8, [x0]
    1dc0:      	add	w8, w8, #0x1
    1dc4:      	str	w8, [x0]
    1dc8:      	b	0x20e0 <generic_tracepoint_process_event+0x20e0>
    1dcc:      	mov	w8, #-0x2               // =-2
    1dd0:      	mov	w24, #0x4               // =4
    1dd4:      	stur	w8, [x21, #0x90]
    1dd8:      	b	0xd3c <generic_tracepoint_process_event+0xd3c>
    1ddc:      	cmp	w9, #0x1
    1de0:      	b.eq	0x1f58 <generic_tracepoint_process_event+0x1f58>
    1de4:      	cmp	w9, #0x2
    1de8:      	b.ne	0x1fa0 <generic_tracepoint_process_event+0x1fa0>
    1dec:      	mov	w9, #0x5e58             // =24152
    1df0:      	b	0x1f5c <generic_tracepoint_process_event+0x1f5c>
    1df4:      	ldr	x23, [sp, #0x30]
    1df8:      	add	x2, x22, #0x8
    1dfc:      	mov	w8, #0x10               // =16
    1e00:      	mov	w9, #0x4                // =4
    1e04:      	mov	w1, #0x10               // =16
    1e08:      	mov	w21, #0x4               // =4
    1e0c:      	add	x0, x23, #0x8
    1e10:      	blr	x9
    1e14:      	add	x0, x23, #0x2
    1e18:      	add	x2, x22, #0x2
    1e1c:      	mov	w8, #0x2                // =2
    1e20:      	mov	w1, #0x2                // =2
    1e24:      	blr	x21
    1e28:      	ldr	x9, [sp, #0x30]
    1e2c:      	adrp	x23, 0x1000 <generic_tracepoint_process_event+0x1000>
    1e30:      	mov	w21, #0x5efc            // =24316
    1e34:      	ldrh	w8, [x9, #0x2]
    1e38:      	rev	w8, w8
    1e3c:      	lsr	w8, w8, #16
    1e40:      	strh	w8, [x9, #0x2]
    1e44:      	ldr	x23, [x23]
    1e48:      	mov	w24, #0x18              // =24
    1e4c:      	mov	x22, x25
    1e50:      	b	0xd4c <generic_tracepoint_process_event+0xd4c>
    1e54:      	mov	x24, xzr
    1e58:      	mov	w21, #0x5efc            // =24316
    1e5c:      	mov	w9, #0x5ea0             // =24224
    1e60:      	mov	x10, x22
    1e64:      	b	0x2450 <generic_tracepoint_process_event+0x2450>
    1e68:      	cmp	w9, #0x1
    1e6c:      	b.eq	0x2130 <generic_tracepoint_process_event+0x2130>
    1e70:      	cmp	w9, #0x2
    1e74:      	b.ne	0x213c <generic_tracepoint_process_event+0x213c>
    1e78:      	mov	w8, #0x5e58             // =24152
    1e7c:      	b	0x2134 <generic_tracepoint_process_event+0x2134>
    1e80:      	ldr	x0, [sp, #0x30]
    1e84:      	add	x2, x23, #0x48
    1e88:      	mov	w21, #0x10              // =16
    1e8c:      	mov	w8, #0x4                // =4
    1e90:      	mov	w1, #0x10               // =16
    1e94:      	mov	w24, #0x4               // =4
    1e98:      	blr	x8
    1e9c:      	add	x2, x23, #0x38
    1ea0:      	mov	x0, x22
    1ea4:      	mov	w1, #0x10               // =16
    1ea8:      	blr	x24
    1eac:      	ldr	x24, [sp, #0x30]
    1eb0:      	add	x2, x23, #0xe
    1eb4:      	mov	w21, #0x2               // =2
    1eb8:      	mov	w8, #0x4                // =4
    1ebc:      	mov	w1, #0x2                // =2
    1ec0:      	add	x22, x23, #0xc
    1ec4:      	mov	w23, #0x4               // =4
    1ec8:      	add	x0, x24, #0x20
    1ecc:      	blr	x8
    1ed0:      	add	x0, x24, #0x22
    1ed4:      	mov	w1, #0x2                // =2
    1ed8:      	mov	x2, x22
    1edc:      	blr	x23
    1ee0:      	ldrh	w8, [x24, #0x22]
    1ee4:      	rev	w8, w8
    1ee8:      	lsr	w8, w8, #16
    1eec:      	strh	w8, [x24, #0x22]
    1ef0:      	ldr	x8, [sp, #0x30]
    1ef4:      	adrp	x0, 0x1000 <generic_tracepoint_process_event+0x1000>
    1ef8:      	add	x9, sp, #0x98
    1efc:      	add	x1, sp, #0x98
    1f00:      	ldr	x8, [x8, #0x28]
    1f04:      	str	x8, [sp, #0x98]
    1f08:      	mov	w8, #0x1                // =1
    1f0c:      	ldr	x0, [x0]
    1f10:      	blr	x8
    1f14:      	cbz	x0, 0x1f34 <generic_tracepoint_process_event+0x1f34>
    1f18:      	ldr	w8, [x0]
    1f1c:      	ldr	x9, [sp, #0x48]
    1f20:      	str	w8, [x9, #0x10]
    1f24:      	ldr	x8, [x0, #0x8]
    1f28:      	str	x8, [x9, #0x18]
    1f2c:      	ldr	w8, [x0, #0x4]
    1f30:      	str	w8, [x9, #0x7c]
    1f34:      	mov	w24, #0x40              // =64
    1f38:      	mov	w21, #0x5efc            // =24316
    1f3c:      	mov	w9, #0x5ea0             // =24224
    1f40:      	mov	x10, x25
    1f44:      	b	0x2450 <generic_tracepoint_process_event+0x2450>
    1f48:      	mov	w9, #0x5e60             // =24160
    1f4c:      	b	0x1f5c <generic_tracepoint_process_event+0x1f5c>
    1f50:      	mov	w9, #0x5e68             // =24168
    1f54:      	b	0x1f5c <generic_tracepoint_process_event+0x1f5c>
    1f58:      	mov	w9, #0x5e50             // =24144
    1f5c:      	add	x9, x22, x9
    1f60:      	ldr	x25, [x9]
    1f64:      	tbnz	w8, #0x4, 0x1fac <generic_tracepoint_process_event+0x1fac>
    1f68:      	cbz	x25, 0x2078 <generic_tracepoint_process_event+0x2078>
    1f6c:      	ldr	x2, [sp, #0x50]
    1f70:      	mov	w8, #0x10               // =16
    1f74:      	mov	w9, #0x4                // =4
    1f78:      	add	x10, sp, #0x98
    1f7c:      	add	x0, sp, #0x98
    1f80:      	mov	w1, #0x10               // =16
    1f84:      	blr	x9
    1f88:      	tbnz	w0, #0x1f, 0x2434 <generic_tracepoint_process_event+0x2434>
    1f8c:      	ldr	x23, [sp, #0xa0]
    1f90:      	cmp	x23, #0xffe
    1f94:      	b.ls	0x21a8 <generic_tracepoint_process_event+0x21a8>
    1f98:      	mov	w8, #-0x3               // =-3
    1f9c:      	b	0x2438 <generic_tracepoint_process_event+0x2438>
    1fa0:      	mov	x25, xzr
    1fa4:      	mov	x23, xzr
    1fa8:      	tbz	w8, #0x4, 0x207c <generic_tracepoint_process_event+0x207c>
    1fac:      	mov	w8, #0xe                // =14
    1fb0:      	blr	x8
    1fb4:      	cmn	x0, #0x16
    1fb8:      	b.ne	0x1fdc <generic_tracepoint_process_event+0x1fdc>
    1fbc:      	add	x2, x19, #0xe8
    1fc0:      	mov	w8, #0x8                // =8
    1fc4:      	mov	w9, #0x4                // =4
    1fc8:      	add	x10, sp, #0x98
    1fcc:      	add	x0, sp, #0x98
    1fd0:      	mov	w1, #0x8                // =8
    1fd4:      	blr	x9
    1fd8:      	ldr	x0, [sp, #0x98]
    1fdc:      	ldr	x10, [x22, #0x8]
    1fe0:      	ldr	x9, [sp, #0x50]
    1fe4:      	mov	x3, xzr
    1fe8:      	add	x1, sp, #0xf0
    1fec:      	add	x2, sp, #0x98
    1ff0:      	add	x21, sp, #0xe0
    1ff4:      	ldr	x8, [x22, #0x60]
    1ff8:      	str	x25, [sp, #0xa8]
    1ffc:      	stp	x10, x9, [sp, #0x98]
    2000:      	add	x9, sp, #0xe0
    2004:      	add	x10, sp, #0x98
    2008:      	stp	x8, x0, [x9, #0x10]
    200c:      	adrp	x0, 0x2000 <generic_tracepoint_process_event+0x2000>
    2010:      	mov	w8, #0x2                // =2
    2014:      	add	x9, sp, #0xf0
    2018:      	ldr	x0, [x0]
    201c:      	blr	x8
    2020:      	cbz	x0, 0x210c <generic_tracepoint_process_event+0x210c>
    2024:      	neg	w8, w0
    2028:      	adrp	x22, 0x2000 <generic_tracepoint_process_event+0x2000>
    202c:      	mov	w9, #0x1                // =1
    2030:      	strh	w8, [sp, #0x100]
    2034:      	mov	w8, #0x5                // =5
    2038:      	add	x1, sp, #0x100
    203c:      	strh	w8, [sp, #0x102]
    2040:      	mov	x8, #0x57               // =87
    2044:      	movk	x8, #0x2, lsl #32
    2048:      	stur	x8, [x21, #0x24]
    204c:      	add	x8, sp, #0x100
    2050:      	mov	w21, #0x1               // =1
    2054:      	ldr	x22, [x22]
    2058:      	mov	x0, x22
    205c:      	blr	x9
    2060:      	cbz	x0, 0x20e8 <generic_tracepoint_process_event+0x20e8>
    2064:      	ldr	w8, [x0]
    2068:      	add	w8, w8, #0x1
    206c:      	str	w8, [x0]
    2070:      	mov	w8, #-0x4               // =-4
    2074:      	b	0x2438 <generic_tracepoint_process_event+0x2438>
    2078:      	mov	x23, xzr
    207c:      	stp	w23, w23, [x29]
    2080:      	add	x24, x23, #0x8
    2084:      	b	0x2440 <generic_tracepoint_process_event+0x2440>
    2088:      	mov	x24, xzr
    208c:      	b	0x2444 <generic_tracepoint_process_event+0x2444>
    2090:      	cmp	w8, #0x33
    2094:      	b.eq	0x2460 <generic_tracepoint_process_event+0x2460>
    2098:      	cmp	w8, #0x3c
    209c:      	b.eq	0x2114 <generic_tracepoint_process_event+0x2114>
    20a0:      	cmp	w8, #0xff
    20a4:      	b.ne	0x2520 <generic_tracepoint_process_event+0x2520>
    20a8:      	mov	w8, #0x28               // =40
    20ac:      	b	0x246c <generic_tracepoint_process_event+0x246c>
    20b0:      	mov	w21, #0x9               // =9
    20b4:      	mov	w8, #0x5ea0             // =24224
    20b8:      	b	0x498 <generic_tracepoint_process_event+0x498>
    20bc:      	str	w21, [sp, #0x90]
    20c0:      	mov	x3, xzr
    20c4:      	mov	w8, #0x2                // =2
    20c8:      	add	x9, sp, #0x100
    20cc:      	add	x10, sp, #0x90
    20d0:      	add	x1, sp, #0x100
    20d4:      	add	x2, sp, #0x90
    20d8:      	mov	x0, x22
    20dc:      	blr	x8
    20e0:      	mov	w8, #-0x4               // =-4
    20e4:      	b	0x219c <generic_tracepoint_process_event+0x219c>
    20e8:      	str	w21, [sp, #0xe8]
    20ec:      	mov	x3, xzr
    20f0:      	mov	w8, #0x2                // =2
    20f4:      	add	x9, sp, #0x100
    20f8:      	add	x10, sp, #0xe8
    20fc:      	add	x1, sp, #0x100
    2100:      	add	x2, sp, #0xe8
    2104:      	mov	x0, x22
    2108:      	blr	x8
    210c:      	mov	w8, #-0x4               // =-4
    2110:      	b	0x2438 <generic_tracepoint_process_event+0x2438>
    2114:      	ldrb	w8, [x23, #0x7]
    2118:      	lsl	w8, w8, #3
    211c:      	b	0x2468 <generic_tracepoint_process_event+0x2468>
    2120:      	mov	w8, #0x5e60             // =24160
    2124:      	b	0x2134 <generic_tracepoint_process_event+0x2134>
    2128:      	mov	w8, #0x5e68             // =24168
    212c:      	b	0x2134 <generic_tracepoint_process_event+0x2134>
    2130:      	mov	w8, #0x5e50             // =24144
    2134:      	add	x8, x22, x8
    2138:      	ldr	x8, [x8]
    213c:      	add	x21, sp, #0xe0
    2140:      	add	x9, sp, #0xe0
    2144:      	add	x10, sp, #0xe8
    2148:      	str	x8, [x21, #0x8]
    214c:      	mov	w8, #0x8                // =8
    2150:      	mov	w11, #0x4               // =4
    2154:      	add	x0, sp, #0xe0
    2158:      	add	x2, sp, #0xe8
    215c:      	mov	w1, #0x8                // =8
    2160:      	mov	w24, #0x4               // =4
    2164:      	blr	x11
    2168:      	ldr	x21, [x21]
    216c:      	mov	w8, #0xfff              // =4095
    2170:      	ldr	x2, [sp, #0x50]
    2174:      	add	x0, x23, #0x8
    2178:      	cmp	x21, #0xfff
    217c:      	csel	x22, x21, x8, lo
    2180:      	mov	w1, w22
    2184:      	blr	x24
    2188:      	tbnz	w0, #0x1f, 0x2198 <generic_tracepoint_process_event+0x2198>
    218c:      	stp	w21, w22, [x23]
    2190:      	add	x24, x22, #0x8
    2194:      	b	0x2444 <generic_tracepoint_process_event+0x2444>
    2198:      	mov	w8, #-0x2               // =-2
    219c:      	str	w8, [x23]
    21a0:      	mov	w24, #0x4               // =4
    21a4:      	b	0x2444 <generic_tracepoint_process_event+0x2444>
    21a8:      	ldr	x8, [sp, #0x118]
    21ac:      	mov	w9, #0x4                // =4
    21b0:      	mov	w1, w23
    21b4:      	add	x21, x8, #0xc
    21b8:      	ldr	x8, [sp, #0x98]
    21bc:      	add	x0, x24, x21
    21c0:      	ldr	x2, [sp, #0x98]
    21c4:      	blr	x9
    21c8:      	tbnz	w0, #0x1f, 0x2434 <generic_tracepoint_process_event+0x2434>
    21cc:      	cmp	x25, #0x1
    21d0:      	b.eq	0x207c <generic_tracepoint_process_event+0x207c>
    21d4:      	ldr	x8, [sp, #0x50]
    21d8:      	mov	w9, #0x4                // =4
    21dc:      	add	x10, sp, #0x98
    21e0:      	add	x0, sp, #0x98
    21e4:      	mov	w1, #0x10               // =16
    21e8:      	add	x2, x8, #0x10
    21ec:      	mov	w8, #0x10               // =16
    21f0:      	blr	x9
    21f4:      	tbnz	w0, #0x1f, 0x2434 <generic_tracepoint_process_event+0x2434>
    21f8:      	ldr	x8, [sp, #0xa0]
    21fc:      	cmp	x8, #0xffe
    2200:      	b.hi	0x1f98 <generic_tracepoint_process_event+0x1f98>
    2204:      	add	x21, x23, x21
    2208:      	mov	x22, x8
    220c:      	ldr	x8, [sp, #0x98]
    2210:      	mov	w9, #0x4                // =4
    2214:      	add	x0, x24, x21
    2218:      	mov	x1, x22
    221c:      	ldr	x2, [sp, #0x98]
    2220:      	blr	x9
    2224:      	tbnz	w0, #0x1f, 0x2434 <generic_tracepoint_process_event+0x2434>
    2228:      	add	x23, x22, x23
    222c:      	cmp	x25, #0x3
    2230:      	b.lo	0x207c <generic_tracepoint_process_event+0x207c>
    2234:      	ldr	x8, [sp, #0x50]
    2238:      	mov	w9, #0x4                // =4
    223c:      	add	x10, sp, #0x98
    2240:      	add	x0, sp, #0x98
    2244:      	mov	w1, #0x10               // =16
    2248:      	add	x2, x8, #0x20
    224c:      	mov	w8, #0x10               // =16
    2250:      	blr	x9
    2254:      	tbnz	w0, #0x1f, 0x2434 <generic_tracepoint_process_event+0x2434>
    2258:      	ldr	x8, [sp, #0xa0]
    225c:      	cmp	x8, #0xffe
    2260:      	str	x8, [sp, #0x40]
    2264:      	b.hi	0x1f98 <generic_tracepoint_process_event+0x1f98>
    2268:      	add	x21, x22, x21
    226c:      	mov	w9, #0x4                // =4
    2270:      	ldr	x1, [sp, #0x40]
    2274:      	and	x8, x21, #0x3fff
    2278:      	add	x0, x24, x8
    227c:      	ldr	x8, [sp, #0x98]
    2280:      	ldr	x2, [sp, #0x98]
    2284:      	blr	x9
    2288:      	tbnz	w0, #0x1f, 0x2434 <generic_tracepoint_process_event+0x2434>
    228c:      	ldr	x8, [sp, #0x40]
    2290:      	cmp	x25, #0x3
    2294:      	add	x23, x8, x23
    2298:      	b.eq	0x207c <generic_tracepoint_process_event+0x207c>
    229c:      	ldr	x8, [sp, #0x50]
    22a0:      	mov	w9, #0x4                // =4
    22a4:      	add	x10, sp, #0x98
    22a8:      	add	x0, sp, #0x98
    22ac:      	mov	w1, #0x10               // =16
    22b0:      	add	x2, x8, #0x30
    22b4:      	mov	w8, #0x10               // =16
    22b8:      	blr	x9
    22bc:      	tbnz	w0, #0x1f, 0x2434 <generic_tracepoint_process_event+0x2434>
    22c0:      	ldr	x8, [sp, #0xa0]
    22c4:      	cmp	x8, #0xffe
    22c8:      	str	x8, [sp, #0x30]
    22cc:      	b.hi	0x1f98 <generic_tracepoint_process_event+0x1f98>
    22d0:      	ldr	x8, [sp, #0x40]
    22d4:      	mov	w9, #0x4                // =4
    22d8:      	ldr	x1, [sp, #0x30]
    22dc:      	add	x21, x8, x21
    22e0:      	and	x8, x21, #0x3fff
    22e4:      	add	x0, x24, x8
    22e8:      	ldr	x8, [sp, #0x98]
    22ec:      	ldr	x2, [sp, #0x98]
    22f0:      	blr	x9
    22f4:      	tbnz	w0, #0x1f, 0x2434 <generic_tracepoint_process_event+0x2434>
    22f8:      	ldr	x8, [sp, #0x30]
    22fc:      	cmp	x25, #0x5
    2300:      	add	x23, x8, x23
    2304:      	b.lo	0x207c <generic_tracepoint_process_event+0x207c>
    2308:      	ldr	x8, [sp, #0x50]
    230c:      	mov	w9, #0x4                // =4
    2310:      	add	x10, sp, #0x98
    2314:      	add	x0, sp, #0x98
    2318:      	mov	w1, #0x10               // =16
    231c:      	add	x2, x8, #0x40
    2320:      	mov	w8, #0x10               // =16
    2324:      	blr	x9
    2328:      	tbnz	w0, #0x1f, 0x2434 <generic_tracepoint_process_event+0x2434>
    232c:      	ldr	x22, [sp, #0xa0]
    2330:      	cmp	x22, #0xffe
    2334:      	b.hi	0x1f98 <generic_tracepoint_process_event+0x1f98>
    2338:      	ldr	x8, [sp, #0x30]
    233c:      	mov	w9, #0x4                // =4
    2340:      	mov	w1, w22
    2344:      	add	x21, x8, x21
    2348:      	and	x8, x21, #0x3fff
    234c:      	add	x0, x24, x8
    2350:      	ldr	x8, [sp, #0x98]
    2354:      	ldr	x2, [sp, #0x98]
    2358:      	blr	x9
    235c:      	tbnz	w0, #0x1f, 0x2434 <generic_tracepoint_process_event+0x2434>
    2360:      	add	x23, x22, x23
    2364:      	cmp	x25, #0x5
    2368:      	b.eq	0x207c <generic_tracepoint_process_event+0x207c>
    236c:      	ldr	x8, [sp, #0x50]
    2370:      	mov	w9, #0x4                // =4
    2374:      	add	x10, sp, #0x98
    2378:      	add	x0, sp, #0x98
    237c:      	mov	w1, #0x10               // =16
    2380:      	add	x2, x8, #0x50
    2384:      	mov	w8, #0x10               // =16
    2388:      	blr	x9
    238c:      	tbnz	w0, #0x1f, 0x2434 <generic_tracepoint_process_event+0x2434>
    2390:      	ldr	x8, [sp, #0xa0]
    2394:      	cmp	x8, #0xffe
    2398:      	str	x8, [sp, #0x40]
    239c:      	b.hi	0x1f98 <generic_tracepoint_process_event+0x1f98>
    23a0:      	add	x21, x22, x21
    23a4:      	mov	w9, #0x4                // =4
    23a8:      	ldr	x1, [sp, #0x40]
    23ac:      	and	x8, x21, #0x3fff
    23b0:      	add	x0, x24, x8
    23b4:      	ldr	x8, [sp, #0x98]
    23b8:      	ldr	x2, [sp, #0x98]
    23bc:      	blr	x9
    23c0:      	tbnz	w0, #0x1f, 0x2434 <generic_tracepoint_process_event+0x2434>
    23c4:      	ldr	x8, [sp, #0x40]
    23c8:      	cmp	x25, #0x7
    23cc:      	add	x23, x8, x23
    23d0:      	b.lo	0x207c <generic_tracepoint_process_event+0x207c>
    23d4:      	ldr	x8, [sp, #0x50]
    23d8:      	mov	w9, #0x4                // =4
    23dc:      	add	x10, sp, #0x98
    23e0:      	add	x0, sp, #0x98
    23e4:      	mov	w1, #0x10               // =16
    23e8:      	add	x2, x8, #0x60
    23ec:      	mov	w8, #0x10               // =16
    23f0:      	blr	x9
    23f4:      	tbnz	w0, #0x1f, 0x2434 <generic_tracepoint_process_event+0x2434>
    23f8:      	ldr	x22, [sp, #0xa0]
    23fc:      	cmp	x22, #0xffe
    2400:      	b.hi	0x1f98 <generic_tracepoint_process_event+0x1f98>
    2404:      	ldr	x8, [sp, #0x40]
    2408:      	mov	w9, #0x4                // =4
    240c:      	mov	w1, w22
    2410:      	add	x8, x8, x21
    2414:      	and	x8, x8, #0x3fff
    2418:      	add	x0, x24, x8
    241c:      	ldr	x8, [sp, #0x98]
    2420:      	ldr	x2, [sp, #0x98]
    2424:      	blr	x9
    2428:      	tbnz	w0, #0x1f, 0x2434 <generic_tracepoint_process_event+0x2434>
    242c:      	add	x23, x22, x23
    2430:      	b	0x207c <generic_tracepoint_process_event+0x207c>
    2434:      	mov	w8, #-0x2               // =-2
    2438:      	mov	w24, #0x4               // =4
    243c:      	str	w8, [x29]
    2440:      	ldr	x29, [sp, #0x48]
    2444:      	mov	w21, #0x5efc            // =24316
    2448:      	ldr	x10, [sp, #0x38]
    244c:      	mov	w9, #0x5ea0             // =24224
    2450:      	adrp	x23, 0x2000 <generic_tracepoint_process_event+0x2000>
    2454:      	ldr	x23, [x23]
    2458:      	ldr	x22, [sp, #0x28]
    245c:      	b	0xd54 <generic_tracepoint_process_event+0xd54>
    2460:      	ldrb	w8, [x23, #0x7]
    2464:      	lsl	w8, w8, #2
    2468:      	add	w8, w8, #0x8
    246c:      	strh	w8, [x23, #0x2]
    2470:      	ldrh	w9, [x23]
    2474:      	ldrb	w22, [x23, #0x6]
    2478:      	add	w8, w9, w8
    247c:      	cmp	w22, #0x3c
    2480:      	strh	w8, [x23]
    2484:      	b.hi	0x253c <generic_tracepoint_process_event+0x253c>
    2488:      	mov	x21, #0x1               // =1
    248c:      	mov	w9, #0x1                // =1
    2490:      	movk	x21, #0x1800, lsl #32
    2494:      	lsl	x9, x9, x22
    2498:      	movk	x21, #0x1008, lsl #48
    249c:      	tst	x9, x21
    24a0:      	b.eq	0x253c <generic_tracepoint_process_event+0x253c>
    24a4:      	strb	w22, [x23, #0x5]
    24a8:      	add	x8, x25, w8, uxth
    24ac:      	mov	w9, #0x2                // =2
    24b0:      	mov	w10, #0x4               // =4
    24b4:      	mov	x0, x24
    24b8:      	mov	w1, #0x2                // =2
    24bc:      	ldrh	w8, [x23]
    24c0:      	add	x2, x25, x8
    24c4:      	blr	x10
    24c8:      	tbnz	x0, #0x3f, 0x29c4 <generic_tracepoint_process_event+0x29c4>
    24cc:      	ldrb	w8, [x23, #0x5]
    24d0:      	cmp	w8, #0x32
    24d4:      	b.gt	0x24f4 <generic_tracepoint_process_event+0x24f4>
    24d8:      	cbz	w8, 0x2514 <generic_tracepoint_process_event+0x2514>
    24dc:      	cmp	w8, #0x2b
    24e0:      	b.eq	0x2514 <generic_tracepoint_process_event+0x2514>
    24e4:      	cmp	w8, #0x2c
    24e8:      	b.ne	0x25f8 <generic_tracepoint_process_event+0x25f8>
    24ec:      	mov	w8, #0x8                // =8
    24f0:      	b	0x2550 <generic_tracepoint_process_event+0x2550>
    24f4:      	cmp	w8, #0x33
    24f8:      	b.eq	0x2544 <generic_tracepoint_process_event+0x2544>
    24fc:      	cmp	w8, #0x3c
    2500:      	b.eq	0x2514 <generic_tracepoint_process_event+0x2514>
    2504:      	cmp	w8, #0xff
    2508:      	b.ne	0x25f8 <generic_tracepoint_process_event+0x25f8>
    250c:      	mov	w8, #0x28               // =40
    2510:      	b	0x2550 <generic_tracepoint_process_event+0x2550>
    2514:      	ldrb	w8, [x23, #0x7]
    2518:      	lsl	w8, w8, #3
    251c:      	b	0x254c <generic_tracepoint_process_event+0x254c>
    2520:      	ldrh	w8, [x23, #0x2]
    2524:      	ldrh	w9, [x23]
    2528:      	ldrb	w22, [x23, #0x6]
    252c:      	add	w8, w9, w8
    2530:      	cmp	w22, #0x3c
    2534:      	strh	w8, [x23]
    2538:      	b.ls	0x2488 <generic_tracepoint_process_event+0x2488>
    253c:      	strh	w8, [sp, #0x88]
    2540:      	b	0x29c8 <generic_tracepoint_process_event+0x29c8>
    2544:      	ldrb	w8, [x23, #0x7]
    2548:      	lsl	w8, w8, #2
    254c:      	add	w8, w8, #0x8
    2550:      	strh	w8, [x23, #0x2]
    2554:      	ldrh	w9, [x23]
    2558:      	ldrb	w22, [x23, #0x6]
    255c:      	add	w8, w9, w8
    2560:      	cmp	w22, #0x3c
    2564:      	strh	w8, [x23]
    2568:      	b.hi	0x2b70 <generic_tracepoint_process_event+0x2b70>
    256c:      	mov	w9, #0x1                // =1
    2570:      	lsl	x9, x9, x22
    2574:      	tst	x9, x21
    2578:      	b.eq	0x2b70 <generic_tracepoint_process_event+0x2b70>
    257c:      	strb	w22, [x23, #0x5]
    2580:      	add	x8, x25, w8, uxth
    2584:      	mov	w9, #0x2                // =2
    2588:      	mov	w10, #0x4               // =4
    258c:      	mov	x0, x24
    2590:      	mov	w1, #0x2                // =2
    2594:      	ldrh	w8, [x23]
    2598:      	add	x2, x25, x8
    259c:      	blr	x10
    25a0:      	tbnz	x0, #0x3f, 0x29c4 <generic_tracepoint_process_event+0x29c4>
    25a4:      	ldrb	w8, [x23, #0x5]
    25a8:      	cmp	w8, #0x32
    25ac:      	b.gt	0x25cc <generic_tracepoint_process_event+0x25cc>
    25b0:      	cbz	w8, 0x25ec <generic_tracepoint_process_event+0x25ec>
    25b4:      	cmp	w8, #0x2b
    25b8:      	b.eq	0x25ec <generic_tracepoint_process_event+0x25ec>
    25bc:      	cmp	w8, #0x2c
    25c0:      	b.ne	0x26cc <generic_tracepoint_process_event+0x26cc>
    25c4:      	mov	w8, #0x8                // =8
    25c8:      	b	0x2624 <generic_tracepoint_process_event+0x2624>
    25cc:      	cmp	w8, #0x33
    25d0:      	b.eq	0x2618 <generic_tracepoint_process_event+0x2618>
    25d4:      	cmp	w8, #0x3c
    25d8:      	b.eq	0x25ec <generic_tracepoint_process_event+0x25ec>
    25dc:      	cmp	w8, #0xff
    25e0:      	b.ne	0x26cc <generic_tracepoint_process_event+0x26cc>
    25e4:      	mov	w8, #0x28               // =40
    25e8:      	b	0x2624 <generic_tracepoint_process_event+0x2624>
    25ec:      	ldrb	w8, [x23, #0x7]
    25f0:      	lsl	w8, w8, #3
    25f4:      	b	0x2620 <generic_tracepoint_process_event+0x2620>
    25f8:      	ldrh	w8, [x23, #0x2]
    25fc:      	ldrh	w9, [x23]
    2600:      	ldrb	w22, [x23, #0x6]
    2604:      	add	w8, w9, w8
    2608:      	cmp	w22, #0x3c
    260c:      	strh	w8, [x23]
    2610:      	b.ls	0x256c <generic_tracepoint_process_event+0x256c>
    2614:      	b	0x2b70 <generic_tracepoint_process_event+0x2b70>
    2618:      	ldrb	w8, [x23, #0x7]
    261c:      	lsl	w8, w8, #2
    2620:      	add	w8, w8, #0x8
    2624:      	strh	w8, [x23, #0x2]
    2628:      	ldrh	w9, [x23]
    262c:      	ldrb	w22, [x23, #0x6]
    2630:      	add	w8, w9, w8
    2634:      	cmp	w22, #0x3c
    2638:      	strh	w8, [x23]
    263c:      	b.hi	0x2b70 <generic_tracepoint_process_event+0x2b70>
    2640:      	mov	w9, #0x1                // =1
    2644:      	lsl	x9, x9, x22
    2648:      	tst	x9, x21
    264c:      	b.eq	0x2b70 <generic_tracepoint_process_event+0x2b70>
    2650:      	strb	w22, [x23, #0x5]
    2654:      	add	x8, x25, w8, uxth
    2658:      	mov	w9, #0x2                // =2
    265c:      	mov	w10, #0x4               // =4
    2660:      	mov	x0, x24
    2664:      	mov	w1, #0x2                // =2
    2668:      	ldrh	w8, [x23]
    266c:      	add	x2, x25, x8
    2670:      	blr	x10
    2674:      	tbnz	x0, #0x3f, 0x29c4 <generic_tracepoint_process_event+0x29c4>
    2678:      	ldrb	w8, [x23, #0x5]
    267c:      	cmp	w8, #0x32
    2680:      	b.gt	0x26a0 <generic_tracepoint_process_event+0x26a0>
    2684:      	cbz	w8, 0x26c0 <generic_tracepoint_process_event+0x26c0>
    2688:      	cmp	w8, #0x2b
    268c:      	b.eq	0x26c0 <generic_tracepoint_process_event+0x26c0>
    2690:      	cmp	w8, #0x2c
    2694:      	b.ne	0x27a0 <generic_tracepoint_process_event+0x27a0>
    2698:      	mov	w8, #0x8                // =8
    269c:      	b	0x26f8 <generic_tracepoint_process_event+0x26f8>
    26a0:      	cmp	w8, #0x33
    26a4:      	b.eq	0x26ec <generic_tracepoint_process_event+0x26ec>
    26a8:      	cmp	w8, #0x3c
    26ac:      	b.eq	0x26c0 <generic_tracepoint_process_event+0x26c0>
    26b0:      	cmp	w8, #0xff
    26b4:      	b.ne	0x27a0 <generic_tracepoint_process_event+0x27a0>
    26b8:      	mov	w8, #0x28               // =40
    26bc:      	b	0x26f8 <generic_tracepoint_process_event+0x26f8>
    26c0:      	ldrb	w8, [x23, #0x7]
    26c4:      	lsl	w8, w8, #3
    26c8:      	b	0x26f4 <generic_tracepoint_process_event+0x26f4>
    26cc:      	ldrh	w8, [x23, #0x2]
    26d0:      	ldrh	w9, [x23]
    26d4:      	ldrb	w22, [x23, #0x6]
    26d8:      	add	w8, w9, w8
    26dc:      	cmp	w22, #0x3c
    26e0:      	strh	w8, [x23]
    26e4:      	b.ls	0x2640 <generic_tracepoint_process_event+0x2640>
    26e8:      	b	0x2b70 <generic_tracepoint_process_event+0x2b70>
    26ec:      	ldrb	w8, [x23, #0x7]
    26f0:      	lsl	w8, w8, #2
    26f4:      	add	w8, w8, #0x8
    26f8:      	strh	w8, [x23, #0x2]
    26fc:      	ldrh	w9, [x23]
    2700:      	ldrb	w22, [x23, #0x6]
    2704:      	add	w8, w9, w8
    2708:      	cmp	w22, #0x3c
    270c:      	strh	w8, [x23]
    2710:      	b.hi	0x2b70 <generic_tracepoint_process_event+0x2b70>
    2714:      	mov	w9, #0x1                // =1
    2718:      	lsl	x9, x9, x22
    271c:      	tst	x9, x21
    2720:      	b.eq	0x2b70 <generic_tracepoint_process_event+0x2b70>
    2724:      	strb	w22, [x23, #0x5]
    2728:      	add	x8, x25, w8, uxth
    272c:      	mov	w9, #0x2                // =2
    2730:      	mov	w10, #0x4               // =4
    2734:      	mov	x0, x24
    2738:      	mov	w1, #0x2                // =2
    273c:      	ldrh	w8, [x23]
    2740:      	add	x2, x25, x8
    2744:      	blr	x10
    2748:      	tbnz	x0, #0x3f, 0x29c4 <generic_tracepoint_process_event+0x29c4>
    274c:      	ldrb	w8, [x23, #0x5]
    2750:      	cmp	w8, #0x32
    2754:      	b.gt	0x2774 <generic_tracepoint_process_event+0x2774>
    2758:      	cbz	w8, 0x2794 <generic_tracepoint_process_event+0x2794>
    275c:      	cmp	w8, #0x2b
    2760:      	b.eq	0x2794 <generic_tracepoint_process_event+0x2794>
    2764:      	cmp	w8, #0x2c
    2768:      	b.ne	0x2874 <generic_tracepoint_process_event+0x2874>
    276c:      	mov	w8, #0x8                // =8
    2770:      	b	0x27cc <generic_tracepoint_process_event+0x27cc>
    2774:      	cmp	w8, #0x33
    2778:      	b.eq	0x27c0 <generic_tracepoint_process_event+0x27c0>
    277c:      	cmp	w8, #0x3c
    2780:      	b.eq	0x2794 <generic_tracepoint_process_event+0x2794>
    2784:      	cmp	w8, #0xff
    2788:      	b.ne	0x2874 <generic_tracepoint_process_event+0x2874>
    278c:      	mov	w8, #0x28               // =40
    2790:      	b	0x27cc <generic_tracepoint_process_event+0x27cc>
    2794:      	ldrb	w8, [x23, #0x7]
    2798:      	lsl	w8, w8, #3
    279c:      	b	0x27c8 <generic_tracepoint_process_event+0x27c8>
    27a0:      	ldrh	w8, [x23, #0x2]
    27a4:      	ldrh	w9, [x23]
    27a8:      	ldrb	w22, [x23, #0x6]
    27ac:      	add	w8, w9, w8
    27b0:      	cmp	w22, #0x3c
    27b4:      	strh	w8, [x23]
    27b8:      	b.ls	0x2714 <generic_tracepoint_process_event+0x2714>
    27bc:      	b	0x2b70 <generic_tracepoint_process_event+0x2b70>
    27c0:      	ldrb	w8, [x23, #0x7]
    27c4:      	lsl	w8, w8, #2
    27c8:      	add	w8, w8, #0x8
    27cc:      	strh	w8, [x23, #0x2]
    27d0:      	ldrh	w9, [x23]
    27d4:      	ldrb	w22, [x23, #0x6]
    27d8:      	add	w8, w9, w8
    27dc:      	cmp	w22, #0x3c
    27e0:      	strh	w8, [x23]
    27e4:      	b.hi	0x2b70 <generic_tracepoint_process_event+0x2b70>
    27e8:      	mov	w9, #0x1                // =1
    27ec:      	lsl	x9, x9, x22
    27f0:      	tst	x9, x21
    27f4:      	b.eq	0x2b70 <generic_tracepoint_process_event+0x2b70>
    27f8:      	strb	w22, [x23, #0x5]
    27fc:      	add	x8, x25, w8, uxth
    2800:      	mov	w9, #0x2                // =2
    2804:      	mov	w10, #0x4               // =4
    2808:      	mov	x0, x24
    280c:      	mov	w1, #0x2                // =2
    2810:      	ldrh	w8, [x23]
    2814:      	add	x2, x25, x8
    2818:      	blr	x10
    281c:      	tbnz	x0, #0x3f, 0x29c4 <generic_tracepoint_process_event+0x29c4>
    2820:      	ldrb	w8, [x23, #0x5]
    2824:      	cmp	w8, #0x32
    2828:      	b.gt	0x2848 <generic_tracepoint_process_event+0x2848>
    282c:      	cbz	w8, 0x2868 <generic_tracepoint_process_event+0x2868>
    2830:      	cmp	w8, #0x2b
    2834:      	b.eq	0x2868 <generic_tracepoint_process_event+0x2868>
    2838:      	cmp	w8, #0x2c
    283c:      	b.ne	0x2948 <generic_tracepoint_process_event+0x2948>
    2840:      	mov	w8, #0x8                // =8
    2844:      	b	0x28a0 <generic_tracepoint_process_event+0x28a0>
    2848:      	cmp	w8, #0x33
    284c:      	b.eq	0x2894 <generic_tracepoint_process_event+0x2894>
    2850:      	cmp	w8, #0x3c
    2854:      	b.eq	0x2868 <generic_tracepoint_process_event+0x2868>
    2858:      	cmp	w8, #0xff
    285c:      	b.ne	0x2948 <generic_tracepoint_process_event+0x2948>
    2860:      	mov	w8, #0x28               // =40
    2864:      	b	0x28a0 <generic_tracepoint_process_event+0x28a0>
    2868:      	ldrb	w8, [x23, #0x7]
    286c:      	lsl	w8, w8, #3
    2870:      	b	0x289c <generic_tracepoint_process_event+0x289c>
    2874:      	ldrh	w8, [x23, #0x2]
    2878:      	ldrh	w9, [x23]
    287c:      	ldrb	w22, [x23, #0x6]
    2880:      	add	w8, w9, w8
    2884:      	cmp	w22, #0x3c
    2888:      	strh	w8, [x23]
    288c:      	b.ls	0x27e8 <generic_tracepoint_process_event+0x27e8>
    2890:      	b	0x2b70 <generic_tracepoint_process_event+0x2b70>
    2894:      	ldrb	w8, [x23, #0x7]
    2898:      	lsl	w8, w8, #2
    289c:      	add	w8, w8, #0x8
    28a0:      	strh	w8, [x23, #0x2]
    28a4:      	ldrh	w9, [x23]
    28a8:      	ldrb	w22, [x23, #0x6]
    28ac:      	add	w8, w9, w8
    28b0:      	cmp	w22, #0x3c
    28b4:      	strh	w8, [x23]
    28b8:      	b.hi	0x2b70 <generic_tracepoint_process_event+0x2b70>
    28bc:      	mov	w9, #0x1                // =1
    28c0:      	lsl	x9, x9, x22
    28c4:      	tst	x9, x21
    28c8:      	b.eq	0x2b70 <generic_tracepoint_process_event+0x2b70>
    28cc:      	strb	w22, [x23, #0x5]
    28d0:      	add	x8, x25, w8, uxth
    28d4:      	mov	w9, #0x2                // =2
    28d8:      	mov	w10, #0x4               // =4
    28dc:      	mov	x0, x24
    28e0:      	mov	w1, #0x2                // =2
    28e4:      	ldrh	w8, [x23]
    28e8:      	add	x2, x25, x8
    28ec:      	blr	x10
    28f0:      	tbnz	x0, #0x3f, 0x29c4 <generic_tracepoint_process_event+0x29c4>
    28f4:      	ldrb	w8, [x23, #0x5]
    28f8:      	cmp	w8, #0x32
    28fc:      	b.gt	0x291c <generic_tracepoint_process_event+0x291c>
    2900:      	cbz	w8, 0x293c <generic_tracepoint_process_event+0x293c>
    2904:      	cmp	w8, #0x2b
    2908:      	b.eq	0x293c <generic_tracepoint_process_event+0x293c>
    290c:      	cmp	w8, #0x2c
    2910:      	b.ne	0x2b54 <generic_tracepoint_process_event+0x2b54>
    2914:      	mov	w8, #0x8                // =8
    2918:      	b	0x2974 <generic_tracepoint_process_event+0x2974>
    291c:      	cmp	w8, #0x33
    2920:      	b.eq	0x2968 <generic_tracepoint_process_event+0x2968>
    2924:      	cmp	w8, #0x3c
    2928:      	b.eq	0x293c <generic_tracepoint_process_event+0x293c>
    292c:      	cmp	w8, #0xff
    2930:      	b.ne	0x2b54 <generic_tracepoint_process_event+0x2b54>
    2934:      	mov	w8, #0x28               // =40
    2938:      	b	0x2974 <generic_tracepoint_process_event+0x2974>
    293c:      	ldrb	w8, [x23, #0x7]
    2940:      	lsl	w8, w8, #3
    2944:      	b	0x2970 <generic_tracepoint_process_event+0x2970>
    2948:      	ldrh	w8, [x23, #0x2]
    294c:      	ldrh	w9, [x23]
    2950:      	ldrb	w22, [x23, #0x6]
    2954:      	add	w8, w9, w8
    2958:      	cmp	w22, #0x3c
    295c:      	strh	w8, [x23]
    2960:      	b.ls	0x28bc <generic_tracepoint_process_event+0x28bc>
    2964:      	b	0x2b70 <generic_tracepoint_process_event+0x2b70>
    2968:      	ldrb	w8, [x23, #0x7]
    296c:      	lsl	w8, w8, #2
    2970:      	add	w8, w8, #0x8
    2974:      	strh	w8, [x23, #0x2]
    2978:      	ldrh	w9, [x23]
    297c:      	ldrb	w22, [x23, #0x6]
    2980:      	add	w8, w9, w8
    2984:      	cmp	w22, #0x3c
    2988:      	strh	w8, [x23]
    298c:      	b.hi	0x2b70 <generic_tracepoint_process_event+0x2b70>
    2990:      	mov	w9, #0x1                // =1
    2994:      	lsl	x9, x9, x22
    2998:      	tst	x9, x21
    299c:      	b.eq	0x2b70 <generic_tracepoint_process_event+0x2b70>
    29a0:      	strb	w22, [x23, #0x5]
    29a4:      	add	x8, x25, w8, uxth
    29a8:      	mov	w9, #0x2                // =2
    29ac:      	mov	w10, #0x4               // =4
    29b0:      	mov	x0, x24
    29b4:      	mov	w1, #0x2                // =2
    29b8:      	ldrh	w8, [x23]
    29bc:      	add	x2, x25, x8
    29c0:      	blr	x10
    29c4:      	mov	w22, wzr
    29c8:      	ldr	x24, [sp, #0x30]
    29cc:      	ldr	x25, [sp, #0x50]
    29d0:      	mov	w8, #0xa                // =10
    29d4:      	mov	w21, #0x10              // =16
    29d8:      	mov	w1, #0x10               // =16
    29dc:      	mov	w23, #0x4               // =4
    29e0:      	strb	w22, [sp, #0x84]
    29e4:      	strh	w22, [x24, #0x24]
    29e8:      	strh	w8, [x24, #0x26]
    29ec:      	add	x2, x25, #0x8
    29f0:      	mov	w8, #0x4                // =4
    29f4:      	mov	x0, x24
    29f8:      	blr	x8
    29fc:      	add	x0, x24, #0x10
    2a00:      	add	x2, x25, #0x18
    2a04:      	mov	w1, #0x10               // =16
    2a08:      	blr	x23
    2a0c:      	cmp	w22, #0x11
    2a10:      	b.eq	0x2a54 <generic_tracepoint_process_event+0x2a54>
    2a14:      	cmp	w22, #0x6
    2a18:      	b.ne	0x2a94 <generic_tracepoint_process_event+0x2a94>
    2a1c:      	ldr	x8, [sp, #0x98]
    2a20:      	ldrh	w9, [sp, #0x88]
    2a24:      	mov	w21, #0x2               // =2
    2a28:      	mov	w1, #0x2                // =2
    2a2c:      	mov	w23, #0x4               // =4
    2a30:      	add	x22, x8, x9
    2a34:      	ldr	x24, [sp, #0x30]
    2a38:      	add	x0, x24, #0x20
    2a3c:      	mov	w8, #0x4                // =4
    2a40:      	mov	x2, x22
    2a44:      	blr	x8
    2a48:      	add	x0, x24, #0x22
    2a4c:      	add	x2, x22, #0x2
    2a50:      	b	0x2a88 <generic_tracepoint_process_event+0x2a88>
    2a54:      	ldr	x8, [sp, #0x98]
    2a58:      	ldrh	w9, [sp, #0x88]
    2a5c:      	mov	w21, #0x2               // =2
    2a60:      	mov	w1, #0x2                // =2
    2a64:      	mov	w23, #0x4               // =4
    2a68:      	add	x22, x8, x9
    2a6c:      	ldr	x24, [sp, #0x30]
    2a70:      	add	x0, x24, #0x20
    2a74:      	mov	w8, #0x4                // =4
    2a78:      	mov	x2, x22
    2a7c:      	blr	x8
    2a80:      	add	x0, x24, #0x22
    2a84:      	add	x2, x22, #0x2
    2a88:      	mov	w1, #0x2                // =2
    2a8c:      	blr	x23
    2a90:      	b	0x2a9c <generic_tracepoint_process_event+0x2a9c>
    2a94:      	ldr	x8, [sp, #0x30]
    2a98:      	str	wzr, [x8, #0x20]
    2a9c:      	ldr	x9, [sp, #0x30]
    2aa0:      	add	x2, x19, #0xe0
    2aa4:      	add	x10, sp, #0xf0
    2aa8:      	add	x0, sp, #0xf0
    2aac:      	ldrh	w8, [x9, #0x20]
    2ab0:      	mov	w1, #0x8                // =8
    2ab4:      	rev	w8, w8
    2ab8:      	lsr	w8, w8, #16
    2abc:      	strh	w8, [x9, #0x20]
    2ac0:      	ldrh	w8, [x9, #0x22]
    2ac4:      	rev	w8, w8
    2ac8:      	lsr	w8, w8, #16
    2acc:      	strh	w8, [x9, #0x22]
    2ad0:      	mov	w8, #0x8                // =8
    2ad4:      	mov	w9, #0x4                // =4
    2ad8:      	blr	x9
    2adc:      	add	x8, sp, #0xe0
    2ae0:      	ldr	x8, [x8, #0x10]
    2ae4:      	cbz	x8, 0x2b48 <generic_tracepoint_process_event+0x2b48>
    2ae8:      	add	x8, x8, #0x5
    2aec:      	mov	w9, #0x8                // =8
    2af0:      	add	x10, sp, #0x100
    2af4:      	mov	w11, #0x4               // =4
    2af8:      	add	x22, sp, #0xe0
    2afc:      	ldr	x8, [x22, #0x10]
    2b00:      	add	x0, sp, #0x100
    2b04:      	mov	w1, #0x8                // =8
    2b08:      	mov	w21, #0x4               // =4
    2b0c:      	add	x2, x8, #0x5
    2b10:      	blr	x11
    2b14:      	ldr	x8, [x22, #0x10]
    2b18:      	ldr	x9, [x22, #0x20]
    2b1c:      	mov	w1, #0x4                // =4
    2b20:      	add	x22, x8, x9, lsl #3
    2b24:      	ldr	x23, [sp, #0x30]
    2b28:      	add	x0, x23, #0x38
    2b2c:      	mov	w8, #0x4                // =4
    2b30:      	add	x2, x22, #0x44
    2b34:      	blr	x8
    2b38:      	add	x0, x23, #0x3c
    2b3c:      	add	x2, x22, #0x45
    2b40:      	mov	w1, #0x4                // =4
    2b44:      	blr	x21
    2b48:      	ldr	x19, [sp, #0x20]
    2b4c:      	mov	w24, #0x40              // =64
    2b50:      	b	0xd3c <generic_tracepoint_process_event+0xd3c>
    2b54:      	ldrh	w8, [x23, #0x2]
    2b58:      	ldrh	w9, [x23]
    2b5c:      	ldrb	w22, [x23, #0x6]
    2b60:      	add	w8, w9, w8
    2b64:      	cmp	w22, #0x3c
    2b68:      	strh	w8, [x23]
    2b6c:      	b.ls	0x2990 <generic_tracepoint_process_event+0x2990>
    2b70:      	strh	w8, [sp, #0x88]
    2b74:      	b	0x29c8 <generic_tracepoint_process_event+0x29c8>
    2b78:      	nop
    2b7c:      	nop

0000000000002b80 <generic_tracepoint_filter>:
    2b80:      	sub	sp, sp, #0x130
    2b84:      	str	x29, [sp, #0xe0]
    2b88:      	stp	x30, x25, [sp, #0xf0]
    2b8c:      	stp	x24, x23, [sp, #0x100]
    2b90:      	stp	x22, x21, [sp, #0x110]
    2b94:      	stp	x20, x19, [sp, #0x120]
    2b98:      	mov	x22, x0
    2b9c:      	str	wzr, [sp, #0x54]
    2ba0:      	adrp	x0, 0x2000 <generic_tracepoint_process_event+0x2000>
    2ba4:      	mov	w8, #0x1                // =1
    2ba8:      	ldr	x0, [x0]
    2bac:      	add	x9, sp, #0x54
    2bb0:      	add	x1, sp, #0x54
    2bb4:      	blr	x8
    2bb8:      	cbz	x0, 0x4a54 <generic_tracepoint_filter+0x1ed4>
    2bbc:      	mov	w8, #0x5ec0             // =24256
    2bc0:      	mov	x20, x0
    2bc4:      	add	x29, x0, x8
    2bc8:      	mov	w8, #0x23               // =35
    2bcc:      	blr	x8
    2bd0:      	str	x0, [sp, #0x58]
    2bd4:      	add	x8, x0, #0x8d4
    2bd8:      	mov	w9, #0x4                // =4
    2bdc:      	mov	w10, #0x71              // =113
    2be0:      	add	x11, sp, #0xd8
    2be4:      	add	x0, sp, #0xd8
    2be8:      	mov	w1, #0x4                // =4
    2bec:      	ldr	x8, [sp, #0x58]
    2bf0:      	add	x2, x8, #0x8d4
    2bf4:      	blr	x10
    2bf8:      	ldr	w8, [sp, #0xd8]
    2bfc:      	adrp	x19, 0x2000 <generic_tracepoint_process_event+0x2000>
    2c00:      	add	x9, sp, #0xc8
    2c04:      	add	x1, sp, #0xc8
    2c08:      	str	w8, [sp, #0xc8]
    2c0c:      	mov	w8, #0x1                // =1
    2c10:      	ldr	x19, [x19]
    2c14:      	mov	x0, x19
    2c18:      	blr	x8
    2c1c:      	cbz	x0, 0x2c2c <generic_tracepoint_filter+0xac>
    2c20:      	ldr	x8, [x0, #0x8]
    2c24:      	mov	x24, x0
    2c28:      	cbnz	x8, 0x385c <generic_tracepoint_filter+0xcdc>
    2c2c:      	ldr	x8, [sp, #0x58]
    2c30:      	mov	w9, #0x8                // =8
    2c34:      	mov	w10, #0x71              // =113
    2c38:      	add	x11, sp, #0x58
    2c3c:      	add	x0, sp, #0x58
    2c40:      	mov	w1, #0x8                // =8
    2c44:      	add	x8, x8, #0x8e0
    2c48:      	ldr	x8, [sp, #0x58]
    2c4c:      	add	x2, x8, #0x8e0
    2c50:      	blr	x10
    2c54:      	ldr	x8, [sp, #0x58]
    2c58:      	cbz	x8, 0x2dd4 <generic_tracepoint_filter+0x254>
    2c5c:      	add	x8, x8, #0x8d4
    2c60:      	mov	w9, #0x4                // =4
    2c64:      	mov	w10, #0x71              // =113
    2c68:      	add	x11, sp, #0xd8
    2c6c:      	ldr	x8, [sp, #0x58]
    2c70:      	add	x0, sp, #0xd8
    2c74:      	mov	w1, #0x4                // =4
    2c78:      	add	x2, x8, #0x8d4
    2c7c:      	blr	x10
    2c80:      	ldr	w8, [sp, #0xd8]
    2c84:      	add	x9, sp, #0xc8
    2c88:      	add	x1, sp, #0xc8
    2c8c:      	mov	x0, x19
    2c90:      	str	w8, [sp, #0xc8]
    2c94:      	mov	w8, #0x1                // =1
    2c98:      	blr	x8
    2c9c:      	cbz	x0, 0x2cac <generic_tracepoint_filter+0x12c>
    2ca0:      	ldr	x8, [x0, #0x8]
    2ca4:      	mov	x24, x0
    2ca8:      	cbnz	x8, 0x385c <generic_tracepoint_filter+0xcdc>
    2cac:      	ldr	x8, [sp, #0x58]
    2cb0:      	mov	w9, #0x8                // =8
    2cb4:      	mov	w10, #0x71              // =113
    2cb8:      	add	x11, sp, #0x58
    2cbc:      	add	x0, sp, #0x58
    2cc0:      	mov	w1, #0x8                // =8
    2cc4:      	add	x8, x8, #0x8e0
    2cc8:      	ldr	x8, [sp, #0x58]
    2ccc:      	add	x2, x8, #0x8e0
    2cd0:      	blr	x10
    2cd4:      	ldr	x8, [sp, #0x58]
    2cd8:      	cbz	x8, 0x2dd4 <generic_tracepoint_filter+0x254>
    2cdc:      	add	x8, x8, #0x8d4
    2ce0:      	mov	w9, #0x4                // =4
    2ce4:      	mov	w10, #0x71              // =113
    2ce8:      	add	x11, sp, #0xd8
    2cec:      	ldr	x8, [sp, #0x58]
    2cf0:      	add	x0, sp, #0xd8
    2cf4:      	mov	w1, #0x4                // =4
    2cf8:      	add	x2, x8, #0x8d4
    2cfc:      	blr	x10
    2d00:      	ldr	w8, [sp, #0xd8]
    2d04:      	add	x9, sp, #0xc8
    2d08:      	add	x1, sp, #0xc8
    2d0c:      	mov	x0, x19
    2d10:      	str	w8, [sp, #0xc8]
    2d14:      	mov	w8, #0x1                // =1
    2d18:      	blr	x8
    2d1c:      	cbz	x0, 0x2d2c <generic_tracepoint_filter+0x1ac>
    2d20:      	ldr	x8, [x0, #0x8]
    2d24:      	mov	x24, x0
    2d28:      	cbnz	x8, 0x385c <generic_tracepoint_filter+0xcdc>
    2d2c:      	ldr	x8, [sp, #0x58]
    2d30:      	mov	w9, #0x8                // =8
    2d34:      	mov	w10, #0x71              // =113
    2d38:      	add	x11, sp, #0x58
    2d3c:      	add	x0, sp, #0x58
    2d40:      	mov	w1, #0x8                // =8
    2d44:      	add	x8, x8, #0x8e0
    2d48:      	ldr	x8, [sp, #0x58]
    2d4c:      	add	x2, x8, #0x8e0
    2d50:      	blr	x10
    2d54:      	ldr	x8, [sp, #0x58]
    2d58:      	cbz	x8, 0x2dd4 <generic_tracepoint_filter+0x254>
    2d5c:      	add	x8, x8, #0x8d4
    2d60:      	mov	w9, #0x4                // =4
    2d64:      	mov	w10, #0x71              // =113
    2d68:      	add	x11, sp, #0xd8
    2d6c:      	ldr	x8, [sp, #0x58]
    2d70:      	add	x0, sp, #0xd8
    2d74:      	mov	w1, #0x4                // =4
    2d78:      	add	x2, x8, #0x8d4
    2d7c:      	blr	x10
    2d80:      	ldr	w8, [sp, #0xd8]
    2d84:      	add	x9, sp, #0xc8
    2d88:      	add	x1, sp, #0xc8
    2d8c:      	mov	x0, x19
    2d90:      	str	w8, [sp, #0xc8]
    2d94:      	mov	w8, #0x1                // =1
    2d98:      	blr	x8
    2d9c:      	cbz	x0, 0x2dac <generic_tracepoint_filter+0x22c>
    2da0:      	ldr	x8, [x0, #0x8]
    2da4:      	mov	x24, x0
    2da8:      	cbnz	x8, 0x385c <generic_tracepoint_filter+0xcdc>
    2dac:      	ldr	x8, [sp, #0x58]
    2db0:      	mov	w9, #0x8                // =8
    2db4:      	mov	w10, #0x71              // =113
    2db8:      	add	x11, sp, #0x58
    2dbc:      	add	x0, sp, #0x58
    2dc0:      	mov	w1, #0x8                // =8
    2dc4:      	add	x8, x8, #0x8e0
    2dc8:      	ldr	x8, [sp, #0x58]
    2dcc:      	add	x2, x8, #0x8e0
    2dd0:      	blr	x10
    2dd4:      	mov	w8, #0x23               // =35
    2dd8:      	blr	x8
    2ddc:      	add	x2, x0, #0x8d4
    2de0:      	mov	w8, #0x4                // =4
    2de4:      	add	x9, sp, #0x58
    2de8:      	mov	x24, x0
    2dec:      	add	x0, sp, #0x58
    2df0:      	mov	w1, #0x4                // =4
    2df4:      	blr	x8
    2df8:      	ldr	w8, [sp, #0x58]
    2dfc:      	mov	x19, x29
    2e00:      	str	w8, [x19, #0x50]!
    2e04:      	mov	w8, #0x7d               // =125
    2e08:      	blr	x8
    2e0c:      	str	x0, [x20, #0x5f18]
    2e10:      	str	wzr, [x19, #0x10]
    2e14:      	add	x2, x24, #0x60
    2e18:      	mov	w8, #0x8                // =8
    2e1c:      	mov	w9, #0x71               // =113
    2e20:      	add	x10, sp, #0xc8
    2e24:      	str	xzr, [x20, #0x5f28]
    2e28:      	str	x19, [sp, #0x48]
    2e2c:      	add	x0, sp, #0xc8
    2e30:      	mov	w1, #0x8                // =8
    2e34:      	str	wzr, [x19, #0x20]
    2e38:      	blr	x9
    2e3c:      	ldr	x8, [sp, #0xc8]
    2e40:      	cbz	x8, 0x2eb0 <generic_tracepoint_filter+0x330>
    2e44:      	add	x8, x8, #0x4
    2e48:      	mov	w9, #0x4                // =4
    2e4c:      	mov	w10, #0x71              // =113
    2e50:      	add	x11, sp, #0xd8
    2e54:      	ldr	x8, [sp, #0xc8]
    2e58:      	add	x0, sp, #0xd8
    2e5c:      	mov	w1, #0x4                // =4
    2e60:      	add	x2, x8, #0x4
    2e64:      	blr	x10
    2e68:      	ldr	w8, [sp, #0xd8]
    2e6c:      	cbz	w8, 0x2eb0 <generic_tracepoint_filter+0x330>
    2e70:      	ldr	x9, [sp, #0xc8]
    2e74:      	lsl	w8, w8, #4
    2e78:      	mov	w10, #0x71              // =113
    2e7c:      	add	x11, sp, #0x58
    2e80:      	add	x0, sp, #0x58
    2e84:      	mov	w1, #0x10               // =16
    2e88:      	add	x8, x9, x8
    2e8c:      	mov	w9, #0x10               // =16
    2e90:      	add	x8, x8, #0x80
    2e94:      	ldr	w9, [sp, #0xd8]
    2e98:      	ldr	x8, [sp, #0xc8]
    2e9c:      	lsl	w9, w9, #4
    2ea0:      	add	x8, x8, x9
    2ea4:      	add	x2, x8, #0x80
    2ea8:      	blr	x10
    2eac:      	ldr	w8, [sp, #0x58]
    2eb0:      	str	w8, [x29, #0x74]
    2eb4:      	mov	w8, #0x5f60             // =24416
    2eb8:      	str	x20, [sp, #0xe8]
    2ebc:      	add	x23, x24, #0xae0
    2ec0:      	mov	w19, #0x8               // =8
    2ec4:      	add	x25, x20, x8
    2ec8:      	add	x8, sp, #0x58
    2ecc:      	mov	w9, #0x4                // =4
    2ed0:      	add	x0, sp, #0x58
    2ed4:      	mov	w1, #0x8                // =8
    2ed8:      	mov	x2, x23
    2edc:      	mov	w21, #0x4               // =4
    2ee0:      	blr	x9
    2ee4:      	ldr	x20, [sp, #0x58]
    2ee8:      	ldr	x9, [sp, #0xe8]
    2eec:      	mov	w8, #0x5f68             // =24424
    2ef0:      	mov	w1, #0x8                // =8
    2ef4:      	add	x0, x9, x8
    2ef8:      	add	x2, x20, #0x40
    2efc:      	mov	w8, #0x4                // =4
    2f00:      	blr	x8
    2f04:      	ldr	x9, [sp, #0xe8]
    2f08:      	mov	w8, #0x5f70             // =24432
    2f0c:      	add	x2, x20, #0x30
    2f10:      	mov	w1, #0x8                // =8
    2f14:      	add	x0, x9, x8
    2f18:      	mov	w8, #0x4                // =4
    2f1c:      	blr	x8
    2f20:      	add	x2, x20, #0x38
    2f24:      	mov	w8, #0x4                // =4
    2f28:      	mov	x0, x25
    2f2c:      	mov	w1, #0x8                // =8
    2f30:      	blr	x8
    2f34:      	ldr	x9, [sp, #0xe8]
    2f38:      	mov	w8, #0x5f38             // =24376
    2f3c:      	add	x2, x24, #0xb50
    2f40:      	add	x0, sp, #0xd8
    2f44:      	mov	w1, #0x8                // =8
    2f48:      	add	x25, x9, x8
    2f4c:      	add	x8, sp, #0xd8
    2f50:      	mov	w9, #0x4                // =4
    2f54:      	blr	x9
    2f58:      	add	x12, sp, #0xd8
    2f5c:      	mov	w9, #0x48               // =72
    2f60:      	add	x10, sp, #0x58
    2f64:      	ldr	x8, [x12]
    2f68:      	mov	w11, #0x4               // =4
    2f6c:      	add	x0, sp, #0x58
    2f70:      	mov	w1, #0x48               // =72
    2f74:      	ldr	x2, [x12]
    2f78:      	blr	x11
    2f7c:      	ldr	x8, [sp, #0x60]
    2f80:      	mov	w9, #0x4                // =4
    2f84:      	mov	x0, x25
    2f88:      	mov	w1, #0x4                // =4
    2f8c:      	add	x8, x8, #0x218
    2f90:      	ldr	x8, [sp, #0x60]
    2f94:      	ldr	x25, [sp, #0xe8]
    2f98:      	add	x2, x8, #0x218
    2f9c:      	blr	x9
    2fa0:      	mov	w8, #0x5f3c             // =24380
    2fa4:      	mov	w9, #0x4                // =4
    2fa8:      	mov	w1, #0x4                // =4
    2fac:      	add	x0, x25, x8
    2fb0:      	ldr	x8, [sp, #0x68]
    2fb4:      	add	x8, x8, #0x4d8
    2fb8:      	ldr	x8, [sp, #0x68]
    2fbc:      	add	x2, x8, #0x4d8
    2fc0:      	blr	x9
    2fc4:      	mov	w8, #0x5f40             // =24384
    2fc8:      	mov	w9, #0x4                // =4
    2fcc:      	mov	w1, #0x4                // =4
    2fd0:      	add	x0, x25, x8
    2fd4:      	ldr	x8, [sp, #0x70]
    2fd8:      	add	x8, x8, #0x58
    2fdc:      	ldr	x8, [sp, #0x70]
    2fe0:      	add	x2, x8, #0x58
    2fe4:      	blr	x9
    2fe8:      	str	xzr, [sp, #0xc0]
    2fec:      	add	x2, x24, #0x938
    2ff0:      	add	x8, sp, #0xc0
    2ff4:      	add	x0, sp, #0xc0
    2ff8:      	mov	w1, #0x8                // =8
    2ffc:      	blr	x21
    3000:      	ldr	x8, [sp, #0xc0]
    3004:      	cbz	x8, 0x308c <generic_tracepoint_filter+0x50c>
    3008:      	str	wzr, [sp, #0xb8]
    300c:      	add	x8, x8, #0x4
    3010:      	add	x9, sp, #0xb8
    3014:      	mov	w10, #0x4               // =4
    3018:      	add	x0, sp, #0xb8
    301c:      	mov	w1, #0x4                // =4
    3020:      	mov	w19, #0x4               // =4
    3024:      	ldr	x8, [sp, #0xc0]
    3028:      	add	x2, x8, #0x4
    302c:      	blr	x10
    3030:      	ldr	x8, [sp, #0xc0]
    3034:      	ldrsw	x9, [sp, #0xb8]
    3038:      	add	x10, sp, #0xc8
    303c:      	mov	w11, #0x4               // =4
    3040:      	add	x0, sp, #0xc8
    3044:      	mov	w1, #0x10               // =16
    3048:      	add	x8, x8, x9, lsl #4
    304c:      	mov	w9, #0x10               // =16
    3050:      	add	x8, x8, #0x80
    3054:      	ldr	x8, [sp, #0xc0]
    3058:      	ldrsw	x9, [sp, #0xb8]
    305c:      	add	x8, x8, x9, lsl #4
    3060:      	add	x2, x8, #0x80
    3064:      	blr	x11
    3068:      	mov	w8, #0x5f44             // =24388
    306c:      	mov	w1, #0x4                // =4
    3070:      	add	x0, x25, x8
    3074:      	ldr	x8, [sp, #0xd0]
    3078:      	add	x8, x8, #0x158
    307c:      	ldr	x8, [sp, #0xd0]
    3080:      	add	x2, x8, #0x158
    3084:      	blr	x19
    3088:      	b	0x3090 <generic_tracepoint_filter+0x510>
    308c:      	str	wzr, [x29, #0x84]
    3090:      	mov	w8, #0x5f48             // =24392
    3094:      	mov	w9, #0x4                // =4
    3098:      	mov	w1, #0x4                // =4
    309c:      	mov	w19, #0x4               // =4
    30a0:      	add	x0, x25, x8
    30a4:      	ldr	x8, [sp, #0x78]
    30a8:      	add	x8, x8, #0x158
    30ac:      	ldr	x8, [sp, #0x78]
    30b0:      	add	x2, x8, #0x158
    30b4:      	blr	x9
    30b8:      	mov	w8, #0x5f4c             // =24396
    30bc:      	mov	w9, #0x4                // =4
    30c0:      	mov	w1, #0x4                // =4
    30c4:      	add	x0, x25, x8
    30c8:      	ldr	x8, [sp, #0x80]
    30cc:      	add	x8, x8, #0x118
    30d0:      	ldr	x8, [sp, #0x80]
    30d4:      	add	x2, x8, #0x118
    30d8:      	blr	x9
    30dc:      	mov	w8, #0x5f50             // =24400
    30e0:      	mov	w9, #0x4                // =4
    30e4:      	mov	w1, #0x4                // =4
    30e8:      	add	x0, x25, x8
    30ec:      	ldr	x8, [sp, #0x88]
    30f0:      	add	x8, x8, #0x98
    30f4:      	ldr	x8, [sp, #0x88]
    30f8:      	add	x2, x8, #0x98
    30fc:      	blr	x9
    3100:      	mov	w8, #0x5f54             // =24404
    3104:      	mov	w9, #0x4                // =4
    3108:      	mov	w1, #0x4                // =4
    310c:      	add	x0, x25, x8
    3110:      	ldr	x8, [sp, #0x90]
    3114:      	add	x8, x8, #0x98
    3118:      	ldr	x8, [sp, #0x90]
    311c:      	add	x2, x8, #0x98
    3120:      	blr	x9
    3124:      	mov	w8, #0x5f58             // =24408
    3128:      	mov	w9, #0x4                // =4
    312c:      	mov	w1, #0x4                // =4
    3130:      	add	x0, x25, x8
    3134:      	ldr	x8, [sp, #0x98]
    3138:      	add	x8, x8, #0x58
    313c:      	ldr	x8, [sp, #0x98]
    3140:      	add	x2, x8, #0x58
    3144:      	blr	x9
    3148:      	stp	xzr, xzr, [sp, #0xc0]
    314c:      	mov	w20, #0x8               // =8
    3150:      	add	x8, sp, #0xc8
    3154:      	mov	w9, #0x4                // =4
    3158:      	add	x0, sp, #0xc8
    315c:      	mov	w1, #0x8                // =8
    3160:      	mov	x2, x23
    3164:      	blr	x9
    3168:      	ldr	x8, [sp, #0xc8]
    316c:      	add	x9, sp, #0xc0
    3170:      	mov	w10, #0x4               // =4
    3174:      	add	x0, sp, #0xc0
    3178:      	mov	w1, #0x8                // =8
    317c:      	add	x8, x8, #0x90
    3180:      	ldr	x8, [sp, #0xc8]
    3184:      	add	x2, x8, #0x90
    3188:      	blr	x10
    318c:      	mov	w8, #0x5f5c             // =24412
    3190:      	mov	w1, #0x4                // =4
    3194:      	add	x0, x25, x8
    3198:      	ldr	x8, [sp, #0xc0]
    319c:      	add	x8, x8, #0x158
    31a0:      	ldr	x8, [sp, #0xc0]
    31a4:      	add	x2, x8, #0x158
    31a8:      	blr	x19
    31ac:      	ldr	w8, [x29, #0x74]
    31b0:      	cmp	w8, #0x1
    31b4:      	b.ne	0x31c4 <generic_tracepoint_filter+0x644>
    31b8:      	ldr	w8, [x29, #0x70]
    31bc:      	orr	w8, w8, #0x2000000
    31c0:      	str	w8, [x29, #0x70]
    31c4:      	add	x0, x29, #0xb8
    31c8:      	mov	w1, wzr
    31cc:      	mov	w2, #0x308              // =776
    31d0:      	bl	0x31d0 <generic_tracepoint_filter+0x650>
    31d4:      	mov	w8, #0x6290             // =25232
    31d8:      	add	x2, x24, #0x858
    31dc:      	mov	w19, #0x8               // =8
    31e0:      	mov	w9, #0x4                // =4
    31e4:      	add	x0, sp, #0xc8
    31e8:      	mov	w1, #0x8                // =8
    31ec:      	mov	w20, #0x4               // =4
    31f0:      	add	x21, x25, x8
    31f4:      	add	x8, sp, #0xc8
    31f8:      	blr	x9
    31fc:      	ldr	x8, [sp, #0xc8]
    3200:      	add	x9, sp, #0x58
    3204:      	add	x0, sp, #0x58
    3208:      	mov	w1, #0x8                // =8
    320c:      	add	x8, x8, #0x528
    3210:      	ldr	x8, [sp, #0xc8]
    3214:      	add	x2, x8, #0x528
    3218:      	blr	x20
    321c:      	str	wzr, [sp, #0xa4]
    3220:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x480>
    3224:      	ldr	x19, [sp, #0x58]
    3228:      	mov	w8, #0x1                // =1
    322c:      	add	x9, sp, #0xa4
    3230:      	add	x1, sp, #0xa4
    3234:      	ldr	x0, [x0]
    3238:      	blr	x8
    323c:      	cbz	x0, 0x36ac <generic_tracepoint_filter+0xb2c>
    3240:      	mov	w8, #0x1000             // =4096
    3244:      	stp	x21, x22, [sp, #0x30]
    3248:      	mov	x24, x0
    324c:      	add	x20, x0, #0x1, lsl #12  // =0x1000
    3250:      	str	x29, [sp, #0x40]
    3254:      	str	w8, [x29, #0x550]
    3258:      	mov	w8, #0x23               // =35
    325c:      	blr	x8
    3260:      	add	x2, x0, #0xb30
    3264:      	mov	w23, #0x8               // =8
    3268:      	add	x8, sp, #0xa8
    326c:      	mov	w9, #0x4                // =4
    3270:      	add	x0, sp, #0xa8
    3274:      	mov	w1, #0x8                // =8
    3278:      	mov	w29, #0x4               // =4
    327c:      	blr	x9
    3280:      	ldr	x22, [sp, #0xa8]
    3284:      	add	x25, x19, #0x48
    3288:      	add	x8, sp, #0xb0
    328c:      	mov	w9, #0x4                // =4
    3290:      	add	x0, sp, #0xb0
    3294:      	mov	w1, #0x8                // =8
    3298:      	mov	x2, x25
    329c:      	blr	x9
    32a0:      	ldr	x21, [sp, #0xb0]
    32a4:      	add	x8, sp, #0x58
    32a8:      	add	x0, sp, #0x58
    32ac:      	mov	w1, #0x8                // =8
    32b0:      	add	x2, x21, #0x10
    32b4:      	blr	x29
    32b8:      	ldr	x8, [sp, #0x58]
    32bc:      	cbz	x8, 0x3530 <generic_tracepoint_filter+0x9b0>
    32c0:      	ldr	x8, [sp, #0x40]
    32c4:      	stp	xzr, xzr, [sp, #0x58]
    32c8:      	add	x21, x22, #0x18
    32cc:      	add	x9, sp, #0x58
    32d0:      	add	x2, x22, #0x20
    32d4:      	mov	w22, #0x8               // =8
    32d8:      	stp	x24, xzr, [sp, #0x68]
    32dc:      	add	x0, sp, #0x58
    32e0:      	mov	w1, #0x8                // =8
    32e4:      	add	x29, x19, #0x40
    32e8:      	add	x19, x9, #0x8
    32ec:      	add	x24, x9, #0x18
    32f0:      	stp	xzr, xzr, [sp, #0x78]
    32f4:      	add	x23, x9, #0x20
    32f8:      	str	x20, [sp, #0x88]
    32fc:      	str	x20, [sp, #0x28]
    3300:      	mov	w20, #0x4               // =4
    3304:      	ldr	w8, [x8, #0x550]
    3308:      	strb	wzr, [sp, #0x94]
    330c:      	str	w8, [sp, #0x90]
    3310:      	mov	w8, #0x4                // =4
    3314:      	blr	x8
    3318:      	mov	w8, #0x4                // =4
    331c:      	mov	x0, x19
    3320:      	mov	w1, #0x8                // =8
    3324:      	mov	x2, x21
    3328:      	blr	x8
    332c:      	mov	w8, #0x4                // =4
    3330:      	mov	x0, x24
    3334:      	mov	w1, #0x8                // =8
    3338:      	mov	x2, x25
    333c:      	blr	x8
    3340:      	mov	x0, x23
    3344:      	mov	w1, #0x8                // =8
    3348:      	mov	x2, x29
    334c:      	blr	x20
    3350:      	ldr	x8, [sp, #0x78]
    3354:      	mov	w19, #0x80              // =128
    3358:      	add	x21, sp, #0xb8
    335c:      	add	x23, sp, #0xd8
    3360:      	sub	x8, x8, #0x20
    3364:      	str	x8, [sp, #0x80]
    3368:      	b	0x3374 <generic_tracepoint_filter+0x7f4>
    336c:      	subs	w19, w19, #0x1
    3370:      	b.eq	0x34e0 <generic_tracepoint_filter+0x960>
    3374:      	ldp	x20, x2, [sp, #0x70]
    3378:      	ldp	x8, x9, [sp, #0x58]
    337c:      	cmp	x20, x8
    3380:      	ccmp	x2, x9, #0x0, eq
    3384:      	b.eq	0x34d8 <generic_tracepoint_filter+0x958>
    3388:      	ldr	x29, [sp, #0x80]
    338c:      	mov	w8, #0x4                // =4
    3390:      	add	x0, sp, #0xb8
    3394:      	mov	w1, #0x8                // =8
    3398:      	blr	x8
    339c:      	ldr	x8, [sp, #0xb8]
    33a0:      	cmp	x20, x8
    33a4:      	b.eq	0x348c <generic_tracepoint_filter+0x90c>
    33a8:      	add	x25, x20, #0x18
    33ac:      	mov	w8, #0x4                // =4
    33b0:      	add	x0, sp, #0xd8
    33b4:      	mov	w1, #0x8                // =8
    33b8:      	mov	x2, x25
    33bc:      	blr	x8
    33c0:      	add	x8, sp, #0xd8
    33c4:      	ldr	x8, [x8]
    33c8:      	cmp	x8, x20
    33cc:      	b.eq	0x348c <generic_tracepoint_filter+0x90c>
    33d0:      	mov	w8, #0x4                // =4
    33d4:      	add	x9, sp, #0xc0
    33d8:      	add	x0, sp, #0xc0
    33dc:      	mov	w1, #0x8                // =8
    33e0:      	mov	x2, x25
    33e4:      	blr	x8
    33e8:      	add	x2, x20, #0x20
    33ec:      	mov	w8, #0x4                // =4
    33f0:      	mov	w9, #0x10               // =16
    33f4:      	add	x10, sp, #0xc8
    33f8:      	add	x0, sp, #0xc8
    33fc:      	mov	w1, #0x10               // =16
    3400:      	blr	x8
    3404:      	ldr	w20, [sp, #0xcc]
    3408:      	ldr	x8, [sp, #0x68]
    340c:      	ldr	x10, [sp, #0x88]
    3410:      	sub	x12, x10, x8
    3414:      	ldr	w25, [sp, #0x90]
    3418:      	subs	w10, w20, w25
    341c:      	ldr	x9, [sp, #0xd0]
    3420:      	csel	w10, wzr, w10, lo
    3424:      	cmp	w25, w20
    3428:      	csel	w11, w25, w20, lo
    342c:      	cinc	w13, w11, hi
    3430:      	sub	w14, w25, w13
    3434:      	subs	x12, x12, x13
    3438:      	str	w14, [sp, #0x90]
    343c:      	b.lo	0x34e0 <generic_tracepoint_filter+0x960>
    3440:      	cmp	x12, #0xfff
    3444:      	b.hi	0x34e0 <generic_tracepoint_filter+0x960>
    3448:      	cmp	w25, w20
    344c:      	b.ls	0x3458 <generic_tracepoint_filter+0x8d8>
    3450:      	mov	w13, #0x2f              // =47
    3454:      	strb	w13, [x8, x12]
    3458:      	add	x29, x8, x12
    345c:      	cmp	w25, w20
    3460:      	add	x2, x9, x10
    3464:      	and	w1, w11, #0xff
    3468:      	mov	w8, #0x4                // =4
    346c:      	cinc	x0, x29, hi
    3470:      	blr	x8
    3474:      	cmp	w25, w20
    3478:      	str	x29, [sp, #0x88]
    347c:      	b.ls	0x34e0 <generic_tracepoint_filter+0x960>
    3480:      	ldr	x8, [sp, #0xc0]
    3484:      	str	x8, [sp, #0x70]
    3488:      	b	0x336c <generic_tracepoint_filter+0x7ec>
    348c:      	add	x2, x29, #0x10
    3490:      	mov	w8, #0x4                // =4
    3494:      	add	x0, sp, #0xd8
    3498:      	mov	w1, #0x8                // =8
    349c:      	blr	x8
    34a0:      	add	x20, sp, #0xd8
    34a4:      	ldr	x8, [sp, #0x80]
    34a8:      	ldr	x9, [x20]
    34ac:      	cmp	x8, x9
    34b0:      	b.eq	0x34d8 <generic_tracepoint_filter+0x958>
    34b4:      	add	x2, x29, #0x18
    34b8:      	mov	w8, #0x4                // =4
    34bc:      	mov	x0, x24
    34c0:      	mov	w1, #0x8                // =8
    34c4:      	blr	x8
    34c8:      	ldr	x8, [x20]
    34cc:      	add	x9, x8, #0x20
    34d0:      	stp	x9, x8, [sp, #0x78]
    34d4:      	b	0x336c <generic_tracepoint_filter+0x7ec>
    34d8:      	mov	w8, #0x1                // =1
    34dc:      	strb	w8, [sp, #0x94]
    34e0:      	ldr	x24, [sp, #0x88]
    34e4:      	ldr	x9, [sp, #0x28]
    34e8:      	cmp	x24, x9
    34ec:      	b.eq	0x3580 <generic_tracepoint_filter+0xa00>
    34f0:      	ldrb	w8, [sp, #0x94]
    34f4:      	ldp	x22, x29, [sp, #0x38]
    34f8:      	cmp	w8, #0x0
    34fc:      	ldr	x21, [sp, #0x30]
    3500:      	cset	w8, eq
    3504:      	lsl	w9, w8, #1
    3508:      	ldr	w8, [sp, #0x90]
    350c:      	str	w9, [x29, #0x554]
    3510:      	cmp	w8, #0x1
    3514:      	str	w8, [x29, #0x550]
    3518:      	b.lt	0x3528 <generic_tracepoint_filter+0x9a8>
    351c:      	mov	w9, #0x1000             // =4096
    3520:      	sub	w8, w9, w8
    3524:      	str	w8, [x29, #0x550]
    3528:      	cbnz	x24, 0x3594 <generic_tracepoint_filter+0xa14>
    352c:      	b	0x36ac <generic_tracepoint_filter+0xb2c>
    3530:      	add	x2, x21, #0x18
    3534:      	mov	w8, #0x8                // =8
    3538:      	mov	w9, #0x4                // =4
    353c:      	add	x10, sp, #0x58
    3540:      	add	x0, sp, #0x58
    3544:      	mov	w1, #0x8                // =8
    3548:      	blr	x9
    354c:      	ldr	x8, [sp, #0x58]
    3550:      	cmp	x8, x21
    3554:      	b.eq	0x32c0 <generic_tracepoint_filter+0x740>
    3558:      	ldr	x29, [sp, #0x40]
    355c:      	ldr	w9, [x29, #0x550]
    3560:      	sub	w8, w9, #0xa
    3564:      	cmp	w9, #0x9
    3568:      	str	w8, [x29, #0x550]
    356c:      	b.gt	0x3a50 <generic_tracepoint_filter+0xed0>
    3570:      	mov	w9, #-0x24              // =-36
    3574:      	mov	x24, x20
    3578:      	str	w9, [x29, #0x554]
    357c:      	b	0x3590 <generic_tracepoint_filter+0xa10>
    3580:      	ldr	x29, [sp, #0x40]
    3584:      	mov	w8, wzr
    3588:      	mov	x24, x9
    358c:      	str	xzr, [x29, #0x550]
    3590:      	ldp	x21, x22, [sp, #0x30]
    3594:      	subs	w9, w8, #0x7f
    3598:      	mov	w10, #0x7f              // =127
    359c:      	mov	x11, x29
    35a0:      	mov	x0, x21
    35a4:      	mov	x2, x24
    35a8:      	csel	w29, w8, w10, lo
    35ac:      	csel	w19, wzr, w9, lo
    35b0:      	cmp	w8, #0xff
    35b4:      	mov	w9, #0xff               // =255
    35b8:      	csel	w8, w8, w9, lo
    35bc:      	and	w1, w8, #0xff
    35c0:      	str	w1, [x11, #0x550]
    35c4:      	mov	w8, #0x4                // =4
    35c8:      	blr	x8
    35cc:      	adrp	x25, 0x3000 <generic_tracepoint_filter+0x480>
    35d0:      	ldr	x25, [x25]
    35d4:      	cbz	x0, 0x3644 <generic_tracepoint_filter+0xac4>
    35d8:      	neg	w8, w0
    35dc:      	mov	w9, #0x1                // =1
    35e0:      	add	x1, sp, #0x58
    35e4:      	strh	w8, [sp, #0x58]
    35e8:      	mov	w8, #0x8                // =8
    35ec:      	mov	x0, x25
    35f0:      	mov	w20, #0x1               // =1
    35f4:      	strh	w8, [sp, #0x5a]
    35f8:      	mov	x8, #0x2de              // =734
    35fc:      	movk	x8, #0x4, lsl #32
    3600:      	stur	x8, [sp, #0x5c]
    3604:      	add	x8, sp, #0x58
    3608:      	blr	x9
    360c:      	cbz	x0, 0x3620 <generic_tracepoint_filter+0xaa0>
    3610:      	ldr	w8, [x0]
    3614:      	add	w8, w8, #0x1
    3618:      	str	w8, [x0]
    361c:      	b	0x3644 <generic_tracepoint_filter+0xac4>
    3620:      	str	w20, [sp, #0xc8]
    3624:      	mov	x3, xzr
    3628:      	mov	w8, #0x2                // =2
    362c:      	add	x9, sp, #0x58
    3630:      	add	x10, sp, #0xc8
    3634:      	add	x1, sp, #0x58
    3638:      	add	x2, sp, #0xc8
    363c:      	mov	x0, x25
    3640:      	blr	x8
    3644:      	ldr	x9, [sp, #0xe8]
    3648:      	mov	w8, #0x6390             // =25488
    364c:      	add	x2, x24, x19
    3650:      	mov	w1, w29
    3654:      	add	x0, x9, x8
    3658:      	mov	w8, #0x4                // =4
    365c:      	blr	x8
    3660:      	ldr	x29, [sp, #0x40]
    3664:      	cbz	x0, 0x36ac <generic_tracepoint_filter+0xb2c>
    3668:      	neg	w8, w0
    366c:      	mov	w9, #0x1                // =1
    3670:      	add	x1, sp, #0x58
    3674:      	strh	w8, [sp, #0x58]
    3678:      	mov	w8, #0x8                // =8
    367c:      	mov	x0, x25
    3680:      	mov	w19, #0x1               // =1
    3684:      	strh	w8, [sp, #0x5a]
    3688:      	mov	x8, #0x2e0              // =736
    368c:      	movk	x8, #0x4, lsl #32
    3690:      	stur	x8, [sp, #0x5c]
    3694:      	add	x8, sp, #0x58
    3698:      	blr	x9
    369c:      	cbz	x0, 0x36d0 <generic_tracepoint_filter+0xb50>
    36a0:      	ldr	w8, [x0]
    36a4:      	add	w8, w8, #0x1
    36a8:      	str	w8, [x0]
    36ac:      	ldr	w8, [x29, #0x550]
    36b0:      	sub	w9, w8, #0x101
    36b4:      	cmn	w9, #0x101
    36b8:      	b.hi	0x3704 <generic_tracepoint_filter+0xb84>
    36bc:      	ldr	x20, [sp, #0xe8]
    36c0:      	ldr	x24, [sp, #0x48]
    36c4:      	mov	w8, #-0x1               // =-1
    36c8:      	stur	w8, [x29, #0xb8]
    36cc:      	b	0x3850 <generic_tracepoint_filter+0xcd0>
    36d0:      	str	w19, [sp, #0xc8]
    36d4:      	mov	x3, xzr
    36d8:      	mov	w8, #0x2                // =2
    36dc:      	add	x9, sp, #0x58
    36e0:      	add	x10, sp, #0xc8
    36e4:      	add	x1, sp, #0x58
    36e8:      	add	x2, sp, #0xc8
    36ec:      	mov	x0, x25
    36f0:      	blr	x8
    36f4:      	ldr	w8, [x29, #0x550]
    36f8:      	sub	w9, w8, #0x101
    36fc:      	cmn	w9, #0x101
    3700:      	b.ls	0x36bc <generic_tracepoint_filter+0xb3c>
    3704:      	ldr	x20, [sp, #0xe8]
    3708:      	and	x24, x8, #0xff
    370c:      	mov	w8, #0x5f80             // =24448
    3710:      	mov	x2, x21
    3714:      	mov	w1, w24
    3718:      	add	x0, x20, x8
    371c:      	mov	w8, #0x4                // =4
    3720:      	blr	x8
    3724:      	mov	x23, x0
    3728:      	cbz	x0, 0x37a4 <generic_tracepoint_filter+0xc24>
    372c:      	neg	w8, w23
    3730:      	adrp	x25, 0x3000 <generic_tracepoint_filter+0x480>
    3734:      	mov	w9, #0x1                // =1
    3738:      	strh	w8, [sp, #0x58]
    373c:      	mov	w8, #0xf                // =15
    3740:      	add	x1, sp, #0x58
    3744:      	mov	w19, #0x1               // =1
    3748:      	strh	w8, [sp, #0x5a]
    374c:      	mov	x8, #0x164              // =356
    3750:      	movk	x8, #0x4, lsl #32
    3754:      	stur	x8, [sp, #0x5c]
    3758:      	add	x8, sp, #0x58
    375c:      	ldr	x25, [x25]
    3760:      	mov	x0, x25
    3764:      	blr	x9
    3768:      	cbz	x0, 0x377c <generic_tracepoint_filter+0xbfc>
    376c:      	ldr	w8, [x0]
    3770:      	add	w8, w8, #0x1
    3774:      	str	w8, [x0]
    3778:      	b	0x37a0 <generic_tracepoint_filter+0xc20>
    377c:      	str	w19, [sp, #0xc8]
    3780:      	mov	x3, xzr
    3784:      	mov	w8, #0x2                // =2
    3788:      	add	x9, sp, #0x58
    378c:      	add	x10, sp, #0xc8
    3790:      	add	x1, sp, #0x58
    3794:      	add	x2, sp, #0xc8
    3798:      	mov	x0, x25
    379c:      	blr	x8
    37a0:      	ldr	x20, [sp, #0xe8]
    37a4:      	cmp	w23, #0x0
    37a8:      	csel	w8, w24, w23, eq
    37ac:      	cmp	w24, #0x7f
    37b0:      	stur	w8, [x29, #0xb8]
    37b4:      	mov	w8, #0x7f               // =127
    37b8:      	csel	w1, w24, w8, lo
    37bc:      	mov	w8, #0x6080             // =24704
    37c0:      	add	x0, x20, x8
    37c4:      	mov	w8, #0x6390             // =25488
    37c8:      	add	x2, x20, x8
    37cc:      	mov	w8, #0x4                // =4
    37d0:      	blr	x8
    37d4:      	ldr	x24, [sp, #0x48]
    37d8:      	cbz	x0, 0x3850 <generic_tracepoint_filter+0xcd0>
    37dc:      	neg	w8, w0
    37e0:      	adrp	x23, 0x3000 <generic_tracepoint_filter+0x480>
    37e4:      	mov	w9, #0x1                // =1
    37e8:      	strh	w8, [sp, #0x58]
    37ec:      	mov	w8, #0xf                // =15
    37f0:      	add	x1, sp, #0x58
    37f4:      	mov	w19, #0x1               // =1
    37f8:      	strh	w8, [sp, #0x5a]
    37fc:      	mov	x8, #0x16a              // =362
    3800:      	movk	x8, #0x4, lsl #32
    3804:      	stur	x8, [sp, #0x5c]
    3808:      	add	x8, sp, #0x58
    380c:      	ldr	x23, [x23]
    3810:      	mov	x0, x23
    3814:      	blr	x9
    3818:      	cbz	x0, 0x382c <generic_tracepoint_filter+0xcac>
    381c:      	ldr	w8, [x0]
    3820:      	add	w8, w8, #0x1
    3824:      	str	w8, [x0]
    3828:      	b	0x3850 <generic_tracepoint_filter+0xcd0>
    382c:      	str	w19, [sp, #0xc8]
    3830:      	mov	x3, xzr
    3834:      	mov	w8, #0x2                // =2
    3838:      	add	x9, sp, #0x58
    383c:      	add	x10, sp, #0xc8
    3840:      	add	x1, sp, #0x58
    3844:      	add	x2, sp, #0xc8
    3848:      	mov	x0, x23
    384c:      	blr	x8
    3850:      	ldrb	w8, [x20, #0x1]
    3854:      	orr	w8, w8, #0x10
    3858:      	strb	w8, [x20, #0x1]
    385c:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x480>
    3860:      	mov	w8, #0x5ef8             // =24312
    3864:      	ldr	x0, [x0]
    3868:      	add	x1, x20, x8
    386c:      	mov	w8, #0x1                // =1
    3870:      	blr	x8
    3874:      	cbz	x0, 0x4a54 <generic_tracepoint_filter+0x1ed4>
    3878:      	ldr	x21, [x20, #0x5eb8]
    387c:      	cmp	x21, #0x6
    3880:      	b.hs	0x3a18 <generic_tracepoint_filter+0xe98>
    3884:      	ldrsw	x8, [x0]
    3888:      	mov	x23, x0
    388c:      	cbz	w8, 0x3a34 <generic_tracepoint_filter+0xeb4>
    3890:      	cmp	x21, x8
    3894:      	b.hs	0x3a18 <generic_tracepoint_filter+0xe98>
    3898:      	str	x8, [sp, #0x28]
    389c:      	stp	x29, x24, [sp, #0x40]
    38a0:      	adrp	x24, 0x3000 <generic_tracepoint_filter+0x480>
    38a4:      	mov	w8, #0x1                // =1
    38a8:      	add	x9, sp, #0x58
    38ac:      	str	x20, [sp, #0xe8]
    38b0:      	add	x1, sp, #0x58
    38b4:      	str	x22, [sp, #0x38]
    38b8:      	str	w21, [sp, #0x58]
    38bc:      	str	wzr, [sp, #0xc8]
    38c0:      	ldr	x24, [x24]
    38c4:      	mov	x0, x24
    38c8:      	blr	x8
    38cc:      	cbz	x0, 0x3b80 <generic_tracepoint_filter+0x1000>
    38d0:      	ldr	w8, [x0]
    38d4:      	mov	x25, x0
    38d8:      	cbz	w8, 0x3b80 <generic_tracepoint_filter+0x1000>
    38dc:      	ldr	x9, [sp, #0x48]
    38e0:      	ldr	w9, [x9, #0x68]
    38e4:      	tbnz	w9, #0x1f, 0x49fc <generic_tracepoint_filter+0x1e7c>
    38e8:      	cmp	w8, #0x1b
    38ec:      	b.hi	0x49fc <generic_tracepoint_filter+0x1e7c>
    38f0:      	mov	w9, #0x1                // =1
    38f4:      	lsl	w9, w9, w8
    38f8:      	tst	w9, #0x60
    38fc:      	b.ne	0x3af4 <generic_tracepoint_filter+0xf74>
    3900:      	mov	w10, #0x100             // =256
    3904:      	movk	w10, #0x400, lsl #16
    3908:      	tst	w9, w10
    390c:      	b.ne	0x3a70 <generic_tracepoint_filter+0xef0>
    3910:      	mov	w9, #0x1                // =1
    3914:      	lsl	w8, w9, w8
    3918:      	mov	w9, #0x200              // =512
    391c:      	movk	w9, #0x800, lsl #16
    3920:      	tst	w8, w9
    3924:      	b.eq	0x49fc <generic_tracepoint_filter+0x1e7c>
    3928:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x480>
    392c:      	add	x1, x25, #0x4
    3930:      	mov	w8, #0x1                // =1
    3934:      	ldr	x0, [x0]
    3938:      	blr	x8
    393c:      	cbz	x0, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3940:      	ldr	x8, [sp, #0x48]
    3944:      	mov	x20, x0
    3948:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x480>
    394c:      	mov	w9, #0x7f               // =127
    3950:      	ldr	w8, [x8, #0x68]
    3954:      	ldr	x0, [x0]
    3958:      	add	x1, sp, #0xc8
    395c:      	cmp	w8, #0x7f
    3960:      	csel	w19, w8, w9, lt
    3964:      	mov	w8, #0x1                // =1
    3968:      	add	x9, sp, #0xc8
    396c:      	blr	x8
    3970:      	cbz	x0, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3974:      	sxtw	x1, w19
    3978:      	mov	x29, x0
    397c:      	lsl	w8, w1, #3
    3980:      	str	w8, [x0]
    3984:      	ldr	x8, [sp, #0x48]
    3988:      	ldr	w8, [x8, #0x6c]
    398c:      	cbnz	w8, 0x39ec <generic_tracepoint_filter+0xe6c>
    3990:      	ldr	x11, [sp, #0x48]
    3994:      	and	w13, w1, #0x7f
    3998:      	mov	x8, xzr
    399c:      	ldr	w12, [x11, #0x68]
    39a0:      	add	x9, x11, #0x1f0
    39a4:      	add	x10, x11, #0x170
    39a8:      	sub	w11, w12, w1
    39ac:      	add	w12, w12, w13
    39b0:      	add	w11, w11, w13
    39b4:      	mvn	w13, w1
    39b8:      	add	w12, w13, w12
    39bc:      	cmp	x8, #0x7f
    39c0:      	b.eq	0x39e0 <generic_tracepoint_filter+0xe60>
    39c4:      	and	x13, x12, #0x7f
    39c8:      	sub	w12, w12, #0x1
    39cc:      	ldrb	w13, [x10, x13]
    39d0:      	strb	w13, [x9, x8]
    39d4:      	add	x8, x8, #0x1
    39d8:      	cmp	x11, x8
    39dc:      	b.ne	0x39bc <generic_tracepoint_filter+0xe3c>
    39e0:      	ldr	x9, [sp, #0x48]
    39e4:      	mov	w8, #0x1                // =1
    39e8:      	str	w8, [x9, #0x6c]
    39ec:      	cmp	w1, #0x7f
    39f0:      	b.hi	0x3a0c <generic_tracepoint_filter+0xe8c>
    39f4:      	ldr	x8, [sp, #0x48]
    39f8:      	add	x0, x29, #0x4
    39fc:      	add	x2, x8, #0x1f0
    3a00:      	mov	w8, #0x4                // =4
    3a04:      	blr	x8
    3a08:      	tbnz	x0, #0x3f, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3a0c:      	mov	w8, #0x1                // =1
    3a10:      	mov	x0, x20
    3a14:      	b	0x3aec <generic_tracepoint_filter+0xf6c>
    3a18:      	ldr	w8, [x24]
    3a1c:      	str	w8, [x20, #0x10]
    3a20:      	ldr	x8, [x24, #0x8]
    3a24:      	str	x8, [x20, #0x18]
    3a28:      	ldrb	w8, [x29]
    3a2c:      	cbnz	w8, 0x4a38 <generic_tracepoint_filter+0x1eb8>
    3a30:      	b	0x4a54 <generic_tracepoint_filter+0x1ed4>
    3a34:      	mov	w8, #0x1                // =1
    3a38:      	strb	w8, [x29]
    3a3c:      	ldr	w8, [x24]
    3a40:      	str	w8, [x20, #0x10]
    3a44:      	ldr	x8, [x24, #0x8]
    3a48:      	str	x8, [x20, #0x18]
    3a4c:      	b	0x4a38 <generic_tracepoint_filter+0x1eb8>
    3a50:      	mov	w8, #0x2964             // =10596
    3a54:      	add	x20, x24, #0xff6
    3a58:      	strh	w8, [x24, #0xffe]
    3a5c:      	adrp	x8, 0x3000 <generic_tracepoint_filter+0x480>
    3a60:      	add	x8, x8, #0x0
    3a64:      	ldr	x8, [x8]
    3a68:      	str	x8, [x20]
    3a6c:      	b	0x32c0 <generic_tracepoint_filter+0x740>
    3a70:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x480>
    3a74:      	add	x1, x25, #0x4
    3a78:      	mov	w8, #0x1                // =1
    3a7c:      	ldr	x0, [x0]
    3a80:      	blr	x8
    3a84:      	cbz	x0, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3a88:      	mov	x19, x0
    3a8c:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x480>
    3a90:      	mov	w8, #0x1                // =1
    3a94:      	ldr	x0, [x0]
    3a98:      	add	x9, sp, #0xc8
    3a9c:      	add	x1, sp, #0xc8
    3aa0:      	blr	x8
    3aa4:      	cbz	x0, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3aa8:      	mov	w1, wzr
    3aac:      	mov	w2, #0x104              // =260
    3ab0:      	mov	x29, x0
    3ab4:      	bl	0x3ab4 <generic_tracepoint_filter+0xf34>
    3ab8:      	ldr	x10, [sp, #0x48]
    3abc:      	mov	x0, x29
    3ac0:      	ldr	w8, [x10, #0x68]
    3ac4:      	add	x2, x10, #0x70
    3ac8:      	lsl	w9, w8, #3
    3acc:      	and	x8, x8, #0xff
    3ad0:      	str	w9, [x0], #0x4
    3ad4:      	mov	w9, #0x4                // =4
    3ad8:      	ldrb	w1, [x10, #0x68]
    3adc:      	blr	x9
    3ae0:      	tbnz	x0, #0x3f, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3ae4:      	mov	w8, #0x1                // =1
    3ae8:      	mov	x0, x19
    3aec:      	mov	x1, x29
    3af0:      	b	0x3b48 <generic_tracepoint_filter+0xfc8>
    3af4:      	ldr	w8, [x25, #0x8]
    3af8:      	cmn	w8, #0x1
    3afc:      	b.eq	0x3b20 <generic_tracepoint_filter+0xfa0>
    3b00:      	ldr	x9, [sp, #0x48]
    3b04:      	ldr	x9, [x9, #0x370]
    3b08:      	lsr	x8, x9, x8
    3b0c:      	tbz	w8, #0x0, 0x3b20 <generic_tracepoint_filter+0xfa0>
    3b10:      	mov	x0, #0xffee             // =65518
    3b14:      	movk	x0, #0xadc0, lsl #16
    3b18:      	movk	x0, #0xb, lsl #32
    3b1c:      	b	0x3b4c <generic_tracepoint_filter+0xfcc>
    3b20:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x480>
    3b24:      	mov	w8, #0x1                // =1
    3b28:      	add	x9, sp, #0x58
    3b2c:      	ldr	x0, [x0]
    3b30:      	add	x1, sp, #0x58
    3b34:      	blr	x8
    3b38:      	cbz	x0, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3b3c:      	ldr	x8, [sp, #0x48]
    3b40:      	add	x1, x8, #0x70
    3b44:      	mov	w8, #0x1                // =1
    3b48:      	blr	x8
    3b4c:      	ldr	w8, [x25]
    3b50:      	cmp	w8, #0x25
    3b54:      	b.hi	0x3b7c <generic_tracepoint_filter+0xffc>
    3b58:      	mov	w9, #0x1                // =1
    3b5c:      	lsl	x8, x9, x8
    3b60:      	mov	x9, #0x50               // =80
    3b64:      	movk	x9, #0xc00, lsl #16
    3b68:      	movk	x9, #0x20, lsl #32
    3b6c:      	tst	x8, x9
    3b70:      	b.eq	0x3b7c <generic_tracepoint_filter+0xffc>
    3b74:      	cbnz	x0, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3b78:      	b	0x3b80 <generic_tracepoint_filter+0x1000>
    3b7c:      	cbz	x0, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3b80:      	adrp	x8, 0x3000 <generic_tracepoint_filter+0x480>
    3b84:      	ldr	x8, [x8]
    3b88:      	ldrb	w8, [x8]
    3b8c:      	cbz	w8, 0x3e04 <generic_tracepoint_filter+0x1284>
    3b90:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x480>
    3b94:      	mov	w8, #0x1                // =1
    3b98:      	ldr	x0, [x0]
    3b9c:      	ldr	x1, [sp, #0x48]
    3ba0:      	blr	x8
    3ba4:      	cbz	x0, 0x3e04 <generic_tracepoint_filter+0x1284>
    3ba8:      	add	w8, w21, #0x5
    3bac:      	str	wzr, [sp, #0xc8]
    3bb0:      	add	x9, sp, #0x58
    3bb4:      	mov	x25, x0
    3bb8:      	str	w8, [sp, #0x58]
    3bbc:      	mov	w8, #0x1                // =1
    3bc0:      	add	x1, sp, #0x58
    3bc4:      	mov	x0, x24
    3bc8:      	blr	x8
    3bcc:      	cbz	x0, 0x3e04 <generic_tracepoint_filter+0x1284>
    3bd0:      	ldr	w8, [x0]
    3bd4:      	mov	x24, x0
    3bd8:      	cbz	w8, 0x3e04 <generic_tracepoint_filter+0x1284>
    3bdc:      	ldr	w9, [x25]
    3be0:      	tbnz	w9, #0x1f, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3be4:      	cmp	w8, #0x1b
    3be8:      	b.hi	0x49fc <generic_tracepoint_filter+0x1e7c>
    3bec:      	mov	w9, #0x1                // =1
    3bf0:      	lsl	w9, w9, w8
    3bf4:      	tst	w9, #0x60
    3bf8:      	b.ne	0x3d80 <generic_tracepoint_filter+0x1200>
    3bfc:      	mov	w10, #0x100             // =256
    3c00:      	movk	w10, #0x400, lsl #16
    3c04:      	tst	w9, w10
    3c08:      	b.ne	0x3d00 <generic_tracepoint_filter+0x1180>
    3c0c:      	mov	w9, #0x1                // =1
    3c10:      	lsl	w8, w9, w8
    3c14:      	mov	w9, #0x200              // =512
    3c18:      	movk	w9, #0x800, lsl #16
    3c1c:      	tst	w8, w9
    3c20:      	b.eq	0x49fc <generic_tracepoint_filter+0x1e7c>
    3c24:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x480>
    3c28:      	add	x1, x24, #0x4
    3c2c:      	mov	w8, #0x1                // =1
    3c30:      	ldr	x0, [x0]
    3c34:      	blr	x8
    3c38:      	cbz	x0, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3c3c:      	ldr	w8, [x25]
    3c40:      	mov	x20, x0
    3c44:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x480>
    3c48:      	mov	w9, #0x7f               // =127
    3c4c:      	ldr	x0, [x0]
    3c50:      	add	x1, sp, #0xc8
    3c54:      	cmp	w8, #0x7f
    3c58:      	csel	w19, w8, w9, lt
    3c5c:      	mov	w8, #0x1                // =1
    3c60:      	add	x9, sp, #0xc8
    3c64:      	blr	x8
    3c68:      	cbz	x0, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3c6c:      	sxtw	x1, w19
    3c70:      	mov	x29, x0
    3c74:      	lsl	w8, w1, #3
    3c78:      	str	w8, [x0]
    3c7c:      	ldr	w8, [x25, #0x4]
    3c80:      	cbnz	w8, 0x3cd8 <generic_tracepoint_filter+0x1158>
    3c84:      	ldr	w12, [x25]
    3c88:      	and	w13, w1, #0x7f
    3c8c:      	mov	x8, xzr
    3c90:      	add	x9, x25, #0x188
    3c94:      	add	x10, x25, #0x108
    3c98:      	sub	w11, w12, w1
    3c9c:      	add	w12, w12, w13
    3ca0:      	add	w11, w11, w13
    3ca4:      	mvn	w13, w1
    3ca8:      	add	w12, w13, w12
    3cac:      	cmp	x8, #0x7f
    3cb0:      	b.eq	0x3cd0 <generic_tracepoint_filter+0x1150>
    3cb4:      	and	x13, x12, #0x7f
    3cb8:      	sub	w12, w12, #0x1
    3cbc:      	ldrb	w13, [x10, x13]
    3cc0:      	strb	w13, [x9, x8]
    3cc4:      	add	x8, x8, #0x1
    3cc8:      	cmp	x11, x8
    3ccc:      	b.ne	0x3cac <generic_tracepoint_filter+0x112c>
    3cd0:      	mov	w8, #0x1                // =1
    3cd4:      	str	w8, [x25, #0x4]
    3cd8:      	cmp	w1, #0x7f
    3cdc:      	b.hi	0x3cf4 <generic_tracepoint_filter+0x1174>
    3ce0:      	add	x0, x29, #0x4
    3ce4:      	add	x2, x25, #0x188
    3ce8:      	mov	w8, #0x4                // =4
    3cec:      	blr	x8
    3cf0:      	tbnz	x0, #0x3f, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3cf4:      	mov	w8, #0x1                // =1
    3cf8:      	mov	x0, x20
    3cfc:      	b	0x3d78 <generic_tracepoint_filter+0x11f8>
    3d00:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x480>
    3d04:      	add	x1, x24, #0x4
    3d08:      	mov	w8, #0x1                // =1
    3d0c:      	ldr	x0, [x0]
    3d10:      	blr	x8
    3d14:      	cbz	x0, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3d18:      	mov	x19, x0
    3d1c:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x480>
    3d20:      	mov	w8, #0x1                // =1
    3d24:      	ldr	x0, [x0]
    3d28:      	add	x9, sp, #0xc8
    3d2c:      	add	x1, sp, #0xc8
    3d30:      	blr	x8
    3d34:      	cbz	x0, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3d38:      	mov	w1, wzr
    3d3c:      	mov	w2, #0x104              // =260
    3d40:      	mov	x29, x0
    3d44:      	bl	0x3d44 <generic_tracepoint_filter+0x11c4>
    3d48:      	ldr	w8, [x25]
    3d4c:      	mov	x0, x29
    3d50:      	add	x2, x25, #0x8
    3d54:      	lsl	w9, w8, #3
    3d58:      	and	x8, x8, #0xff
    3d5c:      	str	w9, [x0], #0x4
    3d60:      	mov	w9, #0x4                // =4
    3d64:      	ldrb	w1, [x25]
    3d68:      	blr	x9
    3d6c:      	tbnz	x0, #0x3f, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3d70:      	mov	w8, #0x1                // =1
    3d74:      	mov	x0, x19
    3d78:      	mov	x1, x29
    3d7c:      	b	0x3dcc <generic_tracepoint_filter+0x124c>
    3d80:      	ldr	w8, [x24, #0x8]
    3d84:      	cmn	w8, #0x1
    3d88:      	b.eq	0x3da8 <generic_tracepoint_filter+0x1228>
    3d8c:      	ldr	x9, [x25, #0x308]
    3d90:      	lsr	x8, x9, x8
    3d94:      	tbz	w8, #0x0, 0x3da8 <generic_tracepoint_filter+0x1228>
    3d98:      	mov	x0, #0xffee             // =65518
    3d9c:      	movk	x0, #0xadc0, lsl #16
    3da0:      	movk	x0, #0xb, lsl #32
    3da4:      	b	0x3dd0 <generic_tracepoint_filter+0x1250>
    3da8:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x480>
    3dac:      	mov	w8, #0x1                // =1
    3db0:      	add	x9, sp, #0x58
    3db4:      	ldr	x0, [x0]
    3db8:      	add	x1, sp, #0x58
    3dbc:      	blr	x8
    3dc0:      	cbz	x0, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3dc4:      	add	x1, x25, #0x8
    3dc8:      	mov	w8, #0x1                // =1
    3dcc:      	blr	x8
    3dd0:      	ldr	w8, [x24]
    3dd4:      	cmp	w8, #0x25
    3dd8:      	b.hi	0x3e00 <generic_tracepoint_filter+0x1280>
    3ddc:      	mov	w9, #0x1                // =1
    3de0:      	lsl	x8, x9, x8
    3de4:      	mov	x9, #0x50               // =80
    3de8:      	movk	x9, #0xc00, lsl #16
    3dec:      	movk	x9, #0x20, lsl #32
    3df0:      	tst	x8, x9
    3df4:      	b.eq	0x3e00 <generic_tracepoint_filter+0x1280>
    3df8:      	cbnz	x0, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3dfc:      	b	0x3e04 <generic_tracepoint_filter+0x1284>
    3e00:      	cbz	x0, 0x49fc <generic_tracepoint_filter+0x1e7c>
    3e04:      	lsl	w8, w21, #2
    3e08:      	add	x9, x8, #0x4
    3e0c:      	ldr	w8, [x9, x23]
    3e10:      	add	w9, w8, w9
    3e14:      	and	w11, w9, #0x3ff
    3e18:      	add	w9, w9, #0x4
    3e1c:      	and	x9, x9, #0x3ff
    3e20:      	add	x10, x11, #0x8
    3e24:      	ldr	w9, [x9, x23]
    3e28:      	cmp	w9, #0x5
    3e2c:      	b.lo	0x3ebc <generic_tracepoint_filter+0x133c>
    3e30:      	add	x9, x10, x23
    3e34:      	ldr	w10, [x9, #0x8]
    3e38:      	ldp	w12, w22, [x9]
    3e3c:      	stp	x9, x11, [sp, #0x8]
    3e40:      	mov	w9, #0x4                // =4
    3e44:      	cmp	w10, #0x4
    3e48:      	stp	xzr, xzr, [sp, #0x58]
    3e4c:      	csel	w9, w10, w9, lo
    3e50:      	cmp	w12, #0x6
    3e54:      	b.ne	0x3e60 <generic_tracepoint_filter+0x12e0>
    3e58:      	mov	x11, #0x100000001       // =4294967297
    3e5c:      	stp	x11, x11, [sp, #0x58]
    3e60:      	cbz	w10, 0x42c4 <generic_tracepoint_filter+0x1744>
    3e64:      	ldr	x10, [sp, #0x48]
    3e68:      	add	w8, w8, w21, lsl #2
    3e6c:      	tst	x22, #0x1
    3e70:      	add	x25, sp, #0x58
    3e74:      	str	w12, [sp, #0x30]
    3e78:      	add	w8, w8, #0x4
    3e7c:      	and	x8, x8, #0x3ff
    3e80:      	add	x21, x8, #0x14
    3e84:      	sub	x8, x9, #0x1
    3e88:      	mov	w9, #0x3                // =3
    3e8c:      	add	x11, x10, #0x24
    3e90:      	str	x11, [sp, #0x20]
    3e94:      	csel	x11, x10, x11, eq
    3e98:      	cmp	x8, #0x3
    3e9c:      	add	x10, x10, #0x10
    3ea0:      	csel	x8, x8, x9, lo
    3ea4:      	and	x9, x21, #0x7fc
    3ea8:      	mov	x20, x11
    3eac:      	str	x10, [sp, #0x18]
    3eb0:      	add	x24, x23, x9
    3eb4:      	add	x19, x8, #0x1
    3eb8:      	b	0x3ef4 <generic_tracepoint_filter+0x1374>
    3ebc:      	mov	w9, #0x1                // =1
    3ec0:      	mov	w8, w10
    3ec4:      	b	0x430c <generic_tracepoint_filter+0x178c>
    3ec8:      	mov	w8, #0x1                // =1
    3ecc:      	ldr	w12, [sp, #0x30]
    3ed0:      	mov	x11, x20
    3ed4:      	cmp	w12, #0x6
    3ed8:      	eor	w8, w8, #0x1
    3edc:      	csinc	w9, w8, wzr, eq
    3ee0:      	str	w9, [x25], #0x4
    3ee4:      	add	x21, x21, #0x4
    3ee8:      	add	x24, x24, #0x4
    3eec:      	subs	x19, x19, #0x1
    3ef0:      	b.eq	0x42c4 <generic_tracepoint_filter+0x1744>
    3ef4:      	cmp	x21, #0x3e8
    3ef8:      	b.ls	0x411c <generic_tracepoint_filter+0x159c>
    3efc:      	mov	x29, xzr
    3f00:      	tbz	w22, #0x1, 0x4124 <generic_tracepoint_filter+0x15a4>
    3f04:      	tbnz	w22, #0x0, 0x4150 <generic_tracepoint_filter+0x15d0>
    3f08:      	ldr	x10, [sp, #0x48]
    3f0c:      	mov	w8, #0x1                // =1
    3f10:      	ldr	w9, [x10]
    3f14:      	cmp	x29, x9
    3f18:      	b.eq	0x3ed4 <generic_tracepoint_filter+0x1354>
    3f1c:      	ldr	w9, [x10, #0x10]
    3f20:      	cmp	x29, x9
    3f24:      	b.eq	0x3ed4 <generic_tracepoint_filter+0x1354>
    3f28:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x480>
    3f2c:      	mov	w8, #0x1                // =1
    3f30:      	ldr	x0, [x0]
    3f34:      	ldr	x1, [sp, #0x18]
    3f38:      	blr	x8
    3f3c:      	cbz	x0, 0x42a8 <generic_tracepoint_filter+0x1728>
    3f40:      	ldr	w9, [x0]
    3f44:      	mov	x1, x0
    3f48:      	mov	w8, #0x1                // =1
    3f4c:      	cmp	x29, x9
    3f50:      	b.eq	0x3ecc <generic_tracepoint_filter+0x134c>
    3f54:      	ldr	w9, [x1, #0x10]!
    3f58:      	ldr	w12, [sp, #0x30]
    3f5c:      	mov	x11, x20
    3f60:      	cmp	x29, x9
    3f64:      	b.eq	0x3ed4 <generic_tracepoint_filter+0x1354>
    3f68:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x480>
    3f6c:      	mov	w8, #0x1                // =1
    3f70:      	ldr	x0, [x0]
    3f74:      	blr	x8
    3f78:      	cbz	x0, 0x42a8 <generic_tracepoint_filter+0x1728>
    3f7c:      	ldr	w9, [x0]
    3f80:      	mov	x1, x0
    3f84:      	mov	w8, #0x1                // =1
    3f88:      	cmp	x29, x9
    3f8c:      	b.eq	0x3ecc <generic_tracepoint_filter+0x134c>
    3f90:      	ldr	w9, [x1, #0x10]!
    3f94:      	ldr	w12, [sp, #0x30]
    3f98:      	mov	x11, x20
    3f9c:      	cmp	x29, x9
    3fa0:      	b.eq	0x3ed4 <generic_tracepoint_filter+0x1354>
    3fa4:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x480>
    3fa8:      	mov	w8, #0x1                // =1
    3fac:      	ldr	x0, [x0]
    3fb0:      	blr	x8
    3fb4:      	cbz	x0, 0x42a8 <generic_tracepoint_filter+0x1728>
    3fb8:      	ldr	w9, [x0]
    3fbc:      	mov	x1, x0
    3fc0:      	mov	w8, #0x1                // =1
    3fc4:      	cmp	x29, x9
    3fc8:      	b.eq	0x3ecc <generic_tracepoint_filter+0x134c>
    3fcc:      	ldr	w9, [x1, #0x10]!
    3fd0:      	ldr	w12, [sp, #0x30]
    3fd4:      	mov	x11, x20
    3fd8:      	cmp	x29, x9
    3fdc:      	b.eq	0x3ed4 <generic_tracepoint_filter+0x1354>
    3fe0:      	adrp	x0, 0x3000 <generic_tracepoint_filter+0x480>
    3fe4:      	mov	w8, #0x1                // =1
    3fe8:      	ldr	x0, [x0]
    3fec:      	blr	x8
    3ff0:      	cbz	x0, 0x42a8 <generic_tracepoint_filter+0x1728>
    3ff4:      	ldr	w9, [x0]
    3ff8:      	mov	x1, x0
    3ffc:      	mov	w8, #0x1                // =1
    4000:      	cmp	x29, x9
    4004:      	b.eq	0x3ecc <generic_tracepoint_filter+0x134c>
    4008:      	ldr	w9, [x1, #0x10]!
    400c:      	ldr	w12, [sp, #0x30]
    4010:      	mov	x11, x20
    4014:      	cmp	x29, x9
    4018:      	b.eq	0x3ed4 <generic_tracepoint_filter+0x1354>
    401c:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x1480>
    4020:      	mov	w8, #0x1                // =1
    4024:      	ldr	x0, [x0]
    4028:      	blr	x8
    402c:      	cbz	x0, 0x42a8 <generic_tracepoint_filter+0x1728>
    4030:      	ldr	w9, [x0]
    4034:      	mov	x1, x0
    4038:      	mov	w8, #0x1                // =1
    403c:      	cmp	x29, x9
    4040:      	b.eq	0x3ecc <generic_tracepoint_filter+0x134c>
    4044:      	ldr	w9, [x1, #0x10]!
    4048:      	ldr	w12, [sp, #0x30]
    404c:      	mov	x11, x20
    4050:      	cmp	x29, x9
    4054:      	b.eq	0x3ed4 <generic_tracepoint_filter+0x1354>
    4058:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x1480>
    405c:      	mov	w8, #0x1                // =1
    4060:      	ldr	x0, [x0]
    4064:      	blr	x8
    4068:      	cbz	x0, 0x42a8 <generic_tracepoint_filter+0x1728>
    406c:      	ldr	w9, [x0]
    4070:      	mov	x1, x0
    4074:      	mov	w8, #0x1                // =1
    4078:      	cmp	x29, x9
    407c:      	b.eq	0x3ecc <generic_tracepoint_filter+0x134c>
    4080:      	ldr	w9, [x1, #0x10]!
    4084:      	ldr	w12, [sp, #0x30]
    4088:      	mov	x11, x20
    408c:      	cmp	x29, x9
    4090:      	b.eq	0x3ed4 <generic_tracepoint_filter+0x1354>
    4094:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x1480>
    4098:      	mov	w8, #0x1                // =1
    409c:      	ldr	x0, [x0]
    40a0:      	blr	x8
    40a4:      	cbz	x0, 0x42a8 <generic_tracepoint_filter+0x1728>
    40a8:      	ldr	w9, [x0]
    40ac:      	mov	x1, x0
    40b0:      	mov	w8, #0x1                // =1
    40b4:      	cmp	x29, x9
    40b8:      	b.eq	0x3ecc <generic_tracepoint_filter+0x134c>
    40bc:      	ldr	w9, [x1, #0x10]!
    40c0:      	ldr	w12, [sp, #0x30]
    40c4:      	mov	x11, x20
    40c8:      	cmp	x29, x9
    40cc:      	b.eq	0x3ed4 <generic_tracepoint_filter+0x1354>
    40d0:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x1480>
    40d4:      	mov	w8, #0x1                // =1
    40d8:      	ldr	x0, [x0]
    40dc:      	blr	x8
    40e0:      	cbz	x0, 0x42a8 <generic_tracepoint_filter+0x1728>
    40e4:      	ldr	w9, [x0]
    40e8:      	mov	x1, x0
    40ec:      	mov	w8, #0x1                // =1
    40f0:      	cmp	x29, x9
    40f4:      	b.eq	0x3ecc <generic_tracepoint_filter+0x134c>
    40f8:      	ldr	w9, [x1, #0x10]!
    40fc:      	ldr	w12, [sp, #0x30]
    4100:      	mov	x11, x20
    4104:      	cmp	x29, x9
    4108:      	b.eq	0x3ed4 <generic_tracepoint_filter+0x1354>
    410c:      	adrp	x9, 0x4000 <generic_tracepoint_filter+0x1480>
    4110:      	mov	w8, #0x1                // =1
    4114:      	ldr	x9, [x9]
    4118:      	b	0x429c <generic_tracepoint_filter+0x171c>
    411c:      	ldr	w29, [x24]
    4120:      	tbnz	w22, #0x1, 0x3f04 <generic_tracepoint_filter+0x1384>
    4124:      	ldr	w8, [x11]
    4128:      	cmp	w12, #0x5
    412c:      	b.ne	0x4140 <generic_tracepoint_filter+0x15c0>
    4130:      	cmp	x29, x8
    4134:      	b.eq	0x4140 <generic_tracepoint_filter+0x15c0>
    4138:      	mov	w9, wzr
    413c:      	b	0x3ee0 <generic_tracepoint_filter+0x1360>
    4140:      	cmp	w12, #0x6
    4144:      	ccmp	x29, x8, #0x0, eq
    4148:      	cset	w9, ne
    414c:      	b	0x3ee0 <generic_tracepoint_filter+0x1360>
    4150:      	ldr	x8, [sp, #0x20]
    4154:      	ldr	w9, [x8]
    4158:      	cbz	w9, 0x3ee0 <generic_tracepoint_filter+0x1360>
    415c:      	mov	w8, #0x1                // =1
    4160:      	cbz	x29, 0x3ed4 <generic_tracepoint_filter+0x1354>
    4164:      	cmp	x29, x9
    4168:      	b.eq	0x3ed4 <generic_tracepoint_filter+0x1354>
    416c:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x1480>
    4170:      	mov	w8, #0x1                // =1
    4174:      	ldr	x0, [x0]
    4178:      	ldr	x1, [sp, #0x18]
    417c:      	blr	x8
    4180:      	cbz	x0, 0x42a8 <generic_tracepoint_filter+0x1728>
    4184:      	ldr	w8, [x0, #0x24]
    4188:      	cmp	x29, x8
    418c:      	b.eq	0x3ec8 <generic_tracepoint_filter+0x1348>
    4190:      	add	x1, x0, #0x10
    4194:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x1480>
    4198:      	mov	w8, #0x1                // =1
    419c:      	ldr	x0, [x0]
    41a0:      	blr	x8
    41a4:      	cbz	x0, 0x42a8 <generic_tracepoint_filter+0x1728>
    41a8:      	ldr	w8, [x0, #0x24]
    41ac:      	cmp	x29, x8
    41b0:      	b.eq	0x3ec8 <generic_tracepoint_filter+0x1348>
    41b4:      	add	x1, x0, #0x10
    41b8:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x1480>
    41bc:      	mov	w8, #0x1                // =1
    41c0:      	ldr	x0, [x0]
    41c4:      	blr	x8
    41c8:      	cbz	x0, 0x42a8 <generic_tracepoint_filter+0x1728>
    41cc:      	ldr	w8, [x0, #0x24]
    41d0:      	cmp	x29, x8
    41d4:      	b.eq	0x3ec8 <generic_tracepoint_filter+0x1348>
    41d8:      	add	x1, x0, #0x10
    41dc:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x1480>
    41e0:      	mov	w8, #0x1                // =1
    41e4:      	ldr	x0, [x0]
    41e8:      	blr	x8
    41ec:      	cbz	x0, 0x42a8 <generic_tracepoint_filter+0x1728>
    41f0:      	ldr	w8, [x0, #0x24]
    41f4:      	cmp	x29, x8
    41f8:      	b.eq	0x3ec8 <generic_tracepoint_filter+0x1348>
    41fc:      	add	x1, x0, #0x10
    4200:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x1480>
    4204:      	mov	w8, #0x1                // =1
    4208:      	ldr	x0, [x0]
    420c:      	blr	x8
    4210:      	cbz	x0, 0x42a8 <generic_tracepoint_filter+0x1728>
    4214:      	ldr	w8, [x0, #0x24]
    4218:      	cmp	x29, x8
    421c:      	b.eq	0x3ec8 <generic_tracepoint_filter+0x1348>
    4220:      	add	x1, x0, #0x10
    4224:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x1480>
    4228:      	mov	w8, #0x1                // =1
    422c:      	ldr	x0, [x0]
    4230:      	blr	x8
    4234:      	cbz	x0, 0x42a8 <generic_tracepoint_filter+0x1728>
    4238:      	ldr	w8, [x0, #0x24]
    423c:      	cmp	x29, x8
    4240:      	b.eq	0x3ec8 <generic_tracepoint_filter+0x1348>
    4244:      	add	x1, x0, #0x10
    4248:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x1480>
    424c:      	mov	w8, #0x1                // =1
    4250:      	ldr	x0, [x0]
    4254:      	blr	x8
    4258:      	cbz	x0, 0x42a8 <generic_tracepoint_filter+0x1728>
    425c:      	ldr	w8, [x0, #0x24]
    4260:      	cmp	x29, x8
    4264:      	b.eq	0x3ec8 <generic_tracepoint_filter+0x1348>
    4268:      	add	x1, x0, #0x10
    426c:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x1480>
    4270:      	mov	w8, #0x1                // =1
    4274:      	ldr	x0, [x0]
    4278:      	blr	x8
    427c:      	cbz	x0, 0x42a8 <generic_tracepoint_filter+0x1728>
    4280:      	ldr	w8, [x0, #0x24]
    4284:      	cmp	x29, x8
    4288:      	b.eq	0x3ec8 <generic_tracepoint_filter+0x1348>
    428c:      	adrp	x9, 0x4000 <generic_tracepoint_filter+0x1480>
    4290:      	add	x1, x0, #0x10
    4294:      	mov	w8, #0x1                // =1
    4298:      	ldr	x9, [x9]
    429c:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x1480>
    42a0:      	ldr	x0, [x0]
    42a4:      	blr	x8
    42a8:      	ldr	w12, [sp, #0x30]
    42ac:      	mov	w8, wzr
    42b0:      	mov	w9, wzr
    42b4:      	mov	x11, x20
    42b8:      	cmp	w12, #0x5
    42bc:      	b.ne	0x3ed4 <generic_tracepoint_filter+0x1354>
    42c0:      	b	0x3ee0 <generic_tracepoint_filter+0x1360>
    42c4:      	ldp	w8, w9, [sp, #0x58]
    42c8:      	ldp	w10, w11, [sp, #0x60]
    42cc:      	cmp	w12, #0x6
    42d0:      	b.ne	0x42e4 <generic_tracepoint_filter+0x1764>
    42d4:      	and	w8, w9, w8
    42d8:      	and	w9, w10, w11
    42dc:      	and	w9, w8, w9
    42e0:      	b	0x42f0 <generic_tracepoint_filter+0x1770>
    42e4:      	orr	w8, w9, w8
    42e8:      	orr	w9, w10, w11
    42ec:      	orr	w9, w8, w9
    42f0:      	ldr	x8, [sp, #0x10]
    42f4:      	cbz	w9, 0x49fc <generic_tracepoint_filter+0x1e7c>
    42f8:      	ldr	x10, [sp, #0x8]
    42fc:      	add	w8, w8, #0x14
    4300:      	ldr	w10, [x10, #0x8]
    4304:      	ubfiz	w10, w10, #2, #3
    4308:      	add	w8, w10, w8
    430c:      	and	x10, x8, #0x3ff
    4310:      	add	w8, w8, #0x4
    4314:      	mov	w19, #0xa               // =10
    4318:      	ldr	w10, [x10, x23]
    431c:      	mov	w20, #0x4               // =4
    4320:      	mov	x25, #0x100000001       // =4294967297
    4324:      	sub	w22, w10, #0x4
    4328:      	ldr	x10, [sp, #0xe8]
    432c:      	add	x10, x10, #0x20
    4330:      	str	x10, [sp, #0x30]
    4334:      	b	0x434c <generic_tracepoint_filter+0x17cc>
    4338:      	orr	w8, w9, w8
    433c:      	orr	w9, w10, w11
    4340:      	orr	w9, w8, w9
    4344:      	cbnz	w9, 0x4500 <generic_tracepoint_filter+0x1980>
    4348:      	b	0x49fc <generic_tracepoint_filter+0x1e7c>
    434c:      	cbz	w22, 0x4514 <generic_tracepoint_filter+0x1994>
    4350:      	and	x9, x8, #0x3ff
    4354:      	add	x10, x9, x23
    4358:      	ldr	w29, [x10, #0x8]
    435c:      	ldp	w9, w24, [x10]
    4360:      	stp	xzr, xzr, [sp, #0x58]
    4364:      	cmp	w29, #0x4
    4368:      	csel	w10, w29, w20, lo
    436c:      	cmp	w24, #0x6
    4370:      	b.ne	0x4378 <generic_tracepoint_filter+0x17f8>
    4374:      	stp	x25, x25, [sp, #0x58]
    4378:      	add	w21, w8, #0xc
    437c:      	cbz	w29, 0x44e0 <generic_tracepoint_filter+0x1960>
    4380:      	and	x9, x9, #0xf
    4384:      	cmp	w9, #0xa
    4388:      	b.lo	0x43b4 <generic_tracepoint_filter+0x1834>
    438c:      	sub	x8, x10, #0x1
    4390:      	mov	w9, #0x3                // =3
    4394:      	add	x0, sp, #0x58
    4398:      	mov	w1, wzr
    439c:      	cmp	x8, #0x3
    43a0:      	csel	x8, x8, x9, lo
    43a4:      	lsl	x8, x8, #2
    43a8:      	add	x2, x8, #0x4
    43ac:      	bl	0x43ac <generic_tracepoint_filter+0x182c>
    43b0:      	b	0x44e0 <generic_tracepoint_filter+0x1960>
    43b4:      	cmp	w21, #0x3e8
    43b8:      	b.ls	0x43c4 <generic_tracepoint_filter+0x1844>
    43bc:      	mov	w11, wzr
    43c0:      	b	0x43cc <generic_tracepoint_filter+0x184c>
    43c4:      	and	w11, w21, #0xfffffffc
    43c8:      	ldr	w11, [x23, w11, uxtw]
    43cc:      	ldr	x12, [sp, #0x30]
    43d0:      	cmp	w24, #0x5
    43d4:      	sub	x10, x10, #0x1
    43d8:      	ldr	w9, [x12, x9, lsl #2]
    43dc:      	cset	w12, ne
    43e0:      	cmp	w24, #0x6
    43e4:      	cset	w13, ne
    43e8:      	cmp	w11, w9
    43ec:      	csinc	w11, w12, wzr, ne
    43f0:      	csinc	w12, w13, wzr, eq
    43f4:      	and	w11, w11, w12
    43f8:      	str	w11, [sp, #0x58]
    43fc:      	cbz	x10, 0x44e0 <generic_tracepoint_filter+0x1960>
    4400:      	add	w11, w8, #0x10
    4404:      	cmp	w11, #0x3e8
    4408:      	b.ls	0x4414 <generic_tracepoint_filter+0x1894>
    440c:      	mov	w11, wzr
    4410:      	b	0x441c <generic_tracepoint_filter+0x189c>
    4414:      	and	w11, w11, #0xfffffffc
    4418:      	ldr	w11, [x23, w11, uxtw]
    441c:      	cmp	w24, #0x5
    4420:      	cset	w12, ne
    4424:      	cmp	w24, #0x6
    4428:      	cset	w13, ne
    442c:      	cmp	w11, w9
    4430:      	csinc	w11, w12, wzr, ne
    4434:      	csinc	w12, w13, wzr, eq
    4438:      	cmp	x10, #0x1
    443c:      	and	w11, w11, w12
    4440:      	str	w11, [sp, #0x5c]
    4444:      	b.eq	0x44e0 <generic_tracepoint_filter+0x1960>
    4448:      	add	w11, w8, #0x14
    444c:      	cmp	w11, #0x3e8
    4450:      	b.ls	0x445c <generic_tracepoint_filter+0x18dc>
    4454:      	mov	w11, wzr
    4458:      	b	0x4464 <generic_tracepoint_filter+0x18e4>
    445c:      	and	w11, w11, #0xfffffffc
    4460:      	ldr	w11, [x23, w11, uxtw]
    4464:      	cmp	w24, #0x5
    4468:      	cset	w12, ne
    446c:      	cmp	w24, #0x6
    4470:      	cset	w13, ne
    4474:      	cmp	w11, w9
    4478:      	csinc	w11, w12, wzr, ne
    447c:      	csinc	w12, w13, wzr, eq
    4480:      	cmp	x10, #0x2
    4484:      	and	w11, w11, w12
    4488:      	str	w11, [sp, #0x60]
    448c:      	b.eq	0x44e0 <generic_tracepoint_filter+0x1960>
    4490:      	add	w8, w8, #0x18
    4494:      	cmp	w8, #0x3e8
    4498:      	b.ls	0x44a4 <generic_tracepoint_filter+0x1924>
    449c:      	mov	w8, wzr
    44a0:      	b	0x44ac <generic_tracepoint_filter+0x192c>
    44a4:      	and	w8, w8, #0xfffffffc
    44a8:      	ldr	w8, [x23, w8, uxtw]
    44ac:      	cmp	w24, #0x5
    44b0:      	cset	w10, ne
    44b4:      	cmp	w24, #0x6
    44b8:      	cset	w11, ne
    44bc:      	cmp	w8, w9
    44c0:      	csinc	w8, w10, wzr, ne
    44c4:      	csinc	w9, w11, wzr, eq
    44c8:      	and	w8, w8, w9
    44cc:      	str	w8, [sp, #0x64]
    44d0:      	nop
    44d4:      	nop
    44d8:      	nop
    44dc:      	nop
    44e0:      	ldp	w8, w9, [sp, #0x58]
    44e4:      	ldp	w10, w11, [sp, #0x60]
    44e8:      	cmp	w24, #0x6
    44ec:      	b.ne	0x4338 <generic_tracepoint_filter+0x17b8>
    44f0:      	and	w8, w9, w8
    44f4:      	and	w9, w10, w11
    44f8:      	and	w9, w8, w9
    44fc:      	cbz	w9, 0x49fc <generic_tracepoint_filter+0x1e7c>
    4500:      	lsl	w8, w29, #2
    4504:      	sub	w10, w22, w29, lsl #2
    4508:      	and	w8, w8, #0x1c
    450c:      	sub	w22, w10, #0xc
    4510:      	add	w8, w8, w21
    4514:      	subs	x19, x19, #0x1
    4518:      	b.ne	0x434c <generic_tracepoint_filter+0x17cc>
    451c:      	mov	w10, w8
    4520:      	add	w19, w8, #0x4
    4524:      	and	x10, x10, #0x3ff
    4528:      	ldr	w10, [x10, x23]
    452c:      	cmp	w10, #0x4
    4530:      	b.ne	0x45c8 <generic_tracepoint_filter+0x1a48>
    4534:      	cbz	w9, 0x49fc <generic_tracepoint_filter+0x1e7c>
    4538:      	mov	w8, w19
    453c:      	and	x8, x8, #0x3ff
    4540:      	ldr	w9, [x8, x23]
    4544:      	add	w8, w19, #0x4
    4548:      	cmp	w9, #0x4
    454c:      	mov	w9, w8
    4550:      	b.eq	0x48f8 <generic_tracepoint_filter+0x1d78>
    4554:      	and	x8, x8, #0x3ff
    4558:      	add	x8, x8, x23
    455c:      	ldp	w20, w22, [x8]
    4560:      	mov	w8, #0xe                // =14
    4564:      	blr	x8
    4568:      	lsr	x8, x0, #32
    456c:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x1480>
    4570:      	add	x9, sp, #0x58
    4574:      	str	w8, [sp, #0x58]
    4578:      	mov	w8, #0x1                // =1
    457c:      	add	x1, sp, #0x58
    4580:      	ldr	x0, [x0]
    4584:      	blr	x8
    4588:      	cbz	x0, 0x49fc <generic_tracepoint_filter+0x1e7c>
    458c:      	cmp	w20, #0x5
    4590:      	b.eq	0x4644 <generic_tracepoint_filter+0x1ac4>
    4594:      	cmp	w20, #0x6
    4598:      	b.ne	0x49fc <generic_tracepoint_filter+0x1e7c>
    459c:      	ldr	x11, [sp, #0xe8]
    45a0:      	mov	w8, #0x5ee8             // =24296
    45a4:      	add	x8, x11, x8
    45a8:      	tbnz	w22, #0x0, 0x4678 <generic_tracepoint_filter+0x1af8>
    45ac:      	ldr	w9, [x0, #0x28]
    45b0:      	cbz	w9, 0x4670 <generic_tracepoint_filter+0x1af0>
    45b4:      	ldr	x10, [sp, #0x30]
    45b8:      	ldr	w10, [x10]
    45bc:      	cmp	w9, w10
    45c0:      	b.eq	0x4678 <generic_tracepoint_filter+0x1af8>
    45c4:      	b	0x48ec <generic_tracepoint_filter+0x1d6c>
    45c8:      	and	x9, x19, #0x3ff
    45cc:      	add	w19, w8, #0x18
    45d0:      	add	x9, x9, x23
    45d4:      	ldp	w8, w10, [x9]
    45d8:      	ldr	w12, [x9, #0x8]
    45dc:      	ldur	x11, [x9, #0xc]
    45e0:      	cbz	w12, 0x4604 <generic_tracepoint_filter+0x1a84>
    45e4:      	ldr	x14, [sp, #0xe8]
    45e8:      	mov	w9, wzr
    45ec:      	cmp	w8, #0x2
    45f0:      	b.hi	0x4534 <generic_tracepoint_filter+0x19b4>
    45f4:      	ldr	w13, [x14, #0x44]
    45f8:      	cmp	w13, w12
    45fc:      	b.ne	0x4618 <generic_tracepoint_filter+0x1a98>
    4600:      	b	0x4534 <generic_tracepoint_filter+0x19b4>
    4604:      	ldr	x14, [sp, #0xe8]
    4608:      	cmp	w8, #0x2
    460c:      	b.ls	0x4618 <generic_tracepoint_filter+0x1a98>
    4610:      	mov	w9, wzr
    4614:      	b	0x4534 <generic_tracepoint_filter+0x19b4>
    4618:      	add	x9, x14, #0x48
    461c:      	cmp	w10, #0x5
    4620:      	ldr	x8, [x9, x8, lsl #3]
    4624:      	and	x8, x8, x11
    4628:      	b.ne	0x4638 <generic_tracepoint_filter+0x1ab8>
    462c:      	cmp	x8, #0x0
    4630:      	cset	w9, ne
    4634:      	b	0x4534 <generic_tracepoint_filter+0x19b4>
    4638:      	cmp	x8, #0x0
    463c:      	cset	w9, eq
    4640:      	b	0x4534 <generic_tracepoint_filter+0x19b4>
    4644:      	ldr	x11, [sp, #0xe8]
    4648:      	mov	w8, #0x5ee8             // =24296
    464c:      	add	x8, x11, x8
    4650:      	tbz	w22, #0x0, 0x469c <generic_tracepoint_filter+0x1b1c>
    4654:      	ldr	w9, [x0, #0x28]
    4658:      	cbz	w9, 0x4694 <generic_tracepoint_filter+0x1b14>
    465c:      	ldr	x10, [sp, #0x30]
    4660:      	ldr	w10, [x10]
    4664:      	cmp	w9, w10
    4668:      	b.eq	0x469c <generic_tracepoint_filter+0x1b1c>
    466c:      	b	0x48ec <generic_tracepoint_filter+0x1d6c>
    4670:      	mov	w9, #0x1                // =1
    4674:      	str	x9, [x8]
    4678:      	tbnz	w22, #0x1, 0x46c0 <generic_tracepoint_filter+0x1b40>
    467c:      	ldr	w9, [x0, #0x2c]
    4680:      	cbz	w9, 0x46b8 <generic_tracepoint_filter+0x1b38>
    4684:      	ldr	w10, [x11, #0x24]
    4688:      	cmp	w9, w10
    468c:      	b.eq	0x46c0 <generic_tracepoint_filter+0x1b40>
    4690:      	b	0x48ec <generic_tracepoint_filter+0x1d6c>
    4694:      	mov	w9, #0x1                // =1
    4698:      	str	x9, [x8]
    469c:      	tbz	w22, #0x1, 0x46e4 <generic_tracepoint_filter+0x1b64>
    46a0:      	ldr	w9, [x0, #0x2c]
    46a4:      	cbz	w9, 0x46dc <generic_tracepoint_filter+0x1b5c>
    46a8:      	ldr	w10, [x11, #0x24]
    46ac:      	cmp	w9, w10
    46b0:      	b.eq	0x46e4 <generic_tracepoint_filter+0x1b64>
    46b4:      	b	0x48ec <generic_tracepoint_filter+0x1d6c>
    46b8:      	mov	w9, #0x1                // =1
    46bc:      	str	x9, [x8]
    46c0:      	tbnz	w22, #0x2, 0x4708 <generic_tracepoint_filter+0x1b88>
    46c4:      	ldr	w9, [x0, #0x30]
    46c8:      	cbz	w9, 0x4700 <generic_tracepoint_filter+0x1b80>
    46cc:      	ldr	w10, [x11, #0x28]
    46d0:      	cmp	w9, w10
    46d4:      	b.eq	0x4708 <generic_tracepoint_filter+0x1b88>
    46d8:      	b	0x48ec <generic_tracepoint_filter+0x1d6c>
    46dc:      	mov	w9, #0x1                // =1
    46e0:      	str	x9, [x8]
    46e4:      	tbz	w22, #0x2, 0x472c <generic_tracepoint_filter+0x1bac>
    46e8:      	ldr	w9, [x0, #0x30]
    46ec:      	cbz	w9, 0x4724 <generic_tracepoint_filter+0x1ba4>
    46f0:      	ldr	w10, [x11, #0x28]
    46f4:      	cmp	w9, w10
    46f8:      	b.eq	0x472c <generic_tracepoint_filter+0x1bac>
    46fc:      	b	0x48ec <generic_tracepoint_filter+0x1d6c>
    4700:      	mov	w9, #0x1                // =1
    4704:      	str	x9, [x8]
    4708:      	tbnz	w22, #0x3, 0x4750 <generic_tracepoint_filter+0x1bd0>
    470c:      	ldr	w9, [x0, #0x34]
    4710:      	cbz	w9, 0x4748 <generic_tracepoint_filter+0x1bc8>
    4714:      	ldr	w10, [x11, #0x2c]
    4718:      	cmp	w9, w10
    471c:      	b.eq	0x4750 <generic_tracepoint_filter+0x1bd0>
    4720:      	b	0x48ec <generic_tracepoint_filter+0x1d6c>
    4724:      	mov	w9, #0x1                // =1
    4728:      	str	x9, [x8]
    472c:      	tbz	w22, #0x3, 0x4774 <generic_tracepoint_filter+0x1bf4>
    4730:      	ldr	w9, [x0, #0x34]
    4734:      	cbz	w9, 0x476c <generic_tracepoint_filter+0x1bec>
    4738:      	ldr	w10, [x11, #0x2c]
    473c:      	cmp	w9, w10
    4740:      	b.eq	0x4774 <generic_tracepoint_filter+0x1bf4>
    4744:      	b	0x48ec <generic_tracepoint_filter+0x1d6c>
    4748:      	mov	w9, #0x1                // =1
    474c:      	str	x9, [x8]
    4750:      	tbnz	w22, #0x4, 0x4798 <generic_tracepoint_filter+0x1c18>
    4754:      	ldr	w9, [x0, #0x38]
    4758:      	cbz	w9, 0x4790 <generic_tracepoint_filter+0x1c10>
    475c:      	ldr	w10, [x11, #0x30]
    4760:      	cmp	w9, w10
    4764:      	b.eq	0x4798 <generic_tracepoint_filter+0x1c18>
    4768:      	b	0x48ec <generic_tracepoint_filter+0x1d6c>
    476c:      	mov	w9, #0x1                // =1
    4770:      	str	x9, [x8]
    4774:      	tbz	w22, #0x4, 0x47bc <generic_tracepoint_filter+0x1c3c>
    4778:      	ldr	w9, [x0, #0x38]
    477c:      	cbz	w9, 0x47b4 <generic_tracepoint_filter+0x1c34>
    4780:      	ldr	w10, [x11, #0x30]
    4784:      	cmp	w9, w10
    4788:      	b.eq	0x47bc <generic_tracepoint_filter+0x1c3c>
    478c:      	b	0x48ec <generic_tracepoint_filter+0x1d6c>
    4790:      	mov	w9, #0x1                // =1
    4794:      	str	x9, [x8]
    4798:      	tbnz	w22, #0x5, 0x47e0 <generic_tracepoint_filter+0x1c60>
    479c:      	ldr	w9, [x0, #0x3c]
    47a0:      	cbz	w9, 0x47d8 <generic_tracepoint_filter+0x1c58>
    47a4:      	ldr	w10, [x11, #0x34]
    47a8:      	cmp	w9, w10
    47ac:      	b.eq	0x47e0 <generic_tracepoint_filter+0x1c60>
    47b0:      	b	0x48ec <generic_tracepoint_filter+0x1d6c>
    47b4:      	mov	w9, #0x1                // =1
    47b8:      	str	x9, [x8]
    47bc:      	tbz	w22, #0x5, 0x4804 <generic_tracepoint_filter+0x1c84>
    47c0:      	ldr	w9, [x0, #0x3c]
    47c4:      	cbz	w9, 0x47fc <generic_tracepoint_filter+0x1c7c>
    47c8:      	ldr	w10, [x11, #0x34]
    47cc:      	cmp	w9, w10
    47d0:      	b.eq	0x4804 <generic_tracepoint_filter+0x1c84>
    47d4:      	b	0x48ec <generic_tracepoint_filter+0x1d6c>
    47d8:      	mov	w9, #0x1                // =1
    47dc:      	str	x9, [x8]
    47e0:      	tbnz	w22, #0x6, 0x4828 <generic_tracepoint_filter+0x1ca8>
    47e4:      	ldr	w9, [x0, #0x40]
    47e8:      	cbz	w9, 0x4820 <generic_tracepoint_filter+0x1ca0>
    47ec:      	ldr	w10, [x11, #0x38]
    47f0:      	cmp	w9, w10
    47f4:      	b.eq	0x4828 <generic_tracepoint_filter+0x1ca8>
    47f8:      	b	0x48ec <generic_tracepoint_filter+0x1d6c>
    47fc:      	mov	w9, #0x1                // =1
    4800:      	str	x9, [x8]
    4804:      	tbz	w22, #0x6, 0x484c <generic_tracepoint_filter+0x1ccc>
    4808:      	ldr	w9, [x0, #0x40]
    480c:      	cbz	w9, 0x4844 <generic_tracepoint_filter+0x1cc4>
    4810:      	ldr	w10, [x11, #0x38]
    4814:      	cmp	w9, w10
    4818:      	b.eq	0x484c <generic_tracepoint_filter+0x1ccc>
    481c:      	b	0x48ec <generic_tracepoint_filter+0x1d6c>
    4820:      	mov	w9, #0x1                // =1
    4824:      	str	x9, [x8]
    4828:      	tbnz	w22, #0x7, 0x4870 <generic_tracepoint_filter+0x1cf0>
    482c:      	ldr	w9, [x0, #0x44]
    4830:      	cbz	w9, 0x4868 <generic_tracepoint_filter+0x1ce8>
    4834:      	ldr	w10, [x11, #0x3c]
    4838:      	cmp	w9, w10
    483c:      	b.eq	0x4870 <generic_tracepoint_filter+0x1cf0>
    4840:      	b	0x48ec <generic_tracepoint_filter+0x1d6c>
    4844:      	mov	w9, #0x1                // =1
    4848:      	str	x9, [x8]
    484c:      	tbz	w22, #0x7, 0x4898 <generic_tracepoint_filter+0x1d18>
    4850:      	ldr	w9, [x0, #0x44]
    4854:      	cbz	w9, 0x4890 <generic_tracepoint_filter+0x1d10>
    4858:      	ldr	w10, [x11, #0x3c]
    485c:      	cmp	w9, w10
    4860:      	b.eq	0x4898 <generic_tracepoint_filter+0x1d18>
    4864:      	b	0x48ec <generic_tracepoint_filter+0x1d6c>
    4868:      	mov	w9, #0x1                // =1
    486c:      	str	x9, [x8]
    4870:      	tbnz	w22, #0x8, 0x48c0 <generic_tracepoint_filter+0x1d40>
    4874:      	ldr	w9, [x0, #0x48]
    4878:      	cbz	w9, 0x48b8 <generic_tracepoint_filter+0x1d38>
    487c:      	ldr	x10, [sp, #0xe8]
    4880:      	ldr	w10, [x10, #0x40]
    4884:      	cmp	w9, w10
    4888:      	b.eq	0x48c0 <generic_tracepoint_filter+0x1d40>
    488c:      	b	0x48ec <generic_tracepoint_filter+0x1d6c>
    4890:      	mov	w9, #0x1                // =1
    4894:      	str	x9, [x8]
    4898:      	tbz	w22, #0x8, 0x48d0 <generic_tracepoint_filter+0x1d50>
    489c:      	ldr	w9, [x0, #0x48]
    48a0:      	cbz	w9, 0x48c8 <generic_tracepoint_filter+0x1d48>
    48a4:      	ldr	x10, [sp, #0xe8]
    48a8:      	ldr	w10, [x10, #0x40]
    48ac:      	cmp	w9, w10
    48b0:      	b.eq	0x48d0 <generic_tracepoint_filter+0x1d50>
    48b4:      	b	0x48ec <generic_tracepoint_filter+0x1d6c>
    48b8:      	mov	w9, #0x1                // =1
    48bc:      	str	x9, [x8]
    48c0:      	tbz	w22, #0x9, 0x48d4 <generic_tracepoint_filter+0x1d54>
    48c4:      	b	0x49fc <generic_tracepoint_filter+0x1e7c>
    48c8:      	mov	w9, #0x1                // =1
    48cc:      	str	x9, [x8]
    48d0:      	tbz	w22, #0x9, 0x49fc <generic_tracepoint_filter+0x1e7c>
    48d4:      	ldr	w9, [x0, #0x4c]
    48d8:      	cbz	w9, 0x49f4 <generic_tracepoint_filter+0x1e74>
    48dc:      	ldr	x10, [sp, #0xe8]
    48e0:      	ldr	w10, [x10, #0x44]
    48e4:      	cmp	w9, w10
    48e8:      	b.eq	0x49fc <generic_tracepoint_filter+0x1e7c>
    48ec:      	add	w9, w19, #0xc
    48f0:      	mov	w10, #0x1               // =1
    48f4:      	str	x10, [x8]
    48f8:      	and	x8, x9, #0x3ff
    48fc:      	adrp	x24, 0x4000 <generic_tracepoint_filter+0x1480>
    4900:      	ldr	w8, [x8, x23]
    4904:      	ldr	x24, [x24]
    4908:      	cmp	w8, #0x4
    490c:      	b.ne	0x4940 <generic_tracepoint_filter+0x1dc0>
    4910:      	ldr	x9, [sp, #0xe8]
    4914:      	mov	w8, #0x5eb8             // =24248
    4918:      	add	x8, x9, x8
    491c:      	ldr	x9, [x9, #0x5eb8]
    4920:      	and	x9, x9, #0x1f
    4924:      	add	x8, x8, x9
    4928:      	mov	w9, #0x1                // =1
    492c:      	strb	w9, [x8, #0x9]
    4930:      	ldr	x8, [sp, #0x40]
    4934:      	strb	w9, [x8, #0x20]
    4938:      	strb	w9, [x8]
    493c:      	b	0x49fc <generic_tracepoint_filter+0x1e7c>
    4940:      	add	w8, w9, #0x4
    4944:      	and	x8, x8, #0x3ff
    4948:      	add	x8, x8, x23
    494c:      	ldp	w21, w19, [x8]
    4950:      	ldr	w22, [x8, #0x8]
    4954:      	ldur	x20, [x8, #0xc]
    4958:      	mov	w8, #0xe                // =14
    495c:      	blr	x8
    4960:      	lsr	x8, x0, #32
    4964:      	add	x9, sp, #0x58
    4968:      	add	x1, sp, #0x58
    496c:      	str	w8, [sp, #0x58]
    4970:      	mov	w8, #0x1                // =1
    4974:      	mov	x0, x24
    4978:      	blr	x8
    497c:      	cbz	x0, 0x49fc <generic_tracepoint_filter+0x1e7c>
    4980:      	cmp	w21, #0x2
    4984:      	cbz	w22, 0x49a0 <generic_tracepoint_filter+0x1e20>
    4988:      	b.hi	0x49fc <generic_tracepoint_filter+0x1e7c>
    498c:      	ldr	x8, [sp, #0xe8]
    4990:      	ldr	w8, [x8, #0x44]
    4994:      	cmp	w8, w22
    4998:      	b.ne	0x49a4 <generic_tracepoint_filter+0x1e24>
    499c:      	b	0x49fc <generic_tracepoint_filter+0x1e7c>
    49a0:      	b.hi	0x49fc <generic_tracepoint_filter+0x1e7c>
    49a4:      	ldr	x8, [sp, #0xe8]
    49a8:      	lsl	x10, x21, #3
    49ac:      	add	x9, x8, #0x48
    49b0:      	add	x8, x0, x21, lsl #3
    49b4:      	ldr	x8, [x8, #0x50]
    49b8:      	ldr	x9, [x9, x10]
    49bc:      	eor	x10, x9, x8
    49c0:      	tst	x10, x20
    49c4:      	b.eq	0x49d4 <generic_tracepoint_filter+0x1e54>
    49c8:      	cmp	w19, #0x5
    49cc:      	b.eq	0x49e4 <generic_tracepoint_filter+0x1e64>
    49d0:      	b	0x49fc <generic_tracepoint_filter+0x1e7c>
    49d4:      	cmp	x8, x9
    49d8:      	b.eq	0x49fc <generic_tracepoint_filter+0x1e7c>
    49dc:      	cmp	w19, #0x6
    49e0:      	b.ne	0x49fc <generic_tracepoint_filter+0x1e7c>
    49e4:      	ldr	x9, [sp, #0xe8]
    49e8:      	mov	w8, #0x1                // =1
    49ec:      	str	x8, [x9, #0x5ef0]
    49f0:      	b	0x4910 <generic_tracepoint_filter+0x1d90>
    49f4:      	mov	w9, #0x1                // =1
    49f8:      	str	x9, [x8]
    49fc:      	ldr	x9, [sp, #0xe8]
    4a00:      	ldr	x10, [sp, #0x28]
    4a04:      	ldr	x8, [x9, #0x5eb8]
    4a08:      	add	x8, x8, #0x1
    4a0c:      	cmp	x8, x10
    4a10:      	str	x8, [x9, #0x5eb8]
    4a14:      	b.ls	0x4a74 <generic_tracepoint_filter+0x1ef4>
    4a18:      	ldr	x10, [sp, #0x48]
    4a1c:      	ldr	w8, [x10]
    4a20:      	str	w8, [x9, #0x10]
    4a24:      	ldr	x8, [x10, #0x8]
    4a28:      	str	x8, [x9, #0x18]
    4a2c:      	ldp	x22, x8, [sp, #0x38]
    4a30:      	ldrb	w8, [x8]
    4a34:      	cbz	w8, 0x4a54 <generic_tracepoint_filter+0x1ed4>
    4a38:      	adrp	x1, 0x4000 <generic_tracepoint_filter+0x1480>
    4a3c:      	mov	w8, #0x1                // =1
    4a40:      	mov	w9, #0xc                // =12
    4a44:      	ldr	x1, [x1]
    4a48:      	mov	x0, x22
    4a4c:      	mov	w2, #0x1                // =1
    4a50:      	blr	x9
    4a54:      	ldp	x20, x19, [sp, #0x120]
    4a58:      	mov	w0, wzr
    4a5c:      	ldr	x29, [sp, #0xe0]
    4a60:      	ldp	x22, x21, [sp, #0x110]
    4a64:      	ldp	x24, x23, [sp, #0x100]
    4a68:      	ldp	x30, x25, [sp, #0xf0]
    4a6c:      	add	sp, sp, #0x130
    4a70:      	ret
    4a74:      	adrp	x1, 0x4000 <generic_tracepoint_filter+0x1480>
    4a78:      	mov	w8, #0x2                // =2
    4a7c:      	mov	w9, #0xc                // =12
    4a80:      	ldr	x1, [x1]
    4a84:      	ldr	x0, [sp, #0x38]
    4a88:      	mov	w2, #0x2                // =2
    4a8c:      	b	0x4a50 <generic_tracepoint_filter+0x1ed0>

0000000000004a90 <generic_tracepoint_arg>:
    4a90:      	sub	sp, sp, #0xf0
    4a94:      	str	x29, [sp, #0xa0]
    4a98:      	stp	x30, x25, [sp, #0xb0]
    4a9c:      	stp	x24, x23, [sp, #0xc0]
    4aa0:      	stp	x22, x21, [sp, #0xd0]
    4aa4:      	stp	x20, x19, [sp, #0xe0]
    4aa8:      	mov	x19, x0
    4aac:      	str	wzr, [sp, #0xa8]
    4ab0:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x1480>
    4ab4:      	mov	w8, #0x1                // =1
    4ab8:      	ldr	x0, [x0]
    4abc:      	add	x9, sp, #0xa8
    4ac0:      	add	x1, sp, #0xa8
    4ac4:      	blr	x8
    4ac8:      	cbz	x0, 0x4c38 <generic_tracepoint_arg+0x1a8>
    4acc:      	mov	w8, #0x5ec1             // =24257
    4ad0:      	mov	x20, x0
    4ad4:      	add	x22, x0, x8
    4ad8:      	mov	w8, #0x5ef8             // =24312
    4adc:      	add	x1, x0, x8
    4ae0:      	adrp	x0, 0x4000 <generic_tracepoint_filter+0x1480>
    4ae4:      	ldur	w23, [x22, #0x3f]
    4ae8:      	mov	w8, #0x1                // =1
    4aec:      	ldr	x0, [x0]
    4af0:      	blr	x8
    4af4:      	cbz	x0, 0x4c1c <generic_tracepoint_arg+0x18c>
    4af8:      	ldrb	w8, [x22, #0x1f]
    4afc:      	cbz	w8, 0x4c1c <generic_tracepoint_arg+0x18c>
    4b00:      	and	x8, x23, #0x7
    4b04:      	mov	w10, #0x5ec1            // =24257
    4b08:      	stp	x23, x22, [sp, #0x50]
    4b0c:      	add	x9, x20, x8
    4b10:      	ldrb	w9, [x9, x10]
    4b14:      	cbz	w9, 0x4b8c <generic_tracepoint_arg+0xfc>
    4b18:      	lsl	w8, w8, #2
    4b1c:      	mov	x21, x0
    4b20:      	add	x8, x8, #0x4
    4b24:      	ldr	w9, [x8, x0]
    4b28:      	add	x8, x8, x9
    4b2c:      	add	x8, x8, #0x4
    4b30:      	and	x9, x8, #0x3ff
    4b34:      	ldr	w9, [x9, x0]
    4b38:      	add	x8, x8, x9
    4b3c:      	and	x9, x8, #0x3ff
    4b40:      	ldr	w9, [x9, x0]
    4b44:      	add	x8, x8, x9
    4b48:      	and	x9, x8, #0x3ff
    4b4c:      	ldr	w9, [x9, x0]
    4b50:      	add	x8, x8, x9
    4b54:      	and	x9, x8, #0x3ff
    4b58:      	ldr	w9, [x9, x0]
    4b5c:      	add	x8, x8, x9
    4b60:      	and	x9, x8, #0x3ff
    4b64:      	ldr	w9, [x9, x0]
    4b68:      	add	x16, x8, x9
    4b6c:      	and	x15, x16, #0x3ff
    4b70:      	add	x17, x0, x15
    4b74:      	ldr	w8, [x17]
    4b78:      	cmp	w8, #0x19
    4b7c:      	b.hs	0x4be0 <generic_tracepoint_arg+0x150>
    4b80:      	cmp	w15, #0x1
    4b84:      	b.eq	0x4c1c <generic_tracepoint_arg+0x18c>
    4b88:      	cbnz	w15, 0x4bf8 <generic_tracepoint_arg+0x168>
    4b8c:      	ldr	x8, [sp, #0x50]
    4b90:      	cmp	w8, #0x1
    4b94:      	b.gt	0x4bb4 <generic_tracepoint_arg+0x124>
    4b98:      	ldr	x9, [sp, #0x58]
    4b9c:      	cmn	w8, #0x1
    4ba0:      	b.eq	0x4c58 <generic_tracepoint_arg+0x1c8>
    4ba4:      	cbz	w8, 0x4c68 <generic_tracepoint_arg+0x1d8>
    4ba8:      	cmp	w8, #0x1
    4bac:      	b.eq	0x4c78 <generic_tracepoint_arg+0x1e8>
    4bb0:      	b	0x4bd0 <generic_tracepoint_arg+0x140>
    4bb4:      	ldr	x9, [sp, #0x58]
    4bb8:      	cmp	w8, #0x2
    4bbc:      	b.eq	0x4c88 <generic_tracepoint_arg+0x1f8>
    4bc0:      	cmp	w8, #0x3
    4bc4:      	b.eq	0x4c98 <generic_tracepoint_arg+0x208>
    4bc8:      	cmp	w8, #0x4
    4bcc:      	b.eq	0x4ca8 <generic_tracepoint_arg+0x218>
    4bd0:      	cmp	w8, #0x4
    4bd4:      	b.gt	0x4cd4 <generic_tracepoint_arg+0x244>
    4bd8:      	add	w8, w8, #0x1
    4bdc:      	b	0x4cb4 <generic_tracepoint_arg+0x224>
    4be0:      	mov	x25, xzr
    4be4:      	mov	w2, #0x5ea0             // =24224
    4be8:      	mov	w12, #0x1               // =1
    4bec:      	stp	x19, x17, [sp, #0x30]
    4bf0:      	stp	x16, x15, [sp, #0x40]
    4bf4:      	b	0x4d34 <generic_tracepoint_arg+0x2a4>
    4bf8:      	ldr	x8, [sp, #0x58]
    4bfc:      	adrp	x1, 0x4000 <generic_tracepoint_filter+0x1480>
    4c00:      	mov	w9, #0xc                // =12
    4c04:      	mov	x0, x19
    4c08:      	stur	w15, [x8, #0x43]
    4c0c:      	mov	w8, #0x4                // =4
    4c10:      	mov	w2, #0x4                // =4
    4c14:      	ldr	x1, [x1]
    4c18:      	blr	x9
    4c1c:      	adrp	x1, 0x4000 <generic_tracepoint_filter+0x1480>
    4c20:      	mov	w8, #0x5                // =5
    4c24:      	mov	w9, #0xc                // =12
    4c28:      	ldr	x1, [x1]
    4c2c:      	mov	x0, x19
    4c30:      	mov	w2, #0x5                // =5
    4c34:      	blr	x9
    4c38:      	ldp	x20, x19, [sp, #0xe0]
    4c3c:      	mov	w0, wzr
    4c40:      	ldr	x29, [sp, #0xa0]
    4c44:      	ldp	x22, x21, [sp, #0xd0]
    4c48:      	ldp	x24, x23, [sp, #0xc0]
    4c4c:      	ldp	x30, x25, [sp, #0xb0]
    4c50:      	add	sp, sp, #0xf0
    4c54:      	ret
    4c58:      	ldrb	w8, [x9]
    4c5c:      	cbz	w8, 0x4c68 <generic_tracepoint_arg+0x1d8>
    4c60:      	mov	w8, wzr
    4c64:      	b	0x4cb4 <generic_tracepoint_arg+0x224>
    4c68:      	ldrb	w8, [x9, #0x1]
    4c6c:      	cbz	w8, 0x4c78 <generic_tracepoint_arg+0x1e8>
    4c70:      	mov	w8, #0x1                // =1
    4c74:      	b	0x4cb4 <generic_tracepoint_arg+0x224>
    4c78:      	ldrb	w8, [x9, #0x2]
    4c7c:      	cbz	w8, 0x4c88 <generic_tracepoint_arg+0x1f8>
    4c80:      	mov	w8, #0x2                // =2
    4c84:      	b	0x4cb4 <generic_tracepoint_arg+0x224>
    4c88:      	ldrb	w8, [x9, #0x3]
    4c8c:      	cbz	w8, 0x4c98 <generic_tracepoint_arg+0x208>
    4c90:      	mov	w8, #0x3                // =3
    4c94:      	b	0x4cb4 <generic_tracepoint_arg+0x224>
    4c98:      	ldrb	w8, [x9, #0x4]
    4c9c:      	cbz	w8, 0x4ca8 <generic_tracepoint_arg+0x218>
    4ca0:      	mov	w8, #0x4                // =4
    4ca4:      	b	0x4cb4 <generic_tracepoint_arg+0x224>
    4ca8:      	ldrb	w8, [x9, #0x5]
    4cac:      	cbz	w8, 0x4cd4 <generic_tracepoint_arg+0x244>
    4cb0:      	mov	w8, #0x5                // =5
    4cb4:      	stur	w8, [x9, #0x3f]
    4cb8:      	adrp	x1, 0x4000 <generic_tracepoint_filter+0x1480>
    4cbc:      	mov	w8, #0x3                // =3
    4cc0:      	mov	w9, #0xc                // =12
    4cc4:      	ldr	x1, [x1]
    4cc8:      	mov	x0, x19
    4ccc:      	mov	w2, #0x3                // =3
    4cd0:      	blr	x9
    4cd4:      	ldr	x19, [x20, #0x60]
    4cd8:      	mov	w8, #0xe                // =14
    4cdc:      	blr	x8
    4ce0:      	stp	x19, x0, [sp, #0x60]
    4ce4:      	adrp	x19, 0x4000 <generic_tracepoint_filter+0x1480>
    4ce8:      	mov	w8, #0x1                // =1
    4cec:      	add	x9, sp, #0x60
    4cf0:      	add	x1, sp, #0x60
    4cf4:      	ldr	x19, [x19]
    4cf8:      	mov	x0, x19
    4cfc:      	blr	x8
    4d00:      	cbz	x0, 0x4c38 <generic_tracepoint_arg+0x1a8>
    4d04:      	mov	w8, #0x3                // =3
    4d08:      	add	x9, sp, #0x60
    4d0c:      	add	x1, sp, #0x60
    4d10:      	mov	x0, x19
    4d14:      	blr	x8
    4d18:      	b	0x4c38 <generic_tracepoint_arg+0x1a8>
    4d1c:      	cmp	w8, #0x3
    4d20:      	cset	w23, eq
    4d24:      	cbz	x23, 0x4b8c <generic_tracepoint_arg+0xfc>
    4d28:      	add	x25, x25, #0x1
    4d2c:      	cmp	x25, #0x5
    4d30:      	b.eq	0x4b80 <generic_tracepoint_arg+0xf0>
    4d34:      	add	x8, x17, x25, lsl #2
    4d38:      	ldr	w8, [x8, #0x4]
    4d3c:      	tst	w8, #0x3ff
    4d40:      	b.eq	0x4b80 <generic_tracepoint_arg+0xf0>
    4d44:      	add	w8, w16, w8
    4d48:      	and	x8, x8, #0x3ff
    4d4c:      	add	x29, x21, x8
    4d50:      	ldr	w8, [x29, #0x4]
    4d54:      	cmp	w8, #0x23
    4d58:      	b.eq	0x4b8c <generic_tracepoint_arg+0xfc>
    4d5c:      	ldr	w9, [x29]
    4d60:      	cmp	w9, #0x4
    4d64:      	b.hi	0x4b8c <generic_tracepoint_arg+0xfc>
    4d68:      	add	x10, x20, x9, lsl #2
    4d6c:      	ldr	w10, [x10, x2]
    4d70:      	cbnz	w10, 0x4b8c <generic_tracepoint_arg+0xfc>
    4d74:      	add	x9, x20, x9, lsl #3
    4d78:      	ldr	x9, [x9, #0x5e78]
    4d7c:      	and	x9, x9, #0x7ff
    4d80:      	add	x9, x20, x9
    4d84:      	add	x22, x9, #0x90
    4d88:      	ldr	w9, [x29, #0xc]
    4d8c:      	cmp	w9, #0x10
    4d90:      	b.le	0x4de0 <generic_tracepoint_arg+0x350>
    4d94:      	sub	w10, w9, #0x1c
    4d98:      	cmp	w10, #0x9
    4d9c:      	b.lo	0x4f50 <generic_tracepoint_arg+0x4c0>
    4da0:      	cmp	w9, #0x2a
    4da4:      	b.hi	0x4dd0 <generic_tracepoint_arg+0x340>
    4da8:      	lsl	x10, x12, x9
    4dac:      	tst	x10, #0xc000000000
    4db0:      	b.ne	0x4e08 <generic_tracepoint_arg+0x378>
    4db4:      	lsl	x10, x12, x9
    4db8:      	tst	x10, #0x30000000000
    4dbc:      	b.ne	0x51f8 <generic_tracepoint_arg+0x768>
    4dc0:      	lsl	x10, x12, x9
    4dc4:      	mov	x11, #0x42000000000     // =4535485464576
    4dc8:      	tst	x10, x11
    4dcc:      	b.ne	0x4e50 <generic_tracepoint_arg+0x3c0>
    4dd0:      	cmp	w9, #0x11
    4dd4:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    4dd8:      	add	x22, x22, #0x4
    4ddc:      	b	0x4e50 <generic_tracepoint_arg+0x3c0>
    4de0:      	cmp	w9, #0x6
    4de4:      	b.gt	0x4e38 <generic_tracepoint_arg+0x3a8>
    4de8:      	cmp	w9, #0x3
    4dec:      	b.le	0x4f0c <generic_tracepoint_arg+0x47c>
    4df0:      	cmp	w9, #0x4
    4df4:      	b.eq	0x4f50 <generic_tracepoint_arg+0x4c0>
    4df8:      	cmp	w9, #0x5
    4dfc:      	b.eq	0x51f8 <generic_tracepoint_arg+0x768>
    4e00:      	cmp	w9, #0x6
    4e04:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    4e08:      	ldr	w24, [x22], #0x4
    4e0c:      	mov	x23, xzr
    4e10:      	cmp	w8, #0x19
    4e14:      	b.gt	0x50ac <generic_tracepoint_arg+0x61c>
    4e18:      	sub	w9, w8, #0x3
    4e1c:      	cmp	w9, #0x2
    4e20:      	b.lo	0x57ac <generic_tracepoint_arg+0xd1c>
    4e24:      	cmp	w8, #0x8
    4e28:      	b.eq	0x5714 <generic_tracepoint_arg+0xc84>
    4e2c:      	cmp	w8, #0x9
    4e30:      	b.eq	0x50c4 <generic_tracepoint_arg+0x634>
    4e34:      	b	0x5cc8 <generic_tracepoint_arg+0x1238>
    4e38:      	sub	w10, w9, #0xa
    4e3c:      	cmp	w10, #0x4
    4e40:      	b.lo	0x4f50 <generic_tracepoint_arg+0x4c0>
    4e44:      	sub	w10, w9, #0xf
    4e48:      	cmp	w10, #0x2
    4e4c:      	b.hs	0x51f0 <generic_tracepoint_arg+0x760>
    4e50:      	ldr	w24, [x22]
    4e54:      	and	w9, w8, #0xfffffffe
    4e58:      	cmp	w9, #0x24
    4e5c:      	b.eq	0x4e64 <generic_tracepoint_arg+0x3d4>
    4e60:      	cbz	w24, 0x4b8c <generic_tracepoint_arg+0xfc>
    4e64:      	cmp	w8, #0x25
    4e68:      	b.hi	0x5190 <generic_tracepoint_arg+0x700>
    4e6c:      	mov	w10, #0x100             // =256
    4e70:      	lsl	x9, x12, x8
    4e74:      	movk	w10, #0x400, lsl #16
    4e78:      	tst	x9, x10
    4e7c:      	b.ne	0x5450 <generic_tracepoint_arg+0x9c0>
    4e80:      	mov	w10, #0x200             // =512
    4e84:      	lsl	x9, x12, x8
    4e88:      	movk	w10, #0x800, lsl #16
    4e8c:      	tst	x9, x10
    4e90:      	b.ne	0x5370 <generic_tracepoint_arg+0x8e0>
    4e94:      	lsl	x9, x12, x8
    4e98:      	tst	x9, #0x3000000000
    4e9c:      	b.eq	0x5190 <generic_tracepoint_arg+0x700>
    4ea0:      	cmp	w24, #0x1fe
    4ea4:      	strh	wzr, [sp, #0x60]
    4ea8:      	b.hi	0x51a8 <generic_tracepoint_arg+0x718>
    4eac:      	add	x8, x22, #0x4
    4eb0:      	mov	w10, #0x4               // =4
    4eb4:      	add	x11, sp, #0x60
    4eb8:      	mov	w12, #0x2               // =2
    4ebc:      	add	x0, sp, #0x60
    4ec0:      	mov	w1, #0x2                // =2
    4ec4:      	add	x9, x8, x24
    4ec8:      	add	x9, x9, #0x4
    4ecc:      	ldr	w9, [x22]
    4ed0:      	add	x8, x8, x9
    4ed4:      	add	x2, x8, #0x4
    4ed8:      	blr	x10
    4edc:      	ldr	w9, [x29, #0x10]
    4ee0:      	cbz	w9, 0x7348 <generic_tracepoint_arg+0x28b8>
    4ee4:      	ldrh	w8, [sp, #0x60]
    4ee8:      	ldp	x16, x15, [sp, #0x40]
    4eec:      	mov	w2, #0x5ea0             // =24224
    4ef0:      	mov	w12, #0x1               // =1
    4ef4:      	and	w8, w8, #0xf000
    4ef8:      	ldr	x17, [sp, #0x38]
    4efc:      	cmp	w9, w8
    4f00:      	b.ne	0x6484 <generic_tracepoint_arg+0x19f4>
    4f04:      	mov	w23, #0x1               // =1
    4f08:      	b	0x735c <generic_tracepoint_arg+0x28cc>
    4f0c:      	cmp	w9, #0x1
    4f10:      	b.eq	0x4f50 <generic_tracepoint_arg+0x4c0>
    4f14:      	cmp	w9, #0x2
    4f18:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    4f1c:      	add	x24, x22, #0x8
    4f20:      	ldr	w22, [x22, #0x4]
    4f24:      	mov	x23, xzr
    4f28:      	cmp	w8, #0x19
    4f2c:      	b.gt	0x5810 <generic_tracepoint_arg+0xd80>
    4f30:      	sub	w9, w8, #0x3
    4f34:      	cmp	w9, #0x2
    4f38:      	b.lo	0x5f7c <generic_tracepoint_arg+0x14ec>
    4f3c:      	cmp	w8, #0x8
    4f40:      	b.eq	0x5ef0 <generic_tracepoint_arg+0x1460>
    4f44:      	cmp	w8, #0x9
    4f48:      	b.eq	0x5828 <generic_tracepoint_arg+0xd98>
    4f4c:      	b	0x778c <generic_tracepoint_arg+0x2cfc>
    4f50:      	cmp	w9, #0xb
    4f54:      	b.le	0x4fc4 <generic_tracepoint_arg+0x534>
    4f58:      	cmp	w9, #0x24
    4f5c:      	b.hi	0x500c <generic_tracepoint_arg+0x57c>
    4f60:      	lsl	x10, x12, x9
    4f64:      	tst	x10, #0x1e00000000
    4f68:      	b.ne	0x4fe4 <generic_tracepoint_arg+0x554>
    4f6c:      	lsl	x10, x12, x9
    4f70:      	tst	x10, #0x60000000
    4f74:      	b.ne	0x51b0 <generic_tracepoint_arg+0x720>
    4f78:      	lsl	x10, x12, x9
    4f7c:      	tst	x10, #0x180000000
    4f80:      	b.eq	0x500c <generic_tracepoint_arg+0x57c>
    4f84:      	cmp	w8, #0x20
    4f88:      	b.hi	0x4b8c <generic_tracepoint_arg+0xfc>
    4f8c:      	lsl	x9, x12, x8
    4f90:      	mov	w10, #0x101e            // =4126
    4f94:      	tst	x9, x10
    4f98:      	b.eq	0x590c <generic_tracepoint_arg+0xe7c>
    4f9c:      	ldr	w9, [x29, #0x10]
    4fa0:      	cmp	w8, #0x2
    4fa4:      	b.le	0x5e18 <generic_tracepoint_arg+0x1388>
    4fa8:      	sub	w10, w8, #0x3
    4fac:      	cmp	w10, #0x2
    4fb0:      	b.hs	0x6340 <generic_tracepoint_arg+0x18b0>
    4fb4:      	ldrb	w10, [x22]
    4fb8:      	cmp	w9, w10
    4fbc:      	b.eq	0x4d1c <generic_tracepoint_arg+0x28c>
    4fc0:      	b	0x66a4 <generic_tracepoint_arg+0x1c14>
    4fc4:      	sub	w10, w9, #0xa
    4fc8:      	cmp	w10, #0x2
    4fcc:      	b.lo	0x5288 <generic_tracepoint_arg+0x7f8>
    4fd0:      	cmp	w9, #0x1
    4fd4:      	b.eq	0x5018 <generic_tracepoint_arg+0x588>
    4fd8:      	cmp	w9, #0x4
    4fdc:      	b.eq	0x5018 <generic_tracepoint_arg+0x588>
    4fe0:      	b	0x4d28 <generic_tracepoint_arg+0x298>
    4fe4:      	cmp	w8, #0x9
    4fe8:      	b.le	0x5238 <generic_tracepoint_arg+0x7a8>
    4fec:      	cmp	w8, #0x1d
    4ff0:      	b.gt	0x55e0 <generic_tracepoint_arg+0xb50>
    4ff4:      	sub	w10, w8, #0xa
    4ff8:      	cmp	w10, #0x2
    4ffc:      	b.lo	0x5314 <generic_tracepoint_arg+0x884>
    5000:      	cmp	w8, #0xc
    5004:      	b.eq	0x52a0 <generic_tracepoint_arg+0x810>
    5008:      	b	0x4b8c <generic_tracepoint_arg+0xfc>
    500c:      	sub	w10, w9, #0xc
    5010:      	cmp	w10, #0x2
    5014:      	b.hs	0x5280 <generic_tracepoint_arg+0x7f0>
    5018:      	cmp	w8, #0x20
    501c:      	b.hi	0x4b8c <generic_tracepoint_arg+0xfc>
    5020:      	lsl	x10, x12, x8
    5024:      	mov	w11, #0x101e            // =4126
    5028:      	tst	x10, x11
    502c:      	b.eq	0x5058 <generic_tracepoint_arg+0x5c8>
    5030:      	ldr	w10, [x29, #0x10]
    5034:      	cmp	w8, #0x2
    5038:      	b.le	0x5248 <generic_tracepoint_arg+0x7b8>
    503c:      	sub	w11, w8, #0x3
    5040:      	cmp	w11, #0x2
    5044:      	b.hs	0x58f4 <generic_tracepoint_arg+0xe64>
    5048:      	ldr	w11, [x22]
    504c:      	cmp	w11, w10
    5050:      	b.eq	0x4d1c <generic_tracepoint_arg+0x28c>
    5054:      	b	0x6920 <generic_tracepoint_arg+0x1e90>
    5058:      	lsl	x10, x12, x8
    505c:      	tst	x10, #0xc00
    5060:      	b.ne	0x54e8 <generic_tracepoint_arg+0xa58>
    5064:      	lsl	x10, x12, x8
    5068:      	tst	x10, #0x180000000
    506c:      	b.eq	0x4b8c <generic_tracepoint_arg+0xfc>
    5070:      	cmp	w8, #0x1f
    5074:      	b.ne	0x5a78 <generic_tracepoint_arg+0xfe8>
    5078:      	ldp	w11, w10, [x29, #0x10]
    507c:      	cmp	w9, #0xc
    5080:      	b.hi	0x6720 <generic_tracepoint_arg+0x1c90>
    5084:      	lsl	w8, w12, w9
    5088:      	mov	w13, #0x1402            // =5122
    508c:      	tst	w8, w13
    5090:      	b.eq	0x6720 <generic_tracepoint_arg+0x1c90>
    5094:      	ldr	w8, [x22]
    5098:      	cmp	w11, w8
    509c:      	b.gt	0x6734 <generic_tracepoint_arg+0x1ca4>
    50a0:      	cmp	w8, w10
    50a4:      	b.le	0x4d28 <generic_tracepoint_arg+0x298>
    50a8:      	b	0x6734 <generic_tracepoint_arg+0x1ca4>
    50ac:      	cmp	w8, #0x20
    50b0:      	b.gt	0x5620 <generic_tracepoint_arg+0xb90>
    50b4:      	cmp	w8, #0x1a
    50b8:      	b.eq	0x5714 <generic_tracepoint_arg+0xc84>
    50bc:      	cmp	w8, #0x1b
    50c0:      	b.ne	0x5cc8 <generic_tracepoint_arg+0x1238>
    50c4:      	ldr	w8, [x29, #0x10]
    50c8:      	str	wzr, [sp, #0x88]
    50cc:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    50d0:      	add	x9, sp, #0x60
    50d4:      	add	x1, sp, #0x60
    50d8:      	str	w8, [sp, #0x60]
    50dc:      	mov	w8, #0x1                // =1
    50e0:      	ldr	x0, [x0]
    50e4:      	blr	x8
    50e8:      	mov	x23, xzr
    50ec:      	cbz	w24, 0x5cb8 <generic_tracepoint_arg+0x1228>
    50f0:      	cbz	x0, 0x5cb8 <generic_tracepoint_arg+0x1228>
    50f4:      	mov	x19, x0
    50f8:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    50fc:      	mov	w8, #0x1                // =1
    5100:      	ldr	x0, [x0]
    5104:      	add	x9, sp, #0x88
    5108:      	add	x1, sp, #0x88
    510c:      	blr	x8
    5110:      	cbz	x0, 0x5cb0 <generic_tracepoint_arg+0x1220>
    5114:      	cmp	w24, #0x7f
    5118:      	mov	w9, #0x7f               // =127
    511c:      	mov	w11, #0x1               // =1
    5120:      	mov	x1, x0
    5124:      	mov	x8, xzr
    5128:      	sub	w12, w24, #0x2
    512c:      	sub	w13, w24, #0x1
    5130:      	csel	w9, w24, w9, lo
    5134:      	sub	x11, x11, x24
    5138:      	lsl	w10, w9, #3
    513c:      	mov	x9, x0
    5140:      	str	w10, [x9], #0x5
    5144:      	neg	x10, x24
    5148:      	add	w14, w13, w8
    514c:      	cmp	x11, x8
    5150:      	and	x14, x14, #0xfff
    5154:      	ldrb	w14, [x22, x14]
    5158:      	sturb	w14, [x9, #-0x1]
    515c:      	b.eq	0x5184 <generic_tracepoint_arg+0x6f4>
    5160:      	cmn	x8, #0x7e
    5164:      	b.eq	0x5184 <generic_tracepoint_arg+0x6f4>
    5168:      	add	w14, w12, w8
    516c:      	sub	x8, x8, #0x2
    5170:      	and	x14, x14, #0xfff
    5174:      	cmp	x10, x8
    5178:      	ldrb	w14, [x22, x14]
    517c:      	strb	w14, [x9], #0x2
    5180:      	b.ne	0x5148 <generic_tracepoint_arg+0x6b8>
    5184:      	mov	w8, #0x1                // =1
    5188:      	mov	x0, x19
    518c:      	b	0x579c <generic_tracepoint_arg+0xd0c>
    5190:      	sub	w8, w8, #0x3
    5194:      	cmp	w8, #0x2
    5198:      	b.hs	0x51a8 <generic_tracepoint_arg+0x718>
    519c:      	cmp	w24, #0x1fe
    51a0:      	str	wzr, [sp, #0x88]
    51a4:      	b.ls	0x5a14 <generic_tracepoint_arg+0xf84>
    51a8:      	mov	x23, xzr
    51ac:      	b	0x735c <generic_tracepoint_arg+0x28cc>
    51b0:      	cmp	w8, #0x20
    51b4:      	b.hi	0x4b8c <generic_tracepoint_arg+0xfc>
    51b8:      	lsl	x9, x12, x8
    51bc:      	mov	w10, #0x101e            // =4126
    51c0:      	tst	x9, x10
    51c4:      	b.eq	0x5938 <generic_tracepoint_arg+0xea8>
    51c8:      	ldr	w9, [x29, #0x10]
    51cc:      	cmp	w8, #0x2
    51d0:      	b.le	0x5e38 <generic_tracepoint_arg+0x13a8>
    51d4:      	sub	w10, w8, #0x3
    51d8:      	cmp	w10, #0x2
    51dc:      	b.hs	0x6358 <generic_tracepoint_arg+0x18c8>
    51e0:      	ldrh	w10, [x22]
    51e4:      	cmp	w9, w10
    51e8:      	b.eq	0x4d1c <generic_tracepoint_arg+0x28c>
    51ec:      	b	0x66e4 <generic_tracepoint_arg+0x1c54>
    51f0:      	cmp	w9, #0x7
    51f4:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    51f8:      	mov	x23, xzr
    51fc:      	cmp	w9, #0x27
    5200:      	stp	xzr, xzr, [sp, #0x78]
    5204:      	str	xzr, [sp, #0x60]
    5208:      	stp	xzr, xzr, [sp, #0x68]
    520c:      	b.gt	0x5220 <generic_tracepoint_arg+0x790>
    5210:      	cmp	w9, #0x5
    5214:      	b.eq	0x553c <generic_tracepoint_arg+0xaac>
    5218:      	cmp	w9, #0x7
    521c:      	b	0x522c <generic_tracepoint_arg+0x79c>
    5220:      	cmp	w9, #0x28
    5224:      	b.eq	0x5544 <generic_tracepoint_arg+0xab4>
    5228:      	cmp	w9, #0x29
    522c:      	mov	x10, x22
    5230:      	b.eq	0x556c <generic_tracepoint_arg+0xadc>
    5234:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    5238:      	sub	w10, w8, #0x1
    523c:      	cmp	w10, #0x4
    5240:      	b.lo	0x52a0 <generic_tracepoint_arg+0x810>
    5244:      	b	0x4b8c <generic_tracepoint_arg+0xfc>
    5248:      	cmp	w8, #0x1
    524c:      	b.eq	0x5bcc <generic_tracepoint_arg+0x113c>
    5250:      	cmp	w8, #0x2
    5254:      	b.ne	0x6920 <generic_tracepoint_arg+0x1e90>
    5258:      	cmp	w9, #0xc
    525c:      	b.hi	0x6914 <generic_tracepoint_arg+0x1e84>
    5260:      	lsl	w11, w12, w9
    5264:      	mov	w13, #0x1402            // =5122
    5268:      	tst	w11, w13
    526c:      	b.eq	0x6914 <generic_tracepoint_arg+0x1e84>
    5270:      	ldr	w11, [x22]
    5274:      	cmp	w11, w10
    5278:      	b.lt	0x4d28 <generic_tracepoint_arg+0x298>
    527c:      	b	0x6920 <generic_tracepoint_arg+0x1e90>
    5280:      	cmp	w9, #0x1c
    5284:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    5288:      	cmp	w8, #0x20
    528c:      	b.hi	0x4b8c <generic_tracepoint_arg+0xfc>
    5290:      	lsl	x10, x12, x8
    5294:      	mov	w11, #0x101e            // =4126
    5298:      	tst	x10, x11
    529c:      	b.eq	0x52c8 <generic_tracepoint_arg+0x838>
    52a0:      	ldr	x10, [x29, #0x10]
    52a4:      	cmp	w8, #0x2
    52a8:      	b.le	0x52e4 <generic_tracepoint_arg+0x854>
    52ac:      	sub	w11, w8, #0x3
    52b0:      	cmp	w11, #0x2
    52b4:      	b.hs	0x5524 <generic_tracepoint_arg+0xa94>
    52b8:      	ldr	x11, [x22]
    52bc:      	cmp	x11, x10
    52c0:      	b.eq	0x4d1c <generic_tracepoint_arg+0x28c>
    52c4:      	b	0x629c <generic_tracepoint_arg+0x180c>
    52c8:      	lsl	x10, x12, x8
    52cc:      	tst	x10, #0xc00
    52d0:      	b.ne	0x5314 <generic_tracepoint_arg+0x884>
    52d4:      	lsl	x10, x12, x8
    52d8:      	tst	x10, #0x180000000
    52dc:      	b.ne	0x55ec <generic_tracepoint_arg+0xb5c>
    52e0:      	b	0x4b8c <generic_tracepoint_arg+0xfc>
    52e4:      	cmp	w8, #0x1
    52e8:      	b.eq	0x59dc <generic_tracepoint_arg+0xf4c>
    52ec:      	cmp	w8, #0x2
    52f0:      	b.ne	0x629c <generic_tracepoint_arg+0x180c>
    52f4:      	cmp	w9, #0xc
    52f8:      	b.eq	0x5304 <generic_tracepoint_arg+0x874>
    52fc:      	cmp	w9, #0xa
    5300:      	b.ne	0x6290 <generic_tracepoint_arg+0x1800>
    5304:      	ldr	x11, [x22]
    5308:      	cmp	x11, x10
    530c:      	b.lt	0x4d28 <generic_tracepoint_arg+0x298>
    5310:      	b	0x629c <generic_tracepoint_arg+0x180c>
    5314:      	ldrb	w8, [x29, #0x10]
    5318:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    531c:      	add	x9, sp, #0x88
    5320:      	add	x1, sp, #0x88
    5324:      	str	w8, [sp, #0x88]
    5328:      	mov	w8, #0x1                // =1
    532c:      	ldr	x0, [x0]
    5330:      	blr	x8
    5334:      	cbz	x0, 0x59fc <generic_tracepoint_arg+0xf6c>
    5338:      	ldr	x8, [x22]
    533c:      	add	x9, sp, #0x60
    5340:      	add	x1, sp, #0x60
    5344:      	str	x8, [sp, #0x60]
    5348:      	mov	w8, #0x1                // =1
    534c:      	blr	x8
    5350:      	ldr	w8, [x29, #0x4]
    5354:      	cmp	w8, #0xb
    5358:      	b.eq	0x5ed0 <generic_tracepoint_arg+0x1440>
    535c:      	cmp	w8, #0xa
    5360:      	mov	w12, #0x1               // =1
    5364:      	b.eq	0x614c <generic_tracepoint_arg+0x16bc>
    5368:      	mov	w8, wzr
    536c:      	b	0x6154 <generic_tracepoint_arg+0x16c4>
    5370:      	ldr	w8, [x29, #0x10]
    5374:      	str	wzr, [sp, #0x88]
    5378:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    537c:      	add	x9, sp, #0x60
    5380:      	add	x1, sp, #0x60
    5384:      	str	w8, [sp, #0x60]
    5388:      	mov	w8, #0x1                // =1
    538c:      	ldr	x0, [x0]
    5390:      	blr	x8
    5394:      	mov	x23, xzr
    5398:      	cbz	w24, 0x6330 <generic_tracepoint_arg+0x18a0>
    539c:      	mov	w12, #0x1               // =1
    53a0:      	cbz	x0, 0x6334 <generic_tracepoint_arg+0x18a4>
    53a4:      	mov	x19, x0
    53a8:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    53ac:      	mov	w8, #0x1                // =1
    53b0:      	ldr	x0, [x0]
    53b4:      	add	x9, sp, #0x88
    53b8:      	add	x1, sp, #0x88
    53bc:      	mov	w23, #0x1               // =1
    53c0:      	blr	x8
    53c4:      	cbz	x0, 0x6328 <generic_tracepoint_arg+0x1898>
    53c8:      	cmp	w24, #0x7f
    53cc:      	mov	w10, #0x7f              // =127
    53d0:      	mov	x1, x0
    53d4:      	mov	x8, xzr
    53d8:      	add	x9, x22, #0x4
    53dc:      	sub	x12, x23, x24
    53e0:      	sub	w13, w24, #0x2
    53e4:      	sub	w14, w24, #0x1
    53e8:      	csel	w10, w24, w10, lo
    53ec:      	lsl	w11, w10, #3
    53f0:      	mov	x10, x0
    53f4:      	str	w11, [x10], #0x5
    53f8:      	neg	x11, x24
    53fc:      	add	w15, w14, w8
    5400:      	cmp	x12, x8
    5404:      	and	x15, x15, #0xfff
    5408:      	ldrb	w15, [x9, x15]
    540c:      	sturb	w15, [x10, #-0x1]
    5410:      	b.eq	0x5438 <generic_tracepoint_arg+0x9a8>
    5414:      	cmn	x8, #0x7e
    5418:      	b.eq	0x5438 <generic_tracepoint_arg+0x9a8>
    541c:      	add	w15, w13, w8
    5420:      	sub	x8, x8, #0x2
    5424:      	and	x15, x15, #0xfff
    5428:      	cmp	x11, x8
    542c:      	ldrb	w15, [x9, x15]
    5430:      	strb	w15, [x10], #0x2
    5434:      	b.ne	0x53fc <generic_tracepoint_arg+0x96c>
    5438:      	mov	w8, #0x1                // =1
    543c:      	mov	x0, x19
    5440:      	blr	x8
    5444:      	cmp	x0, #0x0
    5448:      	cset	w23, ne
    544c:      	b	0x632c <generic_tracepoint_arg+0x189c>
    5450:      	ldr	w8, [x29, #0x10]
    5454:      	str	wzr, [sp, #0x88]
    5458:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    545c:      	add	x9, sp, #0x60
    5460:      	add	x1, sp, #0x60
    5464:      	str	w8, [sp, #0x60]
    5468:      	mov	w8, #0x1                // =1
    546c:      	ldr	x0, [x0]
    5470:      	blr	x8
    5474:      	mov	x23, xzr
    5478:      	cbz	w24, 0x734c <generic_tracepoint_arg+0x28bc>
    547c:      	cbz	x0, 0x734c <generic_tracepoint_arg+0x28bc>
    5480:      	mov	x19, x0
    5484:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    5488:      	mov	w8, #0x1                // =1
    548c:      	ldr	x0, [x0]
    5490:      	add	x9, sp, #0x88
    5494:      	add	x1, sp, #0x88
    5498:      	blr	x8
    549c:      	cbz	x0, 0x64d4 <generic_tracepoint_arg+0x1a44>
    54a0:      	cmp	w24, #0xff
    54a4:      	mov	w8, #0xff               // =255
    54a8:      	add	x2, x22, #0x4
    54ac:      	mov	x22, x0
    54b0:      	csel	w1, w24, w8, lo
    54b4:      	mov	x8, x0
    54b8:      	lsl	w9, w1, #3
    54bc:      	str	w9, [x8], #0x4
    54c0:      	mov	w9, #0x4                // =4
    54c4:      	mov	x0, x8
    54c8:      	blr	x9
    54cc:      	mov	w8, #0x1                // =1
    54d0:      	mov	x0, x19
    54d4:      	mov	x1, x22
    54d8:      	blr	x8
    54dc:      	cmp	x0, #0x0
    54e0:      	cset	w23, ne
    54e4:      	b	0x64d8 <generic_tracepoint_arg+0x1a48>
    54e8:      	ldrb	w8, [x29, #0x10]
    54ec:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    54f0:      	add	x9, sp, #0x88
    54f4:      	add	x1, sp, #0x88
    54f8:      	str	w8, [sp, #0x88]
    54fc:      	mov	w8, #0x1                // =1
    5500:      	ldr	x0, [x0]
    5504:      	blr	x8
    5508:      	cbz	x0, 0x6274 <generic_tracepoint_arg+0x17e4>
    550c:      	ldr	w8, [x22]
    5510:      	add	x9, sp, #0x60
    5514:      	add	x1, sp, #0x60
    5518:      	str	x8, [sp, #0x60]
    551c:      	mov	w8, #0x1                // =1
    5520:      	b	0x623c <generic_tracepoint_arg+0x17ac>
    5524:      	cmp	w8, #0xc
    5528:      	b.ne	0x629c <generic_tracepoint_arg+0x180c>
    552c:      	ldr	x11, [x22]
    5530:      	tst	x11, x10
    5534:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    5538:      	b	0x629c <generic_tracepoint_arg+0x180c>
    553c:      	mov	x10, xzr
    5540:      	b	0x556c <generic_tracepoint_arg+0xadc>
    5544:      	ldrh	w11, [x22]
    5548:      	mov	x10, xzr
    554c:      	strh	w11, [sp, #0x86]
    5550:      	ldrh	w11, [x22, #0x2]
    5554:      	strh	w11, [sp, #0x80]
    5558:      	ldr	x11, [x22, #0x8]
    555c:      	str	x11, [sp, #0x60]
    5560:      	ldr	x11, [x22, #0x10]
    5564:      	add	x22, sp, #0x60
    5568:      	str	x11, [sp, #0x68]
    556c:      	mov	x23, xzr
    5570:      	cmp	w8, #0x13
    5574:      	b.le	0x559c <generic_tracepoint_arg+0xb0c>
    5578:      	cmp	w8, #0x17
    557c:      	b.gt	0x55c4 <generic_tracepoint_arg+0xb34>
    5580:      	sub	w9, w8, #0x14
    5584:      	cmp	w9, #0x2
    5588:      	b.lo	0x5acc <generic_tracepoint_arg+0x103c>
    558c:      	sub	w9, w8, #0x16
    5590:      	cmp	w9, #0x2
    5594:      	b.lo	0x5ab8 <generic_tracepoint_arg+0x1028>
    5598:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    559c:      	cmp	w8, #0xf
    55a0:      	b.le	0x57f4 <generic_tracepoint_arg+0xd64>
    55a4:      	cmp	w8, #0x11
    55a8:      	b.gt	0x5aa8 <generic_tracepoint_arg+0x1018>
    55ac:      	cmp	w8, #0x10
    55b0:      	b.eq	0x5ab8 <generic_tracepoint_arg+0x1028>
    55b4:      	cmp	w8, #0x11
    55b8:      	b.ne	0x4d24 <generic_tracepoint_arg+0x294>
    55bc:      	ldrh	w23, [x22, #0x24]
    55c0:      	b	0x6208 <generic_tracepoint_arg+0x1778>
    55c4:      	cmp	w8, #0x1b
    55c8:      	b.gt	0x5ae0 <generic_tracepoint_arg+0x1050>
    55cc:      	cmp	w8, #0x18
    55d0:      	b.eq	0x5b10 <generic_tracepoint_arg+0x1080>
    55d4:      	cmp	w8, #0x19
    55d8:      	b.eq	0x5b04 <generic_tracepoint_arg+0x1074>
    55dc:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    55e0:      	sub	w10, w8, #0x1f
    55e4:      	cmp	w10, #0x2
    55e8:      	b.hs	0x5f90 <generic_tracepoint_arg+0x1500>
    55ec:      	cmp	w8, #0x1f
    55f0:      	b.ne	0x57cc <generic_tracepoint_arg+0xd3c>
    55f4:      	ldp	x11, x10, [x29, #0x10]
    55f8:      	cmp	w9, #0xa
    55fc:      	b.eq	0x5608 <generic_tracepoint_arg+0xb78>
    5600:      	cmp	w9, #0xc
    5604:      	b.ne	0x6178 <generic_tracepoint_arg+0x16e8>
    5608:      	ldr	x8, [x22]
    560c:      	cmp	x11, x8
    5610:      	b.gt	0x618c <generic_tracepoint_arg+0x16fc>
    5614:      	cmp	x8, x10
    5618:      	b.le	0x4d28 <generic_tracepoint_arg+0x298>
    561c:      	b	0x618c <generic_tracepoint_arg+0x16fc>
    5620:      	cmp	w8, #0x21
    5624:      	b.eq	0x5bf4 <generic_tracepoint_arg+0x1164>
    5628:      	cmp	w8, #0x22
    562c:      	b.ne	0x5cc8 <generic_tracepoint_arg+0x1238>
    5630:      	mov	x23, xzr
    5634:      	mov	w19, wzr
    5638:      	add	x8, x29, #0x10
    563c:      	str	x8, [sp, #0x28]
    5640:      	ldr	x8, [sp, #0x28]
    5644:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    5648:      	add	x9, sp, #0x60
    564c:      	add	x1, sp, #0x60
    5650:      	ldr	w8, [x8, x23, lsl #2]
    5654:      	str	w8, [sp, #0x60]
    5658:      	mov	w8, #0x1                // =1
    565c:      	ldr	x0, [x0]
    5660:      	blr	x8
    5664:      	cbz	x0, 0x5cb0 <generic_tracepoint_arg+0x1220>
    5668:      	cbz	w24, 0x56f0 <generic_tracepoint_arg+0xc60>
    566c:      	mov	x8, xzr
    5670:      	mov	x9, x22
    5674:      	mov	x10, x24
    5678:      	b	0x5690 <generic_tracepoint_arg+0xc00>
    567c:      	add	x8, x8, #0x1
    5680:      	sub	x10, x10, #0x1
    5684:      	add	x9, x9, #0x1
    5688:      	cmp	x8, x24
    568c:      	b.eq	0x56f0 <generic_tracepoint_arg+0xc60>
    5690:      	mov	x11, xzr
    5694:      	nop
    5698:      	nop
    569c:      	nop
    56a0:      	cmp	x10, x11
    56a4:      	b.eq	0x567c <generic_tracepoint_arg+0xbec>
    56a8:      	ldrb	w12, [x0, x11]
    56ac:      	cbz	w12, 0x56ec <generic_tracepoint_arg+0xc5c>
    56b0:      	ldrb	w13, [x9, x11]
    56b4:      	sub	w14, w13, #0x41
    56b8:      	orr	w15, w13, #0x20
    56bc:      	cmp	w14, #0x1a
    56c0:      	sub	w14, w12, #0x41
    56c4:      	csel	w13, w15, w13, lo
    56c8:      	orr	w15, w12, #0x20
    56cc:      	cmp	w14, #0x1a
    56d0:      	csel	w12, w15, w12, lo
    56d4:      	cmp	x11, #0x62
    56d8:      	b.hi	0x567c <generic_tracepoint_arg+0xbec>
    56dc:      	add	x11, x11, #0x1
    56e0:      	cmp	w13, w12
    56e4:      	b.eq	0x56a0 <generic_tracepoint_arg+0xc10>
    56e8:      	b	0x567c <generic_tracepoint_arg+0xbec>
    56ec:      	tbz	w8, #0x1f, 0x67c4 <generic_tracepoint_arg+0x1d34>
    56f0:      	ldr	w9, [x29, #0x8]
    56f4:      	add	w8, w19, #0xc
    56f8:      	cmp	w8, w9
    56fc:      	b.hs	0x5cb0 <generic_tracepoint_arg+0x1220>
    5700:      	add	x23, x23, #0x1
    5704:      	add	w19, w19, #0x4
    5708:      	cmp	x23, #0x64
    570c:      	b.ne	0x5640 <generic_tracepoint_arg+0xbb0>
    5710:      	b	0x5cb0 <generic_tracepoint_arg+0x1220>
    5714:      	ldr	w8, [x29, #0x10]
    5718:      	str	wzr, [sp, #0x88]
    571c:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    5720:      	add	x9, sp, #0x60
    5724:      	add	x1, sp, #0x60
    5728:      	str	w8, [sp, #0x60]
    572c:      	mov	w8, #0x1                // =1
    5730:      	ldr	x0, [x0]
    5734:      	blr	x8
    5738:      	mov	x23, xzr
    573c:      	cbz	w24, 0x5cb8 <generic_tracepoint_arg+0x1228>
    5740:      	cbz	x0, 0x5cb8 <generic_tracepoint_arg+0x1228>
    5744:      	mov	x19, x0
    5748:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    574c:      	mov	w8, #0x1                // =1
    5750:      	ldr	x0, [x0]
    5754:      	add	x9, sp, #0x88
    5758:      	add	x1, sp, #0x88
    575c:      	blr	x8
    5760:      	cbz	x0, 0x5cb0 <generic_tracepoint_arg+0x1220>
    5764:      	cmp	w24, #0xff
    5768:      	mov	w8, #0xff               // =255
    576c:      	mov	x2, x22
    5770:      	csel	w1, w24, w8, lo
    5774:      	mov	x8, x0
    5778:      	mov	x24, x0
    577c:      	lsl	w9, w1, #3
    5780:      	str	w9, [x8], #0x4
    5784:      	mov	w9, #0x4                // =4
    5788:      	mov	x0, x8
    578c:      	blr	x9
    5790:      	mov	w8, #0x1                // =1
    5794:      	mov	x0, x19
    5798:      	mov	x1, x24
    579c:      	blr	x8
    57a0:      	cmp	x0, #0x0
    57a4:      	cset	w23, ne
    57a8:      	b	0x5cb4 <generic_tracepoint_arg+0x1224>
    57ac:      	cmp	w24, #0x1fe
    57b0:      	str	wzr, [sp, #0x88]
    57b4:      	b.ls	0x5cf0 <generic_tracepoint_arg+0x1260>
    57b8:      	mov	x23, xzr
    57bc:      	ldr	w8, [x29, #0x4]
    57c0:      	cmp	w8, #0x25
    57c4:      	b.ls	0x5cd4 <generic_tracepoint_arg+0x1244>
    57c8:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    57cc:      	ldp	x11, x8, [x29, #0x10]
    57d0:      	cmp	w9, #0xc
    57d4:      	b.eq	0x57e0 <generic_tracepoint_arg+0xd50>
    57d8:      	cmp	w9, #0xa
    57dc:      	b.ne	0x61c4 <generic_tracepoint_arg+0x1734>
    57e0:      	ldr	x10, [x22]
    57e4:      	cmp	x11, x10
    57e8:      	ccmp	x10, x8, #0x0, le
    57ec:      	cset	w8, le
    57f0:      	b	0x61d4 <generic_tracepoint_arg+0x1744>
    57f4:      	cmp	w8, #0xd
    57f8:      	b.eq	0x5b10 <generic_tracepoint_arg+0x1080>
    57fc:      	cmp	w8, #0xe
    5800:      	b.eq	0x5b04 <generic_tracepoint_arg+0x1074>
    5804:      	cmp	w8, #0xf
    5808:      	b.eq	0x5acc <generic_tracepoint_arg+0x103c>
    580c:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    5810:      	cmp	w8, #0x20
    5814:      	b.gt	0x5d98 <generic_tracepoint_arg+0x1308>
    5818:      	cmp	w8, #0x1a
    581c:      	b.eq	0x5ef0 <generic_tracepoint_arg+0x1460>
    5820:      	cmp	w8, #0x1b
    5824:      	b.ne	0x778c <generic_tracepoint_arg+0x2cfc>
    5828:      	ldr	w8, [x29, #0x10]
    582c:      	str	wzr, [sp, #0x88]
    5830:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    5834:      	add	x9, sp, #0x60
    5838:      	add	x1, sp, #0x60
    583c:      	mov	w19, #0x1               // =1
    5840:      	str	w8, [sp, #0x60]
    5844:      	mov	w8, #0x1                // =1
    5848:      	ldr	x0, [x0]
    584c:      	blr	x8
    5850:      	mov	x23, xzr
    5854:      	cbz	w22, 0x777c <generic_tracepoint_arg+0x2cec>
    5858:      	cbz	x0, 0x777c <generic_tracepoint_arg+0x2cec>
    585c:      	mov	x23, x0
    5860:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    5864:      	mov	w8, #0x1                // =1
    5868:      	ldr	x0, [x0]
    586c:      	add	x9, sp, #0x88
    5870:      	add	x1, sp, #0x88
    5874:      	blr	x8
    5878:      	cbz	x0, 0x7778 <generic_tracepoint_arg+0x2ce8>
    587c:      	cmp	w22, #0x7f
    5880:      	mov	w9, #0x7f               // =127
    5884:      	mov	x1, x0
    5888:      	mov	x8, xzr
    588c:      	sub	x11, x19, x22
    5890:      	sub	w12, w22, #0x2
    5894:      	sub	w13, w22, #0x1
    5898:      	csel	w9, w22, w9, lo
    589c:      	lsl	w10, w9, #3
    58a0:      	mov	x9, x0
    58a4:      	str	w10, [x9], #0x5
    58a8:      	neg	x10, x22
    58ac:      	add	w14, w13, w8
    58b0:      	cmp	x11, x8
    58b4:      	and	x14, x14, #0xfff
    58b8:      	ldrb	w14, [x24, x14]
    58bc:      	sturb	w14, [x9, #-0x1]
    58c0:      	b.eq	0x58e8 <generic_tracepoint_arg+0xe58>
    58c4:      	cmn	x8, #0x7e
    58c8:      	b.eq	0x58e8 <generic_tracepoint_arg+0xe58>
    58cc:      	add	w14, w12, w8
    58d0:      	sub	x8, x8, #0x2
    58d4:      	and	x14, x14, #0xfff
    58d8:      	cmp	x10, x8
    58dc:      	ldrb	w14, [x24, x14]
    58e0:      	strb	w14, [x9], #0x2
    58e4:      	b.ne	0x58ac <generic_tracepoint_arg+0xe1c>
    58e8:      	mov	w8, #0x1                // =1
    58ec:      	mov	x0, x23
    58f0:      	b	0x7768 <generic_tracepoint_arg+0x2cd8>
    58f4:      	cmp	w8, #0xc
    58f8:      	b.ne	0x6920 <generic_tracepoint_arg+0x1e90>
    58fc:      	ldr	w11, [x22]
    5900:      	tst	w11, w10
    5904:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    5908:      	b	0x6920 <generic_tracepoint_arg+0x1e90>
    590c:      	lsl	x9, x12, x8
    5910:      	tst	x9, #0xc00
    5914:      	b.ne	0x5e58 <generic_tracepoint_arg+0x13c8>
    5918:      	lsl	x9, x12, x8
    591c:      	tst	x9, #0x180000000
    5920:      	b.eq	0x4b8c <generic_tracepoint_arg+0xfc>
    5924:      	cmp	w8, #0x1f
    5928:      	b.ne	0x64e0 <generic_tracepoint_arg+0x1a50>
    592c:      	ldr	w9, [x29, #0x10]
    5930:      	ldrb	w8, [x22]
    5934:      	b	0x5960 <generic_tracepoint_arg+0xed0>
    5938:      	lsl	x9, x12, x8
    593c:      	tst	x9, #0xc00
    5940:      	b.ne	0x5e94 <generic_tracepoint_arg+0x1404>
    5944:      	lsl	x9, x12, x8
    5948:      	tst	x9, #0x180000000
    594c:      	b.eq	0x4b8c <generic_tracepoint_arg+0xfc>
    5950:      	cmp	w8, #0x1f
    5954:      	b.ne	0x6504 <generic_tracepoint_arg+0x1a74>
    5958:      	ldr	w9, [x29, #0x10]
    595c:      	ldrh	w8, [x22]
    5960:      	cmp	w9, w8
    5964:      	b.hi	0x5974 <generic_tracepoint_arg+0xee4>
    5968:      	ldr	w9, [x29, #0x14]
    596c:      	cmp	w9, w8
    5970:      	b.hs	0x4d28 <generic_tracepoint_arg+0x298>
    5974:      	ldr	w9, [x29, #0x8]
    5978:      	cmp	w9, #0x11
    597c:      	b.lo	0x4b8c <generic_tracepoint_arg+0xfc>
    5980:      	ldr	w10, [x29, #0x18]
    5984:      	cmp	w10, w8
    5988:      	b.hi	0x5998 <generic_tracepoint_arg+0xf08>
    598c:      	ldr	w10, [x29, #0x1c]
    5990:      	cmp	w10, w8
    5994:      	b.hs	0x4d28 <generic_tracepoint_arg+0x298>
    5998:      	cmp	w9, #0x19
    599c:      	b.lo	0x4b8c <generic_tracepoint_arg+0xfc>
    59a0:      	ldr	w10, [x29, #0x20]
    59a4:      	cmp	w10, w8
    59a8:      	b.hi	0x59b8 <generic_tracepoint_arg+0xf28>
    59ac:      	ldr	w10, [x29, #0x24]
    59b0:      	cmp	w10, w8
    59b4:      	b.hs	0x4d28 <generic_tracepoint_arg+0x298>
    59b8:      	cmp	w9, #0x21
    59bc:      	b.lo	0x4b8c <generic_tracepoint_arg+0xfc>
    59c0:      	ldr	w9, [x29, #0x28]
    59c4:      	cmp	w9, w8
    59c8:      	b.hi	0x4b8c <generic_tracepoint_arg+0xfc>
    59cc:      	ldr	w9, [x29, #0x2c]
    59d0:      	cmp	w9, w8
    59d4:      	b.hs	0x4d28 <generic_tracepoint_arg+0x298>
    59d8:      	b	0x4b8c <generic_tracepoint_arg+0xfc>
    59dc:      	cmp	w9, #0xc
    59e0:      	b.eq	0x59ec <generic_tracepoint_arg+0xf5c>
    59e4:      	cmp	w9, #0xa
    59e8:      	b.ne	0x6280 <generic_tracepoint_arg+0x17f0>
    59ec:      	ldr	x11, [x22]
    59f0:      	cmp	x11, x10
    59f4:      	b.gt	0x4d28 <generic_tracepoint_arg+0x298>
    59f8:      	b	0x629c <generic_tracepoint_arg+0x180c>
    59fc:      	ldp	x16, x15, [sp, #0x40]
    5a00:      	mov	x23, xzr
    5a04:      	mov	w2, #0x5ea0             // =24224
    5a08:      	mov	w12, #0x1               // =1
    5a0c:      	ldr	x17, [sp, #0x38]
    5a10:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    5a14:      	and	w8, w24, #0xffff
    5a18:      	cmp	w8, #0x90
    5a1c:      	b.hi	0x5ff0 <generic_tracepoint_arg+0x1560>
    5a20:      	and	w8, w24, #0xff
    5a24:      	mov	w9, #0xab               // =171
    5a28:      	tst	w24, #0xffff
    5a2c:      	mul	w8, w8, w9
    5a30:      	mov	w9, #0x18               // =24
    5a34:      	lsr	w8, w8, #12
    5a38:      	msub	w8, w8, w9, w24
    5a3c:      	b.eq	0x5a4c <generic_tracepoint_arg+0xfbc>
    5a40:      	tst	w8, #0xff
    5a44:      	mov	w11, w24
    5a48:      	b.eq	0x5a60 <generic_tracepoint_arg+0xfd0>
    5a4c:      	sub	w8, w24, w8, uxtb
    5a50:      	and	w9, w8, #0xffff
    5a54:      	add	w11, w8, #0x18
    5a58:      	cmp	w9, #0x78
    5a5c:      	b.hi	0x6004 <generic_tracepoint_arg+0x1574>
    5a60:      	and	w8, w11, #0xff
    5a64:      	mov	w9, #0xab               // =171
    5a68:      	mul	w8, w8, w9
    5a6c:      	lsr	w8, w8, #12
    5a70:      	sub	w10, w8, #0x1
    5a74:      	b	0x6014 <generic_tracepoint_arg+0x1584>
    5a78:      	ldp	w11, w8, [x29, #0x10]
    5a7c:      	cmp	w9, #0xc
    5a80:      	b.hi	0x6778 <generic_tracepoint_arg+0x1ce8>
    5a84:      	lsl	w10, w12, w9
    5a88:      	mov	w13, #0x1402            // =5122
    5a8c:      	tst	w10, w13
    5a90:      	b.eq	0x6778 <generic_tracepoint_arg+0x1ce8>
    5a94:      	ldr	w10, [x22]
    5a98:      	cmp	w11, w10
    5a9c:      	ccmp	w10, w8, #0x0, le
    5aa0:      	cset	w8, le
    5aa4:      	b	0x6788 <generic_tracepoint_arg+0x1cf8>
    5aa8:      	cmp	w8, #0x12
    5aac:      	b.eq	0x5acc <generic_tracepoint_arg+0x103c>
    5ab0:      	cmp	w8, #0x13
    5ab4:      	b.ne	0x4d24 <generic_tracepoint_arg+0x294>
    5ab8:      	ldrh	w24, [x22, #0x22]
    5abc:      	mov	w11, wzr
    5ac0:      	mov	w13, wzr
    5ac4:      	mov	x19, xzr
    5ac8:      	b	0x5b1c <generic_tracepoint_arg+0x108c>
    5acc:      	ldrh	w24, [x22, #0x20]
    5ad0:      	mov	w11, wzr
    5ad4:      	mov	w13, wzr
    5ad8:      	mov	x19, xzr
    5adc:      	b	0x5b1c <generic_tracepoint_arg+0x108c>
    5ae0:      	cmp	w8, #0x1c
    5ae4:      	b.eq	0x6204 <generic_tracepoint_arg+0x1774>
    5ae8:      	cmp	w8, #0x1d
    5aec:      	b.ne	0x4d24 <generic_tracepoint_arg+0x294>
    5af0:      	cmp	w9, #0x7
    5af4:      	b.ne	0x6850 <generic_tracepoint_arg+0x1dc0>
    5af8:      	cbnz	x10, 0x6860 <generic_tracepoint_arg+0x1dd0>
    5afc:      	mov	x19, xzr
    5b00:      	b	0x6874 <generic_tracepoint_arg+0x1de4>
    5b04:      	ldp	w11, w13, [x22, #0x10]
    5b08:      	ldr	x19, [x22, #0x18]
    5b0c:      	b	0x5b18 <generic_tracepoint_arg+0x1088>
    5b10:      	ldp	w11, w13, [x22]
    5b14:      	ldr	x19, [x22, #0x8]
    5b18:      	mov	x24, xzr
    5b1c:      	mov	x23, xzr
    5b20:      	cmp	w8, #0x11
    5b24:      	b.gt	0x5b50 <generic_tracepoint_arg+0x10c0>
    5b28:      	sub	w9, w8, #0xd
    5b2c:      	cmp	w9, #0x2
    5b30:      	b.lo	0x5b7c <generic_tracepoint_arg+0x10ec>
    5b34:      	ldr	x19, [sp, #0x30]
    5b38:      	sub	w9, w8, #0xf
    5b3c:      	cmp	w9, #0x2
    5b40:      	b.lo	0x5d64 <generic_tracepoint_arg+0x12d4>
    5b44:      	cmp	w8, #0x11
    5b48:      	b.eq	0x6208 <generic_tracepoint_arg+0x1778>
    5b4c:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    5b50:      	cmp	w8, #0x19
    5b54:      	b.hi	0x5d54 <generic_tracepoint_arg+0x12c4>
    5b58:      	lsl	w9, w12, w8
    5b5c:      	mov	w10, #0x500000          // =5242880
    5b60:      	tst	w9, w10
    5b64:      	b.ne	0x5fd0 <generic_tracepoint_arg+0x1540>
    5b68:      	mov	w10, #0xa00000          // =10485760
    5b6c:      	tst	w9, w10
    5b70:      	b.ne	0x5fe0 <generic_tracepoint_arg+0x1550>
    5b74:      	tst	w9, #0x3000000
    5b78:      	b.eq	0x5d54 <generic_tracepoint_arg+0x12c4>
    5b7c:      	ldrh	w8, [x22, #0x26]
    5b80:      	cmp	w8, #0xa
    5b84:      	b.eq	0x60dc <generic_tracepoint_arg+0x164c>
    5b88:      	cmp	w8, #0x2
    5b8c:      	b.ne	0x6168 <generic_tracepoint_arg+0x16d8>
    5b90:      	ldr	w8, [x29, #0x10]
    5b94:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    5b98:      	add	x9, sp, #0xac
    5b9c:      	add	x1, sp, #0xac
    5ba0:      	str	w8, [sp, #0xac]
    5ba4:      	mov	w8, #0x1                // =1
    5ba8:      	mov	w22, w11
    5bac:      	ldr	x0, [x0]
    5bb0:      	blr	x8
    5bb4:      	ldr	x19, [sp, #0x30]
    5bb8:      	cbz	x0, 0x69e8 <generic_tracepoint_arg+0x1f58>
    5bbc:      	mov	w8, #0x20               // =32
    5bc0:      	add	x1, sp, #0x88
    5bc4:      	stp	w8, w22, [sp, #0x88]
    5bc8:      	b	0x6124 <generic_tracepoint_arg+0x1694>
    5bcc:      	cmp	w9, #0xc
    5bd0:      	b.hi	0x6904 <generic_tracepoint_arg+0x1e74>
    5bd4:      	lsl	w11, w12, w9
    5bd8:      	mov	w13, #0x1402            // =5122
    5bdc:      	tst	w11, w13
    5be0:      	b.eq	0x6904 <generic_tracepoint_arg+0x1e74>
    5be4:      	ldr	w11, [x22]
    5be8:      	cmp	w11, w10
    5bec:      	b.gt	0x4d28 <generic_tracepoint_arg+0x298>
    5bf0:      	b	0x6920 <generic_tracepoint_arg+0x1e90>
    5bf4:      	mov	x19, xzr
    5bf8:      	mov	w23, wzr
    5bfc:      	add	x8, x29, #0x10
    5c00:      	str	x8, [sp, #0x28]
    5c04:      	ldr	x8, [sp, #0x28]
    5c08:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    5c0c:      	add	x9, sp, #0x60
    5c10:      	add	x1, sp, #0x60
    5c14:      	ldr	w8, [x8, x19, lsl #2]
    5c18:      	str	w8, [sp, #0x60]
    5c1c:      	mov	w8, #0x1                // =1
    5c20:      	ldr	x0, [x0]
    5c24:      	blr	x8
    5c28:      	cbz	x0, 0x5cb0 <generic_tracepoint_arg+0x1220>
    5c2c:      	cbz	w24, 0x5c90 <generic_tracepoint_arg+0x1200>
    5c30:      	mov	x8, xzr
    5c34:      	mov	x9, x22
    5c38:      	mov	x10, x24
    5c3c:      	b	0x5c54 <generic_tracepoint_arg+0x11c4>
    5c40:      	add	x8, x8, #0x1
    5c44:      	sub	x10, x10, #0x1
    5c48:      	add	x9, x9, #0x1
    5c4c:      	cmp	x8, x24
    5c50:      	b.eq	0x5c90 <generic_tracepoint_arg+0x1200>
    5c54:      	mov	x11, xzr
    5c58:      	nop
    5c5c:      	nop
    5c60:      	cmp	x10, x11
    5c64:      	b.eq	0x5c40 <generic_tracepoint_arg+0x11b0>
    5c68:      	ldrb	w12, [x0, x11]
    5c6c:      	cbz	w12, 0x5c8c <generic_tracepoint_arg+0x11fc>
    5c70:      	cmp	x11, #0x62
    5c74:      	b.hi	0x5c40 <generic_tracepoint_arg+0x11b0>
    5c78:      	ldrb	w13, [x9, x11]
    5c7c:      	add	x11, x11, #0x1
    5c80:      	cmp	w13, w12
    5c84:      	b.eq	0x5c60 <generic_tracepoint_arg+0x11d0>
    5c88:      	b	0x5c40 <generic_tracepoint_arg+0x11b0>
    5c8c:      	tbz	w8, #0x1f, 0x67c4 <generic_tracepoint_arg+0x1d34>
    5c90:      	ldr	w9, [x29, #0x8]
    5c94:      	add	w8, w23, #0xc
    5c98:      	cmp	w8, w9
    5c9c:      	b.hs	0x5cb0 <generic_tracepoint_arg+0x1220>
    5ca0:      	add	x19, x19, #0x1
    5ca4:      	add	w23, w23, #0x4
    5ca8:      	cmp	x19, #0x64
    5cac:      	b.ne	0x5c04 <generic_tracepoint_arg+0x1174>
    5cb0:      	mov	x23, xzr
    5cb4:      	ldr	x19, [sp, #0x30]
    5cb8:      	ldp	x16, x15, [sp, #0x40]
    5cbc:      	mov	w2, #0x5ea0             // =24224
    5cc0:      	mov	w12, #0x1               // =1
    5cc4:      	ldr	x17, [sp, #0x38]
    5cc8:      	ldr	w8, [x29, #0x4]
    5ccc:      	cmp	w8, #0x25
    5cd0:      	b.hi	0x4d24 <generic_tracepoint_arg+0x294>
    5cd4:      	mov	x9, #0x50               // =80
    5cd8:      	lsl	x8, x12, x8
    5cdc:      	movk	x9, #0xc00, lsl #16
    5ce0:      	movk	x9, #0x20, lsl #32
    5ce4:      	tst	x8, x9
    5ce8:      	b.ne	0x77b4 <generic_tracepoint_arg+0x2d24>
    5cec:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    5cf0:      	and	w8, w24, #0xffff
    5cf4:      	cmp	w8, #0x90
    5cf8:      	b.hi	0x6370 <generic_tracepoint_arg+0x18e0>
    5cfc:      	and	w8, w24, #0xff
    5d00:      	mov	w9, #0xab               // =171
    5d04:      	tst	w24, #0xffff
    5d08:      	mul	w8, w8, w9
    5d0c:      	mov	w9, #0x18               // =24
    5d10:      	lsr	w8, w8, #12
    5d14:      	msub	w8, w8, w9, w24
    5d18:      	b.eq	0x5d28 <generic_tracepoint_arg+0x1298>
    5d1c:      	tst	w8, #0xff
    5d20:      	mov	w11, w24
    5d24:      	b.eq	0x5d3c <generic_tracepoint_arg+0x12ac>
    5d28:      	sub	w8, w24, w8, uxtb
    5d2c:      	and	w9, w8, #0xffff
    5d30:      	add	w11, w8, #0x18
    5d34:      	cmp	w9, #0x78
    5d38:      	b.hi	0x6384 <generic_tracepoint_arg+0x18f4>
    5d3c:      	and	w8, w11, #0xff
    5d40:      	mov	w9, #0xab               // =171
    5d44:      	mul	w8, w8, w9
    5d48:      	lsr	w8, w8, #12
    5d4c:      	sub	w10, w8, #0x1
    5d50:      	b	0x6394 <generic_tracepoint_arg+0x1904>
    5d54:      	ldr	x19, [sp, #0x30]
    5d58:      	sub	w8, w8, #0x12
    5d5c:      	cmp	w8, #0x2
    5d60:      	b.hs	0x4d24 <generic_tracepoint_arg+0x294>
    5d64:      	ldrb	w8, [x29, #0x10]
    5d68:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    5d6c:      	add	x9, sp, #0xac
    5d70:      	add	x1, sp, #0xac
    5d74:      	str	w8, [sp, #0xac]
    5d78:      	mov	w8, #0x1                // =1
    5d7c:      	ldr	x0, [x0]
    5d80:      	blr	x8
    5d84:      	cbz	x0, 0x6274 <generic_tracepoint_arg+0x17e4>
    5d88:      	str	x24, [sp, #0x88]
    5d8c:      	mov	w8, #0x1                // =1
    5d90:      	add	x9, sp, #0x88
    5d94:      	b	0x6238 <generic_tracepoint_arg+0x17a8>
    5d98:      	cmp	w8, #0x21
    5d9c:      	b.eq	0x6570 <generic_tracepoint_arg+0x1ae0>
    5da0:      	cmp	w8, #0x22
    5da4:      	b.ne	0x778c <generic_tracepoint_arg+0x2cfc>
    5da8:      	mov	w19, #0x10              // =16
    5dac:      	ldr	w8, [x29, x19]
    5db0:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    5db4:      	add	x9, sp, #0x60
    5db8:      	add	x1, sp, #0x60
    5dbc:      	str	w8, [sp, #0x60]
    5dc0:      	mov	w8, #0x1                // =1
    5dc4:      	ldr	x0, [x0]
    5dc8:      	blr	x8
    5dcc:      	cbz	x0, 0x6f40 <generic_tracepoint_arg+0x24b0>
    5dd0:      	mov	x1, x0
    5dd4:      	mov	x0, x24
    5dd8:      	mov	x2, x22
    5ddc:      	bl	0x5ddc <generic_tracepoint_arg+0x134c>
    5de0:      	tbz	w0, #0x1f, 0x6f48 <generic_tracepoint_arg+0x24b8>
    5de4:      	ldr	w8, [x29, #0x8]
    5de8:      	add	x19, x19, #0x4
    5dec:      	mov	w12, #0x1               // =1
    5df0:      	mov	x23, xzr
    5df4:      	sub	w9, w19, #0x8
    5df8:      	cmp	w9, w8
    5dfc:      	b.hs	0x6f50 <generic_tracepoint_arg+0x24c0>
    5e00:      	ldp	x16, x15, [sp, #0x40]
    5e04:      	cmp	x19, #0x1a0
    5e08:      	mov	w2, #0x5ea0             // =24224
    5e0c:      	ldr	x17, [sp, #0x38]
    5e10:      	b.ne	0x5dac <generic_tracepoint_arg+0x131c>
    5e14:      	b	0x778c <generic_tracepoint_arg+0x2cfc>
    5e18:      	cmp	w8, #0x1
    5e1c:      	b.eq	0x6698 <generic_tracepoint_arg+0x1c08>
    5e20:      	cmp	w8, #0x2
    5e24:      	b.ne	0x66a4 <generic_tracepoint_arg+0x1c14>
    5e28:      	ldrb	w10, [x22]
    5e2c:      	cmp	w9, w10
    5e30:      	b.hi	0x4d28 <generic_tracepoint_arg+0x298>
    5e34:      	b	0x66a4 <generic_tracepoint_arg+0x1c14>
    5e38:      	cmp	w8, #0x1
    5e3c:      	b.eq	0x66d8 <generic_tracepoint_arg+0x1c48>
    5e40:      	cmp	w8, #0x2
    5e44:      	b.ne	0x66e4 <generic_tracepoint_arg+0x1c54>
    5e48:      	ldrh	w10, [x22]
    5e4c:      	cmp	w9, w10
    5e50:      	b.hi	0x4d28 <generic_tracepoint_arg+0x298>
    5e54:      	b	0x66e4 <generic_tracepoint_arg+0x1c54>
    5e58:      	ldrb	w8, [x29, #0x10]
    5e5c:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    5e60:      	add	x9, sp, #0x88
    5e64:      	add	x1, sp, #0x88
    5e68:      	str	w8, [sp, #0x88]
    5e6c:      	mov	w8, #0x1                // =1
    5e70:      	ldr	x0, [x0]
    5e74:      	blr	x8
    5e78:      	cbz	x0, 0x6274 <generic_tracepoint_arg+0x17e4>
    5e7c:      	ldrb	w8, [x22]
    5e80:      	add	x9, sp, #0x60
    5e84:      	add	x1, sp, #0x60
    5e88:      	str	x8, [sp, #0x60]
    5e8c:      	mov	w8, #0x1                // =1
    5e90:      	b	0x623c <generic_tracepoint_arg+0x17ac>
    5e94:      	ldrb	w8, [x29, #0x10]
    5e98:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    5e9c:      	add	x9, sp, #0x88
    5ea0:      	add	x1, sp, #0x88
    5ea4:      	str	w8, [sp, #0x88]
    5ea8:      	mov	w8, #0x1                // =1
    5eac:      	ldr	x0, [x0]
    5eb0:      	blr	x8
    5eb4:      	cbz	x0, 0x6274 <generic_tracepoint_arg+0x17e4>
    5eb8:      	ldrh	w8, [x22]
    5ebc:      	add	x9, sp, #0x60
    5ec0:      	add	x1, sp, #0x60
    5ec4:      	str	x8, [sp, #0x60]
    5ec8:      	mov	w8, #0x1                // =1
    5ecc:      	b	0x623c <generic_tracepoint_arg+0x17ac>
    5ed0:      	ldp	x16, x15, [sp, #0x40]
    5ed4:      	cmp	x0, #0x0
    5ed8:      	mov	w2, #0x5ea0             // =24224
    5edc:      	mov	w12, #0x1               // =1
    5ee0:      	cset	w8, eq
    5ee4:      	ldr	x17, [sp, #0x38]
    5ee8:      	mov	w23, w8
    5eec:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    5ef0:      	ldr	w8, [x29, #0x10]
    5ef4:      	str	wzr, [sp, #0x88]
    5ef8:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    5efc:      	add	x9, sp, #0x60
    5f00:      	add	x1, sp, #0x60
    5f04:      	str	w8, [sp, #0x60]
    5f08:      	mov	w8, #0x1                // =1
    5f0c:      	ldr	x0, [x0]
    5f10:      	blr	x8
    5f14:      	mov	x23, xzr
    5f18:      	cbz	w22, 0x777c <generic_tracepoint_arg+0x2cec>
    5f1c:      	cbz	x0, 0x777c <generic_tracepoint_arg+0x2cec>
    5f20:      	mov	x19, x0
    5f24:      	adrp	x0, 0x5000 <generic_tracepoint_arg+0x570>
    5f28:      	mov	w8, #0x1                // =1
    5f2c:      	ldr	x0, [x0]
    5f30:      	add	x9, sp, #0x88
    5f34:      	add	x1, sp, #0x88
    5f38:      	blr	x8
    5f3c:      	cbz	x0, 0x7778 <generic_tracepoint_arg+0x2ce8>
    5f40:      	cmp	w22, #0xff
    5f44:      	mov	w8, #0xff               // =255
    5f48:      	mov	x2, x24
    5f4c:      	csel	w1, w22, w8, lo
    5f50:      	mov	x8, x0
    5f54:      	mov	x22, x0
    5f58:      	lsl	w9, w1, #3
    5f5c:      	str	w9, [x8], #0x4
    5f60:      	mov	w9, #0x4                // =4
    5f64:      	mov	x0, x8
    5f68:      	blr	x9
    5f6c:      	mov	w8, #0x1                // =1
    5f70:      	mov	x0, x19
    5f74:      	mov	x1, x22
    5f78:      	b	0x7768 <generic_tracepoint_arg+0x2cd8>
    5f7c:      	cmp	w22, #0x1fe
    5f80:      	str	wzr, [sp, #0x88]
    5f84:      	b.ls	0x6634 <generic_tracepoint_arg+0x1ba4>
    5f88:      	mov	x23, xzr
    5f8c:      	b	0x778c <generic_tracepoint_arg+0x2cfc>
    5f90:      	cmp	w8, #0x1e
    5f94:      	b.ne	0x4b8c <generic_tracepoint_arg+0xfc>
    5f98:      	ldr	w8, [x29, #0x10]
    5f9c:      	and	x8, x8, #0x7
    5fa0:      	add	x9, x20, x8, lsl #2
    5fa4:      	ldr	w9, [x9, x2]
    5fa8:      	cbnz	w9, 0x4b8c <generic_tracepoint_arg+0xfc>
    5fac:      	add	x8, x20, x8, lsl #3
    5fb0:      	ldr	x9, [x22]
    5fb4:      	ldr	x8, [x8, #0x5e78]
    5fb8:      	and	x8, x8, #0x7ff
    5fbc:      	add	x8, x20, x8
    5fc0:      	ldr	x8, [x8, #0x90]
    5fc4:      	bics	xzr, x8, x9
    5fc8:      	cset	w23, ne
    5fcc:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    5fd0:      	ldr	x19, [sp, #0x30]
    5fd4:      	cmp	x24, #0x400
    5fd8:      	cset	w23, lo
    5fdc:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    5fe0:      	ldr	x19, [sp, #0x30]
    5fe4:      	cmp	x24, #0x3ff
    5fe8:      	cset	w23, hi
    5fec:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    5ff0:      	and	w8, w24, #0xffff
    5ff4:      	mov	w9, #0x1fe              // =510
    5ff8:      	cmp	w8, #0x100
    5ffc:      	mov	w8, #0x100              // =256
    6000:      	csel	w11, w9, w8, hi
    6004:      	and	w8, w11, #0xffff
    6008:      	cmp	w8, #0x100
    600c:      	mov	w8, #0x6                // =6
    6010:      	cinc	w10, w8, ne
    6014:      	add	x8, x29, #0x10
    6018:      	and	w9, w10, #0xf
    601c:      	ldr	w8, [x8, w9, uxtw #2]
    6020:      	cmn	w8, #0x1
    6024:      	b.eq	0x7348 <generic_tracepoint_arg+0x28b8>
    6028:      	str	w11, [sp, #0x10]
    602c:      	stp	w8, w10, [sp, #0x1c]
    6030:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0x1570>
    6034:      	mov	w8, #0x1                // =1
    6038:      	add	x23, sp, #0x88
    603c:      	add	x1, sp, #0x88
    6040:      	ldr	x0, [x0]
    6044:      	blr	x8
    6048:      	str	x0, [sp, #0x28]
    604c:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0x1570>
    6050:      	mov	w8, #0x1                // =1
    6054:      	add	x1, sp, #0x88
    6058:      	ldr	x0, [x0]
    605c:      	blr	x8
    6060:      	ldr	x9, [sp, #0x28]
    6064:      	mov	x23, xzr
    6068:      	cbz	x9, 0x734c <generic_tracepoint_arg+0x28bc>
    606c:      	ldp	x16, x15, [sp, #0x40]
    6070:      	mov	w2, #0x5ea0             // =24224
    6074:      	mov	w12, #0x1               // =1
    6078:      	ldr	x17, [sp, #0x38]
    607c:      	cbz	x0, 0x735c <generic_tracepoint_arg+0x28cc>
    6080:      	ldr	w23, [sp, #0x20]
    6084:      	mov	x8, x9
    6088:      	str	x0, [sp, #0x8]
    608c:      	add	x2, x22, #0x4
    6090:      	mov	x22, x9
    6094:      	mov	x0, x8
    6098:      	cmp	w23, #0x5
    609c:      	b.gt	0x6a5c <generic_tracepoint_arg+0x1fcc>
    60a0:      	strb	w24, [x0], #0x1
    60a4:      	mov	w8, #0x4                // =4
    60a8:      	mov	w1, w24
    60ac:      	blr	x8
    60b0:      	ldr	w8, [sp, #0x10]
    60b4:      	and	w8, w8, #0xffff
    60b8:      	cmp	w8, w24
    60bc:      	b.ls	0x6a98 <generic_tracepoint_arg+0x2008>
    60c0:      	add	x9, x22, x24
    60c4:      	sub	w8, w8, w24
    60c8:      	ldr	x2, [sp, #0x8]
    60cc:      	add	x0, x9, #0x1
    60d0:      	and	w1, w8, #0xfff
    60d4:      	mov	w8, #0x4                // =4
    60d8:      	b	0x6a94 <generic_tracepoint_arg+0x2004>
    60dc:      	ldr	w8, [x29, #0x14]
    60e0:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0x1570>
    60e4:      	add	x9, sp, #0xac
    60e8:      	add	x1, sp, #0xac
    60ec:      	str	w8, [sp, #0xac]
    60f0:      	mov	w8, #0x1                // =1
    60f4:      	mov	w23, w13
    60f8:      	mov	w22, w11
    60fc:      	ldr	x0, [x0]
    6100:      	blr	x8
    6104:      	cbz	x0, 0x69f0 <generic_tracepoint_arg+0x1f60>
    6108:      	mov	w8, #0x80               // =128
    610c:      	stp	w23, w19, [sp, #0x90]
    6110:      	add	x1, sp, #0x88
    6114:      	stp	w8, w22, [sp, #0x88]
    6118:      	lsr	x8, x19, #32
    611c:      	ldr	x19, [sp, #0x30]
    6120:      	str	w8, [sp, #0x98]
    6124:      	mov	w8, #0x1                // =1
    6128:      	blr	x8
    612c:      	ldr	w8, [x29, #0x4]
    6130:      	sub	w9, w8, #0x18
    6134:      	cmp	w9, #0x2
    6138:      	b.lo	0x6718 <generic_tracepoint_arg+0x1c88>
    613c:      	sub	w8, w8, #0xd
    6140:      	mov	w12, #0x1               // =1
    6144:      	cmp	w8, #0x1
    6148:      	b.hi	0x5368 <generic_tracepoint_arg+0x8d8>
    614c:      	cmp	x0, #0x0
    6150:      	cset	w8, ne
    6154:      	ldp	x16, x15, [sp, #0x40]
    6158:      	mov	w2, #0x5ea0             // =24224
    615c:      	mov	w23, w8
    6160:      	ldr	x17, [sp, #0x38]
    6164:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    6168:      	ldr	x19, [sp, #0x30]
    616c:      	mov	w8, wzr
    6170:      	mov	w23, wzr
    6174:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    6178:      	ldr	x8, [x22]
    617c:      	cmp	x11, x8
    6180:      	b.hi	0x618c <generic_tracepoint_arg+0x16fc>
    6184:      	cmp	x8, x10
    6188:      	b.ls	0x4d28 <generic_tracepoint_arg+0x298>
    618c:      	ldr	w10, [x29, #0x8]
    6190:      	cmp	w10, #0x19
    6194:      	b.lo	0x4b8c <generic_tracepoint_arg+0xfc>
    6198:      	ldp	x12, x11, [x29, #0x20]
    619c:      	cmp	w9, #0xc
    61a0:      	b.eq	0x61ac <generic_tracepoint_arg+0x171c>
    61a4:      	cmp	w9, #0xa
    61a8:      	b.ne	0x6808 <generic_tracepoint_arg+0x1d78>
    61ac:      	cmp	x12, x8
    61b0:      	mov	w12, #0x1               // =1
    61b4:      	b.gt	0x681c <generic_tracepoint_arg+0x1d8c>
    61b8:      	cmp	x8, x11
    61bc:      	b.le	0x4d28 <generic_tracepoint_arg+0x298>
    61c0:      	b	0x681c <generic_tracepoint_arg+0x1d8c>
    61c4:      	ldr	x10, [x22]
    61c8:      	cmp	x11, x10
    61cc:      	ccmp	x10, x8, #0x2, ls
    61d0:      	cset	w8, ls
    61d4:      	ldr	w11, [x29, #0x8]
    61d8:      	cmp	w11, #0x19
    61dc:      	b.lo	0x7164 <generic_tracepoint_arg+0x26d4>
    61e0:      	ldp	x13, x12, [x29, #0x20]
    61e4:      	cmp	w9, #0xc
    61e8:      	b.eq	0x61f4 <generic_tracepoint_arg+0x1764>
    61ec:      	cmp	w9, #0xa
    61f0:      	b.ne	0x67cc <generic_tracepoint_arg+0x1d3c>
    61f4:      	cmp	x13, x10
    61f8:      	ccmp	x10, x12, #0x0, le
    61fc:      	cset	w12, le
    6200:      	b	0x67d8 <generic_tracepoint_arg+0x1d48>
    6204:      	ldrh	w23, [x22, #0x26]
    6208:      	ldrb	w8, [x29, #0x10]
    620c:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0x1570>
    6210:      	add	x9, sp, #0xac
    6214:      	add	x1, sp, #0xac
    6218:      	str	w8, [sp, #0xac]
    621c:      	mov	w8, #0x1                // =1
    6220:      	ldr	x0, [x0]
    6224:      	blr	x8
    6228:      	cbz	x0, 0x6274 <generic_tracepoint_arg+0x17e4>
    622c:      	str	x23, [sp, #0x88]
    6230:      	mov	w8, #0x1                // =1
    6234:      	add	x9, sp, #0x88
    6238:      	add	x1, sp, #0x88
    623c:      	blr	x8
    6240:      	ldr	w9, [x29, #0x4]
    6244:      	mov	w8, wzr
    6248:      	mov	w12, #0x1               // =1
    624c:      	cmp	w9, #0x1d
    6250:      	b.hi	0x68f0 <generic_tracepoint_arg+0x1e60>
    6254:      	mov	w10, #0x8400            // =33792
    6258:      	lsl	w9, w12, w9
    625c:      	movk	w10, #0x3003, lsl #16
    6260:      	tst	w9, w10
    6264:      	b.eq	0x68d8 <generic_tracepoint_arg+0x1e48>
    6268:      	cmp	x0, #0x0
    626c:      	cset	w8, ne
    6270:      	b	0x68f0 <generic_tracepoint_arg+0x1e60>
    6274:      	mov	x23, xzr
    6278:      	mov	w12, #0x1               // =1
    627c:      	b	0x68f4 <generic_tracepoint_arg+0x1e64>
    6280:      	ldr	x11, [x22]
    6284:      	cmp	x11, x10
    6288:      	b.hi	0x4d28 <generic_tracepoint_arg+0x298>
    628c:      	b	0x629c <generic_tracepoint_arg+0x180c>
    6290:      	ldr	x11, [x22]
    6294:      	cmp	x11, x10
    6298:      	b.lo	0x4d28 <generic_tracepoint_arg+0x298>
    629c:      	ldr	w10, [x29, #0x8]
    62a0:      	cmp	w10, #0x11
    62a4:      	b.lo	0x781c <generic_tracepoint_arg+0x2d8c>
    62a8:      	ldr	x11, [x29, #0x18]
    62ac:      	cmp	w8, #0x2
    62b0:      	b.le	0x62d4 <generic_tracepoint_arg+0x1844>
    62b4:      	sub	w12, w8, #0x3
    62b8:      	cmp	w12, #0x2
    62bc:      	b.hs	0x6308 <generic_tracepoint_arg+0x1878>
    62c0:      	ldr	x12, [x22]
    62c4:      	cmp	x12, x11
    62c8:      	mov	w12, #0x1               // =1
    62cc:      	b.eq	0x4d1c <generic_tracepoint_arg+0x28c>
    62d0:      	b	0x6e1c <generic_tracepoint_arg+0x238c>
    62d4:      	cmp	w8, #0x1
    62d8:      	b.eq	0x6460 <generic_tracepoint_arg+0x19d0>
    62dc:      	cmp	w8, #0x2
    62e0:      	b.ne	0x6e1c <generic_tracepoint_arg+0x238c>
    62e4:      	cmp	w9, #0xc
    62e8:      	b.eq	0x62f4 <generic_tracepoint_arg+0x1864>
    62ec:      	cmp	w9, #0xa
    62f0:      	b.ne	0x6e0c <generic_tracepoint_arg+0x237c>
    62f4:      	ldr	x12, [x22]
    62f8:      	cmp	x12, x11
    62fc:      	mov	w12, #0x1               // =1
    6300:      	b.lt	0x4d28 <generic_tracepoint_arg+0x298>
    6304:      	b	0x6e1c <generic_tracepoint_arg+0x238c>
    6308:      	cmp	w8, #0xc
    630c:      	mov	w12, #0x1               // =1
    6310:      	b.ne	0x6e1c <generic_tracepoint_arg+0x238c>
    6314:      	ldr	x12, [x22]
    6318:      	tst	x12, x11
    631c:      	mov	w12, #0x1               // =1
    6320:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    6324:      	b	0x6e1c <generic_tracepoint_arg+0x238c>
    6328:      	mov	x23, xzr
    632c:      	ldr	x19, [sp, #0x30]
    6330:      	mov	w12, #0x1               // =1
    6334:      	ldp	x16, x15, [sp, #0x40]
    6338:      	mov	w2, #0x5ea0             // =24224
    633c:      	b	0x7358 <generic_tracepoint_arg+0x28c8>
    6340:      	cmp	w8, #0xc
    6344:      	b.ne	0x66a4 <generic_tracepoint_arg+0x1c14>
    6348:      	ldrb	w10, [x22]
    634c:      	tst	w9, w10
    6350:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    6354:      	b	0x66a4 <generic_tracepoint_arg+0x1c14>
    6358:      	cmp	w8, #0xc
    635c:      	b.ne	0x66e4 <generic_tracepoint_arg+0x1c54>
    6360:      	ldrh	w10, [x22]
    6364:      	tst	w9, w10
    6368:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    636c:      	b	0x66e4 <generic_tracepoint_arg+0x1c54>
    6370:      	and	w8, w24, #0xffff
    6374:      	mov	w9, #0x1fe              // =510
    6378:      	cmp	w8, #0x100
    637c:      	mov	w8, #0x100              // =256
    6380:      	csel	w11, w9, w8, hi
    6384:      	and	w8, w11, #0xffff
    6388:      	cmp	w8, #0x100
    638c:      	mov	w8, #0x6                // =6
    6390:      	cinc	w10, w8, ne
    6394:      	add	x8, x29, #0x10
    6398:      	and	w9, w10, #0xf
    639c:      	ldr	w8, [x8, w9, uxtw #2]
    63a0:      	cmn	w8, #0x1
    63a4:      	b.eq	0x71b8 <generic_tracepoint_arg+0x2728>
    63a8:      	str	w11, [sp, #0x10]
    63ac:      	str	w8, [sp, #0x1c]
    63b0:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0x1570>
    63b4:      	mov	w8, #0x1                // =1
    63b8:      	add	x23, sp, #0x88
    63bc:      	add	x1, sp, #0x88
    63c0:      	str	w10, [sp, #0x28]
    63c4:      	ldr	x0, [x0]
    63c8:      	blr	x8
    63cc:      	str	x0, [sp, #0x20]
    63d0:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0x1570>
    63d4:      	mov	w8, #0x1                // =1
    63d8:      	add	x1, sp, #0x88
    63dc:      	ldr	x0, [x0]
    63e0:      	blr	x8
    63e4:      	ldr	x9, [sp, #0x20]
    63e8:      	mov	x23, xzr
    63ec:      	cbz	x9, 0x5cb8 <generic_tracepoint_arg+0x1228>
    63f0:      	ldp	x16, x15, [sp, #0x40]
    63f4:      	mov	w2, #0x5ea0             // =24224
    63f8:      	mov	w12, #0x1               // =1
    63fc:      	ldr	x17, [sp, #0x38]
    6400:      	cbz	x0, 0x5cc8 <generic_tracepoint_arg+0x1238>
    6404:      	mov	x8, x9
    6408:      	ldr	w9, [sp, #0x28]
    640c:      	mov	x23, x0
    6410:      	cmp	w9, #0x5
    6414:      	b.gt	0x6cf8 <generic_tracepoint_arg+0x2268>
    6418:      	mov	x0, x8
    641c:      	mov	x9, x8
    6420:      	mov	w8, #0x4                // =4
    6424:      	mov	w1, w24
    6428:      	mov	x2, x22
    642c:      	strb	w24, [x0], #0x1
    6430:      	mov	x22, x9
    6434:      	blr	x8
    6438:      	ldr	w8, [sp, #0x10]
    643c:      	and	w8, w8, #0xffff
    6440:      	cmp	w8, w24
    6444:      	b.ls	0x6d44 <generic_tracepoint_arg+0x22b4>
    6448:      	add	x9, x22, x24
    644c:      	sub	w8, w8, w24
    6450:      	add	x0, x9, #0x1
    6454:      	and	w1, w8, #0xfff
    6458:      	mov	w8, #0x4                // =4
    645c:      	b	0x6d3c <generic_tracepoint_arg+0x22ac>
    6460:      	cmp	w9, #0xc
    6464:      	b.eq	0x6470 <generic_tracepoint_arg+0x19e0>
    6468:      	cmp	w9, #0xa
    646c:      	b.ne	0x6df8 <generic_tracepoint_arg+0x2368>
    6470:      	ldr	x12, [x22]
    6474:      	cmp	x12, x11
    6478:      	mov	w12, #0x1               // =1
    647c:      	b.gt	0x4d28 <generic_tracepoint_arg+0x298>
    6480:      	b	0x6e1c <generic_tracepoint_arg+0x238c>
    6484:      	ldr	w9, [x29, #0x8]
    6488:      	cmp	w9, #0xd
    648c:      	b.lo	0x51a8 <generic_tracepoint_arg+0x718>
    6490:      	ldr	w10, [x29, #0x14]
    6494:      	cbz	w10, 0x51a8 <generic_tracepoint_arg+0x718>
    6498:      	cmp	w10, w8
    649c:      	b.eq	0x4f04 <generic_tracepoint_arg+0x474>
    64a0:      	cmp	w9, #0x11
    64a4:      	b.lo	0x51a8 <generic_tracepoint_arg+0x718>
    64a8:      	ldr	w10, [x29, #0x18]
    64ac:      	cbz	w10, 0x51a8 <generic_tracepoint_arg+0x718>
    64b0:      	cmp	w10, w8
    64b4:      	b.eq	0x4f04 <generic_tracepoint_arg+0x474>
    64b8:      	cmp	w9, #0x15
    64bc:      	b.lo	0x64d4 <generic_tracepoint_arg+0x1a44>
    64c0:      	ldr	w9, [x29, #0x1c]
    64c4:      	cbz	w9, 0x64d4 <generic_tracepoint_arg+0x1a44>
    64c8:      	cmp	w9, w8
    64cc:      	cset	w23, eq
    64d0:      	b	0x64d8 <generic_tracepoint_arg+0x1a48>
    64d4:      	mov	x23, xzr
    64d8:      	ldr	x19, [sp, #0x30]
    64dc:      	b	0x734c <generic_tracepoint_arg+0x28bc>
    64e0:      	ldp	w8, w11, [x29, #0x10]
    64e4:      	ldrb	w9, [x22]
    64e8:      	cmp	w8, w9
    64ec:      	ldr	w10, [x29, #0x8]
    64f0:      	ccmp	w11, w9, #0x0, ls
    64f4:      	cset	w8, hs
    64f8:      	cmp	w10, #0x11
    64fc:      	b.lo	0x739c <generic_tracepoint_arg+0x290c>
    6500:      	b	0x6524 <generic_tracepoint_arg+0x1a94>
    6504:      	ldp	w8, w11, [x29, #0x10]
    6508:      	ldrh	w9, [x22]
    650c:      	cmp	w8, w9
    6510:      	ldr	w10, [x29, #0x8]
    6514:      	ccmp	w11, w9, #0x0, ls
    6518:      	cset	w8, hs
    651c:      	cmp	w10, #0x11
    6520:      	b.lo	0x739c <generic_tracepoint_arg+0x290c>
    6524:      	ldp	w11, w12, [x29, #0x18]
    6528:      	cmp	w11, w9
    652c:      	ccmp	w12, w9, #0x0, ls
    6530:      	mov	w12, #0x1               // =1
    6534:      	csinc	w8, w8, wzr, lo
    6538:      	cmp	w10, #0x19
    653c:      	b.lo	0x739c <generic_tracepoint_arg+0x290c>
    6540:      	ldp	w11, w12, [x29, #0x20]
    6544:      	cmp	w11, w9
    6548:      	ccmp	w12, w9, #0x0, ls
    654c:      	mov	w12, #0x1               // =1
    6550:      	csinc	w8, w8, wzr, lo
    6554:      	cmp	w10, #0x21
    6558:      	b.lo	0x739c <generic_tracepoint_arg+0x290c>
    655c:      	ldp	w10, w11, [x29, #0x28]
    6560:      	cmp	w10, w9
    6564:      	ccmp	w11, w9, #0x0, ls
    6568:      	csinc	w8, w8, wzr, lo
    656c:      	b	0x739c <generic_tracepoint_arg+0x290c>
    6570:      	mov	x19, xzr
    6574:      	mov	w23, wzr
    6578:      	add	x8, x29, #0x10
    657c:      	str	x8, [sp, #0x28]
    6580:      	ldr	x8, [sp, #0x28]
    6584:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0x1570>
    6588:      	add	x9, sp, #0x60
    658c:      	add	x1, sp, #0x60
    6590:      	ldr	w8, [x8, x19, lsl #2]
    6594:      	str	w8, [sp, #0x60]
    6598:      	mov	w8, #0x1                // =1
    659c:      	ldr	x0, [x0]
    65a0:      	blr	x8
    65a4:      	cbz	x0, 0x7778 <generic_tracepoint_arg+0x2ce8>
    65a8:      	cbz	w22, 0x6610 <generic_tracepoint_arg+0x1b80>
    65ac:      	mov	x8, xzr
    65b0:      	mov	x9, x24
    65b4:      	mov	x10, x22
    65b8:      	b	0x65d0 <generic_tracepoint_arg+0x1b40>
    65bc:      	add	x8, x8, #0x1
    65c0:      	sub	x10, x10, #0x1
    65c4:      	add	x9, x9, #0x1
    65c8:      	cmp	x8, x22
    65cc:      	b.eq	0x6610 <generic_tracepoint_arg+0x1b80>
    65d0:      	mov	x11, xzr
    65d4:      	nop
    65d8:      	nop
    65dc:      	nop
    65e0:      	cmp	x10, x11
    65e4:      	b.eq	0x65bc <generic_tracepoint_arg+0x1b2c>
    65e8:      	ldrb	w12, [x0, x11]
    65ec:      	cbz	w12, 0x660c <generic_tracepoint_arg+0x1b7c>
    65f0:      	cmp	x11, #0x62
    65f4:      	b.hi	0x65bc <generic_tracepoint_arg+0x1b2c>
    65f8:      	ldrb	w13, [x9, x11]
    65fc:      	add	x11, x11, #0x1
    6600:      	cmp	w13, w12
    6604:      	b.eq	0x65e0 <generic_tracepoint_arg+0x1b50>
    6608:      	b	0x65bc <generic_tracepoint_arg+0x1b2c>
    660c:      	tbz	w8, #0x1f, 0x722c <generic_tracepoint_arg+0x279c>
    6610:      	ldr	w9, [x29, #0x8]
    6614:      	add	w8, w23, #0xc
    6618:      	cmp	w8, w9
    661c:      	b.hs	0x7778 <generic_tracepoint_arg+0x2ce8>
    6620:      	add	x19, x19, #0x1
    6624:      	add	w23, w23, #0x4
    6628:      	cmp	x19, #0x64
    662c:      	b.ne	0x6580 <generic_tracepoint_arg+0x1af0>
    6630:      	b	0x7778 <generic_tracepoint_arg+0x2ce8>
    6634:      	and	w8, w22, #0xffff
    6638:      	cmp	w8, #0x90
    663c:      	b.hi	0x6b1c <generic_tracepoint_arg+0x208c>
    6640:      	and	w8, w22, #0xff
    6644:      	mov	w9, #0xab               // =171
    6648:      	tst	w22, #0xffff
    664c:      	mul	w8, w8, w9
    6650:      	mov	w9, #0x18               // =24
    6654:      	lsr	w8, w8, #12
    6658:      	msub	w8, w8, w9, w22
    665c:      	b.eq	0x666c <generic_tracepoint_arg+0x1bdc>
    6660:      	tst	w8, #0xff
    6664:      	mov	w11, w22
    6668:      	b.eq	0x6680 <generic_tracepoint_arg+0x1bf0>
    666c:      	sub	w8, w22, w8, uxtb
    6670:      	and	w9, w8, #0xffff
    6674:      	add	w11, w8, #0x18
    6678:      	cmp	w9, #0x78
    667c:      	b.hi	0x6b30 <generic_tracepoint_arg+0x20a0>
    6680:      	and	w8, w11, #0xff
    6684:      	mov	w9, #0xab               // =171
    6688:      	mul	w8, w8, w9
    668c:      	lsr	w8, w8, #12
    6690:      	sub	w10, w8, #0x1
    6694:      	b	0x6b40 <generic_tracepoint_arg+0x20b0>
    6698:      	ldrb	w10, [x22]
    669c:      	cmp	w9, w10
    66a0:      	b.lo	0x4d28 <generic_tracepoint_arg+0x298>
    66a4:      	ldr	w9, [x29, #0x8]
    66a8:      	cmp	w9, #0xd
    66ac:      	b.lo	0x781c <generic_tracepoint_arg+0x2d8c>
    66b0:      	ldr	w10, [x29, #0x14]
    66b4:      	cmp	w8, #0x2
    66b8:      	b.le	0x6a1c <generic_tracepoint_arg+0x1f8c>
    66bc:      	sub	w11, w8, #0x3
    66c0:      	cmp	w11, #0x2
    66c4:      	b.hs	0x6ea4 <generic_tracepoint_arg+0x2414>
    66c8:      	ldrb	w11, [x22]
    66cc:      	cmp	w10, w11
    66d0:      	b.eq	0x4d1c <generic_tracepoint_arg+0x28c>
    66d4:      	b	0x6f68 <generic_tracepoint_arg+0x24d8>
    66d8:      	ldrh	w10, [x22]
    66dc:      	cmp	w9, w10
    66e0:      	b.lo	0x4d28 <generic_tracepoint_arg+0x298>
    66e4:      	ldr	w9, [x29, #0x8]
    66e8:      	cmp	w9, #0xd
    66ec:      	b.lo	0x781c <generic_tracepoint_arg+0x2d8c>
    66f0:      	ldr	w10, [x29, #0x14]
    66f4:      	cmp	w8, #0x2
    66f8:      	b.le	0x6a3c <generic_tracepoint_arg+0x1fac>
    66fc:      	sub	w11, w8, #0x3
    6700:      	cmp	w11, #0x2
    6704:      	b.hs	0x6ebc <generic_tracepoint_arg+0x242c>
    6708:      	ldrh	w11, [x22]
    670c:      	cmp	w10, w11
    6710:      	b.eq	0x4d1c <generic_tracepoint_arg+0x28c>
    6714:      	b	0x6fa4 <generic_tracepoint_arg+0x2514>
    6718:      	cmp	x0, #0x0
    671c:      	b	0x6a00 <generic_tracepoint_arg+0x1f70>
    6720:      	ldr	w8, [x22]
    6724:      	cmp	w11, w8
    6728:      	b.hi	0x6734 <generic_tracepoint_arg+0x1ca4>
    672c:      	cmp	w8, w10
    6730:      	b.ls	0x4d28 <generic_tracepoint_arg+0x298>
    6734:      	ldr	w10, [x29, #0x8]
    6738:      	cmp	w10, #0x11
    673c:      	b.lo	0x4b8c <generic_tracepoint_arg+0xfc>
    6740:      	ldp	w12, w11, [x29, #0x18]
    6744:      	mov	w13, #0x1               // =1
    6748:      	cmp	w9, #0xc
    674c:      	b.hi	0x6c4c <generic_tracepoint_arg+0x21bc>
    6750:      	lsl	w13, w13, w9
    6754:      	mov	w14, #0x1402            // =5122
    6758:      	tst	w13, w14
    675c:      	b.eq	0x6c4c <generic_tracepoint_arg+0x21bc>
    6760:      	cmp	w12, w8
    6764:      	mov	w12, #0x1               // =1
    6768:      	b.gt	0x6c60 <generic_tracepoint_arg+0x21d0>
    676c:      	cmp	w8, w11
    6770:      	b.le	0x4d28 <generic_tracepoint_arg+0x298>
    6774:      	b	0x6c60 <generic_tracepoint_arg+0x21d0>
    6778:      	ldr	w10, [x22]
    677c:      	cmp	w11, w10
    6780:      	ccmp	w10, w8, #0x2, ls
    6784:      	cset	w8, ls
    6788:      	ldr	w11, [x29, #0x8]
    678c:      	cmp	w11, #0x11
    6790:      	b.lo	0x739c <generic_tracepoint_arg+0x290c>
    6794:      	ldp	w13, w12, [x29, #0x18]
    6798:      	mov	w14, #0x1               // =1
    679c:      	cmp	w9, #0xc
    67a0:      	b.hi	0x6c00 <generic_tracepoint_arg+0x2170>
    67a4:      	lsl	w14, w14, w9
    67a8:      	mov	w1, #0x1402             // =5122
    67ac:      	tst	w14, w1
    67b0:      	b.eq	0x6c00 <generic_tracepoint_arg+0x2170>
    67b4:      	cmp	w13, w10
    67b8:      	ccmp	w10, w12, #0x0, le
    67bc:      	cset	w12, le
    67c0:      	b	0x6c0c <generic_tracepoint_arg+0x217c>
    67c4:      	mov	w23, #0x1               // =1
    67c8:      	b	0x5cb4 <generic_tracepoint_arg+0x1224>
    67cc:      	cmp	x13, x10
    67d0:      	ccmp	x10, x12, #0x2, ls
    67d4:      	cset	w12, ls
    67d8:      	orr	w8, w8, w12
    67dc:      	cmp	w11, #0x29
    67e0:      	b.lo	0x7164 <generic_tracepoint_arg+0x26d4>
    67e4:      	ldp	x13, x12, [x29, #0x30]
    67e8:      	cmp	w9, #0xc
    67ec:      	b.eq	0x67f8 <generic_tracepoint_arg+0x1d68>
    67f0:      	cmp	w9, #0xa
    67f4:      	b.ne	0x6ca0 <generic_tracepoint_arg+0x2210>
    67f8:      	cmp	x13, x10
    67fc:      	ccmp	x10, x12, #0x0, le
    6800:      	cset	w12, le
    6804:      	b	0x6cac <generic_tracepoint_arg+0x221c>
    6808:      	cmp	x12, x8
    680c:      	mov	w12, #0x1               // =1
    6810:      	b.hi	0x681c <generic_tracepoint_arg+0x1d8c>
    6814:      	cmp	x8, x11
    6818:      	b.ls	0x4d28 <generic_tracepoint_arg+0x298>
    681c:      	cmp	w10, #0x29
    6820:      	b.lo	0x4b8c <generic_tracepoint_arg+0xfc>
    6824:      	ldp	x12, x11, [x29, #0x30]
    6828:      	cmp	w9, #0xc
    682c:      	b.eq	0x6838 <generic_tracepoint_arg+0x1da8>
    6830:      	cmp	w9, #0xa
    6834:      	b.ne	0x6db4 <generic_tracepoint_arg+0x2324>
    6838:      	cmp	x12, x8
    683c:      	mov	w12, #0x1               // =1
    6840:      	b.gt	0x6dc8 <generic_tracepoint_arg+0x2338>
    6844:      	cmp	x8, x11
    6848:      	b.le	0x4d28 <generic_tracepoint_arg+0x298>
    684c:      	b	0x6dc8 <generic_tracepoint_arg+0x2338>
    6850:      	mov	x19, xzr
    6854:      	cmp	w9, #0x29
    6858:      	b.ne	0x6864 <generic_tracepoint_arg+0x1dd4>
    685c:      	cbz	x10, 0x6864 <generic_tracepoint_arg+0x1dd4>
    6860:      	ldrb	w19, [x10, #0x3a]
    6864:      	cmp	w9, #0x29
    6868:      	b.eq	0x6874 <generic_tracepoint_arg+0x1de4>
    686c:      	cmp	w9, #0x7
    6870:      	b.ne	0x6cec <generic_tracepoint_arg+0x225c>
    6874:      	ldrb	w8, [x29, #0x10]
    6878:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0x1570>
    687c:      	add	x9, sp, #0xac
    6880:      	add	x1, sp, #0xac
    6884:      	str	w8, [sp, #0xac]
    6888:      	mov	w8, #0x1                // =1
    688c:      	ldr	x0, [x0]
    6890:      	blr	x8
    6894:      	cbz	x0, 0x6cdc <generic_tracepoint_arg+0x224c>
    6898:      	str	x19, [sp, #0x88]
    689c:      	mov	w8, #0x1                // =1
    68a0:      	add	x9, sp, #0x88
    68a4:      	add	x1, sp, #0x88
    68a8:      	blr	x8
    68ac:      	ldr	w9, [x29, #0x4]
    68b0:      	mov	w8, wzr
    68b4:      	cmp	w9, #0x1d
    68b8:      	b.hi	0x77c4 <generic_tracepoint_arg+0x2d34>
    68bc:      	ldr	x19, [sp, #0x30]
    68c0:      	mov	w12, #0x1               // =1
    68c4:      	mov	w10, #0x8400            // =33792
    68c8:      	lsl	w9, w12, w9
    68cc:      	movk	w10, #0x3003, lsl #16
    68d0:      	tst	w9, w10
    68d4:      	b.ne	0x6268 <generic_tracepoint_arg+0x17d8>
    68d8:      	mov	w10, #0x800             // =2048
    68dc:      	movk	w10, #0xc, lsl #16
    68e0:      	tst	w9, w10
    68e4:      	b.eq	0x68f0 <generic_tracepoint_arg+0x1e60>
    68e8:      	cmp	x0, #0x0
    68ec:      	cset	w8, eq
    68f0:      	mov	w23, w8
    68f4:      	ldp	x16, x15, [sp, #0x40]
    68f8:      	mov	w2, #0x5ea0             // =24224
    68fc:      	ldr	x17, [sp, #0x38]
    6900:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    6904:      	ldr	w11, [x22]
    6908:      	cmp	w11, w10
    690c:      	b.hi	0x4d28 <generic_tracepoint_arg+0x298>
    6910:      	b	0x6920 <generic_tracepoint_arg+0x1e90>
    6914:      	ldr	w11, [x22]
    6918:      	cmp	w11, w10
    691c:      	b.lo	0x4d28 <generic_tracepoint_arg+0x298>
    6920:      	ldr	w10, [x29, #0x8]
    6924:      	cmp	w10, #0xd
    6928:      	b.lo	0x781c <generic_tracepoint_arg+0x2d8c>
    692c:      	ldr	w11, [x29, #0x14]
    6930:      	cmp	w8, #0x2
    6934:      	b.le	0x6958 <generic_tracepoint_arg+0x1ec8>
    6938:      	sub	w12, w8, #0x3
    693c:      	cmp	w12, #0x2
    6940:      	b.hs	0x6998 <generic_tracepoint_arg+0x1f08>
    6944:      	ldr	w12, [x22]
    6948:      	cmp	w12, w11
    694c:      	mov	w12, #0x1               // =1
    6950:      	b.eq	0x4d1c <generic_tracepoint_arg+0x28c>
    6954:      	b	0x7090 <generic_tracepoint_arg+0x2600>
    6958:      	cmp	w8, #0x1
    695c:      	b.eq	0x69b8 <generic_tracepoint_arg+0x1f28>
    6960:      	cmp	w8, #0x2
    6964:      	b.ne	0x7090 <generic_tracepoint_arg+0x2600>
    6968:      	mov	w12, #0x1               // =1
    696c:      	cmp	w9, #0xc
    6970:      	b.hi	0x7080 <generic_tracepoint_arg+0x25f0>
    6974:      	lsl	w12, w12, w9
    6978:      	mov	w13, #0x1402            // =5122
    697c:      	tst	w12, w13
    6980:      	b.eq	0x7080 <generic_tracepoint_arg+0x25f0>
    6984:      	ldr	w12, [x22]
    6988:      	cmp	w12, w11
    698c:      	mov	w12, #0x1               // =1
    6990:      	b.lt	0x4d28 <generic_tracepoint_arg+0x298>
    6994:      	b	0x7090 <generic_tracepoint_arg+0x2600>
    6998:      	cmp	w8, #0xc
    699c:      	mov	w12, #0x1               // =1
    69a0:      	b.ne	0x7090 <generic_tracepoint_arg+0x2600>
    69a4:      	ldr	w12, [x22]
    69a8:      	tst	w12, w11
    69ac:      	mov	w12, #0x1               // =1
    69b0:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    69b4:      	b	0x7090 <generic_tracepoint_arg+0x2600>
    69b8:      	mov	w12, #0x1               // =1
    69bc:      	cmp	w9, #0xc
    69c0:      	b.hi	0x706c <generic_tracepoint_arg+0x25dc>
    69c4:      	lsl	w12, w12, w9
    69c8:      	mov	w13, #0x1402            // =5122
    69cc:      	tst	w12, w13
    69d0:      	b.eq	0x706c <generic_tracepoint_arg+0x25dc>
    69d4:      	ldr	w12, [x22]
    69d8:      	cmp	w12, w11
    69dc:      	mov	w12, #0x1               // =1
    69e0:      	b.gt	0x4d28 <generic_tracepoint_arg+0x298>
    69e4:      	b	0x7090 <generic_tracepoint_arg+0x2600>
    69e8:      	ldr	w8, [x29, #0x4]
    69ec:      	b	0x69f8 <generic_tracepoint_arg+0x1f68>
    69f0:      	ldr	w8, [x29, #0x4]
    69f4:      	ldr	x19, [sp, #0x30]
    69f8:      	and	w8, w8, #0xfffffffe
    69fc:      	cmp	w8, #0x18
    6a00:      	cset	w8, eq
    6a04:      	ldp	x16, x15, [sp, #0x40]
    6a08:      	mov	w2, #0x5ea0             // =24224
    6a0c:      	mov	w12, #0x1               // =1
    6a10:      	mov	w23, w8
    6a14:      	ldr	x17, [sp, #0x38]
    6a18:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    6a1c:      	cmp	w8, #0x1
    6a20:      	b.eq	0x6f5c <generic_tracepoint_arg+0x24cc>
    6a24:      	cmp	w8, #0x2
    6a28:      	b.ne	0x6f68 <generic_tracepoint_arg+0x24d8>
    6a2c:      	ldrb	w11, [x22]
    6a30:      	cmp	w10, w11
    6a34:      	b.hi	0x4d28 <generic_tracepoint_arg+0x298>
    6a38:      	b	0x6f68 <generic_tracepoint_arg+0x24d8>
    6a3c:      	cmp	w8, #0x1
    6a40:      	b.eq	0x6f98 <generic_tracepoint_arg+0x2508>
    6a44:      	cmp	w8, #0x2
    6a48:      	b.ne	0x6fa4 <generic_tracepoint_arg+0x2514>
    6a4c:      	ldrh	w11, [x22]
    6a50:      	cmp	w10, w11
    6a54:      	b.hi	0x4d28 <generic_tracepoint_arg+0x298>
    6a58:      	b	0x6fa4 <generic_tracepoint_arg+0x2514>
    6a5c:      	strh	w24, [x0], #0x2
    6a60:      	mov	w8, #0x4                // =4
    6a64:      	mov	w1, w24
    6a68:      	blr	x8
    6a6c:      	ldr	w8, [sp, #0x10]
    6a70:      	and	w8, w8, #0xffff
    6a74:      	cmp	w8, w24
    6a78:      	b.ls	0x6a98 <generic_tracepoint_arg+0x2008>
    6a7c:      	add	x9, x22, x24
    6a80:      	sub	w8, w8, w24
    6a84:      	ldr	x2, [sp, #0x8]
    6a88:      	add	x0, x9, #0x2
    6a8c:      	and	w1, w8, #0xfff
    6a90:      	mov	w8, #0x4                // =4
    6a94:      	blr	x8
    6a98:      	ldr	w8, [sp, #0x1c]
    6a9c:      	cmp	w23, #0x3
    6aa0:      	str	w8, [sp, #0x60]
    6aa4:      	b.gt	0x6ae0 <generic_tracepoint_arg+0x2050>
    6aa8:      	ldp	x16, x15, [sp, #0x40]
    6aac:      	cmp	w23, #0x1
    6ab0:      	mov	w2, #0x5ea0             // =24224
    6ab4:      	mov	w12, #0x1               // =1
    6ab8:      	ldr	x17, [sp, #0x38]
    6abc:      	b.gt	0x6ef8 <generic_tracepoint_arg+0x2468>
    6ac0:      	cbz	w23, 0x72d8 <generic_tracepoint_arg+0x2848>
    6ac4:      	cmp	w23, #0x1
    6ac8:      	b.ne	0x51a8 <generic_tracepoint_arg+0x718>
    6acc:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0x1570>
    6ad0:      	mov	w8, #0x1                // =1
    6ad4:      	add	x9, sp, #0x60
    6ad8:      	ldr	x0, [x0]
    6adc:      	b	0x7324 <generic_tracepoint_arg+0x2894>
    6ae0:      	ldp	x16, x15, [sp, #0x40]
    6ae4:      	cmp	w23, #0x5
    6ae8:      	mov	w2, #0x5ea0             // =24224
    6aec:      	mov	w12, #0x1               // =1
    6af0:      	ldr	x17, [sp, #0x38]
    6af4:      	b.gt	0x6f1c <generic_tracepoint_arg+0x248c>
    6af8:      	cmp	w23, #0x4
    6afc:      	b.eq	0x72ec <generic_tracepoint_arg+0x285c>
    6b00:      	cmp	w23, #0x5
    6b04:      	b.ne	0x51a8 <generic_tracepoint_arg+0x718>
    6b08:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0x1570>
    6b0c:      	mov	w8, #0x1                // =1
    6b10:      	add	x9, sp, #0x60
    6b14:      	ldr	x0, [x0]
    6b18:      	b	0x7324 <generic_tracepoint_arg+0x2894>
    6b1c:      	and	w8, w22, #0xffff
    6b20:      	mov	w9, #0x1fe              // =510
    6b24:      	cmp	w8, #0x100
    6b28:      	mov	w8, #0x100              // =256
    6b2c:      	csel	w11, w9, w8, hi
    6b30:      	and	w8, w11, #0xffff
    6b34:      	cmp	w8, #0x100
    6b38:      	mov	w8, #0x6                // =6
    6b3c:      	cinc	w10, w8, ne
    6b40:      	add	x8, x29, #0x10
    6b44:      	and	w9, w10, #0xf
    6b48:      	ldr	w8, [x8, w9, uxtw #2]
    6b4c:      	cmn	w8, #0x1
    6b50:      	b.eq	0x7778 <generic_tracepoint_arg+0x2ce8>
    6b54:      	stp	w11, w8, [sp, #0x1c]
    6b58:      	str	w10, [sp, #0x28]
    6b5c:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0x1570>
    6b60:      	mov	w8, #0x1                // =1
    6b64:      	add	x19, sp, #0x88
    6b68:      	add	x1, sp, #0x88
    6b6c:      	ldr	x0, [x0]
    6b70:      	blr	x8
    6b74:      	mov	x9, x0
    6b78:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0x1570>
    6b7c:      	mov	w8, #0x1                // =1
    6b80:      	ldr	x0, [x0]
    6b84:      	add	x1, sp, #0x88
    6b88:      	mov	x19, x9
    6b8c:      	blr	x8
    6b90:      	mov	x23, xzr
    6b94:      	cbz	x19, 0x777c <generic_tracepoint_arg+0x2cec>
    6b98:      	ldp	x16, x15, [sp, #0x40]
    6b9c:      	mov	w2, #0x5ea0             // =24224
    6ba0:      	mov	w12, #0x1               // =1
    6ba4:      	ldr	x17, [sp, #0x38]
    6ba8:      	cbz	x0, 0x778c <generic_tracepoint_arg+0x2cfc>
    6bac:      	ldr	w23, [sp, #0x28]
    6bb0:      	str	x0, [sp, #0x10]
    6bb4:      	mov	x0, x19
    6bb8:      	cmp	w23, #0x5
    6bbc:      	b.gt	0x7234 <generic_tracepoint_arg+0x27a4>
    6bc0:      	strb	w22, [x0], #0x1
    6bc4:      	mov	w8, #0x4                // =4
    6bc8:      	mov	w1, w22
    6bcc:      	mov	x2, x24
    6bd0:      	blr	x8
    6bd4:      	ldr	w8, [sp, #0x1c]
    6bd8:      	and	w8, w8, #0xffff
    6bdc:      	cmp	w8, w22
    6be0:      	b.ls	0x7274 <generic_tracepoint_arg+0x27e4>
    6be4:      	add	x9, x19, x22
    6be8:      	sub	w8, w8, w22
    6bec:      	ldr	x2, [sp, #0x10]
    6bf0:      	add	x0, x9, #0x1
    6bf4:      	and	w1, w8, #0xfff
    6bf8:      	mov	w8, #0x4                // =4
    6bfc:      	b	0x7270 <generic_tracepoint_arg+0x27e0>
    6c00:      	cmp	w13, w10
    6c04:      	ccmp	w10, w12, #0x2, ls
    6c08:      	cset	w12, ls
    6c0c:      	orr	w8, w8, w12
    6c10:      	cmp	w11, #0x19
    6c14:      	mov	w12, #0x1               // =1
    6c18:      	b.lo	0x739c <generic_tracepoint_arg+0x290c>
    6c1c:      	ldp	w13, w12, [x29, #0x20]
    6c20:      	mov	w14, #0x1               // =1
    6c24:      	cmp	w9, #0xc
    6c28:      	b.hi	0x6fd4 <generic_tracepoint_arg+0x2544>
    6c2c:      	lsl	w14, w14, w9
    6c30:      	mov	w1, #0x1402             // =5122
    6c34:      	tst	w14, w1
    6c38:      	b.eq	0x6fd4 <generic_tracepoint_arg+0x2544>
    6c3c:      	cmp	w13, w10
    6c40:      	ccmp	w10, w12, #0x0, le
    6c44:      	cset	w12, le
    6c48:      	b	0x6fe0 <generic_tracepoint_arg+0x2550>
    6c4c:      	cmp	w12, w8
    6c50:      	mov	w12, #0x1               // =1
    6c54:      	b.hi	0x6c60 <generic_tracepoint_arg+0x21d0>
    6c58:      	cmp	w8, w11
    6c5c:      	b.ls	0x4d28 <generic_tracepoint_arg+0x298>
    6c60:      	cmp	w10, #0x19
    6c64:      	b.lo	0x4b8c <generic_tracepoint_arg+0xfc>
    6c68:      	ldp	w12, w11, [x29, #0x20]
    6c6c:      	mov	w13, #0x1               // =1
    6c70:      	cmp	w9, #0xc
    6c74:      	b.hi	0x7020 <generic_tracepoint_arg+0x2590>
    6c78:      	lsl	w13, w13, w9
    6c7c:      	mov	w14, #0x1402            // =5122
    6c80:      	tst	w13, w14
    6c84:      	b.eq	0x7020 <generic_tracepoint_arg+0x2590>
    6c88:      	cmp	w12, w8
    6c8c:      	mov	w12, #0x1               // =1
    6c90:      	b.gt	0x7034 <generic_tracepoint_arg+0x25a4>
    6c94:      	cmp	w8, w11
    6c98:      	b.le	0x4d28 <generic_tracepoint_arg+0x298>
    6c9c:      	b	0x7034 <generic_tracepoint_arg+0x25a4>
    6ca0:      	cmp	x13, x10
    6ca4:      	ccmp	x10, x12, #0x2, ls
    6ca8:      	cset	w12, ls
    6cac:      	orr	w8, w8, w12
    6cb0:      	cmp	w11, #0x39
    6cb4:      	b.lo	0x7164 <generic_tracepoint_arg+0x26d4>
    6cb8:      	ldp	x12, x11, [x29, #0x40]
    6cbc:      	cmp	w9, #0xc
    6cc0:      	b.eq	0x6ccc <generic_tracepoint_arg+0x223c>
    6cc4:      	cmp	w9, #0xa
    6cc8:      	b.ne	0x7154 <generic_tracepoint_arg+0x26c4>
    6ccc:      	cmp	x12, x10
    6cd0:      	ccmp	x10, x11, #0x0, le
    6cd4:      	cset	w9, le
    6cd8:      	b	0x7160 <generic_tracepoint_arg+0x26d0>
    6cdc:      	ldr	x19, [sp, #0x30]
    6ce0:      	mov	x23, xzr
    6ce4:      	mov	w12, #0x1               // =1
    6ce8:      	b	0x68f4 <generic_tracepoint_arg+0x1e64>
    6cec:      	ldr	x19, [sp, #0x30]
    6cf0:      	mov	x23, xzr
    6cf4:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    6cf8:      	mov	x0, x8
    6cfc:      	mov	x9, x8
    6d00:      	mov	w8, #0x4                // =4
    6d04:      	mov	w1, w24
    6d08:      	mov	x2, x22
    6d0c:      	strh	w24, [x0], #0x2
    6d10:      	mov	x22, x9
    6d14:      	blr	x8
    6d18:      	ldr	w8, [sp, #0x10]
    6d1c:      	and	w8, w8, #0xffff
    6d20:      	cmp	w8, w24
    6d24:      	b.ls	0x6d44 <generic_tracepoint_arg+0x22b4>
    6d28:      	add	x9, x22, x24
    6d2c:      	sub	w8, w8, w24
    6d30:      	add	x0, x9, #0x2
    6d34:      	and	w1, w8, #0xfff
    6d38:      	mov	w8, #0x4                // =4
    6d3c:      	mov	x2, x23
    6d40:      	blr	x8
    6d44:      	ldr	w8, [sp, #0x1c]
    6d48:      	str	w8, [sp, #0x60]
    6d4c:      	ldr	w8, [sp, #0x28]
    6d50:      	cmp	w8, #0x3
    6d54:      	b.gt	0x6d84 <generic_tracepoint_arg+0x22f4>
    6d58:      	cmp	w8, #0x1
    6d5c:      	mov	w12, #0x1               // =1
    6d60:      	b.gt	0x7170 <generic_tracepoint_arg+0x26e0>
    6d64:      	cbz	w8, 0x74ac <generic_tracepoint_arg+0x2a1c>
    6d68:      	cmp	w8, #0x1
    6d6c:      	b.ne	0x71b8 <generic_tracepoint_arg+0x2728>
    6d70:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0x1570>
    6d74:      	mov	w8, #0x1                // =1
    6d78:      	add	x9, sp, #0x60
    6d7c:      	ldr	x0, [x0]
    6d80:      	b	0x74f8 <generic_tracepoint_arg+0x2a68>
    6d84:      	cmp	w8, #0x5
    6d88:      	mov	w12, #0x1               // =1
    6d8c:      	b.gt	0x7194 <generic_tracepoint_arg+0x2704>
    6d90:      	cmp	w8, #0x4
    6d94:      	b.eq	0x74c0 <generic_tracepoint_arg+0x2a30>
    6d98:      	cmp	w8, #0x5
    6d9c:      	b.ne	0x71b8 <generic_tracepoint_arg+0x2728>
    6da0:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0x1570>
    6da4:      	mov	w8, #0x1                // =1
    6da8:      	add	x9, sp, #0x60
    6dac:      	ldr	x0, [x0]
    6db0:      	b	0x74f8 <generic_tracepoint_arg+0x2a68>
    6db4:      	cmp	x12, x8
    6db8:      	mov	w12, #0x1               // =1
    6dbc:      	b.hi	0x6dc8 <generic_tracepoint_arg+0x2338>
    6dc0:      	cmp	x8, x11
    6dc4:      	b.ls	0x4d28 <generic_tracepoint_arg+0x298>
    6dc8:      	cmp	w10, #0x39
    6dcc:      	b.lo	0x4b8c <generic_tracepoint_arg+0xfc>
    6dd0:      	ldp	x11, x10, [x29, #0x40]
    6dd4:      	cmp	w9, #0xc
    6dd8:      	b.eq	0x6de4 <generic_tracepoint_arg+0x2354>
    6ddc:      	cmp	w9, #0xa
    6de0:      	b.ne	0x71d8 <generic_tracepoint_arg+0x2748>
    6de4:      	cmp	x11, x8
    6de8:      	b.gt	0x4b8c <generic_tracepoint_arg+0xfc>
    6dec:      	cmp	x8, x10
    6df0:      	b.le	0x4d28 <generic_tracepoint_arg+0x298>
    6df4:      	b	0x4b8c <generic_tracepoint_arg+0xfc>
    6df8:      	ldr	x12, [x22]
    6dfc:      	cmp	x12, x11
    6e00:      	mov	w12, #0x1               // =1
    6e04:      	b.hi	0x4d28 <generic_tracepoint_arg+0x298>
    6e08:      	b	0x6e1c <generic_tracepoint_arg+0x238c>
    6e0c:      	ldr	x12, [x22]
    6e10:      	cmp	x12, x11
    6e14:      	mov	w12, #0x1               // =1
    6e18:      	b.lo	0x4d28 <generic_tracepoint_arg+0x298>
    6e1c:      	cmp	w10, #0x19
    6e20:      	b.lo	0x781c <generic_tracepoint_arg+0x2d8c>
    6e24:      	ldr	x11, [x29, #0x20]
    6e28:      	cmp	w8, #0x2
    6e2c:      	b.le	0x6e50 <generic_tracepoint_arg+0x23c0>
    6e30:      	sub	w12, w8, #0x3
    6e34:      	cmp	w12, #0x2
    6e38:      	b.hs	0x6e84 <generic_tracepoint_arg+0x23f4>
    6e3c:      	ldr	x12, [x22]
    6e40:      	cmp	x12, x11
    6e44:      	mov	w12, #0x1               // =1
    6e48:      	b.eq	0x4d1c <generic_tracepoint_arg+0x28c>
    6e4c:      	b	0x73c8 <generic_tracepoint_arg+0x2938>
    6e50:      	cmp	w8, #0x1
    6e54:      	b.eq	0x6ed4 <generic_tracepoint_arg+0x2444>
    6e58:      	cmp	w8, #0x2
    6e5c:      	b.ne	0x73c8 <generic_tracepoint_arg+0x2938>
    6e60:      	cmp	w9, #0xc
    6e64:      	b.eq	0x6e70 <generic_tracepoint_arg+0x23e0>
    6e68:      	cmp	w9, #0xa
    6e6c:      	b.ne	0x73b8 <generic_tracepoint_arg+0x2928>
    6e70:      	ldr	x12, [x22]
    6e74:      	cmp	x12, x11
    6e78:      	mov	w12, #0x1               // =1
    6e7c:      	b.lt	0x4d28 <generic_tracepoint_arg+0x298>
    6e80:      	b	0x73c8 <generic_tracepoint_arg+0x2938>
    6e84:      	cmp	w8, #0xc
    6e88:      	mov	w12, #0x1               // =1
    6e8c:      	b.ne	0x73c8 <generic_tracepoint_arg+0x2938>
    6e90:      	ldr	x12, [x22]
    6e94:      	tst	x12, x11
    6e98:      	mov	w12, #0x1               // =1
    6e9c:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    6ea0:      	b	0x73c8 <generic_tracepoint_arg+0x2938>
    6ea4:      	cmp	w8, #0xc
    6ea8:      	b.ne	0x6f68 <generic_tracepoint_arg+0x24d8>
    6eac:      	ldrb	w11, [x22]
    6eb0:      	tst	w10, w11
    6eb4:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    6eb8:      	b	0x6f68 <generic_tracepoint_arg+0x24d8>
    6ebc:      	cmp	w8, #0xc
    6ec0:      	b.ne	0x6fa4 <generic_tracepoint_arg+0x2514>
    6ec4:      	ldrh	w11, [x22]
    6ec8:      	tst	w10, w11
    6ecc:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    6ed0:      	b	0x6fa4 <generic_tracepoint_arg+0x2514>
    6ed4:      	cmp	w9, #0xc
    6ed8:      	b.eq	0x6ee4 <generic_tracepoint_arg+0x2454>
    6edc:      	cmp	w9, #0xa
    6ee0:      	b.ne	0x73a4 <generic_tracepoint_arg+0x2914>
    6ee4:      	ldr	x12, [x22]
    6ee8:      	cmp	x12, x11
    6eec:      	mov	w12, #0x1               // =1
    6ef0:      	b.gt	0x4d28 <generic_tracepoint_arg+0x298>
    6ef4:      	b	0x73c8 <generic_tracepoint_arg+0x2938>
    6ef8:      	cmp	w23, #0x2
    6efc:      	b.eq	0x7300 <generic_tracepoint_arg+0x2870>
    6f00:      	cmp	w23, #0x3
    6f04:      	b.ne	0x51a8 <generic_tracepoint_arg+0x718>
    6f08:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0x1570>
    6f0c:      	mov	w8, #0x1                // =1
    6f10:      	add	x9, sp, #0x60
    6f14:      	ldr	x0, [x0]
    6f18:      	b	0x7324 <generic_tracepoint_arg+0x2894>
    6f1c:      	cmp	w23, #0x6
    6f20:      	b.eq	0x7314 <generic_tracepoint_arg+0x2884>
    6f24:      	cmp	w23, #0x7
    6f28:      	b.ne	0x51a8 <generic_tracepoint_arg+0x718>
    6f2c:      	adrp	x0, 0x6000 <generic_tracepoint_arg+0x1570>
    6f30:      	mov	w8, #0x1                // =1
    6f34:      	add	x9, sp, #0x60
    6f38:      	ldr	x0, [x0]
    6f3c:      	b	0x7324 <generic_tracepoint_arg+0x2894>
    6f40:      	mov	x23, xzr
    6f44:      	b	0x6f4c <generic_tracepoint_arg+0x24bc>
    6f48:      	mov	w23, #0x1               // =1
    6f4c:      	mov	w12, #0x1               // =1
    6f50:      	ldp	x16, x15, [sp, #0x40]
    6f54:      	mov	w2, #0x5ea0             // =24224
    6f58:      	b	0x7788 <generic_tracepoint_arg+0x2cf8>
    6f5c:      	ldrb	w11, [x22]
    6f60:      	cmp	w10, w11
    6f64:      	b.lo	0x4d28 <generic_tracepoint_arg+0x298>
    6f68:      	cmp	w9, #0x11
    6f6c:      	b.lo	0x781c <generic_tracepoint_arg+0x2d8c>
    6f70:      	ldr	w10, [x29, #0x18]
    6f74:      	cmp	w8, #0x2
    6f78:      	b.le	0x71ec <generic_tracepoint_arg+0x275c>
    6f7c:      	sub	w11, w8, #0x3
    6f80:      	cmp	w11, #0x2
    6f84:      	b.hs	0x7448 <generic_tracepoint_arg+0x29b8>
    6f88:      	ldrb	w11, [x22]
    6f8c:      	cmp	w10, w11
    6f90:      	b.eq	0x4d1c <generic_tracepoint_arg+0x28c>
    6f94:      	b	0x7578 <generic_tracepoint_arg+0x2ae8>
    6f98:      	ldrh	w11, [x22]
    6f9c:      	cmp	w10, w11
    6fa0:      	b.lo	0x4d28 <generic_tracepoint_arg+0x298>
    6fa4:      	cmp	w9, #0x11
    6fa8:      	b.lo	0x781c <generic_tracepoint_arg+0x2d8c>
    6fac:      	ldr	w10, [x29, #0x18]
    6fb0:      	cmp	w8, #0x2
    6fb4:      	b.le	0x720c <generic_tracepoint_arg+0x277c>
    6fb8:      	sub	w11, w8, #0x3
    6fbc:      	cmp	w11, #0x2
    6fc0:      	b.hs	0x7460 <generic_tracepoint_arg+0x29d0>
    6fc4:      	ldrh	w11, [x22]
    6fc8:      	cmp	w10, w11
    6fcc:      	b.eq	0x4d1c <generic_tracepoint_arg+0x28c>
    6fd0:      	b	0x75bc <generic_tracepoint_arg+0x2b2c>
    6fd4:      	cmp	w13, w10
    6fd8:      	ccmp	w10, w12, #0x2, ls
    6fdc:      	cset	w12, ls
    6fe0:      	orr	w8, w8, w12
    6fe4:      	cmp	w11, #0x21
    6fe8:      	mov	w12, #0x1               // =1
    6fec:      	b.lo	0x739c <generic_tracepoint_arg+0x290c>
    6ff0:      	ldp	w12, w11, [x29, #0x28]
    6ff4:      	mov	w13, #0x1               // =1
    6ff8:      	cmp	w9, #0xc
    6ffc:      	b.hi	0x7388 <generic_tracepoint_arg+0x28f8>
    7000:      	lsl	w9, w13, w9
    7004:      	mov	w13, #0x1402            // =5122
    7008:      	tst	w9, w13
    700c:      	b.eq	0x7388 <generic_tracepoint_arg+0x28f8>
    7010:      	cmp	w12, w10
    7014:      	ccmp	w10, w11, #0x0, le
    7018:      	cset	w9, le
    701c:      	b	0x7394 <generic_tracepoint_arg+0x2904>
    7020:      	cmp	w12, w8
    7024:      	mov	w12, #0x1               // =1
    7028:      	b.hi	0x7034 <generic_tracepoint_arg+0x25a4>
    702c:      	cmp	w8, w11
    7030:      	b.ls	0x4d28 <generic_tracepoint_arg+0x298>
    7034:      	cmp	w10, #0x21
    7038:      	b.lo	0x4b8c <generic_tracepoint_arg+0xfc>
    703c:      	ldp	w11, w10, [x29, #0x28]
    7040:      	cmp	w9, #0xc
    7044:      	b.hi	0x7478 <generic_tracepoint_arg+0x29e8>
    7048:      	lsl	w9, w12, w9
    704c:      	mov	w13, #0x1402            // =5122
    7050:      	tst	w9, w13
    7054:      	b.eq	0x7478 <generic_tracepoint_arg+0x29e8>
    7058:      	cmp	w11, w8
    705c:      	b.gt	0x4b8c <generic_tracepoint_arg+0xfc>
    7060:      	cmp	w8, w10
    7064:      	b.le	0x4d28 <generic_tracepoint_arg+0x298>
    7068:      	b	0x4b8c <generic_tracepoint_arg+0xfc>
    706c:      	ldr	w12, [x22]
    7070:      	cmp	w12, w11
    7074:      	mov	w12, #0x1               // =1
    7078:      	b.hi	0x4d28 <generic_tracepoint_arg+0x298>
    707c:      	b	0x7090 <generic_tracepoint_arg+0x2600>
    7080:      	ldr	w12, [x22]
    7084:      	cmp	w12, w11
    7088:      	mov	w12, #0x1               // =1
    708c:      	b.lo	0x4d28 <generic_tracepoint_arg+0x298>
    7090:      	cmp	w10, #0x11
    7094:      	b.lo	0x781c <generic_tracepoint_arg+0x2d8c>
    7098:      	ldr	w11, [x29, #0x18]
    709c:      	cmp	w8, #0x2
    70a0:      	b.le	0x70c4 <generic_tracepoint_arg+0x2634>
    70a4:      	sub	w12, w8, #0x3
    70a8:      	cmp	w12, #0x2
    70ac:      	b.hs	0x7104 <generic_tracepoint_arg+0x2674>
    70b0:      	ldr	w12, [x22]
    70b4:      	cmp	w12, w11
    70b8:      	mov	w12, #0x1               // =1
    70bc:      	b.eq	0x4d1c <generic_tracepoint_arg+0x28c>
    70c0:      	b	0x7618 <generic_tracepoint_arg+0x2b88>
    70c4:      	cmp	w8, #0x1
    70c8:      	b.eq	0x7124 <generic_tracepoint_arg+0x2694>
    70cc:      	cmp	w8, #0x2
    70d0:      	b.ne	0x7618 <generic_tracepoint_arg+0x2b88>
    70d4:      	mov	w12, #0x1               // =1
    70d8:      	cmp	w9, #0xc
    70dc:      	b.hi	0x7608 <generic_tracepoint_arg+0x2b78>
    70e0:      	lsl	w12, w12, w9
    70e4:      	mov	w13, #0x1402            // =5122
    70e8:      	tst	w12, w13
    70ec:      	b.eq	0x7608 <generic_tracepoint_arg+0x2b78>
    70f0:      	ldr	w12, [x22]
    70f4:      	cmp	w12, w11
    70f8:      	mov	w12, #0x1               // =1
    70fc:      	b.lt	0x4d28 <generic_tracepoint_arg+0x298>
    7100:      	b	0x7618 <generic_tracepoint_arg+0x2b88>
    7104:      	cmp	w8, #0xc
    7108:      	mov	w12, #0x1               // =1
    710c:      	b.ne	0x7618 <generic_tracepoint_arg+0x2b88>
    7110:      	ldr	w12, [x22]
    7114:      	tst	w12, w11
    7118:      	mov	w12, #0x1               // =1
    711c:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    7120:      	b	0x7618 <generic_tracepoint_arg+0x2b88>
    7124:      	mov	w12, #0x1               // =1
    7128:      	cmp	w9, #0xc
    712c:      	b.hi	0x75f4 <generic_tracepoint_arg+0x2b64>
    7130:      	lsl	w12, w12, w9
    7134:      	mov	w13, #0x1402            // =5122
    7138:      	tst	w12, w13
    713c:      	b.eq	0x75f4 <generic_tracepoint_arg+0x2b64>
    7140:      	ldr	w12, [x22]
    7144:      	cmp	w12, w11
    7148:      	mov	w12, #0x1               // =1
    714c:      	b.gt	0x4d28 <generic_tracepoint_arg+0x298>
    7150:      	b	0x7618 <generic_tracepoint_arg+0x2b88>
    7154:      	cmp	x12, x10
    7158:      	ccmp	x10, x11, #0x2, ls
    715c:      	cset	w9, ls
    7160:      	orr	w8, w8, w9
    7164:      	mov	w12, #0x1               // =1
    7168:      	tbz	w8, #0x0, 0x4d28 <generic_tracepoint_arg+0x298>
    716c:      	b	0x4b8c <generic_tracepoint_arg+0xfc>
    7170:      	cmp	w8, #0x2
    7174:      	b.eq	0x74d4 <generic_tracepoint_arg+0x2a44>
    7178:      	cmp	w8, #0x3
    717c:      	b.ne	0x71b8 <generic_tracepoint_arg+0x2728>
    7180:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    7184:      	mov	w8, #0x1                // =1
    7188:      	add	x9, sp, #0x60
    718c:      	ldr	x0, [x0]
    7190:      	b	0x74f8 <generic_tracepoint_arg+0x2a68>
    7194:      	cmp	w8, #0x6
    7198:      	b.eq	0x74e8 <generic_tracepoint_arg+0x2a58>
    719c:      	cmp	w8, #0x7
    71a0:      	b.ne	0x71b8 <generic_tracepoint_arg+0x2728>
    71a4:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    71a8:      	mov	w8, #0x1                // =1
    71ac:      	add	x9, sp, #0x60
    71b0:      	ldr	x0, [x0]
    71b4:      	b	0x74f8 <generic_tracepoint_arg+0x2a68>
    71b8:      	ldp	x16, x15, [sp, #0x40]
    71bc:      	mov	x23, xzr
    71c0:      	mov	w2, #0x5ea0             // =24224
    71c4:      	ldr	x17, [sp, #0x38]
    71c8:      	ldr	w8, [x29, #0x4]
    71cc:      	cmp	w8, #0x25
    71d0:      	b.ls	0x5cd4 <generic_tracepoint_arg+0x1244>
    71d4:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    71d8:      	cmp	x11, x8
    71dc:      	b.hi	0x4b8c <generic_tracepoint_arg+0xfc>
    71e0:      	cmp	x8, x10
    71e4:      	b.ls	0x4d28 <generic_tracepoint_arg+0x298>
    71e8:      	b	0x4b8c <generic_tracepoint_arg+0xfc>
    71ec:      	cmp	w8, #0x1
    71f0:      	b.eq	0x756c <generic_tracepoint_arg+0x2adc>
    71f4:      	cmp	w8, #0x2
    71f8:      	b.ne	0x7578 <generic_tracepoint_arg+0x2ae8>
    71fc:      	ldrb	w11, [x22]
    7200:      	cmp	w10, w11
    7204:      	b.hi	0x4d28 <generic_tracepoint_arg+0x298>
    7208:      	b	0x7578 <generic_tracepoint_arg+0x2ae8>
    720c:      	cmp	w8, #0x1
    7210:      	b.eq	0x75b0 <generic_tracepoint_arg+0x2b20>
    7214:      	cmp	w8, #0x2
    7218:      	b.ne	0x75bc <generic_tracepoint_arg+0x2b2c>
    721c:      	ldrh	w11, [x22]
    7220:      	cmp	w10, w11
    7224:      	b.hi	0x4d28 <generic_tracepoint_arg+0x298>
    7228:      	b	0x75bc <generic_tracepoint_arg+0x2b2c>
    722c:      	mov	w23, #0x1               // =1
    7230:      	b	0x777c <generic_tracepoint_arg+0x2cec>
    7234:      	strh	w22, [x0], #0x2
    7238:      	mov	w8, #0x4                // =4
    723c:      	mov	w1, w22
    7240:      	mov	x2, x24
    7244:      	blr	x8
    7248:      	ldr	w8, [sp, #0x1c]
    724c:      	and	w8, w8, #0xffff
    7250:      	cmp	w8, w22
    7254:      	b.ls	0x7274 <generic_tracepoint_arg+0x27e4>
    7258:      	add	x9, x19, x22
    725c:      	sub	w8, w8, w22
    7260:      	ldr	x2, [sp, #0x10]
    7264:      	add	x0, x9, #0x2
    7268:      	and	w1, w8, #0xfff
    726c:      	mov	w8, #0x4                // =4
    7270:      	blr	x8
    7274:      	ldr	w8, [sp, #0x20]
    7278:      	cmp	w23, #0x3
    727c:      	str	w8, [sp, #0x60]
    7280:      	b.gt	0x72ac <generic_tracepoint_arg+0x281c>
    7284:      	cmp	w23, #0x1
    7288:      	b.gt	0x7524 <generic_tracepoint_arg+0x2a94>
    728c:      	cbz	w23, 0x7708 <generic_tracepoint_arg+0x2c78>
    7290:      	cmp	w23, #0x1
    7294:      	b.ne	0x7778 <generic_tracepoint_arg+0x2ce8>
    7298:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    729c:      	mov	w8, #0x1                // =1
    72a0:      	add	x9, sp, #0x60
    72a4:      	ldr	x0, [x0]
    72a8:      	b	0x7754 <generic_tracepoint_arg+0x2cc4>
    72ac:      	cmp	w23, #0x5
    72b0:      	b.gt	0x7548 <generic_tracepoint_arg+0x2ab8>
    72b4:      	cmp	w23, #0x4
    72b8:      	b.eq	0x771c <generic_tracepoint_arg+0x2c8c>
    72bc:      	cmp	w23, #0x5
    72c0:      	b.ne	0x7778 <generic_tracepoint_arg+0x2ce8>
    72c4:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    72c8:      	mov	w8, #0x1                // =1
    72cc:      	add	x9, sp, #0x60
    72d0:      	ldr	x0, [x0]
    72d4:      	b	0x7754 <generic_tracepoint_arg+0x2cc4>
    72d8:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    72dc:      	mov	w8, #0x1                // =1
    72e0:      	add	x9, sp, #0x60
    72e4:      	ldr	x0, [x0]
    72e8:      	b	0x7324 <generic_tracepoint_arg+0x2894>
    72ec:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    72f0:      	mov	w8, #0x1                // =1
    72f4:      	add	x9, sp, #0x60
    72f8:      	ldr	x0, [x0]
    72fc:      	b	0x7324 <generic_tracepoint_arg+0x2894>
    7300:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    7304:      	mov	w8, #0x1                // =1
    7308:      	add	x9, sp, #0x60
    730c:      	ldr	x0, [x0]
    7310:      	b	0x7324 <generic_tracepoint_arg+0x2894>
    7314:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    7318:      	mov	w8, #0x1                // =1
    731c:      	add	x9, sp, #0x60
    7320:      	ldr	x0, [x0]
    7324:      	add	x1, sp, #0x60
    7328:      	blr	x8
    732c:      	cbz	x0, 0x7348 <generic_tracepoint_arg+0x28b8>
    7330:      	mov	w8, #0x1                // =1
    7334:      	mov	x1, x22
    7338:      	blr	x8
    733c:      	cmp	x0, #0x0
    7340:      	cset	w23, ne
    7344:      	b	0x734c <generic_tracepoint_arg+0x28bc>
    7348:      	mov	x23, xzr
    734c:      	ldp	x16, x15, [sp, #0x40]
    7350:      	mov	w2, #0x5ea0             // =24224
    7354:      	mov	w12, #0x1               // =1
    7358:      	ldr	x17, [sp, #0x38]
    735c:      	ldr	w8, [x29, #0x4]
    7360:      	cmp	w8, #0x25
    7364:      	b.hi	0x4d24 <generic_tracepoint_arg+0x294>
    7368:      	mov	x9, #0x50               // =80
    736c:      	lsl	x8, x12, x8
    7370:      	movk	x9, #0xc00, lsl #16
    7374:      	movk	x9, #0x20, lsl #32
    7378:      	tst	x8, x9
    737c:      	b.eq	0x4d24 <generic_tracepoint_arg+0x294>
    7380:      	eor	x23, x23, #0x1
    7384:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    7388:      	cmp	w12, w10
    738c:      	ccmp	w10, w11, #0x2, ls
    7390:      	cset	w9, ls
    7394:      	orr	w8, w8, w9
    7398:      	mov	w12, #0x1               // =1
    739c:      	tbz	w8, #0x0, 0x4d28 <generic_tracepoint_arg+0x298>
    73a0:      	b	0x4b8c <generic_tracepoint_arg+0xfc>
    73a4:      	ldr	x12, [x22]
    73a8:      	cmp	x12, x11
    73ac:      	mov	w12, #0x1               // =1
    73b0:      	b.hi	0x4d28 <generic_tracepoint_arg+0x298>
    73b4:      	b	0x73c8 <generic_tracepoint_arg+0x2938>
    73b8:      	ldr	x12, [x22]
    73bc:      	cmp	x12, x11
    73c0:      	mov	w12, #0x1               // =1
    73c4:      	b.lo	0x4d28 <generic_tracepoint_arg+0x298>
    73c8:      	cmp	w10, #0x21
    73cc:      	b.lo	0x781c <generic_tracepoint_arg+0x2d8c>
    73d0:      	ldr	x10, [x29, #0x28]
    73d4:      	cmp	w8, #0x2
    73d8:      	b.le	0x7408 <generic_tracepoint_arg+0x2978>
    73dc:      	sub	w9, w8, #0x3
    73e0:      	cmp	w9, #0x2
    73e4:      	b.lo	0x7438 <generic_tracepoint_arg+0x29a8>
    73e8:      	cmp	w8, #0x6
    73ec:      	b.eq	0x4d28 <generic_tracepoint_arg+0x298>
    73f0:      	cmp	w8, #0xc
    73f4:      	b.ne	0x4b8c <generic_tracepoint_arg+0xfc>
    73f8:      	ldr	x9, [x22]
    73fc:      	tst	x9, x10
    7400:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    7404:      	b	0x781c <generic_tracepoint_arg+0x2d8c>
    7408:      	cmp	w8, #0x1
    740c:      	b.eq	0x748c <generic_tracepoint_arg+0x29fc>
    7410:      	cmp	w8, #0x2
    7414:      	b.ne	0x4b8c <generic_tracepoint_arg+0xfc>
    7418:      	cmp	w9, #0xc
    741c:      	b.eq	0x7428 <generic_tracepoint_arg+0x2998>
    7420:      	cmp	w9, #0xa
    7424:      	b.ne	0x77d0 <generic_tracepoint_arg+0x2d40>
    7428:      	ldr	x9, [x22]
    742c:      	cmp	x9, x10
    7430:      	b.lt	0x4d28 <generic_tracepoint_arg+0x298>
    7434:      	b	0x781c <generic_tracepoint_arg+0x2d8c>
    7438:      	ldr	x9, [x22]
    743c:      	cmp	x9, x10
    7440:      	b.ne	0x781c <generic_tracepoint_arg+0x2d8c>
    7444:      	b	0x4d1c <generic_tracepoint_arg+0x28c>
    7448:      	cmp	w8, #0xc
    744c:      	b.ne	0x7578 <generic_tracepoint_arg+0x2ae8>
    7450:      	ldrb	w11, [x22]
    7454:      	tst	w10, w11
    7458:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    745c:      	b	0x7578 <generic_tracepoint_arg+0x2ae8>
    7460:      	cmp	w8, #0xc
    7464:      	b.ne	0x75bc <generic_tracepoint_arg+0x2b2c>
    7468:      	ldrh	w11, [x22]
    746c:      	tst	w10, w11
    7470:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    7474:      	b	0x75bc <generic_tracepoint_arg+0x2b2c>
    7478:      	cmp	w11, w8
    747c:      	b.hi	0x4b8c <generic_tracepoint_arg+0xfc>
    7480:      	cmp	w8, w10
    7484:      	b.ls	0x4d28 <generic_tracepoint_arg+0x298>
    7488:      	b	0x4b8c <generic_tracepoint_arg+0xfc>
    748c:      	cmp	w9, #0xc
    7490:      	b.eq	0x749c <generic_tracepoint_arg+0x2a0c>
    7494:      	cmp	w9, #0xa
    7498:      	b.ne	0x77e0 <generic_tracepoint_arg+0x2d50>
    749c:      	ldr	x9, [x22]
    74a0:      	cmp	x9, x10
    74a4:      	b.gt	0x4d28 <generic_tracepoint_arg+0x298>
    74a8:      	b	0x781c <generic_tracepoint_arg+0x2d8c>
    74ac:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    74b0:      	mov	w8, #0x1                // =1
    74b4:      	add	x9, sp, #0x60
    74b8:      	ldr	x0, [x0]
    74bc:      	b	0x74f8 <generic_tracepoint_arg+0x2a68>
    74c0:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    74c4:      	mov	w8, #0x1                // =1
    74c8:      	add	x9, sp, #0x60
    74cc:      	ldr	x0, [x0]
    74d0:      	b	0x74f8 <generic_tracepoint_arg+0x2a68>
    74d4:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    74d8:      	mov	w8, #0x1                // =1
    74dc:      	add	x9, sp, #0x60
    74e0:      	ldr	x0, [x0]
    74e4:      	b	0x74f8 <generic_tracepoint_arg+0x2a68>
    74e8:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    74ec:      	mov	w8, #0x1                // =1
    74f0:      	add	x9, sp, #0x60
    74f4:      	ldr	x0, [x0]
    74f8:      	add	x1, sp, #0x60
    74fc:      	blr	x8
    7500:      	cbz	x0, 0x751c <generic_tracepoint_arg+0x2a8c>
    7504:      	mov	w8, #0x1                // =1
    7508:      	mov	x1, x22
    750c:      	blr	x8
    7510:      	cmp	x0, #0x0
    7514:      	cset	w23, ne
    7518:      	b	0x5cb8 <generic_tracepoint_arg+0x1228>
    751c:      	mov	x23, xzr
    7520:      	b	0x5cb8 <generic_tracepoint_arg+0x1228>
    7524:      	cmp	w23, #0x2
    7528:      	b.eq	0x7730 <generic_tracepoint_arg+0x2ca0>
    752c:      	cmp	w23, #0x3
    7530:      	b.ne	0x7778 <generic_tracepoint_arg+0x2ce8>
    7534:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    7538:      	mov	w8, #0x1                // =1
    753c:      	add	x9, sp, #0x60
    7540:      	ldr	x0, [x0]
    7544:      	b	0x7754 <generic_tracepoint_arg+0x2cc4>
    7548:      	cmp	w23, #0x6
    754c:      	b.eq	0x7744 <generic_tracepoint_arg+0x2cb4>
    7550:      	cmp	w23, #0x7
    7554:      	b.ne	0x7778 <generic_tracepoint_arg+0x2ce8>
    7558:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    755c:      	mov	w8, #0x1                // =1
    7560:      	add	x9, sp, #0x60
    7564:      	ldr	x0, [x0]
    7568:      	b	0x7754 <generic_tracepoint_arg+0x2cc4>
    756c:      	ldrb	w11, [x22]
    7570:      	cmp	w10, w11
    7574:      	b.lo	0x4d28 <generic_tracepoint_arg+0x298>
    7578:      	cmp	w9, #0x15
    757c:      	b.lo	0x781c <generic_tracepoint_arg+0x2d8c>
    7580:      	ldr	w9, [x29, #0x1c]
    7584:      	cmp	w8, #0x2
    7588:      	b.le	0x76c0 <generic_tracepoint_arg+0x2c30>
    758c:      	sub	w10, w8, #0x3
    7590:      	cmp	w10, #0x2
    7594:      	b.lo	0x76f0 <generic_tracepoint_arg+0x2c60>
    7598:      	cmp	w8, #0x6
    759c:      	b.eq	0x4d28 <generic_tracepoint_arg+0x298>
    75a0:      	cmp	w8, #0xc
    75a4:      	b.ne	0x4b8c <generic_tracepoint_arg+0xfc>
    75a8:      	ldrb	w10, [x22]
    75ac:      	b	0x764c <generic_tracepoint_arg+0x2bbc>
    75b0:      	ldrh	w11, [x22]
    75b4:      	cmp	w10, w11
    75b8:      	b.lo	0x4d28 <generic_tracepoint_arg+0x298>
    75bc:      	cmp	w9, #0x15
    75c0:      	b.lo	0x781c <generic_tracepoint_arg+0x2d8c>
    75c4:      	ldr	w9, [x29, #0x1c]
    75c8:      	cmp	w8, #0x2
    75cc:      	b.le	0x76d8 <generic_tracepoint_arg+0x2c48>
    75d0:      	sub	w10, w8, #0x3
    75d4:      	cmp	w10, #0x2
    75d8:      	b.lo	0x76f8 <generic_tracepoint_arg+0x2c68>
    75dc:      	cmp	w8, #0x6
    75e0:      	b.eq	0x4d28 <generic_tracepoint_arg+0x298>
    75e4:      	cmp	w8, #0xc
    75e8:      	b.ne	0x4b8c <generic_tracepoint_arg+0xfc>
    75ec:      	ldrh	w10, [x22]
    75f0:      	b	0x764c <generic_tracepoint_arg+0x2bbc>
    75f4:      	ldr	w12, [x22]
    75f8:      	cmp	w12, w11
    75fc:      	mov	w12, #0x1               // =1
    7600:      	b.hi	0x4d28 <generic_tracepoint_arg+0x298>
    7604:      	b	0x7618 <generic_tracepoint_arg+0x2b88>
    7608:      	ldr	w12, [x22]
    760c:      	cmp	w12, w11
    7610:      	mov	w12, #0x1               // =1
    7614:      	b.lo	0x4d28 <generic_tracepoint_arg+0x298>
    7618:      	cmp	w10, #0x15
    761c:      	b.lo	0x781c <generic_tracepoint_arg+0x2d8c>
    7620:      	ldr	w10, [x29, #0x1c]
    7624:      	cmp	w8, #0x2
    7628:      	b.le	0x7658 <generic_tracepoint_arg+0x2bc8>
    762c:      	sub	w9, w8, #0x3
    7630:      	cmp	w9, #0x2
    7634:      	b.lo	0x7690 <generic_tracepoint_arg+0x2c00>
    7638:      	cmp	w8, #0x6
    763c:      	b.eq	0x4d28 <generic_tracepoint_arg+0x298>
    7640:      	cmp	w8, #0xc
    7644:      	b.ne	0x4b8c <generic_tracepoint_arg+0xfc>
    7648:      	ldr	w9, [x22]
    764c:      	tst	w9, w10
    7650:      	b.ne	0x4d28 <generic_tracepoint_arg+0x298>
    7654:      	b	0x781c <generic_tracepoint_arg+0x2d8c>
    7658:      	cmp	w8, #0x1
    765c:      	b.eq	0x7698 <generic_tracepoint_arg+0x2c08>
    7660:      	cmp	w8, #0x2
    7664:      	b.ne	0x4b8c <generic_tracepoint_arg+0xfc>
    7668:      	cmp	w9, #0xc
    766c:      	b.hi	0x7800 <generic_tracepoint_arg+0x2d70>
    7670:      	lsl	w9, w12, w9
    7674:      	mov	w11, #0x1402            // =5122
    7678:      	tst	w9, w11
    767c:      	b.eq	0x7800 <generic_tracepoint_arg+0x2d70>
    7680:      	ldr	w9, [x22]
    7684:      	cmp	w9, w10
    7688:      	b.lt	0x4d28 <generic_tracepoint_arg+0x298>
    768c:      	b	0x781c <generic_tracepoint_arg+0x2d8c>
    7690:      	ldr	w9, [x22]
    7694:      	b	0x76fc <generic_tracepoint_arg+0x2c6c>
    7698:      	cmp	w9, #0xc
    769c:      	b.hi	0x7810 <generic_tracepoint_arg+0x2d80>
    76a0:      	lsl	w9, w12, w9
    76a4:      	mov	w11, #0x1402            // =5122
    76a8:      	tst	w9, w11
    76ac:      	b.eq	0x7810 <generic_tracepoint_arg+0x2d80>
    76b0:      	ldr	w9, [x22]
    76b4:      	cmp	w9, w10
    76b8:      	b.gt	0x4d28 <generic_tracepoint_arg+0x298>
    76bc:      	b	0x781c <generic_tracepoint_arg+0x2d8c>
    76c0:      	cmp	w8, #0x1
    76c4:      	b.eq	0x77f0 <generic_tracepoint_arg+0x2d60>
    76c8:      	cmp	w8, #0x2
    76cc:      	b.ne	0x4b8c <generic_tracepoint_arg+0xfc>
    76d0:      	ldrb	w10, [x22]
    76d4:      	b	0x7814 <generic_tracepoint_arg+0x2d84>
    76d8:      	cmp	w8, #0x1
    76dc:      	b.eq	0x77f8 <generic_tracepoint_arg+0x2d68>
    76e0:      	cmp	w8, #0x2
    76e4:      	b.ne	0x4b8c <generic_tracepoint_arg+0xfc>
    76e8:      	ldrh	w10, [x22]
    76ec:      	b	0x7814 <generic_tracepoint_arg+0x2d84>
    76f0:      	ldrb	w10, [x22]
    76f4:      	b	0x76fc <generic_tracepoint_arg+0x2c6c>
    76f8:      	ldrh	w10, [x22]
    76fc:      	cmp	w9, w10
    7700:      	b.eq	0x4d1c <generic_tracepoint_arg+0x28c>
    7704:      	b	0x781c <generic_tracepoint_arg+0x2d8c>
    7708:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    770c:      	mov	w8, #0x1                // =1
    7710:      	add	x9, sp, #0x60
    7714:      	ldr	x0, [x0]
    7718:      	b	0x7754 <generic_tracepoint_arg+0x2cc4>
    771c:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    7720:      	mov	w8, #0x1                // =1
    7724:      	add	x9, sp, #0x60
    7728:      	ldr	x0, [x0]
    772c:      	b	0x7754 <generic_tracepoint_arg+0x2cc4>
    7730:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    7734:      	mov	w8, #0x1                // =1
    7738:      	add	x9, sp, #0x60
    773c:      	ldr	x0, [x0]
    7740:      	b	0x7754 <generic_tracepoint_arg+0x2cc4>
    7744:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    7748:      	mov	w8, #0x1                // =1
    774c:      	add	x9, sp, #0x60
    7750:      	ldr	x0, [x0]
    7754:      	add	x1, sp, #0x60
    7758:      	blr	x8
    775c:      	cbz	x0, 0x7778 <generic_tracepoint_arg+0x2ce8>
    7760:      	mov	w8, #0x1                // =1
    7764:      	mov	x1, x19
    7768:      	blr	x8
    776c:      	cmp	x0, #0x0
    7770:      	cset	w23, ne
    7774:      	b	0x777c <generic_tracepoint_arg+0x2cec>
    7778:      	mov	x23, xzr
    777c:      	ldp	x16, x15, [sp, #0x40]
    7780:      	mov	w2, #0x5ea0             // =24224
    7784:      	mov	w12, #0x1               // =1
    7788:      	ldr	x17, [sp, #0x38]
    778c:      	ldr	w8, [x29, #0x4]
    7790:      	cmp	w8, #0x25
    7794:      	b.hi	0x77bc <generic_tracepoint_arg+0x2d2c>
    7798:      	mov	x9, #0x50               // =80
    779c:      	ldr	x19, [sp, #0x30]
    77a0:      	lsl	x8, x12, x8
    77a4:      	movk	x9, #0xc00, lsl #16
    77a8:      	movk	x9, #0x20, lsl #32
    77ac:      	tst	x8, x9
    77b0:      	b.eq	0x4d24 <generic_tracepoint_arg+0x294>
    77b4:      	cmp	x23, #0x0
    77b8:      	b	0x4d20 <generic_tracepoint_arg+0x290>
    77bc:      	ldr	x19, [sp, #0x30]
    77c0:      	b	0x4d24 <generic_tracepoint_arg+0x294>
    77c4:      	ldr	x19, [sp, #0x30]
    77c8:      	mov	w12, #0x1               // =1
    77cc:      	b	0x68f0 <generic_tracepoint_arg+0x1e60>
    77d0:      	ldr	x9, [x22]
    77d4:      	cmp	x9, x10
    77d8:      	b.lo	0x4d28 <generic_tracepoint_arg+0x298>
    77dc:      	b	0x781c <generic_tracepoint_arg+0x2d8c>
    77e0:      	ldr	x9, [x22]
    77e4:      	cmp	x9, x10
    77e8:      	b.hi	0x4d28 <generic_tracepoint_arg+0x298>
    77ec:      	b	0x781c <generic_tracepoint_arg+0x2d8c>
    77f0:      	ldrb	w10, [x22]
    77f4:      	b	0x7804 <generic_tracepoint_arg+0x2d74>
    77f8:      	ldrh	w10, [x22]
    77fc:      	b	0x7804 <generic_tracepoint_arg+0x2d74>
    7800:      	ldr	w9, [x22]
    7804:      	cmp	w9, w10
    7808:      	b.lo	0x4d28 <generic_tracepoint_arg+0x298>
    780c:      	b	0x781c <generic_tracepoint_arg+0x2d8c>
    7810:      	ldr	w9, [x22]
    7814:      	cmp	w9, w10
    7818:      	b.hi	0x4d28 <generic_tracepoint_arg+0x298>
    781c:      	orr	w8, w8, #0x2
    7820:      	cmp	w8, #0x6
    7824:      	b.eq	0x4d28 <generic_tracepoint_arg+0x298>
    7828:      	b	0x4b8c <generic_tracepoint_arg+0xfc>
    782c:      	nop

0000000000007830 <generic_tracepoint_actions>:
    7830:      	sub	sp, sp, #0xf0
    7834:      	str	x29, [sp, #0xa0]
    7838:      	stp	x30, x25, [sp, #0xb0]
    783c:      	stp	x24, x23, [sp, #0xc0]
    7840:      	stp	x22, x21, [sp, #0xd0]
    7844:      	stp	x20, x19, [sp, #0xe0]
    7848:      	str	wzr, [sp, #0x5c]
    784c:      	adrp	x24, 0x7000 <generic_tracepoint_arg+0x2570>
    7850:      	mov	w8, #0x1                // =1
    7854:      	add	x9, sp, #0x5c
    7858:      	ldr	x24, [x24]
    785c:      	mov	x25, x0
    7860:      	add	x1, sp, #0x5c
    7864:      	mov	x0, x24
    7868:      	blr	x8
    786c:      	cbz	x0, 0x8520 <generic_tracepoint_actions+0xcf0>
    7870:      	mov	w8, #0x5f04             // =24324
    7874:      	ldr	w19, [x0, x8]
    7878:      	cmp	w19, #0x2
    787c:      	b.lt	0x8520 <generic_tracepoint_actions+0xcf0>
    7880:      	mov	w8, #0x5ef8             // =24312
    7884:      	add	x1, x0, x8
    7888:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    788c:      	mov	w8, #0x1                // =1
    7890:      	ldr	x0, [x0]
    7894:      	blr	x8
    7898:      	cbz	x0, 0x8520 <generic_tracepoint_actions+0xcf0>
    789c:      	and	x8, x19, #0x7ff
    78a0:      	add	x9, sp, #0x60
    78a4:      	add	x1, sp, #0x60
    78a8:      	ldr	w8, [x0, x8]
    78ac:      	str	wzr, [sp, #0x60]
    78b0:      	add	w8, w8, w19
    78b4:      	and	w8, w8, #0x7ff
    78b8:      	add	x22, x0, x8
    78bc:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    78c0:      	mov	w8, #0x1                // =1
    78c4:      	ldr	x0, [x0]
    78c8:      	blr	x8
    78cc:      	cbz	x0, 0x78f8 <generic_tracepoint_actions+0xc8>
    78d0:      	ldrb	w8, [x0]
    78d4:      	tst	w8, #0xff
    78d8:      	cset	w8, eq
    78dc:      	str	w8, [sp, #0x4c]
    78e0:      	mov	w8, #0x8                // =8
    78e4:      	cinc	x9, x8, ne
    78e8:      	mov	w8, #0x4                // =4
    78ec:      	cinc	x8, x8, ne
    78f0:      	stp	x8, x9, [sp, #0x28]
    78f4:      	b	0x7910 <generic_tracepoint_actions+0xe0>
    78f8:      	mov	w8, #0x1                // =1
    78fc:      	str	w8, [sp, #0x4c]
    7900:      	mov	w8, #0x4                // =4
    7904:      	str	x8, [sp, #0x28]
    7908:      	mov	w8, #0x8                // =8
    790c:      	str	x8, [sp, #0x30]
    7910:      	mov	w23, wzr
    7914:      	mov	w29, wzr
    7918:      	add	x20, sp, #0x64
    791c:      	str	x22, [sp, #0x50]
    7920:      	str	x25, [sp, #0x40]
    7924:      	mov	w8, #0x1                // =1
    7928:      	str	w8, [sp, #0x3c]
    792c:      	b	0x7950 <generic_tracepoint_actions+0x120>
    7930:      	nop
    7934:      	nop
    7938:      	nop
    793c:      	nop
    7940:      	mov	w29, wzr
    7944:      	add	w23, w23, #0x1
    7948:      	cmp	w23, #0x3
    794c:      	b.eq	0x84fc <generic_tracepoint_actions+0xccc>
    7950:      	ldr	w9, [x22]
    7954:      	lsl	w8, w29, #2
    7958:      	add	w8, w8, #0x4
    795c:      	cmp	w8, w9
    7960:      	b.hs	0x84fc <generic_tracepoint_actions+0xccc>
    7964:      	add	x8, x22, w29, uxtw #2
    7968:      	add	x1, sp, #0x64
    796c:      	mov	x0, x24
    7970:      	ldrsw	x19, [x8, #0x4]
    7974:      	str	wzr, [sp, #0x64]
    7978:      	mov	w8, #0x1                // =1
    797c:      	blr	x8
    7980:      	cbz	x0, 0x7940 <generic_tracepoint_actions+0x110>
    7984:      	mov	x21, x0
    7988:      	cmp	w19, #0x7
    798c:      	b.gt	0x79c0 <generic_tracepoint_actions+0x190>
    7990:      	cmp	w19, #0x3
    7994:      	b.gt	0x7a14 <generic_tracepoint_actions+0x1e4>
    7998:      	cmp	w19, #0x1
    799c:      	b.gt	0x7a94 <generic_tracepoint_actions+0x264>
    79a0:      	cbz	w19, 0x7bf0 <generic_tracepoint_actions+0x3c0>
    79a4:      	cmp	w19, #0x1
    79a8:      	b.eq	0x7aa4 <generic_tracepoint_actions+0x274>
    79ac:      	b	0x7e00 <generic_tracepoint_actions+0x5d0>
    79b0:      	nop
    79b4:      	nop
    79b8:      	nop
    79bc:      	nop
    79c0:      	cmp	w19, #0xb
    79c4:      	b.gt	0x7a6c <generic_tracepoint_actions+0x23c>
    79c8:      	sub	w8, w19, #0xa
    79cc:      	cmp	w8, #0x2
    79d0:      	b.lo	0x7af8 <generic_tracepoint_actions+0x2c8>
    79d4:      	cmp	w19, #0x8
    79d8:      	b.eq	0x7b40 <generic_tracepoint_actions+0x310>
    79dc:      	cmp	w19, #0x9
    79e0:      	b.ne	0x7e00 <generic_tracepoint_actions+0x5d0>
    79e4:      	add	w29, w29, #0x1
    79e8:      	add	x8, x22, w29, uxtw #2
    79ec:      	ldr	w0, [x8, #0x4]
    79f0:      	ldr	w8, [sp, #0x4c]
    79f4:      	cbz	w8, 0x7c94 <generic_tracepoint_actions+0x464>
    79f8:      	sxtw	x8, w0
    79fc:      	mov	w9, #0x6d               // =109
    7a00:      	blr	x9
    7a04:      	mov	w20, #0x2               // =2
    7a08:      	mov	w24, w29
    7a0c:      	add	x29, sp, #0x68
    7a10:      	b	0x7db8 <generic_tracepoint_actions+0x588>
    7a14:      	sub	w8, w19, #0x6
    7a18:      	cmp	w8, #0x2
    7a1c:      	b.lo	0x7b2c <generic_tracepoint_actions+0x2fc>
    7a20:      	cmp	w19, #0x4
    7a24:      	b.eq	0x7b48 <generic_tracepoint_actions+0x318>
    7a28:      	cmp	w19, #0x5
    7a2c:      	b.ne	0x7e00 <generic_tracepoint_actions+0x5d0>
    7a30:      	add	w8, w29, #0x1
    7a34:      	add	x9, x22, #0x4
    7a38:      	add	w29, w29, #0x2
    7a3c:      	ldr	w8, [x9, w8, uxtw #2]
    7a40:      	ldr	w20, [x9, w29, uxtw #2]
    7a44:      	stp	xzr, xzr, [sp, #0x68]
    7a48:      	and	x8, x8, #0x7
    7a4c:      	cmp	w8, #0x4
    7a50:      	b.hi	0x7a64 <generic_tracepoint_actions+0x234>
    7a54:      	add	x9, x21, x8, lsl #2
    7a58:      	mov	w10, #0x5ea0            // =24224
    7a5c:      	ldr	w9, [x9, x10]
    7a60:      	cbz	w9, 0x7fc0 <generic_tracepoint_actions+0x790>
    7a64:      	add	x20, sp, #0x64
    7a68:      	b	0x7e00 <generic_tracepoint_actions+0x5d0>
    7a6c:      	cmp	w19, #0xc
    7a70:      	b.eq	0x7ca4 <generic_tracepoint_actions+0x474>
    7a74:      	cmp	w19, #0xd
    7a78:      	b.eq	0x7b58 <generic_tracepoint_actions+0x328>
    7a7c:      	cmp	w19, #0xe
    7a80:      	b.ne	0x7e00 <generic_tracepoint_actions+0x5d0>
    7a84:      	ldr	x20, [sp, #0x30]
    7a88:      	add	w24, w29, #0x2
    7a8c:      	add	x29, sp, #0x68
    7a90:      	b	0x7db8 <generic_tracepoint_actions+0x588>
    7a94:      	cmp	w19, #0x2
    7a98:      	b.eq	0x7c88 <generic_tracepoint_actions+0x458>
    7a9c:      	cmp	w19, #0x3
    7aa0:      	b.ne	0x7e00 <generic_tracepoint_actions+0x5d0>
    7aa4:      	add	w8, w29, #0x1
    7aa8:      	add	x9, x22, #0x4
    7aac:      	add	w29, w29, #0x2
    7ab0:      	ldr	w22, [x9, w8, uxtw #2]
    7ab4:      	ldr	w20, [x9, w29, uxtw #2]
    7ab8:      	stp	xzr, xzr, [sp, #0x68]
    7abc:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    7ac0:      	mov	w8, #0x1                // =1
    7ac4:      	add	x9, sp, #0x88
    7ac8:      	add	x1, sp, #0x88
    7acc:      	str	wzr, [sp, #0x88]
    7ad0:      	ldr	x0, [x0]
    7ad4:      	blr	x8
    7ad8:      	cbz	x0, 0x7aec <generic_tracepoint_actions+0x2bc>
    7adc:      	and	x8, x22, #0x7
    7ae0:      	cmp	w8, #0x4
    7ae4:      	b.ls	0x7d90 <generic_tracepoint_actions+0x560>
    7ae8:      	mov	w0, wzr
    7aec:      	ldr	x22, [sp, #0x50]
    7af0:      	add	x20, sp, #0x64
    7af4:      	b	0x7b24 <generic_tracepoint_actions+0x2f4>
    7af8:      	add	w29, w29, #0x1
    7afc:      	add	x8, x22, w29, uxtw #2
    7b00:      	ldr	w8, [x8, #0x4]
    7b04:      	and	x8, x8, #0x7
    7b08:      	cmp	w8, #0x4
    7b0c:      	b.hi	0x7b20 <generic_tracepoint_actions+0x2f0>
    7b10:      	add	x9, x21, x8, lsl #2
    7b14:      	mov	w10, #0x5ea0            // =24224
    7b18:      	ldr	w9, [x9, x10]
    7b1c:      	cbz	w9, 0x7e18 <generic_tracepoint_actions+0x5e8>
    7b20:      	mov	w0, wzr
    7b24:      	cbnz	w0, 0x7940 <generic_tracepoint_actions+0x110>
    7b28:      	b	0x7e00 <generic_tracepoint_actions+0x5d0>
    7b2c:      	add	w29, w29, #0x1
    7b30:      	add	x8, x22, w29, uxtw #2
    7b34:      	ldr	w8, [x8, #0x4]
    7b38:      	str	w8, [x21, #0x78]
    7b3c:      	b	0x7e00 <generic_tracepoint_actions+0x5d0>
    7b40:      	str	wzr, [sp, #0x3c]
    7b44:      	b	0x7e00 <generic_tracepoint_actions+0x5d0>
    7b48:      	ldr	x20, [sp, #0x28]
    7b4c:      	add	w24, w29, #0x1
    7b50:      	add	x29, sp, #0x68
    7b54:      	b	0x7db8 <generic_tracepoint_actions+0x588>
    7b58:      	mov	w8, #0xe                // =14
    7b5c:      	blr	x8
    7b60:      	str	x0, [sp, #0x78]
    7b64:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    7b68:      	mov	w8, #0x1                // =1
    7b6c:      	add	x9, sp, #0x78
    7b70:      	ldr	x0, [x0]
    7b74:      	add	x1, sp, #0x78
    7b78:      	blr	x8
    7b7c:      	cbz	x0, 0x7e00 <generic_tracepoint_actions+0x5d0>
    7b80:      	ldur	x8, [x0, #0x4]
    7b84:      	mov	x22, x25
    7b88:      	adrp	x25, 0x7000 <generic_tracepoint_arg+0x2570>
    7b8c:      	add	x9, sp, #0x88
    7b90:      	str	x8, [sp, #0x88]
    7b94:      	mov	w8, #0x2                // =2
    7b98:      	add	x1, sp, #0x88
    7b9c:      	str	w8, [sp, #0x90]
    7ba0:      	mov	w8, #0x1                // =1
    7ba4:      	ldr	x25, [x25]
    7ba8:      	mov	x0, x25
    7bac:      	blr	x8
    7bb0:      	mov	w9, #0x1                // =1
    7bb4:      	str	w9, [sp, #0xac]
    7bb8:      	cbz	x0, 0x7f4c <generic_tracepoint_actions+0x71c>
    7bbc:      	mov	x25, x22
    7bc0:      	ldaxr	w8, [x0]
    7bc4:      	add	w8, w8, #0x1
    7bc8:      	stlxr	w9, w8, [x0]
    7bcc:      	cbnz	w9, 0x7bc0 <generic_tracepoint_actions+0x390>
    7bd0:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    7bd4:      	mov	w8, #0x3                // =3
    7bd8:      	add	x9, sp, #0x78
    7bdc:      	ldr	x0, [x0]
    7be0:      	add	x1, sp, #0x78
    7be4:      	blr	x8
    7be8:      	ldr	x22, [sp, #0x50]
    7bec:      	b	0x7e00 <generic_tracepoint_actions+0x5d0>
    7bf0:      	add	w8, w29, #0x1
    7bf4:      	add	x9, x22, #0x4
    7bf8:      	ldr	w25, [x9, w8, uxtw #2]
    7bfc:      	add	w8, w29, #0x2
    7c00:      	ldr	w20, [x9, w8, uxtw #2]
    7c04:      	mov	w8, #0x7d               // =125
    7c08:      	blr	x8
    7c0c:      	str	x0, [sp, #0x68]
    7c10:      	str	wzr, [sp, #0x78]
    7c14:      	str	x25, [sp, #0x10]
    7c18:      	cbz	w25, 0x8378 <generic_tracepoint_actions+0xb48>
    7c1c:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    7c20:      	mov	w8, #0x1                // =1
    7c24:      	add	x9, sp, #0x78
    7c28:      	ldr	x0, [x0]
    7c2c:      	add	x1, sp, #0x78
    7c30:      	blr	x8
    7c34:      	cbz	x0, 0x8378 <generic_tracepoint_actions+0xb48>
    7c38:      	mov	x25, x0
    7c3c:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    7c40:      	mov	w8, #0x1                // =1
    7c44:      	ldr	x0, [x0]
    7c48:      	add	x9, sp, #0x78
    7c4c:      	add	x1, sp, #0x78
    7c50:      	blr	x8
    7c54:      	ldr	x8, [x21, #0x60]
    7c58:      	mov	x2, x0
    7c5c:      	cmp	w20, #0x2
    7c60:      	str	x25, [sp, #0x8]
    7c64:      	str	x8, [x25]
    7c68:      	ldr	x8, [x21, #0x70]
    7c6c:      	str	x8, [x25, #0x8]
    7c70:      	b.eq	0x81a0 <generic_tracepoint_actions+0x970>
    7c74:      	cmp	w20, #0x1
    7c78:      	b.eq	0x8198 <generic_tracepoint_actions+0x968>
    7c7c:      	cbnz	w20, 0x8378 <generic_tracepoint_actions+0xb48>
    7c80:      	ldr	w8, [x21, #0x7c]
    7c84:      	b	0x81a4 <generic_tracepoint_actions+0x974>
    7c88:      	mov	w0, #0x9                // =9
    7c8c:      	ldr	w8, [sp, #0x4c]
    7c90:      	cbnz	w8, 0x79f8 <generic_tracepoint_actions+0x1c8>
    7c94:      	mov	w20, #0x3               // =3
    7c98:      	mov	w24, w29
    7c9c:      	add	x29, sp, #0x68
    7ca0:      	b	0x7db8 <generic_tracepoint_actions+0x588>
    7ca4:      	ldr	w8, [sp, #0x4c]
    7ca8:      	add	w24, w29, #0x3
    7cac:      	cbz	w8, 0x7db0 <generic_tracepoint_actions+0x580>
    7cb0:      	add	x8, x22, #0x4
    7cb4:      	ldr	w9, [x8, w24, uxtw #2]
    7cb8:      	cmp	w9, #0x4
    7cbc:      	b.hi	0x7cd0 <generic_tracepoint_actions+0x4a0>
    7cc0:      	add	x10, x21, x9, lsl #2
    7cc4:      	mov	w11, #0x5ea0            // =24224
    7cc8:      	ldr	w10, [x10, x11]
    7ccc:      	cbz	w10, 0x83f8 <generic_tracepoint_actions+0xbc8>
    7cd0:      	mov	x9, xzr
    7cd4:      	add	w10, w29, #0x2
    7cd8:      	ldr	w20, [x8, w10, uxtw #2]
    7cdc:      	add	w10, w29, #0x1
    7ce0:      	ldr	w22, [x8, w10, uxtw #2]
    7ce4:      	ldr	w8, [x21, #0x60]
    7ce8:      	orr	x25, x8, x9, lsl #32
    7cec:      	mov	w8, #0xe                // =14
    7cf0:      	blr	x8
    7cf4:      	str	x0, [sp, #0x98]
    7cf8:      	strh	w22, [sp, #0x88]
    7cfc:      	mov	w8, #0x1                // =1
    7d00:      	add	x1, sp, #0x98
    7d04:      	strh	w20, [sp, #0x8a]
    7d08:      	stur	x25, [sp, #0x8c]
    7d0c:      	adrp	x20, 0x7000 <generic_tracepoint_arg+0x2570>
    7d10:      	ldr	x20, [x20]
    7d14:      	add	x25, sp, #0x98
    7d18:      	mov	x0, x20
    7d1c:      	blr	x8
    7d20:      	cbz	x0, 0x8078 <generic_tracepoint_actions+0x848>
    7d24:      	ldur	x8, [x0, #0x4]
    7d28:      	mov	w20, #0x1               // =1
    7d2c:      	adrp	x29, 0x7000 <generic_tracepoint_arg+0x2570>
    7d30:      	add	x9, sp, #0x78
    7d34:      	str	w20, [sp, #0x80]
    7d38:      	mov	x22, x0
    7d3c:      	add	x1, sp, #0x78
    7d40:      	str	x8, [sp, #0x78]
    7d44:      	mov	w8, #0x1                // =1
    7d48:      	ldr	x29, [x29]
    7d4c:      	mov	x0, x29
    7d50:      	blr	x8
    7d54:      	ldr	x25, [sp, #0x40]
    7d58:      	str	w20, [sp, #0xa8]
    7d5c:      	cbz	x0, 0x8124 <generic_tracepoint_actions+0x8f4>
    7d60:      	ldaxr	w8, [x0]
    7d64:      	add	w8, w8, #0x1
    7d68:      	stlxr	w9, w8, [x0]
    7d6c:      	cbnz	w9, 0x7d60 <generic_tracepoint_actions+0x530>
    7d70:      	ldr	x8, [sp, #0x88]
    7d74:      	ldr	w9, [sp, #0x90]
    7d78:      	add	x29, sp, #0x68
    7d7c:      	str	w9, [x22, #0x8]
    7d80:      	str	x8, [x22]
    7d84:      	ldr	x22, [sp, #0x50]
    7d88:      	mov	w20, #0x6               // =6
    7d8c:      	b	0x7db8 <generic_tracepoint_actions+0x588>
    7d90:      	add	x9, x21, x8, lsl #2
    7d94:      	mov	w10, #0x5ea0            // =24224
    7d98:      	ldr	x22, [sp, #0x50]
    7d9c:      	ldr	w9, [x9, x10]
    7da0:      	cbz	w9, 0x7ea0 <generic_tracepoint_actions+0x670>
    7da4:      	mov	w0, wzr
    7da8:      	add	x20, sp, #0x64
    7dac:      	b	0x7b24 <generic_tracepoint_actions+0x2f4>
    7db0:      	mov	w20, #0x7               // =7
    7db4:      	add	x29, sp, #0x68
    7db8:      	str	wzr, [sp, #0x68]
    7dbc:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    7dc0:      	mov	w8, #0x1                // =1
    7dc4:      	add	x1, sp, #0x68
    7dc8:      	ldr	x0, [x0]
    7dcc:      	blr	x8
    7dd0:      	cbz	x0, 0x7df0 <generic_tracepoint_actions+0x5c0>
    7dd4:      	add	x8, x0, x20, lsl #3
    7dd8:      	nop
    7ddc:      	nop
    7de0:      	ldaxr	x9, [x8]
    7de4:      	add	x9, x9, #0x1
    7de8:      	stlxr	w10, x9, [x8]
    7dec:      	cbnz	w10, 0x7de0 <generic_tracepoint_actions+0x5b0>
    7df0:      	mov	w29, w24
    7df4:      	adrp	x24, 0x7000 <generic_tracepoint_arg+0x2570>
    7df8:      	add	x20, sp, #0x64
    7dfc:      	ldr	x24, [x24]
    7e00:      	add	w29, w29, #0x1
    7e04:      	str	x19, [x21, #0x70]
    7e08:      	add	w23, w23, #0x1
    7e0c:      	cmp	w23, #0x3
    7e10:      	b.ne	0x7950 <generic_tracepoint_actions+0x120>
    7e14:      	b	0x84fc <generic_tracepoint_actions+0xccc>
    7e18:      	add	x8, x21, x8, lsl #3
    7e1c:      	ldr	x8, [x8, #0x5e78]
    7e20:      	and	x8, x8, #0x7ff
    7e24:      	add	x8, x21, x8
    7e28:      	ldr	x8, [x8, #0xb8]
    7e2c:      	str	x8, [sp, #0x88]
    7e30:      	cbz	x8, 0x7b20 <generic_tracepoint_actions+0x2f0>
    7e34:      	cmp	w19, #0xa
    7e38:      	b.ne	0x8108 <generic_tracepoint_actions+0x8d8>
    7e3c:      	mov	w8, #0xe                // =14
    7e40:      	blr	x8
    7e44:      	lsr	x8, x0, #32
    7e48:      	mov	x22, x0
    7e4c:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    7e50:      	str	w8, [sp, #0x68]
    7e54:      	mov	w8, #0x1                // =1
    7e58:      	add	x9, sp, #0x68
    7e5c:      	add	x1, sp, #0x68
    7e60:      	ldr	x0, [x0]
    7e64:      	blr	x8
    7e68:      	cbz	x0, 0x7f44 <generic_tracepoint_actions+0x714>
    7e6c:      	ldr	w8, [x0]
    7e70:      	mov	x3, xzr
    7e74:      	add	x9, sp, #0x88
    7e78:      	add	x10, sp, #0x68
    7e7c:      	stp	w8, w22, [sp, #0x68]
    7e80:      	ldr	x8, [x0, #0x8]
    7e84:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    7e88:      	add	x1, sp, #0x88
    7e8c:      	add	x2, sp, #0x68
    7e90:      	str	x8, [sp, #0x70]
    7e94:      	mov	w8, #0x2                // =2
    7e98:      	ldr	x0, [x0]
    7e9c:      	b	0x7f3c <generic_tracepoint_actions+0x70c>
    7ea0:      	add	x8, x21, x8, lsl #3
    7ea4:      	mov	x22, x0
    7ea8:      	ldr	x8, [x8, #0x5e78]
    7eac:      	str	wzr, [sp, #0x74]
    7eb0:      	and	x8, x8, #0x7ff
    7eb4:      	add	x8, x21, x8
    7eb8:      	ldr	w8, [x8, #0x90]
    7ebc:      	str	w8, [sp, #0x70]
    7ec0:      	mov	w8, #0xe                // =14
    7ec4:      	blr	x8
    7ec8:      	lsr	x8, x0, #32
    7ecc:      	cmp	w19, #0x1
    7ed0:      	str	x8, [sp, #0x68]
    7ed4:      	b.ne	0x80ec <generic_tracepoint_actions+0x8bc>
    7ed8:      	and	x8, x20, #0x7
    7edc:      	cmp	w8, #0x4
    7ee0:      	b.hi	0x7ae8 <generic_tracepoint_actions+0x2b8>
    7ee4:      	add	x9, x21, x8, lsl #2
    7ee8:      	mov	w10, #0x5ea0            // =24224
    7eec:      	add	x20, sp, #0x64
    7ef0:      	ldr	w9, [x9, x10]
    7ef4:      	cbnz	w9, 0x7f40 <generic_tracepoint_actions+0x710>
    7ef8:      	add	x8, x21, x8, lsl #3
    7efc:      	mov	x0, x22
    7f00:      	ldr	x8, [x8, #0x5e78]
    7f04:      	and	x8, x8, #0x7ff
    7f08:      	add	x2, x21, x8
    7f0c:      	ldr	w8, [x2, #0x90]!
    7f10:      	and	x8, x8, #0xfff
    7f14:      	add	x1, x8, #0x8
    7f18:      	mov	w8, #0x4                // =4
    7f1c:      	blr	x8
    7f20:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    7f24:      	mov	x3, xzr
    7f28:      	mov	w8, #0x2                // =2
    7f2c:      	ldr	x0, [x0]
    7f30:      	add	x9, sp, #0x68
    7f34:      	add	x1, sp, #0x68
    7f38:      	mov	x2, x22
    7f3c:      	blr	x8
    7f40:      	mov	w0, wzr
    7f44:      	ldr	x22, [sp, #0x50]
    7f48:      	b	0x7b24 <generic_tracepoint_actions+0x2f4>
    7f4c:      	mov	w8, #0x2                // =2
    7f50:      	add	x10, sp, #0xac
    7f54:      	add	x11, sp, #0x88
    7f58:      	add	x1, sp, #0x88
    7f5c:      	add	x2, sp, #0xac
    7f60:      	mov	x0, x25
    7f64:      	mov	w3, #0x1                // =1
    7f68:      	blr	x8
    7f6c:      	mov	x25, x22
    7f70:      	cbz	x0, 0x7bd0 <generic_tracepoint_actions+0x3a0>
    7f74:      	mov	x22, x0
    7f78:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    7f7c:      	add	x10, sp, #0x68
    7f80:      	add	x1, sp, #0x68
    7f84:      	neg	w8, w22
    7f88:      	strh	w8, [sp, #0x68]
    7f8c:      	mov	w8, #0x3                // =3
    7f90:      	strh	w8, [sp, #0x6a]
    7f94:      	mov	x8, #0x3b               // =59
    7f98:      	movk	x8, #0x2, lsl #32
    7f9c:      	stur	x8, [sp, #0x6c]
    7fa0:      	mov	w8, #0x1                // =1
    7fa4:      	ldr	x0, [x0]
    7fa8:      	blr	x8
    7fac:      	cbz	x0, 0x8410 <generic_tracepoint_actions+0xbe0>
    7fb0:      	ldr	w8, [x0]
    7fb4:      	add	w8, w8, #0x1
    7fb8:      	str	w8, [x0]
    7fbc:      	b	0x843c <generic_tracepoint_actions+0xc0c>
    7fc0:      	add	x8, x21, x8, lsl #3
    7fc4:      	ldr	x8, [x8, #0x5e78]
    7fc8:      	and	x8, x8, #0x7ff
    7fcc:      	add	x8, x21, x8
    7fd0:      	ldr	w8, [x8, #0x90]
    7fd4:      	str	w8, [sp, #0x70]
    7fd8:      	mov	w8, #0xe                // =14
    7fdc:      	blr	x8
    7fe0:      	lsr	x8, x0, #32
    7fe4:      	adrp	x0, 0x7000 <generic_tracepoint_arg+0x2570>
    7fe8:      	add	x9, sp, #0x68
    7fec:      	str	x8, [sp, #0x68]
    7ff0:      	mov	w8, #0x1                // =1
    7ff4:      	add	x1, sp, #0x68
    7ff8:      	ldr	x0, [x0]
    7ffc:      	blr	x8
    8000:      	cbz	x0, 0x7a64 <generic_tracepoint_actions+0x234>
    8004:      	and	x8, x20, #0x7
    8008:      	cmp	w8, #0x4
    800c:      	b.hi	0x7a64 <generic_tracepoint_actions+0x234>
    8010:      	add	x9, x21, x8, lsl #2
    8014:      	mov	w10, #0x5ea0            // =24224
    8018:      	ldr	w9, [x9, x10]
    801c:      	cbnz	w9, 0x7a64 <generic_tracepoint_actions+0x234>
    8020:      	add	x8, x21, x8, lsl #3
    8024:      	mov	x22, x0
    8028:      	ldr	x8, [x8, #0x5e78]
    802c:      	str	wzr, [sp, #0x74]
    8030:      	and	x8, x8, #0x7ff
    8034:      	add	x8, x21, x8
    8038:      	ldr	w8, [x8, #0x90]
    803c:      	str	w8, [sp, #0x70]
    8040:      	mov	w8, #0xe                // =14
    8044:      	blr	x8
    8048:      	lsr	x8, x0, #32
    804c:      	adrp	x0, 0x8000 <generic_tracepoint_actions+0x7d0>
    8050:      	mov	x3, xzr
    8054:      	str	x8, [sp, #0x68]
    8058:      	mov	w8, #0x2                // =2
    805c:      	add	x9, sp, #0x68
    8060:      	mov	x2, x22
    8064:      	ldr	x0, [x0]
    8068:      	add	x1, sp, #0x68
    806c:      	ldr	x22, [sp, #0x50]
    8070:      	blr	x8
    8074:      	b	0x7a64 <generic_tracepoint_actions+0x234>
    8078:      	mov	x3, xzr
    807c:      	mov	w8, #0x2                // =2
    8080:      	add	x9, sp, #0x88
    8084:      	add	x1, sp, #0x98
    8088:      	add	x2, sp, #0x88
    808c:      	mov	x0, x20
    8090:      	blr	x8
    8094:      	ldr	x25, [sp, #0x40]
    8098:      	ldr	x22, [sp, #0x50]
    809c:      	add	x29, sp, #0x68
    80a0:      	cbz	x0, 0x7d88 <generic_tracepoint_actions+0x558>
    80a4:      	neg	w8, w0
    80a8:      	adrp	x20, 0x8000 <generic_tracepoint_actions+0x7d0>
    80ac:      	add	x1, sp, #0x68
    80b0:      	strh	w8, [sp, #0x68]
    80b4:      	mov	w8, #0x3                // =3
    80b8:      	strh	w8, [sp, #0x6a]
    80bc:      	mov	x8, #0x6b               // =107
    80c0:      	movk	x8, #0x2, lsl #32
    80c4:      	stur	x8, [sp, #0x6c]
    80c8:      	mov	w8, #0x1                // =1
    80cc:      	ldr	x20, [x20]
    80d0:      	mov	x0, x20
    80d4:      	blr	x8
    80d8:      	cbz	x0, 0x8474 <generic_tracepoint_actions+0xc44>
    80dc:      	ldr	w8, [x0]
    80e0:      	add	w8, w8, #0x1
    80e4:      	str	w8, [x0]
    80e8:      	b	0x7d88 <generic_tracepoint_actions+0x558>
    80ec:      	adrp	x0, 0x8000 <generic_tracepoint_actions+0x7d0>
    80f0:      	mov	w8, #0x3                // =3
    80f4:      	add	x9, sp, #0x68
    80f8:      	ldr	x0, [x0]
    80fc:      	add	x1, sp, #0x68
    8100:      	blr	x8
    8104:      	b	0x7aec <generic_tracepoint_actions+0x2bc>
    8108:      	adrp	x0, 0x8000 <generic_tracepoint_actions+0x7d0>
    810c:      	mov	w8, #0x3                // =3
    8110:      	add	x9, sp, #0x88
    8114:      	ldr	x0, [x0]
    8118:      	add	x1, sp, #0x88
    811c:      	blr	x8
    8120:      	b	0x7b24 <generic_tracepoint_actions+0x2f4>
    8124:      	mov	w8, #0x2                // =2
    8128:      	add	x9, sp, #0xa8
    812c:      	add	x10, sp, #0x78
    8130:      	add	x1, sp, #0x78
    8134:      	add	x2, sp, #0xa8
    8138:      	mov	x0, x29
    813c:      	mov	w3, #0x1                // =1
    8140:      	blr	x8
    8144:      	cbz	x0, 0x7d70 <generic_tracepoint_actions+0x540>
    8148:      	mov	x29, x0
    814c:      	adrp	x20, 0x8000 <generic_tracepoint_actions+0x7d0>
    8150:      	add	x9, sp, #0x68
    8154:      	add	x1, sp, #0x68
    8158:      	neg	w8, w29
    815c:      	strh	w8, [sp, #0x68]
    8160:      	mov	w8, #0x3                // =3
    8164:      	strh	w8, [sp, #0x6a]
    8168:      	mov	x8, #0x3b               // =59
    816c:      	movk	x8, #0x2, lsl #32
    8170:      	stur	x8, [sp, #0x6c]
    8174:      	mov	w8, #0x1                // =1
    8178:      	ldr	x20, [x20]
    817c:      	mov	x0, x20
    8180:      	blr	x8
    8184:      	cbz	x0, 0x849c <generic_tracepoint_actions+0xc6c>
    8188:      	ldr	w8, [x0]
    818c:      	add	w8, w8, #0x1
    8190:      	str	w8, [x0]
    8194:      	b	0x84c4 <generic_tracepoint_actions+0xc94>
    8198:      	ldr	w8, [x21, #0x10]
    819c:      	b	0x81a4 <generic_tracepoint_actions+0x974>
    81a0:      	mov	x8, xzr
    81a4:      	ldr	x9, [sp, #0x8]
    81a8:      	ldr	x25, [sp, #0x40]
    81ac:      	mov	w1, #0xc8               // =200
    81b0:      	add	x0, x9, #0x18
    81b4:      	str	x8, [x9, #0x10]
    81b8:      	mov	w8, #0x4                // =4
    81bc:      	mov	w9, #0xc8               // =200
    81c0:      	str	x0, [sp, #0x18]
    81c4:      	blr	x8
    81c8:      	mov	w8, #0x5e78             // =24184
    81cc:      	mov	x22, xzr
    81d0:      	str	wzr, [sp, #0x24]
    81d4:      	add	x20, x21, x8
    81d8:      	b	0x81f0 <generic_tracepoint_actions+0x9c0>
    81dc:      	nop
    81e0:      	add	x22, x22, #0x4
    81e4:      	add	x20, x20, #0x8
    81e8:      	cmp	x22, #0x14
    81ec:      	b.eq	0x8314 <generic_tracepoint_actions+0xae4>
    81f0:      	str	wzr, [sp, #0x88]
    81f4:      	mov	w8, #0x1                // =1
    81f8:      	add	x9, sp, #0x88
    81fc:      	add	x1, sp, #0x88
    8200:      	mov	x0, x24
    8204:      	blr	x8
    8208:      	cbz	x0, 0x8314 <generic_tracepoint_actions+0xae4>
    820c:      	mov	w8, #0x5ef8             // =24312
    8210:      	add	x1, x0, x8
    8214:      	adrp	x0, 0x8000 <generic_tracepoint_actions+0x7d0>
    8218:      	mov	w8, #0x1                // =1
    821c:      	ldr	x0, [x0]
    8220:      	blr	x8
    8224:      	cbz	x0, 0x8314 <generic_tracepoint_actions+0xae4>
    8228:      	add	x8, x0, x22
    822c:      	ldr	w8, [x8, #0x40]
    8230:      	cmn	w8, #0x1
    8234:      	b.eq	0x8314 <generic_tracepoint_actions+0xae4>
    8238:      	ldr	x8, [x20]
    823c:      	ldr	w9, [x21, #0x4]
    8240:      	cmp	x8, x9
    8244:      	b.ge	0x8314 <generic_tracepoint_actions+0xae4>
    8248:      	cmp	x22, #0x10
    824c:      	b.eq	0x82ac <generic_tracepoint_actions+0xa7c>
    8250:      	str	wzr, [sp, #0x88]
    8254:      	mov	w8, #0x1                // =1
    8258:      	add	x9, sp, #0x88
    825c:      	add	x1, sp, #0x88
    8260:      	mov	x0, x24
    8264:      	blr	x8
    8268:      	cbz	x0, 0x82a8 <generic_tracepoint_actions+0xa78>
    826c:      	mov	w8, #0x5ef8             // =24312
    8270:      	add	x1, x0, x8
    8274:      	adrp	x0, 0x8000 <generic_tracepoint_actions+0x7d0>
    8278:      	mov	w8, #0x1                // =1
    827c:      	ldr	x0, [x0]
    8280:      	blr	x8
    8284:      	cbz	x0, 0x82a8 <generic_tracepoint_actions+0xa78>
    8288:      	add	x8, x0, x22
    828c:      	ldr	w9, [x8, #0x44]
    8290:      	ldr	x8, [x20]
    8294:      	cmn	w9, #0x1
    8298:      	b.eq	0x82ac <generic_tracepoint_actions+0xa7c>
    829c:      	ldr	w9, [x20, #0x8]
    82a0:      	sub	w9, w9, w8
    82a4:      	b	0x82b8 <generic_tracepoint_actions+0xa88>
    82a8:      	ldr	x8, [x20]
    82ac:      	ldr	w9, [x21, #0x4]
    82b0:      	sub	w9, w9, w8
    82b4:      	add	w9, w9, #0x4
    82b8:      	cmp	w9, #0x1
    82bc:      	b.lt	0x81e0 <generic_tracepoint_actions+0x9b0>
    82c0:      	mov	w10, #0x3ffc            // =16380
    82c4:      	cmp	w9, #0x28
    82c8:      	add	w8, w8, w10
    82cc:      	mov	w10, #0x28              // =40
    82d0:      	csel	w24, w9, w10, lt
    82d4:      	ldr	w9, [sp, #0x24]
    82d8:      	and	x8, x8, #0x3fff
    82dc:      	add	x8, x21, x8
    82e0:      	mov	w1, w24
    82e4:      	add	x2, x8, #0x90
    82e8:      	mov	w8, #0x4                // =4
    82ec:      	and	w25, w9, #0xff
    82f0:      	ldr	x9, [sp, #0x18]
    82f4:      	add	x0, x9, x25
    82f8:      	blr	x8
    82fc:      	add	w8, w24, w25
    8300:      	adrp	x24, 0x8000 <generic_tracepoint_actions+0x7d0>
    8304:      	str	w8, [sp, #0x24]
    8308:      	ldr	x24, [x24]
    830c:      	ldr	x25, [sp, #0x40]
    8310:      	b	0x81e0 <generic_tracepoint_actions+0x9b0>
    8314:      	adrp	x0, 0x8000 <generic_tracepoint_actions+0x7d0>
    8318:      	mov	w8, #0x1                // =1
    831c:      	ldr	x0, [x0]
    8320:      	ldr	x1, [sp, #0x8]
    8324:      	blr	x8
    8328:      	ldr	x22, [sp, #0x50]
    832c:      	cbz	x0, 0x8358 <generic_tracepoint_actions+0xb28>
    8330:      	ldr	x9, [sp, #0x68]
    8334:      	ldr	x11, [sp, #0x10]
    8338:      	mov	x10, #-0x4240           // =-16960
    833c:      	movk	x10, #0xfff0, lsl #16
    8340:      	ldr	x8, [x0]
    8344:      	madd	x9, x11, x10, x9
    8348:      	cmp	x8, x9
    834c:      	b.ls	0x8358 <generic_tracepoint_actions+0xb28>
    8350:      	str	wzr, [sp, #0x3c]
    8354:      	b	0x837c <generic_tracepoint_actions+0xb4c>
    8358:      	adrp	x0, 0x8000 <generic_tracepoint_actions+0x7d0>
    835c:      	mov	x3, xzr
    8360:      	mov	w8, #0x2                // =2
    8364:      	ldr	x0, [x0]
    8368:      	ldr	x1, [sp, #0x8]
    836c:      	add	x9, sp, #0x68
    8370:      	add	x2, sp, #0x68
    8374:      	blr	x8
    8378:      	ldr	x25, [sp, #0x40]
    837c:      	add	w8, w29, #0x3
    8380:      	add	x20, sp, #0x64
    8384:      	add	x8, x22, w8, uxtw #2
    8388:      	ldr	w8, [x8, #0x4]
    838c:      	cbz	w8, 0x83b8 <generic_tracepoint_actions+0xb88>
    8390:      	ldrb	w8, [x21, #0x1]
    8394:      	adrp	x1, 0x8000 <generic_tracepoint_actions+0x7d0>
    8398:      	mov	x2, xzr
    839c:      	mov	x0, x25
    83a0:      	orr	w8, w8, #0x2
    83a4:      	strb	w8, [x21, #0x1]
    83a8:      	mov	w8, #0x1b               // =27
    83ac:      	ldr	x1, [x1]
    83b0:      	blr	x8
    83b4:      	str	x0, [x21, #0x80]
    83b8:      	add	w29, w29, #0x4
    83bc:      	add	x8, x22, w29, uxtw #2
    83c0:      	ldr	w8, [x8, #0x4]
    83c4:      	cbz	w8, 0x7e00 <generic_tracepoint_actions+0x5d0>
    83c8:      	ldrb	w8, [x21, #0x1]
    83cc:      	adrp	x1, 0x8000 <generic_tracepoint_actions+0x7d0>
    83d0:      	mov	w9, #0x100              // =256
    83d4:      	mov	x0, x25
    83d8:      	mov	w2, #0x100              // =256
    83dc:      	orr	w8, w8, #0x4
    83e0:      	strb	w8, [x21, #0x1]
    83e4:      	mov	w8, #0x1b               // =27
    83e8:      	ldr	x1, [x1]
    83ec:      	blr	x8
    83f0:      	str	x0, [x21, #0x88]
    83f4:      	b	0x7e00 <generic_tracepoint_actions+0x5d0>
    83f8:      	add	x9, x21, x9, lsl #3
    83fc:      	ldr	x9, [x9, #0x5e78]
    8400:      	and	x9, x9, #0x7ff
    8404:      	add	x9, x21, x9
    8408:      	ldr	x9, [x9, #0x90]
    840c:      	b	0x7cd4 <generic_tracepoint_actions+0x4a4>
    8410:      	mov	w8, #0x1                // =1
    8414:      	adrp	x0, 0x8000 <generic_tracepoint_actions+0x7d0>
    8418:      	mov	x3, xzr
    841c:      	str	w8, [sp, #0x98]
    8420:      	mov	w8, #0x2                // =2
    8424:      	add	x9, sp, #0x98
    8428:      	add	x10, sp, #0x68
    842c:      	ldr	x0, [x0]
    8430:      	add	x1, sp, #0x68
    8434:      	add	x2, sp, #0x98
    8438:      	blr	x8
    843c:      	cbz	w22, 0x7bd0 <generic_tracepoint_actions+0x3a0>
    8440:      	adrp	x0, 0x8000 <generic_tracepoint_actions+0x7d0>
    8444:      	mov	w8, #0x1                // =1
    8448:      	add	x9, sp, #0x88
    844c:      	ldr	x0, [x0]
    8450:      	add	x1, sp, #0x88
    8454:      	blr	x8
    8458:      	cbz	x0, 0x7bd0 <generic_tracepoint_actions+0x3a0>
    845c:      	ldr	w8, [sp, #0xac]
    8460:      	ldaxr	w9, [x0]
    8464:      	add	w9, w9, w8
    8468:      	stlxr	w10, w9, [x0]
    846c:      	cbnz	w10, 0x8460 <generic_tracepoint_actions+0xc30>
    8470:      	b	0x7bd0 <generic_tracepoint_actions+0x3a0>
    8474:      	mov	w8, #0x1                // =1
    8478:      	mov	x3, xzr
    847c:      	add	x9, sp, #0x78
    8480:      	str	w8, [sp, #0x78]
    8484:      	mov	w8, #0x2                // =2
    8488:      	add	x1, sp, #0x68
    848c:      	add	x2, sp, #0x78
    8490:      	mov	x0, x20
    8494:      	blr	x8
    8498:      	b	0x7d88 <generic_tracepoint_actions+0x558>
    849c:      	mov	w8, #0x1                // =1
    84a0:      	mov	x3, xzr
    84a4:      	add	x9, sp, #0xac
    84a8:      	str	w8, [sp, #0xac]
    84ac:      	mov	w8, #0x2                // =2
    84b0:      	add	x10, sp, #0x68
    84b4:      	add	x1, sp, #0x68
    84b8:      	add	x2, sp, #0xac
    84bc:      	mov	x0, x20
    84c0:      	blr	x8
    84c4:      	cbz	w29, 0x7d70 <generic_tracepoint_actions+0x540>
    84c8:      	adrp	x0, 0x8000 <generic_tracepoint_actions+0x7d0>
    84cc:      	mov	w8, #0x1                // =1
    84d0:      	add	x9, sp, #0x78
    84d4:      	ldr	x0, [x0]
    84d8:      	add	x1, sp, #0x78
    84dc:      	blr	x8
    84e0:      	cbz	x0, 0x7d70 <generic_tracepoint_actions+0x540>
    84e4:      	ldr	w8, [sp, #0xa8]
    84e8:      	ldaxr	w9, [x0]
    84ec:      	add	w9, w9, w8
    84f0:      	stlxr	w10, w9, [x0]
    84f4:      	cbnz	w10, 0x84e8 <generic_tracepoint_actions+0xcb8>
    84f8:      	b	0x7d70 <generic_tracepoint_actions+0x540>
    84fc:      	ldr	w8, [sp, #0x3c]
    8500:      	cbz	w8, 0x8520 <generic_tracepoint_actions+0xcf0>
    8504:      	adrp	x1, 0x8000 <generic_tracepoint_actions+0x7d0>
    8508:      	mov	w8, #0x5                // =5
    850c:      	mov	w9, #0xc                // =12
    8510:      	ldr	x1, [x1]
    8514:      	mov	x0, x25
    8518:      	mov	w2, #0x5                // =5
    851c:      	blr	x9
    8520:      	ldp	x20, x19, [sp, #0xe0]
    8524:      	mov	w0, wzr
    8528:      	ldr	x29, [sp, #0xa0]
    852c:      	ldp	x22, x21, [sp, #0xd0]
    8530:      	ldp	x24, x23, [sp, #0xc0]
    8534:      	ldp	x30, x25, [sp, #0xb0]
    8538:      	add	sp, sp, #0xf0
    853c:      	ret

0000000000008540 <generic_tracepoint_output>:
    8540:      	sub	sp, sp, #0xc0
    8544:      	str	x29, [sp, #0x70]
    8548:      	stp	x30, x25, [sp, #0x80]
    854c:      	stp	x24, x23, [sp, #0x90]
    8550:      	stp	x22, x21, [sp, #0xa0]
    8554:      	stp	x20, x19, [sp, #0xb0]
    8558:      	mov	x19, x0
    855c:      	str	wzr, [sp, #0x4]
    8560:      	adrp	x0, 0x8000 <generic_tracepoint_actions+0x7d0>
    8564:      	mov	w8, #0x1                // =1
    8568:      	ldr	x0, [x0]
    856c:      	add	x9, sp, #0x4
    8570:      	add	x1, sp, #0x4
    8574:      	blr	x8
    8578:      	cbz	x0, 0x89d8 <generic_tracepoint_output+0x498>
    857c:      	adrp	x21, 0x8000 <generic_tracepoint_actions+0x7d0>
    8580:      	ldr	x8, [x0, #0x5ee8]
    8584:      	mov	x20, x0
    8588:      	ldr	x21, [x21]
    858c:      	cbz	x8, 0x8818 <generic_tracepoint_output+0x2d8>
    8590:      	mov	w8, #0xe                // =14
    8594:      	blr	x8
    8598:      	mov	w8, #0x23               // =35
    859c:      	lsr	x22, x0, #32
    85a0:      	blr	x8
    85a4:      	str	w22, [sp, #0x28]
    85a8:      	mov	w8, #0x1                // =1
    85ac:      	add	x9, sp, #0x28
    85b0:      	mov	x23, x0
    85b4:      	add	x1, sp, #0x28
    85b8:      	mov	x0, x21
    85bc:      	blr	x8
    85c0:      	cbz	x0, 0x8818 <generic_tracepoint_output+0x2d8>
    85c4:      	add	x2, x23, #0xb50
    85c8:      	mov	w29, #0x8               // =8
    85cc:      	add	x8, sp, #0x78
    85d0:      	mov	w9, #0x4                // =4
    85d4:      	mov	x22, x0
    85d8:      	add	x24, x0, #0x28
    85dc:      	add	x0, sp, #0x78
    85e0:      	mov	w1, #0x8                // =8
    85e4:      	mov	w25, #0x4               // =4
    85e8:      	blr	x9
    85ec:      	ldr	x8, [sp, #0x78]
    85f0:      	mov	w9, #0x48               // =72
    85f4:      	add	x10, sp, #0x28
    85f8:      	mov	w11, #0x4               // =4
    85fc:      	ldr	x2, [sp, #0x78]
    8600:      	add	x0, sp, #0x28
    8604:      	mov	w1, #0x48               // =72
    8608:      	blr	x11
    860c:      	ldr	x8, [sp, #0x30]
    8610:      	mov	w9, #0x4                // =4
    8614:      	mov	x0, x24
    8618:      	mov	w1, #0x4                // =4
    861c:      	add	x8, x8, #0x218
    8620:      	ldr	x8, [sp, #0x30]
    8624:      	add	x2, x8, #0x218
    8628:      	blr	x9
    862c:      	ldr	x8, [sp, #0x38]
    8630:      	add	x0, x22, #0x2c
    8634:      	mov	w9, #0x4                // =4
    8638:      	mov	w1, #0x4                // =4
    863c:      	add	x8, x8, #0x4d8
    8640:      	ldr	x8, [sp, #0x38]
    8644:      	add	x2, x8, #0x4d8
    8648:      	blr	x9
    864c:      	ldr	x8, [sp, #0x40]
    8650:      	add	x0, x22, #0x30
    8654:      	mov	w9, #0x4                // =4
    8658:      	mov	w1, #0x4                // =4
    865c:      	add	x8, x8, #0x58
    8660:      	ldr	x8, [sp, #0x40]
    8664:      	add	x2, x8, #0x58
    8668:      	blr	x9
    866c:      	str	xzr, [sp, #0x20]
    8670:      	add	x2, x23, #0x938
    8674:      	add	x8, sp, #0x20
    8678:      	add	x0, sp, #0x20
    867c:      	mov	w1, #0x8                // =8
    8680:      	blr	x25
    8684:      	ldr	x8, [sp, #0x20]
    8688:      	cbz	x8, 0x870c <generic_tracepoint_output+0x1cc>
    868c:      	str	wzr, [sp, #0x1c]
    8690:      	add	x8, x8, #0x4
    8694:      	add	x9, sp, #0x1c
    8698:      	mov	w10, #0x4               // =4
    869c:      	add	x0, sp, #0x1c
    86a0:      	mov	w1, #0x4                // =4
    86a4:      	mov	w24, #0x4               // =4
    86a8:      	ldr	x8, [sp, #0x20]
    86ac:      	add	x2, x8, #0x4
    86b0:      	blr	x10
    86b4:      	ldr	x8, [sp, #0x20]
    86b8:      	ldrsw	x9, [sp, #0x1c]
    86bc:      	add	x10, sp, #0x8
    86c0:      	mov	w11, #0x4               // =4
    86c4:      	add	x0, sp, #0x8
    86c8:      	mov	w1, #0x10               // =16
    86cc:      	add	x8, x8, x9, lsl #4
    86d0:      	mov	w9, #0x10               // =16
    86d4:      	add	x8, x8, #0x80
    86d8:      	ldr	x8, [sp, #0x20]
    86dc:      	ldrsw	x9, [sp, #0x1c]
    86e0:      	add	x8, x8, x9, lsl #4
    86e4:      	add	x2, x8, #0x80
    86e8:      	blr	x11
    86ec:      	ldr	x8, [sp, #0x10]
    86f0:      	add	x0, x22, #0x34
    86f4:      	mov	w1, #0x4                // =4
    86f8:      	add	x8, x8, #0x158
    86fc:      	ldr	x8, [sp, #0x10]
    8700:      	add	x2, x8, #0x158
    8704:      	blr	x24
    8708:      	b	0x8710 <generic_tracepoint_output+0x1d0>
    870c:      	str	wzr, [x22, #0x34]
    8710:      	ldr	x8, [sp, #0x48]
    8714:      	add	x0, x22, #0x38
    8718:      	mov	w9, #0x4                // =4
    871c:      	mov	w1, #0x4                // =4
    8720:      	mov	w24, #0x4               // =4
    8724:      	add	x8, x8, #0x158
    8728:      	ldr	x8, [sp, #0x48]
    872c:      	add	x2, x8, #0x158
    8730:      	blr	x9
    8734:      	ldr	x8, [sp, #0x50]
    8738:      	add	x0, x22, #0x3c
    873c:      	mov	w9, #0x4                // =4
    8740:      	mov	w1, #0x4                // =4
    8744:      	add	x8, x8, #0x118
    8748:      	ldr	x8, [sp, #0x50]
    874c:      	add	x2, x8, #0x118
    8750:      	blr	x9
    8754:      	ldr	x8, [sp, #0x58]
    8758:      	add	x0, x22, #0x40
    875c:      	mov	w9, #0x4                // =4
    8760:      	mov	w1, #0x4                // =4
    8764:      	add	x8, x8, #0x98
    8768:      	ldr	x8, [sp, #0x58]
    876c:      	add	x2, x8, #0x98
    8770:      	blr	x9
    8774:      	ldr	x8, [sp, #0x60]
    8778:      	add	x0, x22, #0x44
    877c:      	mov	w9, #0x4                // =4
    8780:      	mov	w1, #0x4                // =4
    8784:      	add	x8, x8, #0x98
    8788:      	ldr	x8, [sp, #0x60]
    878c:      	add	x2, x8, #0x98
    8790:      	blr	x9
    8794:      	ldr	x8, [sp, #0x68]
    8798:      	add	x0, x22, #0x48
    879c:      	mov	w9, #0x4                // =4
    87a0:      	mov	w1, #0x4                // =4
    87a4:      	add	x8, x8, #0x58
    87a8:      	ldr	x8, [sp, #0x68]
    87ac:      	add	x2, x8, #0x58
    87b0:      	blr	x9
    87b4:      	str	xzr, [sp, #0x8]
    87b8:      	str	xzr, [sp, #0x20]
    87bc:      	add	x2, x23, #0xae0
    87c0:      	mov	w23, #0x8               // =8
    87c4:      	add	x8, sp, #0x8
    87c8:      	mov	w9, #0x4                // =4
    87cc:      	add	x0, sp, #0x8
    87d0:      	mov	w1, #0x8                // =8
    87d4:      	blr	x9
    87d8:      	ldr	x8, [sp, #0x8]
    87dc:      	add	x9, sp, #0x20
    87e0:      	mov	w10, #0x4               // =4
    87e4:      	add	x0, sp, #0x20
    87e8:      	mov	w1, #0x8                // =8
    87ec:      	add	x8, x8, #0x90
    87f0:      	ldr	x8, [sp, #0x8]
    87f4:      	add	x2, x8, #0x90
    87f8:      	blr	x10
    87fc:      	ldr	x8, [sp, #0x20]
    8800:      	add	x0, x22, #0x4c
    8804:      	mov	w1, #0x4                // =4
    8808:      	add	x8, x8, #0x158
    880c:      	ldr	x8, [sp, #0x20]
    8810:      	add	x2, x8, #0x158
    8814:      	blr	x24
    8818:      	ldr	x8, [x20, #0x5ef0]
    881c:      	cbz	x8, 0x88b8 <generic_tracepoint_output+0x378>
    8820:      	mov	w8, #0xe                // =14
    8824:      	blr	x8
    8828:      	mov	w8, #0x23               // =35
    882c:      	lsr	x23, x0, #32
    8830:      	blr	x8
    8834:      	str	w23, [sp, #0x28]
    8838:      	mov	w8, #0x1                // =1
    883c:      	add	x9, sp, #0x28
    8840:      	mov	x22, x0
    8844:      	add	x1, sp, #0x28
    8848:      	mov	x0, x21
    884c:      	blr	x8
    8850:      	cbz	x0, 0x88b8 <generic_tracepoint_output+0x378>
    8854:      	add	x2, x22, #0xae0
    8858:      	mov	w22, #0x8               // =8
    885c:      	add	x8, sp, #0x28
    8860:      	mov	w9, #0x4                // =4
    8864:      	add	x21, x0, #0x50
    8868:      	mov	x24, x0
    886c:      	add	x0, sp, #0x28
    8870:      	mov	w1, #0x8                // =8
    8874:      	mov	w23, #0x4               // =4
    8878:      	blr	x9
    887c:      	ldr	x25, [sp, #0x28]
    8880:      	add	x0, x24, #0x58
    8884:      	mov	w8, #0x4                // =4
    8888:      	mov	w1, #0x8                // =8
    888c:      	add	x2, x25, #0x40
    8890:      	blr	x8
    8894:      	add	x0, x24, #0x60
    8898:      	add	x2, x25, #0x30
    889c:      	mov	w8, #0x4                // =4
    88a0:      	mov	w1, #0x8                // =8
    88a4:      	blr	x8
    88a8:      	add	x2, x25, #0x38
    88ac:      	mov	x0, x21
    88b0:      	mov	w1, #0x8                // =8
    88b4:      	blr	x23
    88b8:      	ldr	w8, [x20, #0x4]
    88bc:      	mov	w9, #0x2328             // =9000
    88c0:      	adrp	x1, 0x8000 <generic_tracepoint_actions+0x7d0>
    88c4:      	mov	x0, x19
    88c8:      	ldr	x1, [x1]
    88cc:      	mov	w2, #-0x1               // =-1
    88d0:      	mov	x3, x20
    88d4:      	add	w8, w8, #0x90
    88d8:      	and	w8, w8, #0x7fff
    88dc:      	cmp	w8, w9
    88e0:      	csel	w4, w8, w9, lo
    88e4:      	mov	w8, #-0x1               // =-1
    88e8:      	mov	w9, #0x19               // =25
    88ec:      	blr	x9
    88f0:      	tbnz	x0, #0x3f, 0x8934 <generic_tracepoint_output+0x3f4>
    88f4:      	str	wzr, [sp, #0x28]
    88f8:      	adrp	x0, 0x8000 <generic_tracepoint_actions+0x7d0>
    88fc:      	mov	w8, #0x1                // =1
    8900:      	add	x9, sp, #0x28
    8904:      	ldr	x0, [x0]
    8908:      	add	x1, sp, #0x28
    890c:      	blr	x8
    8910:      	cbz	x0, 0x89d8 <generic_tracepoint_output+0x498>
    8914:      	add	x8, x0, #0x8
    8918:      	nop
    891c:      	nop
    8920:      	ldaxr	x9, [x8]
    8924:      	add	x9, x9, #0x1
    8928:      	stlxr	w10, x9, [x8]
    892c:      	cbnz	w10, 0x8920 <generic_tracepoint_output+0x3e0>
    8930:      	b	0x89d8 <generic_tracepoint_output+0x498>
    8934:      	mov	x19, x0
    8938:      	str	wzr, [sp, #0x28]
    893c:      	adrp	x0, 0x8000 <generic_tracepoint_actions+0x7d0>
    8940:      	mov	w8, #0x1                // =1
    8944:      	ldr	x0, [x0]
    8948:      	add	x9, sp, #0x28
    894c:      	add	x1, sp, #0x28
    8950:      	blr	x8
    8954:      	cbz	x0, 0x89d8 <generic_tracepoint_output+0x498>
    8958:      	mov	x8, x19
    895c:      	cmn	x19, #0xc
    8960:      	b.gt	0x8984 <generic_tracepoint_output+0x444>
    8964:      	cmn	x8, #0x1c
    8968:      	b.eq	0x89a4 <generic_tracepoint_output+0x464>
    896c:      	cmn	x8, #0x16
    8970:      	b.eq	0x89bc <generic_tracepoint_output+0x47c>
    8974:      	cmn	x8, #0x10
    8978:      	b.ne	0x89b4 <generic_tracepoint_output+0x474>
    897c:      	add	x8, x0, #0x328
    8980:      	b	0x89c8 <generic_tracepoint_output+0x488>
    8984:      	cmn	x8, #0xb
    8988:      	b.eq	0x89ac <generic_tracepoint_output+0x46c>
    898c:      	cmn	x8, #0x7
    8990:      	b.eq	0x89c4 <generic_tracepoint_output+0x484>
    8994:      	cmn	x8, #0x2
    8998:      	b.ne	0x89b4 <generic_tracepoint_output+0x474>
    899c:      	add	x8, x0, #0x318
    89a0:      	b	0x89c8 <generic_tracepoint_output+0x488>
    89a4:      	add	x8, x0, #0x338
    89a8:      	b	0x89c8 <generic_tracepoint_output+0x488>
    89ac:      	add	x8, x0, #0x340
    89b0:      	b	0x89c8 <generic_tracepoint_output+0x488>
    89b4:      	add	x8, x0, #0x310
    89b8:      	b	0x89c8 <generic_tracepoint_output+0x488>
    89bc:      	add	x8, x0, #0x330
    89c0:      	b	0x89c8 <generic_tracepoint_output+0x488>
    89c4:      	add	x8, x0, #0x320
    89c8:      	ldaxr	x9, [x8]
    89cc:      	add	x9, x9, #0x1
    89d0:      	stlxr	w10, x9, [x8]
    89d4:      	cbnz	w10, 0x89c8 <generic_tracepoint_output+0x488>
    89d8:      	ldp	x20, x19, [sp, #0xb0]
    89dc:      	mov	w0, wzr
    89e0:      	ldr	x29, [sp, #0x70]
    89e4:      	ldp	x22, x21, [sp, #0xa0]
    89e8:      	ldp	x24, x23, [sp, #0x90]
    89ec:      	ldp	x30, x25, [sp, #0x80]
    89f0:      	add	sp, sp, #0xc0
    89f4:      	ret

Disassembly of section tracepoint/generic_tracepoint:

0000000000000000 <generic_tracepoint_event>:
       0:      	sub	sp, sp, #0xd0
       4:      	stp	x30, x25, [sp, #0x90]
       8:      	stp	x24, x23, [sp, #0xa0]
       c:      	stp	x22, x21, [sp, #0xb0]
      10:      	stp	x20, x19, [sp, #0xc0]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0xc]
      1c:      	adrp	x0, 0x0 <generic_tracepoint_event>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0xc
      2c:      	add	x1, sp, #0xc
      30:      	blr	x8
      34:      	cbz	x0, 0x3184 <generic_tracepoint_event+0x3184>
      38:      	mov	x20, x0
      3c:      	adrp	x0, 0x0 <generic_tracepoint_event>
      40:      	mov	w8, #0x1                // =1
      44:      	ldr	x0, [x0]
      48:      	add	x9, sp, #0xc
      4c:      	add	x1, sp, #0xc
      50:      	blr	x8
      54:      	cbz	x0, 0x3184 <generic_tracepoint_event+0x3184>
      58:      	ldr	w8, [x0, #0x64]
      5c:      	mov	x21, x0
      60:      	str	w8, [sp, #0x1c]
      64:      	cbz	w8, 0x220 <generic_tracepoint_event+0x220>
      68:      	adrp	x22, 0x0 <generic_tracepoint_event>
      6c:      	mov	w8, #0x1                // =1
      70:      	add	x9, sp, #0x1c
      74:      	ldr	x22, [x22]
      78:      	add	x1, sp, #0x1c
      7c:      	mov	x0, x22
      80:      	blr	x8
      84:      	cbz	x0, 0x3184 <generic_tracepoint_event+0x3184>
      88:      	mov	x23, x0
      8c:      	str	wzr, [sp, #0x84]
      90:      	adrp	x0, 0x0 <generic_tracepoint_event>
      94:      	mov	w8, #0x1                // =1
      98:      	ldr	x0, [x0]
      9c:      	add	x9, sp, #0x84
      a0:      	add	x1, sp, #0x84
      a4:      	blr	x8
      a8:      	cbz	x0, 0xd4 <generic_tracepoint_event+0xd4>
      ac:      	ldr	x8, [x0, #0x20]
      b0:      	mov	w9, #0x7270             // =29296
      b4:      	movk	w9, #0x6367, lsl #16
      b8:      	cmp	x8, x9
      bc:      	b.ne	0xdc <generic_tracepoint_event+0xdc>
      c0:      	mov	w8, #0x50               // =80
      c4:      	blr	x8
      c8:      	str	x0, [sp, #0x30]
      cc:      	cbnz	x0, 0x1d0 <generic_tracepoint_event+0x1d0>
      d0:      	b	0x3184 <generic_tracepoint_event+0x3184>
      d4:      	mov	w24, wzr
      d8:      	b	0xe0 <generic_tracepoint_event+0xe0>
      dc:      	ldr	w24, [x0, #0x10]
      e0:      	mov	w8, #0x23               // =35
      e4:      	blr	x8
      e8:      	str	xzr, [sp, #0x88]
      ec:      	add	x2, x0, #0xcd0
      f0:      	mov	w8, #0x8                // =8
      f4:      	mov	w9, #0x71               // =113
      f8:      	add	x10, sp, #0x20
      fc:      	add	x0, sp, #0x20
     100:      	mov	w1, #0x8                // =8
     104:      	blr	x9
     108:      	ldr	x8, [sp, #0x20]
     10c:      	cbz	x8, 0x164 <generic_tracepoint_event+0x164>
     110:      	cmp	w24, #0xb
     114:      	b.hi	0x164 <generic_tracepoint_event+0x164>
     118:      	ubfiz	x9, x24, #3, #32
     11c:      	mov	w10, #0x8               // =8
     120:      	mov	w11, #0x71              // =113
     124:      	add	x12, sp, #0x38
     128:      	add	x0, sp, #0x38
     12c:      	mov	w1, #0x8                // =8
     130:      	add	x8, x8, x9
     134:      	ldr	x8, [sp, #0x20]
     138:      	add	x2, x8, x9
     13c:      	blr	x11
     140:      	ldr	x8, [sp, #0x38]
     144:      	cbz	x8, 0x164 <generic_tracepoint_event+0x164>
     148:      	mov	w9, #0x8                // =8
     14c:      	mov	w10, #0x71              // =113
     150:      	add	x11, sp, #0x88
     154:      	ldr	x2, [sp, #0x38]
     158:      	add	x0, sp, #0x88
     15c:      	mov	w1, #0x8                // =8
     160:      	blr	x10
     164:      	ldr	x8, [sp, #0x88]
     168:      	cbz	x8, 0x3184 <generic_tracepoint_event+0x3184>
     16c:      	str	xzr, [sp, #0x38]
     170:      	add	x2, x8, #0x100
     174:      	mov	w8, #0x8                // =8
     178:      	mov	w9, #0x71               // =113
     17c:      	add	x10, sp, #0x38
     180:      	add	x0, sp, #0x38
     184:      	mov	w1, #0x8                // =8
     188:      	blr	x9
     18c:      	ldr	x8, [sp, #0x38]
     190:      	str	xzr, [sp, #0x38]
     194:      	cbz	x8, 0x1c4 <generic_tracepoint_event+0x1c4>
     198:      	add	x2, x8, #0x60
     19c:      	mov	w8, #0x8                // =8
     1a0:      	mov	w9, #0x71               // =113
     1a4:      	add	x10, sp, #0x38
     1a8:      	add	x0, sp, #0x38
     1ac:      	mov	w1, #0x8                // =8
     1b0:      	blr	x9
     1b4:      	ldr	x0, [sp, #0x38]
     1b8:      	str	x0, [sp, #0x30]
     1bc:      	cbnz	x0, 0x1d0 <generic_tracepoint_event+0x1d0>
     1c0:      	b	0x3184 <generic_tracepoint_event+0x3184>
     1c4:      	mov	x0, xzr
     1c8:      	str	xzr, [sp, #0x30]
     1cc:      	cbz	xzr, 0x3184 <generic_tracepoint_event+0x3184>
     1d0:      	str	x0, [sp, #0x38]
     1d4:      	adrp	x0, 0x0 <generic_tracepoint_event>
     1d8:      	mov	w8, #0x1                // =1
     1dc:      	add	x9, sp, #0x38
     1e0:      	ldr	x0, [x0]
     1e4:      	add	x1, sp, #0x38
     1e8:      	blr	x8
     1ec:      	cbz	x0, 0x204 <generic_tracepoint_event+0x204>
     1f0:      	ldr	x8, [x0]
     1f4:      	str	x8, [sp, #0x10]
     1f8:      	cbz	x8, 0x208 <generic_tracepoint_event+0x208>
     1fc:      	str	x8, [sp, #0x30]
     200:      	b	0x208 <generic_tracepoint_event+0x208>
     204:      	str	xzr, [sp, #0x10]
     208:      	mov	w8, #0x1                // =1
     20c:      	add	x9, sp, #0x30
     210:      	add	x1, sp, #0x30
     214:      	mov	x0, x23
     218:      	blr	x8
     21c:      	cbz	x0, 0x42c <generic_tracepoint_event+0x42c>
     220:      	add	x23, x20, #0x5, lsl #12 // =0x5000
     224:      	mov	x22, xzr
     228:      	str	wzr, [x23, #0xef8]
     22c:      	ldr	w8, [x21]
     230:      	stp	x8, xzr, [x20, #0x60]
     234:      	ldrh	w8, [x21, #0x2c]
     238:      	ldr	w24, [x21, #0x4]
     23c:      	add	x2, x19, x8
     240:      	cmp	w24, #0xb
     244:      	b.gt	0x274 <generic_tracepoint_event+0x274>
     248:      	cmp	w24, #0x3
     24c:      	b.le	0x30c <generic_tracepoint_event+0x30c>
     250:      	cmp	w24, #0x6
     254:      	b.gt	0x480 <generic_tracepoint_event+0x480>
     258:      	cmp	w24, #0x4
     25c:      	b.eq	0x8c8 <generic_tracepoint_event+0x8c8>
     260:      	cmp	w24, #0x5
     264:      	b.eq	0x770 <generic_tracepoint_event+0x770>
     268:      	cmp	w24, #0x6
     26c:      	b.eq	0x328 <generic_tracepoint_event+0x328>
     270:      	b	0xb40 <generic_tracepoint_event+0xb40>
     274:      	cmp	w24, #0x1d
     278:      	b.le	0x39c <generic_tracepoint_event+0x39c>
     27c:      	cmp	w24, #0x25
     280:      	b.gt	0x4f8 <generic_tracepoint_event+0x4f8>
     284:      	cmp	w24, #0x1e
     288:      	b.eq	0x934 <generic_tracepoint_event+0x934>
     28c:      	cmp	w24, #0x1f
     290:      	b.eq	0x7e4 <generic_tracepoint_event+0x7e4>
     294:      	cmp	w24, #0x20
     298:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     29c:      	mov	w8, #0x1                // =1
     2a0:      	mov	w9, #0x4                // =4
     2a4:      	add	x10, sp, #0x88
     2a8:      	add	x0, sp, #0x88
     2ac:      	mov	w1, #0x1                // =1
     2b0:      	blr	x9
     2b4:      	cbz	x0, 0xab8 <generic_tracepoint_event+0xab8>
     2b8:      	neg	w8, w0
     2bc:      	adrp	x22, 0x0 <generic_tracepoint_event>
     2c0:      	mov	w9, #0x1                // =1
     2c4:      	strh	w8, [sp, #0x38]
     2c8:      	mov	w8, #0x7                // =7
     2cc:      	add	x1, sp, #0x38
     2d0:      	mov	w24, #0x1               // =1
     2d4:      	strh	w8, [sp, #0x3a]
     2d8:      	mov	x8, #0x73               // =115
     2dc:      	movk	x8, #0x4, lsl #32
     2e0:      	stur	x8, [sp, #0x3c]
     2e4:      	add	x8, sp, #0x38
     2e8:      	ldr	x22, [x22]
     2ec:      	mov	x0, x22
     2f0:      	blr	x9
     2f4:      	cbz	x0, 0xa94 <generic_tracepoint_event+0xa94>
     2f8:      	ldr	w8, [x0]
     2fc:      	add	w8, w8, #0x1
     300:      	str	w8, [x0]
     304:      	ldrb	w22, [sp, #0x88]
     308:      	b	0xb40 <generic_tracepoint_event+0xb40>
     30c:      	cmn	w24, #0xc
     310:      	b.le	0x584 <generic_tracepoint_event+0x584>
     314:      	add	w8, w24, #0xb
     318:      	cmp	w8, #0x2
     31c:      	b.lo	0x48c <generic_tracepoint_event+0x48c>
     320:      	cmp	w24, #0x2
     324:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     328:      	mov	w8, #0x8                // =8
     32c:      	mov	w9, #0x4                // =4
     330:      	add	x10, sp, #0x20
     334:      	add	x0, sp, #0x20
     338:      	mov	w1, #0x8                // =8
     33c:      	blr	x9
     340:      	cbz	x0, 0xae4 <generic_tracepoint_event+0xae4>
     344:      	neg	w8, w0
     348:      	adrp	x22, 0x0 <generic_tracepoint_event>
     34c:      	mov	w9, #0x1                // =1
     350:      	strh	w8, [sp, #0x38]
     354:      	mov	w8, #0x7                // =7
     358:      	add	x1, sp, #0x38
     35c:      	mov	w24, #0x1               // =1
     360:      	strh	w8, [sp, #0x3a]
     364:      	mov	x8, #0x81               // =129
     368:      	movk	x8, #0x4, lsl #32
     36c:      	stur	x8, [sp, #0x3c]
     370:      	add	x8, sp, #0x38
     374:      	ldr	x22, [x22]
     378:      	mov	x0, x22
     37c:      	blr	x9
     380:      	cbnz	x0, 0x924 <generic_tracepoint_event+0x924>
     384:      	str	w24, [sp, #0x88]
     388:      	mov	x3, xzr
     38c:      	mov	w8, #0x2                // =2
     390:      	add	x9, sp, #0x38
     394:      	add	x10, sp, #0x88
     398:      	b	0xad4 <generic_tracepoint_event+0xad4>
     39c:      	cmp	w24, #0x11
     3a0:      	b.le	0x598 <generic_tracepoint_event+0x598>
     3a4:      	cmp	w24, #0x12
     3a8:      	b.eq	0x768 <generic_tracepoint_event+0x768>
     3ac:      	cmp	w24, #0x1c
     3b0:      	b.eq	0x48c <generic_tracepoint_event+0x48c>
     3b4:      	cmp	w24, #0x1d
     3b8:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     3bc:      	mov	w8, #0x2                // =2
     3c0:      	mov	w9, #0x4                // =4
     3c4:      	add	x10, sp, #0x88
     3c8:      	add	x0, sp, #0x88
     3cc:      	mov	w1, #0x2                // =2
     3d0:      	blr	x9
     3d4:      	cbz	x0, 0xa60 <generic_tracepoint_event+0xa60>
     3d8:      	neg	w8, w0
     3dc:      	adrp	x22, 0x0 <generic_tracepoint_event>
     3e0:      	mov	w9, #0x1                // =1
     3e4:      	strh	w8, [sp, #0x38]
     3e8:      	mov	w8, #0x7                // =7
     3ec:      	add	x1, sp, #0x38
     3f0:      	mov	w24, #0x1               // =1
     3f4:      	strh	w8, [sp, #0x3a]
     3f8:      	mov	x8, #0x6c               // =108
     3fc:      	movk	x8, #0x4, lsl #32
     400:      	stur	x8, [sp, #0x3c]
     404:      	add	x8, sp, #0x38
     408:      	ldr	x22, [x22]
     40c:      	mov	x0, x22
     410:      	blr	x9
     414:      	cbz	x0, 0xa3c <generic_tracepoint_event+0xa3c>
     418:      	ldr	w8, [x0]
     41c:      	add	w8, w8, #0x1
     420:      	str	w8, [x0]
     424:      	ldrsh	x22, [sp, #0x88]
     428:      	b	0xb40 <generic_tracepoint_event+0xb40>
     42c:      	mov	x8, #-0x1               // =-1
     430:      	mov	w9, #0x1                // =1
     434:      	add	x1, sp, #0x10
     438:      	str	x8, [sp, #0x10]
     43c:      	add	x8, sp, #0x10
     440:      	mov	x0, x23
     444:      	mov	w24, #0x1               // =1
     448:      	blr	x9
     44c:      	cbz	x0, 0x3184 <generic_tracepoint_event+0x3184>
     450:      	str	w24, [sp, #0x1c]
     454:      	add	x8, sp, #0x1c
     458:      	add	x1, sp, #0x1c
     45c:      	mov	x0, x22
     460:      	blr	x24
     464:      	cbz	x0, 0x3184 <generic_tracepoint_event+0x3184>
     468:      	mov	w8, #0x1                // =1
     46c:      	add	x9, sp, #0x30
     470:      	add	x1, sp, #0x30
     474:      	blr	x8
     478:      	cbnz	x0, 0x3184 <generic_tracepoint_event+0x3184>
     47c:      	b	0x220 <generic_tracepoint_event+0x220>
     480:      	sub	w8, w24, #0xa
     484:      	cmp	w8, #0x2
     488:      	b.hs	0x6ec <generic_tracepoint_event+0x6ec>
     48c:      	mov	w8, #0x8                // =8
     490:      	mov	w9, #0x4                // =4
     494:      	add	x10, sp, #0x20
     498:      	add	x0, sp, #0x20
     49c:      	mov	w1, #0x8                // =8
     4a0:      	blr	x9
     4a4:      	cbz	x0, 0x6a8 <generic_tracepoint_event+0x6a8>
     4a8:      	neg	w8, w0
     4ac:      	adrp	x22, 0x0 <generic_tracepoint_event>
     4b0:      	mov	w9, #0x1                // =1
     4b4:      	strh	w8, [sp, #0x38]
     4b8:      	mov	w8, #0x7                // =7
     4bc:      	add	x1, sp, #0x38
     4c0:      	mov	w25, #0x1               // =1
     4c4:      	strh	w8, [sp, #0x3a]
     4c8:      	mov	x8, #0x45               // =69
     4cc:      	movk	x8, #0x4, lsl #32
     4d0:      	stur	x8, [sp, #0x3c]
     4d4:      	add	x8, sp, #0x38
     4d8:      	ldr	x22, [x22]
     4dc:      	mov	x0, x22
     4e0:      	blr	x9
     4e4:      	cbz	x0, 0x684 <generic_tracepoint_event+0x684>
     4e8:      	ldr	w8, [x0]
     4ec:      	add	w8, w8, #0x1
     4f0:      	str	w8, [x0]
     4f4:      	b	0x6a8 <generic_tracepoint_event+0x6a8>
     4f8:      	cmp	w24, #0x26
     4fc:      	b.eq	0x9a4 <generic_tracepoint_event+0x9a4>
     500:      	cmp	w24, #0x28
     504:      	b.eq	0x854 <generic_tracepoint_event+0x854>
     508:      	cmp	w24, #0x29
     50c:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     510:      	mov	w8, #0x8                // =8
     514:      	mov	w9, #0x4                // =4
     518:      	add	x10, sp, #0x20
     51c:      	add	x0, sp, #0x20
     520:      	mov	w1, #0x8                // =8
     524:      	blr	x9
     528:      	cbz	x0, 0xae4 <generic_tracepoint_event+0xae4>
     52c:      	neg	w8, w0
     530:      	adrp	x22, 0x0 <generic_tracepoint_event>
     534:      	mov	w9, #0x1                // =1
     538:      	strh	w8, [sp, #0x38]
     53c:      	mov	w8, #0x7                // =7
     540:      	add	x1, sp, #0x38
     544:      	mov	w24, #0x1               // =1
     548:      	strh	w8, [sp, #0x3a]
     54c:      	mov	x8, #0xa8               // =168
     550:      	movk	x8, #0x4, lsl #32
     554:      	stur	x8, [sp, #0x3c]
     558:      	add	x8, sp, #0x38
     55c:      	ldr	x22, [x22]
     560:      	mov	x0, x22
     564:      	blr	x9
     568:      	cbnz	x0, 0x924 <generic_tracepoint_event+0x924>
     56c:      	str	w24, [sp, #0x88]
     570:      	mov	x3, xzr
     574:      	mov	w8, #0x2                // =2
     578:      	add	x9, sp, #0x38
     57c:      	add	x10, sp, #0x88
     580:      	b	0xad4 <generic_tracepoint_event+0xad4>
     584:      	cmn	w24, #0xd
     588:      	b.eq	0x618 <generic_tracepoint_event+0x618>
     58c:      	cmn	w24, #0xc
     590:      	b.eq	0x5a8 <generic_tracepoint_event+0x5a8>
     594:      	b	0xb40 <generic_tracepoint_event+0xb40>
     598:      	cmp	w24, #0xc
     59c:      	b.eq	0x618 <generic_tracepoint_event+0x618>
     5a0:      	cmp	w24, #0xd
     5a4:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     5a8:      	mov	w8, #0x4                // =4
     5ac:      	add	x9, sp, #0x88
     5b0:      	add	x0, sp, #0x88
     5b4:      	mov	w1, #0x4                // =4
     5b8:      	blr	x8
     5bc:      	cbz	x0, 0xb3c <generic_tracepoint_event+0xb3c>
     5c0:      	neg	w8, w0
     5c4:      	adrp	x22, 0x0 <generic_tracepoint_event>
     5c8:      	mov	w9, #0x1                // =1
     5cc:      	strh	w8, [sp, #0x38]
     5d0:      	mov	w8, #0x7                // =7
     5d4:      	add	x1, sp, #0x38
     5d8:      	mov	w24, #0x1               // =1
     5dc:      	strh	w8, [sp, #0x3a]
     5e0:      	mov	x8, #0x5e               // =94
     5e4:      	movk	x8, #0x4, lsl #32
     5e8:      	stur	x8, [sp, #0x3c]
     5ec:      	add	x8, sp, #0x38
     5f0:      	ldr	x22, [x22]
     5f4:      	mov	x0, x22
     5f8:      	blr	x9
     5fc:      	cbnz	x0, 0x9fc <generic_tracepoint_event+0x9fc>
     600:      	str	w24, [sp, #0x20]
     604:      	mov	x3, xzr
     608:      	mov	w8, #0x2                // =2
     60c:      	add	x9, sp, #0x38
     610:      	add	x10, sp, #0x20
     614:      	b	0xb2c <generic_tracepoint_event+0xb2c>
     618:      	mov	w8, #0x4                // =4
     61c:      	add	x9, sp, #0x88
     620:      	add	x0, sp, #0x88
     624:      	mov	w1, #0x4                // =4
     628:      	blr	x8
     62c:      	cbz	x0, 0xa34 <generic_tracepoint_event+0xa34>
     630:      	neg	w8, w0
     634:      	adrp	x22, 0x0 <generic_tracepoint_event>
     638:      	mov	w9, #0x1                // =1
     63c:      	strh	w8, [sp, #0x38]
     640:      	mov	w8, #0x7                // =7
     644:      	add	x1, sp, #0x38
     648:      	mov	w24, #0x1               // =1
     64c:      	strh	w8, [sp, #0x3a]
     650:      	mov	x8, #0x56               // =86
     654:      	movk	x8, #0x4, lsl #32
     658:      	stur	x8, [sp, #0x3c]
     65c:      	add	x8, sp, #0x38
     660:      	ldr	x22, [x22]
     664:      	mov	x0, x22
     668:      	blr	x9
     66c:      	cbz	x0, 0xa10 <generic_tracepoint_event+0xa10>
     670:      	ldr	w8, [x0]
     674:      	add	w8, w8, #0x1
     678:      	str	w8, [x0]
     67c:      	ldrsw	x22, [sp, #0x88]
     680:      	b	0xb40 <generic_tracepoint_event+0xb40>
     684:      	str	w25, [sp, #0x88]
     688:      	mov	x3, xzr
     68c:      	mov	w8, #0x2                // =2
     690:      	add	x9, sp, #0x38
     694:      	add	x10, sp, #0x88
     698:      	add	x1, sp, #0x38
     69c:      	add	x2, sp, #0x88
     6a0:      	mov	x0, x22
     6a4:      	blr	x8
     6a8:      	ldr	x22, [sp, #0x20]
     6ac:      	cmp	w24, #0x1c
     6b0:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     6b4:      	mov	w8, #0x23               // =35
     6b8:      	blr	x8
     6bc:      	mov	w8, #0x8                // =8
     6c0:      	mov	w9, #0x4                // =4
     6c4:      	add	x10, sp, #0x38
     6c8:      	mov	x2, x0
     6cc:      	add	x0, sp, #0x38
     6d0:      	mov	w1, #0x8                // =8
     6d4:      	blr	x9
     6d8:      	ldr	w8, [sp, #0x38]
     6dc:      	lsl	w8, w8, #9
     6e0:      	and	x8, x8, #0x80000000
     6e4:      	orr	x22, x8, x22
     6e8:      	b	0xb40 <generic_tracepoint_event+0xb40>
     6ec:      	cmp	w24, #0x7
     6f0:      	b.ne	0xb40 <generic_tracepoint_event+0xb40>
     6f4:      	mov	w8, #0x8                // =8
     6f8:      	mov	w9, #0x4                // =4
     6fc:      	add	x10, sp, #0x20
     700:      	add	x0, sp, #0x20
     704:      	mov	w1, #0x8                // =8
     708:      	blr	x9
     70c:      	cbz	x0, 0xae4 <generic_tracepoint_event+0xae4>
     710:      	neg	w8, w0
     714:      	adrp	x22, 0x0 <generic_tracepoint_event>
     718:      	mov	w9, #0x1                // =1
     71c:      	strh	w8, [sp, #0x38]
     720:      	mov	w8, #0x7                // =7
     724:      	add	x1, sp, #0x38
     728:      	mov	w24, #0x1               // =1
     72c:      	strh	w8, [sp, #0x3a]
     730:      	mov	x8, #0x9a               // =154
     734:      	movk	x8, #0x4, lsl #32
     738:      	stur	x8, [sp, #0x3c]
     73c:      	add	x8, sp, #0x38
     740:      	ldr	x22, [x22]
     744:      	mov	x0, x22
     748:      	blr	x9
     74c:      	cbnz	x0, 0x924 <generic_tracepoint_event+0x924>
     750:      	str	w24, [sp, #0x88]
     754:      	mov	x3, xzr
     758:      	mov	w8, #0x2                // =2
     75c:      	add	x9, sp, #0x38
     760:      	add	x10, sp, #0x88
     764:      	b	0xad4 <generic_tracepoint_event+0xad4>
     768:      	mov	x22, x2
     76c:      	b	0xb40 <generic_tracepoint_event+0xb40>
     770:      	mov	w8, #0x8                // =8
     774:      	mov	w9, #0x4                // =4
     778:      	add	x10, sp, #0x20
     77c:      	add	x0, sp, #0x20
     780:      	mov	w1, #0x8                // =8
     784:      	blr	x9
     788:      	cbz	x0, 0xae4 <generic_tracepoint_event+0xae4>
     78c:      	neg	w8, w0
     790:      	adrp	x22, 0x0 <generic_tracepoint_event>
     794:      	mov	w9, #0x1                // =1
     798:      	strh	w8, [sp, #0x38]
     79c:      	mov	w8, #0x7                // =7
     7a0:      	add	x1, sp, #0x38
     7a4:      	mov	w24, #0x1               // =1
     7a8:      	strh	w8, [sp, #0x3a]
     7ac:      	mov	x8, #0x93               // =147
     7b0:      	movk	x8, #0x4, lsl #32
     7b4:      	stur	x8, [sp, #0x3c]
     7b8:      	add	x8, sp, #0x38
     7bc:      	ldr	x22, [x22]
     7c0:      	mov	x0, x22
     7c4:      	blr	x9
     7c8:      	cbnz	x0, 0x924 <generic_tracepoint_event+0x924>
     7cc:      	str	w24, [sp, #0x88]
     7d0:      	mov	x3, xzr
     7d4:      	mov	w8, #0x2                // =2
     7d8:      	add	x9, sp, #0x38
     7dc:      	add	x10, sp, #0x88
     7e0:      	b	0xad4 <generic_tracepoint_event+0xad4>
     7e4:      	mov	w8, #0x1                // =1
     7e8:      	mov	w9, #0x4                // =4
     7ec:      	add	x10, sp, #0x88
     7f0:      	add	x0, sp, #0x88
     7f4:      	mov	w1, #0x1                // =1
     7f8:      	blr	x9
     7fc:      	cbz	x0, 0xa8c <generic_tracepoint_event+0xa8c>
     800:      	neg	w8, w0
     804:      	adrp	x22, 0x0 <generic_tracepoint_event>
     808:      	mov	w9, #0x1                // =1
     80c:      	strh	w8, [sp, #0x38]
     810:      	mov	w8, #0x7                // =7
     814:      	add	x1, sp, #0x38
     818:      	mov	w24, #0x1               // =1
     81c:      	strh	w8, [sp, #0x3a]
     820:      	mov	x8, #0x7a               // =122
     824:      	movk	x8, #0x4, lsl #32
     828:      	stur	x8, [sp, #0x3c]
     82c:      	add	x8, sp, #0x38
     830:      	ldr	x22, [x22]
     834:      	mov	x0, x22
     838:      	blr	x9
     83c:      	cbz	x0, 0xa68 <generic_tracepoint_event+0xa68>
     840:      	ldr	w8, [x0]
     844:      	add	w8, w8, #0x1
     848:      	str	w8, [x0]
     84c:      	ldrsb	x22, [sp, #0x88]
     850:      	b	0xb40 <generic_tracepoint_event+0xb40>
     854:      	mov	w8, #0x8                // =8
     858:      	mov	w9, #0x4                // =4
     85c:      	add	x10, sp, #0x20
     860:      	add	x0, sp, #0x20
     864:      	mov	w1, #0x8                // =8
     868:      	blr	x9
     86c:      	cbz	x0, 0xae4 <generic_tracepoint_event+0xae4>
     870:      	neg	w8, w0
     874:      	adrp	x22, 0x0 <generic_tracepoint_event>
     878:      	mov	w9, #0x1                // =1
     87c:      	strh	w8, [sp, #0x38]
     880:      	mov	w8, #0x7                // =7
     884:      	add	x1, sp, #0x38
     888:      	mov	w24, #0x1               // =1
     88c:      	strh	w8, [sp, #0x3a]
     890:      	mov	x8, #0xa1               // =161
     894:      	movk	x8, #0x4, lsl #32
     898:      	stur	x8, [sp, #0x3c]
     89c:      	add	x8, sp, #0x38
     8a0:      	ldr	x22, [x22]
     8a4:      	mov	x0, x22
     8a8:      	blr	x9
     8ac:      	cbnz	x0, 0x924 <generic_tracepoint_event+0x924>
     8b0:      	str	w24, [sp, #0x88]
     8b4:      	mov	x3, xzr
     8b8:      	mov	w8, #0x2                // =2
     8bc:      	add	x9, sp, #0x38
     8c0:      	add	x10, sp, #0x88
     8c4:      	b	0xad4 <generic_tracepoint_event+0xad4>
     8c8:      	mov	w8, #0x8                // =8
     8cc:      	mov	w9, #0x4                // =4
     8d0:      	add	x10, sp, #0x20
     8d4:      	add	x0, sp, #0x20
     8d8:      	mov	w1, #0x8                // =8
     8dc:      	blr	x9
     8e0:      	cbz	x0, 0xae4 <generic_tracepoint_event+0xae4>
     8e4:      	neg	w8, w0
     8e8:      	adrp	x22, 0x0 <generic_tracepoint_event>
     8ec:      	mov	w9, #0x1                // =1
     8f0:      	strh	w8, [sp, #0x38]
     8f4:      	mov	w8, #0x7                // =7
     8f8:      	add	x1, sp, #0x38
     8fc:      	mov	w24, #0x1               // =1
     900:      	strh	w8, [sp, #0x3a]
     904:      	mov	x8, #0x4e               // =78
     908:      	movk	x8, #0x4, lsl #32
     90c:      	stur	x8, [sp, #0x3c]
     910:      	add	x8, sp, #0x38
     914:      	ldr	x22, [x22]
     918:      	mov	x0, x22
     91c:      	blr	x9
     920:      	cbz	x0, 0xac0 <generic_tracepoint_event+0xac0>
     924:      	ldr	w8, [x0]
     928:      	add	w8, w8, #0x1
     92c:      	str	w8, [x0]
     930:      	b	0xae4 <generic_tracepoint_event+0xae4>
     934:      	mov	w8, #0x2                // =2
     938:      	mov	w9, #0x4                // =4
     93c:      	add	x10, sp, #0x88
     940:      	add	x0, sp, #0x88
     944:      	mov	w1, #0x2                // =2
     948:      	blr	x9
     94c:      	cbz	x0, 0xb10 <generic_tracepoint_event+0xb10>
     950:      	neg	w8, w0
     954:      	adrp	x22, 0x0 <generic_tracepoint_event>
     958:      	mov	w9, #0x1                // =1
     95c:      	strh	w8, [sp, #0x38]
     960:      	mov	w8, #0x7                // =7
     964:      	add	x1, sp, #0x38
     968:      	mov	w24, #0x1               // =1
     96c:      	strh	w8, [sp, #0x3a]
     970:      	mov	x8, #0x65               // =101
     974:      	movk	x8, #0x4, lsl #32
     978:      	stur	x8, [sp, #0x3c]
     97c:      	add	x8, sp, #0x38
     980:      	ldr	x22, [x22]
     984:      	mov	x0, x22
     988:      	blr	x9
     98c:      	cbz	x0, 0xaec <generic_tracepoint_event+0xaec>
     990:      	ldr	w8, [x0]
     994:      	add	w8, w8, #0x1
     998:      	str	w8, [x0]
     99c:      	ldrh	w22, [sp, #0x88]
     9a0:      	b	0xb40 <generic_tracepoint_event+0xb40>
     9a4:      	mov	w8, #0x4                // =4
     9a8:      	add	x9, sp, #0x88
     9ac:      	add	x0, sp, #0x88
     9b0:      	mov	w1, #0x4                // =4
     9b4:      	blr	x8
     9b8:      	cbz	x0, 0xb3c <generic_tracepoint_event+0xb3c>
     9bc:      	neg	w8, w0
     9c0:      	adrp	x22, 0x0 <generic_tracepoint_event>
     9c4:      	mov	w9, #0x1                // =1
     9c8:      	strh	w8, [sp, #0x38]
     9cc:      	mov	w8, #0x7                // =7
     9d0:      	add	x1, sp, #0x38
     9d4:      	mov	w24, #0x1               // =1
     9d8:      	strh	w8, [sp, #0x3a]
     9dc:      	mov	x8, #0x88               // =136
     9e0:      	movk	x8, #0x4, lsl #32
     9e4:      	stur	x8, [sp, #0x3c]
     9e8:      	add	x8, sp, #0x38
     9ec:      	ldr	x22, [x22]
     9f0:      	mov	x0, x22
     9f4:      	blr	x9
     9f8:      	cbz	x0, 0xb18 <generic_tracepoint_event+0xb18>
     9fc:      	ldr	w8, [x0]
     a00:      	add	w8, w8, #0x1
     a04:      	str	w8, [x0]
     a08:      	ldr	w22, [sp, #0x88]
     a0c:      	b	0xb40 <generic_tracepoint_event+0xb40>
     a10:      	str	w24, [sp, #0x20]
     a14:      	mov	x3, xzr
     a18:      	mov	w8, #0x2                // =2
     a1c:      	add	x9, sp, #0x38
     a20:      	add	x10, sp, #0x20
     a24:      	add	x1, sp, #0x38
     a28:      	add	x2, sp, #0x20
     a2c:      	mov	x0, x22
     a30:      	blr	x8
     a34:      	ldrsw	x22, [sp, #0x88]
     a38:      	b	0xb40 <generic_tracepoint_event+0xb40>
     a3c:      	str	w24, [sp, #0x20]
     a40:      	mov	x3, xzr
     a44:      	mov	w8, #0x2                // =2
     a48:      	add	x9, sp, #0x38
     a4c:      	add	x10, sp, #0x20
     a50:      	add	x1, sp, #0x38
     a54:      	add	x2, sp, #0x20
     a58:      	mov	x0, x22
     a5c:      	blr	x8
     a60:      	ldrsh	x22, [sp, #0x88]
     a64:      	b	0xb40 <generic_tracepoint_event+0xb40>
     a68:      	str	w24, [sp, #0x20]
     a6c:      	mov	x3, xzr
     a70:      	mov	w8, #0x2                // =2
     a74:      	add	x9, sp, #0x38
     a78:      	add	x10, sp, #0x20
     a7c:      	add	x1, sp, #0x38
     a80:      	add	x2, sp, #0x20
     a84:      	mov	x0, x22
     a88:      	blr	x8
     a8c:      	ldrsb	x22, [sp, #0x88]
     a90:      	b	0xb40 <generic_tracepoint_event+0xb40>
     a94:      	str	w24, [sp, #0x20]
     a98:      	mov	x3, xzr
     a9c:      	mov	w8, #0x2                // =2
     aa0:      	add	x9, sp, #0x38
     aa4:      	add	x10, sp, #0x20
     aa8:      	add	x1, sp, #0x38
     aac:      	add	x2, sp, #0x20
     ab0:      	mov	x0, x22
     ab4:      	blr	x8
     ab8:      	ldrb	w22, [sp, #0x88]
     abc:      	b	0xb40 <generic_tracepoint_event+0xb40>
     ac0:      	str	w24, [sp, #0x88]
     ac4:      	mov	x3, xzr
     ac8:      	mov	w8, #0x2                // =2
     acc:      	add	x9, sp, #0x38
     ad0:      	add	x10, sp, #0x88
     ad4:      	add	x1, sp, #0x38
     ad8:      	add	x2, sp, #0x88
     adc:      	mov	x0, x22
     ae0:      	blr	x8
     ae4:      	ldr	x22, [sp, #0x20]
     ae8:      	b	0xb40 <generic_tracepoint_event+0xb40>
     aec:      	str	w24, [sp, #0x20]
     af0:      	mov	x3, xzr
     af4:      	mov	w8, #0x2                // =2
     af8:      	add	x9, sp, #0x38
     afc:      	add	x10, sp, #0x20
     b00:      	add	x1, sp, #0x38
     b04:      	add	x2, sp, #0x20
     b08:      	mov	x0, x22
     b0c:      	blr	x8
     b10:      	ldrh	w22, [sp, #0x88]
     b14:      	b	0xb40 <generic_tracepoint_event+0xb40>
     b18:      	str	w24, [sp, #0x20]
     b1c:      	mov	x3, xzr
     b20:      	mov	w8, #0x2                // =2
     b24:      	add	x9, sp, #0x38
     b28:      	add	x10, sp, #0x20
     b2c:      	add	x1, sp, #0x38
     b30:      	add	x2, sp, #0x20
     b34:      	mov	x0, x22
     b38:      	blr	x8
     b3c:      	ldr	w22, [sp, #0x88]
     b40:      	str	x22, [x20, #0x5e50]
     b44:      	mov	x24, xzr
     b48:      	ldrh	w8, [x21, #0x30]
     b4c:      	ldr	w25, [x21, #0x8]
     b50:      	add	x2, x19, x8
     b54:      	cmp	w25, #0xb
     b58:      	b.gt	0xb88 <generic_tracepoint_event+0xb88>
     b5c:      	cmp	w25, #0x3
     b60:      	b.le	0xc20 <generic_tracepoint_event+0xc20>
     b64:      	cmp	w25, #0x6
     b68:      	b.gt	0xd40 <generic_tracepoint_event+0xd40>
     b6c:      	cmp	w25, #0x4
     b70:      	b.eq	0x1188 <generic_tracepoint_event+0x1188>
     b74:      	cmp	w25, #0x5
     b78:      	b.eq	0x1030 <generic_tracepoint_event+0x1030>
     b7c:      	cmp	w25, #0x6
     b80:      	b.eq	0xc3c <generic_tracepoint_event+0xc3c>
     b84:      	b	0x1400 <generic_tracepoint_event+0x1400>
     b88:      	cmp	w25, #0x1d
     b8c:      	b.le	0xcb0 <generic_tracepoint_event+0xcb0>
     b90:      	cmp	w25, #0x25
     b94:      	b.gt	0xdb8 <generic_tracepoint_event+0xdb8>
     b98:      	cmp	w25, #0x1e
     b9c:      	b.eq	0x11f4 <generic_tracepoint_event+0x11f4>
     ba0:      	cmp	w25, #0x1f
     ba4:      	b.eq	0x10a4 <generic_tracepoint_event+0x10a4>
     ba8:      	cmp	w25, #0x20
     bac:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     bb0:      	mov	w8, #0x1                // =1
     bb4:      	mov	w9, #0x4                // =4
     bb8:      	add	x10, sp, #0x88
     bbc:      	add	x0, sp, #0x88
     bc0:      	mov	w1, #0x1                // =1
     bc4:      	blr	x9
     bc8:      	cbz	x0, 0x1378 <generic_tracepoint_event+0x1378>
     bcc:      	neg	w8, w0
     bd0:      	adrp	x22, 0x0 <generic_tracepoint_event>
     bd4:      	mov	w9, #0x1                // =1
     bd8:      	strh	w8, [sp, #0x38]
     bdc:      	mov	w8, #0x7                // =7
     be0:      	add	x1, sp, #0x38
     be4:      	mov	w24, #0x1               // =1
     be8:      	strh	w8, [sp, #0x3a]
     bec:      	mov	x8, #0x73               // =115
     bf0:      	movk	x8, #0x4, lsl #32
     bf4:      	stur	x8, [sp, #0x3c]
     bf8:      	add	x8, sp, #0x38
     bfc:      	ldr	x22, [x22]
     c00:      	mov	x0, x22
     c04:      	blr	x9
     c08:      	cbz	x0, 0x1354 <generic_tracepoint_event+0x1354>
     c0c:      	ldr	w8, [x0]
     c10:      	add	w8, w8, #0x1
     c14:      	str	w8, [x0]
     c18:      	ldrb	w24, [sp, #0x88]
     c1c:      	b	0x1400 <generic_tracepoint_event+0x1400>
     c20:      	cmn	w25, #0xc
     c24:      	b.le	0xe44 <generic_tracepoint_event+0xe44>
     c28:      	add	w8, w25, #0xb
     c2c:      	cmp	w8, #0x2
     c30:      	b.lo	0xd4c <generic_tracepoint_event+0xd4c>
     c34:      	cmp	w25, #0x2
     c38:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     c3c:      	mov	w8, #0x8                // =8
     c40:      	mov	w9, #0x4                // =4
     c44:      	add	x10, sp, #0x20
     c48:      	add	x0, sp, #0x20
     c4c:      	mov	w1, #0x8                // =8
     c50:      	blr	x9
     c54:      	cbz	x0, 0x13a4 <generic_tracepoint_event+0x13a4>
     c58:      	neg	w8, w0
     c5c:      	adrp	x22, 0x0 <generic_tracepoint_event>
     c60:      	mov	w9, #0x1                // =1
     c64:      	strh	w8, [sp, #0x38]
     c68:      	mov	w8, #0x7                // =7
     c6c:      	add	x1, sp, #0x38
     c70:      	mov	w24, #0x1               // =1
     c74:      	strh	w8, [sp, #0x3a]
     c78:      	mov	x8, #0x81               // =129
     c7c:      	movk	x8, #0x4, lsl #32
     c80:      	stur	x8, [sp, #0x3c]
     c84:      	add	x8, sp, #0x38
     c88:      	ldr	x22, [x22]
     c8c:      	mov	x0, x22
     c90:      	blr	x9
     c94:      	cbnz	x0, 0x11e4 <generic_tracepoint_event+0x11e4>
     c98:      	str	w24, [sp, #0x88]
     c9c:      	mov	x3, xzr
     ca0:      	mov	w8, #0x2                // =2
     ca4:      	add	x9, sp, #0x38
     ca8:      	add	x10, sp, #0x88
     cac:      	b	0x1394 <generic_tracepoint_event+0x1394>
     cb0:      	cmp	w25, #0x11
     cb4:      	b.le	0xe58 <generic_tracepoint_event+0xe58>
     cb8:      	cmp	w25, #0x12
     cbc:      	b.eq	0x1028 <generic_tracepoint_event+0x1028>
     cc0:      	cmp	w25, #0x1c
     cc4:      	b.eq	0xd4c <generic_tracepoint_event+0xd4c>
     cc8:      	cmp	w25, #0x1d
     ccc:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     cd0:      	mov	w8, #0x2                // =2
     cd4:      	mov	w9, #0x4                // =4
     cd8:      	add	x10, sp, #0x88
     cdc:      	add	x0, sp, #0x88
     ce0:      	mov	w1, #0x2                // =2
     ce4:      	blr	x9
     ce8:      	cbz	x0, 0x1320 <generic_tracepoint_event+0x1320>
     cec:      	neg	w8, w0
     cf0:      	adrp	x22, 0x0 <generic_tracepoint_event>
     cf4:      	mov	w9, #0x1                // =1
     cf8:      	strh	w8, [sp, #0x38]
     cfc:      	mov	w8, #0x7                // =7
     d00:      	add	x1, sp, #0x38
     d04:      	mov	w24, #0x1               // =1
     d08:      	strh	w8, [sp, #0x3a]
     d0c:      	mov	x8, #0x6c               // =108
     d10:      	movk	x8, #0x4, lsl #32
     d14:      	stur	x8, [sp, #0x3c]
     d18:      	add	x8, sp, #0x38
     d1c:      	ldr	x22, [x22]
     d20:      	mov	x0, x22
     d24:      	blr	x9
     d28:      	cbz	x0, 0x12fc <generic_tracepoint_event+0x12fc>
     d2c:      	ldr	w8, [x0]
     d30:      	add	w8, w8, #0x1
     d34:      	str	w8, [x0]
     d38:      	ldrsh	x24, [sp, #0x88]
     d3c:      	b	0x1400 <generic_tracepoint_event+0x1400>
     d40:      	sub	w8, w25, #0xa
     d44:      	cmp	w8, #0x2
     d48:      	b.hs	0xfac <generic_tracepoint_event+0xfac>
     d4c:      	mov	w8, #0x8                // =8
     d50:      	mov	w9, #0x4                // =4
     d54:      	add	x10, sp, #0x20
     d58:      	add	x0, sp, #0x20
     d5c:      	mov	w1, #0x8                // =8
     d60:      	blr	x9
     d64:      	cbz	x0, 0xf68 <generic_tracepoint_event+0xf68>
     d68:      	neg	w8, w0
     d6c:      	adrp	x22, 0x0 <generic_tracepoint_event>
     d70:      	mov	w9, #0x1                // =1
     d74:      	strh	w8, [sp, #0x38]
     d78:      	mov	w8, #0x7                // =7
     d7c:      	add	x1, sp, #0x38
     d80:      	mov	w24, #0x1               // =1
     d84:      	strh	w8, [sp, #0x3a]
     d88:      	mov	x8, #0x45               // =69
     d8c:      	movk	x8, #0x4, lsl #32
     d90:      	stur	x8, [sp, #0x3c]
     d94:      	add	x8, sp, #0x38
     d98:      	ldr	x22, [x22]
     d9c:      	mov	x0, x22
     da0:      	blr	x9
     da4:      	cbz	x0, 0xf44 <generic_tracepoint_event+0xf44>
     da8:      	ldr	w8, [x0]
     dac:      	add	w8, w8, #0x1
     db0:      	str	w8, [x0]
     db4:      	b	0xf68 <generic_tracepoint_event+0xf68>
     db8:      	cmp	w25, #0x26
     dbc:      	b.eq	0x1264 <generic_tracepoint_event+0x1264>
     dc0:      	cmp	w25, #0x28
     dc4:      	b.eq	0x1114 <generic_tracepoint_event+0x1114>
     dc8:      	cmp	w25, #0x29
     dcc:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     dd0:      	mov	w8, #0x8                // =8
     dd4:      	mov	w9, #0x4                // =4
     dd8:      	add	x10, sp, #0x20
     ddc:      	add	x0, sp, #0x20
     de0:      	mov	w1, #0x8                // =8
     de4:      	blr	x9
     de8:      	cbz	x0, 0x13a4 <generic_tracepoint_event+0x13a4>
     dec:      	neg	w8, w0
     df0:      	adrp	x22, 0x0 <generic_tracepoint_event>
     df4:      	mov	w9, #0x1                // =1
     df8:      	strh	w8, [sp, #0x38]
     dfc:      	mov	w8, #0x7                // =7
     e00:      	add	x1, sp, #0x38
     e04:      	mov	w24, #0x1               // =1
     e08:      	strh	w8, [sp, #0x3a]
     e0c:      	mov	x8, #0xa8               // =168
     e10:      	movk	x8, #0x4, lsl #32
     e14:      	stur	x8, [sp, #0x3c]
     e18:      	add	x8, sp, #0x38
     e1c:      	ldr	x22, [x22]
     e20:      	mov	x0, x22
     e24:      	blr	x9
     e28:      	cbnz	x0, 0x11e4 <generic_tracepoint_event+0x11e4>
     e2c:      	str	w24, [sp, #0x88]
     e30:      	mov	x3, xzr
     e34:      	mov	w8, #0x2                // =2
     e38:      	add	x9, sp, #0x38
     e3c:      	add	x10, sp, #0x88
     e40:      	b	0x1394 <generic_tracepoint_event+0x1394>
     e44:      	cmn	w25, #0xd
     e48:      	b.eq	0xed8 <generic_tracepoint_event+0xed8>
     e4c:      	cmn	w25, #0xc
     e50:      	b.eq	0xe68 <generic_tracepoint_event+0xe68>
     e54:      	b	0x1400 <generic_tracepoint_event+0x1400>
     e58:      	cmp	w25, #0xc
     e5c:      	b.eq	0xed8 <generic_tracepoint_event+0xed8>
     e60:      	cmp	w25, #0xd
     e64:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     e68:      	mov	w8, #0x4                // =4
     e6c:      	add	x9, sp, #0x88
     e70:      	add	x0, sp, #0x88
     e74:      	mov	w1, #0x4                // =4
     e78:      	blr	x8
     e7c:      	cbz	x0, 0x13fc <generic_tracepoint_event+0x13fc>
     e80:      	neg	w8, w0
     e84:      	adrp	x22, 0x0 <generic_tracepoint_event>
     e88:      	mov	w9, #0x1                // =1
     e8c:      	strh	w8, [sp, #0x38]
     e90:      	mov	w8, #0x7                // =7
     e94:      	add	x1, sp, #0x38
     e98:      	mov	w24, #0x1               // =1
     e9c:      	strh	w8, [sp, #0x3a]
     ea0:      	mov	x8, #0x5e               // =94
     ea4:      	movk	x8, #0x4, lsl #32
     ea8:      	stur	x8, [sp, #0x3c]
     eac:      	add	x8, sp, #0x38
     eb0:      	ldr	x22, [x22]
     eb4:      	mov	x0, x22
     eb8:      	blr	x9
     ebc:      	cbnz	x0, 0x12bc <generic_tracepoint_event+0x12bc>
     ec0:      	str	w24, [sp, #0x20]
     ec4:      	mov	x3, xzr
     ec8:      	mov	w8, #0x2                // =2
     ecc:      	add	x9, sp, #0x38
     ed0:      	add	x10, sp, #0x20
     ed4:      	b	0x13ec <generic_tracepoint_event+0x13ec>
     ed8:      	mov	w8, #0x4                // =4
     edc:      	add	x9, sp, #0x88
     ee0:      	add	x0, sp, #0x88
     ee4:      	mov	w1, #0x4                // =4
     ee8:      	blr	x8
     eec:      	cbz	x0, 0x12f4 <generic_tracepoint_event+0x12f4>
     ef0:      	neg	w8, w0
     ef4:      	adrp	x22, 0x0 <generic_tracepoint_event>
     ef8:      	mov	w9, #0x1                // =1
     efc:      	strh	w8, [sp, #0x38]
     f00:      	mov	w8, #0x7                // =7
     f04:      	add	x1, sp, #0x38
     f08:      	mov	w24, #0x1               // =1
     f0c:      	strh	w8, [sp, #0x3a]
     f10:      	mov	x8, #0x56               // =86
     f14:      	movk	x8, #0x4, lsl #32
     f18:      	stur	x8, [sp, #0x3c]
     f1c:      	add	x8, sp, #0x38
     f20:      	ldr	x22, [x22]
     f24:      	mov	x0, x22
     f28:      	blr	x9
     f2c:      	cbz	x0, 0x12d0 <generic_tracepoint_event+0x12d0>
     f30:      	ldr	w8, [x0]
     f34:      	add	w8, w8, #0x1
     f38:      	str	w8, [x0]
     f3c:      	ldrsw	x24, [sp, #0x88]
     f40:      	b	0x1400 <generic_tracepoint_event+0x1400>
     f44:      	str	w24, [sp, #0x88]
     f48:      	mov	x3, xzr
     f4c:      	mov	w8, #0x2                // =2
     f50:      	add	x9, sp, #0x38
     f54:      	add	x10, sp, #0x88
     f58:      	add	x1, sp, #0x38
     f5c:      	add	x2, sp, #0x88
     f60:      	mov	x0, x22
     f64:      	blr	x8
     f68:      	ldr	x24, [sp, #0x20]
     f6c:      	cmp	w25, #0x1c
     f70:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     f74:      	mov	w8, #0x23               // =35
     f78:      	blr	x8
     f7c:      	mov	w8, #0x8                // =8
     f80:      	mov	w9, #0x4                // =4
     f84:      	add	x10, sp, #0x38
     f88:      	mov	x2, x0
     f8c:      	add	x0, sp, #0x38
     f90:      	mov	w1, #0x8                // =8
     f94:      	blr	x9
     f98:      	ldr	w8, [sp, #0x38]
     f9c:      	lsl	w8, w8, #9
     fa0:      	and	x8, x8, #0x80000000
     fa4:      	orr	x24, x8, x24
     fa8:      	b	0x1400 <generic_tracepoint_event+0x1400>
     fac:      	cmp	w25, #0x7
     fb0:      	b.ne	0x1400 <generic_tracepoint_event+0x1400>
     fb4:      	mov	w8, #0x8                // =8
     fb8:      	mov	w9, #0x4                // =4
     fbc:      	add	x10, sp, #0x20
     fc0:      	add	x0, sp, #0x20
     fc4:      	mov	w1, #0x8                // =8
     fc8:      	blr	x9
     fcc:      	cbz	x0, 0x13a4 <generic_tracepoint_event+0x13a4>
     fd0:      	neg	w8, w0
     fd4:      	adrp	x22, 0x0 <generic_tracepoint_event>
     fd8:      	mov	w9, #0x1                // =1
     fdc:      	strh	w8, [sp, #0x38]
     fe0:      	mov	w8, #0x7                // =7
     fe4:      	add	x1, sp, #0x38
     fe8:      	mov	w24, #0x1               // =1
     fec:      	strh	w8, [sp, #0x3a]
     ff0:      	mov	x8, #0x9a               // =154
     ff4:      	movk	x8, #0x4, lsl #32
     ff8:      	stur	x8, [sp, #0x3c]
     ffc:      	add	x8, sp, #0x38
    1000:      	ldr	x22, [x22]
    1004:      	mov	x0, x22
    1008:      	blr	x9
    100c:      	cbnz	x0, 0x11e4 <generic_tracepoint_event+0x11e4>
    1010:      	str	w24, [sp, #0x88]
    1014:      	mov	x3, xzr
    1018:      	mov	w8, #0x2                // =2
    101c:      	add	x9, sp, #0x38
    1020:      	add	x10, sp, #0x88
    1024:      	b	0x1394 <generic_tracepoint_event+0x1394>
    1028:      	mov	x24, x2
    102c:      	b	0x1400 <generic_tracepoint_event+0x1400>
    1030:      	mov	w8, #0x8                // =8
    1034:      	mov	w9, #0x4                // =4
    1038:      	add	x10, sp, #0x20
    103c:      	add	x0, sp, #0x20
    1040:      	mov	w1, #0x8                // =8
    1044:      	blr	x9
    1048:      	cbz	x0, 0x13a4 <generic_tracepoint_event+0x13a4>
    104c:      	neg	w8, w0
    1050:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1054:      	mov	w9, #0x1                // =1
    1058:      	strh	w8, [sp, #0x38]
    105c:      	mov	w8, #0x7                // =7
    1060:      	add	x1, sp, #0x38
    1064:      	mov	w24, #0x1               // =1
    1068:      	strh	w8, [sp, #0x3a]
    106c:      	mov	x8, #0x93               // =147
    1070:      	movk	x8, #0x4, lsl #32
    1074:      	stur	x8, [sp, #0x3c]
    1078:      	add	x8, sp, #0x38
    107c:      	ldr	x22, [x22]
    1080:      	mov	x0, x22
    1084:      	blr	x9
    1088:      	cbnz	x0, 0x11e4 <generic_tracepoint_event+0x11e4>
    108c:      	str	w24, [sp, #0x88]
    1090:      	mov	x3, xzr
    1094:      	mov	w8, #0x2                // =2
    1098:      	add	x9, sp, #0x38
    109c:      	add	x10, sp, #0x88
    10a0:      	b	0x1394 <generic_tracepoint_event+0x1394>
    10a4:      	mov	w8, #0x1                // =1
    10a8:      	mov	w9, #0x4                // =4
    10ac:      	add	x10, sp, #0x88
    10b0:      	add	x0, sp, #0x88
    10b4:      	mov	w1, #0x1                // =1
    10b8:      	blr	x9
    10bc:      	cbz	x0, 0x134c <generic_tracepoint_event+0x134c>
    10c0:      	neg	w8, w0
    10c4:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    10c8:      	mov	w9, #0x1                // =1
    10cc:      	strh	w8, [sp, #0x38]
    10d0:      	mov	w8, #0x7                // =7
    10d4:      	add	x1, sp, #0x38
    10d8:      	mov	w24, #0x1               // =1
    10dc:      	strh	w8, [sp, #0x3a]
    10e0:      	mov	x8, #0x7a               // =122
    10e4:      	movk	x8, #0x4, lsl #32
    10e8:      	stur	x8, [sp, #0x3c]
    10ec:      	add	x8, sp, #0x38
    10f0:      	ldr	x22, [x22]
    10f4:      	mov	x0, x22
    10f8:      	blr	x9
    10fc:      	cbz	x0, 0x1328 <generic_tracepoint_event+0x1328>
    1100:      	ldr	w8, [x0]
    1104:      	add	w8, w8, #0x1
    1108:      	str	w8, [x0]
    110c:      	ldrsb	x24, [sp, #0x88]
    1110:      	b	0x1400 <generic_tracepoint_event+0x1400>
    1114:      	mov	w8, #0x8                // =8
    1118:      	mov	w9, #0x4                // =4
    111c:      	add	x10, sp, #0x20
    1120:      	add	x0, sp, #0x20
    1124:      	mov	w1, #0x8                // =8
    1128:      	blr	x9
    112c:      	cbz	x0, 0x13a4 <generic_tracepoint_event+0x13a4>
    1130:      	neg	w8, w0
    1134:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1138:      	mov	w9, #0x1                // =1
    113c:      	strh	w8, [sp, #0x38]
    1140:      	mov	w8, #0x7                // =7
    1144:      	add	x1, sp, #0x38
    1148:      	mov	w24, #0x1               // =1
    114c:      	strh	w8, [sp, #0x3a]
    1150:      	mov	x8, #0xa1               // =161
    1154:      	movk	x8, #0x4, lsl #32
    1158:      	stur	x8, [sp, #0x3c]
    115c:      	add	x8, sp, #0x38
    1160:      	ldr	x22, [x22]
    1164:      	mov	x0, x22
    1168:      	blr	x9
    116c:      	cbnz	x0, 0x11e4 <generic_tracepoint_event+0x11e4>
    1170:      	str	w24, [sp, #0x88]
    1174:      	mov	x3, xzr
    1178:      	mov	w8, #0x2                // =2
    117c:      	add	x9, sp, #0x38
    1180:      	add	x10, sp, #0x88
    1184:      	b	0x1394 <generic_tracepoint_event+0x1394>
    1188:      	mov	w8, #0x8                // =8
    118c:      	mov	w9, #0x4                // =4
    1190:      	add	x10, sp, #0x20
    1194:      	add	x0, sp, #0x20
    1198:      	mov	w1, #0x8                // =8
    119c:      	blr	x9
    11a0:      	cbz	x0, 0x13a4 <generic_tracepoint_event+0x13a4>
    11a4:      	neg	w8, w0
    11a8:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    11ac:      	mov	w9, #0x1                // =1
    11b0:      	strh	w8, [sp, #0x38]
    11b4:      	mov	w8, #0x7                // =7
    11b8:      	add	x1, sp, #0x38
    11bc:      	mov	w24, #0x1               // =1
    11c0:      	strh	w8, [sp, #0x3a]
    11c4:      	mov	x8, #0x4e               // =78
    11c8:      	movk	x8, #0x4, lsl #32
    11cc:      	stur	x8, [sp, #0x3c]
    11d0:      	add	x8, sp, #0x38
    11d4:      	ldr	x22, [x22]
    11d8:      	mov	x0, x22
    11dc:      	blr	x9
    11e0:      	cbz	x0, 0x1380 <generic_tracepoint_event+0x1380>
    11e4:      	ldr	w8, [x0]
    11e8:      	add	w8, w8, #0x1
    11ec:      	str	w8, [x0]
    11f0:      	b	0x13a4 <generic_tracepoint_event+0x13a4>
    11f4:      	mov	w8, #0x2                // =2
    11f8:      	mov	w9, #0x4                // =4
    11fc:      	add	x10, sp, #0x88
    1200:      	add	x0, sp, #0x88
    1204:      	mov	w1, #0x2                // =2
    1208:      	blr	x9
    120c:      	cbz	x0, 0x13d0 <generic_tracepoint_event+0x13d0>
    1210:      	neg	w8, w0
    1214:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1218:      	mov	w9, #0x1                // =1
    121c:      	strh	w8, [sp, #0x38]
    1220:      	mov	w8, #0x7                // =7
    1224:      	add	x1, sp, #0x38
    1228:      	mov	w24, #0x1               // =1
    122c:      	strh	w8, [sp, #0x3a]
    1230:      	mov	x8, #0x65               // =101
    1234:      	movk	x8, #0x4, lsl #32
    1238:      	stur	x8, [sp, #0x3c]
    123c:      	add	x8, sp, #0x38
    1240:      	ldr	x22, [x22]
    1244:      	mov	x0, x22
    1248:      	blr	x9
    124c:      	cbz	x0, 0x13ac <generic_tracepoint_event+0x13ac>
    1250:      	ldr	w8, [x0]
    1254:      	add	w8, w8, #0x1
    1258:      	str	w8, [x0]
    125c:      	ldrh	w24, [sp, #0x88]
    1260:      	b	0x1400 <generic_tracepoint_event+0x1400>
    1264:      	mov	w8, #0x4                // =4
    1268:      	add	x9, sp, #0x88
    126c:      	add	x0, sp, #0x88
    1270:      	mov	w1, #0x4                // =4
    1274:      	blr	x8
    1278:      	cbz	x0, 0x13fc <generic_tracepoint_event+0x13fc>
    127c:      	neg	w8, w0
    1280:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1284:      	mov	w9, #0x1                // =1
    1288:      	strh	w8, [sp, #0x38]
    128c:      	mov	w8, #0x7                // =7
    1290:      	add	x1, sp, #0x38
    1294:      	mov	w24, #0x1               // =1
    1298:      	strh	w8, [sp, #0x3a]
    129c:      	mov	x8, #0x88               // =136
    12a0:      	movk	x8, #0x4, lsl #32
    12a4:      	stur	x8, [sp, #0x3c]
    12a8:      	add	x8, sp, #0x38
    12ac:      	ldr	x22, [x22]
    12b0:      	mov	x0, x22
    12b4:      	blr	x9
    12b8:      	cbz	x0, 0x13d8 <generic_tracepoint_event+0x13d8>
    12bc:      	ldr	w8, [x0]
    12c0:      	add	w8, w8, #0x1
    12c4:      	str	w8, [x0]
    12c8:      	ldr	w24, [sp, #0x88]
    12cc:      	b	0x1400 <generic_tracepoint_event+0x1400>
    12d0:      	str	w24, [sp, #0x20]
    12d4:      	mov	x3, xzr
    12d8:      	mov	w8, #0x2                // =2
    12dc:      	add	x9, sp, #0x38
    12e0:      	add	x10, sp, #0x20
    12e4:      	add	x1, sp, #0x38
    12e8:      	add	x2, sp, #0x20
    12ec:      	mov	x0, x22
    12f0:      	blr	x8
    12f4:      	ldrsw	x24, [sp, #0x88]
    12f8:      	b	0x1400 <generic_tracepoint_event+0x1400>
    12fc:      	str	w24, [sp, #0x20]
    1300:      	mov	x3, xzr
    1304:      	mov	w8, #0x2                // =2
    1308:      	add	x9, sp, #0x38
    130c:      	add	x10, sp, #0x20
    1310:      	add	x1, sp, #0x38
    1314:      	add	x2, sp, #0x20
    1318:      	mov	x0, x22
    131c:      	blr	x8
    1320:      	ldrsh	x24, [sp, #0x88]
    1324:      	b	0x1400 <generic_tracepoint_event+0x1400>
    1328:      	str	w24, [sp, #0x20]
    132c:      	mov	x3, xzr
    1330:      	mov	w8, #0x2                // =2
    1334:      	add	x9, sp, #0x38
    1338:      	add	x10, sp, #0x20
    133c:      	add	x1, sp, #0x38
    1340:      	add	x2, sp, #0x20
    1344:      	mov	x0, x22
    1348:      	blr	x8
    134c:      	ldrsb	x24, [sp, #0x88]
    1350:      	b	0x1400 <generic_tracepoint_event+0x1400>
    1354:      	str	w24, [sp, #0x20]
    1358:      	mov	x3, xzr
    135c:      	mov	w8, #0x2                // =2
    1360:      	add	x9, sp, #0x38
    1364:      	add	x10, sp, #0x20
    1368:      	add	x1, sp, #0x38
    136c:      	add	x2, sp, #0x20
    1370:      	mov	x0, x22
    1374:      	blr	x8
    1378:      	ldrb	w24, [sp, #0x88]
    137c:      	b	0x1400 <generic_tracepoint_event+0x1400>
    1380:      	str	w24, [sp, #0x88]
    1384:      	mov	x3, xzr
    1388:      	mov	w8, #0x2                // =2
    138c:      	add	x9, sp, #0x38
    1390:      	add	x10, sp, #0x88
    1394:      	add	x1, sp, #0x38
    1398:      	add	x2, sp, #0x88
    139c:      	mov	x0, x22
    13a0:      	blr	x8
    13a4:      	ldr	x24, [sp, #0x20]
    13a8:      	b	0x1400 <generic_tracepoint_event+0x1400>
    13ac:      	str	w24, [sp, #0x20]
    13b0:      	mov	x3, xzr
    13b4:      	mov	w8, #0x2                // =2
    13b8:      	add	x9, sp, #0x38
    13bc:      	add	x10, sp, #0x20
    13c0:      	add	x1, sp, #0x38
    13c4:      	add	x2, sp, #0x20
    13c8:      	mov	x0, x22
    13cc:      	blr	x8
    13d0:      	ldrh	w24, [sp, #0x88]
    13d4:      	b	0x1400 <generic_tracepoint_event+0x1400>
    13d8:      	str	w24, [sp, #0x20]
    13dc:      	mov	x3, xzr
    13e0:      	mov	w8, #0x2                // =2
    13e4:      	add	x9, sp, #0x38
    13e8:      	add	x10, sp, #0x20
    13ec:      	add	x1, sp, #0x38
    13f0:      	add	x2, sp, #0x20
    13f4:      	mov	x0, x22
    13f8:      	blr	x8
    13fc:      	ldr	w24, [sp, #0x88]
    1400:      	str	x24, [x20, #0x5e58]
    1404:      	mov	x22, xzr
    1408:      	ldrh	w8, [x21, #0x34]
    140c:      	ldr	w24, [x21, #0xc]
    1410:      	add	x2, x19, x8
    1414:      	cmp	w24, #0xb
    1418:      	b.gt	0x1448 <generic_tracepoint_event+0x1448>
    141c:      	cmp	w24, #0x3
    1420:      	b.le	0x14e0 <generic_tracepoint_event+0x14e0>
    1424:      	cmp	w24, #0x6
    1428:      	b.gt	0x1600 <generic_tracepoint_event+0x1600>
    142c:      	cmp	w24, #0x4
    1430:      	b.eq	0x1a48 <generic_tracepoint_event+0x1a48>
    1434:      	cmp	w24, #0x5
    1438:      	b.eq	0x18f0 <generic_tracepoint_event+0x18f0>
    143c:      	cmp	w24, #0x6
    1440:      	b.eq	0x14fc <generic_tracepoint_event+0x14fc>
    1444:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1448:      	cmp	w24, #0x1d
    144c:      	b.le	0x1570 <generic_tracepoint_event+0x1570>
    1450:      	cmp	w24, #0x25
    1454:      	b.gt	0x1678 <generic_tracepoint_event+0x1678>
    1458:      	cmp	w24, #0x1e
    145c:      	b.eq	0x1ab4 <generic_tracepoint_event+0x1ab4>
    1460:      	cmp	w24, #0x1f
    1464:      	b.eq	0x1964 <generic_tracepoint_event+0x1964>
    1468:      	cmp	w24, #0x20
    146c:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1470:      	mov	w8, #0x1                // =1
    1474:      	mov	w9, #0x4                // =4
    1478:      	add	x10, sp, #0x88
    147c:      	add	x0, sp, #0x88
    1480:      	mov	w1, #0x1                // =1
    1484:      	blr	x9
    1488:      	cbz	x0, 0x1c38 <generic_tracepoint_event+0x1c38>
    148c:      	neg	w8, w0
    1490:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1494:      	mov	w9, #0x1                // =1
    1498:      	strh	w8, [sp, #0x38]
    149c:      	mov	w8, #0x7                // =7
    14a0:      	add	x1, sp, #0x38
    14a4:      	mov	w24, #0x1               // =1
    14a8:      	strh	w8, [sp, #0x3a]
    14ac:      	mov	x8, #0x73               // =115
    14b0:      	movk	x8, #0x4, lsl #32
    14b4:      	stur	x8, [sp, #0x3c]
    14b8:      	add	x8, sp, #0x38
    14bc:      	ldr	x22, [x22]
    14c0:      	mov	x0, x22
    14c4:      	blr	x9
    14c8:      	cbz	x0, 0x1c14 <generic_tracepoint_event+0x1c14>
    14cc:      	ldr	w8, [x0]
    14d0:      	add	w8, w8, #0x1
    14d4:      	str	w8, [x0]
    14d8:      	ldrb	w22, [sp, #0x88]
    14dc:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    14e0:      	cmn	w24, #0xc
    14e4:      	b.le	0x1704 <generic_tracepoint_event+0x1704>
    14e8:      	add	w8, w24, #0xb
    14ec:      	cmp	w8, #0x2
    14f0:      	b.lo	0x160c <generic_tracepoint_event+0x160c>
    14f4:      	cmp	w24, #0x2
    14f8:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    14fc:      	mov	w8, #0x8                // =8
    1500:      	mov	w9, #0x4                // =4
    1504:      	add	x10, sp, #0x20
    1508:      	add	x0, sp, #0x20
    150c:      	mov	w1, #0x8                // =8
    1510:      	blr	x9
    1514:      	cbz	x0, 0x1c64 <generic_tracepoint_event+0x1c64>
    1518:      	neg	w8, w0
    151c:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1520:      	mov	w9, #0x1                // =1
    1524:      	strh	w8, [sp, #0x38]
    1528:      	mov	w8, #0x7                // =7
    152c:      	add	x1, sp, #0x38
    1530:      	mov	w24, #0x1               // =1
    1534:      	strh	w8, [sp, #0x3a]
    1538:      	mov	x8, #0x81               // =129
    153c:      	movk	x8, #0x4, lsl #32
    1540:      	stur	x8, [sp, #0x3c]
    1544:      	add	x8, sp, #0x38
    1548:      	ldr	x22, [x22]
    154c:      	mov	x0, x22
    1550:      	blr	x9
    1554:      	cbnz	x0, 0x1aa4 <generic_tracepoint_event+0x1aa4>
    1558:      	str	w24, [sp, #0x88]
    155c:      	mov	x3, xzr
    1560:      	mov	w8, #0x2                // =2
    1564:      	add	x9, sp, #0x38
    1568:      	add	x10, sp, #0x88
    156c:      	b	0x1c54 <generic_tracepoint_event+0x1c54>
    1570:      	cmp	w24, #0x11
    1574:      	b.le	0x1718 <generic_tracepoint_event+0x1718>
    1578:      	cmp	w24, #0x12
    157c:      	b.eq	0x18e8 <generic_tracepoint_event+0x18e8>
    1580:      	cmp	w24, #0x1c
    1584:      	b.eq	0x160c <generic_tracepoint_event+0x160c>
    1588:      	cmp	w24, #0x1d
    158c:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1590:      	mov	w8, #0x2                // =2
    1594:      	mov	w9, #0x4                // =4
    1598:      	add	x10, sp, #0x88
    159c:      	add	x0, sp, #0x88
    15a0:      	mov	w1, #0x2                // =2
    15a4:      	blr	x9
    15a8:      	cbz	x0, 0x1be0 <generic_tracepoint_event+0x1be0>
    15ac:      	neg	w8, w0
    15b0:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    15b4:      	mov	w9, #0x1                // =1
    15b8:      	strh	w8, [sp, #0x38]
    15bc:      	mov	w8, #0x7                // =7
    15c0:      	add	x1, sp, #0x38
    15c4:      	mov	w24, #0x1               // =1
    15c8:      	strh	w8, [sp, #0x3a]
    15cc:      	mov	x8, #0x6c               // =108
    15d0:      	movk	x8, #0x4, lsl #32
    15d4:      	stur	x8, [sp, #0x3c]
    15d8:      	add	x8, sp, #0x38
    15dc:      	ldr	x22, [x22]
    15e0:      	mov	x0, x22
    15e4:      	blr	x9
    15e8:      	cbz	x0, 0x1bbc <generic_tracepoint_event+0x1bbc>
    15ec:      	ldr	w8, [x0]
    15f0:      	add	w8, w8, #0x1
    15f4:      	str	w8, [x0]
    15f8:      	ldrsh	x22, [sp, #0x88]
    15fc:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1600:      	sub	w8, w24, #0xa
    1604:      	cmp	w8, #0x2
    1608:      	b.hs	0x186c <generic_tracepoint_event+0x186c>
    160c:      	mov	w8, #0x8                // =8
    1610:      	mov	w9, #0x4                // =4
    1614:      	add	x10, sp, #0x20
    1618:      	add	x0, sp, #0x20
    161c:      	mov	w1, #0x8                // =8
    1620:      	blr	x9
    1624:      	cbz	x0, 0x1828 <generic_tracepoint_event+0x1828>
    1628:      	neg	w8, w0
    162c:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1630:      	mov	w9, #0x1                // =1
    1634:      	strh	w8, [sp, #0x38]
    1638:      	mov	w8, #0x7                // =7
    163c:      	add	x1, sp, #0x38
    1640:      	mov	w25, #0x1               // =1
    1644:      	strh	w8, [sp, #0x3a]
    1648:      	mov	x8, #0x45               // =69
    164c:      	movk	x8, #0x4, lsl #32
    1650:      	stur	x8, [sp, #0x3c]
    1654:      	add	x8, sp, #0x38
    1658:      	ldr	x22, [x22]
    165c:      	mov	x0, x22
    1660:      	blr	x9
    1664:      	cbz	x0, 0x1804 <generic_tracepoint_event+0x1804>
    1668:      	ldr	w8, [x0]
    166c:      	add	w8, w8, #0x1
    1670:      	str	w8, [x0]
    1674:      	b	0x1828 <generic_tracepoint_event+0x1828>
    1678:      	cmp	w24, #0x26
    167c:      	b.eq	0x1b24 <generic_tracepoint_event+0x1b24>
    1680:      	cmp	w24, #0x28
    1684:      	b.eq	0x19d4 <generic_tracepoint_event+0x19d4>
    1688:      	cmp	w24, #0x29
    168c:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1690:      	mov	w8, #0x8                // =8
    1694:      	mov	w9, #0x4                // =4
    1698:      	add	x10, sp, #0x20
    169c:      	add	x0, sp, #0x20
    16a0:      	mov	w1, #0x8                // =8
    16a4:      	blr	x9
    16a8:      	cbz	x0, 0x1c64 <generic_tracepoint_event+0x1c64>
    16ac:      	neg	w8, w0
    16b0:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    16b4:      	mov	w9, #0x1                // =1
    16b8:      	strh	w8, [sp, #0x38]
    16bc:      	mov	w8, #0x7                // =7
    16c0:      	add	x1, sp, #0x38
    16c4:      	mov	w24, #0x1               // =1
    16c8:      	strh	w8, [sp, #0x3a]
    16cc:      	mov	x8, #0xa8               // =168
    16d0:      	movk	x8, #0x4, lsl #32
    16d4:      	stur	x8, [sp, #0x3c]
    16d8:      	add	x8, sp, #0x38
    16dc:      	ldr	x22, [x22]
    16e0:      	mov	x0, x22
    16e4:      	blr	x9
    16e8:      	cbnz	x0, 0x1aa4 <generic_tracepoint_event+0x1aa4>
    16ec:      	str	w24, [sp, #0x88]
    16f0:      	mov	x3, xzr
    16f4:      	mov	w8, #0x2                // =2
    16f8:      	add	x9, sp, #0x38
    16fc:      	add	x10, sp, #0x88
    1700:      	b	0x1c54 <generic_tracepoint_event+0x1c54>
    1704:      	cmn	w24, #0xd
    1708:      	b.eq	0x1798 <generic_tracepoint_event+0x1798>
    170c:      	cmn	w24, #0xc
    1710:      	b.eq	0x1728 <generic_tracepoint_event+0x1728>
    1714:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1718:      	cmp	w24, #0xc
    171c:      	b.eq	0x1798 <generic_tracepoint_event+0x1798>
    1720:      	cmp	w24, #0xd
    1724:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1728:      	mov	w8, #0x4                // =4
    172c:      	add	x9, sp, #0x88
    1730:      	add	x0, sp, #0x88
    1734:      	mov	w1, #0x4                // =4
    1738:      	blr	x8
    173c:      	cbz	x0, 0x1cbc <generic_tracepoint_event+0x1cbc>
    1740:      	neg	w8, w0
    1744:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1748:      	mov	w9, #0x1                // =1
    174c:      	strh	w8, [sp, #0x38]
    1750:      	mov	w8, #0x7                // =7
    1754:      	add	x1, sp, #0x38
    1758:      	mov	w24, #0x1               // =1
    175c:      	strh	w8, [sp, #0x3a]
    1760:      	mov	x8, #0x5e               // =94
    1764:      	movk	x8, #0x4, lsl #32
    1768:      	stur	x8, [sp, #0x3c]
    176c:      	add	x8, sp, #0x38
    1770:      	ldr	x22, [x22]
    1774:      	mov	x0, x22
    1778:      	blr	x9
    177c:      	cbnz	x0, 0x1b7c <generic_tracepoint_event+0x1b7c>
    1780:      	str	w24, [sp, #0x20]
    1784:      	mov	x3, xzr
    1788:      	mov	w8, #0x2                // =2
    178c:      	add	x9, sp, #0x38
    1790:      	add	x10, sp, #0x20
    1794:      	b	0x1cac <generic_tracepoint_event+0x1cac>
    1798:      	mov	w8, #0x4                // =4
    179c:      	add	x9, sp, #0x88
    17a0:      	add	x0, sp, #0x88
    17a4:      	mov	w1, #0x4                // =4
    17a8:      	blr	x8
    17ac:      	cbz	x0, 0x1bb4 <generic_tracepoint_event+0x1bb4>
    17b0:      	neg	w8, w0
    17b4:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    17b8:      	mov	w9, #0x1                // =1
    17bc:      	strh	w8, [sp, #0x38]
    17c0:      	mov	w8, #0x7                // =7
    17c4:      	add	x1, sp, #0x38
    17c8:      	mov	w24, #0x1               // =1
    17cc:      	strh	w8, [sp, #0x3a]
    17d0:      	mov	x8, #0x56               // =86
    17d4:      	movk	x8, #0x4, lsl #32
    17d8:      	stur	x8, [sp, #0x3c]
    17dc:      	add	x8, sp, #0x38
    17e0:      	ldr	x22, [x22]
    17e4:      	mov	x0, x22
    17e8:      	blr	x9
    17ec:      	cbz	x0, 0x1b90 <generic_tracepoint_event+0x1b90>
    17f0:      	ldr	w8, [x0]
    17f4:      	add	w8, w8, #0x1
    17f8:      	str	w8, [x0]
    17fc:      	ldrsw	x22, [sp, #0x88]
    1800:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1804:      	str	w25, [sp, #0x88]
    1808:      	mov	x3, xzr
    180c:      	mov	w8, #0x2                // =2
    1810:      	add	x9, sp, #0x38
    1814:      	add	x10, sp, #0x88
    1818:      	add	x1, sp, #0x38
    181c:      	add	x2, sp, #0x88
    1820:      	mov	x0, x22
    1824:      	blr	x8
    1828:      	ldr	x22, [sp, #0x20]
    182c:      	cmp	w24, #0x1c
    1830:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1834:      	mov	w8, #0x23               // =35
    1838:      	blr	x8
    183c:      	mov	w8, #0x8                // =8
    1840:      	mov	w9, #0x4                // =4
    1844:      	add	x10, sp, #0x38
    1848:      	mov	x2, x0
    184c:      	add	x0, sp, #0x38
    1850:      	mov	w1, #0x8                // =8
    1854:      	blr	x9
    1858:      	ldr	w8, [sp, #0x38]
    185c:      	lsl	w8, w8, #9
    1860:      	and	x8, x8, #0x80000000
    1864:      	orr	x22, x8, x22
    1868:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    186c:      	cmp	w24, #0x7
    1870:      	b.ne	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1874:      	mov	w8, #0x8                // =8
    1878:      	mov	w9, #0x4                // =4
    187c:      	add	x10, sp, #0x20
    1880:      	add	x0, sp, #0x20
    1884:      	mov	w1, #0x8                // =8
    1888:      	blr	x9
    188c:      	cbz	x0, 0x1c64 <generic_tracepoint_event+0x1c64>
    1890:      	neg	w8, w0
    1894:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1898:      	mov	w9, #0x1                // =1
    189c:      	strh	w8, [sp, #0x38]
    18a0:      	mov	w8, #0x7                // =7
    18a4:      	add	x1, sp, #0x38
    18a8:      	mov	w24, #0x1               // =1
    18ac:      	strh	w8, [sp, #0x3a]
    18b0:      	mov	x8, #0x9a               // =154
    18b4:      	movk	x8, #0x4, lsl #32
    18b8:      	stur	x8, [sp, #0x3c]
    18bc:      	add	x8, sp, #0x38
    18c0:      	ldr	x22, [x22]
    18c4:      	mov	x0, x22
    18c8:      	blr	x9
    18cc:      	cbnz	x0, 0x1aa4 <generic_tracepoint_event+0x1aa4>
    18d0:      	str	w24, [sp, #0x88]
    18d4:      	mov	x3, xzr
    18d8:      	mov	w8, #0x2                // =2
    18dc:      	add	x9, sp, #0x38
    18e0:      	add	x10, sp, #0x88
    18e4:      	b	0x1c54 <generic_tracepoint_event+0x1c54>
    18e8:      	mov	x22, x2
    18ec:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    18f0:      	mov	w8, #0x8                // =8
    18f4:      	mov	w9, #0x4                // =4
    18f8:      	add	x10, sp, #0x20
    18fc:      	add	x0, sp, #0x20
    1900:      	mov	w1, #0x8                // =8
    1904:      	blr	x9
    1908:      	cbz	x0, 0x1c64 <generic_tracepoint_event+0x1c64>
    190c:      	neg	w8, w0
    1910:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1914:      	mov	w9, #0x1                // =1
    1918:      	strh	w8, [sp, #0x38]
    191c:      	mov	w8, #0x7                // =7
    1920:      	add	x1, sp, #0x38
    1924:      	mov	w24, #0x1               // =1
    1928:      	strh	w8, [sp, #0x3a]
    192c:      	mov	x8, #0x93               // =147
    1930:      	movk	x8, #0x4, lsl #32
    1934:      	stur	x8, [sp, #0x3c]
    1938:      	add	x8, sp, #0x38
    193c:      	ldr	x22, [x22]
    1940:      	mov	x0, x22
    1944:      	blr	x9
    1948:      	cbnz	x0, 0x1aa4 <generic_tracepoint_event+0x1aa4>
    194c:      	str	w24, [sp, #0x88]
    1950:      	mov	x3, xzr
    1954:      	mov	w8, #0x2                // =2
    1958:      	add	x9, sp, #0x38
    195c:      	add	x10, sp, #0x88
    1960:      	b	0x1c54 <generic_tracepoint_event+0x1c54>
    1964:      	mov	w8, #0x1                // =1
    1968:      	mov	w9, #0x4                // =4
    196c:      	add	x10, sp, #0x88
    1970:      	add	x0, sp, #0x88
    1974:      	mov	w1, #0x1                // =1
    1978:      	blr	x9
    197c:      	cbz	x0, 0x1c0c <generic_tracepoint_event+0x1c0c>
    1980:      	neg	w8, w0
    1984:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1988:      	mov	w9, #0x1                // =1
    198c:      	strh	w8, [sp, #0x38]
    1990:      	mov	w8, #0x7                // =7
    1994:      	add	x1, sp, #0x38
    1998:      	mov	w24, #0x1               // =1
    199c:      	strh	w8, [sp, #0x3a]
    19a0:      	mov	x8, #0x7a               // =122
    19a4:      	movk	x8, #0x4, lsl #32
    19a8:      	stur	x8, [sp, #0x3c]
    19ac:      	add	x8, sp, #0x38
    19b0:      	ldr	x22, [x22]
    19b4:      	mov	x0, x22
    19b8:      	blr	x9
    19bc:      	cbz	x0, 0x1be8 <generic_tracepoint_event+0x1be8>
    19c0:      	ldr	w8, [x0]
    19c4:      	add	w8, w8, #0x1
    19c8:      	str	w8, [x0]
    19cc:      	ldrsb	x22, [sp, #0x88]
    19d0:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    19d4:      	mov	w8, #0x8                // =8
    19d8:      	mov	w9, #0x4                // =4
    19dc:      	add	x10, sp, #0x20
    19e0:      	add	x0, sp, #0x20
    19e4:      	mov	w1, #0x8                // =8
    19e8:      	blr	x9
    19ec:      	cbz	x0, 0x1c64 <generic_tracepoint_event+0x1c64>
    19f0:      	neg	w8, w0
    19f4:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    19f8:      	mov	w9, #0x1                // =1
    19fc:      	strh	w8, [sp, #0x38]
    1a00:      	mov	w8, #0x7                // =7
    1a04:      	add	x1, sp, #0x38
    1a08:      	mov	w24, #0x1               // =1
    1a0c:      	strh	w8, [sp, #0x3a]
    1a10:      	mov	x8, #0xa1               // =161
    1a14:      	movk	x8, #0x4, lsl #32
    1a18:      	stur	x8, [sp, #0x3c]
    1a1c:      	add	x8, sp, #0x38
    1a20:      	ldr	x22, [x22]
    1a24:      	mov	x0, x22
    1a28:      	blr	x9
    1a2c:      	cbnz	x0, 0x1aa4 <generic_tracepoint_event+0x1aa4>
    1a30:      	str	w24, [sp, #0x88]
    1a34:      	mov	x3, xzr
    1a38:      	mov	w8, #0x2                // =2
    1a3c:      	add	x9, sp, #0x38
    1a40:      	add	x10, sp, #0x88
    1a44:      	b	0x1c54 <generic_tracepoint_event+0x1c54>
    1a48:      	mov	w8, #0x8                // =8
    1a4c:      	mov	w9, #0x4                // =4
    1a50:      	add	x10, sp, #0x20
    1a54:      	add	x0, sp, #0x20
    1a58:      	mov	w1, #0x8                // =8
    1a5c:      	blr	x9
    1a60:      	cbz	x0, 0x1c64 <generic_tracepoint_event+0x1c64>
    1a64:      	neg	w8, w0
    1a68:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1a6c:      	mov	w9, #0x1                // =1
    1a70:      	strh	w8, [sp, #0x38]
    1a74:      	mov	w8, #0x7                // =7
    1a78:      	add	x1, sp, #0x38
    1a7c:      	mov	w24, #0x1               // =1
    1a80:      	strh	w8, [sp, #0x3a]
    1a84:      	mov	x8, #0x4e               // =78
    1a88:      	movk	x8, #0x4, lsl #32
    1a8c:      	stur	x8, [sp, #0x3c]
    1a90:      	add	x8, sp, #0x38
    1a94:      	ldr	x22, [x22]
    1a98:      	mov	x0, x22
    1a9c:      	blr	x9
    1aa0:      	cbz	x0, 0x1c40 <generic_tracepoint_event+0x1c40>
    1aa4:      	ldr	w8, [x0]
    1aa8:      	add	w8, w8, #0x1
    1aac:      	str	w8, [x0]
    1ab0:      	b	0x1c64 <generic_tracepoint_event+0x1c64>
    1ab4:      	mov	w8, #0x2                // =2
    1ab8:      	mov	w9, #0x4                // =4
    1abc:      	add	x10, sp, #0x88
    1ac0:      	add	x0, sp, #0x88
    1ac4:      	mov	w1, #0x2                // =2
    1ac8:      	blr	x9
    1acc:      	cbz	x0, 0x1c90 <generic_tracepoint_event+0x1c90>
    1ad0:      	neg	w8, w0
    1ad4:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1ad8:      	mov	w9, #0x1                // =1
    1adc:      	strh	w8, [sp, #0x38]
    1ae0:      	mov	w8, #0x7                // =7
    1ae4:      	add	x1, sp, #0x38
    1ae8:      	mov	w24, #0x1               // =1
    1aec:      	strh	w8, [sp, #0x3a]
    1af0:      	mov	x8, #0x65               // =101
    1af4:      	movk	x8, #0x4, lsl #32
    1af8:      	stur	x8, [sp, #0x3c]
    1afc:      	add	x8, sp, #0x38
    1b00:      	ldr	x22, [x22]
    1b04:      	mov	x0, x22
    1b08:      	blr	x9
    1b0c:      	cbz	x0, 0x1c6c <generic_tracepoint_event+0x1c6c>
    1b10:      	ldr	w8, [x0]
    1b14:      	add	w8, w8, #0x1
    1b18:      	str	w8, [x0]
    1b1c:      	ldrh	w22, [sp, #0x88]
    1b20:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1b24:      	mov	w8, #0x4                // =4
    1b28:      	add	x9, sp, #0x88
    1b2c:      	add	x0, sp, #0x88
    1b30:      	mov	w1, #0x4                // =4
    1b34:      	blr	x8
    1b38:      	cbz	x0, 0x1cbc <generic_tracepoint_event+0x1cbc>
    1b3c:      	neg	w8, w0
    1b40:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1b44:      	mov	w9, #0x1                // =1
    1b48:      	strh	w8, [sp, #0x38]
    1b4c:      	mov	w8, #0x7                // =7
    1b50:      	add	x1, sp, #0x38
    1b54:      	mov	w24, #0x1               // =1
    1b58:      	strh	w8, [sp, #0x3a]
    1b5c:      	mov	x8, #0x88               // =136
    1b60:      	movk	x8, #0x4, lsl #32
    1b64:      	stur	x8, [sp, #0x3c]
    1b68:      	add	x8, sp, #0x38
    1b6c:      	ldr	x22, [x22]
    1b70:      	mov	x0, x22
    1b74:      	blr	x9
    1b78:      	cbz	x0, 0x1c98 <generic_tracepoint_event+0x1c98>
    1b7c:      	ldr	w8, [x0]
    1b80:      	add	w8, w8, #0x1
    1b84:      	str	w8, [x0]
    1b88:      	ldr	w22, [sp, #0x88]
    1b8c:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1b90:      	str	w24, [sp, #0x20]
    1b94:      	mov	x3, xzr
    1b98:      	mov	w8, #0x2                // =2
    1b9c:      	add	x9, sp, #0x38
    1ba0:      	add	x10, sp, #0x20
    1ba4:      	add	x1, sp, #0x38
    1ba8:      	add	x2, sp, #0x20
    1bac:      	mov	x0, x22
    1bb0:      	blr	x8
    1bb4:      	ldrsw	x22, [sp, #0x88]
    1bb8:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1bbc:      	str	w24, [sp, #0x20]
    1bc0:      	mov	x3, xzr
    1bc4:      	mov	w8, #0x2                // =2
    1bc8:      	add	x9, sp, #0x38
    1bcc:      	add	x10, sp, #0x20
    1bd0:      	add	x1, sp, #0x38
    1bd4:      	add	x2, sp, #0x20
    1bd8:      	mov	x0, x22
    1bdc:      	blr	x8
    1be0:      	ldrsh	x22, [sp, #0x88]
    1be4:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1be8:      	str	w24, [sp, #0x20]
    1bec:      	mov	x3, xzr
    1bf0:      	mov	w8, #0x2                // =2
    1bf4:      	add	x9, sp, #0x38
    1bf8:      	add	x10, sp, #0x20
    1bfc:      	add	x1, sp, #0x38
    1c00:      	add	x2, sp, #0x20
    1c04:      	mov	x0, x22
    1c08:      	blr	x8
    1c0c:      	ldrsb	x22, [sp, #0x88]
    1c10:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1c14:      	str	w24, [sp, #0x20]
    1c18:      	mov	x3, xzr
    1c1c:      	mov	w8, #0x2                // =2
    1c20:      	add	x9, sp, #0x38
    1c24:      	add	x10, sp, #0x20
    1c28:      	add	x1, sp, #0x38
    1c2c:      	add	x2, sp, #0x20
    1c30:      	mov	x0, x22
    1c34:      	blr	x8
    1c38:      	ldrb	w22, [sp, #0x88]
    1c3c:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1c40:      	str	w24, [sp, #0x88]
    1c44:      	mov	x3, xzr
    1c48:      	mov	w8, #0x2                // =2
    1c4c:      	add	x9, sp, #0x38
    1c50:      	add	x10, sp, #0x88
    1c54:      	add	x1, sp, #0x38
    1c58:      	add	x2, sp, #0x88
    1c5c:      	mov	x0, x22
    1c60:      	blr	x8
    1c64:      	ldr	x22, [sp, #0x20]
    1c68:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1c6c:      	str	w24, [sp, #0x20]
    1c70:      	mov	x3, xzr
    1c74:      	mov	w8, #0x2                // =2
    1c78:      	add	x9, sp, #0x38
    1c7c:      	add	x10, sp, #0x20
    1c80:      	add	x1, sp, #0x38
    1c84:      	add	x2, sp, #0x20
    1c88:      	mov	x0, x22
    1c8c:      	blr	x8
    1c90:      	ldrh	w22, [sp, #0x88]
    1c94:      	b	0x1cc0 <generic_tracepoint_event+0x1cc0>
    1c98:      	str	w24, [sp, #0x20]
    1c9c:      	mov	x3, xzr
    1ca0:      	mov	w8, #0x2                // =2
    1ca4:      	add	x9, sp, #0x38
    1ca8:      	add	x10, sp, #0x20
    1cac:      	add	x1, sp, #0x38
    1cb0:      	add	x2, sp, #0x20
    1cb4:      	mov	x0, x22
    1cb8:      	blr	x8
    1cbc:      	ldr	w22, [sp, #0x88]
    1cc0:      	str	x22, [x20, #0x5e60]
    1cc4:      	mov	x24, xzr
    1cc8:      	ldrh	w8, [x21, #0x38]
    1ccc:      	ldr	w25, [x21, #0x10]
    1cd0:      	add	x2, x19, x8
    1cd4:      	cmp	w25, #0xb
    1cd8:      	b.gt	0x1d08 <generic_tracepoint_event+0x1d08>
    1cdc:      	cmp	w25, #0x3
    1ce0:      	b.le	0x1da0 <generic_tracepoint_event+0x1da0>
    1ce4:      	cmp	w25, #0x6
    1ce8:      	b.gt	0x1ec0 <generic_tracepoint_event+0x1ec0>
    1cec:      	cmp	w25, #0x4
    1cf0:      	b.eq	0x2308 <generic_tracepoint_event+0x2308>
    1cf4:      	cmp	w25, #0x5
    1cf8:      	b.eq	0x21b0 <generic_tracepoint_event+0x21b0>
    1cfc:      	cmp	w25, #0x6
    1d00:      	b.eq	0x1dbc <generic_tracepoint_event+0x1dbc>
    1d04:      	b	0x2580 <generic_tracepoint_event+0x2580>
    1d08:      	cmp	w25, #0x1d
    1d0c:      	b.le	0x1e30 <generic_tracepoint_event+0x1e30>
    1d10:      	cmp	w25, #0x25
    1d14:      	b.gt	0x1f38 <generic_tracepoint_event+0x1f38>
    1d18:      	cmp	w25, #0x1e
    1d1c:      	b.eq	0x2374 <generic_tracepoint_event+0x2374>
    1d20:      	cmp	w25, #0x1f
    1d24:      	b.eq	0x2224 <generic_tracepoint_event+0x2224>
    1d28:      	cmp	w25, #0x20
    1d2c:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    1d30:      	mov	w8, #0x1                // =1
    1d34:      	mov	w9, #0x4                // =4
    1d38:      	add	x10, sp, #0x88
    1d3c:      	add	x0, sp, #0x88
    1d40:      	mov	w1, #0x1                // =1
    1d44:      	blr	x9
    1d48:      	cbz	x0, 0x24f8 <generic_tracepoint_event+0x24f8>
    1d4c:      	neg	w8, w0
    1d50:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1d54:      	mov	w9, #0x1                // =1
    1d58:      	strh	w8, [sp, #0x38]
    1d5c:      	mov	w8, #0x7                // =7
    1d60:      	add	x1, sp, #0x38
    1d64:      	mov	w24, #0x1               // =1
    1d68:      	strh	w8, [sp, #0x3a]
    1d6c:      	mov	x8, #0x73               // =115
    1d70:      	movk	x8, #0x4, lsl #32
    1d74:      	stur	x8, [sp, #0x3c]
    1d78:      	add	x8, sp, #0x38
    1d7c:      	ldr	x22, [x22]
    1d80:      	mov	x0, x22
    1d84:      	blr	x9
    1d88:      	cbz	x0, 0x24d4 <generic_tracepoint_event+0x24d4>
    1d8c:      	ldr	w8, [x0]
    1d90:      	add	w8, w8, #0x1
    1d94:      	str	w8, [x0]
    1d98:      	ldrb	w24, [sp, #0x88]
    1d9c:      	b	0x2580 <generic_tracepoint_event+0x2580>
    1da0:      	cmn	w25, #0xc
    1da4:      	b.le	0x1fc4 <generic_tracepoint_event+0x1fc4>
    1da8:      	add	w8, w25, #0xb
    1dac:      	cmp	w8, #0x2
    1db0:      	b.lo	0x1ecc <generic_tracepoint_event+0x1ecc>
    1db4:      	cmp	w25, #0x2
    1db8:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    1dbc:      	mov	w8, #0x8                // =8
    1dc0:      	mov	w9, #0x4                // =4
    1dc4:      	add	x10, sp, #0x20
    1dc8:      	add	x0, sp, #0x20
    1dcc:      	mov	w1, #0x8                // =8
    1dd0:      	blr	x9
    1dd4:      	cbz	x0, 0x2524 <generic_tracepoint_event+0x2524>
    1dd8:      	neg	w8, w0
    1ddc:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1de0:      	mov	w9, #0x1                // =1
    1de4:      	strh	w8, [sp, #0x38]
    1de8:      	mov	w8, #0x7                // =7
    1dec:      	add	x1, sp, #0x38
    1df0:      	mov	w24, #0x1               // =1
    1df4:      	strh	w8, [sp, #0x3a]
    1df8:      	mov	x8, #0x81               // =129
    1dfc:      	movk	x8, #0x4, lsl #32
    1e00:      	stur	x8, [sp, #0x3c]
    1e04:      	add	x8, sp, #0x38
    1e08:      	ldr	x22, [x22]
    1e0c:      	mov	x0, x22
    1e10:      	blr	x9
    1e14:      	cbnz	x0, 0x2364 <generic_tracepoint_event+0x2364>
    1e18:      	str	w24, [sp, #0x88]
    1e1c:      	mov	x3, xzr
    1e20:      	mov	w8, #0x2                // =2
    1e24:      	add	x9, sp, #0x38
    1e28:      	add	x10, sp, #0x88
    1e2c:      	b	0x2514 <generic_tracepoint_event+0x2514>
    1e30:      	cmp	w25, #0x11
    1e34:      	b.le	0x1fd8 <generic_tracepoint_event+0x1fd8>
    1e38:      	cmp	w25, #0x12
    1e3c:      	b.eq	0x21a8 <generic_tracepoint_event+0x21a8>
    1e40:      	cmp	w25, #0x1c
    1e44:      	b.eq	0x1ecc <generic_tracepoint_event+0x1ecc>
    1e48:      	cmp	w25, #0x1d
    1e4c:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    1e50:      	mov	w8, #0x2                // =2
    1e54:      	mov	w9, #0x4                // =4
    1e58:      	add	x10, sp, #0x88
    1e5c:      	add	x0, sp, #0x88
    1e60:      	mov	w1, #0x2                // =2
    1e64:      	blr	x9
    1e68:      	cbz	x0, 0x24a0 <generic_tracepoint_event+0x24a0>
    1e6c:      	neg	w8, w0
    1e70:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1e74:      	mov	w9, #0x1                // =1
    1e78:      	strh	w8, [sp, #0x38]
    1e7c:      	mov	w8, #0x7                // =7
    1e80:      	add	x1, sp, #0x38
    1e84:      	mov	w24, #0x1               // =1
    1e88:      	strh	w8, [sp, #0x3a]
    1e8c:      	mov	x8, #0x6c               // =108
    1e90:      	movk	x8, #0x4, lsl #32
    1e94:      	stur	x8, [sp, #0x3c]
    1e98:      	add	x8, sp, #0x38
    1e9c:      	ldr	x22, [x22]
    1ea0:      	mov	x0, x22
    1ea4:      	blr	x9
    1ea8:      	cbz	x0, 0x247c <generic_tracepoint_event+0x247c>
    1eac:      	ldr	w8, [x0]
    1eb0:      	add	w8, w8, #0x1
    1eb4:      	str	w8, [x0]
    1eb8:      	ldrsh	x24, [sp, #0x88]
    1ebc:      	b	0x2580 <generic_tracepoint_event+0x2580>
    1ec0:      	sub	w8, w25, #0xa
    1ec4:      	cmp	w8, #0x2
    1ec8:      	b.hs	0x212c <generic_tracepoint_event+0x212c>
    1ecc:      	mov	w8, #0x8                // =8
    1ed0:      	mov	w9, #0x4                // =4
    1ed4:      	add	x10, sp, #0x20
    1ed8:      	add	x0, sp, #0x20
    1edc:      	mov	w1, #0x8                // =8
    1ee0:      	blr	x9
    1ee4:      	cbz	x0, 0x20e8 <generic_tracepoint_event+0x20e8>
    1ee8:      	neg	w8, w0
    1eec:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1ef0:      	mov	w9, #0x1                // =1
    1ef4:      	strh	w8, [sp, #0x38]
    1ef8:      	mov	w8, #0x7                // =7
    1efc:      	add	x1, sp, #0x38
    1f00:      	mov	w24, #0x1               // =1
    1f04:      	strh	w8, [sp, #0x3a]
    1f08:      	mov	x8, #0x45               // =69
    1f0c:      	movk	x8, #0x4, lsl #32
    1f10:      	stur	x8, [sp, #0x3c]
    1f14:      	add	x8, sp, #0x38
    1f18:      	ldr	x22, [x22]
    1f1c:      	mov	x0, x22
    1f20:      	blr	x9
    1f24:      	cbz	x0, 0x20c4 <generic_tracepoint_event+0x20c4>
    1f28:      	ldr	w8, [x0]
    1f2c:      	add	w8, w8, #0x1
    1f30:      	str	w8, [x0]
    1f34:      	b	0x20e8 <generic_tracepoint_event+0x20e8>
    1f38:      	cmp	w25, #0x26
    1f3c:      	b.eq	0x23e4 <generic_tracepoint_event+0x23e4>
    1f40:      	cmp	w25, #0x28
    1f44:      	b.eq	0x2294 <generic_tracepoint_event+0x2294>
    1f48:      	cmp	w25, #0x29
    1f4c:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    1f50:      	mov	w8, #0x8                // =8
    1f54:      	mov	w9, #0x4                // =4
    1f58:      	add	x10, sp, #0x20
    1f5c:      	add	x0, sp, #0x20
    1f60:      	mov	w1, #0x8                // =8
    1f64:      	blr	x9
    1f68:      	cbz	x0, 0x2524 <generic_tracepoint_event+0x2524>
    1f6c:      	neg	w8, w0
    1f70:      	adrp	x22, 0x1000 <generic_tracepoint_event+0x1000>
    1f74:      	mov	w9, #0x1                // =1
    1f78:      	strh	w8, [sp, #0x38]
    1f7c:      	mov	w8, #0x7                // =7
    1f80:      	add	x1, sp, #0x38
    1f84:      	mov	w24, #0x1               // =1
    1f88:      	strh	w8, [sp, #0x3a]
    1f8c:      	mov	x8, #0xa8               // =168
    1f90:      	movk	x8, #0x4, lsl #32
    1f94:      	stur	x8, [sp, #0x3c]
    1f98:      	add	x8, sp, #0x38
    1f9c:      	ldr	x22, [x22]
    1fa0:      	mov	x0, x22
    1fa4:      	blr	x9
    1fa8:      	cbnz	x0, 0x2364 <generic_tracepoint_event+0x2364>
    1fac:      	str	w24, [sp, #0x88]
    1fb0:      	mov	x3, xzr
    1fb4:      	mov	w8, #0x2                // =2
    1fb8:      	add	x9, sp, #0x38
    1fbc:      	add	x10, sp, #0x88
    1fc0:      	b	0x2514 <generic_tracepoint_event+0x2514>
    1fc4:      	cmn	w25, #0xd
    1fc8:      	b.eq	0x2058 <generic_tracepoint_event+0x2058>
    1fcc:      	cmn	w25, #0xc
    1fd0:      	b.eq	0x1fe8 <generic_tracepoint_event+0x1fe8>
    1fd4:      	b	0x2580 <generic_tracepoint_event+0x2580>
    1fd8:      	cmp	w25, #0xc
    1fdc:      	b.eq	0x2058 <generic_tracepoint_event+0x2058>
    1fe0:      	cmp	w25, #0xd
    1fe4:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    1fe8:      	mov	w8, #0x4                // =4
    1fec:      	add	x9, sp, #0x88
    1ff0:      	add	x0, sp, #0x88
    1ff4:      	mov	w1, #0x4                // =4
    1ff8:      	blr	x8
    1ffc:      	cbz	x0, 0x257c <generic_tracepoint_event+0x257c>
    2000:      	neg	w8, w0
    2004:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    2008:      	mov	w9, #0x1                // =1
    200c:      	strh	w8, [sp, #0x38]
    2010:      	mov	w8, #0x7                // =7
    2014:      	add	x1, sp, #0x38
    2018:      	mov	w24, #0x1               // =1
    201c:      	strh	w8, [sp, #0x3a]
    2020:      	mov	x8, #0x5e               // =94
    2024:      	movk	x8, #0x4, lsl #32
    2028:      	stur	x8, [sp, #0x3c]
    202c:      	add	x8, sp, #0x38
    2030:      	ldr	x22, [x22]
    2034:      	mov	x0, x22
    2038:      	blr	x9
    203c:      	cbnz	x0, 0x243c <generic_tracepoint_event+0x243c>
    2040:      	str	w24, [sp, #0x20]
    2044:      	mov	x3, xzr
    2048:      	mov	w8, #0x2                // =2
    204c:      	add	x9, sp, #0x38
    2050:      	add	x10, sp, #0x20
    2054:      	b	0x256c <generic_tracepoint_event+0x256c>
    2058:      	mov	w8, #0x4                // =4
    205c:      	add	x9, sp, #0x88
    2060:      	add	x0, sp, #0x88
    2064:      	mov	w1, #0x4                // =4
    2068:      	blr	x8
    206c:      	cbz	x0, 0x2474 <generic_tracepoint_event+0x2474>
    2070:      	neg	w8, w0
    2074:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    2078:      	mov	w9, #0x1                // =1
    207c:      	strh	w8, [sp, #0x38]
    2080:      	mov	w8, #0x7                // =7
    2084:      	add	x1, sp, #0x38
    2088:      	mov	w24, #0x1               // =1
    208c:      	strh	w8, [sp, #0x3a]
    2090:      	mov	x8, #0x56               // =86
    2094:      	movk	x8, #0x4, lsl #32
    2098:      	stur	x8, [sp, #0x3c]
    209c:      	add	x8, sp, #0x38
    20a0:      	ldr	x22, [x22]
    20a4:      	mov	x0, x22
    20a8:      	blr	x9
    20ac:      	cbz	x0, 0x2450 <generic_tracepoint_event+0x2450>
    20b0:      	ldr	w8, [x0]
    20b4:      	add	w8, w8, #0x1
    20b8:      	str	w8, [x0]
    20bc:      	ldrsw	x24, [sp, #0x88]
    20c0:      	b	0x2580 <generic_tracepoint_event+0x2580>
    20c4:      	str	w24, [sp, #0x88]
    20c8:      	mov	x3, xzr
    20cc:      	mov	w8, #0x2                // =2
    20d0:      	add	x9, sp, #0x38
    20d4:      	add	x10, sp, #0x88
    20d8:      	add	x1, sp, #0x38
    20dc:      	add	x2, sp, #0x88
    20e0:      	mov	x0, x22
    20e4:      	blr	x8
    20e8:      	ldr	x24, [sp, #0x20]
    20ec:      	cmp	w25, #0x1c
    20f0:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    20f4:      	mov	w8, #0x23               // =35
    20f8:      	blr	x8
    20fc:      	mov	w8, #0x8                // =8
    2100:      	mov	w9, #0x4                // =4
    2104:      	add	x10, sp, #0x38
    2108:      	mov	x2, x0
    210c:      	add	x0, sp, #0x38
    2110:      	mov	w1, #0x8                // =8
    2114:      	blr	x9
    2118:      	ldr	w8, [sp, #0x38]
    211c:      	lsl	w8, w8, #9
    2120:      	and	x8, x8, #0x80000000
    2124:      	orr	x24, x8, x24
    2128:      	b	0x2580 <generic_tracepoint_event+0x2580>
    212c:      	cmp	w25, #0x7
    2130:      	b.ne	0x2580 <generic_tracepoint_event+0x2580>
    2134:      	mov	w8, #0x8                // =8
    2138:      	mov	w9, #0x4                // =4
    213c:      	add	x10, sp, #0x20
    2140:      	add	x0, sp, #0x20
    2144:      	mov	w1, #0x8                // =8
    2148:      	blr	x9
    214c:      	cbz	x0, 0x2524 <generic_tracepoint_event+0x2524>
    2150:      	neg	w8, w0
    2154:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    2158:      	mov	w9, #0x1                // =1
    215c:      	strh	w8, [sp, #0x38]
    2160:      	mov	w8, #0x7                // =7
    2164:      	add	x1, sp, #0x38
    2168:      	mov	w24, #0x1               // =1
    216c:      	strh	w8, [sp, #0x3a]
    2170:      	mov	x8, #0x9a               // =154
    2174:      	movk	x8, #0x4, lsl #32
    2178:      	stur	x8, [sp, #0x3c]
    217c:      	add	x8, sp, #0x38
    2180:      	ldr	x22, [x22]
    2184:      	mov	x0, x22
    2188:      	blr	x9
    218c:      	cbnz	x0, 0x2364 <generic_tracepoint_event+0x2364>
    2190:      	str	w24, [sp, #0x88]
    2194:      	mov	x3, xzr
    2198:      	mov	w8, #0x2                // =2
    219c:      	add	x9, sp, #0x38
    21a0:      	add	x10, sp, #0x88
    21a4:      	b	0x2514 <generic_tracepoint_event+0x2514>
    21a8:      	mov	x24, x2
    21ac:      	b	0x2580 <generic_tracepoint_event+0x2580>
    21b0:      	mov	w8, #0x8                // =8
    21b4:      	mov	w9, #0x4                // =4
    21b8:      	add	x10, sp, #0x20
    21bc:      	add	x0, sp, #0x20
    21c0:      	mov	w1, #0x8                // =8
    21c4:      	blr	x9
    21c8:      	cbz	x0, 0x2524 <generic_tracepoint_event+0x2524>
    21cc:      	neg	w8, w0
    21d0:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    21d4:      	mov	w9, #0x1                // =1
    21d8:      	strh	w8, [sp, #0x38]
    21dc:      	mov	w8, #0x7                // =7
    21e0:      	add	x1, sp, #0x38
    21e4:      	mov	w24, #0x1               // =1
    21e8:      	strh	w8, [sp, #0x3a]
    21ec:      	mov	x8, #0x93               // =147
    21f0:      	movk	x8, #0x4, lsl #32
    21f4:      	stur	x8, [sp, #0x3c]
    21f8:      	add	x8, sp, #0x38
    21fc:      	ldr	x22, [x22]
    2200:      	mov	x0, x22
    2204:      	blr	x9
    2208:      	cbnz	x0, 0x2364 <generic_tracepoint_event+0x2364>
    220c:      	str	w24, [sp, #0x88]
    2210:      	mov	x3, xzr
    2214:      	mov	w8, #0x2                // =2
    2218:      	add	x9, sp, #0x38
    221c:      	add	x10, sp, #0x88
    2220:      	b	0x2514 <generic_tracepoint_event+0x2514>
    2224:      	mov	w8, #0x1                // =1
    2228:      	mov	w9, #0x4                // =4
    222c:      	add	x10, sp, #0x88
    2230:      	add	x0, sp, #0x88
    2234:      	mov	w1, #0x1                // =1
    2238:      	blr	x9
    223c:      	cbz	x0, 0x24cc <generic_tracepoint_event+0x24cc>
    2240:      	neg	w8, w0
    2244:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    2248:      	mov	w9, #0x1                // =1
    224c:      	strh	w8, [sp, #0x38]
    2250:      	mov	w8, #0x7                // =7
    2254:      	add	x1, sp, #0x38
    2258:      	mov	w24, #0x1               // =1
    225c:      	strh	w8, [sp, #0x3a]
    2260:      	mov	x8, #0x7a               // =122
    2264:      	movk	x8, #0x4, lsl #32
    2268:      	stur	x8, [sp, #0x3c]
    226c:      	add	x8, sp, #0x38
    2270:      	ldr	x22, [x22]
    2274:      	mov	x0, x22
    2278:      	blr	x9
    227c:      	cbz	x0, 0x24a8 <generic_tracepoint_event+0x24a8>
    2280:      	ldr	w8, [x0]
    2284:      	add	w8, w8, #0x1
    2288:      	str	w8, [x0]
    228c:      	ldrsb	x24, [sp, #0x88]
    2290:      	b	0x2580 <generic_tracepoint_event+0x2580>
    2294:      	mov	w8, #0x8                // =8
    2298:      	mov	w9, #0x4                // =4
    229c:      	add	x10, sp, #0x20
    22a0:      	add	x0, sp, #0x20
    22a4:      	mov	w1, #0x8                // =8
    22a8:      	blr	x9
    22ac:      	cbz	x0, 0x2524 <generic_tracepoint_event+0x2524>
    22b0:      	neg	w8, w0
    22b4:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    22b8:      	mov	w9, #0x1                // =1
    22bc:      	strh	w8, [sp, #0x38]
    22c0:      	mov	w8, #0x7                // =7
    22c4:      	add	x1, sp, #0x38
    22c8:      	mov	w24, #0x1               // =1
    22cc:      	strh	w8, [sp, #0x3a]
    22d0:      	mov	x8, #0xa1               // =161
    22d4:      	movk	x8, #0x4, lsl #32
    22d8:      	stur	x8, [sp, #0x3c]
    22dc:      	add	x8, sp, #0x38
    22e0:      	ldr	x22, [x22]
    22e4:      	mov	x0, x22
    22e8:      	blr	x9
    22ec:      	cbnz	x0, 0x2364 <generic_tracepoint_event+0x2364>
    22f0:      	str	w24, [sp, #0x88]
    22f4:      	mov	x3, xzr
    22f8:      	mov	w8, #0x2                // =2
    22fc:      	add	x9, sp, #0x38
    2300:      	add	x10, sp, #0x88
    2304:      	b	0x2514 <generic_tracepoint_event+0x2514>
    2308:      	mov	w8, #0x8                // =8
    230c:      	mov	w9, #0x4                // =4
    2310:      	add	x10, sp, #0x20
    2314:      	add	x0, sp, #0x20
    2318:      	mov	w1, #0x8                // =8
    231c:      	blr	x9
    2320:      	cbz	x0, 0x2524 <generic_tracepoint_event+0x2524>
    2324:      	neg	w8, w0
    2328:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    232c:      	mov	w9, #0x1                // =1
    2330:      	strh	w8, [sp, #0x38]
    2334:      	mov	w8, #0x7                // =7
    2338:      	add	x1, sp, #0x38
    233c:      	mov	w24, #0x1               // =1
    2340:      	strh	w8, [sp, #0x3a]
    2344:      	mov	x8, #0x4e               // =78
    2348:      	movk	x8, #0x4, lsl #32
    234c:      	stur	x8, [sp, #0x3c]
    2350:      	add	x8, sp, #0x38
    2354:      	ldr	x22, [x22]
    2358:      	mov	x0, x22
    235c:      	blr	x9
    2360:      	cbz	x0, 0x2500 <generic_tracepoint_event+0x2500>
    2364:      	ldr	w8, [x0]
    2368:      	add	w8, w8, #0x1
    236c:      	str	w8, [x0]
    2370:      	b	0x2524 <generic_tracepoint_event+0x2524>
    2374:      	mov	w8, #0x2                // =2
    2378:      	mov	w9, #0x4                // =4
    237c:      	add	x10, sp, #0x88
    2380:      	add	x0, sp, #0x88
    2384:      	mov	w1, #0x2                // =2
    2388:      	blr	x9
    238c:      	cbz	x0, 0x2550 <generic_tracepoint_event+0x2550>
    2390:      	neg	w8, w0
    2394:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    2398:      	mov	w9, #0x1                // =1
    239c:      	strh	w8, [sp, #0x38]
    23a0:      	mov	w8, #0x7                // =7
    23a4:      	add	x1, sp, #0x38
    23a8:      	mov	w24, #0x1               // =1
    23ac:      	strh	w8, [sp, #0x3a]
    23b0:      	mov	x8, #0x65               // =101
    23b4:      	movk	x8, #0x4, lsl #32
    23b8:      	stur	x8, [sp, #0x3c]
    23bc:      	add	x8, sp, #0x38
    23c0:      	ldr	x22, [x22]
    23c4:      	mov	x0, x22
    23c8:      	blr	x9
    23cc:      	cbz	x0, 0x252c <generic_tracepoint_event+0x252c>
    23d0:      	ldr	w8, [x0]
    23d4:      	add	w8, w8, #0x1
    23d8:      	str	w8, [x0]
    23dc:      	ldrh	w24, [sp, #0x88]
    23e0:      	b	0x2580 <generic_tracepoint_event+0x2580>
    23e4:      	mov	w8, #0x4                // =4
    23e8:      	add	x9, sp, #0x88
    23ec:      	add	x0, sp, #0x88
    23f0:      	mov	w1, #0x4                // =4
    23f4:      	blr	x8
    23f8:      	cbz	x0, 0x257c <generic_tracepoint_event+0x257c>
    23fc:      	neg	w8, w0
    2400:      	adrp	x22, 0x2000 <generic_tracepoint_event+0x2000>
    2404:      	mov	w9, #0x1                // =1
    2408:      	strh	w8, [sp, #0x38]
    240c:      	mov	w8, #0x7                // =7
    2410:      	add	x1, sp, #0x38
    2414:      	mov	w24, #0x1               // =1
    2418:      	strh	w8, [sp, #0x3a]
    241c:      	mov	x8, #0x88               // =136
    2420:      	movk	x8, #0x4, lsl #32
    2424:      	stur	x8, [sp, #0x3c]
    2428:      	add	x8, sp, #0x38
    242c:      	ldr	x22, [x22]
    2430:      	mov	x0, x22
    2434:      	blr	x9
    2438:      	cbz	x0, 0x2558 <generic_tracepoint_event+0x2558>
    243c:      	ldr	w8, [x0]
    2440:      	add	w8, w8, #0x1
    2444:      	str	w8, [x0]
    2448:      	ldr	w24, [sp, #0x88]
    244c:      	b	0x2580 <generic_tracepoint_event+0x2580>
    2450:      	str	w24, [sp, #0x20]
    2454:      	mov	x3, xzr
    2458:      	mov	w8, #0x2                // =2
    245c:      	add	x9, sp, #0x38
    2460:      	add	x10, sp, #0x20
    2464:      	add	x1, sp, #0x38
    2468:      	add	x2, sp, #0x20
    246c:      	mov	x0, x22
    2470:      	blr	x8
    2474:      	ldrsw	x24, [sp, #0x88]
    2478:      	b	0x2580 <generic_tracepoint_event+0x2580>
    247c:      	str	w24, [sp, #0x20]
    2480:      	mov	x3, xzr
    2484:      	mov	w8, #0x2                // =2
    2488:      	add	x9, sp, #0x38
    248c:      	add	x10, sp, #0x20
    2490:      	add	x1, sp, #0x38
    2494:      	add	x2, sp, #0x20
    2498:      	mov	x0, x22
    249c:      	blr	x8
    24a0:      	ldrsh	x24, [sp, #0x88]
    24a4:      	b	0x2580 <generic_tracepoint_event+0x2580>
    24a8:      	str	w24, [sp, #0x20]
    24ac:      	mov	x3, xzr
    24b0:      	mov	w8, #0x2                // =2
    24b4:      	add	x9, sp, #0x38
    24b8:      	add	x10, sp, #0x20
    24bc:      	add	x1, sp, #0x38
    24c0:      	add	x2, sp, #0x20
    24c4:      	mov	x0, x22
    24c8:      	blr	x8
    24cc:      	ldrsb	x24, [sp, #0x88]
    24d0:      	b	0x2580 <generic_tracepoint_event+0x2580>
    24d4:      	str	w24, [sp, #0x20]
    24d8:      	mov	x3, xzr
    24dc:      	mov	w8, #0x2                // =2
    24e0:      	add	x9, sp, #0x38
    24e4:      	add	x10, sp, #0x20
    24e8:      	add	x1, sp, #0x38
    24ec:      	add	x2, sp, #0x20
    24f0:      	mov	x0, x22
    24f4:      	blr	x8
    24f8:      	ldrb	w24, [sp, #0x88]
    24fc:      	b	0x2580 <generic_tracepoint_event+0x2580>
    2500:      	str	w24, [sp, #0x88]
    2504:      	mov	x3, xzr
    2508:      	mov	w8, #0x2                // =2
    250c:      	add	x9, sp, #0x38
    2510:      	add	x10, sp, #0x88
    2514:      	add	x1, sp, #0x38
    2518:      	add	x2, sp, #0x88
    251c:      	mov	x0, x22
    2520:      	blr	x8
    2524:      	ldr	x24, [sp, #0x20]
    2528:      	b	0x2580 <generic_tracepoint_event+0x2580>
    252c:      	str	w24, [sp, #0x20]
    2530:      	mov	x3, xzr
    2534:      	mov	w8, #0x2                // =2
    2538:      	add	x9, sp, #0x38
    253c:      	add	x10, sp, #0x20
    2540:      	add	x1, sp, #0x38
    2544:      	add	x2, sp, #0x20
    2548:      	mov	x0, x22
    254c:      	blr	x8
    2550:      	ldrh	w24, [sp, #0x88]
    2554:      	b	0x2580 <generic_tracepoint_event+0x2580>
    2558:      	str	w24, [sp, #0x20]
    255c:      	mov	x3, xzr
    2560:      	mov	w8, #0x2                // =2
    2564:      	add	x9, sp, #0x38
    2568:      	add	x10, sp, #0x20
    256c:      	add	x1, sp, #0x38
    2570:      	add	x2, sp, #0x20
    2574:      	mov	x0, x22
    2578:      	blr	x8
    257c:      	ldr	w24, [sp, #0x88]
    2580:      	str	x24, [x20, #0x5e68]
    2584:      	mov	x22, xzr
    2588:      	ldrh	w8, [x21, #0x3c]
    258c:      	ldr	w24, [x21, #0x14]
    2590:      	add	x2, x19, x8
    2594:      	cmp	w24, #0xb
    2598:      	b.gt	0x25c8 <generic_tracepoint_event+0x25c8>
    259c:      	cmp	w24, #0x3
    25a0:      	b.le	0x2660 <generic_tracepoint_event+0x2660>
    25a4:      	cmp	w24, #0x6
    25a8:      	b.gt	0x2780 <generic_tracepoint_event+0x2780>
    25ac:      	cmp	w24, #0x4
    25b0:      	b.eq	0x2bc8 <generic_tracepoint_event+0x2bc8>
    25b4:      	cmp	w24, #0x5
    25b8:      	b.eq	0x2a70 <generic_tracepoint_event+0x2a70>
    25bc:      	cmp	w24, #0x6
    25c0:      	b.eq	0x267c <generic_tracepoint_event+0x267c>
    25c4:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    25c8:      	cmp	w24, #0x1d
    25cc:      	b.le	0x26f0 <generic_tracepoint_event+0x26f0>
    25d0:      	cmp	w24, #0x25
    25d4:      	b.gt	0x27f8 <generic_tracepoint_event+0x27f8>
    25d8:      	cmp	w24, #0x1e
    25dc:      	b.eq	0x2c34 <generic_tracepoint_event+0x2c34>
    25e0:      	cmp	w24, #0x1f
    25e4:      	b.eq	0x2ae4 <generic_tracepoint_event+0x2ae4>
    25e8:      	cmp	w24, #0x20
    25ec:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    25f0:      	mov	w8, #0x1                // =1
    25f4:      	mov	w9, #0x4                // =4
    25f8:      	add	x10, sp, #0x88
    25fc:      	add	x0, sp, #0x88
    2600:      	mov	w1, #0x1                // =1
    2604:      	blr	x9
    2608:      	cbz	x0, 0x2db8 <generic_tracepoint_event+0x2db8>
    260c:      	neg	w8, w0
    2610:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2614:      	mov	w9, #0x1                // =1
    2618:      	strh	w8, [sp, #0x38]
    261c:      	mov	w8, #0x7                // =7
    2620:      	add	x1, sp, #0x38
    2624:      	mov	w22, #0x1               // =1
    2628:      	strh	w8, [sp, #0x3a]
    262c:      	mov	x8, #0x73               // =115
    2630:      	movk	x8, #0x4, lsl #32
    2634:      	stur	x8, [sp, #0x3c]
    2638:      	add	x8, sp, #0x38
    263c:      	ldr	x21, [x21]
    2640:      	mov	x0, x21
    2644:      	blr	x9
    2648:      	cbz	x0, 0x2d94 <generic_tracepoint_event+0x2d94>
    264c:      	ldr	w8, [x0]
    2650:      	add	w8, w8, #0x1
    2654:      	str	w8, [x0]
    2658:      	ldrb	w22, [sp, #0x88]
    265c:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2660:      	cmn	w24, #0xc
    2664:      	b.le	0x2884 <generic_tracepoint_event+0x2884>
    2668:      	add	w8, w24, #0xb
    266c:      	cmp	w8, #0x2
    2670:      	b.lo	0x278c <generic_tracepoint_event+0x278c>
    2674:      	cmp	w24, #0x2
    2678:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    267c:      	mov	w8, #0x8                // =8
    2680:      	mov	w9, #0x4                // =4
    2684:      	add	x10, sp, #0x20
    2688:      	add	x0, sp, #0x20
    268c:      	mov	w1, #0x8                // =8
    2690:      	blr	x9
    2694:      	cbz	x0, 0x2de4 <generic_tracepoint_event+0x2de4>
    2698:      	neg	w8, w0
    269c:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    26a0:      	mov	w9, #0x1                // =1
    26a4:      	strh	w8, [sp, #0x38]
    26a8:      	mov	w8, #0x7                // =7
    26ac:      	add	x1, sp, #0x38
    26b0:      	mov	w22, #0x1               // =1
    26b4:      	strh	w8, [sp, #0x3a]
    26b8:      	mov	x8, #0x81               // =129
    26bc:      	movk	x8, #0x4, lsl #32
    26c0:      	stur	x8, [sp, #0x3c]
    26c4:      	add	x8, sp, #0x38
    26c8:      	ldr	x21, [x21]
    26cc:      	mov	x0, x21
    26d0:      	blr	x9
    26d4:      	cbnz	x0, 0x2c24 <generic_tracepoint_event+0x2c24>
    26d8:      	str	w22, [sp, #0x88]
    26dc:      	mov	x3, xzr
    26e0:      	mov	w8, #0x2                // =2
    26e4:      	add	x9, sp, #0x38
    26e8:      	add	x10, sp, #0x88
    26ec:      	b	0x2dd4 <generic_tracepoint_event+0x2dd4>
    26f0:      	cmp	w24, #0x11
    26f4:      	b.le	0x2898 <generic_tracepoint_event+0x2898>
    26f8:      	cmp	w24, #0x12
    26fc:      	b.eq	0x2a68 <generic_tracepoint_event+0x2a68>
    2700:      	cmp	w24, #0x1c
    2704:      	b.eq	0x278c <generic_tracepoint_event+0x278c>
    2708:      	cmp	w24, #0x1d
    270c:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    2710:      	mov	w8, #0x2                // =2
    2714:      	mov	w9, #0x4                // =4
    2718:      	add	x10, sp, #0x88
    271c:      	add	x0, sp, #0x88
    2720:      	mov	w1, #0x2                // =2
    2724:      	blr	x9
    2728:      	cbz	x0, 0x2d60 <generic_tracepoint_event+0x2d60>
    272c:      	neg	w8, w0
    2730:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2734:      	mov	w9, #0x1                // =1
    2738:      	strh	w8, [sp, #0x38]
    273c:      	mov	w8, #0x7                // =7
    2740:      	add	x1, sp, #0x38
    2744:      	mov	w22, #0x1               // =1
    2748:      	strh	w8, [sp, #0x3a]
    274c:      	mov	x8, #0x6c               // =108
    2750:      	movk	x8, #0x4, lsl #32
    2754:      	stur	x8, [sp, #0x3c]
    2758:      	add	x8, sp, #0x38
    275c:      	ldr	x21, [x21]
    2760:      	mov	x0, x21
    2764:      	blr	x9
    2768:      	cbz	x0, 0x2d3c <generic_tracepoint_event+0x2d3c>
    276c:      	ldr	w8, [x0]
    2770:      	add	w8, w8, #0x1
    2774:      	str	w8, [x0]
    2778:      	ldrsh	x22, [sp, #0x88]
    277c:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2780:      	sub	w8, w24, #0xa
    2784:      	cmp	w8, #0x2
    2788:      	b.hs	0x29ec <generic_tracepoint_event+0x29ec>
    278c:      	mov	w8, #0x8                // =8
    2790:      	mov	w9, #0x4                // =4
    2794:      	add	x10, sp, #0x20
    2798:      	add	x0, sp, #0x20
    279c:      	mov	w1, #0x8                // =8
    27a0:      	blr	x9
    27a4:      	cbz	x0, 0x29a8 <generic_tracepoint_event+0x29a8>
    27a8:      	neg	w8, w0
    27ac:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    27b0:      	mov	w9, #0x1                // =1
    27b4:      	strh	w8, [sp, #0x38]
    27b8:      	mov	w8, #0x7                // =7
    27bc:      	add	x1, sp, #0x38
    27c0:      	mov	w22, #0x1               // =1
    27c4:      	strh	w8, [sp, #0x3a]
    27c8:      	mov	x8, #0x45               // =69
    27cc:      	movk	x8, #0x4, lsl #32
    27d0:      	stur	x8, [sp, #0x3c]
    27d4:      	add	x8, sp, #0x38
    27d8:      	ldr	x21, [x21]
    27dc:      	mov	x0, x21
    27e0:      	blr	x9
    27e4:      	cbz	x0, 0x2984 <generic_tracepoint_event+0x2984>
    27e8:      	ldr	w8, [x0]
    27ec:      	add	w8, w8, #0x1
    27f0:      	str	w8, [x0]
    27f4:      	b	0x29a8 <generic_tracepoint_event+0x29a8>
    27f8:      	cmp	w24, #0x26
    27fc:      	b.eq	0x2ca4 <generic_tracepoint_event+0x2ca4>
    2800:      	cmp	w24, #0x28
    2804:      	b.eq	0x2b54 <generic_tracepoint_event+0x2b54>
    2808:      	cmp	w24, #0x29
    280c:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    2810:      	mov	w8, #0x8                // =8
    2814:      	mov	w9, #0x4                // =4
    2818:      	add	x10, sp, #0x20
    281c:      	add	x0, sp, #0x20
    2820:      	mov	w1, #0x8                // =8
    2824:      	blr	x9
    2828:      	cbz	x0, 0x2de4 <generic_tracepoint_event+0x2de4>
    282c:      	neg	w8, w0
    2830:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2834:      	mov	w9, #0x1                // =1
    2838:      	strh	w8, [sp, #0x38]
    283c:      	mov	w8, #0x7                // =7
    2840:      	add	x1, sp, #0x38
    2844:      	mov	w22, #0x1               // =1
    2848:      	strh	w8, [sp, #0x3a]
    284c:      	mov	x8, #0xa8               // =168
    2850:      	movk	x8, #0x4, lsl #32
    2854:      	stur	x8, [sp, #0x3c]
    2858:      	add	x8, sp, #0x38
    285c:      	ldr	x21, [x21]
    2860:      	mov	x0, x21
    2864:      	blr	x9
    2868:      	cbnz	x0, 0x2c24 <generic_tracepoint_event+0x2c24>
    286c:      	str	w22, [sp, #0x88]
    2870:      	mov	x3, xzr
    2874:      	mov	w8, #0x2                // =2
    2878:      	add	x9, sp, #0x38
    287c:      	add	x10, sp, #0x88
    2880:      	b	0x2dd4 <generic_tracepoint_event+0x2dd4>
    2884:      	cmn	w24, #0xd
    2888:      	b.eq	0x2918 <generic_tracepoint_event+0x2918>
    288c:      	cmn	w24, #0xc
    2890:      	b.eq	0x28a8 <generic_tracepoint_event+0x28a8>
    2894:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2898:      	cmp	w24, #0xc
    289c:      	b.eq	0x2918 <generic_tracepoint_event+0x2918>
    28a0:      	cmp	w24, #0xd
    28a4:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    28a8:      	mov	w8, #0x4                // =4
    28ac:      	add	x9, sp, #0x88
    28b0:      	add	x0, sp, #0x88
    28b4:      	mov	w1, #0x4                // =4
    28b8:      	blr	x8
    28bc:      	cbz	x0, 0x2e3c <generic_tracepoint_event+0x2e3c>
    28c0:      	neg	w8, w0
    28c4:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    28c8:      	mov	w9, #0x1                // =1
    28cc:      	strh	w8, [sp, #0x38]
    28d0:      	mov	w8, #0x7                // =7
    28d4:      	add	x1, sp, #0x38
    28d8:      	mov	w22, #0x1               // =1
    28dc:      	strh	w8, [sp, #0x3a]
    28e0:      	mov	x8, #0x5e               // =94
    28e4:      	movk	x8, #0x4, lsl #32
    28e8:      	stur	x8, [sp, #0x3c]
    28ec:      	add	x8, sp, #0x38
    28f0:      	ldr	x21, [x21]
    28f4:      	mov	x0, x21
    28f8:      	blr	x9
    28fc:      	cbnz	x0, 0x2cfc <generic_tracepoint_event+0x2cfc>
    2900:      	str	w22, [sp, #0x20]
    2904:      	mov	x3, xzr
    2908:      	mov	w8, #0x2                // =2
    290c:      	add	x9, sp, #0x38
    2910:      	add	x10, sp, #0x20
    2914:      	b	0x2e2c <generic_tracepoint_event+0x2e2c>
    2918:      	mov	w8, #0x4                // =4
    291c:      	add	x9, sp, #0x88
    2920:      	add	x0, sp, #0x88
    2924:      	mov	w1, #0x4                // =4
    2928:      	blr	x8
    292c:      	cbz	x0, 0x2d34 <generic_tracepoint_event+0x2d34>
    2930:      	neg	w8, w0
    2934:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2938:      	mov	w9, #0x1                // =1
    293c:      	strh	w8, [sp, #0x38]
    2940:      	mov	w8, #0x7                // =7
    2944:      	add	x1, sp, #0x38
    2948:      	mov	w22, #0x1               // =1
    294c:      	strh	w8, [sp, #0x3a]
    2950:      	mov	x8, #0x56               // =86
    2954:      	movk	x8, #0x4, lsl #32
    2958:      	stur	x8, [sp, #0x3c]
    295c:      	add	x8, sp, #0x38
    2960:      	ldr	x21, [x21]
    2964:      	mov	x0, x21
    2968:      	blr	x9
    296c:      	cbz	x0, 0x2d10 <generic_tracepoint_event+0x2d10>
    2970:      	ldr	w8, [x0]
    2974:      	add	w8, w8, #0x1
    2978:      	str	w8, [x0]
    297c:      	ldrsw	x22, [sp, #0x88]
    2980:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2984:      	str	w22, [sp, #0x88]
    2988:      	mov	x3, xzr
    298c:      	mov	w8, #0x2                // =2
    2990:      	add	x9, sp, #0x38
    2994:      	add	x10, sp, #0x88
    2998:      	add	x1, sp, #0x38
    299c:      	add	x2, sp, #0x88
    29a0:      	mov	x0, x21
    29a4:      	blr	x8
    29a8:      	ldr	x22, [sp, #0x20]
    29ac:      	cmp	w24, #0x1c
    29b0:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    29b4:      	mov	w8, #0x23               // =35
    29b8:      	blr	x8
    29bc:      	mov	w8, #0x8                // =8
    29c0:      	mov	w9, #0x4                // =4
    29c4:      	add	x10, sp, #0x38
    29c8:      	mov	x2, x0
    29cc:      	add	x0, sp, #0x38
    29d0:      	mov	w1, #0x8                // =8
    29d4:      	blr	x9
    29d8:      	ldr	w8, [sp, #0x38]
    29dc:      	lsl	w8, w8, #9
    29e0:      	and	x8, x8, #0x80000000
    29e4:      	orr	x22, x8, x22
    29e8:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    29ec:      	cmp	w24, #0x7
    29f0:      	b.ne	0x2e40 <generic_tracepoint_event+0x2e40>
    29f4:      	mov	w8, #0x8                // =8
    29f8:      	mov	w9, #0x4                // =4
    29fc:      	add	x10, sp, #0x20
    2a00:      	add	x0, sp, #0x20
    2a04:      	mov	w1, #0x8                // =8
    2a08:      	blr	x9
    2a0c:      	cbz	x0, 0x2de4 <generic_tracepoint_event+0x2de4>
    2a10:      	neg	w8, w0
    2a14:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2a18:      	mov	w9, #0x1                // =1
    2a1c:      	strh	w8, [sp, #0x38]
    2a20:      	mov	w8, #0x7                // =7
    2a24:      	add	x1, sp, #0x38
    2a28:      	mov	w22, #0x1               // =1
    2a2c:      	strh	w8, [sp, #0x3a]
    2a30:      	mov	x8, #0x9a               // =154
    2a34:      	movk	x8, #0x4, lsl #32
    2a38:      	stur	x8, [sp, #0x3c]
    2a3c:      	add	x8, sp, #0x38
    2a40:      	ldr	x21, [x21]
    2a44:      	mov	x0, x21
    2a48:      	blr	x9
    2a4c:      	cbnz	x0, 0x2c24 <generic_tracepoint_event+0x2c24>
    2a50:      	str	w22, [sp, #0x88]
    2a54:      	mov	x3, xzr
    2a58:      	mov	w8, #0x2                // =2
    2a5c:      	add	x9, sp, #0x38
    2a60:      	add	x10, sp, #0x88
    2a64:      	b	0x2dd4 <generic_tracepoint_event+0x2dd4>
    2a68:      	mov	x22, x2
    2a6c:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2a70:      	mov	w8, #0x8                // =8
    2a74:      	mov	w9, #0x4                // =4
    2a78:      	add	x10, sp, #0x20
    2a7c:      	add	x0, sp, #0x20
    2a80:      	mov	w1, #0x8                // =8
    2a84:      	blr	x9
    2a88:      	cbz	x0, 0x2de4 <generic_tracepoint_event+0x2de4>
    2a8c:      	neg	w8, w0
    2a90:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2a94:      	mov	w9, #0x1                // =1
    2a98:      	strh	w8, [sp, #0x38]
    2a9c:      	mov	w8, #0x7                // =7
    2aa0:      	add	x1, sp, #0x38
    2aa4:      	mov	w22, #0x1               // =1
    2aa8:      	strh	w8, [sp, #0x3a]
    2aac:      	mov	x8, #0x93               // =147
    2ab0:      	movk	x8, #0x4, lsl #32
    2ab4:      	stur	x8, [sp, #0x3c]
    2ab8:      	add	x8, sp, #0x38
    2abc:      	ldr	x21, [x21]
    2ac0:      	mov	x0, x21
    2ac4:      	blr	x9
    2ac8:      	cbnz	x0, 0x2c24 <generic_tracepoint_event+0x2c24>
    2acc:      	str	w22, [sp, #0x88]
    2ad0:      	mov	x3, xzr
    2ad4:      	mov	w8, #0x2                // =2
    2ad8:      	add	x9, sp, #0x38
    2adc:      	add	x10, sp, #0x88
    2ae0:      	b	0x2dd4 <generic_tracepoint_event+0x2dd4>
    2ae4:      	mov	w8, #0x1                // =1
    2ae8:      	mov	w9, #0x4                // =4
    2aec:      	add	x10, sp, #0x88
    2af0:      	add	x0, sp, #0x88
    2af4:      	mov	w1, #0x1                // =1
    2af8:      	blr	x9
    2afc:      	cbz	x0, 0x2d8c <generic_tracepoint_event+0x2d8c>
    2b00:      	neg	w8, w0
    2b04:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2b08:      	mov	w9, #0x1                // =1
    2b0c:      	strh	w8, [sp, #0x38]
    2b10:      	mov	w8, #0x7                // =7
    2b14:      	add	x1, sp, #0x38
    2b18:      	mov	w22, #0x1               // =1
    2b1c:      	strh	w8, [sp, #0x3a]
    2b20:      	mov	x8, #0x7a               // =122
    2b24:      	movk	x8, #0x4, lsl #32
    2b28:      	stur	x8, [sp, #0x3c]
    2b2c:      	add	x8, sp, #0x38
    2b30:      	ldr	x21, [x21]
    2b34:      	mov	x0, x21
    2b38:      	blr	x9
    2b3c:      	cbz	x0, 0x2d68 <generic_tracepoint_event+0x2d68>
    2b40:      	ldr	w8, [x0]
    2b44:      	add	w8, w8, #0x1
    2b48:      	str	w8, [x0]
    2b4c:      	ldrsb	x22, [sp, #0x88]
    2b50:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2b54:      	mov	w8, #0x8                // =8
    2b58:      	mov	w9, #0x4                // =4
    2b5c:      	add	x10, sp, #0x20
    2b60:      	add	x0, sp, #0x20
    2b64:      	mov	w1, #0x8                // =8
    2b68:      	blr	x9
    2b6c:      	cbz	x0, 0x2de4 <generic_tracepoint_event+0x2de4>
    2b70:      	neg	w8, w0
    2b74:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2b78:      	mov	w9, #0x1                // =1
    2b7c:      	strh	w8, [sp, #0x38]
    2b80:      	mov	w8, #0x7                // =7
    2b84:      	add	x1, sp, #0x38
    2b88:      	mov	w22, #0x1               // =1
    2b8c:      	strh	w8, [sp, #0x3a]
    2b90:      	mov	x8, #0xa1               // =161
    2b94:      	movk	x8, #0x4, lsl #32
    2b98:      	stur	x8, [sp, #0x3c]
    2b9c:      	add	x8, sp, #0x38
    2ba0:      	ldr	x21, [x21]
    2ba4:      	mov	x0, x21
    2ba8:      	blr	x9
    2bac:      	cbnz	x0, 0x2c24 <generic_tracepoint_event+0x2c24>
    2bb0:      	str	w22, [sp, #0x88]
    2bb4:      	mov	x3, xzr
    2bb8:      	mov	w8, #0x2                // =2
    2bbc:      	add	x9, sp, #0x38
    2bc0:      	add	x10, sp, #0x88
    2bc4:      	b	0x2dd4 <generic_tracepoint_event+0x2dd4>
    2bc8:      	mov	w8, #0x8                // =8
    2bcc:      	mov	w9, #0x4                // =4
    2bd0:      	add	x10, sp, #0x20
    2bd4:      	add	x0, sp, #0x20
    2bd8:      	mov	w1, #0x8                // =8
    2bdc:      	blr	x9
    2be0:      	cbz	x0, 0x2de4 <generic_tracepoint_event+0x2de4>
    2be4:      	neg	w8, w0
    2be8:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2bec:      	mov	w9, #0x1                // =1
    2bf0:      	strh	w8, [sp, #0x38]
    2bf4:      	mov	w8, #0x7                // =7
    2bf8:      	add	x1, sp, #0x38
    2bfc:      	mov	w22, #0x1               // =1
    2c00:      	strh	w8, [sp, #0x3a]
    2c04:      	mov	x8, #0x4e               // =78
    2c08:      	movk	x8, #0x4, lsl #32
    2c0c:      	stur	x8, [sp, #0x3c]
    2c10:      	add	x8, sp, #0x38
    2c14:      	ldr	x21, [x21]
    2c18:      	mov	x0, x21
    2c1c:      	blr	x9
    2c20:      	cbz	x0, 0x2dc0 <generic_tracepoint_event+0x2dc0>
    2c24:      	ldr	w8, [x0]
    2c28:      	add	w8, w8, #0x1
    2c2c:      	str	w8, [x0]
    2c30:      	b	0x2de4 <generic_tracepoint_event+0x2de4>
    2c34:      	mov	w8, #0x2                // =2
    2c38:      	mov	w9, #0x4                // =4
    2c3c:      	add	x10, sp, #0x88
    2c40:      	add	x0, sp, #0x88
    2c44:      	mov	w1, #0x2                // =2
    2c48:      	blr	x9
    2c4c:      	cbz	x0, 0x2e10 <generic_tracepoint_event+0x2e10>
    2c50:      	neg	w8, w0
    2c54:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2c58:      	mov	w9, #0x1                // =1
    2c5c:      	strh	w8, [sp, #0x38]
    2c60:      	mov	w8, #0x7                // =7
    2c64:      	add	x1, sp, #0x38
    2c68:      	mov	w22, #0x1               // =1
    2c6c:      	strh	w8, [sp, #0x3a]
    2c70:      	mov	x8, #0x65               // =101
    2c74:      	movk	x8, #0x4, lsl #32
    2c78:      	stur	x8, [sp, #0x3c]
    2c7c:      	add	x8, sp, #0x38
    2c80:      	ldr	x21, [x21]
    2c84:      	mov	x0, x21
    2c88:      	blr	x9
    2c8c:      	cbz	x0, 0x2dec <generic_tracepoint_event+0x2dec>
    2c90:      	ldr	w8, [x0]
    2c94:      	add	w8, w8, #0x1
    2c98:      	str	w8, [x0]
    2c9c:      	ldrh	w22, [sp, #0x88]
    2ca0:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2ca4:      	mov	w8, #0x4                // =4
    2ca8:      	add	x9, sp, #0x88
    2cac:      	add	x0, sp, #0x88
    2cb0:      	mov	w1, #0x4                // =4
    2cb4:      	blr	x8
    2cb8:      	cbz	x0, 0x2e3c <generic_tracepoint_event+0x2e3c>
    2cbc:      	neg	w8, w0
    2cc0:      	adrp	x21, 0x2000 <generic_tracepoint_event+0x2000>
    2cc4:      	mov	w9, #0x1                // =1
    2cc8:      	strh	w8, [sp, #0x38]
    2ccc:      	mov	w8, #0x7                // =7
    2cd0:      	add	x1, sp, #0x38
    2cd4:      	mov	w22, #0x1               // =1
    2cd8:      	strh	w8, [sp, #0x3a]
    2cdc:      	mov	x8, #0x88               // =136
    2ce0:      	movk	x8, #0x4, lsl #32
    2ce4:      	stur	x8, [sp, #0x3c]
    2ce8:      	add	x8, sp, #0x38
    2cec:      	ldr	x21, [x21]
    2cf0:      	mov	x0, x21
    2cf4:      	blr	x9
    2cf8:      	cbz	x0, 0x2e18 <generic_tracepoint_event+0x2e18>
    2cfc:      	ldr	w8, [x0]
    2d00:      	add	w8, w8, #0x1
    2d04:      	str	w8, [x0]
    2d08:      	ldr	w22, [sp, #0x88]
    2d0c:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2d10:      	str	w22, [sp, #0x20]
    2d14:      	mov	x3, xzr
    2d18:      	mov	w8, #0x2                // =2
    2d1c:      	add	x9, sp, #0x38
    2d20:      	add	x10, sp, #0x20
    2d24:      	add	x1, sp, #0x38
    2d28:      	add	x2, sp, #0x20
    2d2c:      	mov	x0, x21
    2d30:      	blr	x8
    2d34:      	ldrsw	x22, [sp, #0x88]
    2d38:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2d3c:      	str	w22, [sp, #0x20]
    2d40:      	mov	x3, xzr
    2d44:      	mov	w8, #0x2                // =2
    2d48:      	add	x9, sp, #0x38
    2d4c:      	add	x10, sp, #0x20
    2d50:      	add	x1, sp, #0x38
    2d54:      	add	x2, sp, #0x20
    2d58:      	mov	x0, x21
    2d5c:      	blr	x8
    2d60:      	ldrsh	x22, [sp, #0x88]
    2d64:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2d68:      	str	w22, [sp, #0x20]
    2d6c:      	mov	x3, xzr
    2d70:      	mov	w8, #0x2                // =2
    2d74:      	add	x9, sp, #0x38
    2d78:      	add	x10, sp, #0x20
    2d7c:      	add	x1, sp, #0x38
    2d80:      	add	x2, sp, #0x20
    2d84:      	mov	x0, x21
    2d88:      	blr	x8
    2d8c:      	ldrsb	x22, [sp, #0x88]
    2d90:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2d94:      	str	w22, [sp, #0x20]
    2d98:      	mov	x3, xzr
    2d9c:      	mov	w8, #0x2                // =2
    2da0:      	add	x9, sp, #0x38
    2da4:      	add	x10, sp, #0x20
    2da8:      	add	x1, sp, #0x38
    2dac:      	add	x2, sp, #0x20
    2db0:      	mov	x0, x21
    2db4:      	blr	x8
    2db8:      	ldrb	w22, [sp, #0x88]
    2dbc:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2dc0:      	str	w22, [sp, #0x88]
    2dc4:      	mov	x3, xzr
    2dc8:      	mov	w8, #0x2                // =2
    2dcc:      	add	x9, sp, #0x38
    2dd0:      	add	x10, sp, #0x88
    2dd4:      	add	x1, sp, #0x38
    2dd8:      	add	x2, sp, #0x88
    2ddc:      	mov	x0, x21
    2de0:      	blr	x8
    2de4:      	ldr	x22, [sp, #0x20]
    2de8:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2dec:      	str	w22, [sp, #0x20]
    2df0:      	mov	x3, xzr
    2df4:      	mov	w8, #0x2                // =2
    2df8:      	add	x9, sp, #0x38
    2dfc:      	add	x10, sp, #0x20
    2e00:      	add	x1, sp, #0x38
    2e04:      	add	x2, sp, #0x20
    2e08:      	mov	x0, x21
    2e0c:      	blr	x8
    2e10:      	ldrh	w22, [sp, #0x88]
    2e14:      	b	0x2e40 <generic_tracepoint_event+0x2e40>
    2e18:      	str	w22, [sp, #0x20]
    2e1c:      	mov	x3, xzr
    2e20:      	mov	w8, #0x2                // =2
    2e24:      	add	x9, sp, #0x38
    2e28:      	add	x10, sp, #0x20
    2e2c:      	add	x1, sp, #0x38
    2e30:      	add	x2, sp, #0x20
    2e34:      	mov	x0, x21
    2e38:      	blr	x8
    2e3c:      	ldr	w22, [sp, #0x88]
    2e40:      	mov	w21, #0xe               // =14
    2e44:      	str	x22, [x20, #0x5e70]
    2e48:      	strh	wzr, [x20, #0x2]
    2e4c:      	mov	w8, #0x7d               // =125
    2e50:      	str	wzr, [x20, #0x4]
    2e54:      	strb	w21, [x20]
    2e58:      	blr	x8
    2e5c:      	str	x0, [x20, #0x8]
    2e60:      	str	xzr, [x20, #0x70]
    2e64:      	mov	w8, #0xe                // =14
    2e68:      	str	wzr, [x20, #0x14]
    2e6c:      	blr	x8
    2e70:      	mov	w8, #0x5eb8             // =24248
    2e74:      	add	x9, x23, #0xefc
    2e78:      	str	w0, [x20, #0x7c]
    2e7c:      	strb	w21, [x20]
    2e80:      	add	x8, x20, x8
    2e84:      	str	xzr, [x9]
    2e88:      	str	xzr, [x20, #0x5eb8]
    2e8c:      	mov	w9, #0x23               // =35
    2e90:      	str	xzr, [x20, #0x5ec0]
    2e94:      	str	xzr, [x20, #0x5ec8]
    2e98:      	str	xzr, [x20, #0x5ed0]
    2e9c:      	str	xzr, [x20, #0x5ed8]
    2ea0:      	strb	wzr, [x8, #0x28]
    2ea4:      	blr	x9
    2ea8:      	add	x2, x0, #0xb50
    2eac:      	mov	w24, #0x8               // =8
    2eb0:      	add	x8, sp, #0x88
    2eb4:      	mov	w9, #0x4                // =4
    2eb8:      	mov	x21, x0
    2ebc:      	add	x0, sp, #0x88
    2ec0:      	mov	w1, #0x8                // =8
    2ec4:      	add	x22, x20, #0x20
    2ec8:      	mov	w23, #0x4               // =4
    2ecc:      	blr	x9
    2ed0:      	ldr	x8, [sp, #0x88]
    2ed4:      	mov	w9, #0x48               // =72
    2ed8:      	add	x10, sp, #0x38
    2edc:      	mov	w11, #0x4               // =4
    2ee0:      	ldr	x2, [sp, #0x88]
    2ee4:      	add	x0, sp, #0x38
    2ee8:      	mov	w1, #0x48               // =72
    2eec:      	blr	x11
    2ef0:      	ldr	x8, [sp, #0x40]
    2ef4:      	mov	w9, #0x4                // =4
    2ef8:      	mov	x0, x22
    2efc:      	mov	w1, #0x4                // =4
    2f00:      	add	x8, x8, #0x218
    2f04:      	ldr	x8, [sp, #0x40]
    2f08:      	add	x2, x8, #0x218
    2f0c:      	blr	x9
    2f10:      	ldr	x8, [sp, #0x48]
    2f14:      	add	x0, x20, #0x24
    2f18:      	mov	w9, #0x4                // =4
    2f1c:      	mov	w1, #0x4                // =4
    2f20:      	add	x8, x8, #0x4d8
    2f24:      	ldr	x8, [sp, #0x48]
    2f28:      	add	x2, x8, #0x4d8
    2f2c:      	blr	x9
    2f30:      	ldr	x8, [sp, #0x50]
    2f34:      	add	x0, x20, #0x28
    2f38:      	mov	w9, #0x4                // =4
    2f3c:      	mov	w1, #0x4                // =4
    2f40:      	add	x8, x8, #0x58
    2f44:      	ldr	x8, [sp, #0x50]
    2f48:      	add	x2, x8, #0x58
    2f4c:      	blr	x9
    2f50:      	str	xzr, [sp, #0x30]
    2f54:      	add	x2, x21, #0x938
    2f58:      	add	x8, sp, #0x30
    2f5c:      	add	x0, sp, #0x30
    2f60:      	mov	w1, #0x8                // =8
    2f64:      	blr	x23
    2f68:      	ldr	x8, [sp, #0x30]
    2f6c:      	cbz	x8, 0x2ff0 <generic_tracepoint_event+0x2ff0>
    2f70:      	str	wzr, [sp, #0x10]
    2f74:      	add	x8, x8, #0x4
    2f78:      	add	x9, sp, #0x10
    2f7c:      	mov	w10, #0x4               // =4
    2f80:      	add	x0, sp, #0x10
    2f84:      	mov	w1, #0x4                // =4
    2f88:      	mov	w22, #0x4               // =4
    2f8c:      	ldr	x8, [sp, #0x30]
    2f90:      	add	x2, x8, #0x4
    2f94:      	blr	x10
    2f98:      	ldr	x8, [sp, #0x30]
    2f9c:      	ldrsw	x9, [sp, #0x10]
    2fa0:      	add	x10, sp, #0x20
    2fa4:      	mov	w11, #0x4               // =4
    2fa8:      	add	x0, sp, #0x20
    2fac:      	mov	w1, #0x10               // =16
    2fb0:      	add	x8, x8, x9, lsl #4
    2fb4:      	mov	w9, #0x10               // =16
    2fb8:      	add	x8, x8, #0x80
    2fbc:      	ldr	x8, [sp, #0x30]
    2fc0:      	ldrsw	x9, [sp, #0x10]
    2fc4:      	add	x8, x8, x9, lsl #4
    2fc8:      	add	x2, x8, #0x80
    2fcc:      	blr	x11
    2fd0:      	ldr	x8, [sp, #0x28]
    2fd4:      	add	x0, x20, #0x2c
    2fd8:      	mov	w1, #0x4                // =4
    2fdc:      	add	x8, x8, #0x158
    2fe0:      	ldr	x8, [sp, #0x28]
    2fe4:      	add	x2, x8, #0x158
    2fe8:      	blr	x22
    2fec:      	b	0x2ff4 <generic_tracepoint_event+0x2ff4>
    2ff0:      	str	wzr, [x20, #0x2c]
    2ff4:      	ldr	x8, [sp, #0x58]
    2ff8:      	add	x0, x20, #0x30
    2ffc:      	mov	w9, #0x4                // =4
    3000:      	mov	w1, #0x4                // =4
    3004:      	mov	w23, #0x4               // =4
    3008:      	add	x8, x8, #0x158
    300c:      	ldr	x8, [sp, #0x58]
    3010:      	add	x2, x8, #0x158
    3014:      	blr	x9
    3018:      	ldr	x8, [sp, #0x60]
    301c:      	add	x0, x20, #0x34
    3020:      	mov	w9, #0x4                // =4
    3024:      	mov	w1, #0x4                // =4
    3028:      	add	x8, x8, #0x118
    302c:      	ldr	x8, [sp, #0x60]
    3030:      	add	x2, x8, #0x118
    3034:      	blr	x9
    3038:      	ldr	x8, [sp, #0x68]
    303c:      	add	x0, x20, #0x38
    3040:      	mov	w9, #0x4                // =4
    3044:      	mov	w1, #0x4                // =4
    3048:      	add	x8, x8, #0x98
    304c:      	ldr	x8, [sp, #0x68]
    3050:      	add	x2, x8, #0x98
    3054:      	blr	x9
    3058:      	ldr	x8, [sp, #0x70]
    305c:      	add	x0, x20, #0x3c
    3060:      	mov	w9, #0x4                // =4
    3064:      	mov	w1, #0x4                // =4
    3068:      	add	x8, x8, #0x98
    306c:      	ldr	x8, [sp, #0x70]
    3070:      	add	x2, x8, #0x98
    3074:      	blr	x9
    3078:      	ldr	x8, [sp, #0x78]
    307c:      	add	x0, x20, #0x40
    3080:      	mov	w9, #0x4                // =4
    3084:      	mov	w1, #0x4                // =4
    3088:      	add	x8, x8, #0x58
    308c:      	ldr	x8, [sp, #0x78]
    3090:      	add	x2, x8, #0x58
    3094:      	blr	x9
    3098:      	str	xzr, [sp, #0x20]
    309c:      	str	xzr, [sp, #0x30]
    30a0:      	add	x21, x21, #0xae0
    30a4:      	mov	w24, #0x8               // =8
    30a8:      	add	x8, sp, #0x20
    30ac:      	mov	w9, #0x4                // =4
    30b0:      	add	x0, sp, #0x20
    30b4:      	mov	w1, #0x8                // =8
    30b8:      	mov	x2, x21
    30bc:      	blr	x9
    30c0:      	ldr	x8, [sp, #0x20]
    30c4:      	add	x9, sp, #0x30
    30c8:      	mov	w10, #0x4               // =4
    30cc:      	add	x0, sp, #0x30
    30d0:      	mov	w1, #0x8                // =8
    30d4:      	add	x8, x8, #0x90
    30d8:      	ldr	x8, [sp, #0x20]
    30dc:      	add	x2, x8, #0x90
    30e0:      	blr	x10
    30e4:      	ldr	x8, [sp, #0x30]
    30e8:      	add	x0, x20, #0x44
    30ec:      	mov	w9, #0x4                // =4
    30f0:      	mov	w1, #0x4                // =4
    30f4:      	add	x8, x8, #0x158
    30f8:      	ldr	x8, [sp, #0x30]
    30fc:      	add	x2, x8, #0x158
    3100:      	blr	x9
    3104:      	add	x8, sp, #0x38
    3108:      	mov	w9, #0x4                // =4
    310c:      	add	x0, sp, #0x38
    3110:      	mov	w1, #0x8                // =8
    3114:      	mov	x2, x21
    3118:      	add	x22, x20, #0x48
    311c:      	blr	x9
    3120:      	ldr	x21, [sp, #0x38]
    3124:      	add	x0, x20, #0x50
    3128:      	mov	w8, #0x4                // =4
    312c:      	mov	w1, #0x8                // =8
    3130:      	add	x2, x21, #0x40
    3134:      	blr	x8
    3138:      	add	x0, x20, #0x58
    313c:      	add	x2, x21, #0x30
    3140:      	mov	w8, #0x4                // =4
    3144:      	mov	w1, #0x8                // =8
    3148:      	blr	x8
    314c:      	add	x2, x21, #0x38
    3150:      	mov	x0, x22
    3154:      	mov	w1, #0x8                // =8
    3158:      	blr	x23
    315c:      	strb	wzr, [x20, #0x1]
    3160:      	str	xzr, [x20, #0x5ee8]
    3164:      	adrp	x1, 0x3000 <generic_tracepoint_event+0x3000>
    3168:      	mov	w8, #0x2                // =2
    316c:      	mov	w9, #0xc                // =12
    3170:      	mov	x0, x19
    3174:      	str	xzr, [x20, #0x5ef0]
    3178:      	ldr	x1, [x1]
    317c:      	mov	w2, #0x2                // =2
    3180:      	blr	x9
    3184:      	ldp	x20, x19, [sp, #0xc0]
    3188:      	mov	w0, wzr
    318c:      	ldp	x22, x21, [sp, #0xb0]
    3190:      	ldp	x24, x23, [sp, #0xa0]
    3194:      	ldp	x30, x25, [sp, #0x90]
    3198:      	add	sp, sp, #0xd0
    319c:      	ret
