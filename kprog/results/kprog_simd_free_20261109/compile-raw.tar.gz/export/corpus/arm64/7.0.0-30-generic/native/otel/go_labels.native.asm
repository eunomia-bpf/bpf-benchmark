
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/otel/go_labels.native.o:	file format elf64-littleaarch64

Disassembly of section perf_event/go_labels:

0000000000000000 <perf_go_labels>:
       0:      	sub	sp, sp, #0x100
       4:      	str	x29, [sp, #0xb0]
       8:      	stp	x30, x25, [sp, #0xc0]
       c:      	stp	x24, x23, [sp, #0xd0]
      10:      	stp	x22, x21, [sp, #0xe0]
      14:      	stp	x20, x19, [sp, #0xf0]
      18:      	mov	x19, x0
      1c:      	str	wzr, [sp, #0x30]
      20:      	adrp	x0, 0x0 <perf_go_labels>
      24:      	mov	w8, #0x1                // =1
      28:      	ldr	x0, [x0]
      2c:      	add	x9, sp, #0x30
      30:      	add	x1, sp, #0x30
      34:      	blr	x8
      38:      	cbz	x0, 0xfc <perf_go_labels+0xfc>
      3c:      	ldr	w8, [x0]
      40:      	mov	x20, x0
      44:      	adrp	x0, 0x0 <perf_go_labels>
      48:      	add	x9, sp, #0x74
      4c:      	str	w8, [sp, #0x74]
      50:      	mov	w8, #0x1                // =1
      54:      	add	x1, sp, #0x74
      58:      	ldr	x0, [x0]
      5c:      	blr	x8
      60:      	adrp	x24, 0x0 <perf_go_labels>
      64:      	ldr	x24, [x24]
      68:      	ldr	w8, [x24]
      6c:      	cbz	x0, 0xf8 <perf_go_labels+0xf8>
      70:      	mov	x21, x0
      74:      	cbnz	w8, 0x74c <perf_go_labels+0x74c>
      78:      	ldr	x8, [x20, #0xf68]
      7c:      	ldr	w9, [x21, #0x4]
      80:      	mov	w10, #0x70              // =112
      84:      	add	x11, sp, #0x80
      88:      	add	x0, sp, #0x80
      8c:      	mov	w1, #0x8                // =8
      90:      	add	x8, x8, x9
      94:      	mov	w9, #0x8                // =8
      98:      	ldr	x8, [x20, #0xf68]
      9c:      	ldr	w9, [x21, #0x4]
      a0:      	add	x2, x8, x9
      a4:      	blr	x10
      a8:      	cbz	x0, 0x104 <perf_go_labels+0x104>
      ac:      	ldr	w8, [x24]
      b0:      	cbz	w8, 0x140 <perf_go_labels+0x140>
      b4:      	mov	w8, #0xa                // =10
      b8:      	add	x0, sp, #0x30
      bc:      	mov	w1, #0x2a               // =42
      c0:      	strh	w8, [sp, #0x58]
      c4:      	adrp	x8, 0x0 <perf_go_labels>
      c8:      	add	x8, x8, #0x0
      cc:      	ldp	x9, x10, [x8, #0x10]
      d0:      	stp	x9, x10, [sp, #0x40]
      d4:      	ldr	x9, [x8, #0x20]
      d8:      	add	x10, sp, #0x30
      dc:      	str	x9, [sp, #0x50]
      e0:      	ldp	x8, x9, [x8]
      e4:      	stp	x8, x9, [sp, #0x30]
      e8:      	mov	w8, #0x2a               // =42
      ec:      	mov	w9, #0x6                // =6
      f0:      	blr	x9
      f4:      	b	0x140 <perf_go_labels+0x140>
      f8:      	cbnz	w8, 0x798 <perf_go_labels+0x798>
      fc:      	mov	w0, #-0x1               // =-1
     100:      	b	0x1c0 <perf_go_labels+0x1c0>
     104:      	ldr	x8, [sp, #0x80]
     108:      	ldr	w9, [x21, #0x8]
     10c:      	mov	w10, #0x70              // =112
     110:      	add	x11, sp, #0x78
     114:      	add	x0, sp, #0x78
     118:      	mov	w1, #0x8                // =8
     11c:      	add	x8, x8, x9
     120:      	mov	w9, #0x8                // =8
     124:      	ldr	x8, [sp, #0x80]
     128:      	ldr	w9, [x21, #0x8]
     12c:      	add	x2, x8, x9
     130:      	blr	x10
     134:      	cbz	x0, 0x1dc <perf_go_labels+0x1dc>
     138:      	ldr	w8, [x24]
     13c:      	cbnz	w8, 0x8bc <perf_go_labels+0x8bc>
     140:      	mov	w8, #0x61               // =97
     144:      	adrp	x0, 0x0 <perf_go_labels>
     148:      	add	x9, sp, #0x88
     14c:      	str	w8, [sp, #0x88]
     150:      	mov	w8, #0x1                // =1
     154:      	add	x1, sp, #0x88
     158:      	ldr	x0, [x0]
     15c:      	blr	x8
     160:      	cbz	x0, 0x174 <perf_go_labels+0x174>
     164:      	ldr	x8, [x0]
     168:      	add	x8, x8, #0x1
     16c:      	str	x8, [x0]
     170:      	b	0x17c <perf_go_labels+0x17c>
     174:      	ldr	w8, [x24]
     178:      	cbnz	w8, 0x874 <perf_go_labels+0x874>
     17c:      	ldr	w8, [x20, #0x2c0]
     180:      	mov	w9, #0x80               // =128
     184:      	mov	x10, #0xed0             // =3792
     188:      	sub	w8, w9, w8
     18c:      	mov	x9, #-0x18              // =-24
     190:      	madd	x4, x8, x9, x10
     194:      	cmp	x4, #0xed0
     198:      	b.hi	0x1bc <perf_go_labels+0x1bc>
     19c:      	adrp	x1, 0x0 <perf_go_labels>
     1a0:      	mov	w8, #-0x1               // =-1
     1a4:      	mov	w9, #0x19               // =25
     1a8:      	ldr	x1, [x1]
     1ac:      	mov	x0, x19
     1b0:      	mov	w2, #-0x1               // =-1
     1b4:      	mov	x3, x20
     1b8:      	blr	x9
     1bc:      	mov	w0, wzr
     1c0:      	ldp	x20, x19, [sp, #0xf0]
     1c4:      	ldr	x29, [sp, #0xb0]
     1c8:      	ldp	x22, x21, [sp, #0xe0]
     1cc:      	ldp	x24, x23, [sp, #0xd0]
     1d0:      	ldp	x30, x25, [sp, #0xc0]
     1d4:      	add	sp, sp, #0x100
     1d8:      	ret
     1dc:      	ldr	w8, [x21, #0x14]
     1e0:      	ldr	x22, [sp, #0x78]
     1e4:      	cbz	w8, 0x254 <perf_go_labels+0x254>
     1e8:      	mov	w8, #0x8                // =8
     1ec:      	mov	w9, #0x70               // =112
     1f0:      	add	x10, sp, #0x88
     1f4:      	add	x0, sp, #0x88
     1f8:      	mov	w1, #0x8                // =8
     1fc:      	mov	x2, x22
     200:      	blr	x9
     204:      	cbz	x0, 0x2c0 <perf_go_labels+0x2c0>
     208:      	ldr	w8, [x24]
     20c:      	cbz	w8, 0x140 <perf_go_labels+0x140>
     210:      	mov	w8, #0x2978             // =10616
     214:      	add	x0, sp, #0x30
     218:      	mov	w1, #0x33               // =51
     21c:      	movk	w8, #0xa, lsl #16
     220:      	stur	w8, [sp, #0x5f]
     224:      	adrp	x8, 0x0 <perf_go_labels>
     228:      	add	x8, x8, #0x0
     22c:      	ldp	x9, x10, [x8, #0x10]
     230:      	stp	x9, x10, [sp, #0x40]
     234:      	ldp	x9, x10, [x8, #0x20]
     238:      	stp	x9, x10, [sp, #0x50]
     23c:      	ldp	x9, x8, [x8]
     240:      	add	x10, sp, #0x30
     244:      	stp	x9, x8, [sp, #0x30]
     248:      	mov	w8, #0x33               // =51
     24c:      	mov	w9, #0x6                // =6
     250:      	b	0x2b4 <perf_go_labels+0x2b4>
     254:      	mov	w8, #0x18               // =24
     258:      	mov	w9, #0x70               // =112
     25c:      	add	x10, sp, #0x88
     260:      	add	x0, sp, #0x88
     264:      	mov	w1, #0x18               // =24
     268:      	mov	x2, x22
     26c:      	blr	x9
     270:      	cbz	x0, 0x348 <perf_go_labels+0x348>
     274:      	ldr	w8, [x24]
     278:      	cbz	w8, 0x140 <perf_go_labels+0x140>
     27c:      	adrp	x8, 0x0 <perf_go_labels>
     280:      	add	x8, x8, #0x0
     284:      	strb	wzr, [sp, #0x60]
     288:      	add	x0, sp, #0x30
     28c:      	ldp	x9, x10, [x8, #0x10]
     290:      	mov	w1, #0x31               // =49
     294:      	stp	x9, x10, [sp, #0x40]
     298:      	ldp	x9, x10, [x8, #0x20]
     29c:      	stp	x9, x10, [sp, #0x50]
     2a0:      	ldp	x9, x8, [x8]
     2a4:      	add	x10, sp, #0x30
     2a8:      	stp	x9, x8, [sp, #0x30]
     2ac:      	mov	w8, #0x31               // =49
     2b0:      	mov	w9, #0x6                // =6
     2b4:      	mov	x2, x22
     2b8:      	blr	x9
     2bc:      	b	0x140 <perf_go_labels+0x140>
     2c0:      	ldr	x8, [sp, #0x88]
     2c4:      	ldr	w9, [x21, #0xc]
     2c8:      	mov	w10, #0x70              // =112
     2cc:      	add	x11, sp, #0xb8
     2d0:      	add	x0, sp, #0xb8
     2d4:      	mov	w1, #0x8                // =8
     2d8:      	str	xzr, [sp, #0xb8]
     2dc:      	add	x8, x8, x9
     2e0:      	mov	w9, #0x8                // =8
     2e4:      	ldr	x8, [sp, #0x88]
     2e8:      	ldr	w9, [x21, #0xc]
     2ec:      	add	x2, x8, x9
     2f0:      	blr	x10
     2f4:      	cbz	x0, 0x3c0 <perf_go_labels+0x3c0>
     2f8:      	ldr	w8, [x24]
     2fc:      	cbz	w8, 0x140 <perf_go_labels+0x140>
     300:      	mov	w8, #0x746e             // =29806
     304:      	movk	w8, #0xa, lsl #16
     308:      	stur	w8, [sp, #0x57]
     30c:      	adrp	x8, 0x0 <perf_go_labels>
     310:      	add	x8, x8, #0x0
     314:      	ldp	x9, x10, [x8, #0x10]
     318:      	stp	x9, x10, [sp, #0x40]
     31c:      	ldr	x9, [x8, #0x20]
     320:      	add	x10, sp, #0x30
     324:      	str	x9, [sp, #0x50]
     328:      	ldp	x8, x9, [x8]
     32c:      	stp	x8, x9, [sp, #0x30]
     330:      	mov	w8, #0x2b               // =43
     334:      	mov	w9, #0x6                // =6
     338:      	add	x0, sp, #0x30
     33c:      	mov	w1, #0x2b               // =43
     340:      	blr	x9
     344:      	b	0x140 <perf_go_labels+0x140>
     348:      	ldp	x9, x8, [sp, #0x88]
     34c:      	mov	w10, #0xa               // =10
     350:      	add	x0, x20, #0xf70
     354:      	cmp	x8, #0xa
     358:      	csel	x21, x8, x10, lo
     35c:      	mov	w8, #0x70               // =112
     360:      	lsl	x1, x21, #5
     364:      	ldr	x2, [sp, #0x88]
     368:      	blr	x8
     36c:      	cbz	x0, 0x440 <perf_go_labels+0x440>
     370:      	ldr	w8, [x24]
     374:      	cbz	w8, 0x140 <perf_go_labels+0x140>
     378:      	mov	w8, #0x2978             // =10616
     37c:      	add	x0, sp, #0x30
     380:      	mov	w1, #0x34               // =52
     384:      	movk	w8, #0xa, lsl #16
     388:      	str	w8, [sp, #0x60]
     38c:      	adrp	x8, 0x0 <perf_go_labels>
     390:      	add	x8, x8, #0x0
     394:      	ldp	x9, x10, [x8, #0x10]
     398:      	stp	x9, x10, [sp, #0x40]
     39c:      	ldp	x9, x10, [x8, #0x20]
     3a0:      	stp	x9, x10, [sp, #0x50]
     3a4:      	ldp	x9, x8, [x8]
     3a8:      	add	x10, sp, #0x30
     3ac:      	stp	x9, x8, [sp, #0x30]
     3b0:      	mov	w8, #0x34               // =52
     3b4:      	mov	w9, #0x6                // =6
     3b8:      	ldr	x2, [sp, #0x88]
     3bc:      	b	0x2b8 <perf_go_labels+0x2b8>
     3c0:      	ldr	x8, [sp, #0xb8]
     3c4:      	cbz	x8, 0x4d4 <perf_go_labels+0x4d4>
     3c8:      	ldr	x8, [sp, #0x88]
     3cc:      	ldr	w9, [x21, #0x10]
     3d0:      	mov	w10, #0x70              // =112
     3d4:      	add	x11, sp, #0xac
     3d8:      	add	x0, sp, #0xac
     3dc:      	mov	w1, #0x1                // =1
     3e0:      	add	x8, x8, x9
     3e4:      	mov	w9, #0x1                // =1
     3e8:      	ldr	x8, [sp, #0x88]
     3ec:      	ldr	w9, [x21, #0x10]
     3f0:      	add	x2, x8, x9
     3f4:      	blr	x10
     3f8:      	cbz	x0, 0x510 <perf_go_labels+0x510>
     3fc:      	ldr	w8, [x24]
     400:      	cbz	w8, 0x140 <perf_go_labels+0x140>
     404:      	mov	w8, #0x746e             // =29806
     408:      	movk	w8, #0xa, lsl #16
     40c:      	stur	w8, [sp, #0x57]
     410:      	adrp	x8, 0x0 <perf_go_labels>
     414:      	add	x8, x8, #0x0
     418:      	ldp	x9, x10, [x8, #0x10]
     41c:      	stp	x9, x10, [sp, #0x40]
     420:      	ldr	x9, [x8, #0x20]
     424:      	add	x10, sp, #0x30
     428:      	str	x9, [sp, #0x50]
     42c:      	ldp	x8, x9, [x8]
     430:      	stp	x8, x9, [sp, #0x30]
     434:      	mov	w8, #0x2b               // =43
     438:      	mov	w9, #0x6                // =6
     43c:      	b	0x338 <perf_go_labels+0x338>
     440:      	str	x21, [sp, #0x28]
     444:      	mov	x21, xzr
     448:      	mov	x23, xzr
     44c:      	mov	x25, xzr
     450:      	ldr	x8, [sp, #0x90]
     454:      	cmp	x8, x25
     458:      	b.ls	0x4c8 <perf_go_labels+0x4c8>
     45c:      	add	x29, x20, x21
     460:      	add	x22, x20, x23
     464:      	mov	w9, #0xf                // =15
     468:      	ldr	x8, [x29, #0xf78]
     46c:      	add	x0, x22, #0x3c
     470:      	cmp	x8, #0xf
     474:      	csel	x1, x8, x9, lo
     478:      	ldr	x8, [x29, #0xf70]
     47c:      	mov	w9, #0x70               // =112
     480:      	ldr	x2, [x29, #0xf70]
     484:      	blr	x9
     488:      	cbnz	x0, 0x594 <perf_go_labels+0x594>
     48c:      	ldr	x8, [x29, #0xf88]
     490:      	mov	w9, #0x2f               // =47
     494:      	add	x0, x22, #0x4c
     498:      	cmp	x8, #0x2f
     49c:      	csel	x1, x8, x9, lo
     4a0:      	ldr	x8, [x29, #0xf80]
     4a4:      	mov	w9, #0x70               // =112
     4a8:      	ldr	x2, [x29, #0xf80]
     4ac:      	blr	x9
     4b0:      	cbnz	x0, 0x5dc <perf_go_labels+0x5dc>
     4b4:      	add	x23, x23, #0x40
     4b8:      	add	x25, x25, #0x1
     4bc:      	add	x21, x21, #0x20
     4c0:      	cmp	x23, #0x280
     4c4:      	b.ne	0x450 <perf_go_labels+0x450>
     4c8:      	ldr	x8, [sp, #0x28]
     4cc:      	str	w8, [x20, #0x38]
     4d0:      	b	0x17c <perf_go_labels+0x17c>
     4d4:      	ldr	w8, [x24]
     4d8:      	cbz	w8, 0x140 <perf_go_labels+0x140>
     4dc:      	adrp	x8, 0x0 <perf_go_labels>
     4e0:      	add	x8, x8, #0x0
     4e4:      	add	x10, sp, #0x30
     4e8:      	ldr	x9, [x8]
     4ec:      	ldur	x8, [x8, #0x7]
     4f0:      	add	x0, sp, #0x30
     4f4:      	mov	w1, #0xf                // =15
     4f8:      	str	x9, [sp, #0x30]
     4fc:      	stur	x8, [sp, #0x37]
     500:      	mov	w8, #0xf                // =15
     504:      	mov	w9, #0x6                // =6
     508:      	blr	x9
     50c:      	b	0x140 <perf_go_labels+0x140>
     510:      	ldr	x8, [sp, #0x88]
     514:      	ldr	w9, [x21, #0x14]
     518:      	mov	w10, #0x70              // =112
     51c:      	add	x11, sp, #0xa0
     520:      	add	x0, sp, #0xa0
     524:      	mov	w1, #0x8                // =8
     528:      	add	x8, x8, x9
     52c:      	mov	w9, #0x8                // =8
     530:      	ldr	x8, [sp, #0x88]
     534:      	ldr	w9, [x21, #0x14]
     538:      	add	x2, x8, x9
     53c:      	blr	x10
     540:      	cbz	x0, 0x630 <perf_go_labels+0x630>
     544:      	ldr	w8, [x24]
     548:      	cbz	w8, 0x140 <perf_go_labels+0x140>
     54c:      	mov	w8, #0x7374             // =29556
     550:      	add	x0, sp, #0x30
     554:      	mov	w1, #0x2c               // =44
     558:      	movk	w8, #0xa, lsl #16
     55c:      	str	w8, [sp, #0x58]
     560:      	adrp	x8, 0x0 <perf_go_labels>
     564:      	add	x8, x8, #0x0
     568:      	ldp	x9, x10, [x8, #0x10]
     56c:      	stp	x9, x10, [sp, #0x40]
     570:      	ldr	x9, [x8, #0x20]
     574:      	add	x10, sp, #0x30
     578:      	str	x9, [sp, #0x50]
     57c:      	ldp	x8, x9, [x8]
     580:      	stp	x8, x9, [sp, #0x30]
     584:      	mov	w8, #0x2c               // =44
     588:      	mov	w9, #0x6                // =6
     58c:      	blr	x9
     590:      	b	0x140 <perf_go_labels+0x140>
     594:      	ldr	w8, [x24]
     598:      	cbz	w8, 0x140 <perf_go_labels+0x140>
     59c:      	adrp	x8, 0x0 <perf_go_labels>
     5a0:      	add	x8, x8, #0x0
     5a4:      	add	x11, sp, #0x30
     5a8:      	ldp	x9, x10, [x8, #0x10]
     5ac:      	stp	x9, x10, [sp, #0x40]
     5b0:      	ldr	x9, [x8, #0x20]
     5b4:      	mov	w10, #0x6               // =6
     5b8:      	str	x9, [sp, #0x50]
     5bc:      	ldur	x9, [x8, #0x27]
     5c0:      	stur	x9, [sp, #0x57]
     5c4:      	ldp	x9, x8, [x8]
     5c8:      	stp	x9, x8, [sp, #0x30]
     5cc:      	add	x9, x20, x21
     5d0:      	mov	w8, #0x2f               // =47
     5d4:      	ldr	x2, [x9, #0xf70]
     5d8:      	b	0x620 <perf_go_labels+0x620>
     5dc:      	ldr	w8, [x24]
     5e0:      	cbz	w8, 0x140 <perf_go_labels+0x140>
     5e4:      	adrp	x8, 0x0 <perf_go_labels>
     5e8:      	add	x8, x8, #0x0
     5ec:      	add	x11, sp, #0x30
     5f0:      	ldp	x9, x10, [x8, #0x10]
     5f4:      	stp	x9, x10, [sp, #0x40]
     5f8:      	ldr	x9, [x8, #0x20]
     5fc:      	mov	w10, #0x6               // =6
     600:      	str	x9, [sp, #0x50]
     604:      	ldur	x9, [x8, #0x27]
     608:      	stur	x9, [sp, #0x57]
     60c:      	ldp	x9, x8, [x8]
     610:      	stp	x9, x8, [sp, #0x30]
     614:      	add	x9, x20, x21
     618:      	mov	w8, #0x2f               // =47
     61c:      	ldr	x2, [x9, #0xf80]
     620:      	add	x0, sp, #0x30
     624:      	mov	w1, #0x2f               // =47
     628:      	blr	x10
     62c:      	b	0x140 <perf_go_labels+0x140>
     630:      	ldrb	w8, [sp, #0xac]
     634:      	mov	w9, #0x1                // =1
     638:      	mov	x10, xzr
     63c:      	add	x0, x20, #0xf70
     640:      	add	x22, x20, #0x1, lsl #12 // =0x1000
     644:      	str	x22, [sp, #0x20]
     648:      	mov	w11, #0x110             // =272
     64c:      	lsl	x8, x9, x8
     650:      	and	x8, x8, #0xff
     654:      	stp	x0, x8, [sp, #0x8]
     658:      	cmp	x10, x8
     65c:      	b.eq	0x17c <perf_go_labels+0x17c>
     660:      	ldr	x8, [sp, #0xa0]
     664:      	str	x10, [sp, #0x18]
     668:      	add	x9, x10, x10, lsl #4
     66c:      	mov	w10, #0x70              // =112
     670:      	mov	w1, #0x110              // =272
     674:      	add	x8, x8, x9, lsl #4
     678:      	ldr	x8, [sp, #0xa0]
     67c:      	add	x2, x8, x9, lsl #4
     680:      	blr	x10
     684:      	cbnz	x0, 0x140 <perf_go_labels+0x140>
     688:      	ldr	w8, [x20, #0x38]
     68c:      	mov	x21, xzr
     690:      	mov	x29, x22
     694:      	b	0x6a8 <perf_go_labels+0x6a8>
     698:      	add	x21, x21, #0x1
     69c:      	add	x29, x29, #0x10
     6a0:      	cmp	x21, #0x8
     6a4:      	b.eq	0x730 <perf_go_labels+0x730>
     6a8:      	cmp	w8, #0xa
     6ac:      	b.hs	0x17c <perf_go_labels+0x17c>
     6b0:      	add	x9, x22, x21
     6b4:      	ldurb	w9, [x9, #-0x90]
     6b8:      	cbz	w9, 0x698 <perf_go_labels+0x698>
     6bc:      	ldur	x23, [x29, #-0x88]
     6c0:      	cbz	x23, 0x698 <perf_go_labels+0x698>
     6c4:      	mov	w8, w8
     6c8:      	ldur	x9, [x29, #-0x8]
     6cc:      	ldr	w25, [x29]
     6d0:      	mov	x2, x23
     6d4:      	add	x22, x20, x8, lsl #6
     6d8:      	ldur	w8, [x29, #-0x80]
     6dc:      	add	x0, x22, #0x3c
     6e0:      	cmp	w8, #0xf
     6e4:      	str	x9, [sp, #0x28]
     6e8:      	mov	w9, #0xf                // =15
     6ec:      	csel	w1, w8, w9, lo
     6f0:      	mov	w8, #0x70               // =112
     6f4:      	blr	x8
     6f8:      	cbnz	x0, 0x7e4 <perf_go_labels+0x7e4>
     6fc:      	cmp	w25, #0x2f
     700:      	mov	w8, #0x2f               // =47
     704:      	ldr	x2, [sp, #0x28]
     708:      	add	x0, x22, #0x4c
     70c:      	csel	w1, w25, w8, lo
     710:      	mov	w8, #0x70               // =112
     714:      	blr	x8
     718:      	cbnz	x0, 0x830 <perf_go_labels+0x830>
     71c:      	ldr	w8, [x20, #0x38]
     720:      	ldr	x22, [sp, #0x20]
     724:      	add	w8, w8, #0x1
     728:      	str	w8, [x20, #0x38]
     72c:      	b	0x698 <perf_go_labels+0x698>
     730:      	ldp	x8, x10, [sp, #0x10]
     734:      	mov	w11, #0x110             // =272
     738:      	add	x10, x10, #0x1
     73c:      	ldr	x0, [sp, #0x8]
     740:      	cmp	x10, #0x10
     744:      	b.ne	0x658 <perf_go_labels+0x658>
     748:      	b	0x17c <perf_go_labels+0x17c>
     74c:      	adrp	x8, 0x0 <perf_go_labels>
     750:      	add	x8, x8, #0x0
     754:      	add	x0, sp, #0x30
     758:      	ldp	x9, x10, [x8, #0x20]
     75c:      	mov	w1, #0x40               // =64
     760:      	stp	x9, x10, [sp, #0x50]
     764:      	ldp	x9, x10, [x8, #0x30]
     768:      	stp	x9, x10, [sp, #0x60]
     76c:      	ldp	x9, x10, [x8]
     770:      	stp	x9, x10, [sp, #0x30]
     774:      	ldp	x9, x8, [x8, #0x10]
     778:      	add	x10, sp, #0x30
     77c:      	stp	x9, x8, [sp, #0x40]
     780:      	mov	w8, #0x40               // =64
     784:      	mov	w9, #0x6                // =6
     788:      	ldr	w2, [sp, #0x74]
     78c:      	ldr	x3, [x20, #0xf68]
     790:      	blr	x9
     794:      	b	0x78 <perf_go_labels+0x78>
     798:      	mov	w8, #0xa                // =10
     79c:      	add	x0, sp, #0x30
     7a0:      	mov	w1, #0x32               // =50
     7a4:      	strh	w8, [sp, #0x60]
     7a8:      	adrp	x8, 0x0 <perf_go_labels>
     7ac:      	add	x8, x8, #0x0
     7b0:      	ldp	x9, x10, [x8, #0x10]
     7b4:      	stp	x9, x10, [sp, #0x40]
     7b8:      	ldp	x9, x10, [x8, #0x20]
     7bc:      	stp	x9, x10, [sp, #0x50]
     7c0:      	ldp	x9, x8, [x8]
     7c4:      	add	x10, sp, #0x30
     7c8:      	stp	x9, x8, [sp, #0x30]
     7cc:      	mov	w8, #0x32               // =50
     7d0:      	mov	w9, #0x6                // =6
     7d4:      	ldr	w2, [sp, #0x74]
     7d8:      	blr	x9
     7dc:      	mov	w0, #-0x1               // =-1
     7e0:      	b	0x1c0 <perf_go_labels+0x1c0>
     7e4:      	ldr	w8, [x24]
     7e8:      	cbz	w8, 0x140 <perf_go_labels+0x140>
     7ec:      	adrp	x8, 0x0 <perf_go_labels>
     7f0:      	add	x8, x8, #0x0
     7f4:      	add	x0, sp, #0x30
     7f8:      	ldp	x9, x10, [x8, #0x10]
     7fc:      	mov	w1, #0x2f               // =47
     800:      	mov	x2, x23
     804:      	stp	x9, x10, [sp, #0x40]
     808:      	ldr	x9, [x8, #0x20]
     80c:      	add	x10, sp, #0x30
     810:      	str	x9, [sp, #0x50]
     814:      	ldur	x9, [x8, #0x27]
     818:      	stur	x9, [sp, #0x57]
     81c:      	ldp	x9, x8, [x8]
     820:      	stp	x9, x8, [sp, #0x30]
     824:      	mov	w8, #0x2f               // =47
     828:      	mov	w9, #0x6                // =6
     82c:      	b	0x2b8 <perf_go_labels+0x2b8>
     830:      	ldr	w8, [x24]
     834:      	cbz	w8, 0x140 <perf_go_labels+0x140>
     838:      	mov	w8, #0x6c65             // =27749
     83c:      	movk	w8, #0xa, lsl #16
     840:      	stur	w8, [sp, #0x57]
     844:      	adrp	x8, 0x0 <perf_go_labels>
     848:      	add	x8, x8, #0x0
     84c:      	ldp	x9, x10, [x8, #0x10]
     850:      	stp	x9, x10, [sp, #0x40]
     854:      	ldr	x9, [x8, #0x20]
     858:      	add	x10, sp, #0x30
     85c:      	str	x9, [sp, #0x50]
     860:      	ldp	x8, x9, [x8]
     864:      	stp	x8, x9, [sp, #0x30]
     868:      	mov	w8, #0x2b               // =43
     86c:      	mov	w9, #0x6                // =6
     870:      	b	0x338 <perf_go_labels+0x338>
     874:      	adrp	x8, 0x0 <perf_go_labels>
     878:      	add	x8, x8, #0x0
     87c:      	add	x0, sp, #0x30
     880:      	ldp	x9, x10, [x8, #0x10]
     884:      	mov	w1, #0x2e               // =46
     888:      	stp	x9, x10, [sp, #0x40]
     88c:      	ldr	x9, [x8, #0x20]
     890:      	add	x10, sp, #0x30
     894:      	str	x9, [sp, #0x50]
     898:      	ldur	x9, [x8, #0x26]
     89c:      	stur	x9, [sp, #0x56]
     8a0:      	ldp	x9, x8, [x8]
     8a4:      	stp	x9, x8, [sp, #0x30]
     8a8:      	mov	w8, #0x2e               // =46
     8ac:      	mov	w9, #0x6                // =6
     8b0:      	ldr	w2, [sp, #0x88]
     8b4:      	blr	x9
     8b8:      	b	0x17c <perf_go_labels+0x17c>
     8bc:      	adrp	x8, 0x0 <perf_go_labels>
     8c0:      	add	x8, x8, #0x0
     8c4:      	add	x0, sp, #0x30
     8c8:      	ldp	x9, x10, [x8, #0x20]
     8cc:      	mov	w1, #0x36               // =54
     8d0:      	stp	x9, x10, [sp, #0x50]
     8d4:      	ldur	x9, [x8, #0x2e]
     8d8:      	stur	x9, [sp, #0x5e]
     8dc:      	ldp	x9, x10, [x8]
     8e0:      	stp	x9, x10, [sp, #0x30]
     8e4:      	ldp	x8, x9, [x8, #0x10]
     8e8:      	add	x10, sp, #0x30
     8ec:      	stp	x8, x9, [sp, #0x40]
     8f0:      	mov	w8, #0x36               // =54
     8f4:      	mov	w9, #0x6                // =6
     8f8:      	ldr	x2, [sp, #0x80]
     8fc:      	ldr	w3, [x21, #0x8]
     900:      	blr	x9
     904:      	b	0x140 <perf_go_labels+0x140>

Disassembly of section kprobe/go_labels:

0000000000000000 <kprobe_go_labels>:
       0:      	sub	sp, sp, #0x100
       4:      	str	x29, [sp, #0xb0]
       8:      	stp	x30, x25, [sp, #0xc0]
       c:      	stp	x24, x23, [sp, #0xd0]
      10:      	stp	x22, x21, [sp, #0xe0]
      14:      	stp	x20, x19, [sp, #0xf0]
      18:      	mov	x19, x0
      1c:      	str	wzr, [sp, #0x30]
      20:      	adrp	x0, 0x0 <kprobe_go_labels>
      24:      	mov	w8, #0x1                // =1
      28:      	ldr	x0, [x0]
      2c:      	add	x9, sp, #0x30
      30:      	add	x1, sp, #0x30
      34:      	blr	x8
      38:      	cbz	x0, 0xfc <kprobe_go_labels+0xfc>
      3c:      	ldr	w8, [x0]
      40:      	mov	x20, x0
      44:      	adrp	x0, 0x0 <kprobe_go_labels>
      48:      	add	x9, sp, #0x74
      4c:      	str	w8, [sp, #0x74]
      50:      	mov	w8, #0x1                // =1
      54:      	add	x1, sp, #0x74
      58:      	ldr	x0, [x0]
      5c:      	blr	x8
      60:      	adrp	x24, 0x0 <kprobe_go_labels>
      64:      	ldr	x24, [x24]
      68:      	ldr	w8, [x24]
      6c:      	cbz	x0, 0xf8 <kprobe_go_labels+0xf8>
      70:      	mov	x21, x0
      74:      	cbnz	w8, 0x74c <kprobe_go_labels+0x74c>
      78:      	ldr	x8, [x20, #0xf68]
      7c:      	ldr	w9, [x21, #0x4]
      80:      	mov	w10, #0x70              // =112
      84:      	add	x11, sp, #0x80
      88:      	add	x0, sp, #0x80
      8c:      	mov	w1, #0x8                // =8
      90:      	add	x8, x8, x9
      94:      	mov	w9, #0x8                // =8
      98:      	ldr	x8, [x20, #0xf68]
      9c:      	ldr	w9, [x21, #0x4]
      a0:      	add	x2, x8, x9
      a4:      	blr	x10
      a8:      	cbz	x0, 0x104 <kprobe_go_labels+0x104>
      ac:      	ldr	w8, [x24]
      b0:      	cbz	w8, 0x140 <kprobe_go_labels+0x140>
      b4:      	mov	w8, #0xa                // =10
      b8:      	add	x0, sp, #0x30
      bc:      	mov	w1, #0x2a               // =42
      c0:      	strh	w8, [sp, #0x58]
      c4:      	adrp	x8, 0x0 <kprobe_go_labels>
      c8:      	add	x8, x8, #0x0
      cc:      	ldp	x9, x10, [x8, #0x10]
      d0:      	stp	x9, x10, [sp, #0x40]
      d4:      	ldr	x9, [x8, #0x20]
      d8:      	add	x10, sp, #0x30
      dc:      	str	x9, [sp, #0x50]
      e0:      	ldp	x8, x9, [x8]
      e4:      	stp	x8, x9, [sp, #0x30]
      e8:      	mov	w8, #0x2a               // =42
      ec:      	mov	w9, #0x6                // =6
      f0:      	blr	x9
      f4:      	b	0x140 <kprobe_go_labels+0x140>
      f8:      	cbnz	w8, 0x798 <kprobe_go_labels+0x798>
      fc:      	mov	w0, #-0x1               // =-1
     100:      	b	0x1c0 <kprobe_go_labels+0x1c0>
     104:      	ldr	x8, [sp, #0x80]
     108:      	ldr	w9, [x21, #0x8]
     10c:      	mov	w10, #0x70              // =112
     110:      	add	x11, sp, #0x78
     114:      	add	x0, sp, #0x78
     118:      	mov	w1, #0x8                // =8
     11c:      	add	x8, x8, x9
     120:      	mov	w9, #0x8                // =8
     124:      	ldr	x8, [sp, #0x80]
     128:      	ldr	w9, [x21, #0x8]
     12c:      	add	x2, x8, x9
     130:      	blr	x10
     134:      	cbz	x0, 0x1dc <kprobe_go_labels+0x1dc>
     138:      	ldr	w8, [x24]
     13c:      	cbnz	w8, 0x8bc <kprobe_go_labels+0x8bc>
     140:      	mov	w8, #0x61               // =97
     144:      	adrp	x0, 0x0 <kprobe_go_labels>
     148:      	add	x9, sp, #0x88
     14c:      	str	w8, [sp, #0x88]
     150:      	mov	w8, #0x1                // =1
     154:      	add	x1, sp, #0x88
     158:      	ldr	x0, [x0]
     15c:      	blr	x8
     160:      	cbz	x0, 0x174 <kprobe_go_labels+0x174>
     164:      	ldr	x8, [x0]
     168:      	add	x8, x8, #0x1
     16c:      	str	x8, [x0]
     170:      	b	0x17c <kprobe_go_labels+0x17c>
     174:      	ldr	w8, [x24]
     178:      	cbnz	w8, 0x874 <kprobe_go_labels+0x874>
     17c:      	ldr	w8, [x20, #0x2c0]
     180:      	mov	w9, #0x80               // =128
     184:      	mov	x10, #0xed0             // =3792
     188:      	sub	w8, w9, w8
     18c:      	mov	x9, #-0x18              // =-24
     190:      	madd	x4, x8, x9, x10
     194:      	cmp	x4, #0xed0
     198:      	b.hi	0x1bc <kprobe_go_labels+0x1bc>
     19c:      	adrp	x1, 0x0 <kprobe_go_labels>
     1a0:      	mov	w8, #-0x1               // =-1
     1a4:      	mov	w9, #0x19               // =25
     1a8:      	ldr	x1, [x1]
     1ac:      	mov	x0, x19
     1b0:      	mov	w2, #-0x1               // =-1
     1b4:      	mov	x3, x20
     1b8:      	blr	x9
     1bc:      	mov	w0, wzr
     1c0:      	ldp	x20, x19, [sp, #0xf0]
     1c4:      	ldr	x29, [sp, #0xb0]
     1c8:      	ldp	x22, x21, [sp, #0xe0]
     1cc:      	ldp	x24, x23, [sp, #0xd0]
     1d0:      	ldp	x30, x25, [sp, #0xc0]
     1d4:      	add	sp, sp, #0x100
     1d8:      	ret
     1dc:      	ldr	w8, [x21, #0x14]
     1e0:      	ldr	x22, [sp, #0x78]
     1e4:      	cbz	w8, 0x254 <kprobe_go_labels+0x254>
     1e8:      	mov	w8, #0x8                // =8
     1ec:      	mov	w9, #0x70               // =112
     1f0:      	add	x10, sp, #0x88
     1f4:      	add	x0, sp, #0x88
     1f8:      	mov	w1, #0x8                // =8
     1fc:      	mov	x2, x22
     200:      	blr	x9
     204:      	cbz	x0, 0x2c0 <kprobe_go_labels+0x2c0>
     208:      	ldr	w8, [x24]
     20c:      	cbz	w8, 0x140 <kprobe_go_labels+0x140>
     210:      	mov	w8, #0x2978             // =10616
     214:      	add	x0, sp, #0x30
     218:      	mov	w1, #0x33               // =51
     21c:      	movk	w8, #0xa, lsl #16
     220:      	stur	w8, [sp, #0x5f]
     224:      	adrp	x8, 0x0 <kprobe_go_labels>
     228:      	add	x8, x8, #0x0
     22c:      	ldp	x9, x10, [x8, #0x10]
     230:      	stp	x9, x10, [sp, #0x40]
     234:      	ldp	x9, x10, [x8, #0x20]
     238:      	stp	x9, x10, [sp, #0x50]
     23c:      	ldp	x9, x8, [x8]
     240:      	add	x10, sp, #0x30
     244:      	stp	x9, x8, [sp, #0x30]
     248:      	mov	w8, #0x33               // =51
     24c:      	mov	w9, #0x6                // =6
     250:      	b	0x2b4 <kprobe_go_labels+0x2b4>
     254:      	mov	w8, #0x18               // =24
     258:      	mov	w9, #0x70               // =112
     25c:      	add	x10, sp, #0x88
     260:      	add	x0, sp, #0x88
     264:      	mov	w1, #0x18               // =24
     268:      	mov	x2, x22
     26c:      	blr	x9
     270:      	cbz	x0, 0x348 <kprobe_go_labels+0x348>
     274:      	ldr	w8, [x24]
     278:      	cbz	w8, 0x140 <kprobe_go_labels+0x140>
     27c:      	adrp	x8, 0x0 <kprobe_go_labels>
     280:      	add	x8, x8, #0x0
     284:      	strb	wzr, [sp, #0x60]
     288:      	add	x0, sp, #0x30
     28c:      	ldp	x9, x10, [x8, #0x10]
     290:      	mov	w1, #0x31               // =49
     294:      	stp	x9, x10, [sp, #0x40]
     298:      	ldp	x9, x10, [x8, #0x20]
     29c:      	stp	x9, x10, [sp, #0x50]
     2a0:      	ldp	x9, x8, [x8]
     2a4:      	add	x10, sp, #0x30
     2a8:      	stp	x9, x8, [sp, #0x30]
     2ac:      	mov	w8, #0x31               // =49
     2b0:      	mov	w9, #0x6                // =6
     2b4:      	mov	x2, x22
     2b8:      	blr	x9
     2bc:      	b	0x140 <kprobe_go_labels+0x140>
     2c0:      	ldr	x8, [sp, #0x88]
     2c4:      	ldr	w9, [x21, #0xc]
     2c8:      	mov	w10, #0x70              // =112
     2cc:      	add	x11, sp, #0xb8
     2d0:      	add	x0, sp, #0xb8
     2d4:      	mov	w1, #0x8                // =8
     2d8:      	str	xzr, [sp, #0xb8]
     2dc:      	add	x8, x8, x9
     2e0:      	mov	w9, #0x8                // =8
     2e4:      	ldr	x8, [sp, #0x88]
     2e8:      	ldr	w9, [x21, #0xc]
     2ec:      	add	x2, x8, x9
     2f0:      	blr	x10
     2f4:      	cbz	x0, 0x3c0 <kprobe_go_labels+0x3c0>
     2f8:      	ldr	w8, [x24]
     2fc:      	cbz	w8, 0x140 <kprobe_go_labels+0x140>
     300:      	mov	w8, #0x746e             // =29806
     304:      	movk	w8, #0xa, lsl #16
     308:      	stur	w8, [sp, #0x57]
     30c:      	adrp	x8, 0x0 <kprobe_go_labels>
     310:      	add	x8, x8, #0x0
     314:      	ldp	x9, x10, [x8, #0x10]
     318:      	stp	x9, x10, [sp, #0x40]
     31c:      	ldr	x9, [x8, #0x20]
     320:      	add	x10, sp, #0x30
     324:      	str	x9, [sp, #0x50]
     328:      	ldp	x8, x9, [x8]
     32c:      	stp	x8, x9, [sp, #0x30]
     330:      	mov	w8, #0x2b               // =43
     334:      	mov	w9, #0x6                // =6
     338:      	add	x0, sp, #0x30
     33c:      	mov	w1, #0x2b               // =43
     340:      	blr	x9
     344:      	b	0x140 <kprobe_go_labels+0x140>
     348:      	ldp	x9, x8, [sp, #0x88]
     34c:      	mov	w10, #0xa               // =10
     350:      	add	x0, x20, #0xf70
     354:      	cmp	x8, #0xa
     358:      	csel	x21, x8, x10, lo
     35c:      	mov	w8, #0x70               // =112
     360:      	lsl	x1, x21, #5
     364:      	ldr	x2, [sp, #0x88]
     368:      	blr	x8
     36c:      	cbz	x0, 0x440 <kprobe_go_labels+0x440>
     370:      	ldr	w8, [x24]
     374:      	cbz	w8, 0x140 <kprobe_go_labels+0x140>
     378:      	mov	w8, #0x2978             // =10616
     37c:      	add	x0, sp, #0x30
     380:      	mov	w1, #0x34               // =52
     384:      	movk	w8, #0xa, lsl #16
     388:      	str	w8, [sp, #0x60]
     38c:      	adrp	x8, 0x0 <kprobe_go_labels>
     390:      	add	x8, x8, #0x0
     394:      	ldp	x9, x10, [x8, #0x10]
     398:      	stp	x9, x10, [sp, #0x40]
     39c:      	ldp	x9, x10, [x8, #0x20]
     3a0:      	stp	x9, x10, [sp, #0x50]
     3a4:      	ldp	x9, x8, [x8]
     3a8:      	add	x10, sp, #0x30
     3ac:      	stp	x9, x8, [sp, #0x30]
     3b0:      	mov	w8, #0x34               // =52
     3b4:      	mov	w9, #0x6                // =6
     3b8:      	ldr	x2, [sp, #0x88]
     3bc:      	b	0x2b8 <kprobe_go_labels+0x2b8>
     3c0:      	ldr	x8, [sp, #0xb8]
     3c4:      	cbz	x8, 0x4d4 <kprobe_go_labels+0x4d4>
     3c8:      	ldr	x8, [sp, #0x88]
     3cc:      	ldr	w9, [x21, #0x10]
     3d0:      	mov	w10, #0x70              // =112
     3d4:      	add	x11, sp, #0xac
     3d8:      	add	x0, sp, #0xac
     3dc:      	mov	w1, #0x1                // =1
     3e0:      	add	x8, x8, x9
     3e4:      	mov	w9, #0x1                // =1
     3e8:      	ldr	x8, [sp, #0x88]
     3ec:      	ldr	w9, [x21, #0x10]
     3f0:      	add	x2, x8, x9
     3f4:      	blr	x10
     3f8:      	cbz	x0, 0x510 <kprobe_go_labels+0x510>
     3fc:      	ldr	w8, [x24]
     400:      	cbz	w8, 0x140 <kprobe_go_labels+0x140>
     404:      	mov	w8, #0x746e             // =29806
     408:      	movk	w8, #0xa, lsl #16
     40c:      	stur	w8, [sp, #0x57]
     410:      	adrp	x8, 0x0 <kprobe_go_labels>
     414:      	add	x8, x8, #0x0
     418:      	ldp	x9, x10, [x8, #0x10]
     41c:      	stp	x9, x10, [sp, #0x40]
     420:      	ldr	x9, [x8, #0x20]
     424:      	add	x10, sp, #0x30
     428:      	str	x9, [sp, #0x50]
     42c:      	ldp	x8, x9, [x8]
     430:      	stp	x8, x9, [sp, #0x30]
     434:      	mov	w8, #0x2b               // =43
     438:      	mov	w9, #0x6                // =6
     43c:      	b	0x338 <kprobe_go_labels+0x338>
     440:      	str	x21, [sp, #0x28]
     444:      	mov	x21, xzr
     448:      	mov	x23, xzr
     44c:      	mov	x25, xzr
     450:      	ldr	x8, [sp, #0x90]
     454:      	cmp	x8, x25
     458:      	b.ls	0x4c8 <kprobe_go_labels+0x4c8>
     45c:      	add	x29, x20, x21
     460:      	add	x22, x20, x23
     464:      	mov	w9, #0xf                // =15
     468:      	ldr	x8, [x29, #0xf78]
     46c:      	add	x0, x22, #0x3c
     470:      	cmp	x8, #0xf
     474:      	csel	x1, x8, x9, lo
     478:      	ldr	x8, [x29, #0xf70]
     47c:      	mov	w9, #0x70               // =112
     480:      	ldr	x2, [x29, #0xf70]
     484:      	blr	x9
     488:      	cbnz	x0, 0x594 <kprobe_go_labels+0x594>
     48c:      	ldr	x8, [x29, #0xf88]
     490:      	mov	w9, #0x2f               // =47
     494:      	add	x0, x22, #0x4c
     498:      	cmp	x8, #0x2f
     49c:      	csel	x1, x8, x9, lo
     4a0:      	ldr	x8, [x29, #0xf80]
     4a4:      	mov	w9, #0x70               // =112
     4a8:      	ldr	x2, [x29, #0xf80]
     4ac:      	blr	x9
     4b0:      	cbnz	x0, 0x5dc <kprobe_go_labels+0x5dc>
     4b4:      	add	x23, x23, #0x40
     4b8:      	add	x25, x25, #0x1
     4bc:      	add	x21, x21, #0x20
     4c0:      	cmp	x23, #0x280
     4c4:      	b.ne	0x450 <kprobe_go_labels+0x450>
     4c8:      	ldr	x8, [sp, #0x28]
     4cc:      	str	w8, [x20, #0x38]
     4d0:      	b	0x17c <kprobe_go_labels+0x17c>
     4d4:      	ldr	w8, [x24]
     4d8:      	cbz	w8, 0x140 <kprobe_go_labels+0x140>
     4dc:      	adrp	x8, 0x0 <kprobe_go_labels>
     4e0:      	add	x8, x8, #0x0
     4e4:      	add	x10, sp, #0x30
     4e8:      	ldr	x9, [x8]
     4ec:      	ldur	x8, [x8, #0x7]
     4f0:      	add	x0, sp, #0x30
     4f4:      	mov	w1, #0xf                // =15
     4f8:      	str	x9, [sp, #0x30]
     4fc:      	stur	x8, [sp, #0x37]
     500:      	mov	w8, #0xf                // =15
     504:      	mov	w9, #0x6                // =6
     508:      	blr	x9
     50c:      	b	0x140 <kprobe_go_labels+0x140>
     510:      	ldr	x8, [sp, #0x88]
     514:      	ldr	w9, [x21, #0x14]
     518:      	mov	w10, #0x70              // =112
     51c:      	add	x11, sp, #0xa0
     520:      	add	x0, sp, #0xa0
     524:      	mov	w1, #0x8                // =8
     528:      	add	x8, x8, x9
     52c:      	mov	w9, #0x8                // =8
     530:      	ldr	x8, [sp, #0x88]
     534:      	ldr	w9, [x21, #0x14]
     538:      	add	x2, x8, x9
     53c:      	blr	x10
     540:      	cbz	x0, 0x630 <kprobe_go_labels+0x630>
     544:      	ldr	w8, [x24]
     548:      	cbz	w8, 0x140 <kprobe_go_labels+0x140>
     54c:      	mov	w8, #0x7374             // =29556
     550:      	add	x0, sp, #0x30
     554:      	mov	w1, #0x2c               // =44
     558:      	movk	w8, #0xa, lsl #16
     55c:      	str	w8, [sp, #0x58]
     560:      	adrp	x8, 0x0 <kprobe_go_labels>
     564:      	add	x8, x8, #0x0
     568:      	ldp	x9, x10, [x8, #0x10]
     56c:      	stp	x9, x10, [sp, #0x40]
     570:      	ldr	x9, [x8, #0x20]
     574:      	add	x10, sp, #0x30
     578:      	str	x9, [sp, #0x50]
     57c:      	ldp	x8, x9, [x8]
     580:      	stp	x8, x9, [sp, #0x30]
     584:      	mov	w8, #0x2c               // =44
     588:      	mov	w9, #0x6                // =6
     58c:      	blr	x9
     590:      	b	0x140 <kprobe_go_labels+0x140>
     594:      	ldr	w8, [x24]
     598:      	cbz	w8, 0x140 <kprobe_go_labels+0x140>
     59c:      	adrp	x8, 0x0 <kprobe_go_labels>
     5a0:      	add	x8, x8, #0x0
     5a4:      	add	x11, sp, #0x30
     5a8:      	ldp	x9, x10, [x8, #0x10]
     5ac:      	stp	x9, x10, [sp, #0x40]
     5b0:      	ldr	x9, [x8, #0x20]
     5b4:      	mov	w10, #0x6               // =6
     5b8:      	str	x9, [sp, #0x50]
     5bc:      	ldur	x9, [x8, #0x27]
     5c0:      	stur	x9, [sp, #0x57]
     5c4:      	ldp	x9, x8, [x8]
     5c8:      	stp	x9, x8, [sp, #0x30]
     5cc:      	add	x9, x20, x21
     5d0:      	mov	w8, #0x2f               // =47
     5d4:      	ldr	x2, [x9, #0xf70]
     5d8:      	b	0x620 <kprobe_go_labels+0x620>
     5dc:      	ldr	w8, [x24]
     5e0:      	cbz	w8, 0x140 <kprobe_go_labels+0x140>
     5e4:      	adrp	x8, 0x0 <kprobe_go_labels>
     5e8:      	add	x8, x8, #0x0
     5ec:      	add	x11, sp, #0x30
     5f0:      	ldp	x9, x10, [x8, #0x10]
     5f4:      	stp	x9, x10, [sp, #0x40]
     5f8:      	ldr	x9, [x8, #0x20]
     5fc:      	mov	w10, #0x6               // =6
     600:      	str	x9, [sp, #0x50]
     604:      	ldur	x9, [x8, #0x27]
     608:      	stur	x9, [sp, #0x57]
     60c:      	ldp	x9, x8, [x8]
     610:      	stp	x9, x8, [sp, #0x30]
     614:      	add	x9, x20, x21
     618:      	mov	w8, #0x2f               // =47
     61c:      	ldr	x2, [x9, #0xf80]
     620:      	add	x0, sp, #0x30
     624:      	mov	w1, #0x2f               // =47
     628:      	blr	x10
     62c:      	b	0x140 <kprobe_go_labels+0x140>
     630:      	ldrb	w8, [sp, #0xac]
     634:      	mov	w9, #0x1                // =1
     638:      	mov	x10, xzr
     63c:      	add	x0, x20, #0xf70
     640:      	add	x22, x20, #0x1, lsl #12 // =0x1000
     644:      	str	x22, [sp, #0x20]
     648:      	mov	w11, #0x110             // =272
     64c:      	lsl	x8, x9, x8
     650:      	and	x8, x8, #0xff
     654:      	stp	x0, x8, [sp, #0x8]
     658:      	cmp	x10, x8
     65c:      	b.eq	0x17c <kprobe_go_labels+0x17c>
     660:      	ldr	x8, [sp, #0xa0]
     664:      	str	x10, [sp, #0x18]
     668:      	add	x9, x10, x10, lsl #4
     66c:      	mov	w10, #0x70              // =112
     670:      	mov	w1, #0x110              // =272
     674:      	add	x8, x8, x9, lsl #4
     678:      	ldr	x8, [sp, #0xa0]
     67c:      	add	x2, x8, x9, lsl #4
     680:      	blr	x10
     684:      	cbnz	x0, 0x140 <kprobe_go_labels+0x140>
     688:      	ldr	w8, [x20, #0x38]
     68c:      	mov	x21, xzr
     690:      	mov	x29, x22
     694:      	b	0x6a8 <kprobe_go_labels+0x6a8>
     698:      	add	x21, x21, #0x1
     69c:      	add	x29, x29, #0x10
     6a0:      	cmp	x21, #0x8
     6a4:      	b.eq	0x730 <kprobe_go_labels+0x730>
     6a8:      	cmp	w8, #0xa
     6ac:      	b.hs	0x17c <kprobe_go_labels+0x17c>
     6b0:      	add	x9, x22, x21
     6b4:      	ldurb	w9, [x9, #-0x90]
     6b8:      	cbz	w9, 0x698 <kprobe_go_labels+0x698>
     6bc:      	ldur	x23, [x29, #-0x88]
     6c0:      	cbz	x23, 0x698 <kprobe_go_labels+0x698>
     6c4:      	mov	w8, w8
     6c8:      	ldur	x9, [x29, #-0x8]
     6cc:      	ldr	w25, [x29]
     6d0:      	mov	x2, x23
     6d4:      	add	x22, x20, x8, lsl #6
     6d8:      	ldur	w8, [x29, #-0x80]
     6dc:      	add	x0, x22, #0x3c
     6e0:      	cmp	w8, #0xf
     6e4:      	str	x9, [sp, #0x28]
     6e8:      	mov	w9, #0xf                // =15
     6ec:      	csel	w1, w8, w9, lo
     6f0:      	mov	w8, #0x70               // =112
     6f4:      	blr	x8
     6f8:      	cbnz	x0, 0x7e4 <kprobe_go_labels+0x7e4>
     6fc:      	cmp	w25, #0x2f
     700:      	mov	w8, #0x2f               // =47
     704:      	ldr	x2, [sp, #0x28]
     708:      	add	x0, x22, #0x4c
     70c:      	csel	w1, w25, w8, lo
     710:      	mov	w8, #0x70               // =112
     714:      	blr	x8
     718:      	cbnz	x0, 0x830 <kprobe_go_labels+0x830>
     71c:      	ldr	w8, [x20, #0x38]
     720:      	ldr	x22, [sp, #0x20]
     724:      	add	w8, w8, #0x1
     728:      	str	w8, [x20, #0x38]
     72c:      	b	0x698 <kprobe_go_labels+0x698>
     730:      	ldp	x8, x10, [sp, #0x10]
     734:      	mov	w11, #0x110             // =272
     738:      	add	x10, x10, #0x1
     73c:      	ldr	x0, [sp, #0x8]
     740:      	cmp	x10, #0x10
     744:      	b.ne	0x658 <kprobe_go_labels+0x658>
     748:      	b	0x17c <kprobe_go_labels+0x17c>
     74c:      	adrp	x8, 0x0 <kprobe_go_labels>
     750:      	add	x8, x8, #0x0
     754:      	add	x0, sp, #0x30
     758:      	ldp	x9, x10, [x8, #0x20]
     75c:      	mov	w1, #0x40               // =64
     760:      	stp	x9, x10, [sp, #0x50]
     764:      	ldp	x9, x10, [x8, #0x30]
     768:      	stp	x9, x10, [sp, #0x60]
     76c:      	ldp	x9, x10, [x8]
     770:      	stp	x9, x10, [sp, #0x30]
     774:      	ldp	x9, x8, [x8, #0x10]
     778:      	add	x10, sp, #0x30
     77c:      	stp	x9, x8, [sp, #0x40]
     780:      	mov	w8, #0x40               // =64
     784:      	mov	w9, #0x6                // =6
     788:      	ldr	w2, [sp, #0x74]
     78c:      	ldr	x3, [x20, #0xf68]
     790:      	blr	x9
     794:      	b	0x78 <kprobe_go_labels+0x78>
     798:      	mov	w8, #0xa                // =10
     79c:      	add	x0, sp, #0x30
     7a0:      	mov	w1, #0x32               // =50
     7a4:      	strh	w8, [sp, #0x60]
     7a8:      	adrp	x8, 0x0 <kprobe_go_labels>
     7ac:      	add	x8, x8, #0x0
     7b0:      	ldp	x9, x10, [x8, #0x10]
     7b4:      	stp	x9, x10, [sp, #0x40]
     7b8:      	ldp	x9, x10, [x8, #0x20]
     7bc:      	stp	x9, x10, [sp, #0x50]
     7c0:      	ldp	x9, x8, [x8]
     7c4:      	add	x10, sp, #0x30
     7c8:      	stp	x9, x8, [sp, #0x30]
     7cc:      	mov	w8, #0x32               // =50
     7d0:      	mov	w9, #0x6                // =6
     7d4:      	ldr	w2, [sp, #0x74]
     7d8:      	blr	x9
     7dc:      	mov	w0, #-0x1               // =-1
     7e0:      	b	0x1c0 <kprobe_go_labels+0x1c0>
     7e4:      	ldr	w8, [x24]
     7e8:      	cbz	w8, 0x140 <kprobe_go_labels+0x140>
     7ec:      	adrp	x8, 0x0 <kprobe_go_labels>
     7f0:      	add	x8, x8, #0x0
     7f4:      	add	x0, sp, #0x30
     7f8:      	ldp	x9, x10, [x8, #0x10]
     7fc:      	mov	w1, #0x2f               // =47
     800:      	mov	x2, x23
     804:      	stp	x9, x10, [sp, #0x40]
     808:      	ldr	x9, [x8, #0x20]
     80c:      	add	x10, sp, #0x30
     810:      	str	x9, [sp, #0x50]
     814:      	ldur	x9, [x8, #0x27]
     818:      	stur	x9, [sp, #0x57]
     81c:      	ldp	x9, x8, [x8]
     820:      	stp	x9, x8, [sp, #0x30]
     824:      	mov	w8, #0x2f               // =47
     828:      	mov	w9, #0x6                // =6
     82c:      	b	0x2b8 <kprobe_go_labels+0x2b8>
     830:      	ldr	w8, [x24]
     834:      	cbz	w8, 0x140 <kprobe_go_labels+0x140>
     838:      	mov	w8, #0x6c65             // =27749
     83c:      	movk	w8, #0xa, lsl #16
     840:      	stur	w8, [sp, #0x57]
     844:      	adrp	x8, 0x0 <kprobe_go_labels>
     848:      	add	x8, x8, #0x0
     84c:      	ldp	x9, x10, [x8, #0x10]
     850:      	stp	x9, x10, [sp, #0x40]
     854:      	ldr	x9, [x8, #0x20]
     858:      	add	x10, sp, #0x30
     85c:      	str	x9, [sp, #0x50]
     860:      	ldp	x8, x9, [x8]
     864:      	stp	x8, x9, [sp, #0x30]
     868:      	mov	w8, #0x2b               // =43
     86c:      	mov	w9, #0x6                // =6
     870:      	b	0x338 <kprobe_go_labels+0x338>
     874:      	adrp	x8, 0x0 <kprobe_go_labels>
     878:      	add	x8, x8, #0x0
     87c:      	add	x0, sp, #0x30
     880:      	ldp	x9, x10, [x8, #0x10]
     884:      	mov	w1, #0x2e               // =46
     888:      	stp	x9, x10, [sp, #0x40]
     88c:      	ldr	x9, [x8, #0x20]
     890:      	add	x10, sp, #0x30
     894:      	str	x9, [sp, #0x50]
     898:      	ldur	x9, [x8, #0x26]
     89c:      	stur	x9, [sp, #0x56]
     8a0:      	ldp	x9, x8, [x8]
     8a4:      	stp	x9, x8, [sp, #0x30]
     8a8:      	mov	w8, #0x2e               // =46
     8ac:      	mov	w9, #0x6                // =6
     8b0:      	ldr	w2, [sp, #0x88]
     8b4:      	blr	x9
     8b8:      	b	0x17c <kprobe_go_labels+0x17c>
     8bc:      	adrp	x8, 0x0 <kprobe_go_labels>
     8c0:      	add	x8, x8, #0x0
     8c4:      	add	x0, sp, #0x30
     8c8:      	ldp	x9, x10, [x8, #0x20]
     8cc:      	mov	w1, #0x36               // =54
     8d0:      	stp	x9, x10, [sp, #0x50]
     8d4:      	ldur	x9, [x8, #0x2e]
     8d8:      	stur	x9, [sp, #0x5e]
     8dc:      	ldp	x9, x10, [x8]
     8e0:      	stp	x9, x10, [sp, #0x30]
     8e4:      	ldp	x8, x9, [x8, #0x10]
     8e8:      	add	x10, sp, #0x30
     8ec:      	stp	x8, x9, [sp, #0x40]
     8f0:      	mov	w8, #0x36               // =54
     8f4:      	mov	w9, #0x6                // =6
     8f8:      	ldr	x2, [sp, #0x80]
     8fc:      	ldr	w3, [x21, #0x8]
     900:      	blr	x9
     904:      	b	0x140 <kprobe_go_labels+0x140>
