
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_execve_event_v53.native.o:	file format elf64-littleaarch64

Disassembly of section tracepoint:

0000000000000000 <execve_rate>:
       0:      	sub	sp, sp, #0x80
       4:      	str	x30, [sp, #0x40]
       8:      	stp	x24, x23, [sp, #0x50]
       c:      	stp	x22, x21, [sp, #0x60]
      10:      	stp	x20, x19, [sp, #0x70]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0x4]
      1c:      	adrp	x0, 0x0 <execve_rate>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0x4
      2c:      	add	x1, sp, #0x4
      30:      	blr	x8
      34:      	cbz	x0, 0x284 <execve_rate+0x284>
      38:      	ldr	x23, [x0, #0x8]
      3c:      	ldr	x8, [x0, #0x10]!
      40:      	add	x9, sp, #0x34
      44:      	add	x1, sp, #0x34
      48:      	mov	x20, x0
      4c:      	str	wzr, [sp, #0x34]
      50:      	adrp	x0, 0x0 <execve_rate>
      54:      	str	x8, [sp, #0x38]
      58:      	mov	w8, #0x1                // =1
      5c:      	ldr	x0, [x0]
      60:      	blr	x8
      64:      	cbz	x0, 0x268 <execve_rate+0x268>
      68:      	ldr	x22, [x0, #0x8]
      6c:      	cbz	x22, 0x268 <execve_rate+0x268>
      70:      	adrp	x21, 0x0 <execve_rate>
      74:      	mov	w8, #0x1                // =1
      78:      	add	x9, sp, #0x38
      7c:      	ldr	x21, [x21]
      80:      	mov	x24, x0
      84:      	add	x1, sp, #0x38
      88:      	mov	x0, x21
      8c:      	blr	x8
      90:      	cbz	x0, 0xbc <execve_rate+0xbc>
      94:      	ldr	x8, [x0, #0x10]
      98:      	sub	x9, x23, x8
      9c:      	cmp	x9, x22
      a0:      	b.ls	0xf8 <execve_rate+0xf8>
      a4:      	cmp	x9, x22, lsl #1
      a8:      	b.ls	0x104 <execve_rate+0x104>
      ac:      	udiv	x8, x23, x22
      b0:      	mov	x9, xzr
      b4:      	mul	x8, x8, x22
      b8:      	b	0x10c <execve_rate+0x10c>
      bc:      	mov	w8, #0x1                // =1
      c0:      	str	xzr, [sp, #0x28]
      c4:      	mov	x3, xzr
      c8:      	add	x9, sp, #0x38
      cc:      	stp	x8, xzr, [sp, #0x8]
      d0:      	udiv	x8, x23, x22
      d4:      	add	x10, sp, #0x8
      d8:      	add	x1, sp, #0x38
      dc:      	add	x2, sp, #0x8
      e0:      	mov	x0, x21
      e4:      	mul	x8, x8, x22
      e8:      	stp	x8, xzr, [sp, #0x18]
      ec:      	mov	w8, #0x2                // =2
      f0:      	blr	x8
      f4:      	b	0x268 <execve_rate+0x268>
      f8:      	ldp	x10, x9, [x0]
      fc:      	add	x10, x10, #0x1
     100:      	b	0x114 <execve_rate+0x114>
     104:      	ldr	x9, [x0]
     108:      	add	x8, x8, x22
     10c:      	mov	w10, #0x1               // =1
     110:      	stp	x9, x8, [x0, #0x8]
     114:      	sub	x11, x22, x23
     118:      	str	x10, [x0]
     11c:      	add	x8, x11, x8
     120:      	mul	x8, x8, x9
     124:      	ldr	x9, [x0, #0x20]
     128:      	udiv	x8, x8, x22
     12c:      	add	x8, x8, x10
     130:      	str	x8, [x0, #0x18]
     134:      	cbnz	x9, 0x284 <execve_rate+0x284>
     138:      	ldr	x9, [x24]
     13c:      	cmp	x8, x9
     140:      	b.lo	0x268 <execve_rate+0x268>
     144:      	mov	x22, x0
     148:      	str	x23, [x0, #0x20]
     14c:      	str	wzr, [sp, #0x4c]
     150:      	adrp	x0, 0x0 <execve_rate>
     154:      	mov	w8, #0x1                // =1
     158:      	add	x9, sp, #0x4c
     15c:      	ldr	x0, [x0]
     160:      	add	x1, sp, #0x48
     164:      	str	wzr, [sp, #0x48]
     168:      	blr	x8
     16c:      	cbz	x0, 0x260 <execve_rate+0x260>
     170:      	mov	w24, #0xa0              // =160
     174:      	mov	w8, #0x1b               // =27
     178:      	str	x23, [x0, #0x8]
     17c:      	mov	x21, x0
     180:      	str	w24, [x0, #0x4]
     184:      	mov	x1, x20
     188:      	strh	w8, [x0], #0x10
     18c:      	mov	w2, #0x90               // =144
     190:      	bl	0x190 <execve_rate+0x190>
     194:      	adrp	x1, 0x0 <execve_rate>
     198:      	mov	w8, #-0x1               // =-1
     19c:      	mov	w9, #0x19               // =25
     1a0:      	ldr	x1, [x1]
     1a4:      	mov	x0, x19
     1a8:      	mov	w2, #-0x1               // =-1
     1ac:      	mov	x3, x21
     1b0:      	mov	w4, #0xa0               // =160
     1b4:      	blr	x9
     1b8:      	tbz	x0, #0x3f, 0x260 <execve_rate+0x260>
     1bc:      	mov	x20, x0
     1c0:      	str	wzr, [sp, #0x8]
     1c4:      	adrp	x0, 0x0 <execve_rate>
     1c8:      	mov	w8, #0x1                // =1
     1cc:      	ldr	x0, [x0]
     1d0:      	add	x9, sp, #0x8
     1d4:      	add	x1, sp, #0x8
     1d8:      	blr	x8
     1dc:      	cbz	x0, 0x260 <execve_rate+0x260>
     1e0:      	mov	x8, x20
     1e4:      	cmn	x20, #0xc
     1e8:      	b.gt	0x20c <execve_rate+0x20c>
     1ec:      	cmn	x8, #0x1c
     1f0:      	b.eq	0x22c <execve_rate+0x22c>
     1f4:      	cmn	x8, #0x16
     1f8:      	b.eq	0x244 <execve_rate+0x244>
     1fc:      	cmn	x8, #0x10
     200:      	b.ne	0x23c <execve_rate+0x23c>
     204:      	add	x8, x0, #0x600
     208:      	b	0x250 <execve_rate+0x250>
     20c:      	cmn	x8, #0xb
     210:      	b.eq	0x234 <execve_rate+0x234>
     214:      	cmn	x8, #0x7
     218:      	b.eq	0x24c <execve_rate+0x24c>
     21c:      	cmn	x8, #0x2
     220:      	b.ne	0x23c <execve_rate+0x23c>
     224:      	add	x8, x0, #0x5f0
     228:      	b	0x250 <execve_rate+0x250>
     22c:      	add	x8, x0, #0x610
     230:      	b	0x250 <execve_rate+0x250>
     234:      	add	x8, x0, #0x618
     238:      	b	0x250 <execve_rate+0x250>
     23c:      	add	x8, x0, #0x5e8
     240:      	b	0x250 <execve_rate+0x250>
     244:      	add	x8, x0, #0x608
     248:      	b	0x250 <execve_rate+0x250>
     24c:      	add	x8, x0, #0x5f8
     250:      	ldaxr	x9, [x8]
     254:      	add	x9, x9, #0x1
     258:      	stlxr	w10, x9, [x8]
     25c:      	cbnz	w10, 0x250 <execve_rate+0x250>
     260:      	ldr	x8, [x22, #0x20]
     264:      	cbnz	x8, 0x284 <execve_rate+0x284>
     268:      	adrp	x1, 0x0 <execve_rate>
     26c:      	mov	w8, #0x1                // =1
     270:      	mov	w9, #0xc                // =12
     274:      	ldr	x1, [x1]
     278:      	mov	x0, x19
     27c:      	mov	w2, #0x1                // =1
     280:      	blr	x9
     284:      	ldp	x20, x19, [sp, #0x70]
     288:      	mov	w0, wzr
     28c:      	ldr	x30, [sp, #0x40]
     290:      	ldp	x22, x21, [sp, #0x60]
     294:      	ldp	x24, x23, [sp, #0x50]
     298:      	add	sp, sp, #0x80
     29c:      	ret

00000000000002a0 <execve_send>:
     2a0:      	sub	sp, sp, #0xf0
     2a4:      	str	x29, [sp, #0xa0]
     2a8:      	stp	x30, x25, [sp, #0xb0]
     2ac:      	stp	x24, x23, [sp, #0xc0]
     2b0:      	stp	x22, x21, [sp, #0xd0]
     2b4:      	stp	x20, x19, [sp, #0xe0]
     2b8:      	mov	x29, x0
     2bc:      	str	wzr, [sp, #0x28]
     2c0:      	adrp	x0, 0x0 <execve_rate>
     2c4:      	mov	w8, #0x1                // =1
     2c8:      	ldr	x0, [x0]
     2cc:      	add	x9, sp, #0x28
     2d0:      	add	x1, sp, #0x28
     2d4:      	blr	x8
     2d8:      	cbz	x0, 0x10b8 <execve_send+0xe18>
     2dc:      	mov	w8, #0x23               // =35
     2e0:      	mov	x25, x0
     2e4:      	blr	x8
     2e8:      	mov	w8, #0x16c0             // =5824
     2ec:      	add	x2, x0, #0x858
     2f0:      	mov	w19, #0x8               // =8
     2f4:      	mov	w9, #0x4                // =4
     2f8:      	add	x0, sp, #0x90
     2fc:      	mov	w1, #0x8                // =8
     300:      	mov	w20, #0x4               // =4
     304:      	add	x21, x25, x8
     308:      	add	x8, sp, #0x90
     30c:      	blr	x9
     310:      	ldr	x8, [sp, #0x90]
     314:      	add	x9, sp, #0x40
     318:      	add	x0, sp, #0x40
     31c:      	mov	w1, #0x8                // =8
     320:      	add	x8, x8, #0x528
     324:      	ldr	x8, [sp, #0x90]
     328:      	add	x2, x8, #0x528
     32c:      	blr	x20
     330:      	str	wzr, [sp, #0x2c]
     334:      	adrp	x0, 0x0 <execve_rate>
     338:      	ldr	x19, [sp, #0x40]
     33c:      	mov	w8, #0x1                // =1
     340:      	add	x9, sp, #0x2c
     344:      	add	x1, sp, #0x2c
     348:      	ldr	x0, [x0]
     34c:      	blr	x8
     350:      	cbz	x0, 0x7e0 <execve_send+0x540>
     354:      	mov	w8, #0x1000             // =4096
     358:      	stp	x21, x29, [sp, #0x10]
     35c:      	mov	x22, x0
     360:      	add	x20, x0, #0x1, lsl #12  // =0x1000
     364:      	str	x25, [sp, #0x20]
     368:      	str	w8, [x25, #0x1840]
     36c:      	mov	w8, #0x23               // =35
     370:      	blr	x8
     374:      	add	x2, x0, #0xb30
     378:      	mov	w25, #0x8               // =8
     37c:      	add	x8, sp, #0x30
     380:      	mov	w9, #0x4                // =4
     384:      	add	x0, sp, #0x30
     388:      	mov	w1, #0x8                // =8
     38c:      	mov	w29, #0x4               // =4
     390:      	blr	x9
     394:      	ldr	x21, [sp, #0x30]
     398:      	add	x23, x19, #0x48
     39c:      	add	x8, sp, #0x38
     3a0:      	mov	w9, #0x4                // =4
     3a4:      	add	x0, sp, #0x38
     3a8:      	mov	w1, #0x8                // =8
     3ac:      	mov	x2, x23
     3b0:      	blr	x9
     3b4:      	ldr	x24, [sp, #0x38]
     3b8:      	add	x8, sp, #0x40
     3bc:      	add	x0, sp, #0x40
     3c0:      	mov	w1, #0x8                // =8
     3c4:      	add	x2, x24, #0x10
     3c8:      	blr	x29
     3cc:      	ldr	x8, [sp, #0x40]
     3d0:      	cbz	x8, 0x648 <execve_send+0x3a8>
     3d4:      	ldr	x8, [sp, #0x20]
     3d8:      	stp	xzr, xzr, [sp, #0x40]
     3dc:      	add	x25, x21, #0x18
     3e0:      	add	x9, sp, #0x40
     3e4:      	add	x2, x21, #0x20
     3e8:      	mov	w21, #0x8               // =8
     3ec:      	stp	x22, xzr, [sp, #0x50]
     3f0:      	add	x0, sp, #0x40
     3f4:      	mov	w1, #0x8                // =8
     3f8:      	add	x24, x19, #0x40
     3fc:      	add	x29, x9, #0x8
     400:      	ldr	w8, [x8, #0x1840]
     404:      	stp	xzr, xzr, [sp, #0x60]
     408:      	str	x20, [sp, #0x8]
     40c:      	str	x20, [sp, #0x70]
     410:      	add	x22, x9, #0x18
     414:      	add	x19, x9, #0x20
     418:      	mov	w20, #0x4               // =4
     41c:      	strb	wzr, [sp, #0x7c]
     420:      	str	w8, [sp, #0x78]
     424:      	mov	w8, #0x4                // =4
     428:      	blr	x8
     42c:      	mov	w8, #0x4                // =4
     430:      	mov	x0, x29
     434:      	mov	w1, #0x8                // =8
     438:      	mov	x2, x25
     43c:      	blr	x8
     440:      	mov	w8, #0x4                // =4
     444:      	mov	x0, x22
     448:      	mov	w1, #0x8                // =8
     44c:      	mov	x2, x23
     450:      	blr	x8
     454:      	mov	x0, x19
     458:      	mov	w1, #0x8                // =8
     45c:      	mov	x2, x24
     460:      	blr	x20
     464:      	ldr	x8, [sp, #0x60]
     468:      	mov	w19, #0x80              // =128
     46c:      	add	x24, sp, #0x80
     470:      	add	x25, sp, #0xa8
     474:      	sub	x8, x8, #0x20
     478:      	str	x8, [sp, #0x68]
     47c:      	b	0x4b8 <execve_send+0x218>
     480:      	add	x29, x8, x12
     484:      	cmp	w23, w20
     488:      	add	x2, x9, x10
     48c:      	and	w1, w11, #0xff
     490:      	mov	w8, #0x4                // =4
     494:      	cinc	x0, x29, hi
     498:      	blr	x8
     49c:      	cmp	w23, w20
     4a0:      	str	x29, [sp, #0x70]
     4a4:      	b.ls	0x5f8 <execve_send+0x358>
     4a8:      	ldr	x8, [sp, #0x88]
     4ac:      	str	x8, [sp, #0x58]
     4b0:      	subs	w19, w19, #0x1
     4b4:      	b.eq	0x5f8 <execve_send+0x358>
     4b8:      	ldp	x20, x2, [sp, #0x58]
     4bc:      	ldp	x8, x9, [sp, #0x40]
     4c0:      	cmp	x20, x8
     4c4:      	ccmp	x2, x9, #0x0, eq
     4c8:      	b.eq	0x5f0 <execve_send+0x350>
     4cc:      	ldr	x29, [sp, #0x68]
     4d0:      	mov	w8, #0x4                // =4
     4d4:      	add	x0, sp, #0x80
     4d8:      	mov	w1, #0x8                // =8
     4dc:      	blr	x8
     4e0:      	ldr	x8, [sp, #0x80]
     4e4:      	cmp	x20, x8
     4e8:      	b.eq	0x5a0 <execve_send+0x300>
     4ec:      	add	x23, x20, #0x18
     4f0:      	mov	w8, #0x4                // =4
     4f4:      	add	x0, sp, #0xa8
     4f8:      	mov	w1, #0x8                // =8
     4fc:      	mov	x2, x23
     500:      	blr	x8
     504:      	ldr	x8, [sp, #0xa8]
     508:      	cmp	x8, x20
     50c:      	b.eq	0x5a0 <execve_send+0x300>
     510:      	mov	w8, #0x4                // =4
     514:      	add	x9, sp, #0x88
     518:      	add	x0, sp, #0x88
     51c:      	mov	w1, #0x8                // =8
     520:      	mov	x2, x23
     524:      	blr	x8
     528:      	add	x2, x20, #0x20
     52c:      	mov	w8, #0x4                // =4
     530:      	mov	w9, #0x10               // =16
     534:      	add	x10, sp, #0x90
     538:      	add	x0, sp, #0x90
     53c:      	mov	w1, #0x10               // =16
     540:      	blr	x8
     544:      	ldr	w20, [sp, #0x94]
     548:      	ldr	x8, [sp, #0x50]
     54c:      	ldr	x10, [sp, #0x70]
     550:      	sub	x12, x10, x8
     554:      	ldr	w23, [sp, #0x78]
     558:      	subs	w10, w20, w23
     55c:      	ldr	x9, [sp, #0x98]
     560:      	csel	w10, wzr, w10, lo
     564:      	cmp	w23, w20
     568:      	csel	w11, w23, w20, lo
     56c:      	cinc	w13, w11, hi
     570:      	sub	w14, w23, w13
     574:      	subs	x12, x12, x13
     578:      	str	w14, [sp, #0x78]
     57c:      	b.lo	0x5f8 <execve_send+0x358>
     580:      	cmp	x12, #0xfff
     584:      	b.hi	0x5f8 <execve_send+0x358>
     588:      	cmp	w23, w20
     58c:      	b.ls	0x480 <execve_send+0x1e0>
     590:      	mov	w13, #0x2f              // =47
     594:      	strb	w13, [x8, x12]
     598:      	b	0x480 <execve_send+0x1e0>
     59c:      	nop
     5a0:      	add	x2, x29, #0x10
     5a4:      	mov	w8, #0x4                // =4
     5a8:      	add	x0, sp, #0xa8
     5ac:      	mov	w1, #0x8                // =8
     5b0:      	blr	x8
     5b4:      	ldr	x8, [sp, #0x68]
     5b8:      	ldr	x9, [sp, #0xa8]
     5bc:      	cmp	x8, x9
     5c0:      	b.eq	0x5f0 <execve_send+0x350>
     5c4:      	add	x2, x29, #0x18
     5c8:      	mov	w8, #0x4                // =4
     5cc:      	mov	x0, x22
     5d0:      	mov	w1, #0x8                // =8
     5d4:      	blr	x8
     5d8:      	ldr	x8, [sp, #0xa8]
     5dc:      	add	x9, x8, #0x20
     5e0:      	stp	x9, x8, [sp, #0x60]
     5e4:      	subs	w19, w19, #0x1
     5e8:      	b.ne	0x4b8 <execve_send+0x218>
     5ec:      	b	0x5f8 <execve_send+0x358>
     5f0:      	mov	w8, #0x1                // =1
     5f4:      	strb	w8, [sp, #0x7c]
     5f8:      	ldr	x22, [sp, #0x70]
     5fc:      	ldr	x9, [sp, #0x8]
     600:      	cmp	x22, x9
     604:      	b.eq	0x698 <execve_send+0x3f8>
     608:      	ldrb	w8, [sp, #0x7c]
     60c:      	ldp	x29, x25, [sp, #0x18]
     610:      	cmp	w8, #0x0
     614:      	ldr	x21, [sp, #0x10]
     618:      	cset	w8, eq
     61c:      	lsl	w9, w8, #1
     620:      	ldr	w8, [sp, #0x78]
     624:      	str	w9, [x25, #0x1844]
     628:      	cmp	w8, #0x1
     62c:      	str	w8, [x25, #0x1840]
     630:      	b.lt	0x640 <execve_send+0x3a0>
     634:      	mov	w9, #0x1000             // =4096
     638:      	sub	w8, w9, w8
     63c:      	str	w8, [x25, #0x1840]
     640:      	cbnz	x22, 0x6ac <execve_send+0x40c>
     644:      	b	0x7e0 <execve_send+0x540>
     648:      	add	x2, x24, #0x18
     64c:      	mov	w8, #0x8                // =8
     650:      	mov	w9, #0x4                // =4
     654:      	add	x10, sp, #0x40
     658:      	add	x0, sp, #0x40
     65c:      	mov	w1, #0x8                // =8
     660:      	blr	x9
     664:      	ldr	x8, [sp, #0x40]
     668:      	cmp	x8, x24
     66c:      	b.eq	0x3d4 <execve_send+0x134>
     670:      	ldr	x25, [sp, #0x20]
     674:      	ldr	w9, [x25, #0x1840]
     678:      	sub	w8, w9, #0xa
     67c:      	cmp	w9, #0x9
     680:      	str	w8, [x25, #0x1840]
     684:      	b.gt	0xbfc <execve_send+0x95c>
     688:      	mov	w9, #-0x24              // =-36
     68c:      	mov	x22, x20
     690:      	str	w9, [x25, #0x1844]
     694:      	b	0x6a8 <execve_send+0x408>
     698:      	ldr	x25, [sp, #0x20]
     69c:      	mov	w8, wzr
     6a0:      	mov	x22, x9
     6a4:      	str	xzr, [x25, #0x1840]
     6a8:      	ldp	x21, x29, [sp, #0x10]
     6ac:      	subs	w9, w8, #0x7f
     6b0:      	mov	w10, #0x7f              // =127
     6b4:      	mov	x0, x21
     6b8:      	mov	x2, x22
     6bc:      	csel	w24, w8, w10, lo
     6c0:      	csel	w19, wzr, w9, lo
     6c4:      	cmp	w8, #0xff
     6c8:      	mov	w9, #0xff               // =255
     6cc:      	csel	w8, w8, w9, lo
     6d0:      	and	w1, w8, #0xff
     6d4:      	str	w1, [x25, #0x1840]
     6d8:      	mov	w8, #0x4                // =4
     6dc:      	blr	x8
     6e0:      	adrp	x23, 0x0 <execve_rate>
     6e4:      	ldr	x23, [x23]
     6e8:      	cbz	x0, 0x758 <execve_send+0x4b8>
     6ec:      	neg	w8, w0
     6f0:      	mov	w9, #0x1                // =1
     6f4:      	add	x1, sp, #0x40
     6f8:      	strh	w8, [sp, #0x40]
     6fc:      	mov	w8, #0x8                // =8
     700:      	mov	x0, x23
     704:      	mov	w20, #0x1               // =1
     708:      	strh	w8, [sp, #0x42]
     70c:      	mov	x8, #0x2de              // =734
     710:      	movk	x8, #0x4, lsl #32
     714:      	stur	x8, [sp, #0x44]
     718:      	add	x8, sp, #0x40
     71c:      	blr	x9
     720:      	cbz	x0, 0x734 <execve_send+0x494>
     724:      	ldr	w8, [x0]
     728:      	add	w8, w8, #0x1
     72c:      	str	w8, [x0]
     730:      	b	0x758 <execve_send+0x4b8>
     734:      	str	w20, [sp, #0x90]
     738:      	mov	x3, xzr
     73c:      	mov	w8, #0x2                // =2
     740:      	add	x9, sp, #0x40
     744:      	add	x10, sp, #0x90
     748:      	add	x1, sp, #0x40
     74c:      	add	x2, sp, #0x90
     750:      	mov	x0, x23
     754:      	blr	x8
     758:      	mov	w8, #0x17c0             // =6080
     75c:      	add	x2, x22, x19
     760:      	mov	w1, w24
     764:      	add	x0, x25, x8
     768:      	mov	w8, #0x4                // =4
     76c:      	blr	x8
     770:      	cbz	x0, 0x7e0 <execve_send+0x540>
     774:      	neg	w8, w0
     778:      	mov	w9, #0x1                // =1
     77c:      	add	x1, sp, #0x40
     780:      	strh	w8, [sp, #0x40]
     784:      	mov	w8, #0x8                // =8
     788:      	mov	x0, x23
     78c:      	mov	w19, #0x1               // =1
     790:      	strh	w8, [sp, #0x42]
     794:      	mov	x8, #0x2e0              // =736
     798:      	movk	x8, #0x4, lsl #32
     79c:      	stur	x8, [sp, #0x44]
     7a0:      	add	x8, sp, #0x40
     7a4:      	blr	x9
     7a8:      	cbz	x0, 0x7bc <execve_send+0x51c>
     7ac:      	ldr	w8, [x0]
     7b0:      	add	w8, w8, #0x1
     7b4:      	str	w8, [x0]
     7b8:      	b	0x7e0 <execve_send+0x540>
     7bc:      	str	w19, [sp, #0x90]
     7c0:      	mov	x3, xzr
     7c4:      	mov	w8, #0x2                // =2
     7c8:      	add	x9, sp, #0x40
     7cc:      	add	x10, sp, #0x90
     7d0:      	add	x1, sp, #0x40
     7d4:      	add	x2, sp, #0x90
     7d8:      	mov	x0, x23
     7dc:      	blr	x8
     7e0:      	mov	w8, #0xe                // =14
     7e4:      	blr	x8
     7e8:      	lsr	x8, x0, #32
     7ec:      	adrp	x23, 0x0 <execve_rate>
     7f0:      	add	x9, sp, #0x40
     7f4:      	str	w8, [sp, #0x40]
     7f8:      	mov	w8, #0x1                // =1
     7fc:      	add	x1, sp, #0x40
     800:      	ldr	x23, [x23]
     804:      	mov	x0, x23
     808:      	blr	x8
     80c:      	cbz	x0, 0xfd8 <execve_send+0xd38>
     810:      	ldp	x8, x9, [x0]
     814:      	mov	x22, x0
     818:      	stp	x8, x9, [x25, #0x130]
     81c:      	ldr	w9, [x25, #0x144]
     820:      	ldr	w8, [x0, #0x20]
     824:      	str	w9, [x0]
     828:      	ldr	x9, [x25, #0x170]
     82c:      	str	x9, [x0, #0x8]
     830:      	ldr	w9, [x25, #0x14c]
     834:      	str	w9, [x0, #0x24]
     838:      	ldp	x11, x10, [x25, #0xa0]
     83c:      	stp	x11, x10, [x0, #0x10]
     840:      	tbnz	w8, #0x0, 0x878 <execve_send+0x5d8>
     844:      	and	w10, w8, #0xfffffffe
     848:      	cmp	w9, #0x1
     84c:      	orr	w11, w10, #0x2000000
     850:      	csel	w9, w11, w10, eq
     854:      	str	w9, [x22, #0x20]
     858:      	tbnz	w9, #0x19, 0x89c <execve_send+0x5fc>
     85c:      	cmp	w8, #0x1
     860:      	b.eq	0x8b0 <execve_send+0x610>
     864:      	adrp	x8, 0x0 <execve_rate>
     868:      	ldr	x8, [x8]
     86c:      	ldrb	w8, [x8]
     870:      	cbnz	w8, 0x8f0 <execve_send+0x650>
     874:      	b	0xb58 <execve_send+0x8b8>
     878:      	ldr	w10, [x25, #0x15c]
     87c:      	orr	w10, w10, #0x4000
     880:      	str	w10, [x25, #0x15c]
     884:      	and	w10, w8, #0xfffffffe
     888:      	cmp	w9, #0x1
     88c:      	orr	w11, w10, #0x2000000
     890:      	csel	w9, w11, w10, eq
     894:      	str	w9, [x22, #0x20]
     898:      	tbz	w9, #0x19, 0x85c <execve_send+0x5bc>
     89c:      	ldr	w9, [x25, #0x15c]
     8a0:      	orr	w9, w9, #0x2000000
     8a4:      	str	w9, [x25, #0x15c]
     8a8:      	cmp	w8, #0x1
     8ac:      	b.ne	0x864 <execve_send+0x5c4>
     8b0:      	ldr	x8, [x25, #0x108]
     8b4:      	str	x8, [x22, #0x28]
     8b8:      	ldp	x8, x9, [x25, #0x110]
     8bc:      	ldp	x10, x11, [x25, #0x120]
     8c0:      	stp	x10, x11, [x22, #0x40]
     8c4:      	stp	x8, x9, [x22, #0x30]
     8c8:      	ldr	x8, [x25, #0xe0]
     8cc:      	str	x8, [x22, #0x50]
     8d0:      	ldr	x8, [x25, #0xe8]
     8d4:      	str	x8, [x22, #0x58]
     8d8:      	ldr	x8, [x25, #0xf0]
     8dc:      	str	x8, [x22, #0x60]
     8e0:      	adrp	x8, 0x0 <execve_rate>
     8e4:      	ldr	x8, [x8]
     8e8:      	ldrb	w8, [x8]
     8ec:      	cbz	w8, 0xb58 <execve_send+0x8b8>
     8f0:      	str	wzr, [sp, #0x88]
     8f4:      	adrp	x0, 0x0 <execve_rate>
     8f8:      	mov	w8, #0x1                // =1
     8fc:      	add	x9, sp, #0x88
     900:      	ldr	x0, [x0]
     904:      	add	x1, sp, #0x88
     908:      	blr	x8
     90c:      	cbz	x0, 0xb58 <execve_send+0x8b8>
     910:      	ldrb	w8, [x25, #0x15d]
     914:      	tbnz	w8, #0x6, 0x944 <execve_send+0x6a4>
     918:      	add	x1, x22, #0x68
     91c:      	mov	w2, #0x318              // =792
     920:      	mov	x19, x0
     924:      	bl	0x924 <execve_send+0x684>
     928:      	adrp	x0, 0x0 <execve_rate>
     92c:      	mov	x3, xzr
     930:      	mov	w8, #0x2                // =2
     934:      	ldr	x0, [x0]
     938:      	mov	x1, x22
     93c:      	mov	x2, x19
     940:      	b	0xb54 <execve_send+0x8b4>
     944:      	mov	w8, #0x23               // =35
     948:      	blr	x8
     94c:      	str	x0, [sp, #0x40]
     950:      	add	x8, x0, #0x8e0
     954:      	mov	w9, #0x8                // =8
     958:      	mov	w10, #0x71              // =113
     95c:      	add	x11, sp, #0x40
     960:      	add	x0, sp, #0x40
     964:      	mov	w1, #0x8                // =8
     968:      	ldr	x8, [sp, #0x40]
     96c:      	add	x2, x8, #0x8e0
     970:      	blr	x10
     974:      	ldr	x8, [sp, #0x40]
     978:      	cbz	x8, 0xb58 <execve_send+0x8b8>
     97c:      	add	x8, x8, #0x8d4
     980:      	mov	w9, #0x4                // =4
     984:      	mov	w10, #0x71              // =113
     988:      	add	x11, sp, #0xa8
     98c:      	ldr	x8, [sp, #0x40]
     990:      	add	x0, sp, #0xa8
     994:      	mov	w1, #0x4                // =4
     998:      	add	x2, x8, #0x8d4
     99c:      	blr	x10
     9a0:      	ldr	w8, [sp, #0xa8]
     9a4:      	add	x9, sp, #0x90
     9a8:      	add	x1, sp, #0x90
     9ac:      	mov	x0, x23
     9b0:      	str	w8, [sp, #0x90]
     9b4:      	mov	w8, #0x1                // =1
     9b8:      	blr	x8
     9bc:      	cbz	x0, 0x9c8 <execve_send+0x728>
     9c0:      	ldr	x8, [x0, #0x8]
     9c4:      	cbnz	x8, 0xb3c <execve_send+0x89c>
     9c8:      	ldr	x8, [sp, #0x40]
     9cc:      	mov	w9, #0x8                // =8
     9d0:      	mov	w10, #0x71              // =113
     9d4:      	add	x11, sp, #0x40
     9d8:      	add	x0, sp, #0x40
     9dc:      	mov	w1, #0x8                // =8
     9e0:      	add	x8, x8, #0x8e0
     9e4:      	ldr	x8, [sp, #0x40]
     9e8:      	add	x2, x8, #0x8e0
     9ec:      	blr	x10
     9f0:      	ldr	x8, [sp, #0x40]
     9f4:      	cbz	x8, 0xb58 <execve_send+0x8b8>
     9f8:      	add	x8, x8, #0x8d4
     9fc:      	mov	w9, #0x4                // =4
     a00:      	mov	w10, #0x71              // =113
     a04:      	add	x11, sp, #0xa8
     a08:      	ldr	x8, [sp, #0x40]
     a0c:      	add	x0, sp, #0xa8
     a10:      	mov	w1, #0x4                // =4
     a14:      	add	x2, x8, #0x8d4
     a18:      	blr	x10
     a1c:      	ldr	w8, [sp, #0xa8]
     a20:      	add	x9, sp, #0x90
     a24:      	add	x1, sp, #0x90
     a28:      	mov	x0, x23
     a2c:      	str	w8, [sp, #0x90]
     a30:      	mov	w8, #0x1                // =1
     a34:      	blr	x8
     a38:      	cbz	x0, 0xa44 <execve_send+0x7a4>
     a3c:      	ldr	x8, [x0, #0x8]
     a40:      	cbnz	x8, 0xb3c <execve_send+0x89c>
     a44:      	ldr	x8, [sp, #0x40]
     a48:      	mov	w9, #0x8                // =8
     a4c:      	mov	w10, #0x71              // =113
     a50:      	add	x11, sp, #0x40
     a54:      	add	x0, sp, #0x40
     a58:      	mov	w1, #0x8                // =8
     a5c:      	add	x8, x8, #0x8e0
     a60:      	ldr	x8, [sp, #0x40]
     a64:      	add	x2, x8, #0x8e0
     a68:      	blr	x10
     a6c:      	ldr	x8, [sp, #0x40]
     a70:      	cbz	x8, 0xb58 <execve_send+0x8b8>
     a74:      	add	x8, x8, #0x8d4
     a78:      	mov	w9, #0x4                // =4
     a7c:      	mov	w10, #0x71              // =113
     a80:      	add	x11, sp, #0xa8
     a84:      	ldr	x8, [sp, #0x40]
     a88:      	add	x0, sp, #0xa8
     a8c:      	mov	w1, #0x4                // =4
     a90:      	add	x2, x8, #0x8d4
     a94:      	blr	x10
     a98:      	ldr	w8, [sp, #0xa8]
     a9c:      	add	x9, sp, #0x90
     aa0:      	add	x1, sp, #0x90
     aa4:      	mov	x0, x23
     aa8:      	str	w8, [sp, #0x90]
     aac:      	mov	w8, #0x1                // =1
     ab0:      	blr	x8
     ab4:      	cbz	x0, 0xac0 <execve_send+0x820>
     ab8:      	ldr	x8, [x0, #0x8]
     abc:      	cbnz	x8, 0xb3c <execve_send+0x89c>
     ac0:      	ldr	x8, [sp, #0x40]
     ac4:      	mov	w9, #0x8                // =8
     ac8:      	mov	w10, #0x71              // =113
     acc:      	add	x11, sp, #0x40
     ad0:      	add	x0, sp, #0x40
     ad4:      	mov	w1, #0x8                // =8
     ad8:      	add	x8, x8, #0x8e0
     adc:      	ldr	x8, [sp, #0x40]
     ae0:      	add	x2, x8, #0x8e0
     ae4:      	blr	x10
     ae8:      	ldr	x8, [sp, #0x40]
     aec:      	cbz	x8, 0xb58 <execve_send+0x8b8>
     af0:      	add	x8, x8, #0x8d4
     af4:      	mov	w9, #0x4                // =4
     af8:      	mov	w10, #0x71              // =113
     afc:      	add	x11, sp, #0xa8
     b00:      	ldr	x8, [sp, #0x40]
     b04:      	add	x0, sp, #0xa8
     b08:      	mov	w1, #0x4                // =4
     b0c:      	add	x2, x8, #0x8d4
     b10:      	blr	x10
     b14:      	ldr	w8, [sp, #0xa8]
     b18:      	add	x9, sp, #0x90
     b1c:      	add	x1, sp, #0x90
     b20:      	mov	x0, x23
     b24:      	str	w8, [sp, #0x90]
     b28:      	mov	w8, #0x1                // =1
     b2c:      	blr	x8
     b30:      	cbz	x0, 0xb58 <execve_send+0x8b8>
     b34:      	ldr	x8, [x0, #0x8]
     b38:      	cbz	x8, 0xb58 <execve_send+0x8b8>
     b3c:      	add	x2, x0, #0x68
     b40:      	adrp	x0, 0x0 <execve_rate>
     b44:      	mov	x3, xzr
     b48:      	ldr	x0, [x0]
     b4c:      	mov	w8, #0x2                // =2
     b50:      	mov	x1, x22
     b54:      	blr	x8
     b58:      	add	x0, x22, #0x68
     b5c:      	mov	w1, wzr
     b60:      	mov	w2, #0x308              // =776
     b64:      	add	x19, x25, #0x140
     b68:      	bl	0xb68 <execve_send+0x8c8>
     b6c:      	ldr	w8, [x25, #0x1840]
     b70:      	sub	w9, w8, #0x101
     b74:      	cmn	w9, #0x101
     b78:      	b.hi	0xb88 <execve_send+0x8e8>
     b7c:      	mov	w8, #-0x1               // =-1
     b80:      	stur	w8, [x22, #0x68]
     b84:      	b	0xcf0 <execve_send+0xa50>
     b88:      	and	x24, x8, #0xff
     b8c:      	add	x0, x22, #0x70
     b90:      	mov	w8, #0x4                // =4
     b94:      	mov	x2, x21
     b98:      	mov	w1, w24
     b9c:      	blr	x8
     ba0:      	mov	x21, x0
     ba4:      	cbz	x0, 0xc4c <execve_send+0x9ac>
     ba8:      	neg	w8, w21
     bac:      	mov	x23, x25
     bb0:      	adrp	x25, 0x0 <execve_rate>
     bb4:      	strh	w8, [sp, #0x40]
     bb8:      	mov	w8, #0xf                // =15
     bbc:      	mov	w9, #0x1                // =1
     bc0:      	add	x1, sp, #0x40
     bc4:      	strh	w8, [sp, #0x42]
     bc8:      	mov	x8, #0x164              // =356
     bcc:      	mov	w20, #0x1               // =1
     bd0:      	movk	x8, #0x4, lsl #32
     bd4:      	stur	x8, [sp, #0x44]
     bd8:      	add	x8, sp, #0x40
     bdc:      	ldr	x25, [x25]
     be0:      	mov	x0, x25
     be4:      	blr	x9
     be8:      	cbz	x0, 0xc1c <execve_send+0x97c>
     bec:      	ldr	w8, [x0]
     bf0:      	add	w8, w8, #0x1
     bf4:      	str	w8, [x0]
     bf8:      	b	0xc40 <execve_send+0x9a0>
     bfc:      	mov	w8, #0x2964             // =10596
     c00:      	add	x20, x22, #0xff6
     c04:      	strh	w8, [x22, #0xffe]
     c08:      	adrp	x8, 0x0 <execve_rate>
     c0c:      	add	x8, x8, #0x0
     c10:      	ldr	x8, [x8]
     c14:      	str	x8, [x20]
     c18:      	b	0x3d4 <execve_send+0x134>
     c1c:      	str	w20, [sp, #0x90]
     c20:      	mov	x3, xzr
     c24:      	mov	w8, #0x2                // =2
     c28:      	add	x9, sp, #0x40
     c2c:      	add	x10, sp, #0x90
     c30:      	add	x1, sp, #0x40
     c34:      	add	x2, sp, #0x90
     c38:      	mov	x0, x25
     c3c:      	blr	x8
     c40:      	mov	x25, x23
     c44:      	adrp	x23, 0x0 <execve_rate>
     c48:      	ldr	x23, [x23]
     c4c:      	cmp	w21, #0x0
     c50:      	add	x0, x22, #0x170
     c54:      	csel	w8, w24, w21, eq
     c58:      	cmp	w24, #0x7f
     c5c:      	str	w8, [x22, #0x68]
     c60:      	mov	w8, #0x7f               // =127
     c64:      	csel	w1, w24, w8, lo
     c68:      	mov	w8, #0x17c0             // =6080
     c6c:      	add	x2, x25, x8
     c70:      	mov	w8, #0x4                // =4
     c74:      	blr	x8
     c78:      	cbz	x0, 0xcf0 <execve_send+0xa50>
     c7c:      	neg	w8, w0
     c80:      	adrp	x21, 0x0 <execve_rate>
     c84:      	mov	w9, #0x1                // =1
     c88:      	strh	w8, [sp, #0x40]
     c8c:      	mov	w8, #0xf                // =15
     c90:      	add	x1, sp, #0x40
     c94:      	mov	w20, #0x1               // =1
     c98:      	strh	w8, [sp, #0x42]
     c9c:      	mov	x8, #0x16a              // =362
     ca0:      	movk	x8, #0x4, lsl #32
     ca4:      	stur	x8, [sp, #0x44]
     ca8:      	add	x8, sp, #0x40
     cac:      	ldr	x21, [x21]
     cb0:      	mov	x0, x21
     cb4:      	blr	x9
     cb8:      	cbz	x0, 0xccc <execve_send+0xa2c>
     cbc:      	ldr	w8, [x0]
     cc0:      	add	w8, w8, #0x1
     cc4:      	str	w8, [x0]
     cc8:      	b	0xcf0 <execve_send+0xa50>
     ccc:      	str	w20, [sp, #0x90]
     cd0:      	mov	x3, xzr
     cd4:      	mov	w8, #0x2                // =2
     cd8:      	add	x9, sp, #0x40
     cdc:      	add	x10, sp, #0x90
     ce0:      	add	x1, sp, #0x40
     ce4:      	add	x2, sp, #0x90
     ce8:      	mov	x0, x21
     cec:      	blr	x8
     cf0:      	ldr	w9, [x25, #0x1848]
     cf4:      	ldr	w8, [x25, #0x184c]
     cf8:      	mov	w10, #0xfe              // =254
     cfc:      	add	x24, x22, #0x270
     d00:      	mov	x0, x24
     d04:      	cmp	w9, #0xfe
     d08:      	add	x2, x19, x8
     d0c:      	mov	w8, #0x4                // =4
     d10:      	csel	w21, w9, w10, lo
     d14:      	mov	w1, w21
     d18:      	blr	x8
     d1c:      	cbz	x0, 0xd9c <execve_send+0xafc>
     d20:      	neg	w8, w0
     d24:      	mov	x20, x25
     d28:      	adrp	x25, 0x0 <execve_rate>
     d2c:      	strh	w8, [sp, #0x40]
     d30:      	mov	w8, #0x9                // =9
     d34:      	mov	w9, #0x1                // =1
     d38:      	add	x1, sp, #0x40
     d3c:      	strh	w8, [sp, #0x42]
     d40:      	mov	x8, #0x1af              // =431
     d44:      	mov	w19, #0x1               // =1
     d48:      	movk	x8, #0x4, lsl #32
     d4c:      	stur	x8, [sp, #0x44]
     d50:      	add	x8, sp, #0x40
     d54:      	ldr	x25, [x25]
     d58:      	mov	x0, x25
     d5c:      	blr	x9
     d60:      	cbz	x0, 0xd74 <execve_send+0xad4>
     d64:      	ldr	w8, [x0]
     d68:      	add	w8, w8, #0x1
     d6c:      	str	w8, [x0]
     d70:      	b	0xd98 <execve_send+0xaf8>
     d74:      	str	w19, [sp, #0x90]
     d78:      	mov	x3, xzr
     d7c:      	mov	w8, #0x2                // =2
     d80:      	add	x9, sp, #0x40
     d84:      	add	x10, sp, #0x90
     d88:      	add	x1, sp, #0x40
     d8c:      	add	x2, sp, #0x90
     d90:      	mov	x0, x25
     d94:      	blr	x8
     d98:      	mov	x25, x20
     d9c:      	add	w8, w21, #0x1
     da0:      	strb	wzr, [x24, x21]
     da4:      	strb	wzr, [x24, w8, uxtw]
     da8:      	mov	w8, #0x23               // =35
     dac:      	blr	x8
     db0:      	str	x0, [sp, #0x40]
     db4:      	add	x8, x0, #0x8e0
     db8:      	mov	w9, #0x8                // =8
     dbc:      	mov	w10, #0x71              // =113
     dc0:      	add	x11, sp, #0x40
     dc4:      	add	x0, sp, #0x40
     dc8:      	mov	w1, #0x8                // =8
     dcc:      	ldr	x8, [sp, #0x40]
     dd0:      	add	x2, x8, #0x8e0
     dd4:      	blr	x10
     dd8:      	ldr	x8, [sp, #0x40]
     ddc:      	cbz	x8, 0xfb0 <execve_send+0xd10>
     de0:      	add	x8, x8, #0x8d4
     de4:      	mov	w9, #0x4                // =4
     de8:      	mov	w10, #0x71              // =113
     dec:      	add	x11, sp, #0xa8
     df0:      	ldr	x8, [sp, #0x40]
     df4:      	add	x0, sp, #0xa8
     df8:      	mov	w1, #0x4                // =4
     dfc:      	add	x2, x8, #0x8d4
     e00:      	blr	x10
     e04:      	ldr	w8, [sp, #0xa8]
     e08:      	add	x9, sp, #0x90
     e0c:      	add	x1, sp, #0x90
     e10:      	mov	x0, x23
     e14:      	str	w8, [sp, #0x90]
     e18:      	mov	w8, #0x1                // =1
     e1c:      	blr	x8
     e20:      	cbz	x0, 0xe2c <execve_send+0xb8c>
     e24:      	ldr	x8, [x0, #0x8]
     e28:      	cbnz	x8, 0xfa0 <execve_send+0xd00>
     e2c:      	ldr	x8, [sp, #0x40]
     e30:      	mov	w9, #0x8                // =8
     e34:      	mov	w10, #0x71              // =113
     e38:      	add	x11, sp, #0x40
     e3c:      	add	x0, sp, #0x40
     e40:      	mov	w1, #0x8                // =8
     e44:      	add	x8, x8, #0x8e0
     e48:      	ldr	x8, [sp, #0x40]
     e4c:      	add	x2, x8, #0x8e0
     e50:      	blr	x10
     e54:      	ldr	x8, [sp, #0x40]
     e58:      	cbz	x8, 0xfb0 <execve_send+0xd10>
     e5c:      	add	x8, x8, #0x8d4
     e60:      	mov	w9, #0x4                // =4
     e64:      	mov	w10, #0x71              // =113
     e68:      	add	x11, sp, #0xa8
     e6c:      	ldr	x8, [sp, #0x40]
     e70:      	add	x0, sp, #0xa8
     e74:      	mov	w1, #0x4                // =4
     e78:      	add	x2, x8, #0x8d4
     e7c:      	blr	x10
     e80:      	ldr	w8, [sp, #0xa8]
     e84:      	add	x9, sp, #0x90
     e88:      	add	x1, sp, #0x90
     e8c:      	mov	x0, x23
     e90:      	str	w8, [sp, #0x90]
     e94:      	mov	w8, #0x1                // =1
     e98:      	blr	x8
     e9c:      	cbz	x0, 0xea8 <execve_send+0xc08>
     ea0:      	ldr	x8, [x0, #0x8]
     ea4:      	cbnz	x8, 0xfa0 <execve_send+0xd00>
     ea8:      	ldr	x8, [sp, #0x40]
     eac:      	mov	w9, #0x8                // =8
     eb0:      	mov	w10, #0x71              // =113
     eb4:      	add	x11, sp, #0x40
     eb8:      	add	x0, sp, #0x40
     ebc:      	mov	w1, #0x8                // =8
     ec0:      	add	x8, x8, #0x8e0
     ec4:      	ldr	x8, [sp, #0x40]
     ec8:      	add	x2, x8, #0x8e0
     ecc:      	blr	x10
     ed0:      	ldr	x8, [sp, #0x40]
     ed4:      	cbz	x8, 0xfb0 <execve_send+0xd10>
     ed8:      	add	x8, x8, #0x8d4
     edc:      	mov	w9, #0x4                // =4
     ee0:      	mov	w10, #0x71              // =113
     ee4:      	add	x11, sp, #0xa8
     ee8:      	ldr	x8, [sp, #0x40]
     eec:      	add	x0, sp, #0xa8
     ef0:      	mov	w1, #0x4                // =4
     ef4:      	add	x2, x8, #0x8d4
     ef8:      	blr	x10
     efc:      	ldr	w8, [sp, #0xa8]
     f00:      	add	x9, sp, #0x90
     f04:      	add	x1, sp, #0x90
     f08:      	mov	x0, x23
     f0c:      	str	w8, [sp, #0x90]
     f10:      	mov	w8, #0x1                // =1
     f14:      	blr	x8
     f18:      	cbz	x0, 0xf24 <execve_send+0xc84>
     f1c:      	ldr	x8, [x0, #0x8]
     f20:      	cbnz	x8, 0xfa0 <execve_send+0xd00>
     f24:      	ldr	x8, [sp, #0x40]
     f28:      	mov	w9, #0x8                // =8
     f2c:      	mov	w10, #0x71              // =113
     f30:      	add	x11, sp, #0x40
     f34:      	add	x0, sp, #0x40
     f38:      	mov	w1, #0x8                // =8
     f3c:      	add	x8, x8, #0x8e0
     f40:      	ldr	x8, [sp, #0x40]
     f44:      	add	x2, x8, #0x8e0
     f48:      	blr	x10
     f4c:      	ldr	x8, [sp, #0x40]
     f50:      	cbz	x8, 0xfb0 <execve_send+0xd10>
     f54:      	add	x8, x8, #0x8d4
     f58:      	mov	w9, #0x4                // =4
     f5c:      	mov	w10, #0x71              // =113
     f60:      	add	x11, sp, #0xa8
     f64:      	ldr	x8, [sp, #0x40]
     f68:      	add	x0, sp, #0xa8
     f6c:      	mov	w1, #0x4                // =4
     f70:      	add	x2, x8, #0x8d4
     f74:      	blr	x10
     f78:      	ldr	w8, [sp, #0xa8]
     f7c:      	add	x9, sp, #0x90
     f80:      	add	x1, sp, #0x90
     f84:      	mov	x0, x23
     f88:      	str	w8, [sp, #0x90]
     f8c:      	mov	w8, #0x1                // =1
     f90:      	blr	x8
     f94:      	cbz	x0, 0xfb0 <execve_send+0xd10>
     f98:      	ldr	x8, [x0, #0x8]
     f9c:      	cbz	x8, 0xfb0 <execve_send+0xd10>
     fa0:      	ldr	x8, [x0, #0x370]
     fa4:      	ldr	x9, [x22, #0x370]
     fa8:      	orr	x8, x9, x8
     fac:      	str	x8, [x22, #0x370]
     fb0:      	adrp	x0, 0x0 <execve_rate>
     fb4:      	add	x1, x22, #0x70
     fb8:      	mov	w8, #0x1                // =1
     fbc:      	ldr	x0, [x0]
     fc0:      	blr	x8
     fc4:      	cbz	x0, 0xfd8 <execve_send+0xd38>
     fc8:      	ldr	x8, [x0]
     fcc:      	ldr	x9, [x22, #0x370]
     fd0:      	orr	x8, x9, x8
     fd4:      	str	x8, [x22, #0x370]
     fd8:      	ldr	w8, [x25, #0x140]
     fdc:      	strb	wzr, [x25, #0x1]
     fe0:      	mov	w9, #0x1710             // =5904
     fe4:      	adrp	x1, 0x0 <execve_rate>
     fe8:      	mov	x0, x29
     fec:      	mov	w2, #-0x1               // =-1
     ff0:      	mov	x3, x25
     ff4:      	ldr	x1, [x1]
     ff8:      	cmp	w8, w9
     ffc:      	csel	w8, w8, w9, lo
    1000:      	mov	w9, #0x19               // =25
    1004:      	add	w4, w8, #0x140
    1008:      	mov	w8, #-0x1               // =-1
    100c:      	blr	x9
    1010:      	tbz	x0, #0x3f, 0x10b8 <execve_send+0xe18>
    1014:      	mov	x19, x0
    1018:      	str	wzr, [sp, #0x40]
    101c:      	adrp	x0, 0x1000 <execve_send+0xd60>
    1020:      	mov	w8, #0x1                // =1
    1024:      	ldr	x0, [x0]
    1028:      	add	x9, sp, #0x40
    102c:      	add	x1, sp, #0x40
    1030:      	blr	x8
    1034:      	cbz	x0, 0x10b8 <execve_send+0xe18>
    1038:      	mov	x8, x19
    103c:      	cmn	x19, #0xc
    1040:      	b.gt	0x1064 <execve_send+0xdc4>
    1044:      	cmn	x8, #0x1c
    1048:      	b.eq	0x1084 <execve_send+0xde4>
    104c:      	cmn	x8, #0x16
    1050:      	b.eq	0x109c <execve_send+0xdfc>
    1054:      	cmn	x8, #0x10
    1058:      	b.ne	0x1094 <execve_send+0xdf4>
    105c:      	add	x8, x0, #0x130
    1060:      	b	0x10a8 <execve_send+0xe08>
    1064:      	cmn	x8, #0xb
    1068:      	b.eq	0x108c <execve_send+0xdec>
    106c:      	cmn	x8, #0x7
    1070:      	b.eq	0x10a4 <execve_send+0xe04>
    1074:      	cmn	x8, #0x2
    1078:      	b.ne	0x1094 <execve_send+0xdf4>
    107c:      	add	x8, x0, #0x120
    1080:      	b	0x10a8 <execve_send+0xe08>
    1084:      	add	x8, x0, #0x140
    1088:      	b	0x10a8 <execve_send+0xe08>
    108c:      	add	x8, x0, #0x148
    1090:      	b	0x10a8 <execve_send+0xe08>
    1094:      	add	x8, x0, #0x118
    1098:      	b	0x10a8 <execve_send+0xe08>
    109c:      	add	x8, x0, #0x138
    10a0:      	b	0x10a8 <execve_send+0xe08>
    10a4:      	add	x8, x0, #0x128
    10a8:      	ldaxr	x9, [x8]
    10ac:      	add	x9, x9, #0x1
    10b0:      	stlxr	w10, x9, [x8]
    10b4:      	cbnz	w10, 0x10a8 <execve_send+0xe08>
    10b8:      	ldp	x20, x19, [sp, #0xe0]
    10bc:      	mov	w0, wzr
    10c0:      	ldr	x29, [sp, #0xa0]
    10c4:      	ldp	x22, x21, [sp, #0xd0]
    10c8:      	ldp	x24, x23, [sp, #0xc0]
    10cc:      	ldp	x30, x25, [sp, #0xb0]
    10d0:      	add	sp, sp, #0xf0
    10d4:      	ret

Disassembly of section tracepoint/sys_execve:

0000000000000000 <event_execve>:
       0:      	sub	sp, sp, #0x120
       4:      	str	x29, [sp, #0xd0]
       8:      	stp	x30, x25, [sp, #0xe0]
       c:      	stp	x24, x23, [sp, #0xf0]
      10:      	stp	x22, x21, [sp, #0x100]
      14:      	stp	x20, x19, [sp, #0x110]
      18:      	mov	w8, #0x23               // =35
      1c:      	mov	x29, x0
      20:      	blr	x8
      24:      	mov	x25, x0
      28:      	str	wzr, [sp, #0x3c]
      2c:      	adrp	x0, 0x0 <event_execve>
      30:      	ldrh	w19, [x29, #0x8]
      34:      	mov	w8, #0x1                // =1
      38:      	add	x9, sp, #0x3c
      3c:      	ldr	x0, [x0]
      40:      	add	x1, sp, #0x3c
      44:      	blr	x8
      48:      	cbz	x0, 0x2330 <event_execve+0x2330>
      4c:      	mov	w8, #0xe                // =14
      50:      	mov	x20, x0
      54:      	blr	x8
      58:      	mov	w8, #0x23               // =35
      5c:      	mov	x22, x0
      60:      	blr	x8
      64:      	str	x0, [sp, #0x40]
      68:      	add	x8, x0, #0x8e0
      6c:      	mov	w9, #0x8                // =8
      70:      	mov	w10, #0x71              // =113
      74:      	add	x11, sp, #0x40
      78:      	add	x0, sp, #0x40
      7c:      	mov	w1, #0x8                // =8
      80:      	ldr	x8, [sp, #0x40]
      84:      	add	x2, x8, #0x8e0
      88:      	blr	x10
      8c:      	ldr	x8, [sp, #0x40]
      90:      	cbz	x8, 0x26c <event_execve+0x26c>
      94:      	add	x8, x8, #0x8d4
      98:      	mov	w9, #0x4                // =4
      9c:      	mov	w10, #0x71              // =113
      a0:      	add	x11, sp, #0xc8
      a4:      	ldr	x8, [sp, #0x40]
      a8:      	add	x0, sp, #0xc8
      ac:      	mov	w1, #0x4                // =4
      b0:      	add	x2, x8, #0x8d4
      b4:      	blr	x10
      b8:      	ldr	w8, [sp, #0xc8]
      bc:      	adrp	x23, 0x0 <event_execve>
      c0:      	add	x9, sp, #0xb8
      c4:      	add	x1, sp, #0xb8
      c8:      	str	w8, [sp, #0xb8]
      cc:      	mov	w8, #0x1                // =1
      d0:      	ldr	x23, [x23]
      d4:      	mov	x0, x23
      d8:      	blr	x8
      dc:      	cbz	x0, 0xe8 <event_execve+0xe8>
      e0:      	ldr	x8, [x0, #0x8]
      e4:      	cbnz	x8, 0x25c <event_execve+0x25c>
      e8:      	ldr	x8, [sp, #0x40]
      ec:      	mov	w9, #0x8                // =8
      f0:      	mov	w10, #0x71              // =113
      f4:      	add	x11, sp, #0x40
      f8:      	add	x0, sp, #0x40
      fc:      	mov	w1, #0x8                // =8
     100:      	add	x8, x8, #0x8e0
     104:      	ldr	x8, [sp, #0x40]
     108:      	add	x2, x8, #0x8e0
     10c:      	blr	x10
     110:      	ldr	x8, [sp, #0x40]
     114:      	cbz	x8, 0x26c <event_execve+0x26c>
     118:      	add	x8, x8, #0x8d4
     11c:      	mov	w9, #0x4                // =4
     120:      	mov	w10, #0x71              // =113
     124:      	add	x11, sp, #0xc8
     128:      	ldr	x8, [sp, #0x40]
     12c:      	add	x0, sp, #0xc8
     130:      	mov	w1, #0x4                // =4
     134:      	add	x2, x8, #0x8d4
     138:      	blr	x10
     13c:      	ldr	w8, [sp, #0xc8]
     140:      	add	x9, sp, #0xb8
     144:      	add	x1, sp, #0xb8
     148:      	mov	x0, x23
     14c:      	str	w8, [sp, #0xb8]
     150:      	mov	w8, #0x1                // =1
     154:      	blr	x8
     158:      	cbz	x0, 0x164 <event_execve+0x164>
     15c:      	ldr	x8, [x0, #0x8]
     160:      	cbnz	x8, 0x25c <event_execve+0x25c>
     164:      	ldr	x8, [sp, #0x40]
     168:      	mov	w9, #0x8                // =8
     16c:      	mov	w10, #0x71              // =113
     170:      	add	x11, sp, #0x40
     174:      	add	x0, sp, #0x40
     178:      	mov	w1, #0x8                // =8
     17c:      	add	x8, x8, #0x8e0
     180:      	ldr	x8, [sp, #0x40]
     184:      	add	x2, x8, #0x8e0
     188:      	blr	x10
     18c:      	ldr	x8, [sp, #0x40]
     190:      	cbz	x8, 0x26c <event_execve+0x26c>
     194:      	add	x8, x8, #0x8d4
     198:      	mov	w9, #0x4                // =4
     19c:      	mov	w10, #0x71              // =113
     1a0:      	add	x11, sp, #0xc8
     1a4:      	ldr	x8, [sp, #0x40]
     1a8:      	add	x0, sp, #0xc8
     1ac:      	mov	w1, #0x4                // =4
     1b0:      	add	x2, x8, #0x8d4
     1b4:      	blr	x10
     1b8:      	ldr	w8, [sp, #0xc8]
     1bc:      	add	x9, sp, #0xb8
     1c0:      	add	x1, sp, #0xb8
     1c4:      	mov	x0, x23
     1c8:      	str	w8, [sp, #0xb8]
     1cc:      	mov	w8, #0x1                // =1
     1d0:      	blr	x8
     1d4:      	cbz	x0, 0x1e0 <event_execve+0x1e0>
     1d8:      	ldr	x8, [x0, #0x8]
     1dc:      	cbnz	x8, 0x25c <event_execve+0x25c>
     1e0:      	ldr	x8, [sp, #0x40]
     1e4:      	mov	w9, #0x8                // =8
     1e8:      	mov	w10, #0x71              // =113
     1ec:      	add	x11, sp, #0x40
     1f0:      	add	x0, sp, #0x40
     1f4:      	mov	w1, #0x8                // =8
     1f8:      	add	x8, x8, #0x8e0
     1fc:      	ldr	x8, [sp, #0x40]
     200:      	add	x2, x8, #0x8e0
     204:      	blr	x10
     208:      	ldr	x8, [sp, #0x40]
     20c:      	cbz	x8, 0x26c <event_execve+0x26c>
     210:      	add	x8, x8, #0x8d4
     214:      	mov	w9, #0x4                // =4
     218:      	mov	w10, #0x71              // =113
     21c:      	add	x11, sp, #0xc8
     220:      	ldr	x8, [sp, #0x40]
     224:      	add	x0, sp, #0xc8
     228:      	mov	w1, #0x4                // =4
     22c:      	add	x2, x8, #0x8d4
     230:      	blr	x10
     234:      	ldr	w8, [sp, #0xc8]
     238:      	add	x9, sp, #0xb8
     23c:      	add	x1, sp, #0xb8
     240:      	mov	x0, x23
     244:      	str	w8, [sp, #0xb8]
     248:      	mov	w8, #0x1                // =1
     24c:      	blr	x8
     250:      	cbz	x0, 0x26c <event_execve+0x26c>
     254:      	ldr	x8, [x0, #0x8]
     258:      	cbz	x8, 0x26c <event_execve+0x26c>
     25c:      	ldp	x9, x10, [x0]
     260:      	mov	x8, xzr
     264:      	stp	x9, x10, [x20, #0xa0]
     268:      	b	0x2bc <event_execve+0x2bc>
     26c:      	add	x2, x25, #0x8e0
     270:      	mov	w8, #0x8                // =8
     274:      	mov	w9, #0x71               // =113
     278:      	add	x10, sp, #0x40
     27c:      	add	x0, sp, #0x40
     280:      	mov	w1, #0x8                // =8
     284:      	blr	x9
     288:      	ldr	x8, [sp, #0x40]
     28c:      	cbz	x8, 0x2b0 <event_execve+0x2b0>
     290:      	add	x2, x8, #0x8d4
     294:      	mov	w8, #0x4                // =4
     298:      	mov	w9, #0x71               // =113
     29c:      	add	x10, sp, #0x40
     2a0:      	add	x0, sp, #0x40
     2a4:      	mov	w1, #0x4                // =4
     2a8:      	blr	x9
     2ac:      	ldr	w8, [sp, #0x40]
     2b0:      	str	w8, [x20, #0xa0]
     2b4:      	mov	w8, #0x40               // =64
     2b8:      	str	xzr, [x20, #0xa8]
     2bc:      	str	x8, [x20, #0xb0]
     2c0:      	mov	w8, #0x1                // =1
     2c4:      	str	xzr, [x20, #0x178]
     2c8:      	str	w22, [x20, #0x148]
     2cc:      	str	w8, [x20, #0x15c]
     2d0:      	lsr	x8, x22, #32
     2d4:      	str	w8, [x20, #0x144]
     2d8:      	mov	w8, #0x23               // =35
     2dc:      	blr	x8
     2e0:      	add	x2, x0, #0x60
     2e4:      	mov	w8, #0x8                // =8
     2e8:      	mov	w9, #0x71               // =113
     2ec:      	add	x10, sp, #0xb8
     2f0:      	add	x0, sp, #0xb8
     2f4:      	mov	w1, #0x8                // =8
     2f8:      	blr	x9
     2fc:      	ldr	x8, [sp, #0xb8]
     300:      	cbz	x8, 0x370 <event_execve+0x370>
     304:      	add	x8, x8, #0x4
     308:      	mov	w9, #0x4                // =4
     30c:      	mov	w10, #0x71              // =113
     310:      	add	x11, sp, #0xc8
     314:      	ldr	x8, [sp, #0xb8]
     318:      	add	x0, sp, #0xc8
     31c:      	mov	w1, #0x4                // =4
     320:      	add	x2, x8, #0x4
     324:      	blr	x10
     328:      	ldr	w8, [sp, #0xc8]
     32c:      	cbz	w8, 0x370 <event_execve+0x370>
     330:      	ldr	x9, [sp, #0xb8]
     334:      	lsl	w8, w8, #4
     338:      	mov	w10, #0x71              // =113
     33c:      	add	x11, sp, #0x40
     340:      	add	x0, sp, #0x40
     344:      	mov	w1, #0x10               // =16
     348:      	add	x8, x9, x8
     34c:      	mov	w9, #0x10               // =16
     350:      	add	x8, x8, #0x80
     354:      	ldr	w9, [sp, #0xc8]
     358:      	ldr	x8, [sp, #0xb8]
     35c:      	lsl	w9, w9, #4
     360:      	add	x8, x8, x9
     364:      	add	x2, x8, #0x80
     368:      	blr	x10
     36c:      	ldr	w8, [sp, #0x40]
     370:      	str	w8, [x20, #0x14c]
     374:      	mov	w8, #0x7d               // =125
     378:      	add	x23, x29, x19
     37c:      	blr	x8
     380:      	mov	w8, #0x40               // =64
     384:      	str	x0, [x20, #0x170]
     388:      	str	w8, [x20, #0x140]
     38c:      	mov	w8, #0x23               // =35
     390:      	blr	x8
     394:      	str	xzr, [sp, #0x40]
     398:      	cbz	x0, 0x3c0 <event_execve+0x3c0>
     39c:      	add	x2, x0, #0x70
     3a0:      	mov	w8, #0x8                // =8
     3a4:      	mov	w9, #0x4                // =4
     3a8:      	add	x10, sp, #0x40
     3ac:      	add	x0, sp, #0x40
     3b0:      	mov	w1, #0x8                // =8
     3b4:      	blr	x9
     3b8:      	ldr	x8, [sp, #0x40]
     3bc:      	b	0x3c4 <event_execve+0x3c4>
     3c0:      	mov	x8, xzr
     3c4:      	str	w8, [x20, #0x158]
     3c8:      	str	x22, [sp, #0x40]
     3cc:      	adrp	x21, 0x0 <event_execve>
     3d0:      	mov	w8, #0x1                // =1
     3d4:      	add	x9, sp, #0x40
     3d8:      	add	x1, sp, #0x40
     3dc:      	ldr	x21, [x21]
     3e0:      	mov	x0, x21
     3e4:      	blr	x8
     3e8:      	cbz	x0, 0x450 <event_execve+0x450>
     3ec:      	ldr	w8, [x0]
     3f0:      	add	x9, sp, #0x40
     3f4:      	add	x1, sp, #0x40
     3f8:      	str	w8, [x20, #0x150]
     3fc:      	ldr	x8, [x0, #0x8]
     400:      	str	x8, [x20, #0x168]
     404:      	ldr	w8, [x0, #0x4]
     408:      	str	x22, [sp, #0x40]
     40c:      	mov	x0, x21
     410:      	str	w8, [x20, #0x160]
     414:      	mov	w8, #0x3                // =3
     418:      	blr	x8
     41c:      	cbz	w0, 0x460 <event_execve+0x460>
     420:      	mov	w8, #0x2                // =2
     424:      	adrp	x0, 0x0 <event_execve>
     428:      	add	x9, sp, #0xb8
     42c:      	str	w8, [sp, #0xb8]
     430:      	mov	w8, #0x1                // =1
     434:      	add	x1, sp, #0xb8
     438:      	ldr	x0, [x0]
     43c:      	blr	x8
     440:      	cbz	x0, 0x48c <event_execve+0x48c>
     444:      	ldr	x8, [x0]
     448:      	add	x8, x8, #0x1
     44c:      	b	0x488 <event_execve+0x488>
     450:      	str	wzr, [x20, #0x150]
     454:      	str	xzr, [x20, #0x168]
     458:      	str	wzr, [x20, #0x160]
     45c:      	b	0x48c <event_execve+0x48c>
     460:      	str	wzr, [sp, #0xb8]
     464:      	adrp	x0, 0x0 <event_execve>
     468:      	mov	w8, #0x1                // =1
     46c:      	add	x9, sp, #0xb8
     470:      	ldr	x0, [x0]
     474:      	add	x1, sp, #0xb8
     478:      	blr	x8
     47c:      	cbz	x0, 0x48c <event_execve+0x48c>
     480:      	ldr	x8, [x0]
     484:      	sub	x8, x8, #0x1
     488:      	str	x8, [x0]
     48c:      	add	x0, x20, #0x180
     490:      	mov	w8, #0xff               // =255
     494:      	mov	w9, #0x2d               // =45
     498:      	mov	w1, #0xff               // =255
     49c:      	mov	x2, x23
     4a0:      	blr	x9
     4a4:      	tbnz	w0, #0x1f, 0x5e4 <event_execve+0x5e4>
     4a8:      	cbz	w0, 0x5f0 <event_execve+0x5f0>
     4ac:      	cmp	w0, #0xff
     4b0:      	b.ne	0x5f8 <event_execve+0x5f8>
     4b4:      	str	wzr, [sp, #0xb8]
     4b8:      	adrp	x0, 0x0 <event_execve>
     4bc:      	mov	w8, #0x1                // =1
     4c0:      	add	x9, sp, #0xb8
     4c4:      	ldr	x0, [x0]
     4c8:      	add	x1, sp, #0xb8
     4cc:      	blr	x8
     4d0:      	cbz	x0, 0x5e4 <event_execve+0x5e4>
     4d4:      	mov	w8, #0x18               // =24
     4d8:      	mov	x22, x0
     4dc:      	mov	x21, x25
     4e0:      	str	w8, [x0]
     4e4:      	mov	w8, #0xe                // =14
     4e8:      	blr	x8
     4ec:      	mov	x19, x22
     4f0:      	cmn	x0, #0x16
     4f4:      	str	x0, [x19, #0x10]!
     4f8:      	b.ne	0x520 <event_execve+0x520>
     4fc:      	add	x2, x29, #0xe8
     500:      	mov	w8, #0x8                // =8
     504:      	mov	w9, #0x4                // =4
     508:      	add	x10, sp, #0x40
     50c:      	add	x0, sp, #0x40
     510:      	mov	w1, #0x8                // =8
     514:      	blr	x9
     518:      	ldr	x8, [sp, #0x40]
     51c:      	str	x8, [x19]
     520:      	mov	w8, #0x7d               // =125
     524:      	mov	x24, x29
     528:      	blr	x8
     52c:      	str	x0, [x22, #0x18]
     530:      	add	x25, x22, #0x20
     534:      	mov	w1, #0x7fdf             // =32735
     538:      	mov	x2, x23
     53c:      	ldp	x8, x9, [x19]
     540:      	mov	x0, x25
     544:      	stp	x8, x9, [x20, #0x190]
     548:      	mov	w8, #0x7fdf             // =32735
     54c:      	mov	w9, #0x2d               // =45
     550:      	blr	x9
     554:      	mov	x29, x0
     558:      	tbnz	x0, #0x3f, 0x604 <event_execve+0x604>
     55c:      	cbz	x29, 0x60c <event_execve+0x60c>
     560:      	add	w8, w29, #0x1f
     564:      	adrp	x1, 0x0 <event_execve>
     568:      	mov	w9, #0x19               // =25
     56c:      	mov	x0, x24
     570:      	mov	w2, #-0x1               // =-1
     574:      	mov	x3, x22
     578:      	sub	x19, x29, #0x1
     57c:      	and	x4, x8, #0x7fff
     580:      	str	w4, [x22, #0x4]
     584:      	mov	w8, #-0x1               // =-1
     588:      	ldr	x1, [x1]
     58c:      	blr	x9
     590:      	tbz	x0, #0x3f, 0x674 <event_execve+0x674>
     594:      	str	x0, [sp, #0xd8]
     598:      	str	wzr, [sp, #0x40]
     59c:      	adrp	x0, 0x0 <event_execve>
     5a0:      	mov	w8, #0x1                // =1
     5a4:      	add	x9, sp, #0x40
     5a8:      	add	x1, sp, #0x40
     5ac:      	ldr	x0, [x0]
     5b0:      	blr	x8
     5b4:      	cbz	x0, 0x674 <event_execve+0x674>
     5b8:      	ldr	x8, [sp, #0xd8]
     5bc:      	cmn	x8, #0xc
     5c0:      	b.gt	0x620 <event_execve+0x620>
     5c4:      	cmn	x8, #0x1c
     5c8:      	b.eq	0x640 <event_execve+0x640>
     5cc:      	cmn	x8, #0x16
     5d0:      	b.eq	0x658 <event_execve+0x658>
     5d4:      	cmn	x8, #0x10
     5d8:      	b.ne	0x650 <event_execve+0x650>
     5dc:      	add	x8, x0, #0x558
     5e0:      	b	0x664 <event_execve+0x664>
     5e4:      	mov	w8, wzr
     5e8:      	mov	w0, #0x100              // =256
     5ec:      	b	0x758 <event_execve+0x758>
     5f0:      	mov	w8, w0
     5f4:      	b	0x758 <event_execve+0x758>
     5f8:      	sub	w8, w0, #0x1
     5fc:      	mov	w0, wzr
     600:      	b	0x758 <event_execve+0x758>
     604:      	mov	x19, x29
     608:      	b	0x72c <event_execve+0x72c>
     60c:      	mov	w9, wzr
     610:      	mov	w8, wzr
     614:      	mov	x29, x24
     618:      	mov	x25, x21
     61c:      	b	0x740 <event_execve+0x740>
     620:      	cmn	x8, #0xb
     624:      	b.eq	0x648 <event_execve+0x648>
     628:      	cmn	x8, #0x7
     62c:      	b.eq	0x660 <event_execve+0x660>
     630:      	cmn	x8, #0x2
     634:      	b.ne	0x650 <event_execve+0x650>
     638:      	add	x8, x0, #0x548
     63c:      	b	0x664 <event_execve+0x664>
     640:      	add	x8, x0, #0x568
     644:      	b	0x664 <event_execve+0x664>
     648:      	add	x8, x0, #0x570
     64c:      	b	0x664 <event_execve+0x664>
     650:      	add	x8, x0, #0x540
     654:      	b	0x664 <event_execve+0x664>
     658:      	add	x8, x0, #0x560
     65c:      	b	0x664 <event_execve+0x664>
     660:      	add	x8, x0, #0x550
     664:      	ldaxr	x9, [x8]
     668:      	add	x9, x9, #0x1
     66c:      	stlxr	w10, x9, [x8]
     670:      	cbnz	w10, 0x664 <event_execve+0x664>
     674:      	mov	w8, #0x7fdf             // =32735
     678:      	cmp	x29, x8
     67c:      	b.ne	0x72c <event_execve+0x72c>
     680:      	add	x2, x19, x23
     684:      	mov	w8, #0x7fdf             // =32735
     688:      	mov	w9, #0x2d               // =45
     68c:      	mov	x0, x25
     690:      	mov	w1, #0x7fdf             // =32735
     694:      	blr	x9
     698:      	mov	x29, x24
     69c:      	tbnz	x0, #0x3f, 0x1318 <event_execve+0x1318>
     6a0:      	mov	x25, x21
     6a4:      	cbz	x0, 0x734 <event_execve+0x734>
     6a8:      	add	w8, w0, #0x1f
     6ac:      	adrp	x1, 0x0 <event_execve>
     6b0:      	mov	w9, #0x19               // =25
     6b4:      	sub	x21, x0, #0x1
     6b8:      	mov	x0, x29
     6bc:      	mov	w2, #-0x1               // =-1
     6c0:      	mov	x3, x22
     6c4:      	and	x4, x8, #0x7fff
     6c8:      	str	w4, [x22, #0x4]
     6cc:      	mov	w8, #-0x1               // =-1
     6d0:      	ldr	x1, [x1]
     6d4:      	blr	x9
     6d8:      	tbz	x0, #0x3f, 0x1444 <event_execve+0x1444>
     6dc:      	mov	x22, x0
     6e0:      	str	wzr, [sp, #0x40]
     6e4:      	adrp	x0, 0x0 <event_execve>
     6e8:      	mov	w8, #0x1                // =1
     6ec:      	ldr	x0, [x0]
     6f0:      	add	x9, sp, #0x40
     6f4:      	add	x1, sp, #0x40
     6f8:      	blr	x8
     6fc:      	cbz	x0, 0x1444 <event_execve+0x1444>
     700:      	mov	x8, x22
     704:      	cmn	x22, #0xc
     708:      	b.gt	0x13f0 <event_execve+0x13f0>
     70c:      	cmn	x8, #0x1c
     710:      	b.eq	0x1410 <event_execve+0x1410>
     714:      	cmn	x8, #0x16
     718:      	b.eq	0x1428 <event_execve+0x1428>
     71c:      	cmn	x8, #0x10
     720:      	b.ne	0x1420 <event_execve+0x1420>
     724:      	add	x8, x0, #0x558
     728:      	b	0x1434 <event_execve+0x1434>
     72c:      	mov	x29, x24
     730:      	mov	x25, x21
     734:      	asr	w8, w19, #31
     738:      	and	w9, w19, w8
     73c:      	bic	w8, w19, w8
     740:      	str	w9, [x20, #0x180]
     744:      	add	x9, x20, #0x184
     748:      	str	w8, [x20, #0x18c]
     74c:      	mov	w8, #0x20               // =32
     750:      	mov	w0, #0x800000           // =8388608
     754:      	str	xzr, [x9]
     758:      	ldr	w9, [x20, #0x15c]
     75c:      	strh	w8, [x20, #0x178]
     760:      	orr	w9, w9, w0
     764:      	str	w9, [x20, #0x15c]
     768:      	ldr	w9, [x20, #0x140]
     76c:      	add	w8, w9, w8
     770:      	str	w8, [x20, #0x140]
     774:      	mov	w8, #0x23               // =35
     778:      	blr	x8
     77c:      	str	wzr, [sp, #0xa0]
     780:      	add	x2, x0, #0x858
     784:      	mov	w8, #0x8                // =8
     788:      	mov	w9, #0x4                // =4
     78c:      	add	x10, sp, #0xb0
     790:      	add	x0, sp, #0xb0
     794:      	mov	w1, #0x8                // =8
     798:      	blr	x9
     79c:      	adrp	x23, 0x0 <event_execve>
     7a0:      	ldr	x23, [x23]
     7a4:      	cbz	x0, 0x7ec <event_execve+0x7ec>
     7a8:      	neg	w8, w0
     7ac:      	mov	w9, #0x1                // =1
     7b0:      	add	x1, sp, #0x40
     7b4:      	strh	w8, [sp, #0x40]
     7b8:      	mov	w8, #0x9                // =9
     7bc:      	mov	x0, x23
     7c0:      	mov	w19, #0x1               // =1
     7c4:      	strh	w8, [sp, #0x42]
     7c8:      	mov	x8, #0x42               // =66
     7cc:      	movk	x8, #0x4, lsl #32
     7d0:      	stur	x8, [sp, #0x44]
     7d4:      	add	x8, sp, #0x40
     7d8:      	blr	x9
     7dc:      	cbz	x0, 0x86c <event_execve+0x86c>
     7e0:      	ldr	w8, [x0]
     7e4:      	add	w8, w8, #0x1
     7e8:      	str	w8, [x0]
     7ec:      	ldr	x8, [sp, #0xb0]
     7f0:      	add	x22, x20, #0x140
     7f4:      	add	x24, sp, #0xb8
     7f8:      	cbz	x8, 0xa44 <event_execve+0xa44>
     7fc:      	add	x8, x8, #0x278
     800:      	mov	w9, #0x8                // =8
     804:      	mov	w10, #0x4               // =4
     808:      	add	x11, sp, #0xb8
     80c:      	ldr	x8, [sp, #0xb0]
     810:      	add	x0, sp, #0xb8
     814:      	mov	w1, #0x8                // =8
     818:      	add	x2, x8, #0x278
     81c:      	blr	x10
     820:      	cbz	x0, 0x8c8 <event_execve+0x8c8>
     824:      	neg	w8, w0
     828:      	mov	w9, #0x1                // =1
     82c:      	add	x1, sp, #0x40
     830:      	strh	w8, [sp, #0x40]
     834:      	mov	w8, #0x9                // =9
     838:      	mov	x0, x23
     83c:      	mov	w19, #0x1               // =1
     840:      	strh	w8, [sp, #0x42]
     844:      	mov	x8, #0x47               // =71
     848:      	movk	x8, #0x4, lsl #32
     84c:      	stur	x8, [sp, #0x44]
     850:      	add	x8, sp, #0x40
     854:      	blr	x9
     858:      	cbz	x0, 0x8a4 <event_execve+0x8a4>
     85c:      	ldr	w8, [x0]
     860:      	add	w8, w8, #0x1
     864:      	str	w8, [x0]
     868:      	b	0x8c8 <event_execve+0x8c8>
     86c:      	str	w19, [sp, #0xb8]
     870:      	mov	x3, xzr
     874:      	mov	w8, #0x2                // =2
     878:      	add	x9, sp, #0x40
     87c:      	add	x10, sp, #0xb8
     880:      	add	x1, sp, #0x40
     884:      	add	x2, sp, #0xb8
     888:      	mov	x0, x23
     88c:      	blr	x8
     890:      	ldr	x8, [sp, #0xb0]
     894:      	add	x22, x20, #0x140
     898:      	add	x24, sp, #0xb8
     89c:      	cbnz	x8, 0x7fc <event_execve+0x7fc>
     8a0:      	b	0xa44 <event_execve+0xa44>
     8a4:      	str	w19, [sp, #0xc8]
     8a8:      	mov	x3, xzr
     8ac:      	mov	w8, #0x2                // =2
     8b0:      	add	x9, sp, #0x40
     8b4:      	add	x10, sp, #0xc8
     8b8:      	add	x1, sp, #0x40
     8bc:      	add	x2, sp, #0xc8
     8c0:      	mov	x0, x23
     8c4:      	blr	x8
     8c8:      	ldr	x8, [sp, #0xb0]
     8cc:      	mov	w9, #0x8                // =8
     8d0:      	mov	w10, #0x4               // =4
     8d4:      	add	x11, sp, #0xc8
     8d8:      	add	x0, sp, #0xc8
     8dc:      	mov	w1, #0x8                // =8
     8e0:      	add	x8, x8, #0x280
     8e4:      	ldr	x8, [sp, #0xb0]
     8e8:      	add	x2, x8, #0x280
     8ec:      	blr	x10
     8f0:      	cbz	x0, 0x938 <event_execve+0x938>
     8f4:      	neg	w8, w0
     8f8:      	mov	w9, #0x1                // =1
     8fc:      	add	x1, sp, #0x40
     900:      	strh	w8, [sp, #0x40]
     904:      	mov	w8, #0x9                // =9
     908:      	mov	x0, x23
     90c:      	mov	w19, #0x1               // =1
     910:      	strh	w8, [sp, #0x42]
     914:      	mov	x8, #0x48               // =72
     918:      	movk	x8, #0x4, lsl #32
     91c:      	stur	x8, [sp, #0x44]
     920:      	add	x8, sp, #0x40
     924:      	blr	x9
     928:      	cbz	x0, 0xa64 <event_execve+0xa64>
     92c:      	ldr	w8, [x0]
     930:      	add	w8, w8, #0x1
     934:      	str	w8, [x0]
     938:      	ldr	x8, [sp, #0xb8]
     93c:      	mov	w21, wzr
     940:      	cbz	x8, 0xa9c <event_execve+0xa9c>
     944:      	ldr	x8, [x24, #0x10]
     948:      	cbz	x8, 0xa9c <event_execve+0xa9c>
     94c:      	adrp	x0, 0x0 <event_execve>
     950:      	mov	w8, #0x1                // =1
     954:      	add	x9, sp, #0xa0
     958:      	ldr	x0, [x0]
     95c:      	add	x1, sp, #0xa0
     960:      	blr	x8
     964:      	cbz	x0, 0xa44 <event_execve+0xa44>
     968:      	ldr	x8, [sp, #0xb8]
     96c:      	mov	w9, #0x1000             // =4096
     970:      	mov	w10, #0x2d              // =45
     974:      	mov	w1, #0x1000             // =4096
     978:      	ldr	x2, [sp, #0xb8]
     97c:      	blr	x10
     980:      	tbnz	x0, #0x3f, 0xa98 <event_execve+0xa98>
     984:      	ldr	x8, [sp, #0xb8]
     988:      	str	x25, [sp, #0x30]
     98c:      	add	x19, x8, x0
     990:      	ldr	w8, [x20, #0x140]
     994:      	str	x22, [sp, #0xd8]
     998:      	and	x8, x8, #0x1ff
     99c:      	str	x19, [sp, #0xb8]
     9a0:      	add	x21, x20, x8
     9a4:      	str	w8, [x20, #0x184c]
     9a8:      	ldr	x8, [x24, #0x10]
     9ac:      	sub	x25, x8, x19
     9b0:      	cmp	x25, #0x3ff
     9b4:      	b.hi	0x1158 <event_execve+0x1158>
     9b8:      	add	x9, x20, #0x140
     9bc:      	add	x0, x21, #0x140
     9c0:      	sub	x9, x9, x0
     9c4:      	add	x9, x9, #0x400
     9c8:      	cmp	x25, x9
     9cc:      	b.hs	0x1158 <event_execve+0x1158>
     9d0:      	sub	w9, w25, #0x1
     9d4:      	cmp	x8, x19
     9d8:      	mov	w8, #0x4                // =4
     9dc:      	and	w9, w9, #0x3ff
     9e0:      	csel	w21, wzr, w9, eq
     9e4:      	ldr	x2, [sp, #0xb8]
     9e8:      	mov	w1, w21
     9ec:      	blr	x8
     9f0:      	cbz	x0, 0x1280 <event_execve+0x1280>
     9f4:      	mov	x22, x0
     9f8:      	mov	w9, #0x1                // =1
     9fc:      	add	x1, sp, #0x40
     a00:      	mov	x0, x23
     a04:      	mov	w19, #0x1               // =1
     a08:      	neg	w8, w22
     a0c:      	strh	w8, [sp, #0x40]
     a10:      	mov	w8, #0x9                // =9
     a14:      	strh	w8, [sp, #0x42]
     a18:      	mov	x8, #0x6c               // =108
     a1c:      	movk	x8, #0x4, lsl #32
     a20:      	stur	x8, [sp, #0x44]
     a24:      	add	x8, sp, #0x40
     a28:      	blr	x9
     a2c:      	ldr	x25, [sp, #0x30]
     a30:      	cbz	x0, 0x1288 <event_execve+0x1288>
     a34:      	ldr	w8, [x0]
     a38:      	add	w8, w8, #0x1
     a3c:      	str	w8, [x0]
     a40:      	b	0x12ac <event_execve+0x12ac>
     a44:      	mov	w21, wzr
     a48:      	ldr	w8, [x20, #0x140]
     a4c:      	add	w21, w8, w21
     a50:      	ldrb	w8, [x20, #0x15d]
     a54:      	str	w21, [x20, #0x140]
     a58:      	tbz	w8, #0x5, 0xab0 <event_execve+0xab0>
     a5c:      	mov	w8, wzr
     a60:      	b	0x1874 <event_execve+0x1874>
     a64:      	str	w19, [sp, #0xa8]
     a68:      	mov	x3, xzr
     a6c:      	mov	w8, #0x2                // =2
     a70:      	add	x9, sp, #0x40
     a74:      	add	x10, sp, #0xa8
     a78:      	add	x1, sp, #0x40
     a7c:      	add	x2, sp, #0xa8
     a80:      	mov	x0, x23
     a84:      	blr	x8
     a88:      	ldr	x8, [sp, #0xb8]
     a8c:      	mov	w21, wzr
     a90:      	cbnz	x8, 0x944 <event_execve+0x944>
     a94:      	b	0xa9c <event_execve+0xa9c>
     a98:      	mov	w21, wzr
     a9c:      	ldr	w8, [x20, #0x140]
     aa0:      	add	w21, w8, w21
     aa4:      	ldrb	w8, [x20, #0x15d]
     aa8:      	str	w21, [x20, #0x140]
     aac:      	tbnz	w8, #0x5, 0xa5c <event_execve+0xa5c>
     ab0:      	ldr	w19, [x20, #0x144]
     ab4:      	mov	w8, #0x23               // =35
     ab8:      	blr	x8
     abc:      	mov	x23, x0
     ac0:      	str	wzr, [sp, #0xb8]
     ac4:      	str	x22, [sp, #0xd8]
     ac8:      	str	w21, [sp, #0x1c]
     acc:      	cbz	x0, 0x1458 <event_execve+0x1458>
     ad0:      	add	x2, x23, #0x8d4
     ad4:      	mov	w8, #0x4                // =4
     ad8:      	mov	w9, #0x71               // =113
     adc:      	add	x10, sp, #0xb8
     ae0:      	add	x0, sp, #0xb8
     ae4:      	mov	w1, #0x4                // =4
     ae8:      	blr	x9
     aec:      	ldr	w8, [sp, #0xb8]
     af0:      	cmp	w8, w19
     af4:      	b.eq	0x1458 <event_execve+0x1458>
     af8:      	add	x2, x23, #0x8e0
     afc:      	mov	w8, #0x8                // =8
     b00:      	mov	w9, #0x71               // =113
     b04:      	add	x10, sp, #0x40
     b08:      	add	x0, sp, #0x40
     b0c:      	mov	w1, #0x8                // =8
     b10:      	blr	x9
     b14:      	ldr	x23, [sp, #0x40]
     b18:      	cbz	x23, 0x1458 <event_execve+0x1458>
     b1c:      	add	x2, x23, #0x8d4
     b20:      	mov	w8, #0x4                // =4
     b24:      	mov	w9, #0x71               // =113
     b28:      	add	x10, sp, #0xb8
     b2c:      	add	x0, sp, #0xb8
     b30:      	mov	w1, #0x4                // =4
     b34:      	blr	x9
     b38:      	ldr	w8, [sp, #0xb8]
     b3c:      	cmp	w8, w19
     b40:      	b.eq	0x1458 <event_execve+0x1458>
     b44:      	add	x2, x23, #0x8e0
     b48:      	mov	w8, #0x8                // =8
     b4c:      	mov	w9, #0x71               // =113
     b50:      	add	x10, sp, #0x40
     b54:      	add	x0, sp, #0x40
     b58:      	mov	w1, #0x8                // =8
     b5c:      	blr	x9
     b60:      	ldr	x23, [sp, #0x40]
     b64:      	cbz	x23, 0x1458 <event_execve+0x1458>
     b68:      	add	x2, x23, #0x8d4
     b6c:      	mov	w8, #0x4                // =4
     b70:      	mov	w9, #0x71               // =113
     b74:      	add	x10, sp, #0xb8
     b78:      	add	x0, sp, #0xb8
     b7c:      	mov	w1, #0x4                // =4
     b80:      	blr	x9
     b84:      	ldr	w8, [sp, #0xb8]
     b88:      	cmp	w8, w19
     b8c:      	b.eq	0x1458 <event_execve+0x1458>
     b90:      	add	x2, x23, #0x8e0
     b94:      	mov	w8, #0x8                // =8
     b98:      	mov	w9, #0x71               // =113
     b9c:      	add	x10, sp, #0x40
     ba0:      	add	x0, sp, #0x40
     ba4:      	mov	w1, #0x8                // =8
     ba8:      	blr	x9
     bac:      	ldr	x23, [sp, #0x40]
     bb0:      	cbz	x23, 0x1458 <event_execve+0x1458>
     bb4:      	add	x2, x23, #0x8d4
     bb8:      	mov	w8, #0x4                // =4
     bbc:      	mov	w9, #0x71               // =113
     bc0:      	add	x10, sp, #0xb8
     bc4:      	add	x0, sp, #0xb8
     bc8:      	mov	w1, #0x4                // =4
     bcc:      	blr	x9
     bd0:      	ldr	w8, [sp, #0xb8]
     bd4:      	cmp	w8, w19
     bd8:      	b.eq	0x1458 <event_execve+0x1458>
     bdc:      	add	x2, x23, #0x8e0
     be0:      	mov	w8, #0x8                // =8
     be4:      	mov	w9, #0x71               // =113
     be8:      	add	x10, sp, #0x40
     bec:      	add	x0, sp, #0x40
     bf0:      	mov	w1, #0x8                // =8
     bf4:      	blr	x9
     bf8:      	ldr	x23, [sp, #0x40]
     bfc:      	cbz	x23, 0x1458 <event_execve+0x1458>
     c00:      	add	x2, x23, #0x8d4
     c04:      	mov	w8, #0x4                // =4
     c08:      	mov	w9, #0x71               // =113
     c0c:      	add	x10, sp, #0xb8
     c10:      	add	x0, sp, #0xb8
     c14:      	mov	w1, #0x4                // =4
     c18:      	blr	x9
     c1c:      	ldr	w8, [sp, #0xb8]
     c20:      	cmp	w8, w19
     c24:      	b.eq	0x1458 <event_execve+0x1458>
     c28:      	add	x2, x23, #0x8e0
     c2c:      	mov	w8, #0x8                // =8
     c30:      	mov	w9, #0x71               // =113
     c34:      	add	x10, sp, #0x40
     c38:      	add	x0, sp, #0x40
     c3c:      	mov	w1, #0x8                // =8
     c40:      	blr	x9
     c44:      	ldr	x23, [sp, #0x40]
     c48:      	cbz	x23, 0x1458 <event_execve+0x1458>
     c4c:      	add	x2, x23, #0x8d4
     c50:      	mov	w8, #0x4                // =4
     c54:      	mov	w9, #0x71               // =113
     c58:      	add	x10, sp, #0xb8
     c5c:      	add	x0, sp, #0xb8
     c60:      	mov	w1, #0x4                // =4
     c64:      	blr	x9
     c68:      	ldr	w8, [sp, #0xb8]
     c6c:      	cmp	w8, w19
     c70:      	b.eq	0x1458 <event_execve+0x1458>
     c74:      	add	x2, x23, #0x8e0
     c78:      	mov	w8, #0x8                // =8
     c7c:      	mov	w9, #0x71               // =113
     c80:      	add	x10, sp, #0x40
     c84:      	add	x0, sp, #0x40
     c88:      	mov	w1, #0x8                // =8
     c8c:      	blr	x9
     c90:      	ldr	x23, [sp, #0x40]
     c94:      	cbz	x23, 0x1458 <event_execve+0x1458>
     c98:      	add	x2, x23, #0x8d4
     c9c:      	mov	w8, #0x4                // =4
     ca0:      	mov	w9, #0x71               // =113
     ca4:      	add	x10, sp, #0xb8
     ca8:      	add	x0, sp, #0xb8
     cac:      	mov	w1, #0x4                // =4
     cb0:      	blr	x9
     cb4:      	ldr	w8, [sp, #0xb8]
     cb8:      	cmp	w8, w19
     cbc:      	b.eq	0x1458 <event_execve+0x1458>
     cc0:      	add	x2, x23, #0x8e0
     cc4:      	mov	w8, #0x8                // =8
     cc8:      	mov	w9, #0x71               // =113
     ccc:      	add	x10, sp, #0x40
     cd0:      	add	x0, sp, #0x40
     cd4:      	mov	w1, #0x8                // =8
     cd8:      	blr	x9
     cdc:      	ldr	x23, [sp, #0x40]
     ce0:      	cbz	x23, 0x1458 <event_execve+0x1458>
     ce4:      	add	x2, x23, #0x8d4
     ce8:      	mov	w8, #0x4                // =4
     cec:      	mov	w9, #0x71               // =113
     cf0:      	add	x10, sp, #0xb8
     cf4:      	add	x0, sp, #0xb8
     cf8:      	mov	w1, #0x4                // =4
     cfc:      	blr	x9
     d00:      	ldr	w8, [sp, #0xb8]
     d04:      	cmp	w8, w19
     d08:      	b.eq	0x1458 <event_execve+0x1458>
     d0c:      	add	x2, x23, #0x8e0
     d10:      	mov	w8, #0x8                // =8
     d14:      	mov	w9, #0x71               // =113
     d18:      	add	x10, sp, #0x40
     d1c:      	add	x0, sp, #0x40
     d20:      	mov	w1, #0x8                // =8
     d24:      	mov	x22, x25
     d28:      	mov	x21, x29
     d2c:      	blr	x9
     d30:      	ldr	x23, [sp, #0x40]
     d34:      	cbz	x23, 0x144c <event_execve+0x144c>
     d38:      	add	x2, x23, #0x8d4
     d3c:      	mov	w8, #0x4                // =4
     d40:      	mov	w9, #0x71               // =113
     d44:      	add	x10, sp, #0xb8
     d48:      	add	x0, sp, #0xb8
     d4c:      	mov	w1, #0x4                // =4
     d50:      	blr	x9
     d54:      	ldr	w8, [sp, #0xb8]
     d58:      	mov	x29, x21
     d5c:      	mov	x25, x22
     d60:      	add	x24, sp, #0xb8
     d64:      	cmp	w8, w19
     d68:      	b.eq	0x1458 <event_execve+0x1458>
     d6c:      	add	x2, x23, #0x8e0
     d70:      	mov	w8, #0x8                // =8
     d74:      	mov	w9, #0x71               // =113
     d78:      	add	x10, sp, #0x40
     d7c:      	add	x0, sp, #0x40
     d80:      	mov	w1, #0x8                // =8
     d84:      	blr	x9
     d88:      	ldr	x23, [sp, #0x40]
     d8c:      	cbz	x23, 0x144c <event_execve+0x144c>
     d90:      	add	x2, x23, #0x8d4
     d94:      	mov	w8, #0x4                // =4
     d98:      	mov	w9, #0x71               // =113
     d9c:      	add	x10, sp, #0xb8
     da0:      	add	x0, sp, #0xb8
     da4:      	mov	w1, #0x4                // =4
     da8:      	blr	x9
     dac:      	ldr	w8, [sp, #0xb8]
     db0:      	mov	x29, x21
     db4:      	mov	x25, x22
     db8:      	add	x24, sp, #0xb8
     dbc:      	cmp	w8, w19
     dc0:      	b.eq	0x1458 <event_execve+0x1458>
     dc4:      	add	x2, x23, #0x8e0
     dc8:      	mov	w8, #0x8                // =8
     dcc:      	mov	w9, #0x71               // =113
     dd0:      	add	x10, sp, #0x40
     dd4:      	add	x0, sp, #0x40
     dd8:      	mov	w1, #0x8                // =8
     ddc:      	blr	x9
     de0:      	ldr	x23, [sp, #0x40]
     de4:      	cbz	x23, 0x144c <event_execve+0x144c>
     de8:      	add	x2, x23, #0x8d4
     dec:      	mov	w8, #0x4                // =4
     df0:      	mov	w9, #0x71               // =113
     df4:      	add	x10, sp, #0xb8
     df8:      	add	x0, sp, #0xb8
     dfc:      	mov	w1, #0x4                // =4
     e00:      	blr	x9
     e04:      	ldr	w8, [sp, #0xb8]
     e08:      	mov	x29, x21
     e0c:      	mov	x25, x22
     e10:      	add	x24, sp, #0xb8
     e14:      	cmp	w8, w19
     e18:      	b.eq	0x1458 <event_execve+0x1458>
     e1c:      	add	x2, x23, #0x8e0
     e20:      	mov	w8, #0x8                // =8
     e24:      	mov	w9, #0x71               // =113
     e28:      	add	x10, sp, #0x40
     e2c:      	add	x0, sp, #0x40
     e30:      	mov	w1, #0x8                // =8
     e34:      	blr	x9
     e38:      	ldr	x23, [sp, #0x40]
     e3c:      	cbz	x23, 0x144c <event_execve+0x144c>
     e40:      	add	x2, x23, #0x8d4
     e44:      	mov	w8, #0x4                // =4
     e48:      	mov	w9, #0x71               // =113
     e4c:      	add	x10, sp, #0xb8
     e50:      	add	x0, sp, #0xb8
     e54:      	mov	w1, #0x4                // =4
     e58:      	blr	x9
     e5c:      	ldr	w8, [sp, #0xb8]
     e60:      	mov	x29, x21
     e64:      	mov	x25, x22
     e68:      	add	x24, sp, #0xb8
     e6c:      	cmp	w8, w19
     e70:      	b.eq	0x1458 <event_execve+0x1458>
     e74:      	add	x2, x23, #0x8e0
     e78:      	mov	w8, #0x8                // =8
     e7c:      	mov	w9, #0x71               // =113
     e80:      	add	x10, sp, #0x40
     e84:      	add	x0, sp, #0x40
     e88:      	mov	w1, #0x8                // =8
     e8c:      	blr	x9
     e90:      	ldr	x23, [sp, #0x40]
     e94:      	cbz	x23, 0x144c <event_execve+0x144c>
     e98:      	add	x2, x23, #0x8d4
     e9c:      	mov	w8, #0x4                // =4
     ea0:      	mov	w9, #0x71               // =113
     ea4:      	add	x10, sp, #0xb8
     ea8:      	add	x0, sp, #0xb8
     eac:      	mov	w1, #0x4                // =4
     eb0:      	blr	x9
     eb4:      	ldr	w8, [sp, #0xb8]
     eb8:      	mov	x29, x21
     ebc:      	mov	x25, x22
     ec0:      	add	x24, sp, #0xb8
     ec4:      	cmp	w8, w19
     ec8:      	b.eq	0x1458 <event_execve+0x1458>
     ecc:      	add	x2, x23, #0x8e0
     ed0:      	mov	w8, #0x8                // =8
     ed4:      	mov	w9, #0x71               // =113
     ed8:      	add	x10, sp, #0x40
     edc:      	add	x0, sp, #0x40
     ee0:      	mov	w1, #0x8                // =8
     ee4:      	blr	x9
     ee8:      	ldr	x23, [sp, #0x40]
     eec:      	cbz	x23, 0x144c <event_execve+0x144c>
     ef0:      	add	x2, x23, #0x8d4
     ef4:      	mov	w8, #0x4                // =4
     ef8:      	mov	w9, #0x71               // =113
     efc:      	add	x10, sp, #0xb8
     f00:      	add	x0, sp, #0xb8
     f04:      	mov	w1, #0x4                // =4
     f08:      	blr	x9
     f0c:      	ldr	w8, [sp, #0xb8]
     f10:      	mov	x29, x21
     f14:      	mov	x25, x22
     f18:      	add	x24, sp, #0xb8
     f1c:      	cmp	w8, w19
     f20:      	b.eq	0x1458 <event_execve+0x1458>
     f24:      	add	x2, x23, #0x8e0
     f28:      	mov	w8, #0x8                // =8
     f2c:      	mov	w9, #0x71               // =113
     f30:      	add	x10, sp, #0x40
     f34:      	add	x0, sp, #0x40
     f38:      	mov	w1, #0x8                // =8
     f3c:      	blr	x9
     f40:      	ldr	x23, [sp, #0x40]
     f44:      	cbz	x23, 0x144c <event_execve+0x144c>
     f48:      	add	x2, x23, #0x8d4
     f4c:      	mov	w8, #0x4                // =4
     f50:      	mov	w9, #0x71               // =113
     f54:      	add	x10, sp, #0xb8
     f58:      	add	x0, sp, #0xb8
     f5c:      	mov	w1, #0x4                // =4
     f60:      	blr	x9
     f64:      	ldr	w8, [sp, #0xb8]
     f68:      	mov	x29, x21
     f6c:      	mov	x25, x22
     f70:      	add	x24, sp, #0xb8
     f74:      	cmp	w8, w19
     f78:      	b.eq	0x1458 <event_execve+0x1458>
     f7c:      	add	x2, x23, #0x8e0
     f80:      	mov	w8, #0x8                // =8
     f84:      	mov	w9, #0x71               // =113
     f88:      	add	x10, sp, #0x40
     f8c:      	add	x0, sp, #0x40
     f90:      	mov	w1, #0x8                // =8
     f94:      	blr	x9
     f98:      	ldr	x23, [sp, #0x40]
     f9c:      	cbz	x23, 0x144c <event_execve+0x144c>
     fa0:      	add	x2, x23, #0x8d4
     fa4:      	mov	w8, #0x4                // =4
     fa8:      	mov	w9, #0x71               // =113
     fac:      	add	x10, sp, #0xb8
     fb0:      	add	x0, sp, #0xb8
     fb4:      	mov	w1, #0x4                // =4
     fb8:      	blr	x9
     fbc:      	ldr	w8, [sp, #0xb8]
     fc0:      	mov	x29, x21
     fc4:      	mov	x25, x22
     fc8:      	add	x24, sp, #0xb8
     fcc:      	cmp	w8, w19
     fd0:      	b.eq	0x1458 <event_execve+0x1458>
     fd4:      	add	x2, x23, #0x8e0
     fd8:      	mov	w8, #0x8                // =8
     fdc:      	mov	w9, #0x71               // =113
     fe0:      	add	x10, sp, #0x40
     fe4:      	add	x0, sp, #0x40
     fe8:      	mov	w1, #0x8                // =8
     fec:      	blr	x9
     ff0:      	ldr	x23, [sp, #0x40]
     ff4:      	cbz	x23, 0x144c <event_execve+0x144c>
     ff8:      	add	x2, x23, #0x8d4
     ffc:      	mov	w8, #0x4                // =4
    1000:      	mov	w9, #0x71               // =113
    1004:      	add	x10, sp, #0xb8
    1008:      	add	x0, sp, #0xb8
    100c:      	mov	w1, #0x4                // =4
    1010:      	blr	x9
    1014:      	ldr	w8, [sp, #0xb8]
    1018:      	mov	x29, x21
    101c:      	mov	x25, x22
    1020:      	add	x24, sp, #0xb8
    1024:      	cmp	w8, w19
    1028:      	b.eq	0x1458 <event_execve+0x1458>
    102c:      	add	x2, x23, #0x8e0
    1030:      	mov	w8, #0x8                // =8
    1034:      	mov	w9, #0x71               // =113
    1038:      	add	x10, sp, #0x40
    103c:      	add	x0, sp, #0x40
    1040:      	mov	w1, #0x8                // =8
    1044:      	blr	x9
    1048:      	ldr	x23, [sp, #0x40]
    104c:      	cbz	x23, 0x144c <event_execve+0x144c>
    1050:      	add	x2, x23, #0x8d4
    1054:      	mov	w8, #0x4                // =4
    1058:      	mov	w9, #0x71               // =113
    105c:      	add	x10, sp, #0xb8
    1060:      	add	x0, sp, #0xb8
    1064:      	mov	w1, #0x4                // =4
    1068:      	blr	x9
    106c:      	ldr	w8, [sp, #0xb8]
    1070:      	mov	x29, x21
    1074:      	mov	x25, x22
    1078:      	add	x24, sp, #0xb8
    107c:      	cmp	w8, w19
    1080:      	b.eq	0x1458 <event_execve+0x1458>
    1084:      	add	x2, x23, #0x8e0
    1088:      	mov	w8, #0x8                // =8
    108c:      	mov	w9, #0x71               // =113
    1090:      	add	x10, sp, #0x40
    1094:      	add	x0, sp, #0x40
    1098:      	mov	w1, #0x8                // =8
    109c:      	blr	x9
    10a0:      	ldr	x23, [sp, #0x40]
    10a4:      	cbz	x23, 0x144c <event_execve+0x144c>
    10a8:      	add	x2, x23, #0x8d4
    10ac:      	mov	w8, #0x4                // =4
    10b0:      	mov	w9, #0x71               // =113
    10b4:      	add	x10, sp, #0xb8
    10b8:      	add	x0, sp, #0xb8
    10bc:      	mov	w1, #0x4                // =4
    10c0:      	blr	x9
    10c4:      	ldr	w8, [sp, #0xb8]
    10c8:      	mov	x29, x21
    10cc:      	mov	x25, x22
    10d0:      	add	x24, sp, #0xb8
    10d4:      	cmp	w8, w19
    10d8:      	b.eq	0x1458 <event_execve+0x1458>
    10dc:      	add	x2, x23, #0x8e0
    10e0:      	mov	w8, #0x8                // =8
    10e4:      	mov	w9, #0x71               // =113
    10e8:      	add	x10, sp, #0x40
    10ec:      	add	x0, sp, #0x40
    10f0:      	mov	w1, #0x8                // =8
    10f4:      	blr	x9
    10f8:      	ldr	x23, [sp, #0x40]
    10fc:      	cbz	x23, 0x144c <event_execve+0x144c>
    1100:      	add	x2, x23, #0x8d4
    1104:      	mov	w8, #0x4                // =4
    1108:      	mov	w9, #0x71               // =113
    110c:      	add	x10, sp, #0xb8
    1110:      	add	x0, sp, #0xb8
    1114:      	mov	w1, #0x4                // =4
    1118:      	blr	x9
    111c:      	ldr	w8, [sp, #0xb8]
    1120:      	mov	x29, x21
    1124:      	mov	x25, x22
    1128:      	add	x24, sp, #0xb8
    112c:      	cmp	w8, w19
    1130:      	b.eq	0x1458 <event_execve+0x1458>
    1134:      	add	x2, x23, #0x8e0
    1138:      	mov	w8, #0x8                // =8
    113c:      	mov	w9, #0x71               // =113
    1140:      	add	x10, sp, #0x40
    1144:      	add	x0, sp, #0x40
    1148:      	mov	w1, #0x8                // =8
    114c:      	blr	x9
    1150:      	ldr	x23, [sp, #0x40]
    1154:      	b	0x1458 <event_execve+0x1458>
    1158:      	str	wzr, [sp, #0xa8]
    115c:      	adrp	x0, 0x1000 <event_execve+0x1000>
    1160:      	mov	w8, #0x1                // =1
    1164:      	add	x9, sp, #0xa8
    1168:      	ldr	x0, [x0]
    116c:      	add	x1, sp, #0xa8
    1170:      	blr	x8
    1174:      	cbz	x0, 0x1278 <event_execve+0x1278>
    1178:      	mov	w8, #0x18               // =24
    117c:      	str	x21, [sp, #0x20]
    1180:      	mov	x23, x0
    1184:      	str	w8, [x0]
    1188:      	mov	w8, #0xe                // =14
    118c:      	blr	x8
    1190:      	mov	x21, x23
    1194:      	cmn	x0, #0x16
    1198:      	str	x0, [x21, #0x10]!
    119c:      	b.ne	0x11c4 <event_execve+0x11c4>
    11a0:      	add	x2, x29, #0xe8
    11a4:      	mov	w8, #0x8                // =8
    11a8:      	mov	w9, #0x4                // =4
    11ac:      	add	x10, sp, #0x40
    11b0:      	add	x0, sp, #0x40
    11b4:      	mov	w1, #0x8                // =8
    11b8:      	blr	x9
    11bc:      	ldr	x8, [sp, #0x40]
    11c0:      	str	x8, [x21]
    11c4:      	str	x29, [sp, #0x28]
    11c8:      	mov	w8, #0x7d               // =125
    11cc:      	blr	x8
    11d0:      	str	x0, [x23, #0x18]
    11d4:      	ldr	x10, [sp, #0x20]
    11d8:      	mov	x29, xzr
    11dc:      	mov	w22, #0xa               // =10
    11e0:      	ldp	x8, x9, [x21]
    11e4:      	add	x21, x23, #0x20
    11e8:      	stp	x8, x9, [x10, #0x150]
    11ec:      	subs	x8, x25, x29
    11f0:      	b.mi	0x12c4 <event_execve+0x12c4>
    11f4:      	mov	w9, #0x7fe0             // =32736
    11f8:      	add	x2, x29, x19
    11fc:      	mov	x0, x21
    1200:      	cmp	x8, x9
    1204:      	csel	x24, x8, x9, lo
    1208:      	mov	w8, #0x4                // =4
    120c:      	mov	w1, w24
    1210:      	blr	x8
    1214:      	tbnz	w0, #0x1f, 0x1250 <event_execve+0x1250>
    1218:      	add	w4, w24, #0x20
    121c:      	adrp	x1, 0x1000 <event_execve+0x1000>
    1220:      	ldr	x0, [sp, #0x28]
    1224:      	mov	w8, #0x19               // =25
    1228:      	str	w4, [x23, #0x4]
    122c:      	mov	w9, #-0x1               // =-1
    1230:      	mov	w2, #-0x1               // =-1
    1234:      	mov	x3, x23
    1238:      	ldr	x1, [x1]
    123c:      	blr	x8
    1240:      	sxtw	x8, w0
    1244:      	tst	w0, #0x80000000
    1248:      	csel	x8, x24, x8, eq
    124c:      	b	0x1254 <event_execve+0x1254>
    1250:      	sxtw	x8, w0
    1254:      	add	x24, sp, #0xb8
    1258:      	tbnz	w8, #0x1f, 0x12cc <event_execve+0x12cc>
    125c:      	and	x8, x8, #0x7fffffff
    1260:      	add	x29, x8, x29
    1264:      	cmp	x29, x25
    1268:      	b.eq	0x1320 <event_execve+0x1320>
    126c:      	subs	w22, w22, #0x1
    1270:      	b.ne	0x11ec <event_execve+0x11ec>
    1274:      	b	0x137c <event_execve+0x137c>
    1278:      	mov	w21, wzr
    127c:      	b	0x13c0 <event_execve+0x13c0>
    1280:      	ldr	x25, [sp, #0x30]
    1284:      	b	0x13cc <event_execve+0x13cc>
    1288:      	str	w19, [sp, #0xa8]
    128c:      	mov	x3, xzr
    1290:      	mov	w8, #0x2                // =2
    1294:      	add	x9, sp, #0x40
    1298:      	add	x10, sp, #0xa8
    129c:      	add	x1, sp, #0x40
    12a0:      	add	x2, sp, #0xa8
    12a4:      	mov	x0, x23
    12a8:      	blr	x8
    12ac:      	tbz	w22, #0x1f, 0x13cc <event_execve+0x13cc>
    12b0:      	ldr	w8, [x20, #0x15c]
    12b4:      	mov	w21, wzr
    12b8:      	orr	w8, w8, #0x200
    12bc:      	str	w8, [x20, #0x15c]
    12c0:      	b	0x13cc <event_execve+0x13cc>
    12c4:      	mov	x29, #-0x1              // =-1
    12c8:      	b	0x12d0 <event_execve+0x12d0>
    12cc:      	mov	x29, x8
    12d0:      	str	wzr, [sp, #0x40]
    12d4:      	adrp	x0, 0x1000 <event_execve+0x1000>
    12d8:      	mov	w8, #0x1                // =1
    12dc:      	add	x9, sp, #0x40
    12e0:      	ldr	x0, [x0]
    12e4:      	add	x1, sp, #0x40
    12e8:      	blr	x8
    12ec:      	cbz	x0, 0x137c <event_execve+0x137c>
    12f0:      	cmn	x29, #0xc
    12f4:      	b.gt	0x1328 <event_execve+0x1328>
    12f8:      	cmn	x29, #0x1c
    12fc:      	b.eq	0x1348 <event_execve+0x1348>
    1300:      	cmn	x29, #0x16
    1304:      	b.eq	0x1360 <event_execve+0x1360>
    1308:      	cmn	x29, #0x10
    130c:      	b.ne	0x1358 <event_execve+0x1358>
    1310:      	add	x8, x0, #0x558
    1314:      	b	0x136c <event_execve+0x136c>
    1318:      	mov	x19, x0
    131c:      	b	0x730 <event_execve+0x730>
    1320:      	mov	x29, x25
    1324:      	b	0x137c <event_execve+0x137c>
    1328:      	cmn	x29, #0xb
    132c:      	b.eq	0x1350 <event_execve+0x1350>
    1330:      	cmn	x29, #0x7
    1334:      	b.eq	0x1368 <event_execve+0x1368>
    1338:      	cmn	x29, #0x2
    133c:      	b.ne	0x1358 <event_execve+0x1358>
    1340:      	add	x8, x0, #0x548
    1344:      	b	0x136c <event_execve+0x136c>
    1348:      	add	x8, x0, #0x568
    134c:      	b	0x136c <event_execve+0x136c>
    1350:      	add	x8, x0, #0x570
    1354:      	b	0x136c <event_execve+0x136c>
    1358:      	add	x8, x0, #0x540
    135c:      	b	0x136c <event_execve+0x136c>
    1360:      	add	x8, x0, #0x560
    1364:      	b	0x136c <event_execve+0x136c>
    1368:      	add	x8, x0, #0x550
    136c:      	ldaxr	x9, [x8]
    1370:      	add	x9, x9, #0x1
    1374:      	stlxr	w10, x9, [x8]
    1378:      	cbnz	w10, 0x136c <event_execve+0x136c>
    137c:      	ldr	x11, [sp, #0x20]
    1380:      	cmn	x25, #0x1
    1384:      	sub	w8, w25, w29
    1388:      	asr	w9, w29, #31
    138c:      	str	wzr, [x11, #0x144]
    1390:      	ccmp	w29, #0x0, #0x8, ne
    1394:      	csel	w8, wzr, w8, lt
    1398:      	and	w10, w29, w9
    139c:      	str	w8, [x11, #0x148]
    13a0:      	bic	w8, w29, w9
    13a4:      	str	w10, [x11, #0x140]
    13a8:      	ldr	x29, [sp, #0x28]
    13ac:      	mov	w21, #0x20              // =32
    13b0:      	str	w8, [x11, #0x14c]
    13b4:      	ldr	w8, [x20, #0x15c]
    13b8:      	orr	w8, w8, #0x1000000
    13bc:      	str	w8, [x20, #0x15c]
    13c0:      	adrp	x23, 0x1000 <event_execve+0x1000>
    13c4:      	ldr	x25, [sp, #0x30]
    13c8:      	ldr	x23, [x23]
    13cc:      	ldr	x22, [sp, #0xd8]
    13d0:      	str	w21, [x20, #0x1848]
    13d4:      	strh	w21, [x20, #0x17a]
    13d8:      	ldr	w8, [x20, #0x140]
    13dc:      	add	w21, w8, w21
    13e0:      	ldrb	w8, [x20, #0x15d]
    13e4:      	str	w21, [x20, #0x140]
    13e8:      	tbz	w8, #0x5, 0xab0 <event_execve+0xab0>
    13ec:      	b	0xa5c <event_execve+0xa5c>
    13f0:      	cmn	x8, #0xb
    13f4:      	b.eq	0x1418 <event_execve+0x1418>
    13f8:      	cmn	x8, #0x7
    13fc:      	b.eq	0x1430 <event_execve+0x1430>
    1400:      	cmn	x8, #0x2
    1404:      	b.ne	0x1420 <event_execve+0x1420>
    1408:      	add	x8, x0, #0x548
    140c:      	b	0x1434 <event_execve+0x1434>
    1410:      	add	x8, x0, #0x568
    1414:      	b	0x1434 <event_execve+0x1434>
    1418:      	add	x8, x0, #0x570
    141c:      	b	0x1434 <event_execve+0x1434>
    1420:      	add	x8, x0, #0x540
    1424:      	b	0x1434 <event_execve+0x1434>
    1428:      	add	x8, x0, #0x560
    142c:      	b	0x1434 <event_execve+0x1434>
    1430:      	add	x8, x0, #0x550
    1434:      	ldaxr	x9, [x8]
    1438:      	add	x9, x9, #0x1
    143c:      	stlxr	w10, x9, [x8]
    1440:      	cbnz	w10, 0x1434 <event_execve+0x1434>
    1444:      	add	x19, x21, x19
    1448:      	b	0x734 <event_execve+0x734>
    144c:      	mov	x29, x21
    1450:      	mov	x25, x22
    1454:      	add	x24, sp, #0xb8
    1458:      	ldr	w8, [sp, #0xb8]
    145c:      	mov	w9, #0x4                // =4
    1460:      	add	x10, sp, #0x88
    1464:      	add	x0, sp, #0x88
    1468:      	mov	w1, #0x8                // =8
    146c:      	cmp	w8, w19
    1470:      	csel	x8, x23, xzr, eq
    1474:      	add	x2, x8, #0xb30
    1478:      	mov	w8, #0x8                // =8
    147c:      	blr	x9
    1480:      	ldr	x19, [sp, #0x88]
    1484:      	cbz	x19, 0x153c <event_execve+0x153c>
    1488:      	str	wzr, [sp, #0x94]
    148c:      	adrp	x0, 0x1000 <event_execve+0x1000>
    1490:      	mov	w8, #0x1                // =1
    1494:      	add	x9, sp, #0x94
    1498:      	ldr	x0, [x0]
    149c:      	add	x1, sp, #0x94
    14a0:      	blr	x8
    14a4:      	cbz	x0, 0x1550 <event_execve+0x1550>
    14a8:      	add	x8, x19, #0x28
    14ac:      	stp	x29, x25, [sp, #0x28]
    14b0:      	mov	x21, x0
    14b4:      	str	x8, [sp, #0x10]
    14b8:      	add	x8, x0, #0x1, lsl #12   // =0x1000
    14bc:      	str	x8, [sp, #0x20]
    14c0:      	mov	w8, #0x23               // =35
    14c4:      	blr	x8
    14c8:      	add	x2, x0, #0xb30
    14cc:      	mov	w24, #0x8               // =8
    14d0:      	add	x8, sp, #0x98
    14d4:      	mov	w9, #0x4                // =4
    14d8:      	add	x0, sp, #0x98
    14dc:      	mov	w1, #0x8                // =8
    14e0:      	mov	w22, #0x4               // =4
    14e4:      	blr	x9
    14e8:      	ldr	x23, [sp, #0x98]
    14ec:      	add	x29, x19, #0x30
    14f0:      	mov	w9, #0x4                // =4
    14f4:      	add	x0, sp, #0xa0
    14f8:      	mov	w1, #0x8                // =8
    14fc:      	mov	x2, x29
    1500:      	add	x8, x23, #0x18
    1504:      	str	x8, [sp, #0x8]
    1508:      	add	x8, sp, #0xa0
    150c:      	blr	x9
    1510:      	ldr	x19, [sp, #0xa0]
    1514:      	add	x25, sp, #0x40
    1518:      	add	x0, sp, #0x40
    151c:      	mov	w1, #0x8                // =8
    1520:      	add	x2, x19, #0x10
    1524:      	blr	x22
    1528:      	ldr	x8, [sp, #0x40]
    152c:      	cbz	x8, 0x1564 <event_execve+0x1564>
    1530:      	ldr	x9, [sp, #0x20]
    1534:      	mov	w8, #0x1000             // =4096
    1538:      	b	0x15ac <event_execve+0x15ac>
    153c:      	ldr	w9, [x20, #0x15c]
    1540:      	mov	w8, wzr
    1544:      	orr	w9, w9, #0x2000
    1548:      	str	w9, [x20, #0x15c]
    154c:      	b	0x1554 <event_execve+0x1554>
    1550:      	mov	w8, wzr
    1554:      	adrp	x23, 0x1000 <event_execve+0x1000>
    1558:      	ldr	x23, [x23]
    155c:      	ldr	x22, [sp, #0xd8]
    1560:      	b	0x1870 <event_execve+0x1870>
    1564:      	add	x2, x19, #0x18
    1568:      	mov	w8, #0x8                // =8
    156c:      	mov	w9, #0x4                // =4
    1570:      	add	x10, sp, #0x40
    1574:      	add	x0, sp, #0x40
    1578:      	mov	w1, #0x8                // =8
    157c:      	blr	x9
    1580:      	ldr	x8, [sp, #0x40]
    1584:      	cmp	x8, x19
    1588:      	b.eq	0x1530 <event_execve+0x1530>
    158c:      	mov	w8, #0x2964             // =10596
    1590:      	add	x9, x21, #0xff6
    1594:      	strh	w8, [x21, #0xffe]
    1598:      	adrp	x8, 0x1000 <event_execve+0x1000>
    159c:      	add	x8, x8, #0x0
    15a0:      	ldr	x8, [x8]
    15a4:      	str	x8, [x9]
    15a8:      	mov	w8, #0xff6              // =4086
    15ac:      	stp	xzr, xzr, [sp, #0x40]
    15b0:      	add	x2, x23, #0x20
    15b4:      	mov	w23, #0x8               // =8
    15b8:      	add	x0, sp, #0x40
    15bc:      	mov	w1, #0x8                // =8
    15c0:      	add	x19, x25, #0x8
    15c4:      	stp	x21, xzr, [sp, #0x50]
    15c8:      	add	x24, x25, #0x18
    15cc:      	add	x21, x25, #0x20
    15d0:      	stp	xzr, xzr, [sp, #0x60]
    15d4:      	mov	w22, #0x4               // =4
    15d8:      	str	x9, [sp, #0x20]
    15dc:      	str	x9, [sp, #0x70]
    15e0:      	str	w8, [sp, #0x78]
    15e4:      	mov	w8, #0x4                // =4
    15e8:      	strb	wzr, [sp, #0x7c]
    15ec:      	blr	x8
    15f0:      	ldr	x2, [sp, #0x8]
    15f4:      	mov	w8, #0x4                // =4
    15f8:      	mov	x0, x19
    15fc:      	mov	w1, #0x8                // =8
    1600:      	blr	x8
    1604:      	mov	w8, #0x4                // =4
    1608:      	mov	x0, x24
    160c:      	mov	w1, #0x8                // =8
    1610:      	mov	x2, x29
    1614:      	blr	x8
    1618:      	ldr	x2, [sp, #0x10]
    161c:      	mov	x0, x21
    1620:      	mov	w1, #0x8                // =8
    1624:      	blr	x22
    1628:      	ldr	x8, [sp, #0x60]
    162c:      	mov	w19, #0x80              // =128
    1630:      	sub	x8, x8, #0x20
    1634:      	str	x8, [sp, #0x68]
    1638:      	b	0x1648 <event_execve+0x1648>
    163c:      	nop
    1640:      	subs	w19, w19, #0x1
    1644:      	b.eq	0x17bc <event_execve+0x17bc>
    1648:      	ldp	x29, x2, [sp, #0x58]
    164c:      	ldp	x8, x9, [sp, #0x40]
    1650:      	cmp	x29, x8
    1654:      	ccmp	x2, x9, #0x0, eq
    1658:      	b.eq	0x17b4 <event_execve+0x17b4>
    165c:      	ldr	x22, [sp, #0x68]
    1660:      	mov	w8, #0x4                // =4
    1664:      	add	x9, sp, #0xa8
    1668:      	add	x0, sp, #0xa8
    166c:      	mov	w1, #0x8                // =8
    1670:      	blr	x8
    1674:      	ldr	x8, [sp, #0xa8]
    1678:      	add	x25, sp, #0xb8
    167c:      	cmp	x29, x8
    1680:      	b.eq	0x1768 <event_execve+0x1768>
    1684:      	add	x21, x29, #0x18
    1688:      	mov	w8, #0x4                // =4
    168c:      	add	x9, sp, #0xc8
    1690:      	add	x0, sp, #0xc8
    1694:      	mov	w1, #0x8                // =8
    1698:      	mov	x2, x21
    169c:      	blr	x8
    16a0:      	ldr	x8, [x25, #0x10]
    16a4:      	cmp	x8, x29
    16a8:      	b.eq	0x1768 <event_execve+0x1768>
    16ac:      	mov	w8, #0x4                // =4
    16b0:      	add	x9, sp, #0xb0
    16b4:      	add	x0, sp, #0xb0
    16b8:      	mov	w1, #0x8                // =8
    16bc:      	mov	x2, x21
    16c0:      	blr	x8
    16c4:      	add	x2, x29, #0x20
    16c8:      	mov	w8, #0x4                // =4
    16cc:      	mov	w9, #0x10               // =16
    16d0:      	add	x10, sp, #0xb8
    16d4:      	add	x0, sp, #0xb8
    16d8:      	mov	w1, #0x10               // =16
    16dc:      	blr	x8
    16e0:      	ldr	w21, [sp, #0xbc]
    16e4:      	ldr	x8, [sp, #0x50]
    16e8:      	ldr	x10, [sp, #0x70]
    16ec:      	sub	x12, x10, x8
    16f0:      	ldr	w22, [sp, #0x78]
    16f4:      	subs	w10, w21, w22
    16f8:      	ldr	x9, [x25, #0x8]
    16fc:      	csel	w10, wzr, w10, lo
    1700:      	cmp	w22, w21
    1704:      	csel	w11, w22, w21, lo
    1708:      	cinc	w13, w11, hi
    170c:      	sub	w14, w22, w13
    1710:      	subs	x12, x12, x13
    1714:      	str	w14, [sp, #0x78]
    1718:      	b.lo	0x17bc <event_execve+0x17bc>
    171c:      	cmp	x12, #0xfff
    1720:      	b.hi	0x17bc <event_execve+0x17bc>
    1724:      	cmp	w22, w21
    1728:      	b.ls	0x1734 <event_execve+0x1734>
    172c:      	mov	w13, #0x2f              // =47
    1730:      	strb	w13, [x8, x12]
    1734:      	add	x29, x8, x12
    1738:      	cmp	w22, w21
    173c:      	add	x2, x9, x10
    1740:      	and	w1, w11, #0xff
    1744:      	mov	w8, #0x4                // =4
    1748:      	cinc	x0, x29, hi
    174c:      	blr	x8
    1750:      	cmp	w22, w21
    1754:      	str	x29, [sp, #0x70]
    1758:      	b.ls	0x17bc <event_execve+0x17bc>
    175c:      	ldr	x8, [sp, #0xb0]
    1760:      	str	x8, [sp, #0x58]
    1764:      	b	0x1640 <event_execve+0x1640>
    1768:      	add	x2, x22, #0x10
    176c:      	mov	w8, #0x4                // =4
    1770:      	add	x9, sp, #0xc8
    1774:      	add	x0, sp, #0xc8
    1778:      	mov	w1, #0x8                // =8
    177c:      	blr	x8
    1780:      	ldr	x8, [sp, #0x68]
    1784:      	ldr	x9, [x25, #0x10]
    1788:      	cmp	x8, x9
    178c:      	b.eq	0x17b4 <event_execve+0x17b4>
    1790:      	add	x2, x22, #0x18
    1794:      	mov	w8, #0x4                // =4
    1798:      	mov	x0, x24
    179c:      	mov	w1, #0x8                // =8
    17a0:      	blr	x8
    17a4:      	ldr	x8, [x25, #0x10]
    17a8:      	add	x9, x8, #0x20
    17ac:      	stp	x9, x8, [sp, #0x60]
    17b0:      	b	0x1640 <event_execve+0x1640>
    17b4:      	mov	w8, #0x1                // =1
    17b8:      	strb	w8, [sp, #0x7c]
    17bc:      	ldr	x8, [sp, #0x70]
    17c0:      	ldp	x2, x29, [sp, #0x20]
    17c4:      	cmp	x8, x2
    17c8:      	b.eq	0x1810 <event_execve+0x1810>
    17cc:      	ldrb	w9, [sp, #0x7c]
    17d0:      	ldr	w10, [sp, #0x78]
    17d4:      	adrp	x23, 0x1000 <event_execve+0x1000>
    17d8:      	mov	w11, #0x1000            // =4096
    17dc:      	add	x24, sp, #0xb8
    17e0:      	cmp	w9, #0x0
    17e4:      	ldr	x25, [sp, #0x30]
    17e8:      	ldr	x23, [x23]
    17ec:      	ldr	x22, [sp, #0xd8]
    17f0:      	sub	w11, w11, w10
    17f4:      	cset	w9, eq
    17f8:      	cmp	w10, #0x0
    17fc:      	csel	w21, w11, w10, gt
    1800:      	cbz	x8, 0x1870 <event_execve+0x1870>
    1804:      	lsl	w19, w9, #1
    1808:      	mov	x2, x8
    180c:      	b	0x182c <event_execve+0x182c>
    1810:      	adrp	x23, 0x1000 <event_execve+0x1000>
    1814:      	ldr	x25, [sp, #0x30]
    1818:      	mov	w21, wzr
    181c:      	mov	w19, wzr
    1820:      	ldr	x23, [x23]
    1824:      	ldr	x22, [sp, #0xd8]
    1828:      	add	x24, sp, #0xb8
    182c:      	ldr	w8, [sp, #0x1c]
    1830:      	ands	w1, w21, #0xfff
    1834:      	and	w8, w8, #0x3ff
    1838:      	add	x0, x22, x8
    183c:      	mov	w8, #0x4                // =4
    1840:      	blr	x8
    1844:      	ldr	w9, [x20, #0x15c]
    1848:      	ands	w8, w21, #0xfff
    184c:      	strh	w8, [x20, #0x17c]
    1850:      	orr	w10, w9, #0x1000
    1854:      	csel	w9, w10, w9, eq
    1858:      	cmp	w19, #0x0
    185c:      	orr	w10, w9, #0x400000
    1860:      	csel	w9, w9, w10, eq
    1864:      	mov	w10, #-0x2401           // =-9217
    1868:      	and	w9, w9, w10
    186c:      	str	w9, [x20, #0x15c]
    1870:      	ldr	w21, [x22]
    1874:      	add	w19, w21, w8
    1878:      	str	xzr, [sp, #0xb8]
    187c:      	adrp	x8, 0x1000 <event_execve+0x1000>
    1880:      	str	w19, [x22]
    1884:      	ldr	x8, [x8]
    1888:      	ldrb	w8, [x8]
    188c:      	cbz	w8, 0x1ca8 <event_execve+0x1ca8>
    1890:      	cmp	w19, #0x3ff
    1894:      	b.hi	0x1934 <event_execve+0x1934>
    1898:      	mov	w8, #0x23               // =35
    189c:      	blr	x8
    18a0:      	add	x2, x0, #0x858
    18a4:      	mov	w8, #0x8                // =8
    18a8:      	mov	w9, #0x4                // =4
    18ac:      	add	x10, sp, #0xb8
    18b0:      	add	x0, sp, #0xb8
    18b4:      	mov	w1, #0x8                // =8
    18b8:      	blr	x9
    18bc:      	ldr	x8, [sp, #0xb8]
    18c0:      	cbz	x8, 0x1ca8 <event_execve+0x1ca8>
    18c4:      	add	x8, x8, #0x288
    18c8:      	mov	w9, #0x8                // =8
    18cc:      	mov	w10, #0x4               // =4
    18d0:      	add	x11, sp, #0xc8
    18d4:      	ldr	x8, [sp, #0xb8]
    18d8:      	add	x0, sp, #0xc8
    18dc:      	mov	w1, #0x8                // =8
    18e0:      	add	x2, x8, #0x288
    18e4:      	blr	x10
    18e8:      	cbz	x0, 0x1960 <event_execve+0x1960>
    18ec:      	neg	w8, w0
    18f0:      	mov	w9, #0x1                // =1
    18f4:      	add	x1, sp, #0x40
    18f8:      	strh	w8, [sp, #0x40]
    18fc:      	mov	w8, #0x9                // =9
    1900:      	mov	x0, x23
    1904:      	mov	w21, #0x1               // =1
    1908:      	strh	w8, [sp, #0x42]
    190c:      	mov	x8, #0x9a               // =154
    1910:      	movk	x8, #0x4, lsl #32
    1914:      	stur	x8, [sp, #0x44]
    1918:      	add	x8, sp, #0x40
    191c:      	blr	x9
    1920:      	cbz	x0, 0x193c <event_execve+0x193c>
    1924:      	ldr	w8, [x0]
    1928:      	add	w8, w8, #0x1
    192c:      	str	w8, [x0]
    1930:      	b	0x1960 <event_execve+0x1960>
    1934:      	mov	w8, wzr
    1938:      	b	0x1ca8 <event_execve+0x1ca8>
    193c:      	str	w21, [sp, #0xb0]
    1940:      	mov	x3, xzr
    1944:      	mov	w8, #0x2                // =2
    1948:      	add	x9, sp, #0x40
    194c:      	add	x10, sp, #0xb0
    1950:      	add	x1, sp, #0x40
    1954:      	add	x2, sp, #0xb0
    1958:      	mov	x0, x23
    195c:      	blr	x8
    1960:      	ldr	x8, [sp, #0xb8]
    1964:      	mov	w9, #0x8                // =8
    1968:      	mov	w10, #0x4               // =4
    196c:      	add	x11, sp, #0xb0
    1970:      	add	x0, sp, #0xb0
    1974:      	mov	w1, #0x8                // =8
    1978:      	add	x8, x8, #0x290
    197c:      	ldr	x8, [sp, #0xb8]
    1980:      	add	x2, x8, #0x290
    1984:      	blr	x10
    1988:      	cbz	x0, 0x19d0 <event_execve+0x19d0>
    198c:      	neg	w8, w0
    1990:      	mov	w9, #0x1                // =1
    1994:      	add	x1, sp, #0x40
    1998:      	strh	w8, [sp, #0x40]
    199c:      	mov	w8, #0x9                // =9
    19a0:      	mov	x0, x23
    19a4:      	mov	w21, #0x1               // =1
    19a8:      	strh	w8, [sp, #0x42]
    19ac:      	mov	x8, #0x9b               // =155
    19b0:      	movk	x8, #0x4, lsl #32
    19b4:      	stur	x8, [sp, #0x44]
    19b8:      	add	x8, sp, #0x40
    19bc:      	blr	x9
    19c0:      	cbz	x0, 0x1b5c <event_execve+0x1b5c>
    19c4:      	ldr	w8, [x0]
    19c8:      	add	w8, w8, #0x1
    19cc:      	str	w8, [x0]
    19d0:      	ldr	x23, [x24, #0x10]
    19d4:      	mov	w8, wzr
    19d8:      	add	x10, sp, #0xb8
    19dc:      	cbz	x23, 0x1ca8 <event_execve+0x1ca8>
    19e0:      	ldr	x9, [sp, #0xb0]
    19e4:      	cbz	x9, 0x1ca8 <event_execve+0x1ca8>
    19e8:      	str	x25, [sp, #0x30]
    19ec:      	add	x21, x20, w19, uxtw
    19f0:      	sub	x25, x9, x23
    19f4:      	cmp	x25, #0x3ff
    19f8:      	b.hi	0x1a44 <event_execve+0x1a44>
    19fc:      	add	x0, x21, #0x140
    1a00:      	add	x8, x20, #0x540
    1a04:      	sub	x8, x8, x0
    1a08:      	cmp	x25, x8
    1a0c:      	b.hs	0x1a44 <event_execve+0x1a44>
    1a10:      	sub	w8, w25, #0x1
    1a14:      	cmp	x9, x23
    1a18:      	and	w8, w8, #0x3ff
    1a1c:      	csel	w19, wzr, w8, eq
    1a20:      	mov	w8, #0x4                // =4
    1a24:      	ldr	x2, [x10, #0x10]
    1a28:      	mov	w1, w19
    1a2c:      	blr	x8
    1a30:      	ldr	x25, [sp, #0x30]
    1a34:      	ands	x8, x0, #0x80000000
    1a38:      	lsr	x9, x8, #28
    1a3c:      	csel	w8, w19, wzr, eq
    1a40:      	b	0x1c98 <event_execve+0x1c98>
    1a44:      	str	wzr, [sp, #0xa8]
    1a48:      	adrp	x0, 0x1000 <event_execve+0x1000>
    1a4c:      	mov	w8, #0x1                // =1
    1a50:      	add	x9, sp, #0xa8
    1a54:      	ldr	x0, [x0]
    1a58:      	add	x1, sp, #0xa8
    1a5c:      	blr	x8
    1a60:      	cbz	x0, 0x1b94 <event_execve+0x1b94>
    1a64:      	mov	w8, #0x18               // =24
    1a68:      	mov	x22, x0
    1a6c:      	str	w8, [x0]
    1a70:      	mov	w8, #0xe                // =14
    1a74:      	blr	x8
    1a78:      	mov	x19, x22
    1a7c:      	cmn	x0, #0x16
    1a80:      	str	x0, [x19, #0x10]!
    1a84:      	b.ne	0x1aac <event_execve+0x1aac>
    1a88:      	add	x2, x29, #0xe8
    1a8c:      	mov	w8, #0x8                // =8
    1a90:      	mov	w9, #0x4                // =4
    1a94:      	add	x10, sp, #0x40
    1a98:      	add	x0, sp, #0x40
    1a9c:      	mov	w1, #0x8                // =8
    1aa0:      	blr	x9
    1aa4:      	ldr	x8, [sp, #0x40]
    1aa8:      	str	x8, [x19]
    1aac:      	str	x29, [sp, #0x28]
    1ab0:      	mov	w8, #0x7d               // =125
    1ab4:      	blr	x8
    1ab8:      	str	x0, [x22, #0x18]
    1abc:      	mov	x29, xzr
    1ac0:      	str	x21, [sp, #0xd8]
    1ac4:      	ldp	x8, x9, [x19]
    1ac8:      	mov	w19, #0xa               // =10
    1acc:      	stp	x8, x9, [x21, #0x150]
    1ad0:      	add	x21, x22, #0x20
    1ad4:      	subs	x8, x25, x29
    1ad8:      	b.mi	0x1ba4 <event_execve+0x1ba4>
    1adc:      	mov	w9, #0x7fe0             // =32736
    1ae0:      	add	x2, x29, x23
    1ae4:      	mov	x0, x21
    1ae8:      	cmp	x8, x9
    1aec:      	csel	x24, x8, x9, lo
    1af0:      	mov	w8, #0x4                // =4
    1af4:      	mov	w1, w24
    1af8:      	blr	x8
    1afc:      	tbnz	w0, #0x1f, 0x1b38 <event_execve+0x1b38>
    1b00:      	add	w4, w24, #0x20
    1b04:      	adrp	x1, 0x1000 <event_execve+0x1000>
    1b08:      	ldr	x0, [sp, #0x28]
    1b0c:      	mov	w8, #0x19               // =25
    1b10:      	str	w4, [x22, #0x4]
    1b14:      	mov	w9, #-0x1               // =-1
    1b18:      	mov	w2, #-0x1               // =-1
    1b1c:      	mov	x3, x22
    1b20:      	ldr	x1, [x1]
    1b24:      	blr	x8
    1b28:      	sxtw	x8, w0
    1b2c:      	tst	w0, #0x80000000
    1b30:      	csel	x8, x24, x8, eq
    1b34:      	b	0x1b3c <event_execve+0x1b3c>
    1b38:      	sxtw	x8, w0
    1b3c:      	tbnz	w8, #0x1f, 0x1bac <event_execve+0x1bac>
    1b40:      	and	x8, x8, #0x7fffffff
    1b44:      	add	x29, x8, x29
    1b48:      	cmp	x29, x25
    1b4c:      	b.eq	0x1bf8 <event_execve+0x1bf8>
    1b50:      	subs	w19, w19, #0x1
    1b54:      	b.ne	0x1ad4 <event_execve+0x1ad4>
    1b58:      	b	0x1c54 <event_execve+0x1c54>
    1b5c:      	str	w21, [sp, #0xa8]
    1b60:      	mov	x3, xzr
    1b64:      	mov	w8, #0x2                // =2
    1b68:      	add	x9, sp, #0x40
    1b6c:      	add	x10, sp, #0xa8
    1b70:      	add	x1, sp, #0x40
    1b74:      	add	x2, sp, #0xa8
    1b78:      	mov	x0, x23
    1b7c:      	blr	x8
    1b80:      	ldr	x23, [x24, #0x10]
    1b84:      	mov	w8, wzr
    1b88:      	add	x10, sp, #0xb8
    1b8c:      	cbnz	x23, 0x19e0 <event_execve+0x19e0>
    1b90:      	b	0x1ca8 <event_execve+0x1ca8>
    1b94:      	ldr	x25, [sp, #0x30]
    1b98:      	mov	w9, wzr
    1b9c:      	mov	w8, wzr
    1ba0:      	b	0x1c98 <event_execve+0x1c98>
    1ba4:      	mov	x29, #-0x1              // =-1
    1ba8:      	b	0x1bb0 <event_execve+0x1bb0>
    1bac:      	mov	x29, x8
    1bb0:      	str	wzr, [sp, #0x40]
    1bb4:      	adrp	x0, 0x1000 <event_execve+0x1000>
    1bb8:      	mov	w8, #0x1                // =1
    1bbc:      	add	x9, sp, #0x40
    1bc0:      	ldr	x0, [x0]
    1bc4:      	add	x1, sp, #0x40
    1bc8:      	blr	x8
    1bcc:      	cbz	x0, 0x1c54 <event_execve+0x1c54>
    1bd0:      	cmn	x29, #0xc
    1bd4:      	b.gt	0x1c00 <event_execve+0x1c00>
    1bd8:      	cmn	x29, #0x1c
    1bdc:      	b.eq	0x1c20 <event_execve+0x1c20>
    1be0:      	cmn	x29, #0x16
    1be4:      	b.eq	0x1c38 <event_execve+0x1c38>
    1be8:      	cmn	x29, #0x10
    1bec:      	b.ne	0x1c30 <event_execve+0x1c30>
    1bf0:      	add	x8, x0, #0x558
    1bf4:      	b	0x1c44 <event_execve+0x1c44>
    1bf8:      	mov	x29, x25
    1bfc:      	b	0x1c54 <event_execve+0x1c54>
    1c00:      	cmn	x29, #0xb
    1c04:      	b.eq	0x1c28 <event_execve+0x1c28>
    1c08:      	cmn	x29, #0x7
    1c0c:      	b.eq	0x1c40 <event_execve+0x1c40>
    1c10:      	cmn	x29, #0x2
    1c14:      	b.ne	0x1c30 <event_execve+0x1c30>
    1c18:      	add	x8, x0, #0x548
    1c1c:      	b	0x1c44 <event_execve+0x1c44>
    1c20:      	add	x8, x0, #0x568
    1c24:      	b	0x1c44 <event_execve+0x1c44>
    1c28:      	add	x8, x0, #0x570
    1c2c:      	b	0x1c44 <event_execve+0x1c44>
    1c30:      	add	x8, x0, #0x540
    1c34:      	b	0x1c44 <event_execve+0x1c44>
    1c38:      	add	x8, x0, #0x560
    1c3c:      	b	0x1c44 <event_execve+0x1c44>
    1c40:      	add	x8, x0, #0x550
    1c44:      	ldaxr	x9, [x8]
    1c48:      	add	x9, x9, #0x1
    1c4c:      	stlxr	w10, x9, [x8]
    1c50:      	cbnz	w10, 0x1c44 <event_execve+0x1c44>
    1c54:      	tbnz	w29, #0x1f, 0x1c70 <event_execve+0x1c70>
    1c58:      	ldr	x9, [sp, #0xd8]
    1c5c:      	sub	w8, w25, w29
    1c60:      	cmn	x25, #0x1
    1c64:      	csel	w8, wzr, w8, eq
    1c68:      	str	xzr, [x9, #0x140]
    1c6c:      	b	0x1c84 <event_execve+0x1c84>
    1c70:      	ldr	x9, [sp, #0xd8]
    1c74:      	mov	w8, wzr
    1c78:      	str	w29, [x9, #0x140]
    1c7c:      	str	wzr, [x9, #0x144]
    1c80:      	mov	w29, wzr
    1c84:      	str	w29, [x9, #0x14c]
    1c88:      	ldp	x29, x25, [sp, #0x28]
    1c8c:      	str	w8, [x9, #0x148]
    1c90:      	mov	w8, #0x20               // =32
    1c94:      	mov	w9, #0x2                // =2
    1c98:      	ldr	w10, [x20, #0x15c]
    1c9c:      	strh	w8, [x20, #0x17e]
    1ca0:      	orr	w9, w10, w9
    1ca4:      	str	w9, [x20, #0x15c]
    1ca8:      	ldr	w9, [x20, #0x140]
    1cac:      	add	x22, x25, #0xae0
    1cb0:      	mov	w23, #0x8               // =8
    1cb4:      	add	x0, sp, #0x40
    1cb8:      	mov	w1, #0x8                // =8
    1cbc:      	add	x19, x20, #0xb8
    1cc0:      	mov	w21, #0x4               // =4
    1cc4:      	mov	x2, x22
    1cc8:      	add	w8, w9, w8
    1ccc:      	mov	w9, #0x5                // =5
    1cd0:      	strh	w9, [x20]
    1cd4:      	ldr	x9, [x20, #0x170]
    1cd8:      	str	w8, [x20, #0x140]
    1cdc:      	add	w8, w8, #0x140
    1ce0:      	str	w8, [x20, #0x4]
    1ce4:      	add	x8, sp, #0x40
    1ce8:      	str	x9, [x20, #0x8]
    1cec:      	mov	w9, #0x4                // =4
    1cf0:      	blr	x9
    1cf4:      	ldr	x8, [sp, #0x40]
    1cf8:      	mov	w9, #0x4                // =4
    1cfc:      	mov	x0, x19
    1d00:      	mov	w1, #0x4                // =4
    1d04:      	add	x8, x8, #0x8
    1d08:      	ldr	x8, [sp, #0x40]
    1d0c:      	add	x2, x8, #0x8
    1d10:      	blr	x9
    1d14:      	ldr	x8, [sp, #0x40]
    1d18:      	add	x0, x20, #0xbc
    1d1c:      	mov	w9, #0x4                // =4
    1d20:      	mov	w1, #0x4                // =4
    1d24:      	add	x8, x8, #0xc
    1d28:      	ldr	x8, [sp, #0x40]
    1d2c:      	add	x2, x8, #0xc
    1d30:      	blr	x9
    1d34:      	ldr	x8, [sp, #0x40]
    1d38:      	add	x0, x20, #0xc8
    1d3c:      	mov	w9, #0x4                // =4
    1d40:      	mov	w1, #0x4                // =4
    1d44:      	add	x8, x8, #0x18
    1d48:      	ldr	x8, [sp, #0x40]
    1d4c:      	add	x2, x8, #0x18
    1d50:      	blr	x9
    1d54:      	ldr	x8, [sp, #0x40]
    1d58:      	add	x0, x20, #0xcc
    1d5c:      	mov	w9, #0x4                // =4
    1d60:      	mov	w1, #0x4                // =4
    1d64:      	add	x8, x8, #0x1c
    1d68:      	ldr	x8, [sp, #0x40]
    1d6c:      	add	x2, x8, #0x1c
    1d70:      	blr	x9
    1d74:      	ldr	x8, [sp, #0x40]
    1d78:      	add	x0, x20, #0xc0
    1d7c:      	mov	w9, #0x4                // =4
    1d80:      	mov	w1, #0x4                // =4
    1d84:      	add	x8, x8, #0x10
    1d88:      	ldr	x8, [sp, #0x40]
    1d8c:      	add	x2, x8, #0x10
    1d90:      	blr	x9
    1d94:      	ldr	x8, [sp, #0x40]
    1d98:      	add	x0, x20, #0xc4
    1d9c:      	mov	w9, #0x4                // =4
    1da0:      	mov	w1, #0x4                // =4
    1da4:      	add	x8, x8, #0x14
    1da8:      	ldr	x8, [sp, #0x40]
    1dac:      	add	x2, x8, #0x14
    1db0:      	blr	x9
    1db4:      	ldr	x8, [sp, #0x40]
    1db8:      	add	x0, x20, #0xd0
    1dbc:      	mov	w9, #0x4                // =4
    1dc0:      	mov	w1, #0x4                // =4
    1dc4:      	add	x8, x8, #0x20
    1dc8:      	ldr	x8, [sp, #0x40]
    1dcc:      	add	x2, x8, #0x20
    1dd0:      	blr	x9
    1dd4:      	ldr	x8, [sp, #0x40]
    1dd8:      	add	x0, x20, #0xd4
    1ddc:      	mov	w9, #0x4                // =4
    1de0:      	mov	w1, #0x4                // =4
    1de4:      	add	x8, x8, #0x24
    1de8:      	ldr	x8, [sp, #0x40]
    1dec:      	add	x2, x8, #0x24
    1df0:      	blr	x9
    1df4:      	ldr	x8, [sp, #0x40]
    1df8:      	add	x0, x20, #0xd8
    1dfc:      	mov	w9, #0x4                // =4
    1e00:      	mov	w1, #0x4                // =4
    1e04:      	add	x8, x8, #0x28
    1e08:      	ldr	x8, [sp, #0x40]
    1e0c:      	add	x2, x8, #0x28
    1e10:      	blr	x9
    1e14:      	ldr	x24, [sp, #0x40]
    1e18:      	add	x0, x20, #0xe8
    1e1c:      	mov	w8, #0x4                // =4
    1e20:      	mov	w1, #0x8                // =8
    1e24:      	add	x19, x20, #0xe0
    1e28:      	add	x2, x24, #0x40
    1e2c:      	blr	x8
    1e30:      	add	x0, x20, #0xf0
    1e34:      	add	x2, x24, #0x30
    1e38:      	mov	w8, #0x4                // =4
    1e3c:      	mov	w1, #0x8                // =8
    1e40:      	blr	x8
    1e44:      	add	x2, x24, #0x38
    1e48:      	mov	w8, #0x4                // =4
    1e4c:      	mov	x0, x19
    1e50:      	mov	w1, #0x8                // =8
    1e54:      	blr	x8
    1e58:      	ldr	w8, [x20, #0xc8]
    1e5c:      	add	x2, x25, #0xb50
    1e60:      	mov	w9, #0x4                // =4
    1e64:      	add	x0, sp, #0xc8
    1e68:      	str	w8, [x20, #0x154]
    1e6c:      	add	x8, sp, #0xc8
    1e70:      	mov	w1, #0x8                // =8
    1e74:      	add	x19, x20, #0x108
    1e78:      	blr	x9
    1e7c:      	add	x24, sp, #0xb8
    1e80:      	mov	w9, #0x48               // =72
    1e84:      	add	x10, sp, #0x40
    1e88:      	ldr	x8, [x24, #0x10]
    1e8c:      	mov	w11, #0x4               // =4
    1e90:      	add	x0, sp, #0x40
    1e94:      	mov	w1, #0x48               // =72
    1e98:      	ldr	x2, [x24, #0x10]
    1e9c:      	blr	x11
    1ea0:      	ldr	x8, [sp, #0x48]
    1ea4:      	mov	w9, #0x4                // =4
    1ea8:      	mov	x0, x19
    1eac:      	mov	w1, #0x4                // =4
    1eb0:      	add	x8, x8, #0x218
    1eb4:      	ldr	x8, [sp, #0x48]
    1eb8:      	add	x2, x8, #0x218
    1ebc:      	blr	x9
    1ec0:      	ldr	x8, [sp, #0x50]
    1ec4:      	add	x0, x20, #0x10c
    1ec8:      	mov	w9, #0x4                // =4
    1ecc:      	mov	w1, #0x4                // =4
    1ed0:      	add	x8, x8, #0x4d8
    1ed4:      	ldr	x8, [sp, #0x50]
    1ed8:      	add	x2, x8, #0x4d8
    1edc:      	blr	x9
    1ee0:      	ldr	x8, [sp, #0x58]
    1ee4:      	add	x0, x20, #0x110
    1ee8:      	mov	w9, #0x4                // =4
    1eec:      	mov	w1, #0x4                // =4
    1ef0:      	add	x8, x8, #0x58
    1ef4:      	ldr	x8, [sp, #0x58]
    1ef8:      	add	x2, x8, #0x58
    1efc:      	blr	x9
    1f00:      	str	xzr, [sp, #0xb0]
    1f04:      	add	x2, x25, #0x938
    1f08:      	add	x8, sp, #0xb0
    1f0c:      	add	x0, sp, #0xb0
    1f10:      	mov	w1, #0x8                // =8
    1f14:      	blr	x21
    1f18:      	ldr	x8, [sp, #0xb0]
    1f1c:      	cbz	x8, 0x1fa0 <event_execve+0x1fa0>
    1f20:      	str	wzr, [sp, #0xa8]
    1f24:      	add	x8, x8, #0x4
    1f28:      	add	x9, sp, #0xa8
    1f2c:      	mov	w10, #0x4               // =4
    1f30:      	add	x0, sp, #0xa8
    1f34:      	mov	w1, #0x4                // =4
    1f38:      	mov	w19, #0x4               // =4
    1f3c:      	ldr	x8, [sp, #0xb0]
    1f40:      	add	x2, x8, #0x4
    1f44:      	blr	x10
    1f48:      	ldr	x8, [sp, #0xb0]
    1f4c:      	ldrsw	x9, [sp, #0xa8]
    1f50:      	add	x10, sp, #0xb8
    1f54:      	mov	w11, #0x4               // =4
    1f58:      	add	x0, sp, #0xb8
    1f5c:      	mov	w1, #0x10               // =16
    1f60:      	add	x8, x8, x9, lsl #4
    1f64:      	mov	w9, #0x10               // =16
    1f68:      	add	x8, x8, #0x80
    1f6c:      	ldr	x8, [sp, #0xb0]
    1f70:      	ldrsw	x9, [sp, #0xa8]
    1f74:      	add	x8, x8, x9, lsl #4
    1f78:      	add	x2, x8, #0x80
    1f7c:      	blr	x11
    1f80:      	ldr	x8, [x24, #0x8]
    1f84:      	add	x0, x20, #0x114
    1f88:      	mov	w1, #0x4                // =4
    1f8c:      	add	x8, x8, #0x158
    1f90:      	ldr	x8, [x24, #0x8]
    1f94:      	add	x2, x8, #0x158
    1f98:      	blr	x19
    1f9c:      	b	0x1fa4 <event_execve+0x1fa4>
    1fa0:      	str	wzr, [x20, #0x114]
    1fa4:      	ldr	x8, [sp, #0x60]
    1fa8:      	add	x0, x20, #0x118
    1fac:      	mov	w9, #0x4                // =4
    1fb0:      	mov	w1, #0x4                // =4
    1fb4:      	mov	w19, #0x4               // =4
    1fb8:      	add	x8, x8, #0x158
    1fbc:      	ldr	x8, [sp, #0x60]
    1fc0:      	add	x2, x8, #0x158
    1fc4:      	blr	x9
    1fc8:      	ldr	x8, [sp, #0x68]
    1fcc:      	add	x0, x20, #0x11c
    1fd0:      	mov	w9, #0x4                // =4
    1fd4:      	mov	w1, #0x4                // =4
    1fd8:      	add	x8, x8, #0x118
    1fdc:      	ldr	x8, [sp, #0x68]
    1fe0:      	add	x2, x8, #0x118
    1fe4:      	blr	x9
    1fe8:      	ldr	x8, [sp, #0x70]
    1fec:      	add	x0, x20, #0x120
    1ff0:      	mov	w9, #0x4                // =4
    1ff4:      	mov	w1, #0x4                // =4
    1ff8:      	add	x8, x8, #0x98
    1ffc:      	ldr	x8, [sp, #0x70]
    2000:      	add	x2, x8, #0x98
    2004:      	blr	x9
    2008:      	ldr	x8, [sp, #0x78]
    200c:      	add	x0, x20, #0x124
    2010:      	mov	w9, #0x4                // =4
    2014:      	mov	w1, #0x4                // =4
    2018:      	add	x8, x8, #0x98
    201c:      	ldr	x8, [sp, #0x78]
    2020:      	add	x2, x8, #0x98
    2024:      	blr	x9
    2028:      	ldr	x8, [sp, #0x80]
    202c:      	add	x0, x20, #0x128
    2030:      	mov	w9, #0x4                // =4
    2034:      	mov	w1, #0x4                // =4
    2038:      	add	x8, x8, #0x58
    203c:      	ldr	x8, [sp, #0x80]
    2040:      	add	x2, x8, #0x58
    2044:      	blr	x9
    2048:      	stp	xzr, xzr, [sp, #0xb0]
    204c:      	mov	w21, #0x8               // =8
    2050:      	add	x8, sp, #0xb8
    2054:      	mov	w9, #0x4                // =4
    2058:      	add	x0, sp, #0xb8
    205c:      	mov	w1, #0x8                // =8
    2060:      	mov	x2, x22
    2064:      	blr	x9
    2068:      	ldr	x8, [sp, #0xb8]
    206c:      	add	x9, sp, #0xb0
    2070:      	mov	w10, #0x4               // =4
    2074:      	add	x0, sp, #0xb0
    2078:      	mov	w1, #0x8                // =8
    207c:      	add	x8, x8, #0x90
    2080:      	ldr	x8, [sp, #0xb8]
    2084:      	add	x2, x8, #0x90
    2088:      	blr	x10
    208c:      	ldr	x8, [sp, #0xb0]
    2090:      	add	x0, x20, #0x12c
    2094:      	mov	w1, #0x4                // =4
    2098:      	add	x8, x8, #0x158
    209c:      	ldr	x8, [sp, #0xb0]
    20a0:      	add	x2, x8, #0x158
    20a4:      	blr	x19
    20a8:      	mov	x19, x20
    20ac:      	str	wzr, [sp, #0xb0]
    20b0:      	adrp	x0, 0x2000 <event_execve+0x2000>
    20b4:      	mov	w8, #0x1                // =1
    20b8:      	add	x9, sp, #0xb0
    20bc:      	add	x1, sp, #0xb0
    20c0:      	stp	xzr, xzr, [x19, #0x10]!
    20c4:      	stp	xzr, xzr, [x19, #0x10]
    20c8:      	stp	xzr, xzr, [x19, #0x20]
    20cc:      	stp	xzr, xzr, [x19, #0x30]
    20d0:      	stp	xzr, xzr, [x19, #0x40]
    20d4:      	stp	xzr, xzr, [x19, #0x50]
    20d8:      	stp	xzr, xzr, [x19, #0x60]
    20dc:      	stp	xzr, xzr, [x19, #0x70]
    20e0:      	stp	xzr, xzr, [x19, #0x80]
    20e4:      	ldr	x0, [x0]
    20e8:      	blr	x8
    20ec:      	cbz	x0, 0x210c <event_execve+0x210c>
    20f0:      	ldr	x8, [x0, #0x20]
    20f4:      	ldr	w21, [x0, #0x10]
    20f8:      	mov	w9, #0x7270             // =29296
    20fc:      	movk	w9, #0x6367, lsl #16
    2100:      	cmp	x8, x9
    2104:      	cset	w22, eq
    2108:      	b	0x2114 <event_execve+0x2114>
    210c:      	mov	w21, wzr
    2110:      	mov	w22, wzr
    2114:      	str	xzr, [x24, #0x10]
    2118:      	add	x2, x25, #0xcd0
    211c:      	mov	w8, #0x8                // =8
    2120:      	mov	w9, #0x71               // =113
    2124:      	add	x10, sp, #0xb8
    2128:      	add	x0, sp, #0xb8
    212c:      	mov	w1, #0x8                // =8
    2130:      	blr	x9
    2134:      	ldr	x8, [sp, #0xb8]
    2138:      	cbz	x8, 0x2300 <event_execve+0x2300>
    213c:      	cbz	w22, 0x21ac <event_execve+0x21ac>
    2140:      	add	x8, x8, #0x78
    2144:      	mov	w9, #0x8                // =8
    2148:      	mov	w10, #0x71              // =113
    214c:      	add	x11, sp, #0xc8
    2150:      	ldr	x8, [sp, #0xb8]
    2154:      	add	x0, sp, #0xc8
    2158:      	mov	w1, #0x8                // =8
    215c:      	add	x2, x8, #0x78
    2160:      	blr	x10
    2164:      	ldr	x22, [x24, #0x10]
    2168:      	cbz	x22, 0x2300 <event_execve+0x2300>
    216c:      	mov	w8, #0x50               // =80
    2170:      	blr	x8
    2174:      	mov	w21, wzr
    2178:      	str	x0, [x19]
    217c:      	cbz	x0, 0x2260 <event_execve+0x2260>
    2180:      	str	x0, [sp, #0x40]
    2184:      	adrp	x0, 0x2000 <event_execve+0x2000>
    2188:      	mov	w8, #0x1                // =1
    218c:      	add	x9, sp, #0x40
    2190:      	ldr	x0, [x0]
    2194:      	add	x1, sp, #0x40
    2198:      	blr	x8
    219c:      	cbz	x0, 0x2268 <event_execve+0x2268>
    21a0:      	ldr	x8, [x0]
    21a4:      	str	x8, [x20, #0x18]
    21a8:      	b	0x2270 <event_execve+0x2270>
    21ac:      	cmp	w21, #0xb
    21b0:      	b.hi	0x2300 <event_execve+0x2300>
    21b4:      	ubfiz	x9, x21, #3, #32
    21b8:      	mov	w10, #0x8               // =8
    21bc:      	mov	w11, #0x71              // =113
    21c0:      	add	x12, sp, #0x40
    21c4:      	add	x0, sp, #0x40
    21c8:      	mov	w1, #0x8                // =8
    21cc:      	add	x8, x8, x9
    21d0:      	ldr	x8, [sp, #0xb8]
    21d4:      	add	x2, x8, x9
    21d8:      	blr	x11
    21dc:      	ldr	x8, [sp, #0x40]
    21e0:      	cbz	x8, 0x22f0 <event_execve+0x22f0>
    21e4:      	mov	w9, #0x8                // =8
    21e8:      	mov	w10, #0x71              // =113
    21ec:      	add	x11, sp, #0xc8
    21f0:      	ldr	x2, [sp, #0x40]
    21f4:      	add	x0, sp, #0xc8
    21f8:      	mov	w1, #0x8                // =8
    21fc:      	blr	x10
    2200:      	ldr	x22, [x24, #0x10]
    2204:      	cbz	x22, 0x2300 <event_execve+0x2300>
    2208:      	mov	w21, wzr
    220c:      	str	xzr, [sp, #0x40]
    2210:      	add	x2, x22, #0x100
    2214:      	mov	w8, #0x8                // =8
    2218:      	mov	w9, #0x71               // =113
    221c:      	add	x10, sp, #0x40
    2220:      	add	x0, sp, #0x40
    2224:      	mov	w1, #0x8                // =8
    2228:      	blr	x9
    222c:      	ldr	x8, [sp, #0x40]
    2230:      	str	xzr, [sp, #0x40]
    2234:      	cbz	x8, 0x22e0 <event_execve+0x22e0>
    2238:      	add	x2, x8, #0x60
    223c:      	mov	w8, #0x8                // =8
    2240:      	mov	w9, #0x71               // =113
    2244:      	add	x10, sp, #0x40
    2248:      	add	x0, sp, #0x40
    224c:      	mov	w1, #0x8                // =8
    2250:      	blr	x9
    2254:      	ldr	x0, [sp, #0x40]
    2258:      	str	x0, [x19]
    225c:      	cbnz	x0, 0x2180 <event_execve+0x2180>
    2260:      	orr	w21, w21, #0x200000
    2264:      	b	0x2270 <event_execve+0x2270>
    2268:      	mov	x8, xzr
    226c:      	str	xzr, [x20, #0x18]
    2270:      	add	x2, x22, #0x100
    2274:      	mov	w19, #0x8               // =8
    2278:      	add	x8, sp, #0xb8
    227c:      	mov	w9, #0x4                // =4
    2280:      	add	x0, sp, #0xb8
    2284:      	mov	w1, #0x8                // =8
    2288:      	mov	w22, #0x4               // =4
    228c:      	blr	x9
    2290:      	ldr	x8, [sp, #0xb8]
    2294:      	add	x9, sp, #0x40
    2298:      	add	x0, sp, #0x40
    229c:      	mov	w1, #0x8                // =8
    22a0:      	add	x8, x8, #0x10
    22a4:      	ldr	x8, [sp, #0xb8]
    22a8:      	add	x2, x8, #0x10
    22ac:      	blr	x22
    22b0:      	mov	w8, #0x10000            // =65536
    22b4:      	cbnz	x0, 0x22d8 <event_execve+0x22d8>
    22b8:      	ldr	x2, [sp, #0x40]
    22bc:      	cbz	x2, 0x22d8 <event_execve+0x22d8>
    22c0:      	add	x0, x20, #0x20
    22c4:      	mov	w8, #0x80               // =128
    22c8:      	mov	w9, #0x2d               // =45
    22cc:      	mov	w1, #0x80               // =128
    22d0:      	blr	x9
    22d4:      	mov	w8, wzr
    22d8:      	orr	w8, w8, w21
    22dc:      	b	0x2304 <event_execve+0x2304>
    22e0:      	mov	x0, xzr
    22e4:      	str	xzr, [x19]
    22e8:      	cbnz	xzr, 0x2180 <event_execve+0x2180>
    22ec:      	b	0x2260 <event_execve+0x2260>
    22f0:      	ldr	x22, [x24, #0x10]
    22f4:      	cbz	x22, 0x2300 <event_execve+0x2300>
    22f8:      	mov	w21, #0x80000           // =524288
    22fc:      	b	0x220c <event_execve+0x220c>
    2300:      	mov	w8, wzr
    2304:      	ldr	w10, [x20, #0x15c]
    2308:      	stp	xzr, xzr, [x20, #0x130]
    230c:      	adrp	x1, 0x2000 <event_execve+0x2000>
    2310:      	mov	x9, xzr
    2314:      	mov	x0, x29
    2318:      	mov	w2, wzr
    231c:      	orr	w8, w10, w8
    2320:      	str	w8, [x20, #0x15c]
    2324:      	mov	w8, #0xc                // =12
    2328:      	ldr	x1, [x1]
    232c:      	blr	x8
    2330:      	ldp	x20, x19, [sp, #0x110]
    2334:      	mov	w0, wzr
    2338:      	ldr	x29, [sp, #0xd0]
    233c:      	ldp	x22, x21, [sp, #0x100]
    2340:      	ldp	x24, x23, [sp, #0xf0]
    2344:      	ldp	x30, x25, [sp, #0xe0]
    2348:      	add	sp, sp, #0x120
    234c:      	ret
