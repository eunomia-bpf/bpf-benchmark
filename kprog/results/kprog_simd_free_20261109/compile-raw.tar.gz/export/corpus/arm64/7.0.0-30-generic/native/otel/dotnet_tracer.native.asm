
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/otel/dotnet_tracer.native.o:	file format elf64-littleaarch64

Disassembly of section perf_event/unwind_dotnet:

0000000000000000 <perf_unwind_dotnet>:
       0:      	sub	sp, sp, #0xd0
       4:      	str	x29, [sp, #0x80]
       8:      	stp	x30, x25, [sp, #0x90]
       c:      	stp	x24, x23, [sp, #0xa0]
      10:      	stp	x22, x21, [sp, #0xb0]
      14:      	stp	x20, x19, [sp, #0xc0]
      18:      	str	wzr, [sp, #0x20]
      1c:      	adrp	x20, 0x0 <perf_unwind_dotnet>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x20
      28:      	ldr	x20, [x20]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0x20
      34:      	mov	x0, x20
      38:      	blr	x8
      3c:      	cbz	x0, 0x46f0 <perf_unwind_dotnet+0x46f0>
      40:      	ldr	w8, [x0]
      44:      	adrp	x23, 0x0 <perf_unwind_dotnet>
      48:      	mov	x21, x0
      4c:      	str	w8, [sp, #0x88]
      50:      	ldr	x23, [x23]
      54:      	ldr	w8, [x23]
      58:      	cbnz	w8, 0x538 <perf_unwind_dotnet+0x538>
      5c:      	adrp	x0, 0x0 <perf_unwind_dotnet>
      60:      	mov	w8, #0x1                // =1
      64:      	add	x9, sp, #0x88
      68:      	ldr	x0, [x0]
      6c:      	add	x1, sp, #0x88
      70:      	blr	x8
      74:      	adrp	x24, 0x0 <perf_unwind_dotnet>
      78:      	ldr	x24, [x24]
      7c:      	cbz	x0, 0x124 <perf_unwind_dotnet+0x124>
      80:      	mov	w8, #0x1375             // =4981
      84:      	mov	w9, #0x2                // =2
      88:      	add	x1, sp, #0x70
      8c:      	strb	w9, [x21, x8]
      90:      	mov	w8, #0x5a               // =90
      94:      	add	x9, sp, #0x70
      98:      	mov	x0, x24
      9c:      	str	w8, [sp, #0x70]
      a0:      	mov	w8, #0x1                // =1
      a4:      	blr	x8
      a8:      	cbz	x0, 0x15c <perf_unwind_dotnet+0x15c>
      ac:      	ldr	x8, [x0]
      b0:      	add	x8, x8, #0x1
      b4:      	str	x8, [x0]
      b8:      	ldr	x25, [x21, #0xed8]
      bc:      	ldr	x29, [x21, #0xee0]
      c0:      	ldr	x24, [x21, #0xed0]
      c4:      	ldrb	w22, [x21, #0xf20]
      c8:      	ldr	w8, [x23]
      cc:      	cbz	w8, 0x17c <perf_unwind_dotnet+0x17c>
      d0:      	mov	w8, #0x786c             // =30828
      d4:      	add	x0, sp, #0x20
      d8:      	mov	w1, #0x23               // =35
      dc:      	mov	x2, x24
      e0:      	mov	x3, x25
      e4:      	mov	x4, x29
      e8:      	movk	w8, #0xa, lsl #16
      ec:      	stur	w8, [sp, #0x3f]
      f0:      	adrp	x8, 0x0 <perf_unwind_dotnet>
      f4:      	add	x8, x8, #0x0
      f8:      	ldp	x9, x10, [x8]
      fc:      	stp	x9, x10, [sp, #0x20]
     100:      	ldp	x9, x8, [x8, #0x10]
     104:      	add	x10, sp, #0x20
     108:      	stp	x9, x8, [sp, #0x30]
     10c:      	mov	w8, #0x23               // =35
     110:      	mov	w9, #0x6                // =6
     114:      	blr	x9
     118:      	cmp	x29, x25
     11c:      	b.hs	0x184 <perf_unwind_dotnet+0x184>
     120:      	b	0x45d4 <perf_unwind_dotnet+0x45d4>
     124:      	ldr	w8, [x23]
     128:      	cbnz	w8, 0x58c <perf_unwind_dotnet+0x58c>
     12c:      	mov	w8, #0x5c               // =92
     130:      	add	x9, sp, #0x70
     134:      	add	x1, sp, #0x70
     138:      	str	w8, [sp, #0x70]
     13c:      	mov	w8, #0x1                // =1
     140:      	mov	x0, x24
     144:      	blr	x8
     148:      	cbz	x0, 0x2c4 <perf_unwind_dotnet+0x2c4>
     14c:      	ldr	x8, [x0]
     150:      	add	x8, x8, #0x1
     154:      	str	x8, [x0]
     158:      	b	0x2cc <perf_unwind_dotnet+0x2cc>
     15c:      	ldr	w8, [x23]
     160:      	cbnz	w8, 0x5d8 <perf_unwind_dotnet+0x5d8>
     164:      	ldr	x25, [x21, #0xed8]
     168:      	ldr	x29, [x21, #0xee0]
     16c:      	ldr	x24, [x21, #0xed0]
     170:      	ldrb	w22, [x21, #0xf20]
     174:      	ldr	w8, [x23]
     178:      	cbnz	w8, 0xd0 <perf_unwind_dotnet+0xd0>
     17c:      	cmp	x29, x25
     180:      	b.lo	0x45d4 <perf_unwind_dotnet+0x45d4>
     184:      	add	x8, x25, #0x2, lsl #12  // =0x2000
     188:      	cmp	x29, x8
     18c:      	b.hs	0x45d4 <perf_unwind_dotnet+0x45d4>
     190:      	ldr	x23, [x21, #0xf00]
     194:      	add	x8, x21, #0xf70
     198:      	ldr	x25, [x21, #0xf10]
     19c:      	add	x11, x21, #0xed0
     1a0:      	str	x24, [sp, #0x68]
     1a4:      	str	x8, [sp, #0x18]
     1a8:      	mov	w8, #0x101              // =257
     1ac:      	strh	w8, [x21, #0xf20]
     1b0:      	and	x8, x23, #0xffffffffffffff80
     1b4:      	cmp	x8, #0x80
     1b8:      	b.ne	0x258 <perf_unwind_dotnet+0x258>
     1bc:      	ldr	x8, [x21, #0xed8]
     1c0:      	mov	w9, #0x8                // =8
     1c4:      	mov	w10, #0x70              // =112
     1c8:      	mov	x0, x11
     1cc:      	ldr	x2, [x21, #0xed8]
     1d0:      	mov	w1, #0x8                // =8
     1d4:      	mov	x29, x11
     1d8:      	blr	x10
     1dc:      	cbz	x0, 0x2d8 <perf_unwind_dotnet+0x2d8>
     1e0:      	adrp	x23, 0x0 <perf_unwind_dotnet>
     1e4:      	ldr	x23, [x23]
     1e8:      	ldr	w8, [x23]
     1ec:      	cbnz	w8, 0x690 <perf_unwind_dotnet+0x690>
     1f0:      	mov	w8, #0x5d               // =93
     1f4:      	adrp	x24, 0x0 <perf_unwind_dotnet>
     1f8:      	add	x9, sp, #0x8c
     1fc:      	str	w8, [sp, #0x8c]
     200:      	mov	w8, #0x1                // =1
     204:      	add	x1, sp, #0x8c
     208:      	ldr	x24, [x24]
     20c:      	mov	x0, x24
     210:      	blr	x8
     214:      	cbnz	x0, 0x2b4 <perf_unwind_dotnet+0x2b4>
     218:      	ldr	w8, [x23]
     21c:      	cbz	w8, 0x424 <perf_unwind_dotnet+0x424>
     220:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     224:      	add	x8, x8, #0x0
     228:      	ldp	x9, x10, [x8, #0x10]
     22c:      	stp	x9, x10, [sp, #0x30]
     230:      	ldr	x9, [x8, #0x20]
     234:      	add	x10, sp, #0x20
     238:      	str	x9, [sp, #0x40]
     23c:      	ldur	x9, [x8, #0x26]
     240:      	stur	x9, [sp, #0x46]
     244:      	ldp	x9, x8, [x8]
     248:      	stp	x9, x8, [sp, #0x20]
     24c:      	mov	w8, #0x2e               // =46
     250:      	mov	w9, #0x6                // =6
     254:      	b	0x790 <perf_unwind_dotnet+0x790>
     258:      	str	x11, [sp, #0x10]
     25c:      	mov	w8, #0x10               // =16
     260:      	mov	w9, #0x70               // =112
     264:      	add	x10, sp, #0x70
     268:      	add	x0, sp, #0x70
     26c:      	mov	w1, #0x10               // =16
     270:      	mov	x2, x29
     274:      	blr	x9
     278:      	cbz	x0, 0x2f0 <perf_unwind_dotnet+0x2f0>
     27c:      	adrp	x23, 0x0 <perf_unwind_dotnet>
     280:      	ldr	x23, [x23]
     284:      	ldr	w8, [x23]
     288:      	cbnz	w8, 0x6c4 <perf_unwind_dotnet+0x6c4>
     28c:      	mov	w8, #0x5d               // =93
     290:      	adrp	x24, 0x0 <perf_unwind_dotnet>
     294:      	add	x9, sp, #0x8c
     298:      	str	w8, [sp, #0x8c]
     29c:      	mov	w8, #0x1                // =1
     2a0:      	add	x1, sp, #0x8c
     2a4:      	ldr	x24, [x24]
     2a8:      	mov	x0, x24
     2ac:      	blr	x8
     2b0:      	cbz	x0, 0x41c <perf_unwind_dotnet+0x41c>
     2b4:      	ldr	x8, [x0]
     2b8:      	add	x8, x8, #0x1
     2bc:      	str	x8, [x0]
     2c0:      	b	0x424 <perf_unwind_dotnet+0x424>
     2c4:      	ldr	w8, [x23]
     2c8:      	cbnz	w8, 0x638 <perf_unwind_dotnet+0x638>
     2cc:      	mov	w25, wzr
     2d0:      	mov	w8, #0x1770             // =6000
     2d4:      	b	0x4624 <perf_unwind_dotnet+0x4624>
     2d8:      	ldr	x8, [x21, #0xed8]
     2dc:      	and	x23, x23, #0x7f
     2e0:      	str	x29, [sp, #0x10]
     2e4:      	add	x8, x8, #0x8
     2e8:      	str	x8, [x21, #0xed8]
     2ec:      	b	0x888 <perf_unwind_dotnet+0x888>
     2f0:      	add	x8, x29, #0x10
     2f4:      	str	x8, [x21, #0xed8]
     2f8:      	ldp	x8, x9, [sp, #0x70]
     2fc:      	str	x8, [x21, #0xee0]
     300:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     304:      	str	x9, [x21, #0xed0]
     308:      	ldr	x8, [x8]
     30c:      	ldr	w8, [x8]
     310:      	cbnz	w8, 0x6f8 <perf_unwind_dotnet+0x6f8>
     314:      	cmp	x23, #0x100
     318:      	b.lo	0x888 <perf_unwind_dotnet+0x888>
     31c:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     320:      	ldr	x25, [x21, #0xf10]
     324:      	ldr	x23, [x21, #0xf00]
     328:      	sub	x29, x24, x25
     32c:      	ldr	x8, [x8]
     330:      	ldr	w8, [x8]
     334:      	cbnz	w8, 0x7a4 <perf_unwind_dotnet+0x7a4>
     338:      	lsr	x8, x29, #8
     33c:      	mov	w9, #0x7f               // =127
     340:      	lsr	x10, x29, #15
     344:      	mov	w1, #0x200              // =512
     348:      	sub	w9, w9, w8
     34c:      	lsl	x8, x8, #2
     350:      	cmp	x10, #0x0
     354:      	sub	x8, x8, #0x3fc
     358:      	and	x9, x9, #0x7f
     35c:      	csel	x8, x8, xzr, ne
     360:      	add	x2, x8, x23
     364:      	csel	x8, xzr, x9, ne
     368:      	ldr	x9, [sp, #0x18]
     36c:      	add	x0, x9, x8, lsl #2
     370:      	mov	w8, #0x200              // =512
     374:      	mov	w9, #0x70               // =112
     378:      	blr	x9
     37c:      	cbz	x0, 0x430 <perf_unwind_dotnet+0x430>
     380:      	adrp	x23, 0x0 <perf_unwind_dotnet>
     384:      	ldr	x23, [x23]
     388:      	ldr	w8, [x23]
     38c:      	cbnz	w8, 0x5d84 <perf_unwind_dotnet+0x5d84>
     390:      	mov	w8, #0x5e               // =94
     394:      	adrp	x24, 0x0 <perf_unwind_dotnet>
     398:      	add	x9, sp, #0x8c
     39c:      	str	w8, [sp, #0x8c]
     3a0:      	mov	w8, #0x1                // =1
     3a4:      	add	x1, sp, #0x8c
     3a8:      	ldr	x24, [x24]
     3ac:      	mov	x0, x24
     3b0:      	blr	x8
     3b4:      	cbz	x0, 0x470 <perf_unwind_dotnet+0x470>
     3b8:      	ldr	x8, [x0]
     3bc:      	add	x8, x8, #0x1
     3c0:      	str	x8, [x0]
     3c4:      	ldr	x11, [sp, #0x10]
     3c8:      	mov	w22, wzr
     3cc:      	mov	w2, #0x1772             // =6002
     3d0:      	ldr	w8, [x23]
     3d4:      	cbz	w8, 0x48c <perf_unwind_dotnet+0x48c>
     3d8:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     3dc:      	add	x8, x8, #0x0
     3e0:      	add	x0, sp, #0x20
     3e4:      	ldp	x9, x10, [x8, #0x10]
     3e8:      	mov	w1, #0x28               // =40
     3ec:      	stp	x9, x10, [sp, #0x30]
     3f0:      	ldr	x9, [x8, #0x20]
     3f4:      	add	x10, sp, #0x20
     3f8:      	str	x9, [sp, #0x40]
     3fc:      	ldp	x8, x9, [x8]
     400:      	stp	x8, x9, [sp, #0x20]
     404:      	mov	w8, #0x28               // =40
     408:      	mov	w9, #0x6                // =6
     40c:      	blr	x9
     410:      	ldr	x11, [sp, #0x10]
     414:      	cbnz	w22, 0x490 <perf_unwind_dotnet+0x490>
     418:      	b	0x908 <perf_unwind_dotnet+0x908>
     41c:      	ldr	w8, [x23]
     420:      	cbnz	w8, 0x75c <perf_unwind_dotnet+0x75c>
     424:      	mov	w8, #0x1771             // =6001
     428:      	mov	w25, wzr
     42c:      	b	0x4624 <perf_unwind_dotnet+0x4624>
     430:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     434:      	ldr	w23, [x21, #0x116c]
     438:      	ldr	x8, [x8]
     43c:      	ldr	w8, [x8]
     440:      	cbnz	w8, 0xc98 <perf_unwind_dotnet+0xc98>
     444:      	mov	w8, #0x1c               // =28
     448:      	bic	w8, w8, w29, lsr #3
     44c:      	lsr	w23, w23, w8
     450:      	cbz	w23, 0xcf0 <perf_unwind_dotnet+0xcf0>
     454:      	and	x29, x29, #0xffffffffffffffe0
     458:      	ands	w3, w23, #0xf
     45c:      	b.ne	0x804 <perf_unwind_dotnet+0x804>
     460:      	ubfx	w3, w23, #4, #4
     464:      	cbz	w3, 0x528 <perf_unwind_dotnet+0x528>
     468:      	sub	x29, x29, #0x20
     46c:      	b	0x804 <perf_unwind_dotnet+0x804>
     470:      	ldr	w8, [x23]
     474:      	ldr	x11, [sp, #0x10]
     478:      	cbnz	w8, 0xd64 <perf_unwind_dotnet+0xd64>
     47c:      	mov	w22, wzr
     480:      	mov	w2, #0x1772             // =6002
     484:      	ldr	w8, [x23]
     488:      	cbnz	w8, 0x3d8 <perf_unwind_dotnet+0x3d8>
     48c:      	cbz	w22, 0x908 <perf_unwind_dotnet+0x908>
     490:      	ldr	w8, [x21, #0x2c0]
     494:      	cmp	w8, #0x7f
     498:      	b.lo	0x4d4 <perf_unwind_dotnet+0x4d4>
     49c:      	ldr	w8, [x23]
     4a0:      	cbnz	w8, 0xdc0 <perf_unwind_dotnet+0xdc0>
     4a4:      	mov	w8, #0x2                // =2
     4a8:      	add	x9, sp, #0x8c
     4ac:      	add	x1, sp, #0x8c
     4b0:      	str	w8, [sp, #0x8c]
     4b4:      	mov	w8, #0x1                // =1
     4b8:      	mov	x0, x24
     4bc:      	blr	x8
     4c0:      	cbz	x0, 0x514 <perf_unwind_dotnet+0x514>
     4c4:      	ldr	x8, [x0]
     4c8:      	add	x8, x8, #0x1
     4cc:      	str	x8, [x0]
     4d0:      	b	0x51c <perf_unwind_dotnet+0x51c>
     4d4:      	add	w9, w8, #0x1
     4d8:      	mov	w10, #0x8a              // =138
     4dc:      	str	w9, [x21, #0x2c0]
     4e0:      	mov	w9, #0x18               // =24
     4e4:      	umaddl	x8, w8, w9, x21
     4e8:      	mov	w9, #0x1773             // =6003
     4ec:      	str	x9, [x8, #0x2d8]
     4f0:      	add	x9, x8, #0x2d0
     4f4:      	str	xzr, [x8, #0x2d0]
     4f8:      	strb	w10, [x8, #0x2e0]
     4fc:      	str	wzr, [x8, #0x2e4]
     500:      	stur	wzr, [x9, #0x11]
     504:      	ldr	x29, [x11]
     508:      	ldr	w8, [x23]
     50c:      	cbnz	x29, 0xa24 <perf_unwind_dotnet+0xa24>
     510:      	b	0x16b0 <perf_unwind_dotnet+0x16b0>
     514:      	ldr	w8, [x23]
     518:      	cbnz	w8, 0xfa4 <perf_unwind_dotnet+0xfa4>
     51c:      	mov	w25, wzr
     520:      	mov	w8, #0x2                // =2
     524:      	b	0x4624 <perf_unwind_dotnet+0x4624>
     528:      	ubfx	w3, w23, #8, #4
     52c:      	cbz	w3, 0x57c <perf_unwind_dotnet+0x57c>
     530:      	sub	x29, x29, #0x40
     534:      	b	0x804 <perf_unwind_dotnet+0x804>
     538:      	mov	w8, #0x3d3d             // =15677
     53c:      	add	x0, sp, #0x20
     540:      	mov	w1, #0x1c               // =28
     544:      	movk	w8, #0xa, lsl #16
     548:      	str	w8, [sp, #0x38]
     54c:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     550:      	add	x8, x8, #0x0
     554:      	ldp	x9, x10, [x8]
     558:      	ldr	x8, [x8, #0x10]
     55c:      	stp	x9, x10, [sp, #0x20]
     560:      	str	x8, [sp, #0x30]
     564:      	mov	w8, #0x1c               // =28
     568:      	mov	w9, #0x6                // =6
     56c:      	add	x10, sp, #0x20
     570:      	ldr	w2, [x21, #0x2c0]
     574:      	blr	x9
     578:      	b	0x5c <perf_unwind_dotnet+0x5c>
     57c:      	ubfx	w3, w23, #12, #4
     580:      	cbz	w3, 0x5c8 <perf_unwind_dotnet+0x5c8>
     584:      	sub	x29, x29, #0x60
     588:      	b	0x804 <perf_unwind_dotnet+0x804>
     58c:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     590:      	add	x8, x8, #0x0
     594:      	add	x0, sp, #0x20
     598:      	ldp	x9, x10, [x8, #0x10]
     59c:      	mov	w1, #0x28               // =40
     5a0:      	stp	x9, x10, [sp, #0x30]
     5a4:      	ldr	x9, [x8, #0x20]
     5a8:      	add	x10, sp, #0x20
     5ac:      	str	x9, [sp, #0x40]
     5b0:      	ldp	x8, x9, [x8]
     5b4:      	stp	x8, x9, [sp, #0x20]
     5b8:      	mov	w8, #0x28               // =40
     5bc:      	mov	w9, #0x6                // =6
     5c0:      	blr	x9
     5c4:      	b	0x12c <perf_unwind_dotnet+0x12c>
     5c8:      	ubfx	w3, w23, #16, #4
     5cc:      	cbz	w3, 0x680 <perf_unwind_dotnet+0x680>
     5d0:      	sub	x29, x29, #0x80
     5d4:      	b	0x804 <perf_unwind_dotnet+0x804>
     5d8:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     5dc:      	add	x8, x8, #0x0
     5e0:      	add	x0, sp, #0x20
     5e4:      	ldp	x9, x10, [x8, #0x10]
     5e8:      	mov	w1, #0x2e               // =46
     5ec:      	stp	x9, x10, [sp, #0x30]
     5f0:      	ldr	x9, [x8, #0x20]
     5f4:      	add	x10, sp, #0x20
     5f8:      	str	x9, [sp, #0x40]
     5fc:      	ldur	x9, [x8, #0x26]
     600:      	stur	x9, [sp, #0x46]
     604:      	ldp	x9, x8, [x8]
     608:      	stp	x9, x8, [sp, #0x20]
     60c:      	mov	w8, #0x2e               // =46
     610:      	mov	w9, #0x6                // =6
     614:      	ldr	w2, [sp, #0x70]
     618:      	blr	x9
     61c:      	ldr	x25, [x21, #0xed8]
     620:      	ldr	x29, [x21, #0xee0]
     624:      	ldr	x24, [x21, #0xed0]
     628:      	ldrb	w22, [x21, #0xf20]
     62c:      	ldr	w8, [x23]
     630:      	cbz	w8, 0x17c <perf_unwind_dotnet+0x17c>
     634:      	b	0xd0 <perf_unwind_dotnet+0xd0>
     638:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     63c:      	add	x8, x8, #0x0
     640:      	add	x0, sp, #0x20
     644:      	ldp	x9, x10, [x8, #0x10]
     648:      	mov	w1, #0x2e               // =46
     64c:      	stp	x9, x10, [sp, #0x30]
     650:      	ldr	x9, [x8, #0x20]
     654:      	add	x10, sp, #0x20
     658:      	str	x9, [sp, #0x40]
     65c:      	ldur	x9, [x8, #0x26]
     660:      	stur	x9, [sp, #0x46]
     664:      	ldp	x9, x8, [x8]
     668:      	stp	x9, x8, [sp, #0x20]
     66c:      	mov	w8, #0x2e               // =46
     670:      	mov	w9, #0x6                // =6
     674:      	ldr	w2, [sp, #0x70]
     678:      	blr	x9
     67c:      	b	0x2cc <perf_unwind_dotnet+0x2cc>
     680:      	ubfx	w3, w23, #20, #4
     684:      	cbz	w3, 0x74c <perf_unwind_dotnet+0x74c>
     688:      	sub	x29, x29, #0xa0
     68c:      	b	0x804 <perf_unwind_dotnet+0x804>
     690:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     694:      	add	x8, x8, #0x0
     698:      	add	x0, sp, #0x20
     69c:      	ldp	x9, x10, [x8]
     6a0:      	mov	w1, #0x20               // =32
     6a4:      	stp	x9, x10, [sp, #0x20]
     6a8:      	ldp	x9, x8, [x8, #0x10]
     6ac:      	add	x10, sp, #0x20
     6b0:      	stp	x9, x8, [sp, #0x30]
     6b4:      	mov	w8, #0x20               // =32
     6b8:      	mov	w9, #0x6                // =6
     6bc:      	blr	x9
     6c0:      	b	0x1f0 <perf_unwind_dotnet+0x1f0>
     6c4:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     6c8:      	add	x8, x8, #0x0
     6cc:      	add	x0, sp, #0x20
     6d0:      	ldp	x9, x10, [x8]
     6d4:      	mov	w1, #0x20               // =32
     6d8:      	stp	x9, x10, [sp, #0x20]
     6dc:      	ldp	x9, x8, [x8, #0x10]
     6e0:      	add	x10, sp, #0x20
     6e4:      	stp	x9, x8, [sp, #0x30]
     6e8:      	mov	w8, #0x20               // =32
     6ec:      	mov	w9, #0x6                // =6
     6f0:      	blr	x9
     6f4:      	b	0x28c <perf_unwind_dotnet+0x28c>
     6f8:      	mov	w8, #0x786c             // =30828
     6fc:      	add	x0, sp, #0x20
     700:      	mov	w1, #0x23               // =35
     704:      	movk	w8, #0xa, lsl #16
     708:      	stur	w8, [sp, #0x3f]
     70c:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     710:      	add	x8, x8, #0x0
     714:      	ldp	x9, x10, [x8]
     718:      	stp	x9, x10, [sp, #0x20]
     71c:      	ldp	x9, x8, [x8, #0x10]
     720:      	add	x10, sp, #0x20
     724:      	stp	x9, x8, [sp, #0x30]
     728:      	mov	w8, #0x23               // =35
     72c:      	mov	w9, #0x6                // =6
     730:      	ldr	x2, [x21, #0xed0]
     734:      	ldr	x3, [x21, #0xed8]
     738:      	ldr	x4, [x21, #0xee0]
     73c:      	blr	x9
     740:      	cmp	x23, #0x100
     744:      	b.hs	0x31c <perf_unwind_dotnet+0x31c>
     748:      	b	0x888 <perf_unwind_dotnet+0x888>
     74c:      	ubfx	w3, w23, #24, #4
     750:      	cbz	w3, 0x7fc <perf_unwind_dotnet+0x7fc>
     754:      	sub	x29, x29, #0xc0
     758:      	b	0x804 <perf_unwind_dotnet+0x804>
     75c:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     760:      	add	x8, x8, #0x0
     764:      	ldp	x9, x10, [x8, #0x10]
     768:      	stp	x9, x10, [sp, #0x30]
     76c:      	ldr	x9, [x8, #0x20]
     770:      	add	x10, sp, #0x20
     774:      	str	x9, [sp, #0x40]
     778:      	ldur	x9, [x8, #0x26]
     77c:      	stur	x9, [sp, #0x46]
     780:      	ldp	x9, x8, [x8]
     784:      	stp	x9, x8, [sp, #0x20]
     788:      	mov	w8, #0x2e               // =46
     78c:      	mov	w9, #0x6                // =6
     790:      	ldr	w2, [sp, #0x8c]
     794:      	add	x0, sp, #0x20
     798:      	mov	w1, #0x2e               // =46
     79c:      	blr	x9
     7a0:      	b	0x424 <perf_unwind_dotnet+0x424>
     7a4:      	mov	w8, #0xa                // =10
     7a8:      	mov	w11, #0x6               // =6
     7ac:      	add	x0, sp, #0x20
     7b0:      	strh	w8, [sp, #0x60]
     7b4:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     7b8:      	add	x8, x8, #0x0
     7bc:      	mov	w1, #0x42               // =66
     7c0:      	ldp	x9, x10, [x8, #0x20]
     7c4:      	mov	x2, x29
     7c8:      	mov	x3, x25
     7cc:      	mov	x4, x23
     7d0:      	stp	x9, x10, [sp, #0x40]
     7d4:      	ldp	x9, x10, [x8, #0x30]
     7d8:      	stp	x9, x10, [sp, #0x50]
     7dc:      	ldp	x9, x10, [x8]
     7e0:      	stp	x9, x10, [sp, #0x20]
     7e4:      	ldp	x9, x8, [x8, #0x10]
     7e8:      	mov	w10, #0x42              // =66
     7ec:      	stp	x9, x8, [sp, #0x30]
     7f0:      	add	x8, sp, #0x20
     7f4:      	blr	x11
     7f8:      	b	0x338 <perf_unwind_dotnet+0x338>
     7fc:      	lsr	w3, w23, #28
     800:      	sub	x29, x29, #0xe0
     804:      	adrp	x23, 0x0 <perf_unwind_dotnet>
     808:      	lsl	w9, w3, #2
     80c:      	add	x8, x29, x25
     810:      	ldr	x23, [x23]
     814:      	sub	w9, w9, #0x4
     818:      	add	x25, x8, x9
     81c:      	ldr	w8, [x23]
     820:      	cbnz	w8, 0xd18 <perf_unwind_dotnet+0xd18>
     824:      	sub	x2, x25, #0x8
     828:      	mov	w8, #0x8                // =8
     82c:      	mov	w9, #0x70               // =112
     830:      	add	x10, sp, #0x68
     834:      	add	x0, sp, #0x68
     838:      	mov	w1, #0x8                // =8
     83c:      	blr	x9
     840:      	cbz	x0, 0x884 <perf_unwind_dotnet+0x884>
     844:      	ldr	w8, [x23]
     848:      	cbnz	w8, 0xdfc <perf_unwind_dotnet+0xdfc>
     84c:      	mov	w8, #0x5e               // =94
     850:      	adrp	x24, 0x0 <perf_unwind_dotnet>
     854:      	add	x9, sp, #0x8c
     858:      	str	w8, [sp, #0x8c]
     85c:      	mov	w8, #0x1                // =1
     860:      	add	x1, sp, #0x8c
     864:      	ldr	x24, [x24]
     868:      	mov	x0, x24
     86c:      	blr	x8
     870:      	cbz	x0, 0x900 <perf_unwind_dotnet+0x900>
     874:      	ldr	x8, [x0]
     878:      	add	x8, x8, #0x1
     87c:      	str	x8, [x0]
     880:      	b	0x908 <perf_unwind_dotnet+0x908>
     884:      	mov	w23, #0x1f              // =31
     888:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     88c:      	ldr	x8, [x8]
     890:      	ldr	w8, [x8]
     894:      	cbnz	w8, 0x914 <perf_unwind_dotnet+0x914>
     898:      	ldr	w8, [x21, #0x2c0]
     89c:      	cmp	w8, #0x7f
     8a0:      	b.lo	0x978 <perf_unwind_dotnet+0x978>
     8a4:      	adrp	x23, 0x0 <perf_unwind_dotnet>
     8a8:      	ldr	x23, [x23]
     8ac:      	ldr	w8, [x23]
     8b0:      	cbnz	w8, 0xa4c <perf_unwind_dotnet+0xa4c>
     8b4:      	mov	w8, #0x2                // =2
     8b8:      	adrp	x24, 0x0 <perf_unwind_dotnet>
     8bc:      	add	x9, sp, #0x8c
     8c0:      	str	w8, [sp, #0x8c]
     8c4:      	mov	w8, #0x1                // =1
     8c8:      	add	x1, sp, #0x8c
     8cc:      	ldr	x24, [x24]
     8d0:      	mov	x0, x24
     8d4:      	blr	x8
     8d8:      	cbz	x0, 0x8ec <perf_unwind_dotnet+0x8ec>
     8dc:      	ldr	x8, [x0]
     8e0:      	add	x8, x8, #0x1
     8e4:      	str	x8, [x0]
     8e8:      	b	0x8f4 <perf_unwind_dotnet+0x8f4>
     8ec:      	ldr	w8, [x23]
     8f0:      	cbnz	w8, 0xbf4 <perf_unwind_dotnet+0xbf4>
     8f4:      	mov	w8, #0x2                // =2
     8f8:      	mov	w25, wzr
     8fc:      	b	0x4624 <perf_unwind_dotnet+0x4624>
     900:      	ldr	w8, [x23]
     904:      	cbnz	w8, 0xfec <perf_unwind_dotnet+0xfec>
     908:      	mov	w8, #0x1772             // =6002
     90c:      	mov	w25, wzr
     910:      	b	0x4624 <perf_unwind_dotnet+0x4624>
     914:      	mov	w8, #0x786c             // =30828
     918:      	sub	x4, x24, x25
     91c:      	add	x0, sp, #0x20
     920:      	mov	w1, #0x43               // =67
     924:      	mov	x2, x25
     928:      	movk	w8, #0xa, lsl #16
     92c:      	stur	w8, [sp, #0x5f]
     930:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     934:      	add	x8, x8, #0x0
     938:      	ldp	x9, x10, [x8, #0x20]
     93c:      	stp	x9, x10, [sp, #0x40]
     940:      	ldp	x9, x10, [x8, #0x30]
     944:      	stp	x9, x10, [sp, #0x50]
     948:      	ldp	x9, x10, [x8]
     94c:      	stp	x9, x10, [sp, #0x20]
     950:      	ldp	x9, x8, [x8, #0x10]
     954:      	add	x10, sp, #0x20
     958:      	stp	x9, x8, [sp, #0x30]
     95c:      	mov	w8, #0x43               // =67
     960:      	mov	w9, #0x6                // =6
     964:      	ldr	x3, [sp, #0x68]
     968:      	blr	x9
     96c:      	ldr	w8, [x21, #0x2c0]
     970:      	cmp	w8, #0x7f
     974:      	b.hs	0x8a4 <perf_unwind_dotnet+0x8a4>
     978:      	ldr	x9, [sp, #0x68]
     97c:      	add	w11, w8, #0x1
     980:      	sub	x10, x24, x25
     984:      	adrp	x24, 0x0 <perf_unwind_dotnet>
     988:      	str	w11, [x21, #0x2c0]
     98c:      	mov	w11, #0x18              // =24
     990:      	add	x1, sp, #0x8c
     994:      	umaddl	x8, w8, w11, x21
     998:      	add	x9, x23, x9, lsl #5
     99c:      	str	x10, [x8, #0x2d8]
     9a0:      	mov	w10, #0xa               // =10
     9a4:      	strb	w22, [x8, #0x2e1]
     9a8:      	strh	wzr, [x8, #0x2e6]
     9ac:      	strb	w10, [x8, #0x2e0]
     9b0:      	str	x9, [x8, #0x2d0]
     9b4:      	add	x9, x8, #0x2d0
     9b8:      	mov	w8, #0x5b               // =91
     9bc:      	stur	wzr, [x9, #0x12]
     9c0:      	str	w8, [sp, #0x8c]
     9c4:      	mov	w8, #0x1                // =1
     9c8:      	add	x9, sp, #0x8c
     9cc:      	ldr	x24, [x24]
     9d0:      	mov	x0, x24
     9d4:      	blr	x8
     9d8:      	cbz	x0, 0xa04 <perf_unwind_dotnet+0xa04>
     9dc:      	ldr	x8, [x0]
     9e0:      	adrp	x23, 0x0 <perf_unwind_dotnet>
     9e4:      	add	x8, x8, #0x1
     9e8:      	str	x8, [x0]
     9ec:      	ldr	x23, [x23]
     9f0:      	ldr	x11, [sp, #0x10]
     9f4:      	ldr	x29, [x11]
     9f8:      	ldr	w8, [x23]
     9fc:      	cbnz	x29, 0xa24 <perf_unwind_dotnet+0xa24>
     a00:      	b	0x16b0 <perf_unwind_dotnet+0x16b0>
     a04:      	adrp	x23, 0x0 <perf_unwind_dotnet>
     a08:      	ldr	x23, [x23]
     a0c:      	ldr	x11, [sp, #0x10]
     a10:      	ldr	w8, [x23]
     a14:      	cbnz	w8, 0xc3c <perf_unwind_dotnet+0xc3c>
     a18:      	ldr	x29, [x11]
     a1c:      	ldr	w8, [x23]
     a20:      	cbz	x29, 0x16b0 <perf_unwind_dotnet+0x16b0>
     a24:      	cbnz	w8, 0xa88 <perf_unwind_dotnet+0xa88>
     a28:      	lsr	x8, x29, #56
     a2c:      	cbz	x8, 0xadc <perf_unwind_dotnet+0xadc>
     a30:      	ldr	w8, [x23]
     a34:      	cbnz	w8, 0x1668 <perf_unwind_dotnet+0x1668>
     a38:      	mov	w8, #0xb                // =11
     a3c:      	mov	w25, wzr
     a40:      	str	w8, [x21, #0xf18]
     a44:      	mov	w8, #0xfab              // =4011
     a48:      	b	0x4624 <perf_unwind_dotnet+0x4624>
     a4c:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     a50:      	add	x8, x8, #0x0
     a54:      	add	x0, sp, #0x20
     a58:      	ldp	x9, x10, [x8, #0x10]
     a5c:      	mov	w1, #0x25               // =37
     a60:      	stp	x9, x10, [sp, #0x30]
     a64:      	ldur	x9, [x8, #0x1d]
     a68:      	add	x10, sp, #0x20
     a6c:      	stur	x9, [sp, #0x3d]
     a70:      	ldp	x8, x9, [x8]
     a74:      	stp	x8, x9, [sp, #0x20]
     a78:      	mov	w8, #0x25               // =37
     a7c:      	mov	w9, #0x6                // =6
     a80:      	blr	x9
     a84:      	b	0x8b4 <perf_unwind_dotnet+0x8b4>
     a88:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     a8c:      	add	x8, x8, #0x0
     a90:      	strb	wzr, [sp, #0x50]
     a94:      	add	x0, sp, #0x20
     a98:      	ldp	x9, x10, [x8, #0x10]
     a9c:      	mov	w1, #0x31               // =49
     aa0:      	mov	x22, x11
     aa4:      	stp	x9, x10, [sp, #0x30]
     aa8:      	ldp	x9, x10, [x8, #0x20]
     aac:      	stp	x9, x10, [sp, #0x40]
     ab0:      	ldp	x9, x8, [x8]
     ab4:      	add	x10, sp, #0x20
     ab8:      	stp	x9, x8, [sp, #0x20]
     abc:      	mov	w8, #0x31               // =49
     ac0:      	mov	w9, #0x6                // =6
     ac4:      	ldr	w2, [x21, #0x2c0]
     ac8:      	blr	x9
     acc:      	ldr	x29, [x21, #0xed0]
     ad0:      	mov	x11, x22
     ad4:      	lsr	x8, x29, #56
     ad8:      	cbnz	x8, 0xa30 <perf_unwind_dotnet+0xa30>
     adc:      	cmp	x29, #0xfff
     ae0:      	b.hi	0xb00 <perf_unwind_dotnet+0xb00>
     ae4:      	ldr	w8, [x23]
     ae8:      	cbnz	w8, 0x179c <perf_unwind_dotnet+0x179c>
     aec:      	mov	w8, #0x31               // =49
     af0:      	mov	w25, wzr
     af4:      	str	w8, [x21, #0xf18]
     af8:      	mov	w8, #0xfae              // =4014
     afc:      	b	0x4624 <perf_unwind_dotnet+0x4624>
     b00:      	ldr	w8, [x21]
     b04:      	mov	w9, #0x60               // =96
     b08:      	str	x11, [sp, #0x10]
     b0c:      	adrp	x0, 0x0 <perf_unwind_dotnet>
     b10:      	add	x1, sp, #0x70
     b14:      	rev	w8, w8
     b18:      	stp	w9, w8, [sp, #0x70]
     b1c:      	rev	x8, x29
     b20:      	add	x9, sp, #0x70
     b24:      	str	x8, [sp, #0x78]
     b28:      	mov	w8, #0x1                // =1
     b2c:      	ldr	x0, [x0]
     b30:      	blr	x8
     b34:      	cbz	x0, 0x4efc <perf_unwind_dotnet+0x4efc>
     b38:      	ldr	x8, [x0, #0x8]
     b3c:      	and	x9, x8, #0xffffffffffffff
     b40:      	lsr	x25, x8, #56
     b44:      	str	x9, [x21, #0xf10]
     b48:      	ldr	x8, [x0]
     b4c:      	str	x8, [x21, #0xf00]
     b50:      	sub	x8, x29, x9
     b54:      	str	x8, [x21, #0xf08]
     b58:      	ldr	w8, [x23]
     b5c:      	cbnz	w8, 0xe38 <perf_unwind_dotnet+0xe38>
     b60:      	ldr	x0, [sp, #0x10]
     b64:      	cmp	w25, #0x1
     b68:      	b.ne	0x10e0 <perf_unwind_dotnet+0x10e0>
     b6c:      	ldr	x8, [x21, #0xf00]
     b70:      	adrp	x0, 0x0 <perf_unwind_dotnet>
     b74:      	ldr	x22, [x21, #0xf08]
     b78:      	mov	w9, #0x1                // =1
     b7c:      	add	x1, sp, #0x70
     b80:      	mov	w25, #0x1               // =1
     b84:      	str	x8, [sp, #0x70]
     b88:      	add	x8, sp, #0x70
     b8c:      	ldr	x0, [x0]
     b90:      	blr	x9
     b94:      	cbz	x0, 0xbf0 <perf_unwind_dotnet+0xbf0>
     b98:      	ldr	x8, [x0]
     b9c:      	cmp	x8, x22
     ba0:      	b.hi	0xbb0 <perf_unwind_dotnet+0xbb0>
     ba4:      	ldr	x8, [x0, #0x8]
     ba8:      	cmp	x8, x22
     bac:      	b.hs	0xbc8 <perf_unwind_dotnet+0xbc8>
     bb0:      	ldr	x8, [x0, #0x10]
     bb4:      	cmp	x8, x22
     bb8:      	b.hi	0xbe8 <perf_unwind_dotnet+0xbe8>
     bbc:      	ldr	x8, [x0, #0x18]
     bc0:      	cmp	x8, x22
     bc4:      	b.lo	0xbe8 <perf_unwind_dotnet+0xbe8>
     bc8:      	ldr	w8, [x23]
     bcc:      	cbnz	w8, 0x1044 <perf_unwind_dotnet+0x1044>
     bd0:      	ldrh	w8, [x0, #0x20]
     bd4:      	ldr	w9, [x21, #0x1370]
     bd8:      	lsr	w8, w9, w8
     bdc:      	tbz	w8, #0x0, 0x1098 <perf_unwind_dotnet+0x1098>
     be0:      	ldr	w8, [x23]
     be4:      	cbnz	w8, 0x13e4 <perf_unwind_dotnet+0x13e4>
     be8:      	mov	w25, #0x1               // =1
     bec:      	b	0x10dc <perf_unwind_dotnet+0x10dc>
     bf0:      	b	0x10dc <perf_unwind_dotnet+0x10dc>
     bf4:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     bf8:      	add	x8, x8, #0x0
     bfc:      	add	x0, sp, #0x20
     c00:      	ldp	x9, x10, [x8, #0x10]
     c04:      	mov	w1, #0x2e               // =46
     c08:      	stp	x9, x10, [sp, #0x30]
     c0c:      	ldr	x9, [x8, #0x20]
     c10:      	add	x10, sp, #0x20
     c14:      	str	x9, [sp, #0x40]
     c18:      	ldur	x9, [x8, #0x26]
     c1c:      	stur	x9, [sp, #0x46]
     c20:      	ldp	x9, x8, [x8]
     c24:      	stp	x9, x8, [sp, #0x20]
     c28:      	mov	w8, #0x2e               // =46
     c2c:      	mov	w9, #0x6                // =6
     c30:      	ldr	w2, [sp, #0x8c]
     c34:      	blr	x9
     c38:      	b	0x8f4 <perf_unwind_dotnet+0x8f4>
     c3c:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     c40:      	add	x8, x8, #0x0
     c44:      	add	x0, sp, #0x20
     c48:      	ldp	x9, x10, [x8, #0x10]
     c4c:      	mov	w1, #0x2e               // =46
     c50:      	mov	x22, x11
     c54:      	stp	x9, x10, [sp, #0x30]
     c58:      	ldr	x9, [x8, #0x20]
     c5c:      	add	x10, sp, #0x20
     c60:      	str	x9, [sp, #0x40]
     c64:      	ldur	x9, [x8, #0x26]
     c68:      	stur	x9, [sp, #0x46]
     c6c:      	ldp	x9, x8, [x8]
     c70:      	stp	x9, x8, [sp, #0x20]
     c74:      	mov	w8, #0x2e               // =46
     c78:      	mov	w9, #0x6                // =6
     c7c:      	ldr	w2, [sp, #0x8c]
     c80:      	blr	x9
     c84:      	mov	x11, x22
     c88:      	ldr	x29, [x22]
     c8c:      	ldr	w8, [x23]
     c90:      	cbnz	x29, 0xa24 <perf_unwind_dotnet+0xa24>
     c94:      	b	0x16b0 <perf_unwind_dotnet+0x16b0>
     c98:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     c9c:      	add	x8, x8, #0x0
     ca0:      	add	x0, sp, #0x20
     ca4:      	ldp	x9, x10, [x8, #0x20]
     ca8:      	and	x2, x29, #0xfffffffffffffffc
     cac:      	mov	w1, #0x36               // =54
     cb0:      	mov	w3, w23
     cb4:      	stp	x9, x10, [sp, #0x40]
     cb8:      	ldur	x9, [x8, #0x2e]
     cbc:      	stur	x9, [sp, #0x4e]
     cc0:      	ldp	x9, x10, [x8]
     cc4:      	stp	x9, x10, [sp, #0x20]
     cc8:      	ldp	x8, x9, [x8, #0x10]
     ccc:      	add	x10, sp, #0x20
     cd0:      	stp	x8, x9, [sp, #0x30]
     cd4:      	mov	w8, #0x36               // =54
     cd8:      	mov	w9, #0x6                // =6
     cdc:      	blr	x9
     ce0:      	mov	w8, #0x1c               // =28
     ce4:      	bic	w8, w8, w29, lsr #3
     ce8:      	lsr	w23, w23, w8
     cec:      	cbnz	w23, 0x454 <perf_unwind_dotnet+0x454>
     cf0:      	and	x8, x29, #0xffffffffffffff00
     cf4:      	ldr	w23, [x21, #0x1168]
     cf8:      	sub	x29, x8, #0x20
     cfc:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     d00:      	ldr	x8, [x8]
     d04:      	ldr	w8, [x8]
     d08:      	cbnz	w8, 0xed8 <perf_unwind_dotnet+0xed8>
     d0c:      	cbz	w23, 0xf24 <perf_unwind_dotnet+0xf24>
     d10:      	mov	w3, wzr
     d14:      	b	0x5d18 <perf_unwind_dotnet+0x5d18>
     d18:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     d1c:      	add	x8, x8, #0x0
     d20:      	add	x0, sp, #0x20
     d24:      	ldp	x9, x10, [x8, #0x10]
     d28:      	mov	w1, #0x2e               // =46
     d2c:      	mov	x2, x29
     d30:      	mov	x4, x25
     d34:      	stp	x9, x10, [sp, #0x30]
     d38:      	ldr	x9, [x8, #0x20]
     d3c:      	add	x10, sp, #0x20
     d40:      	str	x9, [sp, #0x40]
     d44:      	ldur	x9, [x8, #0x26]
     d48:      	stur	x9, [sp, #0x46]
     d4c:      	ldp	x9, x8, [x8]
     d50:      	stp	x9, x8, [sp, #0x20]
     d54:      	mov	w8, #0x2e               // =46
     d58:      	mov	w9, #0x6                // =6
     d5c:      	blr	x9
     d60:      	b	0x824 <perf_unwind_dotnet+0x824>
     d64:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     d68:      	add	x8, x8, #0x0
     d6c:      	add	x0, sp, #0x20
     d70:      	ldp	x9, x10, [x8, #0x10]
     d74:      	mov	w1, #0x2e               // =46
     d78:      	stp	x9, x10, [sp, #0x30]
     d7c:      	ldr	x9, [x8, #0x20]
     d80:      	add	x10, sp, #0x20
     d84:      	str	x9, [sp, #0x40]
     d88:      	ldur	x9, [x8, #0x26]
     d8c:      	stur	x9, [sp, #0x46]
     d90:      	ldp	x9, x8, [x8]
     d94:      	stp	x9, x8, [sp, #0x20]
     d98:      	mov	w8, #0x2e               // =46
     d9c:      	mov	w9, #0x6                // =6
     da0:      	ldr	w2, [sp, #0x8c]
     da4:      	blr	x9
     da8:      	ldr	x11, [sp, #0x10]
     dac:      	mov	w22, wzr
     db0:      	mov	w2, #0x1772             // =6002
     db4:      	ldr	w8, [x23]
     db8:      	cbz	w8, 0x48c <perf_unwind_dotnet+0x48c>
     dbc:      	b	0x3d8 <perf_unwind_dotnet+0x3d8>
     dc0:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     dc4:      	add	x8, x8, #0x0
     dc8:      	add	x0, sp, #0x20
     dcc:      	ldp	x9, x10, [x8, #0x10]
     dd0:      	mov	w1, #0x25               // =37
     dd4:      	stp	x9, x10, [sp, #0x30]
     dd8:      	ldur	x9, [x8, #0x1d]
     ddc:      	add	x10, sp, #0x20
     de0:      	stur	x9, [sp, #0x3d]
     de4:      	ldp	x8, x9, [x8]
     de8:      	stp	x8, x9, [sp, #0x20]
     dec:      	mov	w8, #0x25               // =37
     df0:      	mov	w9, #0x6                // =6
     df4:      	blr	x9
     df8:      	b	0x4a4 <perf_unwind_dotnet+0x4a4>
     dfc:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     e00:      	add	x8, x8, #0x0
     e04:      	add	x0, sp, #0x20
     e08:      	ldp	x9, x10, [x8]
     e0c:      	mov	w1, #0x1e               // =30
     e10:      	stp	x9, x10, [sp, #0x20]
     e14:      	ldr	x9, [x8, #0x10]
     e18:      	ldur	x8, [x8, #0x16]
     e1c:      	add	x10, sp, #0x20
     e20:      	str	x9, [sp, #0x30]
     e24:      	stur	x8, [sp, #0x36]
     e28:      	mov	w8, #0x1e               // =30
     e2c:      	mov	w9, #0x6                // =6
     e30:      	blr	x9
     e34:      	b	0x84c <perf_unwind_dotnet+0x84c>
     e38:      	mov	w8, #0xa                // =10
     e3c:      	add	x0, sp, #0x20
     e40:      	mov	w1, #0x32               // =50
     e44:      	strh	w8, [sp, #0x50]
     e48:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     e4c:      	add	x8, x8, #0x0
     e50:      	mov	x2, x29
     e54:      	ldp	x9, x10, [x8, #0x10]
     e58:      	mov	w4, w25
     e5c:      	stp	x9, x10, [sp, #0x30]
     e60:      	ldp	x9, x10, [x8, #0x20]
     e64:      	stp	x9, x10, [sp, #0x40]
     e68:      	ldp	x9, x8, [x8]
     e6c:      	add	x10, sp, #0x20
     e70:      	stp	x9, x8, [sp, #0x20]
     e74:      	mov	w8, #0x32               // =50
     e78:      	mov	w9, #0x6                // =6
     e7c:      	ldr	x3, [x21, #0xf00]
     e80:      	blr	x9
     e84:      	ldr	w8, [x23]
     e88:      	cbz	w8, 0xb60 <perf_unwind_dotnet+0xb60>
     e8c:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     e90:      	add	x8, x8, #0x0
     e94:      	add	x0, sp, #0x20
     e98:      	ldp	x9, x10, [x8, #0x10]
     e9c:      	mov	w1, #0x2f               // =47
     ea0:      	stp	x9, x10, [sp, #0x30]
     ea4:      	ldr	x9, [x8, #0x20]
     ea8:      	add	x10, sp, #0x20
     eac:      	str	x9, [sp, #0x40]
     eb0:      	ldur	x9, [x8, #0x27]
     eb4:      	stur	x9, [sp, #0x47]
     eb8:      	ldp	x9, x8, [x8]
     ebc:      	stp	x9, x8, [sp, #0x20]
     ec0:      	mov	w8, #0x2f               // =47
     ec4:      	mov	w9, #0x6                // =6
     ec8:      	ldr	x2, [x21, #0xf10]
     ecc:      	ldr	x3, [x21, #0xf08]
     ed0:      	blr	x9
     ed4:      	b	0xb60 <perf_unwind_dotnet+0xb60>
     ed8:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     edc:      	add	x8, x8, #0x0
     ee0:      	add	x0, sp, #0x20
     ee4:      	ldp	x9, x10, [x8, #0x20]
     ee8:      	mov	w1, #0x37               // =55
     eec:      	mov	x2, x29
     ef0:      	mov	w3, w23
     ef4:      	stp	x9, x10, [sp, #0x40]
     ef8:      	ldur	x9, [x8, #0x2f]
     efc:      	stur	x9, [sp, #0x4f]
     f00:      	ldp	x9, x10, [x8]
     f04:      	stp	x9, x10, [sp, #0x20]
     f08:      	ldp	x8, x9, [x8, #0x10]
     f0c:      	add	x10, sp, #0x20
     f10:      	stp	x8, x9, [sp, #0x30]
     f14:      	mov	w8, #0x37               // =55
     f18:      	mov	w9, #0x6                // =6
     f1c:      	blr	x9
     f20:      	cbnz	w23, 0xd10 <perf_unwind_dotnet+0xd10>
     f24:      	ldr	x8, [x21, #0x1160]
     f28:      	cbz	x8, 0xf34 <perf_unwind_dotnet+0xf34>
     f2c:      	mov	w9, #-0x7c              // =-124
     f30:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
     f34:      	ldr	x8, [x21, #0x1158]
     f38:      	cbz	x8, 0xf44 <perf_unwind_dotnet+0xf44>
     f3c:      	mov	w9, #-0x7a              // =-122
     f40:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
     f44:      	ldr	x8, [x21, #0x1150]
     f48:      	cbz	x8, 0xf54 <perf_unwind_dotnet+0xf54>
     f4c:      	mov	w9, #-0x78              // =-120
     f50:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
     f54:      	ldr	x8, [x21, #0x1148]
     f58:      	cbz	x8, 0xf64 <perf_unwind_dotnet+0xf64>
     f5c:      	mov	w9, #-0x76              // =-118
     f60:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
     f64:      	ldr	x8, [x21, #0x1140]
     f68:      	cbz	x8, 0xf74 <perf_unwind_dotnet+0xf74>
     f6c:      	mov	w9, #-0x74              // =-116
     f70:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
     f74:      	ldr	x8, [x21, #0x1138]
     f78:      	cbz	x8, 0xf84 <perf_unwind_dotnet+0xf84>
     f7c:      	mov	w9, #-0x72              // =-114
     f80:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
     f84:      	ldr	x8, [x21, #0x1130]
     f88:      	cbz	x8, 0xf94 <perf_unwind_dotnet+0xf94>
     f8c:      	mov	w9, #-0x70              // =-112
     f90:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
     f94:      	ldr	x8, [x21, #0x1128]
     f98:      	cbz	x8, 0x1034 <perf_unwind_dotnet+0x1034>
     f9c:      	mov	w9, #-0x6e              // =-110
     fa0:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
     fa4:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     fa8:      	add	x8, x8, #0x0
     fac:      	add	x0, sp, #0x20
     fb0:      	ldp	x9, x10, [x8, #0x10]
     fb4:      	mov	w1, #0x2e               // =46
     fb8:      	stp	x9, x10, [sp, #0x30]
     fbc:      	ldr	x9, [x8, #0x20]
     fc0:      	add	x10, sp, #0x20
     fc4:      	str	x9, [sp, #0x40]
     fc8:      	ldur	x9, [x8, #0x26]
     fcc:      	stur	x9, [sp, #0x46]
     fd0:      	ldp	x9, x8, [x8]
     fd4:      	stp	x9, x8, [sp, #0x20]
     fd8:      	mov	w8, #0x2e               // =46
     fdc:      	mov	w9, #0x6                // =6
     fe0:      	ldr	w2, [sp, #0x8c]
     fe4:      	blr	x9
     fe8:      	b	0x51c <perf_unwind_dotnet+0x51c>
     fec:      	adrp	x8, 0x0 <perf_unwind_dotnet>
     ff0:      	add	x8, x8, #0x0
     ff4:      	add	x0, sp, #0x20
     ff8:      	ldp	x9, x10, [x8, #0x10]
     ffc:      	mov	w1, #0x2e               // =46
    1000:      	stp	x9, x10, [sp, #0x30]
    1004:      	ldr	x9, [x8, #0x20]
    1008:      	add	x10, sp, #0x20
    100c:      	str	x9, [sp, #0x40]
    1010:      	ldur	x9, [x8, #0x26]
    1014:      	stur	x9, [sp, #0x46]
    1018:      	ldp	x9, x8, [x8]
    101c:      	stp	x9, x8, [sp, #0x20]
    1020:      	mov	w8, #0x2e               // =46
    1024:      	mov	w9, #0x6                // =6
    1028:      	ldr	w2, [sp, #0x8c]
    102c:      	blr	x9
    1030:      	b	0x908 <perf_unwind_dotnet+0x908>
    1034:      	ldr	x8, [x21, #0x1120]
    1038:      	cbz	x8, 0x13d4 <perf_unwind_dotnet+0x13d4>
    103c:      	mov	w9, #-0x6c              // =-108
    1040:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    1044:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1048:      	add	x8, x8, #0x0
    104c:      	mov	x22, x0
    1050:      	ldp	x9, x10, [x8]
    1054:      	mov	w1, #0x1e               // =30
    1058:      	stp	x9, x10, [sp, #0x20]
    105c:      	ldr	x9, [x8, #0x10]
    1060:      	ldur	x8, [x8, #0x16]
    1064:      	add	x10, sp, #0x20
    1068:      	str	x9, [sp, #0x30]
    106c:      	stur	x8, [sp, #0x36]
    1070:      	mov	w8, #0x1e               // =30
    1074:      	mov	w9, #0x6                // =6
    1078:      	ldrh	w2, [x0, #0x20]
    107c:      	add	x0, sp, #0x20
    1080:      	blr	x9
    1084:      	mov	x0, x22
    1088:      	ldrh	w8, [x22, #0x20]
    108c:      	ldr	w9, [x21, #0x1370]
    1090:      	lsr	w8, w9, w8
    1094:      	tbnz	w8, #0x0, 0xbe0 <perf_unwind_dotnet+0xbe0>
    1098:      	str	wzr, [sp, #0x68]
    109c:      	mov	w8, #0x1                // =1
    10a0:      	add	x9, sp, #0x68
    10a4:      	mov	x22, x0
    10a8:      	add	x1, sp, #0x68
    10ac:      	mov	x0, x24
    10b0:      	blr	x8
    10b4:      	cbz	x0, 0x10cc <perf_unwind_dotnet+0x10cc>
    10b8:      	ldr	x8, [x0]
    10bc:      	add	x8, x8, #0x1
    10c0:      	str	x8, [x0]
    10c4:      	mov	x8, x22
    10c8:      	b	0x10d8 <perf_unwind_dotnet+0x10d8>
    10cc:      	ldr	w9, [x23]
    10d0:      	mov	x8, x22
    10d4:      	cbnz	w9, 0x14f0 <perf_unwind_dotnet+0x14f0>
    10d8:      	ldrh	w25, [x8, #0x20]
    10dc:      	ldr	x0, [sp, #0x10]
    10e0:      	cmp	w25, #0x8
    10e4:      	b.ne	0x1164 <perf_unwind_dotnet+0x1164>
    10e8:      	ldr	x25, [x21, #0xed8]
    10ec:      	ldr	x29, [x21, #0xee0]
    10f0:      	ldr	x24, [x21, #0xed0]
    10f4:      	ldrb	w22, [x21, #0xf20]
    10f8:      	ldr	w8, [x23]
    10fc:      	cbnz	w8, 0x135c <perf_unwind_dotnet+0x135c>
    1100:      	cmp	x29, x25
    1104:      	b.lo	0x45d4 <perf_unwind_dotnet+0x45d4>
    1108:      	add	x8, x25, #0x2, lsl #12  // =0x2000
    110c:      	cmp	x29, x8
    1110:      	b.hs	0x45d4 <perf_unwind_dotnet+0x45d4>
    1114:      	ldr	x23, [x21, #0xf00]
    1118:      	ldr	x25, [x21, #0xf10]
    111c:      	mov	w8, #0x101              // =257
    1120:      	str	x24, [sp, #0x68]
    1124:      	strh	w8, [x21, #0xf20]
    1128:      	and	x8, x23, #0xffffffffffffff80
    112c:      	cmp	x8, #0x80
    1130:      	b.ne	0x116c <perf_unwind_dotnet+0x116c>
    1134:      	ldr	x8, [x21, #0xed8]
    1138:      	mov	w9, #0x8                // =8
    113c:      	mov	w10, #0x70              // =112
    1140:      	mov	w1, #0x8                // =8
    1144:      	ldr	x2, [x21, #0xed8]
    1148:      	blr	x10
    114c:      	cbnz	x0, 0x1e0 <perf_unwind_dotnet+0x1e0>
    1150:      	ldr	x8, [x21, #0xed8]
    1154:      	and	x23, x23, #0x7f
    1158:      	add	x8, x8, #0x8
    115c:      	str	x8, [x21, #0xed8]
    1160:      	b	0x1590 <perf_unwind_dotnet+0x1590>
    1164:      	mov	w8, wzr
    1168:      	b	0x4624 <perf_unwind_dotnet+0x4624>
    116c:      	mov	w8, #0x10               // =16
    1170:      	mov	w9, #0x70               // =112
    1174:      	add	x10, sp, #0x70
    1178:      	add	x0, sp, #0x70
    117c:      	mov	w1, #0x10               // =16
    1180:      	mov	x2, x29
    1184:      	blr	x9
    1188:      	cbnz	x0, 0x27c <perf_unwind_dotnet+0x27c>
    118c:      	add	x8, x29, #0x10
    1190:      	str	x8, [x21, #0xed8]
    1194:      	ldp	x8, x9, [sp, #0x70]
    1198:      	str	x8, [x21, #0xee0]
    119c:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    11a0:      	str	x9, [x21, #0xed0]
    11a4:      	ldr	x8, [x8]
    11a8:      	ldr	w8, [x8]
    11ac:      	cbnz	w8, 0x1424 <perf_unwind_dotnet+0x1424>
    11b0:      	cmp	x23, #0x100
    11b4:      	b.lo	0x1590 <perf_unwind_dotnet+0x1590>
    11b8:      	ldr	x8, [x21, #0xf10]
    11bc:      	ldr	x25, [x21, #0xf00]
    11c0:      	sub	x23, x24, x8
    11c4:      	str	x8, [sp, #0x8]
    11c8:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    11cc:      	ldr	x8, [x8]
    11d0:      	ldr	w8, [x8]
    11d4:      	cbnz	w8, 0x1498 <perf_unwind_dotnet+0x1498>
    11d8:      	lsr	x8, x23, #8
    11dc:      	mov	w9, #0x7f               // =127
    11e0:      	lsr	x10, x23, #15
    11e4:      	mov	w1, #0x200              // =512
    11e8:      	sub	w9, w9, w8
    11ec:      	lsl	x8, x8, #2
    11f0:      	cmp	x10, #0x0
    11f4:      	sub	x8, x8, #0x3fc
    11f8:      	and	x9, x9, #0x7f
    11fc:      	csel	x8, x8, xzr, ne
    1200:      	add	x2, x8, x25
    1204:      	csel	x8, xzr, x9, ne
    1208:      	ldr	x9, [sp, #0x18]
    120c:      	add	x0, x9, x8, lsl #2
    1210:      	mov	w8, #0x200              // =512
    1214:      	mov	w9, #0x70               // =112
    1218:      	blr	x9
    121c:      	cbz	x0, 0x127c <perf_unwind_dotnet+0x127c>
    1220:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1224:      	ldr	x8, [x8]
    1228:      	ldr	w8, [x8]
    122c:      	cbnz	w8, 0x6120 <perf_unwind_dotnet+0x6120>
    1230:      	mov	w8, #0x5e               // =94
    1234:      	adrp	x0, 0x1000 <perf_unwind_dotnet+0x1000>
    1238:      	add	x9, sp, #0x8c
    123c:      	str	w8, [sp, #0x8c]
    1240:      	mov	w8, #0x1                // =1
    1244:      	add	x1, sp, #0x8c
    1248:      	ldr	x0, [x0]
    124c:      	blr	x8
    1250:      	cbz	x0, 0x12bc <perf_unwind_dotnet+0x12bc>
    1254:      	ldr	x8, [x0]
    1258:      	add	x8, x8, #0x1
    125c:      	str	x8, [x0]
    1260:      	mov	w22, wzr
    1264:      	mov	w2, #0x1772             // =6002
    1268:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    126c:      	ldr	x8, [x8]
    1270:      	ldr	w8, [x8]
    1274:      	cbz	w8, 0x12e4 <perf_unwind_dotnet+0x12e4>
    1278:      	b	0x61e0 <perf_unwind_dotnet+0x61e0>
    127c:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1280:      	ldr	w25, [x21, #0x116c]
    1284:      	ldr	x8, [x8]
    1288:      	ldr	w8, [x8]
    128c:      	cbnz	w8, 0x194c <perf_unwind_dotnet+0x194c>
    1290:      	mov	w8, #0x1c               // =28
    1294:      	bic	w8, w8, w23, lsr #3
    1298:      	lsr	w25, w25, w8
    129c:      	cbz	w25, 0x19a4 <perf_unwind_dotnet+0x19a4>
    12a0:      	and	x29, x23, #0xffffffffffffffe0
    12a4:      	ands	w3, w25, #0xf
    12a8:      	b.ne	0x1540 <perf_unwind_dotnet+0x1540>
    12ac:      	ubfx	w3, w25, #4, #4
    12b0:      	cbz	w3, 0x133c <perf_unwind_dotnet+0x133c>
    12b4:      	sub	x29, x29, #0x20
    12b8:      	b	0x1540 <perf_unwind_dotnet+0x1540>
    12bc:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    12c0:      	ldr	x8, [x8]
    12c4:      	ldr	w8, [x8]
    12c8:      	cbnz	w8, 0x1a18 <perf_unwind_dotnet+0x1a18>
    12cc:      	mov	w22, wzr
    12d0:      	mov	w2, #0x1772             // =6002
    12d4:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    12d8:      	ldr	x8, [x8]
    12dc:      	ldr	w8, [x8]
    12e0:      	cbnz	w8, 0x61e0 <perf_unwind_dotnet+0x61e0>
    12e4:      	cbz	w22, 0x621c <perf_unwind_dotnet+0x621c>
    12e8:      	ldr	w8, [x21, #0x2c0]
    12ec:      	adrp	x23, 0x1000 <perf_unwind_dotnet+0x1000>
    12f0:      	adrp	x24, 0x1000 <perf_unwind_dotnet+0x1000>
    12f4:      	ldr	x23, [x23]
    12f8:      	ldr	x24, [x24]
    12fc:      	ldr	x11, [sp, #0x10]
    1300:      	cmp	w8, #0x7e
    1304:      	b.hi	0x49c <perf_unwind_dotnet+0x49c>
    1308:      	add	w9, w8, #0x1
    130c:      	mov	w10, #0x8a              // =138
    1310:      	str	w9, [x21, #0x2c0]
    1314:      	mov	w9, #0x18               // =24
    1318:      	umaddl	x8, w8, w9, x21
    131c:      	mov	w9, #0x1773             // =6003
    1320:      	str	x9, [x8, #0x2d8]
    1324:      	add	x9, x8, #0x2d0
    1328:      	str	xzr, [x8, #0x2d0]
    132c:      	strb	w10, [x8, #0x2e0]
    1330:      	str	wzr, [x8, #0x2e4]
    1334:      	stur	wzr, [x9, #0x11]
    1338:      	b	0x1638 <perf_unwind_dotnet+0x1638>
    133c:      	ubfx	w3, w25, #8, #4
    1340:      	cbz	w3, 0x134c <perf_unwind_dotnet+0x134c>
    1344:      	sub	x29, x29, #0x40
    1348:      	b	0x1540 <perf_unwind_dotnet+0x1540>
    134c:      	ubfx	w3, w25, #12, #4
    1350:      	cbz	w3, 0x13b4 <perf_unwind_dotnet+0x13b4>
    1354:      	sub	x29, x29, #0x60
    1358:      	b	0x1540 <perf_unwind_dotnet+0x1540>
    135c:      	mov	w8, #0x786c             // =30828
    1360:      	add	x0, sp, #0x20
    1364:      	mov	w1, #0x23               // =35
    1368:      	mov	x2, x24
    136c:      	mov	x3, x25
    1370:      	mov	x4, x29
    1374:      	movk	w8, #0xa, lsl #16
    1378:      	stur	w8, [sp, #0x3f]
    137c:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1380:      	add	x8, x8, #0x0
    1384:      	ldp	x9, x10, [x8]
    1388:      	stp	x9, x10, [sp, #0x20]
    138c:      	ldp	x9, x8, [x8, #0x10]
    1390:      	add	x10, sp, #0x20
    1394:      	stp	x9, x8, [sp, #0x30]
    1398:      	mov	w8, #0x23               // =35
    139c:      	mov	w9, #0x6                // =6
    13a0:      	blr	x9
    13a4:      	ldr	x0, [sp, #0x10]
    13a8:      	cmp	x29, x25
    13ac:      	b.hs	0x1108 <perf_unwind_dotnet+0x1108>
    13b0:      	b	0x45d4 <perf_unwind_dotnet+0x45d4>
    13b4:      	ubfx	w3, w25, #16, #4
    13b8:      	cbz	w3, 0x13c4 <perf_unwind_dotnet+0x13c4>
    13bc:      	sub	x29, x29, #0x80
    13c0:      	b	0x1540 <perf_unwind_dotnet+0x1540>
    13c4:      	ubfx	w3, w25, #20, #4
    13c8:      	cbz	w3, 0x1478 <perf_unwind_dotnet+0x1478>
    13cc:      	sub	x29, x29, #0xa0
    13d0:      	b	0x1540 <perf_unwind_dotnet+0x1540>
    13d4:      	ldr	x8, [x21, #0x1118]
    13d8:      	cbz	x8, 0x1488 <perf_unwind_dotnet+0x1488>
    13dc:      	mov	w9, #-0x6a              // =-106
    13e0:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    13e4:      	mov	w8, #0x656e             // =25966
    13e8:      	add	x0, sp, #0x20
    13ec:      	mov	w1, #0x1b               // =27
    13f0:      	movk	w8, #0xa, lsl #16
    13f4:      	stur	w8, [sp, #0x37]
    13f8:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    13fc:      	add	x8, x8, #0x0
    1400:      	ldp	x9, x10, [x8]
    1404:      	ldr	x8, [x8, #0x10]
    1408:      	stp	x9, x10, [sp, #0x20]
    140c:      	str	x8, [sp, #0x30]
    1410:      	mov	w8, #0x1b               // =27
    1414:      	mov	w9, #0x6                // =6
    1418:      	add	x10, sp, #0x20
    141c:      	blr	x9
    1420:      	b	0xbe8 <perf_unwind_dotnet+0xbe8>
    1424:      	mov	w8, #0x786c             // =30828
    1428:      	add	x0, sp, #0x20
    142c:      	mov	w1, #0x23               // =35
    1430:      	movk	w8, #0xa, lsl #16
    1434:      	stur	w8, [sp, #0x3f]
    1438:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    143c:      	add	x8, x8, #0x0
    1440:      	ldp	x9, x10, [x8]
    1444:      	stp	x9, x10, [sp, #0x20]
    1448:      	ldp	x9, x8, [x8, #0x10]
    144c:      	add	x10, sp, #0x20
    1450:      	stp	x9, x8, [sp, #0x30]
    1454:      	mov	w8, #0x23               // =35
    1458:      	mov	w9, #0x6                // =6
    145c:      	ldr	x2, [x21, #0xed0]
    1460:      	ldr	x3, [x21, #0xed8]
    1464:      	ldr	x4, [x21, #0xee0]
    1468:      	blr	x9
    146c:      	cmp	x23, #0x100
    1470:      	b.hs	0x11b8 <perf_unwind_dotnet+0x11b8>
    1474:      	b	0x1590 <perf_unwind_dotnet+0x1590>
    1478:      	ubfx	w3, w25, #24, #4
    147c:      	cbz	w3, 0x1538 <perf_unwind_dotnet+0x1538>
    1480:      	sub	x29, x29, #0xc0
    1484:      	b	0x1540 <perf_unwind_dotnet+0x1540>
    1488:      	ldr	x8, [x21, #0x1110]
    148c:      	cbz	x8, 0x193c <perf_unwind_dotnet+0x193c>
    1490:      	mov	w9, #-0x68              // =-104
    1494:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    1498:      	mov	w8, #0xa                // =10
    149c:      	mov	w11, #0x6               // =6
    14a0:      	add	x0, sp, #0x20
    14a4:      	strh	w8, [sp, #0x60]
    14a8:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    14ac:      	add	x8, x8, #0x0
    14b0:      	mov	w1, #0x42               // =66
    14b4:      	ldp	x9, x10, [x8, #0x20]
    14b8:      	mov	x2, x23
    14bc:      	mov	x4, x25
    14c0:      	stp	x9, x10, [sp, #0x40]
    14c4:      	ldp	x9, x10, [x8, #0x30]
    14c8:      	stp	x9, x10, [sp, #0x50]
    14cc:      	ldp	x9, x10, [x8]
    14d0:      	stp	x9, x10, [sp, #0x20]
    14d4:      	ldp	x9, x8, [x8, #0x10]
    14d8:      	mov	w10, #0x42              // =66
    14dc:      	stp	x9, x8, [sp, #0x30]
    14e0:      	add	x8, sp, #0x20
    14e4:      	ldr	x3, [sp, #0x8]
    14e8:      	blr	x11
    14ec:      	b	0x11d8 <perf_unwind_dotnet+0x11d8>
    14f0:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    14f4:      	add	x8, x8, #0x0
    14f8:      	add	x0, sp, #0x20
    14fc:      	ldp	x9, x10, [x8, #0x10]
    1500:      	mov	w1, #0x2e               // =46
    1504:      	stp	x9, x10, [sp, #0x30]
    1508:      	ldr	x9, [x8, #0x20]
    150c:      	add	x10, sp, #0x20
    1510:      	str	x9, [sp, #0x40]
    1514:      	ldur	x9, [x8, #0x26]
    1518:      	stur	x9, [sp, #0x46]
    151c:      	ldp	x9, x8, [x8]
    1520:      	stp	x9, x8, [sp, #0x20]
    1524:      	mov	w8, #0x2e               // =46
    1528:      	mov	w9, #0x6                // =6
    152c:      	ldr	w2, [sp, #0x68]
    1530:      	blr	x9
    1534:      	b	0x10c4 <perf_unwind_dotnet+0x10c4>
    1538:      	lsr	w3, w25, #28
    153c:      	sub	x29, x29, #0xe0
    1540:      	ldr	x8, [sp, #0x8]
    1544:      	lsl	w9, w3, #2
    1548:      	sub	w9, w9, #0x4
    154c:      	add	x8, x29, x8
    1550:      	add	x25, x8, x9
    1554:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1558:      	ldr	x8, [x8]
    155c:      	ldr	w8, [x8]
    1560:      	cbnz	w8, 0x19cc <perf_unwind_dotnet+0x19cc>
    1564:      	sub	x2, x25, #0x8
    1568:      	mov	w8, #0x8                // =8
    156c:      	mov	w9, #0x70               // =112
    1570:      	add	x10, sp, #0x68
    1574:      	add	x0, sp, #0x68
    1578:      	mov	w1, #0x8                // =8
    157c:      	blr	x9
    1580:      	adrp	x23, 0x1000 <perf_unwind_dotnet+0x1000>
    1584:      	ldr	x23, [x23]
    1588:      	cbnz	x0, 0x844 <perf_unwind_dotnet+0x844>
    158c:      	mov	w23, #0x1f              // =31
    1590:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1594:      	ldr	x8, [x8]
    1598:      	ldr	w8, [x8]
    159c:      	cbnz	w8, 0x16c8 <perf_unwind_dotnet+0x16c8>
    15a0:      	ldr	w8, [x21, #0x2c0]
    15a4:      	cmp	w8, #0x7e
    15a8:      	b.hi	0x8a4 <perf_unwind_dotnet+0x8a4>
    15ac:      	ldr	x9, [sp, #0x68]
    15b0:      	add	w11, w8, #0x1
    15b4:      	sub	x10, x24, x25
    15b8:      	adrp	x0, 0x1000 <perf_unwind_dotnet+0x1000>
    15bc:      	str	w11, [x21, #0x2c0]
    15c0:      	mov	w11, #0x18              // =24
    15c4:      	add	x1, sp, #0x8c
    15c8:      	umaddl	x8, w8, w11, x21
    15cc:      	add	x9, x23, x9, lsl #5
    15d0:      	str	x10, [x8, #0x2d8]
    15d4:      	mov	w10, #0xa               // =10
    15d8:      	strb	w22, [x8, #0x2e1]
    15dc:      	strh	wzr, [x8, #0x2e6]
    15e0:      	strb	w10, [x8, #0x2e0]
    15e4:      	str	x9, [x8, #0x2d0]
    15e8:      	add	x9, x8, #0x2d0
    15ec:      	mov	w8, #0x5b               // =91
    15f0:      	stur	wzr, [x9, #0x12]
    15f4:      	str	w8, [sp, #0x8c]
    15f8:      	mov	w8, #0x1                // =1
    15fc:      	add	x9, sp, #0x8c
    1600:      	ldr	x0, [x0]
    1604:      	blr	x8
    1608:      	cbz	x0, 0x1624 <perf_unwind_dotnet+0x1624>
    160c:      	ldr	x8, [x0]
    1610:      	adrp	x23, 0x1000 <perf_unwind_dotnet+0x1000>
    1614:      	add	x8, x8, #0x1
    1618:      	str	x8, [x0]
    161c:      	ldr	x23, [x23]
    1620:      	b	0x1634 <perf_unwind_dotnet+0x1634>
    1624:      	adrp	x23, 0x1000 <perf_unwind_dotnet+0x1000>
    1628:      	ldr	x23, [x23]
    162c:      	ldr	w8, [x23]
    1630:      	cbnz	w8, 0x18f4 <perf_unwind_dotnet+0x18f4>
    1634:      	ldr	x11, [sp, #0x10]
    1638:      	ldr	x29, [x11]
    163c:      	ldr	w8, [x23]
    1640:      	cbz	x29, 0x16a8 <perf_unwind_dotnet+0x16a8>
    1644:      	cbnz	w8, 0x1730 <perf_unwind_dotnet+0x1730>
    1648:      	lsr	x8, x29, #56
    164c:      	cbz	x8, 0x177c <perf_unwind_dotnet+0x177c>
    1650:      	adrp	x23, 0x1000 <perf_unwind_dotnet+0x1000>
    1654:      	adrp	x24, 0x1000 <perf_unwind_dotnet+0x1000>
    1658:      	ldr	x23, [x23]
    165c:      	ldr	x24, [x24]
    1660:      	ldr	w8, [x23]
    1664:      	cbz	w8, 0xa38 <perf_unwind_dotnet+0xa38>
    1668:      	mov	w8, #0xa                // =10
    166c:      	add	x0, sp, #0x20
    1670:      	mov	w1, #0x22               // =34
    1674:      	strh	w8, [sp, #0x40]
    1678:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    167c:      	add	x8, x8, #0x0
    1680:      	mov	x2, x29
    1684:      	ldp	x9, x10, [x8]
    1688:      	stp	x9, x10, [sp, #0x20]
    168c:      	ldp	x9, x8, [x8, #0x10]
    1690:      	add	x10, sp, #0x20
    1694:      	stp	x9, x8, [sp, #0x30]
    1698:      	mov	w8, #0x22               // =34
    169c:      	mov	w9, #0x6                // =6
    16a0:      	blr	x9
    16a4:      	b	0xa38 <perf_unwind_dotnet+0xa38>
    16a8:      	adrp	x24, 0x1000 <perf_unwind_dotnet+0x1000>
    16ac:      	ldr	x24, [x24]
    16b0:      	cbnz	w8, 0x4d6c <perf_unwind_dotnet+0x4d6c>
    16b4:      	mov	w8, #0x1                // =1
    16b8:      	mov	w25, wzr
    16bc:      	str	w8, [x21, #0xf18]
    16c0:      	mov	w8, #0xfad              // =4013
    16c4:      	b	0x4624 <perf_unwind_dotnet+0x4624>
    16c8:      	mov	w8, #0x786c             // =30828
    16cc:      	sub	x4, x24, x25
    16d0:      	add	x0, sp, #0x20
    16d4:      	mov	w1, #0x43               // =67
    16d8:      	mov	x2, x25
    16dc:      	movk	w8, #0xa, lsl #16
    16e0:      	stur	w8, [sp, #0x5f]
    16e4:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    16e8:      	add	x8, x8, #0x0
    16ec:      	ldp	x9, x10, [x8, #0x20]
    16f0:      	stp	x9, x10, [sp, #0x40]
    16f4:      	ldp	x9, x10, [x8, #0x30]
    16f8:      	stp	x9, x10, [sp, #0x50]
    16fc:      	ldp	x9, x10, [x8]
    1700:      	stp	x9, x10, [sp, #0x20]
    1704:      	ldp	x9, x8, [x8, #0x10]
    1708:      	add	x10, sp, #0x20
    170c:      	stp	x9, x8, [sp, #0x30]
    1710:      	mov	w8, #0x43               // =67
    1714:      	mov	w9, #0x6                // =6
    1718:      	ldr	x3, [sp, #0x68]
    171c:      	blr	x9
    1720:      	ldr	w8, [x21, #0x2c0]
    1724:      	cmp	w8, #0x7e
    1728:      	b.hi	0x8a4 <perf_unwind_dotnet+0x8a4>
    172c:      	b	0x15ac <perf_unwind_dotnet+0x15ac>
    1730:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1734:      	add	x8, x8, #0x0
    1738:      	strb	wzr, [sp, #0x50]
    173c:      	add	x0, sp, #0x20
    1740:      	ldp	x9, x10, [x8, #0x10]
    1744:      	mov	w1, #0x31               // =49
    1748:      	stp	x9, x10, [sp, #0x30]
    174c:      	ldp	x9, x10, [x8, #0x20]
    1750:      	stp	x9, x10, [sp, #0x40]
    1754:      	ldp	x9, x8, [x8]
    1758:      	add	x10, sp, #0x20
    175c:      	stp	x9, x8, [sp, #0x20]
    1760:      	mov	w8, #0x31               // =49
    1764:      	mov	w9, #0x6                // =6
    1768:      	ldr	w2, [x21, #0x2c0]
    176c:      	blr	x9
    1770:      	ldr	x29, [x21, #0xed0]
    1774:      	lsr	x8, x29, #56
    1778:      	cbnz	x8, 0x1650 <perf_unwind_dotnet+0x1650>
    177c:      	cmp	x29, #0x1, lsl #12      // =0x1000
    1780:      	b.hs	0x17dc <perf_unwind_dotnet+0x17dc>
    1784:      	adrp	x23, 0x1000 <perf_unwind_dotnet+0x1000>
    1788:      	adrp	x24, 0x1000 <perf_unwind_dotnet+0x1000>
    178c:      	ldr	x23, [x23]
    1790:      	ldr	x24, [x24]
    1794:      	ldr	w8, [x23]
    1798:      	cbz	w8, 0xaec <perf_unwind_dotnet+0xaec>
    179c:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    17a0:      	add	x8, x8, #0x0
    17a4:      	add	x0, sp, #0x20
    17a8:      	ldp	x9, x10, [x8]
    17ac:      	mov	w1, #0x1e               // =30
    17b0:      	mov	x2, x29
    17b4:      	stp	x9, x10, [sp, #0x20]
    17b8:      	ldr	x9, [x8, #0x10]
    17bc:      	ldur	x8, [x8, #0x16]
    17c0:      	add	x10, sp, #0x20
    17c4:      	str	x9, [sp, #0x30]
    17c8:      	stur	x8, [sp, #0x36]
    17cc:      	mov	w8, #0x1e               // =30
    17d0:      	mov	w9, #0x6                // =6
    17d4:      	blr	x9
    17d8:      	b	0xaec <perf_unwind_dotnet+0xaec>
    17dc:      	ldr	w8, [x21]
    17e0:      	mov	w9, #0x60               // =96
    17e4:      	adrp	x0, 0x1000 <perf_unwind_dotnet+0x1000>
    17e8:      	add	x1, sp, #0x70
    17ec:      	rev	w8, w8
    17f0:      	stp	w9, w8, [sp, #0x70]
    17f4:      	rev	x8, x29
    17f8:      	add	x9, sp, #0x70
    17fc:      	str	x8, [sp, #0x78]
    1800:      	mov	w8, #0x1                // =1
    1804:      	ldr	x0, [x0]
    1808:      	blr	x8
    180c:      	cbz	x0, 0x4eec <perf_unwind_dotnet+0x4eec>
    1810:      	ldr	x8, [x0, #0x8]
    1814:      	and	x9, x8, #0xffffffffffffff
    1818:      	lsr	x25, x8, #56
    181c:      	str	x9, [x21, #0xf10]
    1820:      	ldr	x8, [x0]
    1824:      	str	x8, [x21, #0xf00]
    1828:      	sub	x8, x29, x9
    182c:      	str	x8, [x21, #0xf08]
    1830:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1834:      	ldr	x8, [x8]
    1838:      	ldr	w8, [x8]
    183c:      	cbnz	w8, 0x1a88 <perf_unwind_dotnet+0x1a88>
    1840:      	cmp	w25, #0x1
    1844:      	b.ne	0x1cbc <perf_unwind_dotnet+0x1cbc>
    1848:      	ldr	x8, [x21, #0xf00]
    184c:      	adrp	x0, 0x1000 <perf_unwind_dotnet+0x1000>
    1850:      	ldr	x22, [x21, #0xf08]
    1854:      	mov	w9, #0x1                // =1
    1858:      	add	x1, sp, #0x70
    185c:      	mov	w25, #0x1               // =1
    1860:      	str	x8, [sp, #0x70]
    1864:      	add	x8, sp, #0x70
    1868:      	ldr	x0, [x0]
    186c:      	blr	x9
    1870:      	cbz	x0, 0x18e8 <perf_unwind_dotnet+0x18e8>
    1874:      	ldr	x8, [x0]
    1878:      	mov	x23, x0
    187c:      	cmp	x8, x22
    1880:      	b.hi	0x1890 <perf_unwind_dotnet+0x1890>
    1884:      	ldr	x8, [x23, #0x8]
    1888:      	cmp	x8, x22
    188c:      	b.hs	0x18a8 <perf_unwind_dotnet+0x18a8>
    1890:      	ldr	x8, [x23, #0x10]
    1894:      	cmp	x8, x22
    1898:      	b.hi	0x18d8 <perf_unwind_dotnet+0x18d8>
    189c:      	ldr	x8, [x23, #0x18]
    18a0:      	cmp	x8, x22
    18a4:      	b.lo	0x18d8 <perf_unwind_dotnet+0x18d8>
    18a8:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    18ac:      	ldr	x8, [x8]
    18b0:      	ldr	w8, [x8]
    18b4:      	cbnz	w8, 0x1c2c <perf_unwind_dotnet+0x1c2c>
    18b8:      	ldrh	w8, [x23, #0x20]
    18bc:      	ldr	w9, [x21, #0x1370]
    18c0:      	lsr	w8, w9, w8
    18c4:      	tbz	w8, #0x0, 0x1c78 <perf_unwind_dotnet+0x1c78>
    18c8:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    18cc:      	ldr	x8, [x8]
    18d0:      	ldr	w8, [x8]
    18d4:      	cbnz	w8, 0x1fd4 <perf_unwind_dotnet+0x1fd4>
    18d8:      	mov	w25, #0x1               // =1
    18dc:      	cmp	w25, #0x8
    18e0:      	b.eq	0x1cc4 <perf_unwind_dotnet+0x1cc4>
    18e4:      	b	0x4f64 <perf_unwind_dotnet+0x4f64>
    18e8:      	cmp	w25, #0x8
    18ec:      	b.eq	0x1cc4 <perf_unwind_dotnet+0x1cc4>
    18f0:      	b	0x4f64 <perf_unwind_dotnet+0x4f64>
    18f4:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    18f8:      	add	x8, x8, #0x0
    18fc:      	add	x0, sp, #0x20
    1900:      	ldp	x9, x10, [x8, #0x10]
    1904:      	mov	w1, #0x2e               // =46
    1908:      	stp	x9, x10, [sp, #0x30]
    190c:      	ldr	x9, [x8, #0x20]
    1910:      	add	x10, sp, #0x20
    1914:      	str	x9, [sp, #0x40]
    1918:      	ldur	x9, [x8, #0x26]
    191c:      	stur	x9, [sp, #0x46]
    1920:      	ldp	x9, x8, [x8]
    1924:      	stp	x9, x8, [sp, #0x20]
    1928:      	mov	w8, #0x2e               // =46
    192c:      	mov	w9, #0x6                // =6
    1930:      	ldr	w2, [sp, #0x8c]
    1934:      	blr	x9
    1938:      	b	0x1634 <perf_unwind_dotnet+0x1634>
    193c:      	ldr	x8, [x21, #0x1108]
    1940:      	cbz	x8, 0x1a78 <perf_unwind_dotnet+0x1a78>
    1944:      	mov	w9, #-0x66              // =-102
    1948:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    194c:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1950:      	add	x8, x8, #0x0
    1954:      	add	x0, sp, #0x20
    1958:      	ldp	x9, x10, [x8, #0x20]
    195c:      	and	x2, x23, #0xfffffffffffffffc
    1960:      	mov	w1, #0x36               // =54
    1964:      	mov	w3, w25
    1968:      	stp	x9, x10, [sp, #0x40]
    196c:      	ldur	x9, [x8, #0x2e]
    1970:      	stur	x9, [sp, #0x4e]
    1974:      	ldp	x9, x10, [x8]
    1978:      	stp	x9, x10, [sp, #0x20]
    197c:      	ldp	x8, x9, [x8, #0x10]
    1980:      	add	x10, sp, #0x20
    1984:      	stp	x8, x9, [sp, #0x30]
    1988:      	mov	w8, #0x36               // =54
    198c:      	mov	w9, #0x6                // =6
    1990:      	blr	x9
    1994:      	mov	w8, #0x1c               // =28
    1998:      	bic	w8, w8, w23, lsr #3
    199c:      	lsr	w25, w25, w8
    19a0:      	cbnz	w25, 0x12a0 <perf_unwind_dotnet+0x12a0>
    19a4:      	and	x8, x23, #0xffffffffffffff00
    19a8:      	ldr	w25, [x21, #0x1168]
    19ac:      	sub	x23, x8, #0x20
    19b0:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    19b4:      	ldr	x8, [x8]
    19b8:      	ldr	w8, [x8]
    19bc:      	cbnz	w8, 0x1b30 <perf_unwind_dotnet+0x1b30>
    19c0:      	cbz	w25, 0x1b7c <perf_unwind_dotnet+0x1b7c>
    19c4:      	mov	w3, wzr
    19c8:      	b	0x60b4 <perf_unwind_dotnet+0x60b4>
    19cc:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    19d0:      	add	x8, x8, #0x0
    19d4:      	add	x0, sp, #0x20
    19d8:      	ldp	x9, x10, [x8, #0x10]
    19dc:      	mov	w1, #0x2e               // =46
    19e0:      	mov	x2, x29
    19e4:      	mov	x4, x25
    19e8:      	stp	x9, x10, [sp, #0x30]
    19ec:      	ldr	x9, [x8, #0x20]
    19f0:      	add	x10, sp, #0x20
    19f4:      	str	x9, [sp, #0x40]
    19f8:      	ldur	x9, [x8, #0x26]
    19fc:      	stur	x9, [sp, #0x46]
    1a00:      	ldp	x9, x8, [x8]
    1a04:      	stp	x9, x8, [sp, #0x20]
    1a08:      	mov	w8, #0x2e               // =46
    1a0c:      	mov	w9, #0x6                // =6
    1a10:      	blr	x9
    1a14:      	b	0x1564 <perf_unwind_dotnet+0x1564>
    1a18:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1a1c:      	add	x8, x8, #0x0
    1a20:      	add	x0, sp, #0x20
    1a24:      	ldp	x9, x10, [x8, #0x10]
    1a28:      	mov	w1, #0x2e               // =46
    1a2c:      	stp	x9, x10, [sp, #0x30]
    1a30:      	ldr	x9, [x8, #0x20]
    1a34:      	add	x10, sp, #0x20
    1a38:      	str	x9, [sp, #0x40]
    1a3c:      	ldur	x9, [x8, #0x26]
    1a40:      	stur	x9, [sp, #0x46]
    1a44:      	ldp	x9, x8, [x8]
    1a48:      	stp	x9, x8, [sp, #0x20]
    1a4c:      	mov	w8, #0x2e               // =46
    1a50:      	mov	w9, #0x6                // =6
    1a54:      	ldr	w2, [sp, #0x8c]
    1a58:      	blr	x9
    1a5c:      	mov	w22, wzr
    1a60:      	mov	w2, #0x1772             // =6002
    1a64:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1a68:      	ldr	x8, [x8]
    1a6c:      	ldr	w8, [x8]
    1a70:      	cbz	w8, 0x12e4 <perf_unwind_dotnet+0x12e4>
    1a74:      	b	0x61e0 <perf_unwind_dotnet+0x61e0>
    1a78:      	ldr	x8, [x21, #0x1100]
    1a7c:      	cbz	x8, 0x1bfc <perf_unwind_dotnet+0x1bfc>
    1a80:      	mov	w9, #-0x64              // =-100
    1a84:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    1a88:      	mov	w8, #0xa                // =10
    1a8c:      	add	x0, sp, #0x20
    1a90:      	mov	w1, #0x32               // =50
    1a94:      	strh	w8, [sp, #0x50]
    1a98:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1a9c:      	add	x8, x8, #0x0
    1aa0:      	mov	x2, x29
    1aa4:      	ldp	x9, x10, [x8, #0x10]
    1aa8:      	mov	w4, w25
    1aac:      	stp	x9, x10, [sp, #0x30]
    1ab0:      	ldp	x9, x10, [x8, #0x20]
    1ab4:      	stp	x9, x10, [sp, #0x40]
    1ab8:      	ldp	x9, x8, [x8]
    1abc:      	add	x10, sp, #0x20
    1ac0:      	stp	x9, x8, [sp, #0x20]
    1ac4:      	mov	w8, #0x32               // =50
    1ac8:      	mov	w9, #0x6                // =6
    1acc:      	ldr	x3, [x21, #0xf00]
    1ad0:      	blr	x9
    1ad4:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1ad8:      	ldr	x8, [x8]
    1adc:      	ldr	w8, [x8]
    1ae0:      	cbz	w8, 0x1840 <perf_unwind_dotnet+0x1840>
    1ae4:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1ae8:      	add	x8, x8, #0x0
    1aec:      	add	x0, sp, #0x20
    1af0:      	ldp	x9, x10, [x8, #0x10]
    1af4:      	mov	w1, #0x2f               // =47
    1af8:      	stp	x9, x10, [sp, #0x30]
    1afc:      	ldr	x9, [x8, #0x20]
    1b00:      	add	x10, sp, #0x20
    1b04:      	str	x9, [sp, #0x40]
    1b08:      	ldur	x9, [x8, #0x27]
    1b0c:      	stur	x9, [sp, #0x47]
    1b10:      	ldp	x9, x8, [x8]
    1b14:      	stp	x9, x8, [sp, #0x20]
    1b18:      	mov	w8, #0x2f               // =47
    1b1c:      	mov	w9, #0x6                // =6
    1b20:      	ldr	x2, [x21, #0xf10]
    1b24:      	ldr	x3, [x21, #0xf08]
    1b28:      	blr	x9
    1b2c:      	b	0x1840 <perf_unwind_dotnet+0x1840>
    1b30:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1b34:      	add	x8, x8, #0x0
    1b38:      	add	x0, sp, #0x20
    1b3c:      	ldp	x9, x10, [x8, #0x20]
    1b40:      	mov	w1, #0x37               // =55
    1b44:      	mov	x2, x23
    1b48:      	mov	w3, w25
    1b4c:      	stp	x9, x10, [sp, #0x40]
    1b50:      	ldur	x9, [x8, #0x2f]
    1b54:      	stur	x9, [sp, #0x4f]
    1b58:      	ldp	x9, x10, [x8]
    1b5c:      	stp	x9, x10, [sp, #0x20]
    1b60:      	ldp	x8, x9, [x8, #0x10]
    1b64:      	add	x10, sp, #0x20
    1b68:      	stp	x8, x9, [sp, #0x30]
    1b6c:      	mov	w8, #0x37               // =55
    1b70:      	mov	w9, #0x6                // =6
    1b74:      	blr	x9
    1b78:      	cbnz	w25, 0x19c4 <perf_unwind_dotnet+0x19c4>
    1b7c:      	ldr	x8, [x21, #0x1160]
    1b80:      	cbz	x8, 0x1b8c <perf_unwind_dotnet+0x1b8c>
    1b84:      	mov	w9, #-0x7c              // =-124
    1b88:      	b	0x609c <perf_unwind_dotnet+0x609c>
    1b8c:      	ldr	x8, [x21, #0x1158]
    1b90:      	cbz	x8, 0x1b9c <perf_unwind_dotnet+0x1b9c>
    1b94:      	mov	w9, #-0x7a              // =-122
    1b98:      	b	0x609c <perf_unwind_dotnet+0x609c>
    1b9c:      	ldr	x8, [x21, #0x1150]
    1ba0:      	cbz	x8, 0x1bac <perf_unwind_dotnet+0x1bac>
    1ba4:      	mov	w9, #-0x78              // =-120
    1ba8:      	b	0x609c <perf_unwind_dotnet+0x609c>
    1bac:      	ldr	x8, [x21, #0x1148]
    1bb0:      	cbz	x8, 0x1bbc <perf_unwind_dotnet+0x1bbc>
    1bb4:      	mov	w9, #-0x76              // =-118
    1bb8:      	b	0x609c <perf_unwind_dotnet+0x609c>
    1bbc:      	ldr	x8, [x21, #0x1140]
    1bc0:      	cbz	x8, 0x1bcc <perf_unwind_dotnet+0x1bcc>
    1bc4:      	mov	w9, #-0x74              // =-116
    1bc8:      	b	0x609c <perf_unwind_dotnet+0x609c>
    1bcc:      	ldr	x8, [x21, #0x1138]
    1bd0:      	cbz	x8, 0x1bdc <perf_unwind_dotnet+0x1bdc>
    1bd4:      	mov	w9, #-0x72              // =-114
    1bd8:      	b	0x609c <perf_unwind_dotnet+0x609c>
    1bdc:      	ldr	x8, [x21, #0x1130]
    1be0:      	cbz	x8, 0x1bec <perf_unwind_dotnet+0x1bec>
    1be4:      	mov	w9, #-0x70              // =-112
    1be8:      	b	0x609c <perf_unwind_dotnet+0x609c>
    1bec:      	ldr	x8, [x21, #0x1128]
    1bf0:      	cbz	x8, 0x1c0c <perf_unwind_dotnet+0x1c0c>
    1bf4:      	mov	w9, #-0x6e              // =-110
    1bf8:      	b	0x609c <perf_unwind_dotnet+0x609c>
    1bfc:      	ldr	x8, [x21, #0x10f8]
    1c00:      	cbz	x8, 0x1c1c <perf_unwind_dotnet+0x1c1c>
    1c04:      	mov	w9, #-0x62              // =-98
    1c08:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    1c0c:      	ldr	x8, [x21, #0x1120]
    1c10:      	cbz	x8, 0x1fc4 <perf_unwind_dotnet+0x1fc4>
    1c14:      	mov	w9, #-0x6c              // =-108
    1c18:      	b	0x609c <perf_unwind_dotnet+0x609c>
    1c1c:      	ldr	x8, [x21, #0x10f0]
    1c20:      	cbz	x8, 0x2020 <perf_unwind_dotnet+0x2020>
    1c24:      	mov	w9, #-0x60              // =-96
    1c28:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    1c2c:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1c30:      	add	x8, x8, #0x0
    1c34:      	add	x0, sp, #0x20
    1c38:      	ldp	x9, x10, [x8]
    1c3c:      	mov	w1, #0x1e               // =30
    1c40:      	stp	x9, x10, [sp, #0x20]
    1c44:      	ldr	x9, [x8, #0x10]
    1c48:      	ldur	x8, [x8, #0x16]
    1c4c:      	add	x10, sp, #0x20
    1c50:      	str	x9, [sp, #0x30]
    1c54:      	stur	x8, [sp, #0x36]
    1c58:      	mov	w8, #0x1e               // =30
    1c5c:      	mov	w9, #0x6                // =6
    1c60:      	ldrh	w2, [x23, #0x20]
    1c64:      	blr	x9
    1c68:      	ldrh	w8, [x23, #0x20]
    1c6c:      	ldr	w9, [x21, #0x1370]
    1c70:      	lsr	w8, w9, w8
    1c74:      	tbnz	w8, #0x0, 0x18c8 <perf_unwind_dotnet+0x18c8>
    1c78:      	str	wzr, [sp, #0x68]
    1c7c:      	adrp	x0, 0x1000 <perf_unwind_dotnet+0x1000>
    1c80:      	mov	w8, #0x1                // =1
    1c84:      	add	x9, sp, #0x68
    1c88:      	ldr	x0, [x0]
    1c8c:      	add	x1, sp, #0x68
    1c90:      	blr	x8
    1c94:      	cbz	x0, 0x1ca8 <perf_unwind_dotnet+0x1ca8>
    1c98:      	ldr	x8, [x0]
    1c9c:      	add	x8, x8, #0x1
    1ca0:      	str	x8, [x0]
    1ca4:      	b	0x1cb8 <perf_unwind_dotnet+0x1cb8>
    1ca8:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1cac:      	ldr	x8, [x8]
    1cb0:      	ldr	w8, [x8]
    1cb4:      	cbnz	w8, 0x210c <perf_unwind_dotnet+0x210c>
    1cb8:      	ldrh	w25, [x23, #0x20]
    1cbc:      	cmp	w25, #0x8
    1cc0:      	b.ne	0x4f64 <perf_unwind_dotnet+0x4f64>
    1cc4:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1cc8:      	ldr	x25, [x21, #0xed8]
    1ccc:      	ldr	x29, [x21, #0xee0]
    1cd0:      	ldr	x24, [x21, #0xed0]
    1cd4:      	ldrb	w22, [x21, #0xf20]
    1cd8:      	ldr	x8, [x8]
    1cdc:      	ldr	w8, [x8]
    1ce0:      	cbnz	w8, 0x1f50 <perf_unwind_dotnet+0x1f50>
    1ce4:      	cmp	x29, x25
    1ce8:      	b.lo	0x45cc <perf_unwind_dotnet+0x45cc>
    1cec:      	add	x8, x25, #0x2, lsl #12  // =0x2000
    1cf0:      	cmp	x29, x8
    1cf4:      	b.hs	0x45cc <perf_unwind_dotnet+0x45cc>
    1cf8:      	ldr	x23, [x21, #0xf00]
    1cfc:      	ldr	x25, [x21, #0xf10]
    1d00:      	mov	w8, #0x101              // =257
    1d04:      	str	x24, [sp, #0x68]
    1d08:      	strh	w8, [x21, #0xf20]
    1d0c:      	and	x8, x23, #0xffffffffffffff80
    1d10:      	cmp	x8, #0x80
    1d14:      	b.ne	0x1d4c <perf_unwind_dotnet+0x1d4c>
    1d18:      	ldr	x8, [x21, #0xed8]
    1d1c:      	mov	w9, #0x8                // =8
    1d20:      	mov	w10, #0x70              // =112
    1d24:      	ldr	x0, [sp, #0x10]
    1d28:      	mov	w1, #0x8                // =8
    1d2c:      	ldr	x2, [x21, #0xed8]
    1d30:      	blr	x10
    1d34:      	cbnz	x0, 0x1e0 <perf_unwind_dotnet+0x1e0>
    1d38:      	ldr	x8, [x21, #0xed8]
    1d3c:      	and	x23, x23, #0x7f
    1d40:      	add	x8, x8, #0x8
    1d44:      	str	x8, [x21, #0xed8]
    1d48:      	b	0x21ac <perf_unwind_dotnet+0x21ac>
    1d4c:      	mov	w8, #0x10               // =16
    1d50:      	mov	w9, #0x70               // =112
    1d54:      	add	x10, sp, #0x70
    1d58:      	add	x0, sp, #0x70
    1d5c:      	mov	w1, #0x10               // =16
    1d60:      	mov	x2, x29
    1d64:      	blr	x9
    1d68:      	cbnz	x0, 0x27c <perf_unwind_dotnet+0x27c>
    1d6c:      	add	x8, x29, #0x10
    1d70:      	str	x8, [x21, #0xed8]
    1d74:      	ldp	x8, x9, [sp, #0x70]
    1d78:      	str	x8, [x21, #0xee0]
    1d7c:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1d80:      	str	x9, [x21, #0xed0]
    1d84:      	ldr	x8, [x8]
    1d88:      	ldr	w8, [x8]
    1d8c:      	cbnz	w8, 0x2030 <perf_unwind_dotnet+0x2030>
    1d90:      	cmp	x23, #0x100
    1d94:      	b.lo	0x21ac <perf_unwind_dotnet+0x21ac>
    1d98:      	ldr	x8, [x21, #0xf10]
    1d9c:      	ldr	x25, [x21, #0xf00]
    1da0:      	sub	x23, x24, x8
    1da4:      	str	x8, [sp, #0x8]
    1da8:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1dac:      	ldr	x8, [x8]
    1db0:      	ldr	w8, [x8]
    1db4:      	cbnz	w8, 0x20b4 <perf_unwind_dotnet+0x20b4>
    1db8:      	lsr	x8, x23, #8
    1dbc:      	mov	w9, #0x7f               // =127
    1dc0:      	lsr	x10, x23, #15
    1dc4:      	mov	w1, #0x200              // =512
    1dc8:      	sub	w9, w9, w8
    1dcc:      	lsl	x8, x8, #2
    1dd0:      	cmp	x10, #0x0
    1dd4:      	sub	x8, x8, #0x3fc
    1dd8:      	and	x9, x9, #0x7f
    1ddc:      	csel	x8, x8, xzr, ne
    1de0:      	add	x2, x8, x25
    1de4:      	csel	x8, xzr, x9, ne
    1de8:      	ldr	x9, [sp, #0x18]
    1dec:      	add	x0, x9, x8, lsl #2
    1df0:      	mov	w8, #0x200              // =512
    1df4:      	mov	w9, #0x70               // =112
    1df8:      	blr	x9
    1dfc:      	cbz	x0, 0x1e5c <perf_unwind_dotnet+0x1e5c>
    1e00:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1e04:      	ldr	x8, [x8]
    1e08:      	ldr	w8, [x8]
    1e0c:      	cbnz	w8, 0x64e4 <perf_unwind_dotnet+0x64e4>
    1e10:      	mov	w8, #0x5e               // =94
    1e14:      	adrp	x0, 0x1000 <perf_unwind_dotnet+0x1000>
    1e18:      	add	x9, sp, #0x8c
    1e1c:      	str	w8, [sp, #0x8c]
    1e20:      	mov	w8, #0x1                // =1
    1e24:      	add	x1, sp, #0x8c
    1e28:      	ldr	x0, [x0]
    1e2c:      	blr	x8
    1e30:      	cbz	x0, 0x1e9c <perf_unwind_dotnet+0x1e9c>
    1e34:      	ldr	x8, [x0]
    1e38:      	add	x8, x8, #0x1
    1e3c:      	str	x8, [x0]
    1e40:      	mov	w22, wzr
    1e44:      	mov	w2, #0x1772             // =6002
    1e48:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1e4c:      	ldr	x8, [x8]
    1e50:      	ldr	w8, [x8]
    1e54:      	cbz	w8, 0x1ec4 <perf_unwind_dotnet+0x1ec4>
    1e58:      	b	0x65a4 <perf_unwind_dotnet+0x65a4>
    1e5c:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1e60:      	ldr	w25, [x21, #0x116c]
    1e64:      	ldr	x8, [x8]
    1e68:      	ldr	w8, [x8]
    1e6c:      	cbnz	w8, 0x24dc <perf_unwind_dotnet+0x24dc>
    1e70:      	mov	w8, #0x1c               // =28
    1e74:      	bic	w8, w8, w23, lsr #3
    1e78:      	lsr	w25, w25, w8
    1e7c:      	cbz	w25, 0x2534 <perf_unwind_dotnet+0x2534>
    1e80:      	and	x29, x23, #0xffffffffffffffe0
    1e84:      	ands	w3, w25, #0xf
    1e88:      	b.ne	0x215c <perf_unwind_dotnet+0x215c>
    1e8c:      	ubfx	w3, w25, #4, #4
    1e90:      	cbz	w3, 0x1f30 <perf_unwind_dotnet+0x1f30>
    1e94:      	sub	x29, x29, #0x20
    1e98:      	b	0x215c <perf_unwind_dotnet+0x215c>
    1e9c:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1ea0:      	ldr	x8, [x8]
    1ea4:      	ldr	w8, [x8]
    1ea8:      	cbnz	w8, 0x25a8 <perf_unwind_dotnet+0x25a8>
    1eac:      	mov	w22, wzr
    1eb0:      	mov	w2, #0x1772             // =6002
    1eb4:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1eb8:      	ldr	x8, [x8]
    1ebc:      	ldr	w8, [x8]
    1ec0:      	cbnz	w8, 0x65a4 <perf_unwind_dotnet+0x65a4>
    1ec4:      	cbz	w22, 0x621c <perf_unwind_dotnet+0x621c>
    1ec8:      	ldr	w8, [x21, #0x2c0]
    1ecc:      	adrp	x23, 0x1000 <perf_unwind_dotnet+0x1000>
    1ed0:      	adrp	x24, 0x1000 <perf_unwind_dotnet+0x1000>
    1ed4:      	ldr	x23, [x23]
    1ed8:      	ldr	x24, [x24]
    1edc:      	cmp	w8, #0x7e
    1ee0:      	b.hi	0x49c <perf_unwind_dotnet+0x49c>
    1ee4:      	add	w9, w8, #0x1
    1ee8:      	mov	w10, #0x8a              // =138
    1eec:      	str	w9, [x21, #0x2c0]
    1ef0:      	mov	w9, #0x18               // =24
    1ef4:      	umaddl	x8, w8, w9, x21
    1ef8:      	mov	w9, #0x1773             // =6003
    1efc:      	str	x9, [x8, #0x2d8]
    1f00:      	add	x9, x8, #0x2d0
    1f04:      	str	xzr, [x8, #0x2d0]
    1f08:      	strb	w10, [x8, #0x2e0]
    1f0c:      	str	wzr, [x8, #0x2e4]
    1f10:      	stur	wzr, [x9, #0x11]
    1f14:      	ldr	x8, [sp, #0x10]
    1f18:      	ldr	x29, [x8]
    1f1c:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1f20:      	ldr	x8, [x8]
    1f24:      	ldr	w8, [x8]
    1f28:      	cbnz	x29, 0x2278 <perf_unwind_dotnet+0x2278>
    1f2c:      	b	0x4d58 <perf_unwind_dotnet+0x4d58>
    1f30:      	ubfx	w3, w25, #8, #4
    1f34:      	cbz	w3, 0x1f40 <perf_unwind_dotnet+0x1f40>
    1f38:      	sub	x29, x29, #0x40
    1f3c:      	b	0x215c <perf_unwind_dotnet+0x215c>
    1f40:      	ubfx	w3, w25, #12, #4
    1f44:      	cbz	w3, 0x1fa4 <perf_unwind_dotnet+0x1fa4>
    1f48:      	sub	x29, x29, #0x60
    1f4c:      	b	0x215c <perf_unwind_dotnet+0x215c>
    1f50:      	mov	w8, #0x786c             // =30828
    1f54:      	add	x0, sp, #0x20
    1f58:      	mov	w1, #0x23               // =35
    1f5c:      	mov	x2, x24
    1f60:      	mov	x3, x25
    1f64:      	mov	x4, x29
    1f68:      	movk	w8, #0xa, lsl #16
    1f6c:      	stur	w8, [sp, #0x3f]
    1f70:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1f74:      	add	x8, x8, #0x0
    1f78:      	ldp	x9, x10, [x8]
    1f7c:      	stp	x9, x10, [sp, #0x20]
    1f80:      	ldp	x9, x8, [x8, #0x10]
    1f84:      	add	x10, sp, #0x20
    1f88:      	stp	x9, x8, [sp, #0x30]
    1f8c:      	mov	w8, #0x23               // =35
    1f90:      	mov	w9, #0x6                // =6
    1f94:      	blr	x9
    1f98:      	cmp	x29, x25
    1f9c:      	b.hs	0x1cec <perf_unwind_dotnet+0x1cec>
    1fa0:      	b	0x45cc <perf_unwind_dotnet+0x45cc>
    1fa4:      	ubfx	w3, w25, #16, #4
    1fa8:      	cbz	w3, 0x1fb4 <perf_unwind_dotnet+0x1fb4>
    1fac:      	sub	x29, x29, #0x80
    1fb0:      	b	0x215c <perf_unwind_dotnet+0x215c>
    1fb4:      	ubfx	w3, w25, #20, #4
    1fb8:      	cbz	w3, 0x2084 <perf_unwind_dotnet+0x2084>
    1fbc:      	sub	x29, x29, #0xa0
    1fc0:      	b	0x215c <perf_unwind_dotnet+0x215c>
    1fc4:      	ldr	x8, [x21, #0x1118]
    1fc8:      	cbz	x8, 0x2094 <perf_unwind_dotnet+0x2094>
    1fcc:      	mov	w9, #-0x6a              // =-106
    1fd0:      	b	0x609c <perf_unwind_dotnet+0x609c>
    1fd4:      	mov	w8, #0x656e             // =25966
    1fd8:      	add	x0, sp, #0x20
    1fdc:      	mov	w1, #0x1b               // =27
    1fe0:      	movk	w8, #0xa, lsl #16
    1fe4:      	stur	w8, [sp, #0x37]
    1fe8:      	adrp	x8, 0x1000 <perf_unwind_dotnet+0x1000>
    1fec:      	add	x8, x8, #0x0
    1ff0:      	ldp	x9, x10, [x8]
    1ff4:      	ldr	x8, [x8, #0x10]
    1ff8:      	stp	x9, x10, [sp, #0x20]
    1ffc:      	str	x8, [sp, #0x30]
    2000:      	mov	w8, #0x1b               // =27
    2004:      	mov	w9, #0x6                // =6
    2008:      	add	x10, sp, #0x20
    200c:      	blr	x9
    2010:      	mov	w25, #0x1               // =1
    2014:      	cmp	w25, #0x8
    2018:      	b.eq	0x1cc4 <perf_unwind_dotnet+0x1cc4>
    201c:      	b	0x4f64 <perf_unwind_dotnet+0x4f64>
    2020:      	ldr	x8, [x21, #0x10e8]
    2024:      	cbz	x8, 0x20a4 <perf_unwind_dotnet+0x20a4>
    2028:      	mov	w9, #-0x5e              // =-94
    202c:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    2030:      	mov	w8, #0x786c             // =30828
    2034:      	add	x0, sp, #0x20
    2038:      	mov	w1, #0x23               // =35
    203c:      	movk	w8, #0xa, lsl #16
    2040:      	stur	w8, [sp, #0x3f]
    2044:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2048:      	add	x8, x8, #0x0
    204c:      	ldp	x9, x10, [x8]
    2050:      	stp	x9, x10, [sp, #0x20]
    2054:      	ldp	x9, x8, [x8, #0x10]
    2058:      	add	x10, sp, #0x20
    205c:      	stp	x9, x8, [sp, #0x30]
    2060:      	mov	w8, #0x23               // =35
    2064:      	mov	w9, #0x6                // =6
    2068:      	ldr	x2, [x21, #0xed0]
    206c:      	ldr	x3, [x21, #0xed8]
    2070:      	ldr	x4, [x21, #0xee0]
    2074:      	blr	x9
    2078:      	cmp	x23, #0x100
    207c:      	b.hs	0x1d98 <perf_unwind_dotnet+0x1d98>
    2080:      	b	0x21ac <perf_unwind_dotnet+0x21ac>
    2084:      	ubfx	w3, w25, #24, #4
    2088:      	cbz	w3, 0x2154 <perf_unwind_dotnet+0x2154>
    208c:      	sub	x29, x29, #0xc0
    2090:      	b	0x215c <perf_unwind_dotnet+0x215c>
    2094:      	ldr	x8, [x21, #0x1110]
    2098:      	cbz	x8, 0x24bc <perf_unwind_dotnet+0x24bc>
    209c:      	mov	w9, #-0x68              // =-104
    20a0:      	b	0x609c <perf_unwind_dotnet+0x609c>
    20a4:      	ldr	x8, [x21, #0x10e0]
    20a8:      	cbz	x8, 0x24cc <perf_unwind_dotnet+0x24cc>
    20ac:      	mov	w9, #-0x5c              // =-92
    20b0:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    20b4:      	mov	w8, #0xa                // =10
    20b8:      	mov	w11, #0x6               // =6
    20bc:      	add	x0, sp, #0x20
    20c0:      	strh	w8, [sp, #0x60]
    20c4:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    20c8:      	add	x8, x8, #0x0
    20cc:      	mov	w1, #0x42               // =66
    20d0:      	ldp	x9, x10, [x8, #0x20]
    20d4:      	mov	x2, x23
    20d8:      	mov	x4, x25
    20dc:      	stp	x9, x10, [sp, #0x40]
    20e0:      	ldp	x9, x10, [x8, #0x30]
    20e4:      	stp	x9, x10, [sp, #0x50]
    20e8:      	ldp	x9, x10, [x8]
    20ec:      	stp	x9, x10, [sp, #0x20]
    20f0:      	ldp	x9, x8, [x8, #0x10]
    20f4:      	mov	w10, #0x42              // =66
    20f8:      	stp	x9, x8, [sp, #0x30]
    20fc:      	add	x8, sp, #0x20
    2100:      	ldr	x3, [sp, #0x8]
    2104:      	blr	x11
    2108:      	b	0x1db8 <perf_unwind_dotnet+0x1db8>
    210c:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2110:      	add	x8, x8, #0x0
    2114:      	add	x0, sp, #0x20
    2118:      	ldp	x9, x10, [x8, #0x10]
    211c:      	mov	w1, #0x2e               // =46
    2120:      	stp	x9, x10, [sp, #0x30]
    2124:      	ldr	x9, [x8, #0x20]
    2128:      	add	x10, sp, #0x20
    212c:      	str	x9, [sp, #0x40]
    2130:      	ldur	x9, [x8, #0x26]
    2134:      	stur	x9, [sp, #0x46]
    2138:      	ldp	x9, x8, [x8]
    213c:      	stp	x9, x8, [sp, #0x20]
    2140:      	mov	w8, #0x2e               // =46
    2144:      	mov	w9, #0x6                // =6
    2148:      	ldr	w2, [sp, #0x68]
    214c:      	blr	x9
    2150:      	b	0x1cb8 <perf_unwind_dotnet+0x1cb8>
    2154:      	lsr	w3, w25, #28
    2158:      	sub	x29, x29, #0xe0
    215c:      	ldr	x8, [sp, #0x8]
    2160:      	lsl	w9, w3, #2
    2164:      	sub	w9, w9, #0x4
    2168:      	add	x8, x29, x8
    216c:      	add	x25, x8, x9
    2170:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2174:      	ldr	x8, [x8]
    2178:      	ldr	w8, [x8]
    217c:      	cbnz	w8, 0x255c <perf_unwind_dotnet+0x255c>
    2180:      	sub	x2, x25, #0x8
    2184:      	mov	w8, #0x8                // =8
    2188:      	mov	w9, #0x70               // =112
    218c:      	add	x10, sp, #0x68
    2190:      	add	x0, sp, #0x68
    2194:      	mov	w1, #0x8                // =8
    2198:      	blr	x9
    219c:      	adrp	x23, 0x2000 <perf_unwind_dotnet+0x2000>
    21a0:      	ldr	x23, [x23]
    21a4:      	cbnz	x0, 0x844 <perf_unwind_dotnet+0x844>
    21a8:      	mov	w23, #0x1f              // =31
    21ac:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    21b0:      	ldr	x8, [x8]
    21b4:      	ldr	w8, [x8]
    21b8:      	cbnz	w8, 0x23a4 <perf_unwind_dotnet+0x23a4>
    21bc:      	ldr	w8, [x21, #0x2c0]
    21c0:      	cmp	w8, #0x7e
    21c4:      	b.hi	0x8a4 <perf_unwind_dotnet+0x8a4>
    21c8:      	ldr	x9, [sp, #0x68]
    21cc:      	add	w11, w8, #0x1
    21d0:      	sub	x10, x24, x25
    21d4:      	adrp	x0, 0x2000 <perf_unwind_dotnet+0x2000>
    21d8:      	str	w11, [x21, #0x2c0]
    21dc:      	mov	w11, #0x18              // =24
    21e0:      	add	x1, sp, #0x8c
    21e4:      	umaddl	x8, w8, w11, x21
    21e8:      	add	x9, x23, x9, lsl #5
    21ec:      	str	x10, [x8, #0x2d8]
    21f0:      	mov	w10, #0xa               // =10
    21f4:      	strb	w22, [x8, #0x2e1]
    21f8:      	strh	wzr, [x8, #0x2e6]
    21fc:      	strb	w10, [x8, #0x2e0]
    2200:      	str	x9, [x8, #0x2d0]
    2204:      	add	x9, x8, #0x2d0
    2208:      	mov	w8, #0x5b               // =91
    220c:      	stur	wzr, [x9, #0x12]
    2210:      	str	w8, [sp, #0x8c]
    2214:      	mov	w8, #0x1                // =1
    2218:      	add	x9, sp, #0x8c
    221c:      	ldr	x0, [x0]
    2220:      	blr	x8
    2224:      	cbz	x0, 0x2250 <perf_unwind_dotnet+0x2250>
    2228:      	ldr	x8, [x0]
    222c:      	add	x8, x8, #0x1
    2230:      	str	x8, [x0]
    2234:      	ldr	x8, [sp, #0x10]
    2238:      	ldr	x29, [x8]
    223c:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2240:      	ldr	x8, [x8]
    2244:      	ldr	w8, [x8]
    2248:      	cbnz	x29, 0x2278 <perf_unwind_dotnet+0x2278>
    224c:      	b	0x4d58 <perf_unwind_dotnet+0x4d58>
    2250:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2254:      	ldr	x8, [x8]
    2258:      	ldr	w8, [x8]
    225c:      	cbnz	w8, 0x245c <perf_unwind_dotnet+0x245c>
    2260:      	ldr	x8, [sp, #0x10]
    2264:      	ldr	x29, [x8]
    2268:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    226c:      	ldr	x8, [x8]
    2270:      	ldr	w8, [x8]
    2274:      	cbz	x29, 0x4d58 <perf_unwind_dotnet+0x4d58>
    2278:      	cbnz	w8, 0x240c <perf_unwind_dotnet+0x240c>
    227c:      	lsr	x8, x29, #56
    2280:      	cbnz	x8, 0x1650 <perf_unwind_dotnet+0x1650>
    2284:      	cmp	x29, #0x1, lsl #12      // =0x1000
    2288:      	b.lo	0x1784 <perf_unwind_dotnet+0x1784>
    228c:      	ldr	w8, [x21]
    2290:      	mov	w9, #0x60               // =96
    2294:      	adrp	x0, 0x2000 <perf_unwind_dotnet+0x2000>
    2298:      	add	x1, sp, #0x70
    229c:      	rev	w8, w8
    22a0:      	stp	w9, w8, [sp, #0x70]
    22a4:      	rev	x8, x29
    22a8:      	add	x9, sp, #0x70
    22ac:      	str	x8, [sp, #0x78]
    22b0:      	mov	w8, #0x1                // =1
    22b4:      	ldr	x0, [x0]
    22b8:      	blr	x8
    22bc:      	cbz	x0, 0x4eec <perf_unwind_dotnet+0x4eec>
    22c0:      	ldr	x8, [x0, #0x8]
    22c4:      	and	x9, x8, #0xffffffffffffff
    22c8:      	lsr	x25, x8, #56
    22cc:      	str	x9, [x21, #0xf10]
    22d0:      	ldr	x8, [x0]
    22d4:      	str	x8, [x21, #0xf00]
    22d8:      	sub	x8, x29, x9
    22dc:      	str	x8, [x21, #0xf08]
    22e0:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    22e4:      	ldr	x8, [x8]
    22e8:      	ldr	w8, [x8]
    22ec:      	cbnz	w8, 0x2618 <perf_unwind_dotnet+0x2618>
    22f0:      	cmp	w25, #0x1
    22f4:      	b.ne	0x286c <perf_unwind_dotnet+0x286c>
    22f8:      	ldr	x8, [x21, #0xf00]
    22fc:      	adrp	x0, 0x2000 <perf_unwind_dotnet+0x2000>
    2300:      	ldr	x22, [x21, #0xf08]
    2304:      	mov	w9, #0x1                // =1
    2308:      	add	x1, sp, #0x70
    230c:      	mov	w25, #0x1               // =1
    2310:      	str	x8, [sp, #0x70]
    2314:      	add	x8, sp, #0x70
    2318:      	ldr	x0, [x0]
    231c:      	blr	x9
    2320:      	cbz	x0, 0x2398 <perf_unwind_dotnet+0x2398>
    2324:      	ldr	x8, [x0]
    2328:      	mov	x23, x0
    232c:      	cmp	x8, x22
    2330:      	b.hi	0x2340 <perf_unwind_dotnet+0x2340>
    2334:      	ldr	x8, [x23, #0x8]
    2338:      	cmp	x8, x22
    233c:      	b.hs	0x2358 <perf_unwind_dotnet+0x2358>
    2340:      	ldr	x8, [x23, #0x10]
    2344:      	cmp	x8, x22
    2348:      	b.hi	0x2388 <perf_unwind_dotnet+0x2388>
    234c:      	ldr	x8, [x23, #0x18]
    2350:      	cmp	x8, x22
    2354:      	b.lo	0x2388 <perf_unwind_dotnet+0x2388>
    2358:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    235c:      	ldr	x8, [x8]
    2360:      	ldr	w8, [x8]
    2364:      	cbnz	w8, 0x27dc <perf_unwind_dotnet+0x27dc>
    2368:      	ldrh	w8, [x23, #0x20]
    236c:      	ldr	w9, [x21, #0x1370]
    2370:      	lsr	w8, w9, w8
    2374:      	tbz	w8, #0x0, 0x2828 <perf_unwind_dotnet+0x2828>
    2378:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    237c:      	ldr	x8, [x8]
    2380:      	ldr	w8, [x8]
    2384:      	cbnz	w8, 0x2b94 <perf_unwind_dotnet+0x2b94>
    2388:      	mov	w25, #0x1               // =1
    238c:      	cmp	w25, #0x8
    2390:      	b.eq	0x2874 <perf_unwind_dotnet+0x2874>
    2394:      	b	0x4f64 <perf_unwind_dotnet+0x4f64>
    2398:      	cmp	w25, #0x8
    239c:      	b.eq	0x2874 <perf_unwind_dotnet+0x2874>
    23a0:      	b	0x4f64 <perf_unwind_dotnet+0x4f64>
    23a4:      	mov	w8, #0x786c             // =30828
    23a8:      	sub	x4, x24, x25
    23ac:      	add	x0, sp, #0x20
    23b0:      	mov	w1, #0x43               // =67
    23b4:      	mov	x2, x25
    23b8:      	movk	w8, #0xa, lsl #16
    23bc:      	stur	w8, [sp, #0x5f]
    23c0:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    23c4:      	add	x8, x8, #0x0
    23c8:      	ldp	x9, x10, [x8, #0x20]
    23cc:      	stp	x9, x10, [sp, #0x40]
    23d0:      	ldp	x9, x10, [x8, #0x30]
    23d4:      	stp	x9, x10, [sp, #0x50]
    23d8:      	ldp	x9, x10, [x8]
    23dc:      	stp	x9, x10, [sp, #0x20]
    23e0:      	ldp	x9, x8, [x8, #0x10]
    23e4:      	add	x10, sp, #0x20
    23e8:      	stp	x9, x8, [sp, #0x30]
    23ec:      	mov	w8, #0x43               // =67
    23f0:      	mov	w9, #0x6                // =6
    23f4:      	ldr	x3, [sp, #0x68]
    23f8:      	blr	x9
    23fc:      	ldr	w8, [x21, #0x2c0]
    2400:      	cmp	w8, #0x7e
    2404:      	b.hi	0x8a4 <perf_unwind_dotnet+0x8a4>
    2408:      	b	0x21c8 <perf_unwind_dotnet+0x21c8>
    240c:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2410:      	add	x8, x8, #0x0
    2414:      	strb	wzr, [sp, #0x50]
    2418:      	add	x0, sp, #0x20
    241c:      	ldp	x9, x10, [x8, #0x10]
    2420:      	mov	w1, #0x31               // =49
    2424:      	stp	x9, x10, [sp, #0x30]
    2428:      	ldp	x9, x10, [x8, #0x20]
    242c:      	stp	x9, x10, [sp, #0x40]
    2430:      	ldp	x9, x8, [x8]
    2434:      	add	x10, sp, #0x20
    2438:      	stp	x9, x8, [sp, #0x20]
    243c:      	mov	w8, #0x31               // =49
    2440:      	mov	w9, #0x6                // =6
    2444:      	ldr	w2, [x21, #0x2c0]
    2448:      	blr	x9
    244c:      	ldr	x29, [x21, #0xed0]
    2450:      	lsr	x8, x29, #56
    2454:      	cbnz	x8, 0x1650 <perf_unwind_dotnet+0x1650>
    2458:      	b	0x2284 <perf_unwind_dotnet+0x2284>
    245c:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2460:      	add	x8, x8, #0x0
    2464:      	add	x0, sp, #0x20
    2468:      	ldp	x9, x10, [x8, #0x10]
    246c:      	mov	w1, #0x2e               // =46
    2470:      	stp	x9, x10, [sp, #0x30]
    2474:      	ldr	x9, [x8, #0x20]
    2478:      	add	x10, sp, #0x20
    247c:      	str	x9, [sp, #0x40]
    2480:      	ldur	x9, [x8, #0x26]
    2484:      	stur	x9, [sp, #0x46]
    2488:      	ldp	x9, x8, [x8]
    248c:      	stp	x9, x8, [sp, #0x20]
    2490:      	mov	w8, #0x2e               // =46
    2494:      	mov	w9, #0x6                // =6
    2498:      	ldr	w2, [sp, #0x8c]
    249c:      	blr	x9
    24a0:      	ldr	x8, [sp, #0x10]
    24a4:      	ldr	x29, [x8]
    24a8:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    24ac:      	ldr	x8, [x8]
    24b0:      	ldr	w8, [x8]
    24b4:      	cbnz	x29, 0x2278 <perf_unwind_dotnet+0x2278>
    24b8:      	b	0x4d58 <perf_unwind_dotnet+0x4d58>
    24bc:      	ldr	x8, [x21, #0x1108]
    24c0:      	cbz	x8, 0x2608 <perf_unwind_dotnet+0x2608>
    24c4:      	mov	w9, #-0x66              // =-102
    24c8:      	b	0x609c <perf_unwind_dotnet+0x609c>
    24cc:      	ldr	x8, [x21, #0x10d8]
    24d0:      	cbz	x8, 0x26c0 <perf_unwind_dotnet+0x26c0>
    24d4:      	mov	w9, #-0x5a              // =-90
    24d8:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    24dc:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    24e0:      	add	x8, x8, #0x0
    24e4:      	add	x0, sp, #0x20
    24e8:      	ldp	x9, x10, [x8, #0x20]
    24ec:      	and	x2, x23, #0xfffffffffffffffc
    24f0:      	mov	w1, #0x36               // =54
    24f4:      	mov	w3, w25
    24f8:      	stp	x9, x10, [sp, #0x40]
    24fc:      	ldur	x9, [x8, #0x2e]
    2500:      	stur	x9, [sp, #0x4e]
    2504:      	ldp	x9, x10, [x8]
    2508:      	stp	x9, x10, [sp, #0x20]
    250c:      	ldp	x8, x9, [x8, #0x10]
    2510:      	add	x10, sp, #0x20
    2514:      	stp	x8, x9, [sp, #0x30]
    2518:      	mov	w8, #0x36               // =54
    251c:      	mov	w9, #0x6                // =6
    2520:      	blr	x9
    2524:      	mov	w8, #0x1c               // =28
    2528:      	bic	w8, w8, w23, lsr #3
    252c:      	lsr	w25, w25, w8
    2530:      	cbnz	w25, 0x1e80 <perf_unwind_dotnet+0x1e80>
    2534:      	and	x8, x23, #0xffffffffffffff00
    2538:      	ldr	w25, [x21, #0x1168]
    253c:      	sub	x23, x8, #0x20
    2540:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2544:      	ldr	x8, [x8]
    2548:      	ldr	w8, [x8]
    254c:      	cbnz	w8, 0x26d0 <perf_unwind_dotnet+0x26d0>
    2550:      	cbz	w25, 0x271c <perf_unwind_dotnet+0x271c>
    2554:      	mov	w3, wzr
    2558:      	b	0x6478 <perf_unwind_dotnet+0x6478>
    255c:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2560:      	add	x8, x8, #0x0
    2564:      	add	x0, sp, #0x20
    2568:      	ldp	x9, x10, [x8, #0x10]
    256c:      	mov	w1, #0x2e               // =46
    2570:      	mov	x2, x29
    2574:      	mov	x4, x25
    2578:      	stp	x9, x10, [sp, #0x30]
    257c:      	ldr	x9, [x8, #0x20]
    2580:      	add	x10, sp, #0x20
    2584:      	str	x9, [sp, #0x40]
    2588:      	ldur	x9, [x8, #0x26]
    258c:      	stur	x9, [sp, #0x46]
    2590:      	ldp	x9, x8, [x8]
    2594:      	stp	x9, x8, [sp, #0x20]
    2598:      	mov	w8, #0x2e               // =46
    259c:      	mov	w9, #0x6                // =6
    25a0:      	blr	x9
    25a4:      	b	0x2180 <perf_unwind_dotnet+0x2180>
    25a8:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    25ac:      	add	x8, x8, #0x0
    25b0:      	add	x0, sp, #0x20
    25b4:      	ldp	x9, x10, [x8, #0x10]
    25b8:      	mov	w1, #0x2e               // =46
    25bc:      	stp	x9, x10, [sp, #0x30]
    25c0:      	ldr	x9, [x8, #0x20]
    25c4:      	add	x10, sp, #0x20
    25c8:      	str	x9, [sp, #0x40]
    25cc:      	ldur	x9, [x8, #0x26]
    25d0:      	stur	x9, [sp, #0x46]
    25d4:      	ldp	x9, x8, [x8]
    25d8:      	stp	x9, x8, [sp, #0x20]
    25dc:      	mov	w8, #0x2e               // =46
    25e0:      	mov	w9, #0x6                // =6
    25e4:      	ldr	w2, [sp, #0x8c]
    25e8:      	blr	x9
    25ec:      	mov	w22, wzr
    25f0:      	mov	w2, #0x1772             // =6002
    25f4:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    25f8:      	ldr	x8, [x8]
    25fc:      	ldr	w8, [x8]
    2600:      	cbz	w8, 0x1ec4 <perf_unwind_dotnet+0x1ec4>
    2604:      	b	0x65a4 <perf_unwind_dotnet+0x65a4>
    2608:      	ldr	x8, [x21, #0x1100]
    260c:      	cbz	x8, 0x279c <perf_unwind_dotnet+0x279c>
    2610:      	mov	w9, #-0x64              // =-100
    2614:      	b	0x609c <perf_unwind_dotnet+0x609c>
    2618:      	mov	w8, #0xa                // =10
    261c:      	add	x0, sp, #0x20
    2620:      	mov	w1, #0x32               // =50
    2624:      	strh	w8, [sp, #0x50]
    2628:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    262c:      	add	x8, x8, #0x0
    2630:      	mov	x2, x29
    2634:      	ldp	x9, x10, [x8, #0x10]
    2638:      	mov	w4, w25
    263c:      	stp	x9, x10, [sp, #0x30]
    2640:      	ldp	x9, x10, [x8, #0x20]
    2644:      	stp	x9, x10, [sp, #0x40]
    2648:      	ldp	x9, x8, [x8]
    264c:      	add	x10, sp, #0x20
    2650:      	stp	x9, x8, [sp, #0x20]
    2654:      	mov	w8, #0x32               // =50
    2658:      	mov	w9, #0x6                // =6
    265c:      	ldr	x3, [x21, #0xf00]
    2660:      	blr	x9
    2664:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2668:      	ldr	x8, [x8]
    266c:      	ldr	w8, [x8]
    2670:      	cbz	w8, 0x22f0 <perf_unwind_dotnet+0x22f0>
    2674:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2678:      	add	x8, x8, #0x0
    267c:      	add	x0, sp, #0x20
    2680:      	ldp	x9, x10, [x8, #0x10]
    2684:      	mov	w1, #0x2f               // =47
    2688:      	stp	x9, x10, [sp, #0x30]
    268c:      	ldr	x9, [x8, #0x20]
    2690:      	add	x10, sp, #0x20
    2694:      	str	x9, [sp, #0x40]
    2698:      	ldur	x9, [x8, #0x27]
    269c:      	stur	x9, [sp, #0x47]
    26a0:      	ldp	x9, x8, [x8]
    26a4:      	stp	x9, x8, [sp, #0x20]
    26a8:      	mov	w8, #0x2f               // =47
    26ac:      	mov	w9, #0x6                // =6
    26b0:      	ldr	x2, [x21, #0xf10]
    26b4:      	ldr	x3, [x21, #0xf08]
    26b8:      	blr	x9
    26bc:      	b	0x22f0 <perf_unwind_dotnet+0x22f0>
    26c0:      	ldr	x8, [x21, #0x10d0]
    26c4:      	cbz	x8, 0x27ac <perf_unwind_dotnet+0x27ac>
    26c8:      	mov	w9, #-0x58              // =-88
    26cc:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    26d0:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    26d4:      	add	x8, x8, #0x0
    26d8:      	add	x0, sp, #0x20
    26dc:      	ldp	x9, x10, [x8, #0x20]
    26e0:      	mov	w1, #0x37               // =55
    26e4:      	mov	x2, x23
    26e8:      	mov	w3, w25
    26ec:      	stp	x9, x10, [sp, #0x40]
    26f0:      	ldur	x9, [x8, #0x2f]
    26f4:      	stur	x9, [sp, #0x4f]
    26f8:      	ldp	x9, x10, [x8]
    26fc:      	stp	x9, x10, [sp, #0x20]
    2700:      	ldp	x8, x9, [x8, #0x10]
    2704:      	add	x10, sp, #0x20
    2708:      	stp	x8, x9, [sp, #0x30]
    270c:      	mov	w8, #0x37               // =55
    2710:      	mov	w9, #0x6                // =6
    2714:      	blr	x9
    2718:      	cbnz	w25, 0x2554 <perf_unwind_dotnet+0x2554>
    271c:      	ldr	x8, [x21, #0x1160]
    2720:      	cbz	x8, 0x272c <perf_unwind_dotnet+0x272c>
    2724:      	mov	w9, #-0x7c              // =-124
    2728:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    272c:      	ldr	x8, [x21, #0x1158]
    2730:      	cbz	x8, 0x273c <perf_unwind_dotnet+0x273c>
    2734:      	mov	w9, #-0x7a              // =-122
    2738:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    273c:      	ldr	x8, [x21, #0x1150]
    2740:      	cbz	x8, 0x274c <perf_unwind_dotnet+0x274c>
    2744:      	mov	w9, #-0x78              // =-120
    2748:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    274c:      	ldr	x8, [x21, #0x1148]
    2750:      	cbz	x8, 0x275c <perf_unwind_dotnet+0x275c>
    2754:      	mov	w9, #-0x76              // =-118
    2758:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    275c:      	ldr	x8, [x21, #0x1140]
    2760:      	cbz	x8, 0x276c <perf_unwind_dotnet+0x276c>
    2764:      	mov	w9, #-0x74              // =-116
    2768:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    276c:      	ldr	x8, [x21, #0x1138]
    2770:      	cbz	x8, 0x277c <perf_unwind_dotnet+0x277c>
    2774:      	mov	w9, #-0x72              // =-114
    2778:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    277c:      	ldr	x8, [x21, #0x1130]
    2780:      	cbz	x8, 0x278c <perf_unwind_dotnet+0x278c>
    2784:      	mov	w9, #-0x70              // =-112
    2788:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    278c:      	ldr	x8, [x21, #0x1128]
    2790:      	cbz	x8, 0x27bc <perf_unwind_dotnet+0x27bc>
    2794:      	mov	w9, #-0x6e              // =-110
    2798:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    279c:      	ldr	x8, [x21, #0x10f8]
    27a0:      	cbz	x8, 0x27cc <perf_unwind_dotnet+0x27cc>
    27a4:      	mov	w9, #-0x62              // =-98
    27a8:      	b	0x609c <perf_unwind_dotnet+0x609c>
    27ac:      	ldr	x8, [x21, #0x10c8]
    27b0:      	cbz	x8, 0x2b64 <perf_unwind_dotnet+0x2b64>
    27b4:      	mov	w9, #-0x56              // =-86
    27b8:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    27bc:      	ldr	x8, [x21, #0x1120]
    27c0:      	cbz	x8, 0x2b84 <perf_unwind_dotnet+0x2b84>
    27c4:      	mov	w9, #-0x6c              // =-108
    27c8:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    27cc:      	ldr	x8, [x21, #0x10f0]
    27d0:      	cbz	x8, 0x2be0 <perf_unwind_dotnet+0x2be0>
    27d4:      	mov	w9, #-0x60              // =-96
    27d8:      	b	0x609c <perf_unwind_dotnet+0x609c>
    27dc:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    27e0:      	add	x8, x8, #0x0
    27e4:      	add	x0, sp, #0x20
    27e8:      	ldp	x9, x10, [x8]
    27ec:      	mov	w1, #0x1e               // =30
    27f0:      	stp	x9, x10, [sp, #0x20]
    27f4:      	ldr	x9, [x8, #0x10]
    27f8:      	ldur	x8, [x8, #0x16]
    27fc:      	add	x10, sp, #0x20
    2800:      	str	x9, [sp, #0x30]
    2804:      	stur	x8, [sp, #0x36]
    2808:      	mov	w8, #0x1e               // =30
    280c:      	mov	w9, #0x6                // =6
    2810:      	ldrh	w2, [x23, #0x20]
    2814:      	blr	x9
    2818:      	ldrh	w8, [x23, #0x20]
    281c:      	ldr	w9, [x21, #0x1370]
    2820:      	lsr	w8, w9, w8
    2824:      	tbnz	w8, #0x0, 0x2378 <perf_unwind_dotnet+0x2378>
    2828:      	str	wzr, [sp, #0x68]
    282c:      	adrp	x0, 0x2000 <perf_unwind_dotnet+0x2000>
    2830:      	mov	w8, #0x1                // =1
    2834:      	add	x9, sp, #0x68
    2838:      	ldr	x0, [x0]
    283c:      	add	x1, sp, #0x68
    2840:      	blr	x8
    2844:      	cbz	x0, 0x2858 <perf_unwind_dotnet+0x2858>
    2848:      	ldr	x8, [x0]
    284c:      	add	x8, x8, #0x1
    2850:      	str	x8, [x0]
    2854:      	b	0x2868 <perf_unwind_dotnet+0x2868>
    2858:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    285c:      	ldr	x8, [x8]
    2860:      	ldr	w8, [x8]
    2864:      	cbnz	w8, 0x2cdc <perf_unwind_dotnet+0x2cdc>
    2868:      	ldrh	w25, [x23, #0x20]
    286c:      	cmp	w25, #0x8
    2870:      	b.ne	0x4f64 <perf_unwind_dotnet+0x4f64>
    2874:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2878:      	ldr	x25, [x21, #0xed8]
    287c:      	ldr	x29, [x21, #0xee0]
    2880:      	ldr	x24, [x21, #0xed0]
    2884:      	ldrb	w22, [x21, #0xf20]
    2888:      	ldr	x8, [x8]
    288c:      	ldr	w8, [x8]
    2890:      	cbnz	w8, 0x2b00 <perf_unwind_dotnet+0x2b00>
    2894:      	cmp	x29, x25
    2898:      	b.lo	0x45cc <perf_unwind_dotnet+0x45cc>
    289c:      	add	x8, x25, #0x2, lsl #12  // =0x2000
    28a0:      	cmp	x29, x8
    28a4:      	b.hs	0x45cc <perf_unwind_dotnet+0x45cc>
    28a8:      	ldr	x23, [x21, #0xf00]
    28ac:      	ldr	x25, [x21, #0xf10]
    28b0:      	mov	w8, #0x101              // =257
    28b4:      	str	x24, [sp, #0x68]
    28b8:      	strh	w8, [x21, #0xf20]
    28bc:      	and	x8, x23, #0xffffffffffffff80
    28c0:      	cmp	x8, #0x80
    28c4:      	b.ne	0x28fc <perf_unwind_dotnet+0x28fc>
    28c8:      	ldr	x8, [x21, #0xed8]
    28cc:      	mov	w9, #0x8                // =8
    28d0:      	mov	w10, #0x70              // =112
    28d4:      	ldr	x0, [sp, #0x10]
    28d8:      	mov	w1, #0x8                // =8
    28dc:      	ldr	x2, [x21, #0xed8]
    28e0:      	blr	x10
    28e4:      	cbnz	x0, 0x1e0 <perf_unwind_dotnet+0x1e0>
    28e8:      	ldr	x8, [x21, #0xed8]
    28ec:      	and	x23, x23, #0x7f
    28f0:      	add	x8, x8, #0x8
    28f4:      	str	x8, [x21, #0xed8]
    28f8:      	b	0x2d8c <perf_unwind_dotnet+0x2d8c>
    28fc:      	mov	w8, #0x10               // =16
    2900:      	mov	w9, #0x70               // =112
    2904:      	add	x10, sp, #0x70
    2908:      	add	x0, sp, #0x70
    290c:      	mov	w1, #0x10               // =16
    2910:      	mov	x2, x29
    2914:      	blr	x9
    2918:      	cbnz	x0, 0x27c <perf_unwind_dotnet+0x27c>
    291c:      	add	x8, x29, #0x10
    2920:      	str	x8, [x21, #0xed8]
    2924:      	ldp	x8, x9, [sp, #0x70]
    2928:      	str	x8, [x21, #0xee0]
    292c:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2930:      	str	x9, [x21, #0xed0]
    2934:      	ldr	x8, [x8]
    2938:      	ldr	w8, [x8]
    293c:      	cbnz	w8, 0x2bf0 <perf_unwind_dotnet+0x2bf0>
    2940:      	cmp	x23, #0x100
    2944:      	b.lo	0x2d8c <perf_unwind_dotnet+0x2d8c>
    2948:      	ldr	x8, [x21, #0xf10]
    294c:      	ldr	x25, [x21, #0xf00]
    2950:      	sub	x23, x24, x8
    2954:      	str	x8, [sp, #0x8]
    2958:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    295c:      	ldr	x8, [x8]
    2960:      	ldr	w8, [x8]
    2964:      	cbnz	w8, 0x2c84 <perf_unwind_dotnet+0x2c84>
    2968:      	lsr	x8, x23, #8
    296c:      	mov	w9, #0x7f               // =127
    2970:      	lsr	x10, x23, #15
    2974:      	mov	w1, #0x200              // =512
    2978:      	sub	w9, w9, w8
    297c:      	lsl	x8, x8, #2
    2980:      	cmp	x10, #0x0
    2984:      	sub	x8, x8, #0x3fc
    2988:      	and	x9, x9, #0x7f
    298c:      	csel	x8, x8, xzr, ne
    2990:      	add	x2, x8, x25
    2994:      	csel	x8, xzr, x9, ne
    2998:      	ldr	x9, [sp, #0x18]
    299c:      	add	x0, x9, x8, lsl #2
    29a0:      	mov	w8, #0x200              // =512
    29a4:      	mov	w9, #0x70               // =112
    29a8:      	blr	x9
    29ac:      	cbz	x0, 0x2a0c <perf_unwind_dotnet+0x2a0c>
    29b0:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    29b4:      	ldr	x8, [x8]
    29b8:      	ldr	w8, [x8]
    29bc:      	cbnz	w8, 0x3ec8 <perf_unwind_dotnet+0x3ec8>
    29c0:      	mov	w8, #0x5e               // =94
    29c4:      	adrp	x0, 0x2000 <perf_unwind_dotnet+0x2000>
    29c8:      	add	x9, sp, #0x8c
    29cc:      	str	w8, [sp, #0x8c]
    29d0:      	mov	w8, #0x1                // =1
    29d4:      	add	x1, sp, #0x8c
    29d8:      	ldr	x0, [x0]
    29dc:      	blr	x8
    29e0:      	cbz	x0, 0x2a4c <perf_unwind_dotnet+0x2a4c>
    29e4:      	ldr	x8, [x0]
    29e8:      	add	x8, x8, #0x1
    29ec:      	str	x8, [x0]
    29f0:      	mov	w22, wzr
    29f4:      	mov	w2, #0x1772             // =6002
    29f8:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    29fc:      	ldr	x8, [x8]
    2a00:      	ldr	w8, [x8]
    2a04:      	cbz	w8, 0x2a74 <perf_unwind_dotnet+0x2a74>
    2a08:      	b	0x3f88 <perf_unwind_dotnet+0x3f88>
    2a0c:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2a10:      	ldr	w25, [x21, #0x116c]
    2a14:      	ldr	x8, [x8]
    2a18:      	ldr	w8, [x8]
    2a1c:      	cbnz	w8, 0x30bc <perf_unwind_dotnet+0x30bc>
    2a20:      	mov	w8, #0x1c               // =28
    2a24:      	bic	w8, w8, w23, lsr #3
    2a28:      	lsr	w25, w25, w8
    2a2c:      	cbz	w25, 0x3114 <perf_unwind_dotnet+0x3114>
    2a30:      	and	x29, x23, #0xffffffffffffffe0
    2a34:      	ands	w3, w25, #0xf
    2a38:      	b.ne	0x2d3c <perf_unwind_dotnet+0x2d3c>
    2a3c:      	ubfx	w3, w25, #4, #4
    2a40:      	cbz	w3, 0x2ae0 <perf_unwind_dotnet+0x2ae0>
    2a44:      	sub	x29, x29, #0x20
    2a48:      	b	0x2d3c <perf_unwind_dotnet+0x2d3c>
    2a4c:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2a50:      	ldr	x8, [x8]
    2a54:      	ldr	w8, [x8]
    2a58:      	cbnz	w8, 0x3198 <perf_unwind_dotnet+0x3198>
    2a5c:      	mov	w22, wzr
    2a60:      	mov	w2, #0x1772             // =6002
    2a64:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2a68:      	ldr	x8, [x8]
    2a6c:      	ldr	w8, [x8]
    2a70:      	cbnz	w8, 0x3f88 <perf_unwind_dotnet+0x3f88>
    2a74:      	cbz	w22, 0x621c <perf_unwind_dotnet+0x621c>
    2a78:      	ldr	w8, [x21, #0x2c0]
    2a7c:      	adrp	x23, 0x2000 <perf_unwind_dotnet+0x2000>
    2a80:      	adrp	x24, 0x2000 <perf_unwind_dotnet+0x2000>
    2a84:      	ldr	x23, [x23]
    2a88:      	ldr	x24, [x24]
    2a8c:      	cmp	w8, #0x7e
    2a90:      	b.hi	0x49c <perf_unwind_dotnet+0x49c>
    2a94:      	add	w9, w8, #0x1
    2a98:      	mov	w10, #0x8a              // =138
    2a9c:      	str	w9, [x21, #0x2c0]
    2aa0:      	mov	w9, #0x18               // =24
    2aa4:      	umaddl	x8, w8, w9, x21
    2aa8:      	mov	w9, #0x1773             // =6003
    2aac:      	str	x9, [x8, #0x2d8]
    2ab0:      	add	x9, x8, #0x2d0
    2ab4:      	str	xzr, [x8, #0x2d0]
    2ab8:      	strb	w10, [x8, #0x2e0]
    2abc:      	str	wzr, [x8, #0x2e4]
    2ac0:      	stur	wzr, [x9, #0x11]
    2ac4:      	ldr	x8, [sp, #0x10]
    2ac8:      	ldr	x29, [x8]
    2acc:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2ad0:      	ldr	x8, [x8]
    2ad4:      	ldr	w8, [x8]
    2ad8:      	cbnz	x29, 0x2e58 <perf_unwind_dotnet+0x2e58>
    2adc:      	b	0x4d58 <perf_unwind_dotnet+0x4d58>
    2ae0:      	ubfx	w3, w25, #8, #4
    2ae4:      	cbz	w3, 0x2af0 <perf_unwind_dotnet+0x2af0>
    2ae8:      	sub	x29, x29, #0x40
    2aec:      	b	0x2d3c <perf_unwind_dotnet+0x2d3c>
    2af0:      	ubfx	w3, w25, #12, #4
    2af4:      	cbz	w3, 0x2b54 <perf_unwind_dotnet+0x2b54>
    2af8:      	sub	x29, x29, #0x60
    2afc:      	b	0x2d3c <perf_unwind_dotnet+0x2d3c>
    2b00:      	mov	w8, #0x786c             // =30828
    2b04:      	add	x0, sp, #0x20
    2b08:      	mov	w1, #0x23               // =35
    2b0c:      	mov	x2, x24
    2b10:      	mov	x3, x25
    2b14:      	mov	x4, x29
    2b18:      	movk	w8, #0xa, lsl #16
    2b1c:      	stur	w8, [sp, #0x3f]
    2b20:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2b24:      	add	x8, x8, #0x0
    2b28:      	ldp	x9, x10, [x8]
    2b2c:      	stp	x9, x10, [sp, #0x20]
    2b30:      	ldp	x9, x8, [x8, #0x10]
    2b34:      	add	x10, sp, #0x20
    2b38:      	stp	x9, x8, [sp, #0x30]
    2b3c:      	mov	w8, #0x23               // =35
    2b40:      	mov	w9, #0x6                // =6
    2b44:      	blr	x9
    2b48:      	cmp	x29, x25
    2b4c:      	b.hs	0x289c <perf_unwind_dotnet+0x289c>
    2b50:      	b	0x45cc <perf_unwind_dotnet+0x45cc>
    2b54:      	ubfx	w3, w25, #16, #4
    2b58:      	cbz	w3, 0x2b74 <perf_unwind_dotnet+0x2b74>
    2b5c:      	sub	x29, x29, #0x80
    2b60:      	b	0x2d3c <perf_unwind_dotnet+0x2d3c>
    2b64:      	ldr	x8, [x21, #0x10c0]
    2b68:      	cbz	x8, 0x2c44 <perf_unwind_dotnet+0x2c44>
    2b6c:      	mov	w9, #-0x54              // =-84
    2b70:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    2b74:      	ubfx	w3, w25, #20, #4
    2b78:      	cbz	w3, 0x2c54 <perf_unwind_dotnet+0x2c54>
    2b7c:      	sub	x29, x29, #0xa0
    2b80:      	b	0x2d3c <perf_unwind_dotnet+0x2d3c>
    2b84:      	ldr	x8, [x21, #0x1118]
    2b88:      	cbz	x8, 0x2c64 <perf_unwind_dotnet+0x2c64>
    2b8c:      	mov	w9, #-0x6a              // =-106
    2b90:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    2b94:      	mov	w8, #0x656e             // =25966
    2b98:      	add	x0, sp, #0x20
    2b9c:      	mov	w1, #0x1b               // =27
    2ba0:      	movk	w8, #0xa, lsl #16
    2ba4:      	stur	w8, [sp, #0x37]
    2ba8:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2bac:      	add	x8, x8, #0x0
    2bb0:      	ldp	x9, x10, [x8]
    2bb4:      	ldr	x8, [x8, #0x10]
    2bb8:      	stp	x9, x10, [sp, #0x20]
    2bbc:      	str	x8, [sp, #0x30]
    2bc0:      	mov	w8, #0x1b               // =27
    2bc4:      	mov	w9, #0x6                // =6
    2bc8:      	add	x10, sp, #0x20
    2bcc:      	blr	x9
    2bd0:      	mov	w25, #0x1               // =1
    2bd4:      	cmp	w25, #0x8
    2bd8:      	b.eq	0x2874 <perf_unwind_dotnet+0x2874>
    2bdc:      	b	0x4f64 <perf_unwind_dotnet+0x4f64>
    2be0:      	ldr	x8, [x21, #0x10e8]
    2be4:      	cbz	x8, 0x2c74 <perf_unwind_dotnet+0x2c74>
    2be8:      	mov	w9, #-0x5e              // =-94
    2bec:      	b	0x609c <perf_unwind_dotnet+0x609c>
    2bf0:      	mov	w8, #0x786c             // =30828
    2bf4:      	add	x0, sp, #0x20
    2bf8:      	mov	w1, #0x23               // =35
    2bfc:      	movk	w8, #0xa, lsl #16
    2c00:      	stur	w8, [sp, #0x3f]
    2c04:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2c08:      	add	x8, x8, #0x0
    2c0c:      	ldp	x9, x10, [x8]
    2c10:      	stp	x9, x10, [sp, #0x20]
    2c14:      	ldp	x9, x8, [x8, #0x10]
    2c18:      	add	x10, sp, #0x20
    2c1c:      	stp	x9, x8, [sp, #0x30]
    2c20:      	mov	w8, #0x23               // =35
    2c24:      	mov	w9, #0x6                // =6
    2c28:      	ldr	x2, [x21, #0xed0]
    2c2c:      	ldr	x3, [x21, #0xed8]
    2c30:      	ldr	x4, [x21, #0xee0]
    2c34:      	blr	x9
    2c38:      	cmp	x23, #0x100
    2c3c:      	b.hs	0x2948 <perf_unwind_dotnet+0x2948>
    2c40:      	b	0x2d8c <perf_unwind_dotnet+0x2d8c>
    2c44:      	ldr	x8, [x21, #0x10b8]
    2c48:      	cbz	x8, 0x2d24 <perf_unwind_dotnet+0x2d24>
    2c4c:      	mov	w9, #-0x52              // =-82
    2c50:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    2c54:      	ubfx	w3, w25, #24, #4
    2c58:      	cbz	w3, 0x2d34 <perf_unwind_dotnet+0x2d34>
    2c5c:      	sub	x29, x29, #0xc0
    2c60:      	b	0x2d3c <perf_unwind_dotnet+0x2d3c>
    2c64:      	ldr	x8, [x21, #0x1110]
    2c68:      	cbz	x8, 0x309c <perf_unwind_dotnet+0x309c>
    2c6c:      	mov	w9, #-0x68              // =-104
    2c70:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    2c74:      	ldr	x8, [x21, #0x10e0]
    2c78:      	cbz	x8, 0x30ac <perf_unwind_dotnet+0x30ac>
    2c7c:      	mov	w9, #-0x5c              // =-92
    2c80:      	b	0x609c <perf_unwind_dotnet+0x609c>
    2c84:      	mov	w8, #0xa                // =10
    2c88:      	mov	w11, #0x6               // =6
    2c8c:      	add	x0, sp, #0x20
    2c90:      	strh	w8, [sp, #0x60]
    2c94:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2c98:      	add	x8, x8, #0x0
    2c9c:      	mov	w1, #0x42               // =66
    2ca0:      	ldp	x9, x10, [x8, #0x20]
    2ca4:      	mov	x2, x23
    2ca8:      	mov	x4, x25
    2cac:      	stp	x9, x10, [sp, #0x40]
    2cb0:      	ldp	x9, x10, [x8, #0x30]
    2cb4:      	stp	x9, x10, [sp, #0x50]
    2cb8:      	ldp	x9, x10, [x8]
    2cbc:      	stp	x9, x10, [sp, #0x20]
    2cc0:      	ldp	x9, x8, [x8, #0x10]
    2cc4:      	mov	w10, #0x42              // =66
    2cc8:      	stp	x9, x8, [sp, #0x30]
    2ccc:      	add	x8, sp, #0x20
    2cd0:      	ldr	x3, [sp, #0x8]
    2cd4:      	blr	x11
    2cd8:      	b	0x2968 <perf_unwind_dotnet+0x2968>
    2cdc:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2ce0:      	add	x8, x8, #0x0
    2ce4:      	add	x0, sp, #0x20
    2ce8:      	ldp	x9, x10, [x8, #0x10]
    2cec:      	mov	w1, #0x2e               // =46
    2cf0:      	stp	x9, x10, [sp, #0x30]
    2cf4:      	ldr	x9, [x8, #0x20]
    2cf8:      	add	x10, sp, #0x20
    2cfc:      	str	x9, [sp, #0x40]
    2d00:      	ldur	x9, [x8, #0x26]
    2d04:      	stur	x9, [sp, #0x46]
    2d08:      	ldp	x9, x8, [x8]
    2d0c:      	stp	x9, x8, [sp, #0x20]
    2d10:      	mov	w8, #0x2e               // =46
    2d14:      	mov	w9, #0x6                // =6
    2d18:      	ldr	w2, [sp, #0x68]
    2d1c:      	blr	x9
    2d20:      	b	0x2868 <perf_unwind_dotnet+0x2868>
    2d24:      	ldr	x8, [x21, #0x10b0]
    2d28:      	cbz	x8, 0x3188 <perf_unwind_dotnet+0x3188>
    2d2c:      	mov	w9, #-0x50              // =-80
    2d30:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    2d34:      	lsr	w3, w25, #28
    2d38:      	sub	x29, x29, #0xe0
    2d3c:      	ldr	x8, [sp, #0x8]
    2d40:      	lsl	w9, w3, #2
    2d44:      	sub	w9, w9, #0x4
    2d48:      	add	x8, x29, x8
    2d4c:      	add	x25, x8, x9
    2d50:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2d54:      	ldr	x8, [x8]
    2d58:      	ldr	w8, [x8]
    2d5c:      	cbnz	w8, 0x313c <perf_unwind_dotnet+0x313c>
    2d60:      	sub	x2, x25, #0x8
    2d64:      	mov	w8, #0x8                // =8
    2d68:      	mov	w9, #0x70               // =112
    2d6c:      	add	x10, sp, #0x68
    2d70:      	add	x0, sp, #0x68
    2d74:      	mov	w1, #0x8                // =8
    2d78:      	blr	x9
    2d7c:      	adrp	x23, 0x2000 <perf_unwind_dotnet+0x2000>
    2d80:      	ldr	x23, [x23]
    2d84:      	cbnz	x0, 0x844 <perf_unwind_dotnet+0x844>
    2d88:      	mov	w23, #0x1f              // =31
    2d8c:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2d90:      	ldr	x8, [x8]
    2d94:      	ldr	w8, [x8]
    2d98:      	cbnz	w8, 0x2f84 <perf_unwind_dotnet+0x2f84>
    2d9c:      	ldr	w8, [x21, #0x2c0]
    2da0:      	cmp	w8, #0x7e
    2da4:      	b.hi	0x8a4 <perf_unwind_dotnet+0x8a4>
    2da8:      	ldr	x9, [sp, #0x68]
    2dac:      	add	w11, w8, #0x1
    2db0:      	sub	x10, x24, x25
    2db4:      	adrp	x0, 0x2000 <perf_unwind_dotnet+0x2000>
    2db8:      	str	w11, [x21, #0x2c0]
    2dbc:      	mov	w11, #0x18              // =24
    2dc0:      	add	x1, sp, #0x8c
    2dc4:      	umaddl	x8, w8, w11, x21
    2dc8:      	add	x9, x23, x9, lsl #5
    2dcc:      	str	x10, [x8, #0x2d8]
    2dd0:      	mov	w10, #0xa               // =10
    2dd4:      	strb	w22, [x8, #0x2e1]
    2dd8:      	strh	wzr, [x8, #0x2e6]
    2ddc:      	strb	w10, [x8, #0x2e0]
    2de0:      	str	x9, [x8, #0x2d0]
    2de4:      	add	x9, x8, #0x2d0
    2de8:      	mov	w8, #0x5b               // =91
    2dec:      	stur	wzr, [x9, #0x12]
    2df0:      	str	w8, [sp, #0x8c]
    2df4:      	mov	w8, #0x1                // =1
    2df8:      	add	x9, sp, #0x8c
    2dfc:      	ldr	x0, [x0]
    2e00:      	blr	x8
    2e04:      	cbz	x0, 0x2e30 <perf_unwind_dotnet+0x2e30>
    2e08:      	ldr	x8, [x0]
    2e0c:      	add	x8, x8, #0x1
    2e10:      	str	x8, [x0]
    2e14:      	ldr	x8, [sp, #0x10]
    2e18:      	ldr	x29, [x8]
    2e1c:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2e20:      	ldr	x8, [x8]
    2e24:      	ldr	w8, [x8]
    2e28:      	cbnz	x29, 0x2e58 <perf_unwind_dotnet+0x2e58>
    2e2c:      	b	0x4d58 <perf_unwind_dotnet+0x4d58>
    2e30:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2e34:      	ldr	x8, [x8]
    2e38:      	ldr	w8, [x8]
    2e3c:      	cbnz	w8, 0x303c <perf_unwind_dotnet+0x303c>
    2e40:      	ldr	x8, [sp, #0x10]
    2e44:      	ldr	x29, [x8]
    2e48:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2e4c:      	ldr	x8, [x8]
    2e50:      	ldr	w8, [x8]
    2e54:      	cbz	x29, 0x4d58 <perf_unwind_dotnet+0x4d58>
    2e58:      	cbnz	w8, 0x2fec <perf_unwind_dotnet+0x2fec>
    2e5c:      	lsr	x8, x29, #56
    2e60:      	cbnz	x8, 0x1650 <perf_unwind_dotnet+0x1650>
    2e64:      	cmp	x29, #0x1, lsl #12      // =0x1000
    2e68:      	b.lo	0x1784 <perf_unwind_dotnet+0x1784>
    2e6c:      	ldr	w8, [x21]
    2e70:      	mov	w9, #0x60               // =96
    2e74:      	adrp	x0, 0x2000 <perf_unwind_dotnet+0x2000>
    2e78:      	add	x1, sp, #0x70
    2e7c:      	rev	w8, w8
    2e80:      	stp	w9, w8, [sp, #0x70]
    2e84:      	rev	x8, x29
    2e88:      	add	x9, sp, #0x70
    2e8c:      	str	x8, [sp, #0x78]
    2e90:      	mov	w8, #0x1                // =1
    2e94:      	ldr	x0, [x0]
    2e98:      	blr	x8
    2e9c:      	cbz	x0, 0x4eec <perf_unwind_dotnet+0x4eec>
    2ea0:      	ldr	x8, [x0, #0x8]
    2ea4:      	and	x9, x8, #0xffffffffffffff
    2ea8:      	lsr	x25, x8, #56
    2eac:      	str	x9, [x21, #0xf10]
    2eb0:      	ldr	x8, [x0]
    2eb4:      	str	x8, [x21, #0xf00]
    2eb8:      	sub	x8, x29, x9
    2ebc:      	str	x8, [x21, #0xf08]
    2ec0:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2ec4:      	ldr	x8, [x8]
    2ec8:      	ldr	w8, [x8]
    2ecc:      	cbnz	w8, 0x3208 <perf_unwind_dotnet+0x3208>
    2ed0:      	cmp	w25, #0x1
    2ed4:      	b.ne	0x347c <perf_unwind_dotnet+0x347c>
    2ed8:      	ldr	x8, [x21, #0xf00]
    2edc:      	adrp	x0, 0x2000 <perf_unwind_dotnet+0x2000>
    2ee0:      	ldr	x22, [x21, #0xf08]
    2ee4:      	mov	w9, #0x1                // =1
    2ee8:      	add	x1, sp, #0x70
    2eec:      	mov	w25, #0x1               // =1
    2ef0:      	str	x8, [sp, #0x70]
    2ef4:      	add	x8, sp, #0x70
    2ef8:      	ldr	x0, [x0]
    2efc:      	blr	x9
    2f00:      	cbz	x0, 0x2f78 <perf_unwind_dotnet+0x2f78>
    2f04:      	ldr	x8, [x0]
    2f08:      	mov	x23, x0
    2f0c:      	cmp	x8, x22
    2f10:      	b.hi	0x2f20 <perf_unwind_dotnet+0x2f20>
    2f14:      	ldr	x8, [x23, #0x8]
    2f18:      	cmp	x8, x22
    2f1c:      	b.hs	0x2f38 <perf_unwind_dotnet+0x2f38>
    2f20:      	ldr	x8, [x23, #0x10]
    2f24:      	cmp	x8, x22
    2f28:      	b.hi	0x2f68 <perf_unwind_dotnet+0x2f68>
    2f2c:      	ldr	x8, [x23, #0x18]
    2f30:      	cmp	x8, x22
    2f34:      	b.lo	0x2f68 <perf_unwind_dotnet+0x2f68>
    2f38:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2f3c:      	ldr	x8, [x8]
    2f40:      	ldr	w8, [x8]
    2f44:      	cbnz	w8, 0x33ec <perf_unwind_dotnet+0x33ec>
    2f48:      	ldrh	w8, [x23, #0x20]
    2f4c:      	ldr	w9, [x21, #0x1370]
    2f50:      	lsr	w8, w9, w8
    2f54:      	tbz	w8, #0x0, 0x3438 <perf_unwind_dotnet+0x3438>
    2f58:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2f5c:      	ldr	x8, [x8]
    2f60:      	ldr	w8, [x8]
    2f64:      	cbnz	w8, 0x37a4 <perf_unwind_dotnet+0x37a4>
    2f68:      	mov	w25, #0x1               // =1
    2f6c:      	cmp	w25, #0x8
    2f70:      	b.eq	0x3484 <perf_unwind_dotnet+0x3484>
    2f74:      	b	0x4f64 <perf_unwind_dotnet+0x4f64>
    2f78:      	cmp	w25, #0x8
    2f7c:      	b.eq	0x3484 <perf_unwind_dotnet+0x3484>
    2f80:      	b	0x4f64 <perf_unwind_dotnet+0x4f64>
    2f84:      	mov	w8, #0x786c             // =30828
    2f88:      	sub	x4, x24, x25
    2f8c:      	add	x0, sp, #0x20
    2f90:      	mov	w1, #0x43               // =67
    2f94:      	mov	x2, x25
    2f98:      	movk	w8, #0xa, lsl #16
    2f9c:      	stur	w8, [sp, #0x5f]
    2fa0:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2fa4:      	add	x8, x8, #0x0
    2fa8:      	ldp	x9, x10, [x8, #0x20]
    2fac:      	stp	x9, x10, [sp, #0x40]
    2fb0:      	ldp	x9, x10, [x8, #0x30]
    2fb4:      	stp	x9, x10, [sp, #0x50]
    2fb8:      	ldp	x9, x10, [x8]
    2fbc:      	stp	x9, x10, [sp, #0x20]
    2fc0:      	ldp	x9, x8, [x8, #0x10]
    2fc4:      	add	x10, sp, #0x20
    2fc8:      	stp	x9, x8, [sp, #0x30]
    2fcc:      	mov	w8, #0x43               // =67
    2fd0:      	mov	w9, #0x6                // =6
    2fd4:      	ldr	x3, [sp, #0x68]
    2fd8:      	blr	x9
    2fdc:      	ldr	w8, [x21, #0x2c0]
    2fe0:      	cmp	w8, #0x7e
    2fe4:      	b.hi	0x8a4 <perf_unwind_dotnet+0x8a4>
    2fe8:      	b	0x2da8 <perf_unwind_dotnet+0x2da8>
    2fec:      	adrp	x8, 0x2000 <perf_unwind_dotnet+0x2000>
    2ff0:      	add	x8, x8, #0x0
    2ff4:      	strb	wzr, [sp, #0x50]
    2ff8:      	add	x0, sp, #0x20
    2ffc:      	ldp	x9, x10, [x8, #0x10]
    3000:      	mov	w1, #0x31               // =49
    3004:      	stp	x9, x10, [sp, #0x30]
    3008:      	ldp	x9, x10, [x8, #0x20]
    300c:      	stp	x9, x10, [sp, #0x40]
    3010:      	ldp	x9, x8, [x8]
    3014:      	add	x10, sp, #0x20
    3018:      	stp	x9, x8, [sp, #0x20]
    301c:      	mov	w8, #0x31               // =49
    3020:      	mov	w9, #0x6                // =6
    3024:      	ldr	w2, [x21, #0x2c0]
    3028:      	blr	x9
    302c:      	ldr	x29, [x21, #0xed0]
    3030:      	lsr	x8, x29, #56
    3034:      	cbnz	x8, 0x1650 <perf_unwind_dotnet+0x1650>
    3038:      	b	0x2e64 <perf_unwind_dotnet+0x2e64>
    303c:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3040:      	add	x8, x8, #0x0
    3044:      	add	x0, sp, #0x20
    3048:      	ldp	x9, x10, [x8, #0x10]
    304c:      	mov	w1, #0x2e               // =46
    3050:      	stp	x9, x10, [sp, #0x30]
    3054:      	ldr	x9, [x8, #0x20]
    3058:      	add	x10, sp, #0x20
    305c:      	str	x9, [sp, #0x40]
    3060:      	ldur	x9, [x8, #0x26]
    3064:      	stur	x9, [sp, #0x46]
    3068:      	ldp	x9, x8, [x8]
    306c:      	stp	x9, x8, [sp, #0x20]
    3070:      	mov	w8, #0x2e               // =46
    3074:      	mov	w9, #0x6                // =6
    3078:      	ldr	w2, [sp, #0x8c]
    307c:      	blr	x9
    3080:      	ldr	x8, [sp, #0x10]
    3084:      	ldr	x29, [x8]
    3088:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    308c:      	ldr	x8, [x8]
    3090:      	ldr	w8, [x8]
    3094:      	cbnz	x29, 0x2e58 <perf_unwind_dotnet+0x2e58>
    3098:      	b	0x4d58 <perf_unwind_dotnet+0x4d58>
    309c:      	ldr	x8, [x21, #0x1108]
    30a0:      	cbz	x8, 0x31f8 <perf_unwind_dotnet+0x31f8>
    30a4:      	mov	w9, #-0x66              // =-102
    30a8:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    30ac:      	ldr	x8, [x21, #0x10d8]
    30b0:      	cbz	x8, 0x32b0 <perf_unwind_dotnet+0x32b0>
    30b4:      	mov	w9, #-0x5a              // =-90
    30b8:      	b	0x609c <perf_unwind_dotnet+0x609c>
    30bc:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    30c0:      	add	x8, x8, #0x0
    30c4:      	add	x0, sp, #0x20
    30c8:      	ldp	x9, x10, [x8, #0x20]
    30cc:      	and	x2, x23, #0xfffffffffffffffc
    30d0:      	mov	w1, #0x36               // =54
    30d4:      	mov	w3, w25
    30d8:      	stp	x9, x10, [sp, #0x40]
    30dc:      	ldur	x9, [x8, #0x2e]
    30e0:      	stur	x9, [sp, #0x4e]
    30e4:      	ldp	x9, x10, [x8]
    30e8:      	stp	x9, x10, [sp, #0x20]
    30ec:      	ldp	x8, x9, [x8, #0x10]
    30f0:      	add	x10, sp, #0x20
    30f4:      	stp	x8, x9, [sp, #0x30]
    30f8:      	mov	w8, #0x36               // =54
    30fc:      	mov	w9, #0x6                // =6
    3100:      	blr	x9
    3104:      	mov	w8, #0x1c               // =28
    3108:      	bic	w8, w8, w23, lsr #3
    310c:      	lsr	w25, w25, w8
    3110:      	cbnz	w25, 0x2a30 <perf_unwind_dotnet+0x2a30>
    3114:      	and	x8, x23, #0xffffffffffffff00
    3118:      	ldr	w25, [x21, #0x1168]
    311c:      	sub	x23, x8, #0x20
    3120:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3124:      	ldr	x8, [x8]
    3128:      	ldr	w8, [x8]
    312c:      	cbnz	w8, 0x32c0 <perf_unwind_dotnet+0x32c0>
    3130:      	cbz	w25, 0x330c <perf_unwind_dotnet+0x330c>
    3134:      	mov	w3, wzr
    3138:      	b	0x3e5c <perf_unwind_dotnet+0x3e5c>
    313c:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3140:      	add	x8, x8, #0x0
    3144:      	add	x0, sp, #0x20
    3148:      	ldp	x9, x10, [x8, #0x10]
    314c:      	mov	w1, #0x2e               // =46
    3150:      	mov	x2, x29
    3154:      	mov	x4, x25
    3158:      	stp	x9, x10, [sp, #0x30]
    315c:      	ldr	x9, [x8, #0x20]
    3160:      	add	x10, sp, #0x20
    3164:      	str	x9, [sp, #0x40]
    3168:      	ldur	x9, [x8, #0x26]
    316c:      	stur	x9, [sp, #0x46]
    3170:      	ldp	x9, x8, [x8]
    3174:      	stp	x9, x8, [sp, #0x20]
    3178:      	mov	w8, #0x2e               // =46
    317c:      	mov	w9, #0x6                // =6
    3180:      	blr	x9
    3184:      	b	0x2d60 <perf_unwind_dotnet+0x2d60>
    3188:      	ldr	x8, [x21, #0x10a8]
    318c:      	cbz	x8, 0x338c <perf_unwind_dotnet+0x338c>
    3190:      	mov	w9, #-0x4e              // =-78
    3194:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    3198:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    319c:      	add	x8, x8, #0x0
    31a0:      	add	x0, sp, #0x20
    31a4:      	ldp	x9, x10, [x8, #0x10]
    31a8:      	mov	w1, #0x2e               // =46
    31ac:      	stp	x9, x10, [sp, #0x30]
    31b0:      	ldr	x9, [x8, #0x20]
    31b4:      	add	x10, sp, #0x20
    31b8:      	str	x9, [sp, #0x40]
    31bc:      	ldur	x9, [x8, #0x26]
    31c0:      	stur	x9, [sp, #0x46]
    31c4:      	ldp	x9, x8, [x8]
    31c8:      	stp	x9, x8, [sp, #0x20]
    31cc:      	mov	w8, #0x2e               // =46
    31d0:      	mov	w9, #0x6                // =6
    31d4:      	ldr	w2, [sp, #0x8c]
    31d8:      	blr	x9
    31dc:      	mov	w22, wzr
    31e0:      	mov	w2, #0x1772             // =6002
    31e4:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    31e8:      	ldr	x8, [x8]
    31ec:      	ldr	w8, [x8]
    31f0:      	cbz	w8, 0x2a74 <perf_unwind_dotnet+0x2a74>
    31f4:      	b	0x3f88 <perf_unwind_dotnet+0x3f88>
    31f8:      	ldr	x8, [x21, #0x1100]
    31fc:      	cbz	x8, 0x339c <perf_unwind_dotnet+0x339c>
    3200:      	mov	w9, #-0x64              // =-100
    3204:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    3208:      	mov	w8, #0xa                // =10
    320c:      	add	x0, sp, #0x20
    3210:      	mov	w1, #0x32               // =50
    3214:      	strh	w8, [sp, #0x50]
    3218:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    321c:      	add	x8, x8, #0x0
    3220:      	mov	x2, x29
    3224:      	ldp	x9, x10, [x8, #0x10]
    3228:      	mov	w4, w25
    322c:      	stp	x9, x10, [sp, #0x30]
    3230:      	ldp	x9, x10, [x8, #0x20]
    3234:      	stp	x9, x10, [sp, #0x40]
    3238:      	ldp	x9, x8, [x8]
    323c:      	add	x10, sp, #0x20
    3240:      	stp	x9, x8, [sp, #0x20]
    3244:      	mov	w8, #0x32               // =50
    3248:      	mov	w9, #0x6                // =6
    324c:      	ldr	x3, [x21, #0xf00]
    3250:      	blr	x9
    3254:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3258:      	ldr	x8, [x8]
    325c:      	ldr	w8, [x8]
    3260:      	cbz	w8, 0x2ed0 <perf_unwind_dotnet+0x2ed0>
    3264:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3268:      	add	x8, x8, #0x0
    326c:      	add	x0, sp, #0x20
    3270:      	ldp	x9, x10, [x8, #0x10]
    3274:      	mov	w1, #0x2f               // =47
    3278:      	stp	x9, x10, [sp, #0x30]
    327c:      	ldr	x9, [x8, #0x20]
    3280:      	add	x10, sp, #0x20
    3284:      	str	x9, [sp, #0x40]
    3288:      	ldur	x9, [x8, #0x27]
    328c:      	stur	x9, [sp, #0x47]
    3290:      	ldp	x9, x8, [x8]
    3294:      	stp	x9, x8, [sp, #0x20]
    3298:      	mov	w8, #0x2f               // =47
    329c:      	mov	w9, #0x6                // =6
    32a0:      	ldr	x2, [x21, #0xf10]
    32a4:      	ldr	x3, [x21, #0xf08]
    32a8:      	blr	x9
    32ac:      	b	0x2ed0 <perf_unwind_dotnet+0x2ed0>
    32b0:      	ldr	x8, [x21, #0x10d0]
    32b4:      	cbz	x8, 0x33ac <perf_unwind_dotnet+0x33ac>
    32b8:      	mov	w9, #-0x58              // =-88
    32bc:      	b	0x609c <perf_unwind_dotnet+0x609c>
    32c0:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    32c4:      	add	x8, x8, #0x0
    32c8:      	add	x0, sp, #0x20
    32cc:      	ldp	x9, x10, [x8, #0x20]
    32d0:      	mov	w1, #0x37               // =55
    32d4:      	mov	x2, x23
    32d8:      	mov	w3, w25
    32dc:      	stp	x9, x10, [sp, #0x40]
    32e0:      	ldur	x9, [x8, #0x2f]
    32e4:      	stur	x9, [sp, #0x4f]
    32e8:      	ldp	x9, x10, [x8]
    32ec:      	stp	x9, x10, [sp, #0x20]
    32f0:      	ldp	x8, x9, [x8, #0x10]
    32f4:      	add	x10, sp, #0x20
    32f8:      	stp	x8, x9, [sp, #0x30]
    32fc:      	mov	w8, #0x37               // =55
    3300:      	mov	w9, #0x6                // =6
    3304:      	blr	x9
    3308:      	cbnz	w25, 0x3134 <perf_unwind_dotnet+0x3134>
    330c:      	ldr	x8, [x21, #0x1160]
    3310:      	cbz	x8, 0x331c <perf_unwind_dotnet+0x331c>
    3314:      	mov	w9, #-0x7c              // =-124
    3318:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    331c:      	ldr	x8, [x21, #0x1158]
    3320:      	cbz	x8, 0x332c <perf_unwind_dotnet+0x332c>
    3324:      	mov	w9, #-0x7a              // =-122
    3328:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    332c:      	ldr	x8, [x21, #0x1150]
    3330:      	cbz	x8, 0x333c <perf_unwind_dotnet+0x333c>
    3334:      	mov	w9, #-0x78              // =-120
    3338:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    333c:      	ldr	x8, [x21, #0x1148]
    3340:      	cbz	x8, 0x334c <perf_unwind_dotnet+0x334c>
    3344:      	mov	w9, #-0x76              // =-118
    3348:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    334c:      	ldr	x8, [x21, #0x1140]
    3350:      	cbz	x8, 0x335c <perf_unwind_dotnet+0x335c>
    3354:      	mov	w9, #-0x74              // =-116
    3358:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    335c:      	ldr	x8, [x21, #0x1138]
    3360:      	cbz	x8, 0x336c <perf_unwind_dotnet+0x336c>
    3364:      	mov	w9, #-0x72              // =-114
    3368:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    336c:      	ldr	x8, [x21, #0x1130]
    3370:      	cbz	x8, 0x337c <perf_unwind_dotnet+0x337c>
    3374:      	mov	w9, #-0x70              // =-112
    3378:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    337c:      	ldr	x8, [x21, #0x1128]
    3380:      	cbz	x8, 0x33bc <perf_unwind_dotnet+0x33bc>
    3384:      	mov	w9, #-0x6e              // =-110
    3388:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    338c:      	ldr	x8, [x21, #0x10a0]
    3390:      	cbz	x8, 0x33cc <perf_unwind_dotnet+0x33cc>
    3394:      	mov	w9, #-0x4c              // =-76
    3398:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    339c:      	ldr	x8, [x21, #0x10f8]
    33a0:      	cbz	x8, 0x33dc <perf_unwind_dotnet+0x33dc>
    33a4:      	mov	w9, #-0x62              // =-98
    33a8:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    33ac:      	ldr	x8, [x21, #0x10c8]
    33b0:      	cbz	x8, 0x3774 <perf_unwind_dotnet+0x3774>
    33b4:      	mov	w9, #-0x56              // =-86
    33b8:      	b	0x609c <perf_unwind_dotnet+0x609c>
    33bc:      	ldr	x8, [x21, #0x1120]
    33c0:      	cbz	x8, 0x3794 <perf_unwind_dotnet+0x3794>
    33c4:      	mov	w9, #-0x6c              // =-108
    33c8:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    33cc:      	ldr	x8, [x21, #0x1098]
    33d0:      	cbz	x8, 0x37f0 <perf_unwind_dotnet+0x37f0>
    33d4:      	mov	w9, #-0x4a              // =-74
    33d8:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    33dc:      	ldr	x8, [x21, #0x10f0]
    33e0:      	cbz	x8, 0x3800 <perf_unwind_dotnet+0x3800>
    33e4:      	mov	w9, #-0x60              // =-96
    33e8:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    33ec:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    33f0:      	add	x8, x8, #0x0
    33f4:      	add	x0, sp, #0x20
    33f8:      	ldp	x9, x10, [x8]
    33fc:      	mov	w1, #0x1e               // =30
    3400:      	stp	x9, x10, [sp, #0x20]
    3404:      	ldr	x9, [x8, #0x10]
    3408:      	ldur	x8, [x8, #0x16]
    340c:      	add	x10, sp, #0x20
    3410:      	str	x9, [sp, #0x30]
    3414:      	stur	x8, [sp, #0x36]
    3418:      	mov	w8, #0x1e               // =30
    341c:      	mov	w9, #0x6                // =6
    3420:      	ldrh	w2, [x23, #0x20]
    3424:      	blr	x9
    3428:      	ldrh	w8, [x23, #0x20]
    342c:      	ldr	w9, [x21, #0x1370]
    3430:      	lsr	w8, w9, w8
    3434:      	tbnz	w8, #0x0, 0x2f58 <perf_unwind_dotnet+0x2f58>
    3438:      	str	wzr, [sp, #0x68]
    343c:      	adrp	x0, 0x3000 <perf_unwind_dotnet+0x3000>
    3440:      	mov	w8, #0x1                // =1
    3444:      	add	x9, sp, #0x68
    3448:      	ldr	x0, [x0]
    344c:      	add	x1, sp, #0x68
    3450:      	blr	x8
    3454:      	cbz	x0, 0x3468 <perf_unwind_dotnet+0x3468>
    3458:      	ldr	x8, [x0]
    345c:      	add	x8, x8, #0x1
    3460:      	str	x8, [x0]
    3464:      	b	0x3478 <perf_unwind_dotnet+0x3478>
    3468:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    346c:      	ldr	x8, [x8]
    3470:      	ldr	w8, [x8]
    3474:      	cbnz	w8, 0x390c <perf_unwind_dotnet+0x390c>
    3478:      	ldrh	w25, [x23, #0x20]
    347c:      	cmp	w25, #0x8
    3480:      	b.ne	0x4f64 <perf_unwind_dotnet+0x4f64>
    3484:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3488:      	ldr	x25, [x21, #0xed8]
    348c:      	ldr	x29, [x21, #0xee0]
    3490:      	ldr	x24, [x21, #0xed0]
    3494:      	ldrb	w22, [x21, #0xf20]
    3498:      	ldr	x8, [x8]
    349c:      	ldr	w8, [x8]
    34a0:      	cbnz	w8, 0x3710 <perf_unwind_dotnet+0x3710>
    34a4:      	cmp	x29, x25
    34a8:      	b.lo	0x45cc <perf_unwind_dotnet+0x45cc>
    34ac:      	add	x8, x25, #0x2, lsl #12  // =0x2000
    34b0:      	cmp	x29, x8
    34b4:      	b.hs	0x45cc <perf_unwind_dotnet+0x45cc>
    34b8:      	ldr	x23, [x21, #0xf00]
    34bc:      	ldr	x25, [x21, #0xf10]
    34c0:      	mov	w8, #0x101              // =257
    34c4:      	str	x24, [sp, #0x68]
    34c8:      	strh	w8, [x21, #0xf20]
    34cc:      	and	x8, x23, #0xffffffffffffff80
    34d0:      	cmp	x8, #0x80
    34d4:      	b.ne	0x350c <perf_unwind_dotnet+0x350c>
    34d8:      	ldr	x8, [x21, #0xed8]
    34dc:      	mov	w9, #0x8                // =8
    34e0:      	mov	w10, #0x70              // =112
    34e4:      	ldr	x0, [sp, #0x10]
    34e8:      	mov	w1, #0x8                // =8
    34ec:      	ldr	x2, [x21, #0xed8]
    34f0:      	blr	x10
    34f4:      	cbnz	x0, 0x1e0 <perf_unwind_dotnet+0x1e0>
    34f8:      	ldr	x8, [x21, #0xed8]
    34fc:      	and	x23, x23, #0x7f
    3500:      	add	x8, x8, #0x8
    3504:      	str	x8, [x21, #0xed8]
    3508:      	b	0x39bc <perf_unwind_dotnet+0x39bc>
    350c:      	mov	w8, #0x10               // =16
    3510:      	mov	w9, #0x70               // =112
    3514:      	add	x10, sp, #0x70
    3518:      	add	x0, sp, #0x70
    351c:      	mov	w1, #0x10               // =16
    3520:      	mov	x2, x29
    3524:      	blr	x9
    3528:      	cbnz	x0, 0x27c <perf_unwind_dotnet+0x27c>
    352c:      	add	x8, x29, #0x10
    3530:      	str	x8, [x21, #0xed8]
    3534:      	ldp	x8, x9, [sp, #0x70]
    3538:      	str	x8, [x21, #0xee0]
    353c:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3540:      	str	x9, [x21, #0xed0]
    3544:      	ldr	x8, [x8]
    3548:      	ldr	w8, [x8]
    354c:      	cbnz	w8, 0x3810 <perf_unwind_dotnet+0x3810>
    3550:      	cmp	x23, #0x100
    3554:      	b.lo	0x39bc <perf_unwind_dotnet+0x39bc>
    3558:      	ldr	x8, [x21, #0xf10]
    355c:      	ldr	x25, [x21, #0xf00]
    3560:      	sub	x23, x24, x8
    3564:      	str	x8, [sp, #0x8]
    3568:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    356c:      	ldr	x8, [x8]
    3570:      	ldr	w8, [x8]
    3574:      	cbnz	w8, 0x38b4 <perf_unwind_dotnet+0x38b4>
    3578:      	lsr	x8, x23, #8
    357c:      	mov	w9, #0x7f               // =127
    3580:      	lsr	x10, x23, #15
    3584:      	mov	w1, #0x200              // =512
    3588:      	sub	w9, w9, w8
    358c:      	lsl	x8, x8, #2
    3590:      	cmp	x10, #0x0
    3594:      	sub	x8, x8, #0x3fc
    3598:      	and	x9, x9, #0x7f
    359c:      	csel	x8, x8, xzr, ne
    35a0:      	add	x2, x8, x25
    35a4:      	csel	x8, xzr, x9, ne
    35a8:      	ldr	x9, [sp, #0x18]
    35ac:      	add	x0, x9, x8, lsl #2
    35b0:      	mov	w8, #0x200              // =512
    35b4:      	mov	w9, #0x70               // =112
    35b8:      	blr	x9
    35bc:      	cbz	x0, 0x361c <perf_unwind_dotnet+0x361c>
    35c0:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    35c4:      	ldr	x8, [x8]
    35c8:      	ldr	w8, [x8]
    35cc:      	cbnz	w8, 0x6900 <perf_unwind_dotnet+0x6900>
    35d0:      	mov	w8, #0x5e               // =94
    35d4:      	adrp	x0, 0x3000 <perf_unwind_dotnet+0x3000>
    35d8:      	add	x9, sp, #0x8c
    35dc:      	str	w8, [sp, #0x8c]
    35e0:      	mov	w8, #0x1                // =1
    35e4:      	add	x1, sp, #0x8c
    35e8:      	ldr	x0, [x0]
    35ec:      	blr	x8
    35f0:      	cbz	x0, 0x365c <perf_unwind_dotnet+0x365c>
    35f4:      	ldr	x8, [x0]
    35f8:      	add	x8, x8, #0x1
    35fc:      	str	x8, [x0]
    3600:      	mov	w22, wzr
    3604:      	mov	w2, #0x1772             // =6002
    3608:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    360c:      	ldr	x8, [x8]
    3610:      	ldr	w8, [x8]
    3614:      	cbz	w8, 0x3684 <perf_unwind_dotnet+0x3684>
    3618:      	b	0x69c0 <perf_unwind_dotnet+0x69c0>
    361c:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3620:      	ldr	w25, [x21, #0x116c]
    3624:      	ldr	x8, [x8]
    3628:      	ldr	w8, [x8]
    362c:      	cbnz	w8, 0x3cec <perf_unwind_dotnet+0x3cec>
    3630:      	mov	w8, #0x1c               // =28
    3634:      	bic	w8, w8, w23, lsr #3
    3638:      	lsr	w25, w25, w8
    363c:      	cbz	w25, 0x3d44 <perf_unwind_dotnet+0x3d44>
    3640:      	and	x29, x23, #0xffffffffffffffe0
    3644:      	ands	w3, w25, #0xf
    3648:      	b.ne	0x396c <perf_unwind_dotnet+0x396c>
    364c:      	ubfx	w3, w25, #4, #4
    3650:      	cbz	w3, 0x36f0 <perf_unwind_dotnet+0x36f0>
    3654:      	sub	x29, x29, #0x20
    3658:      	b	0x396c <perf_unwind_dotnet+0x396c>
    365c:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3660:      	ldr	x8, [x8]
    3664:      	ldr	w8, [x8]
    3668:      	cbnz	w8, 0x3dd8 <perf_unwind_dotnet+0x3dd8>
    366c:      	mov	w22, wzr
    3670:      	mov	w2, #0x1772             // =6002
    3674:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3678:      	ldr	x8, [x8]
    367c:      	ldr	w8, [x8]
    3680:      	cbnz	w8, 0x69c0 <perf_unwind_dotnet+0x69c0>
    3684:      	cbz	w22, 0x621c <perf_unwind_dotnet+0x621c>
    3688:      	ldr	w8, [x21, #0x2c0]
    368c:      	adrp	x23, 0x3000 <perf_unwind_dotnet+0x3000>
    3690:      	adrp	x24, 0x3000 <perf_unwind_dotnet+0x3000>
    3694:      	ldr	x23, [x23]
    3698:      	ldr	x24, [x24]
    369c:      	cmp	w8, #0x7e
    36a0:      	b.hi	0x49c <perf_unwind_dotnet+0x49c>
    36a4:      	add	w9, w8, #0x1
    36a8:      	mov	w10, #0x8a              // =138
    36ac:      	str	w9, [x21, #0x2c0]
    36b0:      	mov	w9, #0x18               // =24
    36b4:      	umaddl	x8, w8, w9, x21
    36b8:      	mov	w9, #0x1773             // =6003
    36bc:      	str	x9, [x8, #0x2d8]
    36c0:      	add	x9, x8, #0x2d0
    36c4:      	str	xzr, [x8, #0x2d0]
    36c8:      	strb	w10, [x8, #0x2e0]
    36cc:      	str	wzr, [x8, #0x2e4]
    36d0:      	stur	wzr, [x9, #0x11]
    36d4:      	ldr	x8, [sp, #0x10]
    36d8:      	ldr	x29, [x8]
    36dc:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    36e0:      	ldr	x8, [x8]
    36e4:      	ldr	w8, [x8]
    36e8:      	cbnz	x29, 0x3a88 <perf_unwind_dotnet+0x3a88>
    36ec:      	b	0x4d58 <perf_unwind_dotnet+0x4d58>
    36f0:      	ubfx	w3, w25, #8, #4
    36f4:      	cbz	w3, 0x3700 <perf_unwind_dotnet+0x3700>
    36f8:      	sub	x29, x29, #0x40
    36fc:      	b	0x396c <perf_unwind_dotnet+0x396c>
    3700:      	ubfx	w3, w25, #12, #4
    3704:      	cbz	w3, 0x3764 <perf_unwind_dotnet+0x3764>
    3708:      	sub	x29, x29, #0x60
    370c:      	b	0x396c <perf_unwind_dotnet+0x396c>
    3710:      	mov	w8, #0x786c             // =30828
    3714:      	add	x0, sp, #0x20
    3718:      	mov	w1, #0x23               // =35
    371c:      	mov	x2, x24
    3720:      	mov	x3, x25
    3724:      	mov	x4, x29
    3728:      	movk	w8, #0xa, lsl #16
    372c:      	stur	w8, [sp, #0x3f]
    3730:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3734:      	add	x8, x8, #0x0
    3738:      	ldp	x9, x10, [x8]
    373c:      	stp	x9, x10, [sp, #0x20]
    3740:      	ldp	x9, x8, [x8, #0x10]
    3744:      	add	x10, sp, #0x20
    3748:      	stp	x9, x8, [sp, #0x30]
    374c:      	mov	w8, #0x23               // =35
    3750:      	mov	w9, #0x6                // =6
    3754:      	blr	x9
    3758:      	cmp	x29, x25
    375c:      	b.hs	0x34ac <perf_unwind_dotnet+0x34ac>
    3760:      	b	0x45cc <perf_unwind_dotnet+0x45cc>
    3764:      	ubfx	w3, w25, #16, #4
    3768:      	cbz	w3, 0x3784 <perf_unwind_dotnet+0x3784>
    376c:      	sub	x29, x29, #0x80
    3770:      	b	0x396c <perf_unwind_dotnet+0x396c>
    3774:      	ldr	x8, [x21, #0x10c0]
    3778:      	cbz	x8, 0x3864 <perf_unwind_dotnet+0x3864>
    377c:      	mov	w9, #-0x54              // =-84
    3780:      	b	0x609c <perf_unwind_dotnet+0x609c>
    3784:      	ubfx	w3, w25, #20, #4
    3788:      	cbz	w3, 0x3874 <perf_unwind_dotnet+0x3874>
    378c:      	sub	x29, x29, #0xa0
    3790:      	b	0x396c <perf_unwind_dotnet+0x396c>
    3794:      	ldr	x8, [x21, #0x1118]
    3798:      	cbz	x8, 0x3884 <perf_unwind_dotnet+0x3884>
    379c:      	mov	w9, #-0x6a              // =-106
    37a0:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    37a4:      	mov	w8, #0x656e             // =25966
    37a8:      	add	x0, sp, #0x20
    37ac:      	mov	w1, #0x1b               // =27
    37b0:      	movk	w8, #0xa, lsl #16
    37b4:      	stur	w8, [sp, #0x37]
    37b8:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    37bc:      	add	x8, x8, #0x0
    37c0:      	ldp	x9, x10, [x8]
    37c4:      	ldr	x8, [x8, #0x10]
    37c8:      	stp	x9, x10, [sp, #0x20]
    37cc:      	str	x8, [sp, #0x30]
    37d0:      	mov	w8, #0x1b               // =27
    37d4:      	mov	w9, #0x6                // =6
    37d8:      	add	x10, sp, #0x20
    37dc:      	blr	x9
    37e0:      	mov	w25, #0x1               // =1
    37e4:      	cmp	w25, #0x8
    37e8:      	b.eq	0x3484 <perf_unwind_dotnet+0x3484>
    37ec:      	b	0x4f64 <perf_unwind_dotnet+0x4f64>
    37f0:      	ldr	x8, [x21, #0x1090]
    37f4:      	cbz	x8, 0x3894 <perf_unwind_dotnet+0x3894>
    37f8:      	mov	w9, #-0x48              // =-72
    37fc:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    3800:      	ldr	x8, [x21, #0x10e8]
    3804:      	cbz	x8, 0x38a4 <perf_unwind_dotnet+0x38a4>
    3808:      	mov	w9, #-0x5e              // =-94
    380c:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    3810:      	mov	w8, #0x786c             // =30828
    3814:      	add	x0, sp, #0x20
    3818:      	mov	w1, #0x23               // =35
    381c:      	movk	w8, #0xa, lsl #16
    3820:      	stur	w8, [sp, #0x3f]
    3824:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3828:      	add	x8, x8, #0x0
    382c:      	ldp	x9, x10, [x8]
    3830:      	stp	x9, x10, [sp, #0x20]
    3834:      	ldp	x9, x8, [x8, #0x10]
    3838:      	add	x10, sp, #0x20
    383c:      	stp	x9, x8, [sp, #0x30]
    3840:      	mov	w8, #0x23               // =35
    3844:      	mov	w9, #0x6                // =6
    3848:      	ldr	x2, [x21, #0xed0]
    384c:      	ldr	x3, [x21, #0xed8]
    3850:      	ldr	x4, [x21, #0xee0]
    3854:      	blr	x9
    3858:      	cmp	x23, #0x100
    385c:      	b.hs	0x3558 <perf_unwind_dotnet+0x3558>
    3860:      	b	0x39bc <perf_unwind_dotnet+0x39bc>
    3864:      	ldr	x8, [x21, #0x10b8]
    3868:      	cbz	x8, 0x3954 <perf_unwind_dotnet+0x3954>
    386c:      	mov	w9, #-0x52              // =-82
    3870:      	b	0x609c <perf_unwind_dotnet+0x609c>
    3874:      	ubfx	w3, w25, #24, #4
    3878:      	cbz	w3, 0x3964 <perf_unwind_dotnet+0x3964>
    387c:      	sub	x29, x29, #0xc0
    3880:      	b	0x396c <perf_unwind_dotnet+0x396c>
    3884:      	ldr	x8, [x21, #0x1110]
    3888:      	cbz	x8, 0x3ccc <perf_unwind_dotnet+0x3ccc>
    388c:      	mov	w9, #-0x68              // =-104
    3890:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    3894:      	ldr	x8, [x21, #0x1088]
    3898:      	cbz	x8, 0x3cdc <perf_unwind_dotnet+0x3cdc>
    389c:      	mov	w9, #-0x46              // =-70
    38a0:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    38a4:      	ldr	x8, [x21, #0x10e0]
    38a8:      	cbz	x8, 0x3d6c <perf_unwind_dotnet+0x3d6c>
    38ac:      	mov	w9, #-0x5c              // =-92
    38b0:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    38b4:      	mov	w8, #0xa                // =10
    38b8:      	mov	w11, #0x6               // =6
    38bc:      	add	x0, sp, #0x20
    38c0:      	strh	w8, [sp, #0x60]
    38c4:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    38c8:      	add	x8, x8, #0x0
    38cc:      	mov	w1, #0x42               // =66
    38d0:      	ldp	x9, x10, [x8, #0x20]
    38d4:      	mov	x2, x23
    38d8:      	mov	x4, x25
    38dc:      	stp	x9, x10, [sp, #0x40]
    38e0:      	ldp	x9, x10, [x8, #0x30]
    38e4:      	stp	x9, x10, [sp, #0x50]
    38e8:      	ldp	x9, x10, [x8]
    38ec:      	stp	x9, x10, [sp, #0x20]
    38f0:      	ldp	x9, x8, [x8, #0x10]
    38f4:      	mov	w10, #0x42              // =66
    38f8:      	stp	x9, x8, [sp, #0x30]
    38fc:      	add	x8, sp, #0x20
    3900:      	ldr	x3, [sp, #0x8]
    3904:      	blr	x11
    3908:      	b	0x3578 <perf_unwind_dotnet+0x3578>
    390c:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3910:      	add	x8, x8, #0x0
    3914:      	add	x0, sp, #0x20
    3918:      	ldp	x9, x10, [x8, #0x10]
    391c:      	mov	w1, #0x2e               // =46
    3920:      	stp	x9, x10, [sp, #0x30]
    3924:      	ldr	x9, [x8, #0x20]
    3928:      	add	x10, sp, #0x20
    392c:      	str	x9, [sp, #0x40]
    3930:      	ldur	x9, [x8, #0x26]
    3934:      	stur	x9, [sp, #0x46]
    3938:      	ldp	x9, x8, [x8]
    393c:      	stp	x9, x8, [sp, #0x20]
    3940:      	mov	w8, #0x2e               // =46
    3944:      	mov	w9, #0x6                // =6
    3948:      	ldr	w2, [sp, #0x68]
    394c:      	blr	x9
    3950:      	b	0x3478 <perf_unwind_dotnet+0x3478>
    3954:      	ldr	x8, [x21, #0x10b0]
    3958:      	cbz	x8, 0x3d7c <perf_unwind_dotnet+0x3d7c>
    395c:      	mov	w9, #-0x50              // =-80
    3960:      	b	0x609c <perf_unwind_dotnet+0x609c>
    3964:      	lsr	w3, w25, #28
    3968:      	sub	x29, x29, #0xe0
    396c:      	ldr	x8, [sp, #0x8]
    3970:      	lsl	w9, w3, #2
    3974:      	sub	w9, w9, #0x4
    3978:      	add	x8, x29, x8
    397c:      	add	x25, x8, x9
    3980:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3984:      	ldr	x8, [x8]
    3988:      	ldr	w8, [x8]
    398c:      	cbnz	w8, 0x3d8c <perf_unwind_dotnet+0x3d8c>
    3990:      	sub	x2, x25, #0x8
    3994:      	mov	w8, #0x8                // =8
    3998:      	mov	w9, #0x70               // =112
    399c:      	add	x10, sp, #0x68
    39a0:      	add	x0, sp, #0x68
    39a4:      	mov	w1, #0x8                // =8
    39a8:      	blr	x9
    39ac:      	adrp	x23, 0x3000 <perf_unwind_dotnet+0x3000>
    39b0:      	ldr	x23, [x23]
    39b4:      	cbnz	x0, 0x844 <perf_unwind_dotnet+0x844>
    39b8:      	mov	w23, #0x1f              // =31
    39bc:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    39c0:      	ldr	x8, [x8]
    39c4:      	ldr	w8, [x8]
    39c8:      	cbnz	w8, 0x3bb4 <perf_unwind_dotnet+0x3bb4>
    39cc:      	ldr	w8, [x21, #0x2c0]
    39d0:      	cmp	w8, #0x7e
    39d4:      	b.hi	0x8a4 <perf_unwind_dotnet+0x8a4>
    39d8:      	ldr	x9, [sp, #0x68]
    39dc:      	add	w11, w8, #0x1
    39e0:      	sub	x10, x24, x25
    39e4:      	adrp	x0, 0x3000 <perf_unwind_dotnet+0x3000>
    39e8:      	str	w11, [x21, #0x2c0]
    39ec:      	mov	w11, #0x18              // =24
    39f0:      	add	x1, sp, #0x8c
    39f4:      	umaddl	x8, w8, w11, x21
    39f8:      	add	x9, x23, x9, lsl #5
    39fc:      	str	x10, [x8, #0x2d8]
    3a00:      	mov	w10, #0xa               // =10
    3a04:      	strb	w22, [x8, #0x2e1]
    3a08:      	strh	wzr, [x8, #0x2e6]
    3a0c:      	strb	w10, [x8, #0x2e0]
    3a10:      	str	x9, [x8, #0x2d0]
    3a14:      	add	x9, x8, #0x2d0
    3a18:      	mov	w8, #0x5b               // =91
    3a1c:      	stur	wzr, [x9, #0x12]
    3a20:      	str	w8, [sp, #0x8c]
    3a24:      	mov	w8, #0x1                // =1
    3a28:      	add	x9, sp, #0x8c
    3a2c:      	ldr	x0, [x0]
    3a30:      	blr	x8
    3a34:      	cbz	x0, 0x3a60 <perf_unwind_dotnet+0x3a60>
    3a38:      	ldr	x8, [x0]
    3a3c:      	add	x8, x8, #0x1
    3a40:      	str	x8, [x0]
    3a44:      	ldr	x8, [sp, #0x10]
    3a48:      	ldr	x29, [x8]
    3a4c:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3a50:      	ldr	x8, [x8]
    3a54:      	ldr	w8, [x8]
    3a58:      	cbnz	x29, 0x3a88 <perf_unwind_dotnet+0x3a88>
    3a5c:      	b	0x4d58 <perf_unwind_dotnet+0x4d58>
    3a60:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3a64:      	ldr	x8, [x8]
    3a68:      	ldr	w8, [x8]
    3a6c:      	cbnz	w8, 0x3c6c <perf_unwind_dotnet+0x3c6c>
    3a70:      	ldr	x8, [sp, #0x10]
    3a74:      	ldr	x29, [x8]
    3a78:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3a7c:      	ldr	x8, [x8]
    3a80:      	ldr	w8, [x8]
    3a84:      	cbz	x29, 0x4d58 <perf_unwind_dotnet+0x4d58>
    3a88:      	cbnz	w8, 0x3c1c <perf_unwind_dotnet+0x3c1c>
    3a8c:      	lsr	x8, x29, #56
    3a90:      	cbnz	x8, 0x1650 <perf_unwind_dotnet+0x1650>
    3a94:      	cmp	x29, #0x1, lsl #12      // =0x1000
    3a98:      	b.lo	0x1784 <perf_unwind_dotnet+0x1784>
    3a9c:      	ldr	w8, [x21]
    3aa0:      	mov	w9, #0x60               // =96
    3aa4:      	adrp	x0, 0x3000 <perf_unwind_dotnet+0x3000>
    3aa8:      	add	x1, sp, #0x70
    3aac:      	rev	w8, w8
    3ab0:      	stp	w9, w8, [sp, #0x70]
    3ab4:      	rev	x8, x29
    3ab8:      	add	x9, sp, #0x70
    3abc:      	str	x8, [sp, #0x78]
    3ac0:      	mov	w8, #0x1                // =1
    3ac4:      	ldr	x0, [x0]
    3ac8:      	blr	x8
    3acc:      	cbz	x0, 0x4eec <perf_unwind_dotnet+0x4eec>
    3ad0:      	ldr	x8, [x0, #0x8]
    3ad4:      	and	x9, x8, #0xffffffffffffff
    3ad8:      	lsr	x25, x8, #56
    3adc:      	str	x9, [x21, #0xf10]
    3ae0:      	ldr	x8, [x0]
    3ae4:      	str	x8, [x21, #0xf00]
    3ae8:      	sub	x8, x29, x9
    3aec:      	str	x8, [x21, #0xf08]
    3af0:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3af4:      	ldr	x8, [x8]
    3af8:      	ldr	w8, [x8]
    3afc:      	cbnz	w8, 0x4094 <perf_unwind_dotnet+0x4094>
    3b00:      	cmp	w25, #0x1
    3b04:      	b.ne	0x42e8 <perf_unwind_dotnet+0x42e8>
    3b08:      	ldr	x8, [x21, #0xf00]
    3b0c:      	adrp	x0, 0x3000 <perf_unwind_dotnet+0x3000>
    3b10:      	ldr	x22, [x21, #0xf08]
    3b14:      	mov	w9, #0x1                // =1
    3b18:      	add	x1, sp, #0x70
    3b1c:      	mov	w25, #0x1               // =1
    3b20:      	str	x8, [sp, #0x70]
    3b24:      	add	x8, sp, #0x70
    3b28:      	ldr	x0, [x0]
    3b2c:      	blr	x9
    3b30:      	cbz	x0, 0x3ba8 <perf_unwind_dotnet+0x3ba8>
    3b34:      	ldr	x8, [x0]
    3b38:      	mov	x23, x0
    3b3c:      	cmp	x8, x22
    3b40:      	b.hi	0x3b50 <perf_unwind_dotnet+0x3b50>
    3b44:      	ldr	x8, [x23, #0x8]
    3b48:      	cmp	x8, x22
    3b4c:      	b.hs	0x3b68 <perf_unwind_dotnet+0x3b68>
    3b50:      	ldr	x8, [x23, #0x10]
    3b54:      	cmp	x8, x22
    3b58:      	b.hi	0x3b98 <perf_unwind_dotnet+0x3b98>
    3b5c:      	ldr	x8, [x23, #0x18]
    3b60:      	cmp	x8, x22
    3b64:      	b.lo	0x3b98 <perf_unwind_dotnet+0x3b98>
    3b68:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3b6c:      	ldr	x8, [x8]
    3b70:      	ldr	w8, [x8]
    3b74:      	cbnz	w8, 0x4258 <perf_unwind_dotnet+0x4258>
    3b78:      	ldrh	w8, [x23, #0x20]
    3b7c:      	ldr	w9, [x21, #0x1370]
    3b80:      	lsr	w8, w9, w8
    3b84:      	tbz	w8, #0x0, 0x42a4 <perf_unwind_dotnet+0x42a4>
    3b88:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3b8c:      	ldr	x8, [x8]
    3b90:      	ldr	w8, [x8]
    3b94:      	cbnz	w8, 0x4834 <perf_unwind_dotnet+0x4834>
    3b98:      	mov	w25, #0x1               // =1
    3b9c:      	cmp	w25, #0x8
    3ba0:      	b.eq	0x42f0 <perf_unwind_dotnet+0x42f0>
    3ba4:      	b	0x4f64 <perf_unwind_dotnet+0x4f64>
    3ba8:      	cmp	w25, #0x8
    3bac:      	b.eq	0x42f0 <perf_unwind_dotnet+0x42f0>
    3bb0:      	b	0x4f64 <perf_unwind_dotnet+0x4f64>
    3bb4:      	mov	w8, #0x786c             // =30828
    3bb8:      	sub	x4, x24, x25
    3bbc:      	add	x0, sp, #0x20
    3bc0:      	mov	w1, #0x43               // =67
    3bc4:      	mov	x2, x25
    3bc8:      	movk	w8, #0xa, lsl #16
    3bcc:      	stur	w8, [sp, #0x5f]
    3bd0:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3bd4:      	add	x8, x8, #0x0
    3bd8:      	ldp	x9, x10, [x8, #0x20]
    3bdc:      	stp	x9, x10, [sp, #0x40]
    3be0:      	ldp	x9, x10, [x8, #0x30]
    3be4:      	stp	x9, x10, [sp, #0x50]
    3be8:      	ldp	x9, x10, [x8]
    3bec:      	stp	x9, x10, [sp, #0x20]
    3bf0:      	ldp	x9, x8, [x8, #0x10]
    3bf4:      	add	x10, sp, #0x20
    3bf8:      	stp	x9, x8, [sp, #0x30]
    3bfc:      	mov	w8, #0x43               // =67
    3c00:      	mov	w9, #0x6                // =6
    3c04:      	ldr	x3, [sp, #0x68]
    3c08:      	blr	x9
    3c0c:      	ldr	w8, [x21, #0x2c0]
    3c10:      	cmp	w8, #0x7e
    3c14:      	b.hi	0x8a4 <perf_unwind_dotnet+0x8a4>
    3c18:      	b	0x39d8 <perf_unwind_dotnet+0x39d8>
    3c1c:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3c20:      	add	x8, x8, #0x0
    3c24:      	strb	wzr, [sp, #0x50]
    3c28:      	add	x0, sp, #0x20
    3c2c:      	ldp	x9, x10, [x8, #0x10]
    3c30:      	mov	w1, #0x31               // =49
    3c34:      	stp	x9, x10, [sp, #0x30]
    3c38:      	ldp	x9, x10, [x8, #0x20]
    3c3c:      	stp	x9, x10, [sp, #0x40]
    3c40:      	ldp	x9, x8, [x8]
    3c44:      	add	x10, sp, #0x20
    3c48:      	stp	x9, x8, [sp, #0x20]
    3c4c:      	mov	w8, #0x31               // =49
    3c50:      	mov	w9, #0x6                // =6
    3c54:      	ldr	w2, [x21, #0x2c0]
    3c58:      	blr	x9
    3c5c:      	ldr	x29, [x21, #0xed0]
    3c60:      	lsr	x8, x29, #56
    3c64:      	cbnz	x8, 0x1650 <perf_unwind_dotnet+0x1650>
    3c68:      	b	0x3a94 <perf_unwind_dotnet+0x3a94>
    3c6c:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3c70:      	add	x8, x8, #0x0
    3c74:      	add	x0, sp, #0x20
    3c78:      	ldp	x9, x10, [x8, #0x10]
    3c7c:      	mov	w1, #0x2e               // =46
    3c80:      	stp	x9, x10, [sp, #0x30]
    3c84:      	ldr	x9, [x8, #0x20]
    3c88:      	add	x10, sp, #0x20
    3c8c:      	str	x9, [sp, #0x40]
    3c90:      	ldur	x9, [x8, #0x26]
    3c94:      	stur	x9, [sp, #0x46]
    3c98:      	ldp	x9, x8, [x8]
    3c9c:      	stp	x9, x8, [sp, #0x20]
    3ca0:      	mov	w8, #0x2e               // =46
    3ca4:      	mov	w9, #0x6                // =6
    3ca8:      	ldr	w2, [sp, #0x8c]
    3cac:      	blr	x9
    3cb0:      	ldr	x8, [sp, #0x10]
    3cb4:      	ldr	x29, [x8]
    3cb8:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3cbc:      	ldr	x8, [x8]
    3cc0:      	ldr	w8, [x8]
    3cc4:      	cbnz	x29, 0x3a88 <perf_unwind_dotnet+0x3a88>
    3cc8:      	b	0x4d58 <perf_unwind_dotnet+0x4d58>
    3ccc:      	ldr	x8, [x21, #0x1108]
    3cd0:      	cbz	x8, 0x3e38 <perf_unwind_dotnet+0x3e38>
    3cd4:      	mov	w9, #-0x66              // =-102
    3cd8:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    3cdc:      	ldr	x8, [x21, #0x1080]
    3ce0:      	cbz	x8, 0x4084 <perf_unwind_dotnet+0x4084>
    3ce4:      	mov	w9, #-0x44              // =-68
    3ce8:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    3cec:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3cf0:      	add	x8, x8, #0x0
    3cf4:      	add	x0, sp, #0x20
    3cf8:      	ldp	x9, x10, [x8, #0x20]
    3cfc:      	and	x2, x23, #0xfffffffffffffffc
    3d00:      	mov	w1, #0x36               // =54
    3d04:      	mov	w3, w25
    3d08:      	stp	x9, x10, [sp, #0x40]
    3d0c:      	ldur	x9, [x8, #0x2e]
    3d10:      	stur	x9, [sp, #0x4e]
    3d14:      	ldp	x9, x10, [x8]
    3d18:      	stp	x9, x10, [sp, #0x20]
    3d1c:      	ldp	x8, x9, [x8, #0x10]
    3d20:      	add	x10, sp, #0x20
    3d24:      	stp	x8, x9, [sp, #0x30]
    3d28:      	mov	w8, #0x36               // =54
    3d2c:      	mov	w9, #0x6                // =6
    3d30:      	blr	x9
    3d34:      	mov	w8, #0x1c               // =28
    3d38:      	bic	w8, w8, w23, lsr #3
    3d3c:      	lsr	w25, w25, w8
    3d40:      	cbnz	w25, 0x3640 <perf_unwind_dotnet+0x3640>
    3d44:      	and	x8, x23, #0xffffffffffffff00
    3d48:      	ldr	w25, [x21, #0x1168]
    3d4c:      	sub	x23, x8, #0x20
    3d50:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3d54:      	ldr	x8, [x8]
    3d58:      	ldr	w8, [x8]
    3d5c:      	cbnz	w8, 0x413c <perf_unwind_dotnet+0x413c>
    3d60:      	cbz	w25, 0x4188 <perf_unwind_dotnet+0x4188>
    3d64:      	mov	w3, wzr
    3d68:      	b	0x6894 <perf_unwind_dotnet+0x6894>
    3d6c:      	ldr	x8, [x21, #0x10d8]
    3d70:      	cbz	x8, 0x41f8 <perf_unwind_dotnet+0x41f8>
    3d74:      	mov	w9, #-0x5a              // =-90
    3d78:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    3d7c:      	ldr	x8, [x21, #0x10a8]
    3d80:      	cbz	x8, 0x4208 <perf_unwind_dotnet+0x4208>
    3d84:      	mov	w9, #-0x4e              // =-78
    3d88:      	b	0x609c <perf_unwind_dotnet+0x609c>
    3d8c:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3d90:      	add	x8, x8, #0x0
    3d94:      	add	x0, sp, #0x20
    3d98:      	ldp	x9, x10, [x8, #0x10]
    3d9c:      	mov	w1, #0x2e               // =46
    3da0:      	mov	x2, x29
    3da4:      	mov	x4, x25
    3da8:      	stp	x9, x10, [sp, #0x30]
    3dac:      	ldr	x9, [x8, #0x20]
    3db0:      	add	x10, sp, #0x20
    3db4:      	str	x9, [sp, #0x40]
    3db8:      	ldur	x9, [x8, #0x26]
    3dbc:      	stur	x9, [sp, #0x46]
    3dc0:      	ldp	x9, x8, [x8]
    3dc4:      	stp	x9, x8, [sp, #0x20]
    3dc8:      	mov	w8, #0x2e               // =46
    3dcc:      	mov	w9, #0x6                // =6
    3dd0:      	blr	x9
    3dd4:      	b	0x3990 <perf_unwind_dotnet+0x3990>
    3dd8:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3ddc:      	add	x8, x8, #0x0
    3de0:      	add	x0, sp, #0x20
    3de4:      	ldp	x9, x10, [x8, #0x10]
    3de8:      	mov	w1, #0x2e               // =46
    3dec:      	stp	x9, x10, [sp, #0x30]
    3df0:      	ldr	x9, [x8, #0x20]
    3df4:      	add	x10, sp, #0x20
    3df8:      	str	x9, [sp, #0x40]
    3dfc:      	ldur	x9, [x8, #0x26]
    3e00:      	stur	x9, [sp, #0x46]
    3e04:      	ldp	x9, x8, [x8]
    3e08:      	stp	x9, x8, [sp, #0x20]
    3e0c:      	mov	w8, #0x2e               // =46
    3e10:      	mov	w9, #0x6                // =6
    3e14:      	ldr	w2, [sp, #0x8c]
    3e18:      	blr	x9
    3e1c:      	mov	w22, wzr
    3e20:      	mov	w2, #0x1772             // =6002
    3e24:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3e28:      	ldr	x8, [x8]
    3e2c:      	ldr	w8, [x8]
    3e30:      	cbz	w8, 0x3684 <perf_unwind_dotnet+0x3684>
    3e34:      	b	0x69c0 <perf_unwind_dotnet+0x69c0>
    3e38:      	ldr	x8, [x21, #0x1100]
    3e3c:      	cbz	x8, 0x4228 <perf_unwind_dotnet+0x4228>
    3e40:      	mov	w9, #-0x64              // =-100
    3e44:      	lsr	x10, x8, #32
    3e48:      	cmp	x10, #0x0
    3e4c:      	cset	w11, ne
    3e50:      	csel	w25, w10, w8, ne
    3e54:      	sub	w8, w9, w11
    3e58:      	add	w3, w8, #0x7e
    3e5c:      	lsl	w8, w3, #8
    3e60:      	subs	x29, x23, x8
    3e64:      	b.hs	0x3f00 <perf_unwind_dotnet+0x3f00>
    3e68:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3e6c:      	ldr	x8, [x8]
    3e70:      	ldr	w8, [x8]
    3e74:      	cbz	w8, 0x29c0 <perf_unwind_dotnet+0x29c0>
    3e78:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3e7c:      	add	x8, x8, #0x0
    3e80:      	add	x0, sp, #0x20
    3e84:      	ldp	x9, x10, [x8, #0x10]
    3e88:      	mov	w1, #0x2e               // =46
    3e8c:      	stp	x9, x10, [sp, #0x30]
    3e90:      	ldr	x9, [x8, #0x20]
    3e94:      	add	x10, sp, #0x20
    3e98:      	str	x9, [sp, #0x40]
    3e9c:      	ldur	x9, [x8, #0x26]
    3ea0:      	stur	x9, [sp, #0x46]
    3ea4:      	ldp	x9, x8, [x8]
    3ea8:      	stp	x9, x8, [sp, #0x20]
    3eac:      	mov	w8, #0x2e               // =46
    3eb0:      	mov	w9, #0x6                // =6
    3eb4:      	blr	x9
    3eb8:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3ebc:      	ldr	x8, [x8]
    3ec0:      	ldr	w8, [x8]
    3ec4:      	cbz	w8, 0x29c0 <perf_unwind_dotnet+0x29c0>
    3ec8:      	mov	w8, #0x646e             // =25710
    3ecc:      	add	x10, sp, #0x20
    3ed0:      	add	x0, sp, #0x20
    3ed4:      	mov	w1, #0x13               // =19
    3ed8:      	movk	w8, #0xa, lsl #16
    3edc:      	stur	w8, [sp, #0x2f]
    3ee0:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3ee4:      	add	x8, x8, #0x0
    3ee8:      	ldp	x9, x8, [x8]
    3eec:      	stp	x9, x8, [sp, #0x20]
    3ef0:      	mov	w8, #0x13               // =19
    3ef4:      	mov	w9, #0x6                // =6
    3ef8:      	blr	x9
    3efc:      	b	0x29c0 <perf_unwind_dotnet+0x29c0>
    3f00:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3f04:      	ldr	x8, [x8]
    3f08:      	ldr	w8, [x8]
    3f0c:      	cbnz	w8, 0x3fc8 <perf_unwind_dotnet+0x3fc8>
    3f10:      	cbnz	w25, 0x2a34 <perf_unwind_dotnet+0x2a34>
    3f14:      	mov	w8, #0x5f               // =95
    3f18:      	adrp	x0, 0x3000 <perf_unwind_dotnet+0x3000>
    3f1c:      	add	x9, sp, #0x8c
    3f20:      	str	w8, [sp, #0x8c]
    3f24:      	mov	w8, #0x1                // =1
    3f28:      	add	x1, sp, #0x8c
    3f2c:      	ldr	x0, [x0]
    3f30:      	blr	x8
    3f34:      	cbz	x0, 0x3f60 <perf_unwind_dotnet+0x3f60>
    3f38:      	ldr	x8, [x0]
    3f3c:      	add	x8, x8, #0x1
    3f40:      	str	x8, [x0]
    3f44:      	mov	w2, #0x1773             // =6003
    3f48:      	mov	w22, #0x1               // =1
    3f4c:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3f50:      	ldr	x8, [x8]
    3f54:      	ldr	w8, [x8]
    3f58:      	cbz	w8, 0x2a74 <perf_unwind_dotnet+0x2a74>
    3f5c:      	b	0x3f88 <perf_unwind_dotnet+0x3f88>
    3f60:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3f64:      	ldr	x8, [x8]
    3f68:      	ldr	w8, [x8]
    3f6c:      	cbnz	w8, 0x4024 <perf_unwind_dotnet+0x4024>
    3f70:      	mov	w2, #0x1773             // =6003
    3f74:      	mov	w22, #0x1               // =1
    3f78:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3f7c:      	ldr	x8, [x8]
    3f80:      	ldr	w8, [x8]
    3f84:      	cbz	w8, 0x2a74 <perf_unwind_dotnet+0x2a74>
    3f88:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3f8c:      	add	x8, x8, #0x0
    3f90:      	add	x0, sp, #0x20
    3f94:      	ldp	x9, x10, [x8, #0x10]
    3f98:      	mov	w1, #0x28               // =40
    3f9c:      	stp	x9, x10, [sp, #0x30]
    3fa0:      	ldr	x9, [x8, #0x20]
    3fa4:      	add	x10, sp, #0x20
    3fa8:      	str	x9, [sp, #0x40]
    3fac:      	ldp	x8, x9, [x8]
    3fb0:      	stp	x8, x9, [sp, #0x20]
    3fb4:      	mov	w8, #0x28               // =40
    3fb8:      	mov	w9, #0x6                // =6
    3fbc:      	blr	x9
    3fc0:      	cbnz	w22, 0x2a78 <perf_unwind_dotnet+0x2a78>
    3fc4:      	b	0x621c <perf_unwind_dotnet+0x621c>
    3fc8:      	mov	w8, #0x7825             // =30757
    3fcc:      	add	x0, sp, #0x20
    3fd0:      	mov	w1, #0x3c               // =60
    3fd4:      	mov	x2, x29
    3fd8:      	mov	w4, w25
    3fdc:      	movk	w8, #0xa, lsl #16
    3fe0:      	str	w8, [sp, #0x58]
    3fe4:      	adrp	x8, 0x3000 <perf_unwind_dotnet+0x3000>
    3fe8:      	add	x8, x8, #0x0
    3fec:      	ldp	x9, x10, [x8, #0x20]
    3ff0:      	stp	x9, x10, [sp, #0x40]
    3ff4:      	ldr	x9, [x8, #0x30]
    3ff8:      	str	x9, [sp, #0x50]
    3ffc:      	ldp	x9, x10, [x8]
    4000:      	stp	x9, x10, [sp, #0x20]
    4004:      	add	x10, sp, #0x20
    4008:      	ldp	x8, x9, [x8, #0x10]
    400c:      	stp	x8, x9, [sp, #0x30]
    4010:      	mov	w8, #0x3c               // =60
    4014:      	mov	w9, #0x6                // =6
    4018:      	blr	x9
    401c:      	cbnz	w25, 0x2a34 <perf_unwind_dotnet+0x2a34>
    4020:      	b	0x3f14 <perf_unwind_dotnet+0x3f14>
    4024:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4028:      	add	x8, x8, #0x0
    402c:      	add	x0, sp, #0x20
    4030:      	ldp	x9, x10, [x8, #0x10]
    4034:      	mov	w1, #0x2e               // =46
    4038:      	stp	x9, x10, [sp, #0x30]
    403c:      	ldr	x9, [x8, #0x20]
    4040:      	add	x10, sp, #0x20
    4044:      	str	x9, [sp, #0x40]
    4048:      	ldur	x9, [x8, #0x26]
    404c:      	stur	x9, [sp, #0x46]
    4050:      	ldp	x9, x8, [x8]
    4054:      	stp	x9, x8, [sp, #0x20]
    4058:      	mov	w8, #0x2e               // =46
    405c:      	mov	w9, #0x6                // =6
    4060:      	ldr	w2, [sp, #0x8c]
    4064:      	blr	x9
    4068:      	mov	w2, #0x1773             // =6003
    406c:      	mov	w22, #0x1               // =1
    4070:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4074:      	ldr	x8, [x8]
    4078:      	ldr	w8, [x8]
    407c:      	cbz	w8, 0x2a74 <perf_unwind_dotnet+0x2a74>
    4080:      	b	0x3f88 <perf_unwind_dotnet+0x3f88>
    4084:      	ldr	x8, [x21, #0x1078]
    4088:      	cbz	x8, 0x4238 <perf_unwind_dotnet+0x4238>
    408c:      	mov	w9, #-0x42              // =-66
    4090:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    4094:      	mov	w8, #0xa                // =10
    4098:      	add	x0, sp, #0x20
    409c:      	mov	w1, #0x32               // =50
    40a0:      	strh	w8, [sp, #0x50]
    40a4:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    40a8:      	add	x8, x8, #0x0
    40ac:      	mov	x2, x29
    40b0:      	ldp	x9, x10, [x8, #0x10]
    40b4:      	mov	w4, w25
    40b8:      	stp	x9, x10, [sp, #0x30]
    40bc:      	ldp	x9, x10, [x8, #0x20]
    40c0:      	stp	x9, x10, [sp, #0x40]
    40c4:      	ldp	x9, x8, [x8]
    40c8:      	add	x10, sp, #0x20
    40cc:      	stp	x9, x8, [sp, #0x20]
    40d0:      	mov	w8, #0x32               // =50
    40d4:      	mov	w9, #0x6                // =6
    40d8:      	ldr	x3, [x21, #0xf00]
    40dc:      	blr	x9
    40e0:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    40e4:      	ldr	x8, [x8]
    40e8:      	ldr	w8, [x8]
    40ec:      	cbz	w8, 0x3b00 <perf_unwind_dotnet+0x3b00>
    40f0:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    40f4:      	add	x8, x8, #0x0
    40f8:      	add	x0, sp, #0x20
    40fc:      	ldp	x9, x10, [x8, #0x10]
    4100:      	mov	w1, #0x2f               // =47
    4104:      	stp	x9, x10, [sp, #0x30]
    4108:      	ldr	x9, [x8, #0x20]
    410c:      	add	x10, sp, #0x20
    4110:      	str	x9, [sp, #0x40]
    4114:      	ldur	x9, [x8, #0x27]
    4118:      	stur	x9, [sp, #0x47]
    411c:      	ldp	x9, x8, [x8]
    4120:      	stp	x9, x8, [sp, #0x20]
    4124:      	mov	w8, #0x2f               // =47
    4128:      	mov	w9, #0x6                // =6
    412c:      	ldr	x2, [x21, #0xf10]
    4130:      	ldr	x3, [x21, #0xf08]
    4134:      	blr	x9
    4138:      	b	0x3b00 <perf_unwind_dotnet+0x3b00>
    413c:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4140:      	add	x8, x8, #0x0
    4144:      	add	x0, sp, #0x20
    4148:      	ldp	x9, x10, [x8, #0x20]
    414c:      	mov	w1, #0x37               // =55
    4150:      	mov	x2, x23
    4154:      	mov	w3, w25
    4158:      	stp	x9, x10, [sp, #0x40]
    415c:      	ldur	x9, [x8, #0x2f]
    4160:      	stur	x9, [sp, #0x4f]
    4164:      	ldp	x9, x10, [x8]
    4168:      	stp	x9, x10, [sp, #0x20]
    416c:      	ldp	x8, x9, [x8, #0x10]
    4170:      	add	x10, sp, #0x20
    4174:      	stp	x8, x9, [sp, #0x30]
    4178:      	mov	w8, #0x37               // =55
    417c:      	mov	w9, #0x6                // =6
    4180:      	blr	x9
    4184:      	cbnz	w25, 0x3d64 <perf_unwind_dotnet+0x3d64>
    4188:      	ldr	x8, [x21, #0x1160]
    418c:      	cbz	x8, 0x4198 <perf_unwind_dotnet+0x4198>
    4190:      	mov	w9, #-0x7c              // =-124
    4194:      	b	0x687c <perf_unwind_dotnet+0x687c>
    4198:      	ldr	x8, [x21, #0x1158]
    419c:      	cbz	x8, 0x41a8 <perf_unwind_dotnet+0x41a8>
    41a0:      	mov	w9, #-0x7a              // =-122
    41a4:      	b	0x687c <perf_unwind_dotnet+0x687c>
    41a8:      	ldr	x8, [x21, #0x1150]
    41ac:      	cbz	x8, 0x41b8 <perf_unwind_dotnet+0x41b8>
    41b0:      	mov	w9, #-0x78              // =-120
    41b4:      	b	0x687c <perf_unwind_dotnet+0x687c>
    41b8:      	ldr	x8, [x21, #0x1148]
    41bc:      	cbz	x8, 0x41c8 <perf_unwind_dotnet+0x41c8>
    41c0:      	mov	w9, #-0x76              // =-118
    41c4:      	b	0x687c <perf_unwind_dotnet+0x687c>
    41c8:      	ldr	x8, [x21, #0x1140]
    41cc:      	cbz	x8, 0x41d8 <perf_unwind_dotnet+0x41d8>
    41d0:      	mov	w9, #-0x74              // =-116
    41d4:      	b	0x687c <perf_unwind_dotnet+0x687c>
    41d8:      	ldr	x8, [x21, #0x1138]
    41dc:      	cbz	x8, 0x41e8 <perf_unwind_dotnet+0x41e8>
    41e0:      	mov	w9, #-0x72              // =-114
    41e4:      	b	0x687c <perf_unwind_dotnet+0x687c>
    41e8:      	ldr	x8, [x21, #0x1130]
    41ec:      	cbz	x8, 0x4218 <perf_unwind_dotnet+0x4218>
    41f0:      	mov	w9, #-0x70              // =-112
    41f4:      	b	0x687c <perf_unwind_dotnet+0x687c>
    41f8:      	ldr	x8, [x21, #0x10d0]
    41fc:      	cbz	x8, 0x4248 <perf_unwind_dotnet+0x4248>
    4200:      	mov	w9, #-0x58              // =-88
    4204:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    4208:      	ldr	x8, [x21, #0x10a0]
    420c:      	cbz	x8, 0x4880 <perf_unwind_dotnet+0x4880>
    4210:      	mov	w9, #-0x4c              // =-76
    4214:      	b	0x609c <perf_unwind_dotnet+0x609c>
    4218:      	ldr	x8, [x21, #0x1128]
    421c:      	cbz	x8, 0x4890 <perf_unwind_dotnet+0x4890>
    4220:      	mov	w9, #-0x6e              // =-110
    4224:      	b	0x687c <perf_unwind_dotnet+0x687c>
    4228:      	ldr	x8, [x21, #0x10f8]
    422c:      	cbz	x8, 0x48a0 <perf_unwind_dotnet+0x48a0>
    4230:      	mov	w9, #-0x62              // =-98
    4234:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    4238:      	ldr	x8, [x21, #0x1070]
    423c:      	cbz	x8, 0x48b0 <perf_unwind_dotnet+0x48b0>
    4240:      	mov	w9, #-0x40              // =-64
    4244:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    4248:      	ldr	x8, [x21, #0x10c8]
    424c:      	cbz	x8, 0x48c0 <perf_unwind_dotnet+0x48c0>
    4250:      	mov	w9, #-0x56              // =-86
    4254:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    4258:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    425c:      	add	x8, x8, #0x0
    4260:      	add	x0, sp, #0x20
    4264:      	ldp	x9, x10, [x8]
    4268:      	mov	w1, #0x1e               // =30
    426c:      	stp	x9, x10, [sp, #0x20]
    4270:      	ldr	x9, [x8, #0x10]
    4274:      	ldur	x8, [x8, #0x16]
    4278:      	add	x10, sp, #0x20
    427c:      	str	x9, [sp, #0x30]
    4280:      	stur	x8, [sp, #0x36]
    4284:      	mov	w8, #0x1e               // =30
    4288:      	mov	w9, #0x6                // =6
    428c:      	ldrh	w2, [x23, #0x20]
    4290:      	blr	x9
    4294:      	ldrh	w8, [x23, #0x20]
    4298:      	ldr	w9, [x21, #0x1370]
    429c:      	lsr	w8, w9, w8
    42a0:      	tbnz	w8, #0x0, 0x3b88 <perf_unwind_dotnet+0x3b88>
    42a4:      	str	wzr, [sp, #0x68]
    42a8:      	adrp	x0, 0x4000 <perf_unwind_dotnet+0x4000>
    42ac:      	mov	w8, #0x1                // =1
    42b0:      	add	x9, sp, #0x68
    42b4:      	ldr	x0, [x0]
    42b8:      	add	x1, sp, #0x68
    42bc:      	blr	x8
    42c0:      	cbz	x0, 0x42d4 <perf_unwind_dotnet+0x42d4>
    42c4:      	ldr	x8, [x0]
    42c8:      	add	x8, x8, #0x1
    42cc:      	str	x8, [x0]
    42d0:      	b	0x42e4 <perf_unwind_dotnet+0x42e4>
    42d4:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    42d8:      	ldr	x8, [x8]
    42dc:      	ldr	w8, [x8]
    42e0:      	cbnz	w8, 0x48d0 <perf_unwind_dotnet+0x48d0>
    42e4:      	ldrh	w25, [x23, #0x20]
    42e8:      	cmp	w25, #0x8
    42ec:      	b.ne	0x4f64 <perf_unwind_dotnet+0x4f64>
    42f0:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    42f4:      	ldr	x25, [x21, #0xed8]
    42f8:      	ldr	x29, [x21, #0xee0]
    42fc:      	ldr	x24, [x21, #0xed0]
    4300:      	ldrb	w22, [x21, #0xf20]
    4304:      	ldr	x8, [x8]
    4308:      	ldr	w8, [x8]
    430c:      	cbnz	w8, 0x457c <perf_unwind_dotnet+0x457c>
    4310:      	cmp	x29, x25
    4314:      	b.lo	0x45cc <perf_unwind_dotnet+0x45cc>
    4318:      	add	x8, x25, #0x2, lsl #12  // =0x2000
    431c:      	cmp	x29, x8
    4320:      	b.hs	0x45cc <perf_unwind_dotnet+0x45cc>
    4324:      	ldr	x23, [x21, #0xf00]
    4328:      	ldr	x25, [x21, #0xf10]
    432c:      	mov	w8, #0x101              // =257
    4330:      	str	x24, [sp, #0x68]
    4334:      	strh	w8, [x21, #0xf20]
    4338:      	and	x8, x23, #0xffffffffffffff80
    433c:      	cmp	x8, #0x80
    4340:      	b.ne	0x4378 <perf_unwind_dotnet+0x4378>
    4344:      	ldr	x8, [x21, #0xed8]
    4348:      	mov	w9, #0x8                // =8
    434c:      	mov	w10, #0x70              // =112
    4350:      	ldr	x0, [sp, #0x10]
    4354:      	mov	w1, #0x8                // =8
    4358:      	ldr	x2, [x21, #0xed8]
    435c:      	blr	x10
    4360:      	cbnz	x0, 0x1e0 <perf_unwind_dotnet+0x1e0>
    4364:      	ldr	x8, [x21, #0xed8]
    4368:      	and	x23, x23, #0x7f
    436c:      	add	x8, x8, #0x8
    4370:      	str	x8, [x21, #0xed8]
    4374:      	b	0x4cb8 <perf_unwind_dotnet+0x4cb8>
    4378:      	mov	w8, #0x10               // =16
    437c:      	mov	w9, #0x70               // =112
    4380:      	add	x10, sp, #0x70
    4384:      	add	x0, sp, #0x70
    4388:      	mov	w1, #0x10               // =16
    438c:      	mov	x2, x29
    4390:      	blr	x9
    4394:      	cbnz	x0, 0x27c <perf_unwind_dotnet+0x27c>
    4398:      	add	x8, x29, #0x10
    439c:      	str	x8, [x21, #0xed8]
    43a0:      	ldp	x8, x9, [sp, #0x70]
    43a4:      	str	x8, [x21, #0xee0]
    43a8:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    43ac:      	str	x9, [x21, #0xed0]
    43b0:      	ldr	x8, [x8]
    43b4:      	ldr	w8, [x8]
    43b8:      	cbnz	w8, 0x4918 <perf_unwind_dotnet+0x4918>
    43bc:      	cmp	x23, #0x100
    43c0:      	b.lo	0x4cb8 <perf_unwind_dotnet+0x4cb8>
    43c4:      	ldr	x8, [x21, #0xf10]
    43c8:      	ldr	x25, [x21, #0xf00]
    43cc:      	sub	x23, x24, x8
    43d0:      	str	x8, [sp, #0x8]
    43d4:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    43d8:      	ldr	x8, [x8]
    43dc:      	ldr	w8, [x8]
    43e0:      	cbnz	w8, 0x496c <perf_unwind_dotnet+0x496c>
    43e4:      	lsr	x8, x23, #8
    43e8:      	mov	w9, #0x7f               // =127
    43ec:      	lsr	x10, x23, #15
    43f0:      	mov	w1, #0x200              // =512
    43f4:      	sub	w9, w9, w8
    43f8:      	lsl	x8, x8, #2
    43fc:      	cmp	x10, #0x0
    4400:      	sub	x8, x8, #0x3fc
    4404:      	and	x9, x9, #0x7f
    4408:      	csel	x8, x8, xzr, ne
    440c:      	add	x2, x8, x25
    4410:      	csel	x8, xzr, x9, ne
    4414:      	ldr	x9, [sp, #0x18]
    4418:      	add	x0, x9, x8, lsl #2
    441c:      	mov	w8, #0x200              // =512
    4420:      	mov	w9, #0x70               // =112
    4424:      	blr	x9
    4428:      	cbz	x0, 0x4488 <perf_unwind_dotnet+0x4488>
    442c:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4430:      	ldr	x8, [x8]
    4434:      	ldr	w8, [x8]
    4438:      	cbnz	w8, 0x6bbc <perf_unwind_dotnet+0x6bbc>
    443c:      	mov	w8, #0x5e               // =94
    4440:      	adrp	x0, 0x4000 <perf_unwind_dotnet+0x4000>
    4444:      	add	x9, sp, #0x8c
    4448:      	str	w8, [sp, #0x8c]
    444c:      	mov	w8, #0x1                // =1
    4450:      	add	x1, sp, #0x8c
    4454:      	ldr	x0, [x0]
    4458:      	blr	x8
    445c:      	cbz	x0, 0x44c8 <perf_unwind_dotnet+0x44c8>
    4460:      	ldr	x8, [x0]
    4464:      	add	x8, x8, #0x1
    4468:      	str	x8, [x0]
    446c:      	mov	w22, wzr
    4470:      	mov	w2, #0x1772             // =6002
    4474:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4478:      	ldr	x8, [x8]
    447c:      	ldr	w8, [x8]
    4480:      	cbz	w8, 0x44f0 <perf_unwind_dotnet+0x44f0>
    4484:      	b	0x6ca8 <perf_unwind_dotnet+0x6ca8>
    4488:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    448c:      	ldr	w25, [x21, #0x116c]
    4490:      	ldr	x8, [x8]
    4494:      	ldr	w8, [x8]
    4498:      	cbnz	w8, 0x49c4 <perf_unwind_dotnet+0x49c4>
    449c:      	mov	w8, #0x1c               // =28
    44a0:      	bic	w8, w8, w23, lsr #3
    44a4:      	lsr	w25, w25, w8
    44a8:      	cbz	w25, 0x4a1c <perf_unwind_dotnet+0x4a1c>
    44ac:      	and	x29, x23, #0xffffffffffffffe0
    44b0:      	ands	w3, w25, #0xf
    44b4:      	b.ne	0x4c68 <perf_unwind_dotnet+0x4c68>
    44b8:      	ubfx	w3, w25, #4, #4
    44bc:      	cbz	w3, 0x455c <perf_unwind_dotnet+0x455c>
    44c0:      	sub	x29, x29, #0x20
    44c4:      	b	0x4c68 <perf_unwind_dotnet+0x4c68>
    44c8:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    44cc:      	ldr	x8, [x8]
    44d0:      	ldr	w8, [x8]
    44d4:      	cbnz	w8, 0x4a44 <perf_unwind_dotnet+0x4a44>
    44d8:      	mov	w22, wzr
    44dc:      	mov	w2, #0x1772             // =6002
    44e0:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    44e4:      	ldr	x8, [x8]
    44e8:      	ldr	w8, [x8]
    44ec:      	cbnz	w8, 0x6ca8 <perf_unwind_dotnet+0x6ca8>
    44f0:      	cbz	w22, 0x621c <perf_unwind_dotnet+0x621c>
    44f4:      	ldr	w8, [x21, #0x2c0]
    44f8:      	adrp	x23, 0x4000 <perf_unwind_dotnet+0x4000>
    44fc:      	adrp	x24, 0x4000 <perf_unwind_dotnet+0x4000>
    4500:      	ldr	x23, [x23]
    4504:      	ldr	x24, [x24]
    4508:      	cmp	w8, #0x7e
    450c:      	b.hi	0x49c <perf_unwind_dotnet+0x49c>
    4510:      	add	w9, w8, #0x1
    4514:      	mov	w10, #0x8a              // =138
    4518:      	str	w9, [x21, #0x2c0]
    451c:      	mov	w9, #0x18               // =24
    4520:      	umaddl	x8, w8, w9, x21
    4524:      	mov	w9, #0x1773             // =6003
    4528:      	str	x9, [x8, #0x2d8]
    452c:      	add	x9, x8, #0x2d0
    4530:      	str	xzr, [x8, #0x2d0]
    4534:      	strb	w10, [x8, #0x2e0]
    4538:      	str	wzr, [x8, #0x2e4]
    453c:      	stur	wzr, [x9, #0x11]
    4540:      	ldr	x8, [sp, #0x10]
    4544:      	ldr	x29, [x8]
    4548:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    454c:      	ldr	x8, [x8]
    4550:      	ldr	w8, [x8]
    4554:      	cbnz	x29, 0x4dd4 <perf_unwind_dotnet+0x4dd4>
    4558:      	b	0x4d58 <perf_unwind_dotnet+0x4d58>
    455c:      	ubfx	w3, w25, #8, #4
    4560:      	cbz	w3, 0x456c <perf_unwind_dotnet+0x456c>
    4564:      	sub	x29, x29, #0x40
    4568:      	b	0x4c68 <perf_unwind_dotnet+0x4c68>
    456c:      	ubfx	w3, w25, #12, #4
    4570:      	cbz	w3, 0x4aa4 <perf_unwind_dotnet+0x4aa4>
    4574:      	sub	x29, x29, #0x60
    4578:      	b	0x4c68 <perf_unwind_dotnet+0x4c68>
    457c:      	mov	w8, #0x786c             // =30828
    4580:      	add	x0, sp, #0x20
    4584:      	mov	w1, #0x23               // =35
    4588:      	mov	x2, x24
    458c:      	mov	x3, x25
    4590:      	mov	x4, x29
    4594:      	movk	w8, #0xa, lsl #16
    4598:      	stur	w8, [sp, #0x3f]
    459c:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    45a0:      	add	x8, x8, #0x0
    45a4:      	ldp	x9, x10, [x8]
    45a8:      	stp	x9, x10, [sp, #0x20]
    45ac:      	ldp	x9, x8, [x8, #0x10]
    45b0:      	add	x10, sp, #0x20
    45b4:      	stp	x9, x8, [sp, #0x30]
    45b8:      	mov	w8, #0x23               // =35
    45bc:      	mov	w9, #0x6                // =6
    45c0:      	blr	x9
    45c4:      	cmp	x29, x25
    45c8:      	b.hs	0x4318 <perf_unwind_dotnet+0x4318>
    45cc:      	adrp	x23, 0x4000 <perf_unwind_dotnet+0x4000>
    45d0:      	ldr	x23, [x23]
    45d4:      	adrp	x24, 0x4000 <perf_unwind_dotnet+0x4000>
    45d8:      	ldr	w8, [x23]
    45dc:      	ldr	x24, [x24]
    45e0:      	cbnz	w8, 0x4758 <perf_unwind_dotnet+0x4758>
    45e4:      	mov	w8, #0x5d               // =93
    45e8:      	add	x9, sp, #0x68
    45ec:      	add	x1, sp, #0x68
    45f0:      	str	w8, [sp, #0x68]
    45f4:      	mov	w8, #0x1                // =1
    45f8:      	mov	x0, x24
    45fc:      	blr	x8
    4600:      	cbz	x0, 0x4614 <perf_unwind_dotnet+0x4614>
    4604:      	ldr	x8, [x0]
    4608:      	add	x8, x8, #0x1
    460c:      	str	x8, [x0]
    4610:      	b	0x461c <perf_unwind_dotnet+0x461c>
    4614:      	ldr	w8, [x23]
    4618:      	cbnz	w8, 0x47a4 <perf_unwind_dotnet+0x47a4>
    461c:      	mov	w25, wzr
    4620:      	mov	w8, #0x1771             // =6001
    4624:      	str	w8, [x21, #0xf1c]
    4628:      	str	wzr, [sp, #0x20]
    462c:      	mov	w8, #0x1                // =1
    4630:      	add	x9, sp, #0x20
    4634:      	add	x1, sp, #0x20
    4638:      	mov	x0, x20
    463c:      	blr	x8
    4640:      	cbz	x0, 0x4694 <perf_unwind_dotnet+0x4694>
    4644:      	mov	w20, #0x1374            // =4980
    4648:      	mov	w2, w25
    464c:      	ldrb	w8, [x0, x20]
    4650:      	cmp	w8, #0x1d
    4654:      	b.lo	0x46c0 <perf_unwind_dotnet+0x46c0>
    4658:      	mov	w8, #0x5                // =5
    465c:      	add	x9, sp, #0x70
    4660:      	mov	x21, x0
    4664:      	str	w8, [x0, #0xf1c]
    4668:      	mov	w8, #0x44               // =68
    466c:      	add	x1, sp, #0x70
    4670:      	mov	x0, x24
    4674:      	str	w8, [sp, #0x70]
    4678:      	mov	w8, #0x1                // =1
    467c:      	blr	x8
    4680:      	cbz	x0, 0x46ac <perf_unwind_dotnet+0x46ac>
    4684:      	ldr	x8, [x0]
    4688:      	add	x8, x8, #0x1
    468c:      	str	x8, [x0]
    4690:      	b	0x46b4 <perf_unwind_dotnet+0x46b4>
    4694:      	adrp	x10, 0x4000 <perf_unwind_dotnet+0x4000>
    4698:      	mov	x9, xzr
    469c:      	mov	w8, #0xc                // =12
    46a0:      	ldr	x10, [x10]
    46a4:      	mov	w2, wzr
    46a8:      	b	0x46d8 <perf_unwind_dotnet+0x46d8>
    46ac:      	ldr	w8, [x23]
    46b0:      	cbnz	w8, 0x47ec <perf_unwind_dotnet+0x47ec>
    46b4:      	ldrb	w8, [x21, x20]
    46b8:      	mov	w2, wzr
    46bc:      	mov	x0, x21
    46c0:      	add	w8, w8, #0x1
    46c4:      	adrp	x10, 0x4000 <perf_unwind_dotnet+0x4000>
    46c8:      	mov	w9, w2
    46cc:      	strb	w8, [x0, x20]
    46d0:      	mov	w8, #0xc                // =12
    46d4:      	ldr	x10, [x10]
    46d8:      	adrp	x1, 0x4000 <perf_unwind_dotnet+0x4000>
    46dc:      	mov	x0, x19
    46e0:      	ldr	x1, [x1]
    46e4:      	blr	x8
    46e8:      	ldr	w8, [x23]
    46ec:      	cbnz	w8, 0x4710 <perf_unwind_dotnet+0x4710>
    46f0:      	ldp	x20, x19, [sp, #0xc0]
    46f4:      	mov	w0, #-0x1               // =-1
    46f8:      	ldr	x29, [sp, #0x80]
    46fc:      	ldp	x22, x21, [sp, #0xb0]
    4700:      	ldp	x24, x23, [sp, #0xa0]
    4704:      	ldp	x30, x25, [sp, #0x90]
    4708:      	add	sp, sp, #0xd0
    470c:      	ret
    4710:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4714:      	add	x8, x8, #0x0
    4718:      	add	x0, sp, #0x20
    471c:      	ldp	x9, x10, [x8, #0x20]
    4720:      	mov	w1, #0x37               // =55
    4724:      	mov	w2, w25
    4728:      	stp	x9, x10, [sp, #0x40]
    472c:      	ldur	x9, [x8, #0x2f]
    4730:      	stur	x9, [sp, #0x4f]
    4734:      	ldp	x9, x10, [x8]
    4738:      	stp	x9, x10, [sp, #0x20]
    473c:      	ldp	x8, x9, [x8, #0x10]
    4740:      	add	x10, sp, #0x20
    4744:      	stp	x8, x9, [sp, #0x30]
    4748:      	mov	w8, #0x37               // =55
    474c:      	mov	w9, #0x6                // =6
    4750:      	blr	x9
    4754:      	b	0x46f0 <perf_unwind_dotnet+0x46f0>
    4758:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    475c:      	add	x8, x8, #0x0
    4760:      	add	x0, sp, #0x20
    4764:      	ldp	x9, x10, [x8, #0x10]
    4768:      	mov	w1, #0x2d               // =45
    476c:      	mov	x2, x29
    4770:      	mov	x3, x25
    4774:      	stp	x9, x10, [sp, #0x30]
    4778:      	ldr	x9, [x8, #0x20]
    477c:      	add	x10, sp, #0x20
    4780:      	str	x9, [sp, #0x40]
    4784:      	ldur	x9, [x8, #0x25]
    4788:      	stur	x9, [sp, #0x45]
    478c:      	ldp	x9, x8, [x8]
    4790:      	stp	x9, x8, [sp, #0x20]
    4794:      	mov	w8, #0x2d               // =45
    4798:      	mov	w9, #0x6                // =6
    479c:      	blr	x9
    47a0:      	b	0x45e4 <perf_unwind_dotnet+0x45e4>
    47a4:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    47a8:      	add	x8, x8, #0x0
    47ac:      	add	x0, sp, #0x20
    47b0:      	ldp	x9, x10, [x8, #0x10]
    47b4:      	mov	w1, #0x2e               // =46
    47b8:      	stp	x9, x10, [sp, #0x30]
    47bc:      	ldr	x9, [x8, #0x20]
    47c0:      	add	x10, sp, #0x20
    47c4:      	str	x9, [sp, #0x40]
    47c8:      	ldur	x9, [x8, #0x26]
    47cc:      	stur	x9, [sp, #0x46]
    47d0:      	ldp	x9, x8, [x8]
    47d4:      	stp	x9, x8, [sp, #0x20]
    47d8:      	mov	w8, #0x2e               // =46
    47dc:      	mov	w9, #0x6                // =6
    47e0:      	ldr	w2, [sp, #0x68]
    47e4:      	blr	x9
    47e8:      	b	0x461c <perf_unwind_dotnet+0x461c>
    47ec:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    47f0:      	add	x8, x8, #0x0
    47f4:      	add	x0, sp, #0x20
    47f8:      	ldp	x9, x10, [x8, #0x10]
    47fc:      	mov	w1, #0x2e               // =46
    4800:      	stp	x9, x10, [sp, #0x30]
    4804:      	ldr	x9, [x8, #0x20]
    4808:      	add	x10, sp, #0x20
    480c:      	str	x9, [sp, #0x40]
    4810:      	ldur	x9, [x8, #0x26]
    4814:      	stur	x9, [sp, #0x46]
    4818:      	ldp	x9, x8, [x8]
    481c:      	stp	x9, x8, [sp, #0x20]
    4820:      	mov	w8, #0x2e               // =46
    4824:      	mov	w9, #0x6                // =6
    4828:      	ldr	w2, [sp, #0x70]
    482c:      	blr	x9
    4830:      	b	0x46b4 <perf_unwind_dotnet+0x46b4>
    4834:      	mov	w8, #0x656e             // =25966
    4838:      	add	x0, sp, #0x20
    483c:      	mov	w1, #0x1b               // =27
    4840:      	movk	w8, #0xa, lsl #16
    4844:      	stur	w8, [sp, #0x37]
    4848:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    484c:      	add	x8, x8, #0x0
    4850:      	ldp	x9, x10, [x8]
    4854:      	ldr	x8, [x8, #0x10]
    4858:      	stp	x9, x10, [sp, #0x20]
    485c:      	str	x8, [sp, #0x30]
    4860:      	mov	w8, #0x1b               // =27
    4864:      	mov	w9, #0x6                // =6
    4868:      	add	x10, sp, #0x20
    486c:      	blr	x9
    4870:      	mov	w25, #0x1               // =1
    4874:      	cmp	w25, #0x8
    4878:      	b.eq	0x42f0 <perf_unwind_dotnet+0x42f0>
    487c:      	b	0x4f64 <perf_unwind_dotnet+0x4f64>
    4880:      	ldr	x8, [x21, #0x1098]
    4884:      	cbz	x8, 0x4ab4 <perf_unwind_dotnet+0x4ab4>
    4888:      	mov	w9, #-0x4a              // =-74
    488c:      	b	0x609c <perf_unwind_dotnet+0x609c>
    4890:      	ldr	x8, [x21, #0x1120]
    4894:      	cbz	x8, 0x4ac4 <perf_unwind_dotnet+0x4ac4>
    4898:      	mov	w9, #-0x6c              // =-108
    489c:      	b	0x687c <perf_unwind_dotnet+0x687c>
    48a0:      	ldr	x8, [x21, #0x10f0]
    48a4:      	cbz	x8, 0x4ad4 <perf_unwind_dotnet+0x4ad4>
    48a8:      	mov	w9, #-0x60              // =-96
    48ac:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    48b0:      	ldr	x8, [x21, #0x1068]
    48b4:      	cbz	x8, 0x4ae4 <perf_unwind_dotnet+0x4ae4>
    48b8:      	mov	w9, #-0x3e              // =-62
    48bc:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    48c0:      	ldr	x8, [x21, #0x10c0]
    48c4:      	cbz	x8, 0x4af4 <perf_unwind_dotnet+0x4af4>
    48c8:      	mov	w9, #-0x54              // =-84
    48cc:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    48d0:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    48d4:      	add	x8, x8, #0x0
    48d8:      	add	x0, sp, #0x20
    48dc:      	ldp	x9, x10, [x8, #0x10]
    48e0:      	mov	w1, #0x2e               // =46
    48e4:      	stp	x9, x10, [sp, #0x30]
    48e8:      	ldr	x9, [x8, #0x20]
    48ec:      	add	x10, sp, #0x20
    48f0:      	str	x9, [sp, #0x40]
    48f4:      	ldur	x9, [x8, #0x26]
    48f8:      	stur	x9, [sp, #0x46]
    48fc:      	ldp	x9, x8, [x8]
    4900:      	stp	x9, x8, [sp, #0x20]
    4904:      	mov	w8, #0x2e               // =46
    4908:      	mov	w9, #0x6                // =6
    490c:      	ldr	w2, [sp, #0x68]
    4910:      	blr	x9
    4914:      	b	0x42e4 <perf_unwind_dotnet+0x42e4>
    4918:      	mov	w8, #0x786c             // =30828
    491c:      	add	x0, sp, #0x20
    4920:      	mov	w1, #0x23               // =35
    4924:      	movk	w8, #0xa, lsl #16
    4928:      	stur	w8, [sp, #0x3f]
    492c:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4930:      	add	x8, x8, #0x0
    4934:      	ldp	x9, x10, [x8]
    4938:      	stp	x9, x10, [sp, #0x20]
    493c:      	ldp	x9, x8, [x8, #0x10]
    4940:      	add	x10, sp, #0x20
    4944:      	stp	x9, x8, [sp, #0x30]
    4948:      	mov	w8, #0x23               // =35
    494c:      	mov	w9, #0x6                // =6
    4950:      	ldr	x2, [x21, #0xed0]
    4954:      	ldr	x3, [x21, #0xed8]
    4958:      	ldr	x4, [x21, #0xee0]
    495c:      	blr	x9
    4960:      	cmp	x23, #0x100
    4964:      	b.hs	0x43c4 <perf_unwind_dotnet+0x43c4>
    4968:      	b	0x4cb8 <perf_unwind_dotnet+0x4cb8>
    496c:      	mov	w8, #0xa                // =10
    4970:      	mov	w11, #0x6               // =6
    4974:      	add	x0, sp, #0x20
    4978:      	strh	w8, [sp, #0x60]
    497c:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4980:      	add	x8, x8, #0x0
    4984:      	mov	w1, #0x42               // =66
    4988:      	ldp	x9, x10, [x8, #0x20]
    498c:      	mov	x2, x23
    4990:      	mov	x4, x25
    4994:      	stp	x9, x10, [sp, #0x40]
    4998:      	ldp	x9, x10, [x8, #0x30]
    499c:      	stp	x9, x10, [sp, #0x50]
    49a0:      	ldp	x9, x10, [x8]
    49a4:      	stp	x9, x10, [sp, #0x20]
    49a8:      	ldp	x9, x8, [x8, #0x10]
    49ac:      	mov	w10, #0x42              // =66
    49b0:      	stp	x9, x8, [sp, #0x30]
    49b4:      	add	x8, sp, #0x20
    49b8:      	ldr	x3, [sp, #0x8]
    49bc:      	blr	x11
    49c0:      	b	0x43e4 <perf_unwind_dotnet+0x43e4>
    49c4:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    49c8:      	add	x8, x8, #0x0
    49cc:      	add	x0, sp, #0x20
    49d0:      	ldp	x9, x10, [x8, #0x20]
    49d4:      	and	x2, x23, #0xfffffffffffffffc
    49d8:      	mov	w1, #0x36               // =54
    49dc:      	mov	w3, w25
    49e0:      	stp	x9, x10, [sp, #0x40]
    49e4:      	ldur	x9, [x8, #0x2e]
    49e8:      	stur	x9, [sp, #0x4e]
    49ec:      	ldp	x9, x10, [x8]
    49f0:      	stp	x9, x10, [sp, #0x20]
    49f4:      	ldp	x8, x9, [x8, #0x10]
    49f8:      	add	x10, sp, #0x20
    49fc:      	stp	x8, x9, [sp, #0x30]
    4a00:      	mov	w8, #0x36               // =54
    4a04:      	mov	w9, #0x6                // =6
    4a08:      	blr	x9
    4a0c:      	mov	w8, #0x1c               // =28
    4a10:      	bic	w8, w8, w23, lsr #3
    4a14:      	lsr	w25, w25, w8
    4a18:      	cbnz	w25, 0x44ac <perf_unwind_dotnet+0x44ac>
    4a1c:      	and	x8, x23, #0xffffffffffffff00
    4a20:      	ldr	w25, [x21, #0x1168]
    4a24:      	sub	x23, x8, #0x20
    4a28:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4a2c:      	ldr	x8, [x8]
    4a30:      	ldr	w8, [x8]
    4a34:      	cbnz	w8, 0x4b04 <perf_unwind_dotnet+0x4b04>
    4a38:      	cbz	w25, 0x4b50 <perf_unwind_dotnet+0x4b50>
    4a3c:      	mov	w3, wzr
    4a40:      	b	0x6b50 <perf_unwind_dotnet+0x6b50>
    4a44:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4a48:      	add	x8, x8, #0x0
    4a4c:      	add	x0, sp, #0x20
    4a50:      	ldp	x9, x10, [x8, #0x10]
    4a54:      	mov	w1, #0x2e               // =46
    4a58:      	stp	x9, x10, [sp, #0x30]
    4a5c:      	ldr	x9, [x8, #0x20]
    4a60:      	add	x10, sp, #0x20
    4a64:      	str	x9, [sp, #0x40]
    4a68:      	ldur	x9, [x8, #0x26]
    4a6c:      	stur	x9, [sp, #0x46]
    4a70:      	ldp	x9, x8, [x8]
    4a74:      	stp	x9, x8, [sp, #0x20]
    4a78:      	mov	w8, #0x2e               // =46
    4a7c:      	mov	w9, #0x6                // =6
    4a80:      	ldr	w2, [sp, #0x8c]
    4a84:      	blr	x9
    4a88:      	mov	w22, wzr
    4a8c:      	mov	w2, #0x1772             // =6002
    4a90:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4a94:      	ldr	x8, [x8]
    4a98:      	ldr	w8, [x8]
    4a9c:      	cbz	w8, 0x44f0 <perf_unwind_dotnet+0x44f0>
    4aa0:      	b	0x6ca8 <perf_unwind_dotnet+0x6ca8>
    4aa4:      	ubfx	w3, w25, #16, #4
    4aa8:      	cbz	w3, 0x4b80 <perf_unwind_dotnet+0x4b80>
    4aac:      	sub	x29, x29, #0x80
    4ab0:      	b	0x4c68 <perf_unwind_dotnet+0x4c68>
    4ab4:      	ldr	x8, [x21, #0x1090]
    4ab8:      	cbz	x8, 0x4b90 <perf_unwind_dotnet+0x4b90>
    4abc:      	mov	w9, #-0x48              // =-72
    4ac0:      	b	0x609c <perf_unwind_dotnet+0x609c>
    4ac4:      	ldr	x8, [x21, #0x1118]
    4ac8:      	cbz	x8, 0x4ba0 <perf_unwind_dotnet+0x4ba0>
    4acc:      	mov	w9, #-0x6a              // =-106
    4ad0:      	b	0x687c <perf_unwind_dotnet+0x687c>
    4ad4:      	ldr	x8, [x21, #0x10e8]
    4ad8:      	cbz	x8, 0x4bb0 <perf_unwind_dotnet+0x4bb0>
    4adc:      	mov	w9, #-0x5e              // =-94
    4ae0:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    4ae4:      	ldr	x8, [x21, #0x1060]
    4ae8:      	cbz	x8, 0x4bc0 <perf_unwind_dotnet+0x4bc0>
    4aec:      	mov	w9, #-0x3c              // =-60
    4af0:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    4af4:      	ldr	x8, [x21, #0x10b8]
    4af8:      	cbz	x8, 0x4bd0 <perf_unwind_dotnet+0x4bd0>
    4afc:      	mov	w9, #-0x52              // =-82
    4b00:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    4b04:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4b08:      	add	x8, x8, #0x0
    4b0c:      	add	x0, sp, #0x20
    4b10:      	ldp	x9, x10, [x8, #0x20]
    4b14:      	mov	w1, #0x37               // =55
    4b18:      	mov	x2, x23
    4b1c:      	mov	w3, w25
    4b20:      	stp	x9, x10, [sp, #0x40]
    4b24:      	ldur	x9, [x8, #0x2f]
    4b28:      	stur	x9, [sp, #0x4f]
    4b2c:      	ldp	x9, x10, [x8]
    4b30:      	stp	x9, x10, [sp, #0x20]
    4b34:      	ldp	x8, x9, [x8, #0x10]
    4b38:      	add	x10, sp, #0x20
    4b3c:      	stp	x8, x9, [sp, #0x30]
    4b40:      	mov	w8, #0x37               // =55
    4b44:      	mov	w9, #0x6                // =6
    4b48:      	blr	x9
    4b4c:      	cbnz	w25, 0x4a3c <perf_unwind_dotnet+0x4a3c>
    4b50:      	ldr	x8, [x21, #0x1160]
    4b54:      	cbz	x8, 0x4b60 <perf_unwind_dotnet+0x4b60>
    4b58:      	mov	w9, #-0x7c              // =-124
    4b5c:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    4b60:      	ldr	x8, [x21, #0x1158]
    4b64:      	cbz	x8, 0x4b70 <perf_unwind_dotnet+0x4b70>
    4b68:      	mov	w9, #-0x7a              // =-122
    4b6c:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    4b70:      	ldr	x8, [x21, #0x1150]
    4b74:      	cbz	x8, 0x4be0 <perf_unwind_dotnet+0x4be0>
    4b78:      	mov	w9, #-0x78              // =-120
    4b7c:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    4b80:      	ubfx	w3, w25, #20, #4
    4b84:      	cbz	w3, 0x4bf0 <perf_unwind_dotnet+0x4bf0>
    4b88:      	sub	x29, x29, #0xa0
    4b8c:      	b	0x4c68 <perf_unwind_dotnet+0x4c68>
    4b90:      	ldr	x8, [x21, #0x1088]
    4b94:      	cbz	x8, 0x4c00 <perf_unwind_dotnet+0x4c00>
    4b98:      	mov	w9, #-0x46              // =-70
    4b9c:      	b	0x609c <perf_unwind_dotnet+0x609c>
    4ba0:      	ldr	x8, [x21, #0x1110]
    4ba4:      	cbz	x8, 0x4c10 <perf_unwind_dotnet+0x4c10>
    4ba8:      	mov	w9, #-0x68              // =-104
    4bac:      	b	0x687c <perf_unwind_dotnet+0x687c>
    4bb0:      	ldr	x8, [x21, #0x10e0]
    4bb4:      	cbz	x8, 0x4c20 <perf_unwind_dotnet+0x4c20>
    4bb8:      	mov	w9, #-0x5c              // =-92
    4bbc:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    4bc0:      	ldr	x8, [x21, #0x1058]
    4bc4:      	cbz	x8, 0x4c30 <perf_unwind_dotnet+0x4c30>
    4bc8:      	mov	w9, #-0x3a              // =-58
    4bcc:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    4bd0:      	ldr	x8, [x21, #0x10b0]
    4bd4:      	cbz	x8, 0x4c40 <perf_unwind_dotnet+0x4c40>
    4bd8:      	mov	w9, #-0x50              // =-80
    4bdc:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    4be0:      	ldr	x8, [x21, #0x1148]
    4be4:      	cbz	x8, 0x4c50 <perf_unwind_dotnet+0x4c50>
    4be8:      	mov	w9, #-0x76              // =-118
    4bec:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    4bf0:      	ubfx	w3, w25, #24, #4
    4bf4:      	cbz	w3, 0x4c60 <perf_unwind_dotnet+0x4c60>
    4bf8:      	sub	x29, x29, #0xc0
    4bfc:      	b	0x4c68 <perf_unwind_dotnet+0x4c68>
    4c00:      	ldr	x8, [x21, #0x1080]
    4c04:      	cbz	x8, 0x4f7c <perf_unwind_dotnet+0x4f7c>
    4c08:      	mov	w9, #-0x44              // =-68
    4c0c:      	b	0x609c <perf_unwind_dotnet+0x609c>
    4c10:      	ldr	x8, [x21, #0x1108]
    4c14:      	cbz	x8, 0x4f8c <perf_unwind_dotnet+0x4f8c>
    4c18:      	mov	w9, #-0x66              // =-102
    4c1c:      	b	0x687c <perf_unwind_dotnet+0x687c>
    4c20:      	ldr	x8, [x21, #0x10d8]
    4c24:      	cbz	x8, 0x4f9c <perf_unwind_dotnet+0x4f9c>
    4c28:      	mov	w9, #-0x5a              // =-90
    4c2c:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    4c30:      	ldr	x8, [x21, #0x1050]
    4c34:      	cbz	x8, 0x4fac <perf_unwind_dotnet+0x4fac>
    4c38:      	mov	w9, #-0x38              // =-56
    4c3c:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    4c40:      	ldr	x8, [x21, #0x10a8]
    4c44:      	cbz	x8, 0x4fbc <perf_unwind_dotnet+0x4fbc>
    4c48:      	mov	w9, #-0x4e              // =-78
    4c4c:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    4c50:      	ldr	x8, [x21, #0x1140]
    4c54:      	cbz	x8, 0x4fcc <perf_unwind_dotnet+0x4fcc>
    4c58:      	mov	w9, #-0x74              // =-116
    4c5c:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    4c60:      	lsr	w3, w25, #28
    4c64:      	sub	x29, x29, #0xe0
    4c68:      	ldr	x8, [sp, #0x8]
    4c6c:      	lsl	w9, w3, #2
    4c70:      	sub	w9, w9, #0x4
    4c74:      	add	x8, x29, x8
    4c78:      	add	x25, x8, x9
    4c7c:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4c80:      	ldr	x8, [x8]
    4c84:      	ldr	w8, [x8]
    4c88:      	cbnz	w8, 0x4fdc <perf_unwind_dotnet+0x4fdc>
    4c8c:      	sub	x2, x25, #0x8
    4c90:      	mov	w8, #0x8                // =8
    4c94:      	mov	w9, #0x70               // =112
    4c98:      	add	x10, sp, #0x68
    4c9c:      	add	x0, sp, #0x68
    4ca0:      	mov	w1, #0x8                // =8
    4ca4:      	blr	x9
    4ca8:      	adrp	x23, 0x4000 <perf_unwind_dotnet+0x4000>
    4cac:      	ldr	x23, [x23]
    4cb0:      	cbnz	x0, 0x844 <perf_unwind_dotnet+0x844>
    4cb4:      	mov	w23, #0x1f              // =31
    4cb8:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4cbc:      	ldr	x8, [x8]
    4cc0:      	ldr	w8, [x8]
    4cc4:      	cbnz	w8, 0x5028 <perf_unwind_dotnet+0x5028>
    4cc8:      	ldr	w8, [x21, #0x2c0]
    4ccc:      	cmp	w8, #0x7e
    4cd0:      	b.hi	0x8a4 <perf_unwind_dotnet+0x8a4>
    4cd4:      	ldr	x9, [sp, #0x68]
    4cd8:      	add	w11, w8, #0x1
    4cdc:      	sub	x10, x24, x25
    4ce0:      	adrp	x0, 0x4000 <perf_unwind_dotnet+0x4000>
    4ce4:      	str	w11, [x21, #0x2c0]
    4ce8:      	mov	w11, #0x18              // =24
    4cec:      	add	x1, sp, #0x8c
    4cf0:      	umaddl	x8, w8, w11, x21
    4cf4:      	add	x9, x23, x9, lsl #5
    4cf8:      	str	x10, [x8, #0x2d8]
    4cfc:      	mov	w10, #0xa               // =10
    4d00:      	strb	w22, [x8, #0x2e1]
    4d04:      	strh	wzr, [x8, #0x2e6]
    4d08:      	strb	w10, [x8, #0x2e0]
    4d0c:      	str	x9, [x8, #0x2d0]
    4d10:      	add	x9, x8, #0x2d0
    4d14:      	mov	w8, #0x5b               // =91
    4d18:      	stur	wzr, [x9, #0x12]
    4d1c:      	str	w8, [sp, #0x8c]
    4d20:      	mov	w8, #0x1                // =1
    4d24:      	add	x9, sp, #0x8c
    4d28:      	ldr	x0, [x0]
    4d2c:      	blr	x8
    4d30:      	cbz	x0, 0x4dac <perf_unwind_dotnet+0x4dac>
    4d34:      	ldr	x8, [x0]
    4d38:      	add	x8, x8, #0x1
    4d3c:      	str	x8, [x0]
    4d40:      	ldr	x8, [sp, #0x10]
    4d44:      	ldr	x29, [x8]
    4d48:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4d4c:      	ldr	x8, [x8]
    4d50:      	ldr	w8, [x8]
    4d54:      	cbnz	x29, 0x4dd4 <perf_unwind_dotnet+0x4dd4>
    4d58:      	adrp	x23, 0x4000 <perf_unwind_dotnet+0x4000>
    4d5c:      	adrp	x24, 0x4000 <perf_unwind_dotnet+0x4000>
    4d60:      	ldr	x23, [x23]
    4d64:      	ldr	x24, [x24]
    4d68:      	cbz	w8, 0x16b4 <perf_unwind_dotnet+0x16b4>
    4d6c:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4d70:      	add	x8, x8, #0x0
    4d74:      	strb	wzr, [sp, #0x50]
    4d78:      	add	x0, sp, #0x20
    4d7c:      	ldp	x9, x10, [x8, #0x10]
    4d80:      	mov	w1, #0x31               // =49
    4d84:      	stp	x9, x10, [sp, #0x30]
    4d88:      	ldp	x9, x10, [x8, #0x20]
    4d8c:      	stp	x9, x10, [sp, #0x40]
    4d90:      	ldp	x9, x8, [x8]
    4d94:      	add	x10, sp, #0x20
    4d98:      	stp	x9, x8, [sp, #0x20]
    4d9c:      	mov	w8, #0x31               // =49
    4da0:      	mov	w9, #0x6                // =6
    4da4:      	blr	x9
    4da8:      	b	0x16b4 <perf_unwind_dotnet+0x16b4>
    4dac:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4db0:      	ldr	x8, [x8]
    4db4:      	ldr	w8, [x8]
    4db8:      	cbnz	w8, 0x5090 <perf_unwind_dotnet+0x5090>
    4dbc:      	ldr	x8, [sp, #0x10]
    4dc0:      	ldr	x29, [x8]
    4dc4:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4dc8:      	ldr	x8, [x8]
    4dcc:      	ldr	w8, [x8]
    4dd0:      	cbz	x29, 0x4d58 <perf_unwind_dotnet+0x4d58>
    4dd4:      	cbnz	w8, 0x50f0 <perf_unwind_dotnet+0x50f0>
    4dd8:      	lsr	x8, x29, #56
    4ddc:      	cbnz	x8, 0x1650 <perf_unwind_dotnet+0x1650>
    4de0:      	cmp	x29, #0x1, lsl #12      // =0x1000
    4de4:      	b.lo	0x1784 <perf_unwind_dotnet+0x1784>
    4de8:      	ldr	w8, [x21]
    4dec:      	mov	w9, #0x60               // =96
    4df0:      	adrp	x0, 0x4000 <perf_unwind_dotnet+0x4000>
    4df4:      	add	x1, sp, #0x70
    4df8:      	rev	w8, w8
    4dfc:      	stp	w9, w8, [sp, #0x70]
    4e00:      	rev	x8, x29
    4e04:      	add	x9, sp, #0x70
    4e08:      	str	x8, [sp, #0x78]
    4e0c:      	mov	w8, #0x1                // =1
    4e10:      	ldr	x0, [x0]
    4e14:      	blr	x8
    4e18:      	cbz	x0, 0x4eec <perf_unwind_dotnet+0x4eec>
    4e1c:      	ldr	x8, [x0, #0x8]
    4e20:      	and	x9, x8, #0xffffffffffffff
    4e24:      	lsr	x25, x8, #56
    4e28:      	str	x9, [x21, #0xf10]
    4e2c:      	ldr	x8, [x0]
    4e30:      	str	x8, [x21, #0xf00]
    4e34:      	sub	x8, x29, x9
    4e38:      	str	x8, [x21, #0xf08]
    4e3c:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4e40:      	ldr	x8, [x8]
    4e44:      	ldr	w8, [x8]
    4e48:      	cbnz	w8, 0x5140 <perf_unwind_dotnet+0x5140>
    4e4c:      	cmp	w25, #0x1
    4e50:      	b.ne	0x4f64 <perf_unwind_dotnet+0x4f64>
    4e54:      	ldr	x8, [x21, #0xf00]
    4e58:      	adrp	x0, 0x4000 <perf_unwind_dotnet+0x4000>
    4e5c:      	ldr	x22, [x21, #0xf08]
    4e60:      	mov	w9, #0x1                // =1
    4e64:      	add	x1, sp, #0x70
    4e68:      	mov	w25, #0x1               // =1
    4e6c:      	str	x8, [sp, #0x70]
    4e70:      	add	x8, sp, #0x70
    4e74:      	ldr	x0, [x0]
    4e78:      	blr	x9
    4e7c:      	cbz	x0, 0x4f64 <perf_unwind_dotnet+0x4f64>
    4e80:      	ldr	x8, [x0]
    4e84:      	mov	x23, x0
    4e88:      	cmp	x8, x22
    4e8c:      	b.hi	0x4e9c <perf_unwind_dotnet+0x4e9c>
    4e90:      	ldr	x8, [x23, #0x8]
    4e94:      	cmp	x8, x22
    4e98:      	b.hs	0x4eb4 <perf_unwind_dotnet+0x4eb4>
    4e9c:      	ldr	x8, [x23, #0x10]
    4ea0:      	cmp	x8, x22
    4ea4:      	b.hi	0x4ee4 <perf_unwind_dotnet+0x4ee4>
    4ea8:      	ldr	x8, [x23, #0x18]
    4eac:      	cmp	x8, x22
    4eb0:      	b.lo	0x4ee4 <perf_unwind_dotnet+0x4ee4>
    4eb4:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4eb8:      	ldr	x8, [x8]
    4ebc:      	ldr	w8, [x8]
    4ec0:      	cbnz	w8, 0x51e8 <perf_unwind_dotnet+0x51e8>
    4ec4:      	ldrh	w8, [x23, #0x20]
    4ec8:      	ldr	w9, [x21, #0x1370]
    4ecc:      	lsr	w8, w9, w8
    4ed0:      	tbz	w8, #0x0, 0x5234 <perf_unwind_dotnet+0x5234>
    4ed4:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4ed8:      	ldr	x8, [x8]
    4edc:      	ldr	w8, [x8]
    4ee0:      	cbnz	w8, 0x5264 <perf_unwind_dotnet+0x5264>
    4ee4:      	mov	w25, #0x1               // =1
    4ee8:      	b	0x4f64 <perf_unwind_dotnet+0x4f64>
    4eec:      	adrp	x23, 0x4000 <perf_unwind_dotnet+0x4000>
    4ef0:      	adrp	x24, 0x4000 <perf_unwind_dotnet+0x4000>
    4ef4:      	ldr	x23, [x23]
    4ef8:      	ldr	x24, [x24]
    4efc:      	ldr	w8, [x23]
    4f00:      	cbnz	w8, 0x4f18 <perf_unwind_dotnet+0x4f18>
    4f04:      	mov	w8, #0xc                // =12
    4f08:      	mov	w25, wzr
    4f0c:      	str	w8, [x21, #0xf18]
    4f10:      	mov	w8, #0xfac              // =4012
    4f14:      	b	0x4624 <perf_unwind_dotnet+0x4624>
    4f18:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4f1c:      	add	x8, x8, #0x0
    4f20:      	strb	wzr, [sp, #0x58]
    4f24:      	add	x0, sp, #0x20
    4f28:      	ldp	x9, x10, [x8, #0x20]
    4f2c:      	mov	w1, #0x39               // =57
    4f30:      	mov	x2, x29
    4f34:      	stp	x9, x10, [sp, #0x40]
    4f38:      	ldr	x9, [x8, #0x30]
    4f3c:      	str	x9, [sp, #0x50]
    4f40:      	ldp	x9, x10, [x8]
    4f44:      	stp	x9, x10, [sp, #0x20]
    4f48:      	ldp	x8, x9, [x8, #0x10]
    4f4c:      	add	x10, sp, #0x20
    4f50:      	stp	x8, x9, [sp, #0x30]
    4f54:      	mov	w8, #0x39               // =57
    4f58:      	mov	w9, #0x6                // =6
    4f5c:      	blr	x9
    4f60:      	b	0x4f04 <perf_unwind_dotnet+0x4f04>
    4f64:      	adrp	x23, 0x4000 <perf_unwind_dotnet+0x4000>
    4f68:      	adrp	x24, 0x4000 <perf_unwind_dotnet+0x4000>
    4f6c:      	mov	w8, wzr
    4f70:      	ldr	x23, [x23]
    4f74:      	ldr	x24, [x24]
    4f78:      	b	0x4624 <perf_unwind_dotnet+0x4624>
    4f7c:      	ldr	x8, [x21, #0x1078]
    4f80:      	cbz	x8, 0x52a8 <perf_unwind_dotnet+0x52a8>
    4f84:      	mov	w9, #-0x42              // =-66
    4f88:      	b	0x609c <perf_unwind_dotnet+0x609c>
    4f8c:      	ldr	x8, [x21, #0x1100]
    4f90:      	cbz	x8, 0x52b8 <perf_unwind_dotnet+0x52b8>
    4f94:      	mov	w9, #-0x64              // =-100
    4f98:      	b	0x687c <perf_unwind_dotnet+0x687c>
    4f9c:      	ldr	x8, [x21, #0x10d0]
    4fa0:      	cbz	x8, 0x52c8 <perf_unwind_dotnet+0x52c8>
    4fa4:      	mov	w9, #-0x58              // =-88
    4fa8:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    4fac:      	ldr	x8, [x21, #0x1048]
    4fb0:      	cbz	x8, 0x52d8 <perf_unwind_dotnet+0x52d8>
    4fb4:      	mov	w9, #-0x36              // =-54
    4fb8:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    4fbc:      	ldr	x8, [x21, #0x10a0]
    4fc0:      	cbz	x8, 0x52e8 <perf_unwind_dotnet+0x52e8>
    4fc4:      	mov	w9, #-0x4c              // =-76
    4fc8:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    4fcc:      	ldr	x8, [x21, #0x1138]
    4fd0:      	cbz	x8, 0x52f8 <perf_unwind_dotnet+0x52f8>
    4fd4:      	mov	w9, #-0x72              // =-114
    4fd8:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    4fdc:      	adrp	x8, 0x4000 <perf_unwind_dotnet+0x4000>
    4fe0:      	add	x8, x8, #0x0
    4fe4:      	add	x0, sp, #0x20
    4fe8:      	ldp	x9, x10, [x8, #0x10]
    4fec:      	mov	w1, #0x2e               // =46
    4ff0:      	mov	x2, x29
    4ff4:      	mov	x4, x25
    4ff8:      	stp	x9, x10, [sp, #0x30]
    4ffc:      	ldr	x9, [x8, #0x20]
    5000:      	add	x10, sp, #0x20
    5004:      	str	x9, [sp, #0x40]
    5008:      	ldur	x9, [x8, #0x26]
    500c:      	stur	x9, [sp, #0x46]
    5010:      	ldp	x9, x8, [x8]
    5014:      	stp	x9, x8, [sp, #0x20]
    5018:      	mov	w8, #0x2e               // =46
    501c:      	mov	w9, #0x6                // =6
    5020:      	blr	x9
    5024:      	b	0x4c8c <perf_unwind_dotnet+0x4c8c>
    5028:      	mov	w8, #0x786c             // =30828
    502c:      	sub	x4, x24, x25
    5030:      	add	x0, sp, #0x20
    5034:      	mov	w1, #0x43               // =67
    5038:      	mov	x2, x25
    503c:      	movk	w8, #0xa, lsl #16
    5040:      	stur	w8, [sp, #0x5f]
    5044:      	adrp	x8, 0x5000 <perf_unwind_dotnet+0x5000>
    5048:      	add	x8, x8, #0x0
    504c:      	ldp	x9, x10, [x8, #0x20]
    5050:      	stp	x9, x10, [sp, #0x40]
    5054:      	ldp	x9, x10, [x8, #0x30]
    5058:      	stp	x9, x10, [sp, #0x50]
    505c:      	ldp	x9, x10, [x8]
    5060:      	stp	x9, x10, [sp, #0x20]
    5064:      	ldp	x9, x8, [x8, #0x10]
    5068:      	add	x10, sp, #0x20
    506c:      	stp	x9, x8, [sp, #0x30]
    5070:      	mov	w8, #0x43               // =67
    5074:      	mov	w9, #0x6                // =6
    5078:      	ldr	x3, [sp, #0x68]
    507c:      	blr	x9
    5080:      	ldr	w8, [x21, #0x2c0]
    5084:      	cmp	w8, #0x7e
    5088:      	b.hi	0x8a4 <perf_unwind_dotnet+0x8a4>
    508c:      	b	0x4cd4 <perf_unwind_dotnet+0x4cd4>
    5090:      	adrp	x8, 0x5000 <perf_unwind_dotnet+0x5000>
    5094:      	add	x8, x8, #0x0
    5098:      	add	x0, sp, #0x20
    509c:      	ldp	x9, x10, [x8, #0x10]
    50a0:      	mov	w1, #0x2e               // =46
    50a4:      	stp	x9, x10, [sp, #0x30]
    50a8:      	ldr	x9, [x8, #0x20]
    50ac:      	add	x10, sp, #0x20
    50b0:      	str	x9, [sp, #0x40]
    50b4:      	ldur	x9, [x8, #0x26]
    50b8:      	stur	x9, [sp, #0x46]
    50bc:      	ldp	x9, x8, [x8]
    50c0:      	stp	x9, x8, [sp, #0x20]
    50c4:      	mov	w8, #0x2e               // =46
    50c8:      	mov	w9, #0x6                // =6
    50cc:      	ldr	w2, [sp, #0x8c]
    50d0:      	blr	x9
    50d4:      	ldr	x8, [sp, #0x10]
    50d8:      	ldr	x29, [x8]
    50dc:      	adrp	x8, 0x5000 <perf_unwind_dotnet+0x5000>
    50e0:      	ldr	x8, [x8]
    50e4:      	ldr	w8, [x8]
    50e8:      	cbnz	x29, 0x4dd4 <perf_unwind_dotnet+0x4dd4>
    50ec:      	b	0x4d58 <perf_unwind_dotnet+0x4d58>
    50f0:      	adrp	x8, 0x5000 <perf_unwind_dotnet+0x5000>
    50f4:      	add	x8, x8, #0x0
    50f8:      	strb	wzr, [sp, #0x50]
    50fc:      	add	x0, sp, #0x20
    5100:      	ldp	x9, x10, [x8, #0x10]
    5104:      	mov	w1, #0x31               // =49
    5108:      	stp	x9, x10, [sp, #0x30]
    510c:      	ldp	x9, x10, [x8, #0x20]
    5110:      	stp	x9, x10, [sp, #0x40]
    5114:      	ldp	x9, x8, [x8]
    5118:      	add	x10, sp, #0x20
    511c:      	stp	x9, x8, [sp, #0x20]
    5120:      	mov	w8, #0x31               // =49
    5124:      	mov	w9, #0x6                // =6
    5128:      	ldr	w2, [x21, #0x2c0]
    512c:      	blr	x9
    5130:      	ldr	x29, [x21, #0xed0]
    5134:      	lsr	x8, x29, #56
    5138:      	cbnz	x8, 0x1650 <perf_unwind_dotnet+0x1650>
    513c:      	b	0x4de0 <perf_unwind_dotnet+0x4de0>
    5140:      	mov	w8, #0xa                // =10
    5144:      	add	x0, sp, #0x20
    5148:      	mov	w1, #0x32               // =50
    514c:      	strh	w8, [sp, #0x50]
    5150:      	adrp	x8, 0x5000 <perf_unwind_dotnet+0x5000>
    5154:      	add	x8, x8, #0x0
    5158:      	mov	x2, x29
    515c:      	ldp	x9, x10, [x8, #0x10]
    5160:      	mov	w4, w25
    5164:      	stp	x9, x10, [sp, #0x30]
    5168:      	ldp	x9, x10, [x8, #0x20]
    516c:      	stp	x9, x10, [sp, #0x40]
    5170:      	ldp	x9, x8, [x8]
    5174:      	add	x10, sp, #0x20
    5178:      	stp	x9, x8, [sp, #0x20]
    517c:      	mov	w8, #0x32               // =50
    5180:      	mov	w9, #0x6                // =6
    5184:      	ldr	x3, [x21, #0xf00]
    5188:      	blr	x9
    518c:      	adrp	x8, 0x5000 <perf_unwind_dotnet+0x5000>
    5190:      	ldr	x8, [x8]
    5194:      	ldr	w8, [x8]
    5198:      	cbz	w8, 0x4e4c <perf_unwind_dotnet+0x4e4c>
    519c:      	adrp	x8, 0x5000 <perf_unwind_dotnet+0x5000>
    51a0:      	add	x8, x8, #0x0
    51a4:      	add	x0, sp, #0x20
    51a8:      	ldp	x9, x10, [x8, #0x10]
    51ac:      	mov	w1, #0x2f               // =47
    51b0:      	stp	x9, x10, [sp, #0x30]
    51b4:      	ldr	x9, [x8, #0x20]
    51b8:      	add	x10, sp, #0x20
    51bc:      	str	x9, [sp, #0x40]
    51c0:      	ldur	x9, [x8, #0x27]
    51c4:      	stur	x9, [sp, #0x47]
    51c8:      	ldp	x9, x8, [x8]
    51cc:      	stp	x9, x8, [sp, #0x20]
    51d0:      	mov	w8, #0x2f               // =47
    51d4:      	mov	w9, #0x6                // =6
    51d8:      	ldr	x2, [x21, #0xf10]
    51dc:      	ldr	x3, [x21, #0xf08]
    51e0:      	blr	x9
    51e4:      	b	0x4e4c <perf_unwind_dotnet+0x4e4c>
    51e8:      	adrp	x8, 0x5000 <perf_unwind_dotnet+0x5000>
    51ec:      	add	x8, x8, #0x0
    51f0:      	add	x0, sp, #0x20
    51f4:      	ldp	x9, x10, [x8]
    51f8:      	mov	w1, #0x1e               // =30
    51fc:      	stp	x9, x10, [sp, #0x20]
    5200:      	ldr	x9, [x8, #0x10]
    5204:      	ldur	x8, [x8, #0x16]
    5208:      	add	x10, sp, #0x20
    520c:      	str	x9, [sp, #0x30]
    5210:      	stur	x8, [sp, #0x36]
    5214:      	mov	w8, #0x1e               // =30
    5218:      	mov	w9, #0x6                // =6
    521c:      	ldrh	w2, [x23, #0x20]
    5220:      	blr	x9
    5224:      	ldrh	w8, [x23, #0x20]
    5228:      	ldr	w9, [x21, #0x1370]
    522c:      	lsr	w8, w9, w8
    5230:      	tbnz	w8, #0x0, 0x4ed4 <perf_unwind_dotnet+0x4ed4>
    5234:      	str	wzr, [sp, #0x68]
    5238:      	adrp	x0, 0x5000 <perf_unwind_dotnet+0x5000>
    523c:      	mov	w8, #0x1                // =1
    5240:      	add	x9, sp, #0x68
    5244:      	ldr	x0, [x0]
    5248:      	add	x1, sp, #0x68
    524c:      	blr	x8
    5250:      	cbz	x0, 0x5308 <perf_unwind_dotnet+0x5308>
    5254:      	ldr	x8, [x0]
    5258:      	add	x8, x8, #0x1
    525c:      	str	x8, [x0]
    5260:      	b	0x535c <perf_unwind_dotnet+0x535c>
    5264:      	mov	w8, #0x656e             // =25966
    5268:      	add	x0, sp, #0x20
    526c:      	mov	w1, #0x1b               // =27
    5270:      	movk	w8, #0xa, lsl #16
    5274:      	stur	w8, [sp, #0x37]
    5278:      	adrp	x8, 0x5000 <perf_unwind_dotnet+0x5000>
    527c:      	add	x8, x8, #0x0
    5280:      	ldp	x9, x10, [x8]
    5284:      	ldr	x8, [x8, #0x10]
    5288:      	stp	x9, x10, [sp, #0x20]
    528c:      	str	x8, [sp, #0x30]
    5290:      	mov	w8, #0x1b               // =27
    5294:      	mov	w9, #0x6                // =6
    5298:      	add	x10, sp, #0x20
    529c:      	blr	x9
    52a0:      	mov	w25, #0x1               // =1
    52a4:      	b	0x4f64 <perf_unwind_dotnet+0x4f64>
    52a8:      	ldr	x8, [x21, #0x1070]
    52ac:      	cbz	x8, 0x5364 <perf_unwind_dotnet+0x5364>
    52b0:      	mov	w9, #-0x40              // =-64
    52b4:      	b	0x609c <perf_unwind_dotnet+0x609c>
    52b8:      	ldr	x8, [x21, #0x10f8]
    52bc:      	cbz	x8, 0x5374 <perf_unwind_dotnet+0x5374>
    52c0:      	mov	w9, #-0x62              // =-98
    52c4:      	b	0x687c <perf_unwind_dotnet+0x687c>
    52c8:      	ldr	x8, [x21, #0x10c8]
    52cc:      	cbz	x8, 0x5384 <perf_unwind_dotnet+0x5384>
    52d0:      	mov	w9, #-0x56              // =-86
    52d4:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    52d8:      	ldr	x8, [x21, #0x1040]
    52dc:      	cbz	x8, 0x5394 <perf_unwind_dotnet+0x5394>
    52e0:      	mov	w9, #-0x34              // =-52
    52e4:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    52e8:      	ldr	x8, [x21, #0x1098]
    52ec:      	cbz	x8, 0x53a4 <perf_unwind_dotnet+0x53a4>
    52f0:      	mov	w9, #-0x4a              // =-74
    52f4:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    52f8:      	ldr	x8, [x21, #0x1130]
    52fc:      	cbz	x8, 0x53b4 <perf_unwind_dotnet+0x53b4>
    5300:      	mov	w9, #-0x70              // =-112
    5304:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5308:      	adrp	x8, 0x5000 <perf_unwind_dotnet+0x5000>
    530c:      	ldr	x8, [x8]
    5310:      	ldr	w8, [x8]
    5314:      	cbz	w8, 0x535c <perf_unwind_dotnet+0x535c>
    5318:      	adrp	x8, 0x5000 <perf_unwind_dotnet+0x5000>
    531c:      	add	x8, x8, #0x0
    5320:      	add	x0, sp, #0x20
    5324:      	ldp	x9, x10, [x8, #0x10]
    5328:      	mov	w1, #0x2e               // =46
    532c:      	stp	x9, x10, [sp, #0x30]
    5330:      	ldr	x9, [x8, #0x20]
    5334:      	add	x10, sp, #0x20
    5338:      	str	x9, [sp, #0x40]
    533c:      	ldur	x9, [x8, #0x26]
    5340:      	stur	x9, [sp, #0x46]
    5344:      	ldp	x9, x8, [x8]
    5348:      	stp	x9, x8, [sp, #0x20]
    534c:      	mov	w8, #0x2e               // =46
    5350:      	mov	w9, #0x6                // =6
    5354:      	ldr	w2, [sp, #0x68]
    5358:      	blr	x9
    535c:      	ldrh	w25, [x23, #0x20]
    5360:      	b	0x4f64 <perf_unwind_dotnet+0x4f64>
    5364:      	ldr	x8, [x21, #0x1068]
    5368:      	cbz	x8, 0x53c4 <perf_unwind_dotnet+0x53c4>
    536c:      	mov	w9, #-0x3e              // =-62
    5370:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5374:      	ldr	x8, [x21, #0x10f0]
    5378:      	cbz	x8, 0x53d4 <perf_unwind_dotnet+0x53d4>
    537c:      	mov	w9, #-0x60              // =-96
    5380:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5384:      	ldr	x8, [x21, #0x10c0]
    5388:      	cbz	x8, 0x53e4 <perf_unwind_dotnet+0x53e4>
    538c:      	mov	w9, #-0x54              // =-84
    5390:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5394:      	ldr	x8, [x21, #0x1038]
    5398:      	cbz	x8, 0x53f4 <perf_unwind_dotnet+0x53f4>
    539c:      	mov	w9, #-0x32              // =-50
    53a0:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    53a4:      	ldr	x8, [x21, #0x1090]
    53a8:      	cbz	x8, 0x5404 <perf_unwind_dotnet+0x5404>
    53ac:      	mov	w9, #-0x48              // =-72
    53b0:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    53b4:      	ldr	x8, [x21, #0x1128]
    53b8:      	cbz	x8, 0x5414 <perf_unwind_dotnet+0x5414>
    53bc:      	mov	w9, #-0x6e              // =-110
    53c0:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    53c4:      	ldr	x8, [x21, #0x1060]
    53c8:      	cbz	x8, 0x5424 <perf_unwind_dotnet+0x5424>
    53cc:      	mov	w9, #-0x3c              // =-60
    53d0:      	b	0x609c <perf_unwind_dotnet+0x609c>
    53d4:      	ldr	x8, [x21, #0x10e8]
    53d8:      	cbz	x8, 0x5434 <perf_unwind_dotnet+0x5434>
    53dc:      	mov	w9, #-0x5e              // =-94
    53e0:      	b	0x687c <perf_unwind_dotnet+0x687c>
    53e4:      	ldr	x8, [x21, #0x10b8]
    53e8:      	cbz	x8, 0x5444 <perf_unwind_dotnet+0x5444>
    53ec:      	mov	w9, #-0x52              // =-82
    53f0:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    53f4:      	ldr	x8, [x21, #0x1030]
    53f8:      	cbz	x8, 0x5454 <perf_unwind_dotnet+0x5454>
    53fc:      	mov	w9, #-0x30              // =-48
    5400:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    5404:      	ldr	x8, [x21, #0x1088]
    5408:      	cbz	x8, 0x5464 <perf_unwind_dotnet+0x5464>
    540c:      	mov	w9, #-0x46              // =-70
    5410:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5414:      	ldr	x8, [x21, #0x1120]
    5418:      	cbz	x8, 0x5474 <perf_unwind_dotnet+0x5474>
    541c:      	mov	w9, #-0x6c              // =-108
    5420:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5424:      	ldr	x8, [x21, #0x1058]
    5428:      	cbz	x8, 0x5484 <perf_unwind_dotnet+0x5484>
    542c:      	mov	w9, #-0x3a              // =-58
    5430:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5434:      	ldr	x8, [x21, #0x10e0]
    5438:      	cbz	x8, 0x5494 <perf_unwind_dotnet+0x5494>
    543c:      	mov	w9, #-0x5c              // =-92
    5440:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5444:      	ldr	x8, [x21, #0x10b0]
    5448:      	cbz	x8, 0x54a4 <perf_unwind_dotnet+0x54a4>
    544c:      	mov	w9, #-0x50              // =-80
    5450:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5454:      	ldr	x8, [x21, #0x1028]
    5458:      	cbz	x8, 0x54b4 <perf_unwind_dotnet+0x54b4>
    545c:      	mov	w9, #-0x2e              // =-46
    5460:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    5464:      	ldr	x8, [x21, #0x1080]
    5468:      	cbz	x8, 0x54c4 <perf_unwind_dotnet+0x54c4>
    546c:      	mov	w9, #-0x44              // =-68
    5470:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5474:      	ldr	x8, [x21, #0x1118]
    5478:      	cbz	x8, 0x54d4 <perf_unwind_dotnet+0x54d4>
    547c:      	mov	w9, #-0x6a              // =-106
    5480:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5484:      	ldr	x8, [x21, #0x1050]
    5488:      	cbz	x8, 0x54e4 <perf_unwind_dotnet+0x54e4>
    548c:      	mov	w9, #-0x38              // =-56
    5490:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5494:      	ldr	x8, [x21, #0x10d8]
    5498:      	cbz	x8, 0x54f4 <perf_unwind_dotnet+0x54f4>
    549c:      	mov	w9, #-0x5a              // =-90
    54a0:      	b	0x687c <perf_unwind_dotnet+0x687c>
    54a4:      	ldr	x8, [x21, #0x10a8]
    54a8:      	cbz	x8, 0x5504 <perf_unwind_dotnet+0x5504>
    54ac:      	mov	w9, #-0x4e              // =-78
    54b0:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    54b4:      	ldr	x8, [x21, #0x1020]
    54b8:      	cbz	x8, 0x5514 <perf_unwind_dotnet+0x5514>
    54bc:      	mov	w9, #-0x2c              // =-44
    54c0:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    54c4:      	ldr	x8, [x21, #0x1078]
    54c8:      	cbz	x8, 0x5524 <perf_unwind_dotnet+0x5524>
    54cc:      	mov	w9, #-0x42              // =-66
    54d0:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    54d4:      	ldr	x8, [x21, #0x1110]
    54d8:      	cbz	x8, 0x5534 <perf_unwind_dotnet+0x5534>
    54dc:      	mov	w9, #-0x68              // =-104
    54e0:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    54e4:      	ldr	x8, [x21, #0x1048]
    54e8:      	cbz	x8, 0x5544 <perf_unwind_dotnet+0x5544>
    54ec:      	mov	w9, #-0x36              // =-54
    54f0:      	b	0x609c <perf_unwind_dotnet+0x609c>
    54f4:      	ldr	x8, [x21, #0x10d0]
    54f8:      	cbz	x8, 0x5554 <perf_unwind_dotnet+0x5554>
    54fc:      	mov	w9, #-0x58              // =-88
    5500:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5504:      	ldr	x8, [x21, #0x10a0]
    5508:      	cbz	x8, 0x5564 <perf_unwind_dotnet+0x5564>
    550c:      	mov	w9, #-0x4c              // =-76
    5510:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5514:      	ldr	x8, [x21, #0x1018]
    5518:      	cbz	x8, 0x5574 <perf_unwind_dotnet+0x5574>
    551c:      	mov	w9, #-0x2a              // =-42
    5520:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    5524:      	ldr	x8, [x21, #0x1070]
    5528:      	cbz	x8, 0x5584 <perf_unwind_dotnet+0x5584>
    552c:      	mov	w9, #-0x40              // =-64
    5530:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5534:      	ldr	x8, [x21, #0x1108]
    5538:      	cbz	x8, 0x5594 <perf_unwind_dotnet+0x5594>
    553c:      	mov	w9, #-0x66              // =-102
    5540:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5544:      	ldr	x8, [x21, #0x1040]
    5548:      	cbz	x8, 0x55a4 <perf_unwind_dotnet+0x55a4>
    554c:      	mov	w9, #-0x34              // =-52
    5550:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5554:      	ldr	x8, [x21, #0x10c8]
    5558:      	cbz	x8, 0x55b4 <perf_unwind_dotnet+0x55b4>
    555c:      	mov	w9, #-0x56              // =-86
    5560:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5564:      	ldr	x8, [x21, #0x1098]
    5568:      	cbz	x8, 0x55c4 <perf_unwind_dotnet+0x55c4>
    556c:      	mov	w9, #-0x4a              // =-74
    5570:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5574:      	ldr	x8, [x21, #0x1010]
    5578:      	cbz	x8, 0x55d4 <perf_unwind_dotnet+0x55d4>
    557c:      	mov	w9, #-0x28              // =-40
    5580:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    5584:      	ldr	x8, [x21, #0x1068]
    5588:      	cbz	x8, 0x55e4 <perf_unwind_dotnet+0x55e4>
    558c:      	mov	w9, #-0x3e              // =-62
    5590:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5594:      	ldr	x8, [x21, #0x1100]
    5598:      	cbz	x8, 0x55f4 <perf_unwind_dotnet+0x55f4>
    559c:      	mov	w9, #-0x64              // =-100
    55a0:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    55a4:      	ldr	x8, [x21, #0x1038]
    55a8:      	cbz	x8, 0x5604 <perf_unwind_dotnet+0x5604>
    55ac:      	mov	w9, #-0x32              // =-50
    55b0:      	b	0x609c <perf_unwind_dotnet+0x609c>
    55b4:      	ldr	x8, [x21, #0x10c0]
    55b8:      	cbz	x8, 0x5614 <perf_unwind_dotnet+0x5614>
    55bc:      	mov	w9, #-0x54              // =-84
    55c0:      	b	0x687c <perf_unwind_dotnet+0x687c>
    55c4:      	ldr	x8, [x21, #0x1090]
    55c8:      	cbz	x8, 0x5624 <perf_unwind_dotnet+0x5624>
    55cc:      	mov	w9, #-0x48              // =-72
    55d0:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    55d4:      	ldr	x8, [x21, #0x1008]
    55d8:      	cbz	x8, 0x5634 <perf_unwind_dotnet+0x5634>
    55dc:      	mov	w9, #-0x26              // =-38
    55e0:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    55e4:      	ldr	x8, [x21, #0x1060]
    55e8:      	cbz	x8, 0x5644 <perf_unwind_dotnet+0x5644>
    55ec:      	mov	w9, #-0x3c              // =-60
    55f0:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    55f4:      	ldr	x8, [x21, #0x10f8]
    55f8:      	cbz	x8, 0x5654 <perf_unwind_dotnet+0x5654>
    55fc:      	mov	w9, #-0x62              // =-98
    5600:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5604:      	ldr	x8, [x21, #0x1030]
    5608:      	cbz	x8, 0x5664 <perf_unwind_dotnet+0x5664>
    560c:      	mov	w9, #-0x30              // =-48
    5610:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5614:      	ldr	x8, [x21, #0x10b8]
    5618:      	cbz	x8, 0x5674 <perf_unwind_dotnet+0x5674>
    561c:      	mov	w9, #-0x52              // =-82
    5620:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5624:      	ldr	x8, [x21, #0x1088]
    5628:      	cbz	x8, 0x5684 <perf_unwind_dotnet+0x5684>
    562c:      	mov	w9, #-0x46              // =-70
    5630:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5634:      	ldr	x8, [x21, #0x1000]
    5638:      	cbz	x8, 0x5694 <perf_unwind_dotnet+0x5694>
    563c:      	mov	w9, #-0x24              // =-36
    5640:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    5644:      	ldr	x8, [x21, #0x1058]
    5648:      	cbz	x8, 0x56a4 <perf_unwind_dotnet+0x56a4>
    564c:      	mov	w9, #-0x3a              // =-58
    5650:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5654:      	ldr	x8, [x21, #0x10f0]
    5658:      	cbz	x8, 0x56b4 <perf_unwind_dotnet+0x56b4>
    565c:      	mov	w9, #-0x60              // =-96
    5660:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5664:      	ldr	x8, [x21, #0x1028]
    5668:      	cbz	x8, 0x56c4 <perf_unwind_dotnet+0x56c4>
    566c:      	mov	w9, #-0x2e              // =-46
    5670:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5674:      	ldr	x8, [x21, #0x10b0]
    5678:      	cbz	x8, 0x56d4 <perf_unwind_dotnet+0x56d4>
    567c:      	mov	w9, #-0x50              // =-80
    5680:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5684:      	ldr	x8, [x21, #0x1080]
    5688:      	cbz	x8, 0x56e4 <perf_unwind_dotnet+0x56e4>
    568c:      	mov	w9, #-0x44              // =-68
    5690:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5694:      	ldr	x8, [x21, #0xff8]
    5698:      	cbz	x8, 0x56f4 <perf_unwind_dotnet+0x56f4>
    569c:      	mov	w9, #-0x22              // =-34
    56a0:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    56a4:      	ldr	x8, [x21, #0x1050]
    56a8:      	cbz	x8, 0x5704 <perf_unwind_dotnet+0x5704>
    56ac:      	mov	w9, #-0x38              // =-56
    56b0:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    56b4:      	ldr	x8, [x21, #0x10e8]
    56b8:      	cbz	x8, 0x5714 <perf_unwind_dotnet+0x5714>
    56bc:      	mov	w9, #-0x5e              // =-94
    56c0:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    56c4:      	ldr	x8, [x21, #0x1020]
    56c8:      	cbz	x8, 0x5724 <perf_unwind_dotnet+0x5724>
    56cc:      	mov	w9, #-0x2c              // =-44
    56d0:      	b	0x609c <perf_unwind_dotnet+0x609c>
    56d4:      	ldr	x8, [x21, #0x10a8]
    56d8:      	cbz	x8, 0x5734 <perf_unwind_dotnet+0x5734>
    56dc:      	mov	w9, #-0x4e              // =-78
    56e0:      	b	0x687c <perf_unwind_dotnet+0x687c>
    56e4:      	ldr	x8, [x21, #0x1078]
    56e8:      	cbz	x8, 0x5744 <perf_unwind_dotnet+0x5744>
    56ec:      	mov	w9, #-0x42              // =-66
    56f0:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    56f4:      	ldr	x8, [x21, #0xff0]
    56f8:      	cbz	x8, 0x5754 <perf_unwind_dotnet+0x5754>
    56fc:      	mov	w9, #-0x20              // =-32
    5700:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    5704:      	ldr	x8, [x21, #0x1048]
    5708:      	cbz	x8, 0x5764 <perf_unwind_dotnet+0x5764>
    570c:      	mov	w9, #-0x36              // =-54
    5710:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5714:      	ldr	x8, [x21, #0x10e0]
    5718:      	cbz	x8, 0x5774 <perf_unwind_dotnet+0x5774>
    571c:      	mov	w9, #-0x5c              // =-92
    5720:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5724:      	ldr	x8, [x21, #0x1018]
    5728:      	cbz	x8, 0x5784 <perf_unwind_dotnet+0x5784>
    572c:      	mov	w9, #-0x2a              // =-42
    5730:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5734:      	ldr	x8, [x21, #0x10a0]
    5738:      	cbz	x8, 0x5794 <perf_unwind_dotnet+0x5794>
    573c:      	mov	w9, #-0x4c              // =-76
    5740:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5744:      	ldr	x8, [x21, #0x1070]
    5748:      	cbz	x8, 0x57a4 <perf_unwind_dotnet+0x57a4>
    574c:      	mov	w9, #-0x40              // =-64
    5750:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5754:      	ldr	x8, [x21, #0xfe8]
    5758:      	cbz	x8, 0x57b4 <perf_unwind_dotnet+0x57b4>
    575c:      	mov	w9, #-0x1e              // =-30
    5760:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    5764:      	ldr	x8, [x21, #0x1040]
    5768:      	cbz	x8, 0x57c4 <perf_unwind_dotnet+0x57c4>
    576c:      	mov	w9, #-0x34              // =-52
    5770:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5774:      	ldr	x8, [x21, #0x10d8]
    5778:      	cbz	x8, 0x57d4 <perf_unwind_dotnet+0x57d4>
    577c:      	mov	w9, #-0x5a              // =-90
    5780:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5784:      	ldr	x8, [x21, #0x1010]
    5788:      	cbz	x8, 0x57e4 <perf_unwind_dotnet+0x57e4>
    578c:      	mov	w9, #-0x28              // =-40
    5790:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5794:      	ldr	x8, [x21, #0x1098]
    5798:      	cbz	x8, 0x57f4 <perf_unwind_dotnet+0x57f4>
    579c:      	mov	w9, #-0x4a              // =-74
    57a0:      	b	0x687c <perf_unwind_dotnet+0x687c>
    57a4:      	ldr	x8, [x21, #0x1068]
    57a8:      	cbz	x8, 0x5804 <perf_unwind_dotnet+0x5804>
    57ac:      	mov	w9, #-0x3e              // =-62
    57b0:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    57b4:      	ldr	x8, [x21, #0xfe0]
    57b8:      	cbz	x8, 0x5814 <perf_unwind_dotnet+0x5814>
    57bc:      	mov	w9, #-0x1c              // =-28
    57c0:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    57c4:      	ldr	x8, [x21, #0x1038]
    57c8:      	cbz	x8, 0x5824 <perf_unwind_dotnet+0x5824>
    57cc:      	mov	w9, #-0x32              // =-50
    57d0:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    57d4:      	ldr	x8, [x21, #0x10d0]
    57d8:      	cbz	x8, 0x5834 <perf_unwind_dotnet+0x5834>
    57dc:      	mov	w9, #-0x58              // =-88
    57e0:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    57e4:      	ldr	x8, [x21, #0x1008]
    57e8:      	cbz	x8, 0x5844 <perf_unwind_dotnet+0x5844>
    57ec:      	mov	w9, #-0x26              // =-38
    57f0:      	b	0x609c <perf_unwind_dotnet+0x609c>
    57f4:      	ldr	x8, [x21, #0x1090]
    57f8:      	cbz	x8, 0x5854 <perf_unwind_dotnet+0x5854>
    57fc:      	mov	w9, #-0x48              // =-72
    5800:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5804:      	ldr	x8, [x21, #0x1060]
    5808:      	cbz	x8, 0x5864 <perf_unwind_dotnet+0x5864>
    580c:      	mov	w9, #-0x3c              // =-60
    5810:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5814:      	ldr	x8, [x21, #0xfd8]
    5818:      	cbz	x8, 0x5874 <perf_unwind_dotnet+0x5874>
    581c:      	mov	w9, #-0x1a              // =-26
    5820:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    5824:      	ldr	x8, [x21, #0x1030]
    5828:      	cbz	x8, 0x5884 <perf_unwind_dotnet+0x5884>
    582c:      	mov	w9, #-0x30              // =-48
    5830:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5834:      	ldr	x8, [x21, #0x10c8]
    5838:      	cbz	x8, 0x5894 <perf_unwind_dotnet+0x5894>
    583c:      	mov	w9, #-0x56              // =-86
    5840:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5844:      	ldr	x8, [x21, #0x1000]
    5848:      	cbz	x8, 0x58a4 <perf_unwind_dotnet+0x58a4>
    584c:      	mov	w9, #-0x24              // =-36
    5850:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5854:      	ldr	x8, [x21, #0x1088]
    5858:      	cbz	x8, 0x58b4 <perf_unwind_dotnet+0x58b4>
    585c:      	mov	w9, #-0x46              // =-70
    5860:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5864:      	ldr	x8, [x21, #0x1058]
    5868:      	cbz	x8, 0x58c4 <perf_unwind_dotnet+0x58c4>
    586c:      	mov	w9, #-0x3a              // =-58
    5870:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5874:      	ldr	x8, [x21, #0xfd0]
    5878:      	cbz	x8, 0x58d4 <perf_unwind_dotnet+0x58d4>
    587c:      	mov	w9, #-0x18              // =-24
    5880:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    5884:      	ldr	x8, [x21, #0x1028]
    5888:      	cbz	x8, 0x58e4 <perf_unwind_dotnet+0x58e4>
    588c:      	mov	w9, #-0x2e              // =-46
    5890:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5894:      	ldr	x8, [x21, #0x10c0]
    5898:      	cbz	x8, 0x58f4 <perf_unwind_dotnet+0x58f4>
    589c:      	mov	w9, #-0x54              // =-84
    58a0:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    58a4:      	ldr	x8, [x21, #0xff8]
    58a8:      	cbz	x8, 0x5904 <perf_unwind_dotnet+0x5904>
    58ac:      	mov	w9, #-0x22              // =-34
    58b0:      	b	0x609c <perf_unwind_dotnet+0x609c>
    58b4:      	ldr	x8, [x21, #0x1080]
    58b8:      	cbz	x8, 0x5914 <perf_unwind_dotnet+0x5914>
    58bc:      	mov	w9, #-0x44              // =-68
    58c0:      	b	0x687c <perf_unwind_dotnet+0x687c>
    58c4:      	ldr	x8, [x21, #0x1050]
    58c8:      	cbz	x8, 0x5924 <perf_unwind_dotnet+0x5924>
    58cc:      	mov	w9, #-0x38              // =-56
    58d0:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    58d4:      	ldr	x8, [x21, #0xfc8]
    58d8:      	cbz	x8, 0x5934 <perf_unwind_dotnet+0x5934>
    58dc:      	mov	w9, #-0x16              // =-22
    58e0:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    58e4:      	ldr	x8, [x21, #0x1020]
    58e8:      	cbz	x8, 0x5944 <perf_unwind_dotnet+0x5944>
    58ec:      	mov	w9, #-0x2c              // =-44
    58f0:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    58f4:      	ldr	x8, [x21, #0x10b8]
    58f8:      	cbz	x8, 0x5954 <perf_unwind_dotnet+0x5954>
    58fc:      	mov	w9, #-0x52              // =-82
    5900:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5904:      	ldr	x8, [x21, #0xff0]
    5908:      	cbz	x8, 0x5964 <perf_unwind_dotnet+0x5964>
    590c:      	mov	w9, #-0x20              // =-32
    5910:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5914:      	ldr	x8, [x21, #0x1078]
    5918:      	cbz	x8, 0x5974 <perf_unwind_dotnet+0x5974>
    591c:      	mov	w9, #-0x42              // =-66
    5920:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5924:      	ldr	x8, [x21, #0x1048]
    5928:      	cbz	x8, 0x5984 <perf_unwind_dotnet+0x5984>
    592c:      	mov	w9, #-0x36              // =-54
    5930:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5934:      	ldr	x8, [x21, #0xfc0]
    5938:      	cbz	x8, 0x5994 <perf_unwind_dotnet+0x5994>
    593c:      	mov	w9, #-0x14              // =-20
    5940:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    5944:      	ldr	x8, [x21, #0x1018]
    5948:      	cbz	x8, 0x59a4 <perf_unwind_dotnet+0x59a4>
    594c:      	mov	w9, #-0x2a              // =-42
    5950:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5954:      	ldr	x8, [x21, #0x10b0]
    5958:      	cbz	x8, 0x59b4 <perf_unwind_dotnet+0x59b4>
    595c:      	mov	w9, #-0x50              // =-80
    5960:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5964:      	ldr	x8, [x21, #0xfe8]
    5968:      	cbz	x8, 0x59c4 <perf_unwind_dotnet+0x59c4>
    596c:      	mov	w9, #-0x1e              // =-30
    5970:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5974:      	ldr	x8, [x21, #0x1070]
    5978:      	cbz	x8, 0x59d4 <perf_unwind_dotnet+0x59d4>
    597c:      	mov	w9, #-0x40              // =-64
    5980:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5984:      	ldr	x8, [x21, #0x1040]
    5988:      	cbz	x8, 0x59e4 <perf_unwind_dotnet+0x59e4>
    598c:      	mov	w9, #-0x34              // =-52
    5990:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5994:      	ldr	x8, [x21, #0xfb8]
    5998:      	cbz	x8, 0x59f4 <perf_unwind_dotnet+0x59f4>
    599c:      	mov	w9, #-0x12              // =-18
    59a0:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    59a4:      	ldr	x8, [x21, #0x1010]
    59a8:      	cbz	x8, 0x5a04 <perf_unwind_dotnet+0x5a04>
    59ac:      	mov	w9, #-0x28              // =-40
    59b0:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    59b4:      	ldr	x8, [x21, #0x10a8]
    59b8:      	cbz	x8, 0x5a14 <perf_unwind_dotnet+0x5a14>
    59bc:      	mov	w9, #-0x4e              // =-78
    59c0:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    59c4:      	ldr	x8, [x21, #0xfe0]
    59c8:      	cbz	x8, 0x5a24 <perf_unwind_dotnet+0x5a24>
    59cc:      	mov	w9, #-0x1c              // =-28
    59d0:      	b	0x609c <perf_unwind_dotnet+0x609c>
    59d4:      	ldr	x8, [x21, #0x1068]
    59d8:      	cbz	x8, 0x5a34 <perf_unwind_dotnet+0x5a34>
    59dc:      	mov	w9, #-0x3e              // =-62
    59e0:      	b	0x687c <perf_unwind_dotnet+0x687c>
    59e4:      	ldr	x8, [x21, #0x1038]
    59e8:      	cbz	x8, 0x5a44 <perf_unwind_dotnet+0x5a44>
    59ec:      	mov	w9, #-0x32              // =-50
    59f0:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    59f4:      	ldr	x8, [x21, #0xfb0]
    59f8:      	cbz	x8, 0x5a54 <perf_unwind_dotnet+0x5a54>
    59fc:      	mov	w9, #-0x10              // =-16
    5a00:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    5a04:      	ldr	x8, [x21, #0x1008]
    5a08:      	cbz	x8, 0x5a64 <perf_unwind_dotnet+0x5a64>
    5a0c:      	mov	w9, #-0x26              // =-38
    5a10:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5a14:      	ldr	x8, [x21, #0x10a0]
    5a18:      	cbz	x8, 0x5a74 <perf_unwind_dotnet+0x5a74>
    5a1c:      	mov	w9, #-0x4c              // =-76
    5a20:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5a24:      	ldr	x8, [x21, #0xfd8]
    5a28:      	cbz	x8, 0x5a84 <perf_unwind_dotnet+0x5a84>
    5a2c:      	mov	w9, #-0x1a              // =-26
    5a30:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5a34:      	ldr	x8, [x21, #0x1060]
    5a38:      	cbz	x8, 0x5a94 <perf_unwind_dotnet+0x5a94>
    5a3c:      	mov	w9, #-0x3c              // =-60
    5a40:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5a44:      	ldr	x8, [x21, #0x1030]
    5a48:      	cbz	x8, 0x5aa4 <perf_unwind_dotnet+0x5aa4>
    5a4c:      	mov	w9, #-0x30              // =-48
    5a50:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5a54:      	ldr	x8, [x21, #0xfa8]
    5a58:      	cbz	x8, 0x5ab4 <perf_unwind_dotnet+0x5ab4>
    5a5c:      	mov	w9, #-0xe               // =-14
    5a60:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    5a64:      	ldr	x8, [x21, #0x1000]
    5a68:      	cbz	x8, 0x5ac4 <perf_unwind_dotnet+0x5ac4>
    5a6c:      	mov	w9, #-0x24              // =-36
    5a70:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5a74:      	ldr	x8, [x21, #0x1098]
    5a78:      	cbz	x8, 0x5ad4 <perf_unwind_dotnet+0x5ad4>
    5a7c:      	mov	w9, #-0x4a              // =-74
    5a80:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5a84:      	ldr	x8, [x21, #0xfd0]
    5a88:      	cbz	x8, 0x5ae4 <perf_unwind_dotnet+0x5ae4>
    5a8c:      	mov	w9, #-0x18              // =-24
    5a90:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5a94:      	ldr	x8, [x21, #0x1058]
    5a98:      	cbz	x8, 0x5af4 <perf_unwind_dotnet+0x5af4>
    5a9c:      	mov	w9, #-0x3a              // =-58
    5aa0:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5aa4:      	ldr	x8, [x21, #0x1028]
    5aa8:      	cbz	x8, 0x5b04 <perf_unwind_dotnet+0x5b04>
    5aac:      	mov	w9, #-0x2e              // =-46
    5ab0:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5ab4:      	ldr	x8, [x21, #0xfa0]
    5ab8:      	cbz	x8, 0x5b14 <perf_unwind_dotnet+0x5b14>
    5abc:      	mov	w9, #-0xc               // =-12
    5ac0:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    5ac4:      	ldr	x8, [x21, #0xff8]
    5ac8:      	cbz	x8, 0x5b24 <perf_unwind_dotnet+0x5b24>
    5acc:      	mov	w9, #-0x22              // =-34
    5ad0:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5ad4:      	ldr	x8, [x21, #0x1090]
    5ad8:      	cbz	x8, 0x5b34 <perf_unwind_dotnet+0x5b34>
    5adc:      	mov	w9, #-0x48              // =-72
    5ae0:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5ae4:      	ldr	x8, [x21, #0xfc8]
    5ae8:      	cbz	x8, 0x5b44 <perf_unwind_dotnet+0x5b44>
    5aec:      	mov	w9, #-0x16              // =-22
    5af0:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5af4:      	ldr	x8, [x21, #0x1050]
    5af8:      	cbz	x8, 0x5b54 <perf_unwind_dotnet+0x5b54>
    5afc:      	mov	w9, #-0x38              // =-56
    5b00:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5b04:      	ldr	x8, [x21, #0x1020]
    5b08:      	cbz	x8, 0x5b64 <perf_unwind_dotnet+0x5b64>
    5b0c:      	mov	w9, #-0x2c              // =-44
    5b10:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5b14:      	ldr	x8, [x21, #0xf98]
    5b18:      	cbz	x8, 0x5b74 <perf_unwind_dotnet+0x5b74>
    5b1c:      	mov	w9, #-0xa               // =-10
    5b20:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    5b24:      	ldr	x8, [x21, #0xff0]
    5b28:      	cbz	x8, 0x5b84 <perf_unwind_dotnet+0x5b84>
    5b2c:      	mov	w9, #-0x20              // =-32
    5b30:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5b34:      	ldr	x8, [x21, #0x1088]
    5b38:      	cbz	x8, 0x5b94 <perf_unwind_dotnet+0x5b94>
    5b3c:      	mov	w9, #-0x46              // =-70
    5b40:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5b44:      	ldr	x8, [x21, #0xfc0]
    5b48:      	cbz	x8, 0x5ba4 <perf_unwind_dotnet+0x5ba4>
    5b4c:      	mov	w9, #-0x14              // =-20
    5b50:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5b54:      	ldr	x8, [x21, #0x1048]
    5b58:      	cbz	x8, 0x5bb4 <perf_unwind_dotnet+0x5bb4>
    5b5c:      	mov	w9, #-0x36              // =-54
    5b60:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5b64:      	ldr	x8, [x21, #0x1018]
    5b68:      	cbz	x8, 0x5bc4 <perf_unwind_dotnet+0x5bc4>
    5b6c:      	mov	w9, #-0x2a              // =-42
    5b70:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5b74:      	ldr	x8, [x21, #0xf90]
    5b78:      	cbz	x8, 0x5bd4 <perf_unwind_dotnet+0x5bd4>
    5b7c:      	mov	w9, #-0x8               // =-8
    5b80:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    5b84:      	ldr	x8, [x21, #0xfe8]
    5b88:      	cbz	x8, 0x5be4 <perf_unwind_dotnet+0x5be4>
    5b8c:      	mov	w9, #-0x1e              // =-30
    5b90:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5b94:      	ldr	x8, [x21, #0x1080]
    5b98:      	cbz	x8, 0x5bf4 <perf_unwind_dotnet+0x5bf4>
    5b9c:      	mov	w9, #-0x44              // =-68
    5ba0:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5ba4:      	ldr	x8, [x21, #0xfb8]
    5ba8:      	cbz	x8, 0x5c04 <perf_unwind_dotnet+0x5c04>
    5bac:      	mov	w9, #-0x12              // =-18
    5bb0:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5bb4:      	ldr	x8, [x21, #0x1040]
    5bb8:      	cbz	x8, 0x5c14 <perf_unwind_dotnet+0x5c14>
    5bbc:      	mov	w9, #-0x34              // =-52
    5bc0:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5bc4:      	ldr	x8, [x21, #0x1010]
    5bc8:      	cbz	x8, 0x5c24 <perf_unwind_dotnet+0x5c24>
    5bcc:      	mov	w9, #-0x28              // =-40
    5bd0:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5bd4:      	ldr	x8, [x21, #0xf88]
    5bd8:      	cbz	x8, 0x5c34 <perf_unwind_dotnet+0x5c34>
    5bdc:      	mov	w9, #-0x6               // =-6
    5be0:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    5be4:      	ldr	x8, [x21, #0xfe0]
    5be8:      	cbz	x8, 0x5c44 <perf_unwind_dotnet+0x5c44>
    5bec:      	mov	w9, #-0x1c              // =-28
    5bf0:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5bf4:      	ldr	x8, [x21, #0x1078]
    5bf8:      	cbz	x8, 0x5c54 <perf_unwind_dotnet+0x5c54>
    5bfc:      	mov	w9, #-0x42              // =-66
    5c00:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5c04:      	ldr	x8, [x21, #0xfb0]
    5c08:      	cbz	x8, 0x5c64 <perf_unwind_dotnet+0x5c64>
    5c0c:      	mov	w9, #-0x10              // =-16
    5c10:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5c14:      	ldr	x8, [x21, #0x1038]
    5c18:      	cbz	x8, 0x5c74 <perf_unwind_dotnet+0x5c74>
    5c1c:      	mov	w9, #-0x32              // =-50
    5c20:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5c24:      	ldr	x8, [x21, #0x1008]
    5c28:      	cbz	x8, 0x5c84 <perf_unwind_dotnet+0x5c84>
    5c2c:      	mov	w9, #-0x26              // =-38
    5c30:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5c34:      	ldr	x8, [x21, #0xf80]
    5c38:      	cbz	x8, 0x5c94 <perf_unwind_dotnet+0x5c94>
    5c3c:      	mov	w9, #-0x4               // =-4
    5c40:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    5c44:      	ldr	x8, [x21, #0xfd8]
    5c48:      	cbz	x8, 0x5ca4 <perf_unwind_dotnet+0x5ca4>
    5c4c:      	mov	w9, #-0x1a              // =-26
    5c50:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5c54:      	ldr	x8, [x21, #0x1070]
    5c58:      	cbz	x8, 0x5cb4 <perf_unwind_dotnet+0x5cb4>
    5c5c:      	mov	w9, #-0x40              // =-64
    5c60:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5c64:      	ldr	x8, [x21, #0xfa8]
    5c68:      	cbz	x8, 0x5cc4 <perf_unwind_dotnet+0x5cc4>
    5c6c:      	mov	w9, #-0xe               // =-14
    5c70:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5c74:      	ldr	x8, [x21, #0x1030]
    5c78:      	cbz	x8, 0x5cd4 <perf_unwind_dotnet+0x5cd4>
    5c7c:      	mov	w9, #-0x30              // =-48
    5c80:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5c84:      	ldr	x8, [x21, #0x1000]
    5c88:      	cbz	x8, 0x5ce4 <perf_unwind_dotnet+0x5ce4>
    5c8c:      	mov	w9, #-0x24              // =-36
    5c90:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5c94:      	ldr	x8, [x21, #0xf78]
    5c98:      	cbz	x8, 0x5cf4 <perf_unwind_dotnet+0x5cf4>
    5c9c:      	mov	w9, #-0x2               // =-2
    5ca0:      	b	0x5d00 <perf_unwind_dotnet+0x5d00>
    5ca4:      	ldr	x8, [x21, #0xfd0]
    5ca8:      	cbz	x8, 0x5ee0 <perf_unwind_dotnet+0x5ee0>
    5cac:      	mov	w9, #-0x18              // =-24
    5cb0:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5cb4:      	ldr	x8, [x21, #0x1068]
    5cb8:      	cbz	x8, 0x5ef0 <perf_unwind_dotnet+0x5ef0>
    5cbc:      	mov	w9, #-0x3e              // =-62
    5cc0:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5cc4:      	ldr	x8, [x21, #0xfa0]
    5cc8:      	cbz	x8, 0x5f00 <perf_unwind_dotnet+0x5f00>
    5ccc:      	mov	w9, #-0xc               // =-12
    5cd0:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5cd4:      	ldr	x8, [x21, #0x1028]
    5cd8:      	cbz	x8, 0x5f10 <perf_unwind_dotnet+0x5f10>
    5cdc:      	mov	w9, #-0x2e              // =-46
    5ce0:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5ce4:      	ldr	x8, [x21, #0xff8]
    5ce8:      	cbz	x8, 0x5f20 <perf_unwind_dotnet+0x5f20>
    5cec:      	mov	w9, #-0x22              // =-34
    5cf0:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5cf4:      	ldr	x8, [sp, #0x18]
    5cf8:      	mov	w9, wzr
    5cfc:      	ldr	x8, [x8]
    5d00:      	lsr	x10, x8, #32
    5d04:      	cmp	x10, #0x0
    5d08:      	cset	w11, ne
    5d0c:      	csel	w23, w10, w8, ne
    5d10:      	sub	w8, w9, w11
    5d14:      	add	w3, w8, #0x7e
    5d18:      	lsl	w8, w3, #8
    5d1c:      	subs	x29, x29, x8
    5d20:      	b.hs	0x5dbc <perf_unwind_dotnet+0x5dbc>
    5d24:      	adrp	x23, 0x5000 <perf_unwind_dotnet+0x5000>
    5d28:      	ldr	x23, [x23]
    5d2c:      	ldr	w8, [x23]
    5d30:      	cbz	w8, 0x390 <perf_unwind_dotnet+0x390>
    5d34:      	adrp	x8, 0x5000 <perf_unwind_dotnet+0x5000>
    5d38:      	add	x8, x8, #0x0
    5d3c:      	add	x0, sp, #0x20
    5d40:      	ldp	x9, x10, [x8, #0x10]
    5d44:      	mov	w1, #0x2e               // =46
    5d48:      	stp	x9, x10, [sp, #0x30]
    5d4c:      	ldr	x9, [x8, #0x20]
    5d50:      	add	x10, sp, #0x20
    5d54:      	str	x9, [sp, #0x40]
    5d58:      	ldur	x9, [x8, #0x26]
    5d5c:      	stur	x9, [sp, #0x46]
    5d60:      	ldp	x9, x8, [x8]
    5d64:      	stp	x9, x8, [sp, #0x20]
    5d68:      	mov	w8, #0x2e               // =46
    5d6c:      	mov	w9, #0x6                // =6
    5d70:      	blr	x9
    5d74:      	adrp	x23, 0x5000 <perf_unwind_dotnet+0x5000>
    5d78:      	ldr	x23, [x23]
    5d7c:      	ldr	w8, [x23]
    5d80:      	cbz	w8, 0x390 <perf_unwind_dotnet+0x390>
    5d84:      	mov	w8, #0x646e             // =25710
    5d88:      	add	x10, sp, #0x20
    5d8c:      	add	x0, sp, #0x20
    5d90:      	mov	w1, #0x13               // =19
    5d94:      	movk	w8, #0xa, lsl #16
    5d98:      	stur	w8, [sp, #0x2f]
    5d9c:      	adrp	x8, 0x5000 <perf_unwind_dotnet+0x5000>
    5da0:      	add	x8, x8, #0x0
    5da4:      	ldp	x9, x8, [x8]
    5da8:      	stp	x9, x8, [sp, #0x20]
    5dac:      	mov	w8, #0x13               // =19
    5db0:      	mov	w9, #0x6                // =6
    5db4:      	blr	x9
    5db8:      	b	0x390 <perf_unwind_dotnet+0x390>
    5dbc:      	adrp	x8, 0x5000 <perf_unwind_dotnet+0x5000>
    5dc0:      	ldr	x8, [x8]
    5dc4:      	ldr	w8, [x8]
    5dc8:      	cbnz	w8, 0x5e3c <perf_unwind_dotnet+0x5e3c>
    5dcc:      	cbnz	w23, 0x458 <perf_unwind_dotnet+0x458>
    5dd0:      	mov	w8, #0x5f               // =95
    5dd4:      	adrp	x24, 0x5000 <perf_unwind_dotnet+0x5000>
    5dd8:      	add	x9, sp, #0x8c
    5ddc:      	str	w8, [sp, #0x8c]
    5de0:      	mov	w8, #0x1                // =1
    5de4:      	add	x1, sp, #0x8c
    5de8:      	ldr	x24, [x24]
    5dec:      	mov	x0, x24
    5df0:      	blr	x8
    5df4:      	cbz	x0, 0x5e14 <perf_unwind_dotnet+0x5e14>
    5df8:      	ldr	x8, [x0]
    5dfc:      	adrp	x23, 0x5000 <perf_unwind_dotnet+0x5000>
    5e00:      	add	x8, x8, #0x1
    5e04:      	str	x8, [x0]
    5e08:      	ldr	x23, [x23]
    5e0c:      	ldr	x11, [sp, #0x10]
    5e10:      	b	0x5e28 <perf_unwind_dotnet+0x5e28>
    5e14:      	adrp	x23, 0x5000 <perf_unwind_dotnet+0x5000>
    5e18:      	ldr	x23, [x23]
    5e1c:      	ldr	x11, [sp, #0x10]
    5e20:      	ldr	w8, [x23]
    5e24:      	cbnz	w8, 0x5e98 <perf_unwind_dotnet+0x5e98>
    5e28:      	mov	w2, #0x1773             // =6003
    5e2c:      	mov	w22, #0x1               // =1
    5e30:      	ldr	w8, [x23]
    5e34:      	cbz	w8, 0x48c <perf_unwind_dotnet+0x48c>
    5e38:      	b	0x3d8 <perf_unwind_dotnet+0x3d8>
    5e3c:      	mov	w8, #0x7825             // =30757
    5e40:      	add	x0, sp, #0x20
    5e44:      	mov	w1, #0x3c               // =60
    5e48:      	mov	x2, x29
    5e4c:      	mov	w4, w23
    5e50:      	movk	w8, #0xa, lsl #16
    5e54:      	str	w8, [sp, #0x58]
    5e58:      	adrp	x8, 0x5000 <perf_unwind_dotnet+0x5000>
    5e5c:      	add	x8, x8, #0x0
    5e60:      	ldp	x9, x10, [x8, #0x20]
    5e64:      	stp	x9, x10, [sp, #0x40]
    5e68:      	ldr	x9, [x8, #0x30]
    5e6c:      	str	x9, [sp, #0x50]
    5e70:      	ldp	x9, x10, [x8]
    5e74:      	stp	x9, x10, [sp, #0x20]
    5e78:      	add	x10, sp, #0x20
    5e7c:      	ldp	x8, x9, [x8, #0x10]
    5e80:      	stp	x8, x9, [sp, #0x30]
    5e84:      	mov	w8, #0x3c               // =60
    5e88:      	mov	w9, #0x6                // =6
    5e8c:      	blr	x9
    5e90:      	cbnz	w23, 0x458 <perf_unwind_dotnet+0x458>
    5e94:      	b	0x5dd0 <perf_unwind_dotnet+0x5dd0>
    5e98:      	adrp	x8, 0x5000 <perf_unwind_dotnet+0x5000>
    5e9c:      	add	x8, x8, #0x0
    5ea0:      	add	x0, sp, #0x20
    5ea4:      	ldp	x9, x10, [x8, #0x10]
    5ea8:      	mov	w1, #0x2e               // =46
    5eac:      	stp	x9, x10, [sp, #0x30]
    5eb0:      	ldr	x9, [x8, #0x20]
    5eb4:      	add	x10, sp, #0x20
    5eb8:      	str	x9, [sp, #0x40]
    5ebc:      	ldur	x9, [x8, #0x26]
    5ec0:      	stur	x9, [sp, #0x46]
    5ec4:      	ldp	x9, x8, [x8]
    5ec8:      	stp	x9, x8, [sp, #0x20]
    5ecc:      	mov	w8, #0x2e               // =46
    5ed0:      	mov	w9, #0x6                // =6
    5ed4:      	ldr	w2, [sp, #0x8c]
    5ed8:      	blr	x9
    5edc:      	b	0x5e0c <perf_unwind_dotnet+0x5e0c>
    5ee0:      	ldr	x8, [x21, #0xfc8]
    5ee4:      	cbz	x8, 0x5f30 <perf_unwind_dotnet+0x5f30>
    5ee8:      	mov	w9, #-0x16              // =-22
    5eec:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5ef0:      	ldr	x8, [x21, #0x1060]
    5ef4:      	cbz	x8, 0x5f40 <perf_unwind_dotnet+0x5f40>
    5ef8:      	mov	w9, #-0x3c              // =-60
    5efc:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5f00:      	ldr	x8, [x21, #0xf98]
    5f04:      	cbz	x8, 0x5f50 <perf_unwind_dotnet+0x5f50>
    5f08:      	mov	w9, #-0xa               // =-10
    5f0c:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5f10:      	ldr	x8, [x21, #0x1020]
    5f14:      	cbz	x8, 0x5f60 <perf_unwind_dotnet+0x5f60>
    5f18:      	mov	w9, #-0x2c              // =-44
    5f1c:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5f20:      	ldr	x8, [x21, #0xff0]
    5f24:      	cbz	x8, 0x5f70 <perf_unwind_dotnet+0x5f70>
    5f28:      	mov	w9, #-0x20              // =-32
    5f2c:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5f30:      	ldr	x8, [x21, #0xfc0]
    5f34:      	cbz	x8, 0x5f80 <perf_unwind_dotnet+0x5f80>
    5f38:      	mov	w9, #-0x14              // =-20
    5f3c:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5f40:      	ldr	x8, [x21, #0x1058]
    5f44:      	cbz	x8, 0x5f90 <perf_unwind_dotnet+0x5f90>
    5f48:      	mov	w9, #-0x3a              // =-58
    5f4c:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5f50:      	ldr	x8, [x21, #0xf90]
    5f54:      	cbz	x8, 0x5fa0 <perf_unwind_dotnet+0x5fa0>
    5f58:      	mov	w9, #-0x8               // =-8
    5f5c:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5f60:      	ldr	x8, [x21, #0x1018]
    5f64:      	cbz	x8, 0x5fb0 <perf_unwind_dotnet+0x5fb0>
    5f68:      	mov	w9, #-0x2a              // =-42
    5f6c:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5f70:      	ldr	x8, [x21, #0xfe8]
    5f74:      	cbz	x8, 0x5fc0 <perf_unwind_dotnet+0x5fc0>
    5f78:      	mov	w9, #-0x1e              // =-30
    5f7c:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5f80:      	ldr	x8, [x21, #0xfb8]
    5f84:      	cbz	x8, 0x5fd0 <perf_unwind_dotnet+0x5fd0>
    5f88:      	mov	w9, #-0x12              // =-18
    5f8c:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5f90:      	ldr	x8, [x21, #0x1050]
    5f94:      	cbz	x8, 0x5fe0 <perf_unwind_dotnet+0x5fe0>
    5f98:      	mov	w9, #-0x38              // =-56
    5f9c:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5fa0:      	ldr	x8, [x21, #0xf88]
    5fa4:      	cbz	x8, 0x5ff0 <perf_unwind_dotnet+0x5ff0>
    5fa8:      	mov	w9, #-0x6               // =-6
    5fac:      	b	0x609c <perf_unwind_dotnet+0x609c>
    5fb0:      	ldr	x8, [x21, #0x1010]
    5fb4:      	cbz	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    5fb8:      	mov	w9, #-0x28              // =-40
    5fbc:      	b	0x687c <perf_unwind_dotnet+0x687c>
    5fc0:      	ldr	x8, [x21, #0xfe0]
    5fc4:      	cbz	x8, 0x6010 <perf_unwind_dotnet+0x6010>
    5fc8:      	mov	w9, #-0x1c              // =-28
    5fcc:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    5fd0:      	ldr	x8, [x21, #0xfb0]
    5fd4:      	cbz	x8, 0x6020 <perf_unwind_dotnet+0x6020>
    5fd8:      	mov	w9, #-0x10              // =-16
    5fdc:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    5fe0:      	ldr	x8, [x21, #0x1048]
    5fe4:      	cbz	x8, 0x6030 <perf_unwind_dotnet+0x6030>
    5fe8:      	mov	w9, #-0x36              // =-54
    5fec:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    5ff0:      	ldr	x8, [x21, #0xf80]
    5ff4:      	cbz	x8, 0x6040 <perf_unwind_dotnet+0x6040>
    5ff8:      	mov	w9, #-0x4               // =-4
    5ffc:      	b	0x609c <perf_unwind_dotnet+0x609c>
    6000:      	ldr	x8, [x21, #0x1008]
    6004:      	cbz	x8, 0x6050 <perf_unwind_dotnet+0x6050>
    6008:      	mov	w9, #-0x26              // =-38
    600c:      	b	0x687c <perf_unwind_dotnet+0x687c>
    6010:      	ldr	x8, [x21, #0xfd8]
    6014:      	cbz	x8, 0x6060 <perf_unwind_dotnet+0x6060>
    6018:      	mov	w9, #-0x1a              // =-26
    601c:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    6020:      	ldr	x8, [x21, #0xfa8]
    6024:      	cbz	x8, 0x6070 <perf_unwind_dotnet+0x6070>
    6028:      	mov	w9, #-0xe               // =-14
    602c:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    6030:      	ldr	x8, [x21, #0x1040]
    6034:      	cbz	x8, 0x6080 <perf_unwind_dotnet+0x6080>
    6038:      	mov	w9, #-0x34              // =-52
    603c:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6040:      	ldr	x8, [x21, #0xf78]
    6044:      	cbz	x8, 0x6090 <perf_unwind_dotnet+0x6090>
    6048:      	mov	w9, #-0x2               // =-2
    604c:      	b	0x609c <perf_unwind_dotnet+0x609c>
    6050:      	ldr	x8, [x21, #0x1000]
    6054:      	cbz	x8, 0x62f4 <perf_unwind_dotnet+0x62f4>
    6058:      	mov	w9, #-0x24              // =-36
    605c:      	b	0x687c <perf_unwind_dotnet+0x687c>
    6060:      	ldr	x8, [x21, #0xfd0]
    6064:      	cbz	x8, 0x6304 <perf_unwind_dotnet+0x6304>
    6068:      	mov	w9, #-0x18              // =-24
    606c:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    6070:      	ldr	x8, [x21, #0xfa0]
    6074:      	cbz	x8, 0x6314 <perf_unwind_dotnet+0x6314>
    6078:      	mov	w9, #-0xc               // =-12
    607c:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    6080:      	ldr	x8, [x21, #0x1038]
    6084:      	cbz	x8, 0x6324 <perf_unwind_dotnet+0x6324>
    6088:      	mov	w9, #-0x32              // =-50
    608c:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6090:      	ldr	x8, [sp, #0x18]
    6094:      	mov	w9, wzr
    6098:      	ldr	x8, [x8]
    609c:      	lsr	x10, x8, #32
    60a0:      	cmp	x10, #0x0
    60a4:      	cset	w11, ne
    60a8:      	csel	w25, w10, w8, ne
    60ac:      	sub	w8, w9, w11
    60b0:      	add	w3, w8, #0x7e
    60b4:      	lsl	w8, w3, #8
    60b8:      	subs	x29, x23, x8
    60bc:      	b.hs	0x6158 <perf_unwind_dotnet+0x6158>
    60c0:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    60c4:      	ldr	x8, [x8]
    60c8:      	ldr	w8, [x8]
    60cc:      	cbz	w8, 0x1230 <perf_unwind_dotnet+0x1230>
    60d0:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    60d4:      	add	x8, x8, #0x0
    60d8:      	add	x0, sp, #0x20
    60dc:      	ldp	x9, x10, [x8, #0x10]
    60e0:      	mov	w1, #0x2e               // =46
    60e4:      	stp	x9, x10, [sp, #0x30]
    60e8:      	ldr	x9, [x8, #0x20]
    60ec:      	add	x10, sp, #0x20
    60f0:      	str	x9, [sp, #0x40]
    60f4:      	ldur	x9, [x8, #0x26]
    60f8:      	stur	x9, [sp, #0x46]
    60fc:      	ldp	x9, x8, [x8]
    6100:      	stp	x9, x8, [sp, #0x20]
    6104:      	mov	w8, #0x2e               // =46
    6108:      	mov	w9, #0x6                // =6
    610c:      	blr	x9
    6110:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6114:      	ldr	x8, [x8]
    6118:      	ldr	w8, [x8]
    611c:      	cbz	w8, 0x1230 <perf_unwind_dotnet+0x1230>
    6120:      	mov	w8, #0x646e             // =25710
    6124:      	add	x10, sp, #0x20
    6128:      	add	x0, sp, #0x20
    612c:      	mov	w1, #0x13               // =19
    6130:      	movk	w8, #0xa, lsl #16
    6134:      	stur	w8, [sp, #0x2f]
    6138:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    613c:      	add	x8, x8, #0x0
    6140:      	ldp	x9, x8, [x8]
    6144:      	stp	x9, x8, [sp, #0x20]
    6148:      	mov	w8, #0x13               // =19
    614c:      	mov	w9, #0x6                // =6
    6150:      	blr	x9
    6154:      	b	0x1230 <perf_unwind_dotnet+0x1230>
    6158:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    615c:      	ldr	x8, [x8]
    6160:      	ldr	w8, [x8]
    6164:      	cbnz	w8, 0x6238 <perf_unwind_dotnet+0x6238>
    6168:      	cbnz	w25, 0x12a4 <perf_unwind_dotnet+0x12a4>
    616c:      	mov	w8, #0x5f               // =95
    6170:      	adrp	x0, 0x6000 <perf_unwind_dotnet+0x6000>
    6174:      	add	x9, sp, #0x8c
    6178:      	str	w8, [sp, #0x8c]
    617c:      	mov	w8, #0x1                // =1
    6180:      	add	x1, sp, #0x8c
    6184:      	ldr	x0, [x0]
    6188:      	blr	x8
    618c:      	cbz	x0, 0x61b8 <perf_unwind_dotnet+0x61b8>
    6190:      	ldr	x8, [x0]
    6194:      	add	x8, x8, #0x1
    6198:      	str	x8, [x0]
    619c:      	mov	w2, #0x1773             // =6003
    61a0:      	mov	w22, #0x1               // =1
    61a4:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    61a8:      	ldr	x8, [x8]
    61ac:      	ldr	w8, [x8]
    61b0:      	cbz	w8, 0x12e4 <perf_unwind_dotnet+0x12e4>
    61b4:      	b	0x61e0 <perf_unwind_dotnet+0x61e0>
    61b8:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    61bc:      	ldr	x8, [x8]
    61c0:      	ldr	w8, [x8]
    61c4:      	cbnz	w8, 0x6294 <perf_unwind_dotnet+0x6294>
    61c8:      	mov	w2, #0x1773             // =6003
    61cc:      	mov	w22, #0x1               // =1
    61d0:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    61d4:      	ldr	x8, [x8]
    61d8:      	ldr	w8, [x8]
    61dc:      	cbz	w8, 0x12e4 <perf_unwind_dotnet+0x12e4>
    61e0:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    61e4:      	add	x8, x8, #0x0
    61e8:      	add	x0, sp, #0x20
    61ec:      	ldp	x9, x10, [x8, #0x10]
    61f0:      	mov	w1, #0x28               // =40
    61f4:      	stp	x9, x10, [sp, #0x30]
    61f8:      	ldr	x9, [x8, #0x20]
    61fc:      	add	x10, sp, #0x20
    6200:      	str	x9, [sp, #0x40]
    6204:      	ldp	x8, x9, [x8]
    6208:      	stp	x8, x9, [sp, #0x20]
    620c:      	mov	w8, #0x28               // =40
    6210:      	mov	w9, #0x6                // =6
    6214:      	blr	x9
    6218:      	cbnz	w22, 0x12e8 <perf_unwind_dotnet+0x12e8>
    621c:      	adrp	x23, 0x6000 <perf_unwind_dotnet+0x6000>
    6220:      	adrp	x24, 0x6000 <perf_unwind_dotnet+0x6000>
    6224:      	mov	w8, #0x1772             // =6002
    6228:      	ldr	x23, [x23]
    622c:      	ldr	x24, [x24]
    6230:      	mov	w25, wzr
    6234:      	b	0x4624 <perf_unwind_dotnet+0x4624>
    6238:      	mov	w8, #0x7825             // =30757
    623c:      	add	x0, sp, #0x20
    6240:      	mov	w1, #0x3c               // =60
    6244:      	mov	x2, x29
    6248:      	mov	w4, w25
    624c:      	movk	w8, #0xa, lsl #16
    6250:      	str	w8, [sp, #0x58]
    6254:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6258:      	add	x8, x8, #0x0
    625c:      	ldp	x9, x10, [x8, #0x20]
    6260:      	stp	x9, x10, [sp, #0x40]
    6264:      	ldr	x9, [x8, #0x30]
    6268:      	str	x9, [sp, #0x50]
    626c:      	ldp	x9, x10, [x8]
    6270:      	stp	x9, x10, [sp, #0x20]
    6274:      	add	x10, sp, #0x20
    6278:      	ldp	x8, x9, [x8, #0x10]
    627c:      	stp	x8, x9, [sp, #0x30]
    6280:      	mov	w8, #0x3c               // =60
    6284:      	mov	w9, #0x6                // =6
    6288:      	blr	x9
    628c:      	cbnz	w25, 0x12a4 <perf_unwind_dotnet+0x12a4>
    6290:      	b	0x616c <perf_unwind_dotnet+0x616c>
    6294:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6298:      	add	x8, x8, #0x0
    629c:      	add	x0, sp, #0x20
    62a0:      	ldp	x9, x10, [x8, #0x10]
    62a4:      	mov	w1, #0x2e               // =46
    62a8:      	stp	x9, x10, [sp, #0x30]
    62ac:      	ldr	x9, [x8, #0x20]
    62b0:      	add	x10, sp, #0x20
    62b4:      	str	x9, [sp, #0x40]
    62b8:      	ldur	x9, [x8, #0x26]
    62bc:      	stur	x9, [sp, #0x46]
    62c0:      	ldp	x9, x8, [x8]
    62c4:      	stp	x9, x8, [sp, #0x20]
    62c8:      	mov	w8, #0x2e               // =46
    62cc:      	mov	w9, #0x6                // =6
    62d0:      	ldr	w2, [sp, #0x8c]
    62d4:      	blr	x9
    62d8:      	mov	w2, #0x1773             // =6003
    62dc:      	mov	w22, #0x1               // =1
    62e0:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    62e4:      	ldr	x8, [x8]
    62e8:      	ldr	w8, [x8]
    62ec:      	cbz	w8, 0x12e4 <perf_unwind_dotnet+0x12e4>
    62f0:      	b	0x61e0 <perf_unwind_dotnet+0x61e0>
    62f4:      	ldr	x8, [x21, #0xff8]
    62f8:      	cbz	x8, 0x6334 <perf_unwind_dotnet+0x6334>
    62fc:      	mov	w9, #-0x22              // =-34
    6300:      	b	0x687c <perf_unwind_dotnet+0x687c>
    6304:      	ldr	x8, [x21, #0xfc8]
    6308:      	cbz	x8, 0x6344 <perf_unwind_dotnet+0x6344>
    630c:      	mov	w9, #-0x16              // =-22
    6310:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    6314:      	ldr	x8, [x21, #0xf98]
    6318:      	cbz	x8, 0x6354 <perf_unwind_dotnet+0x6354>
    631c:      	mov	w9, #-0xa               // =-10
    6320:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    6324:      	ldr	x8, [x21, #0x1030]
    6328:      	cbz	x8, 0x6364 <perf_unwind_dotnet+0x6364>
    632c:      	mov	w9, #-0x30              // =-48
    6330:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6334:      	ldr	x8, [x21, #0xff0]
    6338:      	cbz	x8, 0x6374 <perf_unwind_dotnet+0x6374>
    633c:      	mov	w9, #-0x20              // =-32
    6340:      	b	0x687c <perf_unwind_dotnet+0x687c>
    6344:      	ldr	x8, [x21, #0xfc0]
    6348:      	cbz	x8, 0x6384 <perf_unwind_dotnet+0x6384>
    634c:      	mov	w9, #-0x14              // =-20
    6350:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    6354:      	ldr	x8, [x21, #0xf90]
    6358:      	cbz	x8, 0x6394 <perf_unwind_dotnet+0x6394>
    635c:      	mov	w9, #-0x8               // =-8
    6360:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    6364:      	ldr	x8, [x21, #0x1028]
    6368:      	cbz	x8, 0x63a4 <perf_unwind_dotnet+0x63a4>
    636c:      	mov	w9, #-0x2e              // =-46
    6370:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6374:      	ldr	x8, [x21, #0xfe8]
    6378:      	cbz	x8, 0x63b4 <perf_unwind_dotnet+0x63b4>
    637c:      	mov	w9, #-0x1e              // =-30
    6380:      	b	0x687c <perf_unwind_dotnet+0x687c>
    6384:      	ldr	x8, [x21, #0xfb8]
    6388:      	cbz	x8, 0x63c4 <perf_unwind_dotnet+0x63c4>
    638c:      	mov	w9, #-0x12              // =-18
    6390:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    6394:      	ldr	x8, [x21, #0xf88]
    6398:      	cbz	x8, 0x63d4 <perf_unwind_dotnet+0x63d4>
    639c:      	mov	w9, #-0x6               // =-6
    63a0:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    63a4:      	ldr	x8, [x21, #0x1020]
    63a8:      	cbz	x8, 0x63e4 <perf_unwind_dotnet+0x63e4>
    63ac:      	mov	w9, #-0x2c              // =-44
    63b0:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    63b4:      	ldr	x8, [x21, #0xfe0]
    63b8:      	cbz	x8, 0x63f4 <perf_unwind_dotnet+0x63f4>
    63bc:      	mov	w9, #-0x1c              // =-28
    63c0:      	b	0x687c <perf_unwind_dotnet+0x687c>
    63c4:      	ldr	x8, [x21, #0xfb0]
    63c8:      	cbz	x8, 0x6404 <perf_unwind_dotnet+0x6404>
    63cc:      	mov	w9, #-0x10              // =-16
    63d0:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    63d4:      	ldr	x8, [x21, #0xf80]
    63d8:      	cbz	x8, 0x6414 <perf_unwind_dotnet+0x6414>
    63dc:      	mov	w9, #-0x4               // =-4
    63e0:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    63e4:      	ldr	x8, [x21, #0x1018]
    63e8:      	cbz	x8, 0x6424 <perf_unwind_dotnet+0x6424>
    63ec:      	mov	w9, #-0x2a              // =-42
    63f0:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    63f4:      	ldr	x8, [x21, #0xfd8]
    63f8:      	cbz	x8, 0x6434 <perf_unwind_dotnet+0x6434>
    63fc:      	mov	w9, #-0x1a              // =-26
    6400:      	b	0x687c <perf_unwind_dotnet+0x687c>
    6404:      	ldr	x8, [x21, #0xfa8]
    6408:      	cbz	x8, 0x6444 <perf_unwind_dotnet+0x6444>
    640c:      	mov	w9, #-0xe               // =-14
    6410:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    6414:      	ldr	x8, [x21, #0xf78]
    6418:      	cbz	x8, 0x6454 <perf_unwind_dotnet+0x6454>
    641c:      	mov	w9, #-0x2               // =-2
    6420:      	b	0x6460 <perf_unwind_dotnet+0x6460>
    6424:      	ldr	x8, [x21, #0x1010]
    6428:      	cbz	x8, 0x66a0 <perf_unwind_dotnet+0x66a0>
    642c:      	mov	w9, #-0x28              // =-40
    6430:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6434:      	ldr	x8, [x21, #0xfd0]
    6438:      	cbz	x8, 0x66b0 <perf_unwind_dotnet+0x66b0>
    643c:      	mov	w9, #-0x18              // =-24
    6440:      	b	0x687c <perf_unwind_dotnet+0x687c>
    6444:      	ldr	x8, [x21, #0xfa0]
    6448:      	cbz	x8, 0x66c0 <perf_unwind_dotnet+0x66c0>
    644c:      	mov	w9, #-0xc               // =-12
    6450:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    6454:      	ldr	x8, [sp, #0x18]
    6458:      	mov	w9, wzr
    645c:      	ldr	x8, [x8]
    6460:      	lsr	x10, x8, #32
    6464:      	cmp	x10, #0x0
    6468:      	cset	w11, ne
    646c:      	csel	w25, w10, w8, ne
    6470:      	sub	w8, w9, w11
    6474:      	add	w3, w8, #0x7e
    6478:      	lsl	w8, w3, #8
    647c:      	subs	x29, x23, x8
    6480:      	b.hs	0x651c <perf_unwind_dotnet+0x651c>
    6484:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6488:      	ldr	x8, [x8]
    648c:      	ldr	w8, [x8]
    6490:      	cbz	w8, 0x1e10 <perf_unwind_dotnet+0x1e10>
    6494:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6498:      	add	x8, x8, #0x0
    649c:      	add	x0, sp, #0x20
    64a0:      	ldp	x9, x10, [x8, #0x10]
    64a4:      	mov	w1, #0x2e               // =46
    64a8:      	stp	x9, x10, [sp, #0x30]
    64ac:      	ldr	x9, [x8, #0x20]
    64b0:      	add	x10, sp, #0x20
    64b4:      	str	x9, [sp, #0x40]
    64b8:      	ldur	x9, [x8, #0x26]
    64bc:      	stur	x9, [sp, #0x46]
    64c0:      	ldp	x9, x8, [x8]
    64c4:      	stp	x9, x8, [sp, #0x20]
    64c8:      	mov	w8, #0x2e               // =46
    64cc:      	mov	w9, #0x6                // =6
    64d0:      	blr	x9
    64d4:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    64d8:      	ldr	x8, [x8]
    64dc:      	ldr	w8, [x8]
    64e0:      	cbz	w8, 0x1e10 <perf_unwind_dotnet+0x1e10>
    64e4:      	mov	w8, #0x646e             // =25710
    64e8:      	add	x10, sp, #0x20
    64ec:      	add	x0, sp, #0x20
    64f0:      	mov	w1, #0x13               // =19
    64f4:      	movk	w8, #0xa, lsl #16
    64f8:      	stur	w8, [sp, #0x2f]
    64fc:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6500:      	add	x8, x8, #0x0
    6504:      	ldp	x9, x8, [x8]
    6508:      	stp	x9, x8, [sp, #0x20]
    650c:      	mov	w8, #0x13               // =19
    6510:      	mov	w9, #0x6                // =6
    6514:      	blr	x9
    6518:      	b	0x1e10 <perf_unwind_dotnet+0x1e10>
    651c:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6520:      	ldr	x8, [x8]
    6524:      	ldr	w8, [x8]
    6528:      	cbnz	w8, 0x65e4 <perf_unwind_dotnet+0x65e4>
    652c:      	cbnz	w25, 0x1e84 <perf_unwind_dotnet+0x1e84>
    6530:      	mov	w8, #0x5f               // =95
    6534:      	adrp	x0, 0x6000 <perf_unwind_dotnet+0x6000>
    6538:      	add	x9, sp, #0x8c
    653c:      	str	w8, [sp, #0x8c]
    6540:      	mov	w8, #0x1                // =1
    6544:      	add	x1, sp, #0x8c
    6548:      	ldr	x0, [x0]
    654c:      	blr	x8
    6550:      	cbz	x0, 0x657c <perf_unwind_dotnet+0x657c>
    6554:      	ldr	x8, [x0]
    6558:      	add	x8, x8, #0x1
    655c:      	str	x8, [x0]
    6560:      	mov	w2, #0x1773             // =6003
    6564:      	mov	w22, #0x1               // =1
    6568:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    656c:      	ldr	x8, [x8]
    6570:      	ldr	w8, [x8]
    6574:      	cbz	w8, 0x1ec4 <perf_unwind_dotnet+0x1ec4>
    6578:      	b	0x65a4 <perf_unwind_dotnet+0x65a4>
    657c:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6580:      	ldr	x8, [x8]
    6584:      	ldr	w8, [x8]
    6588:      	cbnz	w8, 0x6640 <perf_unwind_dotnet+0x6640>
    658c:      	mov	w2, #0x1773             // =6003
    6590:      	mov	w22, #0x1               // =1
    6594:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6598:      	ldr	x8, [x8]
    659c:      	ldr	w8, [x8]
    65a0:      	cbz	w8, 0x1ec4 <perf_unwind_dotnet+0x1ec4>
    65a4:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    65a8:      	add	x8, x8, #0x0
    65ac:      	add	x0, sp, #0x20
    65b0:      	ldp	x9, x10, [x8, #0x10]
    65b4:      	mov	w1, #0x28               // =40
    65b8:      	stp	x9, x10, [sp, #0x30]
    65bc:      	ldr	x9, [x8, #0x20]
    65c0:      	add	x10, sp, #0x20
    65c4:      	str	x9, [sp, #0x40]
    65c8:      	ldp	x8, x9, [x8]
    65cc:      	stp	x8, x9, [sp, #0x20]
    65d0:      	mov	w8, #0x28               // =40
    65d4:      	mov	w9, #0x6                // =6
    65d8:      	blr	x9
    65dc:      	cbnz	w22, 0x1ec8 <perf_unwind_dotnet+0x1ec8>
    65e0:      	b	0x621c <perf_unwind_dotnet+0x621c>
    65e4:      	mov	w8, #0x7825             // =30757
    65e8:      	add	x0, sp, #0x20
    65ec:      	mov	w1, #0x3c               // =60
    65f0:      	mov	x2, x29
    65f4:      	mov	w4, w25
    65f8:      	movk	w8, #0xa, lsl #16
    65fc:      	str	w8, [sp, #0x58]
    6600:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6604:      	add	x8, x8, #0x0
    6608:      	ldp	x9, x10, [x8, #0x20]
    660c:      	stp	x9, x10, [sp, #0x40]
    6610:      	ldr	x9, [x8, #0x30]
    6614:      	str	x9, [sp, #0x50]
    6618:      	ldp	x9, x10, [x8]
    661c:      	stp	x9, x10, [sp, #0x20]
    6620:      	add	x10, sp, #0x20
    6624:      	ldp	x8, x9, [x8, #0x10]
    6628:      	stp	x8, x9, [sp, #0x30]
    662c:      	mov	w8, #0x3c               // =60
    6630:      	mov	w9, #0x6                // =6
    6634:      	blr	x9
    6638:      	cbnz	w25, 0x1e84 <perf_unwind_dotnet+0x1e84>
    663c:      	b	0x6530 <perf_unwind_dotnet+0x6530>
    6640:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6644:      	add	x8, x8, #0x0
    6648:      	add	x0, sp, #0x20
    664c:      	ldp	x9, x10, [x8, #0x10]
    6650:      	mov	w1, #0x2e               // =46
    6654:      	stp	x9, x10, [sp, #0x30]
    6658:      	ldr	x9, [x8, #0x20]
    665c:      	add	x10, sp, #0x20
    6660:      	str	x9, [sp, #0x40]
    6664:      	ldur	x9, [x8, #0x26]
    6668:      	stur	x9, [sp, #0x46]
    666c:      	ldp	x9, x8, [x8]
    6670:      	stp	x9, x8, [sp, #0x20]
    6674:      	mov	w8, #0x2e               // =46
    6678:      	mov	w9, #0x6                // =6
    667c:      	ldr	w2, [sp, #0x8c]
    6680:      	blr	x9
    6684:      	mov	w2, #0x1773             // =6003
    6688:      	mov	w22, #0x1               // =1
    668c:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6690:      	ldr	x8, [x8]
    6694:      	ldr	w8, [x8]
    6698:      	cbz	w8, 0x1ec4 <perf_unwind_dotnet+0x1ec4>
    669c:      	b	0x65a4 <perf_unwind_dotnet+0x65a4>
    66a0:      	ldr	x8, [x21, #0x1008]
    66a4:      	cbz	x8, 0x66d0 <perf_unwind_dotnet+0x66d0>
    66a8:      	mov	w9, #-0x26              // =-38
    66ac:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    66b0:      	ldr	x8, [x21, #0xfc8]
    66b4:      	cbz	x8, 0x66e0 <perf_unwind_dotnet+0x66e0>
    66b8:      	mov	w9, #-0x16              // =-22
    66bc:      	b	0x687c <perf_unwind_dotnet+0x687c>
    66c0:      	ldr	x8, [x21, #0xf98]
    66c4:      	cbz	x8, 0x66f0 <perf_unwind_dotnet+0x66f0>
    66c8:      	mov	w9, #-0xa               // =-10
    66cc:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    66d0:      	ldr	x8, [x21, #0x1000]
    66d4:      	cbz	x8, 0x6700 <perf_unwind_dotnet+0x6700>
    66d8:      	mov	w9, #-0x24              // =-36
    66dc:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    66e0:      	ldr	x8, [x21, #0xfc0]
    66e4:      	cbz	x8, 0x6710 <perf_unwind_dotnet+0x6710>
    66e8:      	mov	w9, #-0x14              // =-20
    66ec:      	b	0x687c <perf_unwind_dotnet+0x687c>
    66f0:      	ldr	x8, [x21, #0xf90]
    66f4:      	cbz	x8, 0x6720 <perf_unwind_dotnet+0x6720>
    66f8:      	mov	w9, #-0x8               // =-8
    66fc:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    6700:      	ldr	x8, [x21, #0xff8]
    6704:      	cbz	x8, 0x6730 <perf_unwind_dotnet+0x6730>
    6708:      	mov	w9, #-0x22              // =-34
    670c:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6710:      	ldr	x8, [x21, #0xfb8]
    6714:      	cbz	x8, 0x6740 <perf_unwind_dotnet+0x6740>
    6718:      	mov	w9, #-0x12              // =-18
    671c:      	b	0x687c <perf_unwind_dotnet+0x687c>
    6720:      	ldr	x8, [x21, #0xf88]
    6724:      	cbz	x8, 0x6750 <perf_unwind_dotnet+0x6750>
    6728:      	mov	w9, #-0x6               // =-6
    672c:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    6730:      	ldr	x8, [x21, #0xff0]
    6734:      	cbz	x8, 0x6760 <perf_unwind_dotnet+0x6760>
    6738:      	mov	w9, #-0x20              // =-32
    673c:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6740:      	ldr	x8, [x21, #0xfb0]
    6744:      	cbz	x8, 0x6770 <perf_unwind_dotnet+0x6770>
    6748:      	mov	w9, #-0x10              // =-16
    674c:      	b	0x687c <perf_unwind_dotnet+0x687c>
    6750:      	ldr	x8, [x21, #0xf80]
    6754:      	cbz	x8, 0x6780 <perf_unwind_dotnet+0x6780>
    6758:      	mov	w9, #-0x4               // =-4
    675c:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    6760:      	ldr	x8, [x21, #0xfe8]
    6764:      	cbz	x8, 0x6790 <perf_unwind_dotnet+0x6790>
    6768:      	mov	w9, #-0x1e              // =-30
    676c:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6770:      	ldr	x8, [x21, #0xfa8]
    6774:      	cbz	x8, 0x67a0 <perf_unwind_dotnet+0x67a0>
    6778:      	mov	w9, #-0xe               // =-14
    677c:      	b	0x687c <perf_unwind_dotnet+0x687c>
    6780:      	ldr	x8, [x21, #0xf78]
    6784:      	cbz	x8, 0x67b0 <perf_unwind_dotnet+0x67b0>
    6788:      	mov	w9, #-0x2               // =-2
    678c:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    6790:      	ldr	x8, [x21, #0xfe0]
    6794:      	cbz	x8, 0x67c0 <perf_unwind_dotnet+0x67c0>
    6798:      	mov	w9, #-0x1c              // =-28
    679c:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    67a0:      	ldr	x8, [x21, #0xfa0]
    67a4:      	cbz	x8, 0x67d0 <perf_unwind_dotnet+0x67d0>
    67a8:      	mov	w9, #-0xc               // =-12
    67ac:      	b	0x687c <perf_unwind_dotnet+0x687c>
    67b0:      	ldr	x8, [sp, #0x18]
    67b4:      	mov	w9, wzr
    67b8:      	ldr	x8, [x8]
    67bc:      	b	0x3e44 <perf_unwind_dotnet+0x3e44>
    67c0:      	ldr	x8, [x21, #0xfd8]
    67c4:      	cbz	x8, 0x67e0 <perf_unwind_dotnet+0x67e0>
    67c8:      	mov	w9, #-0x1a              // =-26
    67cc:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    67d0:      	ldr	x8, [x21, #0xf98]
    67d4:      	cbz	x8, 0x67f0 <perf_unwind_dotnet+0x67f0>
    67d8:      	mov	w9, #-0xa               // =-10
    67dc:      	b	0x687c <perf_unwind_dotnet+0x687c>
    67e0:      	ldr	x8, [x21, #0xfd0]
    67e4:      	cbz	x8, 0x6800 <perf_unwind_dotnet+0x6800>
    67e8:      	mov	w9, #-0x18              // =-24
    67ec:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    67f0:      	ldr	x8, [x21, #0xf90]
    67f4:      	cbz	x8, 0x6810 <perf_unwind_dotnet+0x6810>
    67f8:      	mov	w9, #-0x8               // =-8
    67fc:      	b	0x687c <perf_unwind_dotnet+0x687c>
    6800:      	ldr	x8, [x21, #0xfc8]
    6804:      	cbz	x8, 0x6820 <perf_unwind_dotnet+0x6820>
    6808:      	mov	w9, #-0x16              // =-22
    680c:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6810:      	ldr	x8, [x21, #0xf88]
    6814:      	cbz	x8, 0x6830 <perf_unwind_dotnet+0x6830>
    6818:      	mov	w9, #-0x6               // =-6
    681c:      	b	0x687c <perf_unwind_dotnet+0x687c>
    6820:      	ldr	x8, [x21, #0xfc0]
    6824:      	cbz	x8, 0x6840 <perf_unwind_dotnet+0x6840>
    6828:      	mov	w9, #-0x14              // =-20
    682c:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6830:      	ldr	x8, [x21, #0xf80]
    6834:      	cbz	x8, 0x6850 <perf_unwind_dotnet+0x6850>
    6838:      	mov	w9, #-0x4               // =-4
    683c:      	b	0x687c <perf_unwind_dotnet+0x687c>
    6840:      	ldr	x8, [x21, #0xfb8]
    6844:      	cbz	x8, 0x6860 <perf_unwind_dotnet+0x6860>
    6848:      	mov	w9, #-0x12              // =-18
    684c:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6850:      	ldr	x8, [x21, #0xf78]
    6854:      	cbz	x8, 0x6870 <perf_unwind_dotnet+0x6870>
    6858:      	mov	w9, #-0x2               // =-2
    685c:      	b	0x687c <perf_unwind_dotnet+0x687c>
    6860:      	ldr	x8, [x21, #0xfb0]
    6864:      	cbz	x8, 0x6a5c <perf_unwind_dotnet+0x6a5c>
    6868:      	mov	w9, #-0x10              // =-16
    686c:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6870:      	ldr	x8, [sp, #0x18]
    6874:      	mov	w9, wzr
    6878:      	ldr	x8, [x8]
    687c:      	lsr	x10, x8, #32
    6880:      	cmp	x10, #0x0
    6884:      	cset	w11, ne
    6888:      	csel	w25, w10, w8, ne
    688c:      	sub	w8, w9, w11
    6890:      	add	w3, w8, #0x7e
    6894:      	lsl	w8, w3, #8
    6898:      	subs	x29, x23, x8
    689c:      	b.hs	0x6938 <perf_unwind_dotnet+0x6938>
    68a0:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    68a4:      	ldr	x8, [x8]
    68a8:      	ldr	w8, [x8]
    68ac:      	cbz	w8, 0x35d0 <perf_unwind_dotnet+0x35d0>
    68b0:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    68b4:      	add	x8, x8, #0x0
    68b8:      	add	x0, sp, #0x20
    68bc:      	ldp	x9, x10, [x8, #0x10]
    68c0:      	mov	w1, #0x2e               // =46
    68c4:      	stp	x9, x10, [sp, #0x30]
    68c8:      	ldr	x9, [x8, #0x20]
    68cc:      	add	x10, sp, #0x20
    68d0:      	str	x9, [sp, #0x40]
    68d4:      	ldur	x9, [x8, #0x26]
    68d8:      	stur	x9, [sp, #0x46]
    68dc:      	ldp	x9, x8, [x8]
    68e0:      	stp	x9, x8, [sp, #0x20]
    68e4:      	mov	w8, #0x2e               // =46
    68e8:      	mov	w9, #0x6                // =6
    68ec:      	blr	x9
    68f0:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    68f4:      	ldr	x8, [x8]
    68f8:      	ldr	w8, [x8]
    68fc:      	cbz	w8, 0x35d0 <perf_unwind_dotnet+0x35d0>
    6900:      	mov	w8, #0x646e             // =25710
    6904:      	add	x10, sp, #0x20
    6908:      	add	x0, sp, #0x20
    690c:      	mov	w1, #0x13               // =19
    6910:      	movk	w8, #0xa, lsl #16
    6914:      	stur	w8, [sp, #0x2f]
    6918:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    691c:      	add	x8, x8, #0x0
    6920:      	ldp	x9, x8, [x8]
    6924:      	stp	x9, x8, [sp, #0x20]
    6928:      	mov	w8, #0x13               // =19
    692c:      	mov	w9, #0x6                // =6
    6930:      	blr	x9
    6934:      	b	0x35d0 <perf_unwind_dotnet+0x35d0>
    6938:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    693c:      	ldr	x8, [x8]
    6940:      	ldr	w8, [x8]
    6944:      	cbnz	w8, 0x6a00 <perf_unwind_dotnet+0x6a00>
    6948:      	cbnz	w25, 0x3644 <perf_unwind_dotnet+0x3644>
    694c:      	mov	w8, #0x5f               // =95
    6950:      	adrp	x0, 0x6000 <perf_unwind_dotnet+0x6000>
    6954:      	add	x9, sp, #0x8c
    6958:      	str	w8, [sp, #0x8c]
    695c:      	mov	w8, #0x1                // =1
    6960:      	add	x1, sp, #0x8c
    6964:      	ldr	x0, [x0]
    6968:      	blr	x8
    696c:      	cbz	x0, 0x6998 <perf_unwind_dotnet+0x6998>
    6970:      	ldr	x8, [x0]
    6974:      	add	x8, x8, #0x1
    6978:      	str	x8, [x0]
    697c:      	mov	w2, #0x1773             // =6003
    6980:      	mov	w22, #0x1               // =1
    6984:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6988:      	ldr	x8, [x8]
    698c:      	ldr	w8, [x8]
    6990:      	cbz	w8, 0x3684 <perf_unwind_dotnet+0x3684>
    6994:      	b	0x69c0 <perf_unwind_dotnet+0x69c0>
    6998:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    699c:      	ldr	x8, [x8]
    69a0:      	ldr	w8, [x8]
    69a4:      	cbnz	w8, 0x6a6c <perf_unwind_dotnet+0x6a6c>
    69a8:      	mov	w2, #0x1773             // =6003
    69ac:      	mov	w22, #0x1               // =1
    69b0:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    69b4:      	ldr	x8, [x8]
    69b8:      	ldr	w8, [x8]
    69bc:      	cbz	w8, 0x3684 <perf_unwind_dotnet+0x3684>
    69c0:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    69c4:      	add	x8, x8, #0x0
    69c8:      	add	x0, sp, #0x20
    69cc:      	ldp	x9, x10, [x8, #0x10]
    69d0:      	mov	w1, #0x28               // =40
    69d4:      	stp	x9, x10, [sp, #0x30]
    69d8:      	ldr	x9, [x8, #0x20]
    69dc:      	add	x10, sp, #0x20
    69e0:      	str	x9, [sp, #0x40]
    69e4:      	ldp	x8, x9, [x8]
    69e8:      	stp	x8, x9, [sp, #0x20]
    69ec:      	mov	w8, #0x28               // =40
    69f0:      	mov	w9, #0x6                // =6
    69f4:      	blr	x9
    69f8:      	cbnz	w22, 0x3688 <perf_unwind_dotnet+0x3688>
    69fc:      	b	0x621c <perf_unwind_dotnet+0x621c>
    6a00:      	mov	w8, #0x7825             // =30757
    6a04:      	add	x0, sp, #0x20
    6a08:      	mov	w1, #0x3c               // =60
    6a0c:      	mov	x2, x29
    6a10:      	mov	w4, w25
    6a14:      	movk	w8, #0xa, lsl #16
    6a18:      	str	w8, [sp, #0x58]
    6a1c:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6a20:      	add	x8, x8, #0x0
    6a24:      	ldp	x9, x10, [x8, #0x20]
    6a28:      	stp	x9, x10, [sp, #0x40]
    6a2c:      	ldr	x9, [x8, #0x30]
    6a30:      	str	x9, [sp, #0x50]
    6a34:      	ldp	x9, x10, [x8]
    6a38:      	stp	x9, x10, [sp, #0x20]
    6a3c:      	add	x10, sp, #0x20
    6a40:      	ldp	x8, x9, [x8, #0x10]
    6a44:      	stp	x8, x9, [sp, #0x30]
    6a48:      	mov	w8, #0x3c               // =60
    6a4c:      	mov	w9, #0x6                // =6
    6a50:      	blr	x9
    6a54:      	cbnz	w25, 0x3644 <perf_unwind_dotnet+0x3644>
    6a58:      	b	0x694c <perf_unwind_dotnet+0x694c>
    6a5c:      	ldr	x8, [x21, #0xfa8]
    6a60:      	cbz	x8, 0x6acc <perf_unwind_dotnet+0x6acc>
    6a64:      	mov	w9, #-0xe               // =-14
    6a68:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6a6c:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6a70:      	add	x8, x8, #0x0
    6a74:      	add	x0, sp, #0x20
    6a78:      	ldp	x9, x10, [x8, #0x10]
    6a7c:      	mov	w1, #0x2e               // =46
    6a80:      	stp	x9, x10, [sp, #0x30]
    6a84:      	ldr	x9, [x8, #0x20]
    6a88:      	add	x10, sp, #0x20
    6a8c:      	str	x9, [sp, #0x40]
    6a90:      	ldur	x9, [x8, #0x26]
    6a94:      	stur	x9, [sp, #0x46]
    6a98:      	ldp	x9, x8, [x8]
    6a9c:      	stp	x9, x8, [sp, #0x20]
    6aa0:      	mov	w8, #0x2e               // =46
    6aa4:      	mov	w9, #0x6                // =6
    6aa8:      	ldr	w2, [sp, #0x8c]
    6aac:      	blr	x9
    6ab0:      	mov	w2, #0x1773             // =6003
    6ab4:      	mov	w22, #0x1               // =1
    6ab8:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6abc:      	ldr	x8, [x8]
    6ac0:      	ldr	w8, [x8]
    6ac4:      	cbz	w8, 0x3684 <perf_unwind_dotnet+0x3684>
    6ac8:      	b	0x69c0 <perf_unwind_dotnet+0x69c0>
    6acc:      	ldr	x8, [x21, #0xfa0]
    6ad0:      	cbz	x8, 0x6adc <perf_unwind_dotnet+0x6adc>
    6ad4:      	mov	w9, #-0xc               // =-12
    6ad8:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6adc:      	ldr	x8, [x21, #0xf98]
    6ae0:      	cbz	x8, 0x6aec <perf_unwind_dotnet+0x6aec>
    6ae4:      	mov	w9, #-0xa               // =-10
    6ae8:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6aec:      	ldr	x8, [x21, #0xf90]
    6af0:      	cbz	x8, 0x6afc <perf_unwind_dotnet+0x6afc>
    6af4:      	mov	w9, #-0x8               // =-8
    6af8:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6afc:      	ldr	x8, [x21, #0xf88]
    6b00:      	cbz	x8, 0x6b0c <perf_unwind_dotnet+0x6b0c>
    6b04:      	mov	w9, #-0x6               // =-6
    6b08:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6b0c:      	ldr	x8, [x21, #0xf80]
    6b10:      	cbz	x8, 0x6b1c <perf_unwind_dotnet+0x6b1c>
    6b14:      	mov	w9, #-0x4               // =-4
    6b18:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6b1c:      	ldr	x8, [x21, #0xf78]
    6b20:      	cbz	x8, 0x6b2c <perf_unwind_dotnet+0x6b2c>
    6b24:      	mov	w9, #-0x2               // =-2
    6b28:      	b	0x6b38 <perf_unwind_dotnet+0x6b38>
    6b2c:      	ldr	x8, [sp, #0x18]
    6b30:      	mov	w9, wzr
    6b34:      	ldr	x8, [x8]
    6b38:      	lsr	x10, x8, #32
    6b3c:      	cmp	x10, #0x0
    6b40:      	cset	w11, ne
    6b44:      	csel	w25, w10, w8, ne
    6b48:      	sub	w8, w9, w11
    6b4c:      	add	w3, w8, #0x7e
    6b50:      	lsl	w8, w3, #8
    6b54:      	subs	x29, x23, x8
    6b58:      	b.hs	0x6bf4 <perf_unwind_dotnet+0x6bf4>
    6b5c:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6b60:      	ldr	x8, [x8]
    6b64:      	ldr	w8, [x8]
    6b68:      	cbz	w8, 0x443c <perf_unwind_dotnet+0x443c>
    6b6c:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6b70:      	add	x8, x8, #0x0
    6b74:      	add	x0, sp, #0x20
    6b78:      	ldp	x9, x10, [x8, #0x10]
    6b7c:      	mov	w1, #0x2e               // =46
    6b80:      	stp	x9, x10, [sp, #0x30]
    6b84:      	ldr	x9, [x8, #0x20]
    6b88:      	add	x10, sp, #0x20
    6b8c:      	str	x9, [sp, #0x40]
    6b90:      	ldur	x9, [x8, #0x26]
    6b94:      	stur	x9, [sp, #0x46]
    6b98:      	ldp	x9, x8, [x8]
    6b9c:      	stp	x9, x8, [sp, #0x20]
    6ba0:      	mov	w8, #0x2e               // =46
    6ba4:      	mov	w9, #0x6                // =6
    6ba8:      	blr	x9
    6bac:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6bb0:      	ldr	x8, [x8]
    6bb4:      	ldr	w8, [x8]
    6bb8:      	cbz	w8, 0x443c <perf_unwind_dotnet+0x443c>
    6bbc:      	mov	w8, #0x646e             // =25710
    6bc0:      	add	x10, sp, #0x20
    6bc4:      	add	x0, sp, #0x20
    6bc8:      	mov	w1, #0x13               // =19
    6bcc:      	movk	w8, #0xa, lsl #16
    6bd0:      	stur	w8, [sp, #0x2f]
    6bd4:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6bd8:      	add	x8, x8, #0x0
    6bdc:      	ldp	x9, x8, [x8]
    6be0:      	stp	x9, x8, [sp, #0x20]
    6be4:      	mov	w8, #0x13               // =19
    6be8:      	mov	w9, #0x6                // =6
    6bec:      	blr	x9
    6bf0:      	b	0x443c <perf_unwind_dotnet+0x443c>
    6bf4:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6bf8:      	ldr	x8, [x8]
    6bfc:      	ldr	w8, [x8]
    6c00:      	cbnz	w8, 0x6ce8 <perf_unwind_dotnet+0x6ce8>
    6c04:      	cbnz	w25, 0x44b0 <perf_unwind_dotnet+0x44b0>
    6c08:      	mov	w8, #0x5f               // =95
    6c0c:      	adrp	x0, 0x6000 <perf_unwind_dotnet+0x6000>
    6c10:      	add	x9, sp, #0x8c
    6c14:      	str	w8, [sp, #0x8c]
    6c18:      	mov	w8, #0x1                // =1
    6c1c:      	add	x1, sp, #0x8c
    6c20:      	ldr	x0, [x0]
    6c24:      	blr	x8
    6c28:      	cbz	x0, 0x6c3c <perf_unwind_dotnet+0x6c3c>
    6c2c:      	ldr	x8, [x0]
    6c30:      	add	x8, x8, #0x1
    6c34:      	str	x8, [x0]
    6c38:      	b	0x6c90 <perf_unwind_dotnet+0x6c90>
    6c3c:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6c40:      	ldr	x8, [x8]
    6c44:      	ldr	w8, [x8]
    6c48:      	cbz	w8, 0x6c90 <perf_unwind_dotnet+0x6c90>
    6c4c:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6c50:      	add	x8, x8, #0x0
    6c54:      	add	x0, sp, #0x20
    6c58:      	ldp	x9, x10, [x8, #0x10]
    6c5c:      	mov	w1, #0x2e               // =46
    6c60:      	stp	x9, x10, [sp, #0x30]
    6c64:      	ldr	x9, [x8, #0x20]
    6c68:      	add	x10, sp, #0x20
    6c6c:      	str	x9, [sp, #0x40]
    6c70:      	ldur	x9, [x8, #0x26]
    6c74:      	stur	x9, [sp, #0x46]
    6c78:      	ldp	x9, x8, [x8]
    6c7c:      	stp	x9, x8, [sp, #0x20]
    6c80:      	mov	w8, #0x2e               // =46
    6c84:      	mov	w9, #0x6                // =6
    6c88:      	ldr	w2, [sp, #0x8c]
    6c8c:      	blr	x9
    6c90:      	mov	w2, #0x1773             // =6003
    6c94:      	mov	w22, #0x1               // =1
    6c98:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6c9c:      	ldr	x8, [x8]
    6ca0:      	ldr	w8, [x8]
    6ca4:      	cbz	w8, 0x44f0 <perf_unwind_dotnet+0x44f0>
    6ca8:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6cac:      	add	x8, x8, #0x0
    6cb0:      	add	x0, sp, #0x20
    6cb4:      	ldp	x9, x10, [x8, #0x10]
    6cb8:      	mov	w1, #0x28               // =40
    6cbc:      	stp	x9, x10, [sp, #0x30]
    6cc0:      	ldr	x9, [x8, #0x20]
    6cc4:      	add	x10, sp, #0x20
    6cc8:      	str	x9, [sp, #0x40]
    6ccc:      	ldp	x8, x9, [x8]
    6cd0:      	stp	x8, x9, [sp, #0x20]
    6cd4:      	mov	w8, #0x28               // =40
    6cd8:      	mov	w9, #0x6                // =6
    6cdc:      	blr	x9
    6ce0:      	cbnz	w22, 0x44f4 <perf_unwind_dotnet+0x44f4>
    6ce4:      	b	0x621c <perf_unwind_dotnet+0x621c>
    6ce8:      	mov	w8, #0x7825             // =30757
    6cec:      	add	x0, sp, #0x20
    6cf0:      	mov	w1, #0x3c               // =60
    6cf4:      	mov	x2, x29
    6cf8:      	mov	w4, w25
    6cfc:      	movk	w8, #0xa, lsl #16
    6d00:      	str	w8, [sp, #0x58]
    6d04:      	adrp	x8, 0x6000 <perf_unwind_dotnet+0x6000>
    6d08:      	add	x8, x8, #0x0
    6d0c:      	ldp	x9, x10, [x8, #0x20]
    6d10:      	stp	x9, x10, [sp, #0x40]
    6d14:      	ldr	x9, [x8, #0x30]
    6d18:      	str	x9, [sp, #0x50]
    6d1c:      	ldp	x9, x10, [x8]
    6d20:      	stp	x9, x10, [sp, #0x20]
    6d24:      	add	x10, sp, #0x20
    6d28:      	ldp	x8, x9, [x8, #0x10]
    6d2c:      	stp	x8, x9, [sp, #0x30]
    6d30:      	mov	w8, #0x3c               // =60
    6d34:      	mov	w9, #0x6                // =6
    6d38:      	blr	x9
    6d3c:      	cbnz	w25, 0x44b0 <perf_unwind_dotnet+0x44b0>
    6d40:      	b	0x6c08 <perf_unwind_dotnet+0x6c08>

Disassembly of section kprobe/unwind_dotnet:

0000000000000000 <kprobe_unwind_dotnet>:
       0:      	sub	sp, sp, #0xd0
       4:      	str	x29, [sp, #0x80]
       8:      	stp	x30, x25, [sp, #0x90]
       c:      	stp	x24, x23, [sp, #0xa0]
      10:      	stp	x22, x21, [sp, #0xb0]
      14:      	stp	x20, x19, [sp, #0xc0]
      18:      	str	wzr, [sp, #0x20]
      1c:      	adrp	x20, 0x0 <kprobe_unwind_dotnet>
      20:      	mov	w8, #0x1                // =1
      24:      	add	x9, sp, #0x20
      28:      	ldr	x20, [x20]
      2c:      	mov	x19, x0
      30:      	add	x1, sp, #0x20
      34:      	mov	x0, x20
      38:      	blr	x8
      3c:      	cbz	x0, 0x46f0 <kprobe_unwind_dotnet+0x46f0>
      40:      	ldr	w8, [x0]
      44:      	adrp	x23, 0x0 <kprobe_unwind_dotnet>
      48:      	mov	x21, x0
      4c:      	str	w8, [sp, #0x88]
      50:      	ldr	x23, [x23]
      54:      	ldr	w8, [x23]
      58:      	cbnz	w8, 0x538 <kprobe_unwind_dotnet+0x538>
      5c:      	adrp	x0, 0x0 <kprobe_unwind_dotnet>
      60:      	mov	w8, #0x1                // =1
      64:      	add	x9, sp, #0x88
      68:      	ldr	x0, [x0]
      6c:      	add	x1, sp, #0x88
      70:      	blr	x8
      74:      	adrp	x24, 0x0 <kprobe_unwind_dotnet>
      78:      	ldr	x24, [x24]
      7c:      	cbz	x0, 0x124 <kprobe_unwind_dotnet+0x124>
      80:      	mov	w8, #0x1375             // =4981
      84:      	mov	w9, #0x2                // =2
      88:      	add	x1, sp, #0x70
      8c:      	strb	w9, [x21, x8]
      90:      	mov	w8, #0x5a               // =90
      94:      	add	x9, sp, #0x70
      98:      	mov	x0, x24
      9c:      	str	w8, [sp, #0x70]
      a0:      	mov	w8, #0x1                // =1
      a4:      	blr	x8
      a8:      	cbz	x0, 0x15c <kprobe_unwind_dotnet+0x15c>
      ac:      	ldr	x8, [x0]
      b0:      	add	x8, x8, #0x1
      b4:      	str	x8, [x0]
      b8:      	ldr	x25, [x21, #0xed8]
      bc:      	ldr	x29, [x21, #0xee0]
      c0:      	ldr	x24, [x21, #0xed0]
      c4:      	ldrb	w22, [x21, #0xf20]
      c8:      	ldr	w8, [x23]
      cc:      	cbz	w8, 0x17c <kprobe_unwind_dotnet+0x17c>
      d0:      	mov	w8, #0x786c             // =30828
      d4:      	add	x0, sp, #0x20
      d8:      	mov	w1, #0x23               // =35
      dc:      	mov	x2, x24
      e0:      	mov	x3, x25
      e4:      	mov	x4, x29
      e8:      	movk	w8, #0xa, lsl #16
      ec:      	stur	w8, [sp, #0x3f]
      f0:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
      f4:      	add	x8, x8, #0x0
      f8:      	ldp	x9, x10, [x8]
      fc:      	stp	x9, x10, [sp, #0x20]
     100:      	ldp	x9, x8, [x8, #0x10]
     104:      	add	x10, sp, #0x20
     108:      	stp	x9, x8, [sp, #0x30]
     10c:      	mov	w8, #0x23               // =35
     110:      	mov	w9, #0x6                // =6
     114:      	blr	x9
     118:      	cmp	x29, x25
     11c:      	b.hs	0x184 <kprobe_unwind_dotnet+0x184>
     120:      	b	0x45d4 <kprobe_unwind_dotnet+0x45d4>
     124:      	ldr	w8, [x23]
     128:      	cbnz	w8, 0x58c <kprobe_unwind_dotnet+0x58c>
     12c:      	mov	w8, #0x5c               // =92
     130:      	add	x9, sp, #0x70
     134:      	add	x1, sp, #0x70
     138:      	str	w8, [sp, #0x70]
     13c:      	mov	w8, #0x1                // =1
     140:      	mov	x0, x24
     144:      	blr	x8
     148:      	cbz	x0, 0x2c4 <kprobe_unwind_dotnet+0x2c4>
     14c:      	ldr	x8, [x0]
     150:      	add	x8, x8, #0x1
     154:      	str	x8, [x0]
     158:      	b	0x2cc <kprobe_unwind_dotnet+0x2cc>
     15c:      	ldr	w8, [x23]
     160:      	cbnz	w8, 0x5d8 <kprobe_unwind_dotnet+0x5d8>
     164:      	ldr	x25, [x21, #0xed8]
     168:      	ldr	x29, [x21, #0xee0]
     16c:      	ldr	x24, [x21, #0xed0]
     170:      	ldrb	w22, [x21, #0xf20]
     174:      	ldr	w8, [x23]
     178:      	cbnz	w8, 0xd0 <kprobe_unwind_dotnet+0xd0>
     17c:      	cmp	x29, x25
     180:      	b.lo	0x45d4 <kprobe_unwind_dotnet+0x45d4>
     184:      	add	x8, x25, #0x2, lsl #12  // =0x2000
     188:      	cmp	x29, x8
     18c:      	b.hs	0x45d4 <kprobe_unwind_dotnet+0x45d4>
     190:      	ldr	x23, [x21, #0xf00]
     194:      	add	x8, x21, #0xf70
     198:      	ldr	x25, [x21, #0xf10]
     19c:      	add	x11, x21, #0xed0
     1a0:      	str	x24, [sp, #0x68]
     1a4:      	str	x8, [sp, #0x18]
     1a8:      	mov	w8, #0x101              // =257
     1ac:      	strh	w8, [x21, #0xf20]
     1b0:      	and	x8, x23, #0xffffffffffffff80
     1b4:      	cmp	x8, #0x80
     1b8:      	b.ne	0x258 <kprobe_unwind_dotnet+0x258>
     1bc:      	ldr	x8, [x21, #0xed8]
     1c0:      	mov	w9, #0x8                // =8
     1c4:      	mov	w10, #0x70              // =112
     1c8:      	mov	x0, x11
     1cc:      	ldr	x2, [x21, #0xed8]
     1d0:      	mov	w1, #0x8                // =8
     1d4:      	mov	x29, x11
     1d8:      	blr	x10
     1dc:      	cbz	x0, 0x2d8 <kprobe_unwind_dotnet+0x2d8>
     1e0:      	adrp	x23, 0x0 <kprobe_unwind_dotnet>
     1e4:      	ldr	x23, [x23]
     1e8:      	ldr	w8, [x23]
     1ec:      	cbnz	w8, 0x690 <kprobe_unwind_dotnet+0x690>
     1f0:      	mov	w8, #0x5d               // =93
     1f4:      	adrp	x24, 0x0 <kprobe_unwind_dotnet>
     1f8:      	add	x9, sp, #0x8c
     1fc:      	str	w8, [sp, #0x8c]
     200:      	mov	w8, #0x1                // =1
     204:      	add	x1, sp, #0x8c
     208:      	ldr	x24, [x24]
     20c:      	mov	x0, x24
     210:      	blr	x8
     214:      	cbnz	x0, 0x2b4 <kprobe_unwind_dotnet+0x2b4>
     218:      	ldr	w8, [x23]
     21c:      	cbz	w8, 0x424 <kprobe_unwind_dotnet+0x424>
     220:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     224:      	add	x8, x8, #0x0
     228:      	ldp	x9, x10, [x8, #0x10]
     22c:      	stp	x9, x10, [sp, #0x30]
     230:      	ldr	x9, [x8, #0x20]
     234:      	add	x10, sp, #0x20
     238:      	str	x9, [sp, #0x40]
     23c:      	ldur	x9, [x8, #0x26]
     240:      	stur	x9, [sp, #0x46]
     244:      	ldp	x9, x8, [x8]
     248:      	stp	x9, x8, [sp, #0x20]
     24c:      	mov	w8, #0x2e               // =46
     250:      	mov	w9, #0x6                // =6
     254:      	b	0x790 <kprobe_unwind_dotnet+0x790>
     258:      	str	x11, [sp, #0x10]
     25c:      	mov	w8, #0x10               // =16
     260:      	mov	w9, #0x70               // =112
     264:      	add	x10, sp, #0x70
     268:      	add	x0, sp, #0x70
     26c:      	mov	w1, #0x10               // =16
     270:      	mov	x2, x29
     274:      	blr	x9
     278:      	cbz	x0, 0x2f0 <kprobe_unwind_dotnet+0x2f0>
     27c:      	adrp	x23, 0x0 <kprobe_unwind_dotnet>
     280:      	ldr	x23, [x23]
     284:      	ldr	w8, [x23]
     288:      	cbnz	w8, 0x6c4 <kprobe_unwind_dotnet+0x6c4>
     28c:      	mov	w8, #0x5d               // =93
     290:      	adrp	x24, 0x0 <kprobe_unwind_dotnet>
     294:      	add	x9, sp, #0x8c
     298:      	str	w8, [sp, #0x8c]
     29c:      	mov	w8, #0x1                // =1
     2a0:      	add	x1, sp, #0x8c
     2a4:      	ldr	x24, [x24]
     2a8:      	mov	x0, x24
     2ac:      	blr	x8
     2b0:      	cbz	x0, 0x41c <kprobe_unwind_dotnet+0x41c>
     2b4:      	ldr	x8, [x0]
     2b8:      	add	x8, x8, #0x1
     2bc:      	str	x8, [x0]
     2c0:      	b	0x424 <kprobe_unwind_dotnet+0x424>
     2c4:      	ldr	w8, [x23]
     2c8:      	cbnz	w8, 0x638 <kprobe_unwind_dotnet+0x638>
     2cc:      	mov	w25, wzr
     2d0:      	mov	w8, #0x1770             // =6000
     2d4:      	b	0x4624 <kprobe_unwind_dotnet+0x4624>
     2d8:      	ldr	x8, [x21, #0xed8]
     2dc:      	and	x23, x23, #0x7f
     2e0:      	str	x29, [sp, #0x10]
     2e4:      	add	x8, x8, #0x8
     2e8:      	str	x8, [x21, #0xed8]
     2ec:      	b	0x888 <kprobe_unwind_dotnet+0x888>
     2f0:      	add	x8, x29, #0x10
     2f4:      	str	x8, [x21, #0xed8]
     2f8:      	ldp	x8, x9, [sp, #0x70]
     2fc:      	str	x8, [x21, #0xee0]
     300:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     304:      	str	x9, [x21, #0xed0]
     308:      	ldr	x8, [x8]
     30c:      	ldr	w8, [x8]
     310:      	cbnz	w8, 0x6f8 <kprobe_unwind_dotnet+0x6f8>
     314:      	cmp	x23, #0x100
     318:      	b.lo	0x888 <kprobe_unwind_dotnet+0x888>
     31c:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     320:      	ldr	x25, [x21, #0xf10]
     324:      	ldr	x23, [x21, #0xf00]
     328:      	sub	x29, x24, x25
     32c:      	ldr	x8, [x8]
     330:      	ldr	w8, [x8]
     334:      	cbnz	w8, 0x7a4 <kprobe_unwind_dotnet+0x7a4>
     338:      	lsr	x8, x29, #8
     33c:      	mov	w9, #0x7f               // =127
     340:      	lsr	x10, x29, #15
     344:      	mov	w1, #0x200              // =512
     348:      	sub	w9, w9, w8
     34c:      	lsl	x8, x8, #2
     350:      	cmp	x10, #0x0
     354:      	sub	x8, x8, #0x3fc
     358:      	and	x9, x9, #0x7f
     35c:      	csel	x8, x8, xzr, ne
     360:      	add	x2, x8, x23
     364:      	csel	x8, xzr, x9, ne
     368:      	ldr	x9, [sp, #0x18]
     36c:      	add	x0, x9, x8, lsl #2
     370:      	mov	w8, #0x200              // =512
     374:      	mov	w9, #0x70               // =112
     378:      	blr	x9
     37c:      	cbz	x0, 0x430 <kprobe_unwind_dotnet+0x430>
     380:      	adrp	x23, 0x0 <kprobe_unwind_dotnet>
     384:      	ldr	x23, [x23]
     388:      	ldr	w8, [x23]
     38c:      	cbnz	w8, 0x5d84 <kprobe_unwind_dotnet+0x5d84>
     390:      	mov	w8, #0x5e               // =94
     394:      	adrp	x24, 0x0 <kprobe_unwind_dotnet>
     398:      	add	x9, sp, #0x8c
     39c:      	str	w8, [sp, #0x8c]
     3a0:      	mov	w8, #0x1                // =1
     3a4:      	add	x1, sp, #0x8c
     3a8:      	ldr	x24, [x24]
     3ac:      	mov	x0, x24
     3b0:      	blr	x8
     3b4:      	cbz	x0, 0x470 <kprobe_unwind_dotnet+0x470>
     3b8:      	ldr	x8, [x0]
     3bc:      	add	x8, x8, #0x1
     3c0:      	str	x8, [x0]
     3c4:      	ldr	x11, [sp, #0x10]
     3c8:      	mov	w22, wzr
     3cc:      	mov	w2, #0x1772             // =6002
     3d0:      	ldr	w8, [x23]
     3d4:      	cbz	w8, 0x48c <kprobe_unwind_dotnet+0x48c>
     3d8:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     3dc:      	add	x8, x8, #0x0
     3e0:      	add	x0, sp, #0x20
     3e4:      	ldp	x9, x10, [x8, #0x10]
     3e8:      	mov	w1, #0x28               // =40
     3ec:      	stp	x9, x10, [sp, #0x30]
     3f0:      	ldr	x9, [x8, #0x20]
     3f4:      	add	x10, sp, #0x20
     3f8:      	str	x9, [sp, #0x40]
     3fc:      	ldp	x8, x9, [x8]
     400:      	stp	x8, x9, [sp, #0x20]
     404:      	mov	w8, #0x28               // =40
     408:      	mov	w9, #0x6                // =6
     40c:      	blr	x9
     410:      	ldr	x11, [sp, #0x10]
     414:      	cbnz	w22, 0x490 <kprobe_unwind_dotnet+0x490>
     418:      	b	0x908 <kprobe_unwind_dotnet+0x908>
     41c:      	ldr	w8, [x23]
     420:      	cbnz	w8, 0x75c <kprobe_unwind_dotnet+0x75c>
     424:      	mov	w8, #0x1771             // =6001
     428:      	mov	w25, wzr
     42c:      	b	0x4624 <kprobe_unwind_dotnet+0x4624>
     430:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     434:      	ldr	w23, [x21, #0x116c]
     438:      	ldr	x8, [x8]
     43c:      	ldr	w8, [x8]
     440:      	cbnz	w8, 0xc98 <kprobe_unwind_dotnet+0xc98>
     444:      	mov	w8, #0x1c               // =28
     448:      	bic	w8, w8, w29, lsr #3
     44c:      	lsr	w23, w23, w8
     450:      	cbz	w23, 0xcf0 <kprobe_unwind_dotnet+0xcf0>
     454:      	and	x29, x29, #0xffffffffffffffe0
     458:      	ands	w3, w23, #0xf
     45c:      	b.ne	0x804 <kprobe_unwind_dotnet+0x804>
     460:      	ubfx	w3, w23, #4, #4
     464:      	cbz	w3, 0x528 <kprobe_unwind_dotnet+0x528>
     468:      	sub	x29, x29, #0x20
     46c:      	b	0x804 <kprobe_unwind_dotnet+0x804>
     470:      	ldr	w8, [x23]
     474:      	ldr	x11, [sp, #0x10]
     478:      	cbnz	w8, 0xd64 <kprobe_unwind_dotnet+0xd64>
     47c:      	mov	w22, wzr
     480:      	mov	w2, #0x1772             // =6002
     484:      	ldr	w8, [x23]
     488:      	cbnz	w8, 0x3d8 <kprobe_unwind_dotnet+0x3d8>
     48c:      	cbz	w22, 0x908 <kprobe_unwind_dotnet+0x908>
     490:      	ldr	w8, [x21, #0x2c0]
     494:      	cmp	w8, #0x7f
     498:      	b.lo	0x4d4 <kprobe_unwind_dotnet+0x4d4>
     49c:      	ldr	w8, [x23]
     4a0:      	cbnz	w8, 0xdc0 <kprobe_unwind_dotnet+0xdc0>
     4a4:      	mov	w8, #0x2                // =2
     4a8:      	add	x9, sp, #0x8c
     4ac:      	add	x1, sp, #0x8c
     4b0:      	str	w8, [sp, #0x8c]
     4b4:      	mov	w8, #0x1                // =1
     4b8:      	mov	x0, x24
     4bc:      	blr	x8
     4c0:      	cbz	x0, 0x514 <kprobe_unwind_dotnet+0x514>
     4c4:      	ldr	x8, [x0]
     4c8:      	add	x8, x8, #0x1
     4cc:      	str	x8, [x0]
     4d0:      	b	0x51c <kprobe_unwind_dotnet+0x51c>
     4d4:      	add	w9, w8, #0x1
     4d8:      	mov	w10, #0x8a              // =138
     4dc:      	str	w9, [x21, #0x2c0]
     4e0:      	mov	w9, #0x18               // =24
     4e4:      	umaddl	x8, w8, w9, x21
     4e8:      	mov	w9, #0x1773             // =6003
     4ec:      	str	x9, [x8, #0x2d8]
     4f0:      	add	x9, x8, #0x2d0
     4f4:      	str	xzr, [x8, #0x2d0]
     4f8:      	strb	w10, [x8, #0x2e0]
     4fc:      	str	wzr, [x8, #0x2e4]
     500:      	stur	wzr, [x9, #0x11]
     504:      	ldr	x29, [x11]
     508:      	ldr	w8, [x23]
     50c:      	cbnz	x29, 0xa24 <kprobe_unwind_dotnet+0xa24>
     510:      	b	0x16b0 <kprobe_unwind_dotnet+0x16b0>
     514:      	ldr	w8, [x23]
     518:      	cbnz	w8, 0xfa4 <kprobe_unwind_dotnet+0xfa4>
     51c:      	mov	w25, wzr
     520:      	mov	w8, #0x2                // =2
     524:      	b	0x4624 <kprobe_unwind_dotnet+0x4624>
     528:      	ubfx	w3, w23, #8, #4
     52c:      	cbz	w3, 0x57c <kprobe_unwind_dotnet+0x57c>
     530:      	sub	x29, x29, #0x40
     534:      	b	0x804 <kprobe_unwind_dotnet+0x804>
     538:      	mov	w8, #0x3d3d             // =15677
     53c:      	add	x0, sp, #0x20
     540:      	mov	w1, #0x1c               // =28
     544:      	movk	w8, #0xa, lsl #16
     548:      	str	w8, [sp, #0x38]
     54c:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     550:      	add	x8, x8, #0x0
     554:      	ldp	x9, x10, [x8]
     558:      	ldr	x8, [x8, #0x10]
     55c:      	stp	x9, x10, [sp, #0x20]
     560:      	str	x8, [sp, #0x30]
     564:      	mov	w8, #0x1c               // =28
     568:      	mov	w9, #0x6                // =6
     56c:      	add	x10, sp, #0x20
     570:      	ldr	w2, [x21, #0x2c0]
     574:      	blr	x9
     578:      	b	0x5c <kprobe_unwind_dotnet+0x5c>
     57c:      	ubfx	w3, w23, #12, #4
     580:      	cbz	w3, 0x5c8 <kprobe_unwind_dotnet+0x5c8>
     584:      	sub	x29, x29, #0x60
     588:      	b	0x804 <kprobe_unwind_dotnet+0x804>
     58c:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     590:      	add	x8, x8, #0x0
     594:      	add	x0, sp, #0x20
     598:      	ldp	x9, x10, [x8, #0x10]
     59c:      	mov	w1, #0x28               // =40
     5a0:      	stp	x9, x10, [sp, #0x30]
     5a4:      	ldr	x9, [x8, #0x20]
     5a8:      	add	x10, sp, #0x20
     5ac:      	str	x9, [sp, #0x40]
     5b0:      	ldp	x8, x9, [x8]
     5b4:      	stp	x8, x9, [sp, #0x20]
     5b8:      	mov	w8, #0x28               // =40
     5bc:      	mov	w9, #0x6                // =6
     5c0:      	blr	x9
     5c4:      	b	0x12c <kprobe_unwind_dotnet+0x12c>
     5c8:      	ubfx	w3, w23, #16, #4
     5cc:      	cbz	w3, 0x680 <kprobe_unwind_dotnet+0x680>
     5d0:      	sub	x29, x29, #0x80
     5d4:      	b	0x804 <kprobe_unwind_dotnet+0x804>
     5d8:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     5dc:      	add	x8, x8, #0x0
     5e0:      	add	x0, sp, #0x20
     5e4:      	ldp	x9, x10, [x8, #0x10]
     5e8:      	mov	w1, #0x2e               // =46
     5ec:      	stp	x9, x10, [sp, #0x30]
     5f0:      	ldr	x9, [x8, #0x20]
     5f4:      	add	x10, sp, #0x20
     5f8:      	str	x9, [sp, #0x40]
     5fc:      	ldur	x9, [x8, #0x26]
     600:      	stur	x9, [sp, #0x46]
     604:      	ldp	x9, x8, [x8]
     608:      	stp	x9, x8, [sp, #0x20]
     60c:      	mov	w8, #0x2e               // =46
     610:      	mov	w9, #0x6                // =6
     614:      	ldr	w2, [sp, #0x70]
     618:      	blr	x9
     61c:      	ldr	x25, [x21, #0xed8]
     620:      	ldr	x29, [x21, #0xee0]
     624:      	ldr	x24, [x21, #0xed0]
     628:      	ldrb	w22, [x21, #0xf20]
     62c:      	ldr	w8, [x23]
     630:      	cbz	w8, 0x17c <kprobe_unwind_dotnet+0x17c>
     634:      	b	0xd0 <kprobe_unwind_dotnet+0xd0>
     638:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     63c:      	add	x8, x8, #0x0
     640:      	add	x0, sp, #0x20
     644:      	ldp	x9, x10, [x8, #0x10]
     648:      	mov	w1, #0x2e               // =46
     64c:      	stp	x9, x10, [sp, #0x30]
     650:      	ldr	x9, [x8, #0x20]
     654:      	add	x10, sp, #0x20
     658:      	str	x9, [sp, #0x40]
     65c:      	ldur	x9, [x8, #0x26]
     660:      	stur	x9, [sp, #0x46]
     664:      	ldp	x9, x8, [x8]
     668:      	stp	x9, x8, [sp, #0x20]
     66c:      	mov	w8, #0x2e               // =46
     670:      	mov	w9, #0x6                // =6
     674:      	ldr	w2, [sp, #0x70]
     678:      	blr	x9
     67c:      	b	0x2cc <kprobe_unwind_dotnet+0x2cc>
     680:      	ubfx	w3, w23, #20, #4
     684:      	cbz	w3, 0x74c <kprobe_unwind_dotnet+0x74c>
     688:      	sub	x29, x29, #0xa0
     68c:      	b	0x804 <kprobe_unwind_dotnet+0x804>
     690:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     694:      	add	x8, x8, #0x0
     698:      	add	x0, sp, #0x20
     69c:      	ldp	x9, x10, [x8]
     6a0:      	mov	w1, #0x20               // =32
     6a4:      	stp	x9, x10, [sp, #0x20]
     6a8:      	ldp	x9, x8, [x8, #0x10]
     6ac:      	add	x10, sp, #0x20
     6b0:      	stp	x9, x8, [sp, #0x30]
     6b4:      	mov	w8, #0x20               // =32
     6b8:      	mov	w9, #0x6                // =6
     6bc:      	blr	x9
     6c0:      	b	0x1f0 <kprobe_unwind_dotnet+0x1f0>
     6c4:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     6c8:      	add	x8, x8, #0x0
     6cc:      	add	x0, sp, #0x20
     6d0:      	ldp	x9, x10, [x8]
     6d4:      	mov	w1, #0x20               // =32
     6d8:      	stp	x9, x10, [sp, #0x20]
     6dc:      	ldp	x9, x8, [x8, #0x10]
     6e0:      	add	x10, sp, #0x20
     6e4:      	stp	x9, x8, [sp, #0x30]
     6e8:      	mov	w8, #0x20               // =32
     6ec:      	mov	w9, #0x6                // =6
     6f0:      	blr	x9
     6f4:      	b	0x28c <kprobe_unwind_dotnet+0x28c>
     6f8:      	mov	w8, #0x786c             // =30828
     6fc:      	add	x0, sp, #0x20
     700:      	mov	w1, #0x23               // =35
     704:      	movk	w8, #0xa, lsl #16
     708:      	stur	w8, [sp, #0x3f]
     70c:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     710:      	add	x8, x8, #0x0
     714:      	ldp	x9, x10, [x8]
     718:      	stp	x9, x10, [sp, #0x20]
     71c:      	ldp	x9, x8, [x8, #0x10]
     720:      	add	x10, sp, #0x20
     724:      	stp	x9, x8, [sp, #0x30]
     728:      	mov	w8, #0x23               // =35
     72c:      	mov	w9, #0x6                // =6
     730:      	ldr	x2, [x21, #0xed0]
     734:      	ldr	x3, [x21, #0xed8]
     738:      	ldr	x4, [x21, #0xee0]
     73c:      	blr	x9
     740:      	cmp	x23, #0x100
     744:      	b.hs	0x31c <kprobe_unwind_dotnet+0x31c>
     748:      	b	0x888 <kprobe_unwind_dotnet+0x888>
     74c:      	ubfx	w3, w23, #24, #4
     750:      	cbz	w3, 0x7fc <kprobe_unwind_dotnet+0x7fc>
     754:      	sub	x29, x29, #0xc0
     758:      	b	0x804 <kprobe_unwind_dotnet+0x804>
     75c:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     760:      	add	x8, x8, #0x0
     764:      	ldp	x9, x10, [x8, #0x10]
     768:      	stp	x9, x10, [sp, #0x30]
     76c:      	ldr	x9, [x8, #0x20]
     770:      	add	x10, sp, #0x20
     774:      	str	x9, [sp, #0x40]
     778:      	ldur	x9, [x8, #0x26]
     77c:      	stur	x9, [sp, #0x46]
     780:      	ldp	x9, x8, [x8]
     784:      	stp	x9, x8, [sp, #0x20]
     788:      	mov	w8, #0x2e               // =46
     78c:      	mov	w9, #0x6                // =6
     790:      	ldr	w2, [sp, #0x8c]
     794:      	add	x0, sp, #0x20
     798:      	mov	w1, #0x2e               // =46
     79c:      	blr	x9
     7a0:      	b	0x424 <kprobe_unwind_dotnet+0x424>
     7a4:      	mov	w8, #0xa                // =10
     7a8:      	mov	w11, #0x6               // =6
     7ac:      	add	x0, sp, #0x20
     7b0:      	strh	w8, [sp, #0x60]
     7b4:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     7b8:      	add	x8, x8, #0x0
     7bc:      	mov	w1, #0x42               // =66
     7c0:      	ldp	x9, x10, [x8, #0x20]
     7c4:      	mov	x2, x29
     7c8:      	mov	x3, x25
     7cc:      	mov	x4, x23
     7d0:      	stp	x9, x10, [sp, #0x40]
     7d4:      	ldp	x9, x10, [x8, #0x30]
     7d8:      	stp	x9, x10, [sp, #0x50]
     7dc:      	ldp	x9, x10, [x8]
     7e0:      	stp	x9, x10, [sp, #0x20]
     7e4:      	ldp	x9, x8, [x8, #0x10]
     7e8:      	mov	w10, #0x42              // =66
     7ec:      	stp	x9, x8, [sp, #0x30]
     7f0:      	add	x8, sp, #0x20
     7f4:      	blr	x11
     7f8:      	b	0x338 <kprobe_unwind_dotnet+0x338>
     7fc:      	lsr	w3, w23, #28
     800:      	sub	x29, x29, #0xe0
     804:      	adrp	x23, 0x0 <kprobe_unwind_dotnet>
     808:      	lsl	w9, w3, #2
     80c:      	add	x8, x29, x25
     810:      	ldr	x23, [x23]
     814:      	sub	w9, w9, #0x4
     818:      	add	x25, x8, x9
     81c:      	ldr	w8, [x23]
     820:      	cbnz	w8, 0xd18 <kprobe_unwind_dotnet+0xd18>
     824:      	sub	x2, x25, #0x8
     828:      	mov	w8, #0x8                // =8
     82c:      	mov	w9, #0x70               // =112
     830:      	add	x10, sp, #0x68
     834:      	add	x0, sp, #0x68
     838:      	mov	w1, #0x8                // =8
     83c:      	blr	x9
     840:      	cbz	x0, 0x884 <kprobe_unwind_dotnet+0x884>
     844:      	ldr	w8, [x23]
     848:      	cbnz	w8, 0xdfc <kprobe_unwind_dotnet+0xdfc>
     84c:      	mov	w8, #0x5e               // =94
     850:      	adrp	x24, 0x0 <kprobe_unwind_dotnet>
     854:      	add	x9, sp, #0x8c
     858:      	str	w8, [sp, #0x8c]
     85c:      	mov	w8, #0x1                // =1
     860:      	add	x1, sp, #0x8c
     864:      	ldr	x24, [x24]
     868:      	mov	x0, x24
     86c:      	blr	x8
     870:      	cbz	x0, 0x900 <kprobe_unwind_dotnet+0x900>
     874:      	ldr	x8, [x0]
     878:      	add	x8, x8, #0x1
     87c:      	str	x8, [x0]
     880:      	b	0x908 <kprobe_unwind_dotnet+0x908>
     884:      	mov	w23, #0x1f              // =31
     888:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     88c:      	ldr	x8, [x8]
     890:      	ldr	w8, [x8]
     894:      	cbnz	w8, 0x914 <kprobe_unwind_dotnet+0x914>
     898:      	ldr	w8, [x21, #0x2c0]
     89c:      	cmp	w8, #0x7f
     8a0:      	b.lo	0x978 <kprobe_unwind_dotnet+0x978>
     8a4:      	adrp	x23, 0x0 <kprobe_unwind_dotnet>
     8a8:      	ldr	x23, [x23]
     8ac:      	ldr	w8, [x23]
     8b0:      	cbnz	w8, 0xa4c <kprobe_unwind_dotnet+0xa4c>
     8b4:      	mov	w8, #0x2                // =2
     8b8:      	adrp	x24, 0x0 <kprobe_unwind_dotnet>
     8bc:      	add	x9, sp, #0x8c
     8c0:      	str	w8, [sp, #0x8c]
     8c4:      	mov	w8, #0x1                // =1
     8c8:      	add	x1, sp, #0x8c
     8cc:      	ldr	x24, [x24]
     8d0:      	mov	x0, x24
     8d4:      	blr	x8
     8d8:      	cbz	x0, 0x8ec <kprobe_unwind_dotnet+0x8ec>
     8dc:      	ldr	x8, [x0]
     8e0:      	add	x8, x8, #0x1
     8e4:      	str	x8, [x0]
     8e8:      	b	0x8f4 <kprobe_unwind_dotnet+0x8f4>
     8ec:      	ldr	w8, [x23]
     8f0:      	cbnz	w8, 0xbf4 <kprobe_unwind_dotnet+0xbf4>
     8f4:      	mov	w8, #0x2                // =2
     8f8:      	mov	w25, wzr
     8fc:      	b	0x4624 <kprobe_unwind_dotnet+0x4624>
     900:      	ldr	w8, [x23]
     904:      	cbnz	w8, 0xfec <kprobe_unwind_dotnet+0xfec>
     908:      	mov	w8, #0x1772             // =6002
     90c:      	mov	w25, wzr
     910:      	b	0x4624 <kprobe_unwind_dotnet+0x4624>
     914:      	mov	w8, #0x786c             // =30828
     918:      	sub	x4, x24, x25
     91c:      	add	x0, sp, #0x20
     920:      	mov	w1, #0x43               // =67
     924:      	mov	x2, x25
     928:      	movk	w8, #0xa, lsl #16
     92c:      	stur	w8, [sp, #0x5f]
     930:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     934:      	add	x8, x8, #0x0
     938:      	ldp	x9, x10, [x8, #0x20]
     93c:      	stp	x9, x10, [sp, #0x40]
     940:      	ldp	x9, x10, [x8, #0x30]
     944:      	stp	x9, x10, [sp, #0x50]
     948:      	ldp	x9, x10, [x8]
     94c:      	stp	x9, x10, [sp, #0x20]
     950:      	ldp	x9, x8, [x8, #0x10]
     954:      	add	x10, sp, #0x20
     958:      	stp	x9, x8, [sp, #0x30]
     95c:      	mov	w8, #0x43               // =67
     960:      	mov	w9, #0x6                // =6
     964:      	ldr	x3, [sp, #0x68]
     968:      	blr	x9
     96c:      	ldr	w8, [x21, #0x2c0]
     970:      	cmp	w8, #0x7f
     974:      	b.hs	0x8a4 <kprobe_unwind_dotnet+0x8a4>
     978:      	ldr	x9, [sp, #0x68]
     97c:      	add	w11, w8, #0x1
     980:      	sub	x10, x24, x25
     984:      	adrp	x24, 0x0 <kprobe_unwind_dotnet>
     988:      	str	w11, [x21, #0x2c0]
     98c:      	mov	w11, #0x18              // =24
     990:      	add	x1, sp, #0x8c
     994:      	umaddl	x8, w8, w11, x21
     998:      	add	x9, x23, x9, lsl #5
     99c:      	str	x10, [x8, #0x2d8]
     9a0:      	mov	w10, #0xa               // =10
     9a4:      	strb	w22, [x8, #0x2e1]
     9a8:      	strh	wzr, [x8, #0x2e6]
     9ac:      	strb	w10, [x8, #0x2e0]
     9b0:      	str	x9, [x8, #0x2d0]
     9b4:      	add	x9, x8, #0x2d0
     9b8:      	mov	w8, #0x5b               // =91
     9bc:      	stur	wzr, [x9, #0x12]
     9c0:      	str	w8, [sp, #0x8c]
     9c4:      	mov	w8, #0x1                // =1
     9c8:      	add	x9, sp, #0x8c
     9cc:      	ldr	x24, [x24]
     9d0:      	mov	x0, x24
     9d4:      	blr	x8
     9d8:      	cbz	x0, 0xa04 <kprobe_unwind_dotnet+0xa04>
     9dc:      	ldr	x8, [x0]
     9e0:      	adrp	x23, 0x0 <kprobe_unwind_dotnet>
     9e4:      	add	x8, x8, #0x1
     9e8:      	str	x8, [x0]
     9ec:      	ldr	x23, [x23]
     9f0:      	ldr	x11, [sp, #0x10]
     9f4:      	ldr	x29, [x11]
     9f8:      	ldr	w8, [x23]
     9fc:      	cbnz	x29, 0xa24 <kprobe_unwind_dotnet+0xa24>
     a00:      	b	0x16b0 <kprobe_unwind_dotnet+0x16b0>
     a04:      	adrp	x23, 0x0 <kprobe_unwind_dotnet>
     a08:      	ldr	x23, [x23]
     a0c:      	ldr	x11, [sp, #0x10]
     a10:      	ldr	w8, [x23]
     a14:      	cbnz	w8, 0xc3c <kprobe_unwind_dotnet+0xc3c>
     a18:      	ldr	x29, [x11]
     a1c:      	ldr	w8, [x23]
     a20:      	cbz	x29, 0x16b0 <kprobe_unwind_dotnet+0x16b0>
     a24:      	cbnz	w8, 0xa88 <kprobe_unwind_dotnet+0xa88>
     a28:      	lsr	x8, x29, #56
     a2c:      	cbz	x8, 0xadc <kprobe_unwind_dotnet+0xadc>
     a30:      	ldr	w8, [x23]
     a34:      	cbnz	w8, 0x1668 <kprobe_unwind_dotnet+0x1668>
     a38:      	mov	w8, #0xb                // =11
     a3c:      	mov	w25, wzr
     a40:      	str	w8, [x21, #0xf18]
     a44:      	mov	w8, #0xfab              // =4011
     a48:      	b	0x4624 <kprobe_unwind_dotnet+0x4624>
     a4c:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     a50:      	add	x8, x8, #0x0
     a54:      	add	x0, sp, #0x20
     a58:      	ldp	x9, x10, [x8, #0x10]
     a5c:      	mov	w1, #0x25               // =37
     a60:      	stp	x9, x10, [sp, #0x30]
     a64:      	ldur	x9, [x8, #0x1d]
     a68:      	add	x10, sp, #0x20
     a6c:      	stur	x9, [sp, #0x3d]
     a70:      	ldp	x8, x9, [x8]
     a74:      	stp	x8, x9, [sp, #0x20]
     a78:      	mov	w8, #0x25               // =37
     a7c:      	mov	w9, #0x6                // =6
     a80:      	blr	x9
     a84:      	b	0x8b4 <kprobe_unwind_dotnet+0x8b4>
     a88:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     a8c:      	add	x8, x8, #0x0
     a90:      	strb	wzr, [sp, #0x50]
     a94:      	add	x0, sp, #0x20
     a98:      	ldp	x9, x10, [x8, #0x10]
     a9c:      	mov	w1, #0x31               // =49
     aa0:      	mov	x22, x11
     aa4:      	stp	x9, x10, [sp, #0x30]
     aa8:      	ldp	x9, x10, [x8, #0x20]
     aac:      	stp	x9, x10, [sp, #0x40]
     ab0:      	ldp	x9, x8, [x8]
     ab4:      	add	x10, sp, #0x20
     ab8:      	stp	x9, x8, [sp, #0x20]
     abc:      	mov	w8, #0x31               // =49
     ac0:      	mov	w9, #0x6                // =6
     ac4:      	ldr	w2, [x21, #0x2c0]
     ac8:      	blr	x9
     acc:      	ldr	x29, [x21, #0xed0]
     ad0:      	mov	x11, x22
     ad4:      	lsr	x8, x29, #56
     ad8:      	cbnz	x8, 0xa30 <kprobe_unwind_dotnet+0xa30>
     adc:      	cmp	x29, #0xfff
     ae0:      	b.hi	0xb00 <kprobe_unwind_dotnet+0xb00>
     ae4:      	ldr	w8, [x23]
     ae8:      	cbnz	w8, 0x179c <kprobe_unwind_dotnet+0x179c>
     aec:      	mov	w8, #0x31               // =49
     af0:      	mov	w25, wzr
     af4:      	str	w8, [x21, #0xf18]
     af8:      	mov	w8, #0xfae              // =4014
     afc:      	b	0x4624 <kprobe_unwind_dotnet+0x4624>
     b00:      	ldr	w8, [x21]
     b04:      	mov	w9, #0x60               // =96
     b08:      	str	x11, [sp, #0x10]
     b0c:      	adrp	x0, 0x0 <kprobe_unwind_dotnet>
     b10:      	add	x1, sp, #0x70
     b14:      	rev	w8, w8
     b18:      	stp	w9, w8, [sp, #0x70]
     b1c:      	rev	x8, x29
     b20:      	add	x9, sp, #0x70
     b24:      	str	x8, [sp, #0x78]
     b28:      	mov	w8, #0x1                // =1
     b2c:      	ldr	x0, [x0]
     b30:      	blr	x8
     b34:      	cbz	x0, 0x4efc <kprobe_unwind_dotnet+0x4efc>
     b38:      	ldr	x8, [x0, #0x8]
     b3c:      	and	x9, x8, #0xffffffffffffff
     b40:      	lsr	x25, x8, #56
     b44:      	str	x9, [x21, #0xf10]
     b48:      	ldr	x8, [x0]
     b4c:      	str	x8, [x21, #0xf00]
     b50:      	sub	x8, x29, x9
     b54:      	str	x8, [x21, #0xf08]
     b58:      	ldr	w8, [x23]
     b5c:      	cbnz	w8, 0xe38 <kprobe_unwind_dotnet+0xe38>
     b60:      	ldr	x0, [sp, #0x10]
     b64:      	cmp	w25, #0x1
     b68:      	b.ne	0x10e0 <kprobe_unwind_dotnet+0x10e0>
     b6c:      	ldr	x8, [x21, #0xf00]
     b70:      	adrp	x0, 0x0 <kprobe_unwind_dotnet>
     b74:      	ldr	x22, [x21, #0xf08]
     b78:      	mov	w9, #0x1                // =1
     b7c:      	add	x1, sp, #0x70
     b80:      	mov	w25, #0x1               // =1
     b84:      	str	x8, [sp, #0x70]
     b88:      	add	x8, sp, #0x70
     b8c:      	ldr	x0, [x0]
     b90:      	blr	x9
     b94:      	cbz	x0, 0xbf0 <kprobe_unwind_dotnet+0xbf0>
     b98:      	ldr	x8, [x0]
     b9c:      	cmp	x8, x22
     ba0:      	b.hi	0xbb0 <kprobe_unwind_dotnet+0xbb0>
     ba4:      	ldr	x8, [x0, #0x8]
     ba8:      	cmp	x8, x22
     bac:      	b.hs	0xbc8 <kprobe_unwind_dotnet+0xbc8>
     bb0:      	ldr	x8, [x0, #0x10]
     bb4:      	cmp	x8, x22
     bb8:      	b.hi	0xbe8 <kprobe_unwind_dotnet+0xbe8>
     bbc:      	ldr	x8, [x0, #0x18]
     bc0:      	cmp	x8, x22
     bc4:      	b.lo	0xbe8 <kprobe_unwind_dotnet+0xbe8>
     bc8:      	ldr	w8, [x23]
     bcc:      	cbnz	w8, 0x1044 <kprobe_unwind_dotnet+0x1044>
     bd0:      	ldrh	w8, [x0, #0x20]
     bd4:      	ldr	w9, [x21, #0x1370]
     bd8:      	lsr	w8, w9, w8
     bdc:      	tbz	w8, #0x0, 0x1098 <kprobe_unwind_dotnet+0x1098>
     be0:      	ldr	w8, [x23]
     be4:      	cbnz	w8, 0x13e4 <kprobe_unwind_dotnet+0x13e4>
     be8:      	mov	w25, #0x1               // =1
     bec:      	b	0x10dc <kprobe_unwind_dotnet+0x10dc>
     bf0:      	b	0x10dc <kprobe_unwind_dotnet+0x10dc>
     bf4:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     bf8:      	add	x8, x8, #0x0
     bfc:      	add	x0, sp, #0x20
     c00:      	ldp	x9, x10, [x8, #0x10]
     c04:      	mov	w1, #0x2e               // =46
     c08:      	stp	x9, x10, [sp, #0x30]
     c0c:      	ldr	x9, [x8, #0x20]
     c10:      	add	x10, sp, #0x20
     c14:      	str	x9, [sp, #0x40]
     c18:      	ldur	x9, [x8, #0x26]
     c1c:      	stur	x9, [sp, #0x46]
     c20:      	ldp	x9, x8, [x8]
     c24:      	stp	x9, x8, [sp, #0x20]
     c28:      	mov	w8, #0x2e               // =46
     c2c:      	mov	w9, #0x6                // =6
     c30:      	ldr	w2, [sp, #0x8c]
     c34:      	blr	x9
     c38:      	b	0x8f4 <kprobe_unwind_dotnet+0x8f4>
     c3c:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     c40:      	add	x8, x8, #0x0
     c44:      	add	x0, sp, #0x20
     c48:      	ldp	x9, x10, [x8, #0x10]
     c4c:      	mov	w1, #0x2e               // =46
     c50:      	mov	x22, x11
     c54:      	stp	x9, x10, [sp, #0x30]
     c58:      	ldr	x9, [x8, #0x20]
     c5c:      	add	x10, sp, #0x20
     c60:      	str	x9, [sp, #0x40]
     c64:      	ldur	x9, [x8, #0x26]
     c68:      	stur	x9, [sp, #0x46]
     c6c:      	ldp	x9, x8, [x8]
     c70:      	stp	x9, x8, [sp, #0x20]
     c74:      	mov	w8, #0x2e               // =46
     c78:      	mov	w9, #0x6                // =6
     c7c:      	ldr	w2, [sp, #0x8c]
     c80:      	blr	x9
     c84:      	mov	x11, x22
     c88:      	ldr	x29, [x22]
     c8c:      	ldr	w8, [x23]
     c90:      	cbnz	x29, 0xa24 <kprobe_unwind_dotnet+0xa24>
     c94:      	b	0x16b0 <kprobe_unwind_dotnet+0x16b0>
     c98:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     c9c:      	add	x8, x8, #0x0
     ca0:      	add	x0, sp, #0x20
     ca4:      	ldp	x9, x10, [x8, #0x20]
     ca8:      	and	x2, x29, #0xfffffffffffffffc
     cac:      	mov	w1, #0x36               // =54
     cb0:      	mov	w3, w23
     cb4:      	stp	x9, x10, [sp, #0x40]
     cb8:      	ldur	x9, [x8, #0x2e]
     cbc:      	stur	x9, [sp, #0x4e]
     cc0:      	ldp	x9, x10, [x8]
     cc4:      	stp	x9, x10, [sp, #0x20]
     cc8:      	ldp	x8, x9, [x8, #0x10]
     ccc:      	add	x10, sp, #0x20
     cd0:      	stp	x8, x9, [sp, #0x30]
     cd4:      	mov	w8, #0x36               // =54
     cd8:      	mov	w9, #0x6                // =6
     cdc:      	blr	x9
     ce0:      	mov	w8, #0x1c               // =28
     ce4:      	bic	w8, w8, w29, lsr #3
     ce8:      	lsr	w23, w23, w8
     cec:      	cbnz	w23, 0x454 <kprobe_unwind_dotnet+0x454>
     cf0:      	and	x8, x29, #0xffffffffffffff00
     cf4:      	ldr	w23, [x21, #0x1168]
     cf8:      	sub	x29, x8, #0x20
     cfc:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     d00:      	ldr	x8, [x8]
     d04:      	ldr	w8, [x8]
     d08:      	cbnz	w8, 0xed8 <kprobe_unwind_dotnet+0xed8>
     d0c:      	cbz	w23, 0xf24 <kprobe_unwind_dotnet+0xf24>
     d10:      	mov	w3, wzr
     d14:      	b	0x5d18 <kprobe_unwind_dotnet+0x5d18>
     d18:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     d1c:      	add	x8, x8, #0x0
     d20:      	add	x0, sp, #0x20
     d24:      	ldp	x9, x10, [x8, #0x10]
     d28:      	mov	w1, #0x2e               // =46
     d2c:      	mov	x2, x29
     d30:      	mov	x4, x25
     d34:      	stp	x9, x10, [sp, #0x30]
     d38:      	ldr	x9, [x8, #0x20]
     d3c:      	add	x10, sp, #0x20
     d40:      	str	x9, [sp, #0x40]
     d44:      	ldur	x9, [x8, #0x26]
     d48:      	stur	x9, [sp, #0x46]
     d4c:      	ldp	x9, x8, [x8]
     d50:      	stp	x9, x8, [sp, #0x20]
     d54:      	mov	w8, #0x2e               // =46
     d58:      	mov	w9, #0x6                // =6
     d5c:      	blr	x9
     d60:      	b	0x824 <kprobe_unwind_dotnet+0x824>
     d64:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     d68:      	add	x8, x8, #0x0
     d6c:      	add	x0, sp, #0x20
     d70:      	ldp	x9, x10, [x8, #0x10]
     d74:      	mov	w1, #0x2e               // =46
     d78:      	stp	x9, x10, [sp, #0x30]
     d7c:      	ldr	x9, [x8, #0x20]
     d80:      	add	x10, sp, #0x20
     d84:      	str	x9, [sp, #0x40]
     d88:      	ldur	x9, [x8, #0x26]
     d8c:      	stur	x9, [sp, #0x46]
     d90:      	ldp	x9, x8, [x8]
     d94:      	stp	x9, x8, [sp, #0x20]
     d98:      	mov	w8, #0x2e               // =46
     d9c:      	mov	w9, #0x6                // =6
     da0:      	ldr	w2, [sp, #0x8c]
     da4:      	blr	x9
     da8:      	ldr	x11, [sp, #0x10]
     dac:      	mov	w22, wzr
     db0:      	mov	w2, #0x1772             // =6002
     db4:      	ldr	w8, [x23]
     db8:      	cbz	w8, 0x48c <kprobe_unwind_dotnet+0x48c>
     dbc:      	b	0x3d8 <kprobe_unwind_dotnet+0x3d8>
     dc0:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     dc4:      	add	x8, x8, #0x0
     dc8:      	add	x0, sp, #0x20
     dcc:      	ldp	x9, x10, [x8, #0x10]
     dd0:      	mov	w1, #0x25               // =37
     dd4:      	stp	x9, x10, [sp, #0x30]
     dd8:      	ldur	x9, [x8, #0x1d]
     ddc:      	add	x10, sp, #0x20
     de0:      	stur	x9, [sp, #0x3d]
     de4:      	ldp	x8, x9, [x8]
     de8:      	stp	x8, x9, [sp, #0x20]
     dec:      	mov	w8, #0x25               // =37
     df0:      	mov	w9, #0x6                // =6
     df4:      	blr	x9
     df8:      	b	0x4a4 <kprobe_unwind_dotnet+0x4a4>
     dfc:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     e00:      	add	x8, x8, #0x0
     e04:      	add	x0, sp, #0x20
     e08:      	ldp	x9, x10, [x8]
     e0c:      	mov	w1, #0x1e               // =30
     e10:      	stp	x9, x10, [sp, #0x20]
     e14:      	ldr	x9, [x8, #0x10]
     e18:      	ldur	x8, [x8, #0x16]
     e1c:      	add	x10, sp, #0x20
     e20:      	str	x9, [sp, #0x30]
     e24:      	stur	x8, [sp, #0x36]
     e28:      	mov	w8, #0x1e               // =30
     e2c:      	mov	w9, #0x6                // =6
     e30:      	blr	x9
     e34:      	b	0x84c <kprobe_unwind_dotnet+0x84c>
     e38:      	mov	w8, #0xa                // =10
     e3c:      	add	x0, sp, #0x20
     e40:      	mov	w1, #0x32               // =50
     e44:      	strh	w8, [sp, #0x50]
     e48:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     e4c:      	add	x8, x8, #0x0
     e50:      	mov	x2, x29
     e54:      	ldp	x9, x10, [x8, #0x10]
     e58:      	mov	w4, w25
     e5c:      	stp	x9, x10, [sp, #0x30]
     e60:      	ldp	x9, x10, [x8, #0x20]
     e64:      	stp	x9, x10, [sp, #0x40]
     e68:      	ldp	x9, x8, [x8]
     e6c:      	add	x10, sp, #0x20
     e70:      	stp	x9, x8, [sp, #0x20]
     e74:      	mov	w8, #0x32               // =50
     e78:      	mov	w9, #0x6                // =6
     e7c:      	ldr	x3, [x21, #0xf00]
     e80:      	blr	x9
     e84:      	ldr	w8, [x23]
     e88:      	cbz	w8, 0xb60 <kprobe_unwind_dotnet+0xb60>
     e8c:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     e90:      	add	x8, x8, #0x0
     e94:      	add	x0, sp, #0x20
     e98:      	ldp	x9, x10, [x8, #0x10]
     e9c:      	mov	w1, #0x2f               // =47
     ea0:      	stp	x9, x10, [sp, #0x30]
     ea4:      	ldr	x9, [x8, #0x20]
     ea8:      	add	x10, sp, #0x20
     eac:      	str	x9, [sp, #0x40]
     eb0:      	ldur	x9, [x8, #0x27]
     eb4:      	stur	x9, [sp, #0x47]
     eb8:      	ldp	x9, x8, [x8]
     ebc:      	stp	x9, x8, [sp, #0x20]
     ec0:      	mov	w8, #0x2f               // =47
     ec4:      	mov	w9, #0x6                // =6
     ec8:      	ldr	x2, [x21, #0xf10]
     ecc:      	ldr	x3, [x21, #0xf08]
     ed0:      	blr	x9
     ed4:      	b	0xb60 <kprobe_unwind_dotnet+0xb60>
     ed8:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     edc:      	add	x8, x8, #0x0
     ee0:      	add	x0, sp, #0x20
     ee4:      	ldp	x9, x10, [x8, #0x20]
     ee8:      	mov	w1, #0x37               // =55
     eec:      	mov	x2, x29
     ef0:      	mov	w3, w23
     ef4:      	stp	x9, x10, [sp, #0x40]
     ef8:      	ldur	x9, [x8, #0x2f]
     efc:      	stur	x9, [sp, #0x4f]
     f00:      	ldp	x9, x10, [x8]
     f04:      	stp	x9, x10, [sp, #0x20]
     f08:      	ldp	x8, x9, [x8, #0x10]
     f0c:      	add	x10, sp, #0x20
     f10:      	stp	x8, x9, [sp, #0x30]
     f14:      	mov	w8, #0x37               // =55
     f18:      	mov	w9, #0x6                // =6
     f1c:      	blr	x9
     f20:      	cbnz	w23, 0xd10 <kprobe_unwind_dotnet+0xd10>
     f24:      	ldr	x8, [x21, #0x1160]
     f28:      	cbz	x8, 0xf34 <kprobe_unwind_dotnet+0xf34>
     f2c:      	mov	w9, #-0x7c              // =-124
     f30:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
     f34:      	ldr	x8, [x21, #0x1158]
     f38:      	cbz	x8, 0xf44 <kprobe_unwind_dotnet+0xf44>
     f3c:      	mov	w9, #-0x7a              // =-122
     f40:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
     f44:      	ldr	x8, [x21, #0x1150]
     f48:      	cbz	x8, 0xf54 <kprobe_unwind_dotnet+0xf54>
     f4c:      	mov	w9, #-0x78              // =-120
     f50:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
     f54:      	ldr	x8, [x21, #0x1148]
     f58:      	cbz	x8, 0xf64 <kprobe_unwind_dotnet+0xf64>
     f5c:      	mov	w9, #-0x76              // =-118
     f60:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
     f64:      	ldr	x8, [x21, #0x1140]
     f68:      	cbz	x8, 0xf74 <kprobe_unwind_dotnet+0xf74>
     f6c:      	mov	w9, #-0x74              // =-116
     f70:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
     f74:      	ldr	x8, [x21, #0x1138]
     f78:      	cbz	x8, 0xf84 <kprobe_unwind_dotnet+0xf84>
     f7c:      	mov	w9, #-0x72              // =-114
     f80:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
     f84:      	ldr	x8, [x21, #0x1130]
     f88:      	cbz	x8, 0xf94 <kprobe_unwind_dotnet+0xf94>
     f8c:      	mov	w9, #-0x70              // =-112
     f90:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
     f94:      	ldr	x8, [x21, #0x1128]
     f98:      	cbz	x8, 0x1034 <kprobe_unwind_dotnet+0x1034>
     f9c:      	mov	w9, #-0x6e              // =-110
     fa0:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
     fa4:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     fa8:      	add	x8, x8, #0x0
     fac:      	add	x0, sp, #0x20
     fb0:      	ldp	x9, x10, [x8, #0x10]
     fb4:      	mov	w1, #0x2e               // =46
     fb8:      	stp	x9, x10, [sp, #0x30]
     fbc:      	ldr	x9, [x8, #0x20]
     fc0:      	add	x10, sp, #0x20
     fc4:      	str	x9, [sp, #0x40]
     fc8:      	ldur	x9, [x8, #0x26]
     fcc:      	stur	x9, [sp, #0x46]
     fd0:      	ldp	x9, x8, [x8]
     fd4:      	stp	x9, x8, [sp, #0x20]
     fd8:      	mov	w8, #0x2e               // =46
     fdc:      	mov	w9, #0x6                // =6
     fe0:      	ldr	w2, [sp, #0x8c]
     fe4:      	blr	x9
     fe8:      	b	0x51c <kprobe_unwind_dotnet+0x51c>
     fec:      	adrp	x8, 0x0 <kprobe_unwind_dotnet>
     ff0:      	add	x8, x8, #0x0
     ff4:      	add	x0, sp, #0x20
     ff8:      	ldp	x9, x10, [x8, #0x10]
     ffc:      	mov	w1, #0x2e               // =46
    1000:      	stp	x9, x10, [sp, #0x30]
    1004:      	ldr	x9, [x8, #0x20]
    1008:      	add	x10, sp, #0x20
    100c:      	str	x9, [sp, #0x40]
    1010:      	ldur	x9, [x8, #0x26]
    1014:      	stur	x9, [sp, #0x46]
    1018:      	ldp	x9, x8, [x8]
    101c:      	stp	x9, x8, [sp, #0x20]
    1020:      	mov	w8, #0x2e               // =46
    1024:      	mov	w9, #0x6                // =6
    1028:      	ldr	w2, [sp, #0x8c]
    102c:      	blr	x9
    1030:      	b	0x908 <kprobe_unwind_dotnet+0x908>
    1034:      	ldr	x8, [x21, #0x1120]
    1038:      	cbz	x8, 0x13d4 <kprobe_unwind_dotnet+0x13d4>
    103c:      	mov	w9, #-0x6c              // =-108
    1040:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    1044:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1048:      	add	x8, x8, #0x0
    104c:      	mov	x22, x0
    1050:      	ldp	x9, x10, [x8]
    1054:      	mov	w1, #0x1e               // =30
    1058:      	stp	x9, x10, [sp, #0x20]
    105c:      	ldr	x9, [x8, #0x10]
    1060:      	ldur	x8, [x8, #0x16]
    1064:      	add	x10, sp, #0x20
    1068:      	str	x9, [sp, #0x30]
    106c:      	stur	x8, [sp, #0x36]
    1070:      	mov	w8, #0x1e               // =30
    1074:      	mov	w9, #0x6                // =6
    1078:      	ldrh	w2, [x0, #0x20]
    107c:      	add	x0, sp, #0x20
    1080:      	blr	x9
    1084:      	mov	x0, x22
    1088:      	ldrh	w8, [x22, #0x20]
    108c:      	ldr	w9, [x21, #0x1370]
    1090:      	lsr	w8, w9, w8
    1094:      	tbnz	w8, #0x0, 0xbe0 <kprobe_unwind_dotnet+0xbe0>
    1098:      	str	wzr, [sp, #0x68]
    109c:      	mov	w8, #0x1                // =1
    10a0:      	add	x9, sp, #0x68
    10a4:      	mov	x22, x0
    10a8:      	add	x1, sp, #0x68
    10ac:      	mov	x0, x24
    10b0:      	blr	x8
    10b4:      	cbz	x0, 0x10cc <kprobe_unwind_dotnet+0x10cc>
    10b8:      	ldr	x8, [x0]
    10bc:      	add	x8, x8, #0x1
    10c0:      	str	x8, [x0]
    10c4:      	mov	x8, x22
    10c8:      	b	0x10d8 <kprobe_unwind_dotnet+0x10d8>
    10cc:      	ldr	w9, [x23]
    10d0:      	mov	x8, x22
    10d4:      	cbnz	w9, 0x14f0 <kprobe_unwind_dotnet+0x14f0>
    10d8:      	ldrh	w25, [x8, #0x20]
    10dc:      	ldr	x0, [sp, #0x10]
    10e0:      	cmp	w25, #0x8
    10e4:      	b.ne	0x1164 <kprobe_unwind_dotnet+0x1164>
    10e8:      	ldr	x25, [x21, #0xed8]
    10ec:      	ldr	x29, [x21, #0xee0]
    10f0:      	ldr	x24, [x21, #0xed0]
    10f4:      	ldrb	w22, [x21, #0xf20]
    10f8:      	ldr	w8, [x23]
    10fc:      	cbnz	w8, 0x135c <kprobe_unwind_dotnet+0x135c>
    1100:      	cmp	x29, x25
    1104:      	b.lo	0x45d4 <kprobe_unwind_dotnet+0x45d4>
    1108:      	add	x8, x25, #0x2, lsl #12  // =0x2000
    110c:      	cmp	x29, x8
    1110:      	b.hs	0x45d4 <kprobe_unwind_dotnet+0x45d4>
    1114:      	ldr	x23, [x21, #0xf00]
    1118:      	ldr	x25, [x21, #0xf10]
    111c:      	mov	w8, #0x101              // =257
    1120:      	str	x24, [sp, #0x68]
    1124:      	strh	w8, [x21, #0xf20]
    1128:      	and	x8, x23, #0xffffffffffffff80
    112c:      	cmp	x8, #0x80
    1130:      	b.ne	0x116c <kprobe_unwind_dotnet+0x116c>
    1134:      	ldr	x8, [x21, #0xed8]
    1138:      	mov	w9, #0x8                // =8
    113c:      	mov	w10, #0x70              // =112
    1140:      	mov	w1, #0x8                // =8
    1144:      	ldr	x2, [x21, #0xed8]
    1148:      	blr	x10
    114c:      	cbnz	x0, 0x1e0 <kprobe_unwind_dotnet+0x1e0>
    1150:      	ldr	x8, [x21, #0xed8]
    1154:      	and	x23, x23, #0x7f
    1158:      	add	x8, x8, #0x8
    115c:      	str	x8, [x21, #0xed8]
    1160:      	b	0x1590 <kprobe_unwind_dotnet+0x1590>
    1164:      	mov	w8, wzr
    1168:      	b	0x4624 <kprobe_unwind_dotnet+0x4624>
    116c:      	mov	w8, #0x10               // =16
    1170:      	mov	w9, #0x70               // =112
    1174:      	add	x10, sp, #0x70
    1178:      	add	x0, sp, #0x70
    117c:      	mov	w1, #0x10               // =16
    1180:      	mov	x2, x29
    1184:      	blr	x9
    1188:      	cbnz	x0, 0x27c <kprobe_unwind_dotnet+0x27c>
    118c:      	add	x8, x29, #0x10
    1190:      	str	x8, [x21, #0xed8]
    1194:      	ldp	x8, x9, [sp, #0x70]
    1198:      	str	x8, [x21, #0xee0]
    119c:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    11a0:      	str	x9, [x21, #0xed0]
    11a4:      	ldr	x8, [x8]
    11a8:      	ldr	w8, [x8]
    11ac:      	cbnz	w8, 0x1424 <kprobe_unwind_dotnet+0x1424>
    11b0:      	cmp	x23, #0x100
    11b4:      	b.lo	0x1590 <kprobe_unwind_dotnet+0x1590>
    11b8:      	ldr	x8, [x21, #0xf10]
    11bc:      	ldr	x25, [x21, #0xf00]
    11c0:      	sub	x23, x24, x8
    11c4:      	str	x8, [sp, #0x8]
    11c8:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    11cc:      	ldr	x8, [x8]
    11d0:      	ldr	w8, [x8]
    11d4:      	cbnz	w8, 0x1498 <kprobe_unwind_dotnet+0x1498>
    11d8:      	lsr	x8, x23, #8
    11dc:      	mov	w9, #0x7f               // =127
    11e0:      	lsr	x10, x23, #15
    11e4:      	mov	w1, #0x200              // =512
    11e8:      	sub	w9, w9, w8
    11ec:      	lsl	x8, x8, #2
    11f0:      	cmp	x10, #0x0
    11f4:      	sub	x8, x8, #0x3fc
    11f8:      	and	x9, x9, #0x7f
    11fc:      	csel	x8, x8, xzr, ne
    1200:      	add	x2, x8, x25
    1204:      	csel	x8, xzr, x9, ne
    1208:      	ldr	x9, [sp, #0x18]
    120c:      	add	x0, x9, x8, lsl #2
    1210:      	mov	w8, #0x200              // =512
    1214:      	mov	w9, #0x70               // =112
    1218:      	blr	x9
    121c:      	cbz	x0, 0x127c <kprobe_unwind_dotnet+0x127c>
    1220:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1224:      	ldr	x8, [x8]
    1228:      	ldr	w8, [x8]
    122c:      	cbnz	w8, 0x6120 <kprobe_unwind_dotnet+0x6120>
    1230:      	mov	w8, #0x5e               // =94
    1234:      	adrp	x0, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1238:      	add	x9, sp, #0x8c
    123c:      	str	w8, [sp, #0x8c]
    1240:      	mov	w8, #0x1                // =1
    1244:      	add	x1, sp, #0x8c
    1248:      	ldr	x0, [x0]
    124c:      	blr	x8
    1250:      	cbz	x0, 0x12bc <kprobe_unwind_dotnet+0x12bc>
    1254:      	ldr	x8, [x0]
    1258:      	add	x8, x8, #0x1
    125c:      	str	x8, [x0]
    1260:      	mov	w22, wzr
    1264:      	mov	w2, #0x1772             // =6002
    1268:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    126c:      	ldr	x8, [x8]
    1270:      	ldr	w8, [x8]
    1274:      	cbz	w8, 0x12e4 <kprobe_unwind_dotnet+0x12e4>
    1278:      	b	0x61e0 <kprobe_unwind_dotnet+0x61e0>
    127c:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1280:      	ldr	w25, [x21, #0x116c]
    1284:      	ldr	x8, [x8]
    1288:      	ldr	w8, [x8]
    128c:      	cbnz	w8, 0x194c <kprobe_unwind_dotnet+0x194c>
    1290:      	mov	w8, #0x1c               // =28
    1294:      	bic	w8, w8, w23, lsr #3
    1298:      	lsr	w25, w25, w8
    129c:      	cbz	w25, 0x19a4 <kprobe_unwind_dotnet+0x19a4>
    12a0:      	and	x29, x23, #0xffffffffffffffe0
    12a4:      	ands	w3, w25, #0xf
    12a8:      	b.ne	0x1540 <kprobe_unwind_dotnet+0x1540>
    12ac:      	ubfx	w3, w25, #4, #4
    12b0:      	cbz	w3, 0x133c <kprobe_unwind_dotnet+0x133c>
    12b4:      	sub	x29, x29, #0x20
    12b8:      	b	0x1540 <kprobe_unwind_dotnet+0x1540>
    12bc:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    12c0:      	ldr	x8, [x8]
    12c4:      	ldr	w8, [x8]
    12c8:      	cbnz	w8, 0x1a18 <kprobe_unwind_dotnet+0x1a18>
    12cc:      	mov	w22, wzr
    12d0:      	mov	w2, #0x1772             // =6002
    12d4:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    12d8:      	ldr	x8, [x8]
    12dc:      	ldr	w8, [x8]
    12e0:      	cbnz	w8, 0x61e0 <kprobe_unwind_dotnet+0x61e0>
    12e4:      	cbz	w22, 0x621c <kprobe_unwind_dotnet+0x621c>
    12e8:      	ldr	w8, [x21, #0x2c0]
    12ec:      	adrp	x23, 0x1000 <kprobe_unwind_dotnet+0x1000>
    12f0:      	adrp	x24, 0x1000 <kprobe_unwind_dotnet+0x1000>
    12f4:      	ldr	x23, [x23]
    12f8:      	ldr	x24, [x24]
    12fc:      	ldr	x11, [sp, #0x10]
    1300:      	cmp	w8, #0x7e
    1304:      	b.hi	0x49c <kprobe_unwind_dotnet+0x49c>
    1308:      	add	w9, w8, #0x1
    130c:      	mov	w10, #0x8a              // =138
    1310:      	str	w9, [x21, #0x2c0]
    1314:      	mov	w9, #0x18               // =24
    1318:      	umaddl	x8, w8, w9, x21
    131c:      	mov	w9, #0x1773             // =6003
    1320:      	str	x9, [x8, #0x2d8]
    1324:      	add	x9, x8, #0x2d0
    1328:      	str	xzr, [x8, #0x2d0]
    132c:      	strb	w10, [x8, #0x2e0]
    1330:      	str	wzr, [x8, #0x2e4]
    1334:      	stur	wzr, [x9, #0x11]
    1338:      	b	0x1638 <kprobe_unwind_dotnet+0x1638>
    133c:      	ubfx	w3, w25, #8, #4
    1340:      	cbz	w3, 0x134c <kprobe_unwind_dotnet+0x134c>
    1344:      	sub	x29, x29, #0x40
    1348:      	b	0x1540 <kprobe_unwind_dotnet+0x1540>
    134c:      	ubfx	w3, w25, #12, #4
    1350:      	cbz	w3, 0x13b4 <kprobe_unwind_dotnet+0x13b4>
    1354:      	sub	x29, x29, #0x60
    1358:      	b	0x1540 <kprobe_unwind_dotnet+0x1540>
    135c:      	mov	w8, #0x786c             // =30828
    1360:      	add	x0, sp, #0x20
    1364:      	mov	w1, #0x23               // =35
    1368:      	mov	x2, x24
    136c:      	mov	x3, x25
    1370:      	mov	x4, x29
    1374:      	movk	w8, #0xa, lsl #16
    1378:      	stur	w8, [sp, #0x3f]
    137c:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1380:      	add	x8, x8, #0x0
    1384:      	ldp	x9, x10, [x8]
    1388:      	stp	x9, x10, [sp, #0x20]
    138c:      	ldp	x9, x8, [x8, #0x10]
    1390:      	add	x10, sp, #0x20
    1394:      	stp	x9, x8, [sp, #0x30]
    1398:      	mov	w8, #0x23               // =35
    139c:      	mov	w9, #0x6                // =6
    13a0:      	blr	x9
    13a4:      	ldr	x0, [sp, #0x10]
    13a8:      	cmp	x29, x25
    13ac:      	b.hs	0x1108 <kprobe_unwind_dotnet+0x1108>
    13b0:      	b	0x45d4 <kprobe_unwind_dotnet+0x45d4>
    13b4:      	ubfx	w3, w25, #16, #4
    13b8:      	cbz	w3, 0x13c4 <kprobe_unwind_dotnet+0x13c4>
    13bc:      	sub	x29, x29, #0x80
    13c0:      	b	0x1540 <kprobe_unwind_dotnet+0x1540>
    13c4:      	ubfx	w3, w25, #20, #4
    13c8:      	cbz	w3, 0x1478 <kprobe_unwind_dotnet+0x1478>
    13cc:      	sub	x29, x29, #0xa0
    13d0:      	b	0x1540 <kprobe_unwind_dotnet+0x1540>
    13d4:      	ldr	x8, [x21, #0x1118]
    13d8:      	cbz	x8, 0x1488 <kprobe_unwind_dotnet+0x1488>
    13dc:      	mov	w9, #-0x6a              // =-106
    13e0:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    13e4:      	mov	w8, #0x656e             // =25966
    13e8:      	add	x0, sp, #0x20
    13ec:      	mov	w1, #0x1b               // =27
    13f0:      	movk	w8, #0xa, lsl #16
    13f4:      	stur	w8, [sp, #0x37]
    13f8:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    13fc:      	add	x8, x8, #0x0
    1400:      	ldp	x9, x10, [x8]
    1404:      	ldr	x8, [x8, #0x10]
    1408:      	stp	x9, x10, [sp, #0x20]
    140c:      	str	x8, [sp, #0x30]
    1410:      	mov	w8, #0x1b               // =27
    1414:      	mov	w9, #0x6                // =6
    1418:      	add	x10, sp, #0x20
    141c:      	blr	x9
    1420:      	b	0xbe8 <kprobe_unwind_dotnet+0xbe8>
    1424:      	mov	w8, #0x786c             // =30828
    1428:      	add	x0, sp, #0x20
    142c:      	mov	w1, #0x23               // =35
    1430:      	movk	w8, #0xa, lsl #16
    1434:      	stur	w8, [sp, #0x3f]
    1438:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    143c:      	add	x8, x8, #0x0
    1440:      	ldp	x9, x10, [x8]
    1444:      	stp	x9, x10, [sp, #0x20]
    1448:      	ldp	x9, x8, [x8, #0x10]
    144c:      	add	x10, sp, #0x20
    1450:      	stp	x9, x8, [sp, #0x30]
    1454:      	mov	w8, #0x23               // =35
    1458:      	mov	w9, #0x6                // =6
    145c:      	ldr	x2, [x21, #0xed0]
    1460:      	ldr	x3, [x21, #0xed8]
    1464:      	ldr	x4, [x21, #0xee0]
    1468:      	blr	x9
    146c:      	cmp	x23, #0x100
    1470:      	b.hs	0x11b8 <kprobe_unwind_dotnet+0x11b8>
    1474:      	b	0x1590 <kprobe_unwind_dotnet+0x1590>
    1478:      	ubfx	w3, w25, #24, #4
    147c:      	cbz	w3, 0x1538 <kprobe_unwind_dotnet+0x1538>
    1480:      	sub	x29, x29, #0xc0
    1484:      	b	0x1540 <kprobe_unwind_dotnet+0x1540>
    1488:      	ldr	x8, [x21, #0x1110]
    148c:      	cbz	x8, 0x193c <kprobe_unwind_dotnet+0x193c>
    1490:      	mov	w9, #-0x68              // =-104
    1494:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    1498:      	mov	w8, #0xa                // =10
    149c:      	mov	w11, #0x6               // =6
    14a0:      	add	x0, sp, #0x20
    14a4:      	strh	w8, [sp, #0x60]
    14a8:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    14ac:      	add	x8, x8, #0x0
    14b0:      	mov	w1, #0x42               // =66
    14b4:      	ldp	x9, x10, [x8, #0x20]
    14b8:      	mov	x2, x23
    14bc:      	mov	x4, x25
    14c0:      	stp	x9, x10, [sp, #0x40]
    14c4:      	ldp	x9, x10, [x8, #0x30]
    14c8:      	stp	x9, x10, [sp, #0x50]
    14cc:      	ldp	x9, x10, [x8]
    14d0:      	stp	x9, x10, [sp, #0x20]
    14d4:      	ldp	x9, x8, [x8, #0x10]
    14d8:      	mov	w10, #0x42              // =66
    14dc:      	stp	x9, x8, [sp, #0x30]
    14e0:      	add	x8, sp, #0x20
    14e4:      	ldr	x3, [sp, #0x8]
    14e8:      	blr	x11
    14ec:      	b	0x11d8 <kprobe_unwind_dotnet+0x11d8>
    14f0:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    14f4:      	add	x8, x8, #0x0
    14f8:      	add	x0, sp, #0x20
    14fc:      	ldp	x9, x10, [x8, #0x10]
    1500:      	mov	w1, #0x2e               // =46
    1504:      	stp	x9, x10, [sp, #0x30]
    1508:      	ldr	x9, [x8, #0x20]
    150c:      	add	x10, sp, #0x20
    1510:      	str	x9, [sp, #0x40]
    1514:      	ldur	x9, [x8, #0x26]
    1518:      	stur	x9, [sp, #0x46]
    151c:      	ldp	x9, x8, [x8]
    1520:      	stp	x9, x8, [sp, #0x20]
    1524:      	mov	w8, #0x2e               // =46
    1528:      	mov	w9, #0x6                // =6
    152c:      	ldr	w2, [sp, #0x68]
    1530:      	blr	x9
    1534:      	b	0x10c4 <kprobe_unwind_dotnet+0x10c4>
    1538:      	lsr	w3, w25, #28
    153c:      	sub	x29, x29, #0xe0
    1540:      	ldr	x8, [sp, #0x8]
    1544:      	lsl	w9, w3, #2
    1548:      	sub	w9, w9, #0x4
    154c:      	add	x8, x29, x8
    1550:      	add	x25, x8, x9
    1554:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1558:      	ldr	x8, [x8]
    155c:      	ldr	w8, [x8]
    1560:      	cbnz	w8, 0x19cc <kprobe_unwind_dotnet+0x19cc>
    1564:      	sub	x2, x25, #0x8
    1568:      	mov	w8, #0x8                // =8
    156c:      	mov	w9, #0x70               // =112
    1570:      	add	x10, sp, #0x68
    1574:      	add	x0, sp, #0x68
    1578:      	mov	w1, #0x8                // =8
    157c:      	blr	x9
    1580:      	adrp	x23, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1584:      	ldr	x23, [x23]
    1588:      	cbnz	x0, 0x844 <kprobe_unwind_dotnet+0x844>
    158c:      	mov	w23, #0x1f              // =31
    1590:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1594:      	ldr	x8, [x8]
    1598:      	ldr	w8, [x8]
    159c:      	cbnz	w8, 0x16c8 <kprobe_unwind_dotnet+0x16c8>
    15a0:      	ldr	w8, [x21, #0x2c0]
    15a4:      	cmp	w8, #0x7e
    15a8:      	b.hi	0x8a4 <kprobe_unwind_dotnet+0x8a4>
    15ac:      	ldr	x9, [sp, #0x68]
    15b0:      	add	w11, w8, #0x1
    15b4:      	sub	x10, x24, x25
    15b8:      	adrp	x0, 0x1000 <kprobe_unwind_dotnet+0x1000>
    15bc:      	str	w11, [x21, #0x2c0]
    15c0:      	mov	w11, #0x18              // =24
    15c4:      	add	x1, sp, #0x8c
    15c8:      	umaddl	x8, w8, w11, x21
    15cc:      	add	x9, x23, x9, lsl #5
    15d0:      	str	x10, [x8, #0x2d8]
    15d4:      	mov	w10, #0xa               // =10
    15d8:      	strb	w22, [x8, #0x2e1]
    15dc:      	strh	wzr, [x8, #0x2e6]
    15e0:      	strb	w10, [x8, #0x2e0]
    15e4:      	str	x9, [x8, #0x2d0]
    15e8:      	add	x9, x8, #0x2d0
    15ec:      	mov	w8, #0x5b               // =91
    15f0:      	stur	wzr, [x9, #0x12]
    15f4:      	str	w8, [sp, #0x8c]
    15f8:      	mov	w8, #0x1                // =1
    15fc:      	add	x9, sp, #0x8c
    1600:      	ldr	x0, [x0]
    1604:      	blr	x8
    1608:      	cbz	x0, 0x1624 <kprobe_unwind_dotnet+0x1624>
    160c:      	ldr	x8, [x0]
    1610:      	adrp	x23, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1614:      	add	x8, x8, #0x1
    1618:      	str	x8, [x0]
    161c:      	ldr	x23, [x23]
    1620:      	b	0x1634 <kprobe_unwind_dotnet+0x1634>
    1624:      	adrp	x23, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1628:      	ldr	x23, [x23]
    162c:      	ldr	w8, [x23]
    1630:      	cbnz	w8, 0x18f4 <kprobe_unwind_dotnet+0x18f4>
    1634:      	ldr	x11, [sp, #0x10]
    1638:      	ldr	x29, [x11]
    163c:      	ldr	w8, [x23]
    1640:      	cbz	x29, 0x16a8 <kprobe_unwind_dotnet+0x16a8>
    1644:      	cbnz	w8, 0x1730 <kprobe_unwind_dotnet+0x1730>
    1648:      	lsr	x8, x29, #56
    164c:      	cbz	x8, 0x177c <kprobe_unwind_dotnet+0x177c>
    1650:      	adrp	x23, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1654:      	adrp	x24, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1658:      	ldr	x23, [x23]
    165c:      	ldr	x24, [x24]
    1660:      	ldr	w8, [x23]
    1664:      	cbz	w8, 0xa38 <kprobe_unwind_dotnet+0xa38>
    1668:      	mov	w8, #0xa                // =10
    166c:      	add	x0, sp, #0x20
    1670:      	mov	w1, #0x22               // =34
    1674:      	strh	w8, [sp, #0x40]
    1678:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    167c:      	add	x8, x8, #0x0
    1680:      	mov	x2, x29
    1684:      	ldp	x9, x10, [x8]
    1688:      	stp	x9, x10, [sp, #0x20]
    168c:      	ldp	x9, x8, [x8, #0x10]
    1690:      	add	x10, sp, #0x20
    1694:      	stp	x9, x8, [sp, #0x30]
    1698:      	mov	w8, #0x22               // =34
    169c:      	mov	w9, #0x6                // =6
    16a0:      	blr	x9
    16a4:      	b	0xa38 <kprobe_unwind_dotnet+0xa38>
    16a8:      	adrp	x24, 0x1000 <kprobe_unwind_dotnet+0x1000>
    16ac:      	ldr	x24, [x24]
    16b0:      	cbnz	w8, 0x4d6c <kprobe_unwind_dotnet+0x4d6c>
    16b4:      	mov	w8, #0x1                // =1
    16b8:      	mov	w25, wzr
    16bc:      	str	w8, [x21, #0xf18]
    16c0:      	mov	w8, #0xfad              // =4013
    16c4:      	b	0x4624 <kprobe_unwind_dotnet+0x4624>
    16c8:      	mov	w8, #0x786c             // =30828
    16cc:      	sub	x4, x24, x25
    16d0:      	add	x0, sp, #0x20
    16d4:      	mov	w1, #0x43               // =67
    16d8:      	mov	x2, x25
    16dc:      	movk	w8, #0xa, lsl #16
    16e0:      	stur	w8, [sp, #0x5f]
    16e4:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    16e8:      	add	x8, x8, #0x0
    16ec:      	ldp	x9, x10, [x8, #0x20]
    16f0:      	stp	x9, x10, [sp, #0x40]
    16f4:      	ldp	x9, x10, [x8, #0x30]
    16f8:      	stp	x9, x10, [sp, #0x50]
    16fc:      	ldp	x9, x10, [x8]
    1700:      	stp	x9, x10, [sp, #0x20]
    1704:      	ldp	x9, x8, [x8, #0x10]
    1708:      	add	x10, sp, #0x20
    170c:      	stp	x9, x8, [sp, #0x30]
    1710:      	mov	w8, #0x43               // =67
    1714:      	mov	w9, #0x6                // =6
    1718:      	ldr	x3, [sp, #0x68]
    171c:      	blr	x9
    1720:      	ldr	w8, [x21, #0x2c0]
    1724:      	cmp	w8, #0x7e
    1728:      	b.hi	0x8a4 <kprobe_unwind_dotnet+0x8a4>
    172c:      	b	0x15ac <kprobe_unwind_dotnet+0x15ac>
    1730:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1734:      	add	x8, x8, #0x0
    1738:      	strb	wzr, [sp, #0x50]
    173c:      	add	x0, sp, #0x20
    1740:      	ldp	x9, x10, [x8, #0x10]
    1744:      	mov	w1, #0x31               // =49
    1748:      	stp	x9, x10, [sp, #0x30]
    174c:      	ldp	x9, x10, [x8, #0x20]
    1750:      	stp	x9, x10, [sp, #0x40]
    1754:      	ldp	x9, x8, [x8]
    1758:      	add	x10, sp, #0x20
    175c:      	stp	x9, x8, [sp, #0x20]
    1760:      	mov	w8, #0x31               // =49
    1764:      	mov	w9, #0x6                // =6
    1768:      	ldr	w2, [x21, #0x2c0]
    176c:      	blr	x9
    1770:      	ldr	x29, [x21, #0xed0]
    1774:      	lsr	x8, x29, #56
    1778:      	cbnz	x8, 0x1650 <kprobe_unwind_dotnet+0x1650>
    177c:      	cmp	x29, #0x1, lsl #12      // =0x1000
    1780:      	b.hs	0x17dc <kprobe_unwind_dotnet+0x17dc>
    1784:      	adrp	x23, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1788:      	adrp	x24, 0x1000 <kprobe_unwind_dotnet+0x1000>
    178c:      	ldr	x23, [x23]
    1790:      	ldr	x24, [x24]
    1794:      	ldr	w8, [x23]
    1798:      	cbz	w8, 0xaec <kprobe_unwind_dotnet+0xaec>
    179c:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    17a0:      	add	x8, x8, #0x0
    17a4:      	add	x0, sp, #0x20
    17a8:      	ldp	x9, x10, [x8]
    17ac:      	mov	w1, #0x1e               // =30
    17b0:      	mov	x2, x29
    17b4:      	stp	x9, x10, [sp, #0x20]
    17b8:      	ldr	x9, [x8, #0x10]
    17bc:      	ldur	x8, [x8, #0x16]
    17c0:      	add	x10, sp, #0x20
    17c4:      	str	x9, [sp, #0x30]
    17c8:      	stur	x8, [sp, #0x36]
    17cc:      	mov	w8, #0x1e               // =30
    17d0:      	mov	w9, #0x6                // =6
    17d4:      	blr	x9
    17d8:      	b	0xaec <kprobe_unwind_dotnet+0xaec>
    17dc:      	ldr	w8, [x21]
    17e0:      	mov	w9, #0x60               // =96
    17e4:      	adrp	x0, 0x1000 <kprobe_unwind_dotnet+0x1000>
    17e8:      	add	x1, sp, #0x70
    17ec:      	rev	w8, w8
    17f0:      	stp	w9, w8, [sp, #0x70]
    17f4:      	rev	x8, x29
    17f8:      	add	x9, sp, #0x70
    17fc:      	str	x8, [sp, #0x78]
    1800:      	mov	w8, #0x1                // =1
    1804:      	ldr	x0, [x0]
    1808:      	blr	x8
    180c:      	cbz	x0, 0x4eec <kprobe_unwind_dotnet+0x4eec>
    1810:      	ldr	x8, [x0, #0x8]
    1814:      	and	x9, x8, #0xffffffffffffff
    1818:      	lsr	x25, x8, #56
    181c:      	str	x9, [x21, #0xf10]
    1820:      	ldr	x8, [x0]
    1824:      	str	x8, [x21, #0xf00]
    1828:      	sub	x8, x29, x9
    182c:      	str	x8, [x21, #0xf08]
    1830:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1834:      	ldr	x8, [x8]
    1838:      	ldr	w8, [x8]
    183c:      	cbnz	w8, 0x1a88 <kprobe_unwind_dotnet+0x1a88>
    1840:      	cmp	w25, #0x1
    1844:      	b.ne	0x1cbc <kprobe_unwind_dotnet+0x1cbc>
    1848:      	ldr	x8, [x21, #0xf00]
    184c:      	adrp	x0, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1850:      	ldr	x22, [x21, #0xf08]
    1854:      	mov	w9, #0x1                // =1
    1858:      	add	x1, sp, #0x70
    185c:      	mov	w25, #0x1               // =1
    1860:      	str	x8, [sp, #0x70]
    1864:      	add	x8, sp, #0x70
    1868:      	ldr	x0, [x0]
    186c:      	blr	x9
    1870:      	cbz	x0, 0x18e8 <kprobe_unwind_dotnet+0x18e8>
    1874:      	ldr	x8, [x0]
    1878:      	mov	x23, x0
    187c:      	cmp	x8, x22
    1880:      	b.hi	0x1890 <kprobe_unwind_dotnet+0x1890>
    1884:      	ldr	x8, [x23, #0x8]
    1888:      	cmp	x8, x22
    188c:      	b.hs	0x18a8 <kprobe_unwind_dotnet+0x18a8>
    1890:      	ldr	x8, [x23, #0x10]
    1894:      	cmp	x8, x22
    1898:      	b.hi	0x18d8 <kprobe_unwind_dotnet+0x18d8>
    189c:      	ldr	x8, [x23, #0x18]
    18a0:      	cmp	x8, x22
    18a4:      	b.lo	0x18d8 <kprobe_unwind_dotnet+0x18d8>
    18a8:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    18ac:      	ldr	x8, [x8]
    18b0:      	ldr	w8, [x8]
    18b4:      	cbnz	w8, 0x1c2c <kprobe_unwind_dotnet+0x1c2c>
    18b8:      	ldrh	w8, [x23, #0x20]
    18bc:      	ldr	w9, [x21, #0x1370]
    18c0:      	lsr	w8, w9, w8
    18c4:      	tbz	w8, #0x0, 0x1c78 <kprobe_unwind_dotnet+0x1c78>
    18c8:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    18cc:      	ldr	x8, [x8]
    18d0:      	ldr	w8, [x8]
    18d4:      	cbnz	w8, 0x1fd4 <kprobe_unwind_dotnet+0x1fd4>
    18d8:      	mov	w25, #0x1               // =1
    18dc:      	cmp	w25, #0x8
    18e0:      	b.eq	0x1cc4 <kprobe_unwind_dotnet+0x1cc4>
    18e4:      	b	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    18e8:      	cmp	w25, #0x8
    18ec:      	b.eq	0x1cc4 <kprobe_unwind_dotnet+0x1cc4>
    18f0:      	b	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    18f4:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    18f8:      	add	x8, x8, #0x0
    18fc:      	add	x0, sp, #0x20
    1900:      	ldp	x9, x10, [x8, #0x10]
    1904:      	mov	w1, #0x2e               // =46
    1908:      	stp	x9, x10, [sp, #0x30]
    190c:      	ldr	x9, [x8, #0x20]
    1910:      	add	x10, sp, #0x20
    1914:      	str	x9, [sp, #0x40]
    1918:      	ldur	x9, [x8, #0x26]
    191c:      	stur	x9, [sp, #0x46]
    1920:      	ldp	x9, x8, [x8]
    1924:      	stp	x9, x8, [sp, #0x20]
    1928:      	mov	w8, #0x2e               // =46
    192c:      	mov	w9, #0x6                // =6
    1930:      	ldr	w2, [sp, #0x8c]
    1934:      	blr	x9
    1938:      	b	0x1634 <kprobe_unwind_dotnet+0x1634>
    193c:      	ldr	x8, [x21, #0x1108]
    1940:      	cbz	x8, 0x1a78 <kprobe_unwind_dotnet+0x1a78>
    1944:      	mov	w9, #-0x66              // =-102
    1948:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    194c:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1950:      	add	x8, x8, #0x0
    1954:      	add	x0, sp, #0x20
    1958:      	ldp	x9, x10, [x8, #0x20]
    195c:      	and	x2, x23, #0xfffffffffffffffc
    1960:      	mov	w1, #0x36               // =54
    1964:      	mov	w3, w25
    1968:      	stp	x9, x10, [sp, #0x40]
    196c:      	ldur	x9, [x8, #0x2e]
    1970:      	stur	x9, [sp, #0x4e]
    1974:      	ldp	x9, x10, [x8]
    1978:      	stp	x9, x10, [sp, #0x20]
    197c:      	ldp	x8, x9, [x8, #0x10]
    1980:      	add	x10, sp, #0x20
    1984:      	stp	x8, x9, [sp, #0x30]
    1988:      	mov	w8, #0x36               // =54
    198c:      	mov	w9, #0x6                // =6
    1990:      	blr	x9
    1994:      	mov	w8, #0x1c               // =28
    1998:      	bic	w8, w8, w23, lsr #3
    199c:      	lsr	w25, w25, w8
    19a0:      	cbnz	w25, 0x12a0 <kprobe_unwind_dotnet+0x12a0>
    19a4:      	and	x8, x23, #0xffffffffffffff00
    19a8:      	ldr	w25, [x21, #0x1168]
    19ac:      	sub	x23, x8, #0x20
    19b0:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    19b4:      	ldr	x8, [x8]
    19b8:      	ldr	w8, [x8]
    19bc:      	cbnz	w8, 0x1b30 <kprobe_unwind_dotnet+0x1b30>
    19c0:      	cbz	w25, 0x1b7c <kprobe_unwind_dotnet+0x1b7c>
    19c4:      	mov	w3, wzr
    19c8:      	b	0x60b4 <kprobe_unwind_dotnet+0x60b4>
    19cc:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    19d0:      	add	x8, x8, #0x0
    19d4:      	add	x0, sp, #0x20
    19d8:      	ldp	x9, x10, [x8, #0x10]
    19dc:      	mov	w1, #0x2e               // =46
    19e0:      	mov	x2, x29
    19e4:      	mov	x4, x25
    19e8:      	stp	x9, x10, [sp, #0x30]
    19ec:      	ldr	x9, [x8, #0x20]
    19f0:      	add	x10, sp, #0x20
    19f4:      	str	x9, [sp, #0x40]
    19f8:      	ldur	x9, [x8, #0x26]
    19fc:      	stur	x9, [sp, #0x46]
    1a00:      	ldp	x9, x8, [x8]
    1a04:      	stp	x9, x8, [sp, #0x20]
    1a08:      	mov	w8, #0x2e               // =46
    1a0c:      	mov	w9, #0x6                // =6
    1a10:      	blr	x9
    1a14:      	b	0x1564 <kprobe_unwind_dotnet+0x1564>
    1a18:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1a1c:      	add	x8, x8, #0x0
    1a20:      	add	x0, sp, #0x20
    1a24:      	ldp	x9, x10, [x8, #0x10]
    1a28:      	mov	w1, #0x2e               // =46
    1a2c:      	stp	x9, x10, [sp, #0x30]
    1a30:      	ldr	x9, [x8, #0x20]
    1a34:      	add	x10, sp, #0x20
    1a38:      	str	x9, [sp, #0x40]
    1a3c:      	ldur	x9, [x8, #0x26]
    1a40:      	stur	x9, [sp, #0x46]
    1a44:      	ldp	x9, x8, [x8]
    1a48:      	stp	x9, x8, [sp, #0x20]
    1a4c:      	mov	w8, #0x2e               // =46
    1a50:      	mov	w9, #0x6                // =6
    1a54:      	ldr	w2, [sp, #0x8c]
    1a58:      	blr	x9
    1a5c:      	mov	w22, wzr
    1a60:      	mov	w2, #0x1772             // =6002
    1a64:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1a68:      	ldr	x8, [x8]
    1a6c:      	ldr	w8, [x8]
    1a70:      	cbz	w8, 0x12e4 <kprobe_unwind_dotnet+0x12e4>
    1a74:      	b	0x61e0 <kprobe_unwind_dotnet+0x61e0>
    1a78:      	ldr	x8, [x21, #0x1100]
    1a7c:      	cbz	x8, 0x1bfc <kprobe_unwind_dotnet+0x1bfc>
    1a80:      	mov	w9, #-0x64              // =-100
    1a84:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    1a88:      	mov	w8, #0xa                // =10
    1a8c:      	add	x0, sp, #0x20
    1a90:      	mov	w1, #0x32               // =50
    1a94:      	strh	w8, [sp, #0x50]
    1a98:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1a9c:      	add	x8, x8, #0x0
    1aa0:      	mov	x2, x29
    1aa4:      	ldp	x9, x10, [x8, #0x10]
    1aa8:      	mov	w4, w25
    1aac:      	stp	x9, x10, [sp, #0x30]
    1ab0:      	ldp	x9, x10, [x8, #0x20]
    1ab4:      	stp	x9, x10, [sp, #0x40]
    1ab8:      	ldp	x9, x8, [x8]
    1abc:      	add	x10, sp, #0x20
    1ac0:      	stp	x9, x8, [sp, #0x20]
    1ac4:      	mov	w8, #0x32               // =50
    1ac8:      	mov	w9, #0x6                // =6
    1acc:      	ldr	x3, [x21, #0xf00]
    1ad0:      	blr	x9
    1ad4:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1ad8:      	ldr	x8, [x8]
    1adc:      	ldr	w8, [x8]
    1ae0:      	cbz	w8, 0x1840 <kprobe_unwind_dotnet+0x1840>
    1ae4:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1ae8:      	add	x8, x8, #0x0
    1aec:      	add	x0, sp, #0x20
    1af0:      	ldp	x9, x10, [x8, #0x10]
    1af4:      	mov	w1, #0x2f               // =47
    1af8:      	stp	x9, x10, [sp, #0x30]
    1afc:      	ldr	x9, [x8, #0x20]
    1b00:      	add	x10, sp, #0x20
    1b04:      	str	x9, [sp, #0x40]
    1b08:      	ldur	x9, [x8, #0x27]
    1b0c:      	stur	x9, [sp, #0x47]
    1b10:      	ldp	x9, x8, [x8]
    1b14:      	stp	x9, x8, [sp, #0x20]
    1b18:      	mov	w8, #0x2f               // =47
    1b1c:      	mov	w9, #0x6                // =6
    1b20:      	ldr	x2, [x21, #0xf10]
    1b24:      	ldr	x3, [x21, #0xf08]
    1b28:      	blr	x9
    1b2c:      	b	0x1840 <kprobe_unwind_dotnet+0x1840>
    1b30:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1b34:      	add	x8, x8, #0x0
    1b38:      	add	x0, sp, #0x20
    1b3c:      	ldp	x9, x10, [x8, #0x20]
    1b40:      	mov	w1, #0x37               // =55
    1b44:      	mov	x2, x23
    1b48:      	mov	w3, w25
    1b4c:      	stp	x9, x10, [sp, #0x40]
    1b50:      	ldur	x9, [x8, #0x2f]
    1b54:      	stur	x9, [sp, #0x4f]
    1b58:      	ldp	x9, x10, [x8]
    1b5c:      	stp	x9, x10, [sp, #0x20]
    1b60:      	ldp	x8, x9, [x8, #0x10]
    1b64:      	add	x10, sp, #0x20
    1b68:      	stp	x8, x9, [sp, #0x30]
    1b6c:      	mov	w8, #0x37               // =55
    1b70:      	mov	w9, #0x6                // =6
    1b74:      	blr	x9
    1b78:      	cbnz	w25, 0x19c4 <kprobe_unwind_dotnet+0x19c4>
    1b7c:      	ldr	x8, [x21, #0x1160]
    1b80:      	cbz	x8, 0x1b8c <kprobe_unwind_dotnet+0x1b8c>
    1b84:      	mov	w9, #-0x7c              // =-124
    1b88:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    1b8c:      	ldr	x8, [x21, #0x1158]
    1b90:      	cbz	x8, 0x1b9c <kprobe_unwind_dotnet+0x1b9c>
    1b94:      	mov	w9, #-0x7a              // =-122
    1b98:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    1b9c:      	ldr	x8, [x21, #0x1150]
    1ba0:      	cbz	x8, 0x1bac <kprobe_unwind_dotnet+0x1bac>
    1ba4:      	mov	w9, #-0x78              // =-120
    1ba8:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    1bac:      	ldr	x8, [x21, #0x1148]
    1bb0:      	cbz	x8, 0x1bbc <kprobe_unwind_dotnet+0x1bbc>
    1bb4:      	mov	w9, #-0x76              // =-118
    1bb8:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    1bbc:      	ldr	x8, [x21, #0x1140]
    1bc0:      	cbz	x8, 0x1bcc <kprobe_unwind_dotnet+0x1bcc>
    1bc4:      	mov	w9, #-0x74              // =-116
    1bc8:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    1bcc:      	ldr	x8, [x21, #0x1138]
    1bd0:      	cbz	x8, 0x1bdc <kprobe_unwind_dotnet+0x1bdc>
    1bd4:      	mov	w9, #-0x72              // =-114
    1bd8:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    1bdc:      	ldr	x8, [x21, #0x1130]
    1be0:      	cbz	x8, 0x1bec <kprobe_unwind_dotnet+0x1bec>
    1be4:      	mov	w9, #-0x70              // =-112
    1be8:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    1bec:      	ldr	x8, [x21, #0x1128]
    1bf0:      	cbz	x8, 0x1c0c <kprobe_unwind_dotnet+0x1c0c>
    1bf4:      	mov	w9, #-0x6e              // =-110
    1bf8:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    1bfc:      	ldr	x8, [x21, #0x10f8]
    1c00:      	cbz	x8, 0x1c1c <kprobe_unwind_dotnet+0x1c1c>
    1c04:      	mov	w9, #-0x62              // =-98
    1c08:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    1c0c:      	ldr	x8, [x21, #0x1120]
    1c10:      	cbz	x8, 0x1fc4 <kprobe_unwind_dotnet+0x1fc4>
    1c14:      	mov	w9, #-0x6c              // =-108
    1c18:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    1c1c:      	ldr	x8, [x21, #0x10f0]
    1c20:      	cbz	x8, 0x2020 <kprobe_unwind_dotnet+0x2020>
    1c24:      	mov	w9, #-0x60              // =-96
    1c28:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    1c2c:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1c30:      	add	x8, x8, #0x0
    1c34:      	add	x0, sp, #0x20
    1c38:      	ldp	x9, x10, [x8]
    1c3c:      	mov	w1, #0x1e               // =30
    1c40:      	stp	x9, x10, [sp, #0x20]
    1c44:      	ldr	x9, [x8, #0x10]
    1c48:      	ldur	x8, [x8, #0x16]
    1c4c:      	add	x10, sp, #0x20
    1c50:      	str	x9, [sp, #0x30]
    1c54:      	stur	x8, [sp, #0x36]
    1c58:      	mov	w8, #0x1e               // =30
    1c5c:      	mov	w9, #0x6                // =6
    1c60:      	ldrh	w2, [x23, #0x20]
    1c64:      	blr	x9
    1c68:      	ldrh	w8, [x23, #0x20]
    1c6c:      	ldr	w9, [x21, #0x1370]
    1c70:      	lsr	w8, w9, w8
    1c74:      	tbnz	w8, #0x0, 0x18c8 <kprobe_unwind_dotnet+0x18c8>
    1c78:      	str	wzr, [sp, #0x68]
    1c7c:      	adrp	x0, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1c80:      	mov	w8, #0x1                // =1
    1c84:      	add	x9, sp, #0x68
    1c88:      	ldr	x0, [x0]
    1c8c:      	add	x1, sp, #0x68
    1c90:      	blr	x8
    1c94:      	cbz	x0, 0x1ca8 <kprobe_unwind_dotnet+0x1ca8>
    1c98:      	ldr	x8, [x0]
    1c9c:      	add	x8, x8, #0x1
    1ca0:      	str	x8, [x0]
    1ca4:      	b	0x1cb8 <kprobe_unwind_dotnet+0x1cb8>
    1ca8:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1cac:      	ldr	x8, [x8]
    1cb0:      	ldr	w8, [x8]
    1cb4:      	cbnz	w8, 0x210c <kprobe_unwind_dotnet+0x210c>
    1cb8:      	ldrh	w25, [x23, #0x20]
    1cbc:      	cmp	w25, #0x8
    1cc0:      	b.ne	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    1cc4:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1cc8:      	ldr	x25, [x21, #0xed8]
    1ccc:      	ldr	x29, [x21, #0xee0]
    1cd0:      	ldr	x24, [x21, #0xed0]
    1cd4:      	ldrb	w22, [x21, #0xf20]
    1cd8:      	ldr	x8, [x8]
    1cdc:      	ldr	w8, [x8]
    1ce0:      	cbnz	w8, 0x1f50 <kprobe_unwind_dotnet+0x1f50>
    1ce4:      	cmp	x29, x25
    1ce8:      	b.lo	0x45cc <kprobe_unwind_dotnet+0x45cc>
    1cec:      	add	x8, x25, #0x2, lsl #12  // =0x2000
    1cf0:      	cmp	x29, x8
    1cf4:      	b.hs	0x45cc <kprobe_unwind_dotnet+0x45cc>
    1cf8:      	ldr	x23, [x21, #0xf00]
    1cfc:      	ldr	x25, [x21, #0xf10]
    1d00:      	mov	w8, #0x101              // =257
    1d04:      	str	x24, [sp, #0x68]
    1d08:      	strh	w8, [x21, #0xf20]
    1d0c:      	and	x8, x23, #0xffffffffffffff80
    1d10:      	cmp	x8, #0x80
    1d14:      	b.ne	0x1d4c <kprobe_unwind_dotnet+0x1d4c>
    1d18:      	ldr	x8, [x21, #0xed8]
    1d1c:      	mov	w9, #0x8                // =8
    1d20:      	mov	w10, #0x70              // =112
    1d24:      	ldr	x0, [sp, #0x10]
    1d28:      	mov	w1, #0x8                // =8
    1d2c:      	ldr	x2, [x21, #0xed8]
    1d30:      	blr	x10
    1d34:      	cbnz	x0, 0x1e0 <kprobe_unwind_dotnet+0x1e0>
    1d38:      	ldr	x8, [x21, #0xed8]
    1d3c:      	and	x23, x23, #0x7f
    1d40:      	add	x8, x8, #0x8
    1d44:      	str	x8, [x21, #0xed8]
    1d48:      	b	0x21ac <kprobe_unwind_dotnet+0x21ac>
    1d4c:      	mov	w8, #0x10               // =16
    1d50:      	mov	w9, #0x70               // =112
    1d54:      	add	x10, sp, #0x70
    1d58:      	add	x0, sp, #0x70
    1d5c:      	mov	w1, #0x10               // =16
    1d60:      	mov	x2, x29
    1d64:      	blr	x9
    1d68:      	cbnz	x0, 0x27c <kprobe_unwind_dotnet+0x27c>
    1d6c:      	add	x8, x29, #0x10
    1d70:      	str	x8, [x21, #0xed8]
    1d74:      	ldp	x8, x9, [sp, #0x70]
    1d78:      	str	x8, [x21, #0xee0]
    1d7c:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1d80:      	str	x9, [x21, #0xed0]
    1d84:      	ldr	x8, [x8]
    1d88:      	ldr	w8, [x8]
    1d8c:      	cbnz	w8, 0x2030 <kprobe_unwind_dotnet+0x2030>
    1d90:      	cmp	x23, #0x100
    1d94:      	b.lo	0x21ac <kprobe_unwind_dotnet+0x21ac>
    1d98:      	ldr	x8, [x21, #0xf10]
    1d9c:      	ldr	x25, [x21, #0xf00]
    1da0:      	sub	x23, x24, x8
    1da4:      	str	x8, [sp, #0x8]
    1da8:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1dac:      	ldr	x8, [x8]
    1db0:      	ldr	w8, [x8]
    1db4:      	cbnz	w8, 0x20b4 <kprobe_unwind_dotnet+0x20b4>
    1db8:      	lsr	x8, x23, #8
    1dbc:      	mov	w9, #0x7f               // =127
    1dc0:      	lsr	x10, x23, #15
    1dc4:      	mov	w1, #0x200              // =512
    1dc8:      	sub	w9, w9, w8
    1dcc:      	lsl	x8, x8, #2
    1dd0:      	cmp	x10, #0x0
    1dd4:      	sub	x8, x8, #0x3fc
    1dd8:      	and	x9, x9, #0x7f
    1ddc:      	csel	x8, x8, xzr, ne
    1de0:      	add	x2, x8, x25
    1de4:      	csel	x8, xzr, x9, ne
    1de8:      	ldr	x9, [sp, #0x18]
    1dec:      	add	x0, x9, x8, lsl #2
    1df0:      	mov	w8, #0x200              // =512
    1df4:      	mov	w9, #0x70               // =112
    1df8:      	blr	x9
    1dfc:      	cbz	x0, 0x1e5c <kprobe_unwind_dotnet+0x1e5c>
    1e00:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1e04:      	ldr	x8, [x8]
    1e08:      	ldr	w8, [x8]
    1e0c:      	cbnz	w8, 0x64e4 <kprobe_unwind_dotnet+0x64e4>
    1e10:      	mov	w8, #0x5e               // =94
    1e14:      	adrp	x0, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1e18:      	add	x9, sp, #0x8c
    1e1c:      	str	w8, [sp, #0x8c]
    1e20:      	mov	w8, #0x1                // =1
    1e24:      	add	x1, sp, #0x8c
    1e28:      	ldr	x0, [x0]
    1e2c:      	blr	x8
    1e30:      	cbz	x0, 0x1e9c <kprobe_unwind_dotnet+0x1e9c>
    1e34:      	ldr	x8, [x0]
    1e38:      	add	x8, x8, #0x1
    1e3c:      	str	x8, [x0]
    1e40:      	mov	w22, wzr
    1e44:      	mov	w2, #0x1772             // =6002
    1e48:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1e4c:      	ldr	x8, [x8]
    1e50:      	ldr	w8, [x8]
    1e54:      	cbz	w8, 0x1ec4 <kprobe_unwind_dotnet+0x1ec4>
    1e58:      	b	0x65a4 <kprobe_unwind_dotnet+0x65a4>
    1e5c:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1e60:      	ldr	w25, [x21, #0x116c]
    1e64:      	ldr	x8, [x8]
    1e68:      	ldr	w8, [x8]
    1e6c:      	cbnz	w8, 0x24dc <kprobe_unwind_dotnet+0x24dc>
    1e70:      	mov	w8, #0x1c               // =28
    1e74:      	bic	w8, w8, w23, lsr #3
    1e78:      	lsr	w25, w25, w8
    1e7c:      	cbz	w25, 0x2534 <kprobe_unwind_dotnet+0x2534>
    1e80:      	and	x29, x23, #0xffffffffffffffe0
    1e84:      	ands	w3, w25, #0xf
    1e88:      	b.ne	0x215c <kprobe_unwind_dotnet+0x215c>
    1e8c:      	ubfx	w3, w25, #4, #4
    1e90:      	cbz	w3, 0x1f30 <kprobe_unwind_dotnet+0x1f30>
    1e94:      	sub	x29, x29, #0x20
    1e98:      	b	0x215c <kprobe_unwind_dotnet+0x215c>
    1e9c:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1ea0:      	ldr	x8, [x8]
    1ea4:      	ldr	w8, [x8]
    1ea8:      	cbnz	w8, 0x25a8 <kprobe_unwind_dotnet+0x25a8>
    1eac:      	mov	w22, wzr
    1eb0:      	mov	w2, #0x1772             // =6002
    1eb4:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1eb8:      	ldr	x8, [x8]
    1ebc:      	ldr	w8, [x8]
    1ec0:      	cbnz	w8, 0x65a4 <kprobe_unwind_dotnet+0x65a4>
    1ec4:      	cbz	w22, 0x621c <kprobe_unwind_dotnet+0x621c>
    1ec8:      	ldr	w8, [x21, #0x2c0]
    1ecc:      	adrp	x23, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1ed0:      	adrp	x24, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1ed4:      	ldr	x23, [x23]
    1ed8:      	ldr	x24, [x24]
    1edc:      	cmp	w8, #0x7e
    1ee0:      	b.hi	0x49c <kprobe_unwind_dotnet+0x49c>
    1ee4:      	add	w9, w8, #0x1
    1ee8:      	mov	w10, #0x8a              // =138
    1eec:      	str	w9, [x21, #0x2c0]
    1ef0:      	mov	w9, #0x18               // =24
    1ef4:      	umaddl	x8, w8, w9, x21
    1ef8:      	mov	w9, #0x1773             // =6003
    1efc:      	str	x9, [x8, #0x2d8]
    1f00:      	add	x9, x8, #0x2d0
    1f04:      	str	xzr, [x8, #0x2d0]
    1f08:      	strb	w10, [x8, #0x2e0]
    1f0c:      	str	wzr, [x8, #0x2e4]
    1f10:      	stur	wzr, [x9, #0x11]
    1f14:      	ldr	x8, [sp, #0x10]
    1f18:      	ldr	x29, [x8]
    1f1c:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1f20:      	ldr	x8, [x8]
    1f24:      	ldr	w8, [x8]
    1f28:      	cbnz	x29, 0x2278 <kprobe_unwind_dotnet+0x2278>
    1f2c:      	b	0x4d58 <kprobe_unwind_dotnet+0x4d58>
    1f30:      	ubfx	w3, w25, #8, #4
    1f34:      	cbz	w3, 0x1f40 <kprobe_unwind_dotnet+0x1f40>
    1f38:      	sub	x29, x29, #0x40
    1f3c:      	b	0x215c <kprobe_unwind_dotnet+0x215c>
    1f40:      	ubfx	w3, w25, #12, #4
    1f44:      	cbz	w3, 0x1fa4 <kprobe_unwind_dotnet+0x1fa4>
    1f48:      	sub	x29, x29, #0x60
    1f4c:      	b	0x215c <kprobe_unwind_dotnet+0x215c>
    1f50:      	mov	w8, #0x786c             // =30828
    1f54:      	add	x0, sp, #0x20
    1f58:      	mov	w1, #0x23               // =35
    1f5c:      	mov	x2, x24
    1f60:      	mov	x3, x25
    1f64:      	mov	x4, x29
    1f68:      	movk	w8, #0xa, lsl #16
    1f6c:      	stur	w8, [sp, #0x3f]
    1f70:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1f74:      	add	x8, x8, #0x0
    1f78:      	ldp	x9, x10, [x8]
    1f7c:      	stp	x9, x10, [sp, #0x20]
    1f80:      	ldp	x9, x8, [x8, #0x10]
    1f84:      	add	x10, sp, #0x20
    1f88:      	stp	x9, x8, [sp, #0x30]
    1f8c:      	mov	w8, #0x23               // =35
    1f90:      	mov	w9, #0x6                // =6
    1f94:      	blr	x9
    1f98:      	cmp	x29, x25
    1f9c:      	b.hs	0x1cec <kprobe_unwind_dotnet+0x1cec>
    1fa0:      	b	0x45cc <kprobe_unwind_dotnet+0x45cc>
    1fa4:      	ubfx	w3, w25, #16, #4
    1fa8:      	cbz	w3, 0x1fb4 <kprobe_unwind_dotnet+0x1fb4>
    1fac:      	sub	x29, x29, #0x80
    1fb0:      	b	0x215c <kprobe_unwind_dotnet+0x215c>
    1fb4:      	ubfx	w3, w25, #20, #4
    1fb8:      	cbz	w3, 0x2084 <kprobe_unwind_dotnet+0x2084>
    1fbc:      	sub	x29, x29, #0xa0
    1fc0:      	b	0x215c <kprobe_unwind_dotnet+0x215c>
    1fc4:      	ldr	x8, [x21, #0x1118]
    1fc8:      	cbz	x8, 0x2094 <kprobe_unwind_dotnet+0x2094>
    1fcc:      	mov	w9, #-0x6a              // =-106
    1fd0:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    1fd4:      	mov	w8, #0x656e             // =25966
    1fd8:      	add	x0, sp, #0x20
    1fdc:      	mov	w1, #0x1b               // =27
    1fe0:      	movk	w8, #0xa, lsl #16
    1fe4:      	stur	w8, [sp, #0x37]
    1fe8:      	adrp	x8, 0x1000 <kprobe_unwind_dotnet+0x1000>
    1fec:      	add	x8, x8, #0x0
    1ff0:      	ldp	x9, x10, [x8]
    1ff4:      	ldr	x8, [x8, #0x10]
    1ff8:      	stp	x9, x10, [sp, #0x20]
    1ffc:      	str	x8, [sp, #0x30]
    2000:      	mov	w8, #0x1b               // =27
    2004:      	mov	w9, #0x6                // =6
    2008:      	add	x10, sp, #0x20
    200c:      	blr	x9
    2010:      	mov	w25, #0x1               // =1
    2014:      	cmp	w25, #0x8
    2018:      	b.eq	0x1cc4 <kprobe_unwind_dotnet+0x1cc4>
    201c:      	b	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    2020:      	ldr	x8, [x21, #0x10e8]
    2024:      	cbz	x8, 0x20a4 <kprobe_unwind_dotnet+0x20a4>
    2028:      	mov	w9, #-0x5e              // =-94
    202c:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    2030:      	mov	w8, #0x786c             // =30828
    2034:      	add	x0, sp, #0x20
    2038:      	mov	w1, #0x23               // =35
    203c:      	movk	w8, #0xa, lsl #16
    2040:      	stur	w8, [sp, #0x3f]
    2044:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2048:      	add	x8, x8, #0x0
    204c:      	ldp	x9, x10, [x8]
    2050:      	stp	x9, x10, [sp, #0x20]
    2054:      	ldp	x9, x8, [x8, #0x10]
    2058:      	add	x10, sp, #0x20
    205c:      	stp	x9, x8, [sp, #0x30]
    2060:      	mov	w8, #0x23               // =35
    2064:      	mov	w9, #0x6                // =6
    2068:      	ldr	x2, [x21, #0xed0]
    206c:      	ldr	x3, [x21, #0xed8]
    2070:      	ldr	x4, [x21, #0xee0]
    2074:      	blr	x9
    2078:      	cmp	x23, #0x100
    207c:      	b.hs	0x1d98 <kprobe_unwind_dotnet+0x1d98>
    2080:      	b	0x21ac <kprobe_unwind_dotnet+0x21ac>
    2084:      	ubfx	w3, w25, #24, #4
    2088:      	cbz	w3, 0x2154 <kprobe_unwind_dotnet+0x2154>
    208c:      	sub	x29, x29, #0xc0
    2090:      	b	0x215c <kprobe_unwind_dotnet+0x215c>
    2094:      	ldr	x8, [x21, #0x1110]
    2098:      	cbz	x8, 0x24bc <kprobe_unwind_dotnet+0x24bc>
    209c:      	mov	w9, #-0x68              // =-104
    20a0:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    20a4:      	ldr	x8, [x21, #0x10e0]
    20a8:      	cbz	x8, 0x24cc <kprobe_unwind_dotnet+0x24cc>
    20ac:      	mov	w9, #-0x5c              // =-92
    20b0:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    20b4:      	mov	w8, #0xa                // =10
    20b8:      	mov	w11, #0x6               // =6
    20bc:      	add	x0, sp, #0x20
    20c0:      	strh	w8, [sp, #0x60]
    20c4:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    20c8:      	add	x8, x8, #0x0
    20cc:      	mov	w1, #0x42               // =66
    20d0:      	ldp	x9, x10, [x8, #0x20]
    20d4:      	mov	x2, x23
    20d8:      	mov	x4, x25
    20dc:      	stp	x9, x10, [sp, #0x40]
    20e0:      	ldp	x9, x10, [x8, #0x30]
    20e4:      	stp	x9, x10, [sp, #0x50]
    20e8:      	ldp	x9, x10, [x8]
    20ec:      	stp	x9, x10, [sp, #0x20]
    20f0:      	ldp	x9, x8, [x8, #0x10]
    20f4:      	mov	w10, #0x42              // =66
    20f8:      	stp	x9, x8, [sp, #0x30]
    20fc:      	add	x8, sp, #0x20
    2100:      	ldr	x3, [sp, #0x8]
    2104:      	blr	x11
    2108:      	b	0x1db8 <kprobe_unwind_dotnet+0x1db8>
    210c:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2110:      	add	x8, x8, #0x0
    2114:      	add	x0, sp, #0x20
    2118:      	ldp	x9, x10, [x8, #0x10]
    211c:      	mov	w1, #0x2e               // =46
    2120:      	stp	x9, x10, [sp, #0x30]
    2124:      	ldr	x9, [x8, #0x20]
    2128:      	add	x10, sp, #0x20
    212c:      	str	x9, [sp, #0x40]
    2130:      	ldur	x9, [x8, #0x26]
    2134:      	stur	x9, [sp, #0x46]
    2138:      	ldp	x9, x8, [x8]
    213c:      	stp	x9, x8, [sp, #0x20]
    2140:      	mov	w8, #0x2e               // =46
    2144:      	mov	w9, #0x6                // =6
    2148:      	ldr	w2, [sp, #0x68]
    214c:      	blr	x9
    2150:      	b	0x1cb8 <kprobe_unwind_dotnet+0x1cb8>
    2154:      	lsr	w3, w25, #28
    2158:      	sub	x29, x29, #0xe0
    215c:      	ldr	x8, [sp, #0x8]
    2160:      	lsl	w9, w3, #2
    2164:      	sub	w9, w9, #0x4
    2168:      	add	x8, x29, x8
    216c:      	add	x25, x8, x9
    2170:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2174:      	ldr	x8, [x8]
    2178:      	ldr	w8, [x8]
    217c:      	cbnz	w8, 0x255c <kprobe_unwind_dotnet+0x255c>
    2180:      	sub	x2, x25, #0x8
    2184:      	mov	w8, #0x8                // =8
    2188:      	mov	w9, #0x70               // =112
    218c:      	add	x10, sp, #0x68
    2190:      	add	x0, sp, #0x68
    2194:      	mov	w1, #0x8                // =8
    2198:      	blr	x9
    219c:      	adrp	x23, 0x2000 <kprobe_unwind_dotnet+0x2000>
    21a0:      	ldr	x23, [x23]
    21a4:      	cbnz	x0, 0x844 <kprobe_unwind_dotnet+0x844>
    21a8:      	mov	w23, #0x1f              // =31
    21ac:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    21b0:      	ldr	x8, [x8]
    21b4:      	ldr	w8, [x8]
    21b8:      	cbnz	w8, 0x23a4 <kprobe_unwind_dotnet+0x23a4>
    21bc:      	ldr	w8, [x21, #0x2c0]
    21c0:      	cmp	w8, #0x7e
    21c4:      	b.hi	0x8a4 <kprobe_unwind_dotnet+0x8a4>
    21c8:      	ldr	x9, [sp, #0x68]
    21cc:      	add	w11, w8, #0x1
    21d0:      	sub	x10, x24, x25
    21d4:      	adrp	x0, 0x2000 <kprobe_unwind_dotnet+0x2000>
    21d8:      	str	w11, [x21, #0x2c0]
    21dc:      	mov	w11, #0x18              // =24
    21e0:      	add	x1, sp, #0x8c
    21e4:      	umaddl	x8, w8, w11, x21
    21e8:      	add	x9, x23, x9, lsl #5
    21ec:      	str	x10, [x8, #0x2d8]
    21f0:      	mov	w10, #0xa               // =10
    21f4:      	strb	w22, [x8, #0x2e1]
    21f8:      	strh	wzr, [x8, #0x2e6]
    21fc:      	strb	w10, [x8, #0x2e0]
    2200:      	str	x9, [x8, #0x2d0]
    2204:      	add	x9, x8, #0x2d0
    2208:      	mov	w8, #0x5b               // =91
    220c:      	stur	wzr, [x9, #0x12]
    2210:      	str	w8, [sp, #0x8c]
    2214:      	mov	w8, #0x1                // =1
    2218:      	add	x9, sp, #0x8c
    221c:      	ldr	x0, [x0]
    2220:      	blr	x8
    2224:      	cbz	x0, 0x2250 <kprobe_unwind_dotnet+0x2250>
    2228:      	ldr	x8, [x0]
    222c:      	add	x8, x8, #0x1
    2230:      	str	x8, [x0]
    2234:      	ldr	x8, [sp, #0x10]
    2238:      	ldr	x29, [x8]
    223c:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2240:      	ldr	x8, [x8]
    2244:      	ldr	w8, [x8]
    2248:      	cbnz	x29, 0x2278 <kprobe_unwind_dotnet+0x2278>
    224c:      	b	0x4d58 <kprobe_unwind_dotnet+0x4d58>
    2250:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2254:      	ldr	x8, [x8]
    2258:      	ldr	w8, [x8]
    225c:      	cbnz	w8, 0x245c <kprobe_unwind_dotnet+0x245c>
    2260:      	ldr	x8, [sp, #0x10]
    2264:      	ldr	x29, [x8]
    2268:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    226c:      	ldr	x8, [x8]
    2270:      	ldr	w8, [x8]
    2274:      	cbz	x29, 0x4d58 <kprobe_unwind_dotnet+0x4d58>
    2278:      	cbnz	w8, 0x240c <kprobe_unwind_dotnet+0x240c>
    227c:      	lsr	x8, x29, #56
    2280:      	cbnz	x8, 0x1650 <kprobe_unwind_dotnet+0x1650>
    2284:      	cmp	x29, #0x1, lsl #12      // =0x1000
    2288:      	b.lo	0x1784 <kprobe_unwind_dotnet+0x1784>
    228c:      	ldr	w8, [x21]
    2290:      	mov	w9, #0x60               // =96
    2294:      	adrp	x0, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2298:      	add	x1, sp, #0x70
    229c:      	rev	w8, w8
    22a0:      	stp	w9, w8, [sp, #0x70]
    22a4:      	rev	x8, x29
    22a8:      	add	x9, sp, #0x70
    22ac:      	str	x8, [sp, #0x78]
    22b0:      	mov	w8, #0x1                // =1
    22b4:      	ldr	x0, [x0]
    22b8:      	blr	x8
    22bc:      	cbz	x0, 0x4eec <kprobe_unwind_dotnet+0x4eec>
    22c0:      	ldr	x8, [x0, #0x8]
    22c4:      	and	x9, x8, #0xffffffffffffff
    22c8:      	lsr	x25, x8, #56
    22cc:      	str	x9, [x21, #0xf10]
    22d0:      	ldr	x8, [x0]
    22d4:      	str	x8, [x21, #0xf00]
    22d8:      	sub	x8, x29, x9
    22dc:      	str	x8, [x21, #0xf08]
    22e0:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    22e4:      	ldr	x8, [x8]
    22e8:      	ldr	w8, [x8]
    22ec:      	cbnz	w8, 0x2618 <kprobe_unwind_dotnet+0x2618>
    22f0:      	cmp	w25, #0x1
    22f4:      	b.ne	0x286c <kprobe_unwind_dotnet+0x286c>
    22f8:      	ldr	x8, [x21, #0xf00]
    22fc:      	adrp	x0, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2300:      	ldr	x22, [x21, #0xf08]
    2304:      	mov	w9, #0x1                // =1
    2308:      	add	x1, sp, #0x70
    230c:      	mov	w25, #0x1               // =1
    2310:      	str	x8, [sp, #0x70]
    2314:      	add	x8, sp, #0x70
    2318:      	ldr	x0, [x0]
    231c:      	blr	x9
    2320:      	cbz	x0, 0x2398 <kprobe_unwind_dotnet+0x2398>
    2324:      	ldr	x8, [x0]
    2328:      	mov	x23, x0
    232c:      	cmp	x8, x22
    2330:      	b.hi	0x2340 <kprobe_unwind_dotnet+0x2340>
    2334:      	ldr	x8, [x23, #0x8]
    2338:      	cmp	x8, x22
    233c:      	b.hs	0x2358 <kprobe_unwind_dotnet+0x2358>
    2340:      	ldr	x8, [x23, #0x10]
    2344:      	cmp	x8, x22
    2348:      	b.hi	0x2388 <kprobe_unwind_dotnet+0x2388>
    234c:      	ldr	x8, [x23, #0x18]
    2350:      	cmp	x8, x22
    2354:      	b.lo	0x2388 <kprobe_unwind_dotnet+0x2388>
    2358:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    235c:      	ldr	x8, [x8]
    2360:      	ldr	w8, [x8]
    2364:      	cbnz	w8, 0x27dc <kprobe_unwind_dotnet+0x27dc>
    2368:      	ldrh	w8, [x23, #0x20]
    236c:      	ldr	w9, [x21, #0x1370]
    2370:      	lsr	w8, w9, w8
    2374:      	tbz	w8, #0x0, 0x2828 <kprobe_unwind_dotnet+0x2828>
    2378:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    237c:      	ldr	x8, [x8]
    2380:      	ldr	w8, [x8]
    2384:      	cbnz	w8, 0x2b94 <kprobe_unwind_dotnet+0x2b94>
    2388:      	mov	w25, #0x1               // =1
    238c:      	cmp	w25, #0x8
    2390:      	b.eq	0x2874 <kprobe_unwind_dotnet+0x2874>
    2394:      	b	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    2398:      	cmp	w25, #0x8
    239c:      	b.eq	0x2874 <kprobe_unwind_dotnet+0x2874>
    23a0:      	b	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    23a4:      	mov	w8, #0x786c             // =30828
    23a8:      	sub	x4, x24, x25
    23ac:      	add	x0, sp, #0x20
    23b0:      	mov	w1, #0x43               // =67
    23b4:      	mov	x2, x25
    23b8:      	movk	w8, #0xa, lsl #16
    23bc:      	stur	w8, [sp, #0x5f]
    23c0:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    23c4:      	add	x8, x8, #0x0
    23c8:      	ldp	x9, x10, [x8, #0x20]
    23cc:      	stp	x9, x10, [sp, #0x40]
    23d0:      	ldp	x9, x10, [x8, #0x30]
    23d4:      	stp	x9, x10, [sp, #0x50]
    23d8:      	ldp	x9, x10, [x8]
    23dc:      	stp	x9, x10, [sp, #0x20]
    23e0:      	ldp	x9, x8, [x8, #0x10]
    23e4:      	add	x10, sp, #0x20
    23e8:      	stp	x9, x8, [sp, #0x30]
    23ec:      	mov	w8, #0x43               // =67
    23f0:      	mov	w9, #0x6                // =6
    23f4:      	ldr	x3, [sp, #0x68]
    23f8:      	blr	x9
    23fc:      	ldr	w8, [x21, #0x2c0]
    2400:      	cmp	w8, #0x7e
    2404:      	b.hi	0x8a4 <kprobe_unwind_dotnet+0x8a4>
    2408:      	b	0x21c8 <kprobe_unwind_dotnet+0x21c8>
    240c:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2410:      	add	x8, x8, #0x0
    2414:      	strb	wzr, [sp, #0x50]
    2418:      	add	x0, sp, #0x20
    241c:      	ldp	x9, x10, [x8, #0x10]
    2420:      	mov	w1, #0x31               // =49
    2424:      	stp	x9, x10, [sp, #0x30]
    2428:      	ldp	x9, x10, [x8, #0x20]
    242c:      	stp	x9, x10, [sp, #0x40]
    2430:      	ldp	x9, x8, [x8]
    2434:      	add	x10, sp, #0x20
    2438:      	stp	x9, x8, [sp, #0x20]
    243c:      	mov	w8, #0x31               // =49
    2440:      	mov	w9, #0x6                // =6
    2444:      	ldr	w2, [x21, #0x2c0]
    2448:      	blr	x9
    244c:      	ldr	x29, [x21, #0xed0]
    2450:      	lsr	x8, x29, #56
    2454:      	cbnz	x8, 0x1650 <kprobe_unwind_dotnet+0x1650>
    2458:      	b	0x2284 <kprobe_unwind_dotnet+0x2284>
    245c:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2460:      	add	x8, x8, #0x0
    2464:      	add	x0, sp, #0x20
    2468:      	ldp	x9, x10, [x8, #0x10]
    246c:      	mov	w1, #0x2e               // =46
    2470:      	stp	x9, x10, [sp, #0x30]
    2474:      	ldr	x9, [x8, #0x20]
    2478:      	add	x10, sp, #0x20
    247c:      	str	x9, [sp, #0x40]
    2480:      	ldur	x9, [x8, #0x26]
    2484:      	stur	x9, [sp, #0x46]
    2488:      	ldp	x9, x8, [x8]
    248c:      	stp	x9, x8, [sp, #0x20]
    2490:      	mov	w8, #0x2e               // =46
    2494:      	mov	w9, #0x6                // =6
    2498:      	ldr	w2, [sp, #0x8c]
    249c:      	blr	x9
    24a0:      	ldr	x8, [sp, #0x10]
    24a4:      	ldr	x29, [x8]
    24a8:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    24ac:      	ldr	x8, [x8]
    24b0:      	ldr	w8, [x8]
    24b4:      	cbnz	x29, 0x2278 <kprobe_unwind_dotnet+0x2278>
    24b8:      	b	0x4d58 <kprobe_unwind_dotnet+0x4d58>
    24bc:      	ldr	x8, [x21, #0x1108]
    24c0:      	cbz	x8, 0x2608 <kprobe_unwind_dotnet+0x2608>
    24c4:      	mov	w9, #-0x66              // =-102
    24c8:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    24cc:      	ldr	x8, [x21, #0x10d8]
    24d0:      	cbz	x8, 0x26c0 <kprobe_unwind_dotnet+0x26c0>
    24d4:      	mov	w9, #-0x5a              // =-90
    24d8:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    24dc:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    24e0:      	add	x8, x8, #0x0
    24e4:      	add	x0, sp, #0x20
    24e8:      	ldp	x9, x10, [x8, #0x20]
    24ec:      	and	x2, x23, #0xfffffffffffffffc
    24f0:      	mov	w1, #0x36               // =54
    24f4:      	mov	w3, w25
    24f8:      	stp	x9, x10, [sp, #0x40]
    24fc:      	ldur	x9, [x8, #0x2e]
    2500:      	stur	x9, [sp, #0x4e]
    2504:      	ldp	x9, x10, [x8]
    2508:      	stp	x9, x10, [sp, #0x20]
    250c:      	ldp	x8, x9, [x8, #0x10]
    2510:      	add	x10, sp, #0x20
    2514:      	stp	x8, x9, [sp, #0x30]
    2518:      	mov	w8, #0x36               // =54
    251c:      	mov	w9, #0x6                // =6
    2520:      	blr	x9
    2524:      	mov	w8, #0x1c               // =28
    2528:      	bic	w8, w8, w23, lsr #3
    252c:      	lsr	w25, w25, w8
    2530:      	cbnz	w25, 0x1e80 <kprobe_unwind_dotnet+0x1e80>
    2534:      	and	x8, x23, #0xffffffffffffff00
    2538:      	ldr	w25, [x21, #0x1168]
    253c:      	sub	x23, x8, #0x20
    2540:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2544:      	ldr	x8, [x8]
    2548:      	ldr	w8, [x8]
    254c:      	cbnz	w8, 0x26d0 <kprobe_unwind_dotnet+0x26d0>
    2550:      	cbz	w25, 0x271c <kprobe_unwind_dotnet+0x271c>
    2554:      	mov	w3, wzr
    2558:      	b	0x6478 <kprobe_unwind_dotnet+0x6478>
    255c:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2560:      	add	x8, x8, #0x0
    2564:      	add	x0, sp, #0x20
    2568:      	ldp	x9, x10, [x8, #0x10]
    256c:      	mov	w1, #0x2e               // =46
    2570:      	mov	x2, x29
    2574:      	mov	x4, x25
    2578:      	stp	x9, x10, [sp, #0x30]
    257c:      	ldr	x9, [x8, #0x20]
    2580:      	add	x10, sp, #0x20
    2584:      	str	x9, [sp, #0x40]
    2588:      	ldur	x9, [x8, #0x26]
    258c:      	stur	x9, [sp, #0x46]
    2590:      	ldp	x9, x8, [x8]
    2594:      	stp	x9, x8, [sp, #0x20]
    2598:      	mov	w8, #0x2e               // =46
    259c:      	mov	w9, #0x6                // =6
    25a0:      	blr	x9
    25a4:      	b	0x2180 <kprobe_unwind_dotnet+0x2180>
    25a8:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    25ac:      	add	x8, x8, #0x0
    25b0:      	add	x0, sp, #0x20
    25b4:      	ldp	x9, x10, [x8, #0x10]
    25b8:      	mov	w1, #0x2e               // =46
    25bc:      	stp	x9, x10, [sp, #0x30]
    25c0:      	ldr	x9, [x8, #0x20]
    25c4:      	add	x10, sp, #0x20
    25c8:      	str	x9, [sp, #0x40]
    25cc:      	ldur	x9, [x8, #0x26]
    25d0:      	stur	x9, [sp, #0x46]
    25d4:      	ldp	x9, x8, [x8]
    25d8:      	stp	x9, x8, [sp, #0x20]
    25dc:      	mov	w8, #0x2e               // =46
    25e0:      	mov	w9, #0x6                // =6
    25e4:      	ldr	w2, [sp, #0x8c]
    25e8:      	blr	x9
    25ec:      	mov	w22, wzr
    25f0:      	mov	w2, #0x1772             // =6002
    25f4:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    25f8:      	ldr	x8, [x8]
    25fc:      	ldr	w8, [x8]
    2600:      	cbz	w8, 0x1ec4 <kprobe_unwind_dotnet+0x1ec4>
    2604:      	b	0x65a4 <kprobe_unwind_dotnet+0x65a4>
    2608:      	ldr	x8, [x21, #0x1100]
    260c:      	cbz	x8, 0x279c <kprobe_unwind_dotnet+0x279c>
    2610:      	mov	w9, #-0x64              // =-100
    2614:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    2618:      	mov	w8, #0xa                // =10
    261c:      	add	x0, sp, #0x20
    2620:      	mov	w1, #0x32               // =50
    2624:      	strh	w8, [sp, #0x50]
    2628:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    262c:      	add	x8, x8, #0x0
    2630:      	mov	x2, x29
    2634:      	ldp	x9, x10, [x8, #0x10]
    2638:      	mov	w4, w25
    263c:      	stp	x9, x10, [sp, #0x30]
    2640:      	ldp	x9, x10, [x8, #0x20]
    2644:      	stp	x9, x10, [sp, #0x40]
    2648:      	ldp	x9, x8, [x8]
    264c:      	add	x10, sp, #0x20
    2650:      	stp	x9, x8, [sp, #0x20]
    2654:      	mov	w8, #0x32               // =50
    2658:      	mov	w9, #0x6                // =6
    265c:      	ldr	x3, [x21, #0xf00]
    2660:      	blr	x9
    2664:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2668:      	ldr	x8, [x8]
    266c:      	ldr	w8, [x8]
    2670:      	cbz	w8, 0x22f0 <kprobe_unwind_dotnet+0x22f0>
    2674:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2678:      	add	x8, x8, #0x0
    267c:      	add	x0, sp, #0x20
    2680:      	ldp	x9, x10, [x8, #0x10]
    2684:      	mov	w1, #0x2f               // =47
    2688:      	stp	x9, x10, [sp, #0x30]
    268c:      	ldr	x9, [x8, #0x20]
    2690:      	add	x10, sp, #0x20
    2694:      	str	x9, [sp, #0x40]
    2698:      	ldur	x9, [x8, #0x27]
    269c:      	stur	x9, [sp, #0x47]
    26a0:      	ldp	x9, x8, [x8]
    26a4:      	stp	x9, x8, [sp, #0x20]
    26a8:      	mov	w8, #0x2f               // =47
    26ac:      	mov	w9, #0x6                // =6
    26b0:      	ldr	x2, [x21, #0xf10]
    26b4:      	ldr	x3, [x21, #0xf08]
    26b8:      	blr	x9
    26bc:      	b	0x22f0 <kprobe_unwind_dotnet+0x22f0>
    26c0:      	ldr	x8, [x21, #0x10d0]
    26c4:      	cbz	x8, 0x27ac <kprobe_unwind_dotnet+0x27ac>
    26c8:      	mov	w9, #-0x58              // =-88
    26cc:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    26d0:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    26d4:      	add	x8, x8, #0x0
    26d8:      	add	x0, sp, #0x20
    26dc:      	ldp	x9, x10, [x8, #0x20]
    26e0:      	mov	w1, #0x37               // =55
    26e4:      	mov	x2, x23
    26e8:      	mov	w3, w25
    26ec:      	stp	x9, x10, [sp, #0x40]
    26f0:      	ldur	x9, [x8, #0x2f]
    26f4:      	stur	x9, [sp, #0x4f]
    26f8:      	ldp	x9, x10, [x8]
    26fc:      	stp	x9, x10, [sp, #0x20]
    2700:      	ldp	x8, x9, [x8, #0x10]
    2704:      	add	x10, sp, #0x20
    2708:      	stp	x8, x9, [sp, #0x30]
    270c:      	mov	w8, #0x37               // =55
    2710:      	mov	w9, #0x6                // =6
    2714:      	blr	x9
    2718:      	cbnz	w25, 0x2554 <kprobe_unwind_dotnet+0x2554>
    271c:      	ldr	x8, [x21, #0x1160]
    2720:      	cbz	x8, 0x272c <kprobe_unwind_dotnet+0x272c>
    2724:      	mov	w9, #-0x7c              // =-124
    2728:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    272c:      	ldr	x8, [x21, #0x1158]
    2730:      	cbz	x8, 0x273c <kprobe_unwind_dotnet+0x273c>
    2734:      	mov	w9, #-0x7a              // =-122
    2738:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    273c:      	ldr	x8, [x21, #0x1150]
    2740:      	cbz	x8, 0x274c <kprobe_unwind_dotnet+0x274c>
    2744:      	mov	w9, #-0x78              // =-120
    2748:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    274c:      	ldr	x8, [x21, #0x1148]
    2750:      	cbz	x8, 0x275c <kprobe_unwind_dotnet+0x275c>
    2754:      	mov	w9, #-0x76              // =-118
    2758:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    275c:      	ldr	x8, [x21, #0x1140]
    2760:      	cbz	x8, 0x276c <kprobe_unwind_dotnet+0x276c>
    2764:      	mov	w9, #-0x74              // =-116
    2768:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    276c:      	ldr	x8, [x21, #0x1138]
    2770:      	cbz	x8, 0x277c <kprobe_unwind_dotnet+0x277c>
    2774:      	mov	w9, #-0x72              // =-114
    2778:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    277c:      	ldr	x8, [x21, #0x1130]
    2780:      	cbz	x8, 0x278c <kprobe_unwind_dotnet+0x278c>
    2784:      	mov	w9, #-0x70              // =-112
    2788:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    278c:      	ldr	x8, [x21, #0x1128]
    2790:      	cbz	x8, 0x27bc <kprobe_unwind_dotnet+0x27bc>
    2794:      	mov	w9, #-0x6e              // =-110
    2798:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    279c:      	ldr	x8, [x21, #0x10f8]
    27a0:      	cbz	x8, 0x27cc <kprobe_unwind_dotnet+0x27cc>
    27a4:      	mov	w9, #-0x62              // =-98
    27a8:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    27ac:      	ldr	x8, [x21, #0x10c8]
    27b0:      	cbz	x8, 0x2b64 <kprobe_unwind_dotnet+0x2b64>
    27b4:      	mov	w9, #-0x56              // =-86
    27b8:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    27bc:      	ldr	x8, [x21, #0x1120]
    27c0:      	cbz	x8, 0x2b84 <kprobe_unwind_dotnet+0x2b84>
    27c4:      	mov	w9, #-0x6c              // =-108
    27c8:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    27cc:      	ldr	x8, [x21, #0x10f0]
    27d0:      	cbz	x8, 0x2be0 <kprobe_unwind_dotnet+0x2be0>
    27d4:      	mov	w9, #-0x60              // =-96
    27d8:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    27dc:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    27e0:      	add	x8, x8, #0x0
    27e4:      	add	x0, sp, #0x20
    27e8:      	ldp	x9, x10, [x8]
    27ec:      	mov	w1, #0x1e               // =30
    27f0:      	stp	x9, x10, [sp, #0x20]
    27f4:      	ldr	x9, [x8, #0x10]
    27f8:      	ldur	x8, [x8, #0x16]
    27fc:      	add	x10, sp, #0x20
    2800:      	str	x9, [sp, #0x30]
    2804:      	stur	x8, [sp, #0x36]
    2808:      	mov	w8, #0x1e               // =30
    280c:      	mov	w9, #0x6                // =6
    2810:      	ldrh	w2, [x23, #0x20]
    2814:      	blr	x9
    2818:      	ldrh	w8, [x23, #0x20]
    281c:      	ldr	w9, [x21, #0x1370]
    2820:      	lsr	w8, w9, w8
    2824:      	tbnz	w8, #0x0, 0x2378 <kprobe_unwind_dotnet+0x2378>
    2828:      	str	wzr, [sp, #0x68]
    282c:      	adrp	x0, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2830:      	mov	w8, #0x1                // =1
    2834:      	add	x9, sp, #0x68
    2838:      	ldr	x0, [x0]
    283c:      	add	x1, sp, #0x68
    2840:      	blr	x8
    2844:      	cbz	x0, 0x2858 <kprobe_unwind_dotnet+0x2858>
    2848:      	ldr	x8, [x0]
    284c:      	add	x8, x8, #0x1
    2850:      	str	x8, [x0]
    2854:      	b	0x2868 <kprobe_unwind_dotnet+0x2868>
    2858:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    285c:      	ldr	x8, [x8]
    2860:      	ldr	w8, [x8]
    2864:      	cbnz	w8, 0x2cdc <kprobe_unwind_dotnet+0x2cdc>
    2868:      	ldrh	w25, [x23, #0x20]
    286c:      	cmp	w25, #0x8
    2870:      	b.ne	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    2874:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2878:      	ldr	x25, [x21, #0xed8]
    287c:      	ldr	x29, [x21, #0xee0]
    2880:      	ldr	x24, [x21, #0xed0]
    2884:      	ldrb	w22, [x21, #0xf20]
    2888:      	ldr	x8, [x8]
    288c:      	ldr	w8, [x8]
    2890:      	cbnz	w8, 0x2b00 <kprobe_unwind_dotnet+0x2b00>
    2894:      	cmp	x29, x25
    2898:      	b.lo	0x45cc <kprobe_unwind_dotnet+0x45cc>
    289c:      	add	x8, x25, #0x2, lsl #12  // =0x2000
    28a0:      	cmp	x29, x8
    28a4:      	b.hs	0x45cc <kprobe_unwind_dotnet+0x45cc>
    28a8:      	ldr	x23, [x21, #0xf00]
    28ac:      	ldr	x25, [x21, #0xf10]
    28b0:      	mov	w8, #0x101              // =257
    28b4:      	str	x24, [sp, #0x68]
    28b8:      	strh	w8, [x21, #0xf20]
    28bc:      	and	x8, x23, #0xffffffffffffff80
    28c0:      	cmp	x8, #0x80
    28c4:      	b.ne	0x28fc <kprobe_unwind_dotnet+0x28fc>
    28c8:      	ldr	x8, [x21, #0xed8]
    28cc:      	mov	w9, #0x8                // =8
    28d0:      	mov	w10, #0x70              // =112
    28d4:      	ldr	x0, [sp, #0x10]
    28d8:      	mov	w1, #0x8                // =8
    28dc:      	ldr	x2, [x21, #0xed8]
    28e0:      	blr	x10
    28e4:      	cbnz	x0, 0x1e0 <kprobe_unwind_dotnet+0x1e0>
    28e8:      	ldr	x8, [x21, #0xed8]
    28ec:      	and	x23, x23, #0x7f
    28f0:      	add	x8, x8, #0x8
    28f4:      	str	x8, [x21, #0xed8]
    28f8:      	b	0x2d8c <kprobe_unwind_dotnet+0x2d8c>
    28fc:      	mov	w8, #0x10               // =16
    2900:      	mov	w9, #0x70               // =112
    2904:      	add	x10, sp, #0x70
    2908:      	add	x0, sp, #0x70
    290c:      	mov	w1, #0x10               // =16
    2910:      	mov	x2, x29
    2914:      	blr	x9
    2918:      	cbnz	x0, 0x27c <kprobe_unwind_dotnet+0x27c>
    291c:      	add	x8, x29, #0x10
    2920:      	str	x8, [x21, #0xed8]
    2924:      	ldp	x8, x9, [sp, #0x70]
    2928:      	str	x8, [x21, #0xee0]
    292c:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2930:      	str	x9, [x21, #0xed0]
    2934:      	ldr	x8, [x8]
    2938:      	ldr	w8, [x8]
    293c:      	cbnz	w8, 0x2bf0 <kprobe_unwind_dotnet+0x2bf0>
    2940:      	cmp	x23, #0x100
    2944:      	b.lo	0x2d8c <kprobe_unwind_dotnet+0x2d8c>
    2948:      	ldr	x8, [x21, #0xf10]
    294c:      	ldr	x25, [x21, #0xf00]
    2950:      	sub	x23, x24, x8
    2954:      	str	x8, [sp, #0x8]
    2958:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    295c:      	ldr	x8, [x8]
    2960:      	ldr	w8, [x8]
    2964:      	cbnz	w8, 0x2c84 <kprobe_unwind_dotnet+0x2c84>
    2968:      	lsr	x8, x23, #8
    296c:      	mov	w9, #0x7f               // =127
    2970:      	lsr	x10, x23, #15
    2974:      	mov	w1, #0x200              // =512
    2978:      	sub	w9, w9, w8
    297c:      	lsl	x8, x8, #2
    2980:      	cmp	x10, #0x0
    2984:      	sub	x8, x8, #0x3fc
    2988:      	and	x9, x9, #0x7f
    298c:      	csel	x8, x8, xzr, ne
    2990:      	add	x2, x8, x25
    2994:      	csel	x8, xzr, x9, ne
    2998:      	ldr	x9, [sp, #0x18]
    299c:      	add	x0, x9, x8, lsl #2
    29a0:      	mov	w8, #0x200              // =512
    29a4:      	mov	w9, #0x70               // =112
    29a8:      	blr	x9
    29ac:      	cbz	x0, 0x2a0c <kprobe_unwind_dotnet+0x2a0c>
    29b0:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    29b4:      	ldr	x8, [x8]
    29b8:      	ldr	w8, [x8]
    29bc:      	cbnz	w8, 0x3ec8 <kprobe_unwind_dotnet+0x3ec8>
    29c0:      	mov	w8, #0x5e               // =94
    29c4:      	adrp	x0, 0x2000 <kprobe_unwind_dotnet+0x2000>
    29c8:      	add	x9, sp, #0x8c
    29cc:      	str	w8, [sp, #0x8c]
    29d0:      	mov	w8, #0x1                // =1
    29d4:      	add	x1, sp, #0x8c
    29d8:      	ldr	x0, [x0]
    29dc:      	blr	x8
    29e0:      	cbz	x0, 0x2a4c <kprobe_unwind_dotnet+0x2a4c>
    29e4:      	ldr	x8, [x0]
    29e8:      	add	x8, x8, #0x1
    29ec:      	str	x8, [x0]
    29f0:      	mov	w22, wzr
    29f4:      	mov	w2, #0x1772             // =6002
    29f8:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    29fc:      	ldr	x8, [x8]
    2a00:      	ldr	w8, [x8]
    2a04:      	cbz	w8, 0x2a74 <kprobe_unwind_dotnet+0x2a74>
    2a08:      	b	0x3f88 <kprobe_unwind_dotnet+0x3f88>
    2a0c:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2a10:      	ldr	w25, [x21, #0x116c]
    2a14:      	ldr	x8, [x8]
    2a18:      	ldr	w8, [x8]
    2a1c:      	cbnz	w8, 0x30bc <kprobe_unwind_dotnet+0x30bc>
    2a20:      	mov	w8, #0x1c               // =28
    2a24:      	bic	w8, w8, w23, lsr #3
    2a28:      	lsr	w25, w25, w8
    2a2c:      	cbz	w25, 0x3114 <kprobe_unwind_dotnet+0x3114>
    2a30:      	and	x29, x23, #0xffffffffffffffe0
    2a34:      	ands	w3, w25, #0xf
    2a38:      	b.ne	0x2d3c <kprobe_unwind_dotnet+0x2d3c>
    2a3c:      	ubfx	w3, w25, #4, #4
    2a40:      	cbz	w3, 0x2ae0 <kprobe_unwind_dotnet+0x2ae0>
    2a44:      	sub	x29, x29, #0x20
    2a48:      	b	0x2d3c <kprobe_unwind_dotnet+0x2d3c>
    2a4c:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2a50:      	ldr	x8, [x8]
    2a54:      	ldr	w8, [x8]
    2a58:      	cbnz	w8, 0x3198 <kprobe_unwind_dotnet+0x3198>
    2a5c:      	mov	w22, wzr
    2a60:      	mov	w2, #0x1772             // =6002
    2a64:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2a68:      	ldr	x8, [x8]
    2a6c:      	ldr	w8, [x8]
    2a70:      	cbnz	w8, 0x3f88 <kprobe_unwind_dotnet+0x3f88>
    2a74:      	cbz	w22, 0x621c <kprobe_unwind_dotnet+0x621c>
    2a78:      	ldr	w8, [x21, #0x2c0]
    2a7c:      	adrp	x23, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2a80:      	adrp	x24, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2a84:      	ldr	x23, [x23]
    2a88:      	ldr	x24, [x24]
    2a8c:      	cmp	w8, #0x7e
    2a90:      	b.hi	0x49c <kprobe_unwind_dotnet+0x49c>
    2a94:      	add	w9, w8, #0x1
    2a98:      	mov	w10, #0x8a              // =138
    2a9c:      	str	w9, [x21, #0x2c0]
    2aa0:      	mov	w9, #0x18               // =24
    2aa4:      	umaddl	x8, w8, w9, x21
    2aa8:      	mov	w9, #0x1773             // =6003
    2aac:      	str	x9, [x8, #0x2d8]
    2ab0:      	add	x9, x8, #0x2d0
    2ab4:      	str	xzr, [x8, #0x2d0]
    2ab8:      	strb	w10, [x8, #0x2e0]
    2abc:      	str	wzr, [x8, #0x2e4]
    2ac0:      	stur	wzr, [x9, #0x11]
    2ac4:      	ldr	x8, [sp, #0x10]
    2ac8:      	ldr	x29, [x8]
    2acc:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2ad0:      	ldr	x8, [x8]
    2ad4:      	ldr	w8, [x8]
    2ad8:      	cbnz	x29, 0x2e58 <kprobe_unwind_dotnet+0x2e58>
    2adc:      	b	0x4d58 <kprobe_unwind_dotnet+0x4d58>
    2ae0:      	ubfx	w3, w25, #8, #4
    2ae4:      	cbz	w3, 0x2af0 <kprobe_unwind_dotnet+0x2af0>
    2ae8:      	sub	x29, x29, #0x40
    2aec:      	b	0x2d3c <kprobe_unwind_dotnet+0x2d3c>
    2af0:      	ubfx	w3, w25, #12, #4
    2af4:      	cbz	w3, 0x2b54 <kprobe_unwind_dotnet+0x2b54>
    2af8:      	sub	x29, x29, #0x60
    2afc:      	b	0x2d3c <kprobe_unwind_dotnet+0x2d3c>
    2b00:      	mov	w8, #0x786c             // =30828
    2b04:      	add	x0, sp, #0x20
    2b08:      	mov	w1, #0x23               // =35
    2b0c:      	mov	x2, x24
    2b10:      	mov	x3, x25
    2b14:      	mov	x4, x29
    2b18:      	movk	w8, #0xa, lsl #16
    2b1c:      	stur	w8, [sp, #0x3f]
    2b20:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2b24:      	add	x8, x8, #0x0
    2b28:      	ldp	x9, x10, [x8]
    2b2c:      	stp	x9, x10, [sp, #0x20]
    2b30:      	ldp	x9, x8, [x8, #0x10]
    2b34:      	add	x10, sp, #0x20
    2b38:      	stp	x9, x8, [sp, #0x30]
    2b3c:      	mov	w8, #0x23               // =35
    2b40:      	mov	w9, #0x6                // =6
    2b44:      	blr	x9
    2b48:      	cmp	x29, x25
    2b4c:      	b.hs	0x289c <kprobe_unwind_dotnet+0x289c>
    2b50:      	b	0x45cc <kprobe_unwind_dotnet+0x45cc>
    2b54:      	ubfx	w3, w25, #16, #4
    2b58:      	cbz	w3, 0x2b74 <kprobe_unwind_dotnet+0x2b74>
    2b5c:      	sub	x29, x29, #0x80
    2b60:      	b	0x2d3c <kprobe_unwind_dotnet+0x2d3c>
    2b64:      	ldr	x8, [x21, #0x10c0]
    2b68:      	cbz	x8, 0x2c44 <kprobe_unwind_dotnet+0x2c44>
    2b6c:      	mov	w9, #-0x54              // =-84
    2b70:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    2b74:      	ubfx	w3, w25, #20, #4
    2b78:      	cbz	w3, 0x2c54 <kprobe_unwind_dotnet+0x2c54>
    2b7c:      	sub	x29, x29, #0xa0
    2b80:      	b	0x2d3c <kprobe_unwind_dotnet+0x2d3c>
    2b84:      	ldr	x8, [x21, #0x1118]
    2b88:      	cbz	x8, 0x2c64 <kprobe_unwind_dotnet+0x2c64>
    2b8c:      	mov	w9, #-0x6a              // =-106
    2b90:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    2b94:      	mov	w8, #0x656e             // =25966
    2b98:      	add	x0, sp, #0x20
    2b9c:      	mov	w1, #0x1b               // =27
    2ba0:      	movk	w8, #0xa, lsl #16
    2ba4:      	stur	w8, [sp, #0x37]
    2ba8:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2bac:      	add	x8, x8, #0x0
    2bb0:      	ldp	x9, x10, [x8]
    2bb4:      	ldr	x8, [x8, #0x10]
    2bb8:      	stp	x9, x10, [sp, #0x20]
    2bbc:      	str	x8, [sp, #0x30]
    2bc0:      	mov	w8, #0x1b               // =27
    2bc4:      	mov	w9, #0x6                // =6
    2bc8:      	add	x10, sp, #0x20
    2bcc:      	blr	x9
    2bd0:      	mov	w25, #0x1               // =1
    2bd4:      	cmp	w25, #0x8
    2bd8:      	b.eq	0x2874 <kprobe_unwind_dotnet+0x2874>
    2bdc:      	b	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    2be0:      	ldr	x8, [x21, #0x10e8]
    2be4:      	cbz	x8, 0x2c74 <kprobe_unwind_dotnet+0x2c74>
    2be8:      	mov	w9, #-0x5e              // =-94
    2bec:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    2bf0:      	mov	w8, #0x786c             // =30828
    2bf4:      	add	x0, sp, #0x20
    2bf8:      	mov	w1, #0x23               // =35
    2bfc:      	movk	w8, #0xa, lsl #16
    2c00:      	stur	w8, [sp, #0x3f]
    2c04:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2c08:      	add	x8, x8, #0x0
    2c0c:      	ldp	x9, x10, [x8]
    2c10:      	stp	x9, x10, [sp, #0x20]
    2c14:      	ldp	x9, x8, [x8, #0x10]
    2c18:      	add	x10, sp, #0x20
    2c1c:      	stp	x9, x8, [sp, #0x30]
    2c20:      	mov	w8, #0x23               // =35
    2c24:      	mov	w9, #0x6                // =6
    2c28:      	ldr	x2, [x21, #0xed0]
    2c2c:      	ldr	x3, [x21, #0xed8]
    2c30:      	ldr	x4, [x21, #0xee0]
    2c34:      	blr	x9
    2c38:      	cmp	x23, #0x100
    2c3c:      	b.hs	0x2948 <kprobe_unwind_dotnet+0x2948>
    2c40:      	b	0x2d8c <kprobe_unwind_dotnet+0x2d8c>
    2c44:      	ldr	x8, [x21, #0x10b8]
    2c48:      	cbz	x8, 0x2d24 <kprobe_unwind_dotnet+0x2d24>
    2c4c:      	mov	w9, #-0x52              // =-82
    2c50:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    2c54:      	ubfx	w3, w25, #24, #4
    2c58:      	cbz	w3, 0x2d34 <kprobe_unwind_dotnet+0x2d34>
    2c5c:      	sub	x29, x29, #0xc0
    2c60:      	b	0x2d3c <kprobe_unwind_dotnet+0x2d3c>
    2c64:      	ldr	x8, [x21, #0x1110]
    2c68:      	cbz	x8, 0x309c <kprobe_unwind_dotnet+0x309c>
    2c6c:      	mov	w9, #-0x68              // =-104
    2c70:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    2c74:      	ldr	x8, [x21, #0x10e0]
    2c78:      	cbz	x8, 0x30ac <kprobe_unwind_dotnet+0x30ac>
    2c7c:      	mov	w9, #-0x5c              // =-92
    2c80:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    2c84:      	mov	w8, #0xa                // =10
    2c88:      	mov	w11, #0x6               // =6
    2c8c:      	add	x0, sp, #0x20
    2c90:      	strh	w8, [sp, #0x60]
    2c94:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2c98:      	add	x8, x8, #0x0
    2c9c:      	mov	w1, #0x42               // =66
    2ca0:      	ldp	x9, x10, [x8, #0x20]
    2ca4:      	mov	x2, x23
    2ca8:      	mov	x4, x25
    2cac:      	stp	x9, x10, [sp, #0x40]
    2cb0:      	ldp	x9, x10, [x8, #0x30]
    2cb4:      	stp	x9, x10, [sp, #0x50]
    2cb8:      	ldp	x9, x10, [x8]
    2cbc:      	stp	x9, x10, [sp, #0x20]
    2cc0:      	ldp	x9, x8, [x8, #0x10]
    2cc4:      	mov	w10, #0x42              // =66
    2cc8:      	stp	x9, x8, [sp, #0x30]
    2ccc:      	add	x8, sp, #0x20
    2cd0:      	ldr	x3, [sp, #0x8]
    2cd4:      	blr	x11
    2cd8:      	b	0x2968 <kprobe_unwind_dotnet+0x2968>
    2cdc:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2ce0:      	add	x8, x8, #0x0
    2ce4:      	add	x0, sp, #0x20
    2ce8:      	ldp	x9, x10, [x8, #0x10]
    2cec:      	mov	w1, #0x2e               // =46
    2cf0:      	stp	x9, x10, [sp, #0x30]
    2cf4:      	ldr	x9, [x8, #0x20]
    2cf8:      	add	x10, sp, #0x20
    2cfc:      	str	x9, [sp, #0x40]
    2d00:      	ldur	x9, [x8, #0x26]
    2d04:      	stur	x9, [sp, #0x46]
    2d08:      	ldp	x9, x8, [x8]
    2d0c:      	stp	x9, x8, [sp, #0x20]
    2d10:      	mov	w8, #0x2e               // =46
    2d14:      	mov	w9, #0x6                // =6
    2d18:      	ldr	w2, [sp, #0x68]
    2d1c:      	blr	x9
    2d20:      	b	0x2868 <kprobe_unwind_dotnet+0x2868>
    2d24:      	ldr	x8, [x21, #0x10b0]
    2d28:      	cbz	x8, 0x3188 <kprobe_unwind_dotnet+0x3188>
    2d2c:      	mov	w9, #-0x50              // =-80
    2d30:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    2d34:      	lsr	w3, w25, #28
    2d38:      	sub	x29, x29, #0xe0
    2d3c:      	ldr	x8, [sp, #0x8]
    2d40:      	lsl	w9, w3, #2
    2d44:      	sub	w9, w9, #0x4
    2d48:      	add	x8, x29, x8
    2d4c:      	add	x25, x8, x9
    2d50:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2d54:      	ldr	x8, [x8]
    2d58:      	ldr	w8, [x8]
    2d5c:      	cbnz	w8, 0x313c <kprobe_unwind_dotnet+0x313c>
    2d60:      	sub	x2, x25, #0x8
    2d64:      	mov	w8, #0x8                // =8
    2d68:      	mov	w9, #0x70               // =112
    2d6c:      	add	x10, sp, #0x68
    2d70:      	add	x0, sp, #0x68
    2d74:      	mov	w1, #0x8                // =8
    2d78:      	blr	x9
    2d7c:      	adrp	x23, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2d80:      	ldr	x23, [x23]
    2d84:      	cbnz	x0, 0x844 <kprobe_unwind_dotnet+0x844>
    2d88:      	mov	w23, #0x1f              // =31
    2d8c:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2d90:      	ldr	x8, [x8]
    2d94:      	ldr	w8, [x8]
    2d98:      	cbnz	w8, 0x2f84 <kprobe_unwind_dotnet+0x2f84>
    2d9c:      	ldr	w8, [x21, #0x2c0]
    2da0:      	cmp	w8, #0x7e
    2da4:      	b.hi	0x8a4 <kprobe_unwind_dotnet+0x8a4>
    2da8:      	ldr	x9, [sp, #0x68]
    2dac:      	add	w11, w8, #0x1
    2db0:      	sub	x10, x24, x25
    2db4:      	adrp	x0, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2db8:      	str	w11, [x21, #0x2c0]
    2dbc:      	mov	w11, #0x18              // =24
    2dc0:      	add	x1, sp, #0x8c
    2dc4:      	umaddl	x8, w8, w11, x21
    2dc8:      	add	x9, x23, x9, lsl #5
    2dcc:      	str	x10, [x8, #0x2d8]
    2dd0:      	mov	w10, #0xa               // =10
    2dd4:      	strb	w22, [x8, #0x2e1]
    2dd8:      	strh	wzr, [x8, #0x2e6]
    2ddc:      	strb	w10, [x8, #0x2e0]
    2de0:      	str	x9, [x8, #0x2d0]
    2de4:      	add	x9, x8, #0x2d0
    2de8:      	mov	w8, #0x5b               // =91
    2dec:      	stur	wzr, [x9, #0x12]
    2df0:      	str	w8, [sp, #0x8c]
    2df4:      	mov	w8, #0x1                // =1
    2df8:      	add	x9, sp, #0x8c
    2dfc:      	ldr	x0, [x0]
    2e00:      	blr	x8
    2e04:      	cbz	x0, 0x2e30 <kprobe_unwind_dotnet+0x2e30>
    2e08:      	ldr	x8, [x0]
    2e0c:      	add	x8, x8, #0x1
    2e10:      	str	x8, [x0]
    2e14:      	ldr	x8, [sp, #0x10]
    2e18:      	ldr	x29, [x8]
    2e1c:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2e20:      	ldr	x8, [x8]
    2e24:      	ldr	w8, [x8]
    2e28:      	cbnz	x29, 0x2e58 <kprobe_unwind_dotnet+0x2e58>
    2e2c:      	b	0x4d58 <kprobe_unwind_dotnet+0x4d58>
    2e30:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2e34:      	ldr	x8, [x8]
    2e38:      	ldr	w8, [x8]
    2e3c:      	cbnz	w8, 0x303c <kprobe_unwind_dotnet+0x303c>
    2e40:      	ldr	x8, [sp, #0x10]
    2e44:      	ldr	x29, [x8]
    2e48:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2e4c:      	ldr	x8, [x8]
    2e50:      	ldr	w8, [x8]
    2e54:      	cbz	x29, 0x4d58 <kprobe_unwind_dotnet+0x4d58>
    2e58:      	cbnz	w8, 0x2fec <kprobe_unwind_dotnet+0x2fec>
    2e5c:      	lsr	x8, x29, #56
    2e60:      	cbnz	x8, 0x1650 <kprobe_unwind_dotnet+0x1650>
    2e64:      	cmp	x29, #0x1, lsl #12      // =0x1000
    2e68:      	b.lo	0x1784 <kprobe_unwind_dotnet+0x1784>
    2e6c:      	ldr	w8, [x21]
    2e70:      	mov	w9, #0x60               // =96
    2e74:      	adrp	x0, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2e78:      	add	x1, sp, #0x70
    2e7c:      	rev	w8, w8
    2e80:      	stp	w9, w8, [sp, #0x70]
    2e84:      	rev	x8, x29
    2e88:      	add	x9, sp, #0x70
    2e8c:      	str	x8, [sp, #0x78]
    2e90:      	mov	w8, #0x1                // =1
    2e94:      	ldr	x0, [x0]
    2e98:      	blr	x8
    2e9c:      	cbz	x0, 0x4eec <kprobe_unwind_dotnet+0x4eec>
    2ea0:      	ldr	x8, [x0, #0x8]
    2ea4:      	and	x9, x8, #0xffffffffffffff
    2ea8:      	lsr	x25, x8, #56
    2eac:      	str	x9, [x21, #0xf10]
    2eb0:      	ldr	x8, [x0]
    2eb4:      	str	x8, [x21, #0xf00]
    2eb8:      	sub	x8, x29, x9
    2ebc:      	str	x8, [x21, #0xf08]
    2ec0:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2ec4:      	ldr	x8, [x8]
    2ec8:      	ldr	w8, [x8]
    2ecc:      	cbnz	w8, 0x3208 <kprobe_unwind_dotnet+0x3208>
    2ed0:      	cmp	w25, #0x1
    2ed4:      	b.ne	0x347c <kprobe_unwind_dotnet+0x347c>
    2ed8:      	ldr	x8, [x21, #0xf00]
    2edc:      	adrp	x0, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2ee0:      	ldr	x22, [x21, #0xf08]
    2ee4:      	mov	w9, #0x1                // =1
    2ee8:      	add	x1, sp, #0x70
    2eec:      	mov	w25, #0x1               // =1
    2ef0:      	str	x8, [sp, #0x70]
    2ef4:      	add	x8, sp, #0x70
    2ef8:      	ldr	x0, [x0]
    2efc:      	blr	x9
    2f00:      	cbz	x0, 0x2f78 <kprobe_unwind_dotnet+0x2f78>
    2f04:      	ldr	x8, [x0]
    2f08:      	mov	x23, x0
    2f0c:      	cmp	x8, x22
    2f10:      	b.hi	0x2f20 <kprobe_unwind_dotnet+0x2f20>
    2f14:      	ldr	x8, [x23, #0x8]
    2f18:      	cmp	x8, x22
    2f1c:      	b.hs	0x2f38 <kprobe_unwind_dotnet+0x2f38>
    2f20:      	ldr	x8, [x23, #0x10]
    2f24:      	cmp	x8, x22
    2f28:      	b.hi	0x2f68 <kprobe_unwind_dotnet+0x2f68>
    2f2c:      	ldr	x8, [x23, #0x18]
    2f30:      	cmp	x8, x22
    2f34:      	b.lo	0x2f68 <kprobe_unwind_dotnet+0x2f68>
    2f38:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2f3c:      	ldr	x8, [x8]
    2f40:      	ldr	w8, [x8]
    2f44:      	cbnz	w8, 0x33ec <kprobe_unwind_dotnet+0x33ec>
    2f48:      	ldrh	w8, [x23, #0x20]
    2f4c:      	ldr	w9, [x21, #0x1370]
    2f50:      	lsr	w8, w9, w8
    2f54:      	tbz	w8, #0x0, 0x3438 <kprobe_unwind_dotnet+0x3438>
    2f58:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2f5c:      	ldr	x8, [x8]
    2f60:      	ldr	w8, [x8]
    2f64:      	cbnz	w8, 0x37a4 <kprobe_unwind_dotnet+0x37a4>
    2f68:      	mov	w25, #0x1               // =1
    2f6c:      	cmp	w25, #0x8
    2f70:      	b.eq	0x3484 <kprobe_unwind_dotnet+0x3484>
    2f74:      	b	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    2f78:      	cmp	w25, #0x8
    2f7c:      	b.eq	0x3484 <kprobe_unwind_dotnet+0x3484>
    2f80:      	b	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    2f84:      	mov	w8, #0x786c             // =30828
    2f88:      	sub	x4, x24, x25
    2f8c:      	add	x0, sp, #0x20
    2f90:      	mov	w1, #0x43               // =67
    2f94:      	mov	x2, x25
    2f98:      	movk	w8, #0xa, lsl #16
    2f9c:      	stur	w8, [sp, #0x5f]
    2fa0:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2fa4:      	add	x8, x8, #0x0
    2fa8:      	ldp	x9, x10, [x8, #0x20]
    2fac:      	stp	x9, x10, [sp, #0x40]
    2fb0:      	ldp	x9, x10, [x8, #0x30]
    2fb4:      	stp	x9, x10, [sp, #0x50]
    2fb8:      	ldp	x9, x10, [x8]
    2fbc:      	stp	x9, x10, [sp, #0x20]
    2fc0:      	ldp	x9, x8, [x8, #0x10]
    2fc4:      	add	x10, sp, #0x20
    2fc8:      	stp	x9, x8, [sp, #0x30]
    2fcc:      	mov	w8, #0x43               // =67
    2fd0:      	mov	w9, #0x6                // =6
    2fd4:      	ldr	x3, [sp, #0x68]
    2fd8:      	blr	x9
    2fdc:      	ldr	w8, [x21, #0x2c0]
    2fe0:      	cmp	w8, #0x7e
    2fe4:      	b.hi	0x8a4 <kprobe_unwind_dotnet+0x8a4>
    2fe8:      	b	0x2da8 <kprobe_unwind_dotnet+0x2da8>
    2fec:      	adrp	x8, 0x2000 <kprobe_unwind_dotnet+0x2000>
    2ff0:      	add	x8, x8, #0x0
    2ff4:      	strb	wzr, [sp, #0x50]
    2ff8:      	add	x0, sp, #0x20
    2ffc:      	ldp	x9, x10, [x8, #0x10]
    3000:      	mov	w1, #0x31               // =49
    3004:      	stp	x9, x10, [sp, #0x30]
    3008:      	ldp	x9, x10, [x8, #0x20]
    300c:      	stp	x9, x10, [sp, #0x40]
    3010:      	ldp	x9, x8, [x8]
    3014:      	add	x10, sp, #0x20
    3018:      	stp	x9, x8, [sp, #0x20]
    301c:      	mov	w8, #0x31               // =49
    3020:      	mov	w9, #0x6                // =6
    3024:      	ldr	w2, [x21, #0x2c0]
    3028:      	blr	x9
    302c:      	ldr	x29, [x21, #0xed0]
    3030:      	lsr	x8, x29, #56
    3034:      	cbnz	x8, 0x1650 <kprobe_unwind_dotnet+0x1650>
    3038:      	b	0x2e64 <kprobe_unwind_dotnet+0x2e64>
    303c:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3040:      	add	x8, x8, #0x0
    3044:      	add	x0, sp, #0x20
    3048:      	ldp	x9, x10, [x8, #0x10]
    304c:      	mov	w1, #0x2e               // =46
    3050:      	stp	x9, x10, [sp, #0x30]
    3054:      	ldr	x9, [x8, #0x20]
    3058:      	add	x10, sp, #0x20
    305c:      	str	x9, [sp, #0x40]
    3060:      	ldur	x9, [x8, #0x26]
    3064:      	stur	x9, [sp, #0x46]
    3068:      	ldp	x9, x8, [x8]
    306c:      	stp	x9, x8, [sp, #0x20]
    3070:      	mov	w8, #0x2e               // =46
    3074:      	mov	w9, #0x6                // =6
    3078:      	ldr	w2, [sp, #0x8c]
    307c:      	blr	x9
    3080:      	ldr	x8, [sp, #0x10]
    3084:      	ldr	x29, [x8]
    3088:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    308c:      	ldr	x8, [x8]
    3090:      	ldr	w8, [x8]
    3094:      	cbnz	x29, 0x2e58 <kprobe_unwind_dotnet+0x2e58>
    3098:      	b	0x4d58 <kprobe_unwind_dotnet+0x4d58>
    309c:      	ldr	x8, [x21, #0x1108]
    30a0:      	cbz	x8, 0x31f8 <kprobe_unwind_dotnet+0x31f8>
    30a4:      	mov	w9, #-0x66              // =-102
    30a8:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    30ac:      	ldr	x8, [x21, #0x10d8]
    30b0:      	cbz	x8, 0x32b0 <kprobe_unwind_dotnet+0x32b0>
    30b4:      	mov	w9, #-0x5a              // =-90
    30b8:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    30bc:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    30c0:      	add	x8, x8, #0x0
    30c4:      	add	x0, sp, #0x20
    30c8:      	ldp	x9, x10, [x8, #0x20]
    30cc:      	and	x2, x23, #0xfffffffffffffffc
    30d0:      	mov	w1, #0x36               // =54
    30d4:      	mov	w3, w25
    30d8:      	stp	x9, x10, [sp, #0x40]
    30dc:      	ldur	x9, [x8, #0x2e]
    30e0:      	stur	x9, [sp, #0x4e]
    30e4:      	ldp	x9, x10, [x8]
    30e8:      	stp	x9, x10, [sp, #0x20]
    30ec:      	ldp	x8, x9, [x8, #0x10]
    30f0:      	add	x10, sp, #0x20
    30f4:      	stp	x8, x9, [sp, #0x30]
    30f8:      	mov	w8, #0x36               // =54
    30fc:      	mov	w9, #0x6                // =6
    3100:      	blr	x9
    3104:      	mov	w8, #0x1c               // =28
    3108:      	bic	w8, w8, w23, lsr #3
    310c:      	lsr	w25, w25, w8
    3110:      	cbnz	w25, 0x2a30 <kprobe_unwind_dotnet+0x2a30>
    3114:      	and	x8, x23, #0xffffffffffffff00
    3118:      	ldr	w25, [x21, #0x1168]
    311c:      	sub	x23, x8, #0x20
    3120:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3124:      	ldr	x8, [x8]
    3128:      	ldr	w8, [x8]
    312c:      	cbnz	w8, 0x32c0 <kprobe_unwind_dotnet+0x32c0>
    3130:      	cbz	w25, 0x330c <kprobe_unwind_dotnet+0x330c>
    3134:      	mov	w3, wzr
    3138:      	b	0x3e5c <kprobe_unwind_dotnet+0x3e5c>
    313c:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3140:      	add	x8, x8, #0x0
    3144:      	add	x0, sp, #0x20
    3148:      	ldp	x9, x10, [x8, #0x10]
    314c:      	mov	w1, #0x2e               // =46
    3150:      	mov	x2, x29
    3154:      	mov	x4, x25
    3158:      	stp	x9, x10, [sp, #0x30]
    315c:      	ldr	x9, [x8, #0x20]
    3160:      	add	x10, sp, #0x20
    3164:      	str	x9, [sp, #0x40]
    3168:      	ldur	x9, [x8, #0x26]
    316c:      	stur	x9, [sp, #0x46]
    3170:      	ldp	x9, x8, [x8]
    3174:      	stp	x9, x8, [sp, #0x20]
    3178:      	mov	w8, #0x2e               // =46
    317c:      	mov	w9, #0x6                // =6
    3180:      	blr	x9
    3184:      	b	0x2d60 <kprobe_unwind_dotnet+0x2d60>
    3188:      	ldr	x8, [x21, #0x10a8]
    318c:      	cbz	x8, 0x338c <kprobe_unwind_dotnet+0x338c>
    3190:      	mov	w9, #-0x4e              // =-78
    3194:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    3198:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    319c:      	add	x8, x8, #0x0
    31a0:      	add	x0, sp, #0x20
    31a4:      	ldp	x9, x10, [x8, #0x10]
    31a8:      	mov	w1, #0x2e               // =46
    31ac:      	stp	x9, x10, [sp, #0x30]
    31b0:      	ldr	x9, [x8, #0x20]
    31b4:      	add	x10, sp, #0x20
    31b8:      	str	x9, [sp, #0x40]
    31bc:      	ldur	x9, [x8, #0x26]
    31c0:      	stur	x9, [sp, #0x46]
    31c4:      	ldp	x9, x8, [x8]
    31c8:      	stp	x9, x8, [sp, #0x20]
    31cc:      	mov	w8, #0x2e               // =46
    31d0:      	mov	w9, #0x6                // =6
    31d4:      	ldr	w2, [sp, #0x8c]
    31d8:      	blr	x9
    31dc:      	mov	w22, wzr
    31e0:      	mov	w2, #0x1772             // =6002
    31e4:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    31e8:      	ldr	x8, [x8]
    31ec:      	ldr	w8, [x8]
    31f0:      	cbz	w8, 0x2a74 <kprobe_unwind_dotnet+0x2a74>
    31f4:      	b	0x3f88 <kprobe_unwind_dotnet+0x3f88>
    31f8:      	ldr	x8, [x21, #0x1100]
    31fc:      	cbz	x8, 0x339c <kprobe_unwind_dotnet+0x339c>
    3200:      	mov	w9, #-0x64              // =-100
    3204:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    3208:      	mov	w8, #0xa                // =10
    320c:      	add	x0, sp, #0x20
    3210:      	mov	w1, #0x32               // =50
    3214:      	strh	w8, [sp, #0x50]
    3218:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    321c:      	add	x8, x8, #0x0
    3220:      	mov	x2, x29
    3224:      	ldp	x9, x10, [x8, #0x10]
    3228:      	mov	w4, w25
    322c:      	stp	x9, x10, [sp, #0x30]
    3230:      	ldp	x9, x10, [x8, #0x20]
    3234:      	stp	x9, x10, [sp, #0x40]
    3238:      	ldp	x9, x8, [x8]
    323c:      	add	x10, sp, #0x20
    3240:      	stp	x9, x8, [sp, #0x20]
    3244:      	mov	w8, #0x32               // =50
    3248:      	mov	w9, #0x6                // =6
    324c:      	ldr	x3, [x21, #0xf00]
    3250:      	blr	x9
    3254:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3258:      	ldr	x8, [x8]
    325c:      	ldr	w8, [x8]
    3260:      	cbz	w8, 0x2ed0 <kprobe_unwind_dotnet+0x2ed0>
    3264:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3268:      	add	x8, x8, #0x0
    326c:      	add	x0, sp, #0x20
    3270:      	ldp	x9, x10, [x8, #0x10]
    3274:      	mov	w1, #0x2f               // =47
    3278:      	stp	x9, x10, [sp, #0x30]
    327c:      	ldr	x9, [x8, #0x20]
    3280:      	add	x10, sp, #0x20
    3284:      	str	x9, [sp, #0x40]
    3288:      	ldur	x9, [x8, #0x27]
    328c:      	stur	x9, [sp, #0x47]
    3290:      	ldp	x9, x8, [x8]
    3294:      	stp	x9, x8, [sp, #0x20]
    3298:      	mov	w8, #0x2f               // =47
    329c:      	mov	w9, #0x6                // =6
    32a0:      	ldr	x2, [x21, #0xf10]
    32a4:      	ldr	x3, [x21, #0xf08]
    32a8:      	blr	x9
    32ac:      	b	0x2ed0 <kprobe_unwind_dotnet+0x2ed0>
    32b0:      	ldr	x8, [x21, #0x10d0]
    32b4:      	cbz	x8, 0x33ac <kprobe_unwind_dotnet+0x33ac>
    32b8:      	mov	w9, #-0x58              // =-88
    32bc:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    32c0:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    32c4:      	add	x8, x8, #0x0
    32c8:      	add	x0, sp, #0x20
    32cc:      	ldp	x9, x10, [x8, #0x20]
    32d0:      	mov	w1, #0x37               // =55
    32d4:      	mov	x2, x23
    32d8:      	mov	w3, w25
    32dc:      	stp	x9, x10, [sp, #0x40]
    32e0:      	ldur	x9, [x8, #0x2f]
    32e4:      	stur	x9, [sp, #0x4f]
    32e8:      	ldp	x9, x10, [x8]
    32ec:      	stp	x9, x10, [sp, #0x20]
    32f0:      	ldp	x8, x9, [x8, #0x10]
    32f4:      	add	x10, sp, #0x20
    32f8:      	stp	x8, x9, [sp, #0x30]
    32fc:      	mov	w8, #0x37               // =55
    3300:      	mov	w9, #0x6                // =6
    3304:      	blr	x9
    3308:      	cbnz	w25, 0x3134 <kprobe_unwind_dotnet+0x3134>
    330c:      	ldr	x8, [x21, #0x1160]
    3310:      	cbz	x8, 0x331c <kprobe_unwind_dotnet+0x331c>
    3314:      	mov	w9, #-0x7c              // =-124
    3318:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    331c:      	ldr	x8, [x21, #0x1158]
    3320:      	cbz	x8, 0x332c <kprobe_unwind_dotnet+0x332c>
    3324:      	mov	w9, #-0x7a              // =-122
    3328:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    332c:      	ldr	x8, [x21, #0x1150]
    3330:      	cbz	x8, 0x333c <kprobe_unwind_dotnet+0x333c>
    3334:      	mov	w9, #-0x78              // =-120
    3338:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    333c:      	ldr	x8, [x21, #0x1148]
    3340:      	cbz	x8, 0x334c <kprobe_unwind_dotnet+0x334c>
    3344:      	mov	w9, #-0x76              // =-118
    3348:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    334c:      	ldr	x8, [x21, #0x1140]
    3350:      	cbz	x8, 0x335c <kprobe_unwind_dotnet+0x335c>
    3354:      	mov	w9, #-0x74              // =-116
    3358:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    335c:      	ldr	x8, [x21, #0x1138]
    3360:      	cbz	x8, 0x336c <kprobe_unwind_dotnet+0x336c>
    3364:      	mov	w9, #-0x72              // =-114
    3368:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    336c:      	ldr	x8, [x21, #0x1130]
    3370:      	cbz	x8, 0x337c <kprobe_unwind_dotnet+0x337c>
    3374:      	mov	w9, #-0x70              // =-112
    3378:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    337c:      	ldr	x8, [x21, #0x1128]
    3380:      	cbz	x8, 0x33bc <kprobe_unwind_dotnet+0x33bc>
    3384:      	mov	w9, #-0x6e              // =-110
    3388:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    338c:      	ldr	x8, [x21, #0x10a0]
    3390:      	cbz	x8, 0x33cc <kprobe_unwind_dotnet+0x33cc>
    3394:      	mov	w9, #-0x4c              // =-76
    3398:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    339c:      	ldr	x8, [x21, #0x10f8]
    33a0:      	cbz	x8, 0x33dc <kprobe_unwind_dotnet+0x33dc>
    33a4:      	mov	w9, #-0x62              // =-98
    33a8:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    33ac:      	ldr	x8, [x21, #0x10c8]
    33b0:      	cbz	x8, 0x3774 <kprobe_unwind_dotnet+0x3774>
    33b4:      	mov	w9, #-0x56              // =-86
    33b8:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    33bc:      	ldr	x8, [x21, #0x1120]
    33c0:      	cbz	x8, 0x3794 <kprobe_unwind_dotnet+0x3794>
    33c4:      	mov	w9, #-0x6c              // =-108
    33c8:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    33cc:      	ldr	x8, [x21, #0x1098]
    33d0:      	cbz	x8, 0x37f0 <kprobe_unwind_dotnet+0x37f0>
    33d4:      	mov	w9, #-0x4a              // =-74
    33d8:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    33dc:      	ldr	x8, [x21, #0x10f0]
    33e0:      	cbz	x8, 0x3800 <kprobe_unwind_dotnet+0x3800>
    33e4:      	mov	w9, #-0x60              // =-96
    33e8:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    33ec:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    33f0:      	add	x8, x8, #0x0
    33f4:      	add	x0, sp, #0x20
    33f8:      	ldp	x9, x10, [x8]
    33fc:      	mov	w1, #0x1e               // =30
    3400:      	stp	x9, x10, [sp, #0x20]
    3404:      	ldr	x9, [x8, #0x10]
    3408:      	ldur	x8, [x8, #0x16]
    340c:      	add	x10, sp, #0x20
    3410:      	str	x9, [sp, #0x30]
    3414:      	stur	x8, [sp, #0x36]
    3418:      	mov	w8, #0x1e               // =30
    341c:      	mov	w9, #0x6                // =6
    3420:      	ldrh	w2, [x23, #0x20]
    3424:      	blr	x9
    3428:      	ldrh	w8, [x23, #0x20]
    342c:      	ldr	w9, [x21, #0x1370]
    3430:      	lsr	w8, w9, w8
    3434:      	tbnz	w8, #0x0, 0x2f58 <kprobe_unwind_dotnet+0x2f58>
    3438:      	str	wzr, [sp, #0x68]
    343c:      	adrp	x0, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3440:      	mov	w8, #0x1                // =1
    3444:      	add	x9, sp, #0x68
    3448:      	ldr	x0, [x0]
    344c:      	add	x1, sp, #0x68
    3450:      	blr	x8
    3454:      	cbz	x0, 0x3468 <kprobe_unwind_dotnet+0x3468>
    3458:      	ldr	x8, [x0]
    345c:      	add	x8, x8, #0x1
    3460:      	str	x8, [x0]
    3464:      	b	0x3478 <kprobe_unwind_dotnet+0x3478>
    3468:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    346c:      	ldr	x8, [x8]
    3470:      	ldr	w8, [x8]
    3474:      	cbnz	w8, 0x390c <kprobe_unwind_dotnet+0x390c>
    3478:      	ldrh	w25, [x23, #0x20]
    347c:      	cmp	w25, #0x8
    3480:      	b.ne	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    3484:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3488:      	ldr	x25, [x21, #0xed8]
    348c:      	ldr	x29, [x21, #0xee0]
    3490:      	ldr	x24, [x21, #0xed0]
    3494:      	ldrb	w22, [x21, #0xf20]
    3498:      	ldr	x8, [x8]
    349c:      	ldr	w8, [x8]
    34a0:      	cbnz	w8, 0x3710 <kprobe_unwind_dotnet+0x3710>
    34a4:      	cmp	x29, x25
    34a8:      	b.lo	0x45cc <kprobe_unwind_dotnet+0x45cc>
    34ac:      	add	x8, x25, #0x2, lsl #12  // =0x2000
    34b0:      	cmp	x29, x8
    34b4:      	b.hs	0x45cc <kprobe_unwind_dotnet+0x45cc>
    34b8:      	ldr	x23, [x21, #0xf00]
    34bc:      	ldr	x25, [x21, #0xf10]
    34c0:      	mov	w8, #0x101              // =257
    34c4:      	str	x24, [sp, #0x68]
    34c8:      	strh	w8, [x21, #0xf20]
    34cc:      	and	x8, x23, #0xffffffffffffff80
    34d0:      	cmp	x8, #0x80
    34d4:      	b.ne	0x350c <kprobe_unwind_dotnet+0x350c>
    34d8:      	ldr	x8, [x21, #0xed8]
    34dc:      	mov	w9, #0x8                // =8
    34e0:      	mov	w10, #0x70              // =112
    34e4:      	ldr	x0, [sp, #0x10]
    34e8:      	mov	w1, #0x8                // =8
    34ec:      	ldr	x2, [x21, #0xed8]
    34f0:      	blr	x10
    34f4:      	cbnz	x0, 0x1e0 <kprobe_unwind_dotnet+0x1e0>
    34f8:      	ldr	x8, [x21, #0xed8]
    34fc:      	and	x23, x23, #0x7f
    3500:      	add	x8, x8, #0x8
    3504:      	str	x8, [x21, #0xed8]
    3508:      	b	0x39bc <kprobe_unwind_dotnet+0x39bc>
    350c:      	mov	w8, #0x10               // =16
    3510:      	mov	w9, #0x70               // =112
    3514:      	add	x10, sp, #0x70
    3518:      	add	x0, sp, #0x70
    351c:      	mov	w1, #0x10               // =16
    3520:      	mov	x2, x29
    3524:      	blr	x9
    3528:      	cbnz	x0, 0x27c <kprobe_unwind_dotnet+0x27c>
    352c:      	add	x8, x29, #0x10
    3530:      	str	x8, [x21, #0xed8]
    3534:      	ldp	x8, x9, [sp, #0x70]
    3538:      	str	x8, [x21, #0xee0]
    353c:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3540:      	str	x9, [x21, #0xed0]
    3544:      	ldr	x8, [x8]
    3548:      	ldr	w8, [x8]
    354c:      	cbnz	w8, 0x3810 <kprobe_unwind_dotnet+0x3810>
    3550:      	cmp	x23, #0x100
    3554:      	b.lo	0x39bc <kprobe_unwind_dotnet+0x39bc>
    3558:      	ldr	x8, [x21, #0xf10]
    355c:      	ldr	x25, [x21, #0xf00]
    3560:      	sub	x23, x24, x8
    3564:      	str	x8, [sp, #0x8]
    3568:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    356c:      	ldr	x8, [x8]
    3570:      	ldr	w8, [x8]
    3574:      	cbnz	w8, 0x38b4 <kprobe_unwind_dotnet+0x38b4>
    3578:      	lsr	x8, x23, #8
    357c:      	mov	w9, #0x7f               // =127
    3580:      	lsr	x10, x23, #15
    3584:      	mov	w1, #0x200              // =512
    3588:      	sub	w9, w9, w8
    358c:      	lsl	x8, x8, #2
    3590:      	cmp	x10, #0x0
    3594:      	sub	x8, x8, #0x3fc
    3598:      	and	x9, x9, #0x7f
    359c:      	csel	x8, x8, xzr, ne
    35a0:      	add	x2, x8, x25
    35a4:      	csel	x8, xzr, x9, ne
    35a8:      	ldr	x9, [sp, #0x18]
    35ac:      	add	x0, x9, x8, lsl #2
    35b0:      	mov	w8, #0x200              // =512
    35b4:      	mov	w9, #0x70               // =112
    35b8:      	blr	x9
    35bc:      	cbz	x0, 0x361c <kprobe_unwind_dotnet+0x361c>
    35c0:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    35c4:      	ldr	x8, [x8]
    35c8:      	ldr	w8, [x8]
    35cc:      	cbnz	w8, 0x6900 <kprobe_unwind_dotnet+0x6900>
    35d0:      	mov	w8, #0x5e               // =94
    35d4:      	adrp	x0, 0x3000 <kprobe_unwind_dotnet+0x3000>
    35d8:      	add	x9, sp, #0x8c
    35dc:      	str	w8, [sp, #0x8c]
    35e0:      	mov	w8, #0x1                // =1
    35e4:      	add	x1, sp, #0x8c
    35e8:      	ldr	x0, [x0]
    35ec:      	blr	x8
    35f0:      	cbz	x0, 0x365c <kprobe_unwind_dotnet+0x365c>
    35f4:      	ldr	x8, [x0]
    35f8:      	add	x8, x8, #0x1
    35fc:      	str	x8, [x0]
    3600:      	mov	w22, wzr
    3604:      	mov	w2, #0x1772             // =6002
    3608:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    360c:      	ldr	x8, [x8]
    3610:      	ldr	w8, [x8]
    3614:      	cbz	w8, 0x3684 <kprobe_unwind_dotnet+0x3684>
    3618:      	b	0x69c0 <kprobe_unwind_dotnet+0x69c0>
    361c:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3620:      	ldr	w25, [x21, #0x116c]
    3624:      	ldr	x8, [x8]
    3628:      	ldr	w8, [x8]
    362c:      	cbnz	w8, 0x3cec <kprobe_unwind_dotnet+0x3cec>
    3630:      	mov	w8, #0x1c               // =28
    3634:      	bic	w8, w8, w23, lsr #3
    3638:      	lsr	w25, w25, w8
    363c:      	cbz	w25, 0x3d44 <kprobe_unwind_dotnet+0x3d44>
    3640:      	and	x29, x23, #0xffffffffffffffe0
    3644:      	ands	w3, w25, #0xf
    3648:      	b.ne	0x396c <kprobe_unwind_dotnet+0x396c>
    364c:      	ubfx	w3, w25, #4, #4
    3650:      	cbz	w3, 0x36f0 <kprobe_unwind_dotnet+0x36f0>
    3654:      	sub	x29, x29, #0x20
    3658:      	b	0x396c <kprobe_unwind_dotnet+0x396c>
    365c:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3660:      	ldr	x8, [x8]
    3664:      	ldr	w8, [x8]
    3668:      	cbnz	w8, 0x3dd8 <kprobe_unwind_dotnet+0x3dd8>
    366c:      	mov	w22, wzr
    3670:      	mov	w2, #0x1772             // =6002
    3674:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3678:      	ldr	x8, [x8]
    367c:      	ldr	w8, [x8]
    3680:      	cbnz	w8, 0x69c0 <kprobe_unwind_dotnet+0x69c0>
    3684:      	cbz	w22, 0x621c <kprobe_unwind_dotnet+0x621c>
    3688:      	ldr	w8, [x21, #0x2c0]
    368c:      	adrp	x23, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3690:      	adrp	x24, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3694:      	ldr	x23, [x23]
    3698:      	ldr	x24, [x24]
    369c:      	cmp	w8, #0x7e
    36a0:      	b.hi	0x49c <kprobe_unwind_dotnet+0x49c>
    36a4:      	add	w9, w8, #0x1
    36a8:      	mov	w10, #0x8a              // =138
    36ac:      	str	w9, [x21, #0x2c0]
    36b0:      	mov	w9, #0x18               // =24
    36b4:      	umaddl	x8, w8, w9, x21
    36b8:      	mov	w9, #0x1773             // =6003
    36bc:      	str	x9, [x8, #0x2d8]
    36c0:      	add	x9, x8, #0x2d0
    36c4:      	str	xzr, [x8, #0x2d0]
    36c8:      	strb	w10, [x8, #0x2e0]
    36cc:      	str	wzr, [x8, #0x2e4]
    36d0:      	stur	wzr, [x9, #0x11]
    36d4:      	ldr	x8, [sp, #0x10]
    36d8:      	ldr	x29, [x8]
    36dc:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    36e0:      	ldr	x8, [x8]
    36e4:      	ldr	w8, [x8]
    36e8:      	cbnz	x29, 0x3a88 <kprobe_unwind_dotnet+0x3a88>
    36ec:      	b	0x4d58 <kprobe_unwind_dotnet+0x4d58>
    36f0:      	ubfx	w3, w25, #8, #4
    36f4:      	cbz	w3, 0x3700 <kprobe_unwind_dotnet+0x3700>
    36f8:      	sub	x29, x29, #0x40
    36fc:      	b	0x396c <kprobe_unwind_dotnet+0x396c>
    3700:      	ubfx	w3, w25, #12, #4
    3704:      	cbz	w3, 0x3764 <kprobe_unwind_dotnet+0x3764>
    3708:      	sub	x29, x29, #0x60
    370c:      	b	0x396c <kprobe_unwind_dotnet+0x396c>
    3710:      	mov	w8, #0x786c             // =30828
    3714:      	add	x0, sp, #0x20
    3718:      	mov	w1, #0x23               // =35
    371c:      	mov	x2, x24
    3720:      	mov	x3, x25
    3724:      	mov	x4, x29
    3728:      	movk	w8, #0xa, lsl #16
    372c:      	stur	w8, [sp, #0x3f]
    3730:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3734:      	add	x8, x8, #0x0
    3738:      	ldp	x9, x10, [x8]
    373c:      	stp	x9, x10, [sp, #0x20]
    3740:      	ldp	x9, x8, [x8, #0x10]
    3744:      	add	x10, sp, #0x20
    3748:      	stp	x9, x8, [sp, #0x30]
    374c:      	mov	w8, #0x23               // =35
    3750:      	mov	w9, #0x6                // =6
    3754:      	blr	x9
    3758:      	cmp	x29, x25
    375c:      	b.hs	0x34ac <kprobe_unwind_dotnet+0x34ac>
    3760:      	b	0x45cc <kprobe_unwind_dotnet+0x45cc>
    3764:      	ubfx	w3, w25, #16, #4
    3768:      	cbz	w3, 0x3784 <kprobe_unwind_dotnet+0x3784>
    376c:      	sub	x29, x29, #0x80
    3770:      	b	0x396c <kprobe_unwind_dotnet+0x396c>
    3774:      	ldr	x8, [x21, #0x10c0]
    3778:      	cbz	x8, 0x3864 <kprobe_unwind_dotnet+0x3864>
    377c:      	mov	w9, #-0x54              // =-84
    3780:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    3784:      	ubfx	w3, w25, #20, #4
    3788:      	cbz	w3, 0x3874 <kprobe_unwind_dotnet+0x3874>
    378c:      	sub	x29, x29, #0xa0
    3790:      	b	0x396c <kprobe_unwind_dotnet+0x396c>
    3794:      	ldr	x8, [x21, #0x1118]
    3798:      	cbz	x8, 0x3884 <kprobe_unwind_dotnet+0x3884>
    379c:      	mov	w9, #-0x6a              // =-106
    37a0:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    37a4:      	mov	w8, #0x656e             // =25966
    37a8:      	add	x0, sp, #0x20
    37ac:      	mov	w1, #0x1b               // =27
    37b0:      	movk	w8, #0xa, lsl #16
    37b4:      	stur	w8, [sp, #0x37]
    37b8:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    37bc:      	add	x8, x8, #0x0
    37c0:      	ldp	x9, x10, [x8]
    37c4:      	ldr	x8, [x8, #0x10]
    37c8:      	stp	x9, x10, [sp, #0x20]
    37cc:      	str	x8, [sp, #0x30]
    37d0:      	mov	w8, #0x1b               // =27
    37d4:      	mov	w9, #0x6                // =6
    37d8:      	add	x10, sp, #0x20
    37dc:      	blr	x9
    37e0:      	mov	w25, #0x1               // =1
    37e4:      	cmp	w25, #0x8
    37e8:      	b.eq	0x3484 <kprobe_unwind_dotnet+0x3484>
    37ec:      	b	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    37f0:      	ldr	x8, [x21, #0x1090]
    37f4:      	cbz	x8, 0x3894 <kprobe_unwind_dotnet+0x3894>
    37f8:      	mov	w9, #-0x48              // =-72
    37fc:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    3800:      	ldr	x8, [x21, #0x10e8]
    3804:      	cbz	x8, 0x38a4 <kprobe_unwind_dotnet+0x38a4>
    3808:      	mov	w9, #-0x5e              // =-94
    380c:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    3810:      	mov	w8, #0x786c             // =30828
    3814:      	add	x0, sp, #0x20
    3818:      	mov	w1, #0x23               // =35
    381c:      	movk	w8, #0xa, lsl #16
    3820:      	stur	w8, [sp, #0x3f]
    3824:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3828:      	add	x8, x8, #0x0
    382c:      	ldp	x9, x10, [x8]
    3830:      	stp	x9, x10, [sp, #0x20]
    3834:      	ldp	x9, x8, [x8, #0x10]
    3838:      	add	x10, sp, #0x20
    383c:      	stp	x9, x8, [sp, #0x30]
    3840:      	mov	w8, #0x23               // =35
    3844:      	mov	w9, #0x6                // =6
    3848:      	ldr	x2, [x21, #0xed0]
    384c:      	ldr	x3, [x21, #0xed8]
    3850:      	ldr	x4, [x21, #0xee0]
    3854:      	blr	x9
    3858:      	cmp	x23, #0x100
    385c:      	b.hs	0x3558 <kprobe_unwind_dotnet+0x3558>
    3860:      	b	0x39bc <kprobe_unwind_dotnet+0x39bc>
    3864:      	ldr	x8, [x21, #0x10b8]
    3868:      	cbz	x8, 0x3954 <kprobe_unwind_dotnet+0x3954>
    386c:      	mov	w9, #-0x52              // =-82
    3870:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    3874:      	ubfx	w3, w25, #24, #4
    3878:      	cbz	w3, 0x3964 <kprobe_unwind_dotnet+0x3964>
    387c:      	sub	x29, x29, #0xc0
    3880:      	b	0x396c <kprobe_unwind_dotnet+0x396c>
    3884:      	ldr	x8, [x21, #0x1110]
    3888:      	cbz	x8, 0x3ccc <kprobe_unwind_dotnet+0x3ccc>
    388c:      	mov	w9, #-0x68              // =-104
    3890:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    3894:      	ldr	x8, [x21, #0x1088]
    3898:      	cbz	x8, 0x3cdc <kprobe_unwind_dotnet+0x3cdc>
    389c:      	mov	w9, #-0x46              // =-70
    38a0:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    38a4:      	ldr	x8, [x21, #0x10e0]
    38a8:      	cbz	x8, 0x3d6c <kprobe_unwind_dotnet+0x3d6c>
    38ac:      	mov	w9, #-0x5c              // =-92
    38b0:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    38b4:      	mov	w8, #0xa                // =10
    38b8:      	mov	w11, #0x6               // =6
    38bc:      	add	x0, sp, #0x20
    38c0:      	strh	w8, [sp, #0x60]
    38c4:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    38c8:      	add	x8, x8, #0x0
    38cc:      	mov	w1, #0x42               // =66
    38d0:      	ldp	x9, x10, [x8, #0x20]
    38d4:      	mov	x2, x23
    38d8:      	mov	x4, x25
    38dc:      	stp	x9, x10, [sp, #0x40]
    38e0:      	ldp	x9, x10, [x8, #0x30]
    38e4:      	stp	x9, x10, [sp, #0x50]
    38e8:      	ldp	x9, x10, [x8]
    38ec:      	stp	x9, x10, [sp, #0x20]
    38f0:      	ldp	x9, x8, [x8, #0x10]
    38f4:      	mov	w10, #0x42              // =66
    38f8:      	stp	x9, x8, [sp, #0x30]
    38fc:      	add	x8, sp, #0x20
    3900:      	ldr	x3, [sp, #0x8]
    3904:      	blr	x11
    3908:      	b	0x3578 <kprobe_unwind_dotnet+0x3578>
    390c:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3910:      	add	x8, x8, #0x0
    3914:      	add	x0, sp, #0x20
    3918:      	ldp	x9, x10, [x8, #0x10]
    391c:      	mov	w1, #0x2e               // =46
    3920:      	stp	x9, x10, [sp, #0x30]
    3924:      	ldr	x9, [x8, #0x20]
    3928:      	add	x10, sp, #0x20
    392c:      	str	x9, [sp, #0x40]
    3930:      	ldur	x9, [x8, #0x26]
    3934:      	stur	x9, [sp, #0x46]
    3938:      	ldp	x9, x8, [x8]
    393c:      	stp	x9, x8, [sp, #0x20]
    3940:      	mov	w8, #0x2e               // =46
    3944:      	mov	w9, #0x6                // =6
    3948:      	ldr	w2, [sp, #0x68]
    394c:      	blr	x9
    3950:      	b	0x3478 <kprobe_unwind_dotnet+0x3478>
    3954:      	ldr	x8, [x21, #0x10b0]
    3958:      	cbz	x8, 0x3d7c <kprobe_unwind_dotnet+0x3d7c>
    395c:      	mov	w9, #-0x50              // =-80
    3960:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    3964:      	lsr	w3, w25, #28
    3968:      	sub	x29, x29, #0xe0
    396c:      	ldr	x8, [sp, #0x8]
    3970:      	lsl	w9, w3, #2
    3974:      	sub	w9, w9, #0x4
    3978:      	add	x8, x29, x8
    397c:      	add	x25, x8, x9
    3980:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3984:      	ldr	x8, [x8]
    3988:      	ldr	w8, [x8]
    398c:      	cbnz	w8, 0x3d8c <kprobe_unwind_dotnet+0x3d8c>
    3990:      	sub	x2, x25, #0x8
    3994:      	mov	w8, #0x8                // =8
    3998:      	mov	w9, #0x70               // =112
    399c:      	add	x10, sp, #0x68
    39a0:      	add	x0, sp, #0x68
    39a4:      	mov	w1, #0x8                // =8
    39a8:      	blr	x9
    39ac:      	adrp	x23, 0x3000 <kprobe_unwind_dotnet+0x3000>
    39b0:      	ldr	x23, [x23]
    39b4:      	cbnz	x0, 0x844 <kprobe_unwind_dotnet+0x844>
    39b8:      	mov	w23, #0x1f              // =31
    39bc:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    39c0:      	ldr	x8, [x8]
    39c4:      	ldr	w8, [x8]
    39c8:      	cbnz	w8, 0x3bb4 <kprobe_unwind_dotnet+0x3bb4>
    39cc:      	ldr	w8, [x21, #0x2c0]
    39d0:      	cmp	w8, #0x7e
    39d4:      	b.hi	0x8a4 <kprobe_unwind_dotnet+0x8a4>
    39d8:      	ldr	x9, [sp, #0x68]
    39dc:      	add	w11, w8, #0x1
    39e0:      	sub	x10, x24, x25
    39e4:      	adrp	x0, 0x3000 <kprobe_unwind_dotnet+0x3000>
    39e8:      	str	w11, [x21, #0x2c0]
    39ec:      	mov	w11, #0x18              // =24
    39f0:      	add	x1, sp, #0x8c
    39f4:      	umaddl	x8, w8, w11, x21
    39f8:      	add	x9, x23, x9, lsl #5
    39fc:      	str	x10, [x8, #0x2d8]
    3a00:      	mov	w10, #0xa               // =10
    3a04:      	strb	w22, [x8, #0x2e1]
    3a08:      	strh	wzr, [x8, #0x2e6]
    3a0c:      	strb	w10, [x8, #0x2e0]
    3a10:      	str	x9, [x8, #0x2d0]
    3a14:      	add	x9, x8, #0x2d0
    3a18:      	mov	w8, #0x5b               // =91
    3a1c:      	stur	wzr, [x9, #0x12]
    3a20:      	str	w8, [sp, #0x8c]
    3a24:      	mov	w8, #0x1                // =1
    3a28:      	add	x9, sp, #0x8c
    3a2c:      	ldr	x0, [x0]
    3a30:      	blr	x8
    3a34:      	cbz	x0, 0x3a60 <kprobe_unwind_dotnet+0x3a60>
    3a38:      	ldr	x8, [x0]
    3a3c:      	add	x8, x8, #0x1
    3a40:      	str	x8, [x0]
    3a44:      	ldr	x8, [sp, #0x10]
    3a48:      	ldr	x29, [x8]
    3a4c:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3a50:      	ldr	x8, [x8]
    3a54:      	ldr	w8, [x8]
    3a58:      	cbnz	x29, 0x3a88 <kprobe_unwind_dotnet+0x3a88>
    3a5c:      	b	0x4d58 <kprobe_unwind_dotnet+0x4d58>
    3a60:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3a64:      	ldr	x8, [x8]
    3a68:      	ldr	w8, [x8]
    3a6c:      	cbnz	w8, 0x3c6c <kprobe_unwind_dotnet+0x3c6c>
    3a70:      	ldr	x8, [sp, #0x10]
    3a74:      	ldr	x29, [x8]
    3a78:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3a7c:      	ldr	x8, [x8]
    3a80:      	ldr	w8, [x8]
    3a84:      	cbz	x29, 0x4d58 <kprobe_unwind_dotnet+0x4d58>
    3a88:      	cbnz	w8, 0x3c1c <kprobe_unwind_dotnet+0x3c1c>
    3a8c:      	lsr	x8, x29, #56
    3a90:      	cbnz	x8, 0x1650 <kprobe_unwind_dotnet+0x1650>
    3a94:      	cmp	x29, #0x1, lsl #12      // =0x1000
    3a98:      	b.lo	0x1784 <kprobe_unwind_dotnet+0x1784>
    3a9c:      	ldr	w8, [x21]
    3aa0:      	mov	w9, #0x60               // =96
    3aa4:      	adrp	x0, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3aa8:      	add	x1, sp, #0x70
    3aac:      	rev	w8, w8
    3ab0:      	stp	w9, w8, [sp, #0x70]
    3ab4:      	rev	x8, x29
    3ab8:      	add	x9, sp, #0x70
    3abc:      	str	x8, [sp, #0x78]
    3ac0:      	mov	w8, #0x1                // =1
    3ac4:      	ldr	x0, [x0]
    3ac8:      	blr	x8
    3acc:      	cbz	x0, 0x4eec <kprobe_unwind_dotnet+0x4eec>
    3ad0:      	ldr	x8, [x0, #0x8]
    3ad4:      	and	x9, x8, #0xffffffffffffff
    3ad8:      	lsr	x25, x8, #56
    3adc:      	str	x9, [x21, #0xf10]
    3ae0:      	ldr	x8, [x0]
    3ae4:      	str	x8, [x21, #0xf00]
    3ae8:      	sub	x8, x29, x9
    3aec:      	str	x8, [x21, #0xf08]
    3af0:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3af4:      	ldr	x8, [x8]
    3af8:      	ldr	w8, [x8]
    3afc:      	cbnz	w8, 0x4094 <kprobe_unwind_dotnet+0x4094>
    3b00:      	cmp	w25, #0x1
    3b04:      	b.ne	0x42e8 <kprobe_unwind_dotnet+0x42e8>
    3b08:      	ldr	x8, [x21, #0xf00]
    3b0c:      	adrp	x0, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3b10:      	ldr	x22, [x21, #0xf08]
    3b14:      	mov	w9, #0x1                // =1
    3b18:      	add	x1, sp, #0x70
    3b1c:      	mov	w25, #0x1               // =1
    3b20:      	str	x8, [sp, #0x70]
    3b24:      	add	x8, sp, #0x70
    3b28:      	ldr	x0, [x0]
    3b2c:      	blr	x9
    3b30:      	cbz	x0, 0x3ba8 <kprobe_unwind_dotnet+0x3ba8>
    3b34:      	ldr	x8, [x0]
    3b38:      	mov	x23, x0
    3b3c:      	cmp	x8, x22
    3b40:      	b.hi	0x3b50 <kprobe_unwind_dotnet+0x3b50>
    3b44:      	ldr	x8, [x23, #0x8]
    3b48:      	cmp	x8, x22
    3b4c:      	b.hs	0x3b68 <kprobe_unwind_dotnet+0x3b68>
    3b50:      	ldr	x8, [x23, #0x10]
    3b54:      	cmp	x8, x22
    3b58:      	b.hi	0x3b98 <kprobe_unwind_dotnet+0x3b98>
    3b5c:      	ldr	x8, [x23, #0x18]
    3b60:      	cmp	x8, x22
    3b64:      	b.lo	0x3b98 <kprobe_unwind_dotnet+0x3b98>
    3b68:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3b6c:      	ldr	x8, [x8]
    3b70:      	ldr	w8, [x8]
    3b74:      	cbnz	w8, 0x4258 <kprobe_unwind_dotnet+0x4258>
    3b78:      	ldrh	w8, [x23, #0x20]
    3b7c:      	ldr	w9, [x21, #0x1370]
    3b80:      	lsr	w8, w9, w8
    3b84:      	tbz	w8, #0x0, 0x42a4 <kprobe_unwind_dotnet+0x42a4>
    3b88:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3b8c:      	ldr	x8, [x8]
    3b90:      	ldr	w8, [x8]
    3b94:      	cbnz	w8, 0x4834 <kprobe_unwind_dotnet+0x4834>
    3b98:      	mov	w25, #0x1               // =1
    3b9c:      	cmp	w25, #0x8
    3ba0:      	b.eq	0x42f0 <kprobe_unwind_dotnet+0x42f0>
    3ba4:      	b	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    3ba8:      	cmp	w25, #0x8
    3bac:      	b.eq	0x42f0 <kprobe_unwind_dotnet+0x42f0>
    3bb0:      	b	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    3bb4:      	mov	w8, #0x786c             // =30828
    3bb8:      	sub	x4, x24, x25
    3bbc:      	add	x0, sp, #0x20
    3bc0:      	mov	w1, #0x43               // =67
    3bc4:      	mov	x2, x25
    3bc8:      	movk	w8, #0xa, lsl #16
    3bcc:      	stur	w8, [sp, #0x5f]
    3bd0:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3bd4:      	add	x8, x8, #0x0
    3bd8:      	ldp	x9, x10, [x8, #0x20]
    3bdc:      	stp	x9, x10, [sp, #0x40]
    3be0:      	ldp	x9, x10, [x8, #0x30]
    3be4:      	stp	x9, x10, [sp, #0x50]
    3be8:      	ldp	x9, x10, [x8]
    3bec:      	stp	x9, x10, [sp, #0x20]
    3bf0:      	ldp	x9, x8, [x8, #0x10]
    3bf4:      	add	x10, sp, #0x20
    3bf8:      	stp	x9, x8, [sp, #0x30]
    3bfc:      	mov	w8, #0x43               // =67
    3c00:      	mov	w9, #0x6                // =6
    3c04:      	ldr	x3, [sp, #0x68]
    3c08:      	blr	x9
    3c0c:      	ldr	w8, [x21, #0x2c0]
    3c10:      	cmp	w8, #0x7e
    3c14:      	b.hi	0x8a4 <kprobe_unwind_dotnet+0x8a4>
    3c18:      	b	0x39d8 <kprobe_unwind_dotnet+0x39d8>
    3c1c:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3c20:      	add	x8, x8, #0x0
    3c24:      	strb	wzr, [sp, #0x50]
    3c28:      	add	x0, sp, #0x20
    3c2c:      	ldp	x9, x10, [x8, #0x10]
    3c30:      	mov	w1, #0x31               // =49
    3c34:      	stp	x9, x10, [sp, #0x30]
    3c38:      	ldp	x9, x10, [x8, #0x20]
    3c3c:      	stp	x9, x10, [sp, #0x40]
    3c40:      	ldp	x9, x8, [x8]
    3c44:      	add	x10, sp, #0x20
    3c48:      	stp	x9, x8, [sp, #0x20]
    3c4c:      	mov	w8, #0x31               // =49
    3c50:      	mov	w9, #0x6                // =6
    3c54:      	ldr	w2, [x21, #0x2c0]
    3c58:      	blr	x9
    3c5c:      	ldr	x29, [x21, #0xed0]
    3c60:      	lsr	x8, x29, #56
    3c64:      	cbnz	x8, 0x1650 <kprobe_unwind_dotnet+0x1650>
    3c68:      	b	0x3a94 <kprobe_unwind_dotnet+0x3a94>
    3c6c:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3c70:      	add	x8, x8, #0x0
    3c74:      	add	x0, sp, #0x20
    3c78:      	ldp	x9, x10, [x8, #0x10]
    3c7c:      	mov	w1, #0x2e               // =46
    3c80:      	stp	x9, x10, [sp, #0x30]
    3c84:      	ldr	x9, [x8, #0x20]
    3c88:      	add	x10, sp, #0x20
    3c8c:      	str	x9, [sp, #0x40]
    3c90:      	ldur	x9, [x8, #0x26]
    3c94:      	stur	x9, [sp, #0x46]
    3c98:      	ldp	x9, x8, [x8]
    3c9c:      	stp	x9, x8, [sp, #0x20]
    3ca0:      	mov	w8, #0x2e               // =46
    3ca4:      	mov	w9, #0x6                // =6
    3ca8:      	ldr	w2, [sp, #0x8c]
    3cac:      	blr	x9
    3cb0:      	ldr	x8, [sp, #0x10]
    3cb4:      	ldr	x29, [x8]
    3cb8:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3cbc:      	ldr	x8, [x8]
    3cc0:      	ldr	w8, [x8]
    3cc4:      	cbnz	x29, 0x3a88 <kprobe_unwind_dotnet+0x3a88>
    3cc8:      	b	0x4d58 <kprobe_unwind_dotnet+0x4d58>
    3ccc:      	ldr	x8, [x21, #0x1108]
    3cd0:      	cbz	x8, 0x3e38 <kprobe_unwind_dotnet+0x3e38>
    3cd4:      	mov	w9, #-0x66              // =-102
    3cd8:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    3cdc:      	ldr	x8, [x21, #0x1080]
    3ce0:      	cbz	x8, 0x4084 <kprobe_unwind_dotnet+0x4084>
    3ce4:      	mov	w9, #-0x44              // =-68
    3ce8:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    3cec:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3cf0:      	add	x8, x8, #0x0
    3cf4:      	add	x0, sp, #0x20
    3cf8:      	ldp	x9, x10, [x8, #0x20]
    3cfc:      	and	x2, x23, #0xfffffffffffffffc
    3d00:      	mov	w1, #0x36               // =54
    3d04:      	mov	w3, w25
    3d08:      	stp	x9, x10, [sp, #0x40]
    3d0c:      	ldur	x9, [x8, #0x2e]
    3d10:      	stur	x9, [sp, #0x4e]
    3d14:      	ldp	x9, x10, [x8]
    3d18:      	stp	x9, x10, [sp, #0x20]
    3d1c:      	ldp	x8, x9, [x8, #0x10]
    3d20:      	add	x10, sp, #0x20
    3d24:      	stp	x8, x9, [sp, #0x30]
    3d28:      	mov	w8, #0x36               // =54
    3d2c:      	mov	w9, #0x6                // =6
    3d30:      	blr	x9
    3d34:      	mov	w8, #0x1c               // =28
    3d38:      	bic	w8, w8, w23, lsr #3
    3d3c:      	lsr	w25, w25, w8
    3d40:      	cbnz	w25, 0x3640 <kprobe_unwind_dotnet+0x3640>
    3d44:      	and	x8, x23, #0xffffffffffffff00
    3d48:      	ldr	w25, [x21, #0x1168]
    3d4c:      	sub	x23, x8, #0x20
    3d50:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3d54:      	ldr	x8, [x8]
    3d58:      	ldr	w8, [x8]
    3d5c:      	cbnz	w8, 0x413c <kprobe_unwind_dotnet+0x413c>
    3d60:      	cbz	w25, 0x4188 <kprobe_unwind_dotnet+0x4188>
    3d64:      	mov	w3, wzr
    3d68:      	b	0x6894 <kprobe_unwind_dotnet+0x6894>
    3d6c:      	ldr	x8, [x21, #0x10d8]
    3d70:      	cbz	x8, 0x41f8 <kprobe_unwind_dotnet+0x41f8>
    3d74:      	mov	w9, #-0x5a              // =-90
    3d78:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    3d7c:      	ldr	x8, [x21, #0x10a8]
    3d80:      	cbz	x8, 0x4208 <kprobe_unwind_dotnet+0x4208>
    3d84:      	mov	w9, #-0x4e              // =-78
    3d88:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    3d8c:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3d90:      	add	x8, x8, #0x0
    3d94:      	add	x0, sp, #0x20
    3d98:      	ldp	x9, x10, [x8, #0x10]
    3d9c:      	mov	w1, #0x2e               // =46
    3da0:      	mov	x2, x29
    3da4:      	mov	x4, x25
    3da8:      	stp	x9, x10, [sp, #0x30]
    3dac:      	ldr	x9, [x8, #0x20]
    3db0:      	add	x10, sp, #0x20
    3db4:      	str	x9, [sp, #0x40]
    3db8:      	ldur	x9, [x8, #0x26]
    3dbc:      	stur	x9, [sp, #0x46]
    3dc0:      	ldp	x9, x8, [x8]
    3dc4:      	stp	x9, x8, [sp, #0x20]
    3dc8:      	mov	w8, #0x2e               // =46
    3dcc:      	mov	w9, #0x6                // =6
    3dd0:      	blr	x9
    3dd4:      	b	0x3990 <kprobe_unwind_dotnet+0x3990>
    3dd8:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3ddc:      	add	x8, x8, #0x0
    3de0:      	add	x0, sp, #0x20
    3de4:      	ldp	x9, x10, [x8, #0x10]
    3de8:      	mov	w1, #0x2e               // =46
    3dec:      	stp	x9, x10, [sp, #0x30]
    3df0:      	ldr	x9, [x8, #0x20]
    3df4:      	add	x10, sp, #0x20
    3df8:      	str	x9, [sp, #0x40]
    3dfc:      	ldur	x9, [x8, #0x26]
    3e00:      	stur	x9, [sp, #0x46]
    3e04:      	ldp	x9, x8, [x8]
    3e08:      	stp	x9, x8, [sp, #0x20]
    3e0c:      	mov	w8, #0x2e               // =46
    3e10:      	mov	w9, #0x6                // =6
    3e14:      	ldr	w2, [sp, #0x8c]
    3e18:      	blr	x9
    3e1c:      	mov	w22, wzr
    3e20:      	mov	w2, #0x1772             // =6002
    3e24:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3e28:      	ldr	x8, [x8]
    3e2c:      	ldr	w8, [x8]
    3e30:      	cbz	w8, 0x3684 <kprobe_unwind_dotnet+0x3684>
    3e34:      	b	0x69c0 <kprobe_unwind_dotnet+0x69c0>
    3e38:      	ldr	x8, [x21, #0x1100]
    3e3c:      	cbz	x8, 0x4228 <kprobe_unwind_dotnet+0x4228>
    3e40:      	mov	w9, #-0x64              // =-100
    3e44:      	lsr	x10, x8, #32
    3e48:      	cmp	x10, #0x0
    3e4c:      	cset	w11, ne
    3e50:      	csel	w25, w10, w8, ne
    3e54:      	sub	w8, w9, w11
    3e58:      	add	w3, w8, #0x7e
    3e5c:      	lsl	w8, w3, #8
    3e60:      	subs	x29, x23, x8
    3e64:      	b.hs	0x3f00 <kprobe_unwind_dotnet+0x3f00>
    3e68:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3e6c:      	ldr	x8, [x8]
    3e70:      	ldr	w8, [x8]
    3e74:      	cbz	w8, 0x29c0 <kprobe_unwind_dotnet+0x29c0>
    3e78:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3e7c:      	add	x8, x8, #0x0
    3e80:      	add	x0, sp, #0x20
    3e84:      	ldp	x9, x10, [x8, #0x10]
    3e88:      	mov	w1, #0x2e               // =46
    3e8c:      	stp	x9, x10, [sp, #0x30]
    3e90:      	ldr	x9, [x8, #0x20]
    3e94:      	add	x10, sp, #0x20
    3e98:      	str	x9, [sp, #0x40]
    3e9c:      	ldur	x9, [x8, #0x26]
    3ea0:      	stur	x9, [sp, #0x46]
    3ea4:      	ldp	x9, x8, [x8]
    3ea8:      	stp	x9, x8, [sp, #0x20]
    3eac:      	mov	w8, #0x2e               // =46
    3eb0:      	mov	w9, #0x6                // =6
    3eb4:      	blr	x9
    3eb8:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3ebc:      	ldr	x8, [x8]
    3ec0:      	ldr	w8, [x8]
    3ec4:      	cbz	w8, 0x29c0 <kprobe_unwind_dotnet+0x29c0>
    3ec8:      	mov	w8, #0x646e             // =25710
    3ecc:      	add	x10, sp, #0x20
    3ed0:      	add	x0, sp, #0x20
    3ed4:      	mov	w1, #0x13               // =19
    3ed8:      	movk	w8, #0xa, lsl #16
    3edc:      	stur	w8, [sp, #0x2f]
    3ee0:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3ee4:      	add	x8, x8, #0x0
    3ee8:      	ldp	x9, x8, [x8]
    3eec:      	stp	x9, x8, [sp, #0x20]
    3ef0:      	mov	w8, #0x13               // =19
    3ef4:      	mov	w9, #0x6                // =6
    3ef8:      	blr	x9
    3efc:      	b	0x29c0 <kprobe_unwind_dotnet+0x29c0>
    3f00:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3f04:      	ldr	x8, [x8]
    3f08:      	ldr	w8, [x8]
    3f0c:      	cbnz	w8, 0x3fc8 <kprobe_unwind_dotnet+0x3fc8>
    3f10:      	cbnz	w25, 0x2a34 <kprobe_unwind_dotnet+0x2a34>
    3f14:      	mov	w8, #0x5f               // =95
    3f18:      	adrp	x0, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3f1c:      	add	x9, sp, #0x8c
    3f20:      	str	w8, [sp, #0x8c]
    3f24:      	mov	w8, #0x1                // =1
    3f28:      	add	x1, sp, #0x8c
    3f2c:      	ldr	x0, [x0]
    3f30:      	blr	x8
    3f34:      	cbz	x0, 0x3f60 <kprobe_unwind_dotnet+0x3f60>
    3f38:      	ldr	x8, [x0]
    3f3c:      	add	x8, x8, #0x1
    3f40:      	str	x8, [x0]
    3f44:      	mov	w2, #0x1773             // =6003
    3f48:      	mov	w22, #0x1               // =1
    3f4c:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3f50:      	ldr	x8, [x8]
    3f54:      	ldr	w8, [x8]
    3f58:      	cbz	w8, 0x2a74 <kprobe_unwind_dotnet+0x2a74>
    3f5c:      	b	0x3f88 <kprobe_unwind_dotnet+0x3f88>
    3f60:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3f64:      	ldr	x8, [x8]
    3f68:      	ldr	w8, [x8]
    3f6c:      	cbnz	w8, 0x4024 <kprobe_unwind_dotnet+0x4024>
    3f70:      	mov	w2, #0x1773             // =6003
    3f74:      	mov	w22, #0x1               // =1
    3f78:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3f7c:      	ldr	x8, [x8]
    3f80:      	ldr	w8, [x8]
    3f84:      	cbz	w8, 0x2a74 <kprobe_unwind_dotnet+0x2a74>
    3f88:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3f8c:      	add	x8, x8, #0x0
    3f90:      	add	x0, sp, #0x20
    3f94:      	ldp	x9, x10, [x8, #0x10]
    3f98:      	mov	w1, #0x28               // =40
    3f9c:      	stp	x9, x10, [sp, #0x30]
    3fa0:      	ldr	x9, [x8, #0x20]
    3fa4:      	add	x10, sp, #0x20
    3fa8:      	str	x9, [sp, #0x40]
    3fac:      	ldp	x8, x9, [x8]
    3fb0:      	stp	x8, x9, [sp, #0x20]
    3fb4:      	mov	w8, #0x28               // =40
    3fb8:      	mov	w9, #0x6                // =6
    3fbc:      	blr	x9
    3fc0:      	cbnz	w22, 0x2a78 <kprobe_unwind_dotnet+0x2a78>
    3fc4:      	b	0x621c <kprobe_unwind_dotnet+0x621c>
    3fc8:      	mov	w8, #0x7825             // =30757
    3fcc:      	add	x0, sp, #0x20
    3fd0:      	mov	w1, #0x3c               // =60
    3fd4:      	mov	x2, x29
    3fd8:      	mov	w4, w25
    3fdc:      	movk	w8, #0xa, lsl #16
    3fe0:      	str	w8, [sp, #0x58]
    3fe4:      	adrp	x8, 0x3000 <kprobe_unwind_dotnet+0x3000>
    3fe8:      	add	x8, x8, #0x0
    3fec:      	ldp	x9, x10, [x8, #0x20]
    3ff0:      	stp	x9, x10, [sp, #0x40]
    3ff4:      	ldr	x9, [x8, #0x30]
    3ff8:      	str	x9, [sp, #0x50]
    3ffc:      	ldp	x9, x10, [x8]
    4000:      	stp	x9, x10, [sp, #0x20]
    4004:      	add	x10, sp, #0x20
    4008:      	ldp	x8, x9, [x8, #0x10]
    400c:      	stp	x8, x9, [sp, #0x30]
    4010:      	mov	w8, #0x3c               // =60
    4014:      	mov	w9, #0x6                // =6
    4018:      	blr	x9
    401c:      	cbnz	w25, 0x2a34 <kprobe_unwind_dotnet+0x2a34>
    4020:      	b	0x3f14 <kprobe_unwind_dotnet+0x3f14>
    4024:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4028:      	add	x8, x8, #0x0
    402c:      	add	x0, sp, #0x20
    4030:      	ldp	x9, x10, [x8, #0x10]
    4034:      	mov	w1, #0x2e               // =46
    4038:      	stp	x9, x10, [sp, #0x30]
    403c:      	ldr	x9, [x8, #0x20]
    4040:      	add	x10, sp, #0x20
    4044:      	str	x9, [sp, #0x40]
    4048:      	ldur	x9, [x8, #0x26]
    404c:      	stur	x9, [sp, #0x46]
    4050:      	ldp	x9, x8, [x8]
    4054:      	stp	x9, x8, [sp, #0x20]
    4058:      	mov	w8, #0x2e               // =46
    405c:      	mov	w9, #0x6                // =6
    4060:      	ldr	w2, [sp, #0x8c]
    4064:      	blr	x9
    4068:      	mov	w2, #0x1773             // =6003
    406c:      	mov	w22, #0x1               // =1
    4070:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4074:      	ldr	x8, [x8]
    4078:      	ldr	w8, [x8]
    407c:      	cbz	w8, 0x2a74 <kprobe_unwind_dotnet+0x2a74>
    4080:      	b	0x3f88 <kprobe_unwind_dotnet+0x3f88>
    4084:      	ldr	x8, [x21, #0x1078]
    4088:      	cbz	x8, 0x4238 <kprobe_unwind_dotnet+0x4238>
    408c:      	mov	w9, #-0x42              // =-66
    4090:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    4094:      	mov	w8, #0xa                // =10
    4098:      	add	x0, sp, #0x20
    409c:      	mov	w1, #0x32               // =50
    40a0:      	strh	w8, [sp, #0x50]
    40a4:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    40a8:      	add	x8, x8, #0x0
    40ac:      	mov	x2, x29
    40b0:      	ldp	x9, x10, [x8, #0x10]
    40b4:      	mov	w4, w25
    40b8:      	stp	x9, x10, [sp, #0x30]
    40bc:      	ldp	x9, x10, [x8, #0x20]
    40c0:      	stp	x9, x10, [sp, #0x40]
    40c4:      	ldp	x9, x8, [x8]
    40c8:      	add	x10, sp, #0x20
    40cc:      	stp	x9, x8, [sp, #0x20]
    40d0:      	mov	w8, #0x32               // =50
    40d4:      	mov	w9, #0x6                // =6
    40d8:      	ldr	x3, [x21, #0xf00]
    40dc:      	blr	x9
    40e0:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    40e4:      	ldr	x8, [x8]
    40e8:      	ldr	w8, [x8]
    40ec:      	cbz	w8, 0x3b00 <kprobe_unwind_dotnet+0x3b00>
    40f0:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    40f4:      	add	x8, x8, #0x0
    40f8:      	add	x0, sp, #0x20
    40fc:      	ldp	x9, x10, [x8, #0x10]
    4100:      	mov	w1, #0x2f               // =47
    4104:      	stp	x9, x10, [sp, #0x30]
    4108:      	ldr	x9, [x8, #0x20]
    410c:      	add	x10, sp, #0x20
    4110:      	str	x9, [sp, #0x40]
    4114:      	ldur	x9, [x8, #0x27]
    4118:      	stur	x9, [sp, #0x47]
    411c:      	ldp	x9, x8, [x8]
    4120:      	stp	x9, x8, [sp, #0x20]
    4124:      	mov	w8, #0x2f               // =47
    4128:      	mov	w9, #0x6                // =6
    412c:      	ldr	x2, [x21, #0xf10]
    4130:      	ldr	x3, [x21, #0xf08]
    4134:      	blr	x9
    4138:      	b	0x3b00 <kprobe_unwind_dotnet+0x3b00>
    413c:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4140:      	add	x8, x8, #0x0
    4144:      	add	x0, sp, #0x20
    4148:      	ldp	x9, x10, [x8, #0x20]
    414c:      	mov	w1, #0x37               // =55
    4150:      	mov	x2, x23
    4154:      	mov	w3, w25
    4158:      	stp	x9, x10, [sp, #0x40]
    415c:      	ldur	x9, [x8, #0x2f]
    4160:      	stur	x9, [sp, #0x4f]
    4164:      	ldp	x9, x10, [x8]
    4168:      	stp	x9, x10, [sp, #0x20]
    416c:      	ldp	x8, x9, [x8, #0x10]
    4170:      	add	x10, sp, #0x20
    4174:      	stp	x8, x9, [sp, #0x30]
    4178:      	mov	w8, #0x37               // =55
    417c:      	mov	w9, #0x6                // =6
    4180:      	blr	x9
    4184:      	cbnz	w25, 0x3d64 <kprobe_unwind_dotnet+0x3d64>
    4188:      	ldr	x8, [x21, #0x1160]
    418c:      	cbz	x8, 0x4198 <kprobe_unwind_dotnet+0x4198>
    4190:      	mov	w9, #-0x7c              // =-124
    4194:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    4198:      	ldr	x8, [x21, #0x1158]
    419c:      	cbz	x8, 0x41a8 <kprobe_unwind_dotnet+0x41a8>
    41a0:      	mov	w9, #-0x7a              // =-122
    41a4:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    41a8:      	ldr	x8, [x21, #0x1150]
    41ac:      	cbz	x8, 0x41b8 <kprobe_unwind_dotnet+0x41b8>
    41b0:      	mov	w9, #-0x78              // =-120
    41b4:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    41b8:      	ldr	x8, [x21, #0x1148]
    41bc:      	cbz	x8, 0x41c8 <kprobe_unwind_dotnet+0x41c8>
    41c0:      	mov	w9, #-0x76              // =-118
    41c4:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    41c8:      	ldr	x8, [x21, #0x1140]
    41cc:      	cbz	x8, 0x41d8 <kprobe_unwind_dotnet+0x41d8>
    41d0:      	mov	w9, #-0x74              // =-116
    41d4:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    41d8:      	ldr	x8, [x21, #0x1138]
    41dc:      	cbz	x8, 0x41e8 <kprobe_unwind_dotnet+0x41e8>
    41e0:      	mov	w9, #-0x72              // =-114
    41e4:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    41e8:      	ldr	x8, [x21, #0x1130]
    41ec:      	cbz	x8, 0x4218 <kprobe_unwind_dotnet+0x4218>
    41f0:      	mov	w9, #-0x70              // =-112
    41f4:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    41f8:      	ldr	x8, [x21, #0x10d0]
    41fc:      	cbz	x8, 0x4248 <kprobe_unwind_dotnet+0x4248>
    4200:      	mov	w9, #-0x58              // =-88
    4204:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    4208:      	ldr	x8, [x21, #0x10a0]
    420c:      	cbz	x8, 0x4880 <kprobe_unwind_dotnet+0x4880>
    4210:      	mov	w9, #-0x4c              // =-76
    4214:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    4218:      	ldr	x8, [x21, #0x1128]
    421c:      	cbz	x8, 0x4890 <kprobe_unwind_dotnet+0x4890>
    4220:      	mov	w9, #-0x6e              // =-110
    4224:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    4228:      	ldr	x8, [x21, #0x10f8]
    422c:      	cbz	x8, 0x48a0 <kprobe_unwind_dotnet+0x48a0>
    4230:      	mov	w9, #-0x62              // =-98
    4234:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    4238:      	ldr	x8, [x21, #0x1070]
    423c:      	cbz	x8, 0x48b0 <kprobe_unwind_dotnet+0x48b0>
    4240:      	mov	w9, #-0x40              // =-64
    4244:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    4248:      	ldr	x8, [x21, #0x10c8]
    424c:      	cbz	x8, 0x48c0 <kprobe_unwind_dotnet+0x48c0>
    4250:      	mov	w9, #-0x56              // =-86
    4254:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    4258:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    425c:      	add	x8, x8, #0x0
    4260:      	add	x0, sp, #0x20
    4264:      	ldp	x9, x10, [x8]
    4268:      	mov	w1, #0x1e               // =30
    426c:      	stp	x9, x10, [sp, #0x20]
    4270:      	ldr	x9, [x8, #0x10]
    4274:      	ldur	x8, [x8, #0x16]
    4278:      	add	x10, sp, #0x20
    427c:      	str	x9, [sp, #0x30]
    4280:      	stur	x8, [sp, #0x36]
    4284:      	mov	w8, #0x1e               // =30
    4288:      	mov	w9, #0x6                // =6
    428c:      	ldrh	w2, [x23, #0x20]
    4290:      	blr	x9
    4294:      	ldrh	w8, [x23, #0x20]
    4298:      	ldr	w9, [x21, #0x1370]
    429c:      	lsr	w8, w9, w8
    42a0:      	tbnz	w8, #0x0, 0x3b88 <kprobe_unwind_dotnet+0x3b88>
    42a4:      	str	wzr, [sp, #0x68]
    42a8:      	adrp	x0, 0x4000 <kprobe_unwind_dotnet+0x4000>
    42ac:      	mov	w8, #0x1                // =1
    42b0:      	add	x9, sp, #0x68
    42b4:      	ldr	x0, [x0]
    42b8:      	add	x1, sp, #0x68
    42bc:      	blr	x8
    42c0:      	cbz	x0, 0x42d4 <kprobe_unwind_dotnet+0x42d4>
    42c4:      	ldr	x8, [x0]
    42c8:      	add	x8, x8, #0x1
    42cc:      	str	x8, [x0]
    42d0:      	b	0x42e4 <kprobe_unwind_dotnet+0x42e4>
    42d4:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    42d8:      	ldr	x8, [x8]
    42dc:      	ldr	w8, [x8]
    42e0:      	cbnz	w8, 0x48d0 <kprobe_unwind_dotnet+0x48d0>
    42e4:      	ldrh	w25, [x23, #0x20]
    42e8:      	cmp	w25, #0x8
    42ec:      	b.ne	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    42f0:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    42f4:      	ldr	x25, [x21, #0xed8]
    42f8:      	ldr	x29, [x21, #0xee0]
    42fc:      	ldr	x24, [x21, #0xed0]
    4300:      	ldrb	w22, [x21, #0xf20]
    4304:      	ldr	x8, [x8]
    4308:      	ldr	w8, [x8]
    430c:      	cbnz	w8, 0x457c <kprobe_unwind_dotnet+0x457c>
    4310:      	cmp	x29, x25
    4314:      	b.lo	0x45cc <kprobe_unwind_dotnet+0x45cc>
    4318:      	add	x8, x25, #0x2, lsl #12  // =0x2000
    431c:      	cmp	x29, x8
    4320:      	b.hs	0x45cc <kprobe_unwind_dotnet+0x45cc>
    4324:      	ldr	x23, [x21, #0xf00]
    4328:      	ldr	x25, [x21, #0xf10]
    432c:      	mov	w8, #0x101              // =257
    4330:      	str	x24, [sp, #0x68]
    4334:      	strh	w8, [x21, #0xf20]
    4338:      	and	x8, x23, #0xffffffffffffff80
    433c:      	cmp	x8, #0x80
    4340:      	b.ne	0x4378 <kprobe_unwind_dotnet+0x4378>
    4344:      	ldr	x8, [x21, #0xed8]
    4348:      	mov	w9, #0x8                // =8
    434c:      	mov	w10, #0x70              // =112
    4350:      	ldr	x0, [sp, #0x10]
    4354:      	mov	w1, #0x8                // =8
    4358:      	ldr	x2, [x21, #0xed8]
    435c:      	blr	x10
    4360:      	cbnz	x0, 0x1e0 <kprobe_unwind_dotnet+0x1e0>
    4364:      	ldr	x8, [x21, #0xed8]
    4368:      	and	x23, x23, #0x7f
    436c:      	add	x8, x8, #0x8
    4370:      	str	x8, [x21, #0xed8]
    4374:      	b	0x4cb8 <kprobe_unwind_dotnet+0x4cb8>
    4378:      	mov	w8, #0x10               // =16
    437c:      	mov	w9, #0x70               // =112
    4380:      	add	x10, sp, #0x70
    4384:      	add	x0, sp, #0x70
    4388:      	mov	w1, #0x10               // =16
    438c:      	mov	x2, x29
    4390:      	blr	x9
    4394:      	cbnz	x0, 0x27c <kprobe_unwind_dotnet+0x27c>
    4398:      	add	x8, x29, #0x10
    439c:      	str	x8, [x21, #0xed8]
    43a0:      	ldp	x8, x9, [sp, #0x70]
    43a4:      	str	x8, [x21, #0xee0]
    43a8:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    43ac:      	str	x9, [x21, #0xed0]
    43b0:      	ldr	x8, [x8]
    43b4:      	ldr	w8, [x8]
    43b8:      	cbnz	w8, 0x4918 <kprobe_unwind_dotnet+0x4918>
    43bc:      	cmp	x23, #0x100
    43c0:      	b.lo	0x4cb8 <kprobe_unwind_dotnet+0x4cb8>
    43c4:      	ldr	x8, [x21, #0xf10]
    43c8:      	ldr	x25, [x21, #0xf00]
    43cc:      	sub	x23, x24, x8
    43d0:      	str	x8, [sp, #0x8]
    43d4:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    43d8:      	ldr	x8, [x8]
    43dc:      	ldr	w8, [x8]
    43e0:      	cbnz	w8, 0x496c <kprobe_unwind_dotnet+0x496c>
    43e4:      	lsr	x8, x23, #8
    43e8:      	mov	w9, #0x7f               // =127
    43ec:      	lsr	x10, x23, #15
    43f0:      	mov	w1, #0x200              // =512
    43f4:      	sub	w9, w9, w8
    43f8:      	lsl	x8, x8, #2
    43fc:      	cmp	x10, #0x0
    4400:      	sub	x8, x8, #0x3fc
    4404:      	and	x9, x9, #0x7f
    4408:      	csel	x8, x8, xzr, ne
    440c:      	add	x2, x8, x25
    4410:      	csel	x8, xzr, x9, ne
    4414:      	ldr	x9, [sp, #0x18]
    4418:      	add	x0, x9, x8, lsl #2
    441c:      	mov	w8, #0x200              // =512
    4420:      	mov	w9, #0x70               // =112
    4424:      	blr	x9
    4428:      	cbz	x0, 0x4488 <kprobe_unwind_dotnet+0x4488>
    442c:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4430:      	ldr	x8, [x8]
    4434:      	ldr	w8, [x8]
    4438:      	cbnz	w8, 0x6bbc <kprobe_unwind_dotnet+0x6bbc>
    443c:      	mov	w8, #0x5e               // =94
    4440:      	adrp	x0, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4444:      	add	x9, sp, #0x8c
    4448:      	str	w8, [sp, #0x8c]
    444c:      	mov	w8, #0x1                // =1
    4450:      	add	x1, sp, #0x8c
    4454:      	ldr	x0, [x0]
    4458:      	blr	x8
    445c:      	cbz	x0, 0x44c8 <kprobe_unwind_dotnet+0x44c8>
    4460:      	ldr	x8, [x0]
    4464:      	add	x8, x8, #0x1
    4468:      	str	x8, [x0]
    446c:      	mov	w22, wzr
    4470:      	mov	w2, #0x1772             // =6002
    4474:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4478:      	ldr	x8, [x8]
    447c:      	ldr	w8, [x8]
    4480:      	cbz	w8, 0x44f0 <kprobe_unwind_dotnet+0x44f0>
    4484:      	b	0x6ca8 <kprobe_unwind_dotnet+0x6ca8>
    4488:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    448c:      	ldr	w25, [x21, #0x116c]
    4490:      	ldr	x8, [x8]
    4494:      	ldr	w8, [x8]
    4498:      	cbnz	w8, 0x49c4 <kprobe_unwind_dotnet+0x49c4>
    449c:      	mov	w8, #0x1c               // =28
    44a0:      	bic	w8, w8, w23, lsr #3
    44a4:      	lsr	w25, w25, w8
    44a8:      	cbz	w25, 0x4a1c <kprobe_unwind_dotnet+0x4a1c>
    44ac:      	and	x29, x23, #0xffffffffffffffe0
    44b0:      	ands	w3, w25, #0xf
    44b4:      	b.ne	0x4c68 <kprobe_unwind_dotnet+0x4c68>
    44b8:      	ubfx	w3, w25, #4, #4
    44bc:      	cbz	w3, 0x455c <kprobe_unwind_dotnet+0x455c>
    44c0:      	sub	x29, x29, #0x20
    44c4:      	b	0x4c68 <kprobe_unwind_dotnet+0x4c68>
    44c8:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    44cc:      	ldr	x8, [x8]
    44d0:      	ldr	w8, [x8]
    44d4:      	cbnz	w8, 0x4a44 <kprobe_unwind_dotnet+0x4a44>
    44d8:      	mov	w22, wzr
    44dc:      	mov	w2, #0x1772             // =6002
    44e0:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    44e4:      	ldr	x8, [x8]
    44e8:      	ldr	w8, [x8]
    44ec:      	cbnz	w8, 0x6ca8 <kprobe_unwind_dotnet+0x6ca8>
    44f0:      	cbz	w22, 0x621c <kprobe_unwind_dotnet+0x621c>
    44f4:      	ldr	w8, [x21, #0x2c0]
    44f8:      	adrp	x23, 0x4000 <kprobe_unwind_dotnet+0x4000>
    44fc:      	adrp	x24, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4500:      	ldr	x23, [x23]
    4504:      	ldr	x24, [x24]
    4508:      	cmp	w8, #0x7e
    450c:      	b.hi	0x49c <kprobe_unwind_dotnet+0x49c>
    4510:      	add	w9, w8, #0x1
    4514:      	mov	w10, #0x8a              // =138
    4518:      	str	w9, [x21, #0x2c0]
    451c:      	mov	w9, #0x18               // =24
    4520:      	umaddl	x8, w8, w9, x21
    4524:      	mov	w9, #0x1773             // =6003
    4528:      	str	x9, [x8, #0x2d8]
    452c:      	add	x9, x8, #0x2d0
    4530:      	str	xzr, [x8, #0x2d0]
    4534:      	strb	w10, [x8, #0x2e0]
    4538:      	str	wzr, [x8, #0x2e4]
    453c:      	stur	wzr, [x9, #0x11]
    4540:      	ldr	x8, [sp, #0x10]
    4544:      	ldr	x29, [x8]
    4548:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    454c:      	ldr	x8, [x8]
    4550:      	ldr	w8, [x8]
    4554:      	cbnz	x29, 0x4dd4 <kprobe_unwind_dotnet+0x4dd4>
    4558:      	b	0x4d58 <kprobe_unwind_dotnet+0x4d58>
    455c:      	ubfx	w3, w25, #8, #4
    4560:      	cbz	w3, 0x456c <kprobe_unwind_dotnet+0x456c>
    4564:      	sub	x29, x29, #0x40
    4568:      	b	0x4c68 <kprobe_unwind_dotnet+0x4c68>
    456c:      	ubfx	w3, w25, #12, #4
    4570:      	cbz	w3, 0x4aa4 <kprobe_unwind_dotnet+0x4aa4>
    4574:      	sub	x29, x29, #0x60
    4578:      	b	0x4c68 <kprobe_unwind_dotnet+0x4c68>
    457c:      	mov	w8, #0x786c             // =30828
    4580:      	add	x0, sp, #0x20
    4584:      	mov	w1, #0x23               // =35
    4588:      	mov	x2, x24
    458c:      	mov	x3, x25
    4590:      	mov	x4, x29
    4594:      	movk	w8, #0xa, lsl #16
    4598:      	stur	w8, [sp, #0x3f]
    459c:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    45a0:      	add	x8, x8, #0x0
    45a4:      	ldp	x9, x10, [x8]
    45a8:      	stp	x9, x10, [sp, #0x20]
    45ac:      	ldp	x9, x8, [x8, #0x10]
    45b0:      	add	x10, sp, #0x20
    45b4:      	stp	x9, x8, [sp, #0x30]
    45b8:      	mov	w8, #0x23               // =35
    45bc:      	mov	w9, #0x6                // =6
    45c0:      	blr	x9
    45c4:      	cmp	x29, x25
    45c8:      	b.hs	0x4318 <kprobe_unwind_dotnet+0x4318>
    45cc:      	adrp	x23, 0x4000 <kprobe_unwind_dotnet+0x4000>
    45d0:      	ldr	x23, [x23]
    45d4:      	adrp	x24, 0x4000 <kprobe_unwind_dotnet+0x4000>
    45d8:      	ldr	w8, [x23]
    45dc:      	ldr	x24, [x24]
    45e0:      	cbnz	w8, 0x4758 <kprobe_unwind_dotnet+0x4758>
    45e4:      	mov	w8, #0x5d               // =93
    45e8:      	add	x9, sp, #0x68
    45ec:      	add	x1, sp, #0x68
    45f0:      	str	w8, [sp, #0x68]
    45f4:      	mov	w8, #0x1                // =1
    45f8:      	mov	x0, x24
    45fc:      	blr	x8
    4600:      	cbz	x0, 0x4614 <kprobe_unwind_dotnet+0x4614>
    4604:      	ldr	x8, [x0]
    4608:      	add	x8, x8, #0x1
    460c:      	str	x8, [x0]
    4610:      	b	0x461c <kprobe_unwind_dotnet+0x461c>
    4614:      	ldr	w8, [x23]
    4618:      	cbnz	w8, 0x47a4 <kprobe_unwind_dotnet+0x47a4>
    461c:      	mov	w25, wzr
    4620:      	mov	w8, #0x1771             // =6001
    4624:      	str	w8, [x21, #0xf1c]
    4628:      	str	wzr, [sp, #0x20]
    462c:      	mov	w8, #0x1                // =1
    4630:      	add	x9, sp, #0x20
    4634:      	add	x1, sp, #0x20
    4638:      	mov	x0, x20
    463c:      	blr	x8
    4640:      	cbz	x0, 0x4694 <kprobe_unwind_dotnet+0x4694>
    4644:      	mov	w20, #0x1374            // =4980
    4648:      	mov	w2, w25
    464c:      	ldrb	w8, [x0, x20]
    4650:      	cmp	w8, #0x1d
    4654:      	b.lo	0x46c0 <kprobe_unwind_dotnet+0x46c0>
    4658:      	mov	w8, #0x5                // =5
    465c:      	add	x9, sp, #0x70
    4660:      	mov	x21, x0
    4664:      	str	w8, [x0, #0xf1c]
    4668:      	mov	w8, #0x44               // =68
    466c:      	add	x1, sp, #0x70
    4670:      	mov	x0, x24
    4674:      	str	w8, [sp, #0x70]
    4678:      	mov	w8, #0x1                // =1
    467c:      	blr	x8
    4680:      	cbz	x0, 0x46ac <kprobe_unwind_dotnet+0x46ac>
    4684:      	ldr	x8, [x0]
    4688:      	add	x8, x8, #0x1
    468c:      	str	x8, [x0]
    4690:      	b	0x46b4 <kprobe_unwind_dotnet+0x46b4>
    4694:      	adrp	x10, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4698:      	mov	x9, xzr
    469c:      	mov	w8, #0xc                // =12
    46a0:      	ldr	x10, [x10]
    46a4:      	mov	w2, wzr
    46a8:      	b	0x46d8 <kprobe_unwind_dotnet+0x46d8>
    46ac:      	ldr	w8, [x23]
    46b0:      	cbnz	w8, 0x47ec <kprobe_unwind_dotnet+0x47ec>
    46b4:      	ldrb	w8, [x21, x20]
    46b8:      	mov	w2, wzr
    46bc:      	mov	x0, x21
    46c0:      	add	w8, w8, #0x1
    46c4:      	adrp	x10, 0x4000 <kprobe_unwind_dotnet+0x4000>
    46c8:      	mov	w9, w2
    46cc:      	strb	w8, [x0, x20]
    46d0:      	mov	w8, #0xc                // =12
    46d4:      	ldr	x10, [x10]
    46d8:      	adrp	x1, 0x4000 <kprobe_unwind_dotnet+0x4000>
    46dc:      	mov	x0, x19
    46e0:      	ldr	x1, [x1]
    46e4:      	blr	x8
    46e8:      	ldr	w8, [x23]
    46ec:      	cbnz	w8, 0x4710 <kprobe_unwind_dotnet+0x4710>
    46f0:      	ldp	x20, x19, [sp, #0xc0]
    46f4:      	mov	w0, #-0x1               // =-1
    46f8:      	ldr	x29, [sp, #0x80]
    46fc:      	ldp	x22, x21, [sp, #0xb0]
    4700:      	ldp	x24, x23, [sp, #0xa0]
    4704:      	ldp	x30, x25, [sp, #0x90]
    4708:      	add	sp, sp, #0xd0
    470c:      	ret
    4710:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4714:      	add	x8, x8, #0x0
    4718:      	add	x0, sp, #0x20
    471c:      	ldp	x9, x10, [x8, #0x20]
    4720:      	mov	w1, #0x37               // =55
    4724:      	mov	w2, w25
    4728:      	stp	x9, x10, [sp, #0x40]
    472c:      	ldur	x9, [x8, #0x2f]
    4730:      	stur	x9, [sp, #0x4f]
    4734:      	ldp	x9, x10, [x8]
    4738:      	stp	x9, x10, [sp, #0x20]
    473c:      	ldp	x8, x9, [x8, #0x10]
    4740:      	add	x10, sp, #0x20
    4744:      	stp	x8, x9, [sp, #0x30]
    4748:      	mov	w8, #0x37               // =55
    474c:      	mov	w9, #0x6                // =6
    4750:      	blr	x9
    4754:      	b	0x46f0 <kprobe_unwind_dotnet+0x46f0>
    4758:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    475c:      	add	x8, x8, #0x0
    4760:      	add	x0, sp, #0x20
    4764:      	ldp	x9, x10, [x8, #0x10]
    4768:      	mov	w1, #0x2d               // =45
    476c:      	mov	x2, x29
    4770:      	mov	x3, x25
    4774:      	stp	x9, x10, [sp, #0x30]
    4778:      	ldr	x9, [x8, #0x20]
    477c:      	add	x10, sp, #0x20
    4780:      	str	x9, [sp, #0x40]
    4784:      	ldur	x9, [x8, #0x25]
    4788:      	stur	x9, [sp, #0x45]
    478c:      	ldp	x9, x8, [x8]
    4790:      	stp	x9, x8, [sp, #0x20]
    4794:      	mov	w8, #0x2d               // =45
    4798:      	mov	w9, #0x6                // =6
    479c:      	blr	x9
    47a0:      	b	0x45e4 <kprobe_unwind_dotnet+0x45e4>
    47a4:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    47a8:      	add	x8, x8, #0x0
    47ac:      	add	x0, sp, #0x20
    47b0:      	ldp	x9, x10, [x8, #0x10]
    47b4:      	mov	w1, #0x2e               // =46
    47b8:      	stp	x9, x10, [sp, #0x30]
    47bc:      	ldr	x9, [x8, #0x20]
    47c0:      	add	x10, sp, #0x20
    47c4:      	str	x9, [sp, #0x40]
    47c8:      	ldur	x9, [x8, #0x26]
    47cc:      	stur	x9, [sp, #0x46]
    47d0:      	ldp	x9, x8, [x8]
    47d4:      	stp	x9, x8, [sp, #0x20]
    47d8:      	mov	w8, #0x2e               // =46
    47dc:      	mov	w9, #0x6                // =6
    47e0:      	ldr	w2, [sp, #0x68]
    47e4:      	blr	x9
    47e8:      	b	0x461c <kprobe_unwind_dotnet+0x461c>
    47ec:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    47f0:      	add	x8, x8, #0x0
    47f4:      	add	x0, sp, #0x20
    47f8:      	ldp	x9, x10, [x8, #0x10]
    47fc:      	mov	w1, #0x2e               // =46
    4800:      	stp	x9, x10, [sp, #0x30]
    4804:      	ldr	x9, [x8, #0x20]
    4808:      	add	x10, sp, #0x20
    480c:      	str	x9, [sp, #0x40]
    4810:      	ldur	x9, [x8, #0x26]
    4814:      	stur	x9, [sp, #0x46]
    4818:      	ldp	x9, x8, [x8]
    481c:      	stp	x9, x8, [sp, #0x20]
    4820:      	mov	w8, #0x2e               // =46
    4824:      	mov	w9, #0x6                // =6
    4828:      	ldr	w2, [sp, #0x70]
    482c:      	blr	x9
    4830:      	b	0x46b4 <kprobe_unwind_dotnet+0x46b4>
    4834:      	mov	w8, #0x656e             // =25966
    4838:      	add	x0, sp, #0x20
    483c:      	mov	w1, #0x1b               // =27
    4840:      	movk	w8, #0xa, lsl #16
    4844:      	stur	w8, [sp, #0x37]
    4848:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    484c:      	add	x8, x8, #0x0
    4850:      	ldp	x9, x10, [x8]
    4854:      	ldr	x8, [x8, #0x10]
    4858:      	stp	x9, x10, [sp, #0x20]
    485c:      	str	x8, [sp, #0x30]
    4860:      	mov	w8, #0x1b               // =27
    4864:      	mov	w9, #0x6                // =6
    4868:      	add	x10, sp, #0x20
    486c:      	blr	x9
    4870:      	mov	w25, #0x1               // =1
    4874:      	cmp	w25, #0x8
    4878:      	b.eq	0x42f0 <kprobe_unwind_dotnet+0x42f0>
    487c:      	b	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    4880:      	ldr	x8, [x21, #0x1098]
    4884:      	cbz	x8, 0x4ab4 <kprobe_unwind_dotnet+0x4ab4>
    4888:      	mov	w9, #-0x4a              // =-74
    488c:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    4890:      	ldr	x8, [x21, #0x1120]
    4894:      	cbz	x8, 0x4ac4 <kprobe_unwind_dotnet+0x4ac4>
    4898:      	mov	w9, #-0x6c              // =-108
    489c:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    48a0:      	ldr	x8, [x21, #0x10f0]
    48a4:      	cbz	x8, 0x4ad4 <kprobe_unwind_dotnet+0x4ad4>
    48a8:      	mov	w9, #-0x60              // =-96
    48ac:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    48b0:      	ldr	x8, [x21, #0x1068]
    48b4:      	cbz	x8, 0x4ae4 <kprobe_unwind_dotnet+0x4ae4>
    48b8:      	mov	w9, #-0x3e              // =-62
    48bc:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    48c0:      	ldr	x8, [x21, #0x10c0]
    48c4:      	cbz	x8, 0x4af4 <kprobe_unwind_dotnet+0x4af4>
    48c8:      	mov	w9, #-0x54              // =-84
    48cc:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    48d0:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    48d4:      	add	x8, x8, #0x0
    48d8:      	add	x0, sp, #0x20
    48dc:      	ldp	x9, x10, [x8, #0x10]
    48e0:      	mov	w1, #0x2e               // =46
    48e4:      	stp	x9, x10, [sp, #0x30]
    48e8:      	ldr	x9, [x8, #0x20]
    48ec:      	add	x10, sp, #0x20
    48f0:      	str	x9, [sp, #0x40]
    48f4:      	ldur	x9, [x8, #0x26]
    48f8:      	stur	x9, [sp, #0x46]
    48fc:      	ldp	x9, x8, [x8]
    4900:      	stp	x9, x8, [sp, #0x20]
    4904:      	mov	w8, #0x2e               // =46
    4908:      	mov	w9, #0x6                // =6
    490c:      	ldr	w2, [sp, #0x68]
    4910:      	blr	x9
    4914:      	b	0x42e4 <kprobe_unwind_dotnet+0x42e4>
    4918:      	mov	w8, #0x786c             // =30828
    491c:      	add	x0, sp, #0x20
    4920:      	mov	w1, #0x23               // =35
    4924:      	movk	w8, #0xa, lsl #16
    4928:      	stur	w8, [sp, #0x3f]
    492c:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4930:      	add	x8, x8, #0x0
    4934:      	ldp	x9, x10, [x8]
    4938:      	stp	x9, x10, [sp, #0x20]
    493c:      	ldp	x9, x8, [x8, #0x10]
    4940:      	add	x10, sp, #0x20
    4944:      	stp	x9, x8, [sp, #0x30]
    4948:      	mov	w8, #0x23               // =35
    494c:      	mov	w9, #0x6                // =6
    4950:      	ldr	x2, [x21, #0xed0]
    4954:      	ldr	x3, [x21, #0xed8]
    4958:      	ldr	x4, [x21, #0xee0]
    495c:      	blr	x9
    4960:      	cmp	x23, #0x100
    4964:      	b.hs	0x43c4 <kprobe_unwind_dotnet+0x43c4>
    4968:      	b	0x4cb8 <kprobe_unwind_dotnet+0x4cb8>
    496c:      	mov	w8, #0xa                // =10
    4970:      	mov	w11, #0x6               // =6
    4974:      	add	x0, sp, #0x20
    4978:      	strh	w8, [sp, #0x60]
    497c:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4980:      	add	x8, x8, #0x0
    4984:      	mov	w1, #0x42               // =66
    4988:      	ldp	x9, x10, [x8, #0x20]
    498c:      	mov	x2, x23
    4990:      	mov	x4, x25
    4994:      	stp	x9, x10, [sp, #0x40]
    4998:      	ldp	x9, x10, [x8, #0x30]
    499c:      	stp	x9, x10, [sp, #0x50]
    49a0:      	ldp	x9, x10, [x8]
    49a4:      	stp	x9, x10, [sp, #0x20]
    49a8:      	ldp	x9, x8, [x8, #0x10]
    49ac:      	mov	w10, #0x42              // =66
    49b0:      	stp	x9, x8, [sp, #0x30]
    49b4:      	add	x8, sp, #0x20
    49b8:      	ldr	x3, [sp, #0x8]
    49bc:      	blr	x11
    49c0:      	b	0x43e4 <kprobe_unwind_dotnet+0x43e4>
    49c4:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    49c8:      	add	x8, x8, #0x0
    49cc:      	add	x0, sp, #0x20
    49d0:      	ldp	x9, x10, [x8, #0x20]
    49d4:      	and	x2, x23, #0xfffffffffffffffc
    49d8:      	mov	w1, #0x36               // =54
    49dc:      	mov	w3, w25
    49e0:      	stp	x9, x10, [sp, #0x40]
    49e4:      	ldur	x9, [x8, #0x2e]
    49e8:      	stur	x9, [sp, #0x4e]
    49ec:      	ldp	x9, x10, [x8]
    49f0:      	stp	x9, x10, [sp, #0x20]
    49f4:      	ldp	x8, x9, [x8, #0x10]
    49f8:      	add	x10, sp, #0x20
    49fc:      	stp	x8, x9, [sp, #0x30]
    4a00:      	mov	w8, #0x36               // =54
    4a04:      	mov	w9, #0x6                // =6
    4a08:      	blr	x9
    4a0c:      	mov	w8, #0x1c               // =28
    4a10:      	bic	w8, w8, w23, lsr #3
    4a14:      	lsr	w25, w25, w8
    4a18:      	cbnz	w25, 0x44ac <kprobe_unwind_dotnet+0x44ac>
    4a1c:      	and	x8, x23, #0xffffffffffffff00
    4a20:      	ldr	w25, [x21, #0x1168]
    4a24:      	sub	x23, x8, #0x20
    4a28:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4a2c:      	ldr	x8, [x8]
    4a30:      	ldr	w8, [x8]
    4a34:      	cbnz	w8, 0x4b04 <kprobe_unwind_dotnet+0x4b04>
    4a38:      	cbz	w25, 0x4b50 <kprobe_unwind_dotnet+0x4b50>
    4a3c:      	mov	w3, wzr
    4a40:      	b	0x6b50 <kprobe_unwind_dotnet+0x6b50>
    4a44:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4a48:      	add	x8, x8, #0x0
    4a4c:      	add	x0, sp, #0x20
    4a50:      	ldp	x9, x10, [x8, #0x10]
    4a54:      	mov	w1, #0x2e               // =46
    4a58:      	stp	x9, x10, [sp, #0x30]
    4a5c:      	ldr	x9, [x8, #0x20]
    4a60:      	add	x10, sp, #0x20
    4a64:      	str	x9, [sp, #0x40]
    4a68:      	ldur	x9, [x8, #0x26]
    4a6c:      	stur	x9, [sp, #0x46]
    4a70:      	ldp	x9, x8, [x8]
    4a74:      	stp	x9, x8, [sp, #0x20]
    4a78:      	mov	w8, #0x2e               // =46
    4a7c:      	mov	w9, #0x6                // =6
    4a80:      	ldr	w2, [sp, #0x8c]
    4a84:      	blr	x9
    4a88:      	mov	w22, wzr
    4a8c:      	mov	w2, #0x1772             // =6002
    4a90:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4a94:      	ldr	x8, [x8]
    4a98:      	ldr	w8, [x8]
    4a9c:      	cbz	w8, 0x44f0 <kprobe_unwind_dotnet+0x44f0>
    4aa0:      	b	0x6ca8 <kprobe_unwind_dotnet+0x6ca8>
    4aa4:      	ubfx	w3, w25, #16, #4
    4aa8:      	cbz	w3, 0x4b80 <kprobe_unwind_dotnet+0x4b80>
    4aac:      	sub	x29, x29, #0x80
    4ab0:      	b	0x4c68 <kprobe_unwind_dotnet+0x4c68>
    4ab4:      	ldr	x8, [x21, #0x1090]
    4ab8:      	cbz	x8, 0x4b90 <kprobe_unwind_dotnet+0x4b90>
    4abc:      	mov	w9, #-0x48              // =-72
    4ac0:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    4ac4:      	ldr	x8, [x21, #0x1118]
    4ac8:      	cbz	x8, 0x4ba0 <kprobe_unwind_dotnet+0x4ba0>
    4acc:      	mov	w9, #-0x6a              // =-106
    4ad0:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    4ad4:      	ldr	x8, [x21, #0x10e8]
    4ad8:      	cbz	x8, 0x4bb0 <kprobe_unwind_dotnet+0x4bb0>
    4adc:      	mov	w9, #-0x5e              // =-94
    4ae0:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    4ae4:      	ldr	x8, [x21, #0x1060]
    4ae8:      	cbz	x8, 0x4bc0 <kprobe_unwind_dotnet+0x4bc0>
    4aec:      	mov	w9, #-0x3c              // =-60
    4af0:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    4af4:      	ldr	x8, [x21, #0x10b8]
    4af8:      	cbz	x8, 0x4bd0 <kprobe_unwind_dotnet+0x4bd0>
    4afc:      	mov	w9, #-0x52              // =-82
    4b00:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    4b04:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4b08:      	add	x8, x8, #0x0
    4b0c:      	add	x0, sp, #0x20
    4b10:      	ldp	x9, x10, [x8, #0x20]
    4b14:      	mov	w1, #0x37               // =55
    4b18:      	mov	x2, x23
    4b1c:      	mov	w3, w25
    4b20:      	stp	x9, x10, [sp, #0x40]
    4b24:      	ldur	x9, [x8, #0x2f]
    4b28:      	stur	x9, [sp, #0x4f]
    4b2c:      	ldp	x9, x10, [x8]
    4b30:      	stp	x9, x10, [sp, #0x20]
    4b34:      	ldp	x8, x9, [x8, #0x10]
    4b38:      	add	x10, sp, #0x20
    4b3c:      	stp	x8, x9, [sp, #0x30]
    4b40:      	mov	w8, #0x37               // =55
    4b44:      	mov	w9, #0x6                // =6
    4b48:      	blr	x9
    4b4c:      	cbnz	w25, 0x4a3c <kprobe_unwind_dotnet+0x4a3c>
    4b50:      	ldr	x8, [x21, #0x1160]
    4b54:      	cbz	x8, 0x4b60 <kprobe_unwind_dotnet+0x4b60>
    4b58:      	mov	w9, #-0x7c              // =-124
    4b5c:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    4b60:      	ldr	x8, [x21, #0x1158]
    4b64:      	cbz	x8, 0x4b70 <kprobe_unwind_dotnet+0x4b70>
    4b68:      	mov	w9, #-0x7a              // =-122
    4b6c:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    4b70:      	ldr	x8, [x21, #0x1150]
    4b74:      	cbz	x8, 0x4be0 <kprobe_unwind_dotnet+0x4be0>
    4b78:      	mov	w9, #-0x78              // =-120
    4b7c:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    4b80:      	ubfx	w3, w25, #20, #4
    4b84:      	cbz	w3, 0x4bf0 <kprobe_unwind_dotnet+0x4bf0>
    4b88:      	sub	x29, x29, #0xa0
    4b8c:      	b	0x4c68 <kprobe_unwind_dotnet+0x4c68>
    4b90:      	ldr	x8, [x21, #0x1088]
    4b94:      	cbz	x8, 0x4c00 <kprobe_unwind_dotnet+0x4c00>
    4b98:      	mov	w9, #-0x46              // =-70
    4b9c:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    4ba0:      	ldr	x8, [x21, #0x1110]
    4ba4:      	cbz	x8, 0x4c10 <kprobe_unwind_dotnet+0x4c10>
    4ba8:      	mov	w9, #-0x68              // =-104
    4bac:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    4bb0:      	ldr	x8, [x21, #0x10e0]
    4bb4:      	cbz	x8, 0x4c20 <kprobe_unwind_dotnet+0x4c20>
    4bb8:      	mov	w9, #-0x5c              // =-92
    4bbc:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    4bc0:      	ldr	x8, [x21, #0x1058]
    4bc4:      	cbz	x8, 0x4c30 <kprobe_unwind_dotnet+0x4c30>
    4bc8:      	mov	w9, #-0x3a              // =-58
    4bcc:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    4bd0:      	ldr	x8, [x21, #0x10b0]
    4bd4:      	cbz	x8, 0x4c40 <kprobe_unwind_dotnet+0x4c40>
    4bd8:      	mov	w9, #-0x50              // =-80
    4bdc:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    4be0:      	ldr	x8, [x21, #0x1148]
    4be4:      	cbz	x8, 0x4c50 <kprobe_unwind_dotnet+0x4c50>
    4be8:      	mov	w9, #-0x76              // =-118
    4bec:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    4bf0:      	ubfx	w3, w25, #24, #4
    4bf4:      	cbz	w3, 0x4c60 <kprobe_unwind_dotnet+0x4c60>
    4bf8:      	sub	x29, x29, #0xc0
    4bfc:      	b	0x4c68 <kprobe_unwind_dotnet+0x4c68>
    4c00:      	ldr	x8, [x21, #0x1080]
    4c04:      	cbz	x8, 0x4f7c <kprobe_unwind_dotnet+0x4f7c>
    4c08:      	mov	w9, #-0x44              // =-68
    4c0c:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    4c10:      	ldr	x8, [x21, #0x1108]
    4c14:      	cbz	x8, 0x4f8c <kprobe_unwind_dotnet+0x4f8c>
    4c18:      	mov	w9, #-0x66              // =-102
    4c1c:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    4c20:      	ldr	x8, [x21, #0x10d8]
    4c24:      	cbz	x8, 0x4f9c <kprobe_unwind_dotnet+0x4f9c>
    4c28:      	mov	w9, #-0x5a              // =-90
    4c2c:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    4c30:      	ldr	x8, [x21, #0x1050]
    4c34:      	cbz	x8, 0x4fac <kprobe_unwind_dotnet+0x4fac>
    4c38:      	mov	w9, #-0x38              // =-56
    4c3c:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    4c40:      	ldr	x8, [x21, #0x10a8]
    4c44:      	cbz	x8, 0x4fbc <kprobe_unwind_dotnet+0x4fbc>
    4c48:      	mov	w9, #-0x4e              // =-78
    4c4c:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    4c50:      	ldr	x8, [x21, #0x1140]
    4c54:      	cbz	x8, 0x4fcc <kprobe_unwind_dotnet+0x4fcc>
    4c58:      	mov	w9, #-0x74              // =-116
    4c5c:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    4c60:      	lsr	w3, w25, #28
    4c64:      	sub	x29, x29, #0xe0
    4c68:      	ldr	x8, [sp, #0x8]
    4c6c:      	lsl	w9, w3, #2
    4c70:      	sub	w9, w9, #0x4
    4c74:      	add	x8, x29, x8
    4c78:      	add	x25, x8, x9
    4c7c:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4c80:      	ldr	x8, [x8]
    4c84:      	ldr	w8, [x8]
    4c88:      	cbnz	w8, 0x4fdc <kprobe_unwind_dotnet+0x4fdc>
    4c8c:      	sub	x2, x25, #0x8
    4c90:      	mov	w8, #0x8                // =8
    4c94:      	mov	w9, #0x70               // =112
    4c98:      	add	x10, sp, #0x68
    4c9c:      	add	x0, sp, #0x68
    4ca0:      	mov	w1, #0x8                // =8
    4ca4:      	blr	x9
    4ca8:      	adrp	x23, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4cac:      	ldr	x23, [x23]
    4cb0:      	cbnz	x0, 0x844 <kprobe_unwind_dotnet+0x844>
    4cb4:      	mov	w23, #0x1f              // =31
    4cb8:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4cbc:      	ldr	x8, [x8]
    4cc0:      	ldr	w8, [x8]
    4cc4:      	cbnz	w8, 0x5028 <kprobe_unwind_dotnet+0x5028>
    4cc8:      	ldr	w8, [x21, #0x2c0]
    4ccc:      	cmp	w8, #0x7e
    4cd0:      	b.hi	0x8a4 <kprobe_unwind_dotnet+0x8a4>
    4cd4:      	ldr	x9, [sp, #0x68]
    4cd8:      	add	w11, w8, #0x1
    4cdc:      	sub	x10, x24, x25
    4ce0:      	adrp	x0, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4ce4:      	str	w11, [x21, #0x2c0]
    4ce8:      	mov	w11, #0x18              // =24
    4cec:      	add	x1, sp, #0x8c
    4cf0:      	umaddl	x8, w8, w11, x21
    4cf4:      	add	x9, x23, x9, lsl #5
    4cf8:      	str	x10, [x8, #0x2d8]
    4cfc:      	mov	w10, #0xa               // =10
    4d00:      	strb	w22, [x8, #0x2e1]
    4d04:      	strh	wzr, [x8, #0x2e6]
    4d08:      	strb	w10, [x8, #0x2e0]
    4d0c:      	str	x9, [x8, #0x2d0]
    4d10:      	add	x9, x8, #0x2d0
    4d14:      	mov	w8, #0x5b               // =91
    4d18:      	stur	wzr, [x9, #0x12]
    4d1c:      	str	w8, [sp, #0x8c]
    4d20:      	mov	w8, #0x1                // =1
    4d24:      	add	x9, sp, #0x8c
    4d28:      	ldr	x0, [x0]
    4d2c:      	blr	x8
    4d30:      	cbz	x0, 0x4dac <kprobe_unwind_dotnet+0x4dac>
    4d34:      	ldr	x8, [x0]
    4d38:      	add	x8, x8, #0x1
    4d3c:      	str	x8, [x0]
    4d40:      	ldr	x8, [sp, #0x10]
    4d44:      	ldr	x29, [x8]
    4d48:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4d4c:      	ldr	x8, [x8]
    4d50:      	ldr	w8, [x8]
    4d54:      	cbnz	x29, 0x4dd4 <kprobe_unwind_dotnet+0x4dd4>
    4d58:      	adrp	x23, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4d5c:      	adrp	x24, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4d60:      	ldr	x23, [x23]
    4d64:      	ldr	x24, [x24]
    4d68:      	cbz	w8, 0x16b4 <kprobe_unwind_dotnet+0x16b4>
    4d6c:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4d70:      	add	x8, x8, #0x0
    4d74:      	strb	wzr, [sp, #0x50]
    4d78:      	add	x0, sp, #0x20
    4d7c:      	ldp	x9, x10, [x8, #0x10]
    4d80:      	mov	w1, #0x31               // =49
    4d84:      	stp	x9, x10, [sp, #0x30]
    4d88:      	ldp	x9, x10, [x8, #0x20]
    4d8c:      	stp	x9, x10, [sp, #0x40]
    4d90:      	ldp	x9, x8, [x8]
    4d94:      	add	x10, sp, #0x20
    4d98:      	stp	x9, x8, [sp, #0x20]
    4d9c:      	mov	w8, #0x31               // =49
    4da0:      	mov	w9, #0x6                // =6
    4da4:      	blr	x9
    4da8:      	b	0x16b4 <kprobe_unwind_dotnet+0x16b4>
    4dac:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4db0:      	ldr	x8, [x8]
    4db4:      	ldr	w8, [x8]
    4db8:      	cbnz	w8, 0x5090 <kprobe_unwind_dotnet+0x5090>
    4dbc:      	ldr	x8, [sp, #0x10]
    4dc0:      	ldr	x29, [x8]
    4dc4:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4dc8:      	ldr	x8, [x8]
    4dcc:      	ldr	w8, [x8]
    4dd0:      	cbz	x29, 0x4d58 <kprobe_unwind_dotnet+0x4d58>
    4dd4:      	cbnz	w8, 0x50f0 <kprobe_unwind_dotnet+0x50f0>
    4dd8:      	lsr	x8, x29, #56
    4ddc:      	cbnz	x8, 0x1650 <kprobe_unwind_dotnet+0x1650>
    4de0:      	cmp	x29, #0x1, lsl #12      // =0x1000
    4de4:      	b.lo	0x1784 <kprobe_unwind_dotnet+0x1784>
    4de8:      	ldr	w8, [x21]
    4dec:      	mov	w9, #0x60               // =96
    4df0:      	adrp	x0, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4df4:      	add	x1, sp, #0x70
    4df8:      	rev	w8, w8
    4dfc:      	stp	w9, w8, [sp, #0x70]
    4e00:      	rev	x8, x29
    4e04:      	add	x9, sp, #0x70
    4e08:      	str	x8, [sp, #0x78]
    4e0c:      	mov	w8, #0x1                // =1
    4e10:      	ldr	x0, [x0]
    4e14:      	blr	x8
    4e18:      	cbz	x0, 0x4eec <kprobe_unwind_dotnet+0x4eec>
    4e1c:      	ldr	x8, [x0, #0x8]
    4e20:      	and	x9, x8, #0xffffffffffffff
    4e24:      	lsr	x25, x8, #56
    4e28:      	str	x9, [x21, #0xf10]
    4e2c:      	ldr	x8, [x0]
    4e30:      	str	x8, [x21, #0xf00]
    4e34:      	sub	x8, x29, x9
    4e38:      	str	x8, [x21, #0xf08]
    4e3c:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4e40:      	ldr	x8, [x8]
    4e44:      	ldr	w8, [x8]
    4e48:      	cbnz	w8, 0x5140 <kprobe_unwind_dotnet+0x5140>
    4e4c:      	cmp	w25, #0x1
    4e50:      	b.ne	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    4e54:      	ldr	x8, [x21, #0xf00]
    4e58:      	adrp	x0, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4e5c:      	ldr	x22, [x21, #0xf08]
    4e60:      	mov	w9, #0x1                // =1
    4e64:      	add	x1, sp, #0x70
    4e68:      	mov	w25, #0x1               // =1
    4e6c:      	str	x8, [sp, #0x70]
    4e70:      	add	x8, sp, #0x70
    4e74:      	ldr	x0, [x0]
    4e78:      	blr	x9
    4e7c:      	cbz	x0, 0x4f64 <kprobe_unwind_dotnet+0x4f64>
    4e80:      	ldr	x8, [x0]
    4e84:      	mov	x23, x0
    4e88:      	cmp	x8, x22
    4e8c:      	b.hi	0x4e9c <kprobe_unwind_dotnet+0x4e9c>
    4e90:      	ldr	x8, [x23, #0x8]
    4e94:      	cmp	x8, x22
    4e98:      	b.hs	0x4eb4 <kprobe_unwind_dotnet+0x4eb4>
    4e9c:      	ldr	x8, [x23, #0x10]
    4ea0:      	cmp	x8, x22
    4ea4:      	b.hi	0x4ee4 <kprobe_unwind_dotnet+0x4ee4>
    4ea8:      	ldr	x8, [x23, #0x18]
    4eac:      	cmp	x8, x22
    4eb0:      	b.lo	0x4ee4 <kprobe_unwind_dotnet+0x4ee4>
    4eb4:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4eb8:      	ldr	x8, [x8]
    4ebc:      	ldr	w8, [x8]
    4ec0:      	cbnz	w8, 0x51e8 <kprobe_unwind_dotnet+0x51e8>
    4ec4:      	ldrh	w8, [x23, #0x20]
    4ec8:      	ldr	w9, [x21, #0x1370]
    4ecc:      	lsr	w8, w9, w8
    4ed0:      	tbz	w8, #0x0, 0x5234 <kprobe_unwind_dotnet+0x5234>
    4ed4:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4ed8:      	ldr	x8, [x8]
    4edc:      	ldr	w8, [x8]
    4ee0:      	cbnz	w8, 0x5264 <kprobe_unwind_dotnet+0x5264>
    4ee4:      	mov	w25, #0x1               // =1
    4ee8:      	b	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    4eec:      	adrp	x23, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4ef0:      	adrp	x24, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4ef4:      	ldr	x23, [x23]
    4ef8:      	ldr	x24, [x24]
    4efc:      	ldr	w8, [x23]
    4f00:      	cbnz	w8, 0x4f18 <kprobe_unwind_dotnet+0x4f18>
    4f04:      	mov	w8, #0xc                // =12
    4f08:      	mov	w25, wzr
    4f0c:      	str	w8, [x21, #0xf18]
    4f10:      	mov	w8, #0xfac              // =4012
    4f14:      	b	0x4624 <kprobe_unwind_dotnet+0x4624>
    4f18:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4f1c:      	add	x8, x8, #0x0
    4f20:      	strb	wzr, [sp, #0x58]
    4f24:      	add	x0, sp, #0x20
    4f28:      	ldp	x9, x10, [x8, #0x20]
    4f2c:      	mov	w1, #0x39               // =57
    4f30:      	mov	x2, x29
    4f34:      	stp	x9, x10, [sp, #0x40]
    4f38:      	ldr	x9, [x8, #0x30]
    4f3c:      	str	x9, [sp, #0x50]
    4f40:      	ldp	x9, x10, [x8]
    4f44:      	stp	x9, x10, [sp, #0x20]
    4f48:      	ldp	x8, x9, [x8, #0x10]
    4f4c:      	add	x10, sp, #0x20
    4f50:      	stp	x8, x9, [sp, #0x30]
    4f54:      	mov	w8, #0x39               // =57
    4f58:      	mov	w9, #0x6                // =6
    4f5c:      	blr	x9
    4f60:      	b	0x4f04 <kprobe_unwind_dotnet+0x4f04>
    4f64:      	adrp	x23, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4f68:      	adrp	x24, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4f6c:      	mov	w8, wzr
    4f70:      	ldr	x23, [x23]
    4f74:      	ldr	x24, [x24]
    4f78:      	b	0x4624 <kprobe_unwind_dotnet+0x4624>
    4f7c:      	ldr	x8, [x21, #0x1078]
    4f80:      	cbz	x8, 0x52a8 <kprobe_unwind_dotnet+0x52a8>
    4f84:      	mov	w9, #-0x42              // =-66
    4f88:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    4f8c:      	ldr	x8, [x21, #0x1100]
    4f90:      	cbz	x8, 0x52b8 <kprobe_unwind_dotnet+0x52b8>
    4f94:      	mov	w9, #-0x64              // =-100
    4f98:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    4f9c:      	ldr	x8, [x21, #0x10d0]
    4fa0:      	cbz	x8, 0x52c8 <kprobe_unwind_dotnet+0x52c8>
    4fa4:      	mov	w9, #-0x58              // =-88
    4fa8:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    4fac:      	ldr	x8, [x21, #0x1048]
    4fb0:      	cbz	x8, 0x52d8 <kprobe_unwind_dotnet+0x52d8>
    4fb4:      	mov	w9, #-0x36              // =-54
    4fb8:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    4fbc:      	ldr	x8, [x21, #0x10a0]
    4fc0:      	cbz	x8, 0x52e8 <kprobe_unwind_dotnet+0x52e8>
    4fc4:      	mov	w9, #-0x4c              // =-76
    4fc8:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    4fcc:      	ldr	x8, [x21, #0x1138]
    4fd0:      	cbz	x8, 0x52f8 <kprobe_unwind_dotnet+0x52f8>
    4fd4:      	mov	w9, #-0x72              // =-114
    4fd8:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    4fdc:      	adrp	x8, 0x4000 <kprobe_unwind_dotnet+0x4000>
    4fe0:      	add	x8, x8, #0x0
    4fe4:      	add	x0, sp, #0x20
    4fe8:      	ldp	x9, x10, [x8, #0x10]
    4fec:      	mov	w1, #0x2e               // =46
    4ff0:      	mov	x2, x29
    4ff4:      	mov	x4, x25
    4ff8:      	stp	x9, x10, [sp, #0x30]
    4ffc:      	ldr	x9, [x8, #0x20]
    5000:      	add	x10, sp, #0x20
    5004:      	str	x9, [sp, #0x40]
    5008:      	ldur	x9, [x8, #0x26]
    500c:      	stur	x9, [sp, #0x46]
    5010:      	ldp	x9, x8, [x8]
    5014:      	stp	x9, x8, [sp, #0x20]
    5018:      	mov	w8, #0x2e               // =46
    501c:      	mov	w9, #0x6                // =6
    5020:      	blr	x9
    5024:      	b	0x4c8c <kprobe_unwind_dotnet+0x4c8c>
    5028:      	mov	w8, #0x786c             // =30828
    502c:      	sub	x4, x24, x25
    5030:      	add	x0, sp, #0x20
    5034:      	mov	w1, #0x43               // =67
    5038:      	mov	x2, x25
    503c:      	movk	w8, #0xa, lsl #16
    5040:      	stur	w8, [sp, #0x5f]
    5044:      	adrp	x8, 0x5000 <kprobe_unwind_dotnet+0x5000>
    5048:      	add	x8, x8, #0x0
    504c:      	ldp	x9, x10, [x8, #0x20]
    5050:      	stp	x9, x10, [sp, #0x40]
    5054:      	ldp	x9, x10, [x8, #0x30]
    5058:      	stp	x9, x10, [sp, #0x50]
    505c:      	ldp	x9, x10, [x8]
    5060:      	stp	x9, x10, [sp, #0x20]
    5064:      	ldp	x9, x8, [x8, #0x10]
    5068:      	add	x10, sp, #0x20
    506c:      	stp	x9, x8, [sp, #0x30]
    5070:      	mov	w8, #0x43               // =67
    5074:      	mov	w9, #0x6                // =6
    5078:      	ldr	x3, [sp, #0x68]
    507c:      	blr	x9
    5080:      	ldr	w8, [x21, #0x2c0]
    5084:      	cmp	w8, #0x7e
    5088:      	b.hi	0x8a4 <kprobe_unwind_dotnet+0x8a4>
    508c:      	b	0x4cd4 <kprobe_unwind_dotnet+0x4cd4>
    5090:      	adrp	x8, 0x5000 <kprobe_unwind_dotnet+0x5000>
    5094:      	add	x8, x8, #0x0
    5098:      	add	x0, sp, #0x20
    509c:      	ldp	x9, x10, [x8, #0x10]
    50a0:      	mov	w1, #0x2e               // =46
    50a4:      	stp	x9, x10, [sp, #0x30]
    50a8:      	ldr	x9, [x8, #0x20]
    50ac:      	add	x10, sp, #0x20
    50b0:      	str	x9, [sp, #0x40]
    50b4:      	ldur	x9, [x8, #0x26]
    50b8:      	stur	x9, [sp, #0x46]
    50bc:      	ldp	x9, x8, [x8]
    50c0:      	stp	x9, x8, [sp, #0x20]
    50c4:      	mov	w8, #0x2e               // =46
    50c8:      	mov	w9, #0x6                // =6
    50cc:      	ldr	w2, [sp, #0x8c]
    50d0:      	blr	x9
    50d4:      	ldr	x8, [sp, #0x10]
    50d8:      	ldr	x29, [x8]
    50dc:      	adrp	x8, 0x5000 <kprobe_unwind_dotnet+0x5000>
    50e0:      	ldr	x8, [x8]
    50e4:      	ldr	w8, [x8]
    50e8:      	cbnz	x29, 0x4dd4 <kprobe_unwind_dotnet+0x4dd4>
    50ec:      	b	0x4d58 <kprobe_unwind_dotnet+0x4d58>
    50f0:      	adrp	x8, 0x5000 <kprobe_unwind_dotnet+0x5000>
    50f4:      	add	x8, x8, #0x0
    50f8:      	strb	wzr, [sp, #0x50]
    50fc:      	add	x0, sp, #0x20
    5100:      	ldp	x9, x10, [x8, #0x10]
    5104:      	mov	w1, #0x31               // =49
    5108:      	stp	x9, x10, [sp, #0x30]
    510c:      	ldp	x9, x10, [x8, #0x20]
    5110:      	stp	x9, x10, [sp, #0x40]
    5114:      	ldp	x9, x8, [x8]
    5118:      	add	x10, sp, #0x20
    511c:      	stp	x9, x8, [sp, #0x20]
    5120:      	mov	w8, #0x31               // =49
    5124:      	mov	w9, #0x6                // =6
    5128:      	ldr	w2, [x21, #0x2c0]
    512c:      	blr	x9
    5130:      	ldr	x29, [x21, #0xed0]
    5134:      	lsr	x8, x29, #56
    5138:      	cbnz	x8, 0x1650 <kprobe_unwind_dotnet+0x1650>
    513c:      	b	0x4de0 <kprobe_unwind_dotnet+0x4de0>
    5140:      	mov	w8, #0xa                // =10
    5144:      	add	x0, sp, #0x20
    5148:      	mov	w1, #0x32               // =50
    514c:      	strh	w8, [sp, #0x50]
    5150:      	adrp	x8, 0x5000 <kprobe_unwind_dotnet+0x5000>
    5154:      	add	x8, x8, #0x0
    5158:      	mov	x2, x29
    515c:      	ldp	x9, x10, [x8, #0x10]
    5160:      	mov	w4, w25
    5164:      	stp	x9, x10, [sp, #0x30]
    5168:      	ldp	x9, x10, [x8, #0x20]
    516c:      	stp	x9, x10, [sp, #0x40]
    5170:      	ldp	x9, x8, [x8]
    5174:      	add	x10, sp, #0x20
    5178:      	stp	x9, x8, [sp, #0x20]
    517c:      	mov	w8, #0x32               // =50
    5180:      	mov	w9, #0x6                // =6
    5184:      	ldr	x3, [x21, #0xf00]
    5188:      	blr	x9
    518c:      	adrp	x8, 0x5000 <kprobe_unwind_dotnet+0x5000>
    5190:      	ldr	x8, [x8]
    5194:      	ldr	w8, [x8]
    5198:      	cbz	w8, 0x4e4c <kprobe_unwind_dotnet+0x4e4c>
    519c:      	adrp	x8, 0x5000 <kprobe_unwind_dotnet+0x5000>
    51a0:      	add	x8, x8, #0x0
    51a4:      	add	x0, sp, #0x20
    51a8:      	ldp	x9, x10, [x8, #0x10]
    51ac:      	mov	w1, #0x2f               // =47
    51b0:      	stp	x9, x10, [sp, #0x30]
    51b4:      	ldr	x9, [x8, #0x20]
    51b8:      	add	x10, sp, #0x20
    51bc:      	str	x9, [sp, #0x40]
    51c0:      	ldur	x9, [x8, #0x27]
    51c4:      	stur	x9, [sp, #0x47]
    51c8:      	ldp	x9, x8, [x8]
    51cc:      	stp	x9, x8, [sp, #0x20]
    51d0:      	mov	w8, #0x2f               // =47
    51d4:      	mov	w9, #0x6                // =6
    51d8:      	ldr	x2, [x21, #0xf10]
    51dc:      	ldr	x3, [x21, #0xf08]
    51e0:      	blr	x9
    51e4:      	b	0x4e4c <kprobe_unwind_dotnet+0x4e4c>
    51e8:      	adrp	x8, 0x5000 <kprobe_unwind_dotnet+0x5000>
    51ec:      	add	x8, x8, #0x0
    51f0:      	add	x0, sp, #0x20
    51f4:      	ldp	x9, x10, [x8]
    51f8:      	mov	w1, #0x1e               // =30
    51fc:      	stp	x9, x10, [sp, #0x20]
    5200:      	ldr	x9, [x8, #0x10]
    5204:      	ldur	x8, [x8, #0x16]
    5208:      	add	x10, sp, #0x20
    520c:      	str	x9, [sp, #0x30]
    5210:      	stur	x8, [sp, #0x36]
    5214:      	mov	w8, #0x1e               // =30
    5218:      	mov	w9, #0x6                // =6
    521c:      	ldrh	w2, [x23, #0x20]
    5220:      	blr	x9
    5224:      	ldrh	w8, [x23, #0x20]
    5228:      	ldr	w9, [x21, #0x1370]
    522c:      	lsr	w8, w9, w8
    5230:      	tbnz	w8, #0x0, 0x4ed4 <kprobe_unwind_dotnet+0x4ed4>
    5234:      	str	wzr, [sp, #0x68]
    5238:      	adrp	x0, 0x5000 <kprobe_unwind_dotnet+0x5000>
    523c:      	mov	w8, #0x1                // =1
    5240:      	add	x9, sp, #0x68
    5244:      	ldr	x0, [x0]
    5248:      	add	x1, sp, #0x68
    524c:      	blr	x8
    5250:      	cbz	x0, 0x5308 <kprobe_unwind_dotnet+0x5308>
    5254:      	ldr	x8, [x0]
    5258:      	add	x8, x8, #0x1
    525c:      	str	x8, [x0]
    5260:      	b	0x535c <kprobe_unwind_dotnet+0x535c>
    5264:      	mov	w8, #0x656e             // =25966
    5268:      	add	x0, sp, #0x20
    526c:      	mov	w1, #0x1b               // =27
    5270:      	movk	w8, #0xa, lsl #16
    5274:      	stur	w8, [sp, #0x37]
    5278:      	adrp	x8, 0x5000 <kprobe_unwind_dotnet+0x5000>
    527c:      	add	x8, x8, #0x0
    5280:      	ldp	x9, x10, [x8]
    5284:      	ldr	x8, [x8, #0x10]
    5288:      	stp	x9, x10, [sp, #0x20]
    528c:      	str	x8, [sp, #0x30]
    5290:      	mov	w8, #0x1b               // =27
    5294:      	mov	w9, #0x6                // =6
    5298:      	add	x10, sp, #0x20
    529c:      	blr	x9
    52a0:      	mov	w25, #0x1               // =1
    52a4:      	b	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    52a8:      	ldr	x8, [x21, #0x1070]
    52ac:      	cbz	x8, 0x5364 <kprobe_unwind_dotnet+0x5364>
    52b0:      	mov	w9, #-0x40              // =-64
    52b4:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    52b8:      	ldr	x8, [x21, #0x10f8]
    52bc:      	cbz	x8, 0x5374 <kprobe_unwind_dotnet+0x5374>
    52c0:      	mov	w9, #-0x62              // =-98
    52c4:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    52c8:      	ldr	x8, [x21, #0x10c8]
    52cc:      	cbz	x8, 0x5384 <kprobe_unwind_dotnet+0x5384>
    52d0:      	mov	w9, #-0x56              // =-86
    52d4:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    52d8:      	ldr	x8, [x21, #0x1040]
    52dc:      	cbz	x8, 0x5394 <kprobe_unwind_dotnet+0x5394>
    52e0:      	mov	w9, #-0x34              // =-52
    52e4:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    52e8:      	ldr	x8, [x21, #0x1098]
    52ec:      	cbz	x8, 0x53a4 <kprobe_unwind_dotnet+0x53a4>
    52f0:      	mov	w9, #-0x4a              // =-74
    52f4:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    52f8:      	ldr	x8, [x21, #0x1130]
    52fc:      	cbz	x8, 0x53b4 <kprobe_unwind_dotnet+0x53b4>
    5300:      	mov	w9, #-0x70              // =-112
    5304:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5308:      	adrp	x8, 0x5000 <kprobe_unwind_dotnet+0x5000>
    530c:      	ldr	x8, [x8]
    5310:      	ldr	w8, [x8]
    5314:      	cbz	w8, 0x535c <kprobe_unwind_dotnet+0x535c>
    5318:      	adrp	x8, 0x5000 <kprobe_unwind_dotnet+0x5000>
    531c:      	add	x8, x8, #0x0
    5320:      	add	x0, sp, #0x20
    5324:      	ldp	x9, x10, [x8, #0x10]
    5328:      	mov	w1, #0x2e               // =46
    532c:      	stp	x9, x10, [sp, #0x30]
    5330:      	ldr	x9, [x8, #0x20]
    5334:      	add	x10, sp, #0x20
    5338:      	str	x9, [sp, #0x40]
    533c:      	ldur	x9, [x8, #0x26]
    5340:      	stur	x9, [sp, #0x46]
    5344:      	ldp	x9, x8, [x8]
    5348:      	stp	x9, x8, [sp, #0x20]
    534c:      	mov	w8, #0x2e               // =46
    5350:      	mov	w9, #0x6                // =6
    5354:      	ldr	w2, [sp, #0x68]
    5358:      	blr	x9
    535c:      	ldrh	w25, [x23, #0x20]
    5360:      	b	0x4f64 <kprobe_unwind_dotnet+0x4f64>
    5364:      	ldr	x8, [x21, #0x1068]
    5368:      	cbz	x8, 0x53c4 <kprobe_unwind_dotnet+0x53c4>
    536c:      	mov	w9, #-0x3e              // =-62
    5370:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5374:      	ldr	x8, [x21, #0x10f0]
    5378:      	cbz	x8, 0x53d4 <kprobe_unwind_dotnet+0x53d4>
    537c:      	mov	w9, #-0x60              // =-96
    5380:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5384:      	ldr	x8, [x21, #0x10c0]
    5388:      	cbz	x8, 0x53e4 <kprobe_unwind_dotnet+0x53e4>
    538c:      	mov	w9, #-0x54              // =-84
    5390:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5394:      	ldr	x8, [x21, #0x1038]
    5398:      	cbz	x8, 0x53f4 <kprobe_unwind_dotnet+0x53f4>
    539c:      	mov	w9, #-0x32              // =-50
    53a0:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    53a4:      	ldr	x8, [x21, #0x1090]
    53a8:      	cbz	x8, 0x5404 <kprobe_unwind_dotnet+0x5404>
    53ac:      	mov	w9, #-0x48              // =-72
    53b0:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    53b4:      	ldr	x8, [x21, #0x1128]
    53b8:      	cbz	x8, 0x5414 <kprobe_unwind_dotnet+0x5414>
    53bc:      	mov	w9, #-0x6e              // =-110
    53c0:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    53c4:      	ldr	x8, [x21, #0x1060]
    53c8:      	cbz	x8, 0x5424 <kprobe_unwind_dotnet+0x5424>
    53cc:      	mov	w9, #-0x3c              // =-60
    53d0:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    53d4:      	ldr	x8, [x21, #0x10e8]
    53d8:      	cbz	x8, 0x5434 <kprobe_unwind_dotnet+0x5434>
    53dc:      	mov	w9, #-0x5e              // =-94
    53e0:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    53e4:      	ldr	x8, [x21, #0x10b8]
    53e8:      	cbz	x8, 0x5444 <kprobe_unwind_dotnet+0x5444>
    53ec:      	mov	w9, #-0x52              // =-82
    53f0:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    53f4:      	ldr	x8, [x21, #0x1030]
    53f8:      	cbz	x8, 0x5454 <kprobe_unwind_dotnet+0x5454>
    53fc:      	mov	w9, #-0x30              // =-48
    5400:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    5404:      	ldr	x8, [x21, #0x1088]
    5408:      	cbz	x8, 0x5464 <kprobe_unwind_dotnet+0x5464>
    540c:      	mov	w9, #-0x46              // =-70
    5410:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5414:      	ldr	x8, [x21, #0x1120]
    5418:      	cbz	x8, 0x5474 <kprobe_unwind_dotnet+0x5474>
    541c:      	mov	w9, #-0x6c              // =-108
    5420:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5424:      	ldr	x8, [x21, #0x1058]
    5428:      	cbz	x8, 0x5484 <kprobe_unwind_dotnet+0x5484>
    542c:      	mov	w9, #-0x3a              // =-58
    5430:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5434:      	ldr	x8, [x21, #0x10e0]
    5438:      	cbz	x8, 0x5494 <kprobe_unwind_dotnet+0x5494>
    543c:      	mov	w9, #-0x5c              // =-92
    5440:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5444:      	ldr	x8, [x21, #0x10b0]
    5448:      	cbz	x8, 0x54a4 <kprobe_unwind_dotnet+0x54a4>
    544c:      	mov	w9, #-0x50              // =-80
    5450:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5454:      	ldr	x8, [x21, #0x1028]
    5458:      	cbz	x8, 0x54b4 <kprobe_unwind_dotnet+0x54b4>
    545c:      	mov	w9, #-0x2e              // =-46
    5460:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    5464:      	ldr	x8, [x21, #0x1080]
    5468:      	cbz	x8, 0x54c4 <kprobe_unwind_dotnet+0x54c4>
    546c:      	mov	w9, #-0x44              // =-68
    5470:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5474:      	ldr	x8, [x21, #0x1118]
    5478:      	cbz	x8, 0x54d4 <kprobe_unwind_dotnet+0x54d4>
    547c:      	mov	w9, #-0x6a              // =-106
    5480:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5484:      	ldr	x8, [x21, #0x1050]
    5488:      	cbz	x8, 0x54e4 <kprobe_unwind_dotnet+0x54e4>
    548c:      	mov	w9, #-0x38              // =-56
    5490:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5494:      	ldr	x8, [x21, #0x10d8]
    5498:      	cbz	x8, 0x54f4 <kprobe_unwind_dotnet+0x54f4>
    549c:      	mov	w9, #-0x5a              // =-90
    54a0:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    54a4:      	ldr	x8, [x21, #0x10a8]
    54a8:      	cbz	x8, 0x5504 <kprobe_unwind_dotnet+0x5504>
    54ac:      	mov	w9, #-0x4e              // =-78
    54b0:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    54b4:      	ldr	x8, [x21, #0x1020]
    54b8:      	cbz	x8, 0x5514 <kprobe_unwind_dotnet+0x5514>
    54bc:      	mov	w9, #-0x2c              // =-44
    54c0:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    54c4:      	ldr	x8, [x21, #0x1078]
    54c8:      	cbz	x8, 0x5524 <kprobe_unwind_dotnet+0x5524>
    54cc:      	mov	w9, #-0x42              // =-66
    54d0:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    54d4:      	ldr	x8, [x21, #0x1110]
    54d8:      	cbz	x8, 0x5534 <kprobe_unwind_dotnet+0x5534>
    54dc:      	mov	w9, #-0x68              // =-104
    54e0:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    54e4:      	ldr	x8, [x21, #0x1048]
    54e8:      	cbz	x8, 0x5544 <kprobe_unwind_dotnet+0x5544>
    54ec:      	mov	w9, #-0x36              // =-54
    54f0:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    54f4:      	ldr	x8, [x21, #0x10d0]
    54f8:      	cbz	x8, 0x5554 <kprobe_unwind_dotnet+0x5554>
    54fc:      	mov	w9, #-0x58              // =-88
    5500:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5504:      	ldr	x8, [x21, #0x10a0]
    5508:      	cbz	x8, 0x5564 <kprobe_unwind_dotnet+0x5564>
    550c:      	mov	w9, #-0x4c              // =-76
    5510:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5514:      	ldr	x8, [x21, #0x1018]
    5518:      	cbz	x8, 0x5574 <kprobe_unwind_dotnet+0x5574>
    551c:      	mov	w9, #-0x2a              // =-42
    5520:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    5524:      	ldr	x8, [x21, #0x1070]
    5528:      	cbz	x8, 0x5584 <kprobe_unwind_dotnet+0x5584>
    552c:      	mov	w9, #-0x40              // =-64
    5530:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5534:      	ldr	x8, [x21, #0x1108]
    5538:      	cbz	x8, 0x5594 <kprobe_unwind_dotnet+0x5594>
    553c:      	mov	w9, #-0x66              // =-102
    5540:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5544:      	ldr	x8, [x21, #0x1040]
    5548:      	cbz	x8, 0x55a4 <kprobe_unwind_dotnet+0x55a4>
    554c:      	mov	w9, #-0x34              // =-52
    5550:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5554:      	ldr	x8, [x21, #0x10c8]
    5558:      	cbz	x8, 0x55b4 <kprobe_unwind_dotnet+0x55b4>
    555c:      	mov	w9, #-0x56              // =-86
    5560:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5564:      	ldr	x8, [x21, #0x1098]
    5568:      	cbz	x8, 0x55c4 <kprobe_unwind_dotnet+0x55c4>
    556c:      	mov	w9, #-0x4a              // =-74
    5570:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5574:      	ldr	x8, [x21, #0x1010]
    5578:      	cbz	x8, 0x55d4 <kprobe_unwind_dotnet+0x55d4>
    557c:      	mov	w9, #-0x28              // =-40
    5580:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    5584:      	ldr	x8, [x21, #0x1068]
    5588:      	cbz	x8, 0x55e4 <kprobe_unwind_dotnet+0x55e4>
    558c:      	mov	w9, #-0x3e              // =-62
    5590:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5594:      	ldr	x8, [x21, #0x1100]
    5598:      	cbz	x8, 0x55f4 <kprobe_unwind_dotnet+0x55f4>
    559c:      	mov	w9, #-0x64              // =-100
    55a0:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    55a4:      	ldr	x8, [x21, #0x1038]
    55a8:      	cbz	x8, 0x5604 <kprobe_unwind_dotnet+0x5604>
    55ac:      	mov	w9, #-0x32              // =-50
    55b0:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    55b4:      	ldr	x8, [x21, #0x10c0]
    55b8:      	cbz	x8, 0x5614 <kprobe_unwind_dotnet+0x5614>
    55bc:      	mov	w9, #-0x54              // =-84
    55c0:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    55c4:      	ldr	x8, [x21, #0x1090]
    55c8:      	cbz	x8, 0x5624 <kprobe_unwind_dotnet+0x5624>
    55cc:      	mov	w9, #-0x48              // =-72
    55d0:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    55d4:      	ldr	x8, [x21, #0x1008]
    55d8:      	cbz	x8, 0x5634 <kprobe_unwind_dotnet+0x5634>
    55dc:      	mov	w9, #-0x26              // =-38
    55e0:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    55e4:      	ldr	x8, [x21, #0x1060]
    55e8:      	cbz	x8, 0x5644 <kprobe_unwind_dotnet+0x5644>
    55ec:      	mov	w9, #-0x3c              // =-60
    55f0:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    55f4:      	ldr	x8, [x21, #0x10f8]
    55f8:      	cbz	x8, 0x5654 <kprobe_unwind_dotnet+0x5654>
    55fc:      	mov	w9, #-0x62              // =-98
    5600:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5604:      	ldr	x8, [x21, #0x1030]
    5608:      	cbz	x8, 0x5664 <kprobe_unwind_dotnet+0x5664>
    560c:      	mov	w9, #-0x30              // =-48
    5610:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5614:      	ldr	x8, [x21, #0x10b8]
    5618:      	cbz	x8, 0x5674 <kprobe_unwind_dotnet+0x5674>
    561c:      	mov	w9, #-0x52              // =-82
    5620:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5624:      	ldr	x8, [x21, #0x1088]
    5628:      	cbz	x8, 0x5684 <kprobe_unwind_dotnet+0x5684>
    562c:      	mov	w9, #-0x46              // =-70
    5630:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5634:      	ldr	x8, [x21, #0x1000]
    5638:      	cbz	x8, 0x5694 <kprobe_unwind_dotnet+0x5694>
    563c:      	mov	w9, #-0x24              // =-36
    5640:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    5644:      	ldr	x8, [x21, #0x1058]
    5648:      	cbz	x8, 0x56a4 <kprobe_unwind_dotnet+0x56a4>
    564c:      	mov	w9, #-0x3a              // =-58
    5650:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5654:      	ldr	x8, [x21, #0x10f0]
    5658:      	cbz	x8, 0x56b4 <kprobe_unwind_dotnet+0x56b4>
    565c:      	mov	w9, #-0x60              // =-96
    5660:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5664:      	ldr	x8, [x21, #0x1028]
    5668:      	cbz	x8, 0x56c4 <kprobe_unwind_dotnet+0x56c4>
    566c:      	mov	w9, #-0x2e              // =-46
    5670:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5674:      	ldr	x8, [x21, #0x10b0]
    5678:      	cbz	x8, 0x56d4 <kprobe_unwind_dotnet+0x56d4>
    567c:      	mov	w9, #-0x50              // =-80
    5680:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5684:      	ldr	x8, [x21, #0x1080]
    5688:      	cbz	x8, 0x56e4 <kprobe_unwind_dotnet+0x56e4>
    568c:      	mov	w9, #-0x44              // =-68
    5690:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5694:      	ldr	x8, [x21, #0xff8]
    5698:      	cbz	x8, 0x56f4 <kprobe_unwind_dotnet+0x56f4>
    569c:      	mov	w9, #-0x22              // =-34
    56a0:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    56a4:      	ldr	x8, [x21, #0x1050]
    56a8:      	cbz	x8, 0x5704 <kprobe_unwind_dotnet+0x5704>
    56ac:      	mov	w9, #-0x38              // =-56
    56b0:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    56b4:      	ldr	x8, [x21, #0x10e8]
    56b8:      	cbz	x8, 0x5714 <kprobe_unwind_dotnet+0x5714>
    56bc:      	mov	w9, #-0x5e              // =-94
    56c0:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    56c4:      	ldr	x8, [x21, #0x1020]
    56c8:      	cbz	x8, 0x5724 <kprobe_unwind_dotnet+0x5724>
    56cc:      	mov	w9, #-0x2c              // =-44
    56d0:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    56d4:      	ldr	x8, [x21, #0x10a8]
    56d8:      	cbz	x8, 0x5734 <kprobe_unwind_dotnet+0x5734>
    56dc:      	mov	w9, #-0x4e              // =-78
    56e0:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    56e4:      	ldr	x8, [x21, #0x1078]
    56e8:      	cbz	x8, 0x5744 <kprobe_unwind_dotnet+0x5744>
    56ec:      	mov	w9, #-0x42              // =-66
    56f0:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    56f4:      	ldr	x8, [x21, #0xff0]
    56f8:      	cbz	x8, 0x5754 <kprobe_unwind_dotnet+0x5754>
    56fc:      	mov	w9, #-0x20              // =-32
    5700:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    5704:      	ldr	x8, [x21, #0x1048]
    5708:      	cbz	x8, 0x5764 <kprobe_unwind_dotnet+0x5764>
    570c:      	mov	w9, #-0x36              // =-54
    5710:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5714:      	ldr	x8, [x21, #0x10e0]
    5718:      	cbz	x8, 0x5774 <kprobe_unwind_dotnet+0x5774>
    571c:      	mov	w9, #-0x5c              // =-92
    5720:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5724:      	ldr	x8, [x21, #0x1018]
    5728:      	cbz	x8, 0x5784 <kprobe_unwind_dotnet+0x5784>
    572c:      	mov	w9, #-0x2a              // =-42
    5730:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5734:      	ldr	x8, [x21, #0x10a0]
    5738:      	cbz	x8, 0x5794 <kprobe_unwind_dotnet+0x5794>
    573c:      	mov	w9, #-0x4c              // =-76
    5740:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5744:      	ldr	x8, [x21, #0x1070]
    5748:      	cbz	x8, 0x57a4 <kprobe_unwind_dotnet+0x57a4>
    574c:      	mov	w9, #-0x40              // =-64
    5750:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5754:      	ldr	x8, [x21, #0xfe8]
    5758:      	cbz	x8, 0x57b4 <kprobe_unwind_dotnet+0x57b4>
    575c:      	mov	w9, #-0x1e              // =-30
    5760:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    5764:      	ldr	x8, [x21, #0x1040]
    5768:      	cbz	x8, 0x57c4 <kprobe_unwind_dotnet+0x57c4>
    576c:      	mov	w9, #-0x34              // =-52
    5770:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5774:      	ldr	x8, [x21, #0x10d8]
    5778:      	cbz	x8, 0x57d4 <kprobe_unwind_dotnet+0x57d4>
    577c:      	mov	w9, #-0x5a              // =-90
    5780:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5784:      	ldr	x8, [x21, #0x1010]
    5788:      	cbz	x8, 0x57e4 <kprobe_unwind_dotnet+0x57e4>
    578c:      	mov	w9, #-0x28              // =-40
    5790:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5794:      	ldr	x8, [x21, #0x1098]
    5798:      	cbz	x8, 0x57f4 <kprobe_unwind_dotnet+0x57f4>
    579c:      	mov	w9, #-0x4a              // =-74
    57a0:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    57a4:      	ldr	x8, [x21, #0x1068]
    57a8:      	cbz	x8, 0x5804 <kprobe_unwind_dotnet+0x5804>
    57ac:      	mov	w9, #-0x3e              // =-62
    57b0:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    57b4:      	ldr	x8, [x21, #0xfe0]
    57b8:      	cbz	x8, 0x5814 <kprobe_unwind_dotnet+0x5814>
    57bc:      	mov	w9, #-0x1c              // =-28
    57c0:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    57c4:      	ldr	x8, [x21, #0x1038]
    57c8:      	cbz	x8, 0x5824 <kprobe_unwind_dotnet+0x5824>
    57cc:      	mov	w9, #-0x32              // =-50
    57d0:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    57d4:      	ldr	x8, [x21, #0x10d0]
    57d8:      	cbz	x8, 0x5834 <kprobe_unwind_dotnet+0x5834>
    57dc:      	mov	w9, #-0x58              // =-88
    57e0:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    57e4:      	ldr	x8, [x21, #0x1008]
    57e8:      	cbz	x8, 0x5844 <kprobe_unwind_dotnet+0x5844>
    57ec:      	mov	w9, #-0x26              // =-38
    57f0:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    57f4:      	ldr	x8, [x21, #0x1090]
    57f8:      	cbz	x8, 0x5854 <kprobe_unwind_dotnet+0x5854>
    57fc:      	mov	w9, #-0x48              // =-72
    5800:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5804:      	ldr	x8, [x21, #0x1060]
    5808:      	cbz	x8, 0x5864 <kprobe_unwind_dotnet+0x5864>
    580c:      	mov	w9, #-0x3c              // =-60
    5810:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5814:      	ldr	x8, [x21, #0xfd8]
    5818:      	cbz	x8, 0x5874 <kprobe_unwind_dotnet+0x5874>
    581c:      	mov	w9, #-0x1a              // =-26
    5820:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    5824:      	ldr	x8, [x21, #0x1030]
    5828:      	cbz	x8, 0x5884 <kprobe_unwind_dotnet+0x5884>
    582c:      	mov	w9, #-0x30              // =-48
    5830:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5834:      	ldr	x8, [x21, #0x10c8]
    5838:      	cbz	x8, 0x5894 <kprobe_unwind_dotnet+0x5894>
    583c:      	mov	w9, #-0x56              // =-86
    5840:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5844:      	ldr	x8, [x21, #0x1000]
    5848:      	cbz	x8, 0x58a4 <kprobe_unwind_dotnet+0x58a4>
    584c:      	mov	w9, #-0x24              // =-36
    5850:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5854:      	ldr	x8, [x21, #0x1088]
    5858:      	cbz	x8, 0x58b4 <kprobe_unwind_dotnet+0x58b4>
    585c:      	mov	w9, #-0x46              // =-70
    5860:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5864:      	ldr	x8, [x21, #0x1058]
    5868:      	cbz	x8, 0x58c4 <kprobe_unwind_dotnet+0x58c4>
    586c:      	mov	w9, #-0x3a              // =-58
    5870:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5874:      	ldr	x8, [x21, #0xfd0]
    5878:      	cbz	x8, 0x58d4 <kprobe_unwind_dotnet+0x58d4>
    587c:      	mov	w9, #-0x18              // =-24
    5880:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    5884:      	ldr	x8, [x21, #0x1028]
    5888:      	cbz	x8, 0x58e4 <kprobe_unwind_dotnet+0x58e4>
    588c:      	mov	w9, #-0x2e              // =-46
    5890:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5894:      	ldr	x8, [x21, #0x10c0]
    5898:      	cbz	x8, 0x58f4 <kprobe_unwind_dotnet+0x58f4>
    589c:      	mov	w9, #-0x54              // =-84
    58a0:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    58a4:      	ldr	x8, [x21, #0xff8]
    58a8:      	cbz	x8, 0x5904 <kprobe_unwind_dotnet+0x5904>
    58ac:      	mov	w9, #-0x22              // =-34
    58b0:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    58b4:      	ldr	x8, [x21, #0x1080]
    58b8:      	cbz	x8, 0x5914 <kprobe_unwind_dotnet+0x5914>
    58bc:      	mov	w9, #-0x44              // =-68
    58c0:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    58c4:      	ldr	x8, [x21, #0x1050]
    58c8:      	cbz	x8, 0x5924 <kprobe_unwind_dotnet+0x5924>
    58cc:      	mov	w9, #-0x38              // =-56
    58d0:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    58d4:      	ldr	x8, [x21, #0xfc8]
    58d8:      	cbz	x8, 0x5934 <kprobe_unwind_dotnet+0x5934>
    58dc:      	mov	w9, #-0x16              // =-22
    58e0:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    58e4:      	ldr	x8, [x21, #0x1020]
    58e8:      	cbz	x8, 0x5944 <kprobe_unwind_dotnet+0x5944>
    58ec:      	mov	w9, #-0x2c              // =-44
    58f0:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    58f4:      	ldr	x8, [x21, #0x10b8]
    58f8:      	cbz	x8, 0x5954 <kprobe_unwind_dotnet+0x5954>
    58fc:      	mov	w9, #-0x52              // =-82
    5900:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5904:      	ldr	x8, [x21, #0xff0]
    5908:      	cbz	x8, 0x5964 <kprobe_unwind_dotnet+0x5964>
    590c:      	mov	w9, #-0x20              // =-32
    5910:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5914:      	ldr	x8, [x21, #0x1078]
    5918:      	cbz	x8, 0x5974 <kprobe_unwind_dotnet+0x5974>
    591c:      	mov	w9, #-0x42              // =-66
    5920:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5924:      	ldr	x8, [x21, #0x1048]
    5928:      	cbz	x8, 0x5984 <kprobe_unwind_dotnet+0x5984>
    592c:      	mov	w9, #-0x36              // =-54
    5930:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5934:      	ldr	x8, [x21, #0xfc0]
    5938:      	cbz	x8, 0x5994 <kprobe_unwind_dotnet+0x5994>
    593c:      	mov	w9, #-0x14              // =-20
    5940:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    5944:      	ldr	x8, [x21, #0x1018]
    5948:      	cbz	x8, 0x59a4 <kprobe_unwind_dotnet+0x59a4>
    594c:      	mov	w9, #-0x2a              // =-42
    5950:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5954:      	ldr	x8, [x21, #0x10b0]
    5958:      	cbz	x8, 0x59b4 <kprobe_unwind_dotnet+0x59b4>
    595c:      	mov	w9, #-0x50              // =-80
    5960:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5964:      	ldr	x8, [x21, #0xfe8]
    5968:      	cbz	x8, 0x59c4 <kprobe_unwind_dotnet+0x59c4>
    596c:      	mov	w9, #-0x1e              // =-30
    5970:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5974:      	ldr	x8, [x21, #0x1070]
    5978:      	cbz	x8, 0x59d4 <kprobe_unwind_dotnet+0x59d4>
    597c:      	mov	w9, #-0x40              // =-64
    5980:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5984:      	ldr	x8, [x21, #0x1040]
    5988:      	cbz	x8, 0x59e4 <kprobe_unwind_dotnet+0x59e4>
    598c:      	mov	w9, #-0x34              // =-52
    5990:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5994:      	ldr	x8, [x21, #0xfb8]
    5998:      	cbz	x8, 0x59f4 <kprobe_unwind_dotnet+0x59f4>
    599c:      	mov	w9, #-0x12              // =-18
    59a0:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    59a4:      	ldr	x8, [x21, #0x1010]
    59a8:      	cbz	x8, 0x5a04 <kprobe_unwind_dotnet+0x5a04>
    59ac:      	mov	w9, #-0x28              // =-40
    59b0:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    59b4:      	ldr	x8, [x21, #0x10a8]
    59b8:      	cbz	x8, 0x5a14 <kprobe_unwind_dotnet+0x5a14>
    59bc:      	mov	w9, #-0x4e              // =-78
    59c0:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    59c4:      	ldr	x8, [x21, #0xfe0]
    59c8:      	cbz	x8, 0x5a24 <kprobe_unwind_dotnet+0x5a24>
    59cc:      	mov	w9, #-0x1c              // =-28
    59d0:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    59d4:      	ldr	x8, [x21, #0x1068]
    59d8:      	cbz	x8, 0x5a34 <kprobe_unwind_dotnet+0x5a34>
    59dc:      	mov	w9, #-0x3e              // =-62
    59e0:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    59e4:      	ldr	x8, [x21, #0x1038]
    59e8:      	cbz	x8, 0x5a44 <kprobe_unwind_dotnet+0x5a44>
    59ec:      	mov	w9, #-0x32              // =-50
    59f0:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    59f4:      	ldr	x8, [x21, #0xfb0]
    59f8:      	cbz	x8, 0x5a54 <kprobe_unwind_dotnet+0x5a54>
    59fc:      	mov	w9, #-0x10              // =-16
    5a00:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    5a04:      	ldr	x8, [x21, #0x1008]
    5a08:      	cbz	x8, 0x5a64 <kprobe_unwind_dotnet+0x5a64>
    5a0c:      	mov	w9, #-0x26              // =-38
    5a10:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5a14:      	ldr	x8, [x21, #0x10a0]
    5a18:      	cbz	x8, 0x5a74 <kprobe_unwind_dotnet+0x5a74>
    5a1c:      	mov	w9, #-0x4c              // =-76
    5a20:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5a24:      	ldr	x8, [x21, #0xfd8]
    5a28:      	cbz	x8, 0x5a84 <kprobe_unwind_dotnet+0x5a84>
    5a2c:      	mov	w9, #-0x1a              // =-26
    5a30:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5a34:      	ldr	x8, [x21, #0x1060]
    5a38:      	cbz	x8, 0x5a94 <kprobe_unwind_dotnet+0x5a94>
    5a3c:      	mov	w9, #-0x3c              // =-60
    5a40:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5a44:      	ldr	x8, [x21, #0x1030]
    5a48:      	cbz	x8, 0x5aa4 <kprobe_unwind_dotnet+0x5aa4>
    5a4c:      	mov	w9, #-0x30              // =-48
    5a50:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5a54:      	ldr	x8, [x21, #0xfa8]
    5a58:      	cbz	x8, 0x5ab4 <kprobe_unwind_dotnet+0x5ab4>
    5a5c:      	mov	w9, #-0xe               // =-14
    5a60:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    5a64:      	ldr	x8, [x21, #0x1000]
    5a68:      	cbz	x8, 0x5ac4 <kprobe_unwind_dotnet+0x5ac4>
    5a6c:      	mov	w9, #-0x24              // =-36
    5a70:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5a74:      	ldr	x8, [x21, #0x1098]
    5a78:      	cbz	x8, 0x5ad4 <kprobe_unwind_dotnet+0x5ad4>
    5a7c:      	mov	w9, #-0x4a              // =-74
    5a80:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5a84:      	ldr	x8, [x21, #0xfd0]
    5a88:      	cbz	x8, 0x5ae4 <kprobe_unwind_dotnet+0x5ae4>
    5a8c:      	mov	w9, #-0x18              // =-24
    5a90:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5a94:      	ldr	x8, [x21, #0x1058]
    5a98:      	cbz	x8, 0x5af4 <kprobe_unwind_dotnet+0x5af4>
    5a9c:      	mov	w9, #-0x3a              // =-58
    5aa0:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5aa4:      	ldr	x8, [x21, #0x1028]
    5aa8:      	cbz	x8, 0x5b04 <kprobe_unwind_dotnet+0x5b04>
    5aac:      	mov	w9, #-0x2e              // =-46
    5ab0:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5ab4:      	ldr	x8, [x21, #0xfa0]
    5ab8:      	cbz	x8, 0x5b14 <kprobe_unwind_dotnet+0x5b14>
    5abc:      	mov	w9, #-0xc               // =-12
    5ac0:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    5ac4:      	ldr	x8, [x21, #0xff8]
    5ac8:      	cbz	x8, 0x5b24 <kprobe_unwind_dotnet+0x5b24>
    5acc:      	mov	w9, #-0x22              // =-34
    5ad0:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5ad4:      	ldr	x8, [x21, #0x1090]
    5ad8:      	cbz	x8, 0x5b34 <kprobe_unwind_dotnet+0x5b34>
    5adc:      	mov	w9, #-0x48              // =-72
    5ae0:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5ae4:      	ldr	x8, [x21, #0xfc8]
    5ae8:      	cbz	x8, 0x5b44 <kprobe_unwind_dotnet+0x5b44>
    5aec:      	mov	w9, #-0x16              // =-22
    5af0:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5af4:      	ldr	x8, [x21, #0x1050]
    5af8:      	cbz	x8, 0x5b54 <kprobe_unwind_dotnet+0x5b54>
    5afc:      	mov	w9, #-0x38              // =-56
    5b00:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5b04:      	ldr	x8, [x21, #0x1020]
    5b08:      	cbz	x8, 0x5b64 <kprobe_unwind_dotnet+0x5b64>
    5b0c:      	mov	w9, #-0x2c              // =-44
    5b10:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5b14:      	ldr	x8, [x21, #0xf98]
    5b18:      	cbz	x8, 0x5b74 <kprobe_unwind_dotnet+0x5b74>
    5b1c:      	mov	w9, #-0xa               // =-10
    5b20:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    5b24:      	ldr	x8, [x21, #0xff0]
    5b28:      	cbz	x8, 0x5b84 <kprobe_unwind_dotnet+0x5b84>
    5b2c:      	mov	w9, #-0x20              // =-32
    5b30:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5b34:      	ldr	x8, [x21, #0x1088]
    5b38:      	cbz	x8, 0x5b94 <kprobe_unwind_dotnet+0x5b94>
    5b3c:      	mov	w9, #-0x46              // =-70
    5b40:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5b44:      	ldr	x8, [x21, #0xfc0]
    5b48:      	cbz	x8, 0x5ba4 <kprobe_unwind_dotnet+0x5ba4>
    5b4c:      	mov	w9, #-0x14              // =-20
    5b50:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5b54:      	ldr	x8, [x21, #0x1048]
    5b58:      	cbz	x8, 0x5bb4 <kprobe_unwind_dotnet+0x5bb4>
    5b5c:      	mov	w9, #-0x36              // =-54
    5b60:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5b64:      	ldr	x8, [x21, #0x1018]
    5b68:      	cbz	x8, 0x5bc4 <kprobe_unwind_dotnet+0x5bc4>
    5b6c:      	mov	w9, #-0x2a              // =-42
    5b70:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5b74:      	ldr	x8, [x21, #0xf90]
    5b78:      	cbz	x8, 0x5bd4 <kprobe_unwind_dotnet+0x5bd4>
    5b7c:      	mov	w9, #-0x8               // =-8
    5b80:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    5b84:      	ldr	x8, [x21, #0xfe8]
    5b88:      	cbz	x8, 0x5be4 <kprobe_unwind_dotnet+0x5be4>
    5b8c:      	mov	w9, #-0x1e              // =-30
    5b90:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5b94:      	ldr	x8, [x21, #0x1080]
    5b98:      	cbz	x8, 0x5bf4 <kprobe_unwind_dotnet+0x5bf4>
    5b9c:      	mov	w9, #-0x44              // =-68
    5ba0:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5ba4:      	ldr	x8, [x21, #0xfb8]
    5ba8:      	cbz	x8, 0x5c04 <kprobe_unwind_dotnet+0x5c04>
    5bac:      	mov	w9, #-0x12              // =-18
    5bb0:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5bb4:      	ldr	x8, [x21, #0x1040]
    5bb8:      	cbz	x8, 0x5c14 <kprobe_unwind_dotnet+0x5c14>
    5bbc:      	mov	w9, #-0x34              // =-52
    5bc0:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5bc4:      	ldr	x8, [x21, #0x1010]
    5bc8:      	cbz	x8, 0x5c24 <kprobe_unwind_dotnet+0x5c24>
    5bcc:      	mov	w9, #-0x28              // =-40
    5bd0:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5bd4:      	ldr	x8, [x21, #0xf88]
    5bd8:      	cbz	x8, 0x5c34 <kprobe_unwind_dotnet+0x5c34>
    5bdc:      	mov	w9, #-0x6               // =-6
    5be0:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    5be4:      	ldr	x8, [x21, #0xfe0]
    5be8:      	cbz	x8, 0x5c44 <kprobe_unwind_dotnet+0x5c44>
    5bec:      	mov	w9, #-0x1c              // =-28
    5bf0:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5bf4:      	ldr	x8, [x21, #0x1078]
    5bf8:      	cbz	x8, 0x5c54 <kprobe_unwind_dotnet+0x5c54>
    5bfc:      	mov	w9, #-0x42              // =-66
    5c00:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5c04:      	ldr	x8, [x21, #0xfb0]
    5c08:      	cbz	x8, 0x5c64 <kprobe_unwind_dotnet+0x5c64>
    5c0c:      	mov	w9, #-0x10              // =-16
    5c10:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5c14:      	ldr	x8, [x21, #0x1038]
    5c18:      	cbz	x8, 0x5c74 <kprobe_unwind_dotnet+0x5c74>
    5c1c:      	mov	w9, #-0x32              // =-50
    5c20:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5c24:      	ldr	x8, [x21, #0x1008]
    5c28:      	cbz	x8, 0x5c84 <kprobe_unwind_dotnet+0x5c84>
    5c2c:      	mov	w9, #-0x26              // =-38
    5c30:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5c34:      	ldr	x8, [x21, #0xf80]
    5c38:      	cbz	x8, 0x5c94 <kprobe_unwind_dotnet+0x5c94>
    5c3c:      	mov	w9, #-0x4               // =-4
    5c40:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    5c44:      	ldr	x8, [x21, #0xfd8]
    5c48:      	cbz	x8, 0x5ca4 <kprobe_unwind_dotnet+0x5ca4>
    5c4c:      	mov	w9, #-0x1a              // =-26
    5c50:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5c54:      	ldr	x8, [x21, #0x1070]
    5c58:      	cbz	x8, 0x5cb4 <kprobe_unwind_dotnet+0x5cb4>
    5c5c:      	mov	w9, #-0x40              // =-64
    5c60:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5c64:      	ldr	x8, [x21, #0xfa8]
    5c68:      	cbz	x8, 0x5cc4 <kprobe_unwind_dotnet+0x5cc4>
    5c6c:      	mov	w9, #-0xe               // =-14
    5c70:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5c74:      	ldr	x8, [x21, #0x1030]
    5c78:      	cbz	x8, 0x5cd4 <kprobe_unwind_dotnet+0x5cd4>
    5c7c:      	mov	w9, #-0x30              // =-48
    5c80:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5c84:      	ldr	x8, [x21, #0x1000]
    5c88:      	cbz	x8, 0x5ce4 <kprobe_unwind_dotnet+0x5ce4>
    5c8c:      	mov	w9, #-0x24              // =-36
    5c90:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5c94:      	ldr	x8, [x21, #0xf78]
    5c98:      	cbz	x8, 0x5cf4 <kprobe_unwind_dotnet+0x5cf4>
    5c9c:      	mov	w9, #-0x2               // =-2
    5ca0:      	b	0x5d00 <kprobe_unwind_dotnet+0x5d00>
    5ca4:      	ldr	x8, [x21, #0xfd0]
    5ca8:      	cbz	x8, 0x5ee0 <kprobe_unwind_dotnet+0x5ee0>
    5cac:      	mov	w9, #-0x18              // =-24
    5cb0:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5cb4:      	ldr	x8, [x21, #0x1068]
    5cb8:      	cbz	x8, 0x5ef0 <kprobe_unwind_dotnet+0x5ef0>
    5cbc:      	mov	w9, #-0x3e              // =-62
    5cc0:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5cc4:      	ldr	x8, [x21, #0xfa0]
    5cc8:      	cbz	x8, 0x5f00 <kprobe_unwind_dotnet+0x5f00>
    5ccc:      	mov	w9, #-0xc               // =-12
    5cd0:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5cd4:      	ldr	x8, [x21, #0x1028]
    5cd8:      	cbz	x8, 0x5f10 <kprobe_unwind_dotnet+0x5f10>
    5cdc:      	mov	w9, #-0x2e              // =-46
    5ce0:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5ce4:      	ldr	x8, [x21, #0xff8]
    5ce8:      	cbz	x8, 0x5f20 <kprobe_unwind_dotnet+0x5f20>
    5cec:      	mov	w9, #-0x22              // =-34
    5cf0:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5cf4:      	ldr	x8, [sp, #0x18]
    5cf8:      	mov	w9, wzr
    5cfc:      	ldr	x8, [x8]
    5d00:      	lsr	x10, x8, #32
    5d04:      	cmp	x10, #0x0
    5d08:      	cset	w11, ne
    5d0c:      	csel	w23, w10, w8, ne
    5d10:      	sub	w8, w9, w11
    5d14:      	add	w3, w8, #0x7e
    5d18:      	lsl	w8, w3, #8
    5d1c:      	subs	x29, x29, x8
    5d20:      	b.hs	0x5dbc <kprobe_unwind_dotnet+0x5dbc>
    5d24:      	adrp	x23, 0x5000 <kprobe_unwind_dotnet+0x5000>
    5d28:      	ldr	x23, [x23]
    5d2c:      	ldr	w8, [x23]
    5d30:      	cbz	w8, 0x390 <kprobe_unwind_dotnet+0x390>
    5d34:      	adrp	x8, 0x5000 <kprobe_unwind_dotnet+0x5000>
    5d38:      	add	x8, x8, #0x0
    5d3c:      	add	x0, sp, #0x20
    5d40:      	ldp	x9, x10, [x8, #0x10]
    5d44:      	mov	w1, #0x2e               // =46
    5d48:      	stp	x9, x10, [sp, #0x30]
    5d4c:      	ldr	x9, [x8, #0x20]
    5d50:      	add	x10, sp, #0x20
    5d54:      	str	x9, [sp, #0x40]
    5d58:      	ldur	x9, [x8, #0x26]
    5d5c:      	stur	x9, [sp, #0x46]
    5d60:      	ldp	x9, x8, [x8]
    5d64:      	stp	x9, x8, [sp, #0x20]
    5d68:      	mov	w8, #0x2e               // =46
    5d6c:      	mov	w9, #0x6                // =6
    5d70:      	blr	x9
    5d74:      	adrp	x23, 0x5000 <kprobe_unwind_dotnet+0x5000>
    5d78:      	ldr	x23, [x23]
    5d7c:      	ldr	w8, [x23]
    5d80:      	cbz	w8, 0x390 <kprobe_unwind_dotnet+0x390>
    5d84:      	mov	w8, #0x646e             // =25710
    5d88:      	add	x10, sp, #0x20
    5d8c:      	add	x0, sp, #0x20
    5d90:      	mov	w1, #0x13               // =19
    5d94:      	movk	w8, #0xa, lsl #16
    5d98:      	stur	w8, [sp, #0x2f]
    5d9c:      	adrp	x8, 0x5000 <kprobe_unwind_dotnet+0x5000>
    5da0:      	add	x8, x8, #0x0
    5da4:      	ldp	x9, x8, [x8]
    5da8:      	stp	x9, x8, [sp, #0x20]
    5dac:      	mov	w8, #0x13               // =19
    5db0:      	mov	w9, #0x6                // =6
    5db4:      	blr	x9
    5db8:      	b	0x390 <kprobe_unwind_dotnet+0x390>
    5dbc:      	adrp	x8, 0x5000 <kprobe_unwind_dotnet+0x5000>
    5dc0:      	ldr	x8, [x8]
    5dc4:      	ldr	w8, [x8]
    5dc8:      	cbnz	w8, 0x5e3c <kprobe_unwind_dotnet+0x5e3c>
    5dcc:      	cbnz	w23, 0x458 <kprobe_unwind_dotnet+0x458>
    5dd0:      	mov	w8, #0x5f               // =95
    5dd4:      	adrp	x24, 0x5000 <kprobe_unwind_dotnet+0x5000>
    5dd8:      	add	x9, sp, #0x8c
    5ddc:      	str	w8, [sp, #0x8c]
    5de0:      	mov	w8, #0x1                // =1
    5de4:      	add	x1, sp, #0x8c
    5de8:      	ldr	x24, [x24]
    5dec:      	mov	x0, x24
    5df0:      	blr	x8
    5df4:      	cbz	x0, 0x5e14 <kprobe_unwind_dotnet+0x5e14>
    5df8:      	ldr	x8, [x0]
    5dfc:      	adrp	x23, 0x5000 <kprobe_unwind_dotnet+0x5000>
    5e00:      	add	x8, x8, #0x1
    5e04:      	str	x8, [x0]
    5e08:      	ldr	x23, [x23]
    5e0c:      	ldr	x11, [sp, #0x10]
    5e10:      	b	0x5e28 <kprobe_unwind_dotnet+0x5e28>
    5e14:      	adrp	x23, 0x5000 <kprobe_unwind_dotnet+0x5000>
    5e18:      	ldr	x23, [x23]
    5e1c:      	ldr	x11, [sp, #0x10]
    5e20:      	ldr	w8, [x23]
    5e24:      	cbnz	w8, 0x5e98 <kprobe_unwind_dotnet+0x5e98>
    5e28:      	mov	w2, #0x1773             // =6003
    5e2c:      	mov	w22, #0x1               // =1
    5e30:      	ldr	w8, [x23]
    5e34:      	cbz	w8, 0x48c <kprobe_unwind_dotnet+0x48c>
    5e38:      	b	0x3d8 <kprobe_unwind_dotnet+0x3d8>
    5e3c:      	mov	w8, #0x7825             // =30757
    5e40:      	add	x0, sp, #0x20
    5e44:      	mov	w1, #0x3c               // =60
    5e48:      	mov	x2, x29
    5e4c:      	mov	w4, w23
    5e50:      	movk	w8, #0xa, lsl #16
    5e54:      	str	w8, [sp, #0x58]
    5e58:      	adrp	x8, 0x5000 <kprobe_unwind_dotnet+0x5000>
    5e5c:      	add	x8, x8, #0x0
    5e60:      	ldp	x9, x10, [x8, #0x20]
    5e64:      	stp	x9, x10, [sp, #0x40]
    5e68:      	ldr	x9, [x8, #0x30]
    5e6c:      	str	x9, [sp, #0x50]
    5e70:      	ldp	x9, x10, [x8]
    5e74:      	stp	x9, x10, [sp, #0x20]
    5e78:      	add	x10, sp, #0x20
    5e7c:      	ldp	x8, x9, [x8, #0x10]
    5e80:      	stp	x8, x9, [sp, #0x30]
    5e84:      	mov	w8, #0x3c               // =60
    5e88:      	mov	w9, #0x6                // =6
    5e8c:      	blr	x9
    5e90:      	cbnz	w23, 0x458 <kprobe_unwind_dotnet+0x458>
    5e94:      	b	0x5dd0 <kprobe_unwind_dotnet+0x5dd0>
    5e98:      	adrp	x8, 0x5000 <kprobe_unwind_dotnet+0x5000>
    5e9c:      	add	x8, x8, #0x0
    5ea0:      	add	x0, sp, #0x20
    5ea4:      	ldp	x9, x10, [x8, #0x10]
    5ea8:      	mov	w1, #0x2e               // =46
    5eac:      	stp	x9, x10, [sp, #0x30]
    5eb0:      	ldr	x9, [x8, #0x20]
    5eb4:      	add	x10, sp, #0x20
    5eb8:      	str	x9, [sp, #0x40]
    5ebc:      	ldur	x9, [x8, #0x26]
    5ec0:      	stur	x9, [sp, #0x46]
    5ec4:      	ldp	x9, x8, [x8]
    5ec8:      	stp	x9, x8, [sp, #0x20]
    5ecc:      	mov	w8, #0x2e               // =46
    5ed0:      	mov	w9, #0x6                // =6
    5ed4:      	ldr	w2, [sp, #0x8c]
    5ed8:      	blr	x9
    5edc:      	b	0x5e0c <kprobe_unwind_dotnet+0x5e0c>
    5ee0:      	ldr	x8, [x21, #0xfc8]
    5ee4:      	cbz	x8, 0x5f30 <kprobe_unwind_dotnet+0x5f30>
    5ee8:      	mov	w9, #-0x16              // =-22
    5eec:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5ef0:      	ldr	x8, [x21, #0x1060]
    5ef4:      	cbz	x8, 0x5f40 <kprobe_unwind_dotnet+0x5f40>
    5ef8:      	mov	w9, #-0x3c              // =-60
    5efc:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5f00:      	ldr	x8, [x21, #0xf98]
    5f04:      	cbz	x8, 0x5f50 <kprobe_unwind_dotnet+0x5f50>
    5f08:      	mov	w9, #-0xa               // =-10
    5f0c:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5f10:      	ldr	x8, [x21, #0x1020]
    5f14:      	cbz	x8, 0x5f60 <kprobe_unwind_dotnet+0x5f60>
    5f18:      	mov	w9, #-0x2c              // =-44
    5f1c:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5f20:      	ldr	x8, [x21, #0xff0]
    5f24:      	cbz	x8, 0x5f70 <kprobe_unwind_dotnet+0x5f70>
    5f28:      	mov	w9, #-0x20              // =-32
    5f2c:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5f30:      	ldr	x8, [x21, #0xfc0]
    5f34:      	cbz	x8, 0x5f80 <kprobe_unwind_dotnet+0x5f80>
    5f38:      	mov	w9, #-0x14              // =-20
    5f3c:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5f40:      	ldr	x8, [x21, #0x1058]
    5f44:      	cbz	x8, 0x5f90 <kprobe_unwind_dotnet+0x5f90>
    5f48:      	mov	w9, #-0x3a              // =-58
    5f4c:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5f50:      	ldr	x8, [x21, #0xf90]
    5f54:      	cbz	x8, 0x5fa0 <kprobe_unwind_dotnet+0x5fa0>
    5f58:      	mov	w9, #-0x8               // =-8
    5f5c:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5f60:      	ldr	x8, [x21, #0x1018]
    5f64:      	cbz	x8, 0x5fb0 <kprobe_unwind_dotnet+0x5fb0>
    5f68:      	mov	w9, #-0x2a              // =-42
    5f6c:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5f70:      	ldr	x8, [x21, #0xfe8]
    5f74:      	cbz	x8, 0x5fc0 <kprobe_unwind_dotnet+0x5fc0>
    5f78:      	mov	w9, #-0x1e              // =-30
    5f7c:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5f80:      	ldr	x8, [x21, #0xfb8]
    5f84:      	cbz	x8, 0x5fd0 <kprobe_unwind_dotnet+0x5fd0>
    5f88:      	mov	w9, #-0x12              // =-18
    5f8c:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5f90:      	ldr	x8, [x21, #0x1050]
    5f94:      	cbz	x8, 0x5fe0 <kprobe_unwind_dotnet+0x5fe0>
    5f98:      	mov	w9, #-0x38              // =-56
    5f9c:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5fa0:      	ldr	x8, [x21, #0xf88]
    5fa4:      	cbz	x8, 0x5ff0 <kprobe_unwind_dotnet+0x5ff0>
    5fa8:      	mov	w9, #-0x6               // =-6
    5fac:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    5fb0:      	ldr	x8, [x21, #0x1010]
    5fb4:      	cbz	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    5fb8:      	mov	w9, #-0x28              // =-40
    5fbc:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    5fc0:      	ldr	x8, [x21, #0xfe0]
    5fc4:      	cbz	x8, 0x6010 <kprobe_unwind_dotnet+0x6010>
    5fc8:      	mov	w9, #-0x1c              // =-28
    5fcc:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    5fd0:      	ldr	x8, [x21, #0xfb0]
    5fd4:      	cbz	x8, 0x6020 <kprobe_unwind_dotnet+0x6020>
    5fd8:      	mov	w9, #-0x10              // =-16
    5fdc:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    5fe0:      	ldr	x8, [x21, #0x1048]
    5fe4:      	cbz	x8, 0x6030 <kprobe_unwind_dotnet+0x6030>
    5fe8:      	mov	w9, #-0x36              // =-54
    5fec:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    5ff0:      	ldr	x8, [x21, #0xf80]
    5ff4:      	cbz	x8, 0x6040 <kprobe_unwind_dotnet+0x6040>
    5ff8:      	mov	w9, #-0x4               // =-4
    5ffc:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    6000:      	ldr	x8, [x21, #0x1008]
    6004:      	cbz	x8, 0x6050 <kprobe_unwind_dotnet+0x6050>
    6008:      	mov	w9, #-0x26              // =-38
    600c:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    6010:      	ldr	x8, [x21, #0xfd8]
    6014:      	cbz	x8, 0x6060 <kprobe_unwind_dotnet+0x6060>
    6018:      	mov	w9, #-0x1a              // =-26
    601c:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    6020:      	ldr	x8, [x21, #0xfa8]
    6024:      	cbz	x8, 0x6070 <kprobe_unwind_dotnet+0x6070>
    6028:      	mov	w9, #-0xe               // =-14
    602c:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    6030:      	ldr	x8, [x21, #0x1040]
    6034:      	cbz	x8, 0x6080 <kprobe_unwind_dotnet+0x6080>
    6038:      	mov	w9, #-0x34              // =-52
    603c:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6040:      	ldr	x8, [x21, #0xf78]
    6044:      	cbz	x8, 0x6090 <kprobe_unwind_dotnet+0x6090>
    6048:      	mov	w9, #-0x2               // =-2
    604c:      	b	0x609c <kprobe_unwind_dotnet+0x609c>
    6050:      	ldr	x8, [x21, #0x1000]
    6054:      	cbz	x8, 0x62f4 <kprobe_unwind_dotnet+0x62f4>
    6058:      	mov	w9, #-0x24              // =-36
    605c:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    6060:      	ldr	x8, [x21, #0xfd0]
    6064:      	cbz	x8, 0x6304 <kprobe_unwind_dotnet+0x6304>
    6068:      	mov	w9, #-0x18              // =-24
    606c:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    6070:      	ldr	x8, [x21, #0xfa0]
    6074:      	cbz	x8, 0x6314 <kprobe_unwind_dotnet+0x6314>
    6078:      	mov	w9, #-0xc               // =-12
    607c:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    6080:      	ldr	x8, [x21, #0x1038]
    6084:      	cbz	x8, 0x6324 <kprobe_unwind_dotnet+0x6324>
    6088:      	mov	w9, #-0x32              // =-50
    608c:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6090:      	ldr	x8, [sp, #0x18]
    6094:      	mov	w9, wzr
    6098:      	ldr	x8, [x8]
    609c:      	lsr	x10, x8, #32
    60a0:      	cmp	x10, #0x0
    60a4:      	cset	w11, ne
    60a8:      	csel	w25, w10, w8, ne
    60ac:      	sub	w8, w9, w11
    60b0:      	add	w3, w8, #0x7e
    60b4:      	lsl	w8, w3, #8
    60b8:      	subs	x29, x23, x8
    60bc:      	b.hs	0x6158 <kprobe_unwind_dotnet+0x6158>
    60c0:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    60c4:      	ldr	x8, [x8]
    60c8:      	ldr	w8, [x8]
    60cc:      	cbz	w8, 0x1230 <kprobe_unwind_dotnet+0x1230>
    60d0:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    60d4:      	add	x8, x8, #0x0
    60d8:      	add	x0, sp, #0x20
    60dc:      	ldp	x9, x10, [x8, #0x10]
    60e0:      	mov	w1, #0x2e               // =46
    60e4:      	stp	x9, x10, [sp, #0x30]
    60e8:      	ldr	x9, [x8, #0x20]
    60ec:      	add	x10, sp, #0x20
    60f0:      	str	x9, [sp, #0x40]
    60f4:      	ldur	x9, [x8, #0x26]
    60f8:      	stur	x9, [sp, #0x46]
    60fc:      	ldp	x9, x8, [x8]
    6100:      	stp	x9, x8, [sp, #0x20]
    6104:      	mov	w8, #0x2e               // =46
    6108:      	mov	w9, #0x6                // =6
    610c:      	blr	x9
    6110:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6114:      	ldr	x8, [x8]
    6118:      	ldr	w8, [x8]
    611c:      	cbz	w8, 0x1230 <kprobe_unwind_dotnet+0x1230>
    6120:      	mov	w8, #0x646e             // =25710
    6124:      	add	x10, sp, #0x20
    6128:      	add	x0, sp, #0x20
    612c:      	mov	w1, #0x13               // =19
    6130:      	movk	w8, #0xa, lsl #16
    6134:      	stur	w8, [sp, #0x2f]
    6138:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    613c:      	add	x8, x8, #0x0
    6140:      	ldp	x9, x8, [x8]
    6144:      	stp	x9, x8, [sp, #0x20]
    6148:      	mov	w8, #0x13               // =19
    614c:      	mov	w9, #0x6                // =6
    6150:      	blr	x9
    6154:      	b	0x1230 <kprobe_unwind_dotnet+0x1230>
    6158:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    615c:      	ldr	x8, [x8]
    6160:      	ldr	w8, [x8]
    6164:      	cbnz	w8, 0x6238 <kprobe_unwind_dotnet+0x6238>
    6168:      	cbnz	w25, 0x12a4 <kprobe_unwind_dotnet+0x12a4>
    616c:      	mov	w8, #0x5f               // =95
    6170:      	adrp	x0, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6174:      	add	x9, sp, #0x8c
    6178:      	str	w8, [sp, #0x8c]
    617c:      	mov	w8, #0x1                // =1
    6180:      	add	x1, sp, #0x8c
    6184:      	ldr	x0, [x0]
    6188:      	blr	x8
    618c:      	cbz	x0, 0x61b8 <kprobe_unwind_dotnet+0x61b8>
    6190:      	ldr	x8, [x0]
    6194:      	add	x8, x8, #0x1
    6198:      	str	x8, [x0]
    619c:      	mov	w2, #0x1773             // =6003
    61a0:      	mov	w22, #0x1               // =1
    61a4:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    61a8:      	ldr	x8, [x8]
    61ac:      	ldr	w8, [x8]
    61b0:      	cbz	w8, 0x12e4 <kprobe_unwind_dotnet+0x12e4>
    61b4:      	b	0x61e0 <kprobe_unwind_dotnet+0x61e0>
    61b8:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    61bc:      	ldr	x8, [x8]
    61c0:      	ldr	w8, [x8]
    61c4:      	cbnz	w8, 0x6294 <kprobe_unwind_dotnet+0x6294>
    61c8:      	mov	w2, #0x1773             // =6003
    61cc:      	mov	w22, #0x1               // =1
    61d0:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    61d4:      	ldr	x8, [x8]
    61d8:      	ldr	w8, [x8]
    61dc:      	cbz	w8, 0x12e4 <kprobe_unwind_dotnet+0x12e4>
    61e0:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    61e4:      	add	x8, x8, #0x0
    61e8:      	add	x0, sp, #0x20
    61ec:      	ldp	x9, x10, [x8, #0x10]
    61f0:      	mov	w1, #0x28               // =40
    61f4:      	stp	x9, x10, [sp, #0x30]
    61f8:      	ldr	x9, [x8, #0x20]
    61fc:      	add	x10, sp, #0x20
    6200:      	str	x9, [sp, #0x40]
    6204:      	ldp	x8, x9, [x8]
    6208:      	stp	x8, x9, [sp, #0x20]
    620c:      	mov	w8, #0x28               // =40
    6210:      	mov	w9, #0x6                // =6
    6214:      	blr	x9
    6218:      	cbnz	w22, 0x12e8 <kprobe_unwind_dotnet+0x12e8>
    621c:      	adrp	x23, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6220:      	adrp	x24, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6224:      	mov	w8, #0x1772             // =6002
    6228:      	ldr	x23, [x23]
    622c:      	ldr	x24, [x24]
    6230:      	mov	w25, wzr
    6234:      	b	0x4624 <kprobe_unwind_dotnet+0x4624>
    6238:      	mov	w8, #0x7825             // =30757
    623c:      	add	x0, sp, #0x20
    6240:      	mov	w1, #0x3c               // =60
    6244:      	mov	x2, x29
    6248:      	mov	w4, w25
    624c:      	movk	w8, #0xa, lsl #16
    6250:      	str	w8, [sp, #0x58]
    6254:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6258:      	add	x8, x8, #0x0
    625c:      	ldp	x9, x10, [x8, #0x20]
    6260:      	stp	x9, x10, [sp, #0x40]
    6264:      	ldr	x9, [x8, #0x30]
    6268:      	str	x9, [sp, #0x50]
    626c:      	ldp	x9, x10, [x8]
    6270:      	stp	x9, x10, [sp, #0x20]
    6274:      	add	x10, sp, #0x20
    6278:      	ldp	x8, x9, [x8, #0x10]
    627c:      	stp	x8, x9, [sp, #0x30]
    6280:      	mov	w8, #0x3c               // =60
    6284:      	mov	w9, #0x6                // =6
    6288:      	blr	x9
    628c:      	cbnz	w25, 0x12a4 <kprobe_unwind_dotnet+0x12a4>
    6290:      	b	0x616c <kprobe_unwind_dotnet+0x616c>
    6294:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6298:      	add	x8, x8, #0x0
    629c:      	add	x0, sp, #0x20
    62a0:      	ldp	x9, x10, [x8, #0x10]
    62a4:      	mov	w1, #0x2e               // =46
    62a8:      	stp	x9, x10, [sp, #0x30]
    62ac:      	ldr	x9, [x8, #0x20]
    62b0:      	add	x10, sp, #0x20
    62b4:      	str	x9, [sp, #0x40]
    62b8:      	ldur	x9, [x8, #0x26]
    62bc:      	stur	x9, [sp, #0x46]
    62c0:      	ldp	x9, x8, [x8]
    62c4:      	stp	x9, x8, [sp, #0x20]
    62c8:      	mov	w8, #0x2e               // =46
    62cc:      	mov	w9, #0x6                // =6
    62d0:      	ldr	w2, [sp, #0x8c]
    62d4:      	blr	x9
    62d8:      	mov	w2, #0x1773             // =6003
    62dc:      	mov	w22, #0x1               // =1
    62e0:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    62e4:      	ldr	x8, [x8]
    62e8:      	ldr	w8, [x8]
    62ec:      	cbz	w8, 0x12e4 <kprobe_unwind_dotnet+0x12e4>
    62f0:      	b	0x61e0 <kprobe_unwind_dotnet+0x61e0>
    62f4:      	ldr	x8, [x21, #0xff8]
    62f8:      	cbz	x8, 0x6334 <kprobe_unwind_dotnet+0x6334>
    62fc:      	mov	w9, #-0x22              // =-34
    6300:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    6304:      	ldr	x8, [x21, #0xfc8]
    6308:      	cbz	x8, 0x6344 <kprobe_unwind_dotnet+0x6344>
    630c:      	mov	w9, #-0x16              // =-22
    6310:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    6314:      	ldr	x8, [x21, #0xf98]
    6318:      	cbz	x8, 0x6354 <kprobe_unwind_dotnet+0x6354>
    631c:      	mov	w9, #-0xa               // =-10
    6320:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    6324:      	ldr	x8, [x21, #0x1030]
    6328:      	cbz	x8, 0x6364 <kprobe_unwind_dotnet+0x6364>
    632c:      	mov	w9, #-0x30              // =-48
    6330:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6334:      	ldr	x8, [x21, #0xff0]
    6338:      	cbz	x8, 0x6374 <kprobe_unwind_dotnet+0x6374>
    633c:      	mov	w9, #-0x20              // =-32
    6340:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    6344:      	ldr	x8, [x21, #0xfc0]
    6348:      	cbz	x8, 0x6384 <kprobe_unwind_dotnet+0x6384>
    634c:      	mov	w9, #-0x14              // =-20
    6350:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    6354:      	ldr	x8, [x21, #0xf90]
    6358:      	cbz	x8, 0x6394 <kprobe_unwind_dotnet+0x6394>
    635c:      	mov	w9, #-0x8               // =-8
    6360:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    6364:      	ldr	x8, [x21, #0x1028]
    6368:      	cbz	x8, 0x63a4 <kprobe_unwind_dotnet+0x63a4>
    636c:      	mov	w9, #-0x2e              // =-46
    6370:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6374:      	ldr	x8, [x21, #0xfe8]
    6378:      	cbz	x8, 0x63b4 <kprobe_unwind_dotnet+0x63b4>
    637c:      	mov	w9, #-0x1e              // =-30
    6380:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    6384:      	ldr	x8, [x21, #0xfb8]
    6388:      	cbz	x8, 0x63c4 <kprobe_unwind_dotnet+0x63c4>
    638c:      	mov	w9, #-0x12              // =-18
    6390:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    6394:      	ldr	x8, [x21, #0xf88]
    6398:      	cbz	x8, 0x63d4 <kprobe_unwind_dotnet+0x63d4>
    639c:      	mov	w9, #-0x6               // =-6
    63a0:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    63a4:      	ldr	x8, [x21, #0x1020]
    63a8:      	cbz	x8, 0x63e4 <kprobe_unwind_dotnet+0x63e4>
    63ac:      	mov	w9, #-0x2c              // =-44
    63b0:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    63b4:      	ldr	x8, [x21, #0xfe0]
    63b8:      	cbz	x8, 0x63f4 <kprobe_unwind_dotnet+0x63f4>
    63bc:      	mov	w9, #-0x1c              // =-28
    63c0:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    63c4:      	ldr	x8, [x21, #0xfb0]
    63c8:      	cbz	x8, 0x6404 <kprobe_unwind_dotnet+0x6404>
    63cc:      	mov	w9, #-0x10              // =-16
    63d0:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    63d4:      	ldr	x8, [x21, #0xf80]
    63d8:      	cbz	x8, 0x6414 <kprobe_unwind_dotnet+0x6414>
    63dc:      	mov	w9, #-0x4               // =-4
    63e0:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    63e4:      	ldr	x8, [x21, #0x1018]
    63e8:      	cbz	x8, 0x6424 <kprobe_unwind_dotnet+0x6424>
    63ec:      	mov	w9, #-0x2a              // =-42
    63f0:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    63f4:      	ldr	x8, [x21, #0xfd8]
    63f8:      	cbz	x8, 0x6434 <kprobe_unwind_dotnet+0x6434>
    63fc:      	mov	w9, #-0x1a              // =-26
    6400:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    6404:      	ldr	x8, [x21, #0xfa8]
    6408:      	cbz	x8, 0x6444 <kprobe_unwind_dotnet+0x6444>
    640c:      	mov	w9, #-0xe               // =-14
    6410:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    6414:      	ldr	x8, [x21, #0xf78]
    6418:      	cbz	x8, 0x6454 <kprobe_unwind_dotnet+0x6454>
    641c:      	mov	w9, #-0x2               // =-2
    6420:      	b	0x6460 <kprobe_unwind_dotnet+0x6460>
    6424:      	ldr	x8, [x21, #0x1010]
    6428:      	cbz	x8, 0x66a0 <kprobe_unwind_dotnet+0x66a0>
    642c:      	mov	w9, #-0x28              // =-40
    6430:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6434:      	ldr	x8, [x21, #0xfd0]
    6438:      	cbz	x8, 0x66b0 <kprobe_unwind_dotnet+0x66b0>
    643c:      	mov	w9, #-0x18              // =-24
    6440:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    6444:      	ldr	x8, [x21, #0xfa0]
    6448:      	cbz	x8, 0x66c0 <kprobe_unwind_dotnet+0x66c0>
    644c:      	mov	w9, #-0xc               // =-12
    6450:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    6454:      	ldr	x8, [sp, #0x18]
    6458:      	mov	w9, wzr
    645c:      	ldr	x8, [x8]
    6460:      	lsr	x10, x8, #32
    6464:      	cmp	x10, #0x0
    6468:      	cset	w11, ne
    646c:      	csel	w25, w10, w8, ne
    6470:      	sub	w8, w9, w11
    6474:      	add	w3, w8, #0x7e
    6478:      	lsl	w8, w3, #8
    647c:      	subs	x29, x23, x8
    6480:      	b.hs	0x651c <kprobe_unwind_dotnet+0x651c>
    6484:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6488:      	ldr	x8, [x8]
    648c:      	ldr	w8, [x8]
    6490:      	cbz	w8, 0x1e10 <kprobe_unwind_dotnet+0x1e10>
    6494:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6498:      	add	x8, x8, #0x0
    649c:      	add	x0, sp, #0x20
    64a0:      	ldp	x9, x10, [x8, #0x10]
    64a4:      	mov	w1, #0x2e               // =46
    64a8:      	stp	x9, x10, [sp, #0x30]
    64ac:      	ldr	x9, [x8, #0x20]
    64b0:      	add	x10, sp, #0x20
    64b4:      	str	x9, [sp, #0x40]
    64b8:      	ldur	x9, [x8, #0x26]
    64bc:      	stur	x9, [sp, #0x46]
    64c0:      	ldp	x9, x8, [x8]
    64c4:      	stp	x9, x8, [sp, #0x20]
    64c8:      	mov	w8, #0x2e               // =46
    64cc:      	mov	w9, #0x6                // =6
    64d0:      	blr	x9
    64d4:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    64d8:      	ldr	x8, [x8]
    64dc:      	ldr	w8, [x8]
    64e0:      	cbz	w8, 0x1e10 <kprobe_unwind_dotnet+0x1e10>
    64e4:      	mov	w8, #0x646e             // =25710
    64e8:      	add	x10, sp, #0x20
    64ec:      	add	x0, sp, #0x20
    64f0:      	mov	w1, #0x13               // =19
    64f4:      	movk	w8, #0xa, lsl #16
    64f8:      	stur	w8, [sp, #0x2f]
    64fc:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6500:      	add	x8, x8, #0x0
    6504:      	ldp	x9, x8, [x8]
    6508:      	stp	x9, x8, [sp, #0x20]
    650c:      	mov	w8, #0x13               // =19
    6510:      	mov	w9, #0x6                // =6
    6514:      	blr	x9
    6518:      	b	0x1e10 <kprobe_unwind_dotnet+0x1e10>
    651c:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6520:      	ldr	x8, [x8]
    6524:      	ldr	w8, [x8]
    6528:      	cbnz	w8, 0x65e4 <kprobe_unwind_dotnet+0x65e4>
    652c:      	cbnz	w25, 0x1e84 <kprobe_unwind_dotnet+0x1e84>
    6530:      	mov	w8, #0x5f               // =95
    6534:      	adrp	x0, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6538:      	add	x9, sp, #0x8c
    653c:      	str	w8, [sp, #0x8c]
    6540:      	mov	w8, #0x1                // =1
    6544:      	add	x1, sp, #0x8c
    6548:      	ldr	x0, [x0]
    654c:      	blr	x8
    6550:      	cbz	x0, 0x657c <kprobe_unwind_dotnet+0x657c>
    6554:      	ldr	x8, [x0]
    6558:      	add	x8, x8, #0x1
    655c:      	str	x8, [x0]
    6560:      	mov	w2, #0x1773             // =6003
    6564:      	mov	w22, #0x1               // =1
    6568:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    656c:      	ldr	x8, [x8]
    6570:      	ldr	w8, [x8]
    6574:      	cbz	w8, 0x1ec4 <kprobe_unwind_dotnet+0x1ec4>
    6578:      	b	0x65a4 <kprobe_unwind_dotnet+0x65a4>
    657c:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6580:      	ldr	x8, [x8]
    6584:      	ldr	w8, [x8]
    6588:      	cbnz	w8, 0x6640 <kprobe_unwind_dotnet+0x6640>
    658c:      	mov	w2, #0x1773             // =6003
    6590:      	mov	w22, #0x1               // =1
    6594:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6598:      	ldr	x8, [x8]
    659c:      	ldr	w8, [x8]
    65a0:      	cbz	w8, 0x1ec4 <kprobe_unwind_dotnet+0x1ec4>
    65a4:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    65a8:      	add	x8, x8, #0x0
    65ac:      	add	x0, sp, #0x20
    65b0:      	ldp	x9, x10, [x8, #0x10]
    65b4:      	mov	w1, #0x28               // =40
    65b8:      	stp	x9, x10, [sp, #0x30]
    65bc:      	ldr	x9, [x8, #0x20]
    65c0:      	add	x10, sp, #0x20
    65c4:      	str	x9, [sp, #0x40]
    65c8:      	ldp	x8, x9, [x8]
    65cc:      	stp	x8, x9, [sp, #0x20]
    65d0:      	mov	w8, #0x28               // =40
    65d4:      	mov	w9, #0x6                // =6
    65d8:      	blr	x9
    65dc:      	cbnz	w22, 0x1ec8 <kprobe_unwind_dotnet+0x1ec8>
    65e0:      	b	0x621c <kprobe_unwind_dotnet+0x621c>
    65e4:      	mov	w8, #0x7825             // =30757
    65e8:      	add	x0, sp, #0x20
    65ec:      	mov	w1, #0x3c               // =60
    65f0:      	mov	x2, x29
    65f4:      	mov	w4, w25
    65f8:      	movk	w8, #0xa, lsl #16
    65fc:      	str	w8, [sp, #0x58]
    6600:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6604:      	add	x8, x8, #0x0
    6608:      	ldp	x9, x10, [x8, #0x20]
    660c:      	stp	x9, x10, [sp, #0x40]
    6610:      	ldr	x9, [x8, #0x30]
    6614:      	str	x9, [sp, #0x50]
    6618:      	ldp	x9, x10, [x8]
    661c:      	stp	x9, x10, [sp, #0x20]
    6620:      	add	x10, sp, #0x20
    6624:      	ldp	x8, x9, [x8, #0x10]
    6628:      	stp	x8, x9, [sp, #0x30]
    662c:      	mov	w8, #0x3c               // =60
    6630:      	mov	w9, #0x6                // =6
    6634:      	blr	x9
    6638:      	cbnz	w25, 0x1e84 <kprobe_unwind_dotnet+0x1e84>
    663c:      	b	0x6530 <kprobe_unwind_dotnet+0x6530>
    6640:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6644:      	add	x8, x8, #0x0
    6648:      	add	x0, sp, #0x20
    664c:      	ldp	x9, x10, [x8, #0x10]
    6650:      	mov	w1, #0x2e               // =46
    6654:      	stp	x9, x10, [sp, #0x30]
    6658:      	ldr	x9, [x8, #0x20]
    665c:      	add	x10, sp, #0x20
    6660:      	str	x9, [sp, #0x40]
    6664:      	ldur	x9, [x8, #0x26]
    6668:      	stur	x9, [sp, #0x46]
    666c:      	ldp	x9, x8, [x8]
    6670:      	stp	x9, x8, [sp, #0x20]
    6674:      	mov	w8, #0x2e               // =46
    6678:      	mov	w9, #0x6                // =6
    667c:      	ldr	w2, [sp, #0x8c]
    6680:      	blr	x9
    6684:      	mov	w2, #0x1773             // =6003
    6688:      	mov	w22, #0x1               // =1
    668c:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6690:      	ldr	x8, [x8]
    6694:      	ldr	w8, [x8]
    6698:      	cbz	w8, 0x1ec4 <kprobe_unwind_dotnet+0x1ec4>
    669c:      	b	0x65a4 <kprobe_unwind_dotnet+0x65a4>
    66a0:      	ldr	x8, [x21, #0x1008]
    66a4:      	cbz	x8, 0x66d0 <kprobe_unwind_dotnet+0x66d0>
    66a8:      	mov	w9, #-0x26              // =-38
    66ac:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    66b0:      	ldr	x8, [x21, #0xfc8]
    66b4:      	cbz	x8, 0x66e0 <kprobe_unwind_dotnet+0x66e0>
    66b8:      	mov	w9, #-0x16              // =-22
    66bc:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    66c0:      	ldr	x8, [x21, #0xf98]
    66c4:      	cbz	x8, 0x66f0 <kprobe_unwind_dotnet+0x66f0>
    66c8:      	mov	w9, #-0xa               // =-10
    66cc:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    66d0:      	ldr	x8, [x21, #0x1000]
    66d4:      	cbz	x8, 0x6700 <kprobe_unwind_dotnet+0x6700>
    66d8:      	mov	w9, #-0x24              // =-36
    66dc:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    66e0:      	ldr	x8, [x21, #0xfc0]
    66e4:      	cbz	x8, 0x6710 <kprobe_unwind_dotnet+0x6710>
    66e8:      	mov	w9, #-0x14              // =-20
    66ec:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    66f0:      	ldr	x8, [x21, #0xf90]
    66f4:      	cbz	x8, 0x6720 <kprobe_unwind_dotnet+0x6720>
    66f8:      	mov	w9, #-0x8               // =-8
    66fc:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    6700:      	ldr	x8, [x21, #0xff8]
    6704:      	cbz	x8, 0x6730 <kprobe_unwind_dotnet+0x6730>
    6708:      	mov	w9, #-0x22              // =-34
    670c:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6710:      	ldr	x8, [x21, #0xfb8]
    6714:      	cbz	x8, 0x6740 <kprobe_unwind_dotnet+0x6740>
    6718:      	mov	w9, #-0x12              // =-18
    671c:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    6720:      	ldr	x8, [x21, #0xf88]
    6724:      	cbz	x8, 0x6750 <kprobe_unwind_dotnet+0x6750>
    6728:      	mov	w9, #-0x6               // =-6
    672c:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    6730:      	ldr	x8, [x21, #0xff0]
    6734:      	cbz	x8, 0x6760 <kprobe_unwind_dotnet+0x6760>
    6738:      	mov	w9, #-0x20              // =-32
    673c:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6740:      	ldr	x8, [x21, #0xfb0]
    6744:      	cbz	x8, 0x6770 <kprobe_unwind_dotnet+0x6770>
    6748:      	mov	w9, #-0x10              // =-16
    674c:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    6750:      	ldr	x8, [x21, #0xf80]
    6754:      	cbz	x8, 0x6780 <kprobe_unwind_dotnet+0x6780>
    6758:      	mov	w9, #-0x4               // =-4
    675c:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    6760:      	ldr	x8, [x21, #0xfe8]
    6764:      	cbz	x8, 0x6790 <kprobe_unwind_dotnet+0x6790>
    6768:      	mov	w9, #-0x1e              // =-30
    676c:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6770:      	ldr	x8, [x21, #0xfa8]
    6774:      	cbz	x8, 0x67a0 <kprobe_unwind_dotnet+0x67a0>
    6778:      	mov	w9, #-0xe               // =-14
    677c:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    6780:      	ldr	x8, [x21, #0xf78]
    6784:      	cbz	x8, 0x67b0 <kprobe_unwind_dotnet+0x67b0>
    6788:      	mov	w9, #-0x2               // =-2
    678c:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    6790:      	ldr	x8, [x21, #0xfe0]
    6794:      	cbz	x8, 0x67c0 <kprobe_unwind_dotnet+0x67c0>
    6798:      	mov	w9, #-0x1c              // =-28
    679c:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    67a0:      	ldr	x8, [x21, #0xfa0]
    67a4:      	cbz	x8, 0x67d0 <kprobe_unwind_dotnet+0x67d0>
    67a8:      	mov	w9, #-0xc               // =-12
    67ac:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    67b0:      	ldr	x8, [sp, #0x18]
    67b4:      	mov	w9, wzr
    67b8:      	ldr	x8, [x8]
    67bc:      	b	0x3e44 <kprobe_unwind_dotnet+0x3e44>
    67c0:      	ldr	x8, [x21, #0xfd8]
    67c4:      	cbz	x8, 0x67e0 <kprobe_unwind_dotnet+0x67e0>
    67c8:      	mov	w9, #-0x1a              // =-26
    67cc:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    67d0:      	ldr	x8, [x21, #0xf98]
    67d4:      	cbz	x8, 0x67f0 <kprobe_unwind_dotnet+0x67f0>
    67d8:      	mov	w9, #-0xa               // =-10
    67dc:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    67e0:      	ldr	x8, [x21, #0xfd0]
    67e4:      	cbz	x8, 0x6800 <kprobe_unwind_dotnet+0x6800>
    67e8:      	mov	w9, #-0x18              // =-24
    67ec:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    67f0:      	ldr	x8, [x21, #0xf90]
    67f4:      	cbz	x8, 0x6810 <kprobe_unwind_dotnet+0x6810>
    67f8:      	mov	w9, #-0x8               // =-8
    67fc:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    6800:      	ldr	x8, [x21, #0xfc8]
    6804:      	cbz	x8, 0x6820 <kprobe_unwind_dotnet+0x6820>
    6808:      	mov	w9, #-0x16              // =-22
    680c:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6810:      	ldr	x8, [x21, #0xf88]
    6814:      	cbz	x8, 0x6830 <kprobe_unwind_dotnet+0x6830>
    6818:      	mov	w9, #-0x6               // =-6
    681c:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    6820:      	ldr	x8, [x21, #0xfc0]
    6824:      	cbz	x8, 0x6840 <kprobe_unwind_dotnet+0x6840>
    6828:      	mov	w9, #-0x14              // =-20
    682c:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6830:      	ldr	x8, [x21, #0xf80]
    6834:      	cbz	x8, 0x6850 <kprobe_unwind_dotnet+0x6850>
    6838:      	mov	w9, #-0x4               // =-4
    683c:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    6840:      	ldr	x8, [x21, #0xfb8]
    6844:      	cbz	x8, 0x6860 <kprobe_unwind_dotnet+0x6860>
    6848:      	mov	w9, #-0x12              // =-18
    684c:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6850:      	ldr	x8, [x21, #0xf78]
    6854:      	cbz	x8, 0x6870 <kprobe_unwind_dotnet+0x6870>
    6858:      	mov	w9, #-0x2               // =-2
    685c:      	b	0x687c <kprobe_unwind_dotnet+0x687c>
    6860:      	ldr	x8, [x21, #0xfb0]
    6864:      	cbz	x8, 0x6a5c <kprobe_unwind_dotnet+0x6a5c>
    6868:      	mov	w9, #-0x10              // =-16
    686c:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6870:      	ldr	x8, [sp, #0x18]
    6874:      	mov	w9, wzr
    6878:      	ldr	x8, [x8]
    687c:      	lsr	x10, x8, #32
    6880:      	cmp	x10, #0x0
    6884:      	cset	w11, ne
    6888:      	csel	w25, w10, w8, ne
    688c:      	sub	w8, w9, w11
    6890:      	add	w3, w8, #0x7e
    6894:      	lsl	w8, w3, #8
    6898:      	subs	x29, x23, x8
    689c:      	b.hs	0x6938 <kprobe_unwind_dotnet+0x6938>
    68a0:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    68a4:      	ldr	x8, [x8]
    68a8:      	ldr	w8, [x8]
    68ac:      	cbz	w8, 0x35d0 <kprobe_unwind_dotnet+0x35d0>
    68b0:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    68b4:      	add	x8, x8, #0x0
    68b8:      	add	x0, sp, #0x20
    68bc:      	ldp	x9, x10, [x8, #0x10]
    68c0:      	mov	w1, #0x2e               // =46
    68c4:      	stp	x9, x10, [sp, #0x30]
    68c8:      	ldr	x9, [x8, #0x20]
    68cc:      	add	x10, sp, #0x20
    68d0:      	str	x9, [sp, #0x40]
    68d4:      	ldur	x9, [x8, #0x26]
    68d8:      	stur	x9, [sp, #0x46]
    68dc:      	ldp	x9, x8, [x8]
    68e0:      	stp	x9, x8, [sp, #0x20]
    68e4:      	mov	w8, #0x2e               // =46
    68e8:      	mov	w9, #0x6                // =6
    68ec:      	blr	x9
    68f0:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    68f4:      	ldr	x8, [x8]
    68f8:      	ldr	w8, [x8]
    68fc:      	cbz	w8, 0x35d0 <kprobe_unwind_dotnet+0x35d0>
    6900:      	mov	w8, #0x646e             // =25710
    6904:      	add	x10, sp, #0x20
    6908:      	add	x0, sp, #0x20
    690c:      	mov	w1, #0x13               // =19
    6910:      	movk	w8, #0xa, lsl #16
    6914:      	stur	w8, [sp, #0x2f]
    6918:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    691c:      	add	x8, x8, #0x0
    6920:      	ldp	x9, x8, [x8]
    6924:      	stp	x9, x8, [sp, #0x20]
    6928:      	mov	w8, #0x13               // =19
    692c:      	mov	w9, #0x6                // =6
    6930:      	blr	x9
    6934:      	b	0x35d0 <kprobe_unwind_dotnet+0x35d0>
    6938:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    693c:      	ldr	x8, [x8]
    6940:      	ldr	w8, [x8]
    6944:      	cbnz	w8, 0x6a00 <kprobe_unwind_dotnet+0x6a00>
    6948:      	cbnz	w25, 0x3644 <kprobe_unwind_dotnet+0x3644>
    694c:      	mov	w8, #0x5f               // =95
    6950:      	adrp	x0, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6954:      	add	x9, sp, #0x8c
    6958:      	str	w8, [sp, #0x8c]
    695c:      	mov	w8, #0x1                // =1
    6960:      	add	x1, sp, #0x8c
    6964:      	ldr	x0, [x0]
    6968:      	blr	x8
    696c:      	cbz	x0, 0x6998 <kprobe_unwind_dotnet+0x6998>
    6970:      	ldr	x8, [x0]
    6974:      	add	x8, x8, #0x1
    6978:      	str	x8, [x0]
    697c:      	mov	w2, #0x1773             // =6003
    6980:      	mov	w22, #0x1               // =1
    6984:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6988:      	ldr	x8, [x8]
    698c:      	ldr	w8, [x8]
    6990:      	cbz	w8, 0x3684 <kprobe_unwind_dotnet+0x3684>
    6994:      	b	0x69c0 <kprobe_unwind_dotnet+0x69c0>
    6998:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    699c:      	ldr	x8, [x8]
    69a0:      	ldr	w8, [x8]
    69a4:      	cbnz	w8, 0x6a6c <kprobe_unwind_dotnet+0x6a6c>
    69a8:      	mov	w2, #0x1773             // =6003
    69ac:      	mov	w22, #0x1               // =1
    69b0:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    69b4:      	ldr	x8, [x8]
    69b8:      	ldr	w8, [x8]
    69bc:      	cbz	w8, 0x3684 <kprobe_unwind_dotnet+0x3684>
    69c0:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    69c4:      	add	x8, x8, #0x0
    69c8:      	add	x0, sp, #0x20
    69cc:      	ldp	x9, x10, [x8, #0x10]
    69d0:      	mov	w1, #0x28               // =40
    69d4:      	stp	x9, x10, [sp, #0x30]
    69d8:      	ldr	x9, [x8, #0x20]
    69dc:      	add	x10, sp, #0x20
    69e0:      	str	x9, [sp, #0x40]
    69e4:      	ldp	x8, x9, [x8]
    69e8:      	stp	x8, x9, [sp, #0x20]
    69ec:      	mov	w8, #0x28               // =40
    69f0:      	mov	w9, #0x6                // =6
    69f4:      	blr	x9
    69f8:      	cbnz	w22, 0x3688 <kprobe_unwind_dotnet+0x3688>
    69fc:      	b	0x621c <kprobe_unwind_dotnet+0x621c>
    6a00:      	mov	w8, #0x7825             // =30757
    6a04:      	add	x0, sp, #0x20
    6a08:      	mov	w1, #0x3c               // =60
    6a0c:      	mov	x2, x29
    6a10:      	mov	w4, w25
    6a14:      	movk	w8, #0xa, lsl #16
    6a18:      	str	w8, [sp, #0x58]
    6a1c:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6a20:      	add	x8, x8, #0x0
    6a24:      	ldp	x9, x10, [x8, #0x20]
    6a28:      	stp	x9, x10, [sp, #0x40]
    6a2c:      	ldr	x9, [x8, #0x30]
    6a30:      	str	x9, [sp, #0x50]
    6a34:      	ldp	x9, x10, [x8]
    6a38:      	stp	x9, x10, [sp, #0x20]
    6a3c:      	add	x10, sp, #0x20
    6a40:      	ldp	x8, x9, [x8, #0x10]
    6a44:      	stp	x8, x9, [sp, #0x30]
    6a48:      	mov	w8, #0x3c               // =60
    6a4c:      	mov	w9, #0x6                // =6
    6a50:      	blr	x9
    6a54:      	cbnz	w25, 0x3644 <kprobe_unwind_dotnet+0x3644>
    6a58:      	b	0x694c <kprobe_unwind_dotnet+0x694c>
    6a5c:      	ldr	x8, [x21, #0xfa8]
    6a60:      	cbz	x8, 0x6acc <kprobe_unwind_dotnet+0x6acc>
    6a64:      	mov	w9, #-0xe               // =-14
    6a68:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6a6c:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6a70:      	add	x8, x8, #0x0
    6a74:      	add	x0, sp, #0x20
    6a78:      	ldp	x9, x10, [x8, #0x10]
    6a7c:      	mov	w1, #0x2e               // =46
    6a80:      	stp	x9, x10, [sp, #0x30]
    6a84:      	ldr	x9, [x8, #0x20]
    6a88:      	add	x10, sp, #0x20
    6a8c:      	str	x9, [sp, #0x40]
    6a90:      	ldur	x9, [x8, #0x26]
    6a94:      	stur	x9, [sp, #0x46]
    6a98:      	ldp	x9, x8, [x8]
    6a9c:      	stp	x9, x8, [sp, #0x20]
    6aa0:      	mov	w8, #0x2e               // =46
    6aa4:      	mov	w9, #0x6                // =6
    6aa8:      	ldr	w2, [sp, #0x8c]
    6aac:      	blr	x9
    6ab0:      	mov	w2, #0x1773             // =6003
    6ab4:      	mov	w22, #0x1               // =1
    6ab8:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6abc:      	ldr	x8, [x8]
    6ac0:      	ldr	w8, [x8]
    6ac4:      	cbz	w8, 0x3684 <kprobe_unwind_dotnet+0x3684>
    6ac8:      	b	0x69c0 <kprobe_unwind_dotnet+0x69c0>
    6acc:      	ldr	x8, [x21, #0xfa0]
    6ad0:      	cbz	x8, 0x6adc <kprobe_unwind_dotnet+0x6adc>
    6ad4:      	mov	w9, #-0xc               // =-12
    6ad8:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6adc:      	ldr	x8, [x21, #0xf98]
    6ae0:      	cbz	x8, 0x6aec <kprobe_unwind_dotnet+0x6aec>
    6ae4:      	mov	w9, #-0xa               // =-10
    6ae8:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6aec:      	ldr	x8, [x21, #0xf90]
    6af0:      	cbz	x8, 0x6afc <kprobe_unwind_dotnet+0x6afc>
    6af4:      	mov	w9, #-0x8               // =-8
    6af8:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6afc:      	ldr	x8, [x21, #0xf88]
    6b00:      	cbz	x8, 0x6b0c <kprobe_unwind_dotnet+0x6b0c>
    6b04:      	mov	w9, #-0x6               // =-6
    6b08:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6b0c:      	ldr	x8, [x21, #0xf80]
    6b10:      	cbz	x8, 0x6b1c <kprobe_unwind_dotnet+0x6b1c>
    6b14:      	mov	w9, #-0x4               // =-4
    6b18:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6b1c:      	ldr	x8, [x21, #0xf78]
    6b20:      	cbz	x8, 0x6b2c <kprobe_unwind_dotnet+0x6b2c>
    6b24:      	mov	w9, #-0x2               // =-2
    6b28:      	b	0x6b38 <kprobe_unwind_dotnet+0x6b38>
    6b2c:      	ldr	x8, [sp, #0x18]
    6b30:      	mov	w9, wzr
    6b34:      	ldr	x8, [x8]
    6b38:      	lsr	x10, x8, #32
    6b3c:      	cmp	x10, #0x0
    6b40:      	cset	w11, ne
    6b44:      	csel	w25, w10, w8, ne
    6b48:      	sub	w8, w9, w11
    6b4c:      	add	w3, w8, #0x7e
    6b50:      	lsl	w8, w3, #8
    6b54:      	subs	x29, x23, x8
    6b58:      	b.hs	0x6bf4 <kprobe_unwind_dotnet+0x6bf4>
    6b5c:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6b60:      	ldr	x8, [x8]
    6b64:      	ldr	w8, [x8]
    6b68:      	cbz	w8, 0x443c <kprobe_unwind_dotnet+0x443c>
    6b6c:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6b70:      	add	x8, x8, #0x0
    6b74:      	add	x0, sp, #0x20
    6b78:      	ldp	x9, x10, [x8, #0x10]
    6b7c:      	mov	w1, #0x2e               // =46
    6b80:      	stp	x9, x10, [sp, #0x30]
    6b84:      	ldr	x9, [x8, #0x20]
    6b88:      	add	x10, sp, #0x20
    6b8c:      	str	x9, [sp, #0x40]
    6b90:      	ldur	x9, [x8, #0x26]
    6b94:      	stur	x9, [sp, #0x46]
    6b98:      	ldp	x9, x8, [x8]
    6b9c:      	stp	x9, x8, [sp, #0x20]
    6ba0:      	mov	w8, #0x2e               // =46
    6ba4:      	mov	w9, #0x6                // =6
    6ba8:      	blr	x9
    6bac:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6bb0:      	ldr	x8, [x8]
    6bb4:      	ldr	w8, [x8]
    6bb8:      	cbz	w8, 0x443c <kprobe_unwind_dotnet+0x443c>
    6bbc:      	mov	w8, #0x646e             // =25710
    6bc0:      	add	x10, sp, #0x20
    6bc4:      	add	x0, sp, #0x20
    6bc8:      	mov	w1, #0x13               // =19
    6bcc:      	movk	w8, #0xa, lsl #16
    6bd0:      	stur	w8, [sp, #0x2f]
    6bd4:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6bd8:      	add	x8, x8, #0x0
    6bdc:      	ldp	x9, x8, [x8]
    6be0:      	stp	x9, x8, [sp, #0x20]
    6be4:      	mov	w8, #0x13               // =19
    6be8:      	mov	w9, #0x6                // =6
    6bec:      	blr	x9
    6bf0:      	b	0x443c <kprobe_unwind_dotnet+0x443c>
    6bf4:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6bf8:      	ldr	x8, [x8]
    6bfc:      	ldr	w8, [x8]
    6c00:      	cbnz	w8, 0x6ce8 <kprobe_unwind_dotnet+0x6ce8>
    6c04:      	cbnz	w25, 0x44b0 <kprobe_unwind_dotnet+0x44b0>
    6c08:      	mov	w8, #0x5f               // =95
    6c0c:      	adrp	x0, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6c10:      	add	x9, sp, #0x8c
    6c14:      	str	w8, [sp, #0x8c]
    6c18:      	mov	w8, #0x1                // =1
    6c1c:      	add	x1, sp, #0x8c
    6c20:      	ldr	x0, [x0]
    6c24:      	blr	x8
    6c28:      	cbz	x0, 0x6c3c <kprobe_unwind_dotnet+0x6c3c>
    6c2c:      	ldr	x8, [x0]
    6c30:      	add	x8, x8, #0x1
    6c34:      	str	x8, [x0]
    6c38:      	b	0x6c90 <kprobe_unwind_dotnet+0x6c90>
    6c3c:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6c40:      	ldr	x8, [x8]
    6c44:      	ldr	w8, [x8]
    6c48:      	cbz	w8, 0x6c90 <kprobe_unwind_dotnet+0x6c90>
    6c4c:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6c50:      	add	x8, x8, #0x0
    6c54:      	add	x0, sp, #0x20
    6c58:      	ldp	x9, x10, [x8, #0x10]
    6c5c:      	mov	w1, #0x2e               // =46
    6c60:      	stp	x9, x10, [sp, #0x30]
    6c64:      	ldr	x9, [x8, #0x20]
    6c68:      	add	x10, sp, #0x20
    6c6c:      	str	x9, [sp, #0x40]
    6c70:      	ldur	x9, [x8, #0x26]
    6c74:      	stur	x9, [sp, #0x46]
    6c78:      	ldp	x9, x8, [x8]
    6c7c:      	stp	x9, x8, [sp, #0x20]
    6c80:      	mov	w8, #0x2e               // =46
    6c84:      	mov	w9, #0x6                // =6
    6c88:      	ldr	w2, [sp, #0x8c]
    6c8c:      	blr	x9
    6c90:      	mov	w2, #0x1773             // =6003
    6c94:      	mov	w22, #0x1               // =1
    6c98:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6c9c:      	ldr	x8, [x8]
    6ca0:      	ldr	w8, [x8]
    6ca4:      	cbz	w8, 0x44f0 <kprobe_unwind_dotnet+0x44f0>
    6ca8:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6cac:      	add	x8, x8, #0x0
    6cb0:      	add	x0, sp, #0x20
    6cb4:      	ldp	x9, x10, [x8, #0x10]
    6cb8:      	mov	w1, #0x28               // =40
    6cbc:      	stp	x9, x10, [sp, #0x30]
    6cc0:      	ldr	x9, [x8, #0x20]
    6cc4:      	add	x10, sp, #0x20
    6cc8:      	str	x9, [sp, #0x40]
    6ccc:      	ldp	x8, x9, [x8]
    6cd0:      	stp	x8, x9, [sp, #0x20]
    6cd4:      	mov	w8, #0x28               // =40
    6cd8:      	mov	w9, #0x6                // =6
    6cdc:      	blr	x9
    6ce0:      	cbnz	w22, 0x44f4 <kprobe_unwind_dotnet+0x44f4>
    6ce4:      	b	0x621c <kprobe_unwind_dotnet+0x621c>
    6ce8:      	mov	w8, #0x7825             // =30757
    6cec:      	add	x0, sp, #0x20
    6cf0:      	mov	w1, #0x3c               // =60
    6cf4:      	mov	x2, x29
    6cf8:      	mov	w4, w25
    6cfc:      	movk	w8, #0xa, lsl #16
    6d00:      	str	w8, [sp, #0x58]
    6d04:      	adrp	x8, 0x6000 <kprobe_unwind_dotnet+0x6000>
    6d08:      	add	x8, x8, #0x0
    6d0c:      	ldp	x9, x10, [x8, #0x20]
    6d10:      	stp	x9, x10, [sp, #0x40]
    6d14:      	ldr	x9, [x8, #0x30]
    6d18:      	str	x9, [sp, #0x50]
    6d1c:      	ldp	x9, x10, [x8]
    6d20:      	stp	x9, x10, [sp, #0x20]
    6d24:      	add	x10, sp, #0x20
    6d28:      	ldp	x8, x9, [x8, #0x10]
    6d2c:      	stp	x8, x9, [sp, #0x30]
    6d30:      	mov	w8, #0x3c               // =60
    6d34:      	mov	w9, #0x6                // =6
    6d38:      	blr	x9
    6d3c:      	cbnz	w25, 0x44b0 <kprobe_unwind_dotnet+0x44b0>
    6d40:      	b	0x6c08 <kprobe_unwind_dotnet+0x6c08>
