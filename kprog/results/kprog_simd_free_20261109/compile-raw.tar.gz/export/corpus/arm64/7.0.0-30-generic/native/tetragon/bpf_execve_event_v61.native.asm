
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_execve_event_v61.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <do_str>:
       0:      	sub	sp, sp, #0x60
       4:      	str	x29, [sp, #0x10]
       8:      	stp	x30, x25, [sp, #0x20]
       c:      	stp	x24, x23, [sp, #0x30]
      10:      	stp	x22, x21, [sp, #0x40]
      14:      	stp	x20, x19, [sp, #0x50]
      18:      	add	x21, x1, #0x20
      1c:      	mov	w8, #0x7fdf             // =32735
      20:      	mov	w9, #0x2d               // =45
      24:      	mov	x19, x1
      28:      	mov	x20, x0
      2c:      	mov	w1, #0x7fdf             // =32735
      30:      	mov	x23, x2
      34:      	mov	x0, x21
      38:      	blr	x9
      3c:      	tbnz	x0, #0x3f, 0x434 <do_str+0x434>
      40:      	cbz	x0, 0x434 <do_str+0x434>
      44:      	add	w8, w0, #0x1f
      48:      	str	wzr, [sp, #0xc]
      4c:      	adrp	x22, 0x0 <do_str>
      50:      	add	x9, sp, #0xc
      54:      	mov	x29, x0
      58:      	sub	x25, x0, #0x1
      5c:      	add	x1, sp, #0xc
      60:      	and	x24, x8, #0x7fff
      64:      	str	w24, [x19, #0x4]
      68:      	mov	w8, #0x1                // =1
      6c:      	ldr	x22, [x22]
      70:      	mov	x0, x22
      74:      	blr	x8
      78:      	cbz	x0, 0xfc <do_str+0xfc>
      7c:      	ldrb	w8, [x0, #0x28]
      80:      	cbz	w8, 0xfc <do_str+0xfc>
      84:      	adrp	x1, 0x0 <do_str>
      88:      	mov	w8, #-0x1               // =-1
      8c:      	mov	w9, #0x19               // =25
      90:      	ldr	x1, [x1]
      94:      	mov	x0, x20
      98:      	mov	w2, #-0x1               // =-1
      9c:      	mov	x3, x19
      a0:      	mov	x4, x24
      a4:      	blr	x9
      a8:      	tbz	x0, #0x3f, 0x230 <do_str+0x230>
      ac:      	mov	x24, x0
      b0:      	str	wzr, [sp, #0x1c]
      b4:      	adrp	x0, 0x0 <do_str>
      b8:      	mov	w8, #0x1                // =1
      bc:      	ldr	x0, [x0]
      c0:      	add	x9, sp, #0x1c
      c4:      	add	x1, sp, #0x1c
      c8:      	blr	x8
      cc:      	cbz	x0, 0x230 <do_str+0x230>
      d0:      	mov	x8, x24
      d4:      	cmn	x24, #0xc
      d8:      	b.gt	0x18c <do_str+0x18c>
      dc:      	cmn	x8, #0x1c
      e0:      	b.eq	0x1f4 <do_str+0x1f4>
      e4:      	cmn	x8, #0x16
      e8:      	b.eq	0x20c <do_str+0x20c>
      ec:      	cmn	x8, #0x10
      f0:      	b.ne	0x204 <do_str+0x204>
      f4:      	add	x8, x0, #0x558
      f8:      	b	0x220 <do_str+0x220>
      fc:      	adrp	x0, 0x0 <do_str>
     100:      	mov	x3, xzr
     104:      	mov	w8, #0x82               // =130
     108:      	ldr	x0, [x0]
     10c:      	mov	x1, x19
     110:      	mov	x2, x24
     114:      	blr	x8
     118:      	tbz	x0, #0x3f, 0x230 <do_str+0x230>
     11c:      	mov	x24, x0
     120:      	str	wzr, [sp, #0x18]
     124:      	adrp	x0, 0x0 <do_str>
     128:      	mov	w8, #0x1                // =1
     12c:      	ldr	x0, [x0]
     130:      	add	x9, sp, #0x18
     134:      	add	x1, sp, #0x18
     138:      	blr	x8
     13c:      	cbz	x0, 0x230 <do_str+0x230>
     140:      	mov	x8, x24
     144:      	cmn	x24, #0xc
     148:      	b.gt	0x16c <do_str+0x16c>
     14c:      	cmn	x8, #0x1c
     150:      	b.eq	0x1ac <do_str+0x1ac>
     154:      	cmn	x8, #0x16
     158:      	b.eq	0x1c4 <do_str+0x1c4>
     15c:      	cmn	x8, #0x10
     160:      	b.ne	0x1bc <do_str+0x1bc>
     164:      	add	x8, x0, #0x558
     168:      	b	0x1e0 <do_str+0x1e0>
     16c:      	cmn	x8, #0xb
     170:      	b.eq	0x1b4 <do_str+0x1b4>
     174:      	cmn	x8, #0x7
     178:      	b.eq	0x1cc <do_str+0x1cc>
     17c:      	cmn	x8, #0x2
     180:      	b.ne	0x1bc <do_str+0x1bc>
     184:      	add	x8, x0, #0x548
     188:      	b	0x1e0 <do_str+0x1e0>
     18c:      	cmn	x8, #0xb
     190:      	b.eq	0x1fc <do_str+0x1fc>
     194:      	cmn	x8, #0x7
     198:      	b.eq	0x214 <do_str+0x214>
     19c:      	cmn	x8, #0x2
     1a0:      	b.ne	0x204 <do_str+0x204>
     1a4:      	add	x8, x0, #0x548
     1a8:      	b	0x220 <do_str+0x220>
     1ac:      	add	x8, x0, #0x568
     1b0:      	b	0x1e0 <do_str+0x1e0>
     1b4:      	add	x8, x0, #0x570
     1b8:      	b	0x1e0 <do_str+0x1e0>
     1bc:      	add	x8, x0, #0x540
     1c0:      	b	0x1e0 <do_str+0x1e0>
     1c4:      	add	x8, x0, #0x560
     1c8:      	b	0x1e0 <do_str+0x1e0>
     1cc:      	add	x8, x0, #0x550
     1d0:      	nop
     1d4:      	nop
     1d8:      	nop
     1dc:      	nop
     1e0:      	ldaxr	x9, [x8]
     1e4:      	add	x9, x9, #0x1
     1e8:      	stlxr	w10, x9, [x8]
     1ec:      	cbnz	w10, 0x1e0 <do_str+0x1e0>
     1f0:      	b	0x230 <do_str+0x230>
     1f4:      	add	x8, x0, #0x568
     1f8:      	b	0x220 <do_str+0x220>
     1fc:      	add	x8, x0, #0x570
     200:      	b	0x220 <do_str+0x220>
     204:      	add	x8, x0, #0x540
     208:      	b	0x220 <do_str+0x220>
     20c:      	add	x8, x0, #0x560
     210:      	b	0x220 <do_str+0x220>
     214:      	add	x8, x0, #0x550
     218:      	nop
     21c:      	nop
     220:      	ldaxr	x9, [x8]
     224:      	add	x9, x9, #0x1
     228:      	stlxr	w10, x9, [x8]
     22c:      	cbnz	w10, 0x220 <do_str+0x220>
     230:      	mov	w8, #0x7fdf             // =32735
     234:      	mov	x0, x25
     238:      	cmp	x29, x8
     23c:      	b.ne	0x434 <do_str+0x434>
     240:      	add	x2, x25, x23
     244:      	mov	w8, #0x7fdf             // =32735
     248:      	mov	w9, #0x2d               // =45
     24c:      	mov	x0, x21
     250:      	mov	w1, #0x7fdf             // =32735
     254:      	blr	x9
     258:      	tbnz	x0, #0x3f, 0x434 <do_str+0x434>
     25c:      	cbz	x0, 0x37c <do_str+0x37c>
     260:      	add	w8, w0, #0x1f
     264:      	str	wzr, [sp, #0xc]
     268:      	add	x9, sp, #0xc
     26c:      	sub	x23, x0, #0x1
     270:      	add	x1, sp, #0xc
     274:      	mov	x0, x22
     278:      	and	x21, x8, #0x7fff
     27c:      	str	w21, [x19, #0x4]
     280:      	mov	w8, #0x1                // =1
     284:      	blr	x8
     288:      	cbz	x0, 0x30c <do_str+0x30c>
     28c:      	ldrb	w8, [x0, #0x28]
     290:      	cbz	w8, 0x30c <do_str+0x30c>
     294:      	adrp	x1, 0x0 <do_str>
     298:      	mov	w8, #-0x1               // =-1
     29c:      	mov	w9, #0x19               // =25
     2a0:      	ldr	x1, [x1]
     2a4:      	mov	x0, x20
     2a8:      	mov	w2, #-0x1               // =-1
     2ac:      	mov	x3, x19
     2b0:      	mov	x4, x21
     2b4:      	blr	x9
     2b8:      	tbz	x0, #0x3f, 0x430 <do_str+0x430>
     2bc:      	mov	x19, x0
     2c0:      	str	wzr, [sp, #0x1c]
     2c4:      	adrp	x0, 0x0 <do_str>
     2c8:      	mov	w8, #0x1                // =1
     2cc:      	ldr	x0, [x0]
     2d0:      	add	x9, sp, #0x1c
     2d4:      	add	x1, sp, #0x1c
     2d8:      	blr	x8
     2dc:      	cbz	x0, 0x430 <do_str+0x430>
     2e0:      	mov	x8, x19
     2e4:      	cmn	x19, #0xc
     2e8:      	b.gt	0x3a4 <do_str+0x3a4>
     2ec:      	cmn	x8, #0x1c
     2f0:      	b.eq	0x3fc <do_str+0x3fc>
     2f4:      	cmn	x8, #0x16
     2f8:      	b.eq	0x414 <do_str+0x414>
     2fc:      	cmn	x8, #0x10
     300:      	b.ne	0x40c <do_str+0x40c>
     304:      	add	x8, x0, #0x558
     308:      	b	0x420 <do_str+0x420>
     30c:      	adrp	x0, 0x0 <do_str>
     310:      	mov	x3, xzr
     314:      	mov	w8, #0x82               // =130
     318:      	ldr	x0, [x0]
     31c:      	mov	x1, x19
     320:      	mov	x2, x21
     324:      	blr	x8
     328:      	tbz	x0, #0x3f, 0x430 <do_str+0x430>
     32c:      	mov	x19, x0
     330:      	str	wzr, [sp, #0x18]
     334:      	adrp	x0, 0x0 <do_str>
     338:      	mov	w8, #0x1                // =1
     33c:      	ldr	x0, [x0]
     340:      	add	x9, sp, #0x18
     344:      	add	x1, sp, #0x18
     348:      	blr	x8
     34c:      	cbz	x0, 0x430 <do_str+0x430>
     350:      	mov	x8, x19
     354:      	cmn	x19, #0xc
     358:      	b.gt	0x384 <do_str+0x384>
     35c:      	cmn	x8, #0x1c
     360:      	b.eq	0x3c4 <do_str+0x3c4>
     364:      	cmn	x8, #0x16
     368:      	b.eq	0x3dc <do_str+0x3dc>
     36c:      	cmn	x8, #0x10
     370:      	b.ne	0x3d4 <do_str+0x3d4>
     374:      	add	x8, x0, #0x558
     378:      	b	0x3e8 <do_str+0x3e8>
     37c:      	mov	w0, #0x7fde             // =32734
     380:      	b	0x434 <do_str+0x434>
     384:      	cmn	x8, #0xb
     388:      	b.eq	0x3cc <do_str+0x3cc>
     38c:      	cmn	x8, #0x7
     390:      	b.eq	0x3e4 <do_str+0x3e4>
     394:      	cmn	x8, #0x2
     398:      	b.ne	0x3d4 <do_str+0x3d4>
     39c:      	add	x8, x0, #0x548
     3a0:      	b	0x3e8 <do_str+0x3e8>
     3a4:      	cmn	x8, #0xb
     3a8:      	b.eq	0x404 <do_str+0x404>
     3ac:      	cmn	x8, #0x7
     3b0:      	b.eq	0x41c <do_str+0x41c>
     3b4:      	cmn	x8, #0x2
     3b8:      	b.ne	0x40c <do_str+0x40c>
     3bc:      	add	x8, x0, #0x548
     3c0:      	b	0x420 <do_str+0x420>
     3c4:      	add	x8, x0, #0x568
     3c8:      	b	0x3e8 <do_str+0x3e8>
     3cc:      	add	x8, x0, #0x570
     3d0:      	b	0x3e8 <do_str+0x3e8>
     3d4:      	add	x8, x0, #0x540
     3d8:      	b	0x3e8 <do_str+0x3e8>
     3dc:      	add	x8, x0, #0x560
     3e0:      	b	0x3e8 <do_str+0x3e8>
     3e4:      	add	x8, x0, #0x550
     3e8:      	ldaxr	x9, [x8]
     3ec:      	add	x9, x9, #0x1
     3f0:      	stlxr	w10, x9, [x8]
     3f4:      	cbnz	w10, 0x3e8 <do_str+0x3e8>
     3f8:      	b	0x430 <do_str+0x430>
     3fc:      	add	x8, x0, #0x568
     400:      	b	0x420 <do_str+0x420>
     404:      	add	x8, x0, #0x570
     408:      	b	0x420 <do_str+0x420>
     40c:      	add	x8, x0, #0x540
     410:      	b	0x420 <do_str+0x420>
     414:      	add	x8, x0, #0x560
     418:      	b	0x420 <do_str+0x420>
     41c:      	add	x8, x0, #0x550
     420:      	ldaxr	x9, [x8]
     424:      	add	x9, x9, #0x1
     428:      	stlxr	w10, x9, [x8]
     42c:      	cbnz	w10, 0x420 <do_str+0x420>
     430:      	add	x0, x23, x25
     434:      	ldp	x20, x19, [sp, #0x50]
     438:      	ldr	x29, [sp, #0x10]
     43c:      	ldp	x22, x21, [sp, #0x40]
     440:      	ldp	x24, x23, [sp, #0x30]
     444:      	ldp	x30, x25, [sp, #0x20]
     448:      	add	sp, sp, #0x60
     44c:      	ret

0000000000000450 <do_bytes>:
     450:      	sub	sp, sp, #0x40
     454:      	stp	x30, x23, [sp, #0x10]
     458:      	stp	x22, x21, [sp, #0x20]
     45c:      	stp	x20, x19, [sp, #0x30]
     460:      	mov	x19, x3
     464:      	mov	x21, x2
     468:      	mov	x20, x1
     46c:      	mov	x22, x0
     470:      	bl	0x690 <__do_bytes>
     474:      	tbnz	w0, #0x1f, 0x5d8 <do_bytes+0x188>
     478:      	and	x23, x0, #0x7fffffff
     47c:      	subs	x3, x19, x23
     480:      	b.eq	0x678 <do_bytes+0x228>
     484:      	add	x2, x23, x21
     488:      	mov	x0, x22
     48c:      	mov	x1, x20
     490:      	bl	0x690 <__do_bytes>
     494:      	tbnz	w0, #0x1f, 0x5d8 <do_bytes+0x188>
     498:      	and	x8, x0, #0x7fffffff
     49c:      	add	x23, x8, x23
     4a0:      	subs	x3, x19, x23
     4a4:      	b.eq	0x678 <do_bytes+0x228>
     4a8:      	add	x2, x23, x21
     4ac:      	mov	x0, x22
     4b0:      	mov	x1, x20
     4b4:      	bl	0x690 <__do_bytes>
     4b8:      	tbnz	w0, #0x1f, 0x5d8 <do_bytes+0x188>
     4bc:      	and	x8, x0, #0x7fffffff
     4c0:      	add	x23, x8, x23
     4c4:      	subs	x3, x19, x23
     4c8:      	b.eq	0x678 <do_bytes+0x228>
     4cc:      	add	x2, x23, x21
     4d0:      	mov	x0, x22
     4d4:      	mov	x1, x20
     4d8:      	bl	0x690 <__do_bytes>
     4dc:      	tbnz	w0, #0x1f, 0x5d8 <do_bytes+0x188>
     4e0:      	and	x8, x0, #0x7fffffff
     4e4:      	add	x23, x8, x23
     4e8:      	subs	x3, x19, x23
     4ec:      	b.eq	0x678 <do_bytes+0x228>
     4f0:      	add	x2, x23, x21
     4f4:      	mov	x0, x22
     4f8:      	mov	x1, x20
     4fc:      	bl	0x690 <__do_bytes>
     500:      	tbnz	w0, #0x1f, 0x5d8 <do_bytes+0x188>
     504:      	and	x8, x0, #0x7fffffff
     508:      	add	x23, x8, x23
     50c:      	subs	x3, x19, x23
     510:      	b.eq	0x678 <do_bytes+0x228>
     514:      	add	x2, x23, x21
     518:      	mov	x0, x22
     51c:      	mov	x1, x20
     520:      	bl	0x690 <__do_bytes>
     524:      	tbnz	w0, #0x1f, 0x5d8 <do_bytes+0x188>
     528:      	and	x8, x0, #0x7fffffff
     52c:      	add	x23, x8, x23
     530:      	subs	x3, x19, x23
     534:      	b.eq	0x678 <do_bytes+0x228>
     538:      	add	x2, x23, x21
     53c:      	mov	x0, x22
     540:      	mov	x1, x20
     544:      	bl	0x690 <__do_bytes>
     548:      	tbnz	w0, #0x1f, 0x5d8 <do_bytes+0x188>
     54c:      	and	x8, x0, #0x7fffffff
     550:      	add	x23, x8, x23
     554:      	subs	x3, x19, x23
     558:      	b.eq	0x678 <do_bytes+0x228>
     55c:      	add	x2, x23, x21
     560:      	mov	x0, x22
     564:      	mov	x1, x20
     568:      	bl	0x690 <__do_bytes>
     56c:      	tbnz	w0, #0x1f, 0x5d8 <do_bytes+0x188>
     570:      	and	x8, x0, #0x7fffffff
     574:      	add	x23, x8, x23
     578:      	subs	x3, x19, x23
     57c:      	b.eq	0x678 <do_bytes+0x228>
     580:      	add	x2, x23, x21
     584:      	mov	x0, x22
     588:      	mov	x1, x20
     58c:      	bl	0x690 <__do_bytes>
     590:      	tbnz	w0, #0x1f, 0x5d8 <do_bytes+0x188>
     594:      	and	x8, x0, #0x7fffffff
     598:      	add	x23, x8, x23
     59c:      	subs	x3, x19, x23
     5a0:      	b.eq	0x678 <do_bytes+0x228>
     5a4:      	add	x2, x23, x21
     5a8:      	mov	x0, x22
     5ac:      	mov	x1, x20
     5b0:      	bl	0x690 <__do_bytes>
     5b4:      	tbnz	w0, #0x1f, 0x5d8 <do_bytes+0x188>
     5b8:      	and	x8, x0, #0x7fffffff
     5bc:      	add	x19, x8, x23
     5c0:      	mov	x0, x19
     5c4:      	ldp	x20, x19, [sp, #0x30]
     5c8:      	ldp	x22, x21, [sp, #0x20]
     5cc:      	ldp	x30, x23, [sp, #0x10]
     5d0:      	add	sp, sp, #0x40
     5d4:      	ret
     5d8:      	sxtw	x19, w0
     5dc:      	str	wzr, [sp, #0xc]
     5e0:      	adrp	x0, 0x0 <do_str>
     5e4:      	mov	w8, #0x1                // =1
     5e8:      	ldr	x0, [x0]
     5ec:      	add	x9, sp, #0xc
     5f0:      	add	x1, sp, #0xc
     5f4:      	blr	x8
     5f8:      	cbz	x0, 0x678 <do_bytes+0x228>
     5fc:      	cmn	x19, #0xc
     600:      	b.gt	0x624 <do_bytes+0x1d4>
     604:      	cmn	x19, #0x1c
     608:      	b.eq	0x644 <do_bytes+0x1f4>
     60c:      	cmn	x19, #0x16
     610:      	b.eq	0x65c <do_bytes+0x20c>
     614:      	cmn	x19, #0x10
     618:      	b.ne	0x654 <do_bytes+0x204>
     61c:      	add	x8, x0, #0x558
     620:      	b	0x668 <do_bytes+0x218>
     624:      	cmn	x19, #0xb
     628:      	b.eq	0x64c <do_bytes+0x1fc>
     62c:      	cmn	x19, #0x7
     630:      	b.eq	0x664 <do_bytes+0x214>
     634:      	cmn	x19, #0x2
     638:      	b.ne	0x654 <do_bytes+0x204>
     63c:      	add	x8, x0, #0x548
     640:      	b	0x668 <do_bytes+0x218>
     644:      	add	x8, x0, #0x568
     648:      	b	0x668 <do_bytes+0x218>
     64c:      	add	x8, x0, #0x570
     650:      	b	0x668 <do_bytes+0x218>
     654:      	add	x8, x0, #0x540
     658:      	b	0x668 <do_bytes+0x218>
     65c:      	add	x8, x0, #0x560
     660:      	b	0x668 <do_bytes+0x218>
     664:      	add	x8, x0, #0x550
     668:      	ldaxr	x9, [x8]
     66c:      	add	x9, x9, #0x1
     670:      	stlxr	w10, x9, [x8]
     674:      	cbnz	w10, 0x668 <do_bytes+0x218>
     678:      	mov	x0, x19
     67c:      	ldp	x20, x19, [sp, #0x30]
     680:      	ldp	x22, x21, [sp, #0x20]
     684:      	ldp	x30, x23, [sp, #0x10]
     688:      	add	sp, sp, #0x40
     68c:      	ret

0000000000000690 <__do_bytes>:
     690:      	str	x30, [sp, #-0x30]!
     694:      	stp	x22, x21, [sp, #0x10]
     698:      	stp	x20, x19, [sp, #0x20]
     69c:      	tbnz	x3, #0x3f, 0x734 <__do_bytes+0xa4>
     6a0:      	mov	w8, #0x7fe0             // =32736
     6a4:      	mov	x22, x0
     6a8:      	add	x0, x1, #0x20
     6ac:      	mov	x20, x1
     6b0:      	cmp	x3, x8
     6b4:      	csel	x19, x3, x8, lo
     6b8:      	mov	w8, #0x4                // =4
     6bc:      	mov	w1, w19
     6c0:      	blr	x8
     6c4:      	tbnz	w0, #0x1f, 0x76c <__do_bytes+0xdc>
     6c8:      	add	w21, w19, #0x20
     6cc:      	str	wzr, [sp, #0xc]
     6d0:      	adrp	x0, 0x0 <do_str>
     6d4:      	mov	w8, #0x1                // =1
     6d8:      	str	w21, [x20, #0x4]
     6dc:      	add	x9, sp, #0xc
     6e0:      	add	x1, sp, #0xc
     6e4:      	ldr	x0, [x0]
     6e8:      	blr	x8
     6ec:      	cbz	x0, 0x74c <__do_bytes+0xbc>
     6f0:      	ldrb	w8, [x0, #0x28]
     6f4:      	cbz	w8, 0x74c <__do_bytes+0xbc>
     6f8:      	adrp	x1, 0x0 <do_str>
     6fc:      	mov	w8, #-0x1               // =-1
     700:      	mov	w9, #0x19               // =25
     704:      	ldr	x1, [x1]
     708:      	mov	x0, x22
     70c:      	mov	w2, #-0x1               // =-1
     710:      	mov	x3, x20
     714:      	mov	x4, x21
     718:      	blr	x9
     71c:      	tbnz	w0, #0x1f, 0x76c <__do_bytes+0xdc>
     720:      	mov	x0, x19
     724:      	ldp	x20, x19, [sp, #0x20]
     728:      	ldp	x22, x21, [sp, #0x10]
     72c:      	ldr	x30, [sp], #0x30
     730:      	ret
     734:      	mov	x19, #-0x1              // =-1
     738:      	mov	x0, x19
     73c:      	ldp	x20, x19, [sp, #0x20]
     740:      	ldp	x22, x21, [sp, #0x10]
     744:      	ldr	x30, [sp], #0x30
     748:      	ret
     74c:      	adrp	x0, 0x0 <do_str>
     750:      	mov	x3, xzr
     754:      	mov	w8, #0x82               // =130
     758:      	ldr	x0, [x0]
     75c:      	mov	x1, x20
     760:      	mov	x2, x21
     764:      	blr	x8
     768:      	tbz	w0, #0x1f, 0x720 <__do_bytes+0x90>
     76c:      	sxtw	x19, w0
     770:      	mov	x0, x19
     774:      	ldp	x20, x19, [sp, #0x20]
     778:      	ldp	x22, x21, [sp, #0x10]
     77c:      	ldr	x30, [sp], #0x30
     780:      	ret

Disassembly of section tracepoint:

0000000000000000 <execve_rate>:
       0:      	sub	sp, sp, #0x90
       4:      	str	x30, [sp, #0x50]
       8:      	stp	x24, x23, [sp, #0x60]
       c:      	stp	x22, x21, [sp, #0x70]
      10:      	stp	x20, x19, [sp, #0x80]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0xc]
      1c:      	adrp	x0, 0x0 <execve_rate>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0xc
      2c:      	add	x1, sp, #0xc
      30:      	blr	x8
      34:      	cbz	x0, 0x37c <execve_rate+0x37c>
      38:      	ldr	x23, [x0, #0x8]
      3c:      	ldr	x8, [x0, #0x10]!
      40:      	add	x9, sp, #0x3c
      44:      	add	x1, sp, #0x3c
      48:      	mov	x20, x0
      4c:      	str	wzr, [sp, #0x3c]
      50:      	adrp	x0, 0x0 <execve_rate>
      54:      	str	x8, [sp, #0x40]
      58:      	mov	w8, #0x1                // =1
      5c:      	ldr	x0, [x0]
      60:      	blr	x8
      64:      	cbz	x0, 0x360 <execve_rate+0x360>
      68:      	ldr	x22, [x0, #0x8]
      6c:      	cbz	x22, 0x360 <execve_rate+0x360>
      70:      	adrp	x21, 0x0 <execve_rate>
      74:      	mov	w8, #0x1                // =1
      78:      	add	x9, sp, #0x40
      7c:      	ldr	x21, [x21]
      80:      	mov	x24, x0
      84:      	add	x1, sp, #0x40
      88:      	mov	x0, x21
      8c:      	blr	x8
      90:      	cbz	x0, 0xbc <execve_rate+0xbc>
      94:      	ldr	x8, [x0, #0x10]
      98:      	sub	x9, x23, x8
      9c:      	cmp	x9, x22
      a0:      	b.ls	0xf8 <execve_rate+0xf8>
      a4:      	cmp	x9, x22, lsl #1
      a8:      	b.ls	0x100 <execve_rate+0x100>
      ac:      	udiv	x8, x23, x22
      b0:      	mov	x9, xzr
      b4:      	mul	x8, x8, x22
      b8:      	b	0x108 <execve_rate+0x108>
      bc:      	mov	w8, #0x1                // =1
      c0:      	str	xzr, [sp, #0x30]
      c4:      	mov	x3, xzr
      c8:      	add	x9, sp, #0x40
      cc:      	stp	x8, xzr, [sp, #0x10]
      d0:      	udiv	x8, x23, x22
      d4:      	add	x10, sp, #0x10
      d8:      	add	x1, sp, #0x40
      dc:      	add	x2, sp, #0x10
      e0:      	mov	x0, x21
      e4:      	mul	x8, x8, x22
      e8:      	stp	x8, xzr, [sp, #0x20]
      ec:      	mov	w8, #0x2                // =2
      f0:      	blr	x8
      f4:      	b	0x360 <execve_rate+0x360>
      f8:      	ldp	x10, x9, [x0]
      fc:      	b	0x110 <execve_rate+0x110>
     100:      	ldr	x9, [x0]
     104:      	add	x8, x8, x22
     108:      	mov	x10, xzr
     10c:      	stp	x9, x8, [x0, #0x8]
     110:      	sub	x11, x22, x23
     114:      	add	x10, x10, #0x1
     118:      	add	x8, x11, x8
     11c:      	str	x10, [x0]
     120:      	mul	x8, x8, x9
     124:      	ldr	x9, [x0, #0x20]
     128:      	udiv	x8, x8, x22
     12c:      	add	x8, x8, x10
     130:      	str	x8, [x0, #0x18]
     134:      	cbnz	x9, 0x37c <execve_rate+0x37c>
     138:      	ldr	x9, [x24]
     13c:      	cmp	x8, x9
     140:      	b.lo	0x360 <execve_rate+0x360>
     144:      	mov	x22, x0
     148:      	str	x23, [x0, #0x20]
     14c:      	str	wzr, [sp, #0x58]
     150:      	adrp	x0, 0x0 <execve_rate>
     154:      	mov	w8, #0x1                // =1
     158:      	add	x9, sp, #0x58
     15c:      	ldr	x0, [x0]
     160:      	add	x1, sp, #0x4c
     164:      	str	wzr, [sp, #0x4c]
     168:      	blr	x8
     16c:      	cbz	x0, 0x358 <execve_rate+0x358>
     170:      	mov	w8, #0xa0               // =160
     174:      	mov	x21, x0
     178:      	str	x23, [x0, #0x8]
     17c:      	mov	x1, x20
     180:      	str	w8, [x0, #0x4]
     184:      	mov	w8, #0x1b               // =27
     188:      	mov	w2, #0x90               // =144
     18c:      	strh	w8, [x0], #0x10
     190:      	bl	0x190 <execve_rate+0x190>
     194:      	str	wzr, [sp, #0x5c]
     198:      	adrp	x0, 0x0 <execve_rate>
     19c:      	mov	w8, #0x1                // =1
     1a0:      	add	x9, sp, #0x5c
     1a4:      	ldr	x0, [x0]
     1a8:      	add	x1, sp, #0x5c
     1ac:      	blr	x8
     1b0:      	cbz	x0, 0x238 <execve_rate+0x238>
     1b4:      	ldrb	w8, [x0, #0x28]
     1b8:      	cbz	w8, 0x238 <execve_rate+0x238>
     1bc:      	adrp	x1, 0x0 <execve_rate>
     1c0:      	mov	w8, #-0x1               // =-1
     1c4:      	mov	w9, #0xa0               // =160
     1c8:      	ldr	x1, [x1]
     1cc:      	mov	w10, #0x19              // =25
     1d0:      	mov	x0, x19
     1d4:      	mov	w2, #-0x1               // =-1
     1d8:      	mov	x3, x21
     1dc:      	mov	w4, #0xa0               // =160
     1e0:      	blr	x10
     1e4:      	tbz	x0, #0x3f, 0x358 <execve_rate+0x358>
     1e8:      	mov	x20, x0
     1ec:      	str	wzr, [sp, #0x10]
     1f0:      	adrp	x0, 0x0 <execve_rate>
     1f4:      	mov	w8, #0x1                // =1
     1f8:      	ldr	x0, [x0]
     1fc:      	add	x9, sp, #0x10
     200:      	add	x1, sp, #0x10
     204:      	blr	x8
     208:      	cbz	x0, 0x358 <execve_rate+0x358>
     20c:      	mov	x8, x20
     210:      	cmn	x20, #0xc
     214:      	b.gt	0x2cc <execve_rate+0x2cc>
     218:      	cmn	x8, #0x1c
     21c:      	b.eq	0x324 <execve_rate+0x324>
     220:      	cmn	x8, #0x16
     224:      	b.eq	0x33c <execve_rate+0x33c>
     228:      	cmn	x8, #0x10
     22c:      	b.ne	0x334 <execve_rate+0x334>
     230:      	add	x8, x0, #0x600
     234:      	b	0x348 <execve_rate+0x348>
     238:      	adrp	x0, 0x0 <execve_rate>
     23c:      	mov	x3, xzr
     240:      	mov	w8, #0xa0               // =160
     244:      	ldr	x0, [x0]
     248:      	mov	w9, #0x82               // =130
     24c:      	mov	x1, x21
     250:      	mov	w2, #0xa0               // =160
     254:      	blr	x9
     258:      	tbz	x0, #0x3f, 0x358 <execve_rate+0x358>
     25c:      	mov	x20, x0
     260:      	str	wzr, [sp, #0x10]
     264:      	adrp	x0, 0x0 <execve_rate>
     268:      	mov	w8, #0x1                // =1
     26c:      	ldr	x0, [x0]
     270:      	add	x9, sp, #0x10
     274:      	add	x1, sp, #0x10
     278:      	blr	x8
     27c:      	cbz	x0, 0x358 <execve_rate+0x358>
     280:      	mov	x8, x20
     284:      	cmn	x20, #0xc
     288:      	b.gt	0x2ac <execve_rate+0x2ac>
     28c:      	cmn	x8, #0x1c
     290:      	b.eq	0x2ec <execve_rate+0x2ec>
     294:      	cmn	x8, #0x16
     298:      	b.eq	0x304 <execve_rate+0x304>
     29c:      	cmn	x8, #0x10
     2a0:      	b.ne	0x2fc <execve_rate+0x2fc>
     2a4:      	add	x8, x0, #0x600
     2a8:      	b	0x310 <execve_rate+0x310>
     2ac:      	cmn	x8, #0xb
     2b0:      	b.eq	0x2f4 <execve_rate+0x2f4>
     2b4:      	cmn	x8, #0x7
     2b8:      	b.eq	0x30c <execve_rate+0x30c>
     2bc:      	cmn	x8, #0x2
     2c0:      	b.ne	0x2fc <execve_rate+0x2fc>
     2c4:      	add	x8, x0, #0x5f0
     2c8:      	b	0x310 <execve_rate+0x310>
     2cc:      	cmn	x8, #0xb
     2d0:      	b.eq	0x32c <execve_rate+0x32c>
     2d4:      	cmn	x8, #0x7
     2d8:      	b.eq	0x344 <execve_rate+0x344>
     2dc:      	cmn	x8, #0x2
     2e0:      	b.ne	0x334 <execve_rate+0x334>
     2e4:      	add	x8, x0, #0x5f0
     2e8:      	b	0x348 <execve_rate+0x348>
     2ec:      	add	x8, x0, #0x610
     2f0:      	b	0x310 <execve_rate+0x310>
     2f4:      	add	x8, x0, #0x618
     2f8:      	b	0x310 <execve_rate+0x310>
     2fc:      	add	x8, x0, #0x5e8
     300:      	b	0x310 <execve_rate+0x310>
     304:      	add	x8, x0, #0x608
     308:      	b	0x310 <execve_rate+0x310>
     30c:      	add	x8, x0, #0x5f8
     310:      	ldaxr	x9, [x8]
     314:      	add	x9, x9, #0x1
     318:      	stlxr	w10, x9, [x8]
     31c:      	cbnz	w10, 0x310 <execve_rate+0x310>
     320:      	b	0x358 <execve_rate+0x358>
     324:      	add	x8, x0, #0x610
     328:      	b	0x348 <execve_rate+0x348>
     32c:      	add	x8, x0, #0x618
     330:      	b	0x348 <execve_rate+0x348>
     334:      	add	x8, x0, #0x5e8
     338:      	b	0x348 <execve_rate+0x348>
     33c:      	add	x8, x0, #0x608
     340:      	b	0x348 <execve_rate+0x348>
     344:      	add	x8, x0, #0x5f8
     348:      	ldaxr	x9, [x8]
     34c:      	add	x9, x9, #0x1
     350:      	stlxr	w10, x9, [x8]
     354:      	cbnz	w10, 0x348 <execve_rate+0x348>
     358:      	ldr	x8, [x22, #0x20]
     35c:      	cbnz	x8, 0x37c <execve_rate+0x37c>
     360:      	adrp	x1, 0x0 <execve_rate>
     364:      	mov	w8, #0x1                // =1
     368:      	mov	w9, #0xc                // =12
     36c:      	ldr	x1, [x1]
     370:      	mov	x0, x19
     374:      	mov	w2, #0x1                // =1
     378:      	blr	x9
     37c:      	ldp	x20, x19, [sp, #0x80]
     380:      	mov	w0, wzr
     384:      	ldr	x30, [sp, #0x50]
     388:      	ldp	x22, x21, [sp, #0x70]
     38c:      	ldp	x24, x23, [sp, #0x60]
     390:      	add	sp, sp, #0x90
     394:      	ret
     398:      	nop
     39c:      	nop

00000000000003a0 <execve_send>:
     3a0:      	sub	sp, sp, #0xf0
     3a4:      	str	x29, [sp, #0xa0]
     3a8:      	stp	x30, x25, [sp, #0xb0]
     3ac:      	stp	x24, x23, [sp, #0xc0]
     3b0:      	stp	x22, x21, [sp, #0xd0]
     3b4:      	stp	x20, x19, [sp, #0xe0]
     3b8:      	mov	x19, x0
     3bc:      	str	wzr, [sp, #0x28]
     3c0:      	adrp	x0, 0x0 <execve_rate>
     3c4:      	mov	w8, #0x1                // =1
     3c8:      	ldr	x0, [x0]
     3cc:      	add	x9, sp, #0x28
     3d0:      	add	x1, sp, #0x28
     3d4:      	blr	x8
     3d8:      	cbz	x0, 0x1470 <execve_send+0x10d0>
     3dc:      	str	x19, [sp, #0x18]
     3e0:      	mov	w8, #0x23               // =35
     3e4:      	mov	x29, x0
     3e8:      	blr	x8
     3ec:      	mov	w8, #0x16c0             // =5824
     3f0:      	add	x2, x0, #0x858
     3f4:      	mov	w19, #0x8               // =8
     3f8:      	mov	w9, #0x4                // =4
     3fc:      	add	x0, sp, #0x90
     400:      	mov	w1, #0x8                // =8
     404:      	mov	w20, #0x4               // =4
     408:      	add	x21, x29, x8
     40c:      	add	x8, sp, #0x90
     410:      	blr	x9
     414:      	ldr	x8, [sp, #0x90]
     418:      	add	x9, sp, #0x40
     41c:      	add	x0, sp, #0x40
     420:      	mov	w1, #0x8                // =8
     424:      	add	x8, x8, #0x528
     428:      	ldr	x8, [sp, #0x90]
     42c:      	add	x2, x8, #0x528
     430:      	blr	x20
     434:      	str	wzr, [sp, #0x2c]
     438:      	adrp	x0, 0x0 <execve_rate>
     43c:      	ldr	x20, [sp, #0x40]
     440:      	mov	w8, #0x1                // =1
     444:      	add	x9, sp, #0x2c
     448:      	add	x1, sp, #0x2c
     44c:      	ldr	x0, [x0]
     450:      	blr	x8
     454:      	cbz	x0, 0xa90 <execve_send+0x6f0>
     458:      	mov	w8, #0x1000             // =4096
     45c:      	str	x21, [sp, #0x10]
     460:      	str	x29, [sp, #0x20]
     464:      	mov	x22, x0
     468:      	add	x19, x0, #0x1, lsl #12  // =0x1000
     46c:      	str	w8, [x29, #0x1840]
     470:      	mov	w8, #0x23               // =35
     474:      	blr	x8
     478:      	add	x2, x0, #0xb30
     47c:      	mov	w25, #0x8               // =8
     480:      	add	x8, sp, #0x30
     484:      	mov	w9, #0x4                // =4
     488:      	add	x0, sp, #0x30
     48c:      	mov	w1, #0x8                // =8
     490:      	mov	w29, #0x4               // =4
     494:      	blr	x9
     498:      	ldr	x21, [sp, #0x30]
     49c:      	add	x23, x20, #0x48
     4a0:      	add	x8, sp, #0x38
     4a4:      	mov	w9, #0x4                // =4
     4a8:      	add	x0, sp, #0x38
     4ac:      	mov	w1, #0x8                // =8
     4b0:      	mov	x2, x23
     4b4:      	blr	x9
     4b8:      	ldr	x24, [sp, #0x38]
     4bc:      	add	x8, sp, #0x40
     4c0:      	add	x0, sp, #0x40
     4c4:      	mov	w1, #0x8                // =8
     4c8:      	add	x2, x24, #0x10
     4cc:      	blr	x29
     4d0:      	ldr	x8, [sp, #0x40]
     4d4:      	cbz	x8, 0x708 <execve_send+0x368>
     4d8:      	ldr	x8, [sp, #0x20]
     4dc:      	stp	xzr, xzr, [sp, #0x40]
     4e0:      	add	x25, x21, #0x18
     4e4:      	add	x9, sp, #0x40
     4e8:      	add	x2, x21, #0x20
     4ec:      	mov	w21, #0x8               // =8
     4f0:      	stp	x22, xzr, [sp, #0x50]
     4f4:      	add	x0, sp, #0x40
     4f8:      	mov	w1, #0x8                // =8
     4fc:      	add	x24, x20, #0x40
     500:      	add	x29, x9, #0x8
     504:      	ldr	w8, [x8, #0x1840]
     508:      	stp	xzr, xzr, [sp, #0x60]
     50c:      	str	x19, [sp, #0x8]
     510:      	str	x19, [sp, #0x70]
     514:      	add	x22, x9, #0x18
     518:      	add	x20, x9, #0x20
     51c:      	mov	w19, #0x4               // =4
     520:      	strb	wzr, [sp, #0x7c]
     524:      	str	w8, [sp, #0x78]
     528:      	mov	w8, #0x4                // =4
     52c:      	blr	x8
     530:      	mov	w8, #0x4                // =4
     534:      	mov	x0, x29
     538:      	mov	w1, #0x8                // =8
     53c:      	mov	x2, x25
     540:      	blr	x8
     544:      	mov	w8, #0x4                // =4
     548:      	mov	x0, x22
     54c:      	mov	w1, #0x8                // =8
     550:      	mov	x2, x23
     554:      	blr	x8
     558:      	mov	x0, x20
     55c:      	mov	w1, #0x8                // =8
     560:      	mov	x2, x24
     564:      	blr	x19
     568:      	ldr	x8, [sp, #0x60]
     56c:      	sub	x8, x8, #0x20
     570:      	str	x8, [sp, #0x68]
     574:      	adrp	x8, 0x0 <execve_rate>
     578:      	ldr	x8, [x8]
     57c:      	ldrb	w8, [x8]
     580:      	cbz	w8, 0x75c <execve_send+0x3bc>
     584:      	mov	w20, #0x800             // =2048
     588:      	mov	w24, #0x8               // =8
     58c:      	add	x25, sp, #0x80
     590:      	add	x29, sp, #0xa8
     594:      	b	0x5a8 <execve_send+0x208>
     598:      	nop
     59c:      	nop
     5a0:      	subs	w20, w20, #0x1
     5a4:      	b.eq	0x8f8 <execve_send+0x558>
     5a8:      	ldp	x19, x2, [sp, #0x58]
     5ac:      	ldp	x8, x9, [sp, #0x40]
     5b0:      	cmp	x19, x8
     5b4:      	ccmp	x2, x9, #0x0, eq
     5b8:      	b.eq	0x8f0 <execve_send+0x550>
     5bc:      	ldr	x21, [sp, #0x68]
     5c0:      	mov	w8, #0x4                // =4
     5c4:      	add	x0, sp, #0x80
     5c8:      	mov	w1, #0x8                // =8
     5cc:      	blr	x8
     5d0:      	ldr	x8, [sp, #0x80]
     5d4:      	cmp	x19, x8
     5d8:      	b.eq	0x6c0 <execve_send+0x320>
     5dc:      	add	x23, x19, #0x18
     5e0:      	mov	w8, #0x4                // =4
     5e4:      	add	x0, sp, #0xa8
     5e8:      	mov	w1, #0x8                // =8
     5ec:      	mov	x2, x23
     5f0:      	blr	x8
     5f4:      	ldr	x8, [sp, #0xa8]
     5f8:      	cmp	x8, x19
     5fc:      	b.eq	0x6c0 <execve_send+0x320>
     600:      	mov	w8, #0x4                // =4
     604:      	add	x9, sp, #0x88
     608:      	add	x0, sp, #0x88
     60c:      	mov	w1, #0x8                // =8
     610:      	mov	x2, x23
     614:      	blr	x8
     618:      	add	x2, x19, #0x20
     61c:      	mov	w8, #0x4                // =4
     620:      	mov	w9, #0x10               // =16
     624:      	add	x10, sp, #0x90
     628:      	add	x0, sp, #0x90
     62c:      	mov	w1, #0x10               // =16
     630:      	blr	x8
     634:      	ldr	w19, [sp, #0x94]
     638:      	ldr	x8, [sp, #0x50]
     63c:      	ldr	x10, [sp, #0x70]
     640:      	sub	x12, x10, x8
     644:      	ldr	w21, [sp, #0x78]
     648:      	subs	w10, w19, w21
     64c:      	ldr	x9, [sp, #0x98]
     650:      	csel	w10, wzr, w10, lo
     654:      	cmp	w21, w19
     658:      	csel	w11, w21, w19, lo
     65c:      	cinc	w13, w11, hi
     660:      	sub	w14, w21, w13
     664:      	subs	x12, x12, x13
     668:      	str	w14, [sp, #0x78]
     66c:      	b.lo	0x8f8 <execve_send+0x558>
     670:      	cmp	x12, #0xfff
     674:      	b.hi	0x8f8 <execve_send+0x558>
     678:      	cmp	w21, w19
     67c:      	b.ls	0x688 <execve_send+0x2e8>
     680:      	mov	w13, #0x2f              // =47
     684:      	strb	w13, [x8, x12]
     688:      	add	x23, x8, x12
     68c:      	cmp	w21, w19
     690:      	add	x2, x9, x10
     694:      	and	w1, w11, #0xff
     698:      	mov	w8, #0x4                // =4
     69c:      	cinc	x0, x23, hi
     6a0:      	blr	x8
     6a4:      	cmp	w21, w19
     6a8:      	str	x23, [sp, #0x70]
     6ac:      	b.ls	0x8f8 <execve_send+0x558>
     6b0:      	ldr	x8, [sp, #0x88]
     6b4:      	str	x8, [sp, #0x58]
     6b8:      	b	0x5a0 <execve_send+0x200>
     6bc:      	nop
     6c0:      	add	x2, x21, #0x10
     6c4:      	mov	w8, #0x4                // =4
     6c8:      	add	x0, sp, #0xa8
     6cc:      	mov	w1, #0x8                // =8
     6d0:      	blr	x8
     6d4:      	ldr	x8, [sp, #0x68]
     6d8:      	ldr	x9, [sp, #0xa8]
     6dc:      	cmp	x8, x9
     6e0:      	b.eq	0x8f0 <execve_send+0x550>
     6e4:      	add	x2, x21, #0x18
     6e8:      	mov	w8, #0x4                // =4
     6ec:      	mov	x0, x22
     6f0:      	mov	w1, #0x8                // =8
     6f4:      	blr	x8
     6f8:      	ldr	x8, [sp, #0xa8]
     6fc:      	add	x9, x8, #0x20
     700:      	stp	x9, x8, [sp, #0x60]
     704:      	b	0x5a0 <execve_send+0x200>
     708:      	add	x2, x24, #0x18
     70c:      	mov	w8, #0x8                // =8
     710:      	mov	w9, #0x4                // =4
     714:      	add	x10, sp, #0x40
     718:      	add	x0, sp, #0x40
     71c:      	mov	w1, #0x8                // =8
     720:      	blr	x9
     724:      	ldr	x8, [sp, #0x40]
     728:      	cmp	x8, x24
     72c:      	b.eq	0x4d8 <execve_send+0x138>
     730:      	ldr	x29, [sp, #0x20]
     734:      	ldr	w9, [x29, #0x1840]
     738:      	sub	w8, w9, #0xa
     73c:      	cmp	w9, #0x9
     740:      	str	w8, [x29, #0x1840]
     744:      	b.gt	0xea8 <execve_send+0xb08>
     748:      	ldr	x21, [sp, #0x10]
     74c:      	mov	w9, #-0x24              // =-36
     750:      	mov	x22, x19
     754:      	str	w9, [x29, #0x1844]
     758:      	b	0x95c <execve_send+0x5bc>
     75c:      	mov	w20, #0x800             // =2048
     760:      	mov	w24, #0x8               // =8
     764:      	add	x25, sp, #0x80
     768:      	add	x29, sp, #0xa8
     76c:      	b	0x7b8 <execve_send+0x418>
     770:      	nop
     774:      	nop
     778:      	nop
     77c:      	nop
     780:      	add	x23, x8, x12
     784:      	cmp	w21, w19
     788:      	add	x2, x9, x10
     78c:      	and	w1, w11, #0xff
     790:      	mov	w8, #0x4                // =4
     794:      	cinc	x0, x23, hi
     798:      	blr	x8
     79c:      	cmp	w21, w19
     7a0:      	str	x23, [sp, #0x70]
     7a4:      	b.ls	0x8f8 <execve_send+0x558>
     7a8:      	ldr	x8, [sp, #0x88]
     7ac:      	str	x8, [sp, #0x58]
     7b0:      	subs	w20, w20, #0x1
     7b4:      	b.eq	0x8f8 <execve_send+0x558>
     7b8:      	ldp	x19, x2, [sp, #0x58]
     7bc:      	ldp	x8, x9, [sp, #0x40]
     7c0:      	cmp	x19, x8
     7c4:      	ccmp	x2, x9, #0x0, eq
     7c8:      	b.eq	0x8f0 <execve_send+0x550>
     7cc:      	ldr	x21, [sp, #0x68]
     7d0:      	mov	w8, #0x4                // =4
     7d4:      	add	x0, sp, #0x80
     7d8:      	mov	w1, #0x8                // =8
     7dc:      	blr	x8
     7e0:      	ldr	x8, [sp, #0x80]
     7e4:      	cmp	x19, x8
     7e8:      	b.eq	0x8a0 <execve_send+0x500>
     7ec:      	add	x23, x19, #0x18
     7f0:      	mov	w8, #0x4                // =4
     7f4:      	add	x0, sp, #0xa8
     7f8:      	mov	w1, #0x8                // =8
     7fc:      	mov	x2, x23
     800:      	blr	x8
     804:      	ldr	x8, [sp, #0xa8]
     808:      	cmp	x8, x19
     80c:      	b.eq	0x8a0 <execve_send+0x500>
     810:      	mov	w8, #0x4                // =4
     814:      	add	x9, sp, #0x88
     818:      	add	x0, sp, #0x88
     81c:      	mov	w1, #0x8                // =8
     820:      	mov	x2, x23
     824:      	blr	x8
     828:      	add	x2, x19, #0x20
     82c:      	mov	w8, #0x4                // =4
     830:      	mov	w9, #0x10               // =16
     834:      	add	x10, sp, #0x90
     838:      	add	x0, sp, #0x90
     83c:      	mov	w1, #0x10               // =16
     840:      	blr	x8
     844:      	ldr	w19, [sp, #0x94]
     848:      	ldr	x8, [sp, #0x50]
     84c:      	ldr	x10, [sp, #0x70]
     850:      	sub	x12, x10, x8
     854:      	ldr	w21, [sp, #0x78]
     858:      	subs	w10, w19, w21
     85c:      	ldr	x9, [sp, #0x98]
     860:      	csel	w10, wzr, w10, lo
     864:      	cmp	w21, w19
     868:      	csel	w11, w21, w19, lo
     86c:      	cinc	w13, w11, hi
     870:      	sub	w14, w21, w13
     874:      	subs	x12, x12, x13
     878:      	str	w14, [sp, #0x78]
     87c:      	b.lo	0x8f8 <execve_send+0x558>
     880:      	cmp	x12, #0xfff
     884:      	b.hi	0x8f8 <execve_send+0x558>
     888:      	cmp	w21, w19
     88c:      	b.ls	0x780 <execve_send+0x3e0>
     890:      	mov	w13, #0x2f              // =47
     894:      	strb	w13, [x8, x12]
     898:      	b	0x780 <execve_send+0x3e0>
     89c:      	nop
     8a0:      	add	x2, x21, #0x10
     8a4:      	mov	w8, #0x4                // =4
     8a8:      	add	x0, sp, #0xa8
     8ac:      	mov	w1, #0x8                // =8
     8b0:      	blr	x8
     8b4:      	ldr	x8, [sp, #0x68]
     8b8:      	ldr	x9, [sp, #0xa8]
     8bc:      	cmp	x8, x9
     8c0:      	b.eq	0x8f0 <execve_send+0x550>
     8c4:      	add	x2, x21, #0x18
     8c8:      	mov	w8, #0x4                // =4
     8cc:      	mov	x0, x22
     8d0:      	mov	w1, #0x8                // =8
     8d4:      	blr	x8
     8d8:      	ldr	x8, [sp, #0xa8]
     8dc:      	add	x9, x8, #0x20
     8e0:      	stp	x9, x8, [sp, #0x60]
     8e4:      	subs	w20, w20, #0x1
     8e8:      	b.ne	0x7b8 <execve_send+0x418>
     8ec:      	b	0x8f8 <execve_send+0x558>
     8f0:      	mov	w8, #0x1                // =1
     8f4:      	strb	w8, [sp, #0x7c]
     8f8:      	ldr	x22, [sp, #0x70]
     8fc:      	ldr	x9, [sp, #0x8]
     900:      	cmp	x22, x9
     904:      	b.eq	0x948 <execve_send+0x5a8>
     908:      	ldrb	w8, [sp, #0x7c]
     90c:      	ldr	x29, [sp, #0x20]
     910:      	cmp	w8, #0x0
     914:      	ldr	x21, [sp, #0x10]
     918:      	cset	w8, eq
     91c:      	lsl	w9, w8, #1
     920:      	ldr	w8, [sp, #0x78]
     924:      	cmp	w8, #0x1
     928:      	str	w8, [x29, #0x1840]
     92c:      	str	w9, [x29, #0x1844]
     930:      	b.lt	0x940 <execve_send+0x5a0>
     934:      	mov	w9, #0x1000             // =4096
     938:      	sub	w8, w9, w8
     93c:      	str	w8, [x29, #0x1840]
     940:      	cbnz	x22, 0x95c <execve_send+0x5bc>
     944:      	b	0xa90 <execve_send+0x6f0>
     948:      	ldr	x29, [sp, #0x20]
     94c:      	ldr	x21, [sp, #0x10]
     950:      	mov	w8, wzr
     954:      	mov	x22, x9
     958:      	str	xzr, [x29, #0x1840]
     95c:      	subs	w9, w8, #0x7f
     960:      	mov	w10, #0x7f              // =127
     964:      	mov	x0, x21
     968:      	mov	x2, x22
     96c:      	csel	w24, w8, w10, lo
     970:      	csel	w19, wzr, w9, lo
     974:      	cmp	w8, #0xff
     978:      	mov	w9, #0xff               // =255
     97c:      	csel	w8, w8, w9, lo
     980:      	and	w1, w8, #0xff
     984:      	str	w1, [x29, #0x1840]
     988:      	mov	w8, #0x4                // =4
     98c:      	blr	x8
     990:      	adrp	x23, 0x0 <execve_rate>
     994:      	ldr	x23, [x23]
     998:      	cbz	x0, 0xa08 <execve_send+0x668>
     99c:      	neg	w8, w0
     9a0:      	mov	w9, #0x1                // =1
     9a4:      	add	x1, sp, #0x40
     9a8:      	strh	w8, [sp, #0x40]
     9ac:      	mov	w8, #0x8                // =8
     9b0:      	mov	x0, x23
     9b4:      	mov	w20, #0x1               // =1
     9b8:      	strh	w8, [sp, #0x42]
     9bc:      	mov	x8, #0x2de              // =734
     9c0:      	movk	x8, #0x4, lsl #32
     9c4:      	stur	x8, [sp, #0x44]
     9c8:      	add	x8, sp, #0x40
     9cc:      	blr	x9
     9d0:      	cbz	x0, 0x9e4 <execve_send+0x644>
     9d4:      	ldr	w8, [x0]
     9d8:      	add	w8, w8, #0x1
     9dc:      	str	w8, [x0]
     9e0:      	b	0xa08 <execve_send+0x668>
     9e4:      	str	w20, [sp, #0x90]
     9e8:      	mov	x3, xzr
     9ec:      	mov	w8, #0x2                // =2
     9f0:      	add	x9, sp, #0x40
     9f4:      	add	x10, sp, #0x90
     9f8:      	add	x1, sp, #0x40
     9fc:      	add	x2, sp, #0x90
     a00:      	mov	x0, x23
     a04:      	blr	x8
     a08:      	mov	w8, #0x17c0             // =6080
     a0c:      	add	x2, x22, x19
     a10:      	mov	w1, w24
     a14:      	add	x0, x29, x8
     a18:      	mov	w8, #0x4                // =4
     a1c:      	blr	x8
     a20:      	cbz	x0, 0xa90 <execve_send+0x6f0>
     a24:      	neg	w8, w0
     a28:      	mov	w9, #0x1                // =1
     a2c:      	add	x1, sp, #0x40
     a30:      	strh	w8, [sp, #0x40]
     a34:      	mov	w8, #0x8                // =8
     a38:      	mov	x0, x23
     a3c:      	mov	w19, #0x1               // =1
     a40:      	strh	w8, [sp, #0x42]
     a44:      	mov	x8, #0x2e0              // =736
     a48:      	movk	x8, #0x4, lsl #32
     a4c:      	stur	x8, [sp, #0x44]
     a50:      	add	x8, sp, #0x40
     a54:      	blr	x9
     a58:      	cbz	x0, 0xa6c <execve_send+0x6cc>
     a5c:      	ldr	w8, [x0]
     a60:      	add	w8, w8, #0x1
     a64:      	str	w8, [x0]
     a68:      	b	0xa90 <execve_send+0x6f0>
     a6c:      	str	w19, [sp, #0x90]
     a70:      	mov	x3, xzr
     a74:      	mov	w8, #0x2                // =2
     a78:      	add	x9, sp, #0x40
     a7c:      	add	x10, sp, #0x90
     a80:      	add	x1, sp, #0x40
     a84:      	add	x2, sp, #0x90
     a88:      	mov	x0, x23
     a8c:      	blr	x8
     a90:      	mov	w8, #0xe                // =14
     a94:      	blr	x8
     a98:      	lsr	x8, x0, #32
     a9c:      	adrp	x23, 0x0 <execve_rate>
     aa0:      	add	x9, sp, #0x40
     aa4:      	str	w8, [sp, #0x40]
     aa8:      	mov	w8, #0x1                // =1
     aac:      	add	x1, sp, #0x40
     ab0:      	ldr	x23, [x23]
     ab4:      	mov	x0, x23
     ab8:      	blr	x8
     abc:      	cbz	x0, 0x1290 <execve_send+0xef0>
     ac0:      	ldp	x8, x9, [x0]
     ac4:      	mov	x22, x0
     ac8:      	stp	x8, x9, [x29, #0x130]
     acc:      	ldr	w9, [x29, #0x144]
     ad0:      	ldr	w8, [x0, #0x20]
     ad4:      	str	w9, [x0]
     ad8:      	ldr	x9, [x29, #0x170]
     adc:      	str	x9, [x0, #0x8]
     ae0:      	ldr	w9, [x29, #0x14c]
     ae4:      	str	w9, [x0, #0x24]
     ae8:      	ldp	x11, x10, [x29, #0xa0]
     aec:      	stp	x11, x10, [x0, #0x10]
     af0:      	tbnz	w8, #0x0, 0xb28 <execve_send+0x788>
     af4:      	and	w10, w8, #0xfffffffe
     af8:      	cmp	w9, #0x1
     afc:      	orr	w11, w10, #0x2000000
     b00:      	csel	w9, w11, w10, eq
     b04:      	str	w9, [x22, #0x20]
     b08:      	tbnz	w9, #0x19, 0xb4c <execve_send+0x7ac>
     b0c:      	cmp	w8, #0x1
     b10:      	b.eq	0xb60 <execve_send+0x7c0>
     b14:      	adrp	x8, 0x0 <execve_rate>
     b18:      	ldr	x8, [x8]
     b1c:      	ldrb	w8, [x8]
     b20:      	cbnz	w8, 0xba0 <execve_send+0x800>
     b24:      	b	0xe08 <execve_send+0xa68>
     b28:      	ldr	w10, [x29, #0x15c]
     b2c:      	orr	w10, w10, #0x4000
     b30:      	str	w10, [x29, #0x15c]
     b34:      	and	w10, w8, #0xfffffffe
     b38:      	cmp	w9, #0x1
     b3c:      	orr	w11, w10, #0x2000000
     b40:      	csel	w9, w11, w10, eq
     b44:      	str	w9, [x22, #0x20]
     b48:      	tbz	w9, #0x19, 0xb0c <execve_send+0x76c>
     b4c:      	ldr	w9, [x29, #0x15c]
     b50:      	orr	w9, w9, #0x2000000
     b54:      	str	w9, [x29, #0x15c]
     b58:      	cmp	w8, #0x1
     b5c:      	b.ne	0xb14 <execve_send+0x774>
     b60:      	ldr	x8, [x29, #0x108]
     b64:      	str	x8, [x22, #0x28]
     b68:      	ldp	x8, x9, [x29, #0x110]
     b6c:      	ldp	x10, x11, [x29, #0x120]
     b70:      	stp	x10, x11, [x22, #0x40]
     b74:      	stp	x8, x9, [x22, #0x30]
     b78:      	ldr	x8, [x29, #0xe0]
     b7c:      	str	x8, [x22, #0x50]
     b80:      	ldr	x8, [x29, #0xe8]
     b84:      	str	x8, [x22, #0x58]
     b88:      	ldr	x8, [x29, #0xf0]
     b8c:      	str	x8, [x22, #0x60]
     b90:      	adrp	x8, 0x0 <execve_rate>
     b94:      	ldr	x8, [x8]
     b98:      	ldrb	w8, [x8]
     b9c:      	cbz	w8, 0xe08 <execve_send+0xa68>
     ba0:      	str	wzr, [sp, #0x88]
     ba4:      	adrp	x0, 0x0 <execve_rate>
     ba8:      	mov	w8, #0x1                // =1
     bac:      	add	x9, sp, #0x88
     bb0:      	ldr	x0, [x0]
     bb4:      	add	x1, sp, #0x88
     bb8:      	blr	x8
     bbc:      	cbz	x0, 0xe08 <execve_send+0xa68>
     bc0:      	ldrb	w8, [x29, #0x15d]
     bc4:      	tbnz	w8, #0x6, 0xbf4 <execve_send+0x854>
     bc8:      	add	x1, x22, #0x68
     bcc:      	mov	w2, #0x318              // =792
     bd0:      	mov	x20, x0
     bd4:      	bl	0xbd4 <execve_send+0x834>
     bd8:      	adrp	x0, 0x0 <execve_rate>
     bdc:      	mov	x3, xzr
     be0:      	mov	w8, #0x2                // =2
     be4:      	ldr	x0, [x0]
     be8:      	mov	x1, x22
     bec:      	mov	x2, x20
     bf0:      	b	0xe04 <execve_send+0xa64>
     bf4:      	mov	w8, #0x23               // =35
     bf8:      	blr	x8
     bfc:      	str	x0, [sp, #0x40]
     c00:      	add	x8, x0, #0x8e0
     c04:      	mov	w9, #0x8                // =8
     c08:      	mov	w10, #0x71              // =113
     c0c:      	add	x11, sp, #0x40
     c10:      	add	x0, sp, #0x40
     c14:      	mov	w1, #0x8                // =8
     c18:      	ldr	x8, [sp, #0x40]
     c1c:      	add	x2, x8, #0x8e0
     c20:      	blr	x10
     c24:      	ldr	x8, [sp, #0x40]
     c28:      	cbz	x8, 0xe08 <execve_send+0xa68>
     c2c:      	add	x8, x8, #0x8d4
     c30:      	mov	w9, #0x4                // =4
     c34:      	mov	w10, #0x71              // =113
     c38:      	add	x11, sp, #0xa8
     c3c:      	ldr	x8, [sp, #0x40]
     c40:      	add	x0, sp, #0xa8
     c44:      	mov	w1, #0x4                // =4
     c48:      	add	x2, x8, #0x8d4
     c4c:      	blr	x10
     c50:      	ldr	w8, [sp, #0xa8]
     c54:      	add	x9, sp, #0x90
     c58:      	add	x1, sp, #0x90
     c5c:      	mov	x0, x23
     c60:      	str	w8, [sp, #0x90]
     c64:      	mov	w8, #0x1                // =1
     c68:      	blr	x8
     c6c:      	cbz	x0, 0xc78 <execve_send+0x8d8>
     c70:      	ldr	x8, [x0, #0x8]
     c74:      	cbnz	x8, 0xdec <execve_send+0xa4c>
     c78:      	ldr	x8, [sp, #0x40]
     c7c:      	mov	w9, #0x8                // =8
     c80:      	mov	w10, #0x71              // =113
     c84:      	add	x11, sp, #0x40
     c88:      	add	x0, sp, #0x40
     c8c:      	mov	w1, #0x8                // =8
     c90:      	add	x8, x8, #0x8e0
     c94:      	ldr	x8, [sp, #0x40]
     c98:      	add	x2, x8, #0x8e0
     c9c:      	blr	x10
     ca0:      	ldr	x8, [sp, #0x40]
     ca4:      	cbz	x8, 0xe08 <execve_send+0xa68>
     ca8:      	add	x8, x8, #0x8d4
     cac:      	mov	w9, #0x4                // =4
     cb0:      	mov	w10, #0x71              // =113
     cb4:      	add	x11, sp, #0xa8
     cb8:      	ldr	x8, [sp, #0x40]
     cbc:      	add	x0, sp, #0xa8
     cc0:      	mov	w1, #0x4                // =4
     cc4:      	add	x2, x8, #0x8d4
     cc8:      	blr	x10
     ccc:      	ldr	w8, [sp, #0xa8]
     cd0:      	add	x9, sp, #0x90
     cd4:      	add	x1, sp, #0x90
     cd8:      	mov	x0, x23
     cdc:      	str	w8, [sp, #0x90]
     ce0:      	mov	w8, #0x1                // =1
     ce4:      	blr	x8
     ce8:      	cbz	x0, 0xcf4 <execve_send+0x954>
     cec:      	ldr	x8, [x0, #0x8]
     cf0:      	cbnz	x8, 0xdec <execve_send+0xa4c>
     cf4:      	ldr	x8, [sp, #0x40]
     cf8:      	mov	w9, #0x8                // =8
     cfc:      	mov	w10, #0x71              // =113
     d00:      	add	x11, sp, #0x40
     d04:      	add	x0, sp, #0x40
     d08:      	mov	w1, #0x8                // =8
     d0c:      	add	x8, x8, #0x8e0
     d10:      	ldr	x8, [sp, #0x40]
     d14:      	add	x2, x8, #0x8e0
     d18:      	blr	x10
     d1c:      	ldr	x8, [sp, #0x40]
     d20:      	cbz	x8, 0xe08 <execve_send+0xa68>
     d24:      	add	x8, x8, #0x8d4
     d28:      	mov	w9, #0x4                // =4
     d2c:      	mov	w10, #0x71              // =113
     d30:      	add	x11, sp, #0xa8
     d34:      	ldr	x8, [sp, #0x40]
     d38:      	add	x0, sp, #0xa8
     d3c:      	mov	w1, #0x4                // =4
     d40:      	add	x2, x8, #0x8d4
     d44:      	blr	x10
     d48:      	ldr	w8, [sp, #0xa8]
     d4c:      	add	x9, sp, #0x90
     d50:      	add	x1, sp, #0x90
     d54:      	mov	x0, x23
     d58:      	str	w8, [sp, #0x90]
     d5c:      	mov	w8, #0x1                // =1
     d60:      	blr	x8
     d64:      	cbz	x0, 0xd70 <execve_send+0x9d0>
     d68:      	ldr	x8, [x0, #0x8]
     d6c:      	cbnz	x8, 0xdec <execve_send+0xa4c>
     d70:      	ldr	x8, [sp, #0x40]
     d74:      	mov	w9, #0x8                // =8
     d78:      	mov	w10, #0x71              // =113
     d7c:      	add	x11, sp, #0x40
     d80:      	add	x0, sp, #0x40
     d84:      	mov	w1, #0x8                // =8
     d88:      	add	x8, x8, #0x8e0
     d8c:      	ldr	x8, [sp, #0x40]
     d90:      	add	x2, x8, #0x8e0
     d94:      	blr	x10
     d98:      	ldr	x8, [sp, #0x40]
     d9c:      	cbz	x8, 0xe08 <execve_send+0xa68>
     da0:      	add	x8, x8, #0x8d4
     da4:      	mov	w9, #0x4                // =4
     da8:      	mov	w10, #0x71              // =113
     dac:      	add	x11, sp, #0xa8
     db0:      	ldr	x8, [sp, #0x40]
     db4:      	add	x0, sp, #0xa8
     db8:      	mov	w1, #0x4                // =4
     dbc:      	add	x2, x8, #0x8d4
     dc0:      	blr	x10
     dc4:      	ldr	w8, [sp, #0xa8]
     dc8:      	add	x9, sp, #0x90
     dcc:      	add	x1, sp, #0x90
     dd0:      	mov	x0, x23
     dd4:      	str	w8, [sp, #0x90]
     dd8:      	mov	w8, #0x1                // =1
     ddc:      	blr	x8
     de0:      	cbz	x0, 0xe08 <execve_send+0xa68>
     de4:      	ldr	x8, [x0, #0x8]
     de8:      	cbz	x8, 0xe08 <execve_send+0xa68>
     dec:      	add	x2, x0, #0x68
     df0:      	adrp	x0, 0x0 <execve_rate>
     df4:      	mov	x3, xzr
     df8:      	ldr	x0, [x0]
     dfc:      	mov	w8, #0x2                // =2
     e00:      	mov	x1, x22
     e04:      	blr	x8
     e08:      	add	x0, x22, #0x68
     e0c:      	mov	w1, wzr
     e10:      	mov	w2, #0x308              // =776
     e14:      	add	x20, x29, #0x140
     e18:      	bl	0xe18 <execve_send+0xa78>
     e1c:      	ldr	w8, [x29, #0x1840]
     e20:      	sub	w9, w8, #0x101
     e24:      	cmn	w9, #0x101
     e28:      	b.hi	0xe38 <execve_send+0xa98>
     e2c:      	mov	w8, #-0x1               // =-1
     e30:      	stur	w8, [x22, #0x68]
     e34:      	b	0xf90 <execve_send+0xbf0>
     e38:      	and	x24, x8, #0xff
     e3c:      	add	x0, x22, #0x70
     e40:      	mov	w8, #0x4                // =4
     e44:      	mov	x2, x21
     e48:      	mov	w1, w24
     e4c:      	blr	x8
     e50:      	mov	x21, x0
     e54:      	cbz	x0, 0xeec <execve_send+0xb4c>
     e58:      	neg	w8, w21
     e5c:      	adrp	x25, 0x0 <execve_rate>
     e60:      	mov	w9, #0x1                // =1
     e64:      	strh	w8, [sp, #0x40]
     e68:      	mov	w8, #0xf                // =15
     e6c:      	add	x1, sp, #0x40
     e70:      	mov	w19, #0x1               // =1
     e74:      	strh	w8, [sp, #0x42]
     e78:      	mov	x8, #0x164              // =356
     e7c:      	movk	x8, #0x4, lsl #32
     e80:      	stur	x8, [sp, #0x44]
     e84:      	add	x8, sp, #0x40
     e88:      	ldr	x25, [x25]
     e8c:      	mov	x0, x25
     e90:      	blr	x9
     e94:      	cbz	x0, 0xec8 <execve_send+0xb28>
     e98:      	ldr	w8, [x0]
     e9c:      	add	w8, w8, #0x1
     ea0:      	str	w8, [x0]
     ea4:      	b	0xeec <execve_send+0xb4c>
     ea8:      	mov	w8, #0x2964             // =10596
     eac:      	add	x19, x22, #0xff6
     eb0:      	strh	w8, [x22, #0xffe]
     eb4:      	adrp	x8, 0x0 <execve_rate>
     eb8:      	add	x8, x8, #0x0
     ebc:      	ldr	x8, [x8]
     ec0:      	str	x8, [x19]
     ec4:      	b	0x4d8 <execve_send+0x138>
     ec8:      	str	w19, [sp, #0x90]
     ecc:      	mov	x3, xzr
     ed0:      	mov	w8, #0x2                // =2
     ed4:      	add	x9, sp, #0x40
     ed8:      	add	x10, sp, #0x90
     edc:      	add	x1, sp, #0x40
     ee0:      	add	x2, sp, #0x90
     ee4:      	mov	x0, x25
     ee8:      	blr	x8
     eec:      	cmp	w21, #0x0
     ef0:      	add	x0, x22, #0x170
     ef4:      	csel	w8, w24, w21, eq
     ef8:      	cmp	w24, #0x7f
     efc:      	str	w8, [x22, #0x68]
     f00:      	mov	w8, #0x7f               // =127
     f04:      	csel	w1, w24, w8, lo
     f08:      	mov	w8, #0x17c0             // =6080
     f0c:      	add	x2, x29, x8
     f10:      	mov	w8, #0x4                // =4
     f14:      	blr	x8
     f18:      	cbz	x0, 0xf90 <execve_send+0xbf0>
     f1c:      	neg	w8, w0
     f20:      	adrp	x21, 0x0 <execve_rate>
     f24:      	mov	w9, #0x1                // =1
     f28:      	strh	w8, [sp, #0x40]
     f2c:      	mov	w8, #0xf                // =15
     f30:      	add	x1, sp, #0x40
     f34:      	mov	w19, #0x1               // =1
     f38:      	strh	w8, [sp, #0x42]
     f3c:      	mov	x8, #0x16a              // =362
     f40:      	movk	x8, #0x4, lsl #32
     f44:      	stur	x8, [sp, #0x44]
     f48:      	add	x8, sp, #0x40
     f4c:      	ldr	x21, [x21]
     f50:      	mov	x0, x21
     f54:      	blr	x9
     f58:      	cbz	x0, 0xf6c <execve_send+0xbcc>
     f5c:      	ldr	w8, [x0]
     f60:      	add	w8, w8, #0x1
     f64:      	str	w8, [x0]
     f68:      	b	0xf90 <execve_send+0xbf0>
     f6c:      	str	w19, [sp, #0x90]
     f70:      	mov	x3, xzr
     f74:      	mov	w8, #0x2                // =2
     f78:      	add	x9, sp, #0x40
     f7c:      	add	x10, sp, #0x90
     f80:      	add	x1, sp, #0x40
     f84:      	add	x2, sp, #0x90
     f88:      	mov	x0, x21
     f8c:      	blr	x8
     f90:      	ldr	w9, [x29, #0x1848]
     f94:      	ldr	w8, [x29, #0x184c]
     f98:      	mov	w10, #0xfe              // =254
     f9c:      	add	x24, x22, #0x270
     fa0:      	mov	x0, x24
     fa4:      	cmp	w9, #0xfe
     fa8:      	add	x2, x20, x8
     fac:      	mov	w8, #0x4                // =4
     fb0:      	csel	w21, w9, w10, lo
     fb4:      	mov	w1, w21
     fb8:      	blr	x8
     fbc:      	cbz	x0, 0x1034 <execve_send+0xc94>
     fc0:      	neg	w8, w0
     fc4:      	adrp	x25, 0x0 <execve_rate>
     fc8:      	mov	w9, #0x1                // =1
     fcc:      	strh	w8, [sp, #0x40]
     fd0:      	mov	w8, #0x9                // =9
     fd4:      	add	x1, sp, #0x40
     fd8:      	mov	w19, #0x1               // =1
     fdc:      	strh	w8, [sp, #0x42]
     fe0:      	mov	x8, #0x1af              // =431
     fe4:      	movk	x8, #0x4, lsl #32
     fe8:      	stur	x8, [sp, #0x44]
     fec:      	add	x8, sp, #0x40
     ff0:      	ldr	x25, [x25]
     ff4:      	mov	x0, x25
     ff8:      	blr	x9
     ffc:      	cbz	x0, 0x1010 <execve_send+0xc70>
    1000:      	ldr	w8, [x0]
    1004:      	add	w8, w8, #0x1
    1008:      	str	w8, [x0]
    100c:      	b	0x1034 <execve_send+0xc94>
    1010:      	str	w19, [sp, #0x90]
    1014:      	mov	x3, xzr
    1018:      	mov	w8, #0x2                // =2
    101c:      	add	x9, sp, #0x40
    1020:      	add	x10, sp, #0x90
    1024:      	add	x1, sp, #0x40
    1028:      	add	x2, sp, #0x90
    102c:      	mov	x0, x25
    1030:      	blr	x8
    1034:      	add	w8, w21, #0x1
    1038:      	strb	wzr, [x24, x21]
    103c:      	strb	wzr, [x24, w8, uxtw]
    1040:      	mov	w8, #0x23               // =35
    1044:      	blr	x8
    1048:      	str	x0, [sp, #0x40]
    104c:      	add	x8, x0, #0x8e0
    1050:      	mov	w9, #0x8                // =8
    1054:      	mov	w10, #0x71              // =113
    1058:      	add	x11, sp, #0x40
    105c:      	add	x0, sp, #0x40
    1060:      	mov	w1, #0x8                // =8
    1064:      	ldr	x8, [sp, #0x40]
    1068:      	add	x2, x8, #0x8e0
    106c:      	blr	x10
    1070:      	ldr	x8, [sp, #0x40]
    1074:      	cbz	x8, 0x1250 <execve_send+0xeb0>
    1078:      	add	x8, x8, #0x8d4
    107c:      	mov	w9, #0x4                // =4
    1080:      	mov	w10, #0x71              // =113
    1084:      	add	x11, sp, #0xa8
    1088:      	ldr	x8, [sp, #0x40]
    108c:      	add	x0, sp, #0xa8
    1090:      	mov	w1, #0x4                // =4
    1094:      	add	x2, x8, #0x8d4
    1098:      	blr	x10
    109c:      	ldr	w8, [sp, #0xa8]
    10a0:      	add	x9, sp, #0x90
    10a4:      	add	x1, sp, #0x90
    10a8:      	mov	x0, x23
    10ac:      	str	w8, [sp, #0x90]
    10b0:      	mov	w8, #0x1                // =1
    10b4:      	blr	x8
    10b8:      	cbz	x0, 0x10c4 <execve_send+0xd24>
    10bc:      	ldr	x8, [x0, #0x8]
    10c0:      	cbnz	x8, 0x1238 <execve_send+0xe98>
    10c4:      	ldr	x8, [sp, #0x40]
    10c8:      	mov	w9, #0x8                // =8
    10cc:      	mov	w10, #0x71              // =113
    10d0:      	add	x11, sp, #0x40
    10d4:      	add	x0, sp, #0x40
    10d8:      	mov	w1, #0x8                // =8
    10dc:      	add	x8, x8, #0x8e0
    10e0:      	ldr	x8, [sp, #0x40]
    10e4:      	add	x2, x8, #0x8e0
    10e8:      	blr	x10
    10ec:      	ldr	x8, [sp, #0x40]
    10f0:      	cbz	x8, 0x1250 <execve_send+0xeb0>
    10f4:      	add	x8, x8, #0x8d4
    10f8:      	mov	w9, #0x4                // =4
    10fc:      	mov	w10, #0x71              // =113
    1100:      	add	x11, sp, #0xa8
    1104:      	ldr	x8, [sp, #0x40]
    1108:      	add	x0, sp, #0xa8
    110c:      	mov	w1, #0x4                // =4
    1110:      	add	x2, x8, #0x8d4
    1114:      	blr	x10
    1118:      	ldr	w8, [sp, #0xa8]
    111c:      	add	x9, sp, #0x90
    1120:      	add	x1, sp, #0x90
    1124:      	mov	x0, x23
    1128:      	str	w8, [sp, #0x90]
    112c:      	mov	w8, #0x1                // =1
    1130:      	blr	x8
    1134:      	cbz	x0, 0x1140 <execve_send+0xda0>
    1138:      	ldr	x8, [x0, #0x8]
    113c:      	cbnz	x8, 0x1238 <execve_send+0xe98>
    1140:      	ldr	x8, [sp, #0x40]
    1144:      	mov	w9, #0x8                // =8
    1148:      	mov	w10, #0x71              // =113
    114c:      	add	x11, sp, #0x40
    1150:      	add	x0, sp, #0x40
    1154:      	mov	w1, #0x8                // =8
    1158:      	add	x8, x8, #0x8e0
    115c:      	ldr	x8, [sp, #0x40]
    1160:      	add	x2, x8, #0x8e0
    1164:      	blr	x10
    1168:      	ldr	x8, [sp, #0x40]
    116c:      	cbz	x8, 0x1250 <execve_send+0xeb0>
    1170:      	add	x8, x8, #0x8d4
    1174:      	mov	w9, #0x4                // =4
    1178:      	mov	w10, #0x71              // =113
    117c:      	add	x11, sp, #0xa8
    1180:      	ldr	x8, [sp, #0x40]
    1184:      	add	x0, sp, #0xa8
    1188:      	mov	w1, #0x4                // =4
    118c:      	add	x2, x8, #0x8d4
    1190:      	blr	x10
    1194:      	ldr	w8, [sp, #0xa8]
    1198:      	add	x9, sp, #0x90
    119c:      	add	x1, sp, #0x90
    11a0:      	mov	x0, x23
    11a4:      	str	w8, [sp, #0x90]
    11a8:      	mov	w8, #0x1                // =1
    11ac:      	blr	x8
    11b0:      	cbz	x0, 0x11bc <execve_send+0xe1c>
    11b4:      	ldr	x8, [x0, #0x8]
    11b8:      	cbnz	x8, 0x1238 <execve_send+0xe98>
    11bc:      	ldr	x8, [sp, #0x40]
    11c0:      	mov	w9, #0x8                // =8
    11c4:      	mov	w10, #0x71              // =113
    11c8:      	add	x11, sp, #0x40
    11cc:      	add	x0, sp, #0x40
    11d0:      	mov	w1, #0x8                // =8
    11d4:      	add	x8, x8, #0x8e0
    11d8:      	ldr	x8, [sp, #0x40]
    11dc:      	add	x2, x8, #0x8e0
    11e0:      	blr	x10
    11e4:      	ldr	x8, [sp, #0x40]
    11e8:      	cbz	x8, 0x1250 <execve_send+0xeb0>
    11ec:      	add	x8, x8, #0x8d4
    11f0:      	mov	w9, #0x4                // =4
    11f4:      	mov	w10, #0x71              // =113
    11f8:      	add	x11, sp, #0xa8
    11fc:      	ldr	x8, [sp, #0x40]
    1200:      	add	x0, sp, #0xa8
    1204:      	mov	w1, #0x4                // =4
    1208:      	add	x2, x8, #0x8d4
    120c:      	blr	x10
    1210:      	ldr	w8, [sp, #0xa8]
    1214:      	add	x9, sp, #0x90
    1218:      	add	x1, sp, #0x90
    121c:      	mov	x0, x23
    1220:      	str	w8, [sp, #0x90]
    1224:      	mov	w8, #0x1                // =1
    1228:      	blr	x8
    122c:      	cbz	x0, 0x1250 <execve_send+0xeb0>
    1230:      	ldr	x8, [x0, #0x8]
    1234:      	cbz	x8, 0x1250 <execve_send+0xeb0>
    1238:      	ldr	x9, [x0, #0x370]
    123c:      	add	x8, x22, #0x370
    1240:      	ldaxr	x10, [x8]
    1244:      	orr	x10, x10, x9
    1248:      	stlxr	w11, x10, [x8]
    124c:      	cbnz	w11, 0x1240 <execve_send+0xea0>
    1250:      	adrp	x0, 0x1000 <execve_send+0xc60>
    1254:      	add	x1, x22, #0x70
    1258:      	mov	w8, #0x1                // =1
    125c:      	ldr	x0, [x0]
    1260:      	blr	x8
    1264:      	cbz	x0, 0x1290 <execve_send+0xef0>
    1268:      	ldr	x9, [x0]
    126c:      	add	x8, x22, #0x370
    1270:      	nop
    1274:      	nop
    1278:      	nop
    127c:      	nop
    1280:      	ldaxr	x10, [x8]
    1284:      	orr	x10, x10, x9
    1288:      	stlxr	w11, x10, [x8]
    128c:      	cbnz	w11, 0x1280 <execve_send+0xee0>
    1290:      	ldr	w8, [x29, #0x140]
    1294:      	strb	wzr, [x29, #0x1]
    1298:      	mov	w9, #0x1710             // =5904
    129c:      	adrp	x0, 0x1000 <execve_send+0xc60>
    12a0:      	add	x1, sp, #0x90
    12a4:      	str	wzr, [sp, #0x90]
    12a8:      	ldr	x0, [x0]
    12ac:      	cmp	w8, w9
    12b0:      	csel	w8, w8, w9, lo
    12b4:      	add	x9, sp, #0x90
    12b8:      	add	w21, w8, #0x140
    12bc:      	mov	w8, #0x1                // =1
    12c0:      	blr	x8
    12c4:      	cbz	x0, 0x1348 <execve_send+0xfa8>
    12c8:      	ldrb	w8, [x0, #0x28]
    12cc:      	cbz	w8, 0x1348 <execve_send+0xfa8>
    12d0:      	adrp	x1, 0x1000 <execve_send+0xc60>
    12d4:      	mov	w8, #-0x1               // =-1
    12d8:      	mov	w9, #0x19               // =25
    12dc:      	ldr	x1, [x1]
    12e0:      	ldr	x0, [sp, #0x18]
    12e4:      	mov	w2, #-0x1               // =-1
    12e8:      	mov	x3, x29
    12ec:      	mov	x4, x21
    12f0:      	blr	x9
    12f4:      	tbz	x0, #0x3f, 0x1470 <execve_send+0x10d0>
    12f8:      	mov	x19, x0
    12fc:      	str	wzr, [sp, #0x40]
    1300:      	adrp	x0, 0x1000 <execve_send+0xc60>
    1304:      	mov	w8, #0x1                // =1
    1308:      	ldr	x0, [x0]
    130c:      	add	x9, sp, #0x40
    1310:      	add	x1, sp, #0x40
    1314:      	blr	x8
    1318:      	cbz	x0, 0x1470 <execve_send+0x10d0>
    131c:      	mov	x8, x19
    1320:      	cmn	x19, #0xc
    1324:      	b.gt	0x13d8 <execve_send+0x1038>
    1328:      	cmn	x8, #0x1c
    132c:      	b.eq	0x1434 <execve_send+0x1094>
    1330:      	cmn	x8, #0x16
    1334:      	b.eq	0x144c <execve_send+0x10ac>
    1338:      	cmn	x8, #0x10
    133c:      	b.ne	0x1444 <execve_send+0x10a4>
    1340:      	add	x8, x0, #0x130
    1344:      	b	0x1460 <execve_send+0x10c0>
    1348:      	adrp	x0, 0x1000 <execve_send+0xc60>
    134c:      	mov	x3, xzr
    1350:      	mov	w8, #0x82               // =130
    1354:      	ldr	x0, [x0]
    1358:      	mov	x1, x29
    135c:      	mov	x2, x21
    1360:      	blr	x8
    1364:      	tbz	x0, #0x3f, 0x1470 <execve_send+0x10d0>
    1368:      	mov	x19, x0
    136c:      	str	wzr, [sp, #0x40]
    1370:      	adrp	x0, 0x1000 <execve_send+0xc60>
    1374:      	mov	w8, #0x1                // =1
    1378:      	ldr	x0, [x0]
    137c:      	add	x9, sp, #0x40
    1380:      	add	x1, sp, #0x40
    1384:      	blr	x8
    1388:      	cbz	x0, 0x1470 <execve_send+0x10d0>
    138c:      	mov	x8, x19
    1390:      	cmn	x19, #0xc
    1394:      	b.gt	0x13b8 <execve_send+0x1018>
    1398:      	cmn	x8, #0x1c
    139c:      	b.eq	0x13f8 <execve_send+0x1058>
    13a0:      	cmn	x8, #0x16
    13a4:      	b.eq	0x1410 <execve_send+0x1070>
    13a8:      	cmn	x8, #0x10
    13ac:      	b.ne	0x1408 <execve_send+0x1068>
    13b0:      	add	x8, x0, #0x130
    13b4:      	b	0x1420 <execve_send+0x1080>
    13b8:      	cmn	x8, #0xb
    13bc:      	b.eq	0x1400 <execve_send+0x1060>
    13c0:      	cmn	x8, #0x7
    13c4:      	b.eq	0x1418 <execve_send+0x1078>
    13c8:      	cmn	x8, #0x2
    13cc:      	b.ne	0x1408 <execve_send+0x1068>
    13d0:      	add	x8, x0, #0x120
    13d4:      	b	0x1420 <execve_send+0x1080>
    13d8:      	cmn	x8, #0xb
    13dc:      	b.eq	0x143c <execve_send+0x109c>
    13e0:      	cmn	x8, #0x7
    13e4:      	b.eq	0x1454 <execve_send+0x10b4>
    13e8:      	cmn	x8, #0x2
    13ec:      	b.ne	0x1444 <execve_send+0x10a4>
    13f0:      	add	x8, x0, #0x120
    13f4:      	b	0x1460 <execve_send+0x10c0>
    13f8:      	add	x8, x0, #0x140
    13fc:      	b	0x1420 <execve_send+0x1080>
    1400:      	add	x8, x0, #0x148
    1404:      	b	0x1420 <execve_send+0x1080>
    1408:      	add	x8, x0, #0x118
    140c:      	b	0x1420 <execve_send+0x1080>
    1410:      	add	x8, x0, #0x138
    1414:      	b	0x1420 <execve_send+0x1080>
    1418:      	add	x8, x0, #0x128
    141c:      	nop
    1420:      	ldaxr	x9, [x8]
    1424:      	add	x9, x9, #0x1
    1428:      	stlxr	w10, x9, [x8]
    142c:      	cbnz	w10, 0x1420 <execve_send+0x1080>
    1430:      	b	0x1470 <execve_send+0x10d0>
    1434:      	add	x8, x0, #0x140
    1438:      	b	0x1460 <execve_send+0x10c0>
    143c:      	add	x8, x0, #0x148
    1440:      	b	0x1460 <execve_send+0x10c0>
    1444:      	add	x8, x0, #0x118
    1448:      	b	0x1460 <execve_send+0x10c0>
    144c:      	add	x8, x0, #0x138
    1450:      	b	0x1460 <execve_send+0x10c0>
    1454:      	add	x8, x0, #0x128
    1458:      	nop
    145c:      	nop
    1460:      	ldaxr	x9, [x8]
    1464:      	add	x9, x9, #0x1
    1468:      	stlxr	w10, x9, [x8]
    146c:      	cbnz	w10, 0x1460 <execve_send+0x10c0>
    1470:      	ldp	x20, x19, [sp, #0xe0]
    1474:      	mov	w0, wzr
    1478:      	ldr	x29, [sp, #0xa0]
    147c:      	ldp	x22, x21, [sp, #0xd0]
    1480:      	ldp	x24, x23, [sp, #0xc0]
    1484:      	ldp	x30, x25, [sp, #0xb0]
    1488:      	add	sp, sp, #0xf0
    148c:      	ret

Disassembly of section tracepoint/sys_execve:

0000000000000000 <event_execve>:
       0:      	sub	sp, sp, #0x120
       4:      	str	x29, [sp, #0xd0]
       8:      	stp	x30, x25, [sp, #0xe0]
       c:      	stp	x24, x23, [sp, #0xf0]
      10:      	stp	x22, x21, [sp, #0x100]
      14:      	stp	x20, x19, [sp, #0x110]
      18:      	mov	w8, #0x23               // =35
      1c:      	mov	x25, x0
      20:      	blr	x8
      24:      	mov	x29, x0
      28:      	str	wzr, [sp, #0x3c]
      2c:      	adrp	x0, 0x0 <event_execve>
      30:      	ldrh	w19, [x25, #0x8]
      34:      	mov	w8, #0x1                // =1
      38:      	add	x9, sp, #0x3c
      3c:      	ldr	x0, [x0]
      40:      	add	x1, sp, #0x3c
      44:      	blr	x8
      48:      	cbz	x0, 0x216c <event_execve+0x216c>
      4c:      	mov	w8, #0xe                // =14
      50:      	mov	x20, x0
      54:      	blr	x8
      58:      	mov	w8, #0x23               // =35
      5c:      	mov	x21, x0
      60:      	blr	x8
      64:      	str	x0, [sp, #0x40]
      68:      	add	x8, x0, #0x8e0
      6c:      	mov	w9, #0x8                // =8
      70:      	mov	w10, #0x71              // =113
      74:      	add	x11, sp, #0x40
      78:      	add	x0, sp, #0x40
      7c:      	mov	w1, #0x8                // =8
      80:      	ldr	x8, [sp, #0x40]
      84:      	add	x2, x8, #0x8e0
      88:      	blr	x10
      8c:      	ldr	x8, [sp, #0x40]
      90:      	cbz	x8, 0x3e4 <event_execve+0x3e4>
      94:      	add	x8, x8, #0x8d4
      98:      	mov	w9, #0x4                // =4
      9c:      	mov	w10, #0x71              // =113
      a0:      	add	x11, sp, #0xc8
      a4:      	ldr	x8, [sp, #0x40]
      a8:      	add	x0, sp, #0xc8
      ac:      	mov	w1, #0x4                // =4
      b0:      	add	x2, x8, #0x8d4
      b4:      	blr	x10
      b8:      	ldr	w8, [sp, #0xc8]
      bc:      	adrp	x23, 0x0 <event_execve>
      c0:      	add	x9, sp, #0xb8
      c4:      	add	x1, sp, #0xb8
      c8:      	str	w8, [sp, #0xb8]
      cc:      	mov	w8, #0x1                // =1
      d0:      	ldr	x23, [x23]
      d4:      	mov	x0, x23
      d8:      	blr	x8
      dc:      	cbz	x0, 0xec <event_execve+0xec>
      e0:      	ldr	x8, [x0, #0x8]
      e4:      	mov	x24, x0
      e8:      	cbnz	x8, 0x26c <event_execve+0x26c>
      ec:      	ldr	x8, [sp, #0x40]
      f0:      	mov	w9, #0x8                // =8
      f4:      	mov	w10, #0x71              // =113
      f8:      	add	x11, sp, #0x40
      fc:      	add	x0, sp, #0x40
     100:      	mov	w1, #0x8                // =8
     104:      	add	x8, x8, #0x8e0
     108:      	ldr	x8, [sp, #0x40]
     10c:      	add	x2, x8, #0x8e0
     110:      	blr	x10
     114:      	ldr	x8, [sp, #0x40]
     118:      	cbz	x8, 0x3e4 <event_execve+0x3e4>
     11c:      	add	x8, x8, #0x8d4
     120:      	mov	w9, #0x4                // =4
     124:      	mov	w10, #0x71              // =113
     128:      	add	x11, sp, #0xc8
     12c:      	ldr	x8, [sp, #0x40]
     130:      	add	x0, sp, #0xc8
     134:      	mov	w1, #0x4                // =4
     138:      	add	x2, x8, #0x8d4
     13c:      	blr	x10
     140:      	ldr	w8, [sp, #0xc8]
     144:      	add	x9, sp, #0xb8
     148:      	add	x1, sp, #0xb8
     14c:      	mov	x0, x23
     150:      	str	w8, [sp, #0xb8]
     154:      	mov	w8, #0x1                // =1
     158:      	blr	x8
     15c:      	cbz	x0, 0x16c <event_execve+0x16c>
     160:      	ldr	x8, [x0, #0x8]
     164:      	mov	x24, x0
     168:      	cbnz	x8, 0x26c <event_execve+0x26c>
     16c:      	ldr	x8, [sp, #0x40]
     170:      	mov	w9, #0x8                // =8
     174:      	mov	w10, #0x71              // =113
     178:      	add	x11, sp, #0x40
     17c:      	add	x0, sp, #0x40
     180:      	mov	w1, #0x8                // =8
     184:      	add	x8, x8, #0x8e0
     188:      	ldr	x8, [sp, #0x40]
     18c:      	add	x2, x8, #0x8e0
     190:      	blr	x10
     194:      	ldr	x8, [sp, #0x40]
     198:      	cbz	x8, 0x3e4 <event_execve+0x3e4>
     19c:      	add	x8, x8, #0x8d4
     1a0:      	mov	w9, #0x4                // =4
     1a4:      	mov	w10, #0x71              // =113
     1a8:      	add	x11, sp, #0xc8
     1ac:      	ldr	x8, [sp, #0x40]
     1b0:      	add	x0, sp, #0xc8
     1b4:      	mov	w1, #0x4                // =4
     1b8:      	add	x2, x8, #0x8d4
     1bc:      	blr	x10
     1c0:      	ldr	w8, [sp, #0xc8]
     1c4:      	add	x9, sp, #0xb8
     1c8:      	add	x1, sp, #0xb8
     1cc:      	mov	x0, x23
     1d0:      	str	w8, [sp, #0xb8]
     1d4:      	mov	w8, #0x1                // =1
     1d8:      	blr	x8
     1dc:      	cbz	x0, 0x1ec <event_execve+0x1ec>
     1e0:      	ldr	x8, [x0, #0x8]
     1e4:      	mov	x24, x0
     1e8:      	cbnz	x8, 0x26c <event_execve+0x26c>
     1ec:      	ldr	x8, [sp, #0x40]
     1f0:      	mov	w9, #0x8                // =8
     1f4:      	mov	w10, #0x71              // =113
     1f8:      	add	x11, sp, #0x40
     1fc:      	add	x0, sp, #0x40
     200:      	mov	w1, #0x8                // =8
     204:      	add	x8, x8, #0x8e0
     208:      	ldr	x8, [sp, #0x40]
     20c:      	add	x2, x8, #0x8e0
     210:      	blr	x10
     214:      	ldr	x8, [sp, #0x40]
     218:      	cbz	x8, 0x3e4 <event_execve+0x3e4>
     21c:      	add	x8, x8, #0x8d4
     220:      	mov	w9, #0x4                // =4
     224:      	mov	w10, #0x71              // =113
     228:      	add	x11, sp, #0xc8
     22c:      	ldr	x8, [sp, #0x40]
     230:      	add	x0, sp, #0xc8
     234:      	mov	w1, #0x4                // =4
     238:      	add	x2, x8, #0x8d4
     23c:      	blr	x10
     240:      	ldr	w8, [sp, #0xc8]
     244:      	add	x9, sp, #0xb8
     248:      	add	x1, sp, #0xb8
     24c:      	mov	x0, x23
     250:      	str	w8, [sp, #0xb8]
     254:      	mov	w8, #0x1                // =1
     258:      	blr	x8
     25c:      	cbz	x0, 0x3e4 <event_execve+0x3e4>
     260:      	ldr	x8, [x0, #0x8]
     264:      	mov	x24, x0
     268:      	cbz	x8, 0x3e4 <event_execve+0x3e4>
     26c:      	ldp	x8, x9, [x24]
     270:      	adrp	x0, 0x0 <event_execve>
     274:      	add	x1, sp, #0xb8
     278:      	str	wzr, [sp, #0xb8]
     27c:      	stp	x8, x9, [x20, #0xa0]
     280:      	mov	w8, #0x1                // =1
     284:      	add	x9, sp, #0xb8
     288:      	ldr	x0, [x0]
     28c:      	blr	x8
     290:      	cbz	x0, 0x3dc <event_execve+0x3dc>
     294:      	ldr	x8, [x0]
     298:      	ldr	x9, [x24, #0x378]
     29c:      	cmp	x8, x9
     2a0:      	b.eq	0x3dc <event_execve+0x3dc>
     2a4:      	stp	x19, x21, [sp, #0x28]
     2a8:      	adrp	x8, 0x0 <event_execve>
     2ac:      	mov	w21, wzr
     2b0:      	mov	x22, xzr
     2b4:      	str	x0, [sp, #0xd8]
     2b8:      	stp	x29, x25, [sp, #0x18]
     2bc:      	adrp	x25, 0x0 <event_execve>
     2c0:      	add	x29, x24, #0x370
     2c4:      	ldr	x8, [x8]
     2c8:      	ldrb	w8, [x8]
     2cc:      	ldr	x25, [x25]
     2d0:      	cbz	w8, 0x3a8 <event_execve+0x3a8>
     2d4:      	nop
     2d8:      	nop
     2dc:      	nop
     2e0:      	ldr	w8, [x24, #0x10]
     2e4:      	add	x9, sp, #0x40
     2e8:      	add	x1, sp, #0x40
     2ec:      	mov	x0, x23
     2f0:      	str	w8, [sp, #0x40]
     2f4:      	mov	w8, #0x1                // =1
     2f8:      	blr	x8
     2fc:      	cbz	x0, 0x3c8 <event_execve+0x3c8>
     300:      	add	x1, x0, #0x70
     304:      	mov	w8, #0x1                // =1
     308:      	mov	x19, x0
     30c:      	mov	x0, x25
     310:      	blr	x8
     314:      	cbz	x0, 0x330 <event_execve+0x330>
     318:      	ldr	x8, [x0]
     31c:      	cbz	x8, 0x330 <event_execve+0x330>
     320:      	ldaxr	x9, [x29]
     324:      	orr	x9, x9, x8
     328:      	stlxr	w10, x9, [x29]
     32c:      	cbnz	w10, 0x320 <event_execve+0x320>
     330:      	cmp	x19, x22
     334:      	b.eq	0x3c8 <event_execve+0x3c8>
     338:      	mov	w8, #0x86a0             // =34464
     33c:      	add	w21, w21, #0x1
     340:      	mov	x22, x19
     344:      	movk	w8, #0x1, lsl #16
     348:      	cmp	w21, w8
     34c:      	b.ne	0x2e0 <event_execve+0x2e0>
     350:      	b	0x3c8 <event_execve+0x3c8>
     354:      	nop
     358:      	nop
     35c:      	nop
     360:      	add	x1, x0, #0x70
     364:      	mov	w8, #0x1                // =1
     368:      	mov	x19, x0
     36c:      	mov	x0, x25
     370:      	blr	x8
     374:      	cbz	x0, 0x390 <event_execve+0x390>
     378:      	ldr	x8, [x0]
     37c:      	cbz	x8, 0x390 <event_execve+0x390>
     380:      	ldaxr	x9, [x29]
     384:      	orr	x9, x9, x8
     388:      	stlxr	w10, x9, [x29]
     38c:      	cbnz	w10, 0x380 <event_execve+0x380>
     390:      	cmp	x19, x22
     394:      	b.eq	0x3c8 <event_execve+0x3c8>
     398:      	add	w21, w21, #0x1
     39c:      	mov	x22, x19
     3a0:      	cmp	w21, #0x400
     3a4:      	b.eq	0x3c8 <event_execve+0x3c8>
     3a8:      	ldr	w8, [x24, #0x10]
     3ac:      	add	x9, sp, #0x40
     3b0:      	add	x1, sp, #0x40
     3b4:      	mov	x0, x23
     3b8:      	str	w8, [sp, #0x40]
     3bc:      	mov	w8, #0x1                // =1
     3c0:      	blr	x8
     3c4:      	cbnz	x0, 0x360 <event_execve+0x360>
     3c8:      	ldr	x8, [sp, #0xd8]
     3cc:      	ldp	x29, x25, [sp, #0x18]
     3d0:      	ldr	x8, [x8]
     3d4:      	ldp	x19, x21, [sp, #0x28]
     3d8:      	str	x8, [x24, #0x378]
     3dc:      	mov	x8, xzr
     3e0:      	b	0x434 <event_execve+0x434>
     3e4:      	add	x2, x29, #0x8e0
     3e8:      	mov	w8, #0x8                // =8
     3ec:      	mov	w9, #0x71               // =113
     3f0:      	add	x10, sp, #0x40
     3f4:      	add	x0, sp, #0x40
     3f8:      	mov	w1, #0x8                // =8
     3fc:      	blr	x9
     400:      	ldr	x8, [sp, #0x40]
     404:      	cbz	x8, 0x428 <event_execve+0x428>
     408:      	add	x2, x8, #0x8d4
     40c:      	mov	w8, #0x4                // =4
     410:      	mov	w9, #0x71               // =113
     414:      	add	x10, sp, #0x40
     418:      	add	x0, sp, #0x40
     41c:      	mov	w1, #0x4                // =4
     420:      	blr	x9
     424:      	ldr	w8, [sp, #0x40]
     428:      	str	w8, [x20, #0xa0]
     42c:      	mov	w8, #0x40               // =64
     430:      	str	xzr, [x20, #0xa8]
     434:      	str	x8, [x20, #0xb0]
     438:      	mov	w8, #0x1                // =1
     43c:      	str	xzr, [x20, #0x178]
     440:      	str	w21, [x20, #0x148]
     444:      	str	w8, [x20, #0x15c]
     448:      	lsr	x8, x21, #32
     44c:      	str	w8, [x20, #0x144]
     450:      	mov	w8, #0x23               // =35
     454:      	blr	x8
     458:      	add	x2, x0, #0x60
     45c:      	mov	w8, #0x8                // =8
     460:      	mov	w9, #0x71               // =113
     464:      	add	x10, sp, #0xb8
     468:      	add	x0, sp, #0xb8
     46c:      	mov	w1, #0x8                // =8
     470:      	blr	x9
     474:      	ldr	x8, [sp, #0xb8]
     478:      	cbz	x8, 0x4e8 <event_execve+0x4e8>
     47c:      	add	x8, x8, #0x4
     480:      	mov	w9, #0x4                // =4
     484:      	mov	w10, #0x71              // =113
     488:      	add	x11, sp, #0xc8
     48c:      	ldr	x8, [sp, #0xb8]
     490:      	add	x0, sp, #0xc8
     494:      	mov	w1, #0x4                // =4
     498:      	add	x2, x8, #0x4
     49c:      	blr	x10
     4a0:      	ldr	w8, [sp, #0xc8]
     4a4:      	cbz	w8, 0x4e8 <event_execve+0x4e8>
     4a8:      	ldr	x9, [sp, #0xb8]
     4ac:      	lsl	w8, w8, #4
     4b0:      	mov	w10, #0x71              // =113
     4b4:      	add	x11, sp, #0x40
     4b8:      	add	x0, sp, #0x40
     4bc:      	mov	w1, #0x10               // =16
     4c0:      	add	x8, x9, x8
     4c4:      	mov	w9, #0x10               // =16
     4c8:      	add	x8, x8, #0x80
     4cc:      	ldr	w9, [sp, #0xc8]
     4d0:      	ldr	x8, [sp, #0xb8]
     4d4:      	lsl	w9, w9, #4
     4d8:      	add	x8, x8, x9
     4dc:      	add	x2, x8, #0x80
     4e0:      	blr	x10
     4e4:      	ldr	w8, [sp, #0x40]
     4e8:      	str	w8, [x20, #0x14c]
     4ec:      	mov	w8, #0x7d               // =125
     4f0:      	add	x23, x25, x19
     4f4:      	blr	x8
     4f8:      	mov	w8, #0x40               // =64
     4fc:      	str	x0, [x20, #0x170]
     500:      	str	w8, [x20, #0x140]
     504:      	mov	w8, #0x23               // =35
     508:      	blr	x8
     50c:      	str	xzr, [sp, #0x40]
     510:      	cbz	x0, 0x538 <event_execve+0x538>
     514:      	add	x2, x0, #0x70
     518:      	mov	w8, #0x8                // =8
     51c:      	mov	w9, #0x4                // =4
     520:      	add	x10, sp, #0x40
     524:      	add	x0, sp, #0x40
     528:      	mov	w1, #0x8                // =8
     52c:      	blr	x9
     530:      	ldr	x8, [sp, #0x40]
     534:      	b	0x53c <event_execve+0x53c>
     538:      	mov	x8, xzr
     53c:      	str	w8, [x20, #0x158]
     540:      	str	x21, [sp, #0x40]
     544:      	adrp	x19, 0x0 <event_execve>
     548:      	mov	w8, #0x1                // =1
     54c:      	add	x9, sp, #0x40
     550:      	add	x1, sp, #0x40
     554:      	ldr	x19, [x19]
     558:      	mov	x0, x19
     55c:      	blr	x8
     560:      	cbz	x0, 0x5c8 <event_execve+0x5c8>
     564:      	ldr	w8, [x0]
     568:      	add	x9, sp, #0x40
     56c:      	add	x1, sp, #0x40
     570:      	str	w8, [x20, #0x150]
     574:      	ldr	x8, [x0, #0x8]
     578:      	str	x8, [x20, #0x168]
     57c:      	ldr	w8, [x0, #0x4]
     580:      	str	x21, [sp, #0x40]
     584:      	mov	x0, x19
     588:      	str	w8, [x20, #0x160]
     58c:      	mov	w8, #0x3                // =3
     590:      	blr	x8
     594:      	cbz	w0, 0x5d8 <event_execve+0x5d8>
     598:      	mov	w8, #0x2                // =2
     59c:      	adrp	x0, 0x0 <event_execve>
     5a0:      	add	x9, sp, #0xb8
     5a4:      	str	w8, [sp, #0xb8]
     5a8:      	mov	w8, #0x1                // =1
     5ac:      	add	x1, sp, #0xb8
     5b0:      	ldr	x0, [x0]
     5b4:      	blr	x8
     5b8:      	cbz	x0, 0x604 <event_execve+0x604>
     5bc:      	ldr	x8, [x0]
     5c0:      	add	x8, x8, #0x1
     5c4:      	b	0x600 <event_execve+0x600>
     5c8:      	str	wzr, [x20, #0x150]
     5cc:      	str	xzr, [x20, #0x168]
     5d0:      	str	wzr, [x20, #0x160]
     5d4:      	b	0x604 <event_execve+0x604>
     5d8:      	str	wzr, [sp, #0xb8]
     5dc:      	adrp	x0, 0x0 <event_execve>
     5e0:      	mov	w8, #0x1                // =1
     5e4:      	add	x9, sp, #0xb8
     5e8:      	ldr	x0, [x0]
     5ec:      	add	x1, sp, #0xb8
     5f0:      	blr	x8
     5f4:      	cbz	x0, 0x604 <event_execve+0x604>
     5f8:      	ldr	x8, [x0]
     5fc:      	sub	x8, x8, #0x1
     600:      	str	x8, [x0]
     604:      	add	x0, x20, #0x180
     608:      	mov	w8, #0xff               // =255
     60c:      	mov	w9, #0x2d               // =45
     610:      	mov	w1, #0xff               // =255
     614:      	mov	x2, x23
     618:      	blr	x9
     61c:      	tbnz	w0, #0x1f, 0x6e0 <event_execve+0x6e0>
     620:      	cbz	w0, 0x6ec <event_execve+0x6ec>
     624:      	cmp	w0, #0xff
     628:      	b.ne	0x6f4 <event_execve+0x6f4>
     62c:      	str	wzr, [sp, #0xb8]
     630:      	adrp	x0, 0x0 <event_execve>
     634:      	mov	w8, #0x1                // =1
     638:      	add	x9, sp, #0xb8
     63c:      	ldr	x0, [x0]
     640:      	add	x1, sp, #0xb8
     644:      	blr	x8
     648:      	cbz	x0, 0x6e0 <event_execve+0x6e0>
     64c:      	mov	w8, #0x18               // =24
     650:      	mov	x19, x0
     654:      	str	w8, [x0]
     658:      	mov	w8, #0xe                // =14
     65c:      	blr	x8
     660:      	mov	x21, x19
     664:      	cmn	x0, #0x16
     668:      	str	x0, [x21, #0x10]!
     66c:      	b.ne	0x694 <event_execve+0x694>
     670:      	add	x2, x25, #0xe8
     674:      	mov	w8, #0x8                // =8
     678:      	mov	w9, #0x4                // =4
     67c:      	add	x10, sp, #0x40
     680:      	add	x0, sp, #0x40
     684:      	mov	w1, #0x8                // =8
     688:      	blr	x9
     68c:      	ldr	x8, [sp, #0x40]
     690:      	str	x8, [x21]
     694:      	mov	w8, #0x7d               // =125
     698:      	blr	x8
     69c:      	str	x0, [x19, #0x18]
     6a0:      	mov	x0, x25
     6a4:      	mov	x1, x19
     6a8:      	mov	x2, x23
     6ac:      	ldp	x8, x9, [x21]
     6b0:      	stp	x8, x9, [x20, #0x190]
     6b4:      	bl	0x6b4 <event_execve+0x6b4>
     6b8:      	asr	w8, w0, #31
     6bc:      	and	w9, w0, w8
     6c0:      	bic	w8, w0, w8
     6c4:      	mov	w0, #0x800000           // =8388608
     6c8:      	str	w9, [x20, #0x180]
     6cc:      	add	x9, x20, #0x184
     6d0:      	str	w8, [x20, #0x18c]
     6d4:      	mov	w8, #0x20               // =32
     6d8:      	str	xzr, [x9]
     6dc:      	b	0x6fc <event_execve+0x6fc>
     6e0:      	mov	w8, wzr
     6e4:      	mov	w0, #0x100              // =256
     6e8:      	b	0x6fc <event_execve+0x6fc>
     6ec:      	mov	w8, w0
     6f0:      	b	0x6fc <event_execve+0x6fc>
     6f4:      	sub	w8, w0, #0x1
     6f8:      	mov	w0, wzr
     6fc:      	ldr	w9, [x20, #0x15c]
     700:      	strh	w8, [x20, #0x178]
     704:      	orr	w9, w9, w0
     708:      	str	w9, [x20, #0x15c]
     70c:      	ldr	w9, [x20, #0x140]
     710:      	add	w8, w9, w8
     714:      	str	w8, [x20, #0x140]
     718:      	mov	w8, #0x23               // =35
     71c:      	blr	x8
     720:      	str	wzr, [sp, #0xa0]
     724:      	add	x2, x0, #0x858
     728:      	mov	w8, #0x8                // =8
     72c:      	mov	w9, #0x4                // =4
     730:      	add	x10, sp, #0xb0
     734:      	add	x0, sp, #0xb0
     738:      	mov	w1, #0x8                // =8
     73c:      	blr	x9
     740:      	adrp	x23, 0x0 <event_execve>
     744:      	ldr	x23, [x23]
     748:      	cbz	x0, 0x790 <event_execve+0x790>
     74c:      	neg	w8, w0
     750:      	mov	w9, #0x1                // =1
     754:      	add	x1, sp, #0x40
     758:      	strh	w8, [sp, #0x40]
     75c:      	mov	w8, #0x9                // =9
     760:      	mov	x0, x23
     764:      	mov	w19, #0x1               // =1
     768:      	strh	w8, [sp, #0x42]
     76c:      	mov	x8, #0x42               // =66
     770:      	movk	x8, #0x4, lsl #32
     774:      	stur	x8, [sp, #0x44]
     778:      	add	x8, sp, #0x40
     77c:      	blr	x9
     780:      	cbz	x0, 0x810 <event_execve+0x810>
     784:      	ldr	w8, [x0]
     788:      	add	w8, w8, #0x1
     78c:      	str	w8, [x0]
     790:      	ldr	x8, [sp, #0xb0]
     794:      	add	x22, x20, #0x140
     798:      	add	x24, sp, #0xb8
     79c:      	cbz	x8, 0x9e0 <event_execve+0x9e0>
     7a0:      	add	x8, x8, #0x278
     7a4:      	mov	w9, #0x8                // =8
     7a8:      	mov	w10, #0x4               // =4
     7ac:      	add	x11, sp, #0xb8
     7b0:      	ldr	x8, [sp, #0xb0]
     7b4:      	add	x0, sp, #0xb8
     7b8:      	mov	w1, #0x8                // =8
     7bc:      	add	x2, x8, #0x278
     7c0:      	blr	x10
     7c4:      	cbz	x0, 0x86c <event_execve+0x86c>
     7c8:      	neg	w8, w0
     7cc:      	mov	w9, #0x1                // =1
     7d0:      	add	x1, sp, #0x40
     7d4:      	strh	w8, [sp, #0x40]
     7d8:      	mov	w8, #0x9                // =9
     7dc:      	mov	x0, x23
     7e0:      	mov	w19, #0x1               // =1
     7e4:      	strh	w8, [sp, #0x42]
     7e8:      	mov	x8, #0x47               // =71
     7ec:      	movk	x8, #0x4, lsl #32
     7f0:      	stur	x8, [sp, #0x44]
     7f4:      	add	x8, sp, #0x40
     7f8:      	blr	x9
     7fc:      	cbz	x0, 0x848 <event_execve+0x848>
     800:      	ldr	w8, [x0]
     804:      	add	w8, w8, #0x1
     808:      	str	w8, [x0]
     80c:      	b	0x86c <event_execve+0x86c>
     810:      	str	w19, [sp, #0xb8]
     814:      	mov	x3, xzr
     818:      	mov	w8, #0x2                // =2
     81c:      	add	x9, sp, #0x40
     820:      	add	x10, sp, #0xb8
     824:      	add	x1, sp, #0x40
     828:      	add	x2, sp, #0xb8
     82c:      	mov	x0, x23
     830:      	blr	x8
     834:      	ldr	x8, [sp, #0xb0]
     838:      	add	x22, x20, #0x140
     83c:      	add	x24, sp, #0xb8
     840:      	cbnz	x8, 0x7a0 <event_execve+0x7a0>
     844:      	b	0x9e0 <event_execve+0x9e0>
     848:      	str	w19, [sp, #0xc8]
     84c:      	mov	x3, xzr
     850:      	mov	w8, #0x2                // =2
     854:      	add	x9, sp, #0x40
     858:      	add	x10, sp, #0xc8
     85c:      	add	x1, sp, #0x40
     860:      	add	x2, sp, #0xc8
     864:      	mov	x0, x23
     868:      	blr	x8
     86c:      	ldr	x8, [sp, #0xb0]
     870:      	mov	w9, #0x8                // =8
     874:      	mov	w10, #0x4               // =4
     878:      	add	x11, sp, #0xc8
     87c:      	add	x0, sp, #0xc8
     880:      	mov	w1, #0x8                // =8
     884:      	add	x8, x8, #0x280
     888:      	ldr	x8, [sp, #0xb0]
     88c:      	add	x2, x8, #0x280
     890:      	blr	x10
     894:      	cbz	x0, 0x8dc <event_execve+0x8dc>
     898:      	neg	w8, w0
     89c:      	mov	w9, #0x1                // =1
     8a0:      	add	x1, sp, #0x40
     8a4:      	strh	w8, [sp, #0x40]
     8a8:      	mov	w8, #0x9                // =9
     8ac:      	mov	x0, x23
     8b0:      	mov	w19, #0x1               // =1
     8b4:      	strh	w8, [sp, #0x42]
     8b8:      	mov	x8, #0x48               // =72
     8bc:      	movk	x8, #0x4, lsl #32
     8c0:      	stur	x8, [sp, #0x44]
     8c4:      	add	x8, sp, #0x40
     8c8:      	blr	x9
     8cc:      	cbz	x0, 0xa00 <event_execve+0xa00>
     8d0:      	ldr	w8, [x0]
     8d4:      	add	w8, w8, #0x1
     8d8:      	str	w8, [x0]
     8dc:      	ldr	x8, [sp, #0xb8]
     8e0:      	mov	w19, wzr
     8e4:      	cbz	x8, 0xa38 <event_execve+0xa38>
     8e8:      	ldr	x8, [x24, #0x10]
     8ec:      	cbz	x8, 0xa38 <event_execve+0xa38>
     8f0:      	adrp	x0, 0x0 <event_execve>
     8f4:      	mov	w8, #0x1                // =1
     8f8:      	add	x9, sp, #0xa0
     8fc:      	ldr	x0, [x0]
     900:      	add	x1, sp, #0xa0
     904:      	blr	x8
     908:      	cbz	x0, 0x9e0 <event_execve+0x9e0>
     90c:      	ldr	x8, [sp, #0xb8]
     910:      	mov	w9, #0x1000             // =4096
     914:      	mov	w10, #0x2d              // =45
     918:      	mov	w1, #0x1000             // =4096
     91c:      	ldr	x2, [sp, #0xb8]
     920:      	blr	x10
     924:      	tbnz	x0, #0x3f, 0xa34 <event_execve+0xa34>
     928:      	ldr	x8, [sp, #0xb8]
     92c:      	str	x22, [sp, #0xd8]
     930:      	add	x22, x8, x0
     934:      	ldr	w8, [x20, #0x140]
     938:      	str	x22, [sp, #0xb8]
     93c:      	and	x8, x8, #0x1ff
     940:      	add	x21, x20, x8
     944:      	str	w8, [x20, #0x184c]
     948:      	ldr	x8, [x24, #0x10]
     94c:      	sub	x19, x8, x22
     950:      	cmp	x19, #0x3ff
     954:      	b.hi	0x10f4 <event_execve+0x10f4>
     958:      	add	x9, x20, #0x140
     95c:      	add	x0, x21, #0x140
     960:      	sub	x9, x9, x0
     964:      	add	x9, x9, #0x400
     968:      	cmp	x19, x9
     96c:      	b.hs	0x10f4 <event_execve+0x10f4>
     970:      	sub	w9, w19, #0x1
     974:      	cmp	x8, x22
     978:      	mov	w8, #0x4                // =4
     97c:      	and	w9, w9, #0x3ff
     980:      	csel	w19, wzr, w9, eq
     984:      	ldr	x2, [sp, #0xb8]
     988:      	mov	w1, w19
     98c:      	blr	x8
     990:      	cbz	x0, 0x1210 <event_execve+0x1210>
     994:      	mov	x22, x0
     998:      	mov	w9, #0x1                // =1
     99c:      	add	x1, sp, #0x40
     9a0:      	mov	x0, x23
     9a4:      	mov	w21, #0x1               // =1
     9a8:      	neg	w8, w22
     9ac:      	strh	w8, [sp, #0x40]
     9b0:      	mov	w8, #0x9                // =9
     9b4:      	strh	w8, [sp, #0x42]
     9b8:      	mov	x8, #0x6c               // =108
     9bc:      	movk	x8, #0x4, lsl #32
     9c0:      	stur	x8, [sp, #0x44]
     9c4:      	add	x8, sp, #0x40
     9c8:      	blr	x9
     9cc:      	cbz	x0, 0x11d8 <event_execve+0x11d8>
     9d0:      	ldr	w8, [x0]
     9d4:      	add	w8, w8, #0x1
     9d8:      	str	w8, [x0]
     9dc:      	b	0x11fc <event_execve+0x11fc>
     9e0:      	mov	w19, wzr
     9e4:      	ldr	w8, [x20, #0x140]
     9e8:      	add	w9, w8, w19
     9ec:      	ldrb	w8, [x20, #0x15d]
     9f0:      	str	w9, [x20, #0x140]
     9f4:      	tbz	w8, #0x5, 0xa4c <event_execve+0xa4c>
     9f8:      	mov	w8, wzr
     9fc:      	b	0x1800 <event_execve+0x1800>
     a00:      	str	w19, [sp, #0xa8]
     a04:      	mov	x3, xzr
     a08:      	mov	w8, #0x2                // =2
     a0c:      	add	x9, sp, #0x40
     a10:      	add	x10, sp, #0xa8
     a14:      	add	x1, sp, #0x40
     a18:      	add	x2, sp, #0xa8
     a1c:      	mov	x0, x23
     a20:      	blr	x8
     a24:      	ldr	x8, [sp, #0xb8]
     a28:      	mov	w19, wzr
     a2c:      	cbnz	x8, 0x8e8 <event_execve+0x8e8>
     a30:      	b	0xa38 <event_execve+0xa38>
     a34:      	mov	w19, wzr
     a38:      	ldr	w8, [x20, #0x140]
     a3c:      	add	w9, w8, w19
     a40:      	ldrb	w8, [x20, #0x15d]
     a44:      	str	w9, [x20, #0x140]
     a48:      	tbnz	w8, #0x5, 0x9f8 <event_execve+0x9f8>
     a4c:      	str	w9, [sp, #0x28]
     a50:      	ldr	w19, [x20, #0x144]
     a54:      	mov	w8, #0x23               // =35
     a58:      	blr	x8
     a5c:      	mov	x23, x0
     a60:      	str	wzr, [sp, #0xb8]
     a64:      	str	x22, [sp, #0xd8]
     a68:      	cbz	x0, 0x1240 <event_execve+0x1240>
     a6c:      	add	x2, x23, #0x8d4
     a70:      	mov	w8, #0x4                // =4
     a74:      	mov	w9, #0x71               // =113
     a78:      	add	x10, sp, #0xb8
     a7c:      	add	x0, sp, #0xb8
     a80:      	mov	w1, #0x4                // =4
     a84:      	blr	x9
     a88:      	ldr	w8, [sp, #0xb8]
     a8c:      	cmp	w8, w19
     a90:      	b.eq	0x1240 <event_execve+0x1240>
     a94:      	add	x2, x23, #0x8e0
     a98:      	mov	w8, #0x8                // =8
     a9c:      	mov	w9, #0x71               // =113
     aa0:      	add	x10, sp, #0x40
     aa4:      	add	x0, sp, #0x40
     aa8:      	mov	w1, #0x8                // =8
     aac:      	blr	x9
     ab0:      	ldr	x23, [sp, #0x40]
     ab4:      	cbz	x23, 0x1240 <event_execve+0x1240>
     ab8:      	add	x2, x23, #0x8d4
     abc:      	mov	w8, #0x4                // =4
     ac0:      	mov	w9, #0x71               // =113
     ac4:      	add	x10, sp, #0xb8
     ac8:      	add	x0, sp, #0xb8
     acc:      	mov	w1, #0x4                // =4
     ad0:      	blr	x9
     ad4:      	ldr	w8, [sp, #0xb8]
     ad8:      	cmp	w8, w19
     adc:      	b.eq	0x1240 <event_execve+0x1240>
     ae0:      	add	x2, x23, #0x8e0
     ae4:      	mov	w8, #0x8                // =8
     ae8:      	mov	w9, #0x71               // =113
     aec:      	add	x10, sp, #0x40
     af0:      	add	x0, sp, #0x40
     af4:      	mov	w1, #0x8                // =8
     af8:      	blr	x9
     afc:      	ldr	x23, [sp, #0x40]
     b00:      	cbz	x23, 0x1240 <event_execve+0x1240>
     b04:      	add	x2, x23, #0x8d4
     b08:      	mov	w8, #0x4                // =4
     b0c:      	mov	w9, #0x71               // =113
     b10:      	add	x10, sp, #0xb8
     b14:      	add	x0, sp, #0xb8
     b18:      	mov	w1, #0x4                // =4
     b1c:      	blr	x9
     b20:      	ldr	w8, [sp, #0xb8]
     b24:      	cmp	w8, w19
     b28:      	b.eq	0x1240 <event_execve+0x1240>
     b2c:      	add	x2, x23, #0x8e0
     b30:      	mov	w8, #0x8                // =8
     b34:      	mov	w9, #0x71               // =113
     b38:      	add	x10, sp, #0x40
     b3c:      	add	x0, sp, #0x40
     b40:      	mov	w1, #0x8                // =8
     b44:      	blr	x9
     b48:      	ldr	x23, [sp, #0x40]
     b4c:      	cbz	x23, 0x1240 <event_execve+0x1240>
     b50:      	add	x2, x23, #0x8d4
     b54:      	mov	w8, #0x4                // =4
     b58:      	mov	w9, #0x71               // =113
     b5c:      	add	x10, sp, #0xb8
     b60:      	add	x0, sp, #0xb8
     b64:      	mov	w1, #0x4                // =4
     b68:      	blr	x9
     b6c:      	ldr	w8, [sp, #0xb8]
     b70:      	cmp	w8, w19
     b74:      	b.eq	0x1240 <event_execve+0x1240>
     b78:      	add	x2, x23, #0x8e0
     b7c:      	mov	w8, #0x8                // =8
     b80:      	mov	w9, #0x71               // =113
     b84:      	add	x10, sp, #0x40
     b88:      	add	x0, sp, #0x40
     b8c:      	mov	w1, #0x8                // =8
     b90:      	blr	x9
     b94:      	ldr	x23, [sp, #0x40]
     b98:      	cbz	x23, 0x1240 <event_execve+0x1240>
     b9c:      	add	x2, x23, #0x8d4
     ba0:      	mov	w8, #0x4                // =4
     ba4:      	mov	w9, #0x71               // =113
     ba8:      	add	x10, sp, #0xb8
     bac:      	add	x0, sp, #0xb8
     bb0:      	mov	w1, #0x4                // =4
     bb4:      	blr	x9
     bb8:      	ldr	w8, [sp, #0xb8]
     bbc:      	cmp	w8, w19
     bc0:      	b.eq	0x1240 <event_execve+0x1240>
     bc4:      	add	x2, x23, #0x8e0
     bc8:      	mov	w8, #0x8                // =8
     bcc:      	mov	w9, #0x71               // =113
     bd0:      	add	x10, sp, #0x40
     bd4:      	add	x0, sp, #0x40
     bd8:      	mov	w1, #0x8                // =8
     bdc:      	blr	x9
     be0:      	ldr	x23, [sp, #0x40]
     be4:      	cbz	x23, 0x1240 <event_execve+0x1240>
     be8:      	add	x2, x23, #0x8d4
     bec:      	mov	w8, #0x4                // =4
     bf0:      	mov	w9, #0x71               // =113
     bf4:      	add	x10, sp, #0xb8
     bf8:      	add	x0, sp, #0xb8
     bfc:      	mov	w1, #0x4                // =4
     c00:      	blr	x9
     c04:      	ldr	w8, [sp, #0xb8]
     c08:      	cmp	w8, w19
     c0c:      	b.eq	0x1240 <event_execve+0x1240>
     c10:      	add	x2, x23, #0x8e0
     c14:      	mov	w8, #0x8                // =8
     c18:      	mov	w9, #0x71               // =113
     c1c:      	add	x10, sp, #0x40
     c20:      	add	x0, sp, #0x40
     c24:      	mov	w1, #0x8                // =8
     c28:      	blr	x9
     c2c:      	ldr	x23, [sp, #0x40]
     c30:      	cbz	x23, 0x1240 <event_execve+0x1240>
     c34:      	add	x2, x23, #0x8d4
     c38:      	mov	w8, #0x4                // =4
     c3c:      	mov	w9, #0x71               // =113
     c40:      	add	x10, sp, #0xb8
     c44:      	add	x0, sp, #0xb8
     c48:      	mov	w1, #0x4                // =4
     c4c:      	blr	x9
     c50:      	ldr	w8, [sp, #0xb8]
     c54:      	cmp	w8, w19
     c58:      	b.eq	0x1240 <event_execve+0x1240>
     c5c:      	add	x2, x23, #0x8e0
     c60:      	mov	w8, #0x8                // =8
     c64:      	mov	w9, #0x71               // =113
     c68:      	add	x10, sp, #0x40
     c6c:      	add	x0, sp, #0x40
     c70:      	mov	w1, #0x8                // =8
     c74:      	blr	x9
     c78:      	ldr	x23, [sp, #0x40]
     c7c:      	cbz	x23, 0x1240 <event_execve+0x1240>
     c80:      	add	x2, x23, #0x8d4
     c84:      	mov	w8, #0x4                // =4
     c88:      	mov	w9, #0x71               // =113
     c8c:      	add	x10, sp, #0xb8
     c90:      	add	x0, sp, #0xb8
     c94:      	mov	w1, #0x4                // =4
     c98:      	blr	x9
     c9c:      	ldr	w8, [sp, #0xb8]
     ca0:      	cmp	w8, w19
     ca4:      	b.eq	0x1240 <event_execve+0x1240>
     ca8:      	add	x2, x23, #0x8e0
     cac:      	mov	w8, #0x8                // =8
     cb0:      	mov	w9, #0x71               // =113
     cb4:      	add	x10, sp, #0x40
     cb8:      	add	x0, sp, #0x40
     cbc:      	mov	w1, #0x8                // =8
     cc0:      	mov	x22, x29
     cc4:      	mov	x21, x25
     cc8:      	blr	x9
     ccc:      	ldr	x23, [sp, #0x40]
     cd0:      	cbz	x23, 0x1234 <event_execve+0x1234>
     cd4:      	add	x2, x23, #0x8d4
     cd8:      	mov	w8, #0x4                // =4
     cdc:      	mov	w9, #0x71               // =113
     ce0:      	add	x10, sp, #0xb8
     ce4:      	add	x0, sp, #0xb8
     ce8:      	mov	w1, #0x4                // =4
     cec:      	blr	x9
     cf0:      	ldr	w8, [sp, #0xb8]
     cf4:      	mov	x25, x21
     cf8:      	mov	x29, x22
     cfc:      	add	x24, sp, #0xb8
     d00:      	cmp	w8, w19
     d04:      	b.eq	0x1240 <event_execve+0x1240>
     d08:      	add	x2, x23, #0x8e0
     d0c:      	mov	w8, #0x8                // =8
     d10:      	mov	w9, #0x71               // =113
     d14:      	add	x10, sp, #0x40
     d18:      	add	x0, sp, #0x40
     d1c:      	mov	w1, #0x8                // =8
     d20:      	blr	x9
     d24:      	ldr	x23, [sp, #0x40]
     d28:      	cbz	x23, 0x1234 <event_execve+0x1234>
     d2c:      	add	x2, x23, #0x8d4
     d30:      	mov	w8, #0x4                // =4
     d34:      	mov	w9, #0x71               // =113
     d38:      	add	x10, sp, #0xb8
     d3c:      	add	x0, sp, #0xb8
     d40:      	mov	w1, #0x4                // =4
     d44:      	blr	x9
     d48:      	ldr	w8, [sp, #0xb8]
     d4c:      	mov	x25, x21
     d50:      	mov	x29, x22
     d54:      	add	x24, sp, #0xb8
     d58:      	cmp	w8, w19
     d5c:      	b.eq	0x1240 <event_execve+0x1240>
     d60:      	add	x2, x23, #0x8e0
     d64:      	mov	w8, #0x8                // =8
     d68:      	mov	w9, #0x71               // =113
     d6c:      	add	x10, sp, #0x40
     d70:      	add	x0, sp, #0x40
     d74:      	mov	w1, #0x8                // =8
     d78:      	blr	x9
     d7c:      	ldr	x23, [sp, #0x40]
     d80:      	cbz	x23, 0x1234 <event_execve+0x1234>
     d84:      	add	x2, x23, #0x8d4
     d88:      	mov	w8, #0x4                // =4
     d8c:      	mov	w9, #0x71               // =113
     d90:      	add	x10, sp, #0xb8
     d94:      	add	x0, sp, #0xb8
     d98:      	mov	w1, #0x4                // =4
     d9c:      	blr	x9
     da0:      	ldr	w8, [sp, #0xb8]
     da4:      	mov	x25, x21
     da8:      	mov	x29, x22
     dac:      	add	x24, sp, #0xb8
     db0:      	cmp	w8, w19
     db4:      	b.eq	0x1240 <event_execve+0x1240>
     db8:      	add	x2, x23, #0x8e0
     dbc:      	mov	w8, #0x8                // =8
     dc0:      	mov	w9, #0x71               // =113
     dc4:      	add	x10, sp, #0x40
     dc8:      	add	x0, sp, #0x40
     dcc:      	mov	w1, #0x8                // =8
     dd0:      	blr	x9
     dd4:      	ldr	x23, [sp, #0x40]
     dd8:      	cbz	x23, 0x1234 <event_execve+0x1234>
     ddc:      	add	x2, x23, #0x8d4
     de0:      	mov	w8, #0x4                // =4
     de4:      	mov	w9, #0x71               // =113
     de8:      	add	x10, sp, #0xb8
     dec:      	add	x0, sp, #0xb8
     df0:      	mov	w1, #0x4                // =4
     df4:      	blr	x9
     df8:      	ldr	w8, [sp, #0xb8]
     dfc:      	mov	x25, x21
     e00:      	mov	x29, x22
     e04:      	add	x24, sp, #0xb8
     e08:      	cmp	w8, w19
     e0c:      	b.eq	0x1240 <event_execve+0x1240>
     e10:      	add	x2, x23, #0x8e0
     e14:      	mov	w8, #0x8                // =8
     e18:      	mov	w9, #0x71               // =113
     e1c:      	add	x10, sp, #0x40
     e20:      	add	x0, sp, #0x40
     e24:      	mov	w1, #0x8                // =8
     e28:      	blr	x9
     e2c:      	ldr	x23, [sp, #0x40]
     e30:      	cbz	x23, 0x1234 <event_execve+0x1234>
     e34:      	add	x2, x23, #0x8d4
     e38:      	mov	w8, #0x4                // =4
     e3c:      	mov	w9, #0x71               // =113
     e40:      	add	x10, sp, #0xb8
     e44:      	add	x0, sp, #0xb8
     e48:      	mov	w1, #0x4                // =4
     e4c:      	blr	x9
     e50:      	ldr	w8, [sp, #0xb8]
     e54:      	mov	x25, x21
     e58:      	mov	x29, x22
     e5c:      	add	x24, sp, #0xb8
     e60:      	cmp	w8, w19
     e64:      	b.eq	0x1240 <event_execve+0x1240>
     e68:      	add	x2, x23, #0x8e0
     e6c:      	mov	w8, #0x8                // =8
     e70:      	mov	w9, #0x71               // =113
     e74:      	add	x10, sp, #0x40
     e78:      	add	x0, sp, #0x40
     e7c:      	mov	w1, #0x8                // =8
     e80:      	blr	x9
     e84:      	ldr	x23, [sp, #0x40]
     e88:      	cbz	x23, 0x1234 <event_execve+0x1234>
     e8c:      	add	x2, x23, #0x8d4
     e90:      	mov	w8, #0x4                // =4
     e94:      	mov	w9, #0x71               // =113
     e98:      	add	x10, sp, #0xb8
     e9c:      	add	x0, sp, #0xb8
     ea0:      	mov	w1, #0x4                // =4
     ea4:      	blr	x9
     ea8:      	ldr	w8, [sp, #0xb8]
     eac:      	mov	x25, x21
     eb0:      	mov	x29, x22
     eb4:      	add	x24, sp, #0xb8
     eb8:      	cmp	w8, w19
     ebc:      	b.eq	0x1240 <event_execve+0x1240>
     ec0:      	add	x2, x23, #0x8e0
     ec4:      	mov	w8, #0x8                // =8
     ec8:      	mov	w9, #0x71               // =113
     ecc:      	add	x10, sp, #0x40
     ed0:      	add	x0, sp, #0x40
     ed4:      	mov	w1, #0x8                // =8
     ed8:      	blr	x9
     edc:      	ldr	x23, [sp, #0x40]
     ee0:      	cbz	x23, 0x1234 <event_execve+0x1234>
     ee4:      	add	x2, x23, #0x8d4
     ee8:      	mov	w8, #0x4                // =4
     eec:      	mov	w9, #0x71               // =113
     ef0:      	add	x10, sp, #0xb8
     ef4:      	add	x0, sp, #0xb8
     ef8:      	mov	w1, #0x4                // =4
     efc:      	blr	x9
     f00:      	ldr	w8, [sp, #0xb8]
     f04:      	mov	x25, x21
     f08:      	mov	x29, x22
     f0c:      	add	x24, sp, #0xb8
     f10:      	cmp	w8, w19
     f14:      	b.eq	0x1240 <event_execve+0x1240>
     f18:      	add	x2, x23, #0x8e0
     f1c:      	mov	w8, #0x8                // =8
     f20:      	mov	w9, #0x71               // =113
     f24:      	add	x10, sp, #0x40
     f28:      	add	x0, sp, #0x40
     f2c:      	mov	w1, #0x8                // =8
     f30:      	blr	x9
     f34:      	ldr	x23, [sp, #0x40]
     f38:      	cbz	x23, 0x1234 <event_execve+0x1234>
     f3c:      	add	x2, x23, #0x8d4
     f40:      	mov	w8, #0x4                // =4
     f44:      	mov	w9, #0x71               // =113
     f48:      	add	x10, sp, #0xb8
     f4c:      	add	x0, sp, #0xb8
     f50:      	mov	w1, #0x4                // =4
     f54:      	blr	x9
     f58:      	ldr	w8, [sp, #0xb8]
     f5c:      	mov	x25, x21
     f60:      	mov	x29, x22
     f64:      	add	x24, sp, #0xb8
     f68:      	cmp	w8, w19
     f6c:      	b.eq	0x1240 <event_execve+0x1240>
     f70:      	add	x2, x23, #0x8e0
     f74:      	mov	w8, #0x8                // =8
     f78:      	mov	w9, #0x71               // =113
     f7c:      	add	x10, sp, #0x40
     f80:      	add	x0, sp, #0x40
     f84:      	mov	w1, #0x8                // =8
     f88:      	blr	x9
     f8c:      	ldr	x23, [sp, #0x40]
     f90:      	cbz	x23, 0x1234 <event_execve+0x1234>
     f94:      	add	x2, x23, #0x8d4
     f98:      	mov	w8, #0x4                // =4
     f9c:      	mov	w9, #0x71               // =113
     fa0:      	add	x10, sp, #0xb8
     fa4:      	add	x0, sp, #0xb8
     fa8:      	mov	w1, #0x4                // =4
     fac:      	blr	x9
     fb0:      	ldr	w8, [sp, #0xb8]
     fb4:      	mov	x25, x21
     fb8:      	mov	x29, x22
     fbc:      	add	x24, sp, #0xb8
     fc0:      	cmp	w8, w19
     fc4:      	b.eq	0x1240 <event_execve+0x1240>
     fc8:      	add	x2, x23, #0x8e0
     fcc:      	mov	w8, #0x8                // =8
     fd0:      	mov	w9, #0x71               // =113
     fd4:      	add	x10, sp, #0x40
     fd8:      	add	x0, sp, #0x40
     fdc:      	mov	w1, #0x8                // =8
     fe0:      	blr	x9
     fe4:      	ldr	x23, [sp, #0x40]
     fe8:      	cbz	x23, 0x1234 <event_execve+0x1234>
     fec:      	add	x2, x23, #0x8d4
     ff0:      	mov	w8, #0x4                // =4
     ff4:      	mov	w9, #0x71               // =113
     ff8:      	add	x10, sp, #0xb8
     ffc:      	add	x0, sp, #0xb8
    1000:      	mov	w1, #0x4                // =4
    1004:      	blr	x9
    1008:      	ldr	w8, [sp, #0xb8]
    100c:      	mov	x25, x21
    1010:      	mov	x29, x22
    1014:      	add	x24, sp, #0xb8
    1018:      	cmp	w8, w19
    101c:      	b.eq	0x1240 <event_execve+0x1240>
    1020:      	add	x2, x23, #0x8e0
    1024:      	mov	w8, #0x8                // =8
    1028:      	mov	w9, #0x71               // =113
    102c:      	add	x10, sp, #0x40
    1030:      	add	x0, sp, #0x40
    1034:      	mov	w1, #0x8                // =8
    1038:      	blr	x9
    103c:      	ldr	x23, [sp, #0x40]
    1040:      	cbz	x23, 0x1234 <event_execve+0x1234>
    1044:      	add	x2, x23, #0x8d4
    1048:      	mov	w8, #0x4                // =4
    104c:      	mov	w9, #0x71               // =113
    1050:      	add	x10, sp, #0xb8
    1054:      	add	x0, sp, #0xb8
    1058:      	mov	w1, #0x4                // =4
    105c:      	blr	x9
    1060:      	ldr	w8, [sp, #0xb8]
    1064:      	mov	x25, x21
    1068:      	mov	x29, x22
    106c:      	add	x24, sp, #0xb8
    1070:      	cmp	w8, w19
    1074:      	b.eq	0x1240 <event_execve+0x1240>
    1078:      	add	x2, x23, #0x8e0
    107c:      	mov	w8, #0x8                // =8
    1080:      	mov	w9, #0x71               // =113
    1084:      	add	x10, sp, #0x40
    1088:      	add	x0, sp, #0x40
    108c:      	mov	w1, #0x8                // =8
    1090:      	blr	x9
    1094:      	ldr	x23, [sp, #0x40]
    1098:      	cbz	x23, 0x1234 <event_execve+0x1234>
    109c:      	add	x2, x23, #0x8d4
    10a0:      	mov	w8, #0x4                // =4
    10a4:      	mov	w9, #0x71               // =113
    10a8:      	add	x10, sp, #0xb8
    10ac:      	add	x0, sp, #0xb8
    10b0:      	mov	w1, #0x4                // =4
    10b4:      	blr	x9
    10b8:      	ldr	w8, [sp, #0xb8]
    10bc:      	mov	x25, x21
    10c0:      	mov	x29, x22
    10c4:      	add	x24, sp, #0xb8
    10c8:      	cmp	w8, w19
    10cc:      	b.eq	0x1240 <event_execve+0x1240>
    10d0:      	add	x2, x23, #0x8e0
    10d4:      	mov	w8, #0x8                // =8
    10d8:      	mov	w9, #0x71               // =113
    10dc:      	add	x10, sp, #0x40
    10e0:      	add	x0, sp, #0x40
    10e4:      	mov	w1, #0x8                // =8
    10e8:      	blr	x9
    10ec:      	ldr	x23, [sp, #0x40]
    10f0:      	b	0x1240 <event_execve+0x1240>
    10f4:      	str	wzr, [sp, #0xa8]
    10f8:      	adrp	x0, 0x1000 <event_execve+0x1000>
    10fc:      	mov	w8, #0x1                // =1
    1100:      	add	x9, sp, #0xa8
    1104:      	ldr	x0, [x0]
    1108:      	add	x1, sp, #0xa8
    110c:      	blr	x8
    1110:      	cbz	x0, 0x11c8 <event_execve+0x11c8>
    1114:      	mov	w8, #0x18               // =24
    1118:      	mov	x23, x0
    111c:      	str	w8, [x0]
    1120:      	mov	w8, #0xe                // =14
    1124:      	blr	x8
    1128:      	mov	x24, x23
    112c:      	cmn	x0, #0x16
    1130:      	str	x0, [x24, #0x10]!
    1134:      	b.ne	0x115c <event_execve+0x115c>
    1138:      	add	x2, x25, #0xe8
    113c:      	mov	w8, #0x8                // =8
    1140:      	mov	w9, #0x4                // =4
    1144:      	add	x10, sp, #0x40
    1148:      	add	x0, sp, #0x40
    114c:      	mov	w1, #0x8                // =8
    1150:      	blr	x9
    1154:      	ldr	x8, [sp, #0x40]
    1158:      	str	x8, [x24]
    115c:      	mov	w8, #0x7d               // =125
    1160:      	blr	x8
    1164:      	str	x0, [x23, #0x18]
    1168:      	mov	x0, x25
    116c:      	mov	x1, x23
    1170:      	mov	x2, x22
    1174:      	ldp	x8, x9, [x24]
    1178:      	mov	x3, x19
    117c:      	stp	x8, x9, [x21, #0x150]
    1180:      	bl	0x1180 <event_execve+0x1180>
    1184:      	cmn	x19, #0x1
    1188:      	sub	w8, w19, w0
    118c:      	asr	w9, w0, #31
    1190:      	str	wzr, [x21, #0x144]
    1194:      	mov	w19, #0x20              // =32
    1198:      	add	x24, sp, #0xb8
    119c:      	ccmp	w0, #0x0, #0x8, ne
    11a0:      	and	w10, w0, w9
    11a4:      	str	w10, [x21, #0x140]
    11a8:      	csel	w8, wzr, w8, lt
    11ac:      	str	w8, [x21, #0x148]
    11b0:      	bic	w8, w0, w9
    11b4:      	str	w8, [x21, #0x14c]
    11b8:      	ldr	w8, [x20, #0x15c]
    11bc:      	orr	w8, w8, #0x1000000
    11c0:      	str	w8, [x20, #0x15c]
    11c4:      	b	0x11cc <event_execve+0x11cc>
    11c8:      	mov	w19, wzr
    11cc:      	adrp	x23, 0x1000 <event_execve+0x1000>
    11d0:      	ldr	x23, [x23]
    11d4:      	b	0x1210 <event_execve+0x1210>
    11d8:      	str	w21, [sp, #0xa8]
    11dc:      	mov	x3, xzr
    11e0:      	mov	w8, #0x2                // =2
    11e4:      	add	x9, sp, #0x40
    11e8:      	add	x10, sp, #0xa8
    11ec:      	add	x1, sp, #0x40
    11f0:      	add	x2, sp, #0xa8
    11f4:      	mov	x0, x23
    11f8:      	blr	x8
    11fc:      	tbz	w22, #0x1f, 0x1210 <event_execve+0x1210>
    1200:      	ldr	w8, [x20, #0x15c]
    1204:      	mov	w19, wzr
    1208:      	orr	w8, w8, #0x200
    120c:      	str	w8, [x20, #0x15c]
    1210:      	ldr	x22, [sp, #0xd8]
    1214:      	str	w19, [x20, #0x1848]
    1218:      	strh	w19, [x20, #0x17a]
    121c:      	ldr	w8, [x20, #0x140]
    1220:      	add	w9, w8, w19
    1224:      	ldrb	w8, [x20, #0x15d]
    1228:      	str	w9, [x20, #0x140]
    122c:      	tbz	w8, #0x5, 0xa4c <event_execve+0xa4c>
    1230:      	b	0x9f8 <event_execve+0x9f8>
    1234:      	mov	x25, x21
    1238:      	mov	x29, x22
    123c:      	add	x24, sp, #0xb8
    1240:      	ldr	w8, [sp, #0xb8]
    1244:      	mov	w9, #0x4                // =4
    1248:      	add	x10, sp, #0x88
    124c:      	add	x0, sp, #0x88
    1250:      	mov	w1, #0x8                // =8
    1254:      	cmp	w8, w19
    1258:      	csel	x8, x23, xzr, eq
    125c:      	add	x2, x8, #0xb30
    1260:      	mov	w8, #0x8                // =8
    1264:      	blr	x9
    1268:      	ldr	x21, [sp, #0x88]
    126c:      	cbz	x21, 0x1324 <event_execve+0x1324>
    1270:      	str	wzr, [sp, #0x94]
    1274:      	adrp	x0, 0x1000 <event_execve+0x1000>
    1278:      	mov	w8, #0x1                // =1
    127c:      	add	x9, sp, #0x94
    1280:      	ldr	x0, [x0]
    1284:      	add	x1, sp, #0x94
    1288:      	blr	x8
    128c:      	cbz	x0, 0x1338 <event_execve+0x1338>
    1290:      	add	x8, x21, #0x28
    1294:      	stp	x29, x25, [sp, #0x18]
    1298:      	mov	x19, x0
    129c:      	str	x8, [sp, #0x10]
    12a0:      	add	x8, x0, #0x1, lsl #12   // =0x1000
    12a4:      	str	x8, [sp, #0x30]
    12a8:      	mov	w8, #0x23               // =35
    12ac:      	blr	x8
    12b0:      	add	x2, x0, #0xb30
    12b4:      	mov	w24, #0x8               // =8
    12b8:      	add	x8, sp, #0x98
    12bc:      	mov	w9, #0x4                // =4
    12c0:      	add	x0, sp, #0x98
    12c4:      	mov	w1, #0x8                // =8
    12c8:      	mov	w22, #0x4               // =4
    12cc:      	blr	x9
    12d0:      	ldr	x23, [sp, #0x98]
    12d4:      	add	x29, x21, #0x30
    12d8:      	mov	w9, #0x4                // =4
    12dc:      	add	x0, sp, #0xa0
    12e0:      	mov	w1, #0x8                // =8
    12e4:      	mov	x2, x29
    12e8:      	add	x8, x23, #0x18
    12ec:      	str	x8, [sp, #0x8]
    12f0:      	add	x8, sp, #0xa0
    12f4:      	blr	x9
    12f8:      	ldr	x21, [sp, #0xa0]
    12fc:      	add	x25, sp, #0x40
    1300:      	add	x0, sp, #0x40
    1304:      	mov	w1, #0x8                // =8
    1308:      	add	x2, x21, #0x10
    130c:      	blr	x22
    1310:      	ldr	x8, [sp, #0x40]
    1314:      	cbz	x8, 0x134c <event_execve+0x134c>
    1318:      	ldr	x9, [sp, #0x30]
    131c:      	mov	w8, #0x1000             // =4096
    1320:      	b	0x1394 <event_execve+0x1394>
    1324:      	ldr	w9, [x20, #0x15c]
    1328:      	mov	w8, wzr
    132c:      	orr	w9, w9, #0x2000
    1330:      	str	w9, [x20, #0x15c]
    1334:      	b	0x133c <event_execve+0x133c>
    1338:      	mov	w8, wzr
    133c:      	adrp	x23, 0x1000 <event_execve+0x1000>
    1340:      	ldr	x23, [x23]
    1344:      	ldr	x22, [sp, #0xd8]
    1348:      	b	0x17fc <event_execve+0x17fc>
    134c:      	add	x2, x21, #0x18
    1350:      	mov	w8, #0x8                // =8
    1354:      	mov	w9, #0x4                // =4
    1358:      	add	x10, sp, #0x40
    135c:      	add	x0, sp, #0x40
    1360:      	mov	w1, #0x8                // =8
    1364:      	blr	x9
    1368:      	ldr	x8, [sp, #0x40]
    136c:      	cmp	x8, x21
    1370:      	b.eq	0x1318 <event_execve+0x1318>
    1374:      	mov	w8, #0x2964             // =10596
    1378:      	add	x9, x19, #0xff6
    137c:      	strh	w8, [x19, #0xffe]
    1380:      	adrp	x8, 0x1000 <event_execve+0x1000>
    1384:      	add	x8, x8, #0x0
    1388:      	ldr	x8, [x8]
    138c:      	str	x8, [x9]
    1390:      	mov	w8, #0xff6              // =4086
    1394:      	stp	xzr, xzr, [sp, #0x40]
    1398:      	add	x2, x23, #0x20
    139c:      	mov	w22, #0x8               // =8
    13a0:      	add	x0, sp, #0x40
    13a4:      	mov	w1, #0x8                // =8
    13a8:      	add	x21, x25, #0x8
    13ac:      	stp	x19, xzr, [sp, #0x50]
    13b0:      	add	x24, x25, #0x18
    13b4:      	add	x19, x25, #0x20
    13b8:      	stp	xzr, xzr, [sp, #0x60]
    13bc:      	mov	w23, #0x4               // =4
    13c0:      	str	x9, [sp, #0x30]
    13c4:      	str	x9, [sp, #0x70]
    13c8:      	str	w8, [sp, #0x78]
    13cc:      	mov	w8, #0x4                // =4
    13d0:      	strb	wzr, [sp, #0x7c]
    13d4:      	blr	x8
    13d8:      	ldr	x2, [sp, #0x8]
    13dc:      	mov	w8, #0x4                // =4
    13e0:      	mov	x0, x21
    13e4:      	mov	w1, #0x8                // =8
    13e8:      	blr	x8
    13ec:      	mov	w8, #0x4                // =4
    13f0:      	mov	x0, x24
    13f4:      	mov	w1, #0x8                // =8
    13f8:      	mov	x2, x29
    13fc:      	blr	x8
    1400:      	ldr	x2, [sp, #0x10]
    1404:      	mov	x0, x19
    1408:      	mov	w1, #0x8                // =8
    140c:      	blr	x23
    1410:      	ldr	x8, [sp, #0x60]
    1414:      	sub	x8, x8, #0x20
    1418:      	str	x8, [sp, #0x68]
    141c:      	adrp	x8, 0x1000 <event_execve+0x1000>
    1420:      	ldr	x8, [x8]
    1424:      	ldrb	w8, [x8]
    1428:      	cbz	w8, 0x15bc <event_execve+0x15bc>
    142c:      	mov	w21, #0x800             // =2048
    1430:      	mov	w22, #0x8               // =8
    1434:      	nop
    1438:      	nop
    143c:      	nop
    1440:      	ldp	x23, x2, [sp, #0x58]
    1444:      	ldp	x8, x9, [sp, #0x40]
    1448:      	cmp	x23, x8
    144c:      	ccmp	x2, x9, #0x0, eq
    1450:      	b.eq	0x1740 <event_execve+0x1740>
    1454:      	ldr	x25, [sp, #0x68]
    1458:      	mov	w8, #0x4                // =4
    145c:      	add	x9, sp, #0xa8
    1460:      	add	x0, sp, #0xa8
    1464:      	mov	w1, #0x8                // =8
    1468:      	blr	x8
    146c:      	ldr	x8, [sp, #0xa8]
    1470:      	add	x29, sp, #0xb8
    1474:      	cmp	x23, x8
    1478:      	b.eq	0x1568 <event_execve+0x1568>
    147c:      	add	x19, x23, #0x18
    1480:      	mov	w8, #0x4                // =4
    1484:      	add	x9, sp, #0xc8
    1488:      	add	x0, sp, #0xc8
    148c:      	mov	w1, #0x8                // =8
    1490:      	mov	x2, x19
    1494:      	blr	x8
    1498:      	ldr	x8, [x29, #0x10]
    149c:      	cmp	x8, x23
    14a0:      	b.eq	0x1568 <event_execve+0x1568>
    14a4:      	mov	w8, #0x4                // =4
    14a8:      	add	x9, sp, #0xb0
    14ac:      	add	x0, sp, #0xb0
    14b0:      	mov	w1, #0x8                // =8
    14b4:      	mov	x2, x19
    14b8:      	blr	x8
    14bc:      	add	x2, x23, #0x20
    14c0:      	mov	w8, #0x4                // =4
    14c4:      	mov	w9, #0x10               // =16
    14c8:      	add	x10, sp, #0xb8
    14cc:      	add	x0, sp, #0xb8
    14d0:      	mov	w1, #0x10               // =16
    14d4:      	blr	x8
    14d8:      	ldr	w19, [sp, #0xbc]
    14dc:      	ldr	x8, [sp, #0x50]
    14e0:      	ldr	x10, [sp, #0x70]
    14e4:      	sub	x12, x10, x8
    14e8:      	ldr	w23, [sp, #0x78]
    14ec:      	subs	w10, w19, w23
    14f0:      	ldr	x9, [x29, #0x8]
    14f4:      	csel	w10, wzr, w10, lo
    14f8:      	cmp	w23, w19
    14fc:      	csel	w11, w23, w19, lo
    1500:      	cinc	w13, w11, hi
    1504:      	sub	w14, w23, w13
    1508:      	subs	x12, x12, x13
    150c:      	str	w14, [sp, #0x78]
    1510:      	b.lo	0x1748 <event_execve+0x1748>
    1514:      	cmp	x12, #0xfff
    1518:      	b.hi	0x1748 <event_execve+0x1748>
    151c:      	cmp	w23, w19
    1520:      	b.ls	0x152c <event_execve+0x152c>
    1524:      	mov	w13, #0x2f              // =47
    1528:      	strb	w13, [x8, x12]
    152c:      	add	x25, x8, x12
    1530:      	cmp	w23, w19
    1534:      	add	x2, x9, x10
    1538:      	and	w1, w11, #0xff
    153c:      	mov	w8, #0x4                // =4
    1540:      	cinc	x0, x25, hi
    1544:      	blr	x8
    1548:      	cmp	w23, w19
    154c:      	str	x25, [sp, #0x70]
    1550:      	b.ls	0x1748 <event_execve+0x1748>
    1554:      	ldr	x8, [sp, #0xb0]
    1558:      	str	x8, [sp, #0x58]
    155c:      	subs	w21, w21, #0x1
    1560:      	b.ne	0x1440 <event_execve+0x1440>
    1564:      	b	0x1748 <event_execve+0x1748>
    1568:      	add	x2, x25, #0x10
    156c:      	mov	w8, #0x4                // =4
    1570:      	add	x9, sp, #0xc8
    1574:      	add	x0, sp, #0xc8
    1578:      	mov	w1, #0x8                // =8
    157c:      	blr	x8
    1580:      	ldr	x8, [sp, #0x68]
    1584:      	ldr	x9, [x29, #0x10]
    1588:      	cmp	x8, x9
    158c:      	b.eq	0x1740 <event_execve+0x1740>
    1590:      	add	x2, x25, #0x18
    1594:      	mov	w8, #0x4                // =4
    1598:      	mov	x0, x24
    159c:      	mov	w1, #0x8                // =8
    15a0:      	blr	x8
    15a4:      	ldr	x8, [x29, #0x10]
    15a8:      	add	x9, x8, #0x20
    15ac:      	stp	x9, x8, [sp, #0x60]
    15b0:      	subs	w21, w21, #0x1
    15b4:      	b.ne	0x1440 <event_execve+0x1440>
    15b8:      	b	0x1748 <event_execve+0x1748>
    15bc:      	mov	w21, #0x800             // =2048
    15c0:      	mov	w22, #0x8               // =8
    15c4:      	ldp	x23, x2, [sp, #0x58]
    15c8:      	ldp	x8, x9, [sp, #0x40]
    15cc:      	cmp	x23, x8
    15d0:      	ccmp	x2, x9, #0x0, eq
    15d4:      	b.eq	0x1740 <event_execve+0x1740>
    15d8:      	ldr	x25, [sp, #0x68]
    15dc:      	mov	w8, #0x4                // =4
    15e0:      	add	x9, sp, #0xa8
    15e4:      	add	x0, sp, #0xa8
    15e8:      	mov	w1, #0x8                // =8
    15ec:      	blr	x8
    15f0:      	ldr	x8, [sp, #0xa8]
    15f4:      	add	x29, sp, #0xb8
    15f8:      	cmp	x23, x8
    15fc:      	b.eq	0x16ec <event_execve+0x16ec>
    1600:      	add	x19, x23, #0x18
    1604:      	mov	w8, #0x4                // =4
    1608:      	add	x9, sp, #0xc8
    160c:      	add	x0, sp, #0xc8
    1610:      	mov	w1, #0x8                // =8
    1614:      	mov	x2, x19
    1618:      	blr	x8
    161c:      	ldr	x8, [x29, #0x10]
    1620:      	cmp	x8, x23
    1624:      	b.eq	0x16ec <event_execve+0x16ec>
    1628:      	mov	w8, #0x4                // =4
    162c:      	add	x9, sp, #0xb0
    1630:      	add	x0, sp, #0xb0
    1634:      	mov	w1, #0x8                // =8
    1638:      	mov	x2, x19
    163c:      	blr	x8
    1640:      	add	x2, x23, #0x20
    1644:      	mov	w8, #0x4                // =4
    1648:      	mov	w9, #0x10               // =16
    164c:      	add	x10, sp, #0xb8
    1650:      	add	x0, sp, #0xb8
    1654:      	mov	w1, #0x10               // =16
    1658:      	blr	x8
    165c:      	ldr	w19, [sp, #0xbc]
    1660:      	ldr	x8, [sp, #0x50]
    1664:      	ldr	x10, [sp, #0x70]
    1668:      	sub	x12, x10, x8
    166c:      	ldr	w23, [sp, #0x78]
    1670:      	subs	w10, w19, w23
    1674:      	ldr	x9, [x29, #0x8]
    1678:      	csel	w10, wzr, w10, lo
    167c:      	cmp	w23, w19
    1680:      	csel	w11, w23, w19, lo
    1684:      	cinc	w13, w11, hi
    1688:      	sub	w14, w23, w13
    168c:      	subs	x12, x12, x13
    1690:      	str	w14, [sp, #0x78]
    1694:      	b.lo	0x1748 <event_execve+0x1748>
    1698:      	cmp	x12, #0xfff
    169c:      	b.hi	0x1748 <event_execve+0x1748>
    16a0:      	cmp	w23, w19
    16a4:      	b.ls	0x16b0 <event_execve+0x16b0>
    16a8:      	mov	w13, #0x2f              // =47
    16ac:      	strb	w13, [x8, x12]
    16b0:      	add	x25, x8, x12
    16b4:      	cmp	w23, w19
    16b8:      	add	x2, x9, x10
    16bc:      	and	w1, w11, #0xff
    16c0:      	mov	w8, #0x4                // =4
    16c4:      	cinc	x0, x25, hi
    16c8:      	blr	x8
    16cc:      	cmp	w23, w19
    16d0:      	str	x25, [sp, #0x70]
    16d4:      	b.ls	0x1748 <event_execve+0x1748>
    16d8:      	ldr	x8, [sp, #0xb0]
    16dc:      	str	x8, [sp, #0x58]
    16e0:      	subs	w21, w21, #0x1
    16e4:      	b.ne	0x15c4 <event_execve+0x15c4>
    16e8:      	b	0x1748 <event_execve+0x1748>
    16ec:      	add	x2, x25, #0x10
    16f0:      	mov	w8, #0x4                // =4
    16f4:      	add	x9, sp, #0xc8
    16f8:      	add	x0, sp, #0xc8
    16fc:      	mov	w1, #0x8                // =8
    1700:      	blr	x8
    1704:      	ldr	x8, [sp, #0x68]
    1708:      	ldr	x9, [x29, #0x10]
    170c:      	cmp	x8, x9
    1710:      	b.eq	0x1740 <event_execve+0x1740>
    1714:      	add	x2, x25, #0x18
    1718:      	mov	w8, #0x4                // =4
    171c:      	mov	x0, x24
    1720:      	mov	w1, #0x8                // =8
    1724:      	blr	x8
    1728:      	ldr	x8, [x29, #0x10]
    172c:      	add	x9, x8, #0x20
    1730:      	stp	x9, x8, [sp, #0x60]
    1734:      	subs	w21, w21, #0x1
    1738:      	b.ne	0x15c4 <event_execve+0x15c4>
    173c:      	b	0x1748 <event_execve+0x1748>
    1740:      	mov	w8, #0x1                // =1
    1744:      	strb	w8, [sp, #0x7c]
    1748:      	ldr	x8, [sp, #0x70]
    174c:      	ldr	x2, [sp, #0x30]
    1750:      	cmp	x8, x2
    1754:      	b.eq	0x179c <event_execve+0x179c>
    1758:      	ldrb	w9, [sp, #0x7c]
    175c:      	ldr	w10, [sp, #0x78]
    1760:      	adrp	x23, 0x1000 <event_execve+0x1000>
    1764:      	mov	w11, #0x1000            // =4096
    1768:      	add	x24, sp, #0xb8
    176c:      	cmp	w9, #0x0
    1770:      	ldp	x29, x25, [sp, #0x18]
    1774:      	ldr	x23, [x23]
    1778:      	ldr	x22, [sp, #0xd8]
    177c:      	sub	w11, w11, w10
    1780:      	cset	w9, eq
    1784:      	cmp	w10, #0x0
    1788:      	csel	w21, w11, w10, gt
    178c:      	cbz	x8, 0x17fc <event_execve+0x17fc>
    1790:      	lsl	w19, w9, #1
    1794:      	mov	x2, x8
    1798:      	b	0x17b8 <event_execve+0x17b8>
    179c:      	adrp	x23, 0x1000 <event_execve+0x1000>
    17a0:      	ldp	x29, x25, [sp, #0x18]
    17a4:      	mov	w21, wzr
    17a8:      	mov	w19, wzr
    17ac:      	add	x24, sp, #0xb8
    17b0:      	ldr	x23, [x23]
    17b4:      	ldr	x22, [sp, #0xd8]
    17b8:      	ldr	w8, [sp, #0x28]
    17bc:      	ands	w1, w21, #0xfff
    17c0:      	and	w8, w8, #0x3ff
    17c4:      	add	x0, x22, x8
    17c8:      	mov	w8, #0x4                // =4
    17cc:      	blr	x8
    17d0:      	ldr	w9, [x20, #0x15c]
    17d4:      	ands	w8, w21, #0xfff
    17d8:      	strh	w8, [x20, #0x17c]
    17dc:      	orr	w10, w9, #0x1000
    17e0:      	csel	w9, w10, w9, eq
    17e4:      	cmp	w19, #0x0
    17e8:      	orr	w10, w9, #0x400000
    17ec:      	csel	w9, w9, w10, eq
    17f0:      	mov	w10, #-0x2401           // =-9217
    17f4:      	and	w9, w9, w10
    17f8:      	str	w9, [x20, #0x15c]
    17fc:      	ldr	w9, [x22]
    1800:      	add	w21, w9, w8
    1804:      	str	xzr, [sp, #0xb8]
    1808:      	adrp	x8, 0x1000 <event_execve+0x1000>
    180c:      	str	w21, [x22]
    1810:      	ldr	x8, [x8]
    1814:      	ldrb	w8, [x8]
    1818:      	cbz	w8, 0x1ae4 <event_execve+0x1ae4>
    181c:      	cmp	w21, #0x3ff
    1820:      	b.hi	0x18c0 <event_execve+0x18c0>
    1824:      	mov	w8, #0x23               // =35
    1828:      	blr	x8
    182c:      	add	x2, x0, #0x858
    1830:      	mov	w8, #0x8                // =8
    1834:      	mov	w9, #0x4                // =4
    1838:      	add	x10, sp, #0xb8
    183c:      	add	x0, sp, #0xb8
    1840:      	mov	w1, #0x8                // =8
    1844:      	blr	x9
    1848:      	ldr	x8, [sp, #0xb8]
    184c:      	cbz	x8, 0x1ae4 <event_execve+0x1ae4>
    1850:      	add	x8, x8, #0x288
    1854:      	mov	w9, #0x8                // =8
    1858:      	mov	w10, #0x4               // =4
    185c:      	add	x11, sp, #0xc8
    1860:      	ldr	x8, [sp, #0xb8]
    1864:      	add	x0, sp, #0xc8
    1868:      	mov	w1, #0x8                // =8
    186c:      	add	x2, x8, #0x288
    1870:      	blr	x10
    1874:      	cbz	x0, 0x18ec <event_execve+0x18ec>
    1878:      	neg	w8, w0
    187c:      	mov	w9, #0x1                // =1
    1880:      	add	x1, sp, #0x40
    1884:      	strh	w8, [sp, #0x40]
    1888:      	mov	w8, #0x9                // =9
    188c:      	mov	x0, x23
    1890:      	mov	w19, #0x1               // =1
    1894:      	strh	w8, [sp, #0x42]
    1898:      	mov	x8, #0x9a               // =154
    189c:      	movk	x8, #0x4, lsl #32
    18a0:      	stur	x8, [sp, #0x44]
    18a4:      	add	x8, sp, #0x40
    18a8:      	blr	x9
    18ac:      	cbz	x0, 0x18c8 <event_execve+0x18c8>
    18b0:      	ldr	w8, [x0]
    18b4:      	add	w8, w8, #0x1
    18b8:      	str	w8, [x0]
    18bc:      	b	0x18ec <event_execve+0x18ec>
    18c0:      	mov	w8, wzr
    18c4:      	b	0x1ae4 <event_execve+0x1ae4>
    18c8:      	str	w19, [sp, #0xb0]
    18cc:      	mov	x3, xzr
    18d0:      	mov	w8, #0x2                // =2
    18d4:      	add	x9, sp, #0x40
    18d8:      	add	x10, sp, #0xb0
    18dc:      	add	x1, sp, #0x40
    18e0:      	add	x2, sp, #0xb0
    18e4:      	mov	x0, x23
    18e8:      	blr	x8
    18ec:      	ldr	x8, [sp, #0xb8]
    18f0:      	mov	w9, #0x8                // =8
    18f4:      	mov	w10, #0x4               // =4
    18f8:      	add	x11, sp, #0xb0
    18fc:      	add	x0, sp, #0xb0
    1900:      	mov	w1, #0x8                // =8
    1904:      	add	x8, x8, #0x290
    1908:      	ldr	x8, [sp, #0xb8]
    190c:      	add	x2, x8, #0x290
    1910:      	blr	x10
    1914:      	cbz	x0, 0x195c <event_execve+0x195c>
    1918:      	neg	w8, w0
    191c:      	mov	w9, #0x1                // =1
    1920:      	add	x1, sp, #0x40
    1924:      	strh	w8, [sp, #0x40]
    1928:      	mov	w8, #0x9                // =9
    192c:      	mov	x0, x23
    1930:      	mov	w19, #0x1               // =1
    1934:      	strh	w8, [sp, #0x42]
    1938:      	mov	x8, #0x9b               // =155
    193c:      	movk	x8, #0x4, lsl #32
    1940:      	stur	x8, [sp, #0x44]
    1944:      	add	x8, sp, #0x40
    1948:      	blr	x9
    194c:      	cbz	x0, 0x1a70 <event_execve+0x1a70>
    1950:      	ldr	w8, [x0]
    1954:      	add	w8, w8, #0x1
    1958:      	str	w8, [x0]
    195c:      	ldr	x19, [x24, #0x10]
    1960:      	mov	w8, wzr
    1964:      	add	x10, sp, #0xb8
    1968:      	cbz	x19, 0x1ae4 <event_execve+0x1ae4>
    196c:      	ldr	x9, [sp, #0xb0]
    1970:      	cbz	x9, 0x1ae4 <event_execve+0x1ae4>
    1974:      	add	x21, x20, w21, uxtw
    1978:      	sub	x22, x9, x19
    197c:      	cmp	x22, #0x3ff
    1980:      	b.hi	0x19c8 <event_execve+0x19c8>
    1984:      	add	x0, x21, #0x140
    1988:      	add	x8, x20, #0x540
    198c:      	sub	x8, x8, x0
    1990:      	cmp	x22, x8
    1994:      	b.hs	0x19c8 <event_execve+0x19c8>
    1998:      	sub	w8, w22, #0x1
    199c:      	cmp	x9, x19
    19a0:      	and	w8, w8, #0x3ff
    19a4:      	csel	w21, wzr, w8, eq
    19a8:      	mov	w8, #0x4                // =4
    19ac:      	ldr	x2, [x10, #0x10]
    19b0:      	mov	w1, w21
    19b4:      	blr	x8
    19b8:      	ands	x8, x0, #0x80000000
    19bc:      	lsr	x9, x8, #28
    19c0:      	csel	w8, w21, wzr, eq
    19c4:      	b	0x1ad4 <event_execve+0x1ad4>
    19c8:      	str	wzr, [sp, #0xa8]
    19cc:      	adrp	x0, 0x1000 <event_execve+0x1000>
    19d0:      	mov	w8, #0x1                // =1
    19d4:      	add	x9, sp, #0xa8
    19d8:      	ldr	x0, [x0]
    19dc:      	add	x1, sp, #0xa8
    19e0:      	blr	x8
    19e4:      	cbz	x0, 0x1aa8 <event_execve+0x1aa8>
    19e8:      	mov	w8, #0x18               // =24
    19ec:      	mov	x23, x0
    19f0:      	str	w8, [x0]
    19f4:      	mov	w8, #0xe                // =14
    19f8:      	blr	x8
    19fc:      	mov	x24, x23
    1a00:      	cmn	x0, #0x16
    1a04:      	str	x0, [x24, #0x10]!
    1a08:      	b.ne	0x1a30 <event_execve+0x1a30>
    1a0c:      	add	x2, x25, #0xe8
    1a10:      	mov	w8, #0x8                // =8
    1a14:      	mov	w9, #0x4                // =4
    1a18:      	add	x10, sp, #0x40
    1a1c:      	add	x0, sp, #0x40
    1a20:      	mov	w1, #0x8                // =8
    1a24:      	blr	x9
    1a28:      	ldr	x8, [sp, #0x40]
    1a2c:      	str	x8, [x24]
    1a30:      	mov	w8, #0x7d               // =125
    1a34:      	blr	x8
    1a38:      	str	x0, [x23, #0x18]
    1a3c:      	mov	x0, x25
    1a40:      	mov	x1, x23
    1a44:      	mov	x2, x19
    1a48:      	ldp	x8, x9, [x24]
    1a4c:      	mov	x3, x22
    1a50:      	stp	x8, x9, [x21, #0x150]
    1a54:      	bl	0x1a54 <event_execve+0x1a54>
    1a58:      	tbnz	w0, #0x1f, 0x1ab4 <event_execve+0x1ab4>
    1a5c:      	sub	w8, w22, w0
    1a60:      	cmn	x22, #0x1
    1a64:      	str	xzr, [x21, #0x140]
    1a68:      	csel	w8, wzr, w8, eq
    1a6c:      	b	0x1ac4 <event_execve+0x1ac4>
    1a70:      	str	w19, [sp, #0xa8]
    1a74:      	mov	x3, xzr
    1a78:      	mov	w8, #0x2                // =2
    1a7c:      	add	x9, sp, #0x40
    1a80:      	add	x10, sp, #0xa8
    1a84:      	add	x1, sp, #0x40
    1a88:      	add	x2, sp, #0xa8
    1a8c:      	mov	x0, x23
    1a90:      	blr	x8
    1a94:      	ldr	x19, [x24, #0x10]
    1a98:      	mov	w8, wzr
    1a9c:      	add	x10, sp, #0xb8
    1aa0:      	cbnz	x19, 0x196c <event_execve+0x196c>
    1aa4:      	b	0x1ae4 <event_execve+0x1ae4>
    1aa8:      	mov	w9, wzr
    1aac:      	mov	w8, wzr
    1ab0:      	b	0x1ad4 <event_execve+0x1ad4>
    1ab4:      	mov	w8, wzr
    1ab8:      	str	w0, [x21, #0x140]
    1abc:      	str	wzr, [x21, #0x144]
    1ac0:      	mov	w0, wzr
    1ac4:      	str	w8, [x21, #0x148]
    1ac8:      	mov	w8, #0x20               // =32
    1acc:      	mov	w9, #0x2                // =2
    1ad0:      	str	w0, [x21, #0x14c]
    1ad4:      	ldr	w10, [x20, #0x15c]
    1ad8:      	strh	w8, [x20, #0x17e]
    1adc:      	orr	w9, w10, w9
    1ae0:      	str	w9, [x20, #0x15c]
    1ae4:      	ldr	w9, [x20, #0x140]
    1ae8:      	add	x22, x29, #0xae0
    1aec:      	mov	w23, #0x8               // =8
    1af0:      	add	x0, sp, #0x40
    1af4:      	mov	w1, #0x8                // =8
    1af8:      	add	x19, x20, #0xb8
    1afc:      	mov	w21, #0x4               // =4
    1b00:      	mov	x2, x22
    1b04:      	add	w8, w9, w8
    1b08:      	mov	w9, #0x5                // =5
    1b0c:      	strh	w9, [x20]
    1b10:      	ldr	x9, [x20, #0x170]
    1b14:      	str	w8, [x20, #0x140]
    1b18:      	add	w8, w8, #0x140
    1b1c:      	str	w8, [x20, #0x4]
    1b20:      	add	x8, sp, #0x40
    1b24:      	str	x9, [x20, #0x8]
    1b28:      	mov	w9, #0x4                // =4
    1b2c:      	blr	x9
    1b30:      	ldr	x8, [sp, #0x40]
    1b34:      	mov	w9, #0x4                // =4
    1b38:      	mov	x0, x19
    1b3c:      	mov	w1, #0x4                // =4
    1b40:      	add	x8, x8, #0x8
    1b44:      	ldr	x8, [sp, #0x40]
    1b48:      	add	x2, x8, #0x8
    1b4c:      	blr	x9
    1b50:      	ldr	x8, [sp, #0x40]
    1b54:      	add	x0, x20, #0xbc
    1b58:      	mov	w9, #0x4                // =4
    1b5c:      	mov	w1, #0x4                // =4
    1b60:      	add	x8, x8, #0xc
    1b64:      	ldr	x8, [sp, #0x40]
    1b68:      	add	x2, x8, #0xc
    1b6c:      	blr	x9
    1b70:      	ldr	x8, [sp, #0x40]
    1b74:      	add	x0, x20, #0xc8
    1b78:      	mov	w9, #0x4                // =4
    1b7c:      	mov	w1, #0x4                // =4
    1b80:      	add	x8, x8, #0x18
    1b84:      	ldr	x8, [sp, #0x40]
    1b88:      	add	x2, x8, #0x18
    1b8c:      	blr	x9
    1b90:      	ldr	x8, [sp, #0x40]
    1b94:      	add	x0, x20, #0xcc
    1b98:      	mov	w9, #0x4                // =4
    1b9c:      	mov	w1, #0x4                // =4
    1ba0:      	add	x8, x8, #0x1c
    1ba4:      	ldr	x8, [sp, #0x40]
    1ba8:      	add	x2, x8, #0x1c
    1bac:      	blr	x9
    1bb0:      	ldr	x8, [sp, #0x40]
    1bb4:      	add	x0, x20, #0xc0
    1bb8:      	mov	w9, #0x4                // =4
    1bbc:      	mov	w1, #0x4                // =4
    1bc0:      	add	x8, x8, #0x10
    1bc4:      	ldr	x8, [sp, #0x40]
    1bc8:      	add	x2, x8, #0x10
    1bcc:      	blr	x9
    1bd0:      	ldr	x8, [sp, #0x40]
    1bd4:      	add	x0, x20, #0xc4
    1bd8:      	mov	w9, #0x4                // =4
    1bdc:      	mov	w1, #0x4                // =4
    1be0:      	add	x8, x8, #0x14
    1be4:      	ldr	x8, [sp, #0x40]
    1be8:      	add	x2, x8, #0x14
    1bec:      	blr	x9
    1bf0:      	ldr	x8, [sp, #0x40]
    1bf4:      	add	x0, x20, #0xd0
    1bf8:      	mov	w9, #0x4                // =4
    1bfc:      	mov	w1, #0x4                // =4
    1c00:      	add	x8, x8, #0x20
    1c04:      	ldr	x8, [sp, #0x40]
    1c08:      	add	x2, x8, #0x20
    1c0c:      	blr	x9
    1c10:      	ldr	x8, [sp, #0x40]
    1c14:      	add	x0, x20, #0xd4
    1c18:      	mov	w9, #0x4                // =4
    1c1c:      	mov	w1, #0x4                // =4
    1c20:      	add	x8, x8, #0x24
    1c24:      	ldr	x8, [sp, #0x40]
    1c28:      	add	x2, x8, #0x24
    1c2c:      	blr	x9
    1c30:      	ldr	x8, [sp, #0x40]
    1c34:      	add	x0, x20, #0xd8
    1c38:      	mov	w9, #0x4                // =4
    1c3c:      	mov	w1, #0x4                // =4
    1c40:      	add	x8, x8, #0x28
    1c44:      	ldr	x8, [sp, #0x40]
    1c48:      	add	x2, x8, #0x28
    1c4c:      	blr	x9
    1c50:      	ldr	x24, [sp, #0x40]
    1c54:      	add	x0, x20, #0xe8
    1c58:      	mov	w8, #0x4                // =4
    1c5c:      	mov	w1, #0x8                // =8
    1c60:      	add	x19, x20, #0xe0
    1c64:      	add	x2, x24, #0x40
    1c68:      	blr	x8
    1c6c:      	add	x0, x20, #0xf0
    1c70:      	add	x2, x24, #0x30
    1c74:      	mov	w8, #0x4                // =4
    1c78:      	mov	w1, #0x8                // =8
    1c7c:      	blr	x8
    1c80:      	add	x2, x24, #0x38
    1c84:      	mov	w8, #0x4                // =4
    1c88:      	mov	x0, x19
    1c8c:      	mov	w1, #0x8                // =8
    1c90:      	blr	x8
    1c94:      	ldr	w8, [x20, #0xc8]
    1c98:      	add	x2, x29, #0xb50
    1c9c:      	mov	w9, #0x4                // =4
    1ca0:      	add	x0, sp, #0xc8
    1ca4:      	str	w8, [x20, #0x154]
    1ca8:      	add	x8, sp, #0xc8
    1cac:      	mov	w1, #0x8                // =8
    1cb0:      	add	x19, x20, #0x108
    1cb4:      	blr	x9
    1cb8:      	add	x24, sp, #0xb8
    1cbc:      	mov	w9, #0x48               // =72
    1cc0:      	add	x10, sp, #0x40
    1cc4:      	ldr	x8, [x24, #0x10]
    1cc8:      	mov	w11, #0x4               // =4
    1ccc:      	add	x0, sp, #0x40
    1cd0:      	mov	w1, #0x48               // =72
    1cd4:      	ldr	x2, [x24, #0x10]
    1cd8:      	blr	x11
    1cdc:      	ldr	x8, [sp, #0x48]
    1ce0:      	mov	w9, #0x4                // =4
    1ce4:      	mov	x0, x19
    1ce8:      	mov	w1, #0x4                // =4
    1cec:      	add	x8, x8, #0x218
    1cf0:      	ldr	x8, [sp, #0x48]
    1cf4:      	add	x2, x8, #0x218
    1cf8:      	blr	x9
    1cfc:      	ldr	x8, [sp, #0x50]
    1d00:      	add	x0, x20, #0x10c
    1d04:      	mov	w9, #0x4                // =4
    1d08:      	mov	w1, #0x4                // =4
    1d0c:      	add	x8, x8, #0x4d8
    1d10:      	ldr	x8, [sp, #0x50]
    1d14:      	add	x2, x8, #0x4d8
    1d18:      	blr	x9
    1d1c:      	ldr	x8, [sp, #0x58]
    1d20:      	add	x0, x20, #0x110
    1d24:      	mov	w9, #0x4                // =4
    1d28:      	mov	w1, #0x4                // =4
    1d2c:      	add	x8, x8, #0x58
    1d30:      	ldr	x8, [sp, #0x58]
    1d34:      	add	x2, x8, #0x58
    1d38:      	blr	x9
    1d3c:      	str	xzr, [sp, #0xb0]
    1d40:      	add	x2, x29, #0x938
    1d44:      	add	x8, sp, #0xb0
    1d48:      	add	x0, sp, #0xb0
    1d4c:      	mov	w1, #0x8                // =8
    1d50:      	blr	x21
    1d54:      	ldr	x8, [sp, #0xb0]
    1d58:      	cbz	x8, 0x1ddc <event_execve+0x1ddc>
    1d5c:      	str	wzr, [sp, #0xa8]
    1d60:      	add	x8, x8, #0x4
    1d64:      	add	x9, sp, #0xa8
    1d68:      	mov	w10, #0x4               // =4
    1d6c:      	add	x0, sp, #0xa8
    1d70:      	mov	w1, #0x4                // =4
    1d74:      	mov	w19, #0x4               // =4
    1d78:      	ldr	x8, [sp, #0xb0]
    1d7c:      	add	x2, x8, #0x4
    1d80:      	blr	x10
    1d84:      	ldr	x8, [sp, #0xb0]
    1d88:      	ldrsw	x9, [sp, #0xa8]
    1d8c:      	add	x10, sp, #0xb8
    1d90:      	mov	w11, #0x4               // =4
    1d94:      	add	x0, sp, #0xb8
    1d98:      	mov	w1, #0x10               // =16
    1d9c:      	add	x8, x8, x9, lsl #4
    1da0:      	mov	w9, #0x10               // =16
    1da4:      	add	x8, x8, #0x80
    1da8:      	ldr	x8, [sp, #0xb0]
    1dac:      	ldrsw	x9, [sp, #0xa8]
    1db0:      	add	x8, x8, x9, lsl #4
    1db4:      	add	x2, x8, #0x80
    1db8:      	blr	x11
    1dbc:      	ldr	x8, [x24, #0x8]
    1dc0:      	add	x0, x20, #0x114
    1dc4:      	mov	w1, #0x4                // =4
    1dc8:      	add	x8, x8, #0x158
    1dcc:      	ldr	x8, [x24, #0x8]
    1dd0:      	add	x2, x8, #0x158
    1dd4:      	blr	x19
    1dd8:      	b	0x1de0 <event_execve+0x1de0>
    1ddc:      	str	wzr, [x20, #0x114]
    1de0:      	ldr	x8, [sp, #0x60]
    1de4:      	add	x0, x20, #0x118
    1de8:      	mov	w9, #0x4                // =4
    1dec:      	mov	w1, #0x4                // =4
    1df0:      	mov	w19, #0x4               // =4
    1df4:      	add	x8, x8, #0x158
    1df8:      	ldr	x8, [sp, #0x60]
    1dfc:      	add	x2, x8, #0x158
    1e00:      	blr	x9
    1e04:      	ldr	x8, [sp, #0x68]
    1e08:      	add	x0, x20, #0x11c
    1e0c:      	mov	w9, #0x4                // =4
    1e10:      	mov	w1, #0x4                // =4
    1e14:      	add	x8, x8, #0x118
    1e18:      	ldr	x8, [sp, #0x68]
    1e1c:      	add	x2, x8, #0x118
    1e20:      	blr	x9
    1e24:      	ldr	x8, [sp, #0x70]
    1e28:      	add	x0, x20, #0x120
    1e2c:      	mov	w9, #0x4                // =4
    1e30:      	mov	w1, #0x4                // =4
    1e34:      	add	x8, x8, #0x98
    1e38:      	ldr	x8, [sp, #0x70]
    1e3c:      	add	x2, x8, #0x98
    1e40:      	blr	x9
    1e44:      	ldr	x8, [sp, #0x78]
    1e48:      	add	x0, x20, #0x124
    1e4c:      	mov	w9, #0x4                // =4
    1e50:      	mov	w1, #0x4                // =4
    1e54:      	add	x8, x8, #0x98
    1e58:      	ldr	x8, [sp, #0x78]
    1e5c:      	add	x2, x8, #0x98
    1e60:      	blr	x9
    1e64:      	ldr	x8, [sp, #0x80]
    1e68:      	add	x0, x20, #0x128
    1e6c:      	mov	w9, #0x4                // =4
    1e70:      	mov	w1, #0x4                // =4
    1e74:      	add	x8, x8, #0x58
    1e78:      	ldr	x8, [sp, #0x80]
    1e7c:      	add	x2, x8, #0x58
    1e80:      	blr	x9
    1e84:      	stp	xzr, xzr, [sp, #0xb0]
    1e88:      	mov	w21, #0x8               // =8
    1e8c:      	add	x8, sp, #0xb8
    1e90:      	mov	w9, #0x4                // =4
    1e94:      	add	x0, sp, #0xb8
    1e98:      	mov	w1, #0x8                // =8
    1e9c:      	mov	x2, x22
    1ea0:      	blr	x9
    1ea4:      	ldr	x8, [sp, #0xb8]
    1ea8:      	add	x9, sp, #0xb0
    1eac:      	mov	w10, #0x4               // =4
    1eb0:      	add	x0, sp, #0xb0
    1eb4:      	mov	w1, #0x8                // =8
    1eb8:      	add	x8, x8, #0x90
    1ebc:      	ldr	x8, [sp, #0xb8]
    1ec0:      	add	x2, x8, #0x90
    1ec4:      	blr	x10
    1ec8:      	ldr	x8, [sp, #0xb0]
    1ecc:      	add	x0, x20, #0x12c
    1ed0:      	mov	w1, #0x4                // =4
    1ed4:      	add	x8, x8, #0x158
    1ed8:      	ldr	x8, [sp, #0xb0]
    1edc:      	add	x2, x8, #0x158
    1ee0:      	blr	x19
    1ee4:      	mov	x19, x20
    1ee8:      	str	wzr, [sp, #0xb0]
    1eec:      	adrp	x0, 0x1000 <event_execve+0x1000>
    1ef0:      	mov	w8, #0x1                // =1
    1ef4:      	add	x9, sp, #0xb0
    1ef8:      	add	x1, sp, #0xb0
    1efc:      	stp	xzr, xzr, [x19, #0x10]!
    1f00:      	stp	xzr, xzr, [x19, #0x10]
    1f04:      	stp	xzr, xzr, [x19, #0x20]
    1f08:      	stp	xzr, xzr, [x19, #0x30]
    1f0c:      	stp	xzr, xzr, [x19, #0x40]
    1f10:      	stp	xzr, xzr, [x19, #0x50]
    1f14:      	stp	xzr, xzr, [x19, #0x60]
    1f18:      	stp	xzr, xzr, [x19, #0x70]
    1f1c:      	stp	xzr, xzr, [x19, #0x80]
    1f20:      	ldr	x0, [x0]
    1f24:      	blr	x8
    1f28:      	cbz	x0, 0x1f48 <event_execve+0x1f48>
    1f2c:      	ldr	x8, [x0, #0x20]
    1f30:      	ldr	w21, [x0, #0x10]
    1f34:      	mov	w9, #0x7270             // =29296
    1f38:      	movk	w9, #0x6367, lsl #16
    1f3c:      	cmp	x8, x9
    1f40:      	cset	w22, eq
    1f44:      	b	0x1f50 <event_execve+0x1f50>
    1f48:      	mov	w21, wzr
    1f4c:      	mov	w22, wzr
    1f50:      	str	xzr, [x24, #0x10]
    1f54:      	add	x2, x29, #0xcd0
    1f58:      	mov	w8, #0x8                // =8
    1f5c:      	mov	w9, #0x71               // =113
    1f60:      	add	x10, sp, #0xb8
    1f64:      	add	x0, sp, #0xb8
    1f68:      	mov	w1, #0x8                // =8
    1f6c:      	blr	x9
    1f70:      	ldr	x8, [sp, #0xb8]
    1f74:      	cbz	x8, 0x213c <event_execve+0x213c>
    1f78:      	cbz	w22, 0x1fe8 <event_execve+0x1fe8>
    1f7c:      	add	x8, x8, #0x78
    1f80:      	mov	w9, #0x8                // =8
    1f84:      	mov	w10, #0x71              // =113
    1f88:      	add	x11, sp, #0xc8
    1f8c:      	ldr	x8, [sp, #0xb8]
    1f90:      	add	x0, sp, #0xc8
    1f94:      	mov	w1, #0x8                // =8
    1f98:      	add	x2, x8, #0x78
    1f9c:      	blr	x10
    1fa0:      	ldr	x22, [x24, #0x10]
    1fa4:      	cbz	x22, 0x213c <event_execve+0x213c>
    1fa8:      	mov	w8, #0x50               // =80
    1fac:      	blr	x8
    1fb0:      	mov	w21, wzr
    1fb4:      	str	x0, [x19]
    1fb8:      	cbz	x0, 0x209c <event_execve+0x209c>
    1fbc:      	str	x0, [sp, #0x40]
    1fc0:      	adrp	x0, 0x1000 <event_execve+0x1000>
    1fc4:      	mov	w8, #0x1                // =1
    1fc8:      	add	x9, sp, #0x40
    1fcc:      	ldr	x0, [x0]
    1fd0:      	add	x1, sp, #0x40
    1fd4:      	blr	x8
    1fd8:      	cbz	x0, 0x20a4 <event_execve+0x20a4>
    1fdc:      	ldr	x8, [x0]
    1fe0:      	str	x8, [x20, #0x18]
    1fe4:      	b	0x20ac <event_execve+0x20ac>
    1fe8:      	cmp	w21, #0xb
    1fec:      	b.hi	0x213c <event_execve+0x213c>
    1ff0:      	ubfiz	x9, x21, #3, #32
    1ff4:      	mov	w10, #0x8               // =8
    1ff8:      	mov	w11, #0x71              // =113
    1ffc:      	add	x12, sp, #0x40
    2000:      	add	x0, sp, #0x40
    2004:      	mov	w1, #0x8                // =8
    2008:      	add	x8, x8, x9
    200c:      	ldr	x8, [sp, #0xb8]
    2010:      	add	x2, x8, x9
    2014:      	blr	x11
    2018:      	ldr	x8, [sp, #0x40]
    201c:      	cbz	x8, 0x212c <event_execve+0x212c>
    2020:      	mov	w9, #0x8                // =8
    2024:      	mov	w10, #0x71              // =113
    2028:      	add	x11, sp, #0xc8
    202c:      	ldr	x2, [sp, #0x40]
    2030:      	add	x0, sp, #0xc8
    2034:      	mov	w1, #0x8                // =8
    2038:      	blr	x10
    203c:      	ldr	x22, [x24, #0x10]
    2040:      	cbz	x22, 0x213c <event_execve+0x213c>
    2044:      	mov	w21, wzr
    2048:      	str	xzr, [sp, #0x40]
    204c:      	add	x2, x22, #0x100
    2050:      	mov	w8, #0x8                // =8
    2054:      	mov	w9, #0x71               // =113
    2058:      	add	x10, sp, #0x40
    205c:      	add	x0, sp, #0x40
    2060:      	mov	w1, #0x8                // =8
    2064:      	blr	x9
    2068:      	ldr	x8, [sp, #0x40]
    206c:      	str	xzr, [sp, #0x40]
    2070:      	cbz	x8, 0x211c <event_execve+0x211c>
    2074:      	add	x2, x8, #0x60
    2078:      	mov	w8, #0x8                // =8
    207c:      	mov	w9, #0x71               // =113
    2080:      	add	x10, sp, #0x40
    2084:      	add	x0, sp, #0x40
    2088:      	mov	w1, #0x8                // =8
    208c:      	blr	x9
    2090:      	ldr	x0, [sp, #0x40]
    2094:      	str	x0, [x19]
    2098:      	cbnz	x0, 0x1fbc <event_execve+0x1fbc>
    209c:      	orr	w21, w21, #0x200000
    20a0:      	b	0x20ac <event_execve+0x20ac>
    20a4:      	mov	x8, xzr
    20a8:      	str	xzr, [x20, #0x18]
    20ac:      	add	x2, x22, #0x100
    20b0:      	mov	w19, #0x8               // =8
    20b4:      	add	x8, sp, #0xb8
    20b8:      	mov	w9, #0x4                // =4
    20bc:      	add	x0, sp, #0xb8
    20c0:      	mov	w1, #0x8                // =8
    20c4:      	mov	w22, #0x4               // =4
    20c8:      	blr	x9
    20cc:      	ldr	x8, [sp, #0xb8]
    20d0:      	add	x9, sp, #0x40
    20d4:      	add	x0, sp, #0x40
    20d8:      	mov	w1, #0x8                // =8
    20dc:      	add	x8, x8, #0x10
    20e0:      	ldr	x8, [sp, #0xb8]
    20e4:      	add	x2, x8, #0x10
    20e8:      	blr	x22
    20ec:      	mov	w8, #0x10000            // =65536
    20f0:      	cbnz	x0, 0x2114 <event_execve+0x2114>
    20f4:      	ldr	x2, [sp, #0x40]
    20f8:      	cbz	x2, 0x2114 <event_execve+0x2114>
    20fc:      	add	x0, x20, #0x20
    2100:      	mov	w8, #0x80               // =128
    2104:      	mov	w9, #0x2d               // =45
    2108:      	mov	w1, #0x80               // =128
    210c:      	blr	x9
    2110:      	mov	w8, wzr
    2114:      	orr	w8, w8, w21
    2118:      	b	0x2140 <event_execve+0x2140>
    211c:      	mov	x0, xzr
    2120:      	str	xzr, [x19]
    2124:      	cbnz	xzr, 0x1fbc <event_execve+0x1fbc>
    2128:      	b	0x209c <event_execve+0x209c>
    212c:      	ldr	x22, [x24, #0x10]
    2130:      	cbz	x22, 0x213c <event_execve+0x213c>
    2134:      	mov	w21, #0x80000           // =524288
    2138:      	b	0x2048 <event_execve+0x2048>
    213c:      	mov	w8, wzr
    2140:      	ldr	w10, [x20, #0x15c]
    2144:      	stp	xzr, xzr, [x20, #0x130]
    2148:      	adrp	x1, 0x2000 <event_execve+0x2000>
    214c:      	mov	x9, xzr
    2150:      	mov	x0, x25
    2154:      	mov	w2, wzr
    2158:      	orr	w8, w10, w8
    215c:      	str	w8, [x20, #0x15c]
    2160:      	mov	w8, #0xc                // =12
    2164:      	ldr	x1, [x1]
    2168:      	blr	x8
    216c:      	ldp	x20, x19, [sp, #0x110]
    2170:      	mov	w0, wzr
    2174:      	ldr	x29, [sp, #0xd0]
    2178:      	ldp	x22, x21, [sp, #0x100]
    217c:      	ldp	x24, x23, [sp, #0xf0]
    2180:      	ldp	x30, x25, [sp, #0xe0]
    2184:      	add	sp, sp, #0x120
    2188:      	ret
