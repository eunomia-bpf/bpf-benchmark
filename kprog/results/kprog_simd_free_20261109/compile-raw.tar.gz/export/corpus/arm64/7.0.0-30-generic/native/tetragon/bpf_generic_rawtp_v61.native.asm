
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_generic_rawtp_v61.native.o:	file format elf64-littleaarch64

Disassembly of section .text:

0000000000000000 <extract_arg_depth>:
       0:      	cmp	w0, #0x9
       4:      	b.ls	0x10 <extract_arg_depth+0x10>
       8:      	mov	w0, #0x1                // =1
       c:      	ret
      10:      	str	x30, [sp, #-0x20]!
      14:      	stp	x20, x19, [sp, #0x10]
      18:      	ldr	x8, [x1]
      1c:      	add	x9, x8, w0, uxtw #3
      20:      	ldrh	w9, [x9, #0x6]
      24:      	cbz	w9, 0xb4 <extract_arg_depth+0xb4>
      28:      	mov	w9, w0
      2c:      	add	x10, x8, x9, lsl #3
      30:      	ldr	x8, [x1, #0x8]
      34:      	ldr	w11, [x10]
      38:      	ldrh	w10, [x10, #0x4]
      3c:      	ldr	x9, [x8]
      40:      	add	x9, x9, x11
      44:      	str	x9, [x8]
      48:      	cbz	w10, 0x78 <extract_arg_depth+0x78>
      4c:      	ldrb	w10, [x1, #0x10]
      50:      	mov	w19, w0
      54:      	cbz	w10, 0x88 <extract_arg_depth+0x88>
      58:      	mov	w10, #0x8               // =8
      5c:      	mov	w11, #0x94              // =148
      60:      	ldr	x0, [x1, #0x8]
      64:      	mov	x20, x1
      68:      	mov	w1, #0x8                // =8
      6c:      	ldr	x2, [x0]
      70:      	blr	x11
      74:      	tbnz	w0, #0x1f, 0xa8 <extract_arg_depth+0xa8>
      78:      	mov	w0, wzr
      7c:      	ldp	x20, x19, [sp, #0x10]
      80:      	ldr	x30, [sp], #0x20
      84:      	ret
      88:      	mov	w10, #0x8               // =8
      8c:      	mov	w11, #0x4               // =4
      90:      	ldr	x0, [x1, #0x8]
      94:      	mov	x20, x1
      98:      	mov	w1, #0x8                // =8
      9c:      	ldr	x2, [x0]
      a0:      	blr	x11
      a4:      	tbz	w0, #0x1f, 0x78 <extract_arg_depth+0x78>
      a8:      	ldr	x9, [x20, #0x18]
      ac:      	add	w8, w19, #0x1
      b0:      	str	w8, [x9]
      b4:      	mov	w0, #0x1                // =1
      b8:      	ldp	x20, x19, [sp, #0x10]
      bc:      	ldr	x30, [sp], #0x20
      c0:      	ret
      c4:      	nop
      c8:      	nop
      cc:      	nop

00000000000000d0 <do_bytes>:
      d0:      	sub	sp, sp, #0x40
      d4:      	stp	x30, x23, [sp, #0x10]
      d8:      	stp	x22, x21, [sp, #0x20]
      dc:      	stp	x20, x19, [sp, #0x30]
      e0:      	mov	x19, x3
      e4:      	mov	x21, x2
      e8:      	mov	x20, x1
      ec:      	mov	x22, x0
      f0:      	bl	0x310 <__do_bytes>
      f4:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
      f8:      	and	x23, x0, #0x7fffffff
      fc:      	subs	x3, x19, x23
     100:      	b.eq	0x2f8 <do_bytes+0x228>
     104:      	add	x2, x23, x21
     108:      	mov	x0, x22
     10c:      	mov	x1, x20
     110:      	bl	0x310 <__do_bytes>
     114:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     118:      	and	x8, x0, #0x7fffffff
     11c:      	add	x23, x8, x23
     120:      	subs	x3, x19, x23
     124:      	b.eq	0x2f8 <do_bytes+0x228>
     128:      	add	x2, x23, x21
     12c:      	mov	x0, x22
     130:      	mov	x1, x20
     134:      	bl	0x310 <__do_bytes>
     138:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     13c:      	and	x8, x0, #0x7fffffff
     140:      	add	x23, x8, x23
     144:      	subs	x3, x19, x23
     148:      	b.eq	0x2f8 <do_bytes+0x228>
     14c:      	add	x2, x23, x21
     150:      	mov	x0, x22
     154:      	mov	x1, x20
     158:      	bl	0x310 <__do_bytes>
     15c:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     160:      	and	x8, x0, #0x7fffffff
     164:      	add	x23, x8, x23
     168:      	subs	x3, x19, x23
     16c:      	b.eq	0x2f8 <do_bytes+0x228>
     170:      	add	x2, x23, x21
     174:      	mov	x0, x22
     178:      	mov	x1, x20
     17c:      	bl	0x310 <__do_bytes>
     180:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     184:      	and	x8, x0, #0x7fffffff
     188:      	add	x23, x8, x23
     18c:      	subs	x3, x19, x23
     190:      	b.eq	0x2f8 <do_bytes+0x228>
     194:      	add	x2, x23, x21
     198:      	mov	x0, x22
     19c:      	mov	x1, x20
     1a0:      	bl	0x310 <__do_bytes>
     1a4:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     1a8:      	and	x8, x0, #0x7fffffff
     1ac:      	add	x23, x8, x23
     1b0:      	subs	x3, x19, x23
     1b4:      	b.eq	0x2f8 <do_bytes+0x228>
     1b8:      	add	x2, x23, x21
     1bc:      	mov	x0, x22
     1c0:      	mov	x1, x20
     1c4:      	bl	0x310 <__do_bytes>
     1c8:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     1cc:      	and	x8, x0, #0x7fffffff
     1d0:      	add	x23, x8, x23
     1d4:      	subs	x3, x19, x23
     1d8:      	b.eq	0x2f8 <do_bytes+0x228>
     1dc:      	add	x2, x23, x21
     1e0:      	mov	x0, x22
     1e4:      	mov	x1, x20
     1e8:      	bl	0x310 <__do_bytes>
     1ec:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     1f0:      	and	x8, x0, #0x7fffffff
     1f4:      	add	x23, x8, x23
     1f8:      	subs	x3, x19, x23
     1fc:      	b.eq	0x2f8 <do_bytes+0x228>
     200:      	add	x2, x23, x21
     204:      	mov	x0, x22
     208:      	mov	x1, x20
     20c:      	bl	0x310 <__do_bytes>
     210:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     214:      	and	x8, x0, #0x7fffffff
     218:      	add	x23, x8, x23
     21c:      	subs	x3, x19, x23
     220:      	b.eq	0x2f8 <do_bytes+0x228>
     224:      	add	x2, x23, x21
     228:      	mov	x0, x22
     22c:      	mov	x1, x20
     230:      	bl	0x310 <__do_bytes>
     234:      	tbnz	w0, #0x1f, 0x258 <do_bytes+0x188>
     238:      	and	x8, x0, #0x7fffffff
     23c:      	add	x19, x8, x23
     240:      	mov	x0, x19
     244:      	ldp	x20, x19, [sp, #0x30]
     248:      	ldp	x22, x21, [sp, #0x20]
     24c:      	ldp	x30, x23, [sp, #0x10]
     250:      	add	sp, sp, #0x40
     254:      	ret
     258:      	sxtw	x19, w0
     25c:      	str	wzr, [sp, #0xc]
     260:      	adrp	x0, 0x0 <extract_arg_depth>
     264:      	mov	w8, #0x1                // =1
     268:      	ldr	x0, [x0]
     26c:      	add	x9, sp, #0xc
     270:      	add	x1, sp, #0xc
     274:      	blr	x8
     278:      	cbz	x0, 0x2f8 <do_bytes+0x228>
     27c:      	cmn	x19, #0xc
     280:      	b.gt	0x2a4 <do_bytes+0x1d4>
     284:      	cmn	x19, #0x1c
     288:      	b.eq	0x2c4 <do_bytes+0x1f4>
     28c:      	cmn	x19, #0x16
     290:      	b.eq	0x2dc <do_bytes+0x20c>
     294:      	cmn	x19, #0x10
     298:      	b.ne	0x2d4 <do_bytes+0x204>
     29c:      	add	x8, x0, #0x558
     2a0:      	b	0x2e8 <do_bytes+0x218>
     2a4:      	cmn	x19, #0xb
     2a8:      	b.eq	0x2cc <do_bytes+0x1fc>
     2ac:      	cmn	x19, #0x7
     2b0:      	b.eq	0x2e4 <do_bytes+0x214>
     2b4:      	cmn	x19, #0x2
     2b8:      	b.ne	0x2d4 <do_bytes+0x204>
     2bc:      	add	x8, x0, #0x548
     2c0:      	b	0x2e8 <do_bytes+0x218>
     2c4:      	add	x8, x0, #0x568
     2c8:      	b	0x2e8 <do_bytes+0x218>
     2cc:      	add	x8, x0, #0x570
     2d0:      	b	0x2e8 <do_bytes+0x218>
     2d4:      	add	x8, x0, #0x540
     2d8:      	b	0x2e8 <do_bytes+0x218>
     2dc:      	add	x8, x0, #0x560
     2e0:      	b	0x2e8 <do_bytes+0x218>
     2e4:      	add	x8, x0, #0x550
     2e8:      	ldaxr	x9, [x8]
     2ec:      	add	x9, x9, #0x1
     2f0:      	stlxr	w10, x9, [x8]
     2f4:      	cbnz	w10, 0x2e8 <do_bytes+0x218>
     2f8:      	mov	x0, x19
     2fc:      	ldp	x20, x19, [sp, #0x30]
     300:      	ldp	x22, x21, [sp, #0x20]
     304:      	ldp	x30, x23, [sp, #0x10]
     308:      	add	sp, sp, #0x40
     30c:      	ret

0000000000000310 <__do_bytes>:
     310:      	str	x30, [sp, #-0x30]!
     314:      	stp	x22, x21, [sp, #0x10]
     318:      	stp	x20, x19, [sp, #0x20]
     31c:      	tbnz	x3, #0x3f, 0x3b4 <__do_bytes+0xa4>
     320:      	mov	w8, #0x7fe0             // =32736
     324:      	mov	x22, x0
     328:      	add	x0, x1, #0x20
     32c:      	mov	x20, x1
     330:      	cmp	x3, x8
     334:      	csel	x19, x3, x8, lo
     338:      	mov	w8, #0x4                // =4
     33c:      	mov	w1, w19
     340:      	blr	x8
     344:      	tbnz	w0, #0x1f, 0x3ec <__do_bytes+0xdc>
     348:      	add	w21, w19, #0x20
     34c:      	str	wzr, [sp, #0xc]
     350:      	adrp	x0, 0x0 <extract_arg_depth>
     354:      	mov	w8, #0x1                // =1
     358:      	str	w21, [x20, #0x4]
     35c:      	add	x9, sp, #0xc
     360:      	add	x1, sp, #0xc
     364:      	ldr	x0, [x0]
     368:      	blr	x8
     36c:      	cbz	x0, 0x3cc <__do_bytes+0xbc>
     370:      	ldrb	w8, [x0, #0x28]
     374:      	cbz	w8, 0x3cc <__do_bytes+0xbc>
     378:      	adrp	x1, 0x0 <extract_arg_depth>
     37c:      	mov	w8, #-0x1               // =-1
     380:      	mov	w9, #0x19               // =25
     384:      	ldr	x1, [x1]
     388:      	mov	x0, x22
     38c:      	mov	w2, #-0x1               // =-1
     390:      	mov	x3, x20
     394:      	mov	x4, x21
     398:      	blr	x9
     39c:      	tbnz	w0, #0x1f, 0x3ec <__do_bytes+0xdc>
     3a0:      	mov	x0, x19
     3a4:      	ldp	x20, x19, [sp, #0x20]
     3a8:      	ldp	x22, x21, [sp, #0x10]
     3ac:      	ldr	x30, [sp], #0x30
     3b0:      	ret
     3b4:      	mov	x19, #-0x1              // =-1
     3b8:      	mov	x0, x19
     3bc:      	ldp	x20, x19, [sp, #0x20]
     3c0:      	ldp	x22, x21, [sp, #0x10]
     3c4:      	ldr	x30, [sp], #0x30
     3c8:      	ret
     3cc:      	adrp	x0, 0x0 <extract_arg_depth>
     3d0:      	mov	x3, xzr
     3d4:      	mov	w8, #0x82               // =130
     3d8:      	ldr	x0, [x0]
     3dc:      	mov	x1, x20
     3e0:      	mov	x2, x21
     3e4:      	blr	x8
     3e8:      	tbz	w0, #0x1f, 0x3a0 <__do_bytes+0x90>
     3ec:      	sxtw	x19, w0
     3f0:      	mov	x0, x19
     3f4:      	ldp	x20, x19, [sp, #0x20]
     3f8:      	ldp	x22, x21, [sp, #0x10]
     3fc:      	ldr	x30, [sp], #0x30
     400:      	ret
     404:      	nop
     408:      	nop
     40c:      	nop

0000000000000410 <filter_64ty>:
     410:      	str	x30, [sp, #-0x10]!
     414:      	mov	x8, x0
     418:      	mov	x0, xzr
     41c:      	ldr	w9, [x8, #0x4]
     420:      	cmp	w9, #0x20
     424:      	b.hi	0x484 <filter_64ty+0x74>
     428:      	mov	w10, #0x1               // =1
     42c:      	mov	w11, #0x101e            // =4126
     430:      	lsl	x10, x10, x9
     434:      	tst	x10, x11
     438:      	b.eq	0x44c <filter_64ty+0x3c>
     43c:      	mov	x0, x8
     440:      	bl	0x610 <filter_64ty_selector_val>
     444:      	ldr	x30, [sp], #0x10
     448:      	ret
     44c:      	mov	w10, #0x1               // =1
     450:      	lsl	x10, x10, x9
     454:      	tst	x10, #0xc00
     458:      	b.ne	0x47c <filter_64ty+0x6c>
     45c:      	mov	w10, #0x1               // =1
     460:      	lsl	x9, x10, x9
     464:      	tst	x9, #0x180000000
     468:      	b.eq	0x484 <filter_64ty+0x74>
     46c:      	mov	x0, x8
     470:      	bl	0xa10 <filter_64ty_range>
     474:      	ldr	x30, [sp], #0x10
     478:      	ret
     47c:      	mov	x0, x8
     480:      	bl	0x970 <filter_64ty_map>
     484:      	ldr	x30, [sp], #0x10
     488:      	ret
     48c:      	nop

0000000000000490 <filter_32ty>:
     490:      	str	x30, [sp, #-0x10]!
     494:      	mov	x8, x0
     498:      	mov	x0, xzr
     49c:      	ldr	w9, [x8, #0x4]
     4a0:      	cmp	w9, #0x20
     4a4:      	b.hi	0x504 <filter_32ty+0x74>
     4a8:      	mov	w10, #0x1               // =1
     4ac:      	mov	w11, #0x101e            // =4126
     4b0:      	lsl	x10, x10, x9
     4b4:      	tst	x10, x11
     4b8:      	b.eq	0x4cc <filter_32ty+0x3c>
     4bc:      	mov	x0, x8
     4c0:      	bl	0xc60 <filter_32ty_selector_val>
     4c4:      	ldr	x30, [sp], #0x10
     4c8:      	ret
     4cc:      	mov	w10, #0x1               // =1
     4d0:      	lsl	x10, x10, x9
     4d4:      	tst	x10, #0xc00
     4d8:      	b.ne	0x4fc <filter_32ty+0x6c>
     4dc:      	mov	w10, #0x1               // =1
     4e0:      	lsl	x9, x10, x9
     4e4:      	tst	x9, #0x180000000
     4e8:      	b.eq	0x504 <filter_32ty+0x74>
     4ec:      	mov	x0, x8
     4f0:      	bl	0x1080 <filter_32ty_range>
     4f4:      	ldr	x30, [sp], #0x10
     4f8:      	ret
     4fc:      	mov	x0, x8
     500:      	bl	0xfc0 <filter_32ty_map>
     504:      	ldr	x30, [sp], #0x10
     508:      	ret
     50c:      	nop

0000000000000510 <filter_16ty>:
     510:      	str	x30, [sp, #-0x10]!
     514:      	mov	x8, x0
     518:      	mov	x0, xzr
     51c:      	ldr	w9, [x8, #0x4]
     520:      	cmp	w9, #0x20
     524:      	b.hi	0x584 <filter_16ty+0x74>
     528:      	mov	w10, #0x1               // =1
     52c:      	mov	w11, #0x101e            // =4126
     530:      	lsl	x10, x10, x9
     534:      	tst	x10, x11
     538:      	b.eq	0x54c <filter_16ty+0x3c>
     53c:      	mov	x0, x8
     540:      	bl	0x12d0 <filter_16ty_selector_val>
     544:      	ldr	x30, [sp], #0x10
     548:      	ret
     54c:      	mov	w10, #0x1               // =1
     550:      	lsl	x10, x10, x9
     554:      	tst	x10, #0xc00
     558:      	b.ne	0x57c <filter_16ty+0x6c>
     55c:      	mov	w10, #0x1               // =1
     560:      	lsl	x9, x10, x9
     564:      	tst	x9, #0x180000000
     568:      	b.eq	0x584 <filter_16ty+0x74>
     56c:      	mov	x0, x8
     570:      	bl	0x16f0 <filter_16ty_range>
     574:      	ldr	x30, [sp], #0x10
     578:      	ret
     57c:      	mov	x0, x8
     580:      	bl	0x1630 <filter_16ty_map>
     584:      	ldr	x30, [sp], #0x10
     588:      	ret
     58c:      	nop

0000000000000590 <filter_8ty>:
     590:      	str	x30, [sp, #-0x10]!
     594:      	mov	x8, x0
     598:      	mov	x0, xzr
     59c:      	ldr	w9, [x8, #0x4]
     5a0:      	cmp	w9, #0x20
     5a4:      	b.hi	0x604 <filter_8ty+0x74>
     5a8:      	mov	w10, #0x1               // =1
     5ac:      	mov	w11, #0x101e            // =4126
     5b0:      	lsl	x10, x10, x9
     5b4:      	tst	x10, x11
     5b8:      	b.eq	0x5cc <filter_8ty+0x3c>
     5bc:      	mov	x0, x8
     5c0:      	bl	0x1940 <filter_8ty_selector_val>
     5c4:      	ldr	x30, [sp], #0x10
     5c8:      	ret
     5cc:      	mov	w10, #0x1               // =1
     5d0:      	lsl	x10, x10, x9
     5d4:      	tst	x10, #0xc00
     5d8:      	b.ne	0x5fc <filter_8ty+0x6c>
     5dc:      	mov	w10, #0x1               // =1
     5e0:      	lsl	x9, x10, x9
     5e4:      	tst	x9, #0x180000000
     5e8:      	b.eq	0x604 <filter_8ty+0x74>
     5ec:      	mov	x0, x8
     5f0:      	bl	0x1d60 <filter_8ty_range>
     5f4:      	ldr	x30, [sp], #0x10
     5f8:      	ret
     5fc:      	mov	x0, x8
     600:      	bl	0x1ca0 <filter_8ty_map>
     604:      	ldr	x30, [sp], #0x10
     608:      	ret
     60c:      	nop

0000000000000610 <filter_64ty_selector_val>:
     610:      	ldr	w8, [x0, #0x4]
     614:      	cmp	w8, #0x25
     618:      	b.hi	0x68c <filter_64ty_selector_val+0x7c>
     61c:      	mov	x10, #0x40              // =64
     620:      	mov	w9, #0x1                // =1
     624:      	movk	x10, #0xc00, lsl #16
     628:      	lsl	x9, x9, x8
     62c:      	movk	x10, #0x20, lsl #32
     630:      	tst	x9, x10
     634:      	b.eq	0x640 <filter_64ty_selector_val+0x30>
     638:      	mov	w0, #0x1                // =1
     63c:      	ret
     640:      	mov	w9, #0x1                // =1
     644:      	lsl	x9, x9, x8
     648:      	tst	x9, #0x18
     64c:      	b.eq	0x66c <filter_64ty_selector_val+0x5c>
     650:      	ldr	x9, [x1]
     654:      	ldr	x10, [x0, #0x10]
     658:      	cmp	x9, x10
     65c:      	b.ne	0x70c <filter_64ty_selector_val+0xfc>
     660:      	cmp	w8, #0x3
     664:      	cset	w0, eq
     668:      	ret
     66c:      	cmp	x8, #0xc
     670:      	b.ne	0x68c <filter_64ty_selector_val+0x7c>
     674:      	ldr	x8, [x1]
     678:      	ldr	x9, [x0, #0x10]
     67c:      	tst	x8, x9
     680:      	b.eq	0x7b8 <filter_64ty_selector_val+0x1a8>
     684:      	mov	w0, #0x1                // =1
     688:      	ret
     68c:      	cmp	w8, #0x1
     690:      	b.eq	0x6d4 <filter_64ty_selector_val+0xc4>
     694:      	cmp	w8, #0x2
     698:      	b.ne	0x960 <filter_64ty_selector_val+0x350>
     69c:      	ldr	w8, [x0, #0xc]
     6a0:      	cmp	w8, #0xc
     6a4:      	b.hi	0x7f0 <filter_64ty_selector_val+0x1e0>
     6a8:      	mov	w9, #0x1                // =1
     6ac:      	lsl	w8, w9, w8
     6b0:      	mov	w9, #0x1402             // =5122
     6b4:      	tst	w8, w9
     6b8:      	b.eq	0x7f0 <filter_64ty_selector_val+0x1e0>
     6bc:      	ldr	x8, [x1]
     6c0:      	ldr	x9, [x0, #0x10]
     6c4:      	cmp	x8, x9
     6c8:      	b.ge	0x798 <filter_64ty_selector_val+0x188>
     6cc:      	mov	w0, #0x1                // =1
     6d0:      	ret
     6d4:      	ldr	w8, [x0, #0xc]
     6d8:      	cmp	w8, #0xc
     6dc:      	b.hi	0x7d8 <filter_64ty_selector_val+0x1c8>
     6e0:      	mov	w9, #0x1                // =1
     6e4:      	lsl	w8, w9, w8
     6e8:      	mov	w9, #0x1402             // =5122
     6ec:      	tst	w8, w9
     6f0:      	b.eq	0x7d8 <filter_64ty_selector_val+0x1c8>
     6f4:      	ldr	x8, [x1]
     6f8:      	ldr	x9, [x0, #0x10]
     6fc:      	cmp	x8, x9
     700:      	b.le	0x778 <filter_64ty_selector_val+0x168>
     704:      	mov	w0, #0x1                // =1
     708:      	ret
     70c:      	ldr	w10, [x0, #0x8]
     710:      	cmp	w10, #0x11
     714:      	b.lo	0x74c <filter_64ty_selector_val+0x13c>
     718:      	ldr	x11, [x0, #0x18]
     71c:      	cmp	x9, x11
     720:      	b.eq	0x660 <filter_64ty_selector_val+0x50>
     724:      	cmp	w10, #0x19
     728:      	b.lo	0x74c <filter_64ty_selector_val+0x13c>
     72c:      	ldr	x11, [x0, #0x20]
     730:      	cmp	x9, x11
     734:      	b.eq	0x660 <filter_64ty_selector_val+0x50>
     738:      	cmp	w10, #0x21
     73c:      	b.lo	0x74c <filter_64ty_selector_val+0x13c>
     740:      	ldr	x10, [x0, #0x28]
     744:      	cmp	x9, x10
     748:      	b.eq	0x660 <filter_64ty_selector_val+0x50>
     74c:      	cmp	w8, #0x25
     750:      	b.hi	0x960 <filter_64ty_selector_val+0x350>
     754:      	mov	w9, #0x1                // =1
     758:      	lsl	x8, x9, x8
     75c:      	mov	x9, #0x50               // =80
     760:      	movk	x9, #0xc00, lsl #16
     764:      	movk	x9, #0x20, lsl #32
     768:      	tst	x8, x9
     76c:      	b.eq	0x960 <filter_64ty_selector_val+0x350>
     770:      	mov	w0, #0x1                // =1
     774:      	ret
     778:      	ldr	w9, [x0, #0x8]
     77c:      	cmp	w9, #0x11
     780:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     784:      	ldr	x10, [x0, #0x18]
     788:      	cmp	x8, x10
     78c:      	b.le	0x848 <filter_64ty_selector_val+0x238>
     790:      	mov	w0, #0x1                // =1
     794:      	ret
     798:      	ldr	w9, [x0, #0x8]
     79c:      	cmp	w9, #0x11
     7a0:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     7a4:      	ldr	x10, [x0, #0x18]
     7a8:      	cmp	x8, x10
     7ac:      	b.ge	0x864 <filter_64ty_selector_val+0x254>
     7b0:      	mov	w0, #0x1                // =1
     7b4:      	ret
     7b8:      	ldr	w9, [x0, #0x8]
     7bc:      	cmp	w9, #0x11
     7c0:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     7c4:      	ldr	x10, [x0, #0x18]
     7c8:      	tst	x8, x10
     7cc:      	b.eq	0x880 <filter_64ty_selector_val+0x270>
     7d0:      	mov	w0, #0x1                // =1
     7d4:      	ret
     7d8:      	ldr	x8, [x1]
     7dc:      	ldr	x9, [x0, #0x10]
     7e0:      	cmp	x8, x9
     7e4:      	b.ls	0x808 <filter_64ty_selector_val+0x1f8>
     7e8:      	mov	w0, #0x1                // =1
     7ec:      	ret
     7f0:      	ldr	x8, [x1]
     7f4:      	ldr	x9, [x0, #0x10]
     7f8:      	cmp	x8, x9
     7fc:      	b.hs	0x828 <filter_64ty_selector_val+0x218>
     800:      	mov	w0, #0x1                // =1
     804:      	ret
     808:      	ldr	w9, [x0, #0x8]
     80c:      	cmp	w9, #0x11
     810:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     814:      	ldr	x10, [x0, #0x18]
     818:      	cmp	x8, x10
     81c:      	b.ls	0x89c <filter_64ty_selector_val+0x28c>
     820:      	mov	w0, #0x1                // =1
     824:      	ret
     828:      	ldr	w9, [x0, #0x8]
     82c:      	cmp	w9, #0x11
     830:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     834:      	ldr	x10, [x0, #0x18]
     838:      	cmp	x8, x10
     83c:      	b.hs	0x8b8 <filter_64ty_selector_val+0x2a8>
     840:      	mov	w0, #0x1                // =1
     844:      	ret
     848:      	cmp	w9, #0x19
     84c:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     850:      	ldr	x10, [x0, #0x20]
     854:      	cmp	x8, x10
     858:      	b.le	0x8d4 <filter_64ty_selector_val+0x2c4>
     85c:      	mov	w0, #0x1                // =1
     860:      	ret
     864:      	cmp	w9, #0x19
     868:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     86c:      	ldr	x10, [x0, #0x20]
     870:      	cmp	x8, x10
     874:      	b.ge	0x8f0 <filter_64ty_selector_val+0x2e0>
     878:      	mov	w0, #0x1                // =1
     87c:      	ret
     880:      	cmp	w9, #0x19
     884:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     888:      	ldr	x10, [x0, #0x20]
     88c:      	tst	x8, x10
     890:      	b.eq	0x90c <filter_64ty_selector_val+0x2fc>
     894:      	mov	w0, #0x1                // =1
     898:      	ret
     89c:      	cmp	w9, #0x19
     8a0:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     8a4:      	ldr	x10, [x0, #0x20]
     8a8:      	cmp	x8, x10
     8ac:      	b.ls	0x928 <filter_64ty_selector_val+0x318>
     8b0:      	mov	w0, #0x1                // =1
     8b4:      	ret
     8b8:      	cmp	w9, #0x19
     8bc:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     8c0:      	ldr	x10, [x0, #0x20]
     8c4:      	cmp	x8, x10
     8c8:      	b.hs	0x944 <filter_64ty_selector_val+0x334>
     8cc:      	mov	w0, #0x1                // =1
     8d0:      	ret
     8d4:      	cmp	w9, #0x21
     8d8:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     8dc:      	ldr	x9, [x0, #0x28]
     8e0:      	cmp	x8, x9
     8e4:      	b.le	0x960 <filter_64ty_selector_val+0x350>
     8e8:      	mov	w0, #0x1                // =1
     8ec:      	ret
     8f0:      	cmp	w9, #0x21
     8f4:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     8f8:      	ldr	x9, [x0, #0x28]
     8fc:      	cmp	x8, x9
     900:      	b.ge	0x960 <filter_64ty_selector_val+0x350>
     904:      	mov	w0, #0x1                // =1
     908:      	ret
     90c:      	cmp	w9, #0x21
     910:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     914:      	ldr	x9, [x0, #0x28]
     918:      	tst	x8, x9
     91c:      	b.eq	0x960 <filter_64ty_selector_val+0x350>
     920:      	mov	w0, #0x1                // =1
     924:      	ret
     928:      	cmp	w9, #0x21
     92c:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     930:      	ldr	x9, [x0, #0x28]
     934:      	cmp	x8, x9
     938:      	b.ls	0x960 <filter_64ty_selector_val+0x350>
     93c:      	mov	w0, #0x1                // =1
     940:      	ret
     944:      	cmp	w9, #0x21
     948:      	b.lo	0x960 <filter_64ty_selector_val+0x350>
     94c:      	ldr	x9, [x0, #0x28]
     950:      	cmp	x8, x9
     954:      	b.hs	0x960 <filter_64ty_selector_val+0x350>
     958:      	mov	w0, #0x1                // =1
     95c:      	ret
     960:      	mov	x0, xzr
     964:      	ret
     968:      	nop
     96c:      	nop

0000000000000970 <filter_64ty_map>:
     970:      	sub	sp, sp, #0x30
     974:      	str	x30, [sp, #0x10]
     978:      	stp	x20, x19, [sp, #0x20]
     97c:      	ldrb	w8, [x0, #0x10]
     980:      	mov	x19, x0
     984:      	adrp	x0, 0x0 <extract_arg_depth>
     988:      	add	x9, sp, #0x1c
     98c:      	str	w8, [sp, #0x1c]
     990:      	mov	w8, #0x1                // =1
     994:      	mov	x20, x1
     998:      	add	x1, sp, #0x1c
     99c:      	ldr	x0, [x0]
     9a0:      	blr	x8
     9a4:      	cbz	x0, 0x9f4 <filter_64ty_map+0x84>
     9a8:      	ldr	x8, [x20]
     9ac:      	add	x9, sp, #0x8
     9b0:      	add	x1, sp, #0x8
     9b4:      	str	x8, [sp, #0x8]
     9b8:      	mov	w8, #0x1                // =1
     9bc:      	blr	x8
     9c0:      	ldr	w8, [x19, #0x4]
     9c4:      	cmp	w8, #0xb
     9c8:      	b.eq	0x9e0 <filter_64ty_map+0x70>
     9cc:      	cmp	w8, #0xa
     9d0:      	b.ne	0x9ec <filter_64ty_map+0x7c>
     9d4:      	cmp	x0, #0x0
     9d8:      	cset	w8, ne
     9dc:      	b	0x9f0 <filter_64ty_map+0x80>
     9e0:      	cmp	x0, #0x0
     9e4:      	cset	w8, eq
     9e8:      	b	0x9f0 <filter_64ty_map+0x80>
     9ec:      	mov	w8, wzr
     9f0:      	mov	w0, w8
     9f4:      	ldp	x20, x19, [sp, #0x20]
     9f8:      	ldr	x30, [sp, #0x10]
     9fc:      	add	sp, sp, #0x30
     a00:      	ret
     a04:      	nop
     a08:      	nop
     a0c:      	nop

0000000000000a10 <filter_64ty_range>:
     a10:      	ldr	w9, [x0, #0xc]
     a14:      	ldr	w8, [x0, #0x4]
     a18:      	mov	w10, #0x1               // =1
     a1c:      	cmp	w9, #0xc
     a20:      	lsl	w9, w10, w9
     a24:      	mov	w10, #0x1402            // =5122
     a28:      	and	w9, w9, w10
     a2c:      	ccmp	w9, #0x0, #0x4, ls
     a30:      	b.eq	0xb30 <filter_64ty_range+0x120>
     a34:      	ldr	x10, [x1]
     a38:      	cmp	w8, #0x1f
     a3c:      	b.ne	0xac4 <filter_64ty_range+0xb4>
     a40:      	ldr	x9, [x0, #0x10]
     a44:      	cmp	x9, x10
     a48:      	b.gt	0xa58 <filter_64ty_range+0x48>
     a4c:      	ldr	x9, [x0, #0x18]
     a50:      	cmp	x10, x9
     a54:      	b.le	0xb54 <filter_64ty_range+0x144>
     a58:      	ldr	w9, [x0, #0x8]
     a5c:      	cmp	w9, #0x19
     a60:      	b.lo	0xc40 <filter_64ty_range+0x230>
     a64:      	ldr	x11, [x0, #0x20]
     a68:      	cmp	x11, x10
     a6c:      	b.gt	0xa7c <filter_64ty_range+0x6c>
     a70:      	ldr	x11, [x0, #0x28]
     a74:      	cmp	x10, x11
     a78:      	b.le	0xb54 <filter_64ty_range+0x144>
     a7c:      	cmp	w9, #0x29
     a80:      	b.lo	0xc40 <filter_64ty_range+0x230>
     a84:      	ldr	x11, [x0, #0x30]
     a88:      	cmp	x11, x10
     a8c:      	b.gt	0xa9c <filter_64ty_range+0x8c>
     a90:      	ldr	x11, [x0, #0x38]
     a94:      	cmp	x10, x11
     a98:      	b.le	0xb54 <filter_64ty_range+0x144>
     a9c:      	cmp	w9, #0x39
     aa0:      	b.lo	0xc40 <filter_64ty_range+0x230>
     aa4:      	ldr	x11, [x0, #0x40]
     aa8:      	mov	w9, wzr
     aac:      	cmp	x11, x10
     ab0:      	b.gt	0xc30 <filter_64ty_range+0x220>
     ab4:      	ldr	x11, [x0, #0x48]
     ab8:      	cmp	x10, x11
     abc:      	b.le	0xb54 <filter_64ty_range+0x144>
     ac0:      	b	0xc30 <filter_64ty_range+0x220>
     ac4:      	ldp	x9, x12, [x0, #0x10]
     ac8:      	cmp	x9, x10
     acc:      	ldr	w11, [x0, #0x8]
     ad0:      	ccmp	x10, x12, #0x0, le
     ad4:      	cset	w9, le
     ad8:      	cmp	w11, #0x19
     adc:      	b.lo	0xc30 <filter_64ty_range+0x220>
     ae0:      	ldp	x12, x13, [x0, #0x20]
     ae4:      	cmp	x12, x10
     ae8:      	ccmp	x10, x13, #0x0, le
     aec:      	csinc	w9, w9, wzr, gt
     af0:      	cmp	w11, #0x29
     af4:      	b.lo	0xc30 <filter_64ty_range+0x220>
     af8:      	ldp	x12, x13, [x0, #0x30]
     afc:      	cmp	x12, x10
     b00:      	ccmp	x10, x13, #0x0, le
     b04:      	csinc	w9, w9, wzr, gt
     b08:      	cmp	w11, #0x39
     b0c:      	b.lo	0xc30 <filter_64ty_range+0x220>
     b10:      	ldp	x11, x12, [x0, #0x40]
     b14:      	cmp	x11, x10
     b18:      	ccmp	x10, x12, #0x0, le
     b1c:      	csinc	w9, w9, wzr, gt
     b20:      	cmp	w8, #0x20
     b24:      	eor	w8, w9, #0x1
     b28:      	csel	w0, wzr, w8, ne
     b2c:      	ret
     b30:      	ldr	x10, [x1]
     b34:      	cmp	w8, #0x1f
     b38:      	b.ne	0xb5c <filter_64ty_range+0x14c>
     b3c:      	ldr	x9, [x0, #0x10]
     b40:      	cmp	x9, x10
     b44:      	b.hi	0xbc8 <filter_64ty_range+0x1b8>
     b48:      	ldr	x9, [x0, #0x18]
     b4c:      	cmp	x10, x9
     b50:      	b.hi	0xbc8 <filter_64ty_range+0x1b8>
     b54:      	mov	w0, #0x1                // =1
     b58:      	ret
     b5c:      	ldp	x9, x12, [x0, #0x10]
     b60:      	cmp	x9, x10
     b64:      	ldr	w11, [x0, #0x8]
     b68:      	ccmp	x10, x12, #0x2, ls
     b6c:      	cset	w9, ls
     b70:      	cmp	w11, #0x19
     b74:      	b.lo	0xc30 <filter_64ty_range+0x220>
     b78:      	ldp	x12, x13, [x0, #0x20]
     b7c:      	cmp	x12, x10
     b80:      	ccmp	x10, x13, #0x2, ls
     b84:      	csinc	w9, w9, wzr, hi
     b88:      	cmp	w11, #0x29
     b8c:      	b.lo	0xc30 <filter_64ty_range+0x220>
     b90:      	ldp	x12, x13, [x0, #0x30]
     b94:      	cmp	x12, x10
     b98:      	ccmp	x10, x13, #0x2, ls
     b9c:      	csinc	w9, w9, wzr, hi
     ba0:      	cmp	w11, #0x39
     ba4:      	b.lo	0xc30 <filter_64ty_range+0x220>
     ba8:      	ldp	x11, x12, [x0, #0x40]
     bac:      	cmp	x11, x10
     bb0:      	ccmp	x10, x12, #0x2, ls
     bb4:      	csinc	w9, w9, wzr, hi
     bb8:      	cmp	w8, #0x20
     bbc:      	eor	w8, w9, #0x1
     bc0:      	csel	w0, wzr, w8, ne
     bc4:      	ret
     bc8:      	ldr	w9, [x0, #0x8]
     bcc:      	cmp	w9, #0x19
     bd0:      	b.lo	0xc40 <filter_64ty_range+0x230>
     bd4:      	ldr	x11, [x0, #0x20]
     bd8:      	cmp	x11, x10
     bdc:      	b.hi	0xbec <filter_64ty_range+0x1dc>
     be0:      	ldr	x11, [x0, #0x28]
     be4:      	cmp	x10, x11
     be8:      	b.ls	0xb54 <filter_64ty_range+0x144>
     bec:      	cmp	w9, #0x29
     bf0:      	b.lo	0xc40 <filter_64ty_range+0x230>
     bf4:      	ldr	x11, [x0, #0x30]
     bf8:      	cmp	x11, x10
     bfc:      	b.hi	0xc0c <filter_64ty_range+0x1fc>
     c00:      	ldr	x11, [x0, #0x38]
     c04:      	cmp	x10, x11
     c08:      	b.ls	0xb54 <filter_64ty_range+0x144>
     c0c:      	cmp	w9, #0x39
     c10:      	b.lo	0xc40 <filter_64ty_range+0x230>
     c14:      	ldr	x11, [x0, #0x40]
     c18:      	mov	w9, wzr
     c1c:      	cmp	x11, x10
     c20:      	b.hi	0xc30 <filter_64ty_range+0x220>
     c24:      	ldr	x11, [x0, #0x48]
     c28:      	cmp	x10, x11
     c2c:      	b.ls	0xb54 <filter_64ty_range+0x144>
     c30:      	cmp	w8, #0x20
     c34:      	eor	w8, w9, #0x1
     c38:      	csel	w0, wzr, w8, ne
     c3c:      	ret
     c40:      	mov	w9, wzr
     c44:      	cmp	w8, #0x20
     c48:      	eor	w8, w9, #0x1
     c4c:      	csel	w0, wzr, w8, ne
     c50:      	ret
     c54:      	nop
     c58:      	nop
     c5c:      	nop

0000000000000c60 <filter_32ty_selector_val>:
     c60:      	ldr	w8, [x0, #0x4]
     c64:      	cmp	w8, #0x25
     c68:      	b.hi	0xcdc <filter_32ty_selector_val+0x7c>
     c6c:      	mov	x10, #0x40              // =64
     c70:      	mov	w9, #0x1                // =1
     c74:      	movk	x10, #0xc00, lsl #16
     c78:      	lsl	x9, x9, x8
     c7c:      	movk	x10, #0x20, lsl #32
     c80:      	tst	x9, x10
     c84:      	b.eq	0xc90 <filter_32ty_selector_val+0x30>
     c88:      	mov	w0, #0x1                // =1
     c8c:      	ret
     c90:      	mov	w9, #0x1                // =1
     c94:      	lsl	x9, x9, x8
     c98:      	tst	x9, #0x18
     c9c:      	b.eq	0xcbc <filter_32ty_selector_val+0x5c>
     ca0:      	ldr	w9, [x1]
     ca4:      	ldr	w10, [x0, #0x10]
     ca8:      	cmp	w9, w10
     cac:      	b.ne	0xd5c <filter_32ty_selector_val+0xfc>
     cb0:      	cmp	w8, #0x3
     cb4:      	cset	w0, eq
     cb8:      	ret
     cbc:      	cmp	x8, #0xc
     cc0:      	b.ne	0xcdc <filter_32ty_selector_val+0x7c>
     cc4:      	ldr	w8, [x1]
     cc8:      	ldr	w9, [x0, #0x10]
     ccc:      	tst	w8, w9
     cd0:      	b.eq	0xe08 <filter_32ty_selector_val+0x1a8>
     cd4:      	mov	w0, #0x1                // =1
     cd8:      	ret
     cdc:      	cmp	w8, #0x1
     ce0:      	b.eq	0xd24 <filter_32ty_selector_val+0xc4>
     ce4:      	cmp	w8, #0x2
     ce8:      	b.ne	0xfb0 <filter_32ty_selector_val+0x350>
     cec:      	ldr	w8, [x0, #0xc]
     cf0:      	cmp	w8, #0xc
     cf4:      	b.hi	0xe40 <filter_32ty_selector_val+0x1e0>
     cf8:      	mov	w9, #0x1                // =1
     cfc:      	lsl	w8, w9, w8
     d00:      	mov	w9, #0x1402             // =5122
     d04:      	tst	w8, w9
     d08:      	b.eq	0xe40 <filter_32ty_selector_val+0x1e0>
     d0c:      	ldr	w8, [x1]
     d10:      	ldr	w9, [x0, #0x10]
     d14:      	cmp	w8, w9
     d18:      	b.ge	0xde8 <filter_32ty_selector_val+0x188>
     d1c:      	mov	w0, #0x1                // =1
     d20:      	ret
     d24:      	ldr	w8, [x0, #0xc]
     d28:      	cmp	w8, #0xc
     d2c:      	b.hi	0xe28 <filter_32ty_selector_val+0x1c8>
     d30:      	mov	w9, #0x1                // =1
     d34:      	lsl	w8, w9, w8
     d38:      	mov	w9, #0x1402             // =5122
     d3c:      	tst	w8, w9
     d40:      	b.eq	0xe28 <filter_32ty_selector_val+0x1c8>
     d44:      	ldr	w8, [x1]
     d48:      	ldr	w9, [x0, #0x10]
     d4c:      	cmp	w8, w9
     d50:      	b.le	0xdc8 <filter_32ty_selector_val+0x168>
     d54:      	mov	w0, #0x1                // =1
     d58:      	ret
     d5c:      	ldr	w10, [x0, #0x8]
     d60:      	cmp	w10, #0xd
     d64:      	b.lo	0xd9c <filter_32ty_selector_val+0x13c>
     d68:      	ldr	w11, [x0, #0x14]
     d6c:      	cmp	w9, w11
     d70:      	b.eq	0xcb0 <filter_32ty_selector_val+0x50>
     d74:      	cmp	w10, #0x11
     d78:      	b.lo	0xd9c <filter_32ty_selector_val+0x13c>
     d7c:      	ldr	w11, [x0, #0x18]
     d80:      	cmp	w9, w11
     d84:      	b.eq	0xcb0 <filter_32ty_selector_val+0x50>
     d88:      	cmp	w10, #0x15
     d8c:      	b.lo	0xd9c <filter_32ty_selector_val+0x13c>
     d90:      	ldr	w10, [x0, #0x1c]
     d94:      	cmp	w9, w10
     d98:      	b.eq	0xcb0 <filter_32ty_selector_val+0x50>
     d9c:      	cmp	w8, #0x25
     da0:      	b.hi	0xfb0 <filter_32ty_selector_val+0x350>
     da4:      	mov	w9, #0x1                // =1
     da8:      	lsl	x8, x9, x8
     dac:      	mov	x9, #0x50               // =80
     db0:      	movk	x9, #0xc00, lsl #16
     db4:      	movk	x9, #0x20, lsl #32
     db8:      	tst	x8, x9
     dbc:      	b.eq	0xfb0 <filter_32ty_selector_val+0x350>
     dc0:      	mov	w0, #0x1                // =1
     dc4:      	ret
     dc8:      	ldr	w9, [x0, #0x8]
     dcc:      	cmp	w9, #0xd
     dd0:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     dd4:      	ldr	w10, [x0, #0x14]
     dd8:      	cmp	w8, w10
     ddc:      	b.le	0xe98 <filter_32ty_selector_val+0x238>
     de0:      	mov	w0, #0x1                // =1
     de4:      	ret
     de8:      	ldr	w9, [x0, #0x8]
     dec:      	cmp	w9, #0xd
     df0:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     df4:      	ldr	w10, [x0, #0x14]
     df8:      	cmp	w8, w10
     dfc:      	b.ge	0xeb4 <filter_32ty_selector_val+0x254>
     e00:      	mov	w0, #0x1                // =1
     e04:      	ret
     e08:      	ldr	w9, [x0, #0x8]
     e0c:      	cmp	w9, #0xd
     e10:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     e14:      	ldr	w10, [x0, #0x14]
     e18:      	tst	w8, w10
     e1c:      	b.eq	0xed0 <filter_32ty_selector_val+0x270>
     e20:      	mov	w0, #0x1                // =1
     e24:      	ret
     e28:      	ldr	w8, [x1]
     e2c:      	ldr	w9, [x0, #0x10]
     e30:      	cmp	w8, w9
     e34:      	b.ls	0xe58 <filter_32ty_selector_val+0x1f8>
     e38:      	mov	w0, #0x1                // =1
     e3c:      	ret
     e40:      	ldr	w8, [x1]
     e44:      	ldr	w9, [x0, #0x10]
     e48:      	cmp	w8, w9
     e4c:      	b.hs	0xe78 <filter_32ty_selector_val+0x218>
     e50:      	mov	w0, #0x1                // =1
     e54:      	ret
     e58:      	ldr	w9, [x0, #0x8]
     e5c:      	cmp	w9, #0xd
     e60:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     e64:      	ldr	w10, [x0, #0x14]
     e68:      	cmp	w8, w10
     e6c:      	b.ls	0xeec <filter_32ty_selector_val+0x28c>
     e70:      	mov	w0, #0x1                // =1
     e74:      	ret
     e78:      	ldr	w9, [x0, #0x8]
     e7c:      	cmp	w9, #0xd
     e80:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     e84:      	ldr	w10, [x0, #0x14]
     e88:      	cmp	w8, w10
     e8c:      	b.hs	0xf08 <filter_32ty_selector_val+0x2a8>
     e90:      	mov	w0, #0x1                // =1
     e94:      	ret
     e98:      	cmp	w9, #0x11
     e9c:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     ea0:      	ldr	w10, [x0, #0x18]
     ea4:      	cmp	w8, w10
     ea8:      	b.le	0xf24 <filter_32ty_selector_val+0x2c4>
     eac:      	mov	w0, #0x1                // =1
     eb0:      	ret
     eb4:      	cmp	w9, #0x11
     eb8:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     ebc:      	ldr	w10, [x0, #0x18]
     ec0:      	cmp	w8, w10
     ec4:      	b.ge	0xf40 <filter_32ty_selector_val+0x2e0>
     ec8:      	mov	w0, #0x1                // =1
     ecc:      	ret
     ed0:      	cmp	w9, #0x11
     ed4:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     ed8:      	ldr	w10, [x0, #0x18]
     edc:      	tst	w8, w10
     ee0:      	b.eq	0xf5c <filter_32ty_selector_val+0x2fc>
     ee4:      	mov	w0, #0x1                // =1
     ee8:      	ret
     eec:      	cmp	w9, #0x11
     ef0:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     ef4:      	ldr	w10, [x0, #0x18]
     ef8:      	cmp	w8, w10
     efc:      	b.ls	0xf78 <filter_32ty_selector_val+0x318>
     f00:      	mov	w0, #0x1                // =1
     f04:      	ret
     f08:      	cmp	w9, #0x11
     f0c:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     f10:      	ldr	w10, [x0, #0x18]
     f14:      	cmp	w8, w10
     f18:      	b.hs	0xf94 <filter_32ty_selector_val+0x334>
     f1c:      	mov	w0, #0x1                // =1
     f20:      	ret
     f24:      	cmp	w9, #0x15
     f28:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     f2c:      	ldr	w9, [x0, #0x1c]
     f30:      	cmp	w8, w9
     f34:      	b.le	0xfb0 <filter_32ty_selector_val+0x350>
     f38:      	mov	w0, #0x1                // =1
     f3c:      	ret
     f40:      	cmp	w9, #0x15
     f44:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     f48:      	ldr	w9, [x0, #0x1c]
     f4c:      	cmp	w8, w9
     f50:      	b.ge	0xfb0 <filter_32ty_selector_val+0x350>
     f54:      	mov	w0, #0x1                // =1
     f58:      	ret
     f5c:      	cmp	w9, #0x15
     f60:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     f64:      	ldr	w9, [x0, #0x1c]
     f68:      	tst	w8, w9
     f6c:      	b.eq	0xfb0 <filter_32ty_selector_val+0x350>
     f70:      	mov	w0, #0x1                // =1
     f74:      	ret
     f78:      	cmp	w9, #0x15
     f7c:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     f80:      	ldr	w9, [x0, #0x1c]
     f84:      	cmp	w8, w9
     f88:      	b.ls	0xfb0 <filter_32ty_selector_val+0x350>
     f8c:      	mov	w0, #0x1                // =1
     f90:      	ret
     f94:      	cmp	w9, #0x15
     f98:      	b.lo	0xfb0 <filter_32ty_selector_val+0x350>
     f9c:      	ldr	w9, [x0, #0x1c]
     fa0:      	cmp	w8, w9
     fa4:      	b.hs	0xfb0 <filter_32ty_selector_val+0x350>
     fa8:      	mov	w0, #0x1                // =1
     fac:      	ret
     fb0:      	mov	x0, xzr
     fb4:      	ret
     fb8:      	nop
     fbc:      	nop

0000000000000fc0 <filter_32ty_map>:
     fc0:      	sub	sp, sp, #0x30
     fc4:      	str	x30, [sp, #0x10]
     fc8:      	stp	x20, x19, [sp, #0x20]
     fcc:      	ldrb	w8, [x0, #0x10]
     fd0:      	mov	x19, x0
     fd4:      	adrp	x0, 0x0 <extract_arg_depth>
     fd8:      	add	x9, sp, #0x1c
     fdc:      	str	w8, [sp, #0x1c]
     fe0:      	mov	w8, #0x1                // =1
     fe4:      	mov	x20, x1
     fe8:      	add	x1, sp, #0x1c
     fec:      	ldr	x0, [x0]
     ff0:      	blr	x8
     ff4:      	cbz	x0, 0x1068 <filter_32ty_map+0xa8>
     ff8:      	ldr	w8, [x20]
     ffc:      	mov	w9, #0x1                // =1
    1000:      	add	x1, sp, #0x8
    1004:      	mov	w20, #0x1               // =1
    1008:      	str	x8, [sp, #0x8]
    100c:      	add	x8, sp, #0x8
    1010:      	blr	x9
    1014:      	ldr	w9, [x19, #0x4]
    1018:      	mov	w8, wzr
    101c:      	cmp	w9, #0x1d
    1020:      	b.hi	0x1064 <filter_32ty_map+0xa4>
    1024:      	mov	w11, #0x8400            // =33792
    1028:      	lsl	w10, w20, w9
    102c:      	movk	w11, #0x3003, lsl #16
    1030:      	tst	w10, w11
    1034:      	b.eq	0x1044 <filter_32ty_map+0x84>
    1038:      	cmp	x0, #0x0
    103c:      	cset	w8, ne
    1040:      	b	0x1064 <filter_32ty_map+0xa4>
    1044:      	mov	w10, #0x1               // =1
    1048:      	lsl	w9, w10, w9
    104c:      	mov	w10, #0x800             // =2048
    1050:      	movk	w10, #0xc, lsl #16
    1054:      	tst	w9, w10
    1058:      	b.eq	0x1064 <filter_32ty_map+0xa4>
    105c:      	cmp	x0, #0x0
    1060:      	cset	w8, eq
    1064:      	mov	w0, w8
    1068:      	ldp	x20, x19, [sp, #0x20]
    106c:      	ldr	x30, [sp, #0x10]
    1070:      	add	sp, sp, #0x30
    1074:      	ret
    1078:      	nop
    107c:      	nop

0000000000001080 <filter_32ty_range>:
    1080:      	ldr	w9, [x0, #0xc]
    1084:      	ldr	w8, [x0, #0x4]
    1088:      	mov	w10, #0x1               // =1
    108c:      	cmp	w9, #0xc
    1090:      	lsl	w9, w10, w9
    1094:      	mov	w10, #0x1402            // =5122
    1098:      	and	w9, w9, w10
    109c:      	ccmp	w9, #0x0, #0x4, ls
    10a0:      	b.eq	0x11a0 <filter_32ty_range+0x120>
    10a4:      	ldr	w10, [x1]
    10a8:      	cmp	w8, #0x1f
    10ac:      	b.ne	0x1134 <filter_32ty_range+0xb4>
    10b0:      	ldr	w9, [x0, #0x10]
    10b4:      	cmp	w9, w10
    10b8:      	b.gt	0x10c8 <filter_32ty_range+0x48>
    10bc:      	ldr	w9, [x0, #0x14]
    10c0:      	cmp	w10, w9
    10c4:      	b.le	0x11c4 <filter_32ty_range+0x144>
    10c8:      	ldr	w9, [x0, #0x8]
    10cc:      	cmp	w9, #0x11
    10d0:      	b.lo	0x12b0 <filter_32ty_range+0x230>
    10d4:      	ldr	w11, [x0, #0x18]
    10d8:      	cmp	w11, w10
    10dc:      	b.gt	0x10ec <filter_32ty_range+0x6c>
    10e0:      	ldr	w11, [x0, #0x1c]
    10e4:      	cmp	w10, w11
    10e8:      	b.le	0x11c4 <filter_32ty_range+0x144>
    10ec:      	cmp	w9, #0x19
    10f0:      	b.lo	0x12b0 <filter_32ty_range+0x230>
    10f4:      	ldr	w11, [x0, #0x20]
    10f8:      	cmp	w11, w10
    10fc:      	b.gt	0x110c <filter_32ty_range+0x8c>
    1100:      	ldr	w11, [x0, #0x24]
    1104:      	cmp	w10, w11
    1108:      	b.le	0x11c4 <filter_32ty_range+0x144>
    110c:      	cmp	w9, #0x21
    1110:      	b.lo	0x12b0 <filter_32ty_range+0x230>
    1114:      	ldr	w11, [x0, #0x28]
    1118:      	mov	w9, wzr
    111c:      	cmp	w11, w10
    1120:      	b.gt	0x12a0 <filter_32ty_range+0x220>
    1124:      	ldr	w11, [x0, #0x2c]
    1128:      	cmp	w10, w11
    112c:      	b.le	0x11c4 <filter_32ty_range+0x144>
    1130:      	b	0x12a0 <filter_32ty_range+0x220>
    1134:      	ldp	w9, w12, [x0, #0x10]
    1138:      	ldr	w11, [x0, #0x8]
    113c:      	cmp	w9, w10
    1140:      	ccmp	w10, w12, #0x0, le
    1144:      	cset	w9, le
    1148:      	cmp	w11, #0x11
    114c:      	b.lo	0x12a0 <filter_32ty_range+0x220>
    1150:      	ldp	w12, w13, [x0, #0x18]
    1154:      	cmp	w12, w10
    1158:      	ccmp	w10, w13, #0x0, le
    115c:      	csinc	w9, w9, wzr, gt
    1160:      	cmp	w11, #0x19
    1164:      	b.lo	0x12a0 <filter_32ty_range+0x220>
    1168:      	ldp	w12, w13, [x0, #0x20]
    116c:      	cmp	w12, w10
    1170:      	ccmp	w10, w13, #0x0, le
    1174:      	csinc	w9, w9, wzr, gt
    1178:      	cmp	w11, #0x21
    117c:      	b.lo	0x12a0 <filter_32ty_range+0x220>
    1180:      	ldp	w11, w12, [x0, #0x28]
    1184:      	cmp	w11, w10
    1188:      	ccmp	w10, w12, #0x0, le
    118c:      	csinc	w9, w9, wzr, gt
    1190:      	cmp	w8, #0x20
    1194:      	eor	w8, w9, #0x1
    1198:      	csel	w0, wzr, w8, ne
    119c:      	ret
    11a0:      	ldr	w10, [x1]
    11a4:      	cmp	w8, #0x1f
    11a8:      	b.ne	0x11cc <filter_32ty_range+0x14c>
    11ac:      	ldr	w9, [x0, #0x10]
    11b0:      	cmp	w9, w10
    11b4:      	b.hi	0x1238 <filter_32ty_range+0x1b8>
    11b8:      	ldr	w9, [x0, #0x14]
    11bc:      	cmp	w10, w9
    11c0:      	b.hi	0x1238 <filter_32ty_range+0x1b8>
    11c4:      	mov	w0, #0x1                // =1
    11c8:      	ret
    11cc:      	ldp	w9, w12, [x0, #0x10]
    11d0:      	ldr	w11, [x0, #0x8]
    11d4:      	cmp	w9, w10
    11d8:      	ccmp	w10, w12, #0x2, ls
    11dc:      	cset	w9, ls
    11e0:      	cmp	w11, #0x11
    11e4:      	b.lo	0x12a0 <filter_32ty_range+0x220>
    11e8:      	ldp	w12, w13, [x0, #0x18]
    11ec:      	cmp	w12, w10
    11f0:      	ccmp	w10, w13, #0x2, ls
    11f4:      	csinc	w9, w9, wzr, hi
    11f8:      	cmp	w11, #0x19
    11fc:      	b.lo	0x12a0 <filter_32ty_range+0x220>
    1200:      	ldp	w12, w13, [x0, #0x20]
    1204:      	cmp	w12, w10
    1208:      	ccmp	w10, w13, #0x2, ls
    120c:      	csinc	w9, w9, wzr, hi
    1210:      	cmp	w11, #0x21
    1214:      	b.lo	0x12a0 <filter_32ty_range+0x220>
    1218:      	ldp	w11, w12, [x0, #0x28]
    121c:      	cmp	w11, w10
    1220:      	ccmp	w10, w12, #0x2, ls
    1224:      	csinc	w9, w9, wzr, hi
    1228:      	cmp	w8, #0x20
    122c:      	eor	w8, w9, #0x1
    1230:      	csel	w0, wzr, w8, ne
    1234:      	ret
    1238:      	ldr	w9, [x0, #0x8]
    123c:      	cmp	w9, #0x11
    1240:      	b.lo	0x12b0 <filter_32ty_range+0x230>
    1244:      	ldr	w11, [x0, #0x18]
    1248:      	cmp	w11, w10
    124c:      	b.hi	0x125c <filter_32ty_range+0x1dc>
    1250:      	ldr	w11, [x0, #0x1c]
    1254:      	cmp	w10, w11
    1258:      	b.ls	0x11c4 <filter_32ty_range+0x144>
    125c:      	cmp	w9, #0x19
    1260:      	b.lo	0x12b0 <filter_32ty_range+0x230>
    1264:      	ldr	w11, [x0, #0x20]
    1268:      	cmp	w11, w10
    126c:      	b.hi	0x127c <filter_32ty_range+0x1fc>
    1270:      	ldr	w11, [x0, #0x24]
    1274:      	cmp	w10, w11
    1278:      	b.ls	0x11c4 <filter_32ty_range+0x144>
    127c:      	cmp	w9, #0x21
    1280:      	b.lo	0x12b0 <filter_32ty_range+0x230>
    1284:      	ldr	w11, [x0, #0x28]
    1288:      	mov	w9, wzr
    128c:      	cmp	w11, w10
    1290:      	b.hi	0x12a0 <filter_32ty_range+0x220>
    1294:      	ldr	w11, [x0, #0x2c]
    1298:      	cmp	w10, w11
    129c:      	b.ls	0x11c4 <filter_32ty_range+0x144>
    12a0:      	cmp	w8, #0x20
    12a4:      	eor	w8, w9, #0x1
    12a8:      	csel	w0, wzr, w8, ne
    12ac:      	ret
    12b0:      	mov	w9, wzr
    12b4:      	cmp	w8, #0x20
    12b8:      	eor	w8, w9, #0x1
    12bc:      	csel	w0, wzr, w8, ne
    12c0:      	ret
    12c4:      	nop
    12c8:      	nop
    12cc:      	nop

00000000000012d0 <filter_16ty_selector_val>:
    12d0:      	ldr	w8, [x0, #0x4]
    12d4:      	cmp	w8, #0x25
    12d8:      	b.hi	0x134c <filter_16ty_selector_val+0x7c>
    12dc:      	mov	x10, #0x40              // =64
    12e0:      	mov	w9, #0x1                // =1
    12e4:      	movk	x10, #0xc00, lsl #16
    12e8:      	lsl	x9, x9, x8
    12ec:      	movk	x10, #0x20, lsl #32
    12f0:      	tst	x9, x10
    12f4:      	b.eq	0x1300 <filter_16ty_selector_val+0x30>
    12f8:      	mov	w0, #0x1                // =1
    12fc:      	ret
    1300:      	mov	w9, #0x1                // =1
    1304:      	lsl	x9, x9, x8
    1308:      	tst	x9, #0x18
    130c:      	b.eq	0x132c <filter_16ty_selector_val+0x5c>
    1310:      	ldrh	w9, [x1]
    1314:      	ldr	w10, [x0, #0x10]
    1318:      	cmp	w10, w9
    131c:      	b.ne	0x13cc <filter_16ty_selector_val+0xfc>
    1320:      	cmp	w8, #0x3
    1324:      	cset	w0, eq
    1328:      	ret
    132c:      	cmp	x8, #0xc
    1330:      	b.ne	0x134c <filter_16ty_selector_val+0x7c>
    1334:      	ldrh	w8, [x1]
    1338:      	ldr	w9, [x0, #0x10]
    133c:      	tst	w9, w8
    1340:      	b.eq	0x1478 <filter_16ty_selector_val+0x1a8>
    1344:      	mov	w0, #0x1                // =1
    1348:      	ret
    134c:      	cmp	w8, #0x1
    1350:      	b.eq	0x1394 <filter_16ty_selector_val+0xc4>
    1354:      	cmp	w8, #0x2
    1358:      	b.ne	0x1620 <filter_16ty_selector_val+0x350>
    135c:      	ldr	w8, [x0, #0xc]
    1360:      	cmp	w8, #0xc
    1364:      	b.hi	0x14b0 <filter_16ty_selector_val+0x1e0>
    1368:      	mov	w9, #0x1                // =1
    136c:      	lsl	w8, w9, w8
    1370:      	mov	w9, #0x1402             // =5122
    1374:      	tst	w8, w9
    1378:      	b.eq	0x14b0 <filter_16ty_selector_val+0x1e0>
    137c:      	ldrsh	w8, [x1]
    1380:      	ldr	w9, [x0, #0x10]
    1384:      	cmp	w9, w8
    1388:      	b.le	0x1458 <filter_16ty_selector_val+0x188>
    138c:      	mov	w0, #0x1                // =1
    1390:      	ret
    1394:      	ldr	w8, [x0, #0xc]
    1398:      	cmp	w8, #0xc
    139c:      	b.hi	0x1498 <filter_16ty_selector_val+0x1c8>
    13a0:      	mov	w9, #0x1                // =1
    13a4:      	lsl	w8, w9, w8
    13a8:      	mov	w9, #0x1402             // =5122
    13ac:      	tst	w8, w9
    13b0:      	b.eq	0x1498 <filter_16ty_selector_val+0x1c8>
    13b4:      	ldrsh	w8, [x1]
    13b8:      	ldr	w9, [x0, #0x10]
    13bc:      	cmp	w9, w8
    13c0:      	b.ge	0x1438 <filter_16ty_selector_val+0x168>
    13c4:      	mov	w0, #0x1                // =1
    13c8:      	ret
    13cc:      	ldr	w10, [x0, #0x8]
    13d0:      	cmp	w10, #0xd
    13d4:      	b.lo	0x140c <filter_16ty_selector_val+0x13c>
    13d8:      	ldr	w11, [x0, #0x14]
    13dc:      	cmp	w11, w9
    13e0:      	b.eq	0x1320 <filter_16ty_selector_val+0x50>
    13e4:      	cmp	w10, #0x11
    13e8:      	b.lo	0x140c <filter_16ty_selector_val+0x13c>
    13ec:      	ldr	w11, [x0, #0x18]
    13f0:      	cmp	w11, w9
    13f4:      	b.eq	0x1320 <filter_16ty_selector_val+0x50>
    13f8:      	cmp	w10, #0x15
    13fc:      	b.lo	0x140c <filter_16ty_selector_val+0x13c>
    1400:      	ldr	w10, [x0, #0x1c]
    1404:      	cmp	w10, w9
    1408:      	b.eq	0x1320 <filter_16ty_selector_val+0x50>
    140c:      	cmp	w8, #0x25
    1410:      	b.hi	0x1620 <filter_16ty_selector_val+0x350>
    1414:      	mov	w9, #0x1                // =1
    1418:      	lsl	x8, x9, x8
    141c:      	mov	x9, #0x50               // =80
    1420:      	movk	x9, #0xc00, lsl #16
    1424:      	movk	x9, #0x20, lsl #32
    1428:      	tst	x8, x9
    142c:      	b.eq	0x1620 <filter_16ty_selector_val+0x350>
    1430:      	mov	w0, #0x1                // =1
    1434:      	ret
    1438:      	ldr	w9, [x0, #0x8]
    143c:      	cmp	w9, #0xd
    1440:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1444:      	ldr	w10, [x0, #0x14]
    1448:      	cmp	w10, w8
    144c:      	b.ge	0x1508 <filter_16ty_selector_val+0x238>
    1450:      	mov	w0, #0x1                // =1
    1454:      	ret
    1458:      	ldr	w9, [x0, #0x8]
    145c:      	cmp	w9, #0xd
    1460:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1464:      	ldr	w10, [x0, #0x14]
    1468:      	cmp	w10, w8
    146c:      	b.le	0x1524 <filter_16ty_selector_val+0x254>
    1470:      	mov	w0, #0x1                // =1
    1474:      	ret
    1478:      	ldr	w9, [x0, #0x8]
    147c:      	cmp	w9, #0xd
    1480:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1484:      	ldr	w10, [x0, #0x14]
    1488:      	tst	w10, w8
    148c:      	b.eq	0x1540 <filter_16ty_selector_val+0x270>
    1490:      	mov	w0, #0x1                // =1
    1494:      	ret
    1498:      	ldrh	w8, [x1]
    149c:      	ldr	w9, [x0, #0x10]
    14a0:      	cmp	w9, w8
    14a4:      	b.hs	0x14c8 <filter_16ty_selector_val+0x1f8>
    14a8:      	mov	w0, #0x1                // =1
    14ac:      	ret
    14b0:      	ldrh	w8, [x1]
    14b4:      	ldr	w9, [x0, #0x10]
    14b8:      	cmp	w9, w8
    14bc:      	b.ls	0x14e8 <filter_16ty_selector_val+0x218>
    14c0:      	mov	w0, #0x1                // =1
    14c4:      	ret
    14c8:      	ldr	w9, [x0, #0x8]
    14cc:      	cmp	w9, #0xd
    14d0:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    14d4:      	ldr	w10, [x0, #0x14]
    14d8:      	cmp	w10, w8
    14dc:      	b.hs	0x155c <filter_16ty_selector_val+0x28c>
    14e0:      	mov	w0, #0x1                // =1
    14e4:      	ret
    14e8:      	ldr	w9, [x0, #0x8]
    14ec:      	cmp	w9, #0xd
    14f0:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    14f4:      	ldr	w10, [x0, #0x14]
    14f8:      	cmp	w10, w8
    14fc:      	b.ls	0x1578 <filter_16ty_selector_val+0x2a8>
    1500:      	mov	w0, #0x1                // =1
    1504:      	ret
    1508:      	cmp	w9, #0x11
    150c:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1510:      	ldr	w10, [x0, #0x18]
    1514:      	cmp	w10, w8
    1518:      	b.ge	0x1594 <filter_16ty_selector_val+0x2c4>
    151c:      	mov	w0, #0x1                // =1
    1520:      	ret
    1524:      	cmp	w9, #0x11
    1528:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    152c:      	ldr	w10, [x0, #0x18]
    1530:      	cmp	w10, w8
    1534:      	b.le	0x15b0 <filter_16ty_selector_val+0x2e0>
    1538:      	mov	w0, #0x1                // =1
    153c:      	ret
    1540:      	cmp	w9, #0x11
    1544:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1548:      	ldr	w10, [x0, #0x18]
    154c:      	tst	w10, w8
    1550:      	b.eq	0x15cc <filter_16ty_selector_val+0x2fc>
    1554:      	mov	w0, #0x1                // =1
    1558:      	ret
    155c:      	cmp	w9, #0x11
    1560:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1564:      	ldr	w10, [x0, #0x18]
    1568:      	cmp	w10, w8
    156c:      	b.hs	0x15e8 <filter_16ty_selector_val+0x318>
    1570:      	mov	w0, #0x1                // =1
    1574:      	ret
    1578:      	cmp	w9, #0x11
    157c:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    1580:      	ldr	w10, [x0, #0x18]
    1584:      	cmp	w10, w8
    1588:      	b.ls	0x1604 <filter_16ty_selector_val+0x334>
    158c:      	mov	w0, #0x1                // =1
    1590:      	ret
    1594:      	cmp	w9, #0x15
    1598:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    159c:      	ldr	w9, [x0, #0x1c]
    15a0:      	cmp	w9, w8
    15a4:      	b.ge	0x1620 <filter_16ty_selector_val+0x350>
    15a8:      	mov	w0, #0x1                // =1
    15ac:      	ret
    15b0:      	cmp	w9, #0x15
    15b4:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    15b8:      	ldr	w9, [x0, #0x1c]
    15bc:      	cmp	w9, w8
    15c0:      	b.le	0x1620 <filter_16ty_selector_val+0x350>
    15c4:      	mov	w0, #0x1                // =1
    15c8:      	ret
    15cc:      	cmp	w9, #0x15
    15d0:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    15d4:      	ldr	w9, [x0, #0x1c]
    15d8:      	tst	w9, w8
    15dc:      	b.eq	0x1620 <filter_16ty_selector_val+0x350>
    15e0:      	mov	w0, #0x1                // =1
    15e4:      	ret
    15e8:      	cmp	w9, #0x15
    15ec:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    15f0:      	ldr	w9, [x0, #0x1c]
    15f4:      	cmp	w9, w8
    15f8:      	b.hs	0x1620 <filter_16ty_selector_val+0x350>
    15fc:      	mov	w0, #0x1                // =1
    1600:      	ret
    1604:      	cmp	w9, #0x15
    1608:      	b.lo	0x1620 <filter_16ty_selector_val+0x350>
    160c:      	ldr	w9, [x0, #0x1c]
    1610:      	cmp	w9, w8
    1614:      	b.ls	0x1620 <filter_16ty_selector_val+0x350>
    1618:      	mov	w0, #0x1                // =1
    161c:      	ret
    1620:      	mov	x0, xzr
    1624:      	ret
    1628:      	nop
    162c:      	nop

0000000000001630 <filter_16ty_map>:
    1630:      	sub	sp, sp, #0x30
    1634:      	str	x30, [sp, #0x10]
    1638:      	stp	x20, x19, [sp, #0x20]
    163c:      	ldrb	w8, [x0, #0x10]
    1640:      	mov	x19, x0
    1644:      	adrp	x0, 0x1000 <filter_32ty_map+0x40>
    1648:      	add	x9, sp, #0x1c
    164c:      	str	w8, [sp, #0x1c]
    1650:      	mov	w8, #0x1                // =1
    1654:      	mov	x20, x1
    1658:      	add	x1, sp, #0x1c
    165c:      	ldr	x0, [x0]
    1660:      	blr	x8
    1664:      	cbz	x0, 0x16d8 <filter_16ty_map+0xa8>
    1668:      	ldrh	w8, [x20]
    166c:      	mov	w9, #0x1                // =1
    1670:      	add	x1, sp, #0x8
    1674:      	mov	w20, #0x1               // =1
    1678:      	str	x8, [sp, #0x8]
    167c:      	add	x8, sp, #0x8
    1680:      	blr	x9
    1684:      	ldr	w9, [x19, #0x4]
    1688:      	mov	w8, wzr
    168c:      	cmp	w9, #0x1d
    1690:      	b.hi	0x16d4 <filter_16ty_map+0xa4>
    1694:      	mov	w11, #0x8400            // =33792
    1698:      	lsl	w10, w20, w9
    169c:      	movk	w11, #0x3003, lsl #16
    16a0:      	tst	w10, w11
    16a4:      	b.eq	0x16b4 <filter_16ty_map+0x84>
    16a8:      	cmp	x0, #0x0
    16ac:      	cset	w8, ne
    16b0:      	b	0x16d4 <filter_16ty_map+0xa4>
    16b4:      	mov	w10, #0x1               // =1
    16b8:      	lsl	w9, w10, w9
    16bc:      	mov	w10, #0x800             // =2048
    16c0:      	movk	w10, #0xc, lsl #16
    16c4:      	tst	w9, w10
    16c8:      	b.eq	0x16d4 <filter_16ty_map+0xa4>
    16cc:      	cmp	x0, #0x0
    16d0:      	cset	w8, eq
    16d4:      	mov	w0, w8
    16d8:      	ldp	x20, x19, [sp, #0x20]
    16dc:      	ldr	x30, [sp, #0x10]
    16e0:      	add	sp, sp, #0x30
    16e4:      	ret
    16e8:      	nop
    16ec:      	nop

00000000000016f0 <filter_16ty_range>:
    16f0:      	ldr	w9, [x0, #0xc]
    16f4:      	ldr	w8, [x0, #0x4]
    16f8:      	mov	w10, #0x1               // =1
    16fc:      	cmp	w9, #0xc
    1700:      	lsl	w9, w10, w9
    1704:      	mov	w10, #0x1402            // =5122
    1708:      	and	w9, w9, w10
    170c:      	ccmp	w9, #0x0, #0x4, ls
    1710:      	b.eq	0x1810 <filter_16ty_range+0x120>
    1714:      	ldrsh	w10, [x1]
    1718:      	cmp	w8, #0x1f
    171c:      	b.ne	0x17a4 <filter_16ty_range+0xb4>
    1720:      	ldr	w9, [x0, #0x10]
    1724:      	cmp	w9, w10
    1728:      	b.gt	0x1738 <filter_16ty_range+0x48>
    172c:      	ldr	w9, [x0, #0x14]
    1730:      	cmp	w9, w10
    1734:      	b.ge	0x1834 <filter_16ty_range+0x144>
    1738:      	ldr	w9, [x0, #0x8]
    173c:      	cmp	w9, #0x11
    1740:      	b.lo	0x1920 <filter_16ty_range+0x230>
    1744:      	ldr	w11, [x0, #0x18]
    1748:      	cmp	w11, w10
    174c:      	b.gt	0x175c <filter_16ty_range+0x6c>
    1750:      	ldr	w11, [x0, #0x1c]
    1754:      	cmp	w11, w10
    1758:      	b.ge	0x1834 <filter_16ty_range+0x144>
    175c:      	cmp	w9, #0x19
    1760:      	b.lo	0x1920 <filter_16ty_range+0x230>
    1764:      	ldr	w11, [x0, #0x20]
    1768:      	cmp	w11, w10
    176c:      	b.gt	0x177c <filter_16ty_range+0x8c>
    1770:      	ldr	w11, [x0, #0x24]
    1774:      	cmp	w11, w10
    1778:      	b.ge	0x1834 <filter_16ty_range+0x144>
    177c:      	cmp	w9, #0x21
    1780:      	b.lo	0x1920 <filter_16ty_range+0x230>
    1784:      	ldr	w11, [x0, #0x28]
    1788:      	mov	w9, wzr
    178c:      	cmp	w11, w10
    1790:      	b.gt	0x1910 <filter_16ty_range+0x220>
    1794:      	ldr	w11, [x0, #0x2c]
    1798:      	cmp	w11, w10
    179c:      	b.ge	0x1834 <filter_16ty_range+0x144>
    17a0:      	b	0x1910 <filter_16ty_range+0x220>
    17a4:      	ldp	w9, w12, [x0, #0x10]
    17a8:      	ldr	w11, [x0, #0x8]
    17ac:      	cmp	w9, w10
    17b0:      	ccmp	w12, w10, #0x8, le
    17b4:      	cset	w9, ge
    17b8:      	cmp	w11, #0x11
    17bc:      	b.lo	0x1910 <filter_16ty_range+0x220>
    17c0:      	ldp	w12, w13, [x0, #0x18]
    17c4:      	cmp	w12, w10
    17c8:      	ccmp	w13, w10, #0x8, le
    17cc:      	csinc	w9, w9, wzr, lt
    17d0:      	cmp	w11, #0x19
    17d4:      	b.lo	0x1910 <filter_16ty_range+0x220>
    17d8:      	ldp	w12, w13, [x0, #0x20]
    17dc:      	cmp	w12, w10
    17e0:      	ccmp	w13, w10, #0x8, le
    17e4:      	csinc	w9, w9, wzr, lt
    17e8:      	cmp	w11, #0x21
    17ec:      	b.lo	0x1910 <filter_16ty_range+0x220>
    17f0:      	ldp	w11, w12, [x0, #0x28]
    17f4:      	cmp	w11, w10
    17f8:      	ccmp	w12, w10, #0x8, le
    17fc:      	csinc	w9, w9, wzr, lt
    1800:      	cmp	w8, #0x20
    1804:      	eor	w8, w9, #0x1
    1808:      	csel	w0, wzr, w8, ne
    180c:      	ret
    1810:      	ldrh	w10, [x1]
    1814:      	cmp	w8, #0x1f
    1818:      	b.ne	0x183c <filter_16ty_range+0x14c>
    181c:      	ldr	w9, [x0, #0x10]
    1820:      	cmp	w9, w10
    1824:      	b.hi	0x18a8 <filter_16ty_range+0x1b8>
    1828:      	ldr	w9, [x0, #0x14]
    182c:      	cmp	w9, w10
    1830:      	b.lo	0x18a8 <filter_16ty_range+0x1b8>
    1834:      	mov	w0, #0x1                // =1
    1838:      	ret
    183c:      	ldp	w9, w12, [x0, #0x10]
    1840:      	ldr	w11, [x0, #0x8]
    1844:      	cmp	w9, w10
    1848:      	ccmp	w12, w10, #0x0, ls
    184c:      	cset	w9, hs
    1850:      	cmp	w11, #0x11
    1854:      	b.lo	0x1910 <filter_16ty_range+0x220>
    1858:      	ldp	w12, w13, [x0, #0x18]
    185c:      	cmp	w12, w10
    1860:      	ccmp	w13, w10, #0x0, ls
    1864:      	csinc	w9, w9, wzr, lo
    1868:      	cmp	w11, #0x19
    186c:      	b.lo	0x1910 <filter_16ty_range+0x220>
    1870:      	ldp	w12, w13, [x0, #0x20]
    1874:      	cmp	w12, w10
    1878:      	ccmp	w13, w10, #0x0, ls
    187c:      	csinc	w9, w9, wzr, lo
    1880:      	cmp	w11, #0x21
    1884:      	b.lo	0x1910 <filter_16ty_range+0x220>
    1888:      	ldp	w11, w12, [x0, #0x28]
    188c:      	cmp	w11, w10
    1890:      	ccmp	w12, w10, #0x0, ls
    1894:      	csinc	w9, w9, wzr, lo
    1898:      	cmp	w8, #0x20
    189c:      	eor	w8, w9, #0x1
    18a0:      	csel	w0, wzr, w8, ne
    18a4:      	ret
    18a8:      	ldr	w9, [x0, #0x8]
    18ac:      	cmp	w9, #0x11
    18b0:      	b.lo	0x1920 <filter_16ty_range+0x230>
    18b4:      	ldr	w11, [x0, #0x18]
    18b8:      	cmp	w11, w10
    18bc:      	b.hi	0x18cc <filter_16ty_range+0x1dc>
    18c0:      	ldr	w11, [x0, #0x1c]
    18c4:      	cmp	w11, w10
    18c8:      	b.hs	0x1834 <filter_16ty_range+0x144>
    18cc:      	cmp	w9, #0x19
    18d0:      	b.lo	0x1920 <filter_16ty_range+0x230>
    18d4:      	ldr	w11, [x0, #0x20]
    18d8:      	cmp	w11, w10
    18dc:      	b.hi	0x18ec <filter_16ty_range+0x1fc>
    18e0:      	ldr	w11, [x0, #0x24]
    18e4:      	cmp	w11, w10
    18e8:      	b.hs	0x1834 <filter_16ty_range+0x144>
    18ec:      	cmp	w9, #0x21
    18f0:      	b.lo	0x1920 <filter_16ty_range+0x230>
    18f4:      	ldr	w11, [x0, #0x28]
    18f8:      	mov	w9, wzr
    18fc:      	cmp	w11, w10
    1900:      	b.hi	0x1910 <filter_16ty_range+0x220>
    1904:      	ldr	w11, [x0, #0x2c]
    1908:      	cmp	w11, w10
    190c:      	b.hs	0x1834 <filter_16ty_range+0x144>
    1910:      	cmp	w8, #0x20
    1914:      	eor	w8, w9, #0x1
    1918:      	csel	w0, wzr, w8, ne
    191c:      	ret
    1920:      	mov	w9, wzr
    1924:      	cmp	w8, #0x20
    1928:      	eor	w8, w9, #0x1
    192c:      	csel	w0, wzr, w8, ne
    1930:      	ret
    1934:      	nop
    1938:      	nop
    193c:      	nop

0000000000001940 <filter_8ty_selector_val>:
    1940:      	ldr	w8, [x0, #0x4]
    1944:      	cmp	w8, #0x25
    1948:      	b.hi	0x19bc <filter_8ty_selector_val+0x7c>
    194c:      	mov	x10, #0x40              // =64
    1950:      	mov	w9, #0x1                // =1
    1954:      	movk	x10, #0xc00, lsl #16
    1958:      	lsl	x9, x9, x8
    195c:      	movk	x10, #0x20, lsl #32
    1960:      	tst	x9, x10
    1964:      	b.eq	0x1970 <filter_8ty_selector_val+0x30>
    1968:      	mov	w0, #0x1                // =1
    196c:      	ret
    1970:      	mov	w9, #0x1                // =1
    1974:      	lsl	x9, x9, x8
    1978:      	tst	x9, #0x18
    197c:      	b.eq	0x199c <filter_8ty_selector_val+0x5c>
    1980:      	ldrb	w9, [x1]
    1984:      	ldr	w10, [x0, #0x10]
    1988:      	cmp	w10, w9
    198c:      	b.ne	0x1a3c <filter_8ty_selector_val+0xfc>
    1990:      	cmp	w8, #0x3
    1994:      	cset	w0, eq
    1998:      	ret
    199c:      	cmp	x8, #0xc
    19a0:      	b.ne	0x19bc <filter_8ty_selector_val+0x7c>
    19a4:      	ldrb	w8, [x1]
    19a8:      	ldr	w9, [x0, #0x10]
    19ac:      	tst	w9, w8
    19b0:      	b.eq	0x1ae8 <filter_8ty_selector_val+0x1a8>
    19b4:      	mov	w0, #0x1                // =1
    19b8:      	ret
    19bc:      	cmp	w8, #0x1
    19c0:      	b.eq	0x1a04 <filter_8ty_selector_val+0xc4>
    19c4:      	cmp	w8, #0x2
    19c8:      	b.ne	0x1c90 <filter_8ty_selector_val+0x350>
    19cc:      	ldr	w8, [x0, #0xc]
    19d0:      	cmp	w8, #0xc
    19d4:      	b.hi	0x1b20 <filter_8ty_selector_val+0x1e0>
    19d8:      	mov	w9, #0x1                // =1
    19dc:      	lsl	w8, w9, w8
    19e0:      	mov	w9, #0x1402             // =5122
    19e4:      	tst	w8, w9
    19e8:      	b.eq	0x1b20 <filter_8ty_selector_val+0x1e0>
    19ec:      	ldrsb	w8, [x1]
    19f0:      	ldr	w9, [x0, #0x10]
    19f4:      	cmp	w9, w8
    19f8:      	b.le	0x1ac8 <filter_8ty_selector_val+0x188>
    19fc:      	mov	w0, #0x1                // =1
    1a00:      	ret
    1a04:      	ldr	w8, [x0, #0xc]
    1a08:      	cmp	w8, #0xc
    1a0c:      	b.hi	0x1b08 <filter_8ty_selector_val+0x1c8>
    1a10:      	mov	w9, #0x1                // =1
    1a14:      	lsl	w8, w9, w8
    1a18:      	mov	w9, #0x1402             // =5122
    1a1c:      	tst	w8, w9
    1a20:      	b.eq	0x1b08 <filter_8ty_selector_val+0x1c8>
    1a24:      	ldrsb	w8, [x1]
    1a28:      	ldr	w9, [x0, #0x10]
    1a2c:      	cmp	w9, w8
    1a30:      	b.ge	0x1aa8 <filter_8ty_selector_val+0x168>
    1a34:      	mov	w0, #0x1                // =1
    1a38:      	ret
    1a3c:      	ldr	w10, [x0, #0x8]
    1a40:      	cmp	w10, #0xd
    1a44:      	b.lo	0x1a7c <filter_8ty_selector_val+0x13c>
    1a48:      	ldr	w11, [x0, #0x14]
    1a4c:      	cmp	w11, w9
    1a50:      	b.eq	0x1990 <filter_8ty_selector_val+0x50>
    1a54:      	cmp	w10, #0x11
    1a58:      	b.lo	0x1a7c <filter_8ty_selector_val+0x13c>
    1a5c:      	ldr	w11, [x0, #0x18]
    1a60:      	cmp	w11, w9
    1a64:      	b.eq	0x1990 <filter_8ty_selector_val+0x50>
    1a68:      	cmp	w10, #0x15
    1a6c:      	b.lo	0x1a7c <filter_8ty_selector_val+0x13c>
    1a70:      	ldr	w10, [x0, #0x1c]
    1a74:      	cmp	w10, w9
    1a78:      	b.eq	0x1990 <filter_8ty_selector_val+0x50>
    1a7c:      	cmp	w8, #0x25
    1a80:      	b.hi	0x1c90 <filter_8ty_selector_val+0x350>
    1a84:      	mov	w9, #0x1                // =1
    1a88:      	lsl	x8, x9, x8
    1a8c:      	mov	x9, #0x50               // =80
    1a90:      	movk	x9, #0xc00, lsl #16
    1a94:      	movk	x9, #0x20, lsl #32
    1a98:      	tst	x8, x9
    1a9c:      	b.eq	0x1c90 <filter_8ty_selector_val+0x350>
    1aa0:      	mov	w0, #0x1                // =1
    1aa4:      	ret
    1aa8:      	ldr	w9, [x0, #0x8]
    1aac:      	cmp	w9, #0xd
    1ab0:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1ab4:      	ldr	w10, [x0, #0x14]
    1ab8:      	cmp	w10, w8
    1abc:      	b.ge	0x1b78 <filter_8ty_selector_val+0x238>
    1ac0:      	mov	w0, #0x1                // =1
    1ac4:      	ret
    1ac8:      	ldr	w9, [x0, #0x8]
    1acc:      	cmp	w9, #0xd
    1ad0:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1ad4:      	ldr	w10, [x0, #0x14]
    1ad8:      	cmp	w10, w8
    1adc:      	b.le	0x1b94 <filter_8ty_selector_val+0x254>
    1ae0:      	mov	w0, #0x1                // =1
    1ae4:      	ret
    1ae8:      	ldr	w9, [x0, #0x8]
    1aec:      	cmp	w9, #0xd
    1af0:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1af4:      	ldr	w10, [x0, #0x14]
    1af8:      	tst	w10, w8
    1afc:      	b.eq	0x1bb0 <filter_8ty_selector_val+0x270>
    1b00:      	mov	w0, #0x1                // =1
    1b04:      	ret
    1b08:      	ldrb	w8, [x1]
    1b0c:      	ldr	w9, [x0, #0x10]
    1b10:      	cmp	w9, w8
    1b14:      	b.hs	0x1b38 <filter_8ty_selector_val+0x1f8>
    1b18:      	mov	w0, #0x1                // =1
    1b1c:      	ret
    1b20:      	ldrb	w8, [x1]
    1b24:      	ldr	w9, [x0, #0x10]
    1b28:      	cmp	w9, w8
    1b2c:      	b.ls	0x1b58 <filter_8ty_selector_val+0x218>
    1b30:      	mov	w0, #0x1                // =1
    1b34:      	ret
    1b38:      	ldr	w9, [x0, #0x8]
    1b3c:      	cmp	w9, #0xd
    1b40:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1b44:      	ldr	w10, [x0, #0x14]
    1b48:      	cmp	w10, w8
    1b4c:      	b.hs	0x1bcc <filter_8ty_selector_val+0x28c>
    1b50:      	mov	w0, #0x1                // =1
    1b54:      	ret
    1b58:      	ldr	w9, [x0, #0x8]
    1b5c:      	cmp	w9, #0xd
    1b60:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1b64:      	ldr	w10, [x0, #0x14]
    1b68:      	cmp	w10, w8
    1b6c:      	b.ls	0x1be8 <filter_8ty_selector_val+0x2a8>
    1b70:      	mov	w0, #0x1                // =1
    1b74:      	ret
    1b78:      	cmp	w9, #0x11
    1b7c:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1b80:      	ldr	w10, [x0, #0x18]
    1b84:      	cmp	w10, w8
    1b88:      	b.ge	0x1c04 <filter_8ty_selector_val+0x2c4>
    1b8c:      	mov	w0, #0x1                // =1
    1b90:      	ret
    1b94:      	cmp	w9, #0x11
    1b98:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1b9c:      	ldr	w10, [x0, #0x18]
    1ba0:      	cmp	w10, w8
    1ba4:      	b.le	0x1c20 <filter_8ty_selector_val+0x2e0>
    1ba8:      	mov	w0, #0x1                // =1
    1bac:      	ret
    1bb0:      	cmp	w9, #0x11
    1bb4:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1bb8:      	ldr	w10, [x0, #0x18]
    1bbc:      	tst	w10, w8
    1bc0:      	b.eq	0x1c3c <filter_8ty_selector_val+0x2fc>
    1bc4:      	mov	w0, #0x1                // =1
    1bc8:      	ret
    1bcc:      	cmp	w9, #0x11
    1bd0:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1bd4:      	ldr	w10, [x0, #0x18]
    1bd8:      	cmp	w10, w8
    1bdc:      	b.hs	0x1c58 <filter_8ty_selector_val+0x318>
    1be0:      	mov	w0, #0x1                // =1
    1be4:      	ret
    1be8:      	cmp	w9, #0x11
    1bec:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1bf0:      	ldr	w10, [x0, #0x18]
    1bf4:      	cmp	w10, w8
    1bf8:      	b.ls	0x1c74 <filter_8ty_selector_val+0x334>
    1bfc:      	mov	w0, #0x1                // =1
    1c00:      	ret
    1c04:      	cmp	w9, #0x15
    1c08:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1c0c:      	ldr	w9, [x0, #0x1c]
    1c10:      	cmp	w9, w8
    1c14:      	b.ge	0x1c90 <filter_8ty_selector_val+0x350>
    1c18:      	mov	w0, #0x1                // =1
    1c1c:      	ret
    1c20:      	cmp	w9, #0x15
    1c24:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1c28:      	ldr	w9, [x0, #0x1c]
    1c2c:      	cmp	w9, w8
    1c30:      	b.le	0x1c90 <filter_8ty_selector_val+0x350>
    1c34:      	mov	w0, #0x1                // =1
    1c38:      	ret
    1c3c:      	cmp	w9, #0x15
    1c40:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1c44:      	ldr	w9, [x0, #0x1c]
    1c48:      	tst	w9, w8
    1c4c:      	b.eq	0x1c90 <filter_8ty_selector_val+0x350>
    1c50:      	mov	w0, #0x1                // =1
    1c54:      	ret
    1c58:      	cmp	w9, #0x15
    1c5c:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1c60:      	ldr	w9, [x0, #0x1c]
    1c64:      	cmp	w9, w8
    1c68:      	b.hs	0x1c90 <filter_8ty_selector_val+0x350>
    1c6c:      	mov	w0, #0x1                // =1
    1c70:      	ret
    1c74:      	cmp	w9, #0x15
    1c78:      	b.lo	0x1c90 <filter_8ty_selector_val+0x350>
    1c7c:      	ldr	w9, [x0, #0x1c]
    1c80:      	cmp	w9, w8
    1c84:      	b.ls	0x1c90 <filter_8ty_selector_val+0x350>
    1c88:      	mov	w0, #0x1                // =1
    1c8c:      	ret
    1c90:      	mov	x0, xzr
    1c94:      	ret
    1c98:      	nop
    1c9c:      	nop

0000000000001ca0 <filter_8ty_map>:
    1ca0:      	sub	sp, sp, #0x30
    1ca4:      	str	x30, [sp, #0x10]
    1ca8:      	stp	x20, x19, [sp, #0x20]
    1cac:      	ldrb	w8, [x0, #0x10]
    1cb0:      	mov	x19, x0
    1cb4:      	adrp	x0, 0x1000 <filter_32ty_map+0x40>
    1cb8:      	add	x9, sp, #0x1c
    1cbc:      	str	w8, [sp, #0x1c]
    1cc0:      	mov	w8, #0x1                // =1
    1cc4:      	mov	x20, x1
    1cc8:      	add	x1, sp, #0x1c
    1ccc:      	ldr	x0, [x0]
    1cd0:      	blr	x8
    1cd4:      	cbz	x0, 0x1d48 <filter_8ty_map+0xa8>
    1cd8:      	ldrb	w8, [x20]
    1cdc:      	mov	w9, #0x1                // =1
    1ce0:      	add	x1, sp, #0x8
    1ce4:      	mov	w20, #0x1               // =1
    1ce8:      	str	x8, [sp, #0x8]
    1cec:      	add	x8, sp, #0x8
    1cf0:      	blr	x9
    1cf4:      	ldr	w9, [x19, #0x4]
    1cf8:      	mov	w8, wzr
    1cfc:      	cmp	w9, #0x1d
    1d00:      	b.hi	0x1d44 <filter_8ty_map+0xa4>
    1d04:      	mov	w11, #0x8400            // =33792
    1d08:      	lsl	w10, w20, w9
    1d0c:      	movk	w11, #0x3003, lsl #16
    1d10:      	tst	w10, w11
    1d14:      	b.eq	0x1d24 <filter_8ty_map+0x84>
    1d18:      	cmp	x0, #0x0
    1d1c:      	cset	w8, ne
    1d20:      	b	0x1d44 <filter_8ty_map+0xa4>
    1d24:      	mov	w10, #0x1               // =1
    1d28:      	lsl	w9, w10, w9
    1d2c:      	mov	w10, #0x800             // =2048
    1d30:      	movk	w10, #0xc, lsl #16
    1d34:      	tst	w9, w10
    1d38:      	b.eq	0x1d44 <filter_8ty_map+0xa4>
    1d3c:      	cmp	x0, #0x0
    1d40:      	cset	w8, eq
    1d44:      	mov	w0, w8
    1d48:      	ldp	x20, x19, [sp, #0x20]
    1d4c:      	ldr	x30, [sp, #0x10]
    1d50:      	add	sp, sp, #0x30
    1d54:      	ret
    1d58:      	nop
    1d5c:      	nop

0000000000001d60 <filter_8ty_range>:
    1d60:      	ldr	w9, [x0, #0xc]
    1d64:      	ldr	w8, [x0, #0x4]
    1d68:      	mov	w10, #0x1               // =1
    1d6c:      	cmp	w9, #0xc
    1d70:      	lsl	w9, w10, w9
    1d74:      	mov	w10, #0x1402            // =5122
    1d78:      	and	w9, w9, w10
    1d7c:      	ccmp	w9, #0x0, #0x4, ls
    1d80:      	b.eq	0x1e80 <filter_8ty_range+0x120>
    1d84:      	ldrsb	w10, [x1]
    1d88:      	cmp	w8, #0x1f
    1d8c:      	b.ne	0x1e14 <filter_8ty_range+0xb4>
    1d90:      	ldr	w9, [x0, #0x10]
    1d94:      	cmp	w9, w10
    1d98:      	b.gt	0x1da8 <filter_8ty_range+0x48>
    1d9c:      	ldr	w9, [x0, #0x14]
    1da0:      	cmp	w9, w10
    1da4:      	b.ge	0x1ea4 <filter_8ty_range+0x144>
    1da8:      	ldr	w9, [x0, #0x8]
    1dac:      	cmp	w9, #0x11
    1db0:      	b.lo	0x1f90 <filter_8ty_range+0x230>
    1db4:      	ldr	w11, [x0, #0x18]
    1db8:      	cmp	w11, w10
    1dbc:      	b.gt	0x1dcc <filter_8ty_range+0x6c>
    1dc0:      	ldr	w11, [x0, #0x1c]
    1dc4:      	cmp	w11, w10
    1dc8:      	b.ge	0x1ea4 <filter_8ty_range+0x144>
    1dcc:      	cmp	w9, #0x19
    1dd0:      	b.lo	0x1f90 <filter_8ty_range+0x230>
    1dd4:      	ldr	w11, [x0, #0x20]
    1dd8:      	cmp	w11, w10
    1ddc:      	b.gt	0x1dec <filter_8ty_range+0x8c>
    1de0:      	ldr	w11, [x0, #0x24]
    1de4:      	cmp	w11, w10
    1de8:      	b.ge	0x1ea4 <filter_8ty_range+0x144>
    1dec:      	cmp	w9, #0x21
    1df0:      	b.lo	0x1f90 <filter_8ty_range+0x230>
    1df4:      	ldr	w11, [x0, #0x28]
    1df8:      	mov	w9, wzr
    1dfc:      	cmp	w11, w10
    1e00:      	b.gt	0x1f80 <filter_8ty_range+0x220>
    1e04:      	ldr	w11, [x0, #0x2c]
    1e08:      	cmp	w11, w10
    1e0c:      	b.ge	0x1ea4 <filter_8ty_range+0x144>
    1e10:      	b	0x1f80 <filter_8ty_range+0x220>
    1e14:      	ldp	w9, w12, [x0, #0x10]
    1e18:      	ldr	w11, [x0, #0x8]
    1e1c:      	cmp	w9, w10
    1e20:      	ccmp	w12, w10, #0x8, le
    1e24:      	cset	w9, ge
    1e28:      	cmp	w11, #0x11
    1e2c:      	b.lo	0x1f80 <filter_8ty_range+0x220>
    1e30:      	ldp	w12, w13, [x0, #0x18]
    1e34:      	cmp	w12, w10
    1e38:      	ccmp	w13, w10, #0x8, le
    1e3c:      	csinc	w9, w9, wzr, lt
    1e40:      	cmp	w11, #0x19
    1e44:      	b.lo	0x1f80 <filter_8ty_range+0x220>
    1e48:      	ldp	w12, w13, [x0, #0x20]
    1e4c:      	cmp	w12, w10
    1e50:      	ccmp	w13, w10, #0x8, le
    1e54:      	csinc	w9, w9, wzr, lt
    1e58:      	cmp	w11, #0x21
    1e5c:      	b.lo	0x1f80 <filter_8ty_range+0x220>
    1e60:      	ldp	w11, w12, [x0, #0x28]
    1e64:      	cmp	w11, w10
    1e68:      	ccmp	w12, w10, #0x8, le
    1e6c:      	csinc	w9, w9, wzr, lt
    1e70:      	cmp	w8, #0x20
    1e74:      	eor	w8, w9, #0x1
    1e78:      	csel	w0, wzr, w8, ne
    1e7c:      	ret
    1e80:      	ldrb	w10, [x1]
    1e84:      	cmp	w8, #0x1f
    1e88:      	b.ne	0x1eac <filter_8ty_range+0x14c>
    1e8c:      	ldr	w9, [x0, #0x10]
    1e90:      	cmp	w9, w10
    1e94:      	b.hi	0x1f18 <filter_8ty_range+0x1b8>
    1e98:      	ldr	w9, [x0, #0x14]
    1e9c:      	cmp	w9, w10
    1ea0:      	b.lo	0x1f18 <filter_8ty_range+0x1b8>
    1ea4:      	mov	w0, #0x1                // =1
    1ea8:      	ret
    1eac:      	ldp	w9, w12, [x0, #0x10]
    1eb0:      	ldr	w11, [x0, #0x8]
    1eb4:      	cmp	w9, w10
    1eb8:      	ccmp	w12, w10, #0x0, ls
    1ebc:      	cset	w9, hs
    1ec0:      	cmp	w11, #0x11
    1ec4:      	b.lo	0x1f80 <filter_8ty_range+0x220>
    1ec8:      	ldp	w12, w13, [x0, #0x18]
    1ecc:      	cmp	w12, w10
    1ed0:      	ccmp	w13, w10, #0x0, ls
    1ed4:      	csinc	w9, w9, wzr, lo
    1ed8:      	cmp	w11, #0x19
    1edc:      	b.lo	0x1f80 <filter_8ty_range+0x220>
    1ee0:      	ldp	w12, w13, [x0, #0x20]
    1ee4:      	cmp	w12, w10
    1ee8:      	ccmp	w13, w10, #0x0, ls
    1eec:      	csinc	w9, w9, wzr, lo
    1ef0:      	cmp	w11, #0x21
    1ef4:      	b.lo	0x1f80 <filter_8ty_range+0x220>
    1ef8:      	ldp	w11, w12, [x0, #0x28]
    1efc:      	cmp	w11, w10
    1f00:      	ccmp	w12, w10, #0x0, ls
    1f04:      	csinc	w9, w9, wzr, lo
    1f08:      	cmp	w8, #0x20
    1f0c:      	eor	w8, w9, #0x1
    1f10:      	csel	w0, wzr, w8, ne
    1f14:      	ret
    1f18:      	ldr	w9, [x0, #0x8]
    1f1c:      	cmp	w9, #0x11
    1f20:      	b.lo	0x1f90 <filter_8ty_range+0x230>
    1f24:      	ldr	w11, [x0, #0x18]
    1f28:      	cmp	w11, w10
    1f2c:      	b.hi	0x1f3c <filter_8ty_range+0x1dc>
    1f30:      	ldr	w11, [x0, #0x1c]
    1f34:      	cmp	w11, w10
    1f38:      	b.hs	0x1ea4 <filter_8ty_range+0x144>
    1f3c:      	cmp	w9, #0x19
    1f40:      	b.lo	0x1f90 <filter_8ty_range+0x230>
    1f44:      	ldr	w11, [x0, #0x20]
    1f48:      	cmp	w11, w10
    1f4c:      	b.hi	0x1f5c <filter_8ty_range+0x1fc>
    1f50:      	ldr	w11, [x0, #0x24]
    1f54:      	cmp	w11, w10
    1f58:      	b.hs	0x1ea4 <filter_8ty_range+0x144>
    1f5c:      	cmp	w9, #0x21
    1f60:      	b.lo	0x1f90 <filter_8ty_range+0x230>
    1f64:      	ldr	w11, [x0, #0x28]
    1f68:      	mov	w9, wzr
    1f6c:      	cmp	w11, w10
    1f70:      	b.hi	0x1f80 <filter_8ty_range+0x220>
    1f74:      	ldr	w11, [x0, #0x2c]
    1f78:      	cmp	w11, w10
    1f7c:      	b.hs	0x1ea4 <filter_8ty_range+0x144>
    1f80:      	cmp	w8, #0x20
    1f84:      	eor	w8, w9, #0x1
    1f88:      	csel	w0, wzr, w8, ne
    1f8c:      	ret
    1f90:      	mov	w9, wzr
    1f94:      	cmp	w8, #0x20
    1f98:      	eor	w8, w9, #0x1
    1f9c:      	csel	w0, wzr, w8, ne
    1fa0:      	ret
    1fa4:      	nop
    1fa8:      	nop
    1fac:      	nop

0000000000001fb0 <filter_file_buf>:
    1fb0:      	stp	x30, x19, [sp, #-0x10]!
    1fb4:      	ldr	w2, [x1]
    1fb8:      	ldr	w8, [x0, #0x4]
    1fbc:      	mov	x19, x0
    1fc0:      	cbnz	w2, 0x1fdc <filter_file_buf+0x2c>
    1fc4:      	and	w9, w8, #0xfffffffe
    1fc8:      	cmp	w9, #0x24
    1fcc:      	b.eq	0x1fdc <filter_file_buf+0x2c>
    1fd0:      	mov	x0, xzr
    1fd4:      	ldp	x30, x19, [sp], #0x10
    1fd8:      	ret
    1fdc:      	cmp	w8, #0x25
    1fe0:      	b.hi	0x203c <filter_file_buf+0x8c>
    1fe4:      	mov	w9, #0x1                // =1
    1fe8:      	mov	w10, #0x100             // =256
    1fec:      	lsl	x9, x9, x8
    1ff0:      	movk	w10, #0x400, lsl #16
    1ff4:      	tst	x9, x10
    1ff8:      	b.ne	0x2080 <filter_file_buf+0xd0>
    1ffc:      	mov	w9, #0x1                // =1
    2000:      	mov	w10, #0x200             // =512
    2004:      	lsl	x9, x9, x8
    2008:      	movk	w10, #0x800, lsl #16
    200c:      	tst	x9, x10
    2010:      	b.ne	0x2064 <filter_file_buf+0xb4>
    2014:      	mov	w9, #0x1                // =1
    2018:      	lsl	x9, x9, x8
    201c:      	tst	x9, #0x3000000000
    2020:      	b.eq	0x203c <filter_file_buf+0x8c>
    2024:      	mov	x0, x19
    2028:      	bl	0x2c90 <filter_file_type>
    202c:      	ldr	w8, [x19, #0x4]
    2030:      	cmp	w8, #0x25
    2034:      	b.ls	0x20a8 <filter_file_buf+0xf8>
    2038:      	b	0x20cc <filter_file_buf+0x11c>
    203c:      	sub	w9, w8, #0x3
    2040:      	cmp	w9, #0x2
    2044:      	b.hs	0x209c <filter_file_buf+0xec>
    2048:      	add	x1, x1, #0x4
    204c:      	mov	x0, x19
    2050:      	bl	0x26c0 <filter_char_buf_equal>
    2054:      	ldr	w8, [x19, #0x4]
    2058:      	cmp	w8, #0x25
    205c:      	b.ls	0x20a8 <filter_file_buf+0xf8>
    2060:      	b	0x20cc <filter_file_buf+0x11c>
    2064:      	ldr	w0, [x19, #0x10]
    2068:      	add	x1, x1, #0x4
    206c:      	bl	0x2bb0 <filter_char_buf_postfix>
    2070:      	ldr	w8, [x19, #0x4]
    2074:      	cmp	w8, #0x25
    2078:      	b.ls	0x20a8 <filter_file_buf+0xf8>
    207c:      	b	0x20cc <filter_file_buf+0x11c>
    2080:      	ldr	w0, [x19, #0x10]
    2084:      	add	x1, x1, #0x4
    2088:      	bl	0x2af0 <filter_char_buf_prefix>
    208c:      	ldr	w8, [x19, #0x4]
    2090:      	cmp	w8, #0x25
    2094:      	b.ls	0x20a8 <filter_file_buf+0xf8>
    2098:      	b	0x20cc <filter_file_buf+0x11c>
    209c:      	mov	x0, xzr
    20a0:      	cmp	w8, #0x25
    20a4:      	b.hi	0x20cc <filter_file_buf+0x11c>
    20a8:      	mov	w8, w8
    20ac:      	mov	w9, #0x1                // =1
    20b0:      	lsl	x8, x9, x8
    20b4:      	mov	x9, #0x50               // =80
    20b8:      	movk	x9, #0xc00, lsl #16
    20bc:      	movk	x9, #0x20, lsl #32
    20c0:      	tst	x8, x9
    20c4:      	b.eq	0x20cc <filter_file_buf+0x11c>
    20c8:      	eor	x0, x0, #0x1
    20cc:      	ldp	x30, x19, [sp], #0x10
    20d0:      	ret
    20d4:      	nop
    20d8:      	nop
    20dc:      	nop

00000000000020e0 <filter_char_buf>:
    20e0:      	stp	x30, x19, [sp, #-0x10]!
    20e4:      	mov	w8, w2
    20e8:      	mov	x19, x0
    20ec:      	add	x9, x1, w2, sxtw
    20f0:      	ldur	w2, [x9, #-0x4]
    20f4:      	add	x1, x1, w8, uxtw
    20f8:      	ldr	w8, [x0, #0x4]
    20fc:      	mov	x0, xzr
    2100:      	cmp	w8, #0x19
    2104:      	b.gt	0x2128 <filter_char_buf+0x48>
    2108:      	sub	w9, w8, #0x3
    210c:      	cmp	w9, #0x2
    2110:      	b.lo	0x2174 <filter_char_buf+0x94>
    2114:      	cmp	w8, #0x8
    2118:      	b.eq	0x2168 <filter_char_buf+0x88>
    211c:      	cmp	w8, #0x9
    2120:      	b.eq	0x2140 <filter_char_buf+0x60>
    2124:      	b	0x2190 <filter_char_buf+0xb0>
    2128:      	cmp	w8, #0x20
    212c:      	b.gt	0x214c <filter_char_buf+0x6c>
    2130:      	cmp	w8, #0x1a
    2134:      	b.eq	0x2168 <filter_char_buf+0x88>
    2138:      	cmp	w8, #0x1b
    213c:      	b.ne	0x2190 <filter_char_buf+0xb0>
    2140:      	ldr	w0, [x19, #0x10]
    2144:      	bl	0x2bb0 <filter_char_buf_postfix>
    2148:      	b	0x218c <filter_char_buf+0xac>
    214c:      	cmp	w8, #0x21
    2150:      	b.eq	0x2180 <filter_char_buf+0xa0>
    2154:      	cmp	w8, #0x22
    2158:      	b.ne	0x2190 <filter_char_buf+0xb0>
    215c:      	mov	x0, x19
    2160:      	mov	w3, #0x1                // =1
    2164:      	b	0x2188 <filter_char_buf+0xa8>
    2168:      	ldr	w0, [x19, #0x10]
    216c:      	bl	0x2af0 <filter_char_buf_prefix>
    2170:      	b	0x218c <filter_char_buf+0xac>
    2174:      	mov	x0, x19
    2178:      	bl	0x26c0 <filter_char_buf_equal>
    217c:      	b	0x218c <filter_char_buf+0xac>
    2180:      	mov	x0, x19
    2184:      	mov	w3, wzr
    2188:      	bl	0x2d90 <filter_char_substring>
    218c:      	ldr	w8, [x19, #0x4]
    2190:      	cmp	w8, #0x25
    2194:      	b.hi	0x21c0 <filter_char_buf+0xe0>
    2198:      	mov	w8, w8
    219c:      	mov	w9, #0x1                // =1
    21a0:      	lsl	x8, x9, x8
    21a4:      	mov	x9, #0x50               // =80
    21a8:      	movk	x9, #0xc00, lsl #16
    21ac:      	movk	x9, #0x20, lsl #32
    21b0:      	tst	x8, x9
    21b4:      	b.eq	0x21c0 <filter_char_buf+0xe0>
    21b8:      	cmp	x0, #0x0
    21bc:      	cset	w0, eq
    21c0:      	ldp	x30, x19, [sp], #0x10
    21c4:      	ret
    21c8:      	nop
    21cc:      	nop

00000000000021d0 <filter_inet>:
    21d0:      	sub	sp, sp, #0x80
    21d4:      	str	x30, [sp, #0x50]
    21d8:      	stp	x22, x21, [sp, #0x60]
    21dc:      	stp	x20, x19, [sp, #0x70]
    21e0:      	ldr	w10, [x0, #0xc]
    21e4:      	mov	x8, xzr
    21e8:      	stp	xzr, xzr, [sp, #0x28]
    21ec:      	cmp	w10, #0x27
    21f0:      	str	xzr, [sp, #0x10]
    21f4:      	stp	xzr, xzr, [sp, #0x18]
    21f8:      	str	wzr, [sp, #0x58]
    21fc:      	str	wzr, [sp, #0xc]
    2200:      	b.gt	0x224c <filter_inet+0x7c>
    2204:      	cmp	w10, #0x5
    2208:      	b.eq	0x2280 <filter_inet+0xb0>
    220c:      	cmp	w10, #0x7
    2210:      	mov	x11, x1
    2214:      	b.ne	0x2454 <filter_inet+0x284>
    2218:      	ldr	w9, [x0, #0x4]
    221c:      	mov	x8, xzr
    2220:      	cmp	w9, #0x13
    2224:      	b.le	0x22c8 <filter_inet+0xf8>
    2228:      	cmp	w9, #0x17
    222c:      	b.gt	0x2264 <filter_inet+0x94>
    2230:      	sub	w10, w9, #0x14
    2234:      	cmp	w10, #0x2
    2238:      	b.lo	0x2324 <filter_inet+0x154>
    223c:      	sub	w10, w9, #0x16
    2240:      	cmp	w10, #0x2
    2244:      	b.lo	0x231c <filter_inet+0x14c>
    2248:      	b	0x2454 <filter_inet+0x284>
    224c:      	cmp	w10, #0x28
    2250:      	b.eq	0x2298 <filter_inet+0xc8>
    2254:      	cmp	w10, #0x29
    2258:      	mov	x11, x1
    225c:      	b.eq	0x2218 <filter_inet+0x48>
    2260:      	b	0x2454 <filter_inet+0x284>
    2264:      	cmp	w9, #0x1b
    2268:      	b.gt	0x2368 <filter_inet+0x198>
    226c:      	cmp	w9, #0x18
    2270:      	b.eq	0x2424 <filter_inet+0x254>
    2274:      	cmp	w9, #0x19
    2278:      	b.eq	0x2388 <filter_inet+0x1b8>
    227c:      	b	0x2454 <filter_inet+0x284>
    2280:      	mov	x11, xzr
    2284:      	ldr	w9, [x0, #0x4]
    2288:      	mov	x8, xzr
    228c:      	cmp	w9, #0x13
    2290:      	b.gt	0x2228 <filter_inet+0x58>
    2294:      	b	0x22c8 <filter_inet+0xf8>
    2298:      	ldrh	w8, [x1]
    229c:      	ldrh	w9, [x1, #0x2]
    22a0:      	mov	x11, xzr
    22a4:      	strh	w8, [sp, #0x36]
    22a8:      	strh	w9, [sp, #0x30]
    22ac:      	ldp	x8, x9, [x1, #0x8]
    22b0:      	add	x1, sp, #0x10
    22b4:      	stp	x8, x9, [sp, #0x10]
    22b8:      	ldr	w9, [x0, #0x4]
    22bc:      	mov	x8, xzr
    22c0:      	cmp	w9, #0x13
    22c4:      	b.gt	0x2228 <filter_inet+0x58>
    22c8:      	cmp	w9, #0xf
    22cc:      	b.le	0x22f0 <filter_inet+0x120>
    22d0:      	cmp	w9, #0x11
    22d4:      	b.gt	0x230c <filter_inet+0x13c>
    22d8:      	cmp	w9, #0x10
    22dc:      	b.eq	0x231c <filter_inet+0x14c>
    22e0:      	cmp	w9, #0x11
    22e4:      	b.ne	0x2454 <filter_inet+0x284>
    22e8:      	ldrh	w8, [x1, #0x24]
    22ec:      	b	0x253c <filter_inet+0x36c>
    22f0:      	cmp	w9, #0xd
    22f4:      	b.eq	0x2424 <filter_inet+0x254>
    22f8:      	cmp	w9, #0xe
    22fc:      	b.eq	0x2388 <filter_inet+0x1b8>
    2300:      	cmp	w9, #0xf
    2304:      	b.eq	0x2324 <filter_inet+0x154>
    2308:      	b	0x2454 <filter_inet+0x284>
    230c:      	cmp	w9, #0x12
    2310:      	b.eq	0x2324 <filter_inet+0x154>
    2314:      	cmp	w9, #0x13
    2318:      	b.ne	0x2454 <filter_inet+0x284>
    231c:      	ldrh	w10, [x1, #0x22]
    2320:      	b	0x2328 <filter_inet+0x158>
    2324:      	ldrh	w10, [x1, #0x20]
    2328:      	mov	w19, wzr
    232c:      	mov	w20, wzr
    2330:      	mov	x21, xzr
    2334:      	str	w10, [sp, #0xc]
    2338:      	mov	x8, xzr
    233c:      	cmp	w9, #0x11
    2340:      	b.gt	0x23a0 <filter_inet+0x1d0>
    2344:      	sub	w10, w9, #0xd
    2348:      	cmp	w10, #0x2
    234c:      	b.lo	0x23d8 <filter_inet+0x208>
    2350:      	sub	w10, w9, #0xf
    2354:      	cmp	w10, #0x2
    2358:      	b.lo	0x244c <filter_inet+0x27c>
    235c:      	cmp	w9, #0x11
    2360:      	b.eq	0x2540 <filter_inet+0x370>
    2364:      	b	0x2454 <filter_inet+0x284>
    2368:      	cmp	w9, #0x1c
    236c:      	b.eq	0x2538 <filter_inet+0x368>
    2370:      	cmp	w9, #0x1d
    2374:      	b.ne	0x2454 <filter_inet+0x284>
    2378:      	cmp	w10, #0x7
    237c:      	b.ne	0x2590 <filter_inet+0x3c0>
    2380:      	cbnz	x11, 0x259c <filter_inet+0x3cc>
    2384:      	b	0x2540 <filter_inet+0x370>
    2388:      	ldp	w19, w20, [x1, #0x10]
    238c:      	ldr	x21, [x1, #0x18]
    2390:      	mov	w10, wzr
    2394:      	mov	x8, xzr
    2398:      	cmp	w9, #0x11
    239c:      	b.le	0x2344 <filter_inet+0x174>
    23a0:      	cmp	w9, #0x19
    23a4:      	b.hi	0x2440 <filter_inet+0x270>
    23a8:      	mov	w11, #0x1               // =1
    23ac:      	mov	w12, #0x500000          // =5242880
    23b0:      	lsl	w11, w11, w9
    23b4:      	tst	w11, w12
    23b8:      	b.ne	0x246c <filter_inet+0x29c>
    23bc:      	mov	w12, #0xa00000          // =10485760
    23c0:      	tst	w11, w12
    23c4:      	b.ne	0x248c <filter_inet+0x2bc>
    23c8:      	mov	w10, #0x1               // =1
    23cc:      	lsl	w10, w10, w9
    23d0:      	tst	w10, #0x3000000
    23d4:      	b.eq	0x2440 <filter_inet+0x270>
    23d8:      	ldrh	w8, [x1, #0x26]
    23dc:      	cmp	w8, #0xa
    23e0:      	b.eq	0x24ac <filter_inet+0x2dc>
    23e4:      	cmp	w8, #0x2
    23e8:      	b.ne	0x251c <filter_inet+0x34c>
    23ec:      	ldr	w8, [x0, #0x10]
    23f0:      	mov	x22, x0
    23f4:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    23f8:      	add	x9, sp, #0x5c
    23fc:      	str	w8, [sp, #0x5c]
    2400:      	mov	w8, #0x1                // =1
    2404:      	add	x1, sp, #0x5c
    2408:      	ldr	x0, [x0]
    240c:      	blr	x8
    2410:      	cbz	x0, 0x255c <filter_inet+0x38c>
    2414:      	mov	w8, #0x20               // =32
    2418:      	add	x1, sp, #0x3c
    241c:      	stp	w8, w19, [sp, #0x3c]
    2420:      	b	0x24ec <filter_inet+0x31c>
    2424:      	ldp	w19, w20, [x1]
    2428:      	ldr	x21, [x1, #0x8]
    242c:      	mov	w10, wzr
    2430:      	mov	x8, xzr
    2434:      	cmp	w9, #0x11
    2438:      	b.le	0x2344 <filter_inet+0x174>
    243c:      	b	0x23a0 <filter_inet+0x1d0>
    2440:      	sub	w9, w9, #0x12
    2444:      	cmp	w9, #0x2
    2448:      	b.hs	0x2454 <filter_inet+0x284>
    244c:      	add	x1, sp, #0xc
    2450:      	b	0x2544 <filter_inet+0x374>
    2454:      	ldp	x20, x19, [sp, #0x70]
    2458:      	mov	x0, x8
    245c:      	ldr	x30, [sp, #0x50]
    2460:      	ldp	x22, x21, [sp, #0x60]
    2464:      	add	sp, sp, #0x80
    2468:      	ret
    246c:      	cmp	w10, #0x400
    2470:      	cset	w8, lo
    2474:      	ldp	x20, x19, [sp, #0x70]
    2478:      	mov	x0, x8
    247c:      	ldr	x30, [sp, #0x50]
    2480:      	ldp	x22, x21, [sp, #0x60]
    2484:      	add	sp, sp, #0x80
    2488:      	ret
    248c:      	cmp	w10, #0x3ff
    2490:      	cset	w8, hi
    2494:      	ldp	x20, x19, [sp, #0x70]
    2498:      	mov	x0, x8
    249c:      	ldr	x30, [sp, #0x50]
    24a0:      	ldp	x22, x21, [sp, #0x60]
    24a4:      	add	sp, sp, #0x80
    24a8:      	ret
    24ac:      	ldr	w8, [x0, #0x14]
    24b0:      	mov	x22, x0
    24b4:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    24b8:      	add	x9, sp, #0x5c
    24bc:      	str	w8, [sp, #0x5c]
    24c0:      	mov	w8, #0x1                // =1
    24c4:      	add	x1, sp, #0x5c
    24c8:      	ldr	x0, [x0]
    24cc:      	blr	x8
    24d0:      	cbz	x0, 0x255c <filter_inet+0x38c>
    24d4:      	mov	w8, #0x80               // =128
    24d8:      	add	x1, sp, #0x3c
    24dc:      	stp	w20, w21, [sp, #0x44]
    24e0:      	stp	w8, w19, [sp, #0x3c]
    24e4:      	lsr	x8, x21, #32
    24e8:      	str	w8, [sp, #0x4c]
    24ec:      	mov	w8, #0x1                // =1
    24f0:      	blr	x8
    24f4:      	ldr	w8, [x22, #0x4]
    24f8:      	sub	w9, w8, #0x18
    24fc:      	cmp	w9, #0x2
    2500:      	b.lo	0x256c <filter_inet+0x39c>
    2504:      	sub	w8, w8, #0xd
    2508:      	cmp	w8, #0x1
    250c:      	b.hi	0x251c <filter_inet+0x34c>
    2510:      	cmp	x0, #0x0
    2514:      	cset	w8, ne
    2518:      	b	0x2574 <filter_inet+0x3a4>
    251c:      	mov	w8, wzr
    2520:      	ldp	x20, x19, [sp, #0x70]
    2524:      	mov	x0, x8
    2528:      	ldr	x30, [sp, #0x50]
    252c:      	ldp	x22, x21, [sp, #0x60]
    2530:      	add	sp, sp, #0x80
    2534:      	ret
    2538:      	ldrh	w8, [x1, #0x26]
    253c:      	str	w8, [sp, #0x58]
    2540:      	add	x1, sp, #0x58
    2544:      	bl	0xfc0 <filter_32ty_map>
    2548:      	ldp	x20, x19, [sp, #0x70]
    254c:      	ldr	x30, [sp, #0x50]
    2550:      	ldp	x22, x21, [sp, #0x60]
    2554:      	add	sp, sp, #0x80
    2558:      	ret
    255c:      	ldr	w8, [x22, #0x4]
    2560:      	and	w8, w8, #0xfffffffe
    2564:      	cmp	w8, #0x18
    2568:      	b	0x2570 <filter_inet+0x3a0>
    256c:      	cmp	x0, #0x0
    2570:      	cset	w8, eq
    2574:      	mov	w8, w8
    2578:      	ldp	x20, x19, [sp, #0x70]
    257c:      	mov	x0, x8
    2580:      	ldr	x30, [sp, #0x50]
    2584:      	ldp	x22, x21, [sp, #0x60]
    2588:      	add	sp, sp, #0x80
    258c:      	ret
    2590:      	cmp	w10, #0x29
    2594:      	b.ne	0x25a4 <filter_inet+0x3d4>
    2598:      	cbz	x11, 0x25a4 <filter_inet+0x3d4>
    259c:      	ldrb	w8, [x11, #0x3a]
    25a0:      	str	w8, [sp, #0x58]
    25a4:      	cmp	w10, #0x29
    25a8:      	b.eq	0x2540 <filter_inet+0x370>
    25ac:      	cmp	w10, #0x7
    25b0:      	b.eq	0x2540 <filter_inet+0x370>
    25b4:      	mov	x8, xzr
    25b8:      	ldp	x20, x19, [sp, #0x70]
    25bc:      	mov	x0, x8
    25c0:      	ldr	x30, [sp, #0x50]
    25c4:      	ldp	x22, x21, [sp, #0x60]
    25c8:      	add	sp, sp, #0x80
    25cc:      	ret

00000000000025d0 <filter_sockaddr_un>:
    25d0:      	sub	sp, sp, #0x20
    25d4:      	stp	x30, x19, [sp, #0x10]
    25d8:      	mov	x19, x0
    25dc:      	ldrb	w2, [x1, #0x3]
    25e0:      	mov	x0, xzr
    25e4:      	ldr	w8, [x19, #0x4]
    25e8:      	cmp	w8, #0x19
    25ec:      	b.gt	0x2640 <filter_sockaddr_un+0x70>
    25f0:      	sub	w9, w8, #0x3
    25f4:      	cmp	w9, #0x2
    25f8:      	b.hs	0x2654 <filter_sockaddr_un+0x84>
    25fc:      	add	x1, x1, #0x4
    2600:      	mov	x0, x19
    2604:      	bl	0x26c0 <filter_char_buf_equal>
    2608:      	ldr	w8, [x19, #0x4]
    260c:      	cmp	w8, #0x25
    2610:      	b.hi	0x2634 <filter_sockaddr_un+0x64>
    2614:      	mov	w9, #0x1                // =1
    2618:      	lsl	x8, x9, x8
    261c:      	mov	x9, #0x50               // =80
    2620:      	movk	x9, #0xc00, lsl #16
    2624:      	movk	x9, #0x20, lsl #32
    2628:      	tst	x8, x9
    262c:      	b.eq	0x2634 <filter_sockaddr_un+0x64>
    2630:      	eor	x0, x0, #0x1
    2634:      	ldp	x30, x19, [sp, #0x10]
    2638:      	add	sp, sp, #0x20
    263c:      	ret
    2640:      	cmp	w8, #0x1c
    2644:      	b.eq	0x26a0 <filter_sockaddr_un+0xd0>
    2648:      	cmp	w8, #0x1a
    264c:      	b.eq	0x265c <filter_sockaddr_un+0x8c>
    2650:      	b	0x2634 <filter_sockaddr_un+0x64>
    2654:      	cmp	w8, #0x8
    2658:      	b.ne	0x2634 <filter_sockaddr_un+0x64>
    265c:      	ldr	w0, [x19, #0x10]
    2660:      	add	x1, x1, #0x4
    2664:      	bl	0x2af0 <filter_char_buf_prefix>
    2668:      	ldr	w8, [x19, #0x4]
    266c:      	cmp	w8, #0x25
    2670:      	b.hi	0x2634 <filter_sockaddr_un+0x64>
    2674:      	mov	w9, #0x1                // =1
    2678:      	lsl	x8, x9, x8
    267c:      	mov	x9, #0x50               // =80
    2680:      	movk	x9, #0xc00, lsl #16
    2684:      	movk	x9, #0x20, lsl #32
    2688:      	tst	x8, x9
    268c:      	b.eq	0x2634 <filter_sockaddr_un+0x64>
    2690:      	eor	x0, x0, #0x1
    2694:      	ldp	x30, x19, [sp, #0x10]
    2698:      	add	sp, sp, #0x20
    269c:      	ret
    26a0:      	ldrh	w8, [x1]
    26a4:      	add	x1, sp, #0xc
    26a8:      	mov	x0, x19
    26ac:      	str	w8, [sp, #0xc]
    26b0:      	bl	0xfc0 <filter_32ty_map>
    26b4:      	ldp	x30, x19, [sp, #0x10]
    26b8:      	add	sp, sp, #0x20
    26bc:      	ret

00000000000026c0 <filter_char_buf_equal>:
    26c0:      	str	x29, [sp, #-0x50]!
    26c4:      	stp	x30, x25, [sp, #0x10]
    26c8:      	stp	x24, x23, [sp, #0x20]
    26cc:      	stp	x22, x21, [sp, #0x30]
    26d0:      	stp	x20, x19, [sp, #0x40]
    26d4:      	cmp	w2, #0x1, lsl #12       // =0x1000
    26d8:      	str	wzr, [sp, #0x8]
    26dc:      	b.ls	0x26fc <filter_char_buf_equal+0x3c>
    26e0:      	mov	x0, xzr
    26e4:      	ldp	x20, x19, [sp, #0x40]
    26e8:      	ldp	x22, x21, [sp, #0x30]
    26ec:      	ldp	x24, x23, [sp, #0x20]
    26f0:      	ldp	x30, x25, [sp, #0x10]
    26f4:      	ldr	x29, [sp], #0x50
    26f8:      	ret
    26fc:      	and	w9, w2, #0xffff
    2700:      	add	x8, x0, #0x10
    2704:      	cmp	w9, #0x90
    2708:      	b.hi	0x2778 <filter_char_buf_equal+0xb8>
    270c:      	and	w9, w2, #0xff
    2710:      	mov	w10, #0xab              // =171
    2714:      	tst	w2, #0xffff
    2718:      	mul	w9, w9, w10
    271c:      	mov	w10, #0x18              // =24
    2720:      	lsr	w9, w9, #12
    2724:      	msub	w9, w9, w10, w2
    2728:      	b.eq	0x2738 <filter_char_buf_equal+0x78>
    272c:      	tst	w9, #0xff
    2730:      	mov	w23, w2
    2734:      	b.eq	0x2750 <filter_char_buf_equal+0x90>
    2738:      	sub	w9, w2, w9, uxtb
    273c:      	and	w10, w9, #0xffff
    2740:      	add	w9, w9, #0x18
    2744:      	and	w23, w9, #0xffff
    2748:      	cmp	w10, #0x78
    274c:      	b.hi	0x27ec <filter_char_buf_equal+0x12c>
    2750:      	and	w9, w23, #0xff
    2754:      	mov	w10, #0xab              // =171
    2758:      	mul	w9, w9, w10
    275c:      	lsr	w9, w9, #12
    2760:      	sub	w22, w9, #0x1
    2764:      	and	w9, w22, #0xf
    2768:      	ldr	w24, [x8, w9, uxtw #2]
    276c:      	cmn	w24, #0x1
    2770:      	b.ne	0x2864 <filter_char_buf_equal+0x1a4>
    2774:      	b	0x2a0c <filter_char_buf_equal+0x34c>
    2778:      	cmp	w9, #0x101
    277c:      	b.hs	0x27bc <filter_char_buf_equal+0xfc>
    2780:      	mov	w23, #0x100             // =256
    2784:      	sub	w9, w23, #0x100
    2788:      	ror	w9, w9, #0x8
    278c:      	cmp	w9, #0x2
    2790:      	b.le	0x27fc <filter_char_buf_equal+0x13c>
    2794:      	cmp	w9, #0x3
    2798:      	b.eq	0x2838 <filter_char_buf_equal+0x178>
    279c:      	cmp	w9, #0x7
    27a0:      	b.ne	0x2820 <filter_char_buf_equal+0x160>
    27a4:      	mov	w22, #0x9               // =9
    27a8:      	and	w9, w22, #0xf
    27ac:      	ldr	w24, [x8, w9, uxtw #2]
    27b0:      	cmn	w24, #0x1
    27b4:      	b.ne	0x2864 <filter_char_buf_equal+0x1a4>
    27b8:      	b	0x2a0c <filter_char_buf_equal+0x34c>
    27bc:      	and	w9, w2, #0xffff
    27c0:      	cmp	w9, #0x201
    27c4:      	b.hs	0x27e0 <filter_char_buf_equal+0x120>
    27c8:      	mov	w23, #0x200             // =512
    27cc:      	sub	w9, w23, #0x100
    27d0:      	ror	w9, w9, #0x8
    27d4:      	cmp	w9, #0x2
    27d8:      	b.le	0x27fc <filter_char_buf_equal+0x13c>
    27dc:      	b	0x2794 <filter_char_buf_equal+0xd4>
    27e0:      	cmp	w9, #0x401
    27e4:      	b.hs	0x29c4 <filter_char_buf_equal+0x304>
    27e8:      	mov	w23, #0x400             // =1024
    27ec:      	sub	w9, w23, #0x100
    27f0:      	ror	w9, w9, #0x8
    27f4:      	cmp	w9, #0x2
    27f8:      	b.gt	0x2794 <filter_char_buf_equal+0xd4>
    27fc:      	cbz	w9, 0x2850 <filter_char_buf_equal+0x190>
    2800:      	cmp	w9, #0x1
    2804:      	b.ne	0x2820 <filter_char_buf_equal+0x160>
    2808:      	mov	w22, #0x7               // =7
    280c:      	and	w9, w22, #0xf
    2810:      	ldr	w24, [x8, w9, uxtw #2]
    2814:      	cmn	w24, #0x1
    2818:      	b.ne	0x2864 <filter_char_buf_equal+0x1a4>
    281c:      	b	0x2a0c <filter_char_buf_equal+0x34c>
    2820:      	mov	w22, #0xa               // =10
    2824:      	and	w9, w22, #0xf
    2828:      	ldr	w24, [x8, w9, uxtw #2]
    282c:      	cmn	w24, #0x1
    2830:      	b.ne	0x2864 <filter_char_buf_equal+0x1a4>
    2834:      	b	0x2a0c <filter_char_buf_equal+0x34c>
    2838:      	mov	w22, #0x8               // =8
    283c:      	and	w9, w22, #0xf
    2840:      	ldr	w24, [x8, w9, uxtw #2]
    2844:      	cmn	w24, #0x1
    2848:      	b.ne	0x2864 <filter_char_buf_equal+0x1a4>
    284c:      	b	0x2a0c <filter_char_buf_equal+0x34c>
    2850:      	mov	w22, #0x6               // =6
    2854:      	and	w9, w22, #0xf
    2858:      	ldr	w24, [x8, w9, uxtw #2]
    285c:      	cmn	w24, #0x1
    2860:      	b.eq	0x2a0c <filter_char_buf_equal+0x34c>
    2864:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2868:      	add	x29, sp, #0x8
    286c:      	mov	w8, #0x1                // =1
    2870:      	ldr	x0, [x0]
    2874:      	mov	x25, x1
    2878:      	add	x1, sp, #0x8
    287c:      	mov	w21, w2
    2880:      	mov	w20, #0x1               // =1
    2884:      	blr	x8
    2888:      	mov	x19, x0
    288c:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2890:      	add	x1, sp, #0x8
    2894:      	ldr	x0, [x0]
    2898:      	blr	x20
    289c:      	mov	x20, x0
    28a0:      	mov	x0, xzr
    28a4:      	cbz	x19, 0x26e4 <filter_char_buf_equal+0x24>
    28a8:      	cbz	x20, 0x26e4 <filter_char_buf_equal+0x24>
    28ac:      	mov	x0, x19
    28b0:      	cmp	w22, #0x5
    28b4:      	b.gt	0x28ec <filter_char_buf_equal+0x22c>
    28b8:      	strb	w21, [x0], #0x1
    28bc:      	mov	w29, w21
    28c0:      	mov	w8, #0x4                // =4
    28c4:      	mov	x2, x25
    28c8:      	mov	w1, w21
    28cc:      	blr	x8
    28d0:      	subs	w8, w23, w21
    28d4:      	b.ls	0x2924 <filter_char_buf_equal+0x264>
    28d8:      	add	x9, x19, x29
    28dc:      	and	w1, w8, #0xfff
    28e0:      	mov	w8, #0x4                // =4
    28e4:      	add	x0, x9, #0x1
    28e8:      	b	0x291c <filter_char_buf_equal+0x25c>
    28ec:      	strh	w21, [x0], #0x2
    28f0:      	mov	w29, w21
    28f4:      	mov	w8, #0x4                // =4
    28f8:      	mov	x2, x25
    28fc:      	mov	w1, w21
    2900:      	blr	x8
    2904:      	subs	w8, w23, w21
    2908:      	b.ls	0x2924 <filter_char_buf_equal+0x264>
    290c:      	add	x9, x19, x29
    2910:      	and	w1, w8, #0xfff
    2914:      	mov	w8, #0x4                // =4
    2918:      	add	x0, x9, #0x2
    291c:      	mov	x2, x20
    2920:      	blr	x8
    2924:      	cmp	w22, #0x4
    2928:      	str	w24, [sp, #0xc]
    292c:      	b.le	0x2964 <filter_char_buf_equal+0x2a4>
    2930:      	cmp	w22, #0x7
    2934:      	b.gt	0x2998 <filter_char_buf_equal+0x2d8>
    2938:      	cmp	w22, #0x5
    293c:      	b.eq	0x2a8c <filter_char_buf_equal+0x3cc>
    2940:      	cmp	w22, #0x6
    2944:      	b.eq	0x2a50 <filter_char_buf_equal+0x390>
    2948:      	cmp	w22, #0x7
    294c:      	b.ne	0x2a0c <filter_char_buf_equal+0x34c>
    2950:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2954:      	mov	w8, #0x1                // =1
    2958:      	add	x9, sp, #0xc
    295c:      	ldr	x0, [x0]
    2960:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2964:      	cmp	w22, #0x1
    2968:      	b.le	0x29ec <filter_char_buf_equal+0x32c>
    296c:      	cmp	w22, #0x2
    2970:      	b.eq	0x2a78 <filter_char_buf_equal+0x3b8>
    2974:      	cmp	w22, #0x3
    2978:      	b.eq	0x2a3c <filter_char_buf_equal+0x37c>
    297c:      	cmp	w22, #0x4
    2980:      	b.ne	0x2a0c <filter_char_buf_equal+0x34c>
    2984:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2988:      	mov	w8, #0x1                // =1
    298c:      	add	x9, sp, #0xc
    2990:      	ldr	x0, [x0]
    2994:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2998:      	cmp	w22, #0x8
    299c:      	b.eq	0x2aa0 <filter_char_buf_equal+0x3e0>
    29a0:      	cmp	w22, #0x9
    29a4:      	b.eq	0x2a64 <filter_char_buf_equal+0x3a4>
    29a8:      	cmp	w22, #0xa
    29ac:      	b.ne	0x2a0c <filter_char_buf_equal+0x34c>
    29b0:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    29b4:      	mov	w8, #0x1                // =1
    29b8:      	add	x9, sp, #0xc
    29bc:      	ldr	x0, [x0]
    29c0:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    29c4:      	and	w9, w2, #0xffff
    29c8:      	mov	w10, #0x1000            // =4096
    29cc:      	cmp	w9, #0x800
    29d0:      	mov	w9, #0x800              // =2048
    29d4:      	csel	w23, w10, w9, hi
    29d8:      	sub	w9, w23, #0x100
    29dc:      	ror	w9, w9, #0x8
    29e0:      	cmp	w9, #0x2
    29e4:      	b.le	0x27fc <filter_char_buf_equal+0x13c>
    29e8:      	b	0x2794 <filter_char_buf_equal+0xd4>
    29ec:      	cbz	w22, 0x2a28 <filter_char_buf_equal+0x368>
    29f0:      	cmp	w22, #0x1
    29f4:      	b.ne	0x2a0c <filter_char_buf_equal+0x34c>
    29f8:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    29fc:      	mov	w8, #0x1                // =1
    2a00:      	add	x9, sp, #0xc
    2a04:      	ldr	x0, [x0]
    2a08:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2a0c:      	mov	x0, xzr
    2a10:      	ldp	x20, x19, [sp, #0x40]
    2a14:      	ldp	x22, x21, [sp, #0x30]
    2a18:      	ldp	x24, x23, [sp, #0x20]
    2a1c:      	ldp	x30, x25, [sp, #0x10]
    2a20:      	ldr	x29, [sp], #0x50
    2a24:      	ret
    2a28:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2a2c:      	mov	w8, #0x1                // =1
    2a30:      	add	x9, sp, #0xc
    2a34:      	ldr	x0, [x0]
    2a38:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2a3c:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2a40:      	mov	w8, #0x1                // =1
    2a44:      	add	x9, sp, #0xc
    2a48:      	ldr	x0, [x0]
    2a4c:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2a50:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2a54:      	mov	w8, #0x1                // =1
    2a58:      	add	x9, sp, #0xc
    2a5c:      	ldr	x0, [x0]
    2a60:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2a64:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2a68:      	mov	w8, #0x1                // =1
    2a6c:      	add	x9, sp, #0xc
    2a70:      	ldr	x0, [x0]
    2a74:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2a78:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2a7c:      	mov	w8, #0x1                // =1
    2a80:      	add	x9, sp, #0xc
    2a84:      	ldr	x0, [x0]
    2a88:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2a8c:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2a90:      	mov	w8, #0x1                // =1
    2a94:      	add	x9, sp, #0xc
    2a98:      	ldr	x0, [x0]
    2a9c:      	b	0x2ab0 <filter_char_buf_equal+0x3f0>
    2aa0:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2aa4:      	mov	w8, #0x1                // =1
    2aa8:      	add	x9, sp, #0xc
    2aac:      	ldr	x0, [x0]
    2ab0:      	add	x1, sp, #0xc
    2ab4:      	blr	x8
    2ab8:      	cbz	x0, 0x26e4 <filter_char_buf_equal+0x24>
    2abc:      	mov	w8, #0x1                // =1
    2ac0:      	mov	x1, x19
    2ac4:      	blr	x8
    2ac8:      	cmp	x0, #0x0
    2acc:      	cset	w0, ne
    2ad0:      	ldp	x20, x19, [sp, #0x40]
    2ad4:      	ldp	x22, x21, [sp, #0x30]
    2ad8:      	ldp	x24, x23, [sp, #0x20]
    2adc:      	ldp	x30, x25, [sp, #0x10]
    2ae0:      	ldr	x29, [sp], #0x50
    2ae4:      	ret
    2ae8:      	nop
    2aec:      	nop

0000000000002af0 <filter_char_buf_prefix>:
    2af0:      	sub	sp, sp, #0x30
    2af4:      	stp	x30, x21, [sp, #0x10]
    2af8:      	stp	x20, x19, [sp, #0x20]
    2afc:      	stp	wzr, w0, [sp, #0x8]
    2b00:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2b04:      	mov	w8, #0x1                // =1
    2b08:      	add	x9, sp, #0xc
    2b0c:      	ldr	x0, [x0]
    2b10:      	mov	x19, x1
    2b14:      	add	x1, sp, #0xc
    2b18:      	mov	w20, w2
    2b1c:      	blr	x8
    2b20:      	mov	x8, x0
    2b24:      	mov	x0, xzr
    2b28:      	cbz	w20, 0x2b94 <filter_char_buf_prefix+0xa4>
    2b2c:      	cbz	x8, 0x2b94 <filter_char_buf_prefix+0xa4>
    2b30:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2b34:      	mov	x21, x8
    2b38:      	mov	w8, #0x1                // =1
    2b3c:      	ldr	x0, [x0]
    2b40:      	add	x9, sp, #0x8
    2b44:      	add	x1, sp, #0x8
    2b48:      	blr	x8
    2b4c:      	cbz	x0, 0x2b94 <filter_char_buf_prefix+0xa4>
    2b50:      	cmp	w20, #0xff
    2b54:      	mov	w8, #0xff               // =255
    2b58:      	mov	x2, x19
    2b5c:      	csel	w1, w20, w8, lo
    2b60:      	mov	x8, x0
    2b64:      	mov	x20, x0
    2b68:      	lsl	w9, w1, #3
    2b6c:      	str	w9, [x8], #0x4
    2b70:      	mov	w9, #0x4                // =4
    2b74:      	mov	x0, x8
    2b78:      	blr	x9
    2b7c:      	mov	w8, #0x1                // =1
    2b80:      	mov	x0, x21
    2b84:      	mov	x1, x20
    2b88:      	blr	x8
    2b8c:      	cmp	x0, #0x0
    2b90:      	cset	w0, ne
    2b94:      	ldp	x20, x19, [sp, #0x20]
    2b98:      	ldp	x30, x21, [sp, #0x10]
    2b9c:      	add	sp, sp, #0x30
    2ba0:      	ret
    2ba4:      	nop
    2ba8:      	nop
    2bac:      	nop

0000000000002bb0 <filter_char_buf_postfix>:
    2bb0:      	sub	sp, sp, #0x30
    2bb4:      	stp	x30, x21, [sp, #0x10]
    2bb8:      	stp	x20, x19, [sp, #0x20]
    2bbc:      	stp	wzr, w0, [sp, #0x8]
    2bc0:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2bc4:      	mov	w8, #0x1                // =1
    2bc8:      	add	x9, sp, #0xc
    2bcc:      	ldr	x0, [x0]
    2bd0:      	mov	x19, x1
    2bd4:      	add	x1, sp, #0xc
    2bd8:      	mov	w20, w2
    2bdc:      	blr	x8
    2be0:      	mov	x8, x0
    2be4:      	mov	x0, xzr
    2be8:      	cbz	w20, 0x2c7c <filter_char_buf_postfix+0xcc>
    2bec:      	cbz	x8, 0x2c7c <filter_char_buf_postfix+0xcc>
    2bf0:      	adrp	x0, 0x2000 <filter_file_buf+0x50>
    2bf4:      	mov	x21, x8
    2bf8:      	mov	w8, #0x1                // =1
    2bfc:      	ldr	x0, [x0]
    2c00:      	add	x9, sp, #0x8
    2c04:      	add	x1, sp, #0x8
    2c08:      	blr	x8
    2c0c:      	cbz	x0, 0x2c7c <filter_char_buf_postfix+0xcc>
    2c10:      	cmp	w20, #0x7f
    2c14:      	mov	w9, #0x7f               // =127
    2c18:      	mov	x1, x0
    2c1c:      	mov	x8, xzr
    2c20:      	sub	w10, w20, #0x1
    2c24:      	csel	w9, w20, w9, lo
    2c28:      	lsl	w9, w9, #3
    2c2c:      	str	w9, [x0]
    2c30:      	mov	w9, w20
    2c34:      	nop
    2c38:      	nop
    2c3c:      	nop
    2c40:      	cmp	x8, #0x7f
    2c44:      	b.eq	0x2c68 <filter_char_buf_postfix+0xb8>
    2c48:      	and	x11, x10, #0xfff
    2c4c:      	add	x12, x1, x8
    2c50:      	add	x8, x8, #0x1
    2c54:      	ldrb	w11, [x19, x11]
    2c58:      	sub	w10, w10, #0x1
    2c5c:      	cmp	x9, x8
    2c60:      	strb	w11, [x12, #0x4]
    2c64:      	b.ne	0x2c40 <filter_char_buf_postfix+0x90>
    2c68:      	mov	w8, #0x1                // =1
    2c6c:      	mov	x0, x21
    2c70:      	blr	x8
    2c74:      	cmp	x0, #0x0
    2c78:      	cset	w0, ne
    2c7c:      	ldp	x20, x19, [sp, #0x20]
    2c80:      	ldp	x30, x21, [sp, #0x10]
    2c84:      	add	sp, sp, #0x30
    2c88:      	ret
    2c8c:      	nop

0000000000002c90 <filter_file_type>:
    2c90:      	sub	sp, sp, #0x20
    2c94:      	stp	x30, x19, [sp, #0x10]
    2c98:      	ldr	w8, [x1]
    2c9c:      	strh	wzr, [sp, #0xc]
    2ca0:      	cmp	w8, #0x1, lsl #12       // =0x1000
    2ca4:      	b.hi	0x2d7c <filter_file_type+0xec>
    2ca8:      	add	x9, x1, #0x4
    2cac:      	mov	w10, #0x2               // =2
    2cb0:      	mov	w11, #0x4               // =4
    2cb4:      	add	x12, sp, #0xc
    2cb8:      	mov	x19, x0
    2cbc:      	add	x0, sp, #0xc
    2cc0:      	add	x8, x9, x8
    2cc4:      	add	x8, x8, #0x4
    2cc8:      	ldr	w8, [x1]
    2ccc:      	mov	w1, #0x2                // =2
    2cd0:      	add	x8, x9, x8
    2cd4:      	add	x2, x8, #0x4
    2cd8:      	blr	x11
    2cdc:      	ldr	w9, [x19, #0x10]
    2ce0:      	cbz	w9, 0x2d7c <filter_file_type+0xec>
    2ce4:      	ldrh	w8, [sp, #0xc]
    2ce8:      	and	w8, w8, #0xf000
    2cec:      	cmp	w9, w8
    2cf0:      	b.ne	0x2d04 <filter_file_type+0x74>
    2cf4:      	mov	w0, #0x1                // =1
    2cf8:      	ldp	x30, x19, [sp, #0x10]
    2cfc:      	add	sp, sp, #0x20
    2d00:      	ret
    2d04:      	ldr	w9, [x19, #0x8]
    2d08:      	cmp	w9, #0xc
    2d0c:      	b.ls	0x2d7c <filter_file_type+0xec>
    2d10:      	ldr	w10, [x19, #0x14]
    2d14:      	cbz	w10, 0x2d7c <filter_file_type+0xec>
    2d18:      	cmp	w10, w8
    2d1c:      	b.ne	0x2d30 <filter_file_type+0xa0>
    2d20:      	mov	w0, #0x1                // =1
    2d24:      	ldp	x30, x19, [sp, #0x10]
    2d28:      	add	sp, sp, #0x20
    2d2c:      	ret
    2d30:      	cmp	w9, #0x11
    2d34:      	b.lo	0x2d7c <filter_file_type+0xec>
    2d38:      	ldr	w10, [x19, #0x18]
    2d3c:      	cbz	w10, 0x2d7c <filter_file_type+0xec>
    2d40:      	cmp	w10, w8
    2d44:      	b.ne	0x2d58 <filter_file_type+0xc8>
    2d48:      	mov	w0, #0x1                // =1
    2d4c:      	ldp	x30, x19, [sp, #0x10]
    2d50:      	add	sp, sp, #0x20
    2d54:      	ret
    2d58:      	cmp	w9, #0x15
    2d5c:      	b.lo	0x2d7c <filter_file_type+0xec>
    2d60:      	ldr	w9, [x19, #0x1c]
    2d64:      	cbz	w9, 0x2d7c <filter_file_type+0xec>
    2d68:      	cmp	w9, w8
    2d6c:      	cset	w0, eq
    2d70:      	ldp	x30, x19, [sp, #0x10]
    2d74:      	add	sp, sp, #0x20
    2d78:      	ret
    2d7c:      	mov	x0, xzr
    2d80:      	ldp	x30, x19, [sp, #0x10]
    2d84:      	add	sp, sp, #0x20
    2d88:      	ret
    2d8c:      	nop

0000000000002d90 <filter_char_substring>:
    2d90:      	str	x29, [sp, #-0x50]!
    2d94:      	stp	x30, x25, [sp, #0x10]
    2d98:      	stp	x24, x23, [sp, #0x20]
    2d9c:      	stp	x22, x21, [sp, #0x30]
    2da0:      	stp	x20, x19, [sp, #0x40]
    2da4:      	mov	x21, x1
    2da8:      	mov	x19, x0
    2dac:      	add	x23, x0, #0x10
    2db0:      	mov	w24, w2
    2db4:      	tbz	w3, #0x0, 0x2ea8 <filter_char_substring+0x118>
    2db8:      	cbz	w2, 0x2f68 <filter_char_substring+0x1d8>
    2dbc:      	adrp	x22, 0x2000 <filter_file_buf+0x50>
    2dc0:      	mov	x25, xzr
    2dc4:      	mov	w29, wzr
    2dc8:      	ldr	x22, [x22]
    2dcc:      	add	x20, sp, #0xc
    2dd0:      	nop
    2dd4:      	nop
    2dd8:      	nop
    2ddc:      	nop
    2de0:      	ldr	w8, [x23, x25, lsl #2]
    2de4:      	add	x1, sp, #0xc
    2de8:      	mov	x0, x22
    2dec:      	str	w8, [sp, #0xc]
    2df0:      	mov	w8, #0x1                // =1
    2df4:      	blr	x8
    2df8:      	cbz	x0, 0x3008 <filter_char_substring+0x278>
    2dfc:      	mov	x8, xzr
    2e00:      	mov	x9, x21
    2e04:      	mov	x10, x24
    2e08:      	b	0x2e20 <filter_char_substring+0x90>
    2e0c:      	add	x8, x8, #0x1
    2e10:      	sub	x10, x10, #0x1
    2e14:      	add	x9, x9, #0x1
    2e18:      	cmp	x8, x24
    2e1c:      	b.eq	0x2e84 <filter_char_substring+0xf4>
    2e20:      	mov	x11, xzr
    2e24:      	cmp	x10, x11
    2e28:      	b.eq	0x2e0c <filter_char_substring+0x7c>
    2e2c:      	ldrb	w12, [x0, x11]
    2e30:      	cbz	w12, 0x2e80 <filter_char_substring+0xf0>
    2e34:      	ldrb	w13, [x9, x11]
    2e38:      	sub	w14, w13, #0x41
    2e3c:      	orr	w15, w13, #0x20
    2e40:      	cmp	w14, #0x1a
    2e44:      	sub	w14, w12, #0x41
    2e48:      	csel	w13, w15, w13, lo
    2e4c:      	orr	w15, w12, #0x20
    2e50:      	cmp	w14, #0x1a
    2e54:      	csel	w12, w15, w12, lo
    2e58:      	cmp	x11, #0x62
    2e5c:      	b.hi	0x2e0c <filter_char_substring+0x7c>
    2e60:      	add	x11, x11, #0x1
    2e64:      	cmp	w13, w12
    2e68:      	b.eq	0x2e24 <filter_char_substring+0x94>
    2e6c:      	b	0x2e0c <filter_char_substring+0x7c>
    2e70:      	nop
    2e74:      	nop
    2e78:      	nop
    2e7c:      	nop
    2e80:      	tbz	w8, #0x1f, 0x3020 <filter_char_substring+0x290>
    2e84:      	ldr	w9, [x19, #0x8]
    2e88:      	add	w8, w29, #0xc
    2e8c:      	cmp	w8, w9
    2e90:      	b.hs	0x3004 <filter_char_substring+0x274>
    2e94:      	add	x25, x25, #0x1
    2e98:      	add	w29, w29, #0x4
    2e9c:      	cmp	x25, #0x64
    2ea0:      	b.ne	0x2de0 <filter_char_substring+0x50>
    2ea4:      	b	0x3004 <filter_char_substring+0x274>
    2ea8:      	cbz	w2, 0x2fbc <filter_char_substring+0x22c>
    2eac:      	adrp	x22, 0x2000 <filter_file_buf+0x50>
    2eb0:      	mov	x25, xzr
    2eb4:      	mov	w29, wzr
    2eb8:      	ldr	x22, [x22]
    2ebc:      	add	x20, sp, #0xc
    2ec0:      	ldr	w8, [x23, x25, lsl #2]
    2ec4:      	add	x1, sp, #0xc
    2ec8:      	mov	x0, x22
    2ecc:      	str	w8, [sp, #0xc]
    2ed0:      	mov	w8, #0x1                // =1
    2ed4:      	blr	x8
    2ed8:      	cbz	x0, 0x3008 <filter_char_substring+0x278>
    2edc:      	mov	x8, xzr
    2ee0:      	mov	x9, x21
    2ee4:      	mov	x10, x24
    2ee8:      	b	0x2f00 <filter_char_substring+0x170>
    2eec:      	add	x8, x8, #0x1
    2ef0:      	sub	x10, x10, #0x1
    2ef4:      	add	x9, x9, #0x1
    2ef8:      	cmp	x8, x24
    2efc:      	b.eq	0x2f44 <filter_char_substring+0x1b4>
    2f00:      	mov	x11, xzr
    2f04:      	cmp	x10, x11
    2f08:      	b.eq	0x2eec <filter_char_substring+0x15c>
    2f0c:      	ldrb	w12, [x0, x11]
    2f10:      	cbz	w12, 0x2f40 <filter_char_substring+0x1b0>
    2f14:      	cmp	x11, #0x62
    2f18:      	b.hi	0x2eec <filter_char_substring+0x15c>
    2f1c:      	ldrb	w13, [x9, x11]
    2f20:      	add	x11, x11, #0x1
    2f24:      	cmp	w13, w12
    2f28:      	b.eq	0x2f04 <filter_char_substring+0x174>
    2f2c:      	b	0x2eec <filter_char_substring+0x15c>
    2f30:      	nop
    2f34:      	nop
    2f38:      	nop
    2f3c:      	nop
    2f40:      	tbz	w8, #0x1f, 0x3020 <filter_char_substring+0x290>
    2f44:      	ldr	w9, [x19, #0x8]
    2f48:      	add	w8, w29, #0xc
    2f4c:      	cmp	w8, w9
    2f50:      	b.hs	0x3004 <filter_char_substring+0x274>
    2f54:      	add	x25, x25, #0x1
    2f58:      	add	w29, w29, #0x4
    2f5c:      	cmp	x25, #0x64
    2f60:      	b.ne	0x2ec0 <filter_char_substring+0x130>
    2f64:      	b	0x3004 <filter_char_substring+0x274>
    2f68:      	adrp	x20, 0x2000 <filter_file_buf+0x50>
    2f6c:      	mov	w21, #0x10              // =16
    2f70:      	add	x22, sp, #0xc
    2f74:      	ldr	x20, [x20]
    2f78:      	nop
    2f7c:      	nop
    2f80:      	ldr	w8, [x19, x21]
    2f84:      	add	x1, sp, #0xc
    2f88:      	mov	x0, x20
    2f8c:      	str	w8, [sp, #0xc]
    2f90:      	mov	w8, #0x1                // =1
    2f94:      	blr	x8
    2f98:      	cbz	x0, 0x3008 <filter_char_substring+0x278>
    2f9c:      	ldr	w8, [x19, #0x8]
    2fa0:      	add	x21, x21, #0x4
    2fa4:      	sub	w9, w21, #0x8
    2fa8:      	cmp	w9, w8
    2fac:      	b.hs	0x3004 <filter_char_substring+0x274>
    2fb0:      	cmp	x21, #0x1a0
    2fb4:      	b.ne	0x2f80 <filter_char_substring+0x1f0>
    2fb8:      	b	0x3004 <filter_char_substring+0x274>
    2fbc:      	adrp	x20, 0x2000 <filter_file_buf+0x50>
    2fc0:      	mov	w21, #0x10              // =16
    2fc4:      	add	x22, sp, #0xc
    2fc8:      	ldr	x20, [x20]
    2fcc:      	ldr	w8, [x19, x21]
    2fd0:      	add	x1, sp, #0xc
    2fd4:      	mov	x0, x20
    2fd8:      	str	w8, [sp, #0xc]
    2fdc:      	mov	w8, #0x1                // =1
    2fe0:      	blr	x8
    2fe4:      	cbz	x0, 0x3008 <filter_char_substring+0x278>
    2fe8:      	ldr	w8, [x19, #0x8]
    2fec:      	add	x21, x21, #0x4
    2ff0:      	sub	w9, w21, #0x8
    2ff4:      	cmp	w9, w8
    2ff8:      	b.hs	0x3004 <filter_char_substring+0x274>
    2ffc:      	cmp	x21, #0x1a0
    3000:      	b.ne	0x2fcc <filter_char_substring+0x23c>
    3004:      	mov	x0, xzr
    3008:      	ldp	x20, x19, [sp, #0x40]
    300c:      	ldp	x22, x21, [sp, #0x30]
    3010:      	ldp	x24, x23, [sp, #0x20]
    3014:      	ldp	x30, x25, [sp, #0x10]
    3018:      	ldr	x29, [sp], #0x50
    301c:      	ret
    3020:      	mov	w0, #0x1                // =1
    3024:      	ldp	x20, x19, [sp, #0x40]
    3028:      	ldp	x22, x21, [sp, #0x30]
    302c:      	ldp	x24, x23, [sp, #0x20]
    3030:      	ldp	x30, x25, [sp, #0x10]
    3034:      	ldr	x29, [sp], #0x50
    3038:      	ret
    303c:      	nop

0000000000003040 <do_action>:
    3040:      	sub	sp, sp, #0xc0
    3044:      	str	x29, [sp, #0x70]
    3048:      	stp	x30, x25, [sp, #0x80]
    304c:      	stp	x24, x23, [sp, #0x90]
    3050:      	stp	x22, x21, [sp, #0xa0]
    3054:      	stp	x20, x19, [sp, #0xb0]
    3058:      	add	x8, x2, w1, uxtw #2
    305c:      	str	wzr, [sp, #0x44]
    3060:      	adrp	x24, 0x3000 <filter_char_substring+0x270>
    3064:      	add	x9, sp, #0x44
    3068:      	mov	w19, w1
    306c:      	ldrsw	x22, [x8, #0x4]
    3070:      	ldr	x24, [x24]
    3074:      	mov	w8, #0x1                // =1
    3078:      	mov	x20, x0
    307c:      	add	x1, sp, #0x44
    3080:      	mov	w25, w4
    3084:      	mov	x23, x3
    3088:      	mov	x21, x2
    308c:      	mov	x0, x24
    3090:      	blr	x8
    3094:      	cbz	x0, 0x3538 <do_action+0x4f8>
    3098:      	mov	x29, x0
    309c:      	cmp	w22, #0x7
    30a0:      	b.gt	0x30c4 <do_action+0x84>
    30a4:      	cmp	w22, #0x3
    30a8:      	b.gt	0x310c <do_action+0xcc>
    30ac:      	cmp	w22, #0x1
    30b0:      	b.gt	0x3238 <do_action+0x1f8>
    30b4:      	cbz	w22, 0x3428 <do_action+0x3e8>
    30b8:      	cmp	w22, #0x1
    30bc:      	b.eq	0x3248 <do_action+0x208>
    30c0:      	b	0x3530 <do_action+0x4f0>
    30c4:      	cmp	w22, #0xb
    30c8:      	b.gt	0x3210 <do_action+0x1d0>
    30cc:      	sub	w8, w22, #0xa
    30d0:      	cmp	w8, #0x2
    30d4:      	b.lo	0x3338 <do_action+0x2f8>
    30d8:      	cmp	w22, #0x8
    30dc:      	b.eq	0x3384 <do_action+0x344>
    30e0:      	cmp	w22, #0x9
    30e4:      	b.ne	0x3530 <do_action+0x4f0>
    30e8:      	add	w19, w19, #0x1
    30ec:      	add	x8, x21, w19, uxtw #2
    30f0:      	ldr	w0, [x8, #0x4]
    30f4:      	tbz	w25, #0x0, 0x34d4 <do_action+0x494>
    30f8:      	sxtw	x8, w0
    30fc:      	mov	w9, #0x6d               // =109
    3100:      	blr	x9
    3104:      	mov	w20, #0x2               // =2
    3108:      	b	0x34ec <do_action+0x4ac>
    310c:      	sub	w8, w22, #0x6
    3110:      	cmp	w8, #0x2
    3114:      	b.lo	0x3370 <do_action+0x330>
    3118:      	cmp	w22, #0x4
    311c:      	b.eq	0x338c <do_action+0x34c>
    3120:      	cmp	w22, #0x5
    3124:      	b.ne	0x3530 <do_action+0x4f0>
    3128:      	add	w9, w19, #0x1
    312c:      	add	x8, x21, #0x4
    3130:      	add	w19, w19, #0x2
    3134:      	ldr	w9, [x8, w9, uxtw #2]
    3138:      	and	x9, x9, #0x7
    313c:      	cmp	w9, #0x4
    3140:      	b.hi	0x3530 <do_action+0x4f0>
    3144:      	add	x10, x29, x9, lsl #2
    3148:      	mov	w11, #0x5ea0            // =24224
    314c:      	ldr	w10, [x10, x11]
    3150:      	cbnz	w10, 0x3530 <do_action+0x4f0>
    3154:      	ldr	w20, [x8, w19, uxtw #2]
    3158:      	add	x8, x29, x9, lsl #3
    315c:      	ldr	x8, [x8, #0x5e78]
    3160:      	str	wzr, [sp, #0x54]
    3164:      	and	x8, x8, #0x7ff
    3168:      	add	x8, x29, x8
    316c:      	ldr	w8, [x8, #0x90]
    3170:      	str	w8, [sp, #0x50]
    3174:      	mov	w8, #0xe                // =14
    3178:      	blr	x8
    317c:      	lsr	x8, x0, #32
    3180:      	adrp	x21, 0x3000 <filter_char_substring+0x270>
    3184:      	add	x9, sp, #0x48
    3188:      	str	x8, [sp, #0x48]
    318c:      	mov	w8, #0x1                // =1
    3190:      	add	x1, sp, #0x48
    3194:      	ldr	x21, [x21]
    3198:      	mov	x0, x21
    319c:      	blr	x8
    31a0:      	cbz	x0, 0x3530 <do_action+0x4f0>
    31a4:      	and	x8, x20, #0x7
    31a8:      	cmp	w8, #0x4
    31ac:      	b.hi	0x3530 <do_action+0x4f0>
    31b0:      	add	x9, x29, x8, lsl #2
    31b4:      	mov	w10, #0x5ea0            // =24224
    31b8:      	ldr	w9, [x9, x10]
    31bc:      	cbnz	w9, 0x3530 <do_action+0x4f0>
    31c0:      	add	x8, x29, x8, lsl #3
    31c4:      	mov	x23, x0
    31c8:      	ldr	x8, [x8, #0x5e78]
    31cc:      	str	wzr, [sp, #0x54]
    31d0:      	and	x8, x8, #0x7ff
    31d4:      	add	x8, x29, x8
    31d8:      	ldr	w8, [x8, #0x90]
    31dc:      	str	w8, [sp, #0x50]
    31e0:      	mov	w8, #0xe                // =14
    31e4:      	blr	x8
    31e8:      	lsr	x8, x0, #32
    31ec:      	mov	x3, xzr
    31f0:      	add	x9, sp, #0x48
    31f4:      	str	x8, [sp, #0x48]
    31f8:      	mov	w8, #0x2                // =2
    31fc:      	add	x1, sp, #0x48
    3200:      	mov	x0, x21
    3204:      	mov	x2, x23
    3208:      	blr	x8
    320c:      	b	0x3530 <do_action+0x4f0>
    3210:      	cmp	w22, #0xc
    3214:      	b.eq	0x34dc <do_action+0x49c>
    3218:      	cmp	w22, #0xd
    321c:      	b.eq	0x339c <do_action+0x35c>
    3220:      	cmp	w22, #0xe
    3224:      	b.ne	0x3530 <do_action+0x4f0>
    3228:      	tst	w25, #0x1
    322c:      	mov	w8, #0x8                // =8
    3230:      	add	w19, w19, #0x2
    3234:      	b	0x34e8 <do_action+0x4a8>
    3238:      	cmp	w22, #0x2
    323c:      	b.eq	0x34cc <do_action+0x48c>
    3240:      	cmp	w22, #0x3
    3244:      	b.ne	0x3530 <do_action+0x4f0>
    3248:      	add	w8, w19, #0x1
    324c:      	add	x9, x21, #0x4
    3250:      	add	w19, w19, #0x2
    3254:      	str	wzr, [sp, #0x58]
    3258:      	ldr	w21, [x9, w8, uxtw #2]
    325c:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    3260:      	ldr	w20, [x9, w19, uxtw #2]
    3264:      	ldr	x0, [x0]
    3268:      	mov	w8, #0x1                // =1
    326c:      	add	x9, sp, #0x58
    3270:      	add	x1, sp, #0x58
    3274:      	blr	x8
    3278:      	cbz	x0, 0x3364 <do_action+0x324>
    327c:      	and	x8, x21, #0x7
    3280:      	cmp	w8, #0x4
    3284:      	b.hi	0x3360 <do_action+0x320>
    3288:      	add	x9, x29, x8, lsl #2
    328c:      	mov	w10, #0x5ea0            // =24224
    3290:      	ldr	w9, [x9, x10]
    3294:      	cbnz	w9, 0x3360 <do_action+0x320>
    3298:      	add	x8, x29, x8, lsl #3
    329c:      	mov	x21, x0
    32a0:      	ldr	x8, [x8, #0x5e78]
    32a4:      	str	wzr, [sp, #0x54]
    32a8:      	and	x8, x8, #0x7ff
    32ac:      	add	x8, x29, x8
    32b0:      	ldr	w8, [x8, #0x90]
    32b4:      	str	w8, [sp, #0x50]
    32b8:      	mov	w8, #0xe                // =14
    32bc:      	blr	x8
    32c0:      	lsr	x8, x0, #32
    32c4:      	cmp	w22, #0x1
    32c8:      	str	x8, [sp, #0x48]
    32cc:      	b.ne	0x365c <do_action+0x61c>
    32d0:      	and	x8, x20, #0x7
    32d4:      	cmp	w8, #0x4
    32d8:      	b.hi	0x3360 <do_action+0x320>
    32dc:      	add	x9, x29, x8, lsl #2
    32e0:      	mov	w10, #0x5ea0            // =24224
    32e4:      	ldr	w9, [x9, x10]
    32e8:      	cbnz	w9, 0x3360 <do_action+0x320>
    32ec:      	add	x8, x29, x8, lsl #3
    32f0:      	mov	x0, x21
    32f4:      	ldr	x8, [x8, #0x5e78]
    32f8:      	and	x8, x8, #0x7ff
    32fc:      	add	x2, x29, x8
    3300:      	ldr	w8, [x2, #0x90]!
    3304:      	and	x8, x8, #0xfff
    3308:      	add	x1, x8, #0x8
    330c:      	mov	w8, #0x4                // =4
    3310:      	blr	x8
    3314:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    3318:      	mov	x3, xzr
    331c:      	mov	w8, #0x2                // =2
    3320:      	ldr	x0, [x0]
    3324:      	add	x9, sp, #0x48
    3328:      	add	x1, sp, #0x48
    332c:      	mov	x2, x21
    3330:      	blr	x8
    3334:      	b	0x3360 <do_action+0x320>
    3338:      	add	w19, w19, #0x1
    333c:      	add	x8, x21, w19, uxtw #2
    3340:      	ldr	w8, [x8, #0x4]
    3344:      	and	x8, x8, #0x7
    3348:      	cmp	w8, #0x4
    334c:      	b.hi	0x3360 <do_action+0x320>
    3350:      	add	x9, x29, x8, lsl #2
    3354:      	mov	w10, #0x5ea0            // =24224
    3358:      	ldr	w9, [x9, x10]
    335c:      	cbz	w9, 0x3554 <do_action+0x514>
    3360:      	mov	w0, wzr
    3364:      	cbz	w0, 0x3530 <do_action+0x4f0>
    3368:      	mov	w0, wzr
    336c:      	b	0x3538 <do_action+0x4f8>
    3370:      	add	w19, w19, #0x1
    3374:      	add	x8, x21, w19, uxtw #2
    3378:      	ldr	w8, [x8, #0x4]
    337c:      	str	w8, [x29, #0x78]
    3380:      	b	0x3530 <do_action+0x4f0>
    3384:      	strb	wzr, [x23]
    3388:      	b	0x3530 <do_action+0x4f0>
    338c:      	tst	w25, #0x1
    3390:      	mov	w8, #0x4                // =4
    3394:      	add	w19, w19, #0x1
    3398:      	b	0x34e8 <do_action+0x4a8>
    339c:      	mov	w8, #0xe                // =14
    33a0:      	blr	x8
    33a4:      	str	x0, [sp, #0x68]
    33a8:      	adrp	x21, 0x3000 <filter_char_substring+0x270>
    33ac:      	add	x8, sp, #0x68
    33b0:      	mov	w9, #0x1                // =1
    33b4:      	ldr	x21, [x21]
    33b8:      	add	x1, sp, #0x68
    33bc:      	mov	w20, #0x1               // =1
    33c0:      	mov	x0, x21
    33c4:      	blr	x9
    33c8:      	cbz	x0, 0x3530 <do_action+0x4f0>
    33cc:      	ldur	x8, [x0, #0x4]
    33d0:      	adrp	x25, 0x3000 <filter_char_substring+0x270>
    33d4:      	mov	w9, #0x1                // =1
    33d8:      	add	x1, sp, #0x58
    33dc:      	str	x8, [sp, #0x58]
    33e0:      	mov	w8, #0x2                // =2
    33e4:      	str	w8, [sp, #0x60]
    33e8:      	add	x8, sp, #0x58
    33ec:      	ldr	x25, [x25]
    33f0:      	mov	x0, x25
    33f4:      	blr	x9
    33f8:      	str	w20, [sp, #0x78]
    33fc:      	cbz	x0, 0x35e0 <do_action+0x5a0>
    3400:      	ldaxr	w8, [x0]
    3404:      	add	w8, w8, #0x1
    3408:      	stlxr	w9, w8, [x0]
    340c:      	cbnz	w9, 0x3400 <do_action+0x3c0>
    3410:      	mov	w8, #0x3                // =3
    3414:      	add	x9, sp, #0x68
    3418:      	add	x1, sp, #0x68
    341c:      	mov	x0, x21
    3420:      	blr	x8
    3424:      	b	0x3530 <do_action+0x4f0>
    3428:      	add	w8, w19, #0x1
    342c:      	add	x9, x21, #0x4
    3430:      	str	x20, [sp, #0x30]
    3434:      	ldr	w25, [x9, w8, uxtw #2]
    3438:      	add	w8, w19, #0x2
    343c:      	ldr	w20, [x9, w8, uxtw #2]
    3440:      	mov	w8, #0x7d               // =125
    3444:      	blr	x8
    3448:      	str	x0, [sp, #0x8]
    344c:      	str	x0, [sp, #0x48]
    3450:      	str	wzr, [sp, #0x68]
    3454:      	cbz	w25, 0x3888 <do_action+0x848>
    3458:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    345c:      	mov	w8, #0x1                // =1
    3460:      	add	x9, sp, #0x68
    3464:      	ldr	x0, [x0]
    3468:      	add	x1, sp, #0x68
    346c:      	blr	x8
    3470:      	cbz	x0, 0x3888 <do_action+0x848>
    3474:      	mov	x10, x0
    3478:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    347c:      	mov	w8, #0x1                // =1
    3480:      	ldr	x0, [x0]
    3484:      	add	x9, sp, #0x68
    3488:      	add	x1, sp, #0x68
    348c:      	str	x10, [sp, #0x10]
    3490:      	blr	x8
    3494:      	ldr	x9, [sp, #0x10]
    3498:      	ldr	x8, [x29, #0x60]
    349c:      	mov	x2, x0
    34a0:      	cmp	w20, #0x2
    34a4:      	str	x8, [x9]
    34a8:      	ldr	x8, [x29, #0x70]
    34ac:      	str	x8, [x9, #0x8]
    34b0:      	b.eq	0x36a0 <do_action+0x660>
    34b4:      	cmp	w20, #0x1
    34b8:      	b.eq	0x3694 <do_action+0x654>
    34bc:      	cbnz	w20, 0x3888 <do_action+0x848>
    34c0:      	ldr	w8, [x29, #0x7c]
    34c4:      	str	x25, [sp]
    34c8:      	b	0x36a8 <do_action+0x668>
    34cc:      	mov	w0, #0x9                // =9
    34d0:      	tbnz	w25, #0x0, 0x30f8 <do_action+0xb8>
    34d4:      	mov	w20, #0x3               // =3
    34d8:      	b	0x34ec <do_action+0x4ac>
    34dc:      	tst	w25, #0x1
    34e0:      	mov	w8, #0x6                // =6
    34e4:      	add	w19, w19, #0x3
    34e8:      	cinc	x20, x8, eq
    34ec:      	str	wzr, [sp, #0x48]
    34f0:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    34f4:      	mov	w8, #0x1                // =1
    34f8:      	add	x9, sp, #0x48
    34fc:      	ldr	x0, [x0]
    3500:      	add	x1, sp, #0x48
    3504:      	blr	x8
    3508:      	cbz	x0, 0x3530 <do_action+0x4f0>
    350c:      	add	x8, x0, x20, lsl #3
    3510:      	nop
    3514:      	nop
    3518:      	nop
    351c:      	nop
    3520:      	ldaxr	x9, [x8]
    3524:      	add	x9, x9, #0x1
    3528:      	stlxr	w10, x9, [x8]
    352c:      	cbnz	w10, 0x3520 <do_action+0x4e0>
    3530:      	add	w0, w19, #0x1
    3534:      	str	x22, [x29, #0x70]
    3538:      	ldp	x20, x19, [sp, #0xb0]
    353c:      	ldr	x29, [sp, #0x70]
    3540:      	ldp	x22, x21, [sp, #0xa0]
    3544:      	ldp	x24, x23, [sp, #0x90]
    3548:      	ldp	x30, x25, [sp, #0x80]
    354c:      	add	sp, sp, #0xc0
    3550:      	ret
    3554:      	add	x8, x29, x8, lsl #3
    3558:      	ldr	x8, [x8, #0x5e78]
    355c:      	and	x8, x8, #0x7ff
    3560:      	add	x8, x29, x8
    3564:      	ldr	x8, [x8, #0xb8]
    3568:      	str	x8, [sp, #0x58]
    356c:      	cbz	x8, 0x3360 <do_action+0x320>
    3570:      	cmp	w22, #0xa
    3574:      	b.ne	0x3678 <do_action+0x638>
    3578:      	mov	w8, #0xe                // =14
    357c:      	blr	x8
    3580:      	lsr	x8, x0, #32
    3584:      	mov	x21, x0
    3588:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    358c:      	str	w8, [sp, #0x48]
    3590:      	mov	w8, #0x1                // =1
    3594:      	add	x9, sp, #0x48
    3598:      	add	x1, sp, #0x48
    359c:      	ldr	x0, [x0]
    35a0:      	blr	x8
    35a4:      	cbz	x0, 0x3364 <do_action+0x324>
    35a8:      	ldr	w8, [x0]
    35ac:      	mov	x3, xzr
    35b0:      	add	x9, sp, #0x58
    35b4:      	add	x10, sp, #0x48
    35b8:      	stp	w8, w21, [sp, #0x48]
    35bc:      	ldr	x8, [x0, #0x8]
    35c0:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    35c4:      	add	x1, sp, #0x58
    35c8:      	add	x2, sp, #0x48
    35cc:      	str	x8, [sp, #0x50]
    35d0:      	mov	w8, #0x2                // =2
    35d4:      	ldr	x0, [x0]
    35d8:      	blr	x8
    35dc:      	b	0x3360 <do_action+0x320>
    35e0:      	mov	w8, #0x1                // =1
    35e4:      	mov	w9, #0x2                // =2
    35e8:      	add	x10, sp, #0x58
    35ec:      	add	x11, sp, #0x78
    35f0:      	add	x1, sp, #0x58
    35f4:      	add	x2, sp, #0x78
    35f8:      	mov	x0, x25
    35fc:      	mov	w3, #0x1                // =1
    3600:      	blr	x9
    3604:      	cbz	x0, 0x3410 <do_action+0x3d0>
    3608:      	mov	x23, x0
    360c:      	adrp	x24, 0x3000 <filter_char_substring+0x270>
    3610:      	mov	w9, #0x1                // =1
    3614:      	add	x1, sp, #0x48
    3618:      	mov	w20, #0x1               // =1
    361c:      	neg	w8, w23
    3620:      	strh	w8, [sp, #0x48]
    3624:      	mov	w8, #0x3                // =3
    3628:      	strh	w8, [sp, #0x4a]
    362c:      	mov	x8, #0x3b               // =59
    3630:      	movk	x8, #0x2, lsl #32
    3634:      	stur	x8, [sp, #0x4c]
    3638:      	add	x8, sp, #0x48
    363c:      	ldr	x24, [x24]
    3640:      	mov	x0, x24
    3644:      	blr	x9
    3648:      	cbz	x0, 0x3920 <do_action+0x8e0>
    364c:      	ldr	w8, [x0]
    3650:      	add	w8, w8, #0x1
    3654:      	str	w8, [x0]
    3658:      	b	0x3944 <do_action+0x904>
    365c:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    3660:      	mov	w8, #0x3                // =3
    3664:      	add	x9, sp, #0x48
    3668:      	ldr	x0, [x0]
    366c:      	add	x1, sp, #0x48
    3670:      	blr	x8
    3674:      	b	0x3364 <do_action+0x324>
    3678:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    367c:      	mov	w8, #0x3                // =3
    3680:      	add	x9, sp, #0x58
    3684:      	ldr	x0, [x0]
    3688:      	add	x1, sp, #0x58
    368c:      	blr	x8
    3690:      	b	0x3364 <do_action+0x324>
    3694:      	ldr	w8, [x29, #0x10]
    3698:      	str	x25, [sp]
    369c:      	b	0x36a8 <do_action+0x668>
    36a0:      	str	x25, [sp]
    36a4:      	mov	w8, wzr
    36a8:      	mov	w8, w8
    36ac:      	add	x0, x9, #0x18
    36b0:      	mov	w1, #0xc8               // =200
    36b4:      	str	x8, [x9, #0x10]
    36b8:      	mov	w8, #0xc8               // =200
    36bc:      	mov	w9, #0x4                // =4
    36c0:      	str	x0, [sp, #0x18]
    36c4:      	blr	x9
    36c8:      	ldr	x20, [sp, #0x30]
    36cc:      	mov	w8, #0x5e78             // =24184
    36d0:      	mov	x25, xzr
    36d4:      	str	wzr, [sp, #0x2c]
    36d8:      	add	x10, x29, x8
    36dc:      	str	x23, [sp, #0x20]
    36e0:      	b	0x36f4 <do_action+0x6b4>
    36e4:      	add	x25, x25, #0x4
    36e8:      	add	x10, x10, #0x8
    36ec:      	cmp	x25, #0x14
    36f0:      	b.eq	0x382c <do_action+0x7ec>
    36f4:      	str	x10, [sp, #0x38]
    36f8:      	str	wzr, [sp, #0x58]
    36fc:      	mov	w8, #0x1                // =1
    3700:      	add	x9, sp, #0x58
    3704:      	add	x1, sp, #0x58
    3708:      	mov	x0, x24
    370c:      	blr	x8
    3710:      	cbz	x0, 0x382c <do_action+0x7ec>
    3714:      	mov	w8, #0x5ef8             // =24312
    3718:      	add	x1, x0, x8
    371c:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    3720:      	mov	w8, #0x1                // =1
    3724:      	ldr	x0, [x0]
    3728:      	blr	x8
    372c:      	cbz	x0, 0x382c <do_action+0x7ec>
    3730:      	add	x8, x0, x25
    3734:      	ldr	x10, [sp, #0x38]
    3738:      	ldr	w8, [x8, #0x40]
    373c:      	cmn	w8, #0x1
    3740:      	b.eq	0x382c <do_action+0x7ec>
    3744:      	ldr	x8, [x10]
    3748:      	ldr	w9, [x29, #0x4]
    374c:      	cmp	x8, x9
    3750:      	b.ge	0x382c <do_action+0x7ec>
    3754:      	cmp	x25, #0x10
    3758:      	b.eq	0x37c0 <do_action+0x780>
    375c:      	str	wzr, [sp, #0x58]
    3760:      	mov	w8, #0x1                // =1
    3764:      	add	x9, sp, #0x58
    3768:      	add	x1, sp, #0x58
    376c:      	mov	x0, x24
    3770:      	blr	x8
    3774:      	cbz	x0, 0x37b8 <do_action+0x778>
    3778:      	mov	w8, #0x5ef8             // =24312
    377c:      	add	x1, x0, x8
    3780:      	adrp	x0, 0x3000 <filter_char_substring+0x270>
    3784:      	mov	w8, #0x1                // =1
    3788:      	ldr	x0, [x0]
    378c:      	blr	x8
    3790:      	cbz	x0, 0x37b8 <do_action+0x778>
    3794:      	ldr	x10, [sp, #0x38]
    3798:      	add	x8, x0, x25
    379c:      	ldr	w9, [x8, #0x44]
    37a0:      	ldr	x8, [x10]
    37a4:      	cmn	w9, #0x1
    37a8:      	b.eq	0x37c0 <do_action+0x780>
    37ac:      	ldr	w9, [x10, #0x8]
    37b0:      	sub	w9, w9, w8
    37b4:      	b	0x37cc <do_action+0x78c>
    37b8:      	ldr	x10, [sp, #0x38]
    37bc:      	ldr	x8, [x10]
    37c0:      	ldr	w9, [x29, #0x4]
    37c4:      	sub	w9, w9, w8
    37c8:      	add	w9, w9, #0x4
    37cc:      	cmp	w9, #0x1
    37d0:      	b.lt	0x36e4 <do_action+0x6a4>
    37d4:      	mov	w10, #0x3ffc            // =16380
    37d8:      	cmp	w9, #0x28
    37dc:      	mov	x23, x29
    37e0:      	add	w8, w8, w10
    37e4:      	mov	w10, #0x28              // =40
    37e8:      	csel	w29, w9, w10, lt
    37ec:      	ldr	w9, [sp, #0x2c]
    37f0:      	and	x8, x8, #0x3fff
    37f4:      	add	x8, x23, x8
    37f8:      	mov	w1, w29
    37fc:      	add	x2, x8, #0x90
    3800:      	mov	w8, #0x4                // =4
    3804:      	and	w20, w9, #0xff
    3808:      	ldr	x9, [sp, #0x18]
    380c:      	add	x0, x9, x20
    3810:      	blr	x8
    3814:      	add	w8, w29, w20
    3818:      	ldp	x20, x10, [sp, #0x30]
    381c:      	mov	x29, x23
    3820:      	ldr	x23, [sp, #0x20]
    3824:      	str	w8, [sp, #0x2c]
    3828:      	b	0x36e4 <do_action+0x6a4>
    382c:      	adrp	x24, 0x3000 <filter_char_substring+0x270>
    3830:      	mov	w8, #0x1                // =1
    3834:      	ldr	x24, [x24]
    3838:      	ldr	x1, [sp, #0x10]
    383c:      	mov	x0, x24
    3840:      	blr	x8
    3844:      	cbz	x0, 0x386c <do_action+0x82c>
    3848:      	ldp	x10, x11, [sp]
    384c:      	mov	x9, #-0x4240            // =-16960
    3850:      	movk	x9, #0xfff0, lsl #16
    3854:      	ldr	x8, [x0]
    3858:      	madd	x9, x10, x9, x11
    385c:      	cmp	x8, x9
    3860:      	b.ls	0x386c <do_action+0x82c>
    3864:      	strb	wzr, [x23]
    3868:      	b	0x388c <do_action+0x84c>
    386c:      	ldr	x1, [sp, #0x10]
    3870:      	mov	x3, xzr
    3874:      	mov	w8, #0x2                // =2
    3878:      	add	x9, sp, #0x48
    387c:      	add	x2, sp, #0x48
    3880:      	mov	x0, x24
    3884:      	blr	x8
    3888:      	ldr	x20, [sp, #0x30]
    388c:      	add	w8, w19, #0x3
    3890:      	adrp	x23, 0x3000 <filter_char_substring+0x270>
    3894:      	add	x8, x21, w8, uxtw #2
    3898:      	ldr	w8, [x8, #0x4]
    389c:      	ldr	x23, [x23]
    38a0:      	cbz	w8, 0x38c8 <do_action+0x888>
    38a4:      	ldrb	w8, [x29, #0x1]
    38a8:      	mov	x2, xzr
    38ac:      	mov	x0, x20
    38b0:      	mov	x1, x23
    38b4:      	orr	w8, w8, #0x2
    38b8:      	strb	w8, [x29, #0x1]
    38bc:      	mov	w8, #0x1b               // =27
    38c0:      	blr	x8
    38c4:      	str	x0, [x29, #0x80]
    38c8:      	add	w8, w19, #0x4
    38cc:      	add	x8, x21, w8, uxtw #2
    38d0:      	ldr	w8, [x8, #0x4]
    38d4:      	cbz	w8, 0x3900 <do_action+0x8c0>
    38d8:      	ldrb	w8, [x29, #0x1]
    38dc:      	mov	w9, #0x1b               // =27
    38e0:      	mov	x0, x20
    38e4:      	mov	x1, x23
    38e8:      	mov	w2, #0x100              // =256
    38ec:      	orr	w8, w8, #0x4
    38f0:      	strb	w8, [x29, #0x1]
    38f4:      	mov	w8, #0x100              // =256
    38f8:      	blr	x9
    38fc:      	str	x0, [x29, #0x88]
    3900:      	add	w19, w19, #0x5
    3904:      	add	x8, x21, w19, uxtw #2
    3908:      	ldr	w8, [x8, #0x4]
    390c:      	cbz	w8, 0x3530 <do_action+0x4f0>
    3910:      	ldrb	w8, [x29, #0x1]
    3914:      	orr	w8, w8, #0x8
    3918:      	strb	w8, [x29, #0x1]
    391c:      	b	0x3530 <do_action+0x4f0>
    3920:      	str	w20, [sp, #0x7c]
    3924:      	mov	x3, xzr
    3928:      	mov	w8, #0x2                // =2
    392c:      	add	x9, sp, #0x48
    3930:      	add	x10, sp, #0x7c
    3934:      	add	x1, sp, #0x48
    3938:      	add	x2, sp, #0x7c
    393c:      	mov	x0, x24
    3940:      	blr	x8
    3944:      	cbz	w23, 0x3410 <do_action+0x3d0>
    3948:      	mov	w8, #0x1                // =1
    394c:      	add	x9, sp, #0x58
    3950:      	add	x1, sp, #0x58
    3954:      	mov	x0, x25
    3958:      	blr	x8
    395c:      	cbz	x0, 0x3410 <do_action+0x3d0>
    3960:      	ldr	w8, [sp, #0x78]
    3964:      	ldaxr	w9, [x0]
    3968:      	add	w9, w9, w8
    396c:      	stlxr	w10, w9, [x0]
    3970:      	cbnz	w10, 0x3964 <do_action+0x924>
    3974:      	b	0x3410 <do_action+0x3d0>

Disassembly of section raw_tp:

0000000000000000 <generic_rawtp_setup_event>:
       0:      	sub	sp, sp, #0x50
       4:      	str	x30, [sp, #0x10]
       8:      	stp	x24, x23, [sp, #0x20]
       c:      	stp	x22, x21, [sp, #0x30]
      10:      	stp	x20, x19, [sp, #0x40]
      14:      	str	wzr, [sp, #0x1c]
      18:      	adrp	x20, 0x0 <generic_rawtp_setup_event>
      1c:      	mov	w8, #0x1                // =1
      20:      	add	x9, sp, #0x1c
      24:      	ldr	x20, [x20]
      28:      	mov	x19, x0
      2c:      	add	x1, sp, #0x1c
      30:      	mov	x0, x20
      34:      	blr	x8
      38:      	cbz	x0, 0x1a8 <generic_rawtp_setup_event+0x1a8>
      3c:      	adrp	x21, 0x0 <generic_rawtp_setup_event>
      40:      	mov	w8, #0x5ef8             // =24312
      44:      	mov	x22, x0
      48:      	ldr	x21, [x21]
      4c:      	add	x1, x0, x8
      50:      	mov	w8, #0x1                // =1
      54:      	mov	x0, x21
      58:      	blr	x8
      5c:      	cbz	x0, 0x1a8 <generic_rawtp_setup_event+0x1a8>
      60:      	mov	w24, #0x8               // =8
      64:      	add	x8, sp, #0x8
      68:      	mov	w9, #0x4                // =4
      6c:      	add	x0, sp, #0x8
      70:      	mov	w1, #0x8                // =8
      74:      	mov	x2, x19
      78:      	mov	w23, #0x4               // =4
      7c:      	blr	x9
      80:      	ldr	x8, [sp, #0x8]
      84:      	add	x2, x19, #0x8
      88:      	mov	w9, #0x4                // =4
      8c:      	add	x0, sp, #0x8
      90:      	str	x8, [x22, #0x5e50]
      94:      	add	x8, sp, #0x8
      98:      	mov	w1, #0x8                // =8
      9c:      	blr	x9
      a0:      	ldr	x8, [sp, #0x8]
      a4:      	add	x2, x19, #0x10
      a8:      	mov	w9, #0x4                // =4
      ac:      	add	x0, sp, #0x8
      b0:      	str	x8, [x22, #0x5e58]
      b4:      	add	x8, sp, #0x8
      b8:      	mov	w1, #0x8                // =8
      bc:      	blr	x9
      c0:      	ldr	x8, [sp, #0x8]
      c4:      	add	x2, x19, #0x18
      c8:      	mov	w9, #0x4                // =4
      cc:      	add	x0, sp, #0x8
      d0:      	str	x8, [x22, #0x5e60]
      d4:      	add	x8, sp, #0x8
      d8:      	mov	w1, #0x8                // =8
      dc:      	blr	x9
      e0:      	ldr	x8, [sp, #0x8]
      e4:      	add	x2, x19, #0x20
      e8:      	add	x0, sp, #0x8
      ec:      	mov	w1, #0x8                // =8
      f0:      	str	x8, [x22, #0x5e68]
      f4:      	add	x8, sp, #0x8
      f8:      	blr	x23
      fc:      	ldr	x8, [sp, #0x8]
     100:      	mov	w23, #0xe               // =14
     104:      	strh	wzr, [x22, #0x2]
     108:      	str	wzr, [x22, #0x4]
     10c:      	strb	w23, [x22]
     110:      	str	x8, [x22, #0x5e70]
     114:      	mov	w8, #0x7d               // =125
     118:      	blr	x8
     11c:      	str	x0, [x22, #0x8]
     120:      	str	xzr, [x22, #0x70]
     124:      	str	wzr, [x22, #0x14]
     128:      	blr	x23
     12c:      	str	w0, [x22, #0x7c]
     130:      	str	wzr, [sp, #0x8]
     134:      	mov	w8, #0x1                // =1
     138:      	add	x9, sp, #0x8
     13c:      	add	x1, sp, #0x8
     140:      	mov	x0, x20
     144:      	blr	x8
     148:      	adrp	x20, 0x0 <generic_rawtp_setup_event>
     14c:      	ldr	x20, [x20]
     150:      	cbz	x0, 0x178 <generic_rawtp_setup_event+0x178>
     154:      	mov	w8, #0x5ef8             // =24312
     158:      	add	x1, x0, x8
     15c:      	mov	w8, #0x1                // =1
     160:      	mov	x0, x21
     164:      	blr	x8
     168:      	cbz	x0, 0x178 <generic_rawtp_setup_event+0x178>
     16c:      	ldr	w8, [x0, #0x40]
     170:      	cmn	w8, #0x1
     174:      	b.ne	0x190 <generic_rawtp_setup_event+0x190>
     178:      	mov	w8, #0x3                // =3
     17c:      	mov	w9, #0xc                // =12
     180:      	mov	x0, x19
     184:      	mov	x1, x20
     188:      	mov	w2, #0x3                // =3
     18c:      	blr	x9
     190:      	mov	w8, #0x1                // =1
     194:      	mov	w9, #0xc                // =12
     198:      	mov	x0, x19
     19c:      	mov	x1, x20
     1a0:      	mov	w2, #0x1                // =1
     1a4:      	blr	x9
     1a8:      	ldp	x20, x19, [sp, #0x40]
     1ac:      	mov	w0, wzr
     1b0:      	ldr	x30, [sp, #0x10]
     1b4:      	ldp	x22, x21, [sp, #0x30]
     1b8:      	ldp	x24, x23, [sp, #0x20]
     1bc:      	add	sp, sp, #0x50
     1c0:      	ret
     1c4:      	nop
     1c8:      	nop
     1cc:      	nop

00000000000001d0 <generic_rawtp_process_event>:
     1d0:      	sub	sp, sp, #0x160
     1d4:      	str	x29, [sp, #0x110]
     1d8:      	stp	x30, x25, [sp, #0x120]
     1dc:      	stp	x24, x23, [sp, #0x130]
     1e0:      	stp	x22, x21, [sp, #0x140]
     1e4:      	stp	x20, x19, [sp, #0x150]
     1e8:      	str	wzr, [sp, #0x5c]
     1ec:      	adrp	x25, 0x0 <generic_rawtp_setup_event>
     1f0:      	mov	w8, #0x1                // =1
     1f4:      	add	x9, sp, #0x5c
     1f8:      	ldr	x25, [x25]
     1fc:      	mov	x19, x0
     200:      	add	x1, sp, #0x5c
     204:      	mov	x0, x25
     208:      	blr	x8
     20c:      	cbz	x0, 0xeb0 <generic_rawtp_process_event+0xce0>
     210:      	ldr	w24, [x0, #0x4]
     214:      	mov	w21, #0x5efc            // =24316
     218:      	mov	x20, x0
     21c:      	ldr	w23, [x0, x21]
     220:      	lsr	w8, w24, #3
     224:      	cmp	w8, #0x464
     228:      	b.hi	0x618 <generic_rawtp_process_event+0x448>
     22c:      	str	wzr, [sp, #0x68]
     230:      	mov	w8, #0x1                // =1
     234:      	add	x9, sp, #0x68
     238:      	add	x1, sp, #0x68
     23c:      	mov	x0, x25
     240:      	blr	x8
     244:      	cbz	x0, 0x618 <generic_rawtp_process_event+0x448>
     248:      	mov	w8, #0x5ef8             // =24312
     24c:      	mov	x22, x0
     250:      	add	x1, x0, x8
     254:      	adrp	x0, 0x0 <generic_rawtp_setup_event>
     258:      	mov	w8, #0x1                // =1
     25c:      	ldr	x0, [x0]
     260:      	blr	x8
     264:      	cmp	w23, #0x4
     268:      	ccmp	x0, #0x0, #0x4, le
     26c:      	b.eq	0x618 <generic_rawtp_process_event+0x448>
     270:      	and	x29, x23, #0x7
     274:      	str	x24, [sp, #0x118]
     278:      	str	x23, [sp, #0x50]
     27c:      	mov	w9, #0x5ea0             // =24224
     280:      	add	x8, x0, x29, lsl #2
     284:      	ldrsw	x24, [x8, #0x18]
     288:      	ldr	w23, [x8, #0x4]
     28c:      	add	x8, x22, x29, lsl #2
     290:      	add	x21, x8, x9
     294:      	str	wzr, [x21]
     298:      	and	x10, x24, #0xffffffff
     29c:      	str	x10, [sp, #0x40]
     2a0:      	tbnz	w24, #0x8, 0x2c4 <generic_rawtp_process_event+0xf4>
     2a4:      	tbnz	w10, #0x7, 0x2d0 <generic_rawtp_process_event+0x100>
     2a8:      	tbnz	w24, #0x6, 0x2dc <generic_rawtp_process_event+0x10c>
     2ac:      	add	x8, x0, x29, lsl #2
     2b0:      	ldr	w8, [x8, #0x40]
     2b4:      	and	x8, x8, #0x7
     2b8:      	add	x8, x22, x8, lsl #3
     2bc:      	ldr	x10, [x8, #0x5e50]
     2c0:      	b	0x2f0 <generic_rawtp_process_event+0x120>
     2c4:      	mov	x10, xzr
     2c8:      	str	xzr, [sp, #0x60]
     2cc:      	b	0x3f0 <generic_rawtp_process_event+0x220>
     2d0:      	mov	x10, xzr
     2d4:      	str	xzr, [sp, #0x60]
     2d8:      	b	0x2f4 <generic_rawtp_process_event+0x124>
     2dc:      	mov	w8, #0x23               // =35
     2e0:      	mov	x22, x0
     2e4:      	blr	x8
     2e8:      	mov	x10, x0
     2ec:      	mov	x0, x22
     2f0:      	str	x10, [sp, #0x60]
     2f4:      	cmp	w29, #0x4
     2f8:      	b.hi	0x3f0 <generic_rawtp_process_event+0x220>
     2fc:      	mov	w8, #0x50               // =80
     300:      	umaddl	x8, w29, w8, x0
     304:      	ldrh	w9, [x8, #0x76]
     308:      	cbz	w9, 0x3f0 <generic_rawtp_process_event+0x220>
     30c:      	add	x8, x8, #0x70
     310:      	add	x9, sp, #0x60
     314:      	strb	wzr, [sp, #0xa8]
     318:      	str	x21, [sp, #0xb0]
     31c:      	stp	x8, x9, [sp, #0x98]
     320:      	adrp	x8, 0x0 <generic_rawtp_setup_event>
     324:      	ldr	x8, [x8]
     328:      	ldrb	w8, [x8]
     32c:      	cbz	w8, 0x3c0 <generic_rawtp_process_event+0x1f0>
     330:      	mov	x25, xzr
     334:      	mov	w22, #0x1               // =1
     338:      	mov	w21, #0x8               // =8
     33c:      	b	0x368 <generic_rawtp_process_event+0x198>
     340:      	mov	w10, #0x4               // =4
     344:      	ldr	x0, [sp, #0xa0]
     348:      	mov	w1, #0x8                // =8
     34c:      	ldr	x2, [x0]
     350:      	blr	x10
     354:      	tbnz	w0, #0x1f, 0x3b4 <generic_rawtp_process_event+0x1e4>
     358:      	add	x25, x25, #0x8
     35c:      	add	w22, w22, #0x1
     360:      	cmp	x25, #0x50
     364:      	b.eq	0x3e4 <generic_rawtp_process_event+0x214>
     368:      	ldr	x8, [sp, #0x98]
     36c:      	add	x10, x8, x25
     370:      	ldrh	w8, [x10, #0x6]
     374:      	cbz	w8, 0x3e4 <generic_rawtp_process_event+0x214>
     378:      	ldr	x8, [sp, #0xa0]
     37c:      	ldr	w11, [x10]
     380:      	ldr	x9, [x8]
     384:      	add	x9, x9, x11
     388:      	str	x9, [x8]
     38c:      	ldrh	w10, [x10, #0x4]
     390:      	cbz	w10, 0x358 <generic_rawtp_process_event+0x188>
     394:      	ldrb	w10, [sp, #0xa8]
     398:      	cbz	w10, 0x340 <generic_rawtp_process_event+0x170>
     39c:      	mov	w10, #0x94              // =148
     3a0:      	ldr	x0, [sp, #0xa0]
     3a4:      	mov	w1, #0x8                // =8
     3a8:      	ldr	x2, [x0]
     3ac:      	blr	x10
     3b0:      	tbz	w0, #0x1f, 0x358 <generic_rawtp_process_event+0x188>
     3b4:      	ldr	x8, [sp, #0xb0]
     3b8:      	str	w22, [x8]
     3bc:      	b	0x3e4 <generic_rawtp_process_event+0x214>
     3c0:      	mov	x3, xzr
     3c4:      	adrp	x1, 0x0 <generic_rawtp_setup_event>
     3c8:      	add	x1, x1, #0x0
     3cc:      	mov	w8, #0xa                // =10
     3d0:      	mov	w9, #0xb5               // =181
     3d4:      	add	x10, sp, #0x98
     3d8:      	add	x2, sp, #0x98
     3dc:      	mov	w0, #0xa                // =10
     3e0:      	blr	x9
     3e4:      	adrp	x25, 0x0 <generic_rawtp_setup_event>
     3e8:      	ldr	x10, [sp, #0x60]
     3ec:      	ldr	x25, [x25]
     3f0:      	mov	w22, #0x1000            // =4096
     3f4:      	cmp	w23, #0x15
     3f8:      	b.gt	0x42c <generic_rawtp_process_event+0x25c>
     3fc:      	cmp	w23, #0xb
     400:      	b.gt	0x45c <generic_rawtp_process_event+0x28c>
     404:      	cmp	w23, #0x5
     408:      	b.gt	0x4cc <generic_rawtp_process_event+0x2fc>
     40c:      	cmp	w23, #0x3
     410:      	b.gt	0x560 <generic_rawtp_process_event+0x390>
     414:      	sub	w8, w23, #0x2
     418:      	cmp	w8, #0x2
     41c:      	b.lo	0x51c <generic_rawtp_process_event+0x34c>
     420:      	cmp	w23, #0x1
     424:      	b.eq	0x51c <generic_rawtp_process_event+0x34c>
     428:      	b	0x598 <generic_rawtp_process_event+0x3c8>
     42c:      	cmp	w23, #0x20
     430:      	b.le	0x480 <generic_rawtp_process_event+0x2b0>
     434:      	cmp	w23, #0x27
     438:      	b.gt	0x4a4 <generic_rawtp_process_event+0x2d4>
     43c:      	sub	w8, w23, #0x21
     440:      	cmp	w8, #0x4
     444:      	b.lo	0x578 <generic_rawtp_process_event+0x3a8>
     448:      	cmp	w23, #0x25
     44c:      	b.eq	0x59c <generic_rawtp_process_event+0x3cc>
     450:      	cmp	w23, #0x27
     454:      	b.eq	0x524 <generic_rawtp_process_event+0x354>
     458:      	b	0x598 <generic_rawtp_process_event+0x3c8>
     45c:      	cmp	w23, #0x11
     460:      	b.gt	0x4f0 <generic_rawtp_process_event+0x320>
     464:      	sub	w8, w23, #0xf
     468:      	cmp	w8, #0x3
     46c:      	b.lo	0x59c <generic_rawtp_process_event+0x3cc>
     470:      	sub	w8, w23, #0xc
     474:      	cmp	w8, #0x2
     478:      	b.lo	0x51c <generic_rawtp_process_event+0x34c>
     47c:      	b	0x598 <generic_rawtp_process_event+0x3c8>
     480:      	cmp	w23, #0x1a
     484:      	b.gt	0x510 <generic_rawtp_process_event+0x340>
     488:      	cmp	w23, #0x16
     48c:      	b.eq	0x524 <generic_rawtp_process_event+0x354>
     490:      	cmp	w23, #0x17
     494:      	b.eq	0x578 <generic_rawtp_process_event+0x3a8>
     498:      	cmp	w23, #0x1a
     49c:      	b.eq	0x590 <generic_rawtp_process_event+0x3c0>
     4a0:      	b	0x598 <generic_rawtp_process_event+0x3c8>
     4a4:      	cmp	w23, #0x29
     4a8:      	b.le	0x544 <generic_rawtp_process_event+0x374>
     4ac:      	cmp	w23, #0x2a
     4b0:      	b.eq	0x59c <generic_rawtp_process_event+0x3cc>
     4b4:      	cmp	w23, #0x2b
     4b8:      	b.eq	0x558 <generic_rawtp_process_event+0x388>
     4bc:      	cmp	w23, #0x2c
     4c0:      	b.ne	0x598 <generic_rawtp_process_event+0x3c8>
     4c4:      	mov	w22, #0x70              // =112
     4c8:      	b	0x59c <generic_rawtp_process_event+0x3cc>
     4cc:      	cmp	w23, #0x9
     4d0:      	b.gt	0x578 <generic_rawtp_process_event+0x3a8>
     4d4:      	cmp	w23, #0x6
     4d8:      	b.eq	0x59c <generic_rawtp_process_event+0x3cc>
     4dc:      	cmp	w23, #0x7
     4e0:      	b.eq	0x570 <generic_rawtp_process_event+0x3a0>
     4e4:      	cmp	w23, #0x8
     4e8:      	b.eq	0x590 <generic_rawtp_process_event+0x3c0>
     4ec:      	b	0x598 <generic_rawtp_process_event+0x3c8>
     4f0:      	cmp	w23, #0x13
     4f4:      	b.gt	0x52c <generic_rawtp_process_event+0x35c>
     4f8:      	cmp	w23, #0x12
     4fc:      	mov	x22, x24
     500:      	b.eq	0x59c <generic_rawtp_process_event+0x3cc>
     504:      	cmp	w23, #0x13
     508:      	b.eq	0x558 <generic_rawtp_process_event+0x388>
     50c:      	b	0x598 <generic_rawtp_process_event+0x3c8>
     510:      	sub	w8, w23, #0x1d
     514:      	cmp	w8, #0x4
     518:      	b.hs	0x588 <generic_rawtp_process_event+0x3b8>
     51c:      	mov	w22, #0x4               // =4
     520:      	b	0x59c <generic_rawtp_process_event+0x3cc>
     524:      	mov	w22, #0x10              // =16
     528:      	b	0x59c <generic_rawtp_process_event+0x3cc>
     52c:      	cmp	w23, #0x14
     530:      	b.eq	0x580 <generic_rawtp_process_event+0x3b0>
     534:      	cmp	w23, #0x15
     538:      	b.ne	0x598 <generic_rawtp_process_event+0x3c8>
     53c:      	mov	w22, #0x20              // =32
     540:      	b	0x59c <generic_rawtp_process_event+0x3cc>
     544:      	cmp	w23, #0x28
     548:      	b.eq	0x558 <generic_rawtp_process_event+0x388>
     54c:      	cmp	w23, #0x29
     550:      	b.eq	0x570 <generic_rawtp_process_event+0x3a0>
     554:      	b	0x598 <generic_rawtp_process_event+0x3c8>
     558:      	mov	w22, #0x18              // =24
     55c:      	b	0x59c <generic_rawtp_process_event+0x3cc>
     560:      	cmp	w23, #0x4
     564:      	b.eq	0x578 <generic_rawtp_process_event+0x3a8>
     568:      	cmp	w23, #0x5
     56c:      	b.ne	0x598 <generic_rawtp_process_event+0x3c8>
     570:      	mov	w22, #0x40              // =64
     574:      	b	0x59c <generic_rawtp_process_event+0x3cc>
     578:      	mov	w22, #0x8               // =8
     57c:      	b	0x59c <generic_rawtp_process_event+0x3cc>
     580:      	mov	w22, #0x98              // =152
     584:      	b	0x59c <generic_rawtp_process_event+0x3cc>
     588:      	cmp	w23, #0x1b
     58c:      	b.ne	0x598 <generic_rawtp_process_event+0x3c8>
     590:      	mov	w22, #0x50              // =80
     594:      	b	0x59c <generic_rawtp_process_event+0x3cc>
     598:      	mov	x22, xzr
     59c:      	str	x10, [sp, #0x48]
     5a0:      	str	wzr, [sp, #0x6c]
     5a4:      	mov	w8, #0x1                // =1
     5a8:      	add	x9, sp, #0x6c
     5ac:      	add	x1, sp, #0x6c
     5b0:      	mov	x0, x25
     5b4:      	blr	x8
     5b8:      	cbz	x0, 0x60c <generic_rawtp_process_event+0x43c>
     5bc:      	ldr	x9, [sp, #0x118]
     5c0:      	mov	w8, #0x3ffb             // =16379
     5c4:      	sub	x8, x8, x22
     5c8:      	cmp	x8, x9
     5cc:      	b.ls	0x60c <generic_rawtp_process_event+0x43c>
     5d0:      	add	x22, x0, x29, lsl #2
     5d4:      	mov	w8, #0x5ea0             // =24224
     5d8:      	add	x21, x0, #0x90
     5dc:      	ldr	w9, [x22, x8]
     5e0:      	ldr	x8, [sp, #0x118]
     5e4:      	add	x10, x0, x29, lsl #3
     5e8:      	str	w9, [x21, x8]
     5ec:      	add	x8, x8, #0x4
     5f0:      	str	x8, [x10, #0x5e78]
     5f4:      	cbz	w9, 0x69c <generic_rawtp_process_event+0x4cc>
     5f8:      	ldr	x23, [sp, #0x50]
     5fc:      	ldr	x24, [sp, #0x118]
     600:      	mov	w8, #0x4                // =4
     604:      	mov	w21, #0x5efc            // =24316
     608:      	b	0xe7c <generic_rawtp_process_event+0xcac>
     60c:      	ldr	x23, [sp, #0x50]
     610:      	ldr	x24, [sp, #0x118]
     614:      	mov	w21, #0x5efc            // =24316
     618:      	str	w24, [x20, #0x4]
     61c:      	adrp	x22, 0x0 <generic_rawtp_setup_event>
     620:      	cmp	w23, #0x3
     624:      	ldr	x22, [x22]
     628:      	b.gt	0xe94 <generic_rawtp_process_event+0xcc4>
     62c:      	str	wzr, [sp, #0x98]
     630:      	mov	w8, #0x1                // =1
     634:      	add	x9, sp, #0x98
     638:      	add	x1, sp, #0x98
     63c:      	mov	x0, x25
     640:      	blr	x8
     644:      	cbz	x0, 0xe94 <generic_rawtp_process_event+0xcc4>
     648:      	mov	w8, #0x5ef8             // =24312
     64c:      	add	x1, x0, x8
     650:      	adrp	x0, 0x0 <generic_rawtp_setup_event>
     654:      	mov	w8, #0x1                // =1
     658:      	ldr	x0, [x0]
     65c:      	blr	x8
     660:      	cbz	x0, 0xe94 <generic_rawtp_process_event+0xcc4>
     664:      	add	w8, w23, #0x1
     668:      	and	w9, w8, #0x7
     66c:      	add	x9, x0, w9, uxtw #2
     670:      	ldr	w9, [x9, #0x40]
     674:      	cmn	w9, #0x1
     678:      	b.eq	0xe94 <generic_rawtp_process_event+0xcc4>
     67c:      	str	w8, [x20, x21]
     680:      	mov	w8, #0x1                // =1
     684:      	mov	w9, #0xc                // =12
     688:      	mov	x0, x19
     68c:      	mov	x1, x22
     690:      	mov	w2, #0x1                // =1
     694:      	blr	x9
     698:      	b	0xe94 <generic_rawtp_process_event+0xcc4>
     69c:      	ldr	x10, [sp, #0x48]
     6a0:      	and	x29, x8, #0x3fff
     6a4:      	add	x9, sp, #0xe0
     6a8:      	cmp	w23, #0x17
     6ac:      	str	xzr, [x9, #0x10]
     6b0:      	add	x8, x21, x29
     6b4:      	str	x8, [sp, #0x30]
     6b8:      	str	x10, [sp, #0x98]
     6bc:      	b.le	0x6e8 <generic_rawtp_process_event+0x518>
     6c0:      	cmp	w23, #0x18
     6c4:      	b.eq	0x708 <generic_rawtp_process_event+0x538>
     6c8:      	cmp	w23, #0x25
     6cc:      	b.eq	0x764 <generic_rawtp_process_event+0x594>
     6d0:      	cmp	w23, #0x2a
     6d4:      	b.ne	0xc9c <generic_rawtp_process_event+0xacc>
     6d8:      	add	x8, sp, #0x70
     6dc:      	stp	xzr, x10, [sp, #0x70]
     6e0:      	str	x8, [sp, #0x38]
     6e4:      	b	0x7cc <generic_rawtp_process_event+0x5fc>
     6e8:      	cmp	w23, #0xf
     6ec:      	b.eq	0x79c <generic_rawtp_process_event+0x5cc>
     6f0:      	cmp	w23, #0x10
     6f4:      	b.ne	0xc9c <generic_rawtp_process_event+0xacc>
     6f8:      	mov	x23, x21
     6fc:      	add	x21, sp, #0x100
     700:      	add	x24, sp, #0xe0
     704:      	b	0x734 <generic_rawtp_process_event+0x564>
     708:      	mov	x23, x21
     70c:      	add	x21, sp, #0x100
     710:      	mov	w8, #0x8                // =8
     714:      	mov	w9, #0x4                // =4
     718:      	ldr	x2, [sp, #0x98]
     71c:      	add	x0, sp, #0x100
     720:      	mov	w1, #0x8                // =8
     724:      	blr	x9
     728:      	add	x24, sp, #0xe0
     72c:      	ldr	x8, [x24, #0x20]
     730:      	str	x8, [sp, #0x98]
     734:      	mov	w8, #0x8                // =8
     738:      	mov	w9, #0x4                // =4
     73c:      	add	x10, sp, #0x98
     740:      	add	x0, sp, #0x100
     744:      	add	x2, sp, #0x98
     748:      	mov	w1, #0x8                // =8
     74c:      	blr	x9
     750:      	ldr	x8, [x24, #0x20]
     754:      	mov	x21, x23
     758:      	add	x8, x8, #0x40
     75c:      	str	x8, [sp, #0x38]
     760:      	b	0x7cc <generic_rawtp_process_event+0x5fc>
     764:      	add	x8, x10, #0x40
     768:      	mov	w9, #0x8                // =8
     76c:      	mov	w10, #0x4               // =4
     770:      	str	x8, [sp, #0x98]
     774:      	add	x11, sp, #0x100
     778:      	add	x0, sp, #0x100
     77c:      	mov	w1, #0x8                // =8
     780:      	ldr	x2, [sp, #0x98]
     784:      	blr	x10
     788:      	add	x8, sp, #0xe0
     78c:      	ldr	x8, [x8, #0x20]
     790:      	add	x8, x8, #0x40
     794:      	str	x8, [sp, #0x38]
     798:      	b	0x7cc <generic_rawtp_process_event+0x5fc>
     79c:      	mov	w8, #0x8                // =8
     7a0:      	mov	w9, #0x4                // =4
     7a4:      	add	x10, sp, #0xf0
     7a8:      	add	x11, sp, #0x98
     7ac:      	add	x0, sp, #0xf0
     7b0:      	add	x2, sp, #0x98
     7b4:      	mov	w1, #0x8                // =8
     7b8:      	blr	x9
     7bc:      	add	x8, sp, #0xe0
     7c0:      	ldr	x8, [x8, #0x10]
     7c4:      	str	x8, [sp, #0x38]
     7c8:      	cbz	x8, 0xed0 <generic_rawtp_process_event+0xd00>
     7cc:      	str	wzr, [sp, #0x84]
     7d0:      	adrp	x0, 0x0 <generic_rawtp_setup_event>
     7d4:      	mov	w8, #0x1                // =1
     7d8:      	add	x9, sp, #0x84
     7dc:      	ldr	x0, [x0]
     7e0:      	add	x1, sp, #0x84
     7e4:      	blr	x8
     7e8:      	cbz	x0, 0xd98 <generic_rawtp_process_event+0xbc8>
     7ec:      	add	x8, x0, #0x1, lsl #12   // =0x1000
     7f0:      	stp	x21, x22, [sp, #0x18]
     7f4:      	mov	x24, x0
     7f8:      	str	x8, [sp, #0x40]
     7fc:      	mov	w8, #0x23               // =35
     800:      	blr	x8
     804:      	add	x2, x0, #0xb30
     808:      	mov	w23, #0x8               // =8
     80c:      	add	x8, sp, #0x88
     810:      	mov	w9, #0x4                // =4
     814:      	add	x0, sp, #0x88
     818:      	mov	w1, #0x8                // =8
     81c:      	mov	w25, #0x4               // =4
     820:      	blr	x9
     824:      	ldr	x8, [sp, #0x88]
     828:      	mov	w9, #0x4                // =4
     82c:      	add	x0, sp, #0x90
     830:      	mov	w1, #0x8                // =8
     834:      	str	x8, [sp, #0x10]
     838:      	add	x8, x8, #0x18
     83c:      	str	x8, [sp, #0x48]
     840:      	ldr	x8, [sp, #0x38]
     844:      	add	x2, x8, #0x8
     848:      	add	x8, sp, #0x90
     84c:      	str	x2, [sp, #0x28]
     850:      	blr	x9
     854:      	ldr	x21, [sp, #0x90]
     858:      	add	x22, sp, #0x98
     85c:      	add	x0, sp, #0x98
     860:      	mov	w1, #0x8                // =8
     864:      	add	x2, x21, #0x10
     868:      	blr	x25
     86c:      	ldr	x8, [sp, #0x98]
     870:      	cbz	x8, 0x880 <generic_rawtp_process_event+0x6b0>
     874:      	ldr	x9, [sp, #0x40]
     878:      	mov	w8, #0x1000             // =4096
     87c:      	b	0x8c8 <generic_rawtp_process_event+0x6f8>
     880:      	add	x2, x21, #0x18
     884:      	mov	w8, #0x8                // =8
     888:      	mov	w9, #0x4                // =4
     88c:      	add	x10, sp, #0x98
     890:      	add	x0, sp, #0x98
     894:      	mov	w1, #0x8                // =8
     898:      	blr	x9
     89c:      	ldr	x8, [sp, #0x98]
     8a0:      	cmp	x8, x21
     8a4:      	b.eq	0x874 <generic_rawtp_process_event+0x6a4>
     8a8:      	mov	w8, #0x2964             // =10596
     8ac:      	add	x9, x24, #0xff6
     8b0:      	strh	w8, [x24, #0xffe]
     8b4:      	adrp	x8, 0x0 <generic_rawtp_setup_event>
     8b8:      	add	x8, x8, #0x0
     8bc:      	ldr	x8, [x8]
     8c0:      	str	x8, [x9]
     8c4:      	mov	w8, #0xff6              // =4086
     8c8:      	str	x9, [sp, #0x40]
     8cc:      	str	x9, [sp, #0xc8]
     8d0:      	ldr	x9, [sp, #0x10]
     8d4:      	mov	w21, #0x8               // =8
     8d8:      	add	x0, sp, #0x98
     8dc:      	mov	w1, #0x8                // =8
     8e0:      	stp	xzr, xzr, [sp, #0x98]
     8e4:      	add	x23, x22, #0x8
     8e8:      	add	x29, x22, #0x18
     8ec:      	mov	w25, #0x4               // =4
     8f0:      	add	x2, x9, #0x20
     8f4:      	stp	x24, xzr, [sp, #0xa8]
     8f8:      	stp	xzr, xzr, [sp, #0xb8]
     8fc:      	str	w8, [sp, #0xd0]
     900:      	mov	w8, #0x4                // =4
     904:      	add	x24, x22, #0x20
     908:      	strb	wzr, [sp, #0xd4]
     90c:      	blr	x8
     910:      	ldr	x2, [sp, #0x48]
     914:      	mov	w8, #0x4                // =4
     918:      	mov	x0, x23
     91c:      	mov	w1, #0x8                // =8
     920:      	blr	x8
     924:      	ldr	x2, [sp, #0x28]
     928:      	mov	w8, #0x4                // =4
     92c:      	mov	x0, x29
     930:      	mov	w1, #0x8                // =8
     934:      	str	x29, [sp, #0x48]
     938:      	blr	x8
     93c:      	ldr	x2, [sp, #0x38]
     940:      	mov	x0, x24
     944:      	mov	w1, #0x8                // =8
     948:      	blr	x25
     94c:      	ldr	x8, [sp, #0xb8]
     950:      	sub	x8, x8, #0x20
     954:      	str	x8, [sp, #0xc0]
     958:      	adrp	x8, 0x0 <generic_rawtp_setup_event>
     95c:      	ldr	x8, [x8]
     960:      	ldrb	w8, [x8]
     964:      	cbz	w8, 0xb08 <generic_rawtp_process_event+0x938>
     968:      	mov	w23, #0x800             // =2048
     96c:      	mov	w24, #0x8               // =8
     970:      	add	x22, sp, #0xe0
     974:      	ldp	x21, x2, [sp, #0xb0]
     978:      	ldp	x8, x9, [sp, #0x98]
     97c:      	cmp	x21, x8
     980:      	ccmp	x2, x9, #0x0, eq
     984:      	b.eq	0xd38 <generic_rawtp_process_event+0xb68>
     988:      	ldr	x25, [sp, #0xc0]
     98c:      	mov	w8, #0x4                // =4
     990:      	add	x9, sp, #0xe0
     994:      	add	x0, sp, #0xe0
     998:      	mov	w1, #0x8                // =8
     99c:      	blr	x8
     9a0:      	ldr	x8, [x22]
     9a4:      	add	x29, sp, #0xe0
     9a8:      	cmp	x21, x8
     9ac:      	b.eq	0xaa8 <generic_rawtp_process_event+0x8d8>
     9b0:      	add	x22, x21, #0x18
     9b4:      	mov	w8, #0x4                // =4
     9b8:      	add	x9, sp, #0x100
     9bc:      	add	x0, sp, #0x100
     9c0:      	mov	w1, #0x8                // =8
     9c4:      	mov	x2, x22
     9c8:      	blr	x8
     9cc:      	ldr	x8, [x29, #0x20]
     9d0:      	cmp	x8, x21
     9d4:      	b.eq	0xaa8 <generic_rawtp_process_event+0x8d8>
     9d8:      	mov	w8, #0x4                // =4
     9dc:      	add	x9, sp, #0xe8
     9e0:      	add	x0, sp, #0xe8
     9e4:      	mov	w1, #0x8                // =8
     9e8:      	mov	x2, x22
     9ec:      	blr	x8
     9f0:      	add	x2, x21, #0x20
     9f4:      	mov	w8, #0x4                // =4
     9f8:      	mov	w9, #0x10               // =16
     9fc:      	add	x10, sp, #0xf0
     a00:      	add	x0, sp, #0xf0
     a04:      	mov	w1, #0x10               // =16
     a08:      	blr	x8
     a0c:      	ldr	w21, [sp, #0xf4]
     a10:      	ldr	x8, [sp, #0xa8]
     a14:      	ldr	x10, [sp, #0xc8]
     a18:      	sub	x12, x10, x8
     a1c:      	ldr	w22, [sp, #0xd0]
     a20:      	subs	w10, w21, w22
     a24:      	ldr	x9, [x29, #0x18]
     a28:      	csel	w10, wzr, w10, lo
     a2c:      	cmp	w22, w21
     a30:      	csel	w11, w22, w21, lo
     a34:      	cinc	w13, w11, hi
     a38:      	sub	w14, w22, w13
     a3c:      	subs	x12, x12, x13
     a40:      	str	w14, [sp, #0xd0]
     a44:      	b.lo	0xd40 <generic_rawtp_process_event+0xb70>
     a48:      	cmp	x12, #0xfff
     a4c:      	b.hi	0xd40 <generic_rawtp_process_event+0xb70>
     a50:      	cmp	w22, w21
     a54:      	b.ls	0xa60 <generic_rawtp_process_event+0x890>
     a58:      	mov	w13, #0x2f              // =47
     a5c:      	strb	w13, [x8, x12]
     a60:      	add	x25, x8, x12
     a64:      	cmp	w22, w21
     a68:      	add	x2, x9, x10
     a6c:      	and	w1, w11, #0xff
     a70:      	mov	w8, #0x4                // =4
     a74:      	cinc	x0, x25, hi
     a78:      	blr	x8
     a7c:      	cmp	w22, w21
     a80:      	str	x25, [sp, #0xc8]
     a84:      	b.ls	0xd40 <generic_rawtp_process_event+0xb70>
     a88:      	add	x22, sp, #0xe0
     a8c:      	ldr	x8, [x22, #0x8]
     a90:      	str	x8, [sp, #0xb0]
     a94:      	adrp	x25, 0x0 <generic_rawtp_setup_event>
     a98:      	subs	w23, w23, #0x1
     a9c:      	ldr	x25, [x25]
     aa0:      	b.ne	0x974 <generic_rawtp_process_event+0x7a4>
     aa4:      	b	0xd58 <generic_rawtp_process_event+0xb88>
     aa8:      	add	x2, x25, #0x10
     aac:      	mov	w8, #0x4                // =4
     ab0:      	add	x9, sp, #0x100
     ab4:      	add	x0, sp, #0x100
     ab8:      	mov	w1, #0x8                // =8
     abc:      	blr	x8
     ac0:      	ldr	x8, [sp, #0xc0]
     ac4:      	ldr	x9, [x29, #0x20]
     ac8:      	add	x22, sp, #0xe0
     acc:      	cmp	x8, x9
     ad0:      	b.eq	0xd48 <generic_rawtp_process_event+0xb78>
     ad4:      	ldr	x0, [sp, #0x48]
     ad8:      	add	x2, x25, #0x18
     adc:      	mov	w8, #0x4                // =4
     ae0:      	mov	w1, #0x8                // =8
     ae4:      	blr	x8
     ae8:      	ldr	x8, [x22, #0x20]
     aec:      	add	x9, x8, #0x20
     af0:      	stp	x9, x8, [sp, #0xb8]
     af4:      	adrp	x25, 0x0 <generic_rawtp_setup_event>
     af8:      	subs	w23, w23, #0x1
     afc:      	ldr	x25, [x25]
     b00:      	b.ne	0x974 <generic_rawtp_process_event+0x7a4>
     b04:      	b	0xd58 <generic_rawtp_process_event+0xb88>
     b08:      	mov	w23, #0x800             // =2048
     b0c:      	mov	w24, #0x8               // =8
     b10:      	add	x22, sp, #0xe0
     b14:      	b	0xb28 <generic_rawtp_process_event+0x958>
     b18:      	adrp	x25, 0x0 <generic_rawtp_setup_event>
     b1c:      	subs	w23, w23, #0x1
     b20:      	ldr	x25, [x25]
     b24:      	b.eq	0xd58 <generic_rawtp_process_event+0xb88>
     b28:      	ldp	x21, x2, [sp, #0xb0]
     b2c:      	ldp	x8, x9, [sp, #0x98]
     b30:      	cmp	x21, x8
     b34:      	ccmp	x2, x9, #0x0, eq
     b38:      	b.eq	0xd38 <generic_rawtp_process_event+0xb68>
     b3c:      	ldr	x25, [sp, #0xc0]
     b40:      	mov	w8, #0x4                // =4
     b44:      	add	x9, sp, #0xe0
     b48:      	add	x0, sp, #0xe0
     b4c:      	mov	w1, #0x8                // =8
     b50:      	blr	x8
     b54:      	ldr	x8, [x22]
     b58:      	add	x29, sp, #0xe0
     b5c:      	cmp	x21, x8
     b60:      	b.eq	0xc4c <generic_rawtp_process_event+0xa7c>
     b64:      	add	x22, x21, #0x18
     b68:      	mov	w8, #0x4                // =4
     b6c:      	add	x9, sp, #0x100
     b70:      	add	x0, sp, #0x100
     b74:      	mov	w1, #0x8                // =8
     b78:      	mov	x2, x22
     b7c:      	blr	x8
     b80:      	ldr	x8, [x29, #0x20]
     b84:      	cmp	x8, x21
     b88:      	b.eq	0xc4c <generic_rawtp_process_event+0xa7c>
     b8c:      	mov	w8, #0x4                // =4
     b90:      	add	x9, sp, #0xe8
     b94:      	add	x0, sp, #0xe8
     b98:      	mov	w1, #0x8                // =8
     b9c:      	mov	x2, x22
     ba0:      	blr	x8
     ba4:      	add	x2, x21, #0x20
     ba8:      	mov	w8, #0x4                // =4
     bac:      	mov	w9, #0x10               // =16
     bb0:      	add	x10, sp, #0xf0
     bb4:      	add	x0, sp, #0xf0
     bb8:      	mov	w1, #0x10               // =16
     bbc:      	blr	x8
     bc0:      	ldr	w21, [sp, #0xf4]
     bc4:      	ldr	x8, [sp, #0xa8]
     bc8:      	ldr	x10, [sp, #0xc8]
     bcc:      	sub	x12, x10, x8
     bd0:      	ldr	w22, [sp, #0xd0]
     bd4:      	subs	w10, w21, w22
     bd8:      	ldr	x9, [x29, #0x18]
     bdc:      	csel	w10, wzr, w10, lo
     be0:      	cmp	w22, w21
     be4:      	csel	w11, w22, w21, lo
     be8:      	cinc	w13, w11, hi
     bec:      	sub	w14, w22, w13
     bf0:      	subs	x12, x12, x13
     bf4:      	str	w14, [sp, #0xd0]
     bf8:      	b.lo	0xd40 <generic_rawtp_process_event+0xb70>
     bfc:      	cmp	x12, #0xfff
     c00:      	b.hi	0xd40 <generic_rawtp_process_event+0xb70>
     c04:      	cmp	w22, w21
     c08:      	b.ls	0xc14 <generic_rawtp_process_event+0xa44>
     c0c:      	mov	w13, #0x2f              // =47
     c10:      	strb	w13, [x8, x12]
     c14:      	add	x25, x8, x12
     c18:      	cmp	w22, w21
     c1c:      	add	x2, x9, x10
     c20:      	and	w1, w11, #0xff
     c24:      	mov	w8, #0x4                // =4
     c28:      	cinc	x0, x25, hi
     c2c:      	blr	x8
     c30:      	cmp	w22, w21
     c34:      	str	x25, [sp, #0xc8]
     c38:      	b.ls	0xd40 <generic_rawtp_process_event+0xb70>
     c3c:      	add	x22, sp, #0xe0
     c40:      	ldr	x8, [x22, #0x8]
     c44:      	str	x8, [sp, #0xb0]
     c48:      	b	0xb18 <generic_rawtp_process_event+0x948>
     c4c:      	add	x2, x25, #0x10
     c50:      	mov	w8, #0x4                // =4
     c54:      	add	x9, sp, #0x100
     c58:      	add	x0, sp, #0x100
     c5c:      	mov	w1, #0x8                // =8
     c60:      	blr	x8
     c64:      	ldr	x8, [sp, #0xc0]
     c68:      	ldr	x9, [x29, #0x20]
     c6c:      	add	x22, sp, #0xe0
     c70:      	cmp	x8, x9
     c74:      	b.eq	0xd48 <generic_rawtp_process_event+0xb78>
     c78:      	ldr	x0, [sp, #0x48]
     c7c:      	add	x2, x25, #0x18
     c80:      	mov	w8, #0x4                // =4
     c84:      	mov	w1, #0x8                // =8
     c88:      	blr	x8
     c8c:      	ldr	x8, [x22, #0x20]
     c90:      	add	x9, x8, #0x20
     c94:      	stp	x9, x8, [sp, #0xb8]
     c98:      	b	0xb18 <generic_rawtp_process_event+0x948>
     c9c:      	cmp	w23, #0x2c
     ca0:      	b.hi	0xed0 <generic_rawtp_process_event+0xd00>
     ca4:      	mov	x9, #0x7cf2             // =31986
     ca8:      	mov	w8, #0x1                // =1
     cac:      	movk	x9, #0xf202, lsl #16
     cb0:      	lsl	x8, x8, x23
     cb4:      	movk	x9, #0x11c1, lsl #32
     cb8:      	tst	x8, x9
     cbc:      	b.eq	0xed0 <generic_rawtp_process_event+0xd00>
     cc0:      	add	x8, sp, #0xe0
     cc4:      	str	x22, [sp, #0x20]
     cc8:      	str	wzr, [sp, #0x88]
     ccc:      	add	x9, sp, #0x88
     cd0:      	add	x1, sp, #0x88
     cd4:      	mov	x0, x25
     cd8:      	str	x10, [x8]
     cdc:      	mov	w8, #0x1                // =1
     ce0:      	blr	x8
     ce4:      	mov	x22, xzr
     ce8:      	str	x21, [sp, #0x18]
     cec:      	cbz	x0, 0xe48 <generic_rawtp_process_event+0xc78>
     cf0:      	cmp	w23, #0x10
     cf4:      	b.le	0xf3c <generic_rawtp_process_event+0xd6c>
     cf8:      	cmp	w23, #0x1e
     cfc:      	b.le	0x104c <generic_rawtp_process_event+0xe7c>
     d00:      	cmp	w23, #0x26
     d04:      	b.gt	0x111c <generic_rawtp_process_event+0xf4c>
     d08:      	sub	w8, w23, #0x1f
     d0c:      	cmp	w8, #0x2
     d10:      	b.hs	0x14f4 <generic_rawtp_process_event+0x1324>
     d14:      	ldr	x0, [sp, #0x30]
     d18:      	mov	w8, #0x1                // =1
     d1c:      	add	x9, sp, #0xe0
     d20:      	mov	w10, #0x4               // =4
     d24:      	add	x2, sp, #0xe0
     d28:      	mov	w1, #0x1                // =1
     d2c:      	mov	w22, #0x4               // =4
     d30:      	blr	x10
     d34:      	b	0xe48 <generic_rawtp_process_event+0xc78>
     d38:      	mov	w8, #0x1                // =1
     d3c:      	strb	w8, [sp, #0xd4]
     d40:      	adrp	x25, 0x0 <generic_rawtp_setup_event>
     d44:      	b	0xd54 <generic_rawtp_process_event+0xb84>
     d48:      	mov	w8, #0x1                // =1
     d4c:      	adrp	x25, 0x0 <generic_rawtp_setup_event>
     d50:      	strb	w8, [sp, #0xd4]
     d54:      	ldr	x25, [x25]
     d58:      	ldr	x8, [sp, #0xc8]
     d5c:      	ldr	x2, [sp, #0x40]
     d60:      	cmp	x8, x2
     d64:      	b.eq	0xdac <generic_rawtp_process_event+0xbdc>
     d68:      	ldrb	w9, [sp, #0xd4]
     d6c:      	mov	w11, #0x1000            // =4096
     d70:      	cmp	w9, #0x0
     d74:      	ldr	w9, [sp, #0xd0]
     d78:      	cset	w10, eq
     d7c:      	sub	w11, w11, w9
     d80:      	cmp	w9, #0x0
     d84:      	csel	w9, w11, w9, gt
     d88:      	cbz	x8, 0xd98 <generic_rawtp_process_event+0xbc8>
     d8c:      	lsl	w21, w10, #1
     d90:      	mov	x2, x8
     d94:      	b	0xdb4 <generic_rawtp_process_event+0xbe4>
     d98:      	ldr	x23, [sp, #0x50]
     d9c:      	ldr	x24, [sp, #0x118]
     da0:      	mov	x22, xzr
     da4:      	mov	w21, #0x5efc            // =24316
     da8:      	b	0xe58 <generic_rawtp_process_event+0xc88>
     dac:      	mov	w21, wzr
     db0:      	mov	w9, wzr
     db4:      	ldr	x29, [sp, #0x30]
     db8:      	and	w22, w9, #0xfff
     dbc:      	mov	w8, #0x4                // =4
     dc0:      	mov	w23, #0x4               // =4
     dc4:      	mov	w1, w22
     dc8:      	add	x0, x29, #0x4
     dcc:      	blr	x8
     dd0:      	str	w22, [x29]
     dd4:      	ldr	x2, [sp, #0x28]
     dd8:      	mov	w24, #0x8               // =8
     ddc:      	add	x8, sp, #0x98
     de0:      	mov	w9, #0x4                // =4
     de4:      	add	x0, sp, #0x98
     de8:      	mov	w1, #0x8                // =8
     dec:      	blr	x9
     df0:      	ldr	x8, [sp, #0x98]
     df4:      	add	x9, sp, #0xf0
     df8:      	mov	w10, #0x4               // =4
     dfc:      	add	x0, sp, #0xf0
     e00:      	mov	w1, #0x8                // =8
     e04:      	add	x8, x8, #0x30
     e08:      	ldr	x8, [sp, #0x98]
     e0c:      	add	x2, x8, #0x30
     e10:      	blr	x10
     e14:      	add	x11, sp, #0xe0
     e18:      	mov	w9, #0x2                // =2
     e1c:      	add	x10, sp, #0x100
     e20:      	ldr	x8, [x11, #0x10]
     e24:      	add	x0, sp, #0x100
     e28:      	mov	w1, #0x2                // =2
     e2c:      	ldr	x2, [x11, #0x10]
     e30:      	blr	x23
     e34:      	add	x8, x29, x22
     e38:      	add	w22, w22, #0xa
     e3c:      	str	w21, [x8, #0x4]
     e40:      	ldrh	w9, [sp, #0x100]
     e44:      	strh	w9, [x8, #0x8]
     e48:      	ldr	x23, [sp, #0x50]
     e4c:      	ldr	x24, [sp, #0x118]
     e50:      	mov	w21, #0x5efc            // =24316
     e54:      	tbnz	w22, #0x1f, 0xe64 <generic_rawtp_process_event+0xc94>
     e58:      	and	w8, w22, #0x7fffffff
     e5c:      	add	w8, w8, #0x4
     e60:      	b	0xe7c <generic_rawtp_process_event+0xcac>
     e64:      	ldp	x9, x11, [sp, #0x18]
     e68:      	mov	w8, #-0x1               // =-1
     e6c:      	mov	w10, #0x5ea0            // =24224
     e70:      	str	w8, [x11, x10]
     e74:      	str	w8, [x9, x24]
     e78:      	mov	w8, #0x4                // =4
     e7c:      	add	w24, w8, w24
     e80:      	str	w24, [x20, #0x4]
     e84:      	adrp	x22, 0x0 <generic_rawtp_setup_event>
     e88:      	cmp	w23, #0x3
     e8c:      	ldr	x22, [x22]
     e90:      	b.le	0x62c <generic_rawtp_process_event+0x45c>
     e94:      	str	wzr, [x20, x21]
     e98:      	mov	w8, #0x3                // =3
     e9c:      	mov	w9, #0xc                // =12
     ea0:      	mov	x0, x19
     ea4:      	mov	x1, x22
     ea8:      	mov	w2, #0x3                // =3
     eac:      	blr	x9
     eb0:      	ldp	x20, x19, [sp, #0x150]
     eb4:      	mov	w0, wzr
     eb8:      	ldr	x29, [sp, #0x110]
     ebc:      	ldp	x22, x21, [sp, #0x140]
     ec0:      	ldp	x24, x23, [sp, #0x130]
     ec4:      	ldp	x30, x25, [sp, #0x120]
     ec8:      	add	sp, sp, #0x160
     ecc:      	ret
     ed0:      	str	x22, [sp, #0x20]
     ed4:      	str	wzr, [sp, #0x88]
     ed8:      	mov	w8, #0x1                // =1
     edc:      	add	x9, sp, #0x88
     ee0:      	add	x1, sp, #0x88
     ee4:      	mov	x0, x25
     ee8:      	blr	x8
     eec:      	mov	x22, xzr
     ef0:      	str	x21, [sp, #0x18]
     ef4:      	cbz	x0, 0xe48 <generic_rawtp_process_event+0xc78>
     ef8:      	cmp	w23, #0x19
     efc:      	b.gt	0x10f4 <generic_rawtp_process_event+0xf24>
     f00:      	cmp	w23, #0x12
     f04:      	b.le	0x11e0 <generic_rawtp_process_event+0x1010>
     f08:      	cmp	w23, #0x14
     f0c:      	b.le	0x1458 <generic_rawtp_process_event+0x1288>
     f10:      	cmp	w23, #0x15
     f14:      	b.eq	0x1b78 <generic_rawtp_process_event+0x19a8>
     f18:      	cmp	w23, #0x16
     f1c:      	b.eq	0x1b18 <generic_rawtp_process_event+0x1948>
     f20:      	ldr	x9, [sp, #0x48]
     f24:      	cmp	w23, #0x17
     f28:      	b.ne	0xe48 <generic_rawtp_process_event+0xc78>
     f2c:      	ldr	x8, [sp, #0x30]
     f30:      	mov	w22, #0x8               // =8
     f34:      	stp	w9, wzr, [x8]
     f38:      	b	0xe48 <generic_rawtp_process_event+0xc78>
     f3c:      	cmp	w23, #0x9
     f40:      	b.gt	0x1078 <generic_rawtp_process_event+0xea8>
     f44:      	cmp	w23, #0x4
     f48:      	b.le	0x1258 <generic_rawtp_process_event+0x1088>
     f4c:      	cmp	w23, #0x5
     f50:      	b.eq	0x1738 <generic_rawtp_process_event+0x1568>
     f54:      	ldr	x21, [sp, #0x30]
     f58:      	cmp	w23, #0x6
     f5c:      	b.eq	0x10d8 <generic_rawtp_process_event+0xf08>
     f60:      	cmp	w23, #0x7
     f64:      	b.ne	0xe48 <generic_rawtp_process_event+0xc78>
     f68:      	add	x8, sp, #0xe0
     f6c:      	mov	x24, x0
     f70:      	add	x0, x21, #0x26
     f74:      	ldr	x23, [x8]
     f78:      	mov	w22, #0x2               // =2
     f7c:      	mov	w8, #0x4                // =4
     f80:      	mov	w1, #0x2                // =2
     f84:      	mov	x25, x21
     f88:      	str	x23, [x21, #0x28]
     f8c:      	add	x2, x23, #0x10
     f90:      	mov	w21, #0x4               // =4
     f94:      	blr	x8
     f98:      	add	x0, x25, #0x3a
     f9c:      	add	x2, x23, #0x12
     fa0:      	mov	w8, #0x1                // =1
     fa4:      	mov	w9, #0x4                // =4
     fa8:      	mov	w1, #0x1                // =1
     fac:      	blr	x9
     fb0:      	add	x0, x25, #0x38
     fb4:      	add	x2, x23, #0x21e
     fb8:      	mov	w8, #0x4                // =4
     fbc:      	mov	w1, #0x2                // =2
     fc0:      	blr	x8
     fc4:      	add	x0, x25, #0x24
     fc8:      	add	x2, x23, #0x21c
     fcc:      	mov	w8, #0x4                // =4
     fd0:      	mov	w1, #0x2                // =2
     fd4:      	blr	x8
     fd8:      	add	x0, x25, #0x30
     fdc:      	add	x2, x23, #0x214
     fe0:      	mov	w8, #0x4                // =4
     fe4:      	mov	w1, #0x4                // =4
     fe8:      	blr	x8
     fec:      	add	x0, x25, #0x34
     ff0:      	add	x2, x23, #0x210
     ff4:      	mov	w1, #0x4                // =4
     ff8:      	blr	x21
     ffc:      	ldrh	w8, [x25, #0x26]
    1000:      	mov	x22, x25
    1004:      	stp	xzr, xzr, [x25]
    1008:      	cmp	w8, #0xa
    100c:      	str	xzr, [x25, #0x18]
    1010:      	str	xzr, [x22, #0x10]!
    1014:      	b.eq	0x1f58 <generic_rawtp_process_event+0x1d88>
    1018:      	cmp	w8, #0x2
    101c:      	b.ne	0x1f84 <generic_rawtp_process_event+0x1db4>
    1020:      	ldr	x0, [sp, #0x30]
    1024:      	add	x2, x23, #0x4
    1028:      	mov	w8, #0x4                // =4
    102c:      	mov	w1, #0x4                // =4
    1030:      	mov	w21, #0x4               // =4
    1034:      	blr	x8
    1038:      	mov	x0, x22
    103c:      	mov	w1, #0x4                // =4
    1040:      	mov	x2, x23
    1044:      	blr	x21
    1048:      	b	0x1f84 <generic_rawtp_process_event+0x1db4>
    104c:      	cmp	w23, #0x1c
    1050:      	b.gt	0x1234 <generic_rawtp_process_event+0x1064>
    1054:      	cmp	w23, #0x11
    1058:      	b.eq	0x1524 <generic_rawtp_process_event+0x1354>
    105c:      	cmp	w23, #0x19
    1060:      	str	x0, [sp, #0x48]
    1064:      	b.eq	0x15e0 <generic_rawtp_process_event+0x1410>
    1068:      	ldr	x0, [sp, #0x30]
    106c:      	cmp	w23, #0x1c
    1070:      	b.eq	0x126c <generic_rawtp_process_event+0x109c>
    1074:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    1078:      	ldr	x0, [sp, #0x30]
    107c:      	sub	w8, w23, #0xa
    1080:      	cmp	w8, #0x2
    1084:      	b.lo	0x126c <generic_rawtp_process_event+0x109c>
    1088:      	sub	w8, w23, #0xc
    108c:      	cmp	w8, #0x2
    1090:      	b.lo	0x1288 <generic_rawtp_process_event+0x10b8>
    1094:      	cmp	w23, #0xe
    1098:      	b.ne	0xe48 <generic_rawtp_process_event+0xc78>
    109c:      	mov	w21, #0x8               // =8
    10a0:      	add	x8, sp, #0x98
    10a4:      	add	x23, sp, #0xe0
    10a8:      	mov	w9, #0x4                // =4
    10ac:      	add	x0, sp, #0x98
    10b0:      	add	x2, sp, #0xe0
    10b4:      	mov	w1, #0x8                // =8
    10b8:      	mov	w22, #0x4               // =4
    10bc:      	blr	x9
    10c0:      	ldr	x8, [sp, #0x98]
    10c4:      	add	x0, sp, #0xe0
    10c8:      	mov	w1, #0x8                // =8
    10cc:      	ldr	x2, [sp, #0x98]
    10d0:      	ldr	x21, [sp, #0x30]
    10d4:      	blr	x22
    10d8:      	add	x8, sp, #0xe0
    10dc:      	add	x0, x21, #0x4
    10e0:      	mov	w9, #0x2d               // =45
    10e4:      	ldr	x2, [x8]
    10e8:      	mov	w8, #0x1001             // =4097
    10ec:      	mov	w1, #0x1001             // =4097
    10f0:      	b	0x18b4 <generic_rawtp_process_event+0x16e4>
    10f4:      	ldr	x2, [sp, #0x48]
    10f8:      	cmp	w23, #0x20
    10fc:      	b.le	0x13b4 <generic_rawtp_process_event+0x11e4>
    1100:      	sub	w8, w23, #0x21
    1104:      	cmp	w8, #0x4
    1108:      	b.hs	0x12a4 <generic_rawtp_process_event+0x10d4>
    110c:      	ldr	x0, [sp, #0x30]
    1110:      	mov	w22, #0x8               // =8
    1114:      	mov	w8, #0x4                // =4
    1118:      	b	0x127c <generic_rawtp_process_event+0x10ac>
    111c:      	cmp	w23, #0x27
    1120:      	b.eq	0x1894 <generic_rawtp_process_event+0x16c4>
    1124:      	cmp	w23, #0x28
    1128:      	b.eq	0x18d0 <generic_rawtp_process_event+0x1700>
    112c:      	ldr	x0, [sp, #0x30]
    1130:      	cmp	w23, #0x2c
    1134:      	b.ne	0xe48 <generic_rawtp_process_event+0xc78>
    1138:      	add	x8, sp, #0xe0
    113c:      	strb	wzr, [sp, #0x98]
    1140:      	stp	xzr, xzr, [x0, #0x10]
    1144:      	mov	w9, #0x4                // =4
    1148:      	mov	w1, #0x2                // =2
    114c:      	ldr	x22, [x8]
    1150:      	mov	w8, #0x2                // =2
    1154:      	mov	x2, x22
    1158:      	stp	xzr, xzr, [x0]
    115c:      	stp	xzr, xzr, [x0, #0x20]
    1160:      	stp	xzr, xzr, [x0, #0x30]
    1164:      	stp	xzr, xzr, [x0, #0x40]
    1168:      	stp	xzr, xzr, [x0, #0x50]
    116c:      	stp	xzr, xzr, [x0, #0x60]
    1170:      	blr	x9
    1174:      	tbnz	x0, #0x3f, 0x2184 <generic_rawtp_process_event+0x1fb4>
    1178:      	add	x23, x22, #0x2
    117c:      	mov	w8, #0x1                // =1
    1180:      	mov	w9, #0x4                // =4
    1184:      	add	x10, sp, #0x98
    1188:      	add	x0, sp, #0x98
    118c:      	mov	w1, #0x1                // =1
    1190:      	mov	x2, x23
    1194:      	blr	x9
    1198:      	tbnz	x0, #0x3f, 0x2184 <generic_rawtp_process_event+0x1fb4>
    119c:      	ldrb	w8, [sp, #0x98]
    11a0:      	ldr	x10, [sp, #0x30]
    11a4:      	cmp	w8, #0x0
    11a8:      	add	x0, x10, #0x4
    11ac:      	cset	w9, eq
    11b0:      	strb	w9, [x10, #0x2]
    11b4:      	cbz	w8, 0x215c <generic_rawtp_process_event+0x1f8c>
    11b8:      	mov	w8, #0x6c               // =108
    11bc:      	mov	w9, #0x2d               // =45
    11c0:      	mov	w1, #0x6c               // =108
    11c4:      	mov	x2, x23
    11c8:      	blr	x9
    11cc:      	adrp	x25, 0x1000 <generic_rawtp_process_event+0xe30>
    11d0:      	ldr	x25, [x25]
    11d4:      	tbnz	w0, #0x1f, 0x2184 <generic_rawtp_process_event+0x1fb4>
    11d8:      	sub	w21, w0, #0x1
    11dc:      	b	0x217c <generic_rawtp_process_event+0x1fac>
    11e0:      	cmp	w23, #0x7
    11e4:      	b.gt	0x142c <generic_rawtp_process_event+0x125c>
    11e8:      	cmp	w23, #0x2
    11ec:      	b.eq	0x194c <generic_rawtp_process_event+0x177c>
    11f0:      	cmp	w23, #0x3
    11f4:      	b.ne	0xe48 <generic_rawtp_process_event+0xc78>
    11f8:      	ldr	x8, [sp, #0x40]
    11fc:      	add	x23, x0, #0x90
    1200:      	mov	x24, x0
    1204:      	add	x25, x23, x29
    1208:      	and	w8, w8, #0xf
    120c:      	cmp	w8, #0x2
    1210:      	b.le	0x20ec <generic_rawtp_process_event+0x1f1c>
    1214:      	cmp	w8, #0x3
    1218:      	b.eq	0x2258 <generic_rawtp_process_event+0x2088>
    121c:      	cmp	w8, #0x4
    1220:      	b.eq	0x2260 <generic_rawtp_process_event+0x2090>
    1224:      	cmp	w8, #0x5
    1228:      	b.ne	0x22b4 <generic_rawtp_process_event+0x20e4>
    122c:      	mov	w8, #0x5e70             // =24176
    1230:      	b	0x226c <generic_rawtp_process_event+0x209c>
    1234:      	ldr	x0, [sp, #0x30]
    1238:      	mov	w8, #0x2                // =2
    123c:      	add	x9, sp, #0xe0
    1240:      	mov	w10, #0x4               // =4
    1244:      	add	x2, sp, #0xe0
    1248:      	mov	w1, #0x2                // =2
    124c:      	mov	w22, #0x4               // =4
    1250:      	blr	x10
    1254:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    1258:      	ldr	x0, [sp, #0x30]
    125c:      	cmp	w23, #0x1
    1260:      	b.eq	0x1288 <generic_rawtp_process_event+0x10b8>
    1264:      	cmp	w23, #0x4
    1268:      	b.ne	0xe48 <generic_rawtp_process_event+0xc78>
    126c:      	mov	w22, #0x8               // =8
    1270:      	mov	w8, #0x4                // =4
    1274:      	add	x9, sp, #0xe0
    1278:      	add	x2, sp, #0xe0
    127c:      	mov	w1, #0x8                // =8
    1280:      	blr	x8
    1284:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    1288:      	add	x8, sp, #0xe0
    128c:      	mov	w9, #0x4                // =4
    1290:      	add	x2, sp, #0xe0
    1294:      	mov	w1, #0x4                // =4
    1298:      	mov	w22, #0x4               // =4
    129c:      	blr	x9
    12a0:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    12a4:      	cmp	w23, #0x2b
    12a8:      	b.eq	0x1c34 <generic_rawtp_process_event+0x1a64>
    12ac:      	cmp	w23, #0x29
    12b0:      	b.ne	0xe48 <generic_rawtp_process_event+0xc78>
    12b4:      	add	x2, x2, #0x18
    12b8:      	mov	w8, #0x8                // =8
    12bc:      	mov	w9, #0x4                // =4
    12c0:      	add	x10, sp, #0x98
    12c4:      	mov	x24, x0
    12c8:      	add	x0, sp, #0x98
    12cc:      	mov	w1, #0x8                // =8
    12d0:      	blr	x9
    12d4:      	ldr	x23, [sp, #0x98]
    12d8:      	cbz	x23, 0x2214 <generic_rawtp_process_event+0x2044>
    12dc:      	ldr	x25, [sp, #0x30]
    12e0:      	add	x2, x23, #0x10
    12e4:      	mov	w22, #0x2               // =2
    12e8:      	mov	w8, #0x4                // =4
    12ec:      	str	x23, [x25, #0x28]
    12f0:      	add	x0, x25, #0x26
    12f4:      	mov	w1, #0x2                // =2
    12f8:      	mov	w21, #0x4               // =4
    12fc:      	blr	x8
    1300:      	add	x0, x25, #0x3a
    1304:      	add	x2, x23, #0x12
    1308:      	mov	w8, #0x1                // =1
    130c:      	mov	w9, #0x4                // =4
    1310:      	mov	w1, #0x1                // =1
    1314:      	blr	x9
    1318:      	add	x0, x25, #0x38
    131c:      	add	x2, x23, #0x21e
    1320:      	mov	w8, #0x4                // =4
    1324:      	mov	w1, #0x2                // =2
    1328:      	blr	x8
    132c:      	add	x0, x25, #0x24
    1330:      	add	x2, x23, #0x21c
    1334:      	mov	w8, #0x4                // =4
    1338:      	mov	w1, #0x2                // =2
    133c:      	blr	x8
    1340:      	add	x0, x25, #0x30
    1344:      	add	x2, x23, #0x214
    1348:      	mov	w8, #0x4                // =4
    134c:      	mov	w1, #0x4                // =4
    1350:      	blr	x8
    1354:      	add	x0, x25, #0x34
    1358:      	add	x2, x23, #0x210
    135c:      	mov	w1, #0x4                // =4
    1360:      	blr	x21
    1364:      	ldrh	w8, [x25, #0x26]
    1368:      	mov	x22, x25
    136c:      	stp	xzr, xzr, [x25]
    1370:      	cmp	w8, #0xa
    1374:      	str	xzr, [x25, #0x18]
    1378:      	str	xzr, [x22, #0x10]!
    137c:      	b.eq	0x21a4 <generic_rawtp_process_event+0x1fd4>
    1380:      	cmp	w8, #0x2
    1384:      	b.ne	0x21d0 <generic_rawtp_process_event+0x2000>
    1388:      	ldr	x0, [sp, #0x30]
    138c:      	add	x2, x23, #0x4
    1390:      	mov	w8, #0x4                // =4
    1394:      	mov	w1, #0x4                // =4
    1398:      	mov	w21, #0x4               // =4
    139c:      	blr	x8
    13a0:      	mov	x0, x22
    13a4:      	mov	w1, #0x4                // =4
    13a8:      	mov	x2, x23
    13ac:      	blr	x21
    13b0:      	b	0x21d0 <generic_rawtp_process_event+0x2000>
    13b4:      	cmp	w23, #0x1a
    13b8:      	b.eq	0x1cc4 <generic_rawtp_process_event+0x1af4>
    13bc:      	cmp	w23, #0x1b
    13c0:      	b.ne	0xe48 <generic_rawtp_process_event+0xc78>
    13c4:      	ldr	x10, [sp, #0x30]
    13c8:      	add	x2, x2, #0x18
    13cc:      	mov	w8, #0x3f               // =63
    13d0:      	mov	w9, #0x2d               // =45
    13d4:      	stp	xzr, xzr, [x10, #0x40]
    13d8:      	mov	x0, x10
    13dc:      	stp	xzr, xzr, [x10, #0x30]
    13e0:      	stp	xzr, xzr, [x10, #0x20]
    13e4:      	str	xzr, [x10, #0x18]
    13e8:      	stp	xzr, xzr, [x10]
    13ec:      	mov	w1, #0x3f               // =63
    13f0:      	str	xzr, [x0, #0x10]!
    13f4:      	blr	x9
    13f8:      	tbnz	x0, #0x3f, 0x2004 <generic_rawtp_process_event+0x1e34>
    13fc:      	ldr	x8, [sp, #0x30]
    1400:      	mov	w9, #0x4                // =4
    1404:      	mov	w1, #0x8                // =8
    1408:      	add	x0, x8, #0x8
    140c:      	ldr	x8, [sp, #0x48]
    1410:      	add	x2, x8, #0x360
    1414:      	mov	w8, #0x8                // =8
    1418:      	blr	x9
    141c:      	adrp	x25, 0x1000 <generic_rawtp_process_event+0xe30>
    1420:      	mov	w22, #0x50              // =80
    1424:      	ldr	x25, [x25]
    1428:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    142c:      	cmp	w23, #0x8
    1430:      	b.eq	0x1998 <generic_rawtp_process_event+0x17c8>
    1434:      	ldr	x2, [sp, #0x48]
    1438:      	cmp	w23, #0x12
    143c:      	b.ne	0xe48 <generic_rawtp_process_event+0xc78>
    1440:      	ldr	x8, [sp, #0x40]
    1444:      	ldr	x0, [sp, #0x30]
    1448:      	and	x22, x8, #0x3ff
    144c:      	mov	w8, #0x4                // =4
    1450:      	mov	w1, w22
    1454:      	b	0x1280 <generic_rawtp_process_event+0x10b0>
    1458:      	cmp	w23, #0x13
    145c:      	b.eq	0x1bf0 <generic_rawtp_process_event+0x1a20>
    1460:      	ldr	x29, [sp, #0x48]
    1464:      	cmp	w23, #0x14
    1468:      	b.ne	0xe48 <generic_rawtp_process_event+0xc78>
    146c:      	str	xzr, [sp, #0x98]
    1470:      	add	x2, x29, #0x110
    1474:      	mov	w23, #0x8               // =8
    1478:      	add	x8, sp, #0x98
    147c:      	mov	w9, #0x4                // =4
    1480:      	add	x0, sp, #0x98
    1484:      	mov	w1, #0x8                // =8
    1488:      	add	x22, x29, #0xd8
    148c:      	mov	w21, #0x4               // =4
    1490:      	blr	x9
    1494:      	ldr	x8, [sp, #0x98]
    1498:      	mov	w9, #0x80               // =128
    149c:      	mov	w10, #0x2d              // =45
    14a0:      	ldr	x24, [sp, #0x30]
    14a4:      	mov	w1, #0x80               // =128
    14a8:      	mov	x0, x24
    14ac:      	ldr	x2, [sp, #0x98]
    14b0:      	blr	x10
    14b4:      	add	x0, x24, #0x90
    14b8:      	mov	w8, #0x4                // =4
    14bc:      	mov	w1, #0x4                // =4
    14c0:      	mov	x2, x22
    14c4:      	blr	x8
    14c8:      	add	x0, x24, #0x80
    14cc:      	add	x2, x29, #0xe0
    14d0:      	mov	w8, #0x4                // =4
    14d4:      	mov	w1, #0x8                // =8
    14d8:      	blr	x8
    14dc:      	add	x0, x24, #0x88
    14e0:      	add	x2, x29, #0x118
    14e4:      	mov	w1, #0x8                // =8
    14e8:      	blr	x21
    14ec:      	mov	w22, #0x98              // =152
    14f0:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    14f4:      	ldr	x21, [sp, #0x30]
    14f8:      	cmp	w23, #0x26
    14fc:      	b.ne	0xe48 <generic_rawtp_process_event+0xc78>
    1500:      	add	x8, sp, #0xe0
    1504:      	add	x0, x21, #0x4
    1508:      	ldr	x8, [x8]
    150c:      	add	x2, x19, w8, uxth
    1510:      	ubfx	w8, w8, #16, #12
    1514:      	add	w1, w8, #0x1
    1518:      	mov	w8, #0x2d               // =45
    151c:      	blr	x8
    1520:      	b	0x18b8 <generic_rawtp_process_event+0x16e8>
    1524:      	str	xzr, [sp, #0xa0]
    1528:      	mov	w8, #0xe                // =14
    152c:      	blr	x8
    1530:      	lsr	x8, x0, #32
    1534:      	add	x9, sp, #0xf0
    1538:      	add	x10, sp, #0xe0
    153c:      	str	x8, [sp, #0x98]
    1540:      	mov	w8, #0x4                // =4
    1544:      	add	x0, sp, #0xf0
    1548:      	add	x2, sp, #0xe0
    154c:      	mov	w1, #0x4                // =4
    1550:      	blr	x8
    1554:      	ldr	w8, [sp, #0xf0]
    1558:      	adrp	x0, 0x1000 <generic_rawtp_process_event+0xe30>
    155c:      	add	x9, sp, #0x98
    1560:      	add	x1, sp, #0x98
    1564:      	str	w8, [sp, #0xa0]
    1568:      	mov	w8, #0x1                // =1
    156c:      	ldr	x0, [x0]
    1570:      	blr	x8
    1574:      	cbz	x0, 0x1da8 <generic_rawtp_process_event+0x1bd8>
    1578:      	ldr	x24, [sp, #0x30]
    157c:      	ldr	w21, [x0]
    1580:      	add	x8, sp, #0xf0
    1584:      	mov	w9, #0x4                // =4
    1588:      	add	x2, sp, #0xf0
    158c:      	mov	x22, x0
    1590:      	mov	w1, #0x4                // =4
    1594:      	mov	w23, #0x4               // =4
    1598:      	mov	x0, x24
    159c:      	blr	x9
    15a0:      	and	x21, x21, #0xfff
    15a4:      	add	x0, x24, #0x4
    15a8:      	mov	w8, #0x4                // =4
    15ac:      	mov	x2, x22
    15b0:      	add	x1, x21, #0x4
    15b4:      	blr	x8
    15b8:      	add	w21, w21, #0x8
    15bc:      	mov	w1, #0x4                // =4
    15c0:      	add	x8, x21, x22
    15c4:      	add	x0, x24, x21
    15c8:      	sub	x2, x8, #0x4
    15cc:      	blr	x23
    15d0:      	adrp	x25, 0x1000 <generic_rawtp_process_event+0xe30>
    15d4:      	add	x22, x21, #0x4
    15d8:      	ldr	x25, [x25]
    15dc:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    15e0:      	add	x8, sp, #0xe0
    15e4:      	mov	w9, #0x4                // =4
    15e8:      	add	x10, sp, #0x84
    15ec:      	ldr	x22, [x8]
    15f0:      	mov	w8, #0x1                // =1
    15f4:      	add	x0, sp, #0x84
    15f8:      	mov	w1, #0x1                // =1
    15fc:      	mov	x2, x22
    1600:      	blr	x9
    1604:      	ldrb	w8, [sp, #0x84]
    1608:      	cbz	w8, 0x1db8 <generic_rawtp_process_event+0x1be8>
    160c:      	cmp	w8, #0x1
    1610:      	b.ne	0x1fe8 <generic_rawtp_process_event+0x1e18>
    1614:      	add	x2, x22, #0x10
    1618:      	mov	w23, #0x8               // =8
    161c:      	add	x8, sp, #0xf0
    1620:      	mov	w9, #0x4                // =4
    1624:      	add	x0, sp, #0xf0
    1628:      	mov	w1, #0x8                // =8
    162c:      	mov	w21, #0x4               // =4
    1630:      	blr	x9
    1634:      	add	x22, sp, #0xe0
    1638:      	add	x8, sp, #0x100
    163c:      	mov	w9, #0x4                // =4
    1640:      	ldr	x2, [x22, #0x10]
    1644:      	add	x0, sp, #0x100
    1648:      	mov	w1, #0x8                // =8
    164c:      	blr	x9
    1650:      	ldr	x8, [x22, #0x10]
    1654:      	add	x0, sp, #0xe8
    1658:      	mov	w1, #0x8                // =8
    165c:      	add	x2, x8, #0x8
    1660:      	add	x8, sp, #0xe8
    1664:      	blr	x21
    1668:      	ldr	x8, [sp, #0x48]
    166c:      	ldr	x25, [x22, #0x20]
    1670:      	add	x8, x8, #0x90
    1674:      	ldr	x22, [x22, #0x8]
    1678:      	add	x29, x8, x29
    167c:      	tbz	w24, #0x5, 0x23c0 <generic_rawtp_process_event+0x21f0>
    1680:      	cmp	x22, #0x1, lsl #12      // =0x1000
    1684:      	b.lo	0x23a8 <generic_rawtp_process_event+0x21d8>
    1688:      	mov	w8, #0x1                // =1
    168c:      	adrp	x0, 0x1000 <generic_rawtp_process_event+0xe30>
    1690:      	add	x9, sp, #0x90
    1694:      	str	w8, [x29]
    1698:      	str	wzr, [sp, #0x90]
    169c:      	add	x1, sp, #0x90
    16a0:      	ldr	x0, [x0]
    16a4:      	blr	x8
    16a8:      	cbz	x0, 0x2880 <generic_rawtp_process_event+0x26b0>
    16ac:      	mov	w8, #0x18               // =24
    16b0:      	mov	x24, x0
    16b4:      	str	w8, [x0]
    16b8:      	mov	w8, #0xe                // =14
    16bc:      	blr	x8
    16c0:      	mov	x21, x24
    16c4:      	cmn	x0, #0x16
    16c8:      	str	x0, [x21, #0x10]!
    16cc:      	b.ne	0x16f4 <generic_rawtp_process_event+0x1524>
    16d0:      	add	x2, x19, #0xe8
    16d4:      	mov	w8, #0x8                // =8
    16d8:      	mov	w9, #0x4                // =4
    16dc:      	add	x10, sp, #0x98
    16e0:      	add	x0, sp, #0x98
    16e4:      	mov	w1, #0x8                // =8
    16e8:      	blr	x9
    16ec:      	ldr	x8, [sp, #0x98]
    16f0:      	str	x8, [x21]
    16f4:      	mov	w8, #0x7d               // =125
    16f8:      	blr	x8
    16fc:      	str	x0, [x24, #0x18]
    1700:      	mov	x0, x19
    1704:      	mov	x1, x24
    1708:      	mov	x2, x25
    170c:      	ldp	x8, x9, [x21]
    1710:      	mov	x3, x22
    1714:      	stur	x9, [x29, #0x1c]
    1718:      	stur	x8, [x29, #0x14]
    171c:      	bl	0x171c <generic_rawtp_process_event+0x154c>
    1720:      	tbnz	w0, #0x1f, 0x1eac <generic_rawtp_process_event+0x1cdc>
    1724:      	sub	w8, w22, w0
    1728:      	cmn	x22, #0x1
    172c:      	stur	xzr, [x29, #0x4]
    1730:      	csel	w8, wzr, w8, eq
    1734:      	b	0x1eb8 <generic_rawtp_process_event+0x1ce8>
    1738:      	add	x8, sp, #0xe0
    173c:      	ldr	x21, [sp, #0x30]
    1740:      	mov	w1, #0x4                // =4
    1744:      	mov	w23, #0x4               // =4
    1748:      	ldr	x24, [x8]
    174c:      	mov	w8, #0x4                // =4
    1750:      	add	x0, x21, #0x28
    1754:      	add	x2, x24, #0x98
    1758:      	blr	x8
    175c:      	add	x0, x21, #0x2c
    1760:      	add	x2, x24, #0x70
    1764:      	mov	w8, #0x4                // =4
    1768:      	mov	w1, #0x4                // =4
    176c:      	blr	x8
    1770:      	add	x0, x21, #0x30
    1774:      	add	x2, x24, #0x90
    1778:      	mov	w8, #0x4                // =4
    177c:      	mov	w1, #0x4                // =4
    1780:      	blr	x8
    1784:      	add	x0, x21, #0x34
    1788:      	add	x2, x24, #0xa8
    178c:      	mov	w8, #0x4                // =4
    1790:      	mov	w1, #0x4                // =4
    1794:      	blr	x8
    1798:      	str	xzr, [sp, #0x98]
    179c:      	add	x2, x24, #0xc8
    17a0:      	mov	w8, #0x8                // =8
    17a4:      	add	x9, sp, #0x98
    17a8:      	mov	w10, #0x4               // =4
    17ac:      	add	x0, sp, #0x98
    17b0:      	mov	w1, #0x8                // =8
    17b4:      	blr	x10
    17b8:      	add	x2, x24, #0xb8
    17bc:      	mov	w8, #0x2                // =2
    17c0:      	add	x9, sp, #0xe8
    17c4:      	mov	w10, #0x4               // =4
    17c8:      	add	x0, sp, #0xe8
    17cc:      	mov	w1, #0x2                // =2
    17d0:      	blr	x10
    17d4:      	ldr	x8, [sp, #0x98]
    17d8:      	ldrh	w9, [sp, #0xe8]
    17dc:      	add	x0, sp, #0xdc
    17e0:      	mov	w1, #0x1                // =1
    17e4:      	add	x22, x8, x9
    17e8:      	mov	w8, #0x1                // =1
    17ec:      	add	x9, sp, #0xdc
    17f0:      	mov	x2, x22
    17f4:      	blr	x23
    17f8:      	ldrb	w8, [sp, #0xdc]
    17fc:      	lsr	w8, w8, #4
    1800:      	cmp	w8, #0x6
    1804:      	b.eq	0x1ecc <generic_rawtp_process_event+0x1cfc>
    1808:      	cmp	w8, #0x4
    180c:      	b.ne	0x2fb0 <generic_rawtp_process_event+0x2de0>
    1810:      	add	x2, x22, #0x9
    1814:      	mov	w8, #0x1                // =1
    1818:      	add	x9, sp, #0x84
    181c:      	mov	w10, #0x4               // =4
    1820:      	add	x0, sp, #0x84
    1824:      	mov	w1, #0x1                // =1
    1828:      	mov	w21, #0x4               // =4
    182c:      	blr	x10
    1830:      	ldr	x0, [sp, #0x30]
    1834:      	ldrb	w8, [sp, #0x84]
    1838:      	mov	w25, #0x2               // =2
    183c:      	add	x2, x22, #0xc
    1840:      	mov	w1, #0x4                // =4
    1844:      	mov	x23, x0
    1848:      	strh	w8, [x0, #0x24]
    184c:      	strh	w25, [x0, #0x26]
    1850:      	stp	xzr, xzr, [x0]
    1854:      	str	xzr, [x0, #0x18]
    1858:      	mov	w8, #0x4                // =4
    185c:      	str	xzr, [x23, #0x10]!
    1860:      	blr	x8
    1864:      	add	x2, x22, #0x10
    1868:      	mov	w8, #0x4                // =4
    186c:      	mov	x0, x23
    1870:      	mov	w1, #0x4                // =4
    1874:      	blr	x8
    1878:      	add	x2, x24, #0xb6
    187c:      	add	x8, sp, #0x90
    1880:      	add	x0, sp, #0x90
    1884:      	mov	w1, #0x2                // =2
    1888:      	blr	x21
    188c:      	ldrb	w29, [sp, #0x84]
    1890:      	b	0x2e74 <generic_rawtp_process_event+0x2ca4>
    1894:      	add	x8, sp, #0xe0
    1898:      	ldr	x21, [sp, #0x30]
    189c:      	mov	w9, #0x2d               // =45
    18a0:      	mov	w1, #0x11               // =17
    18a4:      	ldr	x8, [x8]
    18a8:      	add	x0, x21, #0x4
    18ac:      	add	x2, x8, #0x118
    18b0:      	mov	w8, #0x11               // =17
    18b4:      	blr	x9
    18b8:      	mov	x22, x0
    18bc:      	tbnz	x0, #0x3f, 0xe48 <generic_rawtp_process_event+0xc78>
    18c0:      	sub	w8, w22, #0x1
    18c4:      	add	x22, x22, #0x3
    18c8:      	str	w8, [x21]
    18cc:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    18d0:      	ldr	x21, [sp, #0x30]
    18d4:      	add	x8, sp, #0xe0
    18d8:      	mov	w9, #0x4                // =4
    18dc:      	mov	w1, #0x2                // =2
    18e0:      	ldr	x22, [x8]
    18e4:      	mov	w8, #0x2                // =2
    18e8:      	str	xzr, [x21]
    18ec:      	stp	xzr, xzr, [x21, #0x8]
    18f0:      	mov	x0, x21
    18f4:      	mov	x2, x22
    18f8:      	blr	x9
    18fc:      	tbnz	x0, #0x3f, 0x2154 <generic_rawtp_process_event+0x1f84>
    1900:      	ldrh	w8, [x21]
    1904:      	cmp	w8, #0xa
    1908:      	b.eq	0x2104 <generic_rawtp_process_event+0x1f34>
    190c:      	cmp	w8, #0x2
    1910:      	b.ne	0x2138 <generic_rawtp_process_event+0x1f68>
    1914:      	add	x2, x22, #0x4
    1918:      	add	x8, sp, #0x98
    191c:      	mov	w9, #0x4                // =4
    1920:      	add	x0, sp, #0x98
    1924:      	mov	w1, #0x4                // =4
    1928:      	mov	w21, #0x4               // =4
    192c:      	blr	x9
    1930:      	ldr	w8, [sp, #0x98]
    1934:      	ldr	x9, [sp, #0x30]
    1938:      	add	x2, x22, #0x2
    193c:      	add	x0, x9, #0x2
    1940:      	str	x8, [x9, #0x8]
    1944:      	mov	w8, #0x2                // =2
    1948:      	b	0x2130 <generic_rawtp_process_event+0x1f60>
    194c:      	add	x23, x0, #0x90
    1950:      	mov	x22, x0
    1954:      	add	x8, sp, #0xe0
    1958:      	str	xzr, [x8]
    195c:      	add	x25, x23, x29
    1960:      	tbnz	w24, #0x4, 0x2014 <generic_rawtp_process_event+0x1e44>
    1964:      	and	w9, w24, #0xf
    1968:      	mov	x8, xzr
    196c:      	and	x29, x24, #0xffffffff
    1970:      	cmp	w9, #0x2
    1974:      	b.le	0x218c <generic_rawtp_process_event+0x1fbc>
    1978:      	cmp	w9, #0x3
    197c:      	b.eq	0x24a0 <generic_rawtp_process_event+0x22d0>
    1980:      	cmp	w9, #0x4
    1984:      	b.eq	0x24a8 <generic_rawtp_process_event+0x22d8>
    1988:      	cmp	w9, #0x5
    198c:      	b.ne	0x24bc <generic_rawtp_process_event+0x22ec>
    1990:      	mov	w8, #0x5e70             // =24176
    1994:      	b	0x24b4 <generic_rawtp_process_event+0x22e4>
    1998:      	ldr	x29, [sp, #0x30]
    199c:      	ldr	x24, [sp, #0x48]
    19a0:      	mov	w1, #0x4                // =4
    19a4:      	mov	w23, #0x4               // =4
    19a8:      	add	x8, x29, #0x40
    19ac:      	add	x2, x24, #0x8
    19b0:      	mov	x0, x29
    19b4:      	add	x22, x29, #0x28
    19b8:      	str	x8, [sp, #0x40]
    19bc:      	mov	w8, #0x4                // =4
    19c0:      	blr	x8
    19c4:      	add	x0, x29, #0x4
    19c8:      	add	x2, x24, #0xc
    19cc:      	mov	w8, #0x4                // =4
    19d0:      	mov	w1, #0x4                // =4
    19d4:      	blr	x8
    19d8:      	add	x0, x29, #0x10
    19dc:      	add	x2, x24, #0x18
    19e0:      	mov	w8, #0x4                // =4
    19e4:      	mov	w1, #0x4                // =4
    19e8:      	blr	x8
    19ec:      	add	x0, x29, #0x14
    19f0:      	add	x2, x24, #0x1c
    19f4:      	mov	w8, #0x4                // =4
    19f8:      	mov	w1, #0x4                // =4
    19fc:      	blr	x8
    1a00:      	add	x0, x29, #0x8
    1a04:      	add	x2, x24, #0x10
    1a08:      	mov	w8, #0x4                // =4
    1a0c:      	mov	w1, #0x4                // =4
    1a10:      	blr	x8
    1a14:      	add	x0, x29, #0xc
    1a18:      	add	x2, x24, #0x14
    1a1c:      	mov	w8, #0x4                // =4
    1a20:      	mov	w1, #0x4                // =4
    1a24:      	blr	x8
    1a28:      	add	x0, x29, #0x18
    1a2c:      	add	x2, x24, #0x20
    1a30:      	mov	w8, #0x4                // =4
    1a34:      	mov	w1, #0x4                // =4
    1a38:      	blr	x8
    1a3c:      	add	x0, x29, #0x1c
    1a40:      	add	x2, x24, #0x24
    1a44:      	mov	w8, #0x4                // =4
    1a48:      	mov	w1, #0x4                // =4
    1a4c:      	blr	x8
    1a50:      	str	wzr, [x29, #0x24]
    1a54:      	add	x0, x29, #0x20
    1a58:      	add	x2, x24, #0x28
    1a5c:      	mov	w8, #0x4                // =4
    1a60:      	mov	w1, #0x4                // =4
    1a64:      	blr	x8
    1a68:      	add	x0, x29, #0x30
    1a6c:      	add	x2, x24, #0x40
    1a70:      	mov	w21, #0x8               // =8
    1a74:      	mov	w8, #0x4                // =4
    1a78:      	mov	w1, #0x8                // =8
    1a7c:      	blr	x8
    1a80:      	add	x0, x29, #0x38
    1a84:      	add	x2, x24, #0x30
    1a88:      	mov	w8, #0x4                // =4
    1a8c:      	mov	w1, #0x8                // =8
    1a90:      	blr	x8
    1a94:      	add	x2, x24, #0x38
    1a98:      	mov	w8, #0x4                // =4
    1a9c:      	mov	x0, x22
    1aa0:      	mov	w1, #0x8                // =8
    1aa4:      	blr	x8
    1aa8:      	add	x2, x24, #0x90
    1aac:      	add	x8, sp, #0x98
    1ab0:      	mov	w9, #0x4                // =4
    1ab4:      	add	x0, sp, #0x98
    1ab8:      	mov	w1, #0x8                // =8
    1abc:      	blr	x9
    1ac0:      	ldr	x21, [sp, #0x98]
    1ac4:      	ldr	x0, [sp, #0x40]
    1ac8:      	mov	w8, #0x4                // =4
    1acc:      	mov	w1, #0x4                // =4
    1ad0:      	add	x2, x21, #0xc8
    1ad4:      	blr	x8
    1ad8:      	add	x0, x29, #0x44
    1adc:      	add	x2, x21, #0xcc
    1ae0:      	mov	w8, #0x4                // =4
    1ae4:      	mov	w1, #0x4                // =4
    1ae8:      	blr	x8
    1aec:      	add	x0, x29, #0x48
    1af0:      	add	x2, x21, #0xd0
    1af4:      	mov	w8, #0x4                // =4
    1af8:      	mov	w1, #0x4                // =4
    1afc:      	blr	x8
    1b00:      	add	x0, x29, #0x4c
    1b04:      	add	x2, x21, #0x158
    1b08:      	mov	w1, #0x4                // =4
    1b0c:      	blr	x23
    1b10:      	mov	w22, #0x50              // =80
    1b14:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    1b18:      	ldr	x23, [sp, #0x48]
    1b1c:      	ldr	x22, [sp, #0x30]
    1b20:      	mov	w8, #0x4                // =4
    1b24:      	mov	w1, #0x4                // =4
    1b28:      	mov	w21, #0x4               // =4
    1b2c:      	add	x2, x23, #0xc8
    1b30:      	mov	x0, x22
    1b34:      	blr	x8
    1b38:      	add	x0, x22, #0x4
    1b3c:      	add	x2, x23, #0xcc
    1b40:      	mov	w8, #0x4                // =4
    1b44:      	mov	w1, #0x4                // =4
    1b48:      	blr	x8
    1b4c:      	add	x0, x22, #0x8
    1b50:      	add	x2, x23, #0xd0
    1b54:      	mov	w8, #0x4                // =4
    1b58:      	mov	w1, #0x4                // =4
    1b5c:      	blr	x8
    1b60:      	add	x0, x22, #0xc
    1b64:      	add	x2, x23, #0x158
    1b68:      	mov	w1, #0x4                // =4
    1b6c:      	blr	x21
    1b70:      	mov	w22, #0x10              // =16
    1b74:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    1b78:      	ldr	x23, [sp, #0x48]
    1b7c:      	ldr	x22, [sp, #0x30]
    1b80:      	mov	w8, #0x4                // =4
    1b84:      	mov	w1, #0x4                // =4
    1b88:      	mov	w21, #0x4               // =4
    1b8c:      	add	x2, x23, #0x38
    1b90:      	mov	x0, x22
    1b94:      	blr	x8
    1b98:      	add	x0, x22, #0x4
    1b9c:      	add	x2, x23, #0x3c
    1ba0:      	mov	w8, #0x4                // =4
    1ba4:      	mov	w1, #0x4                // =4
    1ba8:      	blr	x8
    1bac:      	add	x0, x22, #0x8
    1bb0:      	add	x2, x23, #0x40
    1bb4:      	mov	w8, #0x4                // =4
    1bb8:      	mov	w1, #0x4                // =4
    1bbc:      	blr	x8
    1bc0:      	add	x0, x22, #0xc
    1bc4:      	add	x2, x23, #0x44
    1bc8:      	mov	w8, #0x4                // =4
    1bcc:      	mov	w1, #0x4                // =4
    1bd0:      	blr	x8
    1bd4:      	add	x0, x22, #0x10
    1bd8:      	add	x2, x23, #0x80
    1bdc:      	mov	w8, #0x10               // =16
    1be0:      	mov	w1, #0x10               // =16
    1be4:      	blr	x21
    1be8:      	mov	w22, #0x20              // =32
    1bec:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    1bf0:      	ldr	x22, [sp, #0x30]
    1bf4:      	ldr	x23, [sp, #0x48]
    1bf8:      	mov	w8, #0x4                // =4
    1bfc:      	mov	w1, #0x4                // =4
    1c00:      	mov	w21, #0x4               // =4
    1c04:      	mov	x0, x22
    1c08:      	mov	x2, x23
    1c0c:      	blr	x8
    1c10:      	add	x0, x22, #0x4
    1c14:      	add	x2, x23, #0x4
    1c18:      	mov	w8, #0x4                // =4
    1c1c:      	mov	w1, #0x4                // =4
    1c20:      	blr	x8
    1c24:      	add	x0, x22, #0x8
    1c28:      	add	x2, x23, #0x30
    1c2c:      	mov	w8, #0x10               // =16
    1c30:      	b	0x1cb4 <generic_rawtp_process_event+0x1ae4>
    1c34:      	mov	x23, x2
    1c38:      	add	x2, x2, #0x4
    1c3c:      	add	x8, sp, #0x98
    1c40:      	mov	w9, #0x4                // =4
    1c44:      	add	x0, sp, #0x98
    1c48:      	mov	w1, #0x4                // =4
    1c4c:      	mov	w21, #0x4               // =4
    1c50:      	blr	x9
    1c54:      	ldr	w8, [sp, #0x98]
    1c58:      	ldr	x22, [sp, #0x30]
    1c5c:      	add	x2, x23, #0xc
    1c60:      	add	x0, sp, #0x98
    1c64:      	mov	w1, #0x4                // =4
    1c68:      	str	w8, [x22]
    1c6c:      	add	x8, sp, #0x98
    1c70:      	blr	x21
    1c74:      	ldr	w8, [sp, #0x98]
    1c78:      	add	x2, x23, #0x50
    1c7c:      	add	x9, sp, #0x98
    1c80:      	mov	w10, #0x2d              // =45
    1c84:      	str	w8, [x22, #0x4]
    1c88:      	mov	w8, #0x8                // =8
    1c8c:      	add	x0, sp, #0x98
    1c90:      	mov	w1, #0x8                // =8
    1c94:      	mov	w21, #0x2d              // =45
    1c98:      	blr	x10
    1c9c:      	ldr	x8, [sp, #0x98]
    1ca0:      	add	x0, x22, #0x8
    1ca4:      	mov	w9, #0x10               // =16
    1ca8:      	add	x8, x8, #0x3f8
    1cac:      	ldr	x8, [sp, #0x98]
    1cb0:      	add	x2, x8, #0x3f8
    1cb4:      	mov	w1, #0x10               // =16
    1cb8:      	blr	x21
    1cbc:      	mov	w22, #0x18              // =24
    1cc0:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    1cc4:      	ldr	x11, [sp, #0x30]
    1cc8:      	mov	w8, #0x8                // =8
    1ccc:      	mov	w9, #0x4                // =4
    1cd0:      	add	x10, sp, #0x98
    1cd4:      	stp	xzr, xzr, [x11, #0x40]
    1cd8:      	add	x0, sp, #0x98
    1cdc:      	stp	xzr, xzr, [x11, #0x30]
    1ce0:      	stp	xzr, xzr, [x11, #0x20]
    1ce4:      	mov	w1, #0x8                // =8
    1ce8:      	stp	xzr, xzr, [x11, #0x10]
    1cec:      	stp	xzr, xzr, [x11]
    1cf0:      	blr	x9
    1cf4:      	mov	x22, xzr
    1cf8:      	cbnz	x0, 0x1d9c <generic_rawtp_process_event+0x1bcc>
    1cfc:      	ldr	x8, [sp, #0x30]
    1d00:      	mov	w9, #0x3f               // =63
    1d04:      	mov	w10, #0x2d              // =45
    1d08:      	mov	w1, #0x3f               // =63
    1d0c:      	add	x0, x8, #0x10
    1d10:      	ldr	x8, [sp, #0x98]
    1d14:      	ldr	x2, [sp, #0x98]
    1d18:      	blr	x10
    1d1c:      	tbnz	x0, #0x3f, 0x2004 <generic_rawtp_process_event+0x1e34>
    1d20:      	ldr	x23, [sp, #0x48]
    1d24:      	mov	w21, #0x8               // =8
    1d28:      	add	x8, sp, #0xf0
    1d2c:      	mov	w9, #0x4                // =4
    1d30:      	add	x0, sp, #0xf0
    1d34:      	mov	w1, #0x8                // =8
    1d38:      	mov	w22, #0x4               // =4
    1d3c:      	add	x2, x23, #0x8
    1d40:      	blr	x9
    1d44:      	ldr	x8, [sp, #0x30]
    1d48:      	add	x10, sp, #0xe0
    1d4c:      	mov	w9, #0x4                // =4
    1d50:      	mov	w1, #0x8                // =8
    1d54:      	add	x0, x8, #0x8
    1d58:      	ldr	x8, [x10, #0x10]
    1d5c:      	add	x8, x8, #0x360
    1d60:      	ldr	x8, [x10, #0x10]
    1d64:      	add	x2, x8, #0x360
    1d68:      	blr	x9
    1d6c:      	add	x2, x23, #0x58
    1d70:      	add	x8, sp, #0xf0
    1d74:      	add	x0, sp, #0xf0
    1d78:      	mov	w1, #0x4                // =4
    1d7c:      	blr	x22
    1d80:      	cbnz	x0, 0x1d98 <generic_rawtp_process_event+0x1bc8>
    1d84:      	ldr	w8, [sp, #0xf0]
    1d88:      	ldr	x9, [sp, #0x30]
    1d8c:      	cmp	w8, #0x0
    1d90:      	cset	w8, ne
    1d94:      	str	w8, [x9]
    1d98:      	mov	w22, #0x50              // =80
    1d9c:      	adrp	x25, 0x1000 <generic_rawtp_process_event+0xe30>
    1da0:      	ldr	x25, [x25]
    1da4:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    1da8:      	adrp	x25, 0x1000 <generic_rawtp_process_event+0xe30>
    1dac:      	mov	x22, #-0x1              // =-1
    1db0:      	ldr	x25, [x25]
    1db4:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    1db8:      	add	x2, x22, #0x10
    1dbc:      	mov	w21, #0x8               // =8
    1dc0:      	add	x8, sp, #0x100
    1dc4:      	mov	w9, #0x4                // =4
    1dc8:      	add	x0, sp, #0x100
    1dcc:      	mov	w1, #0x8                // =8
    1dd0:      	mov	w23, #0x4               // =4
    1dd4:      	blr	x9
    1dd8:      	add	x2, x22, #0x18
    1ddc:      	add	x8, sp, #0xe8
    1de0:      	add	x0, sp, #0xe8
    1de4:      	mov	w1, #0x8                // =8
    1de8:      	blr	x23
    1dec:      	add	x8, sp, #0xe0
    1df0:      	ldr	x23, [x8, #0x20]
    1df4:      	ldr	x22, [x8, #0x8]
    1df8:      	ldp	x9, x8, [sp, #0x40]
    1dfc:      	add	x8, x8, #0x90
    1e00:      	add	x29, x8, x29
    1e04:      	tbz	w9, #0x5, 0x2410 <generic_rawtp_process_event+0x2240>
    1e08:      	cmp	x22, #0x1, lsl #12      // =0x1000
    1e0c:      	b.lo	0x23f8 <generic_rawtp_process_event+0x2228>
    1e10:      	mov	w8, #0x1                // =1
    1e14:      	adrp	x0, 0x1000 <generic_rawtp_process_event+0xe30>
    1e18:      	add	x9, sp, #0x90
    1e1c:      	str	w8, [x29]
    1e20:      	str	wzr, [sp, #0x90]
    1e24:      	add	x1, sp, #0x90
    1e28:      	ldr	x0, [x0]
    1e2c:      	blr	x8
    1e30:      	cbz	x0, 0x2880 <generic_rawtp_process_event+0x26b0>
    1e34:      	mov	w8, #0x18               // =24
    1e38:      	mov	x24, x0
    1e3c:      	str	w8, [x0]
    1e40:      	mov	w8, #0xe                // =14
    1e44:      	blr	x8
    1e48:      	mov	x21, x24
    1e4c:      	cmn	x0, #0x16
    1e50:      	str	x0, [x21, #0x10]!
    1e54:      	b.ne	0x1e7c <generic_rawtp_process_event+0x1cac>
    1e58:      	add	x2, x19, #0xe8
    1e5c:      	mov	w8, #0x8                // =8
    1e60:      	mov	w9, #0x4                // =4
    1e64:      	add	x10, sp, #0x98
    1e68:      	add	x0, sp, #0x98
    1e6c:      	mov	w1, #0x8                // =8
    1e70:      	blr	x9
    1e74:      	ldr	x8, [sp, #0x98]
    1e78:      	str	x8, [x21]
    1e7c:      	mov	w8, #0x7d               // =125
    1e80:      	blr	x8
    1e84:      	str	x0, [x24, #0x18]
    1e88:      	mov	x0, x19
    1e8c:      	mov	x1, x24
    1e90:      	mov	x2, x23
    1e94:      	ldp	x8, x9, [x21]
    1e98:      	mov	x3, x22
    1e9c:      	stur	x9, [x29, #0x1c]
    1ea0:      	stur	x8, [x29, #0x14]
    1ea4:      	bl	0x1ea4 <generic_rawtp_process_event+0x1cd4>
    1ea8:      	tbz	w0, #0x1f, 0x1724 <generic_rawtp_process_event+0x1554>
    1eac:      	mov	w8, wzr
    1eb0:      	stp	w0, wzr, [x29, #0x4]
    1eb4:      	mov	w0, wzr
    1eb8:      	stp	w8, w0, [x29, #0xc]
    1ebc:      	adrp	x25, 0x1000 <generic_rawtp_process_event+0xe30>
    1ec0:      	mov	w22, #0x24              // =36
    1ec4:      	ldr	x25, [x25]
    1ec8:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    1ecc:      	ldr	x8, [sp, #0x98]
    1ed0:      	ldrh	w21, [sp, #0xe8]
    1ed4:      	adrp	x0, 0x1000 <generic_rawtp_process_event+0xe30>
    1ed8:      	add	x9, sp, #0xf0
    1edc:      	add	x1, sp, #0xf0
    1ee0:      	add	x25, x8, x21
    1ee4:      	str	x8, [sp, #0x48]
    1ee8:      	str	wzr, [sp, #0xf0]
    1eec:      	mov	w8, #0x1                // =1
    1ef0:      	ldr	x0, [x0]
    1ef4:      	blr	x8
    1ef8:      	cbz	x0, 0x2e30 <generic_rawtp_process_event+0x2c60>
    1efc:      	mov	w8, #0xff               // =255
    1f00:      	strh	w21, [x0]
    1f04:      	strb	wzr, [x0, #0x7]
    1f08:      	add	x22, x0, #0x6
    1f0c:      	add	x2, x25, #0x6
    1f10:      	mov	w9, #0x4                // =4
    1f14:      	strb	w8, [x0, #0x5]
    1f18:      	mov	w8, #0x1                // =1
    1f1c:      	mov	x23, x0
    1f20:      	mov	x0, x22
    1f24:      	mov	w1, #0x1                // =1
    1f28:      	blr	x9
    1f2c:      	tbnz	x0, #0x3f, 0x2e30 <generic_rawtp_process_event+0x2c60>
    1f30:      	ldrb	w8, [x23, #0x5]
    1f34:      	cmp	w8, #0x32
    1f38:      	b.gt	0x2448 <generic_rawtp_process_event+0x2278>
    1f3c:      	cbz	w8, 0x2494 <generic_rawtp_process_event+0x22c4>
    1f40:      	cmp	w8, #0x2b
    1f44:      	b.eq	0x2494 <generic_rawtp_process_event+0x22c4>
    1f48:      	cmp	w8, #0x2c
    1f4c:      	b.ne	0x2954 <generic_rawtp_process_event+0x2784>
    1f50:      	mov	w8, #0x8                // =8
    1f54:      	b	0x289c <generic_rawtp_process_event+0x26cc>
    1f58:      	ldr	x0, [sp, #0x30]
    1f5c:      	add	x2, x23, #0x48
    1f60:      	mov	w21, #0x10              // =16
    1f64:      	mov	w8, #0x4                // =4
    1f68:      	mov	w1, #0x10               // =16
    1f6c:      	mov	w25, #0x4               // =4
    1f70:      	blr	x8
    1f74:      	add	x2, x23, #0x38
    1f78:      	mov	x0, x22
    1f7c:      	mov	w1, #0x10               // =16
    1f80:      	blr	x25
    1f84:      	ldr	x25, [sp, #0x30]
    1f88:      	add	x2, x23, #0xe
    1f8c:      	mov	w21, #0x2               // =2
    1f90:      	mov	w8, #0x4                // =4
    1f94:      	mov	w1, #0x2                // =2
    1f98:      	add	x22, x23, #0xc
    1f9c:      	mov	w23, #0x4               // =4
    1fa0:      	add	x0, x25, #0x20
    1fa4:      	blr	x8
    1fa8:      	add	x0, x25, #0x22
    1fac:      	mov	w1, #0x2                // =2
    1fb0:      	mov	x2, x22
    1fb4:      	blr	x23
    1fb8:      	ldrh	w8, [x25, #0x22]
    1fbc:      	adrp	x0, 0x1000 <generic_rawtp_process_event+0xe30>
    1fc0:      	add	x9, sp, #0x98
    1fc4:      	rev	w8, w8
    1fc8:      	lsr	w8, w8, #16
    1fcc:      	strh	w8, [x25, #0x22]
    1fd0:      	add	x8, sp, #0xe0
    1fd4:      	ldr	x8, [x8]
    1fd8:      	str	x8, [sp, #0x98]
    1fdc:      	mov	w8, #0x1                // =1
    1fe0:      	ldr	x0, [x0]
    1fe4:      	b	0x2230 <generic_rawtp_process_event+0x2060>
    1fe8:      	ldr	x8, [sp, #0x48]
    1fec:      	adrp	x25, 0x1000 <generic_rawtp_process_event+0xe30>
    1ff0:      	mov	w22, #0x8               // =8
    1ff4:      	add	x8, x8, x29
    1ff8:      	str	xzr, [x8, #0x90]
    1ffc:      	ldr	x25, [x25]
    2000:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    2004:      	adrp	x25, 0x2000 <generic_rawtp_process_event+0x1e30>
    2008:      	mov	x22, xzr
    200c:      	ldr	x25, [x25]
    2010:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    2014:      	mov	w8, #0xe                // =14
    2018:      	blr	x8
    201c:      	cmn	x0, #0x16
    2020:      	b.ne	0x2044 <generic_rawtp_process_event+0x1e74>
    2024:      	add	x2, x19, #0xe8
    2028:      	mov	w8, #0x8                // =8
    202c:      	mov	w9, #0x4                // =4
    2030:      	add	x10, sp, #0x98
    2034:      	add	x0, sp, #0x98
    2038:      	mov	w1, #0x8                // =8
    203c:      	blr	x9
    2040:      	ldr	x0, [sp, #0x98]
    2044:      	ldr	x10, [x22, #0x8]
    2048:      	ldr	x9, [sp, #0x48]
    204c:      	mov	x3, xzr
    2050:      	add	x1, sp, #0xf0
    2054:      	add	x2, sp, #0x98
    2058:      	add	x21, sp, #0xe0
    205c:      	ldr	x8, [x22, #0x60]
    2060:      	str	xzr, [sp, #0xa8]
    2064:      	stp	x10, x9, [sp, #0x98]
    2068:      	add	x9, sp, #0xe0
    206c:      	add	x10, sp, #0x98
    2070:      	stp	x8, x0, [x9, #0x10]
    2074:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    2078:      	mov	w8, #0x2                // =2
    207c:      	add	x9, sp, #0xf0
    2080:      	ldr	x0, [x0]
    2084:      	blr	x8
    2088:      	cbz	x0, 0x248c <generic_rawtp_process_event+0x22bc>
    208c:      	neg	w8, w0
    2090:      	adrp	x22, 0x2000 <generic_rawtp_process_event+0x1e30>
    2094:      	mov	w9, #0x1                // =1
    2098:      	strh	w8, [sp, #0x100]
    209c:      	mov	w8, #0x5                // =5
    20a0:      	add	x1, sp, #0x100
    20a4:      	strh	w8, [sp, #0x102]
    20a8:      	mov	x8, #0x46               // =70
    20ac:      	movk	x8, #0x2, lsl #32
    20b0:      	stur	x8, [x21, #0x24]
    20b4:      	add	x8, sp, #0x100
    20b8:      	mov	w21, #0x1               // =1
    20bc:      	ldr	x22, [x22]
    20c0:      	mov	x0, x22
    20c4:      	blr	x9
    20c8:      	cbnz	x0, 0x237c <generic_rawtp_process_event+0x21ac>
    20cc:      	str	w21, [sp, #0x90]
    20d0:      	mov	x3, xzr
    20d4:      	mov	w8, #0x2                // =2
    20d8:      	add	x9, sp, #0x100
    20dc:      	add	x10, sp, #0x90
    20e0:      	add	x1, sp, #0x100
    20e4:      	add	x2, sp, #0x90
    20e8:      	b	0x2484 <generic_rawtp_process_event+0x22b4>
    20ec:      	cmp	w8, #0x1
    20f0:      	b.eq	0x2268 <generic_rawtp_process_event+0x2098>
    20f4:      	cmp	w8, #0x2
    20f8:      	b.ne	0x22b4 <generic_rawtp_process_event+0x20e4>
    20fc:      	mov	w8, #0x5e58             // =24152
    2100:      	b	0x226c <generic_rawtp_process_event+0x209c>
    2104:      	ldr	x23, [sp, #0x30]
    2108:      	add	x2, x22, #0x8
    210c:      	mov	w8, #0x10               // =16
    2110:      	mov	w9, #0x4                // =4
    2114:      	mov	w1, #0x10               // =16
    2118:      	mov	w21, #0x4               // =4
    211c:      	add	x0, x23, #0x8
    2120:      	blr	x9
    2124:      	add	x0, x23, #0x2
    2128:      	add	x2, x22, #0x2
    212c:      	mov	w8, #0x2                // =2
    2130:      	mov	w1, #0x2                // =2
    2134:      	blr	x21
    2138:      	ldr	x9, [sp, #0x30]
    213c:      	adrp	x25, 0x2000 <generic_rawtp_process_event+0x1e30>
    2140:      	ldrh	w8, [x9, #0x2]
    2144:      	rev	w8, w8
    2148:      	lsr	w8, w8, #16
    214c:      	strh	w8, [x9, #0x2]
    2150:      	ldr	x25, [x25]
    2154:      	mov	w22, #0x18              // =24
    2158:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    215c:      	add	x2, x22, #0x3
    2160:      	mov	w21, #0x6b              // =107
    2164:      	mov	w8, #0x71               // =113
    2168:      	mov	w1, #0x6b               // =107
    216c:      	blr	x8
    2170:      	adrp	x25, 0x2000 <generic_rawtp_process_event+0x1e30>
    2174:      	ldr	x25, [x25]
    2178:      	tbnz	w0, #0x1f, 0x2184 <generic_rawtp_process_event+0x1fb4>
    217c:      	ldr	x8, [sp, #0x30]
    2180:      	strb	w21, [x8, #0x3]
    2184:      	mov	w22, #0x70              // =112
    2188:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    218c:      	cmp	w9, #0x1
    2190:      	b.eq	0x24b0 <generic_rawtp_process_event+0x22e0>
    2194:      	cmp	w9, #0x2
    2198:      	b.ne	0x24bc <generic_rawtp_process_event+0x22ec>
    219c:      	mov	w8, #0x5e58             // =24152
    21a0:      	b	0x24b4 <generic_rawtp_process_event+0x22e4>
    21a4:      	ldr	x0, [sp, #0x30]
    21a8:      	add	x2, x23, #0x48
    21ac:      	mov	w21, #0x10              // =16
    21b0:      	mov	w8, #0x4                // =4
    21b4:      	mov	w1, #0x10               // =16
    21b8:      	mov	w25, #0x4               // =4
    21bc:      	blr	x8
    21c0:      	add	x2, x23, #0x38
    21c4:      	mov	x0, x22
    21c8:      	mov	w1, #0x10               // =16
    21cc:      	blr	x25
    21d0:      	ldr	x25, [sp, #0x30]
    21d4:      	add	x2, x23, #0xe
    21d8:      	mov	w21, #0x2               // =2
    21dc:      	mov	w8, #0x4                // =4
    21e0:      	mov	w1, #0x2                // =2
    21e4:      	add	x22, x23, #0xc
    21e8:      	mov	w23, #0x4               // =4
    21ec:      	add	x0, x25, #0x20
    21f0:      	blr	x8
    21f4:      	add	x0, x25, #0x22
    21f8:      	mov	w1, #0x2                // =2
    21fc:      	mov	x2, x22
    2200:      	blr	x23
    2204:      	ldrh	w8, [x25, #0x22]
    2208:      	rev	w8, w8
    220c:      	lsr	w8, w8, #16
    2210:      	strh	w8, [x25, #0x22]
    2214:      	ldr	x8, [sp, #0x30]
    2218:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    221c:      	add	x9, sp, #0x98
    2220:      	ldr	x8, [x8, #0x28]
    2224:      	str	x8, [sp, #0x98]
    2228:      	mov	w8, #0x1                // =1
    222c:      	ldr	x0, [x0]
    2230:      	add	x1, sp, #0x98
    2234:      	blr	x8
    2238:      	cbz	x0, 0x2fb0 <generic_rawtp_process_event+0x2de0>
    223c:      	ldr	w8, [x0]
    2240:      	str	w8, [x24, #0x10]
    2244:      	ldr	x8, [x0, #0x8]
    2248:      	str	x8, [x24, #0x18]
    224c:      	ldr	w8, [x0, #0x4]
    2250:      	str	w8, [x24, #0x7c]
    2254:      	b	0x2fb0 <generic_rawtp_process_event+0x2de0>
    2258:      	mov	w8, #0x5e60             // =24160
    225c:      	b	0x226c <generic_rawtp_process_event+0x209c>
    2260:      	mov	w8, #0x5e68             // =24168
    2264:      	b	0x226c <generic_rawtp_process_event+0x209c>
    2268:      	mov	w8, #0x5e50             // =24144
    226c:      	add	x8, x24, x8
    2270:      	ldr	x29, [x8]
    2274:      	ldr	x8, [sp, #0x40]
    2278:      	tbnz	w8, #0x4, 0x22c4 <generic_rawtp_process_event+0x20f4>
    227c:      	cbz	x29, 0x2390 <generic_rawtp_process_event+0x21c0>
    2280:      	ldr	x2, [sp, #0x48]
    2284:      	mov	w8, #0x10               // =16
    2288:      	mov	w9, #0x4                // =4
    228c:      	add	x10, sp, #0x98
    2290:      	add	x0, sp, #0x98
    2294:      	mov	w1, #0x10               // =16
    2298:      	blr	x9
    229c:      	tbnz	w0, #0x1f, 0x2878 <generic_rawtp_process_event+0x26a8>
    22a0:      	ldr	x22, [sp, #0xa0]
    22a4:      	cmp	x22, #0xffe
    22a8:      	b.ls	0x25f4 <generic_rawtp_process_event+0x2424>
    22ac:      	mov	w8, #-0x3               // =-3
    22b0:      	b	0x287c <generic_rawtp_process_event+0x26ac>
    22b4:      	ldr	x8, [sp, #0x40]
    22b8:      	mov	x29, xzr
    22bc:      	mov	x22, xzr
    22c0:      	tbz	w8, #0x4, 0x2394 <generic_rawtp_process_event+0x21c4>
    22c4:      	mov	w8, #0xe                // =14
    22c8:      	blr	x8
    22cc:      	cmn	x0, #0x16
    22d0:      	b.ne	0x22f4 <generic_rawtp_process_event+0x2124>
    22d4:      	add	x2, x19, #0xe8
    22d8:      	mov	w8, #0x8                // =8
    22dc:      	mov	w9, #0x4                // =4
    22e0:      	add	x10, sp, #0x98
    22e4:      	add	x0, sp, #0x98
    22e8:      	mov	w1, #0x8                // =8
    22ec:      	blr	x9
    22f0:      	ldr	x0, [sp, #0x98]
    22f4:      	ldr	x10, [x24, #0x8]
    22f8:      	ldr	x9, [sp, #0x48]
    22fc:      	mov	x3, xzr
    2300:      	add	x1, sp, #0xf0
    2304:      	add	x2, sp, #0x98
    2308:      	add	x21, sp, #0xe0
    230c:      	ldr	x8, [x24, #0x60]
    2310:      	str	x29, [sp, #0xa8]
    2314:      	stp	x10, x9, [sp, #0x98]
    2318:      	add	x9, sp, #0xe0
    231c:      	add	x10, sp, #0x98
    2320:      	stp	x8, x0, [x9, #0x10]
    2324:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    2328:      	mov	w8, #0x2                // =2
    232c:      	add	x9, sp, #0xf0
    2330:      	ldr	x0, [x0]
    2334:      	blr	x8
    2338:      	cbz	x0, 0x248c <generic_rawtp_process_event+0x22bc>
    233c:      	neg	w8, w0
    2340:      	adrp	x22, 0x2000 <generic_rawtp_process_event+0x1e30>
    2344:      	mov	w9, #0x1                // =1
    2348:      	strh	w8, [sp, #0x100]
    234c:      	mov	w8, #0x5                // =5
    2350:      	add	x1, sp, #0x100
    2354:      	strh	w8, [sp, #0x102]
    2358:      	mov	x8, #0x57               // =87
    235c:      	movk	x8, #0x2, lsl #32
    2360:      	stur	x8, [x21, #0x24]
    2364:      	add	x8, sp, #0x100
    2368:      	mov	w21, #0x1               // =1
    236c:      	ldr	x22, [x22]
    2370:      	mov	x0, x22
    2374:      	blr	x9
    2378:      	cbz	x0, 0x2468 <generic_rawtp_process_event+0x2298>
    237c:      	ldr	w8, [x0]
    2380:      	add	w8, w8, #0x1
    2384:      	str	w8, [x0]
    2388:      	mov	w8, #-0x4               // =-4
    238c:      	b	0x287c <generic_rawtp_process_event+0x26ac>
    2390:      	mov	x22, xzr
    2394:      	stp	w22, w22, [x25]
    2398:      	adrp	x25, 0x2000 <generic_rawtp_process_event+0x1e30>
    239c:      	add	x22, x22, #0x8
    23a0:      	ldr	x25, [x25]
    23a4:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    23a8:      	ldr	x9, [sp, #0x118]
    23ac:      	str	wzr, [x29]
    23b0:      	mov	w23, #0xc               // =12
    23b4:      	add	w9, w9, #0x8
    23b8:      	and	x9, x9, #0x3fff
    23bc:      	add	x29, x8, x9
    23c0:      	cmp	x22, #0xfff
    23c4:      	mov	w8, #0xfff              // =4095
    23c8:      	add	x0, x29, #0x8
    23cc:      	mov	x2, x25
    23d0:      	csel	x24, x22, x8, lo
    23d4:      	mov	w8, #0x4                // =4
    23d8:      	mov	w1, w24
    23dc:      	blr	x8
    23e0:      	tbnz	w0, #0x1f, 0x243c <generic_rawtp_process_event+0x226c>
    23e4:      	stp	w22, w24, [x29]
    23e8:      	adrp	x25, 0x2000 <generic_rawtp_process_event+0x1e30>
    23ec:      	add	x22, x23, x24
    23f0:      	ldr	x25, [x25]
    23f4:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    23f8:      	ldr	x9, [sp, #0x118]
    23fc:      	str	wzr, [x29]
    2400:      	mov	w21, #0xc               // =12
    2404:      	add	w9, w9, #0x8
    2408:      	and	x9, x9, #0x3fff
    240c:      	add	x29, x8, x9
    2410:      	cmp	x22, #0xfff
    2414:      	mov	w8, #0xfff              // =4095
    2418:      	add	x0, x29, #0x8
    241c:      	mov	x2, x23
    2420:      	csel	x24, x22, x8, lo
    2424:      	mov	w8, #0x4                // =4
    2428:      	mov	w1, w24
    242c:      	blr	x8
    2430:      	tbnz	w0, #0x1f, 0x243c <generic_rawtp_process_event+0x226c>
    2434:      	stp	w22, w24, [x29]
    2438:      	b	0x25e4 <generic_rawtp_process_event+0x2414>
    243c:      	mov	w8, #-0x2               // =-2
    2440:      	str	w8, [x29]
    2444:      	b	0x2880 <generic_rawtp_process_event+0x26b0>
    2448:      	cmp	w8, #0x33
    244c:      	b.eq	0x2890 <generic_rawtp_process_event+0x26c0>
    2450:      	cmp	w8, #0x3c
    2454:      	b.eq	0x2494 <generic_rawtp_process_event+0x22c4>
    2458:      	cmp	w8, #0xff
    245c:      	b.ne	0x2954 <generic_rawtp_process_event+0x2784>
    2460:      	mov	w8, #0x28               // =40
    2464:      	b	0x289c <generic_rawtp_process_event+0x26cc>
    2468:      	str	w21, [sp, #0xe8]
    246c:      	mov	x3, xzr
    2470:      	mov	w8, #0x2                // =2
    2474:      	add	x9, sp, #0x100
    2478:      	add	x10, sp, #0xe8
    247c:      	add	x1, sp, #0x100
    2480:      	add	x2, sp, #0xe8
    2484:      	mov	x0, x22
    2488:      	blr	x8
    248c:      	mov	w8, #-0x4               // =-4
    2490:      	b	0x287c <generic_rawtp_process_event+0x26ac>
    2494:      	ldrb	w8, [x23, #0x7]
    2498:      	lsl	w8, w8, #3
    249c:      	b	0x2898 <generic_rawtp_process_event+0x26c8>
    24a0:      	mov	w8, #0x5e60             // =24160
    24a4:      	b	0x24b4 <generic_rawtp_process_event+0x22e4>
    24a8:      	mov	w8, #0x5e68             // =24168
    24ac:      	b	0x24b4 <generic_rawtp_process_event+0x22e4>
    24b0:      	mov	w8, #0x5e50             // =24144
    24b4:      	add	x8, x22, x8
    24b8:      	ldr	x8, [x8]
    24bc:      	add	x22, sp, #0xe0
    24c0:      	mov	w21, #0x8               // =8
    24c4:      	add	x9, sp, #0xe0
    24c8:      	str	x8, [x22, #0x8]
    24cc:      	mov	w8, #0x4                // =4
    24d0:      	add	x10, sp, #0xe8
    24d4:      	add	x0, sp, #0xe0
    24d8:      	add	x2, sp, #0xe8
    24dc:      	mov	w1, #0x8                // =8
    24e0:      	blr	x8
    24e4:      	ldr	x22, [x22]
    24e8:      	tbz	w29, #0x5, 0x25bc <generic_rawtp_process_event+0x23ec>
    24ec:      	cmp	x22, #0x1, lsl #12      // =0x1000
    24f0:      	b.lo	0x25a4 <generic_rawtp_process_event+0x23d4>
    24f4:      	mov	w8, #0x1                // =1
    24f8:      	adrp	x0, 0x2000 <generic_rawtp_process_event+0x1e30>
    24fc:      	add	x9, sp, #0xf0
    2500:      	str	w8, [x25]
    2504:      	str	wzr, [sp, #0xf0]
    2508:      	add	x1, sp, #0xf0
    250c:      	ldr	x0, [x0]
    2510:      	blr	x8
    2514:      	cbz	x0, 0x2880 <generic_rawtp_process_event+0x26b0>
    2518:      	mov	w8, #0x18               // =24
    251c:      	mov	x24, x0
    2520:      	str	w8, [x0]
    2524:      	mov	w8, #0xe                // =14
    2528:      	blr	x8
    252c:      	mov	x21, x24
    2530:      	cmn	x0, #0x16
    2534:      	str	x0, [x21, #0x10]!
    2538:      	b.ne	0x2560 <generic_rawtp_process_event+0x2390>
    253c:      	add	x2, x19, #0xe8
    2540:      	mov	w8, #0x8                // =8
    2544:      	mov	w9, #0x4                // =4
    2548:      	add	x10, sp, #0x98
    254c:      	add	x0, sp, #0x98
    2550:      	mov	w1, #0x8                // =8
    2554:      	blr	x9
    2558:      	ldr	x8, [sp, #0x98]
    255c:      	str	x8, [x21]
    2560:      	mov	w8, #0x7d               // =125
    2564:      	blr	x8
    2568:      	str	x0, [x24, #0x18]
    256c:      	ldr	x2, [sp, #0x48]
    2570:      	mov	x0, x19
    2574:      	mov	x1, x24
    2578:      	mov	x3, x22
    257c:      	ldp	x8, x9, [x21]
    2580:      	stur	x9, [x25, #0x1c]
    2584:      	stur	x8, [x25, #0x14]
    2588:      	bl	0x2588 <generic_rawtp_process_event+0x23b8>
    258c:      	tbnz	w0, #0x1f, 0x2978 <generic_rawtp_process_event+0x27a8>
    2590:      	sub	w8, w22, w0
    2594:      	cmn	x22, #0x1
    2598:      	stur	xzr, [x25, #0x4]
    259c:      	csel	w8, wzr, w8, eq
    25a0:      	b	0x2984 <generic_rawtp_process_event+0x27b4>
    25a4:      	ldr	x8, [sp, #0x118]
    25a8:      	str	wzr, [x25]
    25ac:      	mov	w21, #0xc               // =12
    25b0:      	add	w8, w8, #0x8
    25b4:      	and	x8, x8, #0x3fff
    25b8:      	add	x25, x23, x8
    25bc:      	cmp	x22, #0xfff
    25c0:      	mov	w8, #0xfff              // =4095
    25c4:      	ldr	x2, [sp, #0x48]
    25c8:      	add	x0, x25, #0x8
    25cc:      	csel	x24, x22, x8, lo
    25d0:      	mov	w8, #0x4                // =4
    25d4:      	mov	w1, w24
    25d8:      	blr	x8
    25dc:      	tbnz	w0, #0x1f, 0x2878 <generic_rawtp_process_event+0x26a8>
    25e0:      	stp	w22, w24, [x25]
    25e4:      	adrp	x25, 0x2000 <generic_rawtp_process_event+0x1e30>
    25e8:      	add	x22, x21, x24
    25ec:      	ldr	x25, [x25]
    25f0:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    25f4:      	ldr	x8, [sp, #0x118]
    25f8:      	mov	w9, #0x4                // =4
    25fc:      	mov	w1, w22
    2600:      	add	x21, x8, #0xc
    2604:      	and	x8, x21, #0x3fff
    2608:      	add	x0, x23, x8
    260c:      	ldr	x8, [sp, #0x98]
    2610:      	ldr	x2, [sp, #0x98]
    2614:      	blr	x9
    2618:      	tbnz	w0, #0x1f, 0x2878 <generic_rawtp_process_event+0x26a8>
    261c:      	cmp	x29, #0x1
    2620:      	b.eq	0x2394 <generic_rawtp_process_event+0x21c4>
    2624:      	ldr	x8, [sp, #0x48]
    2628:      	mov	w9, #0x4                // =4
    262c:      	add	x10, sp, #0x98
    2630:      	add	x0, sp, #0x98
    2634:      	mov	w1, #0x10               // =16
    2638:      	add	x2, x8, #0x10
    263c:      	mov	w8, #0x10               // =16
    2640:      	blr	x9
    2644:      	tbnz	w0, #0x1f, 0x2878 <generic_rawtp_process_event+0x26a8>
    2648:      	ldr	x24, [sp, #0xa0]
    264c:      	cmp	x24, #0xffe
    2650:      	b.hi	0x22ac <generic_rawtp_process_event+0x20dc>
    2654:      	add	x21, x22, x21
    2658:      	mov	w9, #0x4                // =4
    265c:      	mov	w1, w24
    2660:      	and	x8, x21, #0x3fff
    2664:      	add	x0, x23, x8
    2668:      	ldr	x8, [sp, #0x98]
    266c:      	ldr	x2, [sp, #0x98]
    2670:      	blr	x9
    2674:      	tbnz	w0, #0x1f, 0x2878 <generic_rawtp_process_event+0x26a8>
    2678:      	add	x22, x24, x22
    267c:      	cmp	x29, #0x3
    2680:      	b.lo	0x2394 <generic_rawtp_process_event+0x21c4>
    2684:      	ldr	x8, [sp, #0x48]
    2688:      	mov	w9, #0x4                // =4
    268c:      	add	x10, sp, #0x98
    2690:      	add	x0, sp, #0x98
    2694:      	mov	w1, #0x10               // =16
    2698:      	add	x2, x8, #0x20
    269c:      	mov	w8, #0x10               // =16
    26a0:      	blr	x9
    26a4:      	tbnz	w0, #0x1f, 0x2878 <generic_rawtp_process_event+0x26a8>
    26a8:      	ldr	x8, [sp, #0xa0]
    26ac:      	cmp	x8, #0xffe
    26b0:      	str	x8, [sp, #0x40]
    26b4:      	b.hi	0x22ac <generic_rawtp_process_event+0x20dc>
    26b8:      	add	x21, x24, x21
    26bc:      	mov	w9, #0x4                // =4
    26c0:      	ldr	x1, [sp, #0x40]
    26c4:      	and	x8, x21, #0x3fff
    26c8:      	add	x0, x23, x8
    26cc:      	ldr	x8, [sp, #0x98]
    26d0:      	ldr	x2, [sp, #0x98]
    26d4:      	blr	x9
    26d8:      	tbnz	w0, #0x1f, 0x2878 <generic_rawtp_process_event+0x26a8>
    26dc:      	ldr	x8, [sp, #0x40]
    26e0:      	cmp	x29, #0x3
    26e4:      	add	x22, x8, x22
    26e8:      	b.eq	0x2394 <generic_rawtp_process_event+0x21c4>
    26ec:      	ldr	x8, [sp, #0x48]
    26f0:      	mov	w9, #0x4                // =4
    26f4:      	add	x10, sp, #0x98
    26f8:      	add	x0, sp, #0x98
    26fc:      	mov	w1, #0x10               // =16
    2700:      	add	x2, x8, #0x30
    2704:      	mov	w8, #0x10               // =16
    2708:      	blr	x9
    270c:      	tbnz	w0, #0x1f, 0x2878 <generic_rawtp_process_event+0x26a8>
    2710:      	ldr	x24, [sp, #0xa0]
    2714:      	cmp	x24, #0xffe
    2718:      	b.hi	0x22ac <generic_rawtp_process_event+0x20dc>
    271c:      	ldr	x8, [sp, #0x40]
    2720:      	mov	w9, #0x4                // =4
    2724:      	mov	w1, w24
    2728:      	add	x21, x8, x21
    272c:      	and	x8, x21, #0x3fff
    2730:      	add	x0, x23, x8
    2734:      	ldr	x8, [sp, #0x98]
    2738:      	ldr	x2, [sp, #0x98]
    273c:      	blr	x9
    2740:      	tbnz	w0, #0x1f, 0x2878 <generic_rawtp_process_event+0x26a8>
    2744:      	add	x22, x24, x22
    2748:      	cmp	x29, #0x5
    274c:      	b.lo	0x2394 <generic_rawtp_process_event+0x21c4>
    2750:      	ldr	x8, [sp, #0x48]
    2754:      	mov	w9, #0x4                // =4
    2758:      	add	x10, sp, #0x98
    275c:      	add	x0, sp, #0x98
    2760:      	mov	w1, #0x10               // =16
    2764:      	add	x2, x8, #0x40
    2768:      	mov	w8, #0x10               // =16
    276c:      	blr	x9
    2770:      	tbnz	w0, #0x1f, 0x2878 <generic_rawtp_process_event+0x26a8>
    2774:      	ldr	x8, [sp, #0xa0]
    2778:      	cmp	x8, #0xffe
    277c:      	str	x8, [sp, #0x40]
    2780:      	b.hi	0x22ac <generic_rawtp_process_event+0x20dc>
    2784:      	add	x21, x24, x21
    2788:      	mov	w9, #0x4                // =4
    278c:      	ldr	x1, [sp, #0x40]
    2790:      	and	x8, x21, #0x3fff
    2794:      	add	x0, x23, x8
    2798:      	ldr	x8, [sp, #0x98]
    279c:      	ldr	x2, [sp, #0x98]
    27a0:      	blr	x9
    27a4:      	tbnz	w0, #0x1f, 0x2878 <generic_rawtp_process_event+0x26a8>
    27a8:      	ldr	x8, [sp, #0x40]
    27ac:      	cmp	x29, #0x5
    27b0:      	add	x22, x8, x22
    27b4:      	b.eq	0x2394 <generic_rawtp_process_event+0x21c4>
    27b8:      	ldr	x8, [sp, #0x48]
    27bc:      	mov	w9, #0x4                // =4
    27c0:      	add	x10, sp, #0x98
    27c4:      	add	x0, sp, #0x98
    27c8:      	mov	w1, #0x10               // =16
    27cc:      	add	x2, x8, #0x50
    27d0:      	mov	w8, #0x10               // =16
    27d4:      	blr	x9
    27d8:      	tbnz	w0, #0x1f, 0x2878 <generic_rawtp_process_event+0x26a8>
    27dc:      	ldr	x24, [sp, #0xa0]
    27e0:      	cmp	x24, #0xffe
    27e4:      	b.hi	0x22ac <generic_rawtp_process_event+0x20dc>
    27e8:      	ldr	x8, [sp, #0x40]
    27ec:      	mov	w9, #0x4                // =4
    27f0:      	mov	w1, w24
    27f4:      	add	x21, x8, x21
    27f8:      	and	x8, x21, #0x3fff
    27fc:      	add	x0, x23, x8
    2800:      	ldr	x8, [sp, #0x98]
    2804:      	ldr	x2, [sp, #0x98]
    2808:      	blr	x9
    280c:      	tbnz	w0, #0x1f, 0x2878 <generic_rawtp_process_event+0x26a8>
    2810:      	add	x22, x24, x22
    2814:      	cmp	x29, #0x7
    2818:      	b.lo	0x2394 <generic_rawtp_process_event+0x21c4>
    281c:      	ldr	x8, [sp, #0x48]
    2820:      	mov	w9, #0x4                // =4
    2824:      	add	x10, sp, #0x98
    2828:      	add	x0, sp, #0x98
    282c:      	mov	w1, #0x10               // =16
    2830:      	add	x2, x8, #0x60
    2834:      	mov	w8, #0x10               // =16
    2838:      	blr	x9
    283c:      	tbnz	w0, #0x1f, 0x2878 <generic_rawtp_process_event+0x26a8>
    2840:      	ldr	x29, [sp, #0xa0]
    2844:      	cmp	x29, #0xffe
    2848:      	b.hi	0x22ac <generic_rawtp_process_event+0x20dc>
    284c:      	add	x8, x24, x21
    2850:      	mov	w9, #0x4                // =4
    2854:      	mov	w1, w29
    2858:      	and	x8, x8, #0x3fff
    285c:      	add	x0, x23, x8
    2860:      	ldr	x8, [sp, #0x98]
    2864:      	ldr	x2, [sp, #0x98]
    2868:      	blr	x9
    286c:      	tbnz	w0, #0x1f, 0x2878 <generic_rawtp_process_event+0x26a8>
    2870:      	add	x22, x29, x22
    2874:      	b	0x2394 <generic_rawtp_process_event+0x21c4>
    2878:      	mov	w8, #-0x2               // =-2
    287c:      	str	w8, [x25]
    2880:      	adrp	x25, 0x2000 <generic_rawtp_process_event+0x1e30>
    2884:      	mov	w22, #0x4               // =4
    2888:      	ldr	x25, [x25]
    288c:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    2890:      	ldrb	w8, [x23, #0x7]
    2894:      	lsl	w8, w8, #2
    2898:      	add	w8, w8, #0x8
    289c:      	strh	w8, [x23, #0x2]
    28a0:      	ldrh	w9, [x23]
    28a4:      	ldrb	w29, [x23, #0x6]
    28a8:      	add	w8, w9, w8
    28ac:      	cmp	w29, #0x3c
    28b0:      	strh	w8, [x23]
    28b4:      	b.hi	0x2970 <generic_rawtp_process_event+0x27a0>
    28b8:      	mov	x21, #0x1               // =1
    28bc:      	mov	w9, #0x1                // =1
    28c0:      	movk	x21, #0x1800, lsl #32
    28c4:      	lsl	x9, x9, x29
    28c8:      	movk	x21, #0x1008, lsl #48
    28cc:      	tst	x9, x21
    28d0:      	b.eq	0x2970 <generic_rawtp_process_event+0x27a0>
    28d4:      	ldr	x11, [sp, #0x48]
    28d8:      	strb	w29, [x23, #0x5]
    28dc:      	mov	w9, #0x2                // =2
    28e0:      	mov	w10, #0x4               // =4
    28e4:      	mov	x0, x22
    28e8:      	mov	w1, #0x2                // =2
    28ec:      	add	x8, x11, w8, uxth
    28f0:      	ldrh	w8, [x23]
    28f4:      	add	x2, x11, x8
    28f8:      	blr	x10
    28fc:      	tbnz	x0, #0x3f, 0x2e30 <generic_rawtp_process_event+0x2c60>
    2900:      	ldrb	w8, [x23, #0x5]
    2904:      	cmp	w8, #0x32
    2908:      	b.gt	0x2928 <generic_rawtp_process_event+0x2758>
    290c:      	cbz	w8, 0x2948 <generic_rawtp_process_event+0x2778>
    2910:      	cmp	w8, #0x2b
    2914:      	b.eq	0x2948 <generic_rawtp_process_event+0x2778>
    2918:      	cmp	w8, #0x2c
    291c:      	b.ne	0x2a50 <generic_rawtp_process_event+0x2880>
    2920:      	mov	w8, #0x8                // =8
    2924:      	b	0x29a4 <generic_rawtp_process_event+0x27d4>
    2928:      	cmp	w8, #0x33
    292c:      	b.eq	0x2998 <generic_rawtp_process_event+0x27c8>
    2930:      	cmp	w8, #0x3c
    2934:      	b.eq	0x2948 <generic_rawtp_process_event+0x2778>
    2938:      	cmp	w8, #0xff
    293c:      	b.ne	0x2a50 <generic_rawtp_process_event+0x2880>
    2940:      	mov	w8, #0x28               // =40
    2944:      	b	0x29a4 <generic_rawtp_process_event+0x27d4>
    2948:      	ldrb	w8, [x23, #0x7]
    294c:      	lsl	w8, w8, #3
    2950:      	b	0x29a0 <generic_rawtp_process_event+0x27d0>
    2954:      	ldrh	w8, [x23, #0x2]
    2958:      	ldrh	w9, [x23]
    295c:      	ldrb	w29, [x23, #0x6]
    2960:      	add	w8, w9, w8
    2964:      	cmp	w29, #0x3c
    2968:      	strh	w8, [x23]
    296c:      	b.ls	0x28b8 <generic_rawtp_process_event+0x26e8>
    2970:      	strh	w8, [sp, #0x90]
    2974:      	b	0x2e34 <generic_rawtp_process_event+0x2c64>
    2978:      	mov	w8, wzr
    297c:      	stp	w0, wzr, [x25, #0x4]
    2980:      	mov	w0, wzr
    2984:      	stp	w8, w0, [x25, #0xc]
    2988:      	adrp	x25, 0x2000 <generic_rawtp_process_event+0x1e30>
    298c:      	mov	w22, #0x24              // =36
    2990:      	ldr	x25, [x25]
    2994:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    2998:      	ldrb	w8, [x23, #0x7]
    299c:      	lsl	w8, w8, #2
    29a0:      	add	w8, w8, #0x8
    29a4:      	strh	w8, [x23, #0x2]
    29a8:      	ldrh	w9, [x23]
    29ac:      	ldrb	w29, [x23, #0x6]
    29b0:      	add	w8, w9, w8
    29b4:      	cmp	w29, #0x3c
    29b8:      	strh	w8, [x23]
    29bc:      	b.hi	0x2fdc <generic_rawtp_process_event+0x2e0c>
    29c0:      	mov	w9, #0x1                // =1
    29c4:      	lsl	x9, x9, x29
    29c8:      	tst	x9, x21
    29cc:      	b.eq	0x2fdc <generic_rawtp_process_event+0x2e0c>
    29d0:      	ldr	x11, [sp, #0x48]
    29d4:      	strb	w29, [x23, #0x5]
    29d8:      	mov	w9, #0x2                // =2
    29dc:      	mov	w10, #0x4               // =4
    29e0:      	mov	x0, x22
    29e4:      	mov	w1, #0x2                // =2
    29e8:      	add	x8, x11, w8, uxth
    29ec:      	ldrh	w8, [x23]
    29f0:      	add	x2, x11, x8
    29f4:      	blr	x10
    29f8:      	tbnz	x0, #0x3f, 0x2e30 <generic_rawtp_process_event+0x2c60>
    29fc:      	ldrb	w8, [x23, #0x5]
    2a00:      	cmp	w8, #0x32
    2a04:      	b.gt	0x2a24 <generic_rawtp_process_event+0x2854>
    2a08:      	cbz	w8, 0x2a44 <generic_rawtp_process_event+0x2874>
    2a0c:      	cmp	w8, #0x2b
    2a10:      	b.eq	0x2a44 <generic_rawtp_process_event+0x2874>
    2a14:      	cmp	w8, #0x2c
    2a18:      	b.ne	0x2b28 <generic_rawtp_process_event+0x2958>
    2a1c:      	mov	w8, #0x8                // =8
    2a20:      	b	0x2a7c <generic_rawtp_process_event+0x28ac>
    2a24:      	cmp	w8, #0x33
    2a28:      	b.eq	0x2a70 <generic_rawtp_process_event+0x28a0>
    2a2c:      	cmp	w8, #0x3c
    2a30:      	b.eq	0x2a44 <generic_rawtp_process_event+0x2874>
    2a34:      	cmp	w8, #0xff
    2a38:      	b.ne	0x2b28 <generic_rawtp_process_event+0x2958>
    2a3c:      	mov	w8, #0x28               // =40
    2a40:      	b	0x2a7c <generic_rawtp_process_event+0x28ac>
    2a44:      	ldrb	w8, [x23, #0x7]
    2a48:      	lsl	w8, w8, #3
    2a4c:      	b	0x2a78 <generic_rawtp_process_event+0x28a8>
    2a50:      	ldrh	w8, [x23, #0x2]
    2a54:      	ldrh	w9, [x23]
    2a58:      	ldrb	w29, [x23, #0x6]
    2a5c:      	add	w8, w9, w8
    2a60:      	cmp	w29, #0x3c
    2a64:      	strh	w8, [x23]
    2a68:      	b.ls	0x29c0 <generic_rawtp_process_event+0x27f0>
    2a6c:      	b	0x2fdc <generic_rawtp_process_event+0x2e0c>
    2a70:      	ldrb	w8, [x23, #0x7]
    2a74:      	lsl	w8, w8, #2
    2a78:      	add	w8, w8, #0x8
    2a7c:      	strh	w8, [x23, #0x2]
    2a80:      	ldrh	w9, [x23]
    2a84:      	ldrb	w29, [x23, #0x6]
    2a88:      	add	w8, w9, w8
    2a8c:      	cmp	w29, #0x3c
    2a90:      	strh	w8, [x23]
    2a94:      	b.hi	0x2fdc <generic_rawtp_process_event+0x2e0c>
    2a98:      	mov	w9, #0x1                // =1
    2a9c:      	lsl	x9, x9, x29
    2aa0:      	tst	x9, x21
    2aa4:      	b.eq	0x2fdc <generic_rawtp_process_event+0x2e0c>
    2aa8:      	ldr	x11, [sp, #0x48]
    2aac:      	strb	w29, [x23, #0x5]
    2ab0:      	mov	w9, #0x2                // =2
    2ab4:      	mov	w10, #0x4               // =4
    2ab8:      	mov	x0, x22
    2abc:      	mov	w1, #0x2                // =2
    2ac0:      	add	x8, x11, w8, uxth
    2ac4:      	ldrh	w8, [x23]
    2ac8:      	add	x2, x11, x8
    2acc:      	blr	x10
    2ad0:      	tbnz	x0, #0x3f, 0x2e30 <generic_rawtp_process_event+0x2c60>
    2ad4:      	ldrb	w8, [x23, #0x5]
    2ad8:      	cmp	w8, #0x32
    2adc:      	b.gt	0x2afc <generic_rawtp_process_event+0x292c>
    2ae0:      	cbz	w8, 0x2b1c <generic_rawtp_process_event+0x294c>
    2ae4:      	cmp	w8, #0x2b
    2ae8:      	b.eq	0x2b1c <generic_rawtp_process_event+0x294c>
    2aec:      	cmp	w8, #0x2c
    2af0:      	b.ne	0x2c00 <generic_rawtp_process_event+0x2a30>
    2af4:      	mov	w8, #0x8                // =8
    2af8:      	b	0x2b54 <generic_rawtp_process_event+0x2984>
    2afc:      	cmp	w8, #0x33
    2b00:      	b.eq	0x2b48 <generic_rawtp_process_event+0x2978>
    2b04:      	cmp	w8, #0x3c
    2b08:      	b.eq	0x2b1c <generic_rawtp_process_event+0x294c>
    2b0c:      	cmp	w8, #0xff
    2b10:      	b.ne	0x2c00 <generic_rawtp_process_event+0x2a30>
    2b14:      	mov	w8, #0x28               // =40
    2b18:      	b	0x2b54 <generic_rawtp_process_event+0x2984>
    2b1c:      	ldrb	w8, [x23, #0x7]
    2b20:      	lsl	w8, w8, #3
    2b24:      	b	0x2b50 <generic_rawtp_process_event+0x2980>
    2b28:      	ldrh	w8, [x23, #0x2]
    2b2c:      	ldrh	w9, [x23]
    2b30:      	ldrb	w29, [x23, #0x6]
    2b34:      	add	w8, w9, w8
    2b38:      	cmp	w29, #0x3c
    2b3c:      	strh	w8, [x23]
    2b40:      	b.ls	0x2a98 <generic_rawtp_process_event+0x28c8>
    2b44:      	b	0x2fdc <generic_rawtp_process_event+0x2e0c>
    2b48:      	ldrb	w8, [x23, #0x7]
    2b4c:      	lsl	w8, w8, #2
    2b50:      	add	w8, w8, #0x8
    2b54:      	strh	w8, [x23, #0x2]
    2b58:      	ldrh	w9, [x23]
    2b5c:      	ldrb	w29, [x23, #0x6]
    2b60:      	add	w8, w9, w8
    2b64:      	cmp	w29, #0x3c
    2b68:      	strh	w8, [x23]
    2b6c:      	b.hi	0x2fdc <generic_rawtp_process_event+0x2e0c>
    2b70:      	mov	w9, #0x1                // =1
    2b74:      	lsl	x9, x9, x29
    2b78:      	tst	x9, x21
    2b7c:      	b.eq	0x2fdc <generic_rawtp_process_event+0x2e0c>
    2b80:      	ldr	x11, [sp, #0x48]
    2b84:      	strb	w29, [x23, #0x5]
    2b88:      	mov	w9, #0x2                // =2
    2b8c:      	mov	w10, #0x4               // =4
    2b90:      	mov	x0, x22
    2b94:      	mov	w1, #0x2                // =2
    2b98:      	add	x8, x11, w8, uxth
    2b9c:      	ldrh	w8, [x23]
    2ba0:      	add	x2, x11, x8
    2ba4:      	blr	x10
    2ba8:      	tbnz	x0, #0x3f, 0x2e30 <generic_rawtp_process_event+0x2c60>
    2bac:      	ldrb	w8, [x23, #0x5]
    2bb0:      	cmp	w8, #0x32
    2bb4:      	b.gt	0x2bd4 <generic_rawtp_process_event+0x2a04>
    2bb8:      	cbz	w8, 0x2bf4 <generic_rawtp_process_event+0x2a24>
    2bbc:      	cmp	w8, #0x2b
    2bc0:      	b.eq	0x2bf4 <generic_rawtp_process_event+0x2a24>
    2bc4:      	cmp	w8, #0x2c
    2bc8:      	b.ne	0x2cd8 <generic_rawtp_process_event+0x2b08>
    2bcc:      	mov	w8, #0x8                // =8
    2bd0:      	b	0x2c2c <generic_rawtp_process_event+0x2a5c>
    2bd4:      	cmp	w8, #0x33
    2bd8:      	b.eq	0x2c20 <generic_rawtp_process_event+0x2a50>
    2bdc:      	cmp	w8, #0x3c
    2be0:      	b.eq	0x2bf4 <generic_rawtp_process_event+0x2a24>
    2be4:      	cmp	w8, #0xff
    2be8:      	b.ne	0x2cd8 <generic_rawtp_process_event+0x2b08>
    2bec:      	mov	w8, #0x28               // =40
    2bf0:      	b	0x2c2c <generic_rawtp_process_event+0x2a5c>
    2bf4:      	ldrb	w8, [x23, #0x7]
    2bf8:      	lsl	w8, w8, #3
    2bfc:      	b	0x2c28 <generic_rawtp_process_event+0x2a58>
    2c00:      	ldrh	w8, [x23, #0x2]
    2c04:      	ldrh	w9, [x23]
    2c08:      	ldrb	w29, [x23, #0x6]
    2c0c:      	add	w8, w9, w8
    2c10:      	cmp	w29, #0x3c
    2c14:      	strh	w8, [x23]
    2c18:      	b.ls	0x2b70 <generic_rawtp_process_event+0x29a0>
    2c1c:      	b	0x2fdc <generic_rawtp_process_event+0x2e0c>
    2c20:      	ldrb	w8, [x23, #0x7]
    2c24:      	lsl	w8, w8, #2
    2c28:      	add	w8, w8, #0x8
    2c2c:      	strh	w8, [x23, #0x2]
    2c30:      	ldrh	w9, [x23]
    2c34:      	ldrb	w29, [x23, #0x6]
    2c38:      	add	w8, w9, w8
    2c3c:      	cmp	w29, #0x3c
    2c40:      	strh	w8, [x23]
    2c44:      	b.hi	0x2fdc <generic_rawtp_process_event+0x2e0c>
    2c48:      	mov	w9, #0x1                // =1
    2c4c:      	lsl	x9, x9, x29
    2c50:      	tst	x9, x21
    2c54:      	b.eq	0x2fdc <generic_rawtp_process_event+0x2e0c>
    2c58:      	ldr	x11, [sp, #0x48]
    2c5c:      	strb	w29, [x23, #0x5]
    2c60:      	mov	w9, #0x2                // =2
    2c64:      	mov	w10, #0x4               // =4
    2c68:      	mov	x0, x22
    2c6c:      	mov	w1, #0x2                // =2
    2c70:      	add	x8, x11, w8, uxth
    2c74:      	ldrh	w8, [x23]
    2c78:      	add	x2, x11, x8
    2c7c:      	blr	x10
    2c80:      	tbnz	x0, #0x3f, 0x2e30 <generic_rawtp_process_event+0x2c60>
    2c84:      	ldrb	w8, [x23, #0x5]
    2c88:      	cmp	w8, #0x32
    2c8c:      	b.gt	0x2cac <generic_rawtp_process_event+0x2adc>
    2c90:      	cbz	w8, 0x2ccc <generic_rawtp_process_event+0x2afc>
    2c94:      	cmp	w8, #0x2b
    2c98:      	b.eq	0x2ccc <generic_rawtp_process_event+0x2afc>
    2c9c:      	cmp	w8, #0x2c
    2ca0:      	b.ne	0x2db0 <generic_rawtp_process_event+0x2be0>
    2ca4:      	mov	w8, #0x8                // =8
    2ca8:      	b	0x2d04 <generic_rawtp_process_event+0x2b34>
    2cac:      	cmp	w8, #0x33
    2cb0:      	b.eq	0x2cf8 <generic_rawtp_process_event+0x2b28>
    2cb4:      	cmp	w8, #0x3c
    2cb8:      	b.eq	0x2ccc <generic_rawtp_process_event+0x2afc>
    2cbc:      	cmp	w8, #0xff
    2cc0:      	b.ne	0x2db0 <generic_rawtp_process_event+0x2be0>
    2cc4:      	mov	w8, #0x28               // =40
    2cc8:      	b	0x2d04 <generic_rawtp_process_event+0x2b34>
    2ccc:      	ldrb	w8, [x23, #0x7]
    2cd0:      	lsl	w8, w8, #3
    2cd4:      	b	0x2d00 <generic_rawtp_process_event+0x2b30>
    2cd8:      	ldrh	w8, [x23, #0x2]
    2cdc:      	ldrh	w9, [x23]
    2ce0:      	ldrb	w29, [x23, #0x6]
    2ce4:      	add	w8, w9, w8
    2ce8:      	cmp	w29, #0x3c
    2cec:      	strh	w8, [x23]
    2cf0:      	b.ls	0x2c48 <generic_rawtp_process_event+0x2a78>
    2cf4:      	b	0x2fdc <generic_rawtp_process_event+0x2e0c>
    2cf8:      	ldrb	w8, [x23, #0x7]
    2cfc:      	lsl	w8, w8, #2
    2d00:      	add	w8, w8, #0x8
    2d04:      	strh	w8, [x23, #0x2]
    2d08:      	ldrh	w9, [x23]
    2d0c:      	ldrb	w29, [x23, #0x6]
    2d10:      	add	w8, w9, w8
    2d14:      	cmp	w29, #0x3c
    2d18:      	strh	w8, [x23]
    2d1c:      	b.hi	0x2fdc <generic_rawtp_process_event+0x2e0c>
    2d20:      	mov	w9, #0x1                // =1
    2d24:      	lsl	x9, x9, x29
    2d28:      	tst	x9, x21
    2d2c:      	b.eq	0x2fdc <generic_rawtp_process_event+0x2e0c>
    2d30:      	ldr	x11, [sp, #0x48]
    2d34:      	strb	w29, [x23, #0x5]
    2d38:      	mov	w9, #0x2                // =2
    2d3c:      	mov	w10, #0x4               // =4
    2d40:      	mov	x0, x22
    2d44:      	mov	w1, #0x2                // =2
    2d48:      	add	x8, x11, w8, uxth
    2d4c:      	ldrh	w8, [x23]
    2d50:      	add	x2, x11, x8
    2d54:      	blr	x10
    2d58:      	tbnz	x0, #0x3f, 0x2e30 <generic_rawtp_process_event+0x2c60>
    2d5c:      	ldrb	w8, [x23, #0x5]
    2d60:      	cmp	w8, #0x32
    2d64:      	b.gt	0x2d84 <generic_rawtp_process_event+0x2bb4>
    2d68:      	cbz	w8, 0x2da4 <generic_rawtp_process_event+0x2bd4>
    2d6c:      	cmp	w8, #0x2b
    2d70:      	b.eq	0x2da4 <generic_rawtp_process_event+0x2bd4>
    2d74:      	cmp	w8, #0x2c
    2d78:      	b.ne	0x2fc0 <generic_rawtp_process_event+0x2df0>
    2d7c:      	mov	w8, #0x8                // =8
    2d80:      	b	0x2ddc <generic_rawtp_process_event+0x2c0c>
    2d84:      	cmp	w8, #0x33
    2d88:      	b.eq	0x2dd0 <generic_rawtp_process_event+0x2c00>
    2d8c:      	cmp	w8, #0x3c
    2d90:      	b.eq	0x2da4 <generic_rawtp_process_event+0x2bd4>
    2d94:      	cmp	w8, #0xff
    2d98:      	b.ne	0x2fc0 <generic_rawtp_process_event+0x2df0>
    2d9c:      	mov	w8, #0x28               // =40
    2da0:      	b	0x2ddc <generic_rawtp_process_event+0x2c0c>
    2da4:      	ldrb	w8, [x23, #0x7]
    2da8:      	lsl	w8, w8, #3
    2dac:      	b	0x2dd8 <generic_rawtp_process_event+0x2c08>
    2db0:      	ldrh	w8, [x23, #0x2]
    2db4:      	ldrh	w9, [x23]
    2db8:      	ldrb	w29, [x23, #0x6]
    2dbc:      	add	w8, w9, w8
    2dc0:      	cmp	w29, #0x3c
    2dc4:      	strh	w8, [x23]
    2dc8:      	b.ls	0x2d20 <generic_rawtp_process_event+0x2b50>
    2dcc:      	b	0x2fdc <generic_rawtp_process_event+0x2e0c>
    2dd0:      	ldrb	w8, [x23, #0x7]
    2dd4:      	lsl	w8, w8, #2
    2dd8:      	add	w8, w8, #0x8
    2ddc:      	strh	w8, [x23, #0x2]
    2de0:      	ldrh	w9, [x23]
    2de4:      	ldrb	w29, [x23, #0x6]
    2de8:      	add	w8, w9, w8
    2dec:      	cmp	w29, #0x3c
    2df0:      	strh	w8, [x23]
    2df4:      	b.hi	0x2fdc <generic_rawtp_process_event+0x2e0c>
    2df8:      	mov	w9, #0x1                // =1
    2dfc:      	lsl	x9, x9, x29
    2e00:      	tst	x9, x21
    2e04:      	b.eq	0x2fdc <generic_rawtp_process_event+0x2e0c>
    2e08:      	ldr	x11, [sp, #0x48]
    2e0c:      	strb	w29, [x23, #0x5]
    2e10:      	mov	w9, #0x2                // =2
    2e14:      	mov	w10, #0x4               // =4
    2e18:      	mov	x0, x22
    2e1c:      	mov	w1, #0x2                // =2
    2e20:      	add	x8, x11, w8, uxth
    2e24:      	ldrh	w8, [x23]
    2e28:      	add	x2, x11, x8
    2e2c:      	blr	x10
    2e30:      	mov	w29, wzr
    2e34:      	ldr	x23, [sp, #0x30]
    2e38:      	mov	w8, #0xa                // =10
    2e3c:      	strb	w29, [sp, #0x84]
    2e40:      	add	x2, x25, #0x8
    2e44:      	mov	w21, #0x10              // =16
    2e48:      	mov	w1, #0x10               // =16
    2e4c:      	mov	w22, #0x4               // =4
    2e50:      	strh	w29, [x23, #0x24]
    2e54:      	strh	w8, [x23, #0x26]
    2e58:      	mov	w8, #0x4                // =4
    2e5c:      	mov	x0, x23
    2e60:      	blr	x8
    2e64:      	add	x0, x23, #0x10
    2e68:      	add	x2, x25, #0x18
    2e6c:      	mov	w1, #0x10               // =16
    2e70:      	blr	x22
    2e74:      	cmp	w29, #0x11
    2e78:      	b.eq	0x2ebc <generic_rawtp_process_event+0x2cec>
    2e7c:      	cmp	w29, #0x6
    2e80:      	b.ne	0x2efc <generic_rawtp_process_event+0x2d2c>
    2e84:      	ldr	x8, [sp, #0x98]
    2e88:      	ldrh	w9, [sp, #0x90]
    2e8c:      	mov	w21, #0x2               // =2
    2e90:      	mov	w1, #0x2                // =2
    2e94:      	mov	w23, #0x4               // =4
    2e98:      	add	x22, x8, x9
    2e9c:      	ldr	x25, [sp, #0x30]
    2ea0:      	add	x0, x25, #0x20
    2ea4:      	mov	w8, #0x4                // =4
    2ea8:      	mov	x2, x22
    2eac:      	blr	x8
    2eb0:      	add	x0, x25, #0x22
    2eb4:      	add	x2, x22, #0x2
    2eb8:      	b	0x2ef0 <generic_rawtp_process_event+0x2d20>
    2ebc:      	ldr	x8, [sp, #0x98]
    2ec0:      	ldrh	w9, [sp, #0x90]
    2ec4:      	mov	w21, #0x2               // =2
    2ec8:      	mov	w1, #0x2                // =2
    2ecc:      	mov	w23, #0x4               // =4
    2ed0:      	add	x22, x8, x9
    2ed4:      	ldr	x25, [sp, #0x30]
    2ed8:      	add	x0, x25, #0x20
    2edc:      	mov	w8, #0x4                // =4
    2ee0:      	mov	x2, x22
    2ee4:      	blr	x8
    2ee8:      	add	x0, x25, #0x22
    2eec:      	add	x2, x22, #0x2
    2ef0:      	mov	w1, #0x2                // =2
    2ef4:      	blr	x23
    2ef8:      	b	0x2f04 <generic_rawtp_process_event+0x2d34>
    2efc:      	ldr	x8, [sp, #0x30]
    2f00:      	str	wzr, [x8, #0x20]
    2f04:      	ldr	x9, [sp, #0x30]
    2f08:      	add	x2, x24, #0xe0
    2f0c:      	add	x10, sp, #0xf0
    2f10:      	add	x0, sp, #0xf0
    2f14:      	ldrh	w8, [x9, #0x20]
    2f18:      	mov	w1, #0x8                // =8
    2f1c:      	rev	w8, w8
    2f20:      	lsr	w8, w8, #16
    2f24:      	strh	w8, [x9, #0x20]
    2f28:      	ldrh	w8, [x9, #0x22]
    2f2c:      	rev	w8, w8
    2f30:      	lsr	w8, w8, #16
    2f34:      	strh	w8, [x9, #0x22]
    2f38:      	mov	w8, #0x8                // =8
    2f3c:      	mov	w9, #0x4                // =4
    2f40:      	blr	x9
    2f44:      	add	x8, sp, #0xe0
    2f48:      	ldr	x8, [x8, #0x10]
    2f4c:      	cbz	x8, 0x2fb0 <generic_rawtp_process_event+0x2de0>
    2f50:      	add	x8, x8, #0x5
    2f54:      	mov	w9, #0x8                // =8
    2f58:      	add	x10, sp, #0x100
    2f5c:      	mov	w11, #0x4               // =4
    2f60:      	add	x22, sp, #0xe0
    2f64:      	ldr	x8, [x22, #0x10]
    2f68:      	add	x0, sp, #0x100
    2f6c:      	mov	w1, #0x8                // =8
    2f70:      	mov	w21, #0x4               // =4
    2f74:      	add	x2, x8, #0x5
    2f78:      	blr	x11
    2f7c:      	ldr	x8, [x22, #0x10]
    2f80:      	ldr	x9, [x22, #0x20]
    2f84:      	mov	w1, #0x4                // =4
    2f88:      	add	x22, x8, x9, lsl #3
    2f8c:      	ldr	x23, [sp, #0x30]
    2f90:      	add	x0, x23, #0x38
    2f94:      	mov	w8, #0x4                // =4
    2f98:      	add	x2, x22, #0x44
    2f9c:      	blr	x8
    2fa0:      	add	x0, x23, #0x3c
    2fa4:      	add	x2, x22, #0x45
    2fa8:      	mov	w1, #0x4                // =4
    2fac:      	blr	x21
    2fb0:      	adrp	x25, 0x2000 <generic_rawtp_process_event+0x1e30>
    2fb4:      	mov	w22, #0x40              // =64
    2fb8:      	ldr	x25, [x25]
    2fbc:      	b	0xe48 <generic_rawtp_process_event+0xc78>
    2fc0:      	ldrh	w8, [x23, #0x2]
    2fc4:      	ldrh	w9, [x23]
    2fc8:      	ldrb	w29, [x23, #0x6]
    2fcc:      	add	w8, w9, w8
    2fd0:      	cmp	w29, #0x3c
    2fd4:      	strh	w8, [x23]
    2fd8:      	b.ls	0x2df8 <generic_rawtp_process_event+0x2c28>
    2fdc:      	strh	w8, [sp, #0x90]
    2fe0:      	b	0x2e34 <generic_rawtp_process_event+0x2c64>
    2fe4:      	nop
    2fe8:      	nop
    2fec:      	nop

0000000000002ff0 <generic_rawtp_process_filter>:
    2ff0:      	sub	sp, sp, #0x130
    2ff4:      	str	x29, [sp, #0xe0]
    2ff8:      	stp	x30, x25, [sp, #0xf0]
    2ffc:      	stp	x24, x23, [sp, #0x100]
    3000:      	stp	x22, x21, [sp, #0x110]
    3004:      	stp	x20, x19, [sp, #0x120]
    3008:      	mov	x20, x0
    300c:      	str	wzr, [sp, #0x54]
    3010:      	adrp	x0, 0x3000 <generic_rawtp_process_filter+0x10>
    3014:      	mov	w8, #0x1                // =1
    3018:      	ldr	x0, [x0]
    301c:      	add	x9, sp, #0x54
    3020:      	add	x1, sp, #0x54
    3024:      	blr	x8
    3028:      	cbz	x0, 0x532c <generic_rawtp_process_filter+0x233c>
    302c:      	mov	w8, #0x5ec0             // =24256
    3030:      	mov	x22, x0
    3034:      	add	x29, x0, x8
    3038:      	mov	w8, #0x23               // =35
    303c:      	blr	x8
    3040:      	str	x0, [sp, #0x58]
    3044:      	add	x8, x0, #0x8d4
    3048:      	mov	w9, #0x4                // =4
    304c:      	mov	w10, #0x71              // =113
    3050:      	add	x11, sp, #0xd8
    3054:      	add	x0, sp, #0xd8
    3058:      	mov	w1, #0x4                // =4
    305c:      	ldr	x8, [sp, #0x58]
    3060:      	add	x2, x8, #0x8d4
    3064:      	blr	x10
    3068:      	ldr	w8, [sp, #0xd8]
    306c:      	adrp	x19, 0x3000 <generic_rawtp_process_filter+0x10>
    3070:      	add	x9, sp, #0xc8
    3074:      	add	x1, sp, #0xc8
    3078:      	str	w8, [sp, #0xc8]
    307c:      	mov	w8, #0x1                // =1
    3080:      	ldr	x19, [x19]
    3084:      	mov	x0, x19
    3088:      	blr	x8
    308c:      	cbz	x0, 0x309c <generic_rawtp_process_filter+0xac>
    3090:      	ldr	x8, [x0, #0x8]
    3094:      	mov	x24, x0
    3098:      	cbnz	x8, 0x3e8c <generic_rawtp_process_filter+0xe9c>
    309c:      	ldr	x8, [sp, #0x58]
    30a0:      	mov	w9, #0x8                // =8
    30a4:      	mov	w10, #0x71              // =113
    30a8:      	add	x11, sp, #0x58
    30ac:      	add	x0, sp, #0x58
    30b0:      	mov	w1, #0x8                // =8
    30b4:      	add	x8, x8, #0x8e0
    30b8:      	ldr	x8, [sp, #0x58]
    30bc:      	add	x2, x8, #0x8e0
    30c0:      	blr	x10
    30c4:      	ldr	x8, [sp, #0x58]
    30c8:      	cbz	x8, 0x3244 <generic_rawtp_process_filter+0x254>
    30cc:      	add	x8, x8, #0x8d4
    30d0:      	mov	w9, #0x4                // =4
    30d4:      	mov	w10, #0x71              // =113
    30d8:      	add	x11, sp, #0xd8
    30dc:      	ldr	x8, [sp, #0x58]
    30e0:      	add	x0, sp, #0xd8
    30e4:      	mov	w1, #0x4                // =4
    30e8:      	add	x2, x8, #0x8d4
    30ec:      	blr	x10
    30f0:      	ldr	w8, [sp, #0xd8]
    30f4:      	add	x9, sp, #0xc8
    30f8:      	add	x1, sp, #0xc8
    30fc:      	mov	x0, x19
    3100:      	str	w8, [sp, #0xc8]
    3104:      	mov	w8, #0x1                // =1
    3108:      	blr	x8
    310c:      	cbz	x0, 0x311c <generic_rawtp_process_filter+0x12c>
    3110:      	ldr	x8, [x0, #0x8]
    3114:      	mov	x24, x0
    3118:      	cbnz	x8, 0x3e8c <generic_rawtp_process_filter+0xe9c>
    311c:      	ldr	x8, [sp, #0x58]
    3120:      	mov	w9, #0x8                // =8
    3124:      	mov	w10, #0x71              // =113
    3128:      	add	x11, sp, #0x58
    312c:      	add	x0, sp, #0x58
    3130:      	mov	w1, #0x8                // =8
    3134:      	add	x8, x8, #0x8e0
    3138:      	ldr	x8, [sp, #0x58]
    313c:      	add	x2, x8, #0x8e0
    3140:      	blr	x10
    3144:      	ldr	x8, [sp, #0x58]
    3148:      	cbz	x8, 0x3244 <generic_rawtp_process_filter+0x254>
    314c:      	add	x8, x8, #0x8d4
    3150:      	mov	w9, #0x4                // =4
    3154:      	mov	w10, #0x71              // =113
    3158:      	add	x11, sp, #0xd8
    315c:      	ldr	x8, [sp, #0x58]
    3160:      	add	x0, sp, #0xd8
    3164:      	mov	w1, #0x4                // =4
    3168:      	add	x2, x8, #0x8d4
    316c:      	blr	x10
    3170:      	ldr	w8, [sp, #0xd8]
    3174:      	add	x9, sp, #0xc8
    3178:      	add	x1, sp, #0xc8
    317c:      	mov	x0, x19
    3180:      	str	w8, [sp, #0xc8]
    3184:      	mov	w8, #0x1                // =1
    3188:      	blr	x8
    318c:      	cbz	x0, 0x319c <generic_rawtp_process_filter+0x1ac>
    3190:      	ldr	x8, [x0, #0x8]
    3194:      	mov	x24, x0
    3198:      	cbnz	x8, 0x3e8c <generic_rawtp_process_filter+0xe9c>
    319c:      	ldr	x8, [sp, #0x58]
    31a0:      	mov	w9, #0x8                // =8
    31a4:      	mov	w10, #0x71              // =113
    31a8:      	add	x11, sp, #0x58
    31ac:      	add	x0, sp, #0x58
    31b0:      	mov	w1, #0x8                // =8
    31b4:      	add	x8, x8, #0x8e0
    31b8:      	ldr	x8, [sp, #0x58]
    31bc:      	add	x2, x8, #0x8e0
    31c0:      	blr	x10
    31c4:      	ldr	x8, [sp, #0x58]
    31c8:      	cbz	x8, 0x3244 <generic_rawtp_process_filter+0x254>
    31cc:      	add	x8, x8, #0x8d4
    31d0:      	mov	w9, #0x4                // =4
    31d4:      	mov	w10, #0x71              // =113
    31d8:      	add	x11, sp, #0xd8
    31dc:      	ldr	x8, [sp, #0x58]
    31e0:      	add	x0, sp, #0xd8
    31e4:      	mov	w1, #0x4                // =4
    31e8:      	add	x2, x8, #0x8d4
    31ec:      	blr	x10
    31f0:      	ldr	w8, [sp, #0xd8]
    31f4:      	add	x9, sp, #0xc8
    31f8:      	add	x1, sp, #0xc8
    31fc:      	mov	x0, x19
    3200:      	str	w8, [sp, #0xc8]
    3204:      	mov	w8, #0x1                // =1
    3208:      	blr	x8
    320c:      	cbz	x0, 0x321c <generic_rawtp_process_filter+0x22c>
    3210:      	ldr	x8, [x0, #0x8]
    3214:      	mov	x24, x0
    3218:      	cbnz	x8, 0x3e8c <generic_rawtp_process_filter+0xe9c>
    321c:      	ldr	x8, [sp, #0x58]
    3220:      	mov	w9, #0x8                // =8
    3224:      	mov	w10, #0x71              // =113
    3228:      	add	x11, sp, #0x58
    322c:      	add	x0, sp, #0x58
    3230:      	mov	w1, #0x8                // =8
    3234:      	add	x8, x8, #0x8e0
    3238:      	ldr	x8, [sp, #0x58]
    323c:      	add	x2, x8, #0x8e0
    3240:      	blr	x10
    3244:      	str	x20, [sp, #0x38]
    3248:      	mov	w8, #0x23               // =35
    324c:      	blr	x8
    3250:      	add	x2, x0, #0x8d4
    3254:      	mov	w8, #0x4                // =4
    3258:      	add	x9, sp, #0x58
    325c:      	mov	x24, x0
    3260:      	add	x0, sp, #0x58
    3264:      	mov	w1, #0x4                // =4
    3268:      	blr	x8
    326c:      	ldr	w8, [sp, #0x58]
    3270:      	mov	x19, x29
    3274:      	str	w8, [x19, #0x50]!
    3278:      	mov	w8, #0x7d               // =125
    327c:      	blr	x8
    3280:      	str	x0, [x22, #0x5f18]
    3284:      	str	wzr, [x19, #0x10]
    3288:      	add	x2, x24, #0x60
    328c:      	mov	w8, #0x8                // =8
    3290:      	mov	w9, #0x71               // =113
    3294:      	add	x10, sp, #0xc8
    3298:      	str	xzr, [x22, #0x5f28]
    329c:      	str	x19, [sp, #0x48]
    32a0:      	add	x0, sp, #0xc8
    32a4:      	mov	w1, #0x8                // =8
    32a8:      	str	wzr, [x19, #0x20]
    32ac:      	blr	x9
    32b0:      	ldr	x8, [sp, #0xc8]
    32b4:      	cbz	x8, 0x3324 <generic_rawtp_process_filter+0x334>
    32b8:      	add	x8, x8, #0x4
    32bc:      	mov	w9, #0x4                // =4
    32c0:      	mov	w10, #0x71              // =113
    32c4:      	add	x11, sp, #0xd8
    32c8:      	ldr	x8, [sp, #0xc8]
    32cc:      	add	x0, sp, #0xd8
    32d0:      	mov	w1, #0x4                // =4
    32d4:      	add	x2, x8, #0x4
    32d8:      	blr	x10
    32dc:      	ldr	w8, [sp, #0xd8]
    32e0:      	cbz	w8, 0x3324 <generic_rawtp_process_filter+0x334>
    32e4:      	ldr	x9, [sp, #0xc8]
    32e8:      	lsl	w8, w8, #4
    32ec:      	mov	w10, #0x71              // =113
    32f0:      	add	x11, sp, #0x58
    32f4:      	add	x0, sp, #0x58
    32f8:      	mov	w1, #0x10               // =16
    32fc:      	add	x8, x9, x8
    3300:      	mov	w9, #0x10               // =16
    3304:      	add	x8, x8, #0x80
    3308:      	ldr	w9, [sp, #0xd8]
    330c:      	ldr	x8, [sp, #0xc8]
    3310:      	lsl	w9, w9, #4
    3314:      	add	x8, x8, x9
    3318:      	add	x2, x8, #0x80
    331c:      	blr	x10
    3320:      	ldr	w8, [sp, #0x58]
    3324:      	str	w8, [x29, #0x74]
    3328:      	mov	w8, #0x5f60             // =24416
    332c:      	str	x22, [sp, #0xe8]
    3330:      	add	x23, x24, #0xae0
    3334:      	mov	w19, #0x8               // =8
    3338:      	add	x25, x22, x8
    333c:      	add	x8, sp, #0x58
    3340:      	mov	w9, #0x4                // =4
    3344:      	add	x0, sp, #0x58
    3348:      	mov	w1, #0x8                // =8
    334c:      	mov	x2, x23
    3350:      	mov	w21, #0x4               // =4
    3354:      	blr	x9
    3358:      	ldr	x20, [sp, #0x58]
    335c:      	ldr	x9, [sp, #0xe8]
    3360:      	mov	w8, #0x5f68             // =24424
    3364:      	mov	w1, #0x8                // =8
    3368:      	add	x0, x9, x8
    336c:      	add	x2, x20, #0x40
    3370:      	mov	w8, #0x4                // =4
    3374:      	blr	x8
    3378:      	ldr	x9, [sp, #0xe8]
    337c:      	mov	w8, #0x5f70             // =24432
    3380:      	add	x2, x20, #0x30
    3384:      	mov	w1, #0x8                // =8
    3388:      	add	x0, x9, x8
    338c:      	mov	w8, #0x4                // =4
    3390:      	blr	x8
    3394:      	add	x2, x20, #0x38
    3398:      	mov	w8, #0x4                // =4
    339c:      	mov	x0, x25
    33a0:      	mov	w1, #0x8                // =8
    33a4:      	blr	x8
    33a8:      	ldr	x9, [sp, #0xe8]
    33ac:      	mov	w8, #0x5f38             // =24376
    33b0:      	add	x2, x24, #0xb50
    33b4:      	add	x0, sp, #0xd8
    33b8:      	mov	w1, #0x8                // =8
    33bc:      	add	x25, x9, x8
    33c0:      	add	x8, sp, #0xd8
    33c4:      	mov	w9, #0x4                // =4
    33c8:      	blr	x9
    33cc:      	add	x12, sp, #0xd8
    33d0:      	mov	w9, #0x48               // =72
    33d4:      	add	x10, sp, #0x58
    33d8:      	ldr	x8, [x12]
    33dc:      	mov	w11, #0x4               // =4
    33e0:      	add	x0, sp, #0x58
    33e4:      	mov	w1, #0x48               // =72
    33e8:      	ldr	x2, [x12]
    33ec:      	blr	x11
    33f0:      	ldr	x8, [sp, #0x60]
    33f4:      	mov	w9, #0x4                // =4
    33f8:      	mov	x0, x25
    33fc:      	mov	w1, #0x4                // =4
    3400:      	add	x8, x8, #0x218
    3404:      	ldr	x8, [sp, #0x60]
    3408:      	ldr	x22, [sp, #0xe8]
    340c:      	add	x2, x8, #0x218
    3410:      	blr	x9
    3414:      	mov	w8, #0x5f3c             // =24380
    3418:      	mov	w9, #0x4                // =4
    341c:      	mov	w1, #0x4                // =4
    3420:      	add	x0, x22, x8
    3424:      	ldr	x8, [sp, #0x68]
    3428:      	add	x8, x8, #0x4d8
    342c:      	ldr	x8, [sp, #0x68]
    3430:      	add	x2, x8, #0x4d8
    3434:      	blr	x9
    3438:      	mov	w8, #0x5f40             // =24384
    343c:      	mov	w9, #0x4                // =4
    3440:      	mov	w1, #0x4                // =4
    3444:      	add	x0, x22, x8
    3448:      	ldr	x8, [sp, #0x70]
    344c:      	add	x8, x8, #0x58
    3450:      	ldr	x8, [sp, #0x70]
    3454:      	add	x2, x8, #0x58
    3458:      	blr	x9
    345c:      	str	xzr, [sp, #0xc0]
    3460:      	add	x2, x24, #0x938
    3464:      	add	x8, sp, #0xc0
    3468:      	add	x0, sp, #0xc0
    346c:      	mov	w1, #0x8                // =8
    3470:      	blr	x21
    3474:      	ldr	x8, [sp, #0xc0]
    3478:      	cbz	x8, 0x3500 <generic_rawtp_process_filter+0x510>
    347c:      	str	wzr, [sp, #0xb8]
    3480:      	add	x8, x8, #0x4
    3484:      	add	x9, sp, #0xb8
    3488:      	mov	w10, #0x4               // =4
    348c:      	add	x0, sp, #0xb8
    3490:      	mov	w1, #0x4                // =4
    3494:      	mov	w19, #0x4               // =4
    3498:      	ldr	x8, [sp, #0xc0]
    349c:      	add	x2, x8, #0x4
    34a0:      	blr	x10
    34a4:      	ldr	x8, [sp, #0xc0]
    34a8:      	ldrsw	x9, [sp, #0xb8]
    34ac:      	add	x10, sp, #0xc8
    34b0:      	mov	w11, #0x4               // =4
    34b4:      	add	x0, sp, #0xc8
    34b8:      	mov	w1, #0x10               // =16
    34bc:      	add	x8, x8, x9, lsl #4
    34c0:      	mov	w9, #0x10               // =16
    34c4:      	add	x8, x8, #0x80
    34c8:      	ldr	x8, [sp, #0xc0]
    34cc:      	ldrsw	x9, [sp, #0xb8]
    34d0:      	add	x8, x8, x9, lsl #4
    34d4:      	add	x2, x8, #0x80
    34d8:      	blr	x11
    34dc:      	mov	w8, #0x5f44             // =24388
    34e0:      	mov	w1, #0x4                // =4
    34e4:      	add	x0, x22, x8
    34e8:      	ldr	x8, [sp, #0xd0]
    34ec:      	add	x8, x8, #0x158
    34f0:      	ldr	x8, [sp, #0xd0]
    34f4:      	add	x2, x8, #0x158
    34f8:      	blr	x19
    34fc:      	b	0x3504 <generic_rawtp_process_filter+0x514>
    3500:      	str	wzr, [x29, #0x84]
    3504:      	mov	w8, #0x5f48             // =24392
    3508:      	mov	w9, #0x4                // =4
    350c:      	mov	w1, #0x4                // =4
    3510:      	mov	w19, #0x4               // =4
    3514:      	add	x0, x22, x8
    3518:      	ldr	x8, [sp, #0x78]
    351c:      	add	x8, x8, #0x158
    3520:      	ldr	x8, [sp, #0x78]
    3524:      	add	x2, x8, #0x158
    3528:      	blr	x9
    352c:      	mov	w8, #0x5f4c             // =24396
    3530:      	mov	w9, #0x4                // =4
    3534:      	mov	w1, #0x4                // =4
    3538:      	add	x0, x22, x8
    353c:      	ldr	x8, [sp, #0x80]
    3540:      	add	x8, x8, #0x118
    3544:      	ldr	x8, [sp, #0x80]
    3548:      	add	x2, x8, #0x118
    354c:      	blr	x9
    3550:      	mov	w8, #0x5f50             // =24400
    3554:      	mov	w9, #0x4                // =4
    3558:      	mov	w1, #0x4                // =4
    355c:      	add	x0, x22, x8
    3560:      	ldr	x8, [sp, #0x88]
    3564:      	add	x8, x8, #0x98
    3568:      	ldr	x8, [sp, #0x88]
    356c:      	add	x2, x8, #0x98
    3570:      	blr	x9
    3574:      	mov	w8, #0x5f54             // =24404
    3578:      	mov	w9, #0x4                // =4
    357c:      	mov	w1, #0x4                // =4
    3580:      	add	x0, x22, x8
    3584:      	ldr	x8, [sp, #0x90]
    3588:      	add	x8, x8, #0x98
    358c:      	ldr	x8, [sp, #0x90]
    3590:      	add	x2, x8, #0x98
    3594:      	blr	x9
    3598:      	mov	w8, #0x5f58             // =24408
    359c:      	mov	w9, #0x4                // =4
    35a0:      	mov	w1, #0x4                // =4
    35a4:      	add	x0, x22, x8
    35a8:      	ldr	x8, [sp, #0x98]
    35ac:      	add	x8, x8, #0x58
    35b0:      	ldr	x8, [sp, #0x98]
    35b4:      	add	x2, x8, #0x58
    35b8:      	blr	x9
    35bc:      	stp	xzr, xzr, [sp, #0xc0]
    35c0:      	mov	w20, #0x8               // =8
    35c4:      	add	x8, sp, #0xc8
    35c8:      	mov	w9, #0x4                // =4
    35cc:      	add	x0, sp, #0xc8
    35d0:      	mov	w1, #0x8                // =8
    35d4:      	mov	x2, x23
    35d8:      	blr	x9
    35dc:      	ldr	x8, [sp, #0xc8]
    35e0:      	add	x9, sp, #0xc0
    35e4:      	mov	w10, #0x4               // =4
    35e8:      	add	x0, sp, #0xc0
    35ec:      	mov	w1, #0x8                // =8
    35f0:      	add	x8, x8, #0x90
    35f4:      	ldr	x8, [sp, #0xc8]
    35f8:      	add	x2, x8, #0x90
    35fc:      	blr	x10
    3600:      	mov	w8, #0x5f5c             // =24412
    3604:      	mov	w1, #0x4                // =4
    3608:      	add	x0, x22, x8
    360c:      	ldr	x8, [sp, #0xc0]
    3610:      	add	x8, x8, #0x158
    3614:      	ldr	x8, [sp, #0xc0]
    3618:      	add	x2, x8, #0x158
    361c:      	blr	x19
    3620:      	ldr	w8, [x29, #0x74]
    3624:      	cmp	w8, #0x1
    3628:      	b.ne	0x3638 <generic_rawtp_process_filter+0x648>
    362c:      	ldr	w8, [x29, #0x70]
    3630:      	orr	w8, w8, #0x2000000
    3634:      	str	w8, [x29, #0x70]
    3638:      	add	x0, x29, #0xb8
    363c:      	mov	w1, wzr
    3640:      	mov	w2, #0x308              // =776
    3644:      	bl	0x3644 <generic_rawtp_process_filter+0x654>
    3648:      	mov	w8, #0x6290             // =25232
    364c:      	add	x2, x24, #0x858
    3650:      	mov	w19, #0x8               // =8
    3654:      	mov	w9, #0x4                // =4
    3658:      	add	x0, sp, #0xc8
    365c:      	mov	w1, #0x8                // =8
    3660:      	mov	w20, #0x4               // =4
    3664:      	add	x21, x22, x8
    3668:      	add	x8, sp, #0xc8
    366c:      	blr	x9
    3670:      	ldr	x8, [sp, #0xc8]
    3674:      	add	x9, sp, #0x58
    3678:      	add	x0, sp, #0x58
    367c:      	mov	w1, #0x8                // =8
    3680:      	add	x8, x8, #0x528
    3684:      	ldr	x8, [sp, #0xc8]
    3688:      	add	x2, x8, #0x528
    368c:      	blr	x20
    3690:      	str	wzr, [sp, #0xa4]
    3694:      	adrp	x0, 0x3000 <generic_rawtp_process_filter+0x10>
    3698:      	ldr	x19, [sp, #0x58]
    369c:      	mov	w8, #0x1                // =1
    36a0:      	add	x9, sp, #0xa4
    36a4:      	add	x1, sp, #0xa4
    36a8:      	ldr	x0, [x0]
    36ac:      	blr	x8
    36b0:      	cbz	x0, 0x3cd4 <generic_rawtp_process_filter+0xce4>
    36b4:      	mov	w8, #0x1000             // =4096
    36b8:      	str	x21, [sp, #0x30]
    36bc:      	str	x29, [sp, #0x40]
    36c0:      	mov	x24, x0
    36c4:      	add	x20, x0, #0x1, lsl #12  // =0x1000
    36c8:      	str	w8, [x29, #0x550]
    36cc:      	mov	w8, #0x23               // =35
    36d0:      	blr	x8
    36d4:      	add	x2, x0, #0xb30
    36d8:      	mov	w23, #0x8               // =8
    36dc:      	add	x8, sp, #0xa8
    36e0:      	mov	w9, #0x4                // =4
    36e4:      	add	x0, sp, #0xa8
    36e8:      	mov	w1, #0x8                // =8
    36ec:      	mov	w29, #0x4               // =4
    36f0:      	blr	x9
    36f4:      	ldr	x22, [sp, #0xa8]
    36f8:      	add	x25, x19, #0x48
    36fc:      	add	x8, sp, #0xb0
    3700:      	mov	w9, #0x4                // =4
    3704:      	add	x0, sp, #0xb0
    3708:      	mov	w1, #0x8                // =8
    370c:      	mov	x2, x25
    3710:      	blr	x9
    3714:      	ldr	x21, [sp, #0xb0]
    3718:      	add	x8, sp, #0x58
    371c:      	add	x0, sp, #0x58
    3720:      	mov	w1, #0x8                // =8
    3724:      	add	x2, x21, #0x10
    3728:      	blr	x29
    372c:      	ldr	x8, [sp, #0x58]
    3730:      	cbz	x8, 0x3970 <generic_rawtp_process_filter+0x980>
    3734:      	ldr	x8, [sp, #0x40]
    3738:      	stp	xzr, xzr, [sp, #0x58]
    373c:      	add	x21, x22, #0x18
    3740:      	add	x9, sp, #0x58
    3744:      	add	x2, x22, #0x20
    3748:      	mov	w22, #0x8               // =8
    374c:      	stp	x24, xzr, [sp, #0x68]
    3750:      	add	x0, sp, #0x58
    3754:      	mov	w1, #0x8                // =8
    3758:      	add	x29, x19, #0x40
    375c:      	add	x19, x9, #0x8
    3760:      	add	x24, x9, #0x18
    3764:      	stp	xzr, xzr, [sp, #0x78]
    3768:      	add	x23, x9, #0x20
    376c:      	str	x20, [sp, #0x88]
    3770:      	str	x20, [sp, #0x28]
    3774:      	mov	w20, #0x4               // =4
    3778:      	ldr	w8, [x8, #0x550]
    377c:      	strb	wzr, [sp, #0x94]
    3780:      	str	w8, [sp, #0x90]
    3784:      	mov	w8, #0x4                // =4
    3788:      	blr	x8
    378c:      	mov	w8, #0x4                // =4
    3790:      	mov	x0, x19
    3794:      	mov	w1, #0x8                // =8
    3798:      	mov	x2, x21
    379c:      	blr	x8
    37a0:      	mov	w8, #0x4                // =4
    37a4:      	mov	x0, x24
    37a8:      	mov	w1, #0x8                // =8
    37ac:      	mov	x2, x25
    37b0:      	blr	x8
    37b4:      	mov	x0, x23
    37b8:      	mov	w1, #0x8                // =8
    37bc:      	mov	x2, x29
    37c0:      	blr	x20
    37c4:      	ldr	x8, [sp, #0x78]
    37c8:      	sub	x8, x8, #0x20
    37cc:      	str	x8, [sp, #0x80]
    37d0:      	adrp	x8, 0x3000 <generic_rawtp_process_filter+0x10>
    37d4:      	ldr	x8, [x8]
    37d8:      	ldrb	w8, [x8]
    37dc:      	cbz	w8, 0x39c4 <generic_rawtp_process_filter+0x9d4>
    37e0:      	mov	w19, #0x800             // =2048
    37e4:      	mov	w21, #0x8               // =8
    37e8:      	add	x23, sp, #0xb8
    37ec:      	add	x29, sp, #0xd8
    37f0:      	b	0x3850 <generic_rawtp_process_filter+0x860>
    37f4:      	nop
    37f8:      	nop
    37fc:      	nop
    3800:      	add	x2, x22, #0x10
    3804:      	mov	w8, #0x4                // =4
    3808:      	add	x0, sp, #0xd8
    380c:      	mov	w1, #0x8                // =8
    3810:      	blr	x8
    3814:      	add	x20, sp, #0xd8
    3818:      	ldr	x8, [sp, #0x80]
    381c:      	ldr	x9, [x20]
    3820:      	cmp	x8, x9
    3824:      	b.eq	0x3b50 <generic_rawtp_process_filter+0xb60>
    3828:      	add	x2, x22, #0x18
    382c:      	mov	w8, #0x4                // =4
    3830:      	mov	x0, x24
    3834:      	mov	w1, #0x8                // =8
    3838:      	blr	x8
    383c:      	ldr	x8, [x20]
    3840:      	add	x9, x8, #0x20
    3844:      	stp	x9, x8, [sp, #0x78]
    3848:      	subs	w19, w19, #0x1
    384c:      	b.eq	0x3b58 <generic_rawtp_process_filter+0xb68>
    3850:      	ldp	x20, x2, [sp, #0x70]
    3854:      	ldp	x8, x9, [sp, #0x58]
    3858:      	cmp	x20, x8
    385c:      	ccmp	x2, x9, #0x0, eq
    3860:      	b.eq	0x3b50 <generic_rawtp_process_filter+0xb60>
    3864:      	ldr	x22, [sp, #0x80]
    3868:      	mov	w8, #0x4                // =4
    386c:      	add	x0, sp, #0xb8
    3870:      	mov	w1, #0x8                // =8
    3874:      	blr	x8
    3878:      	ldr	x8, [sp, #0xb8]
    387c:      	cmp	x20, x8
    3880:      	b.eq	0x3800 <generic_rawtp_process_filter+0x810>
    3884:      	add	x25, x20, #0x18
    3888:      	mov	w8, #0x4                // =4
    388c:      	add	x0, sp, #0xd8
    3890:      	mov	w1, #0x8                // =8
    3894:      	mov	x2, x25
    3898:      	blr	x8
    389c:      	add	x8, sp, #0xd8
    38a0:      	ldr	x8, [x8]
    38a4:      	cmp	x8, x20
    38a8:      	b.eq	0x3800 <generic_rawtp_process_filter+0x810>
    38ac:      	mov	w8, #0x4                // =4
    38b0:      	add	x9, sp, #0xc0
    38b4:      	add	x0, sp, #0xc0
    38b8:      	mov	w1, #0x8                // =8
    38bc:      	mov	x2, x25
    38c0:      	blr	x8
    38c4:      	add	x2, x20, #0x20
    38c8:      	mov	w8, #0x4                // =4
    38cc:      	mov	w9, #0x10               // =16
    38d0:      	add	x10, sp, #0xc8
    38d4:      	add	x0, sp, #0xc8
    38d8:      	mov	w1, #0x10               // =16
    38dc:      	blr	x8
    38e0:      	ldr	w20, [sp, #0xcc]
    38e4:      	ldr	x8, [sp, #0x68]
    38e8:      	ldr	x10, [sp, #0x88]
    38ec:      	sub	x12, x10, x8
    38f0:      	ldr	w22, [sp, #0x90]
    38f4:      	subs	w10, w20, w22
    38f8:      	ldr	x9, [sp, #0xd0]
    38fc:      	csel	w10, wzr, w10, lo
    3900:      	cmp	w22, w20
    3904:      	csel	w11, w22, w20, lo
    3908:      	cinc	w13, w11, hi
    390c:      	sub	w14, w22, w13
    3910:      	subs	x12, x12, x13
    3914:      	str	w14, [sp, #0x90]
    3918:      	b.lo	0x3b58 <generic_rawtp_process_filter+0xb68>
    391c:      	cmp	x12, #0xfff
    3920:      	b.hi	0x3b58 <generic_rawtp_process_filter+0xb68>
    3924:      	cmp	w22, w20
    3928:      	b.ls	0x3934 <generic_rawtp_process_filter+0x944>
    392c:      	mov	w13, #0x2f              // =47
    3930:      	strb	w13, [x8, x12]
    3934:      	add	x25, x8, x12
    3938:      	cmp	w22, w20
    393c:      	add	x2, x9, x10
    3940:      	and	w1, w11, #0xff
    3944:      	mov	w8, #0x4                // =4
    3948:      	cinc	x0, x25, hi
    394c:      	blr	x8
    3950:      	cmp	w22, w20
    3954:      	str	x25, [sp, #0x88]
    3958:      	b.ls	0x3b58 <generic_rawtp_process_filter+0xb68>
    395c:      	ldr	x8, [sp, #0xc0]
    3960:      	str	x8, [sp, #0x70]
    3964:      	subs	w19, w19, #0x1
    3968:      	b.ne	0x3850 <generic_rawtp_process_filter+0x860>
    396c:      	b	0x3b58 <generic_rawtp_process_filter+0xb68>
    3970:      	add	x2, x21, #0x18
    3974:      	mov	w8, #0x8                // =8
    3978:      	mov	w9, #0x4                // =4
    397c:      	add	x10, sp, #0x58
    3980:      	add	x0, sp, #0x58
    3984:      	mov	w1, #0x8                // =8
    3988:      	blr	x9
    398c:      	ldr	x8, [sp, #0x58]
    3990:      	cmp	x8, x21
    3994:      	b.eq	0x3734 <generic_rawtp_process_filter+0x744>
    3998:      	ldr	x29, [sp, #0x40]
    399c:      	ldr	w9, [x29, #0x550]
    39a0:      	sub	w8, w9, #0xa
    39a4:      	cmp	w9, #0x9
    39a8:      	str	w8, [x29, #0x550]
    39ac:      	b.gt	0x4080 <generic_rawtp_process_filter+0x1090>
    39b0:      	ldr	x21, [sp, #0x30]
    39b4:      	mov	w9, #-0x24              // =-36
    39b8:      	mov	x24, x20
    39bc:      	str	w9, [x29, #0x554]
    39c0:      	b	0x3bbc <generic_rawtp_process_filter+0xbcc>
    39c4:      	mov	w19, #0x800             // =2048
    39c8:      	mov	w21, #0x8               // =8
    39cc:      	add	x23, sp, #0xb8
    39d0:      	add	x29, sp, #0xd8
    39d4:      	b	0x3a30 <generic_rawtp_process_filter+0xa40>
    39d8:      	nop
    39dc:      	nop
    39e0:      	add	x2, x22, #0x10
    39e4:      	mov	w8, #0x4                // =4
    39e8:      	add	x0, sp, #0xd8
    39ec:      	mov	w1, #0x8                // =8
    39f0:      	blr	x8
    39f4:      	add	x20, sp, #0xd8
    39f8:      	ldr	x8, [sp, #0x80]
    39fc:      	ldr	x9, [x20]
    3a00:      	cmp	x8, x9
    3a04:      	b.eq	0x3b50 <generic_rawtp_process_filter+0xb60>
    3a08:      	add	x2, x22, #0x18
    3a0c:      	mov	w8, #0x4                // =4
    3a10:      	mov	x0, x24
    3a14:      	mov	w1, #0x8                // =8
    3a18:      	blr	x8
    3a1c:      	ldr	x8, [x20]
    3a20:      	add	x9, x8, #0x20
    3a24:      	stp	x9, x8, [sp, #0x78]
    3a28:      	subs	w19, w19, #0x1
    3a2c:      	b.eq	0x3b58 <generic_rawtp_process_filter+0xb68>
    3a30:      	ldp	x20, x2, [sp, #0x70]
    3a34:      	ldp	x8, x9, [sp, #0x58]
    3a38:      	cmp	x20, x8
    3a3c:      	ccmp	x2, x9, #0x0, eq
    3a40:      	b.eq	0x3b50 <generic_rawtp_process_filter+0xb60>
    3a44:      	ldr	x22, [sp, #0x80]
    3a48:      	mov	w8, #0x4                // =4
    3a4c:      	add	x0, sp, #0xb8
    3a50:      	mov	w1, #0x8                // =8
    3a54:      	blr	x8
    3a58:      	ldr	x8, [sp, #0xb8]
    3a5c:      	cmp	x20, x8
    3a60:      	b.eq	0x39e0 <generic_rawtp_process_filter+0x9f0>
    3a64:      	add	x25, x20, #0x18
    3a68:      	mov	w8, #0x4                // =4
    3a6c:      	add	x0, sp, #0xd8
    3a70:      	mov	w1, #0x8                // =8
    3a74:      	mov	x2, x25
    3a78:      	blr	x8
    3a7c:      	add	x8, sp, #0xd8
    3a80:      	ldr	x8, [x8]
    3a84:      	cmp	x8, x20
    3a88:      	b.eq	0x39e0 <generic_rawtp_process_filter+0x9f0>
    3a8c:      	mov	w8, #0x4                // =4
    3a90:      	add	x9, sp, #0xc0
    3a94:      	add	x0, sp, #0xc0
    3a98:      	mov	w1, #0x8                // =8
    3a9c:      	mov	x2, x25
    3aa0:      	blr	x8
    3aa4:      	add	x2, x20, #0x20
    3aa8:      	mov	w8, #0x4                // =4
    3aac:      	mov	w9, #0x10               // =16
    3ab0:      	add	x10, sp, #0xc8
    3ab4:      	add	x0, sp, #0xc8
    3ab8:      	mov	w1, #0x10               // =16
    3abc:      	blr	x8
    3ac0:      	ldr	w20, [sp, #0xcc]
    3ac4:      	ldr	x8, [sp, #0x68]
    3ac8:      	ldr	x10, [sp, #0x88]
    3acc:      	sub	x12, x10, x8
    3ad0:      	ldr	w22, [sp, #0x90]
    3ad4:      	subs	w10, w20, w22
    3ad8:      	ldr	x9, [sp, #0xd0]
    3adc:      	csel	w10, wzr, w10, lo
    3ae0:      	cmp	w22, w20
    3ae4:      	csel	w11, w22, w20, lo
    3ae8:      	cinc	w13, w11, hi
    3aec:      	sub	w14, w22, w13
    3af0:      	subs	x12, x12, x13
    3af4:      	str	w14, [sp, #0x90]
    3af8:      	b.lo	0x3b58 <generic_rawtp_process_filter+0xb68>
    3afc:      	cmp	x12, #0xfff
    3b00:      	b.hi	0x3b58 <generic_rawtp_process_filter+0xb68>
    3b04:      	cmp	w22, w20
    3b08:      	b.ls	0x3b14 <generic_rawtp_process_filter+0xb24>
    3b0c:      	mov	w13, #0x2f              // =47
    3b10:      	strb	w13, [x8, x12]
    3b14:      	add	x25, x8, x12
    3b18:      	cmp	w22, w20
    3b1c:      	add	x2, x9, x10
    3b20:      	and	w1, w11, #0xff
    3b24:      	mov	w8, #0x4                // =4
    3b28:      	cinc	x0, x25, hi
    3b2c:      	blr	x8
    3b30:      	cmp	w22, w20
    3b34:      	str	x25, [sp, #0x88]
    3b38:      	b.ls	0x3b58 <generic_rawtp_process_filter+0xb68>
    3b3c:      	ldr	x8, [sp, #0xc0]
    3b40:      	str	x8, [sp, #0x70]
    3b44:      	subs	w19, w19, #0x1
    3b48:      	b.ne	0x3a30 <generic_rawtp_process_filter+0xa40>
    3b4c:      	b	0x3b58 <generic_rawtp_process_filter+0xb68>
    3b50:      	mov	w8, #0x1                // =1
    3b54:      	strb	w8, [sp, #0x94]
    3b58:      	ldr	x24, [sp, #0x88]
    3b5c:      	ldr	x9, [sp, #0x28]
    3b60:      	cmp	x24, x9
    3b64:      	b.eq	0x3ba8 <generic_rawtp_process_filter+0xbb8>
    3b68:      	ldrb	w8, [sp, #0x94]
    3b6c:      	ldr	x29, [sp, #0x40]
    3b70:      	cmp	w8, #0x0
    3b74:      	ldr	x21, [sp, #0x30]
    3b78:      	cset	w8, eq
    3b7c:      	lsl	w9, w8, #1
    3b80:      	ldr	w8, [sp, #0x90]
    3b84:      	cmp	w8, #0x1
    3b88:      	str	w8, [x29, #0x550]
    3b8c:      	str	w9, [x29, #0x554]
    3b90:      	b.lt	0x3ba0 <generic_rawtp_process_filter+0xbb0>
    3b94:      	mov	w9, #0x1000             // =4096
    3b98:      	sub	w8, w9, w8
    3b9c:      	str	w8, [x29, #0x550]
    3ba0:      	cbnz	x24, 0x3bbc <generic_rawtp_process_filter+0xbcc>
    3ba4:      	b	0x3cd4 <generic_rawtp_process_filter+0xce4>
    3ba8:      	ldr	x29, [sp, #0x40]
    3bac:      	ldr	x21, [sp, #0x30]
    3bb0:      	mov	w8, wzr
    3bb4:      	mov	x24, x9
    3bb8:      	str	xzr, [x29, #0x550]
    3bbc:      	subs	w9, w8, #0x7f
    3bc0:      	mov	w10, #0x7f              // =127
    3bc4:      	mov	x11, x29
    3bc8:      	mov	x0, x21
    3bcc:      	mov	x2, x24
    3bd0:      	csel	w29, w8, w10, lo
    3bd4:      	csel	w19, wzr, w9, lo
    3bd8:      	cmp	w8, #0xff
    3bdc:      	mov	w9, #0xff               // =255
    3be0:      	csel	w8, w8, w9, lo
    3be4:      	and	w1, w8, #0xff
    3be8:      	str	w1, [x11, #0x550]
    3bec:      	mov	w8, #0x4                // =4
    3bf0:      	blr	x8
    3bf4:      	adrp	x25, 0x3000 <generic_rawtp_process_filter+0x10>
    3bf8:      	ldr	x25, [x25]
    3bfc:      	cbz	x0, 0x3c6c <generic_rawtp_process_filter+0xc7c>
    3c00:      	neg	w8, w0
    3c04:      	mov	w9, #0x1                // =1
    3c08:      	add	x1, sp, #0x58
    3c0c:      	strh	w8, [sp, #0x58]
    3c10:      	mov	w8, #0x8                // =8
    3c14:      	mov	x0, x25
    3c18:      	mov	w20, #0x1               // =1
    3c1c:      	strh	w8, [sp, #0x5a]
    3c20:      	mov	x8, #0x2de              // =734
    3c24:      	movk	x8, #0x4, lsl #32
    3c28:      	stur	x8, [sp, #0x5c]
    3c2c:      	add	x8, sp, #0x58
    3c30:      	blr	x9
    3c34:      	cbz	x0, 0x3c48 <generic_rawtp_process_filter+0xc58>
    3c38:      	ldr	w8, [x0]
    3c3c:      	add	w8, w8, #0x1
    3c40:      	str	w8, [x0]
    3c44:      	b	0x3c6c <generic_rawtp_process_filter+0xc7c>
    3c48:      	str	w20, [sp, #0xc8]
    3c4c:      	mov	x3, xzr
    3c50:      	mov	w8, #0x2                // =2
    3c54:      	add	x9, sp, #0x58
    3c58:      	add	x10, sp, #0xc8
    3c5c:      	add	x1, sp, #0x58
    3c60:      	add	x2, sp, #0xc8
    3c64:      	mov	x0, x25
    3c68:      	blr	x8
    3c6c:      	ldr	x9, [sp, #0xe8]
    3c70:      	mov	w8, #0x6390             // =25488
    3c74:      	add	x2, x24, x19
    3c78:      	mov	w1, w29
    3c7c:      	add	x0, x9, x8
    3c80:      	mov	w8, #0x4                // =4
    3c84:      	blr	x8
    3c88:      	ldr	x29, [sp, #0x40]
    3c8c:      	cbz	x0, 0x3cd4 <generic_rawtp_process_filter+0xce4>
    3c90:      	neg	w8, w0
    3c94:      	mov	w9, #0x1                // =1
    3c98:      	add	x1, sp, #0x58
    3c9c:      	strh	w8, [sp, #0x58]
    3ca0:      	mov	w8, #0x8                // =8
    3ca4:      	mov	x0, x25
    3ca8:      	mov	w19, #0x1               // =1
    3cac:      	strh	w8, [sp, #0x5a]
    3cb0:      	mov	x8, #0x2e0              // =736
    3cb4:      	movk	x8, #0x4, lsl #32
    3cb8:      	stur	x8, [sp, #0x5c]
    3cbc:      	add	x8, sp, #0x58
    3cc0:      	blr	x9
    3cc4:      	cbz	x0, 0x3cfc <generic_rawtp_process_filter+0xd0c>
    3cc8:      	ldr	w8, [x0]
    3ccc:      	add	w8, w8, #0x1
    3cd0:      	str	w8, [x0]
    3cd4:      	ldr	w8, [x29, #0x550]
    3cd8:      	sub	w9, w8, #0x101
    3cdc:      	cmn	w9, #0x101
    3ce0:      	b.hi	0x3d30 <generic_rawtp_process_filter+0xd40>
    3ce4:      	ldr	x20, [sp, #0x38]
    3ce8:      	ldr	x22, [sp, #0xe8]
    3cec:      	mov	w8, #-0x1               // =-1
    3cf0:      	ldr	x24, [sp, #0x48]
    3cf4:      	stur	w8, [x29, #0xb8]
    3cf8:      	b	0x3e80 <generic_rawtp_process_filter+0xe90>
    3cfc:      	str	w19, [sp, #0xc8]
    3d00:      	mov	x3, xzr
    3d04:      	mov	w8, #0x2                // =2
    3d08:      	add	x9, sp, #0x58
    3d0c:      	add	x10, sp, #0xc8
    3d10:      	add	x1, sp, #0x58
    3d14:      	add	x2, sp, #0xc8
    3d18:      	mov	x0, x25
    3d1c:      	blr	x8
    3d20:      	ldr	w8, [x29, #0x550]
    3d24:      	sub	w9, w8, #0x101
    3d28:      	cmn	w9, #0x101
    3d2c:      	b.ls	0x3ce4 <generic_rawtp_process_filter+0xcf4>
    3d30:      	ldr	x22, [sp, #0xe8]
    3d34:      	and	x24, x8, #0xff
    3d38:      	mov	w8, #0x5f80             // =24448
    3d3c:      	mov	x2, x21
    3d40:      	mov	w1, w24
    3d44:      	add	x0, x22, x8
    3d48:      	mov	w8, #0x4                // =4
    3d4c:      	blr	x8
    3d50:      	mov	x23, x0
    3d54:      	cbz	x0, 0x3dd0 <generic_rawtp_process_filter+0xde0>
    3d58:      	neg	w8, w23
    3d5c:      	adrp	x25, 0x3000 <generic_rawtp_process_filter+0x10>
    3d60:      	mov	w9, #0x1                // =1
    3d64:      	strh	w8, [sp, #0x58]
    3d68:      	mov	w8, #0xf                // =15
    3d6c:      	add	x1, sp, #0x58
    3d70:      	mov	w19, #0x1               // =1
    3d74:      	strh	w8, [sp, #0x5a]
    3d78:      	mov	x8, #0x164              // =356
    3d7c:      	movk	x8, #0x4, lsl #32
    3d80:      	stur	x8, [sp, #0x5c]
    3d84:      	add	x8, sp, #0x58
    3d88:      	ldr	x25, [x25]
    3d8c:      	mov	x0, x25
    3d90:      	blr	x9
    3d94:      	cbz	x0, 0x3da8 <generic_rawtp_process_filter+0xdb8>
    3d98:      	ldr	w8, [x0]
    3d9c:      	add	w8, w8, #0x1
    3da0:      	str	w8, [x0]
    3da4:      	b	0x3dcc <generic_rawtp_process_filter+0xddc>
    3da8:      	str	w19, [sp, #0xc8]
    3dac:      	mov	x3, xzr
    3db0:      	mov	w8, #0x2                // =2
    3db4:      	add	x9, sp, #0x58
    3db8:      	add	x10, sp, #0xc8
    3dbc:      	add	x1, sp, #0x58
    3dc0:      	add	x2, sp, #0xc8
    3dc4:      	mov	x0, x25
    3dc8:      	blr	x8
    3dcc:      	ldr	x22, [sp, #0xe8]
    3dd0:      	cmp	w23, #0x0
    3dd4:      	csel	w8, w24, w23, eq
    3dd8:      	cmp	w24, #0x7f
    3ddc:      	stur	w8, [x29, #0xb8]
    3de0:      	mov	w8, #0x7f               // =127
    3de4:      	csel	w1, w24, w8, lo
    3de8:      	mov	w8, #0x6080             // =24704
    3dec:      	add	x0, x22, x8
    3df0:      	mov	w8, #0x6390             // =25488
    3df4:      	add	x2, x22, x8
    3df8:      	mov	w8, #0x4                // =4
    3dfc:      	blr	x8
    3e00:      	ldr	x20, [sp, #0x38]
    3e04:      	ldr	x24, [sp, #0x48]
    3e08:      	cbz	x0, 0x3e80 <generic_rawtp_process_filter+0xe90>
    3e0c:      	neg	w8, w0
    3e10:      	adrp	x23, 0x3000 <generic_rawtp_process_filter+0x10>
    3e14:      	mov	w9, #0x1                // =1
    3e18:      	strh	w8, [sp, #0x58]
    3e1c:      	mov	w8, #0xf                // =15
    3e20:      	add	x1, sp, #0x58
    3e24:      	mov	w19, #0x1               // =1
    3e28:      	strh	w8, [sp, #0x5a]
    3e2c:      	mov	x8, #0x16a              // =362
    3e30:      	movk	x8, #0x4, lsl #32
    3e34:      	stur	x8, [sp, #0x5c]
    3e38:      	add	x8, sp, #0x58
    3e3c:      	ldr	x23, [x23]
    3e40:      	mov	x0, x23
    3e44:      	blr	x9
    3e48:      	cbz	x0, 0x3e5c <generic_rawtp_process_filter+0xe6c>
    3e4c:      	ldr	w8, [x0]
    3e50:      	add	w8, w8, #0x1
    3e54:      	str	w8, [x0]
    3e58:      	b	0x3e80 <generic_rawtp_process_filter+0xe90>
    3e5c:      	str	w19, [sp, #0xc8]
    3e60:      	mov	x3, xzr
    3e64:      	mov	w8, #0x2                // =2
    3e68:      	add	x9, sp, #0x58
    3e6c:      	add	x10, sp, #0xc8
    3e70:      	add	x1, sp, #0x58
    3e74:      	add	x2, sp, #0xc8
    3e78:      	mov	x0, x23
    3e7c:      	blr	x8
    3e80:      	ldrb	w8, [x22, #0x1]
    3e84:      	orr	w8, w8, #0x10
    3e88:      	strb	w8, [x22, #0x1]
    3e8c:      	adrp	x0, 0x3000 <generic_rawtp_process_filter+0x10>
    3e90:      	mov	w8, #0x5ef8             // =24312
    3e94:      	ldr	x0, [x0]
    3e98:      	add	x1, x22, x8
    3e9c:      	mov	w8, #0x1                // =1
    3ea0:      	blr	x8
    3ea4:      	cbz	x0, 0x532c <generic_rawtp_process_filter+0x233c>
    3ea8:      	ldr	x21, [x22, #0x5eb8]
    3eac:      	cmp	x21, #0x6
    3eb0:      	b.hs	0x4048 <generic_rawtp_process_filter+0x1058>
    3eb4:      	ldrsw	x8, [x0]
    3eb8:      	mov	x23, x0
    3ebc:      	cbz	w8, 0x4064 <generic_rawtp_process_filter+0x1074>
    3ec0:      	cmp	x21, x8
    3ec4:      	b.hs	0x4048 <generic_rawtp_process_filter+0x1058>
    3ec8:      	str	x8, [sp, #0x28]
    3ecc:      	stp	x29, x24, [sp, #0x40]
    3ed0:      	adrp	x24, 0x3000 <generic_rawtp_process_filter+0x10>
    3ed4:      	mov	w8, #0x1                // =1
    3ed8:      	add	x9, sp, #0xd8
    3edc:      	str	x22, [sp, #0xe8]
    3ee0:      	add	x1, sp, #0xd8
    3ee4:      	str	x20, [sp, #0x38]
    3ee8:      	str	w21, [sp, #0xd8]
    3eec:      	str	wzr, [sp, #0xc0]
    3ef0:      	ldr	x24, [x24]
    3ef4:      	mov	x0, x24
    3ef8:      	blr	x8
    3efc:      	cbz	x0, 0x430c <generic_rawtp_process_filter+0x131c>
    3f00:      	ldr	w8, [x0]
    3f04:      	mov	x25, x0
    3f08:      	cbz	w8, 0x430c <generic_rawtp_process_filter+0x131c>
    3f0c:      	ldr	x9, [sp, #0x48]
    3f10:      	ldr	w9, [x9, #0x68]
    3f14:      	tbnz	w9, #0x1f, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    3f18:      	cmp	w8, #0x1b
    3f1c:      	b.hi	0x52d4 <generic_rawtp_process_filter+0x22e4>
    3f20:      	mov	w9, #0x1                // =1
    3f24:      	lsl	w9, w9, w8
    3f28:      	tst	w9, #0x60
    3f2c:      	b.ne	0x4124 <generic_rawtp_process_filter+0x1134>
    3f30:      	mov	w10, #0x100             // =256
    3f34:      	movk	w10, #0x400, lsl #16
    3f38:      	tst	w9, w10
    3f3c:      	b.ne	0x40a0 <generic_rawtp_process_filter+0x10b0>
    3f40:      	mov	w9, #0x1                // =1
    3f44:      	lsl	w8, w9, w8
    3f48:      	mov	w9, #0x200              // =512
    3f4c:      	movk	w9, #0x800, lsl #16
    3f50:      	tst	w8, w9
    3f54:      	b.eq	0x52d4 <generic_rawtp_process_filter+0x22e4>
    3f58:      	adrp	x0, 0x3000 <generic_rawtp_process_filter+0x10>
    3f5c:      	add	x1, x25, #0x4
    3f60:      	mov	w8, #0x1                // =1
    3f64:      	ldr	x0, [x0]
    3f68:      	blr	x8
    3f6c:      	cbz	x0, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    3f70:      	ldr	x8, [sp, #0x48]
    3f74:      	mov	x20, x0
    3f78:      	adrp	x0, 0x3000 <generic_rawtp_process_filter+0x10>
    3f7c:      	mov	w9, #0x7f               // =127
    3f80:      	ldr	w8, [x8, #0x68]
    3f84:      	ldr	x0, [x0]
    3f88:      	add	x1, sp, #0xc0
    3f8c:      	cmp	w8, #0x7f
    3f90:      	csel	w19, w8, w9, lt
    3f94:      	mov	w8, #0x1                // =1
    3f98:      	add	x9, sp, #0xc0
    3f9c:      	blr	x8
    3fa0:      	cbz	x0, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    3fa4:      	sxtw	x1, w19
    3fa8:      	mov	x29, x0
    3fac:      	lsl	w8, w1, #3
    3fb0:      	str	w8, [x0]
    3fb4:      	ldr	x8, [sp, #0x48]
    3fb8:      	ldr	w8, [x8, #0x6c]
    3fbc:      	cbnz	w8, 0x401c <generic_rawtp_process_filter+0x102c>
    3fc0:      	ldr	x11, [sp, #0x48]
    3fc4:      	and	w13, w1, #0x7f
    3fc8:      	mov	x8, xzr
    3fcc:      	ldr	w12, [x11, #0x68]
    3fd0:      	add	x9, x11, #0x1f0
    3fd4:      	add	x10, x11, #0x170
    3fd8:      	sub	w11, w12, w1
    3fdc:      	add	w12, w12, w13
    3fe0:      	add	w11, w11, w13
    3fe4:      	mvn	w13, w1
    3fe8:      	add	w12, w13, w12
    3fec:      	cmp	x8, #0x7f
    3ff0:      	b.eq	0x4010 <generic_rawtp_process_filter+0x1020>
    3ff4:      	and	x13, x12, #0x7f
    3ff8:      	sub	w12, w12, #0x1
    3ffc:      	ldrb	w13, [x10, x13]
    4000:      	strb	w13, [x9, x8]
    4004:      	add	x8, x8, #0x1
    4008:      	cmp	x11, x8
    400c:      	b.ne	0x3fec <generic_rawtp_process_filter+0xffc>
    4010:      	ldr	x9, [sp, #0x48]
    4014:      	mov	w8, #0x1                // =1
    4018:      	str	w8, [x9, #0x6c]
    401c:      	cmp	w1, #0x7f
    4020:      	b.hi	0x403c <generic_rawtp_process_filter+0x104c>
    4024:      	ldr	x8, [sp, #0x48]
    4028:      	add	x0, x29, #0x4
    402c:      	add	x2, x8, #0x1f0
    4030:      	mov	w8, #0x4                // =4
    4034:      	blr	x8
    4038:      	tbnz	x0, #0x3f, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    403c:      	mov	w8, #0x1                // =1
    4040:      	mov	x0, x20
    4044:      	b	0x411c <generic_rawtp_process_filter+0x112c>
    4048:      	ldr	w8, [x24]
    404c:      	str	w8, [x22, #0x10]
    4050:      	ldr	x8, [x24, #0x8]
    4054:      	str	x8, [x22, #0x18]
    4058:      	ldrb	w8, [x29]
    405c:      	cbnz	w8, 0x5310 <generic_rawtp_process_filter+0x2320>
    4060:      	b	0x532c <generic_rawtp_process_filter+0x233c>
    4064:      	mov	w8, #0x1                // =1
    4068:      	strb	w8, [x29]
    406c:      	ldr	w8, [x24]
    4070:      	str	w8, [x22, #0x10]
    4074:      	ldr	x8, [x24, #0x8]
    4078:      	str	x8, [x22, #0x18]
    407c:      	b	0x5310 <generic_rawtp_process_filter+0x2320>
    4080:      	mov	w8, #0x2964             // =10596
    4084:      	add	x20, x24, #0xff6
    4088:      	strh	w8, [x24, #0xffe]
    408c:      	adrp	x8, 0x4000 <generic_rawtp_process_filter+0x1010>
    4090:      	add	x8, x8, #0x0
    4094:      	ldr	x8, [x8]
    4098:      	str	x8, [x20]
    409c:      	b	0x3734 <generic_rawtp_process_filter+0x744>
    40a0:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    40a4:      	add	x1, x25, #0x4
    40a8:      	mov	w8, #0x1                // =1
    40ac:      	ldr	x0, [x0]
    40b0:      	blr	x8
    40b4:      	cbz	x0, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    40b8:      	mov	x19, x0
    40bc:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    40c0:      	mov	w8, #0x1                // =1
    40c4:      	ldr	x0, [x0]
    40c8:      	add	x9, sp, #0xc0
    40cc:      	add	x1, sp, #0xc0
    40d0:      	blr	x8
    40d4:      	cbz	x0, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    40d8:      	mov	w1, wzr
    40dc:      	mov	w2, #0x104              // =260
    40e0:      	mov	x29, x0
    40e4:      	bl	0x40e4 <generic_rawtp_process_filter+0x10f4>
    40e8:      	ldr	x10, [sp, #0x48]
    40ec:      	mov	x0, x29
    40f0:      	ldr	w8, [x10, #0x68]
    40f4:      	add	x2, x10, #0x70
    40f8:      	lsl	w9, w8, #3
    40fc:      	and	x8, x8, #0xff
    4100:      	str	w9, [x0], #0x4
    4104:      	mov	w9, #0x4                // =4
    4108:      	ldrb	w1, [x10, #0x68]
    410c:      	blr	x9
    4110:      	tbnz	x0, #0x3f, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    4114:      	mov	w8, #0x1                // =1
    4118:      	mov	x0, x19
    411c:      	mov	x1, x29
    4120:      	b	0x42d4 <generic_rawtp_process_filter+0x12e4>
    4124:      	str	wzr, [sp, #0xc8]
    4128:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    412c:      	mov	w8, #0x1                // =1
    4130:      	add	x9, sp, #0xc8
    4134:      	ldr	x0, [x0]
    4138:      	add	x1, sp, #0xc8
    413c:      	blr	x8
    4140:      	cbz	x0, 0x4280 <generic_rawtp_process_filter+0x1290>
    4144:      	ldr	x9, [sp, #0x48]
    4148:      	ldr	x8, [x0]
    414c:      	ldr	x9, [x9, #0x378]
    4150:      	cmp	x8, x9
    4154:      	b.eq	0x4280 <generic_rawtp_process_filter+0x1290>
    4158:      	str	x0, [sp, #0x30]
    415c:      	adrp	x8, 0x4000 <generic_rawtp_process_filter+0x1010>
    4160:      	mov	w20, wzr
    4164:      	mov	x19, xzr
    4168:      	ldr	x8, [x8]
    416c:      	ldrb	w8, [x8]
    4170:      	ldr	x9, [sp, #0x48]
    4174:      	add	x22, x9, #0x370
    4178:      	cbz	w8, 0x4248 <generic_rawtp_process_filter+0x1258>
    417c:      	ldr	x8, [sp, #0x48]
    4180:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4184:      	add	x9, sp, #0x58
    4188:      	add	x1, sp, #0x58
    418c:      	ldr	w8, [x8, #0x10]
    4190:      	str	w8, [sp, #0x58]
    4194:      	mov	w8, #0x1                // =1
    4198:      	ldr	x0, [x0]
    419c:      	blr	x8
    41a0:      	cbz	x0, 0x4270 <generic_rawtp_process_filter+0x1280>
    41a4:      	mov	x29, x0
    41a8:      	add	x1, x0, #0x70
    41ac:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    41b0:      	ldr	x0, [x0]
    41b4:      	mov	w8, #0x1                // =1
    41b8:      	blr	x8
    41bc:      	cbz	x0, 0x41d8 <generic_rawtp_process_filter+0x11e8>
    41c0:      	ldr	x8, [x0]
    41c4:      	cbz	x8, 0x41d8 <generic_rawtp_process_filter+0x11e8>
    41c8:      	ldaxr	x9, [x22]
    41cc:      	orr	x9, x9, x8
    41d0:      	stlxr	w10, x9, [x22]
    41d4:      	cbnz	w10, 0x41c8 <generic_rawtp_process_filter+0x11d8>
    41d8:      	cmp	x29, x19
    41dc:      	b.eq	0x4270 <generic_rawtp_process_filter+0x1280>
    41e0:      	mov	w8, #0x86a0             // =34464
    41e4:      	add	w20, w20, #0x1
    41e8:      	mov	x19, x29
    41ec:      	movk	w8, #0x1, lsl #16
    41f0:      	cmp	w20, w8
    41f4:      	b.ne	0x417c <generic_rawtp_process_filter+0x118c>
    41f8:      	b	0x4270 <generic_rawtp_process_filter+0x1280>
    41fc:      	mov	x29, x0
    4200:      	add	x1, x0, #0x70
    4204:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4208:      	ldr	x0, [x0]
    420c:      	mov	w8, #0x1                // =1
    4210:      	blr	x8
    4214:      	cbz	x0, 0x4230 <generic_rawtp_process_filter+0x1240>
    4218:      	ldr	x8, [x0]
    421c:      	cbz	x8, 0x4230 <generic_rawtp_process_filter+0x1240>
    4220:      	ldaxr	x9, [x22]
    4224:      	orr	x9, x9, x8
    4228:      	stlxr	w10, x9, [x22]
    422c:      	cbnz	w10, 0x4220 <generic_rawtp_process_filter+0x1230>
    4230:      	cmp	x29, x19
    4234:      	b.eq	0x4270 <generic_rawtp_process_filter+0x1280>
    4238:      	add	w20, w20, #0x1
    423c:      	mov	x19, x29
    4240:      	cmp	w20, #0x400
    4244:      	b.eq	0x4270 <generic_rawtp_process_filter+0x1280>
    4248:      	ldr	x8, [sp, #0x48]
    424c:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4250:      	add	x9, sp, #0x58
    4254:      	add	x1, sp, #0x58
    4258:      	ldr	w8, [x8, #0x10]
    425c:      	str	w8, [sp, #0x58]
    4260:      	mov	w8, #0x1                // =1
    4264:      	ldr	x0, [x0]
    4268:      	blr	x8
    426c:      	cbnz	x0, 0x41fc <generic_rawtp_process_filter+0x120c>
    4270:      	ldr	x8, [sp, #0x30]
    4274:      	ldr	x9, [sp, #0x48]
    4278:      	ldr	x8, [x8]
    427c:      	str	x8, [x9, #0x378]
    4280:      	ldr	w8, [x25, #0x8]
    4284:      	cmn	w8, #0x1
    4288:      	b.eq	0x42ac <generic_rawtp_process_filter+0x12bc>
    428c:      	ldr	x9, [sp, #0x48]
    4290:      	ldr	x9, [x9, #0x370]
    4294:      	lsr	x8, x9, x8
    4298:      	tbz	w8, #0x0, 0x42ac <generic_rawtp_process_filter+0x12bc>
    429c:      	mov	x0, #0xffee             // =65518
    42a0:      	movk	x0, #0xadc0, lsl #16
    42a4:      	movk	x0, #0xb, lsl #32
    42a8:      	b	0x42d8 <generic_rawtp_process_filter+0x12e8>
    42ac:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    42b0:      	mov	w8, #0x1                // =1
    42b4:      	add	x9, sp, #0xd8
    42b8:      	ldr	x0, [x0]
    42bc:      	add	x1, sp, #0xd8
    42c0:      	blr	x8
    42c4:      	cbz	x0, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    42c8:      	ldr	x8, [sp, #0x48]
    42cc:      	add	x1, x8, #0x70
    42d0:      	mov	w8, #0x1                // =1
    42d4:      	blr	x8
    42d8:      	ldr	w8, [x25]
    42dc:      	cmp	w8, #0x25
    42e0:      	b.hi	0x4308 <generic_rawtp_process_filter+0x1318>
    42e4:      	mov	w9, #0x1                // =1
    42e8:      	lsl	x8, x9, x8
    42ec:      	mov	x9, #0x50               // =80
    42f0:      	movk	x9, #0xc00, lsl #16
    42f4:      	movk	x9, #0x20, lsl #32
    42f8:      	tst	x8, x9
    42fc:      	b.eq	0x4308 <generic_rawtp_process_filter+0x1318>
    4300:      	cbnz	x0, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    4304:      	b	0x430c <generic_rawtp_process_filter+0x131c>
    4308:      	cbz	x0, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    430c:      	adrp	x8, 0x4000 <generic_rawtp_process_filter+0x1010>
    4310:      	ldr	x8, [x8]
    4314:      	ldrb	w8, [x8]
    4318:      	cbz	w8, 0x46e0 <generic_rawtp_process_filter+0x16f0>
    431c:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4320:      	mov	w8, #0x1                // =1
    4324:      	ldr	x0, [x0]
    4328:      	ldr	x1, [sp, #0x48]
    432c:      	blr	x8
    4330:      	cbz	x0, 0x46e0 <generic_rawtp_process_filter+0x16f0>
    4334:      	add	w8, w21, #0x5
    4338:      	str	wzr, [sp, #0xc0]
    433c:      	add	x9, sp, #0xd8
    4340:      	mov	x25, x0
    4344:      	str	w8, [sp, #0xd8]
    4348:      	mov	w8, #0x1                // =1
    434c:      	add	x1, sp, #0xd8
    4350:      	mov	x0, x24
    4354:      	blr	x8
    4358:      	cbz	x0, 0x46e0 <generic_rawtp_process_filter+0x16f0>
    435c:      	ldr	w8, [x0]
    4360:      	mov	x24, x0
    4364:      	cbz	w8, 0x46e0 <generic_rawtp_process_filter+0x16f0>
    4368:      	ldr	w9, [x25]
    436c:      	tbnz	w9, #0x1f, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    4370:      	cmp	w8, #0x1b
    4374:      	b.hi	0x52d4 <generic_rawtp_process_filter+0x22e4>
    4378:      	mov	w9, #0x1                // =1
    437c:      	lsl	w9, w9, w8
    4380:      	tst	w9, #0x60
    4384:      	b.ne	0x450c <generic_rawtp_process_filter+0x151c>
    4388:      	mov	w10, #0x100             // =256
    438c:      	movk	w10, #0x400, lsl #16
    4390:      	tst	w9, w10
    4394:      	b.ne	0x448c <generic_rawtp_process_filter+0x149c>
    4398:      	mov	w9, #0x1                // =1
    439c:      	lsl	w8, w9, w8
    43a0:      	mov	w9, #0x200              // =512
    43a4:      	movk	w9, #0x800, lsl #16
    43a8:      	tst	w8, w9
    43ac:      	b.eq	0x52d4 <generic_rawtp_process_filter+0x22e4>
    43b0:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    43b4:      	add	x1, x24, #0x4
    43b8:      	mov	w8, #0x1                // =1
    43bc:      	ldr	x0, [x0]
    43c0:      	blr	x8
    43c4:      	cbz	x0, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    43c8:      	ldr	w8, [x25]
    43cc:      	mov	x20, x0
    43d0:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    43d4:      	mov	w9, #0x7f               // =127
    43d8:      	ldr	x0, [x0]
    43dc:      	add	x1, sp, #0xc0
    43e0:      	cmp	w8, #0x7f
    43e4:      	csel	w19, w8, w9, lt
    43e8:      	mov	w8, #0x1                // =1
    43ec:      	add	x9, sp, #0xc0
    43f0:      	blr	x8
    43f4:      	cbz	x0, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    43f8:      	sxtw	x1, w19
    43fc:      	mov	x29, x0
    4400:      	lsl	w8, w1, #3
    4404:      	str	w8, [x0]
    4408:      	ldr	w8, [x25, #0x4]
    440c:      	cbnz	w8, 0x4464 <generic_rawtp_process_filter+0x1474>
    4410:      	ldr	w12, [x25]
    4414:      	and	w13, w1, #0x7f
    4418:      	mov	x8, xzr
    441c:      	add	x9, x25, #0x188
    4420:      	add	x10, x25, #0x108
    4424:      	sub	w11, w12, w1
    4428:      	add	w12, w12, w13
    442c:      	add	w11, w11, w13
    4430:      	mvn	w13, w1
    4434:      	add	w12, w13, w12
    4438:      	cmp	x8, #0x7f
    443c:      	b.eq	0x445c <generic_rawtp_process_filter+0x146c>
    4440:      	and	x13, x12, #0x7f
    4444:      	sub	w12, w12, #0x1
    4448:      	ldrb	w13, [x10, x13]
    444c:      	strb	w13, [x9, x8]
    4450:      	add	x8, x8, #0x1
    4454:      	cmp	x11, x8
    4458:      	b.ne	0x4438 <generic_rawtp_process_filter+0x1448>
    445c:      	mov	w8, #0x1                // =1
    4460:      	str	w8, [x25, #0x4]
    4464:      	cmp	w1, #0x7f
    4468:      	b.hi	0x4480 <generic_rawtp_process_filter+0x1490>
    446c:      	add	x0, x29, #0x4
    4470:      	add	x2, x25, #0x188
    4474:      	mov	w8, #0x4                // =4
    4478:      	blr	x8
    447c:      	tbnz	x0, #0x3f, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    4480:      	mov	w8, #0x1                // =1
    4484:      	mov	x0, x20
    4488:      	b	0x4504 <generic_rawtp_process_filter+0x1514>
    448c:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4490:      	add	x1, x24, #0x4
    4494:      	mov	w8, #0x1                // =1
    4498:      	ldr	x0, [x0]
    449c:      	blr	x8
    44a0:      	cbz	x0, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    44a4:      	mov	x19, x0
    44a8:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    44ac:      	mov	w8, #0x1                // =1
    44b0:      	ldr	x0, [x0]
    44b4:      	add	x9, sp, #0xc0
    44b8:      	add	x1, sp, #0xc0
    44bc:      	blr	x8
    44c0:      	cbz	x0, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    44c4:      	mov	w1, wzr
    44c8:      	mov	w2, #0x104              // =260
    44cc:      	mov	x29, x0
    44d0:      	bl	0x44d0 <generic_rawtp_process_filter+0x14e0>
    44d4:      	ldr	w8, [x25]
    44d8:      	mov	x0, x29
    44dc:      	add	x2, x25, #0x8
    44e0:      	lsl	w9, w8, #3
    44e4:      	and	x8, x8, #0xff
    44e8:      	str	w9, [x0], #0x4
    44ec:      	mov	w9, #0x4                // =4
    44f0:      	ldrb	w1, [x25]
    44f4:      	blr	x9
    44f8:      	tbnz	x0, #0x3f, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    44fc:      	mov	w8, #0x1                // =1
    4500:      	mov	x0, x19
    4504:      	mov	x1, x29
    4508:      	b	0x46a8 <generic_rawtp_process_filter+0x16b8>
    450c:      	str	wzr, [sp, #0xc8]
    4510:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4514:      	mov	w8, #0x1                // =1
    4518:      	add	x9, sp, #0xc8
    451c:      	ldr	x0, [x0]
    4520:      	add	x1, sp, #0xc8
    4524:      	blr	x8
    4528:      	cbz	x0, 0x465c <generic_rawtp_process_filter+0x166c>
    452c:      	ldr	x8, [x0]
    4530:      	ldr	x9, [x25, #0x310]
    4534:      	cmp	x8, x9
    4538:      	b.eq	0x465c <generic_rawtp_process_filter+0x166c>
    453c:      	str	x0, [sp, #0x30]
    4540:      	adrp	x8, 0x4000 <generic_rawtp_process_filter+0x1010>
    4544:      	add	x22, x25, #0x308
    4548:      	mov	w20, wzr
    454c:      	ldr	x8, [x8]
    4550:      	mov	x19, xzr
    4554:      	ldrb	w8, [x8]
    4558:      	cbz	w8, 0x4628 <generic_rawtp_process_filter+0x1638>
    455c:      	ldr	x8, [sp, #0x48]
    4560:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4564:      	add	x9, sp, #0x58
    4568:      	add	x1, sp, #0x58
    456c:      	ldr	w8, [x8, #0x10]
    4570:      	str	w8, [sp, #0x58]
    4574:      	mov	w8, #0x1                // =1
    4578:      	ldr	x0, [x0]
    457c:      	blr	x8
    4580:      	cbz	x0, 0x4650 <generic_rawtp_process_filter+0x1660>
    4584:      	mov	x29, x0
    4588:      	add	x1, x0, #0x70
    458c:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4590:      	ldr	x0, [x0]
    4594:      	mov	w8, #0x1                // =1
    4598:      	blr	x8
    459c:      	cbz	x0, 0x45b8 <generic_rawtp_process_filter+0x15c8>
    45a0:      	ldr	x8, [x0]
    45a4:      	cbz	x8, 0x45b8 <generic_rawtp_process_filter+0x15c8>
    45a8:      	ldaxr	x9, [x22]
    45ac:      	orr	x9, x9, x8
    45b0:      	stlxr	w10, x9, [x22]
    45b4:      	cbnz	w10, 0x45a8 <generic_rawtp_process_filter+0x15b8>
    45b8:      	cmp	x29, x19
    45bc:      	b.eq	0x4650 <generic_rawtp_process_filter+0x1660>
    45c0:      	mov	w8, #0x86a0             // =34464
    45c4:      	add	w20, w20, #0x1
    45c8:      	mov	x19, x29
    45cc:      	movk	w8, #0x1, lsl #16
    45d0:      	cmp	w20, w8
    45d4:      	b.ne	0x455c <generic_rawtp_process_filter+0x156c>
    45d8:      	b	0x4650 <generic_rawtp_process_filter+0x1660>
    45dc:      	mov	x29, x0
    45e0:      	add	x1, x0, #0x70
    45e4:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    45e8:      	ldr	x0, [x0]
    45ec:      	mov	w8, #0x1                // =1
    45f0:      	blr	x8
    45f4:      	cbz	x0, 0x4610 <generic_rawtp_process_filter+0x1620>
    45f8:      	ldr	x8, [x0]
    45fc:      	cbz	x8, 0x4610 <generic_rawtp_process_filter+0x1620>
    4600:      	ldaxr	x9, [x22]
    4604:      	orr	x9, x9, x8
    4608:      	stlxr	w10, x9, [x22]
    460c:      	cbnz	w10, 0x4600 <generic_rawtp_process_filter+0x1610>
    4610:      	cmp	x29, x19
    4614:      	b.eq	0x4650 <generic_rawtp_process_filter+0x1660>
    4618:      	add	w20, w20, #0x1
    461c:      	mov	x19, x29
    4620:      	cmp	w20, #0x400
    4624:      	b.eq	0x4650 <generic_rawtp_process_filter+0x1660>
    4628:      	ldr	x8, [sp, #0x48]
    462c:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4630:      	add	x9, sp, #0x58
    4634:      	add	x1, sp, #0x58
    4638:      	ldr	w8, [x8, #0x10]
    463c:      	str	w8, [sp, #0x58]
    4640:      	mov	w8, #0x1                // =1
    4644:      	ldr	x0, [x0]
    4648:      	blr	x8
    464c:      	cbnz	x0, 0x45dc <generic_rawtp_process_filter+0x15ec>
    4650:      	ldr	x8, [sp, #0x30]
    4654:      	ldr	x8, [x8]
    4658:      	str	x8, [x25, #0x310]
    465c:      	ldr	w8, [x24, #0x8]
    4660:      	cmn	w8, #0x1
    4664:      	b.eq	0x4684 <generic_rawtp_process_filter+0x1694>
    4668:      	ldr	x9, [x25, #0x308]
    466c:      	lsr	x8, x9, x8
    4670:      	tbz	w8, #0x0, 0x4684 <generic_rawtp_process_filter+0x1694>
    4674:      	mov	x0, #0xffee             // =65518
    4678:      	movk	x0, #0xadc0, lsl #16
    467c:      	movk	x0, #0xb, lsl #32
    4680:      	b	0x46ac <generic_rawtp_process_filter+0x16bc>
    4684:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4688:      	mov	w8, #0x1                // =1
    468c:      	add	x9, sp, #0xd8
    4690:      	ldr	x0, [x0]
    4694:      	add	x1, sp, #0xd8
    4698:      	blr	x8
    469c:      	cbz	x0, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    46a0:      	add	x1, x25, #0x8
    46a4:      	mov	w8, #0x1                // =1
    46a8:      	blr	x8
    46ac:      	ldr	w8, [x24]
    46b0:      	cmp	w8, #0x25
    46b4:      	b.hi	0x46dc <generic_rawtp_process_filter+0x16ec>
    46b8:      	mov	w9, #0x1                // =1
    46bc:      	lsl	x8, x9, x8
    46c0:      	mov	x9, #0x50               // =80
    46c4:      	movk	x9, #0xc00, lsl #16
    46c8:      	movk	x9, #0x20, lsl #32
    46cc:      	tst	x8, x9
    46d0:      	b.eq	0x46dc <generic_rawtp_process_filter+0x16ec>
    46d4:      	cbnz	x0, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    46d8:      	b	0x46e0 <generic_rawtp_process_filter+0x16f0>
    46dc:      	cbz	x0, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    46e0:      	lsl	w8, w21, #2
    46e4:      	add	x9, x8, #0x4
    46e8:      	ldr	w8, [x9, x23]
    46ec:      	add	w9, w8, w9
    46f0:      	and	w11, w9, #0x3ff
    46f4:      	add	w9, w9, #0x4
    46f8:      	and	x9, x9, #0x3ff
    46fc:      	add	x10, x11, #0x8
    4700:      	ldr	w9, [x9, x23]
    4704:      	cmp	w9, #0x5
    4708:      	b.lo	0x4798 <generic_rawtp_process_filter+0x17a8>
    470c:      	add	x9, x10, x23
    4710:      	ldr	w10, [x9, #0x8]
    4714:      	ldp	w12, w22, [x9]
    4718:      	stp	x9, x11, [sp, #0x8]
    471c:      	mov	w9, #0x4                // =4
    4720:      	cmp	w10, #0x4
    4724:      	stp	xzr, xzr, [sp, #0x58]
    4728:      	csel	w9, w10, w9, lo
    472c:      	cmp	w12, #0x6
    4730:      	b.ne	0x473c <generic_rawtp_process_filter+0x174c>
    4734:      	mov	x11, #0x100000001       // =4294967297
    4738:      	stp	x11, x11, [sp, #0x58]
    473c:      	cbz	w10, 0x4ba0 <generic_rawtp_process_filter+0x1bb0>
    4740:      	ldr	x10, [sp, #0x48]
    4744:      	add	w8, w8, w21, lsl #2
    4748:      	tst	x22, #0x1
    474c:      	add	x25, sp, #0x58
    4750:      	str	w12, [sp, #0x30]
    4754:      	add	w8, w8, #0x4
    4758:      	and	x8, x8, #0x3ff
    475c:      	add	x21, x8, #0x14
    4760:      	sub	x8, x9, #0x1
    4764:      	mov	w9, #0x3                // =3
    4768:      	add	x11, x10, #0x24
    476c:      	str	x11, [sp, #0x20]
    4770:      	csel	x11, x10, x11, eq
    4774:      	cmp	x8, #0x3
    4778:      	add	x10, x10, #0x10
    477c:      	csel	x8, x8, x9, lo
    4780:      	and	x9, x21, #0x7fc
    4784:      	mov	x20, x11
    4788:      	str	x10, [sp, #0x18]
    478c:      	add	x19, x23, x9
    4790:      	add	x24, x8, #0x1
    4794:      	b	0x47d0 <generic_rawtp_process_filter+0x17e0>
    4798:      	mov	w9, #0x1                // =1
    479c:      	mov	w8, w10
    47a0:      	b	0x4be8 <generic_rawtp_process_filter+0x1bf8>
    47a4:      	mov	w8, #0x1                // =1
    47a8:      	ldr	w12, [sp, #0x30]
    47ac:      	mov	x11, x20
    47b0:      	cmp	w12, #0x6
    47b4:      	eor	w8, w8, #0x1
    47b8:      	csinc	w9, w8, wzr, eq
    47bc:      	str	w9, [x25], #0x4
    47c0:      	add	x21, x21, #0x4
    47c4:      	add	x19, x19, #0x4
    47c8:      	subs	x24, x24, #0x1
    47cc:      	b.eq	0x4ba0 <generic_rawtp_process_filter+0x1bb0>
    47d0:      	cmp	x21, #0x3e8
    47d4:      	b.ls	0x49f8 <generic_rawtp_process_filter+0x1a08>
    47d8:      	mov	x29, xzr
    47dc:      	tbz	w22, #0x1, 0x4a00 <generic_rawtp_process_filter+0x1a10>
    47e0:      	tbnz	w22, #0x0, 0x4a2c <generic_rawtp_process_filter+0x1a3c>
    47e4:      	ldr	x10, [sp, #0x48]
    47e8:      	mov	w8, #0x1                // =1
    47ec:      	ldr	w9, [x10]
    47f0:      	cmp	x29, x9
    47f4:      	b.eq	0x47b0 <generic_rawtp_process_filter+0x17c0>
    47f8:      	ldr	w9, [x10, #0x10]
    47fc:      	cmp	x29, x9
    4800:      	b.eq	0x47b0 <generic_rawtp_process_filter+0x17c0>
    4804:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4808:      	mov	w8, #0x1                // =1
    480c:      	ldr	x0, [x0]
    4810:      	ldr	x1, [sp, #0x18]
    4814:      	blr	x8
    4818:      	cbz	x0, 0x4b84 <generic_rawtp_process_filter+0x1b94>
    481c:      	ldr	w9, [x0]
    4820:      	mov	x1, x0
    4824:      	mov	w8, #0x1                // =1
    4828:      	cmp	x29, x9
    482c:      	b.eq	0x47a8 <generic_rawtp_process_filter+0x17b8>
    4830:      	ldr	w9, [x1, #0x10]!
    4834:      	ldr	w12, [sp, #0x30]
    4838:      	mov	x11, x20
    483c:      	cmp	x29, x9
    4840:      	b.eq	0x47b0 <generic_rawtp_process_filter+0x17c0>
    4844:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4848:      	mov	w8, #0x1                // =1
    484c:      	ldr	x0, [x0]
    4850:      	blr	x8
    4854:      	cbz	x0, 0x4b84 <generic_rawtp_process_filter+0x1b94>
    4858:      	ldr	w9, [x0]
    485c:      	mov	x1, x0
    4860:      	mov	w8, #0x1                // =1
    4864:      	cmp	x29, x9
    4868:      	b.eq	0x47a8 <generic_rawtp_process_filter+0x17b8>
    486c:      	ldr	w9, [x1, #0x10]!
    4870:      	ldr	w12, [sp, #0x30]
    4874:      	mov	x11, x20
    4878:      	cmp	x29, x9
    487c:      	b.eq	0x47b0 <generic_rawtp_process_filter+0x17c0>
    4880:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4884:      	mov	w8, #0x1                // =1
    4888:      	ldr	x0, [x0]
    488c:      	blr	x8
    4890:      	cbz	x0, 0x4b84 <generic_rawtp_process_filter+0x1b94>
    4894:      	ldr	w9, [x0]
    4898:      	mov	x1, x0
    489c:      	mov	w8, #0x1                // =1
    48a0:      	cmp	x29, x9
    48a4:      	b.eq	0x47a8 <generic_rawtp_process_filter+0x17b8>
    48a8:      	ldr	w9, [x1, #0x10]!
    48ac:      	ldr	w12, [sp, #0x30]
    48b0:      	mov	x11, x20
    48b4:      	cmp	x29, x9
    48b8:      	b.eq	0x47b0 <generic_rawtp_process_filter+0x17c0>
    48bc:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    48c0:      	mov	w8, #0x1                // =1
    48c4:      	ldr	x0, [x0]
    48c8:      	blr	x8
    48cc:      	cbz	x0, 0x4b84 <generic_rawtp_process_filter+0x1b94>
    48d0:      	ldr	w9, [x0]
    48d4:      	mov	x1, x0
    48d8:      	mov	w8, #0x1                // =1
    48dc:      	cmp	x29, x9
    48e0:      	b.eq	0x47a8 <generic_rawtp_process_filter+0x17b8>
    48e4:      	ldr	w9, [x1, #0x10]!
    48e8:      	ldr	w12, [sp, #0x30]
    48ec:      	mov	x11, x20
    48f0:      	cmp	x29, x9
    48f4:      	b.eq	0x47b0 <generic_rawtp_process_filter+0x17c0>
    48f8:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    48fc:      	mov	w8, #0x1                // =1
    4900:      	ldr	x0, [x0]
    4904:      	blr	x8
    4908:      	cbz	x0, 0x4b84 <generic_rawtp_process_filter+0x1b94>
    490c:      	ldr	w9, [x0]
    4910:      	mov	x1, x0
    4914:      	mov	w8, #0x1                // =1
    4918:      	cmp	x29, x9
    491c:      	b.eq	0x47a8 <generic_rawtp_process_filter+0x17b8>
    4920:      	ldr	w9, [x1, #0x10]!
    4924:      	ldr	w12, [sp, #0x30]
    4928:      	mov	x11, x20
    492c:      	cmp	x29, x9
    4930:      	b.eq	0x47b0 <generic_rawtp_process_filter+0x17c0>
    4934:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4938:      	mov	w8, #0x1                // =1
    493c:      	ldr	x0, [x0]
    4940:      	blr	x8
    4944:      	cbz	x0, 0x4b84 <generic_rawtp_process_filter+0x1b94>
    4948:      	ldr	w9, [x0]
    494c:      	mov	x1, x0
    4950:      	mov	w8, #0x1                // =1
    4954:      	cmp	x29, x9
    4958:      	b.eq	0x47a8 <generic_rawtp_process_filter+0x17b8>
    495c:      	ldr	w9, [x1, #0x10]!
    4960:      	ldr	w12, [sp, #0x30]
    4964:      	mov	x11, x20
    4968:      	cmp	x29, x9
    496c:      	b.eq	0x47b0 <generic_rawtp_process_filter+0x17c0>
    4970:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4974:      	mov	w8, #0x1                // =1
    4978:      	ldr	x0, [x0]
    497c:      	blr	x8
    4980:      	cbz	x0, 0x4b84 <generic_rawtp_process_filter+0x1b94>
    4984:      	ldr	w9, [x0]
    4988:      	mov	x1, x0
    498c:      	mov	w8, #0x1                // =1
    4990:      	cmp	x29, x9
    4994:      	b.eq	0x47a8 <generic_rawtp_process_filter+0x17b8>
    4998:      	ldr	w9, [x1, #0x10]!
    499c:      	ldr	w12, [sp, #0x30]
    49a0:      	mov	x11, x20
    49a4:      	cmp	x29, x9
    49a8:      	b.eq	0x47b0 <generic_rawtp_process_filter+0x17c0>
    49ac:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    49b0:      	mov	w8, #0x1                // =1
    49b4:      	ldr	x0, [x0]
    49b8:      	blr	x8
    49bc:      	cbz	x0, 0x4b84 <generic_rawtp_process_filter+0x1b94>
    49c0:      	ldr	w9, [x0]
    49c4:      	mov	x1, x0
    49c8:      	mov	w8, #0x1                // =1
    49cc:      	cmp	x29, x9
    49d0:      	b.eq	0x47a8 <generic_rawtp_process_filter+0x17b8>
    49d4:      	ldr	w9, [x1, #0x10]!
    49d8:      	ldr	w12, [sp, #0x30]
    49dc:      	mov	x11, x20
    49e0:      	cmp	x29, x9
    49e4:      	b.eq	0x47b0 <generic_rawtp_process_filter+0x17c0>
    49e8:      	adrp	x9, 0x4000 <generic_rawtp_process_filter+0x1010>
    49ec:      	mov	w8, #0x1                // =1
    49f0:      	ldr	x9, [x9]
    49f4:      	b	0x4b78 <generic_rawtp_process_filter+0x1b88>
    49f8:      	ldr	w29, [x19]
    49fc:      	tbnz	w22, #0x1, 0x47e0 <generic_rawtp_process_filter+0x17f0>
    4a00:      	ldr	w8, [x11]
    4a04:      	cmp	w12, #0x5
    4a08:      	b.ne	0x4a1c <generic_rawtp_process_filter+0x1a2c>
    4a0c:      	cmp	x29, x8
    4a10:      	b.eq	0x4a1c <generic_rawtp_process_filter+0x1a2c>
    4a14:      	mov	w9, wzr
    4a18:      	b	0x47bc <generic_rawtp_process_filter+0x17cc>
    4a1c:      	cmp	w12, #0x6
    4a20:      	ccmp	x29, x8, #0x0, eq
    4a24:      	cset	w9, ne
    4a28:      	b	0x47bc <generic_rawtp_process_filter+0x17cc>
    4a2c:      	ldr	x8, [sp, #0x20]
    4a30:      	ldr	w9, [x8]
    4a34:      	cbz	w9, 0x47bc <generic_rawtp_process_filter+0x17cc>
    4a38:      	mov	w8, #0x1                // =1
    4a3c:      	cbz	x29, 0x47b0 <generic_rawtp_process_filter+0x17c0>
    4a40:      	cmp	x29, x9
    4a44:      	b.eq	0x47b0 <generic_rawtp_process_filter+0x17c0>
    4a48:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4a4c:      	mov	w8, #0x1                // =1
    4a50:      	ldr	x0, [x0]
    4a54:      	ldr	x1, [sp, #0x18]
    4a58:      	blr	x8
    4a5c:      	cbz	x0, 0x4b84 <generic_rawtp_process_filter+0x1b94>
    4a60:      	ldr	w8, [x0, #0x24]
    4a64:      	cmp	x29, x8
    4a68:      	b.eq	0x47a4 <generic_rawtp_process_filter+0x17b4>
    4a6c:      	add	x1, x0, #0x10
    4a70:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4a74:      	mov	w8, #0x1                // =1
    4a78:      	ldr	x0, [x0]
    4a7c:      	blr	x8
    4a80:      	cbz	x0, 0x4b84 <generic_rawtp_process_filter+0x1b94>
    4a84:      	ldr	w8, [x0, #0x24]
    4a88:      	cmp	x29, x8
    4a8c:      	b.eq	0x47a4 <generic_rawtp_process_filter+0x17b4>
    4a90:      	add	x1, x0, #0x10
    4a94:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4a98:      	mov	w8, #0x1                // =1
    4a9c:      	ldr	x0, [x0]
    4aa0:      	blr	x8
    4aa4:      	cbz	x0, 0x4b84 <generic_rawtp_process_filter+0x1b94>
    4aa8:      	ldr	w8, [x0, #0x24]
    4aac:      	cmp	x29, x8
    4ab0:      	b.eq	0x47a4 <generic_rawtp_process_filter+0x17b4>
    4ab4:      	add	x1, x0, #0x10
    4ab8:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4abc:      	mov	w8, #0x1                // =1
    4ac0:      	ldr	x0, [x0]
    4ac4:      	blr	x8
    4ac8:      	cbz	x0, 0x4b84 <generic_rawtp_process_filter+0x1b94>
    4acc:      	ldr	w8, [x0, #0x24]
    4ad0:      	cmp	x29, x8
    4ad4:      	b.eq	0x47a4 <generic_rawtp_process_filter+0x17b4>
    4ad8:      	add	x1, x0, #0x10
    4adc:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4ae0:      	mov	w8, #0x1                // =1
    4ae4:      	ldr	x0, [x0]
    4ae8:      	blr	x8
    4aec:      	cbz	x0, 0x4b84 <generic_rawtp_process_filter+0x1b94>
    4af0:      	ldr	w8, [x0, #0x24]
    4af4:      	cmp	x29, x8
    4af8:      	b.eq	0x47a4 <generic_rawtp_process_filter+0x17b4>
    4afc:      	add	x1, x0, #0x10
    4b00:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4b04:      	mov	w8, #0x1                // =1
    4b08:      	ldr	x0, [x0]
    4b0c:      	blr	x8
    4b10:      	cbz	x0, 0x4b84 <generic_rawtp_process_filter+0x1b94>
    4b14:      	ldr	w8, [x0, #0x24]
    4b18:      	cmp	x29, x8
    4b1c:      	b.eq	0x47a4 <generic_rawtp_process_filter+0x17b4>
    4b20:      	add	x1, x0, #0x10
    4b24:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4b28:      	mov	w8, #0x1                // =1
    4b2c:      	ldr	x0, [x0]
    4b30:      	blr	x8
    4b34:      	cbz	x0, 0x4b84 <generic_rawtp_process_filter+0x1b94>
    4b38:      	ldr	w8, [x0, #0x24]
    4b3c:      	cmp	x29, x8
    4b40:      	b.eq	0x47a4 <generic_rawtp_process_filter+0x17b4>
    4b44:      	add	x1, x0, #0x10
    4b48:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4b4c:      	mov	w8, #0x1                // =1
    4b50:      	ldr	x0, [x0]
    4b54:      	blr	x8
    4b58:      	cbz	x0, 0x4b84 <generic_rawtp_process_filter+0x1b94>
    4b5c:      	ldr	w8, [x0, #0x24]
    4b60:      	cmp	x29, x8
    4b64:      	b.eq	0x47a4 <generic_rawtp_process_filter+0x17b4>
    4b68:      	adrp	x9, 0x4000 <generic_rawtp_process_filter+0x1010>
    4b6c:      	add	x1, x0, #0x10
    4b70:      	mov	w8, #0x1                // =1
    4b74:      	ldr	x9, [x9]
    4b78:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4b7c:      	ldr	x0, [x0]
    4b80:      	blr	x8
    4b84:      	ldr	w12, [sp, #0x30]
    4b88:      	mov	w8, wzr
    4b8c:      	mov	w9, wzr
    4b90:      	mov	x11, x20
    4b94:      	cmp	w12, #0x5
    4b98:      	b.ne	0x47b0 <generic_rawtp_process_filter+0x17c0>
    4b9c:      	b	0x47bc <generic_rawtp_process_filter+0x17cc>
    4ba0:      	ldp	w8, w9, [sp, #0x58]
    4ba4:      	ldp	w10, w11, [sp, #0x60]
    4ba8:      	cmp	w12, #0x6
    4bac:      	b.ne	0x4bc0 <generic_rawtp_process_filter+0x1bd0>
    4bb0:      	and	w8, w9, w8
    4bb4:      	and	w9, w10, w11
    4bb8:      	and	w9, w8, w9
    4bbc:      	b	0x4bcc <generic_rawtp_process_filter+0x1bdc>
    4bc0:      	orr	w8, w9, w8
    4bc4:      	orr	w9, w10, w11
    4bc8:      	orr	w9, w8, w9
    4bcc:      	ldr	x8, [sp, #0x10]
    4bd0:      	cbz	w9, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    4bd4:      	ldr	x10, [sp, #0x8]
    4bd8:      	add	w8, w8, #0x14
    4bdc:      	ldr	w10, [x10, #0x8]
    4be0:      	ubfiz	w10, w10, #2, #3
    4be4:      	add	w8, w10, w8
    4be8:      	and	x10, x8, #0x3ff
    4bec:      	add	w8, w8, #0x4
    4bf0:      	mov	w19, #0xa               // =10
    4bf4:      	ldr	w10, [x10, x23]
    4bf8:      	mov	w20, #0x4               // =4
    4bfc:      	mov	x25, #0x100000001       // =4294967297
    4c00:      	sub	w22, w10, #0x4
    4c04:      	ldr	x10, [sp, #0xe8]
    4c08:      	add	x10, x10, #0x20
    4c0c:      	str	x10, [sp, #0x30]
    4c10:      	b	0x4c28 <generic_rawtp_process_filter+0x1c38>
    4c14:      	nop
    4c18:      	nop
    4c1c:      	nop
    4c20:      	subs	x19, x19, #0x1
    4c24:      	b.eq	0x4df4 <generic_rawtp_process_filter+0x1e04>
    4c28:      	cbz	w22, 0x4c20 <generic_rawtp_process_filter+0x1c30>
    4c2c:      	and	x9, x8, #0x3ff
    4c30:      	add	x10, x9, x23
    4c34:      	ldr	w29, [x10, #0x8]
    4c38:      	ldp	w9, w24, [x10]
    4c3c:      	stp	xzr, xzr, [sp, #0x58]
    4c40:      	cmp	w29, #0x4
    4c44:      	csel	w10, w29, w20, lo
    4c48:      	cmp	w24, #0x6
    4c4c:      	b.ne	0x4c54 <generic_rawtp_process_filter+0x1c64>
    4c50:      	stp	x25, x25, [sp, #0x58]
    4c54:      	add	w21, w8, #0xc
    4c58:      	cbz	w29, 0x4dac <generic_rawtp_process_filter+0x1dbc>
    4c5c:      	and	x9, x9, #0xf
    4c60:      	cmp	w9, #0xa
    4c64:      	b.lo	0x4c90 <generic_rawtp_process_filter+0x1ca0>
    4c68:      	sub	x8, x10, #0x1
    4c6c:      	mov	w9, #0x3                // =3
    4c70:      	add	x0, sp, #0x58
    4c74:      	mov	w1, wzr
    4c78:      	cmp	x8, #0x3
    4c7c:      	csel	x8, x8, x9, lo
    4c80:      	lsl	x8, x8, #2
    4c84:      	add	x2, x8, #0x4
    4c88:      	bl	0x4c88 <generic_rawtp_process_filter+0x1c98>
    4c8c:      	b	0x4dac <generic_rawtp_process_filter+0x1dbc>
    4c90:      	cmp	w21, #0x3e8
    4c94:      	b.ls	0x4ca0 <generic_rawtp_process_filter+0x1cb0>
    4c98:      	mov	w11, wzr
    4c9c:      	b	0x4ca8 <generic_rawtp_process_filter+0x1cb8>
    4ca0:      	and	w11, w21, #0xfffffffc
    4ca4:      	ldr	w11, [x23, w11, uxtw]
    4ca8:      	ldr	x12, [sp, #0x30]
    4cac:      	cmp	w24, #0x5
    4cb0:      	sub	x10, x10, #0x1
    4cb4:      	ldr	w9, [x12, x9, lsl #2]
    4cb8:      	cset	w12, ne
    4cbc:      	cmp	w24, #0x6
    4cc0:      	cset	w13, ne
    4cc4:      	cmp	w11, w9
    4cc8:      	csinc	w11, w12, wzr, ne
    4ccc:      	csinc	w12, w13, wzr, eq
    4cd0:      	and	w11, w11, w12
    4cd4:      	str	w11, [sp, #0x58]
    4cd8:      	cbz	x10, 0x4dac <generic_rawtp_process_filter+0x1dbc>
    4cdc:      	add	w11, w8, #0x10
    4ce0:      	cmp	w11, #0x3e8
    4ce4:      	b.ls	0x4cf0 <generic_rawtp_process_filter+0x1d00>
    4ce8:      	mov	w11, wzr
    4cec:      	b	0x4cf8 <generic_rawtp_process_filter+0x1d08>
    4cf0:      	and	w11, w11, #0xfffffffc
    4cf4:      	ldr	w11, [x23, w11, uxtw]
    4cf8:      	cmp	w24, #0x5
    4cfc:      	cset	w12, ne
    4d00:      	cmp	w24, #0x6
    4d04:      	cset	w13, ne
    4d08:      	cmp	w11, w9
    4d0c:      	csinc	w11, w12, wzr, ne
    4d10:      	csinc	w12, w13, wzr, eq
    4d14:      	cmp	x10, #0x1
    4d18:      	and	w11, w11, w12
    4d1c:      	str	w11, [sp, #0x5c]
    4d20:      	b.eq	0x4dac <generic_rawtp_process_filter+0x1dbc>
    4d24:      	add	w11, w8, #0x14
    4d28:      	cmp	w11, #0x3e8
    4d2c:      	b.ls	0x4d38 <generic_rawtp_process_filter+0x1d48>
    4d30:      	mov	w11, wzr
    4d34:      	b	0x4d40 <generic_rawtp_process_filter+0x1d50>
    4d38:      	and	w11, w11, #0xfffffffc
    4d3c:      	ldr	w11, [x23, w11, uxtw]
    4d40:      	cmp	w24, #0x5
    4d44:      	cset	w12, ne
    4d48:      	cmp	w24, #0x6
    4d4c:      	cset	w13, ne
    4d50:      	cmp	w11, w9
    4d54:      	csinc	w11, w12, wzr, ne
    4d58:      	csinc	w12, w13, wzr, eq
    4d5c:      	cmp	x10, #0x2
    4d60:      	and	w11, w11, w12
    4d64:      	str	w11, [sp, #0x60]
    4d68:      	b.eq	0x4dac <generic_rawtp_process_filter+0x1dbc>
    4d6c:      	add	w8, w8, #0x18
    4d70:      	cmp	w8, #0x3e8
    4d74:      	b.ls	0x4d80 <generic_rawtp_process_filter+0x1d90>
    4d78:      	mov	w8, wzr
    4d7c:      	b	0x4d88 <generic_rawtp_process_filter+0x1d98>
    4d80:      	and	w8, w8, #0xfffffffc
    4d84:      	ldr	w8, [x23, w8, uxtw]
    4d88:      	cmp	w24, #0x5
    4d8c:      	cset	w10, ne
    4d90:      	cmp	w24, #0x6
    4d94:      	cset	w11, ne
    4d98:      	cmp	w8, w9
    4d9c:      	csinc	w8, w10, wzr, ne
    4da0:      	csinc	w9, w11, wzr, eq
    4da4:      	and	w8, w8, w9
    4da8:      	str	w8, [sp, #0x64]
    4dac:      	ldp	w8, w9, [sp, #0x58]
    4db0:      	ldp	w10, w11, [sp, #0x60]
    4db4:      	cmp	w24, #0x6
    4db8:      	b.ne	0x4dcc <generic_rawtp_process_filter+0x1ddc>
    4dbc:      	and	w8, w9, w8
    4dc0:      	and	w9, w10, w11
    4dc4:      	and	w9, w8, w9
    4dc8:      	b	0x4dd8 <generic_rawtp_process_filter+0x1de8>
    4dcc:      	orr	w8, w9, w8
    4dd0:      	orr	w9, w10, w11
    4dd4:      	orr	w9, w8, w9
    4dd8:      	cbz	w9, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    4ddc:      	lsl	w8, w29, #2
    4de0:      	sub	w10, w22, w29, lsl #2
    4de4:      	and	w8, w8, #0x1c
    4de8:      	sub	w22, w10, #0xc
    4dec:      	add	w8, w8, w21
    4df0:      	b	0x4c20 <generic_rawtp_process_filter+0x1c30>
    4df4:      	mov	w10, w8
    4df8:      	add	w19, w8, #0x4
    4dfc:      	and	x10, x10, #0x3ff
    4e00:      	ldr	w10, [x10, x23]
    4e04:      	cmp	w10, #0x4
    4e08:      	b.ne	0x4ea0 <generic_rawtp_process_filter+0x1eb0>
    4e0c:      	cbz	w9, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    4e10:      	mov	w8, w19
    4e14:      	and	x8, x8, #0x3ff
    4e18:      	ldr	w9, [x8, x23]
    4e1c:      	add	w8, w19, #0x4
    4e20:      	cmp	w9, #0x4
    4e24:      	mov	w9, w8
    4e28:      	b.eq	0x51d0 <generic_rawtp_process_filter+0x21e0>
    4e2c:      	and	x8, x8, #0x3ff
    4e30:      	add	x8, x8, x23
    4e34:      	ldp	w20, w22, [x8]
    4e38:      	mov	w8, #0xe                // =14
    4e3c:      	blr	x8
    4e40:      	lsr	x8, x0, #32
    4e44:      	adrp	x0, 0x4000 <generic_rawtp_process_filter+0x1010>
    4e48:      	add	x9, sp, #0x58
    4e4c:      	str	w8, [sp, #0x58]
    4e50:      	mov	w8, #0x1                // =1
    4e54:      	add	x1, sp, #0x58
    4e58:      	ldr	x0, [x0]
    4e5c:      	blr	x8
    4e60:      	cbz	x0, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    4e64:      	cmp	w20, #0x5
    4e68:      	b.eq	0x4f1c <generic_rawtp_process_filter+0x1f2c>
    4e6c:      	cmp	w20, #0x6
    4e70:      	b.ne	0x52d4 <generic_rawtp_process_filter+0x22e4>
    4e74:      	ldr	x11, [sp, #0xe8]
    4e78:      	mov	w8, #0x5ee8             // =24296
    4e7c:      	add	x8, x11, x8
    4e80:      	tbnz	w22, #0x0, 0x4f50 <generic_rawtp_process_filter+0x1f60>
    4e84:      	ldr	w9, [x0, #0x28]
    4e88:      	cbz	w9, 0x4f48 <generic_rawtp_process_filter+0x1f58>
    4e8c:      	ldr	x10, [sp, #0x30]
    4e90:      	ldr	w10, [x10]
    4e94:      	cmp	w9, w10
    4e98:      	b.eq	0x4f50 <generic_rawtp_process_filter+0x1f60>
    4e9c:      	b	0x51c4 <generic_rawtp_process_filter+0x21d4>
    4ea0:      	and	x9, x19, #0x3ff
    4ea4:      	add	w19, w8, #0x18
    4ea8:      	add	x9, x9, x23
    4eac:      	ldp	w8, w10, [x9]
    4eb0:      	ldr	w12, [x9, #0x8]
    4eb4:      	ldur	x11, [x9, #0xc]
    4eb8:      	cbz	w12, 0x4edc <generic_rawtp_process_filter+0x1eec>
    4ebc:      	ldr	x14, [sp, #0xe8]
    4ec0:      	mov	w9, wzr
    4ec4:      	cmp	w8, #0x2
    4ec8:      	b.hi	0x4e0c <generic_rawtp_process_filter+0x1e1c>
    4ecc:      	ldr	w13, [x14, #0x44]
    4ed0:      	cmp	w13, w12
    4ed4:      	b.ne	0x4ef0 <generic_rawtp_process_filter+0x1f00>
    4ed8:      	b	0x4e0c <generic_rawtp_process_filter+0x1e1c>
    4edc:      	ldr	x14, [sp, #0xe8]
    4ee0:      	cmp	w8, #0x2
    4ee4:      	b.ls	0x4ef0 <generic_rawtp_process_filter+0x1f00>
    4ee8:      	mov	w9, wzr
    4eec:      	b	0x4e0c <generic_rawtp_process_filter+0x1e1c>
    4ef0:      	add	x9, x14, #0x48
    4ef4:      	cmp	w10, #0x5
    4ef8:      	ldr	x8, [x9, x8, lsl #3]
    4efc:      	and	x8, x8, x11
    4f00:      	b.ne	0x4f10 <generic_rawtp_process_filter+0x1f20>
    4f04:      	cmp	x8, #0x0
    4f08:      	cset	w9, ne
    4f0c:      	b	0x4e0c <generic_rawtp_process_filter+0x1e1c>
    4f10:      	cmp	x8, #0x0
    4f14:      	cset	w9, eq
    4f18:      	b	0x4e0c <generic_rawtp_process_filter+0x1e1c>
    4f1c:      	ldr	x11, [sp, #0xe8]
    4f20:      	mov	w8, #0x5ee8             // =24296
    4f24:      	add	x8, x11, x8
    4f28:      	tbz	w22, #0x0, 0x4f74 <generic_rawtp_process_filter+0x1f84>
    4f2c:      	ldr	w9, [x0, #0x28]
    4f30:      	cbz	w9, 0x4f6c <generic_rawtp_process_filter+0x1f7c>
    4f34:      	ldr	x10, [sp, #0x30]
    4f38:      	ldr	w10, [x10]
    4f3c:      	cmp	w9, w10
    4f40:      	b.eq	0x4f74 <generic_rawtp_process_filter+0x1f84>
    4f44:      	b	0x51c4 <generic_rawtp_process_filter+0x21d4>
    4f48:      	mov	w9, #0x1                // =1
    4f4c:      	str	x9, [x8]
    4f50:      	tbnz	w22, #0x1, 0x4f98 <generic_rawtp_process_filter+0x1fa8>
    4f54:      	ldr	w9, [x0, #0x2c]
    4f58:      	cbz	w9, 0x4f90 <generic_rawtp_process_filter+0x1fa0>
    4f5c:      	ldr	w10, [x11, #0x24]
    4f60:      	cmp	w9, w10
    4f64:      	b.eq	0x4f98 <generic_rawtp_process_filter+0x1fa8>
    4f68:      	b	0x51c4 <generic_rawtp_process_filter+0x21d4>
    4f6c:      	mov	w9, #0x1                // =1
    4f70:      	str	x9, [x8]
    4f74:      	tbz	w22, #0x1, 0x4fbc <generic_rawtp_process_filter+0x1fcc>
    4f78:      	ldr	w9, [x0, #0x2c]
    4f7c:      	cbz	w9, 0x4fb4 <generic_rawtp_process_filter+0x1fc4>
    4f80:      	ldr	w10, [x11, #0x24]
    4f84:      	cmp	w9, w10
    4f88:      	b.eq	0x4fbc <generic_rawtp_process_filter+0x1fcc>
    4f8c:      	b	0x51c4 <generic_rawtp_process_filter+0x21d4>
    4f90:      	mov	w9, #0x1                // =1
    4f94:      	str	x9, [x8]
    4f98:      	tbnz	w22, #0x2, 0x4fe0 <generic_rawtp_process_filter+0x1ff0>
    4f9c:      	ldr	w9, [x0, #0x30]
    4fa0:      	cbz	w9, 0x4fd8 <generic_rawtp_process_filter+0x1fe8>
    4fa4:      	ldr	w10, [x11, #0x28]
    4fa8:      	cmp	w9, w10
    4fac:      	b.eq	0x4fe0 <generic_rawtp_process_filter+0x1ff0>
    4fb0:      	b	0x51c4 <generic_rawtp_process_filter+0x21d4>
    4fb4:      	mov	w9, #0x1                // =1
    4fb8:      	str	x9, [x8]
    4fbc:      	tbz	w22, #0x2, 0x5004 <generic_rawtp_process_filter+0x2014>
    4fc0:      	ldr	w9, [x0, #0x30]
    4fc4:      	cbz	w9, 0x4ffc <generic_rawtp_process_filter+0x200c>
    4fc8:      	ldr	w10, [x11, #0x28]
    4fcc:      	cmp	w9, w10
    4fd0:      	b.eq	0x5004 <generic_rawtp_process_filter+0x2014>
    4fd4:      	b	0x51c4 <generic_rawtp_process_filter+0x21d4>
    4fd8:      	mov	w9, #0x1                // =1
    4fdc:      	str	x9, [x8]
    4fe0:      	tbnz	w22, #0x3, 0x5028 <generic_rawtp_process_filter+0x2038>
    4fe4:      	ldr	w9, [x0, #0x34]
    4fe8:      	cbz	w9, 0x5020 <generic_rawtp_process_filter+0x2030>
    4fec:      	ldr	w10, [x11, #0x2c]
    4ff0:      	cmp	w9, w10
    4ff4:      	b.eq	0x5028 <generic_rawtp_process_filter+0x2038>
    4ff8:      	b	0x51c4 <generic_rawtp_process_filter+0x21d4>
    4ffc:      	mov	w9, #0x1                // =1
    5000:      	str	x9, [x8]
    5004:      	tbz	w22, #0x3, 0x504c <generic_rawtp_process_filter+0x205c>
    5008:      	ldr	w9, [x0, #0x34]
    500c:      	cbz	w9, 0x5044 <generic_rawtp_process_filter+0x2054>
    5010:      	ldr	w10, [x11, #0x2c]
    5014:      	cmp	w9, w10
    5018:      	b.eq	0x504c <generic_rawtp_process_filter+0x205c>
    501c:      	b	0x51c4 <generic_rawtp_process_filter+0x21d4>
    5020:      	mov	w9, #0x1                // =1
    5024:      	str	x9, [x8]
    5028:      	tbnz	w22, #0x4, 0x5070 <generic_rawtp_process_filter+0x2080>
    502c:      	ldr	w9, [x0, #0x38]
    5030:      	cbz	w9, 0x5068 <generic_rawtp_process_filter+0x2078>
    5034:      	ldr	w10, [x11, #0x30]
    5038:      	cmp	w9, w10
    503c:      	b.eq	0x5070 <generic_rawtp_process_filter+0x2080>
    5040:      	b	0x51c4 <generic_rawtp_process_filter+0x21d4>
    5044:      	mov	w9, #0x1                // =1
    5048:      	str	x9, [x8]
    504c:      	tbz	w22, #0x4, 0x5094 <generic_rawtp_process_filter+0x20a4>
    5050:      	ldr	w9, [x0, #0x38]
    5054:      	cbz	w9, 0x508c <generic_rawtp_process_filter+0x209c>
    5058:      	ldr	w10, [x11, #0x30]
    505c:      	cmp	w9, w10
    5060:      	b.eq	0x5094 <generic_rawtp_process_filter+0x20a4>
    5064:      	b	0x51c4 <generic_rawtp_process_filter+0x21d4>
    5068:      	mov	w9, #0x1                // =1
    506c:      	str	x9, [x8]
    5070:      	tbnz	w22, #0x5, 0x50b8 <generic_rawtp_process_filter+0x20c8>
    5074:      	ldr	w9, [x0, #0x3c]
    5078:      	cbz	w9, 0x50b0 <generic_rawtp_process_filter+0x20c0>
    507c:      	ldr	w10, [x11, #0x34]
    5080:      	cmp	w9, w10
    5084:      	b.eq	0x50b8 <generic_rawtp_process_filter+0x20c8>
    5088:      	b	0x51c4 <generic_rawtp_process_filter+0x21d4>
    508c:      	mov	w9, #0x1                // =1
    5090:      	str	x9, [x8]
    5094:      	tbz	w22, #0x5, 0x50dc <generic_rawtp_process_filter+0x20ec>
    5098:      	ldr	w9, [x0, #0x3c]
    509c:      	cbz	w9, 0x50d4 <generic_rawtp_process_filter+0x20e4>
    50a0:      	ldr	w10, [x11, #0x34]
    50a4:      	cmp	w9, w10
    50a8:      	b.eq	0x50dc <generic_rawtp_process_filter+0x20ec>
    50ac:      	b	0x51c4 <generic_rawtp_process_filter+0x21d4>
    50b0:      	mov	w9, #0x1                // =1
    50b4:      	str	x9, [x8]
    50b8:      	tbnz	w22, #0x6, 0x5100 <generic_rawtp_process_filter+0x2110>
    50bc:      	ldr	w9, [x0, #0x40]
    50c0:      	cbz	w9, 0x50f8 <generic_rawtp_process_filter+0x2108>
    50c4:      	ldr	w10, [x11, #0x38]
    50c8:      	cmp	w9, w10
    50cc:      	b.eq	0x5100 <generic_rawtp_process_filter+0x2110>
    50d0:      	b	0x51c4 <generic_rawtp_process_filter+0x21d4>
    50d4:      	mov	w9, #0x1                // =1
    50d8:      	str	x9, [x8]
    50dc:      	tbz	w22, #0x6, 0x5124 <generic_rawtp_process_filter+0x2134>
    50e0:      	ldr	w9, [x0, #0x40]
    50e4:      	cbz	w9, 0x511c <generic_rawtp_process_filter+0x212c>
    50e8:      	ldr	w10, [x11, #0x38]
    50ec:      	cmp	w9, w10
    50f0:      	b.eq	0x5124 <generic_rawtp_process_filter+0x2134>
    50f4:      	b	0x51c4 <generic_rawtp_process_filter+0x21d4>
    50f8:      	mov	w9, #0x1                // =1
    50fc:      	str	x9, [x8]
    5100:      	tbnz	w22, #0x7, 0x5148 <generic_rawtp_process_filter+0x2158>
    5104:      	ldr	w9, [x0, #0x44]
    5108:      	cbz	w9, 0x5140 <generic_rawtp_process_filter+0x2150>
    510c:      	ldr	w10, [x11, #0x3c]
    5110:      	cmp	w9, w10
    5114:      	b.eq	0x5148 <generic_rawtp_process_filter+0x2158>
    5118:      	b	0x51c4 <generic_rawtp_process_filter+0x21d4>
    511c:      	mov	w9, #0x1                // =1
    5120:      	str	x9, [x8]
    5124:      	tbz	w22, #0x7, 0x5170 <generic_rawtp_process_filter+0x2180>
    5128:      	ldr	w9, [x0, #0x44]
    512c:      	cbz	w9, 0x5168 <generic_rawtp_process_filter+0x2178>
    5130:      	ldr	w10, [x11, #0x3c]
    5134:      	cmp	w9, w10
    5138:      	b.eq	0x5170 <generic_rawtp_process_filter+0x2180>
    513c:      	b	0x51c4 <generic_rawtp_process_filter+0x21d4>
    5140:      	mov	w9, #0x1                // =1
    5144:      	str	x9, [x8]
    5148:      	tbnz	w22, #0x8, 0x5198 <generic_rawtp_process_filter+0x21a8>
    514c:      	ldr	w9, [x0, #0x48]
    5150:      	cbz	w9, 0x5190 <generic_rawtp_process_filter+0x21a0>
    5154:      	ldr	x10, [sp, #0xe8]
    5158:      	ldr	w10, [x10, #0x40]
    515c:      	cmp	w9, w10
    5160:      	b.eq	0x5198 <generic_rawtp_process_filter+0x21a8>
    5164:      	b	0x51c4 <generic_rawtp_process_filter+0x21d4>
    5168:      	mov	w9, #0x1                // =1
    516c:      	str	x9, [x8]
    5170:      	tbz	w22, #0x8, 0x51a8 <generic_rawtp_process_filter+0x21b8>
    5174:      	ldr	w9, [x0, #0x48]
    5178:      	cbz	w9, 0x51a0 <generic_rawtp_process_filter+0x21b0>
    517c:      	ldr	x10, [sp, #0xe8]
    5180:      	ldr	w10, [x10, #0x40]
    5184:      	cmp	w9, w10
    5188:      	b.eq	0x51a8 <generic_rawtp_process_filter+0x21b8>
    518c:      	b	0x51c4 <generic_rawtp_process_filter+0x21d4>
    5190:      	mov	w9, #0x1                // =1
    5194:      	str	x9, [x8]
    5198:      	tbz	w22, #0x9, 0x51ac <generic_rawtp_process_filter+0x21bc>
    519c:      	b	0x52d4 <generic_rawtp_process_filter+0x22e4>
    51a0:      	mov	w9, #0x1                // =1
    51a4:      	str	x9, [x8]
    51a8:      	tbz	w22, #0x9, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    51ac:      	ldr	w9, [x0, #0x4c]
    51b0:      	cbz	w9, 0x52cc <generic_rawtp_process_filter+0x22dc>
    51b4:      	ldr	x10, [sp, #0xe8]
    51b8:      	ldr	w10, [x10, #0x44]
    51bc:      	cmp	w9, w10
    51c0:      	b.eq	0x52d4 <generic_rawtp_process_filter+0x22e4>
    51c4:      	add	w9, w19, #0xc
    51c8:      	mov	w10, #0x1               // =1
    51cc:      	str	x10, [x8]
    51d0:      	and	x8, x9, #0x3ff
    51d4:      	adrp	x24, 0x5000 <generic_rawtp_process_filter+0x2010>
    51d8:      	ldr	w8, [x8, x23]
    51dc:      	ldr	x24, [x24]
    51e0:      	cmp	w8, #0x4
    51e4:      	b.ne	0x5218 <generic_rawtp_process_filter+0x2228>
    51e8:      	ldr	x9, [sp, #0xe8]
    51ec:      	mov	w8, #0x5eb8             // =24248
    51f0:      	add	x8, x9, x8
    51f4:      	ldr	x9, [x9, #0x5eb8]
    51f8:      	and	x9, x9, #0x1f
    51fc:      	add	x8, x8, x9
    5200:      	mov	w9, #0x1                // =1
    5204:      	strb	w9, [x8, #0x9]
    5208:      	ldr	x8, [sp, #0x40]
    520c:      	strb	w9, [x8, #0x20]
    5210:      	strb	w9, [x8]
    5214:      	b	0x52d4 <generic_rawtp_process_filter+0x22e4>
    5218:      	add	w8, w9, #0x4
    521c:      	and	x8, x8, #0x3ff
    5220:      	add	x8, x8, x23
    5224:      	ldp	w21, w19, [x8]
    5228:      	ldr	w22, [x8, #0x8]
    522c:      	ldur	x20, [x8, #0xc]
    5230:      	mov	w8, #0xe                // =14
    5234:      	blr	x8
    5238:      	lsr	x8, x0, #32
    523c:      	add	x9, sp, #0x58
    5240:      	add	x1, sp, #0x58
    5244:      	str	w8, [sp, #0x58]
    5248:      	mov	w8, #0x1                // =1
    524c:      	mov	x0, x24
    5250:      	blr	x8
    5254:      	cbz	x0, 0x52d4 <generic_rawtp_process_filter+0x22e4>
    5258:      	cmp	w21, #0x2
    525c:      	cbz	w22, 0x5278 <generic_rawtp_process_filter+0x2288>
    5260:      	b.hi	0x52d4 <generic_rawtp_process_filter+0x22e4>
    5264:      	ldr	x8, [sp, #0xe8]
    5268:      	ldr	w8, [x8, #0x44]
    526c:      	cmp	w8, w22
    5270:      	b.ne	0x527c <generic_rawtp_process_filter+0x228c>
    5274:      	b	0x52d4 <generic_rawtp_process_filter+0x22e4>
    5278:      	b.hi	0x52d4 <generic_rawtp_process_filter+0x22e4>
    527c:      	ldr	x8, [sp, #0xe8]
    5280:      	lsl	x10, x21, #3
    5284:      	add	x9, x8, #0x48
    5288:      	add	x8, x0, x21, lsl #3
    528c:      	ldr	x8, [x8, #0x50]
    5290:      	ldr	x9, [x9, x10]
    5294:      	eor	x10, x9, x8
    5298:      	tst	x10, x20
    529c:      	b.eq	0x52ac <generic_rawtp_process_filter+0x22bc>
    52a0:      	cmp	w19, #0x5
    52a4:      	b.eq	0x52bc <generic_rawtp_process_filter+0x22cc>
    52a8:      	b	0x52d4 <generic_rawtp_process_filter+0x22e4>
    52ac:      	cmp	x8, x9
    52b0:      	b.eq	0x52d4 <generic_rawtp_process_filter+0x22e4>
    52b4:      	cmp	w19, #0x6
    52b8:      	b.ne	0x52d4 <generic_rawtp_process_filter+0x22e4>
    52bc:      	ldr	x9, [sp, #0xe8]
    52c0:      	mov	w8, #0x1                // =1
    52c4:      	str	x8, [x9, #0x5ef0]
    52c8:      	b	0x51e8 <generic_rawtp_process_filter+0x21f8>
    52cc:      	mov	w9, #0x1                // =1
    52d0:      	str	x9, [x8]
    52d4:      	ldr	x9, [sp, #0xe8]
    52d8:      	ldr	x10, [sp, #0x28]
    52dc:      	ldr	x8, [x9, #0x5eb8]
    52e0:      	add	x8, x8, #0x1
    52e4:      	cmp	x8, x10
    52e8:      	str	x8, [x9, #0x5eb8]
    52ec:      	b.ls	0x534c <generic_rawtp_process_filter+0x235c>
    52f0:      	ldr	x10, [sp, #0x48]
    52f4:      	ldr	w8, [x10]
    52f8:      	str	w8, [x9, #0x10]
    52fc:      	ldr	x8, [x10, #0x8]
    5300:      	str	x8, [x9, #0x18]
    5304:      	ldp	x20, x8, [sp, #0x38]
    5308:      	ldrb	w8, [x8]
    530c:      	cbz	w8, 0x532c <generic_rawtp_process_filter+0x233c>
    5310:      	adrp	x1, 0x5000 <generic_rawtp_process_filter+0x2010>
    5314:      	mov	x8, xzr
    5318:      	mov	w9, #0xc                // =12
    531c:      	ldr	x1, [x1]
    5320:      	mov	x0, x20
    5324:      	mov	w2, wzr
    5328:      	blr	x9
    532c:      	ldp	x20, x19, [sp, #0x120]
    5330:      	mov	w0, wzr
    5334:      	ldr	x29, [sp, #0xe0]
    5338:      	ldp	x22, x21, [sp, #0x110]
    533c:      	ldp	x24, x23, [sp, #0x100]
    5340:      	ldp	x30, x25, [sp, #0xf0]
    5344:      	add	sp, sp, #0x130
    5348:      	ret
    534c:      	adrp	x1, 0x5000 <generic_rawtp_process_filter+0x2010>
    5350:      	mov	w8, #0x2                // =2
    5354:      	mov	w9, #0xc                // =12
    5358:      	ldr	x1, [x1]
    535c:      	ldr	x0, [sp, #0x38]
    5360:      	mov	w2, #0x2                // =2
    5364:      	b	0x5328 <generic_rawtp_process_filter+0x2338>
    5368:      	nop
    536c:      	nop

0000000000005370 <generic_rawtp_filter_arg>:
    5370:      	sub	sp, sp, #0x70
    5374:      	str	x29, [sp, #0x20]
    5378:      	stp	x30, x25, [sp, #0x30]
    537c:      	stp	x24, x23, [sp, #0x40]
    5380:      	stp	x22, x21, [sp, #0x50]
    5384:      	stp	x20, x19, [sp, #0x60]
    5388:      	mov	x19, x0
    538c:      	str	wzr, [sp, #0x2c]
    5390:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x2010>
    5394:      	mov	w8, #0x1                // =1
    5398:      	ldr	x0, [x0]
    539c:      	add	x9, sp, #0x2c
    53a0:      	add	x1, sp, #0x2c
    53a4:      	blr	x8
    53a8:      	cbz	x0, 0x5734 <generic_rawtp_filter_arg+0x3c4>
    53ac:      	mov	w8, #0x5ec1             // =24257
    53b0:      	mov	x20, x0
    53b4:      	add	x22, x0, x8
    53b8:      	mov	w8, #0x5ef8             // =24312
    53bc:      	add	x1, x0, x8
    53c0:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x2010>
    53c4:      	ldur	w23, [x22, #0x3f]
    53c8:      	mov	w8, #0x1                // =1
    53cc:      	ldr	x0, [x0]
    53d0:      	blr	x8
    53d4:      	cbz	x0, 0x5718 <generic_rawtp_filter_arg+0x3a8>
    53d8:      	ldrb	w8, [x22, #0x1f]
    53dc:      	cbz	w8, 0x5718 <generic_rawtp_filter_arg+0x3a8>
    53e0:      	and	x8, x23, #0x7
    53e4:      	mov	w10, #0x5ec1            // =24257
    53e8:      	add	x9, x20, x8
    53ec:      	ldrb	w9, [x9, x10]
    53f0:      	cbz	w9, 0x5470 <generic_rawtp_filter_arg+0x100>
    53f4:      	lsl	w8, w8, #2
    53f8:      	mov	x21, x0
    53fc:      	add	x8, x8, #0x4
    5400:      	ldr	w9, [x8, x0]
    5404:      	add	x8, x8, x9
    5408:      	add	x8, x8, #0x4
    540c:      	and	x9, x8, #0x3ff
    5410:      	ldr	w9, [x9, x0]
    5414:      	add	x8, x8, x9
    5418:      	and	x9, x8, #0x3ff
    541c:      	ldr	w9, [x9, x0]
    5420:      	add	x8, x8, x9
    5424:      	and	x9, x8, #0x3ff
    5428:      	ldr	w9, [x9, x0]
    542c:      	add	x8, x8, x9
    5430:      	and	x9, x8, #0x3ff
    5434:      	ldr	w9, [x9, x0]
    5438:      	add	x8, x8, x9
    543c:      	and	x9, x8, #0x3ff
    5440:      	ldr	w9, [x9, x0]
    5444:      	add	x25, x8, x9
    5448:      	and	x8, x25, #0x3ff
    544c:      	add	x29, x0, x8
    5450:      	str	x8, [sp, #0x8]
    5454:      	ldr	w8, [x29]
    5458:      	cmp	w8, #0x19
    545c:      	b.hs	0x54b8 <generic_rawtp_filter_arg+0x148>
    5460:      	ldr	x8, [sp, #0x8]
    5464:      	cmp	w8, #0x1
    5468:      	b.eq	0x5718 <generic_rawtp_filter_arg+0x3a8>
    546c:      	cbnz	w8, 0x56f4 <generic_rawtp_filter_arg+0x384>
    5470:      	cmp	w23, #0x1
    5474:      	b.gt	0x5490 <generic_rawtp_filter_arg+0x120>
    5478:      	cmn	w23, #0x1
    547c:      	b.eq	0x5754 <generic_rawtp_filter_arg+0x3e4>
    5480:      	cbz	w23, 0x5764 <generic_rawtp_filter_arg+0x3f4>
    5484:      	cmp	w23, #0x1
    5488:      	b.eq	0x5774 <generic_rawtp_filter_arg+0x404>
    548c:      	b	0x54a8 <generic_rawtp_filter_arg+0x138>
    5490:      	cmp	w23, #0x2
    5494:      	b.eq	0x5784 <generic_rawtp_filter_arg+0x414>
    5498:      	cmp	w23, #0x3
    549c:      	b.eq	0x5794 <generic_rawtp_filter_arg+0x424>
    54a0:      	cmp	w23, #0x4
    54a4:      	b.eq	0x57a4 <generic_rawtp_filter_arg+0x434>
    54a8:      	cmp	w23, #0x4
    54ac:      	b.gt	0x57d0 <generic_rawtp_filter_arg+0x460>
    54b0:      	add	w8, w23, #0x1
    54b4:      	b	0x57b0 <generic_rawtp_filter_arg+0x440>
    54b8:      	mov	w24, #0x4               // =4
    54bc:      	nop
    54c0:      	ldr	w8, [x29, x24]
    54c4:      	tst	w8, #0x3ff
    54c8:      	b.eq	0x5460 <generic_rawtp_filter_arg+0xf0>
    54cc:      	add	w8, w25, w8
    54d0:      	and	x8, x8, #0x3ff
    54d4:      	add	x0, x21, x8
    54d8:      	ldr	w9, [x0, #0x4]
    54dc:      	cmp	w9, #0x23
    54e0:      	b.eq	0x5470 <generic_rawtp_filter_arg+0x100>
    54e4:      	ldr	w8, [x0]
    54e8:      	cmp	w8, #0x4
    54ec:      	b.hi	0x5470 <generic_rawtp_filter_arg+0x100>
    54f0:      	add	x10, x20, x8, lsl #2
    54f4:      	mov	w11, #0x5ea0            // =24224
    54f8:      	ldr	w10, [x10, x11]
    54fc:      	cbnz	w10, 0x5470 <generic_rawtp_filter_arg+0x100>
    5500:      	add	x8, x20, x8, lsl #3
    5504:      	ldr	x8, [x8, #0x5e78]
    5508:      	and	x8, x8, #0x7ff
    550c:      	add	x8, x20, x8
    5510:      	add	x1, x8, #0x90
    5514:      	ldr	w8, [x0, #0xc]
    5518:      	cmp	w8, #0x1b
    551c:      	b.le	0x5540 <generic_rawtp_filter_arg+0x1d0>
    5520:      	cmp	w8, #0x25
    5524:      	b.gt	0x5574 <generic_rawtp_filter_arg+0x204>
    5528:      	sub	w10, w8, #0x1c
    552c:      	cmp	w10, #0x9
    5530:      	b.lo	0x55b8 <generic_rawtp_filter_arg+0x248>
    5534:      	cmp	w8, #0x25
    5538:      	b.eq	0x56a0 <generic_rawtp_filter_arg+0x330>
    553c:      	b	0x56e4 <generic_rawtp_filter_arg+0x374>
    5540:      	cmp	w8, #0x9
    5544:      	b.le	0x5598 <generic_rawtp_filter_arg+0x228>
    5548:      	sub	w10, w8, #0xa
    554c:      	cmp	w10, #0x4
    5550:      	b.lo	0x55b8 <generic_rawtp_filter_arg+0x248>
    5554:      	sub	w9, w8, #0xf
    5558:      	cmp	w9, #0x2
    555c:      	b.lo	0x56a0 <generic_rawtp_filter_arg+0x330>
    5560:      	cmp	w8, #0x11
    5564:      	b.ne	0x56e4 <generic_rawtp_filter_arg+0x374>
    5568:      	add	x1, x1, #0x4
    556c:      	bl	0x556c <generic_rawtp_filter_arg+0x1fc>
    5570:      	b	0x56e0 <generic_rawtp_filter_arg+0x370>
    5574:      	cmp	w8, #0x29
    5578:      	b.gt	0x5688 <generic_rawtp_filter_arg+0x318>
    557c:      	sub	w9, w8, #0x26
    5580:      	cmp	w9, #0x2
    5584:      	b.lo	0x563c <generic_rawtp_filter_arg+0x2cc>
    5588:      	sub	w8, w8, #0x28
    558c:      	cmp	w8, #0x2
    5590:      	b.lo	0x5634 <generic_rawtp_filter_arg+0x2c4>
    5594:      	b	0x56e4 <generic_rawtp_filter_arg+0x374>
    5598:      	cmp	w8, #0x4
    559c:      	b.gt	0x561c <generic_rawtp_filter_arg+0x2ac>
    55a0:      	cmp	w8, #0x1
    55a4:      	b.eq	0x55b8 <generic_rawtp_filter_arg+0x248>
    55a8:      	cmp	w8, #0x2
    55ac:      	b.eq	0x56c4 <generic_rawtp_filter_arg+0x354>
    55b0:      	cmp	w8, #0x4
    55b4:      	b.ne	0x56e4 <generic_rawtp_filter_arg+0x374>
    55b8:      	cmp	w8, #0xb
    55bc:      	b.le	0x55fc <generic_rawtp_filter_arg+0x28c>
    55c0:      	cmp	w8, #0x24
    55c4:      	b.hi	0x56a8 <generic_rawtp_filter_arg+0x338>
    55c8:      	mov	w11, #0x1               // =1
    55cc:      	lsl	x10, x11, x8
    55d0:      	tst	x10, #0x1e00000000
    55d4:      	b.ne	0x5644 <generic_rawtp_filter_arg+0x2d4>
    55d8:      	lsl	x9, x11, x8
    55dc:      	tst	x9, #0x60000000
    55e0:      	mov	w9, #0x1                // =1
    55e4:      	b.ne	0x56bc <generic_rawtp_filter_arg+0x34c>
    55e8:      	lsl	x9, x9, x8
    55ec:      	tst	x9, #0x180000000
    55f0:      	b.eq	0x56a8 <generic_rawtp_filter_arg+0x338>
    55f4:      	bl	0x55f4 <generic_rawtp_filter_arg+0x284>
    55f8:      	b	0x56e0 <generic_rawtp_filter_arg+0x370>
    55fc:      	sub	w9, w8, #0xa
    5600:      	cmp	w9, #0x2
    5604:      	b.lo	0x56d8 <generic_rawtp_filter_arg+0x368>
    5608:      	cmp	w8, #0x1
    560c:      	b.eq	0x56b4 <generic_rawtp_filter_arg+0x344>
    5610:      	cmp	w8, #0x4
    5614:      	b.eq	0x56b4 <generic_rawtp_filter_arg+0x344>
    5618:      	b	0x56e4 <generic_rawtp_filter_arg+0x374>
    561c:      	cmp	w8, #0x5
    5620:      	b.eq	0x5634 <generic_rawtp_filter_arg+0x2c4>
    5624:      	cmp	w8, #0x6
    5628:      	b.eq	0x563c <generic_rawtp_filter_arg+0x2cc>
    562c:      	cmp	w8, #0x7
    5630:      	b.ne	0x56e4 <generic_rawtp_filter_arg+0x374>
    5634:      	bl	0x5634 <generic_rawtp_filter_arg+0x2c4>
    5638:      	b	0x56e0 <generic_rawtp_filter_arg+0x370>
    563c:      	mov	w2, #0x4                // =4
    5640:      	b	0x56c8 <generic_rawtp_filter_arg+0x358>
    5644:      	cmp	w9, #0x1e
    5648:      	b.ne	0x56d8 <generic_rawtp_filter_arg+0x368>
    564c:      	ldr	w8, [x0, #0x10]
    5650:      	mov	w10, #0x5ea0            // =24224
    5654:      	and	x8, x8, #0x7
    5658:      	add	x9, x20, x8, lsl #2
    565c:      	ldr	w9, [x9, x10]
    5660:      	cbnz	w9, 0x5470 <generic_rawtp_filter_arg+0x100>
    5664:      	add	x8, x20, x8, lsl #3
    5668:      	ldr	x9, [x1]
    566c:      	ldr	x8, [x8, #0x5e78]
    5670:      	and	x8, x8, #0x7ff
    5674:      	add	x8, x20, x8
    5678:      	ldr	x8, [x8, #0x90]
    567c:      	bics	xzr, x8, x9
    5680:      	cset	w0, ne
    5684:      	b	0x56e0 <generic_rawtp_filter_arg+0x370>
    5688:      	cmp	w8, #0x2a
    568c:      	b.eq	0x56a0 <generic_rawtp_filter_arg+0x330>
    5690:      	cmp	w8, #0x2c
    5694:      	b.ne	0x56e4 <generic_rawtp_filter_arg+0x374>
    5698:      	bl	0x5698 <generic_rawtp_filter_arg+0x328>
    569c:      	b	0x56e0 <generic_rawtp_filter_arg+0x370>
    56a0:      	bl	0x56a0 <generic_rawtp_filter_arg+0x330>
    56a4:      	b	0x56e0 <generic_rawtp_filter_arg+0x370>
    56a8:      	sub	w9, w8, #0xc
    56ac:      	cmp	w9, #0x2
    56b0:      	b.hs	0x56d0 <generic_rawtp_filter_arg+0x360>
    56b4:      	bl	0x56b4 <generic_rawtp_filter_arg+0x344>
    56b8:      	b	0x56e0 <generic_rawtp_filter_arg+0x370>
    56bc:      	bl	0x56bc <generic_rawtp_filter_arg+0x34c>
    56c0:      	b	0x56e0 <generic_rawtp_filter_arg+0x370>
    56c4:      	mov	w2, #0x8                // =8
    56c8:      	bl	0x56c8 <generic_rawtp_filter_arg+0x358>
    56cc:      	b	0x56e0 <generic_rawtp_filter_arg+0x370>
    56d0:      	cmp	w8, #0x1c
    56d4:      	b.ne	0x56e4 <generic_rawtp_filter_arg+0x374>
    56d8:      	bl	0x56d8 <generic_rawtp_filter_arg+0x368>
    56dc:      	nop
    56e0:      	cbz	x0, 0x5470 <generic_rawtp_filter_arg+0x100>
    56e4:      	add	x24, x24, #0x4
    56e8:      	cmp	x24, #0x18
    56ec:      	b.ne	0x54c0 <generic_rawtp_filter_arg+0x150>
    56f0:      	b	0x5460 <generic_rawtp_filter_arg+0xf0>
    56f4:      	ldr	x8, [sp, #0x8]
    56f8:      	adrp	x1, 0x5000 <generic_rawtp_process_filter+0x2010>
    56fc:      	mov	w9, #0xc                // =12
    5700:      	mov	x0, x19
    5704:      	stur	w8, [x22, #0x43]
    5708:      	mov	w8, #0x4                // =4
    570c:      	mov	w2, #0x4                // =4
    5710:      	ldr	x1, [x1]
    5714:      	blr	x9
    5718:      	adrp	x1, 0x5000 <generic_rawtp_process_filter+0x2010>
    571c:      	mov	w8, #0x5                // =5
    5720:      	mov	w9, #0xc                // =12
    5724:      	ldr	x1, [x1]
    5728:      	mov	x0, x19
    572c:      	mov	w2, #0x5                // =5
    5730:      	blr	x9
    5734:      	ldp	x20, x19, [sp, #0x60]
    5738:      	mov	w0, wzr
    573c:      	ldr	x29, [sp, #0x20]
    5740:      	ldp	x22, x21, [sp, #0x50]
    5744:      	ldp	x24, x23, [sp, #0x40]
    5748:      	ldp	x30, x25, [sp, #0x30]
    574c:      	add	sp, sp, #0x70
    5750:      	ret
    5754:      	ldrb	w8, [x22]
    5758:      	cbz	w8, 0x5764 <generic_rawtp_filter_arg+0x3f4>
    575c:      	mov	w8, wzr
    5760:      	b	0x57b0 <generic_rawtp_filter_arg+0x440>
    5764:      	ldrb	w8, [x22, #0x1]
    5768:      	cbz	w8, 0x5774 <generic_rawtp_filter_arg+0x404>
    576c:      	mov	w8, #0x1                // =1
    5770:      	b	0x57b0 <generic_rawtp_filter_arg+0x440>
    5774:      	ldrb	w8, [x22, #0x2]
    5778:      	cbz	w8, 0x5784 <generic_rawtp_filter_arg+0x414>
    577c:      	mov	w8, #0x2                // =2
    5780:      	b	0x57b0 <generic_rawtp_filter_arg+0x440>
    5784:      	ldrb	w8, [x22, #0x3]
    5788:      	cbz	w8, 0x5794 <generic_rawtp_filter_arg+0x424>
    578c:      	mov	w8, #0x3                // =3
    5790:      	b	0x57b0 <generic_rawtp_filter_arg+0x440>
    5794:      	ldrb	w8, [x22, #0x4]
    5798:      	cbz	w8, 0x57a4 <generic_rawtp_filter_arg+0x434>
    579c:      	mov	w8, #0x4                // =4
    57a0:      	b	0x57b0 <generic_rawtp_filter_arg+0x440>
    57a4:      	ldrb	w8, [x22, #0x5]
    57a8:      	cbz	w8, 0x57d0 <generic_rawtp_filter_arg+0x460>
    57ac:      	mov	w8, #0x5                // =5
    57b0:      	stur	w8, [x22, #0x3f]
    57b4:      	adrp	x1, 0x5000 <generic_rawtp_process_filter+0x2010>
    57b8:      	mov	w8, #0x3                // =3
    57bc:      	mov	w9, #0xc                // =12
    57c0:      	ldr	x1, [x1]
    57c4:      	mov	x0, x19
    57c8:      	mov	w2, #0x3                // =3
    57cc:      	blr	x9
    57d0:      	ldr	x19, [x20, #0x60]
    57d4:      	mov	w8, #0xe                // =14
    57d8:      	blr	x8
    57dc:      	stp	x19, x0, [sp, #0x10]
    57e0:      	adrp	x19, 0x5000 <generic_rawtp_process_filter+0x2010>
    57e4:      	mov	w8, #0x1                // =1
    57e8:      	add	x9, sp, #0x10
    57ec:      	add	x1, sp, #0x10
    57f0:      	ldr	x19, [x19]
    57f4:      	mov	x0, x19
    57f8:      	blr	x8
    57fc:      	cbz	x0, 0x5734 <generic_rawtp_filter_arg+0x3c4>
    5800:      	mov	w8, #0x3                // =3
    5804:      	add	x9, sp, #0x10
    5808:      	add	x1, sp, #0x10
    580c:      	mov	x0, x19
    5810:      	blr	x8
    5814:      	b	0x5734 <generic_rawtp_filter_arg+0x3c4>
    5818:      	nop
    581c:      	nop

0000000000005820 <generic_rawtp_actions>:
    5820:      	sub	sp, sp, #0x40
    5824:      	str	x30, [sp, #0x10]
    5828:      	stp	x22, x21, [sp, #0x20]
    582c:      	stp	x20, x19, [sp, #0x30]
    5830:      	mov	x19, x0
    5834:      	str	wzr, [sp, #0xc]
    5838:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x2010>
    583c:      	mov	w8, #0x1                // =1
    5840:      	ldr	x0, [x0]
    5844:      	add	x9, sp, #0xc
    5848:      	add	x1, sp, #0xc
    584c:      	blr	x8
    5850:      	cbz	x0, 0x5968 <generic_rawtp_actions+0x148>
    5854:      	mov	w8, #0x5f04             // =24324
    5858:      	ldr	w22, [x0, x8]
    585c:      	cmp	w22, #0x2
    5860:      	b.lt	0x5968 <generic_rawtp_actions+0x148>
    5864:      	mov	w8, #0x5ef8             // =24312
    5868:      	mov	w20, #0x1               // =1
    586c:      	add	x1, x0, x8
    5870:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x2010>
    5874:      	mov	w8, #0x1                // =1
    5878:      	ldr	x0, [x0]
    587c:      	blr	x8
    5880:      	cbz	x0, 0x5968 <generic_rawtp_actions+0x148>
    5884:      	and	x8, x22, #0x7ff
    5888:      	mov	x21, x0
    588c:      	strb	w20, [sp, #0x1c]
    5890:      	mov	w9, #0x1                // =1
    5894:      	ldr	w8, [x0, x8]
    5898:      	str	wzr, [sp, #0x18]
    589c:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x2010>
    58a0:      	add	x1, sp, #0x18
    58a4:      	ldr	x0, [x0]
    58a8:      	add	w8, w8, w22
    58ac:      	and	w22, w8, #0x7ff
    58b0:      	add	x8, sp, #0x18
    58b4:      	blr	x9
    58b8:      	cbz	x0, 0x58c8 <generic_rawtp_actions+0xa8>
    58bc:      	ldrb	w8, [x0]
    58c0:      	cmp	w8, #0x0
    58c4:      	cset	w20, eq
    58c8:      	ldr	w8, [x21, x22]
    58cc:      	cmp	w8, #0x5
    58d0:      	b.lo	0x5944 <generic_rawtp_actions+0x124>
    58d4:      	add	x2, x21, x22
    58d8:      	add	x3, sp, #0x1c
    58dc:      	mov	x0, x19
    58e0:      	mov	w1, wzr
    58e4:      	mov	w4, w20
    58e8:      	bl	0x58e8 <generic_rawtp_actions+0xc8>
    58ec:      	ldr	w9, [x21, x22]
    58f0:      	lsl	w8, w0, #2
    58f4:      	add	w8, w8, #0x4
    58f8:      	cmp	w8, w9
    58fc:      	b.hs	0x5944 <generic_rawtp_actions+0x124>
    5900:      	mov	w1, w0
    5904:      	add	x2, x21, x22
    5908:      	add	x3, sp, #0x1c
    590c:      	mov	x0, x19
    5910:      	mov	w4, w20
    5914:      	bl	0x5914 <generic_rawtp_actions+0xf4>
    5918:      	ldr	w9, [x21, x22]
    591c:      	lsl	w8, w0, #2
    5920:      	add	w8, w8, #0x4
    5924:      	cmp	w8, w9
    5928:      	b.hs	0x5944 <generic_rawtp_actions+0x124>
    592c:      	mov	w1, w0
    5930:      	add	x2, x21, x22
    5934:      	add	x3, sp, #0x1c
    5938:      	mov	x0, x19
    593c:      	mov	w4, w20
    5940:      	bl	0x5940 <generic_rawtp_actions+0x120>
    5944:      	ldrb	w8, [sp, #0x1c]
    5948:      	cbz	w8, 0x5968 <generic_rawtp_actions+0x148>
    594c:      	adrp	x1, 0x5000 <generic_rawtp_process_filter+0x2010>
    5950:      	mov	w8, #0x5                // =5
    5954:      	mov	w9, #0xc                // =12
    5958:      	ldr	x1, [x1]
    595c:      	mov	x0, x19
    5960:      	mov	w2, #0x5                // =5
    5964:      	blr	x9
    5968:      	ldp	x20, x19, [sp, #0x30]
    596c:      	mov	w0, wzr
    5970:      	ldr	x30, [sp, #0x10]
    5974:      	ldp	x22, x21, [sp, #0x20]
    5978:      	add	sp, sp, #0x40
    597c:      	ret

0000000000005980 <generic_rawtp_output>:
    5980:      	sub	sp, sp, #0xc0
    5984:      	str	x29, [sp, #0x70]
    5988:      	stp	x30, x25, [sp, #0x80]
    598c:      	stp	x24, x23, [sp, #0x90]
    5990:      	stp	x22, x21, [sp, #0xa0]
    5994:      	stp	x20, x19, [sp, #0xb0]
    5998:      	mov	x20, x0
    599c:      	str	wzr, [sp, #0x4]
    59a0:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x2010>
    59a4:      	mov	w8, #0x1                // =1
    59a8:      	ldr	x0, [x0]
    59ac:      	add	x9, sp, #0x4
    59b0:      	add	x1, sp, #0x4
    59b4:      	blr	x8
    59b8:      	cbz	x0, 0x5f50 <generic_rawtp_output+0x5d0>
    59bc:      	adrp	x21, 0x5000 <generic_rawtp_process_filter+0x2010>
    59c0:      	ldr	x8, [x0, #0x5ee8]
    59c4:      	mov	x19, x0
    59c8:      	ldr	x21, [x21]
    59cc:      	cbz	x8, 0x5c58 <generic_rawtp_output+0x2d8>
    59d0:      	mov	w8, #0xe                // =14
    59d4:      	blr	x8
    59d8:      	mov	w8, #0x23               // =35
    59dc:      	lsr	x22, x0, #32
    59e0:      	blr	x8
    59e4:      	str	w22, [sp, #0x28]
    59e8:      	mov	w8, #0x1                // =1
    59ec:      	add	x9, sp, #0x28
    59f0:      	mov	x23, x0
    59f4:      	add	x1, sp, #0x28
    59f8:      	mov	x0, x21
    59fc:      	blr	x8
    5a00:      	cbz	x0, 0x5c58 <generic_rawtp_output+0x2d8>
    5a04:      	add	x2, x23, #0xb50
    5a08:      	mov	w29, #0x8               // =8
    5a0c:      	add	x8, sp, #0x78
    5a10:      	mov	w9, #0x4                // =4
    5a14:      	mov	x22, x0
    5a18:      	add	x24, x0, #0x28
    5a1c:      	add	x0, sp, #0x78
    5a20:      	mov	w1, #0x8                // =8
    5a24:      	mov	w25, #0x4               // =4
    5a28:      	blr	x9
    5a2c:      	ldr	x8, [sp, #0x78]
    5a30:      	mov	w9, #0x48               // =72
    5a34:      	add	x10, sp, #0x28
    5a38:      	mov	w11, #0x4               // =4
    5a3c:      	ldr	x2, [sp, #0x78]
    5a40:      	add	x0, sp, #0x28
    5a44:      	mov	w1, #0x48               // =72
    5a48:      	blr	x11
    5a4c:      	ldr	x8, [sp, #0x30]
    5a50:      	mov	w9, #0x4                // =4
    5a54:      	mov	x0, x24
    5a58:      	mov	w1, #0x4                // =4
    5a5c:      	add	x8, x8, #0x218
    5a60:      	ldr	x8, [sp, #0x30]
    5a64:      	add	x2, x8, #0x218
    5a68:      	blr	x9
    5a6c:      	ldr	x8, [sp, #0x38]
    5a70:      	add	x0, x22, #0x2c
    5a74:      	mov	w9, #0x4                // =4
    5a78:      	mov	w1, #0x4                // =4
    5a7c:      	add	x8, x8, #0x4d8
    5a80:      	ldr	x8, [sp, #0x38]
    5a84:      	add	x2, x8, #0x4d8
    5a88:      	blr	x9
    5a8c:      	ldr	x8, [sp, #0x40]
    5a90:      	add	x0, x22, #0x30
    5a94:      	mov	w9, #0x4                // =4
    5a98:      	mov	w1, #0x4                // =4
    5a9c:      	add	x8, x8, #0x58
    5aa0:      	ldr	x8, [sp, #0x40]
    5aa4:      	add	x2, x8, #0x58
    5aa8:      	blr	x9
    5aac:      	str	xzr, [sp, #0x20]
    5ab0:      	add	x2, x23, #0x938
    5ab4:      	add	x8, sp, #0x20
    5ab8:      	add	x0, sp, #0x20
    5abc:      	mov	w1, #0x8                // =8
    5ac0:      	blr	x25
    5ac4:      	ldr	x8, [sp, #0x20]
    5ac8:      	cbz	x8, 0x5b4c <generic_rawtp_output+0x1cc>
    5acc:      	str	wzr, [sp, #0x1c]
    5ad0:      	add	x8, x8, #0x4
    5ad4:      	add	x9, sp, #0x1c
    5ad8:      	mov	w10, #0x4               // =4
    5adc:      	add	x0, sp, #0x1c
    5ae0:      	mov	w1, #0x4                // =4
    5ae4:      	mov	w24, #0x4               // =4
    5ae8:      	ldr	x8, [sp, #0x20]
    5aec:      	add	x2, x8, #0x4
    5af0:      	blr	x10
    5af4:      	ldr	x8, [sp, #0x20]
    5af8:      	ldrsw	x9, [sp, #0x1c]
    5afc:      	add	x10, sp, #0x8
    5b00:      	mov	w11, #0x4               // =4
    5b04:      	add	x0, sp, #0x8
    5b08:      	mov	w1, #0x10               // =16
    5b0c:      	add	x8, x8, x9, lsl #4
    5b10:      	mov	w9, #0x10               // =16
    5b14:      	add	x8, x8, #0x80
    5b18:      	ldr	x8, [sp, #0x20]
    5b1c:      	ldrsw	x9, [sp, #0x1c]
    5b20:      	add	x8, x8, x9, lsl #4
    5b24:      	add	x2, x8, #0x80
    5b28:      	blr	x11
    5b2c:      	ldr	x8, [sp, #0x10]
    5b30:      	add	x0, x22, #0x34
    5b34:      	mov	w1, #0x4                // =4
    5b38:      	add	x8, x8, #0x158
    5b3c:      	ldr	x8, [sp, #0x10]
    5b40:      	add	x2, x8, #0x158
    5b44:      	blr	x24
    5b48:      	b	0x5b50 <generic_rawtp_output+0x1d0>
    5b4c:      	str	wzr, [x22, #0x34]
    5b50:      	ldr	x8, [sp, #0x48]
    5b54:      	add	x0, x22, #0x38
    5b58:      	mov	w9, #0x4                // =4
    5b5c:      	mov	w1, #0x4                // =4
    5b60:      	mov	w24, #0x4               // =4
    5b64:      	add	x8, x8, #0x158
    5b68:      	ldr	x8, [sp, #0x48]
    5b6c:      	add	x2, x8, #0x158
    5b70:      	blr	x9
    5b74:      	ldr	x8, [sp, #0x50]
    5b78:      	add	x0, x22, #0x3c
    5b7c:      	mov	w9, #0x4                // =4
    5b80:      	mov	w1, #0x4                // =4
    5b84:      	add	x8, x8, #0x118
    5b88:      	ldr	x8, [sp, #0x50]
    5b8c:      	add	x2, x8, #0x118
    5b90:      	blr	x9
    5b94:      	ldr	x8, [sp, #0x58]
    5b98:      	add	x0, x22, #0x40
    5b9c:      	mov	w9, #0x4                // =4
    5ba0:      	mov	w1, #0x4                // =4
    5ba4:      	add	x8, x8, #0x98
    5ba8:      	ldr	x8, [sp, #0x58]
    5bac:      	add	x2, x8, #0x98
    5bb0:      	blr	x9
    5bb4:      	ldr	x8, [sp, #0x60]
    5bb8:      	add	x0, x22, #0x44
    5bbc:      	mov	w9, #0x4                // =4
    5bc0:      	mov	w1, #0x4                // =4
    5bc4:      	add	x8, x8, #0x98
    5bc8:      	ldr	x8, [sp, #0x60]
    5bcc:      	add	x2, x8, #0x98
    5bd0:      	blr	x9
    5bd4:      	ldr	x8, [sp, #0x68]
    5bd8:      	add	x0, x22, #0x48
    5bdc:      	mov	w9, #0x4                // =4
    5be0:      	mov	w1, #0x4                // =4
    5be4:      	add	x8, x8, #0x58
    5be8:      	ldr	x8, [sp, #0x68]
    5bec:      	add	x2, x8, #0x58
    5bf0:      	blr	x9
    5bf4:      	str	xzr, [sp, #0x8]
    5bf8:      	str	xzr, [sp, #0x20]
    5bfc:      	add	x2, x23, #0xae0
    5c00:      	mov	w23, #0x8               // =8
    5c04:      	add	x8, sp, #0x8
    5c08:      	mov	w9, #0x4                // =4
    5c0c:      	add	x0, sp, #0x8
    5c10:      	mov	w1, #0x8                // =8
    5c14:      	blr	x9
    5c18:      	ldr	x8, [sp, #0x8]
    5c1c:      	add	x9, sp, #0x20
    5c20:      	mov	w10, #0x4               // =4
    5c24:      	add	x0, sp, #0x20
    5c28:      	mov	w1, #0x8                // =8
    5c2c:      	add	x8, x8, #0x90
    5c30:      	ldr	x8, [sp, #0x8]
    5c34:      	add	x2, x8, #0x90
    5c38:      	blr	x10
    5c3c:      	ldr	x8, [sp, #0x20]
    5c40:      	add	x0, x22, #0x4c
    5c44:      	mov	w1, #0x4                // =4
    5c48:      	add	x8, x8, #0x158
    5c4c:      	ldr	x8, [sp, #0x20]
    5c50:      	add	x2, x8, #0x158
    5c54:      	blr	x24
    5c58:      	ldr	x8, [x19, #0x5ef0]
    5c5c:      	cbz	x8, 0x5cf8 <generic_rawtp_output+0x378>
    5c60:      	mov	w8, #0xe                // =14
    5c64:      	blr	x8
    5c68:      	mov	w8, #0x23               // =35
    5c6c:      	lsr	x23, x0, #32
    5c70:      	blr	x8
    5c74:      	str	w23, [sp, #0x28]
    5c78:      	mov	w8, #0x1                // =1
    5c7c:      	add	x9, sp, #0x28
    5c80:      	mov	x22, x0
    5c84:      	add	x1, sp, #0x28
    5c88:      	mov	x0, x21
    5c8c:      	blr	x8
    5c90:      	cbz	x0, 0x5cf8 <generic_rawtp_output+0x378>
    5c94:      	add	x2, x22, #0xae0
    5c98:      	mov	w22, #0x8               // =8
    5c9c:      	add	x8, sp, #0x28
    5ca0:      	mov	w9, #0x4                // =4
    5ca4:      	add	x21, x0, #0x50
    5ca8:      	mov	x24, x0
    5cac:      	add	x0, sp, #0x28
    5cb0:      	mov	w1, #0x8                // =8
    5cb4:      	mov	w23, #0x4               // =4
    5cb8:      	blr	x9
    5cbc:      	ldr	x25, [sp, #0x28]
    5cc0:      	add	x0, x24, #0x58
    5cc4:      	mov	w8, #0x4                // =4
    5cc8:      	mov	w1, #0x8                // =8
    5ccc:      	add	x2, x25, #0x40
    5cd0:      	blr	x8
    5cd4:      	add	x0, x24, #0x60
    5cd8:      	add	x2, x25, #0x30
    5cdc:      	mov	w8, #0x4                // =4
    5ce0:      	mov	w1, #0x8                // =8
    5ce4:      	blr	x8
    5ce8:      	add	x2, x25, #0x38
    5cec:      	mov	x0, x21
    5cf0:      	mov	w1, #0x8                // =8
    5cf4:      	blr	x23
    5cf8:      	ldr	w8, [x19, #0x4]
    5cfc:      	mov	w9, #0x2328             // =9000
    5d00:      	str	wzr, [sp, #0x8]
    5d04:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x2010>
    5d08:      	add	x1, sp, #0x8
    5d0c:      	add	w8, w8, #0x90
    5d10:      	ldr	x0, [x0]
    5d14:      	and	w8, w8, #0x7fff
    5d18:      	cmp	w8, w9
    5d1c:      	csel	w21, w8, w9, lo
    5d20:      	mov	w8, #0x1                // =1
    5d24:      	add	x9, sp, #0x8
    5d28:      	blr	x8
    5d2c:      	cbz	x0, 0x5d98 <generic_rawtp_output+0x418>
    5d30:      	ldrb	w8, [x0, #0x28]
    5d34:      	cbz	w8, 0x5d98 <generic_rawtp_output+0x418>
    5d38:      	adrp	x1, 0x5000 <generic_rawtp_process_filter+0x2010>
    5d3c:      	mov	w8, #-0x1               // =-1
    5d40:      	mov	w9, #0x19               // =25
    5d44:      	ldr	x1, [x1]
    5d48:      	mov	x0, x20
    5d4c:      	mov	w2, #-0x1               // =-1
    5d50:      	mov	x3, x19
    5d54:      	mov	x4, x21
    5d58:      	blr	x9
    5d5c:      	tbnz	x0, #0x3f, 0x5e44 <generic_rawtp_output+0x4c4>
    5d60:      	str	wzr, [sp, #0x28]
    5d64:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x2010>
    5d68:      	mov	w8, #0x1                // =1
    5d6c:      	add	x9, sp, #0x28
    5d70:      	ldr	x0, [x0]
    5d74:      	add	x1, sp, #0x28
    5d78:      	blr	x8
    5d7c:      	cbz	x0, 0x5f50 <generic_rawtp_output+0x5d0>
    5d80:      	add	x8, x0, #0x8
    5d84:      	ldaxr	x9, [x8]
    5d88:      	add	x9, x9, #0x1
    5d8c:      	stlxr	w10, x9, [x8]
    5d90:      	cbnz	w10, 0x5d84 <generic_rawtp_output+0x404>
    5d94:      	b	0x5f50 <generic_rawtp_output+0x5d0>
    5d98:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x2010>
    5d9c:      	mov	x3, xzr
    5da0:      	mov	w8, #0x82               // =130
    5da4:      	ldr	x0, [x0]
    5da8:      	mov	x1, x19
    5dac:      	mov	x2, x21
    5db0:      	blr	x8
    5db4:      	tbnz	x0, #0x3f, 0x5df4 <generic_rawtp_output+0x474>
    5db8:      	str	wzr, [sp, #0x28]
    5dbc:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x2010>
    5dc0:      	mov	w8, #0x1                // =1
    5dc4:      	add	x9, sp, #0x28
    5dc8:      	ldr	x0, [x0]
    5dcc:      	add	x1, sp, #0x28
    5dd0:      	blr	x8
    5dd4:      	cbz	x0, 0x5f50 <generic_rawtp_output+0x5d0>
    5dd8:      	add	x8, x0, #0x8
    5ddc:      	nop
    5de0:      	ldaxr	x9, [x8]
    5de4:      	add	x9, x9, #0x1
    5de8:      	stlxr	w10, x9, [x8]
    5dec:      	cbnz	w10, 0x5de0 <generic_rawtp_output+0x460>
    5df0:      	b	0x5f50 <generic_rawtp_output+0x5d0>
    5df4:      	mov	x19, x0
    5df8:      	str	wzr, [sp, #0x28]
    5dfc:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x2010>
    5e00:      	mov	w8, #0x1                // =1
    5e04:      	ldr	x0, [x0]
    5e08:      	add	x9, sp, #0x28
    5e0c:      	add	x1, sp, #0x28
    5e10:      	blr	x8
    5e14:      	cbz	x0, 0x5f50 <generic_rawtp_output+0x5d0>
    5e18:      	mov	x8, x19
    5e1c:      	cmn	x19, #0xc
    5e20:      	b.gt	0x5e94 <generic_rawtp_output+0x514>
    5e24:      	cmn	x8, #0x1c
    5e28:      	b.eq	0x5ed4 <generic_rawtp_output+0x554>
    5e2c:      	cmn	x8, #0x16
    5e30:      	b.eq	0x5eec <generic_rawtp_output+0x56c>
    5e34:      	cmn	x8, #0x10
    5e38:      	b.ne	0x5ee4 <generic_rawtp_output+0x564>
    5e3c:      	add	x8, x0, #0x328
    5e40:      	b	0x5f00 <generic_rawtp_output+0x580>
    5e44:      	mov	x19, x0
    5e48:      	str	wzr, [sp, #0x28]
    5e4c:      	adrp	x0, 0x5000 <generic_rawtp_process_filter+0x2010>
    5e50:      	mov	w8, #0x1                // =1
    5e54:      	ldr	x0, [x0]
    5e58:      	add	x9, sp, #0x28
    5e5c:      	add	x1, sp, #0x28
    5e60:      	blr	x8
    5e64:      	cbz	x0, 0x5f50 <generic_rawtp_output+0x5d0>
    5e68:      	mov	x8, x19
    5e6c:      	cmn	x19, #0xc
    5e70:      	b.gt	0x5eb4 <generic_rawtp_output+0x534>
    5e74:      	cmn	x8, #0x1c
    5e78:      	b.eq	0x5f14 <generic_rawtp_output+0x594>
    5e7c:      	cmn	x8, #0x16
    5e80:      	b.eq	0x5f2c <generic_rawtp_output+0x5ac>
    5e84:      	cmn	x8, #0x10
    5e88:      	b.ne	0x5f24 <generic_rawtp_output+0x5a4>
    5e8c:      	add	x8, x0, #0x328
    5e90:      	b	0x5f40 <generic_rawtp_output+0x5c0>
    5e94:      	cmn	x8, #0xb
    5e98:      	b.eq	0x5edc <generic_rawtp_output+0x55c>
    5e9c:      	cmn	x8, #0x7
    5ea0:      	b.eq	0x5ef4 <generic_rawtp_output+0x574>
    5ea4:      	cmn	x8, #0x2
    5ea8:      	b.ne	0x5ee4 <generic_rawtp_output+0x564>
    5eac:      	add	x8, x0, #0x318
    5eb0:      	b	0x5f00 <generic_rawtp_output+0x580>
    5eb4:      	cmn	x8, #0xb
    5eb8:      	b.eq	0x5f1c <generic_rawtp_output+0x59c>
    5ebc:      	cmn	x8, #0x7
    5ec0:      	b.eq	0x5f34 <generic_rawtp_output+0x5b4>
    5ec4:      	cmn	x8, #0x2
    5ec8:      	b.ne	0x5f24 <generic_rawtp_output+0x5a4>
    5ecc:      	add	x8, x0, #0x318
    5ed0:      	b	0x5f40 <generic_rawtp_output+0x5c0>
    5ed4:      	add	x8, x0, #0x338
    5ed8:      	b	0x5f00 <generic_rawtp_output+0x580>
    5edc:      	add	x8, x0, #0x340
    5ee0:      	b	0x5f00 <generic_rawtp_output+0x580>
    5ee4:      	add	x8, x0, #0x310
    5ee8:      	b	0x5f00 <generic_rawtp_output+0x580>
    5eec:      	add	x8, x0, #0x330
    5ef0:      	b	0x5f00 <generic_rawtp_output+0x580>
    5ef4:      	add	x8, x0, #0x320
    5ef8:      	nop
    5efc:      	nop
    5f00:      	ldaxr	x9, [x8]
    5f04:      	add	x9, x9, #0x1
    5f08:      	stlxr	w10, x9, [x8]
    5f0c:      	cbnz	w10, 0x5f00 <generic_rawtp_output+0x580>
    5f10:      	b	0x5f50 <generic_rawtp_output+0x5d0>
    5f14:      	add	x8, x0, #0x338
    5f18:      	b	0x5f40 <generic_rawtp_output+0x5c0>
    5f1c:      	add	x8, x0, #0x340
    5f20:      	b	0x5f40 <generic_rawtp_output+0x5c0>
    5f24:      	add	x8, x0, #0x310
    5f28:      	b	0x5f40 <generic_rawtp_output+0x5c0>
    5f2c:      	add	x8, x0, #0x330
    5f30:      	b	0x5f40 <generic_rawtp_output+0x5c0>
    5f34:      	add	x8, x0, #0x320
    5f38:      	nop
    5f3c:      	nop
    5f40:      	ldaxr	x9, [x8]
    5f44:      	add	x9, x9, #0x1
    5f48:      	stlxr	w10, x9, [x8]
    5f4c:      	cbnz	w10, 0x5f40 <generic_rawtp_output+0x5c0>
    5f50:      	ldp	x20, x19, [sp, #0xb0]
    5f54:      	mov	w0, wzr
    5f58:      	ldr	x29, [sp, #0x70]
    5f5c:      	ldp	x22, x21, [sp, #0xa0]
    5f60:      	ldp	x24, x23, [sp, #0x90]
    5f64:      	ldp	x30, x25, [sp, #0x80]
    5f68:      	add	sp, sp, #0xc0
    5f6c:      	ret

Disassembly of section raw_tp/generic_tracepoint:

0000000000000000 <generic_rawtp_event>:
       0:      	sub	sp, sp, #0xd0
       4:      	stp	x30, x25, [sp, #0x90]
       8:      	stp	x24, x23, [sp, #0xa0]
       c:      	stp	x22, x21, [sp, #0xb0]
      10:      	stp	x20, x19, [sp, #0xc0]
      14:      	mov	x19, x0
      18:      	str	wzr, [sp, #0xc]
      1c:      	adrp	x0, 0x0 <generic_rawtp_event>
      20:      	mov	w8, #0x1                // =1
      24:      	ldr	x0, [x0]
      28:      	add	x9, sp, #0xc
      2c:      	add	x1, sp, #0xc
      30:      	blr	x8
      34:      	cbz	x0, 0x538 <generic_rawtp_event+0x538>
      38:      	add	x23, x0, #0x5, lsl #12  // =0x5000
      3c:      	mov	x20, x0
      40:      	adrp	x0, 0x0 <generic_rawtp_event>
      44:      	str	wzr, [x23, #0xef8]
      48:      	add	x1, x23, #0xef8
      4c:      	mov	w8, #0x1                // =1
      50:      	ldr	x0, [x0]
      54:      	blr	x8
      58:      	cbz	x0, 0x538 <generic_rawtp_event+0x538>
      5c:      	ldr	w8, [x0, #0x64]
      60:      	str	w8, [sp, #0x1c]
      64:      	cbz	w8, 0x220 <generic_rawtp_event+0x220>
      68:      	adrp	x21, 0x0 <generic_rawtp_event>
      6c:      	mov	w8, #0x1                // =1
      70:      	add	x9, sp, #0x1c
      74:      	ldr	x21, [x21]
      78:      	mov	x24, x0
      7c:      	add	x1, sp, #0x1c
      80:      	mov	x0, x21
      84:      	blr	x8
      88:      	cbz	x0, 0x538 <generic_rawtp_event+0x538>
      8c:      	mov	x22, x0
      90:      	str	wzr, [sp, #0x84]
      94:      	adrp	x0, 0x0 <generic_rawtp_event>
      98:      	mov	w8, #0x1                // =1
      9c:      	ldr	x0, [x0]
      a0:      	add	x9, sp, #0x84
      a4:      	add	x1, sp, #0x84
      a8:      	blr	x8
      ac:      	cbz	x0, 0xd8 <generic_rawtp_event+0xd8>
      b0:      	ldr	x8, [x0, #0x20]
      b4:      	mov	w9, #0x7270             // =29296
      b8:      	movk	w9, #0x6367, lsl #16
      bc:      	cmp	x8, x9
      c0:      	b.ne	0xe0 <generic_rawtp_event+0xe0>
      c4:      	mov	w8, #0x50               // =80
      c8:      	blr	x8
      cc:      	str	x0, [sp, #0x30]
      d0:      	cbnz	x0, 0x1d4 <generic_rawtp_event+0x1d4>
      d4:      	b	0x538 <generic_rawtp_event+0x538>
      d8:      	mov	w25, wzr
      dc:      	b	0xe4 <generic_rawtp_event+0xe4>
      e0:      	ldr	w25, [x0, #0x10]
      e4:      	mov	w8, #0x23               // =35
      e8:      	blr	x8
      ec:      	str	xzr, [sp, #0x88]
      f0:      	add	x2, x0, #0xcd0
      f4:      	mov	w8, #0x8                // =8
      f8:      	mov	w9, #0x71               // =113
      fc:      	add	x10, sp, #0x20
     100:      	add	x0, sp, #0x20
     104:      	mov	w1, #0x8                // =8
     108:      	blr	x9
     10c:      	ldr	x8, [sp, #0x20]
     110:      	cbz	x8, 0x538 <generic_rawtp_event+0x538>
     114:      	cmp	w25, #0xb
     118:      	b.hi	0x538 <generic_rawtp_event+0x538>
     11c:      	ubfiz	x9, x25, #3, #32
     120:      	mov	w10, #0x8               // =8
     124:      	mov	w11, #0x71              // =113
     128:      	add	x12, sp, #0x38
     12c:      	add	x0, sp, #0x38
     130:      	mov	w1, #0x8                // =8
     134:      	add	x8, x8, x9
     138:      	ldr	x8, [sp, #0x20]
     13c:      	add	x2, x8, x9
     140:      	blr	x11
     144:      	ldr	x8, [sp, #0x38]
     148:      	cbz	x8, 0x538 <generic_rawtp_event+0x538>
     14c:      	mov	w9, #0x8                // =8
     150:      	mov	w10, #0x71              // =113
     154:      	add	x11, sp, #0x88
     158:      	ldr	x2, [sp, #0x38]
     15c:      	add	x0, sp, #0x88
     160:      	mov	w1, #0x8                // =8
     164:      	blr	x10
     168:      	ldr	x8, [sp, #0x88]
     16c:      	cbz	x8, 0x538 <generic_rawtp_event+0x538>
     170:      	str	xzr, [sp, #0x38]
     174:      	add	x2, x8, #0x100
     178:      	mov	w8, #0x8                // =8
     17c:      	mov	w9, #0x71               // =113
     180:      	add	x10, sp, #0x38
     184:      	add	x0, sp, #0x38
     188:      	mov	w1, #0x8                // =8
     18c:      	blr	x9
     190:      	ldr	x8, [sp, #0x38]
     194:      	str	xzr, [sp, #0x38]
     198:      	cbz	x8, 0x1c8 <generic_rawtp_event+0x1c8>
     19c:      	add	x2, x8, #0x60
     1a0:      	mov	w8, #0x8                // =8
     1a4:      	mov	w9, #0x71               // =113
     1a8:      	add	x10, sp, #0x38
     1ac:      	add	x0, sp, #0x38
     1b0:      	mov	w1, #0x8                // =8
     1b4:      	blr	x9
     1b8:      	ldr	x0, [sp, #0x38]
     1bc:      	str	x0, [sp, #0x30]
     1c0:      	cbnz	x0, 0x1d4 <generic_rawtp_event+0x1d4>
     1c4:      	b	0x538 <generic_rawtp_event+0x538>
     1c8:      	mov	x0, xzr
     1cc:      	str	xzr, [sp, #0x30]
     1d0:      	cbz	xzr, 0x538 <generic_rawtp_event+0x538>
     1d4:      	str	x0, [sp, #0x38]
     1d8:      	adrp	x0, 0x0 <generic_rawtp_event>
     1dc:      	mov	w8, #0x1                // =1
     1e0:      	add	x9, sp, #0x38
     1e4:      	ldr	x0, [x0]
     1e8:      	add	x1, sp, #0x38
     1ec:      	blr	x8
     1f0:      	cbz	x0, 0x200 <generic_rawtp_event+0x200>
     1f4:      	ldr	x8, [x0]
     1f8:      	cbz	x8, 0x200 <generic_rawtp_event+0x200>
     1fc:      	str	x8, [sp, #0x30]
     200:      	mov	w8, #0x1                // =1
     204:      	add	x9, sp, #0x30
     208:      	add	x1, sp, #0x30
     20c:      	mov	x0, x22
     210:      	blr	x8
     214:      	mov	x8, x0
     218:      	mov	x0, x24
     21c:      	cbz	x8, 0x554 <generic_rawtp_event+0x554>
     220:      	ldr	w8, [x0]
     224:      	add	x9, x23, #0xefc
     228:      	str	xzr, [x20, #0x5eb8]
     22c:      	str	xzr, [x20, #0x5ec0]
     230:      	str	xzr, [x20, #0x5ec8]
     234:      	str	xzr, [x9]
     238:      	str	xzr, [x20, #0x5ed0]
     23c:      	str	xzr, [x20, #0x5ed8]
     240:      	stp	x8, xzr, [x20, #0x60]
     244:      	mov	w8, #0x5eb8             // =24248
     248:      	add	x8, x20, x8
     24c:      	strb	wzr, [x8, #0x28]
     250:      	mov	w8, #0x23               // =35
     254:      	blr	x8
     258:      	add	x2, x0, #0xb50
     25c:      	mov	w25, #0x8               // =8
     260:      	add	x8, sp, #0x88
     264:      	mov	w9, #0x4                // =4
     268:      	mov	x21, x0
     26c:      	add	x0, sp, #0x88
     270:      	mov	w1, #0x8                // =8
     274:      	add	x22, x20, #0x20
     278:      	mov	w24, #0x4               // =4
     27c:      	blr	x9
     280:      	ldr	x8, [sp, #0x88]
     284:      	mov	w9, #0x48               // =72
     288:      	add	x10, sp, #0x38
     28c:      	mov	w11, #0x4               // =4
     290:      	ldr	x2, [sp, #0x88]
     294:      	add	x0, sp, #0x38
     298:      	mov	w1, #0x48               // =72
     29c:      	blr	x11
     2a0:      	ldr	x8, [sp, #0x40]
     2a4:      	mov	w9, #0x4                // =4
     2a8:      	mov	x0, x22
     2ac:      	mov	w1, #0x4                // =4
     2b0:      	add	x8, x8, #0x218
     2b4:      	ldr	x8, [sp, #0x40]
     2b8:      	add	x2, x8, #0x218
     2bc:      	blr	x9
     2c0:      	ldr	x8, [sp, #0x48]
     2c4:      	add	x0, x20, #0x24
     2c8:      	mov	w9, #0x4                // =4
     2cc:      	mov	w1, #0x4                // =4
     2d0:      	add	x8, x8, #0x4d8
     2d4:      	ldr	x8, [sp, #0x48]
     2d8:      	add	x2, x8, #0x4d8
     2dc:      	blr	x9
     2e0:      	ldr	x8, [sp, #0x50]
     2e4:      	add	x0, x20, #0x28
     2e8:      	mov	w9, #0x4                // =4
     2ec:      	mov	w1, #0x4                // =4
     2f0:      	add	x8, x8, #0x58
     2f4:      	ldr	x8, [sp, #0x50]
     2f8:      	add	x2, x8, #0x58
     2fc:      	blr	x9
     300:      	str	xzr, [sp, #0x30]
     304:      	add	x2, x21, #0x938
     308:      	add	x8, sp, #0x30
     30c:      	add	x0, sp, #0x30
     310:      	mov	w1, #0x8                // =8
     314:      	blr	x24
     318:      	ldr	x8, [sp, #0x30]
     31c:      	cbz	x8, 0x3a0 <generic_rawtp_event+0x3a0>
     320:      	str	wzr, [sp, #0x10]
     324:      	add	x8, x8, #0x4
     328:      	add	x9, sp, #0x10
     32c:      	mov	w10, #0x4               // =4
     330:      	add	x0, sp, #0x10
     334:      	mov	w1, #0x4                // =4
     338:      	mov	w22, #0x4               // =4
     33c:      	ldr	x8, [sp, #0x30]
     340:      	add	x2, x8, #0x4
     344:      	blr	x10
     348:      	ldr	x8, [sp, #0x30]
     34c:      	ldrsw	x9, [sp, #0x10]
     350:      	add	x10, sp, #0x20
     354:      	mov	w11, #0x4               // =4
     358:      	add	x0, sp, #0x20
     35c:      	mov	w1, #0x10               // =16
     360:      	add	x8, x8, x9, lsl #4
     364:      	mov	w9, #0x10               // =16
     368:      	add	x8, x8, #0x80
     36c:      	ldr	x8, [sp, #0x30]
     370:      	ldrsw	x9, [sp, #0x10]
     374:      	add	x8, x8, x9, lsl #4
     378:      	add	x2, x8, #0x80
     37c:      	blr	x11
     380:      	ldr	x8, [sp, #0x28]
     384:      	add	x0, x20, #0x2c
     388:      	mov	w1, #0x4                // =4
     38c:      	add	x8, x8, #0x158
     390:      	ldr	x8, [sp, #0x28]
     394:      	add	x2, x8, #0x158
     398:      	blr	x22
     39c:      	b	0x3a4 <generic_rawtp_event+0x3a4>
     3a0:      	str	wzr, [x20, #0x2c]
     3a4:      	ldr	x8, [sp, #0x58]
     3a8:      	add	x0, x20, #0x30
     3ac:      	mov	w9, #0x4                // =4
     3b0:      	mov	w1, #0x4                // =4
     3b4:      	mov	w24, #0x4               // =4
     3b8:      	add	x8, x8, #0x158
     3bc:      	ldr	x8, [sp, #0x58]
     3c0:      	add	x2, x8, #0x158
     3c4:      	blr	x9
     3c8:      	ldr	x8, [sp, #0x60]
     3cc:      	add	x0, x20, #0x34
     3d0:      	mov	w9, #0x4                // =4
     3d4:      	mov	w1, #0x4                // =4
     3d8:      	add	x8, x8, #0x118
     3dc:      	ldr	x8, [sp, #0x60]
     3e0:      	add	x2, x8, #0x118
     3e4:      	blr	x9
     3e8:      	ldr	x8, [sp, #0x68]
     3ec:      	add	x0, x20, #0x38
     3f0:      	mov	w9, #0x4                // =4
     3f4:      	mov	w1, #0x4                // =4
     3f8:      	add	x8, x8, #0x98
     3fc:      	ldr	x8, [sp, #0x68]
     400:      	add	x2, x8, #0x98
     404:      	blr	x9
     408:      	ldr	x8, [sp, #0x70]
     40c:      	add	x0, x20, #0x3c
     410:      	mov	w9, #0x4                // =4
     414:      	mov	w1, #0x4                // =4
     418:      	add	x8, x8, #0x98
     41c:      	ldr	x8, [sp, #0x70]
     420:      	add	x2, x8, #0x98
     424:      	blr	x9
     428:      	ldr	x8, [sp, #0x78]
     42c:      	add	x0, x20, #0x40
     430:      	mov	w9, #0x4                // =4
     434:      	mov	w1, #0x4                // =4
     438:      	add	x8, x8, #0x58
     43c:      	ldr	x8, [sp, #0x78]
     440:      	add	x2, x8, #0x58
     444:      	blr	x9
     448:      	str	xzr, [sp, #0x20]
     44c:      	str	xzr, [sp, #0x30]
     450:      	add	x21, x21, #0xae0
     454:      	mov	w25, #0x8               // =8
     458:      	add	x8, sp, #0x20
     45c:      	mov	w9, #0x4                // =4
     460:      	add	x0, sp, #0x20
     464:      	mov	w1, #0x8                // =8
     468:      	mov	x2, x21
     46c:      	blr	x9
     470:      	ldr	x8, [sp, #0x20]
     474:      	add	x9, sp, #0x30
     478:      	mov	w10, #0x4               // =4
     47c:      	add	x0, sp, #0x30
     480:      	mov	w1, #0x8                // =8
     484:      	add	x8, x8, #0x90
     488:      	ldr	x8, [sp, #0x20]
     48c:      	add	x2, x8, #0x90
     490:      	blr	x10
     494:      	ldr	x8, [sp, #0x30]
     498:      	add	x0, x20, #0x44
     49c:      	mov	w9, #0x4                // =4
     4a0:      	mov	w1, #0x4                // =4
     4a4:      	add	x8, x8, #0x158
     4a8:      	ldr	x8, [sp, #0x30]
     4ac:      	add	x2, x8, #0x158
     4b0:      	blr	x9
     4b4:      	add	x8, sp, #0x38
     4b8:      	mov	w9, #0x4                // =4
     4bc:      	add	x0, sp, #0x38
     4c0:      	mov	w1, #0x8                // =8
     4c4:      	mov	x2, x21
     4c8:      	add	x22, x20, #0x48
     4cc:      	blr	x9
     4d0:      	ldr	x21, [sp, #0x38]
     4d4:      	add	x0, x20, #0x50
     4d8:      	mov	w8, #0x4                // =4
     4dc:      	mov	w1, #0x8                // =8
     4e0:      	add	x2, x21, #0x40
     4e4:      	blr	x8
     4e8:      	add	x0, x20, #0x58
     4ec:      	add	x2, x21, #0x30
     4f0:      	mov	w8, #0x4                // =4
     4f4:      	mov	w1, #0x8                // =8
     4f8:      	blr	x8
     4fc:      	add	x2, x21, #0x38
     500:      	mov	x0, x22
     504:      	mov	w1, #0x8                // =8
     508:      	blr	x24
     50c:      	strb	wzr, [x23, #0xf08]
     510:      	strb	wzr, [x20, #0x1]
     514:      	adrp	x1, 0x0 <generic_rawtp_event>
     518:      	mov	w8, #0x2                // =2
     51c:      	mov	w9, #0xc                // =12
     520:      	mov	x0, x19
     524:      	str	xzr, [x20, #0x5ee8]
     528:      	str	xzr, [x20, #0x5ef0]
     52c:      	ldr	x1, [x1]
     530:      	mov	w2, #0x2                // =2
     534:      	blr	x9
     538:      	ldp	x20, x19, [sp, #0xc0]
     53c:      	mov	w0, wzr
     540:      	ldp	x22, x21, [sp, #0xb0]
     544:      	ldp	x24, x23, [sp, #0xa0]
     548:      	ldp	x30, x25, [sp, #0x90]
     54c:      	add	sp, sp, #0xd0
     550:      	ret
     554:      	mov	x8, #-0x1               // =-1
     558:      	mov	w9, #0x1                // =1
     55c:      	add	x1, sp, #0x10
     560:      	str	x8, [sp, #0x10]
     564:      	add	x8, sp, #0x10
     568:      	mov	x0, x22
     56c:      	mov	w25, #0x1               // =1
     570:      	blr	x9
     574:      	cbz	x0, 0x538 <generic_rawtp_event+0x538>
     578:      	str	w25, [sp, #0x1c]
     57c:      	add	x8, sp, #0x1c
     580:      	add	x1, sp, #0x1c
     584:      	mov	x0, x21
     588:      	blr	x25
     58c:      	cbz	x0, 0x538 <generic_rawtp_event+0x538>
     590:      	mov	w8, #0x1                // =1
     594:      	add	x9, sp, #0x30
     598:      	add	x1, sp, #0x30
     59c:      	blr	x8
     5a0:      	mov	x8, x0
     5a4:      	mov	x0, x24
     5a8:      	cbnz	x8, 0x538 <generic_rawtp_event+0x538>
     5ac:      	b	0x220 <generic_rawtp_event+0x220>
