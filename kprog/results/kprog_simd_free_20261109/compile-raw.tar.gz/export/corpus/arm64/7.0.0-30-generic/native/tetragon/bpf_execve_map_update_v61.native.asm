
/var/tmp/kprog-tmp/S14/export/corpus/arm64/7.0.0-30-generic/native/tetragon/bpf_execve_map_update_v61.native.o:	file format elf64-littleaarch64

Disassembly of section socket:

0000000000000000 <execve_map_update>:
       0:      	sub	sp, sp, #0x40
       4:      	stp	x30, x23, [sp, #0x10]
       8:      	stp	x22, x21, [sp, #0x20]
       c:      	stp	x20, x19, [sp, #0x30]
      10:      	str	wzr, [sp, #0x4]
      14:      	adrp	x0, 0x0 <execve_map_update>
      18:      	mov	w8, #0x1                // =1
      1c:      	add	x9, sp, #0x4
      20:      	ldr	x0, [x0]
      24:      	add	x1, sp, #0x4
      28:      	blr	x8
      2c:      	cbz	x0, 0xc0 <execve_map_update+0xc0>
      30:      	adrp	x8, 0x0 <execve_map_update>
      34:      	mov	x19, x0
      38:      	ldr	x8, [x8]
      3c:      	ldrb	w8, [x8]
      40:      	cbz	w8, 0xd8 <execve_map_update+0xd8>
      44:      	adrp	x20, 0x0 <execve_map_update>
      48:      	mov	x21, xzr
      4c:      	mov	w22, #0x1               // =1
      50:      	ldr	x20, [x20]
      54:      	add	x23, sp, #0x8
      58:      	b	0x6c <execve_map_update+0x6c>
      5c:      	nop
      60:      	add	x21, x21, #0x1
      64:      	cmp	x21, #0x8, lsl #12      // =0x8000
      68:      	b.eq	0x160 <execve_map_update+0x160>
      6c:      	ldr	w8, [x19, #0x4]
      70:      	cmp	x21, x8
      74:      	b.eq	0x160 <execve_map_update+0x160>
      78:      	add	x8, x19, x21, lsl #2
      7c:      	add	x1, sp, #0x8
      80:      	mov	x0, x20
      84:      	ldr	w8, [x8, #0x8]
      88:      	str	w8, [sp, #0x8]
      8c:      	mov	w8, #0x1                // =1
      90:      	blr	x8
      94:      	cbz	x0, 0x60 <execve_map_update+0x60>
      98:      	ldr	w9, [x19]
      9c:      	add	x8, x0, #0x370
      a0:      	lsl	w9, w22, w9
      a4:      	mvn	w9, w9
      a8:      	sxtw	x9, w9
      ac:      	ldaxr	x10, [x8]
      b0:      	and	x10, x10, x9
      b4:      	stlxr	w11, x10, [x8]
      b8:      	cbnz	w11, 0xac <execve_map_update+0xac>
      bc:      	b	0x60 <execve_map_update+0x60>
      c0:      	mov	w0, #-0x1               // =-1
      c4:      	ldp	x20, x19, [sp, #0x30]
      c8:      	ldp	x22, x21, [sp, #0x20]
      cc:      	ldp	x30, x23, [sp, #0x10]
      d0:      	add	sp, sp, #0x40
      d4:      	ret
      d8:      	adrp	x20, 0x0 <execve_map_update>
      dc:      	mov	x21, xzr
      e0:      	mov	w22, #0x1               // =1
      e4:      	ldr	x20, [x20]
      e8:      	add	x23, sp, #0xc
      ec:      	b	0x10c <execve_map_update+0x10c>
      f0:      	nop
      f4:      	nop
      f8:      	nop
      fc:      	nop
     100:      	add	x21, x21, #0x1
     104:      	cmp	x21, #0x400
     108:      	b.eq	0x160 <execve_map_update+0x160>
     10c:      	ldr	w8, [x19, #0x4]
     110:      	cmp	x21, x8
     114:      	b.eq	0x160 <execve_map_update+0x160>
     118:      	add	x8, x19, x21, lsl #2
     11c:      	add	x1, sp, #0xc
     120:      	mov	x0, x20
     124:      	ldr	w8, [x8, #0x8]
     128:      	str	w8, [sp, #0xc]
     12c:      	mov	w8, #0x1                // =1
     130:      	blr	x8
     134:      	cbz	x0, 0x100 <execve_map_update+0x100>
     138:      	ldr	w9, [x19]
     13c:      	add	x8, x0, #0x370
     140:      	lsl	w9, w22, w9
     144:      	mvn	w9, w9
     148:      	sxtw	x9, w9
     14c:      	ldaxr	x10, [x8]
     150:      	and	x10, x10, x9
     154:      	stlxr	w11, x10, [x8]
     158:      	cbnz	w11, 0x14c <execve_map_update+0x14c>
     15c:      	b	0x100 <execve_map_update+0x100>
     160:      	mov	w0, wzr
     164:      	ldp	x20, x19, [sp, #0x30]
     168:      	ldp	x22, x21, [sp, #0x20]
     16c:      	ldp	x30, x23, [sp, #0x10]
     170:      	add	sp, sp, #0x40
     174:      	ret
